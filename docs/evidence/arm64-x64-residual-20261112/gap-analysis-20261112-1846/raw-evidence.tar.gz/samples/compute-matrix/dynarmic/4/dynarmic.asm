0000707649fce69b  nop [rax+rax*1], eax
0000707649fce6a0  vmovaps xmm1, [0x0000707649BFE010]
0000707649fce6a8  movq xmm1, xmm1
0000707649fce6ac  movaps [r15+0x110], xmm1
0000707649fce6b4  vmovaps xmm1, [0x0000707649BFE020]
0000707649fce6bc  movq xmm1, xmm1
0000707649fce6c0  movaps [r15+0x120], xmm1
0000707649fce6c8  mov eax, 0x4204C0
0000707649fce6cd  mov r14, [r13+rax*1]
0000707649fce6d2  movq xmm1, r14
0000707649fce6d7  movaps [r15+0x130], xmm1
0000707649fce6df  vmovaps xmm1, [0x0000707649BFE030]
0000707649fce6e7  vpbroadcastq xmm1, xmm1
0000707649fce6ec  movaps [r15+0x140], xmm1
0000707649fce6f4  mov qword ptr [r15+0x40], 0x02
0000707649fce6fc  vmovaps xmm15, [0x0000707649BFE040]
0000707649fce704  movq xmm15, xmm15
0000707649fce709  movaps [r15+0x150], xmm15
0000707649fce711  mov qword ptr [r15+0x58], 0x420000
0000707649fce719  vmovaps xmm15, [0x0000707649BFE050]
0000707649fce721  vpbroadcastq xmm15, xmm15
0000707649fce726  movaps [r15+0x160], xmm15
0000707649fce72e  mov rax, [r15+0x40]
0000707649fce732  vmovq xmm14, rax
0000707649fce737  vpbroadcastq xmm14, xmm14
0000707649fce73c  movaps [r15+0x170], xmm14
0000707649fce744  mov eax, 0x4204D0
0000707649fce749  movups xmm13, [r13+rax*1]
0000707649fce74f  mov qword ptr [r15+0x40], 0x430518
0000707649fce757  mov qword ptr [r15+0x50], 0x430720
0000707649fce75f  vpmovqd xmm12, xmm13
0000707649fce765  pxor xmm11, xmm11
0000707649fce76a  punpcklqdq xmm12, xmm11
0000707649fce76f  movaps [r15+0x210], xmm12
0000707649fce777  movq xmm12, qword ptr [r15+0x120]
0000707649fce780  movq xmm11, qword ptr [r15+0x130]
0000707649fce789  psubd xmm12, xmm11
0000707649fce78e  movq xmm12, xmm12
0000707649fce793  paddq xmm13, xmm14
0000707649fce798  movaps [r15+0x180], xmm13
0000707649fce7a0  movq xmm14, qword ptr [r15+0x150]
0000707649fce7a9  paddd xmm11, xmm14
0000707649fce7ae  movq xmm11, xmm11
0000707649fce7b3  movq xmm11, xmm11
0000707649fce7b8  movaps [r15+0x130], xmm11
0000707649fce7c0  pmovzxdq xmm12, xmm12
0000707649fce7c6  psllq xmm12, 0x00
0000707649fce7cc  movq xmm14, qword ptr [r15+0x210]
0000707649fce7d5  movq xmm13, qword ptr [r15+0x110]
0000707649fce7de  paddd xmm14, xmm13
0000707649fce7e3  movq xmm14, xmm14
0000707649fce7e8  vcvtuqq2pd xmm12, xmm12
0000707649fce7ee  pmovzxdq xmm14, xmm14
0000707649fce7f4  psllq xmm14, 0x00
0000707649fce7fa  vcvtuqq2pd xmm14, xmm14
0000707649fce800  movaps xmm13, xmm12
0000707649fce804  mulpd xmm13, xmm1
0000707649fce809  vcmppd xmm11, xmm13, xmm13, 0x03
0000707649fce80f  ptest xmm11, xmm11
0000707649fce815  jnz 0x0000707649FCE8FF
0000707649fce81b  movaps [r15+0x220], xmm13
0000707649fce823  mov eax, 0x430720
0000707649fce828  movups [r13+rax*1], xmm13
0000707649fce82e  movaps xmm1, xmm14
0000707649fce832  mulpd xmm1, xmm15
0000707649fce837  vcmppd xmm13, xmm1, xmm1, 0x03
0000707649fce83c  ptest xmm13, xmm13
0000707649fce842  jnz 0x0000707649FCEA4C
0000707649fce848  movaps [r15+0x210], xmm1
0000707649fce850  mov eax, 0x430518
0000707649fce855  movups [r13+rax*1], xmm1
0000707649fce85b  mov qword ptr [r15+0x48], 0x10
0000707649fce863  xor eax, eax
0000707649fce865  mov r14d, 0x10
0000707649fce86b  mov r12d, 0x200
0000707649fce871  cmp r14, r12
0000707649fce874  cmc
0000707649fce875  lahf
0000707649fce876  seto al
0000707649fce879  mov [r15+0x108], eax
0000707649fce880  mov eax, [r15+0x108]
0000707649fce887  sahf
0000707649fce888  jnz 0x0000707649FCE8BA
0000707649fce88a  cmp dword ptr [r15+0x318], 0x00
0000707649fce892  jz 0x0000707649FCEFF0
0000707649fce898  nop [rax+rax*1], ax
0000707649fce8a1  nop [rax+rax*1], eax
0000707649fce8a9  mov eax, 0x4101EC
0000707649fce8ae  mov [r15+0x100], rax
0000707649fce8b5  jmp 0x0000707649DFE110
0000707649fce8ba  cmp dword ptr [r15+0x318], 0x00
0000707649fce8c2  jz 0x0000707649FCEBA0
0000707649fce8c8  nop [rax+rax*1], ax
0000707649fce8d1  nop [rax+rax*1], eax
0000707649fce8d9  mov eax, 0x4101AC
0000707649fce8de  mov [r15+0x100], rax
0000707649fce8e5  jmp 0x0000707649DFE110
0000707649fce8ea  int3
0000707649fce8eb  call 0x0000707649E0DC20
0000707649fce8f0  jmp 0x0000707649FCE6D2
0000707649fce8f5  call 0x0000707649E0C260
0000707649fce8fa  jmp 0x0000707649FCE74F
0000707649fce8ff  sub rsp, 0x08
0000707649fce903  push rax
0000707649fce904  push rcx
0000707649fce905  push rdx
0000707649fce906  push rdi
0000707649fce907  push rsi
0000707649fce908  push r8
0000707649fce90a  push r9
0000707649fce90c  push r10
0000707649fce90e  push r11
0000707649fce910  sub rsp, 0xF0
0000707649fce917  vmovaps [rsp], xmm0
0000707649fce91c  vmovaps [rsp+0x10], xmm1
0000707649fce922  vmovaps [rsp+0x20], xmm2
0000707649fce928  vmovaps [rsp+0x30], xmm3
0000707649fce92e  vmovaps [rsp+0x40], xmm4
0000707649fce934  vmovaps [rsp+0x50], xmm5
0000707649fce93a  vmovaps [rsp+0x60], xmm6
0000707649fce940  vmovaps [rsp+0x70], xmm7
0000707649fce946  vmovaps [rsp+0x80], xmm8
0000707649fce94f  vmovaps [rsp+0x90], xmm9
0000707649fce958  vmovaps [rsp+0xA0], xmm10
0000707649fce961  vmovaps [rsp+0xB0], xmm11
0000707649fce96a  vmovaps [rsp+0xC0], xmm12
0000707649fce973  vmovaps [rsp+0xD0], xmm14
0000707649fce97c  vmovaps [rsp+0xE0], xmm15
0000707649fce985  sub rsp, 0x30
0000707649fce989  movaps [rsp], xmm13
0000707649fce98e  movaps [rsp+0x10], xmm12
0000707649fce994  movaps [rsp+0x20], xmm1
0000707649fce999  lea rdi, [rsp]
0000707649fce99d  mov esi, 0x00
0000707649fce9a2  mov rax, 0x59CB0B054530
0000707649fce9ac  call rax
0000707649fce9ae  movaps xmm13, [rsp]
0000707649fce9b3  add rsp, 0x30
0000707649fce9b7  vmovaps xmm0, [rsp]
0000707649fce9bc  vmovaps xmm1, [rsp+0x10]
0000707649fce9c2  vmovaps xmm2, [rsp+0x20]
0000707649fce9c8  vmovaps xmm3, [rsp+0x30]
0000707649fce9ce  vmovaps xmm4, [rsp+0x40]
0000707649fce9d4  vmovaps xmm5, [rsp+0x50]
0000707649fce9da  vmovaps xmm6, [rsp+0x60]
0000707649fce9e0  vmovaps xmm7, [rsp+0x70]
0000707649fce9e6  vmovaps xmm8, [rsp+0x80]
0000707649fce9ef  vmovaps xmm9, [rsp+0x90]
0000707649fce9f8  vmovaps xmm10, [rsp+0xA0]
0000707649fcea01  vmovaps xmm11, [rsp+0xB0]
0000707649fcea0a  vmovaps xmm12, [rsp+0xC0]
0000707649fcea13  vmovaps xmm14, [rsp+0xD0]
0000707649fcea1c  vmovaps xmm15, [rsp+0xE0]
0000707649fcea25  add rsp, 0xF0
0000707649fcea2c  pop r11
0000707649fcea2e  pop r10
0000707649fcea30  pop r9
0000707649fcea32  pop r8
0000707649fcea34  pop rsi
0000707649fcea35  pop rdi
0000707649fcea36  pop rdx
0000707649fcea37  pop rcx
0000707649fcea38  pop rax
0000707649fcea39  add rsp, 0x08
0000707649fcea3d  jmp 0x0000707649FCE81B
0000707649fcea42  call 0x0000707649E0C380
0000707649fcea47  jmp 0x0000707649FCE82E
0000707649fcea4c  sub rsp, 0x08
0000707649fcea50  push rax
0000707649fcea51  push rcx
0000707649fcea52  push rdx
0000707649fcea53  push rdi
0000707649fcea54  push rsi
0000707649fcea55  push r8
0000707649fcea57  push r9
0000707649fcea59  push r10
0000707649fcea5b  push r11
0000707649fcea5d  sub rsp, 0xF0
0000707649fcea64  vmovaps [rsp], xmm0
0000707649fcea69  vmovaps [rsp+0x10], xmm2
0000707649fcea6f  vmovaps [rsp+0x20], xmm3
0000707649fcea75  vmovaps [rsp+0x30], xmm4
0000707649fcea7b  vmovaps [rsp+0x40], xmm5
0000707649fcea81  vmovaps [rsp+0x50], xmm6
0000707649fcea87  vmovaps [rsp+0x60], xmm7
0000707649fcea8d  vmovaps [rsp+0x70], xmm8
0000707649fcea93  vmovaps [rsp+0x80], xmm9
0000707649fcea9c  vmovaps [rsp+0x90], xmm10
0000707649fceaa5  vmovaps [rsp+0xA0], xmm11
0000707649fceaae  vmovaps [rsp+0xB0], xmm12
0000707649fceab7  vmovaps [rsp+0xC0], xmm13
0000707649fceac0  vmovaps [rsp+0xD0], xmm14
0000707649fceac9  vmovaps [rsp+0xE0], xmm15
0000707649fcead2  sub rsp, 0x30
0000707649fcead6  movaps [rsp], xmm1
0000707649fceada  movaps [rsp+0x10], xmm14
0000707649fceae0  movaps [rsp+0x20], xmm15
0000707649fceae6  lea rdi, [rsp]
0000707649fceaea  mov esi, 0x00
0000707649fceaef  mov rax, 0x59CB0B054530
0000707649fceaf9  call rax
0000707649fceafb  movaps xmm1, [rsp]
0000707649fceaff  add rsp, 0x30
0000707649fceb03  vmovaps xmm0, [rsp]
0000707649fceb08  vmovaps xmm2, [rsp+0x10]
0000707649fceb0e  vmovaps xmm3, [rsp+0x20]
0000707649fceb14  vmovaps xmm4, [rsp+0x30]
0000707649fceb1a  vmovaps xmm5, [rsp+0x40]
0000707649fceb20  vmovaps xmm6, [rsp+0x50]
0000707649fceb26  vmovaps xmm7, [rsp+0x60]
0000707649fceb2c  vmovaps xmm8, [rsp+0x70]
0000707649fceb32  vmovaps xmm9, [rsp+0x80]
0000707649fceb3b  vmovaps xmm10, [rsp+0x90]
0000707649fceb44  vmovaps xmm11, [rsp+0xA0]
0000707649fceb4d  vmovaps xmm12, [rsp+0xB0]
0000707649fceb56  vmovaps xmm13, [rsp+0xC0]
0000707649fceb5f  vmovaps xmm14, [rsp+0xD0]
0000707649fceb68  vmovaps xmm15, [rsp+0xE0]
0000707649fceb71  add rsp, 0xF0
0000707649fceb78  pop r11
0000707649fceb7a  pop r10
0000707649fceb7c  pop r9
0000707649fceb7e  pop r8
0000707649fceb80  pop rsi
0000707649fceb81  pop rdi
0000707649fceb82  pop rdx
0000707649fceb83  pop rcx
0000707649fceb84  pop rax
0000707649fceb85  add rsp, 0x08
0000707649fceb89  jmp 0x0000707649FCE848
0000707649fceb8e  call 0x0000707649DFF540
0000707649fceb93  jmp 0x0000707649FCE85B
0000707649fceb98  int3
0000707649fceb99  nop [rax], eax
0000707649fceba0  movaps xmm1, [r15+0x180]
0000707649fceba8  vpmovqd xmm15, xmm1
0000707649fcebae  pxor xmm14, xmm14
0000707649fcebb3  punpcklqdq xmm15, xmm14
0000707649fcebb8  movaps [r15+0x210], xmm15
0000707649fcebc0  movq xmm15, qword ptr [r15+0x120]
0000707649fcebc9  movq xmm14, qword ptr [r15+0x130]
0000707649fcebd2  psubd xmm15, xmm14
0000707649fcebd7  movq xmm15, xmm15
0000707649fcebdc  movaps xmm13, [r15+0x170]
0000707649fcebe4  paddq xmm1, xmm13
0000707649fcebe9  movaps [r15+0x180], xmm1
0000707649fcebf1  movq xmm1, qword ptr [r15+0x150]
0000707649fcebfa  paddd xmm14, xmm1
0000707649fcebff  movq xmm14, xmm14
0000707649fcec04  movq xmm14, xmm14
0000707649fcec09  movaps [r15+0x130], xmm14
0000707649fcec11  pmovzxdq xmm15, xmm15
0000707649fcec17  psllq xmm15, 0x00
0000707649fcec1d  movq xmm1, qword ptr [r15+0x210]
0000707649fcec26  movq xmm14, qword ptr [r15+0x110]
0000707649fcec2f  paddd xmm1, xmm14
0000707649fcec34  movq xmm1, xmm1
0000707649fcec38  vcvtuqq2pd xmm15, xmm15
0000707649fcec3e  pmovzxdq xmm1, xmm1
0000707649fcec43  psllq xmm1, 0x00
0000707649fcec48  vcvtuqq2pd xmm1, xmm1
0000707649fcec4e  movaps xmm14, [r15+0x140]
0000707649fcec56  movaps xmm13, xmm15
0000707649fcec5a  mulpd xmm13, xmm14
0000707649fcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
0000707649fcec65  ptest xmm12, xmm12
0000707649fcec6b  jnz 0x0000707649FCED4E
0000707649fcec71  movaps [r15+0x220], xmm13
0000707649fcec79  mov rax, [r15+0x48]
0000707649fcec7d  mov r14, [r15+0x50]
0000707649fcec81  lea r12, [r14+rax*1]
0000707649fcec85  movups [r13+r12*1], xmm13
0000707649fcec8b  movaps xmm15, [r15+0x160]
0000707649fcec93  movaps xmm14, xmm1
0000707649fcec97  mulpd xmm14, xmm15
0000707649fcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
0000707649fceca2  ptest xmm13, xmm13
0000707649fceca8  jnz 0x0000707649FCEE9C
0000707649fcecae  movaps [r15+0x210], xmm14
0000707649fcecb6  mov r14, [r15+0x40]
0000707649fcecba  lea r12, [r14+rax*1]
0000707649fcecbe  movups [r13+r12*1], xmm14
0000707649fcecc4  lea r14, [rax+0x10]
0000707649fcecc8  mov [r15+0x48], r14
0000707649fceccc  xor eax, eax
0000707649fcecce  mov r12d, 0x200
0000707649fcecd4  cmp r14, r12
0000707649fcecd7  cmc
0000707649fcecd8  lahf
0000707649fcecd9  seto al
0000707649fcecdc  mov [r15+0x108], eax
0000707649fcece3  mov eax, [r15+0x108]
0000707649fcecea  sahf
0000707649fceceb  jnz 0x0000707649FCED1D
0000707649fceced  cmp dword ptr [r15+0x318], 0x00
0000707649fcecf5  jz 0x0000707649FCEFF0
0000707649fcecfb  nop [rax+rax*1], ax
0000707649fced04  nop [rax+rax*1], eax
0000707649fced0c  mov eax, 0x4101EC
0000707649fced11  mov [r15+0x100], rax
0000707649fced18  jmp 0x0000707649DFE110
0000707649fced1d  cmp dword ptr [r15+0x318], 0x00
0000707649fced25  jz 0x0000707649FCEBA0
0000707649fced2b  nop [rax+rax*1], ax
0000707649fced34  nop [rax+rax*1], eax
0000707649fced3c  mov eax, 0x4101AC
0000707649fced41  mov [r15+0x100], rax
0000707649fced48  jmp 0x0000707649DFE110
0000707649fced4d  int3
0000707649fced4e  sub rsp, 0x08
0000707649fced52  push rax
0000707649fced53  push rcx
0000707649fced54  push rdx
0000707649fced55  push rdi
0000707649fced56  push rsi
0000707649fced57  push r8
0000707649fced59  push r9
0000707649fced5b  push r10
0000707649fced5d  push r11
0000707649fced5f  sub rsp, 0xF0
0000707649fced66  vmovaps [rsp], xmm0
0000707649fced6b  vmovaps [rsp+0x10], xmm1
0000707649fced71  vmovaps [rsp+0x20], xmm2
0000707649fced77  vmovaps [rsp+0x30], xmm3
0000707649fced7d  vmovaps [rsp+0x40], xmm4
0000707649fced83  vmovaps [rsp+0x50], xmm5
0000707649fced89  vmovaps [rsp+0x60], xmm6
0000707649fced8f  vmovaps [rsp+0x70], xmm7
0000707649fced95  vmovaps [rsp+0x80], xmm8
0000707649fced9e  vmovaps [rsp+0x90], xmm9
0000707649fceda7  vmovaps [rsp+0xA0], xmm10
0000707649fcedb0  vmovaps [rsp+0xB0], xmm11
0000707649fcedb9  vmovaps [rsp+0xC0], xmm12
0000707649fcedc2  vmovaps [rsp+0xD0], xmm14
0000707649fcedcb  vmovaps [rsp+0xE0], xmm15
0000707649fcedd4  sub rsp, 0x30
0000707649fcedd8  movaps [rsp], xmm13
0000707649fceddd  movaps [rsp+0x10], xmm15
0000707649fcede3  movaps [rsp+0x20], xmm14
0000707649fcede9  lea rdi, [rsp]
0000707649fceded  mov esi, 0x00
0000707649fcedf2  mov rax, 0x59CB0B054530
0000707649fcedfc  call rax
0000707649fcedfe  movaps xmm13, [rsp]
0000707649fcee03  add rsp, 0x30
0000707649fcee07  vmovaps xmm0, [rsp]
0000707649fcee0c  vmovaps xmm1, [rsp+0x10]
0000707649fcee12  vmovaps xmm2, [rsp+0x20]
0000707649fcee18  vmovaps xmm3, [rsp+0x30]
0000707649fcee1e  vmovaps xmm4, [rsp+0x40]
0000707649fcee24  vmovaps xmm5, [rsp+0x50]
0000707649fcee2a  vmovaps xmm6, [rsp+0x60]
0000707649fcee30  vmovaps xmm7, [rsp+0x70]
0000707649fcee36  vmovaps xmm8, [rsp+0x80]
0000707649fcee3f  vmovaps xmm9, [rsp+0x90]
0000707649fcee48  vmovaps xmm10, [rsp+0xA0]
0000707649fcee51  vmovaps xmm11, [rsp+0xB0]
0000707649fcee5a  vmovaps xmm12, [rsp+0xC0]
0000707649fcee63  vmovaps xmm14, [rsp+0xD0]
0000707649fcee6c  vmovaps xmm15, [rsp+0xE0]
0000707649fcee75  add rsp, 0xF0
0000707649fcee7c  pop r11
0000707649fcee7e  pop r10
0000707649fcee80  pop r9
0000707649fcee82  pop r8
0000707649fcee84  pop rsi
0000707649fcee85  pop rdi
0000707649fcee86  pop rdx
0000707649fcee87  pop rcx
0000707649fcee88  pop rax
0000707649fcee89  add rsp, 0x08
0000707649fcee8d  jmp 0x0000707649FCEC71
0000707649fcee92  call 0x0000707649EC2240
0000707649fcee97  jmp 0x0000707649FCEC8B
0000707649fcee9c  sub rsp, 0x08
0000707649fceea0  push rax
0000707649fceea1  push rcx
0000707649fceea2  push rdx
0000707649fceea3  push rdi
0000707649fceea4  push rsi
0000707649fceea5  push r8
0000707649fceea7  push r9
0000707649fceea9  push r10
0000707649fceeab  push r11
0000707649fceead  sub rsp, 0xF0
0000707649fceeb4  vmovaps [rsp], xmm0
0000707649fceeb9  vmovaps [rsp+0x10], xmm1
0000707649fceebf  vmovaps [rsp+0x20], xmm2
0000707649fceec5  vmovaps [rsp+0x30], xmm3
0000707649fceecb  vmovaps [rsp+0x40], xmm4
0000707649fceed1  vmovaps [rsp+0x50], xmm5
0000707649fceed7  vmovaps [rsp+0x60], xmm6
0000707649fceedd  vmovaps [rsp+0x70], xmm7
0000707649fceee3  vmovaps [rsp+0x80], xmm8
0000707649fceeec  vmovaps [rsp+0x90], xmm9
0000707649fceef5  vmovaps [rsp+0xA0], xmm10
0000707649fceefe  vmovaps [rsp+0xB0], xmm11
0000707649fcef07  vmovaps [rsp+0xC0], xmm12
0000707649fcef10  vmovaps [rsp+0xD0], xmm13
0000707649fcef19  vmovaps [rsp+0xE0], xmm15
0000707649fcef22  sub rsp, 0x30
0000707649fcef26  movaps [rsp], xmm14
0000707649fcef2b  movaps [rsp+0x10], xmm1
0000707649fcef30  movaps [rsp+0x20], xmm15
0000707649fcef36  lea rdi, [rsp]
0000707649fcef3a  mov esi, 0x00
0000707649fcef3f  mov rax, 0x59CB0B054530
0000707649fcef49  call rax
0000707649fcef4b  movaps xmm14, [rsp]
0000707649fcef50  add rsp, 0x30
0000707649fcef54  vmovaps xmm0, [rsp]
0000707649fcef59  vmovaps xmm1, [rsp+0x10]
0000707649fcef5f  vmovaps xmm2, [rsp+0x20]
0000707649fcef65  vmovaps xmm3, [rsp+0x30]
0000707649fcef6b  vmovaps xmm4, [rsp+0x40]
0000707649fcef71  vmovaps xmm5, [rsp+0x50]
0000707649fcef77  vmovaps xmm6, [rsp+0x60]
0000707649fcef7d  vmovaps xmm7, [rsp+0x70]
0000707649fcef83  vmovaps xmm8, [rsp+0x80]
0000707649fcef8c  vmovaps xmm9, [rsp+0x90]
0000707649fcef95  vmovaps xmm10, [rsp+0xA0]
0000707649fcef9e  vmovaps xmm11, [rsp+0xB0]
0000707649fcefa7  vmovaps xmm12, [rsp+0xC0]
0000707649fcefb0  vmovaps xmm13, [rsp+0xD0]
0000707649fcefb9  vmovaps xmm15, [rsp+0xE0]
0000707649fcefc2  add rsp, 0xF0
0000707649fcefc9  pop r11
0000707649fcefcb  pop r10
0000707649fcefcd  pop r9
0000707649fcefcf  pop r8
0000707649fcefd1  pop rsi
0000707649fcefd2  pop rdi
0000707649fcefd3  pop rdx
0000707649fcefd4  pop rcx
0000707649fcefd5  pop rax
0000707649fcefd6  add rsp, 0x08
0000707649fcefda  jmp 0x0000707649FCECAE
0000707649fcefdf  call 0x0000707649EC34C0
0000707649fcefe4  jmp 0x0000707649FCECC4
0000707649fcefe9  int3
0000707649fcefea  nop [rax+rax*1], ax
0000707649fceff0  mov rax, [r15+0xF8]
0000707649fceff7  lea r14, [rax-0x150]
0000707649fceffe  mov [r15+0xF8], r14
0000707649fcf005  mov rax, [r15+0x50]
0000707649fcf009  lea r12, [rax+0x80]
0000707649fcf010  movups xmm1, [r13+r12*1]
0000707649fcf016  lea r12, [rax+0x90]
0000707649fcf01d  movups xmm15, [r13+r12*1]
0000707649fcf023  mov qword ptr [r15+0x48], 0x00
0000707649fcf02b  lea r12, [rax+0x40]
0000707649fcf02f  movups xmm14, [r13+r12*1]
0000707649fcf035  lea r12, [rax+0x50]
0000707649fcf039  movups xmm13, [r13+r12*1]
0000707649fcf03f  lea r12, [r14+0x120]
0000707649fcf046  movq xmm12, qword ptr [r15+0x1C0]
0000707649fcf04f  movq xmm11, qword ptr [r15+0x1B0]
0000707649fcf058  movq r11, xmm12
0000707649fcf05d  movq r10, xmm11
0000707649fcf062  mov [r13+r12*1], r11
0000707649fcf067  lea r12, [r14+0x128]
0000707649fcf06e  mov [r13+r12*1], r10
0000707649fcf073  vxorps xmm12, xmm12, xmm12
0000707649fcf078  vpbroadcastq xmm12, xmm12
0000707649fcf07d  lea r12, [r14+0x100]
0000707649fcf084  movq xmm11, qword ptr [r15+0x200]
0000707649fcf08d  movq xmm10, qword ptr [r15+0x1F0]
0000707649fcf096  movq r11, xmm11
0000707649fcf09b  movq r10, xmm10
0000707649fcf0a0  mov [r13+r12*1], r11
0000707649fcf0a5  lea r12, [r14+0x108]
0000707649fcf0ac  mov [r13+r12*1], r10
0000707649fcf0b1  lea r12, [r14+0xE0]
0000707649fcf0b8  movups [r13+r12*1], xmm15
0000707649fcf0be  lea r12, [r14+0xF0]
0000707649fcf0c5  movups [r13+r12*1], xmm1
0000707649fcf0cb  lea r12, [rax+0xC0]
0000707649fcf0d2  movups xmm1, [r13+r12*1]
0000707649fcf0d8  lea r12, [rax+0xD0]
0000707649fcf0df  movups xmm15, [r13+r12*1]
0000707649fcf0e5  lea r12, [r14+0x110]
0000707649fcf0ec  movq xmm11, qword ptr [r15+0x1E0]
0000707649fcf0f5  movq xmm10, qword ptr [r15+0x1D0]
0000707649fcf0fe  movq r11, xmm11
0000707649fcf103  movq r10, xmm10
0000707649fcf108  mov [r13+r12*1], r11
0000707649fcf10d  lea r12, [r14+0x118]
0000707649fcf114  mov [r13+r12*1], r10
0000707649fcf119  movups xmm11, [r13+rax*1]
0000707649fcf11f  lea r12, [rax+0x10]
0000707649fcf123  movups xmm10, [r13+r12*1]
0000707649fcf129  lea r12, [r14+0x130]
0000707649fcf130  movq xmm9, qword ptr [r15+0x1A0]
0000707649fcf139  movq xmm8, qword ptr [r15+0x190]
0000707649fcf142  movq r11, xmm9
0000707649fcf147  movq r10, xmm8
0000707649fcf14c  mov [r13+r12*1], r11
0000707649fcf151  lea r12, [r14+0x138]
0000707649fcf158  mov [r13+r12*1], r10
0000707649fcf15d  lea r12, [rax+0x140]
0000707649fcf164  movups xmm9, [r13+r12*1]
0000707649fcf16a  lea r12, [rax+0x150]
0000707649fcf171  movups xmm8, [r13+r12*1]
0000707649fcf177  lea r12, [r14+0xC0]
0000707649fcf17e  movups [r13+r12*1], xmm15
0000707649fcf184  lea r12, [r14+0xD0]
0000707649fcf18b  movups [r13+r12*1], xmm1
0000707649fcf191  lea r12, [rax+0x100]
0000707649fcf198  movups xmm1, [r13+r12*1]
0000707649fcf19e  lea r12, [rax+0x110]
0000707649fcf1a5  movups xmm15, [r13+r12*1]
0000707649fcf1ab  lea r12, [r14+0x140]
0000707649fcf1b2  mov r11, [r15+0xE8]
0000707649fcf1b9  mov [r13+r12*1], r11
0000707649fcf1be  lea r12, [rax+0x180]
0000707649fcf1c5  movups xmm7, [r13+r12*1]
0000707649fcf1cb  lea r12, [rax+0x190]
0000707649fcf1d2  movups xmm6, [r13+r12*1]
0000707649fcf1d8  lea r12, [rax+0x1C0]
0000707649fcf1df  movups xmm5, [r13+r12*1]
0000707649fcf1e5  lea r12, [rax+0x1D0]
0000707649fcf1ec  movups xmm4, [r13+r12*1]
0000707649fcf1f2  lea r12, [r14+0x20]
0000707649fcf1f6  movups [r13+r12*1], xmm1
0000707649fcf1fc  lea r12, [r14+0x30]
0000707649fcf200  movups [r13+r12*1], xmm13
0000707649fcf206  lea r12, [rax+0x60]
0000707649fcf20a  movups xmm1, [r13+r12*1]
0000707649fcf210  lea r12, [rax+0x70]
0000707649fcf214  movups xmm13, [r13+r12*1]
0000707649fcf21a  lea r12, [rax+0x20]
0000707649fcf21e  movups xmm3, [r13+r12*1]
0000707649fcf224  lea r12, [rax+0x30]
0000707649fcf228  movups xmm2, [r13+r12*1]
0000707649fcf22e  movaps [r15+0x1F0], xmm2
0000707649fcf236  lea r12, [r14+0x60]
0000707649fcf23a  movups [r13+r12*1], xmm11
0000707649fcf240  lea r12, [r14+0x70]
0000707649fcf244  movups [r13+r12*1], xmm5
0000707649fcf24a  lea r12, [rax+0xE0]
0000707649fcf251  movups xmm11, [r13+r12*1]
0000707649fcf257  lea r12, [rax+0xF0]
0000707649fcf25e  movups xmm5, [r13+r12*1]
0000707649fcf264  lea r12, [r14+0xA0]
0000707649fcf26b  movups [r13+r12*1], xmm13
0000707649fcf271  lea r12, [r14+0xB0]
0000707649fcf278  movups [r13+r12*1], xmm1
0000707649fcf27e  lea r12, [rax+0xA0]
0000707649fcf285  movups xmm1, [r13+r12*1]
0000707649fcf28b  lea r12, [rax+0xB0]
0000707649fcf292  movups xmm13, [r13+r12*1]
0000707649fcf298  lea r12, [rax+0x120]
0000707649fcf29f  vmovaps [rsp+0x10], xmm1
0000707649fcf2a5  movups xmm1, [r13+r12*1]
0000707649fcf2ab  lea r12, [rax+0x130]
0000707649fcf2b2  vmovaps [rsp+0x20], xmm1
0000707649fcf2b8  movups xmm1, [r13+r12*1]
0000707649fcf2be  lea r12, [rax+0x160]
0000707649fcf2c5  vmovaps [rsp+0x30], xmm1
0000707649fcf2cb  movups xmm1, [r13+r12*1]
0000707649fcf2d1  lea r12, [rax+0x170]
0000707649fcf2d8  vmovaps [rsp+0x40], xmm1
0000707649fcf2de  movups xmm1, [r13+r12*1]
0000707649fcf2e4  movaps [r15+0x2B0], xmm1
0000707649fcf2ec  lea r12, [r14+0x80]
0000707649fcf2f3  movups [r13+r12*1], xmm13
0000707649fcf2f9  lea r12, [r14+0x90]
0000707649fcf300  vmovaps xmm13, [rsp+0x10]
0000707649fcf306  movups [r13+r12*1], xmm13
0000707649fcf30c  lea r12, [rax+0x1A0]
0000707649fcf313  movups xmm13, [r13+r12*1]
0000707649fcf319  lea r12, [rax+0x1B0]
0000707649fcf320  vmovaps [rsp+0x10], xmm1
0000707649fcf326  movups xmm1, [r13+r12*1]
0000707649fcf32c  movaps [r15+0x290], xmm13
0000707649fcf334  movaps [r15+0x1E0], xmm1
0000707649fcf33c  lea r12, [rax+0x1E0]
0000707649fcf343  vmovaps [rsp+0x50], xmm1
0000707649fcf349  movups xmm1, [r13+r12*1]
0000707649fcf34f  lea r12, [rax+0x1F0]
0000707649fcf356  vmovaps [rsp+0x60], xmm1
0000707649fcf35c  movups xmm1, [r13+r12*1]
0000707649fcf362  mov qword ptr [r15+0x50], 0x430920
0000707649fcf36a  lea rax, [r14+0x40]
0000707649fcf36e  vmovaps [rsp+0x70], xmm1
0000707649fcf374  vmovaps xmm1, [rsp+0x40]
0000707649fcf37a  movups [r13+rax*1], xmm1
0000707649fcf380  lea rax, [r14+0x50]
0000707649fcf384  movups [r13+rax*1], xmm10
0000707649fcf38a  vmovaps xmm1, [rsp+0x70]
0000707649fcf390  movups [r13+r14*1], xmm1
0000707649fcf396  lea rax, [r14+0x10]
0000707649fcf39a  vmovaps xmm1, [rsp+0x60]
0000707649fcf3a0  movups [r13+rax*1], xmm1
0000707649fcf3a6  mov rax, [r15+0x40]
0000707649fcf3aa  vmovaps [rsp+0x40], xmm3
0000707649fcf3b0  vmovaps xmm1, [rsp+0x40]
0000707649fcf3b6  por xmm3, xmm1
0000707649fcf3ba  vmovaps [rsp+0x40], xmm6
0000707649fcf3c0  vmovaps xmm10, [rsp+0x40]
0000707649fcf3c6  por xmm6, xmm10
0000707649fcf3cb  lea r12, [rax+0x30]
0000707649fcf3cf  mov r11, [r13+r12*1]
0000707649fcf3d4  lea r12, [rax+0x38]
0000707649fcf3d8  mov r10, [r13+r12*1]
0000707649fcf3dd  movq xmm10, r11
0000707649fcf3e2  vmovaps [rsp+0x40], xmm1
0000707649fcf3e8  movq xmm1, r10
0000707649fcf3ed  movq xmm10, xmm10
0000707649fcf3f2  vmovaps [rsp+0x60], xmm10
0000707649fcf3f8  movq xmm10, xmm10
0000707649fcf3fd  movaps [r15+0x130], xmm10
0000707649fcf405  movq xmm1, xmm1
0000707649fcf409  vmovaps [rsp+0x70], xmm1
0000707649fcf40f  movq xmm1, xmm1
0000707649fcf413  movaps [r15+0x280], xmm1
0000707649fcf41b  vmovaps [rsp+0x80], xmm9
0000707649fcf424  vmovaps xmm1, [rsp+0x80]
0000707649fcf42d  por xmm9, xmm1
0000707649fcf432  lea r12, [rax+0x20]
0000707649fcf436  mov r11, [r13+r12*1]
0000707649fcf43b  lea r12, [rax+0x28]
0000707649fcf43f  mov r10, [r13+r12*1]
0000707649fcf444  movq xmm1, r11
0000707649fcf449  movq xmm10, r10
0000707649fcf44e  movq xmm1, xmm1
0000707649fcf452  vmovaps [rsp+0x80], xmm1
0000707649fcf45b  movq xmm1, xmm1
0000707649fcf45f  movaps [r15+0x150], xmm1
0000707649fcf467  movq xmm10, xmm10
0000707649fcf46c  vmovaps [rsp+0x90], xmm10
0000707649fcf475  movq xmm10, xmm10
0000707649fcf47a  movaps [r15+0x140], xmm10
0000707649fcf482  lea r12, [rax+0x10]
0000707649fcf486  mov r11, [r13+r12*1]
0000707649fcf48b  lea r12, [rax+0x18]
0000707649fcf48f  mov r10, [r13+r12*1]
0000707649fcf494  movq xmm1, r11
0000707649fcf499  movq xmm10, r10
0000707649fcf49e  movq xmm1, xmm1
0000707649fcf4a2  vmovaps [rsp+0xA0], xmm1
0000707649fcf4ab  movq xmm1, xmm1
0000707649fcf4af  movaps [r15+0x170], xmm1
0000707649fcf4b7  movq xmm10, xmm10
0000707649fcf4bc  vmovaps [rsp+0xB0], xmm10
0000707649fcf4c5  movq xmm10, xmm10
0000707649fcf4ca  movaps [r15+0x160], xmm10
0000707649fcf4d2  mov r12, [r13+rax*1]
0000707649fcf4d7  vmovq xmm1, r12
0000707649fcf4dc  vpbroadcastq xmm1, xmm1
0000707649fcf4e1  lea r12, [rax+0x08]
0000707649fcf4e5  mov rax, [r13+r12*1]
0000707649fcf4ea  movq xmm10, rax
0000707649fcf4ef  movaps [r15+0x230], xmm10
0000707649fcf4f7  lea rax, [r14+0x50]
0000707649fcf4fb  movups xmm10, [r13+rax*1]
0000707649fcf501  lea rax, [r14+0x60]
0000707649fcf505  vmovaps [rsp+0xC0], xmm1
0000707649fcf50e  movups xmm1, [r13+rax*1]
0000707649fcf514  lea rax, [r14+0x30]
0000707649fcf518  vmovaps [rsp+0xD0], xmm1
0000707649fcf521  movups xmm1, [r13+rax*1]
0000707649fcf527  mov qword ptr [r15+0x60], 0x430920
0000707649fcf52f  mov qword ptr [r15+0x58], 0x40
0000707649fcf537  vmovaps [rsp+0xE0], xmm1
0000707649fcf540  vmovaps [rsp+0xF0], xmm15
0000707649fcf549  vmovaps xmm15, [rsp+0xC0]
0000707649fcf552  vmovaps [rsp+0xC0], xmm14
0000707649fcf55b  vmovaps xmm14, [rsp+0x40]
0000707649fcf561  vmovaps [rsp+0x40], xmm13
0000707649fcf567  movaps xmm1, xmm15
0000707649fcf56b  mulpd xmm1, xmm14
0000707649fcf570  vcmppd xmm13, xmm1, xmm1, 0x03
0000707649fcf575  ptest xmm13, xmm13
0000707649fcf57b  jnz 0x0000707649FD0682
0000707649fcf581  movq xmm14, qword ptr [r15+0x230]
0000707649fcf58a  vmovaps [rsp+0x100], xmm14
0000707649fcf593  vpermilpd xmm14, xmm14, 0x00
0000707649fcf599  vmovaps [rsp+0x110], xmm1
0000707649fcf5a2  vmovaps xmm1, [rsp+0xE0]
0000707649fcf5ab  vmovaps [rsp+0xE0], xmm15
0000707649fcf5b4  movaps xmm13, xmm1
0000707649fcf5b8  mulpd xmm13, xmm14
0000707649fcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
0000707649fcf5c3  ptest xmm15, xmm15
0000707649fcf5c9  jnz 0x0000707649FD07C4
0000707649fcf5cf  vxorps xmm1, xmm1, xmm1
0000707649fcf5d3  vpbroadcastq xmm1, xmm1
0000707649fcf5d8  vmovaps xmm14, [rsp+0xE0]
0000707649fcf5e1  vmovaps [rsp+0xE0], xmm1
0000707649fcf5ea  vmovaps xmm1, [rsp+0xD0]
0000707649fcf5f3  vmovaps [rsp+0xD0], xmm13
0000707649fcf5fc  movaps xmm15, xmm14
0000707649fcf600  mulpd xmm15, xmm1
0000707649fcf605  vcmppd xmm13, xmm15, xmm15, 0x03
0000707649fcf60b  ptest xmm13, xmm13
0000707649fcf611  jnz 0x0000707649FD0907
0000707649fcf617  movaps xmm1, xmm14
0000707649fcf61b  mulpd xmm1, xmm10
0000707649fcf620  vcmppd xmm13, xmm1, xmm1, 0x03
0000707649fcf625  ptest xmm13, xmm13
0000707649fcf62b  jnz 0x0000707649FD0A4A
0000707649fcf631  movaps xmm13, xmm14
0000707649fcf635  mulpd xmm13, xmm2
0000707649fcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
0000707649fcf640  ptest xmm10, xmm10
0000707649fcf646  jnz 0x0000707649FD0B8C
0000707649fcf64c  vmovaps [rsp+0x120], xmm7
0000707649fcf655  vmovaps xmm14, [rsp+0x120]
0000707649fcf65e  por xmm7, xmm14
0000707649fcf663  vmovaps xmm14, [rsp+0xC0]
0000707649fcf66c  vmovaps xmm10, [rsp+0xC0]
0000707649fcf675  por xmm14, xmm10
0000707649fcf67a  vmovaps xmm2, [rsp+0x100]
0000707649fcf683  vpermilpd xmm2, xmm2, 0x00
0000707649fcf689  vmovaps [rsp+0xC0], xmm1
0000707649fcf692  vmovaps [rsp+0x120], xmm15
0000707649fcf69b  movaps xmm1, xmm10
0000707649fcf69f  mulpd xmm1, xmm2
0000707649fcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
0000707649fcf6a8  ptest xmm15, xmm15
0000707649fcf6ae  jnz 0x0000707649FD0CCF
0000707649fcf6b4  xor eax, eax
0000707649fcf6b6  mov r12d, 0x40
0000707649fcf6bc  mov r11d, 0x200
0000707649fcf6c2  cmp r12, r11
0000707649fcf6c5  cmc
0000707649fcf6c6  lahf
0000707649fcf6c7  seto al
0000707649fcf6ca  mov [r15+0x108], eax
0000707649fcf6d1  vmovaps xmm10, [rsp+0x110]
0000707649fcf6da  vmovaps xmm2, [rsp+0xE0]
0000707649fcf6e3  vmovaps [rsp+0xE0], xmm1
0000707649fcf6ec  movaps xmm15, xmm10
0000707649fcf6f0  addpd xmm15, xmm2
0000707649fcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
0000707649fcf6fb  ptest xmm1, xmm1
0000707649fcf700  jnz 0x0000707649FD0E10
0000707649fcf706  vmovaps xmm10, [rsp+0x120]
0000707649fcf70f  vmovaps [rsp+0x110], xmm15
0000707649fcf718  movaps xmm1, xmm10
0000707649fcf71c  addpd xmm1, xmm12
0000707649fcf721  vcmppd xmm15, xmm1, xmm1, 0x03
0000707649fcf726  ptest xmm15, xmm15
0000707649fcf72c  jnz 0x0000707649FD0F53
0000707649fcf732  vmovaps xmm10, [rsp+0xC0]
0000707649fcf73b  vmovaps [rsp+0xC0], xmm1
0000707649fcf744  movaps xmm15, xmm10
0000707649fcf748  addpd xmm15, xmm12
0000707649fcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
0000707649fcf753  ptest xmm1, xmm1
0000707649fcf758  jnz 0x0000707649FD1095
0000707649fcf75e  vmovaps xmm1, [rsp+0x30]
0000707649fcf764  vmovaps xmm12, [rsp+0x30]
0000707649fcf76a  por xmm1, xmm12
0000707649fcf76f  vmovaps xmm12, [rsp+0x20]
0000707649fcf775  vmovaps xmm10, [rsp+0x20]
0000707649fcf77b  por xmm12, xmm10
0000707649fcf780  vmovaps [rsp+0x20], xmm5
0000707649fcf786  vmovaps xmm10, [rsp+0x20]
0000707649fcf78c  por xmm5, xmm10
0000707649fcf791  vmovaps [rsp+0x20], xmm11
0000707649fcf797  vmovaps xmm10, [rsp+0x20]
0000707649fcf79d  por xmm11, xmm10
0000707649fcf7a2  vmovaps [rsp+0x20], xmm4
0000707649fcf7a8  vmovaps xmm10, [rsp+0x20]
0000707649fcf7ae  por xmm4, xmm10
0000707649fcf7b3  vmovaps [rsp+0x20], xmm8
0000707649fcf7b9  vmovaps xmm10, [rsp+0x20]
0000707649fcf7bf  por xmm8, xmm10
0000707649fcf7c4  vmovaps xmm10, [rsp+0xF0]
0000707649fcf7cd  vmovaps [rsp+0x20], xmm1
0000707649fcf7d3  vmovaps xmm1, [rsp+0xF0]
0000707649fcf7dc  por xmm10, xmm1
0000707649fcf7e1  lea rax, [r14+0xA0]
0000707649fcf7e8  movups xmm1, [r13+rax*1]
0000707649fcf7ee  lea rax, [r14+0xB0]
0000707649fcf7f5  vmovaps [rsp+0x30], xmm1
0000707649fcf7fb  movups xmm1, [r13+rax*1]
0000707649fcf801  vmovaps [rsp+0xF0], xmm1
0000707649fcf80a  vmovaps [rsp+0x120], xmm15
0000707649fcf813  movaps xmm1, xmm13
0000707649fcf817  addpd xmm1, xmm2
0000707649fcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
0000707649fcf820  ptest xmm15, xmm15
0000707649fcf826  jnz 0x0000707649FD11ED
0000707649fcf82c  lea rax, [r14+0xF0]
0000707649fcf833  movups xmm15, [r13+rax*1]
0000707649fcf839  vmovaps xmm2, [rsp+0xC0]
0000707649fcf842  vmovaps [rsp+0xC0], xmm1
0000707649fcf84b  vmovaps xmm1, [rsp+0xE0]
0000707649fcf854  vmovaps [rsp+0xE0], xmm15
0000707649fcf85d  movaps xmm13, xmm2
0000707649fcf861  addpd xmm13, xmm1
0000707649fcf866  vcmppd xmm15, xmm13, xmm13, 0x03
0000707649fcf86c  ptest xmm15, xmm15
0000707649fcf872  jnz 0x0000707649FD1338
0000707649fcf878  vmovaps xmm15, [rsp+0x120]
0000707649fcf881  vmovaps xmm2, [rsp+0xD0]
0000707649fcf88a  vmovaps [rsp+0xD0], xmm14
0000707649fcf893  movaps xmm1, xmm15
0000707649fcf897  addpd xmm1, xmm2
0000707649fcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
0000707649fcf8a0  ptest xmm14, xmm14
0000707649fcf8a6  jnz 0x0000707649FD147A
0000707649fcf8ac  vmovaps xmm15, [rsp+0x100]
0000707649fcf8b5  vpermilpd xmm15, xmm15, 0x00
0000707649fcf8bb  vmovaps xmm2, [rsp+0xF0]
0000707649fcf8c4  vmovaps [rsp+0xF0], xmm1
0000707649fcf8cd  movaps xmm14, xmm2
0000707649fcf8d1  mulpd xmm14, xmm15
0000707649fcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
0000707649fcf8dc  ptest xmm1, xmm1
0000707649fcf8e1  jnz 0x0000707649FD15BB
0000707649fcf8e7  vmovaps xmm1, [rsp+0xA0]
0000707649fcf8f0  vpermilpd xmm1, xmm1, 0x00
0000707649fcf8f6  vmovaps xmm2, [rsp+0xE0]
0000707649fcf8ff  vmovaps [rsp+0xE0], xmm14
0000707649fcf908  movaps xmm15, xmm2
0000707649fcf90c  mulpd xmm15, xmm1
0000707649fcf911  vcmppd xmm14, xmm15, xmm15, 0x03
0000707649fcf917  ptest xmm14, xmm14
0000707649fcf91d  jnz 0x0000707649FD16FE
0000707649fcf923  lea rax, [r14+0xE0]
0000707649fcf92a  movups xmm1, [r13+rax*1]
0000707649fcf930  vmovaps xmm14, [rsp+0x100]
0000707649fcf939  vpermilpd xmm14, xmm14, 0x00
0000707649fcf93f  vmovaps [rsp+0x100], xmm1
0000707649fcf948  vmovaps xmm1, [rsp+0x30]
0000707649fcf94e  vmovaps [rsp+0x30], xmm15
0000707649fcf954  movaps xmm2, xmm1
0000707649fcf957  mulpd xmm2, xmm14
0000707649fcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
0000707649fcf961  ptest xmm15, xmm15
0000707649fcf967  jnz 0x0000707649FD184A
0000707649fcf96d  vmovaps [rsp+0x120], xmm10
0000707649fcf976  vmovaps xmm1, [rsp+0x120]
0000707649fcf97f  por xmm10, xmm1
0000707649fcf984  movaps [r15+0x300], xmm10
0000707649fcf98c  vmovaps [rsp+0x120], xmm8
0000707649fcf995  vmovaps xmm1, [rsp+0x120]
0000707649fcf99e  por xmm8, xmm1
0000707649fcf9a3  movaps [r15+0x190], xmm8
0000707649fcf9ab  vmovaps xmm1, [rsp+0xA0]
0000707649fcf9b4  vpermilpd xmm1, xmm1, 0x00
0000707649fcf9ba  vmovaps xmm14, [rsp+0x100]
0000707649fcf9c3  vmovaps [rsp+0x100], xmm13
0000707649fcf9cc  movaps xmm15, xmm14
0000707649fcf9d0  mulpd xmm15, xmm1
0000707649fcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
0000707649fcf9db  ptest xmm13, xmm13
0000707649fcf9e1  jnz 0x0000707649FD198B
0000707649fcf9e7  lea rax, [r14+0x90]
0000707649fcf9ee  movups xmm1, [r13+rax*1]
0000707649fcf9f4  vmovaps [rsp+0x120], xmm4
0000707649fcf9fd  vmovaps xmm14, [rsp+0x120]
0000707649fcfa06  por xmm4, xmm14
0000707649fcfa0b  movaps [r15+0x1C0], xmm4
0000707649fcfa13  vmovaps [rsp+0x120], xmm11
0000707649fcfa1c  vmovaps xmm14, [rsp+0x120]
0000707649fcfa25  por xmm11, xmm14
0000707649fcfa2a  movaps [r15+0x200], xmm11
0000707649fcfa32  vmovaps [rsp+0x120], xmm5
0000707649fcfa3b  vmovaps xmm14, [rsp+0x120]
0000707649fcfa44  por xmm5, xmm14
0000707649fcfa49  movaps [r15+0x2D0], xmm5
0000707649fcfa51  vmovaps [rsp+0x120], xmm12
0000707649fcfa5a  vmovaps xmm14, [rsp+0x120]
0000707649fcfa63  por xmm12, xmm14
0000707649fcfa68  movaps [r15+0x2E0], xmm12
0000707649fcfa70  vmovaps xmm13, [rsp+0x110]
0000707649fcfa79  vmovaps [rsp+0x110], xmm1
0000707649fcfa82  vmovaps xmm1, [rsp+0xE0]
0000707649fcfa8b  vmovaps [rsp+0xE0], xmm15
0000707649fcfa94  movaps xmm14, xmm13
0000707649fcfa98  addpd xmm14, xmm1
0000707649fcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
0000707649fcfaa3  ptest xmm15, xmm15
0000707649fcfaa9  jnz 0x0000707649FD1AD8
0000707649fcfaaf  vmovaps xmm1, [rsp+0xA0]
0000707649fcfab8  vpermilpd xmm1, xmm1, 0x00
0000707649fcfabe  vmovaps xmm13, [rsp+0x110]
0000707649fcfac7  vmovaps [rsp+0x110], xmm14
0000707649fcfad0  movaps xmm15, xmm13
0000707649fcfad4  mulpd xmm15, xmm1
0000707649fcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
0000707649fcfadf  ptest xmm14, xmm14
0000707649fcfae5  jnz 0x0000707649FD1C1B
0000707649fcfaeb  lea rax, [r14+0x80]
0000707649fcfaf2  movups xmm1, [r13+rax*1]
0000707649fcfaf8  vmovaps xmm13, [rsp+0xC0]
0000707649fcfb01  vmovaps [rsp+0xC0], xmm1
0000707649fcfb0a  movaps xmm14, xmm13
0000707649fcfb0e  addpd xmm14, xmm2
0000707649fcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
0000707649fcfb19  ptest xmm1, xmm1
0000707649fcfb1e  jnz 0x0000707649FD1D68
0000707649fcfb24  vmovaps xmm13, [rsp+0x100]
0000707649fcfb2d  vmovaps xmm2, [rsp+0x30]
0000707649fcfb33  vmovaps [rsp+0x30], xmm15
0000707649fcfb39  movaps xmm1, xmm13
0000707649fcfb3d  addpd xmm1, xmm2
0000707649fcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
0000707649fcfb46  ptest xmm15, xmm15
0000707649fcfb4c  jnz 0x0000707649FD1EAB
0000707649fcfb52  vmovaps xmm15, [rsp+0x20]
0000707649fcfb58  vmovaps xmm13, [rsp+0x20]
0000707649fcfb5e  por xmm15, xmm13
0000707649fcfb63  movaps [r15+0x2F0], xmm15
0000707649fcfb6b  vmovaps xmm13, [rsp+0xA0]
0000707649fcfb74  vpermilpd xmm13, xmm13, 0x00
0000707649fcfb7a  vmovaps [rsp+0x20], xmm1
0000707649fcfb80  vmovaps xmm1, [rsp+0xC0]
0000707649fcfb89  vmovaps [rsp+0xA0], xmm15
0000707649fcfb92  movaps xmm2, xmm1
0000707649fcfb95  mulpd xmm2, xmm13
0000707649fcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
0000707649fcfb9f  ptest xmm15, xmm15
0000707649fcfba5  jnz 0x0000707649FD1FEC
0000707649fcfbab  lea rax, [r14+0xD0]
0000707649fcfbb2  movups xmm1, [r13+rax*1]
0000707649fcfbb8  vmovaps xmm13, [rsp+0xF0]
0000707649fcfbc1  vmovaps [rsp+0xC0], xmm1
0000707649fcfbca  vmovaps xmm1, [rsp+0xE0]
0000707649fcfbd3  vmovaps [rsp+0xE0], xmm14
0000707649fcfbdc  movaps xmm15, xmm13
0000707649fcfbe0  addpd xmm15, xmm1
0000707649fcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
0000707649fcfbeb  ptest xmm14, xmm14
0000707649fcfbf1  jnz 0x0000707649FD2137
0000707649fcfbf7  vmovaps xmm1, [rsp+0xB0]
0000707649fcfc00  vpermilpd xmm1, xmm1, 0x00
0000707649fcfc06  movaps xmm14, xmm11
0000707649fcfc0a  mulpd xmm14, xmm1
0000707649fcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
0000707649fcfc15  ptest xmm13, xmm13
0000707649fcfc1b  jnz 0x0000707649FD227A
0000707649fcfc21  movaps [r15+0x260], xmm14
0000707649fcfc29  vxorps xmm1, xmm1, xmm1
0000707649fcfc2d  vpbroadcastq xmm1, xmm1
0000707649fcfc32  movaps [r15+0x1B0], xmm1
0000707649fcfc3a  vmovaps xmm1, [rsp+0xB0]
0000707649fcfc43  vpermilpd xmm1, xmm1, 0x00
0000707649fcfc49  vmovaps xmm11, [rsp+0xC0]
0000707649fcfc52  vmovaps [rsp+0xC0], xmm15
0000707649fcfc5b  movaps xmm13, xmm11
0000707649fcfc5f  mulpd xmm13, xmm1
0000707649fcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
0000707649fcfc6a  ptest xmm15, xmm15
0000707649fcfc70  jnz 0x0000707649FD23BD
0000707649fcfc76  lea rax, [r14+0xC0]
0000707649fcfc7d  movups xmm1, [r13+rax*1]
0000707649fcfc83  vmovaps xmm11, [rsp+0x110]
0000707649fcfc8c  vmovaps [rsp+0xF0], xmm1
0000707649fcfc95  vmovaps xmm1, [rsp+0x30]
0000707649fcfc9b  vmovaps [rsp+0x30], xmm14
0000707649fcfca1  movaps xmm15, xmm11
0000707649fcfca5  addpd xmm15, xmm1
0000707649fcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
0000707649fcfcb0  ptest xmm14, xmm14
0000707649fcfcb6  jnz 0x0000707649FD250A
0000707649fcfcbc  vmovaps [rsp+0x100], xmm9
0000707649fcfcc5  vmovaps xmm1, [rsp+0x100]
0000707649fcfcce  por xmm9, xmm1
0000707649fcfcd3  movaps [r15+0x270], xmm9
0000707649fcfcdb  vmovaps [rsp+0x100], xmm6
0000707649fcfce4  vmovaps xmm1, [rsp+0x100]
0000707649fcfced  por xmm6, xmm1
0000707649fcfcf1  movaps [r15+0x1A0], xmm6
0000707649fcfcf9  vmovaps xmm14, [rsp+0xB0]
0000707649fcfd02  vpermilpd xmm14, xmm14, 0x00
0000707649fcfd08  vmovaps xmm6, [rsp+0xF0]
0000707649fcfd11  vmovaps [rsp+0xF0], xmm1
0000707649fcfd1a  movaps xmm11, xmm6
0000707649fcfd1e  mulpd xmm11, xmm14
0000707649fcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
0000707649fcfd29  ptest xmm1, xmm1
0000707649fcfd2e  jnz 0x0000707649FD264D
0000707649fcfd34  lea rax, [r14+0x20]
0000707649fcfd38  movups xmm1, [r13+rax*1]
0000707649fcfd3e  movaps [r15+0x110], xmm1
0000707649fcfd46  vmovaps xmm6, [rsp+0xE0]
0000707649fcfd4f  vmovaps [rsp+0xE0], xmm1
0000707649fcfd58  movaps xmm14, xmm6
0000707649fcfd5c  addpd xmm14, xmm2
0000707649fcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
0000707649fcfd67  ptest xmm1, xmm1
0000707649fcfd6c  jnz 0x0000707649FD279A
0000707649fcfd72  vmovaps xmm1, [rsp+0xB0]
0000707649fcfd7b  vpermilpd xmm1, xmm1, 0x00
0000707649fcfd81  movaps xmm6, xmm5
0000707649fcfd84  mulpd xmm6, xmm1
0000707649fcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
0000707649fcfd8d  ptest xmm2, xmm2
0000707649fcfd92  jnz 0x0000707649FD28DC
0000707649fcfd98  vmovaps xmm5, [rsp+0x20]
0000707649fcfd9e  movaps xmm1, xmm5
0000707649fcfda1  addpd xmm1, xmm13
0000707649fcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
0000707649fcfdab  ptest xmm2, xmm2
0000707649fcfdb0  jnz 0x0000707649FD2A1C
0000707649fcfdb6  vmovaps xmm13, [rsp+0x80]
0000707649fcfdbf  vpermilpd xmm13, xmm13, 0x00
0000707649fcfdc5  vmovaps xmm2, [rsp+0xE0]
0000707649fcfdce  vmovaps [rsp+0x20], xmm1
0000707649fcfdd4  movaps xmm5, xmm2
0000707649fcfdd7  mulpd xmm5, xmm13
0000707649fcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
0000707649fcfde1  ptest xmm1, xmm1
0000707649fcfde6  jnz 0x0000707649FD2B5D
0000707649fcfdec  vmovaps xmm1, [rsp+0x80]
0000707649fcfdf5  vpermilpd xmm1, xmm1, 0x00
0000707649fcfdfb  movaps xmm13, xmm10
0000707649fcfdff  mulpd xmm13, xmm1
0000707649fcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
0000707649fcfe0a  ptest xmm2, xmm2
0000707649fcfe0f  jnz 0x0000707649FD2C9E
0000707649fcfe15  vmovaps xmm10, [rsp+0x30]
0000707649fcfe1b  movaps xmm1, xmm15
0000707649fcfe1f  addpd xmm1, xmm10
0000707649fcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
0000707649fcfe29  ptest xmm2, xmm2
0000707649fcfe2e  jnz 0x0000707649FD2DE1
0000707649fcfe34  vmovaps xmm10, [rsp+0xC0]
0000707649fcfe3d  movaps xmm15, xmm10
0000707649fcfe41  addpd xmm15, xmm11
0000707649fcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
0000707649fcfe4c  ptest xmm2, xmm2
0000707649fcfe51  jnz 0x0000707649FD2F23
0000707649fcfe57  vmovaps xmm11, [rsp+0x80]
0000707649fcfe60  vpermilpd xmm11, xmm11, 0x00
0000707649fcfe66  movaps xmm10, xmm12
0000707649fcfe6a  mulpd xmm10, xmm11
0000707649fcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
0000707649fcfe75  ptest xmm2, xmm2
0000707649fcfe7a  jnz 0x0000707649FD3067
0000707649fcfe80  vmovaps xmm12, [rsp+0x80]
0000707649fcfe89  vpermilpd xmm12, xmm12, 0x00
0000707649fcfe8f  vmovaps xmm2, [rsp+0xA0]
0000707649fcfe98  vmovaps [rsp+0x30], xmm1
0000707649fcfe9e  movaps xmm11, xmm2
0000707649fcfea2  mulpd xmm11, xmm12
0000707649fcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
0000707649fcfead  ptest xmm1, xmm1
0000707649fcfeb2  jnz 0x0000707649FD31AB
0000707649fcfeb8  movaps xmm1, xmm14
0000707649fcfebc  addpd xmm1, xmm6
0000707649fcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
0000707649fcfec5  ptest xmm12, xmm12
0000707649fcfecb  jnz 0x0000707649FD32EE
0000707649fcfed1  vmovaps xmm12, [rsp+0x20]
0000707649fcfed7  movaps xmm14, xmm12
0000707649fcfedb  addpd xmm14, xmm5
0000707649fcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
0000707649fcfee6  ptest xmm6, xmm6
0000707649fcfeeb  jnz 0x0000707649FD342F
0000707649fcfef1  vmovaps xmm12, [rsp+0x90]
0000707649fcfefa  vpermilpd xmm12, xmm12, 0x00
0000707649fcff00  movaps xmm6, xmm9
0000707649fcff04  mulpd xmm6, xmm12
0000707649fcff09  vcmppd xmm5, xmm6, xmm6, 0x03
0000707649fcff0e  ptest xmm5, xmm5
0000707649fcff13  jnz 0x0000707649FD3572
0000707649fcff19  movaps xmm12, xmm15
0000707649fcff1d  addpd xmm12, xmm13
0000707649fcff22  vcmppd xmm9, xmm12, xmm12, 0x03
0000707649fcff28  ptest xmm9, xmm9
0000707649fcff2e  jnz 0x0000707649FD36B4
0000707649fcff34  vmovaps xmm13, [rsp+0x30]
0000707649fcff3a  movaps xmm15, xmm13
0000707649fcff3e  addpd xmm15, xmm10
0000707649fcff43  vcmppd xmm9, xmm15, xmm15, 0x03
0000707649fcff49  ptest xmm9, xmm9
0000707649fcff4f  jnz 0x0000707649FD37F8
0000707649fcff55  vmovaps xmm13, [rsp+0xD0]
0000707649fcff5e  vmovaps xmm10, [rsp+0xD0]
0000707649fcff67  por xmm13, xmm10
0000707649fcff6c  movaps [r15+0x250], xmm13
0000707649fcff74  vmovaps [rsp+0x20], xmm7
0000707649fcff7a  vmovaps xmm13, [rsp+0x20]
0000707649fcff80  por xmm7, xmm13
0000707649fcff85  movaps [r15+0x2A0], xmm7
0000707649fcff8d  vmovaps [rsp+0x20], xmm3
0000707649fcff93  vmovaps xmm13, [rsp+0x20]
0000707649fcff99  por xmm3, xmm13
0000707649fcff9e  movaps [r15+0x1D0], xmm3
0000707649fcffa6  lea rax, [r14+0x40]
0000707649fcffaa  movups xmm13, [r13+rax*1]
0000707649fcffb0  movaps [r15+0x2C0], xmm13
0000707649fcffb8  vmovaps xmm10, [rsp+0x90]
0000707649fcffc1  vpermilpd xmm10, xmm10, 0x00
0000707649fcffc7  movaps xmm9, xmm8
0000707649fcffcb  mulpd xmm9, xmm10
0000707649fcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
0000707649fcffd6  ptest xmm5, xmm5
0000707649fcffdb  jnz 0x0000707649FD3946
0000707649fcffe1  movaps xmm10, xmm1
0000707649fcffe5  addpd xmm10, xmm11
0000707649fcffea  vcmppd xmm8, xmm10, xmm10, 0x03
0000707649fcfff0  ptest xmm8, xmm8
0000707649fcfff6  jnz 0x0000707649FD3A8A
0000707649fcfffc  movaps xmm1, xmm14
0000707649fd0000  addpd xmm1, xmm6
0000707649fd0004  vcmppd xmm11, xmm1, xmm1, 0x03
0000707649fd0009  ptest xmm11, xmm11
0000707649fd000f  jnz 0x0000707649FD3BCD
0000707649fd0015  vmovaps xmm14, [rsp+0x90]
0000707649fd001e  vpermilpd xmm14, xmm14, 0x00
0000707649fd0024  movaps xmm11, xmm13
0000707649fd0028  mulpd xmm11, xmm14
0000707649fd002d  vcmppd xmm8, xmm11, xmm11, 0x03
0000707649fd0033  ptest xmm8, xmm8
0000707649fd0039  jnz 0x0000707649FD3D0E
0000707649fd003f  vmovaps xmm14, [rsp+0x90]
0000707649fd0048  vpermilpd xmm14, xmm14, 0x00
0000707649fd004e  vmovaps xmm8, [rsp+0x10]
0000707649fd0054  movaps xmm13, xmm8
0000707649fd0058  mulpd xmm13, xmm14
0000707649fd005d  vcmppd xmm6, xmm13, xmm13, 0x03
0000707649fd0063  ptest xmm6, xmm6
0000707649fd0068  jnz 0x0000707649FD3E52
0000707649fd006e  vmovaps xmm14, [rsp+0x60]
0000707649fd0074  vpermilpd xmm14, xmm14, 0x00
0000707649fd007a  movaps xmm8, xmm7
0000707649fd007e  mulpd xmm8, xmm14
0000707649fd0083  vcmppd xmm6, xmm8, xmm8, 0x03
0000707649fd0089  ptest xmm6, xmm6
0000707649fd008e  jnz 0x0000707649FD3F96
0000707649fd0094  movaps xmm14, xmm12
0000707649fd0098  addpd xmm14, xmm9
0000707649fd009d  vcmppd xmm7, xmm14, xmm14, 0x03
0000707649fd00a3  ptest xmm7, xmm7
0000707649fd00a8  jnz 0x0000707649FD40D9
0000707649fd00ae  vmovaps xmm12, [rsp+0x60]
0000707649fd00b4  vpermilpd xmm12, xmm12, 0x00
0000707649fd00ba  vmovaps xmm7, [rsp+0xF0]
0000707649fd00c3  movaps xmm9, xmm7
0000707649fd00c7  mulpd xmm9, xmm12
0000707649fd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
0000707649fd00d2  ptest xmm6, xmm6
0000707649fd00d7  jnz 0x0000707649FD421D
0000707649fd00dd  movaps xmm12, xmm15
0000707649fd00e1  addpd xmm12, xmm11
0000707649fd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
0000707649fd00ec  ptest xmm7, xmm7
0000707649fd00f1  jnz 0x0000707649FD4360
0000707649fd00f7  vmovaps xmm15, [rsp+0x60]
0000707649fd00fd  vpermilpd xmm15, xmm15, 0x00
0000707649fd0103  vmovaps xmm7, [rsp+0x40]
0000707649fd0109  movaps xmm11, xmm7
0000707649fd010d  mulpd xmm11, xmm15
0000707649fd0112  vcmppd xmm6, xmm11, xmm11, 0x03
0000707649fd0118  ptest xmm6, xmm6
0000707649fd011d  jnz 0x0000707649FD44A4
0000707649fd0123  movaps xmm15, xmm10
0000707649fd0127  addpd xmm15, xmm13
0000707649fd012c  vcmppd xmm7, xmm15, xmm15, 0x03
0000707649fd0132  ptest xmm7, xmm7
0000707649fd0137  jnz 0x0000707649FD45E7
0000707649fd013d  vmovaps xmm13, [rsp+0x60]
0000707649fd0143  vpermilpd xmm13, xmm13, 0x00
0000707649fd0149  vmovaps xmm7, [rsp+0x50]
0000707649fd014f  movaps xmm10, xmm7
0000707649fd0153  mulpd xmm10, xmm13
0000707649fd0158  vcmppd xmm6, xmm10, xmm10, 0x03
0000707649fd015e  ptest xmm6, xmm6
0000707649fd0163  jnz 0x0000707649FD472B
0000707649fd0169  movaps xmm13, xmm1
0000707649fd016d  addpd xmm13, xmm8
0000707649fd0172  vcmppd xmm7, xmm13, xmm13, 0x03
0000707649fd0178  ptest xmm7, xmm7
0000707649fd017d  jnz 0x0000707649FD486E
0000707649fd0183  lea rax, [r14+0x70]
0000707649fd0187  movups xmm1, [r13+rax*1]
0000707649fd018d  movaps [r15+0x240], xmm1
0000707649fd0195  movaps xmm8, xmm14
0000707649fd0199  addpd xmm8, xmm9
0000707649fd019e  vcmppd xmm7, xmm8, xmm8, 0x03
0000707649fd01a4  ptest xmm7, xmm7
0000707649fd01a9  jnz 0x0000707649FD49BB
0000707649fd01af  movaps [r15+0x170], xmm8
0000707649fd01b7  vmovaps xmm14, [rsp+0x70]
0000707649fd01bd  vpermilpd xmm14, xmm14, 0x00
0000707649fd01c3  movaps xmm9, xmm1
0000707649fd01c7  mulpd xmm9, xmm14
0000707649fd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
0000707649fd01d2  ptest xmm7, xmm7
0000707649fd01d7  jnz 0x0000707649FD4AFF
0000707649fd01dd  vmovaps xmm1, [rsp+0x70]
0000707649fd01e3  vpermilpd xmm1, xmm1, 0x00
0000707649fd01e9  movaps xmm14, xmm4
0000707649fd01ed  mulpd xmm14, xmm1
0000707649fd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
0000707649fd01f8  ptest xmm7, xmm7
0000707649fd01fd  jnz 0x0000707649FD4C42
0000707649fd0203  movaps [r15+0x180], xmm14
0000707649fd020b  movaps xmm1, xmm12
0000707649fd020f  addpd xmm1, xmm11
0000707649fd0214  vcmppd xmm7, xmm1, xmm1, 0x03
0000707649fd0219  ptest xmm7, xmm7
0000707649fd021e  jnz 0x0000707649FD4D84
0000707649fd0224  movaps [r15+0x210], xmm1
0000707649fd022c  movups xmm12, [r13+r14*1]
0000707649fd0232  lea rax, [r14+0x10]
0000707649fd0236  movups xmm11, [r13+rax*1]
0000707649fd023c  movaps [r15+0x230], xmm11
0000707649fd0244  movaps xmm7, xmm15
0000707649fd0248  addpd xmm7, xmm10
0000707649fd024d  vcmppd xmm6, xmm7, xmm7, 0x03
0000707649fd0252  ptest xmm6, xmm6
0000707649fd0257  jnz 0x0000707649FD4EDA
0000707649fd025d  movaps [r15+0x130], xmm7
0000707649fd0265  vmovaps xmm15, [rsp+0x70]
0000707649fd026b  vpermilpd xmm15, xmm15, 0x00
0000707649fd0271  movaps xmm10, xmm11
0000707649fd0275  mulpd xmm10, xmm15
0000707649fd027a  vcmppd xmm6, xmm10, xmm10, 0x03
0000707649fd0280  ptest xmm6, xmm6
0000707649fd0285  jnz 0x0000707649FD501C
0000707649fd028b  movaps [r15+0x220], xmm10
0000707649fd0293  vmovaps xmm15, [rsp+0x70]
0000707649fd0299  vpermilpd xmm15, xmm15, 0x00
0000707649fd029f  movaps xmm11, xmm12
0000707649fd02a3  mulpd xmm11, xmm15
0000707649fd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
0000707649fd02ae  ptest xmm6, xmm6
0000707649fd02b3  jnz 0x0000707649FD5160
0000707649fd02b9  movaps xmm15, xmm13
0000707649fd02bd  addpd xmm15, xmm9
0000707649fd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
0000707649fd02c8  ptest xmm12, xmm12
0000707649fd02ce  jnz 0x0000707649FD52A4
0000707649fd02d4  movaps [r15+0x140], xmm15
0000707649fd02dc  movaps xmm13, xmm8
0000707649fd02e0  addpd xmm13, xmm14
0000707649fd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
0000707649fd02eb  ptest xmm12, xmm12
0000707649fd02f1  jnz 0x0000707649FD53E8
0000707649fd02f7  movaps [r15+0x150], xmm13
0000707649fd02ff  movaps xmm14, xmm1
0000707649fd0303  addpd xmm14, xmm10
0000707649fd0308  vcmppd xmm12, xmm14, xmm14, 0x03
0000707649fd030e  ptest xmm12, xmm12
0000707649fd0314  jnz 0x0000707649FD552C
0000707649fd031a  movaps [r15+0x160], xmm14
0000707649fd0322  movaps xmm1, xmm7
0000707649fd0325  addpd xmm1, xmm11
0000707649fd032a  vcmppd xmm12, xmm1, xmm1, 0x03
0000707649fd032f  ptest xmm12, xmm12
0000707649fd0335  jnz 0x0000707649FD566F
0000707649fd033b  movaps [r15+0x120], xmm1
0000707649fd0343  mov eax, 0x430920
0000707649fd0348  movups [r13+rax*1], xmm15
0000707649fd034e  mov eax, 0x430930
0000707649fd0353  movups [r13+rax*1], xmm13
0000707649fd0359  mov eax, 0x430940
0000707649fd035e  movups [r13+rax*1], xmm14
0000707649fd0364  mov eax, 0x430950
0000707649fd0369  movups [r13+rax*1], xmm1
0000707649fd036f  mov eax, [r15+0x108]
0000707649fd0376  sahf
0000707649fd0377  jnz 0x0000707649FD03A9
0000707649fd0379  cmp dword ptr [r15+0x318], 0x00
0000707649fd0381  jz 0x0000707649FDB900
0000707649fd0387  nop [rax+rax*1], ax
0000707649fd0390  nop [rax+rax*1], eax
0000707649fd0398  mov eax, 0x410444
0000707649fd039d  mov [r15+0x100], rax
0000707649fd03a4  jmp 0x0000707649DFE110
0000707649fd03a9  cmp dword ptr [r15+0x318], 0x00
0000707649fd03b1  jz 0x0000707649FD57E0
0000707649fd03b7  nop [rax+rax*1], ax
0000707649fd03c0  nop [rax+rax*1], eax
0000707649fd03c8  mov eax, 0x410278
0000707649fd03cd  mov [r15+0x100], rax
0000707649fd03d4  jmp 0x0000707649DFE110
0000707649fd03d9  int3
0000707649fd03da  call 0x0000707649EB52F0
0000707649fd03df  jmp 0x0000707649FCF016
0000707649fd03e4  call 0x0000707649EC4620
0000707649fd03e9  jmp 0x0000707649FCF023
0000707649fd03ee  call 0x0000707649EC33A0
0000707649fd03f3  jmp 0x0000707649FCF035
0000707649fd03f8  call 0x0000707649EC2120
0000707649fd03fd  jmp 0x0000707649FCF03F
0000707649fd0402  call 0x0000707649EC0860
0000707649fd0407  jmp 0x0000707649FCF067
0000707649fd040c  call 0x0000707649EBF5F0
0000707649fd0411  jmp 0x0000707649FCF073
0000707649fd0416  call 0x0000707649EC0860
0000707649fd041b  jmp 0x0000707649FCF0A5
0000707649fd0420  call 0x0000707649EBF5F0
0000707649fd0425  jmp 0x0000707649FCF0B1
0000707649fd042a  call 0x0000707649EC4740
0000707649fd042f  jmp 0x0000707649FCF0BE
0000707649fd0434  call 0x0000707649EB5400
0000707649fd0439  jmp 0x0000707649FCF0CB
0000707649fd043e  call 0x0000707649EB52F0
0000707649fd0443  jmp 0x0000707649FCF0D8
0000707649fd0448  call 0x0000707649EC4620
0000707649fd044d  jmp 0x0000707649FCF0E5
0000707649fd0452  call 0x0000707649EC0860
0000707649fd0457  jmp 0x0000707649FCF10D
0000707649fd045c  call 0x0000707649EBF5F0
0000707649fd0461  jmp 0x0000707649FCF119
0000707649fd0466  call 0x0000707649E09D70
0000707649fd046b  jmp 0x0000707649FCF11F
0000707649fd0470  call 0x0000707649EBE9C0
0000707649fd0475  jmp 0x0000707649FCF129
0000707649fd047a  call 0x0000707649EC0860
0000707649fd047f  jmp 0x0000707649FCF151
0000707649fd0484  call 0x0000707649EBF5F0
0000707649fd0489  jmp 0x0000707649FCF15D
0000707649fd048e  call 0x0000707649EBD750
0000707649fd0493  jmp 0x0000707649FCF16A
0000707649fd0498  call 0x0000707649EBC4E0
0000707649fd049d  jmp 0x0000707649FCF177
0000707649fd04a2  call 0x0000707649EC4740
0000707649fd04a7  jmp 0x0000707649FCF184
0000707649fd04ac  call 0x0000707649EB5400
0000707649fd04b1  jmp 0x0000707649FCF191
0000707649fd04b6  call 0x0000707649EB52F0
0000707649fd04bb  jmp 0x0000707649FCF19E
0000707649fd04c0  call 0x0000707649EC4620
0000707649fd04c5  jmp 0x0000707649FCF1AB
0000707649fd04ca  call 0x0000707649EC0860
0000707649fd04cf  jmp 0x0000707649FCF1BE
0000707649fd04d4  call 0x0000707649EBB270
0000707649fd04d9  jmp 0x0000707649FCF1CB
0000707649fd04de  call 0x0000707649EBA000
0000707649fd04e3  jmp 0x0000707649FCF1D8
0000707649fd04e8  call 0x0000707649EB8D90
0000707649fd04ed  jmp 0x0000707649FCF1E5
0000707649fd04f2  call 0x0000707649EB8A20
0000707649fd04f7  jmp 0x0000707649FCF1F2
0000707649fd04fc  call 0x0000707649EB5400
0000707649fd0501  jmp 0x0000707649FCF1FC
0000707649fd0506  call 0x0000707649EC2240
0000707649fd050b  jmp 0x0000707649FCF206
0000707649fd0510  call 0x0000707649EB52F0
0000707649fd0515  jmp 0x0000707649FCF210
0000707649fd051a  call 0x0000707649EC2120
0000707649fd051f  jmp 0x0000707649FCF21A
0000707649fd0524  call 0x0000707649EB77B0
0000707649fd0529  jmp 0x0000707649FCF224
0000707649fd052e  call 0x0000707649EB6550
0000707649fd0533  jmp 0x0000707649FCF22E
0000707649fd0538  call 0x0000707649EBFD50
0000707649fd053d  jmp 0x0000707649FCF240
0000707649fd0542  call 0x0000707649EB8EA0
0000707649fd0547  jmp 0x0000707649FCF24A
0000707649fd054c  call 0x0000707649EBFC30
0000707649fd0551  jmp 0x0000707649FCF257
0000707649fd0556  call 0x0000707649EB8D90
0000707649fd055b  jmp 0x0000707649FCF264
0000707649fd0560  call 0x0000707649EC2240
0000707649fd0565  jmp 0x0000707649FCF271
0000707649fd056a  call 0x0000707649EB5400
0000707649fd056f  jmp 0x0000707649FCF27E
0000707649fd0574  call 0x0000707649EB52F0
0000707649fd0579  jmp 0x0000707649FCF28B
0000707649fd057e  call 0x0000707649EC2120
0000707649fd0583  jmp 0x0000707649FCF298
0000707649fd0588  call 0x0000707649EB52F0
0000707649fd058d  jmp 0x0000707649FCF2AB
0000707649fd0592  call 0x0000707649EB52F0
0000707649fd0597  jmp 0x0000707649FCF2BE
0000707649fd059c  call 0x0000707649EB52F0
0000707649fd05a1  jmp 0x0000707649FCF2D1
0000707649fd05a6  call 0x0000707649EB52F0
0000707649fd05ab  jmp 0x0000707649FCF2E4
0000707649fd05b0  call 0x0000707649EC2240
0000707649fd05b5  jmp 0x0000707649FCF2F9
0000707649fd05ba  call 0x0000707649EC2240
0000707649fd05bf  jmp 0x0000707649FCF30C
0000707649fd05c4  call 0x0000707649EC2120
0000707649fd05c9  jmp 0x0000707649FCF319
0000707649fd05ce  call 0x0000707649EB52F0
0000707649fd05d3  jmp 0x0000707649FCF32C
0000707649fd05d8  call 0x0000707649EB52F0
0000707649fd05dd  jmp 0x0000707649FCF34F
0000707649fd05e2  call 0x0000707649EB52F0
0000707649fd05e7  jmp 0x0000707649FCF362
0000707649fd05ec  call 0x0000707649DFF540
0000707649fd05f1  jmp 0x0000707649FCF380
0000707649fd05f6  call 0x0000707649E08C20
0000707649fd05fb  jmp 0x0000707649FCF38A
0000707649fd0600  call 0x0000707649ED6600
0000707649fd0605  jmp 0x0000707649FCF396
0000707649fd060a  call 0x0000707649DFF540
0000707649fd060f  jmp 0x0000707649FCF3A6
0000707649fd0614  call 0x0000707649EC0370
0000707649fd0619  jmp 0x0000707649FCF3D4
0000707649fd061e  call 0x0000707649EBF100
0000707649fd0623  jmp 0x0000707649FCF3DD
0000707649fd0628  call 0x0000707649EC0370
0000707649fd062d  jmp 0x0000707649FCF43B
0000707649fd0632  call 0x0000707649EBF100
0000707649fd0637  jmp 0x0000707649FCF444
0000707649fd063c  call 0x0000707649EC0370
0000707649fd0641  jmp 0x0000707649FCF48B
0000707649fd0646  call 0x0000707649EBF100
0000707649fd064b  jmp 0x0000707649FCF494
0000707649fd0650  call 0x0000707649E0B720
0000707649fd0655  jmp 0x0000707649FCF4D7
0000707649fd065a  call 0x0000707649EB47C0
0000707649fd065f  jmp 0x0000707649FCF4EA
0000707649fd0664  call 0x0000707649E08B00
0000707649fd0669  jmp 0x0000707649FCF501
0000707649fd066e  call 0x0000707649DFF430
0000707649fd0673  jmp 0x0000707649FCF514
0000707649fd0678  call 0x0000707649DFF430
0000707649fd067d  jmp 0x0000707649FCF527
0000707649fd0682  sub rsp, 0x08
0000707649fd0686  push rax
0000707649fd0687  push rcx
0000707649fd0688  push rdx
0000707649fd0689  push rdi
0000707649fd068a  push rsi
0000707649fd068b  push r8
0000707649fd068d  push r9
0000707649fd068f  push r10
0000707649fd0691  push r11
0000707649fd0693  sub rsp, 0xF0
0000707649fd069a  vmovaps [rsp], xmm0
0000707649fd069f  vmovaps [rsp+0x10], xmm2
0000707649fd06a5  vmovaps [rsp+0x20], xmm3
0000707649fd06ab  vmovaps [rsp+0x30], xmm4
0000707649fd06b1  vmovaps [rsp+0x40], xmm5
0000707649fd06b7  vmovaps [rsp+0x50], xmm6
0000707649fd06bd  vmovaps [rsp+0x60], xmm7
0000707649fd06c3  vmovaps [rsp+0x70], xmm8
0000707649fd06c9  vmovaps [rsp+0x80], xmm9
0000707649fd06d2  vmovaps [rsp+0x90], xmm10
0000707649fd06db  vmovaps [rsp+0xA0], xmm11
0000707649fd06e4  vmovaps [rsp+0xB0], xmm12
0000707649fd06ed  vmovaps [rsp+0xC0], xmm13
0000707649fd06f6  vmovaps [rsp+0xD0], xmm14
0000707649fd06ff  vmovaps [rsp+0xE0], xmm15
0000707649fd0708  sub rsp, 0x30
0000707649fd070c  movaps [rsp], xmm1
0000707649fd0710  movaps [rsp+0x10], xmm15
0000707649fd0716  movaps [rsp+0x20], xmm14
0000707649fd071c  lea rdi, [rsp]
0000707649fd0720  mov esi, 0x00
0000707649fd0725  mov rax, 0x59CB0B054530
0000707649fd072f  call rax
0000707649fd0731  movaps xmm1, [rsp]
0000707649fd0735  add rsp, 0x30
0000707649fd0739  vmovaps xmm0, [rsp]
0000707649fd073e  vmovaps xmm2, [rsp+0x10]
0000707649fd0744  vmovaps xmm3, [rsp+0x20]
0000707649fd074a  vmovaps xmm4, [rsp+0x30]
0000707649fd0750  vmovaps xmm5, [rsp+0x40]
0000707649fd0756  vmovaps xmm6, [rsp+0x50]
0000707649fd075c  vmovaps xmm7, [rsp+0x60]
0000707649fd0762  vmovaps xmm8, [rsp+0x70]
0000707649fd0768  vmovaps xmm9, [rsp+0x80]
0000707649fd0771  vmovaps xmm10, [rsp+0x90]
0000707649fd077a  vmovaps xmm11, [rsp+0xA0]
0000707649fd0783  vmovaps xmm12, [rsp+0xB0]
0000707649fd078c  vmovaps xmm13, [rsp+0xC0]
0000707649fd0795  vmovaps xmm14, [rsp+0xD0]
0000707649fd079e  vmovaps xmm15, [rsp+0xE0]
0000707649fd07a7  add rsp, 0xF0
0000707649fd07ae  pop r11
0000707649fd07b0  pop r10
0000707649fd07b2  pop r9
0000707649fd07b4  pop r8
0000707649fd07b6  pop rsi
0000707649fd07b7  pop rdi
0000707649fd07b8  pop rdx
0000707649fd07b9  pop rcx
0000707649fd07ba  pop rax
0000707649fd07bb  add rsp, 0x08
0000707649fd07bf  jmp 0x0000707649FCF581
0000707649fd07c4  sub rsp, 0x08
0000707649fd07c8  push rax
0000707649fd07c9  push rcx
0000707649fd07ca  push rdx
0000707649fd07cb  push rdi
0000707649fd07cc  push rsi
0000707649fd07cd  push r8
0000707649fd07cf  push r9
0000707649fd07d1  push r10
0000707649fd07d3  push r11
0000707649fd07d5  sub rsp, 0xF0
0000707649fd07dc  vmovaps [rsp], xmm0
0000707649fd07e1  vmovaps [rsp+0x10], xmm1
0000707649fd07e7  vmovaps [rsp+0x20], xmm2
0000707649fd07ed  vmovaps [rsp+0x30], xmm3
0000707649fd07f3  vmovaps [rsp+0x40], xmm4
0000707649fd07f9  vmovaps [rsp+0x50], xmm5
0000707649fd07ff  vmovaps [rsp+0x60], xmm6
0000707649fd0805  vmovaps [rsp+0x70], xmm7
0000707649fd080b  vmovaps [rsp+0x80], xmm8
0000707649fd0814  vmovaps [rsp+0x90], xmm9
0000707649fd081d  vmovaps [rsp+0xA0], xmm10
0000707649fd0826  vmovaps [rsp+0xB0], xmm11
0000707649fd082f  vmovaps [rsp+0xC0], xmm12
0000707649fd0838  vmovaps [rsp+0xD0], xmm14
0000707649fd0841  vmovaps [rsp+0xE0], xmm15
0000707649fd084a  sub rsp, 0x30
0000707649fd084e  movaps [rsp], xmm13
0000707649fd0853  movaps [rsp+0x10], xmm1
0000707649fd0858  movaps [rsp+0x20], xmm14
0000707649fd085e  lea rdi, [rsp]
0000707649fd0862  mov esi, 0x00
0000707649fd0867  mov rax, 0x59CB0B054530
0000707649fd0871  call rax
0000707649fd0873  movaps xmm13, [rsp]
0000707649fd0878  add rsp, 0x30
0000707649fd087c  vmovaps xmm0, [rsp]
0000707649fd0881  vmovaps xmm1, [rsp+0x10]
0000707649fd0887  vmovaps xmm2, [rsp+0x20]
0000707649fd088d  vmovaps xmm3, [rsp+0x30]
0000707649fd0893  vmovaps xmm4, [rsp+0x40]
0000707649fd0899  vmovaps xmm5, [rsp+0x50]
0000707649fd089f  vmovaps xmm6, [rsp+0x60]
0000707649fd08a5  vmovaps xmm7, [rsp+0x70]
0000707649fd08ab  vmovaps xmm8, [rsp+0x80]
0000707649fd08b4  vmovaps xmm9, [rsp+0x90]
0000707649fd08bd  vmovaps xmm10, [rsp+0xA0]
0000707649fd08c6  vmovaps xmm11, [rsp+0xB0]
0000707649fd08cf  vmovaps xmm12, [rsp+0xC0]
0000707649fd08d8  vmovaps xmm14, [rsp+0xD0]
0000707649fd08e1  vmovaps xmm15, [rsp+0xE0]
0000707649fd08ea  add rsp, 0xF0
0000707649fd08f1  pop r11
0000707649fd08f3  pop r10
0000707649fd08f5  pop r9
0000707649fd08f7  pop r8
0000707649fd08f9  pop rsi
0000707649fd08fa  pop rdi
0000707649fd08fb  pop rdx
0000707649fd08fc  pop rcx
0000707649fd08fd  pop rax
0000707649fd08fe  add rsp, 0x08
0000707649fd0902  jmp 0x0000707649FCF5CF
0000707649fd0907  sub rsp, 0x08
0000707649fd090b  push rax
0000707649fd090c  push rcx
0000707649fd090d  push rdx
0000707649fd090e  push rdi
0000707649fd090f  push rsi
0000707649fd0910  push r8
0000707649fd0912  push r9
0000707649fd0914  push r10
0000707649fd0916  push r11
0000707649fd0918  sub rsp, 0xF0
0000707649fd091f  vmovaps [rsp], xmm0
0000707649fd0924  vmovaps [rsp+0x10], xmm1
0000707649fd092a  vmovaps [rsp+0x20], xmm2
0000707649fd0930  vmovaps [rsp+0x30], xmm3
0000707649fd0936  vmovaps [rsp+0x40], xmm4
0000707649fd093c  vmovaps [rsp+0x50], xmm5
0000707649fd0942  vmovaps [rsp+0x60], xmm6
0000707649fd0948  vmovaps [rsp+0x70], xmm7
0000707649fd094e  vmovaps [rsp+0x80], xmm8
0000707649fd0957  vmovaps [rsp+0x90], xmm9
0000707649fd0960  vmovaps [rsp+0xA0], xmm10
0000707649fd0969  vmovaps [rsp+0xB0], xmm11
0000707649fd0972  vmovaps [rsp+0xC0], xmm12
0000707649fd097b  vmovaps [rsp+0xD0], xmm13
0000707649fd0984  vmovaps [rsp+0xE0], xmm14
0000707649fd098d  sub rsp, 0x30
0000707649fd0991  movaps [rsp], xmm15
0000707649fd0996  movaps [rsp+0x10], xmm14
0000707649fd099c  movaps [rsp+0x20], xmm1
0000707649fd09a1  lea rdi, [rsp]
0000707649fd09a5  mov esi, 0x00
0000707649fd09aa  mov rax, 0x59CB0B054530
0000707649fd09b4  call rax
0000707649fd09b6  movaps xmm15, [rsp]
0000707649fd09bb  add rsp, 0x30
0000707649fd09bf  vmovaps xmm0, [rsp]
0000707649fd09c4  vmovaps xmm1, [rsp+0x10]
0000707649fd09ca  vmovaps xmm2, [rsp+0x20]
0000707649fd09d0  vmovaps xmm3, [rsp+0x30]
0000707649fd09d6  vmovaps xmm4, [rsp+0x40]
0000707649fd09dc  vmovaps xmm5, [rsp+0x50]
0000707649fd09e2  vmovaps xmm6, [rsp+0x60]
0000707649fd09e8  vmovaps xmm7, [rsp+0x70]
0000707649fd09ee  vmovaps xmm8, [rsp+0x80]
0000707649fd09f7  vmovaps xmm9, [rsp+0x90]
0000707649fd0a00  vmovaps xmm10, [rsp+0xA0]
0000707649fd0a09  vmovaps xmm11, [rsp+0xB0]
0000707649fd0a12  vmovaps xmm12, [rsp+0xC0]
0000707649fd0a1b  vmovaps xmm13, [rsp+0xD0]
0000707649fd0a24  vmovaps xmm14, [rsp+0xE0]
0000707649fd0a2d  add rsp, 0xF0
0000707649fd0a34  pop r11
0000707649fd0a36  pop r10
0000707649fd0a38  pop r9
0000707649fd0a3a  pop r8
0000707649fd0a3c  pop rsi
0000707649fd0a3d  pop rdi
0000707649fd0a3e  pop rdx
0000707649fd0a3f  pop rcx
0000707649fd0a40  pop rax
0000707649fd0a41  add rsp, 0x08
0000707649fd0a45  jmp 0x0000707649FCF617
0000707649fd0a4a  sub rsp, 0x08
0000707649fd0a4e  push rax
0000707649fd0a4f  push rcx
0000707649fd0a50  push rdx
0000707649fd0a51  push rdi
0000707649fd0a52  push rsi
0000707649fd0a53  push r8
0000707649fd0a55  push r9
0000707649fd0a57  push r10
0000707649fd0a59  push r11
0000707649fd0a5b  sub rsp, 0xF0
0000707649fd0a62  vmovaps [rsp], xmm0
0000707649fd0a67  vmovaps [rsp+0x10], xmm2
0000707649fd0a6d  vmovaps [rsp+0x20], xmm3
0000707649fd0a73  vmovaps [rsp+0x30], xmm4
0000707649fd0a79  vmovaps [rsp+0x40], xmm5
0000707649fd0a7f  vmovaps [rsp+0x50], xmm6
0000707649fd0a85  vmovaps [rsp+0x60], xmm7
0000707649fd0a8b  vmovaps [rsp+0x70], xmm8
0000707649fd0a91  vmovaps [rsp+0x80], xmm9
0000707649fd0a9a  vmovaps [rsp+0x90], xmm10
0000707649fd0aa3  vmovaps [rsp+0xA0], xmm11
0000707649fd0aac  vmovaps [rsp+0xB0], xmm12
0000707649fd0ab5  vmovaps [rsp+0xC0], xmm13
0000707649fd0abe  vmovaps [rsp+0xD0], xmm14
0000707649fd0ac7  vmovaps [rsp+0xE0], xmm15
0000707649fd0ad0  sub rsp, 0x30
0000707649fd0ad4  movaps [rsp], xmm1
0000707649fd0ad8  movaps [rsp+0x10], xmm14
0000707649fd0ade  movaps [rsp+0x20], xmm10
0000707649fd0ae4  lea rdi, [rsp]
0000707649fd0ae8  mov esi, 0x00
0000707649fd0aed  mov rax, 0x59CB0B054530
0000707649fd0af7  call rax
0000707649fd0af9  movaps xmm1, [rsp]
0000707649fd0afd  add rsp, 0x30
0000707649fd0b01  vmovaps xmm0, [rsp]
0000707649fd0b06  vmovaps xmm2, [rsp+0x10]
0000707649fd0b0c  vmovaps xmm3, [rsp+0x20]
0000707649fd0b12  vmovaps xmm4, [rsp+0x30]
0000707649fd0b18  vmovaps xmm5, [rsp+0x40]
0000707649fd0b1e  vmovaps xmm6, [rsp+0x50]
0000707649fd0b24  vmovaps xmm7, [rsp+0x60]
0000707649fd0b2a  vmovaps xmm8, [rsp+0x70]
0000707649fd0b30  vmovaps xmm9, [rsp+0x80]
0000707649fd0b39  vmovaps xmm10, [rsp+0x90]
0000707649fd0b42  vmovaps xmm11, [rsp+0xA0]
0000707649fd0b4b  vmovaps xmm12, [rsp+0xB0]
0000707649fd0b54  vmovaps xmm13, [rsp+0xC0]
0000707649fd0b5d  vmovaps xmm14, [rsp+0xD0]
0000707649fd0b66  vmovaps xmm15, [rsp+0xE0]
0000707649fd0b6f  add rsp, 0xF0
0000707649fd0b76  pop r11
0000707649fd0b78  pop r10
0000707649fd0b7a  pop r9
0000707649fd0b7c  pop r8
0000707649fd0b7e  pop rsi
0000707649fd0b7f  pop rdi
0000707649fd0b80  pop rdx
0000707649fd0b81  pop rcx
0000707649fd0b82  pop rax
0000707649fd0b83  add rsp, 0x08
0000707649fd0b87  jmp 0x0000707649FCF631
0000707649fd0b8c  sub rsp, 0x08
0000707649fd0b90  push rax
0000707649fd0b91  push rcx
0000707649fd0b92  push rdx
0000707649fd0b93  push rdi
0000707649fd0b94  push rsi
0000707649fd0b95  push r8
0000707649fd0b97  push r9
0000707649fd0b99  push r10
0000707649fd0b9b  push r11
0000707649fd0b9d  sub rsp, 0xF0
0000707649fd0ba4  vmovaps [rsp], xmm0
0000707649fd0ba9  vmovaps [rsp+0x10], xmm1
0000707649fd0baf  vmovaps [rsp+0x20], xmm2
0000707649fd0bb5  vmovaps [rsp+0x30], xmm3
0000707649fd0bbb  vmovaps [rsp+0x40], xmm4
0000707649fd0bc1  vmovaps [rsp+0x50], xmm5
0000707649fd0bc7  vmovaps [rsp+0x60], xmm6
0000707649fd0bcd  vmovaps [rsp+0x70], xmm7
0000707649fd0bd3  vmovaps [rsp+0x80], xmm8
0000707649fd0bdc  vmovaps [rsp+0x90], xmm9
0000707649fd0be5  vmovaps [rsp+0xA0], xmm10
0000707649fd0bee  vmovaps [rsp+0xB0], xmm11
0000707649fd0bf7  vmovaps [rsp+0xC0], xmm12
0000707649fd0c00  vmovaps [rsp+0xD0], xmm14
0000707649fd0c09  vmovaps [rsp+0xE0], xmm15
0000707649fd0c12  sub rsp, 0x30
0000707649fd0c16  movaps [rsp], xmm13
0000707649fd0c1b  movaps [rsp+0x10], xmm14
0000707649fd0c21  movaps [rsp+0x20], xmm2
0000707649fd0c26  lea rdi, [rsp]
0000707649fd0c2a  mov esi, 0x00
0000707649fd0c2f  mov rax, 0x59CB0B054530
0000707649fd0c39  call rax
0000707649fd0c3b  movaps xmm13, [rsp]
0000707649fd0c40  add rsp, 0x30
0000707649fd0c44  vmovaps xmm0, [rsp]
0000707649fd0c49  vmovaps xmm1, [rsp+0x10]
0000707649fd0c4f  vmovaps xmm2, [rsp+0x20]
0000707649fd0c55  vmovaps xmm3, [rsp+0x30]
0000707649fd0c5b  vmovaps xmm4, [rsp+0x40]
0000707649fd0c61  vmovaps xmm5, [rsp+0x50]
0000707649fd0c67  vmovaps xmm6, [rsp+0x60]
0000707649fd0c6d  vmovaps xmm7, [rsp+0x70]
0000707649fd0c73  vmovaps xmm8, [rsp+0x80]
0000707649fd0c7c  vmovaps xmm9, [rsp+0x90]
0000707649fd0c85  vmovaps xmm10, [rsp+0xA0]
0000707649fd0c8e  vmovaps xmm11, [rsp+0xB0]
0000707649fd0c97  vmovaps xmm12, [rsp+0xC0]
0000707649fd0ca0  vmovaps xmm14, [rsp+0xD0]
0000707649fd0ca9  vmovaps xmm15, [rsp+0xE0]
0000707649fd0cb2  add rsp, 0xF0
0000707649fd0cb9  pop r11
0000707649fd0cbb  pop r10
0000707649fd0cbd  pop r9
0000707649fd0cbf  pop r8
0000707649fd0cc1  pop rsi
0000707649fd0cc2  pop rdi
0000707649fd0cc3  pop rdx
0000707649fd0cc4  pop rcx
0000707649fd0cc5  pop rax
0000707649fd0cc6  add rsp, 0x08
0000707649fd0cca  jmp 0x0000707649FCF64C
0000707649fd0ccf  sub rsp, 0x08
0000707649fd0cd3  push rax
0000707649fd0cd4  push rcx
0000707649fd0cd5  push rdx
0000707649fd0cd6  push rdi
0000707649fd0cd7  push rsi
0000707649fd0cd8  push r8
0000707649fd0cda  push r9
0000707649fd0cdc  push r10
0000707649fd0cde  push r11
0000707649fd0ce0  sub rsp, 0xF0
0000707649fd0ce7  vmovaps [rsp], xmm0
0000707649fd0cec  vmovaps [rsp+0x10], xmm2
0000707649fd0cf2  vmovaps [rsp+0x20], xmm3
0000707649fd0cf8  vmovaps [rsp+0x30], xmm4
0000707649fd0cfe  vmovaps [rsp+0x40], xmm5
0000707649fd0d04  vmovaps [rsp+0x50], xmm6
0000707649fd0d0a  vmovaps [rsp+0x60], xmm7
0000707649fd0d10  vmovaps [rsp+0x70], xmm8
0000707649fd0d16  vmovaps [rsp+0x80], xmm9
0000707649fd0d1f  vmovaps [rsp+0x90], xmm10
0000707649fd0d28  vmovaps [rsp+0xA0], xmm11
0000707649fd0d31  vmovaps [rsp+0xB0], xmm12
0000707649fd0d3a  vmovaps [rsp+0xC0], xmm13
0000707649fd0d43  vmovaps [rsp+0xD0], xmm14
0000707649fd0d4c  vmovaps [rsp+0xE0], xmm15
0000707649fd0d55  sub rsp, 0x30
0000707649fd0d59  movaps [rsp], xmm1
0000707649fd0d5d  movaps [rsp+0x10], xmm10
0000707649fd0d63  movaps [rsp+0x20], xmm2
0000707649fd0d68  lea rdi, [rsp]
0000707649fd0d6c  mov esi, 0x00
0000707649fd0d71  mov rax, 0x59CB0B054530
0000707649fd0d7b  call rax
0000707649fd0d7d  movaps xmm1, [rsp]
0000707649fd0d81  add rsp, 0x30
0000707649fd0d85  vmovaps xmm0, [rsp]
0000707649fd0d8a  vmovaps xmm2, [rsp+0x10]
0000707649fd0d90  vmovaps xmm3, [rsp+0x20]
0000707649fd0d96  vmovaps xmm4, [rsp+0x30]
0000707649fd0d9c  vmovaps xmm5, [rsp+0x40]
0000707649fd0da2  vmovaps xmm6, [rsp+0x50]
0000707649fd0da8  vmovaps xmm7, [rsp+0x60]
0000707649fd0dae  vmovaps xmm8, [rsp+0x70]
0000707649fd0db4  vmovaps xmm9, [rsp+0x80]
0000707649fd0dbd  vmovaps xmm10, [rsp+0x90]
0000707649fd0dc6  vmovaps xmm11, [rsp+0xA0]
0000707649fd0dcf  vmovaps xmm12, [rsp+0xB0]
0000707649fd0dd8  vmovaps xmm13, [rsp+0xC0]
0000707649fd0de1  vmovaps xmm14, [rsp+0xD0]
0000707649fd0dea  vmovaps xmm15, [rsp+0xE0]
0000707649fd0df3  add rsp, 0xF0
0000707649fd0dfa  pop r11
0000707649fd0dfc  pop r10
0000707649fd0dfe  pop r9
0000707649fd0e00  pop r8
0000707649fd0e02  pop rsi
0000707649fd0e03  pop rdi
0000707649fd0e04  pop rdx
0000707649fd0e05  pop rcx
0000707649fd0e06  pop rax
0000707649fd0e07  add rsp, 0x08
0000707649fd0e0b  jmp 0x0000707649FCF6B4
0000707649fd0e10  sub rsp, 0x08
0000707649fd0e14  push rax
0000707649fd0e15  push rcx
0000707649fd0e16  push rdx
0000707649fd0e17  push rdi
0000707649fd0e18  push rsi
0000707649fd0e19  push r8
0000707649fd0e1b  push r9
0000707649fd0e1d  push r10
0000707649fd0e1f  push r11
0000707649fd0e21  sub rsp, 0xF0
0000707649fd0e28  vmovaps [rsp], xmm0
0000707649fd0e2d  vmovaps [rsp+0x10], xmm1
0000707649fd0e33  vmovaps [rsp+0x20], xmm2
0000707649fd0e39  vmovaps [rsp+0x30], xmm3
0000707649fd0e3f  vmovaps [rsp+0x40], xmm4
0000707649fd0e45  vmovaps [rsp+0x50], xmm5
0000707649fd0e4b  vmovaps [rsp+0x60], xmm6
0000707649fd0e51  vmovaps [rsp+0x70], xmm7
0000707649fd0e57  vmovaps [rsp+0x80], xmm8
0000707649fd0e60  vmovaps [rsp+0x90], xmm9
0000707649fd0e69  vmovaps [rsp+0xA0], xmm10
0000707649fd0e72  vmovaps [rsp+0xB0], xmm11
0000707649fd0e7b  vmovaps [rsp+0xC0], xmm12
0000707649fd0e84  vmovaps [rsp+0xD0], xmm13
0000707649fd0e8d  vmovaps [rsp+0xE0], xmm14
0000707649fd0e96  sub rsp, 0x30
0000707649fd0e9a  movaps [rsp], xmm15
0000707649fd0e9f  movaps [rsp+0x10], xmm10
0000707649fd0ea5  movaps [rsp+0x20], xmm2
0000707649fd0eaa  lea rdi, [rsp]
0000707649fd0eae  mov esi, 0x00
0000707649fd0eb3  mov rax, 0x59CB0B054530
0000707649fd0ebd  call rax
0000707649fd0ebf  movaps xmm15, [rsp]
0000707649fd0ec4  add rsp, 0x30
0000707649fd0ec8  vmovaps xmm0, [rsp]
0000707649fd0ecd  vmovaps xmm1, [rsp+0x10]
0000707649fd0ed3  vmovaps xmm2, [rsp+0x20]
0000707649fd0ed9  vmovaps xmm3, [rsp+0x30]
0000707649fd0edf  vmovaps xmm4, [rsp+0x40]
0000707649fd0ee5  vmovaps xmm5, [rsp+0x50]
0000707649fd0eeb  vmovaps xmm6, [rsp+0x60]
0000707649fd0ef1  vmovaps xmm7, [rsp+0x70]
0000707649fd0ef7  vmovaps xmm8, [rsp+0x80]
0000707649fd0f00  vmovaps xmm9, [rsp+0x90]
0000707649fd0f09  vmovaps xmm10, [rsp+0xA0]
0000707649fd0f12  vmovaps xmm11, [rsp+0xB0]
0000707649fd0f1b  vmovaps xmm12, [rsp+0xC0]
0000707649fd0f24  vmovaps xmm13, [rsp+0xD0]
0000707649fd0f2d  vmovaps xmm14, [rsp+0xE0]
0000707649fd0f36  add rsp, 0xF0
0000707649fd0f3d  pop r11
0000707649fd0f3f  pop r10
0000707649fd0f41  pop r9
0000707649fd0f43  pop r8
0000707649fd0f45  pop rsi
0000707649fd0f46  pop rdi
0000707649fd0f47  pop rdx
0000707649fd0f48  pop rcx
0000707649fd0f49  pop rax
0000707649fd0f4a  add rsp, 0x08
0000707649fd0f4e  jmp 0x0000707649FCF706
0000707649fd0f53  sub rsp, 0x08
0000707649fd0f57  push rax
0000707649fd0f58  push rcx
0000707649fd0f59  push rdx
0000707649fd0f5a  push rdi
0000707649fd0f5b  push rsi
0000707649fd0f5c  push r8
0000707649fd0f5e  push r9
0000707649fd0f60  push r10
0000707649fd0f62  push r11
0000707649fd0f64  sub rsp, 0xF0
0000707649fd0f6b  vmovaps [rsp], xmm0
0000707649fd0f70  vmovaps [rsp+0x10], xmm2
0000707649fd0f76  vmovaps [rsp+0x20], xmm3
0000707649fd0f7c  vmovaps [rsp+0x30], xmm4
0000707649fd0f82  vmovaps [rsp+0x40], xmm5
0000707649fd0f88  vmovaps [rsp+0x50], xmm6
0000707649fd0f8e  vmovaps [rsp+0x60], xmm7
0000707649fd0f94  vmovaps [rsp+0x70], xmm8
0000707649fd0f9a  vmovaps [rsp+0x80], xmm9
0000707649fd0fa3  vmovaps [rsp+0x90], xmm10
0000707649fd0fac  vmovaps [rsp+0xA0], xmm11
0000707649fd0fb5  vmovaps [rsp+0xB0], xmm12
0000707649fd0fbe  vmovaps [rsp+0xC0], xmm13
0000707649fd0fc7  vmovaps [rsp+0xD0], xmm14
0000707649fd0fd0  vmovaps [rsp+0xE0], xmm15
0000707649fd0fd9  sub rsp, 0x30
0000707649fd0fdd  movaps [rsp], xmm1
0000707649fd0fe1  movaps [rsp+0x10], xmm10
0000707649fd0fe7  movaps [rsp+0x20], xmm12
0000707649fd0fed  lea rdi, [rsp]
0000707649fd0ff1  mov esi, 0x00
0000707649fd0ff6  mov rax, 0x59CB0B054530
0000707649fd1000  call rax
0000707649fd1002  movaps xmm1, [rsp]
0000707649fd1006  add rsp, 0x30
0000707649fd100a  vmovaps xmm0, [rsp]
0000707649fd100f  vmovaps xmm2, [rsp+0x10]
0000707649fd1015  vmovaps xmm3, [rsp+0x20]
0000707649fd101b  vmovaps xmm4, [rsp+0x30]
0000707649fd1021  vmovaps xmm5, [rsp+0x40]
0000707649fd1027  vmovaps xmm6, [rsp+0x50]
0000707649fd102d  vmovaps xmm7, [rsp+0x60]
0000707649fd1033  vmovaps xmm8, [rsp+0x70]
0000707649fd1039  vmovaps xmm9, [rsp+0x80]
0000707649fd1042  vmovaps xmm10, [rsp+0x90]
0000707649fd104b  vmovaps xmm11, [rsp+0xA0]
0000707649fd1054  vmovaps xmm12, [rsp+0xB0]
0000707649fd105d  vmovaps xmm13, [rsp+0xC0]
0000707649fd1066  vmovaps xmm14, [rsp+0xD0]
0000707649fd106f  vmovaps xmm15, [rsp+0xE0]
0000707649fd1078  add rsp, 0xF0
0000707649fd107f  pop r11
0000707649fd1081  pop r10
0000707649fd1083  pop r9
0000707649fd1085  pop r8
0000707649fd1087  pop rsi
0000707649fd1088  pop rdi
0000707649fd1089  pop rdx
0000707649fd108a  pop rcx
0000707649fd108b  pop rax
0000707649fd108c  add rsp, 0x08
0000707649fd1090  jmp 0x0000707649FCF732
0000707649fd1095  sub rsp, 0x08
0000707649fd1099  push rax
0000707649fd109a  push rcx
0000707649fd109b  push rdx
0000707649fd109c  push rdi
0000707649fd109d  push rsi
0000707649fd109e  push r8
0000707649fd10a0  push r9
0000707649fd10a2  push r10
0000707649fd10a4  push r11
0000707649fd10a6  sub rsp, 0xF0
0000707649fd10ad  vmovaps [rsp], xmm0
0000707649fd10b2  vmovaps [rsp+0x10], xmm1
0000707649fd10b8  vmovaps [rsp+0x20], xmm2
0000707649fd10be  vmovaps [rsp+0x30], xmm3
0000707649fd10c4  vmovaps [rsp+0x40], xmm4
0000707649fd10ca  vmovaps [rsp+0x50], xmm5
0000707649fd10d0  vmovaps [rsp+0x60], xmm6
0000707649fd10d6  vmovaps [rsp+0x70], xmm7
0000707649fd10dc  vmovaps [rsp+0x80], xmm8
0000707649fd10e5  vmovaps [rsp+0x90], xmm9
0000707649fd10ee  vmovaps [rsp+0xA0], xmm10
0000707649fd10f7  vmovaps [rsp+0xB0], xmm11
0000707649fd1100  vmovaps [rsp+0xC0], xmm12
0000707649fd1109  vmovaps [rsp+0xD0], xmm13
0000707649fd1112  vmovaps [rsp+0xE0], xmm14
0000707649fd111b  sub rsp, 0x30
0000707649fd111f  movaps [rsp], xmm15
0000707649fd1124  movaps [rsp+0x10], xmm10
0000707649fd112a  movaps [rsp+0x20], xmm12
0000707649fd1130  lea rdi, [rsp]
0000707649fd1134  mov esi, 0x00
0000707649fd1139  mov rax, 0x59CB0B054530
0000707649fd1143  call rax
0000707649fd1145  movaps xmm15, [rsp]
0000707649fd114a  add rsp, 0x30
0000707649fd114e  vmovaps xmm0, [rsp]
0000707649fd1153  vmovaps xmm1, [rsp+0x10]
0000707649fd1159  vmovaps xmm2, [rsp+0x20]
0000707649fd115f  vmovaps xmm3, [rsp+0x30]
0000707649fd1165  vmovaps xmm4, [rsp+0x40]
0000707649fd116b  vmovaps xmm5, [rsp+0x50]
0000707649fd1171  vmovaps xmm6, [rsp+0x60]
0000707649fd1177  vmovaps xmm7, [rsp+0x70]
0000707649fd117d  vmovaps xmm8, [rsp+0x80]
0000707649fd1186  vmovaps xmm9, [rsp+0x90]
0000707649fd118f  vmovaps xmm10, [rsp+0xA0]
0000707649fd1198  vmovaps xmm11, [rsp+0xB0]
0000707649fd11a1  vmovaps xmm12, [rsp+0xC0]
0000707649fd11aa  vmovaps xmm13, [rsp+0xD0]
0000707649fd11b3  vmovaps xmm14, [rsp+0xE0]
0000707649fd11bc  add rsp, 0xF0
0000707649fd11c3  pop r11
0000707649fd11c5  pop r10
0000707649fd11c7  pop r9
0000707649fd11c9  pop r8
0000707649fd11cb  pop rsi
0000707649fd11cc  pop rdi
0000707649fd11cd  pop rdx
0000707649fd11ce  pop rcx
0000707649fd11cf  pop rax
0000707649fd11d0  add rsp, 0x08
0000707649fd11d4  jmp 0x0000707649FCF75E
0000707649fd11d9  call 0x0000707649DFF430
0000707649fd11de  jmp 0x0000707649FCF7EE
0000707649fd11e3  call 0x0000707649DFF430
0000707649fd11e8  jmp 0x0000707649FCF801
0000707649fd11ed  sub rsp, 0x08
0000707649fd11f1  push rax
0000707649fd11f2  push rcx
0000707649fd11f3  push rdx
0000707649fd11f4  push rdi
0000707649fd11f5  push rsi
0000707649fd11f6  push r8
0000707649fd11f8  push r9
0000707649fd11fa  push r10
0000707649fd11fc  push r11
0000707649fd11fe  sub rsp, 0xF0
0000707649fd1205  vmovaps [rsp], xmm0
0000707649fd120a  vmovaps [rsp+0x10], xmm2
0000707649fd1210  vmovaps [rsp+0x20], xmm3
0000707649fd1216  vmovaps [rsp+0x30], xmm4
0000707649fd121c  vmovaps [rsp+0x40], xmm5
0000707649fd1222  vmovaps [rsp+0x50], xmm6
0000707649fd1228  vmovaps [rsp+0x60], xmm7
0000707649fd122e  vmovaps [rsp+0x70], xmm8
0000707649fd1234  vmovaps [rsp+0x80], xmm9
0000707649fd123d  vmovaps [rsp+0x90], xmm10
0000707649fd1246  vmovaps [rsp+0xA0], xmm11
0000707649fd124f  vmovaps [rsp+0xB0], xmm12
0000707649fd1258  vmovaps [rsp+0xC0], xmm13
0000707649fd1261  vmovaps [rsp+0xD0], xmm14
0000707649fd126a  vmovaps [rsp+0xE0], xmm15
0000707649fd1273  sub rsp, 0x30
0000707649fd1277  movaps [rsp], xmm1
0000707649fd127b  movaps [rsp+0x10], xmm13
0000707649fd1281  movaps [rsp+0x20], xmm2
0000707649fd1286  lea rdi, [rsp]
0000707649fd128a  mov esi, 0x00
0000707649fd128f  mov rax, 0x59CB0B054530
0000707649fd1299  call rax
0000707649fd129b  movaps xmm1, [rsp]
0000707649fd129f  add rsp, 0x30
0000707649fd12a3  vmovaps xmm0, [rsp]
0000707649fd12a8  vmovaps xmm2, [rsp+0x10]
0000707649fd12ae  vmovaps xmm3, [rsp+0x20]
0000707649fd12b4  vmovaps xmm4, [rsp+0x30]
0000707649fd12ba  vmovaps xmm5, [rsp+0x40]
0000707649fd12c0  vmovaps xmm6, [rsp+0x50]
0000707649fd12c6  vmovaps xmm7, [rsp+0x60]
0000707649fd12cc  vmovaps xmm8, [rsp+0x70]
0000707649fd12d2  vmovaps xmm9, [rsp+0x80]
0000707649fd12db  vmovaps xmm10, [rsp+0x90]
0000707649fd12e4  vmovaps xmm11, [rsp+0xA0]
0000707649fd12ed  vmovaps xmm12, [rsp+0xB0]
0000707649fd12f6  vmovaps xmm13, [rsp+0xC0]
0000707649fd12ff  vmovaps xmm14, [rsp+0xD0]
0000707649fd1308  vmovaps xmm15, [rsp+0xE0]
0000707649fd1311  add rsp, 0xF0
0000707649fd1318  pop r11
0000707649fd131a  pop r10
0000707649fd131c  pop r9
0000707649fd131e  pop r8
0000707649fd1320  pop rsi
0000707649fd1321  pop rdi
0000707649fd1322  pop rdx
0000707649fd1323  pop rcx
0000707649fd1324  pop rax
0000707649fd1325  add rsp, 0x08
0000707649fd1329  jmp 0x0000707649FCF82C
0000707649fd132e  call 0x0000707649E0E760
0000707649fd1333  jmp 0x0000707649FCF839
0000707649fd1338  sub rsp, 0x08
0000707649fd133c  push rax
0000707649fd133d  push rcx
0000707649fd133e  push rdx
0000707649fd133f  push rdi
0000707649fd1340  push rsi
0000707649fd1341  push r8
0000707649fd1343  push r9
0000707649fd1345  push r10
0000707649fd1347  push r11
0000707649fd1349  sub rsp, 0xF0
0000707649fd1350  vmovaps [rsp], xmm0
0000707649fd1355  vmovaps [rsp+0x10], xmm1
0000707649fd135b  vmovaps [rsp+0x20], xmm2
0000707649fd1361  vmovaps [rsp+0x30], xmm3
0000707649fd1367  vmovaps [rsp+0x40], xmm4
0000707649fd136d  vmovaps [rsp+0x50], xmm5
0000707649fd1373  vmovaps [rsp+0x60], xmm6
0000707649fd1379  vmovaps [rsp+0x70], xmm7
0000707649fd137f  vmovaps [rsp+0x80], xmm8
0000707649fd1388  vmovaps [rsp+0x90], xmm9
0000707649fd1391  vmovaps [rsp+0xA0], xmm10
0000707649fd139a  vmovaps [rsp+0xB0], xmm11
0000707649fd13a3  vmovaps [rsp+0xC0], xmm12
0000707649fd13ac  vmovaps [rsp+0xD0], xmm14
0000707649fd13b5  vmovaps [rsp+0xE0], xmm15
0000707649fd13be  sub rsp, 0x30
0000707649fd13c2  movaps [rsp], xmm13
0000707649fd13c7  movaps [rsp+0x10], xmm2
0000707649fd13cc  movaps [rsp+0x20], xmm1
0000707649fd13d1  lea rdi, [rsp]
0000707649fd13d5  mov esi, 0x00
0000707649fd13da  mov rax, 0x59CB0B054530
0000707649fd13e4  call rax
0000707649fd13e6  movaps xmm13, [rsp]
0000707649fd13eb  add rsp, 0x30
0000707649fd13ef  vmovaps xmm0, [rsp]
0000707649fd13f4  vmovaps xmm1, [rsp+0x10]
0000707649fd13fa  vmovaps xmm2, [rsp+0x20]
0000707649fd1400  vmovaps xmm3, [rsp+0x30]
0000707649fd1406  vmovaps xmm4, [rsp+0x40]
0000707649fd140c  vmovaps xmm5, [rsp+0x50]
0000707649fd1412  vmovaps xmm6, [rsp+0x60]
0000707649fd1418  vmovaps xmm7, [rsp+0x70]
0000707649fd141e  vmovaps xmm8, [rsp+0x80]
0000707649fd1427  vmovaps xmm9, [rsp+0x90]
0000707649fd1430  vmovaps xmm10, [rsp+0xA0]
0000707649fd1439  vmovaps xmm11, [rsp+0xB0]
0000707649fd1442  vmovaps xmm12, [rsp+0xC0]
0000707649fd144b  vmovaps xmm14, [rsp+0xD0]
0000707649fd1454  vmovaps xmm15, [rsp+0xE0]
0000707649fd145d  add rsp, 0xF0
0000707649fd1464  pop r11
0000707649fd1466  pop r10
0000707649fd1468  pop r9
0000707649fd146a  pop r8
0000707649fd146c  pop rsi
0000707649fd146d  pop rdi
0000707649fd146e  pop rdx
0000707649fd146f  pop rcx
0000707649fd1470  pop rax
0000707649fd1471  add rsp, 0x08
0000707649fd1475  jmp 0x0000707649FCF878
0000707649fd147a  sub rsp, 0x08
0000707649fd147e  push rax
0000707649fd147f  push rcx
0000707649fd1480  push rdx
0000707649fd1481  push rdi
0000707649fd1482  push rsi
0000707649fd1483  push r8
0000707649fd1485  push r9
0000707649fd1487  push r10
0000707649fd1489  push r11
0000707649fd148b  sub rsp, 0xF0
0000707649fd1492  vmovaps [rsp], xmm0
0000707649fd1497  vmovaps [rsp+0x10], xmm2
0000707649fd149d  vmovaps [rsp+0x20], xmm3
0000707649fd14a3  vmovaps [rsp+0x30], xmm4
0000707649fd14a9  vmovaps [rsp+0x40], xmm5
0000707649fd14af  vmovaps [rsp+0x50], xmm6
0000707649fd14b5  vmovaps [rsp+0x60], xmm7
0000707649fd14bb  vmovaps [rsp+0x70], xmm8
0000707649fd14c1  vmovaps [rsp+0x80], xmm9
0000707649fd14ca  vmovaps [rsp+0x90], xmm10
0000707649fd14d3  vmovaps [rsp+0xA0], xmm11
0000707649fd14dc  vmovaps [rsp+0xB0], xmm12
0000707649fd14e5  vmovaps [rsp+0xC0], xmm13
0000707649fd14ee  vmovaps [rsp+0xD0], xmm14
0000707649fd14f7  vmovaps [rsp+0xE0], xmm15
0000707649fd1500  sub rsp, 0x30
0000707649fd1504  movaps [rsp], xmm1
0000707649fd1508  movaps [rsp+0x10], xmm15
0000707649fd150e  movaps [rsp+0x20], xmm2
0000707649fd1513  lea rdi, [rsp]
0000707649fd1517  mov esi, 0x00
0000707649fd151c  mov rax, 0x59CB0B054530
0000707649fd1526  call rax
0000707649fd1528  movaps xmm1, [rsp]
0000707649fd152c  add rsp, 0x30
0000707649fd1530  vmovaps xmm0, [rsp]
0000707649fd1535  vmovaps xmm2, [rsp+0x10]
0000707649fd153b  vmovaps xmm3, [rsp+0x20]
0000707649fd1541  vmovaps xmm4, [rsp+0x30]
0000707649fd1547  vmovaps xmm5, [rsp+0x40]
0000707649fd154d  vmovaps xmm6, [rsp+0x50]
0000707649fd1553  vmovaps xmm7, [rsp+0x60]
0000707649fd1559  vmovaps xmm8, [rsp+0x70]
0000707649fd155f  vmovaps xmm9, [rsp+0x80]
0000707649fd1568  vmovaps xmm10, [rsp+0x90]
0000707649fd1571  vmovaps xmm11, [rsp+0xA0]
0000707649fd157a  vmovaps xmm12, [rsp+0xB0]
0000707649fd1583  vmovaps xmm13, [rsp+0xC0]
0000707649fd158c  vmovaps xmm14, [rsp+0xD0]
0000707649fd1595  vmovaps xmm15, [rsp+0xE0]
0000707649fd159e  add rsp, 0xF0
0000707649fd15a5  pop r11
0000707649fd15a7  pop r10
0000707649fd15a9  pop r9
0000707649fd15ab  pop r8
0000707649fd15ad  pop rsi
0000707649fd15ae  pop rdi
0000707649fd15af  pop rdx
0000707649fd15b0  pop rcx
0000707649fd15b1  pop rax
0000707649fd15b2  add rsp, 0x08
0000707649fd15b6  jmp 0x0000707649FCF8AC
0000707649fd15bb  sub rsp, 0x08
0000707649fd15bf  push rax
0000707649fd15c0  push rcx
0000707649fd15c1  push rdx
0000707649fd15c2  push rdi
0000707649fd15c3  push rsi
0000707649fd15c4  push r8
0000707649fd15c6  push r9
0000707649fd15c8  push r10
0000707649fd15ca  push r11
0000707649fd15cc  sub rsp, 0xF0
0000707649fd15d3  vmovaps [rsp], xmm0
0000707649fd15d8  vmovaps [rsp+0x10], xmm1
0000707649fd15de  vmovaps [rsp+0x20], xmm2
0000707649fd15e4  vmovaps [rsp+0x30], xmm3
0000707649fd15ea  vmovaps [rsp+0x40], xmm4
0000707649fd15f0  vmovaps [rsp+0x50], xmm5
0000707649fd15f6  vmovaps [rsp+0x60], xmm6
0000707649fd15fc  vmovaps [rsp+0x70], xmm7
0000707649fd1602  vmovaps [rsp+0x80], xmm8
0000707649fd160b  vmovaps [rsp+0x90], xmm9
0000707649fd1614  vmovaps [rsp+0xA0], xmm10
0000707649fd161d  vmovaps [rsp+0xB0], xmm11
0000707649fd1626  vmovaps [rsp+0xC0], xmm12
0000707649fd162f  vmovaps [rsp+0xD0], xmm13
0000707649fd1638  vmovaps [rsp+0xE0], xmm15
0000707649fd1641  sub rsp, 0x30
0000707649fd1645  movaps [rsp], xmm14
0000707649fd164a  movaps [rsp+0x10], xmm2
0000707649fd164f  movaps [rsp+0x20], xmm15
0000707649fd1655  lea rdi, [rsp]
0000707649fd1659  mov esi, 0x00
0000707649fd165e  mov rax, 0x59CB0B054530
0000707649fd1668  call rax
0000707649fd166a  movaps xmm14, [rsp]
0000707649fd166f  add rsp, 0x30
0000707649fd1673  vmovaps xmm0, [rsp]
0000707649fd1678  vmovaps xmm1, [rsp+0x10]
0000707649fd167e  vmovaps xmm2, [rsp+0x20]
0000707649fd1684  vmovaps xmm3, [rsp+0x30]
0000707649fd168a  vmovaps xmm4, [rsp+0x40]
0000707649fd1690  vmovaps xmm5, [rsp+0x50]
0000707649fd1696  vmovaps xmm6, [rsp+0x60]
0000707649fd169c  vmovaps xmm7, [rsp+0x70]
0000707649fd16a2  vmovaps xmm8, [rsp+0x80]
0000707649fd16ab  vmovaps xmm9, [rsp+0x90]
0000707649fd16b4  vmovaps xmm10, [rsp+0xA0]
0000707649fd16bd  vmovaps xmm11, [rsp+0xB0]
0000707649fd16c6  vmovaps xmm12, [rsp+0xC0]
0000707649fd16cf  vmovaps xmm13, [rsp+0xD0]
0000707649fd16d8  vmovaps xmm15, [rsp+0xE0]
0000707649fd16e1  add rsp, 0xF0
0000707649fd16e8  pop r11
0000707649fd16ea  pop r10
0000707649fd16ec  pop r9
0000707649fd16ee  pop r8
0000707649fd16f0  pop rsi
0000707649fd16f1  pop rdi
0000707649fd16f2  pop rdx
0000707649fd16f3  pop rcx
0000707649fd16f4  pop rax
0000707649fd16f5  add rsp, 0x08
0000707649fd16f9  jmp 0x0000707649FCF8E7
0000707649fd16fe  sub rsp, 0x08
0000707649fd1702  push rax
0000707649fd1703  push rcx
0000707649fd1704  push rdx
0000707649fd1705  push rdi
0000707649fd1706  push rsi
0000707649fd1707  push r8
0000707649fd1709  push r9
0000707649fd170b  push r10
0000707649fd170d  push r11
0000707649fd170f  sub rsp, 0xF0
0000707649fd1716  vmovaps [rsp], xmm0
0000707649fd171b  vmovaps [rsp+0x10], xmm1
0000707649fd1721  vmovaps [rsp+0x20], xmm2
0000707649fd1727  vmovaps [rsp+0x30], xmm3
0000707649fd172d  vmovaps [rsp+0x40], xmm4
0000707649fd1733  vmovaps [rsp+0x50], xmm5
0000707649fd1739  vmovaps [rsp+0x60], xmm6
0000707649fd173f  vmovaps [rsp+0x70], xmm7
0000707649fd1745  vmovaps [rsp+0x80], xmm8
0000707649fd174e  vmovaps [rsp+0x90], xmm9
0000707649fd1757  vmovaps [rsp+0xA0], xmm10
0000707649fd1760  vmovaps [rsp+0xB0], xmm11
0000707649fd1769  vmovaps [rsp+0xC0], xmm12
0000707649fd1772  vmovaps [rsp+0xD0], xmm13
0000707649fd177b  vmovaps [rsp+0xE0], xmm14
0000707649fd1784  sub rsp, 0x30
0000707649fd1788  movaps [rsp], xmm15
0000707649fd178d  movaps [rsp+0x10], xmm2
0000707649fd1792  movaps [rsp+0x20], xmm1
0000707649fd1797  lea rdi, [rsp]
0000707649fd179b  mov esi, 0x00
0000707649fd17a0  mov rax, 0x59CB0B054530
0000707649fd17aa  call rax
0000707649fd17ac  movaps xmm15, [rsp]
0000707649fd17b1  add rsp, 0x30
0000707649fd17b5  vmovaps xmm0, [rsp]
0000707649fd17ba  vmovaps xmm1, [rsp+0x10]
0000707649fd17c0  vmovaps xmm2, [rsp+0x20]
0000707649fd17c6  vmovaps xmm3, [rsp+0x30]
0000707649fd17cc  vmovaps xmm4, [rsp+0x40]
0000707649fd17d2  vmovaps xmm5, [rsp+0x50]
0000707649fd17d8  vmovaps xmm6, [rsp+0x60]
0000707649fd17de  vmovaps xmm7, [rsp+0x70]
0000707649fd17e4  vmovaps xmm8, [rsp+0x80]
0000707649fd17ed  vmovaps xmm9, [rsp+0x90]
0000707649fd17f6  vmovaps xmm10, [rsp+0xA0]
0000707649fd17ff  vmovaps xmm11, [rsp+0xB0]
0000707649fd1808  vmovaps xmm12, [rsp+0xC0]
0000707649fd1811  vmovaps xmm13, [rsp+0xD0]
0000707649fd181a  vmovaps xmm14, [rsp+0xE0]
0000707649fd1823  add rsp, 0xF0
0000707649fd182a  pop r11
0000707649fd182c  pop r10
0000707649fd182e  pop r9
0000707649fd1830  pop r8
0000707649fd1832  pop rsi
0000707649fd1833  pop rdi
0000707649fd1834  pop rdx
0000707649fd1835  pop rcx
0000707649fd1836  pop rax
0000707649fd1837  add rsp, 0x08
0000707649fd183b  jmp 0x0000707649FCF923
0000707649fd1840  call 0x0000707649DFF430
0000707649fd1845  jmp 0x0000707649FCF930
0000707649fd184a  sub rsp, 0x08
0000707649fd184e  push rax
0000707649fd184f  push rcx
0000707649fd1850  push rdx
0000707649fd1851  push rdi
0000707649fd1852  push rsi
0000707649fd1853  push r8
0000707649fd1855  push r9
0000707649fd1857  push r10
0000707649fd1859  push r11
0000707649fd185b  sub rsp, 0xF0
0000707649fd1862  vmovaps [rsp], xmm0
0000707649fd1867  vmovaps [rsp+0x10], xmm1
0000707649fd186d  vmovaps [rsp+0x20], xmm3
0000707649fd1873  vmovaps [rsp+0x30], xmm4
0000707649fd1879  vmovaps [rsp+0x40], xmm5
0000707649fd187f  vmovaps [rsp+0x50], xmm6
0000707649fd1885  vmovaps [rsp+0x60], xmm7
0000707649fd188b  vmovaps [rsp+0x70], xmm8
0000707649fd1891  vmovaps [rsp+0x80], xmm9
0000707649fd189a  vmovaps [rsp+0x90], xmm10
0000707649fd18a3  vmovaps [rsp+0xA0], xmm11
0000707649fd18ac  vmovaps [rsp+0xB0], xmm12
0000707649fd18b5  vmovaps [rsp+0xC0], xmm13
0000707649fd18be  vmovaps [rsp+0xD0], xmm14
0000707649fd18c7  vmovaps [rsp+0xE0], xmm15
0000707649fd18d0  sub rsp, 0x30
0000707649fd18d4  movaps [rsp], xmm2
0000707649fd18d8  movaps [rsp+0x10], xmm1
0000707649fd18dd  movaps [rsp+0x20], xmm14
0000707649fd18e3  lea rdi, [rsp]
0000707649fd18e7  mov esi, 0x00
0000707649fd18ec  mov rax, 0x59CB0B054530
0000707649fd18f6  call rax
0000707649fd18f8  movaps xmm2, [rsp]
0000707649fd18fc  add rsp, 0x30
0000707649fd1900  vmovaps xmm0, [rsp]
0000707649fd1905  vmovaps xmm1, [rsp+0x10]
0000707649fd190b  vmovaps xmm3, [rsp+0x20]
0000707649fd1911  vmovaps xmm4, [rsp+0x30]
0000707649fd1917  vmovaps xmm5, [rsp+0x40]
0000707649fd191d  vmovaps xmm6, [rsp+0x50]
0000707649fd1923  vmovaps xmm7, [rsp+0x60]
0000707649fd1929  vmovaps xmm8, [rsp+0x70]
0000707649fd192f  vmovaps xmm9, [rsp+0x80]
0000707649fd1938  vmovaps xmm10, [rsp+0x90]
0000707649fd1941  vmovaps xmm11, [rsp+0xA0]
0000707649fd194a  vmovaps xmm12, [rsp+0xB0]
0000707649fd1953  vmovaps xmm13, [rsp+0xC0]
0000707649fd195c  vmovaps xmm14, [rsp+0xD0]
0000707649fd1965  vmovaps xmm15, [rsp+0xE0]
0000707649fd196e  add rsp, 0xF0
0000707649fd1975  pop r11
0000707649fd1977  pop r10
0000707649fd1979  pop r9
0000707649fd197b  pop r8
0000707649fd197d  pop rsi
0000707649fd197e  pop rdi
0000707649fd197f  pop rdx
0000707649fd1980  pop rcx
0000707649fd1981  pop rax
0000707649fd1982  add rsp, 0x08
0000707649fd1986  jmp 0x0000707649FCF96D
0000707649fd198b  sub rsp, 0x08
0000707649fd198f  push rax
0000707649fd1990  push rcx
0000707649fd1991  push rdx
0000707649fd1992  push rdi
0000707649fd1993  push rsi
0000707649fd1994  push r8
0000707649fd1996  push r9
0000707649fd1998  push r10
0000707649fd199a  push r11
0000707649fd199c  sub rsp, 0xF0
0000707649fd19a3  vmovaps [rsp], xmm0
0000707649fd19a8  vmovaps [rsp+0x10], xmm1
0000707649fd19ae  vmovaps [rsp+0x20], xmm2
0000707649fd19b4  vmovaps [rsp+0x30], xmm3
0000707649fd19ba  vmovaps [rsp+0x40], xmm4
0000707649fd19c0  vmovaps [rsp+0x50], xmm5
0000707649fd19c6  vmovaps [rsp+0x60], xmm6
0000707649fd19cc  vmovaps [rsp+0x70], xmm7
0000707649fd19d2  vmovaps [rsp+0x80], xmm8
0000707649fd19db  vmovaps [rsp+0x90], xmm9
0000707649fd19e4  vmovaps [rsp+0xA0], xmm10
0000707649fd19ed  vmovaps [rsp+0xB0], xmm11
0000707649fd19f6  vmovaps [rsp+0xC0], xmm12
0000707649fd19ff  vmovaps [rsp+0xD0], xmm13
0000707649fd1a08  vmovaps [rsp+0xE0], xmm14
0000707649fd1a11  sub rsp, 0x30
0000707649fd1a15  movaps [rsp], xmm15
0000707649fd1a1a  movaps [rsp+0x10], xmm14
0000707649fd1a20  movaps [rsp+0x20], xmm1
0000707649fd1a25  lea rdi, [rsp]
0000707649fd1a29  mov esi, 0x00
0000707649fd1a2e  mov rax, 0x59CB0B054530
0000707649fd1a38  call rax
0000707649fd1a3a  movaps xmm15, [rsp]
0000707649fd1a3f  add rsp, 0x30
0000707649fd1a43  vmovaps xmm0, [rsp]
0000707649fd1a48  vmovaps xmm1, [rsp+0x10]
0000707649fd1a4e  vmovaps xmm2, [rsp+0x20]
0000707649fd1a54  vmovaps xmm3, [rsp+0x30]
0000707649fd1a5a  vmovaps xmm4, [rsp+0x40]
0000707649fd1a60  vmovaps xmm5, [rsp+0x50]
0000707649fd1a66  vmovaps xmm6, [rsp+0x60]
0000707649fd1a6c  vmovaps xmm7, [rsp+0x70]
0000707649fd1a72  vmovaps xmm8, [rsp+0x80]
0000707649fd1a7b  vmovaps xmm9, [rsp+0x90]
0000707649fd1a84  vmovaps xmm10, [rsp+0xA0]
0000707649fd1a8d  vmovaps xmm11, [rsp+0xB0]
0000707649fd1a96  vmovaps xmm12, [rsp+0xC0]
0000707649fd1a9f  vmovaps xmm13, [rsp+0xD0]
0000707649fd1aa8  vmovaps xmm14, [rsp+0xE0]
0000707649fd1ab1  add rsp, 0xF0
0000707649fd1ab8  pop r11
0000707649fd1aba  pop r10
0000707649fd1abc  pop r9
0000707649fd1abe  pop r8
0000707649fd1ac0  pop rsi
0000707649fd1ac1  pop rdi
0000707649fd1ac2  pop rdx
0000707649fd1ac3  pop rcx
0000707649fd1ac4  pop rax
0000707649fd1ac5  add rsp, 0x08
0000707649fd1ac9  jmp 0x0000707649FCF9E7
0000707649fd1ace  call 0x0000707649DFF430
0000707649fd1ad3  jmp 0x0000707649FCF9F4
0000707649fd1ad8  sub rsp, 0x08
0000707649fd1adc  push rax
0000707649fd1add  push rcx
0000707649fd1ade  push rdx
0000707649fd1adf  push rdi
0000707649fd1ae0  push rsi
0000707649fd1ae1  push r8
0000707649fd1ae3  push r9
0000707649fd1ae5  push r10
0000707649fd1ae7  push r11
0000707649fd1ae9  sub rsp, 0xF0
0000707649fd1af0  vmovaps [rsp], xmm0
0000707649fd1af5  vmovaps [rsp+0x10], xmm1
0000707649fd1afb  vmovaps [rsp+0x20], xmm2
0000707649fd1b01  vmovaps [rsp+0x30], xmm3
0000707649fd1b07  vmovaps [rsp+0x40], xmm4
0000707649fd1b0d  vmovaps [rsp+0x50], xmm5
0000707649fd1b13  vmovaps [rsp+0x60], xmm6
0000707649fd1b19  vmovaps [rsp+0x70], xmm7
0000707649fd1b1f  vmovaps [rsp+0x80], xmm8
0000707649fd1b28  vmovaps [rsp+0x90], xmm9
0000707649fd1b31  vmovaps [rsp+0xA0], xmm10
0000707649fd1b3a  vmovaps [rsp+0xB0], xmm11
0000707649fd1b43  vmovaps [rsp+0xC0], xmm12
0000707649fd1b4c  vmovaps [rsp+0xD0], xmm13
0000707649fd1b55  vmovaps [rsp+0xE0], xmm15
0000707649fd1b5e  sub rsp, 0x30
0000707649fd1b62  movaps [rsp], xmm14
0000707649fd1b67  movaps [rsp+0x10], xmm13
0000707649fd1b6d  movaps [rsp+0x20], xmm1
0000707649fd1b72  lea rdi, [rsp]
0000707649fd1b76  mov esi, 0x00
0000707649fd1b7b  mov rax, 0x59CB0B054530
0000707649fd1b85  call rax
0000707649fd1b87  movaps xmm14, [rsp]
0000707649fd1b8c  add rsp, 0x30
0000707649fd1b90  vmovaps xmm0, [rsp]
0000707649fd1b95  vmovaps xmm1, [rsp+0x10]
0000707649fd1b9b  vmovaps xmm2, [rsp+0x20]
0000707649fd1ba1  vmovaps xmm3, [rsp+0x30]
0000707649fd1ba7  vmovaps xmm4, [rsp+0x40]
0000707649fd1bad  vmovaps xmm5, [rsp+0x50]
0000707649fd1bb3  vmovaps xmm6, [rsp+0x60]
0000707649fd1bb9  vmovaps xmm7, [rsp+0x70]
0000707649fd1bbf  vmovaps xmm8, [rsp+0x80]
0000707649fd1bc8  vmovaps xmm9, [rsp+0x90]
0000707649fd1bd1  vmovaps xmm10, [rsp+0xA0]
0000707649fd1bda  vmovaps xmm11, [rsp+0xB0]
0000707649fd1be3  vmovaps xmm12, [rsp+0xC0]
0000707649fd1bec  vmovaps xmm13, [rsp+0xD0]
0000707649fd1bf5  vmovaps xmm15, [rsp+0xE0]
0000707649fd1bfe  add rsp, 0xF0
0000707649fd1c05  pop r11
0000707649fd1c07  pop r10
0000707649fd1c09  pop r9
0000707649fd1c0b  pop r8
0000707649fd1c0d  pop rsi
0000707649fd1c0e  pop rdi
0000707649fd1c0f  pop rdx
0000707649fd1c10  pop rcx
0000707649fd1c11  pop rax
0000707649fd1c12  add rsp, 0x08
0000707649fd1c16  jmp 0x0000707649FCFAAF
0000707649fd1c1b  sub rsp, 0x08
0000707649fd1c1f  push rax
0000707649fd1c20  push rcx
0000707649fd1c21  push rdx
0000707649fd1c22  push rdi
0000707649fd1c23  push rsi
0000707649fd1c24  push r8
0000707649fd1c26  push r9
0000707649fd1c28  push r10
0000707649fd1c2a  push r11
0000707649fd1c2c  sub rsp, 0xF0
0000707649fd1c33  vmovaps [rsp], xmm0
0000707649fd1c38  vmovaps [rsp+0x10], xmm1
0000707649fd1c3e  vmovaps [rsp+0x20], xmm2
0000707649fd1c44  vmovaps [rsp+0x30], xmm3
0000707649fd1c4a  vmovaps [rsp+0x40], xmm4
0000707649fd1c50  vmovaps [rsp+0x50], xmm5
0000707649fd1c56  vmovaps [rsp+0x60], xmm6
0000707649fd1c5c  vmovaps [rsp+0x70], xmm7
0000707649fd1c62  vmovaps [rsp+0x80], xmm8
0000707649fd1c6b  vmovaps [rsp+0x90], xmm9
0000707649fd1c74  vmovaps [rsp+0xA0], xmm10
0000707649fd1c7d  vmovaps [rsp+0xB0], xmm11
0000707649fd1c86  vmovaps [rsp+0xC0], xmm12
0000707649fd1c8f  vmovaps [rsp+0xD0], xmm13
0000707649fd1c98  vmovaps [rsp+0xE0], xmm14
0000707649fd1ca1  sub rsp, 0x30
0000707649fd1ca5  movaps [rsp], xmm15
0000707649fd1caa  movaps [rsp+0x10], xmm13
0000707649fd1cb0  movaps [rsp+0x20], xmm1
0000707649fd1cb5  lea rdi, [rsp]
0000707649fd1cb9  mov esi, 0x00
0000707649fd1cbe  mov rax, 0x59CB0B054530
0000707649fd1cc8  call rax
0000707649fd1cca  movaps xmm15, [rsp]
0000707649fd1ccf  add rsp, 0x30
0000707649fd1cd3  vmovaps xmm0, [rsp]
0000707649fd1cd8  vmovaps xmm1, [rsp+0x10]
0000707649fd1cde  vmovaps xmm2, [rsp+0x20]
0000707649fd1ce4  vmovaps xmm3, [rsp+0x30]
0000707649fd1cea  vmovaps xmm4, [rsp+0x40]
0000707649fd1cf0  vmovaps xmm5, [rsp+0x50]
0000707649fd1cf6  vmovaps xmm6, [rsp+0x60]
0000707649fd1cfc  vmovaps xmm7, [rsp+0x70]
0000707649fd1d02  vmovaps xmm8, [rsp+0x80]
0000707649fd1d0b  vmovaps xmm9, [rsp+0x90]
0000707649fd1d14  vmovaps xmm10, [rsp+0xA0]
0000707649fd1d1d  vmovaps xmm11, [rsp+0xB0]
0000707649fd1d26  vmovaps xmm12, [rsp+0xC0]
0000707649fd1d2f  vmovaps xmm13, [rsp+0xD0]
0000707649fd1d38  vmovaps xmm14, [rsp+0xE0]
0000707649fd1d41  add rsp, 0xF0
0000707649fd1d48  pop r11
0000707649fd1d4a  pop r10
0000707649fd1d4c  pop r9
0000707649fd1d4e  pop r8
0000707649fd1d50  pop rsi
0000707649fd1d51  pop rdi
0000707649fd1d52  pop rdx
0000707649fd1d53  pop rcx
0000707649fd1d54  pop rax
0000707649fd1d55  add rsp, 0x08
0000707649fd1d59  jmp 0x0000707649FCFAEB
0000707649fd1d5e  call 0x0000707649DFF430
0000707649fd1d63  jmp 0x0000707649FCFAF8
0000707649fd1d68  sub rsp, 0x08
0000707649fd1d6c  push rax
0000707649fd1d6d  push rcx
0000707649fd1d6e  push rdx
0000707649fd1d6f  push rdi
0000707649fd1d70  push rsi
0000707649fd1d71  push r8
0000707649fd1d73  push r9
0000707649fd1d75  push r10
0000707649fd1d77  push r11
0000707649fd1d79  sub rsp, 0xF0
0000707649fd1d80  vmovaps [rsp], xmm0
0000707649fd1d85  vmovaps [rsp+0x10], xmm1
0000707649fd1d8b  vmovaps [rsp+0x20], xmm2
0000707649fd1d91  vmovaps [rsp+0x30], xmm3
0000707649fd1d97  vmovaps [rsp+0x40], xmm4
0000707649fd1d9d  vmovaps [rsp+0x50], xmm5
0000707649fd1da3  vmovaps [rsp+0x60], xmm6
0000707649fd1da9  vmovaps [rsp+0x70], xmm7
0000707649fd1daf  vmovaps [rsp+0x80], xmm8
0000707649fd1db8  vmovaps [rsp+0x90], xmm9
0000707649fd1dc1  vmovaps [rsp+0xA0], xmm10
0000707649fd1dca  vmovaps [rsp+0xB0], xmm11
0000707649fd1dd3  vmovaps [rsp+0xC0], xmm12
0000707649fd1ddc  vmovaps [rsp+0xD0], xmm13
0000707649fd1de5  vmovaps [rsp+0xE0], xmm15
0000707649fd1dee  sub rsp, 0x30
0000707649fd1df2  movaps [rsp], xmm14
0000707649fd1df7  movaps [rsp+0x10], xmm13
0000707649fd1dfd  movaps [rsp+0x20], xmm2
0000707649fd1e02  lea rdi, [rsp]
0000707649fd1e06  mov esi, 0x00
0000707649fd1e0b  mov rax, 0x59CB0B054530
0000707649fd1e15  call rax
0000707649fd1e17  movaps xmm14, [rsp]
0000707649fd1e1c  add rsp, 0x30
0000707649fd1e20  vmovaps xmm0, [rsp]
0000707649fd1e25  vmovaps xmm1, [rsp+0x10]
0000707649fd1e2b  vmovaps xmm2, [rsp+0x20]
0000707649fd1e31  vmovaps xmm3, [rsp+0x30]
0000707649fd1e37  vmovaps xmm4, [rsp+0x40]
0000707649fd1e3d  vmovaps xmm5, [rsp+0x50]
0000707649fd1e43  vmovaps xmm6, [rsp+0x60]
0000707649fd1e49  vmovaps xmm7, [rsp+0x70]
0000707649fd1e4f  vmovaps xmm8, [rsp+0x80]
0000707649fd1e58  vmovaps xmm9, [rsp+0x90]
0000707649fd1e61  vmovaps xmm10, [rsp+0xA0]
0000707649fd1e6a  vmovaps xmm11, [rsp+0xB0]
0000707649fd1e73  vmovaps xmm12, [rsp+0xC0]
0000707649fd1e7c  vmovaps xmm13, [rsp+0xD0]
0000707649fd1e85  vmovaps xmm15, [rsp+0xE0]
0000707649fd1e8e  add rsp, 0xF0
0000707649fd1e95  pop r11
0000707649fd1e97  pop r10
0000707649fd1e99  pop r9
0000707649fd1e9b  pop r8
0000707649fd1e9d  pop rsi
0000707649fd1e9e  pop rdi
0000707649fd1e9f  pop rdx
0000707649fd1ea0  pop rcx
0000707649fd1ea1  pop rax
0000707649fd1ea2  add rsp, 0x08
0000707649fd1ea6  jmp 0x0000707649FCFB24
0000707649fd1eab  sub rsp, 0x08
0000707649fd1eaf  push rax
0000707649fd1eb0  push rcx
0000707649fd1eb1  push rdx
0000707649fd1eb2  push rdi
0000707649fd1eb3  push rsi
0000707649fd1eb4  push r8
0000707649fd1eb6  push r9
0000707649fd1eb8  push r10
0000707649fd1eba  push r11
0000707649fd1ebc  sub rsp, 0xF0
0000707649fd1ec3  vmovaps [rsp], xmm0
0000707649fd1ec8  vmovaps [rsp+0x10], xmm2
0000707649fd1ece  vmovaps [rsp+0x20], xmm3
0000707649fd1ed4  vmovaps [rsp+0x30], xmm4
0000707649fd1eda  vmovaps [rsp+0x40], xmm5
0000707649fd1ee0  vmovaps [rsp+0x50], xmm6
0000707649fd1ee6  vmovaps [rsp+0x60], xmm7
0000707649fd1eec  vmovaps [rsp+0x70], xmm8
0000707649fd1ef2  vmovaps [rsp+0x80], xmm9
0000707649fd1efb  vmovaps [rsp+0x90], xmm10
0000707649fd1f04  vmovaps [rsp+0xA0], xmm11
0000707649fd1f0d  vmovaps [rsp+0xB0], xmm12
0000707649fd1f16  vmovaps [rsp+0xC0], xmm13
0000707649fd1f1f  vmovaps [rsp+0xD0], xmm14
0000707649fd1f28  vmovaps [rsp+0xE0], xmm15
0000707649fd1f31  sub rsp, 0x30
0000707649fd1f35  movaps [rsp], xmm1
0000707649fd1f39  movaps [rsp+0x10], xmm13
0000707649fd1f3f  movaps [rsp+0x20], xmm2
0000707649fd1f44  lea rdi, [rsp]
0000707649fd1f48  mov esi, 0x00
0000707649fd1f4d  mov rax, 0x59CB0B054530
0000707649fd1f57  call rax
0000707649fd1f59  movaps xmm1, [rsp]
0000707649fd1f5d  add rsp, 0x30
0000707649fd1f61  vmovaps xmm0, [rsp]
0000707649fd1f66  vmovaps xmm2, [rsp+0x10]
0000707649fd1f6c  vmovaps xmm3, [rsp+0x20]
0000707649fd1f72  vmovaps xmm4, [rsp+0x30]
0000707649fd1f78  vmovaps xmm5, [rsp+0x40]
0000707649fd1f7e  vmovaps xmm6, [rsp+0x50]
0000707649fd1f84  vmovaps xmm7, [rsp+0x60]
0000707649fd1f8a  vmovaps xmm8, [rsp+0x70]
0000707649fd1f90  vmovaps xmm9, [rsp+0x80]
0000707649fd1f99  vmovaps xmm10, [rsp+0x90]
0000707649fd1fa2  vmovaps xmm11, [rsp+0xA0]
0000707649fd1fab  vmovaps xmm12, [rsp+0xB0]
0000707649fd1fb4  vmovaps xmm13, [rsp+0xC0]
0000707649fd1fbd  vmovaps xmm14, [rsp+0xD0]
0000707649fd1fc6  vmovaps xmm15, [rsp+0xE0]
0000707649fd1fcf  add rsp, 0xF0
0000707649fd1fd6  pop r11
0000707649fd1fd8  pop r10
0000707649fd1fda  pop r9
0000707649fd1fdc  pop r8
0000707649fd1fde  pop rsi
0000707649fd1fdf  pop rdi
0000707649fd1fe0  pop rdx
0000707649fd1fe1  pop rcx
0000707649fd1fe2  pop rax
0000707649fd1fe3  add rsp, 0x08
0000707649fd1fe7  jmp 0x0000707649FCFB52
0000707649fd1fec  sub rsp, 0x08
0000707649fd1ff0  push rax
0000707649fd1ff1  push rcx
0000707649fd1ff2  push rdx
0000707649fd1ff3  push rdi
0000707649fd1ff4  push rsi
0000707649fd1ff5  push r8
0000707649fd1ff7  push r9
0000707649fd1ff9  push r10
0000707649fd1ffb  push r11
0000707649fd1ffd  sub rsp, 0xF0
0000707649fd2004  vmovaps [rsp], xmm0
0000707649fd2009  vmovaps [rsp+0x10], xmm1
0000707649fd200f  vmovaps [rsp+0x20], xmm3
0000707649fd2015  vmovaps [rsp+0x30], xmm4
0000707649fd201b  vmovaps [rsp+0x40], xmm5
0000707649fd2021  vmovaps [rsp+0x50], xmm6
0000707649fd2027  vmovaps [rsp+0x60], xmm7
0000707649fd202d  vmovaps [rsp+0x70], xmm8
0000707649fd2033  vmovaps [rsp+0x80], xmm9
0000707649fd203c  vmovaps [rsp+0x90], xmm10
0000707649fd2045  vmovaps [rsp+0xA0], xmm11
0000707649fd204e  vmovaps [rsp+0xB0], xmm12
0000707649fd2057  vmovaps [rsp+0xC0], xmm13
0000707649fd2060  vmovaps [rsp+0xD0], xmm14
0000707649fd2069  vmovaps [rsp+0xE0], xmm15
0000707649fd2072  sub rsp, 0x30
0000707649fd2076  movaps [rsp], xmm2
0000707649fd207a  movaps [rsp+0x10], xmm1
0000707649fd207f  movaps [rsp+0x20], xmm13
0000707649fd2085  lea rdi, [rsp]
0000707649fd2089  mov esi, 0x00
0000707649fd208e  mov rax, 0x59CB0B054530
0000707649fd2098  call rax
0000707649fd209a  movaps xmm2, [rsp]
0000707649fd209e  add rsp, 0x30
0000707649fd20a2  vmovaps xmm0, [rsp]
0000707649fd20a7  vmovaps xmm1, [rsp+0x10]
0000707649fd20ad  vmovaps xmm3, [rsp+0x20]
0000707649fd20b3  vmovaps xmm4, [rsp+0x30]
0000707649fd20b9  vmovaps xmm5, [rsp+0x40]
0000707649fd20bf  vmovaps xmm6, [rsp+0x50]
0000707649fd20c5  vmovaps xmm7, [rsp+0x60]
0000707649fd20cb  vmovaps xmm8, [rsp+0x70]
0000707649fd20d1  vmovaps xmm9, [rsp+0x80]
0000707649fd20da  vmovaps xmm10, [rsp+0x90]
0000707649fd20e3  vmovaps xmm11, [rsp+0xA0]
0000707649fd20ec  vmovaps xmm12, [rsp+0xB0]
0000707649fd20f5  vmovaps xmm13, [rsp+0xC0]
0000707649fd20fe  vmovaps xmm14, [rsp+0xD0]
0000707649fd2107  vmovaps xmm15, [rsp+0xE0]
0000707649fd2110  add rsp, 0xF0
0000707649fd2117  pop r11
0000707649fd2119  pop r10
0000707649fd211b  pop r9
0000707649fd211d  pop r8
0000707649fd211f  pop rsi
0000707649fd2120  pop rdi
0000707649fd2121  pop rdx
0000707649fd2122  pop rcx
0000707649fd2123  pop rax
0000707649fd2124  add rsp, 0x08
0000707649fd2128  jmp 0x0000707649FCFBAB
0000707649fd212d  call 0x0000707649DFF430
0000707649fd2132  jmp 0x0000707649FCFBB8
0000707649fd2137  sub rsp, 0x08
0000707649fd213b  push rax
0000707649fd213c  push rcx
0000707649fd213d  push rdx
0000707649fd213e  push rdi
0000707649fd213f  push rsi
0000707649fd2140  push r8
0000707649fd2142  push r9
0000707649fd2144  push r10
0000707649fd2146  push r11
0000707649fd2148  sub rsp, 0xF0
0000707649fd214f  vmovaps [rsp], xmm0
0000707649fd2154  vmovaps [rsp+0x10], xmm1
0000707649fd215a  vmovaps [rsp+0x20], xmm2
0000707649fd2160  vmovaps [rsp+0x30], xmm3
0000707649fd2166  vmovaps [rsp+0x40], xmm4
0000707649fd216c  vmovaps [rsp+0x50], xmm5
0000707649fd2172  vmovaps [rsp+0x60], xmm6
0000707649fd2178  vmovaps [rsp+0x70], xmm7
0000707649fd217e  vmovaps [rsp+0x80], xmm8
0000707649fd2187  vmovaps [rsp+0x90], xmm9
0000707649fd2190  vmovaps [rsp+0xA0], xmm10
0000707649fd2199  vmovaps [rsp+0xB0], xmm11
0000707649fd21a2  vmovaps [rsp+0xC0], xmm12
0000707649fd21ab  vmovaps [rsp+0xD0], xmm13
0000707649fd21b4  vmovaps [rsp+0xE0], xmm14
0000707649fd21bd  sub rsp, 0x30
0000707649fd21c1  movaps [rsp], xmm15
0000707649fd21c6  movaps [rsp+0x10], xmm13
0000707649fd21cc  movaps [rsp+0x20], xmm1
0000707649fd21d1  lea rdi, [rsp]
0000707649fd21d5  mov esi, 0x00
0000707649fd21da  mov rax, 0x59CB0B054530
0000707649fd21e4  call rax
0000707649fd21e6  movaps xmm15, [rsp]
0000707649fd21eb  add rsp, 0x30
0000707649fd21ef  vmovaps xmm0, [rsp]
0000707649fd21f4  vmovaps xmm1, [rsp+0x10]
0000707649fd21fa  vmovaps xmm2, [rsp+0x20]
0000707649fd2200  vmovaps xmm3, [rsp+0x30]
0000707649fd2206  vmovaps xmm4, [rsp+0x40]
0000707649fd220c  vmovaps xmm5, [rsp+0x50]
0000707649fd2212  vmovaps xmm6, [rsp+0x60]
0000707649fd2218  vmovaps xmm7, [rsp+0x70]
0000707649fd221e  vmovaps xmm8, [rsp+0x80]
0000707649fd2227  vmovaps xmm9, [rsp+0x90]
0000707649fd2230  vmovaps xmm10, [rsp+0xA0]
0000707649fd2239  vmovaps xmm11, [rsp+0xB0]
0000707649fd2242  vmovaps xmm12, [rsp+0xC0]
0000707649fd224b  vmovaps xmm13, [rsp+0xD0]
0000707649fd2254  vmovaps xmm14, [rsp+0xE0]
0000707649fd225d  add rsp, 0xF0
0000707649fd2264  pop r11
0000707649fd2266  pop r10
0000707649fd2268  pop r9
0000707649fd226a  pop r8
0000707649fd226c  pop rsi
0000707649fd226d  pop rdi
0000707649fd226e  pop rdx
0000707649fd226f  pop rcx
0000707649fd2270  pop rax
0000707649fd2271  add rsp, 0x08
0000707649fd2275  jmp 0x0000707649FCFBF7
0000707649fd227a  sub rsp, 0x08
0000707649fd227e  push rax
0000707649fd227f  push rcx
0000707649fd2280  push rdx
0000707649fd2281  push rdi
0000707649fd2282  push rsi
0000707649fd2283  push r8
0000707649fd2285  push r9
0000707649fd2287  push r10
0000707649fd2289  push r11
0000707649fd228b  sub rsp, 0xF0
0000707649fd2292  vmovaps [rsp], xmm0
0000707649fd2297  vmovaps [rsp+0x10], xmm1
0000707649fd229d  vmovaps [rsp+0x20], xmm2
0000707649fd22a3  vmovaps [rsp+0x30], xmm3
0000707649fd22a9  vmovaps [rsp+0x40], xmm4
0000707649fd22af  vmovaps [rsp+0x50], xmm5
0000707649fd22b5  vmovaps [rsp+0x60], xmm6
0000707649fd22bb  vmovaps [rsp+0x70], xmm7
0000707649fd22c1  vmovaps [rsp+0x80], xmm8
0000707649fd22ca  vmovaps [rsp+0x90], xmm9
0000707649fd22d3  vmovaps [rsp+0xA0], xmm10
0000707649fd22dc  vmovaps [rsp+0xB0], xmm11
0000707649fd22e5  vmovaps [rsp+0xC0], xmm12
0000707649fd22ee  vmovaps [rsp+0xD0], xmm13
0000707649fd22f7  vmovaps [rsp+0xE0], xmm15
0000707649fd2300  sub rsp, 0x30
0000707649fd2304  movaps [rsp], xmm14
0000707649fd2309  movaps [rsp+0x10], xmm11
0000707649fd230f  movaps [rsp+0x20], xmm1
0000707649fd2314  lea rdi, [rsp]
0000707649fd2318  mov esi, 0x00
0000707649fd231d  mov rax, 0x59CB0B054530
0000707649fd2327  call rax
0000707649fd2329  movaps xmm14, [rsp]
0000707649fd232e  add rsp, 0x30
0000707649fd2332  vmovaps xmm0, [rsp]
0000707649fd2337  vmovaps xmm1, [rsp+0x10]
0000707649fd233d  vmovaps xmm2, [rsp+0x20]
0000707649fd2343  vmovaps xmm3, [rsp+0x30]
0000707649fd2349  vmovaps xmm4, [rsp+0x40]
0000707649fd234f  vmovaps xmm5, [rsp+0x50]
0000707649fd2355  vmovaps xmm6, [rsp+0x60]
0000707649fd235b  vmovaps xmm7, [rsp+0x70]
0000707649fd2361  vmovaps xmm8, [rsp+0x80]
0000707649fd236a  vmovaps xmm9, [rsp+0x90]
0000707649fd2373  vmovaps xmm10, [rsp+0xA0]
0000707649fd237c  vmovaps xmm11, [rsp+0xB0]
0000707649fd2385  vmovaps xmm12, [rsp+0xC0]
0000707649fd238e  vmovaps xmm13, [rsp+0xD0]
0000707649fd2397  vmovaps xmm15, [rsp+0xE0]
0000707649fd23a0  add rsp, 0xF0
0000707649fd23a7  pop r11
0000707649fd23a9  pop r10
0000707649fd23ab  pop r9
0000707649fd23ad  pop r8
0000707649fd23af  pop rsi
0000707649fd23b0  pop rdi
0000707649fd23b1  pop rdx
0000707649fd23b2  pop rcx
0000707649fd23b3  pop rax
0000707649fd23b4  add rsp, 0x08
0000707649fd23b8  jmp 0x0000707649FCFC21
0000707649fd23bd  sub rsp, 0x08
0000707649fd23c1  push rax
0000707649fd23c2  push rcx
0000707649fd23c3  push rdx
0000707649fd23c4  push rdi
0000707649fd23c5  push rsi
0000707649fd23c6  push r8
0000707649fd23c8  push r9
0000707649fd23ca  push r10
0000707649fd23cc  push r11
0000707649fd23ce  sub rsp, 0xF0
0000707649fd23d5  vmovaps [rsp], xmm0
0000707649fd23da  vmovaps [rsp+0x10], xmm1
0000707649fd23e0  vmovaps [rsp+0x20], xmm2
0000707649fd23e6  vmovaps [rsp+0x30], xmm3
0000707649fd23ec  vmovaps [rsp+0x40], xmm4
0000707649fd23f2  vmovaps [rsp+0x50], xmm5
0000707649fd23f8  vmovaps [rsp+0x60], xmm6
0000707649fd23fe  vmovaps [rsp+0x70], xmm7
0000707649fd2404  vmovaps [rsp+0x80], xmm8
0000707649fd240d  vmovaps [rsp+0x90], xmm9
0000707649fd2416  vmovaps [rsp+0xA0], xmm10
0000707649fd241f  vmovaps [rsp+0xB0], xmm11
0000707649fd2428  vmovaps [rsp+0xC0], xmm12
0000707649fd2431  vmovaps [rsp+0xD0], xmm14
0000707649fd243a  vmovaps [rsp+0xE0], xmm15
0000707649fd2443  sub rsp, 0x30
0000707649fd2447  movaps [rsp], xmm13
0000707649fd244c  movaps [rsp+0x10], xmm11
0000707649fd2452  movaps [rsp+0x20], xmm1
0000707649fd2457  lea rdi, [rsp]
0000707649fd245b  mov esi, 0x00
0000707649fd2460  mov rax, 0x59CB0B054530
0000707649fd246a  call rax
0000707649fd246c  movaps xmm13, [rsp]
0000707649fd2471  add rsp, 0x30
0000707649fd2475  vmovaps xmm0, [rsp]
0000707649fd247a  vmovaps xmm1, [rsp+0x10]
0000707649fd2480  vmovaps xmm2, [rsp+0x20]
0000707649fd2486  vmovaps xmm3, [rsp+0x30]
0000707649fd248c  vmovaps xmm4, [rsp+0x40]
0000707649fd2492  vmovaps xmm5, [rsp+0x50]
0000707649fd2498  vmovaps xmm6, [rsp+0x60]
0000707649fd249e  vmovaps xmm7, [rsp+0x70]
0000707649fd24a4  vmovaps xmm8, [rsp+0x80]
0000707649fd24ad  vmovaps xmm9, [rsp+0x90]
0000707649fd24b6  vmovaps xmm10, [rsp+0xA0]
0000707649fd24bf  vmovaps xmm11, [rsp+0xB0]
0000707649fd24c8  vmovaps xmm12, [rsp+0xC0]
0000707649fd24d1  vmovaps xmm14, [rsp+0xD0]
0000707649fd24da  vmovaps xmm15, [rsp+0xE0]
0000707649fd24e3  add rsp, 0xF0
0000707649fd24ea  pop r11
0000707649fd24ec  pop r10
0000707649fd24ee  pop r9
0000707649fd24f0  pop r8
0000707649fd24f2  pop rsi
0000707649fd24f3  pop rdi
0000707649fd24f4  pop rdx
0000707649fd24f5  pop rcx
0000707649fd24f6  pop rax
0000707649fd24f7  add rsp, 0x08
0000707649fd24fb  jmp 0x0000707649FCFC76
0000707649fd2500  call 0x0000707649DFF430
0000707649fd2505  jmp 0x0000707649FCFC83
0000707649fd250a  sub rsp, 0x08
0000707649fd250e  push rax
0000707649fd250f  push rcx
0000707649fd2510  push rdx
0000707649fd2511  push rdi
0000707649fd2512  push rsi
0000707649fd2513  push r8
0000707649fd2515  push r9
0000707649fd2517  push r10
0000707649fd2519  push r11
0000707649fd251b  sub rsp, 0xF0
0000707649fd2522  vmovaps [rsp], xmm0
0000707649fd2527  vmovaps [rsp+0x10], xmm1
0000707649fd252d  vmovaps [rsp+0x20], xmm2
0000707649fd2533  vmovaps [rsp+0x30], xmm3
0000707649fd2539  vmovaps [rsp+0x40], xmm4
0000707649fd253f  vmovaps [rsp+0x50], xmm5
0000707649fd2545  vmovaps [rsp+0x60], xmm6
0000707649fd254b  vmovaps [rsp+0x70], xmm7
0000707649fd2551  vmovaps [rsp+0x80], xmm8
0000707649fd255a  vmovaps [rsp+0x90], xmm9
0000707649fd2563  vmovaps [rsp+0xA0], xmm10
0000707649fd256c  vmovaps [rsp+0xB0], xmm11
0000707649fd2575  vmovaps [rsp+0xC0], xmm12
0000707649fd257e  vmovaps [rsp+0xD0], xmm13
0000707649fd2587  vmovaps [rsp+0xE0], xmm14
0000707649fd2590  sub rsp, 0x30
0000707649fd2594  movaps [rsp], xmm15
0000707649fd2599  movaps [rsp+0x10], xmm11
0000707649fd259f  movaps [rsp+0x20], xmm1
0000707649fd25a4  lea rdi, [rsp]
0000707649fd25a8  mov esi, 0x00
0000707649fd25ad  mov rax, 0x59CB0B054530
0000707649fd25b7  call rax
0000707649fd25b9  movaps xmm15, [rsp]
0000707649fd25be  add rsp, 0x30
0000707649fd25c2  vmovaps xmm0, [rsp]
0000707649fd25c7  vmovaps xmm1, [rsp+0x10]
0000707649fd25cd  vmovaps xmm2, [rsp+0x20]
0000707649fd25d3  vmovaps xmm3, [rsp+0x30]
0000707649fd25d9  vmovaps xmm4, [rsp+0x40]
0000707649fd25df  vmovaps xmm5, [rsp+0x50]
0000707649fd25e5  vmovaps xmm6, [rsp+0x60]
0000707649fd25eb  vmovaps xmm7, [rsp+0x70]
0000707649fd25f1  vmovaps xmm8, [rsp+0x80]
0000707649fd25fa  vmovaps xmm9, [rsp+0x90]
0000707649fd2603  vmovaps xmm10, [rsp+0xA0]
0000707649fd260c  vmovaps xmm11, [rsp+0xB0]
0000707649fd2615  vmovaps xmm12, [rsp+0xC0]
0000707649fd261e  vmovaps xmm13, [rsp+0xD0]
0000707649fd2627  vmovaps xmm14, [rsp+0xE0]
0000707649fd2630  add rsp, 0xF0
0000707649fd2637  pop r11
0000707649fd2639  pop r10
0000707649fd263b  pop r9
0000707649fd263d  pop r8
0000707649fd263f  pop rsi
0000707649fd2640  pop rdi
0000707649fd2641  pop rdx
0000707649fd2642  pop rcx
0000707649fd2643  pop rax
0000707649fd2644  add rsp, 0x08
0000707649fd2648  jmp 0x0000707649FCFCBC
0000707649fd264d  sub rsp, 0x08
0000707649fd2651  push rax
0000707649fd2652  push rcx
0000707649fd2653  push rdx
0000707649fd2654  push rdi
0000707649fd2655  push rsi
0000707649fd2656  push r8
0000707649fd2658  push r9
0000707649fd265a  push r10
0000707649fd265c  push r11
0000707649fd265e  sub rsp, 0xF0
0000707649fd2665  vmovaps [rsp], xmm0
0000707649fd266a  vmovaps [rsp+0x10], xmm1
0000707649fd2670  vmovaps [rsp+0x20], xmm2
0000707649fd2676  vmovaps [rsp+0x30], xmm3
0000707649fd267c  vmovaps [rsp+0x40], xmm4
0000707649fd2682  vmovaps [rsp+0x50], xmm5
0000707649fd2688  vmovaps [rsp+0x60], xmm6
0000707649fd268e  vmovaps [rsp+0x70], xmm7
0000707649fd2694  vmovaps [rsp+0x80], xmm8
0000707649fd269d  vmovaps [rsp+0x90], xmm9
0000707649fd26a6  vmovaps [rsp+0xA0], xmm10
0000707649fd26af  vmovaps [rsp+0xB0], xmm12
0000707649fd26b8  vmovaps [rsp+0xC0], xmm13
0000707649fd26c1  vmovaps [rsp+0xD0], xmm14
0000707649fd26ca  vmovaps [rsp+0xE0], xmm15
0000707649fd26d3  sub rsp, 0x30
0000707649fd26d7  movaps [rsp], xmm11
0000707649fd26dc  movaps [rsp+0x10], xmm6
0000707649fd26e1  movaps [rsp+0x20], xmm14
0000707649fd26e7  lea rdi, [rsp]
0000707649fd26eb  mov esi, 0x00
0000707649fd26f0  mov rax, 0x59CB0B054530
0000707649fd26fa  call rax
0000707649fd26fc  movaps xmm11, [rsp]
0000707649fd2701  add rsp, 0x30
0000707649fd2705  vmovaps xmm0, [rsp]
0000707649fd270a  vmovaps xmm1, [rsp+0x10]
0000707649fd2710  vmovaps xmm2, [rsp+0x20]
0000707649fd2716  vmovaps xmm3, [rsp+0x30]
0000707649fd271c  vmovaps xmm4, [rsp+0x40]
0000707649fd2722  vmovaps xmm5, [rsp+0x50]
0000707649fd2728  vmovaps xmm6, [rsp+0x60]
0000707649fd272e  vmovaps xmm7, [rsp+0x70]
0000707649fd2734  vmovaps xmm8, [rsp+0x80]
0000707649fd273d  vmovaps xmm9, [rsp+0x90]
0000707649fd2746  vmovaps xmm10, [rsp+0xA0]
0000707649fd274f  vmovaps xmm12, [rsp+0xB0]
0000707649fd2758  vmovaps xmm13, [rsp+0xC0]
0000707649fd2761  vmovaps xmm14, [rsp+0xD0]
0000707649fd276a  vmovaps xmm15, [rsp+0xE0]
0000707649fd2773  add rsp, 0xF0
0000707649fd277a  pop r11
0000707649fd277c  pop r10
0000707649fd277e  pop r9
0000707649fd2780  pop r8
0000707649fd2782  pop rsi
0000707649fd2783  pop rdi
0000707649fd2784  pop rdx
0000707649fd2785  pop rcx
0000707649fd2786  pop rax
0000707649fd2787  add rsp, 0x08
0000707649fd278b  jmp 0x0000707649FCFD34
0000707649fd2790  call 0x0000707649DFF430
0000707649fd2795  jmp 0x0000707649FCFD3E
0000707649fd279a  sub rsp, 0x08
0000707649fd279e  push rax
0000707649fd279f  push rcx
0000707649fd27a0  push rdx
0000707649fd27a1  push rdi
0000707649fd27a2  push rsi
0000707649fd27a3  push r8
0000707649fd27a5  push r9
0000707649fd27a7  push r10
0000707649fd27a9  push r11
0000707649fd27ab  sub rsp, 0xF0
0000707649fd27b2  vmovaps [rsp], xmm0
0000707649fd27b7  vmovaps [rsp+0x10], xmm1
0000707649fd27bd  vmovaps [rsp+0x20], xmm2
0000707649fd27c3  vmovaps [rsp+0x30], xmm3
0000707649fd27c9  vmovaps [rsp+0x40], xmm4
0000707649fd27cf  vmovaps [rsp+0x50], xmm5
0000707649fd27d5  vmovaps [rsp+0x60], xmm6
0000707649fd27db  vmovaps [rsp+0x70], xmm7
0000707649fd27e1  vmovaps [rsp+0x80], xmm8
0000707649fd27ea  vmovaps [rsp+0x90], xmm9
0000707649fd27f3  vmovaps [rsp+0xA0], xmm10
0000707649fd27fc  vmovaps [rsp+0xB0], xmm11
0000707649fd2805  vmovaps [rsp+0xC0], xmm12
0000707649fd280e  vmovaps [rsp+0xD0], xmm13
0000707649fd2817  vmovaps [rsp+0xE0], xmm15
0000707649fd2820  sub rsp, 0x30
0000707649fd2824  movaps [rsp], xmm14
0000707649fd2829  movaps [rsp+0x10], xmm6
0000707649fd282e  movaps [rsp+0x20], xmm2
0000707649fd2833  lea rdi, [rsp]
0000707649fd2837  mov esi, 0x00
0000707649fd283c  mov rax, 0x59CB0B054530
0000707649fd2846  call rax
0000707649fd2848  movaps xmm14, [rsp]
0000707649fd284d  add rsp, 0x30
0000707649fd2851  vmovaps xmm0, [rsp]
0000707649fd2856  vmovaps xmm1, [rsp+0x10]
0000707649fd285c  vmovaps xmm2, [rsp+0x20]
0000707649fd2862  vmovaps xmm3, [rsp+0x30]
0000707649fd2868  vmovaps xmm4, [rsp+0x40]
0000707649fd286e  vmovaps xmm5, [rsp+0x50]
0000707649fd2874  vmovaps xmm6, [rsp+0x60]
0000707649fd287a  vmovaps xmm7, [rsp+0x70]
0000707649fd2880  vmovaps xmm8, [rsp+0x80]
0000707649fd2889  vmovaps xmm9, [rsp+0x90]
0000707649fd2892  vmovaps xmm10, [rsp+0xA0]
0000707649fd289b  vmovaps xmm11, [rsp+0xB0]
0000707649fd28a4  vmovaps xmm12, [rsp+0xC0]
0000707649fd28ad  vmovaps xmm13, [rsp+0xD0]
0000707649fd28b6  vmovaps xmm15, [rsp+0xE0]
0000707649fd28bf  add rsp, 0xF0
0000707649fd28c6  pop r11
0000707649fd28c8  pop r10
0000707649fd28ca  pop r9
0000707649fd28cc  pop r8
0000707649fd28ce  pop rsi
0000707649fd28cf  pop rdi
0000707649fd28d0  pop rdx
0000707649fd28d1  pop rcx
0000707649fd28d2  pop rax
0000707649fd28d3  add rsp, 0x08
0000707649fd28d7  jmp 0x0000707649FCFD72
0000707649fd28dc  sub rsp, 0x08
0000707649fd28e0  push rax
0000707649fd28e1  push rcx
0000707649fd28e2  push rdx
0000707649fd28e3  push rdi
0000707649fd28e4  push rsi
0000707649fd28e5  push r8
0000707649fd28e7  push r9
0000707649fd28e9  push r10
0000707649fd28eb  push r11
0000707649fd28ed  sub rsp, 0xF0
0000707649fd28f4  vmovaps [rsp], xmm0
0000707649fd28f9  vmovaps [rsp+0x10], xmm1
0000707649fd28ff  vmovaps [rsp+0x20], xmm2
0000707649fd2905  vmovaps [rsp+0x30], xmm3
0000707649fd290b  vmovaps [rsp+0x40], xmm4
0000707649fd2911  vmovaps [rsp+0x50], xmm5
0000707649fd2917  vmovaps [rsp+0x60], xmm7
0000707649fd291d  vmovaps [rsp+0x70], xmm8
0000707649fd2923  vmovaps [rsp+0x80], xmm9
0000707649fd292c  vmovaps [rsp+0x90], xmm10
0000707649fd2935  vmovaps [rsp+0xA0], xmm11
0000707649fd293e  vmovaps [rsp+0xB0], xmm12
0000707649fd2947  vmovaps [rsp+0xC0], xmm13
0000707649fd2950  vmovaps [rsp+0xD0], xmm14
0000707649fd2959  vmovaps [rsp+0xE0], xmm15
0000707649fd2962  sub rsp, 0x30
0000707649fd2966  movaps [rsp], xmm6
0000707649fd296a  movaps [rsp+0x10], xmm5
0000707649fd296f  movaps [rsp+0x20], xmm1
0000707649fd2974  lea rdi, [rsp]
0000707649fd2978  mov esi, 0x00
0000707649fd297d  mov rax, 0x59CB0B054530
0000707649fd2987  call rax
0000707649fd2989  movaps xmm6, [rsp]
0000707649fd298d  add rsp, 0x30
0000707649fd2991  vmovaps xmm0, [rsp]
0000707649fd2996  vmovaps xmm1, [rsp+0x10]
0000707649fd299c  vmovaps xmm2, [rsp+0x20]
0000707649fd29a2  vmovaps xmm3, [rsp+0x30]
0000707649fd29a8  vmovaps xmm4, [rsp+0x40]
0000707649fd29ae  vmovaps xmm5, [rsp+0x50]
0000707649fd29b4  vmovaps xmm7, [rsp+0x60]
0000707649fd29ba  vmovaps xmm8, [rsp+0x70]
0000707649fd29c0  vmovaps xmm9, [rsp+0x80]
0000707649fd29c9  vmovaps xmm10, [rsp+0x90]
0000707649fd29d2  vmovaps xmm11, [rsp+0xA0]
0000707649fd29db  vmovaps xmm12, [rsp+0xB0]
0000707649fd29e4  vmovaps xmm13, [rsp+0xC0]
0000707649fd29ed  vmovaps xmm14, [rsp+0xD0]
0000707649fd29f6  vmovaps xmm15, [rsp+0xE0]
0000707649fd29ff  add rsp, 0xF0
0000707649fd2a06  pop r11
0000707649fd2a08  pop r10
0000707649fd2a0a  pop r9
0000707649fd2a0c  pop r8
0000707649fd2a0e  pop rsi
0000707649fd2a0f  pop rdi
0000707649fd2a10  pop rdx
0000707649fd2a11  pop rcx
0000707649fd2a12  pop rax
0000707649fd2a13  add rsp, 0x08
0000707649fd2a17  jmp 0x0000707649FCFD98
0000707649fd2a1c  sub rsp, 0x08
0000707649fd2a20  push rax
0000707649fd2a21  push rcx
0000707649fd2a22  push rdx
0000707649fd2a23  push rdi
0000707649fd2a24  push rsi
0000707649fd2a25  push r8
0000707649fd2a27  push r9
0000707649fd2a29  push r10
0000707649fd2a2b  push r11
0000707649fd2a2d  sub rsp, 0xF0
0000707649fd2a34  vmovaps [rsp], xmm0
0000707649fd2a39  vmovaps [rsp+0x10], xmm2
0000707649fd2a3f  vmovaps [rsp+0x20], xmm3
0000707649fd2a45  vmovaps [rsp+0x30], xmm4
0000707649fd2a4b  vmovaps [rsp+0x40], xmm5
0000707649fd2a51  vmovaps [rsp+0x50], xmm6
0000707649fd2a57  vmovaps [rsp+0x60], xmm7
0000707649fd2a5d  vmovaps [rsp+0x70], xmm8
0000707649fd2a63  vmovaps [rsp+0x80], xmm9
0000707649fd2a6c  vmovaps [rsp+0x90], xmm10
0000707649fd2a75  vmovaps [rsp+0xA0], xmm11
0000707649fd2a7e  vmovaps [rsp+0xB0], xmm12
0000707649fd2a87  vmovaps [rsp+0xC0], xmm13
0000707649fd2a90  vmovaps [rsp+0xD0], xmm14
0000707649fd2a99  vmovaps [rsp+0xE0], xmm15
0000707649fd2aa2  sub rsp, 0x30
0000707649fd2aa6  movaps [rsp], xmm1
0000707649fd2aaa  movaps [rsp+0x10], xmm5
0000707649fd2aaf  movaps [rsp+0x20], xmm13
0000707649fd2ab5  lea rdi, [rsp]
0000707649fd2ab9  mov esi, 0x00
0000707649fd2abe  mov rax, 0x59CB0B054530
0000707649fd2ac8  call rax
0000707649fd2aca  movaps xmm1, [rsp]
0000707649fd2ace  add rsp, 0x30
0000707649fd2ad2  vmovaps xmm0, [rsp]
0000707649fd2ad7  vmovaps xmm2, [rsp+0x10]
0000707649fd2add  vmovaps xmm3, [rsp+0x20]
0000707649fd2ae3  vmovaps xmm4, [rsp+0x30]
0000707649fd2ae9  vmovaps xmm5, [rsp+0x40]
0000707649fd2aef  vmovaps xmm6, [rsp+0x50]
0000707649fd2af5  vmovaps xmm7, [rsp+0x60]
0000707649fd2afb  vmovaps xmm8, [rsp+0x70]
0000707649fd2b01  vmovaps xmm9, [rsp+0x80]
0000707649fd2b0a  vmovaps xmm10, [rsp+0x90]
0000707649fd2b13  vmovaps xmm11, [rsp+0xA0]
0000707649fd2b1c  vmovaps xmm12, [rsp+0xB0]
0000707649fd2b25  vmovaps xmm13, [rsp+0xC0]
0000707649fd2b2e  vmovaps xmm14, [rsp+0xD0]
0000707649fd2b37  vmovaps xmm15, [rsp+0xE0]
0000707649fd2b40  add rsp, 0xF0
0000707649fd2b47  pop r11
0000707649fd2b49  pop r10
0000707649fd2b4b  pop r9
0000707649fd2b4d  pop r8
0000707649fd2b4f  pop rsi
0000707649fd2b50  pop rdi
0000707649fd2b51  pop rdx
0000707649fd2b52  pop rcx
0000707649fd2b53  pop rax
0000707649fd2b54  add rsp, 0x08
0000707649fd2b58  jmp 0x0000707649FCFDB6
0000707649fd2b5d  sub rsp, 0x08
0000707649fd2b61  push rax
0000707649fd2b62  push rcx
0000707649fd2b63  push rdx
0000707649fd2b64  push rdi
0000707649fd2b65  push rsi
0000707649fd2b66  push r8
0000707649fd2b68  push r9
0000707649fd2b6a  push r10
0000707649fd2b6c  push r11
0000707649fd2b6e  sub rsp, 0xF0
0000707649fd2b75  vmovaps [rsp], xmm0
0000707649fd2b7a  vmovaps [rsp+0x10], xmm1
0000707649fd2b80  vmovaps [rsp+0x20], xmm2
0000707649fd2b86  vmovaps [rsp+0x30], xmm3
0000707649fd2b8c  vmovaps [rsp+0x40], xmm4
0000707649fd2b92  vmovaps [rsp+0x50], xmm6
0000707649fd2b98  vmovaps [rsp+0x60], xmm7
0000707649fd2b9e  vmovaps [rsp+0x70], xmm8
0000707649fd2ba4  vmovaps [rsp+0x80], xmm9
0000707649fd2bad  vmovaps [rsp+0x90], xmm10
0000707649fd2bb6  vmovaps [rsp+0xA0], xmm11
0000707649fd2bbf  vmovaps [rsp+0xB0], xmm12
0000707649fd2bc8  vmovaps [rsp+0xC0], xmm13
0000707649fd2bd1  vmovaps [rsp+0xD0], xmm14
0000707649fd2bda  vmovaps [rsp+0xE0], xmm15
0000707649fd2be3  sub rsp, 0x30
0000707649fd2be7  movaps [rsp], xmm5
0000707649fd2beb  movaps [rsp+0x10], xmm2
0000707649fd2bf0  movaps [rsp+0x20], xmm13
0000707649fd2bf6  lea rdi, [rsp]
0000707649fd2bfa  mov esi, 0x00
0000707649fd2bff  mov rax, 0x59CB0B054530
0000707649fd2c09  call rax
0000707649fd2c0b  movaps xmm5, [rsp]
0000707649fd2c0f  add rsp, 0x30
0000707649fd2c13  vmovaps xmm0, [rsp]
0000707649fd2c18  vmovaps xmm1, [rsp+0x10]
0000707649fd2c1e  vmovaps xmm2, [rsp+0x20]
0000707649fd2c24  vmovaps xmm3, [rsp+0x30]
0000707649fd2c2a  vmovaps xmm4, [rsp+0x40]
0000707649fd2c30  vmovaps xmm6, [rsp+0x50]
0000707649fd2c36  vmovaps xmm7, [rsp+0x60]
0000707649fd2c3c  vmovaps xmm8, [rsp+0x70]
0000707649fd2c42  vmovaps xmm9, [rsp+0x80]
0000707649fd2c4b  vmovaps xmm10, [rsp+0x90]
0000707649fd2c54  vmovaps xmm11, [rsp+0xA0]
0000707649fd2c5d  vmovaps xmm12, [rsp+0xB0]
0000707649fd2c66  vmovaps xmm13, [rsp+0xC0]
0000707649fd2c6f  vmovaps xmm14, [rsp+0xD0]
0000707649fd2c78  vmovaps xmm15, [rsp+0xE0]
0000707649fd2c81  add rsp, 0xF0
0000707649fd2c88  pop r11
0000707649fd2c8a  pop r10
0000707649fd2c8c  pop r9
0000707649fd2c8e  pop r8
0000707649fd2c90  pop rsi
0000707649fd2c91  pop rdi
0000707649fd2c92  pop rdx
0000707649fd2c93  pop rcx
0000707649fd2c94  pop rax
0000707649fd2c95  add rsp, 0x08
0000707649fd2c99  jmp 0x0000707649FCFDEC
0000707649fd2c9e  sub rsp, 0x08
0000707649fd2ca2  push rax
0000707649fd2ca3  push rcx
0000707649fd2ca4  push rdx
0000707649fd2ca5  push rdi
0000707649fd2ca6  push rsi
0000707649fd2ca7  push r8
0000707649fd2ca9  push r9
0000707649fd2cab  push r10
0000707649fd2cad  push r11
0000707649fd2caf  sub rsp, 0xF0
0000707649fd2cb6  vmovaps [rsp], xmm0
0000707649fd2cbb  vmovaps [rsp+0x10], xmm1
0000707649fd2cc1  vmovaps [rsp+0x20], xmm2
0000707649fd2cc7  vmovaps [rsp+0x30], xmm3
0000707649fd2ccd  vmovaps [rsp+0x40], xmm4
0000707649fd2cd3  vmovaps [rsp+0x50], xmm5
0000707649fd2cd9  vmovaps [rsp+0x60], xmm6
0000707649fd2cdf  vmovaps [rsp+0x70], xmm7
0000707649fd2ce5  vmovaps [rsp+0x80], xmm8
0000707649fd2cee  vmovaps [rsp+0x90], xmm9
0000707649fd2cf7  vmovaps [rsp+0xA0], xmm10
0000707649fd2d00  vmovaps [rsp+0xB0], xmm11
0000707649fd2d09  vmovaps [rsp+0xC0], xmm12
0000707649fd2d12  vmovaps [rsp+0xD0], xmm14
0000707649fd2d1b  vmovaps [rsp+0xE0], xmm15
0000707649fd2d24  sub rsp, 0x30
0000707649fd2d28  movaps [rsp], xmm13
0000707649fd2d2d  movaps [rsp+0x10], xmm10
0000707649fd2d33  movaps [rsp+0x20], xmm1
0000707649fd2d38  lea rdi, [rsp]
0000707649fd2d3c  mov esi, 0x00
0000707649fd2d41  mov rax, 0x59CB0B054530
0000707649fd2d4b  call rax
0000707649fd2d4d  movaps xmm13, [rsp]
0000707649fd2d52  add rsp, 0x30
0000707649fd2d56  vmovaps xmm0, [rsp]
0000707649fd2d5b  vmovaps xmm1, [rsp+0x10]
0000707649fd2d61  vmovaps xmm2, [rsp+0x20]
0000707649fd2d67  vmovaps xmm3, [rsp+0x30]
0000707649fd2d6d  vmovaps xmm4, [rsp+0x40]
0000707649fd2d73  vmovaps xmm5, [rsp+0x50]
0000707649fd2d79  vmovaps xmm6, [rsp+0x60]
0000707649fd2d7f  vmovaps xmm7, [rsp+0x70]
0000707649fd2d85  vmovaps xmm8, [rsp+0x80]
0000707649fd2d8e  vmovaps xmm9, [rsp+0x90]
0000707649fd2d97  vmovaps xmm10, [rsp+0xA0]
0000707649fd2da0  vmovaps xmm11, [rsp+0xB0]
0000707649fd2da9  vmovaps xmm12, [rsp+0xC0]
0000707649fd2db2  vmovaps xmm14, [rsp+0xD0]
0000707649fd2dbb  vmovaps xmm15, [rsp+0xE0]
0000707649fd2dc4  add rsp, 0xF0
0000707649fd2dcb  pop r11
0000707649fd2dcd  pop r10
0000707649fd2dcf  pop r9
0000707649fd2dd1  pop r8
0000707649fd2dd3  pop rsi
0000707649fd2dd4  pop rdi
0000707649fd2dd5  pop rdx
0000707649fd2dd6  pop rcx
0000707649fd2dd7  pop rax
0000707649fd2dd8  add rsp, 0x08
0000707649fd2ddc  jmp 0x0000707649FCFE15
0000707649fd2de1  sub rsp, 0x08
0000707649fd2de5  push rax
0000707649fd2de6  push rcx
0000707649fd2de7  push rdx
0000707649fd2de8  push rdi
0000707649fd2de9  push rsi
0000707649fd2dea  push r8
0000707649fd2dec  push r9
0000707649fd2dee  push r10
0000707649fd2df0  push r11
0000707649fd2df2  sub rsp, 0xF0
0000707649fd2df9  vmovaps [rsp], xmm0
0000707649fd2dfe  vmovaps [rsp+0x10], xmm2
0000707649fd2e04  vmovaps [rsp+0x20], xmm3
0000707649fd2e0a  vmovaps [rsp+0x30], xmm4
0000707649fd2e10  vmovaps [rsp+0x40], xmm5
0000707649fd2e16  vmovaps [rsp+0x50], xmm6
0000707649fd2e1c  vmovaps [rsp+0x60], xmm7
0000707649fd2e22  vmovaps [rsp+0x70], xmm8
0000707649fd2e28  vmovaps [rsp+0x80], xmm9
0000707649fd2e31  vmovaps [rsp+0x90], xmm10
0000707649fd2e3a  vmovaps [rsp+0xA0], xmm11
0000707649fd2e43  vmovaps [rsp+0xB0], xmm12
0000707649fd2e4c  vmovaps [rsp+0xC0], xmm13
0000707649fd2e55  vmovaps [rsp+0xD0], xmm14
0000707649fd2e5e  vmovaps [rsp+0xE0], xmm15
0000707649fd2e67  sub rsp, 0x30
0000707649fd2e6b  movaps [rsp], xmm1
0000707649fd2e6f  movaps [rsp+0x10], xmm15
0000707649fd2e75  movaps [rsp+0x20], xmm10
0000707649fd2e7b  lea rdi, [rsp]
0000707649fd2e7f  mov esi, 0x00
0000707649fd2e84  mov rax, 0x59CB0B054530
0000707649fd2e8e  call rax
0000707649fd2e90  movaps xmm1, [rsp]
0000707649fd2e94  add rsp, 0x30
0000707649fd2e98  vmovaps xmm0, [rsp]
0000707649fd2e9d  vmovaps xmm2, [rsp+0x10]
0000707649fd2ea3  vmovaps xmm3, [rsp+0x20]
0000707649fd2ea9  vmovaps xmm4, [rsp+0x30]
0000707649fd2eaf  vmovaps xmm5, [rsp+0x40]
0000707649fd2eb5  vmovaps xmm6, [rsp+0x50]
0000707649fd2ebb  vmovaps xmm7, [rsp+0x60]
0000707649fd2ec1  vmovaps xmm8, [rsp+0x70]
0000707649fd2ec7  vmovaps xmm9, [rsp+0x80]
0000707649fd2ed0  vmovaps xmm10, [rsp+0x90]
0000707649fd2ed9  vmovaps xmm11, [rsp+0xA0]
0000707649fd2ee2  vmovaps xmm12, [rsp+0xB0]
0000707649fd2eeb  vmovaps xmm13, [rsp+0xC0]
0000707649fd2ef4  vmovaps xmm14, [rsp+0xD0]
0000707649fd2efd  vmovaps xmm15, [rsp+0xE0]
0000707649fd2f06  add rsp, 0xF0
0000707649fd2f0d  pop r11
0000707649fd2f0f  pop r10
0000707649fd2f11  pop r9
0000707649fd2f13  pop r8
0000707649fd2f15  pop rsi
0000707649fd2f16  pop rdi
0000707649fd2f17  pop rdx
0000707649fd2f18  pop rcx
0000707649fd2f19  pop rax
0000707649fd2f1a  add rsp, 0x08
0000707649fd2f1e  jmp 0x0000707649FCFE34
0000707649fd2f23  sub rsp, 0x08
0000707649fd2f27  push rax
0000707649fd2f28  push rcx
0000707649fd2f29  push rdx
0000707649fd2f2a  push rdi
0000707649fd2f2b  push rsi
0000707649fd2f2c  push r8
0000707649fd2f2e  push r9
0000707649fd2f30  push r10
0000707649fd2f32  push r11
0000707649fd2f34  sub rsp, 0xF0
0000707649fd2f3b  vmovaps [rsp], xmm0
0000707649fd2f40  vmovaps [rsp+0x10], xmm1
0000707649fd2f46  vmovaps [rsp+0x20], xmm2
0000707649fd2f4c  vmovaps [rsp+0x30], xmm3
0000707649fd2f52  vmovaps [rsp+0x40], xmm4
0000707649fd2f58  vmovaps [rsp+0x50], xmm5
0000707649fd2f5e  vmovaps [rsp+0x60], xmm6
0000707649fd2f64  vmovaps [rsp+0x70], xmm7
0000707649fd2f6a  vmovaps [rsp+0x80], xmm8
0000707649fd2f73  vmovaps [rsp+0x90], xmm9
0000707649fd2f7c  vmovaps [rsp+0xA0], xmm10
0000707649fd2f85  vmovaps [rsp+0xB0], xmm11
0000707649fd2f8e  vmovaps [rsp+0xC0], xmm12
0000707649fd2f97  vmovaps [rsp+0xD0], xmm13
0000707649fd2fa0  vmovaps [rsp+0xE0], xmm14
0000707649fd2fa9  sub rsp, 0x30
0000707649fd2fad  movaps [rsp], xmm15
0000707649fd2fb2  movaps [rsp+0x10], xmm10
0000707649fd2fb8  movaps [rsp+0x20], xmm11
0000707649fd2fbe  lea rdi, [rsp]
0000707649fd2fc2  mov esi, 0x00
0000707649fd2fc7  mov rax, 0x59CB0B054530
0000707649fd2fd1  call rax
0000707649fd2fd3  movaps xmm15, [rsp]
0000707649fd2fd8  add rsp, 0x30
0000707649fd2fdc  vmovaps xmm0, [rsp]
0000707649fd2fe1  vmovaps xmm1, [rsp+0x10]
0000707649fd2fe7  vmovaps xmm2, [rsp+0x20]
0000707649fd2fed  vmovaps xmm3, [rsp+0x30]
0000707649fd2ff3  vmovaps xmm4, [rsp+0x40]
0000707649fd2ff9  vmovaps xmm5, [rsp+0x50]
0000707649fd2fff  vmovaps xmm6, [rsp+0x60]
0000707649fd3005  vmovaps xmm7, [rsp+0x70]
0000707649fd300b  vmovaps xmm8, [rsp+0x80]
0000707649fd3014  vmovaps xmm9, [rsp+0x90]
0000707649fd301d  vmovaps xmm10, [rsp+0xA0]
0000707649fd3026  vmovaps xmm11, [rsp+0xB0]
0000707649fd302f  vmovaps xmm12, [rsp+0xC0]
0000707649fd3038  vmovaps xmm13, [rsp+0xD0]
0000707649fd3041  vmovaps xmm14, [rsp+0xE0]
0000707649fd304a  add rsp, 0xF0
0000707649fd3051  pop r11
0000707649fd3053  pop r10
0000707649fd3055  pop r9
0000707649fd3057  pop r8
0000707649fd3059  pop rsi
0000707649fd305a  pop rdi
0000707649fd305b  pop rdx
0000707649fd305c  pop rcx
0000707649fd305d  pop rax
0000707649fd305e  add rsp, 0x08
0000707649fd3062  jmp 0x0000707649FCFE57
0000707649fd3067  sub rsp, 0x08
0000707649fd306b  push rax
0000707649fd306c  push rcx
0000707649fd306d  push rdx
0000707649fd306e  push rdi
0000707649fd306f  push rsi
0000707649fd3070  push r8
0000707649fd3072  push r9
0000707649fd3074  push r10
0000707649fd3076  push r11
0000707649fd3078  sub rsp, 0xF0
0000707649fd307f  vmovaps [rsp], xmm0
0000707649fd3084  vmovaps [rsp+0x10], xmm1
0000707649fd308a  vmovaps [rsp+0x20], xmm2
0000707649fd3090  vmovaps [rsp+0x30], xmm3
0000707649fd3096  vmovaps [rsp+0x40], xmm4
0000707649fd309c  vmovaps [rsp+0x50], xmm5
0000707649fd30a2  vmovaps [rsp+0x60], xmm6
0000707649fd30a8  vmovaps [rsp+0x70], xmm7
0000707649fd30ae  vmovaps [rsp+0x80], xmm8
0000707649fd30b7  vmovaps [rsp+0x90], xmm9
0000707649fd30c0  vmovaps [rsp+0xA0], xmm11
0000707649fd30c9  vmovaps [rsp+0xB0], xmm12
0000707649fd30d2  vmovaps [rsp+0xC0], xmm13
0000707649fd30db  vmovaps [rsp+0xD0], xmm14
0000707649fd30e4  vmovaps [rsp+0xE0], xmm15
0000707649fd30ed  sub rsp, 0x30
0000707649fd30f1  movaps [rsp], xmm10
0000707649fd30f6  movaps [rsp+0x10], xmm12
0000707649fd30fc  movaps [rsp+0x20], xmm11
0000707649fd3102  lea rdi, [rsp]
0000707649fd3106  mov esi, 0x00
0000707649fd310b  mov rax, 0x59CB0B054530
0000707649fd3115  call rax
0000707649fd3117  movaps xmm10, [rsp]
0000707649fd311c  add rsp, 0x30
0000707649fd3120  vmovaps xmm0, [rsp]
0000707649fd3125  vmovaps xmm1, [rsp+0x10]
0000707649fd312b  vmovaps xmm2, [rsp+0x20]
0000707649fd3131  vmovaps xmm3, [rsp+0x30]
0000707649fd3137  vmovaps xmm4, [rsp+0x40]
0000707649fd313d  vmovaps xmm5, [rsp+0x50]
0000707649fd3143  vmovaps xmm6, [rsp+0x60]
0000707649fd3149  vmovaps xmm7, [rsp+0x70]
0000707649fd314f  vmovaps xmm8, [rsp+0x80]
0000707649fd3158  vmovaps xmm9, [rsp+0x90]
0000707649fd3161  vmovaps xmm11, [rsp+0xA0]
0000707649fd316a  vmovaps xmm12, [rsp+0xB0]
0000707649fd3173  vmovaps xmm13, [rsp+0xC0]
0000707649fd317c  vmovaps xmm14, [rsp+0xD0]
0000707649fd3185  vmovaps xmm15, [rsp+0xE0]
0000707649fd318e  add rsp, 0xF0
0000707649fd3195  pop r11
0000707649fd3197  pop r10
0000707649fd3199  pop r9
0000707649fd319b  pop r8
0000707649fd319d  pop rsi
0000707649fd319e  pop rdi
0000707649fd319f  pop rdx
0000707649fd31a0  pop rcx
0000707649fd31a1  pop rax
0000707649fd31a2  add rsp, 0x08
0000707649fd31a6  jmp 0x0000707649FCFE80
0000707649fd31ab  sub rsp, 0x08
0000707649fd31af  push rax
0000707649fd31b0  push rcx
0000707649fd31b1  push rdx
0000707649fd31b2  push rdi
0000707649fd31b3  push rsi
0000707649fd31b4  push r8
0000707649fd31b6  push r9
0000707649fd31b8  push r10
0000707649fd31ba  push r11
0000707649fd31bc  sub rsp, 0xF0
0000707649fd31c3  vmovaps [rsp], xmm0
0000707649fd31c8  vmovaps [rsp+0x10], xmm1
0000707649fd31ce  vmovaps [rsp+0x20], xmm2
0000707649fd31d4  vmovaps [rsp+0x30], xmm3
0000707649fd31da  vmovaps [rsp+0x40], xmm4
0000707649fd31e0  vmovaps [rsp+0x50], xmm5
0000707649fd31e6  vmovaps [rsp+0x60], xmm6
0000707649fd31ec  vmovaps [rsp+0x70], xmm7
0000707649fd31f2  vmovaps [rsp+0x80], xmm8
0000707649fd31fb  vmovaps [rsp+0x90], xmm9
0000707649fd3204  vmovaps [rsp+0xA0], xmm10
0000707649fd320d  vmovaps [rsp+0xB0], xmm12
0000707649fd3216  vmovaps [rsp+0xC0], xmm13
0000707649fd321f  vmovaps [rsp+0xD0], xmm14
0000707649fd3228  vmovaps [rsp+0xE0], xmm15
0000707649fd3231  sub rsp, 0x30
0000707649fd3235  movaps [rsp], xmm11
0000707649fd323a  movaps [rsp+0x10], xmm2
0000707649fd323f  movaps [rsp+0x20], xmm12
0000707649fd3245  lea rdi, [rsp]
0000707649fd3249  mov esi, 0x00
0000707649fd324e  mov rax, 0x59CB0B054530
0000707649fd3258  call rax
0000707649fd325a  movaps xmm11, [rsp]
0000707649fd325f  add rsp, 0x30
0000707649fd3263  vmovaps xmm0, [rsp]
0000707649fd3268  vmovaps xmm1, [rsp+0x10]
0000707649fd326e  vmovaps xmm2, [rsp+0x20]
0000707649fd3274  vmovaps xmm3, [rsp+0x30]
0000707649fd327a  vmovaps xmm4, [rsp+0x40]
0000707649fd3280  vmovaps xmm5, [rsp+0x50]
0000707649fd3286  vmovaps xmm6, [rsp+0x60]
0000707649fd328c  vmovaps xmm7, [rsp+0x70]
0000707649fd3292  vmovaps xmm8, [rsp+0x80]
0000707649fd329b  vmovaps xmm9, [rsp+0x90]
0000707649fd32a4  vmovaps xmm10, [rsp+0xA0]
0000707649fd32ad  vmovaps xmm12, [rsp+0xB0]
0000707649fd32b6  vmovaps xmm13, [rsp+0xC0]
0000707649fd32bf  vmovaps xmm14, [rsp+0xD0]
0000707649fd32c8  vmovaps xmm15, [rsp+0xE0]
0000707649fd32d1  add rsp, 0xF0
0000707649fd32d8  pop r11
0000707649fd32da  pop r10
0000707649fd32dc  pop r9
0000707649fd32de  pop r8
0000707649fd32e0  pop rsi
0000707649fd32e1  pop rdi
0000707649fd32e2  pop rdx
0000707649fd32e3  pop rcx
0000707649fd32e4  pop rax
0000707649fd32e5  add rsp, 0x08
0000707649fd32e9  jmp 0x0000707649FCFEB8
0000707649fd32ee  sub rsp, 0x08
0000707649fd32f2  push rax
0000707649fd32f3  push rcx
0000707649fd32f4  push rdx
0000707649fd32f5  push rdi
0000707649fd32f6  push rsi
0000707649fd32f7  push r8
0000707649fd32f9  push r9
0000707649fd32fb  push r10
0000707649fd32fd  push r11
0000707649fd32ff  sub rsp, 0xF0
0000707649fd3306  vmovaps [rsp], xmm0
0000707649fd330b  vmovaps [rsp+0x10], xmm2
0000707649fd3311  vmovaps [rsp+0x20], xmm3
0000707649fd3317  vmovaps [rsp+0x30], xmm4
0000707649fd331d  vmovaps [rsp+0x40], xmm5
0000707649fd3323  vmovaps [rsp+0x50], xmm6
0000707649fd3329  vmovaps [rsp+0x60], xmm7
0000707649fd332f  vmovaps [rsp+0x70], xmm8
0000707649fd3335  vmovaps [rsp+0x80], xmm9
0000707649fd333e  vmovaps [rsp+0x90], xmm10
0000707649fd3347  vmovaps [rsp+0xA0], xmm11
0000707649fd3350  vmovaps [rsp+0xB0], xmm12
0000707649fd3359  vmovaps [rsp+0xC0], xmm13
0000707649fd3362  vmovaps [rsp+0xD0], xmm14
0000707649fd336b  vmovaps [rsp+0xE0], xmm15
0000707649fd3374  sub rsp, 0x30
0000707649fd3378  movaps [rsp], xmm1
0000707649fd337c  movaps [rsp+0x10], xmm14
0000707649fd3382  movaps [rsp+0x20], xmm6
0000707649fd3387  lea rdi, [rsp]
0000707649fd338b  mov esi, 0x00
0000707649fd3390  mov rax, 0x59CB0B054530
0000707649fd339a  call rax
0000707649fd339c  movaps xmm1, [rsp]
0000707649fd33a0  add rsp, 0x30
0000707649fd33a4  vmovaps xmm0, [rsp]
0000707649fd33a9  vmovaps xmm2, [rsp+0x10]
0000707649fd33af  vmovaps xmm3, [rsp+0x20]
0000707649fd33b5  vmovaps xmm4, [rsp+0x30]
0000707649fd33bb  vmovaps xmm5, [rsp+0x40]
0000707649fd33c1  vmovaps xmm6, [rsp+0x50]
0000707649fd33c7  vmovaps xmm7, [rsp+0x60]
0000707649fd33cd  vmovaps xmm8, [rsp+0x70]
0000707649fd33d3  vmovaps xmm9, [rsp+0x80]
0000707649fd33dc  vmovaps xmm10, [rsp+0x90]
0000707649fd33e5  vmovaps xmm11, [rsp+0xA0]
0000707649fd33ee  vmovaps xmm12, [rsp+0xB0]
0000707649fd33f7  vmovaps xmm13, [rsp+0xC0]
0000707649fd3400  vmovaps xmm14, [rsp+0xD0]
0000707649fd3409  vmovaps xmm15, [rsp+0xE0]
0000707649fd3412  add rsp, 0xF0
0000707649fd3419  pop r11
0000707649fd341b  pop r10
0000707649fd341d  pop r9
0000707649fd341f  pop r8
0000707649fd3421  pop rsi
0000707649fd3422  pop rdi
0000707649fd3423  pop rdx
0000707649fd3424  pop rcx
0000707649fd3425  pop rax
0000707649fd3426  add rsp, 0x08
0000707649fd342a  jmp 0x0000707649FCFED1
0000707649fd342f  sub rsp, 0x08
0000707649fd3433  push rax
0000707649fd3434  push rcx
0000707649fd3435  push rdx
0000707649fd3436  push rdi
0000707649fd3437  push rsi
0000707649fd3438  push r8
0000707649fd343a  push r9
0000707649fd343c  push r10
0000707649fd343e  push r11
0000707649fd3440  sub rsp, 0xF0
0000707649fd3447  vmovaps [rsp], xmm0
0000707649fd344c  vmovaps [rsp+0x10], xmm1
0000707649fd3452  vmovaps [rsp+0x20], xmm2
0000707649fd3458  vmovaps [rsp+0x30], xmm3
0000707649fd345e  vmovaps [rsp+0x40], xmm4
0000707649fd3464  vmovaps [rsp+0x50], xmm5
0000707649fd346a  vmovaps [rsp+0x60], xmm6
0000707649fd3470  vmovaps [rsp+0x70], xmm7
0000707649fd3476  vmovaps [rsp+0x80], xmm8
0000707649fd347f  vmovaps [rsp+0x90], xmm9
0000707649fd3488  vmovaps [rsp+0xA0], xmm10
0000707649fd3491  vmovaps [rsp+0xB0], xmm11
0000707649fd349a  vmovaps [rsp+0xC0], xmm12
0000707649fd34a3  vmovaps [rsp+0xD0], xmm13
0000707649fd34ac  vmovaps [rsp+0xE0], xmm15
0000707649fd34b5  sub rsp, 0x30
0000707649fd34b9  movaps [rsp], xmm14
0000707649fd34be  movaps [rsp+0x10], xmm12
0000707649fd34c4  movaps [rsp+0x20], xmm5
0000707649fd34c9  lea rdi, [rsp]
0000707649fd34cd  mov esi, 0x00
0000707649fd34d2  mov rax, 0x59CB0B054530
0000707649fd34dc  call rax
0000707649fd34de  movaps xmm14, [rsp]
0000707649fd34e3  add rsp, 0x30
0000707649fd34e7  vmovaps xmm0, [rsp]
0000707649fd34ec  vmovaps xmm1, [rsp+0x10]
0000707649fd34f2  vmovaps xmm2, [rsp+0x20]
0000707649fd34f8  vmovaps xmm3, [rsp+0x30]
0000707649fd34fe  vmovaps xmm4, [rsp+0x40]
0000707649fd3504  vmovaps xmm5, [rsp+0x50]
0000707649fd350a  vmovaps xmm6, [rsp+0x60]
0000707649fd3510  vmovaps xmm7, [rsp+0x70]
0000707649fd3516  vmovaps xmm8, [rsp+0x80]
0000707649fd351f  vmovaps xmm9, [rsp+0x90]
0000707649fd3528  vmovaps xmm10, [rsp+0xA0]
0000707649fd3531  vmovaps xmm11, [rsp+0xB0]
0000707649fd353a  vmovaps xmm12, [rsp+0xC0]
0000707649fd3543  vmovaps xmm13, [rsp+0xD0]
0000707649fd354c  vmovaps xmm15, [rsp+0xE0]
0000707649fd3555  add rsp, 0xF0
0000707649fd355c  pop r11
0000707649fd355e  pop r10
0000707649fd3560  pop r9
0000707649fd3562  pop r8
0000707649fd3564  pop rsi
0000707649fd3565  pop rdi
0000707649fd3566  pop rdx
0000707649fd3567  pop rcx
0000707649fd3568  pop rax
0000707649fd3569  add rsp, 0x08
0000707649fd356d  jmp 0x0000707649FCFEF1
0000707649fd3572  sub rsp, 0x08
0000707649fd3576  push rax
0000707649fd3577  push rcx
0000707649fd3578  push rdx
0000707649fd3579  push rdi
0000707649fd357a  push rsi
0000707649fd357b  push r8
0000707649fd357d  push r9
0000707649fd357f  push r10
0000707649fd3581  push r11
0000707649fd3583  sub rsp, 0xF0
0000707649fd358a  vmovaps [rsp], xmm0
0000707649fd358f  vmovaps [rsp+0x10], xmm1
0000707649fd3595  vmovaps [rsp+0x20], xmm2
0000707649fd359b  vmovaps [rsp+0x30], xmm3
0000707649fd35a1  vmovaps [rsp+0x40], xmm4
0000707649fd35a7  vmovaps [rsp+0x50], xmm5
0000707649fd35ad  vmovaps [rsp+0x60], xmm7
0000707649fd35b3  vmovaps [rsp+0x70], xmm8
0000707649fd35b9  vmovaps [rsp+0x80], xmm9
0000707649fd35c2  vmovaps [rsp+0x90], xmm10
0000707649fd35cb  vmovaps [rsp+0xA0], xmm11
0000707649fd35d4  vmovaps [rsp+0xB0], xmm12
0000707649fd35dd  vmovaps [rsp+0xC0], xmm13
0000707649fd35e6  vmovaps [rsp+0xD0], xmm14
0000707649fd35ef  vmovaps [rsp+0xE0], xmm15
0000707649fd35f8  sub rsp, 0x30
0000707649fd35fc  movaps [rsp], xmm6
0000707649fd3600  movaps [rsp+0x10], xmm9
0000707649fd3606  movaps [rsp+0x20], xmm12
0000707649fd360c  lea rdi, [rsp]
0000707649fd3610  mov esi, 0x00
0000707649fd3615  mov rax, 0x59CB0B054530
0000707649fd361f  call rax
0000707649fd3621  movaps xmm6, [rsp]
0000707649fd3625  add rsp, 0x30
0000707649fd3629  vmovaps xmm0, [rsp]
0000707649fd362e  vmovaps xmm1, [rsp+0x10]
0000707649fd3634  vmovaps xmm2, [rsp+0x20]
0000707649fd363a  vmovaps xmm3, [rsp+0x30]
0000707649fd3640  vmovaps xmm4, [rsp+0x40]
0000707649fd3646  vmovaps xmm5, [rsp+0x50]
0000707649fd364c  vmovaps xmm7, [rsp+0x60]
0000707649fd3652  vmovaps xmm8, [rsp+0x70]
0000707649fd3658  vmovaps xmm9, [rsp+0x80]
0000707649fd3661  vmovaps xmm10, [rsp+0x90]
0000707649fd366a  vmovaps xmm11, [rsp+0xA0]
0000707649fd3673  vmovaps xmm12, [rsp+0xB0]
0000707649fd367c  vmovaps xmm13, [rsp+0xC0]
0000707649fd3685  vmovaps xmm14, [rsp+0xD0]
0000707649fd368e  vmovaps xmm15, [rsp+0xE0]
0000707649fd3697  add rsp, 0xF0
0000707649fd369e  pop r11
0000707649fd36a0  pop r10
0000707649fd36a2  pop r9
0000707649fd36a4  pop r8
0000707649fd36a6  pop rsi
0000707649fd36a7  pop rdi
0000707649fd36a8  pop rdx
0000707649fd36a9  pop rcx
0000707649fd36aa  pop rax
0000707649fd36ab  add rsp, 0x08
0000707649fd36af  jmp 0x0000707649FCFF19
0000707649fd36b4  sub rsp, 0x08
0000707649fd36b8  push rax
0000707649fd36b9  push rcx
0000707649fd36ba  push rdx
0000707649fd36bb  push rdi
0000707649fd36bc  push rsi
0000707649fd36bd  push r8
0000707649fd36bf  push r9
0000707649fd36c1  push r10
0000707649fd36c3  push r11
0000707649fd36c5  sub rsp, 0xF0
0000707649fd36cc  vmovaps [rsp], xmm0
0000707649fd36d1  vmovaps [rsp+0x10], xmm1
0000707649fd36d7  vmovaps [rsp+0x20], xmm2
0000707649fd36dd  vmovaps [rsp+0x30], xmm3
0000707649fd36e3  vmovaps [rsp+0x40], xmm4
0000707649fd36e9  vmovaps [rsp+0x50], xmm5
0000707649fd36ef  vmovaps [rsp+0x60], xmm6
0000707649fd36f5  vmovaps [rsp+0x70], xmm7
0000707649fd36fb  vmovaps [rsp+0x80], xmm8
0000707649fd3704  vmovaps [rsp+0x90], xmm9
0000707649fd370d  vmovaps [rsp+0xA0], xmm10
0000707649fd3716  vmovaps [rsp+0xB0], xmm11
0000707649fd371f  vmovaps [rsp+0xC0], xmm13
0000707649fd3728  vmovaps [rsp+0xD0], xmm14
0000707649fd3731  vmovaps [rsp+0xE0], xmm15
0000707649fd373a  sub rsp, 0x30
0000707649fd373e  movaps [rsp], xmm12
0000707649fd3743  movaps [rsp+0x10], xmm15
0000707649fd3749  movaps [rsp+0x20], xmm13
0000707649fd374f  lea rdi, [rsp]
0000707649fd3753  mov esi, 0x00
0000707649fd3758  mov rax, 0x59CB0B054530
0000707649fd3762  call rax
0000707649fd3764  movaps xmm12, [rsp]
0000707649fd3769  add rsp, 0x30
0000707649fd376d  vmovaps xmm0, [rsp]
0000707649fd3772  vmovaps xmm1, [rsp+0x10]
0000707649fd3778  vmovaps xmm2, [rsp+0x20]
0000707649fd377e  vmovaps xmm3, [rsp+0x30]
0000707649fd3784  vmovaps xmm4, [rsp+0x40]
0000707649fd378a  vmovaps xmm5, [rsp+0x50]
0000707649fd3790  vmovaps xmm6, [rsp+0x60]
0000707649fd3796  vmovaps xmm7, [rsp+0x70]
0000707649fd379c  vmovaps xmm8, [rsp+0x80]
0000707649fd37a5  vmovaps xmm9, [rsp+0x90]
0000707649fd37ae  vmovaps xmm10, [rsp+0xA0]
0000707649fd37b7  vmovaps xmm11, [rsp+0xB0]
0000707649fd37c0  vmovaps xmm13, [rsp+0xC0]
0000707649fd37c9  vmovaps xmm14, [rsp+0xD0]
0000707649fd37d2  vmovaps xmm15, [rsp+0xE0]
0000707649fd37db  add rsp, 0xF0
0000707649fd37e2  pop r11
0000707649fd37e4  pop r10
0000707649fd37e6  pop r9
0000707649fd37e8  pop r8
0000707649fd37ea  pop rsi
0000707649fd37eb  pop rdi
0000707649fd37ec  pop rdx
0000707649fd37ed  pop rcx
0000707649fd37ee  pop rax
0000707649fd37ef  add rsp, 0x08
0000707649fd37f3  jmp 0x0000707649FCFF34
0000707649fd37f8  sub rsp, 0x08
0000707649fd37fc  push rax
0000707649fd37fd  push rcx
0000707649fd37fe  push rdx
0000707649fd37ff  push rdi
0000707649fd3800  push rsi
0000707649fd3801  push r8
0000707649fd3803  push r9
0000707649fd3805  push r10
0000707649fd3807  push r11
0000707649fd3809  sub rsp, 0xF0
0000707649fd3810  vmovaps [rsp], xmm0
0000707649fd3815  vmovaps [rsp+0x10], xmm1
0000707649fd381b  vmovaps [rsp+0x20], xmm2
0000707649fd3821  vmovaps [rsp+0x30], xmm3
0000707649fd3827  vmovaps [rsp+0x40], xmm4
0000707649fd382d  vmovaps [rsp+0x50], xmm5
0000707649fd3833  vmovaps [rsp+0x60], xmm6
0000707649fd3839  vmovaps [rsp+0x70], xmm7
0000707649fd383f  vmovaps [rsp+0x80], xmm8
0000707649fd3848  vmovaps [rsp+0x90], xmm9
0000707649fd3851  vmovaps [rsp+0xA0], xmm10
0000707649fd385a  vmovaps [rsp+0xB0], xmm11
0000707649fd3863  vmovaps [rsp+0xC0], xmm12
0000707649fd386c  vmovaps [rsp+0xD0], xmm13
0000707649fd3875  vmovaps [rsp+0xE0], xmm14
0000707649fd387e  sub rsp, 0x30
0000707649fd3882  movaps [rsp], xmm15
0000707649fd3887  movaps [rsp+0x10], xmm13
0000707649fd388d  movaps [rsp+0x20], xmm10
0000707649fd3893  lea rdi, [rsp]
0000707649fd3897  mov esi, 0x00
0000707649fd389c  mov rax, 0x59CB0B054530
0000707649fd38a6  call rax
0000707649fd38a8  movaps xmm15, [rsp]
0000707649fd38ad  add rsp, 0x30
0000707649fd38b1  vmovaps xmm0, [rsp]
0000707649fd38b6  vmovaps xmm1, [rsp+0x10]
0000707649fd38bc  vmovaps xmm2, [rsp+0x20]
0000707649fd38c2  vmovaps xmm3, [rsp+0x30]
0000707649fd38c8  vmovaps xmm4, [rsp+0x40]
0000707649fd38ce  vmovaps xmm5, [rsp+0x50]
0000707649fd38d4  vmovaps xmm6, [rsp+0x60]
0000707649fd38da  vmovaps xmm7, [rsp+0x70]
0000707649fd38e0  vmovaps xmm8, [rsp+0x80]
0000707649fd38e9  vmovaps xmm9, [rsp+0x90]
0000707649fd38f2  vmovaps xmm10, [rsp+0xA0]
0000707649fd38fb  vmovaps xmm11, [rsp+0xB0]
0000707649fd3904  vmovaps xmm12, [rsp+0xC0]
0000707649fd390d  vmovaps xmm13, [rsp+0xD0]
0000707649fd3916  vmovaps xmm14, [rsp+0xE0]
0000707649fd391f  add rsp, 0xF0
0000707649fd3926  pop r11
0000707649fd3928  pop r10
0000707649fd392a  pop r9
0000707649fd392c  pop r8
0000707649fd392e  pop rsi
0000707649fd392f  pop rdi
0000707649fd3930  pop rdx
0000707649fd3931  pop rcx
0000707649fd3932  pop rax
0000707649fd3933  add rsp, 0x08
0000707649fd3937  jmp 0x0000707649FCFF55
0000707649fd393c  call 0x0000707649E0C260
0000707649fd3941  jmp 0x0000707649FCFFB0
0000707649fd3946  sub rsp, 0x08
0000707649fd394a  push rax
0000707649fd394b  push rcx
0000707649fd394c  push rdx
0000707649fd394d  push rdi
0000707649fd394e  push rsi
0000707649fd394f  push r8
0000707649fd3951  push r9
0000707649fd3953  push r10
0000707649fd3955  push r11
0000707649fd3957  sub rsp, 0xF0
0000707649fd395e  vmovaps [rsp], xmm0
0000707649fd3963  vmovaps [rsp+0x10], xmm1
0000707649fd3969  vmovaps [rsp+0x20], xmm2
0000707649fd396f  vmovaps [rsp+0x30], xmm3
0000707649fd3975  vmovaps [rsp+0x40], xmm4
0000707649fd397b  vmovaps [rsp+0x50], xmm5
0000707649fd3981  vmovaps [rsp+0x60], xmm6
0000707649fd3987  vmovaps [rsp+0x70], xmm7
0000707649fd398d  vmovaps [rsp+0x80], xmm8
0000707649fd3996  vmovaps [rsp+0x90], xmm10
0000707649fd399f  vmovaps [rsp+0xA0], xmm11
0000707649fd39a8  vmovaps [rsp+0xB0], xmm12
0000707649fd39b1  vmovaps [rsp+0xC0], xmm13
0000707649fd39ba  vmovaps [rsp+0xD0], xmm14
0000707649fd39c3  vmovaps [rsp+0xE0], xmm15
0000707649fd39cc  sub rsp, 0x30
0000707649fd39d0  movaps [rsp], xmm9
0000707649fd39d5  movaps [rsp+0x10], xmm8
0000707649fd39db  movaps [rsp+0x20], xmm10
0000707649fd39e1  lea rdi, [rsp]
0000707649fd39e5  mov esi, 0x00
0000707649fd39ea  mov rax, 0x59CB0B054530
0000707649fd39f4  call rax
0000707649fd39f6  movaps xmm9, [rsp]
0000707649fd39fb  add rsp, 0x30
0000707649fd39ff  vmovaps xmm0, [rsp]
0000707649fd3a04  vmovaps xmm1, [rsp+0x10]
0000707649fd3a0a  vmovaps xmm2, [rsp+0x20]
0000707649fd3a10  vmovaps xmm3, [rsp+0x30]
0000707649fd3a16  vmovaps xmm4, [rsp+0x40]
0000707649fd3a1c  vmovaps xmm5, [rsp+0x50]
0000707649fd3a22  vmovaps xmm6, [rsp+0x60]
0000707649fd3a28  vmovaps xmm7, [rsp+0x70]
0000707649fd3a2e  vmovaps xmm8, [rsp+0x80]
0000707649fd3a37  vmovaps xmm10, [rsp+0x90]
0000707649fd3a40  vmovaps xmm11, [rsp+0xA0]
0000707649fd3a49  vmovaps xmm12, [rsp+0xB0]
0000707649fd3a52  vmovaps xmm13, [rsp+0xC0]
0000707649fd3a5b  vmovaps xmm14, [rsp+0xD0]
0000707649fd3a64  vmovaps xmm15, [rsp+0xE0]
0000707649fd3a6d  add rsp, 0xF0
0000707649fd3a74  pop r11
0000707649fd3a76  pop r10
0000707649fd3a78  pop r9
0000707649fd3a7a  pop r8
0000707649fd3a7c  pop rsi
0000707649fd3a7d  pop rdi
0000707649fd3a7e  pop rdx
0000707649fd3a7f  pop rcx
0000707649fd3a80  pop rax
0000707649fd3a81  add rsp, 0x08
0000707649fd3a85  jmp 0x0000707649FCFFE1
0000707649fd3a8a  sub rsp, 0x08
0000707649fd3a8e  push rax
0000707649fd3a8f  push rcx
0000707649fd3a90  push rdx
0000707649fd3a91  push rdi
0000707649fd3a92  push rsi
0000707649fd3a93  push r8
0000707649fd3a95  push r9
0000707649fd3a97  push r10
0000707649fd3a99  push r11
0000707649fd3a9b  sub rsp, 0xF0
0000707649fd3aa2  vmovaps [rsp], xmm0
0000707649fd3aa7  vmovaps [rsp+0x10], xmm1
0000707649fd3aad  vmovaps [rsp+0x20], xmm2
0000707649fd3ab3  vmovaps [rsp+0x30], xmm3
0000707649fd3ab9  vmovaps [rsp+0x40], xmm4
0000707649fd3abf  vmovaps [rsp+0x50], xmm5
0000707649fd3ac5  vmovaps [rsp+0x60], xmm6
0000707649fd3acb  vmovaps [rsp+0x70], xmm7
0000707649fd3ad1  vmovaps [rsp+0x80], xmm8
0000707649fd3ada  vmovaps [rsp+0x90], xmm9
0000707649fd3ae3  vmovaps [rsp+0xA0], xmm11
0000707649fd3aec  vmovaps [rsp+0xB0], xmm12
0000707649fd3af5  vmovaps [rsp+0xC0], xmm13
0000707649fd3afe  vmovaps [rsp+0xD0], xmm14
0000707649fd3b07  vmovaps [rsp+0xE0], xmm15
0000707649fd3b10  sub rsp, 0x30
0000707649fd3b14  movaps [rsp], xmm10
0000707649fd3b19  movaps [rsp+0x10], xmm1
0000707649fd3b1e  movaps [rsp+0x20], xmm11
0000707649fd3b24  lea rdi, [rsp]
0000707649fd3b28  mov esi, 0x00
0000707649fd3b2d  mov rax, 0x59CB0B054530
0000707649fd3b37  call rax
0000707649fd3b39  movaps xmm10, [rsp]
0000707649fd3b3e  add rsp, 0x30
0000707649fd3b42  vmovaps xmm0, [rsp]
0000707649fd3b47  vmovaps xmm1, [rsp+0x10]
0000707649fd3b4d  vmovaps xmm2, [rsp+0x20]
0000707649fd3b53  vmovaps xmm3, [rsp+0x30]
0000707649fd3b59  vmovaps xmm4, [rsp+0x40]
0000707649fd3b5f  vmovaps xmm5, [rsp+0x50]
0000707649fd3b65  vmovaps xmm6, [rsp+0x60]
0000707649fd3b6b  vmovaps xmm7, [rsp+0x70]
0000707649fd3b71  vmovaps xmm8, [rsp+0x80]
0000707649fd3b7a  vmovaps xmm9, [rsp+0x90]
0000707649fd3b83  vmovaps xmm11, [rsp+0xA0]
0000707649fd3b8c  vmovaps xmm12, [rsp+0xB0]
0000707649fd3b95  vmovaps xmm13, [rsp+0xC0]
0000707649fd3b9e  vmovaps xmm14, [rsp+0xD0]
0000707649fd3ba7  vmovaps xmm15, [rsp+0xE0]
0000707649fd3bb0  add rsp, 0xF0
0000707649fd3bb7  pop r11
0000707649fd3bb9  pop r10
0000707649fd3bbb  pop r9
0000707649fd3bbd  pop r8
0000707649fd3bbf  pop rsi
0000707649fd3bc0  pop rdi
0000707649fd3bc1  pop rdx
0000707649fd3bc2  pop rcx
0000707649fd3bc3  pop rax
0000707649fd3bc4  add rsp, 0x08
0000707649fd3bc8  jmp 0x0000707649FCFFFC
0000707649fd3bcd  sub rsp, 0x08
0000707649fd3bd1  push rax
0000707649fd3bd2  push rcx
0000707649fd3bd3  push rdx
0000707649fd3bd4  push rdi
0000707649fd3bd5  push rsi
0000707649fd3bd6  push r8
0000707649fd3bd8  push r9
0000707649fd3bda  push r10
0000707649fd3bdc  push r11
0000707649fd3bde  sub rsp, 0xF0
0000707649fd3be5  vmovaps [rsp], xmm0
0000707649fd3bea  vmovaps [rsp+0x10], xmm2
0000707649fd3bf0  vmovaps [rsp+0x20], xmm3
0000707649fd3bf6  vmovaps [rsp+0x30], xmm4
0000707649fd3bfc  vmovaps [rsp+0x40], xmm5
0000707649fd3c02  vmovaps [rsp+0x50], xmm6
0000707649fd3c08  vmovaps [rsp+0x60], xmm7
0000707649fd3c0e  vmovaps [rsp+0x70], xmm8
0000707649fd3c14  vmovaps [rsp+0x80], xmm9
0000707649fd3c1d  vmovaps [rsp+0x90], xmm10
0000707649fd3c26  vmovaps [rsp+0xA0], xmm11
0000707649fd3c2f  vmovaps [rsp+0xB0], xmm12
0000707649fd3c38  vmovaps [rsp+0xC0], xmm13
0000707649fd3c41  vmovaps [rsp+0xD0], xmm14
0000707649fd3c4a  vmovaps [rsp+0xE0], xmm15
0000707649fd3c53  sub rsp, 0x30
0000707649fd3c57  movaps [rsp], xmm1
0000707649fd3c5b  movaps [rsp+0x10], xmm14
0000707649fd3c61  movaps [rsp+0x20], xmm6
0000707649fd3c66  lea rdi, [rsp]
0000707649fd3c6a  mov esi, 0x00
0000707649fd3c6f  mov rax, 0x59CB0B054530
0000707649fd3c79  call rax
0000707649fd3c7b  movaps xmm1, [rsp]
0000707649fd3c7f  add rsp, 0x30
0000707649fd3c83  vmovaps xmm0, [rsp]
0000707649fd3c88  vmovaps xmm2, [rsp+0x10]
0000707649fd3c8e  vmovaps xmm3, [rsp+0x20]
0000707649fd3c94  vmovaps xmm4, [rsp+0x30]
0000707649fd3c9a  vmovaps xmm5, [rsp+0x40]
0000707649fd3ca0  vmovaps xmm6, [rsp+0x50]
0000707649fd3ca6  vmovaps xmm7, [rsp+0x60]
0000707649fd3cac  vmovaps xmm8, [rsp+0x70]
0000707649fd3cb2  vmovaps xmm9, [rsp+0x80]
0000707649fd3cbb  vmovaps xmm10, [rsp+0x90]
0000707649fd3cc4  vmovaps xmm11, [rsp+0xA0]
0000707649fd3ccd  vmovaps xmm12, [rsp+0xB0]
0000707649fd3cd6  vmovaps xmm13, [rsp+0xC0]
0000707649fd3cdf  vmovaps xmm14, [rsp+0xD0]
0000707649fd3ce8  vmovaps xmm15, [rsp+0xE0]
0000707649fd3cf1  add rsp, 0xF0
0000707649fd3cf8  pop r11
0000707649fd3cfa  pop r10
0000707649fd3cfc  pop r9
0000707649fd3cfe  pop r8
0000707649fd3d00  pop rsi
0000707649fd3d01  pop rdi
0000707649fd3d02  pop rdx
0000707649fd3d03  pop rcx
0000707649fd3d04  pop rax
0000707649fd3d05  add rsp, 0x08
0000707649fd3d09  jmp 0x0000707649FD0015
0000707649fd3d0e  sub rsp, 0x08
0000707649fd3d12  push rax
0000707649fd3d13  push rcx
0000707649fd3d14  push rdx
0000707649fd3d15  push rdi
0000707649fd3d16  push rsi
0000707649fd3d17  push r8
0000707649fd3d19  push r9
0000707649fd3d1b  push r10
0000707649fd3d1d  push r11
0000707649fd3d1f  sub rsp, 0xF0
0000707649fd3d26  vmovaps [rsp], xmm0
0000707649fd3d2b  vmovaps [rsp+0x10], xmm1
0000707649fd3d31  vmovaps [rsp+0x20], xmm2
0000707649fd3d37  vmovaps [rsp+0x30], xmm3
0000707649fd3d3d  vmovaps [rsp+0x40], xmm4
0000707649fd3d43  vmovaps [rsp+0x50], xmm5
0000707649fd3d49  vmovaps [rsp+0x60], xmm6
0000707649fd3d4f  vmovaps [rsp+0x70], xmm7
0000707649fd3d55  vmovaps [rsp+0x80], xmm8
0000707649fd3d5e  vmovaps [rsp+0x90], xmm9
0000707649fd3d67  vmovaps [rsp+0xA0], xmm10
0000707649fd3d70  vmovaps [rsp+0xB0], xmm12
0000707649fd3d79  vmovaps [rsp+0xC0], xmm13
0000707649fd3d82  vmovaps [rsp+0xD0], xmm14
0000707649fd3d8b  vmovaps [rsp+0xE0], xmm15
0000707649fd3d94  sub rsp, 0x30
0000707649fd3d98  movaps [rsp], xmm11
0000707649fd3d9d  movaps [rsp+0x10], xmm13
0000707649fd3da3  movaps [rsp+0x20], xmm14
0000707649fd3da9  lea rdi, [rsp]
0000707649fd3dad  mov esi, 0x00
0000707649fd3db2  mov rax, 0x59CB0B054530
0000707649fd3dbc  call rax
0000707649fd3dbe  movaps xmm11, [rsp]
0000707649fd3dc3  add rsp, 0x30
0000707649fd3dc7  vmovaps xmm0, [rsp]
0000707649fd3dcc  vmovaps xmm1, [rsp+0x10]
0000707649fd3dd2  vmovaps xmm2, [rsp+0x20]
0000707649fd3dd8  vmovaps xmm3, [rsp+0x30]
0000707649fd3dde  vmovaps xmm4, [rsp+0x40]
0000707649fd3de4  vmovaps xmm5, [rsp+0x50]
0000707649fd3dea  vmovaps xmm6, [rsp+0x60]
0000707649fd3df0  vmovaps xmm7, [rsp+0x70]
0000707649fd3df6  vmovaps xmm8, [rsp+0x80]
0000707649fd3dff  vmovaps xmm9, [rsp+0x90]
0000707649fd3e08  vmovaps xmm10, [rsp+0xA0]
0000707649fd3e11  vmovaps xmm12, [rsp+0xB0]
0000707649fd3e1a  vmovaps xmm13, [rsp+0xC0]
0000707649fd3e23  vmovaps xmm14, [rsp+0xD0]
0000707649fd3e2c  vmovaps xmm15, [rsp+0xE0]
0000707649fd3e35  add rsp, 0xF0
0000707649fd3e3c  pop r11
0000707649fd3e3e  pop r10
0000707649fd3e40  pop r9
0000707649fd3e42  pop r8
0000707649fd3e44  pop rsi
0000707649fd3e45  pop rdi
0000707649fd3e46  pop rdx
0000707649fd3e47  pop rcx
0000707649fd3e48  pop rax
0000707649fd3e49  add rsp, 0x08
0000707649fd3e4d  jmp 0x0000707649FD003F
0000707649fd3e52  sub rsp, 0x08
0000707649fd3e56  push rax
0000707649fd3e57  push rcx
0000707649fd3e58  push rdx
0000707649fd3e59  push rdi
0000707649fd3e5a  push rsi
0000707649fd3e5b  push r8
0000707649fd3e5d  push r9
0000707649fd3e5f  push r10
0000707649fd3e61  push r11
0000707649fd3e63  sub rsp, 0xF0
0000707649fd3e6a  vmovaps [rsp], xmm0
0000707649fd3e6f  vmovaps [rsp+0x10], xmm1
0000707649fd3e75  vmovaps [rsp+0x20], xmm2
0000707649fd3e7b  vmovaps [rsp+0x30], xmm3
0000707649fd3e81  vmovaps [rsp+0x40], xmm4
0000707649fd3e87  vmovaps [rsp+0x50], xmm5
0000707649fd3e8d  vmovaps [rsp+0x60], xmm6
0000707649fd3e93  vmovaps [rsp+0x70], xmm7
0000707649fd3e99  vmovaps [rsp+0x80], xmm8
0000707649fd3ea2  vmovaps [rsp+0x90], xmm9
0000707649fd3eab  vmovaps [rsp+0xA0], xmm10
0000707649fd3eb4  vmovaps [rsp+0xB0], xmm11
0000707649fd3ebd  vmovaps [rsp+0xC0], xmm12
0000707649fd3ec6  vmovaps [rsp+0xD0], xmm14
0000707649fd3ecf  vmovaps [rsp+0xE0], xmm15
0000707649fd3ed8  sub rsp, 0x30
0000707649fd3edc  movaps [rsp], xmm13
0000707649fd3ee1  movaps [rsp+0x10], xmm8
0000707649fd3ee7  movaps [rsp+0x20], xmm14
0000707649fd3eed  lea rdi, [rsp]
0000707649fd3ef1  mov esi, 0x00
0000707649fd3ef6  mov rax, 0x59CB0B054530
0000707649fd3f00  call rax
0000707649fd3f02  movaps xmm13, [rsp]
0000707649fd3f07  add rsp, 0x30
0000707649fd3f0b  vmovaps xmm0, [rsp]
0000707649fd3f10  vmovaps xmm1, [rsp+0x10]
0000707649fd3f16  vmovaps xmm2, [rsp+0x20]
0000707649fd3f1c  vmovaps xmm3, [rsp+0x30]
0000707649fd3f22  vmovaps xmm4, [rsp+0x40]
0000707649fd3f28  vmovaps xmm5, [rsp+0x50]
0000707649fd3f2e  vmovaps xmm6, [rsp+0x60]
0000707649fd3f34  vmovaps xmm7, [rsp+0x70]
0000707649fd3f3a  vmovaps xmm8, [rsp+0x80]
0000707649fd3f43  vmovaps xmm9, [rsp+0x90]
0000707649fd3f4c  vmovaps xmm10, [rsp+0xA0]
0000707649fd3f55  vmovaps xmm11, [rsp+0xB0]
0000707649fd3f5e  vmovaps xmm12, [rsp+0xC0]
0000707649fd3f67  vmovaps xmm14, [rsp+0xD0]
0000707649fd3f70  vmovaps xmm15, [rsp+0xE0]
0000707649fd3f79  add rsp, 0xF0
0000707649fd3f80  pop r11
0000707649fd3f82  pop r10
0000707649fd3f84  pop r9
0000707649fd3f86  pop r8
0000707649fd3f88  pop rsi
0000707649fd3f89  pop rdi
0000707649fd3f8a  pop rdx
0000707649fd3f8b  pop rcx
0000707649fd3f8c  pop rax
0000707649fd3f8d  add rsp, 0x08
0000707649fd3f91  jmp 0x0000707649FD006E
0000707649fd3f96  sub rsp, 0x08
0000707649fd3f9a  push rax
0000707649fd3f9b  push rcx
0000707649fd3f9c  push rdx
0000707649fd3f9d  push rdi
0000707649fd3f9e  push rsi
0000707649fd3f9f  push r8
0000707649fd3fa1  push r9
0000707649fd3fa3  push r10
0000707649fd3fa5  push r11
0000707649fd3fa7  sub rsp, 0xF0
0000707649fd3fae  vmovaps [rsp], xmm0
0000707649fd3fb3  vmovaps [rsp+0x10], xmm1
0000707649fd3fb9  vmovaps [rsp+0x20], xmm2
0000707649fd3fbf  vmovaps [rsp+0x30], xmm3
0000707649fd3fc5  vmovaps [rsp+0x40], xmm4
0000707649fd3fcb  vmovaps [rsp+0x50], xmm5
0000707649fd3fd1  vmovaps [rsp+0x60], xmm6
0000707649fd3fd7  vmovaps [rsp+0x70], xmm7
0000707649fd3fdd  vmovaps [rsp+0x80], xmm9
0000707649fd3fe6  vmovaps [rsp+0x90], xmm10
0000707649fd3fef  vmovaps [rsp+0xA0], xmm11
0000707649fd3ff8  vmovaps [rsp+0xB0], xmm12
0000707649fd4001  vmovaps [rsp+0xC0], xmm13
0000707649fd400a  vmovaps [rsp+0xD0], xmm14
0000707649fd4013  vmovaps [rsp+0xE0], xmm15
0000707649fd401c  sub rsp, 0x30
0000707649fd4020  movaps [rsp], xmm8
0000707649fd4025  movaps [rsp+0x10], xmm7
0000707649fd402a  movaps [rsp+0x20], xmm14
0000707649fd4030  lea rdi, [rsp]
0000707649fd4034  mov esi, 0x00
0000707649fd4039  mov rax, 0x59CB0B054530
0000707649fd4043  call rax
0000707649fd4045  movaps xmm8, [rsp]
0000707649fd404a  add rsp, 0x30
0000707649fd404e  vmovaps xmm0, [rsp]
0000707649fd4053  vmovaps xmm1, [rsp+0x10]
0000707649fd4059  vmovaps xmm2, [rsp+0x20]
0000707649fd405f  vmovaps xmm3, [rsp+0x30]
0000707649fd4065  vmovaps xmm4, [rsp+0x40]
0000707649fd406b  vmovaps xmm5, [rsp+0x50]
0000707649fd4071  vmovaps xmm6, [rsp+0x60]
0000707649fd4077  vmovaps xmm7, [rsp+0x70]
0000707649fd407d  vmovaps xmm9, [rsp+0x80]
0000707649fd4086  vmovaps xmm10, [rsp+0x90]
0000707649fd408f  vmovaps xmm11, [rsp+0xA0]
0000707649fd4098  vmovaps xmm12, [rsp+0xB0]
0000707649fd40a1  vmovaps xmm13, [rsp+0xC0]
0000707649fd40aa  vmovaps xmm14, [rsp+0xD0]
0000707649fd40b3  vmovaps xmm15, [rsp+0xE0]
0000707649fd40bc  add rsp, 0xF0
0000707649fd40c3  pop r11
0000707649fd40c5  pop r10
0000707649fd40c7  pop r9
0000707649fd40c9  pop r8
0000707649fd40cb  pop rsi
0000707649fd40cc  pop rdi
0000707649fd40cd  pop rdx
0000707649fd40ce  pop rcx
0000707649fd40cf  pop rax
0000707649fd40d0  add rsp, 0x08
0000707649fd40d4  jmp 0x0000707649FD0094
0000707649fd40d9  sub rsp, 0x08
0000707649fd40dd  push rax
0000707649fd40de  push rcx
0000707649fd40df  push rdx
0000707649fd40e0  push rdi
0000707649fd40e1  push rsi
0000707649fd40e2  push r8
0000707649fd40e4  push r9
0000707649fd40e6  push r10
0000707649fd40e8  push r11
0000707649fd40ea  sub rsp, 0xF0
0000707649fd40f1  vmovaps [rsp], xmm0
0000707649fd40f6  vmovaps [rsp+0x10], xmm1
0000707649fd40fc  vmovaps [rsp+0x20], xmm2
0000707649fd4102  vmovaps [rsp+0x30], xmm3
0000707649fd4108  vmovaps [rsp+0x40], xmm4
0000707649fd410e  vmovaps [rsp+0x50], xmm5
0000707649fd4114  vmovaps [rsp+0x60], xmm6
0000707649fd411a  vmovaps [rsp+0x70], xmm7
0000707649fd4120  vmovaps [rsp+0x80], xmm8
0000707649fd4129  vmovaps [rsp+0x90], xmm9
0000707649fd4132  vmovaps [rsp+0xA0], xmm10
0000707649fd413b  vmovaps [rsp+0xB0], xmm11
0000707649fd4144  vmovaps [rsp+0xC0], xmm12
0000707649fd414d  vmovaps [rsp+0xD0], xmm13
0000707649fd4156  vmovaps [rsp+0xE0], xmm15
0000707649fd415f  sub rsp, 0x30
0000707649fd4163  movaps [rsp], xmm14
0000707649fd4168  movaps [rsp+0x10], xmm12
0000707649fd416e  movaps [rsp+0x20], xmm9
0000707649fd4174  lea rdi, [rsp]
0000707649fd4178  mov esi, 0x00
0000707649fd417d  mov rax, 0x59CB0B054530
0000707649fd4187  call rax
0000707649fd4189  movaps xmm14, [rsp]
0000707649fd418e  add rsp, 0x30
0000707649fd4192  vmovaps xmm0, [rsp]
0000707649fd4197  vmovaps xmm1, [rsp+0x10]
0000707649fd419d  vmovaps xmm2, [rsp+0x20]
0000707649fd41a3  vmovaps xmm3, [rsp+0x30]
0000707649fd41a9  vmovaps xmm4, [rsp+0x40]
0000707649fd41af  vmovaps xmm5, [rsp+0x50]
0000707649fd41b5  vmovaps xmm6, [rsp+0x60]
0000707649fd41bb  vmovaps xmm7, [rsp+0x70]
0000707649fd41c1  vmovaps xmm8, [rsp+0x80]
0000707649fd41ca  vmovaps xmm9, [rsp+0x90]
0000707649fd41d3  vmovaps xmm10, [rsp+0xA0]
0000707649fd41dc  vmovaps xmm11, [rsp+0xB0]
0000707649fd41e5  vmovaps xmm12, [rsp+0xC0]
0000707649fd41ee  vmovaps xmm13, [rsp+0xD0]
0000707649fd41f7  vmovaps xmm15, [rsp+0xE0]
0000707649fd4200  add rsp, 0xF0
0000707649fd4207  pop r11
0000707649fd4209  pop r10
0000707649fd420b  pop r9
0000707649fd420d  pop r8
0000707649fd420f  pop rsi
0000707649fd4210  pop rdi
0000707649fd4211  pop rdx
0000707649fd4212  pop rcx
0000707649fd4213  pop rax
0000707649fd4214  add rsp, 0x08
0000707649fd4218  jmp 0x0000707649FD00AE
0000707649fd421d  sub rsp, 0x08
0000707649fd4221  push rax
0000707649fd4222  push rcx
0000707649fd4223  push rdx
0000707649fd4224  push rdi
0000707649fd4225  push rsi
0000707649fd4226  push r8
0000707649fd4228  push r9
0000707649fd422a  push r10
0000707649fd422c  push r11
0000707649fd422e  sub rsp, 0xF0
0000707649fd4235  vmovaps [rsp], xmm0
0000707649fd423a  vmovaps [rsp+0x10], xmm1
0000707649fd4240  vmovaps [rsp+0x20], xmm2
0000707649fd4246  vmovaps [rsp+0x30], xmm3
0000707649fd424c  vmovaps [rsp+0x40], xmm4
0000707649fd4252  vmovaps [rsp+0x50], xmm5
0000707649fd4258  vmovaps [rsp+0x60], xmm6
0000707649fd425e  vmovaps [rsp+0x70], xmm7
0000707649fd4264  vmovaps [rsp+0x80], xmm8
0000707649fd426d  vmovaps [rsp+0x90], xmm10
0000707649fd4276  vmovaps [rsp+0xA0], xmm11
0000707649fd427f  vmovaps [rsp+0xB0], xmm12
0000707649fd4288  vmovaps [rsp+0xC0], xmm13
0000707649fd4291  vmovaps [rsp+0xD0], xmm14
0000707649fd429a  vmovaps [rsp+0xE0], xmm15
0000707649fd42a3  sub rsp, 0x30
0000707649fd42a7  movaps [rsp], xmm9
0000707649fd42ac  movaps [rsp+0x10], xmm7
0000707649fd42b1  movaps [rsp+0x20], xmm12
0000707649fd42b7  lea rdi, [rsp]
0000707649fd42bb  mov esi, 0x00
0000707649fd42c0  mov rax, 0x59CB0B054530
0000707649fd42ca  call rax
0000707649fd42cc  movaps xmm9, [rsp]
0000707649fd42d1  add rsp, 0x30
0000707649fd42d5  vmovaps xmm0, [rsp]
0000707649fd42da  vmovaps xmm1, [rsp+0x10]
0000707649fd42e0  vmovaps xmm2, [rsp+0x20]
0000707649fd42e6  vmovaps xmm3, [rsp+0x30]
0000707649fd42ec  vmovaps xmm4, [rsp+0x40]
0000707649fd42f2  vmovaps xmm5, [rsp+0x50]
0000707649fd42f8  vmovaps xmm6, [rsp+0x60]
0000707649fd42fe  vmovaps xmm7, [rsp+0x70]
0000707649fd4304  vmovaps xmm8, [rsp+0x80]
0000707649fd430d  vmovaps xmm10, [rsp+0x90]
0000707649fd4316  vmovaps xmm11, [rsp+0xA0]
0000707649fd431f  vmovaps xmm12, [rsp+0xB0]
0000707649fd4328  vmovaps xmm13, [rsp+0xC0]
0000707649fd4331  vmovaps xmm14, [rsp+0xD0]
0000707649fd433a  vmovaps xmm15, [rsp+0xE0]
0000707649fd4343  add rsp, 0xF0
0000707649fd434a  pop r11
0000707649fd434c  pop r10
0000707649fd434e  pop r9
0000707649fd4350  pop r8
0000707649fd4352  pop rsi
0000707649fd4353  pop rdi
0000707649fd4354  pop rdx
0000707649fd4355  pop rcx
0000707649fd4356  pop rax
0000707649fd4357  add rsp, 0x08
0000707649fd435b  jmp 0x0000707649FD00DD
0000707649fd4360  sub rsp, 0x08
0000707649fd4364  push rax
0000707649fd4365  push rcx
0000707649fd4366  push rdx
0000707649fd4367  push rdi
0000707649fd4368  push rsi
0000707649fd4369  push r8
0000707649fd436b  push r9
0000707649fd436d  push r10
0000707649fd436f  push r11
0000707649fd4371  sub rsp, 0xF0
0000707649fd4378  vmovaps [rsp], xmm0
0000707649fd437d  vmovaps [rsp+0x10], xmm1
0000707649fd4383  vmovaps [rsp+0x20], xmm2
0000707649fd4389  vmovaps [rsp+0x30], xmm3
0000707649fd438f  vmovaps [rsp+0x40], xmm4
0000707649fd4395  vmovaps [rsp+0x50], xmm5
0000707649fd439b  vmovaps [rsp+0x60], xmm6
0000707649fd43a1  vmovaps [rsp+0x70], xmm7
0000707649fd43a7  vmovaps [rsp+0x80], xmm8
0000707649fd43b0  vmovaps [rsp+0x90], xmm9
0000707649fd43b9  vmovaps [rsp+0xA0], xmm10
0000707649fd43c2  vmovaps [rsp+0xB0], xmm11
0000707649fd43cb  vmovaps [rsp+0xC0], xmm13
0000707649fd43d4  vmovaps [rsp+0xD0], xmm14
0000707649fd43dd  vmovaps [rsp+0xE0], xmm15
0000707649fd43e6  sub rsp, 0x30
0000707649fd43ea  movaps [rsp], xmm12
0000707649fd43ef  movaps [rsp+0x10], xmm15
0000707649fd43f5  movaps [rsp+0x20], xmm11
0000707649fd43fb  lea rdi, [rsp]
0000707649fd43ff  mov esi, 0x00
0000707649fd4404  mov rax, 0x59CB0B054530
0000707649fd440e  call rax
0000707649fd4410  movaps xmm12, [rsp]
0000707649fd4415  add rsp, 0x30
0000707649fd4419  vmovaps xmm0, [rsp]
0000707649fd441e  vmovaps xmm1, [rsp+0x10]
0000707649fd4424  vmovaps xmm2, [rsp+0x20]
0000707649fd442a  vmovaps xmm3, [rsp+0x30]
0000707649fd4430  vmovaps xmm4, [rsp+0x40]
0000707649fd4436  vmovaps xmm5, [rsp+0x50]
0000707649fd443c  vmovaps xmm6, [rsp+0x60]
0000707649fd4442  vmovaps xmm7, [rsp+0x70]
0000707649fd4448  vmovaps xmm8, [rsp+0x80]
0000707649fd4451  vmovaps xmm9, [rsp+0x90]
0000707649fd445a  vmovaps xmm10, [rsp+0xA0]
0000707649fd4463  vmovaps xmm11, [rsp+0xB0]
0000707649fd446c  vmovaps xmm13, [rsp+0xC0]
0000707649fd4475  vmovaps xmm14, [rsp+0xD0]
0000707649fd447e  vmovaps xmm15, [rsp+0xE0]
0000707649fd4487  add rsp, 0xF0
0000707649fd448e  pop r11
0000707649fd4490  pop r10
0000707649fd4492  pop r9
0000707649fd4494  pop r8
0000707649fd4496  pop rsi
0000707649fd4497  pop rdi
0000707649fd4498  pop rdx
0000707649fd4499  pop rcx
0000707649fd449a  pop rax
0000707649fd449b  add rsp, 0x08
0000707649fd449f  jmp 0x0000707649FD00F7
0000707649fd44a4  sub rsp, 0x08
0000707649fd44a8  push rax
0000707649fd44a9  push rcx
0000707649fd44aa  push rdx
0000707649fd44ab  push rdi
0000707649fd44ac  push rsi
0000707649fd44ad  push r8
0000707649fd44af  push r9
0000707649fd44b1  push r10
0000707649fd44b3  push r11
0000707649fd44b5  sub rsp, 0xF0
0000707649fd44bc  vmovaps [rsp], xmm0
0000707649fd44c1  vmovaps [rsp+0x10], xmm1
0000707649fd44c7  vmovaps [rsp+0x20], xmm2
0000707649fd44cd  vmovaps [rsp+0x30], xmm3
0000707649fd44d3  vmovaps [rsp+0x40], xmm4
0000707649fd44d9  vmovaps [rsp+0x50], xmm5
0000707649fd44df  vmovaps [rsp+0x60], xmm6
0000707649fd44e5  vmovaps [rsp+0x70], xmm7
0000707649fd44eb  vmovaps [rsp+0x80], xmm8
0000707649fd44f4  vmovaps [rsp+0x90], xmm9
0000707649fd44fd  vmovaps [rsp+0xA0], xmm10
0000707649fd4506  vmovaps [rsp+0xB0], xmm12
0000707649fd450f  vmovaps [rsp+0xC0], xmm13
0000707649fd4518  vmovaps [rsp+0xD0], xmm14
0000707649fd4521  vmovaps [rsp+0xE0], xmm15
0000707649fd452a  sub rsp, 0x30
0000707649fd452e  movaps [rsp], xmm11
0000707649fd4533  movaps [rsp+0x10], xmm7
0000707649fd4538  movaps [rsp+0x20], xmm15
0000707649fd453e  lea rdi, [rsp]
0000707649fd4542  mov esi, 0x00
0000707649fd4547  mov rax, 0x59CB0B054530
0000707649fd4551  call rax
0000707649fd4553  movaps xmm11, [rsp]
0000707649fd4558  add rsp, 0x30
0000707649fd455c  vmovaps xmm0, [rsp]
0000707649fd4561  vmovaps xmm1, [rsp+0x10]
0000707649fd4567  vmovaps xmm2, [rsp+0x20]
0000707649fd456d  vmovaps xmm3, [rsp+0x30]
0000707649fd4573  vmovaps xmm4, [rsp+0x40]
0000707649fd4579  vmovaps xmm5, [rsp+0x50]
0000707649fd457f  vmovaps xmm6, [rsp+0x60]
0000707649fd4585  vmovaps xmm7, [rsp+0x70]
0000707649fd458b  vmovaps xmm8, [rsp+0x80]
0000707649fd4594  vmovaps xmm9, [rsp+0x90]
0000707649fd459d  vmovaps xmm10, [rsp+0xA0]
0000707649fd45a6  vmovaps xmm12, [rsp+0xB0]
0000707649fd45af  vmovaps xmm13, [rsp+0xC0]
0000707649fd45b8  vmovaps xmm14, [rsp+0xD0]
0000707649fd45c1  vmovaps xmm15, [rsp+0xE0]
0000707649fd45ca  add rsp, 0xF0
0000707649fd45d1  pop r11
0000707649fd45d3  pop r10
0000707649fd45d5  pop r9
0000707649fd45d7  pop r8
0000707649fd45d9  pop rsi
0000707649fd45da  pop rdi
0000707649fd45db  pop rdx
0000707649fd45dc  pop rcx
0000707649fd45dd  pop rax
0000707649fd45de  add rsp, 0x08
0000707649fd45e2  jmp 0x0000707649FD0123
0000707649fd45e7  sub rsp, 0x08
0000707649fd45eb  push rax
0000707649fd45ec  push rcx
0000707649fd45ed  push rdx
0000707649fd45ee  push rdi
0000707649fd45ef  push rsi
0000707649fd45f0  push r8
0000707649fd45f2  push r9
0000707649fd45f4  push r10
0000707649fd45f6  push r11
0000707649fd45f8  sub rsp, 0xF0
0000707649fd45ff  vmovaps [rsp], xmm0
0000707649fd4604  vmovaps [rsp+0x10], xmm1
0000707649fd460a  vmovaps [rsp+0x20], xmm2
0000707649fd4610  vmovaps [rsp+0x30], xmm3
0000707649fd4616  vmovaps [rsp+0x40], xmm4
0000707649fd461c  vmovaps [rsp+0x50], xmm5
0000707649fd4622  vmovaps [rsp+0x60], xmm6
0000707649fd4628  vmovaps [rsp+0x70], xmm7
0000707649fd462e  vmovaps [rsp+0x80], xmm8
0000707649fd4637  vmovaps [rsp+0x90], xmm9
0000707649fd4640  vmovaps [rsp+0xA0], xmm10
0000707649fd4649  vmovaps [rsp+0xB0], xmm11
0000707649fd4652  vmovaps [rsp+0xC0], xmm12
0000707649fd465b  vmovaps [rsp+0xD0], xmm13
0000707649fd4664  vmovaps [rsp+0xE0], xmm14
0000707649fd466d  sub rsp, 0x30
0000707649fd4671  movaps [rsp], xmm15
0000707649fd4676  movaps [rsp+0x10], xmm10
0000707649fd467c  movaps [rsp+0x20], xmm13
0000707649fd4682  lea rdi, [rsp]
0000707649fd4686  mov esi, 0x00
0000707649fd468b  mov rax, 0x59CB0B054530
0000707649fd4695  call rax
0000707649fd4697  movaps xmm15, [rsp]
0000707649fd469c  add rsp, 0x30
0000707649fd46a0  vmovaps xmm0, [rsp]
0000707649fd46a5  vmovaps xmm1, [rsp+0x10]
0000707649fd46ab  vmovaps xmm2, [rsp+0x20]
0000707649fd46b1  vmovaps xmm3, [rsp+0x30]
0000707649fd46b7  vmovaps xmm4, [rsp+0x40]
0000707649fd46bd  vmovaps xmm5, [rsp+0x50]
0000707649fd46c3  vmovaps xmm6, [rsp+0x60]
0000707649fd46c9  vmovaps xmm7, [rsp+0x70]
0000707649fd46cf  vmovaps xmm8, [rsp+0x80]
0000707649fd46d8  vmovaps xmm9, [rsp+0x90]
0000707649fd46e1  vmovaps xmm10, [rsp+0xA0]
0000707649fd46ea  vmovaps xmm11, [rsp+0xB0]
0000707649fd46f3  vmovaps xmm12, [rsp+0xC0]
0000707649fd46fc  vmovaps xmm13, [rsp+0xD0]
0000707649fd4705  vmovaps xmm14, [rsp+0xE0]
0000707649fd470e  add rsp, 0xF0
0000707649fd4715  pop r11
0000707649fd4717  pop r10
0000707649fd4719  pop r9
0000707649fd471b  pop r8
0000707649fd471d  pop rsi
0000707649fd471e  pop rdi
0000707649fd471f  pop rdx
0000707649fd4720  pop rcx
0000707649fd4721  pop rax
0000707649fd4722  add rsp, 0x08
0000707649fd4726  jmp 0x0000707649FD013D
0000707649fd472b  sub rsp, 0x08
0000707649fd472f  push rax
0000707649fd4730  push rcx
0000707649fd4731  push rdx
0000707649fd4732  push rdi
0000707649fd4733  push rsi
0000707649fd4734  push r8
0000707649fd4736  push r9
0000707649fd4738  push r10
0000707649fd473a  push r11
0000707649fd473c  sub rsp, 0xF0
0000707649fd4743  vmovaps [rsp], xmm0
0000707649fd4748  vmovaps [rsp+0x10], xmm1
0000707649fd474e  vmovaps [rsp+0x20], xmm2
0000707649fd4754  vmovaps [rsp+0x30], xmm3
0000707649fd475a  vmovaps [rsp+0x40], xmm4
0000707649fd4760  vmovaps [rsp+0x50], xmm5
0000707649fd4766  vmovaps [rsp+0x60], xmm6
0000707649fd476c  vmovaps [rsp+0x70], xmm7
0000707649fd4772  vmovaps [rsp+0x80], xmm8
0000707649fd477b  vmovaps [rsp+0x90], xmm9
0000707649fd4784  vmovaps [rsp+0xA0], xmm11
0000707649fd478d  vmovaps [rsp+0xB0], xmm12
0000707649fd4796  vmovaps [rsp+0xC0], xmm13
0000707649fd479f  vmovaps [rsp+0xD0], xmm14
0000707649fd47a8  vmovaps [rsp+0xE0], xmm15
0000707649fd47b1  sub rsp, 0x30
0000707649fd47b5  movaps [rsp], xmm10
0000707649fd47ba  movaps [rsp+0x10], xmm7
0000707649fd47bf  movaps [rsp+0x20], xmm13
0000707649fd47c5  lea rdi, [rsp]
0000707649fd47c9  mov esi, 0x00
0000707649fd47ce  mov rax, 0x59CB0B054530
0000707649fd47d8  call rax
0000707649fd47da  movaps xmm10, [rsp]
0000707649fd47df  add rsp, 0x30
0000707649fd47e3  vmovaps xmm0, [rsp]
0000707649fd47e8  vmovaps xmm1, [rsp+0x10]
0000707649fd47ee  vmovaps xmm2, [rsp+0x20]
0000707649fd47f4  vmovaps xmm3, [rsp+0x30]
0000707649fd47fa  vmovaps xmm4, [rsp+0x40]
0000707649fd4800  vmovaps xmm5, [rsp+0x50]
0000707649fd4806  vmovaps xmm6, [rsp+0x60]
0000707649fd480c  vmovaps xmm7, [rsp+0x70]
0000707649fd4812  vmovaps xmm8, [rsp+0x80]
0000707649fd481b  vmovaps xmm9, [rsp+0x90]
0000707649fd4824  vmovaps xmm11, [rsp+0xA0]
0000707649fd482d  vmovaps xmm12, [rsp+0xB0]
0000707649fd4836  vmovaps xmm13, [rsp+0xC0]
0000707649fd483f  vmovaps xmm14, [rsp+0xD0]
0000707649fd4848  vmovaps xmm15, [rsp+0xE0]
0000707649fd4851  add rsp, 0xF0
0000707649fd4858  pop r11
0000707649fd485a  pop r10
0000707649fd485c  pop r9
0000707649fd485e  pop r8
0000707649fd4860  pop rsi
0000707649fd4861  pop rdi
0000707649fd4862  pop rdx
0000707649fd4863  pop rcx
0000707649fd4864  pop rax
0000707649fd4865  add rsp, 0x08
0000707649fd4869  jmp 0x0000707649FD0169
0000707649fd486e  sub rsp, 0x08
0000707649fd4872  push rax
0000707649fd4873  push rcx
0000707649fd4874  push rdx
0000707649fd4875  push rdi
0000707649fd4876  push rsi
0000707649fd4877  push r8
0000707649fd4879  push r9
0000707649fd487b  push r10
0000707649fd487d  push r11
0000707649fd487f  sub rsp, 0xF0
0000707649fd4886  vmovaps [rsp], xmm0
0000707649fd488b  vmovaps [rsp+0x10], xmm1
0000707649fd4891  vmovaps [rsp+0x20], xmm2
0000707649fd4897  vmovaps [rsp+0x30], xmm3
0000707649fd489d  vmovaps [rsp+0x40], xmm4
0000707649fd48a3  vmovaps [rsp+0x50], xmm5
0000707649fd48a9  vmovaps [rsp+0x60], xmm6
0000707649fd48af  vmovaps [rsp+0x70], xmm7
0000707649fd48b5  vmovaps [rsp+0x80], xmm8
0000707649fd48be  vmovaps [rsp+0x90], xmm9
0000707649fd48c7  vmovaps [rsp+0xA0], xmm10
0000707649fd48d0  vmovaps [rsp+0xB0], xmm11
0000707649fd48d9  vmovaps [rsp+0xC0], xmm12
0000707649fd48e2  vmovaps [rsp+0xD0], xmm14
0000707649fd48eb  vmovaps [rsp+0xE0], xmm15
0000707649fd48f4  sub rsp, 0x30
0000707649fd48f8  movaps [rsp], xmm13
0000707649fd48fd  movaps [rsp+0x10], xmm1
0000707649fd4902  movaps [rsp+0x20], xmm8
0000707649fd4908  lea rdi, [rsp]
0000707649fd490c  mov esi, 0x00
0000707649fd4911  mov rax, 0x59CB0B054530
0000707649fd491b  call rax
0000707649fd491d  movaps xmm13, [rsp]
0000707649fd4922  add rsp, 0x30
0000707649fd4926  vmovaps xmm0, [rsp]
0000707649fd492b  vmovaps xmm1, [rsp+0x10]
0000707649fd4931  vmovaps xmm2, [rsp+0x20]
0000707649fd4937  vmovaps xmm3, [rsp+0x30]
0000707649fd493d  vmovaps xmm4, [rsp+0x40]
0000707649fd4943  vmovaps xmm5, [rsp+0x50]
0000707649fd4949  vmovaps xmm6, [rsp+0x60]
0000707649fd494f  vmovaps xmm7, [rsp+0x70]
0000707649fd4955  vmovaps xmm8, [rsp+0x80]
0000707649fd495e  vmovaps xmm9, [rsp+0x90]
0000707649fd4967  vmovaps xmm10, [rsp+0xA0]
0000707649fd4970  vmovaps xmm11, [rsp+0xB0]
0000707649fd4979  vmovaps xmm12, [rsp+0xC0]
0000707649fd4982  vmovaps xmm14, [rsp+0xD0]
0000707649fd498b  vmovaps xmm15, [rsp+0xE0]
0000707649fd4994  add rsp, 0xF0
0000707649fd499b  pop r11
0000707649fd499d  pop r10
0000707649fd499f  pop r9
0000707649fd49a1  pop r8
0000707649fd49a3  pop rsi
0000707649fd49a4  pop rdi
0000707649fd49a5  pop rdx
0000707649fd49a6  pop rcx
0000707649fd49a7  pop rax
0000707649fd49a8  add rsp, 0x08
0000707649fd49ac  jmp 0x0000707649FD0183
0000707649fd49b1  call 0x0000707649DFF430
0000707649fd49b6  jmp 0x0000707649FD018D
0000707649fd49bb  sub rsp, 0x08
0000707649fd49bf  push rax
0000707649fd49c0  push rcx
0000707649fd49c1  push rdx
0000707649fd49c2  push rdi
0000707649fd49c3  push rsi
0000707649fd49c4  push r8
0000707649fd49c6  push r9
0000707649fd49c8  push r10
0000707649fd49ca  push r11
0000707649fd49cc  sub rsp, 0xF0
0000707649fd49d3  vmovaps [rsp], xmm0
0000707649fd49d8  vmovaps [rsp+0x10], xmm1
0000707649fd49de  vmovaps [rsp+0x20], xmm2
0000707649fd49e4  vmovaps [rsp+0x30], xmm3
0000707649fd49ea  vmovaps [rsp+0x40], xmm4
0000707649fd49f0  vmovaps [rsp+0x50], xmm5
0000707649fd49f6  vmovaps [rsp+0x60], xmm6
0000707649fd49fc  vmovaps [rsp+0x70], xmm7
0000707649fd4a02  vmovaps [rsp+0x80], xmm9
0000707649fd4a0b  vmovaps [rsp+0x90], xmm10
0000707649fd4a14  vmovaps [rsp+0xA0], xmm11
0000707649fd4a1d  vmovaps [rsp+0xB0], xmm12
0000707649fd4a26  vmovaps [rsp+0xC0], xmm13
0000707649fd4a2f  vmovaps [rsp+0xD0], xmm14
0000707649fd4a38  vmovaps [rsp+0xE0], xmm15
0000707649fd4a41  sub rsp, 0x30
0000707649fd4a45  movaps [rsp], xmm8
0000707649fd4a4a  movaps [rsp+0x10], xmm14
0000707649fd4a50  movaps [rsp+0x20], xmm9
0000707649fd4a56  lea rdi, [rsp]
0000707649fd4a5a  mov esi, 0x00
0000707649fd4a5f  mov rax, 0x59CB0B054530
0000707649fd4a69  call rax
0000707649fd4a6b  movaps xmm8, [rsp]
0000707649fd4a70  add rsp, 0x30
0000707649fd4a74  vmovaps xmm0, [rsp]
0000707649fd4a79  vmovaps xmm1, [rsp+0x10]
0000707649fd4a7f  vmovaps xmm2, [rsp+0x20]
0000707649fd4a85  vmovaps xmm3, [rsp+0x30]
0000707649fd4a8b  vmovaps xmm4, [rsp+0x40]
0000707649fd4a91  vmovaps xmm5, [rsp+0x50]
0000707649fd4a97  vmovaps xmm6, [rsp+0x60]
0000707649fd4a9d  vmovaps xmm7, [rsp+0x70]
0000707649fd4aa3  vmovaps xmm9, [rsp+0x80]
0000707649fd4aac  vmovaps xmm10, [rsp+0x90]
0000707649fd4ab5  vmovaps xmm11, [rsp+0xA0]
0000707649fd4abe  vmovaps xmm12, [rsp+0xB0]
0000707649fd4ac7  vmovaps xmm13, [rsp+0xC0]
0000707649fd4ad0  vmovaps xmm14, [rsp+0xD0]
0000707649fd4ad9  vmovaps xmm15, [rsp+0xE0]
0000707649fd4ae2  add rsp, 0xF0
0000707649fd4ae9  pop r11
0000707649fd4aeb  pop r10
0000707649fd4aed  pop r9
0000707649fd4aef  pop r8
0000707649fd4af1  pop rsi
0000707649fd4af2  pop rdi
0000707649fd4af3  pop rdx
0000707649fd4af4  pop rcx
0000707649fd4af5  pop rax
0000707649fd4af6  add rsp, 0x08
0000707649fd4afa  jmp 0x0000707649FD01AF
0000707649fd4aff  sub rsp, 0x08
0000707649fd4b03  push rax
0000707649fd4b04  push rcx
0000707649fd4b05  push rdx
0000707649fd4b06  push rdi
0000707649fd4b07  push rsi
0000707649fd4b08  push r8
0000707649fd4b0a  push r9
0000707649fd4b0c  push r10
0000707649fd4b0e  push r11
0000707649fd4b10  sub rsp, 0xF0
0000707649fd4b17  vmovaps [rsp], xmm0
0000707649fd4b1c  vmovaps [rsp+0x10], xmm1
0000707649fd4b22  vmovaps [rsp+0x20], xmm2
0000707649fd4b28  vmovaps [rsp+0x30], xmm3
0000707649fd4b2e  vmovaps [rsp+0x40], xmm4
0000707649fd4b34  vmovaps [rsp+0x50], xmm5
0000707649fd4b3a  vmovaps [rsp+0x60], xmm6
0000707649fd4b40  vmovaps [rsp+0x70], xmm7
0000707649fd4b46  vmovaps [rsp+0x80], xmm8
0000707649fd4b4f  vmovaps [rsp+0x90], xmm10
0000707649fd4b58  vmovaps [rsp+0xA0], xmm11
0000707649fd4b61  vmovaps [rsp+0xB0], xmm12
0000707649fd4b6a  vmovaps [rsp+0xC0], xmm13
0000707649fd4b73  vmovaps [rsp+0xD0], xmm14
0000707649fd4b7c  vmovaps [rsp+0xE0], xmm15
0000707649fd4b85  sub rsp, 0x30
0000707649fd4b89  movaps [rsp], xmm9
0000707649fd4b8e  movaps [rsp+0x10], xmm1
0000707649fd4b93  movaps [rsp+0x20], xmm14
0000707649fd4b99  lea rdi, [rsp]
0000707649fd4b9d  mov esi, 0x00
0000707649fd4ba2  mov rax, 0x59CB0B054530
0000707649fd4bac  call rax
0000707649fd4bae  movaps xmm9, [rsp]
0000707649fd4bb3  add rsp, 0x30
0000707649fd4bb7  vmovaps xmm0, [rsp]
0000707649fd4bbc  vmovaps xmm1, [rsp+0x10]
0000707649fd4bc2  vmovaps xmm2, [rsp+0x20]
0000707649fd4bc8  vmovaps xmm3, [rsp+0x30]
0000707649fd4bce  vmovaps xmm4, [rsp+0x40]
0000707649fd4bd4  vmovaps xmm5, [rsp+0x50]
0000707649fd4bda  vmovaps xmm6, [rsp+0x60]
0000707649fd4be0  vmovaps xmm7, [rsp+0x70]
0000707649fd4be6  vmovaps xmm8, [rsp+0x80]
0000707649fd4bef  vmovaps xmm10, [rsp+0x90]
0000707649fd4bf8  vmovaps xmm11, [rsp+0xA0]
0000707649fd4c01  vmovaps xmm12, [rsp+0xB0]
0000707649fd4c0a  vmovaps xmm13, [rsp+0xC0]
0000707649fd4c13  vmovaps xmm14, [rsp+0xD0]
0000707649fd4c1c  vmovaps xmm15, [rsp+0xE0]
0000707649fd4c25  add rsp, 0xF0
0000707649fd4c2c  pop r11
0000707649fd4c2e  pop r10
0000707649fd4c30  pop r9
0000707649fd4c32  pop r8
0000707649fd4c34  pop rsi
0000707649fd4c35  pop rdi
0000707649fd4c36  pop rdx
0000707649fd4c37  pop rcx
0000707649fd4c38  pop rax
0000707649fd4c39  add rsp, 0x08
0000707649fd4c3d  jmp 0x0000707649FD01DD
0000707649fd4c42  sub rsp, 0x08
0000707649fd4c46  push rax
0000707649fd4c47  push rcx
0000707649fd4c48  push rdx
0000707649fd4c49  push rdi
0000707649fd4c4a  push rsi
0000707649fd4c4b  push r8
0000707649fd4c4d  push r9
0000707649fd4c4f  push r10
0000707649fd4c51  push r11
0000707649fd4c53  sub rsp, 0xF0
0000707649fd4c5a  vmovaps [rsp], xmm0
0000707649fd4c5f  vmovaps [rsp+0x10], xmm1
0000707649fd4c65  vmovaps [rsp+0x20], xmm2
0000707649fd4c6b  vmovaps [rsp+0x30], xmm3
0000707649fd4c71  vmovaps [rsp+0x40], xmm4
0000707649fd4c77  vmovaps [rsp+0x50], xmm5
0000707649fd4c7d  vmovaps [rsp+0x60], xmm6
0000707649fd4c83  vmovaps [rsp+0x70], xmm7
0000707649fd4c89  vmovaps [rsp+0x80], xmm8
0000707649fd4c92  vmovaps [rsp+0x90], xmm9
0000707649fd4c9b  vmovaps [rsp+0xA0], xmm10
0000707649fd4ca4  vmovaps [rsp+0xB0], xmm11
0000707649fd4cad  vmovaps [rsp+0xC0], xmm12
0000707649fd4cb6  vmovaps [rsp+0xD0], xmm13
0000707649fd4cbf  vmovaps [rsp+0xE0], xmm15
0000707649fd4cc8  sub rsp, 0x30
0000707649fd4ccc  movaps [rsp], xmm14
0000707649fd4cd1  movaps [rsp+0x10], xmm4
0000707649fd4cd6  movaps [rsp+0x20], xmm1
0000707649fd4cdb  lea rdi, [rsp]
0000707649fd4cdf  mov esi, 0x00
0000707649fd4ce4  mov rax, 0x59CB0B054530
0000707649fd4cee  call rax
0000707649fd4cf0  movaps xmm14, [rsp]
0000707649fd4cf5  add rsp, 0x30
0000707649fd4cf9  vmovaps xmm0, [rsp]
0000707649fd4cfe  vmovaps xmm1, [rsp+0x10]
0000707649fd4d04  vmovaps xmm2, [rsp+0x20]
0000707649fd4d0a  vmovaps xmm3, [rsp+0x30]
0000707649fd4d10  vmovaps xmm4, [rsp+0x40]
0000707649fd4d16  vmovaps xmm5, [rsp+0x50]
0000707649fd4d1c  vmovaps xmm6, [rsp+0x60]
0000707649fd4d22  vmovaps xmm7, [rsp+0x70]
0000707649fd4d28  vmovaps xmm8, [rsp+0x80]
0000707649fd4d31  vmovaps xmm9, [rsp+0x90]
0000707649fd4d3a  vmovaps xmm10, [rsp+0xA0]
0000707649fd4d43  vmovaps xmm11, [rsp+0xB0]
0000707649fd4d4c  vmovaps xmm12, [rsp+0xC0]
0000707649fd4d55  vmovaps xmm13, [rsp+0xD0]
0000707649fd4d5e  vmovaps xmm15, [rsp+0xE0]
0000707649fd4d67  add rsp, 0xF0
0000707649fd4d6e  pop r11
0000707649fd4d70  pop r10
0000707649fd4d72  pop r9
0000707649fd4d74  pop r8
0000707649fd4d76  pop rsi
0000707649fd4d77  pop rdi
0000707649fd4d78  pop rdx
0000707649fd4d79  pop rcx
0000707649fd4d7a  pop rax
0000707649fd4d7b  add rsp, 0x08
0000707649fd4d7f  jmp 0x0000707649FD0203
0000707649fd4d84  sub rsp, 0x08
0000707649fd4d88  push rax
0000707649fd4d89  push rcx
0000707649fd4d8a  push rdx
0000707649fd4d8b  push rdi
0000707649fd4d8c  push rsi
0000707649fd4d8d  push r8
0000707649fd4d8f  push r9
0000707649fd4d91  push r10
0000707649fd4d93  push r11
0000707649fd4d95  sub rsp, 0xF0
0000707649fd4d9c  vmovaps [rsp], xmm0
0000707649fd4da1  vmovaps [rsp+0x10], xmm2
0000707649fd4da7  vmovaps [rsp+0x20], xmm3
0000707649fd4dad  vmovaps [rsp+0x30], xmm4
0000707649fd4db3  vmovaps [rsp+0x40], xmm5
0000707649fd4db9  vmovaps [rsp+0x50], xmm6
0000707649fd4dbf  vmovaps [rsp+0x60], xmm7
0000707649fd4dc5  vmovaps [rsp+0x70], xmm8
0000707649fd4dcb  vmovaps [rsp+0x80], xmm9
0000707649fd4dd4  vmovaps [rsp+0x90], xmm10
0000707649fd4ddd  vmovaps [rsp+0xA0], xmm11
0000707649fd4de6  vmovaps [rsp+0xB0], xmm12
0000707649fd4def  vmovaps [rsp+0xC0], xmm13
0000707649fd4df8  vmovaps [rsp+0xD0], xmm14
0000707649fd4e01  vmovaps [rsp+0xE0], xmm15
0000707649fd4e0a  sub rsp, 0x30
0000707649fd4e0e  movaps [rsp], xmm1
0000707649fd4e12  movaps [rsp+0x10], xmm12
0000707649fd4e18  movaps [rsp+0x20], xmm11
0000707649fd4e1e  lea rdi, [rsp]
0000707649fd4e22  mov esi, 0x00
0000707649fd4e27  mov rax, 0x59CB0B054530
0000707649fd4e31  call rax
0000707649fd4e33  movaps xmm1, [rsp]
0000707649fd4e37  add rsp, 0x30
0000707649fd4e3b  vmovaps xmm0, [rsp]
0000707649fd4e40  vmovaps xmm2, [rsp+0x10]
0000707649fd4e46  vmovaps xmm3, [rsp+0x20]
0000707649fd4e4c  vmovaps xmm4, [rsp+0x30]
0000707649fd4e52  vmovaps xmm5, [rsp+0x40]
0000707649fd4e58  vmovaps xmm6, [rsp+0x50]
0000707649fd4e5e  vmovaps xmm7, [rsp+0x60]
0000707649fd4e64  vmovaps xmm8, [rsp+0x70]
0000707649fd4e6a  vmovaps xmm9, [rsp+0x80]
0000707649fd4e73  vmovaps xmm10, [rsp+0x90]
0000707649fd4e7c  vmovaps xmm11, [rsp+0xA0]
0000707649fd4e85  vmovaps xmm12, [rsp+0xB0]
0000707649fd4e8e  vmovaps xmm13, [rsp+0xC0]
0000707649fd4e97  vmovaps xmm14, [rsp+0xD0]
0000707649fd4ea0  vmovaps xmm15, [rsp+0xE0]
0000707649fd4ea9  add rsp, 0xF0
0000707649fd4eb0  pop r11
0000707649fd4eb2  pop r10
0000707649fd4eb4  pop r9
0000707649fd4eb6  pop r8
0000707649fd4eb8  pop rsi
0000707649fd4eb9  pop rdi
0000707649fd4eba  pop rdx
0000707649fd4ebb  pop rcx
0000707649fd4ebc  pop rax
0000707649fd4ebd  add rsp, 0x08
0000707649fd4ec1  jmp 0x0000707649FD0224
0000707649fd4ec6  call 0x0000707649EE20A0
0000707649fd4ecb  jmp 0x0000707649FD0232
0000707649fd4ed0  call 0x0000707649E09D70
0000707649fd4ed5  jmp 0x0000707649FD023C
0000707649fd4eda  sub rsp, 0x08
0000707649fd4ede  push rax
0000707649fd4edf  push rcx
0000707649fd4ee0  push rdx
0000707649fd4ee1  push rdi
0000707649fd4ee2  push rsi
0000707649fd4ee3  push r8
0000707649fd4ee5  push r9
0000707649fd4ee7  push r10
0000707649fd4ee9  push r11
0000707649fd4eeb  sub rsp, 0xF0
0000707649fd4ef2  vmovaps [rsp], xmm0
0000707649fd4ef7  vmovaps [rsp+0x10], xmm1
0000707649fd4efd  vmovaps [rsp+0x20], xmm2
0000707649fd4f03  vmovaps [rsp+0x30], xmm3
0000707649fd4f09  vmovaps [rsp+0x40], xmm4
0000707649fd4f0f  vmovaps [rsp+0x50], xmm5
0000707649fd4f15  vmovaps [rsp+0x60], xmm6
0000707649fd4f1b  vmovaps [rsp+0x70], xmm8
0000707649fd4f21  vmovaps [rsp+0x80], xmm9
0000707649fd4f2a  vmovaps [rsp+0x90], xmm10
0000707649fd4f33  vmovaps [rsp+0xA0], xmm11
0000707649fd4f3c  vmovaps [rsp+0xB0], xmm12
0000707649fd4f45  vmovaps [rsp+0xC0], xmm13
0000707649fd4f4e  vmovaps [rsp+0xD0], xmm14
0000707649fd4f57  vmovaps [rsp+0xE0], xmm15
0000707649fd4f60  sub rsp, 0x30
0000707649fd4f64  movaps [rsp], xmm7
0000707649fd4f68  movaps [rsp+0x10], xmm15
0000707649fd4f6e  movaps [rsp+0x20], xmm10
0000707649fd4f74  lea rdi, [rsp]
0000707649fd4f78  mov esi, 0x00
0000707649fd4f7d  mov rax, 0x59CB0B054530
0000707649fd4f87  call rax
0000707649fd4f89  movaps xmm7, [rsp]
0000707649fd4f8d  add rsp, 0x30
0000707649fd4f91  vmovaps xmm0, [rsp]
0000707649fd4f96  vmovaps xmm1, [rsp+0x10]
0000707649fd4f9c  vmovaps xmm2, [rsp+0x20]
0000707649fd4fa2  vmovaps xmm3, [rsp+0x30]
0000707649fd4fa8  vmovaps xmm4, [rsp+0x40]
0000707649fd4fae  vmovaps xmm5, [rsp+0x50]
0000707649fd4fb4  vmovaps xmm6, [rsp+0x60]
0000707649fd4fba  vmovaps xmm8, [rsp+0x70]
0000707649fd4fc0  vmovaps xmm9, [rsp+0x80]
0000707649fd4fc9  vmovaps xmm10, [rsp+0x90]
0000707649fd4fd2  vmovaps xmm11, [rsp+0xA0]
0000707649fd4fdb  vmovaps xmm12, [rsp+0xB0]
0000707649fd4fe4  vmovaps xmm13, [rsp+0xC0]
0000707649fd4fed  vmovaps xmm14, [rsp+0xD0]
0000707649fd4ff6  vmovaps xmm15, [rsp+0xE0]
0000707649fd4fff  add rsp, 0xF0
0000707649fd5006  pop r11
0000707649fd5008  pop r10
0000707649fd500a  pop r9
0000707649fd500c  pop r8
0000707649fd500e  pop rsi
0000707649fd500f  pop rdi
0000707649fd5010  pop rdx
0000707649fd5011  pop rcx
0000707649fd5012  pop rax
0000707649fd5013  add rsp, 0x08
0000707649fd5017  jmp 0x0000707649FD025D
0000707649fd501c  sub rsp, 0x08
0000707649fd5020  push rax
0000707649fd5021  push rcx
0000707649fd5022  push rdx
0000707649fd5023  push rdi
0000707649fd5024  push rsi
0000707649fd5025  push r8
0000707649fd5027  push r9
0000707649fd5029  push r10
0000707649fd502b  push r11
0000707649fd502d  sub rsp, 0xF0
0000707649fd5034  vmovaps [rsp], xmm0
0000707649fd5039  vmovaps [rsp+0x10], xmm1
0000707649fd503f  vmovaps [rsp+0x20], xmm2
0000707649fd5045  vmovaps [rsp+0x30], xmm3
0000707649fd504b  vmovaps [rsp+0x40], xmm4
0000707649fd5051  vmovaps [rsp+0x50], xmm5
0000707649fd5057  vmovaps [rsp+0x60], xmm6
0000707649fd505d  vmovaps [rsp+0x70], xmm7
0000707649fd5063  vmovaps [rsp+0x80], xmm8
0000707649fd506c  vmovaps [rsp+0x90], xmm9
0000707649fd5075  vmovaps [rsp+0xA0], xmm11
0000707649fd507e  vmovaps [rsp+0xB0], xmm12
0000707649fd5087  vmovaps [rsp+0xC0], xmm13
0000707649fd5090  vmovaps [rsp+0xD0], xmm14
0000707649fd5099  vmovaps [rsp+0xE0], xmm15
0000707649fd50a2  sub rsp, 0x30
0000707649fd50a6  movaps [rsp], xmm10
0000707649fd50ab  movaps [rsp+0x10], xmm11
0000707649fd50b1  movaps [rsp+0x20], xmm15
0000707649fd50b7  lea rdi, [rsp]
0000707649fd50bb  mov esi, 0x00
0000707649fd50c0  mov rax, 0x59CB0B054530
0000707649fd50ca  call rax
0000707649fd50cc  movaps xmm10, [rsp]
0000707649fd50d1  add rsp, 0x30
0000707649fd50d5  vmovaps xmm0, [rsp]
0000707649fd50da  vmovaps xmm1, [rsp+0x10]
0000707649fd50e0  vmovaps xmm2, [rsp+0x20]
0000707649fd50e6  vmovaps xmm3, [rsp+0x30]
0000707649fd50ec  vmovaps xmm4, [rsp+0x40]
0000707649fd50f2  vmovaps xmm5, [rsp+0x50]
0000707649fd50f8  vmovaps xmm6, [rsp+0x60]
0000707649fd50fe  vmovaps xmm7, [rsp+0x70]
0000707649fd5104  vmovaps xmm8, [rsp+0x80]
0000707649fd510d  vmovaps xmm9, [rsp+0x90]
0000707649fd5116  vmovaps xmm11, [rsp+0xA0]
0000707649fd511f  vmovaps xmm12, [rsp+0xB0]
0000707649fd5128  vmovaps xmm13, [rsp+0xC0]
0000707649fd5131  vmovaps xmm14, [rsp+0xD0]
0000707649fd513a  vmovaps xmm15, [rsp+0xE0]
0000707649fd5143  add rsp, 0xF0
0000707649fd514a  pop r11
0000707649fd514c  pop r10
0000707649fd514e  pop r9
0000707649fd5150  pop r8
0000707649fd5152  pop rsi
0000707649fd5153  pop rdi
0000707649fd5154  pop rdx
0000707649fd5155  pop rcx
0000707649fd5156  pop rax
0000707649fd5157  add rsp, 0x08
0000707649fd515b  jmp 0x0000707649FD028B
0000707649fd5160  sub rsp, 0x08
0000707649fd5164  push rax
0000707649fd5165  push rcx
0000707649fd5166  push rdx
0000707649fd5167  push rdi
0000707649fd5168  push rsi
0000707649fd5169  push r8
0000707649fd516b  push r9
0000707649fd516d  push r10
0000707649fd516f  push r11
0000707649fd5171  sub rsp, 0xF0
0000707649fd5178  vmovaps [rsp], xmm0
0000707649fd517d  vmovaps [rsp+0x10], xmm1
0000707649fd5183  vmovaps [rsp+0x20], xmm2
0000707649fd5189  vmovaps [rsp+0x30], xmm3
0000707649fd518f  vmovaps [rsp+0x40], xmm4
0000707649fd5195  vmovaps [rsp+0x50], xmm5
0000707649fd519b  vmovaps [rsp+0x60], xmm6
0000707649fd51a1  vmovaps [rsp+0x70], xmm7
0000707649fd51a7  vmovaps [rsp+0x80], xmm8
0000707649fd51b0  vmovaps [rsp+0x90], xmm9
0000707649fd51b9  vmovaps [rsp+0xA0], xmm10
0000707649fd51c2  vmovaps [rsp+0xB0], xmm12
0000707649fd51cb  vmovaps [rsp+0xC0], xmm13
0000707649fd51d4  vmovaps [rsp+0xD0], xmm14
0000707649fd51dd  vmovaps [rsp+0xE0], xmm15
0000707649fd51e6  sub rsp, 0x30
0000707649fd51ea  movaps [rsp], xmm11
0000707649fd51ef  movaps [rsp+0x10], xmm12
0000707649fd51f5  movaps [rsp+0x20], xmm15
0000707649fd51fb  lea rdi, [rsp]
0000707649fd51ff  mov esi, 0x00
0000707649fd5204  mov rax, 0x59CB0B054530
0000707649fd520e  call rax
0000707649fd5210  movaps xmm11, [rsp]
0000707649fd5215  add rsp, 0x30
0000707649fd5219  vmovaps xmm0, [rsp]
0000707649fd521e  vmovaps xmm1, [rsp+0x10]
0000707649fd5224  vmovaps xmm2, [rsp+0x20]
0000707649fd522a  vmovaps xmm3, [rsp+0x30]
0000707649fd5230  vmovaps xmm4, [rsp+0x40]
0000707649fd5236  vmovaps xmm5, [rsp+0x50]
0000707649fd523c  vmovaps xmm6, [rsp+0x60]
0000707649fd5242  vmovaps xmm7, [rsp+0x70]
0000707649fd5248  vmovaps xmm8, [rsp+0x80]
0000707649fd5251  vmovaps xmm9, [rsp+0x90]
0000707649fd525a  vmovaps xmm10, [rsp+0xA0]
0000707649fd5263  vmovaps xmm12, [rsp+0xB0]
0000707649fd526c  vmovaps xmm13, [rsp+0xC0]
0000707649fd5275  vmovaps xmm14, [rsp+0xD0]
0000707649fd527e  vmovaps xmm15, [rsp+0xE0]
0000707649fd5287  add rsp, 0xF0
0000707649fd528e  pop r11
0000707649fd5290  pop r10
0000707649fd5292  pop r9
0000707649fd5294  pop r8
0000707649fd5296  pop rsi
0000707649fd5297  pop rdi
0000707649fd5298  pop rdx
0000707649fd5299  pop rcx
0000707649fd529a  pop rax
0000707649fd529b  add rsp, 0x08
0000707649fd529f  jmp 0x0000707649FD02B9
0000707649fd52a4  sub rsp, 0x08
0000707649fd52a8  push rax
0000707649fd52a9  push rcx
0000707649fd52aa  push rdx
0000707649fd52ab  push rdi
0000707649fd52ac  push rsi
0000707649fd52ad  push r8
0000707649fd52af  push r9
0000707649fd52b1  push r10
0000707649fd52b3  push r11
0000707649fd52b5  sub rsp, 0xF0
0000707649fd52bc  vmovaps [rsp], xmm0
0000707649fd52c1  vmovaps [rsp+0x10], xmm1
0000707649fd52c7  vmovaps [rsp+0x20], xmm2
0000707649fd52cd  vmovaps [rsp+0x30], xmm3
0000707649fd52d3  vmovaps [rsp+0x40], xmm4
0000707649fd52d9  vmovaps [rsp+0x50], xmm5
0000707649fd52df  vmovaps [rsp+0x60], xmm6
0000707649fd52e5  vmovaps [rsp+0x70], xmm7
0000707649fd52eb  vmovaps [rsp+0x80], xmm8
0000707649fd52f4  vmovaps [rsp+0x90], xmm9
0000707649fd52fd  vmovaps [rsp+0xA0], xmm10
0000707649fd5306  vmovaps [rsp+0xB0], xmm11
0000707649fd530f  vmovaps [rsp+0xC0], xmm12
0000707649fd5318  vmovaps [rsp+0xD0], xmm13
0000707649fd5321  vmovaps [rsp+0xE0], xmm14
0000707649fd532a  sub rsp, 0x30
0000707649fd532e  movaps [rsp], xmm15
0000707649fd5333  movaps [rsp+0x10], xmm13
0000707649fd5339  movaps [rsp+0x20], xmm9
0000707649fd533f  lea rdi, [rsp]
0000707649fd5343  mov esi, 0x00
0000707649fd5348  mov rax, 0x59CB0B054530
0000707649fd5352  call rax
0000707649fd5354  movaps xmm15, [rsp]
0000707649fd5359  add rsp, 0x30
0000707649fd535d  vmovaps xmm0, [rsp]
0000707649fd5362  vmovaps xmm1, [rsp+0x10]
0000707649fd5368  vmovaps xmm2, [rsp+0x20]
0000707649fd536e  vmovaps xmm3, [rsp+0x30]
0000707649fd5374  vmovaps xmm4, [rsp+0x40]
0000707649fd537a  vmovaps xmm5, [rsp+0x50]
0000707649fd5380  vmovaps xmm6, [rsp+0x60]
0000707649fd5386  vmovaps xmm7, [rsp+0x70]
0000707649fd538c  vmovaps xmm8, [rsp+0x80]
0000707649fd5395  vmovaps xmm9, [rsp+0x90]
0000707649fd539e  vmovaps xmm10, [rsp+0xA0]
0000707649fd53a7  vmovaps xmm11, [rsp+0xB0]
0000707649fd53b0  vmovaps xmm12, [rsp+0xC0]
0000707649fd53b9  vmovaps xmm13, [rsp+0xD0]
0000707649fd53c2  vmovaps xmm14, [rsp+0xE0]
0000707649fd53cb  add rsp, 0xF0
0000707649fd53d2  pop r11
0000707649fd53d4  pop r10
0000707649fd53d6  pop r9
0000707649fd53d8  pop r8
0000707649fd53da  pop rsi
0000707649fd53db  pop rdi
0000707649fd53dc  pop rdx
0000707649fd53dd  pop rcx
0000707649fd53de  pop rax
0000707649fd53df  add rsp, 0x08
0000707649fd53e3  jmp 0x0000707649FD02D4
0000707649fd53e8  sub rsp, 0x08
0000707649fd53ec  push rax
0000707649fd53ed  push rcx
0000707649fd53ee  push rdx
0000707649fd53ef  push rdi
0000707649fd53f0  push rsi
0000707649fd53f1  push r8
0000707649fd53f3  push r9
0000707649fd53f5  push r10
0000707649fd53f7  push r11
0000707649fd53f9  sub rsp, 0xF0
0000707649fd5400  vmovaps [rsp], xmm0
0000707649fd5405  vmovaps [rsp+0x10], xmm1
0000707649fd540b  vmovaps [rsp+0x20], xmm2
0000707649fd5411  vmovaps [rsp+0x30], xmm3
0000707649fd5417  vmovaps [rsp+0x40], xmm4
0000707649fd541d  vmovaps [rsp+0x50], xmm5
0000707649fd5423  vmovaps [rsp+0x60], xmm6
0000707649fd5429  vmovaps [rsp+0x70], xmm7
0000707649fd542f  vmovaps [rsp+0x80], xmm8
0000707649fd5438  vmovaps [rsp+0x90], xmm9
0000707649fd5441  vmovaps [rsp+0xA0], xmm10
0000707649fd544a  vmovaps [rsp+0xB0], xmm11
0000707649fd5453  vmovaps [rsp+0xC0], xmm12
0000707649fd545c  vmovaps [rsp+0xD0], xmm14
0000707649fd5465  vmovaps [rsp+0xE0], xmm15
0000707649fd546e  sub rsp, 0x30
0000707649fd5472  movaps [rsp], xmm13
0000707649fd5477  movaps [rsp+0x10], xmm8
0000707649fd547d  movaps [rsp+0x20], xmm14
0000707649fd5483  lea rdi, [rsp]
0000707649fd5487  mov esi, 0x00
0000707649fd548c  mov rax, 0x59CB0B054530
0000707649fd5496  call rax
0000707649fd5498  movaps xmm13, [rsp]
0000707649fd549d  add rsp, 0x30
0000707649fd54a1  vmovaps xmm0, [rsp]
0000707649fd54a6  vmovaps xmm1, [rsp+0x10]
0000707649fd54ac  vmovaps xmm2, [rsp+0x20]
0000707649fd54b2  vmovaps xmm3, [rsp+0x30]
0000707649fd54b8  vmovaps xmm4, [rsp+0x40]
0000707649fd54be  vmovaps xmm5, [rsp+0x50]
0000707649fd54c4  vmovaps xmm6, [rsp+0x60]
0000707649fd54ca  vmovaps xmm7, [rsp+0x70]
0000707649fd54d0  vmovaps xmm8, [rsp+0x80]
0000707649fd54d9  vmovaps xmm9, [rsp+0x90]
0000707649fd54e2  vmovaps xmm10, [rsp+0xA0]
0000707649fd54eb  vmovaps xmm11, [rsp+0xB0]
0000707649fd54f4  vmovaps xmm12, [rsp+0xC0]
0000707649fd54fd  vmovaps xmm14, [rsp+0xD0]
0000707649fd5506  vmovaps xmm15, [rsp+0xE0]
0000707649fd550f  add rsp, 0xF0
0000707649fd5516  pop r11
0000707649fd5518  pop r10
0000707649fd551a  pop r9
0000707649fd551c  pop r8
0000707649fd551e  pop rsi
0000707649fd551f  pop rdi
0000707649fd5520  pop rdx
0000707649fd5521  pop rcx
0000707649fd5522  pop rax
0000707649fd5523  add rsp, 0x08
0000707649fd5527  jmp 0x0000707649FD02F7
0000707649fd552c  sub rsp, 0x08
0000707649fd5530  push rax
0000707649fd5531  push rcx
0000707649fd5532  push rdx
0000707649fd5533  push rdi
0000707649fd5534  push rsi
0000707649fd5535  push r8
0000707649fd5537  push r9
0000707649fd5539  push r10
0000707649fd553b  push r11
0000707649fd553d  sub rsp, 0xF0
0000707649fd5544  vmovaps [rsp], xmm0
0000707649fd5549  vmovaps [rsp+0x10], xmm1
0000707649fd554f  vmovaps [rsp+0x20], xmm2
0000707649fd5555  vmovaps [rsp+0x30], xmm3
0000707649fd555b  vmovaps [rsp+0x40], xmm4
0000707649fd5561  vmovaps [rsp+0x50], xmm5
0000707649fd5567  vmovaps [rsp+0x60], xmm6
0000707649fd556d  vmovaps [rsp+0x70], xmm7
0000707649fd5573  vmovaps [rsp+0x80], xmm8
0000707649fd557c  vmovaps [rsp+0x90], xmm9
0000707649fd5585  vmovaps [rsp+0xA0], xmm10
0000707649fd558e  vmovaps [rsp+0xB0], xmm11
0000707649fd5597  vmovaps [rsp+0xC0], xmm12
0000707649fd55a0  vmovaps [rsp+0xD0], xmm13
0000707649fd55a9  vmovaps [rsp+0xE0], xmm15
0000707649fd55b2  sub rsp, 0x30
0000707649fd55b6  movaps [rsp], xmm14
0000707649fd55bb  movaps [rsp+0x10], xmm1
0000707649fd55c0  movaps [rsp+0x20], xmm10
0000707649fd55c6  lea rdi, [rsp]
0000707649fd55ca  mov esi, 0x00
0000707649fd55cf  mov rax, 0x59CB0B054530
0000707649fd55d9  call rax
0000707649fd55db  movaps xmm14, [rsp]
0000707649fd55e0  add rsp, 0x30
0000707649fd55e4  vmovaps xmm0, [rsp]
0000707649fd55e9  vmovaps xmm1, [rsp+0x10]
0000707649fd55ef  vmovaps xmm2, [rsp+0x20]
0000707649fd55f5  vmovaps xmm3, [rsp+0x30]
0000707649fd55fb  vmovaps xmm4, [rsp+0x40]
0000707649fd5601  vmovaps xmm5, [rsp+0x50]
0000707649fd5607  vmovaps xmm6, [rsp+0x60]
0000707649fd560d  vmovaps xmm7, [rsp+0x70]
0000707649fd5613  vmovaps xmm8, [rsp+0x80]
0000707649fd561c  vmovaps xmm9, [rsp+0x90]
0000707649fd5625  vmovaps xmm10, [rsp+0xA0]
0000707649fd562e  vmovaps xmm11, [rsp+0xB0]
0000707649fd5637  vmovaps xmm12, [rsp+0xC0]
0000707649fd5640  vmovaps xmm13, [rsp+0xD0]
0000707649fd5649  vmovaps xmm15, [rsp+0xE0]
0000707649fd5652  add rsp, 0xF0
0000707649fd5659  pop r11
0000707649fd565b  pop r10
0000707649fd565d  pop r9
0000707649fd565f  pop r8
0000707649fd5661  pop rsi
0000707649fd5662  pop rdi
0000707649fd5663  pop rdx
0000707649fd5664  pop rcx
0000707649fd5665  pop rax
0000707649fd5666  add rsp, 0x08
0000707649fd566a  jmp 0x0000707649FD031A
0000707649fd566f  sub rsp, 0x08
0000707649fd5673  push rax
0000707649fd5674  push rcx
0000707649fd5675  push rdx
0000707649fd5676  push rdi
0000707649fd5677  push rsi
0000707649fd5678  push r8
0000707649fd567a  push r9
0000707649fd567c  push r10
0000707649fd567e  push r11
0000707649fd5680  sub rsp, 0xF0
0000707649fd5687  vmovaps [rsp], xmm0
0000707649fd568c  vmovaps [rsp+0x10], xmm2
0000707649fd5692  vmovaps [rsp+0x20], xmm3
0000707649fd5698  vmovaps [rsp+0x30], xmm4
0000707649fd569e  vmovaps [rsp+0x40], xmm5
0000707649fd56a4  vmovaps [rsp+0x50], xmm6
0000707649fd56aa  vmovaps [rsp+0x60], xmm7
0000707649fd56b0  vmovaps [rsp+0x70], xmm8
0000707649fd56b6  vmovaps [rsp+0x80], xmm9
0000707649fd56bf  vmovaps [rsp+0x90], xmm10
0000707649fd56c8  vmovaps [rsp+0xA0], xmm11
0000707649fd56d1  vmovaps [rsp+0xB0], xmm12
0000707649fd56da  vmovaps [rsp+0xC0], xmm13
0000707649fd56e3  vmovaps [rsp+0xD0], xmm14
0000707649fd56ec  vmovaps [rsp+0xE0], xmm15
0000707649fd56f5  sub rsp, 0x30
0000707649fd56f9  movaps [rsp], xmm1
0000707649fd56fd  movaps [rsp+0x10], xmm7
0000707649fd5702  movaps [rsp+0x20], xmm11
0000707649fd5708  lea rdi, [rsp]
0000707649fd570c  mov esi, 0x00
0000707649fd5711  mov rax, 0x59CB0B054530
0000707649fd571b  call rax
0000707649fd571d  movaps xmm1, [rsp]
0000707649fd5721  add rsp, 0x30
0000707649fd5725  vmovaps xmm0, [rsp]
0000707649fd572a  vmovaps xmm2, [rsp+0x10]
0000707649fd5730  vmovaps xmm3, [rsp+0x20]
0000707649fd5736  vmovaps xmm4, [rsp+0x30]
0000707649fd573c  vmovaps xmm5, [rsp+0x40]
0000707649fd5742  vmovaps xmm6, [rsp+0x50]
0000707649fd5748  vmovaps xmm7, [rsp+0x60]
0000707649fd574e  vmovaps xmm8, [rsp+0x70]
0000707649fd5754  vmovaps xmm9, [rsp+0x80]
0000707649fd575d  vmovaps xmm10, [rsp+0x90]
0000707649fd5766  vmovaps xmm11, [rsp+0xA0]
0000707649fd576f  vmovaps xmm12, [rsp+0xB0]
0000707649fd5778  vmovaps xmm13, [rsp+0xC0]
0000707649fd5781  vmovaps xmm14, [rsp+0xD0]
0000707649fd578a  vmovaps xmm15, [rsp+0xE0]
0000707649fd5793  add rsp, 0xF0
0000707649fd579a  pop r11
0000707649fd579c  pop r10
0000707649fd579e  pop r9
0000707649fd57a0  pop r8
0000707649fd57a2  pop rsi
0000707649fd57a3  pop rdi
0000707649fd57a4  pop rdx
0000707649fd57a5  pop rcx
0000707649fd57a6  pop rax
0000707649fd57a7  add rsp, 0x08
0000707649fd57ab  jmp 0x0000707649FD033B
0000707649fd57b0  call 0x0000707649E0E880
0000707649fd57b5  jmp 0x0000707649FD034E
0000707649fd57ba  call 0x0000707649E0C380
0000707649fd57bf  jmp 0x0000707649FD0359
0000707649fd57c4  call 0x0000707649E0D600
0000707649fd57c9  jmp 0x0000707649FD0364
0000707649fd57ce  call 0x0000707649DFF540
0000707649fd57d3  jmp 0x0000707649FD036F
0000707649fd57d8  int3
0000707649fd57d9  nop [rax], eax
0000707649fd57e0  mov rax, [r15+0x40]
0000707649fd57e4  mov r14, [r15+0x58]
0000707649fd57e8  lea r12, [rax+r14*1]
0000707649fd57ec  movaps xmm1, [r15+0x1D0]
0000707649fd57f4  vmovaps [rsp+0x10], xmm1
0000707649fd57fa  vmovaps xmm15, [rsp+0x10]
0000707649fd5800  por xmm1, xmm15
0000707649fd5805  movaps xmm14, [r15+0x1A0]
0000707649fd580d  vmovaps [rsp+0x10], xmm14
0000707649fd5813  vmovaps xmm13, [rsp+0x10]
0000707649fd5819  por xmm14, xmm13
0000707649fd581e  lea rax, [r12+0x30]
0000707649fd5823  mov r11, [r13+rax*1]
0000707649fd5828  lea rax, [r12+0x38]
0000707649fd582d  mov r10, [r13+rax*1]
0000707649fd5832  movq xmm13, r11
0000707649fd5837  movq xmm12, r10
0000707649fd583c  movq xmm13, xmm13
0000707649fd5841  vmovaps [rsp+0x10], xmm13
0000707649fd5847  movq xmm13, xmm13
0000707649fd584c  movaps [r15+0x130], xmm13
0000707649fd5854  movq xmm12, xmm12
0000707649fd5859  vmovaps [rsp+0x20], xmm12
0000707649fd585f  movq xmm12, xmm12
0000707649fd5864  movaps [r15+0x280], xmm12
0000707649fd586c  movaps xmm13, [r15+0x270]
0000707649fd5874  vmovaps [rsp+0x30], xmm13
0000707649fd587a  vmovaps xmm12, [rsp+0x30]
0000707649fd5880  por xmm13, xmm12
0000707649fd5885  lea rax, [r12+0x20]
0000707649fd588a  mov r11, [r13+rax*1]
0000707649fd588f  lea rax, [r12+0x28]
0000707649fd5894  mov r10, [r13+rax*1]
0000707649fd5899  movq xmm12, r11
0000707649fd589e  movq xmm11, r10
0000707649fd58a3  movq xmm12, xmm12
0000707649fd58a8  vmovaps [rsp+0x30], xmm12
0000707649fd58ae  movq xmm12, xmm12
0000707649fd58b3  movaps [r15+0x150], xmm12
0000707649fd58bb  movq xmm11, xmm11
0000707649fd58c0  vmovaps [rsp+0x40], xmm11
0000707649fd58c6  movq xmm11, xmm11
0000707649fd58cb  movaps [r15+0x140], xmm11
0000707649fd58d3  lea rax, [r12+0x10]
0000707649fd58d8  mov r11, [r13+rax*1]
0000707649fd58dd  lea rax, [r12+0x18]
0000707649fd58e2  mov r10, [r13+rax*1]
0000707649fd58e7  movq xmm12, r11
0000707649fd58ec  movq xmm11, r10
0000707649fd58f1  movq xmm12, xmm12
0000707649fd58f6  vmovaps [rsp+0x50], xmm12
0000707649fd58fc  movq xmm12, xmm12
0000707649fd5901  movaps [r15+0x170], xmm12
0000707649fd5909  movq xmm11, xmm11
0000707649fd590e  vmovaps [rsp+0x60], xmm11
0000707649fd5914  movq xmm11, xmm11
0000707649fd5919  movaps [r15+0x160], xmm11
0000707649fd5921  mov rax, [r13+r12*1]
0000707649fd5926  vmovq xmm12, rax
0000707649fd592b  vpbroadcastq xmm12, xmm12
0000707649fd5930  lea rax, [r12+0x08]
0000707649fd5935  mov r12, [r13+rax*1]
0000707649fd593a  movq xmm11, r12
0000707649fd593f  movaps [r15+0x230], xmm11
0000707649fd5947  mov rax, [r15+0xF8]
0000707649fd594e  lea r12, [rax+0x50]
0000707649fd5952  movups xmm11, [r13+r12*1]
0000707649fd5958  lea r12, [rax+0x60]
0000707649fd595c  movups xmm10, [r13+r12*1]
0000707649fd5962  lea r12, [rax+0x30]
0000707649fd5966  movups xmm9, [r13+r12*1]
0000707649fd596c  mov r12, [r15+0x50]
0000707649fd5970  lea r11, [r12+r14*1]
0000707649fd5974  mov [r15+0x60], r11
0000707649fd5978  lea r12, [r14+0x40]
0000707649fd597c  mov [r15+0x58], r12
0000707649fd5980  movaps xmm8, xmm12
0000707649fd5984  mulpd xmm8, xmm15
0000707649fd5989  vcmppd xmm7, xmm8, xmm8, 0x03
0000707649fd598f  ptest xmm7, xmm7
0000707649fd5994  jnz 0x0000707649FD67B7
0000707649fd599a  movq xmm15, qword ptr [r15+0x230]
0000707649fd59a3  vmovaps [rsp+0x70], xmm15
0000707649fd59a9  vpermilpd xmm15, xmm15, 0x00
0000707649fd59af  movaps xmm7, xmm9
0000707649fd59b3  mulpd xmm7, xmm15
0000707649fd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
0000707649fd59bd  ptest xmm6, xmm6
0000707649fd59c2  jnz 0x0000707649FD68FB
0000707649fd59c8  vxorps xmm15, xmm15, xmm15
0000707649fd59cd  vpbroadcastq xmm15, xmm15
0000707649fd59d2  movaps xmm9, xmm12
0000707649fd59d6  mulpd xmm9, xmm10
0000707649fd59db  vcmppd xmm6, xmm9, xmm9, 0x03
0000707649fd59e1  ptest xmm6, xmm6
0000707649fd59e6  jnz 0x0000707649FD6A3D
0000707649fd59ec  movaps xmm10, xmm12
0000707649fd59f0  mulpd xmm10, xmm11
0000707649fd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
0000707649fd59fb  ptest xmm6, xmm6
0000707649fd5a00  jnz 0x0000707649FD6B81
0000707649fd5a06  movaps xmm11, [r15+0x1F0]
0000707649fd5a0e  movaps xmm6, xmm12
0000707649fd5a12  mulpd xmm6, xmm11
0000707649fd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
0000707649fd5a1c  ptest xmm5, xmm5
0000707649fd5a21  jnz 0x0000707649FD6CC5
0000707649fd5a27  movaps xmm12, [r15+0x2A0]
0000707649fd5a2f  vmovaps [rsp+0x80], xmm12
0000707649fd5a38  vmovaps xmm11, [rsp+0x80]
0000707649fd5a41  por xmm12, xmm11
0000707649fd5a46  movaps xmm11, [r15+0x250]
0000707649fd5a4e  vmovaps [rsp+0x80], xmm11
0000707649fd5a57  vmovaps xmm5, [rsp+0x80]
0000707649fd5a60  por xmm11, xmm5
0000707649fd5a65  vmovaps xmm4, [rsp+0x70]
0000707649fd5a6b  vpermilpd xmm4, xmm4, 0x00
0000707649fd5a71  movaps xmm3, xmm5
0000707649fd5a74  mulpd xmm3, xmm4
0000707649fd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
0000707649fd5a7d  ptest xmm2, xmm2
0000707649fd5a82  jnz 0x0000707649FD6E07
0000707649fd5a88  mov [rsp+0x80], rax
0000707649fd5a90  xor eax, eax
0000707649fd5a92  mov r14d, 0x200
0000707649fd5a98  cmp r12, r14
0000707649fd5a9b  cmc
0000707649fd5a9c  lahf
0000707649fd5a9d  seto al
0000707649fd5aa0  mov [r15+0x108], eax
0000707649fd5aa7  movaps xmm5, xmm8
0000707649fd5aab  addpd xmm5, xmm15
0000707649fd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
0000707649fd5ab5  ptest xmm4, xmm4
0000707649fd5aba  jnz 0x0000707649FD6F47
0000707649fd5ac0  movaps xmm8, [r15+0x1B0]
0000707649fd5ac8  movaps xmm4, xmm9
0000707649fd5acc  addpd xmm4, xmm8
0000707649fd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
0000707649fd5ad6  ptest xmm2, xmm2
0000707649fd5adb  jnz 0x0000707649FD7089
0000707649fd5ae1  movaps xmm9, xmm10
0000707649fd5ae5  addpd xmm9, xmm8
0000707649fd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
0000707649fd5af0  ptest xmm2, xmm2
0000707649fd5af5  jnz 0x0000707649FD71CB
0000707649fd5afb  movaps xmm10, [r15+0x2F0]
0000707649fd5b03  vmovaps [rsp+0x90], xmm10
0000707649fd5b0c  vmovaps xmm8, [rsp+0x90]
0000707649fd5b15  por xmm10, xmm8
0000707649fd5b1a  movaps xmm8, [r15+0x2E0]
0000707649fd5b22  vmovaps [rsp+0x90], xmm8
0000707649fd5b2b  vmovaps xmm2, [rsp+0x90]
0000707649fd5b34  por xmm8, xmm2
0000707649fd5b39  movaps xmm2, [r15+0x2D0]
0000707649fd5b41  vmovaps [rsp+0x90], xmm2
0000707649fd5b4a  vmovaps [rsp+0xA0], xmm1
0000707649fd5b53  vmovaps xmm1, [rsp+0x90]
0000707649fd5b5c  por xmm2, xmm1
0000707649fd5b60  movaps xmm1, [r15+0x200]
0000707649fd5b68  vmovaps [rsp+0x90], xmm1
0000707649fd5b71  vmovaps [rsp+0xB0], xmm15
0000707649fd5b7a  vmovaps xmm15, [rsp+0x90]
0000707649fd5b83  por xmm1, xmm15
0000707649fd5b88  movaps xmm15, [r15+0x1C0]
0000707649fd5b90  vmovaps [rsp+0x90], xmm15
0000707649fd5b99  vmovaps [rsp+0xC0], xmm1
0000707649fd5ba2  vmovaps xmm1, [rsp+0x90]
0000707649fd5bab  por xmm15, xmm1
0000707649fd5bb0  movaps xmm1, [r15+0x190]
0000707649fd5bb8  vmovaps [rsp+0x90], xmm1
0000707649fd5bc1  vmovaps [rsp+0xD0], xmm15
0000707649fd5bca  vmovaps xmm15, [rsp+0x90]
0000707649fd5bd3  por xmm1, xmm15
0000707649fd5bd8  movaps xmm15, [r15+0x300]
0000707649fd5be0  vmovaps [rsp+0x90], xmm15
0000707649fd5be9  vmovaps [rsp+0xE0], xmm1
0000707649fd5bf2  vmovaps xmm1, [rsp+0x90]
0000707649fd5bfb  por xmm15, xmm1
0000707649fd5c00  mov rax, [rsp+0x80]
0000707649fd5c08  lea r14, [rax+0xA0]
0000707649fd5c0f  movups xmm1, [r13+r14*1]
0000707649fd5c15  lea r14, [rax+0xB0]
0000707649fd5c1c  vmovaps [rsp+0x80], xmm1
0000707649fd5c25  movups xmm1, [r13+r14*1]
0000707649fd5c2b  vmovaps [rsp+0x90], xmm1
0000707649fd5c34  vmovaps [rsp+0xF0], xmm15
0000707649fd5c3d  vmovaps xmm15, [rsp+0xB0]
0000707649fd5c46  vmovaps [rsp+0xB0], xmm14
0000707649fd5c4f  movaps xmm1, xmm6
0000707649fd5c52  addpd xmm1, xmm15
0000707649fd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
0000707649fd5c5c  ptest xmm14, xmm14
0000707649fd5c62  jnz 0x0000707649FD7323
0000707649fd5c68  lea r14, [rax+0xF0]
0000707649fd5c6f  movups xmm15, [r13+r14*1]
0000707649fd5c75  movaps xmm14, xmm4
0000707649fd5c79  addpd xmm14, xmm3
0000707649fd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
0000707649fd5c84  ptest xmm6, xmm6
0000707649fd5c89  jnz 0x0000707649FD746E
0000707649fd5c8f  movaps xmm6, xmm9
0000707649fd5c93  addpd xmm6, xmm7
0000707649fd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
0000707649fd5c9c  ptest xmm4, xmm4
0000707649fd5ca1  jnz 0x0000707649FD75B0
0000707649fd5ca7  vmovaps xmm9, [rsp+0x70]
0000707649fd5cad  vpermilpd xmm9, xmm9, 0x00
0000707649fd5cb3  vmovaps xmm4, [rsp+0x90]
0000707649fd5cbc  movaps xmm7, xmm4
0000707649fd5cbf  mulpd xmm7, xmm9
0000707649fd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
0000707649fd5cc9  ptest xmm3, xmm3
0000707649fd5cce  jnz 0x0000707649FD76F1
0000707649fd5cd4  vmovaps xmm9, [rsp+0x50]
0000707649fd5cda  vpermilpd xmm9, xmm9, 0x00
0000707649fd5ce0  movaps xmm4, xmm15
0000707649fd5ce4  mulpd xmm4, xmm9
0000707649fd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
0000707649fd5cee  ptest xmm3, xmm3
0000707649fd5cf3  jnz 0x0000707649FD7832
0000707649fd5cf9  lea r14, [rax+0xE0]
0000707649fd5d00  movups xmm15, [r13+r14*1]
0000707649fd5d06  vmovaps xmm9, [rsp+0x70]
0000707649fd5d0c  vpermilpd xmm9, xmm9, 0x00
0000707649fd5d12  vmovaps [rsp+0x70], xmm1
0000707649fd5d18  vmovaps xmm1, [rsp+0x80]
0000707649fd5d21  vmovaps [rsp+0x80], xmm15
0000707649fd5d2a  movaps xmm3, xmm1
0000707649fd5d2d  mulpd xmm3, xmm9
0000707649fd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
0000707649fd5d37  ptest xmm15, xmm15
0000707649fd5d3d  jnz 0x0000707649FD797E
0000707649fd5d43  vmovaps xmm1, [rsp+0xF0]
0000707649fd5d4c  vmovaps xmm15, [rsp+0xF0]
0000707649fd5d55  por xmm1, xmm15
0000707649fd5d5a  movaps [r15+0x300], xmm1
0000707649fd5d62  vmovaps xmm15, [rsp+0xE0]
0000707649fd5d6b  vmovaps xmm9, [rsp+0xE0]
0000707649fd5d74  por xmm15, xmm9
0000707649fd5d79  movaps [r15+0x190], xmm15
0000707649fd5d81  vmovaps xmm9, [rsp+0x50]
0000707649fd5d87  vpermilpd xmm9, xmm9, 0x00
0000707649fd5d8d  vmovaps [rsp+0x90], xmm1
0000707649fd5d96  vmovaps [rsp+0xE0], xmm15
0000707649fd5d9f  vmovaps xmm15, [rsp+0x80]
0000707649fd5da8  vmovaps [rsp+0x80], xmm14
0000707649fd5db1  movaps xmm1, xmm15
0000707649fd5db5  mulpd xmm1, xmm9
0000707649fd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
0000707649fd5dbf  ptest xmm14, xmm14
0000707649fd5dc5  jnz 0x0000707649FD7ABF
0000707649fd5dcb  lea r14, [rax+0x90]
0000707649fd5dd2  movups xmm15, [r13+r14*1]
0000707649fd5dd8  vmovaps xmm14, [rsp+0xD0]
0000707649fd5de1  vmovaps xmm9, [rsp+0xD0]
0000707649fd5dea  por xmm14, xmm9
0000707649fd5def  movaps [r15+0x1C0], xmm14
0000707649fd5df7  vmovaps xmm9, [rsp+0xC0]
0000707649fd5e00  vmovaps [rsp+0xD0], xmm1
0000707649fd5e09  vmovaps xmm1, [rsp+0xC0]
0000707649fd5e12  por xmm9, xmm1
0000707649fd5e17  movaps [r15+0x200], xmm9
0000707649fd5e1f  vmovaps [rsp+0xC0], xmm2
0000707649fd5e28  vmovaps xmm1, [rsp+0xC0]
0000707649fd5e31  por xmm2, xmm1
0000707649fd5e35  movaps [r15+0x2D0], xmm2
0000707649fd5e3d  vmovaps [rsp+0xC0], xmm8
0000707649fd5e46  vmovaps xmm1, [rsp+0xC0]
0000707649fd5e4f  por xmm8, xmm1
0000707649fd5e54  movaps [r15+0x2E0], xmm8
0000707649fd5e5c  vmovaps [rsp+0xC0], xmm15
0000707649fd5e65  movaps xmm1, xmm5
0000707649fd5e68  addpd xmm1, xmm7
0000707649fd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
0000707649fd5e71  ptest xmm15, xmm15
0000707649fd5e77  jnz 0x0000707649FD7C0B
0000707649fd5e7d  vmovaps xmm15, [rsp+0x50]
0000707649fd5e83  vpermilpd xmm15, xmm15, 0x00
0000707649fd5e89  vmovaps xmm5, [rsp+0xC0]
0000707649fd5e92  vmovaps [rsp+0xC0], xmm1
0000707649fd5e9b  movaps xmm7, xmm5
0000707649fd5e9e  mulpd xmm7, xmm15
0000707649fd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
0000707649fd5ea8  ptest xmm1, xmm1
0000707649fd5ead  jnz 0x0000707649FD7D4B
0000707649fd5eb3  lea r14, [rax+0x80]
0000707649fd5eba  movups xmm1, [r13+r14*1]
0000707649fd5ec0  vmovaps xmm5, [rsp+0x70]
0000707649fd5ec6  vmovaps [rsp+0x70], xmm1
0000707649fd5ecc  movaps xmm15, xmm5
0000707649fd5ed0  addpd xmm15, xmm3
0000707649fd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
0000707649fd5edb  ptest xmm1, xmm1
0000707649fd5ee0  jnz 0x0000707649FD7E96
0000707649fd5ee6  vmovaps xmm5, [rsp+0x80]
0000707649fd5eef  movaps xmm1, xmm5
0000707649fd5ef2  addpd xmm1, xmm4
0000707649fd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
0000707649fd5efb  ptest xmm3, xmm3
0000707649fd5f00  jnz 0x0000707649FD7FD8
0000707649fd5f06  vmovaps [rsp+0x80], xmm10
0000707649fd5f0f  vmovaps xmm5, [rsp+0x80]
0000707649fd5f18  por xmm10, xmm5
0000707649fd5f1d  movaps [r15+0x2F0], xmm10
0000707649fd5f25  vmovaps xmm5, [rsp+0x50]
0000707649fd5f2b  vpermilpd xmm5, xmm5, 0x00
0000707649fd5f31  vmovaps xmm3, [rsp+0x70]
0000707649fd5f37  vmovaps [rsp+0x50], xmm1
0000707649fd5f3d  movaps xmm4, xmm3
0000707649fd5f40  mulpd xmm4, xmm5
0000707649fd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
0000707649fd5f49  ptest xmm1, xmm1
0000707649fd5f4e  jnz 0x0000707649FD8118
0000707649fd5f54  lea r14, [rax+0xD0]
0000707649fd5f5b  movups xmm1, [r13+r14*1]
0000707649fd5f61  vmovaps xmm3, [rsp+0xD0]
0000707649fd5f6a  vmovaps [rsp+0x70], xmm1
0000707649fd5f70  movaps xmm5, xmm6
0000707649fd5f73  addpd xmm5, xmm3
0000707649fd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
0000707649fd5f7c  ptest xmm1, xmm1
0000707649fd5f81  jnz 0x0000707649FD8262
0000707649fd5f87  vmovaps xmm1, [rsp+0x60]
0000707649fd5f8d  vpermilpd xmm1, xmm1, 0x00
0000707649fd5f93  movaps xmm6, xmm9
0000707649fd5f97  mulpd xmm6, xmm1
0000707649fd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
0000707649fd5fa0  ptest xmm3, xmm3
0000707649fd5fa5  jnz 0x0000707649FD83A2
0000707649fd5fab  movaps [r15+0x260], xmm6
0000707649fd5fb3  vxorps xmm1, xmm1, xmm1
0000707649fd5fb7  vpbroadcastq xmm1, xmm1
0000707649fd5fbc  movaps [r15+0x1B0], xmm1
0000707649fd5fc4  vmovaps xmm1, [rsp+0x60]
0000707649fd5fca  vpermilpd xmm1, xmm1, 0x00
0000707649fd5fd0  vmovaps xmm3, [rsp+0x70]
0000707649fd5fd6  vmovaps [rsp+0x70], xmm15
0000707649fd5fdc  movaps xmm9, xmm3
0000707649fd5fe0  mulpd xmm9, xmm1
0000707649fd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
0000707649fd5feb  ptest xmm15, xmm15
0000707649fd5ff1  jnz 0x0000707649FD84E3
0000707649fd5ff7  lea r14, [rax+0xC0]
0000707649fd5ffe  movups xmm1, [r13+r14*1]
0000707649fd6004  vmovaps xmm3, [rsp+0xC0]
0000707649fd600d  vmovaps [rsp+0x80], xmm1
0000707649fd6016  movaps xmm15, xmm3
0000707649fd601a  addpd xmm15, xmm7
0000707649fd601f  vcmppd xmm1, xmm15, xmm15, 0x03
0000707649fd6025  ptest xmm1, xmm1
0000707649fd602a  jnz 0x0000707649FD862F
0000707649fd6030  vmovaps [rsp+0xC0], xmm13
0000707649fd6039  vmovaps xmm1, [rsp+0xC0]
0000707649fd6042  por xmm13, xmm1
0000707649fd6047  movaps [r15+0x270], xmm13
0000707649fd604f  vmovaps xmm1, [rsp+0xB0]
0000707649fd6058  vmovaps xmm7, [rsp+0xB0]
0000707649fd6061  por xmm1, xmm7
0000707649fd6065  movaps [r15+0x1A0], xmm1
0000707649fd606d  vmovaps xmm1, [rsp+0x60]
0000707649fd6073  vpermilpd xmm1, xmm1, 0x00
0000707649fd6079  vmovaps [rsp+0xB0], xmm1
0000707649fd6082  vmovaps xmm1, [rsp+0x80]
0000707649fd608b  vmovaps [rsp+0x80], xmm15
0000707649fd6094  vmovaps xmm15, [rsp+0xB0]
0000707649fd609d  vmovaps [rsp+0xB0], xmm14
0000707649fd60a6  movaps xmm3, xmm1
0000707649fd60a9  mulpd xmm3, xmm15
0000707649fd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
0000707649fd60b3  ptest xmm14, xmm14
0000707649fd60b9  jnz 0x0000707649FD8771
0000707649fd60bf  lea r14, [rax+0x20]
0000707649fd60c3  movups xmm1, [r13+r14*1]
0000707649fd60c9  movaps [r15+0x110], xmm1
0000707649fd60d1  vmovaps xmm14, [rsp+0x70]
0000707649fd60d7  vmovaps [rsp+0x70], xmm1
0000707649fd60dd  movaps xmm15, xmm14
0000707649fd60e1  addpd xmm15, xmm4
0000707649fd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
0000707649fd60ec  ptest xmm1, xmm1
0000707649fd60f1  jnz 0x0000707649FD88BC
0000707649fd60f7  vmovaps xmm1, [rsp+0x60]
0000707649fd60fd  vpermilpd xmm1, xmm1, 0x00
0000707649fd6103  movaps xmm14, xmm2
0000707649fd6107  mulpd xmm14, xmm1
0000707649fd610c  vcmppd xmm4, xmm14, xmm14, 0x03
0000707649fd6112  ptest xmm4, xmm4
0000707649fd6117  jnz 0x0000707649FD89FF
0000707649fd611d  vmovaps xmm4, [rsp+0x50]
0000707649fd6123  movaps xmm1, xmm4
0000707649fd6126  addpd xmm1, xmm9
0000707649fd612b  vcmppd xmm2, xmm1, xmm1, 0x03
0000707649fd6130  ptest xmm2, xmm2
0000707649fd6135  jnz 0x0000707649FD8B41
0000707649fd613b  vmovaps xmm9, [rsp+0x30]
0000707649fd6141  vpermilpd xmm9, xmm9, 0x00
0000707649fd6147  vmovaps xmm2, [rsp+0x70]
0000707649fd614d  vmovaps [rsp+0x50], xmm1
0000707649fd6153  movaps xmm4, xmm2
0000707649fd6156  mulpd xmm4, xmm9
0000707649fd615b  vcmppd xmm1, xmm4, xmm4, 0x03
0000707649fd6160  ptest xmm1, xmm1
0000707649fd6165  jnz 0x0000707649FD8C82
0000707649fd616b  vmovaps xmm1, [rsp+0x30]
0000707649fd6171  vpermilpd xmm1, xmm1, 0x00
0000707649fd6177  vmovaps xmm2, [rsp+0x90]
0000707649fd6180  vmovaps [rsp+0x60], xmm15
0000707649fd6186  movaps xmm9, xmm2
0000707649fd618a  mulpd xmm9, xmm1
0000707649fd618f  vcmppd xmm15, xmm9, xmm9, 0x03
0000707649fd6195  ptest xmm15, xmm15
0000707649fd619b  jnz 0x0000707649FD8DC3
0000707649fd61a1  vmovaps xmm15, [rsp+0x80]
0000707649fd61aa  movaps xmm1, xmm15
0000707649fd61ae  addpd xmm1, xmm6
0000707649fd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
0000707649fd61b7  ptest xmm2, xmm2
0000707649fd61bc  jnz 0x0000707649FD8F05
0000707649fd61c2  movaps xmm15, xmm5
0000707649fd61c6  addpd xmm15, xmm3
0000707649fd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
0000707649fd61d1  ptest xmm6, xmm6
0000707649fd61d6  jnz 0x0000707649FD9046
0000707649fd61dc  vmovaps xmm6, [rsp+0x30]
0000707649fd61e2  vpermilpd xmm6, xmm6, 0x00
0000707649fd61e8  movaps xmm5, xmm8
0000707649fd61ec  mulpd xmm5, xmm6
0000707649fd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
0000707649fd61f5  ptest xmm3, xmm3
0000707649fd61fa  jnz 0x0000707649FD9188
0000707649fd6200  vmovaps xmm8, [rsp+0x30]
0000707649fd6206  vpermilpd xmm8, xmm8, 0x00
0000707649fd620c  movaps xmm6, xmm10
0000707649fd6210  mulpd xmm6, xmm8
0000707649fd6215  vcmppd xmm3, xmm6, xmm6, 0x03
0000707649fd621a  ptest xmm3, xmm3
0000707649fd621f  jnz 0x0000707649FD92C9
0000707649fd6225  vmovaps xmm8, [rsp+0x60]
0000707649fd622b  movaps xmm10, xmm8
0000707649fd622f  addpd xmm10, xmm14
0000707649fd6234  vcmppd xmm3, xmm10, xmm10, 0x03
0000707649fd623a  ptest xmm3, xmm3
0000707649fd623f  jnz 0x0000707649FD940B
0000707649fd6245  vmovaps xmm8, [rsp+0x50]
0000707649fd624b  movaps xmm14, xmm8
0000707649fd624f  addpd xmm14, xmm4
0000707649fd6254  vcmppd xmm3, xmm14, xmm14, 0x03
0000707649fd625a  ptest xmm3, xmm3
0000707649fd625f  jnz 0x0000707649FD954F
0000707649fd6265  vmovaps xmm8, [rsp+0x40]
0000707649fd626b  vpermilpd xmm8, xmm8, 0x00
0000707649fd6271  movaps xmm4, xmm13
0000707649fd6275  mulpd xmm4, xmm8
0000707649fd627a  vcmppd xmm3, xmm4, xmm4, 0x03
0000707649fd627f  ptest xmm3, xmm3
0000707649fd6284  jnz 0x0000707649FD9692
0000707649fd628a  movaps xmm13, xmm15
0000707649fd628e  addpd xmm13, xmm9
0000707649fd6293  vcmppd xmm8, xmm13, xmm13, 0x03
0000707649fd6299  ptest xmm8, xmm8
0000707649fd629f  jnz 0x0000707649FD97D4
0000707649fd62a5  movaps xmm15, xmm1
0000707649fd62a9  addpd xmm15, xmm5
0000707649fd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
0000707649fd62b4  ptest xmm9, xmm9
0000707649fd62ba  jnz 0x0000707649FD9918
0000707649fd62c0  vmovaps [rsp+0x30], xmm11
0000707649fd62c6  vmovaps xmm1, [rsp+0x30]
0000707649fd62cc  por xmm11, xmm1
0000707649fd62d1  movaps [r15+0x250], xmm11
0000707649fd62d9  vmovaps [rsp+0x30], xmm12
0000707649fd62df  vmovaps xmm1, [rsp+0x30]
0000707649fd62e5  por xmm12, xmm1
0000707649fd62ea  movaps [r15+0x2A0], xmm12
0000707649fd62f2  vmovaps xmm1, [rsp+0xA0]
0000707649fd62fb  vmovaps xmm11, [rsp+0xA0]
0000707649fd6304  por xmm1, xmm11
0000707649fd6309  movaps [r15+0x1D0], xmm1
0000707649fd6311  lea r14, [rax+0x40]
0000707649fd6315  movups xmm1, [r13+r14*1]
0000707649fd631b  movaps [r15+0x2C0], xmm1
0000707649fd6323  vmovaps xmm11, [rsp+0x40]
0000707649fd6329  vpermilpd xmm11, xmm11, 0x00
0000707649fd632f  vmovaps xmm8, [rsp+0xE0]
0000707649fd6338  movaps xmm9, xmm8
0000707649fd633c  mulpd xmm9, xmm11
0000707649fd6341  vcmppd xmm5, xmm9, xmm9, 0x03
0000707649fd6347  ptest xmm5, xmm5
0000707649fd634c  jnz 0x0000707649FD9A64
0000707649fd6352  movaps xmm11, xmm10
0000707649fd6356  addpd xmm11, xmm6
0000707649fd635b  vcmppd xmm8, xmm11, xmm11, 0x03
0000707649fd6361  ptest xmm8, xmm8
0000707649fd6367  jnz 0x0000707649FD9BA8
0000707649fd636d  movaps xmm10, xmm14
0000707649fd6371  addpd xmm10, xmm4
0000707649fd6376  vcmppd xmm8, xmm10, xmm10, 0x03
0000707649fd637c  ptest xmm8, xmm8
0000707649fd6382  jnz 0x0000707649FD9CEB
0000707649fd6388  vmovaps xmm14, [rsp+0x40]
0000707649fd638e  vpermilpd xmm14, xmm14, 0x00
0000707649fd6394  movaps xmm8, xmm1
0000707649fd6398  mulpd xmm8, xmm14
0000707649fd639d  vcmppd xmm6, xmm8, xmm8, 0x03
0000707649fd63a3  ptest xmm6, xmm6
0000707649fd63a8  jnz 0x0000707649FD9E2E
0000707649fd63ae  movaps xmm1, [r15+0x2B0]
0000707649fd63b6  vmovaps xmm14, [rsp+0x40]
0000707649fd63bc  vpermilpd xmm14, xmm14, 0x00
0000707649fd63c2  movaps xmm6, xmm1
0000707649fd63c5  mulpd xmm6, xmm14
0000707649fd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
0000707649fd63cf  ptest xmm5, xmm5
0000707649fd63d4  jnz 0x0000707649FD9F71
0000707649fd63da  vmovaps xmm1, [rsp+0x10]
0000707649fd63e0  vpermilpd xmm1, xmm1, 0x00
0000707649fd63e6  movaps xmm14, xmm12
0000707649fd63ea  mulpd xmm14, xmm1
0000707649fd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
0000707649fd63f5  ptest xmm5, xmm5
0000707649fd63fa  jnz 0x0000707649FDA0B2
0000707649fd6400  movaps xmm1, xmm13
0000707649fd6404  addpd xmm1, xmm9
0000707649fd6409  vcmppd xmm12, xmm1, xmm1, 0x03
0000707649fd640e  ptest xmm12, xmm12
0000707649fd6414  jnz 0x0000707649FDA1F5
0000707649fd641a  vmovaps xmm13, [rsp+0x10]
0000707649fd6420  vpermilpd xmm13, xmm13, 0x00
0000707649fd6426  movaps xmm12, xmm7
0000707649fd642a  mulpd xmm12, xmm13
0000707649fd642f  vcmppd xmm9, xmm12, xmm12, 0x03
0000707649fd6435  ptest xmm9, xmm9
0000707649fd643b  jnz 0x0000707649FDA337
0000707649fd6441  movaps xmm13, xmm15
0000707649fd6445  addpd xmm13, xmm8
0000707649fd644a  vcmppd xmm9, xmm13, xmm13, 0x03
0000707649fd6450  ptest xmm9, xmm9
0000707649fd6456  jnz 0x0000707649FDA47A
0000707649fd645c  movaps xmm15, [r15+0x290]
0000707649fd6464  vmovaps xmm9, [rsp+0x10]
0000707649fd646a  vpermilpd xmm9, xmm9, 0x00
0000707649fd6470  movaps xmm8, xmm15
0000707649fd6474  mulpd xmm8, xmm9
0000707649fd6479  vcmppd xmm7, xmm8, xmm8, 0x03
0000707649fd647f  ptest xmm7, xmm7
0000707649fd6484  jnz 0x0000707649FDA5BE
0000707649fd648a  movaps xmm15, xmm11
0000707649fd648e  addpd xmm15, xmm6
0000707649fd6493  vcmppd xmm9, xmm15, xmm15, 0x03
0000707649fd6499  ptest xmm9, xmm9
0000707649fd649f  jnz 0x0000707649FDA702
0000707649fd64a5  movaps xmm11, [r15+0x1E0]
0000707649fd64ad  vmovaps xmm9, [rsp+0x10]
0000707649fd64b3  vpermilpd xmm9, xmm9, 0x00
0000707649fd64b9  movaps xmm7, xmm11
0000707649fd64bd  mulpd xmm7, xmm9
0000707649fd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
0000707649fd64c7  ptest xmm6, xmm6
0000707649fd64cc  jnz 0x0000707649FDA845
0000707649fd64d2  movaps xmm11, xmm10
0000707649fd64d6  addpd xmm11, xmm14
0000707649fd64db  vcmppd xmm9, xmm11, xmm11, 0x03
0000707649fd64e1  ptest xmm9, xmm9
0000707649fd64e7  jnz 0x0000707649FDA987
0000707649fd64ed  lea r14, [rax+0x70]
0000707649fd64f1  movups xmm14, [r13+r14*1]
0000707649fd64f7  movaps [r15+0x240], xmm14
0000707649fd64ff  movaps xmm10, xmm1
0000707649fd6503  addpd xmm10, xmm12
0000707649fd6508  vcmppd xmm9, xmm10, xmm10, 0x03
0000707649fd650e  ptest xmm9, xmm9
0000707649fd6514  jnz 0x0000707649FDAAD5
0000707649fd651a  movaps [r15+0x170], xmm10
0000707649fd6522  vmovaps xmm1, [rsp+0x20]
0000707649fd6528  vpermilpd xmm1, xmm1, 0x00
0000707649fd652e  movaps xmm12, xmm14
0000707649fd6532  mulpd xmm12, xmm1
0000707649fd6537  vcmppd xmm9, xmm12, xmm12, 0x03
0000707649fd653d  ptest xmm9, xmm9
0000707649fd6543  jnz 0x0000707649FDAC18
0000707649fd6549  vmovaps xmm1, [rsp+0x20]
0000707649fd654f  vpermilpd xmm1, xmm1, 0x00
0000707649fd6555  vmovaps xmm9, [rsp+0xB0]
0000707649fd655e  movaps xmm14, xmm9
0000707649fd6562  mulpd xmm14, xmm1
0000707649fd6567  vcmppd xmm6, xmm14, xmm14, 0x03
0000707649fd656d  ptest xmm6, xmm6
0000707649fd6572  jnz 0x0000707649FDAD5B
0000707649fd6578  movaps [r15+0x180], xmm14
0000707649fd6580  movaps xmm1, xmm13
0000707649fd6584  addpd xmm1, xmm8
0000707649fd6589  vcmppd xmm9, xmm1, xmm1, 0x03
0000707649fd658e  ptest xmm9, xmm9
0000707649fd6594  jnz 0x0000707649FDAE9E
0000707649fd659a  movaps [r15+0x210], xmm1
0000707649fd65a2  movups xmm13, [r13+rax*1]
0000707649fd65a8  lea r14, [rax+0x10]
0000707649fd65ac  movups xmm9, [r13+r14*1]
0000707649fd65b2  movaps [r15+0x230], xmm9
0000707649fd65ba  movaps xmm8, xmm15
0000707649fd65be  addpd xmm8, xmm7
0000707649fd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
0000707649fd65c9  ptest xmm6, xmm6
0000707649fd65ce  jnz 0x0000707649FDAFF4
0000707649fd65d4  movaps [r15+0x130], xmm8
0000707649fd65dc  vmovaps xmm15, [rsp+0x20]
0000707649fd65e2  vpermilpd xmm15, xmm15, 0x00
0000707649fd65e8  movaps xmm7, xmm9
0000707649fd65ec  mulpd xmm7, xmm15
0000707649fd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
0000707649fd65f6  ptest xmm6, xmm6
0000707649fd65fb  jnz 0x0000707649FDB137
0000707649fd6601  movaps [r15+0x220], xmm7
0000707649fd6609  vmovaps xmm15, [rsp+0x20]
0000707649fd660f  vpermilpd xmm15, xmm15, 0x00
0000707649fd6615  movaps xmm9, xmm13
0000707649fd6619  mulpd xmm9, xmm15
0000707649fd661e  vcmppd xmm6, xmm9, xmm9, 0x03
0000707649fd6624  ptest xmm6, xmm6
0000707649fd6629  jnz 0x0000707649FDB279
0000707649fd662f  movaps xmm15, xmm11
0000707649fd6633  addpd xmm15, xmm12
0000707649fd6638  vcmppd xmm13, xmm15, xmm15, 0x03
0000707649fd663e  ptest xmm13, xmm13
0000707649fd6644  jnz 0x0000707649FDB3BD
0000707649fd664a  movaps [r15+0x140], xmm15
0000707649fd6652  movaps xmm13, xmm10
0000707649fd6656  addpd xmm13, xmm14
0000707649fd665b  vcmppd xmm12, xmm13, xmm13, 0x03
0000707649fd6661  ptest xmm12, xmm12
0000707649fd6667  jnz 0x0000707649FDB501
0000707649fd666d  movaps [r15+0x150], xmm13
0000707649fd6675  movaps xmm14, xmm1
0000707649fd6679  addpd xmm14, xmm7
0000707649fd667e  vcmppd xmm12, xmm14, xmm14, 0x03
0000707649fd6684  ptest xmm12, xmm12
0000707649fd668a  jnz 0x0000707649FDB645
0000707649fd6690  movaps [r15+0x160], xmm14
0000707649fd6698  movaps xmm1, xmm8
0000707649fd669c  addpd xmm1, xmm9
0000707649fd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
0000707649fd66a6  ptest xmm12, xmm12
0000707649fd66ac  jnz 0x0000707649FDB787
0000707649fd66b2  movaps [r15+0x120], xmm1
0000707649fd66ba  movups [r13+r11*1], xmm15
0000707649fd66c0  lea rax, [r11+0x10]
0000707649fd66c4  movups [r13+rax*1], xmm13
0000707649fd66ca  lea rax, [r11+0x20]
0000707649fd66ce  movups [r13+rax*1], xmm14
0000707649fd66d4  lea rax, [r11+0x30]
0000707649fd66d8  movups [r13+rax*1], xmm1
0000707649fd66de  mov eax, [r15+0x108]
0000707649fd66e5  sahf
0000707649fd66e6  jnz 0x0000707649FD6718
0000707649fd66e8  cmp dword ptr [r15+0x318], 0x00
0000707649fd66f0  jz 0x0000707649FDB900
0000707649fd66f6  nop [rax+rax*1], ax
0000707649fd66ff  nop [rax+rax*1], eax
0000707649fd6707  mov eax, 0x410444
0000707649fd670c  mov [r15+0x100], rax
0000707649fd6713  jmp 0x0000707649DFE110
0000707649fd6718  cmp dword ptr [r15+0x318], 0x00
0000707649fd6720  jz 0x0000707649FD57E0
0000707649fd6726  nop [rax+rax*1], ax
0000707649fd672f  nop [rax+rax*1], eax
0000707649fd6737  mov eax, 0x410278
0000707649fd673c  mov [r15+0x100], rax
0000707649fd6743  jmp 0x0000707649DFE110
0000707649fd6748  int3
0000707649fd6749  call 0x0000707649E0A4B0
0000707649fd674e  jmp 0x0000707649FD5828
0000707649fd6753  call 0x0000707649E09240
0000707649fd6758  jmp 0x0000707649FD5832
0000707649fd675d  call 0x0000707649E0A4B0
0000707649fd6762  jmp 0x0000707649FD588F
0000707649fd6767  call 0x0000707649E09240
0000707649fd676c  jmp 0x0000707649FD5899
0000707649fd6771  call 0x0000707649E0A4B0
0000707649fd6776  jmp 0x0000707649FD58DD
0000707649fd677b  call 0x0000707649E09240
0000707649fd6780  jmp 0x0000707649FD58E7
0000707649fd6785  call 0x0000707649EB47C0
0000707649fd678a  jmp 0x0000707649FD5926
0000707649fd678f  call 0x0000707649E0B720
0000707649fd6794  jmp 0x0000707649FD593A
0000707649fd6799  call 0x0000707649EBFC30
0000707649fd679e  jmp 0x0000707649FD5958
0000707649fd67a3  call 0x0000707649EBE9C0
0000707649fd67a8  jmp 0x0000707649FD5962
0000707649fd67ad  call 0x0000707649EBD750
0000707649fd67b2  jmp 0x0000707649FD596C
0000707649fd67b7  sub rsp, 0x08
0000707649fd67bb  push rax
0000707649fd67bc  push rcx
0000707649fd67bd  push rdx
0000707649fd67be  push rdi
0000707649fd67bf  push rsi
0000707649fd67c0  push r8
0000707649fd67c2  push r9
0000707649fd67c4  push r10
0000707649fd67c6  push r11
0000707649fd67c8  sub rsp, 0xF0
0000707649fd67cf  vmovaps [rsp], xmm0
0000707649fd67d4  vmovaps [rsp+0x10], xmm1
0000707649fd67da  vmovaps [rsp+0x20], xmm2
0000707649fd67e0  vmovaps [rsp+0x30], xmm3
0000707649fd67e6  vmovaps [rsp+0x40], xmm4
0000707649fd67ec  vmovaps [rsp+0x50], xmm5
0000707649fd67f2  vmovaps [rsp+0x60], xmm6
0000707649fd67f8  vmovaps [rsp+0x70], xmm7
0000707649fd67fe  vmovaps [rsp+0x80], xmm9
0000707649fd6807  vmovaps [rsp+0x90], xmm10
0000707649fd6810  vmovaps [rsp+0xA0], xmm11
0000707649fd6819  vmovaps [rsp+0xB0], xmm12
0000707649fd6822  vmovaps [rsp+0xC0], xmm13
0000707649fd682b  vmovaps [rsp+0xD0], xmm14
0000707649fd6834  vmovaps [rsp+0xE0], xmm15
0000707649fd683d  sub rsp, 0x30
0000707649fd6841  movaps [rsp], xmm8
0000707649fd6846  movaps [rsp+0x10], xmm12
0000707649fd684c  movaps [rsp+0x20], xmm15
0000707649fd6852  lea rdi, [rsp]
0000707649fd6856  mov esi, 0x00
0000707649fd685b  mov rax, 0x59CB0B054530
0000707649fd6865  call rax
0000707649fd6867  movaps xmm8, [rsp]
0000707649fd686c  add rsp, 0x30
0000707649fd6870  vmovaps xmm0, [rsp]
0000707649fd6875  vmovaps xmm1, [rsp+0x10]
0000707649fd687b  vmovaps xmm2, [rsp+0x20]
0000707649fd6881  vmovaps xmm3, [rsp+0x30]
0000707649fd6887  vmovaps xmm4, [rsp+0x40]
0000707649fd688d  vmovaps xmm5, [rsp+0x50]
0000707649fd6893  vmovaps xmm6, [rsp+0x60]
0000707649fd6899  vmovaps xmm7, [rsp+0x70]
0000707649fd689f  vmovaps xmm9, [rsp+0x80]
0000707649fd68a8  vmovaps xmm10, [rsp+0x90]
0000707649fd68b1  vmovaps xmm11, [rsp+0xA0]
0000707649fd68ba  vmovaps xmm12, [rsp+0xB0]
0000707649fd68c3  vmovaps xmm13, [rsp+0xC0]
0000707649fd68cc  vmovaps xmm14, [rsp+0xD0]
0000707649fd68d5  vmovaps xmm15, [rsp+0xE0]
0000707649fd68de  add rsp, 0xF0
0000707649fd68e5  pop r11
0000707649fd68e7  pop r10
0000707649fd68e9  pop r9
0000707649fd68eb  pop r8
0000707649fd68ed  pop rsi
0000707649fd68ee  pop rdi
0000707649fd68ef  pop rdx
0000707649fd68f0  pop rcx
0000707649fd68f1  pop rax
0000707649fd68f2  add rsp, 0x08
0000707649fd68f6  jmp 0x0000707649FD599A
0000707649fd68fb  sub rsp, 0x08
0000707649fd68ff  push rax
0000707649fd6900  push rcx
0000707649fd6901  push rdx
0000707649fd6902  push rdi
0000707649fd6903  push rsi
0000707649fd6904  push r8
0000707649fd6906  push r9
0000707649fd6908  push r10
0000707649fd690a  push r11
0000707649fd690c  sub rsp, 0xF0
0000707649fd6913  vmovaps [rsp], xmm0
0000707649fd6918  vmovaps [rsp+0x10], xmm1
0000707649fd691e  vmovaps [rsp+0x20], xmm2
0000707649fd6924  vmovaps [rsp+0x30], xmm3
0000707649fd692a  vmovaps [rsp+0x40], xmm4
0000707649fd6930  vmovaps [rsp+0x50], xmm5
0000707649fd6936  vmovaps [rsp+0x60], xmm6
0000707649fd693c  vmovaps [rsp+0x70], xmm8
0000707649fd6942  vmovaps [rsp+0x80], xmm9
0000707649fd694b  vmovaps [rsp+0x90], xmm10
0000707649fd6954  vmovaps [rsp+0xA0], xmm11
0000707649fd695d  vmovaps [rsp+0xB0], xmm12
0000707649fd6966  vmovaps [rsp+0xC0], xmm13
0000707649fd696f  vmovaps [rsp+0xD0], xmm14
0000707649fd6978  vmovaps [rsp+0xE0], xmm15
0000707649fd6981  sub rsp, 0x30
0000707649fd6985  movaps [rsp], xmm7
0000707649fd6989  movaps [rsp+0x10], xmm9
0000707649fd698f  movaps [rsp+0x20], xmm15
0000707649fd6995  lea rdi, [rsp]
0000707649fd6999  mov esi, 0x00
0000707649fd699e  mov rax, 0x59CB0B054530
0000707649fd69a8  call rax
0000707649fd69aa  movaps xmm7, [rsp]
0000707649fd69ae  add rsp, 0x30
0000707649fd69b2  vmovaps xmm0, [rsp]
0000707649fd69b7  vmovaps xmm1, [rsp+0x10]
0000707649fd69bd  vmovaps xmm2, [rsp+0x20]
0000707649fd69c3  vmovaps xmm3, [rsp+0x30]
0000707649fd69c9  vmovaps xmm4, [rsp+0x40]
0000707649fd69cf  vmovaps xmm5, [rsp+0x50]
0000707649fd69d5  vmovaps xmm6, [rsp+0x60]
0000707649fd69db  vmovaps xmm8, [rsp+0x70]
0000707649fd69e1  vmovaps xmm9, [rsp+0x80]
0000707649fd69ea  vmovaps xmm10, [rsp+0x90]
0000707649fd69f3  vmovaps xmm11, [rsp+0xA0]
0000707649fd69fc  vmovaps xmm12, [rsp+0xB0]
0000707649fd6a05  vmovaps xmm13, [rsp+0xC0]
0000707649fd6a0e  vmovaps xmm14, [rsp+0xD0]
0000707649fd6a17  vmovaps xmm15, [rsp+0xE0]
0000707649fd6a20  add rsp, 0xF0
0000707649fd6a27  pop r11
0000707649fd6a29  pop r10
0000707649fd6a2b  pop r9
0000707649fd6a2d  pop r8
0000707649fd6a2f  pop rsi
0000707649fd6a30  pop rdi
0000707649fd6a31  pop rdx
0000707649fd6a32  pop rcx
0000707649fd6a33  pop rax
0000707649fd6a34  add rsp, 0x08
0000707649fd6a38  jmp 0x0000707649FD59C8
0000707649fd6a3d  sub rsp, 0x08
0000707649fd6a41  push rax
0000707649fd6a42  push rcx
0000707649fd6a43  push rdx
0000707649fd6a44  push rdi
0000707649fd6a45  push rsi
0000707649fd6a46  push r8
0000707649fd6a48  push r9
0000707649fd6a4a  push r10
0000707649fd6a4c  push r11
0000707649fd6a4e  sub rsp, 0xF0
0000707649fd6a55  vmovaps [rsp], xmm0
0000707649fd6a5a  vmovaps [rsp+0x10], xmm1
0000707649fd6a60  vmovaps [rsp+0x20], xmm2
0000707649fd6a66  vmovaps [rsp+0x30], xmm3
0000707649fd6a6c  vmovaps [rsp+0x40], xmm4
0000707649fd6a72  vmovaps [rsp+0x50], xmm5
0000707649fd6a78  vmovaps [rsp+0x60], xmm6
0000707649fd6a7e  vmovaps [rsp+0x70], xmm7
0000707649fd6a84  vmovaps [rsp+0x80], xmm8
0000707649fd6a8d  vmovaps [rsp+0x90], xmm10
0000707649fd6a96  vmovaps [rsp+0xA0], xmm11
0000707649fd6a9f  vmovaps [rsp+0xB0], xmm12
0000707649fd6aa8  vmovaps [rsp+0xC0], xmm13
0000707649fd6ab1  vmovaps [rsp+0xD0], xmm14
0000707649fd6aba  vmovaps [rsp+0xE0], xmm15
0000707649fd6ac3  sub rsp, 0x30
0000707649fd6ac7  movaps [rsp], xmm9
0000707649fd6acc  movaps [rsp+0x10], xmm12
0000707649fd6ad2  movaps [rsp+0x20], xmm10
0000707649fd6ad8  lea rdi, [rsp]
0000707649fd6adc  mov esi, 0x00
0000707649fd6ae1  mov rax, 0x59CB0B054530
0000707649fd6aeb  call rax
0000707649fd6aed  movaps xmm9, [rsp]
0000707649fd6af2  add rsp, 0x30
0000707649fd6af6  vmovaps xmm0, [rsp]
0000707649fd6afb  vmovaps xmm1, [rsp+0x10]
0000707649fd6b01  vmovaps xmm2, [rsp+0x20]
0000707649fd6b07  vmovaps xmm3, [rsp+0x30]
0000707649fd6b0d  vmovaps xmm4, [rsp+0x40]
0000707649fd6b13  vmovaps xmm5, [rsp+0x50]
0000707649fd6b19  vmovaps xmm6, [rsp+0x60]
0000707649fd6b1f  vmovaps xmm7, [rsp+0x70]
0000707649fd6b25  vmovaps xmm8, [rsp+0x80]
0000707649fd6b2e  vmovaps xmm10, [rsp+0x90]
0000707649fd6b37  vmovaps xmm11, [rsp+0xA0]
0000707649fd6b40  vmovaps xmm12, [rsp+0xB0]
0000707649fd6b49  vmovaps xmm13, [rsp+0xC0]
0000707649fd6b52  vmovaps xmm14, [rsp+0xD0]
0000707649fd6b5b  vmovaps xmm15, [rsp+0xE0]
0000707649fd6b64  add rsp, 0xF0
0000707649fd6b6b  pop r11
0000707649fd6b6d  pop r10
0000707649fd6b6f  pop r9
0000707649fd6b71  pop r8
0000707649fd6b73  pop rsi
0000707649fd6b74  pop rdi
0000707649fd6b75  pop rdx
0000707649fd6b76  pop rcx
0000707649fd6b77  pop rax
0000707649fd6b78  add rsp, 0x08
0000707649fd6b7c  jmp 0x0000707649FD59EC
0000707649fd6b81  sub rsp, 0x08
0000707649fd6b85  push rax
0000707649fd6b86  push rcx
0000707649fd6b87  push rdx
0000707649fd6b88  push rdi
0000707649fd6b89  push rsi
0000707649fd6b8a  push r8
0000707649fd6b8c  push r9
0000707649fd6b8e  push r10
0000707649fd6b90  push r11
0000707649fd6b92  sub rsp, 0xF0
0000707649fd6b99  vmovaps [rsp], xmm0
0000707649fd6b9e  vmovaps [rsp+0x10], xmm1
0000707649fd6ba4  vmovaps [rsp+0x20], xmm2
0000707649fd6baa  vmovaps [rsp+0x30], xmm3
0000707649fd6bb0  vmovaps [rsp+0x40], xmm4
0000707649fd6bb6  vmovaps [rsp+0x50], xmm5
0000707649fd6bbc  vmovaps [rsp+0x60], xmm6
0000707649fd6bc2  vmovaps [rsp+0x70], xmm7
0000707649fd6bc8  vmovaps [rsp+0x80], xmm8
0000707649fd6bd1  vmovaps [rsp+0x90], xmm9
0000707649fd6bda  vmovaps [rsp+0xA0], xmm11
0000707649fd6be3  vmovaps [rsp+0xB0], xmm12
0000707649fd6bec  vmovaps [rsp+0xC0], xmm13
0000707649fd6bf5  vmovaps [rsp+0xD0], xmm14
0000707649fd6bfe  vmovaps [rsp+0xE0], xmm15
0000707649fd6c07  sub rsp, 0x30
0000707649fd6c0b  movaps [rsp], xmm10
0000707649fd6c10  movaps [rsp+0x10], xmm12
0000707649fd6c16  movaps [rsp+0x20], xmm11
0000707649fd6c1c  lea rdi, [rsp]
0000707649fd6c20  mov esi, 0x00
0000707649fd6c25  mov rax, 0x59CB0B054530
0000707649fd6c2f  call rax
0000707649fd6c31  movaps xmm10, [rsp]
0000707649fd6c36  add rsp, 0x30
0000707649fd6c3a  vmovaps xmm0, [rsp]
0000707649fd6c3f  vmovaps xmm1, [rsp+0x10]
0000707649fd6c45  vmovaps xmm2, [rsp+0x20]
0000707649fd6c4b  vmovaps xmm3, [rsp+0x30]
0000707649fd6c51  vmovaps xmm4, [rsp+0x40]
0000707649fd6c57  vmovaps xmm5, [rsp+0x50]
0000707649fd6c5d  vmovaps xmm6, [rsp+0x60]
0000707649fd6c63  vmovaps xmm7, [rsp+0x70]
0000707649fd6c69  vmovaps xmm8, [rsp+0x80]
0000707649fd6c72  vmovaps xmm9, [rsp+0x90]
0000707649fd6c7b  vmovaps xmm11, [rsp+0xA0]
0000707649fd6c84  vmovaps xmm12, [rsp+0xB0]
0000707649fd6c8d  vmovaps xmm13, [rsp+0xC0]
0000707649fd6c96  vmovaps xmm14, [rsp+0xD0]
0000707649fd6c9f  vmovaps xmm15, [rsp+0xE0]
0000707649fd6ca8  add rsp, 0xF0
0000707649fd6caf  pop r11
0000707649fd6cb1  pop r10
0000707649fd6cb3  pop r9
0000707649fd6cb5  pop r8
0000707649fd6cb7  pop rsi
0000707649fd6cb8  pop rdi
0000707649fd6cb9  pop rdx
0000707649fd6cba  pop rcx
0000707649fd6cbb  pop rax
0000707649fd6cbc  add rsp, 0x08
0000707649fd6cc0  jmp 0x0000707649FD5A06
0000707649fd6cc5  sub rsp, 0x08
0000707649fd6cc9  push rax
0000707649fd6cca  push rcx
0000707649fd6ccb  push rdx
0000707649fd6ccc  push rdi
0000707649fd6ccd  push rsi
0000707649fd6cce  push r8
0000707649fd6cd0  push r9
0000707649fd6cd2  push r10
0000707649fd6cd4  push r11
0000707649fd6cd6  sub rsp, 0xF0
0000707649fd6cdd  vmovaps [rsp], xmm0
0000707649fd6ce2  vmovaps [rsp+0x10], xmm1
0000707649fd6ce8  vmovaps [rsp+0x20], xmm2
0000707649fd6cee  vmovaps [rsp+0x30], xmm3
0000707649fd6cf4  vmovaps [rsp+0x40], xmm4
0000707649fd6cfa  vmovaps [rsp+0x50], xmm5
0000707649fd6d00  vmovaps [rsp+0x60], xmm7
0000707649fd6d06  vmovaps [rsp+0x70], xmm8
0000707649fd6d0c  vmovaps [rsp+0x80], xmm9
0000707649fd6d15  vmovaps [rsp+0x90], xmm10
0000707649fd6d1e  vmovaps [rsp+0xA0], xmm11
0000707649fd6d27  vmovaps [rsp+0xB0], xmm12
0000707649fd6d30  vmovaps [rsp+0xC0], xmm13
0000707649fd6d39  vmovaps [rsp+0xD0], xmm14
0000707649fd6d42  vmovaps [rsp+0xE0], xmm15
0000707649fd6d4b  sub rsp, 0x30
0000707649fd6d4f  movaps [rsp], xmm6
0000707649fd6d53  movaps [rsp+0x10], xmm12
0000707649fd6d59  movaps [rsp+0x20], xmm11
0000707649fd6d5f  lea rdi, [rsp]
0000707649fd6d63  mov esi, 0x00
0000707649fd6d68  mov rax, 0x59CB0B054530
0000707649fd6d72  call rax
0000707649fd6d74  movaps xmm6, [rsp]
0000707649fd6d78  add rsp, 0x30
0000707649fd6d7c  vmovaps xmm0, [rsp]
0000707649fd6d81  vmovaps xmm1, [rsp+0x10]
0000707649fd6d87  vmovaps xmm2, [rsp+0x20]
0000707649fd6d8d  vmovaps xmm3, [rsp+0x30]
0000707649fd6d93  vmovaps xmm4, [rsp+0x40]
0000707649fd6d99  vmovaps xmm5, [rsp+0x50]
0000707649fd6d9f  vmovaps xmm7, [rsp+0x60]
0000707649fd6da5  vmovaps xmm8, [rsp+0x70]
0000707649fd6dab  vmovaps xmm9, [rsp+0x80]
0000707649fd6db4  vmovaps xmm10, [rsp+0x90]
0000707649fd6dbd  vmovaps xmm11, [rsp+0xA0]
0000707649fd6dc6  vmovaps xmm12, [rsp+0xB0]
0000707649fd6dcf  vmovaps xmm13, [rsp+0xC0]
0000707649fd6dd8  vmovaps xmm14, [rsp+0xD0]
0000707649fd6de1  vmovaps xmm15, [rsp+0xE0]
0000707649fd6dea  add rsp, 0xF0
0000707649fd6df1  pop r11
0000707649fd6df3  pop r10
0000707649fd6df5  pop r9
0000707649fd6df7  pop r8
0000707649fd6df9  pop rsi
0000707649fd6dfa  pop rdi
0000707649fd6dfb  pop rdx
0000707649fd6dfc  pop rcx
0000707649fd6dfd  pop rax
0000707649fd6dfe  add rsp, 0x08
0000707649fd6e02  jmp 0x0000707649FD5A27
0000707649fd6e07  sub rsp, 0x08
0000707649fd6e0b  push rax
0000707649fd6e0c  push rcx
0000707649fd6e0d  push rdx
0000707649fd6e0e  push rdi
0000707649fd6e0f  push rsi
0000707649fd6e10  push r8
0000707649fd6e12  push r9
0000707649fd6e14  push r10
0000707649fd6e16  push r11
0000707649fd6e18  sub rsp, 0xF0
0000707649fd6e1f  vmovaps [rsp], xmm0
0000707649fd6e24  vmovaps [rsp+0x10], xmm1
0000707649fd6e2a  vmovaps [rsp+0x20], xmm2
0000707649fd6e30  vmovaps [rsp+0x30], xmm4
0000707649fd6e36  vmovaps [rsp+0x40], xmm5
0000707649fd6e3c  vmovaps [rsp+0x50], xmm6
0000707649fd6e42  vmovaps [rsp+0x60], xmm7
0000707649fd6e48  vmovaps [rsp+0x70], xmm8
0000707649fd6e4e  vmovaps [rsp+0x80], xmm9
0000707649fd6e57  vmovaps [rsp+0x90], xmm10
0000707649fd6e60  vmovaps [rsp+0xA0], xmm11
0000707649fd6e69  vmovaps [rsp+0xB0], xmm12
0000707649fd6e72  vmovaps [rsp+0xC0], xmm13
0000707649fd6e7b  vmovaps [rsp+0xD0], xmm14
0000707649fd6e84  vmovaps [rsp+0xE0], xmm15
0000707649fd6e8d  sub rsp, 0x30
0000707649fd6e91  movaps [rsp], xmm3
0000707649fd6e95  movaps [rsp+0x10], xmm5
0000707649fd6e9a  movaps [rsp+0x20], xmm4
0000707649fd6e9f  lea rdi, [rsp]
0000707649fd6ea3  mov esi, 0x00
0000707649fd6ea8  mov rax, 0x59CB0B054530
0000707649fd6eb2  call rax
0000707649fd6eb4  movaps xmm3, [rsp]
0000707649fd6eb8  add rsp, 0x30
0000707649fd6ebc  vmovaps xmm0, [rsp]
0000707649fd6ec1  vmovaps xmm1, [rsp+0x10]
0000707649fd6ec7  vmovaps xmm2, [rsp+0x20]
0000707649fd6ecd  vmovaps xmm4, [rsp+0x30]
0000707649fd6ed3  vmovaps xmm5, [rsp+0x40]
0000707649fd6ed9  vmovaps xmm6, [rsp+0x50]
0000707649fd6edf  vmovaps xmm7, [rsp+0x60]
0000707649fd6ee5  vmovaps xmm8, [rsp+0x70]
0000707649fd6eeb  vmovaps xmm9, [rsp+0x80]
0000707649fd6ef4  vmovaps xmm10, [rsp+0x90]
0000707649fd6efd  vmovaps xmm11, [rsp+0xA0]
0000707649fd6f06  vmovaps xmm12, [rsp+0xB0]
0000707649fd6f0f  vmovaps xmm13, [rsp+0xC0]
0000707649fd6f18  vmovaps xmm14, [rsp+0xD0]
0000707649fd6f21  vmovaps xmm15, [rsp+0xE0]
0000707649fd6f2a  add rsp, 0xF0
0000707649fd6f31  pop r11
0000707649fd6f33  pop r10
0000707649fd6f35  pop r9
0000707649fd6f37  pop r8
0000707649fd6f39  pop rsi
0000707649fd6f3a  pop rdi
0000707649fd6f3b  pop rdx
0000707649fd6f3c  pop rcx
0000707649fd6f3d  pop rax
0000707649fd6f3e  add rsp, 0x08
0000707649fd6f42  jmp 0x0000707649FD5A88
0000707649fd6f47  sub rsp, 0x08
0000707649fd6f4b  push rax
0000707649fd6f4c  push rcx
0000707649fd6f4d  push rdx
0000707649fd6f4e  push rdi
0000707649fd6f4f  push rsi
0000707649fd6f50  push r8
0000707649fd6f52  push r9
0000707649fd6f54  push r10
0000707649fd6f56  push r11
0000707649fd6f58  sub rsp, 0xF0
0000707649fd6f5f  vmovaps [rsp], xmm0
0000707649fd6f64  vmovaps [rsp+0x10], xmm1
0000707649fd6f6a  vmovaps [rsp+0x20], xmm2
0000707649fd6f70  vmovaps [rsp+0x30], xmm3
0000707649fd6f76  vmovaps [rsp+0x40], xmm4
0000707649fd6f7c  vmovaps [rsp+0x50], xmm6
0000707649fd6f82  vmovaps [rsp+0x60], xmm7
0000707649fd6f88  vmovaps [rsp+0x70], xmm8
0000707649fd6f8e  vmovaps [rsp+0x80], xmm9
0000707649fd6f97  vmovaps [rsp+0x90], xmm10
0000707649fd6fa0  vmovaps [rsp+0xA0], xmm11
0000707649fd6fa9  vmovaps [rsp+0xB0], xmm12
0000707649fd6fb2  vmovaps [rsp+0xC0], xmm13
0000707649fd6fbb  vmovaps [rsp+0xD0], xmm14
0000707649fd6fc4  vmovaps [rsp+0xE0], xmm15
0000707649fd6fcd  sub rsp, 0x30
0000707649fd6fd1  movaps [rsp], xmm5
0000707649fd6fd5  movaps [rsp+0x10], xmm8
0000707649fd6fdb  movaps [rsp+0x20], xmm15
0000707649fd6fe1  lea rdi, [rsp]
0000707649fd6fe5  mov esi, 0x00
0000707649fd6fea  mov rax, 0x59CB0B054530
0000707649fd6ff4  call rax
0000707649fd6ff6  movaps xmm5, [rsp]
0000707649fd6ffa  add rsp, 0x30
0000707649fd6ffe  vmovaps xmm0, [rsp]
0000707649fd7003  vmovaps xmm1, [rsp+0x10]
0000707649fd7009  vmovaps xmm2, [rsp+0x20]
0000707649fd700f  vmovaps xmm3, [rsp+0x30]
0000707649fd7015  vmovaps xmm4, [rsp+0x40]
0000707649fd701b  vmovaps xmm6, [rsp+0x50]
0000707649fd7021  vmovaps xmm7, [rsp+0x60]
0000707649fd7027  vmovaps xmm8, [rsp+0x70]
0000707649fd702d  vmovaps xmm9, [rsp+0x80]
0000707649fd7036  vmovaps xmm10, [rsp+0x90]
0000707649fd703f  vmovaps xmm11, [rsp+0xA0]
0000707649fd7048  vmovaps xmm12, [rsp+0xB0]
0000707649fd7051  vmovaps xmm13, [rsp+0xC0]
0000707649fd705a  vmovaps xmm14, [rsp+0xD0]
0000707649fd7063  vmovaps xmm15, [rsp+0xE0]
0000707649fd706c  add rsp, 0xF0
0000707649fd7073  pop r11
0000707649fd7075  pop r10
0000707649fd7077  pop r9
0000707649fd7079  pop r8
0000707649fd707b  pop rsi
0000707649fd707c  pop rdi
0000707649fd707d  pop rdx
0000707649fd707e  pop rcx
0000707649fd707f  pop rax
0000707649fd7080  add rsp, 0x08
0000707649fd7084  jmp 0x0000707649FD5AC0
0000707649fd7089  sub rsp, 0x08
0000707649fd708d  push rax
0000707649fd708e  push rcx
0000707649fd708f  push rdx
0000707649fd7090  push rdi
0000707649fd7091  push rsi
0000707649fd7092  push r8
0000707649fd7094  push r9
0000707649fd7096  push r10
0000707649fd7098  push r11
0000707649fd709a  sub rsp, 0xF0
0000707649fd70a1  vmovaps [rsp], xmm0
0000707649fd70a6  vmovaps [rsp+0x10], xmm1
0000707649fd70ac  vmovaps [rsp+0x20], xmm2
0000707649fd70b2  vmovaps [rsp+0x30], xmm3
0000707649fd70b8  vmovaps [rsp+0x40], xmm5
0000707649fd70be  vmovaps [rsp+0x50], xmm6
0000707649fd70c4  vmovaps [rsp+0x60], xmm7
0000707649fd70ca  vmovaps [rsp+0x70], xmm8
0000707649fd70d0  vmovaps [rsp+0x80], xmm9
0000707649fd70d9  vmovaps [rsp+0x90], xmm10
0000707649fd70e2  vmovaps [rsp+0xA0], xmm11
0000707649fd70eb  vmovaps [rsp+0xB0], xmm12
0000707649fd70f4  vmovaps [rsp+0xC0], xmm13
0000707649fd70fd  vmovaps [rsp+0xD0], xmm14
0000707649fd7106  vmovaps [rsp+0xE0], xmm15
0000707649fd710f  sub rsp, 0x30
0000707649fd7113  movaps [rsp], xmm4
0000707649fd7117  movaps [rsp+0x10], xmm9
0000707649fd711d  movaps [rsp+0x20], xmm8
0000707649fd7123  lea rdi, [rsp]
0000707649fd7127  mov esi, 0x00
0000707649fd712c  mov rax, 0x59CB0B054530
0000707649fd7136  call rax
0000707649fd7138  movaps xmm4, [rsp]
0000707649fd713c  add rsp, 0x30
0000707649fd7140  vmovaps xmm0, [rsp]
0000707649fd7145  vmovaps xmm1, [rsp+0x10]
0000707649fd714b  vmovaps xmm2, [rsp+0x20]
0000707649fd7151  vmovaps xmm3, [rsp+0x30]
0000707649fd7157  vmovaps xmm5, [rsp+0x40]
0000707649fd715d  vmovaps xmm6, [rsp+0x50]
0000707649fd7163  vmovaps xmm7, [rsp+0x60]
0000707649fd7169  vmovaps xmm8, [rsp+0x70]
0000707649fd716f  vmovaps xmm9, [rsp+0x80]
0000707649fd7178  vmovaps xmm10, [rsp+0x90]
0000707649fd7181  vmovaps xmm11, [rsp+0xA0]
0000707649fd718a  vmovaps xmm12, [rsp+0xB0]
0000707649fd7193  vmovaps xmm13, [rsp+0xC0]
0000707649fd719c  vmovaps xmm14, [rsp+0xD0]
0000707649fd71a5  vmovaps xmm15, [rsp+0xE0]
0000707649fd71ae  add rsp, 0xF0
0000707649fd71b5  pop r11
0000707649fd71b7  pop r10
0000707649fd71b9  pop r9
0000707649fd71bb  pop r8
0000707649fd71bd  pop rsi
0000707649fd71be  pop rdi
0000707649fd71bf  pop rdx
0000707649fd71c0  pop rcx
0000707649fd71c1  pop rax
0000707649fd71c2  add rsp, 0x08
0000707649fd71c6  jmp 0x0000707649FD5AE1
0000707649fd71cb  sub rsp, 0x08
0000707649fd71cf  push rax
0000707649fd71d0  push rcx
0000707649fd71d1  push rdx
0000707649fd71d2  push rdi
0000707649fd71d3  push rsi
0000707649fd71d4  push r8
0000707649fd71d6  push r9
0000707649fd71d8  push r10
0000707649fd71da  push r11
0000707649fd71dc  sub rsp, 0xF0
0000707649fd71e3  vmovaps [rsp], xmm0
0000707649fd71e8  vmovaps [rsp+0x10], xmm1
0000707649fd71ee  vmovaps [rsp+0x20], xmm2
0000707649fd71f4  vmovaps [rsp+0x30], xmm3
0000707649fd71fa  vmovaps [rsp+0x40], xmm4
0000707649fd7200  vmovaps [rsp+0x50], xmm5
0000707649fd7206  vmovaps [rsp+0x60], xmm6
0000707649fd720c  vmovaps [rsp+0x70], xmm7
0000707649fd7212  vmovaps [rsp+0x80], xmm8
0000707649fd721b  vmovaps [rsp+0x90], xmm10
0000707649fd7224  vmovaps [rsp+0xA0], xmm11
0000707649fd722d  vmovaps [rsp+0xB0], xmm12
0000707649fd7236  vmovaps [rsp+0xC0], xmm13
0000707649fd723f  vmovaps [rsp+0xD0], xmm14
0000707649fd7248  vmovaps [rsp+0xE0], xmm15
0000707649fd7251  sub rsp, 0x30
0000707649fd7255  movaps [rsp], xmm9
0000707649fd725a  movaps [rsp+0x10], xmm10
0000707649fd7260  movaps [rsp+0x20], xmm8
0000707649fd7266  lea rdi, [rsp]
0000707649fd726a  mov esi, 0x00
0000707649fd726f  mov rax, 0x59CB0B054530
0000707649fd7279  call rax
0000707649fd727b  movaps xmm9, [rsp]
0000707649fd7280  add rsp, 0x30
0000707649fd7284  vmovaps xmm0, [rsp]
0000707649fd7289  vmovaps xmm1, [rsp+0x10]
0000707649fd728f  vmovaps xmm2, [rsp+0x20]
0000707649fd7295  vmovaps xmm3, [rsp+0x30]
0000707649fd729b  vmovaps xmm4, [rsp+0x40]
0000707649fd72a1  vmovaps xmm5, [rsp+0x50]
0000707649fd72a7  vmovaps xmm6, [rsp+0x60]
0000707649fd72ad  vmovaps xmm7, [rsp+0x70]
0000707649fd72b3  vmovaps xmm8, [rsp+0x80]
0000707649fd72bc  vmovaps xmm10, [rsp+0x90]
0000707649fd72c5  vmovaps xmm11, [rsp+0xA0]
0000707649fd72ce  vmovaps xmm12, [rsp+0xB0]
0000707649fd72d7  vmovaps xmm13, [rsp+0xC0]
0000707649fd72e0  vmovaps xmm14, [rsp+0xD0]
0000707649fd72e9  vmovaps xmm15, [rsp+0xE0]
0000707649fd72f2  add rsp, 0xF0
0000707649fd72f9  pop r11
0000707649fd72fb  pop r10
0000707649fd72fd  pop r9
0000707649fd72ff  pop r8
0000707649fd7301  pop rsi
0000707649fd7302  pop rdi
0000707649fd7303  pop rdx
0000707649fd7304  pop rcx
0000707649fd7305  pop rax
0000707649fd7306  add rsp, 0x08
0000707649fd730a  jmp 0x0000707649FD5AFB
0000707649fd730f  call 0x0000707649ED64F0
0000707649fd7314  jmp 0x0000707649FD5C15
0000707649fd7319  call 0x0000707649ED64F0
0000707649fd731e  jmp 0x0000707649FD5C2B
0000707649fd7323  sub rsp, 0x08
0000707649fd7327  push rax
0000707649fd7328  push rcx
0000707649fd7329  push rdx
0000707649fd732a  push rdi
0000707649fd732b  push rsi
0000707649fd732c  push r8
0000707649fd732e  push r9
0000707649fd7330  push r10
0000707649fd7332  push r11
0000707649fd7334  sub rsp, 0xF0
0000707649fd733b  vmovaps [rsp], xmm0
0000707649fd7340  vmovaps [rsp+0x10], xmm2
0000707649fd7346  vmovaps [rsp+0x20], xmm3
0000707649fd734c  vmovaps [rsp+0x30], xmm4
0000707649fd7352  vmovaps [rsp+0x40], xmm5
0000707649fd7358  vmovaps [rsp+0x50], xmm6
0000707649fd735e  vmovaps [rsp+0x60], xmm7
0000707649fd7364  vmovaps [rsp+0x70], xmm8
0000707649fd736a  vmovaps [rsp+0x80], xmm9
0000707649fd7373  vmovaps [rsp+0x90], xmm10
0000707649fd737c  vmovaps [rsp+0xA0], xmm11
0000707649fd7385  vmovaps [rsp+0xB0], xmm12
0000707649fd738e  vmovaps [rsp+0xC0], xmm13
0000707649fd7397  vmovaps [rsp+0xD0], xmm14
0000707649fd73a0  vmovaps [rsp+0xE0], xmm15
0000707649fd73a9  sub rsp, 0x30
0000707649fd73ad  movaps [rsp], xmm1
0000707649fd73b1  movaps [rsp+0x10], xmm6
0000707649fd73b6  movaps [rsp+0x20], xmm15
0000707649fd73bc  lea rdi, [rsp]
0000707649fd73c0  mov esi, 0x00
0000707649fd73c5  mov rax, 0x59CB0B054530
0000707649fd73cf  call rax
0000707649fd73d1  movaps xmm1, [rsp]
0000707649fd73d5  add rsp, 0x30
0000707649fd73d9  vmovaps xmm0, [rsp]
0000707649fd73de  vmovaps xmm2, [rsp+0x10]
0000707649fd73e4  vmovaps xmm3, [rsp+0x20]
0000707649fd73ea  vmovaps xmm4, [rsp+0x30]
0000707649fd73f0  vmovaps xmm5, [rsp+0x40]
0000707649fd73f6  vmovaps xmm6, [rsp+0x50]
0000707649fd73fc  vmovaps xmm7, [rsp+0x60]
0000707649fd7402  vmovaps xmm8, [rsp+0x70]
0000707649fd7408  vmovaps xmm9, [rsp+0x80]
0000707649fd7411  vmovaps xmm10, [rsp+0x90]
0000707649fd741a  vmovaps xmm11, [rsp+0xA0]
0000707649fd7423  vmovaps xmm12, [rsp+0xB0]
0000707649fd742c  vmovaps xmm13, [rsp+0xC0]
0000707649fd7435  vmovaps xmm14, [rsp+0xD0]
0000707649fd743e  vmovaps xmm15, [rsp+0xE0]
0000707649fd7447  add rsp, 0xF0
0000707649fd744e  pop r11
0000707649fd7450  pop r10
0000707649fd7452  pop r9
0000707649fd7454  pop r8
0000707649fd7456  pop rsi
0000707649fd7457  pop rdi
0000707649fd7458  pop rdx
0000707649fd7459  pop rcx
0000707649fd745a  pop rax
0000707649fd745b  add rsp, 0x08
0000707649fd745f  jmp 0x0000707649FD5C68
0000707649fd7464  call 0x0000707649EE5820
0000707649fd7469  jmp 0x0000707649FD5C75
0000707649fd746e  sub rsp, 0x08
0000707649fd7472  push rax
0000707649fd7473  push rcx
0000707649fd7474  push rdx
0000707649fd7475  push rdi
0000707649fd7476  push rsi
0000707649fd7477  push r8
0000707649fd7479  push r9
0000707649fd747b  push r10
0000707649fd747d  push r11
0000707649fd747f  sub rsp, 0xF0
0000707649fd7486  vmovaps [rsp], xmm0
0000707649fd748b  vmovaps [rsp+0x10], xmm1
0000707649fd7491  vmovaps [rsp+0x20], xmm2
0000707649fd7497  vmovaps [rsp+0x30], xmm3
0000707649fd749d  vmovaps [rsp+0x40], xmm4
0000707649fd74a3  vmovaps [rsp+0x50], xmm5
0000707649fd74a9  vmovaps [rsp+0x60], xmm6
0000707649fd74af  vmovaps [rsp+0x70], xmm7
0000707649fd74b5  vmovaps [rsp+0x80], xmm8
0000707649fd74be  vmovaps [rsp+0x90], xmm9
0000707649fd74c7  vmovaps [rsp+0xA0], xmm10
0000707649fd74d0  vmovaps [rsp+0xB0], xmm11
0000707649fd74d9  vmovaps [rsp+0xC0], xmm12
0000707649fd74e2  vmovaps [rsp+0xD0], xmm13
0000707649fd74eb  vmovaps [rsp+0xE0], xmm15
0000707649fd74f4  sub rsp, 0x30
0000707649fd74f8  movaps [rsp], xmm14
0000707649fd74fd  movaps [rsp+0x10], xmm4
0000707649fd7502  movaps [rsp+0x20], xmm3
0000707649fd7507  lea rdi, [rsp]
0000707649fd750b  mov esi, 0x00
0000707649fd7510  mov rax, 0x59CB0B054530
0000707649fd751a  call rax
0000707649fd751c  movaps xmm14, [rsp]
0000707649fd7521  add rsp, 0x30
0000707649fd7525  vmovaps xmm0, [rsp]
0000707649fd752a  vmovaps xmm1, [rsp+0x10]
0000707649fd7530  vmovaps xmm2, [rsp+0x20]
0000707649fd7536  vmovaps xmm3, [rsp+0x30]
0000707649fd753c  vmovaps xmm4, [rsp+0x40]
0000707649fd7542  vmovaps xmm5, [rsp+0x50]
0000707649fd7548  vmovaps xmm6, [rsp+0x60]
0000707649fd754e  vmovaps xmm7, [rsp+0x70]
0000707649fd7554  vmovaps xmm8, [rsp+0x80]
0000707649fd755d  vmovaps xmm9, [rsp+0x90]
0000707649fd7566  vmovaps xmm10, [rsp+0xA0]
0000707649fd756f  vmovaps xmm11, [rsp+0xB0]
0000707649fd7578  vmovaps xmm12, [rsp+0xC0]
0000707649fd7581  vmovaps xmm13, [rsp+0xD0]
0000707649fd758a  vmovaps xmm15, [rsp+0xE0]
0000707649fd7593  add rsp, 0xF0
0000707649fd759a  pop r11
0000707649fd759c  pop r10
0000707649fd759e  pop r9
0000707649fd75a0  pop r8
0000707649fd75a2  pop rsi
0000707649fd75a3  pop rdi
0000707649fd75a4  pop rdx
0000707649fd75a5  pop rcx
0000707649fd75a6  pop rax
0000707649fd75a7  add rsp, 0x08
0000707649fd75ab  jmp 0x0000707649FD5C8F
0000707649fd75b0  sub rsp, 0x08
0000707649fd75b4  push rax
0000707649fd75b5  push rcx
0000707649fd75b6  push rdx
0000707649fd75b7  push rdi
0000707649fd75b8  push rsi
0000707649fd75b9  push r8
0000707649fd75bb  push r9
0000707649fd75bd  push r10
0000707649fd75bf  push r11
0000707649fd75c1  sub rsp, 0xF0
0000707649fd75c8  vmovaps [rsp], xmm0
0000707649fd75cd  vmovaps [rsp+0x10], xmm1
0000707649fd75d3  vmovaps [rsp+0x20], xmm2
0000707649fd75d9  vmovaps [rsp+0x30], xmm3
0000707649fd75df  vmovaps [rsp+0x40], xmm4
0000707649fd75e5  vmovaps [rsp+0x50], xmm5
0000707649fd75eb  vmovaps [rsp+0x60], xmm7
0000707649fd75f1  vmovaps [rsp+0x70], xmm8
0000707649fd75f7  vmovaps [rsp+0x80], xmm9
0000707649fd7600  vmovaps [rsp+0x90], xmm10
0000707649fd7609  vmovaps [rsp+0xA0], xmm11
0000707649fd7612  vmovaps [rsp+0xB0], xmm12
0000707649fd761b  vmovaps [rsp+0xC0], xmm13
0000707649fd7624  vmovaps [rsp+0xD0], xmm14
0000707649fd762d  vmovaps [rsp+0xE0], xmm15
0000707649fd7636  sub rsp, 0x30
0000707649fd763a  movaps [rsp], xmm6
0000707649fd763e  movaps [rsp+0x10], xmm9
0000707649fd7644  movaps [rsp+0x20], xmm7
0000707649fd7649  lea rdi, [rsp]
0000707649fd764d  mov esi, 0x00
0000707649fd7652  mov rax, 0x59CB0B054530
0000707649fd765c  call rax
0000707649fd765e  movaps xmm6, [rsp]
0000707649fd7662  add rsp, 0x30
0000707649fd7666  vmovaps xmm0, [rsp]
0000707649fd766b  vmovaps xmm1, [rsp+0x10]
0000707649fd7671  vmovaps xmm2, [rsp+0x20]
0000707649fd7677  vmovaps xmm3, [rsp+0x30]
0000707649fd767d  vmovaps xmm4, [rsp+0x40]
0000707649fd7683  vmovaps xmm5, [rsp+0x50]
0000707649fd7689  vmovaps xmm7, [rsp+0x60]
0000707649fd768f  vmovaps xmm8, [rsp+0x70]
0000707649fd7695  vmovaps xmm9, [rsp+0x80]
0000707649fd769e  vmovaps xmm10, [rsp+0x90]
0000707649fd76a7  vmovaps xmm11, [rsp+0xA0]
0000707649fd76b0  vmovaps xmm12, [rsp+0xB0]
0000707649fd76b9  vmovaps xmm13, [rsp+0xC0]
0000707649fd76c2  vmovaps xmm14, [rsp+0xD0]
0000707649fd76cb  vmovaps xmm15, [rsp+0xE0]
0000707649fd76d4  add rsp, 0xF0
0000707649fd76db  pop r11
0000707649fd76dd  pop r10
0000707649fd76df  pop r9
0000707649fd76e1  pop r8
0000707649fd76e3  pop rsi
0000707649fd76e4  pop rdi
0000707649fd76e5  pop rdx
0000707649fd76e6  pop rcx
0000707649fd76e7  pop rax
0000707649fd76e8  add rsp, 0x08
0000707649fd76ec  jmp 0x0000707649FD5CA7
0000707649fd76f1  sub rsp, 0x08
0000707649fd76f5  push rax
0000707649fd76f6  push rcx
0000707649fd76f7  push rdx
0000707649fd76f8  push rdi
0000707649fd76f9  push rsi
0000707649fd76fa  push r8
0000707649fd76fc  push r9
0000707649fd76fe  push r10
0000707649fd7700  push r11
0000707649fd7702  sub rsp, 0xF0
0000707649fd7709  vmovaps [rsp], xmm0
0000707649fd770e  vmovaps [rsp+0x10], xmm1
0000707649fd7714  vmovaps [rsp+0x20], xmm2
0000707649fd771a  vmovaps [rsp+0x30], xmm3
0000707649fd7720  vmovaps [rsp+0x40], xmm4
0000707649fd7726  vmovaps [rsp+0x50], xmm5
0000707649fd772c  vmovaps [rsp+0x60], xmm6
0000707649fd7732  vmovaps [rsp+0x70], xmm8
0000707649fd7738  vmovaps [rsp+0x80], xmm9
0000707649fd7741  vmovaps [rsp+0x90], xmm10
0000707649fd774a  vmovaps [rsp+0xA0], xmm11
0000707649fd7753  vmovaps [rsp+0xB0], xmm12
0000707649fd775c  vmovaps [rsp+0xC0], xmm13
0000707649fd7765  vmovaps [rsp+0xD0], xmm14
0000707649fd776e  vmovaps [rsp+0xE0], xmm15
0000707649fd7777  sub rsp, 0x30
0000707649fd777b  movaps [rsp], xmm7
0000707649fd777f  movaps [rsp+0x10], xmm4
0000707649fd7784  movaps [rsp+0x20], xmm9
0000707649fd778a  lea rdi, [rsp]
0000707649fd778e  mov esi, 0x00
0000707649fd7793  mov rax, 0x59CB0B054530
0000707649fd779d  call rax
0000707649fd779f  movaps xmm7, [rsp]
0000707649fd77a3  add rsp, 0x30
0000707649fd77a7  vmovaps xmm0, [rsp]
0000707649fd77ac  vmovaps xmm1, [rsp+0x10]
0000707649fd77b2  vmovaps xmm2, [rsp+0x20]
0000707649fd77b8  vmovaps xmm3, [rsp+0x30]
0000707649fd77be  vmovaps xmm4, [rsp+0x40]
0000707649fd77c4  vmovaps xmm5, [rsp+0x50]
0000707649fd77ca  vmovaps xmm6, [rsp+0x60]
0000707649fd77d0  vmovaps xmm8, [rsp+0x70]
0000707649fd77d6  vmovaps xmm9, [rsp+0x80]
0000707649fd77df  vmovaps xmm10, [rsp+0x90]
0000707649fd77e8  vmovaps xmm11, [rsp+0xA0]
0000707649fd77f1  vmovaps xmm12, [rsp+0xB0]
0000707649fd77fa  vmovaps xmm13, [rsp+0xC0]
0000707649fd7803  vmovaps xmm14, [rsp+0xD0]
0000707649fd780c  vmovaps xmm15, [rsp+0xE0]
0000707649fd7815  add rsp, 0xF0
0000707649fd781c  pop r11
0000707649fd781e  pop r10
0000707649fd7820  pop r9
0000707649fd7822  pop r8
0000707649fd7824  pop rsi
0000707649fd7825  pop rdi
0000707649fd7826  pop rdx
0000707649fd7827  pop rcx
0000707649fd7828  pop rax
0000707649fd7829  add rsp, 0x08
0000707649fd782d  jmp 0x0000707649FD5CD4
0000707649fd7832  sub rsp, 0x08
0000707649fd7836  push rax
0000707649fd7837  push rcx
0000707649fd7838  push rdx
0000707649fd7839  push rdi
0000707649fd783a  push rsi
0000707649fd783b  push r8
0000707649fd783d  push r9
0000707649fd783f  push r10
0000707649fd7841  push r11
0000707649fd7843  sub rsp, 0xF0
0000707649fd784a  vmovaps [rsp], xmm0
0000707649fd784f  vmovaps [rsp+0x10], xmm1
0000707649fd7855  vmovaps [rsp+0x20], xmm2
0000707649fd785b  vmovaps [rsp+0x30], xmm3
0000707649fd7861  vmovaps [rsp+0x40], xmm5
0000707649fd7867  vmovaps [rsp+0x50], xmm6
0000707649fd786d  vmovaps [rsp+0x60], xmm7
0000707649fd7873  vmovaps [rsp+0x70], xmm8
0000707649fd7879  vmovaps [rsp+0x80], xmm9
0000707649fd7882  vmovaps [rsp+0x90], xmm10
0000707649fd788b  vmovaps [rsp+0xA0], xmm11
0000707649fd7894  vmovaps [rsp+0xB0], xmm12
0000707649fd789d  vmovaps [rsp+0xC0], xmm13
0000707649fd78a6  vmovaps [rsp+0xD0], xmm14
0000707649fd78af  vmovaps [rsp+0xE0], xmm15
0000707649fd78b8  sub rsp, 0x30
0000707649fd78bc  movaps [rsp], xmm4
0000707649fd78c0  movaps [rsp+0x10], xmm15
0000707649fd78c6  movaps [rsp+0x20], xmm9
0000707649fd78cc  lea rdi, [rsp]
0000707649fd78d0  mov esi, 0x00
0000707649fd78d5  mov rax, 0x59CB0B054530
0000707649fd78df  call rax
0000707649fd78e1  movaps xmm4, [rsp]
0000707649fd78e5  add rsp, 0x30
0000707649fd78e9  vmovaps xmm0, [rsp]
0000707649fd78ee  vmovaps xmm1, [rsp+0x10]
0000707649fd78f4  vmovaps xmm2, [rsp+0x20]
0000707649fd78fa  vmovaps xmm3, [rsp+0x30]
0000707649fd7900  vmovaps xmm5, [rsp+0x40]
0000707649fd7906  vmovaps xmm6, [rsp+0x50]
0000707649fd790c  vmovaps xmm7, [rsp+0x60]
0000707649fd7912  vmovaps xmm8, [rsp+0x70]
0000707649fd7918  vmovaps xmm9, [rsp+0x80]
0000707649fd7921  vmovaps xmm10, [rsp+0x90]
0000707649fd792a  vmovaps xmm11, [rsp+0xA0]
0000707649fd7933  vmovaps xmm12, [rsp+0xB0]
0000707649fd793c  vmovaps xmm13, [rsp+0xC0]
0000707649fd7945  vmovaps xmm14, [rsp+0xD0]
0000707649fd794e  vmovaps xmm15, [rsp+0xE0]
0000707649fd7957  add rsp, 0xF0
0000707649fd795e  pop r11
0000707649fd7960  pop r10
0000707649fd7962  pop r9
0000707649fd7964  pop r8
0000707649fd7966  pop rsi
0000707649fd7967  pop rdi
0000707649fd7968  pop rdx
0000707649fd7969  pop rcx
0000707649fd796a  pop rax
0000707649fd796b  add rsp, 0x08
0000707649fd796f  jmp 0x0000707649FD5CF9
0000707649fd7974  call 0x0000707649EE5820
0000707649fd7979  jmp 0x0000707649FD5D06
0000707649fd797e  sub rsp, 0x08
0000707649fd7982  push rax
0000707649fd7983  push rcx
0000707649fd7984  push rdx
0000707649fd7985  push rdi
0000707649fd7986  push rsi
0000707649fd7987  push r8
0000707649fd7989  push r9
0000707649fd798b  push r10
0000707649fd798d  push r11
0000707649fd798f  sub rsp, 0xF0
0000707649fd7996  vmovaps [rsp], xmm0
0000707649fd799b  vmovaps [rsp+0x10], xmm1
0000707649fd79a1  vmovaps [rsp+0x20], xmm2
0000707649fd79a7  vmovaps [rsp+0x30], xmm4
0000707649fd79ad  vmovaps [rsp+0x40], xmm5
0000707649fd79b3  vmovaps [rsp+0x50], xmm6
0000707649fd79b9  vmovaps [rsp+0x60], xmm7
0000707649fd79bf  vmovaps [rsp+0x70], xmm8
0000707649fd79c5  vmovaps [rsp+0x80], xmm9
0000707649fd79ce  vmovaps [rsp+0x90], xmm10
0000707649fd79d7  vmovaps [rsp+0xA0], xmm11
0000707649fd79e0  vmovaps [rsp+0xB0], xmm12
0000707649fd79e9  vmovaps [rsp+0xC0], xmm13
0000707649fd79f2  vmovaps [rsp+0xD0], xmm14
0000707649fd79fb  vmovaps [rsp+0xE0], xmm15
0000707649fd7a04  sub rsp, 0x30
0000707649fd7a08  movaps [rsp], xmm3
0000707649fd7a0c  movaps [rsp+0x10], xmm1
0000707649fd7a11  movaps [rsp+0x20], xmm9
0000707649fd7a17  lea rdi, [rsp]
0000707649fd7a1b  mov esi, 0x00
0000707649fd7a20  mov rax, 0x59CB0B054530
0000707649fd7a2a  call rax
0000707649fd7a2c  movaps xmm3, [rsp]
0000707649fd7a30  add rsp, 0x30
0000707649fd7a34  vmovaps xmm0, [rsp]
0000707649fd7a39  vmovaps xmm1, [rsp+0x10]
0000707649fd7a3f  vmovaps xmm2, [rsp+0x20]
0000707649fd7a45  vmovaps xmm4, [rsp+0x30]
0000707649fd7a4b  vmovaps xmm5, [rsp+0x40]
0000707649fd7a51  vmovaps xmm6, [rsp+0x50]
0000707649fd7a57  vmovaps xmm7, [rsp+0x60]
0000707649fd7a5d  vmovaps xmm8, [rsp+0x70]
0000707649fd7a63  vmovaps xmm9, [rsp+0x80]
0000707649fd7a6c  vmovaps xmm10, [rsp+0x90]
0000707649fd7a75  vmovaps xmm11, [rsp+0xA0]
0000707649fd7a7e  vmovaps xmm12, [rsp+0xB0]
0000707649fd7a87  vmovaps xmm13, [rsp+0xC0]
0000707649fd7a90  vmovaps xmm14, [rsp+0xD0]
0000707649fd7a99  vmovaps xmm15, [rsp+0xE0]
0000707649fd7aa2  add rsp, 0xF0
0000707649fd7aa9  pop r11
0000707649fd7aab  pop r10
0000707649fd7aad  pop r9
0000707649fd7aaf  pop r8
0000707649fd7ab1  pop rsi
0000707649fd7ab2  pop rdi
0000707649fd7ab3  pop rdx
0000707649fd7ab4  pop rcx
0000707649fd7ab5  pop rax
0000707649fd7ab6  add rsp, 0x08
0000707649fd7aba  jmp 0x0000707649FD5D43
0000707649fd7abf  sub rsp, 0x08
0000707649fd7ac3  push rax
0000707649fd7ac4  push rcx
0000707649fd7ac5  push rdx
0000707649fd7ac6  push rdi
0000707649fd7ac7  push rsi
0000707649fd7ac8  push r8
0000707649fd7aca  push r9
0000707649fd7acc  push r10
0000707649fd7ace  push r11
0000707649fd7ad0  sub rsp, 0xF0
0000707649fd7ad7  vmovaps [rsp], xmm0
0000707649fd7adc  vmovaps [rsp+0x10], xmm2
0000707649fd7ae2  vmovaps [rsp+0x20], xmm3
0000707649fd7ae8  vmovaps [rsp+0x30], xmm4
0000707649fd7aee  vmovaps [rsp+0x40], xmm5
0000707649fd7af4  vmovaps [rsp+0x50], xmm6
0000707649fd7afa  vmovaps [rsp+0x60], xmm7
0000707649fd7b00  vmovaps [rsp+0x70], xmm8
0000707649fd7b06  vmovaps [rsp+0x80], xmm9
0000707649fd7b0f  vmovaps [rsp+0x90], xmm10
0000707649fd7b18  vmovaps [rsp+0xA0], xmm11
0000707649fd7b21  vmovaps [rsp+0xB0], xmm12
0000707649fd7b2a  vmovaps [rsp+0xC0], xmm13
0000707649fd7b33  vmovaps [rsp+0xD0], xmm14
0000707649fd7b3c  vmovaps [rsp+0xE0], xmm15
0000707649fd7b45  sub rsp, 0x30
0000707649fd7b49  movaps [rsp], xmm1
0000707649fd7b4d  movaps [rsp+0x10], xmm15
0000707649fd7b53  movaps [rsp+0x20], xmm9
0000707649fd7b59  lea rdi, [rsp]
0000707649fd7b5d  mov esi, 0x00
0000707649fd7b62  mov rax, 0x59CB0B054530
0000707649fd7b6c  call rax
0000707649fd7b6e  movaps xmm1, [rsp]
0000707649fd7b72  add rsp, 0x30
0000707649fd7b76  vmovaps xmm0, [rsp]
0000707649fd7b7b  vmovaps xmm2, [rsp+0x10]
0000707649fd7b81  vmovaps xmm3, [rsp+0x20]
0000707649fd7b87  vmovaps xmm4, [rsp+0x30]
0000707649fd7b8d  vmovaps xmm5, [rsp+0x40]
0000707649fd7b93  vmovaps xmm6, [rsp+0x50]
0000707649fd7b99  vmovaps xmm7, [rsp+0x60]
0000707649fd7b9f  vmovaps xmm8, [rsp+0x70]
0000707649fd7ba5  vmovaps xmm9, [rsp+0x80]
0000707649fd7bae  vmovaps xmm10, [rsp+0x90]
0000707649fd7bb7  vmovaps xmm11, [rsp+0xA0]
0000707649fd7bc0  vmovaps xmm12, [rsp+0xB0]
0000707649fd7bc9  vmovaps xmm13, [rsp+0xC0]
0000707649fd7bd2  vmovaps xmm14, [rsp+0xD0]
0000707649fd7bdb  vmovaps xmm15, [rsp+0xE0]
0000707649fd7be4  add rsp, 0xF0
0000707649fd7beb  pop r11
0000707649fd7bed  pop r10
0000707649fd7bef  pop r9
0000707649fd7bf1  pop r8
0000707649fd7bf3  pop rsi
0000707649fd7bf4  pop rdi
0000707649fd7bf5  pop rdx
0000707649fd7bf6  pop rcx
0000707649fd7bf7  pop rax
0000707649fd7bf8  add rsp, 0x08
0000707649fd7bfc  jmp 0x0000707649FD5DCB
0000707649fd7c01  call 0x0000707649EE5820
0000707649fd7c06  jmp 0x0000707649FD5DD8
0000707649fd7c0b  sub rsp, 0x08
0000707649fd7c0f  push rax
0000707649fd7c10  push rcx
0000707649fd7c11  push rdx
0000707649fd7c12  push rdi
0000707649fd7c13  push rsi
0000707649fd7c14  push r8
0000707649fd7c16  push r9
0000707649fd7c18  push r10
0000707649fd7c1a  push r11
0000707649fd7c1c  sub rsp, 0xF0
0000707649fd7c23  vmovaps [rsp], xmm0
0000707649fd7c28  vmovaps [rsp+0x10], xmm2
0000707649fd7c2e  vmovaps [rsp+0x20], xmm3
0000707649fd7c34  vmovaps [rsp+0x30], xmm4
0000707649fd7c3a  vmovaps [rsp+0x40], xmm5
0000707649fd7c40  vmovaps [rsp+0x50], xmm6
0000707649fd7c46  vmovaps [rsp+0x60], xmm7
0000707649fd7c4c  vmovaps [rsp+0x70], xmm8
0000707649fd7c52  vmovaps [rsp+0x80], xmm9
0000707649fd7c5b  vmovaps [rsp+0x90], xmm10
0000707649fd7c64  vmovaps [rsp+0xA0], xmm11
0000707649fd7c6d  vmovaps [rsp+0xB0], xmm12
0000707649fd7c76  vmovaps [rsp+0xC0], xmm13
0000707649fd7c7f  vmovaps [rsp+0xD0], xmm14
0000707649fd7c88  vmovaps [rsp+0xE0], xmm15
0000707649fd7c91  sub rsp, 0x30
0000707649fd7c95  movaps [rsp], xmm1
0000707649fd7c99  movaps [rsp+0x10], xmm5
0000707649fd7c9e  movaps [rsp+0x20], xmm7
0000707649fd7ca3  lea rdi, [rsp]
0000707649fd7ca7  mov esi, 0x00
0000707649fd7cac  mov rax, 0x59CB0B054530
0000707649fd7cb6  call rax
0000707649fd7cb8  movaps xmm1, [rsp]
0000707649fd7cbc  add rsp, 0x30
0000707649fd7cc0  vmovaps xmm0, [rsp]
0000707649fd7cc5  vmovaps xmm2, [rsp+0x10]
0000707649fd7ccb  vmovaps xmm3, [rsp+0x20]
0000707649fd7cd1  vmovaps xmm4, [rsp+0x30]
0000707649fd7cd7  vmovaps xmm5, [rsp+0x40]
0000707649fd7cdd  vmovaps xmm6, [rsp+0x50]
0000707649fd7ce3  vmovaps xmm7, [rsp+0x60]
0000707649fd7ce9  vmovaps xmm8, [rsp+0x70]
0000707649fd7cef  vmovaps xmm9, [rsp+0x80]
0000707649fd7cf8  vmovaps xmm10, [rsp+0x90]
0000707649fd7d01  vmovaps xmm11, [rsp+0xA0]
0000707649fd7d0a  vmovaps xmm12, [rsp+0xB0]
0000707649fd7d13  vmovaps xmm13, [rsp+0xC0]
0000707649fd7d1c  vmovaps xmm14, [rsp+0xD0]
0000707649fd7d25  vmovaps xmm15, [rsp+0xE0]
0000707649fd7d2e  add rsp, 0xF0
0000707649fd7d35  pop r11
0000707649fd7d37  pop r10
0000707649fd7d39  pop r9
0000707649fd7d3b  pop r8
0000707649fd7d3d  pop rsi
0000707649fd7d3e  pop rdi
0000707649fd7d3f  pop rdx
0000707649fd7d40  pop rcx
0000707649fd7d41  pop rax
0000707649fd7d42  add rsp, 0x08
0000707649fd7d46  jmp 0x0000707649FD5E7D
0000707649fd7d4b  sub rsp, 0x08
0000707649fd7d4f  push rax
0000707649fd7d50  push rcx
0000707649fd7d51  push rdx
0000707649fd7d52  push rdi
0000707649fd7d53  push rsi
0000707649fd7d54  push r8
0000707649fd7d56  push r9
0000707649fd7d58  push r10
0000707649fd7d5a  push r11
0000707649fd7d5c  sub rsp, 0xF0
0000707649fd7d63  vmovaps [rsp], xmm0
0000707649fd7d68  vmovaps [rsp+0x10], xmm1
0000707649fd7d6e  vmovaps [rsp+0x20], xmm2
0000707649fd7d74  vmovaps [rsp+0x30], xmm3
0000707649fd7d7a  vmovaps [rsp+0x40], xmm4
0000707649fd7d80  vmovaps [rsp+0x50], xmm5
0000707649fd7d86  vmovaps [rsp+0x60], xmm6
0000707649fd7d8c  vmovaps [rsp+0x70], xmm8
0000707649fd7d92  vmovaps [rsp+0x80], xmm9
0000707649fd7d9b  vmovaps [rsp+0x90], xmm10
0000707649fd7da4  vmovaps [rsp+0xA0], xmm11
0000707649fd7dad  vmovaps [rsp+0xB0], xmm12
0000707649fd7db6  vmovaps [rsp+0xC0], xmm13
0000707649fd7dbf  vmovaps [rsp+0xD0], xmm14
0000707649fd7dc8  vmovaps [rsp+0xE0], xmm15
0000707649fd7dd1  sub rsp, 0x30
0000707649fd7dd5  movaps [rsp], xmm7
0000707649fd7dd9  movaps [rsp+0x10], xmm5
0000707649fd7dde  movaps [rsp+0x20], xmm15
0000707649fd7de4  lea rdi, [rsp]
0000707649fd7de8  mov esi, 0x00
0000707649fd7ded  mov rax, 0x59CB0B054530
0000707649fd7df7  call rax
0000707649fd7df9  movaps xmm7, [rsp]
0000707649fd7dfd  add rsp, 0x30
0000707649fd7e01  vmovaps xmm0, [rsp]
0000707649fd7e06  vmovaps xmm1, [rsp+0x10]
0000707649fd7e0c  vmovaps xmm2, [rsp+0x20]
0000707649fd7e12  vmovaps xmm3, [rsp+0x30]
0000707649fd7e18  vmovaps xmm4, [rsp+0x40]
0000707649fd7e1e  vmovaps xmm5, [rsp+0x50]
0000707649fd7e24  vmovaps xmm6, [rsp+0x60]
0000707649fd7e2a  vmovaps xmm8, [rsp+0x70]
0000707649fd7e30  vmovaps xmm9, [rsp+0x80]
0000707649fd7e39  vmovaps xmm10, [rsp+0x90]
0000707649fd7e42  vmovaps xmm11, [rsp+0xA0]
0000707649fd7e4b  vmovaps xmm12, [rsp+0xB0]
0000707649fd7e54  vmovaps xmm13, [rsp+0xC0]
0000707649fd7e5d  vmovaps xmm14, [rsp+0xD0]
0000707649fd7e66  vmovaps xmm15, [rsp+0xE0]
0000707649fd7e6f  add rsp, 0xF0
0000707649fd7e76  pop r11
0000707649fd7e78  pop r10
0000707649fd7e7a  pop r9
0000707649fd7e7c  pop r8
0000707649fd7e7e  pop rsi
0000707649fd7e7f  pop rdi
0000707649fd7e80  pop rdx
0000707649fd7e81  pop rcx
0000707649fd7e82  pop rax
0000707649fd7e83  add rsp, 0x08
0000707649fd7e87  jmp 0x0000707649FD5EB3
0000707649fd7e8c  call 0x0000707649ED64F0
0000707649fd7e91  jmp 0x0000707649FD5EC0
0000707649fd7e96  sub rsp, 0x08
0000707649fd7e9a  push rax
0000707649fd7e9b  push rcx
0000707649fd7e9c  push rdx
0000707649fd7e9d  push rdi
0000707649fd7e9e  push rsi
0000707649fd7e9f  push r8
0000707649fd7ea1  push r9
0000707649fd7ea3  push r10
0000707649fd7ea5  push r11
0000707649fd7ea7  sub rsp, 0xF0
0000707649fd7eae  vmovaps [rsp], xmm0
0000707649fd7eb3  vmovaps [rsp+0x10], xmm1
0000707649fd7eb9  vmovaps [rsp+0x20], xmm2
0000707649fd7ebf  vmovaps [rsp+0x30], xmm3
0000707649fd7ec5  vmovaps [rsp+0x40], xmm4
0000707649fd7ecb  vmovaps [rsp+0x50], xmm5
0000707649fd7ed1  vmovaps [rsp+0x60], xmm6
0000707649fd7ed7  vmovaps [rsp+0x70], xmm7
0000707649fd7edd  vmovaps [rsp+0x80], xmm8
0000707649fd7ee6  vmovaps [rsp+0x90], xmm9
0000707649fd7eef  vmovaps [rsp+0xA0], xmm10
0000707649fd7ef8  vmovaps [rsp+0xB0], xmm11
0000707649fd7f01  vmovaps [rsp+0xC0], xmm12
0000707649fd7f0a  vmovaps [rsp+0xD0], xmm13
0000707649fd7f13  vmovaps [rsp+0xE0], xmm14
0000707649fd7f1c  sub rsp, 0x30
0000707649fd7f20  movaps [rsp], xmm15
0000707649fd7f25  movaps [rsp+0x10], xmm5
0000707649fd7f2a  movaps [rsp+0x20], xmm3
0000707649fd7f2f  lea rdi, [rsp]
0000707649fd7f33  mov esi, 0x00
0000707649fd7f38  mov rax, 0x59CB0B054530
0000707649fd7f42  call rax
0000707649fd7f44  movaps xmm15, [rsp]
0000707649fd7f49  add rsp, 0x30
0000707649fd7f4d  vmovaps xmm0, [rsp]
0000707649fd7f52  vmovaps xmm1, [rsp+0x10]
0000707649fd7f58  vmovaps xmm2, [rsp+0x20]
0000707649fd7f5e  vmovaps xmm3, [rsp+0x30]
0000707649fd7f64  vmovaps xmm4, [rsp+0x40]
0000707649fd7f6a  vmovaps xmm5, [rsp+0x50]
0000707649fd7f70  vmovaps xmm6, [rsp+0x60]
0000707649fd7f76  vmovaps xmm7, [rsp+0x70]
0000707649fd7f7c  vmovaps xmm8, [rsp+0x80]
0000707649fd7f85  vmovaps xmm9, [rsp+0x90]
0000707649fd7f8e  vmovaps xmm10, [rsp+0xA0]
0000707649fd7f97  vmovaps xmm11, [rsp+0xB0]
0000707649fd7fa0  vmovaps xmm12, [rsp+0xC0]
0000707649fd7fa9  vmovaps xmm13, [rsp+0xD0]
0000707649fd7fb2  vmovaps xmm14, [rsp+0xE0]
0000707649fd7fbb  add rsp, 0xF0
0000707649fd7fc2  pop r11
0000707649fd7fc4  pop r10
0000707649fd7fc6  pop r9
0000707649fd7fc8  pop r8
0000707649fd7fca  pop rsi
0000707649fd7fcb  pop rdi
0000707649fd7fcc  pop rdx
0000707649fd7fcd  pop rcx
0000707649fd7fce  pop rax
0000707649fd7fcf  add rsp, 0x08
0000707649fd7fd3  jmp 0x0000707649FD5EE6
0000707649fd7fd8  sub rsp, 0x08
0000707649fd7fdc  push rax
0000707649fd7fdd  push rcx
0000707649fd7fde  push rdx
0000707649fd7fdf  push rdi
0000707649fd7fe0  push rsi
0000707649fd7fe1  push r8
0000707649fd7fe3  push r9
0000707649fd7fe5  push r10
0000707649fd7fe7  push r11
0000707649fd7fe9  sub rsp, 0xF0
0000707649fd7ff0  vmovaps [rsp], xmm0
0000707649fd7ff5  vmovaps [rsp+0x10], xmm2
0000707649fd7ffb  vmovaps [rsp+0x20], xmm3
0000707649fd8001  vmovaps [rsp+0x30], xmm4
0000707649fd8007  vmovaps [rsp+0x40], xmm5
0000707649fd800d  vmovaps [rsp+0x50], xmm6
0000707649fd8013  vmovaps [rsp+0x60], xmm7
0000707649fd8019  vmovaps [rsp+0x70], xmm8
0000707649fd801f  vmovaps [rsp+0x80], xmm9
0000707649fd8028  vmovaps [rsp+0x90], xmm10
0000707649fd8031  vmovaps [rsp+0xA0], xmm11
0000707649fd803a  vmovaps [rsp+0xB0], xmm12
0000707649fd8043  vmovaps [rsp+0xC0], xmm13
0000707649fd804c  vmovaps [rsp+0xD0], xmm14
0000707649fd8055  vmovaps [rsp+0xE0], xmm15
0000707649fd805e  sub rsp, 0x30
0000707649fd8062  movaps [rsp], xmm1
0000707649fd8066  movaps [rsp+0x10], xmm5
0000707649fd806b  movaps [rsp+0x20], xmm4
0000707649fd8070  lea rdi, [rsp]
0000707649fd8074  mov esi, 0x00
0000707649fd8079  mov rax, 0x59CB0B054530
0000707649fd8083  call rax
0000707649fd8085  movaps xmm1, [rsp]
0000707649fd8089  add rsp, 0x30
0000707649fd808d  vmovaps xmm0, [rsp]
0000707649fd8092  vmovaps xmm2, [rsp+0x10]
0000707649fd8098  vmovaps xmm3, [rsp+0x20]
0000707649fd809e  vmovaps xmm4, [rsp+0x30]
0000707649fd80a4  vmovaps xmm5, [rsp+0x40]
0000707649fd80aa  vmovaps xmm6, [rsp+0x50]
0000707649fd80b0  vmovaps xmm7, [rsp+0x60]
0000707649fd80b6  vmovaps xmm8, [rsp+0x70]
0000707649fd80bc  vmovaps xmm9, [rsp+0x80]
0000707649fd80c5  vmovaps xmm10, [rsp+0x90]
0000707649fd80ce  vmovaps xmm11, [rsp+0xA0]
0000707649fd80d7  vmovaps xmm12, [rsp+0xB0]
0000707649fd80e0  vmovaps xmm13, [rsp+0xC0]
0000707649fd80e9  vmovaps xmm14, [rsp+0xD0]
0000707649fd80f2  vmovaps xmm15, [rsp+0xE0]
0000707649fd80fb  add rsp, 0xF0
0000707649fd8102  pop r11
0000707649fd8104  pop r10
0000707649fd8106  pop r9
0000707649fd8108  pop r8
0000707649fd810a  pop rsi
0000707649fd810b  pop rdi
0000707649fd810c  pop rdx
0000707649fd810d  pop rcx
0000707649fd810e  pop rax
0000707649fd810f  add rsp, 0x08
0000707649fd8113  jmp 0x0000707649FD5F06
0000707649fd8118  sub rsp, 0x08
0000707649fd811c  push rax
0000707649fd811d  push rcx
0000707649fd811e  push rdx
0000707649fd811f  push rdi
0000707649fd8120  push rsi
0000707649fd8121  push r8
0000707649fd8123  push r9
0000707649fd8125  push r10
0000707649fd8127  push r11
0000707649fd8129  sub rsp, 0xF0
0000707649fd8130  vmovaps [rsp], xmm0
0000707649fd8135  vmovaps [rsp+0x10], xmm1
0000707649fd813b  vmovaps [rsp+0x20], xmm2
0000707649fd8141  vmovaps [rsp+0x30], xmm3
0000707649fd8147  vmovaps [rsp+0x40], xmm5
0000707649fd814d  vmovaps [rsp+0x50], xmm6
0000707649fd8153  vmovaps [rsp+0x60], xmm7
0000707649fd8159  vmovaps [rsp+0x70], xmm8
0000707649fd815f  vmovaps [rsp+0x80], xmm9
0000707649fd8168  vmovaps [rsp+0x90], xmm10
0000707649fd8171  vmovaps [rsp+0xA0], xmm11
0000707649fd817a  vmovaps [rsp+0xB0], xmm12
0000707649fd8183  vmovaps [rsp+0xC0], xmm13
0000707649fd818c  vmovaps [rsp+0xD0], xmm14
0000707649fd8195  vmovaps [rsp+0xE0], xmm15
0000707649fd819e  sub rsp, 0x30
0000707649fd81a2  movaps [rsp], xmm4
0000707649fd81a6  movaps [rsp+0x10], xmm3
0000707649fd81ab  movaps [rsp+0x20], xmm5
0000707649fd81b0  lea rdi, [rsp]
0000707649fd81b4  mov esi, 0x00
0000707649fd81b9  mov rax, 0x59CB0B054530
0000707649fd81c3  call rax
0000707649fd81c5  movaps xmm4, [rsp]
0000707649fd81c9  add rsp, 0x30
0000707649fd81cd  vmovaps xmm0, [rsp]
0000707649fd81d2  vmovaps xmm1, [rsp+0x10]
0000707649fd81d8  vmovaps xmm2, [rsp+0x20]
0000707649fd81de  vmovaps xmm3, [rsp+0x30]
0000707649fd81e4  vmovaps xmm5, [rsp+0x40]
0000707649fd81ea  vmovaps xmm6, [rsp+0x50]
0000707649fd81f0  vmovaps xmm7, [rsp+0x60]
0000707649fd81f6  vmovaps xmm8, [rsp+0x70]
0000707649fd81fc  vmovaps xmm9, [rsp+0x80]
0000707649fd8205  vmovaps xmm10, [rsp+0x90]
0000707649fd820e  vmovaps xmm11, [rsp+0xA0]
0000707649fd8217  vmovaps xmm12, [rsp+0xB0]
0000707649fd8220  vmovaps xmm13, [rsp+0xC0]
0000707649fd8229  vmovaps xmm14, [rsp+0xD0]
0000707649fd8232  vmovaps xmm15, [rsp+0xE0]
0000707649fd823b  add rsp, 0xF0
0000707649fd8242  pop r11
0000707649fd8244  pop r10
0000707649fd8246  pop r9
0000707649fd8248  pop r8
0000707649fd824a  pop rsi
0000707649fd824b  pop rdi
0000707649fd824c  pop rdx
0000707649fd824d  pop rcx
0000707649fd824e  pop rax
0000707649fd824f  add rsp, 0x08
0000707649fd8253  jmp 0x0000707649FD5F54
0000707649fd8258  call 0x0000707649ED64F0
0000707649fd825d  jmp 0x0000707649FD5F61
0000707649fd8262  sub rsp, 0x08
0000707649fd8266  push rax
0000707649fd8267  push rcx
0000707649fd8268  push rdx
0000707649fd8269  push rdi
0000707649fd826a  push rsi
0000707649fd826b  push r8
0000707649fd826d  push r9
0000707649fd826f  push r10
0000707649fd8271  push r11
0000707649fd8273  sub rsp, 0xF0
0000707649fd827a  vmovaps [rsp], xmm0
0000707649fd827f  vmovaps [rsp+0x10], xmm1
0000707649fd8285  vmovaps [rsp+0x20], xmm2
0000707649fd828b  vmovaps [rsp+0x30], xmm3
0000707649fd8291  vmovaps [rsp+0x40], xmm4
0000707649fd8297  vmovaps [rsp+0x50], xmm6
0000707649fd829d  vmovaps [rsp+0x60], xmm7
0000707649fd82a3  vmovaps [rsp+0x70], xmm8
0000707649fd82a9  vmovaps [rsp+0x80], xmm9
0000707649fd82b2  vmovaps [rsp+0x90], xmm10
0000707649fd82bb  vmovaps [rsp+0xA0], xmm11
0000707649fd82c4  vmovaps [rsp+0xB0], xmm12
0000707649fd82cd  vmovaps [rsp+0xC0], xmm13
0000707649fd82d6  vmovaps [rsp+0xD0], xmm14
0000707649fd82df  vmovaps [rsp+0xE0], xmm15
0000707649fd82e8  sub rsp, 0x30
0000707649fd82ec  movaps [rsp], xmm5
0000707649fd82f0  movaps [rsp+0x10], xmm6
0000707649fd82f5  movaps [rsp+0x20], xmm3
0000707649fd82fa  lea rdi, [rsp]
0000707649fd82fe  mov esi, 0x00
0000707649fd8303  mov rax, 0x59CB0B054530
0000707649fd830d  call rax
0000707649fd830f  movaps xmm5, [rsp]
0000707649fd8313  add rsp, 0x30
0000707649fd8317  vmovaps xmm0, [rsp]
0000707649fd831c  vmovaps xmm1, [rsp+0x10]
0000707649fd8322  vmovaps xmm2, [rsp+0x20]
0000707649fd8328  vmovaps xmm3, [rsp+0x30]
0000707649fd832e  vmovaps xmm4, [rsp+0x40]
0000707649fd8334  vmovaps xmm6, [rsp+0x50]
0000707649fd833a  vmovaps xmm7, [rsp+0x60]
0000707649fd8340  vmovaps xmm8, [rsp+0x70]
0000707649fd8346  vmovaps xmm9, [rsp+0x80]
0000707649fd834f  vmovaps xmm10, [rsp+0x90]
0000707649fd8358  vmovaps xmm11, [rsp+0xA0]
0000707649fd8361  vmovaps xmm12, [rsp+0xB0]
0000707649fd836a  vmovaps xmm13, [rsp+0xC0]
0000707649fd8373  vmovaps xmm14, [rsp+0xD0]
0000707649fd837c  vmovaps xmm15, [rsp+0xE0]
0000707649fd8385  add rsp, 0xF0
0000707649fd838c  pop r11
0000707649fd838e  pop r10
0000707649fd8390  pop r9
0000707649fd8392  pop r8
0000707649fd8394  pop rsi
0000707649fd8395  pop rdi
0000707649fd8396  pop rdx
0000707649fd8397  pop rcx
0000707649fd8398  pop rax
0000707649fd8399  add rsp, 0x08
0000707649fd839d  jmp 0x0000707649FD5F87
0000707649fd83a2  sub rsp, 0x08
0000707649fd83a6  push rax
0000707649fd83a7  push rcx
0000707649fd83a8  push rdx
0000707649fd83a9  push rdi
0000707649fd83aa  push rsi
0000707649fd83ab  push r8
0000707649fd83ad  push r9
0000707649fd83af  push r10
0000707649fd83b1  push r11
0000707649fd83b3  sub rsp, 0xF0
0000707649fd83ba  vmovaps [rsp], xmm0
0000707649fd83bf  vmovaps [rsp+0x10], xmm1
0000707649fd83c5  vmovaps [rsp+0x20], xmm2
0000707649fd83cb  vmovaps [rsp+0x30], xmm3
0000707649fd83d1  vmovaps [rsp+0x40], xmm4
0000707649fd83d7  vmovaps [rsp+0x50], xmm5
0000707649fd83dd  vmovaps [rsp+0x60], xmm7
0000707649fd83e3  vmovaps [rsp+0x70], xmm8
0000707649fd83e9  vmovaps [rsp+0x80], xmm9
0000707649fd83f2  vmovaps [rsp+0x90], xmm10
0000707649fd83fb  vmovaps [rsp+0xA0], xmm11
0000707649fd8404  vmovaps [rsp+0xB0], xmm12
0000707649fd840d  vmovaps [rsp+0xC0], xmm13
0000707649fd8416  vmovaps [rsp+0xD0], xmm14
0000707649fd841f  vmovaps [rsp+0xE0], xmm15
0000707649fd8428  sub rsp, 0x30
0000707649fd842c  movaps [rsp], xmm6
0000707649fd8430  movaps [rsp+0x10], xmm9
0000707649fd8436  movaps [rsp+0x20], xmm1
0000707649fd843b  lea rdi, [rsp]
0000707649fd843f  mov esi, 0x00
0000707649fd8444  mov rax, 0x59CB0B054530
0000707649fd844e  call rax
0000707649fd8450  movaps xmm6, [rsp]
0000707649fd8454  add rsp, 0x30
0000707649fd8458  vmovaps xmm0, [rsp]
0000707649fd845d  vmovaps xmm1, [rsp+0x10]
0000707649fd8463  vmovaps xmm2, [rsp+0x20]
0000707649fd8469  vmovaps xmm3, [rsp+0x30]
0000707649fd846f  vmovaps xmm4, [rsp+0x40]
0000707649fd8475  vmovaps xmm5, [rsp+0x50]
0000707649fd847b  vmovaps xmm7, [rsp+0x60]
0000707649fd8481  vmovaps xmm8, [rsp+0x70]
0000707649fd8487  vmovaps xmm9, [rsp+0x80]
0000707649fd8490  vmovaps xmm10, [rsp+0x90]
0000707649fd8499  vmovaps xmm11, [rsp+0xA0]
0000707649fd84a2  vmovaps xmm12, [rsp+0xB0]
0000707649fd84ab  vmovaps xmm13, [rsp+0xC0]
0000707649fd84b4  vmovaps xmm14, [rsp+0xD0]
0000707649fd84bd  vmovaps xmm15, [rsp+0xE0]
0000707649fd84c6  add rsp, 0xF0
0000707649fd84cd  pop r11
0000707649fd84cf  pop r10
0000707649fd84d1  pop r9
0000707649fd84d3  pop r8
0000707649fd84d5  pop rsi
0000707649fd84d6  pop rdi
0000707649fd84d7  pop rdx
0000707649fd84d8  pop rcx
0000707649fd84d9  pop rax
0000707649fd84da  add rsp, 0x08
0000707649fd84de  jmp 0x0000707649FD5FAB
0000707649fd84e3  sub rsp, 0x08
0000707649fd84e7  push rax
0000707649fd84e8  push rcx
0000707649fd84e9  push rdx
0000707649fd84ea  push rdi
0000707649fd84eb  push rsi
0000707649fd84ec  push r8
0000707649fd84ee  push r9
0000707649fd84f0  push r10
0000707649fd84f2  push r11
0000707649fd84f4  sub rsp, 0xF0
0000707649fd84fb  vmovaps [rsp], xmm0
0000707649fd8500  vmovaps [rsp+0x10], xmm1
0000707649fd8506  vmovaps [rsp+0x20], xmm2
0000707649fd850c  vmovaps [rsp+0x30], xmm3
0000707649fd8512  vmovaps [rsp+0x40], xmm4
0000707649fd8518  vmovaps [rsp+0x50], xmm5
0000707649fd851e  vmovaps [rsp+0x60], xmm6
0000707649fd8524  vmovaps [rsp+0x70], xmm7
0000707649fd852a  vmovaps [rsp+0x80], xmm8
0000707649fd8533  vmovaps [rsp+0x90], xmm10
0000707649fd853c  vmovaps [rsp+0xA0], xmm11
0000707649fd8545  vmovaps [rsp+0xB0], xmm12
0000707649fd854e  vmovaps [rsp+0xC0], xmm13
0000707649fd8557  vmovaps [rsp+0xD0], xmm14
0000707649fd8560  vmovaps [rsp+0xE0], xmm15
0000707649fd8569  sub rsp, 0x30
0000707649fd856d  movaps [rsp], xmm9
0000707649fd8572  movaps [rsp+0x10], xmm3
0000707649fd8577  movaps [rsp+0x20], xmm1
0000707649fd857c  lea rdi, [rsp]
0000707649fd8580  mov esi, 0x00
0000707649fd8585  mov rax, 0x59CB0B054530
0000707649fd858f  call rax
0000707649fd8591  movaps xmm9, [rsp]
0000707649fd8596  add rsp, 0x30
0000707649fd859a  vmovaps xmm0, [rsp]
0000707649fd859f  vmovaps xmm1, [rsp+0x10]
0000707649fd85a5  vmovaps xmm2, [rsp+0x20]
0000707649fd85ab  vmovaps xmm3, [rsp+0x30]
0000707649fd85b1  vmovaps xmm4, [rsp+0x40]
0000707649fd85b7  vmovaps xmm5, [rsp+0x50]
0000707649fd85bd  vmovaps xmm6, [rsp+0x60]
0000707649fd85c3  vmovaps xmm7, [rsp+0x70]
0000707649fd85c9  vmovaps xmm8, [rsp+0x80]
0000707649fd85d2  vmovaps xmm10, [rsp+0x90]
0000707649fd85db  vmovaps xmm11, [rsp+0xA0]
0000707649fd85e4  vmovaps xmm12, [rsp+0xB0]
0000707649fd85ed  vmovaps xmm13, [rsp+0xC0]
0000707649fd85f6  vmovaps xmm14, [rsp+0xD0]
0000707649fd85ff  vmovaps xmm15, [rsp+0xE0]
0000707649fd8608  add rsp, 0xF0
0000707649fd860f  pop r11
0000707649fd8611  pop r10
0000707649fd8613  pop r9
0000707649fd8615  pop r8
0000707649fd8617  pop rsi
0000707649fd8618  pop rdi
0000707649fd8619  pop rdx
0000707649fd861a  pop rcx
0000707649fd861b  pop rax
0000707649fd861c  add rsp, 0x08
0000707649fd8620  jmp 0x0000707649FD5FF7
0000707649fd8625  call 0x0000707649ED64F0
0000707649fd862a  jmp 0x0000707649FD6004
0000707649fd862f  sub rsp, 0x08
0000707649fd8633  push rax
0000707649fd8634  push rcx
0000707649fd8635  push rdx
0000707649fd8636  push rdi
0000707649fd8637  push rsi
0000707649fd8638  push r8
0000707649fd863a  push r9
0000707649fd863c  push r10
0000707649fd863e  push r11
0000707649fd8640  sub rsp, 0xF0
0000707649fd8647  vmovaps [rsp], xmm0
0000707649fd864c  vmovaps [rsp+0x10], xmm1
0000707649fd8652  vmovaps [rsp+0x20], xmm2
0000707649fd8658  vmovaps [rsp+0x30], xmm3
0000707649fd865e  vmovaps [rsp+0x40], xmm4
0000707649fd8664  vmovaps [rsp+0x50], xmm5
0000707649fd866a  vmovaps [rsp+0x60], xmm6
0000707649fd8670  vmovaps [rsp+0x70], xmm7
0000707649fd8676  vmovaps [rsp+0x80], xmm8
0000707649fd867f  vmovaps [rsp+0x90], xmm9
0000707649fd8688  vmovaps [rsp+0xA0], xmm10
0000707649fd8691  vmovaps [rsp+0xB0], xmm11
0000707649fd869a  vmovaps [rsp+0xC0], xmm12
0000707649fd86a3  vmovaps [rsp+0xD0], xmm13
0000707649fd86ac  vmovaps [rsp+0xE0], xmm14
0000707649fd86b5  sub rsp, 0x30
0000707649fd86b9  movaps [rsp], xmm15
0000707649fd86be  movaps [rsp+0x10], xmm3
0000707649fd86c3  movaps [rsp+0x20], xmm7
0000707649fd86c8  lea rdi, [rsp]
0000707649fd86cc  mov esi, 0x00
0000707649fd86d1  mov rax, 0x59CB0B054530
0000707649fd86db  call rax
0000707649fd86dd  movaps xmm15, [rsp]
0000707649fd86e2  add rsp, 0x30
0000707649fd86e6  vmovaps xmm0, [rsp]
0000707649fd86eb  vmovaps xmm1, [rsp+0x10]
0000707649fd86f1  vmovaps xmm2, [rsp+0x20]
0000707649fd86f7  vmovaps xmm3, [rsp+0x30]
0000707649fd86fd  vmovaps xmm4, [rsp+0x40]
0000707649fd8703  vmovaps xmm5, [rsp+0x50]
0000707649fd8709  vmovaps xmm6, [rsp+0x60]
0000707649fd870f  vmovaps xmm7, [rsp+0x70]
0000707649fd8715  vmovaps xmm8, [rsp+0x80]
0000707649fd871e  vmovaps xmm9, [rsp+0x90]
0000707649fd8727  vmovaps xmm10, [rsp+0xA0]
0000707649fd8730  vmovaps xmm11, [rsp+0xB0]
0000707649fd8739  vmovaps xmm12, [rsp+0xC0]
0000707649fd8742  vmovaps xmm13, [rsp+0xD0]
0000707649fd874b  vmovaps xmm14, [rsp+0xE0]
0000707649fd8754  add rsp, 0xF0
0000707649fd875b  pop r11
0000707649fd875d  pop r10
0000707649fd875f  pop r9
0000707649fd8761  pop r8
0000707649fd8763  pop rsi
0000707649fd8764  pop rdi
0000707649fd8765  pop rdx
0000707649fd8766  pop rcx
0000707649fd8767  pop rax
0000707649fd8768  add rsp, 0x08
0000707649fd876c  jmp 0x0000707649FD6030
0000707649fd8771  sub rsp, 0x08
0000707649fd8775  push rax
0000707649fd8776  push rcx
0000707649fd8777  push rdx
0000707649fd8778  push rdi
0000707649fd8779  push rsi
0000707649fd877a  push r8
0000707649fd877c  push r9
0000707649fd877e  push r10
0000707649fd8780  push r11
0000707649fd8782  sub rsp, 0xF0
0000707649fd8789  vmovaps [rsp], xmm0
0000707649fd878e  vmovaps [rsp+0x10], xmm1
0000707649fd8794  vmovaps [rsp+0x20], xmm2
0000707649fd879a  vmovaps [rsp+0x30], xmm4
0000707649fd87a0  vmovaps [rsp+0x40], xmm5
0000707649fd87a6  vmovaps [rsp+0x50], xmm6
0000707649fd87ac  vmovaps [rsp+0x60], xmm7
0000707649fd87b2  vmovaps [rsp+0x70], xmm8
0000707649fd87b8  vmovaps [rsp+0x80], xmm9
0000707649fd87c1  vmovaps [rsp+0x90], xmm10
0000707649fd87ca  vmovaps [rsp+0xA0], xmm11
0000707649fd87d3  vmovaps [rsp+0xB0], xmm12
0000707649fd87dc  vmovaps [rsp+0xC0], xmm13
0000707649fd87e5  vmovaps [rsp+0xD0], xmm14
0000707649fd87ee  vmovaps [rsp+0xE0], xmm15
0000707649fd87f7  sub rsp, 0x30
0000707649fd87fb  movaps [rsp], xmm3
0000707649fd87ff  movaps [rsp+0x10], xmm1
0000707649fd8804  movaps [rsp+0x20], xmm15
0000707649fd880a  lea rdi, [rsp]
0000707649fd880e  mov esi, 0x00
0000707649fd8813  mov rax, 0x59CB0B054530
0000707649fd881d  call rax
0000707649fd881f  movaps xmm3, [rsp]
0000707649fd8823  add rsp, 0x30
0000707649fd8827  vmovaps xmm0, [rsp]
0000707649fd882c  vmovaps xmm1, [rsp+0x10]
0000707649fd8832  vmovaps xmm2, [rsp+0x20]
0000707649fd8838  vmovaps xmm4, [rsp+0x30]
0000707649fd883e  vmovaps xmm5, [rsp+0x40]
0000707649fd8844  vmovaps xmm6, [rsp+0x50]
0000707649fd884a  vmovaps xmm7, [rsp+0x60]
0000707649fd8850  vmovaps xmm8, [rsp+0x70]
0000707649fd8856  vmovaps xmm9, [rsp+0x80]
0000707649fd885f  vmovaps xmm10, [rsp+0x90]
0000707649fd8868  vmovaps xmm11, [rsp+0xA0]
0000707649fd8871  vmovaps xmm12, [rsp+0xB0]
0000707649fd887a  vmovaps xmm13, [rsp+0xC0]
0000707649fd8883  vmovaps xmm14, [rsp+0xD0]
0000707649fd888c  vmovaps xmm15, [rsp+0xE0]
0000707649fd8895  add rsp, 0xF0
0000707649fd889c  pop r11
0000707649fd889e  pop r10
0000707649fd88a0  pop r9
0000707649fd88a2  pop r8
0000707649fd88a4  pop rsi
0000707649fd88a5  pop rdi
0000707649fd88a6  pop rdx
0000707649fd88a7  pop rcx
0000707649fd88a8  pop rax
0000707649fd88a9  add rsp, 0x08
0000707649fd88ad  jmp 0x0000707649FD60BF
0000707649fd88b2  call 0x0000707649ED64F0
0000707649fd88b7  jmp 0x0000707649FD60C9
0000707649fd88bc  sub rsp, 0x08
0000707649fd88c0  push rax
0000707649fd88c1  push rcx
0000707649fd88c2  push rdx
0000707649fd88c3  push rdi
0000707649fd88c4  push rsi
0000707649fd88c5  push r8
0000707649fd88c7  push r9
0000707649fd88c9  push r10
0000707649fd88cb  push r11
0000707649fd88cd  sub rsp, 0xF0
0000707649fd88d4  vmovaps [rsp], xmm0
0000707649fd88d9  vmovaps [rsp+0x10], xmm1
0000707649fd88df  vmovaps [rsp+0x20], xmm2
0000707649fd88e5  vmovaps [rsp+0x30], xmm3
0000707649fd88eb  vmovaps [rsp+0x40], xmm4
0000707649fd88f1  vmovaps [rsp+0x50], xmm5
0000707649fd88f7  vmovaps [rsp+0x60], xmm6
0000707649fd88fd  vmovaps [rsp+0x70], xmm7
0000707649fd8903  vmovaps [rsp+0x80], xmm8
0000707649fd890c  vmovaps [rsp+0x90], xmm9
0000707649fd8915  vmovaps [rsp+0xA0], xmm10
0000707649fd891e  vmovaps [rsp+0xB0], xmm11
0000707649fd8927  vmovaps [rsp+0xC0], xmm12
0000707649fd8930  vmovaps [rsp+0xD0], xmm13
0000707649fd8939  vmovaps [rsp+0xE0], xmm14
0000707649fd8942  sub rsp, 0x30
0000707649fd8946  movaps [rsp], xmm15
0000707649fd894b  movaps [rsp+0x10], xmm14
0000707649fd8951  movaps [rsp+0x20], xmm4
0000707649fd8956  lea rdi, [rsp]
0000707649fd895a  mov esi, 0x00
0000707649fd895f  mov rax, 0x59CB0B054530
0000707649fd8969  call rax
0000707649fd896b  movaps xmm15, [rsp]
0000707649fd8970  add rsp, 0x30
0000707649fd8974  vmovaps xmm0, [rsp]
0000707649fd8979  vmovaps xmm1, [rsp+0x10]
0000707649fd897f  vmovaps xmm2, [rsp+0x20]
0000707649fd8985  vmovaps xmm3, [rsp+0x30]
0000707649fd898b  vmovaps xmm4, [rsp+0x40]
0000707649fd8991  vmovaps xmm5, [rsp+0x50]
0000707649fd8997  vmovaps xmm6, [rsp+0x60]
0000707649fd899d  vmovaps xmm7, [rsp+0x70]
0000707649fd89a3  vmovaps xmm8, [rsp+0x80]
0000707649fd89ac  vmovaps xmm9, [rsp+0x90]
0000707649fd89b5  vmovaps xmm10, [rsp+0xA0]
0000707649fd89be  vmovaps xmm11, [rsp+0xB0]
0000707649fd89c7  vmovaps xmm12, [rsp+0xC0]
0000707649fd89d0  vmovaps xmm13, [rsp+0xD0]
0000707649fd89d9  vmovaps xmm14, [rsp+0xE0]
0000707649fd89e2  add rsp, 0xF0
0000707649fd89e9  pop r11
0000707649fd89eb  pop r10
0000707649fd89ed  pop r9
0000707649fd89ef  pop r8
0000707649fd89f1  pop rsi
0000707649fd89f2  pop rdi
0000707649fd89f3  pop rdx
0000707649fd89f4  pop rcx
0000707649fd89f5  pop rax
0000707649fd89f6  add rsp, 0x08
0000707649fd89fa  jmp 0x0000707649FD60F7
0000707649fd89ff  sub rsp, 0x08
0000707649fd8a03  push rax
0000707649fd8a04  push rcx
0000707649fd8a05  push rdx
0000707649fd8a06  push rdi
0000707649fd8a07  push rsi
0000707649fd8a08  push r8
0000707649fd8a0a  push r9
0000707649fd8a0c  push r10
0000707649fd8a0e  push r11
0000707649fd8a10  sub rsp, 0xF0
0000707649fd8a17  vmovaps [rsp], xmm0
0000707649fd8a1c  vmovaps [rsp+0x10], xmm1
0000707649fd8a22  vmovaps [rsp+0x20], xmm2
0000707649fd8a28  vmovaps [rsp+0x30], xmm3
0000707649fd8a2e  vmovaps [rsp+0x40], xmm4
0000707649fd8a34  vmovaps [rsp+0x50], xmm5
0000707649fd8a3a  vmovaps [rsp+0x60], xmm6
0000707649fd8a40  vmovaps [rsp+0x70], xmm7
0000707649fd8a46  vmovaps [rsp+0x80], xmm8
0000707649fd8a4f  vmovaps [rsp+0x90], xmm9
0000707649fd8a58  vmovaps [rsp+0xA0], xmm10
0000707649fd8a61  vmovaps [rsp+0xB0], xmm11
0000707649fd8a6a  vmovaps [rsp+0xC0], xmm12
0000707649fd8a73  vmovaps [rsp+0xD0], xmm13
0000707649fd8a7c  vmovaps [rsp+0xE0], xmm15
0000707649fd8a85  sub rsp, 0x30
0000707649fd8a89  movaps [rsp], xmm14
0000707649fd8a8e  movaps [rsp+0x10], xmm2
0000707649fd8a93  movaps [rsp+0x20], xmm1
0000707649fd8a98  lea rdi, [rsp]
0000707649fd8a9c  mov esi, 0x00
0000707649fd8aa1  mov rax, 0x59CB0B054530
0000707649fd8aab  call rax
0000707649fd8aad  movaps xmm14, [rsp]
0000707649fd8ab2  add rsp, 0x30
0000707649fd8ab6  vmovaps xmm0, [rsp]
0000707649fd8abb  vmovaps xmm1, [rsp+0x10]
0000707649fd8ac1  vmovaps xmm2, [rsp+0x20]
0000707649fd8ac7  vmovaps xmm3, [rsp+0x30]
0000707649fd8acd  vmovaps xmm4, [rsp+0x40]
0000707649fd8ad3  vmovaps xmm5, [rsp+0x50]
0000707649fd8ad9  vmovaps xmm6, [rsp+0x60]
0000707649fd8adf  vmovaps xmm7, [rsp+0x70]
0000707649fd8ae5  vmovaps xmm8, [rsp+0x80]
0000707649fd8aee  vmovaps xmm9, [rsp+0x90]
0000707649fd8af7  vmovaps xmm10, [rsp+0xA0]
0000707649fd8b00  vmovaps xmm11, [rsp+0xB0]
0000707649fd8b09  vmovaps xmm12, [rsp+0xC0]
0000707649fd8b12  vmovaps xmm13, [rsp+0xD0]
0000707649fd8b1b  vmovaps xmm15, [rsp+0xE0]
0000707649fd8b24  add rsp, 0xF0
0000707649fd8b2b  pop r11
0000707649fd8b2d  pop r10
0000707649fd8b2f  pop r9
0000707649fd8b31  pop r8
0000707649fd8b33  pop rsi
0000707649fd8b34  pop rdi
0000707649fd8b35  pop rdx
0000707649fd8b36  pop rcx
0000707649fd8b37  pop rax
0000707649fd8b38  add rsp, 0x08
0000707649fd8b3c  jmp 0x0000707649FD611D
0000707649fd8b41  sub rsp, 0x08
0000707649fd8b45  push rax
0000707649fd8b46  push rcx
0000707649fd8b47  push rdx
0000707649fd8b48  push rdi
0000707649fd8b49  push rsi
0000707649fd8b4a  push r8
0000707649fd8b4c  push r9
0000707649fd8b4e  push r10
0000707649fd8b50  push r11
0000707649fd8b52  sub rsp, 0xF0
0000707649fd8b59  vmovaps [rsp], xmm0
0000707649fd8b5e  vmovaps [rsp+0x10], xmm2
0000707649fd8b64  vmovaps [rsp+0x20], xmm3
0000707649fd8b6a  vmovaps [rsp+0x30], xmm4
0000707649fd8b70  vmovaps [rsp+0x40], xmm5
0000707649fd8b76  vmovaps [rsp+0x50], xmm6
0000707649fd8b7c  vmovaps [rsp+0x60], xmm7
0000707649fd8b82  vmovaps [rsp+0x70], xmm8
0000707649fd8b88  vmovaps [rsp+0x80], xmm9
0000707649fd8b91  vmovaps [rsp+0x90], xmm10
0000707649fd8b9a  vmovaps [rsp+0xA0], xmm11
0000707649fd8ba3  vmovaps [rsp+0xB0], xmm12
0000707649fd8bac  vmovaps [rsp+0xC0], xmm13
0000707649fd8bb5  vmovaps [rsp+0xD0], xmm14
0000707649fd8bbe  vmovaps [rsp+0xE0], xmm15
0000707649fd8bc7  sub rsp, 0x30
0000707649fd8bcb  movaps [rsp], xmm1
0000707649fd8bcf  movaps [rsp+0x10], xmm4
0000707649fd8bd4  movaps [rsp+0x20], xmm9
0000707649fd8bda  lea rdi, [rsp]
0000707649fd8bde  mov esi, 0x00
0000707649fd8be3  mov rax, 0x59CB0B054530
0000707649fd8bed  call rax
0000707649fd8bef  movaps xmm1, [rsp]
0000707649fd8bf3  add rsp, 0x30
0000707649fd8bf7  vmovaps xmm0, [rsp]
0000707649fd8bfc  vmovaps xmm2, [rsp+0x10]
0000707649fd8c02  vmovaps xmm3, [rsp+0x20]
0000707649fd8c08  vmovaps xmm4, [rsp+0x30]
0000707649fd8c0e  vmovaps xmm5, [rsp+0x40]
0000707649fd8c14  vmovaps xmm6, [rsp+0x50]
0000707649fd8c1a  vmovaps xmm7, [rsp+0x60]
0000707649fd8c20  vmovaps xmm8, [rsp+0x70]
0000707649fd8c26  vmovaps xmm9, [rsp+0x80]
0000707649fd8c2f  vmovaps xmm10, [rsp+0x90]
0000707649fd8c38  vmovaps xmm11, [rsp+0xA0]
0000707649fd8c41  vmovaps xmm12, [rsp+0xB0]
0000707649fd8c4a  vmovaps xmm13, [rsp+0xC0]
0000707649fd8c53  vmovaps xmm14, [rsp+0xD0]
0000707649fd8c5c  vmovaps xmm15, [rsp+0xE0]
0000707649fd8c65  add rsp, 0xF0
0000707649fd8c6c  pop r11
0000707649fd8c6e  pop r10
0000707649fd8c70  pop r9
0000707649fd8c72  pop r8
0000707649fd8c74  pop rsi
0000707649fd8c75  pop rdi
0000707649fd8c76  pop rdx
0000707649fd8c77  pop rcx
0000707649fd8c78  pop rax
0000707649fd8c79  add rsp, 0x08
0000707649fd8c7d  jmp 0x0000707649FD613B
0000707649fd8c82  sub rsp, 0x08
0000707649fd8c86  push rax
0000707649fd8c87  push rcx
0000707649fd8c88  push rdx
0000707649fd8c89  push rdi
0000707649fd8c8a  push rsi
0000707649fd8c8b  push r8
0000707649fd8c8d  push r9
0000707649fd8c8f  push r10
0000707649fd8c91  push r11
0000707649fd8c93  sub rsp, 0xF0
0000707649fd8c9a  vmovaps [rsp], xmm0
0000707649fd8c9f  vmovaps [rsp+0x10], xmm1
0000707649fd8ca5  vmovaps [rsp+0x20], xmm2
0000707649fd8cab  vmovaps [rsp+0x30], xmm3
0000707649fd8cb1  vmovaps [rsp+0x40], xmm5
0000707649fd8cb7  vmovaps [rsp+0x50], xmm6
0000707649fd8cbd  vmovaps [rsp+0x60], xmm7
0000707649fd8cc3  vmovaps [rsp+0x70], xmm8
0000707649fd8cc9  vmovaps [rsp+0x80], xmm9
0000707649fd8cd2  vmovaps [rsp+0x90], xmm10
0000707649fd8cdb  vmovaps [rsp+0xA0], xmm11
0000707649fd8ce4  vmovaps [rsp+0xB0], xmm12
0000707649fd8ced  vmovaps [rsp+0xC0], xmm13
0000707649fd8cf6  vmovaps [rsp+0xD0], xmm14
0000707649fd8cff  vmovaps [rsp+0xE0], xmm15
0000707649fd8d08  sub rsp, 0x30
0000707649fd8d0c  movaps [rsp], xmm4
0000707649fd8d10  movaps [rsp+0x10], xmm2
0000707649fd8d15  movaps [rsp+0x20], xmm9
0000707649fd8d1b  lea rdi, [rsp]
0000707649fd8d1f  mov esi, 0x00
0000707649fd8d24  mov rax, 0x59CB0B054530
0000707649fd8d2e  call rax
0000707649fd8d30  movaps xmm4, [rsp]
0000707649fd8d34  add rsp, 0x30
0000707649fd8d38  vmovaps xmm0, [rsp]
0000707649fd8d3d  vmovaps xmm1, [rsp+0x10]
0000707649fd8d43  vmovaps xmm2, [rsp+0x20]
0000707649fd8d49  vmovaps xmm3, [rsp+0x30]
0000707649fd8d4f  vmovaps xmm5, [rsp+0x40]
0000707649fd8d55  vmovaps xmm6, [rsp+0x50]
0000707649fd8d5b  vmovaps xmm7, [rsp+0x60]
0000707649fd8d61  vmovaps xmm8, [rsp+0x70]
0000707649fd8d67  vmovaps xmm9, [rsp+0x80]
0000707649fd8d70  vmovaps xmm10, [rsp+0x90]
0000707649fd8d79  vmovaps xmm11, [rsp+0xA0]
0000707649fd8d82  vmovaps xmm12, [rsp+0xB0]
0000707649fd8d8b  vmovaps xmm13, [rsp+0xC0]
0000707649fd8d94  vmovaps xmm14, [rsp+0xD0]
0000707649fd8d9d  vmovaps xmm15, [rsp+0xE0]
0000707649fd8da6  add rsp, 0xF0
0000707649fd8dad  pop r11
0000707649fd8daf  pop r10
0000707649fd8db1  pop r9
0000707649fd8db3  pop r8
0000707649fd8db5  pop rsi
0000707649fd8db6  pop rdi
0000707649fd8db7  pop rdx
0000707649fd8db8  pop rcx
0000707649fd8db9  pop rax
0000707649fd8dba  add rsp, 0x08
0000707649fd8dbe  jmp 0x0000707649FD616B
0000707649fd8dc3  sub rsp, 0x08
0000707649fd8dc7  push rax
0000707649fd8dc8  push rcx
0000707649fd8dc9  push rdx
0000707649fd8dca  push rdi
0000707649fd8dcb  push rsi
0000707649fd8dcc  push r8
0000707649fd8dce  push r9
0000707649fd8dd0  push r10
0000707649fd8dd2  push r11
0000707649fd8dd4  sub rsp, 0xF0
0000707649fd8ddb  vmovaps [rsp], xmm0
0000707649fd8de0  vmovaps [rsp+0x10], xmm1
0000707649fd8de6  vmovaps [rsp+0x20], xmm2
0000707649fd8dec  vmovaps [rsp+0x30], xmm3
0000707649fd8df2  vmovaps [rsp+0x40], xmm4
0000707649fd8df8  vmovaps [rsp+0x50], xmm5
0000707649fd8dfe  vmovaps [rsp+0x60], xmm6
0000707649fd8e04  vmovaps [rsp+0x70], xmm7
0000707649fd8e0a  vmovaps [rsp+0x80], xmm8
0000707649fd8e13  vmovaps [rsp+0x90], xmm10
0000707649fd8e1c  vmovaps [rsp+0xA0], xmm11
0000707649fd8e25  vmovaps [rsp+0xB0], xmm12
0000707649fd8e2e  vmovaps [rsp+0xC0], xmm13
0000707649fd8e37  vmovaps [rsp+0xD0], xmm14
0000707649fd8e40  vmovaps [rsp+0xE0], xmm15
0000707649fd8e49  sub rsp, 0x30
0000707649fd8e4d  movaps [rsp], xmm9
0000707649fd8e52  movaps [rsp+0x10], xmm2
0000707649fd8e57  movaps [rsp+0x20], xmm1
0000707649fd8e5c  lea rdi, [rsp]
0000707649fd8e60  mov esi, 0x00
0000707649fd8e65  mov rax, 0x59CB0B054530
0000707649fd8e6f  call rax
0000707649fd8e71  movaps xmm9, [rsp]
0000707649fd8e76  add rsp, 0x30
0000707649fd8e7a  vmovaps xmm0, [rsp]
0000707649fd8e7f  vmovaps xmm1, [rsp+0x10]
0000707649fd8e85  vmovaps xmm2, [rsp+0x20]
0000707649fd8e8b  vmovaps xmm3, [rsp+0x30]
0000707649fd8e91  vmovaps xmm4, [rsp+0x40]
0000707649fd8e97  vmovaps xmm5, [rsp+0x50]
0000707649fd8e9d  vmovaps xmm6, [rsp+0x60]
0000707649fd8ea3  vmovaps xmm7, [rsp+0x70]
0000707649fd8ea9  vmovaps xmm8, [rsp+0x80]
0000707649fd8eb2  vmovaps xmm10, [rsp+0x90]
0000707649fd8ebb  vmovaps xmm11, [rsp+0xA0]
0000707649fd8ec4  vmovaps xmm12, [rsp+0xB0]
0000707649fd8ecd  vmovaps xmm13, [rsp+0xC0]
0000707649fd8ed6  vmovaps xmm14, [rsp+0xD0]
0000707649fd8edf  vmovaps xmm15, [rsp+0xE0]
0000707649fd8ee8  add rsp, 0xF0
0000707649fd8eef  pop r11
0000707649fd8ef1  pop r10
0000707649fd8ef3  pop r9
0000707649fd8ef5  pop r8
0000707649fd8ef7  pop rsi
0000707649fd8ef8  pop rdi
0000707649fd8ef9  pop rdx
0000707649fd8efa  pop rcx
0000707649fd8efb  pop rax
0000707649fd8efc  add rsp, 0x08
0000707649fd8f00  jmp 0x0000707649FD61A1
0000707649fd8f05  sub rsp, 0x08
0000707649fd8f09  push rax
0000707649fd8f0a  push rcx
0000707649fd8f0b  push rdx
0000707649fd8f0c  push rdi
0000707649fd8f0d  push rsi
0000707649fd8f0e  push r8
0000707649fd8f10  push r9
0000707649fd8f12  push r10
0000707649fd8f14  push r11
0000707649fd8f16  sub rsp, 0xF0
0000707649fd8f1d  vmovaps [rsp], xmm0
0000707649fd8f22  vmovaps [rsp+0x10], xmm2
0000707649fd8f28  vmovaps [rsp+0x20], xmm3
0000707649fd8f2e  vmovaps [rsp+0x30], xmm4
0000707649fd8f34  vmovaps [rsp+0x40], xmm5
0000707649fd8f3a  vmovaps [rsp+0x50], xmm6
0000707649fd8f40  vmovaps [rsp+0x60], xmm7
0000707649fd8f46  vmovaps [rsp+0x70], xmm8
0000707649fd8f4c  vmovaps [rsp+0x80], xmm9
0000707649fd8f55  vmovaps [rsp+0x90], xmm10
0000707649fd8f5e  vmovaps [rsp+0xA0], xmm11
0000707649fd8f67  vmovaps [rsp+0xB0], xmm12
0000707649fd8f70  vmovaps [rsp+0xC0], xmm13
0000707649fd8f79  vmovaps [rsp+0xD0], xmm14
0000707649fd8f82  vmovaps [rsp+0xE0], xmm15
0000707649fd8f8b  sub rsp, 0x30
0000707649fd8f8f  movaps [rsp], xmm1
0000707649fd8f93  movaps [rsp+0x10], xmm15
0000707649fd8f99  movaps [rsp+0x20], xmm6
0000707649fd8f9e  lea rdi, [rsp]
0000707649fd8fa2  mov esi, 0x00
0000707649fd8fa7  mov rax, 0x59CB0B054530
0000707649fd8fb1  call rax
0000707649fd8fb3  movaps xmm1, [rsp]
0000707649fd8fb7  add rsp, 0x30
0000707649fd8fbb  vmovaps xmm0, [rsp]
0000707649fd8fc0  vmovaps xmm2, [rsp+0x10]
0000707649fd8fc6  vmovaps xmm3, [rsp+0x20]
0000707649fd8fcc  vmovaps xmm4, [rsp+0x30]
0000707649fd8fd2  vmovaps xmm5, [rsp+0x40]
0000707649fd8fd8  vmovaps xmm6, [rsp+0x50]
0000707649fd8fde  vmovaps xmm7, [rsp+0x60]
0000707649fd8fe4  vmovaps xmm8, [rsp+0x70]
0000707649fd8fea  vmovaps xmm9, [rsp+0x80]
0000707649fd8ff3  vmovaps xmm10, [rsp+0x90]
0000707649fd8ffc  vmovaps xmm11, [rsp+0xA0]
0000707649fd9005  vmovaps xmm12, [rsp+0xB0]
0000707649fd900e  vmovaps xmm13, [rsp+0xC0]
0000707649fd9017  vmovaps xmm14, [rsp+0xD0]
0000707649fd9020  vmovaps xmm15, [rsp+0xE0]
0000707649fd9029  add rsp, 0xF0
0000707649fd9030  pop r11
0000707649fd9032  pop r10
0000707649fd9034  pop r9
0000707649fd9036  pop r8
0000707649fd9038  pop rsi
0000707649fd9039  pop rdi
0000707649fd903a  pop rdx
0000707649fd903b  pop rcx
0000707649fd903c  pop rax
0000707649fd903d  add rsp, 0x08
0000707649fd9041  jmp 0x0000707649FD61C2
0000707649fd9046  sub rsp, 0x08
0000707649fd904a  push rax
0000707649fd904b  push rcx
0000707649fd904c  push rdx
0000707649fd904d  push rdi
0000707649fd904e  push rsi
0000707649fd904f  push r8
0000707649fd9051  push r9
0000707649fd9053  push r10
0000707649fd9055  push r11
0000707649fd9057  sub rsp, 0xF0
0000707649fd905e  vmovaps [rsp], xmm0
0000707649fd9063  vmovaps [rsp+0x10], xmm1
0000707649fd9069  vmovaps [rsp+0x20], xmm2
0000707649fd906f  vmovaps [rsp+0x30], xmm3
0000707649fd9075  vmovaps [rsp+0x40], xmm4
0000707649fd907b  vmovaps [rsp+0x50], xmm5
0000707649fd9081  vmovaps [rsp+0x60], xmm6
0000707649fd9087  vmovaps [rsp+0x70], xmm7
0000707649fd908d  vmovaps [rsp+0x80], xmm8
0000707649fd9096  vmovaps [rsp+0x90], xmm9
0000707649fd909f  vmovaps [rsp+0xA0], xmm10
0000707649fd90a8  vmovaps [rsp+0xB0], xmm11
0000707649fd90b1  vmovaps [rsp+0xC0], xmm12
0000707649fd90ba  vmovaps [rsp+0xD0], xmm13
0000707649fd90c3  vmovaps [rsp+0xE0], xmm14
0000707649fd90cc  sub rsp, 0x30
0000707649fd90d0  movaps [rsp], xmm15
0000707649fd90d5  movaps [rsp+0x10], xmm5
0000707649fd90da  movaps [rsp+0x20], xmm3
0000707649fd90df  lea rdi, [rsp]
0000707649fd90e3  mov esi, 0x00
0000707649fd90e8  mov rax, 0x59CB0B054530
0000707649fd90f2  call rax
0000707649fd90f4  movaps xmm15, [rsp]
0000707649fd90f9  add rsp, 0x30
0000707649fd90fd  vmovaps xmm0, [rsp]
0000707649fd9102  vmovaps xmm1, [rsp+0x10]
0000707649fd9108  vmovaps xmm2, [rsp+0x20]
0000707649fd910e  vmovaps xmm3, [rsp+0x30]
0000707649fd9114  vmovaps xmm4, [rsp+0x40]
0000707649fd911a  vmovaps xmm5, [rsp+0x50]
0000707649fd9120  vmovaps xmm6, [rsp+0x60]
0000707649fd9126  vmovaps xmm7, [rsp+0x70]
0000707649fd912c  vmovaps xmm8, [rsp+0x80]
0000707649fd9135  vmovaps xmm9, [rsp+0x90]
0000707649fd913e  vmovaps xmm10, [rsp+0xA0]
0000707649fd9147  vmovaps xmm11, [rsp+0xB0]
0000707649fd9150  vmovaps xmm12, [rsp+0xC0]
0000707649fd9159  vmovaps xmm13, [rsp+0xD0]
0000707649fd9162  vmovaps xmm14, [rsp+0xE0]
0000707649fd916b  add rsp, 0xF0
0000707649fd9172  pop r11
0000707649fd9174  pop r10
0000707649fd9176  pop r9
0000707649fd9178  pop r8
0000707649fd917a  pop rsi
0000707649fd917b  pop rdi
0000707649fd917c  pop rdx
0000707649fd917d  pop rcx
0000707649fd917e  pop rax
0000707649fd917f  add rsp, 0x08
0000707649fd9183  jmp 0x0000707649FD61DC
0000707649fd9188  sub rsp, 0x08
0000707649fd918c  push rax
0000707649fd918d  push rcx
0000707649fd918e  push rdx
0000707649fd918f  push rdi
0000707649fd9190  push rsi
0000707649fd9191  push r8
0000707649fd9193  push r9
0000707649fd9195  push r10
0000707649fd9197  push r11
0000707649fd9199  sub rsp, 0xF0
0000707649fd91a0  vmovaps [rsp], xmm0
0000707649fd91a5  vmovaps [rsp+0x10], xmm1
0000707649fd91ab  vmovaps [rsp+0x20], xmm2
0000707649fd91b1  vmovaps [rsp+0x30], xmm3
0000707649fd91b7  vmovaps [rsp+0x40], xmm4
0000707649fd91bd  vmovaps [rsp+0x50], xmm6
0000707649fd91c3  vmovaps [rsp+0x60], xmm7
0000707649fd91c9  vmovaps [rsp+0x70], xmm8
0000707649fd91cf  vmovaps [rsp+0x80], xmm9
0000707649fd91d8  vmovaps [rsp+0x90], xmm10
0000707649fd91e1  vmovaps [rsp+0xA0], xmm11
0000707649fd91ea  vmovaps [rsp+0xB0], xmm12
0000707649fd91f3  vmovaps [rsp+0xC0], xmm13
0000707649fd91fc  vmovaps [rsp+0xD0], xmm14
0000707649fd9205  vmovaps [rsp+0xE0], xmm15
0000707649fd920e  sub rsp, 0x30
0000707649fd9212  movaps [rsp], xmm5
0000707649fd9216  movaps [rsp+0x10], xmm8
0000707649fd921c  movaps [rsp+0x20], xmm6
0000707649fd9221  lea rdi, [rsp]
0000707649fd9225  mov esi, 0x00
0000707649fd922a  mov rax, 0x59CB0B054530
0000707649fd9234  call rax
0000707649fd9236  movaps xmm5, [rsp]
0000707649fd923a  add rsp, 0x30
0000707649fd923e  vmovaps xmm0, [rsp]
0000707649fd9243  vmovaps xmm1, [rsp+0x10]
0000707649fd9249  vmovaps xmm2, [rsp+0x20]
0000707649fd924f  vmovaps xmm3, [rsp+0x30]
0000707649fd9255  vmovaps xmm4, [rsp+0x40]
0000707649fd925b  vmovaps xmm6, [rsp+0x50]
0000707649fd9261  vmovaps xmm7, [rsp+0x60]
0000707649fd9267  vmovaps xmm8, [rsp+0x70]
0000707649fd926d  vmovaps xmm9, [rsp+0x80]
0000707649fd9276  vmovaps xmm10, [rsp+0x90]
0000707649fd927f  vmovaps xmm11, [rsp+0xA0]
0000707649fd9288  vmovaps xmm12, [rsp+0xB0]
0000707649fd9291  vmovaps xmm13, [rsp+0xC0]
0000707649fd929a  vmovaps xmm14, [rsp+0xD0]
0000707649fd92a3  vmovaps xmm15, [rsp+0xE0]
0000707649fd92ac  add rsp, 0xF0
0000707649fd92b3  pop r11
0000707649fd92b5  pop r10
0000707649fd92b7  pop r9
0000707649fd92b9  pop r8
0000707649fd92bb  pop rsi
0000707649fd92bc  pop rdi
0000707649fd92bd  pop rdx
0000707649fd92be  pop rcx
0000707649fd92bf  pop rax
0000707649fd92c0  add rsp, 0x08
0000707649fd92c4  jmp 0x0000707649FD6200
0000707649fd92c9  sub rsp, 0x08
0000707649fd92cd  push rax
0000707649fd92ce  push rcx
0000707649fd92cf  push rdx
0000707649fd92d0  push rdi
0000707649fd92d1  push rsi
0000707649fd92d2  push r8
0000707649fd92d4  push r9
0000707649fd92d6  push r10
0000707649fd92d8  push r11
0000707649fd92da  sub rsp, 0xF0
0000707649fd92e1  vmovaps [rsp], xmm0
0000707649fd92e6  vmovaps [rsp+0x10], xmm1
0000707649fd92ec  vmovaps [rsp+0x20], xmm2
0000707649fd92f2  vmovaps [rsp+0x30], xmm3
0000707649fd92f8  vmovaps [rsp+0x40], xmm4
0000707649fd92fe  vmovaps [rsp+0x50], xmm5
0000707649fd9304  vmovaps [rsp+0x60], xmm7
0000707649fd930a  vmovaps [rsp+0x70], xmm8
0000707649fd9310  vmovaps [rsp+0x80], xmm9
0000707649fd9319  vmovaps [rsp+0x90], xmm10
0000707649fd9322  vmovaps [rsp+0xA0], xmm11
0000707649fd932b  vmovaps [rsp+0xB0], xmm12
0000707649fd9334  vmovaps [rsp+0xC0], xmm13
0000707649fd933d  vmovaps [rsp+0xD0], xmm14
0000707649fd9346  vmovaps [rsp+0xE0], xmm15
0000707649fd934f  sub rsp, 0x30
0000707649fd9353  movaps [rsp], xmm6
0000707649fd9357  movaps [rsp+0x10], xmm10
0000707649fd935d  movaps [rsp+0x20], xmm8
0000707649fd9363  lea rdi, [rsp]
0000707649fd9367  mov esi, 0x00
0000707649fd936c  mov rax, 0x59CB0B054530
0000707649fd9376  call rax
0000707649fd9378  movaps xmm6, [rsp]
0000707649fd937c  add rsp, 0x30
0000707649fd9380  vmovaps xmm0, [rsp]
0000707649fd9385  vmovaps xmm1, [rsp+0x10]
0000707649fd938b  vmovaps xmm2, [rsp+0x20]
0000707649fd9391  vmovaps xmm3, [rsp+0x30]
0000707649fd9397  vmovaps xmm4, [rsp+0x40]
0000707649fd939d  vmovaps xmm5, [rsp+0x50]
0000707649fd93a3  vmovaps xmm7, [rsp+0x60]
0000707649fd93a9  vmovaps xmm8, [rsp+0x70]
0000707649fd93af  vmovaps xmm9, [rsp+0x80]
0000707649fd93b8  vmovaps xmm10, [rsp+0x90]
0000707649fd93c1  vmovaps xmm11, [rsp+0xA0]
0000707649fd93ca  vmovaps xmm12, [rsp+0xB0]
0000707649fd93d3  vmovaps xmm13, [rsp+0xC0]
0000707649fd93dc  vmovaps xmm14, [rsp+0xD0]
0000707649fd93e5  vmovaps xmm15, [rsp+0xE0]
0000707649fd93ee  add rsp, 0xF0
0000707649fd93f5  pop r11
0000707649fd93f7  pop r10
0000707649fd93f9  pop r9
0000707649fd93fb  pop r8
0000707649fd93fd  pop rsi
0000707649fd93fe  pop rdi
0000707649fd93ff  pop rdx
0000707649fd9400  pop rcx
0000707649fd9401  pop rax
0000707649fd9402  add rsp, 0x08
0000707649fd9406  jmp 0x0000707649FD6225
0000707649fd940b  sub rsp, 0x08
0000707649fd940f  push rax
0000707649fd9410  push rcx
0000707649fd9411  push rdx
0000707649fd9412  push rdi
0000707649fd9413  push rsi
0000707649fd9414  push r8
0000707649fd9416  push r9
0000707649fd9418  push r10
0000707649fd941a  push r11
0000707649fd941c  sub rsp, 0xF0
0000707649fd9423  vmovaps [rsp], xmm0
0000707649fd9428  vmovaps [rsp+0x10], xmm1
0000707649fd942e  vmovaps [rsp+0x20], xmm2
0000707649fd9434  vmovaps [rsp+0x30], xmm3
0000707649fd943a  vmovaps [rsp+0x40], xmm4
0000707649fd9440  vmovaps [rsp+0x50], xmm5
0000707649fd9446  vmovaps [rsp+0x60], xmm6
0000707649fd944c  vmovaps [rsp+0x70], xmm7
0000707649fd9452  vmovaps [rsp+0x80], xmm8
0000707649fd945b  vmovaps [rsp+0x90], xmm9
0000707649fd9464  vmovaps [rsp+0xA0], xmm11
0000707649fd946d  vmovaps [rsp+0xB0], xmm12
0000707649fd9476  vmovaps [rsp+0xC0], xmm13
0000707649fd947f  vmovaps [rsp+0xD0], xmm14
0000707649fd9488  vmovaps [rsp+0xE0], xmm15
0000707649fd9491  sub rsp, 0x30
0000707649fd9495  movaps [rsp], xmm10
0000707649fd949a  movaps [rsp+0x10], xmm8
0000707649fd94a0  movaps [rsp+0x20], xmm14
0000707649fd94a6  lea rdi, [rsp]
0000707649fd94aa  mov esi, 0x00
0000707649fd94af  mov rax, 0x59CB0B054530
0000707649fd94b9  call rax
0000707649fd94bb  movaps xmm10, [rsp]
0000707649fd94c0  add rsp, 0x30
0000707649fd94c4  vmovaps xmm0, [rsp]
0000707649fd94c9  vmovaps xmm1, [rsp+0x10]
0000707649fd94cf  vmovaps xmm2, [rsp+0x20]
0000707649fd94d5  vmovaps xmm3, [rsp+0x30]
0000707649fd94db  vmovaps xmm4, [rsp+0x40]
0000707649fd94e1  vmovaps xmm5, [rsp+0x50]
0000707649fd94e7  vmovaps xmm6, [rsp+0x60]
0000707649fd94ed  vmovaps xmm7, [rsp+0x70]
0000707649fd94f3  vmovaps xmm8, [rsp+0x80]
0000707649fd94fc  vmovaps xmm9, [rsp+0x90]
0000707649fd9505  vmovaps xmm11, [rsp+0xA0]
0000707649fd950e  vmovaps xmm12, [rsp+0xB0]
0000707649fd9517  vmovaps xmm13, [rsp+0xC0]
0000707649fd9520  vmovaps xmm14, [rsp+0xD0]
0000707649fd9529  vmovaps xmm15, [rsp+0xE0]
0000707649fd9532  add rsp, 0xF0
0000707649fd9539  pop r11
0000707649fd953b  pop r10
0000707649fd953d  pop r9
0000707649fd953f  pop r8
0000707649fd9541  pop rsi
0000707649fd9542  pop rdi
0000707649fd9543  pop rdx
0000707649fd9544  pop rcx
0000707649fd9545  pop rax
0000707649fd9546  add rsp, 0x08
0000707649fd954a  jmp 0x0000707649FD6245
0000707649fd954f  sub rsp, 0x08
0000707649fd9553  push rax
0000707649fd9554  push rcx
0000707649fd9555  push rdx
0000707649fd9556  push rdi
0000707649fd9557  push rsi
0000707649fd9558  push r8
0000707649fd955a  push r9
0000707649fd955c  push r10
0000707649fd955e  push r11
0000707649fd9560  sub rsp, 0xF0
0000707649fd9567  vmovaps [rsp], xmm0
0000707649fd956c  vmovaps [rsp+0x10], xmm1
0000707649fd9572  vmovaps [rsp+0x20], xmm2
0000707649fd9578  vmovaps [rsp+0x30], xmm3
0000707649fd957e  vmovaps [rsp+0x40], xmm4
0000707649fd9584  vmovaps [rsp+0x50], xmm5
0000707649fd958a  vmovaps [rsp+0x60], xmm6
0000707649fd9590  vmovaps [rsp+0x70], xmm7
0000707649fd9596  vmovaps [rsp+0x80], xmm8
0000707649fd959f  vmovaps [rsp+0x90], xmm9
0000707649fd95a8  vmovaps [rsp+0xA0], xmm10
0000707649fd95b1  vmovaps [rsp+0xB0], xmm11
0000707649fd95ba  vmovaps [rsp+0xC0], xmm12
0000707649fd95c3  vmovaps [rsp+0xD0], xmm13
0000707649fd95cc  vmovaps [rsp+0xE0], xmm15
0000707649fd95d5  sub rsp, 0x30
0000707649fd95d9  movaps [rsp], xmm14
0000707649fd95de  movaps [rsp+0x10], xmm8
0000707649fd95e4  movaps [rsp+0x20], xmm4
0000707649fd95e9  lea rdi, [rsp]
0000707649fd95ed  mov esi, 0x00
0000707649fd95f2  mov rax, 0x59CB0B054530
0000707649fd95fc  call rax
0000707649fd95fe  movaps xmm14, [rsp]
0000707649fd9603  add rsp, 0x30
0000707649fd9607  vmovaps xmm0, [rsp]
0000707649fd960c  vmovaps xmm1, [rsp+0x10]
0000707649fd9612  vmovaps xmm2, [rsp+0x20]
0000707649fd9618  vmovaps xmm3, [rsp+0x30]
0000707649fd961e  vmovaps xmm4, [rsp+0x40]
0000707649fd9624  vmovaps xmm5, [rsp+0x50]
0000707649fd962a  vmovaps xmm6, [rsp+0x60]
0000707649fd9630  vmovaps xmm7, [rsp+0x70]
0000707649fd9636  vmovaps xmm8, [rsp+0x80]
0000707649fd963f  vmovaps xmm9, [rsp+0x90]
0000707649fd9648  vmovaps xmm10, [rsp+0xA0]
0000707649fd9651  vmovaps xmm11, [rsp+0xB0]
0000707649fd965a  vmovaps xmm12, [rsp+0xC0]
0000707649fd9663  vmovaps xmm13, [rsp+0xD0]
0000707649fd966c  vmovaps xmm15, [rsp+0xE0]
0000707649fd9675  add rsp, 0xF0
0000707649fd967c  pop r11
0000707649fd967e  pop r10
0000707649fd9680  pop r9
0000707649fd9682  pop r8
0000707649fd9684  pop rsi
0000707649fd9685  pop rdi
0000707649fd9686  pop rdx
0000707649fd9687  pop rcx
0000707649fd9688  pop rax
0000707649fd9689  add rsp, 0x08
0000707649fd968d  jmp 0x0000707649FD6265
0000707649fd9692  sub rsp, 0x08
0000707649fd9696  push rax
0000707649fd9697  push rcx
0000707649fd9698  push rdx
0000707649fd9699  push rdi
0000707649fd969a  push rsi
0000707649fd969b  push r8
0000707649fd969d  push r9
0000707649fd969f  push r10
0000707649fd96a1  push r11
0000707649fd96a3  sub rsp, 0xF0
0000707649fd96aa  vmovaps [rsp], xmm0
0000707649fd96af  vmovaps [rsp+0x10], xmm1
0000707649fd96b5  vmovaps [rsp+0x20], xmm2
0000707649fd96bb  vmovaps [rsp+0x30], xmm3
0000707649fd96c1  vmovaps [rsp+0x40], xmm5
0000707649fd96c7  vmovaps [rsp+0x50], xmm6
0000707649fd96cd  vmovaps [rsp+0x60], xmm7
0000707649fd96d3  vmovaps [rsp+0x70], xmm8
0000707649fd96d9  vmovaps [rsp+0x80], xmm9
0000707649fd96e2  vmovaps [rsp+0x90], xmm10
0000707649fd96eb  vmovaps [rsp+0xA0], xmm11
0000707649fd96f4  vmovaps [rsp+0xB0], xmm12
0000707649fd96fd  vmovaps [rsp+0xC0], xmm13
0000707649fd9706  vmovaps [rsp+0xD0], xmm14
0000707649fd970f  vmovaps [rsp+0xE0], xmm15
0000707649fd9718  sub rsp, 0x30
0000707649fd971c  movaps [rsp], xmm4
0000707649fd9720  movaps [rsp+0x10], xmm13
0000707649fd9726  movaps [rsp+0x20], xmm8
0000707649fd972c  lea rdi, [rsp]
0000707649fd9730  mov esi, 0x00
0000707649fd9735  mov rax, 0x59CB0B054530
0000707649fd973f  call rax
0000707649fd9741  movaps xmm4, [rsp]
0000707649fd9745  add rsp, 0x30
0000707649fd9749  vmovaps xmm0, [rsp]
0000707649fd974e  vmovaps xmm1, [rsp+0x10]
0000707649fd9754  vmovaps xmm2, [rsp+0x20]
0000707649fd975a  vmovaps xmm3, [rsp+0x30]
0000707649fd9760  vmovaps xmm5, [rsp+0x40]
0000707649fd9766  vmovaps xmm6, [rsp+0x50]
0000707649fd976c  vmovaps xmm7, [rsp+0x60]
0000707649fd9772  vmovaps xmm8, [rsp+0x70]
0000707649fd9778  vmovaps xmm9, [rsp+0x80]
0000707649fd9781  vmovaps xmm10, [rsp+0x90]
0000707649fd978a  vmovaps xmm11, [rsp+0xA0]
0000707649fd9793  vmovaps xmm12, [rsp+0xB0]
0000707649fd979c  vmovaps xmm13, [rsp+0xC0]
0000707649fd97a5  vmovaps xmm14, [rsp+0xD0]
0000707649fd97ae  vmovaps xmm15, [rsp+0xE0]
0000707649fd97b7  add rsp, 0xF0
0000707649fd97be  pop r11
0000707649fd97c0  pop r10
0000707649fd97c2  pop r9
0000707649fd97c4  pop r8
0000707649fd97c6  pop rsi
0000707649fd97c7  pop rdi
0000707649fd97c8  pop rdx
0000707649fd97c9  pop rcx
0000707649fd97ca  pop rax
0000707649fd97cb  add rsp, 0x08
0000707649fd97cf  jmp 0x0000707649FD628A
0000707649fd97d4  sub rsp, 0x08
0000707649fd97d8  push rax
0000707649fd97d9  push rcx
0000707649fd97da  push rdx
0000707649fd97db  push rdi
0000707649fd97dc  push rsi
0000707649fd97dd  push r8
0000707649fd97df  push r9
0000707649fd97e1  push r10
0000707649fd97e3  push r11
0000707649fd97e5  sub rsp, 0xF0
0000707649fd97ec  vmovaps [rsp], xmm0
0000707649fd97f1  vmovaps [rsp+0x10], xmm1
0000707649fd97f7  vmovaps [rsp+0x20], xmm2
0000707649fd97fd  vmovaps [rsp+0x30], xmm3
0000707649fd9803  vmovaps [rsp+0x40], xmm4
0000707649fd9809  vmovaps [rsp+0x50], xmm5
0000707649fd980f  vmovaps [rsp+0x60], xmm6
0000707649fd9815  vmovaps [rsp+0x70], xmm7
0000707649fd981b  vmovaps [rsp+0x80], xmm8
0000707649fd9824  vmovaps [rsp+0x90], xmm9
0000707649fd982d  vmovaps [rsp+0xA0], xmm10
0000707649fd9836  vmovaps [rsp+0xB0], xmm11
0000707649fd983f  vmovaps [rsp+0xC0], xmm12
0000707649fd9848  vmovaps [rsp+0xD0], xmm14
0000707649fd9851  vmovaps [rsp+0xE0], xmm15
0000707649fd985a  sub rsp, 0x30
0000707649fd985e  movaps [rsp], xmm13
0000707649fd9863  movaps [rsp+0x10], xmm15
0000707649fd9869  movaps [rsp+0x20], xmm9
0000707649fd986f  lea rdi, [rsp]
0000707649fd9873  mov esi, 0x00
0000707649fd9878  mov rax, 0x59CB0B054530
0000707649fd9882  call rax
0000707649fd9884  movaps xmm13, [rsp]
0000707649fd9889  add rsp, 0x30
0000707649fd988d  vmovaps xmm0, [rsp]
0000707649fd9892  vmovaps xmm1, [rsp+0x10]
0000707649fd9898  vmovaps xmm2, [rsp+0x20]
0000707649fd989e  vmovaps xmm3, [rsp+0x30]
0000707649fd98a4  vmovaps xmm4, [rsp+0x40]
0000707649fd98aa  vmovaps xmm5, [rsp+0x50]
0000707649fd98b0  vmovaps xmm6, [rsp+0x60]
0000707649fd98b6  vmovaps xmm7, [rsp+0x70]
0000707649fd98bc  vmovaps xmm8, [rsp+0x80]
0000707649fd98c5  vmovaps xmm9, [rsp+0x90]
0000707649fd98ce  vmovaps xmm10, [rsp+0xA0]
0000707649fd98d7  vmovaps xmm11, [rsp+0xB0]
0000707649fd98e0  vmovaps xmm12, [rsp+0xC0]
0000707649fd98e9  vmovaps xmm14, [rsp+0xD0]
0000707649fd98f2  vmovaps xmm15, [rsp+0xE0]
0000707649fd98fb  add rsp, 0xF0
0000707649fd9902  pop r11
0000707649fd9904  pop r10
0000707649fd9906  pop r9
0000707649fd9908  pop r8
0000707649fd990a  pop rsi
0000707649fd990b  pop rdi
0000707649fd990c  pop rdx
0000707649fd990d  pop rcx
0000707649fd990e  pop rax
0000707649fd990f  add rsp, 0x08
0000707649fd9913  jmp 0x0000707649FD62A5
0000707649fd9918  sub rsp, 0x08
0000707649fd991c  push rax
0000707649fd991d  push rcx
0000707649fd991e  push rdx
0000707649fd991f  push rdi
0000707649fd9920  push rsi
0000707649fd9921  push r8
0000707649fd9923  push r9
0000707649fd9925  push r10
0000707649fd9927  push r11
0000707649fd9929  sub rsp, 0xF0
0000707649fd9930  vmovaps [rsp], xmm0
0000707649fd9935  vmovaps [rsp+0x10], xmm1
0000707649fd993b  vmovaps [rsp+0x20], xmm2
0000707649fd9941  vmovaps [rsp+0x30], xmm3
0000707649fd9947  vmovaps [rsp+0x40], xmm4
0000707649fd994d  vmovaps [rsp+0x50], xmm5
0000707649fd9953  vmovaps [rsp+0x60], xmm6
0000707649fd9959  vmovaps [rsp+0x70], xmm7
0000707649fd995f  vmovaps [rsp+0x80], xmm8
0000707649fd9968  vmovaps [rsp+0x90], xmm9
0000707649fd9971  vmovaps [rsp+0xA0], xmm10
0000707649fd997a  vmovaps [rsp+0xB0], xmm11
0000707649fd9983  vmovaps [rsp+0xC0], xmm12
0000707649fd998c  vmovaps [rsp+0xD0], xmm13
0000707649fd9995  vmovaps [rsp+0xE0], xmm14
0000707649fd999e  sub rsp, 0x30
0000707649fd99a2  movaps [rsp], xmm15
0000707649fd99a7  movaps [rsp+0x10], xmm1
0000707649fd99ac  movaps [rsp+0x20], xmm5
0000707649fd99b1  lea rdi, [rsp]
0000707649fd99b5  mov esi, 0x00
0000707649fd99ba  mov rax, 0x59CB0B054530
0000707649fd99c4  call rax
0000707649fd99c6  movaps xmm15, [rsp]
0000707649fd99cb  add rsp, 0x30
0000707649fd99cf  vmovaps xmm0, [rsp]
0000707649fd99d4  vmovaps xmm1, [rsp+0x10]
0000707649fd99da  vmovaps xmm2, [rsp+0x20]
0000707649fd99e0  vmovaps xmm3, [rsp+0x30]
0000707649fd99e6  vmovaps xmm4, [rsp+0x40]
0000707649fd99ec  vmovaps xmm5, [rsp+0x50]
0000707649fd99f2  vmovaps xmm6, [rsp+0x60]
0000707649fd99f8  vmovaps xmm7, [rsp+0x70]
0000707649fd99fe  vmovaps xmm8, [rsp+0x80]
0000707649fd9a07  vmovaps xmm9, [rsp+0x90]
0000707649fd9a10  vmovaps xmm10, [rsp+0xA0]
0000707649fd9a19  vmovaps xmm11, [rsp+0xB0]
0000707649fd9a22  vmovaps xmm12, [rsp+0xC0]
0000707649fd9a2b  vmovaps xmm13, [rsp+0xD0]
0000707649fd9a34  vmovaps xmm14, [rsp+0xE0]
0000707649fd9a3d  add rsp, 0xF0
0000707649fd9a44  pop r11
0000707649fd9a46  pop r10
0000707649fd9a48  pop r9
0000707649fd9a4a  pop r8
0000707649fd9a4c  pop rsi
0000707649fd9a4d  pop rdi
0000707649fd9a4e  pop rdx
0000707649fd9a4f  pop rcx
0000707649fd9a50  pop rax
0000707649fd9a51  add rsp, 0x08
0000707649fd9a55  jmp 0x0000707649FD62C0
0000707649fd9a5a  call 0x0000707649ED64F0
0000707649fd9a5f  jmp 0x0000707649FD631B
0000707649fd9a64  sub rsp, 0x08
0000707649fd9a68  push rax
0000707649fd9a69  push rcx
0000707649fd9a6a  push rdx
0000707649fd9a6b  push rdi
0000707649fd9a6c  push rsi
0000707649fd9a6d  push r8
0000707649fd9a6f  push r9
0000707649fd9a71  push r10
0000707649fd9a73  push r11
0000707649fd9a75  sub rsp, 0xF0
0000707649fd9a7c  vmovaps [rsp], xmm0
0000707649fd9a81  vmovaps [rsp+0x10], xmm1
0000707649fd9a87  vmovaps [rsp+0x20], xmm2
0000707649fd9a8d  vmovaps [rsp+0x30], xmm3
0000707649fd9a93  vmovaps [rsp+0x40], xmm4
0000707649fd9a99  vmovaps [rsp+0x50], xmm5
0000707649fd9a9f  vmovaps [rsp+0x60], xmm6
0000707649fd9aa5  vmovaps [rsp+0x70], xmm7
0000707649fd9aab  vmovaps [rsp+0x80], xmm8
0000707649fd9ab4  vmovaps [rsp+0x90], xmm10
0000707649fd9abd  vmovaps [rsp+0xA0], xmm11
0000707649fd9ac6  vmovaps [rsp+0xB0], xmm12
0000707649fd9acf  vmovaps [rsp+0xC0], xmm13
0000707649fd9ad8  vmovaps [rsp+0xD0], xmm14
0000707649fd9ae1  vmovaps [rsp+0xE0], xmm15
0000707649fd9aea  sub rsp, 0x30
0000707649fd9aee  movaps [rsp], xmm9
0000707649fd9af3  movaps [rsp+0x10], xmm8
0000707649fd9af9  movaps [rsp+0x20], xmm11
0000707649fd9aff  lea rdi, [rsp]
0000707649fd9b03  mov esi, 0x00
0000707649fd9b08  mov rax, 0x59CB0B054530
0000707649fd9b12  call rax
0000707649fd9b14  movaps xmm9, [rsp]
0000707649fd9b19  add rsp, 0x30
0000707649fd9b1d  vmovaps xmm0, [rsp]
0000707649fd9b22  vmovaps xmm1, [rsp+0x10]
0000707649fd9b28  vmovaps xmm2, [rsp+0x20]
0000707649fd9b2e  vmovaps xmm3, [rsp+0x30]
0000707649fd9b34  vmovaps xmm4, [rsp+0x40]
0000707649fd9b3a  vmovaps xmm5, [rsp+0x50]
0000707649fd9b40  vmovaps xmm6, [rsp+0x60]
0000707649fd9b46  vmovaps xmm7, [rsp+0x70]
0000707649fd9b4c  vmovaps xmm8, [rsp+0x80]
0000707649fd9b55  vmovaps xmm10, [rsp+0x90]
0000707649fd9b5e  vmovaps xmm11, [rsp+0xA0]
0000707649fd9b67  vmovaps xmm12, [rsp+0xB0]
0000707649fd9b70  vmovaps xmm13, [rsp+0xC0]
0000707649fd9b79  vmovaps xmm14, [rsp+0xD0]
0000707649fd9b82  vmovaps xmm15, [rsp+0xE0]
0000707649fd9b8b  add rsp, 0xF0
0000707649fd9b92  pop r11
0000707649fd9b94  pop r10
0000707649fd9b96  pop r9
0000707649fd9b98  pop r8
0000707649fd9b9a  pop rsi
0000707649fd9b9b  pop rdi
0000707649fd9b9c  pop rdx
0000707649fd9b9d  pop rcx
0000707649fd9b9e  pop rax
0000707649fd9b9f  add rsp, 0x08
0000707649fd9ba3  jmp 0x0000707649FD6352
0000707649fd9ba8  sub rsp, 0x08
0000707649fd9bac  push rax
0000707649fd9bad  push rcx
0000707649fd9bae  push rdx
0000707649fd9baf  push rdi
0000707649fd9bb0  push rsi
0000707649fd9bb1  push r8
0000707649fd9bb3  push r9
0000707649fd9bb5  push r10
0000707649fd9bb7  push r11
0000707649fd9bb9  sub rsp, 0xF0
0000707649fd9bc0  vmovaps [rsp], xmm0
0000707649fd9bc5  vmovaps [rsp+0x10], xmm1
0000707649fd9bcb  vmovaps [rsp+0x20], xmm2
0000707649fd9bd1  vmovaps [rsp+0x30], xmm3
0000707649fd9bd7  vmovaps [rsp+0x40], xmm4
0000707649fd9bdd  vmovaps [rsp+0x50], xmm5
0000707649fd9be3  vmovaps [rsp+0x60], xmm6
0000707649fd9be9  vmovaps [rsp+0x70], xmm7
0000707649fd9bef  vmovaps [rsp+0x80], xmm8
0000707649fd9bf8  vmovaps [rsp+0x90], xmm9
0000707649fd9c01  vmovaps [rsp+0xA0], xmm10
0000707649fd9c0a  vmovaps [rsp+0xB0], xmm12
0000707649fd9c13  vmovaps [rsp+0xC0], xmm13
0000707649fd9c1c  vmovaps [rsp+0xD0], xmm14
0000707649fd9c25  vmovaps [rsp+0xE0], xmm15
0000707649fd9c2e  sub rsp, 0x30
0000707649fd9c32  movaps [rsp], xmm11
0000707649fd9c37  movaps [rsp+0x10], xmm10
0000707649fd9c3d  movaps [rsp+0x20], xmm6
0000707649fd9c42  lea rdi, [rsp]
0000707649fd9c46  mov esi, 0x00
0000707649fd9c4b  mov rax, 0x59CB0B054530
0000707649fd9c55  call rax
0000707649fd9c57  movaps xmm11, [rsp]
0000707649fd9c5c  add rsp, 0x30
0000707649fd9c60  vmovaps xmm0, [rsp]
0000707649fd9c65  vmovaps xmm1, [rsp+0x10]
0000707649fd9c6b  vmovaps xmm2, [rsp+0x20]
0000707649fd9c71  vmovaps xmm3, [rsp+0x30]
0000707649fd9c77  vmovaps xmm4, [rsp+0x40]
0000707649fd9c7d  vmovaps xmm5, [rsp+0x50]
0000707649fd9c83  vmovaps xmm6, [rsp+0x60]
0000707649fd9c89  vmovaps xmm7, [rsp+0x70]
0000707649fd9c8f  vmovaps xmm8, [rsp+0x80]
0000707649fd9c98  vmovaps xmm9, [rsp+0x90]
0000707649fd9ca1  vmovaps xmm10, [rsp+0xA0]
0000707649fd9caa  vmovaps xmm12, [rsp+0xB0]
0000707649fd9cb3  vmovaps xmm13, [rsp+0xC0]
0000707649fd9cbc  vmovaps xmm14, [rsp+0xD0]
0000707649fd9cc5  vmovaps xmm15, [rsp+0xE0]
0000707649fd9cce  add rsp, 0xF0
0000707649fd9cd5  pop r11
0000707649fd9cd7  pop r10
0000707649fd9cd9  pop r9
0000707649fd9cdb  pop r8
0000707649fd9cdd  pop rsi
0000707649fd9cde  pop rdi
0000707649fd9cdf  pop rdx
0000707649fd9ce0  pop rcx
0000707649fd9ce1  pop rax
0000707649fd9ce2  add rsp, 0x08
0000707649fd9ce6  jmp 0x0000707649FD636D
0000707649fd9ceb  sub rsp, 0x08
0000707649fd9cef  push rax
0000707649fd9cf0  push rcx
0000707649fd9cf1  push rdx
0000707649fd9cf2  push rdi
0000707649fd9cf3  push rsi
0000707649fd9cf4  push r8
0000707649fd9cf6  push r9
0000707649fd9cf8  push r10
0000707649fd9cfa  push r11
0000707649fd9cfc  sub rsp, 0xF0
0000707649fd9d03  vmovaps [rsp], xmm0
0000707649fd9d08  vmovaps [rsp+0x10], xmm1
0000707649fd9d0e  vmovaps [rsp+0x20], xmm2
0000707649fd9d14  vmovaps [rsp+0x30], xmm3
0000707649fd9d1a  vmovaps [rsp+0x40], xmm4
0000707649fd9d20  vmovaps [rsp+0x50], xmm5
0000707649fd9d26  vmovaps [rsp+0x60], xmm6
0000707649fd9d2c  vmovaps [rsp+0x70], xmm7
0000707649fd9d32  vmovaps [rsp+0x80], xmm8
0000707649fd9d3b  vmovaps [rsp+0x90], xmm9
0000707649fd9d44  vmovaps [rsp+0xA0], xmm11
0000707649fd9d4d  vmovaps [rsp+0xB0], xmm12
0000707649fd9d56  vmovaps [rsp+0xC0], xmm13
0000707649fd9d5f  vmovaps [rsp+0xD0], xmm14
0000707649fd9d68  vmovaps [rsp+0xE0], xmm15
0000707649fd9d71  sub rsp, 0x30
0000707649fd9d75  movaps [rsp], xmm10
0000707649fd9d7a  movaps [rsp+0x10], xmm14
0000707649fd9d80  movaps [rsp+0x20], xmm4
0000707649fd9d85  lea rdi, [rsp]
0000707649fd9d89  mov esi, 0x00
0000707649fd9d8e  mov rax, 0x59CB0B054530
0000707649fd9d98  call rax
0000707649fd9d9a  movaps xmm10, [rsp]
0000707649fd9d9f  add rsp, 0x30
0000707649fd9da3  vmovaps xmm0, [rsp]
0000707649fd9da8  vmovaps xmm1, [rsp+0x10]
0000707649fd9dae  vmovaps xmm2, [rsp+0x20]
0000707649fd9db4  vmovaps xmm3, [rsp+0x30]
0000707649fd9dba  vmovaps xmm4, [rsp+0x40]
0000707649fd9dc0  vmovaps xmm5, [rsp+0x50]
0000707649fd9dc6  vmovaps xmm6, [rsp+0x60]
0000707649fd9dcc  vmovaps xmm7, [rsp+0x70]
0000707649fd9dd2  vmovaps xmm8, [rsp+0x80]
0000707649fd9ddb  vmovaps xmm9, [rsp+0x90]
0000707649fd9de4  vmovaps xmm11, [rsp+0xA0]
0000707649fd9ded  vmovaps xmm12, [rsp+0xB0]
0000707649fd9df6  vmovaps xmm13, [rsp+0xC0]
0000707649fd9dff  vmovaps xmm14, [rsp+0xD0]
0000707649fd9e08  vmovaps xmm15, [rsp+0xE0]
0000707649fd9e11  add rsp, 0xF0
0000707649fd9e18  pop r11
0000707649fd9e1a  pop r10
0000707649fd9e1c  pop r9
0000707649fd9e1e  pop r8
0000707649fd9e20  pop rsi
0000707649fd9e21  pop rdi
0000707649fd9e22  pop rdx
0000707649fd9e23  pop rcx
0000707649fd9e24  pop rax
0000707649fd9e25  add rsp, 0x08
0000707649fd9e29  jmp 0x0000707649FD6388
0000707649fd9e2e  sub rsp, 0x08
0000707649fd9e32  push rax
0000707649fd9e33  push rcx
0000707649fd9e34  push rdx
0000707649fd9e35  push rdi
0000707649fd9e36  push rsi
0000707649fd9e37  push r8
0000707649fd9e39  push r9
0000707649fd9e3b  push r10
0000707649fd9e3d  push r11
0000707649fd9e3f  sub rsp, 0xF0
0000707649fd9e46  vmovaps [rsp], xmm0
0000707649fd9e4b  vmovaps [rsp+0x10], xmm1
0000707649fd9e51  vmovaps [rsp+0x20], xmm2
0000707649fd9e57  vmovaps [rsp+0x30], xmm3
0000707649fd9e5d  vmovaps [rsp+0x40], xmm4
0000707649fd9e63  vmovaps [rsp+0x50], xmm5
0000707649fd9e69  vmovaps [rsp+0x60], xmm6
0000707649fd9e6f  vmovaps [rsp+0x70], xmm7
0000707649fd9e75  vmovaps [rsp+0x80], xmm9
0000707649fd9e7e  vmovaps [rsp+0x90], xmm10
0000707649fd9e87  vmovaps [rsp+0xA0], xmm11
0000707649fd9e90  vmovaps [rsp+0xB0], xmm12
0000707649fd9e99  vmovaps [rsp+0xC0], xmm13
0000707649fd9ea2  vmovaps [rsp+0xD0], xmm14
0000707649fd9eab  vmovaps [rsp+0xE0], xmm15
0000707649fd9eb4  sub rsp, 0x30
0000707649fd9eb8  movaps [rsp], xmm8
0000707649fd9ebd  movaps [rsp+0x10], xmm1
0000707649fd9ec2  movaps [rsp+0x20], xmm14
0000707649fd9ec8  lea rdi, [rsp]
0000707649fd9ecc  mov esi, 0x00
0000707649fd9ed1  mov rax, 0x59CB0B054530
0000707649fd9edb  call rax
0000707649fd9edd  movaps xmm8, [rsp]
0000707649fd9ee2  add rsp, 0x30
0000707649fd9ee6  vmovaps xmm0, [rsp]
0000707649fd9eeb  vmovaps xmm1, [rsp+0x10]
0000707649fd9ef1  vmovaps xmm2, [rsp+0x20]
0000707649fd9ef7  vmovaps xmm3, [rsp+0x30]
0000707649fd9efd  vmovaps xmm4, [rsp+0x40]
0000707649fd9f03  vmovaps xmm5, [rsp+0x50]
0000707649fd9f09  vmovaps xmm6, [rsp+0x60]
0000707649fd9f0f  vmovaps xmm7, [rsp+0x70]
0000707649fd9f15  vmovaps xmm9, [rsp+0x80]
0000707649fd9f1e  vmovaps xmm10, [rsp+0x90]
0000707649fd9f27  vmovaps xmm11, [rsp+0xA0]
0000707649fd9f30  vmovaps xmm12, [rsp+0xB0]
0000707649fd9f39  vmovaps xmm13, [rsp+0xC0]
0000707649fd9f42  vmovaps xmm14, [rsp+0xD0]
0000707649fd9f4b  vmovaps xmm15, [rsp+0xE0]
0000707649fd9f54  add rsp, 0xF0
0000707649fd9f5b  pop r11
0000707649fd9f5d  pop r10
0000707649fd9f5f  pop r9
0000707649fd9f61  pop r8
0000707649fd9f63  pop rsi
0000707649fd9f64  pop rdi
0000707649fd9f65  pop rdx
0000707649fd9f66  pop rcx
0000707649fd9f67  pop rax
0000707649fd9f68  add rsp, 0x08
0000707649fd9f6c  jmp 0x0000707649FD63AE
0000707649fd9f71  sub rsp, 0x08
0000707649fd9f75  push rax
0000707649fd9f76  push rcx
0000707649fd9f77  push rdx
0000707649fd9f78  push rdi
0000707649fd9f79  push rsi
0000707649fd9f7a  push r8
0000707649fd9f7c  push r9
0000707649fd9f7e  push r10
0000707649fd9f80  push r11
0000707649fd9f82  sub rsp, 0xF0
0000707649fd9f89  vmovaps [rsp], xmm0
0000707649fd9f8e  vmovaps [rsp+0x10], xmm1
0000707649fd9f94  vmovaps [rsp+0x20], xmm2
0000707649fd9f9a  vmovaps [rsp+0x30], xmm3
0000707649fd9fa0  vmovaps [rsp+0x40], xmm4
0000707649fd9fa6  vmovaps [rsp+0x50], xmm5
0000707649fd9fac  vmovaps [rsp+0x60], xmm7
0000707649fd9fb2  vmovaps [rsp+0x70], xmm8
0000707649fd9fb8  vmovaps [rsp+0x80], xmm9
0000707649fd9fc1  vmovaps [rsp+0x90], xmm10
0000707649fd9fca  vmovaps [rsp+0xA0], xmm11
0000707649fd9fd3  vmovaps [rsp+0xB0], xmm12
0000707649fd9fdc  vmovaps [rsp+0xC0], xmm13
0000707649fd9fe5  vmovaps [rsp+0xD0], xmm14
0000707649fd9fee  vmovaps [rsp+0xE0], xmm15
0000707649fd9ff7  sub rsp, 0x30
0000707649fd9ffb  movaps [rsp], xmm6
0000707649fd9fff  movaps [rsp+0x10], xmm1
0000707649fda004  movaps [rsp+0x20], xmm14
0000707649fda00a  lea rdi, [rsp]
0000707649fda00e  mov esi, 0x00
0000707649fda013  mov rax, 0x59CB0B054530
0000707649fda01d  call rax
0000707649fda01f  movaps xmm6, [rsp]
0000707649fda023  add rsp, 0x30
0000707649fda027  vmovaps xmm0, [rsp]
0000707649fda02c  vmovaps xmm1, [rsp+0x10]
0000707649fda032  vmovaps xmm2, [rsp+0x20]
0000707649fda038  vmovaps xmm3, [rsp+0x30]
0000707649fda03e  vmovaps xmm4, [rsp+0x40]
0000707649fda044  vmovaps xmm5, [rsp+0x50]
0000707649fda04a  vmovaps xmm7, [rsp+0x60]
0000707649fda050  vmovaps xmm8, [rsp+0x70]
0000707649fda056  vmovaps xmm9, [rsp+0x80]
0000707649fda05f  vmovaps xmm10, [rsp+0x90]
0000707649fda068  vmovaps xmm11, [rsp+0xA0]
0000707649fda071  vmovaps xmm12, [rsp+0xB0]
0000707649fda07a  vmovaps xmm13, [rsp+0xC0]
0000707649fda083  vmovaps xmm14, [rsp+0xD0]
0000707649fda08c  vmovaps xmm15, [rsp+0xE0]
0000707649fda095  add rsp, 0xF0
0000707649fda09c  pop r11
0000707649fda09e  pop r10
0000707649fda0a0  pop r9
0000707649fda0a2  pop r8
0000707649fda0a4  pop rsi
0000707649fda0a5  pop rdi
0000707649fda0a6  pop rdx
0000707649fda0a7  pop rcx
0000707649fda0a8  pop rax
0000707649fda0a9  add rsp, 0x08
0000707649fda0ad  jmp 0x0000707649FD63DA
0000707649fda0b2  sub rsp, 0x08
0000707649fda0b6  push rax
0000707649fda0b7  push rcx
0000707649fda0b8  push rdx
0000707649fda0b9  push rdi
0000707649fda0ba  push rsi
0000707649fda0bb  push r8
0000707649fda0bd  push r9
0000707649fda0bf  push r10
0000707649fda0c1  push r11
0000707649fda0c3  sub rsp, 0xF0
0000707649fda0ca  vmovaps [rsp], xmm0
0000707649fda0cf  vmovaps [rsp+0x10], xmm1
0000707649fda0d5  vmovaps [rsp+0x20], xmm2
0000707649fda0db  vmovaps [rsp+0x30], xmm3
0000707649fda0e1  vmovaps [rsp+0x40], xmm4
0000707649fda0e7  vmovaps [rsp+0x50], xmm5
0000707649fda0ed  vmovaps [rsp+0x60], xmm6
0000707649fda0f3  vmovaps [rsp+0x70], xmm7
0000707649fda0f9  vmovaps [rsp+0x80], xmm8
0000707649fda102  vmovaps [rsp+0x90], xmm9
0000707649fda10b  vmovaps [rsp+0xA0], xmm10
0000707649fda114  vmovaps [rsp+0xB0], xmm11
0000707649fda11d  vmovaps [rsp+0xC0], xmm12
0000707649fda126  vmovaps [rsp+0xD0], xmm13
0000707649fda12f  vmovaps [rsp+0xE0], xmm15
0000707649fda138  sub rsp, 0x30
0000707649fda13c  movaps [rsp], xmm14
0000707649fda141  movaps [rsp+0x10], xmm12
0000707649fda147  movaps [rsp+0x20], xmm1
0000707649fda14c  lea rdi, [rsp]
0000707649fda150  mov esi, 0x00
0000707649fda155  mov rax, 0x59CB0B054530
0000707649fda15f  call rax
0000707649fda161  movaps xmm14, [rsp]
0000707649fda166  add rsp, 0x30
0000707649fda16a  vmovaps xmm0, [rsp]
0000707649fda16f  vmovaps xmm1, [rsp+0x10]
0000707649fda175  vmovaps xmm2, [rsp+0x20]
0000707649fda17b  vmovaps xmm3, [rsp+0x30]
0000707649fda181  vmovaps xmm4, [rsp+0x40]
0000707649fda187  vmovaps xmm5, [rsp+0x50]
0000707649fda18d  vmovaps xmm6, [rsp+0x60]
0000707649fda193  vmovaps xmm7, [rsp+0x70]
0000707649fda199  vmovaps xmm8, [rsp+0x80]
0000707649fda1a2  vmovaps xmm9, [rsp+0x90]
0000707649fda1ab  vmovaps xmm10, [rsp+0xA0]
0000707649fda1b4  vmovaps xmm11, [rsp+0xB0]
0000707649fda1bd  vmovaps xmm12, [rsp+0xC0]
0000707649fda1c6  vmovaps xmm13, [rsp+0xD0]
0000707649fda1cf  vmovaps xmm15, [rsp+0xE0]
0000707649fda1d8  add rsp, 0xF0
0000707649fda1df  pop r11
0000707649fda1e1  pop r10
0000707649fda1e3  pop r9
0000707649fda1e5  pop r8
0000707649fda1e7  pop rsi
0000707649fda1e8  pop rdi
0000707649fda1e9  pop rdx
0000707649fda1ea  pop rcx
0000707649fda1eb  pop rax
0000707649fda1ec  add rsp, 0x08
0000707649fda1f0  jmp 0x0000707649FD6400
0000707649fda1f5  sub rsp, 0x08
0000707649fda1f9  push rax
0000707649fda1fa  push rcx
0000707649fda1fb  push rdx
0000707649fda1fc  push rdi
0000707649fda1fd  push rsi
0000707649fda1fe  push r8
0000707649fda200  push r9
0000707649fda202  push r10
0000707649fda204  push r11
0000707649fda206  sub rsp, 0xF0
0000707649fda20d  vmovaps [rsp], xmm0
0000707649fda212  vmovaps [rsp+0x10], xmm2
0000707649fda218  vmovaps [rsp+0x20], xmm3
0000707649fda21e  vmovaps [rsp+0x30], xmm4
0000707649fda224  vmovaps [rsp+0x40], xmm5
0000707649fda22a  vmovaps [rsp+0x50], xmm6
0000707649fda230  vmovaps [rsp+0x60], xmm7
0000707649fda236  vmovaps [rsp+0x70], xmm8
0000707649fda23c  vmovaps [rsp+0x80], xmm9
0000707649fda245  vmovaps [rsp+0x90], xmm10
0000707649fda24e  vmovaps [rsp+0xA0], xmm11
0000707649fda257  vmovaps [rsp+0xB0], xmm12
0000707649fda260  vmovaps [rsp+0xC0], xmm13
0000707649fda269  vmovaps [rsp+0xD0], xmm14
0000707649fda272  vmovaps [rsp+0xE0], xmm15
0000707649fda27b  sub rsp, 0x30
0000707649fda27f  movaps [rsp], xmm1
0000707649fda283  movaps [rsp+0x10], xmm13
0000707649fda289  movaps [rsp+0x20], xmm9
0000707649fda28f  lea rdi, [rsp]
0000707649fda293  mov esi, 0x00
0000707649fda298  mov rax, 0x59CB0B054530
0000707649fda2a2  call rax
0000707649fda2a4  movaps xmm1, [rsp]
0000707649fda2a8  add rsp, 0x30
0000707649fda2ac  vmovaps xmm0, [rsp]
0000707649fda2b1  vmovaps xmm2, [rsp+0x10]
0000707649fda2b7  vmovaps xmm3, [rsp+0x20]
0000707649fda2bd  vmovaps xmm4, [rsp+0x30]
0000707649fda2c3  vmovaps xmm5, [rsp+0x40]
0000707649fda2c9  vmovaps xmm6, [rsp+0x50]
0000707649fda2cf  vmovaps xmm7, [rsp+0x60]
0000707649fda2d5  vmovaps xmm8, [rsp+0x70]
0000707649fda2db  vmovaps xmm9, [rsp+0x80]
0000707649fda2e4  vmovaps xmm10, [rsp+0x90]
0000707649fda2ed  vmovaps xmm11, [rsp+0xA0]
0000707649fda2f6  vmovaps xmm12, [rsp+0xB0]
0000707649fda2ff  vmovaps xmm13, [rsp+0xC0]
0000707649fda308  vmovaps xmm14, [rsp+0xD0]
0000707649fda311  vmovaps xmm15, [rsp+0xE0]
0000707649fda31a  add rsp, 0xF0
0000707649fda321  pop r11
0000707649fda323  pop r10
0000707649fda325  pop r9
0000707649fda327  pop r8
0000707649fda329  pop rsi
0000707649fda32a  pop rdi
0000707649fda32b  pop rdx
0000707649fda32c  pop rcx
0000707649fda32d  pop rax
0000707649fda32e  add rsp, 0x08
0000707649fda332  jmp 0x0000707649FD641A
0000707649fda337  sub rsp, 0x08
0000707649fda33b  push rax
0000707649fda33c  push rcx
0000707649fda33d  push rdx
0000707649fda33e  push rdi
0000707649fda33f  push rsi
0000707649fda340  push r8
0000707649fda342  push r9
0000707649fda344  push r10
0000707649fda346  push r11
0000707649fda348  sub rsp, 0xF0
0000707649fda34f  vmovaps [rsp], xmm0
0000707649fda354  vmovaps [rsp+0x10], xmm1
0000707649fda35a  vmovaps [rsp+0x20], xmm2
0000707649fda360  vmovaps [rsp+0x30], xmm3
0000707649fda366  vmovaps [rsp+0x40], xmm4
0000707649fda36c  vmovaps [rsp+0x50], xmm5
0000707649fda372  vmovaps [rsp+0x60], xmm6
0000707649fda378  vmovaps [rsp+0x70], xmm7
0000707649fda37e  vmovaps [rsp+0x80], xmm8
0000707649fda387  vmovaps [rsp+0x90], xmm9
0000707649fda390  vmovaps [rsp+0xA0], xmm10
0000707649fda399  vmovaps [rsp+0xB0], xmm11
0000707649fda3a2  vmovaps [rsp+0xC0], xmm13
0000707649fda3ab  vmovaps [rsp+0xD0], xmm14
0000707649fda3b4  vmovaps [rsp+0xE0], xmm15
0000707649fda3bd  sub rsp, 0x30
0000707649fda3c1  movaps [rsp], xmm12
0000707649fda3c6  movaps [rsp+0x10], xmm7
0000707649fda3cb  movaps [rsp+0x20], xmm13
0000707649fda3d1  lea rdi, [rsp]
0000707649fda3d5  mov esi, 0x00
0000707649fda3da  mov rax, 0x59CB0B054530
0000707649fda3e4  call rax
0000707649fda3e6  movaps xmm12, [rsp]
0000707649fda3eb  add rsp, 0x30
0000707649fda3ef  vmovaps xmm0, [rsp]
0000707649fda3f4  vmovaps xmm1, [rsp+0x10]
0000707649fda3fa  vmovaps xmm2, [rsp+0x20]
0000707649fda400  vmovaps xmm3, [rsp+0x30]
0000707649fda406  vmovaps xmm4, [rsp+0x40]
0000707649fda40c  vmovaps xmm5, [rsp+0x50]
0000707649fda412  vmovaps xmm6, [rsp+0x60]
0000707649fda418  vmovaps xmm7, [rsp+0x70]
0000707649fda41e  vmovaps xmm8, [rsp+0x80]
0000707649fda427  vmovaps xmm9, [rsp+0x90]
0000707649fda430  vmovaps xmm10, [rsp+0xA0]
0000707649fda439  vmovaps xmm11, [rsp+0xB0]
0000707649fda442  vmovaps xmm13, [rsp+0xC0]
0000707649fda44b  vmovaps xmm14, [rsp+0xD0]
0000707649fda454  vmovaps xmm15, [rsp+0xE0]
0000707649fda45d  add rsp, 0xF0
0000707649fda464  pop r11
0000707649fda466  pop r10
0000707649fda468  pop r9
0000707649fda46a  pop r8
0000707649fda46c  pop rsi
0000707649fda46d  pop rdi
0000707649fda46e  pop rdx
0000707649fda46f  pop rcx
0000707649fda470  pop rax
0000707649fda471  add rsp, 0x08
0000707649fda475  jmp 0x0000707649FD6441
0000707649fda47a  sub rsp, 0x08
0000707649fda47e  push rax
0000707649fda47f  push rcx
0000707649fda480  push rdx
0000707649fda481  push rdi
0000707649fda482  push rsi
0000707649fda483  push r8
0000707649fda485  push r9
0000707649fda487  push r10
0000707649fda489  push r11
0000707649fda48b  sub rsp, 0xF0
0000707649fda492  vmovaps [rsp], xmm0
0000707649fda497  vmovaps [rsp+0x10], xmm1
0000707649fda49d  vmovaps [rsp+0x20], xmm2
0000707649fda4a3  vmovaps [rsp+0x30], xmm3
0000707649fda4a9  vmovaps [rsp+0x40], xmm4
0000707649fda4af  vmovaps [rsp+0x50], xmm5
0000707649fda4b5  vmovaps [rsp+0x60], xmm6
0000707649fda4bb  vmovaps [rsp+0x70], xmm7
0000707649fda4c1  vmovaps [rsp+0x80], xmm8
0000707649fda4ca  vmovaps [rsp+0x90], xmm9
0000707649fda4d3  vmovaps [rsp+0xA0], xmm10
0000707649fda4dc  vmovaps [rsp+0xB0], xmm11
0000707649fda4e5  vmovaps [rsp+0xC0], xmm12
0000707649fda4ee  vmovaps [rsp+0xD0], xmm14
0000707649fda4f7  vmovaps [rsp+0xE0], xmm15
0000707649fda500  sub rsp, 0x30
0000707649fda504  movaps [rsp], xmm13
0000707649fda509  movaps [rsp+0x10], xmm15
0000707649fda50f  movaps [rsp+0x20], xmm8
0000707649fda515  lea rdi, [rsp]
0000707649fda519  mov esi, 0x00
0000707649fda51e  mov rax, 0x59CB0B054530
0000707649fda528  call rax
0000707649fda52a  movaps xmm13, [rsp]
0000707649fda52f  add rsp, 0x30
0000707649fda533  vmovaps xmm0, [rsp]
0000707649fda538  vmovaps xmm1, [rsp+0x10]
0000707649fda53e  vmovaps xmm2, [rsp+0x20]
0000707649fda544  vmovaps xmm3, [rsp+0x30]
0000707649fda54a  vmovaps xmm4, [rsp+0x40]
0000707649fda550  vmovaps xmm5, [rsp+0x50]
0000707649fda556  vmovaps xmm6, [rsp+0x60]
0000707649fda55c  vmovaps xmm7, [rsp+0x70]
0000707649fda562  vmovaps xmm8, [rsp+0x80]
0000707649fda56b  vmovaps xmm9, [rsp+0x90]
0000707649fda574  vmovaps xmm10, [rsp+0xA0]
0000707649fda57d  vmovaps xmm11, [rsp+0xB0]
0000707649fda586  vmovaps xmm12, [rsp+0xC0]
0000707649fda58f  vmovaps xmm14, [rsp+0xD0]
0000707649fda598  vmovaps xmm15, [rsp+0xE0]
0000707649fda5a1  add rsp, 0xF0
0000707649fda5a8  pop r11
0000707649fda5aa  pop r10
0000707649fda5ac  pop r9
0000707649fda5ae  pop r8
0000707649fda5b0  pop rsi
0000707649fda5b1  pop rdi
0000707649fda5b2  pop rdx
0000707649fda5b3  pop rcx
0000707649fda5b4  pop rax
0000707649fda5b5  add rsp, 0x08
0000707649fda5b9  jmp 0x0000707649FD645C
0000707649fda5be  sub rsp, 0x08
0000707649fda5c2  push rax
0000707649fda5c3  push rcx
0000707649fda5c4  push rdx
0000707649fda5c5  push rdi
0000707649fda5c6  push rsi
0000707649fda5c7  push r8
0000707649fda5c9  push r9
0000707649fda5cb  push r10
0000707649fda5cd  push r11
0000707649fda5cf  sub rsp, 0xF0
0000707649fda5d6  vmovaps [rsp], xmm0
0000707649fda5db  vmovaps [rsp+0x10], xmm1
0000707649fda5e1  vmovaps [rsp+0x20], xmm2
0000707649fda5e7  vmovaps [rsp+0x30], xmm3
0000707649fda5ed  vmovaps [rsp+0x40], xmm4
0000707649fda5f3  vmovaps [rsp+0x50], xmm5
0000707649fda5f9  vmovaps [rsp+0x60], xmm6
0000707649fda5ff  vmovaps [rsp+0x70], xmm7
0000707649fda605  vmovaps [rsp+0x80], xmm9
0000707649fda60e  vmovaps [rsp+0x90], xmm10
0000707649fda617  vmovaps [rsp+0xA0], xmm11
0000707649fda620  vmovaps [rsp+0xB0], xmm12
0000707649fda629  vmovaps [rsp+0xC0], xmm13
0000707649fda632  vmovaps [rsp+0xD0], xmm14
0000707649fda63b  vmovaps [rsp+0xE0], xmm15
0000707649fda644  sub rsp, 0x30
0000707649fda648  movaps [rsp], xmm8
0000707649fda64d  movaps [rsp+0x10], xmm15
0000707649fda653  movaps [rsp+0x20], xmm9
0000707649fda659  lea rdi, [rsp]
0000707649fda65d  mov esi, 0x00
0000707649fda662  mov rax, 0x59CB0B054530
0000707649fda66c  call rax
0000707649fda66e  movaps xmm8, [rsp]
0000707649fda673  add rsp, 0x30
0000707649fda677  vmovaps xmm0, [rsp]
0000707649fda67c  vmovaps xmm1, [rsp+0x10]
0000707649fda682  vmovaps xmm2, [rsp+0x20]
0000707649fda688  vmovaps xmm3, [rsp+0x30]
0000707649fda68e  vmovaps xmm4, [rsp+0x40]
0000707649fda694  vmovaps xmm5, [rsp+0x50]
0000707649fda69a  vmovaps xmm6, [rsp+0x60]
0000707649fda6a0  vmovaps xmm7, [rsp+0x70]
0000707649fda6a6  vmovaps xmm9, [rsp+0x80]
0000707649fda6af  vmovaps xmm10, [rsp+0x90]
0000707649fda6b8  vmovaps xmm11, [rsp+0xA0]
0000707649fda6c1  vmovaps xmm12, [rsp+0xB0]
0000707649fda6ca  vmovaps xmm13, [rsp+0xC0]
0000707649fda6d3  vmovaps xmm14, [rsp+0xD0]
0000707649fda6dc  vmovaps xmm15, [rsp+0xE0]
0000707649fda6e5  add rsp, 0xF0
0000707649fda6ec  pop r11
0000707649fda6ee  pop r10
0000707649fda6f0  pop r9
0000707649fda6f2  pop r8
0000707649fda6f4  pop rsi
0000707649fda6f5  pop rdi
0000707649fda6f6  pop rdx
0000707649fda6f7  pop rcx
0000707649fda6f8  pop rax
0000707649fda6f9  add rsp, 0x08
0000707649fda6fd  jmp 0x0000707649FD648A
0000707649fda702  sub rsp, 0x08
0000707649fda706  push rax
0000707649fda707  push rcx
0000707649fda708  push rdx
0000707649fda709  push rdi
0000707649fda70a  push rsi
0000707649fda70b  push r8
0000707649fda70d  push r9
0000707649fda70f  push r10
0000707649fda711  push r11
0000707649fda713  sub rsp, 0xF0
0000707649fda71a  vmovaps [rsp], xmm0
0000707649fda71f  vmovaps [rsp+0x10], xmm1
0000707649fda725  vmovaps [rsp+0x20], xmm2
0000707649fda72b  vmovaps [rsp+0x30], xmm3
0000707649fda731  vmovaps [rsp+0x40], xmm4
0000707649fda737  vmovaps [rsp+0x50], xmm5
0000707649fda73d  vmovaps [rsp+0x60], xmm6
0000707649fda743  vmovaps [rsp+0x70], xmm7
0000707649fda749  vmovaps [rsp+0x80], xmm8
0000707649fda752  vmovaps [rsp+0x90], xmm9
0000707649fda75b  vmovaps [rsp+0xA0], xmm10
0000707649fda764  vmovaps [rsp+0xB0], xmm11
0000707649fda76d  vmovaps [rsp+0xC0], xmm12
0000707649fda776  vmovaps [rsp+0xD0], xmm13
0000707649fda77f  vmovaps [rsp+0xE0], xmm14
0000707649fda788  sub rsp, 0x30
0000707649fda78c  movaps [rsp], xmm15
0000707649fda791  movaps [rsp+0x10], xmm11
0000707649fda797  movaps [rsp+0x20], xmm6
0000707649fda79c  lea rdi, [rsp]
0000707649fda7a0  mov esi, 0x00
0000707649fda7a5  mov rax, 0x59CB0B054530
0000707649fda7af  call rax
0000707649fda7b1  movaps xmm15, [rsp]
0000707649fda7b6  add rsp, 0x30
0000707649fda7ba  vmovaps xmm0, [rsp]
0000707649fda7bf  vmovaps xmm1, [rsp+0x10]
0000707649fda7c5  vmovaps xmm2, [rsp+0x20]
0000707649fda7cb  vmovaps xmm3, [rsp+0x30]
0000707649fda7d1  vmovaps xmm4, [rsp+0x40]
0000707649fda7d7  vmovaps xmm5, [rsp+0x50]
0000707649fda7dd  vmovaps xmm6, [rsp+0x60]
0000707649fda7e3  vmovaps xmm7, [rsp+0x70]
0000707649fda7e9  vmovaps xmm8, [rsp+0x80]
0000707649fda7f2  vmovaps xmm9, [rsp+0x90]
0000707649fda7fb  vmovaps xmm10, [rsp+0xA0]
0000707649fda804  vmovaps xmm11, [rsp+0xB0]
0000707649fda80d  vmovaps xmm12, [rsp+0xC0]
0000707649fda816  vmovaps xmm13, [rsp+0xD0]
0000707649fda81f  vmovaps xmm14, [rsp+0xE0]
0000707649fda828  add rsp, 0xF0
0000707649fda82f  pop r11
0000707649fda831  pop r10
0000707649fda833  pop r9
0000707649fda835  pop r8
0000707649fda837  pop rsi
0000707649fda838  pop rdi
0000707649fda839  pop rdx
0000707649fda83a  pop rcx
0000707649fda83b  pop rax
0000707649fda83c  add rsp, 0x08
0000707649fda840  jmp 0x0000707649FD64A5
0000707649fda845  sub rsp, 0x08
0000707649fda849  push rax
0000707649fda84a  push rcx
0000707649fda84b  push rdx
0000707649fda84c  push rdi
0000707649fda84d  push rsi
0000707649fda84e  push r8
0000707649fda850  push r9
0000707649fda852  push r10
0000707649fda854  push r11
0000707649fda856  sub rsp, 0xF0
0000707649fda85d  vmovaps [rsp], xmm0
0000707649fda862  vmovaps [rsp+0x10], xmm1
0000707649fda868  vmovaps [rsp+0x20], xmm2
0000707649fda86e  vmovaps [rsp+0x30], xmm3
0000707649fda874  vmovaps [rsp+0x40], xmm4
0000707649fda87a  vmovaps [rsp+0x50], xmm5
0000707649fda880  vmovaps [rsp+0x60], xmm6
0000707649fda886  vmovaps [rsp+0x70], xmm8
0000707649fda88c  vmovaps [rsp+0x80], xmm9
0000707649fda895  vmovaps [rsp+0x90], xmm10
0000707649fda89e  vmovaps [rsp+0xA0], xmm11
0000707649fda8a7  vmovaps [rsp+0xB0], xmm12
0000707649fda8b0  vmovaps [rsp+0xC0], xmm13
0000707649fda8b9  vmovaps [rsp+0xD0], xmm14
0000707649fda8c2  vmovaps [rsp+0xE0], xmm15
0000707649fda8cb  sub rsp, 0x30
0000707649fda8cf  movaps [rsp], xmm7
0000707649fda8d3  movaps [rsp+0x10], xmm11
0000707649fda8d9  movaps [rsp+0x20], xmm9
0000707649fda8df  lea rdi, [rsp]
0000707649fda8e3  mov esi, 0x00
0000707649fda8e8  mov rax, 0x59CB0B054530
0000707649fda8f2  call rax
0000707649fda8f4  movaps xmm7, [rsp]
0000707649fda8f8  add rsp, 0x30
0000707649fda8fc  vmovaps xmm0, [rsp]
0000707649fda901  vmovaps xmm1, [rsp+0x10]
0000707649fda907  vmovaps xmm2, [rsp+0x20]
0000707649fda90d  vmovaps xmm3, [rsp+0x30]
0000707649fda913  vmovaps xmm4, [rsp+0x40]
0000707649fda919  vmovaps xmm5, [rsp+0x50]
0000707649fda91f  vmovaps xmm6, [rsp+0x60]
0000707649fda925  vmovaps xmm8, [rsp+0x70]
0000707649fda92b  vmovaps xmm9, [rsp+0x80]
0000707649fda934  vmovaps xmm10, [rsp+0x90]
0000707649fda93d  vmovaps xmm11, [rsp+0xA0]
0000707649fda946  vmovaps xmm12, [rsp+0xB0]
0000707649fda94f  vmovaps xmm13, [rsp+0xC0]
0000707649fda958  vmovaps xmm14, [rsp+0xD0]
0000707649fda961  vmovaps xmm15, [rsp+0xE0]
0000707649fda96a  add rsp, 0xF0
0000707649fda971  pop r11
0000707649fda973  pop r10
0000707649fda975  pop r9
0000707649fda977  pop r8
0000707649fda979  pop rsi
0000707649fda97a  pop rdi
0000707649fda97b  pop rdx
0000707649fda97c  pop rcx
0000707649fda97d  pop rax
0000707649fda97e  add rsp, 0x08
0000707649fda982  jmp 0x0000707649FD64D2
0000707649fda987  sub rsp, 0x08
0000707649fda98b  push rax
0000707649fda98c  push rcx
0000707649fda98d  push rdx
0000707649fda98e  push rdi
0000707649fda98f  push rsi
0000707649fda990  push r8
0000707649fda992  push r9
0000707649fda994  push r10
0000707649fda996  push r11
0000707649fda998  sub rsp, 0xF0
0000707649fda99f  vmovaps [rsp], xmm0
0000707649fda9a4  vmovaps [rsp+0x10], xmm1
0000707649fda9aa  vmovaps [rsp+0x20], xmm2
0000707649fda9b0  vmovaps [rsp+0x30], xmm3
0000707649fda9b6  vmovaps [rsp+0x40], xmm4
0000707649fda9bc  vmovaps [rsp+0x50], xmm5
0000707649fda9c2  vmovaps [rsp+0x60], xmm6
0000707649fda9c8  vmovaps [rsp+0x70], xmm7
0000707649fda9ce  vmovaps [rsp+0x80], xmm8
0000707649fda9d7  vmovaps [rsp+0x90], xmm9
0000707649fda9e0  vmovaps [rsp+0xA0], xmm10
0000707649fda9e9  vmovaps [rsp+0xB0], xmm12
0000707649fda9f2  vmovaps [rsp+0xC0], xmm13
0000707649fda9fb  vmovaps [rsp+0xD0], xmm14
0000707649fdaa04  vmovaps [rsp+0xE0], xmm15
0000707649fdaa0d  sub rsp, 0x30
0000707649fdaa11  movaps [rsp], xmm11
0000707649fdaa16  movaps [rsp+0x10], xmm10
0000707649fdaa1c  movaps [rsp+0x20], xmm14
0000707649fdaa22  lea rdi, [rsp]
0000707649fdaa26  mov esi, 0x00
0000707649fdaa2b  mov rax, 0x59CB0B054530
0000707649fdaa35  call rax
0000707649fdaa37  movaps xmm11, [rsp]
0000707649fdaa3c  add rsp, 0x30
0000707649fdaa40  vmovaps xmm0, [rsp]
0000707649fdaa45  vmovaps xmm1, [rsp+0x10]
0000707649fdaa4b  vmovaps xmm2, [rsp+0x20]
0000707649fdaa51  vmovaps xmm3, [rsp+0x30]
0000707649fdaa57  vmovaps xmm4, [rsp+0x40]
0000707649fdaa5d  vmovaps xmm5, [rsp+0x50]
0000707649fdaa63  vmovaps xmm6, [rsp+0x60]
0000707649fdaa69  vmovaps xmm7, [rsp+0x70]
0000707649fdaa6f  vmovaps xmm8, [rsp+0x80]
0000707649fdaa78  vmovaps xmm9, [rsp+0x90]
0000707649fdaa81  vmovaps xmm10, [rsp+0xA0]
0000707649fdaa8a  vmovaps xmm12, [rsp+0xB0]
0000707649fdaa93  vmovaps xmm13, [rsp+0xC0]
0000707649fdaa9c  vmovaps xmm14, [rsp+0xD0]
0000707649fdaaa5  vmovaps xmm15, [rsp+0xE0]
0000707649fdaaae  add rsp, 0xF0
0000707649fdaab5  pop r11
0000707649fdaab7  pop r10
0000707649fdaab9  pop r9
0000707649fdaabb  pop r8
0000707649fdaabd  pop rsi
0000707649fdaabe  pop rdi
0000707649fdaabf  pop rdx
0000707649fdaac0  pop rcx
0000707649fdaac1  pop rax
0000707649fdaac2  add rsp, 0x08
0000707649fdaac6  jmp 0x0000707649FD64ED
0000707649fdaacb  call 0x0000707649EE45A0
0000707649fdaad0  jmp 0x0000707649FD64F7
0000707649fdaad5  sub rsp, 0x08
0000707649fdaad9  push rax
0000707649fdaada  push rcx
0000707649fdaadb  push rdx
0000707649fdaadc  push rdi
0000707649fdaadd  push rsi
0000707649fdaade  push r8
0000707649fdaae0  push r9
0000707649fdaae2  push r10
0000707649fdaae4  push r11
0000707649fdaae6  sub rsp, 0xF0
0000707649fdaaed  vmovaps [rsp], xmm0
0000707649fdaaf2  vmovaps [rsp+0x10], xmm1
0000707649fdaaf8  vmovaps [rsp+0x20], xmm2
0000707649fdaafe  vmovaps [rsp+0x30], xmm3
0000707649fdab04  vmovaps [rsp+0x40], xmm4
0000707649fdab0a  vmovaps [rsp+0x50], xmm5
0000707649fdab10  vmovaps [rsp+0x60], xmm6
0000707649fdab16  vmovaps [rsp+0x70], xmm7
0000707649fdab1c  vmovaps [rsp+0x80], xmm8
0000707649fdab25  vmovaps [rsp+0x90], xmm9
0000707649fdab2e  vmovaps [rsp+0xA0], xmm11
0000707649fdab37  vmovaps [rsp+0xB0], xmm12
0000707649fdab40  vmovaps [rsp+0xC0], xmm13
0000707649fdab49  vmovaps [rsp+0xD0], xmm14
0000707649fdab52  vmovaps [rsp+0xE0], xmm15
0000707649fdab5b  sub rsp, 0x30
0000707649fdab5f  movaps [rsp], xmm10
0000707649fdab64  movaps [rsp+0x10], xmm1
0000707649fdab69  movaps [rsp+0x20], xmm12
0000707649fdab6f  lea rdi, [rsp]
0000707649fdab73  mov esi, 0x00
0000707649fdab78  mov rax, 0x59CB0B054530
0000707649fdab82  call rax
0000707649fdab84  movaps xmm10, [rsp]
0000707649fdab89  add rsp, 0x30
0000707649fdab8d  vmovaps xmm0, [rsp]
0000707649fdab92  vmovaps xmm1, [rsp+0x10]
0000707649fdab98  vmovaps xmm2, [rsp+0x20]
0000707649fdab9e  vmovaps xmm3, [rsp+0x30]
0000707649fdaba4  vmovaps xmm4, [rsp+0x40]
0000707649fdabaa  vmovaps xmm5, [rsp+0x50]
0000707649fdabb0  vmovaps xmm6, [rsp+0x60]
0000707649fdabb6  vmovaps xmm7, [rsp+0x70]
0000707649fdabbc  vmovaps xmm8, [rsp+0x80]
0000707649fdabc5  vmovaps xmm9, [rsp+0x90]
0000707649fdabce  vmovaps xmm11, [rsp+0xA0]
0000707649fdabd7  vmovaps xmm12, [rsp+0xB0]
0000707649fdabe0  vmovaps xmm13, [rsp+0xC0]
0000707649fdabe9  vmovaps xmm14, [rsp+0xD0]
0000707649fdabf2  vmovaps xmm15, [rsp+0xE0]
0000707649fdabfb  add rsp, 0xF0
0000707649fdac02  pop r11
0000707649fdac04  pop r10
0000707649fdac06  pop r9
0000707649fdac08  pop r8
0000707649fdac0a  pop rsi
0000707649fdac0b  pop rdi
0000707649fdac0c  pop rdx
0000707649fdac0d  pop rcx
0000707649fdac0e  pop rax
0000707649fdac0f  add rsp, 0x08
0000707649fdac13  jmp 0x0000707649FD651A
0000707649fdac18  sub rsp, 0x08
0000707649fdac1c  push rax
0000707649fdac1d  push rcx
0000707649fdac1e  push rdx
0000707649fdac1f  push rdi
0000707649fdac20  push rsi
0000707649fdac21  push r8
0000707649fdac23  push r9
0000707649fdac25  push r10
0000707649fdac27  push r11
0000707649fdac29  sub rsp, 0xF0
0000707649fdac30  vmovaps [rsp], xmm0
0000707649fdac35  vmovaps [rsp+0x10], xmm1
0000707649fdac3b  vmovaps [rsp+0x20], xmm2
0000707649fdac41  vmovaps [rsp+0x30], xmm3
0000707649fdac47  vmovaps [rsp+0x40], xmm4
0000707649fdac4d  vmovaps [rsp+0x50], xmm5
0000707649fdac53  vmovaps [rsp+0x60], xmm6
0000707649fdac59  vmovaps [rsp+0x70], xmm7
0000707649fdac5f  vmovaps [rsp+0x80], xmm8
0000707649fdac68  vmovaps [rsp+0x90], xmm9
0000707649fdac71  vmovaps [rsp+0xA0], xmm10
0000707649fdac7a  vmovaps [rsp+0xB0], xmm11
0000707649fdac83  vmovaps [rsp+0xC0], xmm13
0000707649fdac8c  vmovaps [rsp+0xD0], xmm14
0000707649fdac95  vmovaps [rsp+0xE0], xmm15
0000707649fdac9e  sub rsp, 0x30
0000707649fdaca2  movaps [rsp], xmm12
0000707649fdaca7  movaps [rsp+0x10], xmm14
0000707649fdacad  movaps [rsp+0x20], xmm1
0000707649fdacb2  lea rdi, [rsp]
0000707649fdacb6  mov esi, 0x00
0000707649fdacbb  mov rax, 0x59CB0B054530
0000707649fdacc5  call rax
0000707649fdacc7  movaps xmm12, [rsp]
0000707649fdaccc  add rsp, 0x30
0000707649fdacd0  vmovaps xmm0, [rsp]
0000707649fdacd5  vmovaps xmm1, [rsp+0x10]
0000707649fdacdb  vmovaps xmm2, [rsp+0x20]
0000707649fdace1  vmovaps xmm3, [rsp+0x30]
0000707649fdace7  vmovaps xmm4, [rsp+0x40]
0000707649fdaced  vmovaps xmm5, [rsp+0x50]
0000707649fdacf3  vmovaps xmm6, [rsp+0x60]
0000707649fdacf9  vmovaps xmm7, [rsp+0x70]
0000707649fdacff  vmovaps xmm8, [rsp+0x80]
0000707649fdad08  vmovaps xmm9, [rsp+0x90]
0000707649fdad11  vmovaps xmm10, [rsp+0xA0]
0000707649fdad1a  vmovaps xmm11, [rsp+0xB0]
0000707649fdad23  vmovaps xmm13, [rsp+0xC0]
0000707649fdad2c  vmovaps xmm14, [rsp+0xD0]
0000707649fdad35  vmovaps xmm15, [rsp+0xE0]
0000707649fdad3e  add rsp, 0xF0
0000707649fdad45  pop r11
0000707649fdad47  pop r10
0000707649fdad49  pop r9
0000707649fdad4b  pop r8
0000707649fdad4d  pop rsi
0000707649fdad4e  pop rdi
0000707649fdad4f  pop rdx
0000707649fdad50  pop rcx
0000707649fdad51  pop rax
0000707649fdad52  add rsp, 0x08
0000707649fdad56  jmp 0x0000707649FD6549
0000707649fdad5b  sub rsp, 0x08
0000707649fdad5f  push rax
0000707649fdad60  push rcx
0000707649fdad61  push rdx
0000707649fdad62  push rdi
0000707649fdad63  push rsi
0000707649fdad64  push r8
0000707649fdad66  push r9
0000707649fdad68  push r10
0000707649fdad6a  push r11
0000707649fdad6c  sub rsp, 0xF0
0000707649fdad73  vmovaps [rsp], xmm0
0000707649fdad78  vmovaps [rsp+0x10], xmm1
0000707649fdad7e  vmovaps [rsp+0x20], xmm2
0000707649fdad84  vmovaps [rsp+0x30], xmm3
0000707649fdad8a  vmovaps [rsp+0x40], xmm4
0000707649fdad90  vmovaps [rsp+0x50], xmm5
0000707649fdad96  vmovaps [rsp+0x60], xmm6
0000707649fdad9c  vmovaps [rsp+0x70], xmm7
0000707649fdada2  vmovaps [rsp+0x80], xmm8
0000707649fdadab  vmovaps [rsp+0x90], xmm9
0000707649fdadb4  vmovaps [rsp+0xA0], xmm10
0000707649fdadbd  vmovaps [rsp+0xB0], xmm11
0000707649fdadc6  vmovaps [rsp+0xC0], xmm12
0000707649fdadcf  vmovaps [rsp+0xD0], xmm13
0000707649fdadd8  vmovaps [rsp+0xE0], xmm15
0000707649fdade1  sub rsp, 0x30
0000707649fdade5  movaps [rsp], xmm14
0000707649fdadea  movaps [rsp+0x10], xmm9
0000707649fdadf0  movaps [rsp+0x20], xmm1
0000707649fdadf5  lea rdi, [rsp]
0000707649fdadf9  mov esi, 0x00
0000707649fdadfe  mov rax, 0x59CB0B054530
0000707649fdae08  call rax
0000707649fdae0a  movaps xmm14, [rsp]
0000707649fdae0f  add rsp, 0x30
0000707649fdae13  vmovaps xmm0, [rsp]
0000707649fdae18  vmovaps xmm1, [rsp+0x10]
0000707649fdae1e  vmovaps xmm2, [rsp+0x20]
0000707649fdae24  vmovaps xmm3, [rsp+0x30]
0000707649fdae2a  vmovaps xmm4, [rsp+0x40]
0000707649fdae30  vmovaps xmm5, [rsp+0x50]
0000707649fdae36  vmovaps xmm6, [rsp+0x60]
0000707649fdae3c  vmovaps xmm7, [rsp+0x70]
0000707649fdae42  vmovaps xmm8, [rsp+0x80]
0000707649fdae4b  vmovaps xmm9, [rsp+0x90]
0000707649fdae54  vmovaps xmm10, [rsp+0xA0]
0000707649fdae5d  vmovaps xmm11, [rsp+0xB0]
0000707649fdae66  vmovaps xmm12, [rsp+0xC0]
0000707649fdae6f  vmovaps xmm13, [rsp+0xD0]
0000707649fdae78  vmovaps xmm15, [rsp+0xE0]
0000707649fdae81  add rsp, 0xF0
0000707649fdae88  pop r11
0000707649fdae8a  pop r10
0000707649fdae8c  pop r9
0000707649fdae8e  pop r8
0000707649fdae90  pop rsi
0000707649fdae91  pop rdi
0000707649fdae92  pop rdx
0000707649fdae93  pop rcx
0000707649fdae94  pop rax
0000707649fdae95  add rsp, 0x08
0000707649fdae99  jmp 0x0000707649FD6578
0000707649fdae9e  sub rsp, 0x08
0000707649fdaea2  push rax
0000707649fdaea3  push rcx
0000707649fdaea4  push rdx
0000707649fdaea5  push rdi
0000707649fdaea6  push rsi
0000707649fdaea7  push r8
0000707649fdaea9  push r9
0000707649fdaeab  push r10
0000707649fdaead  push r11
0000707649fdaeaf  sub rsp, 0xF0
0000707649fdaeb6  vmovaps [rsp], xmm0
0000707649fdaebb  vmovaps [rsp+0x10], xmm2
0000707649fdaec1  vmovaps [rsp+0x20], xmm3
0000707649fdaec7  vmovaps [rsp+0x30], xmm4
0000707649fdaecd  vmovaps [rsp+0x40], xmm5
0000707649fdaed3  vmovaps [rsp+0x50], xmm6
0000707649fdaed9  vmovaps [rsp+0x60], xmm7
0000707649fdaedf  vmovaps [rsp+0x70], xmm8
0000707649fdaee5  vmovaps [rsp+0x80], xmm9
0000707649fdaeee  vmovaps [rsp+0x90], xmm10
0000707649fdaef7  vmovaps [rsp+0xA0], xmm11
0000707649fdaf00  vmovaps [rsp+0xB0], xmm12
0000707649fdaf09  vmovaps [rsp+0xC0], xmm13
0000707649fdaf12  vmovaps [rsp+0xD0], xmm14
0000707649fdaf1b  vmovaps [rsp+0xE0], xmm15
0000707649fdaf24  sub rsp, 0x30
0000707649fdaf28  movaps [rsp], xmm1
0000707649fdaf2c  movaps [rsp+0x10], xmm13
0000707649fdaf32  movaps [rsp+0x20], xmm8
0000707649fdaf38  lea rdi, [rsp]
0000707649fdaf3c  mov esi, 0x00
0000707649fdaf41  mov rax, 0x59CB0B054530
0000707649fdaf4b  call rax
0000707649fdaf4d  movaps xmm1, [rsp]
0000707649fdaf51  add rsp, 0x30
0000707649fdaf55  vmovaps xmm0, [rsp]
0000707649fdaf5a  vmovaps xmm2, [rsp+0x10]
0000707649fdaf60  vmovaps xmm3, [rsp+0x20]
0000707649fdaf66  vmovaps xmm4, [rsp+0x30]
0000707649fdaf6c  vmovaps xmm5, [rsp+0x40]
0000707649fdaf72  vmovaps xmm6, [rsp+0x50]
0000707649fdaf78  vmovaps xmm7, [rsp+0x60]
0000707649fdaf7e  vmovaps xmm8, [rsp+0x70]
0000707649fdaf84  vmovaps xmm9, [rsp+0x80]
0000707649fdaf8d  vmovaps xmm10, [rsp+0x90]
0000707649fdaf96  vmovaps xmm11, [rsp+0xA0]
0000707649fdaf9f  vmovaps xmm12, [rsp+0xB0]
0000707649fdafa8  vmovaps xmm13, [rsp+0xC0]
0000707649fdafb1  vmovaps xmm14, [rsp+0xD0]
0000707649fdafba  vmovaps xmm15, [rsp+0xE0]
0000707649fdafc3  add rsp, 0xF0
0000707649fdafca  pop r11
0000707649fdafcc  pop r10
0000707649fdafce  pop r9
0000707649fdafd0  pop r8
0000707649fdafd2  pop rsi
0000707649fdafd3  pop rdi
0000707649fdafd4  pop rdx
0000707649fdafd5  pop rcx
0000707649fdafd6  pop rax
0000707649fdafd7  add rsp, 0x08
0000707649fdafdb  jmp 0x0000707649FD659A
0000707649fdafe0  call 0x0000707649E0C260
0000707649fdafe5  jmp 0x0000707649FD65A8
0000707649fdafea  call 0x0000707649EDE950
0000707649fdafef  jmp 0x0000707649FD65B2
0000707649fdaff4  sub rsp, 0x08
0000707649fdaff8  push rax
0000707649fdaff9  push rcx
0000707649fdaffa  push rdx
0000707649fdaffb  push rdi
0000707649fdaffc  push rsi
0000707649fdaffd  push r8
0000707649fdafff  push r9
0000707649fdb001  push r10
0000707649fdb003  push r11
0000707649fdb005  sub rsp, 0xF0
0000707649fdb00c  vmovaps [rsp], xmm0
0000707649fdb011  vmovaps [rsp+0x10], xmm1
0000707649fdb017  vmovaps [rsp+0x20], xmm2
0000707649fdb01d  vmovaps [rsp+0x30], xmm3
0000707649fdb023  vmovaps [rsp+0x40], xmm4
0000707649fdb029  vmovaps [rsp+0x50], xmm5
0000707649fdb02f  vmovaps [rsp+0x60], xmm6
0000707649fdb035  vmovaps [rsp+0x70], xmm7
0000707649fdb03b  vmovaps [rsp+0x80], xmm9
0000707649fdb044  vmovaps [rsp+0x90], xmm10
0000707649fdb04d  vmovaps [rsp+0xA0], xmm11
0000707649fdb056  vmovaps [rsp+0xB0], xmm12
0000707649fdb05f  vmovaps [rsp+0xC0], xmm13
0000707649fdb068  vmovaps [rsp+0xD0], xmm14
0000707649fdb071  vmovaps [rsp+0xE0], xmm15
0000707649fdb07a  sub rsp, 0x30
0000707649fdb07e  movaps [rsp], xmm8
0000707649fdb083  movaps [rsp+0x10], xmm15
0000707649fdb089  movaps [rsp+0x20], xmm7
0000707649fdb08e  lea rdi, [rsp]
0000707649fdb092  mov esi, 0x00
0000707649fdb097  mov rax, 0x59CB0B054530
0000707649fdb0a1  call rax
0000707649fdb0a3  movaps xmm8, [rsp]
0000707649fdb0a8  add rsp, 0x30
0000707649fdb0ac  vmovaps xmm0, [rsp]
0000707649fdb0b1  vmovaps xmm1, [rsp+0x10]
0000707649fdb0b7  vmovaps xmm2, [rsp+0x20]
0000707649fdb0bd  vmovaps xmm3, [rsp+0x30]
0000707649fdb0c3  vmovaps xmm4, [rsp+0x40]
0000707649fdb0c9  vmovaps xmm5, [rsp+0x50]
0000707649fdb0cf  vmovaps xmm6, [rsp+0x60]
0000707649fdb0d5  vmovaps xmm7, [rsp+0x70]
0000707649fdb0db  vmovaps xmm9, [rsp+0x80]
0000707649fdb0e4  vmovaps xmm10, [rsp+0x90]
0000707649fdb0ed  vmovaps xmm11, [rsp+0xA0]
0000707649fdb0f6  vmovaps xmm12, [rsp+0xB0]
0000707649fdb0ff  vmovaps xmm13, [rsp+0xC0]
0000707649fdb108  vmovaps xmm14, [rsp+0xD0]
0000707649fdb111  vmovaps xmm15, [rsp+0xE0]
0000707649fdb11a  add rsp, 0xF0
0000707649fdb121  pop r11
0000707649fdb123  pop r10
0000707649fdb125  pop r9
0000707649fdb127  pop r8
0000707649fdb129  pop rsi
0000707649fdb12a  pop rdi
0000707649fdb12b  pop rdx
0000707649fdb12c  pop rcx
0000707649fdb12d  pop rax
0000707649fdb12e  add rsp, 0x08
0000707649fdb132  jmp 0x0000707649FD65D4
0000707649fdb137  sub rsp, 0x08
0000707649fdb13b  push rax
0000707649fdb13c  push rcx
0000707649fdb13d  push rdx
0000707649fdb13e  push rdi
0000707649fdb13f  push rsi
0000707649fdb140  push r8
0000707649fdb142  push r9
0000707649fdb144  push r10
0000707649fdb146  push r11
0000707649fdb148  sub rsp, 0xF0
0000707649fdb14f  vmovaps [rsp], xmm0
0000707649fdb154  vmovaps [rsp+0x10], xmm1
0000707649fdb15a  vmovaps [rsp+0x20], xmm2
0000707649fdb160  vmovaps [rsp+0x30], xmm3
0000707649fdb166  vmovaps [rsp+0x40], xmm4
0000707649fdb16c  vmovaps [rsp+0x50], xmm5
0000707649fdb172  vmovaps [rsp+0x60], xmm6
0000707649fdb178  vmovaps [rsp+0x70], xmm8
0000707649fdb17e  vmovaps [rsp+0x80], xmm9
0000707649fdb187  vmovaps [rsp+0x90], xmm10
0000707649fdb190  vmovaps [rsp+0xA0], xmm11
0000707649fdb199  vmovaps [rsp+0xB0], xmm12
0000707649fdb1a2  vmovaps [rsp+0xC0], xmm13
0000707649fdb1ab  vmovaps [rsp+0xD0], xmm14
0000707649fdb1b4  vmovaps [rsp+0xE0], xmm15
0000707649fdb1bd  sub rsp, 0x30
0000707649fdb1c1  movaps [rsp], xmm7
0000707649fdb1c5  movaps [rsp+0x10], xmm9
0000707649fdb1cb  movaps [rsp+0x20], xmm15
0000707649fdb1d1  lea rdi, [rsp]
0000707649fdb1d5  mov esi, 0x00
0000707649fdb1da  mov rax, 0x59CB0B054530
0000707649fdb1e4  call rax
0000707649fdb1e6  movaps xmm7, [rsp]
0000707649fdb1ea  add rsp, 0x30
0000707649fdb1ee  vmovaps xmm0, [rsp]
0000707649fdb1f3  vmovaps xmm1, [rsp+0x10]
0000707649fdb1f9  vmovaps xmm2, [rsp+0x20]
0000707649fdb1ff  vmovaps xmm3, [rsp+0x30]
0000707649fdb205  vmovaps xmm4, [rsp+0x40]
0000707649fdb20b  vmovaps xmm5, [rsp+0x50]
0000707649fdb211  vmovaps xmm6, [rsp+0x60]
0000707649fdb217  vmovaps xmm8, [rsp+0x70]
0000707649fdb21d  vmovaps xmm9, [rsp+0x80]
0000707649fdb226  vmovaps xmm10, [rsp+0x90]
0000707649fdb22f  vmovaps xmm11, [rsp+0xA0]
0000707649fdb238  vmovaps xmm12, [rsp+0xB0]
0000707649fdb241  vmovaps xmm13, [rsp+0xC0]
0000707649fdb24a  vmovaps xmm14, [rsp+0xD0]
0000707649fdb253  vmovaps xmm15, [rsp+0xE0]
0000707649fdb25c  add rsp, 0xF0
0000707649fdb263  pop r11
0000707649fdb265  pop r10
0000707649fdb267  pop r9
0000707649fdb269  pop r8
0000707649fdb26b  pop rsi
0000707649fdb26c  pop rdi
0000707649fdb26d  pop rdx
0000707649fdb26e  pop rcx
0000707649fdb26f  pop rax
0000707649fdb270  add rsp, 0x08
0000707649fdb274  jmp 0x0000707649FD6601
0000707649fdb279  sub rsp, 0x08
0000707649fdb27d  push rax
0000707649fdb27e  push rcx
0000707649fdb27f  push rdx
0000707649fdb280  push rdi
0000707649fdb281  push rsi
0000707649fdb282  push r8
0000707649fdb284  push r9
0000707649fdb286  push r10
0000707649fdb288  push r11
0000707649fdb28a  sub rsp, 0xF0
0000707649fdb291  vmovaps [rsp], xmm0
0000707649fdb296  vmovaps [rsp+0x10], xmm1
0000707649fdb29c  vmovaps [rsp+0x20], xmm2
0000707649fdb2a2  vmovaps [rsp+0x30], xmm3
0000707649fdb2a8  vmovaps [rsp+0x40], xmm4
0000707649fdb2ae  vmovaps [rsp+0x50], xmm5
0000707649fdb2b4  vmovaps [rsp+0x60], xmm6
0000707649fdb2ba  vmovaps [rsp+0x70], xmm7
0000707649fdb2c0  vmovaps [rsp+0x80], xmm8
0000707649fdb2c9  vmovaps [rsp+0x90], xmm10
0000707649fdb2d2  vmovaps [rsp+0xA0], xmm11
0000707649fdb2db  vmovaps [rsp+0xB0], xmm12
0000707649fdb2e4  vmovaps [rsp+0xC0], xmm13
0000707649fdb2ed  vmovaps [rsp+0xD0], xmm14
0000707649fdb2f6  vmovaps [rsp+0xE0], xmm15
0000707649fdb2ff  sub rsp, 0x30
0000707649fdb303  movaps [rsp], xmm9
0000707649fdb308  movaps [rsp+0x10], xmm13
0000707649fdb30e  movaps [rsp+0x20], xmm15
0000707649fdb314  lea rdi, [rsp]
0000707649fdb318  mov esi, 0x00
0000707649fdb31d  mov rax, 0x59CB0B054530
0000707649fdb327  call rax
0000707649fdb329  movaps xmm9, [rsp]
0000707649fdb32e  add rsp, 0x30
0000707649fdb332  vmovaps xmm0, [rsp]
0000707649fdb337  vmovaps xmm1, [rsp+0x10]
0000707649fdb33d  vmovaps xmm2, [rsp+0x20]
0000707649fdb343  vmovaps xmm3, [rsp+0x30]
0000707649fdb349  vmovaps xmm4, [rsp+0x40]
0000707649fdb34f  vmovaps xmm5, [rsp+0x50]
0000707649fdb355  vmovaps xmm6, [rsp+0x60]
0000707649fdb35b  vmovaps xmm7, [rsp+0x70]
0000707649fdb361  vmovaps xmm8, [rsp+0x80]
0000707649fdb36a  vmovaps xmm10, [rsp+0x90]
0000707649fdb373  vmovaps xmm11, [rsp+0xA0]
0000707649fdb37c  vmovaps xmm12, [rsp+0xB0]
0000707649fdb385  vmovaps xmm13, [rsp+0xC0]
0000707649fdb38e  vmovaps xmm14, [rsp+0xD0]
0000707649fdb397  vmovaps xmm15, [rsp+0xE0]
0000707649fdb3a0  add rsp, 0xF0
0000707649fdb3a7  pop r11
0000707649fdb3a9  pop r10
0000707649fdb3ab  pop r9
0000707649fdb3ad  pop r8
0000707649fdb3af  pop rsi
0000707649fdb3b0  pop rdi
0000707649fdb3b1  pop rdx
0000707649fdb3b2  pop rcx
0000707649fdb3b3  pop rax
0000707649fdb3b4  add rsp, 0x08
0000707649fdb3b8  jmp 0x0000707649FD662F
0000707649fdb3bd  sub rsp, 0x08
0000707649fdb3c1  push rax
0000707649fdb3c2  push rcx
0000707649fdb3c3  push rdx
0000707649fdb3c4  push rdi
0000707649fdb3c5  push rsi
0000707649fdb3c6  push r8
0000707649fdb3c8  push r9
0000707649fdb3ca  push r10
0000707649fdb3cc  push r11
0000707649fdb3ce  sub rsp, 0xF0
0000707649fdb3d5  vmovaps [rsp], xmm0
0000707649fdb3da  vmovaps [rsp+0x10], xmm1
0000707649fdb3e0  vmovaps [rsp+0x20], xmm2
0000707649fdb3e6  vmovaps [rsp+0x30], xmm3
0000707649fdb3ec  vmovaps [rsp+0x40], xmm4
0000707649fdb3f2  vmovaps [rsp+0x50], xmm5
0000707649fdb3f8  vmovaps [rsp+0x60], xmm6
0000707649fdb3fe  vmovaps [rsp+0x70], xmm7
0000707649fdb404  vmovaps [rsp+0x80], xmm8
0000707649fdb40d  vmovaps [rsp+0x90], xmm9
0000707649fdb416  vmovaps [rsp+0xA0], xmm10
0000707649fdb41f  vmovaps [rsp+0xB0], xmm11
0000707649fdb428  vmovaps [rsp+0xC0], xmm12
0000707649fdb431  vmovaps [rsp+0xD0], xmm13
0000707649fdb43a  vmovaps [rsp+0xE0], xmm14
0000707649fdb443  sub rsp, 0x30
0000707649fdb447  movaps [rsp], xmm15
0000707649fdb44c  movaps [rsp+0x10], xmm11
0000707649fdb452  movaps [rsp+0x20], xmm12
0000707649fdb458  lea rdi, [rsp]
0000707649fdb45c  mov esi, 0x00
0000707649fdb461  mov rax, 0x59CB0B054530
0000707649fdb46b  call rax
0000707649fdb46d  movaps xmm15, [rsp]
0000707649fdb472  add rsp, 0x30
0000707649fdb476  vmovaps xmm0, [rsp]
0000707649fdb47b  vmovaps xmm1, [rsp+0x10]
0000707649fdb481  vmovaps xmm2, [rsp+0x20]
0000707649fdb487  vmovaps xmm3, [rsp+0x30]
0000707649fdb48d  vmovaps xmm4, [rsp+0x40]
0000707649fdb493  vmovaps xmm5, [rsp+0x50]
0000707649fdb499  vmovaps xmm6, [rsp+0x60]
0000707649fdb49f  vmovaps xmm7, [rsp+0x70]
0000707649fdb4a5  vmovaps xmm8, [rsp+0x80]
0000707649fdb4ae  vmovaps xmm9, [rsp+0x90]
0000707649fdb4b7  vmovaps xmm10, [rsp+0xA0]
0000707649fdb4c0  vmovaps xmm11, [rsp+0xB0]
0000707649fdb4c9  vmovaps xmm12, [rsp+0xC0]
0000707649fdb4d2  vmovaps xmm13, [rsp+0xD0]
0000707649fdb4db  vmovaps xmm14, [rsp+0xE0]
0000707649fdb4e4  add rsp, 0xF0
0000707649fdb4eb  pop r11
0000707649fdb4ed  pop r10
0000707649fdb4ef  pop r9
0000707649fdb4f1  pop r8
0000707649fdb4f3  pop rsi
0000707649fdb4f4  pop rdi
0000707649fdb4f5  pop rdx
0000707649fdb4f6  pop rcx
0000707649fdb4f7  pop rax
0000707649fdb4f8  add rsp, 0x08
0000707649fdb4fc  jmp 0x0000707649FD664A
0000707649fdb501  sub rsp, 0x08
0000707649fdb505  push rax
0000707649fdb506  push rcx
0000707649fdb507  push rdx
0000707649fdb508  push rdi
0000707649fdb509  push rsi
0000707649fdb50a  push r8
0000707649fdb50c  push r9
0000707649fdb50e  push r10
0000707649fdb510  push r11
0000707649fdb512  sub rsp, 0xF0
0000707649fdb519  vmovaps [rsp], xmm0
0000707649fdb51e  vmovaps [rsp+0x10], xmm1
0000707649fdb524  vmovaps [rsp+0x20], xmm2
0000707649fdb52a  vmovaps [rsp+0x30], xmm3
0000707649fdb530  vmovaps [rsp+0x40], xmm4
0000707649fdb536  vmovaps [rsp+0x50], xmm5
0000707649fdb53c  vmovaps [rsp+0x60], xmm6
0000707649fdb542  vmovaps [rsp+0x70], xmm7
0000707649fdb548  vmovaps [rsp+0x80], xmm8
0000707649fdb551  vmovaps [rsp+0x90], xmm9
0000707649fdb55a  vmovaps [rsp+0xA0], xmm10
0000707649fdb563  vmovaps [rsp+0xB0], xmm11
0000707649fdb56c  vmovaps [rsp+0xC0], xmm12
0000707649fdb575  vmovaps [rsp+0xD0], xmm14
0000707649fdb57e  vmovaps [rsp+0xE0], xmm15
0000707649fdb587  sub rsp, 0x30
0000707649fdb58b  movaps [rsp], xmm13
0000707649fdb590  movaps [rsp+0x10], xmm10
0000707649fdb596  movaps [rsp+0x20], xmm14
0000707649fdb59c  lea rdi, [rsp]
0000707649fdb5a0  mov esi, 0x00
0000707649fdb5a5  mov rax, 0x59CB0B054530
0000707649fdb5af  call rax
0000707649fdb5b1  movaps xmm13, [rsp]
0000707649fdb5b6  add rsp, 0x30
0000707649fdb5ba  vmovaps xmm0, [rsp]
0000707649fdb5bf  vmovaps xmm1, [rsp+0x10]
0000707649fdb5c5  vmovaps xmm2, [rsp+0x20]
0000707649fdb5cb  vmovaps xmm3, [rsp+0x30]
0000707649fdb5d1  vmovaps xmm4, [rsp+0x40]
0000707649fdb5d7  vmovaps xmm5, [rsp+0x50]
0000707649fdb5dd  vmovaps xmm6, [rsp+0x60]
0000707649fdb5e3  vmovaps xmm7, [rsp+0x70]
0000707649fdb5e9  vmovaps xmm8, [rsp+0x80]
0000707649fdb5f2  vmovaps xmm9, [rsp+0x90]
0000707649fdb5fb  vmovaps xmm10, [rsp+0xA0]
0000707649fdb604  vmovaps xmm11, [rsp+0xB0]
0000707649fdb60d  vmovaps xmm12, [rsp+0xC0]
0000707649fdb616  vmovaps xmm14, [rsp+0xD0]
0000707649fdb61f  vmovaps xmm15, [rsp+0xE0]
0000707649fdb628  add rsp, 0xF0
0000707649fdb62f  pop r11
0000707649fdb631  pop r10
0000707649fdb633  pop r9
0000707649fdb635  pop r8
0000707649fdb637  pop rsi
0000707649fdb638  pop rdi
0000707649fdb639  pop rdx
0000707649fdb63a  pop rcx
0000707649fdb63b  pop rax
0000707649fdb63c  add rsp, 0x08
0000707649fdb640  jmp 0x0000707649FD666D
0000707649fdb645  sub rsp, 0x08
0000707649fdb649  push rax
0000707649fdb64a  push rcx
0000707649fdb64b  push rdx
0000707649fdb64c  push rdi
0000707649fdb64d  push rsi
0000707649fdb64e  push r8
0000707649fdb650  push r9
0000707649fdb652  push r10
0000707649fdb654  push r11
0000707649fdb656  sub rsp, 0xF0
0000707649fdb65d  vmovaps [rsp], xmm0
0000707649fdb662  vmovaps [rsp+0x10], xmm1
0000707649fdb668  vmovaps [rsp+0x20], xmm2
0000707649fdb66e  vmovaps [rsp+0x30], xmm3
0000707649fdb674  vmovaps [rsp+0x40], xmm4
0000707649fdb67a  vmovaps [rsp+0x50], xmm5
0000707649fdb680  vmovaps [rsp+0x60], xmm6
0000707649fdb686  vmovaps [rsp+0x70], xmm7
0000707649fdb68c  vmovaps [rsp+0x80], xmm8
0000707649fdb695  vmovaps [rsp+0x90], xmm9
0000707649fdb69e  vmovaps [rsp+0xA0], xmm10
0000707649fdb6a7  vmovaps [rsp+0xB0], xmm11
0000707649fdb6b0  vmovaps [rsp+0xC0], xmm12
0000707649fdb6b9  vmovaps [rsp+0xD0], xmm13
0000707649fdb6c2  vmovaps [rsp+0xE0], xmm15
0000707649fdb6cb  sub rsp, 0x30
0000707649fdb6cf  movaps [rsp], xmm14
0000707649fdb6d4  movaps [rsp+0x10], xmm1
0000707649fdb6d9  movaps [rsp+0x20], xmm7
0000707649fdb6de  lea rdi, [rsp]
0000707649fdb6e2  mov esi, 0x00
0000707649fdb6e7  mov rax, 0x59CB0B054530
0000707649fdb6f1  call rax
0000707649fdb6f3  movaps xmm14, [rsp]
0000707649fdb6f8  add rsp, 0x30
0000707649fdb6fc  vmovaps xmm0, [rsp]
0000707649fdb701  vmovaps xmm1, [rsp+0x10]
0000707649fdb707  vmovaps xmm2, [rsp+0x20]
0000707649fdb70d  vmovaps xmm3, [rsp+0x30]
0000707649fdb713  vmovaps xmm4, [rsp+0x40]
0000707649fdb719  vmovaps xmm5, [rsp+0x50]
0000707649fdb71f  vmovaps xmm6, [rsp+0x60]
0000707649fdb725  vmovaps xmm7, [rsp+0x70]
0000707649fdb72b  vmovaps xmm8, [rsp+0x80]
0000707649fdb734  vmovaps xmm9, [rsp+0x90]
0000707649fdb73d  vmovaps xmm10, [rsp+0xA0]
0000707649fdb746  vmovaps xmm11, [rsp+0xB0]
0000707649fdb74f  vmovaps xmm12, [rsp+0xC0]
0000707649fdb758  vmovaps xmm13, [rsp+0xD0]
0000707649fdb761  vmovaps xmm15, [rsp+0xE0]
0000707649fdb76a  add rsp, 0xF0
0000707649fdb771  pop r11
0000707649fdb773  pop r10
0000707649fdb775  pop r9
0000707649fdb777  pop r8
0000707649fdb779  pop rsi
0000707649fdb77a  pop rdi
0000707649fdb77b  pop rdx
0000707649fdb77c  pop rcx
0000707649fdb77d  pop rax
0000707649fdb77e  add rsp, 0x08
0000707649fdb782  jmp 0x0000707649FD6690
0000707649fdb787  sub rsp, 0x08
0000707649fdb78b  push rax
0000707649fdb78c  push rcx
0000707649fdb78d  push rdx
0000707649fdb78e  push rdi
0000707649fdb78f  push rsi
0000707649fdb790  push r8
0000707649fdb792  push r9
0000707649fdb794  push r10
0000707649fdb796  push r11
0000707649fdb798  sub rsp, 0xF0
0000707649fdb79f  vmovaps [rsp], xmm0
0000707649fdb7a4  vmovaps [rsp+0x10], xmm2
0000707649fdb7aa  vmovaps [rsp+0x20], xmm3
0000707649fdb7b0  vmovaps [rsp+0x30], xmm4
0000707649fdb7b6  vmovaps [rsp+0x40], xmm5
0000707649fdb7bc  vmovaps [rsp+0x50], xmm6
0000707649fdb7c2  vmovaps [rsp+0x60], xmm7
0000707649fdb7c8  vmovaps [rsp+0x70], xmm8
0000707649fdb7ce  vmovaps [rsp+0x80], xmm9
0000707649fdb7d7  vmovaps [rsp+0x90], xmm10
0000707649fdb7e0  vmovaps [rsp+0xA0], xmm11
0000707649fdb7e9  vmovaps [rsp+0xB0], xmm12
0000707649fdb7f2  vmovaps [rsp+0xC0], xmm13
0000707649fdb7fb  vmovaps [rsp+0xD0], xmm14
0000707649fdb804  vmovaps [rsp+0xE0], xmm15
0000707649fdb80d  sub rsp, 0x30
0000707649fdb811  movaps [rsp], xmm1
0000707649fdb815  movaps [rsp+0x10], xmm8
0000707649fdb81b  movaps [rsp+0x20], xmm9
0000707649fdb821  lea rdi, [rsp]
0000707649fdb825  mov esi, 0x00
0000707649fdb82a  mov rax, 0x59CB0B054530
0000707649fdb834  call rax
0000707649fdb836  movaps xmm1, [rsp]
0000707649fdb83a  add rsp, 0x30
0000707649fdb83e  vmovaps xmm0, [rsp]
0000707649fdb843  vmovaps xmm2, [rsp+0x10]
0000707649fdb849  vmovaps xmm3, [rsp+0x20]
0000707649fdb84f  vmovaps xmm4, [rsp+0x30]
0000707649fdb855  vmovaps xmm5, [rsp+0x40]
0000707649fdb85b  vmovaps xmm6, [rsp+0x50]
0000707649fdb861  vmovaps xmm7, [rsp+0x60]
0000707649fdb867  vmovaps xmm8, [rsp+0x70]
0000707649fdb86d  vmovaps xmm9, [rsp+0x80]
0000707649fdb876  vmovaps xmm10, [rsp+0x90]
0000707649fdb87f  vmovaps xmm11, [rsp+0xA0]
0000707649fdb888  vmovaps xmm12, [rsp+0xB0]
0000707649fdb891  vmovaps xmm13, [rsp+0xC0]
0000707649fdb89a  vmovaps xmm14, [rsp+0xD0]
0000707649fdb8a3  vmovaps xmm15, [rsp+0xE0]
0000707649fdb8ac  add rsp, 0xF0
0000707649fdb8b3  pop r11
0000707649fdb8b5  pop r10
0000707649fdb8b7  pop r9
0000707649fdb8b9  pop r8
0000707649fdb8bb  pop rsi
0000707649fdb8bc  pop rdi
0000707649fdb8bd  pop rdx
0000707649fdb8be  pop rcx
0000707649fdb8bf  pop rax
0000707649fdb8c0  add rsp, 0x08
0000707649fdb8c4  jmp 0x0000707649FD66B2
0000707649fdb8c9  call 0x0000707649EB3E40
0000707649fdb8ce  jmp 0x0000707649FD66C0
0000707649fdb8d3  call 0x0000707649E0C380
0000707649fdb8d8  jmp 0x0000707649FD66CA
0000707649fdb8dd  call 0x0000707649E0D600
0000707649fdb8e2  jmp 0x0000707649FD66D4
0000707649fdb8e7  call 0x0000707649DFF540
0000707649fdb8ec  jmp 0x0000707649FD66DE
0000707649fdb8f1  int3
0000707649fdb8f2  nop [rax+rax*1], ax
0000707649fdb8fb  nop [rax+rax*1], eax
0000707649fdb900  mov eax, [r15+0x48]
0000707649fdb904  lea r14d, [eax+0x01]
0000707649fdb909  mov [rsp+0x10], r14d
0000707649fdb90e  mov r14d, r14d
0000707649fdb911  mov [r15+0x48], r14
0000707649fdb915  xor eax, eax
0000707649fdb917  mov r14d, [rsp+0x10]
0000707649fdb91c  cmp r14d, 0x1F4
0000707649fdb923  cmc
0000707649fdb924  lahf
0000707649fdb925  seto al
0000707649fdb928  mov [r15+0x108], eax
0000707649fdb92f  mov eax, [r15+0x108]
0000707649fdb936  sahf
0000707649fdb937  jnz 0x0000707649FDB969
0000707649fdb939  cmp dword ptr [r15+0x318], 0x00
0000707649fdb941  jz 0x0000707649FE1AB0
0000707649fdb947  nop [rax+rax*1], ax
0000707649fdb950  nop [rax+rax*1], eax
0000707649fdb958  mov eax, 0x410450
0000707649fdb95d  mov [r15+0x100], rax
0000707649fdb964  jmp 0x0000707649DFE110
0000707649fdb969  cmp dword ptr [r15+0x318], 0x00
0000707649fdb971  jz 0x0000707649FDB9A0
0000707649fdb977  nop [rax+rax*1], ax
0000707649fdb980  nop [rax+rax*1], eax
0000707649fdb988  mov eax, 0x410274
0000707649fdb98d  mov [r15+0x100], rax
0000707649fdb994  jmp 0x0000707649DFE110
0000707649fdb999  int3
0000707649fdb99a  int3
0000707649fdb99b  nop [rax+rax*1], eax
0000707649fdb9a0  mov rax, [r15+0x40]
0000707649fdb9a4  movaps xmm1, [r15+0x1D0]
0000707649fdb9ac  vmovaps [rsp+0x10], xmm1
0000707649fdb9b2  vmovaps xmm15, [rsp+0x10]
0000707649fdb9b8  por xmm1, xmm15
0000707649fdb9bd  movaps xmm14, [r15+0x1A0]
0000707649fdb9c5  vmovaps [rsp+0x10], xmm14
0000707649fdb9cb  vmovaps xmm13, [rsp+0x10]
0000707649fdb9d1  por xmm14, xmm13
0000707649fdb9d6  lea r14, [rax+0x30]
0000707649fdb9da  mov r12, [r13+r14*1]
0000707649fdb9df  lea r14, [rax+0x38]
0000707649fdb9e3  mov r11, [r13+r14*1]
0000707649fdb9e8  movq xmm13, r12
0000707649fdb9ed  movq xmm12, r11
0000707649fdb9f2  movq xmm13, xmm13
0000707649fdb9f7  vmovaps [rsp+0x10], xmm13
0000707649fdb9fd  movq xmm13, xmm13
0000707649fdba02  movaps [r15+0x130], xmm13
0000707649fdba0a  movq xmm12, xmm12
0000707649fdba0f  vmovaps [rsp+0x20], xmm12
0000707649fdba15  movq xmm12, xmm12
0000707649fdba1a  movaps [r15+0x280], xmm12
0000707649fdba22  movaps xmm13, [r15+0x270]
0000707649fdba2a  vmovaps [rsp+0x30], xmm13
0000707649fdba30  vmovaps xmm12, [rsp+0x30]
0000707649fdba36  por xmm13, xmm12
0000707649fdba3b  lea r14, [rax+0x20]
0000707649fdba3f  mov r12, [r13+r14*1]
0000707649fdba44  lea r14, [rax+0x28]
0000707649fdba48  mov r11, [r13+r14*1]
0000707649fdba4d  movq xmm12, r12
0000707649fdba52  movq xmm11, r11
0000707649fdba57  movq xmm12, xmm12
0000707649fdba5c  vmovaps [rsp+0x30], xmm12
0000707649fdba62  movq xmm12, xmm12
0000707649fdba67  movaps [r15+0x150], xmm12
0000707649fdba6f  movq xmm11, xmm11
0000707649fdba74  vmovaps [rsp+0x40], xmm11
0000707649fdba7a  movq xmm11, xmm11
0000707649fdba7f  movaps [r15+0x140], xmm11
0000707649fdba87  lea r14, [rax+0x10]
0000707649fdba8b  mov r12, [r13+r14*1]
0000707649fdba90  lea r14, [rax+0x18]
0000707649fdba94  mov r11, [r13+r14*1]
0000707649fdba99  movq xmm12, r12
0000707649fdba9e  movq xmm11, r11
0000707649fdbaa3  movq xmm12, xmm12
0000707649fdbaa8  vmovaps [rsp+0x50], xmm12
0000707649fdbaae  movq xmm12, xmm12
0000707649fdbab3  movaps [r15+0x170], xmm12
0000707649fdbabb  movq xmm11, xmm11
0000707649fdbac0  vmovaps [rsp+0x60], xmm11
0000707649fdbac6  movq xmm11, xmm11
0000707649fdbacb  movaps [r15+0x160], xmm11
0000707649fdbad3  mov r14, [r13+rax*1]
0000707649fdbad8  vmovq xmm12, r14
0000707649fdbadd  vpbroadcastq xmm12, xmm12
0000707649fdbae2  lea r14, [rax+0x08]
0000707649fdbae6  mov rax, [r13+r14*1]
0000707649fdbaeb  movq xmm11, rax
0000707649fdbaf0  movaps [r15+0x230], xmm11
0000707649fdbaf8  mov rax, [r15+0xF8]
0000707649fdbaff  lea r14, [rax+0x50]
0000707649fdbb03  movups xmm11, [r13+r14*1]
0000707649fdbb09  lea r14, [rax+0x60]
0000707649fdbb0d  movups xmm10, [r13+r14*1]
0000707649fdbb13  lea r14, [rax+0x30]
0000707649fdbb17  movups xmm9, [r13+r14*1]
0000707649fdbb1d  mov r14, [r15+0x50]
0000707649fdbb21  mov [r15+0x60], r14
0000707649fdbb25  mov qword ptr [r15+0x58], 0x40
0000707649fdbb2d  movaps xmm8, xmm12
0000707649fdbb31  mulpd xmm8, xmm15
0000707649fdbb36  vcmppd xmm7, xmm8, xmm8, 0x03
0000707649fdbb3c  ptest xmm7, xmm7
0000707649fdbb41  jnz 0x0000707649FDC96A
0000707649fdbb47  movq xmm15, qword ptr [r15+0x230]
0000707649fdbb50  vmovaps [rsp+0x70], xmm15
0000707649fdbb56  vpermilpd xmm15, xmm15, 0x00
0000707649fdbb5c  movaps xmm7, xmm9
0000707649fdbb60  mulpd xmm7, xmm15
0000707649fdbb65  vcmppd xmm6, xmm7, xmm7, 0x03
0000707649fdbb6a  ptest xmm6, xmm6
0000707649fdbb6f  jnz 0x0000707649FDCAAE
0000707649fdbb75  vxorps xmm15, xmm15, xmm15
0000707649fdbb7a  vpbroadcastq xmm15, xmm15
0000707649fdbb7f  movaps xmm9, xmm12
0000707649fdbb83  mulpd xmm9, xmm10
0000707649fdbb88  vcmppd xmm6, xmm9, xmm9, 0x03
0000707649fdbb8e  ptest xmm6, xmm6
0000707649fdbb93  jnz 0x0000707649FDCBF0
0000707649fdbb99  movaps xmm10, xmm12
0000707649fdbb9d  mulpd xmm10, xmm11
0000707649fdbba2  vcmppd xmm6, xmm10, xmm10, 0x03
0000707649fdbba8  ptest xmm6, xmm6
0000707649fdbbad  jnz 0x0000707649FDCD34
0000707649fdbbb3  movaps xmm11, [r15+0x1F0]
0000707649fdbbbb  movaps xmm6, xmm12
0000707649fdbbbf  mulpd xmm6, xmm11
0000707649fdbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
0000707649fdbbc9  ptest xmm5, xmm5
0000707649fdbbce  jnz 0x0000707649FDCE78
0000707649fdbbd4  movaps xmm12, [r15+0x2A0]
0000707649fdbbdc  vmovaps [rsp+0x80], xmm12
0000707649fdbbe5  vmovaps xmm11, [rsp+0x80]
0000707649fdbbee  por xmm12, xmm11
0000707649fdbbf3  movaps xmm11, [r15+0x250]
0000707649fdbbfb  vmovaps [rsp+0x80], xmm11
0000707649fdbc04  vmovaps xmm5, [rsp+0x80]
0000707649fdbc0d  por xmm11, xmm5
0000707649fdbc12  vmovaps xmm4, [rsp+0x70]
0000707649fdbc18  vpermilpd xmm4, xmm4, 0x00
0000707649fdbc1e  movaps xmm3, xmm5
0000707649fdbc21  mulpd xmm3, xmm4
0000707649fdbc25  vcmppd xmm2, xmm3, xmm3, 0x03
0000707649fdbc2a  ptest xmm2, xmm2
0000707649fdbc2f  jnz 0x0000707649FDCFBA
0000707649fdbc35  mov [rsp+0x80], rax
0000707649fdbc3d  xor eax, eax
0000707649fdbc3f  mov r12d, 0x40
0000707649fdbc45  mov r11d, 0x200
0000707649fdbc4b  cmp r12, r11
0000707649fdbc4e  cmc
0000707649fdbc4f  lahf
0000707649fdbc50  seto al
0000707649fdbc53  mov [r15+0x108], eax
0000707649fdbc5a  movaps xmm5, xmm8
0000707649fdbc5e  addpd xmm5, xmm15
0000707649fdbc63  vcmppd xmm4, xmm5, xmm5, 0x03
0000707649fdbc68  ptest xmm4, xmm4
0000707649fdbc6d  jnz 0x0000707649FDD0FA
0000707649fdbc73  movaps xmm8, [r15+0x1B0]
0000707649fdbc7b  movaps xmm4, xmm9
0000707649fdbc7f  addpd xmm4, xmm8
0000707649fdbc84  vcmppd xmm2, xmm4, xmm4, 0x03
0000707649fdbc89  ptest xmm2, xmm2
0000707649fdbc8e  jnz 0x0000707649FDD23C
0000707649fdbc94  movaps xmm9, xmm10
0000707649fdbc98  addpd xmm9, xmm8
0000707649fdbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
0000707649fdbca3  ptest xmm2, xmm2
0000707649fdbca8  jnz 0x0000707649FDD37E
0000707649fdbcae  movaps xmm10, [r15+0x2F0]
0000707649fdbcb6  vmovaps [rsp+0x90], xmm10
0000707649fdbcbf  vmovaps xmm8, [rsp+0x90]
0000707649fdbcc8  por xmm10, xmm8
0000707649fdbccd  movaps xmm8, [r15+0x2E0]
0000707649fdbcd5  vmovaps [rsp+0x90], xmm8
0000707649fdbcde  vmovaps xmm2, [rsp+0x90]
0000707649fdbce7  por xmm8, xmm2
0000707649fdbcec  movaps xmm2, [r15+0x2D0]
0000707649fdbcf4  vmovaps [rsp+0x90], xmm2
0000707649fdbcfd  vmovaps [rsp+0xA0], xmm1
0000707649fdbd06  vmovaps xmm1, [rsp+0x90]
0000707649fdbd0f  por xmm2, xmm1
0000707649fdbd13  movaps xmm1, [r15+0x200]
0000707649fdbd1b  vmovaps [rsp+0x90], xmm1
0000707649fdbd24  vmovaps [rsp+0xB0], xmm15
0000707649fdbd2d  vmovaps xmm15, [rsp+0x90]
0000707649fdbd36  por xmm1, xmm15
0000707649fdbd3b  movaps xmm15, [r15+0x1C0]
0000707649fdbd43  vmovaps [rsp+0x90], xmm15
0000707649fdbd4c  vmovaps [rsp+0xC0], xmm1
0000707649fdbd55  vmovaps xmm1, [rsp+0x90]
0000707649fdbd5e  por xmm15, xmm1
0000707649fdbd63  movaps xmm1, [r15+0x190]
0000707649fdbd6b  vmovaps [rsp+0x90], xmm1
0000707649fdbd74  vmovaps [rsp+0xD0], xmm15
0000707649fdbd7d  vmovaps xmm15, [rsp+0x90]
0000707649fdbd86  por xmm1, xmm15
0000707649fdbd8b  movaps xmm15, [r15+0x300]
0000707649fdbd93  vmovaps [rsp+0x90], xmm15
0000707649fdbd9c  vmovaps [rsp+0xE0], xmm1
0000707649fdbda5  vmovaps xmm1, [rsp+0x90]
0000707649fdbdae  por xmm15, xmm1
0000707649fdbdb3  mov rax, [rsp+0x80]
0000707649fdbdbb  lea r12, [rax+0xA0]
0000707649fdbdc2  movups xmm1, [r13+r12*1]
0000707649fdbdc8  lea r12, [rax+0xB0]
0000707649fdbdcf  vmovaps [rsp+0x80], xmm1
0000707649fdbdd8  movups xmm1, [r13+r12*1]
0000707649fdbdde  vmovaps [rsp+0x90], xmm1
0000707649fdbde7  vmovaps [rsp+0xF0], xmm15
0000707649fdbdf0  vmovaps xmm15, [rsp+0xB0]
0000707649fdbdf9  vmovaps [rsp+0xB0], xmm14
0000707649fdbe02  movaps xmm1, xmm6
0000707649fdbe05  addpd xmm1, xmm15
0000707649fdbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
0000707649fdbe0f  ptest xmm14, xmm14
0000707649fdbe15  jnz 0x0000707649FDD4D6
0000707649fdbe1b  lea r12, [rax+0xF0]
0000707649fdbe22  movups xmm15, [r13+r12*1]
0000707649fdbe28  movaps xmm14, xmm4
0000707649fdbe2c  addpd xmm14, xmm3
0000707649fdbe31  vcmppd xmm6, xmm14, xmm14, 0x03
0000707649fdbe37  ptest xmm6, xmm6
0000707649fdbe3c  jnz 0x0000707649FDD621
0000707649fdbe42  movaps xmm6, xmm9
0000707649fdbe46  addpd xmm6, xmm7
0000707649fdbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
0000707649fdbe4f  ptest xmm4, xmm4
0000707649fdbe54  jnz 0x0000707649FDD763
0000707649fdbe5a  vmovaps xmm9, [rsp+0x70]
0000707649fdbe60  vpermilpd xmm9, xmm9, 0x00
0000707649fdbe66  vmovaps xmm4, [rsp+0x90]
0000707649fdbe6f  movaps xmm7, xmm4
0000707649fdbe72  mulpd xmm7, xmm9
0000707649fdbe77  vcmppd xmm3, xmm7, xmm7, 0x03
0000707649fdbe7c  ptest xmm3, xmm3
0000707649fdbe81  jnz 0x0000707649FDD8A4
0000707649fdbe87  vmovaps xmm9, [rsp+0x50]
0000707649fdbe8d  vpermilpd xmm9, xmm9, 0x00
0000707649fdbe93  movaps xmm4, xmm15
0000707649fdbe97  mulpd xmm4, xmm9
0000707649fdbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
0000707649fdbea1  ptest xmm3, xmm3
0000707649fdbea6  jnz 0x0000707649FDD9E5
0000707649fdbeac  lea r12, [rax+0xE0]
0000707649fdbeb3  movups xmm15, [r13+r12*1]
0000707649fdbeb9  vmovaps xmm9, [rsp+0x70]
0000707649fdbebf  vpermilpd xmm9, xmm9, 0x00
0000707649fdbec5  vmovaps [rsp+0x70], xmm1
0000707649fdbecb  vmovaps xmm1, [rsp+0x80]
0000707649fdbed4  vmovaps [rsp+0x80], xmm15
0000707649fdbedd  movaps xmm3, xmm1
0000707649fdbee0  mulpd xmm3, xmm9
0000707649fdbee5  vcmppd xmm15, xmm3, xmm3, 0x03
0000707649fdbeea  ptest xmm15, xmm15
0000707649fdbef0  jnz 0x0000707649FDDB31
0000707649fdbef6  vmovaps xmm1, [rsp+0xF0]
0000707649fdbeff  vmovaps xmm15, [rsp+0xF0]
0000707649fdbf08  por xmm1, xmm15
0000707649fdbf0d  movaps [r15+0x300], xmm1
0000707649fdbf15  vmovaps xmm15, [rsp+0xE0]
0000707649fdbf1e  vmovaps xmm9, [rsp+0xE0]
0000707649fdbf27  por xmm15, xmm9
0000707649fdbf2c  movaps [r15+0x190], xmm15
0000707649fdbf34  vmovaps xmm9, [rsp+0x50]
0000707649fdbf3a  vpermilpd xmm9, xmm9, 0x00
0000707649fdbf40  vmovaps [rsp+0x90], xmm1
0000707649fdbf49  vmovaps [rsp+0xE0], xmm15
0000707649fdbf52  vmovaps xmm15, [rsp+0x80]
0000707649fdbf5b  vmovaps [rsp+0x80], xmm14
0000707649fdbf64  movaps xmm1, xmm15
0000707649fdbf68  mulpd xmm1, xmm9
0000707649fdbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
0000707649fdbf72  ptest xmm14, xmm14
0000707649fdbf78  jnz 0x0000707649FDDC72
0000707649fdbf7e  lea r12, [rax+0x90]
0000707649fdbf85  movups xmm15, [r13+r12*1]
0000707649fdbf8b  vmovaps xmm14, [rsp+0xD0]
0000707649fdbf94  vmovaps xmm9, [rsp+0xD0]
0000707649fdbf9d  por xmm14, xmm9
0000707649fdbfa2  movaps [r15+0x1C0], xmm14
0000707649fdbfaa  vmovaps xmm9, [rsp+0xC0]
0000707649fdbfb3  vmovaps [rsp+0xD0], xmm1
0000707649fdbfbc  vmovaps xmm1, [rsp+0xC0]
0000707649fdbfc5  por xmm9, xmm1
0000707649fdbfca  movaps [r15+0x200], xmm9
0000707649fdbfd2  vmovaps [rsp+0xC0], xmm2
0000707649fdbfdb  vmovaps xmm1, [rsp+0xC0]
0000707649fdbfe4  por xmm2, xmm1
0000707649fdbfe8  movaps [r15+0x2D0], xmm2
0000707649fdbff0  vmovaps [rsp+0xC0], xmm8
0000707649fdbff9  vmovaps xmm1, [rsp+0xC0]
0000707649fdc002  por xmm8, xmm1
0000707649fdc007  movaps [r15+0x2E0], xmm8
0000707649fdc00f  vmovaps [rsp+0xC0], xmm15
0000707649fdc018  movaps xmm1, xmm5
0000707649fdc01b  addpd xmm1, xmm7
0000707649fdc01f  vcmppd xmm15, xmm1, xmm1, 0x03
0000707649fdc024  ptest xmm15, xmm15
0000707649fdc02a  jnz 0x0000707649FDDDBE
0000707649fdc030  vmovaps xmm15, [rsp+0x50]
0000707649fdc036  vpermilpd xmm15, xmm15, 0x00
0000707649fdc03c  vmovaps xmm5, [rsp+0xC0]
0000707649fdc045  vmovaps [rsp+0xC0], xmm1
0000707649fdc04e  movaps xmm7, xmm5
0000707649fdc051  mulpd xmm7, xmm15
0000707649fdc056  vcmppd xmm1, xmm7, xmm7, 0x03
0000707649fdc05b  ptest xmm1, xmm1
0000707649fdc060  jnz 0x0000707649FDDEFE
0000707649fdc066  lea r12, [rax+0x80]
0000707649fdc06d  movups xmm1, [r13+r12*1]
0000707649fdc073  vmovaps xmm5, [rsp+0x70]
0000707649fdc079  vmovaps [rsp+0x70], xmm1
0000707649fdc07f  movaps xmm15, xmm5
0000707649fdc083  addpd xmm15, xmm3
0000707649fdc088  vcmppd xmm1, xmm15, xmm15, 0x03
0000707649fdc08e  ptest xmm1, xmm1
0000707649fdc093  jnz 0x0000707649FDE049
0000707649fdc099  vmovaps xmm5, [rsp+0x80]
0000707649fdc0a2  movaps xmm1, xmm5
0000707649fdc0a5  addpd xmm1, xmm4
0000707649fdc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
0000707649fdc0ae  ptest xmm3, xmm3
0000707649fdc0b3  jnz 0x0000707649FDE18B
0000707649fdc0b9  vmovaps [rsp+0x80], xmm10
0000707649fdc0c2  vmovaps xmm5, [rsp+0x80]
0000707649fdc0cb  por xmm10, xmm5
0000707649fdc0d0  movaps [r15+0x2F0], xmm10
0000707649fdc0d8  vmovaps xmm5, [rsp+0x50]
0000707649fdc0de  vpermilpd xmm5, xmm5, 0x00
0000707649fdc0e4  vmovaps xmm3, [rsp+0x70]
0000707649fdc0ea  vmovaps [rsp+0x50], xmm1
0000707649fdc0f0  movaps xmm4, xmm3
0000707649fdc0f3  mulpd xmm4, xmm5
0000707649fdc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
0000707649fdc0fc  ptest xmm1, xmm1
0000707649fdc101  jnz 0x0000707649FDE2CB
0000707649fdc107  lea r12, [rax+0xD0]
0000707649fdc10e  movups xmm1, [r13+r12*1]
0000707649fdc114  vmovaps xmm3, [rsp+0xD0]
0000707649fdc11d  vmovaps [rsp+0x70], xmm1
0000707649fdc123  movaps xmm5, xmm6
0000707649fdc126  addpd xmm5, xmm3
0000707649fdc12a  vcmppd xmm1, xmm5, xmm5, 0x03
0000707649fdc12f  ptest xmm1, xmm1
0000707649fdc134  jnz 0x0000707649FDE415
0000707649fdc13a  vmovaps xmm1, [rsp+0x60]
0000707649fdc140  vpermilpd xmm1, xmm1, 0x00
0000707649fdc146  movaps xmm6, xmm9
0000707649fdc14a  mulpd xmm6, xmm1
0000707649fdc14e  vcmppd xmm3, xmm6, xmm6, 0x03
0000707649fdc153  ptest xmm3, xmm3
0000707649fdc158  jnz 0x0000707649FDE555
0000707649fdc15e  movaps [r15+0x260], xmm6
0000707649fdc166  vxorps xmm1, xmm1, xmm1
0000707649fdc16a  vpbroadcastq xmm1, xmm1
0000707649fdc16f  movaps [r15+0x1B0], xmm1
0000707649fdc177  vmovaps xmm1, [rsp+0x60]
0000707649fdc17d  vpermilpd xmm1, xmm1, 0x00
0000707649fdc183  vmovaps xmm3, [rsp+0x70]
0000707649fdc189  vmovaps [rsp+0x70], xmm15
0000707649fdc18f  movaps xmm9, xmm3
0000707649fdc193  mulpd xmm9, xmm1
0000707649fdc198  vcmppd xmm15, xmm9, xmm9, 0x03
0000707649fdc19e  ptest xmm15, xmm15
0000707649fdc1a4  jnz 0x0000707649FDE696
0000707649fdc1aa  lea r12, [rax+0xC0]
0000707649fdc1b1  movups xmm1, [r13+r12*1]
0000707649fdc1b7  vmovaps xmm3, [rsp+0xC0]
0000707649fdc1c0  vmovaps [rsp+0x80], xmm1
0000707649fdc1c9  movaps xmm15, xmm3
0000707649fdc1cd  addpd xmm15, xmm7
0000707649fdc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
0000707649fdc1d8  ptest xmm1, xmm1
0000707649fdc1dd  jnz 0x0000707649FDE7E2
0000707649fdc1e3  vmovaps [rsp+0xC0], xmm13
0000707649fdc1ec  vmovaps xmm1, [rsp+0xC0]
0000707649fdc1f5  por xmm13, xmm1
0000707649fdc1fa  movaps [r15+0x270], xmm13
0000707649fdc202  vmovaps xmm1, [rsp+0xB0]
0000707649fdc20b  vmovaps xmm7, [rsp+0xB0]
0000707649fdc214  por xmm1, xmm7
0000707649fdc218  movaps [r15+0x1A0], xmm1
0000707649fdc220  vmovaps xmm1, [rsp+0x60]
0000707649fdc226  vpermilpd xmm1, xmm1, 0x00
0000707649fdc22c  vmovaps [rsp+0xB0], xmm1
0000707649fdc235  vmovaps xmm1, [rsp+0x80]
0000707649fdc23e  vmovaps [rsp+0x80], xmm15
0000707649fdc247  vmovaps xmm15, [rsp+0xB0]
0000707649fdc250  vmovaps [rsp+0xB0], xmm14
0000707649fdc259  movaps xmm3, xmm1
0000707649fdc25c  mulpd xmm3, xmm15
0000707649fdc261  vcmppd xmm14, xmm3, xmm3, 0x03
0000707649fdc266  ptest xmm14, xmm14
0000707649fdc26c  jnz 0x0000707649FDE924
0000707649fdc272  lea r12, [rax+0x20]
0000707649fdc276  movups xmm1, [r13+r12*1]
0000707649fdc27c  movaps [r15+0x110], xmm1
0000707649fdc284  vmovaps xmm14, [rsp+0x70]
0000707649fdc28a  vmovaps [rsp+0x70], xmm1
0000707649fdc290  movaps xmm15, xmm14
0000707649fdc294  addpd xmm15, xmm4
0000707649fdc299  vcmppd xmm1, xmm15, xmm15, 0x03
0000707649fdc29f  ptest xmm1, xmm1
0000707649fdc2a4  jnz 0x0000707649FDEA6F
0000707649fdc2aa  vmovaps xmm1, [rsp+0x60]
0000707649fdc2b0  vpermilpd xmm1, xmm1, 0x00
0000707649fdc2b6  movaps xmm14, xmm2
0000707649fdc2ba  mulpd xmm14, xmm1
0000707649fdc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
0000707649fdc2c5  ptest xmm4, xmm4
0000707649fdc2ca  jnz 0x0000707649FDEBB2
0000707649fdc2d0  vmovaps xmm4, [rsp+0x50]
0000707649fdc2d6  movaps xmm1, xmm4
0000707649fdc2d9  addpd xmm1, xmm9
0000707649fdc2de  vcmppd xmm2, xmm1, xmm1, 0x03
0000707649fdc2e3  ptest xmm2, xmm2
0000707649fdc2e8  jnz 0x0000707649FDECF4
0000707649fdc2ee  vmovaps xmm9, [rsp+0x30]
0000707649fdc2f4  vpermilpd xmm9, xmm9, 0x00
0000707649fdc2fa  vmovaps xmm2, [rsp+0x70]
0000707649fdc300  vmovaps [rsp+0x50], xmm1
0000707649fdc306  movaps xmm4, xmm2
0000707649fdc309  mulpd xmm4, xmm9
0000707649fdc30e  vcmppd xmm1, xmm4, xmm4, 0x03
0000707649fdc313  ptest xmm1, xmm1
0000707649fdc318  jnz 0x0000707649FDEE35
0000707649fdc31e  vmovaps xmm1, [rsp+0x30]
0000707649fdc324  vpermilpd xmm1, xmm1, 0x00
0000707649fdc32a  vmovaps xmm2, [rsp+0x90]
0000707649fdc333  vmovaps [rsp+0x60], xmm15
0000707649fdc339  movaps xmm9, xmm2
0000707649fdc33d  mulpd xmm9, xmm1
0000707649fdc342  vcmppd xmm15, xmm9, xmm9, 0x03
0000707649fdc348  ptest xmm15, xmm15
0000707649fdc34e  jnz 0x0000707649FDEF76
0000707649fdc354  vmovaps xmm15, [rsp+0x80]
0000707649fdc35d  movaps xmm1, xmm15
0000707649fdc361  addpd xmm1, xmm6
0000707649fdc365  vcmppd xmm2, xmm1, xmm1, 0x03
0000707649fdc36a  ptest xmm2, xmm2
0000707649fdc36f  jnz 0x0000707649FDF0B8
0000707649fdc375  movaps xmm15, xmm5
0000707649fdc379  addpd xmm15, xmm3
0000707649fdc37e  vcmppd xmm6, xmm15, xmm15, 0x03
0000707649fdc384  ptest xmm6, xmm6
0000707649fdc389  jnz 0x0000707649FDF1F9
0000707649fdc38f  vmovaps xmm6, [rsp+0x30]
0000707649fdc395  vpermilpd xmm6, xmm6, 0x00
0000707649fdc39b  movaps xmm5, xmm8
0000707649fdc39f  mulpd xmm5, xmm6
0000707649fdc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
0000707649fdc3a8  ptest xmm3, xmm3
0000707649fdc3ad  jnz 0x0000707649FDF33B
0000707649fdc3b3  vmovaps xmm8, [rsp+0x30]
0000707649fdc3b9  vpermilpd xmm8, xmm8, 0x00
0000707649fdc3bf  movaps xmm6, xmm10
0000707649fdc3c3  mulpd xmm6, xmm8
0000707649fdc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
0000707649fdc3cd  ptest xmm3, xmm3
0000707649fdc3d2  jnz 0x0000707649FDF47C
0000707649fdc3d8  vmovaps xmm8, [rsp+0x60]
0000707649fdc3de  movaps xmm10, xmm8
0000707649fdc3e2  addpd xmm10, xmm14
0000707649fdc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
0000707649fdc3ed  ptest xmm3, xmm3
0000707649fdc3f2  jnz 0x0000707649FDF5BE
0000707649fdc3f8  vmovaps xmm8, [rsp+0x50]
0000707649fdc3fe  movaps xmm14, xmm8
0000707649fdc402  addpd xmm14, xmm4
0000707649fdc407  vcmppd xmm3, xmm14, xmm14, 0x03
0000707649fdc40d  ptest xmm3, xmm3
0000707649fdc412  jnz 0x0000707649FDF702
0000707649fdc418  vmovaps xmm8, [rsp+0x40]
0000707649fdc41e  vpermilpd xmm8, xmm8, 0x00
0000707649fdc424  movaps xmm4, xmm13
0000707649fdc428  mulpd xmm4, xmm8
0000707649fdc42d  vcmppd xmm3, xmm4, xmm4, 0x03
0000707649fdc432  ptest xmm3, xmm3
0000707649fdc437  jnz 0x0000707649FDF845
0000707649fdc43d  movaps xmm13, xmm15
0000707649fdc441  addpd xmm13, xmm9
0000707649fdc446  vcmppd xmm8, xmm13, xmm13, 0x03
0000707649fdc44c  ptest xmm8, xmm8
0000707649fdc452  jnz 0x0000707649FDF987
0000707649fdc458  movaps xmm15, xmm1
0000707649fdc45c  addpd xmm15, xmm5
0000707649fdc461  vcmppd xmm9, xmm15, xmm15, 0x03
0000707649fdc467  ptest xmm9, xmm9
0000707649fdc46d  jnz 0x0000707649FDFACB
0000707649fdc473  vmovaps [rsp+0x30], xmm11
0000707649fdc479  vmovaps xmm1, [rsp+0x30]
0000707649fdc47f  por xmm11, xmm1
0000707649fdc484  movaps [r15+0x250], xmm11
0000707649fdc48c  vmovaps [rsp+0x30], xmm12
0000707649fdc492  vmovaps xmm1, [rsp+0x30]
0000707649fdc498  por xmm12, xmm1
0000707649fdc49d  movaps [r15+0x2A0], xmm12
0000707649fdc4a5  vmovaps xmm1, [rsp+0xA0]
0000707649fdc4ae  vmovaps xmm11, [rsp+0xA0]
0000707649fdc4b7  por xmm1, xmm11
0000707649fdc4bc  movaps [r15+0x1D0], xmm1
0000707649fdc4c4  lea r12, [rax+0x40]
0000707649fdc4c8  movups xmm1, [r13+r12*1]
0000707649fdc4ce  movaps [r15+0x2C0], xmm1
0000707649fdc4d6  vmovaps xmm11, [rsp+0x40]
0000707649fdc4dc  vpermilpd xmm11, xmm11, 0x00
0000707649fdc4e2  vmovaps xmm8, [rsp+0xE0]
0000707649fdc4eb  movaps xmm9, xmm8
0000707649fdc4ef  mulpd xmm9, xmm11
0000707649fdc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
0000707649fdc4fa  ptest xmm5, xmm5
0000707649fdc4ff  jnz 0x0000707649FDFC17
0000707649fdc505  movaps xmm11, xmm10
0000707649fdc509  addpd xmm11, xmm6
0000707649fdc50e  vcmppd xmm8, xmm11, xmm11, 0x03
0000707649fdc514  ptest xmm8, xmm8
0000707649fdc51a  jnz 0x0000707649FDFD5B
0000707649fdc520  movaps xmm10, xmm14
0000707649fdc524  addpd xmm10, xmm4
0000707649fdc529  vcmppd xmm8, xmm10, xmm10, 0x03
0000707649fdc52f  ptest xmm8, xmm8
0000707649fdc535  jnz 0x0000707649FDFE9E
0000707649fdc53b  vmovaps xmm14, [rsp+0x40]
0000707649fdc541  vpermilpd xmm14, xmm14, 0x00
0000707649fdc547  movaps xmm8, xmm1
0000707649fdc54b  mulpd xmm8, xmm14
0000707649fdc550  vcmppd xmm6, xmm8, xmm8, 0x03
0000707649fdc556  ptest xmm6, xmm6
0000707649fdc55b  jnz 0x0000707649FDFFE1
0000707649fdc561  movaps xmm1, [r15+0x2B0]
0000707649fdc569  vmovaps xmm14, [rsp+0x40]
0000707649fdc56f  vpermilpd xmm14, xmm14, 0x00
0000707649fdc575  movaps xmm6, xmm1
0000707649fdc578  mulpd xmm6, xmm14
0000707649fdc57d  vcmppd xmm5, xmm6, xmm6, 0x03
0000707649fdc582  ptest xmm5, xmm5
0000707649fdc587  jnz 0x0000707649FE0124
0000707649fdc58d  vmovaps xmm1, [rsp+0x10]
0000707649fdc593  vpermilpd xmm1, xmm1, 0x00
0000707649fdc599  movaps xmm14, xmm12
0000707649fdc59d  mulpd xmm14, xmm1
0000707649fdc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
0000707649fdc5a8  ptest xmm5, xmm5
0000707649fdc5ad  jnz 0x0000707649FE0265
0000707649fdc5b3  movaps xmm1, xmm13
0000707649fdc5b7  addpd xmm1, xmm9
0000707649fdc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
0000707649fdc5c1  ptest xmm12, xmm12
0000707649fdc5c7  jnz 0x0000707649FE03A8
0000707649fdc5cd  vmovaps xmm13, [rsp+0x10]
0000707649fdc5d3  vpermilpd xmm13, xmm13, 0x00
0000707649fdc5d9  movaps xmm12, xmm7
0000707649fdc5dd  mulpd xmm12, xmm13
0000707649fdc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
0000707649fdc5e8  ptest xmm9, xmm9
0000707649fdc5ee  jnz 0x0000707649FE04EA
0000707649fdc5f4  movaps xmm13, xmm15
0000707649fdc5f8  addpd xmm13, xmm8
0000707649fdc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
0000707649fdc603  ptest xmm9, xmm9
0000707649fdc609  jnz 0x0000707649FE062D
0000707649fdc60f  movaps xmm15, [r15+0x290]
0000707649fdc617  vmovaps xmm9, [rsp+0x10]
0000707649fdc61d  vpermilpd xmm9, xmm9, 0x00
0000707649fdc623  movaps xmm8, xmm15
0000707649fdc627  mulpd xmm8, xmm9
0000707649fdc62c  vcmppd xmm7, xmm8, xmm8, 0x03
0000707649fdc632  ptest xmm7, xmm7
0000707649fdc637  jnz 0x0000707649FE0771
0000707649fdc63d  movaps xmm15, xmm11
0000707649fdc641  addpd xmm15, xmm6
0000707649fdc646  vcmppd xmm9, xmm15, xmm15, 0x03
0000707649fdc64c  ptest xmm9, xmm9
0000707649fdc652  jnz 0x0000707649FE08B5
0000707649fdc658  movaps xmm11, [r15+0x1E0]
0000707649fdc660  vmovaps xmm9, [rsp+0x10]
0000707649fdc666  vpermilpd xmm9, xmm9, 0x00
0000707649fdc66c  movaps xmm7, xmm11
0000707649fdc670  mulpd xmm7, xmm9
0000707649fdc675  vcmppd xmm6, xmm7, xmm7, 0x03
0000707649fdc67a  ptest xmm6, xmm6
0000707649fdc67f  jnz 0x0000707649FE09F8
0000707649fdc685  movaps xmm11, xmm10
0000707649fdc689  addpd xmm11, xmm14
0000707649fdc68e  vcmppd xmm9, xmm11, xmm11, 0x03
0000707649fdc694  ptest xmm9, xmm9
0000707649fdc69a  jnz 0x0000707649FE0B3A
0000707649fdc6a0  lea r12, [rax+0x70]
0000707649fdc6a4  movups xmm14, [r13+r12*1]
0000707649fdc6aa  movaps [r15+0x240], xmm14
0000707649fdc6b2  movaps xmm10, xmm1
0000707649fdc6b6  addpd xmm10, xmm12
0000707649fdc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
0000707649fdc6c1  ptest xmm9, xmm9
0000707649fdc6c7  jnz 0x0000707649FE0C88
0000707649fdc6cd  movaps [r15+0x170], xmm10
0000707649fdc6d5  vmovaps xmm1, [rsp+0x20]
0000707649fdc6db  vpermilpd xmm1, xmm1, 0x00
0000707649fdc6e1  movaps xmm12, xmm14
0000707649fdc6e5  mulpd xmm12, xmm1
0000707649fdc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
0000707649fdc6f0  ptest xmm9, xmm9
0000707649fdc6f6  jnz 0x0000707649FE0DCB
0000707649fdc6fc  vmovaps xmm1, [rsp+0x20]
0000707649fdc702  vpermilpd xmm1, xmm1, 0x00
0000707649fdc708  vmovaps xmm9, [rsp+0xB0]
0000707649fdc711  movaps xmm14, xmm9
0000707649fdc715  mulpd xmm14, xmm1
0000707649fdc71a  vcmppd xmm6, xmm14, xmm14, 0x03
0000707649fdc720  ptest xmm6, xmm6
0000707649fdc725  jnz 0x0000707649FE0F0E
0000707649fdc72b  movaps [r15+0x180], xmm14
0000707649fdc733  movaps xmm1, xmm13
0000707649fdc737  addpd xmm1, xmm8
0000707649fdc73c  vcmppd xmm9, xmm1, xmm1, 0x03
0000707649fdc741  ptest xmm9, xmm9
0000707649fdc747  jnz 0x0000707649FE1051
0000707649fdc74d  movaps [r15+0x210], xmm1
0000707649fdc755  movups xmm13, [r13+rax*1]
0000707649fdc75b  lea r12, [rax+0x10]
0000707649fdc75f  movups xmm9, [r13+r12*1]
0000707649fdc765  movaps [r15+0x230], xmm9
0000707649fdc76d  movaps xmm8, xmm15
0000707649fdc771  addpd xmm8, xmm7
0000707649fdc776  vcmppd xmm6, xmm8, xmm8, 0x03
0000707649fdc77c  ptest xmm6, xmm6
0000707649fdc781  jnz 0x0000707649FE11A7
0000707649fdc787  movaps [r15+0x130], xmm8
0000707649fdc78f  vmovaps xmm15, [rsp+0x20]
0000707649fdc795  vpermilpd xmm15, xmm15, 0x00
0000707649fdc79b  movaps xmm7, xmm9
0000707649fdc79f  mulpd xmm7, xmm15
0000707649fdc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
0000707649fdc7a9  ptest xmm6, xmm6
0000707649fdc7ae  jnz 0x0000707649FE12EA
0000707649fdc7b4  movaps [r15+0x220], xmm7
0000707649fdc7bc  vmovaps xmm15, [rsp+0x20]
0000707649fdc7c2  vpermilpd xmm15, xmm15, 0x00
0000707649fdc7c8  movaps xmm9, xmm13
0000707649fdc7cc  mulpd xmm9, xmm15
0000707649fdc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
0000707649fdc7d7  ptest xmm6, xmm6
0000707649fdc7dc  jnz 0x0000707649FE142C
0000707649fdc7e2  movaps xmm15, xmm11
0000707649fdc7e6  addpd xmm15, xmm12
0000707649fdc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
0000707649fdc7f1  ptest xmm13, xmm13
0000707649fdc7f7  jnz 0x0000707649FE1570
0000707649fdc7fd  movaps [r15+0x140], xmm15
0000707649fdc805  movaps xmm13, xmm10
0000707649fdc809  addpd xmm13, xmm14
0000707649fdc80e  vcmppd xmm12, xmm13, xmm13, 0x03
0000707649fdc814  ptest xmm12, xmm12
0000707649fdc81a  jnz 0x0000707649FE16B4
0000707649fdc820  movaps [r15+0x150], xmm13
0000707649fdc828  movaps xmm14, xmm1
0000707649fdc82c  addpd xmm14, xmm7
0000707649fdc831  vcmppd xmm12, xmm14, xmm14, 0x03
0000707649fdc837  ptest xmm12, xmm12
0000707649fdc83d  jnz 0x0000707649FE17F8
0000707649fdc843  movaps [r15+0x160], xmm14
0000707649fdc84b  movaps xmm1, xmm8
0000707649fdc84f  addpd xmm1, xmm9
0000707649fdc854  vcmppd xmm12, xmm1, xmm1, 0x03
0000707649fdc859  ptest xmm12, xmm12
0000707649fdc85f  jnz 0x0000707649FE193A
0000707649fdc865  movaps [r15+0x120], xmm1
0000707649fdc86d  movups [r13+r14*1], xmm15
0000707649fdc873  lea rax, [r14+0x10]
0000707649fdc877  movups [r13+rax*1], xmm13
0000707649fdc87d  lea rax, [r14+0x20]
0000707649fdc881  movups [r13+rax*1], xmm14
0000707649fdc887  lea rax, [r14+0x30]
0000707649fdc88b  movups [r13+rax*1], xmm1
0000707649fdc891  mov eax, [r15+0x108]
0000707649fdc898  sahf
0000707649fdc899  jnz 0x0000707649FDC8CB
0000707649fdc89b  cmp dword ptr [r15+0x318], 0x00
0000707649fdc8a3  jz 0x0000707649FDB900
0000707649fdc8a9  nop [rax+rax*1], ax
0000707649fdc8b2  nop [rax+rax*1], eax
0000707649fdc8ba  mov eax, 0x410444
0000707649fdc8bf  mov [r15+0x100], rax
0000707649fdc8c6  jmp 0x0000707649DFE110
0000707649fdc8cb  cmp dword ptr [r15+0x318], 0x00
0000707649fdc8d3  jz 0x0000707649FD57E0
0000707649fdc8d9  nop [rax+rax*1], ax
0000707649fdc8e2  nop [rax+rax*1], eax
0000707649fdc8ea  mov eax, 0x410278
0000707649fdc8ef  mov [r15+0x100], rax
0000707649fdc8f6  jmp 0x0000707649DFE110
0000707649fdc8fb  int3
0000707649fdc8fc  call 0x0000707649EE27E0
0000707649fdc901  jmp 0x0000707649FDB9DF
0000707649fdc906  call 0x0000707649EE1570
0000707649fdc90b  jmp 0x0000707649FDB9E8
0000707649fdc910  call 0x0000707649EE27E0
0000707649fdc915  jmp 0x0000707649FDBA44
0000707649fdc91a  call 0x0000707649EE1570
0000707649fdc91f  jmp 0x0000707649FDBA4D
0000707649fdc924  call 0x0000707649EE27E0
0000707649fdc929  jmp 0x0000707649FDBA90
0000707649fdc92e  call 0x0000707649EE1570
0000707649fdc933  jmp 0x0000707649FDBA99
0000707649fdc938  call 0x0000707649E0DC20
0000707649fdc93d  jmp 0x0000707649FDBAD8
0000707649fdc942  call 0x0000707649ED59C0
0000707649fdc947  jmp 0x0000707649FDBAEB
0000707649fdc94c  call 0x0000707649EE0E30
0000707649fdc951  jmp 0x0000707649FDBB09
0000707649fdc956  call 0x0000707649EDFBC0
0000707649fdc95b  jmp 0x0000707649FDBB13
0000707649fdc960  call 0x0000707649EDE950
0000707649fdc965  jmp 0x0000707649FDBB1D
0000707649fdc96a  sub rsp, 0x08
0000707649fdc96e  push rax
0000707649fdc96f  push rcx
0000707649fdc970  push rdx
0000707649fdc971  push rdi
0000707649fdc972  push rsi
0000707649fdc973  push r8
0000707649fdc975  push r9
0000707649fdc977  push r10
0000707649fdc979  push r11
0000707649fdc97b  sub rsp, 0xF0
0000707649fdc982  vmovaps [rsp], xmm0
0000707649fdc987  vmovaps [rsp+0x10], xmm1
0000707649fdc98d  vmovaps [rsp+0x20], xmm2
0000707649fdc993  vmovaps [rsp+0x30], xmm3
0000707649fdc999  vmovaps [rsp+0x40], xmm4
0000707649fdc99f  vmovaps [rsp+0x50], xmm5
0000707649fdc9a5  vmovaps [rsp+0x60], xmm6
0000707649fdc9ab  vmovaps [rsp+0x70], xmm7
0000707649fdc9b1  vmovaps [rsp+0x80], xmm9
0000707649fdc9ba  vmovaps [rsp+0x90], xmm10
0000707649fdc9c3  vmovaps [rsp+0xA0], xmm11
0000707649fdc9cc  vmovaps [rsp+0xB0], xmm12
0000707649fdc9d5  vmovaps [rsp+0xC0], xmm13
0000707649fdc9de  vmovaps [rsp+0xD0], xmm14
0000707649fdc9e7  vmovaps [rsp+0xE0], xmm15
0000707649fdc9f0  sub rsp, 0x30
0000707649fdc9f4  movaps [rsp], xmm8
0000707649fdc9f9  movaps [rsp+0x10], xmm12
0000707649fdc9ff  movaps [rsp+0x20], xmm15
0000707649fdca05  lea rdi, [rsp]
0000707649fdca09  mov esi, 0x00
0000707649fdca0e  mov rax, 0x59CB0B054530
0000707649fdca18  call rax
0000707649fdca1a  movaps xmm8, [rsp]
0000707649fdca1f  add rsp, 0x30
0000707649fdca23  vmovaps xmm0, [rsp]
0000707649fdca28  vmovaps xmm1, [rsp+0x10]
0000707649fdca2e  vmovaps xmm2, [rsp+0x20]
0000707649fdca34  vmovaps xmm3, [rsp+0x30]
0000707649fdca3a  vmovaps xmm4, [rsp+0x40]
0000707649fdca40  vmovaps xmm5, [rsp+0x50]
0000707649fdca46  vmovaps xmm6, [rsp+0x60]
0000707649fdca4c  vmovaps xmm7, [rsp+0x70]
0000707649fdca52  vmovaps xmm9, [rsp+0x80]
0000707649fdca5b  vmovaps xmm10, [rsp+0x90]
0000707649fdca64  vmovaps xmm11, [rsp+0xA0]
0000707649fdca6d  vmovaps xmm12, [rsp+0xB0]
0000707649fdca76  vmovaps xmm13, [rsp+0xC0]
0000707649fdca7f  vmovaps xmm14, [rsp+0xD0]
0000707649fdca88  vmovaps xmm15, [rsp+0xE0]
0000707649fdca91  add rsp, 0xF0
0000707649fdca98  pop r11
0000707649fdca9a  pop r10
0000707649fdca9c  pop r9
0000707649fdca9e  pop r8
0000707649fdcaa0  pop rsi
0000707649fdcaa1  pop rdi
0000707649fdcaa2  pop rdx
0000707649fdcaa3  pop rcx
0000707649fdcaa4  pop rax
0000707649fdcaa5  add rsp, 0x08
0000707649fdcaa9  jmp 0x0000707649FDBB47
0000707649fdcaae  sub rsp, 0x08
0000707649fdcab2  push rax
0000707649fdcab3  push rcx
0000707649fdcab4  push rdx
0000707649fdcab5  push rdi
0000707649fdcab6  push rsi
0000707649fdcab7  push r8
0000707649fdcab9  push r9
0000707649fdcabb  push r10
0000707649fdcabd  push r11
0000707649fdcabf  sub rsp, 0xF0
0000707649fdcac6  vmovaps [rsp], xmm0
0000707649fdcacb  vmovaps [rsp+0x10], xmm1
0000707649fdcad1  vmovaps [rsp+0x20], xmm2
0000707649fdcad7  vmovaps [rsp+0x30], xmm3
0000707649fdcadd  vmovaps [rsp+0x40], xmm4
0000707649fdcae3  vmovaps [rsp+0x50], xmm5
0000707649fdcae9  vmovaps [rsp+0x60], xmm6
0000707649fdcaef  vmovaps [rsp+0x70], xmm8
0000707649fdcaf5  vmovaps [rsp+0x80], xmm9
0000707649fdcafe  vmovaps [rsp+0x90], xmm10
0000707649fdcb07  vmovaps [rsp+0xA0], xmm11
0000707649fdcb10  vmovaps [rsp+0xB0], xmm12
0000707649fdcb19  vmovaps [rsp+0xC0], xmm13
0000707649fdcb22  vmovaps [rsp+0xD0], xmm14
0000707649fdcb2b  vmovaps [rsp+0xE0], xmm15
0000707649fdcb34  sub rsp, 0x30
0000707649fdcb38  movaps [rsp], xmm7
0000707649fdcb3c  movaps [rsp+0x10], xmm9
0000707649fdcb42  movaps [rsp+0x20], xmm15
0000707649fdcb48  lea rdi, [rsp]
0000707649fdcb4c  mov esi, 0x00
0000707649fdcb51  mov rax, 0x59CB0B054530
0000707649fdcb5b  call rax
0000707649fdcb5d  movaps xmm7, [rsp]
0000707649fdcb61  add rsp, 0x30
0000707649fdcb65  vmovaps xmm0, [rsp]
0000707649fdcb6a  vmovaps xmm1, [rsp+0x10]
0000707649fdcb70  vmovaps xmm2, [rsp+0x20]
0000707649fdcb76  vmovaps xmm3, [rsp+0x30]
0000707649fdcb7c  vmovaps xmm4, [rsp+0x40]
0000707649fdcb82  vmovaps xmm5, [rsp+0x50]
0000707649fdcb88  vmovaps xmm6, [rsp+0x60]
0000707649fdcb8e  vmovaps xmm8, [rsp+0x70]
0000707649fdcb94  vmovaps xmm9, [rsp+0x80]
0000707649fdcb9d  vmovaps xmm10, [rsp+0x90]
0000707649fdcba6  vmovaps xmm11, [rsp+0xA0]
0000707649fdcbaf  vmovaps xmm12, [rsp+0xB0]
0000707649fdcbb8  vmovaps xmm13, [rsp+0xC0]
0000707649fdcbc1  vmovaps xmm14, [rsp+0xD0]
0000707649fdcbca  vmovaps xmm15, [rsp+0xE0]
0000707649fdcbd3  add rsp, 0xF0
0000707649fdcbda  pop r11
0000707649fdcbdc  pop r10
0000707649fdcbde  pop r9
0000707649fdcbe0  pop r8
0000707649fdcbe2  pop rsi
0000707649fdcbe3  pop rdi
0000707649fdcbe4  pop rdx
0000707649fdcbe5  pop rcx
0000707649fdcbe6  pop rax
0000707649fdcbe7  add rsp, 0x08
0000707649fdcbeb  jmp 0x0000707649FDBB75
0000707649fdcbf0  sub rsp, 0x08
0000707649fdcbf4  push rax
0000707649fdcbf5  push rcx
0000707649fdcbf6  push rdx
0000707649fdcbf7  push rdi
0000707649fdcbf8  push rsi
0000707649fdcbf9  push r8
0000707649fdcbfb  push r9
0000707649fdcbfd  push r10
0000707649fdcbff  push r11
0000707649fdcc01  sub rsp, 0xF0
0000707649fdcc08  vmovaps [rsp], xmm0
0000707649fdcc0d  vmovaps [rsp+0x10], xmm1
0000707649fdcc13  vmovaps [rsp+0x20], xmm2
0000707649fdcc19  vmovaps [rsp+0x30], xmm3
0000707649fdcc1f  vmovaps [rsp+0x40], xmm4
0000707649fdcc25  vmovaps [rsp+0x50], xmm5
0000707649fdcc2b  vmovaps [rsp+0x60], xmm6
0000707649fdcc31  vmovaps [rsp+0x70], xmm7
0000707649fdcc37  vmovaps [rsp+0x80], xmm8
0000707649fdcc40  vmovaps [rsp+0x90], xmm10
0000707649fdcc49  vmovaps [rsp+0xA0], xmm11
0000707649fdcc52  vmovaps [rsp+0xB0], xmm12
0000707649fdcc5b  vmovaps [rsp+0xC0], xmm13
0000707649fdcc64  vmovaps [rsp+0xD0], xmm14
0000707649fdcc6d  vmovaps [rsp+0xE0], xmm15
0000707649fdcc76  sub rsp, 0x30
0000707649fdcc7a  movaps [rsp], xmm9
0000707649fdcc7f  movaps [rsp+0x10], xmm12
0000707649fdcc85  movaps [rsp+0x20], xmm10
0000707649fdcc8b  lea rdi, [rsp]
0000707649fdcc8f  mov esi, 0x00
0000707649fdcc94  mov rax, 0x59CB0B054530
0000707649fdcc9e  call rax
0000707649fdcca0  movaps xmm9, [rsp]
0000707649fdcca5  add rsp, 0x30
0000707649fdcca9  vmovaps xmm0, [rsp]
0000707649fdccae  vmovaps xmm1, [rsp+0x10]
0000707649fdccb4  vmovaps xmm2, [rsp+0x20]
0000707649fdccba  vmovaps xmm3, [rsp+0x30]
0000707649fdccc0  vmovaps xmm4, [rsp+0x40]
0000707649fdccc6  vmovaps xmm5, [rsp+0x50]
0000707649fdcccc  vmovaps xmm6, [rsp+0x60]
0000707649fdccd2  vmovaps xmm7, [rsp+0x70]
0000707649fdccd8  vmovaps xmm8, [rsp+0x80]
0000707649fdcce1  vmovaps xmm10, [rsp+0x90]
0000707649fdccea  vmovaps xmm11, [rsp+0xA0]
0000707649fdccf3  vmovaps xmm12, [rsp+0xB0]
0000707649fdccfc  vmovaps xmm13, [rsp+0xC0]
0000707649fdcd05  vmovaps xmm14, [rsp+0xD0]
0000707649fdcd0e  vmovaps xmm15, [rsp+0xE0]
0000707649fdcd17  add rsp, 0xF0
0000707649fdcd1e  pop r11
0000707649fdcd20  pop r10
0000707649fdcd22  pop r9
0000707649fdcd24  pop r8
0000707649fdcd26  pop rsi
0000707649fdcd27  pop rdi
0000707649fdcd28  pop rdx
0000707649fdcd29  pop rcx
0000707649fdcd2a  pop rax
0000707649fdcd2b  add rsp, 0x08
0000707649fdcd2f  jmp 0x0000707649FDBB99
0000707649fdcd34  sub rsp, 0x08
0000707649fdcd38  push rax
0000707649fdcd39  push rcx
0000707649fdcd3a  push rdx
0000707649fdcd3b  push rdi
0000707649fdcd3c  push rsi
0000707649fdcd3d  push r8
0000707649fdcd3f  push r9
0000707649fdcd41  push r10
0000707649fdcd43  push r11
0000707649fdcd45  sub rsp, 0xF0
0000707649fdcd4c  vmovaps [rsp], xmm0
0000707649fdcd51  vmovaps [rsp+0x10], xmm1
0000707649fdcd57  vmovaps [rsp+0x20], xmm2
0000707649fdcd5d  vmovaps [rsp+0x30], xmm3
0000707649fdcd63  vmovaps [rsp+0x40], xmm4
0000707649fdcd69  vmovaps [rsp+0x50], xmm5
0000707649fdcd6f  vmovaps [rsp+0x60], xmm6
0000707649fdcd75  vmovaps [rsp+0x70], xmm7
0000707649fdcd7b  vmovaps [rsp+0x80], xmm8
0000707649fdcd84  vmovaps [rsp+0x90], xmm9
0000707649fdcd8d  vmovaps [rsp+0xA0], xmm11
0000707649fdcd96  vmovaps [rsp+0xB0], xmm12
0000707649fdcd9f  vmovaps [rsp+0xC0], xmm13
0000707649fdcda8  vmovaps [rsp+0xD0], xmm14
0000707649fdcdb1  vmovaps [rsp+0xE0], xmm15
0000707649fdcdba  sub rsp, 0x30
0000707649fdcdbe  movaps [rsp], xmm10
0000707649fdcdc3  movaps [rsp+0x10], xmm12
0000707649fdcdc9  movaps [rsp+0x20], xmm11
0000707649fdcdcf  lea rdi, [rsp]
0000707649fdcdd3  mov esi, 0x00
0000707649fdcdd8  mov rax, 0x59CB0B054530
0000707649fdcde2  call rax
0000707649fdcde4  movaps xmm10, [rsp]
0000707649fdcde9  add rsp, 0x30
0000707649fdcded  vmovaps xmm0, [rsp]
0000707649fdcdf2  vmovaps xmm1, [rsp+0x10]
0000707649fdcdf8  vmovaps xmm2, [rsp+0x20]
0000707649fdcdfe  vmovaps xmm3, [rsp+0x30]
0000707649fdce04  vmovaps xmm4, [rsp+0x40]
0000707649fdce0a  vmovaps xmm5, [rsp+0x50]
0000707649fdce10  vmovaps xmm6, [rsp+0x60]
0000707649fdce16  vmovaps xmm7, [rsp+0x70]
0000707649fdce1c  vmovaps xmm8, [rsp+0x80]
0000707649fdce25  vmovaps xmm9, [rsp+0x90]
0000707649fdce2e  vmovaps xmm11, [rsp+0xA0]
0000707649fdce37  vmovaps xmm12, [rsp+0xB0]
0000707649fdce40  vmovaps xmm13, [rsp+0xC0]
0000707649fdce49  vmovaps xmm14, [rsp+0xD0]
0000707649fdce52  vmovaps xmm15, [rsp+0xE0]
0000707649fdce5b  add rsp, 0xF0
0000707649fdce62  pop r11
0000707649fdce64  pop r10
0000707649fdce66  pop r9
0000707649fdce68  pop r8
0000707649fdce6a  pop rsi
0000707649fdce6b  pop rdi
0000707649fdce6c  pop rdx
0000707649fdce6d  pop rcx
0000707649fdce6e  pop rax
0000707649fdce6f  add rsp, 0x08
0000707649fdce73  jmp 0x0000707649FDBBB3
0000707649fdce78  sub rsp, 0x08
0000707649fdce7c  push rax
0000707649fdce7d  push rcx
0000707649fdce7e  push rdx
0000707649fdce7f  push rdi
0000707649fdce80  push rsi
0000707649fdce81  push r8
0000707649fdce83  push r9
0000707649fdce85  push r10
0000707649fdce87  push r11
0000707649fdce89  sub rsp, 0xF0
0000707649fdce90  vmovaps [rsp], xmm0
0000707649fdce95  vmovaps [rsp+0x10], xmm1
0000707649fdce9b  vmovaps [rsp+0x20], xmm2
0000707649fdcea1  vmovaps [rsp+0x30], xmm3
0000707649fdcea7  vmovaps [rsp+0x40], xmm4
0000707649fdcead  vmovaps [rsp+0x50], xmm5
0000707649fdceb3  vmovaps [rsp+0x60], xmm7
0000707649fdceb9  vmovaps [rsp+0x70], xmm8
0000707649fdcebf  vmovaps [rsp+0x80], xmm9
0000707649fdcec8  vmovaps [rsp+0x90], xmm10
0000707649fdced1  vmovaps [rsp+0xA0], xmm11
0000707649fdceda  vmovaps [rsp+0xB0], xmm12
0000707649fdcee3  vmovaps [rsp+0xC0], xmm13
0000707649fdceec  vmovaps [rsp+0xD0], xmm14
0000707649fdcef5  vmovaps [rsp+0xE0], xmm15
0000707649fdcefe  sub rsp, 0x30
0000707649fdcf02  movaps [rsp], xmm6
0000707649fdcf06  movaps [rsp+0x10], xmm12
0000707649fdcf0c  movaps [rsp+0x20], xmm11
0000707649fdcf12  lea rdi, [rsp]
0000707649fdcf16  mov esi, 0x00
0000707649fdcf1b  mov rax, 0x59CB0B054530
0000707649fdcf25  call rax
0000707649fdcf27  movaps xmm6, [rsp]
0000707649fdcf2b  add rsp, 0x30
0000707649fdcf2f  vmovaps xmm0, [rsp]
0000707649fdcf34  vmovaps xmm1, [rsp+0x10]
0000707649fdcf3a  vmovaps xmm2, [rsp+0x20]
0000707649fdcf40  vmovaps xmm3, [rsp+0x30]
0000707649fdcf46  vmovaps xmm4, [rsp+0x40]
0000707649fdcf4c  vmovaps xmm5, [rsp+0x50]
0000707649fdcf52  vmovaps xmm7, [rsp+0x60]
0000707649fdcf58  vmovaps xmm8, [rsp+0x70]
0000707649fdcf5e  vmovaps xmm9, [rsp+0x80]
0000707649fdcf67  vmovaps xmm10, [rsp+0x90]
0000707649fdcf70  vmovaps xmm11, [rsp+0xA0]
0000707649fdcf79  vmovaps xmm12, [rsp+0xB0]
0000707649fdcf82  vmovaps xmm13, [rsp+0xC0]
0000707649fdcf8b  vmovaps xmm14, [rsp+0xD0]
0000707649fdcf94  vmovaps xmm15, [rsp+0xE0]
0000707649fdcf9d  add rsp, 0xF0
0000707649fdcfa4  pop r11
0000707649fdcfa6  pop r10
0000707649fdcfa8  pop r9
0000707649fdcfaa  pop r8
0000707649fdcfac  pop rsi
0000707649fdcfad  pop rdi
0000707649fdcfae  pop rdx
0000707649fdcfaf  pop rcx
0000707649fdcfb0  pop rax
0000707649fdcfb1  add rsp, 0x08
0000707649fdcfb5  jmp 0x0000707649FDBBD4
0000707649fdcfba  sub rsp, 0x08
0000707649fdcfbe  push rax
0000707649fdcfbf  push rcx
0000707649fdcfc0  push rdx
0000707649fdcfc1  push rdi
0000707649fdcfc2  push rsi
0000707649fdcfc3  push r8
0000707649fdcfc5  push r9
0000707649fdcfc7  push r10
0000707649fdcfc9  push r11
0000707649fdcfcb  sub rsp, 0xF0
0000707649fdcfd2  vmovaps [rsp], xmm0
0000707649fdcfd7  vmovaps [rsp+0x10], xmm1
0000707649fdcfdd  vmovaps [rsp+0x20], xmm2
0000707649fdcfe3  vmovaps [rsp+0x30], xmm4
0000707649fdcfe9  vmovaps [rsp+0x40], xmm5
0000707649fdcfef  vmovaps [rsp+0x50], xmm6
0000707649fdcff5  vmovaps [rsp+0x60], xmm7
0000707649fdcffb  vmovaps [rsp+0x70], xmm8
0000707649fdd001  vmovaps [rsp+0x80], xmm9
0000707649fdd00a  vmovaps [rsp+0x90], xmm10
0000707649fdd013  vmovaps [rsp+0xA0], xmm11
0000707649fdd01c  vmovaps [rsp+0xB0], xmm12
0000707649fdd025  vmovaps [rsp+0xC0], xmm13
0000707649fdd02e  vmovaps [rsp+0xD0], xmm14
0000707649fdd037  vmovaps [rsp+0xE0], xmm15
0000707649fdd040  sub rsp, 0x30
0000707649fdd044  movaps [rsp], xmm3
0000707649fdd048  movaps [rsp+0x10], xmm5
0000707649fdd04d  movaps [rsp+0x20], xmm4
0000707649fdd052  lea rdi, [rsp]
0000707649fdd056  mov esi, 0x00
0000707649fdd05b  mov rax, 0x59CB0B054530
0000707649fdd065  call rax
0000707649fdd067  movaps xmm3, [rsp]
0000707649fdd06b  add rsp, 0x30
0000707649fdd06f  vmovaps xmm0, [rsp]
0000707649fdd074  vmovaps xmm1, [rsp+0x10]
0000707649fdd07a  vmovaps xmm2, [rsp+0x20]
0000707649fdd080  vmovaps xmm4, [rsp+0x30]
0000707649fdd086  vmovaps xmm5, [rsp+0x40]
0000707649fdd08c  vmovaps xmm6, [rsp+0x50]
0000707649fdd092  vmovaps xmm7, [rsp+0x60]
0000707649fdd098  vmovaps xmm8, [rsp+0x70]
0000707649fdd09e  vmovaps xmm9, [rsp+0x80]
0000707649fdd0a7  vmovaps xmm10, [rsp+0x90]
0000707649fdd0b0  vmovaps xmm11, [rsp+0xA0]
0000707649fdd0b9  vmovaps xmm12, [rsp+0xB0]
0000707649fdd0c2  vmovaps xmm13, [rsp+0xC0]
0000707649fdd0cb  vmovaps xmm14, [rsp+0xD0]
0000707649fdd0d4  vmovaps xmm15, [rsp+0xE0]
0000707649fdd0dd  add rsp, 0xF0
0000707649fdd0e4  pop r11
0000707649fdd0e6  pop r10
0000707649fdd0e8  pop r9
0000707649fdd0ea  pop r8
0000707649fdd0ec  pop rsi
0000707649fdd0ed  pop rdi
0000707649fdd0ee  pop rdx
0000707649fdd0ef  pop rcx
0000707649fdd0f0  pop rax
0000707649fdd0f1  add rsp, 0x08
0000707649fdd0f5  jmp 0x0000707649FDBC35
0000707649fdd0fa  sub rsp, 0x08
0000707649fdd0fe  push rax
0000707649fdd0ff  push rcx
0000707649fdd100  push rdx
0000707649fdd101  push rdi
0000707649fdd102  push rsi
0000707649fdd103  push r8
0000707649fdd105  push r9
0000707649fdd107  push r10
0000707649fdd109  push r11
0000707649fdd10b  sub rsp, 0xF0
0000707649fdd112  vmovaps [rsp], xmm0
0000707649fdd117  vmovaps [rsp+0x10], xmm1
0000707649fdd11d  vmovaps [rsp+0x20], xmm2
0000707649fdd123  vmovaps [rsp+0x30], xmm3
0000707649fdd129  vmovaps [rsp+0x40], xmm4
0000707649fdd12f  vmovaps [rsp+0x50], xmm6
0000707649fdd135  vmovaps [rsp+0x60], xmm7
0000707649fdd13b  vmovaps [rsp+0x70], xmm8
0000707649fdd141  vmovaps [rsp+0x80], xmm9
0000707649fdd14a  vmovaps [rsp+0x90], xmm10
0000707649fdd153  vmovaps [rsp+0xA0], xmm11
0000707649fdd15c  vmovaps [rsp+0xB0], xmm12
0000707649fdd165  vmovaps [rsp+0xC0], xmm13
0000707649fdd16e  vmovaps [rsp+0xD0], xmm14
0000707649fdd177  vmovaps [rsp+0xE0], xmm15
0000707649fdd180  sub rsp, 0x30
0000707649fdd184  movaps [rsp], xmm5
0000707649fdd188  movaps [rsp+0x10], xmm8
0000707649fdd18e  movaps [rsp+0x20], xmm15
0000707649fdd194  lea rdi, [rsp]
0000707649fdd198  mov esi, 0x00
0000707649fdd19d  mov rax, 0x59CB0B054530
0000707649fdd1a7  call rax
0000707649fdd1a9  movaps xmm5, [rsp]
0000707649fdd1ad  add rsp, 0x30
0000707649fdd1b1  vmovaps xmm0, [rsp]
0000707649fdd1b6  vmovaps xmm1, [rsp+0x10]
0000707649fdd1bc  vmovaps xmm2, [rsp+0x20]
0000707649fdd1c2  vmovaps xmm3, [rsp+0x30]
0000707649fdd1c8  vmovaps xmm4, [rsp+0x40]
0000707649fdd1ce  vmovaps xmm6, [rsp+0x50]
0000707649fdd1d4  vmovaps xmm7, [rsp+0x60]
0000707649fdd1da  vmovaps xmm8, [rsp+0x70]
0000707649fdd1e0  vmovaps xmm9, [rsp+0x80]
0000707649fdd1e9  vmovaps xmm10, [rsp+0x90]
0000707649fdd1f2  vmovaps xmm11, [rsp+0xA0]
0000707649fdd1fb  vmovaps xmm12, [rsp+0xB0]
0000707649fdd204  vmovaps xmm13, [rsp+0xC0]
0000707649fdd20d  vmovaps xmm14, [rsp+0xD0]
0000707649fdd216  vmovaps xmm15, [rsp+0xE0]
0000707649fdd21f  add rsp, 0xF0
0000707649fdd226  pop r11
0000707649fdd228  pop r10
0000707649fdd22a  pop r9
0000707649fdd22c  pop r8
0000707649fdd22e  pop rsi
0000707649fdd22f  pop rdi
0000707649fdd230  pop rdx
0000707649fdd231  pop rcx
0000707649fdd232  pop rax
0000707649fdd233  add rsp, 0x08
0000707649fdd237  jmp 0x0000707649FDBC73
0000707649fdd23c  sub rsp, 0x08
0000707649fdd240  push rax
0000707649fdd241  push rcx
0000707649fdd242  push rdx
0000707649fdd243  push rdi
0000707649fdd244  push rsi
0000707649fdd245  push r8
0000707649fdd247  push r9
0000707649fdd249  push r10
0000707649fdd24b  push r11
0000707649fdd24d  sub rsp, 0xF0
0000707649fdd254  vmovaps [rsp], xmm0
0000707649fdd259  vmovaps [rsp+0x10], xmm1
0000707649fdd25f  vmovaps [rsp+0x20], xmm2
0000707649fdd265  vmovaps [rsp+0x30], xmm3
0000707649fdd26b  vmovaps [rsp+0x40], xmm5
0000707649fdd271  vmovaps [rsp+0x50], xmm6
0000707649fdd277  vmovaps [rsp+0x60], xmm7
0000707649fdd27d  vmovaps [rsp+0x70], xmm8
0000707649fdd283  vmovaps [rsp+0x80], xmm9
0000707649fdd28c  vmovaps [rsp+0x90], xmm10
0000707649fdd295  vmovaps [rsp+0xA0], xmm11
0000707649fdd29e  vmovaps [rsp+0xB0], xmm12
0000707649fdd2a7  vmovaps [rsp+0xC0], xmm13
0000707649fdd2b0  vmovaps [rsp+0xD0], xmm14
0000707649fdd2b9  vmovaps [rsp+0xE0], xmm15
0000707649fdd2c2  sub rsp, 0x30
0000707649fdd2c6  movaps [rsp], xmm4
0000707649fdd2ca  movaps [rsp+0x10], xmm9
0000707649fdd2d0  movaps [rsp+0x20], xmm8
0000707649fdd2d6  lea rdi, [rsp]
0000707649fdd2da  mov esi, 0x00
0000707649fdd2df  mov rax, 0x59CB0B054530
0000707649fdd2e9  call rax
0000707649fdd2eb  movaps xmm4, [rsp]
0000707649fdd2ef  add rsp, 0x30
0000707649fdd2f3  vmovaps xmm0, [rsp]
0000707649fdd2f8  vmovaps xmm1, [rsp+0x10]
0000707649fdd2fe  vmovaps xmm2, [rsp+0x20]
0000707649fdd304  vmovaps xmm3, [rsp+0x30]
0000707649fdd30a  vmovaps xmm5, [rsp+0x40]
0000707649fdd310  vmovaps xmm6, [rsp+0x50]
0000707649fdd316  vmovaps xmm7, [rsp+0x60]
0000707649fdd31c  vmovaps xmm8, [rsp+0x70]
0000707649fdd322  vmovaps xmm9, [rsp+0x80]
0000707649fdd32b  vmovaps xmm10, [rsp+0x90]
0000707649fdd334  vmovaps xmm11, [rsp+0xA0]
0000707649fdd33d  vmovaps xmm12, [rsp+0xB0]
0000707649fdd346  vmovaps xmm13, [rsp+0xC0]
0000707649fdd34f  vmovaps xmm14, [rsp+0xD0]
0000707649fdd358  vmovaps xmm15, [rsp+0xE0]
0000707649fdd361  add rsp, 0xF0
0000707649fdd368  pop r11
0000707649fdd36a  pop r10
0000707649fdd36c  pop r9
0000707649fdd36e  pop r8
0000707649fdd370  pop rsi
0000707649fdd371  pop rdi
0000707649fdd372  pop rdx
0000707649fdd373  pop rcx
0000707649fdd374  pop rax
0000707649fdd375  add rsp, 0x08
0000707649fdd379  jmp 0x0000707649FDBC94
0000707649fdd37e  sub rsp, 0x08
0000707649fdd382  push rax
0000707649fdd383  push rcx
0000707649fdd384  push rdx
0000707649fdd385  push rdi
0000707649fdd386  push rsi
0000707649fdd387  push r8
0000707649fdd389  push r9
0000707649fdd38b  push r10
0000707649fdd38d  push r11
0000707649fdd38f  sub rsp, 0xF0
0000707649fdd396  vmovaps [rsp], xmm0
0000707649fdd39b  vmovaps [rsp+0x10], xmm1
0000707649fdd3a1  vmovaps [rsp+0x20], xmm2
0000707649fdd3a7  vmovaps [rsp+0x30], xmm3
0000707649fdd3ad  vmovaps [rsp+0x40], xmm4
0000707649fdd3b3  vmovaps [rsp+0x50], xmm5
0000707649fdd3b9  vmovaps [rsp+0x60], xmm6
0000707649fdd3bf  vmovaps [rsp+0x70], xmm7
0000707649fdd3c5  vmovaps [rsp+0x80], xmm8
0000707649fdd3ce  vmovaps [rsp+0x90], xmm10
0000707649fdd3d7  vmovaps [rsp+0xA0], xmm11
0000707649fdd3e0  vmovaps [rsp+0xB0], xmm12
0000707649fdd3e9  vmovaps [rsp+0xC0], xmm13
0000707649fdd3f2  vmovaps [rsp+0xD0], xmm14
0000707649fdd3fb  vmovaps [rsp+0xE0], xmm15
0000707649fdd404  sub rsp, 0x30
0000707649fdd408  movaps [rsp], xmm9
0000707649fdd40d  movaps [rsp+0x10], xmm10
0000707649fdd413  movaps [rsp+0x20], xmm8
0000707649fdd419  lea rdi, [rsp]
0000707649fdd41d  mov esi, 0x00
0000707649fdd422  mov rax, 0x59CB0B054530
0000707649fdd42c  call rax
0000707649fdd42e  movaps xmm9, [rsp]
0000707649fdd433  add rsp, 0x30
0000707649fdd437  vmovaps xmm0, [rsp]
0000707649fdd43c  vmovaps xmm1, [rsp+0x10]
0000707649fdd442  vmovaps xmm2, [rsp+0x20]
0000707649fdd448  vmovaps xmm3, [rsp+0x30]
0000707649fdd44e  vmovaps xmm4, [rsp+0x40]
0000707649fdd454  vmovaps xmm5, [rsp+0x50]
0000707649fdd45a  vmovaps xmm6, [rsp+0x60]
0000707649fdd460  vmovaps xmm7, [rsp+0x70]
0000707649fdd466  vmovaps xmm8, [rsp+0x80]
0000707649fdd46f  vmovaps xmm10, [rsp+0x90]
0000707649fdd478  vmovaps xmm11, [rsp+0xA0]
0000707649fdd481  vmovaps xmm12, [rsp+0xB0]
0000707649fdd48a  vmovaps xmm13, [rsp+0xC0]
0000707649fdd493  vmovaps xmm14, [rsp+0xD0]
0000707649fdd49c  vmovaps xmm15, [rsp+0xE0]
0000707649fdd4a5  add rsp, 0xF0
0000707649fdd4ac  pop r11
0000707649fdd4ae  pop r10
0000707649fdd4b0  pop r9
0000707649fdd4b2  pop r8
0000707649fdd4b4  pop rsi
0000707649fdd4b5  pop rdi
0000707649fdd4b6  pop rdx
0000707649fdd4b7  pop rcx
0000707649fdd4b8  pop rax
0000707649fdd4b9  add rsp, 0x08
0000707649fdd4bd  jmp 0x0000707649FDBCAE
0000707649fdd4c2  call 0x0000707649EB52F0
0000707649fdd4c7  jmp 0x0000707649FDBDC8
0000707649fdd4cc  call 0x0000707649EB52F0
0000707649fdd4d1  jmp 0x0000707649FDBDDE
0000707649fdd4d6  sub rsp, 0x08
0000707649fdd4da  push rax
0000707649fdd4db  push rcx
0000707649fdd4dc  push rdx
0000707649fdd4dd  push rdi
0000707649fdd4de  push rsi
0000707649fdd4df  push r8
0000707649fdd4e1  push r9
0000707649fdd4e3  push r10
0000707649fdd4e5  push r11
0000707649fdd4e7  sub rsp, 0xF0
0000707649fdd4ee  vmovaps [rsp], xmm0
0000707649fdd4f3  vmovaps [rsp+0x10], xmm2
0000707649fdd4f9  vmovaps [rsp+0x20], xmm3
0000707649fdd4ff  vmovaps [rsp+0x30], xmm4
0000707649fdd505  vmovaps [rsp+0x40], xmm5
0000707649fdd50b  vmovaps [rsp+0x50], xmm6
0000707649fdd511  vmovaps [rsp+0x60], xmm7
0000707649fdd517  vmovaps [rsp+0x70], xmm8
0000707649fdd51d  vmovaps [rsp+0x80], xmm9
0000707649fdd526  vmovaps [rsp+0x90], xmm10
0000707649fdd52f  vmovaps [rsp+0xA0], xmm11
0000707649fdd538  vmovaps [rsp+0xB0], xmm12
0000707649fdd541  vmovaps [rsp+0xC0], xmm13
0000707649fdd54a  vmovaps [rsp+0xD0], xmm14
0000707649fdd553  vmovaps [rsp+0xE0], xmm15
0000707649fdd55c  sub rsp, 0x30
0000707649fdd560  movaps [rsp], xmm1
0000707649fdd564  movaps [rsp+0x10], xmm6
0000707649fdd569  movaps [rsp+0x20], xmm15
0000707649fdd56f  lea rdi, [rsp]
0000707649fdd573  mov esi, 0x00
0000707649fdd578  mov rax, 0x59CB0B054530
0000707649fdd582  call rax
0000707649fdd584  movaps xmm1, [rsp]
0000707649fdd588  add rsp, 0x30
0000707649fdd58c  vmovaps xmm0, [rsp]
0000707649fdd591  vmovaps xmm2, [rsp+0x10]
0000707649fdd597  vmovaps xmm3, [rsp+0x20]
0000707649fdd59d  vmovaps xmm4, [rsp+0x30]
0000707649fdd5a3  vmovaps xmm5, [rsp+0x40]
0000707649fdd5a9  vmovaps xmm6, [rsp+0x50]
0000707649fdd5af  vmovaps xmm7, [rsp+0x60]
0000707649fdd5b5  vmovaps xmm8, [rsp+0x70]
0000707649fdd5bb  vmovaps xmm9, [rsp+0x80]
0000707649fdd5c4  vmovaps xmm10, [rsp+0x90]
0000707649fdd5cd  vmovaps xmm11, [rsp+0xA0]
0000707649fdd5d6  vmovaps xmm12, [rsp+0xB0]
0000707649fdd5df  vmovaps xmm13, [rsp+0xC0]
0000707649fdd5e8  vmovaps xmm14, [rsp+0xD0]
0000707649fdd5f1  vmovaps xmm15, [rsp+0xE0]
0000707649fdd5fa  add rsp, 0xF0
0000707649fdd601  pop r11
0000707649fdd603  pop r10
0000707649fdd605  pop r9
0000707649fdd607  pop r8
0000707649fdd609  pop rsi
0000707649fdd60a  pop rdi
0000707649fdd60b  pop rdx
0000707649fdd60c  pop rcx
0000707649fdd60d  pop rax
0000707649fdd60e  add rsp, 0x08
0000707649fdd612  jmp 0x0000707649FDBE1B
0000707649fdd617  call 0x0000707649EC4620
0000707649fdd61c  jmp 0x0000707649FDBE28
0000707649fdd621  sub rsp, 0x08
0000707649fdd625  push rax
0000707649fdd626  push rcx
0000707649fdd627  push rdx
0000707649fdd628  push rdi
0000707649fdd629  push rsi
0000707649fdd62a  push r8
0000707649fdd62c  push r9
0000707649fdd62e  push r10
0000707649fdd630  push r11
0000707649fdd632  sub rsp, 0xF0
0000707649fdd639  vmovaps [rsp], xmm0
0000707649fdd63e  vmovaps [rsp+0x10], xmm1
0000707649fdd644  vmovaps [rsp+0x20], xmm2
0000707649fdd64a  vmovaps [rsp+0x30], xmm3
0000707649fdd650  vmovaps [rsp+0x40], xmm4
0000707649fdd656  vmovaps [rsp+0x50], xmm5
0000707649fdd65c  vmovaps [rsp+0x60], xmm6
0000707649fdd662  vmovaps [rsp+0x70], xmm7
0000707649fdd668  vmovaps [rsp+0x80], xmm8
0000707649fdd671  vmovaps [rsp+0x90], xmm9
0000707649fdd67a  vmovaps [rsp+0xA0], xmm10
0000707649fdd683  vmovaps [rsp+0xB0], xmm11
0000707649fdd68c  vmovaps [rsp+0xC0], xmm12
0000707649fdd695  vmovaps [rsp+0xD0], xmm13
0000707649fdd69e  vmovaps [rsp+0xE0], xmm15
0000707649fdd6a7  sub rsp, 0x30
0000707649fdd6ab  movaps [rsp], xmm14
0000707649fdd6b0  movaps [rsp+0x10], xmm4
0000707649fdd6b5  movaps [rsp+0x20], xmm3
0000707649fdd6ba  lea rdi, [rsp]
0000707649fdd6be  mov esi, 0x00
0000707649fdd6c3  mov rax, 0x59CB0B054530
0000707649fdd6cd  call rax
0000707649fdd6cf  movaps xmm14, [rsp]
0000707649fdd6d4  add rsp, 0x30
0000707649fdd6d8  vmovaps xmm0, [rsp]
0000707649fdd6dd  vmovaps xmm1, [rsp+0x10]
0000707649fdd6e3  vmovaps xmm2, [rsp+0x20]
0000707649fdd6e9  vmovaps xmm3, [rsp+0x30]
0000707649fdd6ef  vmovaps xmm4, [rsp+0x40]
0000707649fdd6f5  vmovaps xmm5, [rsp+0x50]
0000707649fdd6fb  vmovaps xmm6, [rsp+0x60]
0000707649fdd701  vmovaps xmm7, [rsp+0x70]
0000707649fdd707  vmovaps xmm8, [rsp+0x80]
0000707649fdd710  vmovaps xmm9, [rsp+0x90]
0000707649fdd719  vmovaps xmm10, [rsp+0xA0]
0000707649fdd722  vmovaps xmm11, [rsp+0xB0]
0000707649fdd72b  vmovaps xmm12, [rsp+0xC0]
0000707649fdd734  vmovaps xmm13, [rsp+0xD0]
0000707649fdd73d  vmovaps xmm15, [rsp+0xE0]
0000707649fdd746  add rsp, 0xF0
0000707649fdd74d  pop r11
0000707649fdd74f  pop r10
0000707649fdd751  pop r9
0000707649fdd753  pop r8
0000707649fdd755  pop rsi
0000707649fdd756  pop rdi
0000707649fdd757  pop rdx
0000707649fdd758  pop rcx
0000707649fdd759  pop rax
0000707649fdd75a  add rsp, 0x08
0000707649fdd75e  jmp 0x0000707649FDBE42
0000707649fdd763  sub rsp, 0x08
0000707649fdd767  push rax
0000707649fdd768  push rcx
0000707649fdd769  push rdx
0000707649fdd76a  push rdi
0000707649fdd76b  push rsi
0000707649fdd76c  push r8
0000707649fdd76e  push r9
0000707649fdd770  push r10
0000707649fdd772  push r11
0000707649fdd774  sub rsp, 0xF0
0000707649fdd77b  vmovaps [rsp], xmm0
0000707649fdd780  vmovaps [rsp+0x10], xmm1
0000707649fdd786  vmovaps [rsp+0x20], xmm2
0000707649fdd78c  vmovaps [rsp+0x30], xmm3
0000707649fdd792  vmovaps [rsp+0x40], xmm4
0000707649fdd798  vmovaps [rsp+0x50], xmm5
0000707649fdd79e  vmovaps [rsp+0x60], xmm7
0000707649fdd7a4  vmovaps [rsp+0x70], xmm8
0000707649fdd7aa  vmovaps [rsp+0x80], xmm9
0000707649fdd7b3  vmovaps [rsp+0x90], xmm10
0000707649fdd7bc  vmovaps [rsp+0xA0], xmm11
0000707649fdd7c5  vmovaps [rsp+0xB0], xmm12
0000707649fdd7ce  vmovaps [rsp+0xC0], xmm13
0000707649fdd7d7  vmovaps [rsp+0xD0], xmm14
0000707649fdd7e0  vmovaps [rsp+0xE0], xmm15
0000707649fdd7e9  sub rsp, 0x30
0000707649fdd7ed  movaps [rsp], xmm6
0000707649fdd7f1  movaps [rsp+0x10], xmm9
0000707649fdd7f7  movaps [rsp+0x20], xmm7
0000707649fdd7fc  lea rdi, [rsp]
0000707649fdd800  mov esi, 0x00
0000707649fdd805  mov rax, 0x59CB0B054530
0000707649fdd80f  call rax
0000707649fdd811  movaps xmm6, [rsp]
0000707649fdd815  add rsp, 0x30
0000707649fdd819  vmovaps xmm0, [rsp]
0000707649fdd81e  vmovaps xmm1, [rsp+0x10]
0000707649fdd824  vmovaps xmm2, [rsp+0x20]
0000707649fdd82a  vmovaps xmm3, [rsp+0x30]
0000707649fdd830  vmovaps xmm4, [rsp+0x40]
0000707649fdd836  vmovaps xmm5, [rsp+0x50]
0000707649fdd83c  vmovaps xmm7, [rsp+0x60]
0000707649fdd842  vmovaps xmm8, [rsp+0x70]
0000707649fdd848  vmovaps xmm9, [rsp+0x80]
0000707649fdd851  vmovaps xmm10, [rsp+0x90]
0000707649fdd85a  vmovaps xmm11, [rsp+0xA0]
0000707649fdd863  vmovaps xmm12, [rsp+0xB0]
0000707649fdd86c  vmovaps xmm13, [rsp+0xC0]
0000707649fdd875  vmovaps xmm14, [rsp+0xD0]
0000707649fdd87e  vmovaps xmm15, [rsp+0xE0]
0000707649fdd887  add rsp, 0xF0
0000707649fdd88e  pop r11
0000707649fdd890  pop r10
0000707649fdd892  pop r9
0000707649fdd894  pop r8
0000707649fdd896  pop rsi
0000707649fdd897  pop rdi
0000707649fdd898  pop rdx
0000707649fdd899  pop rcx
0000707649fdd89a  pop rax
0000707649fdd89b  add rsp, 0x08
0000707649fdd89f  jmp 0x0000707649FDBE5A
0000707649fdd8a4  sub rsp, 0x08
0000707649fdd8a8  push rax
0000707649fdd8a9  push rcx
0000707649fdd8aa  push rdx
0000707649fdd8ab  push rdi
0000707649fdd8ac  push rsi
0000707649fdd8ad  push r8
0000707649fdd8af  push r9
0000707649fdd8b1  push r10
0000707649fdd8b3  push r11
0000707649fdd8b5  sub rsp, 0xF0
0000707649fdd8bc  vmovaps [rsp], xmm0
0000707649fdd8c1  vmovaps [rsp+0x10], xmm1
0000707649fdd8c7  vmovaps [rsp+0x20], xmm2
0000707649fdd8cd  vmovaps [rsp+0x30], xmm3
0000707649fdd8d3  vmovaps [rsp+0x40], xmm4
0000707649fdd8d9  vmovaps [rsp+0x50], xmm5
0000707649fdd8df  vmovaps [rsp+0x60], xmm6
0000707649fdd8e5  vmovaps [rsp+0x70], xmm8
0000707649fdd8eb  vmovaps [rsp+0x80], xmm9
0000707649fdd8f4  vmovaps [rsp+0x90], xmm10
0000707649fdd8fd  vmovaps [rsp+0xA0], xmm11
0000707649fdd906  vmovaps [rsp+0xB0], xmm12
0000707649fdd90f  vmovaps [rsp+0xC0], xmm13
0000707649fdd918  vmovaps [rsp+0xD0], xmm14
0000707649fdd921  vmovaps [rsp+0xE0], xmm15
0000707649fdd92a  sub rsp, 0x30
0000707649fdd92e  movaps [rsp], xmm7
0000707649fdd932  movaps [rsp+0x10], xmm4
0000707649fdd937  movaps [rsp+0x20], xmm9
0000707649fdd93d  lea rdi, [rsp]
0000707649fdd941  mov esi, 0x00
0000707649fdd946  mov rax, 0x59CB0B054530
0000707649fdd950  call rax
0000707649fdd952  movaps xmm7, [rsp]
0000707649fdd956  add rsp, 0x30
0000707649fdd95a  vmovaps xmm0, [rsp]
0000707649fdd95f  vmovaps xmm1, [rsp+0x10]
0000707649fdd965  vmovaps xmm2, [rsp+0x20]
0000707649fdd96b  vmovaps xmm3, [rsp+0x30]
0000707649fdd971  vmovaps xmm4, [rsp+0x40]
0000707649fdd977  vmovaps xmm5, [rsp+0x50]
0000707649fdd97d  vmovaps xmm6, [rsp+0x60]
0000707649fdd983  vmovaps xmm8, [rsp+0x70]
0000707649fdd989  vmovaps xmm9, [rsp+0x80]
0000707649fdd992  vmovaps xmm10, [rsp+0x90]
0000707649fdd99b  vmovaps xmm11, [rsp+0xA0]
0000707649fdd9a4  vmovaps xmm12, [rsp+0xB0]
0000707649fdd9ad  vmovaps xmm13, [rsp+0xC0]
0000707649fdd9b6  vmovaps xmm14, [rsp+0xD0]
0000707649fdd9bf  vmovaps xmm15, [rsp+0xE0]
0000707649fdd9c8  add rsp, 0xF0
0000707649fdd9cf  pop r11
0000707649fdd9d1  pop r10
0000707649fdd9d3  pop r9
0000707649fdd9d5  pop r8
0000707649fdd9d7  pop rsi
0000707649fdd9d8  pop rdi
0000707649fdd9d9  pop rdx
0000707649fdd9da  pop rcx
0000707649fdd9db  pop rax
0000707649fdd9dc  add rsp, 0x08
0000707649fdd9e0  jmp 0x0000707649FDBE87
0000707649fdd9e5  sub rsp, 0x08
0000707649fdd9e9  push rax
0000707649fdd9ea  push rcx
0000707649fdd9eb  push rdx
0000707649fdd9ec  push rdi
0000707649fdd9ed  push rsi
0000707649fdd9ee  push r8
0000707649fdd9f0  push r9
0000707649fdd9f2  push r10
0000707649fdd9f4  push r11
0000707649fdd9f6  sub rsp, 0xF0
0000707649fdd9fd  vmovaps [rsp], xmm0
0000707649fdda02  vmovaps [rsp+0x10], xmm1
0000707649fdda08  vmovaps [rsp+0x20], xmm2
0000707649fdda0e  vmovaps [rsp+0x30], xmm3
0000707649fdda14  vmovaps [rsp+0x40], xmm5
0000707649fdda1a  vmovaps [rsp+0x50], xmm6
0000707649fdda20  vmovaps [rsp+0x60], xmm7
0000707649fdda26  vmovaps [rsp+0x70], xmm8
0000707649fdda2c  vmovaps [rsp+0x80], xmm9
0000707649fdda35  vmovaps [rsp+0x90], xmm10
0000707649fdda3e  vmovaps [rsp+0xA0], xmm11
0000707649fdda47  vmovaps [rsp+0xB0], xmm12
0000707649fdda50  vmovaps [rsp+0xC0], xmm13
0000707649fdda59  vmovaps [rsp+0xD0], xmm14
0000707649fdda62  vmovaps [rsp+0xE0], xmm15
0000707649fdda6b  sub rsp, 0x30
0000707649fdda6f  movaps [rsp], xmm4
0000707649fdda73  movaps [rsp+0x10], xmm15
0000707649fdda79  movaps [rsp+0x20], xmm9
0000707649fdda7f  lea rdi, [rsp]
0000707649fdda83  mov esi, 0x00
0000707649fdda88  mov rax, 0x59CB0B054530
0000707649fdda92  call rax
0000707649fdda94  movaps xmm4, [rsp]
0000707649fdda98  add rsp, 0x30
0000707649fdda9c  vmovaps xmm0, [rsp]
0000707649fddaa1  vmovaps xmm1, [rsp+0x10]
0000707649fddaa7  vmovaps xmm2, [rsp+0x20]
0000707649fddaad  vmovaps xmm3, [rsp+0x30]
0000707649fddab3  vmovaps xmm5, [rsp+0x40]
0000707649fddab9  vmovaps xmm6, [rsp+0x50]
0000707649fddabf  vmovaps xmm7, [rsp+0x60]
0000707649fddac5  vmovaps xmm8, [rsp+0x70]
0000707649fddacb  vmovaps xmm9, [rsp+0x80]
0000707649fddad4  vmovaps xmm10, [rsp+0x90]
0000707649fddadd  vmovaps xmm11, [rsp+0xA0]
0000707649fddae6  vmovaps xmm12, [rsp+0xB0]
0000707649fddaef  vmovaps xmm13, [rsp+0xC0]
0000707649fddaf8  vmovaps xmm14, [rsp+0xD0]
0000707649fddb01  vmovaps xmm15, [rsp+0xE0]
0000707649fddb0a  add rsp, 0xF0
0000707649fddb11  pop r11
0000707649fddb13  pop r10
0000707649fddb15  pop r9
0000707649fddb17  pop r8
0000707649fddb19  pop rsi
0000707649fddb1a  pop rdi
0000707649fddb1b  pop rdx
0000707649fddb1c  pop rcx
0000707649fddb1d  pop rax
0000707649fddb1e  add rsp, 0x08
0000707649fddb22  jmp 0x0000707649FDBEAC
0000707649fddb27  call 0x0000707649EC4620
0000707649fddb2c  jmp 0x0000707649FDBEB9
0000707649fddb31  sub rsp, 0x08
0000707649fddb35  push rax
0000707649fddb36  push rcx
0000707649fddb37  push rdx
0000707649fddb38  push rdi
0000707649fddb39  push rsi
0000707649fddb3a  push r8
0000707649fddb3c  push r9
0000707649fddb3e  push r10
0000707649fddb40  push r11
0000707649fddb42  sub rsp, 0xF0
0000707649fddb49  vmovaps [rsp], xmm0
0000707649fddb4e  vmovaps [rsp+0x10], xmm1
0000707649fddb54  vmovaps [rsp+0x20], xmm2
0000707649fddb5a  vmovaps [rsp+0x30], xmm4
0000707649fddb60  vmovaps [rsp+0x40], xmm5
0000707649fddb66  vmovaps [rsp+0x50], xmm6
0000707649fddb6c  vmovaps [rsp+0x60], xmm7
0000707649fddb72  vmovaps [rsp+0x70], xmm8
0000707649fddb78  vmovaps [rsp+0x80], xmm9
0000707649fddb81  vmovaps [rsp+0x90], xmm10
0000707649fddb8a  vmovaps [rsp+0xA0], xmm11
0000707649fddb93  vmovaps [rsp+0xB0], xmm12
0000707649fddb9c  vmovaps [rsp+0xC0], xmm13
0000707649fddba5  vmovaps [rsp+0xD0], xmm14
0000707649fddbae  vmovaps [rsp+0xE0], xmm15
0000707649fddbb7  sub rsp, 0x30
0000707649fddbbb  movaps [rsp], xmm3
0000707649fddbbf  movaps [rsp+0x10], xmm1
0000707649fddbc4  movaps [rsp+0x20], xmm9
0000707649fddbca  lea rdi, [rsp]
0000707649fddbce  mov esi, 0x00
0000707649fddbd3  mov rax, 0x59CB0B054530
0000707649fddbdd  call rax
0000707649fddbdf  movaps xmm3, [rsp]
0000707649fddbe3  add rsp, 0x30
0000707649fddbe7  vmovaps xmm0, [rsp]
0000707649fddbec  vmovaps xmm1, [rsp+0x10]
0000707649fddbf2  vmovaps xmm2, [rsp+0x20]
0000707649fddbf8  vmovaps xmm4, [rsp+0x30]
0000707649fddbfe  vmovaps xmm5, [rsp+0x40]
0000707649fddc04  vmovaps xmm6, [rsp+0x50]
0000707649fddc0a  vmovaps xmm7, [rsp+0x60]
0000707649fddc10  vmovaps xmm8, [rsp+0x70]
0000707649fddc16  vmovaps xmm9, [rsp+0x80]
0000707649fddc1f  vmovaps xmm10, [rsp+0x90]
0000707649fddc28  vmovaps xmm11, [rsp+0xA0]
0000707649fddc31  vmovaps xmm12, [rsp+0xB0]
0000707649fddc3a  vmovaps xmm13, [rsp+0xC0]
0000707649fddc43  vmovaps xmm14, [rsp+0xD0]
0000707649fddc4c  vmovaps xmm15, [rsp+0xE0]
0000707649fddc55  add rsp, 0xF0
0000707649fddc5c  pop r11
0000707649fddc5e  pop r10
0000707649fddc60  pop r9
0000707649fddc62  pop r8
0000707649fddc64  pop rsi
0000707649fddc65  pop rdi
0000707649fddc66  pop rdx
0000707649fddc67  pop rcx
0000707649fddc68  pop rax
0000707649fddc69  add rsp, 0x08
0000707649fddc6d  jmp 0x0000707649FDBEF6
0000707649fddc72  sub rsp, 0x08
0000707649fddc76  push rax
0000707649fddc77  push rcx
0000707649fddc78  push rdx
0000707649fddc79  push rdi
0000707649fddc7a  push rsi
0000707649fddc7b  push r8
0000707649fddc7d  push r9
0000707649fddc7f  push r10
0000707649fddc81  push r11
0000707649fddc83  sub rsp, 0xF0
0000707649fddc8a  vmovaps [rsp], xmm0
0000707649fddc8f  vmovaps [rsp+0x10], xmm2
0000707649fddc95  vmovaps [rsp+0x20], xmm3
0000707649fddc9b  vmovaps [rsp+0x30], xmm4
0000707649fddca1  vmovaps [rsp+0x40], xmm5
0000707649fddca7  vmovaps [rsp+0x50], xmm6
0000707649fddcad  vmovaps [rsp+0x60], xmm7
0000707649fddcb3  vmovaps [rsp+0x70], xmm8
0000707649fddcb9  vmovaps [rsp+0x80], xmm9
0000707649fddcc2  vmovaps [rsp+0x90], xmm10
0000707649fddccb  vmovaps [rsp+0xA0], xmm11
0000707649fddcd4  vmovaps [rsp+0xB0], xmm12
0000707649fddcdd  vmovaps [rsp+0xC0], xmm13
0000707649fddce6  vmovaps [rsp+0xD0], xmm14
0000707649fddcef  vmovaps [rsp+0xE0], xmm15
0000707649fddcf8  sub rsp, 0x30
0000707649fddcfc  movaps [rsp], xmm1
0000707649fddd00  movaps [rsp+0x10], xmm15
0000707649fddd06  movaps [rsp+0x20], xmm9
0000707649fddd0c  lea rdi, [rsp]
0000707649fddd10  mov esi, 0x00
0000707649fddd15  mov rax, 0x59CB0B054530
0000707649fddd1f  call rax
0000707649fddd21  movaps xmm1, [rsp]
0000707649fddd25  add rsp, 0x30
0000707649fddd29  vmovaps xmm0, [rsp]
0000707649fddd2e  vmovaps xmm2, [rsp+0x10]
0000707649fddd34  vmovaps xmm3, [rsp+0x20]
0000707649fddd3a  vmovaps xmm4, [rsp+0x30]
0000707649fddd40  vmovaps xmm5, [rsp+0x40]
0000707649fddd46  vmovaps xmm6, [rsp+0x50]
0000707649fddd4c  vmovaps xmm7, [rsp+0x60]
0000707649fddd52  vmovaps xmm8, [rsp+0x70]
0000707649fddd58  vmovaps xmm9, [rsp+0x80]
0000707649fddd61  vmovaps xmm10, [rsp+0x90]
0000707649fddd6a  vmovaps xmm11, [rsp+0xA0]
0000707649fddd73  vmovaps xmm12, [rsp+0xB0]
0000707649fddd7c  vmovaps xmm13, [rsp+0xC0]
0000707649fddd85  vmovaps xmm14, [rsp+0xD0]
0000707649fddd8e  vmovaps xmm15, [rsp+0xE0]
0000707649fddd97  add rsp, 0xF0
0000707649fddd9e  pop r11
0000707649fddda0  pop r10
0000707649fddda2  pop r9
0000707649fddda4  pop r8
0000707649fddda6  pop rsi
0000707649fddda7  pop rdi
0000707649fddda8  pop rdx
0000707649fddda9  pop rcx
0000707649fdddaa  pop rax
0000707649fdddab  add rsp, 0x08
0000707649fdddaf  jmp 0x0000707649FDBF7E
0000707649fdddb4  call 0x0000707649EC4620
0000707649fdddb9  jmp 0x0000707649FDBF8B
0000707649fdddbe  sub rsp, 0x08
0000707649fdddc2  push rax
0000707649fdddc3  push rcx
0000707649fdddc4  push rdx
0000707649fdddc5  push rdi
0000707649fdddc6  push rsi
0000707649fdddc7  push r8
0000707649fdddc9  push r9
0000707649fdddcb  push r10
0000707649fdddcd  push r11
0000707649fdddcf  sub rsp, 0xF0
0000707649fdddd6  vmovaps [rsp], xmm0
0000707649fddddb  vmovaps [rsp+0x10], xmm2
0000707649fddde1  vmovaps [rsp+0x20], xmm3
0000707649fddde7  vmovaps [rsp+0x30], xmm4
0000707649fddded  vmovaps [rsp+0x40], xmm5
0000707649fdddf3  vmovaps [rsp+0x50], xmm6
0000707649fdddf9  vmovaps [rsp+0x60], xmm7
0000707649fdddff  vmovaps [rsp+0x70], xmm8
0000707649fdde05  vmovaps [rsp+0x80], xmm9
0000707649fdde0e  vmovaps [rsp+0x90], xmm10
0000707649fdde17  vmovaps [rsp+0xA0], xmm11
0000707649fdde20  vmovaps [rsp+0xB0], xmm12
0000707649fdde29  vmovaps [rsp+0xC0], xmm13
0000707649fdde32  vmovaps [rsp+0xD0], xmm14
0000707649fdde3b  vmovaps [rsp+0xE0], xmm15
0000707649fdde44  sub rsp, 0x30
0000707649fdde48  movaps [rsp], xmm1
0000707649fdde4c  movaps [rsp+0x10], xmm5
0000707649fdde51  movaps [rsp+0x20], xmm7
0000707649fdde56  lea rdi, [rsp]
0000707649fdde5a  mov esi, 0x00
0000707649fdde5f  mov rax, 0x59CB0B054530
0000707649fdde69  call rax
0000707649fdde6b  movaps xmm1, [rsp]
0000707649fdde6f  add rsp, 0x30
0000707649fdde73  vmovaps xmm0, [rsp]
0000707649fdde78  vmovaps xmm2, [rsp+0x10]
0000707649fdde7e  vmovaps xmm3, [rsp+0x20]
0000707649fdde84  vmovaps xmm4, [rsp+0x30]
0000707649fdde8a  vmovaps xmm5, [rsp+0x40]
0000707649fdde90  vmovaps xmm6, [rsp+0x50]
0000707649fdde96  vmovaps xmm7, [rsp+0x60]
0000707649fdde9c  vmovaps xmm8, [rsp+0x70]
0000707649fddea2  vmovaps xmm9, [rsp+0x80]
0000707649fddeab  vmovaps xmm10, [rsp+0x90]
0000707649fddeb4  vmovaps xmm11, [rsp+0xA0]
0000707649fddebd  vmovaps xmm12, [rsp+0xB0]
0000707649fddec6  vmovaps xmm13, [rsp+0xC0]
0000707649fddecf  vmovaps xmm14, [rsp+0xD0]
0000707649fdded8  vmovaps xmm15, [rsp+0xE0]
0000707649fddee1  add rsp, 0xF0
0000707649fddee8  pop r11
0000707649fddeea  pop r10
0000707649fddeec  pop r9
0000707649fddeee  pop r8
0000707649fddef0  pop rsi
0000707649fddef1  pop rdi
0000707649fddef2  pop rdx
0000707649fddef3  pop rcx
0000707649fddef4  pop rax
0000707649fddef5  add rsp, 0x08
0000707649fddef9  jmp 0x0000707649FDC030
0000707649fddefe  sub rsp, 0x08
0000707649fddf02  push rax
0000707649fddf03  push rcx
0000707649fddf04  push rdx
0000707649fddf05  push rdi
0000707649fddf06  push rsi
0000707649fddf07  push r8
0000707649fddf09  push r9
0000707649fddf0b  push r10
0000707649fddf0d  push r11
0000707649fddf0f  sub rsp, 0xF0
0000707649fddf16  vmovaps [rsp], xmm0
0000707649fddf1b  vmovaps [rsp+0x10], xmm1
0000707649fddf21  vmovaps [rsp+0x20], xmm2
0000707649fddf27  vmovaps [rsp+0x30], xmm3
0000707649fddf2d  vmovaps [rsp+0x40], xmm4
0000707649fddf33  vmovaps [rsp+0x50], xmm5
0000707649fddf39  vmovaps [rsp+0x60], xmm6
0000707649fddf3f  vmovaps [rsp+0x70], xmm8
0000707649fddf45  vmovaps [rsp+0x80], xmm9
0000707649fddf4e  vmovaps [rsp+0x90], xmm10
0000707649fddf57  vmovaps [rsp+0xA0], xmm11
0000707649fddf60  vmovaps [rsp+0xB0], xmm12
0000707649fddf69  vmovaps [rsp+0xC0], xmm13
0000707649fddf72  vmovaps [rsp+0xD0], xmm14
0000707649fddf7b  vmovaps [rsp+0xE0], xmm15
0000707649fddf84  sub rsp, 0x30
0000707649fddf88  movaps [rsp], xmm7
0000707649fddf8c  movaps [rsp+0x10], xmm5
0000707649fddf91  movaps [rsp+0x20], xmm15
0000707649fddf97  lea rdi, [rsp]
0000707649fddf9b  mov esi, 0x00
0000707649fddfa0  mov rax, 0x59CB0B054530
0000707649fddfaa  call rax
0000707649fddfac  movaps xmm7, [rsp]
0000707649fddfb0  add rsp, 0x30
0000707649fddfb4  vmovaps xmm0, [rsp]
0000707649fddfb9  vmovaps xmm1, [rsp+0x10]
0000707649fddfbf  vmovaps xmm2, [rsp+0x20]
0000707649fddfc5  vmovaps xmm3, [rsp+0x30]
0000707649fddfcb  vmovaps xmm4, [rsp+0x40]
0000707649fddfd1  vmovaps xmm5, [rsp+0x50]
0000707649fddfd7  vmovaps xmm6, [rsp+0x60]
0000707649fddfdd  vmovaps xmm8, [rsp+0x70]
0000707649fddfe3  vmovaps xmm9, [rsp+0x80]
0000707649fddfec  vmovaps xmm10, [rsp+0x90]
0000707649fddff5  vmovaps xmm11, [rsp+0xA0]
0000707649fddffe  vmovaps xmm12, [rsp+0xB0]
0000707649fde007  vmovaps xmm13, [rsp+0xC0]
0000707649fde010  vmovaps xmm14, [rsp+0xD0]
0000707649fde019  vmovaps xmm15, [rsp+0xE0]
0000707649fde022  add rsp, 0xF0
0000707649fde029  pop r11
0000707649fde02b  pop r10
0000707649fde02d  pop r9
0000707649fde02f  pop r8
0000707649fde031  pop rsi
0000707649fde032  pop rdi
0000707649fde033  pop rdx
0000707649fde034  pop rcx
0000707649fde035  pop rax
0000707649fde036  add rsp, 0x08
0000707649fde03a  jmp 0x0000707649FDC066
0000707649fde03f  call 0x0000707649EB52F0
0000707649fde044  jmp 0x0000707649FDC073
0000707649fde049  sub rsp, 0x08
0000707649fde04d  push rax
0000707649fde04e  push rcx
0000707649fde04f  push rdx
0000707649fde050  push rdi
0000707649fde051  push rsi
0000707649fde052  push r8
0000707649fde054  push r9
0000707649fde056  push r10
0000707649fde058  push r11
0000707649fde05a  sub rsp, 0xF0
0000707649fde061  vmovaps [rsp], xmm0
0000707649fde066  vmovaps [rsp+0x10], xmm1
0000707649fde06c  vmovaps [rsp+0x20], xmm2
0000707649fde072  vmovaps [rsp+0x30], xmm3
0000707649fde078  vmovaps [rsp+0x40], xmm4
0000707649fde07e  vmovaps [rsp+0x50], xmm5
0000707649fde084  vmovaps [rsp+0x60], xmm6
0000707649fde08a  vmovaps [rsp+0x70], xmm7
0000707649fde090  vmovaps [rsp+0x80], xmm8
0000707649fde099  vmovaps [rsp+0x90], xmm9
0000707649fde0a2  vmovaps [rsp+0xA0], xmm10
0000707649fde0ab  vmovaps [rsp+0xB0], xmm11
0000707649fde0b4  vmovaps [rsp+0xC0], xmm12
0000707649fde0bd  vmovaps [rsp+0xD0], xmm13
0000707649fde0c6  vmovaps [rsp+0xE0], xmm14
0000707649fde0cf  sub rsp, 0x30
0000707649fde0d3  movaps [rsp], xmm15
0000707649fde0d8  movaps [rsp+0x10], xmm5
0000707649fde0dd  movaps [rsp+0x20], xmm3
0000707649fde0e2  lea rdi, [rsp]
0000707649fde0e6  mov esi, 0x00
0000707649fde0eb  mov rax, 0x59CB0B054530
0000707649fde0f5  call rax
0000707649fde0f7  movaps xmm15, [rsp]
0000707649fde0fc  add rsp, 0x30
0000707649fde100  vmovaps xmm0, [rsp]
0000707649fde105  vmovaps xmm1, [rsp+0x10]
0000707649fde10b  vmovaps xmm2, [rsp+0x20]
0000707649fde111  vmovaps xmm3, [rsp+0x30]
0000707649fde117  vmovaps xmm4, [rsp+0x40]
0000707649fde11d  vmovaps xmm5, [rsp+0x50]
0000707649fde123  vmovaps xmm6, [rsp+0x60]
0000707649fde129  vmovaps xmm7, [rsp+0x70]
0000707649fde12f  vmovaps xmm8, [rsp+0x80]
0000707649fde138  vmovaps xmm9, [rsp+0x90]
0000707649fde141  vmovaps xmm10, [rsp+0xA0]
0000707649fde14a  vmovaps xmm11, [rsp+0xB0]
0000707649fde153  vmovaps xmm12, [rsp+0xC0]
0000707649fde15c  vmovaps xmm13, [rsp+0xD0]
0000707649fde165  vmovaps xmm14, [rsp+0xE0]
0000707649fde16e  add rsp, 0xF0
0000707649fde175  pop r11
0000707649fde177  pop r10
0000707649fde179  pop r9
0000707649fde17b  pop r8
0000707649fde17d  pop rsi
0000707649fde17e  pop rdi
0000707649fde17f  pop rdx
0000707649fde180  pop rcx
0000707649fde181  pop rax
0000707649fde182  add rsp, 0x08
0000707649fde186  jmp 0x0000707649FDC099
0000707649fde18b  sub rsp, 0x08
0000707649fde18f  push rax
0000707649fde190  push rcx
0000707649fde191  push rdx
0000707649fde192  push rdi
0000707649fde193  push rsi
0000707649fde194  push r8
0000707649fde196  push r9
0000707649fde198  push r10
0000707649fde19a  push r11
0000707649fde19c  sub rsp, 0xF0
0000707649fde1a3  vmovaps [rsp], xmm0
0000707649fde1a8  vmovaps [rsp+0x10], xmm2
0000707649fde1ae  vmovaps [rsp+0x20], xmm3
0000707649fde1b4  vmovaps [rsp+0x30], xmm4
0000707649fde1ba  vmovaps [rsp+0x40], xmm5
0000707649fde1c0  vmovaps [rsp+0x50], xmm6
0000707649fde1c6  vmovaps [rsp+0x60], xmm7
0000707649fde1cc  vmovaps [rsp+0x70], xmm8
0000707649fde1d2  vmovaps [rsp+0x80], xmm9
0000707649fde1db  vmovaps [rsp+0x90], xmm10
0000707649fde1e4  vmovaps [rsp+0xA0], xmm11
0000707649fde1ed  vmovaps [rsp+0xB0], xmm12
0000707649fde1f6  vmovaps [rsp+0xC0], xmm13
0000707649fde1ff  vmovaps [rsp+0xD0], xmm14
0000707649fde208  vmovaps [rsp+0xE0], xmm15
0000707649fde211  sub rsp, 0x30
0000707649fde215  movaps [rsp], xmm1
0000707649fde219  movaps [rsp+0x10], xmm5
0000707649fde21e  movaps [rsp+0x20], xmm4
0000707649fde223  lea rdi, [rsp]
0000707649fde227  mov esi, 0x00
0000707649fde22c  mov rax, 0x59CB0B054530
0000707649fde236  call rax
0000707649fde238  movaps xmm1, [rsp]
0000707649fde23c  add rsp, 0x30
0000707649fde240  vmovaps xmm0, [rsp]
0000707649fde245  vmovaps xmm2, [rsp+0x10]
0000707649fde24b  vmovaps xmm3, [rsp+0x20]
0000707649fde251  vmovaps xmm4, [rsp+0x30]
0000707649fde257  vmovaps xmm5, [rsp+0x40]
0000707649fde25d  vmovaps xmm6, [rsp+0x50]
0000707649fde263  vmovaps xmm7, [rsp+0x60]
0000707649fde269  vmovaps xmm8, [rsp+0x70]
0000707649fde26f  vmovaps xmm9, [rsp+0x80]
0000707649fde278  vmovaps xmm10, [rsp+0x90]
0000707649fde281  vmovaps xmm11, [rsp+0xA0]
0000707649fde28a  vmovaps xmm12, [rsp+0xB0]
0000707649fde293  vmovaps xmm13, [rsp+0xC0]
0000707649fde29c  vmovaps xmm14, [rsp+0xD0]
0000707649fde2a5  vmovaps xmm15, [rsp+0xE0]
0000707649fde2ae  add rsp, 0xF0
0000707649fde2b5  pop r11
0000707649fde2b7  pop r10
0000707649fde2b9  pop r9
0000707649fde2bb  pop r8
0000707649fde2bd  pop rsi
0000707649fde2be  pop rdi
0000707649fde2bf  pop rdx
0000707649fde2c0  pop rcx
0000707649fde2c1  pop rax
0000707649fde2c2  add rsp, 0x08
0000707649fde2c6  jmp 0x0000707649FDC0B9
0000707649fde2cb  sub rsp, 0x08
0000707649fde2cf  push rax
0000707649fde2d0  push rcx
0000707649fde2d1  push rdx
0000707649fde2d2  push rdi
0000707649fde2d3  push rsi
0000707649fde2d4  push r8
0000707649fde2d6  push r9
0000707649fde2d8  push r10
0000707649fde2da  push r11
0000707649fde2dc  sub rsp, 0xF0
0000707649fde2e3  vmovaps [rsp], xmm0
0000707649fde2e8  vmovaps [rsp+0x10], xmm1
0000707649fde2ee  vmovaps [rsp+0x20], xmm2
0000707649fde2f4  vmovaps [rsp+0x30], xmm3
0000707649fde2fa  vmovaps [rsp+0x40], xmm5
0000707649fde300  vmovaps [rsp+0x50], xmm6
0000707649fde306  vmovaps [rsp+0x60], xmm7
0000707649fde30c  vmovaps [rsp+0x70], xmm8
0000707649fde312  vmovaps [rsp+0x80], xmm9
0000707649fde31b  vmovaps [rsp+0x90], xmm10
0000707649fde324  vmovaps [rsp+0xA0], xmm11
0000707649fde32d  vmovaps [rsp+0xB0], xmm12
0000707649fde336  vmovaps [rsp+0xC0], xmm13
0000707649fde33f  vmovaps [rsp+0xD0], xmm14
0000707649fde348  vmovaps [rsp+0xE0], xmm15
0000707649fde351  sub rsp, 0x30
0000707649fde355  movaps [rsp], xmm4
0000707649fde359  movaps [rsp+0x10], xmm3
0000707649fde35e  movaps [rsp+0x20], xmm5
0000707649fde363  lea rdi, [rsp]
0000707649fde367  mov esi, 0x00
0000707649fde36c  mov rax, 0x59CB0B054530
0000707649fde376  call rax
0000707649fde378  movaps xmm4, [rsp]
0000707649fde37c  add rsp, 0x30
0000707649fde380  vmovaps xmm0, [rsp]
0000707649fde385  vmovaps xmm1, [rsp+0x10]
0000707649fde38b  vmovaps xmm2, [rsp+0x20]
0000707649fde391  vmovaps xmm3, [rsp+0x30]
0000707649fde397  vmovaps xmm5, [rsp+0x40]
0000707649fde39d  vmovaps xmm6, [rsp+0x50]
0000707649fde3a3  vmovaps xmm7, [rsp+0x60]
0000707649fde3a9  vmovaps xmm8, [rsp+0x70]
0000707649fde3af  vmovaps xmm9, [rsp+0x80]
0000707649fde3b8  vmovaps xmm10, [rsp+0x90]
0000707649fde3c1  vmovaps xmm11, [rsp+0xA0]
0000707649fde3ca  vmovaps xmm12, [rsp+0xB0]
0000707649fde3d3  vmovaps xmm13, [rsp+0xC0]
0000707649fde3dc  vmovaps xmm14, [rsp+0xD0]
0000707649fde3e5  vmovaps xmm15, [rsp+0xE0]
0000707649fde3ee  add rsp, 0xF0
0000707649fde3f5  pop r11
0000707649fde3f7  pop r10
0000707649fde3f9  pop r9
0000707649fde3fb  pop r8
0000707649fde3fd  pop rsi
0000707649fde3fe  pop rdi
0000707649fde3ff  pop rdx
0000707649fde400  pop rcx
0000707649fde401  pop rax
0000707649fde402  add rsp, 0x08
0000707649fde406  jmp 0x0000707649FDC107
0000707649fde40b  call 0x0000707649EB52F0
0000707649fde410  jmp 0x0000707649FDC114
0000707649fde415  sub rsp, 0x08
0000707649fde419  push rax
0000707649fde41a  push rcx
0000707649fde41b  push rdx
0000707649fde41c  push rdi
0000707649fde41d  push rsi
0000707649fde41e  push r8
0000707649fde420  push r9
0000707649fde422  push r10
0000707649fde424  push r11
0000707649fde426  sub rsp, 0xF0
0000707649fde42d  vmovaps [rsp], xmm0
0000707649fde432  vmovaps [rsp+0x10], xmm1
0000707649fde438  vmovaps [rsp+0x20], xmm2
0000707649fde43e  vmovaps [rsp+0x30], xmm3
0000707649fde444  vmovaps [rsp+0x40], xmm4
0000707649fde44a  vmovaps [rsp+0x50], xmm6
0000707649fde450  vmovaps [rsp+0x60], xmm7
0000707649fde456  vmovaps [rsp+0x70], xmm8
0000707649fde45c  vmovaps [rsp+0x80], xmm9
0000707649fde465  vmovaps [rsp+0x90], xmm10
0000707649fde46e  vmovaps [rsp+0xA0], xmm11
0000707649fde477  vmovaps [rsp+0xB0], xmm12
0000707649fde480  vmovaps [rsp+0xC0], xmm13
0000707649fde489  vmovaps [rsp+0xD0], xmm14
0000707649fde492  vmovaps [rsp+0xE0], xmm15
0000707649fde49b  sub rsp, 0x30
0000707649fde49f  movaps [rsp], xmm5
0000707649fde4a3  movaps [rsp+0x10], xmm6
0000707649fde4a8  movaps [rsp+0x20], xmm3
0000707649fde4ad  lea rdi, [rsp]
0000707649fde4b1  mov esi, 0x00
0000707649fde4b6  mov rax, 0x59CB0B054530
0000707649fde4c0  call rax
0000707649fde4c2  movaps xmm5, [rsp]
0000707649fde4c6  add rsp, 0x30
0000707649fde4ca  vmovaps xmm0, [rsp]
0000707649fde4cf  vmovaps xmm1, [rsp+0x10]
0000707649fde4d5  vmovaps xmm2, [rsp+0x20]
0000707649fde4db  vmovaps xmm3, [rsp+0x30]
0000707649fde4e1  vmovaps xmm4, [rsp+0x40]
0000707649fde4e7  vmovaps xmm6, [rsp+0x50]
0000707649fde4ed  vmovaps xmm7, [rsp+0x60]
0000707649fde4f3  vmovaps xmm8, [rsp+0x70]
0000707649fde4f9  vmovaps xmm9, [rsp+0x80]
0000707649fde502  vmovaps xmm10, [rsp+0x90]
0000707649fde50b  vmovaps xmm11, [rsp+0xA0]
0000707649fde514  vmovaps xmm12, [rsp+0xB0]
0000707649fde51d  vmovaps xmm13, [rsp+0xC0]
0000707649fde526  vmovaps xmm14, [rsp+0xD0]
0000707649fde52f  vmovaps xmm15, [rsp+0xE0]
0000707649fde538  add rsp, 0xF0
0000707649fde53f  pop r11
0000707649fde541  pop r10
0000707649fde543  pop r9
0000707649fde545  pop r8
0000707649fde547  pop rsi
0000707649fde548  pop rdi
0000707649fde549  pop rdx
0000707649fde54a  pop rcx
0000707649fde54b  pop rax
0000707649fde54c  add rsp, 0x08
0000707649fde550  jmp 0x0000707649FDC13A
0000707649fde555  sub rsp, 0x08
0000707649fde559  push rax
0000707649fde55a  push rcx
0000707649fde55b  push rdx
0000707649fde55c  push rdi
0000707649fde55d  push rsi
0000707649fde55e  push r8
0000707649fde560  push r9
0000707649fde562  push r10
0000707649fde564  push r11
0000707649fde566  sub rsp, 0xF0
0000707649fde56d  vmovaps [rsp], xmm0
0000707649fde572  vmovaps [rsp+0x10], xmm1
0000707649fde578  vmovaps [rsp+0x20], xmm2
0000707649fde57e  vmovaps [rsp+0x30], xmm3
0000707649fde584  vmovaps [rsp+0x40], xmm4
0000707649fde58a  vmovaps [rsp+0x50], xmm5
0000707649fde590  vmovaps [rsp+0x60], xmm7
0000707649fde596  vmovaps [rsp+0x70], xmm8
0000707649fde59c  vmovaps [rsp+0x80], xmm9
0000707649fde5a5  vmovaps [rsp+0x90], xmm10
0000707649fde5ae  vmovaps [rsp+0xA0], xmm11
0000707649fde5b7  vmovaps [rsp+0xB0], xmm12
0000707649fde5c0  vmovaps [rsp+0xC0], xmm13
0000707649fde5c9  vmovaps [rsp+0xD0], xmm14
0000707649fde5d2  vmovaps [rsp+0xE0], xmm15
0000707649fde5db  sub rsp, 0x30
0000707649fde5df  movaps [rsp], xmm6
0000707649fde5e3  movaps [rsp+0x10], xmm9
0000707649fde5e9  movaps [rsp+0x20], xmm1
0000707649fde5ee  lea rdi, [rsp]
0000707649fde5f2  mov esi, 0x00
0000707649fde5f7  mov rax, 0x59CB0B054530
0000707649fde601  call rax
0000707649fde603  movaps xmm6, [rsp]
0000707649fde607  add rsp, 0x30
0000707649fde60b  vmovaps xmm0, [rsp]
0000707649fde610  vmovaps xmm1, [rsp+0x10]
0000707649fde616  vmovaps xmm2, [rsp+0x20]
0000707649fde61c  vmovaps xmm3, [rsp+0x30]
0000707649fde622  vmovaps xmm4, [rsp+0x40]
0000707649fde628  vmovaps xmm5, [rsp+0x50]
0000707649fde62e  vmovaps xmm7, [rsp+0x60]
0000707649fde634  vmovaps xmm8, [rsp+0x70]
0000707649fde63a  vmovaps xmm9, [rsp+0x80]
0000707649fde643  vmovaps xmm10, [rsp+0x90]
0000707649fde64c  vmovaps xmm11, [rsp+0xA0]
0000707649fde655  vmovaps xmm12, [rsp+0xB0]
0000707649fde65e  vmovaps xmm13, [rsp+0xC0]
0000707649fde667  vmovaps xmm14, [rsp+0xD0]
0000707649fde670  vmovaps xmm15, [rsp+0xE0]
0000707649fde679  add rsp, 0xF0
0000707649fde680  pop r11
0000707649fde682  pop r10
0000707649fde684  pop r9
0000707649fde686  pop r8
0000707649fde688  pop rsi
0000707649fde689  pop rdi
0000707649fde68a  pop rdx
0000707649fde68b  pop rcx
0000707649fde68c  pop rax
0000707649fde68d  add rsp, 0x08
0000707649fde691  jmp 0x0000707649FDC15E
0000707649fde696  sub rsp, 0x08
0000707649fde69a  push rax
0000707649fde69b  push rcx
0000707649fde69c  push rdx
0000707649fde69d  push rdi
0000707649fde69e  push rsi
0000707649fde69f  push r8
0000707649fde6a1  push r9
0000707649fde6a3  push r10
0000707649fde6a5  push r11
0000707649fde6a7  sub rsp, 0xF0
0000707649fde6ae  vmovaps [rsp], xmm0
0000707649fde6b3  vmovaps [rsp+0x10], xmm1
0000707649fde6b9  vmovaps [rsp+0x20], xmm2
0000707649fde6bf  vmovaps [rsp+0x30], xmm3
0000707649fde6c5  vmovaps [rsp+0x40], xmm4
0000707649fde6cb  vmovaps [rsp+0x50], xmm5
0000707649fde6d1  vmovaps [rsp+0x60], xmm6
0000707649fde6d7  vmovaps [rsp+0x70], xmm7
0000707649fde6dd  vmovaps [rsp+0x80], xmm8
0000707649fde6e6  vmovaps [rsp+0x90], xmm10
0000707649fde6ef  vmovaps [rsp+0xA0], xmm11
0000707649fde6f8  vmovaps [rsp+0xB0], xmm12
0000707649fde701  vmovaps [rsp+0xC0], xmm13
0000707649fde70a  vmovaps [rsp+0xD0], xmm14
0000707649fde713  vmovaps [rsp+0xE0], xmm15
0000707649fde71c  sub rsp, 0x30
0000707649fde720  movaps [rsp], xmm9
0000707649fde725  movaps [rsp+0x10], xmm3
0000707649fde72a  movaps [rsp+0x20], xmm1
0000707649fde72f  lea rdi, [rsp]
0000707649fde733  mov esi, 0x00
0000707649fde738  mov rax, 0x59CB0B054530
0000707649fde742  call rax
0000707649fde744  movaps xmm9, [rsp]
0000707649fde749  add rsp, 0x30
0000707649fde74d  vmovaps xmm0, [rsp]
0000707649fde752  vmovaps xmm1, [rsp+0x10]
0000707649fde758  vmovaps xmm2, [rsp+0x20]
0000707649fde75e  vmovaps xmm3, [rsp+0x30]
0000707649fde764  vmovaps xmm4, [rsp+0x40]
0000707649fde76a  vmovaps xmm5, [rsp+0x50]
0000707649fde770  vmovaps xmm6, [rsp+0x60]
0000707649fde776  vmovaps xmm7, [rsp+0x70]
0000707649fde77c  vmovaps xmm8, [rsp+0x80]
0000707649fde785  vmovaps xmm10, [rsp+0x90]
0000707649fde78e  vmovaps xmm11, [rsp+0xA0]
0000707649fde797  vmovaps xmm12, [rsp+0xB0]
0000707649fde7a0  vmovaps xmm13, [rsp+0xC0]
0000707649fde7a9  vmovaps xmm14, [rsp+0xD0]
0000707649fde7b2  vmovaps xmm15, [rsp+0xE0]
0000707649fde7bb  add rsp, 0xF0
0000707649fde7c2  pop r11
0000707649fde7c4  pop r10
0000707649fde7c6  pop r9
0000707649fde7c8  pop r8
0000707649fde7ca  pop rsi
0000707649fde7cb  pop rdi
0000707649fde7cc  pop rdx
0000707649fde7cd  pop rcx
0000707649fde7ce  pop rax
0000707649fde7cf  add rsp, 0x08
0000707649fde7d3  jmp 0x0000707649FDC1AA
0000707649fde7d8  call 0x0000707649EB52F0
0000707649fde7dd  jmp 0x0000707649FDC1B7
0000707649fde7e2  sub rsp, 0x08
0000707649fde7e6  push rax
0000707649fde7e7  push rcx
0000707649fde7e8  push rdx
0000707649fde7e9  push rdi
0000707649fde7ea  push rsi
0000707649fde7eb  push r8
0000707649fde7ed  push r9
0000707649fde7ef  push r10
0000707649fde7f1  push r11
0000707649fde7f3  sub rsp, 0xF0
0000707649fde7fa  vmovaps [rsp], xmm0
0000707649fde7ff  vmovaps [rsp+0x10], xmm1
0000707649fde805  vmovaps [rsp+0x20], xmm2
0000707649fde80b  vmovaps [rsp+0x30], xmm3
0000707649fde811  vmovaps [rsp+0x40], xmm4
0000707649fde817  vmovaps [rsp+0x50], xmm5
0000707649fde81d  vmovaps [rsp+0x60], xmm6
0000707649fde823  vmovaps [rsp+0x70], xmm7
0000707649fde829  vmovaps [rsp+0x80], xmm8
0000707649fde832  vmovaps [rsp+0x90], xmm9
0000707649fde83b  vmovaps [rsp+0xA0], xmm10
0000707649fde844  vmovaps [rsp+0xB0], xmm11
0000707649fde84d  vmovaps [rsp+0xC0], xmm12
0000707649fde856  vmovaps [rsp+0xD0], xmm13
0000707649fde85f  vmovaps [rsp+0xE0], xmm14
0000707649fde868  sub rsp, 0x30
0000707649fde86c  movaps [rsp], xmm15
0000707649fde871  movaps [rsp+0x10], xmm3
0000707649fde876  movaps [rsp+0x20], xmm7
0000707649fde87b  lea rdi, [rsp]
0000707649fde87f  mov esi, 0x00
0000707649fde884  mov rax, 0x59CB0B054530
0000707649fde88e  call rax
0000707649fde890  movaps xmm15, [rsp]
0000707649fde895  add rsp, 0x30
0000707649fde899  vmovaps xmm0, [rsp]
0000707649fde89e  vmovaps xmm1, [rsp+0x10]
0000707649fde8a4  vmovaps xmm2, [rsp+0x20]
0000707649fde8aa  vmovaps xmm3, [rsp+0x30]
0000707649fde8b0  vmovaps xmm4, [rsp+0x40]
0000707649fde8b6  vmovaps xmm5, [rsp+0x50]
0000707649fde8bc  vmovaps xmm6, [rsp+0x60]
0000707649fde8c2  vmovaps xmm7, [rsp+0x70]
0000707649fde8c8  vmovaps xmm8, [rsp+0x80]
0000707649fde8d1  vmovaps xmm9, [rsp+0x90]
0000707649fde8da  vmovaps xmm10, [rsp+0xA0]
0000707649fde8e3  vmovaps xmm11, [rsp+0xB0]
0000707649fde8ec  vmovaps xmm12, [rsp+0xC0]
0000707649fde8f5  vmovaps xmm13, [rsp+0xD0]
0000707649fde8fe  vmovaps xmm14, [rsp+0xE0]
0000707649fde907  add rsp, 0xF0
0000707649fde90e  pop r11
0000707649fde910  pop r10
0000707649fde912  pop r9
0000707649fde914  pop r8
0000707649fde916  pop rsi
0000707649fde917  pop rdi
0000707649fde918  pop rdx
0000707649fde919  pop rcx
0000707649fde91a  pop rax
0000707649fde91b  add rsp, 0x08
0000707649fde91f  jmp 0x0000707649FDC1E3
0000707649fde924  sub rsp, 0x08
0000707649fde928  push rax
0000707649fde929  push rcx
0000707649fde92a  push rdx
0000707649fde92b  push rdi
0000707649fde92c  push rsi
0000707649fde92d  push r8
0000707649fde92f  push r9
0000707649fde931  push r10
0000707649fde933  push r11
0000707649fde935  sub rsp, 0xF0
0000707649fde93c  vmovaps [rsp], xmm0
0000707649fde941  vmovaps [rsp+0x10], xmm1
0000707649fde947  vmovaps [rsp+0x20], xmm2
0000707649fde94d  vmovaps [rsp+0x30], xmm4
0000707649fde953  vmovaps [rsp+0x40], xmm5
0000707649fde959  vmovaps [rsp+0x50], xmm6
0000707649fde95f  vmovaps [rsp+0x60], xmm7
0000707649fde965  vmovaps [rsp+0x70], xmm8
0000707649fde96b  vmovaps [rsp+0x80], xmm9
0000707649fde974  vmovaps [rsp+0x90], xmm10
0000707649fde97d  vmovaps [rsp+0xA0], xmm11
0000707649fde986  vmovaps [rsp+0xB0], xmm12
0000707649fde98f  vmovaps [rsp+0xC0], xmm13
0000707649fde998  vmovaps [rsp+0xD0], xmm14
0000707649fde9a1  vmovaps [rsp+0xE0], xmm15
0000707649fde9aa  sub rsp, 0x30
0000707649fde9ae  movaps [rsp], xmm3
0000707649fde9b2  movaps [rsp+0x10], xmm1
0000707649fde9b7  movaps [rsp+0x20], xmm15
0000707649fde9bd  lea rdi, [rsp]
0000707649fde9c1  mov esi, 0x00
0000707649fde9c6  mov rax, 0x59CB0B054530
0000707649fde9d0  call rax
0000707649fde9d2  movaps xmm3, [rsp]
0000707649fde9d6  add rsp, 0x30
0000707649fde9da  vmovaps xmm0, [rsp]
0000707649fde9df  vmovaps xmm1, [rsp+0x10]
0000707649fde9e5  vmovaps xmm2, [rsp+0x20]
0000707649fde9eb  vmovaps xmm4, [rsp+0x30]
0000707649fde9f1  vmovaps xmm5, [rsp+0x40]
0000707649fde9f7  vmovaps xmm6, [rsp+0x50]
0000707649fde9fd  vmovaps xmm7, [rsp+0x60]
0000707649fdea03  vmovaps xmm8, [rsp+0x70]
0000707649fdea09  vmovaps xmm9, [rsp+0x80]
0000707649fdea12  vmovaps xmm10, [rsp+0x90]
0000707649fdea1b  vmovaps xmm11, [rsp+0xA0]
0000707649fdea24  vmovaps xmm12, [rsp+0xB0]
0000707649fdea2d  vmovaps xmm13, [rsp+0xC0]
0000707649fdea36  vmovaps xmm14, [rsp+0xD0]
0000707649fdea3f  vmovaps xmm15, [rsp+0xE0]
0000707649fdea48  add rsp, 0xF0
0000707649fdea4f  pop r11
0000707649fdea51  pop r10
0000707649fdea53  pop r9
0000707649fdea55  pop r8
0000707649fdea57  pop rsi
0000707649fdea58  pop rdi
0000707649fdea59  pop rdx
0000707649fdea5a  pop rcx
0000707649fdea5b  pop rax
0000707649fdea5c  add rsp, 0x08
0000707649fdea60  jmp 0x0000707649FDC272
0000707649fdea65  call 0x0000707649EB52F0
0000707649fdea6a  jmp 0x0000707649FDC27C
0000707649fdea6f  sub rsp, 0x08
0000707649fdea73  push rax
0000707649fdea74  push rcx
0000707649fdea75  push rdx
0000707649fdea76  push rdi
0000707649fdea77  push rsi
0000707649fdea78  push r8
0000707649fdea7a  push r9
0000707649fdea7c  push r10
0000707649fdea7e  push r11
0000707649fdea80  sub rsp, 0xF0
0000707649fdea87  vmovaps [rsp], xmm0
0000707649fdea8c  vmovaps [rsp+0x10], xmm1
0000707649fdea92  vmovaps [rsp+0x20], xmm2
0000707649fdea98  vmovaps [rsp+0x30], xmm3
0000707649fdea9e  vmovaps [rsp+0x40], xmm4
0000707649fdeaa4  vmovaps [rsp+0x50], xmm5
0000707649fdeaaa  vmovaps [rsp+0x60], xmm6
0000707649fdeab0  vmovaps [rsp+0x70], xmm7
0000707649fdeab6  vmovaps [rsp+0x80], xmm8
0000707649fdeabf  vmovaps [rsp+0x90], xmm9
0000707649fdeac8  vmovaps [rsp+0xA0], xmm10
0000707649fdead1  vmovaps [rsp+0xB0], xmm11
0000707649fdeada  vmovaps [rsp+0xC0], xmm12
0000707649fdeae3  vmovaps [rsp+0xD0], xmm13
0000707649fdeaec  vmovaps [rsp+0xE0], xmm14
0000707649fdeaf5  sub rsp, 0x30
0000707649fdeaf9  movaps [rsp], xmm15
0000707649fdeafe  movaps [rsp+0x10], xmm14
0000707649fdeb04  movaps [rsp+0x20], xmm4
0000707649fdeb09  lea rdi, [rsp]
0000707649fdeb0d  mov esi, 0x00
0000707649fdeb12  mov rax, 0x59CB0B054530
0000707649fdeb1c  call rax
0000707649fdeb1e  movaps xmm15, [rsp]
0000707649fdeb23  add rsp, 0x30
0000707649fdeb27  vmovaps xmm0, [rsp]
0000707649fdeb2c  vmovaps xmm1, [rsp+0x10]
0000707649fdeb32  vmovaps xmm2, [rsp+0x20]
0000707649fdeb38  vmovaps xmm3, [rsp+0x30]
0000707649fdeb3e  vmovaps xmm4, [rsp+0x40]
0000707649fdeb44  vmovaps xmm5, [rsp+0x50]
0000707649fdeb4a  vmovaps xmm6, [rsp+0x60]
0000707649fdeb50  vmovaps xmm7, [rsp+0x70]
0000707649fdeb56  vmovaps xmm8, [rsp+0x80]
0000707649fdeb5f  vmovaps xmm9, [rsp+0x90]
0000707649fdeb68  vmovaps xmm10, [rsp+0xA0]
0000707649fdeb71  vmovaps xmm11, [rsp+0xB0]
0000707649fdeb7a  vmovaps xmm12, [rsp+0xC0]
0000707649fdeb83  vmovaps xmm13, [rsp+0xD0]
0000707649fdeb8c  vmovaps xmm14, [rsp+0xE0]
0000707649fdeb95  add rsp, 0xF0
0000707649fdeb9c  pop r11
0000707649fdeb9e  pop r10
0000707649fdeba0  pop r9
0000707649fdeba2  pop r8
0000707649fdeba4  pop rsi
0000707649fdeba5  pop rdi
0000707649fdeba6  pop rdx
0000707649fdeba7  pop rcx
0000707649fdeba8  pop rax
0000707649fdeba9  add rsp, 0x08
0000707649fdebad  jmp 0x0000707649FDC2AA
0000707649fdebb2  sub rsp, 0x08
0000707649fdebb6  push rax
0000707649fdebb7  push rcx
0000707649fdebb8  push rdx
0000707649fdebb9  push rdi
0000707649fdebba  push rsi
0000707649fdebbb  push r8
0000707649fdebbd  push r9
0000707649fdebbf  push r10
0000707649fdebc1  push r11
0000707649fdebc3  sub rsp, 0xF0
0000707649fdebca  vmovaps [rsp], xmm0
0000707649fdebcf  vmovaps [rsp+0x10], xmm1
0000707649fdebd5  vmovaps [rsp+0x20], xmm2
0000707649fdebdb  vmovaps [rsp+0x30], xmm3
0000707649fdebe1  vmovaps [rsp+0x40], xmm4
0000707649fdebe7  vmovaps [rsp+0x50], xmm5
0000707649fdebed  vmovaps [rsp+0x60], xmm6
0000707649fdebf3  vmovaps [rsp+0x70], xmm7
0000707649fdebf9  vmovaps [rsp+0x80], xmm8
0000707649fdec02  vmovaps [rsp+0x90], xmm9
0000707649fdec0b  vmovaps [rsp+0xA0], xmm10
0000707649fdec14  vmovaps [rsp+0xB0], xmm11
0000707649fdec1d  vmovaps [rsp+0xC0], xmm12
0000707649fdec26  vmovaps [rsp+0xD0], xmm13
0000707649fdec2f  vmovaps [rsp+0xE0], xmm15
0000707649fdec38  sub rsp, 0x30
0000707649fdec3c  movaps [rsp], xmm14
0000707649fdec41  movaps [rsp+0x10], xmm2
0000707649fdec46  movaps [rsp+0x20], xmm1
0000707649fdec4b  lea rdi, [rsp]
0000707649fdec4f  mov esi, 0x00
0000707649fdec54  mov rax, 0x59CB0B054530
0000707649fdec5e  call rax
0000707649fdec60  movaps xmm14, [rsp]
0000707649fdec65  add rsp, 0x30
0000707649fdec69  vmovaps xmm0, [rsp]
0000707649fdec6e  vmovaps xmm1, [rsp+0x10]
0000707649fdec74  vmovaps xmm2, [rsp+0x20]
0000707649fdec7a  vmovaps xmm3, [rsp+0x30]
0000707649fdec80  vmovaps xmm4, [rsp+0x40]
0000707649fdec86  vmovaps xmm5, [rsp+0x50]
0000707649fdec8c  vmovaps xmm6, [rsp+0x60]
0000707649fdec92  vmovaps xmm7, [rsp+0x70]
0000707649fdec98  vmovaps xmm8, [rsp+0x80]
0000707649fdeca1  vmovaps xmm9, [rsp+0x90]
0000707649fdecaa  vmovaps xmm10, [rsp+0xA0]
0000707649fdecb3  vmovaps xmm11, [rsp+0xB0]
0000707649fdecbc  vmovaps xmm12, [rsp+0xC0]
0000707649fdecc5  vmovaps xmm13, [rsp+0xD0]
0000707649fdecce  vmovaps xmm15, [rsp+0xE0]
0000707649fdecd7  add rsp, 0xF0
0000707649fdecde  pop r11
0000707649fdece0  pop r10
0000707649fdece2  pop r9
0000707649fdece4  pop r8
0000707649fdece6  pop rsi
0000707649fdece7  pop rdi
0000707649fdece8  pop rdx
0000707649fdece9  pop rcx
0000707649fdecea  pop rax
0000707649fdeceb  add rsp, 0x08
0000707649fdecef  jmp 0x0000707649FDC2D0
0000707649fdecf4  sub rsp, 0x08
0000707649fdecf8  push rax
0000707649fdecf9  push rcx
0000707649fdecfa  push rdx
0000707649fdecfb  push rdi
0000707649fdecfc  push rsi
0000707649fdecfd  push r8
0000707649fdecff  push r9
0000707649fded01  push r10
0000707649fded03  push r11
0000707649fded05  sub rsp, 0xF0
0000707649fded0c  vmovaps [rsp], xmm0
0000707649fded11  vmovaps [rsp+0x10], xmm2
0000707649fded17  vmovaps [rsp+0x20], xmm3
0000707649fded1d  vmovaps [rsp+0x30], xmm4
0000707649fded23  vmovaps [rsp+0x40], xmm5
0000707649fded29  vmovaps [rsp+0x50], xmm6
0000707649fded2f  vmovaps [rsp+0x60], xmm7
0000707649fded35  vmovaps [rsp+0x70], xmm8
0000707649fded3b  vmovaps [rsp+0x80], xmm9
0000707649fded44  vmovaps [rsp+0x90], xmm10
0000707649fded4d  vmovaps [rsp+0xA0], xmm11
0000707649fded56  vmovaps [rsp+0xB0], xmm12
0000707649fded5f  vmovaps [rsp+0xC0], xmm13
0000707649fded68  vmovaps [rsp+0xD0], xmm14
0000707649fded71  vmovaps [rsp+0xE0], xmm15
0000707649fded7a  sub rsp, 0x30
0000707649fded7e  movaps [rsp], xmm1
0000707649fded82  movaps [rsp+0x10], xmm4
0000707649fded87  movaps [rsp+0x20], xmm9
0000707649fded8d  lea rdi, [rsp]
0000707649fded91  mov esi, 0x00
0000707649fded96  mov rax, 0x59CB0B054530
0000707649fdeda0  call rax
0000707649fdeda2  movaps xmm1, [rsp]
0000707649fdeda6  add rsp, 0x30
0000707649fdedaa  vmovaps xmm0, [rsp]
0000707649fdedaf  vmovaps xmm2, [rsp+0x10]
0000707649fdedb5  vmovaps xmm3, [rsp+0x20]
0000707649fdedbb  vmovaps xmm4, [rsp+0x30]
0000707649fdedc1  vmovaps xmm5, [rsp+0x40]
0000707649fdedc7  vmovaps xmm6, [rsp+0x50]
0000707649fdedcd  vmovaps xmm7, [rsp+0x60]
0000707649fdedd3  vmovaps xmm8, [rsp+0x70]
0000707649fdedd9  vmovaps xmm9, [rsp+0x80]
0000707649fdede2  vmovaps xmm10, [rsp+0x90]
0000707649fdedeb  vmovaps xmm11, [rsp+0xA0]
0000707649fdedf4  vmovaps xmm12, [rsp+0xB0]
0000707649fdedfd  vmovaps xmm13, [rsp+0xC0]
0000707649fdee06  vmovaps xmm14, [rsp+0xD0]
0000707649fdee0f  vmovaps xmm15, [rsp+0xE0]
0000707649fdee18  add rsp, 0xF0
0000707649fdee1f  pop r11
0000707649fdee21  pop r10
0000707649fdee23  pop r9
0000707649fdee25  pop r8
0000707649fdee27  pop rsi
0000707649fdee28  pop rdi
0000707649fdee29  pop rdx
0000707649fdee2a  pop rcx
0000707649fdee2b  pop rax
0000707649fdee2c  add rsp, 0x08
0000707649fdee30  jmp 0x0000707649FDC2EE
0000707649fdee35  sub rsp, 0x08
0000707649fdee39  push rax
0000707649fdee3a  push rcx
0000707649fdee3b  push rdx
0000707649fdee3c  push rdi
0000707649fdee3d  push rsi
0000707649fdee3e  push r8
0000707649fdee40  push r9
0000707649fdee42  push r10
0000707649fdee44  push r11
0000707649fdee46  sub rsp, 0xF0
0000707649fdee4d  vmovaps [rsp], xmm0
0000707649fdee52  vmovaps [rsp+0x10], xmm1
0000707649fdee58  vmovaps [rsp+0x20], xmm2
0000707649fdee5e  vmovaps [rsp+0x30], xmm3
0000707649fdee64  vmovaps [rsp+0x40], xmm5
0000707649fdee6a  vmovaps [rsp+0x50], xmm6
0000707649fdee70  vmovaps [rsp+0x60], xmm7
0000707649fdee76  vmovaps [rsp+0x70], xmm8
0000707649fdee7c  vmovaps [rsp+0x80], xmm9
0000707649fdee85  vmovaps [rsp+0x90], xmm10
0000707649fdee8e  vmovaps [rsp+0xA0], xmm11
0000707649fdee97  vmovaps [rsp+0xB0], xmm12
0000707649fdeea0  vmovaps [rsp+0xC0], xmm13
0000707649fdeea9  vmovaps [rsp+0xD0], xmm14
0000707649fdeeb2  vmovaps [rsp+0xE0], xmm15
0000707649fdeebb  sub rsp, 0x30
0000707649fdeebf  movaps [rsp], xmm4
0000707649fdeec3  movaps [rsp+0x10], xmm2
0000707649fdeec8  movaps [rsp+0x20], xmm9
0000707649fdeece  lea rdi, [rsp]
0000707649fdeed2  mov esi, 0x00
0000707649fdeed7  mov rax, 0x59CB0B054530
0000707649fdeee1  call rax
0000707649fdeee3  movaps xmm4, [rsp]
0000707649fdeee7  add rsp, 0x30
0000707649fdeeeb  vmovaps xmm0, [rsp]
0000707649fdeef0  vmovaps xmm1, [rsp+0x10]
0000707649fdeef6  vmovaps xmm2, [rsp+0x20]
0000707649fdeefc  vmovaps xmm3, [rsp+0x30]
0000707649fdef02  vmovaps xmm5, [rsp+0x40]
0000707649fdef08  vmovaps xmm6, [rsp+0x50]
0000707649fdef0e  vmovaps xmm7, [rsp+0x60]
0000707649fdef14  vmovaps xmm8, [rsp+0x70]
0000707649fdef1a  vmovaps xmm9, [rsp+0x80]
0000707649fdef23  vmovaps xmm10, [rsp+0x90]
0000707649fdef2c  vmovaps xmm11, [rsp+0xA0]
0000707649fdef35  vmovaps xmm12, [rsp+0xB0]
0000707649fdef3e  vmovaps xmm13, [rsp+0xC0]
0000707649fdef47  vmovaps xmm14, [rsp+0xD0]
0000707649fdef50  vmovaps xmm15, [rsp+0xE0]
0000707649fdef59  add rsp, 0xF0
0000707649fdef60  pop r11
0000707649fdef62  pop r10
0000707649fdef64  pop r9
0000707649fdef66  pop r8
0000707649fdef68  pop rsi
0000707649fdef69  pop rdi
0000707649fdef6a  pop rdx
0000707649fdef6b  pop rcx
0000707649fdef6c  pop rax
0000707649fdef6d  add rsp, 0x08
0000707649fdef71  jmp 0x0000707649FDC31E
0000707649fdef76  sub rsp, 0x08
0000707649fdef7a  push rax
0000707649fdef7b  push rcx
0000707649fdef7c  push rdx
0000707649fdef7d  push rdi
0000707649fdef7e  push rsi
0000707649fdef7f  push r8
0000707649fdef81  push r9
0000707649fdef83  push r10
0000707649fdef85  push r11
0000707649fdef87  sub rsp, 0xF0
0000707649fdef8e  vmovaps [rsp], xmm0
0000707649fdef93  vmovaps [rsp+0x10], xmm1
0000707649fdef99  vmovaps [rsp+0x20], xmm2
0000707649fdef9f  vmovaps [rsp+0x30], xmm3
0000707649fdefa5  vmovaps [rsp+0x40], xmm4
0000707649fdefab  vmovaps [rsp+0x50], xmm5
0000707649fdefb1  vmovaps [rsp+0x60], xmm6
0000707649fdefb7  vmovaps [rsp+0x70], xmm7
0000707649fdefbd  vmovaps [rsp+0x80], xmm8
0000707649fdefc6  vmovaps [rsp+0x90], xmm10
0000707649fdefcf  vmovaps [rsp+0xA0], xmm11
0000707649fdefd8  vmovaps [rsp+0xB0], xmm12
0000707649fdefe1  vmovaps [rsp+0xC0], xmm13
0000707649fdefea  vmovaps [rsp+0xD0], xmm14
0000707649fdeff3  vmovaps [rsp+0xE0], xmm15
0000707649fdeffc  sub rsp, 0x30
0000707649fdf000  movaps [rsp], xmm9
0000707649fdf005  movaps [rsp+0x10], xmm2
0000707649fdf00a  movaps [rsp+0x20], xmm1
0000707649fdf00f  lea rdi, [rsp]
0000707649fdf013  mov esi, 0x00
0000707649fdf018  mov rax, 0x59CB0B054530
0000707649fdf022  call rax
0000707649fdf024  movaps xmm9, [rsp]
0000707649fdf029  add rsp, 0x30
0000707649fdf02d  vmovaps xmm0, [rsp]
0000707649fdf032  vmovaps xmm1, [rsp+0x10]
0000707649fdf038  vmovaps xmm2, [rsp+0x20]
0000707649fdf03e  vmovaps xmm3, [rsp+0x30]
0000707649fdf044  vmovaps xmm4, [rsp+0x40]
0000707649fdf04a  vmovaps xmm5, [rsp+0x50]
0000707649fdf050  vmovaps xmm6, [rsp+0x60]
0000707649fdf056  vmovaps xmm7, [rsp+0x70]
0000707649fdf05c  vmovaps xmm8, [rsp+0x80]
0000707649fdf065  vmovaps xmm10, [rsp+0x90]
0000707649fdf06e  vmovaps xmm11, [rsp+0xA0]
0000707649fdf077  vmovaps xmm12, [rsp+0xB0]
0000707649fdf080  vmovaps xmm13, [rsp+0xC0]
0000707649fdf089  vmovaps xmm14, [rsp+0xD0]
0000707649fdf092  vmovaps xmm15, [rsp+0xE0]
0000707649fdf09b  add rsp, 0xF0
0000707649fdf0a2  pop r11
0000707649fdf0a4  pop r10
0000707649fdf0a6  pop r9
0000707649fdf0a8  pop r8
0000707649fdf0aa  pop rsi
0000707649fdf0ab  pop rdi
0000707649fdf0ac  pop rdx
0000707649fdf0ad  pop rcx
0000707649fdf0ae  pop rax
0000707649fdf0af  add rsp, 0x08
0000707649fdf0b3  jmp 0x0000707649FDC354
0000707649fdf0b8  sub rsp, 0x08
0000707649fdf0bc  push rax
0000707649fdf0bd  push rcx
0000707649fdf0be  push rdx
0000707649fdf0bf  push rdi
0000707649fdf0c0  push rsi
0000707649fdf0c1  push r8
0000707649fdf0c3  push r9
0000707649fdf0c5  push r10
0000707649fdf0c7  push r11
0000707649fdf0c9  sub rsp, 0xF0
0000707649fdf0d0  vmovaps [rsp], xmm0
0000707649fdf0d5  vmovaps [rsp+0x10], xmm2
0000707649fdf0db  vmovaps [rsp+0x20], xmm3
0000707649fdf0e1  vmovaps [rsp+0x30], xmm4
0000707649fdf0e7  vmovaps [rsp+0x40], xmm5
0000707649fdf0ed  vmovaps [rsp+0x50], xmm6
0000707649fdf0f3  vmovaps [rsp+0x60], xmm7
0000707649fdf0f9  vmovaps [rsp+0x70], xmm8
0000707649fdf0ff  vmovaps [rsp+0x80], xmm9
0000707649fdf108  vmovaps [rsp+0x90], xmm10
0000707649fdf111  vmovaps [rsp+0xA0], xmm11
0000707649fdf11a  vmovaps [rsp+0xB0], xmm12
0000707649fdf123  vmovaps [rsp+0xC0], xmm13
0000707649fdf12c  vmovaps [rsp+0xD0], xmm14
0000707649fdf135  vmovaps [rsp+0xE0], xmm15
0000707649fdf13e  sub rsp, 0x30
0000707649fdf142  movaps [rsp], xmm1
0000707649fdf146  movaps [rsp+0x10], xmm15
0000707649fdf14c  movaps [rsp+0x20], xmm6
0000707649fdf151  lea rdi, [rsp]
0000707649fdf155  mov esi, 0x00
0000707649fdf15a  mov rax, 0x59CB0B054530
0000707649fdf164  call rax
0000707649fdf166  movaps xmm1, [rsp]
0000707649fdf16a  add rsp, 0x30
0000707649fdf16e  vmovaps xmm0, [rsp]
0000707649fdf173  vmovaps xmm2, [rsp+0x10]
0000707649fdf179  vmovaps xmm3, [rsp+0x20]
0000707649fdf17f  vmovaps xmm4, [rsp+0x30]
0000707649fdf185  vmovaps xmm5, [rsp+0x40]
0000707649fdf18b  vmovaps xmm6, [rsp+0x50]
0000707649fdf191  vmovaps xmm7, [rsp+0x60]
0000707649fdf197  vmovaps xmm8, [rsp+0x70]
0000707649fdf19d  vmovaps xmm9, [rsp+0x80]
0000707649fdf1a6  vmovaps xmm10, [rsp+0x90]
0000707649fdf1af  vmovaps xmm11, [rsp+0xA0]
0000707649fdf1b8  vmovaps xmm12, [rsp+0xB0]
0000707649fdf1c1  vmovaps xmm13, [rsp+0xC0]
0000707649fdf1ca  vmovaps xmm14, [rsp+0xD0]
0000707649fdf1d3  vmovaps xmm15, [rsp+0xE0]
0000707649fdf1dc  add rsp, 0xF0
0000707649fdf1e3  pop r11
0000707649fdf1e5  pop r10
0000707649fdf1e7  pop r9
0000707649fdf1e9  pop r8
0000707649fdf1eb  pop rsi
0000707649fdf1ec  pop rdi
0000707649fdf1ed  pop rdx
0000707649fdf1ee  pop rcx
0000707649fdf1ef  pop rax
0000707649fdf1f0  add rsp, 0x08
0000707649fdf1f4  jmp 0x0000707649FDC375
0000707649fdf1f9  sub rsp, 0x08
0000707649fdf1fd  push rax
0000707649fdf1fe  push rcx
0000707649fdf1ff  push rdx
0000707649fdf200  push rdi
0000707649fdf201  push rsi
0000707649fdf202  push r8
0000707649fdf204  push r9
0000707649fdf206  push r10
0000707649fdf208  push r11
0000707649fdf20a  sub rsp, 0xF0
0000707649fdf211  vmovaps [rsp], xmm0
0000707649fdf216  vmovaps [rsp+0x10], xmm1
0000707649fdf21c  vmovaps [rsp+0x20], xmm2
0000707649fdf222  vmovaps [rsp+0x30], xmm3
0000707649fdf228  vmovaps [rsp+0x40], xmm4
0000707649fdf22e  vmovaps [rsp+0x50], xmm5
0000707649fdf234  vmovaps [rsp+0x60], xmm6
0000707649fdf23a  vmovaps [rsp+0x70], xmm7
0000707649fdf240  vmovaps [rsp+0x80], xmm8
0000707649fdf249  vmovaps [rsp+0x90], xmm9
0000707649fdf252  vmovaps [rsp+0xA0], xmm10
0000707649fdf25b  vmovaps [rsp+0xB0], xmm11
0000707649fdf264  vmovaps [rsp+0xC0], xmm12
0000707649fdf26d  vmovaps [rsp+0xD0], xmm13
0000707649fdf276  vmovaps [rsp+0xE0], xmm14
0000707649fdf27f  sub rsp, 0x30
0000707649fdf283  movaps [rsp], xmm15
0000707649fdf288  movaps [rsp+0x10], xmm5
0000707649fdf28d  movaps [rsp+0x20], xmm3
0000707649fdf292  lea rdi, [rsp]
0000707649fdf296  mov esi, 0x00
0000707649fdf29b  mov rax, 0x59CB0B054530
0000707649fdf2a5  call rax
0000707649fdf2a7  movaps xmm15, [rsp]
0000707649fdf2ac  add rsp, 0x30
0000707649fdf2b0  vmovaps xmm0, [rsp]
0000707649fdf2b5  vmovaps xmm1, [rsp+0x10]
0000707649fdf2bb  vmovaps xmm2, [rsp+0x20]
0000707649fdf2c1  vmovaps xmm3, [rsp+0x30]
0000707649fdf2c7  vmovaps xmm4, [rsp+0x40]
0000707649fdf2cd  vmovaps xmm5, [rsp+0x50]
0000707649fdf2d3  vmovaps xmm6, [rsp+0x60]
0000707649fdf2d9  vmovaps xmm7, [rsp+0x70]
0000707649fdf2df  vmovaps xmm8, [rsp+0x80]
0000707649fdf2e8  vmovaps xmm9, [rsp+0x90]
0000707649fdf2f1  vmovaps xmm10, [rsp+0xA0]
0000707649fdf2fa  vmovaps xmm11, [rsp+0xB0]
0000707649fdf303  vmovaps xmm12, [rsp+0xC0]
0000707649fdf30c  vmovaps xmm13, [rsp+0xD0]
0000707649fdf315  vmovaps xmm14, [rsp+0xE0]
0000707649fdf31e  add rsp, 0xF0
0000707649fdf325  pop r11
0000707649fdf327  pop r10
0000707649fdf329  pop r9
0000707649fdf32b  pop r8
0000707649fdf32d  pop rsi
0000707649fdf32e  pop rdi
0000707649fdf32f  pop rdx
0000707649fdf330  pop rcx
0000707649fdf331  pop rax
0000707649fdf332  add rsp, 0x08
0000707649fdf336  jmp 0x0000707649FDC38F
0000707649fdf33b  sub rsp, 0x08
0000707649fdf33f  push rax
0000707649fdf340  push rcx
0000707649fdf341  push rdx
0000707649fdf342  push rdi
0000707649fdf343  push rsi
0000707649fdf344  push r8
0000707649fdf346  push r9
0000707649fdf348  push r10
0000707649fdf34a  push r11
0000707649fdf34c  sub rsp, 0xF0
0000707649fdf353  vmovaps [rsp], xmm0
0000707649fdf358  vmovaps [rsp+0x10], xmm1
0000707649fdf35e  vmovaps [rsp+0x20], xmm2
0000707649fdf364  vmovaps [rsp+0x30], xmm3
0000707649fdf36a  vmovaps [rsp+0x40], xmm4
0000707649fdf370  vmovaps [rsp+0x50], xmm6
0000707649fdf376  vmovaps [rsp+0x60], xmm7
0000707649fdf37c  vmovaps [rsp+0x70], xmm8
0000707649fdf382  vmovaps [rsp+0x80], xmm9
0000707649fdf38b  vmovaps [rsp+0x90], xmm10
0000707649fdf394  vmovaps [rsp+0xA0], xmm11
0000707649fdf39d  vmovaps [rsp+0xB0], xmm12
0000707649fdf3a6  vmovaps [rsp+0xC0], xmm13
0000707649fdf3af  vmovaps [rsp+0xD0], xmm14
0000707649fdf3b8  vmovaps [rsp+0xE0], xmm15
0000707649fdf3c1  sub rsp, 0x30
0000707649fdf3c5  movaps [rsp], xmm5
0000707649fdf3c9  movaps [rsp+0x10], xmm8
0000707649fdf3cf  movaps [rsp+0x20], xmm6
0000707649fdf3d4  lea rdi, [rsp]
0000707649fdf3d8  mov esi, 0x00
0000707649fdf3dd  mov rax, 0x59CB0B054530
0000707649fdf3e7  call rax
0000707649fdf3e9  movaps xmm5, [rsp]
0000707649fdf3ed  add rsp, 0x30
0000707649fdf3f1  vmovaps xmm0, [rsp]
0000707649fdf3f6  vmovaps xmm1, [rsp+0x10]
0000707649fdf3fc  vmovaps xmm2, [rsp+0x20]
0000707649fdf402  vmovaps xmm3, [rsp+0x30]
0000707649fdf408  vmovaps xmm4, [rsp+0x40]
0000707649fdf40e  vmovaps xmm6, [rsp+0x50]
0000707649fdf414  vmovaps xmm7, [rsp+0x60]
0000707649fdf41a  vmovaps xmm8, [rsp+0x70]
0000707649fdf420  vmovaps xmm9, [rsp+0x80]
0000707649fdf429  vmovaps xmm10, [rsp+0x90]
0000707649fdf432  vmovaps xmm11, [rsp+0xA0]
0000707649fdf43b  vmovaps xmm12, [rsp+0xB0]
0000707649fdf444  vmovaps xmm13, [rsp+0xC0]
0000707649fdf44d  vmovaps xmm14, [rsp+0xD0]
0000707649fdf456  vmovaps xmm15, [rsp+0xE0]
0000707649fdf45f  add rsp, 0xF0
0000707649fdf466  pop r11
0000707649fdf468  pop r10
0000707649fdf46a  pop r9
0000707649fdf46c  pop r8
0000707649fdf46e  pop rsi
0000707649fdf46f  pop rdi
0000707649fdf470  pop rdx
0000707649fdf471  pop rcx
0000707649fdf472  pop rax
0000707649fdf473  add rsp, 0x08
0000707649fdf477  jmp 0x0000707649FDC3B3
0000707649fdf47c  sub rsp, 0x08
0000707649fdf480  push rax
0000707649fdf481  push rcx
0000707649fdf482  push rdx
0000707649fdf483  push rdi
0000707649fdf484  push rsi
0000707649fdf485  push r8
0000707649fdf487  push r9
0000707649fdf489  push r10
0000707649fdf48b  push r11
0000707649fdf48d  sub rsp, 0xF0
0000707649fdf494  vmovaps [rsp], xmm0
0000707649fdf499  vmovaps [rsp+0x10], xmm1
0000707649fdf49f  vmovaps [rsp+0x20], xmm2
0000707649fdf4a5  vmovaps [rsp+0x30], xmm3
0000707649fdf4ab  vmovaps [rsp+0x40], xmm4
0000707649fdf4b1  vmovaps [rsp+0x50], xmm5
0000707649fdf4b7  vmovaps [rsp+0x60], xmm7
0000707649fdf4bd  vmovaps [rsp+0x70], xmm8
0000707649fdf4c3  vmovaps [rsp+0x80], xmm9
0000707649fdf4cc  vmovaps [rsp+0x90], xmm10
0000707649fdf4d5  vmovaps [rsp+0xA0], xmm11
0000707649fdf4de  vmovaps [rsp+0xB0], xmm12
0000707649fdf4e7  vmovaps [rsp+0xC0], xmm13
0000707649fdf4f0  vmovaps [rsp+0xD0], xmm14
0000707649fdf4f9  vmovaps [rsp+0xE0], xmm15
0000707649fdf502  sub rsp, 0x30
0000707649fdf506  movaps [rsp], xmm6
0000707649fdf50a  movaps [rsp+0x10], xmm10
0000707649fdf510  movaps [rsp+0x20], xmm8
0000707649fdf516  lea rdi, [rsp]
0000707649fdf51a  mov esi, 0x00
0000707649fdf51f  mov rax, 0x59CB0B054530
0000707649fdf529  call rax
0000707649fdf52b  movaps xmm6, [rsp]
0000707649fdf52f  add rsp, 0x30
0000707649fdf533  vmovaps xmm0, [rsp]
0000707649fdf538  vmovaps xmm1, [rsp+0x10]
0000707649fdf53e  vmovaps xmm2, [rsp+0x20]
0000707649fdf544  vmovaps xmm3, [rsp+0x30]
0000707649fdf54a  vmovaps xmm4, [rsp+0x40]
0000707649fdf550  vmovaps xmm5, [rsp+0x50]
0000707649fdf556  vmovaps xmm7, [rsp+0x60]
0000707649fdf55c  vmovaps xmm8, [rsp+0x70]
0000707649fdf562  vmovaps xmm9, [rsp+0x80]
0000707649fdf56b  vmovaps xmm10, [rsp+0x90]
0000707649fdf574  vmovaps xmm11, [rsp+0xA0]
0000707649fdf57d  vmovaps xmm12, [rsp+0xB0]
0000707649fdf586  vmovaps xmm13, [rsp+0xC0]
0000707649fdf58f  vmovaps xmm14, [rsp+0xD0]
0000707649fdf598  vmovaps xmm15, [rsp+0xE0]
0000707649fdf5a1  add rsp, 0xF0
0000707649fdf5a8  pop r11
0000707649fdf5aa  pop r10
0000707649fdf5ac  pop r9
0000707649fdf5ae  pop r8
0000707649fdf5b0  pop rsi
0000707649fdf5b1  pop rdi
0000707649fdf5b2  pop rdx
0000707649fdf5b3  pop rcx
0000707649fdf5b4  pop rax
0000707649fdf5b5  add rsp, 0x08
0000707649fdf5b9  jmp 0x0000707649FDC3D8
0000707649fdf5be  sub rsp, 0x08
0000707649fdf5c2  push rax
0000707649fdf5c3  push rcx
0000707649fdf5c4  push rdx
0000707649fdf5c5  push rdi
0000707649fdf5c6  push rsi
0000707649fdf5c7  push r8
0000707649fdf5c9  push r9
0000707649fdf5cb  push r10
0000707649fdf5cd  push r11
0000707649fdf5cf  sub rsp, 0xF0
0000707649fdf5d6  vmovaps [rsp], xmm0
0000707649fdf5db  vmovaps [rsp+0x10], xmm1
0000707649fdf5e1  vmovaps [rsp+0x20], xmm2
0000707649fdf5e7  vmovaps [rsp+0x30], xmm3
0000707649fdf5ed  vmovaps [rsp+0x40], xmm4
0000707649fdf5f3  vmovaps [rsp+0x50], xmm5
0000707649fdf5f9  vmovaps [rsp+0x60], xmm6
0000707649fdf5ff  vmovaps [rsp+0x70], xmm7
0000707649fdf605  vmovaps [rsp+0x80], xmm8
0000707649fdf60e  vmovaps [rsp+0x90], xmm9
0000707649fdf617  vmovaps [rsp+0xA0], xmm11
0000707649fdf620  vmovaps [rsp+0xB0], xmm12
0000707649fdf629  vmovaps [rsp+0xC0], xmm13
0000707649fdf632  vmovaps [rsp+0xD0], xmm14
0000707649fdf63b  vmovaps [rsp+0xE0], xmm15
0000707649fdf644  sub rsp, 0x30
0000707649fdf648  movaps [rsp], xmm10
0000707649fdf64d  movaps [rsp+0x10], xmm8
0000707649fdf653  movaps [rsp+0x20], xmm14
0000707649fdf659  lea rdi, [rsp]
0000707649fdf65d  mov esi, 0x00
0000707649fdf662  mov rax, 0x59CB0B054530
0000707649fdf66c  call rax
0000707649fdf66e  movaps xmm10, [rsp]
0000707649fdf673  add rsp, 0x30
0000707649fdf677  vmovaps xmm0, [rsp]
0000707649fdf67c  vmovaps xmm1, [rsp+0x10]
0000707649fdf682  vmovaps xmm2, [rsp+0x20]
0000707649fdf688  vmovaps xmm3, [rsp+0x30]
0000707649fdf68e  vmovaps xmm4, [rsp+0x40]
0000707649fdf694  vmovaps xmm5, [rsp+0x50]
0000707649fdf69a  vmovaps xmm6, [rsp+0x60]
0000707649fdf6a0  vmovaps xmm7, [rsp+0x70]
0000707649fdf6a6  vmovaps xmm8, [rsp+0x80]
0000707649fdf6af  vmovaps xmm9, [rsp+0x90]
0000707649fdf6b8  vmovaps xmm11, [rsp+0xA0]
0000707649fdf6c1  vmovaps xmm12, [rsp+0xB0]
0000707649fdf6ca  vmovaps xmm13, [rsp+0xC0]
0000707649fdf6d3  vmovaps xmm14, [rsp+0xD0]
0000707649fdf6dc  vmovaps xmm15, [rsp+0xE0]
0000707649fdf6e5  add rsp, 0xF0
0000707649fdf6ec  pop r11
0000707649fdf6ee  pop r10
0000707649fdf6f0  pop r9
0000707649fdf6f2  pop r8
0000707649fdf6f4  pop rsi
0000707649fdf6f5  pop rdi
0000707649fdf6f6  pop rdx
0000707649fdf6f7  pop rcx
0000707649fdf6f8  pop rax
0000707649fdf6f9  add rsp, 0x08
0000707649fdf6fd  jmp 0x0000707649FDC3F8
0000707649fdf702  sub rsp, 0x08
0000707649fdf706  push rax
0000707649fdf707  push rcx
0000707649fdf708  push rdx
0000707649fdf709  push rdi
0000707649fdf70a  push rsi
0000707649fdf70b  push r8
0000707649fdf70d  push r9
0000707649fdf70f  push r10
0000707649fdf711  push r11
0000707649fdf713  sub rsp, 0xF0
0000707649fdf71a  vmovaps [rsp], xmm0
0000707649fdf71f  vmovaps [rsp+0x10], xmm1
0000707649fdf725  vmovaps [rsp+0x20], xmm2
0000707649fdf72b  vmovaps [rsp+0x30], xmm3
0000707649fdf731  vmovaps [rsp+0x40], xmm4
0000707649fdf737  vmovaps [rsp+0x50], xmm5
0000707649fdf73d  vmovaps [rsp+0x60], xmm6
0000707649fdf743  vmovaps [rsp+0x70], xmm7
0000707649fdf749  vmovaps [rsp+0x80], xmm8
0000707649fdf752  vmovaps [rsp+0x90], xmm9
0000707649fdf75b  vmovaps [rsp+0xA0], xmm10
0000707649fdf764  vmovaps [rsp+0xB0], xmm11
0000707649fdf76d  vmovaps [rsp+0xC0], xmm12
0000707649fdf776  vmovaps [rsp+0xD0], xmm13
0000707649fdf77f  vmovaps [rsp+0xE0], xmm15
0000707649fdf788  sub rsp, 0x30
0000707649fdf78c  movaps [rsp], xmm14
0000707649fdf791  movaps [rsp+0x10], xmm8
0000707649fdf797  movaps [rsp+0x20], xmm4
0000707649fdf79c  lea rdi, [rsp]
0000707649fdf7a0  mov esi, 0x00
0000707649fdf7a5  mov rax, 0x59CB0B054530
0000707649fdf7af  call rax
0000707649fdf7b1  movaps xmm14, [rsp]
0000707649fdf7b6  add rsp, 0x30
0000707649fdf7ba  vmovaps xmm0, [rsp]
0000707649fdf7bf  vmovaps xmm1, [rsp+0x10]
0000707649fdf7c5  vmovaps xmm2, [rsp+0x20]
0000707649fdf7cb  vmovaps xmm3, [rsp+0x30]
0000707649fdf7d1  vmovaps xmm4, [rsp+0x40]
0000707649fdf7d7  vmovaps xmm5, [rsp+0x50]
0000707649fdf7dd  vmovaps xmm6, [rsp+0x60]
0000707649fdf7e3  vmovaps xmm7, [rsp+0x70]
0000707649fdf7e9  vmovaps xmm8, [rsp+0x80]
0000707649fdf7f2  vmovaps xmm9, [rsp+0x90]
0000707649fdf7fb  vmovaps xmm10, [rsp+0xA0]
0000707649fdf804  vmovaps xmm11, [rsp+0xB0]
0000707649fdf80d  vmovaps xmm12, [rsp+0xC0]
0000707649fdf816  vmovaps xmm13, [rsp+0xD0]
0000707649fdf81f  vmovaps xmm15, [rsp+0xE0]
0000707649fdf828  add rsp, 0xF0
0000707649fdf82f  pop r11
0000707649fdf831  pop r10
0000707649fdf833  pop r9
0000707649fdf835  pop r8
0000707649fdf837  pop rsi
0000707649fdf838  pop rdi
0000707649fdf839  pop rdx
0000707649fdf83a  pop rcx
0000707649fdf83b  pop rax
0000707649fdf83c  add rsp, 0x08
0000707649fdf840  jmp 0x0000707649FDC418
0000707649fdf845  sub rsp, 0x08
0000707649fdf849  push rax
0000707649fdf84a  push rcx
0000707649fdf84b  push rdx
0000707649fdf84c  push rdi
0000707649fdf84d  push rsi
0000707649fdf84e  push r8
0000707649fdf850  push r9
0000707649fdf852  push r10
0000707649fdf854  push r11
0000707649fdf856  sub rsp, 0xF0
0000707649fdf85d  vmovaps [rsp], xmm0
0000707649fdf862  vmovaps [rsp+0x10], xmm1
0000707649fdf868  vmovaps [rsp+0x20], xmm2
0000707649fdf86e  vmovaps [rsp+0x30], xmm3
0000707649fdf874  vmovaps [rsp+0x40], xmm5
0000707649fdf87a  vmovaps [rsp+0x50], xmm6
0000707649fdf880  vmovaps [rsp+0x60], xmm7
0000707649fdf886  vmovaps [rsp+0x70], xmm8
0000707649fdf88c  vmovaps [rsp+0x80], xmm9
0000707649fdf895  vmovaps [rsp+0x90], xmm10
0000707649fdf89e  vmovaps [rsp+0xA0], xmm11
0000707649fdf8a7  vmovaps [rsp+0xB0], xmm12
0000707649fdf8b0  vmovaps [rsp+0xC0], xmm13
0000707649fdf8b9  vmovaps [rsp+0xD0], xmm14
0000707649fdf8c2  vmovaps [rsp+0xE0], xmm15
0000707649fdf8cb  sub rsp, 0x30
0000707649fdf8cf  movaps [rsp], xmm4
0000707649fdf8d3  movaps [rsp+0x10], xmm13
0000707649fdf8d9  movaps [rsp+0x20], xmm8
0000707649fdf8df  lea rdi, [rsp]
0000707649fdf8e3  mov esi, 0x00
0000707649fdf8e8  mov rax, 0x59CB0B054530
0000707649fdf8f2  call rax
0000707649fdf8f4  movaps xmm4, [rsp]
0000707649fdf8f8  add rsp, 0x30
0000707649fdf8fc  vmovaps xmm0, [rsp]
0000707649fdf901  vmovaps xmm1, [rsp+0x10]
0000707649fdf907  vmovaps xmm2, [rsp+0x20]
0000707649fdf90d  vmovaps xmm3, [rsp+0x30]
0000707649fdf913  vmovaps xmm5, [rsp+0x40]
0000707649fdf919  vmovaps xmm6, [rsp+0x50]
0000707649fdf91f  vmovaps xmm7, [rsp+0x60]
0000707649fdf925  vmovaps xmm8, [rsp+0x70]
0000707649fdf92b  vmovaps xmm9, [rsp+0x80]
0000707649fdf934  vmovaps xmm10, [rsp+0x90]
0000707649fdf93d  vmovaps xmm11, [rsp+0xA0]
0000707649fdf946  vmovaps xmm12, [rsp+0xB0]
0000707649fdf94f  vmovaps xmm13, [rsp+0xC0]
0000707649fdf958  vmovaps xmm14, [rsp+0xD0]
0000707649fdf961  vmovaps xmm15, [rsp+0xE0]
0000707649fdf96a  add rsp, 0xF0
0000707649fdf971  pop r11
0000707649fdf973  pop r10
0000707649fdf975  pop r9
0000707649fdf977  pop r8
0000707649fdf979  pop rsi
0000707649fdf97a  pop rdi
0000707649fdf97b  pop rdx
0000707649fdf97c  pop rcx
0000707649fdf97d  pop rax
0000707649fdf97e  add rsp, 0x08
0000707649fdf982  jmp 0x0000707649FDC43D
0000707649fdf987  sub rsp, 0x08
0000707649fdf98b  push rax
0000707649fdf98c  push rcx
0000707649fdf98d  push rdx
0000707649fdf98e  push rdi
0000707649fdf98f  push rsi
0000707649fdf990  push r8
0000707649fdf992  push r9
0000707649fdf994  push r10
0000707649fdf996  push r11
0000707649fdf998  sub rsp, 0xF0
0000707649fdf99f  vmovaps [rsp], xmm0
0000707649fdf9a4  vmovaps [rsp+0x10], xmm1
0000707649fdf9aa  vmovaps [rsp+0x20], xmm2
0000707649fdf9b0  vmovaps [rsp+0x30], xmm3
0000707649fdf9b6  vmovaps [rsp+0x40], xmm4
0000707649fdf9bc  vmovaps [rsp+0x50], xmm5
0000707649fdf9c2  vmovaps [rsp+0x60], xmm6
0000707649fdf9c8  vmovaps [rsp+0x70], xmm7
0000707649fdf9ce  vmovaps [rsp+0x80], xmm8
0000707649fdf9d7  vmovaps [rsp+0x90], xmm9
0000707649fdf9e0  vmovaps [rsp+0xA0], xmm10
0000707649fdf9e9  vmovaps [rsp+0xB0], xmm11
0000707649fdf9f2  vmovaps [rsp+0xC0], xmm12
0000707649fdf9fb  vmovaps [rsp+0xD0], xmm14
0000707649fdfa04  vmovaps [rsp+0xE0], xmm15
0000707649fdfa0d  sub rsp, 0x30
0000707649fdfa11  movaps [rsp], xmm13
0000707649fdfa16  movaps [rsp+0x10], xmm15
0000707649fdfa1c  movaps [rsp+0x20], xmm9
0000707649fdfa22  lea rdi, [rsp]
0000707649fdfa26  mov esi, 0x00
0000707649fdfa2b  mov rax, 0x59CB0B054530
0000707649fdfa35  call rax
0000707649fdfa37  movaps xmm13, [rsp]
0000707649fdfa3c  add rsp, 0x30
0000707649fdfa40  vmovaps xmm0, [rsp]
0000707649fdfa45  vmovaps xmm1, [rsp+0x10]
0000707649fdfa4b  vmovaps xmm2, [rsp+0x20]
0000707649fdfa51  vmovaps xmm3, [rsp+0x30]
0000707649fdfa57  vmovaps xmm4, [rsp+0x40]
0000707649fdfa5d  vmovaps xmm5, [rsp+0x50]
0000707649fdfa63  vmovaps xmm6, [rsp+0x60]
0000707649fdfa69  vmovaps xmm7, [rsp+0x70]
0000707649fdfa6f  vmovaps xmm8, [rsp+0x80]
0000707649fdfa78  vmovaps xmm9, [rsp+0x90]
0000707649fdfa81  vmovaps xmm10, [rsp+0xA0]
0000707649fdfa8a  vmovaps xmm11, [rsp+0xB0]
0000707649fdfa93  vmovaps xmm12, [rsp+0xC0]
0000707649fdfa9c  vmovaps xmm14, [rsp+0xD0]
0000707649fdfaa5  vmovaps xmm15, [rsp+0xE0]
0000707649fdfaae  add rsp, 0xF0
0000707649fdfab5  pop r11
0000707649fdfab7  pop r10
0000707649fdfab9  pop r9
0000707649fdfabb  pop r8
0000707649fdfabd  pop rsi
0000707649fdfabe  pop rdi
0000707649fdfabf  pop rdx
0000707649fdfac0  pop rcx
0000707649fdfac1  pop rax
0000707649fdfac2  add rsp, 0x08
0000707649fdfac6  jmp 0x0000707649FDC458
0000707649fdfacb  sub rsp, 0x08
0000707649fdfacf  push rax
0000707649fdfad0  push rcx
0000707649fdfad1  push rdx
0000707649fdfad2  push rdi
0000707649fdfad3  push rsi
0000707649fdfad4  push r8
0000707649fdfad6  push r9
0000707649fdfad8  push r10
0000707649fdfada  push r11
0000707649fdfadc  sub rsp, 0xF0
0000707649fdfae3  vmovaps [rsp], xmm0
0000707649fdfae8  vmovaps [rsp+0x10], xmm1
0000707649fdfaee  vmovaps [rsp+0x20], xmm2
0000707649fdfaf4  vmovaps [rsp+0x30], xmm3
0000707649fdfafa  vmovaps [rsp+0x40], xmm4
0000707649fdfb00  vmovaps [rsp+0x50], xmm5
0000707649fdfb06  vmovaps [rsp+0x60], xmm6
0000707649fdfb0c  vmovaps [rsp+0x70], xmm7
0000707649fdfb12  vmovaps [rsp+0x80], xmm8
0000707649fdfb1b  vmovaps [rsp+0x90], xmm9
0000707649fdfb24  vmovaps [rsp+0xA0], xmm10
0000707649fdfb2d  vmovaps [rsp+0xB0], xmm11
0000707649fdfb36  vmovaps [rsp+0xC0], xmm12
0000707649fdfb3f  vmovaps [rsp+0xD0], xmm13
0000707649fdfb48  vmovaps [rsp+0xE0], xmm14
0000707649fdfb51  sub rsp, 0x30
0000707649fdfb55  movaps [rsp], xmm15
0000707649fdfb5a  movaps [rsp+0x10], xmm1
0000707649fdfb5f  movaps [rsp+0x20], xmm5
0000707649fdfb64  lea rdi, [rsp]
0000707649fdfb68  mov esi, 0x00
0000707649fdfb6d  mov rax, 0x59CB0B054530
0000707649fdfb77  call rax
0000707649fdfb79  movaps xmm15, [rsp]
0000707649fdfb7e  add rsp, 0x30
0000707649fdfb82  vmovaps xmm0, [rsp]
0000707649fdfb87  vmovaps xmm1, [rsp+0x10]
0000707649fdfb8d  vmovaps xmm2, [rsp+0x20]
0000707649fdfb93  vmovaps xmm3, [rsp+0x30]
0000707649fdfb99  vmovaps xmm4, [rsp+0x40]
0000707649fdfb9f  vmovaps xmm5, [rsp+0x50]
0000707649fdfba5  vmovaps xmm6, [rsp+0x60]
0000707649fdfbab  vmovaps xmm7, [rsp+0x70]
0000707649fdfbb1  vmovaps xmm8, [rsp+0x80]
0000707649fdfbba  vmovaps xmm9, [rsp+0x90]
0000707649fdfbc3  vmovaps xmm10, [rsp+0xA0]
0000707649fdfbcc  vmovaps xmm11, [rsp+0xB0]
0000707649fdfbd5  vmovaps xmm12, [rsp+0xC0]
0000707649fdfbde  vmovaps xmm13, [rsp+0xD0]
0000707649fdfbe7  vmovaps xmm14, [rsp+0xE0]
0000707649fdfbf0  add rsp, 0xF0
0000707649fdfbf7  pop r11
0000707649fdfbf9  pop r10
0000707649fdfbfb  pop r9
0000707649fdfbfd  pop r8
0000707649fdfbff  pop rsi
0000707649fdfc00  pop rdi
0000707649fdfc01  pop rdx
0000707649fdfc02  pop rcx
0000707649fdfc03  pop rax
0000707649fdfc04  add rsp, 0x08
0000707649fdfc08  jmp 0x0000707649FDC473
0000707649fdfc0d  call 0x0000707649EB52F0
0000707649fdfc12  jmp 0x0000707649FDC4CE
0000707649fdfc17  sub rsp, 0x08
0000707649fdfc1b  push rax
0000707649fdfc1c  push rcx
0000707649fdfc1d  push rdx
0000707649fdfc1e  push rdi
0000707649fdfc1f  push rsi
0000707649fdfc20  push r8
0000707649fdfc22  push r9
0000707649fdfc24  push r10
0000707649fdfc26  push r11
0000707649fdfc28  sub rsp, 0xF0
0000707649fdfc2f  vmovaps [rsp], xmm0
0000707649fdfc34  vmovaps [rsp+0x10], xmm1
0000707649fdfc3a  vmovaps [rsp+0x20], xmm2
0000707649fdfc40  vmovaps [rsp+0x30], xmm3
0000707649fdfc46  vmovaps [rsp+0x40], xmm4
0000707649fdfc4c  vmovaps [rsp+0x50], xmm5
0000707649fdfc52  vmovaps [rsp+0x60], xmm6
0000707649fdfc58  vmovaps [rsp+0x70], xmm7
0000707649fdfc5e  vmovaps [rsp+0x80], xmm8
0000707649fdfc67  vmovaps [rsp+0x90], xmm10
0000707649fdfc70  vmovaps [rsp+0xA0], xmm11
0000707649fdfc79  vmovaps [rsp+0xB0], xmm12
0000707649fdfc82  vmovaps [rsp+0xC0], xmm13
0000707649fdfc8b  vmovaps [rsp+0xD0], xmm14
0000707649fdfc94  vmovaps [rsp+0xE0], xmm15
0000707649fdfc9d  sub rsp, 0x30
0000707649fdfca1  movaps [rsp], xmm9
0000707649fdfca6  movaps [rsp+0x10], xmm8
0000707649fdfcac  movaps [rsp+0x20], xmm11
0000707649fdfcb2  lea rdi, [rsp]
0000707649fdfcb6  mov esi, 0x00
0000707649fdfcbb  mov rax, 0x59CB0B054530
0000707649fdfcc5  call rax
0000707649fdfcc7  movaps xmm9, [rsp]
0000707649fdfccc  add rsp, 0x30
0000707649fdfcd0  vmovaps xmm0, [rsp]
0000707649fdfcd5  vmovaps xmm1, [rsp+0x10]
0000707649fdfcdb  vmovaps xmm2, [rsp+0x20]
0000707649fdfce1  vmovaps xmm3, [rsp+0x30]
0000707649fdfce7  vmovaps xmm4, [rsp+0x40]
0000707649fdfced  vmovaps xmm5, [rsp+0x50]
0000707649fdfcf3  vmovaps xmm6, [rsp+0x60]
0000707649fdfcf9  vmovaps xmm7, [rsp+0x70]
0000707649fdfcff  vmovaps xmm8, [rsp+0x80]
0000707649fdfd08  vmovaps xmm10, [rsp+0x90]
0000707649fdfd11  vmovaps xmm11, [rsp+0xA0]
0000707649fdfd1a  vmovaps xmm12, [rsp+0xB0]
0000707649fdfd23  vmovaps xmm13, [rsp+0xC0]
0000707649fdfd2c  vmovaps xmm14, [rsp+0xD0]
0000707649fdfd35  vmovaps xmm15, [rsp+0xE0]
0000707649fdfd3e  add rsp, 0xF0
0000707649fdfd45  pop r11
0000707649fdfd47  pop r10
0000707649fdfd49  pop r9
0000707649fdfd4b  pop r8
0000707649fdfd4d  pop rsi
0000707649fdfd4e  pop rdi
0000707649fdfd4f  pop rdx
0000707649fdfd50  pop rcx
0000707649fdfd51  pop rax
0000707649fdfd52  add rsp, 0x08
0000707649fdfd56  jmp 0x0000707649FDC505
0000707649fdfd5b  sub rsp, 0x08
0000707649fdfd5f  push rax
0000707649fdfd60  push rcx
0000707649fdfd61  push rdx
0000707649fdfd62  push rdi
0000707649fdfd63  push rsi
0000707649fdfd64  push r8
0000707649fdfd66  push r9
0000707649fdfd68  push r10
0000707649fdfd6a  push r11
0000707649fdfd6c  sub rsp, 0xF0
0000707649fdfd73  vmovaps [rsp], xmm0
0000707649fdfd78  vmovaps [rsp+0x10], xmm1
0000707649fdfd7e  vmovaps [rsp+0x20], xmm2
0000707649fdfd84  vmovaps [rsp+0x30], xmm3
0000707649fdfd8a  vmovaps [rsp+0x40], xmm4
0000707649fdfd90  vmovaps [rsp+0x50], xmm5
0000707649fdfd96  vmovaps [rsp+0x60], xmm6
0000707649fdfd9c  vmovaps [rsp+0x70], xmm7
0000707649fdfda2  vmovaps [rsp+0x80], xmm8
0000707649fdfdab  vmovaps [rsp+0x90], xmm9
0000707649fdfdb4  vmovaps [rsp+0xA0], xmm10
0000707649fdfdbd  vmovaps [rsp+0xB0], xmm12
0000707649fdfdc6  vmovaps [rsp+0xC0], xmm13
0000707649fdfdcf  vmovaps [rsp+0xD0], xmm14
0000707649fdfdd8  vmovaps [rsp+0xE0], xmm15
0000707649fdfde1  sub rsp, 0x30
0000707649fdfde5  movaps [rsp], xmm11
0000707649fdfdea  movaps [rsp+0x10], xmm10
0000707649fdfdf0  movaps [rsp+0x20], xmm6
0000707649fdfdf5  lea rdi, [rsp]
0000707649fdfdf9  mov esi, 0x00
0000707649fdfdfe  mov rax, 0x59CB0B054530
0000707649fdfe08  call rax
0000707649fdfe0a  movaps xmm11, [rsp]
0000707649fdfe0f  add rsp, 0x30
0000707649fdfe13  vmovaps xmm0, [rsp]
0000707649fdfe18  vmovaps xmm1, [rsp+0x10]
0000707649fdfe1e  vmovaps xmm2, [rsp+0x20]
0000707649fdfe24  vmovaps xmm3, [rsp+0x30]
0000707649fdfe2a  vmovaps xmm4, [rsp+0x40]
0000707649fdfe30  vmovaps xmm5, [rsp+0x50]
0000707649fdfe36  vmovaps xmm6, [rsp+0x60]
0000707649fdfe3c  vmovaps xmm7, [rsp+0x70]
0000707649fdfe42  vmovaps xmm8, [rsp+0x80]
0000707649fdfe4b  vmovaps xmm9, [rsp+0x90]
0000707649fdfe54  vmovaps xmm10, [rsp+0xA0]
0000707649fdfe5d  vmovaps xmm12, [rsp+0xB0]
0000707649fdfe66  vmovaps xmm13, [rsp+0xC0]
0000707649fdfe6f  vmovaps xmm14, [rsp+0xD0]
0000707649fdfe78  vmovaps xmm15, [rsp+0xE0]
0000707649fdfe81  add rsp, 0xF0
0000707649fdfe88  pop r11
0000707649fdfe8a  pop r10
0000707649fdfe8c  pop r9
0000707649fdfe8e  pop r8
0000707649fdfe90  pop rsi
0000707649fdfe91  pop rdi
0000707649fdfe92  pop rdx
0000707649fdfe93  pop rcx
0000707649fdfe94  pop rax
0000707649fdfe95  add rsp, 0x08
0000707649fdfe99  jmp 0x0000707649FDC520
0000707649fdfe9e  sub rsp, 0x08
0000707649fdfea2  push rax
0000707649fdfea3  push rcx
0000707649fdfea4  push rdx
0000707649fdfea5  push rdi
0000707649fdfea6  push rsi
0000707649fdfea7  push r8
0000707649fdfea9  push r9
0000707649fdfeab  push r10
0000707649fdfead  push r11
0000707649fdfeaf  sub rsp, 0xF0
0000707649fdfeb6  vmovaps [rsp], xmm0
0000707649fdfebb  vmovaps [rsp+0x10], xmm1
0000707649fdfec1  vmovaps [rsp+0x20], xmm2
0000707649fdfec7  vmovaps [rsp+0x30], xmm3
0000707649fdfecd  vmovaps [rsp+0x40], xmm4
0000707649fdfed3  vmovaps [rsp+0x50], xmm5
0000707649fdfed9  vmovaps [rsp+0x60], xmm6
0000707649fdfedf  vmovaps [rsp+0x70], xmm7
0000707649fdfee5  vmovaps [rsp+0x80], xmm8
0000707649fdfeee  vmovaps [rsp+0x90], xmm9
0000707649fdfef7  vmovaps [rsp+0xA0], xmm11
0000707649fdff00  vmovaps [rsp+0xB0], xmm12
0000707649fdff09  vmovaps [rsp+0xC0], xmm13
0000707649fdff12  vmovaps [rsp+0xD0], xmm14
0000707649fdff1b  vmovaps [rsp+0xE0], xmm15
0000707649fdff24  sub rsp, 0x30
0000707649fdff28  movaps [rsp], xmm10
0000707649fdff2d  movaps [rsp+0x10], xmm14
0000707649fdff33  movaps [rsp+0x20], xmm4
0000707649fdff38  lea rdi, [rsp]
0000707649fdff3c  mov esi, 0x00
0000707649fdff41  mov rax, 0x59CB0B054530
0000707649fdff4b  call rax
0000707649fdff4d  movaps xmm10, [rsp]
0000707649fdff52  add rsp, 0x30
0000707649fdff56  vmovaps xmm0, [rsp]
0000707649fdff5b  vmovaps xmm1, [rsp+0x10]
0000707649fdff61  vmovaps xmm2, [rsp+0x20]
0000707649fdff67  vmovaps xmm3, [rsp+0x30]
0000707649fdff6d  vmovaps xmm4, [rsp+0x40]
0000707649fdff73  vmovaps xmm5, [rsp+0x50]
0000707649fdff79  vmovaps xmm6, [rsp+0x60]
0000707649fdff7f  vmovaps xmm7, [rsp+0x70]
0000707649fdff85  vmovaps xmm8, [rsp+0x80]
0000707649fdff8e  vmovaps xmm9, [rsp+0x90]
0000707649fdff97  vmovaps xmm11, [rsp+0xA0]
0000707649fdffa0  vmovaps xmm12, [rsp+0xB0]
0000707649fdffa9  vmovaps xmm13, [rsp+0xC0]
0000707649fdffb2  vmovaps xmm14, [rsp+0xD0]
0000707649fdffbb  vmovaps xmm15, [rsp+0xE0]
0000707649fdffc4  add rsp, 0xF0
0000707649fdffcb  pop r11
0000707649fdffcd  pop r10
0000707649fdffcf  pop r9
0000707649fdffd1  pop r8
0000707649fdffd3  pop rsi
0000707649fdffd4  pop rdi
0000707649fdffd5  pop rdx
0000707649fdffd6  pop rcx
0000707649fdffd7  pop rax
0000707649fdffd8  add rsp, 0x08
0000707649fdffdc  jmp 0x0000707649FDC53B
0000707649fdffe1  sub rsp, 0x08
0000707649fdffe5  push rax
0000707649fdffe6  push rcx
0000707649fdffe7  push rdx
0000707649fdffe8  push rdi
0000707649fdffe9  push rsi
0000707649fdffea  push r8
0000707649fdffec  push r9
0000707649fdffee  push r10
0000707649fdfff0  push r11
0000707649fdfff2  sub rsp, 0xF0
0000707649fdfff9  vmovaps [rsp], xmm0
0000707649fdfffe  vmovaps [rsp+0x10], xmm1
0000707649fe0004  vmovaps [rsp+0x20], xmm2
0000707649fe000a  vmovaps [rsp+0x30], xmm3
0000707649fe0010  vmovaps [rsp+0x40], xmm4
0000707649fe0016  vmovaps [rsp+0x50], xmm5
0000707649fe001c  vmovaps [rsp+0x60], xmm6
0000707649fe0022  vmovaps [rsp+0x70], xmm7
0000707649fe0028  vmovaps [rsp+0x80], xmm9
0000707649fe0031  vmovaps [rsp+0x90], xmm10
0000707649fe003a  vmovaps [rsp+0xA0], xmm11
0000707649fe0043  vmovaps [rsp+0xB0], xmm12
0000707649fe004c  vmovaps [rsp+0xC0], xmm13
0000707649fe0055  vmovaps [rsp+0xD0], xmm14
0000707649fe005e  vmovaps [rsp+0xE0], xmm15
0000707649fe0067  sub rsp, 0x30
0000707649fe006b  movaps [rsp], xmm8
0000707649fe0070  movaps [rsp+0x10], xmm1
0000707649fe0075  movaps [rsp+0x20], xmm14
0000707649fe007b  lea rdi, [rsp]
0000707649fe007f  mov esi, 0x00
0000707649fe0084  mov rax, 0x59CB0B054530
0000707649fe008e  call rax
0000707649fe0090  movaps xmm8, [rsp]
0000707649fe0095  add rsp, 0x30
0000707649fe0099  vmovaps xmm0, [rsp]
0000707649fe009e  vmovaps xmm1, [rsp+0x10]
0000707649fe00a4  vmovaps xmm2, [rsp+0x20]
0000707649fe00aa  vmovaps xmm3, [rsp+0x30]
0000707649fe00b0  vmovaps xmm4, [rsp+0x40]
0000707649fe00b6  vmovaps xmm5, [rsp+0x50]
0000707649fe00bc  vmovaps xmm6, [rsp+0x60]
0000707649fe00c2  vmovaps xmm7, [rsp+0x70]
0000707649fe00c8  vmovaps xmm9, [rsp+0x80]
0000707649fe00d1  vmovaps xmm10, [rsp+0x90]
0000707649fe00da  vmovaps xmm11, [rsp+0xA0]
0000707649fe00e3  vmovaps xmm12, [rsp+0xB0]
0000707649fe00ec  vmovaps xmm13, [rsp+0xC0]
0000707649fe00f5  vmovaps xmm14, [rsp+0xD0]
0000707649fe00fe  vmovaps xmm15, [rsp+0xE0]
0000707649fe0107  add rsp, 0xF0
0000707649fe010e  pop r11
0000707649fe0110  pop r10
0000707649fe0112  pop r9
0000707649fe0114  pop r8
0000707649fe0116  pop rsi
0000707649fe0117  pop rdi
0000707649fe0118  pop rdx
0000707649fe0119  pop rcx
0000707649fe011a  pop rax
0000707649fe011b  add rsp, 0x08
0000707649fe011f  jmp 0x0000707649FDC561
0000707649fe0124  sub rsp, 0x08
0000707649fe0128  push rax
0000707649fe0129  push rcx
0000707649fe012a  push rdx
0000707649fe012b  push rdi
0000707649fe012c  push rsi
0000707649fe012d  push r8
0000707649fe012f  push r9
0000707649fe0131  push r10
0000707649fe0133  push r11
0000707649fe0135  sub rsp, 0xF0
0000707649fe013c  vmovaps [rsp], xmm0
0000707649fe0141  vmovaps [rsp+0x10], xmm1
0000707649fe0147  vmovaps [rsp+0x20], xmm2
0000707649fe014d  vmovaps [rsp+0x30], xmm3
0000707649fe0153  vmovaps [rsp+0x40], xmm4
0000707649fe0159  vmovaps [rsp+0x50], xmm5
0000707649fe015f  vmovaps [rsp+0x60], xmm7
0000707649fe0165  vmovaps [rsp+0x70], xmm8
0000707649fe016b  vmovaps [rsp+0x80], xmm9
0000707649fe0174  vmovaps [rsp+0x90], xmm10
0000707649fe017d  vmovaps [rsp+0xA0], xmm11
0000707649fe0186  vmovaps [rsp+0xB0], xmm12
0000707649fe018f  vmovaps [rsp+0xC0], xmm13
0000707649fe0198  vmovaps [rsp+0xD0], xmm14
0000707649fe01a1  vmovaps [rsp+0xE0], xmm15
0000707649fe01aa  sub rsp, 0x30
0000707649fe01ae  movaps [rsp], xmm6
0000707649fe01b2  movaps [rsp+0x10], xmm1
0000707649fe01b7  movaps [rsp+0x20], xmm14
0000707649fe01bd  lea rdi, [rsp]
0000707649fe01c1  mov esi, 0x00
0000707649fe01c6  mov rax, 0x59CB0B054530
0000707649fe01d0  call rax
0000707649fe01d2  movaps xmm6, [rsp]
0000707649fe01d6  add rsp, 0x30
0000707649fe01da  vmovaps xmm0, [rsp]
0000707649fe01df  vmovaps xmm1, [rsp+0x10]
0000707649fe01e5  vmovaps xmm2, [rsp+0x20]
0000707649fe01eb  vmovaps xmm3, [rsp+0x30]
0000707649fe01f1  vmovaps xmm4, [rsp+0x40]
0000707649fe01f7  vmovaps xmm5, [rsp+0x50]
0000707649fe01fd  vmovaps xmm7, [rsp+0x60]
0000707649fe0203  vmovaps xmm8, [rsp+0x70]
0000707649fe0209  vmovaps xmm9, [rsp+0x80]
0000707649fe0212  vmovaps xmm10, [rsp+0x90]
0000707649fe021b  vmovaps xmm11, [rsp+0xA0]
0000707649fe0224  vmovaps xmm12, [rsp+0xB0]
0000707649fe022d  vmovaps xmm13, [rsp+0xC0]
0000707649fe0236  vmovaps xmm14, [rsp+0xD0]
0000707649fe023f  vmovaps xmm15, [rsp+0xE0]
0000707649fe0248  add rsp, 0xF0
0000707649fe024f  pop r11
0000707649fe0251  pop r10
0000707649fe0253  pop r9
0000707649fe0255  pop r8
0000707649fe0257  pop rsi
0000707649fe0258  pop rdi
0000707649fe0259  pop rdx
0000707649fe025a  pop rcx
0000707649fe025b  pop rax
0000707649fe025c  add rsp, 0x08
0000707649fe0260  jmp 0x0000707649FDC58D
0000707649fe0265  sub rsp, 0x08
0000707649fe0269  push rax
0000707649fe026a  push rcx
0000707649fe026b  push rdx
0000707649fe026c  push rdi
0000707649fe026d  push rsi
0000707649fe026e  push r8
0000707649fe0270  push r9
0000707649fe0272  push r10
0000707649fe0274  push r11
0000707649fe0276  sub rsp, 0xF0
0000707649fe027d  vmovaps [rsp], xmm0
0000707649fe0282  vmovaps [rsp+0x10], xmm1
0000707649fe0288  vmovaps [rsp+0x20], xmm2
0000707649fe028e  vmovaps [rsp+0x30], xmm3
0000707649fe0294  vmovaps [rsp+0x40], xmm4
0000707649fe029a  vmovaps [rsp+0x50], xmm5
0000707649fe02a0  vmovaps [rsp+0x60], xmm6
0000707649fe02a6  vmovaps [rsp+0x70], xmm7
0000707649fe02ac  vmovaps [rsp+0x80], xmm8
0000707649fe02b5  vmovaps [rsp+0x90], xmm9
0000707649fe02be  vmovaps [rsp+0xA0], xmm10
0000707649fe02c7  vmovaps [rsp+0xB0], xmm11
0000707649fe02d0  vmovaps [rsp+0xC0], xmm12
0000707649fe02d9  vmovaps [rsp+0xD0], xmm13
0000707649fe02e2  vmovaps [rsp+0xE0], xmm15
0000707649fe02eb  sub rsp, 0x30
0000707649fe02ef  movaps [rsp], xmm14
0000707649fe02f4  movaps [rsp+0x10], xmm12
0000707649fe02fa  movaps [rsp+0x20], xmm1
0000707649fe02ff  lea rdi, [rsp]
0000707649fe0303  mov esi, 0x00
0000707649fe0308  mov rax, 0x59CB0B054530
0000707649fe0312  call rax
0000707649fe0314  movaps xmm14, [rsp]
0000707649fe0319  add rsp, 0x30
0000707649fe031d  vmovaps xmm0, [rsp]
0000707649fe0322  vmovaps xmm1, [rsp+0x10]
0000707649fe0328  vmovaps xmm2, [rsp+0x20]
0000707649fe032e  vmovaps xmm3, [rsp+0x30]
0000707649fe0334  vmovaps xmm4, [rsp+0x40]
0000707649fe033a  vmovaps xmm5, [rsp+0x50]
0000707649fe0340  vmovaps xmm6, [rsp+0x60]
0000707649fe0346  vmovaps xmm7, [rsp+0x70]
0000707649fe034c  vmovaps xmm8, [rsp+0x80]
0000707649fe0355  vmovaps xmm9, [rsp+0x90]
0000707649fe035e  vmovaps xmm10, [rsp+0xA0]
0000707649fe0367  vmovaps xmm11, [rsp+0xB0]
0000707649fe0370  vmovaps xmm12, [rsp+0xC0]
0000707649fe0379  vmovaps xmm13, [rsp+0xD0]
0000707649fe0382  vmovaps xmm15, [rsp+0xE0]
0000707649fe038b  add rsp, 0xF0
0000707649fe0392  pop r11
0000707649fe0394  pop r10
0000707649fe0396  pop r9
0000707649fe0398  pop r8
0000707649fe039a  pop rsi
0000707649fe039b  pop rdi
0000707649fe039c  pop rdx
0000707649fe039d  pop rcx
0000707649fe039e  pop rax
0000707649fe039f  add rsp, 0x08
0000707649fe03a3  jmp 0x0000707649FDC5B3
0000707649fe03a8  sub rsp, 0x08
0000707649fe03ac  push rax
0000707649fe03ad  push rcx
0000707649fe03ae  push rdx
0000707649fe03af  push rdi
0000707649fe03b0  push rsi
0000707649fe03b1  push r8
0000707649fe03b3  push r9
0000707649fe03b5  push r10
0000707649fe03b7  push r11
0000707649fe03b9  sub rsp, 0xF0
0000707649fe03c0  vmovaps [rsp], xmm0
0000707649fe03c5  vmovaps [rsp+0x10], xmm2
0000707649fe03cb  vmovaps [rsp+0x20], xmm3
0000707649fe03d1  vmovaps [rsp+0x30], xmm4
0000707649fe03d7  vmovaps [rsp+0x40], xmm5
0000707649fe03dd  vmovaps [rsp+0x50], xmm6
0000707649fe03e3  vmovaps [rsp+0x60], xmm7
0000707649fe03e9  vmovaps [rsp+0x70], xmm8
0000707649fe03ef  vmovaps [rsp+0x80], xmm9
0000707649fe03f8  vmovaps [rsp+0x90], xmm10
0000707649fe0401  vmovaps [rsp+0xA0], xmm11
0000707649fe040a  vmovaps [rsp+0xB0], xmm12
0000707649fe0413  vmovaps [rsp+0xC0], xmm13
0000707649fe041c  vmovaps [rsp+0xD0], xmm14
0000707649fe0425  vmovaps [rsp+0xE0], xmm15
0000707649fe042e  sub rsp, 0x30
0000707649fe0432  movaps [rsp], xmm1
0000707649fe0436  movaps [rsp+0x10], xmm13
0000707649fe043c  movaps [rsp+0x20], xmm9
0000707649fe0442  lea rdi, [rsp]
0000707649fe0446  mov esi, 0x00
0000707649fe044b  mov rax, 0x59CB0B054530
0000707649fe0455  call rax
0000707649fe0457  movaps xmm1, [rsp]
0000707649fe045b  add rsp, 0x30
0000707649fe045f  vmovaps xmm0, [rsp]
0000707649fe0464  vmovaps xmm2, [rsp+0x10]
0000707649fe046a  vmovaps xmm3, [rsp+0x20]
0000707649fe0470  vmovaps xmm4, [rsp+0x30]
0000707649fe0476  vmovaps xmm5, [rsp+0x40]
0000707649fe047c  vmovaps xmm6, [rsp+0x50]
0000707649fe0482  vmovaps xmm7, [rsp+0x60]
0000707649fe0488  vmovaps xmm8, [rsp+0x70]
0000707649fe048e  vmovaps xmm9, [rsp+0x80]
0000707649fe0497  vmovaps xmm10, [rsp+0x90]
0000707649fe04a0  vmovaps xmm11, [rsp+0xA0]
0000707649fe04a9  vmovaps xmm12, [rsp+0xB0]
0000707649fe04b2  vmovaps xmm13, [rsp+0xC0]
0000707649fe04bb  vmovaps xmm14, [rsp+0xD0]
0000707649fe04c4  vmovaps xmm15, [rsp+0xE0]
0000707649fe04cd  add rsp, 0xF0
0000707649fe04d4  pop r11
0000707649fe04d6  pop r10
0000707649fe04d8  pop r9
0000707649fe04da  pop r8
0000707649fe04dc  pop rsi
0000707649fe04dd  pop rdi
0000707649fe04de  pop rdx
0000707649fe04df  pop rcx
0000707649fe04e0  pop rax
0000707649fe04e1  add rsp, 0x08
0000707649fe04e5  jmp 0x0000707649FDC5CD
0000707649fe04ea  sub rsp, 0x08
0000707649fe04ee  push rax
0000707649fe04ef  push rcx
0000707649fe04f0  push rdx
0000707649fe04f1  push rdi
0000707649fe04f2  push rsi
0000707649fe04f3  push r8
0000707649fe04f5  push r9
0000707649fe04f7  push r10
0000707649fe04f9  push r11
0000707649fe04fb  sub rsp, 0xF0
0000707649fe0502  vmovaps [rsp], xmm0
0000707649fe0507  vmovaps [rsp+0x10], xmm1
0000707649fe050d  vmovaps [rsp+0x20], xmm2
0000707649fe0513  vmovaps [rsp+0x30], xmm3
0000707649fe0519  vmovaps [rsp+0x40], xmm4
0000707649fe051f  vmovaps [rsp+0x50], xmm5
0000707649fe0525  vmovaps [rsp+0x60], xmm6
0000707649fe052b  vmovaps [rsp+0x70], xmm7
0000707649fe0531  vmovaps [rsp+0x80], xmm8
0000707649fe053a  vmovaps [rsp+0x90], xmm9
0000707649fe0543  vmovaps [rsp+0xA0], xmm10
0000707649fe054c  vmovaps [rsp+0xB0], xmm11
0000707649fe0555  vmovaps [rsp+0xC0], xmm13
0000707649fe055e  vmovaps [rsp+0xD0], xmm14
0000707649fe0567  vmovaps [rsp+0xE0], xmm15
0000707649fe0570  sub rsp, 0x30
0000707649fe0574  movaps [rsp], xmm12
0000707649fe0579  movaps [rsp+0x10], xmm7
0000707649fe057e  movaps [rsp+0x20], xmm13
0000707649fe0584  lea rdi, [rsp]
0000707649fe0588  mov esi, 0x00
0000707649fe058d  mov rax, 0x59CB0B054530
0000707649fe0597  call rax
0000707649fe0599  movaps xmm12, [rsp]
0000707649fe059e  add rsp, 0x30
0000707649fe05a2  vmovaps xmm0, [rsp]
0000707649fe05a7  vmovaps xmm1, [rsp+0x10]
0000707649fe05ad  vmovaps xmm2, [rsp+0x20]
0000707649fe05b3  vmovaps xmm3, [rsp+0x30]
0000707649fe05b9  vmovaps xmm4, [rsp+0x40]
0000707649fe05bf  vmovaps xmm5, [rsp+0x50]
0000707649fe05c5  vmovaps xmm6, [rsp+0x60]
0000707649fe05cb  vmovaps xmm7, [rsp+0x70]
0000707649fe05d1  vmovaps xmm8, [rsp+0x80]
0000707649fe05da  vmovaps xmm9, [rsp+0x90]
0000707649fe05e3  vmovaps xmm10, [rsp+0xA0]
0000707649fe05ec  vmovaps xmm11, [rsp+0xB0]
0000707649fe05f5  vmovaps xmm13, [rsp+0xC0]
0000707649fe05fe  vmovaps xmm14, [rsp+0xD0]
0000707649fe0607  vmovaps xmm15, [rsp+0xE0]
0000707649fe0610  add rsp, 0xF0
0000707649fe0617  pop r11
0000707649fe0619  pop r10
0000707649fe061b  pop r9
0000707649fe061d  pop r8
0000707649fe061f  pop rsi
0000707649fe0620  pop rdi
0000707649fe0621  pop rdx
0000707649fe0622  pop rcx
0000707649fe0623  pop rax
0000707649fe0624  add rsp, 0x08
0000707649fe0628  jmp 0x0000707649FDC5F4
0000707649fe062d  sub rsp, 0x08
0000707649fe0631  push rax
0000707649fe0632  push rcx
0000707649fe0633  push rdx
0000707649fe0634  push rdi
0000707649fe0635  push rsi
0000707649fe0636  push r8
0000707649fe0638  push r9
0000707649fe063a  push r10
0000707649fe063c  push r11
0000707649fe063e  sub rsp, 0xF0
0000707649fe0645  vmovaps [rsp], xmm0
0000707649fe064a  vmovaps [rsp+0x10], xmm1
0000707649fe0650  vmovaps [rsp+0x20], xmm2
0000707649fe0656  vmovaps [rsp+0x30], xmm3
0000707649fe065c  vmovaps [rsp+0x40], xmm4
0000707649fe0662  vmovaps [rsp+0x50], xmm5
0000707649fe0668  vmovaps [rsp+0x60], xmm6
0000707649fe066e  vmovaps [rsp+0x70], xmm7
0000707649fe0674  vmovaps [rsp+0x80], xmm8
0000707649fe067d  vmovaps [rsp+0x90], xmm9
0000707649fe0686  vmovaps [rsp+0xA0], xmm10
0000707649fe068f  vmovaps [rsp+0xB0], xmm11
0000707649fe0698  vmovaps [rsp+0xC0], xmm12
0000707649fe06a1  vmovaps [rsp+0xD0], xmm14
0000707649fe06aa  vmovaps [rsp+0xE0], xmm15
0000707649fe06b3  sub rsp, 0x30
0000707649fe06b7  movaps [rsp], xmm13
0000707649fe06bc  movaps [rsp+0x10], xmm15
0000707649fe06c2  movaps [rsp+0x20], xmm8
0000707649fe06c8  lea rdi, [rsp]
0000707649fe06cc  mov esi, 0x00
0000707649fe06d1  mov rax, 0x59CB0B054530
0000707649fe06db  call rax
0000707649fe06dd  movaps xmm13, [rsp]
0000707649fe06e2  add rsp, 0x30
0000707649fe06e6  vmovaps xmm0, [rsp]
0000707649fe06eb  vmovaps xmm1, [rsp+0x10]
0000707649fe06f1  vmovaps xmm2, [rsp+0x20]
0000707649fe06f7  vmovaps xmm3, [rsp+0x30]
0000707649fe06fd  vmovaps xmm4, [rsp+0x40]
0000707649fe0703  vmovaps xmm5, [rsp+0x50]
0000707649fe0709  vmovaps xmm6, [rsp+0x60]
0000707649fe070f  vmovaps xmm7, [rsp+0x70]
0000707649fe0715  vmovaps xmm8, [rsp+0x80]
0000707649fe071e  vmovaps xmm9, [rsp+0x90]
0000707649fe0727  vmovaps xmm10, [rsp+0xA0]
0000707649fe0730  vmovaps xmm11, [rsp+0xB0]
0000707649fe0739  vmovaps xmm12, [rsp+0xC0]
0000707649fe0742  vmovaps xmm14, [rsp+0xD0]
0000707649fe074b  vmovaps xmm15, [rsp+0xE0]
0000707649fe0754  add rsp, 0xF0
0000707649fe075b  pop r11
0000707649fe075d  pop r10
0000707649fe075f  pop r9
0000707649fe0761  pop r8
0000707649fe0763  pop rsi
0000707649fe0764  pop rdi
0000707649fe0765  pop rdx
0000707649fe0766  pop rcx
0000707649fe0767  pop rax
0000707649fe0768  add rsp, 0x08
0000707649fe076c  jmp 0x0000707649FDC60F
0000707649fe0771  sub rsp, 0x08
0000707649fe0775  push rax
0000707649fe0776  push rcx
0000707649fe0777  push rdx
0000707649fe0778  push rdi
0000707649fe0779  push rsi
0000707649fe077a  push r8
0000707649fe077c  push r9
0000707649fe077e  push r10
0000707649fe0780  push r11
0000707649fe0782  sub rsp, 0xF0
0000707649fe0789  vmovaps [rsp], xmm0
0000707649fe078e  vmovaps [rsp+0x10], xmm1
0000707649fe0794  vmovaps [rsp+0x20], xmm2
0000707649fe079a  vmovaps [rsp+0x30], xmm3
0000707649fe07a0  vmovaps [rsp+0x40], xmm4
0000707649fe07a6  vmovaps [rsp+0x50], xmm5
0000707649fe07ac  vmovaps [rsp+0x60], xmm6
0000707649fe07b2  vmovaps [rsp+0x70], xmm7
0000707649fe07b8  vmovaps [rsp+0x80], xmm9
0000707649fe07c1  vmovaps [rsp+0x90], xmm10
0000707649fe07ca  vmovaps [rsp+0xA0], xmm11
0000707649fe07d3  vmovaps [rsp+0xB0], xmm12
0000707649fe07dc  vmovaps [rsp+0xC0], xmm13
0000707649fe07e5  vmovaps [rsp+0xD0], xmm14
0000707649fe07ee  vmovaps [rsp+0xE0], xmm15
0000707649fe07f7  sub rsp, 0x30
0000707649fe07fb  movaps [rsp], xmm8
0000707649fe0800  movaps [rsp+0x10], xmm15
0000707649fe0806  movaps [rsp+0x20], xmm9
0000707649fe080c  lea rdi, [rsp]
0000707649fe0810  mov esi, 0x00
0000707649fe0815  mov rax, 0x59CB0B054530
0000707649fe081f  call rax
0000707649fe0821  movaps xmm8, [rsp]
0000707649fe0826  add rsp, 0x30
0000707649fe082a  vmovaps xmm0, [rsp]
0000707649fe082f  vmovaps xmm1, [rsp+0x10]
0000707649fe0835  vmovaps xmm2, [rsp+0x20]
0000707649fe083b  vmovaps xmm3, [rsp+0x30]
0000707649fe0841  vmovaps xmm4, [rsp+0x40]
0000707649fe0847  vmovaps xmm5, [rsp+0x50]
0000707649fe084d  vmovaps xmm6, [rsp+0x60]
0000707649fe0853  vmovaps xmm7, [rsp+0x70]
0000707649fe0859  vmovaps xmm9, [rsp+0x80]
0000707649fe0862  vmovaps xmm10, [rsp+0x90]
0000707649fe086b  vmovaps xmm11, [rsp+0xA0]
0000707649fe0874  vmovaps xmm12, [rsp+0xB0]
0000707649fe087d  vmovaps xmm13, [rsp+0xC0]
0000707649fe0886  vmovaps xmm14, [rsp+0xD0]
0000707649fe088f  vmovaps xmm15, [rsp+0xE0]
0000707649fe0898  add rsp, 0xF0
0000707649fe089f  pop r11
0000707649fe08a1  pop r10
0000707649fe08a3  pop r9
0000707649fe08a5  pop r8
0000707649fe08a7  pop rsi
0000707649fe08a8  pop rdi
0000707649fe08a9  pop rdx
0000707649fe08aa  pop rcx
0000707649fe08ab  pop rax
0000707649fe08ac  add rsp, 0x08
0000707649fe08b0  jmp 0x0000707649FDC63D
0000707649fe08b5  sub rsp, 0x08
0000707649fe08b9  push rax
0000707649fe08ba  push rcx
0000707649fe08bb  push rdx
0000707649fe08bc  push rdi
0000707649fe08bd  push rsi
0000707649fe08be  push r8
0000707649fe08c0  push r9
0000707649fe08c2  push r10
0000707649fe08c4  push r11
0000707649fe08c6  sub rsp, 0xF0
0000707649fe08cd  vmovaps [rsp], xmm0
0000707649fe08d2  vmovaps [rsp+0x10], xmm1
0000707649fe08d8  vmovaps [rsp+0x20], xmm2
0000707649fe08de  vmovaps [rsp+0x30], xmm3
0000707649fe08e4  vmovaps [rsp+0x40], xmm4
0000707649fe08ea  vmovaps [rsp+0x50], xmm5
0000707649fe08f0  vmovaps [rsp+0x60], xmm6
0000707649fe08f6  vmovaps [rsp+0x70], xmm7
0000707649fe08fc  vmovaps [rsp+0x80], xmm8
0000707649fe0905  vmovaps [rsp+0x90], xmm9
0000707649fe090e  vmovaps [rsp+0xA0], xmm10
0000707649fe0917  vmovaps [rsp+0xB0], xmm11
0000707649fe0920  vmovaps [rsp+0xC0], xmm12
0000707649fe0929  vmovaps [rsp+0xD0], xmm13
0000707649fe0932  vmovaps [rsp+0xE0], xmm14
0000707649fe093b  sub rsp, 0x30
0000707649fe093f  movaps [rsp], xmm15
0000707649fe0944  movaps [rsp+0x10], xmm11
0000707649fe094a  movaps [rsp+0x20], xmm6
0000707649fe094f  lea rdi, [rsp]
0000707649fe0953  mov esi, 0x00
0000707649fe0958  mov rax, 0x59CB0B054530
0000707649fe0962  call rax
0000707649fe0964  movaps xmm15, [rsp]
0000707649fe0969  add rsp, 0x30
0000707649fe096d  vmovaps xmm0, [rsp]
0000707649fe0972  vmovaps xmm1, [rsp+0x10]
0000707649fe0978  vmovaps xmm2, [rsp+0x20]
0000707649fe097e  vmovaps xmm3, [rsp+0x30]
0000707649fe0984  vmovaps xmm4, [rsp+0x40]
0000707649fe098a  vmovaps xmm5, [rsp+0x50]
0000707649fe0990  vmovaps xmm6, [rsp+0x60]
0000707649fe0996  vmovaps xmm7, [rsp+0x70]
0000707649fe099c  vmovaps xmm8, [rsp+0x80]
0000707649fe09a5  vmovaps xmm9, [rsp+0x90]
0000707649fe09ae  vmovaps xmm10, [rsp+0xA0]
0000707649fe09b7  vmovaps xmm11, [rsp+0xB0]
0000707649fe09c0  vmovaps xmm12, [rsp+0xC0]
0000707649fe09c9  vmovaps xmm13, [rsp+0xD0]
0000707649fe09d2  vmovaps xmm14, [rsp+0xE0]
0000707649fe09db  add rsp, 0xF0
0000707649fe09e2  pop r11
0000707649fe09e4  pop r10
0000707649fe09e6  pop r9
0000707649fe09e8  pop r8
0000707649fe09ea  pop rsi
0000707649fe09eb  pop rdi
0000707649fe09ec  pop rdx
0000707649fe09ed  pop rcx
0000707649fe09ee  pop rax
0000707649fe09ef  add rsp, 0x08
0000707649fe09f3  jmp 0x0000707649FDC658
0000707649fe09f8  sub rsp, 0x08
0000707649fe09fc  push rax
0000707649fe09fd  push rcx
0000707649fe09fe  push rdx
0000707649fe09ff  push rdi
0000707649fe0a00  push rsi
0000707649fe0a01  push r8
0000707649fe0a03  push r9
0000707649fe0a05  push r10
0000707649fe0a07  push r11
0000707649fe0a09  sub rsp, 0xF0
0000707649fe0a10  vmovaps [rsp], xmm0
0000707649fe0a15  vmovaps [rsp+0x10], xmm1
0000707649fe0a1b  vmovaps [rsp+0x20], xmm2
0000707649fe0a21  vmovaps [rsp+0x30], xmm3
0000707649fe0a27  vmovaps [rsp+0x40], xmm4
0000707649fe0a2d  vmovaps [rsp+0x50], xmm5
0000707649fe0a33  vmovaps [rsp+0x60], xmm6
0000707649fe0a39  vmovaps [rsp+0x70], xmm8
0000707649fe0a3f  vmovaps [rsp+0x80], xmm9
0000707649fe0a48  vmovaps [rsp+0x90], xmm10
0000707649fe0a51  vmovaps [rsp+0xA0], xmm11
0000707649fe0a5a  vmovaps [rsp+0xB0], xmm12
0000707649fe0a63  vmovaps [rsp+0xC0], xmm13
0000707649fe0a6c  vmovaps [rsp+0xD0], xmm14
0000707649fe0a75  vmovaps [rsp+0xE0], xmm15
0000707649fe0a7e  sub rsp, 0x30
0000707649fe0a82  movaps [rsp], xmm7
0000707649fe0a86  movaps [rsp+0x10], xmm11
0000707649fe0a8c  movaps [rsp+0x20], xmm9
0000707649fe0a92  lea rdi, [rsp]
0000707649fe0a96  mov esi, 0x00
0000707649fe0a9b  mov rax, 0x59CB0B054530
0000707649fe0aa5  call rax
0000707649fe0aa7  movaps xmm7, [rsp]
0000707649fe0aab  add rsp, 0x30
0000707649fe0aaf  vmovaps xmm0, [rsp]
0000707649fe0ab4  vmovaps xmm1, [rsp+0x10]
0000707649fe0aba  vmovaps xmm2, [rsp+0x20]
0000707649fe0ac0  vmovaps xmm3, [rsp+0x30]
0000707649fe0ac6  vmovaps xmm4, [rsp+0x40]
0000707649fe0acc  vmovaps xmm5, [rsp+0x50]
0000707649fe0ad2  vmovaps xmm6, [rsp+0x60]
0000707649fe0ad8  vmovaps xmm8, [rsp+0x70]
0000707649fe0ade  vmovaps xmm9, [rsp+0x80]
0000707649fe0ae7  vmovaps xmm10, [rsp+0x90]
0000707649fe0af0  vmovaps xmm11, [rsp+0xA0]
0000707649fe0af9  vmovaps xmm12, [rsp+0xB0]
0000707649fe0b02  vmovaps xmm13, [rsp+0xC0]
0000707649fe0b0b  vmovaps xmm14, [rsp+0xD0]
0000707649fe0b14  vmovaps xmm15, [rsp+0xE0]
0000707649fe0b1d  add rsp, 0xF0
0000707649fe0b24  pop r11
0000707649fe0b26  pop r10
0000707649fe0b28  pop r9
0000707649fe0b2a  pop r8
0000707649fe0b2c  pop rsi
0000707649fe0b2d  pop rdi
0000707649fe0b2e  pop rdx
0000707649fe0b2f  pop rcx
0000707649fe0b30  pop rax
0000707649fe0b31  add rsp, 0x08
0000707649fe0b35  jmp 0x0000707649FDC685
0000707649fe0b3a  sub rsp, 0x08
0000707649fe0b3e  push rax
0000707649fe0b3f  push rcx
0000707649fe0b40  push rdx
0000707649fe0b41  push rdi
0000707649fe0b42  push rsi
0000707649fe0b43  push r8
0000707649fe0b45  push r9
0000707649fe0b47  push r10
0000707649fe0b49  push r11
0000707649fe0b4b  sub rsp, 0xF0
0000707649fe0b52  vmovaps [rsp], xmm0
0000707649fe0b57  vmovaps [rsp+0x10], xmm1
0000707649fe0b5d  vmovaps [rsp+0x20], xmm2
0000707649fe0b63  vmovaps [rsp+0x30], xmm3
0000707649fe0b69  vmovaps [rsp+0x40], xmm4
0000707649fe0b6f  vmovaps [rsp+0x50], xmm5
0000707649fe0b75  vmovaps [rsp+0x60], xmm6
0000707649fe0b7b  vmovaps [rsp+0x70], xmm7
0000707649fe0b81  vmovaps [rsp+0x80], xmm8
0000707649fe0b8a  vmovaps [rsp+0x90], xmm9
0000707649fe0b93  vmovaps [rsp+0xA0], xmm10
0000707649fe0b9c  vmovaps [rsp+0xB0], xmm12
0000707649fe0ba5  vmovaps [rsp+0xC0], xmm13
0000707649fe0bae  vmovaps [rsp+0xD0], xmm14
0000707649fe0bb7  vmovaps [rsp+0xE0], xmm15
0000707649fe0bc0  sub rsp, 0x30
0000707649fe0bc4  movaps [rsp], xmm11
0000707649fe0bc9  movaps [rsp+0x10], xmm10
0000707649fe0bcf  movaps [rsp+0x20], xmm14
0000707649fe0bd5  lea rdi, [rsp]
0000707649fe0bd9  mov esi, 0x00
0000707649fe0bde  mov rax, 0x59CB0B054530
0000707649fe0be8  call rax
0000707649fe0bea  movaps xmm11, [rsp]
0000707649fe0bef  add rsp, 0x30
0000707649fe0bf3  vmovaps xmm0, [rsp]
0000707649fe0bf8  vmovaps xmm1, [rsp+0x10]
0000707649fe0bfe  vmovaps xmm2, [rsp+0x20]
0000707649fe0c04  vmovaps xmm3, [rsp+0x30]
0000707649fe0c0a  vmovaps xmm4, [rsp+0x40]
0000707649fe0c10  vmovaps xmm5, [rsp+0x50]
0000707649fe0c16  vmovaps xmm6, [rsp+0x60]
0000707649fe0c1c  vmovaps xmm7, [rsp+0x70]
0000707649fe0c22  vmovaps xmm8, [rsp+0x80]
0000707649fe0c2b  vmovaps xmm9, [rsp+0x90]
0000707649fe0c34  vmovaps xmm10, [rsp+0xA0]
0000707649fe0c3d  vmovaps xmm12, [rsp+0xB0]
0000707649fe0c46  vmovaps xmm13, [rsp+0xC0]
0000707649fe0c4f  vmovaps xmm14, [rsp+0xD0]
0000707649fe0c58  vmovaps xmm15, [rsp+0xE0]
0000707649fe0c61  add rsp, 0xF0
0000707649fe0c68  pop r11
0000707649fe0c6a  pop r10
0000707649fe0c6c  pop r9
0000707649fe0c6e  pop r8
0000707649fe0c70  pop rsi
0000707649fe0c71  pop rdi
0000707649fe0c72  pop rdx
0000707649fe0c73  pop rcx
0000707649fe0c74  pop rax
0000707649fe0c75  add rsp, 0x08
0000707649fe0c79  jmp 0x0000707649FDC6A0
0000707649fe0c7e  call 0x0000707649EC33A0
0000707649fe0c83  jmp 0x0000707649FDC6AA
0000707649fe0c88  sub rsp, 0x08
0000707649fe0c8c  push rax
0000707649fe0c8d  push rcx
0000707649fe0c8e  push rdx
0000707649fe0c8f  push rdi
0000707649fe0c90  push rsi
0000707649fe0c91  push r8
0000707649fe0c93  push r9
0000707649fe0c95  push r10
0000707649fe0c97  push r11
0000707649fe0c99  sub rsp, 0xF0
0000707649fe0ca0  vmovaps [rsp], xmm0
0000707649fe0ca5  vmovaps [rsp+0x10], xmm1
0000707649fe0cab  vmovaps [rsp+0x20], xmm2
0000707649fe0cb1  vmovaps [rsp+0x30], xmm3
0000707649fe0cb7  vmovaps [rsp+0x40], xmm4
0000707649fe0cbd  vmovaps [rsp+0x50], xmm5
0000707649fe0cc3  vmovaps [rsp+0x60], xmm6
0000707649fe0cc9  vmovaps [rsp+0x70], xmm7
0000707649fe0ccf  vmovaps [rsp+0x80], xmm8
0000707649fe0cd8  vmovaps [rsp+0x90], xmm9
0000707649fe0ce1  vmovaps [rsp+0xA0], xmm11
0000707649fe0cea  vmovaps [rsp+0xB0], xmm12
0000707649fe0cf3  vmovaps [rsp+0xC0], xmm13
0000707649fe0cfc  vmovaps [rsp+0xD0], xmm14
0000707649fe0d05  vmovaps [rsp+0xE0], xmm15
0000707649fe0d0e  sub rsp, 0x30
0000707649fe0d12  movaps [rsp], xmm10
0000707649fe0d17  movaps [rsp+0x10], xmm1
0000707649fe0d1c  movaps [rsp+0x20], xmm12
0000707649fe0d22  lea rdi, [rsp]
0000707649fe0d26  mov esi, 0x00
0000707649fe0d2b  mov rax, 0x59CB0B054530
0000707649fe0d35  call rax
0000707649fe0d37  movaps xmm10, [rsp]
0000707649fe0d3c  add rsp, 0x30
0000707649fe0d40  vmovaps xmm0, [rsp]
0000707649fe0d45  vmovaps xmm1, [rsp+0x10]
0000707649fe0d4b  vmovaps xmm2, [rsp+0x20]
0000707649fe0d51  vmovaps xmm3, [rsp+0x30]
0000707649fe0d57  vmovaps xmm4, [rsp+0x40]
0000707649fe0d5d  vmovaps xmm5, [rsp+0x50]
0000707649fe0d63  vmovaps xmm6, [rsp+0x60]
0000707649fe0d69  vmovaps xmm7, [rsp+0x70]
0000707649fe0d6f  vmovaps xmm8, [rsp+0x80]
0000707649fe0d78  vmovaps xmm9, [rsp+0x90]
0000707649fe0d81  vmovaps xmm11, [rsp+0xA0]
0000707649fe0d8a  vmovaps xmm12, [rsp+0xB0]
0000707649fe0d93  vmovaps xmm13, [rsp+0xC0]
0000707649fe0d9c  vmovaps xmm14, [rsp+0xD0]
0000707649fe0da5  vmovaps xmm15, [rsp+0xE0]
0000707649fe0dae  add rsp, 0xF0
0000707649fe0db5  pop r11
0000707649fe0db7  pop r10
0000707649fe0db9  pop r9
0000707649fe0dbb  pop r8
0000707649fe0dbd  pop rsi
0000707649fe0dbe  pop rdi
0000707649fe0dbf  pop rdx
0000707649fe0dc0  pop rcx
0000707649fe0dc1  pop rax
0000707649fe0dc2  add rsp, 0x08
0000707649fe0dc6  jmp 0x0000707649FDC6CD
0000707649fe0dcb  sub rsp, 0x08
0000707649fe0dcf  push rax
0000707649fe0dd0  push rcx
0000707649fe0dd1  push rdx
0000707649fe0dd2  push rdi
0000707649fe0dd3  push rsi
0000707649fe0dd4  push r8
0000707649fe0dd6  push r9
0000707649fe0dd8  push r10
0000707649fe0dda  push r11
0000707649fe0ddc  sub rsp, 0xF0
0000707649fe0de3  vmovaps [rsp], xmm0
0000707649fe0de8  vmovaps [rsp+0x10], xmm1
0000707649fe0dee  vmovaps [rsp+0x20], xmm2
0000707649fe0df4  vmovaps [rsp+0x30], xmm3
0000707649fe0dfa  vmovaps [rsp+0x40], xmm4
0000707649fe0e00  vmovaps [rsp+0x50], xmm5
0000707649fe0e06  vmovaps [rsp+0x60], xmm6
0000707649fe0e0c  vmovaps [rsp+0x70], xmm7
0000707649fe0e12  vmovaps [rsp+0x80], xmm8
0000707649fe0e1b  vmovaps [rsp+0x90], xmm9
0000707649fe0e24  vmovaps [rsp+0xA0], xmm10
0000707649fe0e2d  vmovaps [rsp+0xB0], xmm11
0000707649fe0e36  vmovaps [rsp+0xC0], xmm13
0000707649fe0e3f  vmovaps [rsp+0xD0], xmm14
0000707649fe0e48  vmovaps [rsp+0xE0], xmm15
0000707649fe0e51  sub rsp, 0x30
0000707649fe0e55  movaps [rsp], xmm12
0000707649fe0e5a  movaps [rsp+0x10], xmm14
0000707649fe0e60  movaps [rsp+0x20], xmm1
0000707649fe0e65  lea rdi, [rsp]
0000707649fe0e69  mov esi, 0x00
0000707649fe0e6e  mov rax, 0x59CB0B054530
0000707649fe0e78  call rax
0000707649fe0e7a  movaps xmm12, [rsp]
0000707649fe0e7f  add rsp, 0x30
0000707649fe0e83  vmovaps xmm0, [rsp]
0000707649fe0e88  vmovaps xmm1, [rsp+0x10]
0000707649fe0e8e  vmovaps xmm2, [rsp+0x20]
0000707649fe0e94  vmovaps xmm3, [rsp+0x30]
0000707649fe0e9a  vmovaps xmm4, [rsp+0x40]
0000707649fe0ea0  vmovaps xmm5, [rsp+0x50]
0000707649fe0ea6  vmovaps xmm6, [rsp+0x60]
0000707649fe0eac  vmovaps xmm7, [rsp+0x70]
0000707649fe0eb2  vmovaps xmm8, [rsp+0x80]
0000707649fe0ebb  vmovaps xmm9, [rsp+0x90]
0000707649fe0ec4  vmovaps xmm10, [rsp+0xA0]
0000707649fe0ecd  vmovaps xmm11, [rsp+0xB0]
0000707649fe0ed6  vmovaps xmm13, [rsp+0xC0]
0000707649fe0edf  vmovaps xmm14, [rsp+0xD0]
0000707649fe0ee8  vmovaps xmm15, [rsp+0xE0]
0000707649fe0ef1  add rsp, 0xF0
0000707649fe0ef8  pop r11
0000707649fe0efa  pop r10
0000707649fe0efc  pop r9
0000707649fe0efe  pop r8
0000707649fe0f00  pop rsi
0000707649fe0f01  pop rdi
0000707649fe0f02  pop rdx
0000707649fe0f03  pop rcx
0000707649fe0f04  pop rax
0000707649fe0f05  add rsp, 0x08
0000707649fe0f09  jmp 0x0000707649FDC6FC
0000707649fe0f0e  sub rsp, 0x08
0000707649fe0f12  push rax
0000707649fe0f13  push rcx
0000707649fe0f14  push rdx
0000707649fe0f15  push rdi
0000707649fe0f16  push rsi
0000707649fe0f17  push r8
0000707649fe0f19  push r9
0000707649fe0f1b  push r10
0000707649fe0f1d  push r11
0000707649fe0f1f  sub rsp, 0xF0
0000707649fe0f26  vmovaps [rsp], xmm0
0000707649fe0f2b  vmovaps [rsp+0x10], xmm1
0000707649fe0f31  vmovaps [rsp+0x20], xmm2
0000707649fe0f37  vmovaps [rsp+0x30], xmm3
0000707649fe0f3d  vmovaps [rsp+0x40], xmm4
0000707649fe0f43  vmovaps [rsp+0x50], xmm5
0000707649fe0f49  vmovaps [rsp+0x60], xmm6
0000707649fe0f4f  vmovaps [rsp+0x70], xmm7
0000707649fe0f55  vmovaps [rsp+0x80], xmm8
0000707649fe0f5e  vmovaps [rsp+0x90], xmm9
0000707649fe0f67  vmovaps [rsp+0xA0], xmm10
0000707649fe0f70  vmovaps [rsp+0xB0], xmm11
0000707649fe0f79  vmovaps [rsp+0xC0], xmm12
0000707649fe0f82  vmovaps [rsp+0xD0], xmm13
0000707649fe0f8b  vmovaps [rsp+0xE0], xmm15
0000707649fe0f94  sub rsp, 0x30
0000707649fe0f98  movaps [rsp], xmm14
0000707649fe0f9d  movaps [rsp+0x10], xmm9
0000707649fe0fa3  movaps [rsp+0x20], xmm1
0000707649fe0fa8  lea rdi, [rsp]
0000707649fe0fac  mov esi, 0x00
0000707649fe0fb1  mov rax, 0x59CB0B054530
0000707649fe0fbb  call rax
0000707649fe0fbd  movaps xmm14, [rsp]
0000707649fe0fc2  add rsp, 0x30
0000707649fe0fc6  vmovaps xmm0, [rsp]
0000707649fe0fcb  vmovaps xmm1, [rsp+0x10]
0000707649fe0fd1  vmovaps xmm2, [rsp+0x20]
0000707649fe0fd7  vmovaps xmm3, [rsp+0x30]
0000707649fe0fdd  vmovaps xmm4, [rsp+0x40]
0000707649fe0fe3  vmovaps xmm5, [rsp+0x50]
0000707649fe0fe9  vmovaps xmm6, [rsp+0x60]
0000707649fe0fef  vmovaps xmm7, [rsp+0x70]
0000707649fe0ff5  vmovaps xmm8, [rsp+0x80]
0000707649fe0ffe  vmovaps xmm9, [rsp+0x90]
0000707649fe1007  vmovaps xmm10, [rsp+0xA0]
0000707649fe1010  vmovaps xmm11, [rsp+0xB0]
0000707649fe1019  vmovaps xmm12, [rsp+0xC0]
0000707649fe1022  vmovaps xmm13, [rsp+0xD0]
0000707649fe102b  vmovaps xmm15, [rsp+0xE0]
0000707649fe1034  add rsp, 0xF0
0000707649fe103b  pop r11
0000707649fe103d  pop r10
0000707649fe103f  pop r9
0000707649fe1041  pop r8
0000707649fe1043  pop rsi
0000707649fe1044  pop rdi
0000707649fe1045  pop rdx
0000707649fe1046  pop rcx
0000707649fe1047  pop rax
0000707649fe1048  add rsp, 0x08
0000707649fe104c  jmp 0x0000707649FDC72B
0000707649fe1051  sub rsp, 0x08
0000707649fe1055  push rax
0000707649fe1056  push rcx
0000707649fe1057  push rdx
0000707649fe1058  push rdi
0000707649fe1059  push rsi
0000707649fe105a  push r8
0000707649fe105c  push r9
0000707649fe105e  push r10
0000707649fe1060  push r11
0000707649fe1062  sub rsp, 0xF0
0000707649fe1069  vmovaps [rsp], xmm0
0000707649fe106e  vmovaps [rsp+0x10], xmm2
0000707649fe1074  vmovaps [rsp+0x20], xmm3
0000707649fe107a  vmovaps [rsp+0x30], xmm4
0000707649fe1080  vmovaps [rsp+0x40], xmm5
0000707649fe1086  vmovaps [rsp+0x50], xmm6
0000707649fe108c  vmovaps [rsp+0x60], xmm7
0000707649fe1092  vmovaps [rsp+0x70], xmm8
0000707649fe1098  vmovaps [rsp+0x80], xmm9
0000707649fe10a1  vmovaps [rsp+0x90], xmm10
0000707649fe10aa  vmovaps [rsp+0xA0], xmm11
0000707649fe10b3  vmovaps [rsp+0xB0], xmm12
0000707649fe10bc  vmovaps [rsp+0xC0], xmm13
0000707649fe10c5  vmovaps [rsp+0xD0], xmm14
0000707649fe10ce  vmovaps [rsp+0xE0], xmm15
0000707649fe10d7  sub rsp, 0x30
0000707649fe10db  movaps [rsp], xmm1
0000707649fe10df  movaps [rsp+0x10], xmm13
0000707649fe10e5  movaps [rsp+0x20], xmm8
0000707649fe10eb  lea rdi, [rsp]
0000707649fe10ef  mov esi, 0x00
0000707649fe10f4  mov rax, 0x59CB0B054530
0000707649fe10fe  call rax
0000707649fe1100  movaps xmm1, [rsp]
0000707649fe1104  add rsp, 0x30
0000707649fe1108  vmovaps xmm0, [rsp]
0000707649fe110d  vmovaps xmm2, [rsp+0x10]
0000707649fe1113  vmovaps xmm3, [rsp+0x20]
0000707649fe1119  vmovaps xmm4, [rsp+0x30]
0000707649fe111f  vmovaps xmm5, [rsp+0x40]
0000707649fe1125  vmovaps xmm6, [rsp+0x50]
0000707649fe112b  vmovaps xmm7, [rsp+0x60]
0000707649fe1131  vmovaps xmm8, [rsp+0x70]
0000707649fe1137  vmovaps xmm9, [rsp+0x80]
0000707649fe1140  vmovaps xmm10, [rsp+0x90]
0000707649fe1149  vmovaps xmm11, [rsp+0xA0]
0000707649fe1152  vmovaps xmm12, [rsp+0xB0]
0000707649fe115b  vmovaps xmm13, [rsp+0xC0]
0000707649fe1164  vmovaps xmm14, [rsp+0xD0]
0000707649fe116d  vmovaps xmm15, [rsp+0xE0]
0000707649fe1176  add rsp, 0xF0
0000707649fe117d  pop r11
0000707649fe117f  pop r10
0000707649fe1181  pop r9
0000707649fe1183  pop r8
0000707649fe1185  pop rsi
0000707649fe1186  pop rdi
0000707649fe1187  pop rdx
0000707649fe1188  pop rcx
0000707649fe1189  pop rax
0000707649fe118a  add rsp, 0x08
0000707649fe118e  jmp 0x0000707649FDC74D
0000707649fe1193  call 0x0000707649E0C260
0000707649fe1198  jmp 0x0000707649FDC75B
0000707649fe119d  call 0x0000707649EBD750
0000707649fe11a2  jmp 0x0000707649FDC765
0000707649fe11a7  sub rsp, 0x08
0000707649fe11ab  push rax
0000707649fe11ac  push rcx
0000707649fe11ad  push rdx
0000707649fe11ae  push rdi
0000707649fe11af  push rsi
0000707649fe11b0  push r8
0000707649fe11b2  push r9
0000707649fe11b4  push r10
0000707649fe11b6  push r11
0000707649fe11b8  sub rsp, 0xF0
0000707649fe11bf  vmovaps [rsp], xmm0
0000707649fe11c4  vmovaps [rsp+0x10], xmm1
0000707649fe11ca  vmovaps [rsp+0x20], xmm2
0000707649fe11d0  vmovaps [rsp+0x30], xmm3
0000707649fe11d6  vmovaps [rsp+0x40], xmm4
0000707649fe11dc  vmovaps [rsp+0x50], xmm5
0000707649fe11e2  vmovaps [rsp+0x60], xmm6
0000707649fe11e8  vmovaps [rsp+0x70], xmm7
0000707649fe11ee  vmovaps [rsp+0x80], xmm9
0000707649fe11f7  vmovaps [rsp+0x90], xmm10
0000707649fe1200  vmovaps [rsp+0xA0], xmm11
0000707649fe1209  vmovaps [rsp+0xB0], xmm12
0000707649fe1212  vmovaps [rsp+0xC0], xmm13
0000707649fe121b  vmovaps [rsp+0xD0], xmm14
0000707649fe1224  vmovaps [rsp+0xE0], xmm15
0000707649fe122d  sub rsp, 0x30
0000707649fe1231  movaps [rsp], xmm8
0000707649fe1236  movaps [rsp+0x10], xmm15
0000707649fe123c  movaps [rsp+0x20], xmm7
0000707649fe1241  lea rdi, [rsp]
0000707649fe1245  mov esi, 0x00
0000707649fe124a  mov rax, 0x59CB0B054530
0000707649fe1254  call rax
0000707649fe1256  movaps xmm8, [rsp]
0000707649fe125b  add rsp, 0x30
0000707649fe125f  vmovaps xmm0, [rsp]
0000707649fe1264  vmovaps xmm1, [rsp+0x10]
0000707649fe126a  vmovaps xmm2, [rsp+0x20]
0000707649fe1270  vmovaps xmm3, [rsp+0x30]
0000707649fe1276  vmovaps xmm4, [rsp+0x40]
0000707649fe127c  vmovaps xmm5, [rsp+0x50]
0000707649fe1282  vmovaps xmm6, [rsp+0x60]
0000707649fe1288  vmovaps xmm7, [rsp+0x70]
0000707649fe128e  vmovaps xmm9, [rsp+0x80]
0000707649fe1297  vmovaps xmm10, [rsp+0x90]
0000707649fe12a0  vmovaps xmm11, [rsp+0xA0]
0000707649fe12a9  vmovaps xmm12, [rsp+0xB0]
0000707649fe12b2  vmovaps xmm13, [rsp+0xC0]
0000707649fe12bb  vmovaps xmm14, [rsp+0xD0]
0000707649fe12c4  vmovaps xmm15, [rsp+0xE0]
0000707649fe12cd  add rsp, 0xF0
0000707649fe12d4  pop r11
0000707649fe12d6  pop r10
0000707649fe12d8  pop r9
0000707649fe12da  pop r8
0000707649fe12dc  pop rsi
0000707649fe12dd  pop rdi
0000707649fe12de  pop rdx
0000707649fe12df  pop rcx
0000707649fe12e0  pop rax
0000707649fe12e1  add rsp, 0x08
0000707649fe12e5  jmp 0x0000707649FDC787
0000707649fe12ea  sub rsp, 0x08
0000707649fe12ee  push rax
0000707649fe12ef  push rcx
0000707649fe12f0  push rdx
0000707649fe12f1  push rdi
0000707649fe12f2  push rsi
0000707649fe12f3  push r8
0000707649fe12f5  push r9
0000707649fe12f7  push r10
0000707649fe12f9  push r11
0000707649fe12fb  sub rsp, 0xF0
0000707649fe1302  vmovaps [rsp], xmm0
0000707649fe1307  vmovaps [rsp+0x10], xmm1
0000707649fe130d  vmovaps [rsp+0x20], xmm2
0000707649fe1313  vmovaps [rsp+0x30], xmm3
0000707649fe1319  vmovaps [rsp+0x40], xmm4
0000707649fe131f  vmovaps [rsp+0x50], xmm5
0000707649fe1325  vmovaps [rsp+0x60], xmm6
0000707649fe132b  vmovaps [rsp+0x70], xmm8
0000707649fe1331  vmovaps [rsp+0x80], xmm9
0000707649fe133a  vmovaps [rsp+0x90], xmm10
0000707649fe1343  vmovaps [rsp+0xA0], xmm11
0000707649fe134c  vmovaps [rsp+0xB0], xmm12
0000707649fe1355  vmovaps [rsp+0xC0], xmm13
0000707649fe135e  vmovaps [rsp+0xD0], xmm14
0000707649fe1367  vmovaps [rsp+0xE0], xmm15
0000707649fe1370  sub rsp, 0x30
0000707649fe1374  movaps [rsp], xmm7
0000707649fe1378  movaps [rsp+0x10], xmm9
0000707649fe137e  movaps [rsp+0x20], xmm15
0000707649fe1384  lea rdi, [rsp]
0000707649fe1388  mov esi, 0x00
0000707649fe138d  mov rax, 0x59CB0B054530
0000707649fe1397  call rax
0000707649fe1399  movaps xmm7, [rsp]
0000707649fe139d  add rsp, 0x30
0000707649fe13a1  vmovaps xmm0, [rsp]
0000707649fe13a6  vmovaps xmm1, [rsp+0x10]
0000707649fe13ac  vmovaps xmm2, [rsp+0x20]
0000707649fe13b2  vmovaps xmm3, [rsp+0x30]
0000707649fe13b8  vmovaps xmm4, [rsp+0x40]
0000707649fe13be  vmovaps xmm5, [rsp+0x50]
0000707649fe13c4  vmovaps xmm6, [rsp+0x60]
0000707649fe13ca  vmovaps xmm8, [rsp+0x70]
0000707649fe13d0  vmovaps xmm9, [rsp+0x80]
0000707649fe13d9  vmovaps xmm10, [rsp+0x90]
0000707649fe13e2  vmovaps xmm11, [rsp+0xA0]
0000707649fe13eb  vmovaps xmm12, [rsp+0xB0]
0000707649fe13f4  vmovaps xmm13, [rsp+0xC0]
0000707649fe13fd  vmovaps xmm14, [rsp+0xD0]
0000707649fe1406  vmovaps xmm15, [rsp+0xE0]
0000707649fe140f  add rsp, 0xF0
0000707649fe1416  pop r11
0000707649fe1418  pop r10
0000707649fe141a  pop r9
0000707649fe141c  pop r8
0000707649fe141e  pop rsi
0000707649fe141f  pop rdi
0000707649fe1420  pop rdx
0000707649fe1421  pop rcx
0000707649fe1422  pop rax
0000707649fe1423  add rsp, 0x08
0000707649fe1427  jmp 0x0000707649FDC7B4
0000707649fe142c  sub rsp, 0x08
0000707649fe1430  push rax
0000707649fe1431  push rcx
0000707649fe1432  push rdx
0000707649fe1433  push rdi
0000707649fe1434  push rsi
0000707649fe1435  push r8
0000707649fe1437  push r9
0000707649fe1439  push r10
0000707649fe143b  push r11
0000707649fe143d  sub rsp, 0xF0
0000707649fe1444  vmovaps [rsp], xmm0
0000707649fe1449  vmovaps [rsp+0x10], xmm1
0000707649fe144f  vmovaps [rsp+0x20], xmm2
0000707649fe1455  vmovaps [rsp+0x30], xmm3
0000707649fe145b  vmovaps [rsp+0x40], xmm4
0000707649fe1461  vmovaps [rsp+0x50], xmm5
0000707649fe1467  vmovaps [rsp+0x60], xmm6
0000707649fe146d  vmovaps [rsp+0x70], xmm7
0000707649fe1473  vmovaps [rsp+0x80], xmm8
0000707649fe147c  vmovaps [rsp+0x90], xmm10
0000707649fe1485  vmovaps [rsp+0xA0], xmm11
0000707649fe148e  vmovaps [rsp+0xB0], xmm12
0000707649fe1497  vmovaps [rsp+0xC0], xmm13
0000707649fe14a0  vmovaps [rsp+0xD0], xmm14
0000707649fe14a9  vmovaps [rsp+0xE0], xmm15
0000707649fe14b2  sub rsp, 0x30
0000707649fe14b6  movaps [rsp], xmm9
0000707649fe14bb  movaps [rsp+0x10], xmm13
0000707649fe14c1  movaps [rsp+0x20], xmm15
0000707649fe14c7  lea rdi, [rsp]
0000707649fe14cb  mov esi, 0x00
0000707649fe14d0  mov rax, 0x59CB0B054530
0000707649fe14da  call rax
0000707649fe14dc  movaps xmm9, [rsp]
0000707649fe14e1  add rsp, 0x30
0000707649fe14e5  vmovaps xmm0, [rsp]
0000707649fe14ea  vmovaps xmm1, [rsp+0x10]
0000707649fe14f0  vmovaps xmm2, [rsp+0x20]
0000707649fe14f6  vmovaps xmm3, [rsp+0x30]
0000707649fe14fc  vmovaps xmm4, [rsp+0x40]
0000707649fe1502  vmovaps xmm5, [rsp+0x50]
0000707649fe1508  vmovaps xmm6, [rsp+0x60]
0000707649fe150e  vmovaps xmm7, [rsp+0x70]
0000707649fe1514  vmovaps xmm8, [rsp+0x80]
0000707649fe151d  vmovaps xmm10, [rsp+0x90]
0000707649fe1526  vmovaps xmm11, [rsp+0xA0]
0000707649fe152f  vmovaps xmm12, [rsp+0xB0]
0000707649fe1538  vmovaps xmm13, [rsp+0xC0]
0000707649fe1541  vmovaps xmm14, [rsp+0xD0]
0000707649fe154a  vmovaps xmm15, [rsp+0xE0]
0000707649fe1553  add rsp, 0xF0
0000707649fe155a  pop r11
0000707649fe155c  pop r10
0000707649fe155e  pop r9
0000707649fe1560  pop r8
0000707649fe1562  pop rsi
0000707649fe1563  pop rdi
0000707649fe1564  pop rdx
0000707649fe1565  pop rcx
0000707649fe1566  pop rax
0000707649fe1567  add rsp, 0x08
0000707649fe156b  jmp 0x0000707649FDC7E2
0000707649fe1570  sub rsp, 0x08
0000707649fe1574  push rax
0000707649fe1575  push rcx
0000707649fe1576  push rdx
0000707649fe1577  push rdi
0000707649fe1578  push rsi
0000707649fe1579  push r8
0000707649fe157b  push r9
0000707649fe157d  push r10
0000707649fe157f  push r11
0000707649fe1581  sub rsp, 0xF0
0000707649fe1588  vmovaps [rsp], xmm0
0000707649fe158d  vmovaps [rsp+0x10], xmm1
0000707649fe1593  vmovaps [rsp+0x20], xmm2
0000707649fe1599  vmovaps [rsp+0x30], xmm3
0000707649fe159f  vmovaps [rsp+0x40], xmm4
0000707649fe15a5  vmovaps [rsp+0x50], xmm5
0000707649fe15ab  vmovaps [rsp+0x60], xmm6
0000707649fe15b1  vmovaps [rsp+0x70], xmm7
0000707649fe15b7  vmovaps [rsp+0x80], xmm8
0000707649fe15c0  vmovaps [rsp+0x90], xmm9
0000707649fe15c9  vmovaps [rsp+0xA0], xmm10
0000707649fe15d2  vmovaps [rsp+0xB0], xmm11
0000707649fe15db  vmovaps [rsp+0xC0], xmm12
0000707649fe15e4  vmovaps [rsp+0xD0], xmm13
0000707649fe15ed  vmovaps [rsp+0xE0], xmm14
0000707649fe15f6  sub rsp, 0x30
0000707649fe15fa  movaps [rsp], xmm15
0000707649fe15ff  movaps [rsp+0x10], xmm11
0000707649fe1605  movaps [rsp+0x20], xmm12
0000707649fe160b  lea rdi, [rsp]
0000707649fe160f  mov esi, 0x00
0000707649fe1614  mov rax, 0x59CB0B054530
0000707649fe161e  call rax
0000707649fe1620  movaps xmm15, [rsp]
0000707649fe1625  add rsp, 0x30
0000707649fe1629  vmovaps xmm0, [rsp]
0000707649fe162e  vmovaps xmm1, [rsp+0x10]
0000707649fe1634  vmovaps xmm2, [rsp+0x20]
0000707649fe163a  vmovaps xmm3, [rsp+0x30]
0000707649fe1640  vmovaps xmm4, [rsp+0x40]
0000707649fe1646  vmovaps xmm5, [rsp+0x50]
0000707649fe164c  vmovaps xmm6, [rsp+0x60]
0000707649fe1652  vmovaps xmm7, [rsp+0x70]
0000707649fe1658  vmovaps xmm8, [rsp+0x80]
0000707649fe1661  vmovaps xmm9, [rsp+0x90]
0000707649fe166a  vmovaps xmm10, [rsp+0xA0]
0000707649fe1673  vmovaps xmm11, [rsp+0xB0]
0000707649fe167c  vmovaps xmm12, [rsp+0xC0]
0000707649fe1685  vmovaps xmm13, [rsp+0xD0]
0000707649fe168e  vmovaps xmm14, [rsp+0xE0]
0000707649fe1697  add rsp, 0xF0
0000707649fe169e  pop r11
0000707649fe16a0  pop r10
0000707649fe16a2  pop r9
0000707649fe16a4  pop r8
0000707649fe16a6  pop rsi
0000707649fe16a7  pop rdi
0000707649fe16a8  pop rdx
0000707649fe16a9  pop rcx
0000707649fe16aa  pop rax
0000707649fe16ab  add rsp, 0x08
0000707649fe16af  jmp 0x0000707649FDC7FD
0000707649fe16b4  sub rsp, 0x08
0000707649fe16b8  push rax
0000707649fe16b9  push rcx
0000707649fe16ba  push rdx
0000707649fe16bb  push rdi
0000707649fe16bc  push rsi
0000707649fe16bd  push r8
0000707649fe16bf  push r9
0000707649fe16c1  push r10
0000707649fe16c3  push r11
0000707649fe16c5  sub rsp, 0xF0
0000707649fe16cc  vmovaps [rsp], xmm0
0000707649fe16d1  vmovaps [rsp+0x10], xmm1
0000707649fe16d7  vmovaps [rsp+0x20], xmm2
0000707649fe16dd  vmovaps [rsp+0x30], xmm3
0000707649fe16e3  vmovaps [rsp+0x40], xmm4
0000707649fe16e9  vmovaps [rsp+0x50], xmm5
0000707649fe16ef  vmovaps [rsp+0x60], xmm6
0000707649fe16f5  vmovaps [rsp+0x70], xmm7
0000707649fe16fb  vmovaps [rsp+0x80], xmm8
0000707649fe1704  vmovaps [rsp+0x90], xmm9
0000707649fe170d  vmovaps [rsp+0xA0], xmm10
0000707649fe1716  vmovaps [rsp+0xB0], xmm11
0000707649fe171f  vmovaps [rsp+0xC0], xmm12
0000707649fe1728  vmovaps [rsp+0xD0], xmm14
0000707649fe1731  vmovaps [rsp+0xE0], xmm15
0000707649fe173a  sub rsp, 0x30
0000707649fe173e  movaps [rsp], xmm13
0000707649fe1743  movaps [rsp+0x10], xmm10
0000707649fe1749  movaps [rsp+0x20], xmm14
0000707649fe174f  lea rdi, [rsp]
0000707649fe1753  mov esi, 0x00
0000707649fe1758  mov rax, 0x59CB0B054530
0000707649fe1762  call rax
0000707649fe1764  movaps xmm13, [rsp]
0000707649fe1769  add rsp, 0x30
0000707649fe176d  vmovaps xmm0, [rsp]
0000707649fe1772  vmovaps xmm1, [rsp+0x10]
0000707649fe1778  vmovaps xmm2, [rsp+0x20]
0000707649fe177e  vmovaps xmm3, [rsp+0x30]
0000707649fe1784  vmovaps xmm4, [rsp+0x40]
0000707649fe178a  vmovaps xmm5, [rsp+0x50]
0000707649fe1790  vmovaps xmm6, [rsp+0x60]
0000707649fe1796  vmovaps xmm7, [rsp+0x70]
0000707649fe179c  vmovaps xmm8, [rsp+0x80]
0000707649fe17a5  vmovaps xmm9, [rsp+0x90]
0000707649fe17ae  vmovaps xmm10, [rsp+0xA0]
0000707649fe17b7  vmovaps xmm11, [rsp+0xB0]
0000707649fe17c0  vmovaps xmm12, [rsp+0xC0]
0000707649fe17c9  vmovaps xmm14, [rsp+0xD0]
0000707649fe17d2  vmovaps xmm15, [rsp+0xE0]
0000707649fe17db  add rsp, 0xF0
0000707649fe17e2  pop r11
0000707649fe17e4  pop r10
0000707649fe17e6  pop r9
0000707649fe17e8  pop r8
0000707649fe17ea  pop rsi
0000707649fe17eb  pop rdi
0000707649fe17ec  pop rdx
0000707649fe17ed  pop rcx
0000707649fe17ee  pop rax
0000707649fe17ef  add rsp, 0x08
0000707649fe17f3  jmp 0x0000707649FDC820
0000707649fe17f8  sub rsp, 0x08
0000707649fe17fc  push rax
0000707649fe17fd  push rcx
0000707649fe17fe  push rdx
0000707649fe17ff  push rdi
0000707649fe1800  push rsi
0000707649fe1801  push r8
0000707649fe1803  push r9
0000707649fe1805  push r10
0000707649fe1807  push r11
0000707649fe1809  sub rsp, 0xF0
0000707649fe1810  vmovaps [rsp], xmm0
0000707649fe1815  vmovaps [rsp+0x10], xmm1
0000707649fe181b  vmovaps [rsp+0x20], xmm2
0000707649fe1821  vmovaps [rsp+0x30], xmm3
0000707649fe1827  vmovaps [rsp+0x40], xmm4
0000707649fe182d  vmovaps [rsp+0x50], xmm5
0000707649fe1833  vmovaps [rsp+0x60], xmm6
0000707649fe1839  vmovaps [rsp+0x70], xmm7
0000707649fe183f  vmovaps [rsp+0x80], xmm8
0000707649fe1848  vmovaps [rsp+0x90], xmm9
0000707649fe1851  vmovaps [rsp+0xA0], xmm10
0000707649fe185a  vmovaps [rsp+0xB0], xmm11
0000707649fe1863  vmovaps [rsp+0xC0], xmm12
0000707649fe186c  vmovaps [rsp+0xD0], xmm13
0000707649fe1875  vmovaps [rsp+0xE0], xmm15
0000707649fe187e  sub rsp, 0x30
0000707649fe1882  movaps [rsp], xmm14
0000707649fe1887  movaps [rsp+0x10], xmm1
0000707649fe188c  movaps [rsp+0x20], xmm7
0000707649fe1891  lea rdi, [rsp]
0000707649fe1895  mov esi, 0x00
0000707649fe189a  mov rax, 0x59CB0B054530
0000707649fe18a4  call rax
0000707649fe18a6  movaps xmm14, [rsp]
0000707649fe18ab  add rsp, 0x30
0000707649fe18af  vmovaps xmm0, [rsp]
0000707649fe18b4  vmovaps xmm1, [rsp+0x10]
0000707649fe18ba  vmovaps xmm2, [rsp+0x20]
0000707649fe18c0  vmovaps xmm3, [rsp+0x30]
0000707649fe18c6  vmovaps xmm4, [rsp+0x40]
0000707649fe18cc  vmovaps xmm5, [rsp+0x50]
0000707649fe18d2  vmovaps xmm6, [rsp+0x60]
0000707649fe18d8  vmovaps xmm7, [rsp+0x70]
0000707649fe18de  vmovaps xmm8, [rsp+0x80]
0000707649fe18e7  vmovaps xmm9, [rsp+0x90]
0000707649fe18f0  vmovaps xmm10, [rsp+0xA0]
0000707649fe18f9  vmovaps xmm11, [rsp+0xB0]
0000707649fe1902  vmovaps xmm12, [rsp+0xC0]
0000707649fe190b  vmovaps xmm13, [rsp+0xD0]
0000707649fe1914  vmovaps xmm15, [rsp+0xE0]
0000707649fe191d  add rsp, 0xF0
0000707649fe1924  pop r11
0000707649fe1926  pop r10
0000707649fe1928  pop r9
0000707649fe192a  pop r8
0000707649fe192c  pop rsi
0000707649fe192d  pop rdi
0000707649fe192e  pop rdx
0000707649fe192f  pop rcx
0000707649fe1930  pop rax
0000707649fe1931  add rsp, 0x08
0000707649fe1935  jmp 0x0000707649FDC843
0000707649fe193a  sub rsp, 0x08
0000707649fe193e  push rax
0000707649fe193f  push rcx
0000707649fe1940  push rdx
0000707649fe1941  push rdi
0000707649fe1942  push rsi
0000707649fe1943  push r8
0000707649fe1945  push r9
0000707649fe1947  push r10
0000707649fe1949  push r11
0000707649fe194b  sub rsp, 0xF0
0000707649fe1952  vmovaps [rsp], xmm0
0000707649fe1957  vmovaps [rsp+0x10], xmm2
0000707649fe195d  vmovaps [rsp+0x20], xmm3
0000707649fe1963  vmovaps [rsp+0x30], xmm4
0000707649fe1969  vmovaps [rsp+0x40], xmm5
0000707649fe196f  vmovaps [rsp+0x50], xmm6
0000707649fe1975  vmovaps [rsp+0x60], xmm7
0000707649fe197b  vmovaps [rsp+0x70], xmm8
0000707649fe1981  vmovaps [rsp+0x80], xmm9
0000707649fe198a  vmovaps [rsp+0x90], xmm10
0000707649fe1993  vmovaps [rsp+0xA0], xmm11
0000707649fe199c  vmovaps [rsp+0xB0], xmm12
0000707649fe19a5  vmovaps [rsp+0xC0], xmm13
0000707649fe19ae  vmovaps [rsp+0xD0], xmm14
0000707649fe19b7  vmovaps [rsp+0xE0], xmm15
0000707649fe19c0  sub rsp, 0x30
0000707649fe19c4  movaps [rsp], xmm1
0000707649fe19c8  movaps [rsp+0x10], xmm8
0000707649fe19ce  movaps [rsp+0x20], xmm9
0000707649fe19d4  lea rdi, [rsp]
0000707649fe19d8  mov esi, 0x00
0000707649fe19dd  mov rax, 0x59CB0B054530
0000707649fe19e7  call rax
0000707649fe19e9  movaps xmm1, [rsp]
0000707649fe19ed  add rsp, 0x30
0000707649fe19f1  vmovaps xmm0, [rsp]
0000707649fe19f6  vmovaps xmm2, [rsp+0x10]
0000707649fe19fc  vmovaps xmm3, [rsp+0x20]
0000707649fe1a02  vmovaps xmm4, [rsp+0x30]
0000707649fe1a08  vmovaps xmm5, [rsp+0x40]
0000707649fe1a0e  vmovaps xmm6, [rsp+0x50]
0000707649fe1a14  vmovaps xmm7, [rsp+0x60]
0000707649fe1a1a  vmovaps xmm8, [rsp+0x70]
0000707649fe1a20  vmovaps xmm9, [rsp+0x80]
0000707649fe1a29  vmovaps xmm10, [rsp+0x90]
0000707649fe1a32  vmovaps xmm11, [rsp+0xA0]
0000707649fe1a3b  vmovaps xmm12, [rsp+0xB0]
0000707649fe1a44  vmovaps xmm13, [rsp+0xC0]
0000707649fe1a4d  vmovaps xmm14, [rsp+0xD0]
0000707649fe1a56  vmovaps xmm15, [rsp+0xE0]
0000707649fe1a5f  add rsp, 0xF0
0000707649fe1a66  pop r11
0000707649fe1a68  pop r10
0000707649fe1a6a  pop r9
0000707649fe1a6c  pop r8
0000707649fe1a6e  pop rsi
0000707649fe1a6f  pop rdi
0000707649fe1a70  pop rdx
0000707649fe1a71  pop rcx
0000707649fe1a72  pop rax
0000707649fe1a73  add rsp, 0x08
0000707649fe1a77  jmp 0x0000707649FDC865
0000707649fe1a7c  call 0x0000707649EE5940
0000707649fe1a81  jmp 0x0000707649FDC873
0000707649fe1a86  call 0x0000707649E0C380
0000707649fe1a8b  jmp 0x0000707649FDC87D
0000707649fe1a90  call 0x0000707649E0D600
0000707649fe1a95  jmp 0x0000707649FDC887
0000707649fe1a9a  call 0x0000707649DFF540
0000707649fe1a9f  jmp 0x0000707649FDC891
0000707649fe1aa4  int3
0000707649fe1aa5  nop [rax+rax*1], ax
0000707649fe1aae  nop
0000707649fe1ab0  mov rax, [r15+0xF8]
0000707649fe1ab7  lea r14, [rax+0x140]
0000707649fe1abe  mov r12, [r13+r14*1]
0000707649fe1ac3  mov [r15+0xE8], r12
0000707649fe1aca  lea r14, [rax+0x130]
0000707649fe1ad1  mov r12, [r13+r14*1]
0000707649fe1ad6  lea r14, [rax+0x138]
0000707649fe1add  mov r11, [r13+r14*1]
0000707649fe1ae2  movq xmm1, r12
0000707649fe1ae7  movq xmm15, r11
0000707649fe1aec  movq xmm1, xmm1
0000707649fe1af0  movq xmm1, xmm1
0000707649fe1af4  movaps [r15+0x1A0], xmm1
0000707649fe1afc  movq xmm15, xmm15
0000707649fe1b01  movq xmm15, xmm15
0000707649fe1b06  movaps [r15+0x190], xmm15
0000707649fe1b0e  lea r14, [rax+0x120]
0000707649fe1b15  mov r12, [r13+r14*1]
0000707649fe1b1a  lea r14, [rax+0x128]
0000707649fe1b21  mov r11, [r13+r14*1]
0000707649fe1b26  movq xmm1, r12
0000707649fe1b2b  movq xmm15, r11
0000707649fe1b30  movq xmm1, xmm1
0000707649fe1b34  movq xmm1, xmm1
0000707649fe1b38  movaps [r15+0x1C0], xmm1
0000707649fe1b40  movq xmm15, xmm15
0000707649fe1b45  movq xmm15, xmm15
0000707649fe1b4a  movaps [r15+0x1B0], xmm15
0000707649fe1b52  lea r14, [rax+0x110]
0000707649fe1b59  mov r12, [r13+r14*1]
0000707649fe1b5e  lea r14, [rax+0x118]
0000707649fe1b65  mov r11, [r13+r14*1]
0000707649fe1b6a  movq xmm1, r12
0000707649fe1b6f  movq xmm15, r11
0000707649fe1b74  movq xmm1, xmm1
0000707649fe1b78  movq xmm1, xmm1
0000707649fe1b7c  movaps [r15+0x1E0], xmm1
0000707649fe1b84  movq xmm15, xmm15
0000707649fe1b89  movq xmm15, xmm15
0000707649fe1b8e  movaps [r15+0x1D0], xmm15
0000707649fe1b96  lea r14, [rax+0x100]
0000707649fe1b9d  mov r12, [r13+r14*1]
0000707649fe1ba2  lea r14, [rax+0x108]
0000707649fe1ba9  mov r11, [r13+r14*1]
0000707649fe1bae  movq xmm1, r12
0000707649fe1bb3  movq xmm15, r11
0000707649fe1bb8  movq xmm1, xmm1
0000707649fe1bbc  movq xmm1, xmm1
0000707649fe1bc0  movaps [r15+0x200], xmm1
0000707649fe1bc8  movq xmm15, xmm15
0000707649fe1bcd  movq xmm15, xmm15
0000707649fe1bd2  movaps [r15+0x1F0], xmm15
0000707649fe1bda  mov qword ptr [r15+0x40], 0x430000
0000707649fe1be2  mov r14d, 0x430510
0000707649fe1be8  mov r12, [r13+r14*1]
0000707649fe1bed  movq xmm1, r12
0000707649fe1bf2  lea r14, [rax+0x150]
0000707649fe1bf9  mov [r15+0xF8], r14
0000707649fe1c00  mov rax, [r15+0x50]
0000707649fe1c04  movups xmm15, [r13+rax*1]
0000707649fe1c0a  movaps [r15+0x120], xmm15
0000707649fe1c12  mov qword ptr [r15+0x48], 0x10
0000707649fe1c1a  xor eax, eax
0000707649fe1c1c  mov r14d, 0x10
0000707649fe1c22  mov r12d, 0x200
0000707649fe1c28  cmp r14, r12
0000707649fe1c2b  cmc
0000707649fe1c2c  lahf
0000707649fe1c2d  seto al
0000707649fe1c30  mov [r15+0x108], eax
0000707649fe1c37  pextrq rax, xmm15, 0x01
0000707649fe1c3e  movq xmm14, rax
0000707649fe1c43  movaps [r15+0x130], xmm14
0000707649fe1c4b  movq rax, xmm1
0000707649fe1c50  movq r14, xmm15
0000707649fe1c55  vmovq xmm1, rax
0000707649fe1c5a  vmovq xmm15, r14
0000707649fe1c5f  movaps xmm13, xmm1
0000707649fe1c63  addsd xmm13, xmm15
0000707649fe1c68  ucomisd xmm13, xmm13
0000707649fe1c6d  jp 0x0000707649FE1D86
0000707649fe1c73  movq xmm13, xmm13
0000707649fe1c78  movq rax, xmm13
0000707649fe1c7d  movq r14, xmm14
0000707649fe1c82  vmovq xmm1, rax
0000707649fe1c87  vmovq xmm15, r14
0000707649fe1c8c  movaps xmm14, xmm1
0000707649fe1c90  addsd xmm14, xmm15
0000707649fe1c95  ucomisd xmm14, xmm14
0000707649fe1c9a  jp 0x0000707649FE1DCE
0000707649fe1ca0  movq xmm14, xmm14
0000707649fe1ca5  movaps [r15+0x110], xmm14
0000707649fe1cad  mov eax, [r15+0x108]
0000707649fe1cb4  sahf
0000707649fe1cb5  jnz 0x0000707649FE1CE7
0000707649fe1cb7  cmp dword ptr [r15+0x318], 0x00
0000707649fe1cbf  jz 0x0000707649FE1FE0
0000707649fe1cc5  nop [rax+rax*1], ax
0000707649fe1cce  nop [rax+rax*1], eax
0000707649fe1cd6  mov eax, 0x410490
0000707649fe1cdb  mov [r15+0x100], rax
0000707649fe1ce2  jmp 0x0000707649DFE110
0000707649fe1ce7  cmp dword ptr [r15+0x318], 0x00
0000707649fe1cef  jz 0x0000707649FE1E20
0000707649fe1cf5  nop [rax+rax*1], ax
0000707649fe1cfe  nop [rax+rax*1], eax
0000707649fe1d06  mov eax, 0x410474
0000707649fe1d0b  mov [r15+0x100], rax
0000707649fe1d12  jmp 0x0000707649DFE110
0000707649fe1d17  int3
0000707649fe1d18  call 0x0000707649EE27E0
0000707649fe1d1d  jmp 0x0000707649FE1AC3
0000707649fe1d22  call 0x0000707649EE27E0
0000707649fe1d27  jmp 0x0000707649FE1AD6
0000707649fe1d2c  call 0x0000707649EE1570
0000707649fe1d31  jmp 0x0000707649FE1AE2
0000707649fe1d36  call 0x0000707649EE27E0
0000707649fe1d3b  jmp 0x0000707649FE1B1A
0000707649fe1d40  call 0x0000707649EE1570
0000707649fe1d45  jmp 0x0000707649FE1B26
0000707649fe1d4a  call 0x0000707649EE27E0
0000707649fe1d4f  jmp 0x0000707649FE1B5E
0000707649fe1d54  call 0x0000707649EE1570
0000707649fe1d59  jmp 0x0000707649FE1B6A
0000707649fe1d5e  call 0x0000707649EE27E0
0000707649fe1d63  jmp 0x0000707649FE1BA2
0000707649fe1d68  call 0x0000707649EE1570
0000707649fe1d6d  jmp 0x0000707649FE1BAE
0000707649fe1d72  call 0x0000707649EE27E0
0000707649fe1d77  jmp 0x0000707649FE1BED
0000707649fe1d7c  call 0x0000707649E0E760
0000707649fe1d81  jmp 0x0000707649FE1C0A
0000707649fe1d86  ucomisd xmm1, xmm15
0000707649fe1d8b  jp 0x0000707649FE1D9A
0000707649fe1d8d  movaps xmm13, [0x0000707649BFE060]
0000707649fe1d95  jmp 0x0000707649FE1C73
0000707649fe1d9a  vxorps xmm0, xmm1, xmm15
0000707649fe1d9f  pextrw eax, xmm0, 0x03
0000707649fe1da4  and eax, 0x7FF8
0000707649fe1da9  cmp eax, 0x08
0000707649fe1dac  jnz 0x0000707649FE1C73
0000707649fe1db2  movq rax, xmm15
0000707649fe1db7  shl rax, 0x0D
0000707649fe1dbb  jbe 0x0000707649FE1C73
0000707649fe1dc1  vorps xmm13, xmm15, [0x0000707649BFE070]
0000707649fe1dc9  jmp 0x0000707649FE1C73
0000707649fe1dce  ucomisd xmm1, xmm15
0000707649fe1dd3  jp 0x0000707649FE1DE2
0000707649fe1dd5  movaps xmm14, [0x0000707649BFE060]
0000707649fe1ddd  jmp 0x0000707649FE1CA0
0000707649fe1de2  vxorps xmm0, xmm1, xmm15
0000707649fe1de7  pextrw eax, xmm0, 0x03
0000707649fe1dec  and eax, 0x7FF8
0000707649fe1df1  cmp eax, 0x08
0000707649fe1df4  jnz 0x0000707649FE1CA0
0000707649fe1dfa  movq rax, xmm15
0000707649fe1dff  shl rax, 0x0D
0000707649fe1e03  jbe 0x0000707649FE1CA0
0000707649fe1e09  vorps xmm14, xmm15, [0x0000707649BFE070]
0000707649fe1e11  jmp 0x0000707649FE1CA0
0000707649fe1e16  int3
0000707649fe1e17  nop [rax+rax*1], ax
0000707649fe1e20  mov rax, [r15+0x48]
0000707649fe1e24  mov r14, [r15+0x50]
0000707649fe1e28  lea r12, [r14+rax*1]
0000707649fe1e2c  movups xmm1, [r13+r12*1]
0000707649fe1e32  movaps [r15+0x120], xmm1
0000707649fe1e3a  lea r14, [rax+0x10]
0000707649fe1e3e  mov [r15+0x48], r14
0000707649fe1e42  xor eax, eax
0000707649fe1e44  mov r12d, 0x200
0000707649fe1e4a  cmp r14, r12
0000707649fe1e4d  cmc
0000707649fe1e4e  lahf
0000707649fe1e4f  seto al
0000707649fe1e52  mov [r15+0x108], eax
0000707649fe1e59  pextrq rax, xmm1, 0x01
0000707649fe1e60  movq xmm15, rax
0000707649fe1e65  movaps [r15+0x130], xmm15
0000707649fe1e6d  movaps xmm14, [r15+0x110]
0000707649fe1e75  movq rax, xmm14
0000707649fe1e7a  movq r14, xmm1
0000707649fe1e7f  vmovq xmm1, rax
0000707649fe1e84  vmovq xmm14, r14
0000707649fe1e89  movaps xmm13, xmm1
0000707649fe1e8d  addsd xmm13, xmm14
0000707649fe1e92  ucomisd xmm13, xmm13
0000707649fe1e97  jp 0x0000707649FE1F4C
0000707649fe1e9d  movq xmm13, xmm13
0000707649fe1ea2  movq rax, xmm13
0000707649fe1ea7  movq r14, xmm15
0000707649fe1eac  vmovq xmm1, rax
0000707649fe1eb1  vmovq xmm15, r14
0000707649fe1eb6  movaps xmm14, xmm1
0000707649fe1eba  addsd xmm14, xmm15
0000707649fe1ebf  ucomisd xmm14, xmm14
0000707649fe1ec4  jp 0x0000707649FE1F94
0000707649fe1eca  movq xmm14, xmm14
0000707649fe1ecf  movaps [r15+0x110], xmm14
0000707649fe1ed7  mov eax, [r15+0x108]
0000707649fe1ede  sahf
0000707649fe1edf  jnz 0x0000707649FE1F11
0000707649fe1ee1  cmp dword ptr [r15+0x318], 0x00
0000707649fe1ee9  jz 0x0000707649FE1FE0
0000707649fe1eef  nop [rax+rax*1], ax
0000707649fe1ef8  nop [rax+rax*1], eax
0000707649fe1f00  mov eax, 0x410490
0000707649fe1f05  mov [r15+0x100], rax
0000707649fe1f0c  jmp 0x0000707649DFE110
0000707649fe1f11  cmp dword ptr [r15+0x318], 0x00
0000707649fe1f19  jz 0x0000707649FE1E20
0000707649fe1f1f  nop [rax+rax*1], ax
0000707649fe1f28  nop [rax+rax*1], eax
0000707649fe1f30  mov eax, 0x410474
0000707649fe1f35  mov [r15+0x100], rax
0000707649fe1f3c  jmp 0x0000707649DFE110
0000707649fe1f41  int3
0000707649fe1f42  call 0x0000707649EB52F0
0000707649fe1f47  jmp 0x0000707649FE1E32
0000707649fe1f4c  ucomisd xmm1, xmm14
0000707649fe1f51  jp 0x0000707649FE1F60
0000707649fe1f53  movaps xmm13, [0x0000707649BFE060]
0000707649fe1f5b  jmp 0x0000707649FE1E9D
0000707649fe1f60  vxorps xmm0, xmm1, xmm14
0000707649fe1f65  pextrw eax, xmm0, 0x03
0000707649fe1f6a  and eax, 0x7FF8
0000707649fe1f6f  cmp eax, 0x08
0000707649fe1f72  jnz 0x0000707649FE1E9D
0000707649fe1f78  movq rax, xmm14
0000707649fe1f7d  shl rax, 0x0D
0000707649fe1f81  jbe 0x0000707649FE1E9D
0000707649fe1f87  vorps xmm13, xmm14, [0x0000707649BFE070]
0000707649fe1f8f  jmp 0x0000707649FE1E9D
0000707649fe1f94  ucomisd xmm1, xmm15
0000707649fe1f99  jp 0x0000707649FE1FA8
0000707649fe1f9b  movaps xmm14, [0x0000707649BFE060]
0000707649fe1fa3  jmp 0x0000707649FE1ECA
0000707649fe1fa8  vxorps xmm0, xmm1, xmm15
0000707649fe1fad  pextrw eax, xmm0, 0x03
0000707649fe1fb2  and eax, 0x7FF8
0000707649fe1fb7  cmp eax, 0x08
0000707649fe1fba  jnz 0x0000707649FE1ECA
0000707649fe1fc0  movq rax, xmm15
0000707649fe1fc5  shl rax, 0x0D
0000707649fe1fc9  jbe 0x0000707649FE1ECA
0000707649fe1fcf  vorps xmm14, xmm15, [0x0000707649BFE070]
0000707649fe1fd7  jmp 0x0000707649FE1ECA
0000707649fe1fdc  int3
0000707649fe1fdd  nop [rax], eax
0000707649fe1fe0  mov rax, [r15+0x40]
0000707649fe1fe4  lea r14, [rax+0x510]
0000707649fe1feb  movaps xmm1, [r15+0x110]
0000707649fe1ff3  movq rax, xmm1
0000707649fe1ff8  mov [r13+r14*1], rax
0000707649fe1ffd  mov rax, [r15+0xF0]
0000707649fe2004  mov [r15+0x100], rax
0000707649fe200b  jmp 0x0000707649FCE5C0
0000707649fe2010  int3
0000707649fe2011  call 0x0000707649ED5EB0
0000707649fe2016  jmp 0x0000707649FE1FFD
0000707649fe201b  int3
0000707649fe201c  nop [rax], eax
0000707649fe2020  mov qword ptr [r15+0x100], 0x04
0000707649fe202b  mov esi, 0x00
0000707649fe2030  mov edx, 0x09
0000707649fe2035  mov rdi, 0x7FFCF8055FA0
0000707649fe203f  mov rax, 0x59CB0AEE7970
0000707649fe2049  call rax
0000707649fe204b  cmp dword ptr [r15+0x318], 0x00
0000707649fe2053  jnz 0x0000707649DFE110
0000707649fe2059  jmp 0x0000707649DFE0A0
0000707649fe205e  int3
0000707649fe205f  int3
