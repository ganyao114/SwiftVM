00007a40685ce69b  nop [rax+rax*1], eax
00007a40685ce6a0  vmovaps xmm1, [0x00007A40681FE010]
00007a40685ce6a8  movq xmm1, xmm1
00007a40685ce6ac  movaps [r15+0x110], xmm1
00007a40685ce6b4  vmovaps xmm1, [0x00007A40681FE020]
00007a40685ce6bc  movq xmm1, xmm1
00007a40685ce6c0  movaps [r15+0x120], xmm1
00007a40685ce6c8  mov eax, 0x4204C0
00007a40685ce6cd  mov r14, [r13+rax*1]
00007a40685ce6d2  movq xmm1, r14
00007a40685ce6d7  movaps [r15+0x130], xmm1
00007a40685ce6df  vmovaps xmm1, [0x00007A40681FE030]
00007a40685ce6e7  vpbroadcastq xmm1, xmm1
00007a40685ce6ec  movaps [r15+0x140], xmm1
00007a40685ce6f4  mov qword ptr [r15+0x40], 0x02
00007a40685ce6fc  vmovaps xmm15, [0x00007A40681FE040]
00007a40685ce704  movq xmm15, xmm15
00007a40685ce709  movaps [r15+0x150], xmm15
00007a40685ce711  mov qword ptr [r15+0x58], 0x420000
00007a40685ce719  vmovaps xmm15, [0x00007A40681FE050]
00007a40685ce721  vpbroadcastq xmm15, xmm15
00007a40685ce726  movaps [r15+0x160], xmm15
00007a40685ce72e  mov rax, [r15+0x40]
00007a40685ce732  vmovq xmm14, rax
00007a40685ce737  vpbroadcastq xmm14, xmm14
00007a40685ce73c  movaps [r15+0x170], xmm14
00007a40685ce744  mov eax, 0x4204D0
00007a40685ce749  movups xmm13, [r13+rax*1]
00007a40685ce74f  mov qword ptr [r15+0x40], 0x430518
00007a40685ce757  mov qword ptr [r15+0x50], 0x430720
00007a40685ce75f  vpmovqd xmm12, xmm13
00007a40685ce765  pxor xmm11, xmm11
00007a40685ce76a  punpcklqdq xmm12, xmm11
00007a40685ce76f  movaps [r15+0x210], xmm12
00007a40685ce777  movq xmm12, qword ptr [r15+0x120]
00007a40685ce780  movq xmm11, qword ptr [r15+0x130]
00007a40685ce789  psubd xmm12, xmm11
00007a40685ce78e  movq xmm12, xmm12
00007a40685ce793  paddq xmm13, xmm14
00007a40685ce798  movaps [r15+0x180], xmm13
00007a40685ce7a0  movq xmm14, qword ptr [r15+0x150]
00007a40685ce7a9  paddd xmm11, xmm14
00007a40685ce7ae  movq xmm11, xmm11
00007a40685ce7b3  movq xmm11, xmm11
00007a40685ce7b8  movaps [r15+0x130], xmm11
00007a40685ce7c0  pmovzxdq xmm12, xmm12
00007a40685ce7c6  psllq xmm12, 0x00
00007a40685ce7cc  movq xmm14, qword ptr [r15+0x210]
00007a40685ce7d5  movq xmm13, qword ptr [r15+0x110]
00007a40685ce7de  paddd xmm14, xmm13
00007a40685ce7e3  movq xmm14, xmm14
00007a40685ce7e8  vcvtuqq2pd xmm12, xmm12
00007a40685ce7ee  pmovzxdq xmm14, xmm14
00007a40685ce7f4  psllq xmm14, 0x00
00007a40685ce7fa  vcvtuqq2pd xmm14, xmm14
00007a40685ce800  movaps xmm13, xmm12
00007a40685ce804  mulpd xmm13, xmm1
00007a40685ce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007a40685ce80f  ptest xmm11, xmm11
00007a40685ce815  jnz 0x00007A40685CE8FF
00007a40685ce81b  movaps [r15+0x220], xmm13
00007a40685ce823  mov eax, 0x430720
00007a40685ce828  movups [r13+rax*1], xmm13
00007a40685ce82e  movaps xmm1, xmm14
00007a40685ce832  mulpd xmm1, xmm15
00007a40685ce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007a40685ce83c  ptest xmm13, xmm13
00007a40685ce842  jnz 0x00007A40685CEA4C
00007a40685ce848  movaps [r15+0x210], xmm1
00007a40685ce850  mov eax, 0x430518
00007a40685ce855  movups [r13+rax*1], xmm1
00007a40685ce85b  mov qword ptr [r15+0x48], 0x10
00007a40685ce863  xor eax, eax
00007a40685ce865  mov r14d, 0x10
00007a40685ce86b  mov r12d, 0x200
00007a40685ce871  cmp r14, r12
00007a40685ce874  cmc
00007a40685ce875  lahf
00007a40685ce876  seto al
00007a40685ce879  mov [r15+0x108], eax
00007a40685ce880  mov eax, [r15+0x108]
00007a40685ce887  sahf
00007a40685ce888  jnz 0x00007A40685CE8BA
00007a40685ce88a  cmp dword ptr [r15+0x318], 0x00
00007a40685ce892  jz 0x00007A40685CEFF0
00007a40685ce898  nop [rax+rax*1], ax
00007a40685ce8a1  nop [rax+rax*1], eax
00007a40685ce8a9  mov eax, 0x4101EC
00007a40685ce8ae  mov [r15+0x100], rax
00007a40685ce8b5  jmp 0x00007A40683FE110
00007a40685ce8ba  cmp dword ptr [r15+0x318], 0x00
00007a40685ce8c2  jz 0x00007A40685CEBA0
00007a40685ce8c8  nop [rax+rax*1], ax
00007a40685ce8d1  nop [rax+rax*1], eax
00007a40685ce8d9  mov eax, 0x4101AC
00007a40685ce8de  mov [r15+0x100], rax
00007a40685ce8e5  jmp 0x00007A40683FE110
00007a40685ce8ea  int3
00007a40685ce8eb  call 0x00007A406840DC20
00007a40685ce8f0  jmp 0x00007A40685CE6D2
00007a40685ce8f5  call 0x00007A406840C260
00007a40685ce8fa  jmp 0x00007A40685CE74F
00007a40685ce8ff  sub rsp, 0x08
00007a40685ce903  push rax
00007a40685ce904  push rcx
00007a40685ce905  push rdx
00007a40685ce906  push rdi
00007a40685ce907  push rsi
00007a40685ce908  push r8
00007a40685ce90a  push r9
00007a40685ce90c  push r10
00007a40685ce90e  push r11
00007a40685ce910  sub rsp, 0xF0
00007a40685ce917  vmovaps [rsp], xmm0
00007a40685ce91c  vmovaps [rsp+0x10], xmm1
00007a40685ce922  vmovaps [rsp+0x20], xmm2
00007a40685ce928  vmovaps [rsp+0x30], xmm3
00007a40685ce92e  vmovaps [rsp+0x40], xmm4
00007a40685ce934  vmovaps [rsp+0x50], xmm5
00007a40685ce93a  vmovaps [rsp+0x60], xmm6
00007a40685ce940  vmovaps [rsp+0x70], xmm7
00007a40685ce946  vmovaps [rsp+0x80], xmm8
00007a40685ce94f  vmovaps [rsp+0x90], xmm9
00007a40685ce958  vmovaps [rsp+0xA0], xmm10
00007a40685ce961  vmovaps [rsp+0xB0], xmm11
00007a40685ce96a  vmovaps [rsp+0xC0], xmm12
00007a40685ce973  vmovaps [rsp+0xD0], xmm14
00007a40685ce97c  vmovaps [rsp+0xE0], xmm15
00007a40685ce985  sub rsp, 0x30
00007a40685ce989  movaps [rsp], xmm13
00007a40685ce98e  movaps [rsp+0x10], xmm12
00007a40685ce994  movaps [rsp+0x20], xmm1
00007a40685ce999  lea rdi, [rsp]
00007a40685ce99d  mov esi, 0x00
00007a40685ce9a2  mov rax, 0x56F679577530
00007a40685ce9ac  call rax
00007a40685ce9ae  movaps xmm13, [rsp]
00007a40685ce9b3  add rsp, 0x30
00007a40685ce9b7  vmovaps xmm0, [rsp]
00007a40685ce9bc  vmovaps xmm1, [rsp+0x10]
00007a40685ce9c2  vmovaps xmm2, [rsp+0x20]
00007a40685ce9c8  vmovaps xmm3, [rsp+0x30]
00007a40685ce9ce  vmovaps xmm4, [rsp+0x40]
00007a40685ce9d4  vmovaps xmm5, [rsp+0x50]
00007a40685ce9da  vmovaps xmm6, [rsp+0x60]
00007a40685ce9e0  vmovaps xmm7, [rsp+0x70]
00007a40685ce9e6  vmovaps xmm8, [rsp+0x80]
00007a40685ce9ef  vmovaps xmm9, [rsp+0x90]
00007a40685ce9f8  vmovaps xmm10, [rsp+0xA0]
00007a40685cea01  vmovaps xmm11, [rsp+0xB0]
00007a40685cea0a  vmovaps xmm12, [rsp+0xC0]
00007a40685cea13  vmovaps xmm14, [rsp+0xD0]
00007a40685cea1c  vmovaps xmm15, [rsp+0xE0]
00007a40685cea25  add rsp, 0xF0
00007a40685cea2c  pop r11
00007a40685cea2e  pop r10
00007a40685cea30  pop r9
00007a40685cea32  pop r8
00007a40685cea34  pop rsi
00007a40685cea35  pop rdi
00007a40685cea36  pop rdx
00007a40685cea37  pop rcx
00007a40685cea38  pop rax
00007a40685cea39  add rsp, 0x08
00007a40685cea3d  jmp 0x00007A40685CE81B
00007a40685cea42  call 0x00007A406840C380
00007a40685cea47  jmp 0x00007A40685CE82E
00007a40685cea4c  sub rsp, 0x08
00007a40685cea50  push rax
00007a40685cea51  push rcx
00007a40685cea52  push rdx
00007a40685cea53  push rdi
00007a40685cea54  push rsi
00007a40685cea55  push r8
00007a40685cea57  push r9
00007a40685cea59  push r10
00007a40685cea5b  push r11
00007a40685cea5d  sub rsp, 0xF0
00007a40685cea64  vmovaps [rsp], xmm0
00007a40685cea69  vmovaps [rsp+0x10], xmm2
00007a40685cea6f  vmovaps [rsp+0x20], xmm3
00007a40685cea75  vmovaps [rsp+0x30], xmm4
00007a40685cea7b  vmovaps [rsp+0x40], xmm5
00007a40685cea81  vmovaps [rsp+0x50], xmm6
00007a40685cea87  vmovaps [rsp+0x60], xmm7
00007a40685cea8d  vmovaps [rsp+0x70], xmm8
00007a40685cea93  vmovaps [rsp+0x80], xmm9
00007a40685cea9c  vmovaps [rsp+0x90], xmm10
00007a40685ceaa5  vmovaps [rsp+0xA0], xmm11
00007a40685ceaae  vmovaps [rsp+0xB0], xmm12
00007a40685ceab7  vmovaps [rsp+0xC0], xmm13
00007a40685ceac0  vmovaps [rsp+0xD0], xmm14
00007a40685ceac9  vmovaps [rsp+0xE0], xmm15
00007a40685cead2  sub rsp, 0x30
00007a40685cead6  movaps [rsp], xmm1
00007a40685ceada  movaps [rsp+0x10], xmm14
00007a40685ceae0  movaps [rsp+0x20], xmm15
00007a40685ceae6  lea rdi, [rsp]
00007a40685ceaea  mov esi, 0x00
00007a40685ceaef  mov rax, 0x56F679577530
00007a40685ceaf9  call rax
00007a40685ceafb  movaps xmm1, [rsp]
00007a40685ceaff  add rsp, 0x30
00007a40685ceb03  vmovaps xmm0, [rsp]
00007a40685ceb08  vmovaps xmm2, [rsp+0x10]
00007a40685ceb0e  vmovaps xmm3, [rsp+0x20]
00007a40685ceb14  vmovaps xmm4, [rsp+0x30]
00007a40685ceb1a  vmovaps xmm5, [rsp+0x40]
00007a40685ceb20  vmovaps xmm6, [rsp+0x50]
00007a40685ceb26  vmovaps xmm7, [rsp+0x60]
00007a40685ceb2c  vmovaps xmm8, [rsp+0x70]
00007a40685ceb32  vmovaps xmm9, [rsp+0x80]
00007a40685ceb3b  vmovaps xmm10, [rsp+0x90]
00007a40685ceb44  vmovaps xmm11, [rsp+0xA0]
00007a40685ceb4d  vmovaps xmm12, [rsp+0xB0]
00007a40685ceb56  vmovaps xmm13, [rsp+0xC0]
00007a40685ceb5f  vmovaps xmm14, [rsp+0xD0]
00007a40685ceb68  vmovaps xmm15, [rsp+0xE0]
00007a40685ceb71  add rsp, 0xF0
00007a40685ceb78  pop r11
00007a40685ceb7a  pop r10
00007a40685ceb7c  pop r9
00007a40685ceb7e  pop r8
00007a40685ceb80  pop rsi
00007a40685ceb81  pop rdi
00007a40685ceb82  pop rdx
00007a40685ceb83  pop rcx
00007a40685ceb84  pop rax
00007a40685ceb85  add rsp, 0x08
00007a40685ceb89  jmp 0x00007A40685CE848
00007a40685ceb8e  call 0x00007A40683FF540
00007a40685ceb93  jmp 0x00007A40685CE85B
00007a40685ceb98  int3
00007a40685ceb99  nop [rax], eax
00007a40685ceba0  movaps xmm1, [r15+0x180]
00007a40685ceba8  vpmovqd xmm15, xmm1
00007a40685cebae  pxor xmm14, xmm14
00007a40685cebb3  punpcklqdq xmm15, xmm14
00007a40685cebb8  movaps [r15+0x210], xmm15
00007a40685cebc0  movq xmm15, qword ptr [r15+0x120]
00007a40685cebc9  movq xmm14, qword ptr [r15+0x130]
00007a40685cebd2  psubd xmm15, xmm14
00007a40685cebd7  movq xmm15, xmm15
00007a40685cebdc  movaps xmm13, [r15+0x170]
00007a40685cebe4  paddq xmm1, xmm13
00007a40685cebe9  movaps [r15+0x180], xmm1
00007a40685cebf1  movq xmm1, qword ptr [r15+0x150]
00007a40685cebfa  paddd xmm14, xmm1
00007a40685cebff  movq xmm14, xmm14
00007a40685cec04  movq xmm14, xmm14
00007a40685cec09  movaps [r15+0x130], xmm14
00007a40685cec11  pmovzxdq xmm15, xmm15
00007a40685cec17  psllq xmm15, 0x00
00007a40685cec1d  movq xmm1, qword ptr [r15+0x210]
00007a40685cec26  movq xmm14, qword ptr [r15+0x110]
00007a40685cec2f  paddd xmm1, xmm14
00007a40685cec34  movq xmm1, xmm1
00007a40685cec38  vcvtuqq2pd xmm15, xmm15
00007a40685cec3e  pmovzxdq xmm1, xmm1
00007a40685cec43  psllq xmm1, 0x00
00007a40685cec48  vcvtuqq2pd xmm1, xmm1
00007a40685cec4e  movaps xmm14, [r15+0x140]
00007a40685cec56  movaps xmm13, xmm15
00007a40685cec5a  mulpd xmm13, xmm14
00007a40685cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007a40685cec65  ptest xmm12, xmm12
00007a40685cec6b  jnz 0x00007A40685CED4E
00007a40685cec71  movaps [r15+0x220], xmm13
00007a40685cec79  mov rax, [r15+0x48]
00007a40685cec7d  mov r14, [r15+0x50]
00007a40685cec81  lea r12, [r14+rax*1]
00007a40685cec85  movups [r13+r12*1], xmm13
00007a40685cec8b  movaps xmm15, [r15+0x160]
00007a40685cec93  movaps xmm14, xmm1
00007a40685cec97  mulpd xmm14, xmm15
00007a40685cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007a40685ceca2  ptest xmm13, xmm13
00007a40685ceca8  jnz 0x00007A40685CEE9C
00007a40685cecae  movaps [r15+0x210], xmm14
00007a40685cecb6  mov r14, [r15+0x40]
00007a40685cecba  lea r12, [r14+rax*1]
00007a40685cecbe  movups [r13+r12*1], xmm14
00007a40685cecc4  lea r14, [rax+0x10]
00007a40685cecc8  mov [r15+0x48], r14
00007a40685ceccc  xor eax, eax
00007a40685cecce  mov r12d, 0x200
00007a40685cecd4  cmp r14, r12
00007a40685cecd7  cmc
00007a40685cecd8  lahf
00007a40685cecd9  seto al
00007a40685cecdc  mov [r15+0x108], eax
00007a40685cece3  mov eax, [r15+0x108]
00007a40685cecea  sahf
00007a40685ceceb  jnz 0x00007A40685CED1D
00007a40685ceced  cmp dword ptr [r15+0x318], 0x00
00007a40685cecf5  jz 0x00007A40685CEFF0
00007a40685cecfb  nop [rax+rax*1], ax
00007a40685ced04  nop [rax+rax*1], eax
00007a40685ced0c  mov eax, 0x4101EC
00007a40685ced11  mov [r15+0x100], rax
00007a40685ced18  jmp 0x00007A40683FE110
00007a40685ced1d  cmp dword ptr [r15+0x318], 0x00
00007a40685ced25  jz 0x00007A40685CEBA0
00007a40685ced2b  nop [rax+rax*1], ax
00007a40685ced34  nop [rax+rax*1], eax
00007a40685ced3c  mov eax, 0x4101AC
00007a40685ced41  mov [r15+0x100], rax
00007a40685ced48  jmp 0x00007A40683FE110
00007a40685ced4d  int3
00007a40685ced4e  sub rsp, 0x08
00007a40685ced52  push rax
00007a40685ced53  push rcx
00007a40685ced54  push rdx
00007a40685ced55  push rdi
00007a40685ced56  push rsi
00007a40685ced57  push r8
00007a40685ced59  push r9
00007a40685ced5b  push r10
00007a40685ced5d  push r11
00007a40685ced5f  sub rsp, 0xF0
00007a40685ced66  vmovaps [rsp], xmm0
00007a40685ced6b  vmovaps [rsp+0x10], xmm1
00007a40685ced71  vmovaps [rsp+0x20], xmm2
00007a40685ced77  vmovaps [rsp+0x30], xmm3
00007a40685ced7d  vmovaps [rsp+0x40], xmm4
00007a40685ced83  vmovaps [rsp+0x50], xmm5
00007a40685ced89  vmovaps [rsp+0x60], xmm6
00007a40685ced8f  vmovaps [rsp+0x70], xmm7
00007a40685ced95  vmovaps [rsp+0x80], xmm8
00007a40685ced9e  vmovaps [rsp+0x90], xmm9
00007a40685ceda7  vmovaps [rsp+0xA0], xmm10
00007a40685cedb0  vmovaps [rsp+0xB0], xmm11
00007a40685cedb9  vmovaps [rsp+0xC0], xmm12
00007a40685cedc2  vmovaps [rsp+0xD0], xmm14
00007a40685cedcb  vmovaps [rsp+0xE0], xmm15
00007a40685cedd4  sub rsp, 0x30
00007a40685cedd8  movaps [rsp], xmm13
00007a40685ceddd  movaps [rsp+0x10], xmm15
00007a40685cede3  movaps [rsp+0x20], xmm14
00007a40685cede9  lea rdi, [rsp]
00007a40685ceded  mov esi, 0x00
00007a40685cedf2  mov rax, 0x56F679577530
00007a40685cedfc  call rax
00007a40685cedfe  movaps xmm13, [rsp]
00007a40685cee03  add rsp, 0x30
00007a40685cee07  vmovaps xmm0, [rsp]
00007a40685cee0c  vmovaps xmm1, [rsp+0x10]
00007a40685cee12  vmovaps xmm2, [rsp+0x20]
00007a40685cee18  vmovaps xmm3, [rsp+0x30]
00007a40685cee1e  vmovaps xmm4, [rsp+0x40]
00007a40685cee24  vmovaps xmm5, [rsp+0x50]
00007a40685cee2a  vmovaps xmm6, [rsp+0x60]
00007a40685cee30  vmovaps xmm7, [rsp+0x70]
00007a40685cee36  vmovaps xmm8, [rsp+0x80]
00007a40685cee3f  vmovaps xmm9, [rsp+0x90]
00007a40685cee48  vmovaps xmm10, [rsp+0xA0]
00007a40685cee51  vmovaps xmm11, [rsp+0xB0]
00007a40685cee5a  vmovaps xmm12, [rsp+0xC0]
00007a40685cee63  vmovaps xmm14, [rsp+0xD0]
00007a40685cee6c  vmovaps xmm15, [rsp+0xE0]
00007a40685cee75  add rsp, 0xF0
00007a40685cee7c  pop r11
00007a40685cee7e  pop r10
00007a40685cee80  pop r9
00007a40685cee82  pop r8
00007a40685cee84  pop rsi
00007a40685cee85  pop rdi
00007a40685cee86  pop rdx
00007a40685cee87  pop rcx
00007a40685cee88  pop rax
00007a40685cee89  add rsp, 0x08
00007a40685cee8d  jmp 0x00007A40685CEC71
00007a40685cee92  call 0x00007A40684C2240
00007a40685cee97  jmp 0x00007A40685CEC8B
00007a40685cee9c  sub rsp, 0x08
00007a40685ceea0  push rax
00007a40685ceea1  push rcx
00007a40685ceea2  push rdx
00007a40685ceea3  push rdi
00007a40685ceea4  push rsi
00007a40685ceea5  push r8
00007a40685ceea7  push r9
00007a40685ceea9  push r10
00007a40685ceeab  push r11
00007a40685ceead  sub rsp, 0xF0
00007a40685ceeb4  vmovaps [rsp], xmm0
00007a40685ceeb9  vmovaps [rsp+0x10], xmm1
00007a40685ceebf  vmovaps [rsp+0x20], xmm2
00007a40685ceec5  vmovaps [rsp+0x30], xmm3
00007a40685ceecb  vmovaps [rsp+0x40], xmm4
00007a40685ceed1  vmovaps [rsp+0x50], xmm5
00007a40685ceed7  vmovaps [rsp+0x60], xmm6
00007a40685ceedd  vmovaps [rsp+0x70], xmm7
00007a40685ceee3  vmovaps [rsp+0x80], xmm8
00007a40685ceeec  vmovaps [rsp+0x90], xmm9
00007a40685ceef5  vmovaps [rsp+0xA0], xmm10
00007a40685ceefe  vmovaps [rsp+0xB0], xmm11
00007a40685cef07  vmovaps [rsp+0xC0], xmm12
00007a40685cef10  vmovaps [rsp+0xD0], xmm13
00007a40685cef19  vmovaps [rsp+0xE0], xmm15
00007a40685cef22  sub rsp, 0x30
00007a40685cef26  movaps [rsp], xmm14
00007a40685cef2b  movaps [rsp+0x10], xmm1
00007a40685cef30  movaps [rsp+0x20], xmm15
00007a40685cef36  lea rdi, [rsp]
00007a40685cef3a  mov esi, 0x00
00007a40685cef3f  mov rax, 0x56F679577530
00007a40685cef49  call rax
00007a40685cef4b  movaps xmm14, [rsp]
00007a40685cef50  add rsp, 0x30
00007a40685cef54  vmovaps xmm0, [rsp]
00007a40685cef59  vmovaps xmm1, [rsp+0x10]
00007a40685cef5f  vmovaps xmm2, [rsp+0x20]
00007a40685cef65  vmovaps xmm3, [rsp+0x30]
00007a40685cef6b  vmovaps xmm4, [rsp+0x40]
00007a40685cef71  vmovaps xmm5, [rsp+0x50]
00007a40685cef77  vmovaps xmm6, [rsp+0x60]
00007a40685cef7d  vmovaps xmm7, [rsp+0x70]
00007a40685cef83  vmovaps xmm8, [rsp+0x80]
00007a40685cef8c  vmovaps xmm9, [rsp+0x90]
00007a40685cef95  vmovaps xmm10, [rsp+0xA0]
00007a40685cef9e  vmovaps xmm11, [rsp+0xB0]
00007a40685cefa7  vmovaps xmm12, [rsp+0xC0]
00007a40685cefb0  vmovaps xmm13, [rsp+0xD0]
00007a40685cefb9  vmovaps xmm15, [rsp+0xE0]
00007a40685cefc2  add rsp, 0xF0
00007a40685cefc9  pop r11
00007a40685cefcb  pop r10
00007a40685cefcd  pop r9
00007a40685cefcf  pop r8
00007a40685cefd1  pop rsi
00007a40685cefd2  pop rdi
00007a40685cefd3  pop rdx
00007a40685cefd4  pop rcx
00007a40685cefd5  pop rax
00007a40685cefd6  add rsp, 0x08
00007a40685cefda  jmp 0x00007A40685CECAE
00007a40685cefdf  call 0x00007A40684C34C0
00007a40685cefe4  jmp 0x00007A40685CECC4
00007a40685cefe9  int3
00007a40685cefea  nop [rax+rax*1], ax
00007a40685ceff0  mov rax, [r15+0xF8]
00007a40685ceff7  lea r14, [rax-0x150]
00007a40685ceffe  mov [r15+0xF8], r14
00007a40685cf005  mov rax, [r15+0x50]
00007a40685cf009  lea r12, [rax+0x80]
00007a40685cf010  movups xmm1, [r13+r12*1]
00007a40685cf016  lea r12, [rax+0x90]
00007a40685cf01d  movups xmm15, [r13+r12*1]
00007a40685cf023  mov qword ptr [r15+0x48], 0x00
00007a40685cf02b  lea r12, [rax+0x40]
00007a40685cf02f  movups xmm14, [r13+r12*1]
00007a40685cf035  lea r12, [rax+0x50]
00007a40685cf039  movups xmm13, [r13+r12*1]
00007a40685cf03f  lea r12, [r14+0x120]
00007a40685cf046  movq xmm12, qword ptr [r15+0x1C0]
00007a40685cf04f  movq xmm11, qword ptr [r15+0x1B0]
00007a40685cf058  movq r11, xmm12
00007a40685cf05d  movq r10, xmm11
00007a40685cf062  mov [r13+r12*1], r11
00007a40685cf067  lea r12, [r14+0x128]
00007a40685cf06e  mov [r13+r12*1], r10
00007a40685cf073  vxorps xmm12, xmm12, xmm12
00007a40685cf078  vpbroadcastq xmm12, xmm12
00007a40685cf07d  lea r12, [r14+0x100]
00007a40685cf084  movq xmm11, qword ptr [r15+0x200]
00007a40685cf08d  movq xmm10, qword ptr [r15+0x1F0]
00007a40685cf096  movq r11, xmm11
00007a40685cf09b  movq r10, xmm10
00007a40685cf0a0  mov [r13+r12*1], r11
00007a40685cf0a5  lea r12, [r14+0x108]
00007a40685cf0ac  mov [r13+r12*1], r10
00007a40685cf0b1  lea r12, [r14+0xE0]
00007a40685cf0b8  movups [r13+r12*1], xmm15
00007a40685cf0be  lea r12, [r14+0xF0]
00007a40685cf0c5  movups [r13+r12*1], xmm1
00007a40685cf0cb  lea r12, [rax+0xC0]
00007a40685cf0d2  movups xmm1, [r13+r12*1]
00007a40685cf0d8  lea r12, [rax+0xD0]
00007a40685cf0df  movups xmm15, [r13+r12*1]
00007a40685cf0e5  lea r12, [r14+0x110]
00007a40685cf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007a40685cf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007a40685cf0fe  movq r11, xmm11
00007a40685cf103  movq r10, xmm10
00007a40685cf108  mov [r13+r12*1], r11
00007a40685cf10d  lea r12, [r14+0x118]
00007a40685cf114  mov [r13+r12*1], r10
00007a40685cf119  movups xmm11, [r13+rax*1]
00007a40685cf11f  lea r12, [rax+0x10]
00007a40685cf123  movups xmm10, [r13+r12*1]
00007a40685cf129  lea r12, [r14+0x130]
00007a40685cf130  movq xmm9, qword ptr [r15+0x1A0]
00007a40685cf139  movq xmm8, qword ptr [r15+0x190]
00007a40685cf142  movq r11, xmm9
00007a40685cf147  movq r10, xmm8
00007a40685cf14c  mov [r13+r12*1], r11
00007a40685cf151  lea r12, [r14+0x138]
00007a40685cf158  mov [r13+r12*1], r10
00007a40685cf15d  lea r12, [rax+0x140]
00007a40685cf164  movups xmm9, [r13+r12*1]
00007a40685cf16a  lea r12, [rax+0x150]
00007a40685cf171  movups xmm8, [r13+r12*1]
00007a40685cf177  lea r12, [r14+0xC0]
00007a40685cf17e  movups [r13+r12*1], xmm15
00007a40685cf184  lea r12, [r14+0xD0]
00007a40685cf18b  movups [r13+r12*1], xmm1
00007a40685cf191  lea r12, [rax+0x100]
00007a40685cf198  movups xmm1, [r13+r12*1]
00007a40685cf19e  lea r12, [rax+0x110]
00007a40685cf1a5  movups xmm15, [r13+r12*1]
00007a40685cf1ab  lea r12, [r14+0x140]
00007a40685cf1b2  mov r11, [r15+0xE8]
00007a40685cf1b9  mov [r13+r12*1], r11
00007a40685cf1be  lea r12, [rax+0x180]
00007a40685cf1c5  movups xmm7, [r13+r12*1]
00007a40685cf1cb  lea r12, [rax+0x190]
00007a40685cf1d2  movups xmm6, [r13+r12*1]
00007a40685cf1d8  lea r12, [rax+0x1C0]
00007a40685cf1df  movups xmm5, [r13+r12*1]
00007a40685cf1e5  lea r12, [rax+0x1D0]
00007a40685cf1ec  movups xmm4, [r13+r12*1]
00007a40685cf1f2  lea r12, [r14+0x20]
00007a40685cf1f6  movups [r13+r12*1], xmm1
00007a40685cf1fc  lea r12, [r14+0x30]
00007a40685cf200  movups [r13+r12*1], xmm13
00007a40685cf206  lea r12, [rax+0x60]
00007a40685cf20a  movups xmm1, [r13+r12*1]
00007a40685cf210  lea r12, [rax+0x70]
00007a40685cf214  movups xmm13, [r13+r12*1]
00007a40685cf21a  lea r12, [rax+0x20]
00007a40685cf21e  movups xmm3, [r13+r12*1]
00007a40685cf224  lea r12, [rax+0x30]
00007a40685cf228  movups xmm2, [r13+r12*1]
00007a40685cf22e  movaps [r15+0x1F0], xmm2
00007a40685cf236  lea r12, [r14+0x60]
00007a40685cf23a  movups [r13+r12*1], xmm11
00007a40685cf240  lea r12, [r14+0x70]
00007a40685cf244  movups [r13+r12*1], xmm5
00007a40685cf24a  lea r12, [rax+0xE0]
00007a40685cf251  movups xmm11, [r13+r12*1]
00007a40685cf257  lea r12, [rax+0xF0]
00007a40685cf25e  movups xmm5, [r13+r12*1]
00007a40685cf264  lea r12, [r14+0xA0]
00007a40685cf26b  movups [r13+r12*1], xmm13
00007a40685cf271  lea r12, [r14+0xB0]
00007a40685cf278  movups [r13+r12*1], xmm1
00007a40685cf27e  lea r12, [rax+0xA0]
00007a40685cf285  movups xmm1, [r13+r12*1]
00007a40685cf28b  lea r12, [rax+0xB0]
00007a40685cf292  movups xmm13, [r13+r12*1]
00007a40685cf298  lea r12, [rax+0x120]
00007a40685cf29f  vmovaps [rsp+0x10], xmm1
00007a40685cf2a5  movups xmm1, [r13+r12*1]
00007a40685cf2ab  lea r12, [rax+0x130]
00007a40685cf2b2  vmovaps [rsp+0x20], xmm1
00007a40685cf2b8  movups xmm1, [r13+r12*1]
00007a40685cf2be  lea r12, [rax+0x160]
00007a40685cf2c5  vmovaps [rsp+0x30], xmm1
00007a40685cf2cb  movups xmm1, [r13+r12*1]
00007a40685cf2d1  lea r12, [rax+0x170]
00007a40685cf2d8  vmovaps [rsp+0x40], xmm1
00007a40685cf2de  movups xmm1, [r13+r12*1]
00007a40685cf2e4  movaps [r15+0x2B0], xmm1
00007a40685cf2ec  lea r12, [r14+0x80]
00007a40685cf2f3  movups [r13+r12*1], xmm13
00007a40685cf2f9  lea r12, [r14+0x90]
00007a40685cf300  vmovaps xmm13, [rsp+0x10]
00007a40685cf306  movups [r13+r12*1], xmm13
00007a40685cf30c  lea r12, [rax+0x1A0]
00007a40685cf313  movups xmm13, [r13+r12*1]
00007a40685cf319  lea r12, [rax+0x1B0]
00007a40685cf320  vmovaps [rsp+0x10], xmm1
00007a40685cf326  movups xmm1, [r13+r12*1]
00007a40685cf32c  movaps [r15+0x290], xmm13
00007a40685cf334  movaps [r15+0x1E0], xmm1
00007a40685cf33c  lea r12, [rax+0x1E0]
00007a40685cf343  vmovaps [rsp+0x50], xmm1
00007a40685cf349  movups xmm1, [r13+r12*1]
00007a40685cf34f  lea r12, [rax+0x1F0]
00007a40685cf356  vmovaps [rsp+0x60], xmm1
00007a40685cf35c  movups xmm1, [r13+r12*1]
00007a40685cf362  mov qword ptr [r15+0x50], 0x430920
00007a40685cf36a  lea rax, [r14+0x40]
00007a40685cf36e  vmovaps [rsp+0x70], xmm1
00007a40685cf374  vmovaps xmm1, [rsp+0x40]
00007a40685cf37a  movups [r13+rax*1], xmm1
00007a40685cf380  lea rax, [r14+0x50]
00007a40685cf384  movups [r13+rax*1], xmm10
00007a40685cf38a  vmovaps xmm1, [rsp+0x70]
00007a40685cf390  movups [r13+r14*1], xmm1
00007a40685cf396  lea rax, [r14+0x10]
00007a40685cf39a  vmovaps xmm1, [rsp+0x60]
00007a40685cf3a0  movups [r13+rax*1], xmm1
00007a40685cf3a6  mov rax, [r15+0x40]
00007a40685cf3aa  vmovaps [rsp+0x40], xmm3
00007a40685cf3b0  vmovaps xmm1, [rsp+0x40]
00007a40685cf3b6  por xmm3, xmm1
00007a40685cf3ba  vmovaps [rsp+0x40], xmm6
00007a40685cf3c0  vmovaps xmm10, [rsp+0x40]
00007a40685cf3c6  por xmm6, xmm10
00007a40685cf3cb  lea r12, [rax+0x30]
00007a40685cf3cf  mov r11, [r13+r12*1]
00007a40685cf3d4  lea r12, [rax+0x38]
00007a40685cf3d8  mov r10, [r13+r12*1]
00007a40685cf3dd  movq xmm10, r11
00007a40685cf3e2  vmovaps [rsp+0x40], xmm1
00007a40685cf3e8  movq xmm1, r10
00007a40685cf3ed  movq xmm10, xmm10
00007a40685cf3f2  vmovaps [rsp+0x60], xmm10
00007a40685cf3f8  movq xmm10, xmm10
00007a40685cf3fd  movaps [r15+0x130], xmm10
00007a40685cf405  movq xmm1, xmm1
00007a40685cf409  vmovaps [rsp+0x70], xmm1
00007a40685cf40f  movq xmm1, xmm1
00007a40685cf413  movaps [r15+0x280], xmm1
00007a40685cf41b  vmovaps [rsp+0x80], xmm9
00007a40685cf424  vmovaps xmm1, [rsp+0x80]
00007a40685cf42d  por xmm9, xmm1
00007a40685cf432  lea r12, [rax+0x20]
00007a40685cf436  mov r11, [r13+r12*1]
00007a40685cf43b  lea r12, [rax+0x28]
00007a40685cf43f  mov r10, [r13+r12*1]
00007a40685cf444  movq xmm1, r11
00007a40685cf449  movq xmm10, r10
00007a40685cf44e  movq xmm1, xmm1
00007a40685cf452  vmovaps [rsp+0x80], xmm1
00007a40685cf45b  movq xmm1, xmm1
00007a40685cf45f  movaps [r15+0x150], xmm1
00007a40685cf467  movq xmm10, xmm10
00007a40685cf46c  vmovaps [rsp+0x90], xmm10
00007a40685cf475  movq xmm10, xmm10
00007a40685cf47a  movaps [r15+0x140], xmm10
00007a40685cf482  lea r12, [rax+0x10]
00007a40685cf486  mov r11, [r13+r12*1]
00007a40685cf48b  lea r12, [rax+0x18]
00007a40685cf48f  mov r10, [r13+r12*1]
00007a40685cf494  movq xmm1, r11
00007a40685cf499  movq xmm10, r10
00007a40685cf49e  movq xmm1, xmm1
00007a40685cf4a2  vmovaps [rsp+0xA0], xmm1
00007a40685cf4ab  movq xmm1, xmm1
00007a40685cf4af  movaps [r15+0x170], xmm1
00007a40685cf4b7  movq xmm10, xmm10
00007a40685cf4bc  vmovaps [rsp+0xB0], xmm10
00007a40685cf4c5  movq xmm10, xmm10
00007a40685cf4ca  movaps [r15+0x160], xmm10
00007a40685cf4d2  mov r12, [r13+rax*1]
00007a40685cf4d7  vmovq xmm1, r12
00007a40685cf4dc  vpbroadcastq xmm1, xmm1
00007a40685cf4e1  lea r12, [rax+0x08]
00007a40685cf4e5  mov rax, [r13+r12*1]
00007a40685cf4ea  movq xmm10, rax
00007a40685cf4ef  movaps [r15+0x230], xmm10
00007a40685cf4f7  lea rax, [r14+0x50]
00007a40685cf4fb  movups xmm10, [r13+rax*1]
00007a40685cf501  lea rax, [r14+0x60]
00007a40685cf505  vmovaps [rsp+0xC0], xmm1
00007a40685cf50e  movups xmm1, [r13+rax*1]
00007a40685cf514  lea rax, [r14+0x30]
00007a40685cf518  vmovaps [rsp+0xD0], xmm1
00007a40685cf521  movups xmm1, [r13+rax*1]
00007a40685cf527  mov qword ptr [r15+0x60], 0x430920
00007a40685cf52f  mov qword ptr [r15+0x58], 0x40
00007a40685cf537  vmovaps [rsp+0xE0], xmm1
00007a40685cf540  vmovaps [rsp+0xF0], xmm15
00007a40685cf549  vmovaps xmm15, [rsp+0xC0]
00007a40685cf552  vmovaps [rsp+0xC0], xmm14
00007a40685cf55b  vmovaps xmm14, [rsp+0x40]
00007a40685cf561  vmovaps [rsp+0x40], xmm13
00007a40685cf567  movaps xmm1, xmm15
00007a40685cf56b  mulpd xmm1, xmm14
00007a40685cf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007a40685cf575  ptest xmm13, xmm13
00007a40685cf57b  jnz 0x00007A40685D0682
00007a40685cf581  movq xmm14, qword ptr [r15+0x230]
00007a40685cf58a  vmovaps [rsp+0x100], xmm14
00007a40685cf593  vpermilpd xmm14, xmm14, 0x00
00007a40685cf599  vmovaps [rsp+0x110], xmm1
00007a40685cf5a2  vmovaps xmm1, [rsp+0xE0]
00007a40685cf5ab  vmovaps [rsp+0xE0], xmm15
00007a40685cf5b4  movaps xmm13, xmm1
00007a40685cf5b8  mulpd xmm13, xmm14
00007a40685cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007a40685cf5c3  ptest xmm15, xmm15
00007a40685cf5c9  jnz 0x00007A40685D07C4
00007a40685cf5cf  vxorps xmm1, xmm1, xmm1
00007a40685cf5d3  vpbroadcastq xmm1, xmm1
00007a40685cf5d8  vmovaps xmm14, [rsp+0xE0]
00007a40685cf5e1  vmovaps [rsp+0xE0], xmm1
00007a40685cf5ea  vmovaps xmm1, [rsp+0xD0]
00007a40685cf5f3  vmovaps [rsp+0xD0], xmm13
00007a40685cf5fc  movaps xmm15, xmm14
00007a40685cf600  mulpd xmm15, xmm1
00007a40685cf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007a40685cf60b  ptest xmm13, xmm13
00007a40685cf611  jnz 0x00007A40685D0907
00007a40685cf617  movaps xmm1, xmm14
00007a40685cf61b  mulpd xmm1, xmm10
00007a40685cf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007a40685cf625  ptest xmm13, xmm13
00007a40685cf62b  jnz 0x00007A40685D0A4A
00007a40685cf631  movaps xmm13, xmm14
00007a40685cf635  mulpd xmm13, xmm2
00007a40685cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007a40685cf640  ptest xmm10, xmm10
00007a40685cf646  jnz 0x00007A40685D0B8C
00007a40685cf64c  vmovaps [rsp+0x120], xmm7
00007a40685cf655  vmovaps xmm14, [rsp+0x120]
00007a40685cf65e  por xmm7, xmm14
00007a40685cf663  vmovaps xmm14, [rsp+0xC0]
00007a40685cf66c  vmovaps xmm10, [rsp+0xC0]
00007a40685cf675  por xmm14, xmm10
00007a40685cf67a  vmovaps xmm2, [rsp+0x100]
00007a40685cf683  vpermilpd xmm2, xmm2, 0x00
00007a40685cf689  vmovaps [rsp+0xC0], xmm1
00007a40685cf692  vmovaps [rsp+0x120], xmm15
00007a40685cf69b  movaps xmm1, xmm10
00007a40685cf69f  mulpd xmm1, xmm2
00007a40685cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007a40685cf6a8  ptest xmm15, xmm15
00007a40685cf6ae  jnz 0x00007A40685D0CCF
00007a40685cf6b4  xor eax, eax
00007a40685cf6b6  mov r12d, 0x40
00007a40685cf6bc  mov r11d, 0x200
00007a40685cf6c2  cmp r12, r11
00007a40685cf6c5  cmc
00007a40685cf6c6  lahf
00007a40685cf6c7  seto al
00007a40685cf6ca  mov [r15+0x108], eax
00007a40685cf6d1  vmovaps xmm10, [rsp+0x110]
00007a40685cf6da  vmovaps xmm2, [rsp+0xE0]
00007a40685cf6e3  vmovaps [rsp+0xE0], xmm1
00007a40685cf6ec  movaps xmm15, xmm10
00007a40685cf6f0  addpd xmm15, xmm2
00007a40685cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007a40685cf6fb  ptest xmm1, xmm1
00007a40685cf700  jnz 0x00007A40685D0E10
00007a40685cf706  vmovaps xmm10, [rsp+0x120]
00007a40685cf70f  vmovaps [rsp+0x110], xmm15
00007a40685cf718  movaps xmm1, xmm10
00007a40685cf71c  addpd xmm1, xmm12
00007a40685cf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007a40685cf726  ptest xmm15, xmm15
00007a40685cf72c  jnz 0x00007A40685D0F53
00007a40685cf732  vmovaps xmm10, [rsp+0xC0]
00007a40685cf73b  vmovaps [rsp+0xC0], xmm1
00007a40685cf744  movaps xmm15, xmm10
00007a40685cf748  addpd xmm15, xmm12
00007a40685cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007a40685cf753  ptest xmm1, xmm1
00007a40685cf758  jnz 0x00007A40685D1095
00007a40685cf75e  vmovaps xmm1, [rsp+0x30]
00007a40685cf764  vmovaps xmm12, [rsp+0x30]
00007a40685cf76a  por xmm1, xmm12
00007a40685cf76f  vmovaps xmm12, [rsp+0x20]
00007a40685cf775  vmovaps xmm10, [rsp+0x20]
00007a40685cf77b  por xmm12, xmm10
00007a40685cf780  vmovaps [rsp+0x20], xmm5
00007a40685cf786  vmovaps xmm10, [rsp+0x20]
00007a40685cf78c  por xmm5, xmm10
00007a40685cf791  vmovaps [rsp+0x20], xmm11
00007a40685cf797  vmovaps xmm10, [rsp+0x20]
00007a40685cf79d  por xmm11, xmm10
00007a40685cf7a2  vmovaps [rsp+0x20], xmm4
00007a40685cf7a8  vmovaps xmm10, [rsp+0x20]
00007a40685cf7ae  por xmm4, xmm10
00007a40685cf7b3  vmovaps [rsp+0x20], xmm8
00007a40685cf7b9  vmovaps xmm10, [rsp+0x20]
00007a40685cf7bf  por xmm8, xmm10
00007a40685cf7c4  vmovaps xmm10, [rsp+0xF0]
00007a40685cf7cd  vmovaps [rsp+0x20], xmm1
00007a40685cf7d3  vmovaps xmm1, [rsp+0xF0]
00007a40685cf7dc  por xmm10, xmm1
00007a40685cf7e1  lea rax, [r14+0xA0]
00007a40685cf7e8  movups xmm1, [r13+rax*1]
00007a40685cf7ee  lea rax, [r14+0xB0]
00007a40685cf7f5  vmovaps [rsp+0x30], xmm1
00007a40685cf7fb  movups xmm1, [r13+rax*1]
00007a40685cf801  vmovaps [rsp+0xF0], xmm1
00007a40685cf80a  vmovaps [rsp+0x120], xmm15
00007a40685cf813  movaps xmm1, xmm13
00007a40685cf817  addpd xmm1, xmm2
00007a40685cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007a40685cf820  ptest xmm15, xmm15
00007a40685cf826  jnz 0x00007A40685D11ED
00007a40685cf82c  lea rax, [r14+0xF0]
00007a40685cf833  movups xmm15, [r13+rax*1]
00007a40685cf839  vmovaps xmm2, [rsp+0xC0]
00007a40685cf842  vmovaps [rsp+0xC0], xmm1
00007a40685cf84b  vmovaps xmm1, [rsp+0xE0]
00007a40685cf854  vmovaps [rsp+0xE0], xmm15
00007a40685cf85d  movaps xmm13, xmm2
00007a40685cf861  addpd xmm13, xmm1
00007a40685cf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007a40685cf86c  ptest xmm15, xmm15
00007a40685cf872  jnz 0x00007A40685D1338
00007a40685cf878  vmovaps xmm15, [rsp+0x120]
00007a40685cf881  vmovaps xmm2, [rsp+0xD0]
00007a40685cf88a  vmovaps [rsp+0xD0], xmm14
00007a40685cf893  movaps xmm1, xmm15
00007a40685cf897  addpd xmm1, xmm2
00007a40685cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007a40685cf8a0  ptest xmm14, xmm14
00007a40685cf8a6  jnz 0x00007A40685D147A
00007a40685cf8ac  vmovaps xmm15, [rsp+0x100]
00007a40685cf8b5  vpermilpd xmm15, xmm15, 0x00
00007a40685cf8bb  vmovaps xmm2, [rsp+0xF0]
00007a40685cf8c4  vmovaps [rsp+0xF0], xmm1
00007a40685cf8cd  movaps xmm14, xmm2
00007a40685cf8d1  mulpd xmm14, xmm15
00007a40685cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007a40685cf8dc  ptest xmm1, xmm1
00007a40685cf8e1  jnz 0x00007A40685D15BB
00007a40685cf8e7  vmovaps xmm1, [rsp+0xA0]
00007a40685cf8f0  vpermilpd xmm1, xmm1, 0x00
00007a40685cf8f6  vmovaps xmm2, [rsp+0xE0]
00007a40685cf8ff  vmovaps [rsp+0xE0], xmm14
00007a40685cf908  movaps xmm15, xmm2
00007a40685cf90c  mulpd xmm15, xmm1
00007a40685cf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007a40685cf917  ptest xmm14, xmm14
00007a40685cf91d  jnz 0x00007A40685D16FE
00007a40685cf923  lea rax, [r14+0xE0]
00007a40685cf92a  movups xmm1, [r13+rax*1]
00007a40685cf930  vmovaps xmm14, [rsp+0x100]
00007a40685cf939  vpermilpd xmm14, xmm14, 0x00
00007a40685cf93f  vmovaps [rsp+0x100], xmm1
00007a40685cf948  vmovaps xmm1, [rsp+0x30]
00007a40685cf94e  vmovaps [rsp+0x30], xmm15
00007a40685cf954  movaps xmm2, xmm1
00007a40685cf957  mulpd xmm2, xmm14
00007a40685cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007a40685cf961  ptest xmm15, xmm15
00007a40685cf967  jnz 0x00007A40685D184A
00007a40685cf96d  vmovaps [rsp+0x120], xmm10
00007a40685cf976  vmovaps xmm1, [rsp+0x120]
00007a40685cf97f  por xmm10, xmm1
00007a40685cf984  movaps [r15+0x300], xmm10
00007a40685cf98c  vmovaps [rsp+0x120], xmm8
00007a40685cf995  vmovaps xmm1, [rsp+0x120]
00007a40685cf99e  por xmm8, xmm1
00007a40685cf9a3  movaps [r15+0x190], xmm8
00007a40685cf9ab  vmovaps xmm1, [rsp+0xA0]
00007a40685cf9b4  vpermilpd xmm1, xmm1, 0x00
00007a40685cf9ba  vmovaps xmm14, [rsp+0x100]
00007a40685cf9c3  vmovaps [rsp+0x100], xmm13
00007a40685cf9cc  movaps xmm15, xmm14
00007a40685cf9d0  mulpd xmm15, xmm1
00007a40685cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007a40685cf9db  ptest xmm13, xmm13
00007a40685cf9e1  jnz 0x00007A40685D198B
00007a40685cf9e7  lea rax, [r14+0x90]
00007a40685cf9ee  movups xmm1, [r13+rax*1]
00007a40685cf9f4  vmovaps [rsp+0x120], xmm4
00007a40685cf9fd  vmovaps xmm14, [rsp+0x120]
00007a40685cfa06  por xmm4, xmm14
00007a40685cfa0b  movaps [r15+0x1C0], xmm4
00007a40685cfa13  vmovaps [rsp+0x120], xmm11
00007a40685cfa1c  vmovaps xmm14, [rsp+0x120]
00007a40685cfa25  por xmm11, xmm14
00007a40685cfa2a  movaps [r15+0x200], xmm11
00007a40685cfa32  vmovaps [rsp+0x120], xmm5
00007a40685cfa3b  vmovaps xmm14, [rsp+0x120]
00007a40685cfa44  por xmm5, xmm14
00007a40685cfa49  movaps [r15+0x2D0], xmm5
00007a40685cfa51  vmovaps [rsp+0x120], xmm12
00007a40685cfa5a  vmovaps xmm14, [rsp+0x120]
00007a40685cfa63  por xmm12, xmm14
00007a40685cfa68  movaps [r15+0x2E0], xmm12
00007a40685cfa70  vmovaps xmm13, [rsp+0x110]
00007a40685cfa79  vmovaps [rsp+0x110], xmm1
00007a40685cfa82  vmovaps xmm1, [rsp+0xE0]
00007a40685cfa8b  vmovaps [rsp+0xE0], xmm15
00007a40685cfa94  movaps xmm14, xmm13
00007a40685cfa98  addpd xmm14, xmm1
00007a40685cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007a40685cfaa3  ptest xmm15, xmm15
00007a40685cfaa9  jnz 0x00007A40685D1AD8
00007a40685cfaaf  vmovaps xmm1, [rsp+0xA0]
00007a40685cfab8  vpermilpd xmm1, xmm1, 0x00
00007a40685cfabe  vmovaps xmm13, [rsp+0x110]
00007a40685cfac7  vmovaps [rsp+0x110], xmm14
00007a40685cfad0  movaps xmm15, xmm13
00007a40685cfad4  mulpd xmm15, xmm1
00007a40685cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007a40685cfadf  ptest xmm14, xmm14
00007a40685cfae5  jnz 0x00007A40685D1C1B
00007a40685cfaeb  lea rax, [r14+0x80]
00007a40685cfaf2  movups xmm1, [r13+rax*1]
00007a40685cfaf8  vmovaps xmm13, [rsp+0xC0]
00007a40685cfb01  vmovaps [rsp+0xC0], xmm1
00007a40685cfb0a  movaps xmm14, xmm13
00007a40685cfb0e  addpd xmm14, xmm2
00007a40685cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007a40685cfb19  ptest xmm1, xmm1
00007a40685cfb1e  jnz 0x00007A40685D1D68
00007a40685cfb24  vmovaps xmm13, [rsp+0x100]
00007a40685cfb2d  vmovaps xmm2, [rsp+0x30]
00007a40685cfb33  vmovaps [rsp+0x30], xmm15
00007a40685cfb39  movaps xmm1, xmm13
00007a40685cfb3d  addpd xmm1, xmm2
00007a40685cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007a40685cfb46  ptest xmm15, xmm15
00007a40685cfb4c  jnz 0x00007A40685D1EAB
00007a40685cfb52  vmovaps xmm15, [rsp+0x20]
00007a40685cfb58  vmovaps xmm13, [rsp+0x20]
00007a40685cfb5e  por xmm15, xmm13
00007a40685cfb63  movaps [r15+0x2F0], xmm15
00007a40685cfb6b  vmovaps xmm13, [rsp+0xA0]
00007a40685cfb74  vpermilpd xmm13, xmm13, 0x00
00007a40685cfb7a  vmovaps [rsp+0x20], xmm1
00007a40685cfb80  vmovaps xmm1, [rsp+0xC0]
00007a40685cfb89  vmovaps [rsp+0xA0], xmm15
00007a40685cfb92  movaps xmm2, xmm1
00007a40685cfb95  mulpd xmm2, xmm13
00007a40685cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007a40685cfb9f  ptest xmm15, xmm15
00007a40685cfba5  jnz 0x00007A40685D1FEC
00007a40685cfbab  lea rax, [r14+0xD0]
00007a40685cfbb2  movups xmm1, [r13+rax*1]
00007a40685cfbb8  vmovaps xmm13, [rsp+0xF0]
00007a40685cfbc1  vmovaps [rsp+0xC0], xmm1
00007a40685cfbca  vmovaps xmm1, [rsp+0xE0]
00007a40685cfbd3  vmovaps [rsp+0xE0], xmm14
00007a40685cfbdc  movaps xmm15, xmm13
00007a40685cfbe0  addpd xmm15, xmm1
00007a40685cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007a40685cfbeb  ptest xmm14, xmm14
00007a40685cfbf1  jnz 0x00007A40685D2137
00007a40685cfbf7  vmovaps xmm1, [rsp+0xB0]
00007a40685cfc00  vpermilpd xmm1, xmm1, 0x00
00007a40685cfc06  movaps xmm14, xmm11
00007a40685cfc0a  mulpd xmm14, xmm1
00007a40685cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007a40685cfc15  ptest xmm13, xmm13
00007a40685cfc1b  jnz 0x00007A40685D227A
00007a40685cfc21  movaps [r15+0x260], xmm14
00007a40685cfc29  vxorps xmm1, xmm1, xmm1
00007a40685cfc2d  vpbroadcastq xmm1, xmm1
00007a40685cfc32  movaps [r15+0x1B0], xmm1
00007a40685cfc3a  vmovaps xmm1, [rsp+0xB0]
00007a40685cfc43  vpermilpd xmm1, xmm1, 0x00
00007a40685cfc49  vmovaps xmm11, [rsp+0xC0]
00007a40685cfc52  vmovaps [rsp+0xC0], xmm15
00007a40685cfc5b  movaps xmm13, xmm11
00007a40685cfc5f  mulpd xmm13, xmm1
00007a40685cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007a40685cfc6a  ptest xmm15, xmm15
00007a40685cfc70  jnz 0x00007A40685D23BD
00007a40685cfc76  lea rax, [r14+0xC0]
00007a40685cfc7d  movups xmm1, [r13+rax*1]
00007a40685cfc83  vmovaps xmm11, [rsp+0x110]
00007a40685cfc8c  vmovaps [rsp+0xF0], xmm1
00007a40685cfc95  vmovaps xmm1, [rsp+0x30]
00007a40685cfc9b  vmovaps [rsp+0x30], xmm14
00007a40685cfca1  movaps xmm15, xmm11
00007a40685cfca5  addpd xmm15, xmm1
00007a40685cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007a40685cfcb0  ptest xmm14, xmm14
00007a40685cfcb6  jnz 0x00007A40685D250A
00007a40685cfcbc  vmovaps [rsp+0x100], xmm9
00007a40685cfcc5  vmovaps xmm1, [rsp+0x100]
00007a40685cfcce  por xmm9, xmm1
00007a40685cfcd3  movaps [r15+0x270], xmm9
00007a40685cfcdb  vmovaps [rsp+0x100], xmm6
00007a40685cfce4  vmovaps xmm1, [rsp+0x100]
00007a40685cfced  por xmm6, xmm1
00007a40685cfcf1  movaps [r15+0x1A0], xmm6
00007a40685cfcf9  vmovaps xmm14, [rsp+0xB0]
00007a40685cfd02  vpermilpd xmm14, xmm14, 0x00
00007a40685cfd08  vmovaps xmm6, [rsp+0xF0]
00007a40685cfd11  vmovaps [rsp+0xF0], xmm1
00007a40685cfd1a  movaps xmm11, xmm6
00007a40685cfd1e  mulpd xmm11, xmm14
00007a40685cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007a40685cfd29  ptest xmm1, xmm1
00007a40685cfd2e  jnz 0x00007A40685D264D
00007a40685cfd34  lea rax, [r14+0x20]
00007a40685cfd38  movups xmm1, [r13+rax*1]
00007a40685cfd3e  movaps [r15+0x110], xmm1
00007a40685cfd46  vmovaps xmm6, [rsp+0xE0]
00007a40685cfd4f  vmovaps [rsp+0xE0], xmm1
00007a40685cfd58  movaps xmm14, xmm6
00007a40685cfd5c  addpd xmm14, xmm2
00007a40685cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007a40685cfd67  ptest xmm1, xmm1
00007a40685cfd6c  jnz 0x00007A40685D279A
00007a40685cfd72  vmovaps xmm1, [rsp+0xB0]
00007a40685cfd7b  vpermilpd xmm1, xmm1, 0x00
00007a40685cfd81  movaps xmm6, xmm5
00007a40685cfd84  mulpd xmm6, xmm1
00007a40685cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007a40685cfd8d  ptest xmm2, xmm2
00007a40685cfd92  jnz 0x00007A40685D28DC
00007a40685cfd98  vmovaps xmm5, [rsp+0x20]
00007a40685cfd9e  movaps xmm1, xmm5
00007a40685cfda1  addpd xmm1, xmm13
00007a40685cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007a40685cfdab  ptest xmm2, xmm2
00007a40685cfdb0  jnz 0x00007A40685D2A1C
00007a40685cfdb6  vmovaps xmm13, [rsp+0x80]
00007a40685cfdbf  vpermilpd xmm13, xmm13, 0x00
00007a40685cfdc5  vmovaps xmm2, [rsp+0xE0]
00007a40685cfdce  vmovaps [rsp+0x20], xmm1
00007a40685cfdd4  movaps xmm5, xmm2
00007a40685cfdd7  mulpd xmm5, xmm13
00007a40685cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007a40685cfde1  ptest xmm1, xmm1
00007a40685cfde6  jnz 0x00007A40685D2B5D
00007a40685cfdec  vmovaps xmm1, [rsp+0x80]
00007a40685cfdf5  vpermilpd xmm1, xmm1, 0x00
00007a40685cfdfb  movaps xmm13, xmm10
00007a40685cfdff  mulpd xmm13, xmm1
00007a40685cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007a40685cfe0a  ptest xmm2, xmm2
00007a40685cfe0f  jnz 0x00007A40685D2C9E
00007a40685cfe15  vmovaps xmm10, [rsp+0x30]
00007a40685cfe1b  movaps xmm1, xmm15
00007a40685cfe1f  addpd xmm1, xmm10
00007a40685cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007a40685cfe29  ptest xmm2, xmm2
00007a40685cfe2e  jnz 0x00007A40685D2DE1
00007a40685cfe34  vmovaps xmm10, [rsp+0xC0]
00007a40685cfe3d  movaps xmm15, xmm10
00007a40685cfe41  addpd xmm15, xmm11
00007a40685cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007a40685cfe4c  ptest xmm2, xmm2
00007a40685cfe51  jnz 0x00007A40685D2F23
00007a40685cfe57  vmovaps xmm11, [rsp+0x80]
00007a40685cfe60  vpermilpd xmm11, xmm11, 0x00
00007a40685cfe66  movaps xmm10, xmm12
00007a40685cfe6a  mulpd xmm10, xmm11
00007a40685cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007a40685cfe75  ptest xmm2, xmm2
00007a40685cfe7a  jnz 0x00007A40685D3067
00007a40685cfe80  vmovaps xmm12, [rsp+0x80]
00007a40685cfe89  vpermilpd xmm12, xmm12, 0x00
00007a40685cfe8f  vmovaps xmm2, [rsp+0xA0]
00007a40685cfe98  vmovaps [rsp+0x30], xmm1
00007a40685cfe9e  movaps xmm11, xmm2
00007a40685cfea2  mulpd xmm11, xmm12
00007a40685cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007a40685cfead  ptest xmm1, xmm1
00007a40685cfeb2  jnz 0x00007A40685D31AB
00007a40685cfeb8  movaps xmm1, xmm14
00007a40685cfebc  addpd xmm1, xmm6
00007a40685cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007a40685cfec5  ptest xmm12, xmm12
00007a40685cfecb  jnz 0x00007A40685D32EE
00007a40685cfed1  vmovaps xmm12, [rsp+0x20]
00007a40685cfed7  movaps xmm14, xmm12
00007a40685cfedb  addpd xmm14, xmm5
00007a40685cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007a40685cfee6  ptest xmm6, xmm6
00007a40685cfeeb  jnz 0x00007A40685D342F
00007a40685cfef1  vmovaps xmm12, [rsp+0x90]
00007a40685cfefa  vpermilpd xmm12, xmm12, 0x00
00007a40685cff00  movaps xmm6, xmm9
00007a40685cff04  mulpd xmm6, xmm12
00007a40685cff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007a40685cff0e  ptest xmm5, xmm5
00007a40685cff13  jnz 0x00007A40685D3572
00007a40685cff19  movaps xmm12, xmm15
00007a40685cff1d  addpd xmm12, xmm13
00007a40685cff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007a40685cff28  ptest xmm9, xmm9
00007a40685cff2e  jnz 0x00007A40685D36B4
00007a40685cff34  vmovaps xmm13, [rsp+0x30]
00007a40685cff3a  movaps xmm15, xmm13
00007a40685cff3e  addpd xmm15, xmm10
00007a40685cff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007a40685cff49  ptest xmm9, xmm9
00007a40685cff4f  jnz 0x00007A40685D37F8
00007a40685cff55  vmovaps xmm13, [rsp+0xD0]
00007a40685cff5e  vmovaps xmm10, [rsp+0xD0]
00007a40685cff67  por xmm13, xmm10
00007a40685cff6c  movaps [r15+0x250], xmm13
00007a40685cff74  vmovaps [rsp+0x20], xmm7
00007a40685cff7a  vmovaps xmm13, [rsp+0x20]
00007a40685cff80  por xmm7, xmm13
00007a40685cff85  movaps [r15+0x2A0], xmm7
00007a40685cff8d  vmovaps [rsp+0x20], xmm3
00007a40685cff93  vmovaps xmm13, [rsp+0x20]
00007a40685cff99  por xmm3, xmm13
00007a40685cff9e  movaps [r15+0x1D0], xmm3
00007a40685cffa6  lea rax, [r14+0x40]
00007a40685cffaa  movups xmm13, [r13+rax*1]
00007a40685cffb0  movaps [r15+0x2C0], xmm13
00007a40685cffb8  vmovaps xmm10, [rsp+0x90]
00007a40685cffc1  vpermilpd xmm10, xmm10, 0x00
00007a40685cffc7  movaps xmm9, xmm8
00007a40685cffcb  mulpd xmm9, xmm10
00007a40685cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007a40685cffd6  ptest xmm5, xmm5
00007a40685cffdb  jnz 0x00007A40685D3946
00007a40685cffe1  movaps xmm10, xmm1
00007a40685cffe5  addpd xmm10, xmm11
00007a40685cffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007a40685cfff0  ptest xmm8, xmm8
00007a40685cfff6  jnz 0x00007A40685D3A8A
00007a40685cfffc  movaps xmm1, xmm14
00007a40685d0000  addpd xmm1, xmm6
00007a40685d0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007a40685d0009  ptest xmm11, xmm11
00007a40685d000f  jnz 0x00007A40685D3BCD
00007a40685d0015  vmovaps xmm14, [rsp+0x90]
00007a40685d001e  vpermilpd xmm14, xmm14, 0x00
00007a40685d0024  movaps xmm11, xmm13
00007a40685d0028  mulpd xmm11, xmm14
00007a40685d002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007a40685d0033  ptest xmm8, xmm8
00007a40685d0039  jnz 0x00007A40685D3D0E
00007a40685d003f  vmovaps xmm14, [rsp+0x90]
00007a40685d0048  vpermilpd xmm14, xmm14, 0x00
00007a40685d004e  vmovaps xmm8, [rsp+0x10]
00007a40685d0054  movaps xmm13, xmm8
00007a40685d0058  mulpd xmm13, xmm14
00007a40685d005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007a40685d0063  ptest xmm6, xmm6
00007a40685d0068  jnz 0x00007A40685D3E52
00007a40685d006e  vmovaps xmm14, [rsp+0x60]
00007a40685d0074  vpermilpd xmm14, xmm14, 0x00
00007a40685d007a  movaps xmm8, xmm7
00007a40685d007e  mulpd xmm8, xmm14
00007a40685d0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007a40685d0089  ptest xmm6, xmm6
00007a40685d008e  jnz 0x00007A40685D3F96
00007a40685d0094  movaps xmm14, xmm12
00007a40685d0098  addpd xmm14, xmm9
00007a40685d009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007a40685d00a3  ptest xmm7, xmm7
00007a40685d00a8  jnz 0x00007A40685D40D9
00007a40685d00ae  vmovaps xmm12, [rsp+0x60]
00007a40685d00b4  vpermilpd xmm12, xmm12, 0x00
00007a40685d00ba  vmovaps xmm7, [rsp+0xF0]
00007a40685d00c3  movaps xmm9, xmm7
00007a40685d00c7  mulpd xmm9, xmm12
00007a40685d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007a40685d00d2  ptest xmm6, xmm6
00007a40685d00d7  jnz 0x00007A40685D421D
00007a40685d00dd  movaps xmm12, xmm15
00007a40685d00e1  addpd xmm12, xmm11
00007a40685d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007a40685d00ec  ptest xmm7, xmm7
00007a40685d00f1  jnz 0x00007A40685D4360
00007a40685d00f7  vmovaps xmm15, [rsp+0x60]
00007a40685d00fd  vpermilpd xmm15, xmm15, 0x00
00007a40685d0103  vmovaps xmm7, [rsp+0x40]
00007a40685d0109  movaps xmm11, xmm7
00007a40685d010d  mulpd xmm11, xmm15
00007a40685d0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007a40685d0118  ptest xmm6, xmm6
00007a40685d011d  jnz 0x00007A40685D44A4
00007a40685d0123  movaps xmm15, xmm10
00007a40685d0127  addpd xmm15, xmm13
00007a40685d012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007a40685d0132  ptest xmm7, xmm7
00007a40685d0137  jnz 0x00007A40685D45E7
00007a40685d013d  vmovaps xmm13, [rsp+0x60]
00007a40685d0143  vpermilpd xmm13, xmm13, 0x00
00007a40685d0149  vmovaps xmm7, [rsp+0x50]
00007a40685d014f  movaps xmm10, xmm7
00007a40685d0153  mulpd xmm10, xmm13
00007a40685d0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007a40685d015e  ptest xmm6, xmm6
00007a40685d0163  jnz 0x00007A40685D472B
00007a40685d0169  movaps xmm13, xmm1
00007a40685d016d  addpd xmm13, xmm8
00007a40685d0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007a40685d0178  ptest xmm7, xmm7
00007a40685d017d  jnz 0x00007A40685D486E
00007a40685d0183  lea rax, [r14+0x70]
00007a40685d0187  movups xmm1, [r13+rax*1]
00007a40685d018d  movaps [r15+0x240], xmm1
00007a40685d0195  movaps xmm8, xmm14
00007a40685d0199  addpd xmm8, xmm9
00007a40685d019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007a40685d01a4  ptest xmm7, xmm7
00007a40685d01a9  jnz 0x00007A40685D49BB
00007a40685d01af  movaps [r15+0x170], xmm8
00007a40685d01b7  vmovaps xmm14, [rsp+0x70]
00007a40685d01bd  vpermilpd xmm14, xmm14, 0x00
00007a40685d01c3  movaps xmm9, xmm1
00007a40685d01c7  mulpd xmm9, xmm14
00007a40685d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007a40685d01d2  ptest xmm7, xmm7
00007a40685d01d7  jnz 0x00007A40685D4AFF
00007a40685d01dd  vmovaps xmm1, [rsp+0x70]
00007a40685d01e3  vpermilpd xmm1, xmm1, 0x00
00007a40685d01e9  movaps xmm14, xmm4
00007a40685d01ed  mulpd xmm14, xmm1
00007a40685d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007a40685d01f8  ptest xmm7, xmm7
00007a40685d01fd  jnz 0x00007A40685D4C42
00007a40685d0203  movaps [r15+0x180], xmm14
00007a40685d020b  movaps xmm1, xmm12
00007a40685d020f  addpd xmm1, xmm11
00007a40685d0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007a40685d0219  ptest xmm7, xmm7
00007a40685d021e  jnz 0x00007A40685D4D84
00007a40685d0224  movaps [r15+0x210], xmm1
00007a40685d022c  movups xmm12, [r13+r14*1]
00007a40685d0232  lea rax, [r14+0x10]
00007a40685d0236  movups xmm11, [r13+rax*1]
00007a40685d023c  movaps [r15+0x230], xmm11
00007a40685d0244  movaps xmm7, xmm15
00007a40685d0248  addpd xmm7, xmm10
00007a40685d024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007a40685d0252  ptest xmm6, xmm6
00007a40685d0257  jnz 0x00007A40685D4EDA
00007a40685d025d  movaps [r15+0x130], xmm7
00007a40685d0265  vmovaps xmm15, [rsp+0x70]
00007a40685d026b  vpermilpd xmm15, xmm15, 0x00
00007a40685d0271  movaps xmm10, xmm11
00007a40685d0275  mulpd xmm10, xmm15
00007a40685d027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007a40685d0280  ptest xmm6, xmm6
00007a40685d0285  jnz 0x00007A40685D501C
00007a40685d028b  movaps [r15+0x220], xmm10
00007a40685d0293  vmovaps xmm15, [rsp+0x70]
00007a40685d0299  vpermilpd xmm15, xmm15, 0x00
00007a40685d029f  movaps xmm11, xmm12
00007a40685d02a3  mulpd xmm11, xmm15
00007a40685d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007a40685d02ae  ptest xmm6, xmm6
00007a40685d02b3  jnz 0x00007A40685D5160
00007a40685d02b9  movaps xmm15, xmm13
00007a40685d02bd  addpd xmm15, xmm9
00007a40685d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007a40685d02c8  ptest xmm12, xmm12
00007a40685d02ce  jnz 0x00007A40685D52A4
00007a40685d02d4  movaps [r15+0x140], xmm15
00007a40685d02dc  movaps xmm13, xmm8
00007a40685d02e0  addpd xmm13, xmm14
00007a40685d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007a40685d02eb  ptest xmm12, xmm12
00007a40685d02f1  jnz 0x00007A40685D53E8
00007a40685d02f7  movaps [r15+0x150], xmm13
00007a40685d02ff  movaps xmm14, xmm1
00007a40685d0303  addpd xmm14, xmm10
00007a40685d0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007a40685d030e  ptest xmm12, xmm12
00007a40685d0314  jnz 0x00007A40685D552C
00007a40685d031a  movaps [r15+0x160], xmm14
00007a40685d0322  movaps xmm1, xmm7
00007a40685d0325  addpd xmm1, xmm11
00007a40685d032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007a40685d032f  ptest xmm12, xmm12
00007a40685d0335  jnz 0x00007A40685D566F
00007a40685d033b  movaps [r15+0x120], xmm1
00007a40685d0343  mov eax, 0x430920
00007a40685d0348  movups [r13+rax*1], xmm15
00007a40685d034e  mov eax, 0x430930
00007a40685d0353  movups [r13+rax*1], xmm13
00007a40685d0359  mov eax, 0x430940
00007a40685d035e  movups [r13+rax*1], xmm14
00007a40685d0364  mov eax, 0x430950
00007a40685d0369  movups [r13+rax*1], xmm1
00007a40685d036f  mov eax, [r15+0x108]
00007a40685d0376  sahf
00007a40685d0377  jnz 0x00007A40685D03A9
00007a40685d0379  cmp dword ptr [r15+0x318], 0x00
00007a40685d0381  jz 0x00007A40685DB900
00007a40685d0387  nop [rax+rax*1], ax
00007a40685d0390  nop [rax+rax*1], eax
00007a40685d0398  mov eax, 0x410444
00007a40685d039d  mov [r15+0x100], rax
00007a40685d03a4  jmp 0x00007A40683FE110
00007a40685d03a9  cmp dword ptr [r15+0x318], 0x00
00007a40685d03b1  jz 0x00007A40685D57E0
00007a40685d03b7  nop [rax+rax*1], ax
00007a40685d03c0  nop [rax+rax*1], eax
00007a40685d03c8  mov eax, 0x410278
00007a40685d03cd  mov [r15+0x100], rax
00007a40685d03d4  jmp 0x00007A40683FE110
00007a40685d03d9  int3
00007a40685d03da  call 0x00007A40684B52F0
00007a40685d03df  jmp 0x00007A40685CF016
00007a40685d03e4  call 0x00007A40684C4620
00007a40685d03e9  jmp 0x00007A40685CF023
00007a40685d03ee  call 0x00007A40684C33A0
00007a40685d03f3  jmp 0x00007A40685CF035
00007a40685d03f8  call 0x00007A40684C2120
00007a40685d03fd  jmp 0x00007A40685CF03F
00007a40685d0402  call 0x00007A40684C0860
00007a40685d0407  jmp 0x00007A40685CF067
00007a40685d040c  call 0x00007A40684BF5F0
00007a40685d0411  jmp 0x00007A40685CF073
00007a40685d0416  call 0x00007A40684C0860
00007a40685d041b  jmp 0x00007A40685CF0A5
00007a40685d0420  call 0x00007A40684BF5F0
00007a40685d0425  jmp 0x00007A40685CF0B1
00007a40685d042a  call 0x00007A40684C4740
00007a40685d042f  jmp 0x00007A40685CF0BE
00007a40685d0434  call 0x00007A40684B5400
00007a40685d0439  jmp 0x00007A40685CF0CB
00007a40685d043e  call 0x00007A40684B52F0
00007a40685d0443  jmp 0x00007A40685CF0D8
00007a40685d0448  call 0x00007A40684C4620
00007a40685d044d  jmp 0x00007A40685CF0E5
00007a40685d0452  call 0x00007A40684C0860
00007a40685d0457  jmp 0x00007A40685CF10D
00007a40685d045c  call 0x00007A40684BF5F0
00007a40685d0461  jmp 0x00007A40685CF119
00007a40685d0466  call 0x00007A4068409D70
00007a40685d046b  jmp 0x00007A40685CF11F
00007a40685d0470  call 0x00007A40684BE9C0
00007a40685d0475  jmp 0x00007A40685CF129
00007a40685d047a  call 0x00007A40684C0860
00007a40685d047f  jmp 0x00007A40685CF151
00007a40685d0484  call 0x00007A40684BF5F0
00007a40685d0489  jmp 0x00007A40685CF15D
00007a40685d048e  call 0x00007A40684BD750
00007a40685d0493  jmp 0x00007A40685CF16A
00007a40685d0498  call 0x00007A40684BC4E0
00007a40685d049d  jmp 0x00007A40685CF177
00007a40685d04a2  call 0x00007A40684C4740
00007a40685d04a7  jmp 0x00007A40685CF184
00007a40685d04ac  call 0x00007A40684B5400
00007a40685d04b1  jmp 0x00007A40685CF191
00007a40685d04b6  call 0x00007A40684B52F0
00007a40685d04bb  jmp 0x00007A40685CF19E
00007a40685d04c0  call 0x00007A40684C4620
00007a40685d04c5  jmp 0x00007A40685CF1AB
00007a40685d04ca  call 0x00007A40684C0860
00007a40685d04cf  jmp 0x00007A40685CF1BE
00007a40685d04d4  call 0x00007A40684BB270
00007a40685d04d9  jmp 0x00007A40685CF1CB
00007a40685d04de  call 0x00007A40684BA000
00007a40685d04e3  jmp 0x00007A40685CF1D8
00007a40685d04e8  call 0x00007A40684B8D90
00007a40685d04ed  jmp 0x00007A40685CF1E5
00007a40685d04f2  call 0x00007A40684B8A20
00007a40685d04f7  jmp 0x00007A40685CF1F2
00007a40685d04fc  call 0x00007A40684B5400
00007a40685d0501  jmp 0x00007A40685CF1FC
00007a40685d0506  call 0x00007A40684C2240
00007a40685d050b  jmp 0x00007A40685CF206
00007a40685d0510  call 0x00007A40684B52F0
00007a40685d0515  jmp 0x00007A40685CF210
00007a40685d051a  call 0x00007A40684C2120
00007a40685d051f  jmp 0x00007A40685CF21A
00007a40685d0524  call 0x00007A40684B77B0
00007a40685d0529  jmp 0x00007A40685CF224
00007a40685d052e  call 0x00007A40684B6550
00007a40685d0533  jmp 0x00007A40685CF22E
00007a40685d0538  call 0x00007A40684BFD50
00007a40685d053d  jmp 0x00007A40685CF240
00007a40685d0542  call 0x00007A40684B8EA0
00007a40685d0547  jmp 0x00007A40685CF24A
00007a40685d054c  call 0x00007A40684BFC30
00007a40685d0551  jmp 0x00007A40685CF257
00007a40685d0556  call 0x00007A40684B8D90
00007a40685d055b  jmp 0x00007A40685CF264
00007a40685d0560  call 0x00007A40684C2240
00007a40685d0565  jmp 0x00007A40685CF271
00007a40685d056a  call 0x00007A40684B5400
00007a40685d056f  jmp 0x00007A40685CF27E
00007a40685d0574  call 0x00007A40684B52F0
00007a40685d0579  jmp 0x00007A40685CF28B
00007a40685d057e  call 0x00007A40684C2120
00007a40685d0583  jmp 0x00007A40685CF298
00007a40685d0588  call 0x00007A40684B52F0
00007a40685d058d  jmp 0x00007A40685CF2AB
00007a40685d0592  call 0x00007A40684B52F0
00007a40685d0597  jmp 0x00007A40685CF2BE
00007a40685d059c  call 0x00007A40684B52F0
00007a40685d05a1  jmp 0x00007A40685CF2D1
00007a40685d05a6  call 0x00007A40684B52F0
00007a40685d05ab  jmp 0x00007A40685CF2E4
00007a40685d05b0  call 0x00007A40684C2240
00007a40685d05b5  jmp 0x00007A40685CF2F9
00007a40685d05ba  call 0x00007A40684C2240
00007a40685d05bf  jmp 0x00007A40685CF30C
00007a40685d05c4  call 0x00007A40684C2120
00007a40685d05c9  jmp 0x00007A40685CF319
00007a40685d05ce  call 0x00007A40684B52F0
00007a40685d05d3  jmp 0x00007A40685CF32C
00007a40685d05d8  call 0x00007A40684B52F0
00007a40685d05dd  jmp 0x00007A40685CF34F
00007a40685d05e2  call 0x00007A40684B52F0
00007a40685d05e7  jmp 0x00007A40685CF362
00007a40685d05ec  call 0x00007A40683FF540
00007a40685d05f1  jmp 0x00007A40685CF380
00007a40685d05f6  call 0x00007A4068408C20
00007a40685d05fb  jmp 0x00007A40685CF38A
00007a40685d0600  call 0x00007A40684D6600
00007a40685d0605  jmp 0x00007A40685CF396
00007a40685d060a  call 0x00007A40683FF540
00007a40685d060f  jmp 0x00007A40685CF3A6
00007a40685d0614  call 0x00007A40684C0370
00007a40685d0619  jmp 0x00007A40685CF3D4
00007a40685d061e  call 0x00007A40684BF100
00007a40685d0623  jmp 0x00007A40685CF3DD
00007a40685d0628  call 0x00007A40684C0370
00007a40685d062d  jmp 0x00007A40685CF43B
00007a40685d0632  call 0x00007A40684BF100
00007a40685d0637  jmp 0x00007A40685CF444
00007a40685d063c  call 0x00007A40684C0370
00007a40685d0641  jmp 0x00007A40685CF48B
00007a40685d0646  call 0x00007A40684BF100
00007a40685d064b  jmp 0x00007A40685CF494
00007a40685d0650  call 0x00007A406840B720
00007a40685d0655  jmp 0x00007A40685CF4D7
00007a40685d065a  call 0x00007A40684B47C0
00007a40685d065f  jmp 0x00007A40685CF4EA
00007a40685d0664  call 0x00007A4068408B00
00007a40685d0669  jmp 0x00007A40685CF501
00007a40685d066e  call 0x00007A40683FF430
00007a40685d0673  jmp 0x00007A40685CF514
00007a40685d0678  call 0x00007A40683FF430
00007a40685d067d  jmp 0x00007A40685CF527
00007a40685d0682  sub rsp, 0x08
00007a40685d0686  push rax
00007a40685d0687  push rcx
00007a40685d0688  push rdx
00007a40685d0689  push rdi
00007a40685d068a  push rsi
00007a40685d068b  push r8
00007a40685d068d  push r9
00007a40685d068f  push r10
00007a40685d0691  push r11
00007a40685d0693  sub rsp, 0xF0
00007a40685d069a  vmovaps [rsp], xmm0
00007a40685d069f  vmovaps [rsp+0x10], xmm2
00007a40685d06a5  vmovaps [rsp+0x20], xmm3
00007a40685d06ab  vmovaps [rsp+0x30], xmm4
00007a40685d06b1  vmovaps [rsp+0x40], xmm5
00007a40685d06b7  vmovaps [rsp+0x50], xmm6
00007a40685d06bd  vmovaps [rsp+0x60], xmm7
00007a40685d06c3  vmovaps [rsp+0x70], xmm8
00007a40685d06c9  vmovaps [rsp+0x80], xmm9
00007a40685d06d2  vmovaps [rsp+0x90], xmm10
00007a40685d06db  vmovaps [rsp+0xA0], xmm11
00007a40685d06e4  vmovaps [rsp+0xB0], xmm12
00007a40685d06ed  vmovaps [rsp+0xC0], xmm13
00007a40685d06f6  vmovaps [rsp+0xD0], xmm14
00007a40685d06ff  vmovaps [rsp+0xE0], xmm15
00007a40685d0708  sub rsp, 0x30
00007a40685d070c  movaps [rsp], xmm1
00007a40685d0710  movaps [rsp+0x10], xmm15
00007a40685d0716  movaps [rsp+0x20], xmm14
00007a40685d071c  lea rdi, [rsp]
00007a40685d0720  mov esi, 0x00
00007a40685d0725  mov rax, 0x56F679577530
00007a40685d072f  call rax
00007a40685d0731  movaps xmm1, [rsp]
00007a40685d0735  add rsp, 0x30
00007a40685d0739  vmovaps xmm0, [rsp]
00007a40685d073e  vmovaps xmm2, [rsp+0x10]
00007a40685d0744  vmovaps xmm3, [rsp+0x20]
00007a40685d074a  vmovaps xmm4, [rsp+0x30]
00007a40685d0750  vmovaps xmm5, [rsp+0x40]
00007a40685d0756  vmovaps xmm6, [rsp+0x50]
00007a40685d075c  vmovaps xmm7, [rsp+0x60]
00007a40685d0762  vmovaps xmm8, [rsp+0x70]
00007a40685d0768  vmovaps xmm9, [rsp+0x80]
00007a40685d0771  vmovaps xmm10, [rsp+0x90]
00007a40685d077a  vmovaps xmm11, [rsp+0xA0]
00007a40685d0783  vmovaps xmm12, [rsp+0xB0]
00007a40685d078c  vmovaps xmm13, [rsp+0xC0]
00007a40685d0795  vmovaps xmm14, [rsp+0xD0]
00007a40685d079e  vmovaps xmm15, [rsp+0xE0]
00007a40685d07a7  add rsp, 0xF0
00007a40685d07ae  pop r11
00007a40685d07b0  pop r10
00007a40685d07b2  pop r9
00007a40685d07b4  pop r8
00007a40685d07b6  pop rsi
00007a40685d07b7  pop rdi
00007a40685d07b8  pop rdx
00007a40685d07b9  pop rcx
00007a40685d07ba  pop rax
00007a40685d07bb  add rsp, 0x08
00007a40685d07bf  jmp 0x00007A40685CF581
00007a40685d07c4  sub rsp, 0x08
00007a40685d07c8  push rax
00007a40685d07c9  push rcx
00007a40685d07ca  push rdx
00007a40685d07cb  push rdi
00007a40685d07cc  push rsi
00007a40685d07cd  push r8
00007a40685d07cf  push r9
00007a40685d07d1  push r10
00007a40685d07d3  push r11
00007a40685d07d5  sub rsp, 0xF0
00007a40685d07dc  vmovaps [rsp], xmm0
00007a40685d07e1  vmovaps [rsp+0x10], xmm1
00007a40685d07e7  vmovaps [rsp+0x20], xmm2
00007a40685d07ed  vmovaps [rsp+0x30], xmm3
00007a40685d07f3  vmovaps [rsp+0x40], xmm4
00007a40685d07f9  vmovaps [rsp+0x50], xmm5
00007a40685d07ff  vmovaps [rsp+0x60], xmm6
00007a40685d0805  vmovaps [rsp+0x70], xmm7
00007a40685d080b  vmovaps [rsp+0x80], xmm8
00007a40685d0814  vmovaps [rsp+0x90], xmm9
00007a40685d081d  vmovaps [rsp+0xA0], xmm10
00007a40685d0826  vmovaps [rsp+0xB0], xmm11
00007a40685d082f  vmovaps [rsp+0xC0], xmm12
00007a40685d0838  vmovaps [rsp+0xD0], xmm14
00007a40685d0841  vmovaps [rsp+0xE0], xmm15
00007a40685d084a  sub rsp, 0x30
00007a40685d084e  movaps [rsp], xmm13
00007a40685d0853  movaps [rsp+0x10], xmm1
00007a40685d0858  movaps [rsp+0x20], xmm14
00007a40685d085e  lea rdi, [rsp]
00007a40685d0862  mov esi, 0x00
00007a40685d0867  mov rax, 0x56F679577530
00007a40685d0871  call rax
00007a40685d0873  movaps xmm13, [rsp]
00007a40685d0878  add rsp, 0x30
00007a40685d087c  vmovaps xmm0, [rsp]
00007a40685d0881  vmovaps xmm1, [rsp+0x10]
00007a40685d0887  vmovaps xmm2, [rsp+0x20]
00007a40685d088d  vmovaps xmm3, [rsp+0x30]
00007a40685d0893  vmovaps xmm4, [rsp+0x40]
00007a40685d0899  vmovaps xmm5, [rsp+0x50]
00007a40685d089f  vmovaps xmm6, [rsp+0x60]
00007a40685d08a5  vmovaps xmm7, [rsp+0x70]
00007a40685d08ab  vmovaps xmm8, [rsp+0x80]
00007a40685d08b4  vmovaps xmm9, [rsp+0x90]
00007a40685d08bd  vmovaps xmm10, [rsp+0xA0]
00007a40685d08c6  vmovaps xmm11, [rsp+0xB0]
00007a40685d08cf  vmovaps xmm12, [rsp+0xC0]
00007a40685d08d8  vmovaps xmm14, [rsp+0xD0]
00007a40685d08e1  vmovaps xmm15, [rsp+0xE0]
00007a40685d08ea  add rsp, 0xF0
00007a40685d08f1  pop r11
00007a40685d08f3  pop r10
00007a40685d08f5  pop r9
00007a40685d08f7  pop r8
00007a40685d08f9  pop rsi
00007a40685d08fa  pop rdi
00007a40685d08fb  pop rdx
00007a40685d08fc  pop rcx
00007a40685d08fd  pop rax
00007a40685d08fe  add rsp, 0x08
00007a40685d0902  jmp 0x00007A40685CF5CF
00007a40685d0907  sub rsp, 0x08
00007a40685d090b  push rax
00007a40685d090c  push rcx
00007a40685d090d  push rdx
00007a40685d090e  push rdi
00007a40685d090f  push rsi
00007a40685d0910  push r8
00007a40685d0912  push r9
00007a40685d0914  push r10
00007a40685d0916  push r11
00007a40685d0918  sub rsp, 0xF0
00007a40685d091f  vmovaps [rsp], xmm0
00007a40685d0924  vmovaps [rsp+0x10], xmm1
00007a40685d092a  vmovaps [rsp+0x20], xmm2
00007a40685d0930  vmovaps [rsp+0x30], xmm3
00007a40685d0936  vmovaps [rsp+0x40], xmm4
00007a40685d093c  vmovaps [rsp+0x50], xmm5
00007a40685d0942  vmovaps [rsp+0x60], xmm6
00007a40685d0948  vmovaps [rsp+0x70], xmm7
00007a40685d094e  vmovaps [rsp+0x80], xmm8
00007a40685d0957  vmovaps [rsp+0x90], xmm9
00007a40685d0960  vmovaps [rsp+0xA0], xmm10
00007a40685d0969  vmovaps [rsp+0xB0], xmm11
00007a40685d0972  vmovaps [rsp+0xC0], xmm12
00007a40685d097b  vmovaps [rsp+0xD0], xmm13
00007a40685d0984  vmovaps [rsp+0xE0], xmm14
00007a40685d098d  sub rsp, 0x30
00007a40685d0991  movaps [rsp], xmm15
00007a40685d0996  movaps [rsp+0x10], xmm14
00007a40685d099c  movaps [rsp+0x20], xmm1
00007a40685d09a1  lea rdi, [rsp]
00007a40685d09a5  mov esi, 0x00
00007a40685d09aa  mov rax, 0x56F679577530
00007a40685d09b4  call rax
00007a40685d09b6  movaps xmm15, [rsp]
00007a40685d09bb  add rsp, 0x30
00007a40685d09bf  vmovaps xmm0, [rsp]
00007a40685d09c4  vmovaps xmm1, [rsp+0x10]
00007a40685d09ca  vmovaps xmm2, [rsp+0x20]
00007a40685d09d0  vmovaps xmm3, [rsp+0x30]
00007a40685d09d6  vmovaps xmm4, [rsp+0x40]
00007a40685d09dc  vmovaps xmm5, [rsp+0x50]
00007a40685d09e2  vmovaps xmm6, [rsp+0x60]
00007a40685d09e8  vmovaps xmm7, [rsp+0x70]
00007a40685d09ee  vmovaps xmm8, [rsp+0x80]
00007a40685d09f7  vmovaps xmm9, [rsp+0x90]
00007a40685d0a00  vmovaps xmm10, [rsp+0xA0]
00007a40685d0a09  vmovaps xmm11, [rsp+0xB0]
00007a40685d0a12  vmovaps xmm12, [rsp+0xC0]
00007a40685d0a1b  vmovaps xmm13, [rsp+0xD0]
00007a40685d0a24  vmovaps xmm14, [rsp+0xE0]
00007a40685d0a2d  add rsp, 0xF0
00007a40685d0a34  pop r11
00007a40685d0a36  pop r10
00007a40685d0a38  pop r9
00007a40685d0a3a  pop r8
00007a40685d0a3c  pop rsi
00007a40685d0a3d  pop rdi
00007a40685d0a3e  pop rdx
00007a40685d0a3f  pop rcx
00007a40685d0a40  pop rax
00007a40685d0a41  add rsp, 0x08
00007a40685d0a45  jmp 0x00007A40685CF617
00007a40685d0a4a  sub rsp, 0x08
00007a40685d0a4e  push rax
00007a40685d0a4f  push rcx
00007a40685d0a50  push rdx
00007a40685d0a51  push rdi
00007a40685d0a52  push rsi
00007a40685d0a53  push r8
00007a40685d0a55  push r9
00007a40685d0a57  push r10
00007a40685d0a59  push r11
00007a40685d0a5b  sub rsp, 0xF0
00007a40685d0a62  vmovaps [rsp], xmm0
00007a40685d0a67  vmovaps [rsp+0x10], xmm2
00007a40685d0a6d  vmovaps [rsp+0x20], xmm3
00007a40685d0a73  vmovaps [rsp+0x30], xmm4
00007a40685d0a79  vmovaps [rsp+0x40], xmm5
00007a40685d0a7f  vmovaps [rsp+0x50], xmm6
00007a40685d0a85  vmovaps [rsp+0x60], xmm7
00007a40685d0a8b  vmovaps [rsp+0x70], xmm8
00007a40685d0a91  vmovaps [rsp+0x80], xmm9
00007a40685d0a9a  vmovaps [rsp+0x90], xmm10
00007a40685d0aa3  vmovaps [rsp+0xA0], xmm11
00007a40685d0aac  vmovaps [rsp+0xB0], xmm12
00007a40685d0ab5  vmovaps [rsp+0xC0], xmm13
00007a40685d0abe  vmovaps [rsp+0xD0], xmm14
00007a40685d0ac7  vmovaps [rsp+0xE0], xmm15
00007a40685d0ad0  sub rsp, 0x30
00007a40685d0ad4  movaps [rsp], xmm1
00007a40685d0ad8  movaps [rsp+0x10], xmm14
00007a40685d0ade  movaps [rsp+0x20], xmm10
00007a40685d0ae4  lea rdi, [rsp]
00007a40685d0ae8  mov esi, 0x00
00007a40685d0aed  mov rax, 0x56F679577530
00007a40685d0af7  call rax
00007a40685d0af9  movaps xmm1, [rsp]
00007a40685d0afd  add rsp, 0x30
00007a40685d0b01  vmovaps xmm0, [rsp]
00007a40685d0b06  vmovaps xmm2, [rsp+0x10]
00007a40685d0b0c  vmovaps xmm3, [rsp+0x20]
00007a40685d0b12  vmovaps xmm4, [rsp+0x30]
00007a40685d0b18  vmovaps xmm5, [rsp+0x40]
00007a40685d0b1e  vmovaps xmm6, [rsp+0x50]
00007a40685d0b24  vmovaps xmm7, [rsp+0x60]
00007a40685d0b2a  vmovaps xmm8, [rsp+0x70]
00007a40685d0b30  vmovaps xmm9, [rsp+0x80]
00007a40685d0b39  vmovaps xmm10, [rsp+0x90]
00007a40685d0b42  vmovaps xmm11, [rsp+0xA0]
00007a40685d0b4b  vmovaps xmm12, [rsp+0xB0]
00007a40685d0b54  vmovaps xmm13, [rsp+0xC0]
00007a40685d0b5d  vmovaps xmm14, [rsp+0xD0]
00007a40685d0b66  vmovaps xmm15, [rsp+0xE0]
00007a40685d0b6f  add rsp, 0xF0
00007a40685d0b76  pop r11
00007a40685d0b78  pop r10
00007a40685d0b7a  pop r9
00007a40685d0b7c  pop r8
00007a40685d0b7e  pop rsi
00007a40685d0b7f  pop rdi
00007a40685d0b80  pop rdx
00007a40685d0b81  pop rcx
00007a40685d0b82  pop rax
00007a40685d0b83  add rsp, 0x08
00007a40685d0b87  jmp 0x00007A40685CF631
00007a40685d0b8c  sub rsp, 0x08
00007a40685d0b90  push rax
00007a40685d0b91  push rcx
00007a40685d0b92  push rdx
00007a40685d0b93  push rdi
00007a40685d0b94  push rsi
00007a40685d0b95  push r8
00007a40685d0b97  push r9
00007a40685d0b99  push r10
00007a40685d0b9b  push r11
00007a40685d0b9d  sub rsp, 0xF0
00007a40685d0ba4  vmovaps [rsp], xmm0
00007a40685d0ba9  vmovaps [rsp+0x10], xmm1
00007a40685d0baf  vmovaps [rsp+0x20], xmm2
00007a40685d0bb5  vmovaps [rsp+0x30], xmm3
00007a40685d0bbb  vmovaps [rsp+0x40], xmm4
00007a40685d0bc1  vmovaps [rsp+0x50], xmm5
00007a40685d0bc7  vmovaps [rsp+0x60], xmm6
00007a40685d0bcd  vmovaps [rsp+0x70], xmm7
00007a40685d0bd3  vmovaps [rsp+0x80], xmm8
00007a40685d0bdc  vmovaps [rsp+0x90], xmm9
00007a40685d0be5  vmovaps [rsp+0xA0], xmm10
00007a40685d0bee  vmovaps [rsp+0xB0], xmm11
00007a40685d0bf7  vmovaps [rsp+0xC0], xmm12
00007a40685d0c00  vmovaps [rsp+0xD0], xmm14
00007a40685d0c09  vmovaps [rsp+0xE0], xmm15
00007a40685d0c12  sub rsp, 0x30
00007a40685d0c16  movaps [rsp], xmm13
00007a40685d0c1b  movaps [rsp+0x10], xmm14
00007a40685d0c21  movaps [rsp+0x20], xmm2
00007a40685d0c26  lea rdi, [rsp]
00007a40685d0c2a  mov esi, 0x00
00007a40685d0c2f  mov rax, 0x56F679577530
00007a40685d0c39  call rax
00007a40685d0c3b  movaps xmm13, [rsp]
00007a40685d0c40  add rsp, 0x30
00007a40685d0c44  vmovaps xmm0, [rsp]
00007a40685d0c49  vmovaps xmm1, [rsp+0x10]
00007a40685d0c4f  vmovaps xmm2, [rsp+0x20]
00007a40685d0c55  vmovaps xmm3, [rsp+0x30]
00007a40685d0c5b  vmovaps xmm4, [rsp+0x40]
00007a40685d0c61  vmovaps xmm5, [rsp+0x50]
00007a40685d0c67  vmovaps xmm6, [rsp+0x60]
00007a40685d0c6d  vmovaps xmm7, [rsp+0x70]
00007a40685d0c73  vmovaps xmm8, [rsp+0x80]
00007a40685d0c7c  vmovaps xmm9, [rsp+0x90]
00007a40685d0c85  vmovaps xmm10, [rsp+0xA0]
00007a40685d0c8e  vmovaps xmm11, [rsp+0xB0]
00007a40685d0c97  vmovaps xmm12, [rsp+0xC0]
00007a40685d0ca0  vmovaps xmm14, [rsp+0xD0]
00007a40685d0ca9  vmovaps xmm15, [rsp+0xE0]
00007a40685d0cb2  add rsp, 0xF0
00007a40685d0cb9  pop r11
00007a40685d0cbb  pop r10
00007a40685d0cbd  pop r9
00007a40685d0cbf  pop r8
00007a40685d0cc1  pop rsi
00007a40685d0cc2  pop rdi
00007a40685d0cc3  pop rdx
00007a40685d0cc4  pop rcx
00007a40685d0cc5  pop rax
00007a40685d0cc6  add rsp, 0x08
00007a40685d0cca  jmp 0x00007A40685CF64C
00007a40685d0ccf  sub rsp, 0x08
00007a40685d0cd3  push rax
00007a40685d0cd4  push rcx
00007a40685d0cd5  push rdx
00007a40685d0cd6  push rdi
00007a40685d0cd7  push rsi
00007a40685d0cd8  push r8
00007a40685d0cda  push r9
00007a40685d0cdc  push r10
00007a40685d0cde  push r11
00007a40685d0ce0  sub rsp, 0xF0
00007a40685d0ce7  vmovaps [rsp], xmm0
00007a40685d0cec  vmovaps [rsp+0x10], xmm2
00007a40685d0cf2  vmovaps [rsp+0x20], xmm3
00007a40685d0cf8  vmovaps [rsp+0x30], xmm4
00007a40685d0cfe  vmovaps [rsp+0x40], xmm5
00007a40685d0d04  vmovaps [rsp+0x50], xmm6
00007a40685d0d0a  vmovaps [rsp+0x60], xmm7
00007a40685d0d10  vmovaps [rsp+0x70], xmm8
00007a40685d0d16  vmovaps [rsp+0x80], xmm9
00007a40685d0d1f  vmovaps [rsp+0x90], xmm10
00007a40685d0d28  vmovaps [rsp+0xA0], xmm11
00007a40685d0d31  vmovaps [rsp+0xB0], xmm12
00007a40685d0d3a  vmovaps [rsp+0xC0], xmm13
00007a40685d0d43  vmovaps [rsp+0xD0], xmm14
00007a40685d0d4c  vmovaps [rsp+0xE0], xmm15
00007a40685d0d55  sub rsp, 0x30
00007a40685d0d59  movaps [rsp], xmm1
00007a40685d0d5d  movaps [rsp+0x10], xmm10
00007a40685d0d63  movaps [rsp+0x20], xmm2
00007a40685d0d68  lea rdi, [rsp]
00007a40685d0d6c  mov esi, 0x00
00007a40685d0d71  mov rax, 0x56F679577530
00007a40685d0d7b  call rax
00007a40685d0d7d  movaps xmm1, [rsp]
00007a40685d0d81  add rsp, 0x30
00007a40685d0d85  vmovaps xmm0, [rsp]
00007a40685d0d8a  vmovaps xmm2, [rsp+0x10]
00007a40685d0d90  vmovaps xmm3, [rsp+0x20]
00007a40685d0d96  vmovaps xmm4, [rsp+0x30]
00007a40685d0d9c  vmovaps xmm5, [rsp+0x40]
00007a40685d0da2  vmovaps xmm6, [rsp+0x50]
00007a40685d0da8  vmovaps xmm7, [rsp+0x60]
00007a40685d0dae  vmovaps xmm8, [rsp+0x70]
00007a40685d0db4  vmovaps xmm9, [rsp+0x80]
00007a40685d0dbd  vmovaps xmm10, [rsp+0x90]
00007a40685d0dc6  vmovaps xmm11, [rsp+0xA0]
00007a40685d0dcf  vmovaps xmm12, [rsp+0xB0]
00007a40685d0dd8  vmovaps xmm13, [rsp+0xC0]
00007a40685d0de1  vmovaps xmm14, [rsp+0xD0]
00007a40685d0dea  vmovaps xmm15, [rsp+0xE0]
00007a40685d0df3  add rsp, 0xF0
00007a40685d0dfa  pop r11
00007a40685d0dfc  pop r10
00007a40685d0dfe  pop r9
00007a40685d0e00  pop r8
00007a40685d0e02  pop rsi
00007a40685d0e03  pop rdi
00007a40685d0e04  pop rdx
00007a40685d0e05  pop rcx
00007a40685d0e06  pop rax
00007a40685d0e07  add rsp, 0x08
00007a40685d0e0b  jmp 0x00007A40685CF6B4
00007a40685d0e10  sub rsp, 0x08
00007a40685d0e14  push rax
00007a40685d0e15  push rcx
00007a40685d0e16  push rdx
00007a40685d0e17  push rdi
00007a40685d0e18  push rsi
00007a40685d0e19  push r8
00007a40685d0e1b  push r9
00007a40685d0e1d  push r10
00007a40685d0e1f  push r11
00007a40685d0e21  sub rsp, 0xF0
00007a40685d0e28  vmovaps [rsp], xmm0
00007a40685d0e2d  vmovaps [rsp+0x10], xmm1
00007a40685d0e33  vmovaps [rsp+0x20], xmm2
00007a40685d0e39  vmovaps [rsp+0x30], xmm3
00007a40685d0e3f  vmovaps [rsp+0x40], xmm4
00007a40685d0e45  vmovaps [rsp+0x50], xmm5
00007a40685d0e4b  vmovaps [rsp+0x60], xmm6
00007a40685d0e51  vmovaps [rsp+0x70], xmm7
00007a40685d0e57  vmovaps [rsp+0x80], xmm8
00007a40685d0e60  vmovaps [rsp+0x90], xmm9
00007a40685d0e69  vmovaps [rsp+0xA0], xmm10
00007a40685d0e72  vmovaps [rsp+0xB0], xmm11
00007a40685d0e7b  vmovaps [rsp+0xC0], xmm12
00007a40685d0e84  vmovaps [rsp+0xD0], xmm13
00007a40685d0e8d  vmovaps [rsp+0xE0], xmm14
00007a40685d0e96  sub rsp, 0x30
00007a40685d0e9a  movaps [rsp], xmm15
00007a40685d0e9f  movaps [rsp+0x10], xmm10
00007a40685d0ea5  movaps [rsp+0x20], xmm2
00007a40685d0eaa  lea rdi, [rsp]
00007a40685d0eae  mov esi, 0x00
00007a40685d0eb3  mov rax, 0x56F679577530
00007a40685d0ebd  call rax
00007a40685d0ebf  movaps xmm15, [rsp]
00007a40685d0ec4  add rsp, 0x30
00007a40685d0ec8  vmovaps xmm0, [rsp]
00007a40685d0ecd  vmovaps xmm1, [rsp+0x10]
00007a40685d0ed3  vmovaps xmm2, [rsp+0x20]
00007a40685d0ed9  vmovaps xmm3, [rsp+0x30]
00007a40685d0edf  vmovaps xmm4, [rsp+0x40]
00007a40685d0ee5  vmovaps xmm5, [rsp+0x50]
00007a40685d0eeb  vmovaps xmm6, [rsp+0x60]
00007a40685d0ef1  vmovaps xmm7, [rsp+0x70]
00007a40685d0ef7  vmovaps xmm8, [rsp+0x80]
00007a40685d0f00  vmovaps xmm9, [rsp+0x90]
00007a40685d0f09  vmovaps xmm10, [rsp+0xA0]
00007a40685d0f12  vmovaps xmm11, [rsp+0xB0]
00007a40685d0f1b  vmovaps xmm12, [rsp+0xC0]
00007a40685d0f24  vmovaps xmm13, [rsp+0xD0]
00007a40685d0f2d  vmovaps xmm14, [rsp+0xE0]
00007a40685d0f36  add rsp, 0xF0
00007a40685d0f3d  pop r11
00007a40685d0f3f  pop r10
00007a40685d0f41  pop r9
00007a40685d0f43  pop r8
00007a40685d0f45  pop rsi
00007a40685d0f46  pop rdi
00007a40685d0f47  pop rdx
00007a40685d0f48  pop rcx
00007a40685d0f49  pop rax
00007a40685d0f4a  add rsp, 0x08
00007a40685d0f4e  jmp 0x00007A40685CF706
00007a40685d0f53  sub rsp, 0x08
00007a40685d0f57  push rax
00007a40685d0f58  push rcx
00007a40685d0f59  push rdx
00007a40685d0f5a  push rdi
00007a40685d0f5b  push rsi
00007a40685d0f5c  push r8
00007a40685d0f5e  push r9
00007a40685d0f60  push r10
00007a40685d0f62  push r11
00007a40685d0f64  sub rsp, 0xF0
00007a40685d0f6b  vmovaps [rsp], xmm0
00007a40685d0f70  vmovaps [rsp+0x10], xmm2
00007a40685d0f76  vmovaps [rsp+0x20], xmm3
00007a40685d0f7c  vmovaps [rsp+0x30], xmm4
00007a40685d0f82  vmovaps [rsp+0x40], xmm5
00007a40685d0f88  vmovaps [rsp+0x50], xmm6
00007a40685d0f8e  vmovaps [rsp+0x60], xmm7
00007a40685d0f94  vmovaps [rsp+0x70], xmm8
00007a40685d0f9a  vmovaps [rsp+0x80], xmm9
00007a40685d0fa3  vmovaps [rsp+0x90], xmm10
00007a40685d0fac  vmovaps [rsp+0xA0], xmm11
00007a40685d0fb5  vmovaps [rsp+0xB0], xmm12
00007a40685d0fbe  vmovaps [rsp+0xC0], xmm13
00007a40685d0fc7  vmovaps [rsp+0xD0], xmm14
00007a40685d0fd0  vmovaps [rsp+0xE0], xmm15
00007a40685d0fd9  sub rsp, 0x30
00007a40685d0fdd  movaps [rsp], xmm1
00007a40685d0fe1  movaps [rsp+0x10], xmm10
00007a40685d0fe7  movaps [rsp+0x20], xmm12
00007a40685d0fed  lea rdi, [rsp]
00007a40685d0ff1  mov esi, 0x00
00007a40685d0ff6  mov rax, 0x56F679577530
00007a40685d1000  call rax
00007a40685d1002  movaps xmm1, [rsp]
00007a40685d1006  add rsp, 0x30
00007a40685d100a  vmovaps xmm0, [rsp]
00007a40685d100f  vmovaps xmm2, [rsp+0x10]
00007a40685d1015  vmovaps xmm3, [rsp+0x20]
00007a40685d101b  vmovaps xmm4, [rsp+0x30]
00007a40685d1021  vmovaps xmm5, [rsp+0x40]
00007a40685d1027  vmovaps xmm6, [rsp+0x50]
00007a40685d102d  vmovaps xmm7, [rsp+0x60]
00007a40685d1033  vmovaps xmm8, [rsp+0x70]
00007a40685d1039  vmovaps xmm9, [rsp+0x80]
00007a40685d1042  vmovaps xmm10, [rsp+0x90]
00007a40685d104b  vmovaps xmm11, [rsp+0xA0]
00007a40685d1054  vmovaps xmm12, [rsp+0xB0]
00007a40685d105d  vmovaps xmm13, [rsp+0xC0]
00007a40685d1066  vmovaps xmm14, [rsp+0xD0]
00007a40685d106f  vmovaps xmm15, [rsp+0xE0]
00007a40685d1078  add rsp, 0xF0
00007a40685d107f  pop r11
00007a40685d1081  pop r10
00007a40685d1083  pop r9
00007a40685d1085  pop r8
00007a40685d1087  pop rsi
00007a40685d1088  pop rdi
00007a40685d1089  pop rdx
00007a40685d108a  pop rcx
00007a40685d108b  pop rax
00007a40685d108c  add rsp, 0x08
00007a40685d1090  jmp 0x00007A40685CF732
00007a40685d1095  sub rsp, 0x08
00007a40685d1099  push rax
00007a40685d109a  push rcx
00007a40685d109b  push rdx
00007a40685d109c  push rdi
00007a40685d109d  push rsi
00007a40685d109e  push r8
00007a40685d10a0  push r9
00007a40685d10a2  push r10
00007a40685d10a4  push r11
00007a40685d10a6  sub rsp, 0xF0
00007a40685d10ad  vmovaps [rsp], xmm0
00007a40685d10b2  vmovaps [rsp+0x10], xmm1
00007a40685d10b8  vmovaps [rsp+0x20], xmm2
00007a40685d10be  vmovaps [rsp+0x30], xmm3
00007a40685d10c4  vmovaps [rsp+0x40], xmm4
00007a40685d10ca  vmovaps [rsp+0x50], xmm5
00007a40685d10d0  vmovaps [rsp+0x60], xmm6
00007a40685d10d6  vmovaps [rsp+0x70], xmm7
00007a40685d10dc  vmovaps [rsp+0x80], xmm8
00007a40685d10e5  vmovaps [rsp+0x90], xmm9
00007a40685d10ee  vmovaps [rsp+0xA0], xmm10
00007a40685d10f7  vmovaps [rsp+0xB0], xmm11
00007a40685d1100  vmovaps [rsp+0xC0], xmm12
00007a40685d1109  vmovaps [rsp+0xD0], xmm13
00007a40685d1112  vmovaps [rsp+0xE0], xmm14
00007a40685d111b  sub rsp, 0x30
00007a40685d111f  movaps [rsp], xmm15
00007a40685d1124  movaps [rsp+0x10], xmm10
00007a40685d112a  movaps [rsp+0x20], xmm12
00007a40685d1130  lea rdi, [rsp]
00007a40685d1134  mov esi, 0x00
00007a40685d1139  mov rax, 0x56F679577530
00007a40685d1143  call rax
00007a40685d1145  movaps xmm15, [rsp]
00007a40685d114a  add rsp, 0x30
00007a40685d114e  vmovaps xmm0, [rsp]
00007a40685d1153  vmovaps xmm1, [rsp+0x10]
00007a40685d1159  vmovaps xmm2, [rsp+0x20]
00007a40685d115f  vmovaps xmm3, [rsp+0x30]
00007a40685d1165  vmovaps xmm4, [rsp+0x40]
00007a40685d116b  vmovaps xmm5, [rsp+0x50]
00007a40685d1171  vmovaps xmm6, [rsp+0x60]
00007a40685d1177  vmovaps xmm7, [rsp+0x70]
00007a40685d117d  vmovaps xmm8, [rsp+0x80]
00007a40685d1186  vmovaps xmm9, [rsp+0x90]
00007a40685d118f  vmovaps xmm10, [rsp+0xA0]
00007a40685d1198  vmovaps xmm11, [rsp+0xB0]
00007a40685d11a1  vmovaps xmm12, [rsp+0xC0]
00007a40685d11aa  vmovaps xmm13, [rsp+0xD0]
00007a40685d11b3  vmovaps xmm14, [rsp+0xE0]
00007a40685d11bc  add rsp, 0xF0
00007a40685d11c3  pop r11
00007a40685d11c5  pop r10
00007a40685d11c7  pop r9
00007a40685d11c9  pop r8
00007a40685d11cb  pop rsi
00007a40685d11cc  pop rdi
00007a40685d11cd  pop rdx
00007a40685d11ce  pop rcx
00007a40685d11cf  pop rax
00007a40685d11d0  add rsp, 0x08
00007a40685d11d4  jmp 0x00007A40685CF75E
00007a40685d11d9  call 0x00007A40683FF430
00007a40685d11de  jmp 0x00007A40685CF7EE
00007a40685d11e3  call 0x00007A40683FF430
00007a40685d11e8  jmp 0x00007A40685CF801
00007a40685d11ed  sub rsp, 0x08
00007a40685d11f1  push rax
00007a40685d11f2  push rcx
00007a40685d11f3  push rdx
00007a40685d11f4  push rdi
00007a40685d11f5  push rsi
00007a40685d11f6  push r8
00007a40685d11f8  push r9
00007a40685d11fa  push r10
00007a40685d11fc  push r11
00007a40685d11fe  sub rsp, 0xF0
00007a40685d1205  vmovaps [rsp], xmm0
00007a40685d120a  vmovaps [rsp+0x10], xmm2
00007a40685d1210  vmovaps [rsp+0x20], xmm3
00007a40685d1216  vmovaps [rsp+0x30], xmm4
00007a40685d121c  vmovaps [rsp+0x40], xmm5
00007a40685d1222  vmovaps [rsp+0x50], xmm6
00007a40685d1228  vmovaps [rsp+0x60], xmm7
00007a40685d122e  vmovaps [rsp+0x70], xmm8
00007a40685d1234  vmovaps [rsp+0x80], xmm9
00007a40685d123d  vmovaps [rsp+0x90], xmm10
00007a40685d1246  vmovaps [rsp+0xA0], xmm11
00007a40685d124f  vmovaps [rsp+0xB0], xmm12
00007a40685d1258  vmovaps [rsp+0xC0], xmm13
00007a40685d1261  vmovaps [rsp+0xD0], xmm14
00007a40685d126a  vmovaps [rsp+0xE0], xmm15
00007a40685d1273  sub rsp, 0x30
00007a40685d1277  movaps [rsp], xmm1
00007a40685d127b  movaps [rsp+0x10], xmm13
00007a40685d1281  movaps [rsp+0x20], xmm2
00007a40685d1286  lea rdi, [rsp]
00007a40685d128a  mov esi, 0x00
00007a40685d128f  mov rax, 0x56F679577530
00007a40685d1299  call rax
00007a40685d129b  movaps xmm1, [rsp]
00007a40685d129f  add rsp, 0x30
00007a40685d12a3  vmovaps xmm0, [rsp]
00007a40685d12a8  vmovaps xmm2, [rsp+0x10]
00007a40685d12ae  vmovaps xmm3, [rsp+0x20]
00007a40685d12b4  vmovaps xmm4, [rsp+0x30]
00007a40685d12ba  vmovaps xmm5, [rsp+0x40]
00007a40685d12c0  vmovaps xmm6, [rsp+0x50]
00007a40685d12c6  vmovaps xmm7, [rsp+0x60]
00007a40685d12cc  vmovaps xmm8, [rsp+0x70]
00007a40685d12d2  vmovaps xmm9, [rsp+0x80]
00007a40685d12db  vmovaps xmm10, [rsp+0x90]
00007a40685d12e4  vmovaps xmm11, [rsp+0xA0]
00007a40685d12ed  vmovaps xmm12, [rsp+0xB0]
00007a40685d12f6  vmovaps xmm13, [rsp+0xC0]
00007a40685d12ff  vmovaps xmm14, [rsp+0xD0]
00007a40685d1308  vmovaps xmm15, [rsp+0xE0]
00007a40685d1311  add rsp, 0xF0
00007a40685d1318  pop r11
00007a40685d131a  pop r10
00007a40685d131c  pop r9
00007a40685d131e  pop r8
00007a40685d1320  pop rsi
00007a40685d1321  pop rdi
00007a40685d1322  pop rdx
00007a40685d1323  pop rcx
00007a40685d1324  pop rax
00007a40685d1325  add rsp, 0x08
00007a40685d1329  jmp 0x00007A40685CF82C
00007a40685d132e  call 0x00007A406840E760
00007a40685d1333  jmp 0x00007A40685CF839
00007a40685d1338  sub rsp, 0x08
00007a40685d133c  push rax
00007a40685d133d  push rcx
00007a40685d133e  push rdx
00007a40685d133f  push rdi
00007a40685d1340  push rsi
00007a40685d1341  push r8
00007a40685d1343  push r9
00007a40685d1345  push r10
00007a40685d1347  push r11
00007a40685d1349  sub rsp, 0xF0
00007a40685d1350  vmovaps [rsp], xmm0
00007a40685d1355  vmovaps [rsp+0x10], xmm1
00007a40685d135b  vmovaps [rsp+0x20], xmm2
00007a40685d1361  vmovaps [rsp+0x30], xmm3
00007a40685d1367  vmovaps [rsp+0x40], xmm4
00007a40685d136d  vmovaps [rsp+0x50], xmm5
00007a40685d1373  vmovaps [rsp+0x60], xmm6
00007a40685d1379  vmovaps [rsp+0x70], xmm7
00007a40685d137f  vmovaps [rsp+0x80], xmm8
00007a40685d1388  vmovaps [rsp+0x90], xmm9
00007a40685d1391  vmovaps [rsp+0xA0], xmm10
00007a40685d139a  vmovaps [rsp+0xB0], xmm11
00007a40685d13a3  vmovaps [rsp+0xC0], xmm12
00007a40685d13ac  vmovaps [rsp+0xD0], xmm14
00007a40685d13b5  vmovaps [rsp+0xE0], xmm15
00007a40685d13be  sub rsp, 0x30
00007a40685d13c2  movaps [rsp], xmm13
00007a40685d13c7  movaps [rsp+0x10], xmm2
00007a40685d13cc  movaps [rsp+0x20], xmm1
00007a40685d13d1  lea rdi, [rsp]
00007a40685d13d5  mov esi, 0x00
00007a40685d13da  mov rax, 0x56F679577530
00007a40685d13e4  call rax
00007a40685d13e6  movaps xmm13, [rsp]
00007a40685d13eb  add rsp, 0x30
00007a40685d13ef  vmovaps xmm0, [rsp]
00007a40685d13f4  vmovaps xmm1, [rsp+0x10]
00007a40685d13fa  vmovaps xmm2, [rsp+0x20]
00007a40685d1400  vmovaps xmm3, [rsp+0x30]
00007a40685d1406  vmovaps xmm4, [rsp+0x40]
00007a40685d140c  vmovaps xmm5, [rsp+0x50]
00007a40685d1412  vmovaps xmm6, [rsp+0x60]
00007a40685d1418  vmovaps xmm7, [rsp+0x70]
00007a40685d141e  vmovaps xmm8, [rsp+0x80]
00007a40685d1427  vmovaps xmm9, [rsp+0x90]
00007a40685d1430  vmovaps xmm10, [rsp+0xA0]
00007a40685d1439  vmovaps xmm11, [rsp+0xB0]
00007a40685d1442  vmovaps xmm12, [rsp+0xC0]
00007a40685d144b  vmovaps xmm14, [rsp+0xD0]
00007a40685d1454  vmovaps xmm15, [rsp+0xE0]
00007a40685d145d  add rsp, 0xF0
00007a40685d1464  pop r11
00007a40685d1466  pop r10
00007a40685d1468  pop r9
00007a40685d146a  pop r8
00007a40685d146c  pop rsi
00007a40685d146d  pop rdi
00007a40685d146e  pop rdx
00007a40685d146f  pop rcx
00007a40685d1470  pop rax
00007a40685d1471  add rsp, 0x08
00007a40685d1475  jmp 0x00007A40685CF878
00007a40685d147a  sub rsp, 0x08
00007a40685d147e  push rax
00007a40685d147f  push rcx
00007a40685d1480  push rdx
00007a40685d1481  push rdi
00007a40685d1482  push rsi
00007a40685d1483  push r8
00007a40685d1485  push r9
00007a40685d1487  push r10
00007a40685d1489  push r11
00007a40685d148b  sub rsp, 0xF0
00007a40685d1492  vmovaps [rsp], xmm0
00007a40685d1497  vmovaps [rsp+0x10], xmm2
00007a40685d149d  vmovaps [rsp+0x20], xmm3
00007a40685d14a3  vmovaps [rsp+0x30], xmm4
00007a40685d14a9  vmovaps [rsp+0x40], xmm5
00007a40685d14af  vmovaps [rsp+0x50], xmm6
00007a40685d14b5  vmovaps [rsp+0x60], xmm7
00007a40685d14bb  vmovaps [rsp+0x70], xmm8
00007a40685d14c1  vmovaps [rsp+0x80], xmm9
00007a40685d14ca  vmovaps [rsp+0x90], xmm10
00007a40685d14d3  vmovaps [rsp+0xA0], xmm11
00007a40685d14dc  vmovaps [rsp+0xB0], xmm12
00007a40685d14e5  vmovaps [rsp+0xC0], xmm13
00007a40685d14ee  vmovaps [rsp+0xD0], xmm14
00007a40685d14f7  vmovaps [rsp+0xE0], xmm15
00007a40685d1500  sub rsp, 0x30
00007a40685d1504  movaps [rsp], xmm1
00007a40685d1508  movaps [rsp+0x10], xmm15
00007a40685d150e  movaps [rsp+0x20], xmm2
00007a40685d1513  lea rdi, [rsp]
00007a40685d1517  mov esi, 0x00
00007a40685d151c  mov rax, 0x56F679577530
00007a40685d1526  call rax
00007a40685d1528  movaps xmm1, [rsp]
00007a40685d152c  add rsp, 0x30
00007a40685d1530  vmovaps xmm0, [rsp]
00007a40685d1535  vmovaps xmm2, [rsp+0x10]
00007a40685d153b  vmovaps xmm3, [rsp+0x20]
00007a40685d1541  vmovaps xmm4, [rsp+0x30]
00007a40685d1547  vmovaps xmm5, [rsp+0x40]
00007a40685d154d  vmovaps xmm6, [rsp+0x50]
00007a40685d1553  vmovaps xmm7, [rsp+0x60]
00007a40685d1559  vmovaps xmm8, [rsp+0x70]
00007a40685d155f  vmovaps xmm9, [rsp+0x80]
00007a40685d1568  vmovaps xmm10, [rsp+0x90]
00007a40685d1571  vmovaps xmm11, [rsp+0xA0]
00007a40685d157a  vmovaps xmm12, [rsp+0xB0]
00007a40685d1583  vmovaps xmm13, [rsp+0xC0]
00007a40685d158c  vmovaps xmm14, [rsp+0xD0]
00007a40685d1595  vmovaps xmm15, [rsp+0xE0]
00007a40685d159e  add rsp, 0xF0
00007a40685d15a5  pop r11
00007a40685d15a7  pop r10
00007a40685d15a9  pop r9
00007a40685d15ab  pop r8
00007a40685d15ad  pop rsi
00007a40685d15ae  pop rdi
00007a40685d15af  pop rdx
00007a40685d15b0  pop rcx
00007a40685d15b1  pop rax
00007a40685d15b2  add rsp, 0x08
00007a40685d15b6  jmp 0x00007A40685CF8AC
00007a40685d15bb  sub rsp, 0x08
00007a40685d15bf  push rax
00007a40685d15c0  push rcx
00007a40685d15c1  push rdx
00007a40685d15c2  push rdi
00007a40685d15c3  push rsi
00007a40685d15c4  push r8
00007a40685d15c6  push r9
00007a40685d15c8  push r10
00007a40685d15ca  push r11
00007a40685d15cc  sub rsp, 0xF0
00007a40685d15d3  vmovaps [rsp], xmm0
00007a40685d15d8  vmovaps [rsp+0x10], xmm1
00007a40685d15de  vmovaps [rsp+0x20], xmm2
00007a40685d15e4  vmovaps [rsp+0x30], xmm3
00007a40685d15ea  vmovaps [rsp+0x40], xmm4
00007a40685d15f0  vmovaps [rsp+0x50], xmm5
00007a40685d15f6  vmovaps [rsp+0x60], xmm6
00007a40685d15fc  vmovaps [rsp+0x70], xmm7
00007a40685d1602  vmovaps [rsp+0x80], xmm8
00007a40685d160b  vmovaps [rsp+0x90], xmm9
00007a40685d1614  vmovaps [rsp+0xA0], xmm10
00007a40685d161d  vmovaps [rsp+0xB0], xmm11
00007a40685d1626  vmovaps [rsp+0xC0], xmm12
00007a40685d162f  vmovaps [rsp+0xD0], xmm13
00007a40685d1638  vmovaps [rsp+0xE0], xmm15
00007a40685d1641  sub rsp, 0x30
00007a40685d1645  movaps [rsp], xmm14
00007a40685d164a  movaps [rsp+0x10], xmm2
00007a40685d164f  movaps [rsp+0x20], xmm15
00007a40685d1655  lea rdi, [rsp]
00007a40685d1659  mov esi, 0x00
00007a40685d165e  mov rax, 0x56F679577530
00007a40685d1668  call rax
00007a40685d166a  movaps xmm14, [rsp]
00007a40685d166f  add rsp, 0x30
00007a40685d1673  vmovaps xmm0, [rsp]
00007a40685d1678  vmovaps xmm1, [rsp+0x10]
00007a40685d167e  vmovaps xmm2, [rsp+0x20]
00007a40685d1684  vmovaps xmm3, [rsp+0x30]
00007a40685d168a  vmovaps xmm4, [rsp+0x40]
00007a40685d1690  vmovaps xmm5, [rsp+0x50]
00007a40685d1696  vmovaps xmm6, [rsp+0x60]
00007a40685d169c  vmovaps xmm7, [rsp+0x70]
00007a40685d16a2  vmovaps xmm8, [rsp+0x80]
00007a40685d16ab  vmovaps xmm9, [rsp+0x90]
00007a40685d16b4  vmovaps xmm10, [rsp+0xA0]
00007a40685d16bd  vmovaps xmm11, [rsp+0xB0]
00007a40685d16c6  vmovaps xmm12, [rsp+0xC0]
00007a40685d16cf  vmovaps xmm13, [rsp+0xD0]
00007a40685d16d8  vmovaps xmm15, [rsp+0xE0]
00007a40685d16e1  add rsp, 0xF0
00007a40685d16e8  pop r11
00007a40685d16ea  pop r10
00007a40685d16ec  pop r9
00007a40685d16ee  pop r8
00007a40685d16f0  pop rsi
00007a40685d16f1  pop rdi
00007a40685d16f2  pop rdx
00007a40685d16f3  pop rcx
00007a40685d16f4  pop rax
00007a40685d16f5  add rsp, 0x08
00007a40685d16f9  jmp 0x00007A40685CF8E7
00007a40685d16fe  sub rsp, 0x08
00007a40685d1702  push rax
00007a40685d1703  push rcx
00007a40685d1704  push rdx
00007a40685d1705  push rdi
00007a40685d1706  push rsi
00007a40685d1707  push r8
00007a40685d1709  push r9
00007a40685d170b  push r10
00007a40685d170d  push r11
00007a40685d170f  sub rsp, 0xF0
00007a40685d1716  vmovaps [rsp], xmm0
00007a40685d171b  vmovaps [rsp+0x10], xmm1
00007a40685d1721  vmovaps [rsp+0x20], xmm2
00007a40685d1727  vmovaps [rsp+0x30], xmm3
00007a40685d172d  vmovaps [rsp+0x40], xmm4
00007a40685d1733  vmovaps [rsp+0x50], xmm5
00007a40685d1739  vmovaps [rsp+0x60], xmm6
00007a40685d173f  vmovaps [rsp+0x70], xmm7
00007a40685d1745  vmovaps [rsp+0x80], xmm8
00007a40685d174e  vmovaps [rsp+0x90], xmm9
00007a40685d1757  vmovaps [rsp+0xA0], xmm10
00007a40685d1760  vmovaps [rsp+0xB0], xmm11
00007a40685d1769  vmovaps [rsp+0xC0], xmm12
00007a40685d1772  vmovaps [rsp+0xD0], xmm13
00007a40685d177b  vmovaps [rsp+0xE0], xmm14
00007a40685d1784  sub rsp, 0x30
00007a40685d1788  movaps [rsp], xmm15
00007a40685d178d  movaps [rsp+0x10], xmm2
00007a40685d1792  movaps [rsp+0x20], xmm1
00007a40685d1797  lea rdi, [rsp]
00007a40685d179b  mov esi, 0x00
00007a40685d17a0  mov rax, 0x56F679577530
00007a40685d17aa  call rax
00007a40685d17ac  movaps xmm15, [rsp]
00007a40685d17b1  add rsp, 0x30
00007a40685d17b5  vmovaps xmm0, [rsp]
00007a40685d17ba  vmovaps xmm1, [rsp+0x10]
00007a40685d17c0  vmovaps xmm2, [rsp+0x20]
00007a40685d17c6  vmovaps xmm3, [rsp+0x30]
00007a40685d17cc  vmovaps xmm4, [rsp+0x40]
00007a40685d17d2  vmovaps xmm5, [rsp+0x50]
00007a40685d17d8  vmovaps xmm6, [rsp+0x60]
00007a40685d17de  vmovaps xmm7, [rsp+0x70]
00007a40685d17e4  vmovaps xmm8, [rsp+0x80]
00007a40685d17ed  vmovaps xmm9, [rsp+0x90]
00007a40685d17f6  vmovaps xmm10, [rsp+0xA0]
00007a40685d17ff  vmovaps xmm11, [rsp+0xB0]
00007a40685d1808  vmovaps xmm12, [rsp+0xC0]
00007a40685d1811  vmovaps xmm13, [rsp+0xD0]
00007a40685d181a  vmovaps xmm14, [rsp+0xE0]
00007a40685d1823  add rsp, 0xF0
00007a40685d182a  pop r11
00007a40685d182c  pop r10
00007a40685d182e  pop r9
00007a40685d1830  pop r8
00007a40685d1832  pop rsi
00007a40685d1833  pop rdi
00007a40685d1834  pop rdx
00007a40685d1835  pop rcx
00007a40685d1836  pop rax
00007a40685d1837  add rsp, 0x08
00007a40685d183b  jmp 0x00007A40685CF923
00007a40685d1840  call 0x00007A40683FF430
00007a40685d1845  jmp 0x00007A40685CF930
00007a40685d184a  sub rsp, 0x08
00007a40685d184e  push rax
00007a40685d184f  push rcx
00007a40685d1850  push rdx
00007a40685d1851  push rdi
00007a40685d1852  push rsi
00007a40685d1853  push r8
00007a40685d1855  push r9
00007a40685d1857  push r10
00007a40685d1859  push r11
00007a40685d185b  sub rsp, 0xF0
00007a40685d1862  vmovaps [rsp], xmm0
00007a40685d1867  vmovaps [rsp+0x10], xmm1
00007a40685d186d  vmovaps [rsp+0x20], xmm3
00007a40685d1873  vmovaps [rsp+0x30], xmm4
00007a40685d1879  vmovaps [rsp+0x40], xmm5
00007a40685d187f  vmovaps [rsp+0x50], xmm6
00007a40685d1885  vmovaps [rsp+0x60], xmm7
00007a40685d188b  vmovaps [rsp+0x70], xmm8
00007a40685d1891  vmovaps [rsp+0x80], xmm9
00007a40685d189a  vmovaps [rsp+0x90], xmm10
00007a40685d18a3  vmovaps [rsp+0xA0], xmm11
00007a40685d18ac  vmovaps [rsp+0xB0], xmm12
00007a40685d18b5  vmovaps [rsp+0xC0], xmm13
00007a40685d18be  vmovaps [rsp+0xD0], xmm14
00007a40685d18c7  vmovaps [rsp+0xE0], xmm15
00007a40685d18d0  sub rsp, 0x30
00007a40685d18d4  movaps [rsp], xmm2
00007a40685d18d8  movaps [rsp+0x10], xmm1
00007a40685d18dd  movaps [rsp+0x20], xmm14
00007a40685d18e3  lea rdi, [rsp]
00007a40685d18e7  mov esi, 0x00
00007a40685d18ec  mov rax, 0x56F679577530
00007a40685d18f6  call rax
00007a40685d18f8  movaps xmm2, [rsp]
00007a40685d18fc  add rsp, 0x30
00007a40685d1900  vmovaps xmm0, [rsp]
00007a40685d1905  vmovaps xmm1, [rsp+0x10]
00007a40685d190b  vmovaps xmm3, [rsp+0x20]
00007a40685d1911  vmovaps xmm4, [rsp+0x30]
00007a40685d1917  vmovaps xmm5, [rsp+0x40]
00007a40685d191d  vmovaps xmm6, [rsp+0x50]
00007a40685d1923  vmovaps xmm7, [rsp+0x60]
00007a40685d1929  vmovaps xmm8, [rsp+0x70]
00007a40685d192f  vmovaps xmm9, [rsp+0x80]
00007a40685d1938  vmovaps xmm10, [rsp+0x90]
00007a40685d1941  vmovaps xmm11, [rsp+0xA0]
00007a40685d194a  vmovaps xmm12, [rsp+0xB0]
00007a40685d1953  vmovaps xmm13, [rsp+0xC0]
00007a40685d195c  vmovaps xmm14, [rsp+0xD0]
00007a40685d1965  vmovaps xmm15, [rsp+0xE0]
00007a40685d196e  add rsp, 0xF0
00007a40685d1975  pop r11
00007a40685d1977  pop r10
00007a40685d1979  pop r9
00007a40685d197b  pop r8
00007a40685d197d  pop rsi
00007a40685d197e  pop rdi
00007a40685d197f  pop rdx
00007a40685d1980  pop rcx
00007a40685d1981  pop rax
00007a40685d1982  add rsp, 0x08
00007a40685d1986  jmp 0x00007A40685CF96D
00007a40685d198b  sub rsp, 0x08
00007a40685d198f  push rax
00007a40685d1990  push rcx
00007a40685d1991  push rdx
00007a40685d1992  push rdi
00007a40685d1993  push rsi
00007a40685d1994  push r8
00007a40685d1996  push r9
00007a40685d1998  push r10
00007a40685d199a  push r11
00007a40685d199c  sub rsp, 0xF0
00007a40685d19a3  vmovaps [rsp], xmm0
00007a40685d19a8  vmovaps [rsp+0x10], xmm1
00007a40685d19ae  vmovaps [rsp+0x20], xmm2
00007a40685d19b4  vmovaps [rsp+0x30], xmm3
00007a40685d19ba  vmovaps [rsp+0x40], xmm4
00007a40685d19c0  vmovaps [rsp+0x50], xmm5
00007a40685d19c6  vmovaps [rsp+0x60], xmm6
00007a40685d19cc  vmovaps [rsp+0x70], xmm7
00007a40685d19d2  vmovaps [rsp+0x80], xmm8
00007a40685d19db  vmovaps [rsp+0x90], xmm9
00007a40685d19e4  vmovaps [rsp+0xA0], xmm10
00007a40685d19ed  vmovaps [rsp+0xB0], xmm11
00007a40685d19f6  vmovaps [rsp+0xC0], xmm12
00007a40685d19ff  vmovaps [rsp+0xD0], xmm13
00007a40685d1a08  vmovaps [rsp+0xE0], xmm14
00007a40685d1a11  sub rsp, 0x30
00007a40685d1a15  movaps [rsp], xmm15
00007a40685d1a1a  movaps [rsp+0x10], xmm14
00007a40685d1a20  movaps [rsp+0x20], xmm1
00007a40685d1a25  lea rdi, [rsp]
00007a40685d1a29  mov esi, 0x00
00007a40685d1a2e  mov rax, 0x56F679577530
00007a40685d1a38  call rax
00007a40685d1a3a  movaps xmm15, [rsp]
00007a40685d1a3f  add rsp, 0x30
00007a40685d1a43  vmovaps xmm0, [rsp]
00007a40685d1a48  vmovaps xmm1, [rsp+0x10]
00007a40685d1a4e  vmovaps xmm2, [rsp+0x20]
00007a40685d1a54  vmovaps xmm3, [rsp+0x30]
00007a40685d1a5a  vmovaps xmm4, [rsp+0x40]
00007a40685d1a60  vmovaps xmm5, [rsp+0x50]
00007a40685d1a66  vmovaps xmm6, [rsp+0x60]
00007a40685d1a6c  vmovaps xmm7, [rsp+0x70]
00007a40685d1a72  vmovaps xmm8, [rsp+0x80]
00007a40685d1a7b  vmovaps xmm9, [rsp+0x90]
00007a40685d1a84  vmovaps xmm10, [rsp+0xA0]
00007a40685d1a8d  vmovaps xmm11, [rsp+0xB0]
00007a40685d1a96  vmovaps xmm12, [rsp+0xC0]
00007a40685d1a9f  vmovaps xmm13, [rsp+0xD0]
00007a40685d1aa8  vmovaps xmm14, [rsp+0xE0]
00007a40685d1ab1  add rsp, 0xF0
00007a40685d1ab8  pop r11
00007a40685d1aba  pop r10
00007a40685d1abc  pop r9
00007a40685d1abe  pop r8
00007a40685d1ac0  pop rsi
00007a40685d1ac1  pop rdi
00007a40685d1ac2  pop rdx
00007a40685d1ac3  pop rcx
00007a40685d1ac4  pop rax
00007a40685d1ac5  add rsp, 0x08
00007a40685d1ac9  jmp 0x00007A40685CF9E7
00007a40685d1ace  call 0x00007A40683FF430
00007a40685d1ad3  jmp 0x00007A40685CF9F4
00007a40685d1ad8  sub rsp, 0x08
00007a40685d1adc  push rax
00007a40685d1add  push rcx
00007a40685d1ade  push rdx
00007a40685d1adf  push rdi
00007a40685d1ae0  push rsi
00007a40685d1ae1  push r8
00007a40685d1ae3  push r9
00007a40685d1ae5  push r10
00007a40685d1ae7  push r11
00007a40685d1ae9  sub rsp, 0xF0
00007a40685d1af0  vmovaps [rsp], xmm0
00007a40685d1af5  vmovaps [rsp+0x10], xmm1
00007a40685d1afb  vmovaps [rsp+0x20], xmm2
00007a40685d1b01  vmovaps [rsp+0x30], xmm3
00007a40685d1b07  vmovaps [rsp+0x40], xmm4
00007a40685d1b0d  vmovaps [rsp+0x50], xmm5
00007a40685d1b13  vmovaps [rsp+0x60], xmm6
00007a40685d1b19  vmovaps [rsp+0x70], xmm7
00007a40685d1b1f  vmovaps [rsp+0x80], xmm8
00007a40685d1b28  vmovaps [rsp+0x90], xmm9
00007a40685d1b31  vmovaps [rsp+0xA0], xmm10
00007a40685d1b3a  vmovaps [rsp+0xB0], xmm11
00007a40685d1b43  vmovaps [rsp+0xC0], xmm12
00007a40685d1b4c  vmovaps [rsp+0xD0], xmm13
00007a40685d1b55  vmovaps [rsp+0xE0], xmm15
00007a40685d1b5e  sub rsp, 0x30
00007a40685d1b62  movaps [rsp], xmm14
00007a40685d1b67  movaps [rsp+0x10], xmm13
00007a40685d1b6d  movaps [rsp+0x20], xmm1
00007a40685d1b72  lea rdi, [rsp]
00007a40685d1b76  mov esi, 0x00
00007a40685d1b7b  mov rax, 0x56F679577530
00007a40685d1b85  call rax
00007a40685d1b87  movaps xmm14, [rsp]
00007a40685d1b8c  add rsp, 0x30
00007a40685d1b90  vmovaps xmm0, [rsp]
00007a40685d1b95  vmovaps xmm1, [rsp+0x10]
00007a40685d1b9b  vmovaps xmm2, [rsp+0x20]
00007a40685d1ba1  vmovaps xmm3, [rsp+0x30]
00007a40685d1ba7  vmovaps xmm4, [rsp+0x40]
00007a40685d1bad  vmovaps xmm5, [rsp+0x50]
00007a40685d1bb3  vmovaps xmm6, [rsp+0x60]
00007a40685d1bb9  vmovaps xmm7, [rsp+0x70]
00007a40685d1bbf  vmovaps xmm8, [rsp+0x80]
00007a40685d1bc8  vmovaps xmm9, [rsp+0x90]
00007a40685d1bd1  vmovaps xmm10, [rsp+0xA0]
00007a40685d1bda  vmovaps xmm11, [rsp+0xB0]
00007a40685d1be3  vmovaps xmm12, [rsp+0xC0]
00007a40685d1bec  vmovaps xmm13, [rsp+0xD0]
00007a40685d1bf5  vmovaps xmm15, [rsp+0xE0]
00007a40685d1bfe  add rsp, 0xF0
00007a40685d1c05  pop r11
00007a40685d1c07  pop r10
00007a40685d1c09  pop r9
00007a40685d1c0b  pop r8
00007a40685d1c0d  pop rsi
00007a40685d1c0e  pop rdi
00007a40685d1c0f  pop rdx
00007a40685d1c10  pop rcx
00007a40685d1c11  pop rax
00007a40685d1c12  add rsp, 0x08
00007a40685d1c16  jmp 0x00007A40685CFAAF
00007a40685d1c1b  sub rsp, 0x08
00007a40685d1c1f  push rax
00007a40685d1c20  push rcx
00007a40685d1c21  push rdx
00007a40685d1c22  push rdi
00007a40685d1c23  push rsi
00007a40685d1c24  push r8
00007a40685d1c26  push r9
00007a40685d1c28  push r10
00007a40685d1c2a  push r11
00007a40685d1c2c  sub rsp, 0xF0
00007a40685d1c33  vmovaps [rsp], xmm0
00007a40685d1c38  vmovaps [rsp+0x10], xmm1
00007a40685d1c3e  vmovaps [rsp+0x20], xmm2
00007a40685d1c44  vmovaps [rsp+0x30], xmm3
00007a40685d1c4a  vmovaps [rsp+0x40], xmm4
00007a40685d1c50  vmovaps [rsp+0x50], xmm5
00007a40685d1c56  vmovaps [rsp+0x60], xmm6
00007a40685d1c5c  vmovaps [rsp+0x70], xmm7
00007a40685d1c62  vmovaps [rsp+0x80], xmm8
00007a40685d1c6b  vmovaps [rsp+0x90], xmm9
00007a40685d1c74  vmovaps [rsp+0xA0], xmm10
00007a40685d1c7d  vmovaps [rsp+0xB0], xmm11
00007a40685d1c86  vmovaps [rsp+0xC0], xmm12
00007a40685d1c8f  vmovaps [rsp+0xD0], xmm13
00007a40685d1c98  vmovaps [rsp+0xE0], xmm14
00007a40685d1ca1  sub rsp, 0x30
00007a40685d1ca5  movaps [rsp], xmm15
00007a40685d1caa  movaps [rsp+0x10], xmm13
00007a40685d1cb0  movaps [rsp+0x20], xmm1
00007a40685d1cb5  lea rdi, [rsp]
00007a40685d1cb9  mov esi, 0x00
00007a40685d1cbe  mov rax, 0x56F679577530
00007a40685d1cc8  call rax
00007a40685d1cca  movaps xmm15, [rsp]
00007a40685d1ccf  add rsp, 0x30
00007a40685d1cd3  vmovaps xmm0, [rsp]
00007a40685d1cd8  vmovaps xmm1, [rsp+0x10]
00007a40685d1cde  vmovaps xmm2, [rsp+0x20]
00007a40685d1ce4  vmovaps xmm3, [rsp+0x30]
00007a40685d1cea  vmovaps xmm4, [rsp+0x40]
00007a40685d1cf0  vmovaps xmm5, [rsp+0x50]
00007a40685d1cf6  vmovaps xmm6, [rsp+0x60]
00007a40685d1cfc  vmovaps xmm7, [rsp+0x70]
00007a40685d1d02  vmovaps xmm8, [rsp+0x80]
00007a40685d1d0b  vmovaps xmm9, [rsp+0x90]
00007a40685d1d14  vmovaps xmm10, [rsp+0xA0]
00007a40685d1d1d  vmovaps xmm11, [rsp+0xB0]
00007a40685d1d26  vmovaps xmm12, [rsp+0xC0]
00007a40685d1d2f  vmovaps xmm13, [rsp+0xD0]
00007a40685d1d38  vmovaps xmm14, [rsp+0xE0]
00007a40685d1d41  add rsp, 0xF0
00007a40685d1d48  pop r11
00007a40685d1d4a  pop r10
00007a40685d1d4c  pop r9
00007a40685d1d4e  pop r8
00007a40685d1d50  pop rsi
00007a40685d1d51  pop rdi
00007a40685d1d52  pop rdx
00007a40685d1d53  pop rcx
00007a40685d1d54  pop rax
00007a40685d1d55  add rsp, 0x08
00007a40685d1d59  jmp 0x00007A40685CFAEB
00007a40685d1d5e  call 0x00007A40683FF430
00007a40685d1d63  jmp 0x00007A40685CFAF8
00007a40685d1d68  sub rsp, 0x08
00007a40685d1d6c  push rax
00007a40685d1d6d  push rcx
00007a40685d1d6e  push rdx
00007a40685d1d6f  push rdi
00007a40685d1d70  push rsi
00007a40685d1d71  push r8
00007a40685d1d73  push r9
00007a40685d1d75  push r10
00007a40685d1d77  push r11
00007a40685d1d79  sub rsp, 0xF0
00007a40685d1d80  vmovaps [rsp], xmm0
00007a40685d1d85  vmovaps [rsp+0x10], xmm1
00007a40685d1d8b  vmovaps [rsp+0x20], xmm2
00007a40685d1d91  vmovaps [rsp+0x30], xmm3
00007a40685d1d97  vmovaps [rsp+0x40], xmm4
00007a40685d1d9d  vmovaps [rsp+0x50], xmm5
00007a40685d1da3  vmovaps [rsp+0x60], xmm6
00007a40685d1da9  vmovaps [rsp+0x70], xmm7
00007a40685d1daf  vmovaps [rsp+0x80], xmm8
00007a40685d1db8  vmovaps [rsp+0x90], xmm9
00007a40685d1dc1  vmovaps [rsp+0xA0], xmm10
00007a40685d1dca  vmovaps [rsp+0xB0], xmm11
00007a40685d1dd3  vmovaps [rsp+0xC0], xmm12
00007a40685d1ddc  vmovaps [rsp+0xD0], xmm13
00007a40685d1de5  vmovaps [rsp+0xE0], xmm15
00007a40685d1dee  sub rsp, 0x30
00007a40685d1df2  movaps [rsp], xmm14
00007a40685d1df7  movaps [rsp+0x10], xmm13
00007a40685d1dfd  movaps [rsp+0x20], xmm2
00007a40685d1e02  lea rdi, [rsp]
00007a40685d1e06  mov esi, 0x00
00007a40685d1e0b  mov rax, 0x56F679577530
00007a40685d1e15  call rax
00007a40685d1e17  movaps xmm14, [rsp]
00007a40685d1e1c  add rsp, 0x30
00007a40685d1e20  vmovaps xmm0, [rsp]
00007a40685d1e25  vmovaps xmm1, [rsp+0x10]
00007a40685d1e2b  vmovaps xmm2, [rsp+0x20]
00007a40685d1e31  vmovaps xmm3, [rsp+0x30]
00007a40685d1e37  vmovaps xmm4, [rsp+0x40]
00007a40685d1e3d  vmovaps xmm5, [rsp+0x50]
00007a40685d1e43  vmovaps xmm6, [rsp+0x60]
00007a40685d1e49  vmovaps xmm7, [rsp+0x70]
00007a40685d1e4f  vmovaps xmm8, [rsp+0x80]
00007a40685d1e58  vmovaps xmm9, [rsp+0x90]
00007a40685d1e61  vmovaps xmm10, [rsp+0xA0]
00007a40685d1e6a  vmovaps xmm11, [rsp+0xB0]
00007a40685d1e73  vmovaps xmm12, [rsp+0xC0]
00007a40685d1e7c  vmovaps xmm13, [rsp+0xD0]
00007a40685d1e85  vmovaps xmm15, [rsp+0xE0]
00007a40685d1e8e  add rsp, 0xF0
00007a40685d1e95  pop r11
00007a40685d1e97  pop r10
00007a40685d1e99  pop r9
00007a40685d1e9b  pop r8
00007a40685d1e9d  pop rsi
00007a40685d1e9e  pop rdi
00007a40685d1e9f  pop rdx
00007a40685d1ea0  pop rcx
00007a40685d1ea1  pop rax
00007a40685d1ea2  add rsp, 0x08
00007a40685d1ea6  jmp 0x00007A40685CFB24
00007a40685d1eab  sub rsp, 0x08
00007a40685d1eaf  push rax
00007a40685d1eb0  push rcx
00007a40685d1eb1  push rdx
00007a40685d1eb2  push rdi
00007a40685d1eb3  push rsi
00007a40685d1eb4  push r8
00007a40685d1eb6  push r9
00007a40685d1eb8  push r10
00007a40685d1eba  push r11
00007a40685d1ebc  sub rsp, 0xF0
00007a40685d1ec3  vmovaps [rsp], xmm0
00007a40685d1ec8  vmovaps [rsp+0x10], xmm2
00007a40685d1ece  vmovaps [rsp+0x20], xmm3
00007a40685d1ed4  vmovaps [rsp+0x30], xmm4
00007a40685d1eda  vmovaps [rsp+0x40], xmm5
00007a40685d1ee0  vmovaps [rsp+0x50], xmm6
00007a40685d1ee6  vmovaps [rsp+0x60], xmm7
00007a40685d1eec  vmovaps [rsp+0x70], xmm8
00007a40685d1ef2  vmovaps [rsp+0x80], xmm9
00007a40685d1efb  vmovaps [rsp+0x90], xmm10
00007a40685d1f04  vmovaps [rsp+0xA0], xmm11
00007a40685d1f0d  vmovaps [rsp+0xB0], xmm12
00007a40685d1f16  vmovaps [rsp+0xC0], xmm13
00007a40685d1f1f  vmovaps [rsp+0xD0], xmm14
00007a40685d1f28  vmovaps [rsp+0xE0], xmm15
00007a40685d1f31  sub rsp, 0x30
00007a40685d1f35  movaps [rsp], xmm1
00007a40685d1f39  movaps [rsp+0x10], xmm13
00007a40685d1f3f  movaps [rsp+0x20], xmm2
00007a40685d1f44  lea rdi, [rsp]
00007a40685d1f48  mov esi, 0x00
00007a40685d1f4d  mov rax, 0x56F679577530
00007a40685d1f57  call rax
00007a40685d1f59  movaps xmm1, [rsp]
00007a40685d1f5d  add rsp, 0x30
00007a40685d1f61  vmovaps xmm0, [rsp]
00007a40685d1f66  vmovaps xmm2, [rsp+0x10]
00007a40685d1f6c  vmovaps xmm3, [rsp+0x20]
00007a40685d1f72  vmovaps xmm4, [rsp+0x30]
00007a40685d1f78  vmovaps xmm5, [rsp+0x40]
00007a40685d1f7e  vmovaps xmm6, [rsp+0x50]
00007a40685d1f84  vmovaps xmm7, [rsp+0x60]
00007a40685d1f8a  vmovaps xmm8, [rsp+0x70]
00007a40685d1f90  vmovaps xmm9, [rsp+0x80]
00007a40685d1f99  vmovaps xmm10, [rsp+0x90]
00007a40685d1fa2  vmovaps xmm11, [rsp+0xA0]
00007a40685d1fab  vmovaps xmm12, [rsp+0xB0]
00007a40685d1fb4  vmovaps xmm13, [rsp+0xC0]
00007a40685d1fbd  vmovaps xmm14, [rsp+0xD0]
00007a40685d1fc6  vmovaps xmm15, [rsp+0xE0]
00007a40685d1fcf  add rsp, 0xF0
00007a40685d1fd6  pop r11
00007a40685d1fd8  pop r10
00007a40685d1fda  pop r9
00007a40685d1fdc  pop r8
00007a40685d1fde  pop rsi
00007a40685d1fdf  pop rdi
00007a40685d1fe0  pop rdx
00007a40685d1fe1  pop rcx
00007a40685d1fe2  pop rax
00007a40685d1fe3  add rsp, 0x08
00007a40685d1fe7  jmp 0x00007A40685CFB52
00007a40685d1fec  sub rsp, 0x08
00007a40685d1ff0  push rax
00007a40685d1ff1  push rcx
00007a40685d1ff2  push rdx
00007a40685d1ff3  push rdi
00007a40685d1ff4  push rsi
00007a40685d1ff5  push r8
00007a40685d1ff7  push r9
00007a40685d1ff9  push r10
00007a40685d1ffb  push r11
00007a40685d1ffd  sub rsp, 0xF0
00007a40685d2004  vmovaps [rsp], xmm0
00007a40685d2009  vmovaps [rsp+0x10], xmm1
00007a40685d200f  vmovaps [rsp+0x20], xmm3
00007a40685d2015  vmovaps [rsp+0x30], xmm4
00007a40685d201b  vmovaps [rsp+0x40], xmm5
00007a40685d2021  vmovaps [rsp+0x50], xmm6
00007a40685d2027  vmovaps [rsp+0x60], xmm7
00007a40685d202d  vmovaps [rsp+0x70], xmm8
00007a40685d2033  vmovaps [rsp+0x80], xmm9
00007a40685d203c  vmovaps [rsp+0x90], xmm10
00007a40685d2045  vmovaps [rsp+0xA0], xmm11
00007a40685d204e  vmovaps [rsp+0xB0], xmm12
00007a40685d2057  vmovaps [rsp+0xC0], xmm13
00007a40685d2060  vmovaps [rsp+0xD0], xmm14
00007a40685d2069  vmovaps [rsp+0xE0], xmm15
00007a40685d2072  sub rsp, 0x30
00007a40685d2076  movaps [rsp], xmm2
00007a40685d207a  movaps [rsp+0x10], xmm1
00007a40685d207f  movaps [rsp+0x20], xmm13
00007a40685d2085  lea rdi, [rsp]
00007a40685d2089  mov esi, 0x00
00007a40685d208e  mov rax, 0x56F679577530
00007a40685d2098  call rax
00007a40685d209a  movaps xmm2, [rsp]
00007a40685d209e  add rsp, 0x30
00007a40685d20a2  vmovaps xmm0, [rsp]
00007a40685d20a7  vmovaps xmm1, [rsp+0x10]
00007a40685d20ad  vmovaps xmm3, [rsp+0x20]
00007a40685d20b3  vmovaps xmm4, [rsp+0x30]
00007a40685d20b9  vmovaps xmm5, [rsp+0x40]
00007a40685d20bf  vmovaps xmm6, [rsp+0x50]
00007a40685d20c5  vmovaps xmm7, [rsp+0x60]
00007a40685d20cb  vmovaps xmm8, [rsp+0x70]
00007a40685d20d1  vmovaps xmm9, [rsp+0x80]
00007a40685d20da  vmovaps xmm10, [rsp+0x90]
00007a40685d20e3  vmovaps xmm11, [rsp+0xA0]
00007a40685d20ec  vmovaps xmm12, [rsp+0xB0]
00007a40685d20f5  vmovaps xmm13, [rsp+0xC0]
00007a40685d20fe  vmovaps xmm14, [rsp+0xD0]
00007a40685d2107  vmovaps xmm15, [rsp+0xE0]
00007a40685d2110  add rsp, 0xF0
00007a40685d2117  pop r11
00007a40685d2119  pop r10
00007a40685d211b  pop r9
00007a40685d211d  pop r8
00007a40685d211f  pop rsi
00007a40685d2120  pop rdi
00007a40685d2121  pop rdx
00007a40685d2122  pop rcx
00007a40685d2123  pop rax
00007a40685d2124  add rsp, 0x08
00007a40685d2128  jmp 0x00007A40685CFBAB
00007a40685d212d  call 0x00007A40683FF430
00007a40685d2132  jmp 0x00007A40685CFBB8
00007a40685d2137  sub rsp, 0x08
00007a40685d213b  push rax
00007a40685d213c  push rcx
00007a40685d213d  push rdx
00007a40685d213e  push rdi
00007a40685d213f  push rsi
00007a40685d2140  push r8
00007a40685d2142  push r9
00007a40685d2144  push r10
00007a40685d2146  push r11
00007a40685d2148  sub rsp, 0xF0
00007a40685d214f  vmovaps [rsp], xmm0
00007a40685d2154  vmovaps [rsp+0x10], xmm1
00007a40685d215a  vmovaps [rsp+0x20], xmm2
00007a40685d2160  vmovaps [rsp+0x30], xmm3
00007a40685d2166  vmovaps [rsp+0x40], xmm4
00007a40685d216c  vmovaps [rsp+0x50], xmm5
00007a40685d2172  vmovaps [rsp+0x60], xmm6
00007a40685d2178  vmovaps [rsp+0x70], xmm7
00007a40685d217e  vmovaps [rsp+0x80], xmm8
00007a40685d2187  vmovaps [rsp+0x90], xmm9
00007a40685d2190  vmovaps [rsp+0xA0], xmm10
00007a40685d2199  vmovaps [rsp+0xB0], xmm11
00007a40685d21a2  vmovaps [rsp+0xC0], xmm12
00007a40685d21ab  vmovaps [rsp+0xD0], xmm13
00007a40685d21b4  vmovaps [rsp+0xE0], xmm14
00007a40685d21bd  sub rsp, 0x30
00007a40685d21c1  movaps [rsp], xmm15
00007a40685d21c6  movaps [rsp+0x10], xmm13
00007a40685d21cc  movaps [rsp+0x20], xmm1
00007a40685d21d1  lea rdi, [rsp]
00007a40685d21d5  mov esi, 0x00
00007a40685d21da  mov rax, 0x56F679577530
00007a40685d21e4  call rax
00007a40685d21e6  movaps xmm15, [rsp]
00007a40685d21eb  add rsp, 0x30
00007a40685d21ef  vmovaps xmm0, [rsp]
00007a40685d21f4  vmovaps xmm1, [rsp+0x10]
00007a40685d21fa  vmovaps xmm2, [rsp+0x20]
00007a40685d2200  vmovaps xmm3, [rsp+0x30]
00007a40685d2206  vmovaps xmm4, [rsp+0x40]
00007a40685d220c  vmovaps xmm5, [rsp+0x50]
00007a40685d2212  vmovaps xmm6, [rsp+0x60]
00007a40685d2218  vmovaps xmm7, [rsp+0x70]
00007a40685d221e  vmovaps xmm8, [rsp+0x80]
00007a40685d2227  vmovaps xmm9, [rsp+0x90]
00007a40685d2230  vmovaps xmm10, [rsp+0xA0]
00007a40685d2239  vmovaps xmm11, [rsp+0xB0]
00007a40685d2242  vmovaps xmm12, [rsp+0xC0]
00007a40685d224b  vmovaps xmm13, [rsp+0xD0]
00007a40685d2254  vmovaps xmm14, [rsp+0xE0]
00007a40685d225d  add rsp, 0xF0
00007a40685d2264  pop r11
00007a40685d2266  pop r10
00007a40685d2268  pop r9
00007a40685d226a  pop r8
00007a40685d226c  pop rsi
00007a40685d226d  pop rdi
00007a40685d226e  pop rdx
00007a40685d226f  pop rcx
00007a40685d2270  pop rax
00007a40685d2271  add rsp, 0x08
00007a40685d2275  jmp 0x00007A40685CFBF7
00007a40685d227a  sub rsp, 0x08
00007a40685d227e  push rax
00007a40685d227f  push rcx
00007a40685d2280  push rdx
00007a40685d2281  push rdi
00007a40685d2282  push rsi
00007a40685d2283  push r8
00007a40685d2285  push r9
00007a40685d2287  push r10
00007a40685d2289  push r11
00007a40685d228b  sub rsp, 0xF0
00007a40685d2292  vmovaps [rsp], xmm0
00007a40685d2297  vmovaps [rsp+0x10], xmm1
00007a40685d229d  vmovaps [rsp+0x20], xmm2
00007a40685d22a3  vmovaps [rsp+0x30], xmm3
00007a40685d22a9  vmovaps [rsp+0x40], xmm4
00007a40685d22af  vmovaps [rsp+0x50], xmm5
00007a40685d22b5  vmovaps [rsp+0x60], xmm6
00007a40685d22bb  vmovaps [rsp+0x70], xmm7
00007a40685d22c1  vmovaps [rsp+0x80], xmm8
00007a40685d22ca  vmovaps [rsp+0x90], xmm9
00007a40685d22d3  vmovaps [rsp+0xA0], xmm10
00007a40685d22dc  vmovaps [rsp+0xB0], xmm11
00007a40685d22e5  vmovaps [rsp+0xC0], xmm12
00007a40685d22ee  vmovaps [rsp+0xD0], xmm13
00007a40685d22f7  vmovaps [rsp+0xE0], xmm15
00007a40685d2300  sub rsp, 0x30
00007a40685d2304  movaps [rsp], xmm14
00007a40685d2309  movaps [rsp+0x10], xmm11
00007a40685d230f  movaps [rsp+0x20], xmm1
00007a40685d2314  lea rdi, [rsp]
00007a40685d2318  mov esi, 0x00
00007a40685d231d  mov rax, 0x56F679577530
00007a40685d2327  call rax
00007a40685d2329  movaps xmm14, [rsp]
00007a40685d232e  add rsp, 0x30
00007a40685d2332  vmovaps xmm0, [rsp]
00007a40685d2337  vmovaps xmm1, [rsp+0x10]
00007a40685d233d  vmovaps xmm2, [rsp+0x20]
00007a40685d2343  vmovaps xmm3, [rsp+0x30]
00007a40685d2349  vmovaps xmm4, [rsp+0x40]
00007a40685d234f  vmovaps xmm5, [rsp+0x50]
00007a40685d2355  vmovaps xmm6, [rsp+0x60]
00007a40685d235b  vmovaps xmm7, [rsp+0x70]
00007a40685d2361  vmovaps xmm8, [rsp+0x80]
00007a40685d236a  vmovaps xmm9, [rsp+0x90]
00007a40685d2373  vmovaps xmm10, [rsp+0xA0]
00007a40685d237c  vmovaps xmm11, [rsp+0xB0]
00007a40685d2385  vmovaps xmm12, [rsp+0xC0]
00007a40685d238e  vmovaps xmm13, [rsp+0xD0]
00007a40685d2397  vmovaps xmm15, [rsp+0xE0]
00007a40685d23a0  add rsp, 0xF0
00007a40685d23a7  pop r11
00007a40685d23a9  pop r10
00007a40685d23ab  pop r9
00007a40685d23ad  pop r8
00007a40685d23af  pop rsi
00007a40685d23b0  pop rdi
00007a40685d23b1  pop rdx
00007a40685d23b2  pop rcx
00007a40685d23b3  pop rax
00007a40685d23b4  add rsp, 0x08
00007a40685d23b8  jmp 0x00007A40685CFC21
00007a40685d23bd  sub rsp, 0x08
00007a40685d23c1  push rax
00007a40685d23c2  push rcx
00007a40685d23c3  push rdx
00007a40685d23c4  push rdi
00007a40685d23c5  push rsi
00007a40685d23c6  push r8
00007a40685d23c8  push r9
00007a40685d23ca  push r10
00007a40685d23cc  push r11
00007a40685d23ce  sub rsp, 0xF0
00007a40685d23d5  vmovaps [rsp], xmm0
00007a40685d23da  vmovaps [rsp+0x10], xmm1
00007a40685d23e0  vmovaps [rsp+0x20], xmm2
00007a40685d23e6  vmovaps [rsp+0x30], xmm3
00007a40685d23ec  vmovaps [rsp+0x40], xmm4
00007a40685d23f2  vmovaps [rsp+0x50], xmm5
00007a40685d23f8  vmovaps [rsp+0x60], xmm6
00007a40685d23fe  vmovaps [rsp+0x70], xmm7
00007a40685d2404  vmovaps [rsp+0x80], xmm8
00007a40685d240d  vmovaps [rsp+0x90], xmm9
00007a40685d2416  vmovaps [rsp+0xA0], xmm10
00007a40685d241f  vmovaps [rsp+0xB0], xmm11
00007a40685d2428  vmovaps [rsp+0xC0], xmm12
00007a40685d2431  vmovaps [rsp+0xD0], xmm14
00007a40685d243a  vmovaps [rsp+0xE0], xmm15
00007a40685d2443  sub rsp, 0x30
00007a40685d2447  movaps [rsp], xmm13
00007a40685d244c  movaps [rsp+0x10], xmm11
00007a40685d2452  movaps [rsp+0x20], xmm1
00007a40685d2457  lea rdi, [rsp]
00007a40685d245b  mov esi, 0x00
00007a40685d2460  mov rax, 0x56F679577530
00007a40685d246a  call rax
00007a40685d246c  movaps xmm13, [rsp]
00007a40685d2471  add rsp, 0x30
00007a40685d2475  vmovaps xmm0, [rsp]
00007a40685d247a  vmovaps xmm1, [rsp+0x10]
00007a40685d2480  vmovaps xmm2, [rsp+0x20]
00007a40685d2486  vmovaps xmm3, [rsp+0x30]
00007a40685d248c  vmovaps xmm4, [rsp+0x40]
00007a40685d2492  vmovaps xmm5, [rsp+0x50]
00007a40685d2498  vmovaps xmm6, [rsp+0x60]
00007a40685d249e  vmovaps xmm7, [rsp+0x70]
00007a40685d24a4  vmovaps xmm8, [rsp+0x80]
00007a40685d24ad  vmovaps xmm9, [rsp+0x90]
00007a40685d24b6  vmovaps xmm10, [rsp+0xA0]
00007a40685d24bf  vmovaps xmm11, [rsp+0xB0]
00007a40685d24c8  vmovaps xmm12, [rsp+0xC0]
00007a40685d24d1  vmovaps xmm14, [rsp+0xD0]
00007a40685d24da  vmovaps xmm15, [rsp+0xE0]
00007a40685d24e3  add rsp, 0xF0
00007a40685d24ea  pop r11
00007a40685d24ec  pop r10
00007a40685d24ee  pop r9
00007a40685d24f0  pop r8
00007a40685d24f2  pop rsi
00007a40685d24f3  pop rdi
00007a40685d24f4  pop rdx
00007a40685d24f5  pop rcx
00007a40685d24f6  pop rax
00007a40685d24f7  add rsp, 0x08
00007a40685d24fb  jmp 0x00007A40685CFC76
00007a40685d2500  call 0x00007A40683FF430
00007a40685d2505  jmp 0x00007A40685CFC83
00007a40685d250a  sub rsp, 0x08
00007a40685d250e  push rax
00007a40685d250f  push rcx
00007a40685d2510  push rdx
00007a40685d2511  push rdi
00007a40685d2512  push rsi
00007a40685d2513  push r8
00007a40685d2515  push r9
00007a40685d2517  push r10
00007a40685d2519  push r11
00007a40685d251b  sub rsp, 0xF0
00007a40685d2522  vmovaps [rsp], xmm0
00007a40685d2527  vmovaps [rsp+0x10], xmm1
00007a40685d252d  vmovaps [rsp+0x20], xmm2
00007a40685d2533  vmovaps [rsp+0x30], xmm3
00007a40685d2539  vmovaps [rsp+0x40], xmm4
00007a40685d253f  vmovaps [rsp+0x50], xmm5
00007a40685d2545  vmovaps [rsp+0x60], xmm6
00007a40685d254b  vmovaps [rsp+0x70], xmm7
00007a40685d2551  vmovaps [rsp+0x80], xmm8
00007a40685d255a  vmovaps [rsp+0x90], xmm9
00007a40685d2563  vmovaps [rsp+0xA0], xmm10
00007a40685d256c  vmovaps [rsp+0xB0], xmm11
00007a40685d2575  vmovaps [rsp+0xC0], xmm12
00007a40685d257e  vmovaps [rsp+0xD0], xmm13
00007a40685d2587  vmovaps [rsp+0xE0], xmm14
00007a40685d2590  sub rsp, 0x30
00007a40685d2594  movaps [rsp], xmm15
00007a40685d2599  movaps [rsp+0x10], xmm11
00007a40685d259f  movaps [rsp+0x20], xmm1
00007a40685d25a4  lea rdi, [rsp]
00007a40685d25a8  mov esi, 0x00
00007a40685d25ad  mov rax, 0x56F679577530
00007a40685d25b7  call rax
00007a40685d25b9  movaps xmm15, [rsp]
00007a40685d25be  add rsp, 0x30
00007a40685d25c2  vmovaps xmm0, [rsp]
00007a40685d25c7  vmovaps xmm1, [rsp+0x10]
00007a40685d25cd  vmovaps xmm2, [rsp+0x20]
00007a40685d25d3  vmovaps xmm3, [rsp+0x30]
00007a40685d25d9  vmovaps xmm4, [rsp+0x40]
00007a40685d25df  vmovaps xmm5, [rsp+0x50]
00007a40685d25e5  vmovaps xmm6, [rsp+0x60]
00007a40685d25eb  vmovaps xmm7, [rsp+0x70]
00007a40685d25f1  vmovaps xmm8, [rsp+0x80]
00007a40685d25fa  vmovaps xmm9, [rsp+0x90]
00007a40685d2603  vmovaps xmm10, [rsp+0xA0]
00007a40685d260c  vmovaps xmm11, [rsp+0xB0]
00007a40685d2615  vmovaps xmm12, [rsp+0xC0]
00007a40685d261e  vmovaps xmm13, [rsp+0xD0]
00007a40685d2627  vmovaps xmm14, [rsp+0xE0]
00007a40685d2630  add rsp, 0xF0
00007a40685d2637  pop r11
00007a40685d2639  pop r10
00007a40685d263b  pop r9
00007a40685d263d  pop r8
00007a40685d263f  pop rsi
00007a40685d2640  pop rdi
00007a40685d2641  pop rdx
00007a40685d2642  pop rcx
00007a40685d2643  pop rax
00007a40685d2644  add rsp, 0x08
00007a40685d2648  jmp 0x00007A40685CFCBC
00007a40685d264d  sub rsp, 0x08
00007a40685d2651  push rax
00007a40685d2652  push rcx
00007a40685d2653  push rdx
00007a40685d2654  push rdi
00007a40685d2655  push rsi
00007a40685d2656  push r8
00007a40685d2658  push r9
00007a40685d265a  push r10
00007a40685d265c  push r11
00007a40685d265e  sub rsp, 0xF0
00007a40685d2665  vmovaps [rsp], xmm0
00007a40685d266a  vmovaps [rsp+0x10], xmm1
00007a40685d2670  vmovaps [rsp+0x20], xmm2
00007a40685d2676  vmovaps [rsp+0x30], xmm3
00007a40685d267c  vmovaps [rsp+0x40], xmm4
00007a40685d2682  vmovaps [rsp+0x50], xmm5
00007a40685d2688  vmovaps [rsp+0x60], xmm6
00007a40685d268e  vmovaps [rsp+0x70], xmm7
00007a40685d2694  vmovaps [rsp+0x80], xmm8
00007a40685d269d  vmovaps [rsp+0x90], xmm9
00007a40685d26a6  vmovaps [rsp+0xA0], xmm10
00007a40685d26af  vmovaps [rsp+0xB0], xmm12
00007a40685d26b8  vmovaps [rsp+0xC0], xmm13
00007a40685d26c1  vmovaps [rsp+0xD0], xmm14
00007a40685d26ca  vmovaps [rsp+0xE0], xmm15
00007a40685d26d3  sub rsp, 0x30
00007a40685d26d7  movaps [rsp], xmm11
00007a40685d26dc  movaps [rsp+0x10], xmm6
00007a40685d26e1  movaps [rsp+0x20], xmm14
00007a40685d26e7  lea rdi, [rsp]
00007a40685d26eb  mov esi, 0x00
00007a40685d26f0  mov rax, 0x56F679577530
00007a40685d26fa  call rax
00007a40685d26fc  movaps xmm11, [rsp]
00007a40685d2701  add rsp, 0x30
00007a40685d2705  vmovaps xmm0, [rsp]
00007a40685d270a  vmovaps xmm1, [rsp+0x10]
00007a40685d2710  vmovaps xmm2, [rsp+0x20]
00007a40685d2716  vmovaps xmm3, [rsp+0x30]
00007a40685d271c  vmovaps xmm4, [rsp+0x40]
00007a40685d2722  vmovaps xmm5, [rsp+0x50]
00007a40685d2728  vmovaps xmm6, [rsp+0x60]
00007a40685d272e  vmovaps xmm7, [rsp+0x70]
00007a40685d2734  vmovaps xmm8, [rsp+0x80]
00007a40685d273d  vmovaps xmm9, [rsp+0x90]
00007a40685d2746  vmovaps xmm10, [rsp+0xA0]
00007a40685d274f  vmovaps xmm12, [rsp+0xB0]
00007a40685d2758  vmovaps xmm13, [rsp+0xC0]
00007a40685d2761  vmovaps xmm14, [rsp+0xD0]
00007a40685d276a  vmovaps xmm15, [rsp+0xE0]
00007a40685d2773  add rsp, 0xF0
00007a40685d277a  pop r11
00007a40685d277c  pop r10
00007a40685d277e  pop r9
00007a40685d2780  pop r8
00007a40685d2782  pop rsi
00007a40685d2783  pop rdi
00007a40685d2784  pop rdx
00007a40685d2785  pop rcx
00007a40685d2786  pop rax
00007a40685d2787  add rsp, 0x08
00007a40685d278b  jmp 0x00007A40685CFD34
00007a40685d2790  call 0x00007A40683FF430
00007a40685d2795  jmp 0x00007A40685CFD3E
00007a40685d279a  sub rsp, 0x08
00007a40685d279e  push rax
00007a40685d279f  push rcx
00007a40685d27a0  push rdx
00007a40685d27a1  push rdi
00007a40685d27a2  push rsi
00007a40685d27a3  push r8
00007a40685d27a5  push r9
00007a40685d27a7  push r10
00007a40685d27a9  push r11
00007a40685d27ab  sub rsp, 0xF0
00007a40685d27b2  vmovaps [rsp], xmm0
00007a40685d27b7  vmovaps [rsp+0x10], xmm1
00007a40685d27bd  vmovaps [rsp+0x20], xmm2
00007a40685d27c3  vmovaps [rsp+0x30], xmm3
00007a40685d27c9  vmovaps [rsp+0x40], xmm4
00007a40685d27cf  vmovaps [rsp+0x50], xmm5
00007a40685d27d5  vmovaps [rsp+0x60], xmm6
00007a40685d27db  vmovaps [rsp+0x70], xmm7
00007a40685d27e1  vmovaps [rsp+0x80], xmm8
00007a40685d27ea  vmovaps [rsp+0x90], xmm9
00007a40685d27f3  vmovaps [rsp+0xA0], xmm10
00007a40685d27fc  vmovaps [rsp+0xB0], xmm11
00007a40685d2805  vmovaps [rsp+0xC0], xmm12
00007a40685d280e  vmovaps [rsp+0xD0], xmm13
00007a40685d2817  vmovaps [rsp+0xE0], xmm15
00007a40685d2820  sub rsp, 0x30
00007a40685d2824  movaps [rsp], xmm14
00007a40685d2829  movaps [rsp+0x10], xmm6
00007a40685d282e  movaps [rsp+0x20], xmm2
00007a40685d2833  lea rdi, [rsp]
00007a40685d2837  mov esi, 0x00
00007a40685d283c  mov rax, 0x56F679577530
00007a40685d2846  call rax
00007a40685d2848  movaps xmm14, [rsp]
00007a40685d284d  add rsp, 0x30
00007a40685d2851  vmovaps xmm0, [rsp]
00007a40685d2856  vmovaps xmm1, [rsp+0x10]
00007a40685d285c  vmovaps xmm2, [rsp+0x20]
00007a40685d2862  vmovaps xmm3, [rsp+0x30]
00007a40685d2868  vmovaps xmm4, [rsp+0x40]
00007a40685d286e  vmovaps xmm5, [rsp+0x50]
00007a40685d2874  vmovaps xmm6, [rsp+0x60]
00007a40685d287a  vmovaps xmm7, [rsp+0x70]
00007a40685d2880  vmovaps xmm8, [rsp+0x80]
00007a40685d2889  vmovaps xmm9, [rsp+0x90]
00007a40685d2892  vmovaps xmm10, [rsp+0xA0]
00007a40685d289b  vmovaps xmm11, [rsp+0xB0]
00007a40685d28a4  vmovaps xmm12, [rsp+0xC0]
00007a40685d28ad  vmovaps xmm13, [rsp+0xD0]
00007a40685d28b6  vmovaps xmm15, [rsp+0xE0]
00007a40685d28bf  add rsp, 0xF0
00007a40685d28c6  pop r11
00007a40685d28c8  pop r10
00007a40685d28ca  pop r9
00007a40685d28cc  pop r8
00007a40685d28ce  pop rsi
00007a40685d28cf  pop rdi
00007a40685d28d0  pop rdx
00007a40685d28d1  pop rcx
00007a40685d28d2  pop rax
00007a40685d28d3  add rsp, 0x08
00007a40685d28d7  jmp 0x00007A40685CFD72
00007a40685d28dc  sub rsp, 0x08
00007a40685d28e0  push rax
00007a40685d28e1  push rcx
00007a40685d28e2  push rdx
00007a40685d28e3  push rdi
00007a40685d28e4  push rsi
00007a40685d28e5  push r8
00007a40685d28e7  push r9
00007a40685d28e9  push r10
00007a40685d28eb  push r11
00007a40685d28ed  sub rsp, 0xF0
00007a40685d28f4  vmovaps [rsp], xmm0
00007a40685d28f9  vmovaps [rsp+0x10], xmm1
00007a40685d28ff  vmovaps [rsp+0x20], xmm2
00007a40685d2905  vmovaps [rsp+0x30], xmm3
00007a40685d290b  vmovaps [rsp+0x40], xmm4
00007a40685d2911  vmovaps [rsp+0x50], xmm5
00007a40685d2917  vmovaps [rsp+0x60], xmm7
00007a40685d291d  vmovaps [rsp+0x70], xmm8
00007a40685d2923  vmovaps [rsp+0x80], xmm9
00007a40685d292c  vmovaps [rsp+0x90], xmm10
00007a40685d2935  vmovaps [rsp+0xA0], xmm11
00007a40685d293e  vmovaps [rsp+0xB0], xmm12
00007a40685d2947  vmovaps [rsp+0xC0], xmm13
00007a40685d2950  vmovaps [rsp+0xD0], xmm14
00007a40685d2959  vmovaps [rsp+0xE0], xmm15
00007a40685d2962  sub rsp, 0x30
00007a40685d2966  movaps [rsp], xmm6
00007a40685d296a  movaps [rsp+0x10], xmm5
00007a40685d296f  movaps [rsp+0x20], xmm1
00007a40685d2974  lea rdi, [rsp]
00007a40685d2978  mov esi, 0x00
00007a40685d297d  mov rax, 0x56F679577530
00007a40685d2987  call rax
00007a40685d2989  movaps xmm6, [rsp]
00007a40685d298d  add rsp, 0x30
00007a40685d2991  vmovaps xmm0, [rsp]
00007a40685d2996  vmovaps xmm1, [rsp+0x10]
00007a40685d299c  vmovaps xmm2, [rsp+0x20]
00007a40685d29a2  vmovaps xmm3, [rsp+0x30]
00007a40685d29a8  vmovaps xmm4, [rsp+0x40]
00007a40685d29ae  vmovaps xmm5, [rsp+0x50]
00007a40685d29b4  vmovaps xmm7, [rsp+0x60]
00007a40685d29ba  vmovaps xmm8, [rsp+0x70]
00007a40685d29c0  vmovaps xmm9, [rsp+0x80]
00007a40685d29c9  vmovaps xmm10, [rsp+0x90]
00007a40685d29d2  vmovaps xmm11, [rsp+0xA0]
00007a40685d29db  vmovaps xmm12, [rsp+0xB0]
00007a40685d29e4  vmovaps xmm13, [rsp+0xC0]
00007a40685d29ed  vmovaps xmm14, [rsp+0xD0]
00007a40685d29f6  vmovaps xmm15, [rsp+0xE0]
00007a40685d29ff  add rsp, 0xF0
00007a40685d2a06  pop r11
00007a40685d2a08  pop r10
00007a40685d2a0a  pop r9
00007a40685d2a0c  pop r8
00007a40685d2a0e  pop rsi
00007a40685d2a0f  pop rdi
00007a40685d2a10  pop rdx
00007a40685d2a11  pop rcx
00007a40685d2a12  pop rax
00007a40685d2a13  add rsp, 0x08
00007a40685d2a17  jmp 0x00007A40685CFD98
00007a40685d2a1c  sub rsp, 0x08
00007a40685d2a20  push rax
00007a40685d2a21  push rcx
00007a40685d2a22  push rdx
00007a40685d2a23  push rdi
00007a40685d2a24  push rsi
00007a40685d2a25  push r8
00007a40685d2a27  push r9
00007a40685d2a29  push r10
00007a40685d2a2b  push r11
00007a40685d2a2d  sub rsp, 0xF0
00007a40685d2a34  vmovaps [rsp], xmm0
00007a40685d2a39  vmovaps [rsp+0x10], xmm2
00007a40685d2a3f  vmovaps [rsp+0x20], xmm3
00007a40685d2a45  vmovaps [rsp+0x30], xmm4
00007a40685d2a4b  vmovaps [rsp+0x40], xmm5
00007a40685d2a51  vmovaps [rsp+0x50], xmm6
00007a40685d2a57  vmovaps [rsp+0x60], xmm7
00007a40685d2a5d  vmovaps [rsp+0x70], xmm8
00007a40685d2a63  vmovaps [rsp+0x80], xmm9
00007a40685d2a6c  vmovaps [rsp+0x90], xmm10
00007a40685d2a75  vmovaps [rsp+0xA0], xmm11
00007a40685d2a7e  vmovaps [rsp+0xB0], xmm12
00007a40685d2a87  vmovaps [rsp+0xC0], xmm13
00007a40685d2a90  vmovaps [rsp+0xD0], xmm14
00007a40685d2a99  vmovaps [rsp+0xE0], xmm15
00007a40685d2aa2  sub rsp, 0x30
00007a40685d2aa6  movaps [rsp], xmm1
00007a40685d2aaa  movaps [rsp+0x10], xmm5
00007a40685d2aaf  movaps [rsp+0x20], xmm13
00007a40685d2ab5  lea rdi, [rsp]
00007a40685d2ab9  mov esi, 0x00
00007a40685d2abe  mov rax, 0x56F679577530
00007a40685d2ac8  call rax
00007a40685d2aca  movaps xmm1, [rsp]
00007a40685d2ace  add rsp, 0x30
00007a40685d2ad2  vmovaps xmm0, [rsp]
00007a40685d2ad7  vmovaps xmm2, [rsp+0x10]
00007a40685d2add  vmovaps xmm3, [rsp+0x20]
00007a40685d2ae3  vmovaps xmm4, [rsp+0x30]
00007a40685d2ae9  vmovaps xmm5, [rsp+0x40]
00007a40685d2aef  vmovaps xmm6, [rsp+0x50]
00007a40685d2af5  vmovaps xmm7, [rsp+0x60]
00007a40685d2afb  vmovaps xmm8, [rsp+0x70]
00007a40685d2b01  vmovaps xmm9, [rsp+0x80]
00007a40685d2b0a  vmovaps xmm10, [rsp+0x90]
00007a40685d2b13  vmovaps xmm11, [rsp+0xA0]
00007a40685d2b1c  vmovaps xmm12, [rsp+0xB0]
00007a40685d2b25  vmovaps xmm13, [rsp+0xC0]
00007a40685d2b2e  vmovaps xmm14, [rsp+0xD0]
00007a40685d2b37  vmovaps xmm15, [rsp+0xE0]
00007a40685d2b40  add rsp, 0xF0
00007a40685d2b47  pop r11
00007a40685d2b49  pop r10
00007a40685d2b4b  pop r9
00007a40685d2b4d  pop r8
00007a40685d2b4f  pop rsi
00007a40685d2b50  pop rdi
00007a40685d2b51  pop rdx
00007a40685d2b52  pop rcx
00007a40685d2b53  pop rax
00007a40685d2b54  add rsp, 0x08
00007a40685d2b58  jmp 0x00007A40685CFDB6
00007a40685d2b5d  sub rsp, 0x08
00007a40685d2b61  push rax
00007a40685d2b62  push rcx
00007a40685d2b63  push rdx
00007a40685d2b64  push rdi
00007a40685d2b65  push rsi
00007a40685d2b66  push r8
00007a40685d2b68  push r9
00007a40685d2b6a  push r10
00007a40685d2b6c  push r11
00007a40685d2b6e  sub rsp, 0xF0
00007a40685d2b75  vmovaps [rsp], xmm0
00007a40685d2b7a  vmovaps [rsp+0x10], xmm1
00007a40685d2b80  vmovaps [rsp+0x20], xmm2
00007a40685d2b86  vmovaps [rsp+0x30], xmm3
00007a40685d2b8c  vmovaps [rsp+0x40], xmm4
00007a40685d2b92  vmovaps [rsp+0x50], xmm6
00007a40685d2b98  vmovaps [rsp+0x60], xmm7
00007a40685d2b9e  vmovaps [rsp+0x70], xmm8
00007a40685d2ba4  vmovaps [rsp+0x80], xmm9
00007a40685d2bad  vmovaps [rsp+0x90], xmm10
00007a40685d2bb6  vmovaps [rsp+0xA0], xmm11
00007a40685d2bbf  vmovaps [rsp+0xB0], xmm12
00007a40685d2bc8  vmovaps [rsp+0xC0], xmm13
00007a40685d2bd1  vmovaps [rsp+0xD0], xmm14
00007a40685d2bda  vmovaps [rsp+0xE0], xmm15
00007a40685d2be3  sub rsp, 0x30
00007a40685d2be7  movaps [rsp], xmm5
00007a40685d2beb  movaps [rsp+0x10], xmm2
00007a40685d2bf0  movaps [rsp+0x20], xmm13
00007a40685d2bf6  lea rdi, [rsp]
00007a40685d2bfa  mov esi, 0x00
00007a40685d2bff  mov rax, 0x56F679577530
00007a40685d2c09  call rax
00007a40685d2c0b  movaps xmm5, [rsp]
00007a40685d2c0f  add rsp, 0x30
00007a40685d2c13  vmovaps xmm0, [rsp]
00007a40685d2c18  vmovaps xmm1, [rsp+0x10]
00007a40685d2c1e  vmovaps xmm2, [rsp+0x20]
00007a40685d2c24  vmovaps xmm3, [rsp+0x30]
00007a40685d2c2a  vmovaps xmm4, [rsp+0x40]
00007a40685d2c30  vmovaps xmm6, [rsp+0x50]
00007a40685d2c36  vmovaps xmm7, [rsp+0x60]
00007a40685d2c3c  vmovaps xmm8, [rsp+0x70]
00007a40685d2c42  vmovaps xmm9, [rsp+0x80]
00007a40685d2c4b  vmovaps xmm10, [rsp+0x90]
00007a40685d2c54  vmovaps xmm11, [rsp+0xA0]
00007a40685d2c5d  vmovaps xmm12, [rsp+0xB0]
00007a40685d2c66  vmovaps xmm13, [rsp+0xC0]
00007a40685d2c6f  vmovaps xmm14, [rsp+0xD0]
00007a40685d2c78  vmovaps xmm15, [rsp+0xE0]
00007a40685d2c81  add rsp, 0xF0
00007a40685d2c88  pop r11
00007a40685d2c8a  pop r10
00007a40685d2c8c  pop r9
00007a40685d2c8e  pop r8
00007a40685d2c90  pop rsi
00007a40685d2c91  pop rdi
00007a40685d2c92  pop rdx
00007a40685d2c93  pop rcx
00007a40685d2c94  pop rax
00007a40685d2c95  add rsp, 0x08
00007a40685d2c99  jmp 0x00007A40685CFDEC
00007a40685d2c9e  sub rsp, 0x08
00007a40685d2ca2  push rax
00007a40685d2ca3  push rcx
00007a40685d2ca4  push rdx
00007a40685d2ca5  push rdi
00007a40685d2ca6  push rsi
00007a40685d2ca7  push r8
00007a40685d2ca9  push r9
00007a40685d2cab  push r10
00007a40685d2cad  push r11
00007a40685d2caf  sub rsp, 0xF0
00007a40685d2cb6  vmovaps [rsp], xmm0
00007a40685d2cbb  vmovaps [rsp+0x10], xmm1
00007a40685d2cc1  vmovaps [rsp+0x20], xmm2
00007a40685d2cc7  vmovaps [rsp+0x30], xmm3
00007a40685d2ccd  vmovaps [rsp+0x40], xmm4
00007a40685d2cd3  vmovaps [rsp+0x50], xmm5
00007a40685d2cd9  vmovaps [rsp+0x60], xmm6
00007a40685d2cdf  vmovaps [rsp+0x70], xmm7
00007a40685d2ce5  vmovaps [rsp+0x80], xmm8
00007a40685d2cee  vmovaps [rsp+0x90], xmm9
00007a40685d2cf7  vmovaps [rsp+0xA0], xmm10
00007a40685d2d00  vmovaps [rsp+0xB0], xmm11
00007a40685d2d09  vmovaps [rsp+0xC0], xmm12
00007a40685d2d12  vmovaps [rsp+0xD0], xmm14
00007a40685d2d1b  vmovaps [rsp+0xE0], xmm15
00007a40685d2d24  sub rsp, 0x30
00007a40685d2d28  movaps [rsp], xmm13
00007a40685d2d2d  movaps [rsp+0x10], xmm10
00007a40685d2d33  movaps [rsp+0x20], xmm1
00007a40685d2d38  lea rdi, [rsp]
00007a40685d2d3c  mov esi, 0x00
00007a40685d2d41  mov rax, 0x56F679577530
00007a40685d2d4b  call rax
00007a40685d2d4d  movaps xmm13, [rsp]
00007a40685d2d52  add rsp, 0x30
00007a40685d2d56  vmovaps xmm0, [rsp]
00007a40685d2d5b  vmovaps xmm1, [rsp+0x10]
00007a40685d2d61  vmovaps xmm2, [rsp+0x20]
00007a40685d2d67  vmovaps xmm3, [rsp+0x30]
00007a40685d2d6d  vmovaps xmm4, [rsp+0x40]
00007a40685d2d73  vmovaps xmm5, [rsp+0x50]
00007a40685d2d79  vmovaps xmm6, [rsp+0x60]
00007a40685d2d7f  vmovaps xmm7, [rsp+0x70]
00007a40685d2d85  vmovaps xmm8, [rsp+0x80]
00007a40685d2d8e  vmovaps xmm9, [rsp+0x90]
00007a40685d2d97  vmovaps xmm10, [rsp+0xA0]
00007a40685d2da0  vmovaps xmm11, [rsp+0xB0]
00007a40685d2da9  vmovaps xmm12, [rsp+0xC0]
00007a40685d2db2  vmovaps xmm14, [rsp+0xD0]
00007a40685d2dbb  vmovaps xmm15, [rsp+0xE0]
00007a40685d2dc4  add rsp, 0xF0
00007a40685d2dcb  pop r11
00007a40685d2dcd  pop r10
00007a40685d2dcf  pop r9
00007a40685d2dd1  pop r8
00007a40685d2dd3  pop rsi
00007a40685d2dd4  pop rdi
00007a40685d2dd5  pop rdx
00007a40685d2dd6  pop rcx
00007a40685d2dd7  pop rax
00007a40685d2dd8  add rsp, 0x08
00007a40685d2ddc  jmp 0x00007A40685CFE15
00007a40685d2de1  sub rsp, 0x08
00007a40685d2de5  push rax
00007a40685d2de6  push rcx
00007a40685d2de7  push rdx
00007a40685d2de8  push rdi
00007a40685d2de9  push rsi
00007a40685d2dea  push r8
00007a40685d2dec  push r9
00007a40685d2dee  push r10
00007a40685d2df0  push r11
00007a40685d2df2  sub rsp, 0xF0
00007a40685d2df9  vmovaps [rsp], xmm0
00007a40685d2dfe  vmovaps [rsp+0x10], xmm2
00007a40685d2e04  vmovaps [rsp+0x20], xmm3
00007a40685d2e0a  vmovaps [rsp+0x30], xmm4
00007a40685d2e10  vmovaps [rsp+0x40], xmm5
00007a40685d2e16  vmovaps [rsp+0x50], xmm6
00007a40685d2e1c  vmovaps [rsp+0x60], xmm7
00007a40685d2e22  vmovaps [rsp+0x70], xmm8
00007a40685d2e28  vmovaps [rsp+0x80], xmm9
00007a40685d2e31  vmovaps [rsp+0x90], xmm10
00007a40685d2e3a  vmovaps [rsp+0xA0], xmm11
00007a40685d2e43  vmovaps [rsp+0xB0], xmm12
00007a40685d2e4c  vmovaps [rsp+0xC0], xmm13
00007a40685d2e55  vmovaps [rsp+0xD0], xmm14
00007a40685d2e5e  vmovaps [rsp+0xE0], xmm15
00007a40685d2e67  sub rsp, 0x30
00007a40685d2e6b  movaps [rsp], xmm1
00007a40685d2e6f  movaps [rsp+0x10], xmm15
00007a40685d2e75  movaps [rsp+0x20], xmm10
00007a40685d2e7b  lea rdi, [rsp]
00007a40685d2e7f  mov esi, 0x00
00007a40685d2e84  mov rax, 0x56F679577530
00007a40685d2e8e  call rax
00007a40685d2e90  movaps xmm1, [rsp]
00007a40685d2e94  add rsp, 0x30
00007a40685d2e98  vmovaps xmm0, [rsp]
00007a40685d2e9d  vmovaps xmm2, [rsp+0x10]
00007a40685d2ea3  vmovaps xmm3, [rsp+0x20]
00007a40685d2ea9  vmovaps xmm4, [rsp+0x30]
00007a40685d2eaf  vmovaps xmm5, [rsp+0x40]
00007a40685d2eb5  vmovaps xmm6, [rsp+0x50]
00007a40685d2ebb  vmovaps xmm7, [rsp+0x60]
00007a40685d2ec1  vmovaps xmm8, [rsp+0x70]
00007a40685d2ec7  vmovaps xmm9, [rsp+0x80]
00007a40685d2ed0  vmovaps xmm10, [rsp+0x90]
00007a40685d2ed9  vmovaps xmm11, [rsp+0xA0]
00007a40685d2ee2  vmovaps xmm12, [rsp+0xB0]
00007a40685d2eeb  vmovaps xmm13, [rsp+0xC0]
00007a40685d2ef4  vmovaps xmm14, [rsp+0xD0]
00007a40685d2efd  vmovaps xmm15, [rsp+0xE0]
00007a40685d2f06  add rsp, 0xF0
00007a40685d2f0d  pop r11
00007a40685d2f0f  pop r10
00007a40685d2f11  pop r9
00007a40685d2f13  pop r8
00007a40685d2f15  pop rsi
00007a40685d2f16  pop rdi
00007a40685d2f17  pop rdx
00007a40685d2f18  pop rcx
00007a40685d2f19  pop rax
00007a40685d2f1a  add rsp, 0x08
00007a40685d2f1e  jmp 0x00007A40685CFE34
00007a40685d2f23  sub rsp, 0x08
00007a40685d2f27  push rax
00007a40685d2f28  push rcx
00007a40685d2f29  push rdx
00007a40685d2f2a  push rdi
00007a40685d2f2b  push rsi
00007a40685d2f2c  push r8
00007a40685d2f2e  push r9
00007a40685d2f30  push r10
00007a40685d2f32  push r11
00007a40685d2f34  sub rsp, 0xF0
00007a40685d2f3b  vmovaps [rsp], xmm0
00007a40685d2f40  vmovaps [rsp+0x10], xmm1
00007a40685d2f46  vmovaps [rsp+0x20], xmm2
00007a40685d2f4c  vmovaps [rsp+0x30], xmm3
00007a40685d2f52  vmovaps [rsp+0x40], xmm4
00007a40685d2f58  vmovaps [rsp+0x50], xmm5
00007a40685d2f5e  vmovaps [rsp+0x60], xmm6
00007a40685d2f64  vmovaps [rsp+0x70], xmm7
00007a40685d2f6a  vmovaps [rsp+0x80], xmm8
00007a40685d2f73  vmovaps [rsp+0x90], xmm9
00007a40685d2f7c  vmovaps [rsp+0xA0], xmm10
00007a40685d2f85  vmovaps [rsp+0xB0], xmm11
00007a40685d2f8e  vmovaps [rsp+0xC0], xmm12
00007a40685d2f97  vmovaps [rsp+0xD0], xmm13
00007a40685d2fa0  vmovaps [rsp+0xE0], xmm14
00007a40685d2fa9  sub rsp, 0x30
00007a40685d2fad  movaps [rsp], xmm15
00007a40685d2fb2  movaps [rsp+0x10], xmm10
00007a40685d2fb8  movaps [rsp+0x20], xmm11
00007a40685d2fbe  lea rdi, [rsp]
00007a40685d2fc2  mov esi, 0x00
00007a40685d2fc7  mov rax, 0x56F679577530
00007a40685d2fd1  call rax
00007a40685d2fd3  movaps xmm15, [rsp]
00007a40685d2fd8  add rsp, 0x30
00007a40685d2fdc  vmovaps xmm0, [rsp]
00007a40685d2fe1  vmovaps xmm1, [rsp+0x10]
00007a40685d2fe7  vmovaps xmm2, [rsp+0x20]
00007a40685d2fed  vmovaps xmm3, [rsp+0x30]
00007a40685d2ff3  vmovaps xmm4, [rsp+0x40]
00007a40685d2ff9  vmovaps xmm5, [rsp+0x50]
00007a40685d2fff  vmovaps xmm6, [rsp+0x60]
00007a40685d3005  vmovaps xmm7, [rsp+0x70]
00007a40685d300b  vmovaps xmm8, [rsp+0x80]
00007a40685d3014  vmovaps xmm9, [rsp+0x90]
00007a40685d301d  vmovaps xmm10, [rsp+0xA0]
00007a40685d3026  vmovaps xmm11, [rsp+0xB0]
00007a40685d302f  vmovaps xmm12, [rsp+0xC0]
00007a40685d3038  vmovaps xmm13, [rsp+0xD0]
00007a40685d3041  vmovaps xmm14, [rsp+0xE0]
00007a40685d304a  add rsp, 0xF0
00007a40685d3051  pop r11
00007a40685d3053  pop r10
00007a40685d3055  pop r9
00007a40685d3057  pop r8
00007a40685d3059  pop rsi
00007a40685d305a  pop rdi
00007a40685d305b  pop rdx
00007a40685d305c  pop rcx
00007a40685d305d  pop rax
00007a40685d305e  add rsp, 0x08
00007a40685d3062  jmp 0x00007A40685CFE57
00007a40685d3067  sub rsp, 0x08
00007a40685d306b  push rax
00007a40685d306c  push rcx
00007a40685d306d  push rdx
00007a40685d306e  push rdi
00007a40685d306f  push rsi
00007a40685d3070  push r8
00007a40685d3072  push r9
00007a40685d3074  push r10
00007a40685d3076  push r11
00007a40685d3078  sub rsp, 0xF0
00007a40685d307f  vmovaps [rsp], xmm0
00007a40685d3084  vmovaps [rsp+0x10], xmm1
00007a40685d308a  vmovaps [rsp+0x20], xmm2
00007a40685d3090  vmovaps [rsp+0x30], xmm3
00007a40685d3096  vmovaps [rsp+0x40], xmm4
00007a40685d309c  vmovaps [rsp+0x50], xmm5
00007a40685d30a2  vmovaps [rsp+0x60], xmm6
00007a40685d30a8  vmovaps [rsp+0x70], xmm7
00007a40685d30ae  vmovaps [rsp+0x80], xmm8
00007a40685d30b7  vmovaps [rsp+0x90], xmm9
00007a40685d30c0  vmovaps [rsp+0xA0], xmm11
00007a40685d30c9  vmovaps [rsp+0xB0], xmm12
00007a40685d30d2  vmovaps [rsp+0xC0], xmm13
00007a40685d30db  vmovaps [rsp+0xD0], xmm14
00007a40685d30e4  vmovaps [rsp+0xE0], xmm15
00007a40685d30ed  sub rsp, 0x30
00007a40685d30f1  movaps [rsp], xmm10
00007a40685d30f6  movaps [rsp+0x10], xmm12
00007a40685d30fc  movaps [rsp+0x20], xmm11
00007a40685d3102  lea rdi, [rsp]
00007a40685d3106  mov esi, 0x00
00007a40685d310b  mov rax, 0x56F679577530
00007a40685d3115  call rax
00007a40685d3117  movaps xmm10, [rsp]
00007a40685d311c  add rsp, 0x30
00007a40685d3120  vmovaps xmm0, [rsp]
00007a40685d3125  vmovaps xmm1, [rsp+0x10]
00007a40685d312b  vmovaps xmm2, [rsp+0x20]
00007a40685d3131  vmovaps xmm3, [rsp+0x30]
00007a40685d3137  vmovaps xmm4, [rsp+0x40]
00007a40685d313d  vmovaps xmm5, [rsp+0x50]
00007a40685d3143  vmovaps xmm6, [rsp+0x60]
00007a40685d3149  vmovaps xmm7, [rsp+0x70]
00007a40685d314f  vmovaps xmm8, [rsp+0x80]
00007a40685d3158  vmovaps xmm9, [rsp+0x90]
00007a40685d3161  vmovaps xmm11, [rsp+0xA0]
00007a40685d316a  vmovaps xmm12, [rsp+0xB0]
00007a40685d3173  vmovaps xmm13, [rsp+0xC0]
00007a40685d317c  vmovaps xmm14, [rsp+0xD0]
00007a40685d3185  vmovaps xmm15, [rsp+0xE0]
00007a40685d318e  add rsp, 0xF0
00007a40685d3195  pop r11
00007a40685d3197  pop r10
00007a40685d3199  pop r9
00007a40685d319b  pop r8
00007a40685d319d  pop rsi
00007a40685d319e  pop rdi
00007a40685d319f  pop rdx
00007a40685d31a0  pop rcx
00007a40685d31a1  pop rax
00007a40685d31a2  add rsp, 0x08
00007a40685d31a6  jmp 0x00007A40685CFE80
00007a40685d31ab  sub rsp, 0x08
00007a40685d31af  push rax
00007a40685d31b0  push rcx
00007a40685d31b1  push rdx
00007a40685d31b2  push rdi
00007a40685d31b3  push rsi
00007a40685d31b4  push r8
00007a40685d31b6  push r9
00007a40685d31b8  push r10
00007a40685d31ba  push r11
00007a40685d31bc  sub rsp, 0xF0
00007a40685d31c3  vmovaps [rsp], xmm0
00007a40685d31c8  vmovaps [rsp+0x10], xmm1
00007a40685d31ce  vmovaps [rsp+0x20], xmm2
00007a40685d31d4  vmovaps [rsp+0x30], xmm3
00007a40685d31da  vmovaps [rsp+0x40], xmm4
00007a40685d31e0  vmovaps [rsp+0x50], xmm5
00007a40685d31e6  vmovaps [rsp+0x60], xmm6
00007a40685d31ec  vmovaps [rsp+0x70], xmm7
00007a40685d31f2  vmovaps [rsp+0x80], xmm8
00007a40685d31fb  vmovaps [rsp+0x90], xmm9
00007a40685d3204  vmovaps [rsp+0xA0], xmm10
00007a40685d320d  vmovaps [rsp+0xB0], xmm12
00007a40685d3216  vmovaps [rsp+0xC0], xmm13
00007a40685d321f  vmovaps [rsp+0xD0], xmm14
00007a40685d3228  vmovaps [rsp+0xE0], xmm15
00007a40685d3231  sub rsp, 0x30
00007a40685d3235  movaps [rsp], xmm11
00007a40685d323a  movaps [rsp+0x10], xmm2
00007a40685d323f  movaps [rsp+0x20], xmm12
00007a40685d3245  lea rdi, [rsp]
00007a40685d3249  mov esi, 0x00
00007a40685d324e  mov rax, 0x56F679577530
00007a40685d3258  call rax
00007a40685d325a  movaps xmm11, [rsp]
00007a40685d325f  add rsp, 0x30
00007a40685d3263  vmovaps xmm0, [rsp]
00007a40685d3268  vmovaps xmm1, [rsp+0x10]
00007a40685d326e  vmovaps xmm2, [rsp+0x20]
00007a40685d3274  vmovaps xmm3, [rsp+0x30]
00007a40685d327a  vmovaps xmm4, [rsp+0x40]
00007a40685d3280  vmovaps xmm5, [rsp+0x50]
00007a40685d3286  vmovaps xmm6, [rsp+0x60]
00007a40685d328c  vmovaps xmm7, [rsp+0x70]
00007a40685d3292  vmovaps xmm8, [rsp+0x80]
00007a40685d329b  vmovaps xmm9, [rsp+0x90]
00007a40685d32a4  vmovaps xmm10, [rsp+0xA0]
00007a40685d32ad  vmovaps xmm12, [rsp+0xB0]
00007a40685d32b6  vmovaps xmm13, [rsp+0xC0]
00007a40685d32bf  vmovaps xmm14, [rsp+0xD0]
00007a40685d32c8  vmovaps xmm15, [rsp+0xE0]
00007a40685d32d1  add rsp, 0xF0
00007a40685d32d8  pop r11
00007a40685d32da  pop r10
00007a40685d32dc  pop r9
00007a40685d32de  pop r8
00007a40685d32e0  pop rsi
00007a40685d32e1  pop rdi
00007a40685d32e2  pop rdx
00007a40685d32e3  pop rcx
00007a40685d32e4  pop rax
00007a40685d32e5  add rsp, 0x08
00007a40685d32e9  jmp 0x00007A40685CFEB8
00007a40685d32ee  sub rsp, 0x08
00007a40685d32f2  push rax
00007a40685d32f3  push rcx
00007a40685d32f4  push rdx
00007a40685d32f5  push rdi
00007a40685d32f6  push rsi
00007a40685d32f7  push r8
00007a40685d32f9  push r9
00007a40685d32fb  push r10
00007a40685d32fd  push r11
00007a40685d32ff  sub rsp, 0xF0
00007a40685d3306  vmovaps [rsp], xmm0
00007a40685d330b  vmovaps [rsp+0x10], xmm2
00007a40685d3311  vmovaps [rsp+0x20], xmm3
00007a40685d3317  vmovaps [rsp+0x30], xmm4
00007a40685d331d  vmovaps [rsp+0x40], xmm5
00007a40685d3323  vmovaps [rsp+0x50], xmm6
00007a40685d3329  vmovaps [rsp+0x60], xmm7
00007a40685d332f  vmovaps [rsp+0x70], xmm8
00007a40685d3335  vmovaps [rsp+0x80], xmm9
00007a40685d333e  vmovaps [rsp+0x90], xmm10
00007a40685d3347  vmovaps [rsp+0xA0], xmm11
00007a40685d3350  vmovaps [rsp+0xB0], xmm12
00007a40685d3359  vmovaps [rsp+0xC0], xmm13
00007a40685d3362  vmovaps [rsp+0xD0], xmm14
00007a40685d336b  vmovaps [rsp+0xE0], xmm15
00007a40685d3374  sub rsp, 0x30
00007a40685d3378  movaps [rsp], xmm1
00007a40685d337c  movaps [rsp+0x10], xmm14
00007a40685d3382  movaps [rsp+0x20], xmm6
00007a40685d3387  lea rdi, [rsp]
00007a40685d338b  mov esi, 0x00
00007a40685d3390  mov rax, 0x56F679577530
00007a40685d339a  call rax
00007a40685d339c  movaps xmm1, [rsp]
00007a40685d33a0  add rsp, 0x30
00007a40685d33a4  vmovaps xmm0, [rsp]
00007a40685d33a9  vmovaps xmm2, [rsp+0x10]
00007a40685d33af  vmovaps xmm3, [rsp+0x20]
00007a40685d33b5  vmovaps xmm4, [rsp+0x30]
00007a40685d33bb  vmovaps xmm5, [rsp+0x40]
00007a40685d33c1  vmovaps xmm6, [rsp+0x50]
00007a40685d33c7  vmovaps xmm7, [rsp+0x60]
00007a40685d33cd  vmovaps xmm8, [rsp+0x70]
00007a40685d33d3  vmovaps xmm9, [rsp+0x80]
00007a40685d33dc  vmovaps xmm10, [rsp+0x90]
00007a40685d33e5  vmovaps xmm11, [rsp+0xA0]
00007a40685d33ee  vmovaps xmm12, [rsp+0xB0]
00007a40685d33f7  vmovaps xmm13, [rsp+0xC0]
00007a40685d3400  vmovaps xmm14, [rsp+0xD0]
00007a40685d3409  vmovaps xmm15, [rsp+0xE0]
00007a40685d3412  add rsp, 0xF0
00007a40685d3419  pop r11
00007a40685d341b  pop r10
00007a40685d341d  pop r9
00007a40685d341f  pop r8
00007a40685d3421  pop rsi
00007a40685d3422  pop rdi
00007a40685d3423  pop rdx
00007a40685d3424  pop rcx
00007a40685d3425  pop rax
00007a40685d3426  add rsp, 0x08
00007a40685d342a  jmp 0x00007A40685CFED1
00007a40685d342f  sub rsp, 0x08
00007a40685d3433  push rax
00007a40685d3434  push rcx
00007a40685d3435  push rdx
00007a40685d3436  push rdi
00007a40685d3437  push rsi
00007a40685d3438  push r8
00007a40685d343a  push r9
00007a40685d343c  push r10
00007a40685d343e  push r11
00007a40685d3440  sub rsp, 0xF0
00007a40685d3447  vmovaps [rsp], xmm0
00007a40685d344c  vmovaps [rsp+0x10], xmm1
00007a40685d3452  vmovaps [rsp+0x20], xmm2
00007a40685d3458  vmovaps [rsp+0x30], xmm3
00007a40685d345e  vmovaps [rsp+0x40], xmm4
00007a40685d3464  vmovaps [rsp+0x50], xmm5
00007a40685d346a  vmovaps [rsp+0x60], xmm6
00007a40685d3470  vmovaps [rsp+0x70], xmm7
00007a40685d3476  vmovaps [rsp+0x80], xmm8
00007a40685d347f  vmovaps [rsp+0x90], xmm9
00007a40685d3488  vmovaps [rsp+0xA0], xmm10
00007a40685d3491  vmovaps [rsp+0xB0], xmm11
00007a40685d349a  vmovaps [rsp+0xC0], xmm12
00007a40685d34a3  vmovaps [rsp+0xD0], xmm13
00007a40685d34ac  vmovaps [rsp+0xE0], xmm15
00007a40685d34b5  sub rsp, 0x30
00007a40685d34b9  movaps [rsp], xmm14
00007a40685d34be  movaps [rsp+0x10], xmm12
00007a40685d34c4  movaps [rsp+0x20], xmm5
00007a40685d34c9  lea rdi, [rsp]
00007a40685d34cd  mov esi, 0x00
00007a40685d34d2  mov rax, 0x56F679577530
00007a40685d34dc  call rax
00007a40685d34de  movaps xmm14, [rsp]
00007a40685d34e3  add rsp, 0x30
00007a40685d34e7  vmovaps xmm0, [rsp]
00007a40685d34ec  vmovaps xmm1, [rsp+0x10]
00007a40685d34f2  vmovaps xmm2, [rsp+0x20]
00007a40685d34f8  vmovaps xmm3, [rsp+0x30]
00007a40685d34fe  vmovaps xmm4, [rsp+0x40]
00007a40685d3504  vmovaps xmm5, [rsp+0x50]
00007a40685d350a  vmovaps xmm6, [rsp+0x60]
00007a40685d3510  vmovaps xmm7, [rsp+0x70]
00007a40685d3516  vmovaps xmm8, [rsp+0x80]
00007a40685d351f  vmovaps xmm9, [rsp+0x90]
00007a40685d3528  vmovaps xmm10, [rsp+0xA0]
00007a40685d3531  vmovaps xmm11, [rsp+0xB0]
00007a40685d353a  vmovaps xmm12, [rsp+0xC0]
00007a40685d3543  vmovaps xmm13, [rsp+0xD0]
00007a40685d354c  vmovaps xmm15, [rsp+0xE0]
00007a40685d3555  add rsp, 0xF0
00007a40685d355c  pop r11
00007a40685d355e  pop r10
00007a40685d3560  pop r9
00007a40685d3562  pop r8
00007a40685d3564  pop rsi
00007a40685d3565  pop rdi
00007a40685d3566  pop rdx
00007a40685d3567  pop rcx
00007a40685d3568  pop rax
00007a40685d3569  add rsp, 0x08
00007a40685d356d  jmp 0x00007A40685CFEF1
00007a40685d3572  sub rsp, 0x08
00007a40685d3576  push rax
00007a40685d3577  push rcx
00007a40685d3578  push rdx
00007a40685d3579  push rdi
00007a40685d357a  push rsi
00007a40685d357b  push r8
00007a40685d357d  push r9
00007a40685d357f  push r10
00007a40685d3581  push r11
00007a40685d3583  sub rsp, 0xF0
00007a40685d358a  vmovaps [rsp], xmm0
00007a40685d358f  vmovaps [rsp+0x10], xmm1
00007a40685d3595  vmovaps [rsp+0x20], xmm2
00007a40685d359b  vmovaps [rsp+0x30], xmm3
00007a40685d35a1  vmovaps [rsp+0x40], xmm4
00007a40685d35a7  vmovaps [rsp+0x50], xmm5
00007a40685d35ad  vmovaps [rsp+0x60], xmm7
00007a40685d35b3  vmovaps [rsp+0x70], xmm8
00007a40685d35b9  vmovaps [rsp+0x80], xmm9
00007a40685d35c2  vmovaps [rsp+0x90], xmm10
00007a40685d35cb  vmovaps [rsp+0xA0], xmm11
00007a40685d35d4  vmovaps [rsp+0xB0], xmm12
00007a40685d35dd  vmovaps [rsp+0xC0], xmm13
00007a40685d35e6  vmovaps [rsp+0xD0], xmm14
00007a40685d35ef  vmovaps [rsp+0xE0], xmm15
00007a40685d35f8  sub rsp, 0x30
00007a40685d35fc  movaps [rsp], xmm6
00007a40685d3600  movaps [rsp+0x10], xmm9
00007a40685d3606  movaps [rsp+0x20], xmm12
00007a40685d360c  lea rdi, [rsp]
00007a40685d3610  mov esi, 0x00
00007a40685d3615  mov rax, 0x56F679577530
00007a40685d361f  call rax
00007a40685d3621  movaps xmm6, [rsp]
00007a40685d3625  add rsp, 0x30
00007a40685d3629  vmovaps xmm0, [rsp]
00007a40685d362e  vmovaps xmm1, [rsp+0x10]
00007a40685d3634  vmovaps xmm2, [rsp+0x20]
00007a40685d363a  vmovaps xmm3, [rsp+0x30]
00007a40685d3640  vmovaps xmm4, [rsp+0x40]
00007a40685d3646  vmovaps xmm5, [rsp+0x50]
00007a40685d364c  vmovaps xmm7, [rsp+0x60]
00007a40685d3652  vmovaps xmm8, [rsp+0x70]
00007a40685d3658  vmovaps xmm9, [rsp+0x80]
00007a40685d3661  vmovaps xmm10, [rsp+0x90]
00007a40685d366a  vmovaps xmm11, [rsp+0xA0]
00007a40685d3673  vmovaps xmm12, [rsp+0xB0]
00007a40685d367c  vmovaps xmm13, [rsp+0xC0]
00007a40685d3685  vmovaps xmm14, [rsp+0xD0]
00007a40685d368e  vmovaps xmm15, [rsp+0xE0]
00007a40685d3697  add rsp, 0xF0
00007a40685d369e  pop r11
00007a40685d36a0  pop r10
00007a40685d36a2  pop r9
00007a40685d36a4  pop r8
00007a40685d36a6  pop rsi
00007a40685d36a7  pop rdi
00007a40685d36a8  pop rdx
00007a40685d36a9  pop rcx
00007a40685d36aa  pop rax
00007a40685d36ab  add rsp, 0x08
00007a40685d36af  jmp 0x00007A40685CFF19
00007a40685d36b4  sub rsp, 0x08
00007a40685d36b8  push rax
00007a40685d36b9  push rcx
00007a40685d36ba  push rdx
00007a40685d36bb  push rdi
00007a40685d36bc  push rsi
00007a40685d36bd  push r8
00007a40685d36bf  push r9
00007a40685d36c1  push r10
00007a40685d36c3  push r11
00007a40685d36c5  sub rsp, 0xF0
00007a40685d36cc  vmovaps [rsp], xmm0
00007a40685d36d1  vmovaps [rsp+0x10], xmm1
00007a40685d36d7  vmovaps [rsp+0x20], xmm2
00007a40685d36dd  vmovaps [rsp+0x30], xmm3
00007a40685d36e3  vmovaps [rsp+0x40], xmm4
00007a40685d36e9  vmovaps [rsp+0x50], xmm5
00007a40685d36ef  vmovaps [rsp+0x60], xmm6
00007a40685d36f5  vmovaps [rsp+0x70], xmm7
00007a40685d36fb  vmovaps [rsp+0x80], xmm8
00007a40685d3704  vmovaps [rsp+0x90], xmm9
00007a40685d370d  vmovaps [rsp+0xA0], xmm10
00007a40685d3716  vmovaps [rsp+0xB0], xmm11
00007a40685d371f  vmovaps [rsp+0xC0], xmm13
00007a40685d3728  vmovaps [rsp+0xD0], xmm14
00007a40685d3731  vmovaps [rsp+0xE0], xmm15
00007a40685d373a  sub rsp, 0x30
00007a40685d373e  movaps [rsp], xmm12
00007a40685d3743  movaps [rsp+0x10], xmm15
00007a40685d3749  movaps [rsp+0x20], xmm13
00007a40685d374f  lea rdi, [rsp]
00007a40685d3753  mov esi, 0x00
00007a40685d3758  mov rax, 0x56F679577530
00007a40685d3762  call rax
00007a40685d3764  movaps xmm12, [rsp]
00007a40685d3769  add rsp, 0x30
00007a40685d376d  vmovaps xmm0, [rsp]
00007a40685d3772  vmovaps xmm1, [rsp+0x10]
00007a40685d3778  vmovaps xmm2, [rsp+0x20]
00007a40685d377e  vmovaps xmm3, [rsp+0x30]
00007a40685d3784  vmovaps xmm4, [rsp+0x40]
00007a40685d378a  vmovaps xmm5, [rsp+0x50]
00007a40685d3790  vmovaps xmm6, [rsp+0x60]
00007a40685d3796  vmovaps xmm7, [rsp+0x70]
00007a40685d379c  vmovaps xmm8, [rsp+0x80]
00007a40685d37a5  vmovaps xmm9, [rsp+0x90]
00007a40685d37ae  vmovaps xmm10, [rsp+0xA0]
00007a40685d37b7  vmovaps xmm11, [rsp+0xB0]
00007a40685d37c0  vmovaps xmm13, [rsp+0xC0]
00007a40685d37c9  vmovaps xmm14, [rsp+0xD0]
00007a40685d37d2  vmovaps xmm15, [rsp+0xE0]
00007a40685d37db  add rsp, 0xF0
00007a40685d37e2  pop r11
00007a40685d37e4  pop r10
00007a40685d37e6  pop r9
00007a40685d37e8  pop r8
00007a40685d37ea  pop rsi
00007a40685d37eb  pop rdi
00007a40685d37ec  pop rdx
00007a40685d37ed  pop rcx
00007a40685d37ee  pop rax
00007a40685d37ef  add rsp, 0x08
00007a40685d37f3  jmp 0x00007A40685CFF34
00007a40685d37f8  sub rsp, 0x08
00007a40685d37fc  push rax
00007a40685d37fd  push rcx
00007a40685d37fe  push rdx
00007a40685d37ff  push rdi
00007a40685d3800  push rsi
00007a40685d3801  push r8
00007a40685d3803  push r9
00007a40685d3805  push r10
00007a40685d3807  push r11
00007a40685d3809  sub rsp, 0xF0
00007a40685d3810  vmovaps [rsp], xmm0
00007a40685d3815  vmovaps [rsp+0x10], xmm1
00007a40685d381b  vmovaps [rsp+0x20], xmm2
00007a40685d3821  vmovaps [rsp+0x30], xmm3
00007a40685d3827  vmovaps [rsp+0x40], xmm4
00007a40685d382d  vmovaps [rsp+0x50], xmm5
00007a40685d3833  vmovaps [rsp+0x60], xmm6
00007a40685d3839  vmovaps [rsp+0x70], xmm7
00007a40685d383f  vmovaps [rsp+0x80], xmm8
00007a40685d3848  vmovaps [rsp+0x90], xmm9
00007a40685d3851  vmovaps [rsp+0xA0], xmm10
00007a40685d385a  vmovaps [rsp+0xB0], xmm11
00007a40685d3863  vmovaps [rsp+0xC0], xmm12
00007a40685d386c  vmovaps [rsp+0xD0], xmm13
00007a40685d3875  vmovaps [rsp+0xE0], xmm14
00007a40685d387e  sub rsp, 0x30
00007a40685d3882  movaps [rsp], xmm15
00007a40685d3887  movaps [rsp+0x10], xmm13
00007a40685d388d  movaps [rsp+0x20], xmm10
00007a40685d3893  lea rdi, [rsp]
00007a40685d3897  mov esi, 0x00
00007a40685d389c  mov rax, 0x56F679577530
00007a40685d38a6  call rax
00007a40685d38a8  movaps xmm15, [rsp]
00007a40685d38ad  add rsp, 0x30
00007a40685d38b1  vmovaps xmm0, [rsp]
00007a40685d38b6  vmovaps xmm1, [rsp+0x10]
00007a40685d38bc  vmovaps xmm2, [rsp+0x20]
00007a40685d38c2  vmovaps xmm3, [rsp+0x30]
00007a40685d38c8  vmovaps xmm4, [rsp+0x40]
00007a40685d38ce  vmovaps xmm5, [rsp+0x50]
00007a40685d38d4  vmovaps xmm6, [rsp+0x60]
00007a40685d38da  vmovaps xmm7, [rsp+0x70]
00007a40685d38e0  vmovaps xmm8, [rsp+0x80]
00007a40685d38e9  vmovaps xmm9, [rsp+0x90]
00007a40685d38f2  vmovaps xmm10, [rsp+0xA0]
00007a40685d38fb  vmovaps xmm11, [rsp+0xB0]
00007a40685d3904  vmovaps xmm12, [rsp+0xC0]
00007a40685d390d  vmovaps xmm13, [rsp+0xD0]
00007a40685d3916  vmovaps xmm14, [rsp+0xE0]
00007a40685d391f  add rsp, 0xF0
00007a40685d3926  pop r11
00007a40685d3928  pop r10
00007a40685d392a  pop r9
00007a40685d392c  pop r8
00007a40685d392e  pop rsi
00007a40685d392f  pop rdi
00007a40685d3930  pop rdx
00007a40685d3931  pop rcx
00007a40685d3932  pop rax
00007a40685d3933  add rsp, 0x08
00007a40685d3937  jmp 0x00007A40685CFF55
00007a40685d393c  call 0x00007A406840C260
00007a40685d3941  jmp 0x00007A40685CFFB0
00007a40685d3946  sub rsp, 0x08
00007a40685d394a  push rax
00007a40685d394b  push rcx
00007a40685d394c  push rdx
00007a40685d394d  push rdi
00007a40685d394e  push rsi
00007a40685d394f  push r8
00007a40685d3951  push r9
00007a40685d3953  push r10
00007a40685d3955  push r11
00007a40685d3957  sub rsp, 0xF0
00007a40685d395e  vmovaps [rsp], xmm0
00007a40685d3963  vmovaps [rsp+0x10], xmm1
00007a40685d3969  vmovaps [rsp+0x20], xmm2
00007a40685d396f  vmovaps [rsp+0x30], xmm3
00007a40685d3975  vmovaps [rsp+0x40], xmm4
00007a40685d397b  vmovaps [rsp+0x50], xmm5
00007a40685d3981  vmovaps [rsp+0x60], xmm6
00007a40685d3987  vmovaps [rsp+0x70], xmm7
00007a40685d398d  vmovaps [rsp+0x80], xmm8
00007a40685d3996  vmovaps [rsp+0x90], xmm10
00007a40685d399f  vmovaps [rsp+0xA0], xmm11
00007a40685d39a8  vmovaps [rsp+0xB0], xmm12
00007a40685d39b1  vmovaps [rsp+0xC0], xmm13
00007a40685d39ba  vmovaps [rsp+0xD0], xmm14
00007a40685d39c3  vmovaps [rsp+0xE0], xmm15
00007a40685d39cc  sub rsp, 0x30
00007a40685d39d0  movaps [rsp], xmm9
00007a40685d39d5  movaps [rsp+0x10], xmm8
00007a40685d39db  movaps [rsp+0x20], xmm10
00007a40685d39e1  lea rdi, [rsp]
00007a40685d39e5  mov esi, 0x00
00007a40685d39ea  mov rax, 0x56F679577530
00007a40685d39f4  call rax
00007a40685d39f6  movaps xmm9, [rsp]
00007a40685d39fb  add rsp, 0x30
00007a40685d39ff  vmovaps xmm0, [rsp]
00007a40685d3a04  vmovaps xmm1, [rsp+0x10]
00007a40685d3a0a  vmovaps xmm2, [rsp+0x20]
00007a40685d3a10  vmovaps xmm3, [rsp+0x30]
00007a40685d3a16  vmovaps xmm4, [rsp+0x40]
00007a40685d3a1c  vmovaps xmm5, [rsp+0x50]
00007a40685d3a22  vmovaps xmm6, [rsp+0x60]
00007a40685d3a28  vmovaps xmm7, [rsp+0x70]
00007a40685d3a2e  vmovaps xmm8, [rsp+0x80]
00007a40685d3a37  vmovaps xmm10, [rsp+0x90]
00007a40685d3a40  vmovaps xmm11, [rsp+0xA0]
00007a40685d3a49  vmovaps xmm12, [rsp+0xB0]
00007a40685d3a52  vmovaps xmm13, [rsp+0xC0]
00007a40685d3a5b  vmovaps xmm14, [rsp+0xD0]
00007a40685d3a64  vmovaps xmm15, [rsp+0xE0]
00007a40685d3a6d  add rsp, 0xF0
00007a40685d3a74  pop r11
00007a40685d3a76  pop r10
00007a40685d3a78  pop r9
00007a40685d3a7a  pop r8
00007a40685d3a7c  pop rsi
00007a40685d3a7d  pop rdi
00007a40685d3a7e  pop rdx
00007a40685d3a7f  pop rcx
00007a40685d3a80  pop rax
00007a40685d3a81  add rsp, 0x08
00007a40685d3a85  jmp 0x00007A40685CFFE1
00007a40685d3a8a  sub rsp, 0x08
00007a40685d3a8e  push rax
00007a40685d3a8f  push rcx
00007a40685d3a90  push rdx
00007a40685d3a91  push rdi
00007a40685d3a92  push rsi
00007a40685d3a93  push r8
00007a40685d3a95  push r9
00007a40685d3a97  push r10
00007a40685d3a99  push r11
00007a40685d3a9b  sub rsp, 0xF0
00007a40685d3aa2  vmovaps [rsp], xmm0
00007a40685d3aa7  vmovaps [rsp+0x10], xmm1
00007a40685d3aad  vmovaps [rsp+0x20], xmm2
00007a40685d3ab3  vmovaps [rsp+0x30], xmm3
00007a40685d3ab9  vmovaps [rsp+0x40], xmm4
00007a40685d3abf  vmovaps [rsp+0x50], xmm5
00007a40685d3ac5  vmovaps [rsp+0x60], xmm6
00007a40685d3acb  vmovaps [rsp+0x70], xmm7
00007a40685d3ad1  vmovaps [rsp+0x80], xmm8
00007a40685d3ada  vmovaps [rsp+0x90], xmm9
00007a40685d3ae3  vmovaps [rsp+0xA0], xmm11
00007a40685d3aec  vmovaps [rsp+0xB0], xmm12
00007a40685d3af5  vmovaps [rsp+0xC0], xmm13
00007a40685d3afe  vmovaps [rsp+0xD0], xmm14
00007a40685d3b07  vmovaps [rsp+0xE0], xmm15
00007a40685d3b10  sub rsp, 0x30
00007a40685d3b14  movaps [rsp], xmm10
00007a40685d3b19  movaps [rsp+0x10], xmm1
00007a40685d3b1e  movaps [rsp+0x20], xmm11
00007a40685d3b24  lea rdi, [rsp]
00007a40685d3b28  mov esi, 0x00
00007a40685d3b2d  mov rax, 0x56F679577530
00007a40685d3b37  call rax
00007a40685d3b39  movaps xmm10, [rsp]
00007a40685d3b3e  add rsp, 0x30
00007a40685d3b42  vmovaps xmm0, [rsp]
00007a40685d3b47  vmovaps xmm1, [rsp+0x10]
00007a40685d3b4d  vmovaps xmm2, [rsp+0x20]
00007a40685d3b53  vmovaps xmm3, [rsp+0x30]
00007a40685d3b59  vmovaps xmm4, [rsp+0x40]
00007a40685d3b5f  vmovaps xmm5, [rsp+0x50]
00007a40685d3b65  vmovaps xmm6, [rsp+0x60]
00007a40685d3b6b  vmovaps xmm7, [rsp+0x70]
00007a40685d3b71  vmovaps xmm8, [rsp+0x80]
00007a40685d3b7a  vmovaps xmm9, [rsp+0x90]
00007a40685d3b83  vmovaps xmm11, [rsp+0xA0]
00007a40685d3b8c  vmovaps xmm12, [rsp+0xB0]
00007a40685d3b95  vmovaps xmm13, [rsp+0xC0]
00007a40685d3b9e  vmovaps xmm14, [rsp+0xD0]
00007a40685d3ba7  vmovaps xmm15, [rsp+0xE0]
00007a40685d3bb0  add rsp, 0xF0
00007a40685d3bb7  pop r11
00007a40685d3bb9  pop r10
00007a40685d3bbb  pop r9
00007a40685d3bbd  pop r8
00007a40685d3bbf  pop rsi
00007a40685d3bc0  pop rdi
00007a40685d3bc1  pop rdx
00007a40685d3bc2  pop rcx
00007a40685d3bc3  pop rax
00007a40685d3bc4  add rsp, 0x08
00007a40685d3bc8  jmp 0x00007A40685CFFFC
00007a40685d3bcd  sub rsp, 0x08
00007a40685d3bd1  push rax
00007a40685d3bd2  push rcx
00007a40685d3bd3  push rdx
00007a40685d3bd4  push rdi
00007a40685d3bd5  push rsi
00007a40685d3bd6  push r8
00007a40685d3bd8  push r9
00007a40685d3bda  push r10
00007a40685d3bdc  push r11
00007a40685d3bde  sub rsp, 0xF0
00007a40685d3be5  vmovaps [rsp], xmm0
00007a40685d3bea  vmovaps [rsp+0x10], xmm2
00007a40685d3bf0  vmovaps [rsp+0x20], xmm3
00007a40685d3bf6  vmovaps [rsp+0x30], xmm4
00007a40685d3bfc  vmovaps [rsp+0x40], xmm5
00007a40685d3c02  vmovaps [rsp+0x50], xmm6
00007a40685d3c08  vmovaps [rsp+0x60], xmm7
00007a40685d3c0e  vmovaps [rsp+0x70], xmm8
00007a40685d3c14  vmovaps [rsp+0x80], xmm9
00007a40685d3c1d  vmovaps [rsp+0x90], xmm10
00007a40685d3c26  vmovaps [rsp+0xA0], xmm11
00007a40685d3c2f  vmovaps [rsp+0xB0], xmm12
00007a40685d3c38  vmovaps [rsp+0xC0], xmm13
00007a40685d3c41  vmovaps [rsp+0xD0], xmm14
00007a40685d3c4a  vmovaps [rsp+0xE0], xmm15
00007a40685d3c53  sub rsp, 0x30
00007a40685d3c57  movaps [rsp], xmm1
00007a40685d3c5b  movaps [rsp+0x10], xmm14
00007a40685d3c61  movaps [rsp+0x20], xmm6
00007a40685d3c66  lea rdi, [rsp]
00007a40685d3c6a  mov esi, 0x00
00007a40685d3c6f  mov rax, 0x56F679577530
00007a40685d3c79  call rax
00007a40685d3c7b  movaps xmm1, [rsp]
00007a40685d3c7f  add rsp, 0x30
00007a40685d3c83  vmovaps xmm0, [rsp]
00007a40685d3c88  vmovaps xmm2, [rsp+0x10]
00007a40685d3c8e  vmovaps xmm3, [rsp+0x20]
00007a40685d3c94  vmovaps xmm4, [rsp+0x30]
00007a40685d3c9a  vmovaps xmm5, [rsp+0x40]
00007a40685d3ca0  vmovaps xmm6, [rsp+0x50]
00007a40685d3ca6  vmovaps xmm7, [rsp+0x60]
00007a40685d3cac  vmovaps xmm8, [rsp+0x70]
00007a40685d3cb2  vmovaps xmm9, [rsp+0x80]
00007a40685d3cbb  vmovaps xmm10, [rsp+0x90]
00007a40685d3cc4  vmovaps xmm11, [rsp+0xA0]
00007a40685d3ccd  vmovaps xmm12, [rsp+0xB0]
00007a40685d3cd6  vmovaps xmm13, [rsp+0xC0]
00007a40685d3cdf  vmovaps xmm14, [rsp+0xD0]
00007a40685d3ce8  vmovaps xmm15, [rsp+0xE0]
00007a40685d3cf1  add rsp, 0xF0
00007a40685d3cf8  pop r11
00007a40685d3cfa  pop r10
00007a40685d3cfc  pop r9
00007a40685d3cfe  pop r8
00007a40685d3d00  pop rsi
00007a40685d3d01  pop rdi
00007a40685d3d02  pop rdx
00007a40685d3d03  pop rcx
00007a40685d3d04  pop rax
00007a40685d3d05  add rsp, 0x08
00007a40685d3d09  jmp 0x00007A40685D0015
00007a40685d3d0e  sub rsp, 0x08
00007a40685d3d12  push rax
00007a40685d3d13  push rcx
00007a40685d3d14  push rdx
00007a40685d3d15  push rdi
00007a40685d3d16  push rsi
00007a40685d3d17  push r8
00007a40685d3d19  push r9
00007a40685d3d1b  push r10
00007a40685d3d1d  push r11
00007a40685d3d1f  sub rsp, 0xF0
00007a40685d3d26  vmovaps [rsp], xmm0
00007a40685d3d2b  vmovaps [rsp+0x10], xmm1
00007a40685d3d31  vmovaps [rsp+0x20], xmm2
00007a40685d3d37  vmovaps [rsp+0x30], xmm3
00007a40685d3d3d  vmovaps [rsp+0x40], xmm4
00007a40685d3d43  vmovaps [rsp+0x50], xmm5
00007a40685d3d49  vmovaps [rsp+0x60], xmm6
00007a40685d3d4f  vmovaps [rsp+0x70], xmm7
00007a40685d3d55  vmovaps [rsp+0x80], xmm8
00007a40685d3d5e  vmovaps [rsp+0x90], xmm9
00007a40685d3d67  vmovaps [rsp+0xA0], xmm10
00007a40685d3d70  vmovaps [rsp+0xB0], xmm12
00007a40685d3d79  vmovaps [rsp+0xC0], xmm13
00007a40685d3d82  vmovaps [rsp+0xD0], xmm14
00007a40685d3d8b  vmovaps [rsp+0xE0], xmm15
00007a40685d3d94  sub rsp, 0x30
00007a40685d3d98  movaps [rsp], xmm11
00007a40685d3d9d  movaps [rsp+0x10], xmm13
00007a40685d3da3  movaps [rsp+0x20], xmm14
00007a40685d3da9  lea rdi, [rsp]
00007a40685d3dad  mov esi, 0x00
00007a40685d3db2  mov rax, 0x56F679577530
00007a40685d3dbc  call rax
00007a40685d3dbe  movaps xmm11, [rsp]
00007a40685d3dc3  add rsp, 0x30
00007a40685d3dc7  vmovaps xmm0, [rsp]
00007a40685d3dcc  vmovaps xmm1, [rsp+0x10]
00007a40685d3dd2  vmovaps xmm2, [rsp+0x20]
00007a40685d3dd8  vmovaps xmm3, [rsp+0x30]
00007a40685d3dde  vmovaps xmm4, [rsp+0x40]
00007a40685d3de4  vmovaps xmm5, [rsp+0x50]
00007a40685d3dea  vmovaps xmm6, [rsp+0x60]
00007a40685d3df0  vmovaps xmm7, [rsp+0x70]
00007a40685d3df6  vmovaps xmm8, [rsp+0x80]
00007a40685d3dff  vmovaps xmm9, [rsp+0x90]
00007a40685d3e08  vmovaps xmm10, [rsp+0xA0]
00007a40685d3e11  vmovaps xmm12, [rsp+0xB0]
00007a40685d3e1a  vmovaps xmm13, [rsp+0xC0]
00007a40685d3e23  vmovaps xmm14, [rsp+0xD0]
00007a40685d3e2c  vmovaps xmm15, [rsp+0xE0]
00007a40685d3e35  add rsp, 0xF0
00007a40685d3e3c  pop r11
00007a40685d3e3e  pop r10
00007a40685d3e40  pop r9
00007a40685d3e42  pop r8
00007a40685d3e44  pop rsi
00007a40685d3e45  pop rdi
00007a40685d3e46  pop rdx
00007a40685d3e47  pop rcx
00007a40685d3e48  pop rax
00007a40685d3e49  add rsp, 0x08
00007a40685d3e4d  jmp 0x00007A40685D003F
00007a40685d3e52  sub rsp, 0x08
00007a40685d3e56  push rax
00007a40685d3e57  push rcx
00007a40685d3e58  push rdx
00007a40685d3e59  push rdi
00007a40685d3e5a  push rsi
00007a40685d3e5b  push r8
00007a40685d3e5d  push r9
00007a40685d3e5f  push r10
00007a40685d3e61  push r11
00007a40685d3e63  sub rsp, 0xF0
00007a40685d3e6a  vmovaps [rsp], xmm0
00007a40685d3e6f  vmovaps [rsp+0x10], xmm1
00007a40685d3e75  vmovaps [rsp+0x20], xmm2
00007a40685d3e7b  vmovaps [rsp+0x30], xmm3
00007a40685d3e81  vmovaps [rsp+0x40], xmm4
00007a40685d3e87  vmovaps [rsp+0x50], xmm5
00007a40685d3e8d  vmovaps [rsp+0x60], xmm6
00007a40685d3e93  vmovaps [rsp+0x70], xmm7
00007a40685d3e99  vmovaps [rsp+0x80], xmm8
00007a40685d3ea2  vmovaps [rsp+0x90], xmm9
00007a40685d3eab  vmovaps [rsp+0xA0], xmm10
00007a40685d3eb4  vmovaps [rsp+0xB0], xmm11
00007a40685d3ebd  vmovaps [rsp+0xC0], xmm12
00007a40685d3ec6  vmovaps [rsp+0xD0], xmm14
00007a40685d3ecf  vmovaps [rsp+0xE0], xmm15
00007a40685d3ed8  sub rsp, 0x30
00007a40685d3edc  movaps [rsp], xmm13
00007a40685d3ee1  movaps [rsp+0x10], xmm8
00007a40685d3ee7  movaps [rsp+0x20], xmm14
00007a40685d3eed  lea rdi, [rsp]
00007a40685d3ef1  mov esi, 0x00
00007a40685d3ef6  mov rax, 0x56F679577530
00007a40685d3f00  call rax
00007a40685d3f02  movaps xmm13, [rsp]
00007a40685d3f07  add rsp, 0x30
00007a40685d3f0b  vmovaps xmm0, [rsp]
00007a40685d3f10  vmovaps xmm1, [rsp+0x10]
00007a40685d3f16  vmovaps xmm2, [rsp+0x20]
00007a40685d3f1c  vmovaps xmm3, [rsp+0x30]
00007a40685d3f22  vmovaps xmm4, [rsp+0x40]
00007a40685d3f28  vmovaps xmm5, [rsp+0x50]
00007a40685d3f2e  vmovaps xmm6, [rsp+0x60]
00007a40685d3f34  vmovaps xmm7, [rsp+0x70]
00007a40685d3f3a  vmovaps xmm8, [rsp+0x80]
00007a40685d3f43  vmovaps xmm9, [rsp+0x90]
00007a40685d3f4c  vmovaps xmm10, [rsp+0xA0]
00007a40685d3f55  vmovaps xmm11, [rsp+0xB0]
00007a40685d3f5e  vmovaps xmm12, [rsp+0xC0]
00007a40685d3f67  vmovaps xmm14, [rsp+0xD0]
00007a40685d3f70  vmovaps xmm15, [rsp+0xE0]
00007a40685d3f79  add rsp, 0xF0
00007a40685d3f80  pop r11
00007a40685d3f82  pop r10
00007a40685d3f84  pop r9
00007a40685d3f86  pop r8
00007a40685d3f88  pop rsi
00007a40685d3f89  pop rdi
00007a40685d3f8a  pop rdx
00007a40685d3f8b  pop rcx
00007a40685d3f8c  pop rax
00007a40685d3f8d  add rsp, 0x08
00007a40685d3f91  jmp 0x00007A40685D006E
00007a40685d3f96  sub rsp, 0x08
00007a40685d3f9a  push rax
00007a40685d3f9b  push rcx
00007a40685d3f9c  push rdx
00007a40685d3f9d  push rdi
00007a40685d3f9e  push rsi
00007a40685d3f9f  push r8
00007a40685d3fa1  push r9
00007a40685d3fa3  push r10
00007a40685d3fa5  push r11
00007a40685d3fa7  sub rsp, 0xF0
00007a40685d3fae  vmovaps [rsp], xmm0
00007a40685d3fb3  vmovaps [rsp+0x10], xmm1
00007a40685d3fb9  vmovaps [rsp+0x20], xmm2
00007a40685d3fbf  vmovaps [rsp+0x30], xmm3
00007a40685d3fc5  vmovaps [rsp+0x40], xmm4
00007a40685d3fcb  vmovaps [rsp+0x50], xmm5
00007a40685d3fd1  vmovaps [rsp+0x60], xmm6
00007a40685d3fd7  vmovaps [rsp+0x70], xmm7
00007a40685d3fdd  vmovaps [rsp+0x80], xmm9
00007a40685d3fe6  vmovaps [rsp+0x90], xmm10
00007a40685d3fef  vmovaps [rsp+0xA0], xmm11
00007a40685d3ff8  vmovaps [rsp+0xB0], xmm12
00007a40685d4001  vmovaps [rsp+0xC0], xmm13
00007a40685d400a  vmovaps [rsp+0xD0], xmm14
00007a40685d4013  vmovaps [rsp+0xE0], xmm15
00007a40685d401c  sub rsp, 0x30
00007a40685d4020  movaps [rsp], xmm8
00007a40685d4025  movaps [rsp+0x10], xmm7
00007a40685d402a  movaps [rsp+0x20], xmm14
00007a40685d4030  lea rdi, [rsp]
00007a40685d4034  mov esi, 0x00
00007a40685d4039  mov rax, 0x56F679577530
00007a40685d4043  call rax
00007a40685d4045  movaps xmm8, [rsp]
00007a40685d404a  add rsp, 0x30
00007a40685d404e  vmovaps xmm0, [rsp]
00007a40685d4053  vmovaps xmm1, [rsp+0x10]
00007a40685d4059  vmovaps xmm2, [rsp+0x20]
00007a40685d405f  vmovaps xmm3, [rsp+0x30]
00007a40685d4065  vmovaps xmm4, [rsp+0x40]
00007a40685d406b  vmovaps xmm5, [rsp+0x50]
00007a40685d4071  vmovaps xmm6, [rsp+0x60]
00007a40685d4077  vmovaps xmm7, [rsp+0x70]
00007a40685d407d  vmovaps xmm9, [rsp+0x80]
00007a40685d4086  vmovaps xmm10, [rsp+0x90]
00007a40685d408f  vmovaps xmm11, [rsp+0xA0]
00007a40685d4098  vmovaps xmm12, [rsp+0xB0]
00007a40685d40a1  vmovaps xmm13, [rsp+0xC0]
00007a40685d40aa  vmovaps xmm14, [rsp+0xD0]
00007a40685d40b3  vmovaps xmm15, [rsp+0xE0]
00007a40685d40bc  add rsp, 0xF0
00007a40685d40c3  pop r11
00007a40685d40c5  pop r10
00007a40685d40c7  pop r9
00007a40685d40c9  pop r8
00007a40685d40cb  pop rsi
00007a40685d40cc  pop rdi
00007a40685d40cd  pop rdx
00007a40685d40ce  pop rcx
00007a40685d40cf  pop rax
00007a40685d40d0  add rsp, 0x08
00007a40685d40d4  jmp 0x00007A40685D0094
00007a40685d40d9  sub rsp, 0x08
00007a40685d40dd  push rax
00007a40685d40de  push rcx
00007a40685d40df  push rdx
00007a40685d40e0  push rdi
00007a40685d40e1  push rsi
00007a40685d40e2  push r8
00007a40685d40e4  push r9
00007a40685d40e6  push r10
00007a40685d40e8  push r11
00007a40685d40ea  sub rsp, 0xF0
00007a40685d40f1  vmovaps [rsp], xmm0
00007a40685d40f6  vmovaps [rsp+0x10], xmm1
00007a40685d40fc  vmovaps [rsp+0x20], xmm2
00007a40685d4102  vmovaps [rsp+0x30], xmm3
00007a40685d4108  vmovaps [rsp+0x40], xmm4
00007a40685d410e  vmovaps [rsp+0x50], xmm5
00007a40685d4114  vmovaps [rsp+0x60], xmm6
00007a40685d411a  vmovaps [rsp+0x70], xmm7
00007a40685d4120  vmovaps [rsp+0x80], xmm8
00007a40685d4129  vmovaps [rsp+0x90], xmm9
00007a40685d4132  vmovaps [rsp+0xA0], xmm10
00007a40685d413b  vmovaps [rsp+0xB0], xmm11
00007a40685d4144  vmovaps [rsp+0xC0], xmm12
00007a40685d414d  vmovaps [rsp+0xD0], xmm13
00007a40685d4156  vmovaps [rsp+0xE0], xmm15
00007a40685d415f  sub rsp, 0x30
00007a40685d4163  movaps [rsp], xmm14
00007a40685d4168  movaps [rsp+0x10], xmm12
00007a40685d416e  movaps [rsp+0x20], xmm9
00007a40685d4174  lea rdi, [rsp]
00007a40685d4178  mov esi, 0x00
00007a40685d417d  mov rax, 0x56F679577530
00007a40685d4187  call rax
00007a40685d4189  movaps xmm14, [rsp]
00007a40685d418e  add rsp, 0x30
00007a40685d4192  vmovaps xmm0, [rsp]
00007a40685d4197  vmovaps xmm1, [rsp+0x10]
00007a40685d419d  vmovaps xmm2, [rsp+0x20]
00007a40685d41a3  vmovaps xmm3, [rsp+0x30]
00007a40685d41a9  vmovaps xmm4, [rsp+0x40]
00007a40685d41af  vmovaps xmm5, [rsp+0x50]
00007a40685d41b5  vmovaps xmm6, [rsp+0x60]
00007a40685d41bb  vmovaps xmm7, [rsp+0x70]
00007a40685d41c1  vmovaps xmm8, [rsp+0x80]
00007a40685d41ca  vmovaps xmm9, [rsp+0x90]
00007a40685d41d3  vmovaps xmm10, [rsp+0xA0]
00007a40685d41dc  vmovaps xmm11, [rsp+0xB0]
00007a40685d41e5  vmovaps xmm12, [rsp+0xC0]
00007a40685d41ee  vmovaps xmm13, [rsp+0xD0]
00007a40685d41f7  vmovaps xmm15, [rsp+0xE0]
00007a40685d4200  add rsp, 0xF0
00007a40685d4207  pop r11
00007a40685d4209  pop r10
00007a40685d420b  pop r9
00007a40685d420d  pop r8
00007a40685d420f  pop rsi
00007a40685d4210  pop rdi
00007a40685d4211  pop rdx
00007a40685d4212  pop rcx
00007a40685d4213  pop rax
00007a40685d4214  add rsp, 0x08
00007a40685d4218  jmp 0x00007A40685D00AE
00007a40685d421d  sub rsp, 0x08
00007a40685d4221  push rax
00007a40685d4222  push rcx
00007a40685d4223  push rdx
00007a40685d4224  push rdi
00007a40685d4225  push rsi
00007a40685d4226  push r8
00007a40685d4228  push r9
00007a40685d422a  push r10
00007a40685d422c  push r11
00007a40685d422e  sub rsp, 0xF0
00007a40685d4235  vmovaps [rsp], xmm0
00007a40685d423a  vmovaps [rsp+0x10], xmm1
00007a40685d4240  vmovaps [rsp+0x20], xmm2
00007a40685d4246  vmovaps [rsp+0x30], xmm3
00007a40685d424c  vmovaps [rsp+0x40], xmm4
00007a40685d4252  vmovaps [rsp+0x50], xmm5
00007a40685d4258  vmovaps [rsp+0x60], xmm6
00007a40685d425e  vmovaps [rsp+0x70], xmm7
00007a40685d4264  vmovaps [rsp+0x80], xmm8
00007a40685d426d  vmovaps [rsp+0x90], xmm10
00007a40685d4276  vmovaps [rsp+0xA0], xmm11
00007a40685d427f  vmovaps [rsp+0xB0], xmm12
00007a40685d4288  vmovaps [rsp+0xC0], xmm13
00007a40685d4291  vmovaps [rsp+0xD0], xmm14
00007a40685d429a  vmovaps [rsp+0xE0], xmm15
00007a40685d42a3  sub rsp, 0x30
00007a40685d42a7  movaps [rsp], xmm9
00007a40685d42ac  movaps [rsp+0x10], xmm7
00007a40685d42b1  movaps [rsp+0x20], xmm12
00007a40685d42b7  lea rdi, [rsp]
00007a40685d42bb  mov esi, 0x00
00007a40685d42c0  mov rax, 0x56F679577530
00007a40685d42ca  call rax
00007a40685d42cc  movaps xmm9, [rsp]
00007a40685d42d1  add rsp, 0x30
00007a40685d42d5  vmovaps xmm0, [rsp]
00007a40685d42da  vmovaps xmm1, [rsp+0x10]
00007a40685d42e0  vmovaps xmm2, [rsp+0x20]
00007a40685d42e6  vmovaps xmm3, [rsp+0x30]
00007a40685d42ec  vmovaps xmm4, [rsp+0x40]
00007a40685d42f2  vmovaps xmm5, [rsp+0x50]
00007a40685d42f8  vmovaps xmm6, [rsp+0x60]
00007a40685d42fe  vmovaps xmm7, [rsp+0x70]
00007a40685d4304  vmovaps xmm8, [rsp+0x80]
00007a40685d430d  vmovaps xmm10, [rsp+0x90]
00007a40685d4316  vmovaps xmm11, [rsp+0xA0]
00007a40685d431f  vmovaps xmm12, [rsp+0xB0]
00007a40685d4328  vmovaps xmm13, [rsp+0xC0]
00007a40685d4331  vmovaps xmm14, [rsp+0xD0]
00007a40685d433a  vmovaps xmm15, [rsp+0xE0]
00007a40685d4343  add rsp, 0xF0
00007a40685d434a  pop r11
00007a40685d434c  pop r10
00007a40685d434e  pop r9
00007a40685d4350  pop r8
00007a40685d4352  pop rsi
00007a40685d4353  pop rdi
00007a40685d4354  pop rdx
00007a40685d4355  pop rcx
00007a40685d4356  pop rax
00007a40685d4357  add rsp, 0x08
00007a40685d435b  jmp 0x00007A40685D00DD
00007a40685d4360  sub rsp, 0x08
00007a40685d4364  push rax
00007a40685d4365  push rcx
00007a40685d4366  push rdx
00007a40685d4367  push rdi
00007a40685d4368  push rsi
00007a40685d4369  push r8
00007a40685d436b  push r9
00007a40685d436d  push r10
00007a40685d436f  push r11
00007a40685d4371  sub rsp, 0xF0
00007a40685d4378  vmovaps [rsp], xmm0
00007a40685d437d  vmovaps [rsp+0x10], xmm1
00007a40685d4383  vmovaps [rsp+0x20], xmm2
00007a40685d4389  vmovaps [rsp+0x30], xmm3
00007a40685d438f  vmovaps [rsp+0x40], xmm4
00007a40685d4395  vmovaps [rsp+0x50], xmm5
00007a40685d439b  vmovaps [rsp+0x60], xmm6
00007a40685d43a1  vmovaps [rsp+0x70], xmm7
00007a40685d43a7  vmovaps [rsp+0x80], xmm8
00007a40685d43b0  vmovaps [rsp+0x90], xmm9
00007a40685d43b9  vmovaps [rsp+0xA0], xmm10
00007a40685d43c2  vmovaps [rsp+0xB0], xmm11
00007a40685d43cb  vmovaps [rsp+0xC0], xmm13
00007a40685d43d4  vmovaps [rsp+0xD0], xmm14
00007a40685d43dd  vmovaps [rsp+0xE0], xmm15
00007a40685d43e6  sub rsp, 0x30
00007a40685d43ea  movaps [rsp], xmm12
00007a40685d43ef  movaps [rsp+0x10], xmm15
00007a40685d43f5  movaps [rsp+0x20], xmm11
00007a40685d43fb  lea rdi, [rsp]
00007a40685d43ff  mov esi, 0x00
00007a40685d4404  mov rax, 0x56F679577530
00007a40685d440e  call rax
00007a40685d4410  movaps xmm12, [rsp]
00007a40685d4415  add rsp, 0x30
00007a40685d4419  vmovaps xmm0, [rsp]
00007a40685d441e  vmovaps xmm1, [rsp+0x10]
00007a40685d4424  vmovaps xmm2, [rsp+0x20]
00007a40685d442a  vmovaps xmm3, [rsp+0x30]
00007a40685d4430  vmovaps xmm4, [rsp+0x40]
00007a40685d4436  vmovaps xmm5, [rsp+0x50]
00007a40685d443c  vmovaps xmm6, [rsp+0x60]
00007a40685d4442  vmovaps xmm7, [rsp+0x70]
00007a40685d4448  vmovaps xmm8, [rsp+0x80]
00007a40685d4451  vmovaps xmm9, [rsp+0x90]
00007a40685d445a  vmovaps xmm10, [rsp+0xA0]
00007a40685d4463  vmovaps xmm11, [rsp+0xB0]
00007a40685d446c  vmovaps xmm13, [rsp+0xC0]
00007a40685d4475  vmovaps xmm14, [rsp+0xD0]
00007a40685d447e  vmovaps xmm15, [rsp+0xE0]
00007a40685d4487  add rsp, 0xF0
00007a40685d448e  pop r11
00007a40685d4490  pop r10
00007a40685d4492  pop r9
00007a40685d4494  pop r8
00007a40685d4496  pop rsi
00007a40685d4497  pop rdi
00007a40685d4498  pop rdx
00007a40685d4499  pop rcx
00007a40685d449a  pop rax
00007a40685d449b  add rsp, 0x08
00007a40685d449f  jmp 0x00007A40685D00F7
00007a40685d44a4  sub rsp, 0x08
00007a40685d44a8  push rax
00007a40685d44a9  push rcx
00007a40685d44aa  push rdx
00007a40685d44ab  push rdi
00007a40685d44ac  push rsi
00007a40685d44ad  push r8
00007a40685d44af  push r9
00007a40685d44b1  push r10
00007a40685d44b3  push r11
00007a40685d44b5  sub rsp, 0xF0
00007a40685d44bc  vmovaps [rsp], xmm0
00007a40685d44c1  vmovaps [rsp+0x10], xmm1
00007a40685d44c7  vmovaps [rsp+0x20], xmm2
00007a40685d44cd  vmovaps [rsp+0x30], xmm3
00007a40685d44d3  vmovaps [rsp+0x40], xmm4
00007a40685d44d9  vmovaps [rsp+0x50], xmm5
00007a40685d44df  vmovaps [rsp+0x60], xmm6
00007a40685d44e5  vmovaps [rsp+0x70], xmm7
00007a40685d44eb  vmovaps [rsp+0x80], xmm8
00007a40685d44f4  vmovaps [rsp+0x90], xmm9
00007a40685d44fd  vmovaps [rsp+0xA0], xmm10
00007a40685d4506  vmovaps [rsp+0xB0], xmm12
00007a40685d450f  vmovaps [rsp+0xC0], xmm13
00007a40685d4518  vmovaps [rsp+0xD0], xmm14
00007a40685d4521  vmovaps [rsp+0xE0], xmm15
00007a40685d452a  sub rsp, 0x30
00007a40685d452e  movaps [rsp], xmm11
00007a40685d4533  movaps [rsp+0x10], xmm7
00007a40685d4538  movaps [rsp+0x20], xmm15
00007a40685d453e  lea rdi, [rsp]
00007a40685d4542  mov esi, 0x00
00007a40685d4547  mov rax, 0x56F679577530
00007a40685d4551  call rax
00007a40685d4553  movaps xmm11, [rsp]
00007a40685d4558  add rsp, 0x30
00007a40685d455c  vmovaps xmm0, [rsp]
00007a40685d4561  vmovaps xmm1, [rsp+0x10]
00007a40685d4567  vmovaps xmm2, [rsp+0x20]
00007a40685d456d  vmovaps xmm3, [rsp+0x30]
00007a40685d4573  vmovaps xmm4, [rsp+0x40]
00007a40685d4579  vmovaps xmm5, [rsp+0x50]
00007a40685d457f  vmovaps xmm6, [rsp+0x60]
00007a40685d4585  vmovaps xmm7, [rsp+0x70]
00007a40685d458b  vmovaps xmm8, [rsp+0x80]
00007a40685d4594  vmovaps xmm9, [rsp+0x90]
00007a40685d459d  vmovaps xmm10, [rsp+0xA0]
00007a40685d45a6  vmovaps xmm12, [rsp+0xB0]
00007a40685d45af  vmovaps xmm13, [rsp+0xC0]
00007a40685d45b8  vmovaps xmm14, [rsp+0xD0]
00007a40685d45c1  vmovaps xmm15, [rsp+0xE0]
00007a40685d45ca  add rsp, 0xF0
00007a40685d45d1  pop r11
00007a40685d45d3  pop r10
00007a40685d45d5  pop r9
00007a40685d45d7  pop r8
00007a40685d45d9  pop rsi
00007a40685d45da  pop rdi
00007a40685d45db  pop rdx
00007a40685d45dc  pop rcx
00007a40685d45dd  pop rax
00007a40685d45de  add rsp, 0x08
00007a40685d45e2  jmp 0x00007A40685D0123
00007a40685d45e7  sub rsp, 0x08
00007a40685d45eb  push rax
00007a40685d45ec  push rcx
00007a40685d45ed  push rdx
00007a40685d45ee  push rdi
00007a40685d45ef  push rsi
00007a40685d45f0  push r8
00007a40685d45f2  push r9
00007a40685d45f4  push r10
00007a40685d45f6  push r11
00007a40685d45f8  sub rsp, 0xF0
00007a40685d45ff  vmovaps [rsp], xmm0
00007a40685d4604  vmovaps [rsp+0x10], xmm1
00007a40685d460a  vmovaps [rsp+0x20], xmm2
00007a40685d4610  vmovaps [rsp+0x30], xmm3
00007a40685d4616  vmovaps [rsp+0x40], xmm4
00007a40685d461c  vmovaps [rsp+0x50], xmm5
00007a40685d4622  vmovaps [rsp+0x60], xmm6
00007a40685d4628  vmovaps [rsp+0x70], xmm7
00007a40685d462e  vmovaps [rsp+0x80], xmm8
00007a40685d4637  vmovaps [rsp+0x90], xmm9
00007a40685d4640  vmovaps [rsp+0xA0], xmm10
00007a40685d4649  vmovaps [rsp+0xB0], xmm11
00007a40685d4652  vmovaps [rsp+0xC0], xmm12
00007a40685d465b  vmovaps [rsp+0xD0], xmm13
00007a40685d4664  vmovaps [rsp+0xE0], xmm14
00007a40685d466d  sub rsp, 0x30
00007a40685d4671  movaps [rsp], xmm15
00007a40685d4676  movaps [rsp+0x10], xmm10
00007a40685d467c  movaps [rsp+0x20], xmm13
00007a40685d4682  lea rdi, [rsp]
00007a40685d4686  mov esi, 0x00
00007a40685d468b  mov rax, 0x56F679577530
00007a40685d4695  call rax
00007a40685d4697  movaps xmm15, [rsp]
00007a40685d469c  add rsp, 0x30
00007a40685d46a0  vmovaps xmm0, [rsp]
00007a40685d46a5  vmovaps xmm1, [rsp+0x10]
00007a40685d46ab  vmovaps xmm2, [rsp+0x20]
00007a40685d46b1  vmovaps xmm3, [rsp+0x30]
00007a40685d46b7  vmovaps xmm4, [rsp+0x40]
00007a40685d46bd  vmovaps xmm5, [rsp+0x50]
00007a40685d46c3  vmovaps xmm6, [rsp+0x60]
00007a40685d46c9  vmovaps xmm7, [rsp+0x70]
00007a40685d46cf  vmovaps xmm8, [rsp+0x80]
00007a40685d46d8  vmovaps xmm9, [rsp+0x90]
00007a40685d46e1  vmovaps xmm10, [rsp+0xA0]
00007a40685d46ea  vmovaps xmm11, [rsp+0xB0]
00007a40685d46f3  vmovaps xmm12, [rsp+0xC0]
00007a40685d46fc  vmovaps xmm13, [rsp+0xD0]
00007a40685d4705  vmovaps xmm14, [rsp+0xE0]
00007a40685d470e  add rsp, 0xF0
00007a40685d4715  pop r11
00007a40685d4717  pop r10
00007a40685d4719  pop r9
00007a40685d471b  pop r8
00007a40685d471d  pop rsi
00007a40685d471e  pop rdi
00007a40685d471f  pop rdx
00007a40685d4720  pop rcx
00007a40685d4721  pop rax
00007a40685d4722  add rsp, 0x08
00007a40685d4726  jmp 0x00007A40685D013D
00007a40685d472b  sub rsp, 0x08
00007a40685d472f  push rax
00007a40685d4730  push rcx
00007a40685d4731  push rdx
00007a40685d4732  push rdi
00007a40685d4733  push rsi
00007a40685d4734  push r8
00007a40685d4736  push r9
00007a40685d4738  push r10
00007a40685d473a  push r11
00007a40685d473c  sub rsp, 0xF0
00007a40685d4743  vmovaps [rsp], xmm0
00007a40685d4748  vmovaps [rsp+0x10], xmm1
00007a40685d474e  vmovaps [rsp+0x20], xmm2
00007a40685d4754  vmovaps [rsp+0x30], xmm3
00007a40685d475a  vmovaps [rsp+0x40], xmm4
00007a40685d4760  vmovaps [rsp+0x50], xmm5
00007a40685d4766  vmovaps [rsp+0x60], xmm6
00007a40685d476c  vmovaps [rsp+0x70], xmm7
00007a40685d4772  vmovaps [rsp+0x80], xmm8
00007a40685d477b  vmovaps [rsp+0x90], xmm9
00007a40685d4784  vmovaps [rsp+0xA0], xmm11
00007a40685d478d  vmovaps [rsp+0xB0], xmm12
00007a40685d4796  vmovaps [rsp+0xC0], xmm13
00007a40685d479f  vmovaps [rsp+0xD0], xmm14
00007a40685d47a8  vmovaps [rsp+0xE0], xmm15
00007a40685d47b1  sub rsp, 0x30
00007a40685d47b5  movaps [rsp], xmm10
00007a40685d47ba  movaps [rsp+0x10], xmm7
00007a40685d47bf  movaps [rsp+0x20], xmm13
00007a40685d47c5  lea rdi, [rsp]
00007a40685d47c9  mov esi, 0x00
00007a40685d47ce  mov rax, 0x56F679577530
00007a40685d47d8  call rax
00007a40685d47da  movaps xmm10, [rsp]
00007a40685d47df  add rsp, 0x30
00007a40685d47e3  vmovaps xmm0, [rsp]
00007a40685d47e8  vmovaps xmm1, [rsp+0x10]
00007a40685d47ee  vmovaps xmm2, [rsp+0x20]
00007a40685d47f4  vmovaps xmm3, [rsp+0x30]
00007a40685d47fa  vmovaps xmm4, [rsp+0x40]
00007a40685d4800  vmovaps xmm5, [rsp+0x50]
00007a40685d4806  vmovaps xmm6, [rsp+0x60]
00007a40685d480c  vmovaps xmm7, [rsp+0x70]
00007a40685d4812  vmovaps xmm8, [rsp+0x80]
00007a40685d481b  vmovaps xmm9, [rsp+0x90]
00007a40685d4824  vmovaps xmm11, [rsp+0xA0]
00007a40685d482d  vmovaps xmm12, [rsp+0xB0]
00007a40685d4836  vmovaps xmm13, [rsp+0xC0]
00007a40685d483f  vmovaps xmm14, [rsp+0xD0]
00007a40685d4848  vmovaps xmm15, [rsp+0xE0]
00007a40685d4851  add rsp, 0xF0
00007a40685d4858  pop r11
00007a40685d485a  pop r10
00007a40685d485c  pop r9
00007a40685d485e  pop r8
00007a40685d4860  pop rsi
00007a40685d4861  pop rdi
00007a40685d4862  pop rdx
00007a40685d4863  pop rcx
00007a40685d4864  pop rax
00007a40685d4865  add rsp, 0x08
00007a40685d4869  jmp 0x00007A40685D0169
00007a40685d486e  sub rsp, 0x08
00007a40685d4872  push rax
00007a40685d4873  push rcx
00007a40685d4874  push rdx
00007a40685d4875  push rdi
00007a40685d4876  push rsi
00007a40685d4877  push r8
00007a40685d4879  push r9
00007a40685d487b  push r10
00007a40685d487d  push r11
00007a40685d487f  sub rsp, 0xF0
00007a40685d4886  vmovaps [rsp], xmm0
00007a40685d488b  vmovaps [rsp+0x10], xmm1
00007a40685d4891  vmovaps [rsp+0x20], xmm2
00007a40685d4897  vmovaps [rsp+0x30], xmm3
00007a40685d489d  vmovaps [rsp+0x40], xmm4
00007a40685d48a3  vmovaps [rsp+0x50], xmm5
00007a40685d48a9  vmovaps [rsp+0x60], xmm6
00007a40685d48af  vmovaps [rsp+0x70], xmm7
00007a40685d48b5  vmovaps [rsp+0x80], xmm8
00007a40685d48be  vmovaps [rsp+0x90], xmm9
00007a40685d48c7  vmovaps [rsp+0xA0], xmm10
00007a40685d48d0  vmovaps [rsp+0xB0], xmm11
00007a40685d48d9  vmovaps [rsp+0xC0], xmm12
00007a40685d48e2  vmovaps [rsp+0xD0], xmm14
00007a40685d48eb  vmovaps [rsp+0xE0], xmm15
00007a40685d48f4  sub rsp, 0x30
00007a40685d48f8  movaps [rsp], xmm13
00007a40685d48fd  movaps [rsp+0x10], xmm1
00007a40685d4902  movaps [rsp+0x20], xmm8
00007a40685d4908  lea rdi, [rsp]
00007a40685d490c  mov esi, 0x00
00007a40685d4911  mov rax, 0x56F679577530
00007a40685d491b  call rax
00007a40685d491d  movaps xmm13, [rsp]
00007a40685d4922  add rsp, 0x30
00007a40685d4926  vmovaps xmm0, [rsp]
00007a40685d492b  vmovaps xmm1, [rsp+0x10]
00007a40685d4931  vmovaps xmm2, [rsp+0x20]
00007a40685d4937  vmovaps xmm3, [rsp+0x30]
00007a40685d493d  vmovaps xmm4, [rsp+0x40]
00007a40685d4943  vmovaps xmm5, [rsp+0x50]
00007a40685d4949  vmovaps xmm6, [rsp+0x60]
00007a40685d494f  vmovaps xmm7, [rsp+0x70]
00007a40685d4955  vmovaps xmm8, [rsp+0x80]
00007a40685d495e  vmovaps xmm9, [rsp+0x90]
00007a40685d4967  vmovaps xmm10, [rsp+0xA0]
00007a40685d4970  vmovaps xmm11, [rsp+0xB0]
00007a40685d4979  vmovaps xmm12, [rsp+0xC0]
00007a40685d4982  vmovaps xmm14, [rsp+0xD0]
00007a40685d498b  vmovaps xmm15, [rsp+0xE0]
00007a40685d4994  add rsp, 0xF0
00007a40685d499b  pop r11
00007a40685d499d  pop r10
00007a40685d499f  pop r9
00007a40685d49a1  pop r8
00007a40685d49a3  pop rsi
00007a40685d49a4  pop rdi
00007a40685d49a5  pop rdx
00007a40685d49a6  pop rcx
00007a40685d49a7  pop rax
00007a40685d49a8  add rsp, 0x08
00007a40685d49ac  jmp 0x00007A40685D0183
00007a40685d49b1  call 0x00007A40683FF430
00007a40685d49b6  jmp 0x00007A40685D018D
00007a40685d49bb  sub rsp, 0x08
00007a40685d49bf  push rax
00007a40685d49c0  push rcx
00007a40685d49c1  push rdx
00007a40685d49c2  push rdi
00007a40685d49c3  push rsi
00007a40685d49c4  push r8
00007a40685d49c6  push r9
00007a40685d49c8  push r10
00007a40685d49ca  push r11
00007a40685d49cc  sub rsp, 0xF0
00007a40685d49d3  vmovaps [rsp], xmm0
00007a40685d49d8  vmovaps [rsp+0x10], xmm1
00007a40685d49de  vmovaps [rsp+0x20], xmm2
00007a40685d49e4  vmovaps [rsp+0x30], xmm3
00007a40685d49ea  vmovaps [rsp+0x40], xmm4
00007a40685d49f0  vmovaps [rsp+0x50], xmm5
00007a40685d49f6  vmovaps [rsp+0x60], xmm6
00007a40685d49fc  vmovaps [rsp+0x70], xmm7
00007a40685d4a02  vmovaps [rsp+0x80], xmm9
00007a40685d4a0b  vmovaps [rsp+0x90], xmm10
00007a40685d4a14  vmovaps [rsp+0xA0], xmm11
00007a40685d4a1d  vmovaps [rsp+0xB0], xmm12
00007a40685d4a26  vmovaps [rsp+0xC0], xmm13
00007a40685d4a2f  vmovaps [rsp+0xD0], xmm14
00007a40685d4a38  vmovaps [rsp+0xE0], xmm15
00007a40685d4a41  sub rsp, 0x30
00007a40685d4a45  movaps [rsp], xmm8
00007a40685d4a4a  movaps [rsp+0x10], xmm14
00007a40685d4a50  movaps [rsp+0x20], xmm9
00007a40685d4a56  lea rdi, [rsp]
00007a40685d4a5a  mov esi, 0x00
00007a40685d4a5f  mov rax, 0x56F679577530
00007a40685d4a69  call rax
00007a40685d4a6b  movaps xmm8, [rsp]
00007a40685d4a70  add rsp, 0x30
00007a40685d4a74  vmovaps xmm0, [rsp]
00007a40685d4a79  vmovaps xmm1, [rsp+0x10]
00007a40685d4a7f  vmovaps xmm2, [rsp+0x20]
00007a40685d4a85  vmovaps xmm3, [rsp+0x30]
00007a40685d4a8b  vmovaps xmm4, [rsp+0x40]
00007a40685d4a91  vmovaps xmm5, [rsp+0x50]
00007a40685d4a97  vmovaps xmm6, [rsp+0x60]
00007a40685d4a9d  vmovaps xmm7, [rsp+0x70]
00007a40685d4aa3  vmovaps xmm9, [rsp+0x80]
00007a40685d4aac  vmovaps xmm10, [rsp+0x90]
00007a40685d4ab5  vmovaps xmm11, [rsp+0xA0]
00007a40685d4abe  vmovaps xmm12, [rsp+0xB0]
00007a40685d4ac7  vmovaps xmm13, [rsp+0xC0]
00007a40685d4ad0  vmovaps xmm14, [rsp+0xD0]
00007a40685d4ad9  vmovaps xmm15, [rsp+0xE0]
00007a40685d4ae2  add rsp, 0xF0
00007a40685d4ae9  pop r11
00007a40685d4aeb  pop r10
00007a40685d4aed  pop r9
00007a40685d4aef  pop r8
00007a40685d4af1  pop rsi
00007a40685d4af2  pop rdi
00007a40685d4af3  pop rdx
00007a40685d4af4  pop rcx
00007a40685d4af5  pop rax
00007a40685d4af6  add rsp, 0x08
00007a40685d4afa  jmp 0x00007A40685D01AF
00007a40685d4aff  sub rsp, 0x08
00007a40685d4b03  push rax
00007a40685d4b04  push rcx
00007a40685d4b05  push rdx
00007a40685d4b06  push rdi
00007a40685d4b07  push rsi
00007a40685d4b08  push r8
00007a40685d4b0a  push r9
00007a40685d4b0c  push r10
00007a40685d4b0e  push r11
00007a40685d4b10  sub rsp, 0xF0
00007a40685d4b17  vmovaps [rsp], xmm0
00007a40685d4b1c  vmovaps [rsp+0x10], xmm1
00007a40685d4b22  vmovaps [rsp+0x20], xmm2
00007a40685d4b28  vmovaps [rsp+0x30], xmm3
00007a40685d4b2e  vmovaps [rsp+0x40], xmm4
00007a40685d4b34  vmovaps [rsp+0x50], xmm5
00007a40685d4b3a  vmovaps [rsp+0x60], xmm6
00007a40685d4b40  vmovaps [rsp+0x70], xmm7
00007a40685d4b46  vmovaps [rsp+0x80], xmm8
00007a40685d4b4f  vmovaps [rsp+0x90], xmm10
00007a40685d4b58  vmovaps [rsp+0xA0], xmm11
00007a40685d4b61  vmovaps [rsp+0xB0], xmm12
00007a40685d4b6a  vmovaps [rsp+0xC0], xmm13
00007a40685d4b73  vmovaps [rsp+0xD0], xmm14
00007a40685d4b7c  vmovaps [rsp+0xE0], xmm15
00007a40685d4b85  sub rsp, 0x30
00007a40685d4b89  movaps [rsp], xmm9
00007a40685d4b8e  movaps [rsp+0x10], xmm1
00007a40685d4b93  movaps [rsp+0x20], xmm14
00007a40685d4b99  lea rdi, [rsp]
00007a40685d4b9d  mov esi, 0x00
00007a40685d4ba2  mov rax, 0x56F679577530
00007a40685d4bac  call rax
00007a40685d4bae  movaps xmm9, [rsp]
00007a40685d4bb3  add rsp, 0x30
00007a40685d4bb7  vmovaps xmm0, [rsp]
00007a40685d4bbc  vmovaps xmm1, [rsp+0x10]
00007a40685d4bc2  vmovaps xmm2, [rsp+0x20]
00007a40685d4bc8  vmovaps xmm3, [rsp+0x30]
00007a40685d4bce  vmovaps xmm4, [rsp+0x40]
00007a40685d4bd4  vmovaps xmm5, [rsp+0x50]
00007a40685d4bda  vmovaps xmm6, [rsp+0x60]
00007a40685d4be0  vmovaps xmm7, [rsp+0x70]
00007a40685d4be6  vmovaps xmm8, [rsp+0x80]
00007a40685d4bef  vmovaps xmm10, [rsp+0x90]
00007a40685d4bf8  vmovaps xmm11, [rsp+0xA0]
00007a40685d4c01  vmovaps xmm12, [rsp+0xB0]
00007a40685d4c0a  vmovaps xmm13, [rsp+0xC0]
00007a40685d4c13  vmovaps xmm14, [rsp+0xD0]
00007a40685d4c1c  vmovaps xmm15, [rsp+0xE0]
00007a40685d4c25  add rsp, 0xF0
00007a40685d4c2c  pop r11
00007a40685d4c2e  pop r10
00007a40685d4c30  pop r9
00007a40685d4c32  pop r8
00007a40685d4c34  pop rsi
00007a40685d4c35  pop rdi
00007a40685d4c36  pop rdx
00007a40685d4c37  pop rcx
00007a40685d4c38  pop rax
00007a40685d4c39  add rsp, 0x08
00007a40685d4c3d  jmp 0x00007A40685D01DD
00007a40685d4c42  sub rsp, 0x08
00007a40685d4c46  push rax
00007a40685d4c47  push rcx
00007a40685d4c48  push rdx
00007a40685d4c49  push rdi
00007a40685d4c4a  push rsi
00007a40685d4c4b  push r8
00007a40685d4c4d  push r9
00007a40685d4c4f  push r10
00007a40685d4c51  push r11
00007a40685d4c53  sub rsp, 0xF0
00007a40685d4c5a  vmovaps [rsp], xmm0
00007a40685d4c5f  vmovaps [rsp+0x10], xmm1
00007a40685d4c65  vmovaps [rsp+0x20], xmm2
00007a40685d4c6b  vmovaps [rsp+0x30], xmm3
00007a40685d4c71  vmovaps [rsp+0x40], xmm4
00007a40685d4c77  vmovaps [rsp+0x50], xmm5
00007a40685d4c7d  vmovaps [rsp+0x60], xmm6
00007a40685d4c83  vmovaps [rsp+0x70], xmm7
00007a40685d4c89  vmovaps [rsp+0x80], xmm8
00007a40685d4c92  vmovaps [rsp+0x90], xmm9
00007a40685d4c9b  vmovaps [rsp+0xA0], xmm10
00007a40685d4ca4  vmovaps [rsp+0xB0], xmm11
00007a40685d4cad  vmovaps [rsp+0xC0], xmm12
00007a40685d4cb6  vmovaps [rsp+0xD0], xmm13
00007a40685d4cbf  vmovaps [rsp+0xE0], xmm15
00007a40685d4cc8  sub rsp, 0x30
00007a40685d4ccc  movaps [rsp], xmm14
00007a40685d4cd1  movaps [rsp+0x10], xmm4
00007a40685d4cd6  movaps [rsp+0x20], xmm1
00007a40685d4cdb  lea rdi, [rsp]
00007a40685d4cdf  mov esi, 0x00
00007a40685d4ce4  mov rax, 0x56F679577530
00007a40685d4cee  call rax
00007a40685d4cf0  movaps xmm14, [rsp]
00007a40685d4cf5  add rsp, 0x30
00007a40685d4cf9  vmovaps xmm0, [rsp]
00007a40685d4cfe  vmovaps xmm1, [rsp+0x10]
00007a40685d4d04  vmovaps xmm2, [rsp+0x20]
00007a40685d4d0a  vmovaps xmm3, [rsp+0x30]
00007a40685d4d10  vmovaps xmm4, [rsp+0x40]
00007a40685d4d16  vmovaps xmm5, [rsp+0x50]
00007a40685d4d1c  vmovaps xmm6, [rsp+0x60]
00007a40685d4d22  vmovaps xmm7, [rsp+0x70]
00007a40685d4d28  vmovaps xmm8, [rsp+0x80]
00007a40685d4d31  vmovaps xmm9, [rsp+0x90]
00007a40685d4d3a  vmovaps xmm10, [rsp+0xA0]
00007a40685d4d43  vmovaps xmm11, [rsp+0xB0]
00007a40685d4d4c  vmovaps xmm12, [rsp+0xC0]
00007a40685d4d55  vmovaps xmm13, [rsp+0xD0]
00007a40685d4d5e  vmovaps xmm15, [rsp+0xE0]
00007a40685d4d67  add rsp, 0xF0
00007a40685d4d6e  pop r11
00007a40685d4d70  pop r10
00007a40685d4d72  pop r9
00007a40685d4d74  pop r8
00007a40685d4d76  pop rsi
00007a40685d4d77  pop rdi
00007a40685d4d78  pop rdx
00007a40685d4d79  pop rcx
00007a40685d4d7a  pop rax
00007a40685d4d7b  add rsp, 0x08
00007a40685d4d7f  jmp 0x00007A40685D0203
00007a40685d4d84  sub rsp, 0x08
00007a40685d4d88  push rax
00007a40685d4d89  push rcx
00007a40685d4d8a  push rdx
00007a40685d4d8b  push rdi
00007a40685d4d8c  push rsi
00007a40685d4d8d  push r8
00007a40685d4d8f  push r9
00007a40685d4d91  push r10
00007a40685d4d93  push r11
00007a40685d4d95  sub rsp, 0xF0
00007a40685d4d9c  vmovaps [rsp], xmm0
00007a40685d4da1  vmovaps [rsp+0x10], xmm2
00007a40685d4da7  vmovaps [rsp+0x20], xmm3
00007a40685d4dad  vmovaps [rsp+0x30], xmm4
00007a40685d4db3  vmovaps [rsp+0x40], xmm5
00007a40685d4db9  vmovaps [rsp+0x50], xmm6
00007a40685d4dbf  vmovaps [rsp+0x60], xmm7
00007a40685d4dc5  vmovaps [rsp+0x70], xmm8
00007a40685d4dcb  vmovaps [rsp+0x80], xmm9
00007a40685d4dd4  vmovaps [rsp+0x90], xmm10
00007a40685d4ddd  vmovaps [rsp+0xA0], xmm11
00007a40685d4de6  vmovaps [rsp+0xB0], xmm12
00007a40685d4def  vmovaps [rsp+0xC0], xmm13
00007a40685d4df8  vmovaps [rsp+0xD0], xmm14
00007a40685d4e01  vmovaps [rsp+0xE0], xmm15
00007a40685d4e0a  sub rsp, 0x30
00007a40685d4e0e  movaps [rsp], xmm1
00007a40685d4e12  movaps [rsp+0x10], xmm12
00007a40685d4e18  movaps [rsp+0x20], xmm11
00007a40685d4e1e  lea rdi, [rsp]
00007a40685d4e22  mov esi, 0x00
00007a40685d4e27  mov rax, 0x56F679577530
00007a40685d4e31  call rax
00007a40685d4e33  movaps xmm1, [rsp]
00007a40685d4e37  add rsp, 0x30
00007a40685d4e3b  vmovaps xmm0, [rsp]
00007a40685d4e40  vmovaps xmm2, [rsp+0x10]
00007a40685d4e46  vmovaps xmm3, [rsp+0x20]
00007a40685d4e4c  vmovaps xmm4, [rsp+0x30]
00007a40685d4e52  vmovaps xmm5, [rsp+0x40]
00007a40685d4e58  vmovaps xmm6, [rsp+0x50]
00007a40685d4e5e  vmovaps xmm7, [rsp+0x60]
00007a40685d4e64  vmovaps xmm8, [rsp+0x70]
00007a40685d4e6a  vmovaps xmm9, [rsp+0x80]
00007a40685d4e73  vmovaps xmm10, [rsp+0x90]
00007a40685d4e7c  vmovaps xmm11, [rsp+0xA0]
00007a40685d4e85  vmovaps xmm12, [rsp+0xB0]
00007a40685d4e8e  vmovaps xmm13, [rsp+0xC0]
00007a40685d4e97  vmovaps xmm14, [rsp+0xD0]
00007a40685d4ea0  vmovaps xmm15, [rsp+0xE0]
00007a40685d4ea9  add rsp, 0xF0
00007a40685d4eb0  pop r11
00007a40685d4eb2  pop r10
00007a40685d4eb4  pop r9
00007a40685d4eb6  pop r8
00007a40685d4eb8  pop rsi
00007a40685d4eb9  pop rdi
00007a40685d4eba  pop rdx
00007a40685d4ebb  pop rcx
00007a40685d4ebc  pop rax
00007a40685d4ebd  add rsp, 0x08
00007a40685d4ec1  jmp 0x00007A40685D0224
00007a40685d4ec6  call 0x00007A40684E20A0
00007a40685d4ecb  jmp 0x00007A40685D0232
00007a40685d4ed0  call 0x00007A4068409D70
00007a40685d4ed5  jmp 0x00007A40685D023C
00007a40685d4eda  sub rsp, 0x08
00007a40685d4ede  push rax
00007a40685d4edf  push rcx
00007a40685d4ee0  push rdx
00007a40685d4ee1  push rdi
00007a40685d4ee2  push rsi
00007a40685d4ee3  push r8
00007a40685d4ee5  push r9
00007a40685d4ee7  push r10
00007a40685d4ee9  push r11
00007a40685d4eeb  sub rsp, 0xF0
00007a40685d4ef2  vmovaps [rsp], xmm0
00007a40685d4ef7  vmovaps [rsp+0x10], xmm1
00007a40685d4efd  vmovaps [rsp+0x20], xmm2
00007a40685d4f03  vmovaps [rsp+0x30], xmm3
00007a40685d4f09  vmovaps [rsp+0x40], xmm4
00007a40685d4f0f  vmovaps [rsp+0x50], xmm5
00007a40685d4f15  vmovaps [rsp+0x60], xmm6
00007a40685d4f1b  vmovaps [rsp+0x70], xmm8
00007a40685d4f21  vmovaps [rsp+0x80], xmm9
00007a40685d4f2a  vmovaps [rsp+0x90], xmm10
00007a40685d4f33  vmovaps [rsp+0xA0], xmm11
00007a40685d4f3c  vmovaps [rsp+0xB0], xmm12
00007a40685d4f45  vmovaps [rsp+0xC0], xmm13
00007a40685d4f4e  vmovaps [rsp+0xD0], xmm14
00007a40685d4f57  vmovaps [rsp+0xE0], xmm15
00007a40685d4f60  sub rsp, 0x30
00007a40685d4f64  movaps [rsp], xmm7
00007a40685d4f68  movaps [rsp+0x10], xmm15
00007a40685d4f6e  movaps [rsp+0x20], xmm10
00007a40685d4f74  lea rdi, [rsp]
00007a40685d4f78  mov esi, 0x00
00007a40685d4f7d  mov rax, 0x56F679577530
00007a40685d4f87  call rax
00007a40685d4f89  movaps xmm7, [rsp]
00007a40685d4f8d  add rsp, 0x30
00007a40685d4f91  vmovaps xmm0, [rsp]
00007a40685d4f96  vmovaps xmm1, [rsp+0x10]
00007a40685d4f9c  vmovaps xmm2, [rsp+0x20]
00007a40685d4fa2  vmovaps xmm3, [rsp+0x30]
00007a40685d4fa8  vmovaps xmm4, [rsp+0x40]
00007a40685d4fae  vmovaps xmm5, [rsp+0x50]
00007a40685d4fb4  vmovaps xmm6, [rsp+0x60]
00007a40685d4fba  vmovaps xmm8, [rsp+0x70]
00007a40685d4fc0  vmovaps xmm9, [rsp+0x80]
00007a40685d4fc9  vmovaps xmm10, [rsp+0x90]
00007a40685d4fd2  vmovaps xmm11, [rsp+0xA0]
00007a40685d4fdb  vmovaps xmm12, [rsp+0xB0]
00007a40685d4fe4  vmovaps xmm13, [rsp+0xC0]
00007a40685d4fed  vmovaps xmm14, [rsp+0xD0]
00007a40685d4ff6  vmovaps xmm15, [rsp+0xE0]
00007a40685d4fff  add rsp, 0xF0
00007a40685d5006  pop r11
00007a40685d5008  pop r10
00007a40685d500a  pop r9
00007a40685d500c  pop r8
00007a40685d500e  pop rsi
00007a40685d500f  pop rdi
00007a40685d5010  pop rdx
00007a40685d5011  pop rcx
00007a40685d5012  pop rax
00007a40685d5013  add rsp, 0x08
00007a40685d5017  jmp 0x00007A40685D025D
00007a40685d501c  sub rsp, 0x08
00007a40685d5020  push rax
00007a40685d5021  push rcx
00007a40685d5022  push rdx
00007a40685d5023  push rdi
00007a40685d5024  push rsi
00007a40685d5025  push r8
00007a40685d5027  push r9
00007a40685d5029  push r10
00007a40685d502b  push r11
00007a40685d502d  sub rsp, 0xF0
00007a40685d5034  vmovaps [rsp], xmm0
00007a40685d5039  vmovaps [rsp+0x10], xmm1
00007a40685d503f  vmovaps [rsp+0x20], xmm2
00007a40685d5045  vmovaps [rsp+0x30], xmm3
00007a40685d504b  vmovaps [rsp+0x40], xmm4
00007a40685d5051  vmovaps [rsp+0x50], xmm5
00007a40685d5057  vmovaps [rsp+0x60], xmm6
00007a40685d505d  vmovaps [rsp+0x70], xmm7
00007a40685d5063  vmovaps [rsp+0x80], xmm8
00007a40685d506c  vmovaps [rsp+0x90], xmm9
00007a40685d5075  vmovaps [rsp+0xA0], xmm11
00007a40685d507e  vmovaps [rsp+0xB0], xmm12
00007a40685d5087  vmovaps [rsp+0xC0], xmm13
00007a40685d5090  vmovaps [rsp+0xD0], xmm14
00007a40685d5099  vmovaps [rsp+0xE0], xmm15
00007a40685d50a2  sub rsp, 0x30
00007a40685d50a6  movaps [rsp], xmm10
00007a40685d50ab  movaps [rsp+0x10], xmm11
00007a40685d50b1  movaps [rsp+0x20], xmm15
00007a40685d50b7  lea rdi, [rsp]
00007a40685d50bb  mov esi, 0x00
00007a40685d50c0  mov rax, 0x56F679577530
00007a40685d50ca  call rax
00007a40685d50cc  movaps xmm10, [rsp]
00007a40685d50d1  add rsp, 0x30
00007a40685d50d5  vmovaps xmm0, [rsp]
00007a40685d50da  vmovaps xmm1, [rsp+0x10]
00007a40685d50e0  vmovaps xmm2, [rsp+0x20]
00007a40685d50e6  vmovaps xmm3, [rsp+0x30]
00007a40685d50ec  vmovaps xmm4, [rsp+0x40]
00007a40685d50f2  vmovaps xmm5, [rsp+0x50]
00007a40685d50f8  vmovaps xmm6, [rsp+0x60]
00007a40685d50fe  vmovaps xmm7, [rsp+0x70]
00007a40685d5104  vmovaps xmm8, [rsp+0x80]
00007a40685d510d  vmovaps xmm9, [rsp+0x90]
00007a40685d5116  vmovaps xmm11, [rsp+0xA0]
00007a40685d511f  vmovaps xmm12, [rsp+0xB0]
00007a40685d5128  vmovaps xmm13, [rsp+0xC0]
00007a40685d5131  vmovaps xmm14, [rsp+0xD0]
00007a40685d513a  vmovaps xmm15, [rsp+0xE0]
00007a40685d5143  add rsp, 0xF0
00007a40685d514a  pop r11
00007a40685d514c  pop r10
00007a40685d514e  pop r9
00007a40685d5150  pop r8
00007a40685d5152  pop rsi
00007a40685d5153  pop rdi
00007a40685d5154  pop rdx
00007a40685d5155  pop rcx
00007a40685d5156  pop rax
00007a40685d5157  add rsp, 0x08
00007a40685d515b  jmp 0x00007A40685D028B
00007a40685d5160  sub rsp, 0x08
00007a40685d5164  push rax
00007a40685d5165  push rcx
00007a40685d5166  push rdx
00007a40685d5167  push rdi
00007a40685d5168  push rsi
00007a40685d5169  push r8
00007a40685d516b  push r9
00007a40685d516d  push r10
00007a40685d516f  push r11
00007a40685d5171  sub rsp, 0xF0
00007a40685d5178  vmovaps [rsp], xmm0
00007a40685d517d  vmovaps [rsp+0x10], xmm1
00007a40685d5183  vmovaps [rsp+0x20], xmm2
00007a40685d5189  vmovaps [rsp+0x30], xmm3
00007a40685d518f  vmovaps [rsp+0x40], xmm4
00007a40685d5195  vmovaps [rsp+0x50], xmm5
00007a40685d519b  vmovaps [rsp+0x60], xmm6
00007a40685d51a1  vmovaps [rsp+0x70], xmm7
00007a40685d51a7  vmovaps [rsp+0x80], xmm8
00007a40685d51b0  vmovaps [rsp+0x90], xmm9
00007a40685d51b9  vmovaps [rsp+0xA0], xmm10
00007a40685d51c2  vmovaps [rsp+0xB0], xmm12
00007a40685d51cb  vmovaps [rsp+0xC0], xmm13
00007a40685d51d4  vmovaps [rsp+0xD0], xmm14
00007a40685d51dd  vmovaps [rsp+0xE0], xmm15
00007a40685d51e6  sub rsp, 0x30
00007a40685d51ea  movaps [rsp], xmm11
00007a40685d51ef  movaps [rsp+0x10], xmm12
00007a40685d51f5  movaps [rsp+0x20], xmm15
00007a40685d51fb  lea rdi, [rsp]
00007a40685d51ff  mov esi, 0x00
00007a40685d5204  mov rax, 0x56F679577530
00007a40685d520e  call rax
00007a40685d5210  movaps xmm11, [rsp]
00007a40685d5215  add rsp, 0x30
00007a40685d5219  vmovaps xmm0, [rsp]
00007a40685d521e  vmovaps xmm1, [rsp+0x10]
00007a40685d5224  vmovaps xmm2, [rsp+0x20]
00007a40685d522a  vmovaps xmm3, [rsp+0x30]
00007a40685d5230  vmovaps xmm4, [rsp+0x40]
00007a40685d5236  vmovaps xmm5, [rsp+0x50]
00007a40685d523c  vmovaps xmm6, [rsp+0x60]
00007a40685d5242  vmovaps xmm7, [rsp+0x70]
00007a40685d5248  vmovaps xmm8, [rsp+0x80]
00007a40685d5251  vmovaps xmm9, [rsp+0x90]
00007a40685d525a  vmovaps xmm10, [rsp+0xA0]
00007a40685d5263  vmovaps xmm12, [rsp+0xB0]
00007a40685d526c  vmovaps xmm13, [rsp+0xC0]
00007a40685d5275  vmovaps xmm14, [rsp+0xD0]
00007a40685d527e  vmovaps xmm15, [rsp+0xE0]
00007a40685d5287  add rsp, 0xF0
00007a40685d528e  pop r11
00007a40685d5290  pop r10
00007a40685d5292  pop r9
00007a40685d5294  pop r8
00007a40685d5296  pop rsi
00007a40685d5297  pop rdi
00007a40685d5298  pop rdx
00007a40685d5299  pop rcx
00007a40685d529a  pop rax
00007a40685d529b  add rsp, 0x08
00007a40685d529f  jmp 0x00007A40685D02B9
00007a40685d52a4  sub rsp, 0x08
00007a40685d52a8  push rax
00007a40685d52a9  push rcx
00007a40685d52aa  push rdx
00007a40685d52ab  push rdi
00007a40685d52ac  push rsi
00007a40685d52ad  push r8
00007a40685d52af  push r9
00007a40685d52b1  push r10
00007a40685d52b3  push r11
00007a40685d52b5  sub rsp, 0xF0
00007a40685d52bc  vmovaps [rsp], xmm0
00007a40685d52c1  vmovaps [rsp+0x10], xmm1
00007a40685d52c7  vmovaps [rsp+0x20], xmm2
00007a40685d52cd  vmovaps [rsp+0x30], xmm3
00007a40685d52d3  vmovaps [rsp+0x40], xmm4
00007a40685d52d9  vmovaps [rsp+0x50], xmm5
00007a40685d52df  vmovaps [rsp+0x60], xmm6
00007a40685d52e5  vmovaps [rsp+0x70], xmm7
00007a40685d52eb  vmovaps [rsp+0x80], xmm8
00007a40685d52f4  vmovaps [rsp+0x90], xmm9
00007a40685d52fd  vmovaps [rsp+0xA0], xmm10
00007a40685d5306  vmovaps [rsp+0xB0], xmm11
00007a40685d530f  vmovaps [rsp+0xC0], xmm12
00007a40685d5318  vmovaps [rsp+0xD0], xmm13
00007a40685d5321  vmovaps [rsp+0xE0], xmm14
00007a40685d532a  sub rsp, 0x30
00007a40685d532e  movaps [rsp], xmm15
00007a40685d5333  movaps [rsp+0x10], xmm13
00007a40685d5339  movaps [rsp+0x20], xmm9
00007a40685d533f  lea rdi, [rsp]
00007a40685d5343  mov esi, 0x00
00007a40685d5348  mov rax, 0x56F679577530
00007a40685d5352  call rax
00007a40685d5354  movaps xmm15, [rsp]
00007a40685d5359  add rsp, 0x30
00007a40685d535d  vmovaps xmm0, [rsp]
00007a40685d5362  vmovaps xmm1, [rsp+0x10]
00007a40685d5368  vmovaps xmm2, [rsp+0x20]
00007a40685d536e  vmovaps xmm3, [rsp+0x30]
00007a40685d5374  vmovaps xmm4, [rsp+0x40]
00007a40685d537a  vmovaps xmm5, [rsp+0x50]
00007a40685d5380  vmovaps xmm6, [rsp+0x60]
00007a40685d5386  vmovaps xmm7, [rsp+0x70]
00007a40685d538c  vmovaps xmm8, [rsp+0x80]
00007a40685d5395  vmovaps xmm9, [rsp+0x90]
00007a40685d539e  vmovaps xmm10, [rsp+0xA0]
00007a40685d53a7  vmovaps xmm11, [rsp+0xB0]
00007a40685d53b0  vmovaps xmm12, [rsp+0xC0]
00007a40685d53b9  vmovaps xmm13, [rsp+0xD0]
00007a40685d53c2  vmovaps xmm14, [rsp+0xE0]
00007a40685d53cb  add rsp, 0xF0
00007a40685d53d2  pop r11
00007a40685d53d4  pop r10
00007a40685d53d6  pop r9
00007a40685d53d8  pop r8
00007a40685d53da  pop rsi
00007a40685d53db  pop rdi
00007a40685d53dc  pop rdx
00007a40685d53dd  pop rcx
00007a40685d53de  pop rax
00007a40685d53df  add rsp, 0x08
00007a40685d53e3  jmp 0x00007A40685D02D4
00007a40685d53e8  sub rsp, 0x08
00007a40685d53ec  push rax
00007a40685d53ed  push rcx
00007a40685d53ee  push rdx
00007a40685d53ef  push rdi
00007a40685d53f0  push rsi
00007a40685d53f1  push r8
00007a40685d53f3  push r9
00007a40685d53f5  push r10
00007a40685d53f7  push r11
00007a40685d53f9  sub rsp, 0xF0
00007a40685d5400  vmovaps [rsp], xmm0
00007a40685d5405  vmovaps [rsp+0x10], xmm1
00007a40685d540b  vmovaps [rsp+0x20], xmm2
00007a40685d5411  vmovaps [rsp+0x30], xmm3
00007a40685d5417  vmovaps [rsp+0x40], xmm4
00007a40685d541d  vmovaps [rsp+0x50], xmm5
00007a40685d5423  vmovaps [rsp+0x60], xmm6
00007a40685d5429  vmovaps [rsp+0x70], xmm7
00007a40685d542f  vmovaps [rsp+0x80], xmm8
00007a40685d5438  vmovaps [rsp+0x90], xmm9
00007a40685d5441  vmovaps [rsp+0xA0], xmm10
00007a40685d544a  vmovaps [rsp+0xB0], xmm11
00007a40685d5453  vmovaps [rsp+0xC0], xmm12
00007a40685d545c  vmovaps [rsp+0xD0], xmm14
00007a40685d5465  vmovaps [rsp+0xE0], xmm15
00007a40685d546e  sub rsp, 0x30
00007a40685d5472  movaps [rsp], xmm13
00007a40685d5477  movaps [rsp+0x10], xmm8
00007a40685d547d  movaps [rsp+0x20], xmm14
00007a40685d5483  lea rdi, [rsp]
00007a40685d5487  mov esi, 0x00
00007a40685d548c  mov rax, 0x56F679577530
00007a40685d5496  call rax
00007a40685d5498  movaps xmm13, [rsp]
00007a40685d549d  add rsp, 0x30
00007a40685d54a1  vmovaps xmm0, [rsp]
00007a40685d54a6  vmovaps xmm1, [rsp+0x10]
00007a40685d54ac  vmovaps xmm2, [rsp+0x20]
00007a40685d54b2  vmovaps xmm3, [rsp+0x30]
00007a40685d54b8  vmovaps xmm4, [rsp+0x40]
00007a40685d54be  vmovaps xmm5, [rsp+0x50]
00007a40685d54c4  vmovaps xmm6, [rsp+0x60]
00007a40685d54ca  vmovaps xmm7, [rsp+0x70]
00007a40685d54d0  vmovaps xmm8, [rsp+0x80]
00007a40685d54d9  vmovaps xmm9, [rsp+0x90]
00007a40685d54e2  vmovaps xmm10, [rsp+0xA0]
00007a40685d54eb  vmovaps xmm11, [rsp+0xB0]
00007a40685d54f4  vmovaps xmm12, [rsp+0xC0]
00007a40685d54fd  vmovaps xmm14, [rsp+0xD0]
00007a40685d5506  vmovaps xmm15, [rsp+0xE0]
00007a40685d550f  add rsp, 0xF0
00007a40685d5516  pop r11
00007a40685d5518  pop r10
00007a40685d551a  pop r9
00007a40685d551c  pop r8
00007a40685d551e  pop rsi
00007a40685d551f  pop rdi
00007a40685d5520  pop rdx
00007a40685d5521  pop rcx
00007a40685d5522  pop rax
00007a40685d5523  add rsp, 0x08
00007a40685d5527  jmp 0x00007A40685D02F7
00007a40685d552c  sub rsp, 0x08
00007a40685d5530  push rax
00007a40685d5531  push rcx
00007a40685d5532  push rdx
00007a40685d5533  push rdi
00007a40685d5534  push rsi
00007a40685d5535  push r8
00007a40685d5537  push r9
00007a40685d5539  push r10
00007a40685d553b  push r11
00007a40685d553d  sub rsp, 0xF0
00007a40685d5544  vmovaps [rsp], xmm0
00007a40685d5549  vmovaps [rsp+0x10], xmm1
00007a40685d554f  vmovaps [rsp+0x20], xmm2
00007a40685d5555  vmovaps [rsp+0x30], xmm3
00007a40685d555b  vmovaps [rsp+0x40], xmm4
00007a40685d5561  vmovaps [rsp+0x50], xmm5
00007a40685d5567  vmovaps [rsp+0x60], xmm6
00007a40685d556d  vmovaps [rsp+0x70], xmm7
00007a40685d5573  vmovaps [rsp+0x80], xmm8
00007a40685d557c  vmovaps [rsp+0x90], xmm9
00007a40685d5585  vmovaps [rsp+0xA0], xmm10
00007a40685d558e  vmovaps [rsp+0xB0], xmm11
00007a40685d5597  vmovaps [rsp+0xC0], xmm12
00007a40685d55a0  vmovaps [rsp+0xD0], xmm13
00007a40685d55a9  vmovaps [rsp+0xE0], xmm15
00007a40685d55b2  sub rsp, 0x30
00007a40685d55b6  movaps [rsp], xmm14
00007a40685d55bb  movaps [rsp+0x10], xmm1
00007a40685d55c0  movaps [rsp+0x20], xmm10
00007a40685d55c6  lea rdi, [rsp]
00007a40685d55ca  mov esi, 0x00
00007a40685d55cf  mov rax, 0x56F679577530
00007a40685d55d9  call rax
00007a40685d55db  movaps xmm14, [rsp]
00007a40685d55e0  add rsp, 0x30
00007a40685d55e4  vmovaps xmm0, [rsp]
00007a40685d55e9  vmovaps xmm1, [rsp+0x10]
00007a40685d55ef  vmovaps xmm2, [rsp+0x20]
00007a40685d55f5  vmovaps xmm3, [rsp+0x30]
00007a40685d55fb  vmovaps xmm4, [rsp+0x40]
00007a40685d5601  vmovaps xmm5, [rsp+0x50]
00007a40685d5607  vmovaps xmm6, [rsp+0x60]
00007a40685d560d  vmovaps xmm7, [rsp+0x70]
00007a40685d5613  vmovaps xmm8, [rsp+0x80]
00007a40685d561c  vmovaps xmm9, [rsp+0x90]
00007a40685d5625  vmovaps xmm10, [rsp+0xA0]
00007a40685d562e  vmovaps xmm11, [rsp+0xB0]
00007a40685d5637  vmovaps xmm12, [rsp+0xC0]
00007a40685d5640  vmovaps xmm13, [rsp+0xD0]
00007a40685d5649  vmovaps xmm15, [rsp+0xE0]
00007a40685d5652  add rsp, 0xF0
00007a40685d5659  pop r11
00007a40685d565b  pop r10
00007a40685d565d  pop r9
00007a40685d565f  pop r8
00007a40685d5661  pop rsi
00007a40685d5662  pop rdi
00007a40685d5663  pop rdx
00007a40685d5664  pop rcx
00007a40685d5665  pop rax
00007a40685d5666  add rsp, 0x08
00007a40685d566a  jmp 0x00007A40685D031A
00007a40685d566f  sub rsp, 0x08
00007a40685d5673  push rax
00007a40685d5674  push rcx
00007a40685d5675  push rdx
00007a40685d5676  push rdi
00007a40685d5677  push rsi
00007a40685d5678  push r8
00007a40685d567a  push r9
00007a40685d567c  push r10
00007a40685d567e  push r11
00007a40685d5680  sub rsp, 0xF0
00007a40685d5687  vmovaps [rsp], xmm0
00007a40685d568c  vmovaps [rsp+0x10], xmm2
00007a40685d5692  vmovaps [rsp+0x20], xmm3
00007a40685d5698  vmovaps [rsp+0x30], xmm4
00007a40685d569e  vmovaps [rsp+0x40], xmm5
00007a40685d56a4  vmovaps [rsp+0x50], xmm6
00007a40685d56aa  vmovaps [rsp+0x60], xmm7
00007a40685d56b0  vmovaps [rsp+0x70], xmm8
00007a40685d56b6  vmovaps [rsp+0x80], xmm9
00007a40685d56bf  vmovaps [rsp+0x90], xmm10
00007a40685d56c8  vmovaps [rsp+0xA0], xmm11
00007a40685d56d1  vmovaps [rsp+0xB0], xmm12
00007a40685d56da  vmovaps [rsp+0xC0], xmm13
00007a40685d56e3  vmovaps [rsp+0xD0], xmm14
00007a40685d56ec  vmovaps [rsp+0xE0], xmm15
00007a40685d56f5  sub rsp, 0x30
00007a40685d56f9  movaps [rsp], xmm1
00007a40685d56fd  movaps [rsp+0x10], xmm7
00007a40685d5702  movaps [rsp+0x20], xmm11
00007a40685d5708  lea rdi, [rsp]
00007a40685d570c  mov esi, 0x00
00007a40685d5711  mov rax, 0x56F679577530
00007a40685d571b  call rax
00007a40685d571d  movaps xmm1, [rsp]
00007a40685d5721  add rsp, 0x30
00007a40685d5725  vmovaps xmm0, [rsp]
00007a40685d572a  vmovaps xmm2, [rsp+0x10]
00007a40685d5730  vmovaps xmm3, [rsp+0x20]
00007a40685d5736  vmovaps xmm4, [rsp+0x30]
00007a40685d573c  vmovaps xmm5, [rsp+0x40]
00007a40685d5742  vmovaps xmm6, [rsp+0x50]
00007a40685d5748  vmovaps xmm7, [rsp+0x60]
00007a40685d574e  vmovaps xmm8, [rsp+0x70]
00007a40685d5754  vmovaps xmm9, [rsp+0x80]
00007a40685d575d  vmovaps xmm10, [rsp+0x90]
00007a40685d5766  vmovaps xmm11, [rsp+0xA0]
00007a40685d576f  vmovaps xmm12, [rsp+0xB0]
00007a40685d5778  vmovaps xmm13, [rsp+0xC0]
00007a40685d5781  vmovaps xmm14, [rsp+0xD0]
00007a40685d578a  vmovaps xmm15, [rsp+0xE0]
00007a40685d5793  add rsp, 0xF0
00007a40685d579a  pop r11
00007a40685d579c  pop r10
00007a40685d579e  pop r9
00007a40685d57a0  pop r8
00007a40685d57a2  pop rsi
00007a40685d57a3  pop rdi
00007a40685d57a4  pop rdx
00007a40685d57a5  pop rcx
00007a40685d57a6  pop rax
00007a40685d57a7  add rsp, 0x08
00007a40685d57ab  jmp 0x00007A40685D033B
00007a40685d57b0  call 0x00007A406840E880
00007a40685d57b5  jmp 0x00007A40685D034E
00007a40685d57ba  call 0x00007A406840C380
00007a40685d57bf  jmp 0x00007A40685D0359
00007a40685d57c4  call 0x00007A406840D600
00007a40685d57c9  jmp 0x00007A40685D0364
00007a40685d57ce  call 0x00007A40683FF540
00007a40685d57d3  jmp 0x00007A40685D036F
00007a40685d57d8  int3
00007a40685d57d9  nop [rax], eax
00007a40685d57e0  mov rax, [r15+0x40]
00007a40685d57e4  mov r14, [r15+0x58]
00007a40685d57e8  lea r12, [rax+r14*1]
00007a40685d57ec  movaps xmm1, [r15+0x1D0]
00007a40685d57f4  vmovaps [rsp+0x10], xmm1
00007a40685d57fa  vmovaps xmm15, [rsp+0x10]
00007a40685d5800  por xmm1, xmm15
00007a40685d5805  movaps xmm14, [r15+0x1A0]
00007a40685d580d  vmovaps [rsp+0x10], xmm14
00007a40685d5813  vmovaps xmm13, [rsp+0x10]
00007a40685d5819  por xmm14, xmm13
00007a40685d581e  lea rax, [r12+0x30]
00007a40685d5823  mov r11, [r13+rax*1]
00007a40685d5828  lea rax, [r12+0x38]
00007a40685d582d  mov r10, [r13+rax*1]
00007a40685d5832  movq xmm13, r11
00007a40685d5837  movq xmm12, r10
00007a40685d583c  movq xmm13, xmm13
00007a40685d5841  vmovaps [rsp+0x10], xmm13
00007a40685d5847  movq xmm13, xmm13
00007a40685d584c  movaps [r15+0x130], xmm13
00007a40685d5854  movq xmm12, xmm12
00007a40685d5859  vmovaps [rsp+0x20], xmm12
00007a40685d585f  movq xmm12, xmm12
00007a40685d5864  movaps [r15+0x280], xmm12
00007a40685d586c  movaps xmm13, [r15+0x270]
00007a40685d5874  vmovaps [rsp+0x30], xmm13
00007a40685d587a  vmovaps xmm12, [rsp+0x30]
00007a40685d5880  por xmm13, xmm12
00007a40685d5885  lea rax, [r12+0x20]
00007a40685d588a  mov r11, [r13+rax*1]
00007a40685d588f  lea rax, [r12+0x28]
00007a40685d5894  mov r10, [r13+rax*1]
00007a40685d5899  movq xmm12, r11
00007a40685d589e  movq xmm11, r10
00007a40685d58a3  movq xmm12, xmm12
00007a40685d58a8  vmovaps [rsp+0x30], xmm12
00007a40685d58ae  movq xmm12, xmm12
00007a40685d58b3  movaps [r15+0x150], xmm12
00007a40685d58bb  movq xmm11, xmm11
00007a40685d58c0  vmovaps [rsp+0x40], xmm11
00007a40685d58c6  movq xmm11, xmm11
00007a40685d58cb  movaps [r15+0x140], xmm11
00007a40685d58d3  lea rax, [r12+0x10]
00007a40685d58d8  mov r11, [r13+rax*1]
00007a40685d58dd  lea rax, [r12+0x18]
00007a40685d58e2  mov r10, [r13+rax*1]
00007a40685d58e7  movq xmm12, r11
00007a40685d58ec  movq xmm11, r10
00007a40685d58f1  movq xmm12, xmm12
00007a40685d58f6  vmovaps [rsp+0x50], xmm12
00007a40685d58fc  movq xmm12, xmm12
00007a40685d5901  movaps [r15+0x170], xmm12
00007a40685d5909  movq xmm11, xmm11
00007a40685d590e  vmovaps [rsp+0x60], xmm11
00007a40685d5914  movq xmm11, xmm11
00007a40685d5919  movaps [r15+0x160], xmm11
00007a40685d5921  mov rax, [r13+r12*1]
00007a40685d5926  vmovq xmm12, rax
00007a40685d592b  vpbroadcastq xmm12, xmm12
00007a40685d5930  lea rax, [r12+0x08]
00007a40685d5935  mov r12, [r13+rax*1]
00007a40685d593a  movq xmm11, r12
00007a40685d593f  movaps [r15+0x230], xmm11
00007a40685d5947  mov rax, [r15+0xF8]
00007a40685d594e  lea r12, [rax+0x50]
00007a40685d5952  movups xmm11, [r13+r12*1]
00007a40685d5958  lea r12, [rax+0x60]
00007a40685d595c  movups xmm10, [r13+r12*1]
00007a40685d5962  lea r12, [rax+0x30]
00007a40685d5966  movups xmm9, [r13+r12*1]
00007a40685d596c  mov r12, [r15+0x50]
00007a40685d5970  lea r11, [r12+r14*1]
00007a40685d5974  mov [r15+0x60], r11
00007a40685d5978  lea r12, [r14+0x40]
00007a40685d597c  mov [r15+0x58], r12
00007a40685d5980  movaps xmm8, xmm12
00007a40685d5984  mulpd xmm8, xmm15
00007a40685d5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007a40685d598f  ptest xmm7, xmm7
00007a40685d5994  jnz 0x00007A40685D67B7
00007a40685d599a  movq xmm15, qword ptr [r15+0x230]
00007a40685d59a3  vmovaps [rsp+0x70], xmm15
00007a40685d59a9  vpermilpd xmm15, xmm15, 0x00
00007a40685d59af  movaps xmm7, xmm9
00007a40685d59b3  mulpd xmm7, xmm15
00007a40685d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007a40685d59bd  ptest xmm6, xmm6
00007a40685d59c2  jnz 0x00007A40685D68FB
00007a40685d59c8  vxorps xmm15, xmm15, xmm15
00007a40685d59cd  vpbroadcastq xmm15, xmm15
00007a40685d59d2  movaps xmm9, xmm12
00007a40685d59d6  mulpd xmm9, xmm10
00007a40685d59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007a40685d59e1  ptest xmm6, xmm6
00007a40685d59e6  jnz 0x00007A40685D6A3D
00007a40685d59ec  movaps xmm10, xmm12
00007a40685d59f0  mulpd xmm10, xmm11
00007a40685d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007a40685d59fb  ptest xmm6, xmm6
00007a40685d5a00  jnz 0x00007A40685D6B81
00007a40685d5a06  movaps xmm11, [r15+0x1F0]
00007a40685d5a0e  movaps xmm6, xmm12
00007a40685d5a12  mulpd xmm6, xmm11
00007a40685d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007a40685d5a1c  ptest xmm5, xmm5
00007a40685d5a21  jnz 0x00007A40685D6CC5
00007a40685d5a27  movaps xmm12, [r15+0x2A0]
00007a40685d5a2f  vmovaps [rsp+0x80], xmm12
00007a40685d5a38  vmovaps xmm11, [rsp+0x80]
00007a40685d5a41  por xmm12, xmm11
00007a40685d5a46  movaps xmm11, [r15+0x250]
00007a40685d5a4e  vmovaps [rsp+0x80], xmm11
00007a40685d5a57  vmovaps xmm5, [rsp+0x80]
00007a40685d5a60  por xmm11, xmm5
00007a40685d5a65  vmovaps xmm4, [rsp+0x70]
00007a40685d5a6b  vpermilpd xmm4, xmm4, 0x00
00007a40685d5a71  movaps xmm3, xmm5
00007a40685d5a74  mulpd xmm3, xmm4
00007a40685d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007a40685d5a7d  ptest xmm2, xmm2
00007a40685d5a82  jnz 0x00007A40685D6E07
00007a40685d5a88  mov [rsp+0x80], rax
00007a40685d5a90  xor eax, eax
00007a40685d5a92  mov r14d, 0x200
00007a40685d5a98  cmp r12, r14
00007a40685d5a9b  cmc
00007a40685d5a9c  lahf
00007a40685d5a9d  seto al
00007a40685d5aa0  mov [r15+0x108], eax
00007a40685d5aa7  movaps xmm5, xmm8
00007a40685d5aab  addpd xmm5, xmm15
00007a40685d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007a40685d5ab5  ptest xmm4, xmm4
00007a40685d5aba  jnz 0x00007A40685D6F47
00007a40685d5ac0  movaps xmm8, [r15+0x1B0]
00007a40685d5ac8  movaps xmm4, xmm9
00007a40685d5acc  addpd xmm4, xmm8
00007a40685d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007a40685d5ad6  ptest xmm2, xmm2
00007a40685d5adb  jnz 0x00007A40685D7089
00007a40685d5ae1  movaps xmm9, xmm10
00007a40685d5ae5  addpd xmm9, xmm8
00007a40685d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007a40685d5af0  ptest xmm2, xmm2
00007a40685d5af5  jnz 0x00007A40685D71CB
00007a40685d5afb  movaps xmm10, [r15+0x2F0]
00007a40685d5b03  vmovaps [rsp+0x90], xmm10
00007a40685d5b0c  vmovaps xmm8, [rsp+0x90]
00007a40685d5b15  por xmm10, xmm8
00007a40685d5b1a  movaps xmm8, [r15+0x2E0]
00007a40685d5b22  vmovaps [rsp+0x90], xmm8
00007a40685d5b2b  vmovaps xmm2, [rsp+0x90]
00007a40685d5b34  por xmm8, xmm2
00007a40685d5b39  movaps xmm2, [r15+0x2D0]
00007a40685d5b41  vmovaps [rsp+0x90], xmm2
00007a40685d5b4a  vmovaps [rsp+0xA0], xmm1
00007a40685d5b53  vmovaps xmm1, [rsp+0x90]
00007a40685d5b5c  por xmm2, xmm1
00007a40685d5b60  movaps xmm1, [r15+0x200]
00007a40685d5b68  vmovaps [rsp+0x90], xmm1
00007a40685d5b71  vmovaps [rsp+0xB0], xmm15
00007a40685d5b7a  vmovaps xmm15, [rsp+0x90]
00007a40685d5b83  por xmm1, xmm15
00007a40685d5b88  movaps xmm15, [r15+0x1C0]
00007a40685d5b90  vmovaps [rsp+0x90], xmm15
00007a40685d5b99  vmovaps [rsp+0xC0], xmm1
00007a40685d5ba2  vmovaps xmm1, [rsp+0x90]
00007a40685d5bab  por xmm15, xmm1
00007a40685d5bb0  movaps xmm1, [r15+0x190]
00007a40685d5bb8  vmovaps [rsp+0x90], xmm1
00007a40685d5bc1  vmovaps [rsp+0xD0], xmm15
00007a40685d5bca  vmovaps xmm15, [rsp+0x90]
00007a40685d5bd3  por xmm1, xmm15
00007a40685d5bd8  movaps xmm15, [r15+0x300]
00007a40685d5be0  vmovaps [rsp+0x90], xmm15
00007a40685d5be9  vmovaps [rsp+0xE0], xmm1
00007a40685d5bf2  vmovaps xmm1, [rsp+0x90]
00007a40685d5bfb  por xmm15, xmm1
00007a40685d5c00  mov rax, [rsp+0x80]
00007a40685d5c08  lea r14, [rax+0xA0]
00007a40685d5c0f  movups xmm1, [r13+r14*1]
00007a40685d5c15  lea r14, [rax+0xB0]
00007a40685d5c1c  vmovaps [rsp+0x80], xmm1
00007a40685d5c25  movups xmm1, [r13+r14*1]
00007a40685d5c2b  vmovaps [rsp+0x90], xmm1
00007a40685d5c34  vmovaps [rsp+0xF0], xmm15
00007a40685d5c3d  vmovaps xmm15, [rsp+0xB0]
00007a40685d5c46  vmovaps [rsp+0xB0], xmm14
00007a40685d5c4f  movaps xmm1, xmm6
00007a40685d5c52  addpd xmm1, xmm15
00007a40685d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007a40685d5c5c  ptest xmm14, xmm14
00007a40685d5c62  jnz 0x00007A40685D7323
00007a40685d5c68  lea r14, [rax+0xF0]
00007a40685d5c6f  movups xmm15, [r13+r14*1]
00007a40685d5c75  movaps xmm14, xmm4
00007a40685d5c79  addpd xmm14, xmm3
00007a40685d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007a40685d5c84  ptest xmm6, xmm6
00007a40685d5c89  jnz 0x00007A40685D746E
00007a40685d5c8f  movaps xmm6, xmm9
00007a40685d5c93  addpd xmm6, xmm7
00007a40685d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007a40685d5c9c  ptest xmm4, xmm4
00007a40685d5ca1  jnz 0x00007A40685D75B0
00007a40685d5ca7  vmovaps xmm9, [rsp+0x70]
00007a40685d5cad  vpermilpd xmm9, xmm9, 0x00
00007a40685d5cb3  vmovaps xmm4, [rsp+0x90]
00007a40685d5cbc  movaps xmm7, xmm4
00007a40685d5cbf  mulpd xmm7, xmm9
00007a40685d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007a40685d5cc9  ptest xmm3, xmm3
00007a40685d5cce  jnz 0x00007A40685D76F1
00007a40685d5cd4  vmovaps xmm9, [rsp+0x50]
00007a40685d5cda  vpermilpd xmm9, xmm9, 0x00
00007a40685d5ce0  movaps xmm4, xmm15
00007a40685d5ce4  mulpd xmm4, xmm9
00007a40685d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007a40685d5cee  ptest xmm3, xmm3
00007a40685d5cf3  jnz 0x00007A40685D7832
00007a40685d5cf9  lea r14, [rax+0xE0]
00007a40685d5d00  movups xmm15, [r13+r14*1]
00007a40685d5d06  vmovaps xmm9, [rsp+0x70]
00007a40685d5d0c  vpermilpd xmm9, xmm9, 0x00
00007a40685d5d12  vmovaps [rsp+0x70], xmm1
00007a40685d5d18  vmovaps xmm1, [rsp+0x80]
00007a40685d5d21  vmovaps [rsp+0x80], xmm15
00007a40685d5d2a  movaps xmm3, xmm1
00007a40685d5d2d  mulpd xmm3, xmm9
00007a40685d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007a40685d5d37  ptest xmm15, xmm15
00007a40685d5d3d  jnz 0x00007A40685D797E
00007a40685d5d43  vmovaps xmm1, [rsp+0xF0]
00007a40685d5d4c  vmovaps xmm15, [rsp+0xF0]
00007a40685d5d55  por xmm1, xmm15
00007a40685d5d5a  movaps [r15+0x300], xmm1
00007a40685d5d62  vmovaps xmm15, [rsp+0xE0]
00007a40685d5d6b  vmovaps xmm9, [rsp+0xE0]
00007a40685d5d74  por xmm15, xmm9
00007a40685d5d79  movaps [r15+0x190], xmm15
00007a40685d5d81  vmovaps xmm9, [rsp+0x50]
00007a40685d5d87  vpermilpd xmm9, xmm9, 0x00
00007a40685d5d8d  vmovaps [rsp+0x90], xmm1
00007a40685d5d96  vmovaps [rsp+0xE0], xmm15
00007a40685d5d9f  vmovaps xmm15, [rsp+0x80]
00007a40685d5da8  vmovaps [rsp+0x80], xmm14
00007a40685d5db1  movaps xmm1, xmm15
00007a40685d5db5  mulpd xmm1, xmm9
00007a40685d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007a40685d5dbf  ptest xmm14, xmm14
00007a40685d5dc5  jnz 0x00007A40685D7ABF
00007a40685d5dcb  lea r14, [rax+0x90]
00007a40685d5dd2  movups xmm15, [r13+r14*1]
00007a40685d5dd8  vmovaps xmm14, [rsp+0xD0]
00007a40685d5de1  vmovaps xmm9, [rsp+0xD0]
00007a40685d5dea  por xmm14, xmm9
00007a40685d5def  movaps [r15+0x1C0], xmm14
00007a40685d5df7  vmovaps xmm9, [rsp+0xC0]
00007a40685d5e00  vmovaps [rsp+0xD0], xmm1
00007a40685d5e09  vmovaps xmm1, [rsp+0xC0]
00007a40685d5e12  por xmm9, xmm1
00007a40685d5e17  movaps [r15+0x200], xmm9
00007a40685d5e1f  vmovaps [rsp+0xC0], xmm2
00007a40685d5e28  vmovaps xmm1, [rsp+0xC0]
00007a40685d5e31  por xmm2, xmm1
00007a40685d5e35  movaps [r15+0x2D0], xmm2
00007a40685d5e3d  vmovaps [rsp+0xC0], xmm8
00007a40685d5e46  vmovaps xmm1, [rsp+0xC0]
00007a40685d5e4f  por xmm8, xmm1
00007a40685d5e54  movaps [r15+0x2E0], xmm8
00007a40685d5e5c  vmovaps [rsp+0xC0], xmm15
00007a40685d5e65  movaps xmm1, xmm5
00007a40685d5e68  addpd xmm1, xmm7
00007a40685d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007a40685d5e71  ptest xmm15, xmm15
00007a40685d5e77  jnz 0x00007A40685D7C0B
00007a40685d5e7d  vmovaps xmm15, [rsp+0x50]
00007a40685d5e83  vpermilpd xmm15, xmm15, 0x00
00007a40685d5e89  vmovaps xmm5, [rsp+0xC0]
00007a40685d5e92  vmovaps [rsp+0xC0], xmm1
00007a40685d5e9b  movaps xmm7, xmm5
00007a40685d5e9e  mulpd xmm7, xmm15
00007a40685d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007a40685d5ea8  ptest xmm1, xmm1
00007a40685d5ead  jnz 0x00007A40685D7D4B
00007a40685d5eb3  lea r14, [rax+0x80]
00007a40685d5eba  movups xmm1, [r13+r14*1]
00007a40685d5ec0  vmovaps xmm5, [rsp+0x70]
00007a40685d5ec6  vmovaps [rsp+0x70], xmm1
00007a40685d5ecc  movaps xmm15, xmm5
00007a40685d5ed0  addpd xmm15, xmm3
00007a40685d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007a40685d5edb  ptest xmm1, xmm1
00007a40685d5ee0  jnz 0x00007A40685D7E96
00007a40685d5ee6  vmovaps xmm5, [rsp+0x80]
00007a40685d5eef  movaps xmm1, xmm5
00007a40685d5ef2  addpd xmm1, xmm4
00007a40685d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007a40685d5efb  ptest xmm3, xmm3
00007a40685d5f00  jnz 0x00007A40685D7FD8
00007a40685d5f06  vmovaps [rsp+0x80], xmm10
00007a40685d5f0f  vmovaps xmm5, [rsp+0x80]
00007a40685d5f18  por xmm10, xmm5
00007a40685d5f1d  movaps [r15+0x2F0], xmm10
00007a40685d5f25  vmovaps xmm5, [rsp+0x50]
00007a40685d5f2b  vpermilpd xmm5, xmm5, 0x00
00007a40685d5f31  vmovaps xmm3, [rsp+0x70]
00007a40685d5f37  vmovaps [rsp+0x50], xmm1
00007a40685d5f3d  movaps xmm4, xmm3
00007a40685d5f40  mulpd xmm4, xmm5
00007a40685d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007a40685d5f49  ptest xmm1, xmm1
00007a40685d5f4e  jnz 0x00007A40685D8118
00007a40685d5f54  lea r14, [rax+0xD0]
00007a40685d5f5b  movups xmm1, [r13+r14*1]
00007a40685d5f61  vmovaps xmm3, [rsp+0xD0]
00007a40685d5f6a  vmovaps [rsp+0x70], xmm1
00007a40685d5f70  movaps xmm5, xmm6
00007a40685d5f73  addpd xmm5, xmm3
00007a40685d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007a40685d5f7c  ptest xmm1, xmm1
00007a40685d5f81  jnz 0x00007A40685D8262
00007a40685d5f87  vmovaps xmm1, [rsp+0x60]
00007a40685d5f8d  vpermilpd xmm1, xmm1, 0x00
00007a40685d5f93  movaps xmm6, xmm9
00007a40685d5f97  mulpd xmm6, xmm1
00007a40685d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007a40685d5fa0  ptest xmm3, xmm3
00007a40685d5fa5  jnz 0x00007A40685D83A2
00007a40685d5fab  movaps [r15+0x260], xmm6
00007a40685d5fb3  vxorps xmm1, xmm1, xmm1
00007a40685d5fb7  vpbroadcastq xmm1, xmm1
00007a40685d5fbc  movaps [r15+0x1B0], xmm1
00007a40685d5fc4  vmovaps xmm1, [rsp+0x60]
00007a40685d5fca  vpermilpd xmm1, xmm1, 0x00
00007a40685d5fd0  vmovaps xmm3, [rsp+0x70]
00007a40685d5fd6  vmovaps [rsp+0x70], xmm15
00007a40685d5fdc  movaps xmm9, xmm3
00007a40685d5fe0  mulpd xmm9, xmm1
00007a40685d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007a40685d5feb  ptest xmm15, xmm15
00007a40685d5ff1  jnz 0x00007A40685D84E3
00007a40685d5ff7  lea r14, [rax+0xC0]
00007a40685d5ffe  movups xmm1, [r13+r14*1]
00007a40685d6004  vmovaps xmm3, [rsp+0xC0]
00007a40685d600d  vmovaps [rsp+0x80], xmm1
00007a40685d6016  movaps xmm15, xmm3
00007a40685d601a  addpd xmm15, xmm7
00007a40685d601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007a40685d6025  ptest xmm1, xmm1
00007a40685d602a  jnz 0x00007A40685D862F
00007a40685d6030  vmovaps [rsp+0xC0], xmm13
00007a40685d6039  vmovaps xmm1, [rsp+0xC0]
00007a40685d6042  por xmm13, xmm1
00007a40685d6047  movaps [r15+0x270], xmm13
00007a40685d604f  vmovaps xmm1, [rsp+0xB0]
00007a40685d6058  vmovaps xmm7, [rsp+0xB0]
00007a40685d6061  por xmm1, xmm7
00007a40685d6065  movaps [r15+0x1A0], xmm1
00007a40685d606d  vmovaps xmm1, [rsp+0x60]
00007a40685d6073  vpermilpd xmm1, xmm1, 0x00
00007a40685d6079  vmovaps [rsp+0xB0], xmm1
00007a40685d6082  vmovaps xmm1, [rsp+0x80]
00007a40685d608b  vmovaps [rsp+0x80], xmm15
00007a40685d6094  vmovaps xmm15, [rsp+0xB0]
00007a40685d609d  vmovaps [rsp+0xB0], xmm14
00007a40685d60a6  movaps xmm3, xmm1
00007a40685d60a9  mulpd xmm3, xmm15
00007a40685d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007a40685d60b3  ptest xmm14, xmm14
00007a40685d60b9  jnz 0x00007A40685D8771
00007a40685d60bf  lea r14, [rax+0x20]
00007a40685d60c3  movups xmm1, [r13+r14*1]
00007a40685d60c9  movaps [r15+0x110], xmm1
00007a40685d60d1  vmovaps xmm14, [rsp+0x70]
00007a40685d60d7  vmovaps [rsp+0x70], xmm1
00007a40685d60dd  movaps xmm15, xmm14
00007a40685d60e1  addpd xmm15, xmm4
00007a40685d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007a40685d60ec  ptest xmm1, xmm1
00007a40685d60f1  jnz 0x00007A40685D88BC
00007a40685d60f7  vmovaps xmm1, [rsp+0x60]
00007a40685d60fd  vpermilpd xmm1, xmm1, 0x00
00007a40685d6103  movaps xmm14, xmm2
00007a40685d6107  mulpd xmm14, xmm1
00007a40685d610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007a40685d6112  ptest xmm4, xmm4
00007a40685d6117  jnz 0x00007A40685D89FF
00007a40685d611d  vmovaps xmm4, [rsp+0x50]
00007a40685d6123  movaps xmm1, xmm4
00007a40685d6126  addpd xmm1, xmm9
00007a40685d612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007a40685d6130  ptest xmm2, xmm2
00007a40685d6135  jnz 0x00007A40685D8B41
00007a40685d613b  vmovaps xmm9, [rsp+0x30]
00007a40685d6141  vpermilpd xmm9, xmm9, 0x00
00007a40685d6147  vmovaps xmm2, [rsp+0x70]
00007a40685d614d  vmovaps [rsp+0x50], xmm1
00007a40685d6153  movaps xmm4, xmm2
00007a40685d6156  mulpd xmm4, xmm9
00007a40685d615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007a40685d6160  ptest xmm1, xmm1
00007a40685d6165  jnz 0x00007A40685D8C82
00007a40685d616b  vmovaps xmm1, [rsp+0x30]
00007a40685d6171  vpermilpd xmm1, xmm1, 0x00
00007a40685d6177  vmovaps xmm2, [rsp+0x90]
00007a40685d6180  vmovaps [rsp+0x60], xmm15
00007a40685d6186  movaps xmm9, xmm2
00007a40685d618a  mulpd xmm9, xmm1
00007a40685d618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007a40685d6195  ptest xmm15, xmm15
00007a40685d619b  jnz 0x00007A40685D8DC3
00007a40685d61a1  vmovaps xmm15, [rsp+0x80]
00007a40685d61aa  movaps xmm1, xmm15
00007a40685d61ae  addpd xmm1, xmm6
00007a40685d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007a40685d61b7  ptest xmm2, xmm2
00007a40685d61bc  jnz 0x00007A40685D8F05
00007a40685d61c2  movaps xmm15, xmm5
00007a40685d61c6  addpd xmm15, xmm3
00007a40685d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007a40685d61d1  ptest xmm6, xmm6
00007a40685d61d6  jnz 0x00007A40685D9046
00007a40685d61dc  vmovaps xmm6, [rsp+0x30]
00007a40685d61e2  vpermilpd xmm6, xmm6, 0x00
00007a40685d61e8  movaps xmm5, xmm8
00007a40685d61ec  mulpd xmm5, xmm6
00007a40685d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007a40685d61f5  ptest xmm3, xmm3
00007a40685d61fa  jnz 0x00007A40685D9188
00007a40685d6200  vmovaps xmm8, [rsp+0x30]
00007a40685d6206  vpermilpd xmm8, xmm8, 0x00
00007a40685d620c  movaps xmm6, xmm10
00007a40685d6210  mulpd xmm6, xmm8
00007a40685d6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007a40685d621a  ptest xmm3, xmm3
00007a40685d621f  jnz 0x00007A40685D92C9
00007a40685d6225  vmovaps xmm8, [rsp+0x60]
00007a40685d622b  movaps xmm10, xmm8
00007a40685d622f  addpd xmm10, xmm14
00007a40685d6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007a40685d623a  ptest xmm3, xmm3
00007a40685d623f  jnz 0x00007A40685D940B
00007a40685d6245  vmovaps xmm8, [rsp+0x50]
00007a40685d624b  movaps xmm14, xmm8
00007a40685d624f  addpd xmm14, xmm4
00007a40685d6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007a40685d625a  ptest xmm3, xmm3
00007a40685d625f  jnz 0x00007A40685D954F
00007a40685d6265  vmovaps xmm8, [rsp+0x40]
00007a40685d626b  vpermilpd xmm8, xmm8, 0x00
00007a40685d6271  movaps xmm4, xmm13
00007a40685d6275  mulpd xmm4, xmm8
00007a40685d627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007a40685d627f  ptest xmm3, xmm3
00007a40685d6284  jnz 0x00007A40685D9692
00007a40685d628a  movaps xmm13, xmm15
00007a40685d628e  addpd xmm13, xmm9
00007a40685d6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007a40685d6299  ptest xmm8, xmm8
00007a40685d629f  jnz 0x00007A40685D97D4
00007a40685d62a5  movaps xmm15, xmm1
00007a40685d62a9  addpd xmm15, xmm5
00007a40685d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007a40685d62b4  ptest xmm9, xmm9
00007a40685d62ba  jnz 0x00007A40685D9918
00007a40685d62c0  vmovaps [rsp+0x30], xmm11
00007a40685d62c6  vmovaps xmm1, [rsp+0x30]
00007a40685d62cc  por xmm11, xmm1
00007a40685d62d1  movaps [r15+0x250], xmm11
00007a40685d62d9  vmovaps [rsp+0x30], xmm12
00007a40685d62df  vmovaps xmm1, [rsp+0x30]
00007a40685d62e5  por xmm12, xmm1
00007a40685d62ea  movaps [r15+0x2A0], xmm12
00007a40685d62f2  vmovaps xmm1, [rsp+0xA0]
00007a40685d62fb  vmovaps xmm11, [rsp+0xA0]
00007a40685d6304  por xmm1, xmm11
00007a40685d6309  movaps [r15+0x1D0], xmm1
00007a40685d6311  lea r14, [rax+0x40]
00007a40685d6315  movups xmm1, [r13+r14*1]
00007a40685d631b  movaps [r15+0x2C0], xmm1
00007a40685d6323  vmovaps xmm11, [rsp+0x40]
00007a40685d6329  vpermilpd xmm11, xmm11, 0x00
00007a40685d632f  vmovaps xmm8, [rsp+0xE0]
00007a40685d6338  movaps xmm9, xmm8
00007a40685d633c  mulpd xmm9, xmm11
00007a40685d6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007a40685d6347  ptest xmm5, xmm5
00007a40685d634c  jnz 0x00007A40685D9A64
00007a40685d6352  movaps xmm11, xmm10
00007a40685d6356  addpd xmm11, xmm6
00007a40685d635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007a40685d6361  ptest xmm8, xmm8
00007a40685d6367  jnz 0x00007A40685D9BA8
00007a40685d636d  movaps xmm10, xmm14
00007a40685d6371  addpd xmm10, xmm4
00007a40685d6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007a40685d637c  ptest xmm8, xmm8
00007a40685d6382  jnz 0x00007A40685D9CEB
00007a40685d6388  vmovaps xmm14, [rsp+0x40]
00007a40685d638e  vpermilpd xmm14, xmm14, 0x00
00007a40685d6394  movaps xmm8, xmm1
00007a40685d6398  mulpd xmm8, xmm14
00007a40685d639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007a40685d63a3  ptest xmm6, xmm6
00007a40685d63a8  jnz 0x00007A40685D9E2E
00007a40685d63ae  movaps xmm1, [r15+0x2B0]
00007a40685d63b6  vmovaps xmm14, [rsp+0x40]
00007a40685d63bc  vpermilpd xmm14, xmm14, 0x00
00007a40685d63c2  movaps xmm6, xmm1
00007a40685d63c5  mulpd xmm6, xmm14
00007a40685d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007a40685d63cf  ptest xmm5, xmm5
00007a40685d63d4  jnz 0x00007A40685D9F71
00007a40685d63da  vmovaps xmm1, [rsp+0x10]
00007a40685d63e0  vpermilpd xmm1, xmm1, 0x00
00007a40685d63e6  movaps xmm14, xmm12
00007a40685d63ea  mulpd xmm14, xmm1
00007a40685d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007a40685d63f5  ptest xmm5, xmm5
00007a40685d63fa  jnz 0x00007A40685DA0B2
00007a40685d6400  movaps xmm1, xmm13
00007a40685d6404  addpd xmm1, xmm9
00007a40685d6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007a40685d640e  ptest xmm12, xmm12
00007a40685d6414  jnz 0x00007A40685DA1F5
00007a40685d641a  vmovaps xmm13, [rsp+0x10]
00007a40685d6420  vpermilpd xmm13, xmm13, 0x00
00007a40685d6426  movaps xmm12, xmm7
00007a40685d642a  mulpd xmm12, xmm13
00007a40685d642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007a40685d6435  ptest xmm9, xmm9
00007a40685d643b  jnz 0x00007A40685DA337
00007a40685d6441  movaps xmm13, xmm15
00007a40685d6445  addpd xmm13, xmm8
00007a40685d644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007a40685d6450  ptest xmm9, xmm9
00007a40685d6456  jnz 0x00007A40685DA47A
00007a40685d645c  movaps xmm15, [r15+0x290]
00007a40685d6464  vmovaps xmm9, [rsp+0x10]
00007a40685d646a  vpermilpd xmm9, xmm9, 0x00
00007a40685d6470  movaps xmm8, xmm15
00007a40685d6474  mulpd xmm8, xmm9
00007a40685d6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007a40685d647f  ptest xmm7, xmm7
00007a40685d6484  jnz 0x00007A40685DA5BE
00007a40685d648a  movaps xmm15, xmm11
00007a40685d648e  addpd xmm15, xmm6
00007a40685d6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007a40685d6499  ptest xmm9, xmm9
00007a40685d649f  jnz 0x00007A40685DA702
00007a40685d64a5  movaps xmm11, [r15+0x1E0]
00007a40685d64ad  vmovaps xmm9, [rsp+0x10]
00007a40685d64b3  vpermilpd xmm9, xmm9, 0x00
00007a40685d64b9  movaps xmm7, xmm11
00007a40685d64bd  mulpd xmm7, xmm9
00007a40685d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007a40685d64c7  ptest xmm6, xmm6
00007a40685d64cc  jnz 0x00007A40685DA845
00007a40685d64d2  movaps xmm11, xmm10
00007a40685d64d6  addpd xmm11, xmm14
00007a40685d64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007a40685d64e1  ptest xmm9, xmm9
00007a40685d64e7  jnz 0x00007A40685DA987
00007a40685d64ed  lea r14, [rax+0x70]
00007a40685d64f1  movups xmm14, [r13+r14*1]
00007a40685d64f7  movaps [r15+0x240], xmm14
00007a40685d64ff  movaps xmm10, xmm1
00007a40685d6503  addpd xmm10, xmm12
00007a40685d6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007a40685d650e  ptest xmm9, xmm9
00007a40685d6514  jnz 0x00007A40685DAAD5
00007a40685d651a  movaps [r15+0x170], xmm10
00007a40685d6522  vmovaps xmm1, [rsp+0x20]
00007a40685d6528  vpermilpd xmm1, xmm1, 0x00
00007a40685d652e  movaps xmm12, xmm14
00007a40685d6532  mulpd xmm12, xmm1
00007a40685d6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007a40685d653d  ptest xmm9, xmm9
00007a40685d6543  jnz 0x00007A40685DAC18
00007a40685d6549  vmovaps xmm1, [rsp+0x20]
00007a40685d654f  vpermilpd xmm1, xmm1, 0x00
00007a40685d6555  vmovaps xmm9, [rsp+0xB0]
00007a40685d655e  movaps xmm14, xmm9
00007a40685d6562  mulpd xmm14, xmm1
00007a40685d6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007a40685d656d  ptest xmm6, xmm6
00007a40685d6572  jnz 0x00007A40685DAD5B
00007a40685d6578  movaps [r15+0x180], xmm14
00007a40685d6580  movaps xmm1, xmm13
00007a40685d6584  addpd xmm1, xmm8
00007a40685d6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007a40685d658e  ptest xmm9, xmm9
00007a40685d6594  jnz 0x00007A40685DAE9E
00007a40685d659a  movaps [r15+0x210], xmm1
00007a40685d65a2  movups xmm13, [r13+rax*1]
00007a40685d65a8  lea r14, [rax+0x10]
00007a40685d65ac  movups xmm9, [r13+r14*1]
00007a40685d65b2  movaps [r15+0x230], xmm9
00007a40685d65ba  movaps xmm8, xmm15
00007a40685d65be  addpd xmm8, xmm7
00007a40685d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007a40685d65c9  ptest xmm6, xmm6
00007a40685d65ce  jnz 0x00007A40685DAFF4
00007a40685d65d4  movaps [r15+0x130], xmm8
00007a40685d65dc  vmovaps xmm15, [rsp+0x20]
00007a40685d65e2  vpermilpd xmm15, xmm15, 0x00
00007a40685d65e8  movaps xmm7, xmm9
00007a40685d65ec  mulpd xmm7, xmm15
00007a40685d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007a40685d65f6  ptest xmm6, xmm6
00007a40685d65fb  jnz 0x00007A40685DB137
00007a40685d6601  movaps [r15+0x220], xmm7
00007a40685d6609  vmovaps xmm15, [rsp+0x20]
00007a40685d660f  vpermilpd xmm15, xmm15, 0x00
00007a40685d6615  movaps xmm9, xmm13
00007a40685d6619  mulpd xmm9, xmm15
00007a40685d661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007a40685d6624  ptest xmm6, xmm6
00007a40685d6629  jnz 0x00007A40685DB279
00007a40685d662f  movaps xmm15, xmm11
00007a40685d6633  addpd xmm15, xmm12
00007a40685d6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007a40685d663e  ptest xmm13, xmm13
00007a40685d6644  jnz 0x00007A40685DB3BD
00007a40685d664a  movaps [r15+0x140], xmm15
00007a40685d6652  movaps xmm13, xmm10
00007a40685d6656  addpd xmm13, xmm14
00007a40685d665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007a40685d6661  ptest xmm12, xmm12
00007a40685d6667  jnz 0x00007A40685DB501
00007a40685d666d  movaps [r15+0x150], xmm13
00007a40685d6675  movaps xmm14, xmm1
00007a40685d6679  addpd xmm14, xmm7
00007a40685d667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007a40685d6684  ptest xmm12, xmm12
00007a40685d668a  jnz 0x00007A40685DB645
00007a40685d6690  movaps [r15+0x160], xmm14
00007a40685d6698  movaps xmm1, xmm8
00007a40685d669c  addpd xmm1, xmm9
00007a40685d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007a40685d66a6  ptest xmm12, xmm12
00007a40685d66ac  jnz 0x00007A40685DB787
00007a40685d66b2  movaps [r15+0x120], xmm1
00007a40685d66ba  movups [r13+r11*1], xmm15
00007a40685d66c0  lea rax, [r11+0x10]
00007a40685d66c4  movups [r13+rax*1], xmm13
00007a40685d66ca  lea rax, [r11+0x20]
00007a40685d66ce  movups [r13+rax*1], xmm14
00007a40685d66d4  lea rax, [r11+0x30]
00007a40685d66d8  movups [r13+rax*1], xmm1
00007a40685d66de  mov eax, [r15+0x108]
00007a40685d66e5  sahf
00007a40685d66e6  jnz 0x00007A40685D6718
00007a40685d66e8  cmp dword ptr [r15+0x318], 0x00
00007a40685d66f0  jz 0x00007A40685DB900
00007a40685d66f6  nop [rax+rax*1], ax
00007a40685d66ff  nop [rax+rax*1], eax
00007a40685d6707  mov eax, 0x410444
00007a40685d670c  mov [r15+0x100], rax
00007a40685d6713  jmp 0x00007A40683FE110
00007a40685d6718  cmp dword ptr [r15+0x318], 0x00
00007a40685d6720  jz 0x00007A40685D57E0
00007a40685d6726  nop [rax+rax*1], ax
00007a40685d672f  nop [rax+rax*1], eax
00007a40685d6737  mov eax, 0x410278
00007a40685d673c  mov [r15+0x100], rax
00007a40685d6743  jmp 0x00007A40683FE110
00007a40685d6748  int3
00007a40685d6749  call 0x00007A406840A4B0
00007a40685d674e  jmp 0x00007A40685D5828
00007a40685d6753  call 0x00007A4068409240
00007a40685d6758  jmp 0x00007A40685D5832
00007a40685d675d  call 0x00007A406840A4B0
00007a40685d6762  jmp 0x00007A40685D588F
00007a40685d6767  call 0x00007A4068409240
00007a40685d676c  jmp 0x00007A40685D5899
00007a40685d6771  call 0x00007A406840A4B0
00007a40685d6776  jmp 0x00007A40685D58DD
00007a40685d677b  call 0x00007A4068409240
00007a40685d6780  jmp 0x00007A40685D58E7
00007a40685d6785  call 0x00007A40684B47C0
00007a40685d678a  jmp 0x00007A40685D5926
00007a40685d678f  call 0x00007A406840B720
00007a40685d6794  jmp 0x00007A40685D593A
00007a40685d6799  call 0x00007A40684BFC30
00007a40685d679e  jmp 0x00007A40685D5958
00007a40685d67a3  call 0x00007A40684BE9C0
00007a40685d67a8  jmp 0x00007A40685D5962
00007a40685d67ad  call 0x00007A40684BD750
00007a40685d67b2  jmp 0x00007A40685D596C
00007a40685d67b7  sub rsp, 0x08
00007a40685d67bb  push rax
00007a40685d67bc  push rcx
00007a40685d67bd  push rdx
00007a40685d67be  push rdi
00007a40685d67bf  push rsi
00007a40685d67c0  push r8
00007a40685d67c2  push r9
00007a40685d67c4  push r10
00007a40685d67c6  push r11
00007a40685d67c8  sub rsp, 0xF0
00007a40685d67cf  vmovaps [rsp], xmm0
00007a40685d67d4  vmovaps [rsp+0x10], xmm1
00007a40685d67da  vmovaps [rsp+0x20], xmm2
00007a40685d67e0  vmovaps [rsp+0x30], xmm3
00007a40685d67e6  vmovaps [rsp+0x40], xmm4
00007a40685d67ec  vmovaps [rsp+0x50], xmm5
00007a40685d67f2  vmovaps [rsp+0x60], xmm6
00007a40685d67f8  vmovaps [rsp+0x70], xmm7
00007a40685d67fe  vmovaps [rsp+0x80], xmm9
00007a40685d6807  vmovaps [rsp+0x90], xmm10
00007a40685d6810  vmovaps [rsp+0xA0], xmm11
00007a40685d6819  vmovaps [rsp+0xB0], xmm12
00007a40685d6822  vmovaps [rsp+0xC0], xmm13
00007a40685d682b  vmovaps [rsp+0xD0], xmm14
00007a40685d6834  vmovaps [rsp+0xE0], xmm15
00007a40685d683d  sub rsp, 0x30
00007a40685d6841  movaps [rsp], xmm8
00007a40685d6846  movaps [rsp+0x10], xmm12
00007a40685d684c  movaps [rsp+0x20], xmm15
00007a40685d6852  lea rdi, [rsp]
00007a40685d6856  mov esi, 0x00
00007a40685d685b  mov rax, 0x56F679577530
00007a40685d6865  call rax
00007a40685d6867  movaps xmm8, [rsp]
00007a40685d686c  add rsp, 0x30
00007a40685d6870  vmovaps xmm0, [rsp]
00007a40685d6875  vmovaps xmm1, [rsp+0x10]
00007a40685d687b  vmovaps xmm2, [rsp+0x20]
00007a40685d6881  vmovaps xmm3, [rsp+0x30]
00007a40685d6887  vmovaps xmm4, [rsp+0x40]
00007a40685d688d  vmovaps xmm5, [rsp+0x50]
00007a40685d6893  vmovaps xmm6, [rsp+0x60]
00007a40685d6899  vmovaps xmm7, [rsp+0x70]
00007a40685d689f  vmovaps xmm9, [rsp+0x80]
00007a40685d68a8  vmovaps xmm10, [rsp+0x90]
00007a40685d68b1  vmovaps xmm11, [rsp+0xA0]
00007a40685d68ba  vmovaps xmm12, [rsp+0xB0]
00007a40685d68c3  vmovaps xmm13, [rsp+0xC0]
00007a40685d68cc  vmovaps xmm14, [rsp+0xD0]
00007a40685d68d5  vmovaps xmm15, [rsp+0xE0]
00007a40685d68de  add rsp, 0xF0
00007a40685d68e5  pop r11
00007a40685d68e7  pop r10
00007a40685d68e9  pop r9
00007a40685d68eb  pop r8
00007a40685d68ed  pop rsi
00007a40685d68ee  pop rdi
00007a40685d68ef  pop rdx
00007a40685d68f0  pop rcx
00007a40685d68f1  pop rax
00007a40685d68f2  add rsp, 0x08
00007a40685d68f6  jmp 0x00007A40685D599A
00007a40685d68fb  sub rsp, 0x08
00007a40685d68ff  push rax
00007a40685d6900  push rcx
00007a40685d6901  push rdx
00007a40685d6902  push rdi
00007a40685d6903  push rsi
00007a40685d6904  push r8
00007a40685d6906  push r9
00007a40685d6908  push r10
00007a40685d690a  push r11
00007a40685d690c  sub rsp, 0xF0
00007a40685d6913  vmovaps [rsp], xmm0
00007a40685d6918  vmovaps [rsp+0x10], xmm1
00007a40685d691e  vmovaps [rsp+0x20], xmm2
00007a40685d6924  vmovaps [rsp+0x30], xmm3
00007a40685d692a  vmovaps [rsp+0x40], xmm4
00007a40685d6930  vmovaps [rsp+0x50], xmm5
00007a40685d6936  vmovaps [rsp+0x60], xmm6
00007a40685d693c  vmovaps [rsp+0x70], xmm8
00007a40685d6942  vmovaps [rsp+0x80], xmm9
00007a40685d694b  vmovaps [rsp+0x90], xmm10
00007a40685d6954  vmovaps [rsp+0xA0], xmm11
00007a40685d695d  vmovaps [rsp+0xB0], xmm12
00007a40685d6966  vmovaps [rsp+0xC0], xmm13
00007a40685d696f  vmovaps [rsp+0xD0], xmm14
00007a40685d6978  vmovaps [rsp+0xE0], xmm15
00007a40685d6981  sub rsp, 0x30
00007a40685d6985  movaps [rsp], xmm7
00007a40685d6989  movaps [rsp+0x10], xmm9
00007a40685d698f  movaps [rsp+0x20], xmm15
00007a40685d6995  lea rdi, [rsp]
00007a40685d6999  mov esi, 0x00
00007a40685d699e  mov rax, 0x56F679577530
00007a40685d69a8  call rax
00007a40685d69aa  movaps xmm7, [rsp]
00007a40685d69ae  add rsp, 0x30
00007a40685d69b2  vmovaps xmm0, [rsp]
00007a40685d69b7  vmovaps xmm1, [rsp+0x10]
00007a40685d69bd  vmovaps xmm2, [rsp+0x20]
00007a40685d69c3  vmovaps xmm3, [rsp+0x30]
00007a40685d69c9  vmovaps xmm4, [rsp+0x40]
00007a40685d69cf  vmovaps xmm5, [rsp+0x50]
00007a40685d69d5  vmovaps xmm6, [rsp+0x60]
00007a40685d69db  vmovaps xmm8, [rsp+0x70]
00007a40685d69e1  vmovaps xmm9, [rsp+0x80]
00007a40685d69ea  vmovaps xmm10, [rsp+0x90]
00007a40685d69f3  vmovaps xmm11, [rsp+0xA0]
00007a40685d69fc  vmovaps xmm12, [rsp+0xB0]
00007a40685d6a05  vmovaps xmm13, [rsp+0xC0]
00007a40685d6a0e  vmovaps xmm14, [rsp+0xD0]
00007a40685d6a17  vmovaps xmm15, [rsp+0xE0]
00007a40685d6a20  add rsp, 0xF0
00007a40685d6a27  pop r11
00007a40685d6a29  pop r10
00007a40685d6a2b  pop r9
00007a40685d6a2d  pop r8
00007a40685d6a2f  pop rsi
00007a40685d6a30  pop rdi
00007a40685d6a31  pop rdx
00007a40685d6a32  pop rcx
00007a40685d6a33  pop rax
00007a40685d6a34  add rsp, 0x08
00007a40685d6a38  jmp 0x00007A40685D59C8
00007a40685d6a3d  sub rsp, 0x08
00007a40685d6a41  push rax
00007a40685d6a42  push rcx
00007a40685d6a43  push rdx
00007a40685d6a44  push rdi
00007a40685d6a45  push rsi
00007a40685d6a46  push r8
00007a40685d6a48  push r9
00007a40685d6a4a  push r10
00007a40685d6a4c  push r11
00007a40685d6a4e  sub rsp, 0xF0
00007a40685d6a55  vmovaps [rsp], xmm0
00007a40685d6a5a  vmovaps [rsp+0x10], xmm1
00007a40685d6a60  vmovaps [rsp+0x20], xmm2
00007a40685d6a66  vmovaps [rsp+0x30], xmm3
00007a40685d6a6c  vmovaps [rsp+0x40], xmm4
00007a40685d6a72  vmovaps [rsp+0x50], xmm5
00007a40685d6a78  vmovaps [rsp+0x60], xmm6
00007a40685d6a7e  vmovaps [rsp+0x70], xmm7
00007a40685d6a84  vmovaps [rsp+0x80], xmm8
00007a40685d6a8d  vmovaps [rsp+0x90], xmm10
00007a40685d6a96  vmovaps [rsp+0xA0], xmm11
00007a40685d6a9f  vmovaps [rsp+0xB0], xmm12
00007a40685d6aa8  vmovaps [rsp+0xC0], xmm13
00007a40685d6ab1  vmovaps [rsp+0xD0], xmm14
00007a40685d6aba  vmovaps [rsp+0xE0], xmm15
00007a40685d6ac3  sub rsp, 0x30
00007a40685d6ac7  movaps [rsp], xmm9
00007a40685d6acc  movaps [rsp+0x10], xmm12
00007a40685d6ad2  movaps [rsp+0x20], xmm10
00007a40685d6ad8  lea rdi, [rsp]
00007a40685d6adc  mov esi, 0x00
00007a40685d6ae1  mov rax, 0x56F679577530
00007a40685d6aeb  call rax
00007a40685d6aed  movaps xmm9, [rsp]
00007a40685d6af2  add rsp, 0x30
00007a40685d6af6  vmovaps xmm0, [rsp]
00007a40685d6afb  vmovaps xmm1, [rsp+0x10]
00007a40685d6b01  vmovaps xmm2, [rsp+0x20]
00007a40685d6b07  vmovaps xmm3, [rsp+0x30]
00007a40685d6b0d  vmovaps xmm4, [rsp+0x40]
00007a40685d6b13  vmovaps xmm5, [rsp+0x50]
00007a40685d6b19  vmovaps xmm6, [rsp+0x60]
00007a40685d6b1f  vmovaps xmm7, [rsp+0x70]
00007a40685d6b25  vmovaps xmm8, [rsp+0x80]
00007a40685d6b2e  vmovaps xmm10, [rsp+0x90]
00007a40685d6b37  vmovaps xmm11, [rsp+0xA0]
00007a40685d6b40  vmovaps xmm12, [rsp+0xB0]
00007a40685d6b49  vmovaps xmm13, [rsp+0xC0]
00007a40685d6b52  vmovaps xmm14, [rsp+0xD0]
00007a40685d6b5b  vmovaps xmm15, [rsp+0xE0]
00007a40685d6b64  add rsp, 0xF0
00007a40685d6b6b  pop r11
00007a40685d6b6d  pop r10
00007a40685d6b6f  pop r9
00007a40685d6b71  pop r8
00007a40685d6b73  pop rsi
00007a40685d6b74  pop rdi
00007a40685d6b75  pop rdx
00007a40685d6b76  pop rcx
00007a40685d6b77  pop rax
00007a40685d6b78  add rsp, 0x08
00007a40685d6b7c  jmp 0x00007A40685D59EC
00007a40685d6b81  sub rsp, 0x08
00007a40685d6b85  push rax
00007a40685d6b86  push rcx
00007a40685d6b87  push rdx
00007a40685d6b88  push rdi
00007a40685d6b89  push rsi
00007a40685d6b8a  push r8
00007a40685d6b8c  push r9
00007a40685d6b8e  push r10
00007a40685d6b90  push r11
00007a40685d6b92  sub rsp, 0xF0
00007a40685d6b99  vmovaps [rsp], xmm0
00007a40685d6b9e  vmovaps [rsp+0x10], xmm1
00007a40685d6ba4  vmovaps [rsp+0x20], xmm2
00007a40685d6baa  vmovaps [rsp+0x30], xmm3
00007a40685d6bb0  vmovaps [rsp+0x40], xmm4
00007a40685d6bb6  vmovaps [rsp+0x50], xmm5
00007a40685d6bbc  vmovaps [rsp+0x60], xmm6
00007a40685d6bc2  vmovaps [rsp+0x70], xmm7
00007a40685d6bc8  vmovaps [rsp+0x80], xmm8
00007a40685d6bd1  vmovaps [rsp+0x90], xmm9
00007a40685d6bda  vmovaps [rsp+0xA0], xmm11
00007a40685d6be3  vmovaps [rsp+0xB0], xmm12
00007a40685d6bec  vmovaps [rsp+0xC0], xmm13
00007a40685d6bf5  vmovaps [rsp+0xD0], xmm14
00007a40685d6bfe  vmovaps [rsp+0xE0], xmm15
00007a40685d6c07  sub rsp, 0x30
00007a40685d6c0b  movaps [rsp], xmm10
00007a40685d6c10  movaps [rsp+0x10], xmm12
00007a40685d6c16  movaps [rsp+0x20], xmm11
00007a40685d6c1c  lea rdi, [rsp]
00007a40685d6c20  mov esi, 0x00
00007a40685d6c25  mov rax, 0x56F679577530
00007a40685d6c2f  call rax
00007a40685d6c31  movaps xmm10, [rsp]
00007a40685d6c36  add rsp, 0x30
00007a40685d6c3a  vmovaps xmm0, [rsp]
00007a40685d6c3f  vmovaps xmm1, [rsp+0x10]
00007a40685d6c45  vmovaps xmm2, [rsp+0x20]
00007a40685d6c4b  vmovaps xmm3, [rsp+0x30]
00007a40685d6c51  vmovaps xmm4, [rsp+0x40]
00007a40685d6c57  vmovaps xmm5, [rsp+0x50]
00007a40685d6c5d  vmovaps xmm6, [rsp+0x60]
00007a40685d6c63  vmovaps xmm7, [rsp+0x70]
00007a40685d6c69  vmovaps xmm8, [rsp+0x80]
00007a40685d6c72  vmovaps xmm9, [rsp+0x90]
00007a40685d6c7b  vmovaps xmm11, [rsp+0xA0]
00007a40685d6c84  vmovaps xmm12, [rsp+0xB0]
00007a40685d6c8d  vmovaps xmm13, [rsp+0xC0]
00007a40685d6c96  vmovaps xmm14, [rsp+0xD0]
00007a40685d6c9f  vmovaps xmm15, [rsp+0xE0]
00007a40685d6ca8  add rsp, 0xF0
00007a40685d6caf  pop r11
00007a40685d6cb1  pop r10
00007a40685d6cb3  pop r9
00007a40685d6cb5  pop r8
00007a40685d6cb7  pop rsi
00007a40685d6cb8  pop rdi
00007a40685d6cb9  pop rdx
00007a40685d6cba  pop rcx
00007a40685d6cbb  pop rax
00007a40685d6cbc  add rsp, 0x08
00007a40685d6cc0  jmp 0x00007A40685D5A06
00007a40685d6cc5  sub rsp, 0x08
00007a40685d6cc9  push rax
00007a40685d6cca  push rcx
00007a40685d6ccb  push rdx
00007a40685d6ccc  push rdi
00007a40685d6ccd  push rsi
00007a40685d6cce  push r8
00007a40685d6cd0  push r9
00007a40685d6cd2  push r10
00007a40685d6cd4  push r11
00007a40685d6cd6  sub rsp, 0xF0
00007a40685d6cdd  vmovaps [rsp], xmm0
00007a40685d6ce2  vmovaps [rsp+0x10], xmm1
00007a40685d6ce8  vmovaps [rsp+0x20], xmm2
00007a40685d6cee  vmovaps [rsp+0x30], xmm3
00007a40685d6cf4  vmovaps [rsp+0x40], xmm4
00007a40685d6cfa  vmovaps [rsp+0x50], xmm5
00007a40685d6d00  vmovaps [rsp+0x60], xmm7
00007a40685d6d06  vmovaps [rsp+0x70], xmm8
00007a40685d6d0c  vmovaps [rsp+0x80], xmm9
00007a40685d6d15  vmovaps [rsp+0x90], xmm10
00007a40685d6d1e  vmovaps [rsp+0xA0], xmm11
00007a40685d6d27  vmovaps [rsp+0xB0], xmm12
00007a40685d6d30  vmovaps [rsp+0xC0], xmm13
00007a40685d6d39  vmovaps [rsp+0xD0], xmm14
00007a40685d6d42  vmovaps [rsp+0xE0], xmm15
00007a40685d6d4b  sub rsp, 0x30
00007a40685d6d4f  movaps [rsp], xmm6
00007a40685d6d53  movaps [rsp+0x10], xmm12
00007a40685d6d59  movaps [rsp+0x20], xmm11
00007a40685d6d5f  lea rdi, [rsp]
00007a40685d6d63  mov esi, 0x00
00007a40685d6d68  mov rax, 0x56F679577530
00007a40685d6d72  call rax
00007a40685d6d74  movaps xmm6, [rsp]
00007a40685d6d78  add rsp, 0x30
00007a40685d6d7c  vmovaps xmm0, [rsp]
00007a40685d6d81  vmovaps xmm1, [rsp+0x10]
00007a40685d6d87  vmovaps xmm2, [rsp+0x20]
00007a40685d6d8d  vmovaps xmm3, [rsp+0x30]
00007a40685d6d93  vmovaps xmm4, [rsp+0x40]
00007a40685d6d99  vmovaps xmm5, [rsp+0x50]
00007a40685d6d9f  vmovaps xmm7, [rsp+0x60]
00007a40685d6da5  vmovaps xmm8, [rsp+0x70]
00007a40685d6dab  vmovaps xmm9, [rsp+0x80]
00007a40685d6db4  vmovaps xmm10, [rsp+0x90]
00007a40685d6dbd  vmovaps xmm11, [rsp+0xA0]
00007a40685d6dc6  vmovaps xmm12, [rsp+0xB0]
00007a40685d6dcf  vmovaps xmm13, [rsp+0xC0]
00007a40685d6dd8  vmovaps xmm14, [rsp+0xD0]
00007a40685d6de1  vmovaps xmm15, [rsp+0xE0]
00007a40685d6dea  add rsp, 0xF0
00007a40685d6df1  pop r11
00007a40685d6df3  pop r10
00007a40685d6df5  pop r9
00007a40685d6df7  pop r8
00007a40685d6df9  pop rsi
00007a40685d6dfa  pop rdi
00007a40685d6dfb  pop rdx
00007a40685d6dfc  pop rcx
00007a40685d6dfd  pop rax
00007a40685d6dfe  add rsp, 0x08
00007a40685d6e02  jmp 0x00007A40685D5A27
00007a40685d6e07  sub rsp, 0x08
00007a40685d6e0b  push rax
00007a40685d6e0c  push rcx
00007a40685d6e0d  push rdx
00007a40685d6e0e  push rdi
00007a40685d6e0f  push rsi
00007a40685d6e10  push r8
00007a40685d6e12  push r9
00007a40685d6e14  push r10
00007a40685d6e16  push r11
00007a40685d6e18  sub rsp, 0xF0
00007a40685d6e1f  vmovaps [rsp], xmm0
00007a40685d6e24  vmovaps [rsp+0x10], xmm1
00007a40685d6e2a  vmovaps [rsp+0x20], xmm2
00007a40685d6e30  vmovaps [rsp+0x30], xmm4
00007a40685d6e36  vmovaps [rsp+0x40], xmm5
00007a40685d6e3c  vmovaps [rsp+0x50], xmm6
00007a40685d6e42  vmovaps [rsp+0x60], xmm7
00007a40685d6e48  vmovaps [rsp+0x70], xmm8
00007a40685d6e4e  vmovaps [rsp+0x80], xmm9
00007a40685d6e57  vmovaps [rsp+0x90], xmm10
00007a40685d6e60  vmovaps [rsp+0xA0], xmm11
00007a40685d6e69  vmovaps [rsp+0xB0], xmm12
00007a40685d6e72  vmovaps [rsp+0xC0], xmm13
00007a40685d6e7b  vmovaps [rsp+0xD0], xmm14
00007a40685d6e84  vmovaps [rsp+0xE0], xmm15
00007a40685d6e8d  sub rsp, 0x30
00007a40685d6e91  movaps [rsp], xmm3
00007a40685d6e95  movaps [rsp+0x10], xmm5
00007a40685d6e9a  movaps [rsp+0x20], xmm4
00007a40685d6e9f  lea rdi, [rsp]
00007a40685d6ea3  mov esi, 0x00
00007a40685d6ea8  mov rax, 0x56F679577530
00007a40685d6eb2  call rax
00007a40685d6eb4  movaps xmm3, [rsp]
00007a40685d6eb8  add rsp, 0x30
00007a40685d6ebc  vmovaps xmm0, [rsp]
00007a40685d6ec1  vmovaps xmm1, [rsp+0x10]
00007a40685d6ec7  vmovaps xmm2, [rsp+0x20]
00007a40685d6ecd  vmovaps xmm4, [rsp+0x30]
00007a40685d6ed3  vmovaps xmm5, [rsp+0x40]
00007a40685d6ed9  vmovaps xmm6, [rsp+0x50]
00007a40685d6edf  vmovaps xmm7, [rsp+0x60]
00007a40685d6ee5  vmovaps xmm8, [rsp+0x70]
00007a40685d6eeb  vmovaps xmm9, [rsp+0x80]
00007a40685d6ef4  vmovaps xmm10, [rsp+0x90]
00007a40685d6efd  vmovaps xmm11, [rsp+0xA0]
00007a40685d6f06  vmovaps xmm12, [rsp+0xB0]
00007a40685d6f0f  vmovaps xmm13, [rsp+0xC0]
00007a40685d6f18  vmovaps xmm14, [rsp+0xD0]
00007a40685d6f21  vmovaps xmm15, [rsp+0xE0]
00007a40685d6f2a  add rsp, 0xF0
00007a40685d6f31  pop r11
00007a40685d6f33  pop r10
00007a40685d6f35  pop r9
00007a40685d6f37  pop r8
00007a40685d6f39  pop rsi
00007a40685d6f3a  pop rdi
00007a40685d6f3b  pop rdx
00007a40685d6f3c  pop rcx
00007a40685d6f3d  pop rax
00007a40685d6f3e  add rsp, 0x08
00007a40685d6f42  jmp 0x00007A40685D5A88
00007a40685d6f47  sub rsp, 0x08
00007a40685d6f4b  push rax
00007a40685d6f4c  push rcx
00007a40685d6f4d  push rdx
00007a40685d6f4e  push rdi
00007a40685d6f4f  push rsi
00007a40685d6f50  push r8
00007a40685d6f52  push r9
00007a40685d6f54  push r10
00007a40685d6f56  push r11
00007a40685d6f58  sub rsp, 0xF0
00007a40685d6f5f  vmovaps [rsp], xmm0
00007a40685d6f64  vmovaps [rsp+0x10], xmm1
00007a40685d6f6a  vmovaps [rsp+0x20], xmm2
00007a40685d6f70  vmovaps [rsp+0x30], xmm3
00007a40685d6f76  vmovaps [rsp+0x40], xmm4
00007a40685d6f7c  vmovaps [rsp+0x50], xmm6
00007a40685d6f82  vmovaps [rsp+0x60], xmm7
00007a40685d6f88  vmovaps [rsp+0x70], xmm8
00007a40685d6f8e  vmovaps [rsp+0x80], xmm9
00007a40685d6f97  vmovaps [rsp+0x90], xmm10
00007a40685d6fa0  vmovaps [rsp+0xA0], xmm11
00007a40685d6fa9  vmovaps [rsp+0xB0], xmm12
00007a40685d6fb2  vmovaps [rsp+0xC0], xmm13
00007a40685d6fbb  vmovaps [rsp+0xD0], xmm14
00007a40685d6fc4  vmovaps [rsp+0xE0], xmm15
00007a40685d6fcd  sub rsp, 0x30
00007a40685d6fd1  movaps [rsp], xmm5
00007a40685d6fd5  movaps [rsp+0x10], xmm8
00007a40685d6fdb  movaps [rsp+0x20], xmm15
00007a40685d6fe1  lea rdi, [rsp]
00007a40685d6fe5  mov esi, 0x00
00007a40685d6fea  mov rax, 0x56F679577530
00007a40685d6ff4  call rax
00007a40685d6ff6  movaps xmm5, [rsp]
00007a40685d6ffa  add rsp, 0x30
00007a40685d6ffe  vmovaps xmm0, [rsp]
00007a40685d7003  vmovaps xmm1, [rsp+0x10]
00007a40685d7009  vmovaps xmm2, [rsp+0x20]
00007a40685d700f  vmovaps xmm3, [rsp+0x30]
00007a40685d7015  vmovaps xmm4, [rsp+0x40]
00007a40685d701b  vmovaps xmm6, [rsp+0x50]
00007a40685d7021  vmovaps xmm7, [rsp+0x60]
00007a40685d7027  vmovaps xmm8, [rsp+0x70]
00007a40685d702d  vmovaps xmm9, [rsp+0x80]
00007a40685d7036  vmovaps xmm10, [rsp+0x90]
00007a40685d703f  vmovaps xmm11, [rsp+0xA0]
00007a40685d7048  vmovaps xmm12, [rsp+0xB0]
00007a40685d7051  vmovaps xmm13, [rsp+0xC0]
00007a40685d705a  vmovaps xmm14, [rsp+0xD0]
00007a40685d7063  vmovaps xmm15, [rsp+0xE0]
00007a40685d706c  add rsp, 0xF0
00007a40685d7073  pop r11
00007a40685d7075  pop r10
00007a40685d7077  pop r9
00007a40685d7079  pop r8
00007a40685d707b  pop rsi
00007a40685d707c  pop rdi
00007a40685d707d  pop rdx
00007a40685d707e  pop rcx
00007a40685d707f  pop rax
00007a40685d7080  add rsp, 0x08
00007a40685d7084  jmp 0x00007A40685D5AC0
00007a40685d7089  sub rsp, 0x08
00007a40685d708d  push rax
00007a40685d708e  push rcx
00007a40685d708f  push rdx
00007a40685d7090  push rdi
00007a40685d7091  push rsi
00007a40685d7092  push r8
00007a40685d7094  push r9
00007a40685d7096  push r10
00007a40685d7098  push r11
00007a40685d709a  sub rsp, 0xF0
00007a40685d70a1  vmovaps [rsp], xmm0
00007a40685d70a6  vmovaps [rsp+0x10], xmm1
00007a40685d70ac  vmovaps [rsp+0x20], xmm2
00007a40685d70b2  vmovaps [rsp+0x30], xmm3
00007a40685d70b8  vmovaps [rsp+0x40], xmm5
00007a40685d70be  vmovaps [rsp+0x50], xmm6
00007a40685d70c4  vmovaps [rsp+0x60], xmm7
00007a40685d70ca  vmovaps [rsp+0x70], xmm8
00007a40685d70d0  vmovaps [rsp+0x80], xmm9
00007a40685d70d9  vmovaps [rsp+0x90], xmm10
00007a40685d70e2  vmovaps [rsp+0xA0], xmm11
00007a40685d70eb  vmovaps [rsp+0xB0], xmm12
00007a40685d70f4  vmovaps [rsp+0xC0], xmm13
00007a40685d70fd  vmovaps [rsp+0xD0], xmm14
00007a40685d7106  vmovaps [rsp+0xE0], xmm15
00007a40685d710f  sub rsp, 0x30
00007a40685d7113  movaps [rsp], xmm4
00007a40685d7117  movaps [rsp+0x10], xmm9
00007a40685d711d  movaps [rsp+0x20], xmm8
00007a40685d7123  lea rdi, [rsp]
00007a40685d7127  mov esi, 0x00
00007a40685d712c  mov rax, 0x56F679577530
00007a40685d7136  call rax
00007a40685d7138  movaps xmm4, [rsp]
00007a40685d713c  add rsp, 0x30
00007a40685d7140  vmovaps xmm0, [rsp]
00007a40685d7145  vmovaps xmm1, [rsp+0x10]
00007a40685d714b  vmovaps xmm2, [rsp+0x20]
00007a40685d7151  vmovaps xmm3, [rsp+0x30]
00007a40685d7157  vmovaps xmm5, [rsp+0x40]
00007a40685d715d  vmovaps xmm6, [rsp+0x50]
00007a40685d7163  vmovaps xmm7, [rsp+0x60]
00007a40685d7169  vmovaps xmm8, [rsp+0x70]
00007a40685d716f  vmovaps xmm9, [rsp+0x80]
00007a40685d7178  vmovaps xmm10, [rsp+0x90]
00007a40685d7181  vmovaps xmm11, [rsp+0xA0]
00007a40685d718a  vmovaps xmm12, [rsp+0xB0]
00007a40685d7193  vmovaps xmm13, [rsp+0xC0]
00007a40685d719c  vmovaps xmm14, [rsp+0xD0]
00007a40685d71a5  vmovaps xmm15, [rsp+0xE0]
00007a40685d71ae  add rsp, 0xF0
00007a40685d71b5  pop r11
00007a40685d71b7  pop r10
00007a40685d71b9  pop r9
00007a40685d71bb  pop r8
00007a40685d71bd  pop rsi
00007a40685d71be  pop rdi
00007a40685d71bf  pop rdx
00007a40685d71c0  pop rcx
00007a40685d71c1  pop rax
00007a40685d71c2  add rsp, 0x08
00007a40685d71c6  jmp 0x00007A40685D5AE1
00007a40685d71cb  sub rsp, 0x08
00007a40685d71cf  push rax
00007a40685d71d0  push rcx
00007a40685d71d1  push rdx
00007a40685d71d2  push rdi
00007a40685d71d3  push rsi
00007a40685d71d4  push r8
00007a40685d71d6  push r9
00007a40685d71d8  push r10
00007a40685d71da  push r11
00007a40685d71dc  sub rsp, 0xF0
00007a40685d71e3  vmovaps [rsp], xmm0
00007a40685d71e8  vmovaps [rsp+0x10], xmm1
00007a40685d71ee  vmovaps [rsp+0x20], xmm2
00007a40685d71f4  vmovaps [rsp+0x30], xmm3
00007a40685d71fa  vmovaps [rsp+0x40], xmm4
00007a40685d7200  vmovaps [rsp+0x50], xmm5
00007a40685d7206  vmovaps [rsp+0x60], xmm6
00007a40685d720c  vmovaps [rsp+0x70], xmm7
00007a40685d7212  vmovaps [rsp+0x80], xmm8
00007a40685d721b  vmovaps [rsp+0x90], xmm10
00007a40685d7224  vmovaps [rsp+0xA0], xmm11
00007a40685d722d  vmovaps [rsp+0xB0], xmm12
00007a40685d7236  vmovaps [rsp+0xC0], xmm13
00007a40685d723f  vmovaps [rsp+0xD0], xmm14
00007a40685d7248  vmovaps [rsp+0xE0], xmm15
00007a40685d7251  sub rsp, 0x30
00007a40685d7255  movaps [rsp], xmm9
00007a40685d725a  movaps [rsp+0x10], xmm10
00007a40685d7260  movaps [rsp+0x20], xmm8
00007a40685d7266  lea rdi, [rsp]
00007a40685d726a  mov esi, 0x00
00007a40685d726f  mov rax, 0x56F679577530
00007a40685d7279  call rax
00007a40685d727b  movaps xmm9, [rsp]
00007a40685d7280  add rsp, 0x30
00007a40685d7284  vmovaps xmm0, [rsp]
00007a40685d7289  vmovaps xmm1, [rsp+0x10]
00007a40685d728f  vmovaps xmm2, [rsp+0x20]
00007a40685d7295  vmovaps xmm3, [rsp+0x30]
00007a40685d729b  vmovaps xmm4, [rsp+0x40]
00007a40685d72a1  vmovaps xmm5, [rsp+0x50]
00007a40685d72a7  vmovaps xmm6, [rsp+0x60]
00007a40685d72ad  vmovaps xmm7, [rsp+0x70]
00007a40685d72b3  vmovaps xmm8, [rsp+0x80]
00007a40685d72bc  vmovaps xmm10, [rsp+0x90]
00007a40685d72c5  vmovaps xmm11, [rsp+0xA0]
00007a40685d72ce  vmovaps xmm12, [rsp+0xB0]
00007a40685d72d7  vmovaps xmm13, [rsp+0xC0]
00007a40685d72e0  vmovaps xmm14, [rsp+0xD0]
00007a40685d72e9  vmovaps xmm15, [rsp+0xE0]
00007a40685d72f2  add rsp, 0xF0
00007a40685d72f9  pop r11
00007a40685d72fb  pop r10
00007a40685d72fd  pop r9
00007a40685d72ff  pop r8
00007a40685d7301  pop rsi
00007a40685d7302  pop rdi
00007a40685d7303  pop rdx
00007a40685d7304  pop rcx
00007a40685d7305  pop rax
00007a40685d7306  add rsp, 0x08
00007a40685d730a  jmp 0x00007A40685D5AFB
00007a40685d730f  call 0x00007A40684D64F0
00007a40685d7314  jmp 0x00007A40685D5C15
00007a40685d7319  call 0x00007A40684D64F0
00007a40685d731e  jmp 0x00007A40685D5C2B
00007a40685d7323  sub rsp, 0x08
00007a40685d7327  push rax
00007a40685d7328  push rcx
00007a40685d7329  push rdx
00007a40685d732a  push rdi
00007a40685d732b  push rsi
00007a40685d732c  push r8
00007a40685d732e  push r9
00007a40685d7330  push r10
00007a40685d7332  push r11
00007a40685d7334  sub rsp, 0xF0
00007a40685d733b  vmovaps [rsp], xmm0
00007a40685d7340  vmovaps [rsp+0x10], xmm2
00007a40685d7346  vmovaps [rsp+0x20], xmm3
00007a40685d734c  vmovaps [rsp+0x30], xmm4
00007a40685d7352  vmovaps [rsp+0x40], xmm5
00007a40685d7358  vmovaps [rsp+0x50], xmm6
00007a40685d735e  vmovaps [rsp+0x60], xmm7
00007a40685d7364  vmovaps [rsp+0x70], xmm8
00007a40685d736a  vmovaps [rsp+0x80], xmm9
00007a40685d7373  vmovaps [rsp+0x90], xmm10
00007a40685d737c  vmovaps [rsp+0xA0], xmm11
00007a40685d7385  vmovaps [rsp+0xB0], xmm12
00007a40685d738e  vmovaps [rsp+0xC0], xmm13
00007a40685d7397  vmovaps [rsp+0xD0], xmm14
00007a40685d73a0  vmovaps [rsp+0xE0], xmm15
00007a40685d73a9  sub rsp, 0x30
00007a40685d73ad  movaps [rsp], xmm1
00007a40685d73b1  movaps [rsp+0x10], xmm6
00007a40685d73b6  movaps [rsp+0x20], xmm15
00007a40685d73bc  lea rdi, [rsp]
00007a40685d73c0  mov esi, 0x00
00007a40685d73c5  mov rax, 0x56F679577530
00007a40685d73cf  call rax
00007a40685d73d1  movaps xmm1, [rsp]
00007a40685d73d5  add rsp, 0x30
00007a40685d73d9  vmovaps xmm0, [rsp]
00007a40685d73de  vmovaps xmm2, [rsp+0x10]
00007a40685d73e4  vmovaps xmm3, [rsp+0x20]
00007a40685d73ea  vmovaps xmm4, [rsp+0x30]
00007a40685d73f0  vmovaps xmm5, [rsp+0x40]
00007a40685d73f6  vmovaps xmm6, [rsp+0x50]
00007a40685d73fc  vmovaps xmm7, [rsp+0x60]
00007a40685d7402  vmovaps xmm8, [rsp+0x70]
00007a40685d7408  vmovaps xmm9, [rsp+0x80]
00007a40685d7411  vmovaps xmm10, [rsp+0x90]
00007a40685d741a  vmovaps xmm11, [rsp+0xA0]
00007a40685d7423  vmovaps xmm12, [rsp+0xB0]
00007a40685d742c  vmovaps xmm13, [rsp+0xC0]
00007a40685d7435  vmovaps xmm14, [rsp+0xD0]
00007a40685d743e  vmovaps xmm15, [rsp+0xE0]
00007a40685d7447  add rsp, 0xF0
00007a40685d744e  pop r11
00007a40685d7450  pop r10
00007a40685d7452  pop r9
00007a40685d7454  pop r8
00007a40685d7456  pop rsi
00007a40685d7457  pop rdi
00007a40685d7458  pop rdx
00007a40685d7459  pop rcx
00007a40685d745a  pop rax
00007a40685d745b  add rsp, 0x08
00007a40685d745f  jmp 0x00007A40685D5C68
00007a40685d7464  call 0x00007A40684E5820
00007a40685d7469  jmp 0x00007A40685D5C75
00007a40685d746e  sub rsp, 0x08
00007a40685d7472  push rax
00007a40685d7473  push rcx
00007a40685d7474  push rdx
00007a40685d7475  push rdi
00007a40685d7476  push rsi
00007a40685d7477  push r8
00007a40685d7479  push r9
00007a40685d747b  push r10
00007a40685d747d  push r11
00007a40685d747f  sub rsp, 0xF0
00007a40685d7486  vmovaps [rsp], xmm0
00007a40685d748b  vmovaps [rsp+0x10], xmm1
00007a40685d7491  vmovaps [rsp+0x20], xmm2
00007a40685d7497  vmovaps [rsp+0x30], xmm3
00007a40685d749d  vmovaps [rsp+0x40], xmm4
00007a40685d74a3  vmovaps [rsp+0x50], xmm5
00007a40685d74a9  vmovaps [rsp+0x60], xmm6
00007a40685d74af  vmovaps [rsp+0x70], xmm7
00007a40685d74b5  vmovaps [rsp+0x80], xmm8
00007a40685d74be  vmovaps [rsp+0x90], xmm9
00007a40685d74c7  vmovaps [rsp+0xA0], xmm10
00007a40685d74d0  vmovaps [rsp+0xB0], xmm11
00007a40685d74d9  vmovaps [rsp+0xC0], xmm12
00007a40685d74e2  vmovaps [rsp+0xD0], xmm13
00007a40685d74eb  vmovaps [rsp+0xE0], xmm15
00007a40685d74f4  sub rsp, 0x30
00007a40685d74f8  movaps [rsp], xmm14
00007a40685d74fd  movaps [rsp+0x10], xmm4
00007a40685d7502  movaps [rsp+0x20], xmm3
00007a40685d7507  lea rdi, [rsp]
00007a40685d750b  mov esi, 0x00
00007a40685d7510  mov rax, 0x56F679577530
00007a40685d751a  call rax
00007a40685d751c  movaps xmm14, [rsp]
00007a40685d7521  add rsp, 0x30
00007a40685d7525  vmovaps xmm0, [rsp]
00007a40685d752a  vmovaps xmm1, [rsp+0x10]
00007a40685d7530  vmovaps xmm2, [rsp+0x20]
00007a40685d7536  vmovaps xmm3, [rsp+0x30]
00007a40685d753c  vmovaps xmm4, [rsp+0x40]
00007a40685d7542  vmovaps xmm5, [rsp+0x50]
00007a40685d7548  vmovaps xmm6, [rsp+0x60]
00007a40685d754e  vmovaps xmm7, [rsp+0x70]
00007a40685d7554  vmovaps xmm8, [rsp+0x80]
00007a40685d755d  vmovaps xmm9, [rsp+0x90]
00007a40685d7566  vmovaps xmm10, [rsp+0xA0]
00007a40685d756f  vmovaps xmm11, [rsp+0xB0]
00007a40685d7578  vmovaps xmm12, [rsp+0xC0]
00007a40685d7581  vmovaps xmm13, [rsp+0xD0]
00007a40685d758a  vmovaps xmm15, [rsp+0xE0]
00007a40685d7593  add rsp, 0xF0
00007a40685d759a  pop r11
00007a40685d759c  pop r10
00007a40685d759e  pop r9
00007a40685d75a0  pop r8
00007a40685d75a2  pop rsi
00007a40685d75a3  pop rdi
00007a40685d75a4  pop rdx
00007a40685d75a5  pop rcx
00007a40685d75a6  pop rax
00007a40685d75a7  add rsp, 0x08
00007a40685d75ab  jmp 0x00007A40685D5C8F
00007a40685d75b0  sub rsp, 0x08
00007a40685d75b4  push rax
00007a40685d75b5  push rcx
00007a40685d75b6  push rdx
00007a40685d75b7  push rdi
00007a40685d75b8  push rsi
00007a40685d75b9  push r8
00007a40685d75bb  push r9
00007a40685d75bd  push r10
00007a40685d75bf  push r11
00007a40685d75c1  sub rsp, 0xF0
00007a40685d75c8  vmovaps [rsp], xmm0
00007a40685d75cd  vmovaps [rsp+0x10], xmm1
00007a40685d75d3  vmovaps [rsp+0x20], xmm2
00007a40685d75d9  vmovaps [rsp+0x30], xmm3
00007a40685d75df  vmovaps [rsp+0x40], xmm4
00007a40685d75e5  vmovaps [rsp+0x50], xmm5
00007a40685d75eb  vmovaps [rsp+0x60], xmm7
00007a40685d75f1  vmovaps [rsp+0x70], xmm8
00007a40685d75f7  vmovaps [rsp+0x80], xmm9
00007a40685d7600  vmovaps [rsp+0x90], xmm10
00007a40685d7609  vmovaps [rsp+0xA0], xmm11
00007a40685d7612  vmovaps [rsp+0xB0], xmm12
00007a40685d761b  vmovaps [rsp+0xC0], xmm13
00007a40685d7624  vmovaps [rsp+0xD0], xmm14
00007a40685d762d  vmovaps [rsp+0xE0], xmm15
00007a40685d7636  sub rsp, 0x30
00007a40685d763a  movaps [rsp], xmm6
00007a40685d763e  movaps [rsp+0x10], xmm9
00007a40685d7644  movaps [rsp+0x20], xmm7
00007a40685d7649  lea rdi, [rsp]
00007a40685d764d  mov esi, 0x00
00007a40685d7652  mov rax, 0x56F679577530
00007a40685d765c  call rax
00007a40685d765e  movaps xmm6, [rsp]
00007a40685d7662  add rsp, 0x30
00007a40685d7666  vmovaps xmm0, [rsp]
00007a40685d766b  vmovaps xmm1, [rsp+0x10]
00007a40685d7671  vmovaps xmm2, [rsp+0x20]
00007a40685d7677  vmovaps xmm3, [rsp+0x30]
00007a40685d767d  vmovaps xmm4, [rsp+0x40]
00007a40685d7683  vmovaps xmm5, [rsp+0x50]
00007a40685d7689  vmovaps xmm7, [rsp+0x60]
00007a40685d768f  vmovaps xmm8, [rsp+0x70]
00007a40685d7695  vmovaps xmm9, [rsp+0x80]
00007a40685d769e  vmovaps xmm10, [rsp+0x90]
00007a40685d76a7  vmovaps xmm11, [rsp+0xA0]
00007a40685d76b0  vmovaps xmm12, [rsp+0xB0]
00007a40685d76b9  vmovaps xmm13, [rsp+0xC0]
00007a40685d76c2  vmovaps xmm14, [rsp+0xD0]
00007a40685d76cb  vmovaps xmm15, [rsp+0xE0]
00007a40685d76d4  add rsp, 0xF0
00007a40685d76db  pop r11
00007a40685d76dd  pop r10
00007a40685d76df  pop r9
00007a40685d76e1  pop r8
00007a40685d76e3  pop rsi
00007a40685d76e4  pop rdi
00007a40685d76e5  pop rdx
00007a40685d76e6  pop rcx
00007a40685d76e7  pop rax
00007a40685d76e8  add rsp, 0x08
00007a40685d76ec  jmp 0x00007A40685D5CA7
00007a40685d76f1  sub rsp, 0x08
00007a40685d76f5  push rax
00007a40685d76f6  push rcx
00007a40685d76f7  push rdx
00007a40685d76f8  push rdi
00007a40685d76f9  push rsi
00007a40685d76fa  push r8
00007a40685d76fc  push r9
00007a40685d76fe  push r10
00007a40685d7700  push r11
00007a40685d7702  sub rsp, 0xF0
00007a40685d7709  vmovaps [rsp], xmm0
00007a40685d770e  vmovaps [rsp+0x10], xmm1
00007a40685d7714  vmovaps [rsp+0x20], xmm2
00007a40685d771a  vmovaps [rsp+0x30], xmm3
00007a40685d7720  vmovaps [rsp+0x40], xmm4
00007a40685d7726  vmovaps [rsp+0x50], xmm5
00007a40685d772c  vmovaps [rsp+0x60], xmm6
00007a40685d7732  vmovaps [rsp+0x70], xmm8
00007a40685d7738  vmovaps [rsp+0x80], xmm9
00007a40685d7741  vmovaps [rsp+0x90], xmm10
00007a40685d774a  vmovaps [rsp+0xA0], xmm11
00007a40685d7753  vmovaps [rsp+0xB0], xmm12
00007a40685d775c  vmovaps [rsp+0xC0], xmm13
00007a40685d7765  vmovaps [rsp+0xD0], xmm14
00007a40685d776e  vmovaps [rsp+0xE0], xmm15
00007a40685d7777  sub rsp, 0x30
00007a40685d777b  movaps [rsp], xmm7
00007a40685d777f  movaps [rsp+0x10], xmm4
00007a40685d7784  movaps [rsp+0x20], xmm9
00007a40685d778a  lea rdi, [rsp]
00007a40685d778e  mov esi, 0x00
00007a40685d7793  mov rax, 0x56F679577530
00007a40685d779d  call rax
00007a40685d779f  movaps xmm7, [rsp]
00007a40685d77a3  add rsp, 0x30
00007a40685d77a7  vmovaps xmm0, [rsp]
00007a40685d77ac  vmovaps xmm1, [rsp+0x10]
00007a40685d77b2  vmovaps xmm2, [rsp+0x20]
00007a40685d77b8  vmovaps xmm3, [rsp+0x30]
00007a40685d77be  vmovaps xmm4, [rsp+0x40]
00007a40685d77c4  vmovaps xmm5, [rsp+0x50]
00007a40685d77ca  vmovaps xmm6, [rsp+0x60]
00007a40685d77d0  vmovaps xmm8, [rsp+0x70]
00007a40685d77d6  vmovaps xmm9, [rsp+0x80]
00007a40685d77df  vmovaps xmm10, [rsp+0x90]
00007a40685d77e8  vmovaps xmm11, [rsp+0xA0]
00007a40685d77f1  vmovaps xmm12, [rsp+0xB0]
00007a40685d77fa  vmovaps xmm13, [rsp+0xC0]
00007a40685d7803  vmovaps xmm14, [rsp+0xD0]
00007a40685d780c  vmovaps xmm15, [rsp+0xE0]
00007a40685d7815  add rsp, 0xF0
00007a40685d781c  pop r11
00007a40685d781e  pop r10
00007a40685d7820  pop r9
00007a40685d7822  pop r8
00007a40685d7824  pop rsi
00007a40685d7825  pop rdi
00007a40685d7826  pop rdx
00007a40685d7827  pop rcx
00007a40685d7828  pop rax
00007a40685d7829  add rsp, 0x08
00007a40685d782d  jmp 0x00007A40685D5CD4
00007a40685d7832  sub rsp, 0x08
00007a40685d7836  push rax
00007a40685d7837  push rcx
00007a40685d7838  push rdx
00007a40685d7839  push rdi
00007a40685d783a  push rsi
00007a40685d783b  push r8
00007a40685d783d  push r9
00007a40685d783f  push r10
00007a40685d7841  push r11
00007a40685d7843  sub rsp, 0xF0
00007a40685d784a  vmovaps [rsp], xmm0
00007a40685d784f  vmovaps [rsp+0x10], xmm1
00007a40685d7855  vmovaps [rsp+0x20], xmm2
00007a40685d785b  vmovaps [rsp+0x30], xmm3
00007a40685d7861  vmovaps [rsp+0x40], xmm5
00007a40685d7867  vmovaps [rsp+0x50], xmm6
00007a40685d786d  vmovaps [rsp+0x60], xmm7
00007a40685d7873  vmovaps [rsp+0x70], xmm8
00007a40685d7879  vmovaps [rsp+0x80], xmm9
00007a40685d7882  vmovaps [rsp+0x90], xmm10
00007a40685d788b  vmovaps [rsp+0xA0], xmm11
00007a40685d7894  vmovaps [rsp+0xB0], xmm12
00007a40685d789d  vmovaps [rsp+0xC0], xmm13
00007a40685d78a6  vmovaps [rsp+0xD0], xmm14
00007a40685d78af  vmovaps [rsp+0xE0], xmm15
00007a40685d78b8  sub rsp, 0x30
00007a40685d78bc  movaps [rsp], xmm4
00007a40685d78c0  movaps [rsp+0x10], xmm15
00007a40685d78c6  movaps [rsp+0x20], xmm9
00007a40685d78cc  lea rdi, [rsp]
00007a40685d78d0  mov esi, 0x00
00007a40685d78d5  mov rax, 0x56F679577530
00007a40685d78df  call rax
00007a40685d78e1  movaps xmm4, [rsp]
00007a40685d78e5  add rsp, 0x30
00007a40685d78e9  vmovaps xmm0, [rsp]
00007a40685d78ee  vmovaps xmm1, [rsp+0x10]
00007a40685d78f4  vmovaps xmm2, [rsp+0x20]
00007a40685d78fa  vmovaps xmm3, [rsp+0x30]
00007a40685d7900  vmovaps xmm5, [rsp+0x40]
00007a40685d7906  vmovaps xmm6, [rsp+0x50]
00007a40685d790c  vmovaps xmm7, [rsp+0x60]
00007a40685d7912  vmovaps xmm8, [rsp+0x70]
00007a40685d7918  vmovaps xmm9, [rsp+0x80]
00007a40685d7921  vmovaps xmm10, [rsp+0x90]
00007a40685d792a  vmovaps xmm11, [rsp+0xA0]
00007a40685d7933  vmovaps xmm12, [rsp+0xB0]
00007a40685d793c  vmovaps xmm13, [rsp+0xC0]
00007a40685d7945  vmovaps xmm14, [rsp+0xD0]
00007a40685d794e  vmovaps xmm15, [rsp+0xE0]
00007a40685d7957  add rsp, 0xF0
00007a40685d795e  pop r11
00007a40685d7960  pop r10
00007a40685d7962  pop r9
00007a40685d7964  pop r8
00007a40685d7966  pop rsi
00007a40685d7967  pop rdi
00007a40685d7968  pop rdx
00007a40685d7969  pop rcx
00007a40685d796a  pop rax
00007a40685d796b  add rsp, 0x08
00007a40685d796f  jmp 0x00007A40685D5CF9
00007a40685d7974  call 0x00007A40684E5820
00007a40685d7979  jmp 0x00007A40685D5D06
00007a40685d797e  sub rsp, 0x08
00007a40685d7982  push rax
00007a40685d7983  push rcx
00007a40685d7984  push rdx
00007a40685d7985  push rdi
00007a40685d7986  push rsi
00007a40685d7987  push r8
00007a40685d7989  push r9
00007a40685d798b  push r10
00007a40685d798d  push r11
00007a40685d798f  sub rsp, 0xF0
00007a40685d7996  vmovaps [rsp], xmm0
00007a40685d799b  vmovaps [rsp+0x10], xmm1
00007a40685d79a1  vmovaps [rsp+0x20], xmm2
00007a40685d79a7  vmovaps [rsp+0x30], xmm4
00007a40685d79ad  vmovaps [rsp+0x40], xmm5
00007a40685d79b3  vmovaps [rsp+0x50], xmm6
00007a40685d79b9  vmovaps [rsp+0x60], xmm7
00007a40685d79bf  vmovaps [rsp+0x70], xmm8
00007a40685d79c5  vmovaps [rsp+0x80], xmm9
00007a40685d79ce  vmovaps [rsp+0x90], xmm10
00007a40685d79d7  vmovaps [rsp+0xA0], xmm11
00007a40685d79e0  vmovaps [rsp+0xB0], xmm12
00007a40685d79e9  vmovaps [rsp+0xC0], xmm13
00007a40685d79f2  vmovaps [rsp+0xD0], xmm14
00007a40685d79fb  vmovaps [rsp+0xE0], xmm15
00007a40685d7a04  sub rsp, 0x30
00007a40685d7a08  movaps [rsp], xmm3
00007a40685d7a0c  movaps [rsp+0x10], xmm1
00007a40685d7a11  movaps [rsp+0x20], xmm9
00007a40685d7a17  lea rdi, [rsp]
00007a40685d7a1b  mov esi, 0x00
00007a40685d7a20  mov rax, 0x56F679577530
00007a40685d7a2a  call rax
00007a40685d7a2c  movaps xmm3, [rsp]
00007a40685d7a30  add rsp, 0x30
00007a40685d7a34  vmovaps xmm0, [rsp]
00007a40685d7a39  vmovaps xmm1, [rsp+0x10]
00007a40685d7a3f  vmovaps xmm2, [rsp+0x20]
00007a40685d7a45  vmovaps xmm4, [rsp+0x30]
00007a40685d7a4b  vmovaps xmm5, [rsp+0x40]
00007a40685d7a51  vmovaps xmm6, [rsp+0x50]
00007a40685d7a57  vmovaps xmm7, [rsp+0x60]
00007a40685d7a5d  vmovaps xmm8, [rsp+0x70]
00007a40685d7a63  vmovaps xmm9, [rsp+0x80]
00007a40685d7a6c  vmovaps xmm10, [rsp+0x90]
00007a40685d7a75  vmovaps xmm11, [rsp+0xA0]
00007a40685d7a7e  vmovaps xmm12, [rsp+0xB0]
00007a40685d7a87  vmovaps xmm13, [rsp+0xC0]
00007a40685d7a90  vmovaps xmm14, [rsp+0xD0]
00007a40685d7a99  vmovaps xmm15, [rsp+0xE0]
00007a40685d7aa2  add rsp, 0xF0
00007a40685d7aa9  pop r11
00007a40685d7aab  pop r10
00007a40685d7aad  pop r9
00007a40685d7aaf  pop r8
00007a40685d7ab1  pop rsi
00007a40685d7ab2  pop rdi
00007a40685d7ab3  pop rdx
00007a40685d7ab4  pop rcx
00007a40685d7ab5  pop rax
00007a40685d7ab6  add rsp, 0x08
00007a40685d7aba  jmp 0x00007A40685D5D43
00007a40685d7abf  sub rsp, 0x08
00007a40685d7ac3  push rax
00007a40685d7ac4  push rcx
00007a40685d7ac5  push rdx
00007a40685d7ac6  push rdi
00007a40685d7ac7  push rsi
00007a40685d7ac8  push r8
00007a40685d7aca  push r9
00007a40685d7acc  push r10
00007a40685d7ace  push r11
00007a40685d7ad0  sub rsp, 0xF0
00007a40685d7ad7  vmovaps [rsp], xmm0
00007a40685d7adc  vmovaps [rsp+0x10], xmm2
00007a40685d7ae2  vmovaps [rsp+0x20], xmm3
00007a40685d7ae8  vmovaps [rsp+0x30], xmm4
00007a40685d7aee  vmovaps [rsp+0x40], xmm5
00007a40685d7af4  vmovaps [rsp+0x50], xmm6
00007a40685d7afa  vmovaps [rsp+0x60], xmm7
00007a40685d7b00  vmovaps [rsp+0x70], xmm8
00007a40685d7b06  vmovaps [rsp+0x80], xmm9
00007a40685d7b0f  vmovaps [rsp+0x90], xmm10
00007a40685d7b18  vmovaps [rsp+0xA0], xmm11
00007a40685d7b21  vmovaps [rsp+0xB0], xmm12
00007a40685d7b2a  vmovaps [rsp+0xC0], xmm13
00007a40685d7b33  vmovaps [rsp+0xD0], xmm14
00007a40685d7b3c  vmovaps [rsp+0xE0], xmm15
00007a40685d7b45  sub rsp, 0x30
00007a40685d7b49  movaps [rsp], xmm1
00007a40685d7b4d  movaps [rsp+0x10], xmm15
00007a40685d7b53  movaps [rsp+0x20], xmm9
00007a40685d7b59  lea rdi, [rsp]
00007a40685d7b5d  mov esi, 0x00
00007a40685d7b62  mov rax, 0x56F679577530
00007a40685d7b6c  call rax
00007a40685d7b6e  movaps xmm1, [rsp]
00007a40685d7b72  add rsp, 0x30
00007a40685d7b76  vmovaps xmm0, [rsp]
00007a40685d7b7b  vmovaps xmm2, [rsp+0x10]
00007a40685d7b81  vmovaps xmm3, [rsp+0x20]
00007a40685d7b87  vmovaps xmm4, [rsp+0x30]
00007a40685d7b8d  vmovaps xmm5, [rsp+0x40]
00007a40685d7b93  vmovaps xmm6, [rsp+0x50]
00007a40685d7b99  vmovaps xmm7, [rsp+0x60]
00007a40685d7b9f  vmovaps xmm8, [rsp+0x70]
00007a40685d7ba5  vmovaps xmm9, [rsp+0x80]
00007a40685d7bae  vmovaps xmm10, [rsp+0x90]
00007a40685d7bb7  vmovaps xmm11, [rsp+0xA0]
00007a40685d7bc0  vmovaps xmm12, [rsp+0xB0]
00007a40685d7bc9  vmovaps xmm13, [rsp+0xC0]
00007a40685d7bd2  vmovaps xmm14, [rsp+0xD0]
00007a40685d7bdb  vmovaps xmm15, [rsp+0xE0]
00007a40685d7be4  add rsp, 0xF0
00007a40685d7beb  pop r11
00007a40685d7bed  pop r10
00007a40685d7bef  pop r9
00007a40685d7bf1  pop r8
00007a40685d7bf3  pop rsi
00007a40685d7bf4  pop rdi
00007a40685d7bf5  pop rdx
00007a40685d7bf6  pop rcx
00007a40685d7bf7  pop rax
00007a40685d7bf8  add rsp, 0x08
00007a40685d7bfc  jmp 0x00007A40685D5DCB
00007a40685d7c01  call 0x00007A40684E5820
00007a40685d7c06  jmp 0x00007A40685D5DD8
00007a40685d7c0b  sub rsp, 0x08
00007a40685d7c0f  push rax
00007a40685d7c10  push rcx
00007a40685d7c11  push rdx
00007a40685d7c12  push rdi
00007a40685d7c13  push rsi
00007a40685d7c14  push r8
00007a40685d7c16  push r9
00007a40685d7c18  push r10
00007a40685d7c1a  push r11
00007a40685d7c1c  sub rsp, 0xF0
00007a40685d7c23  vmovaps [rsp], xmm0
00007a40685d7c28  vmovaps [rsp+0x10], xmm2
00007a40685d7c2e  vmovaps [rsp+0x20], xmm3
00007a40685d7c34  vmovaps [rsp+0x30], xmm4
00007a40685d7c3a  vmovaps [rsp+0x40], xmm5
00007a40685d7c40  vmovaps [rsp+0x50], xmm6
00007a40685d7c46  vmovaps [rsp+0x60], xmm7
00007a40685d7c4c  vmovaps [rsp+0x70], xmm8
00007a40685d7c52  vmovaps [rsp+0x80], xmm9
00007a40685d7c5b  vmovaps [rsp+0x90], xmm10
00007a40685d7c64  vmovaps [rsp+0xA0], xmm11
00007a40685d7c6d  vmovaps [rsp+0xB0], xmm12
00007a40685d7c76  vmovaps [rsp+0xC0], xmm13
00007a40685d7c7f  vmovaps [rsp+0xD0], xmm14
00007a40685d7c88  vmovaps [rsp+0xE0], xmm15
00007a40685d7c91  sub rsp, 0x30
00007a40685d7c95  movaps [rsp], xmm1
00007a40685d7c99  movaps [rsp+0x10], xmm5
00007a40685d7c9e  movaps [rsp+0x20], xmm7
00007a40685d7ca3  lea rdi, [rsp]
00007a40685d7ca7  mov esi, 0x00
00007a40685d7cac  mov rax, 0x56F679577530
00007a40685d7cb6  call rax
00007a40685d7cb8  movaps xmm1, [rsp]
00007a40685d7cbc  add rsp, 0x30
00007a40685d7cc0  vmovaps xmm0, [rsp]
00007a40685d7cc5  vmovaps xmm2, [rsp+0x10]
00007a40685d7ccb  vmovaps xmm3, [rsp+0x20]
00007a40685d7cd1  vmovaps xmm4, [rsp+0x30]
00007a40685d7cd7  vmovaps xmm5, [rsp+0x40]
00007a40685d7cdd  vmovaps xmm6, [rsp+0x50]
00007a40685d7ce3  vmovaps xmm7, [rsp+0x60]
00007a40685d7ce9  vmovaps xmm8, [rsp+0x70]
00007a40685d7cef  vmovaps xmm9, [rsp+0x80]
00007a40685d7cf8  vmovaps xmm10, [rsp+0x90]
00007a40685d7d01  vmovaps xmm11, [rsp+0xA0]
00007a40685d7d0a  vmovaps xmm12, [rsp+0xB0]
00007a40685d7d13  vmovaps xmm13, [rsp+0xC0]
00007a40685d7d1c  vmovaps xmm14, [rsp+0xD0]
00007a40685d7d25  vmovaps xmm15, [rsp+0xE0]
00007a40685d7d2e  add rsp, 0xF0
00007a40685d7d35  pop r11
00007a40685d7d37  pop r10
00007a40685d7d39  pop r9
00007a40685d7d3b  pop r8
00007a40685d7d3d  pop rsi
00007a40685d7d3e  pop rdi
00007a40685d7d3f  pop rdx
00007a40685d7d40  pop rcx
00007a40685d7d41  pop rax
00007a40685d7d42  add rsp, 0x08
00007a40685d7d46  jmp 0x00007A40685D5E7D
00007a40685d7d4b  sub rsp, 0x08
00007a40685d7d4f  push rax
00007a40685d7d50  push rcx
00007a40685d7d51  push rdx
00007a40685d7d52  push rdi
00007a40685d7d53  push rsi
00007a40685d7d54  push r8
00007a40685d7d56  push r9
00007a40685d7d58  push r10
00007a40685d7d5a  push r11
00007a40685d7d5c  sub rsp, 0xF0
00007a40685d7d63  vmovaps [rsp], xmm0
00007a40685d7d68  vmovaps [rsp+0x10], xmm1
00007a40685d7d6e  vmovaps [rsp+0x20], xmm2
00007a40685d7d74  vmovaps [rsp+0x30], xmm3
00007a40685d7d7a  vmovaps [rsp+0x40], xmm4
00007a40685d7d80  vmovaps [rsp+0x50], xmm5
00007a40685d7d86  vmovaps [rsp+0x60], xmm6
00007a40685d7d8c  vmovaps [rsp+0x70], xmm8
00007a40685d7d92  vmovaps [rsp+0x80], xmm9
00007a40685d7d9b  vmovaps [rsp+0x90], xmm10
00007a40685d7da4  vmovaps [rsp+0xA0], xmm11
00007a40685d7dad  vmovaps [rsp+0xB0], xmm12
00007a40685d7db6  vmovaps [rsp+0xC0], xmm13
00007a40685d7dbf  vmovaps [rsp+0xD0], xmm14
00007a40685d7dc8  vmovaps [rsp+0xE0], xmm15
00007a40685d7dd1  sub rsp, 0x30
00007a40685d7dd5  movaps [rsp], xmm7
00007a40685d7dd9  movaps [rsp+0x10], xmm5
00007a40685d7dde  movaps [rsp+0x20], xmm15
00007a40685d7de4  lea rdi, [rsp]
00007a40685d7de8  mov esi, 0x00
00007a40685d7ded  mov rax, 0x56F679577530
00007a40685d7df7  call rax
00007a40685d7df9  movaps xmm7, [rsp]
00007a40685d7dfd  add rsp, 0x30
00007a40685d7e01  vmovaps xmm0, [rsp]
00007a40685d7e06  vmovaps xmm1, [rsp+0x10]
00007a40685d7e0c  vmovaps xmm2, [rsp+0x20]
00007a40685d7e12  vmovaps xmm3, [rsp+0x30]
00007a40685d7e18  vmovaps xmm4, [rsp+0x40]
00007a40685d7e1e  vmovaps xmm5, [rsp+0x50]
00007a40685d7e24  vmovaps xmm6, [rsp+0x60]
00007a40685d7e2a  vmovaps xmm8, [rsp+0x70]
00007a40685d7e30  vmovaps xmm9, [rsp+0x80]
00007a40685d7e39  vmovaps xmm10, [rsp+0x90]
00007a40685d7e42  vmovaps xmm11, [rsp+0xA0]
00007a40685d7e4b  vmovaps xmm12, [rsp+0xB0]
00007a40685d7e54  vmovaps xmm13, [rsp+0xC0]
00007a40685d7e5d  vmovaps xmm14, [rsp+0xD0]
00007a40685d7e66  vmovaps xmm15, [rsp+0xE0]
00007a40685d7e6f  add rsp, 0xF0
00007a40685d7e76  pop r11
00007a40685d7e78  pop r10
00007a40685d7e7a  pop r9
00007a40685d7e7c  pop r8
00007a40685d7e7e  pop rsi
00007a40685d7e7f  pop rdi
00007a40685d7e80  pop rdx
00007a40685d7e81  pop rcx
00007a40685d7e82  pop rax
00007a40685d7e83  add rsp, 0x08
00007a40685d7e87  jmp 0x00007A40685D5EB3
00007a40685d7e8c  call 0x00007A40684D64F0
00007a40685d7e91  jmp 0x00007A40685D5EC0
00007a40685d7e96  sub rsp, 0x08
00007a40685d7e9a  push rax
00007a40685d7e9b  push rcx
00007a40685d7e9c  push rdx
00007a40685d7e9d  push rdi
00007a40685d7e9e  push rsi
00007a40685d7e9f  push r8
00007a40685d7ea1  push r9
00007a40685d7ea3  push r10
00007a40685d7ea5  push r11
00007a40685d7ea7  sub rsp, 0xF0
00007a40685d7eae  vmovaps [rsp], xmm0
00007a40685d7eb3  vmovaps [rsp+0x10], xmm1
00007a40685d7eb9  vmovaps [rsp+0x20], xmm2
00007a40685d7ebf  vmovaps [rsp+0x30], xmm3
00007a40685d7ec5  vmovaps [rsp+0x40], xmm4
00007a40685d7ecb  vmovaps [rsp+0x50], xmm5
00007a40685d7ed1  vmovaps [rsp+0x60], xmm6
00007a40685d7ed7  vmovaps [rsp+0x70], xmm7
00007a40685d7edd  vmovaps [rsp+0x80], xmm8
00007a40685d7ee6  vmovaps [rsp+0x90], xmm9
00007a40685d7eef  vmovaps [rsp+0xA0], xmm10
00007a40685d7ef8  vmovaps [rsp+0xB0], xmm11
00007a40685d7f01  vmovaps [rsp+0xC0], xmm12
00007a40685d7f0a  vmovaps [rsp+0xD0], xmm13
00007a40685d7f13  vmovaps [rsp+0xE0], xmm14
00007a40685d7f1c  sub rsp, 0x30
00007a40685d7f20  movaps [rsp], xmm15
00007a40685d7f25  movaps [rsp+0x10], xmm5
00007a40685d7f2a  movaps [rsp+0x20], xmm3
00007a40685d7f2f  lea rdi, [rsp]
00007a40685d7f33  mov esi, 0x00
00007a40685d7f38  mov rax, 0x56F679577530
00007a40685d7f42  call rax
00007a40685d7f44  movaps xmm15, [rsp]
00007a40685d7f49  add rsp, 0x30
00007a40685d7f4d  vmovaps xmm0, [rsp]
00007a40685d7f52  vmovaps xmm1, [rsp+0x10]
00007a40685d7f58  vmovaps xmm2, [rsp+0x20]
00007a40685d7f5e  vmovaps xmm3, [rsp+0x30]
00007a40685d7f64  vmovaps xmm4, [rsp+0x40]
00007a40685d7f6a  vmovaps xmm5, [rsp+0x50]
00007a40685d7f70  vmovaps xmm6, [rsp+0x60]
00007a40685d7f76  vmovaps xmm7, [rsp+0x70]
00007a40685d7f7c  vmovaps xmm8, [rsp+0x80]
00007a40685d7f85  vmovaps xmm9, [rsp+0x90]
00007a40685d7f8e  vmovaps xmm10, [rsp+0xA0]
00007a40685d7f97  vmovaps xmm11, [rsp+0xB0]
00007a40685d7fa0  vmovaps xmm12, [rsp+0xC0]
00007a40685d7fa9  vmovaps xmm13, [rsp+0xD0]
00007a40685d7fb2  vmovaps xmm14, [rsp+0xE0]
00007a40685d7fbb  add rsp, 0xF0
00007a40685d7fc2  pop r11
00007a40685d7fc4  pop r10
00007a40685d7fc6  pop r9
00007a40685d7fc8  pop r8
00007a40685d7fca  pop rsi
00007a40685d7fcb  pop rdi
00007a40685d7fcc  pop rdx
00007a40685d7fcd  pop rcx
00007a40685d7fce  pop rax
00007a40685d7fcf  add rsp, 0x08
00007a40685d7fd3  jmp 0x00007A40685D5EE6
00007a40685d7fd8  sub rsp, 0x08
00007a40685d7fdc  push rax
00007a40685d7fdd  push rcx
00007a40685d7fde  push rdx
00007a40685d7fdf  push rdi
00007a40685d7fe0  push rsi
00007a40685d7fe1  push r8
00007a40685d7fe3  push r9
00007a40685d7fe5  push r10
00007a40685d7fe7  push r11
00007a40685d7fe9  sub rsp, 0xF0
00007a40685d7ff0  vmovaps [rsp], xmm0
00007a40685d7ff5  vmovaps [rsp+0x10], xmm2
00007a40685d7ffb  vmovaps [rsp+0x20], xmm3
00007a40685d8001  vmovaps [rsp+0x30], xmm4
00007a40685d8007  vmovaps [rsp+0x40], xmm5
00007a40685d800d  vmovaps [rsp+0x50], xmm6
00007a40685d8013  vmovaps [rsp+0x60], xmm7
00007a40685d8019  vmovaps [rsp+0x70], xmm8
00007a40685d801f  vmovaps [rsp+0x80], xmm9
00007a40685d8028  vmovaps [rsp+0x90], xmm10
00007a40685d8031  vmovaps [rsp+0xA0], xmm11
00007a40685d803a  vmovaps [rsp+0xB0], xmm12
00007a40685d8043  vmovaps [rsp+0xC0], xmm13
00007a40685d804c  vmovaps [rsp+0xD0], xmm14
00007a40685d8055  vmovaps [rsp+0xE0], xmm15
00007a40685d805e  sub rsp, 0x30
00007a40685d8062  movaps [rsp], xmm1
00007a40685d8066  movaps [rsp+0x10], xmm5
00007a40685d806b  movaps [rsp+0x20], xmm4
00007a40685d8070  lea rdi, [rsp]
00007a40685d8074  mov esi, 0x00
00007a40685d8079  mov rax, 0x56F679577530
00007a40685d8083  call rax
00007a40685d8085  movaps xmm1, [rsp]
00007a40685d8089  add rsp, 0x30
00007a40685d808d  vmovaps xmm0, [rsp]
00007a40685d8092  vmovaps xmm2, [rsp+0x10]
00007a40685d8098  vmovaps xmm3, [rsp+0x20]
00007a40685d809e  vmovaps xmm4, [rsp+0x30]
00007a40685d80a4  vmovaps xmm5, [rsp+0x40]
00007a40685d80aa  vmovaps xmm6, [rsp+0x50]
00007a40685d80b0  vmovaps xmm7, [rsp+0x60]
00007a40685d80b6  vmovaps xmm8, [rsp+0x70]
00007a40685d80bc  vmovaps xmm9, [rsp+0x80]
00007a40685d80c5  vmovaps xmm10, [rsp+0x90]
00007a40685d80ce  vmovaps xmm11, [rsp+0xA0]
00007a40685d80d7  vmovaps xmm12, [rsp+0xB0]
00007a40685d80e0  vmovaps xmm13, [rsp+0xC0]
00007a40685d80e9  vmovaps xmm14, [rsp+0xD0]
00007a40685d80f2  vmovaps xmm15, [rsp+0xE0]
00007a40685d80fb  add rsp, 0xF0
00007a40685d8102  pop r11
00007a40685d8104  pop r10
00007a40685d8106  pop r9
00007a40685d8108  pop r8
00007a40685d810a  pop rsi
00007a40685d810b  pop rdi
00007a40685d810c  pop rdx
00007a40685d810d  pop rcx
00007a40685d810e  pop rax
00007a40685d810f  add rsp, 0x08
00007a40685d8113  jmp 0x00007A40685D5F06
00007a40685d8118  sub rsp, 0x08
00007a40685d811c  push rax
00007a40685d811d  push rcx
00007a40685d811e  push rdx
00007a40685d811f  push rdi
00007a40685d8120  push rsi
00007a40685d8121  push r8
00007a40685d8123  push r9
00007a40685d8125  push r10
00007a40685d8127  push r11
00007a40685d8129  sub rsp, 0xF0
00007a40685d8130  vmovaps [rsp], xmm0
00007a40685d8135  vmovaps [rsp+0x10], xmm1
00007a40685d813b  vmovaps [rsp+0x20], xmm2
00007a40685d8141  vmovaps [rsp+0x30], xmm3
00007a40685d8147  vmovaps [rsp+0x40], xmm5
00007a40685d814d  vmovaps [rsp+0x50], xmm6
00007a40685d8153  vmovaps [rsp+0x60], xmm7
00007a40685d8159  vmovaps [rsp+0x70], xmm8
00007a40685d815f  vmovaps [rsp+0x80], xmm9
00007a40685d8168  vmovaps [rsp+0x90], xmm10
00007a40685d8171  vmovaps [rsp+0xA0], xmm11
00007a40685d817a  vmovaps [rsp+0xB0], xmm12
00007a40685d8183  vmovaps [rsp+0xC0], xmm13
00007a40685d818c  vmovaps [rsp+0xD0], xmm14
00007a40685d8195  vmovaps [rsp+0xE0], xmm15
00007a40685d819e  sub rsp, 0x30
00007a40685d81a2  movaps [rsp], xmm4
00007a40685d81a6  movaps [rsp+0x10], xmm3
00007a40685d81ab  movaps [rsp+0x20], xmm5
00007a40685d81b0  lea rdi, [rsp]
00007a40685d81b4  mov esi, 0x00
00007a40685d81b9  mov rax, 0x56F679577530
00007a40685d81c3  call rax
00007a40685d81c5  movaps xmm4, [rsp]
00007a40685d81c9  add rsp, 0x30
00007a40685d81cd  vmovaps xmm0, [rsp]
00007a40685d81d2  vmovaps xmm1, [rsp+0x10]
00007a40685d81d8  vmovaps xmm2, [rsp+0x20]
00007a40685d81de  vmovaps xmm3, [rsp+0x30]
00007a40685d81e4  vmovaps xmm5, [rsp+0x40]
00007a40685d81ea  vmovaps xmm6, [rsp+0x50]
00007a40685d81f0  vmovaps xmm7, [rsp+0x60]
00007a40685d81f6  vmovaps xmm8, [rsp+0x70]
00007a40685d81fc  vmovaps xmm9, [rsp+0x80]
00007a40685d8205  vmovaps xmm10, [rsp+0x90]
00007a40685d820e  vmovaps xmm11, [rsp+0xA0]
00007a40685d8217  vmovaps xmm12, [rsp+0xB0]
00007a40685d8220  vmovaps xmm13, [rsp+0xC0]
00007a40685d8229  vmovaps xmm14, [rsp+0xD0]
00007a40685d8232  vmovaps xmm15, [rsp+0xE0]
00007a40685d823b  add rsp, 0xF0
00007a40685d8242  pop r11
00007a40685d8244  pop r10
00007a40685d8246  pop r9
00007a40685d8248  pop r8
00007a40685d824a  pop rsi
00007a40685d824b  pop rdi
00007a40685d824c  pop rdx
00007a40685d824d  pop rcx
00007a40685d824e  pop rax
00007a40685d824f  add rsp, 0x08
00007a40685d8253  jmp 0x00007A40685D5F54
00007a40685d8258  call 0x00007A40684D64F0
00007a40685d825d  jmp 0x00007A40685D5F61
00007a40685d8262  sub rsp, 0x08
00007a40685d8266  push rax
00007a40685d8267  push rcx
00007a40685d8268  push rdx
00007a40685d8269  push rdi
00007a40685d826a  push rsi
00007a40685d826b  push r8
00007a40685d826d  push r9
00007a40685d826f  push r10
00007a40685d8271  push r11
00007a40685d8273  sub rsp, 0xF0
00007a40685d827a  vmovaps [rsp], xmm0
00007a40685d827f  vmovaps [rsp+0x10], xmm1
00007a40685d8285  vmovaps [rsp+0x20], xmm2
00007a40685d828b  vmovaps [rsp+0x30], xmm3
00007a40685d8291  vmovaps [rsp+0x40], xmm4
00007a40685d8297  vmovaps [rsp+0x50], xmm6
00007a40685d829d  vmovaps [rsp+0x60], xmm7
00007a40685d82a3  vmovaps [rsp+0x70], xmm8
00007a40685d82a9  vmovaps [rsp+0x80], xmm9
00007a40685d82b2  vmovaps [rsp+0x90], xmm10
00007a40685d82bb  vmovaps [rsp+0xA0], xmm11
00007a40685d82c4  vmovaps [rsp+0xB0], xmm12
00007a40685d82cd  vmovaps [rsp+0xC0], xmm13
00007a40685d82d6  vmovaps [rsp+0xD0], xmm14
00007a40685d82df  vmovaps [rsp+0xE0], xmm15
00007a40685d82e8  sub rsp, 0x30
00007a40685d82ec  movaps [rsp], xmm5
00007a40685d82f0  movaps [rsp+0x10], xmm6
00007a40685d82f5  movaps [rsp+0x20], xmm3
00007a40685d82fa  lea rdi, [rsp]
00007a40685d82fe  mov esi, 0x00
00007a40685d8303  mov rax, 0x56F679577530
00007a40685d830d  call rax
00007a40685d830f  movaps xmm5, [rsp]
00007a40685d8313  add rsp, 0x30
00007a40685d8317  vmovaps xmm0, [rsp]
00007a40685d831c  vmovaps xmm1, [rsp+0x10]
00007a40685d8322  vmovaps xmm2, [rsp+0x20]
00007a40685d8328  vmovaps xmm3, [rsp+0x30]
00007a40685d832e  vmovaps xmm4, [rsp+0x40]
00007a40685d8334  vmovaps xmm6, [rsp+0x50]
00007a40685d833a  vmovaps xmm7, [rsp+0x60]
00007a40685d8340  vmovaps xmm8, [rsp+0x70]
00007a40685d8346  vmovaps xmm9, [rsp+0x80]
00007a40685d834f  vmovaps xmm10, [rsp+0x90]
00007a40685d8358  vmovaps xmm11, [rsp+0xA0]
00007a40685d8361  vmovaps xmm12, [rsp+0xB0]
00007a40685d836a  vmovaps xmm13, [rsp+0xC0]
00007a40685d8373  vmovaps xmm14, [rsp+0xD0]
00007a40685d837c  vmovaps xmm15, [rsp+0xE0]
00007a40685d8385  add rsp, 0xF0
00007a40685d838c  pop r11
00007a40685d838e  pop r10
00007a40685d8390  pop r9
00007a40685d8392  pop r8
00007a40685d8394  pop rsi
00007a40685d8395  pop rdi
00007a40685d8396  pop rdx
00007a40685d8397  pop rcx
00007a40685d8398  pop rax
00007a40685d8399  add rsp, 0x08
00007a40685d839d  jmp 0x00007A40685D5F87
00007a40685d83a2  sub rsp, 0x08
00007a40685d83a6  push rax
00007a40685d83a7  push rcx
00007a40685d83a8  push rdx
00007a40685d83a9  push rdi
00007a40685d83aa  push rsi
00007a40685d83ab  push r8
00007a40685d83ad  push r9
00007a40685d83af  push r10
00007a40685d83b1  push r11
00007a40685d83b3  sub rsp, 0xF0
00007a40685d83ba  vmovaps [rsp], xmm0
00007a40685d83bf  vmovaps [rsp+0x10], xmm1
00007a40685d83c5  vmovaps [rsp+0x20], xmm2
00007a40685d83cb  vmovaps [rsp+0x30], xmm3
00007a40685d83d1  vmovaps [rsp+0x40], xmm4
00007a40685d83d7  vmovaps [rsp+0x50], xmm5
00007a40685d83dd  vmovaps [rsp+0x60], xmm7
00007a40685d83e3  vmovaps [rsp+0x70], xmm8
00007a40685d83e9  vmovaps [rsp+0x80], xmm9
00007a40685d83f2  vmovaps [rsp+0x90], xmm10
00007a40685d83fb  vmovaps [rsp+0xA0], xmm11
00007a40685d8404  vmovaps [rsp+0xB0], xmm12
00007a40685d840d  vmovaps [rsp+0xC0], xmm13
00007a40685d8416  vmovaps [rsp+0xD0], xmm14
00007a40685d841f  vmovaps [rsp+0xE0], xmm15
00007a40685d8428  sub rsp, 0x30
00007a40685d842c  movaps [rsp], xmm6
00007a40685d8430  movaps [rsp+0x10], xmm9
00007a40685d8436  movaps [rsp+0x20], xmm1
00007a40685d843b  lea rdi, [rsp]
00007a40685d843f  mov esi, 0x00
00007a40685d8444  mov rax, 0x56F679577530
00007a40685d844e  call rax
00007a40685d8450  movaps xmm6, [rsp]
00007a40685d8454  add rsp, 0x30
00007a40685d8458  vmovaps xmm0, [rsp]
00007a40685d845d  vmovaps xmm1, [rsp+0x10]
00007a40685d8463  vmovaps xmm2, [rsp+0x20]
00007a40685d8469  vmovaps xmm3, [rsp+0x30]
00007a40685d846f  vmovaps xmm4, [rsp+0x40]
00007a40685d8475  vmovaps xmm5, [rsp+0x50]
00007a40685d847b  vmovaps xmm7, [rsp+0x60]
00007a40685d8481  vmovaps xmm8, [rsp+0x70]
00007a40685d8487  vmovaps xmm9, [rsp+0x80]
00007a40685d8490  vmovaps xmm10, [rsp+0x90]
00007a40685d8499  vmovaps xmm11, [rsp+0xA0]
00007a40685d84a2  vmovaps xmm12, [rsp+0xB0]
00007a40685d84ab  vmovaps xmm13, [rsp+0xC0]
00007a40685d84b4  vmovaps xmm14, [rsp+0xD0]
00007a40685d84bd  vmovaps xmm15, [rsp+0xE0]
00007a40685d84c6  add rsp, 0xF0
00007a40685d84cd  pop r11
00007a40685d84cf  pop r10
00007a40685d84d1  pop r9
00007a40685d84d3  pop r8
00007a40685d84d5  pop rsi
00007a40685d84d6  pop rdi
00007a40685d84d7  pop rdx
00007a40685d84d8  pop rcx
00007a40685d84d9  pop rax
00007a40685d84da  add rsp, 0x08
00007a40685d84de  jmp 0x00007A40685D5FAB
00007a40685d84e3  sub rsp, 0x08
00007a40685d84e7  push rax
00007a40685d84e8  push rcx
00007a40685d84e9  push rdx
00007a40685d84ea  push rdi
00007a40685d84eb  push rsi
00007a40685d84ec  push r8
00007a40685d84ee  push r9
00007a40685d84f0  push r10
00007a40685d84f2  push r11
00007a40685d84f4  sub rsp, 0xF0
00007a40685d84fb  vmovaps [rsp], xmm0
00007a40685d8500  vmovaps [rsp+0x10], xmm1
00007a40685d8506  vmovaps [rsp+0x20], xmm2
00007a40685d850c  vmovaps [rsp+0x30], xmm3
00007a40685d8512  vmovaps [rsp+0x40], xmm4
00007a40685d8518  vmovaps [rsp+0x50], xmm5
00007a40685d851e  vmovaps [rsp+0x60], xmm6
00007a40685d8524  vmovaps [rsp+0x70], xmm7
00007a40685d852a  vmovaps [rsp+0x80], xmm8
00007a40685d8533  vmovaps [rsp+0x90], xmm10
00007a40685d853c  vmovaps [rsp+0xA0], xmm11
00007a40685d8545  vmovaps [rsp+0xB0], xmm12
00007a40685d854e  vmovaps [rsp+0xC0], xmm13
00007a40685d8557  vmovaps [rsp+0xD0], xmm14
00007a40685d8560  vmovaps [rsp+0xE0], xmm15
00007a40685d8569  sub rsp, 0x30
00007a40685d856d  movaps [rsp], xmm9
00007a40685d8572  movaps [rsp+0x10], xmm3
00007a40685d8577  movaps [rsp+0x20], xmm1
00007a40685d857c  lea rdi, [rsp]
00007a40685d8580  mov esi, 0x00
00007a40685d8585  mov rax, 0x56F679577530
00007a40685d858f  call rax
00007a40685d8591  movaps xmm9, [rsp]
00007a40685d8596  add rsp, 0x30
00007a40685d859a  vmovaps xmm0, [rsp]
00007a40685d859f  vmovaps xmm1, [rsp+0x10]
00007a40685d85a5  vmovaps xmm2, [rsp+0x20]
00007a40685d85ab  vmovaps xmm3, [rsp+0x30]
00007a40685d85b1  vmovaps xmm4, [rsp+0x40]
00007a40685d85b7  vmovaps xmm5, [rsp+0x50]
00007a40685d85bd  vmovaps xmm6, [rsp+0x60]
00007a40685d85c3  vmovaps xmm7, [rsp+0x70]
00007a40685d85c9  vmovaps xmm8, [rsp+0x80]
00007a40685d85d2  vmovaps xmm10, [rsp+0x90]
00007a40685d85db  vmovaps xmm11, [rsp+0xA0]
00007a40685d85e4  vmovaps xmm12, [rsp+0xB0]
00007a40685d85ed  vmovaps xmm13, [rsp+0xC0]
00007a40685d85f6  vmovaps xmm14, [rsp+0xD0]
00007a40685d85ff  vmovaps xmm15, [rsp+0xE0]
00007a40685d8608  add rsp, 0xF0
00007a40685d860f  pop r11
00007a40685d8611  pop r10
00007a40685d8613  pop r9
00007a40685d8615  pop r8
00007a40685d8617  pop rsi
00007a40685d8618  pop rdi
00007a40685d8619  pop rdx
00007a40685d861a  pop rcx
00007a40685d861b  pop rax
00007a40685d861c  add rsp, 0x08
00007a40685d8620  jmp 0x00007A40685D5FF7
00007a40685d8625  call 0x00007A40684D64F0
00007a40685d862a  jmp 0x00007A40685D6004
00007a40685d862f  sub rsp, 0x08
00007a40685d8633  push rax
00007a40685d8634  push rcx
00007a40685d8635  push rdx
00007a40685d8636  push rdi
00007a40685d8637  push rsi
00007a40685d8638  push r8
00007a40685d863a  push r9
00007a40685d863c  push r10
00007a40685d863e  push r11
00007a40685d8640  sub rsp, 0xF0
00007a40685d8647  vmovaps [rsp], xmm0
00007a40685d864c  vmovaps [rsp+0x10], xmm1
00007a40685d8652  vmovaps [rsp+0x20], xmm2
00007a40685d8658  vmovaps [rsp+0x30], xmm3
00007a40685d865e  vmovaps [rsp+0x40], xmm4
00007a40685d8664  vmovaps [rsp+0x50], xmm5
00007a40685d866a  vmovaps [rsp+0x60], xmm6
00007a40685d8670  vmovaps [rsp+0x70], xmm7
00007a40685d8676  vmovaps [rsp+0x80], xmm8
00007a40685d867f  vmovaps [rsp+0x90], xmm9
00007a40685d8688  vmovaps [rsp+0xA0], xmm10
00007a40685d8691  vmovaps [rsp+0xB0], xmm11
00007a40685d869a  vmovaps [rsp+0xC0], xmm12
00007a40685d86a3  vmovaps [rsp+0xD0], xmm13
00007a40685d86ac  vmovaps [rsp+0xE0], xmm14
00007a40685d86b5  sub rsp, 0x30
00007a40685d86b9  movaps [rsp], xmm15
00007a40685d86be  movaps [rsp+0x10], xmm3
00007a40685d86c3  movaps [rsp+0x20], xmm7
00007a40685d86c8  lea rdi, [rsp]
00007a40685d86cc  mov esi, 0x00
00007a40685d86d1  mov rax, 0x56F679577530
00007a40685d86db  call rax
00007a40685d86dd  movaps xmm15, [rsp]
00007a40685d86e2  add rsp, 0x30
00007a40685d86e6  vmovaps xmm0, [rsp]
00007a40685d86eb  vmovaps xmm1, [rsp+0x10]
00007a40685d86f1  vmovaps xmm2, [rsp+0x20]
00007a40685d86f7  vmovaps xmm3, [rsp+0x30]
00007a40685d86fd  vmovaps xmm4, [rsp+0x40]
00007a40685d8703  vmovaps xmm5, [rsp+0x50]
00007a40685d8709  vmovaps xmm6, [rsp+0x60]
00007a40685d870f  vmovaps xmm7, [rsp+0x70]
00007a40685d8715  vmovaps xmm8, [rsp+0x80]
00007a40685d871e  vmovaps xmm9, [rsp+0x90]
00007a40685d8727  vmovaps xmm10, [rsp+0xA0]
00007a40685d8730  vmovaps xmm11, [rsp+0xB0]
00007a40685d8739  vmovaps xmm12, [rsp+0xC0]
00007a40685d8742  vmovaps xmm13, [rsp+0xD0]
00007a40685d874b  vmovaps xmm14, [rsp+0xE0]
00007a40685d8754  add rsp, 0xF0
00007a40685d875b  pop r11
00007a40685d875d  pop r10
00007a40685d875f  pop r9
00007a40685d8761  pop r8
00007a40685d8763  pop rsi
00007a40685d8764  pop rdi
00007a40685d8765  pop rdx
00007a40685d8766  pop rcx
00007a40685d8767  pop rax
00007a40685d8768  add rsp, 0x08
00007a40685d876c  jmp 0x00007A40685D6030
00007a40685d8771  sub rsp, 0x08
00007a40685d8775  push rax
00007a40685d8776  push rcx
00007a40685d8777  push rdx
00007a40685d8778  push rdi
00007a40685d8779  push rsi
00007a40685d877a  push r8
00007a40685d877c  push r9
00007a40685d877e  push r10
00007a40685d8780  push r11
00007a40685d8782  sub rsp, 0xF0
00007a40685d8789  vmovaps [rsp], xmm0
00007a40685d878e  vmovaps [rsp+0x10], xmm1
00007a40685d8794  vmovaps [rsp+0x20], xmm2
00007a40685d879a  vmovaps [rsp+0x30], xmm4
00007a40685d87a0  vmovaps [rsp+0x40], xmm5
00007a40685d87a6  vmovaps [rsp+0x50], xmm6
00007a40685d87ac  vmovaps [rsp+0x60], xmm7
00007a40685d87b2  vmovaps [rsp+0x70], xmm8
00007a40685d87b8  vmovaps [rsp+0x80], xmm9
00007a40685d87c1  vmovaps [rsp+0x90], xmm10
00007a40685d87ca  vmovaps [rsp+0xA0], xmm11
00007a40685d87d3  vmovaps [rsp+0xB0], xmm12
00007a40685d87dc  vmovaps [rsp+0xC0], xmm13
00007a40685d87e5  vmovaps [rsp+0xD0], xmm14
00007a40685d87ee  vmovaps [rsp+0xE0], xmm15
00007a40685d87f7  sub rsp, 0x30
00007a40685d87fb  movaps [rsp], xmm3
00007a40685d87ff  movaps [rsp+0x10], xmm1
00007a40685d8804  movaps [rsp+0x20], xmm15
00007a40685d880a  lea rdi, [rsp]
00007a40685d880e  mov esi, 0x00
00007a40685d8813  mov rax, 0x56F679577530
00007a40685d881d  call rax
00007a40685d881f  movaps xmm3, [rsp]
00007a40685d8823  add rsp, 0x30
00007a40685d8827  vmovaps xmm0, [rsp]
00007a40685d882c  vmovaps xmm1, [rsp+0x10]
00007a40685d8832  vmovaps xmm2, [rsp+0x20]
00007a40685d8838  vmovaps xmm4, [rsp+0x30]
00007a40685d883e  vmovaps xmm5, [rsp+0x40]
00007a40685d8844  vmovaps xmm6, [rsp+0x50]
00007a40685d884a  vmovaps xmm7, [rsp+0x60]
00007a40685d8850  vmovaps xmm8, [rsp+0x70]
00007a40685d8856  vmovaps xmm9, [rsp+0x80]
00007a40685d885f  vmovaps xmm10, [rsp+0x90]
00007a40685d8868  vmovaps xmm11, [rsp+0xA0]
00007a40685d8871  vmovaps xmm12, [rsp+0xB0]
00007a40685d887a  vmovaps xmm13, [rsp+0xC0]
00007a40685d8883  vmovaps xmm14, [rsp+0xD0]
00007a40685d888c  vmovaps xmm15, [rsp+0xE0]
00007a40685d8895  add rsp, 0xF0
00007a40685d889c  pop r11
00007a40685d889e  pop r10
00007a40685d88a0  pop r9
00007a40685d88a2  pop r8
00007a40685d88a4  pop rsi
00007a40685d88a5  pop rdi
00007a40685d88a6  pop rdx
00007a40685d88a7  pop rcx
00007a40685d88a8  pop rax
00007a40685d88a9  add rsp, 0x08
00007a40685d88ad  jmp 0x00007A40685D60BF
00007a40685d88b2  call 0x00007A40684D64F0
00007a40685d88b7  jmp 0x00007A40685D60C9
00007a40685d88bc  sub rsp, 0x08
00007a40685d88c0  push rax
00007a40685d88c1  push rcx
00007a40685d88c2  push rdx
00007a40685d88c3  push rdi
00007a40685d88c4  push rsi
00007a40685d88c5  push r8
00007a40685d88c7  push r9
00007a40685d88c9  push r10
00007a40685d88cb  push r11
00007a40685d88cd  sub rsp, 0xF0
00007a40685d88d4  vmovaps [rsp], xmm0
00007a40685d88d9  vmovaps [rsp+0x10], xmm1
00007a40685d88df  vmovaps [rsp+0x20], xmm2
00007a40685d88e5  vmovaps [rsp+0x30], xmm3
00007a40685d88eb  vmovaps [rsp+0x40], xmm4
00007a40685d88f1  vmovaps [rsp+0x50], xmm5
00007a40685d88f7  vmovaps [rsp+0x60], xmm6
00007a40685d88fd  vmovaps [rsp+0x70], xmm7
00007a40685d8903  vmovaps [rsp+0x80], xmm8
00007a40685d890c  vmovaps [rsp+0x90], xmm9
00007a40685d8915  vmovaps [rsp+0xA0], xmm10
00007a40685d891e  vmovaps [rsp+0xB0], xmm11
00007a40685d8927  vmovaps [rsp+0xC0], xmm12
00007a40685d8930  vmovaps [rsp+0xD0], xmm13
00007a40685d8939  vmovaps [rsp+0xE0], xmm14
00007a40685d8942  sub rsp, 0x30
00007a40685d8946  movaps [rsp], xmm15
00007a40685d894b  movaps [rsp+0x10], xmm14
00007a40685d8951  movaps [rsp+0x20], xmm4
00007a40685d8956  lea rdi, [rsp]
00007a40685d895a  mov esi, 0x00
00007a40685d895f  mov rax, 0x56F679577530
00007a40685d8969  call rax
00007a40685d896b  movaps xmm15, [rsp]
00007a40685d8970  add rsp, 0x30
00007a40685d8974  vmovaps xmm0, [rsp]
00007a40685d8979  vmovaps xmm1, [rsp+0x10]
00007a40685d897f  vmovaps xmm2, [rsp+0x20]
00007a40685d8985  vmovaps xmm3, [rsp+0x30]
00007a40685d898b  vmovaps xmm4, [rsp+0x40]
00007a40685d8991  vmovaps xmm5, [rsp+0x50]
00007a40685d8997  vmovaps xmm6, [rsp+0x60]
00007a40685d899d  vmovaps xmm7, [rsp+0x70]
00007a40685d89a3  vmovaps xmm8, [rsp+0x80]
00007a40685d89ac  vmovaps xmm9, [rsp+0x90]
00007a40685d89b5  vmovaps xmm10, [rsp+0xA0]
00007a40685d89be  vmovaps xmm11, [rsp+0xB0]
00007a40685d89c7  vmovaps xmm12, [rsp+0xC0]
00007a40685d89d0  vmovaps xmm13, [rsp+0xD0]
00007a40685d89d9  vmovaps xmm14, [rsp+0xE0]
00007a40685d89e2  add rsp, 0xF0
00007a40685d89e9  pop r11
00007a40685d89eb  pop r10
00007a40685d89ed  pop r9
00007a40685d89ef  pop r8
00007a40685d89f1  pop rsi
00007a40685d89f2  pop rdi
00007a40685d89f3  pop rdx
00007a40685d89f4  pop rcx
00007a40685d89f5  pop rax
00007a40685d89f6  add rsp, 0x08
00007a40685d89fa  jmp 0x00007A40685D60F7
00007a40685d89ff  sub rsp, 0x08
00007a40685d8a03  push rax
00007a40685d8a04  push rcx
00007a40685d8a05  push rdx
00007a40685d8a06  push rdi
00007a40685d8a07  push rsi
00007a40685d8a08  push r8
00007a40685d8a0a  push r9
00007a40685d8a0c  push r10
00007a40685d8a0e  push r11
00007a40685d8a10  sub rsp, 0xF0
00007a40685d8a17  vmovaps [rsp], xmm0
00007a40685d8a1c  vmovaps [rsp+0x10], xmm1
00007a40685d8a22  vmovaps [rsp+0x20], xmm2
00007a40685d8a28  vmovaps [rsp+0x30], xmm3
00007a40685d8a2e  vmovaps [rsp+0x40], xmm4
00007a40685d8a34  vmovaps [rsp+0x50], xmm5
00007a40685d8a3a  vmovaps [rsp+0x60], xmm6
00007a40685d8a40  vmovaps [rsp+0x70], xmm7
00007a40685d8a46  vmovaps [rsp+0x80], xmm8
00007a40685d8a4f  vmovaps [rsp+0x90], xmm9
00007a40685d8a58  vmovaps [rsp+0xA0], xmm10
00007a40685d8a61  vmovaps [rsp+0xB0], xmm11
00007a40685d8a6a  vmovaps [rsp+0xC0], xmm12
00007a40685d8a73  vmovaps [rsp+0xD0], xmm13
00007a40685d8a7c  vmovaps [rsp+0xE0], xmm15
00007a40685d8a85  sub rsp, 0x30
00007a40685d8a89  movaps [rsp], xmm14
00007a40685d8a8e  movaps [rsp+0x10], xmm2
00007a40685d8a93  movaps [rsp+0x20], xmm1
00007a40685d8a98  lea rdi, [rsp]
00007a40685d8a9c  mov esi, 0x00
00007a40685d8aa1  mov rax, 0x56F679577530
00007a40685d8aab  call rax
00007a40685d8aad  movaps xmm14, [rsp]
00007a40685d8ab2  add rsp, 0x30
00007a40685d8ab6  vmovaps xmm0, [rsp]
00007a40685d8abb  vmovaps xmm1, [rsp+0x10]
00007a40685d8ac1  vmovaps xmm2, [rsp+0x20]
00007a40685d8ac7  vmovaps xmm3, [rsp+0x30]
00007a40685d8acd  vmovaps xmm4, [rsp+0x40]
00007a40685d8ad3  vmovaps xmm5, [rsp+0x50]
00007a40685d8ad9  vmovaps xmm6, [rsp+0x60]
00007a40685d8adf  vmovaps xmm7, [rsp+0x70]
00007a40685d8ae5  vmovaps xmm8, [rsp+0x80]
00007a40685d8aee  vmovaps xmm9, [rsp+0x90]
00007a40685d8af7  vmovaps xmm10, [rsp+0xA0]
00007a40685d8b00  vmovaps xmm11, [rsp+0xB0]
00007a40685d8b09  vmovaps xmm12, [rsp+0xC0]
00007a40685d8b12  vmovaps xmm13, [rsp+0xD0]
00007a40685d8b1b  vmovaps xmm15, [rsp+0xE0]
00007a40685d8b24  add rsp, 0xF0
00007a40685d8b2b  pop r11
00007a40685d8b2d  pop r10
00007a40685d8b2f  pop r9
00007a40685d8b31  pop r8
00007a40685d8b33  pop rsi
00007a40685d8b34  pop rdi
00007a40685d8b35  pop rdx
00007a40685d8b36  pop rcx
00007a40685d8b37  pop rax
00007a40685d8b38  add rsp, 0x08
00007a40685d8b3c  jmp 0x00007A40685D611D
00007a40685d8b41  sub rsp, 0x08
00007a40685d8b45  push rax
00007a40685d8b46  push rcx
00007a40685d8b47  push rdx
00007a40685d8b48  push rdi
00007a40685d8b49  push rsi
00007a40685d8b4a  push r8
00007a40685d8b4c  push r9
00007a40685d8b4e  push r10
00007a40685d8b50  push r11
00007a40685d8b52  sub rsp, 0xF0
00007a40685d8b59  vmovaps [rsp], xmm0
00007a40685d8b5e  vmovaps [rsp+0x10], xmm2
00007a40685d8b64  vmovaps [rsp+0x20], xmm3
00007a40685d8b6a  vmovaps [rsp+0x30], xmm4
00007a40685d8b70  vmovaps [rsp+0x40], xmm5
00007a40685d8b76  vmovaps [rsp+0x50], xmm6
00007a40685d8b7c  vmovaps [rsp+0x60], xmm7
00007a40685d8b82  vmovaps [rsp+0x70], xmm8
00007a40685d8b88  vmovaps [rsp+0x80], xmm9
00007a40685d8b91  vmovaps [rsp+0x90], xmm10
00007a40685d8b9a  vmovaps [rsp+0xA0], xmm11
00007a40685d8ba3  vmovaps [rsp+0xB0], xmm12
00007a40685d8bac  vmovaps [rsp+0xC0], xmm13
00007a40685d8bb5  vmovaps [rsp+0xD0], xmm14
00007a40685d8bbe  vmovaps [rsp+0xE0], xmm15
00007a40685d8bc7  sub rsp, 0x30
00007a40685d8bcb  movaps [rsp], xmm1
00007a40685d8bcf  movaps [rsp+0x10], xmm4
00007a40685d8bd4  movaps [rsp+0x20], xmm9
00007a40685d8bda  lea rdi, [rsp]
00007a40685d8bde  mov esi, 0x00
00007a40685d8be3  mov rax, 0x56F679577530
00007a40685d8bed  call rax
00007a40685d8bef  movaps xmm1, [rsp]
00007a40685d8bf3  add rsp, 0x30
00007a40685d8bf7  vmovaps xmm0, [rsp]
00007a40685d8bfc  vmovaps xmm2, [rsp+0x10]
00007a40685d8c02  vmovaps xmm3, [rsp+0x20]
00007a40685d8c08  vmovaps xmm4, [rsp+0x30]
00007a40685d8c0e  vmovaps xmm5, [rsp+0x40]
00007a40685d8c14  vmovaps xmm6, [rsp+0x50]
00007a40685d8c1a  vmovaps xmm7, [rsp+0x60]
00007a40685d8c20  vmovaps xmm8, [rsp+0x70]
00007a40685d8c26  vmovaps xmm9, [rsp+0x80]
00007a40685d8c2f  vmovaps xmm10, [rsp+0x90]
00007a40685d8c38  vmovaps xmm11, [rsp+0xA0]
00007a40685d8c41  vmovaps xmm12, [rsp+0xB0]
00007a40685d8c4a  vmovaps xmm13, [rsp+0xC0]
00007a40685d8c53  vmovaps xmm14, [rsp+0xD0]
00007a40685d8c5c  vmovaps xmm15, [rsp+0xE0]
00007a40685d8c65  add rsp, 0xF0
00007a40685d8c6c  pop r11
00007a40685d8c6e  pop r10
00007a40685d8c70  pop r9
00007a40685d8c72  pop r8
00007a40685d8c74  pop rsi
00007a40685d8c75  pop rdi
00007a40685d8c76  pop rdx
00007a40685d8c77  pop rcx
00007a40685d8c78  pop rax
00007a40685d8c79  add rsp, 0x08
00007a40685d8c7d  jmp 0x00007A40685D613B
00007a40685d8c82  sub rsp, 0x08
00007a40685d8c86  push rax
00007a40685d8c87  push rcx
00007a40685d8c88  push rdx
00007a40685d8c89  push rdi
00007a40685d8c8a  push rsi
00007a40685d8c8b  push r8
00007a40685d8c8d  push r9
00007a40685d8c8f  push r10
00007a40685d8c91  push r11
00007a40685d8c93  sub rsp, 0xF0
00007a40685d8c9a  vmovaps [rsp], xmm0
00007a40685d8c9f  vmovaps [rsp+0x10], xmm1
00007a40685d8ca5  vmovaps [rsp+0x20], xmm2
00007a40685d8cab  vmovaps [rsp+0x30], xmm3
00007a40685d8cb1  vmovaps [rsp+0x40], xmm5
00007a40685d8cb7  vmovaps [rsp+0x50], xmm6
00007a40685d8cbd  vmovaps [rsp+0x60], xmm7
00007a40685d8cc3  vmovaps [rsp+0x70], xmm8
00007a40685d8cc9  vmovaps [rsp+0x80], xmm9
00007a40685d8cd2  vmovaps [rsp+0x90], xmm10
00007a40685d8cdb  vmovaps [rsp+0xA0], xmm11
00007a40685d8ce4  vmovaps [rsp+0xB0], xmm12
00007a40685d8ced  vmovaps [rsp+0xC0], xmm13
00007a40685d8cf6  vmovaps [rsp+0xD0], xmm14
00007a40685d8cff  vmovaps [rsp+0xE0], xmm15
00007a40685d8d08  sub rsp, 0x30
00007a40685d8d0c  movaps [rsp], xmm4
00007a40685d8d10  movaps [rsp+0x10], xmm2
00007a40685d8d15  movaps [rsp+0x20], xmm9
00007a40685d8d1b  lea rdi, [rsp]
00007a40685d8d1f  mov esi, 0x00
00007a40685d8d24  mov rax, 0x56F679577530
00007a40685d8d2e  call rax
00007a40685d8d30  movaps xmm4, [rsp]
00007a40685d8d34  add rsp, 0x30
00007a40685d8d38  vmovaps xmm0, [rsp]
00007a40685d8d3d  vmovaps xmm1, [rsp+0x10]
00007a40685d8d43  vmovaps xmm2, [rsp+0x20]
00007a40685d8d49  vmovaps xmm3, [rsp+0x30]
00007a40685d8d4f  vmovaps xmm5, [rsp+0x40]
00007a40685d8d55  vmovaps xmm6, [rsp+0x50]
00007a40685d8d5b  vmovaps xmm7, [rsp+0x60]
00007a40685d8d61  vmovaps xmm8, [rsp+0x70]
00007a40685d8d67  vmovaps xmm9, [rsp+0x80]
00007a40685d8d70  vmovaps xmm10, [rsp+0x90]
00007a40685d8d79  vmovaps xmm11, [rsp+0xA0]
00007a40685d8d82  vmovaps xmm12, [rsp+0xB0]
00007a40685d8d8b  vmovaps xmm13, [rsp+0xC0]
00007a40685d8d94  vmovaps xmm14, [rsp+0xD0]
00007a40685d8d9d  vmovaps xmm15, [rsp+0xE0]
00007a40685d8da6  add rsp, 0xF0
00007a40685d8dad  pop r11
00007a40685d8daf  pop r10
00007a40685d8db1  pop r9
00007a40685d8db3  pop r8
00007a40685d8db5  pop rsi
00007a40685d8db6  pop rdi
00007a40685d8db7  pop rdx
00007a40685d8db8  pop rcx
00007a40685d8db9  pop rax
00007a40685d8dba  add rsp, 0x08
00007a40685d8dbe  jmp 0x00007A40685D616B
00007a40685d8dc3  sub rsp, 0x08
00007a40685d8dc7  push rax
00007a40685d8dc8  push rcx
00007a40685d8dc9  push rdx
00007a40685d8dca  push rdi
00007a40685d8dcb  push rsi
00007a40685d8dcc  push r8
00007a40685d8dce  push r9
00007a40685d8dd0  push r10
00007a40685d8dd2  push r11
00007a40685d8dd4  sub rsp, 0xF0
00007a40685d8ddb  vmovaps [rsp], xmm0
00007a40685d8de0  vmovaps [rsp+0x10], xmm1
00007a40685d8de6  vmovaps [rsp+0x20], xmm2
00007a40685d8dec  vmovaps [rsp+0x30], xmm3
00007a40685d8df2  vmovaps [rsp+0x40], xmm4
00007a40685d8df8  vmovaps [rsp+0x50], xmm5
00007a40685d8dfe  vmovaps [rsp+0x60], xmm6
00007a40685d8e04  vmovaps [rsp+0x70], xmm7
00007a40685d8e0a  vmovaps [rsp+0x80], xmm8
00007a40685d8e13  vmovaps [rsp+0x90], xmm10
00007a40685d8e1c  vmovaps [rsp+0xA0], xmm11
00007a40685d8e25  vmovaps [rsp+0xB0], xmm12
00007a40685d8e2e  vmovaps [rsp+0xC0], xmm13
00007a40685d8e37  vmovaps [rsp+0xD0], xmm14
00007a40685d8e40  vmovaps [rsp+0xE0], xmm15
00007a40685d8e49  sub rsp, 0x30
00007a40685d8e4d  movaps [rsp], xmm9
00007a40685d8e52  movaps [rsp+0x10], xmm2
00007a40685d8e57  movaps [rsp+0x20], xmm1
00007a40685d8e5c  lea rdi, [rsp]
00007a40685d8e60  mov esi, 0x00
00007a40685d8e65  mov rax, 0x56F679577530
00007a40685d8e6f  call rax
00007a40685d8e71  movaps xmm9, [rsp]
00007a40685d8e76  add rsp, 0x30
00007a40685d8e7a  vmovaps xmm0, [rsp]
00007a40685d8e7f  vmovaps xmm1, [rsp+0x10]
00007a40685d8e85  vmovaps xmm2, [rsp+0x20]
00007a40685d8e8b  vmovaps xmm3, [rsp+0x30]
00007a40685d8e91  vmovaps xmm4, [rsp+0x40]
00007a40685d8e97  vmovaps xmm5, [rsp+0x50]
00007a40685d8e9d  vmovaps xmm6, [rsp+0x60]
00007a40685d8ea3  vmovaps xmm7, [rsp+0x70]
00007a40685d8ea9  vmovaps xmm8, [rsp+0x80]
00007a40685d8eb2  vmovaps xmm10, [rsp+0x90]
00007a40685d8ebb  vmovaps xmm11, [rsp+0xA0]
00007a40685d8ec4  vmovaps xmm12, [rsp+0xB0]
00007a40685d8ecd  vmovaps xmm13, [rsp+0xC0]
00007a40685d8ed6  vmovaps xmm14, [rsp+0xD0]
00007a40685d8edf  vmovaps xmm15, [rsp+0xE0]
00007a40685d8ee8  add rsp, 0xF0
00007a40685d8eef  pop r11
00007a40685d8ef1  pop r10
00007a40685d8ef3  pop r9
00007a40685d8ef5  pop r8
00007a40685d8ef7  pop rsi
00007a40685d8ef8  pop rdi
00007a40685d8ef9  pop rdx
00007a40685d8efa  pop rcx
00007a40685d8efb  pop rax
00007a40685d8efc  add rsp, 0x08
00007a40685d8f00  jmp 0x00007A40685D61A1
00007a40685d8f05  sub rsp, 0x08
00007a40685d8f09  push rax
00007a40685d8f0a  push rcx
00007a40685d8f0b  push rdx
00007a40685d8f0c  push rdi
00007a40685d8f0d  push rsi
00007a40685d8f0e  push r8
00007a40685d8f10  push r9
00007a40685d8f12  push r10
00007a40685d8f14  push r11
00007a40685d8f16  sub rsp, 0xF0
00007a40685d8f1d  vmovaps [rsp], xmm0
00007a40685d8f22  vmovaps [rsp+0x10], xmm2
00007a40685d8f28  vmovaps [rsp+0x20], xmm3
00007a40685d8f2e  vmovaps [rsp+0x30], xmm4
00007a40685d8f34  vmovaps [rsp+0x40], xmm5
00007a40685d8f3a  vmovaps [rsp+0x50], xmm6
00007a40685d8f40  vmovaps [rsp+0x60], xmm7
00007a40685d8f46  vmovaps [rsp+0x70], xmm8
00007a40685d8f4c  vmovaps [rsp+0x80], xmm9
00007a40685d8f55  vmovaps [rsp+0x90], xmm10
00007a40685d8f5e  vmovaps [rsp+0xA0], xmm11
00007a40685d8f67  vmovaps [rsp+0xB0], xmm12
00007a40685d8f70  vmovaps [rsp+0xC0], xmm13
00007a40685d8f79  vmovaps [rsp+0xD0], xmm14
00007a40685d8f82  vmovaps [rsp+0xE0], xmm15
00007a40685d8f8b  sub rsp, 0x30
00007a40685d8f8f  movaps [rsp], xmm1
00007a40685d8f93  movaps [rsp+0x10], xmm15
00007a40685d8f99  movaps [rsp+0x20], xmm6
00007a40685d8f9e  lea rdi, [rsp]
00007a40685d8fa2  mov esi, 0x00
00007a40685d8fa7  mov rax, 0x56F679577530
00007a40685d8fb1  call rax
00007a40685d8fb3  movaps xmm1, [rsp]
00007a40685d8fb7  add rsp, 0x30
00007a40685d8fbb  vmovaps xmm0, [rsp]
00007a40685d8fc0  vmovaps xmm2, [rsp+0x10]
00007a40685d8fc6  vmovaps xmm3, [rsp+0x20]
00007a40685d8fcc  vmovaps xmm4, [rsp+0x30]
00007a40685d8fd2  vmovaps xmm5, [rsp+0x40]
00007a40685d8fd8  vmovaps xmm6, [rsp+0x50]
00007a40685d8fde  vmovaps xmm7, [rsp+0x60]
00007a40685d8fe4  vmovaps xmm8, [rsp+0x70]
00007a40685d8fea  vmovaps xmm9, [rsp+0x80]
00007a40685d8ff3  vmovaps xmm10, [rsp+0x90]
00007a40685d8ffc  vmovaps xmm11, [rsp+0xA0]
00007a40685d9005  vmovaps xmm12, [rsp+0xB0]
00007a40685d900e  vmovaps xmm13, [rsp+0xC0]
00007a40685d9017  vmovaps xmm14, [rsp+0xD0]
00007a40685d9020  vmovaps xmm15, [rsp+0xE0]
00007a40685d9029  add rsp, 0xF0
00007a40685d9030  pop r11
00007a40685d9032  pop r10
00007a40685d9034  pop r9
00007a40685d9036  pop r8
00007a40685d9038  pop rsi
00007a40685d9039  pop rdi
00007a40685d903a  pop rdx
00007a40685d903b  pop rcx
00007a40685d903c  pop rax
00007a40685d903d  add rsp, 0x08
00007a40685d9041  jmp 0x00007A40685D61C2
00007a40685d9046  sub rsp, 0x08
00007a40685d904a  push rax
00007a40685d904b  push rcx
00007a40685d904c  push rdx
00007a40685d904d  push rdi
00007a40685d904e  push rsi
00007a40685d904f  push r8
00007a40685d9051  push r9
00007a40685d9053  push r10
00007a40685d9055  push r11
00007a40685d9057  sub rsp, 0xF0
00007a40685d905e  vmovaps [rsp], xmm0
00007a40685d9063  vmovaps [rsp+0x10], xmm1
00007a40685d9069  vmovaps [rsp+0x20], xmm2
00007a40685d906f  vmovaps [rsp+0x30], xmm3
00007a40685d9075  vmovaps [rsp+0x40], xmm4
00007a40685d907b  vmovaps [rsp+0x50], xmm5
00007a40685d9081  vmovaps [rsp+0x60], xmm6
00007a40685d9087  vmovaps [rsp+0x70], xmm7
00007a40685d908d  vmovaps [rsp+0x80], xmm8
00007a40685d9096  vmovaps [rsp+0x90], xmm9
00007a40685d909f  vmovaps [rsp+0xA0], xmm10
00007a40685d90a8  vmovaps [rsp+0xB0], xmm11
00007a40685d90b1  vmovaps [rsp+0xC0], xmm12
00007a40685d90ba  vmovaps [rsp+0xD0], xmm13
00007a40685d90c3  vmovaps [rsp+0xE0], xmm14
00007a40685d90cc  sub rsp, 0x30
00007a40685d90d0  movaps [rsp], xmm15
00007a40685d90d5  movaps [rsp+0x10], xmm5
00007a40685d90da  movaps [rsp+0x20], xmm3
00007a40685d90df  lea rdi, [rsp]
00007a40685d90e3  mov esi, 0x00
00007a40685d90e8  mov rax, 0x56F679577530
00007a40685d90f2  call rax
00007a40685d90f4  movaps xmm15, [rsp]
00007a40685d90f9  add rsp, 0x30
00007a40685d90fd  vmovaps xmm0, [rsp]
00007a40685d9102  vmovaps xmm1, [rsp+0x10]
00007a40685d9108  vmovaps xmm2, [rsp+0x20]
00007a40685d910e  vmovaps xmm3, [rsp+0x30]
00007a40685d9114  vmovaps xmm4, [rsp+0x40]
00007a40685d911a  vmovaps xmm5, [rsp+0x50]
00007a40685d9120  vmovaps xmm6, [rsp+0x60]
00007a40685d9126  vmovaps xmm7, [rsp+0x70]
00007a40685d912c  vmovaps xmm8, [rsp+0x80]
00007a40685d9135  vmovaps xmm9, [rsp+0x90]
00007a40685d913e  vmovaps xmm10, [rsp+0xA0]
00007a40685d9147  vmovaps xmm11, [rsp+0xB0]
00007a40685d9150  vmovaps xmm12, [rsp+0xC0]
00007a40685d9159  vmovaps xmm13, [rsp+0xD0]
00007a40685d9162  vmovaps xmm14, [rsp+0xE0]
00007a40685d916b  add rsp, 0xF0
00007a40685d9172  pop r11
00007a40685d9174  pop r10
00007a40685d9176  pop r9
00007a40685d9178  pop r8
00007a40685d917a  pop rsi
00007a40685d917b  pop rdi
00007a40685d917c  pop rdx
00007a40685d917d  pop rcx
00007a40685d917e  pop rax
00007a40685d917f  add rsp, 0x08
00007a40685d9183  jmp 0x00007A40685D61DC
00007a40685d9188  sub rsp, 0x08
00007a40685d918c  push rax
00007a40685d918d  push rcx
00007a40685d918e  push rdx
00007a40685d918f  push rdi
00007a40685d9190  push rsi
00007a40685d9191  push r8
00007a40685d9193  push r9
00007a40685d9195  push r10
00007a40685d9197  push r11
00007a40685d9199  sub rsp, 0xF0
00007a40685d91a0  vmovaps [rsp], xmm0
00007a40685d91a5  vmovaps [rsp+0x10], xmm1
00007a40685d91ab  vmovaps [rsp+0x20], xmm2
00007a40685d91b1  vmovaps [rsp+0x30], xmm3
00007a40685d91b7  vmovaps [rsp+0x40], xmm4
00007a40685d91bd  vmovaps [rsp+0x50], xmm6
00007a40685d91c3  vmovaps [rsp+0x60], xmm7
00007a40685d91c9  vmovaps [rsp+0x70], xmm8
00007a40685d91cf  vmovaps [rsp+0x80], xmm9
00007a40685d91d8  vmovaps [rsp+0x90], xmm10
00007a40685d91e1  vmovaps [rsp+0xA0], xmm11
00007a40685d91ea  vmovaps [rsp+0xB0], xmm12
00007a40685d91f3  vmovaps [rsp+0xC0], xmm13
00007a40685d91fc  vmovaps [rsp+0xD0], xmm14
00007a40685d9205  vmovaps [rsp+0xE0], xmm15
00007a40685d920e  sub rsp, 0x30
00007a40685d9212  movaps [rsp], xmm5
00007a40685d9216  movaps [rsp+0x10], xmm8
00007a40685d921c  movaps [rsp+0x20], xmm6
00007a40685d9221  lea rdi, [rsp]
00007a40685d9225  mov esi, 0x00
00007a40685d922a  mov rax, 0x56F679577530
00007a40685d9234  call rax
00007a40685d9236  movaps xmm5, [rsp]
00007a40685d923a  add rsp, 0x30
00007a40685d923e  vmovaps xmm0, [rsp]
00007a40685d9243  vmovaps xmm1, [rsp+0x10]
00007a40685d9249  vmovaps xmm2, [rsp+0x20]
00007a40685d924f  vmovaps xmm3, [rsp+0x30]
00007a40685d9255  vmovaps xmm4, [rsp+0x40]
00007a40685d925b  vmovaps xmm6, [rsp+0x50]
00007a40685d9261  vmovaps xmm7, [rsp+0x60]
00007a40685d9267  vmovaps xmm8, [rsp+0x70]
00007a40685d926d  vmovaps xmm9, [rsp+0x80]
00007a40685d9276  vmovaps xmm10, [rsp+0x90]
00007a40685d927f  vmovaps xmm11, [rsp+0xA0]
00007a40685d9288  vmovaps xmm12, [rsp+0xB0]
00007a40685d9291  vmovaps xmm13, [rsp+0xC0]
00007a40685d929a  vmovaps xmm14, [rsp+0xD0]
00007a40685d92a3  vmovaps xmm15, [rsp+0xE0]
00007a40685d92ac  add rsp, 0xF0
00007a40685d92b3  pop r11
00007a40685d92b5  pop r10
00007a40685d92b7  pop r9
00007a40685d92b9  pop r8
00007a40685d92bb  pop rsi
00007a40685d92bc  pop rdi
00007a40685d92bd  pop rdx
00007a40685d92be  pop rcx
00007a40685d92bf  pop rax
00007a40685d92c0  add rsp, 0x08
00007a40685d92c4  jmp 0x00007A40685D6200
00007a40685d92c9  sub rsp, 0x08
00007a40685d92cd  push rax
00007a40685d92ce  push rcx
00007a40685d92cf  push rdx
00007a40685d92d0  push rdi
00007a40685d92d1  push rsi
00007a40685d92d2  push r8
00007a40685d92d4  push r9
00007a40685d92d6  push r10
00007a40685d92d8  push r11
00007a40685d92da  sub rsp, 0xF0
00007a40685d92e1  vmovaps [rsp], xmm0
00007a40685d92e6  vmovaps [rsp+0x10], xmm1
00007a40685d92ec  vmovaps [rsp+0x20], xmm2
00007a40685d92f2  vmovaps [rsp+0x30], xmm3
00007a40685d92f8  vmovaps [rsp+0x40], xmm4
00007a40685d92fe  vmovaps [rsp+0x50], xmm5
00007a40685d9304  vmovaps [rsp+0x60], xmm7
00007a40685d930a  vmovaps [rsp+0x70], xmm8
00007a40685d9310  vmovaps [rsp+0x80], xmm9
00007a40685d9319  vmovaps [rsp+0x90], xmm10
00007a40685d9322  vmovaps [rsp+0xA0], xmm11
00007a40685d932b  vmovaps [rsp+0xB0], xmm12
00007a40685d9334  vmovaps [rsp+0xC0], xmm13
00007a40685d933d  vmovaps [rsp+0xD0], xmm14
00007a40685d9346  vmovaps [rsp+0xE0], xmm15
00007a40685d934f  sub rsp, 0x30
00007a40685d9353  movaps [rsp], xmm6
00007a40685d9357  movaps [rsp+0x10], xmm10
00007a40685d935d  movaps [rsp+0x20], xmm8
00007a40685d9363  lea rdi, [rsp]
00007a40685d9367  mov esi, 0x00
00007a40685d936c  mov rax, 0x56F679577530
00007a40685d9376  call rax
00007a40685d9378  movaps xmm6, [rsp]
00007a40685d937c  add rsp, 0x30
00007a40685d9380  vmovaps xmm0, [rsp]
00007a40685d9385  vmovaps xmm1, [rsp+0x10]
00007a40685d938b  vmovaps xmm2, [rsp+0x20]
00007a40685d9391  vmovaps xmm3, [rsp+0x30]
00007a40685d9397  vmovaps xmm4, [rsp+0x40]
00007a40685d939d  vmovaps xmm5, [rsp+0x50]
00007a40685d93a3  vmovaps xmm7, [rsp+0x60]
00007a40685d93a9  vmovaps xmm8, [rsp+0x70]
00007a40685d93af  vmovaps xmm9, [rsp+0x80]
00007a40685d93b8  vmovaps xmm10, [rsp+0x90]
00007a40685d93c1  vmovaps xmm11, [rsp+0xA0]
00007a40685d93ca  vmovaps xmm12, [rsp+0xB0]
00007a40685d93d3  vmovaps xmm13, [rsp+0xC0]
00007a40685d93dc  vmovaps xmm14, [rsp+0xD0]
00007a40685d93e5  vmovaps xmm15, [rsp+0xE0]
00007a40685d93ee  add rsp, 0xF0
00007a40685d93f5  pop r11
00007a40685d93f7  pop r10
00007a40685d93f9  pop r9
00007a40685d93fb  pop r8
00007a40685d93fd  pop rsi
00007a40685d93fe  pop rdi
00007a40685d93ff  pop rdx
00007a40685d9400  pop rcx
00007a40685d9401  pop rax
00007a40685d9402  add rsp, 0x08
00007a40685d9406  jmp 0x00007A40685D6225
00007a40685d940b  sub rsp, 0x08
00007a40685d940f  push rax
00007a40685d9410  push rcx
00007a40685d9411  push rdx
00007a40685d9412  push rdi
00007a40685d9413  push rsi
00007a40685d9414  push r8
00007a40685d9416  push r9
00007a40685d9418  push r10
00007a40685d941a  push r11
00007a40685d941c  sub rsp, 0xF0
00007a40685d9423  vmovaps [rsp], xmm0
00007a40685d9428  vmovaps [rsp+0x10], xmm1
00007a40685d942e  vmovaps [rsp+0x20], xmm2
00007a40685d9434  vmovaps [rsp+0x30], xmm3
00007a40685d943a  vmovaps [rsp+0x40], xmm4
00007a40685d9440  vmovaps [rsp+0x50], xmm5
00007a40685d9446  vmovaps [rsp+0x60], xmm6
00007a40685d944c  vmovaps [rsp+0x70], xmm7
00007a40685d9452  vmovaps [rsp+0x80], xmm8
00007a40685d945b  vmovaps [rsp+0x90], xmm9
00007a40685d9464  vmovaps [rsp+0xA0], xmm11
00007a40685d946d  vmovaps [rsp+0xB0], xmm12
00007a40685d9476  vmovaps [rsp+0xC0], xmm13
00007a40685d947f  vmovaps [rsp+0xD0], xmm14
00007a40685d9488  vmovaps [rsp+0xE0], xmm15
00007a40685d9491  sub rsp, 0x30
00007a40685d9495  movaps [rsp], xmm10
00007a40685d949a  movaps [rsp+0x10], xmm8
00007a40685d94a0  movaps [rsp+0x20], xmm14
00007a40685d94a6  lea rdi, [rsp]
00007a40685d94aa  mov esi, 0x00
00007a40685d94af  mov rax, 0x56F679577530
00007a40685d94b9  call rax
00007a40685d94bb  movaps xmm10, [rsp]
00007a40685d94c0  add rsp, 0x30
00007a40685d94c4  vmovaps xmm0, [rsp]
00007a40685d94c9  vmovaps xmm1, [rsp+0x10]
00007a40685d94cf  vmovaps xmm2, [rsp+0x20]
00007a40685d94d5  vmovaps xmm3, [rsp+0x30]
00007a40685d94db  vmovaps xmm4, [rsp+0x40]
00007a40685d94e1  vmovaps xmm5, [rsp+0x50]
00007a40685d94e7  vmovaps xmm6, [rsp+0x60]
00007a40685d94ed  vmovaps xmm7, [rsp+0x70]
00007a40685d94f3  vmovaps xmm8, [rsp+0x80]
00007a40685d94fc  vmovaps xmm9, [rsp+0x90]
00007a40685d9505  vmovaps xmm11, [rsp+0xA0]
00007a40685d950e  vmovaps xmm12, [rsp+0xB0]
00007a40685d9517  vmovaps xmm13, [rsp+0xC0]
00007a40685d9520  vmovaps xmm14, [rsp+0xD0]
00007a40685d9529  vmovaps xmm15, [rsp+0xE0]
00007a40685d9532  add rsp, 0xF0
00007a40685d9539  pop r11
00007a40685d953b  pop r10
00007a40685d953d  pop r9
00007a40685d953f  pop r8
00007a40685d9541  pop rsi
00007a40685d9542  pop rdi
00007a40685d9543  pop rdx
00007a40685d9544  pop rcx
00007a40685d9545  pop rax
00007a40685d9546  add rsp, 0x08
00007a40685d954a  jmp 0x00007A40685D6245
00007a40685d954f  sub rsp, 0x08
00007a40685d9553  push rax
00007a40685d9554  push rcx
00007a40685d9555  push rdx
00007a40685d9556  push rdi
00007a40685d9557  push rsi
00007a40685d9558  push r8
00007a40685d955a  push r9
00007a40685d955c  push r10
00007a40685d955e  push r11
00007a40685d9560  sub rsp, 0xF0
00007a40685d9567  vmovaps [rsp], xmm0
00007a40685d956c  vmovaps [rsp+0x10], xmm1
00007a40685d9572  vmovaps [rsp+0x20], xmm2
00007a40685d9578  vmovaps [rsp+0x30], xmm3
00007a40685d957e  vmovaps [rsp+0x40], xmm4
00007a40685d9584  vmovaps [rsp+0x50], xmm5
00007a40685d958a  vmovaps [rsp+0x60], xmm6
00007a40685d9590  vmovaps [rsp+0x70], xmm7
00007a40685d9596  vmovaps [rsp+0x80], xmm8
00007a40685d959f  vmovaps [rsp+0x90], xmm9
00007a40685d95a8  vmovaps [rsp+0xA0], xmm10
00007a40685d95b1  vmovaps [rsp+0xB0], xmm11
00007a40685d95ba  vmovaps [rsp+0xC0], xmm12
00007a40685d95c3  vmovaps [rsp+0xD0], xmm13
00007a40685d95cc  vmovaps [rsp+0xE0], xmm15
00007a40685d95d5  sub rsp, 0x30
00007a40685d95d9  movaps [rsp], xmm14
00007a40685d95de  movaps [rsp+0x10], xmm8
00007a40685d95e4  movaps [rsp+0x20], xmm4
00007a40685d95e9  lea rdi, [rsp]
00007a40685d95ed  mov esi, 0x00
00007a40685d95f2  mov rax, 0x56F679577530
00007a40685d95fc  call rax
00007a40685d95fe  movaps xmm14, [rsp]
00007a40685d9603  add rsp, 0x30
00007a40685d9607  vmovaps xmm0, [rsp]
00007a40685d960c  vmovaps xmm1, [rsp+0x10]
00007a40685d9612  vmovaps xmm2, [rsp+0x20]
00007a40685d9618  vmovaps xmm3, [rsp+0x30]
00007a40685d961e  vmovaps xmm4, [rsp+0x40]
00007a40685d9624  vmovaps xmm5, [rsp+0x50]
00007a40685d962a  vmovaps xmm6, [rsp+0x60]
00007a40685d9630  vmovaps xmm7, [rsp+0x70]
00007a40685d9636  vmovaps xmm8, [rsp+0x80]
00007a40685d963f  vmovaps xmm9, [rsp+0x90]
00007a40685d9648  vmovaps xmm10, [rsp+0xA0]
00007a40685d9651  vmovaps xmm11, [rsp+0xB0]
00007a40685d965a  vmovaps xmm12, [rsp+0xC0]
00007a40685d9663  vmovaps xmm13, [rsp+0xD0]
00007a40685d966c  vmovaps xmm15, [rsp+0xE0]
00007a40685d9675  add rsp, 0xF0
00007a40685d967c  pop r11
00007a40685d967e  pop r10
00007a40685d9680  pop r9
00007a40685d9682  pop r8
00007a40685d9684  pop rsi
00007a40685d9685  pop rdi
00007a40685d9686  pop rdx
00007a40685d9687  pop rcx
00007a40685d9688  pop rax
00007a40685d9689  add rsp, 0x08
00007a40685d968d  jmp 0x00007A40685D6265
00007a40685d9692  sub rsp, 0x08
00007a40685d9696  push rax
00007a40685d9697  push rcx
00007a40685d9698  push rdx
00007a40685d9699  push rdi
00007a40685d969a  push rsi
00007a40685d969b  push r8
00007a40685d969d  push r9
00007a40685d969f  push r10
00007a40685d96a1  push r11
00007a40685d96a3  sub rsp, 0xF0
00007a40685d96aa  vmovaps [rsp], xmm0
00007a40685d96af  vmovaps [rsp+0x10], xmm1
00007a40685d96b5  vmovaps [rsp+0x20], xmm2
00007a40685d96bb  vmovaps [rsp+0x30], xmm3
00007a40685d96c1  vmovaps [rsp+0x40], xmm5
00007a40685d96c7  vmovaps [rsp+0x50], xmm6
00007a40685d96cd  vmovaps [rsp+0x60], xmm7
00007a40685d96d3  vmovaps [rsp+0x70], xmm8
00007a40685d96d9  vmovaps [rsp+0x80], xmm9
00007a40685d96e2  vmovaps [rsp+0x90], xmm10
00007a40685d96eb  vmovaps [rsp+0xA0], xmm11
00007a40685d96f4  vmovaps [rsp+0xB0], xmm12
00007a40685d96fd  vmovaps [rsp+0xC0], xmm13
00007a40685d9706  vmovaps [rsp+0xD0], xmm14
00007a40685d970f  vmovaps [rsp+0xE0], xmm15
00007a40685d9718  sub rsp, 0x30
00007a40685d971c  movaps [rsp], xmm4
00007a40685d9720  movaps [rsp+0x10], xmm13
00007a40685d9726  movaps [rsp+0x20], xmm8
00007a40685d972c  lea rdi, [rsp]
00007a40685d9730  mov esi, 0x00
00007a40685d9735  mov rax, 0x56F679577530
00007a40685d973f  call rax
00007a40685d9741  movaps xmm4, [rsp]
00007a40685d9745  add rsp, 0x30
00007a40685d9749  vmovaps xmm0, [rsp]
00007a40685d974e  vmovaps xmm1, [rsp+0x10]
00007a40685d9754  vmovaps xmm2, [rsp+0x20]
00007a40685d975a  vmovaps xmm3, [rsp+0x30]
00007a40685d9760  vmovaps xmm5, [rsp+0x40]
00007a40685d9766  vmovaps xmm6, [rsp+0x50]
00007a40685d976c  vmovaps xmm7, [rsp+0x60]
00007a40685d9772  vmovaps xmm8, [rsp+0x70]
00007a40685d9778  vmovaps xmm9, [rsp+0x80]
00007a40685d9781  vmovaps xmm10, [rsp+0x90]
00007a40685d978a  vmovaps xmm11, [rsp+0xA0]
00007a40685d9793  vmovaps xmm12, [rsp+0xB0]
00007a40685d979c  vmovaps xmm13, [rsp+0xC0]
00007a40685d97a5  vmovaps xmm14, [rsp+0xD0]
00007a40685d97ae  vmovaps xmm15, [rsp+0xE0]
00007a40685d97b7  add rsp, 0xF0
00007a40685d97be  pop r11
00007a40685d97c0  pop r10
00007a40685d97c2  pop r9
00007a40685d97c4  pop r8
00007a40685d97c6  pop rsi
00007a40685d97c7  pop rdi
00007a40685d97c8  pop rdx
00007a40685d97c9  pop rcx
00007a40685d97ca  pop rax
00007a40685d97cb  add rsp, 0x08
00007a40685d97cf  jmp 0x00007A40685D628A
00007a40685d97d4  sub rsp, 0x08
00007a40685d97d8  push rax
00007a40685d97d9  push rcx
00007a40685d97da  push rdx
00007a40685d97db  push rdi
00007a40685d97dc  push rsi
00007a40685d97dd  push r8
00007a40685d97df  push r9
00007a40685d97e1  push r10
00007a40685d97e3  push r11
00007a40685d97e5  sub rsp, 0xF0
00007a40685d97ec  vmovaps [rsp], xmm0
00007a40685d97f1  vmovaps [rsp+0x10], xmm1
00007a40685d97f7  vmovaps [rsp+0x20], xmm2
00007a40685d97fd  vmovaps [rsp+0x30], xmm3
00007a40685d9803  vmovaps [rsp+0x40], xmm4
00007a40685d9809  vmovaps [rsp+0x50], xmm5
00007a40685d980f  vmovaps [rsp+0x60], xmm6
00007a40685d9815  vmovaps [rsp+0x70], xmm7
00007a40685d981b  vmovaps [rsp+0x80], xmm8
00007a40685d9824  vmovaps [rsp+0x90], xmm9
00007a40685d982d  vmovaps [rsp+0xA0], xmm10
00007a40685d9836  vmovaps [rsp+0xB0], xmm11
00007a40685d983f  vmovaps [rsp+0xC0], xmm12
00007a40685d9848  vmovaps [rsp+0xD0], xmm14
00007a40685d9851  vmovaps [rsp+0xE0], xmm15
00007a40685d985a  sub rsp, 0x30
00007a40685d985e  movaps [rsp], xmm13
00007a40685d9863  movaps [rsp+0x10], xmm15
00007a40685d9869  movaps [rsp+0x20], xmm9
00007a40685d986f  lea rdi, [rsp]
00007a40685d9873  mov esi, 0x00
00007a40685d9878  mov rax, 0x56F679577530
00007a40685d9882  call rax
00007a40685d9884  movaps xmm13, [rsp]
00007a40685d9889  add rsp, 0x30
00007a40685d988d  vmovaps xmm0, [rsp]
00007a40685d9892  vmovaps xmm1, [rsp+0x10]
00007a40685d9898  vmovaps xmm2, [rsp+0x20]
00007a40685d989e  vmovaps xmm3, [rsp+0x30]
00007a40685d98a4  vmovaps xmm4, [rsp+0x40]
00007a40685d98aa  vmovaps xmm5, [rsp+0x50]
00007a40685d98b0  vmovaps xmm6, [rsp+0x60]
00007a40685d98b6  vmovaps xmm7, [rsp+0x70]
00007a40685d98bc  vmovaps xmm8, [rsp+0x80]
00007a40685d98c5  vmovaps xmm9, [rsp+0x90]
00007a40685d98ce  vmovaps xmm10, [rsp+0xA0]
00007a40685d98d7  vmovaps xmm11, [rsp+0xB0]
00007a40685d98e0  vmovaps xmm12, [rsp+0xC0]
00007a40685d98e9  vmovaps xmm14, [rsp+0xD0]
00007a40685d98f2  vmovaps xmm15, [rsp+0xE0]
00007a40685d98fb  add rsp, 0xF0
00007a40685d9902  pop r11
00007a40685d9904  pop r10
00007a40685d9906  pop r9
00007a40685d9908  pop r8
00007a40685d990a  pop rsi
00007a40685d990b  pop rdi
00007a40685d990c  pop rdx
00007a40685d990d  pop rcx
00007a40685d990e  pop rax
00007a40685d990f  add rsp, 0x08
00007a40685d9913  jmp 0x00007A40685D62A5
00007a40685d9918  sub rsp, 0x08
00007a40685d991c  push rax
00007a40685d991d  push rcx
00007a40685d991e  push rdx
00007a40685d991f  push rdi
00007a40685d9920  push rsi
00007a40685d9921  push r8
00007a40685d9923  push r9
00007a40685d9925  push r10
00007a40685d9927  push r11
00007a40685d9929  sub rsp, 0xF0
00007a40685d9930  vmovaps [rsp], xmm0
00007a40685d9935  vmovaps [rsp+0x10], xmm1
00007a40685d993b  vmovaps [rsp+0x20], xmm2
00007a40685d9941  vmovaps [rsp+0x30], xmm3
00007a40685d9947  vmovaps [rsp+0x40], xmm4
00007a40685d994d  vmovaps [rsp+0x50], xmm5
00007a40685d9953  vmovaps [rsp+0x60], xmm6
00007a40685d9959  vmovaps [rsp+0x70], xmm7
00007a40685d995f  vmovaps [rsp+0x80], xmm8
00007a40685d9968  vmovaps [rsp+0x90], xmm9
00007a40685d9971  vmovaps [rsp+0xA0], xmm10
00007a40685d997a  vmovaps [rsp+0xB0], xmm11
00007a40685d9983  vmovaps [rsp+0xC0], xmm12
00007a40685d998c  vmovaps [rsp+0xD0], xmm13
00007a40685d9995  vmovaps [rsp+0xE0], xmm14
00007a40685d999e  sub rsp, 0x30
00007a40685d99a2  movaps [rsp], xmm15
00007a40685d99a7  movaps [rsp+0x10], xmm1
00007a40685d99ac  movaps [rsp+0x20], xmm5
00007a40685d99b1  lea rdi, [rsp]
00007a40685d99b5  mov esi, 0x00
00007a40685d99ba  mov rax, 0x56F679577530
00007a40685d99c4  call rax
00007a40685d99c6  movaps xmm15, [rsp]
00007a40685d99cb  add rsp, 0x30
00007a40685d99cf  vmovaps xmm0, [rsp]
00007a40685d99d4  vmovaps xmm1, [rsp+0x10]
00007a40685d99da  vmovaps xmm2, [rsp+0x20]
00007a40685d99e0  vmovaps xmm3, [rsp+0x30]
00007a40685d99e6  vmovaps xmm4, [rsp+0x40]
00007a40685d99ec  vmovaps xmm5, [rsp+0x50]
00007a40685d99f2  vmovaps xmm6, [rsp+0x60]
00007a40685d99f8  vmovaps xmm7, [rsp+0x70]
00007a40685d99fe  vmovaps xmm8, [rsp+0x80]
00007a40685d9a07  vmovaps xmm9, [rsp+0x90]
00007a40685d9a10  vmovaps xmm10, [rsp+0xA0]
00007a40685d9a19  vmovaps xmm11, [rsp+0xB0]
00007a40685d9a22  vmovaps xmm12, [rsp+0xC0]
00007a40685d9a2b  vmovaps xmm13, [rsp+0xD0]
00007a40685d9a34  vmovaps xmm14, [rsp+0xE0]
00007a40685d9a3d  add rsp, 0xF0
00007a40685d9a44  pop r11
00007a40685d9a46  pop r10
00007a40685d9a48  pop r9
00007a40685d9a4a  pop r8
00007a40685d9a4c  pop rsi
00007a40685d9a4d  pop rdi
00007a40685d9a4e  pop rdx
00007a40685d9a4f  pop rcx
00007a40685d9a50  pop rax
00007a40685d9a51  add rsp, 0x08
00007a40685d9a55  jmp 0x00007A40685D62C0
00007a40685d9a5a  call 0x00007A40684D64F0
00007a40685d9a5f  jmp 0x00007A40685D631B
00007a40685d9a64  sub rsp, 0x08
00007a40685d9a68  push rax
00007a40685d9a69  push rcx
00007a40685d9a6a  push rdx
00007a40685d9a6b  push rdi
00007a40685d9a6c  push rsi
00007a40685d9a6d  push r8
00007a40685d9a6f  push r9
00007a40685d9a71  push r10
00007a40685d9a73  push r11
00007a40685d9a75  sub rsp, 0xF0
00007a40685d9a7c  vmovaps [rsp], xmm0
00007a40685d9a81  vmovaps [rsp+0x10], xmm1
00007a40685d9a87  vmovaps [rsp+0x20], xmm2
00007a40685d9a8d  vmovaps [rsp+0x30], xmm3
00007a40685d9a93  vmovaps [rsp+0x40], xmm4
00007a40685d9a99  vmovaps [rsp+0x50], xmm5
00007a40685d9a9f  vmovaps [rsp+0x60], xmm6
00007a40685d9aa5  vmovaps [rsp+0x70], xmm7
00007a40685d9aab  vmovaps [rsp+0x80], xmm8
00007a40685d9ab4  vmovaps [rsp+0x90], xmm10
00007a40685d9abd  vmovaps [rsp+0xA0], xmm11
00007a40685d9ac6  vmovaps [rsp+0xB0], xmm12
00007a40685d9acf  vmovaps [rsp+0xC0], xmm13
00007a40685d9ad8  vmovaps [rsp+0xD0], xmm14
00007a40685d9ae1  vmovaps [rsp+0xE0], xmm15
00007a40685d9aea  sub rsp, 0x30
00007a40685d9aee  movaps [rsp], xmm9
00007a40685d9af3  movaps [rsp+0x10], xmm8
00007a40685d9af9  movaps [rsp+0x20], xmm11
00007a40685d9aff  lea rdi, [rsp]
00007a40685d9b03  mov esi, 0x00
00007a40685d9b08  mov rax, 0x56F679577530
00007a40685d9b12  call rax
00007a40685d9b14  movaps xmm9, [rsp]
00007a40685d9b19  add rsp, 0x30
00007a40685d9b1d  vmovaps xmm0, [rsp]
00007a40685d9b22  vmovaps xmm1, [rsp+0x10]
00007a40685d9b28  vmovaps xmm2, [rsp+0x20]
00007a40685d9b2e  vmovaps xmm3, [rsp+0x30]
00007a40685d9b34  vmovaps xmm4, [rsp+0x40]
00007a40685d9b3a  vmovaps xmm5, [rsp+0x50]
00007a40685d9b40  vmovaps xmm6, [rsp+0x60]
00007a40685d9b46  vmovaps xmm7, [rsp+0x70]
00007a40685d9b4c  vmovaps xmm8, [rsp+0x80]
00007a40685d9b55  vmovaps xmm10, [rsp+0x90]
00007a40685d9b5e  vmovaps xmm11, [rsp+0xA0]
00007a40685d9b67  vmovaps xmm12, [rsp+0xB0]
00007a40685d9b70  vmovaps xmm13, [rsp+0xC0]
00007a40685d9b79  vmovaps xmm14, [rsp+0xD0]
00007a40685d9b82  vmovaps xmm15, [rsp+0xE0]
00007a40685d9b8b  add rsp, 0xF0
00007a40685d9b92  pop r11
00007a40685d9b94  pop r10
00007a40685d9b96  pop r9
00007a40685d9b98  pop r8
00007a40685d9b9a  pop rsi
00007a40685d9b9b  pop rdi
00007a40685d9b9c  pop rdx
00007a40685d9b9d  pop rcx
00007a40685d9b9e  pop rax
00007a40685d9b9f  add rsp, 0x08
00007a40685d9ba3  jmp 0x00007A40685D6352
00007a40685d9ba8  sub rsp, 0x08
00007a40685d9bac  push rax
00007a40685d9bad  push rcx
00007a40685d9bae  push rdx
00007a40685d9baf  push rdi
00007a40685d9bb0  push rsi
00007a40685d9bb1  push r8
00007a40685d9bb3  push r9
00007a40685d9bb5  push r10
00007a40685d9bb7  push r11
00007a40685d9bb9  sub rsp, 0xF0
00007a40685d9bc0  vmovaps [rsp], xmm0
00007a40685d9bc5  vmovaps [rsp+0x10], xmm1
00007a40685d9bcb  vmovaps [rsp+0x20], xmm2
00007a40685d9bd1  vmovaps [rsp+0x30], xmm3
00007a40685d9bd7  vmovaps [rsp+0x40], xmm4
00007a40685d9bdd  vmovaps [rsp+0x50], xmm5
00007a40685d9be3  vmovaps [rsp+0x60], xmm6
00007a40685d9be9  vmovaps [rsp+0x70], xmm7
00007a40685d9bef  vmovaps [rsp+0x80], xmm8
00007a40685d9bf8  vmovaps [rsp+0x90], xmm9
00007a40685d9c01  vmovaps [rsp+0xA0], xmm10
00007a40685d9c0a  vmovaps [rsp+0xB0], xmm12
00007a40685d9c13  vmovaps [rsp+0xC0], xmm13
00007a40685d9c1c  vmovaps [rsp+0xD0], xmm14
00007a40685d9c25  vmovaps [rsp+0xE0], xmm15
00007a40685d9c2e  sub rsp, 0x30
00007a40685d9c32  movaps [rsp], xmm11
00007a40685d9c37  movaps [rsp+0x10], xmm10
00007a40685d9c3d  movaps [rsp+0x20], xmm6
00007a40685d9c42  lea rdi, [rsp]
00007a40685d9c46  mov esi, 0x00
00007a40685d9c4b  mov rax, 0x56F679577530
00007a40685d9c55  call rax
00007a40685d9c57  movaps xmm11, [rsp]
00007a40685d9c5c  add rsp, 0x30
00007a40685d9c60  vmovaps xmm0, [rsp]
00007a40685d9c65  vmovaps xmm1, [rsp+0x10]
00007a40685d9c6b  vmovaps xmm2, [rsp+0x20]
00007a40685d9c71  vmovaps xmm3, [rsp+0x30]
00007a40685d9c77  vmovaps xmm4, [rsp+0x40]
00007a40685d9c7d  vmovaps xmm5, [rsp+0x50]
00007a40685d9c83  vmovaps xmm6, [rsp+0x60]
00007a40685d9c89  vmovaps xmm7, [rsp+0x70]
00007a40685d9c8f  vmovaps xmm8, [rsp+0x80]
00007a40685d9c98  vmovaps xmm9, [rsp+0x90]
00007a40685d9ca1  vmovaps xmm10, [rsp+0xA0]
00007a40685d9caa  vmovaps xmm12, [rsp+0xB0]
00007a40685d9cb3  vmovaps xmm13, [rsp+0xC0]
00007a40685d9cbc  vmovaps xmm14, [rsp+0xD0]
00007a40685d9cc5  vmovaps xmm15, [rsp+0xE0]
00007a40685d9cce  add rsp, 0xF0
00007a40685d9cd5  pop r11
00007a40685d9cd7  pop r10
00007a40685d9cd9  pop r9
00007a40685d9cdb  pop r8
00007a40685d9cdd  pop rsi
00007a40685d9cde  pop rdi
00007a40685d9cdf  pop rdx
00007a40685d9ce0  pop rcx
00007a40685d9ce1  pop rax
00007a40685d9ce2  add rsp, 0x08
00007a40685d9ce6  jmp 0x00007A40685D636D
00007a40685d9ceb  sub rsp, 0x08
00007a40685d9cef  push rax
00007a40685d9cf0  push rcx
00007a40685d9cf1  push rdx
00007a40685d9cf2  push rdi
00007a40685d9cf3  push rsi
00007a40685d9cf4  push r8
00007a40685d9cf6  push r9
00007a40685d9cf8  push r10
00007a40685d9cfa  push r11
00007a40685d9cfc  sub rsp, 0xF0
00007a40685d9d03  vmovaps [rsp], xmm0
00007a40685d9d08  vmovaps [rsp+0x10], xmm1
00007a40685d9d0e  vmovaps [rsp+0x20], xmm2
00007a40685d9d14  vmovaps [rsp+0x30], xmm3
00007a40685d9d1a  vmovaps [rsp+0x40], xmm4
00007a40685d9d20  vmovaps [rsp+0x50], xmm5
00007a40685d9d26  vmovaps [rsp+0x60], xmm6
00007a40685d9d2c  vmovaps [rsp+0x70], xmm7
00007a40685d9d32  vmovaps [rsp+0x80], xmm8
00007a40685d9d3b  vmovaps [rsp+0x90], xmm9
00007a40685d9d44  vmovaps [rsp+0xA0], xmm11
00007a40685d9d4d  vmovaps [rsp+0xB0], xmm12
00007a40685d9d56  vmovaps [rsp+0xC0], xmm13
00007a40685d9d5f  vmovaps [rsp+0xD0], xmm14
00007a40685d9d68  vmovaps [rsp+0xE0], xmm15
00007a40685d9d71  sub rsp, 0x30
00007a40685d9d75  movaps [rsp], xmm10
00007a40685d9d7a  movaps [rsp+0x10], xmm14
00007a40685d9d80  movaps [rsp+0x20], xmm4
00007a40685d9d85  lea rdi, [rsp]
00007a40685d9d89  mov esi, 0x00
00007a40685d9d8e  mov rax, 0x56F679577530
00007a40685d9d98  call rax
00007a40685d9d9a  movaps xmm10, [rsp]
00007a40685d9d9f  add rsp, 0x30
00007a40685d9da3  vmovaps xmm0, [rsp]
00007a40685d9da8  vmovaps xmm1, [rsp+0x10]
00007a40685d9dae  vmovaps xmm2, [rsp+0x20]
00007a40685d9db4  vmovaps xmm3, [rsp+0x30]
00007a40685d9dba  vmovaps xmm4, [rsp+0x40]
00007a40685d9dc0  vmovaps xmm5, [rsp+0x50]
00007a40685d9dc6  vmovaps xmm6, [rsp+0x60]
00007a40685d9dcc  vmovaps xmm7, [rsp+0x70]
00007a40685d9dd2  vmovaps xmm8, [rsp+0x80]
00007a40685d9ddb  vmovaps xmm9, [rsp+0x90]
00007a40685d9de4  vmovaps xmm11, [rsp+0xA0]
00007a40685d9ded  vmovaps xmm12, [rsp+0xB0]
00007a40685d9df6  vmovaps xmm13, [rsp+0xC0]
00007a40685d9dff  vmovaps xmm14, [rsp+0xD0]
00007a40685d9e08  vmovaps xmm15, [rsp+0xE0]
00007a40685d9e11  add rsp, 0xF0
00007a40685d9e18  pop r11
00007a40685d9e1a  pop r10
00007a40685d9e1c  pop r9
00007a40685d9e1e  pop r8
00007a40685d9e20  pop rsi
00007a40685d9e21  pop rdi
00007a40685d9e22  pop rdx
00007a40685d9e23  pop rcx
00007a40685d9e24  pop rax
00007a40685d9e25  add rsp, 0x08
00007a40685d9e29  jmp 0x00007A40685D6388
00007a40685d9e2e  sub rsp, 0x08
00007a40685d9e32  push rax
00007a40685d9e33  push rcx
00007a40685d9e34  push rdx
00007a40685d9e35  push rdi
00007a40685d9e36  push rsi
00007a40685d9e37  push r8
00007a40685d9e39  push r9
00007a40685d9e3b  push r10
00007a40685d9e3d  push r11
00007a40685d9e3f  sub rsp, 0xF0
00007a40685d9e46  vmovaps [rsp], xmm0
00007a40685d9e4b  vmovaps [rsp+0x10], xmm1
00007a40685d9e51  vmovaps [rsp+0x20], xmm2
00007a40685d9e57  vmovaps [rsp+0x30], xmm3
00007a40685d9e5d  vmovaps [rsp+0x40], xmm4
00007a40685d9e63  vmovaps [rsp+0x50], xmm5
00007a40685d9e69  vmovaps [rsp+0x60], xmm6
00007a40685d9e6f  vmovaps [rsp+0x70], xmm7
00007a40685d9e75  vmovaps [rsp+0x80], xmm9
00007a40685d9e7e  vmovaps [rsp+0x90], xmm10
00007a40685d9e87  vmovaps [rsp+0xA0], xmm11
00007a40685d9e90  vmovaps [rsp+0xB0], xmm12
00007a40685d9e99  vmovaps [rsp+0xC0], xmm13
00007a40685d9ea2  vmovaps [rsp+0xD0], xmm14
00007a40685d9eab  vmovaps [rsp+0xE0], xmm15
00007a40685d9eb4  sub rsp, 0x30
00007a40685d9eb8  movaps [rsp], xmm8
00007a40685d9ebd  movaps [rsp+0x10], xmm1
00007a40685d9ec2  movaps [rsp+0x20], xmm14
00007a40685d9ec8  lea rdi, [rsp]
00007a40685d9ecc  mov esi, 0x00
00007a40685d9ed1  mov rax, 0x56F679577530
00007a40685d9edb  call rax
00007a40685d9edd  movaps xmm8, [rsp]
00007a40685d9ee2  add rsp, 0x30
00007a40685d9ee6  vmovaps xmm0, [rsp]
00007a40685d9eeb  vmovaps xmm1, [rsp+0x10]
00007a40685d9ef1  vmovaps xmm2, [rsp+0x20]
00007a40685d9ef7  vmovaps xmm3, [rsp+0x30]
00007a40685d9efd  vmovaps xmm4, [rsp+0x40]
00007a40685d9f03  vmovaps xmm5, [rsp+0x50]
00007a40685d9f09  vmovaps xmm6, [rsp+0x60]
00007a40685d9f0f  vmovaps xmm7, [rsp+0x70]
00007a40685d9f15  vmovaps xmm9, [rsp+0x80]
00007a40685d9f1e  vmovaps xmm10, [rsp+0x90]
00007a40685d9f27  vmovaps xmm11, [rsp+0xA0]
00007a40685d9f30  vmovaps xmm12, [rsp+0xB0]
00007a40685d9f39  vmovaps xmm13, [rsp+0xC0]
00007a40685d9f42  vmovaps xmm14, [rsp+0xD0]
00007a40685d9f4b  vmovaps xmm15, [rsp+0xE0]
00007a40685d9f54  add rsp, 0xF0
00007a40685d9f5b  pop r11
00007a40685d9f5d  pop r10
00007a40685d9f5f  pop r9
00007a40685d9f61  pop r8
00007a40685d9f63  pop rsi
00007a40685d9f64  pop rdi
00007a40685d9f65  pop rdx
00007a40685d9f66  pop rcx
00007a40685d9f67  pop rax
00007a40685d9f68  add rsp, 0x08
00007a40685d9f6c  jmp 0x00007A40685D63AE
00007a40685d9f71  sub rsp, 0x08
00007a40685d9f75  push rax
00007a40685d9f76  push rcx
00007a40685d9f77  push rdx
00007a40685d9f78  push rdi
00007a40685d9f79  push rsi
00007a40685d9f7a  push r8
00007a40685d9f7c  push r9
00007a40685d9f7e  push r10
00007a40685d9f80  push r11
00007a40685d9f82  sub rsp, 0xF0
00007a40685d9f89  vmovaps [rsp], xmm0
00007a40685d9f8e  vmovaps [rsp+0x10], xmm1
00007a40685d9f94  vmovaps [rsp+0x20], xmm2
00007a40685d9f9a  vmovaps [rsp+0x30], xmm3
00007a40685d9fa0  vmovaps [rsp+0x40], xmm4
00007a40685d9fa6  vmovaps [rsp+0x50], xmm5
00007a40685d9fac  vmovaps [rsp+0x60], xmm7
00007a40685d9fb2  vmovaps [rsp+0x70], xmm8
00007a40685d9fb8  vmovaps [rsp+0x80], xmm9
00007a40685d9fc1  vmovaps [rsp+0x90], xmm10
00007a40685d9fca  vmovaps [rsp+0xA0], xmm11
00007a40685d9fd3  vmovaps [rsp+0xB0], xmm12
00007a40685d9fdc  vmovaps [rsp+0xC0], xmm13
00007a40685d9fe5  vmovaps [rsp+0xD0], xmm14
00007a40685d9fee  vmovaps [rsp+0xE0], xmm15
00007a40685d9ff7  sub rsp, 0x30
00007a40685d9ffb  movaps [rsp], xmm6
00007a40685d9fff  movaps [rsp+0x10], xmm1
00007a40685da004  movaps [rsp+0x20], xmm14
00007a40685da00a  lea rdi, [rsp]
00007a40685da00e  mov esi, 0x00
00007a40685da013  mov rax, 0x56F679577530
00007a40685da01d  call rax
00007a40685da01f  movaps xmm6, [rsp]
00007a40685da023  add rsp, 0x30
00007a40685da027  vmovaps xmm0, [rsp]
00007a40685da02c  vmovaps xmm1, [rsp+0x10]
00007a40685da032  vmovaps xmm2, [rsp+0x20]
00007a40685da038  vmovaps xmm3, [rsp+0x30]
00007a40685da03e  vmovaps xmm4, [rsp+0x40]
00007a40685da044  vmovaps xmm5, [rsp+0x50]
00007a40685da04a  vmovaps xmm7, [rsp+0x60]
00007a40685da050  vmovaps xmm8, [rsp+0x70]
00007a40685da056  vmovaps xmm9, [rsp+0x80]
00007a40685da05f  vmovaps xmm10, [rsp+0x90]
00007a40685da068  vmovaps xmm11, [rsp+0xA0]
00007a40685da071  vmovaps xmm12, [rsp+0xB0]
00007a40685da07a  vmovaps xmm13, [rsp+0xC0]
00007a40685da083  vmovaps xmm14, [rsp+0xD0]
00007a40685da08c  vmovaps xmm15, [rsp+0xE0]
00007a40685da095  add rsp, 0xF0
00007a40685da09c  pop r11
00007a40685da09e  pop r10
00007a40685da0a0  pop r9
00007a40685da0a2  pop r8
00007a40685da0a4  pop rsi
00007a40685da0a5  pop rdi
00007a40685da0a6  pop rdx
00007a40685da0a7  pop rcx
00007a40685da0a8  pop rax
00007a40685da0a9  add rsp, 0x08
00007a40685da0ad  jmp 0x00007A40685D63DA
00007a40685da0b2  sub rsp, 0x08
00007a40685da0b6  push rax
00007a40685da0b7  push rcx
00007a40685da0b8  push rdx
00007a40685da0b9  push rdi
00007a40685da0ba  push rsi
00007a40685da0bb  push r8
00007a40685da0bd  push r9
00007a40685da0bf  push r10
00007a40685da0c1  push r11
00007a40685da0c3  sub rsp, 0xF0
00007a40685da0ca  vmovaps [rsp], xmm0
00007a40685da0cf  vmovaps [rsp+0x10], xmm1
00007a40685da0d5  vmovaps [rsp+0x20], xmm2
00007a40685da0db  vmovaps [rsp+0x30], xmm3
00007a40685da0e1  vmovaps [rsp+0x40], xmm4
00007a40685da0e7  vmovaps [rsp+0x50], xmm5
00007a40685da0ed  vmovaps [rsp+0x60], xmm6
00007a40685da0f3  vmovaps [rsp+0x70], xmm7
00007a40685da0f9  vmovaps [rsp+0x80], xmm8
00007a40685da102  vmovaps [rsp+0x90], xmm9
00007a40685da10b  vmovaps [rsp+0xA0], xmm10
00007a40685da114  vmovaps [rsp+0xB0], xmm11
00007a40685da11d  vmovaps [rsp+0xC0], xmm12
00007a40685da126  vmovaps [rsp+0xD0], xmm13
00007a40685da12f  vmovaps [rsp+0xE0], xmm15
00007a40685da138  sub rsp, 0x30
00007a40685da13c  movaps [rsp], xmm14
00007a40685da141  movaps [rsp+0x10], xmm12
00007a40685da147  movaps [rsp+0x20], xmm1
00007a40685da14c  lea rdi, [rsp]
00007a40685da150  mov esi, 0x00
00007a40685da155  mov rax, 0x56F679577530
00007a40685da15f  call rax
00007a40685da161  movaps xmm14, [rsp]
00007a40685da166  add rsp, 0x30
00007a40685da16a  vmovaps xmm0, [rsp]
00007a40685da16f  vmovaps xmm1, [rsp+0x10]
00007a40685da175  vmovaps xmm2, [rsp+0x20]
00007a40685da17b  vmovaps xmm3, [rsp+0x30]
00007a40685da181  vmovaps xmm4, [rsp+0x40]
00007a40685da187  vmovaps xmm5, [rsp+0x50]
00007a40685da18d  vmovaps xmm6, [rsp+0x60]
00007a40685da193  vmovaps xmm7, [rsp+0x70]
00007a40685da199  vmovaps xmm8, [rsp+0x80]
00007a40685da1a2  vmovaps xmm9, [rsp+0x90]
00007a40685da1ab  vmovaps xmm10, [rsp+0xA0]
00007a40685da1b4  vmovaps xmm11, [rsp+0xB0]
00007a40685da1bd  vmovaps xmm12, [rsp+0xC0]
00007a40685da1c6  vmovaps xmm13, [rsp+0xD0]
00007a40685da1cf  vmovaps xmm15, [rsp+0xE0]
00007a40685da1d8  add rsp, 0xF0
00007a40685da1df  pop r11
00007a40685da1e1  pop r10
00007a40685da1e3  pop r9
00007a40685da1e5  pop r8
00007a40685da1e7  pop rsi
00007a40685da1e8  pop rdi
00007a40685da1e9  pop rdx
00007a40685da1ea  pop rcx
00007a40685da1eb  pop rax
00007a40685da1ec  add rsp, 0x08
00007a40685da1f0  jmp 0x00007A40685D6400
00007a40685da1f5  sub rsp, 0x08
00007a40685da1f9  push rax
00007a40685da1fa  push rcx
00007a40685da1fb  push rdx
00007a40685da1fc  push rdi
00007a40685da1fd  push rsi
00007a40685da1fe  push r8
00007a40685da200  push r9
00007a40685da202  push r10
00007a40685da204  push r11
00007a40685da206  sub rsp, 0xF0
00007a40685da20d  vmovaps [rsp], xmm0
00007a40685da212  vmovaps [rsp+0x10], xmm2
00007a40685da218  vmovaps [rsp+0x20], xmm3
00007a40685da21e  vmovaps [rsp+0x30], xmm4
00007a40685da224  vmovaps [rsp+0x40], xmm5
00007a40685da22a  vmovaps [rsp+0x50], xmm6
00007a40685da230  vmovaps [rsp+0x60], xmm7
00007a40685da236  vmovaps [rsp+0x70], xmm8
00007a40685da23c  vmovaps [rsp+0x80], xmm9
00007a40685da245  vmovaps [rsp+0x90], xmm10
00007a40685da24e  vmovaps [rsp+0xA0], xmm11
00007a40685da257  vmovaps [rsp+0xB0], xmm12
00007a40685da260  vmovaps [rsp+0xC0], xmm13
00007a40685da269  vmovaps [rsp+0xD0], xmm14
00007a40685da272  vmovaps [rsp+0xE0], xmm15
00007a40685da27b  sub rsp, 0x30
00007a40685da27f  movaps [rsp], xmm1
00007a40685da283  movaps [rsp+0x10], xmm13
00007a40685da289  movaps [rsp+0x20], xmm9
00007a40685da28f  lea rdi, [rsp]
00007a40685da293  mov esi, 0x00
00007a40685da298  mov rax, 0x56F679577530
00007a40685da2a2  call rax
00007a40685da2a4  movaps xmm1, [rsp]
00007a40685da2a8  add rsp, 0x30
00007a40685da2ac  vmovaps xmm0, [rsp]
00007a40685da2b1  vmovaps xmm2, [rsp+0x10]
00007a40685da2b7  vmovaps xmm3, [rsp+0x20]
00007a40685da2bd  vmovaps xmm4, [rsp+0x30]
00007a40685da2c3  vmovaps xmm5, [rsp+0x40]
00007a40685da2c9  vmovaps xmm6, [rsp+0x50]
00007a40685da2cf  vmovaps xmm7, [rsp+0x60]
00007a40685da2d5  vmovaps xmm8, [rsp+0x70]
00007a40685da2db  vmovaps xmm9, [rsp+0x80]
00007a40685da2e4  vmovaps xmm10, [rsp+0x90]
00007a40685da2ed  vmovaps xmm11, [rsp+0xA0]
00007a40685da2f6  vmovaps xmm12, [rsp+0xB0]
00007a40685da2ff  vmovaps xmm13, [rsp+0xC0]
00007a40685da308  vmovaps xmm14, [rsp+0xD0]
00007a40685da311  vmovaps xmm15, [rsp+0xE0]
00007a40685da31a  add rsp, 0xF0
00007a40685da321  pop r11
00007a40685da323  pop r10
00007a40685da325  pop r9
00007a40685da327  pop r8
00007a40685da329  pop rsi
00007a40685da32a  pop rdi
00007a40685da32b  pop rdx
00007a40685da32c  pop rcx
00007a40685da32d  pop rax
00007a40685da32e  add rsp, 0x08
00007a40685da332  jmp 0x00007A40685D641A
00007a40685da337  sub rsp, 0x08
00007a40685da33b  push rax
00007a40685da33c  push rcx
00007a40685da33d  push rdx
00007a40685da33e  push rdi
00007a40685da33f  push rsi
00007a40685da340  push r8
00007a40685da342  push r9
00007a40685da344  push r10
00007a40685da346  push r11
00007a40685da348  sub rsp, 0xF0
00007a40685da34f  vmovaps [rsp], xmm0
00007a40685da354  vmovaps [rsp+0x10], xmm1
00007a40685da35a  vmovaps [rsp+0x20], xmm2
00007a40685da360  vmovaps [rsp+0x30], xmm3
00007a40685da366  vmovaps [rsp+0x40], xmm4
00007a40685da36c  vmovaps [rsp+0x50], xmm5
00007a40685da372  vmovaps [rsp+0x60], xmm6
00007a40685da378  vmovaps [rsp+0x70], xmm7
00007a40685da37e  vmovaps [rsp+0x80], xmm8
00007a40685da387  vmovaps [rsp+0x90], xmm9
00007a40685da390  vmovaps [rsp+0xA0], xmm10
00007a40685da399  vmovaps [rsp+0xB0], xmm11
00007a40685da3a2  vmovaps [rsp+0xC0], xmm13
00007a40685da3ab  vmovaps [rsp+0xD0], xmm14
00007a40685da3b4  vmovaps [rsp+0xE0], xmm15
00007a40685da3bd  sub rsp, 0x30
00007a40685da3c1  movaps [rsp], xmm12
00007a40685da3c6  movaps [rsp+0x10], xmm7
00007a40685da3cb  movaps [rsp+0x20], xmm13
00007a40685da3d1  lea rdi, [rsp]
00007a40685da3d5  mov esi, 0x00
00007a40685da3da  mov rax, 0x56F679577530
00007a40685da3e4  call rax
00007a40685da3e6  movaps xmm12, [rsp]
00007a40685da3eb  add rsp, 0x30
00007a40685da3ef  vmovaps xmm0, [rsp]
00007a40685da3f4  vmovaps xmm1, [rsp+0x10]
00007a40685da3fa  vmovaps xmm2, [rsp+0x20]
00007a40685da400  vmovaps xmm3, [rsp+0x30]
00007a40685da406  vmovaps xmm4, [rsp+0x40]
00007a40685da40c  vmovaps xmm5, [rsp+0x50]
00007a40685da412  vmovaps xmm6, [rsp+0x60]
00007a40685da418  vmovaps xmm7, [rsp+0x70]
00007a40685da41e  vmovaps xmm8, [rsp+0x80]
00007a40685da427  vmovaps xmm9, [rsp+0x90]
00007a40685da430  vmovaps xmm10, [rsp+0xA0]
00007a40685da439  vmovaps xmm11, [rsp+0xB0]
00007a40685da442  vmovaps xmm13, [rsp+0xC0]
00007a40685da44b  vmovaps xmm14, [rsp+0xD0]
00007a40685da454  vmovaps xmm15, [rsp+0xE0]
00007a40685da45d  add rsp, 0xF0
00007a40685da464  pop r11
00007a40685da466  pop r10
00007a40685da468  pop r9
00007a40685da46a  pop r8
00007a40685da46c  pop rsi
00007a40685da46d  pop rdi
00007a40685da46e  pop rdx
00007a40685da46f  pop rcx
00007a40685da470  pop rax
00007a40685da471  add rsp, 0x08
00007a40685da475  jmp 0x00007A40685D6441
00007a40685da47a  sub rsp, 0x08
00007a40685da47e  push rax
00007a40685da47f  push rcx
00007a40685da480  push rdx
00007a40685da481  push rdi
00007a40685da482  push rsi
00007a40685da483  push r8
00007a40685da485  push r9
00007a40685da487  push r10
00007a40685da489  push r11
00007a40685da48b  sub rsp, 0xF0
00007a40685da492  vmovaps [rsp], xmm0
00007a40685da497  vmovaps [rsp+0x10], xmm1
00007a40685da49d  vmovaps [rsp+0x20], xmm2
00007a40685da4a3  vmovaps [rsp+0x30], xmm3
00007a40685da4a9  vmovaps [rsp+0x40], xmm4
00007a40685da4af  vmovaps [rsp+0x50], xmm5
00007a40685da4b5  vmovaps [rsp+0x60], xmm6
00007a40685da4bb  vmovaps [rsp+0x70], xmm7
00007a40685da4c1  vmovaps [rsp+0x80], xmm8
00007a40685da4ca  vmovaps [rsp+0x90], xmm9
00007a40685da4d3  vmovaps [rsp+0xA0], xmm10
00007a40685da4dc  vmovaps [rsp+0xB0], xmm11
00007a40685da4e5  vmovaps [rsp+0xC0], xmm12
00007a40685da4ee  vmovaps [rsp+0xD0], xmm14
00007a40685da4f7  vmovaps [rsp+0xE0], xmm15
00007a40685da500  sub rsp, 0x30
00007a40685da504  movaps [rsp], xmm13
00007a40685da509  movaps [rsp+0x10], xmm15
00007a40685da50f  movaps [rsp+0x20], xmm8
00007a40685da515  lea rdi, [rsp]
00007a40685da519  mov esi, 0x00
00007a40685da51e  mov rax, 0x56F679577530
00007a40685da528  call rax
00007a40685da52a  movaps xmm13, [rsp]
00007a40685da52f  add rsp, 0x30
00007a40685da533  vmovaps xmm0, [rsp]
00007a40685da538  vmovaps xmm1, [rsp+0x10]
00007a40685da53e  vmovaps xmm2, [rsp+0x20]
00007a40685da544  vmovaps xmm3, [rsp+0x30]
00007a40685da54a  vmovaps xmm4, [rsp+0x40]
00007a40685da550  vmovaps xmm5, [rsp+0x50]
00007a40685da556  vmovaps xmm6, [rsp+0x60]
00007a40685da55c  vmovaps xmm7, [rsp+0x70]
00007a40685da562  vmovaps xmm8, [rsp+0x80]
00007a40685da56b  vmovaps xmm9, [rsp+0x90]
00007a40685da574  vmovaps xmm10, [rsp+0xA0]
00007a40685da57d  vmovaps xmm11, [rsp+0xB0]
00007a40685da586  vmovaps xmm12, [rsp+0xC0]
00007a40685da58f  vmovaps xmm14, [rsp+0xD0]
00007a40685da598  vmovaps xmm15, [rsp+0xE0]
00007a40685da5a1  add rsp, 0xF0
00007a40685da5a8  pop r11
00007a40685da5aa  pop r10
00007a40685da5ac  pop r9
00007a40685da5ae  pop r8
00007a40685da5b0  pop rsi
00007a40685da5b1  pop rdi
00007a40685da5b2  pop rdx
00007a40685da5b3  pop rcx
00007a40685da5b4  pop rax
00007a40685da5b5  add rsp, 0x08
00007a40685da5b9  jmp 0x00007A40685D645C
00007a40685da5be  sub rsp, 0x08
00007a40685da5c2  push rax
00007a40685da5c3  push rcx
00007a40685da5c4  push rdx
00007a40685da5c5  push rdi
00007a40685da5c6  push rsi
00007a40685da5c7  push r8
00007a40685da5c9  push r9
00007a40685da5cb  push r10
00007a40685da5cd  push r11
00007a40685da5cf  sub rsp, 0xF0
00007a40685da5d6  vmovaps [rsp], xmm0
00007a40685da5db  vmovaps [rsp+0x10], xmm1
00007a40685da5e1  vmovaps [rsp+0x20], xmm2
00007a40685da5e7  vmovaps [rsp+0x30], xmm3
00007a40685da5ed  vmovaps [rsp+0x40], xmm4
00007a40685da5f3  vmovaps [rsp+0x50], xmm5
00007a40685da5f9  vmovaps [rsp+0x60], xmm6
00007a40685da5ff  vmovaps [rsp+0x70], xmm7
00007a40685da605  vmovaps [rsp+0x80], xmm9
00007a40685da60e  vmovaps [rsp+0x90], xmm10
00007a40685da617  vmovaps [rsp+0xA0], xmm11
00007a40685da620  vmovaps [rsp+0xB0], xmm12
00007a40685da629  vmovaps [rsp+0xC0], xmm13
00007a40685da632  vmovaps [rsp+0xD0], xmm14
00007a40685da63b  vmovaps [rsp+0xE0], xmm15
00007a40685da644  sub rsp, 0x30
00007a40685da648  movaps [rsp], xmm8
00007a40685da64d  movaps [rsp+0x10], xmm15
00007a40685da653  movaps [rsp+0x20], xmm9
00007a40685da659  lea rdi, [rsp]
00007a40685da65d  mov esi, 0x00
00007a40685da662  mov rax, 0x56F679577530
00007a40685da66c  call rax
00007a40685da66e  movaps xmm8, [rsp]
00007a40685da673  add rsp, 0x30
00007a40685da677  vmovaps xmm0, [rsp]
00007a40685da67c  vmovaps xmm1, [rsp+0x10]
00007a40685da682  vmovaps xmm2, [rsp+0x20]
00007a40685da688  vmovaps xmm3, [rsp+0x30]
00007a40685da68e  vmovaps xmm4, [rsp+0x40]
00007a40685da694  vmovaps xmm5, [rsp+0x50]
00007a40685da69a  vmovaps xmm6, [rsp+0x60]
00007a40685da6a0  vmovaps xmm7, [rsp+0x70]
00007a40685da6a6  vmovaps xmm9, [rsp+0x80]
00007a40685da6af  vmovaps xmm10, [rsp+0x90]
00007a40685da6b8  vmovaps xmm11, [rsp+0xA0]
00007a40685da6c1  vmovaps xmm12, [rsp+0xB0]
00007a40685da6ca  vmovaps xmm13, [rsp+0xC0]
00007a40685da6d3  vmovaps xmm14, [rsp+0xD0]
00007a40685da6dc  vmovaps xmm15, [rsp+0xE0]
00007a40685da6e5  add rsp, 0xF0
00007a40685da6ec  pop r11
00007a40685da6ee  pop r10
00007a40685da6f0  pop r9
00007a40685da6f2  pop r8
00007a40685da6f4  pop rsi
00007a40685da6f5  pop rdi
00007a40685da6f6  pop rdx
00007a40685da6f7  pop rcx
00007a40685da6f8  pop rax
00007a40685da6f9  add rsp, 0x08
00007a40685da6fd  jmp 0x00007A40685D648A
00007a40685da702  sub rsp, 0x08
00007a40685da706  push rax
00007a40685da707  push rcx
00007a40685da708  push rdx
00007a40685da709  push rdi
00007a40685da70a  push rsi
00007a40685da70b  push r8
00007a40685da70d  push r9
00007a40685da70f  push r10
00007a40685da711  push r11
00007a40685da713  sub rsp, 0xF0
00007a40685da71a  vmovaps [rsp], xmm0
00007a40685da71f  vmovaps [rsp+0x10], xmm1
00007a40685da725  vmovaps [rsp+0x20], xmm2
00007a40685da72b  vmovaps [rsp+0x30], xmm3
00007a40685da731  vmovaps [rsp+0x40], xmm4
00007a40685da737  vmovaps [rsp+0x50], xmm5
00007a40685da73d  vmovaps [rsp+0x60], xmm6
00007a40685da743  vmovaps [rsp+0x70], xmm7
00007a40685da749  vmovaps [rsp+0x80], xmm8
00007a40685da752  vmovaps [rsp+0x90], xmm9
00007a40685da75b  vmovaps [rsp+0xA0], xmm10
00007a40685da764  vmovaps [rsp+0xB0], xmm11
00007a40685da76d  vmovaps [rsp+0xC0], xmm12
00007a40685da776  vmovaps [rsp+0xD0], xmm13
00007a40685da77f  vmovaps [rsp+0xE0], xmm14
00007a40685da788  sub rsp, 0x30
00007a40685da78c  movaps [rsp], xmm15
00007a40685da791  movaps [rsp+0x10], xmm11
00007a40685da797  movaps [rsp+0x20], xmm6
00007a40685da79c  lea rdi, [rsp]
00007a40685da7a0  mov esi, 0x00
00007a40685da7a5  mov rax, 0x56F679577530
00007a40685da7af  call rax
00007a40685da7b1  movaps xmm15, [rsp]
00007a40685da7b6  add rsp, 0x30
00007a40685da7ba  vmovaps xmm0, [rsp]
00007a40685da7bf  vmovaps xmm1, [rsp+0x10]
00007a40685da7c5  vmovaps xmm2, [rsp+0x20]
00007a40685da7cb  vmovaps xmm3, [rsp+0x30]
00007a40685da7d1  vmovaps xmm4, [rsp+0x40]
00007a40685da7d7  vmovaps xmm5, [rsp+0x50]
00007a40685da7dd  vmovaps xmm6, [rsp+0x60]
00007a40685da7e3  vmovaps xmm7, [rsp+0x70]
00007a40685da7e9  vmovaps xmm8, [rsp+0x80]
00007a40685da7f2  vmovaps xmm9, [rsp+0x90]
00007a40685da7fb  vmovaps xmm10, [rsp+0xA0]
00007a40685da804  vmovaps xmm11, [rsp+0xB0]
00007a40685da80d  vmovaps xmm12, [rsp+0xC0]
00007a40685da816  vmovaps xmm13, [rsp+0xD0]
00007a40685da81f  vmovaps xmm14, [rsp+0xE0]
00007a40685da828  add rsp, 0xF0
00007a40685da82f  pop r11
00007a40685da831  pop r10
00007a40685da833  pop r9
00007a40685da835  pop r8
00007a40685da837  pop rsi
00007a40685da838  pop rdi
00007a40685da839  pop rdx
00007a40685da83a  pop rcx
00007a40685da83b  pop rax
00007a40685da83c  add rsp, 0x08
00007a40685da840  jmp 0x00007A40685D64A5
00007a40685da845  sub rsp, 0x08
00007a40685da849  push rax
00007a40685da84a  push rcx
00007a40685da84b  push rdx
00007a40685da84c  push rdi
00007a40685da84d  push rsi
00007a40685da84e  push r8
00007a40685da850  push r9
00007a40685da852  push r10
00007a40685da854  push r11
00007a40685da856  sub rsp, 0xF0
00007a40685da85d  vmovaps [rsp], xmm0
00007a40685da862  vmovaps [rsp+0x10], xmm1
00007a40685da868  vmovaps [rsp+0x20], xmm2
00007a40685da86e  vmovaps [rsp+0x30], xmm3
00007a40685da874  vmovaps [rsp+0x40], xmm4
00007a40685da87a  vmovaps [rsp+0x50], xmm5
00007a40685da880  vmovaps [rsp+0x60], xmm6
00007a40685da886  vmovaps [rsp+0x70], xmm8
00007a40685da88c  vmovaps [rsp+0x80], xmm9
00007a40685da895  vmovaps [rsp+0x90], xmm10
00007a40685da89e  vmovaps [rsp+0xA0], xmm11
00007a40685da8a7  vmovaps [rsp+0xB0], xmm12
00007a40685da8b0  vmovaps [rsp+0xC0], xmm13
00007a40685da8b9  vmovaps [rsp+0xD0], xmm14
00007a40685da8c2  vmovaps [rsp+0xE0], xmm15
00007a40685da8cb  sub rsp, 0x30
00007a40685da8cf  movaps [rsp], xmm7
00007a40685da8d3  movaps [rsp+0x10], xmm11
00007a40685da8d9  movaps [rsp+0x20], xmm9
00007a40685da8df  lea rdi, [rsp]
00007a40685da8e3  mov esi, 0x00
00007a40685da8e8  mov rax, 0x56F679577530
00007a40685da8f2  call rax
00007a40685da8f4  movaps xmm7, [rsp]
00007a40685da8f8  add rsp, 0x30
00007a40685da8fc  vmovaps xmm0, [rsp]
00007a40685da901  vmovaps xmm1, [rsp+0x10]
00007a40685da907  vmovaps xmm2, [rsp+0x20]
00007a40685da90d  vmovaps xmm3, [rsp+0x30]
00007a40685da913  vmovaps xmm4, [rsp+0x40]
00007a40685da919  vmovaps xmm5, [rsp+0x50]
00007a40685da91f  vmovaps xmm6, [rsp+0x60]
00007a40685da925  vmovaps xmm8, [rsp+0x70]
00007a40685da92b  vmovaps xmm9, [rsp+0x80]
00007a40685da934  vmovaps xmm10, [rsp+0x90]
00007a40685da93d  vmovaps xmm11, [rsp+0xA0]
00007a40685da946  vmovaps xmm12, [rsp+0xB0]
00007a40685da94f  vmovaps xmm13, [rsp+0xC0]
00007a40685da958  vmovaps xmm14, [rsp+0xD0]
00007a40685da961  vmovaps xmm15, [rsp+0xE0]
00007a40685da96a  add rsp, 0xF0
00007a40685da971  pop r11
00007a40685da973  pop r10
00007a40685da975  pop r9
00007a40685da977  pop r8
00007a40685da979  pop rsi
00007a40685da97a  pop rdi
00007a40685da97b  pop rdx
00007a40685da97c  pop rcx
00007a40685da97d  pop rax
00007a40685da97e  add rsp, 0x08
00007a40685da982  jmp 0x00007A40685D64D2
00007a40685da987  sub rsp, 0x08
00007a40685da98b  push rax
00007a40685da98c  push rcx
00007a40685da98d  push rdx
00007a40685da98e  push rdi
00007a40685da98f  push rsi
00007a40685da990  push r8
00007a40685da992  push r9
00007a40685da994  push r10
00007a40685da996  push r11
00007a40685da998  sub rsp, 0xF0
00007a40685da99f  vmovaps [rsp], xmm0
00007a40685da9a4  vmovaps [rsp+0x10], xmm1
00007a40685da9aa  vmovaps [rsp+0x20], xmm2
00007a40685da9b0  vmovaps [rsp+0x30], xmm3
00007a40685da9b6  vmovaps [rsp+0x40], xmm4
00007a40685da9bc  vmovaps [rsp+0x50], xmm5
00007a40685da9c2  vmovaps [rsp+0x60], xmm6
00007a40685da9c8  vmovaps [rsp+0x70], xmm7
00007a40685da9ce  vmovaps [rsp+0x80], xmm8
00007a40685da9d7  vmovaps [rsp+0x90], xmm9
00007a40685da9e0  vmovaps [rsp+0xA0], xmm10
00007a40685da9e9  vmovaps [rsp+0xB0], xmm12
00007a40685da9f2  vmovaps [rsp+0xC0], xmm13
00007a40685da9fb  vmovaps [rsp+0xD0], xmm14
00007a40685daa04  vmovaps [rsp+0xE0], xmm15
00007a40685daa0d  sub rsp, 0x30
00007a40685daa11  movaps [rsp], xmm11
00007a40685daa16  movaps [rsp+0x10], xmm10
00007a40685daa1c  movaps [rsp+0x20], xmm14
00007a40685daa22  lea rdi, [rsp]
00007a40685daa26  mov esi, 0x00
00007a40685daa2b  mov rax, 0x56F679577530
00007a40685daa35  call rax
00007a40685daa37  movaps xmm11, [rsp]
00007a40685daa3c  add rsp, 0x30
00007a40685daa40  vmovaps xmm0, [rsp]
00007a40685daa45  vmovaps xmm1, [rsp+0x10]
00007a40685daa4b  vmovaps xmm2, [rsp+0x20]
00007a40685daa51  vmovaps xmm3, [rsp+0x30]
00007a40685daa57  vmovaps xmm4, [rsp+0x40]
00007a40685daa5d  vmovaps xmm5, [rsp+0x50]
00007a40685daa63  vmovaps xmm6, [rsp+0x60]
00007a40685daa69  vmovaps xmm7, [rsp+0x70]
00007a40685daa6f  vmovaps xmm8, [rsp+0x80]
00007a40685daa78  vmovaps xmm9, [rsp+0x90]
00007a40685daa81  vmovaps xmm10, [rsp+0xA0]
00007a40685daa8a  vmovaps xmm12, [rsp+0xB0]
00007a40685daa93  vmovaps xmm13, [rsp+0xC0]
00007a40685daa9c  vmovaps xmm14, [rsp+0xD0]
00007a40685daaa5  vmovaps xmm15, [rsp+0xE0]
00007a40685daaae  add rsp, 0xF0
00007a40685daab5  pop r11
00007a40685daab7  pop r10
00007a40685daab9  pop r9
00007a40685daabb  pop r8
00007a40685daabd  pop rsi
00007a40685daabe  pop rdi
00007a40685daabf  pop rdx
00007a40685daac0  pop rcx
00007a40685daac1  pop rax
00007a40685daac2  add rsp, 0x08
00007a40685daac6  jmp 0x00007A40685D64ED
00007a40685daacb  call 0x00007A40684E45A0
00007a40685daad0  jmp 0x00007A40685D64F7
00007a40685daad5  sub rsp, 0x08
00007a40685daad9  push rax
00007a40685daada  push rcx
00007a40685daadb  push rdx
00007a40685daadc  push rdi
00007a40685daadd  push rsi
00007a40685daade  push r8
00007a40685daae0  push r9
00007a40685daae2  push r10
00007a40685daae4  push r11
00007a40685daae6  sub rsp, 0xF0
00007a40685daaed  vmovaps [rsp], xmm0
00007a40685daaf2  vmovaps [rsp+0x10], xmm1
00007a40685daaf8  vmovaps [rsp+0x20], xmm2
00007a40685daafe  vmovaps [rsp+0x30], xmm3
00007a40685dab04  vmovaps [rsp+0x40], xmm4
00007a40685dab0a  vmovaps [rsp+0x50], xmm5
00007a40685dab10  vmovaps [rsp+0x60], xmm6
00007a40685dab16  vmovaps [rsp+0x70], xmm7
00007a40685dab1c  vmovaps [rsp+0x80], xmm8
00007a40685dab25  vmovaps [rsp+0x90], xmm9
00007a40685dab2e  vmovaps [rsp+0xA0], xmm11
00007a40685dab37  vmovaps [rsp+0xB0], xmm12
00007a40685dab40  vmovaps [rsp+0xC0], xmm13
00007a40685dab49  vmovaps [rsp+0xD0], xmm14
00007a40685dab52  vmovaps [rsp+0xE0], xmm15
00007a40685dab5b  sub rsp, 0x30
00007a40685dab5f  movaps [rsp], xmm10
00007a40685dab64  movaps [rsp+0x10], xmm1
00007a40685dab69  movaps [rsp+0x20], xmm12
00007a40685dab6f  lea rdi, [rsp]
00007a40685dab73  mov esi, 0x00
00007a40685dab78  mov rax, 0x56F679577530
00007a40685dab82  call rax
00007a40685dab84  movaps xmm10, [rsp]
00007a40685dab89  add rsp, 0x30
00007a40685dab8d  vmovaps xmm0, [rsp]
00007a40685dab92  vmovaps xmm1, [rsp+0x10]
00007a40685dab98  vmovaps xmm2, [rsp+0x20]
00007a40685dab9e  vmovaps xmm3, [rsp+0x30]
00007a40685daba4  vmovaps xmm4, [rsp+0x40]
00007a40685dabaa  vmovaps xmm5, [rsp+0x50]
00007a40685dabb0  vmovaps xmm6, [rsp+0x60]
00007a40685dabb6  vmovaps xmm7, [rsp+0x70]
00007a40685dabbc  vmovaps xmm8, [rsp+0x80]
00007a40685dabc5  vmovaps xmm9, [rsp+0x90]
00007a40685dabce  vmovaps xmm11, [rsp+0xA0]
00007a40685dabd7  vmovaps xmm12, [rsp+0xB0]
00007a40685dabe0  vmovaps xmm13, [rsp+0xC0]
00007a40685dabe9  vmovaps xmm14, [rsp+0xD0]
00007a40685dabf2  vmovaps xmm15, [rsp+0xE0]
00007a40685dabfb  add rsp, 0xF0
00007a40685dac02  pop r11
00007a40685dac04  pop r10
00007a40685dac06  pop r9
00007a40685dac08  pop r8
00007a40685dac0a  pop rsi
00007a40685dac0b  pop rdi
00007a40685dac0c  pop rdx
00007a40685dac0d  pop rcx
00007a40685dac0e  pop rax
00007a40685dac0f  add rsp, 0x08
00007a40685dac13  jmp 0x00007A40685D651A
00007a40685dac18  sub rsp, 0x08
00007a40685dac1c  push rax
00007a40685dac1d  push rcx
00007a40685dac1e  push rdx
00007a40685dac1f  push rdi
00007a40685dac20  push rsi
00007a40685dac21  push r8
00007a40685dac23  push r9
00007a40685dac25  push r10
00007a40685dac27  push r11
00007a40685dac29  sub rsp, 0xF0
00007a40685dac30  vmovaps [rsp], xmm0
00007a40685dac35  vmovaps [rsp+0x10], xmm1
00007a40685dac3b  vmovaps [rsp+0x20], xmm2
00007a40685dac41  vmovaps [rsp+0x30], xmm3
00007a40685dac47  vmovaps [rsp+0x40], xmm4
00007a40685dac4d  vmovaps [rsp+0x50], xmm5
00007a40685dac53  vmovaps [rsp+0x60], xmm6
00007a40685dac59  vmovaps [rsp+0x70], xmm7
00007a40685dac5f  vmovaps [rsp+0x80], xmm8
00007a40685dac68  vmovaps [rsp+0x90], xmm9
00007a40685dac71  vmovaps [rsp+0xA0], xmm10
00007a40685dac7a  vmovaps [rsp+0xB0], xmm11
00007a40685dac83  vmovaps [rsp+0xC0], xmm13
00007a40685dac8c  vmovaps [rsp+0xD0], xmm14
00007a40685dac95  vmovaps [rsp+0xE0], xmm15
00007a40685dac9e  sub rsp, 0x30
00007a40685daca2  movaps [rsp], xmm12
00007a40685daca7  movaps [rsp+0x10], xmm14
00007a40685dacad  movaps [rsp+0x20], xmm1
00007a40685dacb2  lea rdi, [rsp]
00007a40685dacb6  mov esi, 0x00
00007a40685dacbb  mov rax, 0x56F679577530
00007a40685dacc5  call rax
00007a40685dacc7  movaps xmm12, [rsp]
00007a40685daccc  add rsp, 0x30
00007a40685dacd0  vmovaps xmm0, [rsp]
00007a40685dacd5  vmovaps xmm1, [rsp+0x10]
00007a40685dacdb  vmovaps xmm2, [rsp+0x20]
00007a40685dace1  vmovaps xmm3, [rsp+0x30]
00007a40685dace7  vmovaps xmm4, [rsp+0x40]
00007a40685daced  vmovaps xmm5, [rsp+0x50]
00007a40685dacf3  vmovaps xmm6, [rsp+0x60]
00007a40685dacf9  vmovaps xmm7, [rsp+0x70]
00007a40685dacff  vmovaps xmm8, [rsp+0x80]
00007a40685dad08  vmovaps xmm9, [rsp+0x90]
00007a40685dad11  vmovaps xmm10, [rsp+0xA0]
00007a40685dad1a  vmovaps xmm11, [rsp+0xB0]
00007a40685dad23  vmovaps xmm13, [rsp+0xC0]
00007a40685dad2c  vmovaps xmm14, [rsp+0xD0]
00007a40685dad35  vmovaps xmm15, [rsp+0xE0]
00007a40685dad3e  add rsp, 0xF0
00007a40685dad45  pop r11
00007a40685dad47  pop r10
00007a40685dad49  pop r9
00007a40685dad4b  pop r8
00007a40685dad4d  pop rsi
00007a40685dad4e  pop rdi
00007a40685dad4f  pop rdx
00007a40685dad50  pop rcx
00007a40685dad51  pop rax
00007a40685dad52  add rsp, 0x08
00007a40685dad56  jmp 0x00007A40685D6549
00007a40685dad5b  sub rsp, 0x08
00007a40685dad5f  push rax
00007a40685dad60  push rcx
00007a40685dad61  push rdx
00007a40685dad62  push rdi
00007a40685dad63  push rsi
00007a40685dad64  push r8
00007a40685dad66  push r9
00007a40685dad68  push r10
00007a40685dad6a  push r11
00007a40685dad6c  sub rsp, 0xF0
00007a40685dad73  vmovaps [rsp], xmm0
00007a40685dad78  vmovaps [rsp+0x10], xmm1
00007a40685dad7e  vmovaps [rsp+0x20], xmm2
00007a40685dad84  vmovaps [rsp+0x30], xmm3
00007a40685dad8a  vmovaps [rsp+0x40], xmm4
00007a40685dad90  vmovaps [rsp+0x50], xmm5
00007a40685dad96  vmovaps [rsp+0x60], xmm6
00007a40685dad9c  vmovaps [rsp+0x70], xmm7
00007a40685dada2  vmovaps [rsp+0x80], xmm8
00007a40685dadab  vmovaps [rsp+0x90], xmm9
00007a40685dadb4  vmovaps [rsp+0xA0], xmm10
00007a40685dadbd  vmovaps [rsp+0xB0], xmm11
00007a40685dadc6  vmovaps [rsp+0xC0], xmm12
00007a40685dadcf  vmovaps [rsp+0xD0], xmm13
00007a40685dadd8  vmovaps [rsp+0xE0], xmm15
00007a40685dade1  sub rsp, 0x30
00007a40685dade5  movaps [rsp], xmm14
00007a40685dadea  movaps [rsp+0x10], xmm9
00007a40685dadf0  movaps [rsp+0x20], xmm1
00007a40685dadf5  lea rdi, [rsp]
00007a40685dadf9  mov esi, 0x00
00007a40685dadfe  mov rax, 0x56F679577530
00007a40685dae08  call rax
00007a40685dae0a  movaps xmm14, [rsp]
00007a40685dae0f  add rsp, 0x30
00007a40685dae13  vmovaps xmm0, [rsp]
00007a40685dae18  vmovaps xmm1, [rsp+0x10]
00007a40685dae1e  vmovaps xmm2, [rsp+0x20]
00007a40685dae24  vmovaps xmm3, [rsp+0x30]
00007a40685dae2a  vmovaps xmm4, [rsp+0x40]
00007a40685dae30  vmovaps xmm5, [rsp+0x50]
00007a40685dae36  vmovaps xmm6, [rsp+0x60]
00007a40685dae3c  vmovaps xmm7, [rsp+0x70]
00007a40685dae42  vmovaps xmm8, [rsp+0x80]
00007a40685dae4b  vmovaps xmm9, [rsp+0x90]
00007a40685dae54  vmovaps xmm10, [rsp+0xA0]
00007a40685dae5d  vmovaps xmm11, [rsp+0xB0]
00007a40685dae66  vmovaps xmm12, [rsp+0xC0]
00007a40685dae6f  vmovaps xmm13, [rsp+0xD0]
00007a40685dae78  vmovaps xmm15, [rsp+0xE0]
00007a40685dae81  add rsp, 0xF0
00007a40685dae88  pop r11
00007a40685dae8a  pop r10
00007a40685dae8c  pop r9
00007a40685dae8e  pop r8
00007a40685dae90  pop rsi
00007a40685dae91  pop rdi
00007a40685dae92  pop rdx
00007a40685dae93  pop rcx
00007a40685dae94  pop rax
00007a40685dae95  add rsp, 0x08
00007a40685dae99  jmp 0x00007A40685D6578
00007a40685dae9e  sub rsp, 0x08
00007a40685daea2  push rax
00007a40685daea3  push rcx
00007a40685daea4  push rdx
00007a40685daea5  push rdi
00007a40685daea6  push rsi
00007a40685daea7  push r8
00007a40685daea9  push r9
00007a40685daeab  push r10
00007a40685daead  push r11
00007a40685daeaf  sub rsp, 0xF0
00007a40685daeb6  vmovaps [rsp], xmm0
00007a40685daebb  vmovaps [rsp+0x10], xmm2
00007a40685daec1  vmovaps [rsp+0x20], xmm3
00007a40685daec7  vmovaps [rsp+0x30], xmm4
00007a40685daecd  vmovaps [rsp+0x40], xmm5
00007a40685daed3  vmovaps [rsp+0x50], xmm6
00007a40685daed9  vmovaps [rsp+0x60], xmm7
00007a40685daedf  vmovaps [rsp+0x70], xmm8
00007a40685daee5  vmovaps [rsp+0x80], xmm9
00007a40685daeee  vmovaps [rsp+0x90], xmm10
00007a40685daef7  vmovaps [rsp+0xA0], xmm11
00007a40685daf00  vmovaps [rsp+0xB0], xmm12
00007a40685daf09  vmovaps [rsp+0xC0], xmm13
00007a40685daf12  vmovaps [rsp+0xD0], xmm14
00007a40685daf1b  vmovaps [rsp+0xE0], xmm15
00007a40685daf24  sub rsp, 0x30
00007a40685daf28  movaps [rsp], xmm1
00007a40685daf2c  movaps [rsp+0x10], xmm13
00007a40685daf32  movaps [rsp+0x20], xmm8
00007a40685daf38  lea rdi, [rsp]
00007a40685daf3c  mov esi, 0x00
00007a40685daf41  mov rax, 0x56F679577530
00007a40685daf4b  call rax
00007a40685daf4d  movaps xmm1, [rsp]
00007a40685daf51  add rsp, 0x30
00007a40685daf55  vmovaps xmm0, [rsp]
00007a40685daf5a  vmovaps xmm2, [rsp+0x10]
00007a40685daf60  vmovaps xmm3, [rsp+0x20]
00007a40685daf66  vmovaps xmm4, [rsp+0x30]
00007a40685daf6c  vmovaps xmm5, [rsp+0x40]
00007a40685daf72  vmovaps xmm6, [rsp+0x50]
00007a40685daf78  vmovaps xmm7, [rsp+0x60]
00007a40685daf7e  vmovaps xmm8, [rsp+0x70]
00007a40685daf84  vmovaps xmm9, [rsp+0x80]
00007a40685daf8d  vmovaps xmm10, [rsp+0x90]
00007a40685daf96  vmovaps xmm11, [rsp+0xA0]
00007a40685daf9f  vmovaps xmm12, [rsp+0xB0]
00007a40685dafa8  vmovaps xmm13, [rsp+0xC0]
00007a40685dafb1  vmovaps xmm14, [rsp+0xD0]
00007a40685dafba  vmovaps xmm15, [rsp+0xE0]
00007a40685dafc3  add rsp, 0xF0
00007a40685dafca  pop r11
00007a40685dafcc  pop r10
00007a40685dafce  pop r9
00007a40685dafd0  pop r8
00007a40685dafd2  pop rsi
00007a40685dafd3  pop rdi
00007a40685dafd4  pop rdx
00007a40685dafd5  pop rcx
00007a40685dafd6  pop rax
00007a40685dafd7  add rsp, 0x08
00007a40685dafdb  jmp 0x00007A40685D659A
00007a40685dafe0  call 0x00007A406840C260
00007a40685dafe5  jmp 0x00007A40685D65A8
00007a40685dafea  call 0x00007A40684DE950
00007a40685dafef  jmp 0x00007A40685D65B2
00007a40685daff4  sub rsp, 0x08
00007a40685daff8  push rax
00007a40685daff9  push rcx
00007a40685daffa  push rdx
00007a40685daffb  push rdi
00007a40685daffc  push rsi
00007a40685daffd  push r8
00007a40685dafff  push r9
00007a40685db001  push r10
00007a40685db003  push r11
00007a40685db005  sub rsp, 0xF0
00007a40685db00c  vmovaps [rsp], xmm0
00007a40685db011  vmovaps [rsp+0x10], xmm1
00007a40685db017  vmovaps [rsp+0x20], xmm2
00007a40685db01d  vmovaps [rsp+0x30], xmm3
00007a40685db023  vmovaps [rsp+0x40], xmm4
00007a40685db029  vmovaps [rsp+0x50], xmm5
00007a40685db02f  vmovaps [rsp+0x60], xmm6
00007a40685db035  vmovaps [rsp+0x70], xmm7
00007a40685db03b  vmovaps [rsp+0x80], xmm9
00007a40685db044  vmovaps [rsp+0x90], xmm10
00007a40685db04d  vmovaps [rsp+0xA0], xmm11
00007a40685db056  vmovaps [rsp+0xB0], xmm12
00007a40685db05f  vmovaps [rsp+0xC0], xmm13
00007a40685db068  vmovaps [rsp+0xD0], xmm14
00007a40685db071  vmovaps [rsp+0xE0], xmm15
00007a40685db07a  sub rsp, 0x30
00007a40685db07e  movaps [rsp], xmm8
00007a40685db083  movaps [rsp+0x10], xmm15
00007a40685db089  movaps [rsp+0x20], xmm7
00007a40685db08e  lea rdi, [rsp]
00007a40685db092  mov esi, 0x00
00007a40685db097  mov rax, 0x56F679577530
00007a40685db0a1  call rax
00007a40685db0a3  movaps xmm8, [rsp]
00007a40685db0a8  add rsp, 0x30
00007a40685db0ac  vmovaps xmm0, [rsp]
00007a40685db0b1  vmovaps xmm1, [rsp+0x10]
00007a40685db0b7  vmovaps xmm2, [rsp+0x20]
00007a40685db0bd  vmovaps xmm3, [rsp+0x30]
00007a40685db0c3  vmovaps xmm4, [rsp+0x40]
00007a40685db0c9  vmovaps xmm5, [rsp+0x50]
00007a40685db0cf  vmovaps xmm6, [rsp+0x60]
00007a40685db0d5  vmovaps xmm7, [rsp+0x70]
00007a40685db0db  vmovaps xmm9, [rsp+0x80]
00007a40685db0e4  vmovaps xmm10, [rsp+0x90]
00007a40685db0ed  vmovaps xmm11, [rsp+0xA0]
00007a40685db0f6  vmovaps xmm12, [rsp+0xB0]
00007a40685db0ff  vmovaps xmm13, [rsp+0xC0]
00007a40685db108  vmovaps xmm14, [rsp+0xD0]
00007a40685db111  vmovaps xmm15, [rsp+0xE0]
00007a40685db11a  add rsp, 0xF0
00007a40685db121  pop r11
00007a40685db123  pop r10
00007a40685db125  pop r9
00007a40685db127  pop r8
00007a40685db129  pop rsi
00007a40685db12a  pop rdi
00007a40685db12b  pop rdx
00007a40685db12c  pop rcx
00007a40685db12d  pop rax
00007a40685db12e  add rsp, 0x08
00007a40685db132  jmp 0x00007A40685D65D4
00007a40685db137  sub rsp, 0x08
00007a40685db13b  push rax
00007a40685db13c  push rcx
00007a40685db13d  push rdx
00007a40685db13e  push rdi
00007a40685db13f  push rsi
00007a40685db140  push r8
00007a40685db142  push r9
00007a40685db144  push r10
00007a40685db146  push r11
00007a40685db148  sub rsp, 0xF0
00007a40685db14f  vmovaps [rsp], xmm0
00007a40685db154  vmovaps [rsp+0x10], xmm1
00007a40685db15a  vmovaps [rsp+0x20], xmm2
00007a40685db160  vmovaps [rsp+0x30], xmm3
00007a40685db166  vmovaps [rsp+0x40], xmm4
00007a40685db16c  vmovaps [rsp+0x50], xmm5
00007a40685db172  vmovaps [rsp+0x60], xmm6
00007a40685db178  vmovaps [rsp+0x70], xmm8
00007a40685db17e  vmovaps [rsp+0x80], xmm9
00007a40685db187  vmovaps [rsp+0x90], xmm10
00007a40685db190  vmovaps [rsp+0xA0], xmm11
00007a40685db199  vmovaps [rsp+0xB0], xmm12
00007a40685db1a2  vmovaps [rsp+0xC0], xmm13
00007a40685db1ab  vmovaps [rsp+0xD0], xmm14
00007a40685db1b4  vmovaps [rsp+0xE0], xmm15
00007a40685db1bd  sub rsp, 0x30
00007a40685db1c1  movaps [rsp], xmm7
00007a40685db1c5  movaps [rsp+0x10], xmm9
00007a40685db1cb  movaps [rsp+0x20], xmm15
00007a40685db1d1  lea rdi, [rsp]
00007a40685db1d5  mov esi, 0x00
00007a40685db1da  mov rax, 0x56F679577530
00007a40685db1e4  call rax
00007a40685db1e6  movaps xmm7, [rsp]
00007a40685db1ea  add rsp, 0x30
00007a40685db1ee  vmovaps xmm0, [rsp]
00007a40685db1f3  vmovaps xmm1, [rsp+0x10]
00007a40685db1f9  vmovaps xmm2, [rsp+0x20]
00007a40685db1ff  vmovaps xmm3, [rsp+0x30]
00007a40685db205  vmovaps xmm4, [rsp+0x40]
00007a40685db20b  vmovaps xmm5, [rsp+0x50]
00007a40685db211  vmovaps xmm6, [rsp+0x60]
00007a40685db217  vmovaps xmm8, [rsp+0x70]
00007a40685db21d  vmovaps xmm9, [rsp+0x80]
00007a40685db226  vmovaps xmm10, [rsp+0x90]
00007a40685db22f  vmovaps xmm11, [rsp+0xA0]
00007a40685db238  vmovaps xmm12, [rsp+0xB0]
00007a40685db241  vmovaps xmm13, [rsp+0xC0]
00007a40685db24a  vmovaps xmm14, [rsp+0xD0]
00007a40685db253  vmovaps xmm15, [rsp+0xE0]
00007a40685db25c  add rsp, 0xF0
00007a40685db263  pop r11
00007a40685db265  pop r10
00007a40685db267  pop r9
00007a40685db269  pop r8
00007a40685db26b  pop rsi
00007a40685db26c  pop rdi
00007a40685db26d  pop rdx
00007a40685db26e  pop rcx
00007a40685db26f  pop rax
00007a40685db270  add rsp, 0x08
00007a40685db274  jmp 0x00007A40685D6601
00007a40685db279  sub rsp, 0x08
00007a40685db27d  push rax
00007a40685db27e  push rcx
00007a40685db27f  push rdx
00007a40685db280  push rdi
00007a40685db281  push rsi
00007a40685db282  push r8
00007a40685db284  push r9
00007a40685db286  push r10
00007a40685db288  push r11
00007a40685db28a  sub rsp, 0xF0
00007a40685db291  vmovaps [rsp], xmm0
00007a40685db296  vmovaps [rsp+0x10], xmm1
00007a40685db29c  vmovaps [rsp+0x20], xmm2
00007a40685db2a2  vmovaps [rsp+0x30], xmm3
00007a40685db2a8  vmovaps [rsp+0x40], xmm4
00007a40685db2ae  vmovaps [rsp+0x50], xmm5
00007a40685db2b4  vmovaps [rsp+0x60], xmm6
00007a40685db2ba  vmovaps [rsp+0x70], xmm7
00007a40685db2c0  vmovaps [rsp+0x80], xmm8
00007a40685db2c9  vmovaps [rsp+0x90], xmm10
00007a40685db2d2  vmovaps [rsp+0xA0], xmm11
00007a40685db2db  vmovaps [rsp+0xB0], xmm12
00007a40685db2e4  vmovaps [rsp+0xC0], xmm13
00007a40685db2ed  vmovaps [rsp+0xD0], xmm14
00007a40685db2f6  vmovaps [rsp+0xE0], xmm15
00007a40685db2ff  sub rsp, 0x30
00007a40685db303  movaps [rsp], xmm9
00007a40685db308  movaps [rsp+0x10], xmm13
00007a40685db30e  movaps [rsp+0x20], xmm15
00007a40685db314  lea rdi, [rsp]
00007a40685db318  mov esi, 0x00
00007a40685db31d  mov rax, 0x56F679577530
00007a40685db327  call rax
00007a40685db329  movaps xmm9, [rsp]
00007a40685db32e  add rsp, 0x30
00007a40685db332  vmovaps xmm0, [rsp]
00007a40685db337  vmovaps xmm1, [rsp+0x10]
00007a40685db33d  vmovaps xmm2, [rsp+0x20]
00007a40685db343  vmovaps xmm3, [rsp+0x30]
00007a40685db349  vmovaps xmm4, [rsp+0x40]
00007a40685db34f  vmovaps xmm5, [rsp+0x50]
00007a40685db355  vmovaps xmm6, [rsp+0x60]
00007a40685db35b  vmovaps xmm7, [rsp+0x70]
00007a40685db361  vmovaps xmm8, [rsp+0x80]
00007a40685db36a  vmovaps xmm10, [rsp+0x90]
00007a40685db373  vmovaps xmm11, [rsp+0xA0]
00007a40685db37c  vmovaps xmm12, [rsp+0xB0]
00007a40685db385  vmovaps xmm13, [rsp+0xC0]
00007a40685db38e  vmovaps xmm14, [rsp+0xD0]
00007a40685db397  vmovaps xmm15, [rsp+0xE0]
00007a40685db3a0  add rsp, 0xF0
00007a40685db3a7  pop r11
00007a40685db3a9  pop r10
00007a40685db3ab  pop r9
00007a40685db3ad  pop r8
00007a40685db3af  pop rsi
00007a40685db3b0  pop rdi
00007a40685db3b1  pop rdx
00007a40685db3b2  pop rcx
00007a40685db3b3  pop rax
00007a40685db3b4  add rsp, 0x08
00007a40685db3b8  jmp 0x00007A40685D662F
00007a40685db3bd  sub rsp, 0x08
00007a40685db3c1  push rax
00007a40685db3c2  push rcx
00007a40685db3c3  push rdx
00007a40685db3c4  push rdi
00007a40685db3c5  push rsi
00007a40685db3c6  push r8
00007a40685db3c8  push r9
00007a40685db3ca  push r10
00007a40685db3cc  push r11
00007a40685db3ce  sub rsp, 0xF0
00007a40685db3d5  vmovaps [rsp], xmm0
00007a40685db3da  vmovaps [rsp+0x10], xmm1
00007a40685db3e0  vmovaps [rsp+0x20], xmm2
00007a40685db3e6  vmovaps [rsp+0x30], xmm3
00007a40685db3ec  vmovaps [rsp+0x40], xmm4
00007a40685db3f2  vmovaps [rsp+0x50], xmm5
00007a40685db3f8  vmovaps [rsp+0x60], xmm6
00007a40685db3fe  vmovaps [rsp+0x70], xmm7
00007a40685db404  vmovaps [rsp+0x80], xmm8
00007a40685db40d  vmovaps [rsp+0x90], xmm9
00007a40685db416  vmovaps [rsp+0xA0], xmm10
00007a40685db41f  vmovaps [rsp+0xB0], xmm11
00007a40685db428  vmovaps [rsp+0xC0], xmm12
00007a40685db431  vmovaps [rsp+0xD0], xmm13
00007a40685db43a  vmovaps [rsp+0xE0], xmm14
00007a40685db443  sub rsp, 0x30
00007a40685db447  movaps [rsp], xmm15
00007a40685db44c  movaps [rsp+0x10], xmm11
00007a40685db452  movaps [rsp+0x20], xmm12
00007a40685db458  lea rdi, [rsp]
00007a40685db45c  mov esi, 0x00
00007a40685db461  mov rax, 0x56F679577530
00007a40685db46b  call rax
00007a40685db46d  movaps xmm15, [rsp]
00007a40685db472  add rsp, 0x30
00007a40685db476  vmovaps xmm0, [rsp]
00007a40685db47b  vmovaps xmm1, [rsp+0x10]
00007a40685db481  vmovaps xmm2, [rsp+0x20]
00007a40685db487  vmovaps xmm3, [rsp+0x30]
00007a40685db48d  vmovaps xmm4, [rsp+0x40]
00007a40685db493  vmovaps xmm5, [rsp+0x50]
00007a40685db499  vmovaps xmm6, [rsp+0x60]
00007a40685db49f  vmovaps xmm7, [rsp+0x70]
00007a40685db4a5  vmovaps xmm8, [rsp+0x80]
00007a40685db4ae  vmovaps xmm9, [rsp+0x90]
00007a40685db4b7  vmovaps xmm10, [rsp+0xA0]
00007a40685db4c0  vmovaps xmm11, [rsp+0xB0]
00007a40685db4c9  vmovaps xmm12, [rsp+0xC0]
00007a40685db4d2  vmovaps xmm13, [rsp+0xD0]
00007a40685db4db  vmovaps xmm14, [rsp+0xE0]
00007a40685db4e4  add rsp, 0xF0
00007a40685db4eb  pop r11
00007a40685db4ed  pop r10
00007a40685db4ef  pop r9
00007a40685db4f1  pop r8
00007a40685db4f3  pop rsi
00007a40685db4f4  pop rdi
00007a40685db4f5  pop rdx
00007a40685db4f6  pop rcx
00007a40685db4f7  pop rax
00007a40685db4f8  add rsp, 0x08
00007a40685db4fc  jmp 0x00007A40685D664A
00007a40685db501  sub rsp, 0x08
00007a40685db505  push rax
00007a40685db506  push rcx
00007a40685db507  push rdx
00007a40685db508  push rdi
00007a40685db509  push rsi
00007a40685db50a  push r8
00007a40685db50c  push r9
00007a40685db50e  push r10
00007a40685db510  push r11
00007a40685db512  sub rsp, 0xF0
00007a40685db519  vmovaps [rsp], xmm0
00007a40685db51e  vmovaps [rsp+0x10], xmm1
00007a40685db524  vmovaps [rsp+0x20], xmm2
00007a40685db52a  vmovaps [rsp+0x30], xmm3
00007a40685db530  vmovaps [rsp+0x40], xmm4
00007a40685db536  vmovaps [rsp+0x50], xmm5
00007a40685db53c  vmovaps [rsp+0x60], xmm6
00007a40685db542  vmovaps [rsp+0x70], xmm7
00007a40685db548  vmovaps [rsp+0x80], xmm8
00007a40685db551  vmovaps [rsp+0x90], xmm9
00007a40685db55a  vmovaps [rsp+0xA0], xmm10
00007a40685db563  vmovaps [rsp+0xB0], xmm11
00007a40685db56c  vmovaps [rsp+0xC0], xmm12
00007a40685db575  vmovaps [rsp+0xD0], xmm14
00007a40685db57e  vmovaps [rsp+0xE0], xmm15
00007a40685db587  sub rsp, 0x30
00007a40685db58b  movaps [rsp], xmm13
00007a40685db590  movaps [rsp+0x10], xmm10
00007a40685db596  movaps [rsp+0x20], xmm14
00007a40685db59c  lea rdi, [rsp]
00007a40685db5a0  mov esi, 0x00
00007a40685db5a5  mov rax, 0x56F679577530
00007a40685db5af  call rax
00007a40685db5b1  movaps xmm13, [rsp]
00007a40685db5b6  add rsp, 0x30
00007a40685db5ba  vmovaps xmm0, [rsp]
00007a40685db5bf  vmovaps xmm1, [rsp+0x10]
00007a40685db5c5  vmovaps xmm2, [rsp+0x20]
00007a40685db5cb  vmovaps xmm3, [rsp+0x30]
00007a40685db5d1  vmovaps xmm4, [rsp+0x40]
00007a40685db5d7  vmovaps xmm5, [rsp+0x50]
00007a40685db5dd  vmovaps xmm6, [rsp+0x60]
00007a40685db5e3  vmovaps xmm7, [rsp+0x70]
00007a40685db5e9  vmovaps xmm8, [rsp+0x80]
00007a40685db5f2  vmovaps xmm9, [rsp+0x90]
00007a40685db5fb  vmovaps xmm10, [rsp+0xA0]
00007a40685db604  vmovaps xmm11, [rsp+0xB0]
00007a40685db60d  vmovaps xmm12, [rsp+0xC0]
00007a40685db616  vmovaps xmm14, [rsp+0xD0]
00007a40685db61f  vmovaps xmm15, [rsp+0xE0]
00007a40685db628  add rsp, 0xF0
00007a40685db62f  pop r11
00007a40685db631  pop r10
00007a40685db633  pop r9
00007a40685db635  pop r8
00007a40685db637  pop rsi
00007a40685db638  pop rdi
00007a40685db639  pop rdx
00007a40685db63a  pop rcx
00007a40685db63b  pop rax
00007a40685db63c  add rsp, 0x08
00007a40685db640  jmp 0x00007A40685D666D
00007a40685db645  sub rsp, 0x08
00007a40685db649  push rax
00007a40685db64a  push rcx
00007a40685db64b  push rdx
00007a40685db64c  push rdi
00007a40685db64d  push rsi
00007a40685db64e  push r8
00007a40685db650  push r9
00007a40685db652  push r10
00007a40685db654  push r11
00007a40685db656  sub rsp, 0xF0
00007a40685db65d  vmovaps [rsp], xmm0
00007a40685db662  vmovaps [rsp+0x10], xmm1
00007a40685db668  vmovaps [rsp+0x20], xmm2
00007a40685db66e  vmovaps [rsp+0x30], xmm3
00007a40685db674  vmovaps [rsp+0x40], xmm4
00007a40685db67a  vmovaps [rsp+0x50], xmm5
00007a40685db680  vmovaps [rsp+0x60], xmm6
00007a40685db686  vmovaps [rsp+0x70], xmm7
00007a40685db68c  vmovaps [rsp+0x80], xmm8
00007a40685db695  vmovaps [rsp+0x90], xmm9
00007a40685db69e  vmovaps [rsp+0xA0], xmm10
00007a40685db6a7  vmovaps [rsp+0xB0], xmm11
00007a40685db6b0  vmovaps [rsp+0xC0], xmm12
00007a40685db6b9  vmovaps [rsp+0xD0], xmm13
00007a40685db6c2  vmovaps [rsp+0xE0], xmm15
00007a40685db6cb  sub rsp, 0x30
00007a40685db6cf  movaps [rsp], xmm14
00007a40685db6d4  movaps [rsp+0x10], xmm1
00007a40685db6d9  movaps [rsp+0x20], xmm7
00007a40685db6de  lea rdi, [rsp]
00007a40685db6e2  mov esi, 0x00
00007a40685db6e7  mov rax, 0x56F679577530
00007a40685db6f1  call rax
00007a40685db6f3  movaps xmm14, [rsp]
00007a40685db6f8  add rsp, 0x30
00007a40685db6fc  vmovaps xmm0, [rsp]
00007a40685db701  vmovaps xmm1, [rsp+0x10]
00007a40685db707  vmovaps xmm2, [rsp+0x20]
00007a40685db70d  vmovaps xmm3, [rsp+0x30]
00007a40685db713  vmovaps xmm4, [rsp+0x40]
00007a40685db719  vmovaps xmm5, [rsp+0x50]
00007a40685db71f  vmovaps xmm6, [rsp+0x60]
00007a40685db725  vmovaps xmm7, [rsp+0x70]
00007a40685db72b  vmovaps xmm8, [rsp+0x80]
00007a40685db734  vmovaps xmm9, [rsp+0x90]
00007a40685db73d  vmovaps xmm10, [rsp+0xA0]
00007a40685db746  vmovaps xmm11, [rsp+0xB0]
00007a40685db74f  vmovaps xmm12, [rsp+0xC0]
00007a40685db758  vmovaps xmm13, [rsp+0xD0]
00007a40685db761  vmovaps xmm15, [rsp+0xE0]
00007a40685db76a  add rsp, 0xF0
00007a40685db771  pop r11
00007a40685db773  pop r10
00007a40685db775  pop r9
00007a40685db777  pop r8
00007a40685db779  pop rsi
00007a40685db77a  pop rdi
00007a40685db77b  pop rdx
00007a40685db77c  pop rcx
00007a40685db77d  pop rax
00007a40685db77e  add rsp, 0x08
00007a40685db782  jmp 0x00007A40685D6690
00007a40685db787  sub rsp, 0x08
00007a40685db78b  push rax
00007a40685db78c  push rcx
00007a40685db78d  push rdx
00007a40685db78e  push rdi
00007a40685db78f  push rsi
00007a40685db790  push r8
00007a40685db792  push r9
00007a40685db794  push r10
00007a40685db796  push r11
00007a40685db798  sub rsp, 0xF0
00007a40685db79f  vmovaps [rsp], xmm0
00007a40685db7a4  vmovaps [rsp+0x10], xmm2
00007a40685db7aa  vmovaps [rsp+0x20], xmm3
00007a40685db7b0  vmovaps [rsp+0x30], xmm4
00007a40685db7b6  vmovaps [rsp+0x40], xmm5
00007a40685db7bc  vmovaps [rsp+0x50], xmm6
00007a40685db7c2  vmovaps [rsp+0x60], xmm7
00007a40685db7c8  vmovaps [rsp+0x70], xmm8
00007a40685db7ce  vmovaps [rsp+0x80], xmm9
00007a40685db7d7  vmovaps [rsp+0x90], xmm10
00007a40685db7e0  vmovaps [rsp+0xA0], xmm11
00007a40685db7e9  vmovaps [rsp+0xB0], xmm12
00007a40685db7f2  vmovaps [rsp+0xC0], xmm13
00007a40685db7fb  vmovaps [rsp+0xD0], xmm14
00007a40685db804  vmovaps [rsp+0xE0], xmm15
00007a40685db80d  sub rsp, 0x30
00007a40685db811  movaps [rsp], xmm1
00007a40685db815  movaps [rsp+0x10], xmm8
00007a40685db81b  movaps [rsp+0x20], xmm9
00007a40685db821  lea rdi, [rsp]
00007a40685db825  mov esi, 0x00
00007a40685db82a  mov rax, 0x56F679577530
00007a40685db834  call rax
00007a40685db836  movaps xmm1, [rsp]
00007a40685db83a  add rsp, 0x30
00007a40685db83e  vmovaps xmm0, [rsp]
00007a40685db843  vmovaps xmm2, [rsp+0x10]
00007a40685db849  vmovaps xmm3, [rsp+0x20]
00007a40685db84f  vmovaps xmm4, [rsp+0x30]
00007a40685db855  vmovaps xmm5, [rsp+0x40]
00007a40685db85b  vmovaps xmm6, [rsp+0x50]
00007a40685db861  vmovaps xmm7, [rsp+0x60]
00007a40685db867  vmovaps xmm8, [rsp+0x70]
00007a40685db86d  vmovaps xmm9, [rsp+0x80]
00007a40685db876  vmovaps xmm10, [rsp+0x90]
00007a40685db87f  vmovaps xmm11, [rsp+0xA0]
00007a40685db888  vmovaps xmm12, [rsp+0xB0]
00007a40685db891  vmovaps xmm13, [rsp+0xC0]
00007a40685db89a  vmovaps xmm14, [rsp+0xD0]
00007a40685db8a3  vmovaps xmm15, [rsp+0xE0]
00007a40685db8ac  add rsp, 0xF0
00007a40685db8b3  pop r11
00007a40685db8b5  pop r10
00007a40685db8b7  pop r9
00007a40685db8b9  pop r8
00007a40685db8bb  pop rsi
00007a40685db8bc  pop rdi
00007a40685db8bd  pop rdx
00007a40685db8be  pop rcx
00007a40685db8bf  pop rax
00007a40685db8c0  add rsp, 0x08
00007a40685db8c4  jmp 0x00007A40685D66B2
00007a40685db8c9  call 0x00007A40684B3E40
00007a40685db8ce  jmp 0x00007A40685D66C0
00007a40685db8d3  call 0x00007A406840C380
00007a40685db8d8  jmp 0x00007A40685D66CA
00007a40685db8dd  call 0x00007A406840D600
00007a40685db8e2  jmp 0x00007A40685D66D4
00007a40685db8e7  call 0x00007A40683FF540
00007a40685db8ec  jmp 0x00007A40685D66DE
00007a40685db8f1  int3
00007a40685db8f2  nop [rax+rax*1], ax
00007a40685db8fb  nop [rax+rax*1], eax
00007a40685db900  mov eax, [r15+0x48]
00007a40685db904  lea r14d, [eax+0x01]
00007a40685db909  mov [rsp+0x10], r14d
00007a40685db90e  mov r14d, r14d
00007a40685db911  mov [r15+0x48], r14
00007a40685db915  xor eax, eax
00007a40685db917  mov r14d, [rsp+0x10]
00007a40685db91c  cmp r14d, 0x1F4
00007a40685db923  cmc
00007a40685db924  lahf
00007a40685db925  seto al
00007a40685db928  mov [r15+0x108], eax
00007a40685db92f  mov eax, [r15+0x108]
00007a40685db936  sahf
00007a40685db937  jnz 0x00007A40685DB969
00007a40685db939  cmp dword ptr [r15+0x318], 0x00
00007a40685db941  jz 0x00007A40685E1AB0
00007a40685db947  nop [rax+rax*1], ax
00007a40685db950  nop [rax+rax*1], eax
00007a40685db958  mov eax, 0x410450
00007a40685db95d  mov [r15+0x100], rax
00007a40685db964  jmp 0x00007A40683FE110
00007a40685db969  cmp dword ptr [r15+0x318], 0x00
00007a40685db971  jz 0x00007A40685DB9A0
00007a40685db977  nop [rax+rax*1], ax
00007a40685db980  nop [rax+rax*1], eax
00007a40685db988  mov eax, 0x410274
00007a40685db98d  mov [r15+0x100], rax
00007a40685db994  jmp 0x00007A40683FE110
00007a40685db999  int3
00007a40685db99a  int3
00007a40685db99b  nop [rax+rax*1], eax
00007a40685db9a0  mov rax, [r15+0x40]
00007a40685db9a4  movaps xmm1, [r15+0x1D0]
00007a40685db9ac  vmovaps [rsp+0x10], xmm1
00007a40685db9b2  vmovaps xmm15, [rsp+0x10]
00007a40685db9b8  por xmm1, xmm15
00007a40685db9bd  movaps xmm14, [r15+0x1A0]
00007a40685db9c5  vmovaps [rsp+0x10], xmm14
00007a40685db9cb  vmovaps xmm13, [rsp+0x10]
00007a40685db9d1  por xmm14, xmm13
00007a40685db9d6  lea r14, [rax+0x30]
00007a40685db9da  mov r12, [r13+r14*1]
00007a40685db9df  lea r14, [rax+0x38]
00007a40685db9e3  mov r11, [r13+r14*1]
00007a40685db9e8  movq xmm13, r12
00007a40685db9ed  movq xmm12, r11
00007a40685db9f2  movq xmm13, xmm13
00007a40685db9f7  vmovaps [rsp+0x10], xmm13
00007a40685db9fd  movq xmm13, xmm13
00007a40685dba02  movaps [r15+0x130], xmm13
00007a40685dba0a  movq xmm12, xmm12
00007a40685dba0f  vmovaps [rsp+0x20], xmm12
00007a40685dba15  movq xmm12, xmm12
00007a40685dba1a  movaps [r15+0x280], xmm12
00007a40685dba22  movaps xmm13, [r15+0x270]
00007a40685dba2a  vmovaps [rsp+0x30], xmm13
00007a40685dba30  vmovaps xmm12, [rsp+0x30]
00007a40685dba36  por xmm13, xmm12
00007a40685dba3b  lea r14, [rax+0x20]
00007a40685dba3f  mov r12, [r13+r14*1]
00007a40685dba44  lea r14, [rax+0x28]
00007a40685dba48  mov r11, [r13+r14*1]
00007a40685dba4d  movq xmm12, r12
00007a40685dba52  movq xmm11, r11
00007a40685dba57  movq xmm12, xmm12
00007a40685dba5c  vmovaps [rsp+0x30], xmm12
00007a40685dba62  movq xmm12, xmm12
00007a40685dba67  movaps [r15+0x150], xmm12
00007a40685dba6f  movq xmm11, xmm11
00007a40685dba74  vmovaps [rsp+0x40], xmm11
00007a40685dba7a  movq xmm11, xmm11
00007a40685dba7f  movaps [r15+0x140], xmm11
00007a40685dba87  lea r14, [rax+0x10]
00007a40685dba8b  mov r12, [r13+r14*1]
00007a40685dba90  lea r14, [rax+0x18]
00007a40685dba94  mov r11, [r13+r14*1]
00007a40685dba99  movq xmm12, r12
00007a40685dba9e  movq xmm11, r11
00007a40685dbaa3  movq xmm12, xmm12
00007a40685dbaa8  vmovaps [rsp+0x50], xmm12
00007a40685dbaae  movq xmm12, xmm12
00007a40685dbab3  movaps [r15+0x170], xmm12
00007a40685dbabb  movq xmm11, xmm11
00007a40685dbac0  vmovaps [rsp+0x60], xmm11
00007a40685dbac6  movq xmm11, xmm11
00007a40685dbacb  movaps [r15+0x160], xmm11
00007a40685dbad3  mov r14, [r13+rax*1]
00007a40685dbad8  vmovq xmm12, r14
00007a40685dbadd  vpbroadcastq xmm12, xmm12
00007a40685dbae2  lea r14, [rax+0x08]
00007a40685dbae6  mov rax, [r13+r14*1]
00007a40685dbaeb  movq xmm11, rax
00007a40685dbaf0  movaps [r15+0x230], xmm11
00007a40685dbaf8  mov rax, [r15+0xF8]
00007a40685dbaff  lea r14, [rax+0x50]
00007a40685dbb03  movups xmm11, [r13+r14*1]
00007a40685dbb09  lea r14, [rax+0x60]
00007a40685dbb0d  movups xmm10, [r13+r14*1]
00007a40685dbb13  lea r14, [rax+0x30]
00007a40685dbb17  movups xmm9, [r13+r14*1]
00007a40685dbb1d  mov r14, [r15+0x50]
00007a40685dbb21  mov [r15+0x60], r14
00007a40685dbb25  mov qword ptr [r15+0x58], 0x40
00007a40685dbb2d  movaps xmm8, xmm12
00007a40685dbb31  mulpd xmm8, xmm15
00007a40685dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007a40685dbb3c  ptest xmm7, xmm7
00007a40685dbb41  jnz 0x00007A40685DC96A
00007a40685dbb47  movq xmm15, qword ptr [r15+0x230]
00007a40685dbb50  vmovaps [rsp+0x70], xmm15
00007a40685dbb56  vpermilpd xmm15, xmm15, 0x00
00007a40685dbb5c  movaps xmm7, xmm9
00007a40685dbb60  mulpd xmm7, xmm15
00007a40685dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007a40685dbb6a  ptest xmm6, xmm6
00007a40685dbb6f  jnz 0x00007A40685DCAAE
00007a40685dbb75  vxorps xmm15, xmm15, xmm15
00007a40685dbb7a  vpbroadcastq xmm15, xmm15
00007a40685dbb7f  movaps xmm9, xmm12
00007a40685dbb83  mulpd xmm9, xmm10
00007a40685dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007a40685dbb8e  ptest xmm6, xmm6
00007a40685dbb93  jnz 0x00007A40685DCBF0
00007a40685dbb99  movaps xmm10, xmm12
00007a40685dbb9d  mulpd xmm10, xmm11
00007a40685dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007a40685dbba8  ptest xmm6, xmm6
00007a40685dbbad  jnz 0x00007A40685DCD34
00007a40685dbbb3  movaps xmm11, [r15+0x1F0]
00007a40685dbbbb  movaps xmm6, xmm12
00007a40685dbbbf  mulpd xmm6, xmm11
00007a40685dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007a40685dbbc9  ptest xmm5, xmm5
00007a40685dbbce  jnz 0x00007A40685DCE78
00007a40685dbbd4  movaps xmm12, [r15+0x2A0]
00007a40685dbbdc  vmovaps [rsp+0x80], xmm12
00007a40685dbbe5  vmovaps xmm11, [rsp+0x80]
00007a40685dbbee  por xmm12, xmm11
00007a40685dbbf3  movaps xmm11, [r15+0x250]
00007a40685dbbfb  vmovaps [rsp+0x80], xmm11
00007a40685dbc04  vmovaps xmm5, [rsp+0x80]
00007a40685dbc0d  por xmm11, xmm5
00007a40685dbc12  vmovaps xmm4, [rsp+0x70]
00007a40685dbc18  vpermilpd xmm4, xmm4, 0x00
00007a40685dbc1e  movaps xmm3, xmm5
00007a40685dbc21  mulpd xmm3, xmm4
00007a40685dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007a40685dbc2a  ptest xmm2, xmm2
00007a40685dbc2f  jnz 0x00007A40685DCFBA
00007a40685dbc35  mov [rsp+0x80], rax
00007a40685dbc3d  xor eax, eax
00007a40685dbc3f  mov r12d, 0x40
00007a40685dbc45  mov r11d, 0x200
00007a40685dbc4b  cmp r12, r11
00007a40685dbc4e  cmc
00007a40685dbc4f  lahf
00007a40685dbc50  seto al
00007a40685dbc53  mov [r15+0x108], eax
00007a40685dbc5a  movaps xmm5, xmm8
00007a40685dbc5e  addpd xmm5, xmm15
00007a40685dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007a40685dbc68  ptest xmm4, xmm4
00007a40685dbc6d  jnz 0x00007A40685DD0FA
00007a40685dbc73  movaps xmm8, [r15+0x1B0]
00007a40685dbc7b  movaps xmm4, xmm9
00007a40685dbc7f  addpd xmm4, xmm8
00007a40685dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007a40685dbc89  ptest xmm2, xmm2
00007a40685dbc8e  jnz 0x00007A40685DD23C
00007a40685dbc94  movaps xmm9, xmm10
00007a40685dbc98  addpd xmm9, xmm8
00007a40685dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007a40685dbca3  ptest xmm2, xmm2
00007a40685dbca8  jnz 0x00007A40685DD37E
00007a40685dbcae  movaps xmm10, [r15+0x2F0]
00007a40685dbcb6  vmovaps [rsp+0x90], xmm10
00007a40685dbcbf  vmovaps xmm8, [rsp+0x90]
00007a40685dbcc8  por xmm10, xmm8
00007a40685dbccd  movaps xmm8, [r15+0x2E0]
00007a40685dbcd5  vmovaps [rsp+0x90], xmm8
00007a40685dbcde  vmovaps xmm2, [rsp+0x90]
00007a40685dbce7  por xmm8, xmm2
00007a40685dbcec  movaps xmm2, [r15+0x2D0]
00007a40685dbcf4  vmovaps [rsp+0x90], xmm2
00007a40685dbcfd  vmovaps [rsp+0xA0], xmm1
00007a40685dbd06  vmovaps xmm1, [rsp+0x90]
00007a40685dbd0f  por xmm2, xmm1
00007a40685dbd13  movaps xmm1, [r15+0x200]
00007a40685dbd1b  vmovaps [rsp+0x90], xmm1
00007a40685dbd24  vmovaps [rsp+0xB0], xmm15
00007a40685dbd2d  vmovaps xmm15, [rsp+0x90]
00007a40685dbd36  por xmm1, xmm15
00007a40685dbd3b  movaps xmm15, [r15+0x1C0]
00007a40685dbd43  vmovaps [rsp+0x90], xmm15
00007a40685dbd4c  vmovaps [rsp+0xC0], xmm1
00007a40685dbd55  vmovaps xmm1, [rsp+0x90]
00007a40685dbd5e  por xmm15, xmm1
00007a40685dbd63  movaps xmm1, [r15+0x190]
00007a40685dbd6b  vmovaps [rsp+0x90], xmm1
00007a40685dbd74  vmovaps [rsp+0xD0], xmm15
00007a40685dbd7d  vmovaps xmm15, [rsp+0x90]
00007a40685dbd86  por xmm1, xmm15
00007a40685dbd8b  movaps xmm15, [r15+0x300]
00007a40685dbd93  vmovaps [rsp+0x90], xmm15
00007a40685dbd9c  vmovaps [rsp+0xE0], xmm1
00007a40685dbda5  vmovaps xmm1, [rsp+0x90]
00007a40685dbdae  por xmm15, xmm1
00007a40685dbdb3  mov rax, [rsp+0x80]
00007a40685dbdbb  lea r12, [rax+0xA0]
00007a40685dbdc2  movups xmm1, [r13+r12*1]
00007a40685dbdc8  lea r12, [rax+0xB0]
00007a40685dbdcf  vmovaps [rsp+0x80], xmm1
00007a40685dbdd8  movups xmm1, [r13+r12*1]
00007a40685dbdde  vmovaps [rsp+0x90], xmm1
00007a40685dbde7  vmovaps [rsp+0xF0], xmm15
00007a40685dbdf0  vmovaps xmm15, [rsp+0xB0]
00007a40685dbdf9  vmovaps [rsp+0xB0], xmm14
00007a40685dbe02  movaps xmm1, xmm6
00007a40685dbe05  addpd xmm1, xmm15
00007a40685dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007a40685dbe0f  ptest xmm14, xmm14
00007a40685dbe15  jnz 0x00007A40685DD4D6
00007a40685dbe1b  lea r12, [rax+0xF0]
00007a40685dbe22  movups xmm15, [r13+r12*1]
00007a40685dbe28  movaps xmm14, xmm4
00007a40685dbe2c  addpd xmm14, xmm3
00007a40685dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007a40685dbe37  ptest xmm6, xmm6
00007a40685dbe3c  jnz 0x00007A40685DD621
00007a40685dbe42  movaps xmm6, xmm9
00007a40685dbe46  addpd xmm6, xmm7
00007a40685dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007a40685dbe4f  ptest xmm4, xmm4
00007a40685dbe54  jnz 0x00007A40685DD763
00007a40685dbe5a  vmovaps xmm9, [rsp+0x70]
00007a40685dbe60  vpermilpd xmm9, xmm9, 0x00
00007a40685dbe66  vmovaps xmm4, [rsp+0x90]
00007a40685dbe6f  movaps xmm7, xmm4
00007a40685dbe72  mulpd xmm7, xmm9
00007a40685dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007a40685dbe7c  ptest xmm3, xmm3
00007a40685dbe81  jnz 0x00007A40685DD8A4
00007a40685dbe87  vmovaps xmm9, [rsp+0x50]
00007a40685dbe8d  vpermilpd xmm9, xmm9, 0x00
00007a40685dbe93  movaps xmm4, xmm15
00007a40685dbe97  mulpd xmm4, xmm9
00007a40685dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007a40685dbea1  ptest xmm3, xmm3
00007a40685dbea6  jnz 0x00007A40685DD9E5
00007a40685dbeac  lea r12, [rax+0xE0]
00007a40685dbeb3  movups xmm15, [r13+r12*1]
00007a40685dbeb9  vmovaps xmm9, [rsp+0x70]
00007a40685dbebf  vpermilpd xmm9, xmm9, 0x00
00007a40685dbec5  vmovaps [rsp+0x70], xmm1
00007a40685dbecb  vmovaps xmm1, [rsp+0x80]
00007a40685dbed4  vmovaps [rsp+0x80], xmm15
00007a40685dbedd  movaps xmm3, xmm1
00007a40685dbee0  mulpd xmm3, xmm9
00007a40685dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007a40685dbeea  ptest xmm15, xmm15
00007a40685dbef0  jnz 0x00007A40685DDB31
00007a40685dbef6  vmovaps xmm1, [rsp+0xF0]
00007a40685dbeff  vmovaps xmm15, [rsp+0xF0]
00007a40685dbf08  por xmm1, xmm15
00007a40685dbf0d  movaps [r15+0x300], xmm1
00007a40685dbf15  vmovaps xmm15, [rsp+0xE0]
00007a40685dbf1e  vmovaps xmm9, [rsp+0xE0]
00007a40685dbf27  por xmm15, xmm9
00007a40685dbf2c  movaps [r15+0x190], xmm15
00007a40685dbf34  vmovaps xmm9, [rsp+0x50]
00007a40685dbf3a  vpermilpd xmm9, xmm9, 0x00
00007a40685dbf40  vmovaps [rsp+0x90], xmm1
00007a40685dbf49  vmovaps [rsp+0xE0], xmm15
00007a40685dbf52  vmovaps xmm15, [rsp+0x80]
00007a40685dbf5b  vmovaps [rsp+0x80], xmm14
00007a40685dbf64  movaps xmm1, xmm15
00007a40685dbf68  mulpd xmm1, xmm9
00007a40685dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007a40685dbf72  ptest xmm14, xmm14
00007a40685dbf78  jnz 0x00007A40685DDC72
00007a40685dbf7e  lea r12, [rax+0x90]
00007a40685dbf85  movups xmm15, [r13+r12*1]
00007a40685dbf8b  vmovaps xmm14, [rsp+0xD0]
00007a40685dbf94  vmovaps xmm9, [rsp+0xD0]
00007a40685dbf9d  por xmm14, xmm9
00007a40685dbfa2  movaps [r15+0x1C0], xmm14
00007a40685dbfaa  vmovaps xmm9, [rsp+0xC0]
00007a40685dbfb3  vmovaps [rsp+0xD0], xmm1
00007a40685dbfbc  vmovaps xmm1, [rsp+0xC0]
00007a40685dbfc5  por xmm9, xmm1
00007a40685dbfca  movaps [r15+0x200], xmm9
00007a40685dbfd2  vmovaps [rsp+0xC0], xmm2
00007a40685dbfdb  vmovaps xmm1, [rsp+0xC0]
00007a40685dbfe4  por xmm2, xmm1
00007a40685dbfe8  movaps [r15+0x2D0], xmm2
00007a40685dbff0  vmovaps [rsp+0xC0], xmm8
00007a40685dbff9  vmovaps xmm1, [rsp+0xC0]
00007a40685dc002  por xmm8, xmm1
00007a40685dc007  movaps [r15+0x2E0], xmm8
00007a40685dc00f  vmovaps [rsp+0xC0], xmm15
00007a40685dc018  movaps xmm1, xmm5
00007a40685dc01b  addpd xmm1, xmm7
00007a40685dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007a40685dc024  ptest xmm15, xmm15
00007a40685dc02a  jnz 0x00007A40685DDDBE
00007a40685dc030  vmovaps xmm15, [rsp+0x50]
00007a40685dc036  vpermilpd xmm15, xmm15, 0x00
00007a40685dc03c  vmovaps xmm5, [rsp+0xC0]
00007a40685dc045  vmovaps [rsp+0xC0], xmm1
00007a40685dc04e  movaps xmm7, xmm5
00007a40685dc051  mulpd xmm7, xmm15
00007a40685dc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007a40685dc05b  ptest xmm1, xmm1
00007a40685dc060  jnz 0x00007A40685DDEFE
00007a40685dc066  lea r12, [rax+0x80]
00007a40685dc06d  movups xmm1, [r13+r12*1]
00007a40685dc073  vmovaps xmm5, [rsp+0x70]
00007a40685dc079  vmovaps [rsp+0x70], xmm1
00007a40685dc07f  movaps xmm15, xmm5
00007a40685dc083  addpd xmm15, xmm3
00007a40685dc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007a40685dc08e  ptest xmm1, xmm1
00007a40685dc093  jnz 0x00007A40685DE049
00007a40685dc099  vmovaps xmm5, [rsp+0x80]
00007a40685dc0a2  movaps xmm1, xmm5
00007a40685dc0a5  addpd xmm1, xmm4
00007a40685dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007a40685dc0ae  ptest xmm3, xmm3
00007a40685dc0b3  jnz 0x00007A40685DE18B
00007a40685dc0b9  vmovaps [rsp+0x80], xmm10
00007a40685dc0c2  vmovaps xmm5, [rsp+0x80]
00007a40685dc0cb  por xmm10, xmm5
00007a40685dc0d0  movaps [r15+0x2F0], xmm10
00007a40685dc0d8  vmovaps xmm5, [rsp+0x50]
00007a40685dc0de  vpermilpd xmm5, xmm5, 0x00
00007a40685dc0e4  vmovaps xmm3, [rsp+0x70]
00007a40685dc0ea  vmovaps [rsp+0x50], xmm1
00007a40685dc0f0  movaps xmm4, xmm3
00007a40685dc0f3  mulpd xmm4, xmm5
00007a40685dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007a40685dc0fc  ptest xmm1, xmm1
00007a40685dc101  jnz 0x00007A40685DE2CB
00007a40685dc107  lea r12, [rax+0xD0]
00007a40685dc10e  movups xmm1, [r13+r12*1]
00007a40685dc114  vmovaps xmm3, [rsp+0xD0]
00007a40685dc11d  vmovaps [rsp+0x70], xmm1
00007a40685dc123  movaps xmm5, xmm6
00007a40685dc126  addpd xmm5, xmm3
00007a40685dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007a40685dc12f  ptest xmm1, xmm1
00007a40685dc134  jnz 0x00007A40685DE415
00007a40685dc13a  vmovaps xmm1, [rsp+0x60]
00007a40685dc140  vpermilpd xmm1, xmm1, 0x00
00007a40685dc146  movaps xmm6, xmm9
00007a40685dc14a  mulpd xmm6, xmm1
00007a40685dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007a40685dc153  ptest xmm3, xmm3
00007a40685dc158  jnz 0x00007A40685DE555
00007a40685dc15e  movaps [r15+0x260], xmm6
00007a40685dc166  vxorps xmm1, xmm1, xmm1
00007a40685dc16a  vpbroadcastq xmm1, xmm1
00007a40685dc16f  movaps [r15+0x1B0], xmm1
00007a40685dc177  vmovaps xmm1, [rsp+0x60]
00007a40685dc17d  vpermilpd xmm1, xmm1, 0x00
00007a40685dc183  vmovaps xmm3, [rsp+0x70]
00007a40685dc189  vmovaps [rsp+0x70], xmm15
00007a40685dc18f  movaps xmm9, xmm3
00007a40685dc193  mulpd xmm9, xmm1
00007a40685dc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007a40685dc19e  ptest xmm15, xmm15
00007a40685dc1a4  jnz 0x00007A40685DE696
00007a40685dc1aa  lea r12, [rax+0xC0]
00007a40685dc1b1  movups xmm1, [r13+r12*1]
00007a40685dc1b7  vmovaps xmm3, [rsp+0xC0]
00007a40685dc1c0  vmovaps [rsp+0x80], xmm1
00007a40685dc1c9  movaps xmm15, xmm3
00007a40685dc1cd  addpd xmm15, xmm7
00007a40685dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007a40685dc1d8  ptest xmm1, xmm1
00007a40685dc1dd  jnz 0x00007A40685DE7E2
00007a40685dc1e3  vmovaps [rsp+0xC0], xmm13
00007a40685dc1ec  vmovaps xmm1, [rsp+0xC0]
00007a40685dc1f5  por xmm13, xmm1
00007a40685dc1fa  movaps [r15+0x270], xmm13
00007a40685dc202  vmovaps xmm1, [rsp+0xB0]
00007a40685dc20b  vmovaps xmm7, [rsp+0xB0]
00007a40685dc214  por xmm1, xmm7
00007a40685dc218  movaps [r15+0x1A0], xmm1
00007a40685dc220  vmovaps xmm1, [rsp+0x60]
00007a40685dc226  vpermilpd xmm1, xmm1, 0x00
00007a40685dc22c  vmovaps [rsp+0xB0], xmm1
00007a40685dc235  vmovaps xmm1, [rsp+0x80]
00007a40685dc23e  vmovaps [rsp+0x80], xmm15
00007a40685dc247  vmovaps xmm15, [rsp+0xB0]
00007a40685dc250  vmovaps [rsp+0xB0], xmm14
00007a40685dc259  movaps xmm3, xmm1
00007a40685dc25c  mulpd xmm3, xmm15
00007a40685dc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007a40685dc266  ptest xmm14, xmm14
00007a40685dc26c  jnz 0x00007A40685DE924
00007a40685dc272  lea r12, [rax+0x20]
00007a40685dc276  movups xmm1, [r13+r12*1]
00007a40685dc27c  movaps [r15+0x110], xmm1
00007a40685dc284  vmovaps xmm14, [rsp+0x70]
00007a40685dc28a  vmovaps [rsp+0x70], xmm1
00007a40685dc290  movaps xmm15, xmm14
00007a40685dc294  addpd xmm15, xmm4
00007a40685dc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007a40685dc29f  ptest xmm1, xmm1
00007a40685dc2a4  jnz 0x00007A40685DEA6F
00007a40685dc2aa  vmovaps xmm1, [rsp+0x60]
00007a40685dc2b0  vpermilpd xmm1, xmm1, 0x00
00007a40685dc2b6  movaps xmm14, xmm2
00007a40685dc2ba  mulpd xmm14, xmm1
00007a40685dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007a40685dc2c5  ptest xmm4, xmm4
00007a40685dc2ca  jnz 0x00007A40685DEBB2
00007a40685dc2d0  vmovaps xmm4, [rsp+0x50]
00007a40685dc2d6  movaps xmm1, xmm4
00007a40685dc2d9  addpd xmm1, xmm9
00007a40685dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007a40685dc2e3  ptest xmm2, xmm2
00007a40685dc2e8  jnz 0x00007A40685DECF4
00007a40685dc2ee  vmovaps xmm9, [rsp+0x30]
00007a40685dc2f4  vpermilpd xmm9, xmm9, 0x00
00007a40685dc2fa  vmovaps xmm2, [rsp+0x70]
00007a40685dc300  vmovaps [rsp+0x50], xmm1
00007a40685dc306  movaps xmm4, xmm2
00007a40685dc309  mulpd xmm4, xmm9
00007a40685dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007a40685dc313  ptest xmm1, xmm1
00007a40685dc318  jnz 0x00007A40685DEE35
00007a40685dc31e  vmovaps xmm1, [rsp+0x30]
00007a40685dc324  vpermilpd xmm1, xmm1, 0x00
00007a40685dc32a  vmovaps xmm2, [rsp+0x90]
00007a40685dc333  vmovaps [rsp+0x60], xmm15
00007a40685dc339  movaps xmm9, xmm2
00007a40685dc33d  mulpd xmm9, xmm1
00007a40685dc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007a40685dc348  ptest xmm15, xmm15
00007a40685dc34e  jnz 0x00007A40685DEF76
00007a40685dc354  vmovaps xmm15, [rsp+0x80]
00007a40685dc35d  movaps xmm1, xmm15
00007a40685dc361  addpd xmm1, xmm6
00007a40685dc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007a40685dc36a  ptest xmm2, xmm2
00007a40685dc36f  jnz 0x00007A40685DF0B8
00007a40685dc375  movaps xmm15, xmm5
00007a40685dc379  addpd xmm15, xmm3
00007a40685dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007a40685dc384  ptest xmm6, xmm6
00007a40685dc389  jnz 0x00007A40685DF1F9
00007a40685dc38f  vmovaps xmm6, [rsp+0x30]
00007a40685dc395  vpermilpd xmm6, xmm6, 0x00
00007a40685dc39b  movaps xmm5, xmm8
00007a40685dc39f  mulpd xmm5, xmm6
00007a40685dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007a40685dc3a8  ptest xmm3, xmm3
00007a40685dc3ad  jnz 0x00007A40685DF33B
00007a40685dc3b3  vmovaps xmm8, [rsp+0x30]
00007a40685dc3b9  vpermilpd xmm8, xmm8, 0x00
00007a40685dc3bf  movaps xmm6, xmm10
00007a40685dc3c3  mulpd xmm6, xmm8
00007a40685dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007a40685dc3cd  ptest xmm3, xmm3
00007a40685dc3d2  jnz 0x00007A40685DF47C
00007a40685dc3d8  vmovaps xmm8, [rsp+0x60]
00007a40685dc3de  movaps xmm10, xmm8
00007a40685dc3e2  addpd xmm10, xmm14
00007a40685dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007a40685dc3ed  ptest xmm3, xmm3
00007a40685dc3f2  jnz 0x00007A40685DF5BE
00007a40685dc3f8  vmovaps xmm8, [rsp+0x50]
00007a40685dc3fe  movaps xmm14, xmm8
00007a40685dc402  addpd xmm14, xmm4
00007a40685dc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007a40685dc40d  ptest xmm3, xmm3
00007a40685dc412  jnz 0x00007A40685DF702
00007a40685dc418  vmovaps xmm8, [rsp+0x40]
00007a40685dc41e  vpermilpd xmm8, xmm8, 0x00
00007a40685dc424  movaps xmm4, xmm13
00007a40685dc428  mulpd xmm4, xmm8
00007a40685dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007a40685dc432  ptest xmm3, xmm3
00007a40685dc437  jnz 0x00007A40685DF845
00007a40685dc43d  movaps xmm13, xmm15
00007a40685dc441  addpd xmm13, xmm9
00007a40685dc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007a40685dc44c  ptest xmm8, xmm8
00007a40685dc452  jnz 0x00007A40685DF987
00007a40685dc458  movaps xmm15, xmm1
00007a40685dc45c  addpd xmm15, xmm5
00007a40685dc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007a40685dc467  ptest xmm9, xmm9
00007a40685dc46d  jnz 0x00007A40685DFACB
00007a40685dc473  vmovaps [rsp+0x30], xmm11
00007a40685dc479  vmovaps xmm1, [rsp+0x30]
00007a40685dc47f  por xmm11, xmm1
00007a40685dc484  movaps [r15+0x250], xmm11
00007a40685dc48c  vmovaps [rsp+0x30], xmm12
00007a40685dc492  vmovaps xmm1, [rsp+0x30]
00007a40685dc498  por xmm12, xmm1
00007a40685dc49d  movaps [r15+0x2A0], xmm12
00007a40685dc4a5  vmovaps xmm1, [rsp+0xA0]
00007a40685dc4ae  vmovaps xmm11, [rsp+0xA0]
00007a40685dc4b7  por xmm1, xmm11
00007a40685dc4bc  movaps [r15+0x1D0], xmm1
00007a40685dc4c4  lea r12, [rax+0x40]
00007a40685dc4c8  movups xmm1, [r13+r12*1]
00007a40685dc4ce  movaps [r15+0x2C0], xmm1
00007a40685dc4d6  vmovaps xmm11, [rsp+0x40]
00007a40685dc4dc  vpermilpd xmm11, xmm11, 0x00
00007a40685dc4e2  vmovaps xmm8, [rsp+0xE0]
00007a40685dc4eb  movaps xmm9, xmm8
00007a40685dc4ef  mulpd xmm9, xmm11
00007a40685dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007a40685dc4fa  ptest xmm5, xmm5
00007a40685dc4ff  jnz 0x00007A40685DFC17
00007a40685dc505  movaps xmm11, xmm10
00007a40685dc509  addpd xmm11, xmm6
00007a40685dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007a40685dc514  ptest xmm8, xmm8
00007a40685dc51a  jnz 0x00007A40685DFD5B
00007a40685dc520  movaps xmm10, xmm14
00007a40685dc524  addpd xmm10, xmm4
00007a40685dc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007a40685dc52f  ptest xmm8, xmm8
00007a40685dc535  jnz 0x00007A40685DFE9E
00007a40685dc53b  vmovaps xmm14, [rsp+0x40]
00007a40685dc541  vpermilpd xmm14, xmm14, 0x00
00007a40685dc547  movaps xmm8, xmm1
00007a40685dc54b  mulpd xmm8, xmm14
00007a40685dc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007a40685dc556  ptest xmm6, xmm6
00007a40685dc55b  jnz 0x00007A40685DFFE1
00007a40685dc561  movaps xmm1, [r15+0x2B0]
00007a40685dc569  vmovaps xmm14, [rsp+0x40]
00007a40685dc56f  vpermilpd xmm14, xmm14, 0x00
00007a40685dc575  movaps xmm6, xmm1
00007a40685dc578  mulpd xmm6, xmm14
00007a40685dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007a40685dc582  ptest xmm5, xmm5
00007a40685dc587  jnz 0x00007A40685E0124
00007a40685dc58d  vmovaps xmm1, [rsp+0x10]
00007a40685dc593  vpermilpd xmm1, xmm1, 0x00
00007a40685dc599  movaps xmm14, xmm12
00007a40685dc59d  mulpd xmm14, xmm1
00007a40685dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007a40685dc5a8  ptest xmm5, xmm5
00007a40685dc5ad  jnz 0x00007A40685E0265
00007a40685dc5b3  movaps xmm1, xmm13
00007a40685dc5b7  addpd xmm1, xmm9
00007a40685dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007a40685dc5c1  ptest xmm12, xmm12
00007a40685dc5c7  jnz 0x00007A40685E03A8
00007a40685dc5cd  vmovaps xmm13, [rsp+0x10]
00007a40685dc5d3  vpermilpd xmm13, xmm13, 0x00
00007a40685dc5d9  movaps xmm12, xmm7
00007a40685dc5dd  mulpd xmm12, xmm13
00007a40685dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007a40685dc5e8  ptest xmm9, xmm9
00007a40685dc5ee  jnz 0x00007A40685E04EA
00007a40685dc5f4  movaps xmm13, xmm15
00007a40685dc5f8  addpd xmm13, xmm8
00007a40685dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007a40685dc603  ptest xmm9, xmm9
00007a40685dc609  jnz 0x00007A40685E062D
00007a40685dc60f  movaps xmm15, [r15+0x290]
00007a40685dc617  vmovaps xmm9, [rsp+0x10]
00007a40685dc61d  vpermilpd xmm9, xmm9, 0x00
00007a40685dc623  movaps xmm8, xmm15
00007a40685dc627  mulpd xmm8, xmm9
00007a40685dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007a40685dc632  ptest xmm7, xmm7
00007a40685dc637  jnz 0x00007A40685E0771
00007a40685dc63d  movaps xmm15, xmm11
00007a40685dc641  addpd xmm15, xmm6
00007a40685dc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007a40685dc64c  ptest xmm9, xmm9
00007a40685dc652  jnz 0x00007A40685E08B5
00007a40685dc658  movaps xmm11, [r15+0x1E0]
00007a40685dc660  vmovaps xmm9, [rsp+0x10]
00007a40685dc666  vpermilpd xmm9, xmm9, 0x00
00007a40685dc66c  movaps xmm7, xmm11
00007a40685dc670  mulpd xmm7, xmm9
00007a40685dc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007a40685dc67a  ptest xmm6, xmm6
00007a40685dc67f  jnz 0x00007A40685E09F8
00007a40685dc685  movaps xmm11, xmm10
00007a40685dc689  addpd xmm11, xmm14
00007a40685dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007a40685dc694  ptest xmm9, xmm9
00007a40685dc69a  jnz 0x00007A40685E0B3A
00007a40685dc6a0  lea r12, [rax+0x70]
00007a40685dc6a4  movups xmm14, [r13+r12*1]
00007a40685dc6aa  movaps [r15+0x240], xmm14
00007a40685dc6b2  movaps xmm10, xmm1
00007a40685dc6b6  addpd xmm10, xmm12
00007a40685dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007a40685dc6c1  ptest xmm9, xmm9
00007a40685dc6c7  jnz 0x00007A40685E0C88
00007a40685dc6cd  movaps [r15+0x170], xmm10
00007a40685dc6d5  vmovaps xmm1, [rsp+0x20]
00007a40685dc6db  vpermilpd xmm1, xmm1, 0x00
00007a40685dc6e1  movaps xmm12, xmm14
00007a40685dc6e5  mulpd xmm12, xmm1
00007a40685dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007a40685dc6f0  ptest xmm9, xmm9
00007a40685dc6f6  jnz 0x00007A40685E0DCB
00007a40685dc6fc  vmovaps xmm1, [rsp+0x20]
00007a40685dc702  vpermilpd xmm1, xmm1, 0x00
00007a40685dc708  vmovaps xmm9, [rsp+0xB0]
00007a40685dc711  movaps xmm14, xmm9
00007a40685dc715  mulpd xmm14, xmm1
00007a40685dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007a40685dc720  ptest xmm6, xmm6
00007a40685dc725  jnz 0x00007A40685E0F0E
00007a40685dc72b  movaps [r15+0x180], xmm14
00007a40685dc733  movaps xmm1, xmm13
00007a40685dc737  addpd xmm1, xmm8
00007a40685dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007a40685dc741  ptest xmm9, xmm9
00007a40685dc747  jnz 0x00007A40685E1051
00007a40685dc74d  movaps [r15+0x210], xmm1
00007a40685dc755  movups xmm13, [r13+rax*1]
00007a40685dc75b  lea r12, [rax+0x10]
00007a40685dc75f  movups xmm9, [r13+r12*1]
00007a40685dc765  movaps [r15+0x230], xmm9
00007a40685dc76d  movaps xmm8, xmm15
00007a40685dc771  addpd xmm8, xmm7
00007a40685dc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007a40685dc77c  ptest xmm6, xmm6
00007a40685dc781  jnz 0x00007A40685E11A7
00007a40685dc787  movaps [r15+0x130], xmm8
00007a40685dc78f  vmovaps xmm15, [rsp+0x20]
00007a40685dc795  vpermilpd xmm15, xmm15, 0x00
00007a40685dc79b  movaps xmm7, xmm9
00007a40685dc79f  mulpd xmm7, xmm15
00007a40685dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007a40685dc7a9  ptest xmm6, xmm6
00007a40685dc7ae  jnz 0x00007A40685E12EA
00007a40685dc7b4  movaps [r15+0x220], xmm7
00007a40685dc7bc  vmovaps xmm15, [rsp+0x20]
00007a40685dc7c2  vpermilpd xmm15, xmm15, 0x00
00007a40685dc7c8  movaps xmm9, xmm13
00007a40685dc7cc  mulpd xmm9, xmm15
00007a40685dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007a40685dc7d7  ptest xmm6, xmm6
00007a40685dc7dc  jnz 0x00007A40685E142C
00007a40685dc7e2  movaps xmm15, xmm11
00007a40685dc7e6  addpd xmm15, xmm12
00007a40685dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007a40685dc7f1  ptest xmm13, xmm13
00007a40685dc7f7  jnz 0x00007A40685E1570
00007a40685dc7fd  movaps [r15+0x140], xmm15
00007a40685dc805  movaps xmm13, xmm10
00007a40685dc809  addpd xmm13, xmm14
00007a40685dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007a40685dc814  ptest xmm12, xmm12
00007a40685dc81a  jnz 0x00007A40685E16B4
00007a40685dc820  movaps [r15+0x150], xmm13
00007a40685dc828  movaps xmm14, xmm1
00007a40685dc82c  addpd xmm14, xmm7
00007a40685dc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007a40685dc837  ptest xmm12, xmm12
00007a40685dc83d  jnz 0x00007A40685E17F8
00007a40685dc843  movaps [r15+0x160], xmm14
00007a40685dc84b  movaps xmm1, xmm8
00007a40685dc84f  addpd xmm1, xmm9
00007a40685dc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007a40685dc859  ptest xmm12, xmm12
00007a40685dc85f  jnz 0x00007A40685E193A
00007a40685dc865  movaps [r15+0x120], xmm1
00007a40685dc86d  movups [r13+r14*1], xmm15
00007a40685dc873  lea rax, [r14+0x10]
00007a40685dc877  movups [r13+rax*1], xmm13
00007a40685dc87d  lea rax, [r14+0x20]
00007a40685dc881  movups [r13+rax*1], xmm14
00007a40685dc887  lea rax, [r14+0x30]
00007a40685dc88b  movups [r13+rax*1], xmm1
00007a40685dc891  mov eax, [r15+0x108]
00007a40685dc898  sahf
00007a40685dc899  jnz 0x00007A40685DC8CB
00007a40685dc89b  cmp dword ptr [r15+0x318], 0x00
00007a40685dc8a3  jz 0x00007A40685DB900
00007a40685dc8a9  nop [rax+rax*1], ax
00007a40685dc8b2  nop [rax+rax*1], eax
00007a40685dc8ba  mov eax, 0x410444
00007a40685dc8bf  mov [r15+0x100], rax
00007a40685dc8c6  jmp 0x00007A40683FE110
00007a40685dc8cb  cmp dword ptr [r15+0x318], 0x00
00007a40685dc8d3  jz 0x00007A40685D57E0
00007a40685dc8d9  nop [rax+rax*1], ax
00007a40685dc8e2  nop [rax+rax*1], eax
00007a40685dc8ea  mov eax, 0x410278
00007a40685dc8ef  mov [r15+0x100], rax
00007a40685dc8f6  jmp 0x00007A40683FE110
00007a40685dc8fb  int3
00007a40685dc8fc  call 0x00007A40684E27E0
00007a40685dc901  jmp 0x00007A40685DB9DF
00007a40685dc906  call 0x00007A40684E1570
00007a40685dc90b  jmp 0x00007A40685DB9E8
00007a40685dc910  call 0x00007A40684E27E0
00007a40685dc915  jmp 0x00007A40685DBA44
00007a40685dc91a  call 0x00007A40684E1570
00007a40685dc91f  jmp 0x00007A40685DBA4D
00007a40685dc924  call 0x00007A40684E27E0
00007a40685dc929  jmp 0x00007A40685DBA90
00007a40685dc92e  call 0x00007A40684E1570
00007a40685dc933  jmp 0x00007A40685DBA99
00007a40685dc938  call 0x00007A406840DC20
00007a40685dc93d  jmp 0x00007A40685DBAD8
00007a40685dc942  call 0x00007A40684D59C0
00007a40685dc947  jmp 0x00007A40685DBAEB
00007a40685dc94c  call 0x00007A40684E0E30
00007a40685dc951  jmp 0x00007A40685DBB09
00007a40685dc956  call 0x00007A40684DFBC0
00007a40685dc95b  jmp 0x00007A40685DBB13
00007a40685dc960  call 0x00007A40684DE950
00007a40685dc965  jmp 0x00007A40685DBB1D
00007a40685dc96a  sub rsp, 0x08
00007a40685dc96e  push rax
00007a40685dc96f  push rcx
00007a40685dc970  push rdx
00007a40685dc971  push rdi
00007a40685dc972  push rsi
00007a40685dc973  push r8
00007a40685dc975  push r9
00007a40685dc977  push r10
00007a40685dc979  push r11
00007a40685dc97b  sub rsp, 0xF0
00007a40685dc982  vmovaps [rsp], xmm0
00007a40685dc987  vmovaps [rsp+0x10], xmm1
00007a40685dc98d  vmovaps [rsp+0x20], xmm2
00007a40685dc993  vmovaps [rsp+0x30], xmm3
00007a40685dc999  vmovaps [rsp+0x40], xmm4
00007a40685dc99f  vmovaps [rsp+0x50], xmm5
00007a40685dc9a5  vmovaps [rsp+0x60], xmm6
00007a40685dc9ab  vmovaps [rsp+0x70], xmm7
00007a40685dc9b1  vmovaps [rsp+0x80], xmm9
00007a40685dc9ba  vmovaps [rsp+0x90], xmm10
00007a40685dc9c3  vmovaps [rsp+0xA0], xmm11
00007a40685dc9cc  vmovaps [rsp+0xB0], xmm12
00007a40685dc9d5  vmovaps [rsp+0xC0], xmm13
00007a40685dc9de  vmovaps [rsp+0xD0], xmm14
00007a40685dc9e7  vmovaps [rsp+0xE0], xmm15
00007a40685dc9f0  sub rsp, 0x30
00007a40685dc9f4  movaps [rsp], xmm8
00007a40685dc9f9  movaps [rsp+0x10], xmm12
00007a40685dc9ff  movaps [rsp+0x20], xmm15
00007a40685dca05  lea rdi, [rsp]
00007a40685dca09  mov esi, 0x00
00007a40685dca0e  mov rax, 0x56F679577530
00007a40685dca18  call rax
00007a40685dca1a  movaps xmm8, [rsp]
00007a40685dca1f  add rsp, 0x30
00007a40685dca23  vmovaps xmm0, [rsp]
00007a40685dca28  vmovaps xmm1, [rsp+0x10]
00007a40685dca2e  vmovaps xmm2, [rsp+0x20]
00007a40685dca34  vmovaps xmm3, [rsp+0x30]
00007a40685dca3a  vmovaps xmm4, [rsp+0x40]
00007a40685dca40  vmovaps xmm5, [rsp+0x50]
00007a40685dca46  vmovaps xmm6, [rsp+0x60]
00007a40685dca4c  vmovaps xmm7, [rsp+0x70]
00007a40685dca52  vmovaps xmm9, [rsp+0x80]
00007a40685dca5b  vmovaps xmm10, [rsp+0x90]
00007a40685dca64  vmovaps xmm11, [rsp+0xA0]
00007a40685dca6d  vmovaps xmm12, [rsp+0xB0]
00007a40685dca76  vmovaps xmm13, [rsp+0xC0]
00007a40685dca7f  vmovaps xmm14, [rsp+0xD0]
00007a40685dca88  vmovaps xmm15, [rsp+0xE0]
00007a40685dca91  add rsp, 0xF0
00007a40685dca98  pop r11
00007a40685dca9a  pop r10
00007a40685dca9c  pop r9
00007a40685dca9e  pop r8
00007a40685dcaa0  pop rsi
00007a40685dcaa1  pop rdi
00007a40685dcaa2  pop rdx
00007a40685dcaa3  pop rcx
00007a40685dcaa4  pop rax
00007a40685dcaa5  add rsp, 0x08
00007a40685dcaa9  jmp 0x00007A40685DBB47
00007a40685dcaae  sub rsp, 0x08
00007a40685dcab2  push rax
00007a40685dcab3  push rcx
00007a40685dcab4  push rdx
00007a40685dcab5  push rdi
00007a40685dcab6  push rsi
00007a40685dcab7  push r8
00007a40685dcab9  push r9
00007a40685dcabb  push r10
00007a40685dcabd  push r11
00007a40685dcabf  sub rsp, 0xF0
00007a40685dcac6  vmovaps [rsp], xmm0
00007a40685dcacb  vmovaps [rsp+0x10], xmm1
00007a40685dcad1  vmovaps [rsp+0x20], xmm2
00007a40685dcad7  vmovaps [rsp+0x30], xmm3
00007a40685dcadd  vmovaps [rsp+0x40], xmm4
00007a40685dcae3  vmovaps [rsp+0x50], xmm5
00007a40685dcae9  vmovaps [rsp+0x60], xmm6
00007a40685dcaef  vmovaps [rsp+0x70], xmm8
00007a40685dcaf5  vmovaps [rsp+0x80], xmm9
00007a40685dcafe  vmovaps [rsp+0x90], xmm10
00007a40685dcb07  vmovaps [rsp+0xA0], xmm11
00007a40685dcb10  vmovaps [rsp+0xB0], xmm12
00007a40685dcb19  vmovaps [rsp+0xC0], xmm13
00007a40685dcb22  vmovaps [rsp+0xD0], xmm14
00007a40685dcb2b  vmovaps [rsp+0xE0], xmm15
00007a40685dcb34  sub rsp, 0x30
00007a40685dcb38  movaps [rsp], xmm7
00007a40685dcb3c  movaps [rsp+0x10], xmm9
00007a40685dcb42  movaps [rsp+0x20], xmm15
00007a40685dcb48  lea rdi, [rsp]
00007a40685dcb4c  mov esi, 0x00
00007a40685dcb51  mov rax, 0x56F679577530
00007a40685dcb5b  call rax
00007a40685dcb5d  movaps xmm7, [rsp]
00007a40685dcb61  add rsp, 0x30
00007a40685dcb65  vmovaps xmm0, [rsp]
00007a40685dcb6a  vmovaps xmm1, [rsp+0x10]
00007a40685dcb70  vmovaps xmm2, [rsp+0x20]
00007a40685dcb76  vmovaps xmm3, [rsp+0x30]
00007a40685dcb7c  vmovaps xmm4, [rsp+0x40]
00007a40685dcb82  vmovaps xmm5, [rsp+0x50]
00007a40685dcb88  vmovaps xmm6, [rsp+0x60]
00007a40685dcb8e  vmovaps xmm8, [rsp+0x70]
00007a40685dcb94  vmovaps xmm9, [rsp+0x80]
00007a40685dcb9d  vmovaps xmm10, [rsp+0x90]
00007a40685dcba6  vmovaps xmm11, [rsp+0xA0]
00007a40685dcbaf  vmovaps xmm12, [rsp+0xB0]
00007a40685dcbb8  vmovaps xmm13, [rsp+0xC0]
00007a40685dcbc1  vmovaps xmm14, [rsp+0xD0]
00007a40685dcbca  vmovaps xmm15, [rsp+0xE0]
00007a40685dcbd3  add rsp, 0xF0
00007a40685dcbda  pop r11
00007a40685dcbdc  pop r10
00007a40685dcbde  pop r9
00007a40685dcbe0  pop r8
00007a40685dcbe2  pop rsi
00007a40685dcbe3  pop rdi
00007a40685dcbe4  pop rdx
00007a40685dcbe5  pop rcx
00007a40685dcbe6  pop rax
00007a40685dcbe7  add rsp, 0x08
00007a40685dcbeb  jmp 0x00007A40685DBB75
00007a40685dcbf0  sub rsp, 0x08
00007a40685dcbf4  push rax
00007a40685dcbf5  push rcx
00007a40685dcbf6  push rdx
00007a40685dcbf7  push rdi
00007a40685dcbf8  push rsi
00007a40685dcbf9  push r8
00007a40685dcbfb  push r9
00007a40685dcbfd  push r10
00007a40685dcbff  push r11
00007a40685dcc01  sub rsp, 0xF0
00007a40685dcc08  vmovaps [rsp], xmm0
00007a40685dcc0d  vmovaps [rsp+0x10], xmm1
00007a40685dcc13  vmovaps [rsp+0x20], xmm2
00007a40685dcc19  vmovaps [rsp+0x30], xmm3
00007a40685dcc1f  vmovaps [rsp+0x40], xmm4
00007a40685dcc25  vmovaps [rsp+0x50], xmm5
00007a40685dcc2b  vmovaps [rsp+0x60], xmm6
00007a40685dcc31  vmovaps [rsp+0x70], xmm7
00007a40685dcc37  vmovaps [rsp+0x80], xmm8
00007a40685dcc40  vmovaps [rsp+0x90], xmm10
00007a40685dcc49  vmovaps [rsp+0xA0], xmm11
00007a40685dcc52  vmovaps [rsp+0xB0], xmm12
00007a40685dcc5b  vmovaps [rsp+0xC0], xmm13
00007a40685dcc64  vmovaps [rsp+0xD0], xmm14
00007a40685dcc6d  vmovaps [rsp+0xE0], xmm15
00007a40685dcc76  sub rsp, 0x30
00007a40685dcc7a  movaps [rsp], xmm9
00007a40685dcc7f  movaps [rsp+0x10], xmm12
00007a40685dcc85  movaps [rsp+0x20], xmm10
00007a40685dcc8b  lea rdi, [rsp]
00007a40685dcc8f  mov esi, 0x00
00007a40685dcc94  mov rax, 0x56F679577530
00007a40685dcc9e  call rax
00007a40685dcca0  movaps xmm9, [rsp]
00007a40685dcca5  add rsp, 0x30
00007a40685dcca9  vmovaps xmm0, [rsp]
00007a40685dccae  vmovaps xmm1, [rsp+0x10]
00007a40685dccb4  vmovaps xmm2, [rsp+0x20]
00007a40685dccba  vmovaps xmm3, [rsp+0x30]
00007a40685dccc0  vmovaps xmm4, [rsp+0x40]
00007a40685dccc6  vmovaps xmm5, [rsp+0x50]
00007a40685dcccc  vmovaps xmm6, [rsp+0x60]
00007a40685dccd2  vmovaps xmm7, [rsp+0x70]
00007a40685dccd8  vmovaps xmm8, [rsp+0x80]
00007a40685dcce1  vmovaps xmm10, [rsp+0x90]
00007a40685dccea  vmovaps xmm11, [rsp+0xA0]
00007a40685dccf3  vmovaps xmm12, [rsp+0xB0]
00007a40685dccfc  vmovaps xmm13, [rsp+0xC0]
00007a40685dcd05  vmovaps xmm14, [rsp+0xD0]
00007a40685dcd0e  vmovaps xmm15, [rsp+0xE0]
00007a40685dcd17  add rsp, 0xF0
00007a40685dcd1e  pop r11
00007a40685dcd20  pop r10
00007a40685dcd22  pop r9
00007a40685dcd24  pop r8
00007a40685dcd26  pop rsi
00007a40685dcd27  pop rdi
00007a40685dcd28  pop rdx
00007a40685dcd29  pop rcx
00007a40685dcd2a  pop rax
00007a40685dcd2b  add rsp, 0x08
00007a40685dcd2f  jmp 0x00007A40685DBB99
00007a40685dcd34  sub rsp, 0x08
00007a40685dcd38  push rax
00007a40685dcd39  push rcx
00007a40685dcd3a  push rdx
00007a40685dcd3b  push rdi
00007a40685dcd3c  push rsi
00007a40685dcd3d  push r8
00007a40685dcd3f  push r9
00007a40685dcd41  push r10
00007a40685dcd43  push r11
00007a40685dcd45  sub rsp, 0xF0
00007a40685dcd4c  vmovaps [rsp], xmm0
00007a40685dcd51  vmovaps [rsp+0x10], xmm1
00007a40685dcd57  vmovaps [rsp+0x20], xmm2
00007a40685dcd5d  vmovaps [rsp+0x30], xmm3
00007a40685dcd63  vmovaps [rsp+0x40], xmm4
00007a40685dcd69  vmovaps [rsp+0x50], xmm5
00007a40685dcd6f  vmovaps [rsp+0x60], xmm6
00007a40685dcd75  vmovaps [rsp+0x70], xmm7
00007a40685dcd7b  vmovaps [rsp+0x80], xmm8
00007a40685dcd84  vmovaps [rsp+0x90], xmm9
00007a40685dcd8d  vmovaps [rsp+0xA0], xmm11
00007a40685dcd96  vmovaps [rsp+0xB0], xmm12
00007a40685dcd9f  vmovaps [rsp+0xC0], xmm13
00007a40685dcda8  vmovaps [rsp+0xD0], xmm14
00007a40685dcdb1  vmovaps [rsp+0xE0], xmm15
00007a40685dcdba  sub rsp, 0x30
00007a40685dcdbe  movaps [rsp], xmm10
00007a40685dcdc3  movaps [rsp+0x10], xmm12
00007a40685dcdc9  movaps [rsp+0x20], xmm11
00007a40685dcdcf  lea rdi, [rsp]
00007a40685dcdd3  mov esi, 0x00
00007a40685dcdd8  mov rax, 0x56F679577530
00007a40685dcde2  call rax
00007a40685dcde4  movaps xmm10, [rsp]
00007a40685dcde9  add rsp, 0x30
00007a40685dcded  vmovaps xmm0, [rsp]
00007a40685dcdf2  vmovaps xmm1, [rsp+0x10]
00007a40685dcdf8  vmovaps xmm2, [rsp+0x20]
00007a40685dcdfe  vmovaps xmm3, [rsp+0x30]
00007a40685dce04  vmovaps xmm4, [rsp+0x40]
00007a40685dce0a  vmovaps xmm5, [rsp+0x50]
00007a40685dce10  vmovaps xmm6, [rsp+0x60]
00007a40685dce16  vmovaps xmm7, [rsp+0x70]
00007a40685dce1c  vmovaps xmm8, [rsp+0x80]
00007a40685dce25  vmovaps xmm9, [rsp+0x90]
00007a40685dce2e  vmovaps xmm11, [rsp+0xA0]
00007a40685dce37  vmovaps xmm12, [rsp+0xB0]
00007a40685dce40  vmovaps xmm13, [rsp+0xC0]
00007a40685dce49  vmovaps xmm14, [rsp+0xD0]
00007a40685dce52  vmovaps xmm15, [rsp+0xE0]
00007a40685dce5b  add rsp, 0xF0
00007a40685dce62  pop r11
00007a40685dce64  pop r10
00007a40685dce66  pop r9
00007a40685dce68  pop r8
00007a40685dce6a  pop rsi
00007a40685dce6b  pop rdi
00007a40685dce6c  pop rdx
00007a40685dce6d  pop rcx
00007a40685dce6e  pop rax
00007a40685dce6f  add rsp, 0x08
00007a40685dce73  jmp 0x00007A40685DBBB3
00007a40685dce78  sub rsp, 0x08
00007a40685dce7c  push rax
00007a40685dce7d  push rcx
00007a40685dce7e  push rdx
00007a40685dce7f  push rdi
00007a40685dce80  push rsi
00007a40685dce81  push r8
00007a40685dce83  push r9
00007a40685dce85  push r10
00007a40685dce87  push r11
00007a40685dce89  sub rsp, 0xF0
00007a40685dce90  vmovaps [rsp], xmm0
00007a40685dce95  vmovaps [rsp+0x10], xmm1
00007a40685dce9b  vmovaps [rsp+0x20], xmm2
00007a40685dcea1  vmovaps [rsp+0x30], xmm3
00007a40685dcea7  vmovaps [rsp+0x40], xmm4
00007a40685dcead  vmovaps [rsp+0x50], xmm5
00007a40685dceb3  vmovaps [rsp+0x60], xmm7
00007a40685dceb9  vmovaps [rsp+0x70], xmm8
00007a40685dcebf  vmovaps [rsp+0x80], xmm9
00007a40685dcec8  vmovaps [rsp+0x90], xmm10
00007a40685dced1  vmovaps [rsp+0xA0], xmm11
00007a40685dceda  vmovaps [rsp+0xB0], xmm12
00007a40685dcee3  vmovaps [rsp+0xC0], xmm13
00007a40685dceec  vmovaps [rsp+0xD0], xmm14
00007a40685dcef5  vmovaps [rsp+0xE0], xmm15
00007a40685dcefe  sub rsp, 0x30
00007a40685dcf02  movaps [rsp], xmm6
00007a40685dcf06  movaps [rsp+0x10], xmm12
00007a40685dcf0c  movaps [rsp+0x20], xmm11
00007a40685dcf12  lea rdi, [rsp]
00007a40685dcf16  mov esi, 0x00
00007a40685dcf1b  mov rax, 0x56F679577530
00007a40685dcf25  call rax
00007a40685dcf27  movaps xmm6, [rsp]
00007a40685dcf2b  add rsp, 0x30
00007a40685dcf2f  vmovaps xmm0, [rsp]
00007a40685dcf34  vmovaps xmm1, [rsp+0x10]
00007a40685dcf3a  vmovaps xmm2, [rsp+0x20]
00007a40685dcf40  vmovaps xmm3, [rsp+0x30]
00007a40685dcf46  vmovaps xmm4, [rsp+0x40]
00007a40685dcf4c  vmovaps xmm5, [rsp+0x50]
00007a40685dcf52  vmovaps xmm7, [rsp+0x60]
00007a40685dcf58  vmovaps xmm8, [rsp+0x70]
00007a40685dcf5e  vmovaps xmm9, [rsp+0x80]
00007a40685dcf67  vmovaps xmm10, [rsp+0x90]
00007a40685dcf70  vmovaps xmm11, [rsp+0xA0]
00007a40685dcf79  vmovaps xmm12, [rsp+0xB0]
00007a40685dcf82  vmovaps xmm13, [rsp+0xC0]
00007a40685dcf8b  vmovaps xmm14, [rsp+0xD0]
00007a40685dcf94  vmovaps xmm15, [rsp+0xE0]
00007a40685dcf9d  add rsp, 0xF0
00007a40685dcfa4  pop r11
00007a40685dcfa6  pop r10
00007a40685dcfa8  pop r9
00007a40685dcfaa  pop r8
00007a40685dcfac  pop rsi
00007a40685dcfad  pop rdi
00007a40685dcfae  pop rdx
00007a40685dcfaf  pop rcx
00007a40685dcfb0  pop rax
00007a40685dcfb1  add rsp, 0x08
00007a40685dcfb5  jmp 0x00007A40685DBBD4
00007a40685dcfba  sub rsp, 0x08
00007a40685dcfbe  push rax
00007a40685dcfbf  push rcx
00007a40685dcfc0  push rdx
00007a40685dcfc1  push rdi
00007a40685dcfc2  push rsi
00007a40685dcfc3  push r8
00007a40685dcfc5  push r9
00007a40685dcfc7  push r10
00007a40685dcfc9  push r11
00007a40685dcfcb  sub rsp, 0xF0
00007a40685dcfd2  vmovaps [rsp], xmm0
00007a40685dcfd7  vmovaps [rsp+0x10], xmm1
00007a40685dcfdd  vmovaps [rsp+0x20], xmm2
00007a40685dcfe3  vmovaps [rsp+0x30], xmm4
00007a40685dcfe9  vmovaps [rsp+0x40], xmm5
00007a40685dcfef  vmovaps [rsp+0x50], xmm6
00007a40685dcff5  vmovaps [rsp+0x60], xmm7
00007a40685dcffb  vmovaps [rsp+0x70], xmm8
00007a40685dd001  vmovaps [rsp+0x80], xmm9
00007a40685dd00a  vmovaps [rsp+0x90], xmm10
00007a40685dd013  vmovaps [rsp+0xA0], xmm11
00007a40685dd01c  vmovaps [rsp+0xB0], xmm12
00007a40685dd025  vmovaps [rsp+0xC0], xmm13
00007a40685dd02e  vmovaps [rsp+0xD0], xmm14
00007a40685dd037  vmovaps [rsp+0xE0], xmm15
00007a40685dd040  sub rsp, 0x30
00007a40685dd044  movaps [rsp], xmm3
00007a40685dd048  movaps [rsp+0x10], xmm5
00007a40685dd04d  movaps [rsp+0x20], xmm4
00007a40685dd052  lea rdi, [rsp]
00007a40685dd056  mov esi, 0x00
00007a40685dd05b  mov rax, 0x56F679577530
00007a40685dd065  call rax
00007a40685dd067  movaps xmm3, [rsp]
00007a40685dd06b  add rsp, 0x30
00007a40685dd06f  vmovaps xmm0, [rsp]
00007a40685dd074  vmovaps xmm1, [rsp+0x10]
00007a40685dd07a  vmovaps xmm2, [rsp+0x20]
00007a40685dd080  vmovaps xmm4, [rsp+0x30]
00007a40685dd086  vmovaps xmm5, [rsp+0x40]
00007a40685dd08c  vmovaps xmm6, [rsp+0x50]
00007a40685dd092  vmovaps xmm7, [rsp+0x60]
00007a40685dd098  vmovaps xmm8, [rsp+0x70]
00007a40685dd09e  vmovaps xmm9, [rsp+0x80]
00007a40685dd0a7  vmovaps xmm10, [rsp+0x90]
00007a40685dd0b0  vmovaps xmm11, [rsp+0xA0]
00007a40685dd0b9  vmovaps xmm12, [rsp+0xB0]
00007a40685dd0c2  vmovaps xmm13, [rsp+0xC0]
00007a40685dd0cb  vmovaps xmm14, [rsp+0xD0]
00007a40685dd0d4  vmovaps xmm15, [rsp+0xE0]
00007a40685dd0dd  add rsp, 0xF0
00007a40685dd0e4  pop r11
00007a40685dd0e6  pop r10
00007a40685dd0e8  pop r9
00007a40685dd0ea  pop r8
00007a40685dd0ec  pop rsi
00007a40685dd0ed  pop rdi
00007a40685dd0ee  pop rdx
00007a40685dd0ef  pop rcx
00007a40685dd0f0  pop rax
00007a40685dd0f1  add rsp, 0x08
00007a40685dd0f5  jmp 0x00007A40685DBC35
00007a40685dd0fa  sub rsp, 0x08
00007a40685dd0fe  push rax
00007a40685dd0ff  push rcx
00007a40685dd100  push rdx
00007a40685dd101  push rdi
00007a40685dd102  push rsi
00007a40685dd103  push r8
00007a40685dd105  push r9
00007a40685dd107  push r10
00007a40685dd109  push r11
00007a40685dd10b  sub rsp, 0xF0
00007a40685dd112  vmovaps [rsp], xmm0
00007a40685dd117  vmovaps [rsp+0x10], xmm1
00007a40685dd11d  vmovaps [rsp+0x20], xmm2
00007a40685dd123  vmovaps [rsp+0x30], xmm3
00007a40685dd129  vmovaps [rsp+0x40], xmm4
00007a40685dd12f  vmovaps [rsp+0x50], xmm6
00007a40685dd135  vmovaps [rsp+0x60], xmm7
00007a40685dd13b  vmovaps [rsp+0x70], xmm8
00007a40685dd141  vmovaps [rsp+0x80], xmm9
00007a40685dd14a  vmovaps [rsp+0x90], xmm10
00007a40685dd153  vmovaps [rsp+0xA0], xmm11
00007a40685dd15c  vmovaps [rsp+0xB0], xmm12
00007a40685dd165  vmovaps [rsp+0xC0], xmm13
00007a40685dd16e  vmovaps [rsp+0xD0], xmm14
00007a40685dd177  vmovaps [rsp+0xE0], xmm15
00007a40685dd180  sub rsp, 0x30
00007a40685dd184  movaps [rsp], xmm5
00007a40685dd188  movaps [rsp+0x10], xmm8
00007a40685dd18e  movaps [rsp+0x20], xmm15
00007a40685dd194  lea rdi, [rsp]
00007a40685dd198  mov esi, 0x00
00007a40685dd19d  mov rax, 0x56F679577530
00007a40685dd1a7  call rax
00007a40685dd1a9  movaps xmm5, [rsp]
00007a40685dd1ad  add rsp, 0x30
00007a40685dd1b1  vmovaps xmm0, [rsp]
00007a40685dd1b6  vmovaps xmm1, [rsp+0x10]
00007a40685dd1bc  vmovaps xmm2, [rsp+0x20]
00007a40685dd1c2  vmovaps xmm3, [rsp+0x30]
00007a40685dd1c8  vmovaps xmm4, [rsp+0x40]
00007a40685dd1ce  vmovaps xmm6, [rsp+0x50]
00007a40685dd1d4  vmovaps xmm7, [rsp+0x60]
00007a40685dd1da  vmovaps xmm8, [rsp+0x70]
00007a40685dd1e0  vmovaps xmm9, [rsp+0x80]
00007a40685dd1e9  vmovaps xmm10, [rsp+0x90]
00007a40685dd1f2  vmovaps xmm11, [rsp+0xA0]
00007a40685dd1fb  vmovaps xmm12, [rsp+0xB0]
00007a40685dd204  vmovaps xmm13, [rsp+0xC0]
00007a40685dd20d  vmovaps xmm14, [rsp+0xD0]
00007a40685dd216  vmovaps xmm15, [rsp+0xE0]
00007a40685dd21f  add rsp, 0xF0
00007a40685dd226  pop r11
00007a40685dd228  pop r10
00007a40685dd22a  pop r9
00007a40685dd22c  pop r8
00007a40685dd22e  pop rsi
00007a40685dd22f  pop rdi
00007a40685dd230  pop rdx
00007a40685dd231  pop rcx
00007a40685dd232  pop rax
00007a40685dd233  add rsp, 0x08
00007a40685dd237  jmp 0x00007A40685DBC73
00007a40685dd23c  sub rsp, 0x08
00007a40685dd240  push rax
00007a40685dd241  push rcx
00007a40685dd242  push rdx
00007a40685dd243  push rdi
00007a40685dd244  push rsi
00007a40685dd245  push r8
00007a40685dd247  push r9
00007a40685dd249  push r10
00007a40685dd24b  push r11
00007a40685dd24d  sub rsp, 0xF0
00007a40685dd254  vmovaps [rsp], xmm0
00007a40685dd259  vmovaps [rsp+0x10], xmm1
00007a40685dd25f  vmovaps [rsp+0x20], xmm2
00007a40685dd265  vmovaps [rsp+0x30], xmm3
00007a40685dd26b  vmovaps [rsp+0x40], xmm5
00007a40685dd271  vmovaps [rsp+0x50], xmm6
00007a40685dd277  vmovaps [rsp+0x60], xmm7
00007a40685dd27d  vmovaps [rsp+0x70], xmm8
00007a40685dd283  vmovaps [rsp+0x80], xmm9
00007a40685dd28c  vmovaps [rsp+0x90], xmm10
00007a40685dd295  vmovaps [rsp+0xA0], xmm11
00007a40685dd29e  vmovaps [rsp+0xB0], xmm12
00007a40685dd2a7  vmovaps [rsp+0xC0], xmm13
00007a40685dd2b0  vmovaps [rsp+0xD0], xmm14
00007a40685dd2b9  vmovaps [rsp+0xE0], xmm15
00007a40685dd2c2  sub rsp, 0x30
00007a40685dd2c6  movaps [rsp], xmm4
00007a40685dd2ca  movaps [rsp+0x10], xmm9
00007a40685dd2d0  movaps [rsp+0x20], xmm8
00007a40685dd2d6  lea rdi, [rsp]
00007a40685dd2da  mov esi, 0x00
00007a40685dd2df  mov rax, 0x56F679577530
00007a40685dd2e9  call rax
00007a40685dd2eb  movaps xmm4, [rsp]
00007a40685dd2ef  add rsp, 0x30
00007a40685dd2f3  vmovaps xmm0, [rsp]
00007a40685dd2f8  vmovaps xmm1, [rsp+0x10]
00007a40685dd2fe  vmovaps xmm2, [rsp+0x20]
00007a40685dd304  vmovaps xmm3, [rsp+0x30]
00007a40685dd30a  vmovaps xmm5, [rsp+0x40]
00007a40685dd310  vmovaps xmm6, [rsp+0x50]
00007a40685dd316  vmovaps xmm7, [rsp+0x60]
00007a40685dd31c  vmovaps xmm8, [rsp+0x70]
00007a40685dd322  vmovaps xmm9, [rsp+0x80]
00007a40685dd32b  vmovaps xmm10, [rsp+0x90]
00007a40685dd334  vmovaps xmm11, [rsp+0xA0]
00007a40685dd33d  vmovaps xmm12, [rsp+0xB0]
00007a40685dd346  vmovaps xmm13, [rsp+0xC0]
00007a40685dd34f  vmovaps xmm14, [rsp+0xD0]
00007a40685dd358  vmovaps xmm15, [rsp+0xE0]
00007a40685dd361  add rsp, 0xF0
00007a40685dd368  pop r11
00007a40685dd36a  pop r10
00007a40685dd36c  pop r9
00007a40685dd36e  pop r8
00007a40685dd370  pop rsi
00007a40685dd371  pop rdi
00007a40685dd372  pop rdx
00007a40685dd373  pop rcx
00007a40685dd374  pop rax
00007a40685dd375  add rsp, 0x08
00007a40685dd379  jmp 0x00007A40685DBC94
00007a40685dd37e  sub rsp, 0x08
00007a40685dd382  push rax
00007a40685dd383  push rcx
00007a40685dd384  push rdx
00007a40685dd385  push rdi
00007a40685dd386  push rsi
00007a40685dd387  push r8
00007a40685dd389  push r9
00007a40685dd38b  push r10
00007a40685dd38d  push r11
00007a40685dd38f  sub rsp, 0xF0
00007a40685dd396  vmovaps [rsp], xmm0
00007a40685dd39b  vmovaps [rsp+0x10], xmm1
00007a40685dd3a1  vmovaps [rsp+0x20], xmm2
00007a40685dd3a7  vmovaps [rsp+0x30], xmm3
00007a40685dd3ad  vmovaps [rsp+0x40], xmm4
00007a40685dd3b3  vmovaps [rsp+0x50], xmm5
00007a40685dd3b9  vmovaps [rsp+0x60], xmm6
00007a40685dd3bf  vmovaps [rsp+0x70], xmm7
00007a40685dd3c5  vmovaps [rsp+0x80], xmm8
00007a40685dd3ce  vmovaps [rsp+0x90], xmm10
00007a40685dd3d7  vmovaps [rsp+0xA0], xmm11
00007a40685dd3e0  vmovaps [rsp+0xB0], xmm12
00007a40685dd3e9  vmovaps [rsp+0xC0], xmm13
00007a40685dd3f2  vmovaps [rsp+0xD0], xmm14
00007a40685dd3fb  vmovaps [rsp+0xE0], xmm15
00007a40685dd404  sub rsp, 0x30
00007a40685dd408  movaps [rsp], xmm9
00007a40685dd40d  movaps [rsp+0x10], xmm10
00007a40685dd413  movaps [rsp+0x20], xmm8
00007a40685dd419  lea rdi, [rsp]
00007a40685dd41d  mov esi, 0x00
00007a40685dd422  mov rax, 0x56F679577530
00007a40685dd42c  call rax
00007a40685dd42e  movaps xmm9, [rsp]
00007a40685dd433  add rsp, 0x30
00007a40685dd437  vmovaps xmm0, [rsp]
00007a40685dd43c  vmovaps xmm1, [rsp+0x10]
00007a40685dd442  vmovaps xmm2, [rsp+0x20]
00007a40685dd448  vmovaps xmm3, [rsp+0x30]
00007a40685dd44e  vmovaps xmm4, [rsp+0x40]
00007a40685dd454  vmovaps xmm5, [rsp+0x50]
00007a40685dd45a  vmovaps xmm6, [rsp+0x60]
00007a40685dd460  vmovaps xmm7, [rsp+0x70]
00007a40685dd466  vmovaps xmm8, [rsp+0x80]
00007a40685dd46f  vmovaps xmm10, [rsp+0x90]
00007a40685dd478  vmovaps xmm11, [rsp+0xA0]
00007a40685dd481  vmovaps xmm12, [rsp+0xB0]
00007a40685dd48a  vmovaps xmm13, [rsp+0xC0]
00007a40685dd493  vmovaps xmm14, [rsp+0xD0]
00007a40685dd49c  vmovaps xmm15, [rsp+0xE0]
00007a40685dd4a5  add rsp, 0xF0
00007a40685dd4ac  pop r11
00007a40685dd4ae  pop r10
00007a40685dd4b0  pop r9
00007a40685dd4b2  pop r8
00007a40685dd4b4  pop rsi
00007a40685dd4b5  pop rdi
00007a40685dd4b6  pop rdx
00007a40685dd4b7  pop rcx
00007a40685dd4b8  pop rax
00007a40685dd4b9  add rsp, 0x08
00007a40685dd4bd  jmp 0x00007A40685DBCAE
00007a40685dd4c2  call 0x00007A40684B52F0
00007a40685dd4c7  jmp 0x00007A40685DBDC8
00007a40685dd4cc  call 0x00007A40684B52F0
00007a40685dd4d1  jmp 0x00007A40685DBDDE
00007a40685dd4d6  sub rsp, 0x08
00007a40685dd4da  push rax
00007a40685dd4db  push rcx
00007a40685dd4dc  push rdx
00007a40685dd4dd  push rdi
00007a40685dd4de  push rsi
00007a40685dd4df  push r8
00007a40685dd4e1  push r9
00007a40685dd4e3  push r10
00007a40685dd4e5  push r11
00007a40685dd4e7  sub rsp, 0xF0
00007a40685dd4ee  vmovaps [rsp], xmm0
00007a40685dd4f3  vmovaps [rsp+0x10], xmm2
00007a40685dd4f9  vmovaps [rsp+0x20], xmm3
00007a40685dd4ff  vmovaps [rsp+0x30], xmm4
00007a40685dd505  vmovaps [rsp+0x40], xmm5
00007a40685dd50b  vmovaps [rsp+0x50], xmm6
00007a40685dd511  vmovaps [rsp+0x60], xmm7
00007a40685dd517  vmovaps [rsp+0x70], xmm8
00007a40685dd51d  vmovaps [rsp+0x80], xmm9
00007a40685dd526  vmovaps [rsp+0x90], xmm10
00007a40685dd52f  vmovaps [rsp+0xA0], xmm11
00007a40685dd538  vmovaps [rsp+0xB0], xmm12
00007a40685dd541  vmovaps [rsp+0xC0], xmm13
00007a40685dd54a  vmovaps [rsp+0xD0], xmm14
00007a40685dd553  vmovaps [rsp+0xE0], xmm15
00007a40685dd55c  sub rsp, 0x30
00007a40685dd560  movaps [rsp], xmm1
00007a40685dd564  movaps [rsp+0x10], xmm6
00007a40685dd569  movaps [rsp+0x20], xmm15
00007a40685dd56f  lea rdi, [rsp]
00007a40685dd573  mov esi, 0x00
00007a40685dd578  mov rax, 0x56F679577530
00007a40685dd582  call rax
00007a40685dd584  movaps xmm1, [rsp]
00007a40685dd588  add rsp, 0x30
00007a40685dd58c  vmovaps xmm0, [rsp]
00007a40685dd591  vmovaps xmm2, [rsp+0x10]
00007a40685dd597  vmovaps xmm3, [rsp+0x20]
00007a40685dd59d  vmovaps xmm4, [rsp+0x30]
00007a40685dd5a3  vmovaps xmm5, [rsp+0x40]
00007a40685dd5a9  vmovaps xmm6, [rsp+0x50]
00007a40685dd5af  vmovaps xmm7, [rsp+0x60]
00007a40685dd5b5  vmovaps xmm8, [rsp+0x70]
00007a40685dd5bb  vmovaps xmm9, [rsp+0x80]
00007a40685dd5c4  vmovaps xmm10, [rsp+0x90]
00007a40685dd5cd  vmovaps xmm11, [rsp+0xA0]
00007a40685dd5d6  vmovaps xmm12, [rsp+0xB0]
00007a40685dd5df  vmovaps xmm13, [rsp+0xC0]
00007a40685dd5e8  vmovaps xmm14, [rsp+0xD0]
00007a40685dd5f1  vmovaps xmm15, [rsp+0xE0]
00007a40685dd5fa  add rsp, 0xF0
00007a40685dd601  pop r11
00007a40685dd603  pop r10
00007a40685dd605  pop r9
00007a40685dd607  pop r8
00007a40685dd609  pop rsi
00007a40685dd60a  pop rdi
00007a40685dd60b  pop rdx
00007a40685dd60c  pop rcx
00007a40685dd60d  pop rax
00007a40685dd60e  add rsp, 0x08
00007a40685dd612  jmp 0x00007A40685DBE1B
00007a40685dd617  call 0x00007A40684C4620
00007a40685dd61c  jmp 0x00007A40685DBE28
00007a40685dd621  sub rsp, 0x08
00007a40685dd625  push rax
00007a40685dd626  push rcx
00007a40685dd627  push rdx
00007a40685dd628  push rdi
00007a40685dd629  push rsi
00007a40685dd62a  push r8
00007a40685dd62c  push r9
00007a40685dd62e  push r10
00007a40685dd630  push r11
00007a40685dd632  sub rsp, 0xF0
00007a40685dd639  vmovaps [rsp], xmm0
00007a40685dd63e  vmovaps [rsp+0x10], xmm1
00007a40685dd644  vmovaps [rsp+0x20], xmm2
00007a40685dd64a  vmovaps [rsp+0x30], xmm3
00007a40685dd650  vmovaps [rsp+0x40], xmm4
00007a40685dd656  vmovaps [rsp+0x50], xmm5
00007a40685dd65c  vmovaps [rsp+0x60], xmm6
00007a40685dd662  vmovaps [rsp+0x70], xmm7
00007a40685dd668  vmovaps [rsp+0x80], xmm8
00007a40685dd671  vmovaps [rsp+0x90], xmm9
00007a40685dd67a  vmovaps [rsp+0xA0], xmm10
00007a40685dd683  vmovaps [rsp+0xB0], xmm11
00007a40685dd68c  vmovaps [rsp+0xC0], xmm12
00007a40685dd695  vmovaps [rsp+0xD0], xmm13
00007a40685dd69e  vmovaps [rsp+0xE0], xmm15
00007a40685dd6a7  sub rsp, 0x30
00007a40685dd6ab  movaps [rsp], xmm14
00007a40685dd6b0  movaps [rsp+0x10], xmm4
00007a40685dd6b5  movaps [rsp+0x20], xmm3
00007a40685dd6ba  lea rdi, [rsp]
00007a40685dd6be  mov esi, 0x00
00007a40685dd6c3  mov rax, 0x56F679577530
00007a40685dd6cd  call rax
00007a40685dd6cf  movaps xmm14, [rsp]
00007a40685dd6d4  add rsp, 0x30
00007a40685dd6d8  vmovaps xmm0, [rsp]
00007a40685dd6dd  vmovaps xmm1, [rsp+0x10]
00007a40685dd6e3  vmovaps xmm2, [rsp+0x20]
00007a40685dd6e9  vmovaps xmm3, [rsp+0x30]
00007a40685dd6ef  vmovaps xmm4, [rsp+0x40]
00007a40685dd6f5  vmovaps xmm5, [rsp+0x50]
00007a40685dd6fb  vmovaps xmm6, [rsp+0x60]
00007a40685dd701  vmovaps xmm7, [rsp+0x70]
00007a40685dd707  vmovaps xmm8, [rsp+0x80]
00007a40685dd710  vmovaps xmm9, [rsp+0x90]
00007a40685dd719  vmovaps xmm10, [rsp+0xA0]
00007a40685dd722  vmovaps xmm11, [rsp+0xB0]
00007a40685dd72b  vmovaps xmm12, [rsp+0xC0]
00007a40685dd734  vmovaps xmm13, [rsp+0xD0]
00007a40685dd73d  vmovaps xmm15, [rsp+0xE0]
00007a40685dd746  add rsp, 0xF0
00007a40685dd74d  pop r11
00007a40685dd74f  pop r10
00007a40685dd751  pop r9
00007a40685dd753  pop r8
00007a40685dd755  pop rsi
00007a40685dd756  pop rdi
00007a40685dd757  pop rdx
00007a40685dd758  pop rcx
00007a40685dd759  pop rax
00007a40685dd75a  add rsp, 0x08
00007a40685dd75e  jmp 0x00007A40685DBE42
00007a40685dd763  sub rsp, 0x08
00007a40685dd767  push rax
00007a40685dd768  push rcx
00007a40685dd769  push rdx
00007a40685dd76a  push rdi
00007a40685dd76b  push rsi
00007a40685dd76c  push r8
00007a40685dd76e  push r9
00007a40685dd770  push r10
00007a40685dd772  push r11
00007a40685dd774  sub rsp, 0xF0
00007a40685dd77b  vmovaps [rsp], xmm0
00007a40685dd780  vmovaps [rsp+0x10], xmm1
00007a40685dd786  vmovaps [rsp+0x20], xmm2
00007a40685dd78c  vmovaps [rsp+0x30], xmm3
00007a40685dd792  vmovaps [rsp+0x40], xmm4
00007a40685dd798  vmovaps [rsp+0x50], xmm5
00007a40685dd79e  vmovaps [rsp+0x60], xmm7
00007a40685dd7a4  vmovaps [rsp+0x70], xmm8
00007a40685dd7aa  vmovaps [rsp+0x80], xmm9
00007a40685dd7b3  vmovaps [rsp+0x90], xmm10
00007a40685dd7bc  vmovaps [rsp+0xA0], xmm11
00007a40685dd7c5  vmovaps [rsp+0xB0], xmm12
00007a40685dd7ce  vmovaps [rsp+0xC0], xmm13
00007a40685dd7d7  vmovaps [rsp+0xD0], xmm14
00007a40685dd7e0  vmovaps [rsp+0xE0], xmm15
00007a40685dd7e9  sub rsp, 0x30
00007a40685dd7ed  movaps [rsp], xmm6
00007a40685dd7f1  movaps [rsp+0x10], xmm9
00007a40685dd7f7  movaps [rsp+0x20], xmm7
00007a40685dd7fc  lea rdi, [rsp]
00007a40685dd800  mov esi, 0x00
00007a40685dd805  mov rax, 0x56F679577530
00007a40685dd80f  call rax
00007a40685dd811  movaps xmm6, [rsp]
00007a40685dd815  add rsp, 0x30
00007a40685dd819  vmovaps xmm0, [rsp]
00007a40685dd81e  vmovaps xmm1, [rsp+0x10]
00007a40685dd824  vmovaps xmm2, [rsp+0x20]
00007a40685dd82a  vmovaps xmm3, [rsp+0x30]
00007a40685dd830  vmovaps xmm4, [rsp+0x40]
00007a40685dd836  vmovaps xmm5, [rsp+0x50]
00007a40685dd83c  vmovaps xmm7, [rsp+0x60]
00007a40685dd842  vmovaps xmm8, [rsp+0x70]
00007a40685dd848  vmovaps xmm9, [rsp+0x80]
00007a40685dd851  vmovaps xmm10, [rsp+0x90]
00007a40685dd85a  vmovaps xmm11, [rsp+0xA0]
00007a40685dd863  vmovaps xmm12, [rsp+0xB0]
00007a40685dd86c  vmovaps xmm13, [rsp+0xC0]
00007a40685dd875  vmovaps xmm14, [rsp+0xD0]
00007a40685dd87e  vmovaps xmm15, [rsp+0xE0]
00007a40685dd887  add rsp, 0xF0
00007a40685dd88e  pop r11
00007a40685dd890  pop r10
00007a40685dd892  pop r9
00007a40685dd894  pop r8
00007a40685dd896  pop rsi
00007a40685dd897  pop rdi
00007a40685dd898  pop rdx
00007a40685dd899  pop rcx
00007a40685dd89a  pop rax
00007a40685dd89b  add rsp, 0x08
00007a40685dd89f  jmp 0x00007A40685DBE5A
00007a40685dd8a4  sub rsp, 0x08
00007a40685dd8a8  push rax
00007a40685dd8a9  push rcx
00007a40685dd8aa  push rdx
00007a40685dd8ab  push rdi
00007a40685dd8ac  push rsi
00007a40685dd8ad  push r8
00007a40685dd8af  push r9
00007a40685dd8b1  push r10
00007a40685dd8b3  push r11
00007a40685dd8b5  sub rsp, 0xF0
00007a40685dd8bc  vmovaps [rsp], xmm0
00007a40685dd8c1  vmovaps [rsp+0x10], xmm1
00007a40685dd8c7  vmovaps [rsp+0x20], xmm2
00007a40685dd8cd  vmovaps [rsp+0x30], xmm3
00007a40685dd8d3  vmovaps [rsp+0x40], xmm4
00007a40685dd8d9  vmovaps [rsp+0x50], xmm5
00007a40685dd8df  vmovaps [rsp+0x60], xmm6
00007a40685dd8e5  vmovaps [rsp+0x70], xmm8
00007a40685dd8eb  vmovaps [rsp+0x80], xmm9
00007a40685dd8f4  vmovaps [rsp+0x90], xmm10
00007a40685dd8fd  vmovaps [rsp+0xA0], xmm11
00007a40685dd906  vmovaps [rsp+0xB0], xmm12
00007a40685dd90f  vmovaps [rsp+0xC0], xmm13
00007a40685dd918  vmovaps [rsp+0xD0], xmm14
00007a40685dd921  vmovaps [rsp+0xE0], xmm15
00007a40685dd92a  sub rsp, 0x30
00007a40685dd92e  movaps [rsp], xmm7
00007a40685dd932  movaps [rsp+0x10], xmm4
00007a40685dd937  movaps [rsp+0x20], xmm9
00007a40685dd93d  lea rdi, [rsp]
00007a40685dd941  mov esi, 0x00
00007a40685dd946  mov rax, 0x56F679577530
00007a40685dd950  call rax
00007a40685dd952  movaps xmm7, [rsp]
00007a40685dd956  add rsp, 0x30
00007a40685dd95a  vmovaps xmm0, [rsp]
00007a40685dd95f  vmovaps xmm1, [rsp+0x10]
00007a40685dd965  vmovaps xmm2, [rsp+0x20]
00007a40685dd96b  vmovaps xmm3, [rsp+0x30]
00007a40685dd971  vmovaps xmm4, [rsp+0x40]
00007a40685dd977  vmovaps xmm5, [rsp+0x50]
00007a40685dd97d  vmovaps xmm6, [rsp+0x60]
00007a40685dd983  vmovaps xmm8, [rsp+0x70]
00007a40685dd989  vmovaps xmm9, [rsp+0x80]
00007a40685dd992  vmovaps xmm10, [rsp+0x90]
00007a40685dd99b  vmovaps xmm11, [rsp+0xA0]
00007a40685dd9a4  vmovaps xmm12, [rsp+0xB0]
00007a40685dd9ad  vmovaps xmm13, [rsp+0xC0]
00007a40685dd9b6  vmovaps xmm14, [rsp+0xD0]
00007a40685dd9bf  vmovaps xmm15, [rsp+0xE0]
00007a40685dd9c8  add rsp, 0xF0
00007a40685dd9cf  pop r11
00007a40685dd9d1  pop r10
00007a40685dd9d3  pop r9
00007a40685dd9d5  pop r8
00007a40685dd9d7  pop rsi
00007a40685dd9d8  pop rdi
00007a40685dd9d9  pop rdx
00007a40685dd9da  pop rcx
00007a40685dd9db  pop rax
00007a40685dd9dc  add rsp, 0x08
00007a40685dd9e0  jmp 0x00007A40685DBE87
00007a40685dd9e5  sub rsp, 0x08
00007a40685dd9e9  push rax
00007a40685dd9ea  push rcx
00007a40685dd9eb  push rdx
00007a40685dd9ec  push rdi
00007a40685dd9ed  push rsi
00007a40685dd9ee  push r8
00007a40685dd9f0  push r9
00007a40685dd9f2  push r10
00007a40685dd9f4  push r11
00007a40685dd9f6  sub rsp, 0xF0
00007a40685dd9fd  vmovaps [rsp], xmm0
00007a40685dda02  vmovaps [rsp+0x10], xmm1
00007a40685dda08  vmovaps [rsp+0x20], xmm2
00007a40685dda0e  vmovaps [rsp+0x30], xmm3
00007a40685dda14  vmovaps [rsp+0x40], xmm5
00007a40685dda1a  vmovaps [rsp+0x50], xmm6
00007a40685dda20  vmovaps [rsp+0x60], xmm7
00007a40685dda26  vmovaps [rsp+0x70], xmm8
00007a40685dda2c  vmovaps [rsp+0x80], xmm9
00007a40685dda35  vmovaps [rsp+0x90], xmm10
00007a40685dda3e  vmovaps [rsp+0xA0], xmm11
00007a40685dda47  vmovaps [rsp+0xB0], xmm12
00007a40685dda50  vmovaps [rsp+0xC0], xmm13
00007a40685dda59  vmovaps [rsp+0xD0], xmm14
00007a40685dda62  vmovaps [rsp+0xE0], xmm15
00007a40685dda6b  sub rsp, 0x30
00007a40685dda6f  movaps [rsp], xmm4
00007a40685dda73  movaps [rsp+0x10], xmm15
00007a40685dda79  movaps [rsp+0x20], xmm9
00007a40685dda7f  lea rdi, [rsp]
00007a40685dda83  mov esi, 0x00
00007a40685dda88  mov rax, 0x56F679577530
00007a40685dda92  call rax
00007a40685dda94  movaps xmm4, [rsp]
00007a40685dda98  add rsp, 0x30
00007a40685dda9c  vmovaps xmm0, [rsp]
00007a40685ddaa1  vmovaps xmm1, [rsp+0x10]
00007a40685ddaa7  vmovaps xmm2, [rsp+0x20]
00007a40685ddaad  vmovaps xmm3, [rsp+0x30]
00007a40685ddab3  vmovaps xmm5, [rsp+0x40]
00007a40685ddab9  vmovaps xmm6, [rsp+0x50]
00007a40685ddabf  vmovaps xmm7, [rsp+0x60]
00007a40685ddac5  vmovaps xmm8, [rsp+0x70]
00007a40685ddacb  vmovaps xmm9, [rsp+0x80]
00007a40685ddad4  vmovaps xmm10, [rsp+0x90]
00007a40685ddadd  vmovaps xmm11, [rsp+0xA0]
00007a40685ddae6  vmovaps xmm12, [rsp+0xB0]
00007a40685ddaef  vmovaps xmm13, [rsp+0xC0]
00007a40685ddaf8  vmovaps xmm14, [rsp+0xD0]
00007a40685ddb01  vmovaps xmm15, [rsp+0xE0]
00007a40685ddb0a  add rsp, 0xF0
00007a40685ddb11  pop r11
00007a40685ddb13  pop r10
00007a40685ddb15  pop r9
00007a40685ddb17  pop r8
00007a40685ddb19  pop rsi
00007a40685ddb1a  pop rdi
00007a40685ddb1b  pop rdx
00007a40685ddb1c  pop rcx
00007a40685ddb1d  pop rax
00007a40685ddb1e  add rsp, 0x08
00007a40685ddb22  jmp 0x00007A40685DBEAC
00007a40685ddb27  call 0x00007A40684C4620
00007a40685ddb2c  jmp 0x00007A40685DBEB9
00007a40685ddb31  sub rsp, 0x08
00007a40685ddb35  push rax
00007a40685ddb36  push rcx
00007a40685ddb37  push rdx
00007a40685ddb38  push rdi
00007a40685ddb39  push rsi
00007a40685ddb3a  push r8
00007a40685ddb3c  push r9
00007a40685ddb3e  push r10
00007a40685ddb40  push r11
00007a40685ddb42  sub rsp, 0xF0
00007a40685ddb49  vmovaps [rsp], xmm0
00007a40685ddb4e  vmovaps [rsp+0x10], xmm1
00007a40685ddb54  vmovaps [rsp+0x20], xmm2
00007a40685ddb5a  vmovaps [rsp+0x30], xmm4
00007a40685ddb60  vmovaps [rsp+0x40], xmm5
00007a40685ddb66  vmovaps [rsp+0x50], xmm6
00007a40685ddb6c  vmovaps [rsp+0x60], xmm7
00007a40685ddb72  vmovaps [rsp+0x70], xmm8
00007a40685ddb78  vmovaps [rsp+0x80], xmm9
00007a40685ddb81  vmovaps [rsp+0x90], xmm10
00007a40685ddb8a  vmovaps [rsp+0xA0], xmm11
00007a40685ddb93  vmovaps [rsp+0xB0], xmm12
00007a40685ddb9c  vmovaps [rsp+0xC0], xmm13
00007a40685ddba5  vmovaps [rsp+0xD0], xmm14
00007a40685ddbae  vmovaps [rsp+0xE0], xmm15
00007a40685ddbb7  sub rsp, 0x30
00007a40685ddbbb  movaps [rsp], xmm3
00007a40685ddbbf  movaps [rsp+0x10], xmm1
00007a40685ddbc4  movaps [rsp+0x20], xmm9
00007a40685ddbca  lea rdi, [rsp]
00007a40685ddbce  mov esi, 0x00
00007a40685ddbd3  mov rax, 0x56F679577530
00007a40685ddbdd  call rax
00007a40685ddbdf  movaps xmm3, [rsp]
00007a40685ddbe3  add rsp, 0x30
00007a40685ddbe7  vmovaps xmm0, [rsp]
00007a40685ddbec  vmovaps xmm1, [rsp+0x10]
00007a40685ddbf2  vmovaps xmm2, [rsp+0x20]
00007a40685ddbf8  vmovaps xmm4, [rsp+0x30]
00007a40685ddbfe  vmovaps xmm5, [rsp+0x40]
00007a40685ddc04  vmovaps xmm6, [rsp+0x50]
00007a40685ddc0a  vmovaps xmm7, [rsp+0x60]
00007a40685ddc10  vmovaps xmm8, [rsp+0x70]
00007a40685ddc16  vmovaps xmm9, [rsp+0x80]
00007a40685ddc1f  vmovaps xmm10, [rsp+0x90]
00007a40685ddc28  vmovaps xmm11, [rsp+0xA0]
00007a40685ddc31  vmovaps xmm12, [rsp+0xB0]
00007a40685ddc3a  vmovaps xmm13, [rsp+0xC0]
00007a40685ddc43  vmovaps xmm14, [rsp+0xD0]
00007a40685ddc4c  vmovaps xmm15, [rsp+0xE0]
00007a40685ddc55  add rsp, 0xF0
00007a40685ddc5c  pop r11
00007a40685ddc5e  pop r10
00007a40685ddc60  pop r9
00007a40685ddc62  pop r8
00007a40685ddc64  pop rsi
00007a40685ddc65  pop rdi
00007a40685ddc66  pop rdx
00007a40685ddc67  pop rcx
00007a40685ddc68  pop rax
00007a40685ddc69  add rsp, 0x08
00007a40685ddc6d  jmp 0x00007A40685DBEF6
00007a40685ddc72  sub rsp, 0x08
00007a40685ddc76  push rax
00007a40685ddc77  push rcx
00007a40685ddc78  push rdx
00007a40685ddc79  push rdi
00007a40685ddc7a  push rsi
00007a40685ddc7b  push r8
00007a40685ddc7d  push r9
00007a40685ddc7f  push r10
00007a40685ddc81  push r11
00007a40685ddc83  sub rsp, 0xF0
00007a40685ddc8a  vmovaps [rsp], xmm0
00007a40685ddc8f  vmovaps [rsp+0x10], xmm2
00007a40685ddc95  vmovaps [rsp+0x20], xmm3
00007a40685ddc9b  vmovaps [rsp+0x30], xmm4
00007a40685ddca1  vmovaps [rsp+0x40], xmm5
00007a40685ddca7  vmovaps [rsp+0x50], xmm6
00007a40685ddcad  vmovaps [rsp+0x60], xmm7
00007a40685ddcb3  vmovaps [rsp+0x70], xmm8
00007a40685ddcb9  vmovaps [rsp+0x80], xmm9
00007a40685ddcc2  vmovaps [rsp+0x90], xmm10
00007a40685ddccb  vmovaps [rsp+0xA0], xmm11
00007a40685ddcd4  vmovaps [rsp+0xB0], xmm12
00007a40685ddcdd  vmovaps [rsp+0xC0], xmm13
00007a40685ddce6  vmovaps [rsp+0xD0], xmm14
00007a40685ddcef  vmovaps [rsp+0xE0], xmm15
00007a40685ddcf8  sub rsp, 0x30
00007a40685ddcfc  movaps [rsp], xmm1
00007a40685ddd00  movaps [rsp+0x10], xmm15
00007a40685ddd06  movaps [rsp+0x20], xmm9
00007a40685ddd0c  lea rdi, [rsp]
00007a40685ddd10  mov esi, 0x00
00007a40685ddd15  mov rax, 0x56F679577530
00007a40685ddd1f  call rax
00007a40685ddd21  movaps xmm1, [rsp]
00007a40685ddd25  add rsp, 0x30
00007a40685ddd29  vmovaps xmm0, [rsp]
00007a40685ddd2e  vmovaps xmm2, [rsp+0x10]
00007a40685ddd34  vmovaps xmm3, [rsp+0x20]
00007a40685ddd3a  vmovaps xmm4, [rsp+0x30]
00007a40685ddd40  vmovaps xmm5, [rsp+0x40]
00007a40685ddd46  vmovaps xmm6, [rsp+0x50]
00007a40685ddd4c  vmovaps xmm7, [rsp+0x60]
00007a40685ddd52  vmovaps xmm8, [rsp+0x70]
00007a40685ddd58  vmovaps xmm9, [rsp+0x80]
00007a40685ddd61  vmovaps xmm10, [rsp+0x90]
00007a40685ddd6a  vmovaps xmm11, [rsp+0xA0]
00007a40685ddd73  vmovaps xmm12, [rsp+0xB0]
00007a40685ddd7c  vmovaps xmm13, [rsp+0xC0]
00007a40685ddd85  vmovaps xmm14, [rsp+0xD0]
00007a40685ddd8e  vmovaps xmm15, [rsp+0xE0]
00007a40685ddd97  add rsp, 0xF0
00007a40685ddd9e  pop r11
00007a40685ddda0  pop r10
00007a40685ddda2  pop r9
00007a40685ddda4  pop r8
00007a40685ddda6  pop rsi
00007a40685ddda7  pop rdi
00007a40685ddda8  pop rdx
00007a40685ddda9  pop rcx
00007a40685dddaa  pop rax
00007a40685dddab  add rsp, 0x08
00007a40685dddaf  jmp 0x00007A40685DBF7E
00007a40685dddb4  call 0x00007A40684C4620
00007a40685dddb9  jmp 0x00007A40685DBF8B
00007a40685dddbe  sub rsp, 0x08
00007a40685dddc2  push rax
00007a40685dddc3  push rcx
00007a40685dddc4  push rdx
00007a40685dddc5  push rdi
00007a40685dddc6  push rsi
00007a40685dddc7  push r8
00007a40685dddc9  push r9
00007a40685dddcb  push r10
00007a40685dddcd  push r11
00007a40685dddcf  sub rsp, 0xF0
00007a40685dddd6  vmovaps [rsp], xmm0
00007a40685ddddb  vmovaps [rsp+0x10], xmm2
00007a40685ddde1  vmovaps [rsp+0x20], xmm3
00007a40685ddde7  vmovaps [rsp+0x30], xmm4
00007a40685ddded  vmovaps [rsp+0x40], xmm5
00007a40685dddf3  vmovaps [rsp+0x50], xmm6
00007a40685dddf9  vmovaps [rsp+0x60], xmm7
00007a40685dddff  vmovaps [rsp+0x70], xmm8
00007a40685dde05  vmovaps [rsp+0x80], xmm9
00007a40685dde0e  vmovaps [rsp+0x90], xmm10
00007a40685dde17  vmovaps [rsp+0xA0], xmm11
00007a40685dde20  vmovaps [rsp+0xB0], xmm12
00007a40685dde29  vmovaps [rsp+0xC0], xmm13
00007a40685dde32  vmovaps [rsp+0xD0], xmm14
00007a40685dde3b  vmovaps [rsp+0xE0], xmm15
00007a40685dde44  sub rsp, 0x30
00007a40685dde48  movaps [rsp], xmm1
00007a40685dde4c  movaps [rsp+0x10], xmm5
00007a40685dde51  movaps [rsp+0x20], xmm7
00007a40685dde56  lea rdi, [rsp]
00007a40685dde5a  mov esi, 0x00
00007a40685dde5f  mov rax, 0x56F679577530
00007a40685dde69  call rax
00007a40685dde6b  movaps xmm1, [rsp]
00007a40685dde6f  add rsp, 0x30
00007a40685dde73  vmovaps xmm0, [rsp]
00007a40685dde78  vmovaps xmm2, [rsp+0x10]
00007a40685dde7e  vmovaps xmm3, [rsp+0x20]
00007a40685dde84  vmovaps xmm4, [rsp+0x30]
00007a40685dde8a  vmovaps xmm5, [rsp+0x40]
00007a40685dde90  vmovaps xmm6, [rsp+0x50]
00007a40685dde96  vmovaps xmm7, [rsp+0x60]
00007a40685dde9c  vmovaps xmm8, [rsp+0x70]
00007a40685ddea2  vmovaps xmm9, [rsp+0x80]
00007a40685ddeab  vmovaps xmm10, [rsp+0x90]
00007a40685ddeb4  vmovaps xmm11, [rsp+0xA0]
00007a40685ddebd  vmovaps xmm12, [rsp+0xB0]
00007a40685ddec6  vmovaps xmm13, [rsp+0xC0]
00007a40685ddecf  vmovaps xmm14, [rsp+0xD0]
00007a40685dded8  vmovaps xmm15, [rsp+0xE0]
00007a40685ddee1  add rsp, 0xF0
00007a40685ddee8  pop r11
00007a40685ddeea  pop r10
00007a40685ddeec  pop r9
00007a40685ddeee  pop r8
00007a40685ddef0  pop rsi
00007a40685ddef1  pop rdi
00007a40685ddef2  pop rdx
00007a40685ddef3  pop rcx
00007a40685ddef4  pop rax
00007a40685ddef5  add rsp, 0x08
00007a40685ddef9  jmp 0x00007A40685DC030
00007a40685ddefe  sub rsp, 0x08
00007a40685ddf02  push rax
00007a40685ddf03  push rcx
00007a40685ddf04  push rdx
00007a40685ddf05  push rdi
00007a40685ddf06  push rsi
00007a40685ddf07  push r8
00007a40685ddf09  push r9
00007a40685ddf0b  push r10
00007a40685ddf0d  push r11
00007a40685ddf0f  sub rsp, 0xF0
00007a40685ddf16  vmovaps [rsp], xmm0
00007a40685ddf1b  vmovaps [rsp+0x10], xmm1
00007a40685ddf21  vmovaps [rsp+0x20], xmm2
00007a40685ddf27  vmovaps [rsp+0x30], xmm3
00007a40685ddf2d  vmovaps [rsp+0x40], xmm4
00007a40685ddf33  vmovaps [rsp+0x50], xmm5
00007a40685ddf39  vmovaps [rsp+0x60], xmm6
00007a40685ddf3f  vmovaps [rsp+0x70], xmm8
00007a40685ddf45  vmovaps [rsp+0x80], xmm9
00007a40685ddf4e  vmovaps [rsp+0x90], xmm10
00007a40685ddf57  vmovaps [rsp+0xA0], xmm11
00007a40685ddf60  vmovaps [rsp+0xB0], xmm12
00007a40685ddf69  vmovaps [rsp+0xC0], xmm13
00007a40685ddf72  vmovaps [rsp+0xD0], xmm14
00007a40685ddf7b  vmovaps [rsp+0xE0], xmm15
00007a40685ddf84  sub rsp, 0x30
00007a40685ddf88  movaps [rsp], xmm7
00007a40685ddf8c  movaps [rsp+0x10], xmm5
00007a40685ddf91  movaps [rsp+0x20], xmm15
00007a40685ddf97  lea rdi, [rsp]
00007a40685ddf9b  mov esi, 0x00
00007a40685ddfa0  mov rax, 0x56F679577530
00007a40685ddfaa  call rax
00007a40685ddfac  movaps xmm7, [rsp]
00007a40685ddfb0  add rsp, 0x30
00007a40685ddfb4  vmovaps xmm0, [rsp]
00007a40685ddfb9  vmovaps xmm1, [rsp+0x10]
00007a40685ddfbf  vmovaps xmm2, [rsp+0x20]
00007a40685ddfc5  vmovaps xmm3, [rsp+0x30]
00007a40685ddfcb  vmovaps xmm4, [rsp+0x40]
00007a40685ddfd1  vmovaps xmm5, [rsp+0x50]
00007a40685ddfd7  vmovaps xmm6, [rsp+0x60]
00007a40685ddfdd  vmovaps xmm8, [rsp+0x70]
00007a40685ddfe3  vmovaps xmm9, [rsp+0x80]
00007a40685ddfec  vmovaps xmm10, [rsp+0x90]
00007a40685ddff5  vmovaps xmm11, [rsp+0xA0]
00007a40685ddffe  vmovaps xmm12, [rsp+0xB0]
00007a40685de007  vmovaps xmm13, [rsp+0xC0]
00007a40685de010  vmovaps xmm14, [rsp+0xD0]
00007a40685de019  vmovaps xmm15, [rsp+0xE0]
00007a40685de022  add rsp, 0xF0
00007a40685de029  pop r11
00007a40685de02b  pop r10
00007a40685de02d  pop r9
00007a40685de02f  pop r8
00007a40685de031  pop rsi
00007a40685de032  pop rdi
00007a40685de033  pop rdx
00007a40685de034  pop rcx
00007a40685de035  pop rax
00007a40685de036  add rsp, 0x08
00007a40685de03a  jmp 0x00007A40685DC066
00007a40685de03f  call 0x00007A40684B52F0
00007a40685de044  jmp 0x00007A40685DC073
00007a40685de049  sub rsp, 0x08
00007a40685de04d  push rax
00007a40685de04e  push rcx
00007a40685de04f  push rdx
00007a40685de050  push rdi
00007a40685de051  push rsi
00007a40685de052  push r8
00007a40685de054  push r9
00007a40685de056  push r10
00007a40685de058  push r11
00007a40685de05a  sub rsp, 0xF0
00007a40685de061  vmovaps [rsp], xmm0
00007a40685de066  vmovaps [rsp+0x10], xmm1
00007a40685de06c  vmovaps [rsp+0x20], xmm2
00007a40685de072  vmovaps [rsp+0x30], xmm3
00007a40685de078  vmovaps [rsp+0x40], xmm4
00007a40685de07e  vmovaps [rsp+0x50], xmm5
00007a40685de084  vmovaps [rsp+0x60], xmm6
00007a40685de08a  vmovaps [rsp+0x70], xmm7
00007a40685de090  vmovaps [rsp+0x80], xmm8
00007a40685de099  vmovaps [rsp+0x90], xmm9
00007a40685de0a2  vmovaps [rsp+0xA0], xmm10
00007a40685de0ab  vmovaps [rsp+0xB0], xmm11
00007a40685de0b4  vmovaps [rsp+0xC0], xmm12
00007a40685de0bd  vmovaps [rsp+0xD0], xmm13
00007a40685de0c6  vmovaps [rsp+0xE0], xmm14
00007a40685de0cf  sub rsp, 0x30
00007a40685de0d3  movaps [rsp], xmm15
00007a40685de0d8  movaps [rsp+0x10], xmm5
00007a40685de0dd  movaps [rsp+0x20], xmm3
00007a40685de0e2  lea rdi, [rsp]
00007a40685de0e6  mov esi, 0x00
00007a40685de0eb  mov rax, 0x56F679577530
00007a40685de0f5  call rax
00007a40685de0f7  movaps xmm15, [rsp]
00007a40685de0fc  add rsp, 0x30
00007a40685de100  vmovaps xmm0, [rsp]
00007a40685de105  vmovaps xmm1, [rsp+0x10]
00007a40685de10b  vmovaps xmm2, [rsp+0x20]
00007a40685de111  vmovaps xmm3, [rsp+0x30]
00007a40685de117  vmovaps xmm4, [rsp+0x40]
00007a40685de11d  vmovaps xmm5, [rsp+0x50]
00007a40685de123  vmovaps xmm6, [rsp+0x60]
00007a40685de129  vmovaps xmm7, [rsp+0x70]
00007a40685de12f  vmovaps xmm8, [rsp+0x80]
00007a40685de138  vmovaps xmm9, [rsp+0x90]
00007a40685de141  vmovaps xmm10, [rsp+0xA0]
00007a40685de14a  vmovaps xmm11, [rsp+0xB0]
00007a40685de153  vmovaps xmm12, [rsp+0xC0]
00007a40685de15c  vmovaps xmm13, [rsp+0xD0]
00007a40685de165  vmovaps xmm14, [rsp+0xE0]
00007a40685de16e  add rsp, 0xF0
00007a40685de175  pop r11
00007a40685de177  pop r10
00007a40685de179  pop r9
00007a40685de17b  pop r8
00007a40685de17d  pop rsi
00007a40685de17e  pop rdi
00007a40685de17f  pop rdx
00007a40685de180  pop rcx
00007a40685de181  pop rax
00007a40685de182  add rsp, 0x08
00007a40685de186  jmp 0x00007A40685DC099
00007a40685de18b  sub rsp, 0x08
00007a40685de18f  push rax
00007a40685de190  push rcx
00007a40685de191  push rdx
00007a40685de192  push rdi
00007a40685de193  push rsi
00007a40685de194  push r8
00007a40685de196  push r9
00007a40685de198  push r10
00007a40685de19a  push r11
00007a40685de19c  sub rsp, 0xF0
00007a40685de1a3  vmovaps [rsp], xmm0
00007a40685de1a8  vmovaps [rsp+0x10], xmm2
00007a40685de1ae  vmovaps [rsp+0x20], xmm3
00007a40685de1b4  vmovaps [rsp+0x30], xmm4
00007a40685de1ba  vmovaps [rsp+0x40], xmm5
00007a40685de1c0  vmovaps [rsp+0x50], xmm6
00007a40685de1c6  vmovaps [rsp+0x60], xmm7
00007a40685de1cc  vmovaps [rsp+0x70], xmm8
00007a40685de1d2  vmovaps [rsp+0x80], xmm9
00007a40685de1db  vmovaps [rsp+0x90], xmm10
00007a40685de1e4  vmovaps [rsp+0xA0], xmm11
00007a40685de1ed  vmovaps [rsp+0xB0], xmm12
00007a40685de1f6  vmovaps [rsp+0xC0], xmm13
00007a40685de1ff  vmovaps [rsp+0xD0], xmm14
00007a40685de208  vmovaps [rsp+0xE0], xmm15
00007a40685de211  sub rsp, 0x30
00007a40685de215  movaps [rsp], xmm1
00007a40685de219  movaps [rsp+0x10], xmm5
00007a40685de21e  movaps [rsp+0x20], xmm4
00007a40685de223  lea rdi, [rsp]
00007a40685de227  mov esi, 0x00
00007a40685de22c  mov rax, 0x56F679577530
00007a40685de236  call rax
00007a40685de238  movaps xmm1, [rsp]
00007a40685de23c  add rsp, 0x30
00007a40685de240  vmovaps xmm0, [rsp]
00007a40685de245  vmovaps xmm2, [rsp+0x10]
00007a40685de24b  vmovaps xmm3, [rsp+0x20]
00007a40685de251  vmovaps xmm4, [rsp+0x30]
00007a40685de257  vmovaps xmm5, [rsp+0x40]
00007a40685de25d  vmovaps xmm6, [rsp+0x50]
00007a40685de263  vmovaps xmm7, [rsp+0x60]
00007a40685de269  vmovaps xmm8, [rsp+0x70]
00007a40685de26f  vmovaps xmm9, [rsp+0x80]
00007a40685de278  vmovaps xmm10, [rsp+0x90]
00007a40685de281  vmovaps xmm11, [rsp+0xA0]
00007a40685de28a  vmovaps xmm12, [rsp+0xB0]
00007a40685de293  vmovaps xmm13, [rsp+0xC0]
00007a40685de29c  vmovaps xmm14, [rsp+0xD0]
00007a40685de2a5  vmovaps xmm15, [rsp+0xE0]
00007a40685de2ae  add rsp, 0xF0
00007a40685de2b5  pop r11
00007a40685de2b7  pop r10
00007a40685de2b9  pop r9
00007a40685de2bb  pop r8
00007a40685de2bd  pop rsi
00007a40685de2be  pop rdi
00007a40685de2bf  pop rdx
00007a40685de2c0  pop rcx
00007a40685de2c1  pop rax
00007a40685de2c2  add rsp, 0x08
00007a40685de2c6  jmp 0x00007A40685DC0B9
00007a40685de2cb  sub rsp, 0x08
00007a40685de2cf  push rax
00007a40685de2d0  push rcx
00007a40685de2d1  push rdx
00007a40685de2d2  push rdi
00007a40685de2d3  push rsi
00007a40685de2d4  push r8
00007a40685de2d6  push r9
00007a40685de2d8  push r10
00007a40685de2da  push r11
00007a40685de2dc  sub rsp, 0xF0
00007a40685de2e3  vmovaps [rsp], xmm0
00007a40685de2e8  vmovaps [rsp+0x10], xmm1
00007a40685de2ee  vmovaps [rsp+0x20], xmm2
00007a40685de2f4  vmovaps [rsp+0x30], xmm3
00007a40685de2fa  vmovaps [rsp+0x40], xmm5
00007a40685de300  vmovaps [rsp+0x50], xmm6
00007a40685de306  vmovaps [rsp+0x60], xmm7
00007a40685de30c  vmovaps [rsp+0x70], xmm8
00007a40685de312  vmovaps [rsp+0x80], xmm9
00007a40685de31b  vmovaps [rsp+0x90], xmm10
00007a40685de324  vmovaps [rsp+0xA0], xmm11
00007a40685de32d  vmovaps [rsp+0xB0], xmm12
00007a40685de336  vmovaps [rsp+0xC0], xmm13
00007a40685de33f  vmovaps [rsp+0xD0], xmm14
00007a40685de348  vmovaps [rsp+0xE0], xmm15
00007a40685de351  sub rsp, 0x30
00007a40685de355  movaps [rsp], xmm4
00007a40685de359  movaps [rsp+0x10], xmm3
00007a40685de35e  movaps [rsp+0x20], xmm5
00007a40685de363  lea rdi, [rsp]
00007a40685de367  mov esi, 0x00
00007a40685de36c  mov rax, 0x56F679577530
00007a40685de376  call rax
00007a40685de378  movaps xmm4, [rsp]
00007a40685de37c  add rsp, 0x30
00007a40685de380  vmovaps xmm0, [rsp]
00007a40685de385  vmovaps xmm1, [rsp+0x10]
00007a40685de38b  vmovaps xmm2, [rsp+0x20]
00007a40685de391  vmovaps xmm3, [rsp+0x30]
00007a40685de397  vmovaps xmm5, [rsp+0x40]
00007a40685de39d  vmovaps xmm6, [rsp+0x50]
00007a40685de3a3  vmovaps xmm7, [rsp+0x60]
00007a40685de3a9  vmovaps xmm8, [rsp+0x70]
00007a40685de3af  vmovaps xmm9, [rsp+0x80]
00007a40685de3b8  vmovaps xmm10, [rsp+0x90]
00007a40685de3c1  vmovaps xmm11, [rsp+0xA0]
00007a40685de3ca  vmovaps xmm12, [rsp+0xB0]
00007a40685de3d3  vmovaps xmm13, [rsp+0xC0]
00007a40685de3dc  vmovaps xmm14, [rsp+0xD0]
00007a40685de3e5  vmovaps xmm15, [rsp+0xE0]
00007a40685de3ee  add rsp, 0xF0
00007a40685de3f5  pop r11
00007a40685de3f7  pop r10
00007a40685de3f9  pop r9
00007a40685de3fb  pop r8
00007a40685de3fd  pop rsi
00007a40685de3fe  pop rdi
00007a40685de3ff  pop rdx
00007a40685de400  pop rcx
00007a40685de401  pop rax
00007a40685de402  add rsp, 0x08
00007a40685de406  jmp 0x00007A40685DC107
00007a40685de40b  call 0x00007A40684B52F0
00007a40685de410  jmp 0x00007A40685DC114
00007a40685de415  sub rsp, 0x08
00007a40685de419  push rax
00007a40685de41a  push rcx
00007a40685de41b  push rdx
00007a40685de41c  push rdi
00007a40685de41d  push rsi
00007a40685de41e  push r8
00007a40685de420  push r9
00007a40685de422  push r10
00007a40685de424  push r11
00007a40685de426  sub rsp, 0xF0
00007a40685de42d  vmovaps [rsp], xmm0
00007a40685de432  vmovaps [rsp+0x10], xmm1
00007a40685de438  vmovaps [rsp+0x20], xmm2
00007a40685de43e  vmovaps [rsp+0x30], xmm3
00007a40685de444  vmovaps [rsp+0x40], xmm4
00007a40685de44a  vmovaps [rsp+0x50], xmm6
00007a40685de450  vmovaps [rsp+0x60], xmm7
00007a40685de456  vmovaps [rsp+0x70], xmm8
00007a40685de45c  vmovaps [rsp+0x80], xmm9
00007a40685de465  vmovaps [rsp+0x90], xmm10
00007a40685de46e  vmovaps [rsp+0xA0], xmm11
00007a40685de477  vmovaps [rsp+0xB0], xmm12
00007a40685de480  vmovaps [rsp+0xC0], xmm13
00007a40685de489  vmovaps [rsp+0xD0], xmm14
00007a40685de492  vmovaps [rsp+0xE0], xmm15
00007a40685de49b  sub rsp, 0x30
00007a40685de49f  movaps [rsp], xmm5
00007a40685de4a3  movaps [rsp+0x10], xmm6
00007a40685de4a8  movaps [rsp+0x20], xmm3
00007a40685de4ad  lea rdi, [rsp]
00007a40685de4b1  mov esi, 0x00
00007a40685de4b6  mov rax, 0x56F679577530
00007a40685de4c0  call rax
00007a40685de4c2  movaps xmm5, [rsp]
00007a40685de4c6  add rsp, 0x30
00007a40685de4ca  vmovaps xmm0, [rsp]
00007a40685de4cf  vmovaps xmm1, [rsp+0x10]
00007a40685de4d5  vmovaps xmm2, [rsp+0x20]
00007a40685de4db  vmovaps xmm3, [rsp+0x30]
00007a40685de4e1  vmovaps xmm4, [rsp+0x40]
00007a40685de4e7  vmovaps xmm6, [rsp+0x50]
00007a40685de4ed  vmovaps xmm7, [rsp+0x60]
00007a40685de4f3  vmovaps xmm8, [rsp+0x70]
00007a40685de4f9  vmovaps xmm9, [rsp+0x80]
00007a40685de502  vmovaps xmm10, [rsp+0x90]
00007a40685de50b  vmovaps xmm11, [rsp+0xA0]
00007a40685de514  vmovaps xmm12, [rsp+0xB0]
00007a40685de51d  vmovaps xmm13, [rsp+0xC0]
00007a40685de526  vmovaps xmm14, [rsp+0xD0]
00007a40685de52f  vmovaps xmm15, [rsp+0xE0]
00007a40685de538  add rsp, 0xF0
00007a40685de53f  pop r11
00007a40685de541  pop r10
00007a40685de543  pop r9
00007a40685de545  pop r8
00007a40685de547  pop rsi
00007a40685de548  pop rdi
00007a40685de549  pop rdx
00007a40685de54a  pop rcx
00007a40685de54b  pop rax
00007a40685de54c  add rsp, 0x08
00007a40685de550  jmp 0x00007A40685DC13A
00007a40685de555  sub rsp, 0x08
00007a40685de559  push rax
00007a40685de55a  push rcx
00007a40685de55b  push rdx
00007a40685de55c  push rdi
00007a40685de55d  push rsi
00007a40685de55e  push r8
00007a40685de560  push r9
00007a40685de562  push r10
00007a40685de564  push r11
00007a40685de566  sub rsp, 0xF0
00007a40685de56d  vmovaps [rsp], xmm0
00007a40685de572  vmovaps [rsp+0x10], xmm1
00007a40685de578  vmovaps [rsp+0x20], xmm2
00007a40685de57e  vmovaps [rsp+0x30], xmm3
00007a40685de584  vmovaps [rsp+0x40], xmm4
00007a40685de58a  vmovaps [rsp+0x50], xmm5
00007a40685de590  vmovaps [rsp+0x60], xmm7
00007a40685de596  vmovaps [rsp+0x70], xmm8
00007a40685de59c  vmovaps [rsp+0x80], xmm9
00007a40685de5a5  vmovaps [rsp+0x90], xmm10
00007a40685de5ae  vmovaps [rsp+0xA0], xmm11
00007a40685de5b7  vmovaps [rsp+0xB0], xmm12
00007a40685de5c0  vmovaps [rsp+0xC0], xmm13
00007a40685de5c9  vmovaps [rsp+0xD0], xmm14
00007a40685de5d2  vmovaps [rsp+0xE0], xmm15
00007a40685de5db  sub rsp, 0x30
00007a40685de5df  movaps [rsp], xmm6
00007a40685de5e3  movaps [rsp+0x10], xmm9
00007a40685de5e9  movaps [rsp+0x20], xmm1
00007a40685de5ee  lea rdi, [rsp]
00007a40685de5f2  mov esi, 0x00
00007a40685de5f7  mov rax, 0x56F679577530
00007a40685de601  call rax
00007a40685de603  movaps xmm6, [rsp]
00007a40685de607  add rsp, 0x30
00007a40685de60b  vmovaps xmm0, [rsp]
00007a40685de610  vmovaps xmm1, [rsp+0x10]
00007a40685de616  vmovaps xmm2, [rsp+0x20]
00007a40685de61c  vmovaps xmm3, [rsp+0x30]
00007a40685de622  vmovaps xmm4, [rsp+0x40]
00007a40685de628  vmovaps xmm5, [rsp+0x50]
00007a40685de62e  vmovaps xmm7, [rsp+0x60]
00007a40685de634  vmovaps xmm8, [rsp+0x70]
00007a40685de63a  vmovaps xmm9, [rsp+0x80]
00007a40685de643  vmovaps xmm10, [rsp+0x90]
00007a40685de64c  vmovaps xmm11, [rsp+0xA0]
00007a40685de655  vmovaps xmm12, [rsp+0xB0]
00007a40685de65e  vmovaps xmm13, [rsp+0xC0]
00007a40685de667  vmovaps xmm14, [rsp+0xD0]
00007a40685de670  vmovaps xmm15, [rsp+0xE0]
00007a40685de679  add rsp, 0xF0
00007a40685de680  pop r11
00007a40685de682  pop r10
00007a40685de684  pop r9
00007a40685de686  pop r8
00007a40685de688  pop rsi
00007a40685de689  pop rdi
00007a40685de68a  pop rdx
00007a40685de68b  pop rcx
00007a40685de68c  pop rax
00007a40685de68d  add rsp, 0x08
00007a40685de691  jmp 0x00007A40685DC15E
00007a40685de696  sub rsp, 0x08
00007a40685de69a  push rax
00007a40685de69b  push rcx
00007a40685de69c  push rdx
00007a40685de69d  push rdi
00007a40685de69e  push rsi
00007a40685de69f  push r8
00007a40685de6a1  push r9
00007a40685de6a3  push r10
00007a40685de6a5  push r11
00007a40685de6a7  sub rsp, 0xF0
00007a40685de6ae  vmovaps [rsp], xmm0
00007a40685de6b3  vmovaps [rsp+0x10], xmm1
00007a40685de6b9  vmovaps [rsp+0x20], xmm2
00007a40685de6bf  vmovaps [rsp+0x30], xmm3
00007a40685de6c5  vmovaps [rsp+0x40], xmm4
00007a40685de6cb  vmovaps [rsp+0x50], xmm5
00007a40685de6d1  vmovaps [rsp+0x60], xmm6
00007a40685de6d7  vmovaps [rsp+0x70], xmm7
00007a40685de6dd  vmovaps [rsp+0x80], xmm8
00007a40685de6e6  vmovaps [rsp+0x90], xmm10
00007a40685de6ef  vmovaps [rsp+0xA0], xmm11
00007a40685de6f8  vmovaps [rsp+0xB0], xmm12
00007a40685de701  vmovaps [rsp+0xC0], xmm13
00007a40685de70a  vmovaps [rsp+0xD0], xmm14
00007a40685de713  vmovaps [rsp+0xE0], xmm15
00007a40685de71c  sub rsp, 0x30
00007a40685de720  movaps [rsp], xmm9
00007a40685de725  movaps [rsp+0x10], xmm3
00007a40685de72a  movaps [rsp+0x20], xmm1
00007a40685de72f  lea rdi, [rsp]
00007a40685de733  mov esi, 0x00
00007a40685de738  mov rax, 0x56F679577530
00007a40685de742  call rax
00007a40685de744  movaps xmm9, [rsp]
00007a40685de749  add rsp, 0x30
00007a40685de74d  vmovaps xmm0, [rsp]
00007a40685de752  vmovaps xmm1, [rsp+0x10]
00007a40685de758  vmovaps xmm2, [rsp+0x20]
00007a40685de75e  vmovaps xmm3, [rsp+0x30]
00007a40685de764  vmovaps xmm4, [rsp+0x40]
00007a40685de76a  vmovaps xmm5, [rsp+0x50]
00007a40685de770  vmovaps xmm6, [rsp+0x60]
00007a40685de776  vmovaps xmm7, [rsp+0x70]
00007a40685de77c  vmovaps xmm8, [rsp+0x80]
00007a40685de785  vmovaps xmm10, [rsp+0x90]
00007a40685de78e  vmovaps xmm11, [rsp+0xA0]
00007a40685de797  vmovaps xmm12, [rsp+0xB0]
00007a40685de7a0  vmovaps xmm13, [rsp+0xC0]
00007a40685de7a9  vmovaps xmm14, [rsp+0xD0]
00007a40685de7b2  vmovaps xmm15, [rsp+0xE0]
00007a40685de7bb  add rsp, 0xF0
00007a40685de7c2  pop r11
00007a40685de7c4  pop r10
00007a40685de7c6  pop r9
00007a40685de7c8  pop r8
00007a40685de7ca  pop rsi
00007a40685de7cb  pop rdi
00007a40685de7cc  pop rdx
00007a40685de7cd  pop rcx
00007a40685de7ce  pop rax
00007a40685de7cf  add rsp, 0x08
00007a40685de7d3  jmp 0x00007A40685DC1AA
00007a40685de7d8  call 0x00007A40684B52F0
00007a40685de7dd  jmp 0x00007A40685DC1B7
00007a40685de7e2  sub rsp, 0x08
00007a40685de7e6  push rax
00007a40685de7e7  push rcx
00007a40685de7e8  push rdx
00007a40685de7e9  push rdi
00007a40685de7ea  push rsi
00007a40685de7eb  push r8
00007a40685de7ed  push r9
00007a40685de7ef  push r10
00007a40685de7f1  push r11
00007a40685de7f3  sub rsp, 0xF0
00007a40685de7fa  vmovaps [rsp], xmm0
00007a40685de7ff  vmovaps [rsp+0x10], xmm1
00007a40685de805  vmovaps [rsp+0x20], xmm2
00007a40685de80b  vmovaps [rsp+0x30], xmm3
00007a40685de811  vmovaps [rsp+0x40], xmm4
00007a40685de817  vmovaps [rsp+0x50], xmm5
00007a40685de81d  vmovaps [rsp+0x60], xmm6
00007a40685de823  vmovaps [rsp+0x70], xmm7
00007a40685de829  vmovaps [rsp+0x80], xmm8
00007a40685de832  vmovaps [rsp+0x90], xmm9
00007a40685de83b  vmovaps [rsp+0xA0], xmm10
00007a40685de844  vmovaps [rsp+0xB0], xmm11
00007a40685de84d  vmovaps [rsp+0xC0], xmm12
00007a40685de856  vmovaps [rsp+0xD0], xmm13
00007a40685de85f  vmovaps [rsp+0xE0], xmm14
00007a40685de868  sub rsp, 0x30
00007a40685de86c  movaps [rsp], xmm15
00007a40685de871  movaps [rsp+0x10], xmm3
00007a40685de876  movaps [rsp+0x20], xmm7
00007a40685de87b  lea rdi, [rsp]
00007a40685de87f  mov esi, 0x00
00007a40685de884  mov rax, 0x56F679577530
00007a40685de88e  call rax
00007a40685de890  movaps xmm15, [rsp]
00007a40685de895  add rsp, 0x30
00007a40685de899  vmovaps xmm0, [rsp]
00007a40685de89e  vmovaps xmm1, [rsp+0x10]
00007a40685de8a4  vmovaps xmm2, [rsp+0x20]
00007a40685de8aa  vmovaps xmm3, [rsp+0x30]
00007a40685de8b0  vmovaps xmm4, [rsp+0x40]
00007a40685de8b6  vmovaps xmm5, [rsp+0x50]
00007a40685de8bc  vmovaps xmm6, [rsp+0x60]
00007a40685de8c2  vmovaps xmm7, [rsp+0x70]
00007a40685de8c8  vmovaps xmm8, [rsp+0x80]
00007a40685de8d1  vmovaps xmm9, [rsp+0x90]
00007a40685de8da  vmovaps xmm10, [rsp+0xA0]
00007a40685de8e3  vmovaps xmm11, [rsp+0xB0]
00007a40685de8ec  vmovaps xmm12, [rsp+0xC0]
00007a40685de8f5  vmovaps xmm13, [rsp+0xD0]
00007a40685de8fe  vmovaps xmm14, [rsp+0xE0]
00007a40685de907  add rsp, 0xF0
00007a40685de90e  pop r11
00007a40685de910  pop r10
00007a40685de912  pop r9
00007a40685de914  pop r8
00007a40685de916  pop rsi
00007a40685de917  pop rdi
00007a40685de918  pop rdx
00007a40685de919  pop rcx
00007a40685de91a  pop rax
00007a40685de91b  add rsp, 0x08
00007a40685de91f  jmp 0x00007A40685DC1E3
00007a40685de924  sub rsp, 0x08
00007a40685de928  push rax
00007a40685de929  push rcx
00007a40685de92a  push rdx
00007a40685de92b  push rdi
00007a40685de92c  push rsi
00007a40685de92d  push r8
00007a40685de92f  push r9
00007a40685de931  push r10
00007a40685de933  push r11
00007a40685de935  sub rsp, 0xF0
00007a40685de93c  vmovaps [rsp], xmm0
00007a40685de941  vmovaps [rsp+0x10], xmm1
00007a40685de947  vmovaps [rsp+0x20], xmm2
00007a40685de94d  vmovaps [rsp+0x30], xmm4
00007a40685de953  vmovaps [rsp+0x40], xmm5
00007a40685de959  vmovaps [rsp+0x50], xmm6
00007a40685de95f  vmovaps [rsp+0x60], xmm7
00007a40685de965  vmovaps [rsp+0x70], xmm8
00007a40685de96b  vmovaps [rsp+0x80], xmm9
00007a40685de974  vmovaps [rsp+0x90], xmm10
00007a40685de97d  vmovaps [rsp+0xA0], xmm11
00007a40685de986  vmovaps [rsp+0xB0], xmm12
00007a40685de98f  vmovaps [rsp+0xC0], xmm13
00007a40685de998  vmovaps [rsp+0xD0], xmm14
00007a40685de9a1  vmovaps [rsp+0xE0], xmm15
00007a40685de9aa  sub rsp, 0x30
00007a40685de9ae  movaps [rsp], xmm3
00007a40685de9b2  movaps [rsp+0x10], xmm1
00007a40685de9b7  movaps [rsp+0x20], xmm15
00007a40685de9bd  lea rdi, [rsp]
00007a40685de9c1  mov esi, 0x00
00007a40685de9c6  mov rax, 0x56F679577530
00007a40685de9d0  call rax
00007a40685de9d2  movaps xmm3, [rsp]
00007a40685de9d6  add rsp, 0x30
00007a40685de9da  vmovaps xmm0, [rsp]
00007a40685de9df  vmovaps xmm1, [rsp+0x10]
00007a40685de9e5  vmovaps xmm2, [rsp+0x20]
00007a40685de9eb  vmovaps xmm4, [rsp+0x30]
00007a40685de9f1  vmovaps xmm5, [rsp+0x40]
00007a40685de9f7  vmovaps xmm6, [rsp+0x50]
00007a40685de9fd  vmovaps xmm7, [rsp+0x60]
00007a40685dea03  vmovaps xmm8, [rsp+0x70]
00007a40685dea09  vmovaps xmm9, [rsp+0x80]
00007a40685dea12  vmovaps xmm10, [rsp+0x90]
00007a40685dea1b  vmovaps xmm11, [rsp+0xA0]
00007a40685dea24  vmovaps xmm12, [rsp+0xB0]
00007a40685dea2d  vmovaps xmm13, [rsp+0xC0]
00007a40685dea36  vmovaps xmm14, [rsp+0xD0]
00007a40685dea3f  vmovaps xmm15, [rsp+0xE0]
00007a40685dea48  add rsp, 0xF0
00007a40685dea4f  pop r11
00007a40685dea51  pop r10
00007a40685dea53  pop r9
00007a40685dea55  pop r8
00007a40685dea57  pop rsi
00007a40685dea58  pop rdi
00007a40685dea59  pop rdx
00007a40685dea5a  pop rcx
00007a40685dea5b  pop rax
00007a40685dea5c  add rsp, 0x08
00007a40685dea60  jmp 0x00007A40685DC272
00007a40685dea65  call 0x00007A40684B52F0
00007a40685dea6a  jmp 0x00007A40685DC27C
00007a40685dea6f  sub rsp, 0x08
00007a40685dea73  push rax
00007a40685dea74  push rcx
00007a40685dea75  push rdx
00007a40685dea76  push rdi
00007a40685dea77  push rsi
00007a40685dea78  push r8
00007a40685dea7a  push r9
00007a40685dea7c  push r10
00007a40685dea7e  push r11
00007a40685dea80  sub rsp, 0xF0
00007a40685dea87  vmovaps [rsp], xmm0
00007a40685dea8c  vmovaps [rsp+0x10], xmm1
00007a40685dea92  vmovaps [rsp+0x20], xmm2
00007a40685dea98  vmovaps [rsp+0x30], xmm3
00007a40685dea9e  vmovaps [rsp+0x40], xmm4
00007a40685deaa4  vmovaps [rsp+0x50], xmm5
00007a40685deaaa  vmovaps [rsp+0x60], xmm6
00007a40685deab0  vmovaps [rsp+0x70], xmm7
00007a40685deab6  vmovaps [rsp+0x80], xmm8
00007a40685deabf  vmovaps [rsp+0x90], xmm9
00007a40685deac8  vmovaps [rsp+0xA0], xmm10
00007a40685dead1  vmovaps [rsp+0xB0], xmm11
00007a40685deada  vmovaps [rsp+0xC0], xmm12
00007a40685deae3  vmovaps [rsp+0xD0], xmm13
00007a40685deaec  vmovaps [rsp+0xE0], xmm14
00007a40685deaf5  sub rsp, 0x30
00007a40685deaf9  movaps [rsp], xmm15
00007a40685deafe  movaps [rsp+0x10], xmm14
00007a40685deb04  movaps [rsp+0x20], xmm4
00007a40685deb09  lea rdi, [rsp]
00007a40685deb0d  mov esi, 0x00
00007a40685deb12  mov rax, 0x56F679577530
00007a40685deb1c  call rax
00007a40685deb1e  movaps xmm15, [rsp]
00007a40685deb23  add rsp, 0x30
00007a40685deb27  vmovaps xmm0, [rsp]
00007a40685deb2c  vmovaps xmm1, [rsp+0x10]
00007a40685deb32  vmovaps xmm2, [rsp+0x20]
00007a40685deb38  vmovaps xmm3, [rsp+0x30]
00007a40685deb3e  vmovaps xmm4, [rsp+0x40]
00007a40685deb44  vmovaps xmm5, [rsp+0x50]
00007a40685deb4a  vmovaps xmm6, [rsp+0x60]
00007a40685deb50  vmovaps xmm7, [rsp+0x70]
00007a40685deb56  vmovaps xmm8, [rsp+0x80]
00007a40685deb5f  vmovaps xmm9, [rsp+0x90]
00007a40685deb68  vmovaps xmm10, [rsp+0xA0]
00007a40685deb71  vmovaps xmm11, [rsp+0xB0]
00007a40685deb7a  vmovaps xmm12, [rsp+0xC0]
00007a40685deb83  vmovaps xmm13, [rsp+0xD0]
00007a40685deb8c  vmovaps xmm14, [rsp+0xE0]
00007a40685deb95  add rsp, 0xF0
00007a40685deb9c  pop r11
00007a40685deb9e  pop r10
00007a40685deba0  pop r9
00007a40685deba2  pop r8
00007a40685deba4  pop rsi
00007a40685deba5  pop rdi
00007a40685deba6  pop rdx
00007a40685deba7  pop rcx
00007a40685deba8  pop rax
00007a40685deba9  add rsp, 0x08
00007a40685debad  jmp 0x00007A40685DC2AA
00007a40685debb2  sub rsp, 0x08
00007a40685debb6  push rax
00007a40685debb7  push rcx
00007a40685debb8  push rdx
00007a40685debb9  push rdi
00007a40685debba  push rsi
00007a40685debbb  push r8
00007a40685debbd  push r9
00007a40685debbf  push r10
00007a40685debc1  push r11
00007a40685debc3  sub rsp, 0xF0
00007a40685debca  vmovaps [rsp], xmm0
00007a40685debcf  vmovaps [rsp+0x10], xmm1
00007a40685debd5  vmovaps [rsp+0x20], xmm2
00007a40685debdb  vmovaps [rsp+0x30], xmm3
00007a40685debe1  vmovaps [rsp+0x40], xmm4
00007a40685debe7  vmovaps [rsp+0x50], xmm5
00007a40685debed  vmovaps [rsp+0x60], xmm6
00007a40685debf3  vmovaps [rsp+0x70], xmm7
00007a40685debf9  vmovaps [rsp+0x80], xmm8
00007a40685dec02  vmovaps [rsp+0x90], xmm9
00007a40685dec0b  vmovaps [rsp+0xA0], xmm10
00007a40685dec14  vmovaps [rsp+0xB0], xmm11
00007a40685dec1d  vmovaps [rsp+0xC0], xmm12
00007a40685dec26  vmovaps [rsp+0xD0], xmm13
00007a40685dec2f  vmovaps [rsp+0xE0], xmm15
00007a40685dec38  sub rsp, 0x30
00007a40685dec3c  movaps [rsp], xmm14
00007a40685dec41  movaps [rsp+0x10], xmm2
00007a40685dec46  movaps [rsp+0x20], xmm1
00007a40685dec4b  lea rdi, [rsp]
00007a40685dec4f  mov esi, 0x00
00007a40685dec54  mov rax, 0x56F679577530
00007a40685dec5e  call rax
00007a40685dec60  movaps xmm14, [rsp]
00007a40685dec65  add rsp, 0x30
00007a40685dec69  vmovaps xmm0, [rsp]
00007a40685dec6e  vmovaps xmm1, [rsp+0x10]
00007a40685dec74  vmovaps xmm2, [rsp+0x20]
00007a40685dec7a  vmovaps xmm3, [rsp+0x30]
00007a40685dec80  vmovaps xmm4, [rsp+0x40]
00007a40685dec86  vmovaps xmm5, [rsp+0x50]
00007a40685dec8c  vmovaps xmm6, [rsp+0x60]
00007a40685dec92  vmovaps xmm7, [rsp+0x70]
00007a40685dec98  vmovaps xmm8, [rsp+0x80]
00007a40685deca1  vmovaps xmm9, [rsp+0x90]
00007a40685decaa  vmovaps xmm10, [rsp+0xA0]
00007a40685decb3  vmovaps xmm11, [rsp+0xB0]
00007a40685decbc  vmovaps xmm12, [rsp+0xC0]
00007a40685decc5  vmovaps xmm13, [rsp+0xD0]
00007a40685decce  vmovaps xmm15, [rsp+0xE0]
00007a40685decd7  add rsp, 0xF0
00007a40685decde  pop r11
00007a40685dece0  pop r10
00007a40685dece2  pop r9
00007a40685dece4  pop r8
00007a40685dece6  pop rsi
00007a40685dece7  pop rdi
00007a40685dece8  pop rdx
00007a40685dece9  pop rcx
00007a40685decea  pop rax
00007a40685deceb  add rsp, 0x08
00007a40685decef  jmp 0x00007A40685DC2D0
00007a40685decf4  sub rsp, 0x08
00007a40685decf8  push rax
00007a40685decf9  push rcx
00007a40685decfa  push rdx
00007a40685decfb  push rdi
00007a40685decfc  push rsi
00007a40685decfd  push r8
00007a40685decff  push r9
00007a40685ded01  push r10
00007a40685ded03  push r11
00007a40685ded05  sub rsp, 0xF0
00007a40685ded0c  vmovaps [rsp], xmm0
00007a40685ded11  vmovaps [rsp+0x10], xmm2
00007a40685ded17  vmovaps [rsp+0x20], xmm3
00007a40685ded1d  vmovaps [rsp+0x30], xmm4
00007a40685ded23  vmovaps [rsp+0x40], xmm5
00007a40685ded29  vmovaps [rsp+0x50], xmm6
00007a40685ded2f  vmovaps [rsp+0x60], xmm7
00007a40685ded35  vmovaps [rsp+0x70], xmm8
00007a40685ded3b  vmovaps [rsp+0x80], xmm9
00007a40685ded44  vmovaps [rsp+0x90], xmm10
00007a40685ded4d  vmovaps [rsp+0xA0], xmm11
00007a40685ded56  vmovaps [rsp+0xB0], xmm12
00007a40685ded5f  vmovaps [rsp+0xC0], xmm13
00007a40685ded68  vmovaps [rsp+0xD0], xmm14
00007a40685ded71  vmovaps [rsp+0xE0], xmm15
00007a40685ded7a  sub rsp, 0x30
00007a40685ded7e  movaps [rsp], xmm1
00007a40685ded82  movaps [rsp+0x10], xmm4
00007a40685ded87  movaps [rsp+0x20], xmm9
00007a40685ded8d  lea rdi, [rsp]
00007a40685ded91  mov esi, 0x00
00007a40685ded96  mov rax, 0x56F679577530
00007a40685deda0  call rax
00007a40685deda2  movaps xmm1, [rsp]
00007a40685deda6  add rsp, 0x30
00007a40685dedaa  vmovaps xmm0, [rsp]
00007a40685dedaf  vmovaps xmm2, [rsp+0x10]
00007a40685dedb5  vmovaps xmm3, [rsp+0x20]
00007a40685dedbb  vmovaps xmm4, [rsp+0x30]
00007a40685dedc1  vmovaps xmm5, [rsp+0x40]
00007a40685dedc7  vmovaps xmm6, [rsp+0x50]
00007a40685dedcd  vmovaps xmm7, [rsp+0x60]
00007a40685dedd3  vmovaps xmm8, [rsp+0x70]
00007a40685dedd9  vmovaps xmm9, [rsp+0x80]
00007a40685dede2  vmovaps xmm10, [rsp+0x90]
00007a40685dedeb  vmovaps xmm11, [rsp+0xA0]
00007a40685dedf4  vmovaps xmm12, [rsp+0xB0]
00007a40685dedfd  vmovaps xmm13, [rsp+0xC0]
00007a40685dee06  vmovaps xmm14, [rsp+0xD0]
00007a40685dee0f  vmovaps xmm15, [rsp+0xE0]
00007a40685dee18  add rsp, 0xF0
00007a40685dee1f  pop r11
00007a40685dee21  pop r10
00007a40685dee23  pop r9
00007a40685dee25  pop r8
00007a40685dee27  pop rsi
00007a40685dee28  pop rdi
00007a40685dee29  pop rdx
00007a40685dee2a  pop rcx
00007a40685dee2b  pop rax
00007a40685dee2c  add rsp, 0x08
00007a40685dee30  jmp 0x00007A40685DC2EE
00007a40685dee35  sub rsp, 0x08
00007a40685dee39  push rax
00007a40685dee3a  push rcx
00007a40685dee3b  push rdx
00007a40685dee3c  push rdi
00007a40685dee3d  push rsi
00007a40685dee3e  push r8
00007a40685dee40  push r9
00007a40685dee42  push r10
00007a40685dee44  push r11
00007a40685dee46  sub rsp, 0xF0
00007a40685dee4d  vmovaps [rsp], xmm0
00007a40685dee52  vmovaps [rsp+0x10], xmm1
00007a40685dee58  vmovaps [rsp+0x20], xmm2
00007a40685dee5e  vmovaps [rsp+0x30], xmm3
00007a40685dee64  vmovaps [rsp+0x40], xmm5
00007a40685dee6a  vmovaps [rsp+0x50], xmm6
00007a40685dee70  vmovaps [rsp+0x60], xmm7
00007a40685dee76  vmovaps [rsp+0x70], xmm8
00007a40685dee7c  vmovaps [rsp+0x80], xmm9
00007a40685dee85  vmovaps [rsp+0x90], xmm10
00007a40685dee8e  vmovaps [rsp+0xA0], xmm11
00007a40685dee97  vmovaps [rsp+0xB0], xmm12
00007a40685deea0  vmovaps [rsp+0xC0], xmm13
00007a40685deea9  vmovaps [rsp+0xD0], xmm14
00007a40685deeb2  vmovaps [rsp+0xE0], xmm15
00007a40685deebb  sub rsp, 0x30
00007a40685deebf  movaps [rsp], xmm4
00007a40685deec3  movaps [rsp+0x10], xmm2
00007a40685deec8  movaps [rsp+0x20], xmm9
00007a40685deece  lea rdi, [rsp]
00007a40685deed2  mov esi, 0x00
00007a40685deed7  mov rax, 0x56F679577530
00007a40685deee1  call rax
00007a40685deee3  movaps xmm4, [rsp]
00007a40685deee7  add rsp, 0x30
00007a40685deeeb  vmovaps xmm0, [rsp]
00007a40685deef0  vmovaps xmm1, [rsp+0x10]
00007a40685deef6  vmovaps xmm2, [rsp+0x20]
00007a40685deefc  vmovaps xmm3, [rsp+0x30]
00007a40685def02  vmovaps xmm5, [rsp+0x40]
00007a40685def08  vmovaps xmm6, [rsp+0x50]
00007a40685def0e  vmovaps xmm7, [rsp+0x60]
00007a40685def14  vmovaps xmm8, [rsp+0x70]
00007a40685def1a  vmovaps xmm9, [rsp+0x80]
00007a40685def23  vmovaps xmm10, [rsp+0x90]
00007a40685def2c  vmovaps xmm11, [rsp+0xA0]
00007a40685def35  vmovaps xmm12, [rsp+0xB0]
00007a40685def3e  vmovaps xmm13, [rsp+0xC0]
00007a40685def47  vmovaps xmm14, [rsp+0xD0]
00007a40685def50  vmovaps xmm15, [rsp+0xE0]
00007a40685def59  add rsp, 0xF0
00007a40685def60  pop r11
00007a40685def62  pop r10
00007a40685def64  pop r9
00007a40685def66  pop r8
00007a40685def68  pop rsi
00007a40685def69  pop rdi
00007a40685def6a  pop rdx
00007a40685def6b  pop rcx
00007a40685def6c  pop rax
00007a40685def6d  add rsp, 0x08
00007a40685def71  jmp 0x00007A40685DC31E
00007a40685def76  sub rsp, 0x08
00007a40685def7a  push rax
00007a40685def7b  push rcx
00007a40685def7c  push rdx
00007a40685def7d  push rdi
00007a40685def7e  push rsi
00007a40685def7f  push r8
00007a40685def81  push r9
00007a40685def83  push r10
00007a40685def85  push r11
00007a40685def87  sub rsp, 0xF0
00007a40685def8e  vmovaps [rsp], xmm0
00007a40685def93  vmovaps [rsp+0x10], xmm1
00007a40685def99  vmovaps [rsp+0x20], xmm2
00007a40685def9f  vmovaps [rsp+0x30], xmm3
00007a40685defa5  vmovaps [rsp+0x40], xmm4
00007a40685defab  vmovaps [rsp+0x50], xmm5
00007a40685defb1  vmovaps [rsp+0x60], xmm6
00007a40685defb7  vmovaps [rsp+0x70], xmm7
00007a40685defbd  vmovaps [rsp+0x80], xmm8
00007a40685defc6  vmovaps [rsp+0x90], xmm10
00007a40685defcf  vmovaps [rsp+0xA0], xmm11
00007a40685defd8  vmovaps [rsp+0xB0], xmm12
00007a40685defe1  vmovaps [rsp+0xC0], xmm13
00007a40685defea  vmovaps [rsp+0xD0], xmm14
00007a40685deff3  vmovaps [rsp+0xE0], xmm15
00007a40685deffc  sub rsp, 0x30
00007a40685df000  movaps [rsp], xmm9
00007a40685df005  movaps [rsp+0x10], xmm2
00007a40685df00a  movaps [rsp+0x20], xmm1
00007a40685df00f  lea rdi, [rsp]
00007a40685df013  mov esi, 0x00
00007a40685df018  mov rax, 0x56F679577530
00007a40685df022  call rax
00007a40685df024  movaps xmm9, [rsp]
00007a40685df029  add rsp, 0x30
00007a40685df02d  vmovaps xmm0, [rsp]
00007a40685df032  vmovaps xmm1, [rsp+0x10]
00007a40685df038  vmovaps xmm2, [rsp+0x20]
00007a40685df03e  vmovaps xmm3, [rsp+0x30]
00007a40685df044  vmovaps xmm4, [rsp+0x40]
00007a40685df04a  vmovaps xmm5, [rsp+0x50]
00007a40685df050  vmovaps xmm6, [rsp+0x60]
00007a40685df056  vmovaps xmm7, [rsp+0x70]
00007a40685df05c  vmovaps xmm8, [rsp+0x80]
00007a40685df065  vmovaps xmm10, [rsp+0x90]
00007a40685df06e  vmovaps xmm11, [rsp+0xA0]
00007a40685df077  vmovaps xmm12, [rsp+0xB0]
00007a40685df080  vmovaps xmm13, [rsp+0xC0]
00007a40685df089  vmovaps xmm14, [rsp+0xD0]
00007a40685df092  vmovaps xmm15, [rsp+0xE0]
00007a40685df09b  add rsp, 0xF0
00007a40685df0a2  pop r11
00007a40685df0a4  pop r10
00007a40685df0a6  pop r9
00007a40685df0a8  pop r8
00007a40685df0aa  pop rsi
00007a40685df0ab  pop rdi
00007a40685df0ac  pop rdx
00007a40685df0ad  pop rcx
00007a40685df0ae  pop rax
00007a40685df0af  add rsp, 0x08
00007a40685df0b3  jmp 0x00007A40685DC354
00007a40685df0b8  sub rsp, 0x08
00007a40685df0bc  push rax
00007a40685df0bd  push rcx
00007a40685df0be  push rdx
00007a40685df0bf  push rdi
00007a40685df0c0  push rsi
00007a40685df0c1  push r8
00007a40685df0c3  push r9
00007a40685df0c5  push r10
00007a40685df0c7  push r11
00007a40685df0c9  sub rsp, 0xF0
00007a40685df0d0  vmovaps [rsp], xmm0
00007a40685df0d5  vmovaps [rsp+0x10], xmm2
00007a40685df0db  vmovaps [rsp+0x20], xmm3
00007a40685df0e1  vmovaps [rsp+0x30], xmm4
00007a40685df0e7  vmovaps [rsp+0x40], xmm5
00007a40685df0ed  vmovaps [rsp+0x50], xmm6
00007a40685df0f3  vmovaps [rsp+0x60], xmm7
00007a40685df0f9  vmovaps [rsp+0x70], xmm8
00007a40685df0ff  vmovaps [rsp+0x80], xmm9
00007a40685df108  vmovaps [rsp+0x90], xmm10
00007a40685df111  vmovaps [rsp+0xA0], xmm11
00007a40685df11a  vmovaps [rsp+0xB0], xmm12
00007a40685df123  vmovaps [rsp+0xC0], xmm13
00007a40685df12c  vmovaps [rsp+0xD0], xmm14
00007a40685df135  vmovaps [rsp+0xE0], xmm15
00007a40685df13e  sub rsp, 0x30
00007a40685df142  movaps [rsp], xmm1
00007a40685df146  movaps [rsp+0x10], xmm15
00007a40685df14c  movaps [rsp+0x20], xmm6
00007a40685df151  lea rdi, [rsp]
00007a40685df155  mov esi, 0x00
00007a40685df15a  mov rax, 0x56F679577530
00007a40685df164  call rax
00007a40685df166  movaps xmm1, [rsp]
00007a40685df16a  add rsp, 0x30
00007a40685df16e  vmovaps xmm0, [rsp]
00007a40685df173  vmovaps xmm2, [rsp+0x10]
00007a40685df179  vmovaps xmm3, [rsp+0x20]
00007a40685df17f  vmovaps xmm4, [rsp+0x30]
00007a40685df185  vmovaps xmm5, [rsp+0x40]
00007a40685df18b  vmovaps xmm6, [rsp+0x50]
00007a40685df191  vmovaps xmm7, [rsp+0x60]
00007a40685df197  vmovaps xmm8, [rsp+0x70]
00007a40685df19d  vmovaps xmm9, [rsp+0x80]
00007a40685df1a6  vmovaps xmm10, [rsp+0x90]
00007a40685df1af  vmovaps xmm11, [rsp+0xA0]
00007a40685df1b8  vmovaps xmm12, [rsp+0xB0]
00007a40685df1c1  vmovaps xmm13, [rsp+0xC0]
00007a40685df1ca  vmovaps xmm14, [rsp+0xD0]
00007a40685df1d3  vmovaps xmm15, [rsp+0xE0]
00007a40685df1dc  add rsp, 0xF0
00007a40685df1e3  pop r11
00007a40685df1e5  pop r10
00007a40685df1e7  pop r9
00007a40685df1e9  pop r8
00007a40685df1eb  pop rsi
00007a40685df1ec  pop rdi
00007a40685df1ed  pop rdx
00007a40685df1ee  pop rcx
00007a40685df1ef  pop rax
00007a40685df1f0  add rsp, 0x08
00007a40685df1f4  jmp 0x00007A40685DC375
00007a40685df1f9  sub rsp, 0x08
00007a40685df1fd  push rax
00007a40685df1fe  push rcx
00007a40685df1ff  push rdx
00007a40685df200  push rdi
00007a40685df201  push rsi
00007a40685df202  push r8
00007a40685df204  push r9
00007a40685df206  push r10
00007a40685df208  push r11
00007a40685df20a  sub rsp, 0xF0
00007a40685df211  vmovaps [rsp], xmm0
00007a40685df216  vmovaps [rsp+0x10], xmm1
00007a40685df21c  vmovaps [rsp+0x20], xmm2
00007a40685df222  vmovaps [rsp+0x30], xmm3
00007a40685df228  vmovaps [rsp+0x40], xmm4
00007a40685df22e  vmovaps [rsp+0x50], xmm5
00007a40685df234  vmovaps [rsp+0x60], xmm6
00007a40685df23a  vmovaps [rsp+0x70], xmm7
00007a40685df240  vmovaps [rsp+0x80], xmm8
00007a40685df249  vmovaps [rsp+0x90], xmm9
00007a40685df252  vmovaps [rsp+0xA0], xmm10
00007a40685df25b  vmovaps [rsp+0xB0], xmm11
00007a40685df264  vmovaps [rsp+0xC0], xmm12
00007a40685df26d  vmovaps [rsp+0xD0], xmm13
00007a40685df276  vmovaps [rsp+0xE0], xmm14
00007a40685df27f  sub rsp, 0x30
00007a40685df283  movaps [rsp], xmm15
00007a40685df288  movaps [rsp+0x10], xmm5
00007a40685df28d  movaps [rsp+0x20], xmm3
00007a40685df292  lea rdi, [rsp]
00007a40685df296  mov esi, 0x00
00007a40685df29b  mov rax, 0x56F679577530
00007a40685df2a5  call rax
00007a40685df2a7  movaps xmm15, [rsp]
00007a40685df2ac  add rsp, 0x30
00007a40685df2b0  vmovaps xmm0, [rsp]
00007a40685df2b5  vmovaps xmm1, [rsp+0x10]
00007a40685df2bb  vmovaps xmm2, [rsp+0x20]
00007a40685df2c1  vmovaps xmm3, [rsp+0x30]
00007a40685df2c7  vmovaps xmm4, [rsp+0x40]
00007a40685df2cd  vmovaps xmm5, [rsp+0x50]
00007a40685df2d3  vmovaps xmm6, [rsp+0x60]
00007a40685df2d9  vmovaps xmm7, [rsp+0x70]
00007a40685df2df  vmovaps xmm8, [rsp+0x80]
00007a40685df2e8  vmovaps xmm9, [rsp+0x90]
00007a40685df2f1  vmovaps xmm10, [rsp+0xA0]
00007a40685df2fa  vmovaps xmm11, [rsp+0xB0]
00007a40685df303  vmovaps xmm12, [rsp+0xC0]
00007a40685df30c  vmovaps xmm13, [rsp+0xD0]
00007a40685df315  vmovaps xmm14, [rsp+0xE0]
00007a40685df31e  add rsp, 0xF0
00007a40685df325  pop r11
00007a40685df327  pop r10
00007a40685df329  pop r9
00007a40685df32b  pop r8
00007a40685df32d  pop rsi
00007a40685df32e  pop rdi
00007a40685df32f  pop rdx
00007a40685df330  pop rcx
00007a40685df331  pop rax
00007a40685df332  add rsp, 0x08
00007a40685df336  jmp 0x00007A40685DC38F
00007a40685df33b  sub rsp, 0x08
00007a40685df33f  push rax
00007a40685df340  push rcx
00007a40685df341  push rdx
00007a40685df342  push rdi
00007a40685df343  push rsi
00007a40685df344  push r8
00007a40685df346  push r9
00007a40685df348  push r10
00007a40685df34a  push r11
00007a40685df34c  sub rsp, 0xF0
00007a40685df353  vmovaps [rsp], xmm0
00007a40685df358  vmovaps [rsp+0x10], xmm1
00007a40685df35e  vmovaps [rsp+0x20], xmm2
00007a40685df364  vmovaps [rsp+0x30], xmm3
00007a40685df36a  vmovaps [rsp+0x40], xmm4
00007a40685df370  vmovaps [rsp+0x50], xmm6
00007a40685df376  vmovaps [rsp+0x60], xmm7
00007a40685df37c  vmovaps [rsp+0x70], xmm8
00007a40685df382  vmovaps [rsp+0x80], xmm9
00007a40685df38b  vmovaps [rsp+0x90], xmm10
00007a40685df394  vmovaps [rsp+0xA0], xmm11
00007a40685df39d  vmovaps [rsp+0xB0], xmm12
00007a40685df3a6  vmovaps [rsp+0xC0], xmm13
00007a40685df3af  vmovaps [rsp+0xD0], xmm14
00007a40685df3b8  vmovaps [rsp+0xE0], xmm15
00007a40685df3c1  sub rsp, 0x30
00007a40685df3c5  movaps [rsp], xmm5
00007a40685df3c9  movaps [rsp+0x10], xmm8
00007a40685df3cf  movaps [rsp+0x20], xmm6
00007a40685df3d4  lea rdi, [rsp]
00007a40685df3d8  mov esi, 0x00
00007a40685df3dd  mov rax, 0x56F679577530
00007a40685df3e7  call rax
00007a40685df3e9  movaps xmm5, [rsp]
00007a40685df3ed  add rsp, 0x30
00007a40685df3f1  vmovaps xmm0, [rsp]
00007a40685df3f6  vmovaps xmm1, [rsp+0x10]
00007a40685df3fc  vmovaps xmm2, [rsp+0x20]
00007a40685df402  vmovaps xmm3, [rsp+0x30]
00007a40685df408  vmovaps xmm4, [rsp+0x40]
00007a40685df40e  vmovaps xmm6, [rsp+0x50]
00007a40685df414  vmovaps xmm7, [rsp+0x60]
00007a40685df41a  vmovaps xmm8, [rsp+0x70]
00007a40685df420  vmovaps xmm9, [rsp+0x80]
00007a40685df429  vmovaps xmm10, [rsp+0x90]
00007a40685df432  vmovaps xmm11, [rsp+0xA0]
00007a40685df43b  vmovaps xmm12, [rsp+0xB0]
00007a40685df444  vmovaps xmm13, [rsp+0xC0]
00007a40685df44d  vmovaps xmm14, [rsp+0xD0]
00007a40685df456  vmovaps xmm15, [rsp+0xE0]
00007a40685df45f  add rsp, 0xF0
00007a40685df466  pop r11
00007a40685df468  pop r10
00007a40685df46a  pop r9
00007a40685df46c  pop r8
00007a40685df46e  pop rsi
00007a40685df46f  pop rdi
00007a40685df470  pop rdx
00007a40685df471  pop rcx
00007a40685df472  pop rax
00007a40685df473  add rsp, 0x08
00007a40685df477  jmp 0x00007A40685DC3B3
00007a40685df47c  sub rsp, 0x08
00007a40685df480  push rax
00007a40685df481  push rcx
00007a40685df482  push rdx
00007a40685df483  push rdi
00007a40685df484  push rsi
00007a40685df485  push r8
00007a40685df487  push r9
00007a40685df489  push r10
00007a40685df48b  push r11
00007a40685df48d  sub rsp, 0xF0
00007a40685df494  vmovaps [rsp], xmm0
00007a40685df499  vmovaps [rsp+0x10], xmm1
00007a40685df49f  vmovaps [rsp+0x20], xmm2
00007a40685df4a5  vmovaps [rsp+0x30], xmm3
00007a40685df4ab  vmovaps [rsp+0x40], xmm4
00007a40685df4b1  vmovaps [rsp+0x50], xmm5
00007a40685df4b7  vmovaps [rsp+0x60], xmm7
00007a40685df4bd  vmovaps [rsp+0x70], xmm8
00007a40685df4c3  vmovaps [rsp+0x80], xmm9
00007a40685df4cc  vmovaps [rsp+0x90], xmm10
00007a40685df4d5  vmovaps [rsp+0xA0], xmm11
00007a40685df4de  vmovaps [rsp+0xB0], xmm12
00007a40685df4e7  vmovaps [rsp+0xC0], xmm13
00007a40685df4f0  vmovaps [rsp+0xD0], xmm14
00007a40685df4f9  vmovaps [rsp+0xE0], xmm15
00007a40685df502  sub rsp, 0x30
00007a40685df506  movaps [rsp], xmm6
00007a40685df50a  movaps [rsp+0x10], xmm10
00007a40685df510  movaps [rsp+0x20], xmm8
00007a40685df516  lea rdi, [rsp]
00007a40685df51a  mov esi, 0x00
00007a40685df51f  mov rax, 0x56F679577530
00007a40685df529  call rax
00007a40685df52b  movaps xmm6, [rsp]
00007a40685df52f  add rsp, 0x30
00007a40685df533  vmovaps xmm0, [rsp]
00007a40685df538  vmovaps xmm1, [rsp+0x10]
00007a40685df53e  vmovaps xmm2, [rsp+0x20]
00007a40685df544  vmovaps xmm3, [rsp+0x30]
00007a40685df54a  vmovaps xmm4, [rsp+0x40]
00007a40685df550  vmovaps xmm5, [rsp+0x50]
00007a40685df556  vmovaps xmm7, [rsp+0x60]
00007a40685df55c  vmovaps xmm8, [rsp+0x70]
00007a40685df562  vmovaps xmm9, [rsp+0x80]
00007a40685df56b  vmovaps xmm10, [rsp+0x90]
00007a40685df574  vmovaps xmm11, [rsp+0xA0]
00007a40685df57d  vmovaps xmm12, [rsp+0xB0]
00007a40685df586  vmovaps xmm13, [rsp+0xC0]
00007a40685df58f  vmovaps xmm14, [rsp+0xD0]
00007a40685df598  vmovaps xmm15, [rsp+0xE0]
00007a40685df5a1  add rsp, 0xF0
00007a40685df5a8  pop r11
00007a40685df5aa  pop r10
00007a40685df5ac  pop r9
00007a40685df5ae  pop r8
00007a40685df5b0  pop rsi
00007a40685df5b1  pop rdi
00007a40685df5b2  pop rdx
00007a40685df5b3  pop rcx
00007a40685df5b4  pop rax
00007a40685df5b5  add rsp, 0x08
00007a40685df5b9  jmp 0x00007A40685DC3D8
00007a40685df5be  sub rsp, 0x08
00007a40685df5c2  push rax
00007a40685df5c3  push rcx
00007a40685df5c4  push rdx
00007a40685df5c5  push rdi
00007a40685df5c6  push rsi
00007a40685df5c7  push r8
00007a40685df5c9  push r9
00007a40685df5cb  push r10
00007a40685df5cd  push r11
00007a40685df5cf  sub rsp, 0xF0
00007a40685df5d6  vmovaps [rsp], xmm0
00007a40685df5db  vmovaps [rsp+0x10], xmm1
00007a40685df5e1  vmovaps [rsp+0x20], xmm2
00007a40685df5e7  vmovaps [rsp+0x30], xmm3
00007a40685df5ed  vmovaps [rsp+0x40], xmm4
00007a40685df5f3  vmovaps [rsp+0x50], xmm5
00007a40685df5f9  vmovaps [rsp+0x60], xmm6
00007a40685df5ff  vmovaps [rsp+0x70], xmm7
00007a40685df605  vmovaps [rsp+0x80], xmm8
00007a40685df60e  vmovaps [rsp+0x90], xmm9
00007a40685df617  vmovaps [rsp+0xA0], xmm11
00007a40685df620  vmovaps [rsp+0xB0], xmm12
00007a40685df629  vmovaps [rsp+0xC0], xmm13
00007a40685df632  vmovaps [rsp+0xD0], xmm14
00007a40685df63b  vmovaps [rsp+0xE0], xmm15
00007a40685df644  sub rsp, 0x30
00007a40685df648  movaps [rsp], xmm10
00007a40685df64d  movaps [rsp+0x10], xmm8
00007a40685df653  movaps [rsp+0x20], xmm14
00007a40685df659  lea rdi, [rsp]
00007a40685df65d  mov esi, 0x00
00007a40685df662  mov rax, 0x56F679577530
00007a40685df66c  call rax
00007a40685df66e  movaps xmm10, [rsp]
00007a40685df673  add rsp, 0x30
00007a40685df677  vmovaps xmm0, [rsp]
00007a40685df67c  vmovaps xmm1, [rsp+0x10]
00007a40685df682  vmovaps xmm2, [rsp+0x20]
00007a40685df688  vmovaps xmm3, [rsp+0x30]
00007a40685df68e  vmovaps xmm4, [rsp+0x40]
00007a40685df694  vmovaps xmm5, [rsp+0x50]
00007a40685df69a  vmovaps xmm6, [rsp+0x60]
00007a40685df6a0  vmovaps xmm7, [rsp+0x70]
00007a40685df6a6  vmovaps xmm8, [rsp+0x80]
00007a40685df6af  vmovaps xmm9, [rsp+0x90]
00007a40685df6b8  vmovaps xmm11, [rsp+0xA0]
00007a40685df6c1  vmovaps xmm12, [rsp+0xB0]
00007a40685df6ca  vmovaps xmm13, [rsp+0xC0]
00007a40685df6d3  vmovaps xmm14, [rsp+0xD0]
00007a40685df6dc  vmovaps xmm15, [rsp+0xE0]
00007a40685df6e5  add rsp, 0xF0
00007a40685df6ec  pop r11
00007a40685df6ee  pop r10
00007a40685df6f0  pop r9
00007a40685df6f2  pop r8
00007a40685df6f4  pop rsi
00007a40685df6f5  pop rdi
00007a40685df6f6  pop rdx
00007a40685df6f7  pop rcx
00007a40685df6f8  pop rax
00007a40685df6f9  add rsp, 0x08
00007a40685df6fd  jmp 0x00007A40685DC3F8
00007a40685df702  sub rsp, 0x08
00007a40685df706  push rax
00007a40685df707  push rcx
00007a40685df708  push rdx
00007a40685df709  push rdi
00007a40685df70a  push rsi
00007a40685df70b  push r8
00007a40685df70d  push r9
00007a40685df70f  push r10
00007a40685df711  push r11
00007a40685df713  sub rsp, 0xF0
00007a40685df71a  vmovaps [rsp], xmm0
00007a40685df71f  vmovaps [rsp+0x10], xmm1
00007a40685df725  vmovaps [rsp+0x20], xmm2
00007a40685df72b  vmovaps [rsp+0x30], xmm3
00007a40685df731  vmovaps [rsp+0x40], xmm4
00007a40685df737  vmovaps [rsp+0x50], xmm5
00007a40685df73d  vmovaps [rsp+0x60], xmm6
00007a40685df743  vmovaps [rsp+0x70], xmm7
00007a40685df749  vmovaps [rsp+0x80], xmm8
00007a40685df752  vmovaps [rsp+0x90], xmm9
00007a40685df75b  vmovaps [rsp+0xA0], xmm10
00007a40685df764  vmovaps [rsp+0xB0], xmm11
00007a40685df76d  vmovaps [rsp+0xC0], xmm12
00007a40685df776  vmovaps [rsp+0xD0], xmm13
00007a40685df77f  vmovaps [rsp+0xE0], xmm15
00007a40685df788  sub rsp, 0x30
00007a40685df78c  movaps [rsp], xmm14
00007a40685df791  movaps [rsp+0x10], xmm8
00007a40685df797  movaps [rsp+0x20], xmm4
00007a40685df79c  lea rdi, [rsp]
00007a40685df7a0  mov esi, 0x00
00007a40685df7a5  mov rax, 0x56F679577530
00007a40685df7af  call rax
00007a40685df7b1  movaps xmm14, [rsp]
00007a40685df7b6  add rsp, 0x30
00007a40685df7ba  vmovaps xmm0, [rsp]
00007a40685df7bf  vmovaps xmm1, [rsp+0x10]
00007a40685df7c5  vmovaps xmm2, [rsp+0x20]
00007a40685df7cb  vmovaps xmm3, [rsp+0x30]
00007a40685df7d1  vmovaps xmm4, [rsp+0x40]
00007a40685df7d7  vmovaps xmm5, [rsp+0x50]
00007a40685df7dd  vmovaps xmm6, [rsp+0x60]
00007a40685df7e3  vmovaps xmm7, [rsp+0x70]
00007a40685df7e9  vmovaps xmm8, [rsp+0x80]
00007a40685df7f2  vmovaps xmm9, [rsp+0x90]
00007a40685df7fb  vmovaps xmm10, [rsp+0xA0]
00007a40685df804  vmovaps xmm11, [rsp+0xB0]
00007a40685df80d  vmovaps xmm12, [rsp+0xC0]
00007a40685df816  vmovaps xmm13, [rsp+0xD0]
00007a40685df81f  vmovaps xmm15, [rsp+0xE0]
00007a40685df828  add rsp, 0xF0
00007a40685df82f  pop r11
00007a40685df831  pop r10
00007a40685df833  pop r9
00007a40685df835  pop r8
00007a40685df837  pop rsi
00007a40685df838  pop rdi
00007a40685df839  pop rdx
00007a40685df83a  pop rcx
00007a40685df83b  pop rax
00007a40685df83c  add rsp, 0x08
00007a40685df840  jmp 0x00007A40685DC418
00007a40685df845  sub rsp, 0x08
00007a40685df849  push rax
00007a40685df84a  push rcx
00007a40685df84b  push rdx
00007a40685df84c  push rdi
00007a40685df84d  push rsi
00007a40685df84e  push r8
00007a40685df850  push r9
00007a40685df852  push r10
00007a40685df854  push r11
00007a40685df856  sub rsp, 0xF0
00007a40685df85d  vmovaps [rsp], xmm0
00007a40685df862  vmovaps [rsp+0x10], xmm1
00007a40685df868  vmovaps [rsp+0x20], xmm2
00007a40685df86e  vmovaps [rsp+0x30], xmm3
00007a40685df874  vmovaps [rsp+0x40], xmm5
00007a40685df87a  vmovaps [rsp+0x50], xmm6
00007a40685df880  vmovaps [rsp+0x60], xmm7
00007a40685df886  vmovaps [rsp+0x70], xmm8
00007a40685df88c  vmovaps [rsp+0x80], xmm9
00007a40685df895  vmovaps [rsp+0x90], xmm10
00007a40685df89e  vmovaps [rsp+0xA0], xmm11
00007a40685df8a7  vmovaps [rsp+0xB0], xmm12
00007a40685df8b0  vmovaps [rsp+0xC0], xmm13
00007a40685df8b9  vmovaps [rsp+0xD0], xmm14
00007a40685df8c2  vmovaps [rsp+0xE0], xmm15
00007a40685df8cb  sub rsp, 0x30
00007a40685df8cf  movaps [rsp], xmm4
00007a40685df8d3  movaps [rsp+0x10], xmm13
00007a40685df8d9  movaps [rsp+0x20], xmm8
00007a40685df8df  lea rdi, [rsp]
00007a40685df8e3  mov esi, 0x00
00007a40685df8e8  mov rax, 0x56F679577530
00007a40685df8f2  call rax
00007a40685df8f4  movaps xmm4, [rsp]
00007a40685df8f8  add rsp, 0x30
00007a40685df8fc  vmovaps xmm0, [rsp]
00007a40685df901  vmovaps xmm1, [rsp+0x10]
00007a40685df907  vmovaps xmm2, [rsp+0x20]
00007a40685df90d  vmovaps xmm3, [rsp+0x30]
00007a40685df913  vmovaps xmm5, [rsp+0x40]
00007a40685df919  vmovaps xmm6, [rsp+0x50]
00007a40685df91f  vmovaps xmm7, [rsp+0x60]
00007a40685df925  vmovaps xmm8, [rsp+0x70]
00007a40685df92b  vmovaps xmm9, [rsp+0x80]
00007a40685df934  vmovaps xmm10, [rsp+0x90]
00007a40685df93d  vmovaps xmm11, [rsp+0xA0]
00007a40685df946  vmovaps xmm12, [rsp+0xB0]
00007a40685df94f  vmovaps xmm13, [rsp+0xC0]
00007a40685df958  vmovaps xmm14, [rsp+0xD0]
00007a40685df961  vmovaps xmm15, [rsp+0xE0]
00007a40685df96a  add rsp, 0xF0
00007a40685df971  pop r11
00007a40685df973  pop r10
00007a40685df975  pop r9
00007a40685df977  pop r8
00007a40685df979  pop rsi
00007a40685df97a  pop rdi
00007a40685df97b  pop rdx
00007a40685df97c  pop rcx
00007a40685df97d  pop rax
00007a40685df97e  add rsp, 0x08
00007a40685df982  jmp 0x00007A40685DC43D
00007a40685df987  sub rsp, 0x08
00007a40685df98b  push rax
00007a40685df98c  push rcx
00007a40685df98d  push rdx
00007a40685df98e  push rdi
00007a40685df98f  push rsi
00007a40685df990  push r8
00007a40685df992  push r9
00007a40685df994  push r10
00007a40685df996  push r11
00007a40685df998  sub rsp, 0xF0
00007a40685df99f  vmovaps [rsp], xmm0
00007a40685df9a4  vmovaps [rsp+0x10], xmm1
00007a40685df9aa  vmovaps [rsp+0x20], xmm2
00007a40685df9b0  vmovaps [rsp+0x30], xmm3
00007a40685df9b6  vmovaps [rsp+0x40], xmm4
00007a40685df9bc  vmovaps [rsp+0x50], xmm5
00007a40685df9c2  vmovaps [rsp+0x60], xmm6
00007a40685df9c8  vmovaps [rsp+0x70], xmm7
00007a40685df9ce  vmovaps [rsp+0x80], xmm8
00007a40685df9d7  vmovaps [rsp+0x90], xmm9
00007a40685df9e0  vmovaps [rsp+0xA0], xmm10
00007a40685df9e9  vmovaps [rsp+0xB0], xmm11
00007a40685df9f2  vmovaps [rsp+0xC0], xmm12
00007a40685df9fb  vmovaps [rsp+0xD0], xmm14
00007a40685dfa04  vmovaps [rsp+0xE0], xmm15
00007a40685dfa0d  sub rsp, 0x30
00007a40685dfa11  movaps [rsp], xmm13
00007a40685dfa16  movaps [rsp+0x10], xmm15
00007a40685dfa1c  movaps [rsp+0x20], xmm9
00007a40685dfa22  lea rdi, [rsp]
00007a40685dfa26  mov esi, 0x00
00007a40685dfa2b  mov rax, 0x56F679577530
00007a40685dfa35  call rax
00007a40685dfa37  movaps xmm13, [rsp]
00007a40685dfa3c  add rsp, 0x30
00007a40685dfa40  vmovaps xmm0, [rsp]
00007a40685dfa45  vmovaps xmm1, [rsp+0x10]
00007a40685dfa4b  vmovaps xmm2, [rsp+0x20]
00007a40685dfa51  vmovaps xmm3, [rsp+0x30]
00007a40685dfa57  vmovaps xmm4, [rsp+0x40]
00007a40685dfa5d  vmovaps xmm5, [rsp+0x50]
00007a40685dfa63  vmovaps xmm6, [rsp+0x60]
00007a40685dfa69  vmovaps xmm7, [rsp+0x70]
00007a40685dfa6f  vmovaps xmm8, [rsp+0x80]
00007a40685dfa78  vmovaps xmm9, [rsp+0x90]
00007a40685dfa81  vmovaps xmm10, [rsp+0xA0]
00007a40685dfa8a  vmovaps xmm11, [rsp+0xB0]
00007a40685dfa93  vmovaps xmm12, [rsp+0xC0]
00007a40685dfa9c  vmovaps xmm14, [rsp+0xD0]
00007a40685dfaa5  vmovaps xmm15, [rsp+0xE0]
00007a40685dfaae  add rsp, 0xF0
00007a40685dfab5  pop r11
00007a40685dfab7  pop r10
00007a40685dfab9  pop r9
00007a40685dfabb  pop r8
00007a40685dfabd  pop rsi
00007a40685dfabe  pop rdi
00007a40685dfabf  pop rdx
00007a40685dfac0  pop rcx
00007a40685dfac1  pop rax
00007a40685dfac2  add rsp, 0x08
00007a40685dfac6  jmp 0x00007A40685DC458
00007a40685dfacb  sub rsp, 0x08
00007a40685dfacf  push rax
00007a40685dfad0  push rcx
00007a40685dfad1  push rdx
00007a40685dfad2  push rdi
00007a40685dfad3  push rsi
00007a40685dfad4  push r8
00007a40685dfad6  push r9
00007a40685dfad8  push r10
00007a40685dfada  push r11
00007a40685dfadc  sub rsp, 0xF0
00007a40685dfae3  vmovaps [rsp], xmm0
00007a40685dfae8  vmovaps [rsp+0x10], xmm1
00007a40685dfaee  vmovaps [rsp+0x20], xmm2
00007a40685dfaf4  vmovaps [rsp+0x30], xmm3
00007a40685dfafa  vmovaps [rsp+0x40], xmm4
00007a40685dfb00  vmovaps [rsp+0x50], xmm5
00007a40685dfb06  vmovaps [rsp+0x60], xmm6
00007a40685dfb0c  vmovaps [rsp+0x70], xmm7
00007a40685dfb12  vmovaps [rsp+0x80], xmm8
00007a40685dfb1b  vmovaps [rsp+0x90], xmm9
00007a40685dfb24  vmovaps [rsp+0xA0], xmm10
00007a40685dfb2d  vmovaps [rsp+0xB0], xmm11
00007a40685dfb36  vmovaps [rsp+0xC0], xmm12
00007a40685dfb3f  vmovaps [rsp+0xD0], xmm13
00007a40685dfb48  vmovaps [rsp+0xE0], xmm14
00007a40685dfb51  sub rsp, 0x30
00007a40685dfb55  movaps [rsp], xmm15
00007a40685dfb5a  movaps [rsp+0x10], xmm1
00007a40685dfb5f  movaps [rsp+0x20], xmm5
00007a40685dfb64  lea rdi, [rsp]
00007a40685dfb68  mov esi, 0x00
00007a40685dfb6d  mov rax, 0x56F679577530
00007a40685dfb77  call rax
00007a40685dfb79  movaps xmm15, [rsp]
00007a40685dfb7e  add rsp, 0x30
00007a40685dfb82  vmovaps xmm0, [rsp]
00007a40685dfb87  vmovaps xmm1, [rsp+0x10]
00007a40685dfb8d  vmovaps xmm2, [rsp+0x20]
00007a40685dfb93  vmovaps xmm3, [rsp+0x30]
00007a40685dfb99  vmovaps xmm4, [rsp+0x40]
00007a40685dfb9f  vmovaps xmm5, [rsp+0x50]
00007a40685dfba5  vmovaps xmm6, [rsp+0x60]
00007a40685dfbab  vmovaps xmm7, [rsp+0x70]
00007a40685dfbb1  vmovaps xmm8, [rsp+0x80]
00007a40685dfbba  vmovaps xmm9, [rsp+0x90]
00007a40685dfbc3  vmovaps xmm10, [rsp+0xA0]
00007a40685dfbcc  vmovaps xmm11, [rsp+0xB0]
00007a40685dfbd5  vmovaps xmm12, [rsp+0xC0]
00007a40685dfbde  vmovaps xmm13, [rsp+0xD0]
00007a40685dfbe7  vmovaps xmm14, [rsp+0xE0]
00007a40685dfbf0  add rsp, 0xF0
00007a40685dfbf7  pop r11
00007a40685dfbf9  pop r10
00007a40685dfbfb  pop r9
00007a40685dfbfd  pop r8
00007a40685dfbff  pop rsi
00007a40685dfc00  pop rdi
00007a40685dfc01  pop rdx
00007a40685dfc02  pop rcx
00007a40685dfc03  pop rax
00007a40685dfc04  add rsp, 0x08
00007a40685dfc08  jmp 0x00007A40685DC473
00007a40685dfc0d  call 0x00007A40684B52F0
00007a40685dfc12  jmp 0x00007A40685DC4CE
00007a40685dfc17  sub rsp, 0x08
00007a40685dfc1b  push rax
00007a40685dfc1c  push rcx
00007a40685dfc1d  push rdx
00007a40685dfc1e  push rdi
00007a40685dfc1f  push rsi
00007a40685dfc20  push r8
00007a40685dfc22  push r9
00007a40685dfc24  push r10
00007a40685dfc26  push r11
00007a40685dfc28  sub rsp, 0xF0
00007a40685dfc2f  vmovaps [rsp], xmm0
00007a40685dfc34  vmovaps [rsp+0x10], xmm1
00007a40685dfc3a  vmovaps [rsp+0x20], xmm2
00007a40685dfc40  vmovaps [rsp+0x30], xmm3
00007a40685dfc46  vmovaps [rsp+0x40], xmm4
00007a40685dfc4c  vmovaps [rsp+0x50], xmm5
00007a40685dfc52  vmovaps [rsp+0x60], xmm6
00007a40685dfc58  vmovaps [rsp+0x70], xmm7
00007a40685dfc5e  vmovaps [rsp+0x80], xmm8
00007a40685dfc67  vmovaps [rsp+0x90], xmm10
00007a40685dfc70  vmovaps [rsp+0xA0], xmm11
00007a40685dfc79  vmovaps [rsp+0xB0], xmm12
00007a40685dfc82  vmovaps [rsp+0xC0], xmm13
00007a40685dfc8b  vmovaps [rsp+0xD0], xmm14
00007a40685dfc94  vmovaps [rsp+0xE0], xmm15
00007a40685dfc9d  sub rsp, 0x30
00007a40685dfca1  movaps [rsp], xmm9
00007a40685dfca6  movaps [rsp+0x10], xmm8
00007a40685dfcac  movaps [rsp+0x20], xmm11
00007a40685dfcb2  lea rdi, [rsp]
00007a40685dfcb6  mov esi, 0x00
00007a40685dfcbb  mov rax, 0x56F679577530
00007a40685dfcc5  call rax
00007a40685dfcc7  movaps xmm9, [rsp]
00007a40685dfccc  add rsp, 0x30
00007a40685dfcd0  vmovaps xmm0, [rsp]
00007a40685dfcd5  vmovaps xmm1, [rsp+0x10]
00007a40685dfcdb  vmovaps xmm2, [rsp+0x20]
00007a40685dfce1  vmovaps xmm3, [rsp+0x30]
00007a40685dfce7  vmovaps xmm4, [rsp+0x40]
00007a40685dfced  vmovaps xmm5, [rsp+0x50]
00007a40685dfcf3  vmovaps xmm6, [rsp+0x60]
00007a40685dfcf9  vmovaps xmm7, [rsp+0x70]
00007a40685dfcff  vmovaps xmm8, [rsp+0x80]
00007a40685dfd08  vmovaps xmm10, [rsp+0x90]
00007a40685dfd11  vmovaps xmm11, [rsp+0xA0]
00007a40685dfd1a  vmovaps xmm12, [rsp+0xB0]
00007a40685dfd23  vmovaps xmm13, [rsp+0xC0]
00007a40685dfd2c  vmovaps xmm14, [rsp+0xD0]
00007a40685dfd35  vmovaps xmm15, [rsp+0xE0]
00007a40685dfd3e  add rsp, 0xF0
00007a40685dfd45  pop r11
00007a40685dfd47  pop r10
00007a40685dfd49  pop r9
00007a40685dfd4b  pop r8
00007a40685dfd4d  pop rsi
00007a40685dfd4e  pop rdi
00007a40685dfd4f  pop rdx
00007a40685dfd50  pop rcx
00007a40685dfd51  pop rax
00007a40685dfd52  add rsp, 0x08
00007a40685dfd56  jmp 0x00007A40685DC505
00007a40685dfd5b  sub rsp, 0x08
00007a40685dfd5f  push rax
00007a40685dfd60  push rcx
00007a40685dfd61  push rdx
00007a40685dfd62  push rdi
00007a40685dfd63  push rsi
00007a40685dfd64  push r8
00007a40685dfd66  push r9
00007a40685dfd68  push r10
00007a40685dfd6a  push r11
00007a40685dfd6c  sub rsp, 0xF0
00007a40685dfd73  vmovaps [rsp], xmm0
00007a40685dfd78  vmovaps [rsp+0x10], xmm1
00007a40685dfd7e  vmovaps [rsp+0x20], xmm2
00007a40685dfd84  vmovaps [rsp+0x30], xmm3
00007a40685dfd8a  vmovaps [rsp+0x40], xmm4
00007a40685dfd90  vmovaps [rsp+0x50], xmm5
00007a40685dfd96  vmovaps [rsp+0x60], xmm6
00007a40685dfd9c  vmovaps [rsp+0x70], xmm7
00007a40685dfda2  vmovaps [rsp+0x80], xmm8
00007a40685dfdab  vmovaps [rsp+0x90], xmm9
00007a40685dfdb4  vmovaps [rsp+0xA0], xmm10
00007a40685dfdbd  vmovaps [rsp+0xB0], xmm12
00007a40685dfdc6  vmovaps [rsp+0xC0], xmm13
00007a40685dfdcf  vmovaps [rsp+0xD0], xmm14
00007a40685dfdd8  vmovaps [rsp+0xE0], xmm15
00007a40685dfde1  sub rsp, 0x30
00007a40685dfde5  movaps [rsp], xmm11
00007a40685dfdea  movaps [rsp+0x10], xmm10
00007a40685dfdf0  movaps [rsp+0x20], xmm6
00007a40685dfdf5  lea rdi, [rsp]
00007a40685dfdf9  mov esi, 0x00
00007a40685dfdfe  mov rax, 0x56F679577530
00007a40685dfe08  call rax
00007a40685dfe0a  movaps xmm11, [rsp]
00007a40685dfe0f  add rsp, 0x30
00007a40685dfe13  vmovaps xmm0, [rsp]
00007a40685dfe18  vmovaps xmm1, [rsp+0x10]
00007a40685dfe1e  vmovaps xmm2, [rsp+0x20]
00007a40685dfe24  vmovaps xmm3, [rsp+0x30]
00007a40685dfe2a  vmovaps xmm4, [rsp+0x40]
00007a40685dfe30  vmovaps xmm5, [rsp+0x50]
00007a40685dfe36  vmovaps xmm6, [rsp+0x60]
00007a40685dfe3c  vmovaps xmm7, [rsp+0x70]
00007a40685dfe42  vmovaps xmm8, [rsp+0x80]
00007a40685dfe4b  vmovaps xmm9, [rsp+0x90]
00007a40685dfe54  vmovaps xmm10, [rsp+0xA0]
00007a40685dfe5d  vmovaps xmm12, [rsp+0xB0]
00007a40685dfe66  vmovaps xmm13, [rsp+0xC0]
00007a40685dfe6f  vmovaps xmm14, [rsp+0xD0]
00007a40685dfe78  vmovaps xmm15, [rsp+0xE0]
00007a40685dfe81  add rsp, 0xF0
00007a40685dfe88  pop r11
00007a40685dfe8a  pop r10
00007a40685dfe8c  pop r9
00007a40685dfe8e  pop r8
00007a40685dfe90  pop rsi
00007a40685dfe91  pop rdi
00007a40685dfe92  pop rdx
00007a40685dfe93  pop rcx
00007a40685dfe94  pop rax
00007a40685dfe95  add rsp, 0x08
00007a40685dfe99  jmp 0x00007A40685DC520
00007a40685dfe9e  sub rsp, 0x08
00007a40685dfea2  push rax
00007a40685dfea3  push rcx
00007a40685dfea4  push rdx
00007a40685dfea5  push rdi
00007a40685dfea6  push rsi
00007a40685dfea7  push r8
00007a40685dfea9  push r9
00007a40685dfeab  push r10
00007a40685dfead  push r11
00007a40685dfeaf  sub rsp, 0xF0
00007a40685dfeb6  vmovaps [rsp], xmm0
00007a40685dfebb  vmovaps [rsp+0x10], xmm1
00007a40685dfec1  vmovaps [rsp+0x20], xmm2
00007a40685dfec7  vmovaps [rsp+0x30], xmm3
00007a40685dfecd  vmovaps [rsp+0x40], xmm4
00007a40685dfed3  vmovaps [rsp+0x50], xmm5
00007a40685dfed9  vmovaps [rsp+0x60], xmm6
00007a40685dfedf  vmovaps [rsp+0x70], xmm7
00007a40685dfee5  vmovaps [rsp+0x80], xmm8
00007a40685dfeee  vmovaps [rsp+0x90], xmm9
00007a40685dfef7  vmovaps [rsp+0xA0], xmm11
00007a40685dff00  vmovaps [rsp+0xB0], xmm12
00007a40685dff09  vmovaps [rsp+0xC0], xmm13
00007a40685dff12  vmovaps [rsp+0xD0], xmm14
00007a40685dff1b  vmovaps [rsp+0xE0], xmm15
00007a40685dff24  sub rsp, 0x30
00007a40685dff28  movaps [rsp], xmm10
00007a40685dff2d  movaps [rsp+0x10], xmm14
00007a40685dff33  movaps [rsp+0x20], xmm4
00007a40685dff38  lea rdi, [rsp]
00007a40685dff3c  mov esi, 0x00
00007a40685dff41  mov rax, 0x56F679577530
00007a40685dff4b  call rax
00007a40685dff4d  movaps xmm10, [rsp]
00007a40685dff52  add rsp, 0x30
00007a40685dff56  vmovaps xmm0, [rsp]
00007a40685dff5b  vmovaps xmm1, [rsp+0x10]
00007a40685dff61  vmovaps xmm2, [rsp+0x20]
00007a40685dff67  vmovaps xmm3, [rsp+0x30]
00007a40685dff6d  vmovaps xmm4, [rsp+0x40]
00007a40685dff73  vmovaps xmm5, [rsp+0x50]
00007a40685dff79  vmovaps xmm6, [rsp+0x60]
00007a40685dff7f  vmovaps xmm7, [rsp+0x70]
00007a40685dff85  vmovaps xmm8, [rsp+0x80]
00007a40685dff8e  vmovaps xmm9, [rsp+0x90]
00007a40685dff97  vmovaps xmm11, [rsp+0xA0]
00007a40685dffa0  vmovaps xmm12, [rsp+0xB0]
00007a40685dffa9  vmovaps xmm13, [rsp+0xC0]
00007a40685dffb2  vmovaps xmm14, [rsp+0xD0]
00007a40685dffbb  vmovaps xmm15, [rsp+0xE0]
00007a40685dffc4  add rsp, 0xF0
00007a40685dffcb  pop r11
00007a40685dffcd  pop r10
00007a40685dffcf  pop r9
00007a40685dffd1  pop r8
00007a40685dffd3  pop rsi
00007a40685dffd4  pop rdi
00007a40685dffd5  pop rdx
00007a40685dffd6  pop rcx
00007a40685dffd7  pop rax
00007a40685dffd8  add rsp, 0x08
00007a40685dffdc  jmp 0x00007A40685DC53B
00007a40685dffe1  sub rsp, 0x08
00007a40685dffe5  push rax
00007a40685dffe6  push rcx
00007a40685dffe7  push rdx
00007a40685dffe8  push rdi
00007a40685dffe9  push rsi
00007a40685dffea  push r8
00007a40685dffec  push r9
00007a40685dffee  push r10
00007a40685dfff0  push r11
00007a40685dfff2  sub rsp, 0xF0
00007a40685dfff9  vmovaps [rsp], xmm0
00007a40685dfffe  vmovaps [rsp+0x10], xmm1
00007a40685e0004  vmovaps [rsp+0x20], xmm2
00007a40685e000a  vmovaps [rsp+0x30], xmm3
00007a40685e0010  vmovaps [rsp+0x40], xmm4
00007a40685e0016  vmovaps [rsp+0x50], xmm5
00007a40685e001c  vmovaps [rsp+0x60], xmm6
00007a40685e0022  vmovaps [rsp+0x70], xmm7
00007a40685e0028  vmovaps [rsp+0x80], xmm9
00007a40685e0031  vmovaps [rsp+0x90], xmm10
00007a40685e003a  vmovaps [rsp+0xA0], xmm11
00007a40685e0043  vmovaps [rsp+0xB0], xmm12
00007a40685e004c  vmovaps [rsp+0xC0], xmm13
00007a40685e0055  vmovaps [rsp+0xD0], xmm14
00007a40685e005e  vmovaps [rsp+0xE0], xmm15
00007a40685e0067  sub rsp, 0x30
00007a40685e006b  movaps [rsp], xmm8
00007a40685e0070  movaps [rsp+0x10], xmm1
00007a40685e0075  movaps [rsp+0x20], xmm14
00007a40685e007b  lea rdi, [rsp]
00007a40685e007f  mov esi, 0x00
00007a40685e0084  mov rax, 0x56F679577530
00007a40685e008e  call rax
00007a40685e0090  movaps xmm8, [rsp]
00007a40685e0095  add rsp, 0x30
00007a40685e0099  vmovaps xmm0, [rsp]
00007a40685e009e  vmovaps xmm1, [rsp+0x10]
00007a40685e00a4  vmovaps xmm2, [rsp+0x20]
00007a40685e00aa  vmovaps xmm3, [rsp+0x30]
00007a40685e00b0  vmovaps xmm4, [rsp+0x40]
00007a40685e00b6  vmovaps xmm5, [rsp+0x50]
00007a40685e00bc  vmovaps xmm6, [rsp+0x60]
00007a40685e00c2  vmovaps xmm7, [rsp+0x70]
00007a40685e00c8  vmovaps xmm9, [rsp+0x80]
00007a40685e00d1  vmovaps xmm10, [rsp+0x90]
00007a40685e00da  vmovaps xmm11, [rsp+0xA0]
00007a40685e00e3  vmovaps xmm12, [rsp+0xB0]
00007a40685e00ec  vmovaps xmm13, [rsp+0xC0]
00007a40685e00f5  vmovaps xmm14, [rsp+0xD0]
00007a40685e00fe  vmovaps xmm15, [rsp+0xE0]
00007a40685e0107  add rsp, 0xF0
00007a40685e010e  pop r11
00007a40685e0110  pop r10
00007a40685e0112  pop r9
00007a40685e0114  pop r8
00007a40685e0116  pop rsi
00007a40685e0117  pop rdi
00007a40685e0118  pop rdx
00007a40685e0119  pop rcx
00007a40685e011a  pop rax
00007a40685e011b  add rsp, 0x08
00007a40685e011f  jmp 0x00007A40685DC561
00007a40685e0124  sub rsp, 0x08
00007a40685e0128  push rax
00007a40685e0129  push rcx
00007a40685e012a  push rdx
00007a40685e012b  push rdi
00007a40685e012c  push rsi
00007a40685e012d  push r8
00007a40685e012f  push r9
00007a40685e0131  push r10
00007a40685e0133  push r11
00007a40685e0135  sub rsp, 0xF0
00007a40685e013c  vmovaps [rsp], xmm0
00007a40685e0141  vmovaps [rsp+0x10], xmm1
00007a40685e0147  vmovaps [rsp+0x20], xmm2
00007a40685e014d  vmovaps [rsp+0x30], xmm3
00007a40685e0153  vmovaps [rsp+0x40], xmm4
00007a40685e0159  vmovaps [rsp+0x50], xmm5
00007a40685e015f  vmovaps [rsp+0x60], xmm7
00007a40685e0165  vmovaps [rsp+0x70], xmm8
00007a40685e016b  vmovaps [rsp+0x80], xmm9
00007a40685e0174  vmovaps [rsp+0x90], xmm10
00007a40685e017d  vmovaps [rsp+0xA0], xmm11
00007a40685e0186  vmovaps [rsp+0xB0], xmm12
00007a40685e018f  vmovaps [rsp+0xC0], xmm13
00007a40685e0198  vmovaps [rsp+0xD0], xmm14
00007a40685e01a1  vmovaps [rsp+0xE0], xmm15
00007a40685e01aa  sub rsp, 0x30
00007a40685e01ae  movaps [rsp], xmm6
00007a40685e01b2  movaps [rsp+0x10], xmm1
00007a40685e01b7  movaps [rsp+0x20], xmm14
00007a40685e01bd  lea rdi, [rsp]
00007a40685e01c1  mov esi, 0x00
00007a40685e01c6  mov rax, 0x56F679577530
00007a40685e01d0  call rax
00007a40685e01d2  movaps xmm6, [rsp]
00007a40685e01d6  add rsp, 0x30
00007a40685e01da  vmovaps xmm0, [rsp]
00007a40685e01df  vmovaps xmm1, [rsp+0x10]
00007a40685e01e5  vmovaps xmm2, [rsp+0x20]
00007a40685e01eb  vmovaps xmm3, [rsp+0x30]
00007a40685e01f1  vmovaps xmm4, [rsp+0x40]
00007a40685e01f7  vmovaps xmm5, [rsp+0x50]
00007a40685e01fd  vmovaps xmm7, [rsp+0x60]
00007a40685e0203  vmovaps xmm8, [rsp+0x70]
00007a40685e0209  vmovaps xmm9, [rsp+0x80]
00007a40685e0212  vmovaps xmm10, [rsp+0x90]
00007a40685e021b  vmovaps xmm11, [rsp+0xA0]
00007a40685e0224  vmovaps xmm12, [rsp+0xB0]
00007a40685e022d  vmovaps xmm13, [rsp+0xC0]
00007a40685e0236  vmovaps xmm14, [rsp+0xD0]
00007a40685e023f  vmovaps xmm15, [rsp+0xE0]
00007a40685e0248  add rsp, 0xF0
00007a40685e024f  pop r11
00007a40685e0251  pop r10
00007a40685e0253  pop r9
00007a40685e0255  pop r8
00007a40685e0257  pop rsi
00007a40685e0258  pop rdi
00007a40685e0259  pop rdx
00007a40685e025a  pop rcx
00007a40685e025b  pop rax
00007a40685e025c  add rsp, 0x08
00007a40685e0260  jmp 0x00007A40685DC58D
00007a40685e0265  sub rsp, 0x08
00007a40685e0269  push rax
00007a40685e026a  push rcx
00007a40685e026b  push rdx
00007a40685e026c  push rdi
00007a40685e026d  push rsi
00007a40685e026e  push r8
00007a40685e0270  push r9
00007a40685e0272  push r10
00007a40685e0274  push r11
00007a40685e0276  sub rsp, 0xF0
00007a40685e027d  vmovaps [rsp], xmm0
00007a40685e0282  vmovaps [rsp+0x10], xmm1
00007a40685e0288  vmovaps [rsp+0x20], xmm2
00007a40685e028e  vmovaps [rsp+0x30], xmm3
00007a40685e0294  vmovaps [rsp+0x40], xmm4
00007a40685e029a  vmovaps [rsp+0x50], xmm5
00007a40685e02a0  vmovaps [rsp+0x60], xmm6
00007a40685e02a6  vmovaps [rsp+0x70], xmm7
00007a40685e02ac  vmovaps [rsp+0x80], xmm8
00007a40685e02b5  vmovaps [rsp+0x90], xmm9
00007a40685e02be  vmovaps [rsp+0xA0], xmm10
00007a40685e02c7  vmovaps [rsp+0xB0], xmm11
00007a40685e02d0  vmovaps [rsp+0xC0], xmm12
00007a40685e02d9  vmovaps [rsp+0xD0], xmm13
00007a40685e02e2  vmovaps [rsp+0xE0], xmm15
00007a40685e02eb  sub rsp, 0x30
00007a40685e02ef  movaps [rsp], xmm14
00007a40685e02f4  movaps [rsp+0x10], xmm12
00007a40685e02fa  movaps [rsp+0x20], xmm1
00007a40685e02ff  lea rdi, [rsp]
00007a40685e0303  mov esi, 0x00
00007a40685e0308  mov rax, 0x56F679577530
00007a40685e0312  call rax
00007a40685e0314  movaps xmm14, [rsp]
00007a40685e0319  add rsp, 0x30
00007a40685e031d  vmovaps xmm0, [rsp]
00007a40685e0322  vmovaps xmm1, [rsp+0x10]
00007a40685e0328  vmovaps xmm2, [rsp+0x20]
00007a40685e032e  vmovaps xmm3, [rsp+0x30]
00007a40685e0334  vmovaps xmm4, [rsp+0x40]
00007a40685e033a  vmovaps xmm5, [rsp+0x50]
00007a40685e0340  vmovaps xmm6, [rsp+0x60]
00007a40685e0346  vmovaps xmm7, [rsp+0x70]
00007a40685e034c  vmovaps xmm8, [rsp+0x80]
00007a40685e0355  vmovaps xmm9, [rsp+0x90]
00007a40685e035e  vmovaps xmm10, [rsp+0xA0]
00007a40685e0367  vmovaps xmm11, [rsp+0xB0]
00007a40685e0370  vmovaps xmm12, [rsp+0xC0]
00007a40685e0379  vmovaps xmm13, [rsp+0xD0]
00007a40685e0382  vmovaps xmm15, [rsp+0xE0]
00007a40685e038b  add rsp, 0xF0
00007a40685e0392  pop r11
00007a40685e0394  pop r10
00007a40685e0396  pop r9
00007a40685e0398  pop r8
00007a40685e039a  pop rsi
00007a40685e039b  pop rdi
00007a40685e039c  pop rdx
00007a40685e039d  pop rcx
00007a40685e039e  pop rax
00007a40685e039f  add rsp, 0x08
00007a40685e03a3  jmp 0x00007A40685DC5B3
00007a40685e03a8  sub rsp, 0x08
00007a40685e03ac  push rax
00007a40685e03ad  push rcx
00007a40685e03ae  push rdx
00007a40685e03af  push rdi
00007a40685e03b0  push rsi
00007a40685e03b1  push r8
00007a40685e03b3  push r9
00007a40685e03b5  push r10
00007a40685e03b7  push r11
00007a40685e03b9  sub rsp, 0xF0
00007a40685e03c0  vmovaps [rsp], xmm0
00007a40685e03c5  vmovaps [rsp+0x10], xmm2
00007a40685e03cb  vmovaps [rsp+0x20], xmm3
00007a40685e03d1  vmovaps [rsp+0x30], xmm4
00007a40685e03d7  vmovaps [rsp+0x40], xmm5
00007a40685e03dd  vmovaps [rsp+0x50], xmm6
00007a40685e03e3  vmovaps [rsp+0x60], xmm7
00007a40685e03e9  vmovaps [rsp+0x70], xmm8
00007a40685e03ef  vmovaps [rsp+0x80], xmm9
00007a40685e03f8  vmovaps [rsp+0x90], xmm10
00007a40685e0401  vmovaps [rsp+0xA0], xmm11
00007a40685e040a  vmovaps [rsp+0xB0], xmm12
00007a40685e0413  vmovaps [rsp+0xC0], xmm13
00007a40685e041c  vmovaps [rsp+0xD0], xmm14
00007a40685e0425  vmovaps [rsp+0xE0], xmm15
00007a40685e042e  sub rsp, 0x30
00007a40685e0432  movaps [rsp], xmm1
00007a40685e0436  movaps [rsp+0x10], xmm13
00007a40685e043c  movaps [rsp+0x20], xmm9
00007a40685e0442  lea rdi, [rsp]
00007a40685e0446  mov esi, 0x00
00007a40685e044b  mov rax, 0x56F679577530
00007a40685e0455  call rax
00007a40685e0457  movaps xmm1, [rsp]
00007a40685e045b  add rsp, 0x30
00007a40685e045f  vmovaps xmm0, [rsp]
00007a40685e0464  vmovaps xmm2, [rsp+0x10]
00007a40685e046a  vmovaps xmm3, [rsp+0x20]
00007a40685e0470  vmovaps xmm4, [rsp+0x30]
00007a40685e0476  vmovaps xmm5, [rsp+0x40]
00007a40685e047c  vmovaps xmm6, [rsp+0x50]
00007a40685e0482  vmovaps xmm7, [rsp+0x60]
00007a40685e0488  vmovaps xmm8, [rsp+0x70]
00007a40685e048e  vmovaps xmm9, [rsp+0x80]
00007a40685e0497  vmovaps xmm10, [rsp+0x90]
00007a40685e04a0  vmovaps xmm11, [rsp+0xA0]
00007a40685e04a9  vmovaps xmm12, [rsp+0xB0]
00007a40685e04b2  vmovaps xmm13, [rsp+0xC0]
00007a40685e04bb  vmovaps xmm14, [rsp+0xD0]
00007a40685e04c4  vmovaps xmm15, [rsp+0xE0]
00007a40685e04cd  add rsp, 0xF0
00007a40685e04d4  pop r11
00007a40685e04d6  pop r10
00007a40685e04d8  pop r9
00007a40685e04da  pop r8
00007a40685e04dc  pop rsi
00007a40685e04dd  pop rdi
00007a40685e04de  pop rdx
00007a40685e04df  pop rcx
00007a40685e04e0  pop rax
00007a40685e04e1  add rsp, 0x08
00007a40685e04e5  jmp 0x00007A40685DC5CD
00007a40685e04ea  sub rsp, 0x08
00007a40685e04ee  push rax
00007a40685e04ef  push rcx
00007a40685e04f0  push rdx
00007a40685e04f1  push rdi
00007a40685e04f2  push rsi
00007a40685e04f3  push r8
00007a40685e04f5  push r9
00007a40685e04f7  push r10
00007a40685e04f9  push r11
00007a40685e04fb  sub rsp, 0xF0
00007a40685e0502  vmovaps [rsp], xmm0
00007a40685e0507  vmovaps [rsp+0x10], xmm1
00007a40685e050d  vmovaps [rsp+0x20], xmm2
00007a40685e0513  vmovaps [rsp+0x30], xmm3
00007a40685e0519  vmovaps [rsp+0x40], xmm4
00007a40685e051f  vmovaps [rsp+0x50], xmm5
00007a40685e0525  vmovaps [rsp+0x60], xmm6
00007a40685e052b  vmovaps [rsp+0x70], xmm7
00007a40685e0531  vmovaps [rsp+0x80], xmm8
00007a40685e053a  vmovaps [rsp+0x90], xmm9
00007a40685e0543  vmovaps [rsp+0xA0], xmm10
00007a40685e054c  vmovaps [rsp+0xB0], xmm11
00007a40685e0555  vmovaps [rsp+0xC0], xmm13
00007a40685e055e  vmovaps [rsp+0xD0], xmm14
00007a40685e0567  vmovaps [rsp+0xE0], xmm15
00007a40685e0570  sub rsp, 0x30
00007a40685e0574  movaps [rsp], xmm12
00007a40685e0579  movaps [rsp+0x10], xmm7
00007a40685e057e  movaps [rsp+0x20], xmm13
00007a40685e0584  lea rdi, [rsp]
00007a40685e0588  mov esi, 0x00
00007a40685e058d  mov rax, 0x56F679577530
00007a40685e0597  call rax
00007a40685e0599  movaps xmm12, [rsp]
00007a40685e059e  add rsp, 0x30
00007a40685e05a2  vmovaps xmm0, [rsp]
00007a40685e05a7  vmovaps xmm1, [rsp+0x10]
00007a40685e05ad  vmovaps xmm2, [rsp+0x20]
00007a40685e05b3  vmovaps xmm3, [rsp+0x30]
00007a40685e05b9  vmovaps xmm4, [rsp+0x40]
00007a40685e05bf  vmovaps xmm5, [rsp+0x50]
00007a40685e05c5  vmovaps xmm6, [rsp+0x60]
00007a40685e05cb  vmovaps xmm7, [rsp+0x70]
00007a40685e05d1  vmovaps xmm8, [rsp+0x80]
00007a40685e05da  vmovaps xmm9, [rsp+0x90]
00007a40685e05e3  vmovaps xmm10, [rsp+0xA0]
00007a40685e05ec  vmovaps xmm11, [rsp+0xB0]
00007a40685e05f5  vmovaps xmm13, [rsp+0xC0]
00007a40685e05fe  vmovaps xmm14, [rsp+0xD0]
00007a40685e0607  vmovaps xmm15, [rsp+0xE0]
00007a40685e0610  add rsp, 0xF0
00007a40685e0617  pop r11
00007a40685e0619  pop r10
00007a40685e061b  pop r9
00007a40685e061d  pop r8
00007a40685e061f  pop rsi
00007a40685e0620  pop rdi
00007a40685e0621  pop rdx
00007a40685e0622  pop rcx
00007a40685e0623  pop rax
00007a40685e0624  add rsp, 0x08
00007a40685e0628  jmp 0x00007A40685DC5F4
00007a40685e062d  sub rsp, 0x08
00007a40685e0631  push rax
00007a40685e0632  push rcx
00007a40685e0633  push rdx
00007a40685e0634  push rdi
00007a40685e0635  push rsi
00007a40685e0636  push r8
00007a40685e0638  push r9
00007a40685e063a  push r10
00007a40685e063c  push r11
00007a40685e063e  sub rsp, 0xF0
00007a40685e0645  vmovaps [rsp], xmm0
00007a40685e064a  vmovaps [rsp+0x10], xmm1
00007a40685e0650  vmovaps [rsp+0x20], xmm2
00007a40685e0656  vmovaps [rsp+0x30], xmm3
00007a40685e065c  vmovaps [rsp+0x40], xmm4
00007a40685e0662  vmovaps [rsp+0x50], xmm5
00007a40685e0668  vmovaps [rsp+0x60], xmm6
00007a40685e066e  vmovaps [rsp+0x70], xmm7
00007a40685e0674  vmovaps [rsp+0x80], xmm8
00007a40685e067d  vmovaps [rsp+0x90], xmm9
00007a40685e0686  vmovaps [rsp+0xA0], xmm10
00007a40685e068f  vmovaps [rsp+0xB0], xmm11
00007a40685e0698  vmovaps [rsp+0xC0], xmm12
00007a40685e06a1  vmovaps [rsp+0xD0], xmm14
00007a40685e06aa  vmovaps [rsp+0xE0], xmm15
00007a40685e06b3  sub rsp, 0x30
00007a40685e06b7  movaps [rsp], xmm13
00007a40685e06bc  movaps [rsp+0x10], xmm15
00007a40685e06c2  movaps [rsp+0x20], xmm8
00007a40685e06c8  lea rdi, [rsp]
00007a40685e06cc  mov esi, 0x00
00007a40685e06d1  mov rax, 0x56F679577530
00007a40685e06db  call rax
00007a40685e06dd  movaps xmm13, [rsp]
00007a40685e06e2  add rsp, 0x30
00007a40685e06e6  vmovaps xmm0, [rsp]
00007a40685e06eb  vmovaps xmm1, [rsp+0x10]
00007a40685e06f1  vmovaps xmm2, [rsp+0x20]
00007a40685e06f7  vmovaps xmm3, [rsp+0x30]
00007a40685e06fd  vmovaps xmm4, [rsp+0x40]
00007a40685e0703  vmovaps xmm5, [rsp+0x50]
00007a40685e0709  vmovaps xmm6, [rsp+0x60]
00007a40685e070f  vmovaps xmm7, [rsp+0x70]
00007a40685e0715  vmovaps xmm8, [rsp+0x80]
00007a40685e071e  vmovaps xmm9, [rsp+0x90]
00007a40685e0727  vmovaps xmm10, [rsp+0xA0]
00007a40685e0730  vmovaps xmm11, [rsp+0xB0]
00007a40685e0739  vmovaps xmm12, [rsp+0xC0]
00007a40685e0742  vmovaps xmm14, [rsp+0xD0]
00007a40685e074b  vmovaps xmm15, [rsp+0xE0]
00007a40685e0754  add rsp, 0xF0
00007a40685e075b  pop r11
00007a40685e075d  pop r10
00007a40685e075f  pop r9
00007a40685e0761  pop r8
00007a40685e0763  pop rsi
00007a40685e0764  pop rdi
00007a40685e0765  pop rdx
00007a40685e0766  pop rcx
00007a40685e0767  pop rax
00007a40685e0768  add rsp, 0x08
00007a40685e076c  jmp 0x00007A40685DC60F
00007a40685e0771  sub rsp, 0x08
00007a40685e0775  push rax
00007a40685e0776  push rcx
00007a40685e0777  push rdx
00007a40685e0778  push rdi
00007a40685e0779  push rsi
00007a40685e077a  push r8
00007a40685e077c  push r9
00007a40685e077e  push r10
00007a40685e0780  push r11
00007a40685e0782  sub rsp, 0xF0
00007a40685e0789  vmovaps [rsp], xmm0
00007a40685e078e  vmovaps [rsp+0x10], xmm1
00007a40685e0794  vmovaps [rsp+0x20], xmm2
00007a40685e079a  vmovaps [rsp+0x30], xmm3
00007a40685e07a0  vmovaps [rsp+0x40], xmm4
00007a40685e07a6  vmovaps [rsp+0x50], xmm5
00007a40685e07ac  vmovaps [rsp+0x60], xmm6
00007a40685e07b2  vmovaps [rsp+0x70], xmm7
00007a40685e07b8  vmovaps [rsp+0x80], xmm9
00007a40685e07c1  vmovaps [rsp+0x90], xmm10
00007a40685e07ca  vmovaps [rsp+0xA0], xmm11
00007a40685e07d3  vmovaps [rsp+0xB0], xmm12
00007a40685e07dc  vmovaps [rsp+0xC0], xmm13
00007a40685e07e5  vmovaps [rsp+0xD0], xmm14
00007a40685e07ee  vmovaps [rsp+0xE0], xmm15
00007a40685e07f7  sub rsp, 0x30
00007a40685e07fb  movaps [rsp], xmm8
00007a40685e0800  movaps [rsp+0x10], xmm15
00007a40685e0806  movaps [rsp+0x20], xmm9
00007a40685e080c  lea rdi, [rsp]
00007a40685e0810  mov esi, 0x00
00007a40685e0815  mov rax, 0x56F679577530
00007a40685e081f  call rax
00007a40685e0821  movaps xmm8, [rsp]
00007a40685e0826  add rsp, 0x30
00007a40685e082a  vmovaps xmm0, [rsp]
00007a40685e082f  vmovaps xmm1, [rsp+0x10]
00007a40685e0835  vmovaps xmm2, [rsp+0x20]
00007a40685e083b  vmovaps xmm3, [rsp+0x30]
00007a40685e0841  vmovaps xmm4, [rsp+0x40]
00007a40685e0847  vmovaps xmm5, [rsp+0x50]
00007a40685e084d  vmovaps xmm6, [rsp+0x60]
00007a40685e0853  vmovaps xmm7, [rsp+0x70]
00007a40685e0859  vmovaps xmm9, [rsp+0x80]
00007a40685e0862  vmovaps xmm10, [rsp+0x90]
00007a40685e086b  vmovaps xmm11, [rsp+0xA0]
00007a40685e0874  vmovaps xmm12, [rsp+0xB0]
00007a40685e087d  vmovaps xmm13, [rsp+0xC0]
00007a40685e0886  vmovaps xmm14, [rsp+0xD0]
00007a40685e088f  vmovaps xmm15, [rsp+0xE0]
00007a40685e0898  add rsp, 0xF0
00007a40685e089f  pop r11
00007a40685e08a1  pop r10
00007a40685e08a3  pop r9
00007a40685e08a5  pop r8
00007a40685e08a7  pop rsi
00007a40685e08a8  pop rdi
00007a40685e08a9  pop rdx
00007a40685e08aa  pop rcx
00007a40685e08ab  pop rax
00007a40685e08ac  add rsp, 0x08
00007a40685e08b0  jmp 0x00007A40685DC63D
00007a40685e08b5  sub rsp, 0x08
00007a40685e08b9  push rax
00007a40685e08ba  push rcx
00007a40685e08bb  push rdx
00007a40685e08bc  push rdi
00007a40685e08bd  push rsi
00007a40685e08be  push r8
00007a40685e08c0  push r9
00007a40685e08c2  push r10
00007a40685e08c4  push r11
00007a40685e08c6  sub rsp, 0xF0
00007a40685e08cd  vmovaps [rsp], xmm0
00007a40685e08d2  vmovaps [rsp+0x10], xmm1
00007a40685e08d8  vmovaps [rsp+0x20], xmm2
00007a40685e08de  vmovaps [rsp+0x30], xmm3
00007a40685e08e4  vmovaps [rsp+0x40], xmm4
00007a40685e08ea  vmovaps [rsp+0x50], xmm5
00007a40685e08f0  vmovaps [rsp+0x60], xmm6
00007a40685e08f6  vmovaps [rsp+0x70], xmm7
00007a40685e08fc  vmovaps [rsp+0x80], xmm8
00007a40685e0905  vmovaps [rsp+0x90], xmm9
00007a40685e090e  vmovaps [rsp+0xA0], xmm10
00007a40685e0917  vmovaps [rsp+0xB0], xmm11
00007a40685e0920  vmovaps [rsp+0xC0], xmm12
00007a40685e0929  vmovaps [rsp+0xD0], xmm13
00007a40685e0932  vmovaps [rsp+0xE0], xmm14
00007a40685e093b  sub rsp, 0x30
00007a40685e093f  movaps [rsp], xmm15
00007a40685e0944  movaps [rsp+0x10], xmm11
00007a40685e094a  movaps [rsp+0x20], xmm6
00007a40685e094f  lea rdi, [rsp]
00007a40685e0953  mov esi, 0x00
00007a40685e0958  mov rax, 0x56F679577530
00007a40685e0962  call rax
00007a40685e0964  movaps xmm15, [rsp]
00007a40685e0969  add rsp, 0x30
00007a40685e096d  vmovaps xmm0, [rsp]
00007a40685e0972  vmovaps xmm1, [rsp+0x10]
00007a40685e0978  vmovaps xmm2, [rsp+0x20]
00007a40685e097e  vmovaps xmm3, [rsp+0x30]
00007a40685e0984  vmovaps xmm4, [rsp+0x40]
00007a40685e098a  vmovaps xmm5, [rsp+0x50]
00007a40685e0990  vmovaps xmm6, [rsp+0x60]
00007a40685e0996  vmovaps xmm7, [rsp+0x70]
00007a40685e099c  vmovaps xmm8, [rsp+0x80]
00007a40685e09a5  vmovaps xmm9, [rsp+0x90]
00007a40685e09ae  vmovaps xmm10, [rsp+0xA0]
00007a40685e09b7  vmovaps xmm11, [rsp+0xB0]
00007a40685e09c0  vmovaps xmm12, [rsp+0xC0]
00007a40685e09c9  vmovaps xmm13, [rsp+0xD0]
00007a40685e09d2  vmovaps xmm14, [rsp+0xE0]
00007a40685e09db  add rsp, 0xF0
00007a40685e09e2  pop r11
00007a40685e09e4  pop r10
00007a40685e09e6  pop r9
00007a40685e09e8  pop r8
00007a40685e09ea  pop rsi
00007a40685e09eb  pop rdi
00007a40685e09ec  pop rdx
00007a40685e09ed  pop rcx
00007a40685e09ee  pop rax
00007a40685e09ef  add rsp, 0x08
00007a40685e09f3  jmp 0x00007A40685DC658
00007a40685e09f8  sub rsp, 0x08
00007a40685e09fc  push rax
00007a40685e09fd  push rcx
00007a40685e09fe  push rdx
00007a40685e09ff  push rdi
00007a40685e0a00  push rsi
00007a40685e0a01  push r8
00007a40685e0a03  push r9
00007a40685e0a05  push r10
00007a40685e0a07  push r11
00007a40685e0a09  sub rsp, 0xF0
00007a40685e0a10  vmovaps [rsp], xmm0
00007a40685e0a15  vmovaps [rsp+0x10], xmm1
00007a40685e0a1b  vmovaps [rsp+0x20], xmm2
00007a40685e0a21  vmovaps [rsp+0x30], xmm3
00007a40685e0a27  vmovaps [rsp+0x40], xmm4
00007a40685e0a2d  vmovaps [rsp+0x50], xmm5
00007a40685e0a33  vmovaps [rsp+0x60], xmm6
00007a40685e0a39  vmovaps [rsp+0x70], xmm8
00007a40685e0a3f  vmovaps [rsp+0x80], xmm9
00007a40685e0a48  vmovaps [rsp+0x90], xmm10
00007a40685e0a51  vmovaps [rsp+0xA0], xmm11
00007a40685e0a5a  vmovaps [rsp+0xB0], xmm12
00007a40685e0a63  vmovaps [rsp+0xC0], xmm13
00007a40685e0a6c  vmovaps [rsp+0xD0], xmm14
00007a40685e0a75  vmovaps [rsp+0xE0], xmm15
00007a40685e0a7e  sub rsp, 0x30
00007a40685e0a82  movaps [rsp], xmm7
00007a40685e0a86  movaps [rsp+0x10], xmm11
00007a40685e0a8c  movaps [rsp+0x20], xmm9
00007a40685e0a92  lea rdi, [rsp]
00007a40685e0a96  mov esi, 0x00
00007a40685e0a9b  mov rax, 0x56F679577530
00007a40685e0aa5  call rax
00007a40685e0aa7  movaps xmm7, [rsp]
00007a40685e0aab  add rsp, 0x30
00007a40685e0aaf  vmovaps xmm0, [rsp]
00007a40685e0ab4  vmovaps xmm1, [rsp+0x10]
00007a40685e0aba  vmovaps xmm2, [rsp+0x20]
00007a40685e0ac0  vmovaps xmm3, [rsp+0x30]
00007a40685e0ac6  vmovaps xmm4, [rsp+0x40]
00007a40685e0acc  vmovaps xmm5, [rsp+0x50]
00007a40685e0ad2  vmovaps xmm6, [rsp+0x60]
00007a40685e0ad8  vmovaps xmm8, [rsp+0x70]
00007a40685e0ade  vmovaps xmm9, [rsp+0x80]
00007a40685e0ae7  vmovaps xmm10, [rsp+0x90]
00007a40685e0af0  vmovaps xmm11, [rsp+0xA0]
00007a40685e0af9  vmovaps xmm12, [rsp+0xB0]
00007a40685e0b02  vmovaps xmm13, [rsp+0xC0]
00007a40685e0b0b  vmovaps xmm14, [rsp+0xD0]
00007a40685e0b14  vmovaps xmm15, [rsp+0xE0]
00007a40685e0b1d  add rsp, 0xF0
00007a40685e0b24  pop r11
00007a40685e0b26  pop r10
00007a40685e0b28  pop r9
00007a40685e0b2a  pop r8
00007a40685e0b2c  pop rsi
00007a40685e0b2d  pop rdi
00007a40685e0b2e  pop rdx
00007a40685e0b2f  pop rcx
00007a40685e0b30  pop rax
00007a40685e0b31  add rsp, 0x08
00007a40685e0b35  jmp 0x00007A40685DC685
00007a40685e0b3a  sub rsp, 0x08
00007a40685e0b3e  push rax
00007a40685e0b3f  push rcx
00007a40685e0b40  push rdx
00007a40685e0b41  push rdi
00007a40685e0b42  push rsi
00007a40685e0b43  push r8
00007a40685e0b45  push r9
00007a40685e0b47  push r10
00007a40685e0b49  push r11
00007a40685e0b4b  sub rsp, 0xF0
00007a40685e0b52  vmovaps [rsp], xmm0
00007a40685e0b57  vmovaps [rsp+0x10], xmm1
00007a40685e0b5d  vmovaps [rsp+0x20], xmm2
00007a40685e0b63  vmovaps [rsp+0x30], xmm3
00007a40685e0b69  vmovaps [rsp+0x40], xmm4
00007a40685e0b6f  vmovaps [rsp+0x50], xmm5
00007a40685e0b75  vmovaps [rsp+0x60], xmm6
00007a40685e0b7b  vmovaps [rsp+0x70], xmm7
00007a40685e0b81  vmovaps [rsp+0x80], xmm8
00007a40685e0b8a  vmovaps [rsp+0x90], xmm9
00007a40685e0b93  vmovaps [rsp+0xA0], xmm10
00007a40685e0b9c  vmovaps [rsp+0xB0], xmm12
00007a40685e0ba5  vmovaps [rsp+0xC0], xmm13
00007a40685e0bae  vmovaps [rsp+0xD0], xmm14
00007a40685e0bb7  vmovaps [rsp+0xE0], xmm15
00007a40685e0bc0  sub rsp, 0x30
00007a40685e0bc4  movaps [rsp], xmm11
00007a40685e0bc9  movaps [rsp+0x10], xmm10
00007a40685e0bcf  movaps [rsp+0x20], xmm14
00007a40685e0bd5  lea rdi, [rsp]
00007a40685e0bd9  mov esi, 0x00
00007a40685e0bde  mov rax, 0x56F679577530
00007a40685e0be8  call rax
00007a40685e0bea  movaps xmm11, [rsp]
00007a40685e0bef  add rsp, 0x30
00007a40685e0bf3  vmovaps xmm0, [rsp]
00007a40685e0bf8  vmovaps xmm1, [rsp+0x10]
00007a40685e0bfe  vmovaps xmm2, [rsp+0x20]
00007a40685e0c04  vmovaps xmm3, [rsp+0x30]
00007a40685e0c0a  vmovaps xmm4, [rsp+0x40]
00007a40685e0c10  vmovaps xmm5, [rsp+0x50]
00007a40685e0c16  vmovaps xmm6, [rsp+0x60]
00007a40685e0c1c  vmovaps xmm7, [rsp+0x70]
00007a40685e0c22  vmovaps xmm8, [rsp+0x80]
00007a40685e0c2b  vmovaps xmm9, [rsp+0x90]
00007a40685e0c34  vmovaps xmm10, [rsp+0xA0]
00007a40685e0c3d  vmovaps xmm12, [rsp+0xB0]
00007a40685e0c46  vmovaps xmm13, [rsp+0xC0]
00007a40685e0c4f  vmovaps xmm14, [rsp+0xD0]
00007a40685e0c58  vmovaps xmm15, [rsp+0xE0]
00007a40685e0c61  add rsp, 0xF0
00007a40685e0c68  pop r11
00007a40685e0c6a  pop r10
00007a40685e0c6c  pop r9
00007a40685e0c6e  pop r8
00007a40685e0c70  pop rsi
00007a40685e0c71  pop rdi
00007a40685e0c72  pop rdx
00007a40685e0c73  pop rcx
00007a40685e0c74  pop rax
00007a40685e0c75  add rsp, 0x08
00007a40685e0c79  jmp 0x00007A40685DC6A0
00007a40685e0c7e  call 0x00007A40684C33A0
00007a40685e0c83  jmp 0x00007A40685DC6AA
00007a40685e0c88  sub rsp, 0x08
00007a40685e0c8c  push rax
00007a40685e0c8d  push rcx
00007a40685e0c8e  push rdx
00007a40685e0c8f  push rdi
00007a40685e0c90  push rsi
00007a40685e0c91  push r8
00007a40685e0c93  push r9
00007a40685e0c95  push r10
00007a40685e0c97  push r11
00007a40685e0c99  sub rsp, 0xF0
00007a40685e0ca0  vmovaps [rsp], xmm0
00007a40685e0ca5  vmovaps [rsp+0x10], xmm1
00007a40685e0cab  vmovaps [rsp+0x20], xmm2
00007a40685e0cb1  vmovaps [rsp+0x30], xmm3
00007a40685e0cb7  vmovaps [rsp+0x40], xmm4
00007a40685e0cbd  vmovaps [rsp+0x50], xmm5
00007a40685e0cc3  vmovaps [rsp+0x60], xmm6
00007a40685e0cc9  vmovaps [rsp+0x70], xmm7
00007a40685e0ccf  vmovaps [rsp+0x80], xmm8
00007a40685e0cd8  vmovaps [rsp+0x90], xmm9
00007a40685e0ce1  vmovaps [rsp+0xA0], xmm11
00007a40685e0cea  vmovaps [rsp+0xB0], xmm12
00007a40685e0cf3  vmovaps [rsp+0xC0], xmm13
00007a40685e0cfc  vmovaps [rsp+0xD0], xmm14
00007a40685e0d05  vmovaps [rsp+0xE0], xmm15
00007a40685e0d0e  sub rsp, 0x30
00007a40685e0d12  movaps [rsp], xmm10
00007a40685e0d17  movaps [rsp+0x10], xmm1
00007a40685e0d1c  movaps [rsp+0x20], xmm12
00007a40685e0d22  lea rdi, [rsp]
00007a40685e0d26  mov esi, 0x00
00007a40685e0d2b  mov rax, 0x56F679577530
00007a40685e0d35  call rax
00007a40685e0d37  movaps xmm10, [rsp]
00007a40685e0d3c  add rsp, 0x30
00007a40685e0d40  vmovaps xmm0, [rsp]
00007a40685e0d45  vmovaps xmm1, [rsp+0x10]
00007a40685e0d4b  vmovaps xmm2, [rsp+0x20]
00007a40685e0d51  vmovaps xmm3, [rsp+0x30]
00007a40685e0d57  vmovaps xmm4, [rsp+0x40]
00007a40685e0d5d  vmovaps xmm5, [rsp+0x50]
00007a40685e0d63  vmovaps xmm6, [rsp+0x60]
00007a40685e0d69  vmovaps xmm7, [rsp+0x70]
00007a40685e0d6f  vmovaps xmm8, [rsp+0x80]
00007a40685e0d78  vmovaps xmm9, [rsp+0x90]
00007a40685e0d81  vmovaps xmm11, [rsp+0xA0]
00007a40685e0d8a  vmovaps xmm12, [rsp+0xB0]
00007a40685e0d93  vmovaps xmm13, [rsp+0xC0]
00007a40685e0d9c  vmovaps xmm14, [rsp+0xD0]
00007a40685e0da5  vmovaps xmm15, [rsp+0xE0]
00007a40685e0dae  add rsp, 0xF0
00007a40685e0db5  pop r11
00007a40685e0db7  pop r10
00007a40685e0db9  pop r9
00007a40685e0dbb  pop r8
00007a40685e0dbd  pop rsi
00007a40685e0dbe  pop rdi
00007a40685e0dbf  pop rdx
00007a40685e0dc0  pop rcx
00007a40685e0dc1  pop rax
00007a40685e0dc2  add rsp, 0x08
00007a40685e0dc6  jmp 0x00007A40685DC6CD
00007a40685e0dcb  sub rsp, 0x08
00007a40685e0dcf  push rax
00007a40685e0dd0  push rcx
00007a40685e0dd1  push rdx
00007a40685e0dd2  push rdi
00007a40685e0dd3  push rsi
00007a40685e0dd4  push r8
00007a40685e0dd6  push r9
00007a40685e0dd8  push r10
00007a40685e0dda  push r11
00007a40685e0ddc  sub rsp, 0xF0
00007a40685e0de3  vmovaps [rsp], xmm0
00007a40685e0de8  vmovaps [rsp+0x10], xmm1
00007a40685e0dee  vmovaps [rsp+0x20], xmm2
00007a40685e0df4  vmovaps [rsp+0x30], xmm3
00007a40685e0dfa  vmovaps [rsp+0x40], xmm4
00007a40685e0e00  vmovaps [rsp+0x50], xmm5
00007a40685e0e06  vmovaps [rsp+0x60], xmm6
00007a40685e0e0c  vmovaps [rsp+0x70], xmm7
00007a40685e0e12  vmovaps [rsp+0x80], xmm8
00007a40685e0e1b  vmovaps [rsp+0x90], xmm9
00007a40685e0e24  vmovaps [rsp+0xA0], xmm10
00007a40685e0e2d  vmovaps [rsp+0xB0], xmm11
00007a40685e0e36  vmovaps [rsp+0xC0], xmm13
00007a40685e0e3f  vmovaps [rsp+0xD0], xmm14
00007a40685e0e48  vmovaps [rsp+0xE0], xmm15
00007a40685e0e51  sub rsp, 0x30
00007a40685e0e55  movaps [rsp], xmm12
00007a40685e0e5a  movaps [rsp+0x10], xmm14
00007a40685e0e60  movaps [rsp+0x20], xmm1
00007a40685e0e65  lea rdi, [rsp]
00007a40685e0e69  mov esi, 0x00
00007a40685e0e6e  mov rax, 0x56F679577530
00007a40685e0e78  call rax
00007a40685e0e7a  movaps xmm12, [rsp]
00007a40685e0e7f  add rsp, 0x30
00007a40685e0e83  vmovaps xmm0, [rsp]
00007a40685e0e88  vmovaps xmm1, [rsp+0x10]
00007a40685e0e8e  vmovaps xmm2, [rsp+0x20]
00007a40685e0e94  vmovaps xmm3, [rsp+0x30]
00007a40685e0e9a  vmovaps xmm4, [rsp+0x40]
00007a40685e0ea0  vmovaps xmm5, [rsp+0x50]
00007a40685e0ea6  vmovaps xmm6, [rsp+0x60]
00007a40685e0eac  vmovaps xmm7, [rsp+0x70]
00007a40685e0eb2  vmovaps xmm8, [rsp+0x80]
00007a40685e0ebb  vmovaps xmm9, [rsp+0x90]
00007a40685e0ec4  vmovaps xmm10, [rsp+0xA0]
00007a40685e0ecd  vmovaps xmm11, [rsp+0xB0]
00007a40685e0ed6  vmovaps xmm13, [rsp+0xC0]
00007a40685e0edf  vmovaps xmm14, [rsp+0xD0]
00007a40685e0ee8  vmovaps xmm15, [rsp+0xE0]
00007a40685e0ef1  add rsp, 0xF0
00007a40685e0ef8  pop r11
00007a40685e0efa  pop r10
00007a40685e0efc  pop r9
00007a40685e0efe  pop r8
00007a40685e0f00  pop rsi
00007a40685e0f01  pop rdi
00007a40685e0f02  pop rdx
00007a40685e0f03  pop rcx
00007a40685e0f04  pop rax
00007a40685e0f05  add rsp, 0x08
00007a40685e0f09  jmp 0x00007A40685DC6FC
00007a40685e0f0e  sub rsp, 0x08
00007a40685e0f12  push rax
00007a40685e0f13  push rcx
00007a40685e0f14  push rdx
00007a40685e0f15  push rdi
00007a40685e0f16  push rsi
00007a40685e0f17  push r8
00007a40685e0f19  push r9
00007a40685e0f1b  push r10
00007a40685e0f1d  push r11
00007a40685e0f1f  sub rsp, 0xF0
00007a40685e0f26  vmovaps [rsp], xmm0
00007a40685e0f2b  vmovaps [rsp+0x10], xmm1
00007a40685e0f31  vmovaps [rsp+0x20], xmm2
00007a40685e0f37  vmovaps [rsp+0x30], xmm3
00007a40685e0f3d  vmovaps [rsp+0x40], xmm4
00007a40685e0f43  vmovaps [rsp+0x50], xmm5
00007a40685e0f49  vmovaps [rsp+0x60], xmm6
00007a40685e0f4f  vmovaps [rsp+0x70], xmm7
00007a40685e0f55  vmovaps [rsp+0x80], xmm8
00007a40685e0f5e  vmovaps [rsp+0x90], xmm9
00007a40685e0f67  vmovaps [rsp+0xA0], xmm10
00007a40685e0f70  vmovaps [rsp+0xB0], xmm11
00007a40685e0f79  vmovaps [rsp+0xC0], xmm12
00007a40685e0f82  vmovaps [rsp+0xD0], xmm13
00007a40685e0f8b  vmovaps [rsp+0xE0], xmm15
00007a40685e0f94  sub rsp, 0x30
00007a40685e0f98  movaps [rsp], xmm14
00007a40685e0f9d  movaps [rsp+0x10], xmm9
00007a40685e0fa3  movaps [rsp+0x20], xmm1
00007a40685e0fa8  lea rdi, [rsp]
00007a40685e0fac  mov esi, 0x00
00007a40685e0fb1  mov rax, 0x56F679577530
00007a40685e0fbb  call rax
00007a40685e0fbd  movaps xmm14, [rsp]
00007a40685e0fc2  add rsp, 0x30
00007a40685e0fc6  vmovaps xmm0, [rsp]
00007a40685e0fcb  vmovaps xmm1, [rsp+0x10]
00007a40685e0fd1  vmovaps xmm2, [rsp+0x20]
00007a40685e0fd7  vmovaps xmm3, [rsp+0x30]
00007a40685e0fdd  vmovaps xmm4, [rsp+0x40]
00007a40685e0fe3  vmovaps xmm5, [rsp+0x50]
00007a40685e0fe9  vmovaps xmm6, [rsp+0x60]
00007a40685e0fef  vmovaps xmm7, [rsp+0x70]
00007a40685e0ff5  vmovaps xmm8, [rsp+0x80]
00007a40685e0ffe  vmovaps xmm9, [rsp+0x90]
00007a40685e1007  vmovaps xmm10, [rsp+0xA0]
00007a40685e1010  vmovaps xmm11, [rsp+0xB0]
00007a40685e1019  vmovaps xmm12, [rsp+0xC0]
00007a40685e1022  vmovaps xmm13, [rsp+0xD0]
00007a40685e102b  vmovaps xmm15, [rsp+0xE0]
00007a40685e1034  add rsp, 0xF0
00007a40685e103b  pop r11
00007a40685e103d  pop r10
00007a40685e103f  pop r9
00007a40685e1041  pop r8
00007a40685e1043  pop rsi
00007a40685e1044  pop rdi
00007a40685e1045  pop rdx
00007a40685e1046  pop rcx
00007a40685e1047  pop rax
00007a40685e1048  add rsp, 0x08
00007a40685e104c  jmp 0x00007A40685DC72B
00007a40685e1051  sub rsp, 0x08
00007a40685e1055  push rax
00007a40685e1056  push rcx
00007a40685e1057  push rdx
00007a40685e1058  push rdi
00007a40685e1059  push rsi
00007a40685e105a  push r8
00007a40685e105c  push r9
00007a40685e105e  push r10
00007a40685e1060  push r11
00007a40685e1062  sub rsp, 0xF0
00007a40685e1069  vmovaps [rsp], xmm0
00007a40685e106e  vmovaps [rsp+0x10], xmm2
00007a40685e1074  vmovaps [rsp+0x20], xmm3
00007a40685e107a  vmovaps [rsp+0x30], xmm4
00007a40685e1080  vmovaps [rsp+0x40], xmm5
00007a40685e1086  vmovaps [rsp+0x50], xmm6
00007a40685e108c  vmovaps [rsp+0x60], xmm7
00007a40685e1092  vmovaps [rsp+0x70], xmm8
00007a40685e1098  vmovaps [rsp+0x80], xmm9
00007a40685e10a1  vmovaps [rsp+0x90], xmm10
00007a40685e10aa  vmovaps [rsp+0xA0], xmm11
00007a40685e10b3  vmovaps [rsp+0xB0], xmm12
00007a40685e10bc  vmovaps [rsp+0xC0], xmm13
00007a40685e10c5  vmovaps [rsp+0xD0], xmm14
00007a40685e10ce  vmovaps [rsp+0xE0], xmm15
00007a40685e10d7  sub rsp, 0x30
00007a40685e10db  movaps [rsp], xmm1
00007a40685e10df  movaps [rsp+0x10], xmm13
00007a40685e10e5  movaps [rsp+0x20], xmm8
00007a40685e10eb  lea rdi, [rsp]
00007a40685e10ef  mov esi, 0x00
00007a40685e10f4  mov rax, 0x56F679577530
00007a40685e10fe  call rax
00007a40685e1100  movaps xmm1, [rsp]
00007a40685e1104  add rsp, 0x30
00007a40685e1108  vmovaps xmm0, [rsp]
00007a40685e110d  vmovaps xmm2, [rsp+0x10]
00007a40685e1113  vmovaps xmm3, [rsp+0x20]
00007a40685e1119  vmovaps xmm4, [rsp+0x30]
00007a40685e111f  vmovaps xmm5, [rsp+0x40]
00007a40685e1125  vmovaps xmm6, [rsp+0x50]
00007a40685e112b  vmovaps xmm7, [rsp+0x60]
00007a40685e1131  vmovaps xmm8, [rsp+0x70]
00007a40685e1137  vmovaps xmm9, [rsp+0x80]
00007a40685e1140  vmovaps xmm10, [rsp+0x90]
00007a40685e1149  vmovaps xmm11, [rsp+0xA0]
00007a40685e1152  vmovaps xmm12, [rsp+0xB0]
00007a40685e115b  vmovaps xmm13, [rsp+0xC0]
00007a40685e1164  vmovaps xmm14, [rsp+0xD0]
00007a40685e116d  vmovaps xmm15, [rsp+0xE0]
00007a40685e1176  add rsp, 0xF0
00007a40685e117d  pop r11
00007a40685e117f  pop r10
00007a40685e1181  pop r9
00007a40685e1183  pop r8
00007a40685e1185  pop rsi
00007a40685e1186  pop rdi
00007a40685e1187  pop rdx
00007a40685e1188  pop rcx
00007a40685e1189  pop rax
00007a40685e118a  add rsp, 0x08
00007a40685e118e  jmp 0x00007A40685DC74D
00007a40685e1193  call 0x00007A406840C260
00007a40685e1198  jmp 0x00007A40685DC75B
00007a40685e119d  call 0x00007A40684BD750
00007a40685e11a2  jmp 0x00007A40685DC765
00007a40685e11a7  sub rsp, 0x08
00007a40685e11ab  push rax
00007a40685e11ac  push rcx
00007a40685e11ad  push rdx
00007a40685e11ae  push rdi
00007a40685e11af  push rsi
00007a40685e11b0  push r8
00007a40685e11b2  push r9
00007a40685e11b4  push r10
00007a40685e11b6  push r11
00007a40685e11b8  sub rsp, 0xF0
00007a40685e11bf  vmovaps [rsp], xmm0
00007a40685e11c4  vmovaps [rsp+0x10], xmm1
00007a40685e11ca  vmovaps [rsp+0x20], xmm2
00007a40685e11d0  vmovaps [rsp+0x30], xmm3
00007a40685e11d6  vmovaps [rsp+0x40], xmm4
00007a40685e11dc  vmovaps [rsp+0x50], xmm5
00007a40685e11e2  vmovaps [rsp+0x60], xmm6
00007a40685e11e8  vmovaps [rsp+0x70], xmm7
00007a40685e11ee  vmovaps [rsp+0x80], xmm9
00007a40685e11f7  vmovaps [rsp+0x90], xmm10
00007a40685e1200  vmovaps [rsp+0xA0], xmm11
00007a40685e1209  vmovaps [rsp+0xB0], xmm12
00007a40685e1212  vmovaps [rsp+0xC0], xmm13
00007a40685e121b  vmovaps [rsp+0xD0], xmm14
00007a40685e1224  vmovaps [rsp+0xE0], xmm15
00007a40685e122d  sub rsp, 0x30
00007a40685e1231  movaps [rsp], xmm8
00007a40685e1236  movaps [rsp+0x10], xmm15
00007a40685e123c  movaps [rsp+0x20], xmm7
00007a40685e1241  lea rdi, [rsp]
00007a40685e1245  mov esi, 0x00
00007a40685e124a  mov rax, 0x56F679577530
00007a40685e1254  call rax
00007a40685e1256  movaps xmm8, [rsp]
00007a40685e125b  add rsp, 0x30
00007a40685e125f  vmovaps xmm0, [rsp]
00007a40685e1264  vmovaps xmm1, [rsp+0x10]
00007a40685e126a  vmovaps xmm2, [rsp+0x20]
00007a40685e1270  vmovaps xmm3, [rsp+0x30]
00007a40685e1276  vmovaps xmm4, [rsp+0x40]
00007a40685e127c  vmovaps xmm5, [rsp+0x50]
00007a40685e1282  vmovaps xmm6, [rsp+0x60]
00007a40685e1288  vmovaps xmm7, [rsp+0x70]
00007a40685e128e  vmovaps xmm9, [rsp+0x80]
00007a40685e1297  vmovaps xmm10, [rsp+0x90]
00007a40685e12a0  vmovaps xmm11, [rsp+0xA0]
00007a40685e12a9  vmovaps xmm12, [rsp+0xB0]
00007a40685e12b2  vmovaps xmm13, [rsp+0xC0]
00007a40685e12bb  vmovaps xmm14, [rsp+0xD0]
00007a40685e12c4  vmovaps xmm15, [rsp+0xE0]
00007a40685e12cd  add rsp, 0xF0
00007a40685e12d4  pop r11
00007a40685e12d6  pop r10
00007a40685e12d8  pop r9
00007a40685e12da  pop r8
00007a40685e12dc  pop rsi
00007a40685e12dd  pop rdi
00007a40685e12de  pop rdx
00007a40685e12df  pop rcx
00007a40685e12e0  pop rax
00007a40685e12e1  add rsp, 0x08
00007a40685e12e5  jmp 0x00007A40685DC787
00007a40685e12ea  sub rsp, 0x08
00007a40685e12ee  push rax
00007a40685e12ef  push rcx
00007a40685e12f0  push rdx
00007a40685e12f1  push rdi
00007a40685e12f2  push rsi
00007a40685e12f3  push r8
00007a40685e12f5  push r9
00007a40685e12f7  push r10
00007a40685e12f9  push r11
00007a40685e12fb  sub rsp, 0xF0
00007a40685e1302  vmovaps [rsp], xmm0
00007a40685e1307  vmovaps [rsp+0x10], xmm1
00007a40685e130d  vmovaps [rsp+0x20], xmm2
00007a40685e1313  vmovaps [rsp+0x30], xmm3
00007a40685e1319  vmovaps [rsp+0x40], xmm4
00007a40685e131f  vmovaps [rsp+0x50], xmm5
00007a40685e1325  vmovaps [rsp+0x60], xmm6
00007a40685e132b  vmovaps [rsp+0x70], xmm8
00007a40685e1331  vmovaps [rsp+0x80], xmm9
00007a40685e133a  vmovaps [rsp+0x90], xmm10
00007a40685e1343  vmovaps [rsp+0xA0], xmm11
00007a40685e134c  vmovaps [rsp+0xB0], xmm12
00007a40685e1355  vmovaps [rsp+0xC0], xmm13
00007a40685e135e  vmovaps [rsp+0xD0], xmm14
00007a40685e1367  vmovaps [rsp+0xE0], xmm15
00007a40685e1370  sub rsp, 0x30
00007a40685e1374  movaps [rsp], xmm7
00007a40685e1378  movaps [rsp+0x10], xmm9
00007a40685e137e  movaps [rsp+0x20], xmm15
00007a40685e1384  lea rdi, [rsp]
00007a40685e1388  mov esi, 0x00
00007a40685e138d  mov rax, 0x56F679577530
00007a40685e1397  call rax
00007a40685e1399  movaps xmm7, [rsp]
00007a40685e139d  add rsp, 0x30
00007a40685e13a1  vmovaps xmm0, [rsp]
00007a40685e13a6  vmovaps xmm1, [rsp+0x10]
00007a40685e13ac  vmovaps xmm2, [rsp+0x20]
00007a40685e13b2  vmovaps xmm3, [rsp+0x30]
00007a40685e13b8  vmovaps xmm4, [rsp+0x40]
00007a40685e13be  vmovaps xmm5, [rsp+0x50]
00007a40685e13c4  vmovaps xmm6, [rsp+0x60]
00007a40685e13ca  vmovaps xmm8, [rsp+0x70]
00007a40685e13d0  vmovaps xmm9, [rsp+0x80]
00007a40685e13d9  vmovaps xmm10, [rsp+0x90]
00007a40685e13e2  vmovaps xmm11, [rsp+0xA0]
00007a40685e13eb  vmovaps xmm12, [rsp+0xB0]
00007a40685e13f4  vmovaps xmm13, [rsp+0xC0]
00007a40685e13fd  vmovaps xmm14, [rsp+0xD0]
00007a40685e1406  vmovaps xmm15, [rsp+0xE0]
00007a40685e140f  add rsp, 0xF0
00007a40685e1416  pop r11
00007a40685e1418  pop r10
00007a40685e141a  pop r9
00007a40685e141c  pop r8
00007a40685e141e  pop rsi
00007a40685e141f  pop rdi
00007a40685e1420  pop rdx
00007a40685e1421  pop rcx
00007a40685e1422  pop rax
00007a40685e1423  add rsp, 0x08
00007a40685e1427  jmp 0x00007A40685DC7B4
00007a40685e142c  sub rsp, 0x08
00007a40685e1430  push rax
00007a40685e1431  push rcx
00007a40685e1432  push rdx
00007a40685e1433  push rdi
00007a40685e1434  push rsi
00007a40685e1435  push r8
00007a40685e1437  push r9
00007a40685e1439  push r10
00007a40685e143b  push r11
00007a40685e143d  sub rsp, 0xF0
00007a40685e1444  vmovaps [rsp], xmm0
00007a40685e1449  vmovaps [rsp+0x10], xmm1
00007a40685e144f  vmovaps [rsp+0x20], xmm2
00007a40685e1455  vmovaps [rsp+0x30], xmm3
00007a40685e145b  vmovaps [rsp+0x40], xmm4
00007a40685e1461  vmovaps [rsp+0x50], xmm5
00007a40685e1467  vmovaps [rsp+0x60], xmm6
00007a40685e146d  vmovaps [rsp+0x70], xmm7
00007a40685e1473  vmovaps [rsp+0x80], xmm8
00007a40685e147c  vmovaps [rsp+0x90], xmm10
00007a40685e1485  vmovaps [rsp+0xA0], xmm11
00007a40685e148e  vmovaps [rsp+0xB0], xmm12
00007a40685e1497  vmovaps [rsp+0xC0], xmm13
00007a40685e14a0  vmovaps [rsp+0xD0], xmm14
00007a40685e14a9  vmovaps [rsp+0xE0], xmm15
00007a40685e14b2  sub rsp, 0x30
00007a40685e14b6  movaps [rsp], xmm9
00007a40685e14bb  movaps [rsp+0x10], xmm13
00007a40685e14c1  movaps [rsp+0x20], xmm15
00007a40685e14c7  lea rdi, [rsp]
00007a40685e14cb  mov esi, 0x00
00007a40685e14d0  mov rax, 0x56F679577530
00007a40685e14da  call rax
00007a40685e14dc  movaps xmm9, [rsp]
00007a40685e14e1  add rsp, 0x30
00007a40685e14e5  vmovaps xmm0, [rsp]
00007a40685e14ea  vmovaps xmm1, [rsp+0x10]
00007a40685e14f0  vmovaps xmm2, [rsp+0x20]
00007a40685e14f6  vmovaps xmm3, [rsp+0x30]
00007a40685e14fc  vmovaps xmm4, [rsp+0x40]
00007a40685e1502  vmovaps xmm5, [rsp+0x50]
00007a40685e1508  vmovaps xmm6, [rsp+0x60]
00007a40685e150e  vmovaps xmm7, [rsp+0x70]
00007a40685e1514  vmovaps xmm8, [rsp+0x80]
00007a40685e151d  vmovaps xmm10, [rsp+0x90]
00007a40685e1526  vmovaps xmm11, [rsp+0xA0]
00007a40685e152f  vmovaps xmm12, [rsp+0xB0]
00007a40685e1538  vmovaps xmm13, [rsp+0xC0]
00007a40685e1541  vmovaps xmm14, [rsp+0xD0]
00007a40685e154a  vmovaps xmm15, [rsp+0xE0]
00007a40685e1553  add rsp, 0xF0
00007a40685e155a  pop r11
00007a40685e155c  pop r10
00007a40685e155e  pop r9
00007a40685e1560  pop r8
00007a40685e1562  pop rsi
00007a40685e1563  pop rdi
00007a40685e1564  pop rdx
00007a40685e1565  pop rcx
00007a40685e1566  pop rax
00007a40685e1567  add rsp, 0x08
00007a40685e156b  jmp 0x00007A40685DC7E2
00007a40685e1570  sub rsp, 0x08
00007a40685e1574  push rax
00007a40685e1575  push rcx
00007a40685e1576  push rdx
00007a40685e1577  push rdi
00007a40685e1578  push rsi
00007a40685e1579  push r8
00007a40685e157b  push r9
00007a40685e157d  push r10
00007a40685e157f  push r11
00007a40685e1581  sub rsp, 0xF0
00007a40685e1588  vmovaps [rsp], xmm0
00007a40685e158d  vmovaps [rsp+0x10], xmm1
00007a40685e1593  vmovaps [rsp+0x20], xmm2
00007a40685e1599  vmovaps [rsp+0x30], xmm3
00007a40685e159f  vmovaps [rsp+0x40], xmm4
00007a40685e15a5  vmovaps [rsp+0x50], xmm5
00007a40685e15ab  vmovaps [rsp+0x60], xmm6
00007a40685e15b1  vmovaps [rsp+0x70], xmm7
00007a40685e15b7  vmovaps [rsp+0x80], xmm8
00007a40685e15c0  vmovaps [rsp+0x90], xmm9
00007a40685e15c9  vmovaps [rsp+0xA0], xmm10
00007a40685e15d2  vmovaps [rsp+0xB0], xmm11
00007a40685e15db  vmovaps [rsp+0xC0], xmm12
00007a40685e15e4  vmovaps [rsp+0xD0], xmm13
00007a40685e15ed  vmovaps [rsp+0xE0], xmm14
00007a40685e15f6  sub rsp, 0x30
00007a40685e15fa  movaps [rsp], xmm15
00007a40685e15ff  movaps [rsp+0x10], xmm11
00007a40685e1605  movaps [rsp+0x20], xmm12
00007a40685e160b  lea rdi, [rsp]
00007a40685e160f  mov esi, 0x00
00007a40685e1614  mov rax, 0x56F679577530
00007a40685e161e  call rax
00007a40685e1620  movaps xmm15, [rsp]
00007a40685e1625  add rsp, 0x30
00007a40685e1629  vmovaps xmm0, [rsp]
00007a40685e162e  vmovaps xmm1, [rsp+0x10]
00007a40685e1634  vmovaps xmm2, [rsp+0x20]
00007a40685e163a  vmovaps xmm3, [rsp+0x30]
00007a40685e1640  vmovaps xmm4, [rsp+0x40]
00007a40685e1646  vmovaps xmm5, [rsp+0x50]
00007a40685e164c  vmovaps xmm6, [rsp+0x60]
00007a40685e1652  vmovaps xmm7, [rsp+0x70]
00007a40685e1658  vmovaps xmm8, [rsp+0x80]
00007a40685e1661  vmovaps xmm9, [rsp+0x90]
00007a40685e166a  vmovaps xmm10, [rsp+0xA0]
00007a40685e1673  vmovaps xmm11, [rsp+0xB0]
00007a40685e167c  vmovaps xmm12, [rsp+0xC0]
00007a40685e1685  vmovaps xmm13, [rsp+0xD0]
00007a40685e168e  vmovaps xmm14, [rsp+0xE0]
00007a40685e1697  add rsp, 0xF0
00007a40685e169e  pop r11
00007a40685e16a0  pop r10
00007a40685e16a2  pop r9
00007a40685e16a4  pop r8
00007a40685e16a6  pop rsi
00007a40685e16a7  pop rdi
00007a40685e16a8  pop rdx
00007a40685e16a9  pop rcx
00007a40685e16aa  pop rax
00007a40685e16ab  add rsp, 0x08
00007a40685e16af  jmp 0x00007A40685DC7FD
00007a40685e16b4  sub rsp, 0x08
00007a40685e16b8  push rax
00007a40685e16b9  push rcx
00007a40685e16ba  push rdx
00007a40685e16bb  push rdi
00007a40685e16bc  push rsi
00007a40685e16bd  push r8
00007a40685e16bf  push r9
00007a40685e16c1  push r10
00007a40685e16c3  push r11
00007a40685e16c5  sub rsp, 0xF0
00007a40685e16cc  vmovaps [rsp], xmm0
00007a40685e16d1  vmovaps [rsp+0x10], xmm1
00007a40685e16d7  vmovaps [rsp+0x20], xmm2
00007a40685e16dd  vmovaps [rsp+0x30], xmm3
00007a40685e16e3  vmovaps [rsp+0x40], xmm4
00007a40685e16e9  vmovaps [rsp+0x50], xmm5
00007a40685e16ef  vmovaps [rsp+0x60], xmm6
00007a40685e16f5  vmovaps [rsp+0x70], xmm7
00007a40685e16fb  vmovaps [rsp+0x80], xmm8
00007a40685e1704  vmovaps [rsp+0x90], xmm9
00007a40685e170d  vmovaps [rsp+0xA0], xmm10
00007a40685e1716  vmovaps [rsp+0xB0], xmm11
00007a40685e171f  vmovaps [rsp+0xC0], xmm12
00007a40685e1728  vmovaps [rsp+0xD0], xmm14
00007a40685e1731  vmovaps [rsp+0xE0], xmm15
00007a40685e173a  sub rsp, 0x30
00007a40685e173e  movaps [rsp], xmm13
00007a40685e1743  movaps [rsp+0x10], xmm10
00007a40685e1749  movaps [rsp+0x20], xmm14
00007a40685e174f  lea rdi, [rsp]
00007a40685e1753  mov esi, 0x00
00007a40685e1758  mov rax, 0x56F679577530
00007a40685e1762  call rax
00007a40685e1764  movaps xmm13, [rsp]
00007a40685e1769  add rsp, 0x30
00007a40685e176d  vmovaps xmm0, [rsp]
00007a40685e1772  vmovaps xmm1, [rsp+0x10]
00007a40685e1778  vmovaps xmm2, [rsp+0x20]
00007a40685e177e  vmovaps xmm3, [rsp+0x30]
00007a40685e1784  vmovaps xmm4, [rsp+0x40]
00007a40685e178a  vmovaps xmm5, [rsp+0x50]
00007a40685e1790  vmovaps xmm6, [rsp+0x60]
00007a40685e1796  vmovaps xmm7, [rsp+0x70]
00007a40685e179c  vmovaps xmm8, [rsp+0x80]
00007a40685e17a5  vmovaps xmm9, [rsp+0x90]
00007a40685e17ae  vmovaps xmm10, [rsp+0xA0]
00007a40685e17b7  vmovaps xmm11, [rsp+0xB0]
00007a40685e17c0  vmovaps xmm12, [rsp+0xC0]
00007a40685e17c9  vmovaps xmm14, [rsp+0xD0]
00007a40685e17d2  vmovaps xmm15, [rsp+0xE0]
00007a40685e17db  add rsp, 0xF0
00007a40685e17e2  pop r11
00007a40685e17e4  pop r10
00007a40685e17e6  pop r9
00007a40685e17e8  pop r8
00007a40685e17ea  pop rsi
00007a40685e17eb  pop rdi
00007a40685e17ec  pop rdx
00007a40685e17ed  pop rcx
00007a40685e17ee  pop rax
00007a40685e17ef  add rsp, 0x08
00007a40685e17f3  jmp 0x00007A40685DC820
00007a40685e17f8  sub rsp, 0x08
00007a40685e17fc  push rax
00007a40685e17fd  push rcx
00007a40685e17fe  push rdx
00007a40685e17ff  push rdi
00007a40685e1800  push rsi
00007a40685e1801  push r8
00007a40685e1803  push r9
00007a40685e1805  push r10
00007a40685e1807  push r11
00007a40685e1809  sub rsp, 0xF0
00007a40685e1810  vmovaps [rsp], xmm0
00007a40685e1815  vmovaps [rsp+0x10], xmm1
00007a40685e181b  vmovaps [rsp+0x20], xmm2
00007a40685e1821  vmovaps [rsp+0x30], xmm3
00007a40685e1827  vmovaps [rsp+0x40], xmm4
00007a40685e182d  vmovaps [rsp+0x50], xmm5
00007a40685e1833  vmovaps [rsp+0x60], xmm6
00007a40685e1839  vmovaps [rsp+0x70], xmm7
00007a40685e183f  vmovaps [rsp+0x80], xmm8
00007a40685e1848  vmovaps [rsp+0x90], xmm9
00007a40685e1851  vmovaps [rsp+0xA0], xmm10
00007a40685e185a  vmovaps [rsp+0xB0], xmm11
00007a40685e1863  vmovaps [rsp+0xC0], xmm12
00007a40685e186c  vmovaps [rsp+0xD0], xmm13
00007a40685e1875  vmovaps [rsp+0xE0], xmm15
00007a40685e187e  sub rsp, 0x30
00007a40685e1882  movaps [rsp], xmm14
00007a40685e1887  movaps [rsp+0x10], xmm1
00007a40685e188c  movaps [rsp+0x20], xmm7
00007a40685e1891  lea rdi, [rsp]
00007a40685e1895  mov esi, 0x00
00007a40685e189a  mov rax, 0x56F679577530
00007a40685e18a4  call rax
00007a40685e18a6  movaps xmm14, [rsp]
00007a40685e18ab  add rsp, 0x30
00007a40685e18af  vmovaps xmm0, [rsp]
00007a40685e18b4  vmovaps xmm1, [rsp+0x10]
00007a40685e18ba  vmovaps xmm2, [rsp+0x20]
00007a40685e18c0  vmovaps xmm3, [rsp+0x30]
00007a40685e18c6  vmovaps xmm4, [rsp+0x40]
00007a40685e18cc  vmovaps xmm5, [rsp+0x50]
00007a40685e18d2  vmovaps xmm6, [rsp+0x60]
00007a40685e18d8  vmovaps xmm7, [rsp+0x70]
00007a40685e18de  vmovaps xmm8, [rsp+0x80]
00007a40685e18e7  vmovaps xmm9, [rsp+0x90]
00007a40685e18f0  vmovaps xmm10, [rsp+0xA0]
00007a40685e18f9  vmovaps xmm11, [rsp+0xB0]
00007a40685e1902  vmovaps xmm12, [rsp+0xC0]
00007a40685e190b  vmovaps xmm13, [rsp+0xD0]
00007a40685e1914  vmovaps xmm15, [rsp+0xE0]
00007a40685e191d  add rsp, 0xF0
00007a40685e1924  pop r11
00007a40685e1926  pop r10
00007a40685e1928  pop r9
00007a40685e192a  pop r8
00007a40685e192c  pop rsi
00007a40685e192d  pop rdi
00007a40685e192e  pop rdx
00007a40685e192f  pop rcx
00007a40685e1930  pop rax
00007a40685e1931  add rsp, 0x08
00007a40685e1935  jmp 0x00007A40685DC843
00007a40685e193a  sub rsp, 0x08
00007a40685e193e  push rax
00007a40685e193f  push rcx
00007a40685e1940  push rdx
00007a40685e1941  push rdi
00007a40685e1942  push rsi
00007a40685e1943  push r8
00007a40685e1945  push r9
00007a40685e1947  push r10
00007a40685e1949  push r11
00007a40685e194b  sub rsp, 0xF0
00007a40685e1952  vmovaps [rsp], xmm0
00007a40685e1957  vmovaps [rsp+0x10], xmm2
00007a40685e195d  vmovaps [rsp+0x20], xmm3
00007a40685e1963  vmovaps [rsp+0x30], xmm4
00007a40685e1969  vmovaps [rsp+0x40], xmm5
00007a40685e196f  vmovaps [rsp+0x50], xmm6
00007a40685e1975  vmovaps [rsp+0x60], xmm7
00007a40685e197b  vmovaps [rsp+0x70], xmm8
00007a40685e1981  vmovaps [rsp+0x80], xmm9
00007a40685e198a  vmovaps [rsp+0x90], xmm10
00007a40685e1993  vmovaps [rsp+0xA0], xmm11
00007a40685e199c  vmovaps [rsp+0xB0], xmm12
00007a40685e19a5  vmovaps [rsp+0xC0], xmm13
00007a40685e19ae  vmovaps [rsp+0xD0], xmm14
00007a40685e19b7  vmovaps [rsp+0xE0], xmm15
00007a40685e19c0  sub rsp, 0x30
00007a40685e19c4  movaps [rsp], xmm1
00007a40685e19c8  movaps [rsp+0x10], xmm8
00007a40685e19ce  movaps [rsp+0x20], xmm9
00007a40685e19d4  lea rdi, [rsp]
00007a40685e19d8  mov esi, 0x00
00007a40685e19dd  mov rax, 0x56F679577530
00007a40685e19e7  call rax
00007a40685e19e9  movaps xmm1, [rsp]
00007a40685e19ed  add rsp, 0x30
00007a40685e19f1  vmovaps xmm0, [rsp]
00007a40685e19f6  vmovaps xmm2, [rsp+0x10]
00007a40685e19fc  vmovaps xmm3, [rsp+0x20]
00007a40685e1a02  vmovaps xmm4, [rsp+0x30]
00007a40685e1a08  vmovaps xmm5, [rsp+0x40]
00007a40685e1a0e  vmovaps xmm6, [rsp+0x50]
00007a40685e1a14  vmovaps xmm7, [rsp+0x60]
00007a40685e1a1a  vmovaps xmm8, [rsp+0x70]
00007a40685e1a20  vmovaps xmm9, [rsp+0x80]
00007a40685e1a29  vmovaps xmm10, [rsp+0x90]
00007a40685e1a32  vmovaps xmm11, [rsp+0xA0]
00007a40685e1a3b  vmovaps xmm12, [rsp+0xB0]
00007a40685e1a44  vmovaps xmm13, [rsp+0xC0]
00007a40685e1a4d  vmovaps xmm14, [rsp+0xD0]
00007a40685e1a56  vmovaps xmm15, [rsp+0xE0]
00007a40685e1a5f  add rsp, 0xF0
00007a40685e1a66  pop r11
00007a40685e1a68  pop r10
00007a40685e1a6a  pop r9
00007a40685e1a6c  pop r8
00007a40685e1a6e  pop rsi
00007a40685e1a6f  pop rdi
00007a40685e1a70  pop rdx
00007a40685e1a71  pop rcx
00007a40685e1a72  pop rax
00007a40685e1a73  add rsp, 0x08
00007a40685e1a77  jmp 0x00007A40685DC865
00007a40685e1a7c  call 0x00007A40684E5940
00007a40685e1a81  jmp 0x00007A40685DC873
00007a40685e1a86  call 0x00007A406840C380
00007a40685e1a8b  jmp 0x00007A40685DC87D
00007a40685e1a90  call 0x00007A406840D600
00007a40685e1a95  jmp 0x00007A40685DC887
00007a40685e1a9a  call 0x00007A40683FF540
00007a40685e1a9f  jmp 0x00007A40685DC891
00007a40685e1aa4  int3
00007a40685e1aa5  nop [rax+rax*1], ax
00007a40685e1aae  nop
00007a40685e1ab0  mov rax, [r15+0xF8]
00007a40685e1ab7  lea r14, [rax+0x140]
00007a40685e1abe  mov r12, [r13+r14*1]
00007a40685e1ac3  mov [r15+0xE8], r12
00007a40685e1aca  lea r14, [rax+0x130]
00007a40685e1ad1  mov r12, [r13+r14*1]
00007a40685e1ad6  lea r14, [rax+0x138]
00007a40685e1add  mov r11, [r13+r14*1]
00007a40685e1ae2  movq xmm1, r12
00007a40685e1ae7  movq xmm15, r11
00007a40685e1aec  movq xmm1, xmm1
00007a40685e1af0  movq xmm1, xmm1
00007a40685e1af4  movaps [r15+0x1A0], xmm1
00007a40685e1afc  movq xmm15, xmm15
00007a40685e1b01  movq xmm15, xmm15
00007a40685e1b06  movaps [r15+0x190], xmm15
00007a40685e1b0e  lea r14, [rax+0x120]
00007a40685e1b15  mov r12, [r13+r14*1]
00007a40685e1b1a  lea r14, [rax+0x128]
00007a40685e1b21  mov r11, [r13+r14*1]
00007a40685e1b26  movq xmm1, r12
00007a40685e1b2b  movq xmm15, r11
00007a40685e1b30  movq xmm1, xmm1
00007a40685e1b34  movq xmm1, xmm1
00007a40685e1b38  movaps [r15+0x1C0], xmm1
00007a40685e1b40  movq xmm15, xmm15
00007a40685e1b45  movq xmm15, xmm15
00007a40685e1b4a  movaps [r15+0x1B0], xmm15
00007a40685e1b52  lea r14, [rax+0x110]
00007a40685e1b59  mov r12, [r13+r14*1]
00007a40685e1b5e  lea r14, [rax+0x118]
00007a40685e1b65  mov r11, [r13+r14*1]
00007a40685e1b6a  movq xmm1, r12
00007a40685e1b6f  movq xmm15, r11
00007a40685e1b74  movq xmm1, xmm1
00007a40685e1b78  movq xmm1, xmm1
00007a40685e1b7c  movaps [r15+0x1E0], xmm1
00007a40685e1b84  movq xmm15, xmm15
00007a40685e1b89  movq xmm15, xmm15
00007a40685e1b8e  movaps [r15+0x1D0], xmm15
00007a40685e1b96  lea r14, [rax+0x100]
00007a40685e1b9d  mov r12, [r13+r14*1]
00007a40685e1ba2  lea r14, [rax+0x108]
00007a40685e1ba9  mov r11, [r13+r14*1]
00007a40685e1bae  movq xmm1, r12
00007a40685e1bb3  movq xmm15, r11
00007a40685e1bb8  movq xmm1, xmm1
00007a40685e1bbc  movq xmm1, xmm1
00007a40685e1bc0  movaps [r15+0x200], xmm1
00007a40685e1bc8  movq xmm15, xmm15
00007a40685e1bcd  movq xmm15, xmm15
00007a40685e1bd2  movaps [r15+0x1F0], xmm15
00007a40685e1bda  mov qword ptr [r15+0x40], 0x430000
00007a40685e1be2  mov r14d, 0x430510
00007a40685e1be8  mov r12, [r13+r14*1]
00007a40685e1bed  movq xmm1, r12
00007a40685e1bf2  lea r14, [rax+0x150]
00007a40685e1bf9  mov [r15+0xF8], r14
00007a40685e1c00  mov rax, [r15+0x50]
00007a40685e1c04  movups xmm15, [r13+rax*1]
00007a40685e1c0a  movaps [r15+0x120], xmm15
00007a40685e1c12  mov qword ptr [r15+0x48], 0x10
00007a40685e1c1a  xor eax, eax
00007a40685e1c1c  mov r14d, 0x10
00007a40685e1c22  mov r12d, 0x200
00007a40685e1c28  cmp r14, r12
00007a40685e1c2b  cmc
00007a40685e1c2c  lahf
00007a40685e1c2d  seto al
00007a40685e1c30  mov [r15+0x108], eax
00007a40685e1c37  pextrq rax, xmm15, 0x01
00007a40685e1c3e  movq xmm14, rax
00007a40685e1c43  movaps [r15+0x130], xmm14
00007a40685e1c4b  movq rax, xmm1
00007a40685e1c50  movq r14, xmm15
00007a40685e1c55  vmovq xmm1, rax
00007a40685e1c5a  vmovq xmm15, r14
00007a40685e1c5f  movaps xmm13, xmm1
00007a40685e1c63  addsd xmm13, xmm15
00007a40685e1c68  ucomisd xmm13, xmm13
00007a40685e1c6d  jp 0x00007A40685E1D86
00007a40685e1c73  movq xmm13, xmm13
00007a40685e1c78  movq rax, xmm13
00007a40685e1c7d  movq r14, xmm14
00007a40685e1c82  vmovq xmm1, rax
00007a40685e1c87  vmovq xmm15, r14
00007a40685e1c8c  movaps xmm14, xmm1
00007a40685e1c90  addsd xmm14, xmm15
00007a40685e1c95  ucomisd xmm14, xmm14
00007a40685e1c9a  jp 0x00007A40685E1DCE
00007a40685e1ca0  movq xmm14, xmm14
00007a40685e1ca5  movaps [r15+0x110], xmm14
00007a40685e1cad  mov eax, [r15+0x108]
00007a40685e1cb4  sahf
00007a40685e1cb5  jnz 0x00007A40685E1CE7
00007a40685e1cb7  cmp dword ptr [r15+0x318], 0x00
00007a40685e1cbf  jz 0x00007A40685E1FE0
00007a40685e1cc5  nop [rax+rax*1], ax
00007a40685e1cce  nop [rax+rax*1], eax
00007a40685e1cd6  mov eax, 0x410490
00007a40685e1cdb  mov [r15+0x100], rax
00007a40685e1ce2  jmp 0x00007A40683FE110
00007a40685e1ce7  cmp dword ptr [r15+0x318], 0x00
00007a40685e1cef  jz 0x00007A40685E1E20
00007a40685e1cf5  nop [rax+rax*1], ax
00007a40685e1cfe  nop [rax+rax*1], eax
00007a40685e1d06  mov eax, 0x410474
00007a40685e1d0b  mov [r15+0x100], rax
00007a40685e1d12  jmp 0x00007A40683FE110
00007a40685e1d17  int3
00007a40685e1d18  call 0x00007A40684E27E0
00007a40685e1d1d  jmp 0x00007A40685E1AC3
00007a40685e1d22  call 0x00007A40684E27E0
00007a40685e1d27  jmp 0x00007A40685E1AD6
00007a40685e1d2c  call 0x00007A40684E1570
00007a40685e1d31  jmp 0x00007A40685E1AE2
00007a40685e1d36  call 0x00007A40684E27E0
00007a40685e1d3b  jmp 0x00007A40685E1B1A
00007a40685e1d40  call 0x00007A40684E1570
00007a40685e1d45  jmp 0x00007A40685E1B26
00007a40685e1d4a  call 0x00007A40684E27E0
00007a40685e1d4f  jmp 0x00007A40685E1B5E
00007a40685e1d54  call 0x00007A40684E1570
00007a40685e1d59  jmp 0x00007A40685E1B6A
00007a40685e1d5e  call 0x00007A40684E27E0
00007a40685e1d63  jmp 0x00007A40685E1BA2
00007a40685e1d68  call 0x00007A40684E1570
00007a40685e1d6d  jmp 0x00007A40685E1BAE
00007a40685e1d72  call 0x00007A40684E27E0
00007a40685e1d77  jmp 0x00007A40685E1BED
00007a40685e1d7c  call 0x00007A406840E760
00007a40685e1d81  jmp 0x00007A40685E1C0A
00007a40685e1d86  ucomisd xmm1, xmm15
00007a40685e1d8b  jp 0x00007A40685E1D9A
00007a40685e1d8d  movaps xmm13, [0x00007A40681FE060]
00007a40685e1d95  jmp 0x00007A40685E1C73
00007a40685e1d9a  vxorps xmm0, xmm1, xmm15
00007a40685e1d9f  pextrw eax, xmm0, 0x03
00007a40685e1da4  and eax, 0x7FF8
00007a40685e1da9  cmp eax, 0x08
00007a40685e1dac  jnz 0x00007A40685E1C73
00007a40685e1db2  movq rax, xmm15
00007a40685e1db7  shl rax, 0x0D
00007a40685e1dbb  jbe 0x00007A40685E1C73
00007a40685e1dc1  vorps xmm13, xmm15, [0x00007A40681FE070]
00007a40685e1dc9  jmp 0x00007A40685E1C73
00007a40685e1dce  ucomisd xmm1, xmm15
00007a40685e1dd3  jp 0x00007A40685E1DE2
00007a40685e1dd5  movaps xmm14, [0x00007A40681FE060]
00007a40685e1ddd  jmp 0x00007A40685E1CA0
00007a40685e1de2  vxorps xmm0, xmm1, xmm15
00007a40685e1de7  pextrw eax, xmm0, 0x03
00007a40685e1dec  and eax, 0x7FF8
00007a40685e1df1  cmp eax, 0x08
00007a40685e1df4  jnz 0x00007A40685E1CA0
00007a40685e1dfa  movq rax, xmm15
00007a40685e1dff  shl rax, 0x0D
00007a40685e1e03  jbe 0x00007A40685E1CA0
00007a40685e1e09  vorps xmm14, xmm15, [0x00007A40681FE070]
00007a40685e1e11  jmp 0x00007A40685E1CA0
00007a40685e1e16  int3
00007a40685e1e17  nop [rax+rax*1], ax
00007a40685e1e20  mov rax, [r15+0x48]
00007a40685e1e24  mov r14, [r15+0x50]
00007a40685e1e28  lea r12, [r14+rax*1]
00007a40685e1e2c  movups xmm1, [r13+r12*1]
00007a40685e1e32  movaps [r15+0x120], xmm1
00007a40685e1e3a  lea r14, [rax+0x10]
00007a40685e1e3e  mov [r15+0x48], r14
00007a40685e1e42  xor eax, eax
00007a40685e1e44  mov r12d, 0x200
00007a40685e1e4a  cmp r14, r12
00007a40685e1e4d  cmc
00007a40685e1e4e  lahf
00007a40685e1e4f  seto al
00007a40685e1e52  mov [r15+0x108], eax
00007a40685e1e59  pextrq rax, xmm1, 0x01
00007a40685e1e60  movq xmm15, rax
00007a40685e1e65  movaps [r15+0x130], xmm15
00007a40685e1e6d  movaps xmm14, [r15+0x110]
00007a40685e1e75  movq rax, xmm14
00007a40685e1e7a  movq r14, xmm1
00007a40685e1e7f  vmovq xmm1, rax
00007a40685e1e84  vmovq xmm14, r14
00007a40685e1e89  movaps xmm13, xmm1
00007a40685e1e8d  addsd xmm13, xmm14
00007a40685e1e92  ucomisd xmm13, xmm13
00007a40685e1e97  jp 0x00007A40685E1F4C
00007a40685e1e9d  movq xmm13, xmm13
00007a40685e1ea2  movq rax, xmm13
00007a40685e1ea7  movq r14, xmm15
00007a40685e1eac  vmovq xmm1, rax
00007a40685e1eb1  vmovq xmm15, r14
00007a40685e1eb6  movaps xmm14, xmm1
00007a40685e1eba  addsd xmm14, xmm15
00007a40685e1ebf  ucomisd xmm14, xmm14
00007a40685e1ec4  jp 0x00007A40685E1F94
00007a40685e1eca  movq xmm14, xmm14
00007a40685e1ecf  movaps [r15+0x110], xmm14
00007a40685e1ed7  mov eax, [r15+0x108]
00007a40685e1ede  sahf
00007a40685e1edf  jnz 0x00007A40685E1F11
00007a40685e1ee1  cmp dword ptr [r15+0x318], 0x00
00007a40685e1ee9  jz 0x00007A40685E1FE0
00007a40685e1eef  nop [rax+rax*1], ax
00007a40685e1ef8  nop [rax+rax*1], eax
00007a40685e1f00  mov eax, 0x410490
00007a40685e1f05  mov [r15+0x100], rax
00007a40685e1f0c  jmp 0x00007A40683FE110
00007a40685e1f11  cmp dword ptr [r15+0x318], 0x00
00007a40685e1f19  jz 0x00007A40685E1E20
00007a40685e1f1f  nop [rax+rax*1], ax
00007a40685e1f28  nop [rax+rax*1], eax
00007a40685e1f30  mov eax, 0x410474
00007a40685e1f35  mov [r15+0x100], rax
00007a40685e1f3c  jmp 0x00007A40683FE110
00007a40685e1f41  int3
00007a40685e1f42  call 0x00007A40684B52F0
00007a40685e1f47  jmp 0x00007A40685E1E32
00007a40685e1f4c  ucomisd xmm1, xmm14
00007a40685e1f51  jp 0x00007A40685E1F60
00007a40685e1f53  movaps xmm13, [0x00007A40681FE060]
00007a40685e1f5b  jmp 0x00007A40685E1E9D
00007a40685e1f60  vxorps xmm0, xmm1, xmm14
00007a40685e1f65  pextrw eax, xmm0, 0x03
00007a40685e1f6a  and eax, 0x7FF8
00007a40685e1f6f  cmp eax, 0x08
00007a40685e1f72  jnz 0x00007A40685E1E9D
00007a40685e1f78  movq rax, xmm14
00007a40685e1f7d  shl rax, 0x0D
00007a40685e1f81  jbe 0x00007A40685E1E9D
00007a40685e1f87  vorps xmm13, xmm14, [0x00007A40681FE070]
00007a40685e1f8f  jmp 0x00007A40685E1E9D
00007a40685e1f94  ucomisd xmm1, xmm15
00007a40685e1f99  jp 0x00007A40685E1FA8
00007a40685e1f9b  movaps xmm14, [0x00007A40681FE060]
00007a40685e1fa3  jmp 0x00007A40685E1ECA
00007a40685e1fa8  vxorps xmm0, xmm1, xmm15
00007a40685e1fad  pextrw eax, xmm0, 0x03
00007a40685e1fb2  and eax, 0x7FF8
00007a40685e1fb7  cmp eax, 0x08
00007a40685e1fba  jnz 0x00007A40685E1ECA
00007a40685e1fc0  movq rax, xmm15
00007a40685e1fc5  shl rax, 0x0D
00007a40685e1fc9  jbe 0x00007A40685E1ECA
00007a40685e1fcf  vorps xmm14, xmm15, [0x00007A40681FE070]
00007a40685e1fd7  jmp 0x00007A40685E1ECA
00007a40685e1fdc  int3
00007a40685e1fdd  nop [rax], eax
00007a40685e1fe0  mov rax, [r15+0x40]
00007a40685e1fe4  lea r14, [rax+0x510]
00007a40685e1feb  movaps xmm1, [r15+0x110]
00007a40685e1ff3  movq rax, xmm1
00007a40685e1ff8  mov [r13+r14*1], rax
00007a40685e1ffd  mov rax, [r15+0xF0]
00007a40685e2004  mov [r15+0x100], rax
00007a40685e200b  jmp 0x00007A40685CE5C0
00007a40685e2010  int3
00007a40685e2011  call 0x00007A40684D5EB0
00007a40685e2016  jmp 0x00007A40685E1FFD
00007a40685e201b  int3
00007a40685e201c  nop [rax], eax
00007a40685e2020  mov qword ptr [r15+0x100], 0x04
00007a40685e202b  mov esi, 0x00
00007a40685e2030  mov edx, 0x09
00007a40685e2035  mov rdi, 0x7FFC94D77E70
00007a40685e203f  mov rax, 0x56F67940A970
00007a40685e2049  call rax
00007a40685e204b  cmp dword ptr [r15+0x318], 0x00
00007a40685e2053  jnz 0x00007A40683FE110
00007a40685e2059  jmp 0x00007A40683FE0A0
00007a40685e205e  int3
00007a40685e205f  int3
