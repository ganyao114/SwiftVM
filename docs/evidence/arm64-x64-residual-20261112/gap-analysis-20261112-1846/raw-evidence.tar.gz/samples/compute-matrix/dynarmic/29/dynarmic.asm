00007d5be8fce69b  nop [rax+rax*1], eax
00007d5be8fce6a0  vmovaps xmm1, [0x00007D5BE8BFE010]
00007d5be8fce6a8  movq xmm1, xmm1
00007d5be8fce6ac  movaps [r15+0x110], xmm1
00007d5be8fce6b4  vmovaps xmm1, [0x00007D5BE8BFE020]
00007d5be8fce6bc  movq xmm1, xmm1
00007d5be8fce6c0  movaps [r15+0x120], xmm1
00007d5be8fce6c8  mov eax, 0x4204C0
00007d5be8fce6cd  mov r14, [r13+rax*1]
00007d5be8fce6d2  movq xmm1, r14
00007d5be8fce6d7  movaps [r15+0x130], xmm1
00007d5be8fce6df  vmovaps xmm1, [0x00007D5BE8BFE030]
00007d5be8fce6e7  vpbroadcastq xmm1, xmm1
00007d5be8fce6ec  movaps [r15+0x140], xmm1
00007d5be8fce6f4  mov qword ptr [r15+0x40], 0x02
00007d5be8fce6fc  vmovaps xmm15, [0x00007D5BE8BFE040]
00007d5be8fce704  movq xmm15, xmm15
00007d5be8fce709  movaps [r15+0x150], xmm15
00007d5be8fce711  mov qword ptr [r15+0x58], 0x420000
00007d5be8fce719  vmovaps xmm15, [0x00007D5BE8BFE050]
00007d5be8fce721  vpbroadcastq xmm15, xmm15
00007d5be8fce726  movaps [r15+0x160], xmm15
00007d5be8fce72e  mov rax, [r15+0x40]
00007d5be8fce732  vmovq xmm14, rax
00007d5be8fce737  vpbroadcastq xmm14, xmm14
00007d5be8fce73c  movaps [r15+0x170], xmm14
00007d5be8fce744  mov eax, 0x4204D0
00007d5be8fce749  movups xmm13, [r13+rax*1]
00007d5be8fce74f  mov qword ptr [r15+0x40], 0x430518
00007d5be8fce757  mov qword ptr [r15+0x50], 0x430720
00007d5be8fce75f  vpmovqd xmm12, xmm13
00007d5be8fce765  pxor xmm11, xmm11
00007d5be8fce76a  punpcklqdq xmm12, xmm11
00007d5be8fce76f  movaps [r15+0x210], xmm12
00007d5be8fce777  movq xmm12, qword ptr [r15+0x120]
00007d5be8fce780  movq xmm11, qword ptr [r15+0x130]
00007d5be8fce789  psubd xmm12, xmm11
00007d5be8fce78e  movq xmm12, xmm12
00007d5be8fce793  paddq xmm13, xmm14
00007d5be8fce798  movaps [r15+0x180], xmm13
00007d5be8fce7a0  movq xmm14, qword ptr [r15+0x150]
00007d5be8fce7a9  paddd xmm11, xmm14
00007d5be8fce7ae  movq xmm11, xmm11
00007d5be8fce7b3  movq xmm11, xmm11
00007d5be8fce7b8  movaps [r15+0x130], xmm11
00007d5be8fce7c0  pmovzxdq xmm12, xmm12
00007d5be8fce7c6  psllq xmm12, 0x00
00007d5be8fce7cc  movq xmm14, qword ptr [r15+0x210]
00007d5be8fce7d5  movq xmm13, qword ptr [r15+0x110]
00007d5be8fce7de  paddd xmm14, xmm13
00007d5be8fce7e3  movq xmm14, xmm14
00007d5be8fce7e8  vcvtuqq2pd xmm12, xmm12
00007d5be8fce7ee  pmovzxdq xmm14, xmm14
00007d5be8fce7f4  psllq xmm14, 0x00
00007d5be8fce7fa  vcvtuqq2pd xmm14, xmm14
00007d5be8fce800  movaps xmm13, xmm12
00007d5be8fce804  mulpd xmm13, xmm1
00007d5be8fce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007d5be8fce80f  ptest xmm11, xmm11
00007d5be8fce815  jnz 0x00007D5BE8FCE8FF
00007d5be8fce81b  movaps [r15+0x220], xmm13
00007d5be8fce823  mov eax, 0x430720
00007d5be8fce828  movups [r13+rax*1], xmm13
00007d5be8fce82e  movaps xmm1, xmm14
00007d5be8fce832  mulpd xmm1, xmm15
00007d5be8fce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007d5be8fce83c  ptest xmm13, xmm13
00007d5be8fce842  jnz 0x00007D5BE8FCEA4C
00007d5be8fce848  movaps [r15+0x210], xmm1
00007d5be8fce850  mov eax, 0x430518
00007d5be8fce855  movups [r13+rax*1], xmm1
00007d5be8fce85b  mov qword ptr [r15+0x48], 0x10
00007d5be8fce863  xor eax, eax
00007d5be8fce865  mov r14d, 0x10
00007d5be8fce86b  mov r12d, 0x200
00007d5be8fce871  cmp r14, r12
00007d5be8fce874  cmc
00007d5be8fce875  lahf
00007d5be8fce876  seto al
00007d5be8fce879  mov [r15+0x108], eax
00007d5be8fce880  mov eax, [r15+0x108]
00007d5be8fce887  sahf
00007d5be8fce888  jnz 0x00007D5BE8FCE8BA
00007d5be8fce88a  cmp dword ptr [r15+0x318], 0x00
00007d5be8fce892  jz 0x00007D5BE8FCEFF0
00007d5be8fce898  nop [rax+rax*1], ax
00007d5be8fce8a1  nop [rax+rax*1], eax
00007d5be8fce8a9  mov eax, 0x4101EC
00007d5be8fce8ae  mov [r15+0x100], rax
00007d5be8fce8b5  jmp 0x00007D5BE8DFE110
00007d5be8fce8ba  cmp dword ptr [r15+0x318], 0x00
00007d5be8fce8c2  jz 0x00007D5BE8FCEBA0
00007d5be8fce8c8  nop [rax+rax*1], ax
00007d5be8fce8d1  nop [rax+rax*1], eax
00007d5be8fce8d9  mov eax, 0x4101AC
00007d5be8fce8de  mov [r15+0x100], rax
00007d5be8fce8e5  jmp 0x00007D5BE8DFE110
00007d5be8fce8ea  int3
00007d5be8fce8eb  call 0x00007D5BE8E0DC20
00007d5be8fce8f0  jmp 0x00007D5BE8FCE6D2
00007d5be8fce8f5  call 0x00007D5BE8E0C260
00007d5be8fce8fa  jmp 0x00007D5BE8FCE74F
00007d5be8fce8ff  sub rsp, 0x08
00007d5be8fce903  push rax
00007d5be8fce904  push rcx
00007d5be8fce905  push rdx
00007d5be8fce906  push rdi
00007d5be8fce907  push rsi
00007d5be8fce908  push r8
00007d5be8fce90a  push r9
00007d5be8fce90c  push r10
00007d5be8fce90e  push r11
00007d5be8fce910  sub rsp, 0xF0
00007d5be8fce917  vmovaps [rsp], xmm0
00007d5be8fce91c  vmovaps [rsp+0x10], xmm1
00007d5be8fce922  vmovaps [rsp+0x20], xmm2
00007d5be8fce928  vmovaps [rsp+0x30], xmm3
00007d5be8fce92e  vmovaps [rsp+0x40], xmm4
00007d5be8fce934  vmovaps [rsp+0x50], xmm5
00007d5be8fce93a  vmovaps [rsp+0x60], xmm6
00007d5be8fce940  vmovaps [rsp+0x70], xmm7
00007d5be8fce946  vmovaps [rsp+0x80], xmm8
00007d5be8fce94f  vmovaps [rsp+0x90], xmm9
00007d5be8fce958  vmovaps [rsp+0xA0], xmm10
00007d5be8fce961  vmovaps [rsp+0xB0], xmm11
00007d5be8fce96a  vmovaps [rsp+0xC0], xmm12
00007d5be8fce973  vmovaps [rsp+0xD0], xmm14
00007d5be8fce97c  vmovaps [rsp+0xE0], xmm15
00007d5be8fce985  sub rsp, 0x30
00007d5be8fce989  movaps [rsp], xmm13
00007d5be8fce98e  movaps [rsp+0x10], xmm12
00007d5be8fce994  movaps [rsp+0x20], xmm1
00007d5be8fce999  lea rdi, [rsp]
00007d5be8fce99d  mov esi, 0x00
00007d5be8fce9a2  mov rax, 0x5D345705A530
00007d5be8fce9ac  call rax
00007d5be8fce9ae  movaps xmm13, [rsp]
00007d5be8fce9b3  add rsp, 0x30
00007d5be8fce9b7  vmovaps xmm0, [rsp]
00007d5be8fce9bc  vmovaps xmm1, [rsp+0x10]
00007d5be8fce9c2  vmovaps xmm2, [rsp+0x20]
00007d5be8fce9c8  vmovaps xmm3, [rsp+0x30]
00007d5be8fce9ce  vmovaps xmm4, [rsp+0x40]
00007d5be8fce9d4  vmovaps xmm5, [rsp+0x50]
00007d5be8fce9da  vmovaps xmm6, [rsp+0x60]
00007d5be8fce9e0  vmovaps xmm7, [rsp+0x70]
00007d5be8fce9e6  vmovaps xmm8, [rsp+0x80]
00007d5be8fce9ef  vmovaps xmm9, [rsp+0x90]
00007d5be8fce9f8  vmovaps xmm10, [rsp+0xA0]
00007d5be8fcea01  vmovaps xmm11, [rsp+0xB0]
00007d5be8fcea0a  vmovaps xmm12, [rsp+0xC0]
00007d5be8fcea13  vmovaps xmm14, [rsp+0xD0]
00007d5be8fcea1c  vmovaps xmm15, [rsp+0xE0]
00007d5be8fcea25  add rsp, 0xF0
00007d5be8fcea2c  pop r11
00007d5be8fcea2e  pop r10
00007d5be8fcea30  pop r9
00007d5be8fcea32  pop r8
00007d5be8fcea34  pop rsi
00007d5be8fcea35  pop rdi
00007d5be8fcea36  pop rdx
00007d5be8fcea37  pop rcx
00007d5be8fcea38  pop rax
00007d5be8fcea39  add rsp, 0x08
00007d5be8fcea3d  jmp 0x00007D5BE8FCE81B
00007d5be8fcea42  call 0x00007D5BE8E0C380
00007d5be8fcea47  jmp 0x00007D5BE8FCE82E
00007d5be8fcea4c  sub rsp, 0x08
00007d5be8fcea50  push rax
00007d5be8fcea51  push rcx
00007d5be8fcea52  push rdx
00007d5be8fcea53  push rdi
00007d5be8fcea54  push rsi
00007d5be8fcea55  push r8
00007d5be8fcea57  push r9
00007d5be8fcea59  push r10
00007d5be8fcea5b  push r11
00007d5be8fcea5d  sub rsp, 0xF0
00007d5be8fcea64  vmovaps [rsp], xmm0
00007d5be8fcea69  vmovaps [rsp+0x10], xmm2
00007d5be8fcea6f  vmovaps [rsp+0x20], xmm3
00007d5be8fcea75  vmovaps [rsp+0x30], xmm4
00007d5be8fcea7b  vmovaps [rsp+0x40], xmm5
00007d5be8fcea81  vmovaps [rsp+0x50], xmm6
00007d5be8fcea87  vmovaps [rsp+0x60], xmm7
00007d5be8fcea8d  vmovaps [rsp+0x70], xmm8
00007d5be8fcea93  vmovaps [rsp+0x80], xmm9
00007d5be8fcea9c  vmovaps [rsp+0x90], xmm10
00007d5be8fceaa5  vmovaps [rsp+0xA0], xmm11
00007d5be8fceaae  vmovaps [rsp+0xB0], xmm12
00007d5be8fceab7  vmovaps [rsp+0xC0], xmm13
00007d5be8fceac0  vmovaps [rsp+0xD0], xmm14
00007d5be8fceac9  vmovaps [rsp+0xE0], xmm15
00007d5be8fcead2  sub rsp, 0x30
00007d5be8fcead6  movaps [rsp], xmm1
00007d5be8fceada  movaps [rsp+0x10], xmm14
00007d5be8fceae0  movaps [rsp+0x20], xmm15
00007d5be8fceae6  lea rdi, [rsp]
00007d5be8fceaea  mov esi, 0x00
00007d5be8fceaef  mov rax, 0x5D345705A530
00007d5be8fceaf9  call rax
00007d5be8fceafb  movaps xmm1, [rsp]
00007d5be8fceaff  add rsp, 0x30
00007d5be8fceb03  vmovaps xmm0, [rsp]
00007d5be8fceb08  vmovaps xmm2, [rsp+0x10]
00007d5be8fceb0e  vmovaps xmm3, [rsp+0x20]
00007d5be8fceb14  vmovaps xmm4, [rsp+0x30]
00007d5be8fceb1a  vmovaps xmm5, [rsp+0x40]
00007d5be8fceb20  vmovaps xmm6, [rsp+0x50]
00007d5be8fceb26  vmovaps xmm7, [rsp+0x60]
00007d5be8fceb2c  vmovaps xmm8, [rsp+0x70]
00007d5be8fceb32  vmovaps xmm9, [rsp+0x80]
00007d5be8fceb3b  vmovaps xmm10, [rsp+0x90]
00007d5be8fceb44  vmovaps xmm11, [rsp+0xA0]
00007d5be8fceb4d  vmovaps xmm12, [rsp+0xB0]
00007d5be8fceb56  vmovaps xmm13, [rsp+0xC0]
00007d5be8fceb5f  vmovaps xmm14, [rsp+0xD0]
00007d5be8fceb68  vmovaps xmm15, [rsp+0xE0]
00007d5be8fceb71  add rsp, 0xF0
00007d5be8fceb78  pop r11
00007d5be8fceb7a  pop r10
00007d5be8fceb7c  pop r9
00007d5be8fceb7e  pop r8
00007d5be8fceb80  pop rsi
00007d5be8fceb81  pop rdi
00007d5be8fceb82  pop rdx
00007d5be8fceb83  pop rcx
00007d5be8fceb84  pop rax
00007d5be8fceb85  add rsp, 0x08
00007d5be8fceb89  jmp 0x00007D5BE8FCE848
00007d5be8fceb8e  call 0x00007D5BE8DFF540
00007d5be8fceb93  jmp 0x00007D5BE8FCE85B
00007d5be8fceb98  int3
00007d5be8fceb99  nop [rax], eax
00007d5be8fceba0  movaps xmm1, [r15+0x180]
00007d5be8fceba8  vpmovqd xmm15, xmm1
00007d5be8fcebae  pxor xmm14, xmm14
00007d5be8fcebb3  punpcklqdq xmm15, xmm14
00007d5be8fcebb8  movaps [r15+0x210], xmm15
00007d5be8fcebc0  movq xmm15, qword ptr [r15+0x120]
00007d5be8fcebc9  movq xmm14, qword ptr [r15+0x130]
00007d5be8fcebd2  psubd xmm15, xmm14
00007d5be8fcebd7  movq xmm15, xmm15
00007d5be8fcebdc  movaps xmm13, [r15+0x170]
00007d5be8fcebe4  paddq xmm1, xmm13
00007d5be8fcebe9  movaps [r15+0x180], xmm1
00007d5be8fcebf1  movq xmm1, qword ptr [r15+0x150]
00007d5be8fcebfa  paddd xmm14, xmm1
00007d5be8fcebff  movq xmm14, xmm14
00007d5be8fcec04  movq xmm14, xmm14
00007d5be8fcec09  movaps [r15+0x130], xmm14
00007d5be8fcec11  pmovzxdq xmm15, xmm15
00007d5be8fcec17  psllq xmm15, 0x00
00007d5be8fcec1d  movq xmm1, qword ptr [r15+0x210]
00007d5be8fcec26  movq xmm14, qword ptr [r15+0x110]
00007d5be8fcec2f  paddd xmm1, xmm14
00007d5be8fcec34  movq xmm1, xmm1
00007d5be8fcec38  vcvtuqq2pd xmm15, xmm15
00007d5be8fcec3e  pmovzxdq xmm1, xmm1
00007d5be8fcec43  psllq xmm1, 0x00
00007d5be8fcec48  vcvtuqq2pd xmm1, xmm1
00007d5be8fcec4e  movaps xmm14, [r15+0x140]
00007d5be8fcec56  movaps xmm13, xmm15
00007d5be8fcec5a  mulpd xmm13, xmm14
00007d5be8fcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007d5be8fcec65  ptest xmm12, xmm12
00007d5be8fcec6b  jnz 0x00007D5BE8FCED4E
00007d5be8fcec71  movaps [r15+0x220], xmm13
00007d5be8fcec79  mov rax, [r15+0x48]
00007d5be8fcec7d  mov r14, [r15+0x50]
00007d5be8fcec81  lea r12, [r14+rax*1]
00007d5be8fcec85  movups [r13+r12*1], xmm13
00007d5be8fcec8b  movaps xmm15, [r15+0x160]
00007d5be8fcec93  movaps xmm14, xmm1
00007d5be8fcec97  mulpd xmm14, xmm15
00007d5be8fcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007d5be8fceca2  ptest xmm13, xmm13
00007d5be8fceca8  jnz 0x00007D5BE8FCEE9C
00007d5be8fcecae  movaps [r15+0x210], xmm14
00007d5be8fcecb6  mov r14, [r15+0x40]
00007d5be8fcecba  lea r12, [r14+rax*1]
00007d5be8fcecbe  movups [r13+r12*1], xmm14
00007d5be8fcecc4  lea r14, [rax+0x10]
00007d5be8fcecc8  mov [r15+0x48], r14
00007d5be8fceccc  xor eax, eax
00007d5be8fcecce  mov r12d, 0x200
00007d5be8fcecd4  cmp r14, r12
00007d5be8fcecd7  cmc
00007d5be8fcecd8  lahf
00007d5be8fcecd9  seto al
00007d5be8fcecdc  mov [r15+0x108], eax
00007d5be8fcece3  mov eax, [r15+0x108]
00007d5be8fcecea  sahf
00007d5be8fceceb  jnz 0x00007D5BE8FCED1D
00007d5be8fceced  cmp dword ptr [r15+0x318], 0x00
00007d5be8fcecf5  jz 0x00007D5BE8FCEFF0
00007d5be8fcecfb  nop [rax+rax*1], ax
00007d5be8fced04  nop [rax+rax*1], eax
00007d5be8fced0c  mov eax, 0x4101EC
00007d5be8fced11  mov [r15+0x100], rax
00007d5be8fced18  jmp 0x00007D5BE8DFE110
00007d5be8fced1d  cmp dword ptr [r15+0x318], 0x00
00007d5be8fced25  jz 0x00007D5BE8FCEBA0
00007d5be8fced2b  nop [rax+rax*1], ax
00007d5be8fced34  nop [rax+rax*1], eax
00007d5be8fced3c  mov eax, 0x4101AC
00007d5be8fced41  mov [r15+0x100], rax
00007d5be8fced48  jmp 0x00007D5BE8DFE110
00007d5be8fced4d  int3
00007d5be8fced4e  sub rsp, 0x08
00007d5be8fced52  push rax
00007d5be8fced53  push rcx
00007d5be8fced54  push rdx
00007d5be8fced55  push rdi
00007d5be8fced56  push rsi
00007d5be8fced57  push r8
00007d5be8fced59  push r9
00007d5be8fced5b  push r10
00007d5be8fced5d  push r11
00007d5be8fced5f  sub rsp, 0xF0
00007d5be8fced66  vmovaps [rsp], xmm0
00007d5be8fced6b  vmovaps [rsp+0x10], xmm1
00007d5be8fced71  vmovaps [rsp+0x20], xmm2
00007d5be8fced77  vmovaps [rsp+0x30], xmm3
00007d5be8fced7d  vmovaps [rsp+0x40], xmm4
00007d5be8fced83  vmovaps [rsp+0x50], xmm5
00007d5be8fced89  vmovaps [rsp+0x60], xmm6
00007d5be8fced8f  vmovaps [rsp+0x70], xmm7
00007d5be8fced95  vmovaps [rsp+0x80], xmm8
00007d5be8fced9e  vmovaps [rsp+0x90], xmm9
00007d5be8fceda7  vmovaps [rsp+0xA0], xmm10
00007d5be8fcedb0  vmovaps [rsp+0xB0], xmm11
00007d5be8fcedb9  vmovaps [rsp+0xC0], xmm12
00007d5be8fcedc2  vmovaps [rsp+0xD0], xmm14
00007d5be8fcedcb  vmovaps [rsp+0xE0], xmm15
00007d5be8fcedd4  sub rsp, 0x30
00007d5be8fcedd8  movaps [rsp], xmm13
00007d5be8fceddd  movaps [rsp+0x10], xmm15
00007d5be8fcede3  movaps [rsp+0x20], xmm14
00007d5be8fcede9  lea rdi, [rsp]
00007d5be8fceded  mov esi, 0x00
00007d5be8fcedf2  mov rax, 0x5D345705A530
00007d5be8fcedfc  call rax
00007d5be8fcedfe  movaps xmm13, [rsp]
00007d5be8fcee03  add rsp, 0x30
00007d5be8fcee07  vmovaps xmm0, [rsp]
00007d5be8fcee0c  vmovaps xmm1, [rsp+0x10]
00007d5be8fcee12  vmovaps xmm2, [rsp+0x20]
00007d5be8fcee18  vmovaps xmm3, [rsp+0x30]
00007d5be8fcee1e  vmovaps xmm4, [rsp+0x40]
00007d5be8fcee24  vmovaps xmm5, [rsp+0x50]
00007d5be8fcee2a  vmovaps xmm6, [rsp+0x60]
00007d5be8fcee30  vmovaps xmm7, [rsp+0x70]
00007d5be8fcee36  vmovaps xmm8, [rsp+0x80]
00007d5be8fcee3f  vmovaps xmm9, [rsp+0x90]
00007d5be8fcee48  vmovaps xmm10, [rsp+0xA0]
00007d5be8fcee51  vmovaps xmm11, [rsp+0xB0]
00007d5be8fcee5a  vmovaps xmm12, [rsp+0xC0]
00007d5be8fcee63  vmovaps xmm14, [rsp+0xD0]
00007d5be8fcee6c  vmovaps xmm15, [rsp+0xE0]
00007d5be8fcee75  add rsp, 0xF0
00007d5be8fcee7c  pop r11
00007d5be8fcee7e  pop r10
00007d5be8fcee80  pop r9
00007d5be8fcee82  pop r8
00007d5be8fcee84  pop rsi
00007d5be8fcee85  pop rdi
00007d5be8fcee86  pop rdx
00007d5be8fcee87  pop rcx
00007d5be8fcee88  pop rax
00007d5be8fcee89  add rsp, 0x08
00007d5be8fcee8d  jmp 0x00007D5BE8FCEC71
00007d5be8fcee92  call 0x00007D5BE8EC2240
00007d5be8fcee97  jmp 0x00007D5BE8FCEC8B
00007d5be8fcee9c  sub rsp, 0x08
00007d5be8fceea0  push rax
00007d5be8fceea1  push rcx
00007d5be8fceea2  push rdx
00007d5be8fceea3  push rdi
00007d5be8fceea4  push rsi
00007d5be8fceea5  push r8
00007d5be8fceea7  push r9
00007d5be8fceea9  push r10
00007d5be8fceeab  push r11
00007d5be8fceead  sub rsp, 0xF0
00007d5be8fceeb4  vmovaps [rsp], xmm0
00007d5be8fceeb9  vmovaps [rsp+0x10], xmm1
00007d5be8fceebf  vmovaps [rsp+0x20], xmm2
00007d5be8fceec5  vmovaps [rsp+0x30], xmm3
00007d5be8fceecb  vmovaps [rsp+0x40], xmm4
00007d5be8fceed1  vmovaps [rsp+0x50], xmm5
00007d5be8fceed7  vmovaps [rsp+0x60], xmm6
00007d5be8fceedd  vmovaps [rsp+0x70], xmm7
00007d5be8fceee3  vmovaps [rsp+0x80], xmm8
00007d5be8fceeec  vmovaps [rsp+0x90], xmm9
00007d5be8fceef5  vmovaps [rsp+0xA0], xmm10
00007d5be8fceefe  vmovaps [rsp+0xB0], xmm11
00007d5be8fcef07  vmovaps [rsp+0xC0], xmm12
00007d5be8fcef10  vmovaps [rsp+0xD0], xmm13
00007d5be8fcef19  vmovaps [rsp+0xE0], xmm15
00007d5be8fcef22  sub rsp, 0x30
00007d5be8fcef26  movaps [rsp], xmm14
00007d5be8fcef2b  movaps [rsp+0x10], xmm1
00007d5be8fcef30  movaps [rsp+0x20], xmm15
00007d5be8fcef36  lea rdi, [rsp]
00007d5be8fcef3a  mov esi, 0x00
00007d5be8fcef3f  mov rax, 0x5D345705A530
00007d5be8fcef49  call rax
00007d5be8fcef4b  movaps xmm14, [rsp]
00007d5be8fcef50  add rsp, 0x30
00007d5be8fcef54  vmovaps xmm0, [rsp]
00007d5be8fcef59  vmovaps xmm1, [rsp+0x10]
00007d5be8fcef5f  vmovaps xmm2, [rsp+0x20]
00007d5be8fcef65  vmovaps xmm3, [rsp+0x30]
00007d5be8fcef6b  vmovaps xmm4, [rsp+0x40]
00007d5be8fcef71  vmovaps xmm5, [rsp+0x50]
00007d5be8fcef77  vmovaps xmm6, [rsp+0x60]
00007d5be8fcef7d  vmovaps xmm7, [rsp+0x70]
00007d5be8fcef83  vmovaps xmm8, [rsp+0x80]
00007d5be8fcef8c  vmovaps xmm9, [rsp+0x90]
00007d5be8fcef95  vmovaps xmm10, [rsp+0xA0]
00007d5be8fcef9e  vmovaps xmm11, [rsp+0xB0]
00007d5be8fcefa7  vmovaps xmm12, [rsp+0xC0]
00007d5be8fcefb0  vmovaps xmm13, [rsp+0xD0]
00007d5be8fcefb9  vmovaps xmm15, [rsp+0xE0]
00007d5be8fcefc2  add rsp, 0xF0
00007d5be8fcefc9  pop r11
00007d5be8fcefcb  pop r10
00007d5be8fcefcd  pop r9
00007d5be8fcefcf  pop r8
00007d5be8fcefd1  pop rsi
00007d5be8fcefd2  pop rdi
00007d5be8fcefd3  pop rdx
00007d5be8fcefd4  pop rcx
00007d5be8fcefd5  pop rax
00007d5be8fcefd6  add rsp, 0x08
00007d5be8fcefda  jmp 0x00007D5BE8FCECAE
00007d5be8fcefdf  call 0x00007D5BE8EC34C0
00007d5be8fcefe4  jmp 0x00007D5BE8FCECC4
00007d5be8fcefe9  int3
00007d5be8fcefea  nop [rax+rax*1], ax
00007d5be8fceff0  mov rax, [r15+0xF8]
00007d5be8fceff7  lea r14, [rax-0x150]
00007d5be8fceffe  mov [r15+0xF8], r14
00007d5be8fcf005  mov rax, [r15+0x50]
00007d5be8fcf009  lea r12, [rax+0x80]
00007d5be8fcf010  movups xmm1, [r13+r12*1]
00007d5be8fcf016  lea r12, [rax+0x90]
00007d5be8fcf01d  movups xmm15, [r13+r12*1]
00007d5be8fcf023  mov qword ptr [r15+0x48], 0x00
00007d5be8fcf02b  lea r12, [rax+0x40]
00007d5be8fcf02f  movups xmm14, [r13+r12*1]
00007d5be8fcf035  lea r12, [rax+0x50]
00007d5be8fcf039  movups xmm13, [r13+r12*1]
00007d5be8fcf03f  lea r12, [r14+0x120]
00007d5be8fcf046  movq xmm12, qword ptr [r15+0x1C0]
00007d5be8fcf04f  movq xmm11, qword ptr [r15+0x1B0]
00007d5be8fcf058  movq r11, xmm12
00007d5be8fcf05d  movq r10, xmm11
00007d5be8fcf062  mov [r13+r12*1], r11
00007d5be8fcf067  lea r12, [r14+0x128]
00007d5be8fcf06e  mov [r13+r12*1], r10
00007d5be8fcf073  vxorps xmm12, xmm12, xmm12
00007d5be8fcf078  vpbroadcastq xmm12, xmm12
00007d5be8fcf07d  lea r12, [r14+0x100]
00007d5be8fcf084  movq xmm11, qword ptr [r15+0x200]
00007d5be8fcf08d  movq xmm10, qword ptr [r15+0x1F0]
00007d5be8fcf096  movq r11, xmm11
00007d5be8fcf09b  movq r10, xmm10
00007d5be8fcf0a0  mov [r13+r12*1], r11
00007d5be8fcf0a5  lea r12, [r14+0x108]
00007d5be8fcf0ac  mov [r13+r12*1], r10
00007d5be8fcf0b1  lea r12, [r14+0xE0]
00007d5be8fcf0b8  movups [r13+r12*1], xmm15
00007d5be8fcf0be  lea r12, [r14+0xF0]
00007d5be8fcf0c5  movups [r13+r12*1], xmm1
00007d5be8fcf0cb  lea r12, [rax+0xC0]
00007d5be8fcf0d2  movups xmm1, [r13+r12*1]
00007d5be8fcf0d8  lea r12, [rax+0xD0]
00007d5be8fcf0df  movups xmm15, [r13+r12*1]
00007d5be8fcf0e5  lea r12, [r14+0x110]
00007d5be8fcf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007d5be8fcf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007d5be8fcf0fe  movq r11, xmm11
00007d5be8fcf103  movq r10, xmm10
00007d5be8fcf108  mov [r13+r12*1], r11
00007d5be8fcf10d  lea r12, [r14+0x118]
00007d5be8fcf114  mov [r13+r12*1], r10
00007d5be8fcf119  movups xmm11, [r13+rax*1]
00007d5be8fcf11f  lea r12, [rax+0x10]
00007d5be8fcf123  movups xmm10, [r13+r12*1]
00007d5be8fcf129  lea r12, [r14+0x130]
00007d5be8fcf130  movq xmm9, qword ptr [r15+0x1A0]
00007d5be8fcf139  movq xmm8, qword ptr [r15+0x190]
00007d5be8fcf142  movq r11, xmm9
00007d5be8fcf147  movq r10, xmm8
00007d5be8fcf14c  mov [r13+r12*1], r11
00007d5be8fcf151  lea r12, [r14+0x138]
00007d5be8fcf158  mov [r13+r12*1], r10
00007d5be8fcf15d  lea r12, [rax+0x140]
00007d5be8fcf164  movups xmm9, [r13+r12*1]
00007d5be8fcf16a  lea r12, [rax+0x150]
00007d5be8fcf171  movups xmm8, [r13+r12*1]
00007d5be8fcf177  lea r12, [r14+0xC0]
00007d5be8fcf17e  movups [r13+r12*1], xmm15
00007d5be8fcf184  lea r12, [r14+0xD0]
00007d5be8fcf18b  movups [r13+r12*1], xmm1
00007d5be8fcf191  lea r12, [rax+0x100]
00007d5be8fcf198  movups xmm1, [r13+r12*1]
00007d5be8fcf19e  lea r12, [rax+0x110]
00007d5be8fcf1a5  movups xmm15, [r13+r12*1]
00007d5be8fcf1ab  lea r12, [r14+0x140]
00007d5be8fcf1b2  mov r11, [r15+0xE8]
00007d5be8fcf1b9  mov [r13+r12*1], r11
00007d5be8fcf1be  lea r12, [rax+0x180]
00007d5be8fcf1c5  movups xmm7, [r13+r12*1]
00007d5be8fcf1cb  lea r12, [rax+0x190]
00007d5be8fcf1d2  movups xmm6, [r13+r12*1]
00007d5be8fcf1d8  lea r12, [rax+0x1C0]
00007d5be8fcf1df  movups xmm5, [r13+r12*1]
00007d5be8fcf1e5  lea r12, [rax+0x1D0]
00007d5be8fcf1ec  movups xmm4, [r13+r12*1]
00007d5be8fcf1f2  lea r12, [r14+0x20]
00007d5be8fcf1f6  movups [r13+r12*1], xmm1
00007d5be8fcf1fc  lea r12, [r14+0x30]
00007d5be8fcf200  movups [r13+r12*1], xmm13
00007d5be8fcf206  lea r12, [rax+0x60]
00007d5be8fcf20a  movups xmm1, [r13+r12*1]
00007d5be8fcf210  lea r12, [rax+0x70]
00007d5be8fcf214  movups xmm13, [r13+r12*1]
00007d5be8fcf21a  lea r12, [rax+0x20]
00007d5be8fcf21e  movups xmm3, [r13+r12*1]
00007d5be8fcf224  lea r12, [rax+0x30]
00007d5be8fcf228  movups xmm2, [r13+r12*1]
00007d5be8fcf22e  movaps [r15+0x1F0], xmm2
00007d5be8fcf236  lea r12, [r14+0x60]
00007d5be8fcf23a  movups [r13+r12*1], xmm11
00007d5be8fcf240  lea r12, [r14+0x70]
00007d5be8fcf244  movups [r13+r12*1], xmm5
00007d5be8fcf24a  lea r12, [rax+0xE0]
00007d5be8fcf251  movups xmm11, [r13+r12*1]
00007d5be8fcf257  lea r12, [rax+0xF0]
00007d5be8fcf25e  movups xmm5, [r13+r12*1]
00007d5be8fcf264  lea r12, [r14+0xA0]
00007d5be8fcf26b  movups [r13+r12*1], xmm13
00007d5be8fcf271  lea r12, [r14+0xB0]
00007d5be8fcf278  movups [r13+r12*1], xmm1
00007d5be8fcf27e  lea r12, [rax+0xA0]
00007d5be8fcf285  movups xmm1, [r13+r12*1]
00007d5be8fcf28b  lea r12, [rax+0xB0]
00007d5be8fcf292  movups xmm13, [r13+r12*1]
00007d5be8fcf298  lea r12, [rax+0x120]
00007d5be8fcf29f  vmovaps [rsp+0x10], xmm1
00007d5be8fcf2a5  movups xmm1, [r13+r12*1]
00007d5be8fcf2ab  lea r12, [rax+0x130]
00007d5be8fcf2b2  vmovaps [rsp+0x20], xmm1
00007d5be8fcf2b8  movups xmm1, [r13+r12*1]
00007d5be8fcf2be  lea r12, [rax+0x160]
00007d5be8fcf2c5  vmovaps [rsp+0x30], xmm1
00007d5be8fcf2cb  movups xmm1, [r13+r12*1]
00007d5be8fcf2d1  lea r12, [rax+0x170]
00007d5be8fcf2d8  vmovaps [rsp+0x40], xmm1
00007d5be8fcf2de  movups xmm1, [r13+r12*1]
00007d5be8fcf2e4  movaps [r15+0x2B0], xmm1
00007d5be8fcf2ec  lea r12, [r14+0x80]
00007d5be8fcf2f3  movups [r13+r12*1], xmm13
00007d5be8fcf2f9  lea r12, [r14+0x90]
00007d5be8fcf300  vmovaps xmm13, [rsp+0x10]
00007d5be8fcf306  movups [r13+r12*1], xmm13
00007d5be8fcf30c  lea r12, [rax+0x1A0]
00007d5be8fcf313  movups xmm13, [r13+r12*1]
00007d5be8fcf319  lea r12, [rax+0x1B0]
00007d5be8fcf320  vmovaps [rsp+0x10], xmm1
00007d5be8fcf326  movups xmm1, [r13+r12*1]
00007d5be8fcf32c  movaps [r15+0x290], xmm13
00007d5be8fcf334  movaps [r15+0x1E0], xmm1
00007d5be8fcf33c  lea r12, [rax+0x1E0]
00007d5be8fcf343  vmovaps [rsp+0x50], xmm1
00007d5be8fcf349  movups xmm1, [r13+r12*1]
00007d5be8fcf34f  lea r12, [rax+0x1F0]
00007d5be8fcf356  vmovaps [rsp+0x60], xmm1
00007d5be8fcf35c  movups xmm1, [r13+r12*1]
00007d5be8fcf362  mov qword ptr [r15+0x50], 0x430920
00007d5be8fcf36a  lea rax, [r14+0x40]
00007d5be8fcf36e  vmovaps [rsp+0x70], xmm1
00007d5be8fcf374  vmovaps xmm1, [rsp+0x40]
00007d5be8fcf37a  movups [r13+rax*1], xmm1
00007d5be8fcf380  lea rax, [r14+0x50]
00007d5be8fcf384  movups [r13+rax*1], xmm10
00007d5be8fcf38a  vmovaps xmm1, [rsp+0x70]
00007d5be8fcf390  movups [r13+r14*1], xmm1
00007d5be8fcf396  lea rax, [r14+0x10]
00007d5be8fcf39a  vmovaps xmm1, [rsp+0x60]
00007d5be8fcf3a0  movups [r13+rax*1], xmm1
00007d5be8fcf3a6  mov rax, [r15+0x40]
00007d5be8fcf3aa  vmovaps [rsp+0x40], xmm3
00007d5be8fcf3b0  vmovaps xmm1, [rsp+0x40]
00007d5be8fcf3b6  por xmm3, xmm1
00007d5be8fcf3ba  vmovaps [rsp+0x40], xmm6
00007d5be8fcf3c0  vmovaps xmm10, [rsp+0x40]
00007d5be8fcf3c6  por xmm6, xmm10
00007d5be8fcf3cb  lea r12, [rax+0x30]
00007d5be8fcf3cf  mov r11, [r13+r12*1]
00007d5be8fcf3d4  lea r12, [rax+0x38]
00007d5be8fcf3d8  mov r10, [r13+r12*1]
00007d5be8fcf3dd  movq xmm10, r11
00007d5be8fcf3e2  vmovaps [rsp+0x40], xmm1
00007d5be8fcf3e8  movq xmm1, r10
00007d5be8fcf3ed  movq xmm10, xmm10
00007d5be8fcf3f2  vmovaps [rsp+0x60], xmm10
00007d5be8fcf3f8  movq xmm10, xmm10
00007d5be8fcf3fd  movaps [r15+0x130], xmm10
00007d5be8fcf405  movq xmm1, xmm1
00007d5be8fcf409  vmovaps [rsp+0x70], xmm1
00007d5be8fcf40f  movq xmm1, xmm1
00007d5be8fcf413  movaps [r15+0x280], xmm1
00007d5be8fcf41b  vmovaps [rsp+0x80], xmm9
00007d5be8fcf424  vmovaps xmm1, [rsp+0x80]
00007d5be8fcf42d  por xmm9, xmm1
00007d5be8fcf432  lea r12, [rax+0x20]
00007d5be8fcf436  mov r11, [r13+r12*1]
00007d5be8fcf43b  lea r12, [rax+0x28]
00007d5be8fcf43f  mov r10, [r13+r12*1]
00007d5be8fcf444  movq xmm1, r11
00007d5be8fcf449  movq xmm10, r10
00007d5be8fcf44e  movq xmm1, xmm1
00007d5be8fcf452  vmovaps [rsp+0x80], xmm1
00007d5be8fcf45b  movq xmm1, xmm1
00007d5be8fcf45f  movaps [r15+0x150], xmm1
00007d5be8fcf467  movq xmm10, xmm10
00007d5be8fcf46c  vmovaps [rsp+0x90], xmm10
00007d5be8fcf475  movq xmm10, xmm10
00007d5be8fcf47a  movaps [r15+0x140], xmm10
00007d5be8fcf482  lea r12, [rax+0x10]
00007d5be8fcf486  mov r11, [r13+r12*1]
00007d5be8fcf48b  lea r12, [rax+0x18]
00007d5be8fcf48f  mov r10, [r13+r12*1]
00007d5be8fcf494  movq xmm1, r11
00007d5be8fcf499  movq xmm10, r10
00007d5be8fcf49e  movq xmm1, xmm1
00007d5be8fcf4a2  vmovaps [rsp+0xA0], xmm1
00007d5be8fcf4ab  movq xmm1, xmm1
00007d5be8fcf4af  movaps [r15+0x170], xmm1
00007d5be8fcf4b7  movq xmm10, xmm10
00007d5be8fcf4bc  vmovaps [rsp+0xB0], xmm10
00007d5be8fcf4c5  movq xmm10, xmm10
00007d5be8fcf4ca  movaps [r15+0x160], xmm10
00007d5be8fcf4d2  mov r12, [r13+rax*1]
00007d5be8fcf4d7  vmovq xmm1, r12
00007d5be8fcf4dc  vpbroadcastq xmm1, xmm1
00007d5be8fcf4e1  lea r12, [rax+0x08]
00007d5be8fcf4e5  mov rax, [r13+r12*1]
00007d5be8fcf4ea  movq xmm10, rax
00007d5be8fcf4ef  movaps [r15+0x230], xmm10
00007d5be8fcf4f7  lea rax, [r14+0x50]
00007d5be8fcf4fb  movups xmm10, [r13+rax*1]
00007d5be8fcf501  lea rax, [r14+0x60]
00007d5be8fcf505  vmovaps [rsp+0xC0], xmm1
00007d5be8fcf50e  movups xmm1, [r13+rax*1]
00007d5be8fcf514  lea rax, [r14+0x30]
00007d5be8fcf518  vmovaps [rsp+0xD0], xmm1
00007d5be8fcf521  movups xmm1, [r13+rax*1]
00007d5be8fcf527  mov qword ptr [r15+0x60], 0x430920
00007d5be8fcf52f  mov qword ptr [r15+0x58], 0x40
00007d5be8fcf537  vmovaps [rsp+0xE0], xmm1
00007d5be8fcf540  vmovaps [rsp+0xF0], xmm15
00007d5be8fcf549  vmovaps xmm15, [rsp+0xC0]
00007d5be8fcf552  vmovaps [rsp+0xC0], xmm14
00007d5be8fcf55b  vmovaps xmm14, [rsp+0x40]
00007d5be8fcf561  vmovaps [rsp+0x40], xmm13
00007d5be8fcf567  movaps xmm1, xmm15
00007d5be8fcf56b  mulpd xmm1, xmm14
00007d5be8fcf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007d5be8fcf575  ptest xmm13, xmm13
00007d5be8fcf57b  jnz 0x00007D5BE8FD0682
00007d5be8fcf581  movq xmm14, qword ptr [r15+0x230]
00007d5be8fcf58a  vmovaps [rsp+0x100], xmm14
00007d5be8fcf593  vpermilpd xmm14, xmm14, 0x00
00007d5be8fcf599  vmovaps [rsp+0x110], xmm1
00007d5be8fcf5a2  vmovaps xmm1, [rsp+0xE0]
00007d5be8fcf5ab  vmovaps [rsp+0xE0], xmm15
00007d5be8fcf5b4  movaps xmm13, xmm1
00007d5be8fcf5b8  mulpd xmm13, xmm14
00007d5be8fcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007d5be8fcf5c3  ptest xmm15, xmm15
00007d5be8fcf5c9  jnz 0x00007D5BE8FD07C4
00007d5be8fcf5cf  vxorps xmm1, xmm1, xmm1
00007d5be8fcf5d3  vpbroadcastq xmm1, xmm1
00007d5be8fcf5d8  vmovaps xmm14, [rsp+0xE0]
00007d5be8fcf5e1  vmovaps [rsp+0xE0], xmm1
00007d5be8fcf5ea  vmovaps xmm1, [rsp+0xD0]
00007d5be8fcf5f3  vmovaps [rsp+0xD0], xmm13
00007d5be8fcf5fc  movaps xmm15, xmm14
00007d5be8fcf600  mulpd xmm15, xmm1
00007d5be8fcf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007d5be8fcf60b  ptest xmm13, xmm13
00007d5be8fcf611  jnz 0x00007D5BE8FD0907
00007d5be8fcf617  movaps xmm1, xmm14
00007d5be8fcf61b  mulpd xmm1, xmm10
00007d5be8fcf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007d5be8fcf625  ptest xmm13, xmm13
00007d5be8fcf62b  jnz 0x00007D5BE8FD0A4A
00007d5be8fcf631  movaps xmm13, xmm14
00007d5be8fcf635  mulpd xmm13, xmm2
00007d5be8fcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007d5be8fcf640  ptest xmm10, xmm10
00007d5be8fcf646  jnz 0x00007D5BE8FD0B8C
00007d5be8fcf64c  vmovaps [rsp+0x120], xmm7
00007d5be8fcf655  vmovaps xmm14, [rsp+0x120]
00007d5be8fcf65e  por xmm7, xmm14
00007d5be8fcf663  vmovaps xmm14, [rsp+0xC0]
00007d5be8fcf66c  vmovaps xmm10, [rsp+0xC0]
00007d5be8fcf675  por xmm14, xmm10
00007d5be8fcf67a  vmovaps xmm2, [rsp+0x100]
00007d5be8fcf683  vpermilpd xmm2, xmm2, 0x00
00007d5be8fcf689  vmovaps [rsp+0xC0], xmm1
00007d5be8fcf692  vmovaps [rsp+0x120], xmm15
00007d5be8fcf69b  movaps xmm1, xmm10
00007d5be8fcf69f  mulpd xmm1, xmm2
00007d5be8fcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007d5be8fcf6a8  ptest xmm15, xmm15
00007d5be8fcf6ae  jnz 0x00007D5BE8FD0CCF
00007d5be8fcf6b4  xor eax, eax
00007d5be8fcf6b6  mov r12d, 0x40
00007d5be8fcf6bc  mov r11d, 0x200
00007d5be8fcf6c2  cmp r12, r11
00007d5be8fcf6c5  cmc
00007d5be8fcf6c6  lahf
00007d5be8fcf6c7  seto al
00007d5be8fcf6ca  mov [r15+0x108], eax
00007d5be8fcf6d1  vmovaps xmm10, [rsp+0x110]
00007d5be8fcf6da  vmovaps xmm2, [rsp+0xE0]
00007d5be8fcf6e3  vmovaps [rsp+0xE0], xmm1
00007d5be8fcf6ec  movaps xmm15, xmm10
00007d5be8fcf6f0  addpd xmm15, xmm2
00007d5be8fcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007d5be8fcf6fb  ptest xmm1, xmm1
00007d5be8fcf700  jnz 0x00007D5BE8FD0E10
00007d5be8fcf706  vmovaps xmm10, [rsp+0x120]
00007d5be8fcf70f  vmovaps [rsp+0x110], xmm15
00007d5be8fcf718  movaps xmm1, xmm10
00007d5be8fcf71c  addpd xmm1, xmm12
00007d5be8fcf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007d5be8fcf726  ptest xmm15, xmm15
00007d5be8fcf72c  jnz 0x00007D5BE8FD0F53
00007d5be8fcf732  vmovaps xmm10, [rsp+0xC0]
00007d5be8fcf73b  vmovaps [rsp+0xC0], xmm1
00007d5be8fcf744  movaps xmm15, xmm10
00007d5be8fcf748  addpd xmm15, xmm12
00007d5be8fcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007d5be8fcf753  ptest xmm1, xmm1
00007d5be8fcf758  jnz 0x00007D5BE8FD1095
00007d5be8fcf75e  vmovaps xmm1, [rsp+0x30]
00007d5be8fcf764  vmovaps xmm12, [rsp+0x30]
00007d5be8fcf76a  por xmm1, xmm12
00007d5be8fcf76f  vmovaps xmm12, [rsp+0x20]
00007d5be8fcf775  vmovaps xmm10, [rsp+0x20]
00007d5be8fcf77b  por xmm12, xmm10
00007d5be8fcf780  vmovaps [rsp+0x20], xmm5
00007d5be8fcf786  vmovaps xmm10, [rsp+0x20]
00007d5be8fcf78c  por xmm5, xmm10
00007d5be8fcf791  vmovaps [rsp+0x20], xmm11
00007d5be8fcf797  vmovaps xmm10, [rsp+0x20]
00007d5be8fcf79d  por xmm11, xmm10
00007d5be8fcf7a2  vmovaps [rsp+0x20], xmm4
00007d5be8fcf7a8  vmovaps xmm10, [rsp+0x20]
00007d5be8fcf7ae  por xmm4, xmm10
00007d5be8fcf7b3  vmovaps [rsp+0x20], xmm8
00007d5be8fcf7b9  vmovaps xmm10, [rsp+0x20]
00007d5be8fcf7bf  por xmm8, xmm10
00007d5be8fcf7c4  vmovaps xmm10, [rsp+0xF0]
00007d5be8fcf7cd  vmovaps [rsp+0x20], xmm1
00007d5be8fcf7d3  vmovaps xmm1, [rsp+0xF0]
00007d5be8fcf7dc  por xmm10, xmm1
00007d5be8fcf7e1  lea rax, [r14+0xA0]
00007d5be8fcf7e8  movups xmm1, [r13+rax*1]
00007d5be8fcf7ee  lea rax, [r14+0xB0]
00007d5be8fcf7f5  vmovaps [rsp+0x30], xmm1
00007d5be8fcf7fb  movups xmm1, [r13+rax*1]
00007d5be8fcf801  vmovaps [rsp+0xF0], xmm1
00007d5be8fcf80a  vmovaps [rsp+0x120], xmm15
00007d5be8fcf813  movaps xmm1, xmm13
00007d5be8fcf817  addpd xmm1, xmm2
00007d5be8fcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007d5be8fcf820  ptest xmm15, xmm15
00007d5be8fcf826  jnz 0x00007D5BE8FD11ED
00007d5be8fcf82c  lea rax, [r14+0xF0]
00007d5be8fcf833  movups xmm15, [r13+rax*1]
00007d5be8fcf839  vmovaps xmm2, [rsp+0xC0]
00007d5be8fcf842  vmovaps [rsp+0xC0], xmm1
00007d5be8fcf84b  vmovaps xmm1, [rsp+0xE0]
00007d5be8fcf854  vmovaps [rsp+0xE0], xmm15
00007d5be8fcf85d  movaps xmm13, xmm2
00007d5be8fcf861  addpd xmm13, xmm1
00007d5be8fcf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007d5be8fcf86c  ptest xmm15, xmm15
00007d5be8fcf872  jnz 0x00007D5BE8FD1338
00007d5be8fcf878  vmovaps xmm15, [rsp+0x120]
00007d5be8fcf881  vmovaps xmm2, [rsp+0xD0]
00007d5be8fcf88a  vmovaps [rsp+0xD0], xmm14
00007d5be8fcf893  movaps xmm1, xmm15
00007d5be8fcf897  addpd xmm1, xmm2
00007d5be8fcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007d5be8fcf8a0  ptest xmm14, xmm14
00007d5be8fcf8a6  jnz 0x00007D5BE8FD147A
00007d5be8fcf8ac  vmovaps xmm15, [rsp+0x100]
00007d5be8fcf8b5  vpermilpd xmm15, xmm15, 0x00
00007d5be8fcf8bb  vmovaps xmm2, [rsp+0xF0]
00007d5be8fcf8c4  vmovaps [rsp+0xF0], xmm1
00007d5be8fcf8cd  movaps xmm14, xmm2
00007d5be8fcf8d1  mulpd xmm14, xmm15
00007d5be8fcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007d5be8fcf8dc  ptest xmm1, xmm1
00007d5be8fcf8e1  jnz 0x00007D5BE8FD15BB
00007d5be8fcf8e7  vmovaps xmm1, [rsp+0xA0]
00007d5be8fcf8f0  vpermilpd xmm1, xmm1, 0x00
00007d5be8fcf8f6  vmovaps xmm2, [rsp+0xE0]
00007d5be8fcf8ff  vmovaps [rsp+0xE0], xmm14
00007d5be8fcf908  movaps xmm15, xmm2
00007d5be8fcf90c  mulpd xmm15, xmm1
00007d5be8fcf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007d5be8fcf917  ptest xmm14, xmm14
00007d5be8fcf91d  jnz 0x00007D5BE8FD16FE
00007d5be8fcf923  lea rax, [r14+0xE0]
00007d5be8fcf92a  movups xmm1, [r13+rax*1]
00007d5be8fcf930  vmovaps xmm14, [rsp+0x100]
00007d5be8fcf939  vpermilpd xmm14, xmm14, 0x00
00007d5be8fcf93f  vmovaps [rsp+0x100], xmm1
00007d5be8fcf948  vmovaps xmm1, [rsp+0x30]
00007d5be8fcf94e  vmovaps [rsp+0x30], xmm15
00007d5be8fcf954  movaps xmm2, xmm1
00007d5be8fcf957  mulpd xmm2, xmm14
00007d5be8fcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007d5be8fcf961  ptest xmm15, xmm15
00007d5be8fcf967  jnz 0x00007D5BE8FD184A
00007d5be8fcf96d  vmovaps [rsp+0x120], xmm10
00007d5be8fcf976  vmovaps xmm1, [rsp+0x120]
00007d5be8fcf97f  por xmm10, xmm1
00007d5be8fcf984  movaps [r15+0x300], xmm10
00007d5be8fcf98c  vmovaps [rsp+0x120], xmm8
00007d5be8fcf995  vmovaps xmm1, [rsp+0x120]
00007d5be8fcf99e  por xmm8, xmm1
00007d5be8fcf9a3  movaps [r15+0x190], xmm8
00007d5be8fcf9ab  vmovaps xmm1, [rsp+0xA0]
00007d5be8fcf9b4  vpermilpd xmm1, xmm1, 0x00
00007d5be8fcf9ba  vmovaps xmm14, [rsp+0x100]
00007d5be8fcf9c3  vmovaps [rsp+0x100], xmm13
00007d5be8fcf9cc  movaps xmm15, xmm14
00007d5be8fcf9d0  mulpd xmm15, xmm1
00007d5be8fcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007d5be8fcf9db  ptest xmm13, xmm13
00007d5be8fcf9e1  jnz 0x00007D5BE8FD198B
00007d5be8fcf9e7  lea rax, [r14+0x90]
00007d5be8fcf9ee  movups xmm1, [r13+rax*1]
00007d5be8fcf9f4  vmovaps [rsp+0x120], xmm4
00007d5be8fcf9fd  vmovaps xmm14, [rsp+0x120]
00007d5be8fcfa06  por xmm4, xmm14
00007d5be8fcfa0b  movaps [r15+0x1C0], xmm4
00007d5be8fcfa13  vmovaps [rsp+0x120], xmm11
00007d5be8fcfa1c  vmovaps xmm14, [rsp+0x120]
00007d5be8fcfa25  por xmm11, xmm14
00007d5be8fcfa2a  movaps [r15+0x200], xmm11
00007d5be8fcfa32  vmovaps [rsp+0x120], xmm5
00007d5be8fcfa3b  vmovaps xmm14, [rsp+0x120]
00007d5be8fcfa44  por xmm5, xmm14
00007d5be8fcfa49  movaps [r15+0x2D0], xmm5
00007d5be8fcfa51  vmovaps [rsp+0x120], xmm12
00007d5be8fcfa5a  vmovaps xmm14, [rsp+0x120]
00007d5be8fcfa63  por xmm12, xmm14
00007d5be8fcfa68  movaps [r15+0x2E0], xmm12
00007d5be8fcfa70  vmovaps xmm13, [rsp+0x110]
00007d5be8fcfa79  vmovaps [rsp+0x110], xmm1
00007d5be8fcfa82  vmovaps xmm1, [rsp+0xE0]
00007d5be8fcfa8b  vmovaps [rsp+0xE0], xmm15
00007d5be8fcfa94  movaps xmm14, xmm13
00007d5be8fcfa98  addpd xmm14, xmm1
00007d5be8fcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007d5be8fcfaa3  ptest xmm15, xmm15
00007d5be8fcfaa9  jnz 0x00007D5BE8FD1AD8
00007d5be8fcfaaf  vmovaps xmm1, [rsp+0xA0]
00007d5be8fcfab8  vpermilpd xmm1, xmm1, 0x00
00007d5be8fcfabe  vmovaps xmm13, [rsp+0x110]
00007d5be8fcfac7  vmovaps [rsp+0x110], xmm14
00007d5be8fcfad0  movaps xmm15, xmm13
00007d5be8fcfad4  mulpd xmm15, xmm1
00007d5be8fcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007d5be8fcfadf  ptest xmm14, xmm14
00007d5be8fcfae5  jnz 0x00007D5BE8FD1C1B
00007d5be8fcfaeb  lea rax, [r14+0x80]
00007d5be8fcfaf2  movups xmm1, [r13+rax*1]
00007d5be8fcfaf8  vmovaps xmm13, [rsp+0xC0]
00007d5be8fcfb01  vmovaps [rsp+0xC0], xmm1
00007d5be8fcfb0a  movaps xmm14, xmm13
00007d5be8fcfb0e  addpd xmm14, xmm2
00007d5be8fcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007d5be8fcfb19  ptest xmm1, xmm1
00007d5be8fcfb1e  jnz 0x00007D5BE8FD1D68
00007d5be8fcfb24  vmovaps xmm13, [rsp+0x100]
00007d5be8fcfb2d  vmovaps xmm2, [rsp+0x30]
00007d5be8fcfb33  vmovaps [rsp+0x30], xmm15
00007d5be8fcfb39  movaps xmm1, xmm13
00007d5be8fcfb3d  addpd xmm1, xmm2
00007d5be8fcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007d5be8fcfb46  ptest xmm15, xmm15
00007d5be8fcfb4c  jnz 0x00007D5BE8FD1EAB
00007d5be8fcfb52  vmovaps xmm15, [rsp+0x20]
00007d5be8fcfb58  vmovaps xmm13, [rsp+0x20]
00007d5be8fcfb5e  por xmm15, xmm13
00007d5be8fcfb63  movaps [r15+0x2F0], xmm15
00007d5be8fcfb6b  vmovaps xmm13, [rsp+0xA0]
00007d5be8fcfb74  vpermilpd xmm13, xmm13, 0x00
00007d5be8fcfb7a  vmovaps [rsp+0x20], xmm1
00007d5be8fcfb80  vmovaps xmm1, [rsp+0xC0]
00007d5be8fcfb89  vmovaps [rsp+0xA0], xmm15
00007d5be8fcfb92  movaps xmm2, xmm1
00007d5be8fcfb95  mulpd xmm2, xmm13
00007d5be8fcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007d5be8fcfb9f  ptest xmm15, xmm15
00007d5be8fcfba5  jnz 0x00007D5BE8FD1FEC
00007d5be8fcfbab  lea rax, [r14+0xD0]
00007d5be8fcfbb2  movups xmm1, [r13+rax*1]
00007d5be8fcfbb8  vmovaps xmm13, [rsp+0xF0]
00007d5be8fcfbc1  vmovaps [rsp+0xC0], xmm1
00007d5be8fcfbca  vmovaps xmm1, [rsp+0xE0]
00007d5be8fcfbd3  vmovaps [rsp+0xE0], xmm14
00007d5be8fcfbdc  movaps xmm15, xmm13
00007d5be8fcfbe0  addpd xmm15, xmm1
00007d5be8fcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007d5be8fcfbeb  ptest xmm14, xmm14
00007d5be8fcfbf1  jnz 0x00007D5BE8FD2137
00007d5be8fcfbf7  vmovaps xmm1, [rsp+0xB0]
00007d5be8fcfc00  vpermilpd xmm1, xmm1, 0x00
00007d5be8fcfc06  movaps xmm14, xmm11
00007d5be8fcfc0a  mulpd xmm14, xmm1
00007d5be8fcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007d5be8fcfc15  ptest xmm13, xmm13
00007d5be8fcfc1b  jnz 0x00007D5BE8FD227A
00007d5be8fcfc21  movaps [r15+0x260], xmm14
00007d5be8fcfc29  vxorps xmm1, xmm1, xmm1
00007d5be8fcfc2d  vpbroadcastq xmm1, xmm1
00007d5be8fcfc32  movaps [r15+0x1B0], xmm1
00007d5be8fcfc3a  vmovaps xmm1, [rsp+0xB0]
00007d5be8fcfc43  vpermilpd xmm1, xmm1, 0x00
00007d5be8fcfc49  vmovaps xmm11, [rsp+0xC0]
00007d5be8fcfc52  vmovaps [rsp+0xC0], xmm15
00007d5be8fcfc5b  movaps xmm13, xmm11
00007d5be8fcfc5f  mulpd xmm13, xmm1
00007d5be8fcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007d5be8fcfc6a  ptest xmm15, xmm15
00007d5be8fcfc70  jnz 0x00007D5BE8FD23BD
00007d5be8fcfc76  lea rax, [r14+0xC0]
00007d5be8fcfc7d  movups xmm1, [r13+rax*1]
00007d5be8fcfc83  vmovaps xmm11, [rsp+0x110]
00007d5be8fcfc8c  vmovaps [rsp+0xF0], xmm1
00007d5be8fcfc95  vmovaps xmm1, [rsp+0x30]
00007d5be8fcfc9b  vmovaps [rsp+0x30], xmm14
00007d5be8fcfca1  movaps xmm15, xmm11
00007d5be8fcfca5  addpd xmm15, xmm1
00007d5be8fcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007d5be8fcfcb0  ptest xmm14, xmm14
00007d5be8fcfcb6  jnz 0x00007D5BE8FD250A
00007d5be8fcfcbc  vmovaps [rsp+0x100], xmm9
00007d5be8fcfcc5  vmovaps xmm1, [rsp+0x100]
00007d5be8fcfcce  por xmm9, xmm1
00007d5be8fcfcd3  movaps [r15+0x270], xmm9
00007d5be8fcfcdb  vmovaps [rsp+0x100], xmm6
00007d5be8fcfce4  vmovaps xmm1, [rsp+0x100]
00007d5be8fcfced  por xmm6, xmm1
00007d5be8fcfcf1  movaps [r15+0x1A0], xmm6
00007d5be8fcfcf9  vmovaps xmm14, [rsp+0xB0]
00007d5be8fcfd02  vpermilpd xmm14, xmm14, 0x00
00007d5be8fcfd08  vmovaps xmm6, [rsp+0xF0]
00007d5be8fcfd11  vmovaps [rsp+0xF0], xmm1
00007d5be8fcfd1a  movaps xmm11, xmm6
00007d5be8fcfd1e  mulpd xmm11, xmm14
00007d5be8fcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007d5be8fcfd29  ptest xmm1, xmm1
00007d5be8fcfd2e  jnz 0x00007D5BE8FD264D
00007d5be8fcfd34  lea rax, [r14+0x20]
00007d5be8fcfd38  movups xmm1, [r13+rax*1]
00007d5be8fcfd3e  movaps [r15+0x110], xmm1
00007d5be8fcfd46  vmovaps xmm6, [rsp+0xE0]
00007d5be8fcfd4f  vmovaps [rsp+0xE0], xmm1
00007d5be8fcfd58  movaps xmm14, xmm6
00007d5be8fcfd5c  addpd xmm14, xmm2
00007d5be8fcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007d5be8fcfd67  ptest xmm1, xmm1
00007d5be8fcfd6c  jnz 0x00007D5BE8FD279A
00007d5be8fcfd72  vmovaps xmm1, [rsp+0xB0]
00007d5be8fcfd7b  vpermilpd xmm1, xmm1, 0x00
00007d5be8fcfd81  movaps xmm6, xmm5
00007d5be8fcfd84  mulpd xmm6, xmm1
00007d5be8fcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007d5be8fcfd8d  ptest xmm2, xmm2
00007d5be8fcfd92  jnz 0x00007D5BE8FD28DC
00007d5be8fcfd98  vmovaps xmm5, [rsp+0x20]
00007d5be8fcfd9e  movaps xmm1, xmm5
00007d5be8fcfda1  addpd xmm1, xmm13
00007d5be8fcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007d5be8fcfdab  ptest xmm2, xmm2
00007d5be8fcfdb0  jnz 0x00007D5BE8FD2A1C
00007d5be8fcfdb6  vmovaps xmm13, [rsp+0x80]
00007d5be8fcfdbf  vpermilpd xmm13, xmm13, 0x00
00007d5be8fcfdc5  vmovaps xmm2, [rsp+0xE0]
00007d5be8fcfdce  vmovaps [rsp+0x20], xmm1
00007d5be8fcfdd4  movaps xmm5, xmm2
00007d5be8fcfdd7  mulpd xmm5, xmm13
00007d5be8fcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007d5be8fcfde1  ptest xmm1, xmm1
00007d5be8fcfde6  jnz 0x00007D5BE8FD2B5D
00007d5be8fcfdec  vmovaps xmm1, [rsp+0x80]
00007d5be8fcfdf5  vpermilpd xmm1, xmm1, 0x00
00007d5be8fcfdfb  movaps xmm13, xmm10
00007d5be8fcfdff  mulpd xmm13, xmm1
00007d5be8fcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007d5be8fcfe0a  ptest xmm2, xmm2
00007d5be8fcfe0f  jnz 0x00007D5BE8FD2C9E
00007d5be8fcfe15  vmovaps xmm10, [rsp+0x30]
00007d5be8fcfe1b  movaps xmm1, xmm15
00007d5be8fcfe1f  addpd xmm1, xmm10
00007d5be8fcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007d5be8fcfe29  ptest xmm2, xmm2
00007d5be8fcfe2e  jnz 0x00007D5BE8FD2DE1
00007d5be8fcfe34  vmovaps xmm10, [rsp+0xC0]
00007d5be8fcfe3d  movaps xmm15, xmm10
00007d5be8fcfe41  addpd xmm15, xmm11
00007d5be8fcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007d5be8fcfe4c  ptest xmm2, xmm2
00007d5be8fcfe51  jnz 0x00007D5BE8FD2F23
00007d5be8fcfe57  vmovaps xmm11, [rsp+0x80]
00007d5be8fcfe60  vpermilpd xmm11, xmm11, 0x00
00007d5be8fcfe66  movaps xmm10, xmm12
00007d5be8fcfe6a  mulpd xmm10, xmm11
00007d5be8fcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007d5be8fcfe75  ptest xmm2, xmm2
00007d5be8fcfe7a  jnz 0x00007D5BE8FD3067
00007d5be8fcfe80  vmovaps xmm12, [rsp+0x80]
00007d5be8fcfe89  vpermilpd xmm12, xmm12, 0x00
00007d5be8fcfe8f  vmovaps xmm2, [rsp+0xA0]
00007d5be8fcfe98  vmovaps [rsp+0x30], xmm1
00007d5be8fcfe9e  movaps xmm11, xmm2
00007d5be8fcfea2  mulpd xmm11, xmm12
00007d5be8fcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007d5be8fcfead  ptest xmm1, xmm1
00007d5be8fcfeb2  jnz 0x00007D5BE8FD31AB
00007d5be8fcfeb8  movaps xmm1, xmm14
00007d5be8fcfebc  addpd xmm1, xmm6
00007d5be8fcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007d5be8fcfec5  ptest xmm12, xmm12
00007d5be8fcfecb  jnz 0x00007D5BE8FD32EE
00007d5be8fcfed1  vmovaps xmm12, [rsp+0x20]
00007d5be8fcfed7  movaps xmm14, xmm12
00007d5be8fcfedb  addpd xmm14, xmm5
00007d5be8fcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007d5be8fcfee6  ptest xmm6, xmm6
00007d5be8fcfeeb  jnz 0x00007D5BE8FD342F
00007d5be8fcfef1  vmovaps xmm12, [rsp+0x90]
00007d5be8fcfefa  vpermilpd xmm12, xmm12, 0x00
00007d5be8fcff00  movaps xmm6, xmm9
00007d5be8fcff04  mulpd xmm6, xmm12
00007d5be8fcff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007d5be8fcff0e  ptest xmm5, xmm5
00007d5be8fcff13  jnz 0x00007D5BE8FD3572
00007d5be8fcff19  movaps xmm12, xmm15
00007d5be8fcff1d  addpd xmm12, xmm13
00007d5be8fcff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007d5be8fcff28  ptest xmm9, xmm9
00007d5be8fcff2e  jnz 0x00007D5BE8FD36B4
00007d5be8fcff34  vmovaps xmm13, [rsp+0x30]
00007d5be8fcff3a  movaps xmm15, xmm13
00007d5be8fcff3e  addpd xmm15, xmm10
00007d5be8fcff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007d5be8fcff49  ptest xmm9, xmm9
00007d5be8fcff4f  jnz 0x00007D5BE8FD37F8
00007d5be8fcff55  vmovaps xmm13, [rsp+0xD0]
00007d5be8fcff5e  vmovaps xmm10, [rsp+0xD0]
00007d5be8fcff67  por xmm13, xmm10
00007d5be8fcff6c  movaps [r15+0x250], xmm13
00007d5be8fcff74  vmovaps [rsp+0x20], xmm7
00007d5be8fcff7a  vmovaps xmm13, [rsp+0x20]
00007d5be8fcff80  por xmm7, xmm13
00007d5be8fcff85  movaps [r15+0x2A0], xmm7
00007d5be8fcff8d  vmovaps [rsp+0x20], xmm3
00007d5be8fcff93  vmovaps xmm13, [rsp+0x20]
00007d5be8fcff99  por xmm3, xmm13
00007d5be8fcff9e  movaps [r15+0x1D0], xmm3
00007d5be8fcffa6  lea rax, [r14+0x40]
00007d5be8fcffaa  movups xmm13, [r13+rax*1]
00007d5be8fcffb0  movaps [r15+0x2C0], xmm13
00007d5be8fcffb8  vmovaps xmm10, [rsp+0x90]
00007d5be8fcffc1  vpermilpd xmm10, xmm10, 0x00
00007d5be8fcffc7  movaps xmm9, xmm8
00007d5be8fcffcb  mulpd xmm9, xmm10
00007d5be8fcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007d5be8fcffd6  ptest xmm5, xmm5
00007d5be8fcffdb  jnz 0x00007D5BE8FD3946
00007d5be8fcffe1  movaps xmm10, xmm1
00007d5be8fcffe5  addpd xmm10, xmm11
00007d5be8fcffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007d5be8fcfff0  ptest xmm8, xmm8
00007d5be8fcfff6  jnz 0x00007D5BE8FD3A8A
00007d5be8fcfffc  movaps xmm1, xmm14
00007d5be8fd0000  addpd xmm1, xmm6
00007d5be8fd0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007d5be8fd0009  ptest xmm11, xmm11
00007d5be8fd000f  jnz 0x00007D5BE8FD3BCD
00007d5be8fd0015  vmovaps xmm14, [rsp+0x90]
00007d5be8fd001e  vpermilpd xmm14, xmm14, 0x00
00007d5be8fd0024  movaps xmm11, xmm13
00007d5be8fd0028  mulpd xmm11, xmm14
00007d5be8fd002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007d5be8fd0033  ptest xmm8, xmm8
00007d5be8fd0039  jnz 0x00007D5BE8FD3D0E
00007d5be8fd003f  vmovaps xmm14, [rsp+0x90]
00007d5be8fd0048  vpermilpd xmm14, xmm14, 0x00
00007d5be8fd004e  vmovaps xmm8, [rsp+0x10]
00007d5be8fd0054  movaps xmm13, xmm8
00007d5be8fd0058  mulpd xmm13, xmm14
00007d5be8fd005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007d5be8fd0063  ptest xmm6, xmm6
00007d5be8fd0068  jnz 0x00007D5BE8FD3E52
00007d5be8fd006e  vmovaps xmm14, [rsp+0x60]
00007d5be8fd0074  vpermilpd xmm14, xmm14, 0x00
00007d5be8fd007a  movaps xmm8, xmm7
00007d5be8fd007e  mulpd xmm8, xmm14
00007d5be8fd0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007d5be8fd0089  ptest xmm6, xmm6
00007d5be8fd008e  jnz 0x00007D5BE8FD3F96
00007d5be8fd0094  movaps xmm14, xmm12
00007d5be8fd0098  addpd xmm14, xmm9
00007d5be8fd009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007d5be8fd00a3  ptest xmm7, xmm7
00007d5be8fd00a8  jnz 0x00007D5BE8FD40D9
00007d5be8fd00ae  vmovaps xmm12, [rsp+0x60]
00007d5be8fd00b4  vpermilpd xmm12, xmm12, 0x00
00007d5be8fd00ba  vmovaps xmm7, [rsp+0xF0]
00007d5be8fd00c3  movaps xmm9, xmm7
00007d5be8fd00c7  mulpd xmm9, xmm12
00007d5be8fd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007d5be8fd00d2  ptest xmm6, xmm6
00007d5be8fd00d7  jnz 0x00007D5BE8FD421D
00007d5be8fd00dd  movaps xmm12, xmm15
00007d5be8fd00e1  addpd xmm12, xmm11
00007d5be8fd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007d5be8fd00ec  ptest xmm7, xmm7
00007d5be8fd00f1  jnz 0x00007D5BE8FD4360
00007d5be8fd00f7  vmovaps xmm15, [rsp+0x60]
00007d5be8fd00fd  vpermilpd xmm15, xmm15, 0x00
00007d5be8fd0103  vmovaps xmm7, [rsp+0x40]
00007d5be8fd0109  movaps xmm11, xmm7
00007d5be8fd010d  mulpd xmm11, xmm15
00007d5be8fd0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007d5be8fd0118  ptest xmm6, xmm6
00007d5be8fd011d  jnz 0x00007D5BE8FD44A4
00007d5be8fd0123  movaps xmm15, xmm10
00007d5be8fd0127  addpd xmm15, xmm13
00007d5be8fd012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007d5be8fd0132  ptest xmm7, xmm7
00007d5be8fd0137  jnz 0x00007D5BE8FD45E7
00007d5be8fd013d  vmovaps xmm13, [rsp+0x60]
00007d5be8fd0143  vpermilpd xmm13, xmm13, 0x00
00007d5be8fd0149  vmovaps xmm7, [rsp+0x50]
00007d5be8fd014f  movaps xmm10, xmm7
00007d5be8fd0153  mulpd xmm10, xmm13
00007d5be8fd0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007d5be8fd015e  ptest xmm6, xmm6
00007d5be8fd0163  jnz 0x00007D5BE8FD472B
00007d5be8fd0169  movaps xmm13, xmm1
00007d5be8fd016d  addpd xmm13, xmm8
00007d5be8fd0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007d5be8fd0178  ptest xmm7, xmm7
00007d5be8fd017d  jnz 0x00007D5BE8FD486E
00007d5be8fd0183  lea rax, [r14+0x70]
00007d5be8fd0187  movups xmm1, [r13+rax*1]
00007d5be8fd018d  movaps [r15+0x240], xmm1
00007d5be8fd0195  movaps xmm8, xmm14
00007d5be8fd0199  addpd xmm8, xmm9
00007d5be8fd019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007d5be8fd01a4  ptest xmm7, xmm7
00007d5be8fd01a9  jnz 0x00007D5BE8FD49BB
00007d5be8fd01af  movaps [r15+0x170], xmm8
00007d5be8fd01b7  vmovaps xmm14, [rsp+0x70]
00007d5be8fd01bd  vpermilpd xmm14, xmm14, 0x00
00007d5be8fd01c3  movaps xmm9, xmm1
00007d5be8fd01c7  mulpd xmm9, xmm14
00007d5be8fd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007d5be8fd01d2  ptest xmm7, xmm7
00007d5be8fd01d7  jnz 0x00007D5BE8FD4AFF
00007d5be8fd01dd  vmovaps xmm1, [rsp+0x70]
00007d5be8fd01e3  vpermilpd xmm1, xmm1, 0x00
00007d5be8fd01e9  movaps xmm14, xmm4
00007d5be8fd01ed  mulpd xmm14, xmm1
00007d5be8fd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007d5be8fd01f8  ptest xmm7, xmm7
00007d5be8fd01fd  jnz 0x00007D5BE8FD4C42
00007d5be8fd0203  movaps [r15+0x180], xmm14
00007d5be8fd020b  movaps xmm1, xmm12
00007d5be8fd020f  addpd xmm1, xmm11
00007d5be8fd0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007d5be8fd0219  ptest xmm7, xmm7
00007d5be8fd021e  jnz 0x00007D5BE8FD4D84
00007d5be8fd0224  movaps [r15+0x210], xmm1
00007d5be8fd022c  movups xmm12, [r13+r14*1]
00007d5be8fd0232  lea rax, [r14+0x10]
00007d5be8fd0236  movups xmm11, [r13+rax*1]
00007d5be8fd023c  movaps [r15+0x230], xmm11
00007d5be8fd0244  movaps xmm7, xmm15
00007d5be8fd0248  addpd xmm7, xmm10
00007d5be8fd024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007d5be8fd0252  ptest xmm6, xmm6
00007d5be8fd0257  jnz 0x00007D5BE8FD4EDA
00007d5be8fd025d  movaps [r15+0x130], xmm7
00007d5be8fd0265  vmovaps xmm15, [rsp+0x70]
00007d5be8fd026b  vpermilpd xmm15, xmm15, 0x00
00007d5be8fd0271  movaps xmm10, xmm11
00007d5be8fd0275  mulpd xmm10, xmm15
00007d5be8fd027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007d5be8fd0280  ptest xmm6, xmm6
00007d5be8fd0285  jnz 0x00007D5BE8FD501C
00007d5be8fd028b  movaps [r15+0x220], xmm10
00007d5be8fd0293  vmovaps xmm15, [rsp+0x70]
00007d5be8fd0299  vpermilpd xmm15, xmm15, 0x00
00007d5be8fd029f  movaps xmm11, xmm12
00007d5be8fd02a3  mulpd xmm11, xmm15
00007d5be8fd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007d5be8fd02ae  ptest xmm6, xmm6
00007d5be8fd02b3  jnz 0x00007D5BE8FD5160
00007d5be8fd02b9  movaps xmm15, xmm13
00007d5be8fd02bd  addpd xmm15, xmm9
00007d5be8fd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007d5be8fd02c8  ptest xmm12, xmm12
00007d5be8fd02ce  jnz 0x00007D5BE8FD52A4
00007d5be8fd02d4  movaps [r15+0x140], xmm15
00007d5be8fd02dc  movaps xmm13, xmm8
00007d5be8fd02e0  addpd xmm13, xmm14
00007d5be8fd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007d5be8fd02eb  ptest xmm12, xmm12
00007d5be8fd02f1  jnz 0x00007D5BE8FD53E8
00007d5be8fd02f7  movaps [r15+0x150], xmm13
00007d5be8fd02ff  movaps xmm14, xmm1
00007d5be8fd0303  addpd xmm14, xmm10
00007d5be8fd0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007d5be8fd030e  ptest xmm12, xmm12
00007d5be8fd0314  jnz 0x00007D5BE8FD552C
00007d5be8fd031a  movaps [r15+0x160], xmm14
00007d5be8fd0322  movaps xmm1, xmm7
00007d5be8fd0325  addpd xmm1, xmm11
00007d5be8fd032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007d5be8fd032f  ptest xmm12, xmm12
00007d5be8fd0335  jnz 0x00007D5BE8FD566F
00007d5be8fd033b  movaps [r15+0x120], xmm1
00007d5be8fd0343  mov eax, 0x430920
00007d5be8fd0348  movups [r13+rax*1], xmm15
00007d5be8fd034e  mov eax, 0x430930
00007d5be8fd0353  movups [r13+rax*1], xmm13
00007d5be8fd0359  mov eax, 0x430940
00007d5be8fd035e  movups [r13+rax*1], xmm14
00007d5be8fd0364  mov eax, 0x430950
00007d5be8fd0369  movups [r13+rax*1], xmm1
00007d5be8fd036f  mov eax, [r15+0x108]
00007d5be8fd0376  sahf
00007d5be8fd0377  jnz 0x00007D5BE8FD03A9
00007d5be8fd0379  cmp dword ptr [r15+0x318], 0x00
00007d5be8fd0381  jz 0x00007D5BE8FDB900
00007d5be8fd0387  nop [rax+rax*1], ax
00007d5be8fd0390  nop [rax+rax*1], eax
00007d5be8fd0398  mov eax, 0x410444
00007d5be8fd039d  mov [r15+0x100], rax
00007d5be8fd03a4  jmp 0x00007D5BE8DFE110
00007d5be8fd03a9  cmp dword ptr [r15+0x318], 0x00
00007d5be8fd03b1  jz 0x00007D5BE8FD57E0
00007d5be8fd03b7  nop [rax+rax*1], ax
00007d5be8fd03c0  nop [rax+rax*1], eax
00007d5be8fd03c8  mov eax, 0x410278
00007d5be8fd03cd  mov [r15+0x100], rax
00007d5be8fd03d4  jmp 0x00007D5BE8DFE110
00007d5be8fd03d9  int3
00007d5be8fd03da  call 0x00007D5BE8EB52F0
00007d5be8fd03df  jmp 0x00007D5BE8FCF016
00007d5be8fd03e4  call 0x00007D5BE8EC4620
00007d5be8fd03e9  jmp 0x00007D5BE8FCF023
00007d5be8fd03ee  call 0x00007D5BE8EC33A0
00007d5be8fd03f3  jmp 0x00007D5BE8FCF035
00007d5be8fd03f8  call 0x00007D5BE8EC2120
00007d5be8fd03fd  jmp 0x00007D5BE8FCF03F
00007d5be8fd0402  call 0x00007D5BE8EC0860
00007d5be8fd0407  jmp 0x00007D5BE8FCF067
00007d5be8fd040c  call 0x00007D5BE8EBF5F0
00007d5be8fd0411  jmp 0x00007D5BE8FCF073
00007d5be8fd0416  call 0x00007D5BE8EC0860
00007d5be8fd041b  jmp 0x00007D5BE8FCF0A5
00007d5be8fd0420  call 0x00007D5BE8EBF5F0
00007d5be8fd0425  jmp 0x00007D5BE8FCF0B1
00007d5be8fd042a  call 0x00007D5BE8EC4740
00007d5be8fd042f  jmp 0x00007D5BE8FCF0BE
00007d5be8fd0434  call 0x00007D5BE8EB5400
00007d5be8fd0439  jmp 0x00007D5BE8FCF0CB
00007d5be8fd043e  call 0x00007D5BE8EB52F0
00007d5be8fd0443  jmp 0x00007D5BE8FCF0D8
00007d5be8fd0448  call 0x00007D5BE8EC4620
00007d5be8fd044d  jmp 0x00007D5BE8FCF0E5
00007d5be8fd0452  call 0x00007D5BE8EC0860
00007d5be8fd0457  jmp 0x00007D5BE8FCF10D
00007d5be8fd045c  call 0x00007D5BE8EBF5F0
00007d5be8fd0461  jmp 0x00007D5BE8FCF119
00007d5be8fd0466  call 0x00007D5BE8E09D70
00007d5be8fd046b  jmp 0x00007D5BE8FCF11F
00007d5be8fd0470  call 0x00007D5BE8EBE9C0
00007d5be8fd0475  jmp 0x00007D5BE8FCF129
00007d5be8fd047a  call 0x00007D5BE8EC0860
00007d5be8fd047f  jmp 0x00007D5BE8FCF151
00007d5be8fd0484  call 0x00007D5BE8EBF5F0
00007d5be8fd0489  jmp 0x00007D5BE8FCF15D
00007d5be8fd048e  call 0x00007D5BE8EBD750
00007d5be8fd0493  jmp 0x00007D5BE8FCF16A
00007d5be8fd0498  call 0x00007D5BE8EBC4E0
00007d5be8fd049d  jmp 0x00007D5BE8FCF177
00007d5be8fd04a2  call 0x00007D5BE8EC4740
00007d5be8fd04a7  jmp 0x00007D5BE8FCF184
00007d5be8fd04ac  call 0x00007D5BE8EB5400
00007d5be8fd04b1  jmp 0x00007D5BE8FCF191
00007d5be8fd04b6  call 0x00007D5BE8EB52F0
00007d5be8fd04bb  jmp 0x00007D5BE8FCF19E
00007d5be8fd04c0  call 0x00007D5BE8EC4620
00007d5be8fd04c5  jmp 0x00007D5BE8FCF1AB
00007d5be8fd04ca  call 0x00007D5BE8EC0860
00007d5be8fd04cf  jmp 0x00007D5BE8FCF1BE
00007d5be8fd04d4  call 0x00007D5BE8EBB270
00007d5be8fd04d9  jmp 0x00007D5BE8FCF1CB
00007d5be8fd04de  call 0x00007D5BE8EBA000
00007d5be8fd04e3  jmp 0x00007D5BE8FCF1D8
00007d5be8fd04e8  call 0x00007D5BE8EB8D90
00007d5be8fd04ed  jmp 0x00007D5BE8FCF1E5
00007d5be8fd04f2  call 0x00007D5BE8EB8A20
00007d5be8fd04f7  jmp 0x00007D5BE8FCF1F2
00007d5be8fd04fc  call 0x00007D5BE8EB5400
00007d5be8fd0501  jmp 0x00007D5BE8FCF1FC
00007d5be8fd0506  call 0x00007D5BE8EC2240
00007d5be8fd050b  jmp 0x00007D5BE8FCF206
00007d5be8fd0510  call 0x00007D5BE8EB52F0
00007d5be8fd0515  jmp 0x00007D5BE8FCF210
00007d5be8fd051a  call 0x00007D5BE8EC2120
00007d5be8fd051f  jmp 0x00007D5BE8FCF21A
00007d5be8fd0524  call 0x00007D5BE8EB77B0
00007d5be8fd0529  jmp 0x00007D5BE8FCF224
00007d5be8fd052e  call 0x00007D5BE8EB6550
00007d5be8fd0533  jmp 0x00007D5BE8FCF22E
00007d5be8fd0538  call 0x00007D5BE8EBFD50
00007d5be8fd053d  jmp 0x00007D5BE8FCF240
00007d5be8fd0542  call 0x00007D5BE8EB8EA0
00007d5be8fd0547  jmp 0x00007D5BE8FCF24A
00007d5be8fd054c  call 0x00007D5BE8EBFC30
00007d5be8fd0551  jmp 0x00007D5BE8FCF257
00007d5be8fd0556  call 0x00007D5BE8EB8D90
00007d5be8fd055b  jmp 0x00007D5BE8FCF264
00007d5be8fd0560  call 0x00007D5BE8EC2240
00007d5be8fd0565  jmp 0x00007D5BE8FCF271
00007d5be8fd056a  call 0x00007D5BE8EB5400
00007d5be8fd056f  jmp 0x00007D5BE8FCF27E
00007d5be8fd0574  call 0x00007D5BE8EB52F0
00007d5be8fd0579  jmp 0x00007D5BE8FCF28B
00007d5be8fd057e  call 0x00007D5BE8EC2120
00007d5be8fd0583  jmp 0x00007D5BE8FCF298
00007d5be8fd0588  call 0x00007D5BE8EB52F0
00007d5be8fd058d  jmp 0x00007D5BE8FCF2AB
00007d5be8fd0592  call 0x00007D5BE8EB52F0
00007d5be8fd0597  jmp 0x00007D5BE8FCF2BE
00007d5be8fd059c  call 0x00007D5BE8EB52F0
00007d5be8fd05a1  jmp 0x00007D5BE8FCF2D1
00007d5be8fd05a6  call 0x00007D5BE8EB52F0
00007d5be8fd05ab  jmp 0x00007D5BE8FCF2E4
00007d5be8fd05b0  call 0x00007D5BE8EC2240
00007d5be8fd05b5  jmp 0x00007D5BE8FCF2F9
00007d5be8fd05ba  call 0x00007D5BE8EC2240
00007d5be8fd05bf  jmp 0x00007D5BE8FCF30C
00007d5be8fd05c4  call 0x00007D5BE8EC2120
00007d5be8fd05c9  jmp 0x00007D5BE8FCF319
00007d5be8fd05ce  call 0x00007D5BE8EB52F0
00007d5be8fd05d3  jmp 0x00007D5BE8FCF32C
00007d5be8fd05d8  call 0x00007D5BE8EB52F0
00007d5be8fd05dd  jmp 0x00007D5BE8FCF34F
00007d5be8fd05e2  call 0x00007D5BE8EB52F0
00007d5be8fd05e7  jmp 0x00007D5BE8FCF362
00007d5be8fd05ec  call 0x00007D5BE8DFF540
00007d5be8fd05f1  jmp 0x00007D5BE8FCF380
00007d5be8fd05f6  call 0x00007D5BE8E08C20
00007d5be8fd05fb  jmp 0x00007D5BE8FCF38A
00007d5be8fd0600  call 0x00007D5BE8ED6600
00007d5be8fd0605  jmp 0x00007D5BE8FCF396
00007d5be8fd060a  call 0x00007D5BE8DFF540
00007d5be8fd060f  jmp 0x00007D5BE8FCF3A6
00007d5be8fd0614  call 0x00007D5BE8EC0370
00007d5be8fd0619  jmp 0x00007D5BE8FCF3D4
00007d5be8fd061e  call 0x00007D5BE8EBF100
00007d5be8fd0623  jmp 0x00007D5BE8FCF3DD
00007d5be8fd0628  call 0x00007D5BE8EC0370
00007d5be8fd062d  jmp 0x00007D5BE8FCF43B
00007d5be8fd0632  call 0x00007D5BE8EBF100
00007d5be8fd0637  jmp 0x00007D5BE8FCF444
00007d5be8fd063c  call 0x00007D5BE8EC0370
00007d5be8fd0641  jmp 0x00007D5BE8FCF48B
00007d5be8fd0646  call 0x00007D5BE8EBF100
00007d5be8fd064b  jmp 0x00007D5BE8FCF494
00007d5be8fd0650  call 0x00007D5BE8E0B720
00007d5be8fd0655  jmp 0x00007D5BE8FCF4D7
00007d5be8fd065a  call 0x00007D5BE8EB47C0
00007d5be8fd065f  jmp 0x00007D5BE8FCF4EA
00007d5be8fd0664  call 0x00007D5BE8E08B00
00007d5be8fd0669  jmp 0x00007D5BE8FCF501
00007d5be8fd066e  call 0x00007D5BE8DFF430
00007d5be8fd0673  jmp 0x00007D5BE8FCF514
00007d5be8fd0678  call 0x00007D5BE8DFF430
00007d5be8fd067d  jmp 0x00007D5BE8FCF527
00007d5be8fd0682  sub rsp, 0x08
00007d5be8fd0686  push rax
00007d5be8fd0687  push rcx
00007d5be8fd0688  push rdx
00007d5be8fd0689  push rdi
00007d5be8fd068a  push rsi
00007d5be8fd068b  push r8
00007d5be8fd068d  push r9
00007d5be8fd068f  push r10
00007d5be8fd0691  push r11
00007d5be8fd0693  sub rsp, 0xF0
00007d5be8fd069a  vmovaps [rsp], xmm0
00007d5be8fd069f  vmovaps [rsp+0x10], xmm2
00007d5be8fd06a5  vmovaps [rsp+0x20], xmm3
00007d5be8fd06ab  vmovaps [rsp+0x30], xmm4
00007d5be8fd06b1  vmovaps [rsp+0x40], xmm5
00007d5be8fd06b7  vmovaps [rsp+0x50], xmm6
00007d5be8fd06bd  vmovaps [rsp+0x60], xmm7
00007d5be8fd06c3  vmovaps [rsp+0x70], xmm8
00007d5be8fd06c9  vmovaps [rsp+0x80], xmm9
00007d5be8fd06d2  vmovaps [rsp+0x90], xmm10
00007d5be8fd06db  vmovaps [rsp+0xA0], xmm11
00007d5be8fd06e4  vmovaps [rsp+0xB0], xmm12
00007d5be8fd06ed  vmovaps [rsp+0xC0], xmm13
00007d5be8fd06f6  vmovaps [rsp+0xD0], xmm14
00007d5be8fd06ff  vmovaps [rsp+0xE0], xmm15
00007d5be8fd0708  sub rsp, 0x30
00007d5be8fd070c  movaps [rsp], xmm1
00007d5be8fd0710  movaps [rsp+0x10], xmm15
00007d5be8fd0716  movaps [rsp+0x20], xmm14
00007d5be8fd071c  lea rdi, [rsp]
00007d5be8fd0720  mov esi, 0x00
00007d5be8fd0725  mov rax, 0x5D345705A530
00007d5be8fd072f  call rax
00007d5be8fd0731  movaps xmm1, [rsp]
00007d5be8fd0735  add rsp, 0x30
00007d5be8fd0739  vmovaps xmm0, [rsp]
00007d5be8fd073e  vmovaps xmm2, [rsp+0x10]
00007d5be8fd0744  vmovaps xmm3, [rsp+0x20]
00007d5be8fd074a  vmovaps xmm4, [rsp+0x30]
00007d5be8fd0750  vmovaps xmm5, [rsp+0x40]
00007d5be8fd0756  vmovaps xmm6, [rsp+0x50]
00007d5be8fd075c  vmovaps xmm7, [rsp+0x60]
00007d5be8fd0762  vmovaps xmm8, [rsp+0x70]
00007d5be8fd0768  vmovaps xmm9, [rsp+0x80]
00007d5be8fd0771  vmovaps xmm10, [rsp+0x90]
00007d5be8fd077a  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd0783  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd078c  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd0795  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd079e  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd07a7  add rsp, 0xF0
00007d5be8fd07ae  pop r11
00007d5be8fd07b0  pop r10
00007d5be8fd07b2  pop r9
00007d5be8fd07b4  pop r8
00007d5be8fd07b6  pop rsi
00007d5be8fd07b7  pop rdi
00007d5be8fd07b8  pop rdx
00007d5be8fd07b9  pop rcx
00007d5be8fd07ba  pop rax
00007d5be8fd07bb  add rsp, 0x08
00007d5be8fd07bf  jmp 0x00007D5BE8FCF581
00007d5be8fd07c4  sub rsp, 0x08
00007d5be8fd07c8  push rax
00007d5be8fd07c9  push rcx
00007d5be8fd07ca  push rdx
00007d5be8fd07cb  push rdi
00007d5be8fd07cc  push rsi
00007d5be8fd07cd  push r8
00007d5be8fd07cf  push r9
00007d5be8fd07d1  push r10
00007d5be8fd07d3  push r11
00007d5be8fd07d5  sub rsp, 0xF0
00007d5be8fd07dc  vmovaps [rsp], xmm0
00007d5be8fd07e1  vmovaps [rsp+0x10], xmm1
00007d5be8fd07e7  vmovaps [rsp+0x20], xmm2
00007d5be8fd07ed  vmovaps [rsp+0x30], xmm3
00007d5be8fd07f3  vmovaps [rsp+0x40], xmm4
00007d5be8fd07f9  vmovaps [rsp+0x50], xmm5
00007d5be8fd07ff  vmovaps [rsp+0x60], xmm6
00007d5be8fd0805  vmovaps [rsp+0x70], xmm7
00007d5be8fd080b  vmovaps [rsp+0x80], xmm8
00007d5be8fd0814  vmovaps [rsp+0x90], xmm9
00007d5be8fd081d  vmovaps [rsp+0xA0], xmm10
00007d5be8fd0826  vmovaps [rsp+0xB0], xmm11
00007d5be8fd082f  vmovaps [rsp+0xC0], xmm12
00007d5be8fd0838  vmovaps [rsp+0xD0], xmm14
00007d5be8fd0841  vmovaps [rsp+0xE0], xmm15
00007d5be8fd084a  sub rsp, 0x30
00007d5be8fd084e  movaps [rsp], xmm13
00007d5be8fd0853  movaps [rsp+0x10], xmm1
00007d5be8fd0858  movaps [rsp+0x20], xmm14
00007d5be8fd085e  lea rdi, [rsp]
00007d5be8fd0862  mov esi, 0x00
00007d5be8fd0867  mov rax, 0x5D345705A530
00007d5be8fd0871  call rax
00007d5be8fd0873  movaps xmm13, [rsp]
00007d5be8fd0878  add rsp, 0x30
00007d5be8fd087c  vmovaps xmm0, [rsp]
00007d5be8fd0881  vmovaps xmm1, [rsp+0x10]
00007d5be8fd0887  vmovaps xmm2, [rsp+0x20]
00007d5be8fd088d  vmovaps xmm3, [rsp+0x30]
00007d5be8fd0893  vmovaps xmm4, [rsp+0x40]
00007d5be8fd0899  vmovaps xmm5, [rsp+0x50]
00007d5be8fd089f  vmovaps xmm6, [rsp+0x60]
00007d5be8fd08a5  vmovaps xmm7, [rsp+0x70]
00007d5be8fd08ab  vmovaps xmm8, [rsp+0x80]
00007d5be8fd08b4  vmovaps xmm9, [rsp+0x90]
00007d5be8fd08bd  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd08c6  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd08cf  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd08d8  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd08e1  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd08ea  add rsp, 0xF0
00007d5be8fd08f1  pop r11
00007d5be8fd08f3  pop r10
00007d5be8fd08f5  pop r9
00007d5be8fd08f7  pop r8
00007d5be8fd08f9  pop rsi
00007d5be8fd08fa  pop rdi
00007d5be8fd08fb  pop rdx
00007d5be8fd08fc  pop rcx
00007d5be8fd08fd  pop rax
00007d5be8fd08fe  add rsp, 0x08
00007d5be8fd0902  jmp 0x00007D5BE8FCF5CF
00007d5be8fd0907  sub rsp, 0x08
00007d5be8fd090b  push rax
00007d5be8fd090c  push rcx
00007d5be8fd090d  push rdx
00007d5be8fd090e  push rdi
00007d5be8fd090f  push rsi
00007d5be8fd0910  push r8
00007d5be8fd0912  push r9
00007d5be8fd0914  push r10
00007d5be8fd0916  push r11
00007d5be8fd0918  sub rsp, 0xF0
00007d5be8fd091f  vmovaps [rsp], xmm0
00007d5be8fd0924  vmovaps [rsp+0x10], xmm1
00007d5be8fd092a  vmovaps [rsp+0x20], xmm2
00007d5be8fd0930  vmovaps [rsp+0x30], xmm3
00007d5be8fd0936  vmovaps [rsp+0x40], xmm4
00007d5be8fd093c  vmovaps [rsp+0x50], xmm5
00007d5be8fd0942  vmovaps [rsp+0x60], xmm6
00007d5be8fd0948  vmovaps [rsp+0x70], xmm7
00007d5be8fd094e  vmovaps [rsp+0x80], xmm8
00007d5be8fd0957  vmovaps [rsp+0x90], xmm9
00007d5be8fd0960  vmovaps [rsp+0xA0], xmm10
00007d5be8fd0969  vmovaps [rsp+0xB0], xmm11
00007d5be8fd0972  vmovaps [rsp+0xC0], xmm12
00007d5be8fd097b  vmovaps [rsp+0xD0], xmm13
00007d5be8fd0984  vmovaps [rsp+0xE0], xmm14
00007d5be8fd098d  sub rsp, 0x30
00007d5be8fd0991  movaps [rsp], xmm15
00007d5be8fd0996  movaps [rsp+0x10], xmm14
00007d5be8fd099c  movaps [rsp+0x20], xmm1
00007d5be8fd09a1  lea rdi, [rsp]
00007d5be8fd09a5  mov esi, 0x00
00007d5be8fd09aa  mov rax, 0x5D345705A530
00007d5be8fd09b4  call rax
00007d5be8fd09b6  movaps xmm15, [rsp]
00007d5be8fd09bb  add rsp, 0x30
00007d5be8fd09bf  vmovaps xmm0, [rsp]
00007d5be8fd09c4  vmovaps xmm1, [rsp+0x10]
00007d5be8fd09ca  vmovaps xmm2, [rsp+0x20]
00007d5be8fd09d0  vmovaps xmm3, [rsp+0x30]
00007d5be8fd09d6  vmovaps xmm4, [rsp+0x40]
00007d5be8fd09dc  vmovaps xmm5, [rsp+0x50]
00007d5be8fd09e2  vmovaps xmm6, [rsp+0x60]
00007d5be8fd09e8  vmovaps xmm7, [rsp+0x70]
00007d5be8fd09ee  vmovaps xmm8, [rsp+0x80]
00007d5be8fd09f7  vmovaps xmm9, [rsp+0x90]
00007d5be8fd0a00  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd0a09  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd0a12  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd0a1b  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd0a24  vmovaps xmm14, [rsp+0xE0]
00007d5be8fd0a2d  add rsp, 0xF0
00007d5be8fd0a34  pop r11
00007d5be8fd0a36  pop r10
00007d5be8fd0a38  pop r9
00007d5be8fd0a3a  pop r8
00007d5be8fd0a3c  pop rsi
00007d5be8fd0a3d  pop rdi
00007d5be8fd0a3e  pop rdx
00007d5be8fd0a3f  pop rcx
00007d5be8fd0a40  pop rax
00007d5be8fd0a41  add rsp, 0x08
00007d5be8fd0a45  jmp 0x00007D5BE8FCF617
00007d5be8fd0a4a  sub rsp, 0x08
00007d5be8fd0a4e  push rax
00007d5be8fd0a4f  push rcx
00007d5be8fd0a50  push rdx
00007d5be8fd0a51  push rdi
00007d5be8fd0a52  push rsi
00007d5be8fd0a53  push r8
00007d5be8fd0a55  push r9
00007d5be8fd0a57  push r10
00007d5be8fd0a59  push r11
00007d5be8fd0a5b  sub rsp, 0xF0
00007d5be8fd0a62  vmovaps [rsp], xmm0
00007d5be8fd0a67  vmovaps [rsp+0x10], xmm2
00007d5be8fd0a6d  vmovaps [rsp+0x20], xmm3
00007d5be8fd0a73  vmovaps [rsp+0x30], xmm4
00007d5be8fd0a79  vmovaps [rsp+0x40], xmm5
00007d5be8fd0a7f  vmovaps [rsp+0x50], xmm6
00007d5be8fd0a85  vmovaps [rsp+0x60], xmm7
00007d5be8fd0a8b  vmovaps [rsp+0x70], xmm8
00007d5be8fd0a91  vmovaps [rsp+0x80], xmm9
00007d5be8fd0a9a  vmovaps [rsp+0x90], xmm10
00007d5be8fd0aa3  vmovaps [rsp+0xA0], xmm11
00007d5be8fd0aac  vmovaps [rsp+0xB0], xmm12
00007d5be8fd0ab5  vmovaps [rsp+0xC0], xmm13
00007d5be8fd0abe  vmovaps [rsp+0xD0], xmm14
00007d5be8fd0ac7  vmovaps [rsp+0xE0], xmm15
00007d5be8fd0ad0  sub rsp, 0x30
00007d5be8fd0ad4  movaps [rsp], xmm1
00007d5be8fd0ad8  movaps [rsp+0x10], xmm14
00007d5be8fd0ade  movaps [rsp+0x20], xmm10
00007d5be8fd0ae4  lea rdi, [rsp]
00007d5be8fd0ae8  mov esi, 0x00
00007d5be8fd0aed  mov rax, 0x5D345705A530
00007d5be8fd0af7  call rax
00007d5be8fd0af9  movaps xmm1, [rsp]
00007d5be8fd0afd  add rsp, 0x30
00007d5be8fd0b01  vmovaps xmm0, [rsp]
00007d5be8fd0b06  vmovaps xmm2, [rsp+0x10]
00007d5be8fd0b0c  vmovaps xmm3, [rsp+0x20]
00007d5be8fd0b12  vmovaps xmm4, [rsp+0x30]
00007d5be8fd0b18  vmovaps xmm5, [rsp+0x40]
00007d5be8fd0b1e  vmovaps xmm6, [rsp+0x50]
00007d5be8fd0b24  vmovaps xmm7, [rsp+0x60]
00007d5be8fd0b2a  vmovaps xmm8, [rsp+0x70]
00007d5be8fd0b30  vmovaps xmm9, [rsp+0x80]
00007d5be8fd0b39  vmovaps xmm10, [rsp+0x90]
00007d5be8fd0b42  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd0b4b  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd0b54  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd0b5d  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd0b66  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd0b6f  add rsp, 0xF0
00007d5be8fd0b76  pop r11
00007d5be8fd0b78  pop r10
00007d5be8fd0b7a  pop r9
00007d5be8fd0b7c  pop r8
00007d5be8fd0b7e  pop rsi
00007d5be8fd0b7f  pop rdi
00007d5be8fd0b80  pop rdx
00007d5be8fd0b81  pop rcx
00007d5be8fd0b82  pop rax
00007d5be8fd0b83  add rsp, 0x08
00007d5be8fd0b87  jmp 0x00007D5BE8FCF631
00007d5be8fd0b8c  sub rsp, 0x08
00007d5be8fd0b90  push rax
00007d5be8fd0b91  push rcx
00007d5be8fd0b92  push rdx
00007d5be8fd0b93  push rdi
00007d5be8fd0b94  push rsi
00007d5be8fd0b95  push r8
00007d5be8fd0b97  push r9
00007d5be8fd0b99  push r10
00007d5be8fd0b9b  push r11
00007d5be8fd0b9d  sub rsp, 0xF0
00007d5be8fd0ba4  vmovaps [rsp], xmm0
00007d5be8fd0ba9  vmovaps [rsp+0x10], xmm1
00007d5be8fd0baf  vmovaps [rsp+0x20], xmm2
00007d5be8fd0bb5  vmovaps [rsp+0x30], xmm3
00007d5be8fd0bbb  vmovaps [rsp+0x40], xmm4
00007d5be8fd0bc1  vmovaps [rsp+0x50], xmm5
00007d5be8fd0bc7  vmovaps [rsp+0x60], xmm6
00007d5be8fd0bcd  vmovaps [rsp+0x70], xmm7
00007d5be8fd0bd3  vmovaps [rsp+0x80], xmm8
00007d5be8fd0bdc  vmovaps [rsp+0x90], xmm9
00007d5be8fd0be5  vmovaps [rsp+0xA0], xmm10
00007d5be8fd0bee  vmovaps [rsp+0xB0], xmm11
00007d5be8fd0bf7  vmovaps [rsp+0xC0], xmm12
00007d5be8fd0c00  vmovaps [rsp+0xD0], xmm14
00007d5be8fd0c09  vmovaps [rsp+0xE0], xmm15
00007d5be8fd0c12  sub rsp, 0x30
00007d5be8fd0c16  movaps [rsp], xmm13
00007d5be8fd0c1b  movaps [rsp+0x10], xmm14
00007d5be8fd0c21  movaps [rsp+0x20], xmm2
00007d5be8fd0c26  lea rdi, [rsp]
00007d5be8fd0c2a  mov esi, 0x00
00007d5be8fd0c2f  mov rax, 0x5D345705A530
00007d5be8fd0c39  call rax
00007d5be8fd0c3b  movaps xmm13, [rsp]
00007d5be8fd0c40  add rsp, 0x30
00007d5be8fd0c44  vmovaps xmm0, [rsp]
00007d5be8fd0c49  vmovaps xmm1, [rsp+0x10]
00007d5be8fd0c4f  vmovaps xmm2, [rsp+0x20]
00007d5be8fd0c55  vmovaps xmm3, [rsp+0x30]
00007d5be8fd0c5b  vmovaps xmm4, [rsp+0x40]
00007d5be8fd0c61  vmovaps xmm5, [rsp+0x50]
00007d5be8fd0c67  vmovaps xmm6, [rsp+0x60]
00007d5be8fd0c6d  vmovaps xmm7, [rsp+0x70]
00007d5be8fd0c73  vmovaps xmm8, [rsp+0x80]
00007d5be8fd0c7c  vmovaps xmm9, [rsp+0x90]
00007d5be8fd0c85  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd0c8e  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd0c97  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd0ca0  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd0ca9  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd0cb2  add rsp, 0xF0
00007d5be8fd0cb9  pop r11
00007d5be8fd0cbb  pop r10
00007d5be8fd0cbd  pop r9
00007d5be8fd0cbf  pop r8
00007d5be8fd0cc1  pop rsi
00007d5be8fd0cc2  pop rdi
00007d5be8fd0cc3  pop rdx
00007d5be8fd0cc4  pop rcx
00007d5be8fd0cc5  pop rax
00007d5be8fd0cc6  add rsp, 0x08
00007d5be8fd0cca  jmp 0x00007D5BE8FCF64C
00007d5be8fd0ccf  sub rsp, 0x08
00007d5be8fd0cd3  push rax
00007d5be8fd0cd4  push rcx
00007d5be8fd0cd5  push rdx
00007d5be8fd0cd6  push rdi
00007d5be8fd0cd7  push rsi
00007d5be8fd0cd8  push r8
00007d5be8fd0cda  push r9
00007d5be8fd0cdc  push r10
00007d5be8fd0cde  push r11
00007d5be8fd0ce0  sub rsp, 0xF0
00007d5be8fd0ce7  vmovaps [rsp], xmm0
00007d5be8fd0cec  vmovaps [rsp+0x10], xmm2
00007d5be8fd0cf2  vmovaps [rsp+0x20], xmm3
00007d5be8fd0cf8  vmovaps [rsp+0x30], xmm4
00007d5be8fd0cfe  vmovaps [rsp+0x40], xmm5
00007d5be8fd0d04  vmovaps [rsp+0x50], xmm6
00007d5be8fd0d0a  vmovaps [rsp+0x60], xmm7
00007d5be8fd0d10  vmovaps [rsp+0x70], xmm8
00007d5be8fd0d16  vmovaps [rsp+0x80], xmm9
00007d5be8fd0d1f  vmovaps [rsp+0x90], xmm10
00007d5be8fd0d28  vmovaps [rsp+0xA0], xmm11
00007d5be8fd0d31  vmovaps [rsp+0xB0], xmm12
00007d5be8fd0d3a  vmovaps [rsp+0xC0], xmm13
00007d5be8fd0d43  vmovaps [rsp+0xD0], xmm14
00007d5be8fd0d4c  vmovaps [rsp+0xE0], xmm15
00007d5be8fd0d55  sub rsp, 0x30
00007d5be8fd0d59  movaps [rsp], xmm1
00007d5be8fd0d5d  movaps [rsp+0x10], xmm10
00007d5be8fd0d63  movaps [rsp+0x20], xmm2
00007d5be8fd0d68  lea rdi, [rsp]
00007d5be8fd0d6c  mov esi, 0x00
00007d5be8fd0d71  mov rax, 0x5D345705A530
00007d5be8fd0d7b  call rax
00007d5be8fd0d7d  movaps xmm1, [rsp]
00007d5be8fd0d81  add rsp, 0x30
00007d5be8fd0d85  vmovaps xmm0, [rsp]
00007d5be8fd0d8a  vmovaps xmm2, [rsp+0x10]
00007d5be8fd0d90  vmovaps xmm3, [rsp+0x20]
00007d5be8fd0d96  vmovaps xmm4, [rsp+0x30]
00007d5be8fd0d9c  vmovaps xmm5, [rsp+0x40]
00007d5be8fd0da2  vmovaps xmm6, [rsp+0x50]
00007d5be8fd0da8  vmovaps xmm7, [rsp+0x60]
00007d5be8fd0dae  vmovaps xmm8, [rsp+0x70]
00007d5be8fd0db4  vmovaps xmm9, [rsp+0x80]
00007d5be8fd0dbd  vmovaps xmm10, [rsp+0x90]
00007d5be8fd0dc6  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd0dcf  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd0dd8  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd0de1  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd0dea  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd0df3  add rsp, 0xF0
00007d5be8fd0dfa  pop r11
00007d5be8fd0dfc  pop r10
00007d5be8fd0dfe  pop r9
00007d5be8fd0e00  pop r8
00007d5be8fd0e02  pop rsi
00007d5be8fd0e03  pop rdi
00007d5be8fd0e04  pop rdx
00007d5be8fd0e05  pop rcx
00007d5be8fd0e06  pop rax
00007d5be8fd0e07  add rsp, 0x08
00007d5be8fd0e0b  jmp 0x00007D5BE8FCF6B4
00007d5be8fd0e10  sub rsp, 0x08
00007d5be8fd0e14  push rax
00007d5be8fd0e15  push rcx
00007d5be8fd0e16  push rdx
00007d5be8fd0e17  push rdi
00007d5be8fd0e18  push rsi
00007d5be8fd0e19  push r8
00007d5be8fd0e1b  push r9
00007d5be8fd0e1d  push r10
00007d5be8fd0e1f  push r11
00007d5be8fd0e21  sub rsp, 0xF0
00007d5be8fd0e28  vmovaps [rsp], xmm0
00007d5be8fd0e2d  vmovaps [rsp+0x10], xmm1
00007d5be8fd0e33  vmovaps [rsp+0x20], xmm2
00007d5be8fd0e39  vmovaps [rsp+0x30], xmm3
00007d5be8fd0e3f  vmovaps [rsp+0x40], xmm4
00007d5be8fd0e45  vmovaps [rsp+0x50], xmm5
00007d5be8fd0e4b  vmovaps [rsp+0x60], xmm6
00007d5be8fd0e51  vmovaps [rsp+0x70], xmm7
00007d5be8fd0e57  vmovaps [rsp+0x80], xmm8
00007d5be8fd0e60  vmovaps [rsp+0x90], xmm9
00007d5be8fd0e69  vmovaps [rsp+0xA0], xmm10
00007d5be8fd0e72  vmovaps [rsp+0xB0], xmm11
00007d5be8fd0e7b  vmovaps [rsp+0xC0], xmm12
00007d5be8fd0e84  vmovaps [rsp+0xD0], xmm13
00007d5be8fd0e8d  vmovaps [rsp+0xE0], xmm14
00007d5be8fd0e96  sub rsp, 0x30
00007d5be8fd0e9a  movaps [rsp], xmm15
00007d5be8fd0e9f  movaps [rsp+0x10], xmm10
00007d5be8fd0ea5  movaps [rsp+0x20], xmm2
00007d5be8fd0eaa  lea rdi, [rsp]
00007d5be8fd0eae  mov esi, 0x00
00007d5be8fd0eb3  mov rax, 0x5D345705A530
00007d5be8fd0ebd  call rax
00007d5be8fd0ebf  movaps xmm15, [rsp]
00007d5be8fd0ec4  add rsp, 0x30
00007d5be8fd0ec8  vmovaps xmm0, [rsp]
00007d5be8fd0ecd  vmovaps xmm1, [rsp+0x10]
00007d5be8fd0ed3  vmovaps xmm2, [rsp+0x20]
00007d5be8fd0ed9  vmovaps xmm3, [rsp+0x30]
00007d5be8fd0edf  vmovaps xmm4, [rsp+0x40]
00007d5be8fd0ee5  vmovaps xmm5, [rsp+0x50]
00007d5be8fd0eeb  vmovaps xmm6, [rsp+0x60]
00007d5be8fd0ef1  vmovaps xmm7, [rsp+0x70]
00007d5be8fd0ef7  vmovaps xmm8, [rsp+0x80]
00007d5be8fd0f00  vmovaps xmm9, [rsp+0x90]
00007d5be8fd0f09  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd0f12  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd0f1b  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd0f24  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd0f2d  vmovaps xmm14, [rsp+0xE0]
00007d5be8fd0f36  add rsp, 0xF0
00007d5be8fd0f3d  pop r11
00007d5be8fd0f3f  pop r10
00007d5be8fd0f41  pop r9
00007d5be8fd0f43  pop r8
00007d5be8fd0f45  pop rsi
00007d5be8fd0f46  pop rdi
00007d5be8fd0f47  pop rdx
00007d5be8fd0f48  pop rcx
00007d5be8fd0f49  pop rax
00007d5be8fd0f4a  add rsp, 0x08
00007d5be8fd0f4e  jmp 0x00007D5BE8FCF706
00007d5be8fd0f53  sub rsp, 0x08
00007d5be8fd0f57  push rax
00007d5be8fd0f58  push rcx
00007d5be8fd0f59  push rdx
00007d5be8fd0f5a  push rdi
00007d5be8fd0f5b  push rsi
00007d5be8fd0f5c  push r8
00007d5be8fd0f5e  push r9
00007d5be8fd0f60  push r10
00007d5be8fd0f62  push r11
00007d5be8fd0f64  sub rsp, 0xF0
00007d5be8fd0f6b  vmovaps [rsp], xmm0
00007d5be8fd0f70  vmovaps [rsp+0x10], xmm2
00007d5be8fd0f76  vmovaps [rsp+0x20], xmm3
00007d5be8fd0f7c  vmovaps [rsp+0x30], xmm4
00007d5be8fd0f82  vmovaps [rsp+0x40], xmm5
00007d5be8fd0f88  vmovaps [rsp+0x50], xmm6
00007d5be8fd0f8e  vmovaps [rsp+0x60], xmm7
00007d5be8fd0f94  vmovaps [rsp+0x70], xmm8
00007d5be8fd0f9a  vmovaps [rsp+0x80], xmm9
00007d5be8fd0fa3  vmovaps [rsp+0x90], xmm10
00007d5be8fd0fac  vmovaps [rsp+0xA0], xmm11
00007d5be8fd0fb5  vmovaps [rsp+0xB0], xmm12
00007d5be8fd0fbe  vmovaps [rsp+0xC0], xmm13
00007d5be8fd0fc7  vmovaps [rsp+0xD0], xmm14
00007d5be8fd0fd0  vmovaps [rsp+0xE0], xmm15
00007d5be8fd0fd9  sub rsp, 0x30
00007d5be8fd0fdd  movaps [rsp], xmm1
00007d5be8fd0fe1  movaps [rsp+0x10], xmm10
00007d5be8fd0fe7  movaps [rsp+0x20], xmm12
00007d5be8fd0fed  lea rdi, [rsp]
00007d5be8fd0ff1  mov esi, 0x00
00007d5be8fd0ff6  mov rax, 0x5D345705A530
00007d5be8fd1000  call rax
00007d5be8fd1002  movaps xmm1, [rsp]
00007d5be8fd1006  add rsp, 0x30
00007d5be8fd100a  vmovaps xmm0, [rsp]
00007d5be8fd100f  vmovaps xmm2, [rsp+0x10]
00007d5be8fd1015  vmovaps xmm3, [rsp+0x20]
00007d5be8fd101b  vmovaps xmm4, [rsp+0x30]
00007d5be8fd1021  vmovaps xmm5, [rsp+0x40]
00007d5be8fd1027  vmovaps xmm6, [rsp+0x50]
00007d5be8fd102d  vmovaps xmm7, [rsp+0x60]
00007d5be8fd1033  vmovaps xmm8, [rsp+0x70]
00007d5be8fd1039  vmovaps xmm9, [rsp+0x80]
00007d5be8fd1042  vmovaps xmm10, [rsp+0x90]
00007d5be8fd104b  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd1054  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd105d  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd1066  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd106f  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd1078  add rsp, 0xF0
00007d5be8fd107f  pop r11
00007d5be8fd1081  pop r10
00007d5be8fd1083  pop r9
00007d5be8fd1085  pop r8
00007d5be8fd1087  pop rsi
00007d5be8fd1088  pop rdi
00007d5be8fd1089  pop rdx
00007d5be8fd108a  pop rcx
00007d5be8fd108b  pop rax
00007d5be8fd108c  add rsp, 0x08
00007d5be8fd1090  jmp 0x00007D5BE8FCF732
00007d5be8fd1095  sub rsp, 0x08
00007d5be8fd1099  push rax
00007d5be8fd109a  push rcx
00007d5be8fd109b  push rdx
00007d5be8fd109c  push rdi
00007d5be8fd109d  push rsi
00007d5be8fd109e  push r8
00007d5be8fd10a0  push r9
00007d5be8fd10a2  push r10
00007d5be8fd10a4  push r11
00007d5be8fd10a6  sub rsp, 0xF0
00007d5be8fd10ad  vmovaps [rsp], xmm0
00007d5be8fd10b2  vmovaps [rsp+0x10], xmm1
00007d5be8fd10b8  vmovaps [rsp+0x20], xmm2
00007d5be8fd10be  vmovaps [rsp+0x30], xmm3
00007d5be8fd10c4  vmovaps [rsp+0x40], xmm4
00007d5be8fd10ca  vmovaps [rsp+0x50], xmm5
00007d5be8fd10d0  vmovaps [rsp+0x60], xmm6
00007d5be8fd10d6  vmovaps [rsp+0x70], xmm7
00007d5be8fd10dc  vmovaps [rsp+0x80], xmm8
00007d5be8fd10e5  vmovaps [rsp+0x90], xmm9
00007d5be8fd10ee  vmovaps [rsp+0xA0], xmm10
00007d5be8fd10f7  vmovaps [rsp+0xB0], xmm11
00007d5be8fd1100  vmovaps [rsp+0xC0], xmm12
00007d5be8fd1109  vmovaps [rsp+0xD0], xmm13
00007d5be8fd1112  vmovaps [rsp+0xE0], xmm14
00007d5be8fd111b  sub rsp, 0x30
00007d5be8fd111f  movaps [rsp], xmm15
00007d5be8fd1124  movaps [rsp+0x10], xmm10
00007d5be8fd112a  movaps [rsp+0x20], xmm12
00007d5be8fd1130  lea rdi, [rsp]
00007d5be8fd1134  mov esi, 0x00
00007d5be8fd1139  mov rax, 0x5D345705A530
00007d5be8fd1143  call rax
00007d5be8fd1145  movaps xmm15, [rsp]
00007d5be8fd114a  add rsp, 0x30
00007d5be8fd114e  vmovaps xmm0, [rsp]
00007d5be8fd1153  vmovaps xmm1, [rsp+0x10]
00007d5be8fd1159  vmovaps xmm2, [rsp+0x20]
00007d5be8fd115f  vmovaps xmm3, [rsp+0x30]
00007d5be8fd1165  vmovaps xmm4, [rsp+0x40]
00007d5be8fd116b  vmovaps xmm5, [rsp+0x50]
00007d5be8fd1171  vmovaps xmm6, [rsp+0x60]
00007d5be8fd1177  vmovaps xmm7, [rsp+0x70]
00007d5be8fd117d  vmovaps xmm8, [rsp+0x80]
00007d5be8fd1186  vmovaps xmm9, [rsp+0x90]
00007d5be8fd118f  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd1198  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd11a1  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd11aa  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd11b3  vmovaps xmm14, [rsp+0xE0]
00007d5be8fd11bc  add rsp, 0xF0
00007d5be8fd11c3  pop r11
00007d5be8fd11c5  pop r10
00007d5be8fd11c7  pop r9
00007d5be8fd11c9  pop r8
00007d5be8fd11cb  pop rsi
00007d5be8fd11cc  pop rdi
00007d5be8fd11cd  pop rdx
00007d5be8fd11ce  pop rcx
00007d5be8fd11cf  pop rax
00007d5be8fd11d0  add rsp, 0x08
00007d5be8fd11d4  jmp 0x00007D5BE8FCF75E
00007d5be8fd11d9  call 0x00007D5BE8DFF430
00007d5be8fd11de  jmp 0x00007D5BE8FCF7EE
00007d5be8fd11e3  call 0x00007D5BE8DFF430
00007d5be8fd11e8  jmp 0x00007D5BE8FCF801
00007d5be8fd11ed  sub rsp, 0x08
00007d5be8fd11f1  push rax
00007d5be8fd11f2  push rcx
00007d5be8fd11f3  push rdx
00007d5be8fd11f4  push rdi
00007d5be8fd11f5  push rsi
00007d5be8fd11f6  push r8
00007d5be8fd11f8  push r9
00007d5be8fd11fa  push r10
00007d5be8fd11fc  push r11
00007d5be8fd11fe  sub rsp, 0xF0
00007d5be8fd1205  vmovaps [rsp], xmm0
00007d5be8fd120a  vmovaps [rsp+0x10], xmm2
00007d5be8fd1210  vmovaps [rsp+0x20], xmm3
00007d5be8fd1216  vmovaps [rsp+0x30], xmm4
00007d5be8fd121c  vmovaps [rsp+0x40], xmm5
00007d5be8fd1222  vmovaps [rsp+0x50], xmm6
00007d5be8fd1228  vmovaps [rsp+0x60], xmm7
00007d5be8fd122e  vmovaps [rsp+0x70], xmm8
00007d5be8fd1234  vmovaps [rsp+0x80], xmm9
00007d5be8fd123d  vmovaps [rsp+0x90], xmm10
00007d5be8fd1246  vmovaps [rsp+0xA0], xmm11
00007d5be8fd124f  vmovaps [rsp+0xB0], xmm12
00007d5be8fd1258  vmovaps [rsp+0xC0], xmm13
00007d5be8fd1261  vmovaps [rsp+0xD0], xmm14
00007d5be8fd126a  vmovaps [rsp+0xE0], xmm15
00007d5be8fd1273  sub rsp, 0x30
00007d5be8fd1277  movaps [rsp], xmm1
00007d5be8fd127b  movaps [rsp+0x10], xmm13
00007d5be8fd1281  movaps [rsp+0x20], xmm2
00007d5be8fd1286  lea rdi, [rsp]
00007d5be8fd128a  mov esi, 0x00
00007d5be8fd128f  mov rax, 0x5D345705A530
00007d5be8fd1299  call rax
00007d5be8fd129b  movaps xmm1, [rsp]
00007d5be8fd129f  add rsp, 0x30
00007d5be8fd12a3  vmovaps xmm0, [rsp]
00007d5be8fd12a8  vmovaps xmm2, [rsp+0x10]
00007d5be8fd12ae  vmovaps xmm3, [rsp+0x20]
00007d5be8fd12b4  vmovaps xmm4, [rsp+0x30]
00007d5be8fd12ba  vmovaps xmm5, [rsp+0x40]
00007d5be8fd12c0  vmovaps xmm6, [rsp+0x50]
00007d5be8fd12c6  vmovaps xmm7, [rsp+0x60]
00007d5be8fd12cc  vmovaps xmm8, [rsp+0x70]
00007d5be8fd12d2  vmovaps xmm9, [rsp+0x80]
00007d5be8fd12db  vmovaps xmm10, [rsp+0x90]
00007d5be8fd12e4  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd12ed  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd12f6  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd12ff  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd1308  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd1311  add rsp, 0xF0
00007d5be8fd1318  pop r11
00007d5be8fd131a  pop r10
00007d5be8fd131c  pop r9
00007d5be8fd131e  pop r8
00007d5be8fd1320  pop rsi
00007d5be8fd1321  pop rdi
00007d5be8fd1322  pop rdx
00007d5be8fd1323  pop rcx
00007d5be8fd1324  pop rax
00007d5be8fd1325  add rsp, 0x08
00007d5be8fd1329  jmp 0x00007D5BE8FCF82C
00007d5be8fd132e  call 0x00007D5BE8E0E760
00007d5be8fd1333  jmp 0x00007D5BE8FCF839
00007d5be8fd1338  sub rsp, 0x08
00007d5be8fd133c  push rax
00007d5be8fd133d  push rcx
00007d5be8fd133e  push rdx
00007d5be8fd133f  push rdi
00007d5be8fd1340  push rsi
00007d5be8fd1341  push r8
00007d5be8fd1343  push r9
00007d5be8fd1345  push r10
00007d5be8fd1347  push r11
00007d5be8fd1349  sub rsp, 0xF0
00007d5be8fd1350  vmovaps [rsp], xmm0
00007d5be8fd1355  vmovaps [rsp+0x10], xmm1
00007d5be8fd135b  vmovaps [rsp+0x20], xmm2
00007d5be8fd1361  vmovaps [rsp+0x30], xmm3
00007d5be8fd1367  vmovaps [rsp+0x40], xmm4
00007d5be8fd136d  vmovaps [rsp+0x50], xmm5
00007d5be8fd1373  vmovaps [rsp+0x60], xmm6
00007d5be8fd1379  vmovaps [rsp+0x70], xmm7
00007d5be8fd137f  vmovaps [rsp+0x80], xmm8
00007d5be8fd1388  vmovaps [rsp+0x90], xmm9
00007d5be8fd1391  vmovaps [rsp+0xA0], xmm10
00007d5be8fd139a  vmovaps [rsp+0xB0], xmm11
00007d5be8fd13a3  vmovaps [rsp+0xC0], xmm12
00007d5be8fd13ac  vmovaps [rsp+0xD0], xmm14
00007d5be8fd13b5  vmovaps [rsp+0xE0], xmm15
00007d5be8fd13be  sub rsp, 0x30
00007d5be8fd13c2  movaps [rsp], xmm13
00007d5be8fd13c7  movaps [rsp+0x10], xmm2
00007d5be8fd13cc  movaps [rsp+0x20], xmm1
00007d5be8fd13d1  lea rdi, [rsp]
00007d5be8fd13d5  mov esi, 0x00
00007d5be8fd13da  mov rax, 0x5D345705A530
00007d5be8fd13e4  call rax
00007d5be8fd13e6  movaps xmm13, [rsp]
00007d5be8fd13eb  add rsp, 0x30
00007d5be8fd13ef  vmovaps xmm0, [rsp]
00007d5be8fd13f4  vmovaps xmm1, [rsp+0x10]
00007d5be8fd13fa  vmovaps xmm2, [rsp+0x20]
00007d5be8fd1400  vmovaps xmm3, [rsp+0x30]
00007d5be8fd1406  vmovaps xmm4, [rsp+0x40]
00007d5be8fd140c  vmovaps xmm5, [rsp+0x50]
00007d5be8fd1412  vmovaps xmm6, [rsp+0x60]
00007d5be8fd1418  vmovaps xmm7, [rsp+0x70]
00007d5be8fd141e  vmovaps xmm8, [rsp+0x80]
00007d5be8fd1427  vmovaps xmm9, [rsp+0x90]
00007d5be8fd1430  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd1439  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd1442  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd144b  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd1454  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd145d  add rsp, 0xF0
00007d5be8fd1464  pop r11
00007d5be8fd1466  pop r10
00007d5be8fd1468  pop r9
00007d5be8fd146a  pop r8
00007d5be8fd146c  pop rsi
00007d5be8fd146d  pop rdi
00007d5be8fd146e  pop rdx
00007d5be8fd146f  pop rcx
00007d5be8fd1470  pop rax
00007d5be8fd1471  add rsp, 0x08
00007d5be8fd1475  jmp 0x00007D5BE8FCF878
00007d5be8fd147a  sub rsp, 0x08
00007d5be8fd147e  push rax
00007d5be8fd147f  push rcx
00007d5be8fd1480  push rdx
00007d5be8fd1481  push rdi
00007d5be8fd1482  push rsi
00007d5be8fd1483  push r8
00007d5be8fd1485  push r9
00007d5be8fd1487  push r10
00007d5be8fd1489  push r11
00007d5be8fd148b  sub rsp, 0xF0
00007d5be8fd1492  vmovaps [rsp], xmm0
00007d5be8fd1497  vmovaps [rsp+0x10], xmm2
00007d5be8fd149d  vmovaps [rsp+0x20], xmm3
00007d5be8fd14a3  vmovaps [rsp+0x30], xmm4
00007d5be8fd14a9  vmovaps [rsp+0x40], xmm5
00007d5be8fd14af  vmovaps [rsp+0x50], xmm6
00007d5be8fd14b5  vmovaps [rsp+0x60], xmm7
00007d5be8fd14bb  vmovaps [rsp+0x70], xmm8
00007d5be8fd14c1  vmovaps [rsp+0x80], xmm9
00007d5be8fd14ca  vmovaps [rsp+0x90], xmm10
00007d5be8fd14d3  vmovaps [rsp+0xA0], xmm11
00007d5be8fd14dc  vmovaps [rsp+0xB0], xmm12
00007d5be8fd14e5  vmovaps [rsp+0xC0], xmm13
00007d5be8fd14ee  vmovaps [rsp+0xD0], xmm14
00007d5be8fd14f7  vmovaps [rsp+0xE0], xmm15
00007d5be8fd1500  sub rsp, 0x30
00007d5be8fd1504  movaps [rsp], xmm1
00007d5be8fd1508  movaps [rsp+0x10], xmm15
00007d5be8fd150e  movaps [rsp+0x20], xmm2
00007d5be8fd1513  lea rdi, [rsp]
00007d5be8fd1517  mov esi, 0x00
00007d5be8fd151c  mov rax, 0x5D345705A530
00007d5be8fd1526  call rax
00007d5be8fd1528  movaps xmm1, [rsp]
00007d5be8fd152c  add rsp, 0x30
00007d5be8fd1530  vmovaps xmm0, [rsp]
00007d5be8fd1535  vmovaps xmm2, [rsp+0x10]
00007d5be8fd153b  vmovaps xmm3, [rsp+0x20]
00007d5be8fd1541  vmovaps xmm4, [rsp+0x30]
00007d5be8fd1547  vmovaps xmm5, [rsp+0x40]
00007d5be8fd154d  vmovaps xmm6, [rsp+0x50]
00007d5be8fd1553  vmovaps xmm7, [rsp+0x60]
00007d5be8fd1559  vmovaps xmm8, [rsp+0x70]
00007d5be8fd155f  vmovaps xmm9, [rsp+0x80]
00007d5be8fd1568  vmovaps xmm10, [rsp+0x90]
00007d5be8fd1571  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd157a  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd1583  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd158c  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd1595  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd159e  add rsp, 0xF0
00007d5be8fd15a5  pop r11
00007d5be8fd15a7  pop r10
00007d5be8fd15a9  pop r9
00007d5be8fd15ab  pop r8
00007d5be8fd15ad  pop rsi
00007d5be8fd15ae  pop rdi
00007d5be8fd15af  pop rdx
00007d5be8fd15b0  pop rcx
00007d5be8fd15b1  pop rax
00007d5be8fd15b2  add rsp, 0x08
00007d5be8fd15b6  jmp 0x00007D5BE8FCF8AC
00007d5be8fd15bb  sub rsp, 0x08
00007d5be8fd15bf  push rax
00007d5be8fd15c0  push rcx
00007d5be8fd15c1  push rdx
00007d5be8fd15c2  push rdi
00007d5be8fd15c3  push rsi
00007d5be8fd15c4  push r8
00007d5be8fd15c6  push r9
00007d5be8fd15c8  push r10
00007d5be8fd15ca  push r11
00007d5be8fd15cc  sub rsp, 0xF0
00007d5be8fd15d3  vmovaps [rsp], xmm0
00007d5be8fd15d8  vmovaps [rsp+0x10], xmm1
00007d5be8fd15de  vmovaps [rsp+0x20], xmm2
00007d5be8fd15e4  vmovaps [rsp+0x30], xmm3
00007d5be8fd15ea  vmovaps [rsp+0x40], xmm4
00007d5be8fd15f0  vmovaps [rsp+0x50], xmm5
00007d5be8fd15f6  vmovaps [rsp+0x60], xmm6
00007d5be8fd15fc  vmovaps [rsp+0x70], xmm7
00007d5be8fd1602  vmovaps [rsp+0x80], xmm8
00007d5be8fd160b  vmovaps [rsp+0x90], xmm9
00007d5be8fd1614  vmovaps [rsp+0xA0], xmm10
00007d5be8fd161d  vmovaps [rsp+0xB0], xmm11
00007d5be8fd1626  vmovaps [rsp+0xC0], xmm12
00007d5be8fd162f  vmovaps [rsp+0xD0], xmm13
00007d5be8fd1638  vmovaps [rsp+0xE0], xmm15
00007d5be8fd1641  sub rsp, 0x30
00007d5be8fd1645  movaps [rsp], xmm14
00007d5be8fd164a  movaps [rsp+0x10], xmm2
00007d5be8fd164f  movaps [rsp+0x20], xmm15
00007d5be8fd1655  lea rdi, [rsp]
00007d5be8fd1659  mov esi, 0x00
00007d5be8fd165e  mov rax, 0x5D345705A530
00007d5be8fd1668  call rax
00007d5be8fd166a  movaps xmm14, [rsp]
00007d5be8fd166f  add rsp, 0x30
00007d5be8fd1673  vmovaps xmm0, [rsp]
00007d5be8fd1678  vmovaps xmm1, [rsp+0x10]
00007d5be8fd167e  vmovaps xmm2, [rsp+0x20]
00007d5be8fd1684  vmovaps xmm3, [rsp+0x30]
00007d5be8fd168a  vmovaps xmm4, [rsp+0x40]
00007d5be8fd1690  vmovaps xmm5, [rsp+0x50]
00007d5be8fd1696  vmovaps xmm6, [rsp+0x60]
00007d5be8fd169c  vmovaps xmm7, [rsp+0x70]
00007d5be8fd16a2  vmovaps xmm8, [rsp+0x80]
00007d5be8fd16ab  vmovaps xmm9, [rsp+0x90]
00007d5be8fd16b4  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd16bd  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd16c6  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd16cf  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd16d8  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd16e1  add rsp, 0xF0
00007d5be8fd16e8  pop r11
00007d5be8fd16ea  pop r10
00007d5be8fd16ec  pop r9
00007d5be8fd16ee  pop r8
00007d5be8fd16f0  pop rsi
00007d5be8fd16f1  pop rdi
00007d5be8fd16f2  pop rdx
00007d5be8fd16f3  pop rcx
00007d5be8fd16f4  pop rax
00007d5be8fd16f5  add rsp, 0x08
00007d5be8fd16f9  jmp 0x00007D5BE8FCF8E7
00007d5be8fd16fe  sub rsp, 0x08
00007d5be8fd1702  push rax
00007d5be8fd1703  push rcx
00007d5be8fd1704  push rdx
00007d5be8fd1705  push rdi
00007d5be8fd1706  push rsi
00007d5be8fd1707  push r8
00007d5be8fd1709  push r9
00007d5be8fd170b  push r10
00007d5be8fd170d  push r11
00007d5be8fd170f  sub rsp, 0xF0
00007d5be8fd1716  vmovaps [rsp], xmm0
00007d5be8fd171b  vmovaps [rsp+0x10], xmm1
00007d5be8fd1721  vmovaps [rsp+0x20], xmm2
00007d5be8fd1727  vmovaps [rsp+0x30], xmm3
00007d5be8fd172d  vmovaps [rsp+0x40], xmm4
00007d5be8fd1733  vmovaps [rsp+0x50], xmm5
00007d5be8fd1739  vmovaps [rsp+0x60], xmm6
00007d5be8fd173f  vmovaps [rsp+0x70], xmm7
00007d5be8fd1745  vmovaps [rsp+0x80], xmm8
00007d5be8fd174e  vmovaps [rsp+0x90], xmm9
00007d5be8fd1757  vmovaps [rsp+0xA0], xmm10
00007d5be8fd1760  vmovaps [rsp+0xB0], xmm11
00007d5be8fd1769  vmovaps [rsp+0xC0], xmm12
00007d5be8fd1772  vmovaps [rsp+0xD0], xmm13
00007d5be8fd177b  vmovaps [rsp+0xE0], xmm14
00007d5be8fd1784  sub rsp, 0x30
00007d5be8fd1788  movaps [rsp], xmm15
00007d5be8fd178d  movaps [rsp+0x10], xmm2
00007d5be8fd1792  movaps [rsp+0x20], xmm1
00007d5be8fd1797  lea rdi, [rsp]
00007d5be8fd179b  mov esi, 0x00
00007d5be8fd17a0  mov rax, 0x5D345705A530
00007d5be8fd17aa  call rax
00007d5be8fd17ac  movaps xmm15, [rsp]
00007d5be8fd17b1  add rsp, 0x30
00007d5be8fd17b5  vmovaps xmm0, [rsp]
00007d5be8fd17ba  vmovaps xmm1, [rsp+0x10]
00007d5be8fd17c0  vmovaps xmm2, [rsp+0x20]
00007d5be8fd17c6  vmovaps xmm3, [rsp+0x30]
00007d5be8fd17cc  vmovaps xmm4, [rsp+0x40]
00007d5be8fd17d2  vmovaps xmm5, [rsp+0x50]
00007d5be8fd17d8  vmovaps xmm6, [rsp+0x60]
00007d5be8fd17de  vmovaps xmm7, [rsp+0x70]
00007d5be8fd17e4  vmovaps xmm8, [rsp+0x80]
00007d5be8fd17ed  vmovaps xmm9, [rsp+0x90]
00007d5be8fd17f6  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd17ff  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd1808  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd1811  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd181a  vmovaps xmm14, [rsp+0xE0]
00007d5be8fd1823  add rsp, 0xF0
00007d5be8fd182a  pop r11
00007d5be8fd182c  pop r10
00007d5be8fd182e  pop r9
00007d5be8fd1830  pop r8
00007d5be8fd1832  pop rsi
00007d5be8fd1833  pop rdi
00007d5be8fd1834  pop rdx
00007d5be8fd1835  pop rcx
00007d5be8fd1836  pop rax
00007d5be8fd1837  add rsp, 0x08
00007d5be8fd183b  jmp 0x00007D5BE8FCF923
00007d5be8fd1840  call 0x00007D5BE8DFF430
00007d5be8fd1845  jmp 0x00007D5BE8FCF930
00007d5be8fd184a  sub rsp, 0x08
00007d5be8fd184e  push rax
00007d5be8fd184f  push rcx
00007d5be8fd1850  push rdx
00007d5be8fd1851  push rdi
00007d5be8fd1852  push rsi
00007d5be8fd1853  push r8
00007d5be8fd1855  push r9
00007d5be8fd1857  push r10
00007d5be8fd1859  push r11
00007d5be8fd185b  sub rsp, 0xF0
00007d5be8fd1862  vmovaps [rsp], xmm0
00007d5be8fd1867  vmovaps [rsp+0x10], xmm1
00007d5be8fd186d  vmovaps [rsp+0x20], xmm3
00007d5be8fd1873  vmovaps [rsp+0x30], xmm4
00007d5be8fd1879  vmovaps [rsp+0x40], xmm5
00007d5be8fd187f  vmovaps [rsp+0x50], xmm6
00007d5be8fd1885  vmovaps [rsp+0x60], xmm7
00007d5be8fd188b  vmovaps [rsp+0x70], xmm8
00007d5be8fd1891  vmovaps [rsp+0x80], xmm9
00007d5be8fd189a  vmovaps [rsp+0x90], xmm10
00007d5be8fd18a3  vmovaps [rsp+0xA0], xmm11
00007d5be8fd18ac  vmovaps [rsp+0xB0], xmm12
00007d5be8fd18b5  vmovaps [rsp+0xC0], xmm13
00007d5be8fd18be  vmovaps [rsp+0xD0], xmm14
00007d5be8fd18c7  vmovaps [rsp+0xE0], xmm15
00007d5be8fd18d0  sub rsp, 0x30
00007d5be8fd18d4  movaps [rsp], xmm2
00007d5be8fd18d8  movaps [rsp+0x10], xmm1
00007d5be8fd18dd  movaps [rsp+0x20], xmm14
00007d5be8fd18e3  lea rdi, [rsp]
00007d5be8fd18e7  mov esi, 0x00
00007d5be8fd18ec  mov rax, 0x5D345705A530
00007d5be8fd18f6  call rax
00007d5be8fd18f8  movaps xmm2, [rsp]
00007d5be8fd18fc  add rsp, 0x30
00007d5be8fd1900  vmovaps xmm0, [rsp]
00007d5be8fd1905  vmovaps xmm1, [rsp+0x10]
00007d5be8fd190b  vmovaps xmm3, [rsp+0x20]
00007d5be8fd1911  vmovaps xmm4, [rsp+0x30]
00007d5be8fd1917  vmovaps xmm5, [rsp+0x40]
00007d5be8fd191d  vmovaps xmm6, [rsp+0x50]
00007d5be8fd1923  vmovaps xmm7, [rsp+0x60]
00007d5be8fd1929  vmovaps xmm8, [rsp+0x70]
00007d5be8fd192f  vmovaps xmm9, [rsp+0x80]
00007d5be8fd1938  vmovaps xmm10, [rsp+0x90]
00007d5be8fd1941  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd194a  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd1953  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd195c  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd1965  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd196e  add rsp, 0xF0
00007d5be8fd1975  pop r11
00007d5be8fd1977  pop r10
00007d5be8fd1979  pop r9
00007d5be8fd197b  pop r8
00007d5be8fd197d  pop rsi
00007d5be8fd197e  pop rdi
00007d5be8fd197f  pop rdx
00007d5be8fd1980  pop rcx
00007d5be8fd1981  pop rax
00007d5be8fd1982  add rsp, 0x08
00007d5be8fd1986  jmp 0x00007D5BE8FCF96D
00007d5be8fd198b  sub rsp, 0x08
00007d5be8fd198f  push rax
00007d5be8fd1990  push rcx
00007d5be8fd1991  push rdx
00007d5be8fd1992  push rdi
00007d5be8fd1993  push rsi
00007d5be8fd1994  push r8
00007d5be8fd1996  push r9
00007d5be8fd1998  push r10
00007d5be8fd199a  push r11
00007d5be8fd199c  sub rsp, 0xF0
00007d5be8fd19a3  vmovaps [rsp], xmm0
00007d5be8fd19a8  vmovaps [rsp+0x10], xmm1
00007d5be8fd19ae  vmovaps [rsp+0x20], xmm2
00007d5be8fd19b4  vmovaps [rsp+0x30], xmm3
00007d5be8fd19ba  vmovaps [rsp+0x40], xmm4
00007d5be8fd19c0  vmovaps [rsp+0x50], xmm5
00007d5be8fd19c6  vmovaps [rsp+0x60], xmm6
00007d5be8fd19cc  vmovaps [rsp+0x70], xmm7
00007d5be8fd19d2  vmovaps [rsp+0x80], xmm8
00007d5be8fd19db  vmovaps [rsp+0x90], xmm9
00007d5be8fd19e4  vmovaps [rsp+0xA0], xmm10
00007d5be8fd19ed  vmovaps [rsp+0xB0], xmm11
00007d5be8fd19f6  vmovaps [rsp+0xC0], xmm12
00007d5be8fd19ff  vmovaps [rsp+0xD0], xmm13
00007d5be8fd1a08  vmovaps [rsp+0xE0], xmm14
00007d5be8fd1a11  sub rsp, 0x30
00007d5be8fd1a15  movaps [rsp], xmm15
00007d5be8fd1a1a  movaps [rsp+0x10], xmm14
00007d5be8fd1a20  movaps [rsp+0x20], xmm1
00007d5be8fd1a25  lea rdi, [rsp]
00007d5be8fd1a29  mov esi, 0x00
00007d5be8fd1a2e  mov rax, 0x5D345705A530
00007d5be8fd1a38  call rax
00007d5be8fd1a3a  movaps xmm15, [rsp]
00007d5be8fd1a3f  add rsp, 0x30
00007d5be8fd1a43  vmovaps xmm0, [rsp]
00007d5be8fd1a48  vmovaps xmm1, [rsp+0x10]
00007d5be8fd1a4e  vmovaps xmm2, [rsp+0x20]
00007d5be8fd1a54  vmovaps xmm3, [rsp+0x30]
00007d5be8fd1a5a  vmovaps xmm4, [rsp+0x40]
00007d5be8fd1a60  vmovaps xmm5, [rsp+0x50]
00007d5be8fd1a66  vmovaps xmm6, [rsp+0x60]
00007d5be8fd1a6c  vmovaps xmm7, [rsp+0x70]
00007d5be8fd1a72  vmovaps xmm8, [rsp+0x80]
00007d5be8fd1a7b  vmovaps xmm9, [rsp+0x90]
00007d5be8fd1a84  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd1a8d  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd1a96  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd1a9f  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd1aa8  vmovaps xmm14, [rsp+0xE0]
00007d5be8fd1ab1  add rsp, 0xF0
00007d5be8fd1ab8  pop r11
00007d5be8fd1aba  pop r10
00007d5be8fd1abc  pop r9
00007d5be8fd1abe  pop r8
00007d5be8fd1ac0  pop rsi
00007d5be8fd1ac1  pop rdi
00007d5be8fd1ac2  pop rdx
00007d5be8fd1ac3  pop rcx
00007d5be8fd1ac4  pop rax
00007d5be8fd1ac5  add rsp, 0x08
00007d5be8fd1ac9  jmp 0x00007D5BE8FCF9E7
00007d5be8fd1ace  call 0x00007D5BE8DFF430
00007d5be8fd1ad3  jmp 0x00007D5BE8FCF9F4
00007d5be8fd1ad8  sub rsp, 0x08
00007d5be8fd1adc  push rax
00007d5be8fd1add  push rcx
00007d5be8fd1ade  push rdx
00007d5be8fd1adf  push rdi
00007d5be8fd1ae0  push rsi
00007d5be8fd1ae1  push r8
00007d5be8fd1ae3  push r9
00007d5be8fd1ae5  push r10
00007d5be8fd1ae7  push r11
00007d5be8fd1ae9  sub rsp, 0xF0
00007d5be8fd1af0  vmovaps [rsp], xmm0
00007d5be8fd1af5  vmovaps [rsp+0x10], xmm1
00007d5be8fd1afb  vmovaps [rsp+0x20], xmm2
00007d5be8fd1b01  vmovaps [rsp+0x30], xmm3
00007d5be8fd1b07  vmovaps [rsp+0x40], xmm4
00007d5be8fd1b0d  vmovaps [rsp+0x50], xmm5
00007d5be8fd1b13  vmovaps [rsp+0x60], xmm6
00007d5be8fd1b19  vmovaps [rsp+0x70], xmm7
00007d5be8fd1b1f  vmovaps [rsp+0x80], xmm8
00007d5be8fd1b28  vmovaps [rsp+0x90], xmm9
00007d5be8fd1b31  vmovaps [rsp+0xA0], xmm10
00007d5be8fd1b3a  vmovaps [rsp+0xB0], xmm11
00007d5be8fd1b43  vmovaps [rsp+0xC0], xmm12
00007d5be8fd1b4c  vmovaps [rsp+0xD0], xmm13
00007d5be8fd1b55  vmovaps [rsp+0xE0], xmm15
00007d5be8fd1b5e  sub rsp, 0x30
00007d5be8fd1b62  movaps [rsp], xmm14
00007d5be8fd1b67  movaps [rsp+0x10], xmm13
00007d5be8fd1b6d  movaps [rsp+0x20], xmm1
00007d5be8fd1b72  lea rdi, [rsp]
00007d5be8fd1b76  mov esi, 0x00
00007d5be8fd1b7b  mov rax, 0x5D345705A530
00007d5be8fd1b85  call rax
00007d5be8fd1b87  movaps xmm14, [rsp]
00007d5be8fd1b8c  add rsp, 0x30
00007d5be8fd1b90  vmovaps xmm0, [rsp]
00007d5be8fd1b95  vmovaps xmm1, [rsp+0x10]
00007d5be8fd1b9b  vmovaps xmm2, [rsp+0x20]
00007d5be8fd1ba1  vmovaps xmm3, [rsp+0x30]
00007d5be8fd1ba7  vmovaps xmm4, [rsp+0x40]
00007d5be8fd1bad  vmovaps xmm5, [rsp+0x50]
00007d5be8fd1bb3  vmovaps xmm6, [rsp+0x60]
00007d5be8fd1bb9  vmovaps xmm7, [rsp+0x70]
00007d5be8fd1bbf  vmovaps xmm8, [rsp+0x80]
00007d5be8fd1bc8  vmovaps xmm9, [rsp+0x90]
00007d5be8fd1bd1  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd1bda  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd1be3  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd1bec  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd1bf5  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd1bfe  add rsp, 0xF0
00007d5be8fd1c05  pop r11
00007d5be8fd1c07  pop r10
00007d5be8fd1c09  pop r9
00007d5be8fd1c0b  pop r8
00007d5be8fd1c0d  pop rsi
00007d5be8fd1c0e  pop rdi
00007d5be8fd1c0f  pop rdx
00007d5be8fd1c10  pop rcx
00007d5be8fd1c11  pop rax
00007d5be8fd1c12  add rsp, 0x08
00007d5be8fd1c16  jmp 0x00007D5BE8FCFAAF
00007d5be8fd1c1b  sub rsp, 0x08
00007d5be8fd1c1f  push rax
00007d5be8fd1c20  push rcx
00007d5be8fd1c21  push rdx
00007d5be8fd1c22  push rdi
00007d5be8fd1c23  push rsi
00007d5be8fd1c24  push r8
00007d5be8fd1c26  push r9
00007d5be8fd1c28  push r10
00007d5be8fd1c2a  push r11
00007d5be8fd1c2c  sub rsp, 0xF0
00007d5be8fd1c33  vmovaps [rsp], xmm0
00007d5be8fd1c38  vmovaps [rsp+0x10], xmm1
00007d5be8fd1c3e  vmovaps [rsp+0x20], xmm2
00007d5be8fd1c44  vmovaps [rsp+0x30], xmm3
00007d5be8fd1c4a  vmovaps [rsp+0x40], xmm4
00007d5be8fd1c50  vmovaps [rsp+0x50], xmm5
00007d5be8fd1c56  vmovaps [rsp+0x60], xmm6
00007d5be8fd1c5c  vmovaps [rsp+0x70], xmm7
00007d5be8fd1c62  vmovaps [rsp+0x80], xmm8
00007d5be8fd1c6b  vmovaps [rsp+0x90], xmm9
00007d5be8fd1c74  vmovaps [rsp+0xA0], xmm10
00007d5be8fd1c7d  vmovaps [rsp+0xB0], xmm11
00007d5be8fd1c86  vmovaps [rsp+0xC0], xmm12
00007d5be8fd1c8f  vmovaps [rsp+0xD0], xmm13
00007d5be8fd1c98  vmovaps [rsp+0xE0], xmm14
00007d5be8fd1ca1  sub rsp, 0x30
00007d5be8fd1ca5  movaps [rsp], xmm15
00007d5be8fd1caa  movaps [rsp+0x10], xmm13
00007d5be8fd1cb0  movaps [rsp+0x20], xmm1
00007d5be8fd1cb5  lea rdi, [rsp]
00007d5be8fd1cb9  mov esi, 0x00
00007d5be8fd1cbe  mov rax, 0x5D345705A530
00007d5be8fd1cc8  call rax
00007d5be8fd1cca  movaps xmm15, [rsp]
00007d5be8fd1ccf  add rsp, 0x30
00007d5be8fd1cd3  vmovaps xmm0, [rsp]
00007d5be8fd1cd8  vmovaps xmm1, [rsp+0x10]
00007d5be8fd1cde  vmovaps xmm2, [rsp+0x20]
00007d5be8fd1ce4  vmovaps xmm3, [rsp+0x30]
00007d5be8fd1cea  vmovaps xmm4, [rsp+0x40]
00007d5be8fd1cf0  vmovaps xmm5, [rsp+0x50]
00007d5be8fd1cf6  vmovaps xmm6, [rsp+0x60]
00007d5be8fd1cfc  vmovaps xmm7, [rsp+0x70]
00007d5be8fd1d02  vmovaps xmm8, [rsp+0x80]
00007d5be8fd1d0b  vmovaps xmm9, [rsp+0x90]
00007d5be8fd1d14  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd1d1d  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd1d26  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd1d2f  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd1d38  vmovaps xmm14, [rsp+0xE0]
00007d5be8fd1d41  add rsp, 0xF0
00007d5be8fd1d48  pop r11
00007d5be8fd1d4a  pop r10
00007d5be8fd1d4c  pop r9
00007d5be8fd1d4e  pop r8
00007d5be8fd1d50  pop rsi
00007d5be8fd1d51  pop rdi
00007d5be8fd1d52  pop rdx
00007d5be8fd1d53  pop rcx
00007d5be8fd1d54  pop rax
00007d5be8fd1d55  add rsp, 0x08
00007d5be8fd1d59  jmp 0x00007D5BE8FCFAEB
00007d5be8fd1d5e  call 0x00007D5BE8DFF430
00007d5be8fd1d63  jmp 0x00007D5BE8FCFAF8
00007d5be8fd1d68  sub rsp, 0x08
00007d5be8fd1d6c  push rax
00007d5be8fd1d6d  push rcx
00007d5be8fd1d6e  push rdx
00007d5be8fd1d6f  push rdi
00007d5be8fd1d70  push rsi
00007d5be8fd1d71  push r8
00007d5be8fd1d73  push r9
00007d5be8fd1d75  push r10
00007d5be8fd1d77  push r11
00007d5be8fd1d79  sub rsp, 0xF0
00007d5be8fd1d80  vmovaps [rsp], xmm0
00007d5be8fd1d85  vmovaps [rsp+0x10], xmm1
00007d5be8fd1d8b  vmovaps [rsp+0x20], xmm2
00007d5be8fd1d91  vmovaps [rsp+0x30], xmm3
00007d5be8fd1d97  vmovaps [rsp+0x40], xmm4
00007d5be8fd1d9d  vmovaps [rsp+0x50], xmm5
00007d5be8fd1da3  vmovaps [rsp+0x60], xmm6
00007d5be8fd1da9  vmovaps [rsp+0x70], xmm7
00007d5be8fd1daf  vmovaps [rsp+0x80], xmm8
00007d5be8fd1db8  vmovaps [rsp+0x90], xmm9
00007d5be8fd1dc1  vmovaps [rsp+0xA0], xmm10
00007d5be8fd1dca  vmovaps [rsp+0xB0], xmm11
00007d5be8fd1dd3  vmovaps [rsp+0xC0], xmm12
00007d5be8fd1ddc  vmovaps [rsp+0xD0], xmm13
00007d5be8fd1de5  vmovaps [rsp+0xE0], xmm15
00007d5be8fd1dee  sub rsp, 0x30
00007d5be8fd1df2  movaps [rsp], xmm14
00007d5be8fd1df7  movaps [rsp+0x10], xmm13
00007d5be8fd1dfd  movaps [rsp+0x20], xmm2
00007d5be8fd1e02  lea rdi, [rsp]
00007d5be8fd1e06  mov esi, 0x00
00007d5be8fd1e0b  mov rax, 0x5D345705A530
00007d5be8fd1e15  call rax
00007d5be8fd1e17  movaps xmm14, [rsp]
00007d5be8fd1e1c  add rsp, 0x30
00007d5be8fd1e20  vmovaps xmm0, [rsp]
00007d5be8fd1e25  vmovaps xmm1, [rsp+0x10]
00007d5be8fd1e2b  vmovaps xmm2, [rsp+0x20]
00007d5be8fd1e31  vmovaps xmm3, [rsp+0x30]
00007d5be8fd1e37  vmovaps xmm4, [rsp+0x40]
00007d5be8fd1e3d  vmovaps xmm5, [rsp+0x50]
00007d5be8fd1e43  vmovaps xmm6, [rsp+0x60]
00007d5be8fd1e49  vmovaps xmm7, [rsp+0x70]
00007d5be8fd1e4f  vmovaps xmm8, [rsp+0x80]
00007d5be8fd1e58  vmovaps xmm9, [rsp+0x90]
00007d5be8fd1e61  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd1e6a  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd1e73  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd1e7c  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd1e85  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd1e8e  add rsp, 0xF0
00007d5be8fd1e95  pop r11
00007d5be8fd1e97  pop r10
00007d5be8fd1e99  pop r9
00007d5be8fd1e9b  pop r8
00007d5be8fd1e9d  pop rsi
00007d5be8fd1e9e  pop rdi
00007d5be8fd1e9f  pop rdx
00007d5be8fd1ea0  pop rcx
00007d5be8fd1ea1  pop rax
00007d5be8fd1ea2  add rsp, 0x08
00007d5be8fd1ea6  jmp 0x00007D5BE8FCFB24
00007d5be8fd1eab  sub rsp, 0x08
00007d5be8fd1eaf  push rax
00007d5be8fd1eb0  push rcx
00007d5be8fd1eb1  push rdx
00007d5be8fd1eb2  push rdi
00007d5be8fd1eb3  push rsi
00007d5be8fd1eb4  push r8
00007d5be8fd1eb6  push r9
00007d5be8fd1eb8  push r10
00007d5be8fd1eba  push r11
00007d5be8fd1ebc  sub rsp, 0xF0
00007d5be8fd1ec3  vmovaps [rsp], xmm0
00007d5be8fd1ec8  vmovaps [rsp+0x10], xmm2
00007d5be8fd1ece  vmovaps [rsp+0x20], xmm3
00007d5be8fd1ed4  vmovaps [rsp+0x30], xmm4
00007d5be8fd1eda  vmovaps [rsp+0x40], xmm5
00007d5be8fd1ee0  vmovaps [rsp+0x50], xmm6
00007d5be8fd1ee6  vmovaps [rsp+0x60], xmm7
00007d5be8fd1eec  vmovaps [rsp+0x70], xmm8
00007d5be8fd1ef2  vmovaps [rsp+0x80], xmm9
00007d5be8fd1efb  vmovaps [rsp+0x90], xmm10
00007d5be8fd1f04  vmovaps [rsp+0xA0], xmm11
00007d5be8fd1f0d  vmovaps [rsp+0xB0], xmm12
00007d5be8fd1f16  vmovaps [rsp+0xC0], xmm13
00007d5be8fd1f1f  vmovaps [rsp+0xD0], xmm14
00007d5be8fd1f28  vmovaps [rsp+0xE0], xmm15
00007d5be8fd1f31  sub rsp, 0x30
00007d5be8fd1f35  movaps [rsp], xmm1
00007d5be8fd1f39  movaps [rsp+0x10], xmm13
00007d5be8fd1f3f  movaps [rsp+0x20], xmm2
00007d5be8fd1f44  lea rdi, [rsp]
00007d5be8fd1f48  mov esi, 0x00
00007d5be8fd1f4d  mov rax, 0x5D345705A530
00007d5be8fd1f57  call rax
00007d5be8fd1f59  movaps xmm1, [rsp]
00007d5be8fd1f5d  add rsp, 0x30
00007d5be8fd1f61  vmovaps xmm0, [rsp]
00007d5be8fd1f66  vmovaps xmm2, [rsp+0x10]
00007d5be8fd1f6c  vmovaps xmm3, [rsp+0x20]
00007d5be8fd1f72  vmovaps xmm4, [rsp+0x30]
00007d5be8fd1f78  vmovaps xmm5, [rsp+0x40]
00007d5be8fd1f7e  vmovaps xmm6, [rsp+0x50]
00007d5be8fd1f84  vmovaps xmm7, [rsp+0x60]
00007d5be8fd1f8a  vmovaps xmm8, [rsp+0x70]
00007d5be8fd1f90  vmovaps xmm9, [rsp+0x80]
00007d5be8fd1f99  vmovaps xmm10, [rsp+0x90]
00007d5be8fd1fa2  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd1fab  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd1fb4  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd1fbd  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd1fc6  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd1fcf  add rsp, 0xF0
00007d5be8fd1fd6  pop r11
00007d5be8fd1fd8  pop r10
00007d5be8fd1fda  pop r9
00007d5be8fd1fdc  pop r8
00007d5be8fd1fde  pop rsi
00007d5be8fd1fdf  pop rdi
00007d5be8fd1fe0  pop rdx
00007d5be8fd1fe1  pop rcx
00007d5be8fd1fe2  pop rax
00007d5be8fd1fe3  add rsp, 0x08
00007d5be8fd1fe7  jmp 0x00007D5BE8FCFB52
00007d5be8fd1fec  sub rsp, 0x08
00007d5be8fd1ff0  push rax
00007d5be8fd1ff1  push rcx
00007d5be8fd1ff2  push rdx
00007d5be8fd1ff3  push rdi
00007d5be8fd1ff4  push rsi
00007d5be8fd1ff5  push r8
00007d5be8fd1ff7  push r9
00007d5be8fd1ff9  push r10
00007d5be8fd1ffb  push r11
00007d5be8fd1ffd  sub rsp, 0xF0
00007d5be8fd2004  vmovaps [rsp], xmm0
00007d5be8fd2009  vmovaps [rsp+0x10], xmm1
00007d5be8fd200f  vmovaps [rsp+0x20], xmm3
00007d5be8fd2015  vmovaps [rsp+0x30], xmm4
00007d5be8fd201b  vmovaps [rsp+0x40], xmm5
00007d5be8fd2021  vmovaps [rsp+0x50], xmm6
00007d5be8fd2027  vmovaps [rsp+0x60], xmm7
00007d5be8fd202d  vmovaps [rsp+0x70], xmm8
00007d5be8fd2033  vmovaps [rsp+0x80], xmm9
00007d5be8fd203c  vmovaps [rsp+0x90], xmm10
00007d5be8fd2045  vmovaps [rsp+0xA0], xmm11
00007d5be8fd204e  vmovaps [rsp+0xB0], xmm12
00007d5be8fd2057  vmovaps [rsp+0xC0], xmm13
00007d5be8fd2060  vmovaps [rsp+0xD0], xmm14
00007d5be8fd2069  vmovaps [rsp+0xE0], xmm15
00007d5be8fd2072  sub rsp, 0x30
00007d5be8fd2076  movaps [rsp], xmm2
00007d5be8fd207a  movaps [rsp+0x10], xmm1
00007d5be8fd207f  movaps [rsp+0x20], xmm13
00007d5be8fd2085  lea rdi, [rsp]
00007d5be8fd2089  mov esi, 0x00
00007d5be8fd208e  mov rax, 0x5D345705A530
00007d5be8fd2098  call rax
00007d5be8fd209a  movaps xmm2, [rsp]
00007d5be8fd209e  add rsp, 0x30
00007d5be8fd20a2  vmovaps xmm0, [rsp]
00007d5be8fd20a7  vmovaps xmm1, [rsp+0x10]
00007d5be8fd20ad  vmovaps xmm3, [rsp+0x20]
00007d5be8fd20b3  vmovaps xmm4, [rsp+0x30]
00007d5be8fd20b9  vmovaps xmm5, [rsp+0x40]
00007d5be8fd20bf  vmovaps xmm6, [rsp+0x50]
00007d5be8fd20c5  vmovaps xmm7, [rsp+0x60]
00007d5be8fd20cb  vmovaps xmm8, [rsp+0x70]
00007d5be8fd20d1  vmovaps xmm9, [rsp+0x80]
00007d5be8fd20da  vmovaps xmm10, [rsp+0x90]
00007d5be8fd20e3  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd20ec  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd20f5  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd20fe  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd2107  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd2110  add rsp, 0xF0
00007d5be8fd2117  pop r11
00007d5be8fd2119  pop r10
00007d5be8fd211b  pop r9
00007d5be8fd211d  pop r8
00007d5be8fd211f  pop rsi
00007d5be8fd2120  pop rdi
00007d5be8fd2121  pop rdx
00007d5be8fd2122  pop rcx
00007d5be8fd2123  pop rax
00007d5be8fd2124  add rsp, 0x08
00007d5be8fd2128  jmp 0x00007D5BE8FCFBAB
00007d5be8fd212d  call 0x00007D5BE8DFF430
00007d5be8fd2132  jmp 0x00007D5BE8FCFBB8
00007d5be8fd2137  sub rsp, 0x08
00007d5be8fd213b  push rax
00007d5be8fd213c  push rcx
00007d5be8fd213d  push rdx
00007d5be8fd213e  push rdi
00007d5be8fd213f  push rsi
00007d5be8fd2140  push r8
00007d5be8fd2142  push r9
00007d5be8fd2144  push r10
00007d5be8fd2146  push r11
00007d5be8fd2148  sub rsp, 0xF0
00007d5be8fd214f  vmovaps [rsp], xmm0
00007d5be8fd2154  vmovaps [rsp+0x10], xmm1
00007d5be8fd215a  vmovaps [rsp+0x20], xmm2
00007d5be8fd2160  vmovaps [rsp+0x30], xmm3
00007d5be8fd2166  vmovaps [rsp+0x40], xmm4
00007d5be8fd216c  vmovaps [rsp+0x50], xmm5
00007d5be8fd2172  vmovaps [rsp+0x60], xmm6
00007d5be8fd2178  vmovaps [rsp+0x70], xmm7
00007d5be8fd217e  vmovaps [rsp+0x80], xmm8
00007d5be8fd2187  vmovaps [rsp+0x90], xmm9
00007d5be8fd2190  vmovaps [rsp+0xA0], xmm10
00007d5be8fd2199  vmovaps [rsp+0xB0], xmm11
00007d5be8fd21a2  vmovaps [rsp+0xC0], xmm12
00007d5be8fd21ab  vmovaps [rsp+0xD0], xmm13
00007d5be8fd21b4  vmovaps [rsp+0xE0], xmm14
00007d5be8fd21bd  sub rsp, 0x30
00007d5be8fd21c1  movaps [rsp], xmm15
00007d5be8fd21c6  movaps [rsp+0x10], xmm13
00007d5be8fd21cc  movaps [rsp+0x20], xmm1
00007d5be8fd21d1  lea rdi, [rsp]
00007d5be8fd21d5  mov esi, 0x00
00007d5be8fd21da  mov rax, 0x5D345705A530
00007d5be8fd21e4  call rax
00007d5be8fd21e6  movaps xmm15, [rsp]
00007d5be8fd21eb  add rsp, 0x30
00007d5be8fd21ef  vmovaps xmm0, [rsp]
00007d5be8fd21f4  vmovaps xmm1, [rsp+0x10]
00007d5be8fd21fa  vmovaps xmm2, [rsp+0x20]
00007d5be8fd2200  vmovaps xmm3, [rsp+0x30]
00007d5be8fd2206  vmovaps xmm4, [rsp+0x40]
00007d5be8fd220c  vmovaps xmm5, [rsp+0x50]
00007d5be8fd2212  vmovaps xmm6, [rsp+0x60]
00007d5be8fd2218  vmovaps xmm7, [rsp+0x70]
00007d5be8fd221e  vmovaps xmm8, [rsp+0x80]
00007d5be8fd2227  vmovaps xmm9, [rsp+0x90]
00007d5be8fd2230  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd2239  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd2242  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd224b  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd2254  vmovaps xmm14, [rsp+0xE0]
00007d5be8fd225d  add rsp, 0xF0
00007d5be8fd2264  pop r11
00007d5be8fd2266  pop r10
00007d5be8fd2268  pop r9
00007d5be8fd226a  pop r8
00007d5be8fd226c  pop rsi
00007d5be8fd226d  pop rdi
00007d5be8fd226e  pop rdx
00007d5be8fd226f  pop rcx
00007d5be8fd2270  pop rax
00007d5be8fd2271  add rsp, 0x08
00007d5be8fd2275  jmp 0x00007D5BE8FCFBF7
00007d5be8fd227a  sub rsp, 0x08
00007d5be8fd227e  push rax
00007d5be8fd227f  push rcx
00007d5be8fd2280  push rdx
00007d5be8fd2281  push rdi
00007d5be8fd2282  push rsi
00007d5be8fd2283  push r8
00007d5be8fd2285  push r9
00007d5be8fd2287  push r10
00007d5be8fd2289  push r11
00007d5be8fd228b  sub rsp, 0xF0
00007d5be8fd2292  vmovaps [rsp], xmm0
00007d5be8fd2297  vmovaps [rsp+0x10], xmm1
00007d5be8fd229d  vmovaps [rsp+0x20], xmm2
00007d5be8fd22a3  vmovaps [rsp+0x30], xmm3
00007d5be8fd22a9  vmovaps [rsp+0x40], xmm4
00007d5be8fd22af  vmovaps [rsp+0x50], xmm5
00007d5be8fd22b5  vmovaps [rsp+0x60], xmm6
00007d5be8fd22bb  vmovaps [rsp+0x70], xmm7
00007d5be8fd22c1  vmovaps [rsp+0x80], xmm8
00007d5be8fd22ca  vmovaps [rsp+0x90], xmm9
00007d5be8fd22d3  vmovaps [rsp+0xA0], xmm10
00007d5be8fd22dc  vmovaps [rsp+0xB0], xmm11
00007d5be8fd22e5  vmovaps [rsp+0xC0], xmm12
00007d5be8fd22ee  vmovaps [rsp+0xD0], xmm13
00007d5be8fd22f7  vmovaps [rsp+0xE0], xmm15
00007d5be8fd2300  sub rsp, 0x30
00007d5be8fd2304  movaps [rsp], xmm14
00007d5be8fd2309  movaps [rsp+0x10], xmm11
00007d5be8fd230f  movaps [rsp+0x20], xmm1
00007d5be8fd2314  lea rdi, [rsp]
00007d5be8fd2318  mov esi, 0x00
00007d5be8fd231d  mov rax, 0x5D345705A530
00007d5be8fd2327  call rax
00007d5be8fd2329  movaps xmm14, [rsp]
00007d5be8fd232e  add rsp, 0x30
00007d5be8fd2332  vmovaps xmm0, [rsp]
00007d5be8fd2337  vmovaps xmm1, [rsp+0x10]
00007d5be8fd233d  vmovaps xmm2, [rsp+0x20]
00007d5be8fd2343  vmovaps xmm3, [rsp+0x30]
00007d5be8fd2349  vmovaps xmm4, [rsp+0x40]
00007d5be8fd234f  vmovaps xmm5, [rsp+0x50]
00007d5be8fd2355  vmovaps xmm6, [rsp+0x60]
00007d5be8fd235b  vmovaps xmm7, [rsp+0x70]
00007d5be8fd2361  vmovaps xmm8, [rsp+0x80]
00007d5be8fd236a  vmovaps xmm9, [rsp+0x90]
00007d5be8fd2373  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd237c  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd2385  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd238e  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd2397  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd23a0  add rsp, 0xF0
00007d5be8fd23a7  pop r11
00007d5be8fd23a9  pop r10
00007d5be8fd23ab  pop r9
00007d5be8fd23ad  pop r8
00007d5be8fd23af  pop rsi
00007d5be8fd23b0  pop rdi
00007d5be8fd23b1  pop rdx
00007d5be8fd23b2  pop rcx
00007d5be8fd23b3  pop rax
00007d5be8fd23b4  add rsp, 0x08
00007d5be8fd23b8  jmp 0x00007D5BE8FCFC21
00007d5be8fd23bd  sub rsp, 0x08
00007d5be8fd23c1  push rax
00007d5be8fd23c2  push rcx
00007d5be8fd23c3  push rdx
00007d5be8fd23c4  push rdi
00007d5be8fd23c5  push rsi
00007d5be8fd23c6  push r8
00007d5be8fd23c8  push r9
00007d5be8fd23ca  push r10
00007d5be8fd23cc  push r11
00007d5be8fd23ce  sub rsp, 0xF0
00007d5be8fd23d5  vmovaps [rsp], xmm0
00007d5be8fd23da  vmovaps [rsp+0x10], xmm1
00007d5be8fd23e0  vmovaps [rsp+0x20], xmm2
00007d5be8fd23e6  vmovaps [rsp+0x30], xmm3
00007d5be8fd23ec  vmovaps [rsp+0x40], xmm4
00007d5be8fd23f2  vmovaps [rsp+0x50], xmm5
00007d5be8fd23f8  vmovaps [rsp+0x60], xmm6
00007d5be8fd23fe  vmovaps [rsp+0x70], xmm7
00007d5be8fd2404  vmovaps [rsp+0x80], xmm8
00007d5be8fd240d  vmovaps [rsp+0x90], xmm9
00007d5be8fd2416  vmovaps [rsp+0xA0], xmm10
00007d5be8fd241f  vmovaps [rsp+0xB0], xmm11
00007d5be8fd2428  vmovaps [rsp+0xC0], xmm12
00007d5be8fd2431  vmovaps [rsp+0xD0], xmm14
00007d5be8fd243a  vmovaps [rsp+0xE0], xmm15
00007d5be8fd2443  sub rsp, 0x30
00007d5be8fd2447  movaps [rsp], xmm13
00007d5be8fd244c  movaps [rsp+0x10], xmm11
00007d5be8fd2452  movaps [rsp+0x20], xmm1
00007d5be8fd2457  lea rdi, [rsp]
00007d5be8fd245b  mov esi, 0x00
00007d5be8fd2460  mov rax, 0x5D345705A530
00007d5be8fd246a  call rax
00007d5be8fd246c  movaps xmm13, [rsp]
00007d5be8fd2471  add rsp, 0x30
00007d5be8fd2475  vmovaps xmm0, [rsp]
00007d5be8fd247a  vmovaps xmm1, [rsp+0x10]
00007d5be8fd2480  vmovaps xmm2, [rsp+0x20]
00007d5be8fd2486  vmovaps xmm3, [rsp+0x30]
00007d5be8fd248c  vmovaps xmm4, [rsp+0x40]
00007d5be8fd2492  vmovaps xmm5, [rsp+0x50]
00007d5be8fd2498  vmovaps xmm6, [rsp+0x60]
00007d5be8fd249e  vmovaps xmm7, [rsp+0x70]
00007d5be8fd24a4  vmovaps xmm8, [rsp+0x80]
00007d5be8fd24ad  vmovaps xmm9, [rsp+0x90]
00007d5be8fd24b6  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd24bf  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd24c8  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd24d1  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd24da  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd24e3  add rsp, 0xF0
00007d5be8fd24ea  pop r11
00007d5be8fd24ec  pop r10
00007d5be8fd24ee  pop r9
00007d5be8fd24f0  pop r8
00007d5be8fd24f2  pop rsi
00007d5be8fd24f3  pop rdi
00007d5be8fd24f4  pop rdx
00007d5be8fd24f5  pop rcx
00007d5be8fd24f6  pop rax
00007d5be8fd24f7  add rsp, 0x08
00007d5be8fd24fb  jmp 0x00007D5BE8FCFC76
00007d5be8fd2500  call 0x00007D5BE8DFF430
00007d5be8fd2505  jmp 0x00007D5BE8FCFC83
00007d5be8fd250a  sub rsp, 0x08
00007d5be8fd250e  push rax
00007d5be8fd250f  push rcx
00007d5be8fd2510  push rdx
00007d5be8fd2511  push rdi
00007d5be8fd2512  push rsi
00007d5be8fd2513  push r8
00007d5be8fd2515  push r9
00007d5be8fd2517  push r10
00007d5be8fd2519  push r11
00007d5be8fd251b  sub rsp, 0xF0
00007d5be8fd2522  vmovaps [rsp], xmm0
00007d5be8fd2527  vmovaps [rsp+0x10], xmm1
00007d5be8fd252d  vmovaps [rsp+0x20], xmm2
00007d5be8fd2533  vmovaps [rsp+0x30], xmm3
00007d5be8fd2539  vmovaps [rsp+0x40], xmm4
00007d5be8fd253f  vmovaps [rsp+0x50], xmm5
00007d5be8fd2545  vmovaps [rsp+0x60], xmm6
00007d5be8fd254b  vmovaps [rsp+0x70], xmm7
00007d5be8fd2551  vmovaps [rsp+0x80], xmm8
00007d5be8fd255a  vmovaps [rsp+0x90], xmm9
00007d5be8fd2563  vmovaps [rsp+0xA0], xmm10
00007d5be8fd256c  vmovaps [rsp+0xB0], xmm11
00007d5be8fd2575  vmovaps [rsp+0xC0], xmm12
00007d5be8fd257e  vmovaps [rsp+0xD0], xmm13
00007d5be8fd2587  vmovaps [rsp+0xE0], xmm14
00007d5be8fd2590  sub rsp, 0x30
00007d5be8fd2594  movaps [rsp], xmm15
00007d5be8fd2599  movaps [rsp+0x10], xmm11
00007d5be8fd259f  movaps [rsp+0x20], xmm1
00007d5be8fd25a4  lea rdi, [rsp]
00007d5be8fd25a8  mov esi, 0x00
00007d5be8fd25ad  mov rax, 0x5D345705A530
00007d5be8fd25b7  call rax
00007d5be8fd25b9  movaps xmm15, [rsp]
00007d5be8fd25be  add rsp, 0x30
00007d5be8fd25c2  vmovaps xmm0, [rsp]
00007d5be8fd25c7  vmovaps xmm1, [rsp+0x10]
00007d5be8fd25cd  vmovaps xmm2, [rsp+0x20]
00007d5be8fd25d3  vmovaps xmm3, [rsp+0x30]
00007d5be8fd25d9  vmovaps xmm4, [rsp+0x40]
00007d5be8fd25df  vmovaps xmm5, [rsp+0x50]
00007d5be8fd25e5  vmovaps xmm6, [rsp+0x60]
00007d5be8fd25eb  vmovaps xmm7, [rsp+0x70]
00007d5be8fd25f1  vmovaps xmm8, [rsp+0x80]
00007d5be8fd25fa  vmovaps xmm9, [rsp+0x90]
00007d5be8fd2603  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd260c  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd2615  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd261e  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd2627  vmovaps xmm14, [rsp+0xE0]
00007d5be8fd2630  add rsp, 0xF0
00007d5be8fd2637  pop r11
00007d5be8fd2639  pop r10
00007d5be8fd263b  pop r9
00007d5be8fd263d  pop r8
00007d5be8fd263f  pop rsi
00007d5be8fd2640  pop rdi
00007d5be8fd2641  pop rdx
00007d5be8fd2642  pop rcx
00007d5be8fd2643  pop rax
00007d5be8fd2644  add rsp, 0x08
00007d5be8fd2648  jmp 0x00007D5BE8FCFCBC
00007d5be8fd264d  sub rsp, 0x08
00007d5be8fd2651  push rax
00007d5be8fd2652  push rcx
00007d5be8fd2653  push rdx
00007d5be8fd2654  push rdi
00007d5be8fd2655  push rsi
00007d5be8fd2656  push r8
00007d5be8fd2658  push r9
00007d5be8fd265a  push r10
00007d5be8fd265c  push r11
00007d5be8fd265e  sub rsp, 0xF0
00007d5be8fd2665  vmovaps [rsp], xmm0
00007d5be8fd266a  vmovaps [rsp+0x10], xmm1
00007d5be8fd2670  vmovaps [rsp+0x20], xmm2
00007d5be8fd2676  vmovaps [rsp+0x30], xmm3
00007d5be8fd267c  vmovaps [rsp+0x40], xmm4
00007d5be8fd2682  vmovaps [rsp+0x50], xmm5
00007d5be8fd2688  vmovaps [rsp+0x60], xmm6
00007d5be8fd268e  vmovaps [rsp+0x70], xmm7
00007d5be8fd2694  vmovaps [rsp+0x80], xmm8
00007d5be8fd269d  vmovaps [rsp+0x90], xmm9
00007d5be8fd26a6  vmovaps [rsp+0xA0], xmm10
00007d5be8fd26af  vmovaps [rsp+0xB0], xmm12
00007d5be8fd26b8  vmovaps [rsp+0xC0], xmm13
00007d5be8fd26c1  vmovaps [rsp+0xD0], xmm14
00007d5be8fd26ca  vmovaps [rsp+0xE0], xmm15
00007d5be8fd26d3  sub rsp, 0x30
00007d5be8fd26d7  movaps [rsp], xmm11
00007d5be8fd26dc  movaps [rsp+0x10], xmm6
00007d5be8fd26e1  movaps [rsp+0x20], xmm14
00007d5be8fd26e7  lea rdi, [rsp]
00007d5be8fd26eb  mov esi, 0x00
00007d5be8fd26f0  mov rax, 0x5D345705A530
00007d5be8fd26fa  call rax
00007d5be8fd26fc  movaps xmm11, [rsp]
00007d5be8fd2701  add rsp, 0x30
00007d5be8fd2705  vmovaps xmm0, [rsp]
00007d5be8fd270a  vmovaps xmm1, [rsp+0x10]
00007d5be8fd2710  vmovaps xmm2, [rsp+0x20]
00007d5be8fd2716  vmovaps xmm3, [rsp+0x30]
00007d5be8fd271c  vmovaps xmm4, [rsp+0x40]
00007d5be8fd2722  vmovaps xmm5, [rsp+0x50]
00007d5be8fd2728  vmovaps xmm6, [rsp+0x60]
00007d5be8fd272e  vmovaps xmm7, [rsp+0x70]
00007d5be8fd2734  vmovaps xmm8, [rsp+0x80]
00007d5be8fd273d  vmovaps xmm9, [rsp+0x90]
00007d5be8fd2746  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd274f  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd2758  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd2761  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd276a  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd2773  add rsp, 0xF0
00007d5be8fd277a  pop r11
00007d5be8fd277c  pop r10
00007d5be8fd277e  pop r9
00007d5be8fd2780  pop r8
00007d5be8fd2782  pop rsi
00007d5be8fd2783  pop rdi
00007d5be8fd2784  pop rdx
00007d5be8fd2785  pop rcx
00007d5be8fd2786  pop rax
00007d5be8fd2787  add rsp, 0x08
00007d5be8fd278b  jmp 0x00007D5BE8FCFD34
00007d5be8fd2790  call 0x00007D5BE8DFF430
00007d5be8fd2795  jmp 0x00007D5BE8FCFD3E
00007d5be8fd279a  sub rsp, 0x08
00007d5be8fd279e  push rax
00007d5be8fd279f  push rcx
00007d5be8fd27a0  push rdx
00007d5be8fd27a1  push rdi
00007d5be8fd27a2  push rsi
00007d5be8fd27a3  push r8
00007d5be8fd27a5  push r9
00007d5be8fd27a7  push r10
00007d5be8fd27a9  push r11
00007d5be8fd27ab  sub rsp, 0xF0
00007d5be8fd27b2  vmovaps [rsp], xmm0
00007d5be8fd27b7  vmovaps [rsp+0x10], xmm1
00007d5be8fd27bd  vmovaps [rsp+0x20], xmm2
00007d5be8fd27c3  vmovaps [rsp+0x30], xmm3
00007d5be8fd27c9  vmovaps [rsp+0x40], xmm4
00007d5be8fd27cf  vmovaps [rsp+0x50], xmm5
00007d5be8fd27d5  vmovaps [rsp+0x60], xmm6
00007d5be8fd27db  vmovaps [rsp+0x70], xmm7
00007d5be8fd27e1  vmovaps [rsp+0x80], xmm8
00007d5be8fd27ea  vmovaps [rsp+0x90], xmm9
00007d5be8fd27f3  vmovaps [rsp+0xA0], xmm10
00007d5be8fd27fc  vmovaps [rsp+0xB0], xmm11
00007d5be8fd2805  vmovaps [rsp+0xC0], xmm12
00007d5be8fd280e  vmovaps [rsp+0xD0], xmm13
00007d5be8fd2817  vmovaps [rsp+0xE0], xmm15
00007d5be8fd2820  sub rsp, 0x30
00007d5be8fd2824  movaps [rsp], xmm14
00007d5be8fd2829  movaps [rsp+0x10], xmm6
00007d5be8fd282e  movaps [rsp+0x20], xmm2
00007d5be8fd2833  lea rdi, [rsp]
00007d5be8fd2837  mov esi, 0x00
00007d5be8fd283c  mov rax, 0x5D345705A530
00007d5be8fd2846  call rax
00007d5be8fd2848  movaps xmm14, [rsp]
00007d5be8fd284d  add rsp, 0x30
00007d5be8fd2851  vmovaps xmm0, [rsp]
00007d5be8fd2856  vmovaps xmm1, [rsp+0x10]
00007d5be8fd285c  vmovaps xmm2, [rsp+0x20]
00007d5be8fd2862  vmovaps xmm3, [rsp+0x30]
00007d5be8fd2868  vmovaps xmm4, [rsp+0x40]
00007d5be8fd286e  vmovaps xmm5, [rsp+0x50]
00007d5be8fd2874  vmovaps xmm6, [rsp+0x60]
00007d5be8fd287a  vmovaps xmm7, [rsp+0x70]
00007d5be8fd2880  vmovaps xmm8, [rsp+0x80]
00007d5be8fd2889  vmovaps xmm9, [rsp+0x90]
00007d5be8fd2892  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd289b  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd28a4  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd28ad  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd28b6  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd28bf  add rsp, 0xF0
00007d5be8fd28c6  pop r11
00007d5be8fd28c8  pop r10
00007d5be8fd28ca  pop r9
00007d5be8fd28cc  pop r8
00007d5be8fd28ce  pop rsi
00007d5be8fd28cf  pop rdi
00007d5be8fd28d0  pop rdx
00007d5be8fd28d1  pop rcx
00007d5be8fd28d2  pop rax
00007d5be8fd28d3  add rsp, 0x08
00007d5be8fd28d7  jmp 0x00007D5BE8FCFD72
00007d5be8fd28dc  sub rsp, 0x08
00007d5be8fd28e0  push rax
00007d5be8fd28e1  push rcx
00007d5be8fd28e2  push rdx
00007d5be8fd28e3  push rdi
00007d5be8fd28e4  push rsi
00007d5be8fd28e5  push r8
00007d5be8fd28e7  push r9
00007d5be8fd28e9  push r10
00007d5be8fd28eb  push r11
00007d5be8fd28ed  sub rsp, 0xF0
00007d5be8fd28f4  vmovaps [rsp], xmm0
00007d5be8fd28f9  vmovaps [rsp+0x10], xmm1
00007d5be8fd28ff  vmovaps [rsp+0x20], xmm2
00007d5be8fd2905  vmovaps [rsp+0x30], xmm3
00007d5be8fd290b  vmovaps [rsp+0x40], xmm4
00007d5be8fd2911  vmovaps [rsp+0x50], xmm5
00007d5be8fd2917  vmovaps [rsp+0x60], xmm7
00007d5be8fd291d  vmovaps [rsp+0x70], xmm8
00007d5be8fd2923  vmovaps [rsp+0x80], xmm9
00007d5be8fd292c  vmovaps [rsp+0x90], xmm10
00007d5be8fd2935  vmovaps [rsp+0xA0], xmm11
00007d5be8fd293e  vmovaps [rsp+0xB0], xmm12
00007d5be8fd2947  vmovaps [rsp+0xC0], xmm13
00007d5be8fd2950  vmovaps [rsp+0xD0], xmm14
00007d5be8fd2959  vmovaps [rsp+0xE0], xmm15
00007d5be8fd2962  sub rsp, 0x30
00007d5be8fd2966  movaps [rsp], xmm6
00007d5be8fd296a  movaps [rsp+0x10], xmm5
00007d5be8fd296f  movaps [rsp+0x20], xmm1
00007d5be8fd2974  lea rdi, [rsp]
00007d5be8fd2978  mov esi, 0x00
00007d5be8fd297d  mov rax, 0x5D345705A530
00007d5be8fd2987  call rax
00007d5be8fd2989  movaps xmm6, [rsp]
00007d5be8fd298d  add rsp, 0x30
00007d5be8fd2991  vmovaps xmm0, [rsp]
00007d5be8fd2996  vmovaps xmm1, [rsp+0x10]
00007d5be8fd299c  vmovaps xmm2, [rsp+0x20]
00007d5be8fd29a2  vmovaps xmm3, [rsp+0x30]
00007d5be8fd29a8  vmovaps xmm4, [rsp+0x40]
00007d5be8fd29ae  vmovaps xmm5, [rsp+0x50]
00007d5be8fd29b4  vmovaps xmm7, [rsp+0x60]
00007d5be8fd29ba  vmovaps xmm8, [rsp+0x70]
00007d5be8fd29c0  vmovaps xmm9, [rsp+0x80]
00007d5be8fd29c9  vmovaps xmm10, [rsp+0x90]
00007d5be8fd29d2  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd29db  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd29e4  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd29ed  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd29f6  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd29ff  add rsp, 0xF0
00007d5be8fd2a06  pop r11
00007d5be8fd2a08  pop r10
00007d5be8fd2a0a  pop r9
00007d5be8fd2a0c  pop r8
00007d5be8fd2a0e  pop rsi
00007d5be8fd2a0f  pop rdi
00007d5be8fd2a10  pop rdx
00007d5be8fd2a11  pop rcx
00007d5be8fd2a12  pop rax
00007d5be8fd2a13  add rsp, 0x08
00007d5be8fd2a17  jmp 0x00007D5BE8FCFD98
00007d5be8fd2a1c  sub rsp, 0x08
00007d5be8fd2a20  push rax
00007d5be8fd2a21  push rcx
00007d5be8fd2a22  push rdx
00007d5be8fd2a23  push rdi
00007d5be8fd2a24  push rsi
00007d5be8fd2a25  push r8
00007d5be8fd2a27  push r9
00007d5be8fd2a29  push r10
00007d5be8fd2a2b  push r11
00007d5be8fd2a2d  sub rsp, 0xF0
00007d5be8fd2a34  vmovaps [rsp], xmm0
00007d5be8fd2a39  vmovaps [rsp+0x10], xmm2
00007d5be8fd2a3f  vmovaps [rsp+0x20], xmm3
00007d5be8fd2a45  vmovaps [rsp+0x30], xmm4
00007d5be8fd2a4b  vmovaps [rsp+0x40], xmm5
00007d5be8fd2a51  vmovaps [rsp+0x50], xmm6
00007d5be8fd2a57  vmovaps [rsp+0x60], xmm7
00007d5be8fd2a5d  vmovaps [rsp+0x70], xmm8
00007d5be8fd2a63  vmovaps [rsp+0x80], xmm9
00007d5be8fd2a6c  vmovaps [rsp+0x90], xmm10
00007d5be8fd2a75  vmovaps [rsp+0xA0], xmm11
00007d5be8fd2a7e  vmovaps [rsp+0xB0], xmm12
00007d5be8fd2a87  vmovaps [rsp+0xC0], xmm13
00007d5be8fd2a90  vmovaps [rsp+0xD0], xmm14
00007d5be8fd2a99  vmovaps [rsp+0xE0], xmm15
00007d5be8fd2aa2  sub rsp, 0x30
00007d5be8fd2aa6  movaps [rsp], xmm1
00007d5be8fd2aaa  movaps [rsp+0x10], xmm5
00007d5be8fd2aaf  movaps [rsp+0x20], xmm13
00007d5be8fd2ab5  lea rdi, [rsp]
00007d5be8fd2ab9  mov esi, 0x00
00007d5be8fd2abe  mov rax, 0x5D345705A530
00007d5be8fd2ac8  call rax
00007d5be8fd2aca  movaps xmm1, [rsp]
00007d5be8fd2ace  add rsp, 0x30
00007d5be8fd2ad2  vmovaps xmm0, [rsp]
00007d5be8fd2ad7  vmovaps xmm2, [rsp+0x10]
00007d5be8fd2add  vmovaps xmm3, [rsp+0x20]
00007d5be8fd2ae3  vmovaps xmm4, [rsp+0x30]
00007d5be8fd2ae9  vmovaps xmm5, [rsp+0x40]
00007d5be8fd2aef  vmovaps xmm6, [rsp+0x50]
00007d5be8fd2af5  vmovaps xmm7, [rsp+0x60]
00007d5be8fd2afb  vmovaps xmm8, [rsp+0x70]
00007d5be8fd2b01  vmovaps xmm9, [rsp+0x80]
00007d5be8fd2b0a  vmovaps xmm10, [rsp+0x90]
00007d5be8fd2b13  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd2b1c  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd2b25  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd2b2e  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd2b37  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd2b40  add rsp, 0xF0
00007d5be8fd2b47  pop r11
00007d5be8fd2b49  pop r10
00007d5be8fd2b4b  pop r9
00007d5be8fd2b4d  pop r8
00007d5be8fd2b4f  pop rsi
00007d5be8fd2b50  pop rdi
00007d5be8fd2b51  pop rdx
00007d5be8fd2b52  pop rcx
00007d5be8fd2b53  pop rax
00007d5be8fd2b54  add rsp, 0x08
00007d5be8fd2b58  jmp 0x00007D5BE8FCFDB6
00007d5be8fd2b5d  sub rsp, 0x08
00007d5be8fd2b61  push rax
00007d5be8fd2b62  push rcx
00007d5be8fd2b63  push rdx
00007d5be8fd2b64  push rdi
00007d5be8fd2b65  push rsi
00007d5be8fd2b66  push r8
00007d5be8fd2b68  push r9
00007d5be8fd2b6a  push r10
00007d5be8fd2b6c  push r11
00007d5be8fd2b6e  sub rsp, 0xF0
00007d5be8fd2b75  vmovaps [rsp], xmm0
00007d5be8fd2b7a  vmovaps [rsp+0x10], xmm1
00007d5be8fd2b80  vmovaps [rsp+0x20], xmm2
00007d5be8fd2b86  vmovaps [rsp+0x30], xmm3
00007d5be8fd2b8c  vmovaps [rsp+0x40], xmm4
00007d5be8fd2b92  vmovaps [rsp+0x50], xmm6
00007d5be8fd2b98  vmovaps [rsp+0x60], xmm7
00007d5be8fd2b9e  vmovaps [rsp+0x70], xmm8
00007d5be8fd2ba4  vmovaps [rsp+0x80], xmm9
00007d5be8fd2bad  vmovaps [rsp+0x90], xmm10
00007d5be8fd2bb6  vmovaps [rsp+0xA0], xmm11
00007d5be8fd2bbf  vmovaps [rsp+0xB0], xmm12
00007d5be8fd2bc8  vmovaps [rsp+0xC0], xmm13
00007d5be8fd2bd1  vmovaps [rsp+0xD0], xmm14
00007d5be8fd2bda  vmovaps [rsp+0xE0], xmm15
00007d5be8fd2be3  sub rsp, 0x30
00007d5be8fd2be7  movaps [rsp], xmm5
00007d5be8fd2beb  movaps [rsp+0x10], xmm2
00007d5be8fd2bf0  movaps [rsp+0x20], xmm13
00007d5be8fd2bf6  lea rdi, [rsp]
00007d5be8fd2bfa  mov esi, 0x00
00007d5be8fd2bff  mov rax, 0x5D345705A530
00007d5be8fd2c09  call rax
00007d5be8fd2c0b  movaps xmm5, [rsp]
00007d5be8fd2c0f  add rsp, 0x30
00007d5be8fd2c13  vmovaps xmm0, [rsp]
00007d5be8fd2c18  vmovaps xmm1, [rsp+0x10]
00007d5be8fd2c1e  vmovaps xmm2, [rsp+0x20]
00007d5be8fd2c24  vmovaps xmm3, [rsp+0x30]
00007d5be8fd2c2a  vmovaps xmm4, [rsp+0x40]
00007d5be8fd2c30  vmovaps xmm6, [rsp+0x50]
00007d5be8fd2c36  vmovaps xmm7, [rsp+0x60]
00007d5be8fd2c3c  vmovaps xmm8, [rsp+0x70]
00007d5be8fd2c42  vmovaps xmm9, [rsp+0x80]
00007d5be8fd2c4b  vmovaps xmm10, [rsp+0x90]
00007d5be8fd2c54  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd2c5d  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd2c66  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd2c6f  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd2c78  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd2c81  add rsp, 0xF0
00007d5be8fd2c88  pop r11
00007d5be8fd2c8a  pop r10
00007d5be8fd2c8c  pop r9
00007d5be8fd2c8e  pop r8
00007d5be8fd2c90  pop rsi
00007d5be8fd2c91  pop rdi
00007d5be8fd2c92  pop rdx
00007d5be8fd2c93  pop rcx
00007d5be8fd2c94  pop rax
00007d5be8fd2c95  add rsp, 0x08
00007d5be8fd2c99  jmp 0x00007D5BE8FCFDEC
00007d5be8fd2c9e  sub rsp, 0x08
00007d5be8fd2ca2  push rax
00007d5be8fd2ca3  push rcx
00007d5be8fd2ca4  push rdx
00007d5be8fd2ca5  push rdi
00007d5be8fd2ca6  push rsi
00007d5be8fd2ca7  push r8
00007d5be8fd2ca9  push r9
00007d5be8fd2cab  push r10
00007d5be8fd2cad  push r11
00007d5be8fd2caf  sub rsp, 0xF0
00007d5be8fd2cb6  vmovaps [rsp], xmm0
00007d5be8fd2cbb  vmovaps [rsp+0x10], xmm1
00007d5be8fd2cc1  vmovaps [rsp+0x20], xmm2
00007d5be8fd2cc7  vmovaps [rsp+0x30], xmm3
00007d5be8fd2ccd  vmovaps [rsp+0x40], xmm4
00007d5be8fd2cd3  vmovaps [rsp+0x50], xmm5
00007d5be8fd2cd9  vmovaps [rsp+0x60], xmm6
00007d5be8fd2cdf  vmovaps [rsp+0x70], xmm7
00007d5be8fd2ce5  vmovaps [rsp+0x80], xmm8
00007d5be8fd2cee  vmovaps [rsp+0x90], xmm9
00007d5be8fd2cf7  vmovaps [rsp+0xA0], xmm10
00007d5be8fd2d00  vmovaps [rsp+0xB0], xmm11
00007d5be8fd2d09  vmovaps [rsp+0xC0], xmm12
00007d5be8fd2d12  vmovaps [rsp+0xD0], xmm14
00007d5be8fd2d1b  vmovaps [rsp+0xE0], xmm15
00007d5be8fd2d24  sub rsp, 0x30
00007d5be8fd2d28  movaps [rsp], xmm13
00007d5be8fd2d2d  movaps [rsp+0x10], xmm10
00007d5be8fd2d33  movaps [rsp+0x20], xmm1
00007d5be8fd2d38  lea rdi, [rsp]
00007d5be8fd2d3c  mov esi, 0x00
00007d5be8fd2d41  mov rax, 0x5D345705A530
00007d5be8fd2d4b  call rax
00007d5be8fd2d4d  movaps xmm13, [rsp]
00007d5be8fd2d52  add rsp, 0x30
00007d5be8fd2d56  vmovaps xmm0, [rsp]
00007d5be8fd2d5b  vmovaps xmm1, [rsp+0x10]
00007d5be8fd2d61  vmovaps xmm2, [rsp+0x20]
00007d5be8fd2d67  vmovaps xmm3, [rsp+0x30]
00007d5be8fd2d6d  vmovaps xmm4, [rsp+0x40]
00007d5be8fd2d73  vmovaps xmm5, [rsp+0x50]
00007d5be8fd2d79  vmovaps xmm6, [rsp+0x60]
00007d5be8fd2d7f  vmovaps xmm7, [rsp+0x70]
00007d5be8fd2d85  vmovaps xmm8, [rsp+0x80]
00007d5be8fd2d8e  vmovaps xmm9, [rsp+0x90]
00007d5be8fd2d97  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd2da0  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd2da9  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd2db2  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd2dbb  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd2dc4  add rsp, 0xF0
00007d5be8fd2dcb  pop r11
00007d5be8fd2dcd  pop r10
00007d5be8fd2dcf  pop r9
00007d5be8fd2dd1  pop r8
00007d5be8fd2dd3  pop rsi
00007d5be8fd2dd4  pop rdi
00007d5be8fd2dd5  pop rdx
00007d5be8fd2dd6  pop rcx
00007d5be8fd2dd7  pop rax
00007d5be8fd2dd8  add rsp, 0x08
00007d5be8fd2ddc  jmp 0x00007D5BE8FCFE15
00007d5be8fd2de1  sub rsp, 0x08
00007d5be8fd2de5  push rax
00007d5be8fd2de6  push rcx
00007d5be8fd2de7  push rdx
00007d5be8fd2de8  push rdi
00007d5be8fd2de9  push rsi
00007d5be8fd2dea  push r8
00007d5be8fd2dec  push r9
00007d5be8fd2dee  push r10
00007d5be8fd2df0  push r11
00007d5be8fd2df2  sub rsp, 0xF0
00007d5be8fd2df9  vmovaps [rsp], xmm0
00007d5be8fd2dfe  vmovaps [rsp+0x10], xmm2
00007d5be8fd2e04  vmovaps [rsp+0x20], xmm3
00007d5be8fd2e0a  vmovaps [rsp+0x30], xmm4
00007d5be8fd2e10  vmovaps [rsp+0x40], xmm5
00007d5be8fd2e16  vmovaps [rsp+0x50], xmm6
00007d5be8fd2e1c  vmovaps [rsp+0x60], xmm7
00007d5be8fd2e22  vmovaps [rsp+0x70], xmm8
00007d5be8fd2e28  vmovaps [rsp+0x80], xmm9
00007d5be8fd2e31  vmovaps [rsp+0x90], xmm10
00007d5be8fd2e3a  vmovaps [rsp+0xA0], xmm11
00007d5be8fd2e43  vmovaps [rsp+0xB0], xmm12
00007d5be8fd2e4c  vmovaps [rsp+0xC0], xmm13
00007d5be8fd2e55  vmovaps [rsp+0xD0], xmm14
00007d5be8fd2e5e  vmovaps [rsp+0xE0], xmm15
00007d5be8fd2e67  sub rsp, 0x30
00007d5be8fd2e6b  movaps [rsp], xmm1
00007d5be8fd2e6f  movaps [rsp+0x10], xmm15
00007d5be8fd2e75  movaps [rsp+0x20], xmm10
00007d5be8fd2e7b  lea rdi, [rsp]
00007d5be8fd2e7f  mov esi, 0x00
00007d5be8fd2e84  mov rax, 0x5D345705A530
00007d5be8fd2e8e  call rax
00007d5be8fd2e90  movaps xmm1, [rsp]
00007d5be8fd2e94  add rsp, 0x30
00007d5be8fd2e98  vmovaps xmm0, [rsp]
00007d5be8fd2e9d  vmovaps xmm2, [rsp+0x10]
00007d5be8fd2ea3  vmovaps xmm3, [rsp+0x20]
00007d5be8fd2ea9  vmovaps xmm4, [rsp+0x30]
00007d5be8fd2eaf  vmovaps xmm5, [rsp+0x40]
00007d5be8fd2eb5  vmovaps xmm6, [rsp+0x50]
00007d5be8fd2ebb  vmovaps xmm7, [rsp+0x60]
00007d5be8fd2ec1  vmovaps xmm8, [rsp+0x70]
00007d5be8fd2ec7  vmovaps xmm9, [rsp+0x80]
00007d5be8fd2ed0  vmovaps xmm10, [rsp+0x90]
00007d5be8fd2ed9  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd2ee2  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd2eeb  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd2ef4  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd2efd  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd2f06  add rsp, 0xF0
00007d5be8fd2f0d  pop r11
00007d5be8fd2f0f  pop r10
00007d5be8fd2f11  pop r9
00007d5be8fd2f13  pop r8
00007d5be8fd2f15  pop rsi
00007d5be8fd2f16  pop rdi
00007d5be8fd2f17  pop rdx
00007d5be8fd2f18  pop rcx
00007d5be8fd2f19  pop rax
00007d5be8fd2f1a  add rsp, 0x08
00007d5be8fd2f1e  jmp 0x00007D5BE8FCFE34
00007d5be8fd2f23  sub rsp, 0x08
00007d5be8fd2f27  push rax
00007d5be8fd2f28  push rcx
00007d5be8fd2f29  push rdx
00007d5be8fd2f2a  push rdi
00007d5be8fd2f2b  push rsi
00007d5be8fd2f2c  push r8
00007d5be8fd2f2e  push r9
00007d5be8fd2f30  push r10
00007d5be8fd2f32  push r11
00007d5be8fd2f34  sub rsp, 0xF0
00007d5be8fd2f3b  vmovaps [rsp], xmm0
00007d5be8fd2f40  vmovaps [rsp+0x10], xmm1
00007d5be8fd2f46  vmovaps [rsp+0x20], xmm2
00007d5be8fd2f4c  vmovaps [rsp+0x30], xmm3
00007d5be8fd2f52  vmovaps [rsp+0x40], xmm4
00007d5be8fd2f58  vmovaps [rsp+0x50], xmm5
00007d5be8fd2f5e  vmovaps [rsp+0x60], xmm6
00007d5be8fd2f64  vmovaps [rsp+0x70], xmm7
00007d5be8fd2f6a  vmovaps [rsp+0x80], xmm8
00007d5be8fd2f73  vmovaps [rsp+0x90], xmm9
00007d5be8fd2f7c  vmovaps [rsp+0xA0], xmm10
00007d5be8fd2f85  vmovaps [rsp+0xB0], xmm11
00007d5be8fd2f8e  vmovaps [rsp+0xC0], xmm12
00007d5be8fd2f97  vmovaps [rsp+0xD0], xmm13
00007d5be8fd2fa0  vmovaps [rsp+0xE0], xmm14
00007d5be8fd2fa9  sub rsp, 0x30
00007d5be8fd2fad  movaps [rsp], xmm15
00007d5be8fd2fb2  movaps [rsp+0x10], xmm10
00007d5be8fd2fb8  movaps [rsp+0x20], xmm11
00007d5be8fd2fbe  lea rdi, [rsp]
00007d5be8fd2fc2  mov esi, 0x00
00007d5be8fd2fc7  mov rax, 0x5D345705A530
00007d5be8fd2fd1  call rax
00007d5be8fd2fd3  movaps xmm15, [rsp]
00007d5be8fd2fd8  add rsp, 0x30
00007d5be8fd2fdc  vmovaps xmm0, [rsp]
00007d5be8fd2fe1  vmovaps xmm1, [rsp+0x10]
00007d5be8fd2fe7  vmovaps xmm2, [rsp+0x20]
00007d5be8fd2fed  vmovaps xmm3, [rsp+0x30]
00007d5be8fd2ff3  vmovaps xmm4, [rsp+0x40]
00007d5be8fd2ff9  vmovaps xmm5, [rsp+0x50]
00007d5be8fd2fff  vmovaps xmm6, [rsp+0x60]
00007d5be8fd3005  vmovaps xmm7, [rsp+0x70]
00007d5be8fd300b  vmovaps xmm8, [rsp+0x80]
00007d5be8fd3014  vmovaps xmm9, [rsp+0x90]
00007d5be8fd301d  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd3026  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd302f  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd3038  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd3041  vmovaps xmm14, [rsp+0xE0]
00007d5be8fd304a  add rsp, 0xF0
00007d5be8fd3051  pop r11
00007d5be8fd3053  pop r10
00007d5be8fd3055  pop r9
00007d5be8fd3057  pop r8
00007d5be8fd3059  pop rsi
00007d5be8fd305a  pop rdi
00007d5be8fd305b  pop rdx
00007d5be8fd305c  pop rcx
00007d5be8fd305d  pop rax
00007d5be8fd305e  add rsp, 0x08
00007d5be8fd3062  jmp 0x00007D5BE8FCFE57
00007d5be8fd3067  sub rsp, 0x08
00007d5be8fd306b  push rax
00007d5be8fd306c  push rcx
00007d5be8fd306d  push rdx
00007d5be8fd306e  push rdi
00007d5be8fd306f  push rsi
00007d5be8fd3070  push r8
00007d5be8fd3072  push r9
00007d5be8fd3074  push r10
00007d5be8fd3076  push r11
00007d5be8fd3078  sub rsp, 0xF0
00007d5be8fd307f  vmovaps [rsp], xmm0
00007d5be8fd3084  vmovaps [rsp+0x10], xmm1
00007d5be8fd308a  vmovaps [rsp+0x20], xmm2
00007d5be8fd3090  vmovaps [rsp+0x30], xmm3
00007d5be8fd3096  vmovaps [rsp+0x40], xmm4
00007d5be8fd309c  vmovaps [rsp+0x50], xmm5
00007d5be8fd30a2  vmovaps [rsp+0x60], xmm6
00007d5be8fd30a8  vmovaps [rsp+0x70], xmm7
00007d5be8fd30ae  vmovaps [rsp+0x80], xmm8
00007d5be8fd30b7  vmovaps [rsp+0x90], xmm9
00007d5be8fd30c0  vmovaps [rsp+0xA0], xmm11
00007d5be8fd30c9  vmovaps [rsp+0xB0], xmm12
00007d5be8fd30d2  vmovaps [rsp+0xC0], xmm13
00007d5be8fd30db  vmovaps [rsp+0xD0], xmm14
00007d5be8fd30e4  vmovaps [rsp+0xE0], xmm15
00007d5be8fd30ed  sub rsp, 0x30
00007d5be8fd30f1  movaps [rsp], xmm10
00007d5be8fd30f6  movaps [rsp+0x10], xmm12
00007d5be8fd30fc  movaps [rsp+0x20], xmm11
00007d5be8fd3102  lea rdi, [rsp]
00007d5be8fd3106  mov esi, 0x00
00007d5be8fd310b  mov rax, 0x5D345705A530
00007d5be8fd3115  call rax
00007d5be8fd3117  movaps xmm10, [rsp]
00007d5be8fd311c  add rsp, 0x30
00007d5be8fd3120  vmovaps xmm0, [rsp]
00007d5be8fd3125  vmovaps xmm1, [rsp+0x10]
00007d5be8fd312b  vmovaps xmm2, [rsp+0x20]
00007d5be8fd3131  vmovaps xmm3, [rsp+0x30]
00007d5be8fd3137  vmovaps xmm4, [rsp+0x40]
00007d5be8fd313d  vmovaps xmm5, [rsp+0x50]
00007d5be8fd3143  vmovaps xmm6, [rsp+0x60]
00007d5be8fd3149  vmovaps xmm7, [rsp+0x70]
00007d5be8fd314f  vmovaps xmm8, [rsp+0x80]
00007d5be8fd3158  vmovaps xmm9, [rsp+0x90]
00007d5be8fd3161  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd316a  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd3173  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd317c  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd3185  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd318e  add rsp, 0xF0
00007d5be8fd3195  pop r11
00007d5be8fd3197  pop r10
00007d5be8fd3199  pop r9
00007d5be8fd319b  pop r8
00007d5be8fd319d  pop rsi
00007d5be8fd319e  pop rdi
00007d5be8fd319f  pop rdx
00007d5be8fd31a0  pop rcx
00007d5be8fd31a1  pop rax
00007d5be8fd31a2  add rsp, 0x08
00007d5be8fd31a6  jmp 0x00007D5BE8FCFE80
00007d5be8fd31ab  sub rsp, 0x08
00007d5be8fd31af  push rax
00007d5be8fd31b0  push rcx
00007d5be8fd31b1  push rdx
00007d5be8fd31b2  push rdi
00007d5be8fd31b3  push rsi
00007d5be8fd31b4  push r8
00007d5be8fd31b6  push r9
00007d5be8fd31b8  push r10
00007d5be8fd31ba  push r11
00007d5be8fd31bc  sub rsp, 0xF0
00007d5be8fd31c3  vmovaps [rsp], xmm0
00007d5be8fd31c8  vmovaps [rsp+0x10], xmm1
00007d5be8fd31ce  vmovaps [rsp+0x20], xmm2
00007d5be8fd31d4  vmovaps [rsp+0x30], xmm3
00007d5be8fd31da  vmovaps [rsp+0x40], xmm4
00007d5be8fd31e0  vmovaps [rsp+0x50], xmm5
00007d5be8fd31e6  vmovaps [rsp+0x60], xmm6
00007d5be8fd31ec  vmovaps [rsp+0x70], xmm7
00007d5be8fd31f2  vmovaps [rsp+0x80], xmm8
00007d5be8fd31fb  vmovaps [rsp+0x90], xmm9
00007d5be8fd3204  vmovaps [rsp+0xA0], xmm10
00007d5be8fd320d  vmovaps [rsp+0xB0], xmm12
00007d5be8fd3216  vmovaps [rsp+0xC0], xmm13
00007d5be8fd321f  vmovaps [rsp+0xD0], xmm14
00007d5be8fd3228  vmovaps [rsp+0xE0], xmm15
00007d5be8fd3231  sub rsp, 0x30
00007d5be8fd3235  movaps [rsp], xmm11
00007d5be8fd323a  movaps [rsp+0x10], xmm2
00007d5be8fd323f  movaps [rsp+0x20], xmm12
00007d5be8fd3245  lea rdi, [rsp]
00007d5be8fd3249  mov esi, 0x00
00007d5be8fd324e  mov rax, 0x5D345705A530
00007d5be8fd3258  call rax
00007d5be8fd325a  movaps xmm11, [rsp]
00007d5be8fd325f  add rsp, 0x30
00007d5be8fd3263  vmovaps xmm0, [rsp]
00007d5be8fd3268  vmovaps xmm1, [rsp+0x10]
00007d5be8fd326e  vmovaps xmm2, [rsp+0x20]
00007d5be8fd3274  vmovaps xmm3, [rsp+0x30]
00007d5be8fd327a  vmovaps xmm4, [rsp+0x40]
00007d5be8fd3280  vmovaps xmm5, [rsp+0x50]
00007d5be8fd3286  vmovaps xmm6, [rsp+0x60]
00007d5be8fd328c  vmovaps xmm7, [rsp+0x70]
00007d5be8fd3292  vmovaps xmm8, [rsp+0x80]
00007d5be8fd329b  vmovaps xmm9, [rsp+0x90]
00007d5be8fd32a4  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd32ad  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd32b6  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd32bf  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd32c8  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd32d1  add rsp, 0xF0
00007d5be8fd32d8  pop r11
00007d5be8fd32da  pop r10
00007d5be8fd32dc  pop r9
00007d5be8fd32de  pop r8
00007d5be8fd32e0  pop rsi
00007d5be8fd32e1  pop rdi
00007d5be8fd32e2  pop rdx
00007d5be8fd32e3  pop rcx
00007d5be8fd32e4  pop rax
00007d5be8fd32e5  add rsp, 0x08
00007d5be8fd32e9  jmp 0x00007D5BE8FCFEB8
00007d5be8fd32ee  sub rsp, 0x08
00007d5be8fd32f2  push rax
00007d5be8fd32f3  push rcx
00007d5be8fd32f4  push rdx
00007d5be8fd32f5  push rdi
00007d5be8fd32f6  push rsi
00007d5be8fd32f7  push r8
00007d5be8fd32f9  push r9
00007d5be8fd32fb  push r10
00007d5be8fd32fd  push r11
00007d5be8fd32ff  sub rsp, 0xF0
00007d5be8fd3306  vmovaps [rsp], xmm0
00007d5be8fd330b  vmovaps [rsp+0x10], xmm2
00007d5be8fd3311  vmovaps [rsp+0x20], xmm3
00007d5be8fd3317  vmovaps [rsp+0x30], xmm4
00007d5be8fd331d  vmovaps [rsp+0x40], xmm5
00007d5be8fd3323  vmovaps [rsp+0x50], xmm6
00007d5be8fd3329  vmovaps [rsp+0x60], xmm7
00007d5be8fd332f  vmovaps [rsp+0x70], xmm8
00007d5be8fd3335  vmovaps [rsp+0x80], xmm9
00007d5be8fd333e  vmovaps [rsp+0x90], xmm10
00007d5be8fd3347  vmovaps [rsp+0xA0], xmm11
00007d5be8fd3350  vmovaps [rsp+0xB0], xmm12
00007d5be8fd3359  vmovaps [rsp+0xC0], xmm13
00007d5be8fd3362  vmovaps [rsp+0xD0], xmm14
00007d5be8fd336b  vmovaps [rsp+0xE0], xmm15
00007d5be8fd3374  sub rsp, 0x30
00007d5be8fd3378  movaps [rsp], xmm1
00007d5be8fd337c  movaps [rsp+0x10], xmm14
00007d5be8fd3382  movaps [rsp+0x20], xmm6
00007d5be8fd3387  lea rdi, [rsp]
00007d5be8fd338b  mov esi, 0x00
00007d5be8fd3390  mov rax, 0x5D345705A530
00007d5be8fd339a  call rax
00007d5be8fd339c  movaps xmm1, [rsp]
00007d5be8fd33a0  add rsp, 0x30
00007d5be8fd33a4  vmovaps xmm0, [rsp]
00007d5be8fd33a9  vmovaps xmm2, [rsp+0x10]
00007d5be8fd33af  vmovaps xmm3, [rsp+0x20]
00007d5be8fd33b5  vmovaps xmm4, [rsp+0x30]
00007d5be8fd33bb  vmovaps xmm5, [rsp+0x40]
00007d5be8fd33c1  vmovaps xmm6, [rsp+0x50]
00007d5be8fd33c7  vmovaps xmm7, [rsp+0x60]
00007d5be8fd33cd  vmovaps xmm8, [rsp+0x70]
00007d5be8fd33d3  vmovaps xmm9, [rsp+0x80]
00007d5be8fd33dc  vmovaps xmm10, [rsp+0x90]
00007d5be8fd33e5  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd33ee  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd33f7  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd3400  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd3409  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd3412  add rsp, 0xF0
00007d5be8fd3419  pop r11
00007d5be8fd341b  pop r10
00007d5be8fd341d  pop r9
00007d5be8fd341f  pop r8
00007d5be8fd3421  pop rsi
00007d5be8fd3422  pop rdi
00007d5be8fd3423  pop rdx
00007d5be8fd3424  pop rcx
00007d5be8fd3425  pop rax
00007d5be8fd3426  add rsp, 0x08
00007d5be8fd342a  jmp 0x00007D5BE8FCFED1
00007d5be8fd342f  sub rsp, 0x08
00007d5be8fd3433  push rax
00007d5be8fd3434  push rcx
00007d5be8fd3435  push rdx
00007d5be8fd3436  push rdi
00007d5be8fd3437  push rsi
00007d5be8fd3438  push r8
00007d5be8fd343a  push r9
00007d5be8fd343c  push r10
00007d5be8fd343e  push r11
00007d5be8fd3440  sub rsp, 0xF0
00007d5be8fd3447  vmovaps [rsp], xmm0
00007d5be8fd344c  vmovaps [rsp+0x10], xmm1
00007d5be8fd3452  vmovaps [rsp+0x20], xmm2
00007d5be8fd3458  vmovaps [rsp+0x30], xmm3
00007d5be8fd345e  vmovaps [rsp+0x40], xmm4
00007d5be8fd3464  vmovaps [rsp+0x50], xmm5
00007d5be8fd346a  vmovaps [rsp+0x60], xmm6
00007d5be8fd3470  vmovaps [rsp+0x70], xmm7
00007d5be8fd3476  vmovaps [rsp+0x80], xmm8
00007d5be8fd347f  vmovaps [rsp+0x90], xmm9
00007d5be8fd3488  vmovaps [rsp+0xA0], xmm10
00007d5be8fd3491  vmovaps [rsp+0xB0], xmm11
00007d5be8fd349a  vmovaps [rsp+0xC0], xmm12
00007d5be8fd34a3  vmovaps [rsp+0xD0], xmm13
00007d5be8fd34ac  vmovaps [rsp+0xE0], xmm15
00007d5be8fd34b5  sub rsp, 0x30
00007d5be8fd34b9  movaps [rsp], xmm14
00007d5be8fd34be  movaps [rsp+0x10], xmm12
00007d5be8fd34c4  movaps [rsp+0x20], xmm5
00007d5be8fd34c9  lea rdi, [rsp]
00007d5be8fd34cd  mov esi, 0x00
00007d5be8fd34d2  mov rax, 0x5D345705A530
00007d5be8fd34dc  call rax
00007d5be8fd34de  movaps xmm14, [rsp]
00007d5be8fd34e3  add rsp, 0x30
00007d5be8fd34e7  vmovaps xmm0, [rsp]
00007d5be8fd34ec  vmovaps xmm1, [rsp+0x10]
00007d5be8fd34f2  vmovaps xmm2, [rsp+0x20]
00007d5be8fd34f8  vmovaps xmm3, [rsp+0x30]
00007d5be8fd34fe  vmovaps xmm4, [rsp+0x40]
00007d5be8fd3504  vmovaps xmm5, [rsp+0x50]
00007d5be8fd350a  vmovaps xmm6, [rsp+0x60]
00007d5be8fd3510  vmovaps xmm7, [rsp+0x70]
00007d5be8fd3516  vmovaps xmm8, [rsp+0x80]
00007d5be8fd351f  vmovaps xmm9, [rsp+0x90]
00007d5be8fd3528  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd3531  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd353a  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd3543  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd354c  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd3555  add rsp, 0xF0
00007d5be8fd355c  pop r11
00007d5be8fd355e  pop r10
00007d5be8fd3560  pop r9
00007d5be8fd3562  pop r8
00007d5be8fd3564  pop rsi
00007d5be8fd3565  pop rdi
00007d5be8fd3566  pop rdx
00007d5be8fd3567  pop rcx
00007d5be8fd3568  pop rax
00007d5be8fd3569  add rsp, 0x08
00007d5be8fd356d  jmp 0x00007D5BE8FCFEF1
00007d5be8fd3572  sub rsp, 0x08
00007d5be8fd3576  push rax
00007d5be8fd3577  push rcx
00007d5be8fd3578  push rdx
00007d5be8fd3579  push rdi
00007d5be8fd357a  push rsi
00007d5be8fd357b  push r8
00007d5be8fd357d  push r9
00007d5be8fd357f  push r10
00007d5be8fd3581  push r11
00007d5be8fd3583  sub rsp, 0xF0
00007d5be8fd358a  vmovaps [rsp], xmm0
00007d5be8fd358f  vmovaps [rsp+0x10], xmm1
00007d5be8fd3595  vmovaps [rsp+0x20], xmm2
00007d5be8fd359b  vmovaps [rsp+0x30], xmm3
00007d5be8fd35a1  vmovaps [rsp+0x40], xmm4
00007d5be8fd35a7  vmovaps [rsp+0x50], xmm5
00007d5be8fd35ad  vmovaps [rsp+0x60], xmm7
00007d5be8fd35b3  vmovaps [rsp+0x70], xmm8
00007d5be8fd35b9  vmovaps [rsp+0x80], xmm9
00007d5be8fd35c2  vmovaps [rsp+0x90], xmm10
00007d5be8fd35cb  vmovaps [rsp+0xA0], xmm11
00007d5be8fd35d4  vmovaps [rsp+0xB0], xmm12
00007d5be8fd35dd  vmovaps [rsp+0xC0], xmm13
00007d5be8fd35e6  vmovaps [rsp+0xD0], xmm14
00007d5be8fd35ef  vmovaps [rsp+0xE0], xmm15
00007d5be8fd35f8  sub rsp, 0x30
00007d5be8fd35fc  movaps [rsp], xmm6
00007d5be8fd3600  movaps [rsp+0x10], xmm9
00007d5be8fd3606  movaps [rsp+0x20], xmm12
00007d5be8fd360c  lea rdi, [rsp]
00007d5be8fd3610  mov esi, 0x00
00007d5be8fd3615  mov rax, 0x5D345705A530
00007d5be8fd361f  call rax
00007d5be8fd3621  movaps xmm6, [rsp]
00007d5be8fd3625  add rsp, 0x30
00007d5be8fd3629  vmovaps xmm0, [rsp]
00007d5be8fd362e  vmovaps xmm1, [rsp+0x10]
00007d5be8fd3634  vmovaps xmm2, [rsp+0x20]
00007d5be8fd363a  vmovaps xmm3, [rsp+0x30]
00007d5be8fd3640  vmovaps xmm4, [rsp+0x40]
00007d5be8fd3646  vmovaps xmm5, [rsp+0x50]
00007d5be8fd364c  vmovaps xmm7, [rsp+0x60]
00007d5be8fd3652  vmovaps xmm8, [rsp+0x70]
00007d5be8fd3658  vmovaps xmm9, [rsp+0x80]
00007d5be8fd3661  vmovaps xmm10, [rsp+0x90]
00007d5be8fd366a  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd3673  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd367c  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd3685  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd368e  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd3697  add rsp, 0xF0
00007d5be8fd369e  pop r11
00007d5be8fd36a0  pop r10
00007d5be8fd36a2  pop r9
00007d5be8fd36a4  pop r8
00007d5be8fd36a6  pop rsi
00007d5be8fd36a7  pop rdi
00007d5be8fd36a8  pop rdx
00007d5be8fd36a9  pop rcx
00007d5be8fd36aa  pop rax
00007d5be8fd36ab  add rsp, 0x08
00007d5be8fd36af  jmp 0x00007D5BE8FCFF19
00007d5be8fd36b4  sub rsp, 0x08
00007d5be8fd36b8  push rax
00007d5be8fd36b9  push rcx
00007d5be8fd36ba  push rdx
00007d5be8fd36bb  push rdi
00007d5be8fd36bc  push rsi
00007d5be8fd36bd  push r8
00007d5be8fd36bf  push r9
00007d5be8fd36c1  push r10
00007d5be8fd36c3  push r11
00007d5be8fd36c5  sub rsp, 0xF0
00007d5be8fd36cc  vmovaps [rsp], xmm0
00007d5be8fd36d1  vmovaps [rsp+0x10], xmm1
00007d5be8fd36d7  vmovaps [rsp+0x20], xmm2
00007d5be8fd36dd  vmovaps [rsp+0x30], xmm3
00007d5be8fd36e3  vmovaps [rsp+0x40], xmm4
00007d5be8fd36e9  vmovaps [rsp+0x50], xmm5
00007d5be8fd36ef  vmovaps [rsp+0x60], xmm6
00007d5be8fd36f5  vmovaps [rsp+0x70], xmm7
00007d5be8fd36fb  vmovaps [rsp+0x80], xmm8
00007d5be8fd3704  vmovaps [rsp+0x90], xmm9
00007d5be8fd370d  vmovaps [rsp+0xA0], xmm10
00007d5be8fd3716  vmovaps [rsp+0xB0], xmm11
00007d5be8fd371f  vmovaps [rsp+0xC0], xmm13
00007d5be8fd3728  vmovaps [rsp+0xD0], xmm14
00007d5be8fd3731  vmovaps [rsp+0xE0], xmm15
00007d5be8fd373a  sub rsp, 0x30
00007d5be8fd373e  movaps [rsp], xmm12
00007d5be8fd3743  movaps [rsp+0x10], xmm15
00007d5be8fd3749  movaps [rsp+0x20], xmm13
00007d5be8fd374f  lea rdi, [rsp]
00007d5be8fd3753  mov esi, 0x00
00007d5be8fd3758  mov rax, 0x5D345705A530
00007d5be8fd3762  call rax
00007d5be8fd3764  movaps xmm12, [rsp]
00007d5be8fd3769  add rsp, 0x30
00007d5be8fd376d  vmovaps xmm0, [rsp]
00007d5be8fd3772  vmovaps xmm1, [rsp+0x10]
00007d5be8fd3778  vmovaps xmm2, [rsp+0x20]
00007d5be8fd377e  vmovaps xmm3, [rsp+0x30]
00007d5be8fd3784  vmovaps xmm4, [rsp+0x40]
00007d5be8fd378a  vmovaps xmm5, [rsp+0x50]
00007d5be8fd3790  vmovaps xmm6, [rsp+0x60]
00007d5be8fd3796  vmovaps xmm7, [rsp+0x70]
00007d5be8fd379c  vmovaps xmm8, [rsp+0x80]
00007d5be8fd37a5  vmovaps xmm9, [rsp+0x90]
00007d5be8fd37ae  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd37b7  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd37c0  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd37c9  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd37d2  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd37db  add rsp, 0xF0
00007d5be8fd37e2  pop r11
00007d5be8fd37e4  pop r10
00007d5be8fd37e6  pop r9
00007d5be8fd37e8  pop r8
00007d5be8fd37ea  pop rsi
00007d5be8fd37eb  pop rdi
00007d5be8fd37ec  pop rdx
00007d5be8fd37ed  pop rcx
00007d5be8fd37ee  pop rax
00007d5be8fd37ef  add rsp, 0x08
00007d5be8fd37f3  jmp 0x00007D5BE8FCFF34
00007d5be8fd37f8  sub rsp, 0x08
00007d5be8fd37fc  push rax
00007d5be8fd37fd  push rcx
00007d5be8fd37fe  push rdx
00007d5be8fd37ff  push rdi
00007d5be8fd3800  push rsi
00007d5be8fd3801  push r8
00007d5be8fd3803  push r9
00007d5be8fd3805  push r10
00007d5be8fd3807  push r11
00007d5be8fd3809  sub rsp, 0xF0
00007d5be8fd3810  vmovaps [rsp], xmm0
00007d5be8fd3815  vmovaps [rsp+0x10], xmm1
00007d5be8fd381b  vmovaps [rsp+0x20], xmm2
00007d5be8fd3821  vmovaps [rsp+0x30], xmm3
00007d5be8fd3827  vmovaps [rsp+0x40], xmm4
00007d5be8fd382d  vmovaps [rsp+0x50], xmm5
00007d5be8fd3833  vmovaps [rsp+0x60], xmm6
00007d5be8fd3839  vmovaps [rsp+0x70], xmm7
00007d5be8fd383f  vmovaps [rsp+0x80], xmm8
00007d5be8fd3848  vmovaps [rsp+0x90], xmm9
00007d5be8fd3851  vmovaps [rsp+0xA0], xmm10
00007d5be8fd385a  vmovaps [rsp+0xB0], xmm11
00007d5be8fd3863  vmovaps [rsp+0xC0], xmm12
00007d5be8fd386c  vmovaps [rsp+0xD0], xmm13
00007d5be8fd3875  vmovaps [rsp+0xE0], xmm14
00007d5be8fd387e  sub rsp, 0x30
00007d5be8fd3882  movaps [rsp], xmm15
00007d5be8fd3887  movaps [rsp+0x10], xmm13
00007d5be8fd388d  movaps [rsp+0x20], xmm10
00007d5be8fd3893  lea rdi, [rsp]
00007d5be8fd3897  mov esi, 0x00
00007d5be8fd389c  mov rax, 0x5D345705A530
00007d5be8fd38a6  call rax
00007d5be8fd38a8  movaps xmm15, [rsp]
00007d5be8fd38ad  add rsp, 0x30
00007d5be8fd38b1  vmovaps xmm0, [rsp]
00007d5be8fd38b6  vmovaps xmm1, [rsp+0x10]
00007d5be8fd38bc  vmovaps xmm2, [rsp+0x20]
00007d5be8fd38c2  vmovaps xmm3, [rsp+0x30]
00007d5be8fd38c8  vmovaps xmm4, [rsp+0x40]
00007d5be8fd38ce  vmovaps xmm5, [rsp+0x50]
00007d5be8fd38d4  vmovaps xmm6, [rsp+0x60]
00007d5be8fd38da  vmovaps xmm7, [rsp+0x70]
00007d5be8fd38e0  vmovaps xmm8, [rsp+0x80]
00007d5be8fd38e9  vmovaps xmm9, [rsp+0x90]
00007d5be8fd38f2  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd38fb  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd3904  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd390d  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd3916  vmovaps xmm14, [rsp+0xE0]
00007d5be8fd391f  add rsp, 0xF0
00007d5be8fd3926  pop r11
00007d5be8fd3928  pop r10
00007d5be8fd392a  pop r9
00007d5be8fd392c  pop r8
00007d5be8fd392e  pop rsi
00007d5be8fd392f  pop rdi
00007d5be8fd3930  pop rdx
00007d5be8fd3931  pop rcx
00007d5be8fd3932  pop rax
00007d5be8fd3933  add rsp, 0x08
00007d5be8fd3937  jmp 0x00007D5BE8FCFF55
00007d5be8fd393c  call 0x00007D5BE8E0C260
00007d5be8fd3941  jmp 0x00007D5BE8FCFFB0
00007d5be8fd3946  sub rsp, 0x08
00007d5be8fd394a  push rax
00007d5be8fd394b  push rcx
00007d5be8fd394c  push rdx
00007d5be8fd394d  push rdi
00007d5be8fd394e  push rsi
00007d5be8fd394f  push r8
00007d5be8fd3951  push r9
00007d5be8fd3953  push r10
00007d5be8fd3955  push r11
00007d5be8fd3957  sub rsp, 0xF0
00007d5be8fd395e  vmovaps [rsp], xmm0
00007d5be8fd3963  vmovaps [rsp+0x10], xmm1
00007d5be8fd3969  vmovaps [rsp+0x20], xmm2
00007d5be8fd396f  vmovaps [rsp+0x30], xmm3
00007d5be8fd3975  vmovaps [rsp+0x40], xmm4
00007d5be8fd397b  vmovaps [rsp+0x50], xmm5
00007d5be8fd3981  vmovaps [rsp+0x60], xmm6
00007d5be8fd3987  vmovaps [rsp+0x70], xmm7
00007d5be8fd398d  vmovaps [rsp+0x80], xmm8
00007d5be8fd3996  vmovaps [rsp+0x90], xmm10
00007d5be8fd399f  vmovaps [rsp+0xA0], xmm11
00007d5be8fd39a8  vmovaps [rsp+0xB0], xmm12
00007d5be8fd39b1  vmovaps [rsp+0xC0], xmm13
00007d5be8fd39ba  vmovaps [rsp+0xD0], xmm14
00007d5be8fd39c3  vmovaps [rsp+0xE0], xmm15
00007d5be8fd39cc  sub rsp, 0x30
00007d5be8fd39d0  movaps [rsp], xmm9
00007d5be8fd39d5  movaps [rsp+0x10], xmm8
00007d5be8fd39db  movaps [rsp+0x20], xmm10
00007d5be8fd39e1  lea rdi, [rsp]
00007d5be8fd39e5  mov esi, 0x00
00007d5be8fd39ea  mov rax, 0x5D345705A530
00007d5be8fd39f4  call rax
00007d5be8fd39f6  movaps xmm9, [rsp]
00007d5be8fd39fb  add rsp, 0x30
00007d5be8fd39ff  vmovaps xmm0, [rsp]
00007d5be8fd3a04  vmovaps xmm1, [rsp+0x10]
00007d5be8fd3a0a  vmovaps xmm2, [rsp+0x20]
00007d5be8fd3a10  vmovaps xmm3, [rsp+0x30]
00007d5be8fd3a16  vmovaps xmm4, [rsp+0x40]
00007d5be8fd3a1c  vmovaps xmm5, [rsp+0x50]
00007d5be8fd3a22  vmovaps xmm6, [rsp+0x60]
00007d5be8fd3a28  vmovaps xmm7, [rsp+0x70]
00007d5be8fd3a2e  vmovaps xmm8, [rsp+0x80]
00007d5be8fd3a37  vmovaps xmm10, [rsp+0x90]
00007d5be8fd3a40  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd3a49  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd3a52  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd3a5b  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd3a64  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd3a6d  add rsp, 0xF0
00007d5be8fd3a74  pop r11
00007d5be8fd3a76  pop r10
00007d5be8fd3a78  pop r9
00007d5be8fd3a7a  pop r8
00007d5be8fd3a7c  pop rsi
00007d5be8fd3a7d  pop rdi
00007d5be8fd3a7e  pop rdx
00007d5be8fd3a7f  pop rcx
00007d5be8fd3a80  pop rax
00007d5be8fd3a81  add rsp, 0x08
00007d5be8fd3a85  jmp 0x00007D5BE8FCFFE1
00007d5be8fd3a8a  sub rsp, 0x08
00007d5be8fd3a8e  push rax
00007d5be8fd3a8f  push rcx
00007d5be8fd3a90  push rdx
00007d5be8fd3a91  push rdi
00007d5be8fd3a92  push rsi
00007d5be8fd3a93  push r8
00007d5be8fd3a95  push r9
00007d5be8fd3a97  push r10
00007d5be8fd3a99  push r11
00007d5be8fd3a9b  sub rsp, 0xF0
00007d5be8fd3aa2  vmovaps [rsp], xmm0
00007d5be8fd3aa7  vmovaps [rsp+0x10], xmm1
00007d5be8fd3aad  vmovaps [rsp+0x20], xmm2
00007d5be8fd3ab3  vmovaps [rsp+0x30], xmm3
00007d5be8fd3ab9  vmovaps [rsp+0x40], xmm4
00007d5be8fd3abf  vmovaps [rsp+0x50], xmm5
00007d5be8fd3ac5  vmovaps [rsp+0x60], xmm6
00007d5be8fd3acb  vmovaps [rsp+0x70], xmm7
00007d5be8fd3ad1  vmovaps [rsp+0x80], xmm8
00007d5be8fd3ada  vmovaps [rsp+0x90], xmm9
00007d5be8fd3ae3  vmovaps [rsp+0xA0], xmm11
00007d5be8fd3aec  vmovaps [rsp+0xB0], xmm12
00007d5be8fd3af5  vmovaps [rsp+0xC0], xmm13
00007d5be8fd3afe  vmovaps [rsp+0xD0], xmm14
00007d5be8fd3b07  vmovaps [rsp+0xE0], xmm15
00007d5be8fd3b10  sub rsp, 0x30
00007d5be8fd3b14  movaps [rsp], xmm10
00007d5be8fd3b19  movaps [rsp+0x10], xmm1
00007d5be8fd3b1e  movaps [rsp+0x20], xmm11
00007d5be8fd3b24  lea rdi, [rsp]
00007d5be8fd3b28  mov esi, 0x00
00007d5be8fd3b2d  mov rax, 0x5D345705A530
00007d5be8fd3b37  call rax
00007d5be8fd3b39  movaps xmm10, [rsp]
00007d5be8fd3b3e  add rsp, 0x30
00007d5be8fd3b42  vmovaps xmm0, [rsp]
00007d5be8fd3b47  vmovaps xmm1, [rsp+0x10]
00007d5be8fd3b4d  vmovaps xmm2, [rsp+0x20]
00007d5be8fd3b53  vmovaps xmm3, [rsp+0x30]
00007d5be8fd3b59  vmovaps xmm4, [rsp+0x40]
00007d5be8fd3b5f  vmovaps xmm5, [rsp+0x50]
00007d5be8fd3b65  vmovaps xmm6, [rsp+0x60]
00007d5be8fd3b6b  vmovaps xmm7, [rsp+0x70]
00007d5be8fd3b71  vmovaps xmm8, [rsp+0x80]
00007d5be8fd3b7a  vmovaps xmm9, [rsp+0x90]
00007d5be8fd3b83  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd3b8c  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd3b95  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd3b9e  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd3ba7  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd3bb0  add rsp, 0xF0
00007d5be8fd3bb7  pop r11
00007d5be8fd3bb9  pop r10
00007d5be8fd3bbb  pop r9
00007d5be8fd3bbd  pop r8
00007d5be8fd3bbf  pop rsi
00007d5be8fd3bc0  pop rdi
00007d5be8fd3bc1  pop rdx
00007d5be8fd3bc2  pop rcx
00007d5be8fd3bc3  pop rax
00007d5be8fd3bc4  add rsp, 0x08
00007d5be8fd3bc8  jmp 0x00007D5BE8FCFFFC
00007d5be8fd3bcd  sub rsp, 0x08
00007d5be8fd3bd1  push rax
00007d5be8fd3bd2  push rcx
00007d5be8fd3bd3  push rdx
00007d5be8fd3bd4  push rdi
00007d5be8fd3bd5  push rsi
00007d5be8fd3bd6  push r8
00007d5be8fd3bd8  push r9
00007d5be8fd3bda  push r10
00007d5be8fd3bdc  push r11
00007d5be8fd3bde  sub rsp, 0xF0
00007d5be8fd3be5  vmovaps [rsp], xmm0
00007d5be8fd3bea  vmovaps [rsp+0x10], xmm2
00007d5be8fd3bf0  vmovaps [rsp+0x20], xmm3
00007d5be8fd3bf6  vmovaps [rsp+0x30], xmm4
00007d5be8fd3bfc  vmovaps [rsp+0x40], xmm5
00007d5be8fd3c02  vmovaps [rsp+0x50], xmm6
00007d5be8fd3c08  vmovaps [rsp+0x60], xmm7
00007d5be8fd3c0e  vmovaps [rsp+0x70], xmm8
00007d5be8fd3c14  vmovaps [rsp+0x80], xmm9
00007d5be8fd3c1d  vmovaps [rsp+0x90], xmm10
00007d5be8fd3c26  vmovaps [rsp+0xA0], xmm11
00007d5be8fd3c2f  vmovaps [rsp+0xB0], xmm12
00007d5be8fd3c38  vmovaps [rsp+0xC0], xmm13
00007d5be8fd3c41  vmovaps [rsp+0xD0], xmm14
00007d5be8fd3c4a  vmovaps [rsp+0xE0], xmm15
00007d5be8fd3c53  sub rsp, 0x30
00007d5be8fd3c57  movaps [rsp], xmm1
00007d5be8fd3c5b  movaps [rsp+0x10], xmm14
00007d5be8fd3c61  movaps [rsp+0x20], xmm6
00007d5be8fd3c66  lea rdi, [rsp]
00007d5be8fd3c6a  mov esi, 0x00
00007d5be8fd3c6f  mov rax, 0x5D345705A530
00007d5be8fd3c79  call rax
00007d5be8fd3c7b  movaps xmm1, [rsp]
00007d5be8fd3c7f  add rsp, 0x30
00007d5be8fd3c83  vmovaps xmm0, [rsp]
00007d5be8fd3c88  vmovaps xmm2, [rsp+0x10]
00007d5be8fd3c8e  vmovaps xmm3, [rsp+0x20]
00007d5be8fd3c94  vmovaps xmm4, [rsp+0x30]
00007d5be8fd3c9a  vmovaps xmm5, [rsp+0x40]
00007d5be8fd3ca0  vmovaps xmm6, [rsp+0x50]
00007d5be8fd3ca6  vmovaps xmm7, [rsp+0x60]
00007d5be8fd3cac  vmovaps xmm8, [rsp+0x70]
00007d5be8fd3cb2  vmovaps xmm9, [rsp+0x80]
00007d5be8fd3cbb  vmovaps xmm10, [rsp+0x90]
00007d5be8fd3cc4  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd3ccd  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd3cd6  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd3cdf  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd3ce8  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd3cf1  add rsp, 0xF0
00007d5be8fd3cf8  pop r11
00007d5be8fd3cfa  pop r10
00007d5be8fd3cfc  pop r9
00007d5be8fd3cfe  pop r8
00007d5be8fd3d00  pop rsi
00007d5be8fd3d01  pop rdi
00007d5be8fd3d02  pop rdx
00007d5be8fd3d03  pop rcx
00007d5be8fd3d04  pop rax
00007d5be8fd3d05  add rsp, 0x08
00007d5be8fd3d09  jmp 0x00007D5BE8FD0015
00007d5be8fd3d0e  sub rsp, 0x08
00007d5be8fd3d12  push rax
00007d5be8fd3d13  push rcx
00007d5be8fd3d14  push rdx
00007d5be8fd3d15  push rdi
00007d5be8fd3d16  push rsi
00007d5be8fd3d17  push r8
00007d5be8fd3d19  push r9
00007d5be8fd3d1b  push r10
00007d5be8fd3d1d  push r11
00007d5be8fd3d1f  sub rsp, 0xF0
00007d5be8fd3d26  vmovaps [rsp], xmm0
00007d5be8fd3d2b  vmovaps [rsp+0x10], xmm1
00007d5be8fd3d31  vmovaps [rsp+0x20], xmm2
00007d5be8fd3d37  vmovaps [rsp+0x30], xmm3
00007d5be8fd3d3d  vmovaps [rsp+0x40], xmm4
00007d5be8fd3d43  vmovaps [rsp+0x50], xmm5
00007d5be8fd3d49  vmovaps [rsp+0x60], xmm6
00007d5be8fd3d4f  vmovaps [rsp+0x70], xmm7
00007d5be8fd3d55  vmovaps [rsp+0x80], xmm8
00007d5be8fd3d5e  vmovaps [rsp+0x90], xmm9
00007d5be8fd3d67  vmovaps [rsp+0xA0], xmm10
00007d5be8fd3d70  vmovaps [rsp+0xB0], xmm12
00007d5be8fd3d79  vmovaps [rsp+0xC0], xmm13
00007d5be8fd3d82  vmovaps [rsp+0xD0], xmm14
00007d5be8fd3d8b  vmovaps [rsp+0xE0], xmm15
00007d5be8fd3d94  sub rsp, 0x30
00007d5be8fd3d98  movaps [rsp], xmm11
00007d5be8fd3d9d  movaps [rsp+0x10], xmm13
00007d5be8fd3da3  movaps [rsp+0x20], xmm14
00007d5be8fd3da9  lea rdi, [rsp]
00007d5be8fd3dad  mov esi, 0x00
00007d5be8fd3db2  mov rax, 0x5D345705A530
00007d5be8fd3dbc  call rax
00007d5be8fd3dbe  movaps xmm11, [rsp]
00007d5be8fd3dc3  add rsp, 0x30
00007d5be8fd3dc7  vmovaps xmm0, [rsp]
00007d5be8fd3dcc  vmovaps xmm1, [rsp+0x10]
00007d5be8fd3dd2  vmovaps xmm2, [rsp+0x20]
00007d5be8fd3dd8  vmovaps xmm3, [rsp+0x30]
00007d5be8fd3dde  vmovaps xmm4, [rsp+0x40]
00007d5be8fd3de4  vmovaps xmm5, [rsp+0x50]
00007d5be8fd3dea  vmovaps xmm6, [rsp+0x60]
00007d5be8fd3df0  vmovaps xmm7, [rsp+0x70]
00007d5be8fd3df6  vmovaps xmm8, [rsp+0x80]
00007d5be8fd3dff  vmovaps xmm9, [rsp+0x90]
00007d5be8fd3e08  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd3e11  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd3e1a  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd3e23  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd3e2c  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd3e35  add rsp, 0xF0
00007d5be8fd3e3c  pop r11
00007d5be8fd3e3e  pop r10
00007d5be8fd3e40  pop r9
00007d5be8fd3e42  pop r8
00007d5be8fd3e44  pop rsi
00007d5be8fd3e45  pop rdi
00007d5be8fd3e46  pop rdx
00007d5be8fd3e47  pop rcx
00007d5be8fd3e48  pop rax
00007d5be8fd3e49  add rsp, 0x08
00007d5be8fd3e4d  jmp 0x00007D5BE8FD003F
00007d5be8fd3e52  sub rsp, 0x08
00007d5be8fd3e56  push rax
00007d5be8fd3e57  push rcx
00007d5be8fd3e58  push rdx
00007d5be8fd3e59  push rdi
00007d5be8fd3e5a  push rsi
00007d5be8fd3e5b  push r8
00007d5be8fd3e5d  push r9
00007d5be8fd3e5f  push r10
00007d5be8fd3e61  push r11
00007d5be8fd3e63  sub rsp, 0xF0
00007d5be8fd3e6a  vmovaps [rsp], xmm0
00007d5be8fd3e6f  vmovaps [rsp+0x10], xmm1
00007d5be8fd3e75  vmovaps [rsp+0x20], xmm2
00007d5be8fd3e7b  vmovaps [rsp+0x30], xmm3
00007d5be8fd3e81  vmovaps [rsp+0x40], xmm4
00007d5be8fd3e87  vmovaps [rsp+0x50], xmm5
00007d5be8fd3e8d  vmovaps [rsp+0x60], xmm6
00007d5be8fd3e93  vmovaps [rsp+0x70], xmm7
00007d5be8fd3e99  vmovaps [rsp+0x80], xmm8
00007d5be8fd3ea2  vmovaps [rsp+0x90], xmm9
00007d5be8fd3eab  vmovaps [rsp+0xA0], xmm10
00007d5be8fd3eb4  vmovaps [rsp+0xB0], xmm11
00007d5be8fd3ebd  vmovaps [rsp+0xC0], xmm12
00007d5be8fd3ec6  vmovaps [rsp+0xD0], xmm14
00007d5be8fd3ecf  vmovaps [rsp+0xE0], xmm15
00007d5be8fd3ed8  sub rsp, 0x30
00007d5be8fd3edc  movaps [rsp], xmm13
00007d5be8fd3ee1  movaps [rsp+0x10], xmm8
00007d5be8fd3ee7  movaps [rsp+0x20], xmm14
00007d5be8fd3eed  lea rdi, [rsp]
00007d5be8fd3ef1  mov esi, 0x00
00007d5be8fd3ef6  mov rax, 0x5D345705A530
00007d5be8fd3f00  call rax
00007d5be8fd3f02  movaps xmm13, [rsp]
00007d5be8fd3f07  add rsp, 0x30
00007d5be8fd3f0b  vmovaps xmm0, [rsp]
00007d5be8fd3f10  vmovaps xmm1, [rsp+0x10]
00007d5be8fd3f16  vmovaps xmm2, [rsp+0x20]
00007d5be8fd3f1c  vmovaps xmm3, [rsp+0x30]
00007d5be8fd3f22  vmovaps xmm4, [rsp+0x40]
00007d5be8fd3f28  vmovaps xmm5, [rsp+0x50]
00007d5be8fd3f2e  vmovaps xmm6, [rsp+0x60]
00007d5be8fd3f34  vmovaps xmm7, [rsp+0x70]
00007d5be8fd3f3a  vmovaps xmm8, [rsp+0x80]
00007d5be8fd3f43  vmovaps xmm9, [rsp+0x90]
00007d5be8fd3f4c  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd3f55  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd3f5e  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd3f67  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd3f70  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd3f79  add rsp, 0xF0
00007d5be8fd3f80  pop r11
00007d5be8fd3f82  pop r10
00007d5be8fd3f84  pop r9
00007d5be8fd3f86  pop r8
00007d5be8fd3f88  pop rsi
00007d5be8fd3f89  pop rdi
00007d5be8fd3f8a  pop rdx
00007d5be8fd3f8b  pop rcx
00007d5be8fd3f8c  pop rax
00007d5be8fd3f8d  add rsp, 0x08
00007d5be8fd3f91  jmp 0x00007D5BE8FD006E
00007d5be8fd3f96  sub rsp, 0x08
00007d5be8fd3f9a  push rax
00007d5be8fd3f9b  push rcx
00007d5be8fd3f9c  push rdx
00007d5be8fd3f9d  push rdi
00007d5be8fd3f9e  push rsi
00007d5be8fd3f9f  push r8
00007d5be8fd3fa1  push r9
00007d5be8fd3fa3  push r10
00007d5be8fd3fa5  push r11
00007d5be8fd3fa7  sub rsp, 0xF0
00007d5be8fd3fae  vmovaps [rsp], xmm0
00007d5be8fd3fb3  vmovaps [rsp+0x10], xmm1
00007d5be8fd3fb9  vmovaps [rsp+0x20], xmm2
00007d5be8fd3fbf  vmovaps [rsp+0x30], xmm3
00007d5be8fd3fc5  vmovaps [rsp+0x40], xmm4
00007d5be8fd3fcb  vmovaps [rsp+0x50], xmm5
00007d5be8fd3fd1  vmovaps [rsp+0x60], xmm6
00007d5be8fd3fd7  vmovaps [rsp+0x70], xmm7
00007d5be8fd3fdd  vmovaps [rsp+0x80], xmm9
00007d5be8fd3fe6  vmovaps [rsp+0x90], xmm10
00007d5be8fd3fef  vmovaps [rsp+0xA0], xmm11
00007d5be8fd3ff8  vmovaps [rsp+0xB0], xmm12
00007d5be8fd4001  vmovaps [rsp+0xC0], xmm13
00007d5be8fd400a  vmovaps [rsp+0xD0], xmm14
00007d5be8fd4013  vmovaps [rsp+0xE0], xmm15
00007d5be8fd401c  sub rsp, 0x30
00007d5be8fd4020  movaps [rsp], xmm8
00007d5be8fd4025  movaps [rsp+0x10], xmm7
00007d5be8fd402a  movaps [rsp+0x20], xmm14
00007d5be8fd4030  lea rdi, [rsp]
00007d5be8fd4034  mov esi, 0x00
00007d5be8fd4039  mov rax, 0x5D345705A530
00007d5be8fd4043  call rax
00007d5be8fd4045  movaps xmm8, [rsp]
00007d5be8fd404a  add rsp, 0x30
00007d5be8fd404e  vmovaps xmm0, [rsp]
00007d5be8fd4053  vmovaps xmm1, [rsp+0x10]
00007d5be8fd4059  vmovaps xmm2, [rsp+0x20]
00007d5be8fd405f  vmovaps xmm3, [rsp+0x30]
00007d5be8fd4065  vmovaps xmm4, [rsp+0x40]
00007d5be8fd406b  vmovaps xmm5, [rsp+0x50]
00007d5be8fd4071  vmovaps xmm6, [rsp+0x60]
00007d5be8fd4077  vmovaps xmm7, [rsp+0x70]
00007d5be8fd407d  vmovaps xmm9, [rsp+0x80]
00007d5be8fd4086  vmovaps xmm10, [rsp+0x90]
00007d5be8fd408f  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd4098  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd40a1  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd40aa  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd40b3  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd40bc  add rsp, 0xF0
00007d5be8fd40c3  pop r11
00007d5be8fd40c5  pop r10
00007d5be8fd40c7  pop r9
00007d5be8fd40c9  pop r8
00007d5be8fd40cb  pop rsi
00007d5be8fd40cc  pop rdi
00007d5be8fd40cd  pop rdx
00007d5be8fd40ce  pop rcx
00007d5be8fd40cf  pop rax
00007d5be8fd40d0  add rsp, 0x08
00007d5be8fd40d4  jmp 0x00007D5BE8FD0094
00007d5be8fd40d9  sub rsp, 0x08
00007d5be8fd40dd  push rax
00007d5be8fd40de  push rcx
00007d5be8fd40df  push rdx
00007d5be8fd40e0  push rdi
00007d5be8fd40e1  push rsi
00007d5be8fd40e2  push r8
00007d5be8fd40e4  push r9
00007d5be8fd40e6  push r10
00007d5be8fd40e8  push r11
00007d5be8fd40ea  sub rsp, 0xF0
00007d5be8fd40f1  vmovaps [rsp], xmm0
00007d5be8fd40f6  vmovaps [rsp+0x10], xmm1
00007d5be8fd40fc  vmovaps [rsp+0x20], xmm2
00007d5be8fd4102  vmovaps [rsp+0x30], xmm3
00007d5be8fd4108  vmovaps [rsp+0x40], xmm4
00007d5be8fd410e  vmovaps [rsp+0x50], xmm5
00007d5be8fd4114  vmovaps [rsp+0x60], xmm6
00007d5be8fd411a  vmovaps [rsp+0x70], xmm7
00007d5be8fd4120  vmovaps [rsp+0x80], xmm8
00007d5be8fd4129  vmovaps [rsp+0x90], xmm9
00007d5be8fd4132  vmovaps [rsp+0xA0], xmm10
00007d5be8fd413b  vmovaps [rsp+0xB0], xmm11
00007d5be8fd4144  vmovaps [rsp+0xC0], xmm12
00007d5be8fd414d  vmovaps [rsp+0xD0], xmm13
00007d5be8fd4156  vmovaps [rsp+0xE0], xmm15
00007d5be8fd415f  sub rsp, 0x30
00007d5be8fd4163  movaps [rsp], xmm14
00007d5be8fd4168  movaps [rsp+0x10], xmm12
00007d5be8fd416e  movaps [rsp+0x20], xmm9
00007d5be8fd4174  lea rdi, [rsp]
00007d5be8fd4178  mov esi, 0x00
00007d5be8fd417d  mov rax, 0x5D345705A530
00007d5be8fd4187  call rax
00007d5be8fd4189  movaps xmm14, [rsp]
00007d5be8fd418e  add rsp, 0x30
00007d5be8fd4192  vmovaps xmm0, [rsp]
00007d5be8fd4197  vmovaps xmm1, [rsp+0x10]
00007d5be8fd419d  vmovaps xmm2, [rsp+0x20]
00007d5be8fd41a3  vmovaps xmm3, [rsp+0x30]
00007d5be8fd41a9  vmovaps xmm4, [rsp+0x40]
00007d5be8fd41af  vmovaps xmm5, [rsp+0x50]
00007d5be8fd41b5  vmovaps xmm6, [rsp+0x60]
00007d5be8fd41bb  vmovaps xmm7, [rsp+0x70]
00007d5be8fd41c1  vmovaps xmm8, [rsp+0x80]
00007d5be8fd41ca  vmovaps xmm9, [rsp+0x90]
00007d5be8fd41d3  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd41dc  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd41e5  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd41ee  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd41f7  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd4200  add rsp, 0xF0
00007d5be8fd4207  pop r11
00007d5be8fd4209  pop r10
00007d5be8fd420b  pop r9
00007d5be8fd420d  pop r8
00007d5be8fd420f  pop rsi
00007d5be8fd4210  pop rdi
00007d5be8fd4211  pop rdx
00007d5be8fd4212  pop rcx
00007d5be8fd4213  pop rax
00007d5be8fd4214  add rsp, 0x08
00007d5be8fd4218  jmp 0x00007D5BE8FD00AE
00007d5be8fd421d  sub rsp, 0x08
00007d5be8fd4221  push rax
00007d5be8fd4222  push rcx
00007d5be8fd4223  push rdx
00007d5be8fd4224  push rdi
00007d5be8fd4225  push rsi
00007d5be8fd4226  push r8
00007d5be8fd4228  push r9
00007d5be8fd422a  push r10
00007d5be8fd422c  push r11
00007d5be8fd422e  sub rsp, 0xF0
00007d5be8fd4235  vmovaps [rsp], xmm0
00007d5be8fd423a  vmovaps [rsp+0x10], xmm1
00007d5be8fd4240  vmovaps [rsp+0x20], xmm2
00007d5be8fd4246  vmovaps [rsp+0x30], xmm3
00007d5be8fd424c  vmovaps [rsp+0x40], xmm4
00007d5be8fd4252  vmovaps [rsp+0x50], xmm5
00007d5be8fd4258  vmovaps [rsp+0x60], xmm6
00007d5be8fd425e  vmovaps [rsp+0x70], xmm7
00007d5be8fd4264  vmovaps [rsp+0x80], xmm8
00007d5be8fd426d  vmovaps [rsp+0x90], xmm10
00007d5be8fd4276  vmovaps [rsp+0xA0], xmm11
00007d5be8fd427f  vmovaps [rsp+0xB0], xmm12
00007d5be8fd4288  vmovaps [rsp+0xC0], xmm13
00007d5be8fd4291  vmovaps [rsp+0xD0], xmm14
00007d5be8fd429a  vmovaps [rsp+0xE0], xmm15
00007d5be8fd42a3  sub rsp, 0x30
00007d5be8fd42a7  movaps [rsp], xmm9
00007d5be8fd42ac  movaps [rsp+0x10], xmm7
00007d5be8fd42b1  movaps [rsp+0x20], xmm12
00007d5be8fd42b7  lea rdi, [rsp]
00007d5be8fd42bb  mov esi, 0x00
00007d5be8fd42c0  mov rax, 0x5D345705A530
00007d5be8fd42ca  call rax
00007d5be8fd42cc  movaps xmm9, [rsp]
00007d5be8fd42d1  add rsp, 0x30
00007d5be8fd42d5  vmovaps xmm0, [rsp]
00007d5be8fd42da  vmovaps xmm1, [rsp+0x10]
00007d5be8fd42e0  vmovaps xmm2, [rsp+0x20]
00007d5be8fd42e6  vmovaps xmm3, [rsp+0x30]
00007d5be8fd42ec  vmovaps xmm4, [rsp+0x40]
00007d5be8fd42f2  vmovaps xmm5, [rsp+0x50]
00007d5be8fd42f8  vmovaps xmm6, [rsp+0x60]
00007d5be8fd42fe  vmovaps xmm7, [rsp+0x70]
00007d5be8fd4304  vmovaps xmm8, [rsp+0x80]
00007d5be8fd430d  vmovaps xmm10, [rsp+0x90]
00007d5be8fd4316  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd431f  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd4328  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd4331  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd433a  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd4343  add rsp, 0xF0
00007d5be8fd434a  pop r11
00007d5be8fd434c  pop r10
00007d5be8fd434e  pop r9
00007d5be8fd4350  pop r8
00007d5be8fd4352  pop rsi
00007d5be8fd4353  pop rdi
00007d5be8fd4354  pop rdx
00007d5be8fd4355  pop rcx
00007d5be8fd4356  pop rax
00007d5be8fd4357  add rsp, 0x08
00007d5be8fd435b  jmp 0x00007D5BE8FD00DD
00007d5be8fd4360  sub rsp, 0x08
00007d5be8fd4364  push rax
00007d5be8fd4365  push rcx
00007d5be8fd4366  push rdx
00007d5be8fd4367  push rdi
00007d5be8fd4368  push rsi
00007d5be8fd4369  push r8
00007d5be8fd436b  push r9
00007d5be8fd436d  push r10
00007d5be8fd436f  push r11
00007d5be8fd4371  sub rsp, 0xF0
00007d5be8fd4378  vmovaps [rsp], xmm0
00007d5be8fd437d  vmovaps [rsp+0x10], xmm1
00007d5be8fd4383  vmovaps [rsp+0x20], xmm2
00007d5be8fd4389  vmovaps [rsp+0x30], xmm3
00007d5be8fd438f  vmovaps [rsp+0x40], xmm4
00007d5be8fd4395  vmovaps [rsp+0x50], xmm5
00007d5be8fd439b  vmovaps [rsp+0x60], xmm6
00007d5be8fd43a1  vmovaps [rsp+0x70], xmm7
00007d5be8fd43a7  vmovaps [rsp+0x80], xmm8
00007d5be8fd43b0  vmovaps [rsp+0x90], xmm9
00007d5be8fd43b9  vmovaps [rsp+0xA0], xmm10
00007d5be8fd43c2  vmovaps [rsp+0xB0], xmm11
00007d5be8fd43cb  vmovaps [rsp+0xC0], xmm13
00007d5be8fd43d4  vmovaps [rsp+0xD0], xmm14
00007d5be8fd43dd  vmovaps [rsp+0xE0], xmm15
00007d5be8fd43e6  sub rsp, 0x30
00007d5be8fd43ea  movaps [rsp], xmm12
00007d5be8fd43ef  movaps [rsp+0x10], xmm15
00007d5be8fd43f5  movaps [rsp+0x20], xmm11
00007d5be8fd43fb  lea rdi, [rsp]
00007d5be8fd43ff  mov esi, 0x00
00007d5be8fd4404  mov rax, 0x5D345705A530
00007d5be8fd440e  call rax
00007d5be8fd4410  movaps xmm12, [rsp]
00007d5be8fd4415  add rsp, 0x30
00007d5be8fd4419  vmovaps xmm0, [rsp]
00007d5be8fd441e  vmovaps xmm1, [rsp+0x10]
00007d5be8fd4424  vmovaps xmm2, [rsp+0x20]
00007d5be8fd442a  vmovaps xmm3, [rsp+0x30]
00007d5be8fd4430  vmovaps xmm4, [rsp+0x40]
00007d5be8fd4436  vmovaps xmm5, [rsp+0x50]
00007d5be8fd443c  vmovaps xmm6, [rsp+0x60]
00007d5be8fd4442  vmovaps xmm7, [rsp+0x70]
00007d5be8fd4448  vmovaps xmm8, [rsp+0x80]
00007d5be8fd4451  vmovaps xmm9, [rsp+0x90]
00007d5be8fd445a  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd4463  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd446c  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd4475  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd447e  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd4487  add rsp, 0xF0
00007d5be8fd448e  pop r11
00007d5be8fd4490  pop r10
00007d5be8fd4492  pop r9
00007d5be8fd4494  pop r8
00007d5be8fd4496  pop rsi
00007d5be8fd4497  pop rdi
00007d5be8fd4498  pop rdx
00007d5be8fd4499  pop rcx
00007d5be8fd449a  pop rax
00007d5be8fd449b  add rsp, 0x08
00007d5be8fd449f  jmp 0x00007D5BE8FD00F7
00007d5be8fd44a4  sub rsp, 0x08
00007d5be8fd44a8  push rax
00007d5be8fd44a9  push rcx
00007d5be8fd44aa  push rdx
00007d5be8fd44ab  push rdi
00007d5be8fd44ac  push rsi
00007d5be8fd44ad  push r8
00007d5be8fd44af  push r9
00007d5be8fd44b1  push r10
00007d5be8fd44b3  push r11
00007d5be8fd44b5  sub rsp, 0xF0
00007d5be8fd44bc  vmovaps [rsp], xmm0
00007d5be8fd44c1  vmovaps [rsp+0x10], xmm1
00007d5be8fd44c7  vmovaps [rsp+0x20], xmm2
00007d5be8fd44cd  vmovaps [rsp+0x30], xmm3
00007d5be8fd44d3  vmovaps [rsp+0x40], xmm4
00007d5be8fd44d9  vmovaps [rsp+0x50], xmm5
00007d5be8fd44df  vmovaps [rsp+0x60], xmm6
00007d5be8fd44e5  vmovaps [rsp+0x70], xmm7
00007d5be8fd44eb  vmovaps [rsp+0x80], xmm8
00007d5be8fd44f4  vmovaps [rsp+0x90], xmm9
00007d5be8fd44fd  vmovaps [rsp+0xA0], xmm10
00007d5be8fd4506  vmovaps [rsp+0xB0], xmm12
00007d5be8fd450f  vmovaps [rsp+0xC0], xmm13
00007d5be8fd4518  vmovaps [rsp+0xD0], xmm14
00007d5be8fd4521  vmovaps [rsp+0xE0], xmm15
00007d5be8fd452a  sub rsp, 0x30
00007d5be8fd452e  movaps [rsp], xmm11
00007d5be8fd4533  movaps [rsp+0x10], xmm7
00007d5be8fd4538  movaps [rsp+0x20], xmm15
00007d5be8fd453e  lea rdi, [rsp]
00007d5be8fd4542  mov esi, 0x00
00007d5be8fd4547  mov rax, 0x5D345705A530
00007d5be8fd4551  call rax
00007d5be8fd4553  movaps xmm11, [rsp]
00007d5be8fd4558  add rsp, 0x30
00007d5be8fd455c  vmovaps xmm0, [rsp]
00007d5be8fd4561  vmovaps xmm1, [rsp+0x10]
00007d5be8fd4567  vmovaps xmm2, [rsp+0x20]
00007d5be8fd456d  vmovaps xmm3, [rsp+0x30]
00007d5be8fd4573  vmovaps xmm4, [rsp+0x40]
00007d5be8fd4579  vmovaps xmm5, [rsp+0x50]
00007d5be8fd457f  vmovaps xmm6, [rsp+0x60]
00007d5be8fd4585  vmovaps xmm7, [rsp+0x70]
00007d5be8fd458b  vmovaps xmm8, [rsp+0x80]
00007d5be8fd4594  vmovaps xmm9, [rsp+0x90]
00007d5be8fd459d  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd45a6  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd45af  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd45b8  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd45c1  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd45ca  add rsp, 0xF0
00007d5be8fd45d1  pop r11
00007d5be8fd45d3  pop r10
00007d5be8fd45d5  pop r9
00007d5be8fd45d7  pop r8
00007d5be8fd45d9  pop rsi
00007d5be8fd45da  pop rdi
00007d5be8fd45db  pop rdx
00007d5be8fd45dc  pop rcx
00007d5be8fd45dd  pop rax
00007d5be8fd45de  add rsp, 0x08
00007d5be8fd45e2  jmp 0x00007D5BE8FD0123
00007d5be8fd45e7  sub rsp, 0x08
00007d5be8fd45eb  push rax
00007d5be8fd45ec  push rcx
00007d5be8fd45ed  push rdx
00007d5be8fd45ee  push rdi
00007d5be8fd45ef  push rsi
00007d5be8fd45f0  push r8
00007d5be8fd45f2  push r9
00007d5be8fd45f4  push r10
00007d5be8fd45f6  push r11
00007d5be8fd45f8  sub rsp, 0xF0
00007d5be8fd45ff  vmovaps [rsp], xmm0
00007d5be8fd4604  vmovaps [rsp+0x10], xmm1
00007d5be8fd460a  vmovaps [rsp+0x20], xmm2
00007d5be8fd4610  vmovaps [rsp+0x30], xmm3
00007d5be8fd4616  vmovaps [rsp+0x40], xmm4
00007d5be8fd461c  vmovaps [rsp+0x50], xmm5
00007d5be8fd4622  vmovaps [rsp+0x60], xmm6
00007d5be8fd4628  vmovaps [rsp+0x70], xmm7
00007d5be8fd462e  vmovaps [rsp+0x80], xmm8
00007d5be8fd4637  vmovaps [rsp+0x90], xmm9
00007d5be8fd4640  vmovaps [rsp+0xA0], xmm10
00007d5be8fd4649  vmovaps [rsp+0xB0], xmm11
00007d5be8fd4652  vmovaps [rsp+0xC0], xmm12
00007d5be8fd465b  vmovaps [rsp+0xD0], xmm13
00007d5be8fd4664  vmovaps [rsp+0xE0], xmm14
00007d5be8fd466d  sub rsp, 0x30
00007d5be8fd4671  movaps [rsp], xmm15
00007d5be8fd4676  movaps [rsp+0x10], xmm10
00007d5be8fd467c  movaps [rsp+0x20], xmm13
00007d5be8fd4682  lea rdi, [rsp]
00007d5be8fd4686  mov esi, 0x00
00007d5be8fd468b  mov rax, 0x5D345705A530
00007d5be8fd4695  call rax
00007d5be8fd4697  movaps xmm15, [rsp]
00007d5be8fd469c  add rsp, 0x30
00007d5be8fd46a0  vmovaps xmm0, [rsp]
00007d5be8fd46a5  vmovaps xmm1, [rsp+0x10]
00007d5be8fd46ab  vmovaps xmm2, [rsp+0x20]
00007d5be8fd46b1  vmovaps xmm3, [rsp+0x30]
00007d5be8fd46b7  vmovaps xmm4, [rsp+0x40]
00007d5be8fd46bd  vmovaps xmm5, [rsp+0x50]
00007d5be8fd46c3  vmovaps xmm6, [rsp+0x60]
00007d5be8fd46c9  vmovaps xmm7, [rsp+0x70]
00007d5be8fd46cf  vmovaps xmm8, [rsp+0x80]
00007d5be8fd46d8  vmovaps xmm9, [rsp+0x90]
00007d5be8fd46e1  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd46ea  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd46f3  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd46fc  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd4705  vmovaps xmm14, [rsp+0xE0]
00007d5be8fd470e  add rsp, 0xF0
00007d5be8fd4715  pop r11
00007d5be8fd4717  pop r10
00007d5be8fd4719  pop r9
00007d5be8fd471b  pop r8
00007d5be8fd471d  pop rsi
00007d5be8fd471e  pop rdi
00007d5be8fd471f  pop rdx
00007d5be8fd4720  pop rcx
00007d5be8fd4721  pop rax
00007d5be8fd4722  add rsp, 0x08
00007d5be8fd4726  jmp 0x00007D5BE8FD013D
00007d5be8fd472b  sub rsp, 0x08
00007d5be8fd472f  push rax
00007d5be8fd4730  push rcx
00007d5be8fd4731  push rdx
00007d5be8fd4732  push rdi
00007d5be8fd4733  push rsi
00007d5be8fd4734  push r8
00007d5be8fd4736  push r9
00007d5be8fd4738  push r10
00007d5be8fd473a  push r11
00007d5be8fd473c  sub rsp, 0xF0
00007d5be8fd4743  vmovaps [rsp], xmm0
00007d5be8fd4748  vmovaps [rsp+0x10], xmm1
00007d5be8fd474e  vmovaps [rsp+0x20], xmm2
00007d5be8fd4754  vmovaps [rsp+0x30], xmm3
00007d5be8fd475a  vmovaps [rsp+0x40], xmm4
00007d5be8fd4760  vmovaps [rsp+0x50], xmm5
00007d5be8fd4766  vmovaps [rsp+0x60], xmm6
00007d5be8fd476c  vmovaps [rsp+0x70], xmm7
00007d5be8fd4772  vmovaps [rsp+0x80], xmm8
00007d5be8fd477b  vmovaps [rsp+0x90], xmm9
00007d5be8fd4784  vmovaps [rsp+0xA0], xmm11
00007d5be8fd478d  vmovaps [rsp+0xB0], xmm12
00007d5be8fd4796  vmovaps [rsp+0xC0], xmm13
00007d5be8fd479f  vmovaps [rsp+0xD0], xmm14
00007d5be8fd47a8  vmovaps [rsp+0xE0], xmm15
00007d5be8fd47b1  sub rsp, 0x30
00007d5be8fd47b5  movaps [rsp], xmm10
00007d5be8fd47ba  movaps [rsp+0x10], xmm7
00007d5be8fd47bf  movaps [rsp+0x20], xmm13
00007d5be8fd47c5  lea rdi, [rsp]
00007d5be8fd47c9  mov esi, 0x00
00007d5be8fd47ce  mov rax, 0x5D345705A530
00007d5be8fd47d8  call rax
00007d5be8fd47da  movaps xmm10, [rsp]
00007d5be8fd47df  add rsp, 0x30
00007d5be8fd47e3  vmovaps xmm0, [rsp]
00007d5be8fd47e8  vmovaps xmm1, [rsp+0x10]
00007d5be8fd47ee  vmovaps xmm2, [rsp+0x20]
00007d5be8fd47f4  vmovaps xmm3, [rsp+0x30]
00007d5be8fd47fa  vmovaps xmm4, [rsp+0x40]
00007d5be8fd4800  vmovaps xmm5, [rsp+0x50]
00007d5be8fd4806  vmovaps xmm6, [rsp+0x60]
00007d5be8fd480c  vmovaps xmm7, [rsp+0x70]
00007d5be8fd4812  vmovaps xmm8, [rsp+0x80]
00007d5be8fd481b  vmovaps xmm9, [rsp+0x90]
00007d5be8fd4824  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd482d  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd4836  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd483f  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd4848  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd4851  add rsp, 0xF0
00007d5be8fd4858  pop r11
00007d5be8fd485a  pop r10
00007d5be8fd485c  pop r9
00007d5be8fd485e  pop r8
00007d5be8fd4860  pop rsi
00007d5be8fd4861  pop rdi
00007d5be8fd4862  pop rdx
00007d5be8fd4863  pop rcx
00007d5be8fd4864  pop rax
00007d5be8fd4865  add rsp, 0x08
00007d5be8fd4869  jmp 0x00007D5BE8FD0169
00007d5be8fd486e  sub rsp, 0x08
00007d5be8fd4872  push rax
00007d5be8fd4873  push rcx
00007d5be8fd4874  push rdx
00007d5be8fd4875  push rdi
00007d5be8fd4876  push rsi
00007d5be8fd4877  push r8
00007d5be8fd4879  push r9
00007d5be8fd487b  push r10
00007d5be8fd487d  push r11
00007d5be8fd487f  sub rsp, 0xF0
00007d5be8fd4886  vmovaps [rsp], xmm0
00007d5be8fd488b  vmovaps [rsp+0x10], xmm1
00007d5be8fd4891  vmovaps [rsp+0x20], xmm2
00007d5be8fd4897  vmovaps [rsp+0x30], xmm3
00007d5be8fd489d  vmovaps [rsp+0x40], xmm4
00007d5be8fd48a3  vmovaps [rsp+0x50], xmm5
00007d5be8fd48a9  vmovaps [rsp+0x60], xmm6
00007d5be8fd48af  vmovaps [rsp+0x70], xmm7
00007d5be8fd48b5  vmovaps [rsp+0x80], xmm8
00007d5be8fd48be  vmovaps [rsp+0x90], xmm9
00007d5be8fd48c7  vmovaps [rsp+0xA0], xmm10
00007d5be8fd48d0  vmovaps [rsp+0xB0], xmm11
00007d5be8fd48d9  vmovaps [rsp+0xC0], xmm12
00007d5be8fd48e2  vmovaps [rsp+0xD0], xmm14
00007d5be8fd48eb  vmovaps [rsp+0xE0], xmm15
00007d5be8fd48f4  sub rsp, 0x30
00007d5be8fd48f8  movaps [rsp], xmm13
00007d5be8fd48fd  movaps [rsp+0x10], xmm1
00007d5be8fd4902  movaps [rsp+0x20], xmm8
00007d5be8fd4908  lea rdi, [rsp]
00007d5be8fd490c  mov esi, 0x00
00007d5be8fd4911  mov rax, 0x5D345705A530
00007d5be8fd491b  call rax
00007d5be8fd491d  movaps xmm13, [rsp]
00007d5be8fd4922  add rsp, 0x30
00007d5be8fd4926  vmovaps xmm0, [rsp]
00007d5be8fd492b  vmovaps xmm1, [rsp+0x10]
00007d5be8fd4931  vmovaps xmm2, [rsp+0x20]
00007d5be8fd4937  vmovaps xmm3, [rsp+0x30]
00007d5be8fd493d  vmovaps xmm4, [rsp+0x40]
00007d5be8fd4943  vmovaps xmm5, [rsp+0x50]
00007d5be8fd4949  vmovaps xmm6, [rsp+0x60]
00007d5be8fd494f  vmovaps xmm7, [rsp+0x70]
00007d5be8fd4955  vmovaps xmm8, [rsp+0x80]
00007d5be8fd495e  vmovaps xmm9, [rsp+0x90]
00007d5be8fd4967  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd4970  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd4979  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd4982  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd498b  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd4994  add rsp, 0xF0
00007d5be8fd499b  pop r11
00007d5be8fd499d  pop r10
00007d5be8fd499f  pop r9
00007d5be8fd49a1  pop r8
00007d5be8fd49a3  pop rsi
00007d5be8fd49a4  pop rdi
00007d5be8fd49a5  pop rdx
00007d5be8fd49a6  pop rcx
00007d5be8fd49a7  pop rax
00007d5be8fd49a8  add rsp, 0x08
00007d5be8fd49ac  jmp 0x00007D5BE8FD0183
00007d5be8fd49b1  call 0x00007D5BE8DFF430
00007d5be8fd49b6  jmp 0x00007D5BE8FD018D
00007d5be8fd49bb  sub rsp, 0x08
00007d5be8fd49bf  push rax
00007d5be8fd49c0  push rcx
00007d5be8fd49c1  push rdx
00007d5be8fd49c2  push rdi
00007d5be8fd49c3  push rsi
00007d5be8fd49c4  push r8
00007d5be8fd49c6  push r9
00007d5be8fd49c8  push r10
00007d5be8fd49ca  push r11
00007d5be8fd49cc  sub rsp, 0xF0
00007d5be8fd49d3  vmovaps [rsp], xmm0
00007d5be8fd49d8  vmovaps [rsp+0x10], xmm1
00007d5be8fd49de  vmovaps [rsp+0x20], xmm2
00007d5be8fd49e4  vmovaps [rsp+0x30], xmm3
00007d5be8fd49ea  vmovaps [rsp+0x40], xmm4
00007d5be8fd49f0  vmovaps [rsp+0x50], xmm5
00007d5be8fd49f6  vmovaps [rsp+0x60], xmm6
00007d5be8fd49fc  vmovaps [rsp+0x70], xmm7
00007d5be8fd4a02  vmovaps [rsp+0x80], xmm9
00007d5be8fd4a0b  vmovaps [rsp+0x90], xmm10
00007d5be8fd4a14  vmovaps [rsp+0xA0], xmm11
00007d5be8fd4a1d  vmovaps [rsp+0xB0], xmm12
00007d5be8fd4a26  vmovaps [rsp+0xC0], xmm13
00007d5be8fd4a2f  vmovaps [rsp+0xD0], xmm14
00007d5be8fd4a38  vmovaps [rsp+0xE0], xmm15
00007d5be8fd4a41  sub rsp, 0x30
00007d5be8fd4a45  movaps [rsp], xmm8
00007d5be8fd4a4a  movaps [rsp+0x10], xmm14
00007d5be8fd4a50  movaps [rsp+0x20], xmm9
00007d5be8fd4a56  lea rdi, [rsp]
00007d5be8fd4a5a  mov esi, 0x00
00007d5be8fd4a5f  mov rax, 0x5D345705A530
00007d5be8fd4a69  call rax
00007d5be8fd4a6b  movaps xmm8, [rsp]
00007d5be8fd4a70  add rsp, 0x30
00007d5be8fd4a74  vmovaps xmm0, [rsp]
00007d5be8fd4a79  vmovaps xmm1, [rsp+0x10]
00007d5be8fd4a7f  vmovaps xmm2, [rsp+0x20]
00007d5be8fd4a85  vmovaps xmm3, [rsp+0x30]
00007d5be8fd4a8b  vmovaps xmm4, [rsp+0x40]
00007d5be8fd4a91  vmovaps xmm5, [rsp+0x50]
00007d5be8fd4a97  vmovaps xmm6, [rsp+0x60]
00007d5be8fd4a9d  vmovaps xmm7, [rsp+0x70]
00007d5be8fd4aa3  vmovaps xmm9, [rsp+0x80]
00007d5be8fd4aac  vmovaps xmm10, [rsp+0x90]
00007d5be8fd4ab5  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd4abe  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd4ac7  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd4ad0  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd4ad9  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd4ae2  add rsp, 0xF0
00007d5be8fd4ae9  pop r11
00007d5be8fd4aeb  pop r10
00007d5be8fd4aed  pop r9
00007d5be8fd4aef  pop r8
00007d5be8fd4af1  pop rsi
00007d5be8fd4af2  pop rdi
00007d5be8fd4af3  pop rdx
00007d5be8fd4af4  pop rcx
00007d5be8fd4af5  pop rax
00007d5be8fd4af6  add rsp, 0x08
00007d5be8fd4afa  jmp 0x00007D5BE8FD01AF
00007d5be8fd4aff  sub rsp, 0x08
00007d5be8fd4b03  push rax
00007d5be8fd4b04  push rcx
00007d5be8fd4b05  push rdx
00007d5be8fd4b06  push rdi
00007d5be8fd4b07  push rsi
00007d5be8fd4b08  push r8
00007d5be8fd4b0a  push r9
00007d5be8fd4b0c  push r10
00007d5be8fd4b0e  push r11
00007d5be8fd4b10  sub rsp, 0xF0
00007d5be8fd4b17  vmovaps [rsp], xmm0
00007d5be8fd4b1c  vmovaps [rsp+0x10], xmm1
00007d5be8fd4b22  vmovaps [rsp+0x20], xmm2
00007d5be8fd4b28  vmovaps [rsp+0x30], xmm3
00007d5be8fd4b2e  vmovaps [rsp+0x40], xmm4
00007d5be8fd4b34  vmovaps [rsp+0x50], xmm5
00007d5be8fd4b3a  vmovaps [rsp+0x60], xmm6
00007d5be8fd4b40  vmovaps [rsp+0x70], xmm7
00007d5be8fd4b46  vmovaps [rsp+0x80], xmm8
00007d5be8fd4b4f  vmovaps [rsp+0x90], xmm10
00007d5be8fd4b58  vmovaps [rsp+0xA0], xmm11
00007d5be8fd4b61  vmovaps [rsp+0xB0], xmm12
00007d5be8fd4b6a  vmovaps [rsp+0xC0], xmm13
00007d5be8fd4b73  vmovaps [rsp+0xD0], xmm14
00007d5be8fd4b7c  vmovaps [rsp+0xE0], xmm15
00007d5be8fd4b85  sub rsp, 0x30
00007d5be8fd4b89  movaps [rsp], xmm9
00007d5be8fd4b8e  movaps [rsp+0x10], xmm1
00007d5be8fd4b93  movaps [rsp+0x20], xmm14
00007d5be8fd4b99  lea rdi, [rsp]
00007d5be8fd4b9d  mov esi, 0x00
00007d5be8fd4ba2  mov rax, 0x5D345705A530
00007d5be8fd4bac  call rax
00007d5be8fd4bae  movaps xmm9, [rsp]
00007d5be8fd4bb3  add rsp, 0x30
00007d5be8fd4bb7  vmovaps xmm0, [rsp]
00007d5be8fd4bbc  vmovaps xmm1, [rsp+0x10]
00007d5be8fd4bc2  vmovaps xmm2, [rsp+0x20]
00007d5be8fd4bc8  vmovaps xmm3, [rsp+0x30]
00007d5be8fd4bce  vmovaps xmm4, [rsp+0x40]
00007d5be8fd4bd4  vmovaps xmm5, [rsp+0x50]
00007d5be8fd4bda  vmovaps xmm6, [rsp+0x60]
00007d5be8fd4be0  vmovaps xmm7, [rsp+0x70]
00007d5be8fd4be6  vmovaps xmm8, [rsp+0x80]
00007d5be8fd4bef  vmovaps xmm10, [rsp+0x90]
00007d5be8fd4bf8  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd4c01  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd4c0a  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd4c13  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd4c1c  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd4c25  add rsp, 0xF0
00007d5be8fd4c2c  pop r11
00007d5be8fd4c2e  pop r10
00007d5be8fd4c30  pop r9
00007d5be8fd4c32  pop r8
00007d5be8fd4c34  pop rsi
00007d5be8fd4c35  pop rdi
00007d5be8fd4c36  pop rdx
00007d5be8fd4c37  pop rcx
00007d5be8fd4c38  pop rax
00007d5be8fd4c39  add rsp, 0x08
00007d5be8fd4c3d  jmp 0x00007D5BE8FD01DD
00007d5be8fd4c42  sub rsp, 0x08
00007d5be8fd4c46  push rax
00007d5be8fd4c47  push rcx
00007d5be8fd4c48  push rdx
00007d5be8fd4c49  push rdi
00007d5be8fd4c4a  push rsi
00007d5be8fd4c4b  push r8
00007d5be8fd4c4d  push r9
00007d5be8fd4c4f  push r10
00007d5be8fd4c51  push r11
00007d5be8fd4c53  sub rsp, 0xF0
00007d5be8fd4c5a  vmovaps [rsp], xmm0
00007d5be8fd4c5f  vmovaps [rsp+0x10], xmm1
00007d5be8fd4c65  vmovaps [rsp+0x20], xmm2
00007d5be8fd4c6b  vmovaps [rsp+0x30], xmm3
00007d5be8fd4c71  vmovaps [rsp+0x40], xmm4
00007d5be8fd4c77  vmovaps [rsp+0x50], xmm5
00007d5be8fd4c7d  vmovaps [rsp+0x60], xmm6
00007d5be8fd4c83  vmovaps [rsp+0x70], xmm7
00007d5be8fd4c89  vmovaps [rsp+0x80], xmm8
00007d5be8fd4c92  vmovaps [rsp+0x90], xmm9
00007d5be8fd4c9b  vmovaps [rsp+0xA0], xmm10
00007d5be8fd4ca4  vmovaps [rsp+0xB0], xmm11
00007d5be8fd4cad  vmovaps [rsp+0xC0], xmm12
00007d5be8fd4cb6  vmovaps [rsp+0xD0], xmm13
00007d5be8fd4cbf  vmovaps [rsp+0xE0], xmm15
00007d5be8fd4cc8  sub rsp, 0x30
00007d5be8fd4ccc  movaps [rsp], xmm14
00007d5be8fd4cd1  movaps [rsp+0x10], xmm4
00007d5be8fd4cd6  movaps [rsp+0x20], xmm1
00007d5be8fd4cdb  lea rdi, [rsp]
00007d5be8fd4cdf  mov esi, 0x00
00007d5be8fd4ce4  mov rax, 0x5D345705A530
00007d5be8fd4cee  call rax
00007d5be8fd4cf0  movaps xmm14, [rsp]
00007d5be8fd4cf5  add rsp, 0x30
00007d5be8fd4cf9  vmovaps xmm0, [rsp]
00007d5be8fd4cfe  vmovaps xmm1, [rsp+0x10]
00007d5be8fd4d04  vmovaps xmm2, [rsp+0x20]
00007d5be8fd4d0a  vmovaps xmm3, [rsp+0x30]
00007d5be8fd4d10  vmovaps xmm4, [rsp+0x40]
00007d5be8fd4d16  vmovaps xmm5, [rsp+0x50]
00007d5be8fd4d1c  vmovaps xmm6, [rsp+0x60]
00007d5be8fd4d22  vmovaps xmm7, [rsp+0x70]
00007d5be8fd4d28  vmovaps xmm8, [rsp+0x80]
00007d5be8fd4d31  vmovaps xmm9, [rsp+0x90]
00007d5be8fd4d3a  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd4d43  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd4d4c  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd4d55  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd4d5e  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd4d67  add rsp, 0xF0
00007d5be8fd4d6e  pop r11
00007d5be8fd4d70  pop r10
00007d5be8fd4d72  pop r9
00007d5be8fd4d74  pop r8
00007d5be8fd4d76  pop rsi
00007d5be8fd4d77  pop rdi
00007d5be8fd4d78  pop rdx
00007d5be8fd4d79  pop rcx
00007d5be8fd4d7a  pop rax
00007d5be8fd4d7b  add rsp, 0x08
00007d5be8fd4d7f  jmp 0x00007D5BE8FD0203
00007d5be8fd4d84  sub rsp, 0x08
00007d5be8fd4d88  push rax
00007d5be8fd4d89  push rcx
00007d5be8fd4d8a  push rdx
00007d5be8fd4d8b  push rdi
00007d5be8fd4d8c  push rsi
00007d5be8fd4d8d  push r8
00007d5be8fd4d8f  push r9
00007d5be8fd4d91  push r10
00007d5be8fd4d93  push r11
00007d5be8fd4d95  sub rsp, 0xF0
00007d5be8fd4d9c  vmovaps [rsp], xmm0
00007d5be8fd4da1  vmovaps [rsp+0x10], xmm2
00007d5be8fd4da7  vmovaps [rsp+0x20], xmm3
00007d5be8fd4dad  vmovaps [rsp+0x30], xmm4
00007d5be8fd4db3  vmovaps [rsp+0x40], xmm5
00007d5be8fd4db9  vmovaps [rsp+0x50], xmm6
00007d5be8fd4dbf  vmovaps [rsp+0x60], xmm7
00007d5be8fd4dc5  vmovaps [rsp+0x70], xmm8
00007d5be8fd4dcb  vmovaps [rsp+0x80], xmm9
00007d5be8fd4dd4  vmovaps [rsp+0x90], xmm10
00007d5be8fd4ddd  vmovaps [rsp+0xA0], xmm11
00007d5be8fd4de6  vmovaps [rsp+0xB0], xmm12
00007d5be8fd4def  vmovaps [rsp+0xC0], xmm13
00007d5be8fd4df8  vmovaps [rsp+0xD0], xmm14
00007d5be8fd4e01  vmovaps [rsp+0xE0], xmm15
00007d5be8fd4e0a  sub rsp, 0x30
00007d5be8fd4e0e  movaps [rsp], xmm1
00007d5be8fd4e12  movaps [rsp+0x10], xmm12
00007d5be8fd4e18  movaps [rsp+0x20], xmm11
00007d5be8fd4e1e  lea rdi, [rsp]
00007d5be8fd4e22  mov esi, 0x00
00007d5be8fd4e27  mov rax, 0x5D345705A530
00007d5be8fd4e31  call rax
00007d5be8fd4e33  movaps xmm1, [rsp]
00007d5be8fd4e37  add rsp, 0x30
00007d5be8fd4e3b  vmovaps xmm0, [rsp]
00007d5be8fd4e40  vmovaps xmm2, [rsp+0x10]
00007d5be8fd4e46  vmovaps xmm3, [rsp+0x20]
00007d5be8fd4e4c  vmovaps xmm4, [rsp+0x30]
00007d5be8fd4e52  vmovaps xmm5, [rsp+0x40]
00007d5be8fd4e58  vmovaps xmm6, [rsp+0x50]
00007d5be8fd4e5e  vmovaps xmm7, [rsp+0x60]
00007d5be8fd4e64  vmovaps xmm8, [rsp+0x70]
00007d5be8fd4e6a  vmovaps xmm9, [rsp+0x80]
00007d5be8fd4e73  vmovaps xmm10, [rsp+0x90]
00007d5be8fd4e7c  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd4e85  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd4e8e  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd4e97  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd4ea0  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd4ea9  add rsp, 0xF0
00007d5be8fd4eb0  pop r11
00007d5be8fd4eb2  pop r10
00007d5be8fd4eb4  pop r9
00007d5be8fd4eb6  pop r8
00007d5be8fd4eb8  pop rsi
00007d5be8fd4eb9  pop rdi
00007d5be8fd4eba  pop rdx
00007d5be8fd4ebb  pop rcx
00007d5be8fd4ebc  pop rax
00007d5be8fd4ebd  add rsp, 0x08
00007d5be8fd4ec1  jmp 0x00007D5BE8FD0224
00007d5be8fd4ec6  call 0x00007D5BE8EE20A0
00007d5be8fd4ecb  jmp 0x00007D5BE8FD0232
00007d5be8fd4ed0  call 0x00007D5BE8E09D70
00007d5be8fd4ed5  jmp 0x00007D5BE8FD023C
00007d5be8fd4eda  sub rsp, 0x08
00007d5be8fd4ede  push rax
00007d5be8fd4edf  push rcx
00007d5be8fd4ee0  push rdx
00007d5be8fd4ee1  push rdi
00007d5be8fd4ee2  push rsi
00007d5be8fd4ee3  push r8
00007d5be8fd4ee5  push r9
00007d5be8fd4ee7  push r10
00007d5be8fd4ee9  push r11
00007d5be8fd4eeb  sub rsp, 0xF0
00007d5be8fd4ef2  vmovaps [rsp], xmm0
00007d5be8fd4ef7  vmovaps [rsp+0x10], xmm1
00007d5be8fd4efd  vmovaps [rsp+0x20], xmm2
00007d5be8fd4f03  vmovaps [rsp+0x30], xmm3
00007d5be8fd4f09  vmovaps [rsp+0x40], xmm4
00007d5be8fd4f0f  vmovaps [rsp+0x50], xmm5
00007d5be8fd4f15  vmovaps [rsp+0x60], xmm6
00007d5be8fd4f1b  vmovaps [rsp+0x70], xmm8
00007d5be8fd4f21  vmovaps [rsp+0x80], xmm9
00007d5be8fd4f2a  vmovaps [rsp+0x90], xmm10
00007d5be8fd4f33  vmovaps [rsp+0xA0], xmm11
00007d5be8fd4f3c  vmovaps [rsp+0xB0], xmm12
00007d5be8fd4f45  vmovaps [rsp+0xC0], xmm13
00007d5be8fd4f4e  vmovaps [rsp+0xD0], xmm14
00007d5be8fd4f57  vmovaps [rsp+0xE0], xmm15
00007d5be8fd4f60  sub rsp, 0x30
00007d5be8fd4f64  movaps [rsp], xmm7
00007d5be8fd4f68  movaps [rsp+0x10], xmm15
00007d5be8fd4f6e  movaps [rsp+0x20], xmm10
00007d5be8fd4f74  lea rdi, [rsp]
00007d5be8fd4f78  mov esi, 0x00
00007d5be8fd4f7d  mov rax, 0x5D345705A530
00007d5be8fd4f87  call rax
00007d5be8fd4f89  movaps xmm7, [rsp]
00007d5be8fd4f8d  add rsp, 0x30
00007d5be8fd4f91  vmovaps xmm0, [rsp]
00007d5be8fd4f96  vmovaps xmm1, [rsp+0x10]
00007d5be8fd4f9c  vmovaps xmm2, [rsp+0x20]
00007d5be8fd4fa2  vmovaps xmm3, [rsp+0x30]
00007d5be8fd4fa8  vmovaps xmm4, [rsp+0x40]
00007d5be8fd4fae  vmovaps xmm5, [rsp+0x50]
00007d5be8fd4fb4  vmovaps xmm6, [rsp+0x60]
00007d5be8fd4fba  vmovaps xmm8, [rsp+0x70]
00007d5be8fd4fc0  vmovaps xmm9, [rsp+0x80]
00007d5be8fd4fc9  vmovaps xmm10, [rsp+0x90]
00007d5be8fd4fd2  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd4fdb  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd4fe4  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd4fed  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd4ff6  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd4fff  add rsp, 0xF0
00007d5be8fd5006  pop r11
00007d5be8fd5008  pop r10
00007d5be8fd500a  pop r9
00007d5be8fd500c  pop r8
00007d5be8fd500e  pop rsi
00007d5be8fd500f  pop rdi
00007d5be8fd5010  pop rdx
00007d5be8fd5011  pop rcx
00007d5be8fd5012  pop rax
00007d5be8fd5013  add rsp, 0x08
00007d5be8fd5017  jmp 0x00007D5BE8FD025D
00007d5be8fd501c  sub rsp, 0x08
00007d5be8fd5020  push rax
00007d5be8fd5021  push rcx
00007d5be8fd5022  push rdx
00007d5be8fd5023  push rdi
00007d5be8fd5024  push rsi
00007d5be8fd5025  push r8
00007d5be8fd5027  push r9
00007d5be8fd5029  push r10
00007d5be8fd502b  push r11
00007d5be8fd502d  sub rsp, 0xF0
00007d5be8fd5034  vmovaps [rsp], xmm0
00007d5be8fd5039  vmovaps [rsp+0x10], xmm1
00007d5be8fd503f  vmovaps [rsp+0x20], xmm2
00007d5be8fd5045  vmovaps [rsp+0x30], xmm3
00007d5be8fd504b  vmovaps [rsp+0x40], xmm4
00007d5be8fd5051  vmovaps [rsp+0x50], xmm5
00007d5be8fd5057  vmovaps [rsp+0x60], xmm6
00007d5be8fd505d  vmovaps [rsp+0x70], xmm7
00007d5be8fd5063  vmovaps [rsp+0x80], xmm8
00007d5be8fd506c  vmovaps [rsp+0x90], xmm9
00007d5be8fd5075  vmovaps [rsp+0xA0], xmm11
00007d5be8fd507e  vmovaps [rsp+0xB0], xmm12
00007d5be8fd5087  vmovaps [rsp+0xC0], xmm13
00007d5be8fd5090  vmovaps [rsp+0xD0], xmm14
00007d5be8fd5099  vmovaps [rsp+0xE0], xmm15
00007d5be8fd50a2  sub rsp, 0x30
00007d5be8fd50a6  movaps [rsp], xmm10
00007d5be8fd50ab  movaps [rsp+0x10], xmm11
00007d5be8fd50b1  movaps [rsp+0x20], xmm15
00007d5be8fd50b7  lea rdi, [rsp]
00007d5be8fd50bb  mov esi, 0x00
00007d5be8fd50c0  mov rax, 0x5D345705A530
00007d5be8fd50ca  call rax
00007d5be8fd50cc  movaps xmm10, [rsp]
00007d5be8fd50d1  add rsp, 0x30
00007d5be8fd50d5  vmovaps xmm0, [rsp]
00007d5be8fd50da  vmovaps xmm1, [rsp+0x10]
00007d5be8fd50e0  vmovaps xmm2, [rsp+0x20]
00007d5be8fd50e6  vmovaps xmm3, [rsp+0x30]
00007d5be8fd50ec  vmovaps xmm4, [rsp+0x40]
00007d5be8fd50f2  vmovaps xmm5, [rsp+0x50]
00007d5be8fd50f8  vmovaps xmm6, [rsp+0x60]
00007d5be8fd50fe  vmovaps xmm7, [rsp+0x70]
00007d5be8fd5104  vmovaps xmm8, [rsp+0x80]
00007d5be8fd510d  vmovaps xmm9, [rsp+0x90]
00007d5be8fd5116  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd511f  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd5128  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd5131  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd513a  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd5143  add rsp, 0xF0
00007d5be8fd514a  pop r11
00007d5be8fd514c  pop r10
00007d5be8fd514e  pop r9
00007d5be8fd5150  pop r8
00007d5be8fd5152  pop rsi
00007d5be8fd5153  pop rdi
00007d5be8fd5154  pop rdx
00007d5be8fd5155  pop rcx
00007d5be8fd5156  pop rax
00007d5be8fd5157  add rsp, 0x08
00007d5be8fd515b  jmp 0x00007D5BE8FD028B
00007d5be8fd5160  sub rsp, 0x08
00007d5be8fd5164  push rax
00007d5be8fd5165  push rcx
00007d5be8fd5166  push rdx
00007d5be8fd5167  push rdi
00007d5be8fd5168  push rsi
00007d5be8fd5169  push r8
00007d5be8fd516b  push r9
00007d5be8fd516d  push r10
00007d5be8fd516f  push r11
00007d5be8fd5171  sub rsp, 0xF0
00007d5be8fd5178  vmovaps [rsp], xmm0
00007d5be8fd517d  vmovaps [rsp+0x10], xmm1
00007d5be8fd5183  vmovaps [rsp+0x20], xmm2
00007d5be8fd5189  vmovaps [rsp+0x30], xmm3
00007d5be8fd518f  vmovaps [rsp+0x40], xmm4
00007d5be8fd5195  vmovaps [rsp+0x50], xmm5
00007d5be8fd519b  vmovaps [rsp+0x60], xmm6
00007d5be8fd51a1  vmovaps [rsp+0x70], xmm7
00007d5be8fd51a7  vmovaps [rsp+0x80], xmm8
00007d5be8fd51b0  vmovaps [rsp+0x90], xmm9
00007d5be8fd51b9  vmovaps [rsp+0xA0], xmm10
00007d5be8fd51c2  vmovaps [rsp+0xB0], xmm12
00007d5be8fd51cb  vmovaps [rsp+0xC0], xmm13
00007d5be8fd51d4  vmovaps [rsp+0xD0], xmm14
00007d5be8fd51dd  vmovaps [rsp+0xE0], xmm15
00007d5be8fd51e6  sub rsp, 0x30
00007d5be8fd51ea  movaps [rsp], xmm11
00007d5be8fd51ef  movaps [rsp+0x10], xmm12
00007d5be8fd51f5  movaps [rsp+0x20], xmm15
00007d5be8fd51fb  lea rdi, [rsp]
00007d5be8fd51ff  mov esi, 0x00
00007d5be8fd5204  mov rax, 0x5D345705A530
00007d5be8fd520e  call rax
00007d5be8fd5210  movaps xmm11, [rsp]
00007d5be8fd5215  add rsp, 0x30
00007d5be8fd5219  vmovaps xmm0, [rsp]
00007d5be8fd521e  vmovaps xmm1, [rsp+0x10]
00007d5be8fd5224  vmovaps xmm2, [rsp+0x20]
00007d5be8fd522a  vmovaps xmm3, [rsp+0x30]
00007d5be8fd5230  vmovaps xmm4, [rsp+0x40]
00007d5be8fd5236  vmovaps xmm5, [rsp+0x50]
00007d5be8fd523c  vmovaps xmm6, [rsp+0x60]
00007d5be8fd5242  vmovaps xmm7, [rsp+0x70]
00007d5be8fd5248  vmovaps xmm8, [rsp+0x80]
00007d5be8fd5251  vmovaps xmm9, [rsp+0x90]
00007d5be8fd525a  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd5263  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd526c  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd5275  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd527e  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd5287  add rsp, 0xF0
00007d5be8fd528e  pop r11
00007d5be8fd5290  pop r10
00007d5be8fd5292  pop r9
00007d5be8fd5294  pop r8
00007d5be8fd5296  pop rsi
00007d5be8fd5297  pop rdi
00007d5be8fd5298  pop rdx
00007d5be8fd5299  pop rcx
00007d5be8fd529a  pop rax
00007d5be8fd529b  add rsp, 0x08
00007d5be8fd529f  jmp 0x00007D5BE8FD02B9
00007d5be8fd52a4  sub rsp, 0x08
00007d5be8fd52a8  push rax
00007d5be8fd52a9  push rcx
00007d5be8fd52aa  push rdx
00007d5be8fd52ab  push rdi
00007d5be8fd52ac  push rsi
00007d5be8fd52ad  push r8
00007d5be8fd52af  push r9
00007d5be8fd52b1  push r10
00007d5be8fd52b3  push r11
00007d5be8fd52b5  sub rsp, 0xF0
00007d5be8fd52bc  vmovaps [rsp], xmm0
00007d5be8fd52c1  vmovaps [rsp+0x10], xmm1
00007d5be8fd52c7  vmovaps [rsp+0x20], xmm2
00007d5be8fd52cd  vmovaps [rsp+0x30], xmm3
00007d5be8fd52d3  vmovaps [rsp+0x40], xmm4
00007d5be8fd52d9  vmovaps [rsp+0x50], xmm5
00007d5be8fd52df  vmovaps [rsp+0x60], xmm6
00007d5be8fd52e5  vmovaps [rsp+0x70], xmm7
00007d5be8fd52eb  vmovaps [rsp+0x80], xmm8
00007d5be8fd52f4  vmovaps [rsp+0x90], xmm9
00007d5be8fd52fd  vmovaps [rsp+0xA0], xmm10
00007d5be8fd5306  vmovaps [rsp+0xB0], xmm11
00007d5be8fd530f  vmovaps [rsp+0xC0], xmm12
00007d5be8fd5318  vmovaps [rsp+0xD0], xmm13
00007d5be8fd5321  vmovaps [rsp+0xE0], xmm14
00007d5be8fd532a  sub rsp, 0x30
00007d5be8fd532e  movaps [rsp], xmm15
00007d5be8fd5333  movaps [rsp+0x10], xmm13
00007d5be8fd5339  movaps [rsp+0x20], xmm9
00007d5be8fd533f  lea rdi, [rsp]
00007d5be8fd5343  mov esi, 0x00
00007d5be8fd5348  mov rax, 0x5D345705A530
00007d5be8fd5352  call rax
00007d5be8fd5354  movaps xmm15, [rsp]
00007d5be8fd5359  add rsp, 0x30
00007d5be8fd535d  vmovaps xmm0, [rsp]
00007d5be8fd5362  vmovaps xmm1, [rsp+0x10]
00007d5be8fd5368  vmovaps xmm2, [rsp+0x20]
00007d5be8fd536e  vmovaps xmm3, [rsp+0x30]
00007d5be8fd5374  vmovaps xmm4, [rsp+0x40]
00007d5be8fd537a  vmovaps xmm5, [rsp+0x50]
00007d5be8fd5380  vmovaps xmm6, [rsp+0x60]
00007d5be8fd5386  vmovaps xmm7, [rsp+0x70]
00007d5be8fd538c  vmovaps xmm8, [rsp+0x80]
00007d5be8fd5395  vmovaps xmm9, [rsp+0x90]
00007d5be8fd539e  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd53a7  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd53b0  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd53b9  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd53c2  vmovaps xmm14, [rsp+0xE0]
00007d5be8fd53cb  add rsp, 0xF0
00007d5be8fd53d2  pop r11
00007d5be8fd53d4  pop r10
00007d5be8fd53d6  pop r9
00007d5be8fd53d8  pop r8
00007d5be8fd53da  pop rsi
00007d5be8fd53db  pop rdi
00007d5be8fd53dc  pop rdx
00007d5be8fd53dd  pop rcx
00007d5be8fd53de  pop rax
00007d5be8fd53df  add rsp, 0x08
00007d5be8fd53e3  jmp 0x00007D5BE8FD02D4
00007d5be8fd53e8  sub rsp, 0x08
00007d5be8fd53ec  push rax
00007d5be8fd53ed  push rcx
00007d5be8fd53ee  push rdx
00007d5be8fd53ef  push rdi
00007d5be8fd53f0  push rsi
00007d5be8fd53f1  push r8
00007d5be8fd53f3  push r9
00007d5be8fd53f5  push r10
00007d5be8fd53f7  push r11
00007d5be8fd53f9  sub rsp, 0xF0
00007d5be8fd5400  vmovaps [rsp], xmm0
00007d5be8fd5405  vmovaps [rsp+0x10], xmm1
00007d5be8fd540b  vmovaps [rsp+0x20], xmm2
00007d5be8fd5411  vmovaps [rsp+0x30], xmm3
00007d5be8fd5417  vmovaps [rsp+0x40], xmm4
00007d5be8fd541d  vmovaps [rsp+0x50], xmm5
00007d5be8fd5423  vmovaps [rsp+0x60], xmm6
00007d5be8fd5429  vmovaps [rsp+0x70], xmm7
00007d5be8fd542f  vmovaps [rsp+0x80], xmm8
00007d5be8fd5438  vmovaps [rsp+0x90], xmm9
00007d5be8fd5441  vmovaps [rsp+0xA0], xmm10
00007d5be8fd544a  vmovaps [rsp+0xB0], xmm11
00007d5be8fd5453  vmovaps [rsp+0xC0], xmm12
00007d5be8fd545c  vmovaps [rsp+0xD0], xmm14
00007d5be8fd5465  vmovaps [rsp+0xE0], xmm15
00007d5be8fd546e  sub rsp, 0x30
00007d5be8fd5472  movaps [rsp], xmm13
00007d5be8fd5477  movaps [rsp+0x10], xmm8
00007d5be8fd547d  movaps [rsp+0x20], xmm14
00007d5be8fd5483  lea rdi, [rsp]
00007d5be8fd5487  mov esi, 0x00
00007d5be8fd548c  mov rax, 0x5D345705A530
00007d5be8fd5496  call rax
00007d5be8fd5498  movaps xmm13, [rsp]
00007d5be8fd549d  add rsp, 0x30
00007d5be8fd54a1  vmovaps xmm0, [rsp]
00007d5be8fd54a6  vmovaps xmm1, [rsp+0x10]
00007d5be8fd54ac  vmovaps xmm2, [rsp+0x20]
00007d5be8fd54b2  vmovaps xmm3, [rsp+0x30]
00007d5be8fd54b8  vmovaps xmm4, [rsp+0x40]
00007d5be8fd54be  vmovaps xmm5, [rsp+0x50]
00007d5be8fd54c4  vmovaps xmm6, [rsp+0x60]
00007d5be8fd54ca  vmovaps xmm7, [rsp+0x70]
00007d5be8fd54d0  vmovaps xmm8, [rsp+0x80]
00007d5be8fd54d9  vmovaps xmm9, [rsp+0x90]
00007d5be8fd54e2  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd54eb  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd54f4  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd54fd  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd5506  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd550f  add rsp, 0xF0
00007d5be8fd5516  pop r11
00007d5be8fd5518  pop r10
00007d5be8fd551a  pop r9
00007d5be8fd551c  pop r8
00007d5be8fd551e  pop rsi
00007d5be8fd551f  pop rdi
00007d5be8fd5520  pop rdx
00007d5be8fd5521  pop rcx
00007d5be8fd5522  pop rax
00007d5be8fd5523  add rsp, 0x08
00007d5be8fd5527  jmp 0x00007D5BE8FD02F7
00007d5be8fd552c  sub rsp, 0x08
00007d5be8fd5530  push rax
00007d5be8fd5531  push rcx
00007d5be8fd5532  push rdx
00007d5be8fd5533  push rdi
00007d5be8fd5534  push rsi
00007d5be8fd5535  push r8
00007d5be8fd5537  push r9
00007d5be8fd5539  push r10
00007d5be8fd553b  push r11
00007d5be8fd553d  sub rsp, 0xF0
00007d5be8fd5544  vmovaps [rsp], xmm0
00007d5be8fd5549  vmovaps [rsp+0x10], xmm1
00007d5be8fd554f  vmovaps [rsp+0x20], xmm2
00007d5be8fd5555  vmovaps [rsp+0x30], xmm3
00007d5be8fd555b  vmovaps [rsp+0x40], xmm4
00007d5be8fd5561  vmovaps [rsp+0x50], xmm5
00007d5be8fd5567  vmovaps [rsp+0x60], xmm6
00007d5be8fd556d  vmovaps [rsp+0x70], xmm7
00007d5be8fd5573  vmovaps [rsp+0x80], xmm8
00007d5be8fd557c  vmovaps [rsp+0x90], xmm9
00007d5be8fd5585  vmovaps [rsp+0xA0], xmm10
00007d5be8fd558e  vmovaps [rsp+0xB0], xmm11
00007d5be8fd5597  vmovaps [rsp+0xC0], xmm12
00007d5be8fd55a0  vmovaps [rsp+0xD0], xmm13
00007d5be8fd55a9  vmovaps [rsp+0xE0], xmm15
00007d5be8fd55b2  sub rsp, 0x30
00007d5be8fd55b6  movaps [rsp], xmm14
00007d5be8fd55bb  movaps [rsp+0x10], xmm1
00007d5be8fd55c0  movaps [rsp+0x20], xmm10
00007d5be8fd55c6  lea rdi, [rsp]
00007d5be8fd55ca  mov esi, 0x00
00007d5be8fd55cf  mov rax, 0x5D345705A530
00007d5be8fd55d9  call rax
00007d5be8fd55db  movaps xmm14, [rsp]
00007d5be8fd55e0  add rsp, 0x30
00007d5be8fd55e4  vmovaps xmm0, [rsp]
00007d5be8fd55e9  vmovaps xmm1, [rsp+0x10]
00007d5be8fd55ef  vmovaps xmm2, [rsp+0x20]
00007d5be8fd55f5  vmovaps xmm3, [rsp+0x30]
00007d5be8fd55fb  vmovaps xmm4, [rsp+0x40]
00007d5be8fd5601  vmovaps xmm5, [rsp+0x50]
00007d5be8fd5607  vmovaps xmm6, [rsp+0x60]
00007d5be8fd560d  vmovaps xmm7, [rsp+0x70]
00007d5be8fd5613  vmovaps xmm8, [rsp+0x80]
00007d5be8fd561c  vmovaps xmm9, [rsp+0x90]
00007d5be8fd5625  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd562e  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd5637  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd5640  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd5649  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd5652  add rsp, 0xF0
00007d5be8fd5659  pop r11
00007d5be8fd565b  pop r10
00007d5be8fd565d  pop r9
00007d5be8fd565f  pop r8
00007d5be8fd5661  pop rsi
00007d5be8fd5662  pop rdi
00007d5be8fd5663  pop rdx
00007d5be8fd5664  pop rcx
00007d5be8fd5665  pop rax
00007d5be8fd5666  add rsp, 0x08
00007d5be8fd566a  jmp 0x00007D5BE8FD031A
00007d5be8fd566f  sub rsp, 0x08
00007d5be8fd5673  push rax
00007d5be8fd5674  push rcx
00007d5be8fd5675  push rdx
00007d5be8fd5676  push rdi
00007d5be8fd5677  push rsi
00007d5be8fd5678  push r8
00007d5be8fd567a  push r9
00007d5be8fd567c  push r10
00007d5be8fd567e  push r11
00007d5be8fd5680  sub rsp, 0xF0
00007d5be8fd5687  vmovaps [rsp], xmm0
00007d5be8fd568c  vmovaps [rsp+0x10], xmm2
00007d5be8fd5692  vmovaps [rsp+0x20], xmm3
00007d5be8fd5698  vmovaps [rsp+0x30], xmm4
00007d5be8fd569e  vmovaps [rsp+0x40], xmm5
00007d5be8fd56a4  vmovaps [rsp+0x50], xmm6
00007d5be8fd56aa  vmovaps [rsp+0x60], xmm7
00007d5be8fd56b0  vmovaps [rsp+0x70], xmm8
00007d5be8fd56b6  vmovaps [rsp+0x80], xmm9
00007d5be8fd56bf  vmovaps [rsp+0x90], xmm10
00007d5be8fd56c8  vmovaps [rsp+0xA0], xmm11
00007d5be8fd56d1  vmovaps [rsp+0xB0], xmm12
00007d5be8fd56da  vmovaps [rsp+0xC0], xmm13
00007d5be8fd56e3  vmovaps [rsp+0xD0], xmm14
00007d5be8fd56ec  vmovaps [rsp+0xE0], xmm15
00007d5be8fd56f5  sub rsp, 0x30
00007d5be8fd56f9  movaps [rsp], xmm1
00007d5be8fd56fd  movaps [rsp+0x10], xmm7
00007d5be8fd5702  movaps [rsp+0x20], xmm11
00007d5be8fd5708  lea rdi, [rsp]
00007d5be8fd570c  mov esi, 0x00
00007d5be8fd5711  mov rax, 0x5D345705A530
00007d5be8fd571b  call rax
00007d5be8fd571d  movaps xmm1, [rsp]
00007d5be8fd5721  add rsp, 0x30
00007d5be8fd5725  vmovaps xmm0, [rsp]
00007d5be8fd572a  vmovaps xmm2, [rsp+0x10]
00007d5be8fd5730  vmovaps xmm3, [rsp+0x20]
00007d5be8fd5736  vmovaps xmm4, [rsp+0x30]
00007d5be8fd573c  vmovaps xmm5, [rsp+0x40]
00007d5be8fd5742  vmovaps xmm6, [rsp+0x50]
00007d5be8fd5748  vmovaps xmm7, [rsp+0x60]
00007d5be8fd574e  vmovaps xmm8, [rsp+0x70]
00007d5be8fd5754  vmovaps xmm9, [rsp+0x80]
00007d5be8fd575d  vmovaps xmm10, [rsp+0x90]
00007d5be8fd5766  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd576f  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd5778  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd5781  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd578a  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd5793  add rsp, 0xF0
00007d5be8fd579a  pop r11
00007d5be8fd579c  pop r10
00007d5be8fd579e  pop r9
00007d5be8fd57a0  pop r8
00007d5be8fd57a2  pop rsi
00007d5be8fd57a3  pop rdi
00007d5be8fd57a4  pop rdx
00007d5be8fd57a5  pop rcx
00007d5be8fd57a6  pop rax
00007d5be8fd57a7  add rsp, 0x08
00007d5be8fd57ab  jmp 0x00007D5BE8FD033B
00007d5be8fd57b0  call 0x00007D5BE8E0E880
00007d5be8fd57b5  jmp 0x00007D5BE8FD034E
00007d5be8fd57ba  call 0x00007D5BE8E0C380
00007d5be8fd57bf  jmp 0x00007D5BE8FD0359
00007d5be8fd57c4  call 0x00007D5BE8E0D600
00007d5be8fd57c9  jmp 0x00007D5BE8FD0364
00007d5be8fd57ce  call 0x00007D5BE8DFF540
00007d5be8fd57d3  jmp 0x00007D5BE8FD036F
00007d5be8fd57d8  int3
00007d5be8fd57d9  nop [rax], eax
00007d5be8fd57e0  mov rax, [r15+0x40]
00007d5be8fd57e4  mov r14, [r15+0x58]
00007d5be8fd57e8  lea r12, [rax+r14*1]
00007d5be8fd57ec  movaps xmm1, [r15+0x1D0]
00007d5be8fd57f4  vmovaps [rsp+0x10], xmm1
00007d5be8fd57fa  vmovaps xmm15, [rsp+0x10]
00007d5be8fd5800  por xmm1, xmm15
00007d5be8fd5805  movaps xmm14, [r15+0x1A0]
00007d5be8fd580d  vmovaps [rsp+0x10], xmm14
00007d5be8fd5813  vmovaps xmm13, [rsp+0x10]
00007d5be8fd5819  por xmm14, xmm13
00007d5be8fd581e  lea rax, [r12+0x30]
00007d5be8fd5823  mov r11, [r13+rax*1]
00007d5be8fd5828  lea rax, [r12+0x38]
00007d5be8fd582d  mov r10, [r13+rax*1]
00007d5be8fd5832  movq xmm13, r11
00007d5be8fd5837  movq xmm12, r10
00007d5be8fd583c  movq xmm13, xmm13
00007d5be8fd5841  vmovaps [rsp+0x10], xmm13
00007d5be8fd5847  movq xmm13, xmm13
00007d5be8fd584c  movaps [r15+0x130], xmm13
00007d5be8fd5854  movq xmm12, xmm12
00007d5be8fd5859  vmovaps [rsp+0x20], xmm12
00007d5be8fd585f  movq xmm12, xmm12
00007d5be8fd5864  movaps [r15+0x280], xmm12
00007d5be8fd586c  movaps xmm13, [r15+0x270]
00007d5be8fd5874  vmovaps [rsp+0x30], xmm13
00007d5be8fd587a  vmovaps xmm12, [rsp+0x30]
00007d5be8fd5880  por xmm13, xmm12
00007d5be8fd5885  lea rax, [r12+0x20]
00007d5be8fd588a  mov r11, [r13+rax*1]
00007d5be8fd588f  lea rax, [r12+0x28]
00007d5be8fd5894  mov r10, [r13+rax*1]
00007d5be8fd5899  movq xmm12, r11
00007d5be8fd589e  movq xmm11, r10
00007d5be8fd58a3  movq xmm12, xmm12
00007d5be8fd58a8  vmovaps [rsp+0x30], xmm12
00007d5be8fd58ae  movq xmm12, xmm12
00007d5be8fd58b3  movaps [r15+0x150], xmm12
00007d5be8fd58bb  movq xmm11, xmm11
00007d5be8fd58c0  vmovaps [rsp+0x40], xmm11
00007d5be8fd58c6  movq xmm11, xmm11
00007d5be8fd58cb  movaps [r15+0x140], xmm11
00007d5be8fd58d3  lea rax, [r12+0x10]
00007d5be8fd58d8  mov r11, [r13+rax*1]
00007d5be8fd58dd  lea rax, [r12+0x18]
00007d5be8fd58e2  mov r10, [r13+rax*1]
00007d5be8fd58e7  movq xmm12, r11
00007d5be8fd58ec  movq xmm11, r10
00007d5be8fd58f1  movq xmm12, xmm12
00007d5be8fd58f6  vmovaps [rsp+0x50], xmm12
00007d5be8fd58fc  movq xmm12, xmm12
00007d5be8fd5901  movaps [r15+0x170], xmm12
00007d5be8fd5909  movq xmm11, xmm11
00007d5be8fd590e  vmovaps [rsp+0x60], xmm11
00007d5be8fd5914  movq xmm11, xmm11
00007d5be8fd5919  movaps [r15+0x160], xmm11
00007d5be8fd5921  mov rax, [r13+r12*1]
00007d5be8fd5926  vmovq xmm12, rax
00007d5be8fd592b  vpbroadcastq xmm12, xmm12
00007d5be8fd5930  lea rax, [r12+0x08]
00007d5be8fd5935  mov r12, [r13+rax*1]
00007d5be8fd593a  movq xmm11, r12
00007d5be8fd593f  movaps [r15+0x230], xmm11
00007d5be8fd5947  mov rax, [r15+0xF8]
00007d5be8fd594e  lea r12, [rax+0x50]
00007d5be8fd5952  movups xmm11, [r13+r12*1]
00007d5be8fd5958  lea r12, [rax+0x60]
00007d5be8fd595c  movups xmm10, [r13+r12*1]
00007d5be8fd5962  lea r12, [rax+0x30]
00007d5be8fd5966  movups xmm9, [r13+r12*1]
00007d5be8fd596c  mov r12, [r15+0x50]
00007d5be8fd5970  lea r11, [r12+r14*1]
00007d5be8fd5974  mov [r15+0x60], r11
00007d5be8fd5978  lea r12, [r14+0x40]
00007d5be8fd597c  mov [r15+0x58], r12
00007d5be8fd5980  movaps xmm8, xmm12
00007d5be8fd5984  mulpd xmm8, xmm15
00007d5be8fd5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007d5be8fd598f  ptest xmm7, xmm7
00007d5be8fd5994  jnz 0x00007D5BE8FD67B7
00007d5be8fd599a  movq xmm15, qword ptr [r15+0x230]
00007d5be8fd59a3  vmovaps [rsp+0x70], xmm15
00007d5be8fd59a9  vpermilpd xmm15, xmm15, 0x00
00007d5be8fd59af  movaps xmm7, xmm9
00007d5be8fd59b3  mulpd xmm7, xmm15
00007d5be8fd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007d5be8fd59bd  ptest xmm6, xmm6
00007d5be8fd59c2  jnz 0x00007D5BE8FD68FB
00007d5be8fd59c8  vxorps xmm15, xmm15, xmm15
00007d5be8fd59cd  vpbroadcastq xmm15, xmm15
00007d5be8fd59d2  movaps xmm9, xmm12
00007d5be8fd59d6  mulpd xmm9, xmm10
00007d5be8fd59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007d5be8fd59e1  ptest xmm6, xmm6
00007d5be8fd59e6  jnz 0x00007D5BE8FD6A3D
00007d5be8fd59ec  movaps xmm10, xmm12
00007d5be8fd59f0  mulpd xmm10, xmm11
00007d5be8fd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007d5be8fd59fb  ptest xmm6, xmm6
00007d5be8fd5a00  jnz 0x00007D5BE8FD6B81
00007d5be8fd5a06  movaps xmm11, [r15+0x1F0]
00007d5be8fd5a0e  movaps xmm6, xmm12
00007d5be8fd5a12  mulpd xmm6, xmm11
00007d5be8fd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007d5be8fd5a1c  ptest xmm5, xmm5
00007d5be8fd5a21  jnz 0x00007D5BE8FD6CC5
00007d5be8fd5a27  movaps xmm12, [r15+0x2A0]
00007d5be8fd5a2f  vmovaps [rsp+0x80], xmm12
00007d5be8fd5a38  vmovaps xmm11, [rsp+0x80]
00007d5be8fd5a41  por xmm12, xmm11
00007d5be8fd5a46  movaps xmm11, [r15+0x250]
00007d5be8fd5a4e  vmovaps [rsp+0x80], xmm11
00007d5be8fd5a57  vmovaps xmm5, [rsp+0x80]
00007d5be8fd5a60  por xmm11, xmm5
00007d5be8fd5a65  vmovaps xmm4, [rsp+0x70]
00007d5be8fd5a6b  vpermilpd xmm4, xmm4, 0x00
00007d5be8fd5a71  movaps xmm3, xmm5
00007d5be8fd5a74  mulpd xmm3, xmm4
00007d5be8fd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007d5be8fd5a7d  ptest xmm2, xmm2
00007d5be8fd5a82  jnz 0x00007D5BE8FD6E07
00007d5be8fd5a88  mov [rsp+0x80], rax
00007d5be8fd5a90  xor eax, eax
00007d5be8fd5a92  mov r14d, 0x200
00007d5be8fd5a98  cmp r12, r14
00007d5be8fd5a9b  cmc
00007d5be8fd5a9c  lahf
00007d5be8fd5a9d  seto al
00007d5be8fd5aa0  mov [r15+0x108], eax
00007d5be8fd5aa7  movaps xmm5, xmm8
00007d5be8fd5aab  addpd xmm5, xmm15
00007d5be8fd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007d5be8fd5ab5  ptest xmm4, xmm4
00007d5be8fd5aba  jnz 0x00007D5BE8FD6F47
00007d5be8fd5ac0  movaps xmm8, [r15+0x1B0]
00007d5be8fd5ac8  movaps xmm4, xmm9
00007d5be8fd5acc  addpd xmm4, xmm8
00007d5be8fd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007d5be8fd5ad6  ptest xmm2, xmm2
00007d5be8fd5adb  jnz 0x00007D5BE8FD7089
00007d5be8fd5ae1  movaps xmm9, xmm10
00007d5be8fd5ae5  addpd xmm9, xmm8
00007d5be8fd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007d5be8fd5af0  ptest xmm2, xmm2
00007d5be8fd5af5  jnz 0x00007D5BE8FD71CB
00007d5be8fd5afb  movaps xmm10, [r15+0x2F0]
00007d5be8fd5b03  vmovaps [rsp+0x90], xmm10
00007d5be8fd5b0c  vmovaps xmm8, [rsp+0x90]
00007d5be8fd5b15  por xmm10, xmm8
00007d5be8fd5b1a  movaps xmm8, [r15+0x2E0]
00007d5be8fd5b22  vmovaps [rsp+0x90], xmm8
00007d5be8fd5b2b  vmovaps xmm2, [rsp+0x90]
00007d5be8fd5b34  por xmm8, xmm2
00007d5be8fd5b39  movaps xmm2, [r15+0x2D0]
00007d5be8fd5b41  vmovaps [rsp+0x90], xmm2
00007d5be8fd5b4a  vmovaps [rsp+0xA0], xmm1
00007d5be8fd5b53  vmovaps xmm1, [rsp+0x90]
00007d5be8fd5b5c  por xmm2, xmm1
00007d5be8fd5b60  movaps xmm1, [r15+0x200]
00007d5be8fd5b68  vmovaps [rsp+0x90], xmm1
00007d5be8fd5b71  vmovaps [rsp+0xB0], xmm15
00007d5be8fd5b7a  vmovaps xmm15, [rsp+0x90]
00007d5be8fd5b83  por xmm1, xmm15
00007d5be8fd5b88  movaps xmm15, [r15+0x1C0]
00007d5be8fd5b90  vmovaps [rsp+0x90], xmm15
00007d5be8fd5b99  vmovaps [rsp+0xC0], xmm1
00007d5be8fd5ba2  vmovaps xmm1, [rsp+0x90]
00007d5be8fd5bab  por xmm15, xmm1
00007d5be8fd5bb0  movaps xmm1, [r15+0x190]
00007d5be8fd5bb8  vmovaps [rsp+0x90], xmm1
00007d5be8fd5bc1  vmovaps [rsp+0xD0], xmm15
00007d5be8fd5bca  vmovaps xmm15, [rsp+0x90]
00007d5be8fd5bd3  por xmm1, xmm15
00007d5be8fd5bd8  movaps xmm15, [r15+0x300]
00007d5be8fd5be0  vmovaps [rsp+0x90], xmm15
00007d5be8fd5be9  vmovaps [rsp+0xE0], xmm1
00007d5be8fd5bf2  vmovaps xmm1, [rsp+0x90]
00007d5be8fd5bfb  por xmm15, xmm1
00007d5be8fd5c00  mov rax, [rsp+0x80]
00007d5be8fd5c08  lea r14, [rax+0xA0]
00007d5be8fd5c0f  movups xmm1, [r13+r14*1]
00007d5be8fd5c15  lea r14, [rax+0xB0]
00007d5be8fd5c1c  vmovaps [rsp+0x80], xmm1
00007d5be8fd5c25  movups xmm1, [r13+r14*1]
00007d5be8fd5c2b  vmovaps [rsp+0x90], xmm1
00007d5be8fd5c34  vmovaps [rsp+0xF0], xmm15
00007d5be8fd5c3d  vmovaps xmm15, [rsp+0xB0]
00007d5be8fd5c46  vmovaps [rsp+0xB0], xmm14
00007d5be8fd5c4f  movaps xmm1, xmm6
00007d5be8fd5c52  addpd xmm1, xmm15
00007d5be8fd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007d5be8fd5c5c  ptest xmm14, xmm14
00007d5be8fd5c62  jnz 0x00007D5BE8FD7323
00007d5be8fd5c68  lea r14, [rax+0xF0]
00007d5be8fd5c6f  movups xmm15, [r13+r14*1]
00007d5be8fd5c75  movaps xmm14, xmm4
00007d5be8fd5c79  addpd xmm14, xmm3
00007d5be8fd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007d5be8fd5c84  ptest xmm6, xmm6
00007d5be8fd5c89  jnz 0x00007D5BE8FD746E
00007d5be8fd5c8f  movaps xmm6, xmm9
00007d5be8fd5c93  addpd xmm6, xmm7
00007d5be8fd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007d5be8fd5c9c  ptest xmm4, xmm4
00007d5be8fd5ca1  jnz 0x00007D5BE8FD75B0
00007d5be8fd5ca7  vmovaps xmm9, [rsp+0x70]
00007d5be8fd5cad  vpermilpd xmm9, xmm9, 0x00
00007d5be8fd5cb3  vmovaps xmm4, [rsp+0x90]
00007d5be8fd5cbc  movaps xmm7, xmm4
00007d5be8fd5cbf  mulpd xmm7, xmm9
00007d5be8fd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007d5be8fd5cc9  ptest xmm3, xmm3
00007d5be8fd5cce  jnz 0x00007D5BE8FD76F1
00007d5be8fd5cd4  vmovaps xmm9, [rsp+0x50]
00007d5be8fd5cda  vpermilpd xmm9, xmm9, 0x00
00007d5be8fd5ce0  movaps xmm4, xmm15
00007d5be8fd5ce4  mulpd xmm4, xmm9
00007d5be8fd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007d5be8fd5cee  ptest xmm3, xmm3
00007d5be8fd5cf3  jnz 0x00007D5BE8FD7832
00007d5be8fd5cf9  lea r14, [rax+0xE0]
00007d5be8fd5d00  movups xmm15, [r13+r14*1]
00007d5be8fd5d06  vmovaps xmm9, [rsp+0x70]
00007d5be8fd5d0c  vpermilpd xmm9, xmm9, 0x00
00007d5be8fd5d12  vmovaps [rsp+0x70], xmm1
00007d5be8fd5d18  vmovaps xmm1, [rsp+0x80]
00007d5be8fd5d21  vmovaps [rsp+0x80], xmm15
00007d5be8fd5d2a  movaps xmm3, xmm1
00007d5be8fd5d2d  mulpd xmm3, xmm9
00007d5be8fd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007d5be8fd5d37  ptest xmm15, xmm15
00007d5be8fd5d3d  jnz 0x00007D5BE8FD797E
00007d5be8fd5d43  vmovaps xmm1, [rsp+0xF0]
00007d5be8fd5d4c  vmovaps xmm15, [rsp+0xF0]
00007d5be8fd5d55  por xmm1, xmm15
00007d5be8fd5d5a  movaps [r15+0x300], xmm1
00007d5be8fd5d62  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd5d6b  vmovaps xmm9, [rsp+0xE0]
00007d5be8fd5d74  por xmm15, xmm9
00007d5be8fd5d79  movaps [r15+0x190], xmm15
00007d5be8fd5d81  vmovaps xmm9, [rsp+0x50]
00007d5be8fd5d87  vpermilpd xmm9, xmm9, 0x00
00007d5be8fd5d8d  vmovaps [rsp+0x90], xmm1
00007d5be8fd5d96  vmovaps [rsp+0xE0], xmm15
00007d5be8fd5d9f  vmovaps xmm15, [rsp+0x80]
00007d5be8fd5da8  vmovaps [rsp+0x80], xmm14
00007d5be8fd5db1  movaps xmm1, xmm15
00007d5be8fd5db5  mulpd xmm1, xmm9
00007d5be8fd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007d5be8fd5dbf  ptest xmm14, xmm14
00007d5be8fd5dc5  jnz 0x00007D5BE8FD7ABF
00007d5be8fd5dcb  lea r14, [rax+0x90]
00007d5be8fd5dd2  movups xmm15, [r13+r14*1]
00007d5be8fd5dd8  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd5de1  vmovaps xmm9, [rsp+0xD0]
00007d5be8fd5dea  por xmm14, xmm9
00007d5be8fd5def  movaps [r15+0x1C0], xmm14
00007d5be8fd5df7  vmovaps xmm9, [rsp+0xC0]
00007d5be8fd5e00  vmovaps [rsp+0xD0], xmm1
00007d5be8fd5e09  vmovaps xmm1, [rsp+0xC0]
00007d5be8fd5e12  por xmm9, xmm1
00007d5be8fd5e17  movaps [r15+0x200], xmm9
00007d5be8fd5e1f  vmovaps [rsp+0xC0], xmm2
00007d5be8fd5e28  vmovaps xmm1, [rsp+0xC0]
00007d5be8fd5e31  por xmm2, xmm1
00007d5be8fd5e35  movaps [r15+0x2D0], xmm2
00007d5be8fd5e3d  vmovaps [rsp+0xC0], xmm8
00007d5be8fd5e46  vmovaps xmm1, [rsp+0xC0]
00007d5be8fd5e4f  por xmm8, xmm1
00007d5be8fd5e54  movaps [r15+0x2E0], xmm8
00007d5be8fd5e5c  vmovaps [rsp+0xC0], xmm15
00007d5be8fd5e65  movaps xmm1, xmm5
00007d5be8fd5e68  addpd xmm1, xmm7
00007d5be8fd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007d5be8fd5e71  ptest xmm15, xmm15
00007d5be8fd5e77  jnz 0x00007D5BE8FD7C0B
00007d5be8fd5e7d  vmovaps xmm15, [rsp+0x50]
00007d5be8fd5e83  vpermilpd xmm15, xmm15, 0x00
00007d5be8fd5e89  vmovaps xmm5, [rsp+0xC0]
00007d5be8fd5e92  vmovaps [rsp+0xC0], xmm1
00007d5be8fd5e9b  movaps xmm7, xmm5
00007d5be8fd5e9e  mulpd xmm7, xmm15
00007d5be8fd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007d5be8fd5ea8  ptest xmm1, xmm1
00007d5be8fd5ead  jnz 0x00007D5BE8FD7D4B
00007d5be8fd5eb3  lea r14, [rax+0x80]
00007d5be8fd5eba  movups xmm1, [r13+r14*1]
00007d5be8fd5ec0  vmovaps xmm5, [rsp+0x70]
00007d5be8fd5ec6  vmovaps [rsp+0x70], xmm1
00007d5be8fd5ecc  movaps xmm15, xmm5
00007d5be8fd5ed0  addpd xmm15, xmm3
00007d5be8fd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007d5be8fd5edb  ptest xmm1, xmm1
00007d5be8fd5ee0  jnz 0x00007D5BE8FD7E96
00007d5be8fd5ee6  vmovaps xmm5, [rsp+0x80]
00007d5be8fd5eef  movaps xmm1, xmm5
00007d5be8fd5ef2  addpd xmm1, xmm4
00007d5be8fd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007d5be8fd5efb  ptest xmm3, xmm3
00007d5be8fd5f00  jnz 0x00007D5BE8FD7FD8
00007d5be8fd5f06  vmovaps [rsp+0x80], xmm10
00007d5be8fd5f0f  vmovaps xmm5, [rsp+0x80]
00007d5be8fd5f18  por xmm10, xmm5
00007d5be8fd5f1d  movaps [r15+0x2F0], xmm10
00007d5be8fd5f25  vmovaps xmm5, [rsp+0x50]
00007d5be8fd5f2b  vpermilpd xmm5, xmm5, 0x00
00007d5be8fd5f31  vmovaps xmm3, [rsp+0x70]
00007d5be8fd5f37  vmovaps [rsp+0x50], xmm1
00007d5be8fd5f3d  movaps xmm4, xmm3
00007d5be8fd5f40  mulpd xmm4, xmm5
00007d5be8fd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007d5be8fd5f49  ptest xmm1, xmm1
00007d5be8fd5f4e  jnz 0x00007D5BE8FD8118
00007d5be8fd5f54  lea r14, [rax+0xD0]
00007d5be8fd5f5b  movups xmm1, [r13+r14*1]
00007d5be8fd5f61  vmovaps xmm3, [rsp+0xD0]
00007d5be8fd5f6a  vmovaps [rsp+0x70], xmm1
00007d5be8fd5f70  movaps xmm5, xmm6
00007d5be8fd5f73  addpd xmm5, xmm3
00007d5be8fd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007d5be8fd5f7c  ptest xmm1, xmm1
00007d5be8fd5f81  jnz 0x00007D5BE8FD8262
00007d5be8fd5f87  vmovaps xmm1, [rsp+0x60]
00007d5be8fd5f8d  vpermilpd xmm1, xmm1, 0x00
00007d5be8fd5f93  movaps xmm6, xmm9
00007d5be8fd5f97  mulpd xmm6, xmm1
00007d5be8fd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007d5be8fd5fa0  ptest xmm3, xmm3
00007d5be8fd5fa5  jnz 0x00007D5BE8FD83A2
00007d5be8fd5fab  movaps [r15+0x260], xmm6
00007d5be8fd5fb3  vxorps xmm1, xmm1, xmm1
00007d5be8fd5fb7  vpbroadcastq xmm1, xmm1
00007d5be8fd5fbc  movaps [r15+0x1B0], xmm1
00007d5be8fd5fc4  vmovaps xmm1, [rsp+0x60]
00007d5be8fd5fca  vpermilpd xmm1, xmm1, 0x00
00007d5be8fd5fd0  vmovaps xmm3, [rsp+0x70]
00007d5be8fd5fd6  vmovaps [rsp+0x70], xmm15
00007d5be8fd5fdc  movaps xmm9, xmm3
00007d5be8fd5fe0  mulpd xmm9, xmm1
00007d5be8fd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007d5be8fd5feb  ptest xmm15, xmm15
00007d5be8fd5ff1  jnz 0x00007D5BE8FD84E3
00007d5be8fd5ff7  lea r14, [rax+0xC0]
00007d5be8fd5ffe  movups xmm1, [r13+r14*1]
00007d5be8fd6004  vmovaps xmm3, [rsp+0xC0]
00007d5be8fd600d  vmovaps [rsp+0x80], xmm1
00007d5be8fd6016  movaps xmm15, xmm3
00007d5be8fd601a  addpd xmm15, xmm7
00007d5be8fd601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007d5be8fd6025  ptest xmm1, xmm1
00007d5be8fd602a  jnz 0x00007D5BE8FD862F
00007d5be8fd6030  vmovaps [rsp+0xC0], xmm13
00007d5be8fd6039  vmovaps xmm1, [rsp+0xC0]
00007d5be8fd6042  por xmm13, xmm1
00007d5be8fd6047  movaps [r15+0x270], xmm13
00007d5be8fd604f  vmovaps xmm1, [rsp+0xB0]
00007d5be8fd6058  vmovaps xmm7, [rsp+0xB0]
00007d5be8fd6061  por xmm1, xmm7
00007d5be8fd6065  movaps [r15+0x1A0], xmm1
00007d5be8fd606d  vmovaps xmm1, [rsp+0x60]
00007d5be8fd6073  vpermilpd xmm1, xmm1, 0x00
00007d5be8fd6079  vmovaps [rsp+0xB0], xmm1
00007d5be8fd6082  vmovaps xmm1, [rsp+0x80]
00007d5be8fd608b  vmovaps [rsp+0x80], xmm15
00007d5be8fd6094  vmovaps xmm15, [rsp+0xB0]
00007d5be8fd609d  vmovaps [rsp+0xB0], xmm14
00007d5be8fd60a6  movaps xmm3, xmm1
00007d5be8fd60a9  mulpd xmm3, xmm15
00007d5be8fd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007d5be8fd60b3  ptest xmm14, xmm14
00007d5be8fd60b9  jnz 0x00007D5BE8FD8771
00007d5be8fd60bf  lea r14, [rax+0x20]
00007d5be8fd60c3  movups xmm1, [r13+r14*1]
00007d5be8fd60c9  movaps [r15+0x110], xmm1
00007d5be8fd60d1  vmovaps xmm14, [rsp+0x70]
00007d5be8fd60d7  vmovaps [rsp+0x70], xmm1
00007d5be8fd60dd  movaps xmm15, xmm14
00007d5be8fd60e1  addpd xmm15, xmm4
00007d5be8fd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007d5be8fd60ec  ptest xmm1, xmm1
00007d5be8fd60f1  jnz 0x00007D5BE8FD88BC
00007d5be8fd60f7  vmovaps xmm1, [rsp+0x60]
00007d5be8fd60fd  vpermilpd xmm1, xmm1, 0x00
00007d5be8fd6103  movaps xmm14, xmm2
00007d5be8fd6107  mulpd xmm14, xmm1
00007d5be8fd610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007d5be8fd6112  ptest xmm4, xmm4
00007d5be8fd6117  jnz 0x00007D5BE8FD89FF
00007d5be8fd611d  vmovaps xmm4, [rsp+0x50]
00007d5be8fd6123  movaps xmm1, xmm4
00007d5be8fd6126  addpd xmm1, xmm9
00007d5be8fd612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007d5be8fd6130  ptest xmm2, xmm2
00007d5be8fd6135  jnz 0x00007D5BE8FD8B41
00007d5be8fd613b  vmovaps xmm9, [rsp+0x30]
00007d5be8fd6141  vpermilpd xmm9, xmm9, 0x00
00007d5be8fd6147  vmovaps xmm2, [rsp+0x70]
00007d5be8fd614d  vmovaps [rsp+0x50], xmm1
00007d5be8fd6153  movaps xmm4, xmm2
00007d5be8fd6156  mulpd xmm4, xmm9
00007d5be8fd615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007d5be8fd6160  ptest xmm1, xmm1
00007d5be8fd6165  jnz 0x00007D5BE8FD8C82
00007d5be8fd616b  vmovaps xmm1, [rsp+0x30]
00007d5be8fd6171  vpermilpd xmm1, xmm1, 0x00
00007d5be8fd6177  vmovaps xmm2, [rsp+0x90]
00007d5be8fd6180  vmovaps [rsp+0x60], xmm15
00007d5be8fd6186  movaps xmm9, xmm2
00007d5be8fd618a  mulpd xmm9, xmm1
00007d5be8fd618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007d5be8fd6195  ptest xmm15, xmm15
00007d5be8fd619b  jnz 0x00007D5BE8FD8DC3
00007d5be8fd61a1  vmovaps xmm15, [rsp+0x80]
00007d5be8fd61aa  movaps xmm1, xmm15
00007d5be8fd61ae  addpd xmm1, xmm6
00007d5be8fd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007d5be8fd61b7  ptest xmm2, xmm2
00007d5be8fd61bc  jnz 0x00007D5BE8FD8F05
00007d5be8fd61c2  movaps xmm15, xmm5
00007d5be8fd61c6  addpd xmm15, xmm3
00007d5be8fd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007d5be8fd61d1  ptest xmm6, xmm6
00007d5be8fd61d6  jnz 0x00007D5BE8FD9046
00007d5be8fd61dc  vmovaps xmm6, [rsp+0x30]
00007d5be8fd61e2  vpermilpd xmm6, xmm6, 0x00
00007d5be8fd61e8  movaps xmm5, xmm8
00007d5be8fd61ec  mulpd xmm5, xmm6
00007d5be8fd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007d5be8fd61f5  ptest xmm3, xmm3
00007d5be8fd61fa  jnz 0x00007D5BE8FD9188
00007d5be8fd6200  vmovaps xmm8, [rsp+0x30]
00007d5be8fd6206  vpermilpd xmm8, xmm8, 0x00
00007d5be8fd620c  movaps xmm6, xmm10
00007d5be8fd6210  mulpd xmm6, xmm8
00007d5be8fd6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007d5be8fd621a  ptest xmm3, xmm3
00007d5be8fd621f  jnz 0x00007D5BE8FD92C9
00007d5be8fd6225  vmovaps xmm8, [rsp+0x60]
00007d5be8fd622b  movaps xmm10, xmm8
00007d5be8fd622f  addpd xmm10, xmm14
00007d5be8fd6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007d5be8fd623a  ptest xmm3, xmm3
00007d5be8fd623f  jnz 0x00007D5BE8FD940B
00007d5be8fd6245  vmovaps xmm8, [rsp+0x50]
00007d5be8fd624b  movaps xmm14, xmm8
00007d5be8fd624f  addpd xmm14, xmm4
00007d5be8fd6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007d5be8fd625a  ptest xmm3, xmm3
00007d5be8fd625f  jnz 0x00007D5BE8FD954F
00007d5be8fd6265  vmovaps xmm8, [rsp+0x40]
00007d5be8fd626b  vpermilpd xmm8, xmm8, 0x00
00007d5be8fd6271  movaps xmm4, xmm13
00007d5be8fd6275  mulpd xmm4, xmm8
00007d5be8fd627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007d5be8fd627f  ptest xmm3, xmm3
00007d5be8fd6284  jnz 0x00007D5BE8FD9692
00007d5be8fd628a  movaps xmm13, xmm15
00007d5be8fd628e  addpd xmm13, xmm9
00007d5be8fd6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007d5be8fd6299  ptest xmm8, xmm8
00007d5be8fd629f  jnz 0x00007D5BE8FD97D4
00007d5be8fd62a5  movaps xmm15, xmm1
00007d5be8fd62a9  addpd xmm15, xmm5
00007d5be8fd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007d5be8fd62b4  ptest xmm9, xmm9
00007d5be8fd62ba  jnz 0x00007D5BE8FD9918
00007d5be8fd62c0  vmovaps [rsp+0x30], xmm11
00007d5be8fd62c6  vmovaps xmm1, [rsp+0x30]
00007d5be8fd62cc  por xmm11, xmm1
00007d5be8fd62d1  movaps [r15+0x250], xmm11
00007d5be8fd62d9  vmovaps [rsp+0x30], xmm12
00007d5be8fd62df  vmovaps xmm1, [rsp+0x30]
00007d5be8fd62e5  por xmm12, xmm1
00007d5be8fd62ea  movaps [r15+0x2A0], xmm12
00007d5be8fd62f2  vmovaps xmm1, [rsp+0xA0]
00007d5be8fd62fb  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd6304  por xmm1, xmm11
00007d5be8fd6309  movaps [r15+0x1D0], xmm1
00007d5be8fd6311  lea r14, [rax+0x40]
00007d5be8fd6315  movups xmm1, [r13+r14*1]
00007d5be8fd631b  movaps [r15+0x2C0], xmm1
00007d5be8fd6323  vmovaps xmm11, [rsp+0x40]
00007d5be8fd6329  vpermilpd xmm11, xmm11, 0x00
00007d5be8fd632f  vmovaps xmm8, [rsp+0xE0]
00007d5be8fd6338  movaps xmm9, xmm8
00007d5be8fd633c  mulpd xmm9, xmm11
00007d5be8fd6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007d5be8fd6347  ptest xmm5, xmm5
00007d5be8fd634c  jnz 0x00007D5BE8FD9A64
00007d5be8fd6352  movaps xmm11, xmm10
00007d5be8fd6356  addpd xmm11, xmm6
00007d5be8fd635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007d5be8fd6361  ptest xmm8, xmm8
00007d5be8fd6367  jnz 0x00007D5BE8FD9BA8
00007d5be8fd636d  movaps xmm10, xmm14
00007d5be8fd6371  addpd xmm10, xmm4
00007d5be8fd6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007d5be8fd637c  ptest xmm8, xmm8
00007d5be8fd6382  jnz 0x00007D5BE8FD9CEB
00007d5be8fd6388  vmovaps xmm14, [rsp+0x40]
00007d5be8fd638e  vpermilpd xmm14, xmm14, 0x00
00007d5be8fd6394  movaps xmm8, xmm1
00007d5be8fd6398  mulpd xmm8, xmm14
00007d5be8fd639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007d5be8fd63a3  ptest xmm6, xmm6
00007d5be8fd63a8  jnz 0x00007D5BE8FD9E2E
00007d5be8fd63ae  movaps xmm1, [r15+0x2B0]
00007d5be8fd63b6  vmovaps xmm14, [rsp+0x40]
00007d5be8fd63bc  vpermilpd xmm14, xmm14, 0x00
00007d5be8fd63c2  movaps xmm6, xmm1
00007d5be8fd63c5  mulpd xmm6, xmm14
00007d5be8fd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007d5be8fd63cf  ptest xmm5, xmm5
00007d5be8fd63d4  jnz 0x00007D5BE8FD9F71
00007d5be8fd63da  vmovaps xmm1, [rsp+0x10]
00007d5be8fd63e0  vpermilpd xmm1, xmm1, 0x00
00007d5be8fd63e6  movaps xmm14, xmm12
00007d5be8fd63ea  mulpd xmm14, xmm1
00007d5be8fd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007d5be8fd63f5  ptest xmm5, xmm5
00007d5be8fd63fa  jnz 0x00007D5BE8FDA0B2
00007d5be8fd6400  movaps xmm1, xmm13
00007d5be8fd6404  addpd xmm1, xmm9
00007d5be8fd6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007d5be8fd640e  ptest xmm12, xmm12
00007d5be8fd6414  jnz 0x00007D5BE8FDA1F5
00007d5be8fd641a  vmovaps xmm13, [rsp+0x10]
00007d5be8fd6420  vpermilpd xmm13, xmm13, 0x00
00007d5be8fd6426  movaps xmm12, xmm7
00007d5be8fd642a  mulpd xmm12, xmm13
00007d5be8fd642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007d5be8fd6435  ptest xmm9, xmm9
00007d5be8fd643b  jnz 0x00007D5BE8FDA337
00007d5be8fd6441  movaps xmm13, xmm15
00007d5be8fd6445  addpd xmm13, xmm8
00007d5be8fd644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007d5be8fd6450  ptest xmm9, xmm9
00007d5be8fd6456  jnz 0x00007D5BE8FDA47A
00007d5be8fd645c  movaps xmm15, [r15+0x290]
00007d5be8fd6464  vmovaps xmm9, [rsp+0x10]
00007d5be8fd646a  vpermilpd xmm9, xmm9, 0x00
00007d5be8fd6470  movaps xmm8, xmm15
00007d5be8fd6474  mulpd xmm8, xmm9
00007d5be8fd6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007d5be8fd647f  ptest xmm7, xmm7
00007d5be8fd6484  jnz 0x00007D5BE8FDA5BE
00007d5be8fd648a  movaps xmm15, xmm11
00007d5be8fd648e  addpd xmm15, xmm6
00007d5be8fd6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007d5be8fd6499  ptest xmm9, xmm9
00007d5be8fd649f  jnz 0x00007D5BE8FDA702
00007d5be8fd64a5  movaps xmm11, [r15+0x1E0]
00007d5be8fd64ad  vmovaps xmm9, [rsp+0x10]
00007d5be8fd64b3  vpermilpd xmm9, xmm9, 0x00
00007d5be8fd64b9  movaps xmm7, xmm11
00007d5be8fd64bd  mulpd xmm7, xmm9
00007d5be8fd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007d5be8fd64c7  ptest xmm6, xmm6
00007d5be8fd64cc  jnz 0x00007D5BE8FDA845
00007d5be8fd64d2  movaps xmm11, xmm10
00007d5be8fd64d6  addpd xmm11, xmm14
00007d5be8fd64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007d5be8fd64e1  ptest xmm9, xmm9
00007d5be8fd64e7  jnz 0x00007D5BE8FDA987
00007d5be8fd64ed  lea r14, [rax+0x70]
00007d5be8fd64f1  movups xmm14, [r13+r14*1]
00007d5be8fd64f7  movaps [r15+0x240], xmm14
00007d5be8fd64ff  movaps xmm10, xmm1
00007d5be8fd6503  addpd xmm10, xmm12
00007d5be8fd6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007d5be8fd650e  ptest xmm9, xmm9
00007d5be8fd6514  jnz 0x00007D5BE8FDAAD5
00007d5be8fd651a  movaps [r15+0x170], xmm10
00007d5be8fd6522  vmovaps xmm1, [rsp+0x20]
00007d5be8fd6528  vpermilpd xmm1, xmm1, 0x00
00007d5be8fd652e  movaps xmm12, xmm14
00007d5be8fd6532  mulpd xmm12, xmm1
00007d5be8fd6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007d5be8fd653d  ptest xmm9, xmm9
00007d5be8fd6543  jnz 0x00007D5BE8FDAC18
00007d5be8fd6549  vmovaps xmm1, [rsp+0x20]
00007d5be8fd654f  vpermilpd xmm1, xmm1, 0x00
00007d5be8fd6555  vmovaps xmm9, [rsp+0xB0]
00007d5be8fd655e  movaps xmm14, xmm9
00007d5be8fd6562  mulpd xmm14, xmm1
00007d5be8fd6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007d5be8fd656d  ptest xmm6, xmm6
00007d5be8fd6572  jnz 0x00007D5BE8FDAD5B
00007d5be8fd6578  movaps [r15+0x180], xmm14
00007d5be8fd6580  movaps xmm1, xmm13
00007d5be8fd6584  addpd xmm1, xmm8
00007d5be8fd6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007d5be8fd658e  ptest xmm9, xmm9
00007d5be8fd6594  jnz 0x00007D5BE8FDAE9E
00007d5be8fd659a  movaps [r15+0x210], xmm1
00007d5be8fd65a2  movups xmm13, [r13+rax*1]
00007d5be8fd65a8  lea r14, [rax+0x10]
00007d5be8fd65ac  movups xmm9, [r13+r14*1]
00007d5be8fd65b2  movaps [r15+0x230], xmm9
00007d5be8fd65ba  movaps xmm8, xmm15
00007d5be8fd65be  addpd xmm8, xmm7
00007d5be8fd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007d5be8fd65c9  ptest xmm6, xmm6
00007d5be8fd65ce  jnz 0x00007D5BE8FDAFF4
00007d5be8fd65d4  movaps [r15+0x130], xmm8
00007d5be8fd65dc  vmovaps xmm15, [rsp+0x20]
00007d5be8fd65e2  vpermilpd xmm15, xmm15, 0x00
00007d5be8fd65e8  movaps xmm7, xmm9
00007d5be8fd65ec  mulpd xmm7, xmm15
00007d5be8fd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007d5be8fd65f6  ptest xmm6, xmm6
00007d5be8fd65fb  jnz 0x00007D5BE8FDB137
00007d5be8fd6601  movaps [r15+0x220], xmm7
00007d5be8fd6609  vmovaps xmm15, [rsp+0x20]
00007d5be8fd660f  vpermilpd xmm15, xmm15, 0x00
00007d5be8fd6615  movaps xmm9, xmm13
00007d5be8fd6619  mulpd xmm9, xmm15
00007d5be8fd661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007d5be8fd6624  ptest xmm6, xmm6
00007d5be8fd6629  jnz 0x00007D5BE8FDB279
00007d5be8fd662f  movaps xmm15, xmm11
00007d5be8fd6633  addpd xmm15, xmm12
00007d5be8fd6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007d5be8fd663e  ptest xmm13, xmm13
00007d5be8fd6644  jnz 0x00007D5BE8FDB3BD
00007d5be8fd664a  movaps [r15+0x140], xmm15
00007d5be8fd6652  movaps xmm13, xmm10
00007d5be8fd6656  addpd xmm13, xmm14
00007d5be8fd665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007d5be8fd6661  ptest xmm12, xmm12
00007d5be8fd6667  jnz 0x00007D5BE8FDB501
00007d5be8fd666d  movaps [r15+0x150], xmm13
00007d5be8fd6675  movaps xmm14, xmm1
00007d5be8fd6679  addpd xmm14, xmm7
00007d5be8fd667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007d5be8fd6684  ptest xmm12, xmm12
00007d5be8fd668a  jnz 0x00007D5BE8FDB645
00007d5be8fd6690  movaps [r15+0x160], xmm14
00007d5be8fd6698  movaps xmm1, xmm8
00007d5be8fd669c  addpd xmm1, xmm9
00007d5be8fd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007d5be8fd66a6  ptest xmm12, xmm12
00007d5be8fd66ac  jnz 0x00007D5BE8FDB787
00007d5be8fd66b2  movaps [r15+0x120], xmm1
00007d5be8fd66ba  movups [r13+r11*1], xmm15
00007d5be8fd66c0  lea rax, [r11+0x10]
00007d5be8fd66c4  movups [r13+rax*1], xmm13
00007d5be8fd66ca  lea rax, [r11+0x20]
00007d5be8fd66ce  movups [r13+rax*1], xmm14
00007d5be8fd66d4  lea rax, [r11+0x30]
00007d5be8fd66d8  movups [r13+rax*1], xmm1
00007d5be8fd66de  mov eax, [r15+0x108]
00007d5be8fd66e5  sahf
00007d5be8fd66e6  jnz 0x00007D5BE8FD6718
00007d5be8fd66e8  cmp dword ptr [r15+0x318], 0x00
00007d5be8fd66f0  jz 0x00007D5BE8FDB900
00007d5be8fd66f6  nop [rax+rax*1], ax
00007d5be8fd66ff  nop [rax+rax*1], eax
00007d5be8fd6707  mov eax, 0x410444
00007d5be8fd670c  mov [r15+0x100], rax
00007d5be8fd6713  jmp 0x00007D5BE8DFE110
00007d5be8fd6718  cmp dword ptr [r15+0x318], 0x00
00007d5be8fd6720  jz 0x00007D5BE8FD57E0
00007d5be8fd6726  nop [rax+rax*1], ax
00007d5be8fd672f  nop [rax+rax*1], eax
00007d5be8fd6737  mov eax, 0x410278
00007d5be8fd673c  mov [r15+0x100], rax
00007d5be8fd6743  jmp 0x00007D5BE8DFE110
00007d5be8fd6748  int3
00007d5be8fd6749  call 0x00007D5BE8E0A4B0
00007d5be8fd674e  jmp 0x00007D5BE8FD5828
00007d5be8fd6753  call 0x00007D5BE8E09240
00007d5be8fd6758  jmp 0x00007D5BE8FD5832
00007d5be8fd675d  call 0x00007D5BE8E0A4B0
00007d5be8fd6762  jmp 0x00007D5BE8FD588F
00007d5be8fd6767  call 0x00007D5BE8E09240
00007d5be8fd676c  jmp 0x00007D5BE8FD5899
00007d5be8fd6771  call 0x00007D5BE8E0A4B0
00007d5be8fd6776  jmp 0x00007D5BE8FD58DD
00007d5be8fd677b  call 0x00007D5BE8E09240
00007d5be8fd6780  jmp 0x00007D5BE8FD58E7
00007d5be8fd6785  call 0x00007D5BE8EB47C0
00007d5be8fd678a  jmp 0x00007D5BE8FD5926
00007d5be8fd678f  call 0x00007D5BE8E0B720
00007d5be8fd6794  jmp 0x00007D5BE8FD593A
00007d5be8fd6799  call 0x00007D5BE8EBFC30
00007d5be8fd679e  jmp 0x00007D5BE8FD5958
00007d5be8fd67a3  call 0x00007D5BE8EBE9C0
00007d5be8fd67a8  jmp 0x00007D5BE8FD5962
00007d5be8fd67ad  call 0x00007D5BE8EBD750
00007d5be8fd67b2  jmp 0x00007D5BE8FD596C
00007d5be8fd67b7  sub rsp, 0x08
00007d5be8fd67bb  push rax
00007d5be8fd67bc  push rcx
00007d5be8fd67bd  push rdx
00007d5be8fd67be  push rdi
00007d5be8fd67bf  push rsi
00007d5be8fd67c0  push r8
00007d5be8fd67c2  push r9
00007d5be8fd67c4  push r10
00007d5be8fd67c6  push r11
00007d5be8fd67c8  sub rsp, 0xF0
00007d5be8fd67cf  vmovaps [rsp], xmm0
00007d5be8fd67d4  vmovaps [rsp+0x10], xmm1
00007d5be8fd67da  vmovaps [rsp+0x20], xmm2
00007d5be8fd67e0  vmovaps [rsp+0x30], xmm3
00007d5be8fd67e6  vmovaps [rsp+0x40], xmm4
00007d5be8fd67ec  vmovaps [rsp+0x50], xmm5
00007d5be8fd67f2  vmovaps [rsp+0x60], xmm6
00007d5be8fd67f8  vmovaps [rsp+0x70], xmm7
00007d5be8fd67fe  vmovaps [rsp+0x80], xmm9
00007d5be8fd6807  vmovaps [rsp+0x90], xmm10
00007d5be8fd6810  vmovaps [rsp+0xA0], xmm11
00007d5be8fd6819  vmovaps [rsp+0xB0], xmm12
00007d5be8fd6822  vmovaps [rsp+0xC0], xmm13
00007d5be8fd682b  vmovaps [rsp+0xD0], xmm14
00007d5be8fd6834  vmovaps [rsp+0xE0], xmm15
00007d5be8fd683d  sub rsp, 0x30
00007d5be8fd6841  movaps [rsp], xmm8
00007d5be8fd6846  movaps [rsp+0x10], xmm12
00007d5be8fd684c  movaps [rsp+0x20], xmm15
00007d5be8fd6852  lea rdi, [rsp]
00007d5be8fd6856  mov esi, 0x00
00007d5be8fd685b  mov rax, 0x5D345705A530
00007d5be8fd6865  call rax
00007d5be8fd6867  movaps xmm8, [rsp]
00007d5be8fd686c  add rsp, 0x30
00007d5be8fd6870  vmovaps xmm0, [rsp]
00007d5be8fd6875  vmovaps xmm1, [rsp+0x10]
00007d5be8fd687b  vmovaps xmm2, [rsp+0x20]
00007d5be8fd6881  vmovaps xmm3, [rsp+0x30]
00007d5be8fd6887  vmovaps xmm4, [rsp+0x40]
00007d5be8fd688d  vmovaps xmm5, [rsp+0x50]
00007d5be8fd6893  vmovaps xmm6, [rsp+0x60]
00007d5be8fd6899  vmovaps xmm7, [rsp+0x70]
00007d5be8fd689f  vmovaps xmm9, [rsp+0x80]
00007d5be8fd68a8  vmovaps xmm10, [rsp+0x90]
00007d5be8fd68b1  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd68ba  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd68c3  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd68cc  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd68d5  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd68de  add rsp, 0xF0
00007d5be8fd68e5  pop r11
00007d5be8fd68e7  pop r10
00007d5be8fd68e9  pop r9
00007d5be8fd68eb  pop r8
00007d5be8fd68ed  pop rsi
00007d5be8fd68ee  pop rdi
00007d5be8fd68ef  pop rdx
00007d5be8fd68f0  pop rcx
00007d5be8fd68f1  pop rax
00007d5be8fd68f2  add rsp, 0x08
00007d5be8fd68f6  jmp 0x00007D5BE8FD599A
00007d5be8fd68fb  sub rsp, 0x08
00007d5be8fd68ff  push rax
00007d5be8fd6900  push rcx
00007d5be8fd6901  push rdx
00007d5be8fd6902  push rdi
00007d5be8fd6903  push rsi
00007d5be8fd6904  push r8
00007d5be8fd6906  push r9
00007d5be8fd6908  push r10
00007d5be8fd690a  push r11
00007d5be8fd690c  sub rsp, 0xF0
00007d5be8fd6913  vmovaps [rsp], xmm0
00007d5be8fd6918  vmovaps [rsp+0x10], xmm1
00007d5be8fd691e  vmovaps [rsp+0x20], xmm2
00007d5be8fd6924  vmovaps [rsp+0x30], xmm3
00007d5be8fd692a  vmovaps [rsp+0x40], xmm4
00007d5be8fd6930  vmovaps [rsp+0x50], xmm5
00007d5be8fd6936  vmovaps [rsp+0x60], xmm6
00007d5be8fd693c  vmovaps [rsp+0x70], xmm8
00007d5be8fd6942  vmovaps [rsp+0x80], xmm9
00007d5be8fd694b  vmovaps [rsp+0x90], xmm10
00007d5be8fd6954  vmovaps [rsp+0xA0], xmm11
00007d5be8fd695d  vmovaps [rsp+0xB0], xmm12
00007d5be8fd6966  vmovaps [rsp+0xC0], xmm13
00007d5be8fd696f  vmovaps [rsp+0xD0], xmm14
00007d5be8fd6978  vmovaps [rsp+0xE0], xmm15
00007d5be8fd6981  sub rsp, 0x30
00007d5be8fd6985  movaps [rsp], xmm7
00007d5be8fd6989  movaps [rsp+0x10], xmm9
00007d5be8fd698f  movaps [rsp+0x20], xmm15
00007d5be8fd6995  lea rdi, [rsp]
00007d5be8fd6999  mov esi, 0x00
00007d5be8fd699e  mov rax, 0x5D345705A530
00007d5be8fd69a8  call rax
00007d5be8fd69aa  movaps xmm7, [rsp]
00007d5be8fd69ae  add rsp, 0x30
00007d5be8fd69b2  vmovaps xmm0, [rsp]
00007d5be8fd69b7  vmovaps xmm1, [rsp+0x10]
00007d5be8fd69bd  vmovaps xmm2, [rsp+0x20]
00007d5be8fd69c3  vmovaps xmm3, [rsp+0x30]
00007d5be8fd69c9  vmovaps xmm4, [rsp+0x40]
00007d5be8fd69cf  vmovaps xmm5, [rsp+0x50]
00007d5be8fd69d5  vmovaps xmm6, [rsp+0x60]
00007d5be8fd69db  vmovaps xmm8, [rsp+0x70]
00007d5be8fd69e1  vmovaps xmm9, [rsp+0x80]
00007d5be8fd69ea  vmovaps xmm10, [rsp+0x90]
00007d5be8fd69f3  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd69fc  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd6a05  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd6a0e  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd6a17  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd6a20  add rsp, 0xF0
00007d5be8fd6a27  pop r11
00007d5be8fd6a29  pop r10
00007d5be8fd6a2b  pop r9
00007d5be8fd6a2d  pop r8
00007d5be8fd6a2f  pop rsi
00007d5be8fd6a30  pop rdi
00007d5be8fd6a31  pop rdx
00007d5be8fd6a32  pop rcx
00007d5be8fd6a33  pop rax
00007d5be8fd6a34  add rsp, 0x08
00007d5be8fd6a38  jmp 0x00007D5BE8FD59C8
00007d5be8fd6a3d  sub rsp, 0x08
00007d5be8fd6a41  push rax
00007d5be8fd6a42  push rcx
00007d5be8fd6a43  push rdx
00007d5be8fd6a44  push rdi
00007d5be8fd6a45  push rsi
00007d5be8fd6a46  push r8
00007d5be8fd6a48  push r9
00007d5be8fd6a4a  push r10
00007d5be8fd6a4c  push r11
00007d5be8fd6a4e  sub rsp, 0xF0
00007d5be8fd6a55  vmovaps [rsp], xmm0
00007d5be8fd6a5a  vmovaps [rsp+0x10], xmm1
00007d5be8fd6a60  vmovaps [rsp+0x20], xmm2
00007d5be8fd6a66  vmovaps [rsp+0x30], xmm3
00007d5be8fd6a6c  vmovaps [rsp+0x40], xmm4
00007d5be8fd6a72  vmovaps [rsp+0x50], xmm5
00007d5be8fd6a78  vmovaps [rsp+0x60], xmm6
00007d5be8fd6a7e  vmovaps [rsp+0x70], xmm7
00007d5be8fd6a84  vmovaps [rsp+0x80], xmm8
00007d5be8fd6a8d  vmovaps [rsp+0x90], xmm10
00007d5be8fd6a96  vmovaps [rsp+0xA0], xmm11
00007d5be8fd6a9f  vmovaps [rsp+0xB0], xmm12
00007d5be8fd6aa8  vmovaps [rsp+0xC0], xmm13
00007d5be8fd6ab1  vmovaps [rsp+0xD0], xmm14
00007d5be8fd6aba  vmovaps [rsp+0xE0], xmm15
00007d5be8fd6ac3  sub rsp, 0x30
00007d5be8fd6ac7  movaps [rsp], xmm9
00007d5be8fd6acc  movaps [rsp+0x10], xmm12
00007d5be8fd6ad2  movaps [rsp+0x20], xmm10
00007d5be8fd6ad8  lea rdi, [rsp]
00007d5be8fd6adc  mov esi, 0x00
00007d5be8fd6ae1  mov rax, 0x5D345705A530
00007d5be8fd6aeb  call rax
00007d5be8fd6aed  movaps xmm9, [rsp]
00007d5be8fd6af2  add rsp, 0x30
00007d5be8fd6af6  vmovaps xmm0, [rsp]
00007d5be8fd6afb  vmovaps xmm1, [rsp+0x10]
00007d5be8fd6b01  vmovaps xmm2, [rsp+0x20]
00007d5be8fd6b07  vmovaps xmm3, [rsp+0x30]
00007d5be8fd6b0d  vmovaps xmm4, [rsp+0x40]
00007d5be8fd6b13  vmovaps xmm5, [rsp+0x50]
00007d5be8fd6b19  vmovaps xmm6, [rsp+0x60]
00007d5be8fd6b1f  vmovaps xmm7, [rsp+0x70]
00007d5be8fd6b25  vmovaps xmm8, [rsp+0x80]
00007d5be8fd6b2e  vmovaps xmm10, [rsp+0x90]
00007d5be8fd6b37  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd6b40  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd6b49  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd6b52  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd6b5b  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd6b64  add rsp, 0xF0
00007d5be8fd6b6b  pop r11
00007d5be8fd6b6d  pop r10
00007d5be8fd6b6f  pop r9
00007d5be8fd6b71  pop r8
00007d5be8fd6b73  pop rsi
00007d5be8fd6b74  pop rdi
00007d5be8fd6b75  pop rdx
00007d5be8fd6b76  pop rcx
00007d5be8fd6b77  pop rax
00007d5be8fd6b78  add rsp, 0x08
00007d5be8fd6b7c  jmp 0x00007D5BE8FD59EC
00007d5be8fd6b81  sub rsp, 0x08
00007d5be8fd6b85  push rax
00007d5be8fd6b86  push rcx
00007d5be8fd6b87  push rdx
00007d5be8fd6b88  push rdi
00007d5be8fd6b89  push rsi
00007d5be8fd6b8a  push r8
00007d5be8fd6b8c  push r9
00007d5be8fd6b8e  push r10
00007d5be8fd6b90  push r11
00007d5be8fd6b92  sub rsp, 0xF0
00007d5be8fd6b99  vmovaps [rsp], xmm0
00007d5be8fd6b9e  vmovaps [rsp+0x10], xmm1
00007d5be8fd6ba4  vmovaps [rsp+0x20], xmm2
00007d5be8fd6baa  vmovaps [rsp+0x30], xmm3
00007d5be8fd6bb0  vmovaps [rsp+0x40], xmm4
00007d5be8fd6bb6  vmovaps [rsp+0x50], xmm5
00007d5be8fd6bbc  vmovaps [rsp+0x60], xmm6
00007d5be8fd6bc2  vmovaps [rsp+0x70], xmm7
00007d5be8fd6bc8  vmovaps [rsp+0x80], xmm8
00007d5be8fd6bd1  vmovaps [rsp+0x90], xmm9
00007d5be8fd6bda  vmovaps [rsp+0xA0], xmm11
00007d5be8fd6be3  vmovaps [rsp+0xB0], xmm12
00007d5be8fd6bec  vmovaps [rsp+0xC0], xmm13
00007d5be8fd6bf5  vmovaps [rsp+0xD0], xmm14
00007d5be8fd6bfe  vmovaps [rsp+0xE0], xmm15
00007d5be8fd6c07  sub rsp, 0x30
00007d5be8fd6c0b  movaps [rsp], xmm10
00007d5be8fd6c10  movaps [rsp+0x10], xmm12
00007d5be8fd6c16  movaps [rsp+0x20], xmm11
00007d5be8fd6c1c  lea rdi, [rsp]
00007d5be8fd6c20  mov esi, 0x00
00007d5be8fd6c25  mov rax, 0x5D345705A530
00007d5be8fd6c2f  call rax
00007d5be8fd6c31  movaps xmm10, [rsp]
00007d5be8fd6c36  add rsp, 0x30
00007d5be8fd6c3a  vmovaps xmm0, [rsp]
00007d5be8fd6c3f  vmovaps xmm1, [rsp+0x10]
00007d5be8fd6c45  vmovaps xmm2, [rsp+0x20]
00007d5be8fd6c4b  vmovaps xmm3, [rsp+0x30]
00007d5be8fd6c51  vmovaps xmm4, [rsp+0x40]
00007d5be8fd6c57  vmovaps xmm5, [rsp+0x50]
00007d5be8fd6c5d  vmovaps xmm6, [rsp+0x60]
00007d5be8fd6c63  vmovaps xmm7, [rsp+0x70]
00007d5be8fd6c69  vmovaps xmm8, [rsp+0x80]
00007d5be8fd6c72  vmovaps xmm9, [rsp+0x90]
00007d5be8fd6c7b  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd6c84  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd6c8d  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd6c96  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd6c9f  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd6ca8  add rsp, 0xF0
00007d5be8fd6caf  pop r11
00007d5be8fd6cb1  pop r10
00007d5be8fd6cb3  pop r9
00007d5be8fd6cb5  pop r8
00007d5be8fd6cb7  pop rsi
00007d5be8fd6cb8  pop rdi
00007d5be8fd6cb9  pop rdx
00007d5be8fd6cba  pop rcx
00007d5be8fd6cbb  pop rax
00007d5be8fd6cbc  add rsp, 0x08
00007d5be8fd6cc0  jmp 0x00007D5BE8FD5A06
00007d5be8fd6cc5  sub rsp, 0x08
00007d5be8fd6cc9  push rax
00007d5be8fd6cca  push rcx
00007d5be8fd6ccb  push rdx
00007d5be8fd6ccc  push rdi
00007d5be8fd6ccd  push rsi
00007d5be8fd6cce  push r8
00007d5be8fd6cd0  push r9
00007d5be8fd6cd2  push r10
00007d5be8fd6cd4  push r11
00007d5be8fd6cd6  sub rsp, 0xF0
00007d5be8fd6cdd  vmovaps [rsp], xmm0
00007d5be8fd6ce2  vmovaps [rsp+0x10], xmm1
00007d5be8fd6ce8  vmovaps [rsp+0x20], xmm2
00007d5be8fd6cee  vmovaps [rsp+0x30], xmm3
00007d5be8fd6cf4  vmovaps [rsp+0x40], xmm4
00007d5be8fd6cfa  vmovaps [rsp+0x50], xmm5
00007d5be8fd6d00  vmovaps [rsp+0x60], xmm7
00007d5be8fd6d06  vmovaps [rsp+0x70], xmm8
00007d5be8fd6d0c  vmovaps [rsp+0x80], xmm9
00007d5be8fd6d15  vmovaps [rsp+0x90], xmm10
00007d5be8fd6d1e  vmovaps [rsp+0xA0], xmm11
00007d5be8fd6d27  vmovaps [rsp+0xB0], xmm12
00007d5be8fd6d30  vmovaps [rsp+0xC0], xmm13
00007d5be8fd6d39  vmovaps [rsp+0xD0], xmm14
00007d5be8fd6d42  vmovaps [rsp+0xE0], xmm15
00007d5be8fd6d4b  sub rsp, 0x30
00007d5be8fd6d4f  movaps [rsp], xmm6
00007d5be8fd6d53  movaps [rsp+0x10], xmm12
00007d5be8fd6d59  movaps [rsp+0x20], xmm11
00007d5be8fd6d5f  lea rdi, [rsp]
00007d5be8fd6d63  mov esi, 0x00
00007d5be8fd6d68  mov rax, 0x5D345705A530
00007d5be8fd6d72  call rax
00007d5be8fd6d74  movaps xmm6, [rsp]
00007d5be8fd6d78  add rsp, 0x30
00007d5be8fd6d7c  vmovaps xmm0, [rsp]
00007d5be8fd6d81  vmovaps xmm1, [rsp+0x10]
00007d5be8fd6d87  vmovaps xmm2, [rsp+0x20]
00007d5be8fd6d8d  vmovaps xmm3, [rsp+0x30]
00007d5be8fd6d93  vmovaps xmm4, [rsp+0x40]
00007d5be8fd6d99  vmovaps xmm5, [rsp+0x50]
00007d5be8fd6d9f  vmovaps xmm7, [rsp+0x60]
00007d5be8fd6da5  vmovaps xmm8, [rsp+0x70]
00007d5be8fd6dab  vmovaps xmm9, [rsp+0x80]
00007d5be8fd6db4  vmovaps xmm10, [rsp+0x90]
00007d5be8fd6dbd  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd6dc6  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd6dcf  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd6dd8  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd6de1  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd6dea  add rsp, 0xF0
00007d5be8fd6df1  pop r11
00007d5be8fd6df3  pop r10
00007d5be8fd6df5  pop r9
00007d5be8fd6df7  pop r8
00007d5be8fd6df9  pop rsi
00007d5be8fd6dfa  pop rdi
00007d5be8fd6dfb  pop rdx
00007d5be8fd6dfc  pop rcx
00007d5be8fd6dfd  pop rax
00007d5be8fd6dfe  add rsp, 0x08
00007d5be8fd6e02  jmp 0x00007D5BE8FD5A27
00007d5be8fd6e07  sub rsp, 0x08
00007d5be8fd6e0b  push rax
00007d5be8fd6e0c  push rcx
00007d5be8fd6e0d  push rdx
00007d5be8fd6e0e  push rdi
00007d5be8fd6e0f  push rsi
00007d5be8fd6e10  push r8
00007d5be8fd6e12  push r9
00007d5be8fd6e14  push r10
00007d5be8fd6e16  push r11
00007d5be8fd6e18  sub rsp, 0xF0
00007d5be8fd6e1f  vmovaps [rsp], xmm0
00007d5be8fd6e24  vmovaps [rsp+0x10], xmm1
00007d5be8fd6e2a  vmovaps [rsp+0x20], xmm2
00007d5be8fd6e30  vmovaps [rsp+0x30], xmm4
00007d5be8fd6e36  vmovaps [rsp+0x40], xmm5
00007d5be8fd6e3c  vmovaps [rsp+0x50], xmm6
00007d5be8fd6e42  vmovaps [rsp+0x60], xmm7
00007d5be8fd6e48  vmovaps [rsp+0x70], xmm8
00007d5be8fd6e4e  vmovaps [rsp+0x80], xmm9
00007d5be8fd6e57  vmovaps [rsp+0x90], xmm10
00007d5be8fd6e60  vmovaps [rsp+0xA0], xmm11
00007d5be8fd6e69  vmovaps [rsp+0xB0], xmm12
00007d5be8fd6e72  vmovaps [rsp+0xC0], xmm13
00007d5be8fd6e7b  vmovaps [rsp+0xD0], xmm14
00007d5be8fd6e84  vmovaps [rsp+0xE0], xmm15
00007d5be8fd6e8d  sub rsp, 0x30
00007d5be8fd6e91  movaps [rsp], xmm3
00007d5be8fd6e95  movaps [rsp+0x10], xmm5
00007d5be8fd6e9a  movaps [rsp+0x20], xmm4
00007d5be8fd6e9f  lea rdi, [rsp]
00007d5be8fd6ea3  mov esi, 0x00
00007d5be8fd6ea8  mov rax, 0x5D345705A530
00007d5be8fd6eb2  call rax
00007d5be8fd6eb4  movaps xmm3, [rsp]
00007d5be8fd6eb8  add rsp, 0x30
00007d5be8fd6ebc  vmovaps xmm0, [rsp]
00007d5be8fd6ec1  vmovaps xmm1, [rsp+0x10]
00007d5be8fd6ec7  vmovaps xmm2, [rsp+0x20]
00007d5be8fd6ecd  vmovaps xmm4, [rsp+0x30]
00007d5be8fd6ed3  vmovaps xmm5, [rsp+0x40]
00007d5be8fd6ed9  vmovaps xmm6, [rsp+0x50]
00007d5be8fd6edf  vmovaps xmm7, [rsp+0x60]
00007d5be8fd6ee5  vmovaps xmm8, [rsp+0x70]
00007d5be8fd6eeb  vmovaps xmm9, [rsp+0x80]
00007d5be8fd6ef4  vmovaps xmm10, [rsp+0x90]
00007d5be8fd6efd  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd6f06  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd6f0f  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd6f18  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd6f21  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd6f2a  add rsp, 0xF0
00007d5be8fd6f31  pop r11
00007d5be8fd6f33  pop r10
00007d5be8fd6f35  pop r9
00007d5be8fd6f37  pop r8
00007d5be8fd6f39  pop rsi
00007d5be8fd6f3a  pop rdi
00007d5be8fd6f3b  pop rdx
00007d5be8fd6f3c  pop rcx
00007d5be8fd6f3d  pop rax
00007d5be8fd6f3e  add rsp, 0x08
00007d5be8fd6f42  jmp 0x00007D5BE8FD5A88
00007d5be8fd6f47  sub rsp, 0x08
00007d5be8fd6f4b  push rax
00007d5be8fd6f4c  push rcx
00007d5be8fd6f4d  push rdx
00007d5be8fd6f4e  push rdi
00007d5be8fd6f4f  push rsi
00007d5be8fd6f50  push r8
00007d5be8fd6f52  push r9
00007d5be8fd6f54  push r10
00007d5be8fd6f56  push r11
00007d5be8fd6f58  sub rsp, 0xF0
00007d5be8fd6f5f  vmovaps [rsp], xmm0
00007d5be8fd6f64  vmovaps [rsp+0x10], xmm1
00007d5be8fd6f6a  vmovaps [rsp+0x20], xmm2
00007d5be8fd6f70  vmovaps [rsp+0x30], xmm3
00007d5be8fd6f76  vmovaps [rsp+0x40], xmm4
00007d5be8fd6f7c  vmovaps [rsp+0x50], xmm6
00007d5be8fd6f82  vmovaps [rsp+0x60], xmm7
00007d5be8fd6f88  vmovaps [rsp+0x70], xmm8
00007d5be8fd6f8e  vmovaps [rsp+0x80], xmm9
00007d5be8fd6f97  vmovaps [rsp+0x90], xmm10
00007d5be8fd6fa0  vmovaps [rsp+0xA0], xmm11
00007d5be8fd6fa9  vmovaps [rsp+0xB0], xmm12
00007d5be8fd6fb2  vmovaps [rsp+0xC0], xmm13
00007d5be8fd6fbb  vmovaps [rsp+0xD0], xmm14
00007d5be8fd6fc4  vmovaps [rsp+0xE0], xmm15
00007d5be8fd6fcd  sub rsp, 0x30
00007d5be8fd6fd1  movaps [rsp], xmm5
00007d5be8fd6fd5  movaps [rsp+0x10], xmm8
00007d5be8fd6fdb  movaps [rsp+0x20], xmm15
00007d5be8fd6fe1  lea rdi, [rsp]
00007d5be8fd6fe5  mov esi, 0x00
00007d5be8fd6fea  mov rax, 0x5D345705A530
00007d5be8fd6ff4  call rax
00007d5be8fd6ff6  movaps xmm5, [rsp]
00007d5be8fd6ffa  add rsp, 0x30
00007d5be8fd6ffe  vmovaps xmm0, [rsp]
00007d5be8fd7003  vmovaps xmm1, [rsp+0x10]
00007d5be8fd7009  vmovaps xmm2, [rsp+0x20]
00007d5be8fd700f  vmovaps xmm3, [rsp+0x30]
00007d5be8fd7015  vmovaps xmm4, [rsp+0x40]
00007d5be8fd701b  vmovaps xmm6, [rsp+0x50]
00007d5be8fd7021  vmovaps xmm7, [rsp+0x60]
00007d5be8fd7027  vmovaps xmm8, [rsp+0x70]
00007d5be8fd702d  vmovaps xmm9, [rsp+0x80]
00007d5be8fd7036  vmovaps xmm10, [rsp+0x90]
00007d5be8fd703f  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd7048  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd7051  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd705a  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd7063  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd706c  add rsp, 0xF0
00007d5be8fd7073  pop r11
00007d5be8fd7075  pop r10
00007d5be8fd7077  pop r9
00007d5be8fd7079  pop r8
00007d5be8fd707b  pop rsi
00007d5be8fd707c  pop rdi
00007d5be8fd707d  pop rdx
00007d5be8fd707e  pop rcx
00007d5be8fd707f  pop rax
00007d5be8fd7080  add rsp, 0x08
00007d5be8fd7084  jmp 0x00007D5BE8FD5AC0
00007d5be8fd7089  sub rsp, 0x08
00007d5be8fd708d  push rax
00007d5be8fd708e  push rcx
00007d5be8fd708f  push rdx
00007d5be8fd7090  push rdi
00007d5be8fd7091  push rsi
00007d5be8fd7092  push r8
00007d5be8fd7094  push r9
00007d5be8fd7096  push r10
00007d5be8fd7098  push r11
00007d5be8fd709a  sub rsp, 0xF0
00007d5be8fd70a1  vmovaps [rsp], xmm0
00007d5be8fd70a6  vmovaps [rsp+0x10], xmm1
00007d5be8fd70ac  vmovaps [rsp+0x20], xmm2
00007d5be8fd70b2  vmovaps [rsp+0x30], xmm3
00007d5be8fd70b8  vmovaps [rsp+0x40], xmm5
00007d5be8fd70be  vmovaps [rsp+0x50], xmm6
00007d5be8fd70c4  vmovaps [rsp+0x60], xmm7
00007d5be8fd70ca  vmovaps [rsp+0x70], xmm8
00007d5be8fd70d0  vmovaps [rsp+0x80], xmm9
00007d5be8fd70d9  vmovaps [rsp+0x90], xmm10
00007d5be8fd70e2  vmovaps [rsp+0xA0], xmm11
00007d5be8fd70eb  vmovaps [rsp+0xB0], xmm12
00007d5be8fd70f4  vmovaps [rsp+0xC0], xmm13
00007d5be8fd70fd  vmovaps [rsp+0xD0], xmm14
00007d5be8fd7106  vmovaps [rsp+0xE0], xmm15
00007d5be8fd710f  sub rsp, 0x30
00007d5be8fd7113  movaps [rsp], xmm4
00007d5be8fd7117  movaps [rsp+0x10], xmm9
00007d5be8fd711d  movaps [rsp+0x20], xmm8
00007d5be8fd7123  lea rdi, [rsp]
00007d5be8fd7127  mov esi, 0x00
00007d5be8fd712c  mov rax, 0x5D345705A530
00007d5be8fd7136  call rax
00007d5be8fd7138  movaps xmm4, [rsp]
00007d5be8fd713c  add rsp, 0x30
00007d5be8fd7140  vmovaps xmm0, [rsp]
00007d5be8fd7145  vmovaps xmm1, [rsp+0x10]
00007d5be8fd714b  vmovaps xmm2, [rsp+0x20]
00007d5be8fd7151  vmovaps xmm3, [rsp+0x30]
00007d5be8fd7157  vmovaps xmm5, [rsp+0x40]
00007d5be8fd715d  vmovaps xmm6, [rsp+0x50]
00007d5be8fd7163  vmovaps xmm7, [rsp+0x60]
00007d5be8fd7169  vmovaps xmm8, [rsp+0x70]
00007d5be8fd716f  vmovaps xmm9, [rsp+0x80]
00007d5be8fd7178  vmovaps xmm10, [rsp+0x90]
00007d5be8fd7181  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd718a  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd7193  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd719c  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd71a5  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd71ae  add rsp, 0xF0
00007d5be8fd71b5  pop r11
00007d5be8fd71b7  pop r10
00007d5be8fd71b9  pop r9
00007d5be8fd71bb  pop r8
00007d5be8fd71bd  pop rsi
00007d5be8fd71be  pop rdi
00007d5be8fd71bf  pop rdx
00007d5be8fd71c0  pop rcx
00007d5be8fd71c1  pop rax
00007d5be8fd71c2  add rsp, 0x08
00007d5be8fd71c6  jmp 0x00007D5BE8FD5AE1
00007d5be8fd71cb  sub rsp, 0x08
00007d5be8fd71cf  push rax
00007d5be8fd71d0  push rcx
00007d5be8fd71d1  push rdx
00007d5be8fd71d2  push rdi
00007d5be8fd71d3  push rsi
00007d5be8fd71d4  push r8
00007d5be8fd71d6  push r9
00007d5be8fd71d8  push r10
00007d5be8fd71da  push r11
00007d5be8fd71dc  sub rsp, 0xF0
00007d5be8fd71e3  vmovaps [rsp], xmm0
00007d5be8fd71e8  vmovaps [rsp+0x10], xmm1
00007d5be8fd71ee  vmovaps [rsp+0x20], xmm2
00007d5be8fd71f4  vmovaps [rsp+0x30], xmm3
00007d5be8fd71fa  vmovaps [rsp+0x40], xmm4
00007d5be8fd7200  vmovaps [rsp+0x50], xmm5
00007d5be8fd7206  vmovaps [rsp+0x60], xmm6
00007d5be8fd720c  vmovaps [rsp+0x70], xmm7
00007d5be8fd7212  vmovaps [rsp+0x80], xmm8
00007d5be8fd721b  vmovaps [rsp+0x90], xmm10
00007d5be8fd7224  vmovaps [rsp+0xA0], xmm11
00007d5be8fd722d  vmovaps [rsp+0xB0], xmm12
00007d5be8fd7236  vmovaps [rsp+0xC0], xmm13
00007d5be8fd723f  vmovaps [rsp+0xD0], xmm14
00007d5be8fd7248  vmovaps [rsp+0xE0], xmm15
00007d5be8fd7251  sub rsp, 0x30
00007d5be8fd7255  movaps [rsp], xmm9
00007d5be8fd725a  movaps [rsp+0x10], xmm10
00007d5be8fd7260  movaps [rsp+0x20], xmm8
00007d5be8fd7266  lea rdi, [rsp]
00007d5be8fd726a  mov esi, 0x00
00007d5be8fd726f  mov rax, 0x5D345705A530
00007d5be8fd7279  call rax
00007d5be8fd727b  movaps xmm9, [rsp]
00007d5be8fd7280  add rsp, 0x30
00007d5be8fd7284  vmovaps xmm0, [rsp]
00007d5be8fd7289  vmovaps xmm1, [rsp+0x10]
00007d5be8fd728f  vmovaps xmm2, [rsp+0x20]
00007d5be8fd7295  vmovaps xmm3, [rsp+0x30]
00007d5be8fd729b  vmovaps xmm4, [rsp+0x40]
00007d5be8fd72a1  vmovaps xmm5, [rsp+0x50]
00007d5be8fd72a7  vmovaps xmm6, [rsp+0x60]
00007d5be8fd72ad  vmovaps xmm7, [rsp+0x70]
00007d5be8fd72b3  vmovaps xmm8, [rsp+0x80]
00007d5be8fd72bc  vmovaps xmm10, [rsp+0x90]
00007d5be8fd72c5  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd72ce  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd72d7  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd72e0  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd72e9  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd72f2  add rsp, 0xF0
00007d5be8fd72f9  pop r11
00007d5be8fd72fb  pop r10
00007d5be8fd72fd  pop r9
00007d5be8fd72ff  pop r8
00007d5be8fd7301  pop rsi
00007d5be8fd7302  pop rdi
00007d5be8fd7303  pop rdx
00007d5be8fd7304  pop rcx
00007d5be8fd7305  pop rax
00007d5be8fd7306  add rsp, 0x08
00007d5be8fd730a  jmp 0x00007D5BE8FD5AFB
00007d5be8fd730f  call 0x00007D5BE8ED64F0
00007d5be8fd7314  jmp 0x00007D5BE8FD5C15
00007d5be8fd7319  call 0x00007D5BE8ED64F0
00007d5be8fd731e  jmp 0x00007D5BE8FD5C2B
00007d5be8fd7323  sub rsp, 0x08
00007d5be8fd7327  push rax
00007d5be8fd7328  push rcx
00007d5be8fd7329  push rdx
00007d5be8fd732a  push rdi
00007d5be8fd732b  push rsi
00007d5be8fd732c  push r8
00007d5be8fd732e  push r9
00007d5be8fd7330  push r10
00007d5be8fd7332  push r11
00007d5be8fd7334  sub rsp, 0xF0
00007d5be8fd733b  vmovaps [rsp], xmm0
00007d5be8fd7340  vmovaps [rsp+0x10], xmm2
00007d5be8fd7346  vmovaps [rsp+0x20], xmm3
00007d5be8fd734c  vmovaps [rsp+0x30], xmm4
00007d5be8fd7352  vmovaps [rsp+0x40], xmm5
00007d5be8fd7358  vmovaps [rsp+0x50], xmm6
00007d5be8fd735e  vmovaps [rsp+0x60], xmm7
00007d5be8fd7364  vmovaps [rsp+0x70], xmm8
00007d5be8fd736a  vmovaps [rsp+0x80], xmm9
00007d5be8fd7373  vmovaps [rsp+0x90], xmm10
00007d5be8fd737c  vmovaps [rsp+0xA0], xmm11
00007d5be8fd7385  vmovaps [rsp+0xB0], xmm12
00007d5be8fd738e  vmovaps [rsp+0xC0], xmm13
00007d5be8fd7397  vmovaps [rsp+0xD0], xmm14
00007d5be8fd73a0  vmovaps [rsp+0xE0], xmm15
00007d5be8fd73a9  sub rsp, 0x30
00007d5be8fd73ad  movaps [rsp], xmm1
00007d5be8fd73b1  movaps [rsp+0x10], xmm6
00007d5be8fd73b6  movaps [rsp+0x20], xmm15
00007d5be8fd73bc  lea rdi, [rsp]
00007d5be8fd73c0  mov esi, 0x00
00007d5be8fd73c5  mov rax, 0x5D345705A530
00007d5be8fd73cf  call rax
00007d5be8fd73d1  movaps xmm1, [rsp]
00007d5be8fd73d5  add rsp, 0x30
00007d5be8fd73d9  vmovaps xmm0, [rsp]
00007d5be8fd73de  vmovaps xmm2, [rsp+0x10]
00007d5be8fd73e4  vmovaps xmm3, [rsp+0x20]
00007d5be8fd73ea  vmovaps xmm4, [rsp+0x30]
00007d5be8fd73f0  vmovaps xmm5, [rsp+0x40]
00007d5be8fd73f6  vmovaps xmm6, [rsp+0x50]
00007d5be8fd73fc  vmovaps xmm7, [rsp+0x60]
00007d5be8fd7402  vmovaps xmm8, [rsp+0x70]
00007d5be8fd7408  vmovaps xmm9, [rsp+0x80]
00007d5be8fd7411  vmovaps xmm10, [rsp+0x90]
00007d5be8fd741a  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd7423  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd742c  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd7435  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd743e  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd7447  add rsp, 0xF0
00007d5be8fd744e  pop r11
00007d5be8fd7450  pop r10
00007d5be8fd7452  pop r9
00007d5be8fd7454  pop r8
00007d5be8fd7456  pop rsi
00007d5be8fd7457  pop rdi
00007d5be8fd7458  pop rdx
00007d5be8fd7459  pop rcx
00007d5be8fd745a  pop rax
00007d5be8fd745b  add rsp, 0x08
00007d5be8fd745f  jmp 0x00007D5BE8FD5C68
00007d5be8fd7464  call 0x00007D5BE8EE5820
00007d5be8fd7469  jmp 0x00007D5BE8FD5C75
00007d5be8fd746e  sub rsp, 0x08
00007d5be8fd7472  push rax
00007d5be8fd7473  push rcx
00007d5be8fd7474  push rdx
00007d5be8fd7475  push rdi
00007d5be8fd7476  push rsi
00007d5be8fd7477  push r8
00007d5be8fd7479  push r9
00007d5be8fd747b  push r10
00007d5be8fd747d  push r11
00007d5be8fd747f  sub rsp, 0xF0
00007d5be8fd7486  vmovaps [rsp], xmm0
00007d5be8fd748b  vmovaps [rsp+0x10], xmm1
00007d5be8fd7491  vmovaps [rsp+0x20], xmm2
00007d5be8fd7497  vmovaps [rsp+0x30], xmm3
00007d5be8fd749d  vmovaps [rsp+0x40], xmm4
00007d5be8fd74a3  vmovaps [rsp+0x50], xmm5
00007d5be8fd74a9  vmovaps [rsp+0x60], xmm6
00007d5be8fd74af  vmovaps [rsp+0x70], xmm7
00007d5be8fd74b5  vmovaps [rsp+0x80], xmm8
00007d5be8fd74be  vmovaps [rsp+0x90], xmm9
00007d5be8fd74c7  vmovaps [rsp+0xA0], xmm10
00007d5be8fd74d0  vmovaps [rsp+0xB0], xmm11
00007d5be8fd74d9  vmovaps [rsp+0xC0], xmm12
00007d5be8fd74e2  vmovaps [rsp+0xD0], xmm13
00007d5be8fd74eb  vmovaps [rsp+0xE0], xmm15
00007d5be8fd74f4  sub rsp, 0x30
00007d5be8fd74f8  movaps [rsp], xmm14
00007d5be8fd74fd  movaps [rsp+0x10], xmm4
00007d5be8fd7502  movaps [rsp+0x20], xmm3
00007d5be8fd7507  lea rdi, [rsp]
00007d5be8fd750b  mov esi, 0x00
00007d5be8fd7510  mov rax, 0x5D345705A530
00007d5be8fd751a  call rax
00007d5be8fd751c  movaps xmm14, [rsp]
00007d5be8fd7521  add rsp, 0x30
00007d5be8fd7525  vmovaps xmm0, [rsp]
00007d5be8fd752a  vmovaps xmm1, [rsp+0x10]
00007d5be8fd7530  vmovaps xmm2, [rsp+0x20]
00007d5be8fd7536  vmovaps xmm3, [rsp+0x30]
00007d5be8fd753c  vmovaps xmm4, [rsp+0x40]
00007d5be8fd7542  vmovaps xmm5, [rsp+0x50]
00007d5be8fd7548  vmovaps xmm6, [rsp+0x60]
00007d5be8fd754e  vmovaps xmm7, [rsp+0x70]
00007d5be8fd7554  vmovaps xmm8, [rsp+0x80]
00007d5be8fd755d  vmovaps xmm9, [rsp+0x90]
00007d5be8fd7566  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd756f  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd7578  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd7581  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd758a  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd7593  add rsp, 0xF0
00007d5be8fd759a  pop r11
00007d5be8fd759c  pop r10
00007d5be8fd759e  pop r9
00007d5be8fd75a0  pop r8
00007d5be8fd75a2  pop rsi
00007d5be8fd75a3  pop rdi
00007d5be8fd75a4  pop rdx
00007d5be8fd75a5  pop rcx
00007d5be8fd75a6  pop rax
00007d5be8fd75a7  add rsp, 0x08
00007d5be8fd75ab  jmp 0x00007D5BE8FD5C8F
00007d5be8fd75b0  sub rsp, 0x08
00007d5be8fd75b4  push rax
00007d5be8fd75b5  push rcx
00007d5be8fd75b6  push rdx
00007d5be8fd75b7  push rdi
00007d5be8fd75b8  push rsi
00007d5be8fd75b9  push r8
00007d5be8fd75bb  push r9
00007d5be8fd75bd  push r10
00007d5be8fd75bf  push r11
00007d5be8fd75c1  sub rsp, 0xF0
00007d5be8fd75c8  vmovaps [rsp], xmm0
00007d5be8fd75cd  vmovaps [rsp+0x10], xmm1
00007d5be8fd75d3  vmovaps [rsp+0x20], xmm2
00007d5be8fd75d9  vmovaps [rsp+0x30], xmm3
00007d5be8fd75df  vmovaps [rsp+0x40], xmm4
00007d5be8fd75e5  vmovaps [rsp+0x50], xmm5
00007d5be8fd75eb  vmovaps [rsp+0x60], xmm7
00007d5be8fd75f1  vmovaps [rsp+0x70], xmm8
00007d5be8fd75f7  vmovaps [rsp+0x80], xmm9
00007d5be8fd7600  vmovaps [rsp+0x90], xmm10
00007d5be8fd7609  vmovaps [rsp+0xA0], xmm11
00007d5be8fd7612  vmovaps [rsp+0xB0], xmm12
00007d5be8fd761b  vmovaps [rsp+0xC0], xmm13
00007d5be8fd7624  vmovaps [rsp+0xD0], xmm14
00007d5be8fd762d  vmovaps [rsp+0xE0], xmm15
00007d5be8fd7636  sub rsp, 0x30
00007d5be8fd763a  movaps [rsp], xmm6
00007d5be8fd763e  movaps [rsp+0x10], xmm9
00007d5be8fd7644  movaps [rsp+0x20], xmm7
00007d5be8fd7649  lea rdi, [rsp]
00007d5be8fd764d  mov esi, 0x00
00007d5be8fd7652  mov rax, 0x5D345705A530
00007d5be8fd765c  call rax
00007d5be8fd765e  movaps xmm6, [rsp]
00007d5be8fd7662  add rsp, 0x30
00007d5be8fd7666  vmovaps xmm0, [rsp]
00007d5be8fd766b  vmovaps xmm1, [rsp+0x10]
00007d5be8fd7671  vmovaps xmm2, [rsp+0x20]
00007d5be8fd7677  vmovaps xmm3, [rsp+0x30]
00007d5be8fd767d  vmovaps xmm4, [rsp+0x40]
00007d5be8fd7683  vmovaps xmm5, [rsp+0x50]
00007d5be8fd7689  vmovaps xmm7, [rsp+0x60]
00007d5be8fd768f  vmovaps xmm8, [rsp+0x70]
00007d5be8fd7695  vmovaps xmm9, [rsp+0x80]
00007d5be8fd769e  vmovaps xmm10, [rsp+0x90]
00007d5be8fd76a7  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd76b0  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd76b9  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd76c2  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd76cb  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd76d4  add rsp, 0xF0
00007d5be8fd76db  pop r11
00007d5be8fd76dd  pop r10
00007d5be8fd76df  pop r9
00007d5be8fd76e1  pop r8
00007d5be8fd76e3  pop rsi
00007d5be8fd76e4  pop rdi
00007d5be8fd76e5  pop rdx
00007d5be8fd76e6  pop rcx
00007d5be8fd76e7  pop rax
00007d5be8fd76e8  add rsp, 0x08
00007d5be8fd76ec  jmp 0x00007D5BE8FD5CA7
00007d5be8fd76f1  sub rsp, 0x08
00007d5be8fd76f5  push rax
00007d5be8fd76f6  push rcx
00007d5be8fd76f7  push rdx
00007d5be8fd76f8  push rdi
00007d5be8fd76f9  push rsi
00007d5be8fd76fa  push r8
00007d5be8fd76fc  push r9
00007d5be8fd76fe  push r10
00007d5be8fd7700  push r11
00007d5be8fd7702  sub rsp, 0xF0
00007d5be8fd7709  vmovaps [rsp], xmm0
00007d5be8fd770e  vmovaps [rsp+0x10], xmm1
00007d5be8fd7714  vmovaps [rsp+0x20], xmm2
00007d5be8fd771a  vmovaps [rsp+0x30], xmm3
00007d5be8fd7720  vmovaps [rsp+0x40], xmm4
00007d5be8fd7726  vmovaps [rsp+0x50], xmm5
00007d5be8fd772c  vmovaps [rsp+0x60], xmm6
00007d5be8fd7732  vmovaps [rsp+0x70], xmm8
00007d5be8fd7738  vmovaps [rsp+0x80], xmm9
00007d5be8fd7741  vmovaps [rsp+0x90], xmm10
00007d5be8fd774a  vmovaps [rsp+0xA0], xmm11
00007d5be8fd7753  vmovaps [rsp+0xB0], xmm12
00007d5be8fd775c  vmovaps [rsp+0xC0], xmm13
00007d5be8fd7765  vmovaps [rsp+0xD0], xmm14
00007d5be8fd776e  vmovaps [rsp+0xE0], xmm15
00007d5be8fd7777  sub rsp, 0x30
00007d5be8fd777b  movaps [rsp], xmm7
00007d5be8fd777f  movaps [rsp+0x10], xmm4
00007d5be8fd7784  movaps [rsp+0x20], xmm9
00007d5be8fd778a  lea rdi, [rsp]
00007d5be8fd778e  mov esi, 0x00
00007d5be8fd7793  mov rax, 0x5D345705A530
00007d5be8fd779d  call rax
00007d5be8fd779f  movaps xmm7, [rsp]
00007d5be8fd77a3  add rsp, 0x30
00007d5be8fd77a7  vmovaps xmm0, [rsp]
00007d5be8fd77ac  vmovaps xmm1, [rsp+0x10]
00007d5be8fd77b2  vmovaps xmm2, [rsp+0x20]
00007d5be8fd77b8  vmovaps xmm3, [rsp+0x30]
00007d5be8fd77be  vmovaps xmm4, [rsp+0x40]
00007d5be8fd77c4  vmovaps xmm5, [rsp+0x50]
00007d5be8fd77ca  vmovaps xmm6, [rsp+0x60]
00007d5be8fd77d0  vmovaps xmm8, [rsp+0x70]
00007d5be8fd77d6  vmovaps xmm9, [rsp+0x80]
00007d5be8fd77df  vmovaps xmm10, [rsp+0x90]
00007d5be8fd77e8  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd77f1  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd77fa  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd7803  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd780c  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd7815  add rsp, 0xF0
00007d5be8fd781c  pop r11
00007d5be8fd781e  pop r10
00007d5be8fd7820  pop r9
00007d5be8fd7822  pop r8
00007d5be8fd7824  pop rsi
00007d5be8fd7825  pop rdi
00007d5be8fd7826  pop rdx
00007d5be8fd7827  pop rcx
00007d5be8fd7828  pop rax
00007d5be8fd7829  add rsp, 0x08
00007d5be8fd782d  jmp 0x00007D5BE8FD5CD4
00007d5be8fd7832  sub rsp, 0x08
00007d5be8fd7836  push rax
00007d5be8fd7837  push rcx
00007d5be8fd7838  push rdx
00007d5be8fd7839  push rdi
00007d5be8fd783a  push rsi
00007d5be8fd783b  push r8
00007d5be8fd783d  push r9
00007d5be8fd783f  push r10
00007d5be8fd7841  push r11
00007d5be8fd7843  sub rsp, 0xF0
00007d5be8fd784a  vmovaps [rsp], xmm0
00007d5be8fd784f  vmovaps [rsp+0x10], xmm1
00007d5be8fd7855  vmovaps [rsp+0x20], xmm2
00007d5be8fd785b  vmovaps [rsp+0x30], xmm3
00007d5be8fd7861  vmovaps [rsp+0x40], xmm5
00007d5be8fd7867  vmovaps [rsp+0x50], xmm6
00007d5be8fd786d  vmovaps [rsp+0x60], xmm7
00007d5be8fd7873  vmovaps [rsp+0x70], xmm8
00007d5be8fd7879  vmovaps [rsp+0x80], xmm9
00007d5be8fd7882  vmovaps [rsp+0x90], xmm10
00007d5be8fd788b  vmovaps [rsp+0xA0], xmm11
00007d5be8fd7894  vmovaps [rsp+0xB0], xmm12
00007d5be8fd789d  vmovaps [rsp+0xC0], xmm13
00007d5be8fd78a6  vmovaps [rsp+0xD0], xmm14
00007d5be8fd78af  vmovaps [rsp+0xE0], xmm15
00007d5be8fd78b8  sub rsp, 0x30
00007d5be8fd78bc  movaps [rsp], xmm4
00007d5be8fd78c0  movaps [rsp+0x10], xmm15
00007d5be8fd78c6  movaps [rsp+0x20], xmm9
00007d5be8fd78cc  lea rdi, [rsp]
00007d5be8fd78d0  mov esi, 0x00
00007d5be8fd78d5  mov rax, 0x5D345705A530
00007d5be8fd78df  call rax
00007d5be8fd78e1  movaps xmm4, [rsp]
00007d5be8fd78e5  add rsp, 0x30
00007d5be8fd78e9  vmovaps xmm0, [rsp]
00007d5be8fd78ee  vmovaps xmm1, [rsp+0x10]
00007d5be8fd78f4  vmovaps xmm2, [rsp+0x20]
00007d5be8fd78fa  vmovaps xmm3, [rsp+0x30]
00007d5be8fd7900  vmovaps xmm5, [rsp+0x40]
00007d5be8fd7906  vmovaps xmm6, [rsp+0x50]
00007d5be8fd790c  vmovaps xmm7, [rsp+0x60]
00007d5be8fd7912  vmovaps xmm8, [rsp+0x70]
00007d5be8fd7918  vmovaps xmm9, [rsp+0x80]
00007d5be8fd7921  vmovaps xmm10, [rsp+0x90]
00007d5be8fd792a  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd7933  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd793c  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd7945  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd794e  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd7957  add rsp, 0xF0
00007d5be8fd795e  pop r11
00007d5be8fd7960  pop r10
00007d5be8fd7962  pop r9
00007d5be8fd7964  pop r8
00007d5be8fd7966  pop rsi
00007d5be8fd7967  pop rdi
00007d5be8fd7968  pop rdx
00007d5be8fd7969  pop rcx
00007d5be8fd796a  pop rax
00007d5be8fd796b  add rsp, 0x08
00007d5be8fd796f  jmp 0x00007D5BE8FD5CF9
00007d5be8fd7974  call 0x00007D5BE8EE5820
00007d5be8fd7979  jmp 0x00007D5BE8FD5D06
00007d5be8fd797e  sub rsp, 0x08
00007d5be8fd7982  push rax
00007d5be8fd7983  push rcx
00007d5be8fd7984  push rdx
00007d5be8fd7985  push rdi
00007d5be8fd7986  push rsi
00007d5be8fd7987  push r8
00007d5be8fd7989  push r9
00007d5be8fd798b  push r10
00007d5be8fd798d  push r11
00007d5be8fd798f  sub rsp, 0xF0
00007d5be8fd7996  vmovaps [rsp], xmm0
00007d5be8fd799b  vmovaps [rsp+0x10], xmm1
00007d5be8fd79a1  vmovaps [rsp+0x20], xmm2
00007d5be8fd79a7  vmovaps [rsp+0x30], xmm4
00007d5be8fd79ad  vmovaps [rsp+0x40], xmm5
00007d5be8fd79b3  vmovaps [rsp+0x50], xmm6
00007d5be8fd79b9  vmovaps [rsp+0x60], xmm7
00007d5be8fd79bf  vmovaps [rsp+0x70], xmm8
00007d5be8fd79c5  vmovaps [rsp+0x80], xmm9
00007d5be8fd79ce  vmovaps [rsp+0x90], xmm10
00007d5be8fd79d7  vmovaps [rsp+0xA0], xmm11
00007d5be8fd79e0  vmovaps [rsp+0xB0], xmm12
00007d5be8fd79e9  vmovaps [rsp+0xC0], xmm13
00007d5be8fd79f2  vmovaps [rsp+0xD0], xmm14
00007d5be8fd79fb  vmovaps [rsp+0xE0], xmm15
00007d5be8fd7a04  sub rsp, 0x30
00007d5be8fd7a08  movaps [rsp], xmm3
00007d5be8fd7a0c  movaps [rsp+0x10], xmm1
00007d5be8fd7a11  movaps [rsp+0x20], xmm9
00007d5be8fd7a17  lea rdi, [rsp]
00007d5be8fd7a1b  mov esi, 0x00
00007d5be8fd7a20  mov rax, 0x5D345705A530
00007d5be8fd7a2a  call rax
00007d5be8fd7a2c  movaps xmm3, [rsp]
00007d5be8fd7a30  add rsp, 0x30
00007d5be8fd7a34  vmovaps xmm0, [rsp]
00007d5be8fd7a39  vmovaps xmm1, [rsp+0x10]
00007d5be8fd7a3f  vmovaps xmm2, [rsp+0x20]
00007d5be8fd7a45  vmovaps xmm4, [rsp+0x30]
00007d5be8fd7a4b  vmovaps xmm5, [rsp+0x40]
00007d5be8fd7a51  vmovaps xmm6, [rsp+0x50]
00007d5be8fd7a57  vmovaps xmm7, [rsp+0x60]
00007d5be8fd7a5d  vmovaps xmm8, [rsp+0x70]
00007d5be8fd7a63  vmovaps xmm9, [rsp+0x80]
00007d5be8fd7a6c  vmovaps xmm10, [rsp+0x90]
00007d5be8fd7a75  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd7a7e  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd7a87  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd7a90  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd7a99  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd7aa2  add rsp, 0xF0
00007d5be8fd7aa9  pop r11
00007d5be8fd7aab  pop r10
00007d5be8fd7aad  pop r9
00007d5be8fd7aaf  pop r8
00007d5be8fd7ab1  pop rsi
00007d5be8fd7ab2  pop rdi
00007d5be8fd7ab3  pop rdx
00007d5be8fd7ab4  pop rcx
00007d5be8fd7ab5  pop rax
00007d5be8fd7ab6  add rsp, 0x08
00007d5be8fd7aba  jmp 0x00007D5BE8FD5D43
00007d5be8fd7abf  sub rsp, 0x08
00007d5be8fd7ac3  push rax
00007d5be8fd7ac4  push rcx
00007d5be8fd7ac5  push rdx
00007d5be8fd7ac6  push rdi
00007d5be8fd7ac7  push rsi
00007d5be8fd7ac8  push r8
00007d5be8fd7aca  push r9
00007d5be8fd7acc  push r10
00007d5be8fd7ace  push r11
00007d5be8fd7ad0  sub rsp, 0xF0
00007d5be8fd7ad7  vmovaps [rsp], xmm0
00007d5be8fd7adc  vmovaps [rsp+0x10], xmm2
00007d5be8fd7ae2  vmovaps [rsp+0x20], xmm3
00007d5be8fd7ae8  vmovaps [rsp+0x30], xmm4
00007d5be8fd7aee  vmovaps [rsp+0x40], xmm5
00007d5be8fd7af4  vmovaps [rsp+0x50], xmm6
00007d5be8fd7afa  vmovaps [rsp+0x60], xmm7
00007d5be8fd7b00  vmovaps [rsp+0x70], xmm8
00007d5be8fd7b06  vmovaps [rsp+0x80], xmm9
00007d5be8fd7b0f  vmovaps [rsp+0x90], xmm10
00007d5be8fd7b18  vmovaps [rsp+0xA0], xmm11
00007d5be8fd7b21  vmovaps [rsp+0xB0], xmm12
00007d5be8fd7b2a  vmovaps [rsp+0xC0], xmm13
00007d5be8fd7b33  vmovaps [rsp+0xD0], xmm14
00007d5be8fd7b3c  vmovaps [rsp+0xE0], xmm15
00007d5be8fd7b45  sub rsp, 0x30
00007d5be8fd7b49  movaps [rsp], xmm1
00007d5be8fd7b4d  movaps [rsp+0x10], xmm15
00007d5be8fd7b53  movaps [rsp+0x20], xmm9
00007d5be8fd7b59  lea rdi, [rsp]
00007d5be8fd7b5d  mov esi, 0x00
00007d5be8fd7b62  mov rax, 0x5D345705A530
00007d5be8fd7b6c  call rax
00007d5be8fd7b6e  movaps xmm1, [rsp]
00007d5be8fd7b72  add rsp, 0x30
00007d5be8fd7b76  vmovaps xmm0, [rsp]
00007d5be8fd7b7b  vmovaps xmm2, [rsp+0x10]
00007d5be8fd7b81  vmovaps xmm3, [rsp+0x20]
00007d5be8fd7b87  vmovaps xmm4, [rsp+0x30]
00007d5be8fd7b8d  vmovaps xmm5, [rsp+0x40]
00007d5be8fd7b93  vmovaps xmm6, [rsp+0x50]
00007d5be8fd7b99  vmovaps xmm7, [rsp+0x60]
00007d5be8fd7b9f  vmovaps xmm8, [rsp+0x70]
00007d5be8fd7ba5  vmovaps xmm9, [rsp+0x80]
00007d5be8fd7bae  vmovaps xmm10, [rsp+0x90]
00007d5be8fd7bb7  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd7bc0  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd7bc9  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd7bd2  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd7bdb  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd7be4  add rsp, 0xF0
00007d5be8fd7beb  pop r11
00007d5be8fd7bed  pop r10
00007d5be8fd7bef  pop r9
00007d5be8fd7bf1  pop r8
00007d5be8fd7bf3  pop rsi
00007d5be8fd7bf4  pop rdi
00007d5be8fd7bf5  pop rdx
00007d5be8fd7bf6  pop rcx
00007d5be8fd7bf7  pop rax
00007d5be8fd7bf8  add rsp, 0x08
00007d5be8fd7bfc  jmp 0x00007D5BE8FD5DCB
00007d5be8fd7c01  call 0x00007D5BE8EE5820
00007d5be8fd7c06  jmp 0x00007D5BE8FD5DD8
00007d5be8fd7c0b  sub rsp, 0x08
00007d5be8fd7c0f  push rax
00007d5be8fd7c10  push rcx
00007d5be8fd7c11  push rdx
00007d5be8fd7c12  push rdi
00007d5be8fd7c13  push rsi
00007d5be8fd7c14  push r8
00007d5be8fd7c16  push r9
00007d5be8fd7c18  push r10
00007d5be8fd7c1a  push r11
00007d5be8fd7c1c  sub rsp, 0xF0
00007d5be8fd7c23  vmovaps [rsp], xmm0
00007d5be8fd7c28  vmovaps [rsp+0x10], xmm2
00007d5be8fd7c2e  vmovaps [rsp+0x20], xmm3
00007d5be8fd7c34  vmovaps [rsp+0x30], xmm4
00007d5be8fd7c3a  vmovaps [rsp+0x40], xmm5
00007d5be8fd7c40  vmovaps [rsp+0x50], xmm6
00007d5be8fd7c46  vmovaps [rsp+0x60], xmm7
00007d5be8fd7c4c  vmovaps [rsp+0x70], xmm8
00007d5be8fd7c52  vmovaps [rsp+0x80], xmm9
00007d5be8fd7c5b  vmovaps [rsp+0x90], xmm10
00007d5be8fd7c64  vmovaps [rsp+0xA0], xmm11
00007d5be8fd7c6d  vmovaps [rsp+0xB0], xmm12
00007d5be8fd7c76  vmovaps [rsp+0xC0], xmm13
00007d5be8fd7c7f  vmovaps [rsp+0xD0], xmm14
00007d5be8fd7c88  vmovaps [rsp+0xE0], xmm15
00007d5be8fd7c91  sub rsp, 0x30
00007d5be8fd7c95  movaps [rsp], xmm1
00007d5be8fd7c99  movaps [rsp+0x10], xmm5
00007d5be8fd7c9e  movaps [rsp+0x20], xmm7
00007d5be8fd7ca3  lea rdi, [rsp]
00007d5be8fd7ca7  mov esi, 0x00
00007d5be8fd7cac  mov rax, 0x5D345705A530
00007d5be8fd7cb6  call rax
00007d5be8fd7cb8  movaps xmm1, [rsp]
00007d5be8fd7cbc  add rsp, 0x30
00007d5be8fd7cc0  vmovaps xmm0, [rsp]
00007d5be8fd7cc5  vmovaps xmm2, [rsp+0x10]
00007d5be8fd7ccb  vmovaps xmm3, [rsp+0x20]
00007d5be8fd7cd1  vmovaps xmm4, [rsp+0x30]
00007d5be8fd7cd7  vmovaps xmm5, [rsp+0x40]
00007d5be8fd7cdd  vmovaps xmm6, [rsp+0x50]
00007d5be8fd7ce3  vmovaps xmm7, [rsp+0x60]
00007d5be8fd7ce9  vmovaps xmm8, [rsp+0x70]
00007d5be8fd7cef  vmovaps xmm9, [rsp+0x80]
00007d5be8fd7cf8  vmovaps xmm10, [rsp+0x90]
00007d5be8fd7d01  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd7d0a  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd7d13  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd7d1c  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd7d25  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd7d2e  add rsp, 0xF0
00007d5be8fd7d35  pop r11
00007d5be8fd7d37  pop r10
00007d5be8fd7d39  pop r9
00007d5be8fd7d3b  pop r8
00007d5be8fd7d3d  pop rsi
00007d5be8fd7d3e  pop rdi
00007d5be8fd7d3f  pop rdx
00007d5be8fd7d40  pop rcx
00007d5be8fd7d41  pop rax
00007d5be8fd7d42  add rsp, 0x08
00007d5be8fd7d46  jmp 0x00007D5BE8FD5E7D
00007d5be8fd7d4b  sub rsp, 0x08
00007d5be8fd7d4f  push rax
00007d5be8fd7d50  push rcx
00007d5be8fd7d51  push rdx
00007d5be8fd7d52  push rdi
00007d5be8fd7d53  push rsi
00007d5be8fd7d54  push r8
00007d5be8fd7d56  push r9
00007d5be8fd7d58  push r10
00007d5be8fd7d5a  push r11
00007d5be8fd7d5c  sub rsp, 0xF0
00007d5be8fd7d63  vmovaps [rsp], xmm0
00007d5be8fd7d68  vmovaps [rsp+0x10], xmm1
00007d5be8fd7d6e  vmovaps [rsp+0x20], xmm2
00007d5be8fd7d74  vmovaps [rsp+0x30], xmm3
00007d5be8fd7d7a  vmovaps [rsp+0x40], xmm4
00007d5be8fd7d80  vmovaps [rsp+0x50], xmm5
00007d5be8fd7d86  vmovaps [rsp+0x60], xmm6
00007d5be8fd7d8c  vmovaps [rsp+0x70], xmm8
00007d5be8fd7d92  vmovaps [rsp+0x80], xmm9
00007d5be8fd7d9b  vmovaps [rsp+0x90], xmm10
00007d5be8fd7da4  vmovaps [rsp+0xA0], xmm11
00007d5be8fd7dad  vmovaps [rsp+0xB0], xmm12
00007d5be8fd7db6  vmovaps [rsp+0xC0], xmm13
00007d5be8fd7dbf  vmovaps [rsp+0xD0], xmm14
00007d5be8fd7dc8  vmovaps [rsp+0xE0], xmm15
00007d5be8fd7dd1  sub rsp, 0x30
00007d5be8fd7dd5  movaps [rsp], xmm7
00007d5be8fd7dd9  movaps [rsp+0x10], xmm5
00007d5be8fd7dde  movaps [rsp+0x20], xmm15
00007d5be8fd7de4  lea rdi, [rsp]
00007d5be8fd7de8  mov esi, 0x00
00007d5be8fd7ded  mov rax, 0x5D345705A530
00007d5be8fd7df7  call rax
00007d5be8fd7df9  movaps xmm7, [rsp]
00007d5be8fd7dfd  add rsp, 0x30
00007d5be8fd7e01  vmovaps xmm0, [rsp]
00007d5be8fd7e06  vmovaps xmm1, [rsp+0x10]
00007d5be8fd7e0c  vmovaps xmm2, [rsp+0x20]
00007d5be8fd7e12  vmovaps xmm3, [rsp+0x30]
00007d5be8fd7e18  vmovaps xmm4, [rsp+0x40]
00007d5be8fd7e1e  vmovaps xmm5, [rsp+0x50]
00007d5be8fd7e24  vmovaps xmm6, [rsp+0x60]
00007d5be8fd7e2a  vmovaps xmm8, [rsp+0x70]
00007d5be8fd7e30  vmovaps xmm9, [rsp+0x80]
00007d5be8fd7e39  vmovaps xmm10, [rsp+0x90]
00007d5be8fd7e42  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd7e4b  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd7e54  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd7e5d  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd7e66  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd7e6f  add rsp, 0xF0
00007d5be8fd7e76  pop r11
00007d5be8fd7e78  pop r10
00007d5be8fd7e7a  pop r9
00007d5be8fd7e7c  pop r8
00007d5be8fd7e7e  pop rsi
00007d5be8fd7e7f  pop rdi
00007d5be8fd7e80  pop rdx
00007d5be8fd7e81  pop rcx
00007d5be8fd7e82  pop rax
00007d5be8fd7e83  add rsp, 0x08
00007d5be8fd7e87  jmp 0x00007D5BE8FD5EB3
00007d5be8fd7e8c  call 0x00007D5BE8ED64F0
00007d5be8fd7e91  jmp 0x00007D5BE8FD5EC0
00007d5be8fd7e96  sub rsp, 0x08
00007d5be8fd7e9a  push rax
00007d5be8fd7e9b  push rcx
00007d5be8fd7e9c  push rdx
00007d5be8fd7e9d  push rdi
00007d5be8fd7e9e  push rsi
00007d5be8fd7e9f  push r8
00007d5be8fd7ea1  push r9
00007d5be8fd7ea3  push r10
00007d5be8fd7ea5  push r11
00007d5be8fd7ea7  sub rsp, 0xF0
00007d5be8fd7eae  vmovaps [rsp], xmm0
00007d5be8fd7eb3  vmovaps [rsp+0x10], xmm1
00007d5be8fd7eb9  vmovaps [rsp+0x20], xmm2
00007d5be8fd7ebf  vmovaps [rsp+0x30], xmm3
00007d5be8fd7ec5  vmovaps [rsp+0x40], xmm4
00007d5be8fd7ecb  vmovaps [rsp+0x50], xmm5
00007d5be8fd7ed1  vmovaps [rsp+0x60], xmm6
00007d5be8fd7ed7  vmovaps [rsp+0x70], xmm7
00007d5be8fd7edd  vmovaps [rsp+0x80], xmm8
00007d5be8fd7ee6  vmovaps [rsp+0x90], xmm9
00007d5be8fd7eef  vmovaps [rsp+0xA0], xmm10
00007d5be8fd7ef8  vmovaps [rsp+0xB0], xmm11
00007d5be8fd7f01  vmovaps [rsp+0xC0], xmm12
00007d5be8fd7f0a  vmovaps [rsp+0xD0], xmm13
00007d5be8fd7f13  vmovaps [rsp+0xE0], xmm14
00007d5be8fd7f1c  sub rsp, 0x30
00007d5be8fd7f20  movaps [rsp], xmm15
00007d5be8fd7f25  movaps [rsp+0x10], xmm5
00007d5be8fd7f2a  movaps [rsp+0x20], xmm3
00007d5be8fd7f2f  lea rdi, [rsp]
00007d5be8fd7f33  mov esi, 0x00
00007d5be8fd7f38  mov rax, 0x5D345705A530
00007d5be8fd7f42  call rax
00007d5be8fd7f44  movaps xmm15, [rsp]
00007d5be8fd7f49  add rsp, 0x30
00007d5be8fd7f4d  vmovaps xmm0, [rsp]
00007d5be8fd7f52  vmovaps xmm1, [rsp+0x10]
00007d5be8fd7f58  vmovaps xmm2, [rsp+0x20]
00007d5be8fd7f5e  vmovaps xmm3, [rsp+0x30]
00007d5be8fd7f64  vmovaps xmm4, [rsp+0x40]
00007d5be8fd7f6a  vmovaps xmm5, [rsp+0x50]
00007d5be8fd7f70  vmovaps xmm6, [rsp+0x60]
00007d5be8fd7f76  vmovaps xmm7, [rsp+0x70]
00007d5be8fd7f7c  vmovaps xmm8, [rsp+0x80]
00007d5be8fd7f85  vmovaps xmm9, [rsp+0x90]
00007d5be8fd7f8e  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd7f97  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd7fa0  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd7fa9  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd7fb2  vmovaps xmm14, [rsp+0xE0]
00007d5be8fd7fbb  add rsp, 0xF0
00007d5be8fd7fc2  pop r11
00007d5be8fd7fc4  pop r10
00007d5be8fd7fc6  pop r9
00007d5be8fd7fc8  pop r8
00007d5be8fd7fca  pop rsi
00007d5be8fd7fcb  pop rdi
00007d5be8fd7fcc  pop rdx
00007d5be8fd7fcd  pop rcx
00007d5be8fd7fce  pop rax
00007d5be8fd7fcf  add rsp, 0x08
00007d5be8fd7fd3  jmp 0x00007D5BE8FD5EE6
00007d5be8fd7fd8  sub rsp, 0x08
00007d5be8fd7fdc  push rax
00007d5be8fd7fdd  push rcx
00007d5be8fd7fde  push rdx
00007d5be8fd7fdf  push rdi
00007d5be8fd7fe0  push rsi
00007d5be8fd7fe1  push r8
00007d5be8fd7fe3  push r9
00007d5be8fd7fe5  push r10
00007d5be8fd7fe7  push r11
00007d5be8fd7fe9  sub rsp, 0xF0
00007d5be8fd7ff0  vmovaps [rsp], xmm0
00007d5be8fd7ff5  vmovaps [rsp+0x10], xmm2
00007d5be8fd7ffb  vmovaps [rsp+0x20], xmm3
00007d5be8fd8001  vmovaps [rsp+0x30], xmm4
00007d5be8fd8007  vmovaps [rsp+0x40], xmm5
00007d5be8fd800d  vmovaps [rsp+0x50], xmm6
00007d5be8fd8013  vmovaps [rsp+0x60], xmm7
00007d5be8fd8019  vmovaps [rsp+0x70], xmm8
00007d5be8fd801f  vmovaps [rsp+0x80], xmm9
00007d5be8fd8028  vmovaps [rsp+0x90], xmm10
00007d5be8fd8031  vmovaps [rsp+0xA0], xmm11
00007d5be8fd803a  vmovaps [rsp+0xB0], xmm12
00007d5be8fd8043  vmovaps [rsp+0xC0], xmm13
00007d5be8fd804c  vmovaps [rsp+0xD0], xmm14
00007d5be8fd8055  vmovaps [rsp+0xE0], xmm15
00007d5be8fd805e  sub rsp, 0x30
00007d5be8fd8062  movaps [rsp], xmm1
00007d5be8fd8066  movaps [rsp+0x10], xmm5
00007d5be8fd806b  movaps [rsp+0x20], xmm4
00007d5be8fd8070  lea rdi, [rsp]
00007d5be8fd8074  mov esi, 0x00
00007d5be8fd8079  mov rax, 0x5D345705A530
00007d5be8fd8083  call rax
00007d5be8fd8085  movaps xmm1, [rsp]
00007d5be8fd8089  add rsp, 0x30
00007d5be8fd808d  vmovaps xmm0, [rsp]
00007d5be8fd8092  vmovaps xmm2, [rsp+0x10]
00007d5be8fd8098  vmovaps xmm3, [rsp+0x20]
00007d5be8fd809e  vmovaps xmm4, [rsp+0x30]
00007d5be8fd80a4  vmovaps xmm5, [rsp+0x40]
00007d5be8fd80aa  vmovaps xmm6, [rsp+0x50]
00007d5be8fd80b0  vmovaps xmm7, [rsp+0x60]
00007d5be8fd80b6  vmovaps xmm8, [rsp+0x70]
00007d5be8fd80bc  vmovaps xmm9, [rsp+0x80]
00007d5be8fd80c5  vmovaps xmm10, [rsp+0x90]
00007d5be8fd80ce  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd80d7  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd80e0  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd80e9  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd80f2  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd80fb  add rsp, 0xF0
00007d5be8fd8102  pop r11
00007d5be8fd8104  pop r10
00007d5be8fd8106  pop r9
00007d5be8fd8108  pop r8
00007d5be8fd810a  pop rsi
00007d5be8fd810b  pop rdi
00007d5be8fd810c  pop rdx
00007d5be8fd810d  pop rcx
00007d5be8fd810e  pop rax
00007d5be8fd810f  add rsp, 0x08
00007d5be8fd8113  jmp 0x00007D5BE8FD5F06
00007d5be8fd8118  sub rsp, 0x08
00007d5be8fd811c  push rax
00007d5be8fd811d  push rcx
00007d5be8fd811e  push rdx
00007d5be8fd811f  push rdi
00007d5be8fd8120  push rsi
00007d5be8fd8121  push r8
00007d5be8fd8123  push r9
00007d5be8fd8125  push r10
00007d5be8fd8127  push r11
00007d5be8fd8129  sub rsp, 0xF0
00007d5be8fd8130  vmovaps [rsp], xmm0
00007d5be8fd8135  vmovaps [rsp+0x10], xmm1
00007d5be8fd813b  vmovaps [rsp+0x20], xmm2
00007d5be8fd8141  vmovaps [rsp+0x30], xmm3
00007d5be8fd8147  vmovaps [rsp+0x40], xmm5
00007d5be8fd814d  vmovaps [rsp+0x50], xmm6
00007d5be8fd8153  vmovaps [rsp+0x60], xmm7
00007d5be8fd8159  vmovaps [rsp+0x70], xmm8
00007d5be8fd815f  vmovaps [rsp+0x80], xmm9
00007d5be8fd8168  vmovaps [rsp+0x90], xmm10
00007d5be8fd8171  vmovaps [rsp+0xA0], xmm11
00007d5be8fd817a  vmovaps [rsp+0xB0], xmm12
00007d5be8fd8183  vmovaps [rsp+0xC0], xmm13
00007d5be8fd818c  vmovaps [rsp+0xD0], xmm14
00007d5be8fd8195  vmovaps [rsp+0xE0], xmm15
00007d5be8fd819e  sub rsp, 0x30
00007d5be8fd81a2  movaps [rsp], xmm4
00007d5be8fd81a6  movaps [rsp+0x10], xmm3
00007d5be8fd81ab  movaps [rsp+0x20], xmm5
00007d5be8fd81b0  lea rdi, [rsp]
00007d5be8fd81b4  mov esi, 0x00
00007d5be8fd81b9  mov rax, 0x5D345705A530
00007d5be8fd81c3  call rax
00007d5be8fd81c5  movaps xmm4, [rsp]
00007d5be8fd81c9  add rsp, 0x30
00007d5be8fd81cd  vmovaps xmm0, [rsp]
00007d5be8fd81d2  vmovaps xmm1, [rsp+0x10]
00007d5be8fd81d8  vmovaps xmm2, [rsp+0x20]
00007d5be8fd81de  vmovaps xmm3, [rsp+0x30]
00007d5be8fd81e4  vmovaps xmm5, [rsp+0x40]
00007d5be8fd81ea  vmovaps xmm6, [rsp+0x50]
00007d5be8fd81f0  vmovaps xmm7, [rsp+0x60]
00007d5be8fd81f6  vmovaps xmm8, [rsp+0x70]
00007d5be8fd81fc  vmovaps xmm9, [rsp+0x80]
00007d5be8fd8205  vmovaps xmm10, [rsp+0x90]
00007d5be8fd820e  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd8217  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd8220  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd8229  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd8232  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd823b  add rsp, 0xF0
00007d5be8fd8242  pop r11
00007d5be8fd8244  pop r10
00007d5be8fd8246  pop r9
00007d5be8fd8248  pop r8
00007d5be8fd824a  pop rsi
00007d5be8fd824b  pop rdi
00007d5be8fd824c  pop rdx
00007d5be8fd824d  pop rcx
00007d5be8fd824e  pop rax
00007d5be8fd824f  add rsp, 0x08
00007d5be8fd8253  jmp 0x00007D5BE8FD5F54
00007d5be8fd8258  call 0x00007D5BE8ED64F0
00007d5be8fd825d  jmp 0x00007D5BE8FD5F61
00007d5be8fd8262  sub rsp, 0x08
00007d5be8fd8266  push rax
00007d5be8fd8267  push rcx
00007d5be8fd8268  push rdx
00007d5be8fd8269  push rdi
00007d5be8fd826a  push rsi
00007d5be8fd826b  push r8
00007d5be8fd826d  push r9
00007d5be8fd826f  push r10
00007d5be8fd8271  push r11
00007d5be8fd8273  sub rsp, 0xF0
00007d5be8fd827a  vmovaps [rsp], xmm0
00007d5be8fd827f  vmovaps [rsp+0x10], xmm1
00007d5be8fd8285  vmovaps [rsp+0x20], xmm2
00007d5be8fd828b  vmovaps [rsp+0x30], xmm3
00007d5be8fd8291  vmovaps [rsp+0x40], xmm4
00007d5be8fd8297  vmovaps [rsp+0x50], xmm6
00007d5be8fd829d  vmovaps [rsp+0x60], xmm7
00007d5be8fd82a3  vmovaps [rsp+0x70], xmm8
00007d5be8fd82a9  vmovaps [rsp+0x80], xmm9
00007d5be8fd82b2  vmovaps [rsp+0x90], xmm10
00007d5be8fd82bb  vmovaps [rsp+0xA0], xmm11
00007d5be8fd82c4  vmovaps [rsp+0xB0], xmm12
00007d5be8fd82cd  vmovaps [rsp+0xC0], xmm13
00007d5be8fd82d6  vmovaps [rsp+0xD0], xmm14
00007d5be8fd82df  vmovaps [rsp+0xE0], xmm15
00007d5be8fd82e8  sub rsp, 0x30
00007d5be8fd82ec  movaps [rsp], xmm5
00007d5be8fd82f0  movaps [rsp+0x10], xmm6
00007d5be8fd82f5  movaps [rsp+0x20], xmm3
00007d5be8fd82fa  lea rdi, [rsp]
00007d5be8fd82fe  mov esi, 0x00
00007d5be8fd8303  mov rax, 0x5D345705A530
00007d5be8fd830d  call rax
00007d5be8fd830f  movaps xmm5, [rsp]
00007d5be8fd8313  add rsp, 0x30
00007d5be8fd8317  vmovaps xmm0, [rsp]
00007d5be8fd831c  vmovaps xmm1, [rsp+0x10]
00007d5be8fd8322  vmovaps xmm2, [rsp+0x20]
00007d5be8fd8328  vmovaps xmm3, [rsp+0x30]
00007d5be8fd832e  vmovaps xmm4, [rsp+0x40]
00007d5be8fd8334  vmovaps xmm6, [rsp+0x50]
00007d5be8fd833a  vmovaps xmm7, [rsp+0x60]
00007d5be8fd8340  vmovaps xmm8, [rsp+0x70]
00007d5be8fd8346  vmovaps xmm9, [rsp+0x80]
00007d5be8fd834f  vmovaps xmm10, [rsp+0x90]
00007d5be8fd8358  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd8361  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd836a  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd8373  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd837c  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd8385  add rsp, 0xF0
00007d5be8fd838c  pop r11
00007d5be8fd838e  pop r10
00007d5be8fd8390  pop r9
00007d5be8fd8392  pop r8
00007d5be8fd8394  pop rsi
00007d5be8fd8395  pop rdi
00007d5be8fd8396  pop rdx
00007d5be8fd8397  pop rcx
00007d5be8fd8398  pop rax
00007d5be8fd8399  add rsp, 0x08
00007d5be8fd839d  jmp 0x00007D5BE8FD5F87
00007d5be8fd83a2  sub rsp, 0x08
00007d5be8fd83a6  push rax
00007d5be8fd83a7  push rcx
00007d5be8fd83a8  push rdx
00007d5be8fd83a9  push rdi
00007d5be8fd83aa  push rsi
00007d5be8fd83ab  push r8
00007d5be8fd83ad  push r9
00007d5be8fd83af  push r10
00007d5be8fd83b1  push r11
00007d5be8fd83b3  sub rsp, 0xF0
00007d5be8fd83ba  vmovaps [rsp], xmm0
00007d5be8fd83bf  vmovaps [rsp+0x10], xmm1
00007d5be8fd83c5  vmovaps [rsp+0x20], xmm2
00007d5be8fd83cb  vmovaps [rsp+0x30], xmm3
00007d5be8fd83d1  vmovaps [rsp+0x40], xmm4
00007d5be8fd83d7  vmovaps [rsp+0x50], xmm5
00007d5be8fd83dd  vmovaps [rsp+0x60], xmm7
00007d5be8fd83e3  vmovaps [rsp+0x70], xmm8
00007d5be8fd83e9  vmovaps [rsp+0x80], xmm9
00007d5be8fd83f2  vmovaps [rsp+0x90], xmm10
00007d5be8fd83fb  vmovaps [rsp+0xA0], xmm11
00007d5be8fd8404  vmovaps [rsp+0xB0], xmm12
00007d5be8fd840d  vmovaps [rsp+0xC0], xmm13
00007d5be8fd8416  vmovaps [rsp+0xD0], xmm14
00007d5be8fd841f  vmovaps [rsp+0xE0], xmm15
00007d5be8fd8428  sub rsp, 0x30
00007d5be8fd842c  movaps [rsp], xmm6
00007d5be8fd8430  movaps [rsp+0x10], xmm9
00007d5be8fd8436  movaps [rsp+0x20], xmm1
00007d5be8fd843b  lea rdi, [rsp]
00007d5be8fd843f  mov esi, 0x00
00007d5be8fd8444  mov rax, 0x5D345705A530
00007d5be8fd844e  call rax
00007d5be8fd8450  movaps xmm6, [rsp]
00007d5be8fd8454  add rsp, 0x30
00007d5be8fd8458  vmovaps xmm0, [rsp]
00007d5be8fd845d  vmovaps xmm1, [rsp+0x10]
00007d5be8fd8463  vmovaps xmm2, [rsp+0x20]
00007d5be8fd8469  vmovaps xmm3, [rsp+0x30]
00007d5be8fd846f  vmovaps xmm4, [rsp+0x40]
00007d5be8fd8475  vmovaps xmm5, [rsp+0x50]
00007d5be8fd847b  vmovaps xmm7, [rsp+0x60]
00007d5be8fd8481  vmovaps xmm8, [rsp+0x70]
00007d5be8fd8487  vmovaps xmm9, [rsp+0x80]
00007d5be8fd8490  vmovaps xmm10, [rsp+0x90]
00007d5be8fd8499  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd84a2  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd84ab  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd84b4  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd84bd  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd84c6  add rsp, 0xF0
00007d5be8fd84cd  pop r11
00007d5be8fd84cf  pop r10
00007d5be8fd84d1  pop r9
00007d5be8fd84d3  pop r8
00007d5be8fd84d5  pop rsi
00007d5be8fd84d6  pop rdi
00007d5be8fd84d7  pop rdx
00007d5be8fd84d8  pop rcx
00007d5be8fd84d9  pop rax
00007d5be8fd84da  add rsp, 0x08
00007d5be8fd84de  jmp 0x00007D5BE8FD5FAB
00007d5be8fd84e3  sub rsp, 0x08
00007d5be8fd84e7  push rax
00007d5be8fd84e8  push rcx
00007d5be8fd84e9  push rdx
00007d5be8fd84ea  push rdi
00007d5be8fd84eb  push rsi
00007d5be8fd84ec  push r8
00007d5be8fd84ee  push r9
00007d5be8fd84f0  push r10
00007d5be8fd84f2  push r11
00007d5be8fd84f4  sub rsp, 0xF0
00007d5be8fd84fb  vmovaps [rsp], xmm0
00007d5be8fd8500  vmovaps [rsp+0x10], xmm1
00007d5be8fd8506  vmovaps [rsp+0x20], xmm2
00007d5be8fd850c  vmovaps [rsp+0x30], xmm3
00007d5be8fd8512  vmovaps [rsp+0x40], xmm4
00007d5be8fd8518  vmovaps [rsp+0x50], xmm5
00007d5be8fd851e  vmovaps [rsp+0x60], xmm6
00007d5be8fd8524  vmovaps [rsp+0x70], xmm7
00007d5be8fd852a  vmovaps [rsp+0x80], xmm8
00007d5be8fd8533  vmovaps [rsp+0x90], xmm10
00007d5be8fd853c  vmovaps [rsp+0xA0], xmm11
00007d5be8fd8545  vmovaps [rsp+0xB0], xmm12
00007d5be8fd854e  vmovaps [rsp+0xC0], xmm13
00007d5be8fd8557  vmovaps [rsp+0xD0], xmm14
00007d5be8fd8560  vmovaps [rsp+0xE0], xmm15
00007d5be8fd8569  sub rsp, 0x30
00007d5be8fd856d  movaps [rsp], xmm9
00007d5be8fd8572  movaps [rsp+0x10], xmm3
00007d5be8fd8577  movaps [rsp+0x20], xmm1
00007d5be8fd857c  lea rdi, [rsp]
00007d5be8fd8580  mov esi, 0x00
00007d5be8fd8585  mov rax, 0x5D345705A530
00007d5be8fd858f  call rax
00007d5be8fd8591  movaps xmm9, [rsp]
00007d5be8fd8596  add rsp, 0x30
00007d5be8fd859a  vmovaps xmm0, [rsp]
00007d5be8fd859f  vmovaps xmm1, [rsp+0x10]
00007d5be8fd85a5  vmovaps xmm2, [rsp+0x20]
00007d5be8fd85ab  vmovaps xmm3, [rsp+0x30]
00007d5be8fd85b1  vmovaps xmm4, [rsp+0x40]
00007d5be8fd85b7  vmovaps xmm5, [rsp+0x50]
00007d5be8fd85bd  vmovaps xmm6, [rsp+0x60]
00007d5be8fd85c3  vmovaps xmm7, [rsp+0x70]
00007d5be8fd85c9  vmovaps xmm8, [rsp+0x80]
00007d5be8fd85d2  vmovaps xmm10, [rsp+0x90]
00007d5be8fd85db  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd85e4  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd85ed  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd85f6  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd85ff  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd8608  add rsp, 0xF0
00007d5be8fd860f  pop r11
00007d5be8fd8611  pop r10
00007d5be8fd8613  pop r9
00007d5be8fd8615  pop r8
00007d5be8fd8617  pop rsi
00007d5be8fd8618  pop rdi
00007d5be8fd8619  pop rdx
00007d5be8fd861a  pop rcx
00007d5be8fd861b  pop rax
00007d5be8fd861c  add rsp, 0x08
00007d5be8fd8620  jmp 0x00007D5BE8FD5FF7
00007d5be8fd8625  call 0x00007D5BE8ED64F0
00007d5be8fd862a  jmp 0x00007D5BE8FD6004
00007d5be8fd862f  sub rsp, 0x08
00007d5be8fd8633  push rax
00007d5be8fd8634  push rcx
00007d5be8fd8635  push rdx
00007d5be8fd8636  push rdi
00007d5be8fd8637  push rsi
00007d5be8fd8638  push r8
00007d5be8fd863a  push r9
00007d5be8fd863c  push r10
00007d5be8fd863e  push r11
00007d5be8fd8640  sub rsp, 0xF0
00007d5be8fd8647  vmovaps [rsp], xmm0
00007d5be8fd864c  vmovaps [rsp+0x10], xmm1
00007d5be8fd8652  vmovaps [rsp+0x20], xmm2
00007d5be8fd8658  vmovaps [rsp+0x30], xmm3
00007d5be8fd865e  vmovaps [rsp+0x40], xmm4
00007d5be8fd8664  vmovaps [rsp+0x50], xmm5
00007d5be8fd866a  vmovaps [rsp+0x60], xmm6
00007d5be8fd8670  vmovaps [rsp+0x70], xmm7
00007d5be8fd8676  vmovaps [rsp+0x80], xmm8
00007d5be8fd867f  vmovaps [rsp+0x90], xmm9
00007d5be8fd8688  vmovaps [rsp+0xA0], xmm10
00007d5be8fd8691  vmovaps [rsp+0xB0], xmm11
00007d5be8fd869a  vmovaps [rsp+0xC0], xmm12
00007d5be8fd86a3  vmovaps [rsp+0xD0], xmm13
00007d5be8fd86ac  vmovaps [rsp+0xE0], xmm14
00007d5be8fd86b5  sub rsp, 0x30
00007d5be8fd86b9  movaps [rsp], xmm15
00007d5be8fd86be  movaps [rsp+0x10], xmm3
00007d5be8fd86c3  movaps [rsp+0x20], xmm7
00007d5be8fd86c8  lea rdi, [rsp]
00007d5be8fd86cc  mov esi, 0x00
00007d5be8fd86d1  mov rax, 0x5D345705A530
00007d5be8fd86db  call rax
00007d5be8fd86dd  movaps xmm15, [rsp]
00007d5be8fd86e2  add rsp, 0x30
00007d5be8fd86e6  vmovaps xmm0, [rsp]
00007d5be8fd86eb  vmovaps xmm1, [rsp+0x10]
00007d5be8fd86f1  vmovaps xmm2, [rsp+0x20]
00007d5be8fd86f7  vmovaps xmm3, [rsp+0x30]
00007d5be8fd86fd  vmovaps xmm4, [rsp+0x40]
00007d5be8fd8703  vmovaps xmm5, [rsp+0x50]
00007d5be8fd8709  vmovaps xmm6, [rsp+0x60]
00007d5be8fd870f  vmovaps xmm7, [rsp+0x70]
00007d5be8fd8715  vmovaps xmm8, [rsp+0x80]
00007d5be8fd871e  vmovaps xmm9, [rsp+0x90]
00007d5be8fd8727  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd8730  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd8739  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd8742  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd874b  vmovaps xmm14, [rsp+0xE0]
00007d5be8fd8754  add rsp, 0xF0
00007d5be8fd875b  pop r11
00007d5be8fd875d  pop r10
00007d5be8fd875f  pop r9
00007d5be8fd8761  pop r8
00007d5be8fd8763  pop rsi
00007d5be8fd8764  pop rdi
00007d5be8fd8765  pop rdx
00007d5be8fd8766  pop rcx
00007d5be8fd8767  pop rax
00007d5be8fd8768  add rsp, 0x08
00007d5be8fd876c  jmp 0x00007D5BE8FD6030
00007d5be8fd8771  sub rsp, 0x08
00007d5be8fd8775  push rax
00007d5be8fd8776  push rcx
00007d5be8fd8777  push rdx
00007d5be8fd8778  push rdi
00007d5be8fd8779  push rsi
00007d5be8fd877a  push r8
00007d5be8fd877c  push r9
00007d5be8fd877e  push r10
00007d5be8fd8780  push r11
00007d5be8fd8782  sub rsp, 0xF0
00007d5be8fd8789  vmovaps [rsp], xmm0
00007d5be8fd878e  vmovaps [rsp+0x10], xmm1
00007d5be8fd8794  vmovaps [rsp+0x20], xmm2
00007d5be8fd879a  vmovaps [rsp+0x30], xmm4
00007d5be8fd87a0  vmovaps [rsp+0x40], xmm5
00007d5be8fd87a6  vmovaps [rsp+0x50], xmm6
00007d5be8fd87ac  vmovaps [rsp+0x60], xmm7
00007d5be8fd87b2  vmovaps [rsp+0x70], xmm8
00007d5be8fd87b8  vmovaps [rsp+0x80], xmm9
00007d5be8fd87c1  vmovaps [rsp+0x90], xmm10
00007d5be8fd87ca  vmovaps [rsp+0xA0], xmm11
00007d5be8fd87d3  vmovaps [rsp+0xB0], xmm12
00007d5be8fd87dc  vmovaps [rsp+0xC0], xmm13
00007d5be8fd87e5  vmovaps [rsp+0xD0], xmm14
00007d5be8fd87ee  vmovaps [rsp+0xE0], xmm15
00007d5be8fd87f7  sub rsp, 0x30
00007d5be8fd87fb  movaps [rsp], xmm3
00007d5be8fd87ff  movaps [rsp+0x10], xmm1
00007d5be8fd8804  movaps [rsp+0x20], xmm15
00007d5be8fd880a  lea rdi, [rsp]
00007d5be8fd880e  mov esi, 0x00
00007d5be8fd8813  mov rax, 0x5D345705A530
00007d5be8fd881d  call rax
00007d5be8fd881f  movaps xmm3, [rsp]
00007d5be8fd8823  add rsp, 0x30
00007d5be8fd8827  vmovaps xmm0, [rsp]
00007d5be8fd882c  vmovaps xmm1, [rsp+0x10]
00007d5be8fd8832  vmovaps xmm2, [rsp+0x20]
00007d5be8fd8838  vmovaps xmm4, [rsp+0x30]
00007d5be8fd883e  vmovaps xmm5, [rsp+0x40]
00007d5be8fd8844  vmovaps xmm6, [rsp+0x50]
00007d5be8fd884a  vmovaps xmm7, [rsp+0x60]
00007d5be8fd8850  vmovaps xmm8, [rsp+0x70]
00007d5be8fd8856  vmovaps xmm9, [rsp+0x80]
00007d5be8fd885f  vmovaps xmm10, [rsp+0x90]
00007d5be8fd8868  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd8871  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd887a  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd8883  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd888c  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd8895  add rsp, 0xF0
00007d5be8fd889c  pop r11
00007d5be8fd889e  pop r10
00007d5be8fd88a0  pop r9
00007d5be8fd88a2  pop r8
00007d5be8fd88a4  pop rsi
00007d5be8fd88a5  pop rdi
00007d5be8fd88a6  pop rdx
00007d5be8fd88a7  pop rcx
00007d5be8fd88a8  pop rax
00007d5be8fd88a9  add rsp, 0x08
00007d5be8fd88ad  jmp 0x00007D5BE8FD60BF
00007d5be8fd88b2  call 0x00007D5BE8ED64F0
00007d5be8fd88b7  jmp 0x00007D5BE8FD60C9
00007d5be8fd88bc  sub rsp, 0x08
00007d5be8fd88c0  push rax
00007d5be8fd88c1  push rcx
00007d5be8fd88c2  push rdx
00007d5be8fd88c3  push rdi
00007d5be8fd88c4  push rsi
00007d5be8fd88c5  push r8
00007d5be8fd88c7  push r9
00007d5be8fd88c9  push r10
00007d5be8fd88cb  push r11
00007d5be8fd88cd  sub rsp, 0xF0
00007d5be8fd88d4  vmovaps [rsp], xmm0
00007d5be8fd88d9  vmovaps [rsp+0x10], xmm1
00007d5be8fd88df  vmovaps [rsp+0x20], xmm2
00007d5be8fd88e5  vmovaps [rsp+0x30], xmm3
00007d5be8fd88eb  vmovaps [rsp+0x40], xmm4
00007d5be8fd88f1  vmovaps [rsp+0x50], xmm5
00007d5be8fd88f7  vmovaps [rsp+0x60], xmm6
00007d5be8fd88fd  vmovaps [rsp+0x70], xmm7
00007d5be8fd8903  vmovaps [rsp+0x80], xmm8
00007d5be8fd890c  vmovaps [rsp+0x90], xmm9
00007d5be8fd8915  vmovaps [rsp+0xA0], xmm10
00007d5be8fd891e  vmovaps [rsp+0xB0], xmm11
00007d5be8fd8927  vmovaps [rsp+0xC0], xmm12
00007d5be8fd8930  vmovaps [rsp+0xD0], xmm13
00007d5be8fd8939  vmovaps [rsp+0xE0], xmm14
00007d5be8fd8942  sub rsp, 0x30
00007d5be8fd8946  movaps [rsp], xmm15
00007d5be8fd894b  movaps [rsp+0x10], xmm14
00007d5be8fd8951  movaps [rsp+0x20], xmm4
00007d5be8fd8956  lea rdi, [rsp]
00007d5be8fd895a  mov esi, 0x00
00007d5be8fd895f  mov rax, 0x5D345705A530
00007d5be8fd8969  call rax
00007d5be8fd896b  movaps xmm15, [rsp]
00007d5be8fd8970  add rsp, 0x30
00007d5be8fd8974  vmovaps xmm0, [rsp]
00007d5be8fd8979  vmovaps xmm1, [rsp+0x10]
00007d5be8fd897f  vmovaps xmm2, [rsp+0x20]
00007d5be8fd8985  vmovaps xmm3, [rsp+0x30]
00007d5be8fd898b  vmovaps xmm4, [rsp+0x40]
00007d5be8fd8991  vmovaps xmm5, [rsp+0x50]
00007d5be8fd8997  vmovaps xmm6, [rsp+0x60]
00007d5be8fd899d  vmovaps xmm7, [rsp+0x70]
00007d5be8fd89a3  vmovaps xmm8, [rsp+0x80]
00007d5be8fd89ac  vmovaps xmm9, [rsp+0x90]
00007d5be8fd89b5  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd89be  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd89c7  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd89d0  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd89d9  vmovaps xmm14, [rsp+0xE0]
00007d5be8fd89e2  add rsp, 0xF0
00007d5be8fd89e9  pop r11
00007d5be8fd89eb  pop r10
00007d5be8fd89ed  pop r9
00007d5be8fd89ef  pop r8
00007d5be8fd89f1  pop rsi
00007d5be8fd89f2  pop rdi
00007d5be8fd89f3  pop rdx
00007d5be8fd89f4  pop rcx
00007d5be8fd89f5  pop rax
00007d5be8fd89f6  add rsp, 0x08
00007d5be8fd89fa  jmp 0x00007D5BE8FD60F7
00007d5be8fd89ff  sub rsp, 0x08
00007d5be8fd8a03  push rax
00007d5be8fd8a04  push rcx
00007d5be8fd8a05  push rdx
00007d5be8fd8a06  push rdi
00007d5be8fd8a07  push rsi
00007d5be8fd8a08  push r8
00007d5be8fd8a0a  push r9
00007d5be8fd8a0c  push r10
00007d5be8fd8a0e  push r11
00007d5be8fd8a10  sub rsp, 0xF0
00007d5be8fd8a17  vmovaps [rsp], xmm0
00007d5be8fd8a1c  vmovaps [rsp+0x10], xmm1
00007d5be8fd8a22  vmovaps [rsp+0x20], xmm2
00007d5be8fd8a28  vmovaps [rsp+0x30], xmm3
00007d5be8fd8a2e  vmovaps [rsp+0x40], xmm4
00007d5be8fd8a34  vmovaps [rsp+0x50], xmm5
00007d5be8fd8a3a  vmovaps [rsp+0x60], xmm6
00007d5be8fd8a40  vmovaps [rsp+0x70], xmm7
00007d5be8fd8a46  vmovaps [rsp+0x80], xmm8
00007d5be8fd8a4f  vmovaps [rsp+0x90], xmm9
00007d5be8fd8a58  vmovaps [rsp+0xA0], xmm10
00007d5be8fd8a61  vmovaps [rsp+0xB0], xmm11
00007d5be8fd8a6a  vmovaps [rsp+0xC0], xmm12
00007d5be8fd8a73  vmovaps [rsp+0xD0], xmm13
00007d5be8fd8a7c  vmovaps [rsp+0xE0], xmm15
00007d5be8fd8a85  sub rsp, 0x30
00007d5be8fd8a89  movaps [rsp], xmm14
00007d5be8fd8a8e  movaps [rsp+0x10], xmm2
00007d5be8fd8a93  movaps [rsp+0x20], xmm1
00007d5be8fd8a98  lea rdi, [rsp]
00007d5be8fd8a9c  mov esi, 0x00
00007d5be8fd8aa1  mov rax, 0x5D345705A530
00007d5be8fd8aab  call rax
00007d5be8fd8aad  movaps xmm14, [rsp]
00007d5be8fd8ab2  add rsp, 0x30
00007d5be8fd8ab6  vmovaps xmm0, [rsp]
00007d5be8fd8abb  vmovaps xmm1, [rsp+0x10]
00007d5be8fd8ac1  vmovaps xmm2, [rsp+0x20]
00007d5be8fd8ac7  vmovaps xmm3, [rsp+0x30]
00007d5be8fd8acd  vmovaps xmm4, [rsp+0x40]
00007d5be8fd8ad3  vmovaps xmm5, [rsp+0x50]
00007d5be8fd8ad9  vmovaps xmm6, [rsp+0x60]
00007d5be8fd8adf  vmovaps xmm7, [rsp+0x70]
00007d5be8fd8ae5  vmovaps xmm8, [rsp+0x80]
00007d5be8fd8aee  vmovaps xmm9, [rsp+0x90]
00007d5be8fd8af7  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd8b00  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd8b09  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd8b12  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd8b1b  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd8b24  add rsp, 0xF0
00007d5be8fd8b2b  pop r11
00007d5be8fd8b2d  pop r10
00007d5be8fd8b2f  pop r9
00007d5be8fd8b31  pop r8
00007d5be8fd8b33  pop rsi
00007d5be8fd8b34  pop rdi
00007d5be8fd8b35  pop rdx
00007d5be8fd8b36  pop rcx
00007d5be8fd8b37  pop rax
00007d5be8fd8b38  add rsp, 0x08
00007d5be8fd8b3c  jmp 0x00007D5BE8FD611D
00007d5be8fd8b41  sub rsp, 0x08
00007d5be8fd8b45  push rax
00007d5be8fd8b46  push rcx
00007d5be8fd8b47  push rdx
00007d5be8fd8b48  push rdi
00007d5be8fd8b49  push rsi
00007d5be8fd8b4a  push r8
00007d5be8fd8b4c  push r9
00007d5be8fd8b4e  push r10
00007d5be8fd8b50  push r11
00007d5be8fd8b52  sub rsp, 0xF0
00007d5be8fd8b59  vmovaps [rsp], xmm0
00007d5be8fd8b5e  vmovaps [rsp+0x10], xmm2
00007d5be8fd8b64  vmovaps [rsp+0x20], xmm3
00007d5be8fd8b6a  vmovaps [rsp+0x30], xmm4
00007d5be8fd8b70  vmovaps [rsp+0x40], xmm5
00007d5be8fd8b76  vmovaps [rsp+0x50], xmm6
00007d5be8fd8b7c  vmovaps [rsp+0x60], xmm7
00007d5be8fd8b82  vmovaps [rsp+0x70], xmm8
00007d5be8fd8b88  vmovaps [rsp+0x80], xmm9
00007d5be8fd8b91  vmovaps [rsp+0x90], xmm10
00007d5be8fd8b9a  vmovaps [rsp+0xA0], xmm11
00007d5be8fd8ba3  vmovaps [rsp+0xB0], xmm12
00007d5be8fd8bac  vmovaps [rsp+0xC0], xmm13
00007d5be8fd8bb5  vmovaps [rsp+0xD0], xmm14
00007d5be8fd8bbe  vmovaps [rsp+0xE0], xmm15
00007d5be8fd8bc7  sub rsp, 0x30
00007d5be8fd8bcb  movaps [rsp], xmm1
00007d5be8fd8bcf  movaps [rsp+0x10], xmm4
00007d5be8fd8bd4  movaps [rsp+0x20], xmm9
00007d5be8fd8bda  lea rdi, [rsp]
00007d5be8fd8bde  mov esi, 0x00
00007d5be8fd8be3  mov rax, 0x5D345705A530
00007d5be8fd8bed  call rax
00007d5be8fd8bef  movaps xmm1, [rsp]
00007d5be8fd8bf3  add rsp, 0x30
00007d5be8fd8bf7  vmovaps xmm0, [rsp]
00007d5be8fd8bfc  vmovaps xmm2, [rsp+0x10]
00007d5be8fd8c02  vmovaps xmm3, [rsp+0x20]
00007d5be8fd8c08  vmovaps xmm4, [rsp+0x30]
00007d5be8fd8c0e  vmovaps xmm5, [rsp+0x40]
00007d5be8fd8c14  vmovaps xmm6, [rsp+0x50]
00007d5be8fd8c1a  vmovaps xmm7, [rsp+0x60]
00007d5be8fd8c20  vmovaps xmm8, [rsp+0x70]
00007d5be8fd8c26  vmovaps xmm9, [rsp+0x80]
00007d5be8fd8c2f  vmovaps xmm10, [rsp+0x90]
00007d5be8fd8c38  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd8c41  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd8c4a  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd8c53  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd8c5c  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd8c65  add rsp, 0xF0
00007d5be8fd8c6c  pop r11
00007d5be8fd8c6e  pop r10
00007d5be8fd8c70  pop r9
00007d5be8fd8c72  pop r8
00007d5be8fd8c74  pop rsi
00007d5be8fd8c75  pop rdi
00007d5be8fd8c76  pop rdx
00007d5be8fd8c77  pop rcx
00007d5be8fd8c78  pop rax
00007d5be8fd8c79  add rsp, 0x08
00007d5be8fd8c7d  jmp 0x00007D5BE8FD613B
00007d5be8fd8c82  sub rsp, 0x08
00007d5be8fd8c86  push rax
00007d5be8fd8c87  push rcx
00007d5be8fd8c88  push rdx
00007d5be8fd8c89  push rdi
00007d5be8fd8c8a  push rsi
00007d5be8fd8c8b  push r8
00007d5be8fd8c8d  push r9
00007d5be8fd8c8f  push r10
00007d5be8fd8c91  push r11
00007d5be8fd8c93  sub rsp, 0xF0
00007d5be8fd8c9a  vmovaps [rsp], xmm0
00007d5be8fd8c9f  vmovaps [rsp+0x10], xmm1
00007d5be8fd8ca5  vmovaps [rsp+0x20], xmm2
00007d5be8fd8cab  vmovaps [rsp+0x30], xmm3
00007d5be8fd8cb1  vmovaps [rsp+0x40], xmm5
00007d5be8fd8cb7  vmovaps [rsp+0x50], xmm6
00007d5be8fd8cbd  vmovaps [rsp+0x60], xmm7
00007d5be8fd8cc3  vmovaps [rsp+0x70], xmm8
00007d5be8fd8cc9  vmovaps [rsp+0x80], xmm9
00007d5be8fd8cd2  vmovaps [rsp+0x90], xmm10
00007d5be8fd8cdb  vmovaps [rsp+0xA0], xmm11
00007d5be8fd8ce4  vmovaps [rsp+0xB0], xmm12
00007d5be8fd8ced  vmovaps [rsp+0xC0], xmm13
00007d5be8fd8cf6  vmovaps [rsp+0xD0], xmm14
00007d5be8fd8cff  vmovaps [rsp+0xE0], xmm15
00007d5be8fd8d08  sub rsp, 0x30
00007d5be8fd8d0c  movaps [rsp], xmm4
00007d5be8fd8d10  movaps [rsp+0x10], xmm2
00007d5be8fd8d15  movaps [rsp+0x20], xmm9
00007d5be8fd8d1b  lea rdi, [rsp]
00007d5be8fd8d1f  mov esi, 0x00
00007d5be8fd8d24  mov rax, 0x5D345705A530
00007d5be8fd8d2e  call rax
00007d5be8fd8d30  movaps xmm4, [rsp]
00007d5be8fd8d34  add rsp, 0x30
00007d5be8fd8d38  vmovaps xmm0, [rsp]
00007d5be8fd8d3d  vmovaps xmm1, [rsp+0x10]
00007d5be8fd8d43  vmovaps xmm2, [rsp+0x20]
00007d5be8fd8d49  vmovaps xmm3, [rsp+0x30]
00007d5be8fd8d4f  vmovaps xmm5, [rsp+0x40]
00007d5be8fd8d55  vmovaps xmm6, [rsp+0x50]
00007d5be8fd8d5b  vmovaps xmm7, [rsp+0x60]
00007d5be8fd8d61  vmovaps xmm8, [rsp+0x70]
00007d5be8fd8d67  vmovaps xmm9, [rsp+0x80]
00007d5be8fd8d70  vmovaps xmm10, [rsp+0x90]
00007d5be8fd8d79  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd8d82  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd8d8b  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd8d94  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd8d9d  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd8da6  add rsp, 0xF0
00007d5be8fd8dad  pop r11
00007d5be8fd8daf  pop r10
00007d5be8fd8db1  pop r9
00007d5be8fd8db3  pop r8
00007d5be8fd8db5  pop rsi
00007d5be8fd8db6  pop rdi
00007d5be8fd8db7  pop rdx
00007d5be8fd8db8  pop rcx
00007d5be8fd8db9  pop rax
00007d5be8fd8dba  add rsp, 0x08
00007d5be8fd8dbe  jmp 0x00007D5BE8FD616B
00007d5be8fd8dc3  sub rsp, 0x08
00007d5be8fd8dc7  push rax
00007d5be8fd8dc8  push rcx
00007d5be8fd8dc9  push rdx
00007d5be8fd8dca  push rdi
00007d5be8fd8dcb  push rsi
00007d5be8fd8dcc  push r8
00007d5be8fd8dce  push r9
00007d5be8fd8dd0  push r10
00007d5be8fd8dd2  push r11
00007d5be8fd8dd4  sub rsp, 0xF0
00007d5be8fd8ddb  vmovaps [rsp], xmm0
00007d5be8fd8de0  vmovaps [rsp+0x10], xmm1
00007d5be8fd8de6  vmovaps [rsp+0x20], xmm2
00007d5be8fd8dec  vmovaps [rsp+0x30], xmm3
00007d5be8fd8df2  vmovaps [rsp+0x40], xmm4
00007d5be8fd8df8  vmovaps [rsp+0x50], xmm5
00007d5be8fd8dfe  vmovaps [rsp+0x60], xmm6
00007d5be8fd8e04  vmovaps [rsp+0x70], xmm7
00007d5be8fd8e0a  vmovaps [rsp+0x80], xmm8
00007d5be8fd8e13  vmovaps [rsp+0x90], xmm10
00007d5be8fd8e1c  vmovaps [rsp+0xA0], xmm11
00007d5be8fd8e25  vmovaps [rsp+0xB0], xmm12
00007d5be8fd8e2e  vmovaps [rsp+0xC0], xmm13
00007d5be8fd8e37  vmovaps [rsp+0xD0], xmm14
00007d5be8fd8e40  vmovaps [rsp+0xE0], xmm15
00007d5be8fd8e49  sub rsp, 0x30
00007d5be8fd8e4d  movaps [rsp], xmm9
00007d5be8fd8e52  movaps [rsp+0x10], xmm2
00007d5be8fd8e57  movaps [rsp+0x20], xmm1
00007d5be8fd8e5c  lea rdi, [rsp]
00007d5be8fd8e60  mov esi, 0x00
00007d5be8fd8e65  mov rax, 0x5D345705A530
00007d5be8fd8e6f  call rax
00007d5be8fd8e71  movaps xmm9, [rsp]
00007d5be8fd8e76  add rsp, 0x30
00007d5be8fd8e7a  vmovaps xmm0, [rsp]
00007d5be8fd8e7f  vmovaps xmm1, [rsp+0x10]
00007d5be8fd8e85  vmovaps xmm2, [rsp+0x20]
00007d5be8fd8e8b  vmovaps xmm3, [rsp+0x30]
00007d5be8fd8e91  vmovaps xmm4, [rsp+0x40]
00007d5be8fd8e97  vmovaps xmm5, [rsp+0x50]
00007d5be8fd8e9d  vmovaps xmm6, [rsp+0x60]
00007d5be8fd8ea3  vmovaps xmm7, [rsp+0x70]
00007d5be8fd8ea9  vmovaps xmm8, [rsp+0x80]
00007d5be8fd8eb2  vmovaps xmm10, [rsp+0x90]
00007d5be8fd8ebb  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd8ec4  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd8ecd  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd8ed6  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd8edf  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd8ee8  add rsp, 0xF0
00007d5be8fd8eef  pop r11
00007d5be8fd8ef1  pop r10
00007d5be8fd8ef3  pop r9
00007d5be8fd8ef5  pop r8
00007d5be8fd8ef7  pop rsi
00007d5be8fd8ef8  pop rdi
00007d5be8fd8ef9  pop rdx
00007d5be8fd8efa  pop rcx
00007d5be8fd8efb  pop rax
00007d5be8fd8efc  add rsp, 0x08
00007d5be8fd8f00  jmp 0x00007D5BE8FD61A1
00007d5be8fd8f05  sub rsp, 0x08
00007d5be8fd8f09  push rax
00007d5be8fd8f0a  push rcx
00007d5be8fd8f0b  push rdx
00007d5be8fd8f0c  push rdi
00007d5be8fd8f0d  push rsi
00007d5be8fd8f0e  push r8
00007d5be8fd8f10  push r9
00007d5be8fd8f12  push r10
00007d5be8fd8f14  push r11
00007d5be8fd8f16  sub rsp, 0xF0
00007d5be8fd8f1d  vmovaps [rsp], xmm0
00007d5be8fd8f22  vmovaps [rsp+0x10], xmm2
00007d5be8fd8f28  vmovaps [rsp+0x20], xmm3
00007d5be8fd8f2e  vmovaps [rsp+0x30], xmm4
00007d5be8fd8f34  vmovaps [rsp+0x40], xmm5
00007d5be8fd8f3a  vmovaps [rsp+0x50], xmm6
00007d5be8fd8f40  vmovaps [rsp+0x60], xmm7
00007d5be8fd8f46  vmovaps [rsp+0x70], xmm8
00007d5be8fd8f4c  vmovaps [rsp+0x80], xmm9
00007d5be8fd8f55  vmovaps [rsp+0x90], xmm10
00007d5be8fd8f5e  vmovaps [rsp+0xA0], xmm11
00007d5be8fd8f67  vmovaps [rsp+0xB0], xmm12
00007d5be8fd8f70  vmovaps [rsp+0xC0], xmm13
00007d5be8fd8f79  vmovaps [rsp+0xD0], xmm14
00007d5be8fd8f82  vmovaps [rsp+0xE0], xmm15
00007d5be8fd8f8b  sub rsp, 0x30
00007d5be8fd8f8f  movaps [rsp], xmm1
00007d5be8fd8f93  movaps [rsp+0x10], xmm15
00007d5be8fd8f99  movaps [rsp+0x20], xmm6
00007d5be8fd8f9e  lea rdi, [rsp]
00007d5be8fd8fa2  mov esi, 0x00
00007d5be8fd8fa7  mov rax, 0x5D345705A530
00007d5be8fd8fb1  call rax
00007d5be8fd8fb3  movaps xmm1, [rsp]
00007d5be8fd8fb7  add rsp, 0x30
00007d5be8fd8fbb  vmovaps xmm0, [rsp]
00007d5be8fd8fc0  vmovaps xmm2, [rsp+0x10]
00007d5be8fd8fc6  vmovaps xmm3, [rsp+0x20]
00007d5be8fd8fcc  vmovaps xmm4, [rsp+0x30]
00007d5be8fd8fd2  vmovaps xmm5, [rsp+0x40]
00007d5be8fd8fd8  vmovaps xmm6, [rsp+0x50]
00007d5be8fd8fde  vmovaps xmm7, [rsp+0x60]
00007d5be8fd8fe4  vmovaps xmm8, [rsp+0x70]
00007d5be8fd8fea  vmovaps xmm9, [rsp+0x80]
00007d5be8fd8ff3  vmovaps xmm10, [rsp+0x90]
00007d5be8fd8ffc  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd9005  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd900e  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd9017  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd9020  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd9029  add rsp, 0xF0
00007d5be8fd9030  pop r11
00007d5be8fd9032  pop r10
00007d5be8fd9034  pop r9
00007d5be8fd9036  pop r8
00007d5be8fd9038  pop rsi
00007d5be8fd9039  pop rdi
00007d5be8fd903a  pop rdx
00007d5be8fd903b  pop rcx
00007d5be8fd903c  pop rax
00007d5be8fd903d  add rsp, 0x08
00007d5be8fd9041  jmp 0x00007D5BE8FD61C2
00007d5be8fd9046  sub rsp, 0x08
00007d5be8fd904a  push rax
00007d5be8fd904b  push rcx
00007d5be8fd904c  push rdx
00007d5be8fd904d  push rdi
00007d5be8fd904e  push rsi
00007d5be8fd904f  push r8
00007d5be8fd9051  push r9
00007d5be8fd9053  push r10
00007d5be8fd9055  push r11
00007d5be8fd9057  sub rsp, 0xF0
00007d5be8fd905e  vmovaps [rsp], xmm0
00007d5be8fd9063  vmovaps [rsp+0x10], xmm1
00007d5be8fd9069  vmovaps [rsp+0x20], xmm2
00007d5be8fd906f  vmovaps [rsp+0x30], xmm3
00007d5be8fd9075  vmovaps [rsp+0x40], xmm4
00007d5be8fd907b  vmovaps [rsp+0x50], xmm5
00007d5be8fd9081  vmovaps [rsp+0x60], xmm6
00007d5be8fd9087  vmovaps [rsp+0x70], xmm7
00007d5be8fd908d  vmovaps [rsp+0x80], xmm8
00007d5be8fd9096  vmovaps [rsp+0x90], xmm9
00007d5be8fd909f  vmovaps [rsp+0xA0], xmm10
00007d5be8fd90a8  vmovaps [rsp+0xB0], xmm11
00007d5be8fd90b1  vmovaps [rsp+0xC0], xmm12
00007d5be8fd90ba  vmovaps [rsp+0xD0], xmm13
00007d5be8fd90c3  vmovaps [rsp+0xE0], xmm14
00007d5be8fd90cc  sub rsp, 0x30
00007d5be8fd90d0  movaps [rsp], xmm15
00007d5be8fd90d5  movaps [rsp+0x10], xmm5
00007d5be8fd90da  movaps [rsp+0x20], xmm3
00007d5be8fd90df  lea rdi, [rsp]
00007d5be8fd90e3  mov esi, 0x00
00007d5be8fd90e8  mov rax, 0x5D345705A530
00007d5be8fd90f2  call rax
00007d5be8fd90f4  movaps xmm15, [rsp]
00007d5be8fd90f9  add rsp, 0x30
00007d5be8fd90fd  vmovaps xmm0, [rsp]
00007d5be8fd9102  vmovaps xmm1, [rsp+0x10]
00007d5be8fd9108  vmovaps xmm2, [rsp+0x20]
00007d5be8fd910e  vmovaps xmm3, [rsp+0x30]
00007d5be8fd9114  vmovaps xmm4, [rsp+0x40]
00007d5be8fd911a  vmovaps xmm5, [rsp+0x50]
00007d5be8fd9120  vmovaps xmm6, [rsp+0x60]
00007d5be8fd9126  vmovaps xmm7, [rsp+0x70]
00007d5be8fd912c  vmovaps xmm8, [rsp+0x80]
00007d5be8fd9135  vmovaps xmm9, [rsp+0x90]
00007d5be8fd913e  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd9147  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd9150  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd9159  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd9162  vmovaps xmm14, [rsp+0xE0]
00007d5be8fd916b  add rsp, 0xF0
00007d5be8fd9172  pop r11
00007d5be8fd9174  pop r10
00007d5be8fd9176  pop r9
00007d5be8fd9178  pop r8
00007d5be8fd917a  pop rsi
00007d5be8fd917b  pop rdi
00007d5be8fd917c  pop rdx
00007d5be8fd917d  pop rcx
00007d5be8fd917e  pop rax
00007d5be8fd917f  add rsp, 0x08
00007d5be8fd9183  jmp 0x00007D5BE8FD61DC
00007d5be8fd9188  sub rsp, 0x08
00007d5be8fd918c  push rax
00007d5be8fd918d  push rcx
00007d5be8fd918e  push rdx
00007d5be8fd918f  push rdi
00007d5be8fd9190  push rsi
00007d5be8fd9191  push r8
00007d5be8fd9193  push r9
00007d5be8fd9195  push r10
00007d5be8fd9197  push r11
00007d5be8fd9199  sub rsp, 0xF0
00007d5be8fd91a0  vmovaps [rsp], xmm0
00007d5be8fd91a5  vmovaps [rsp+0x10], xmm1
00007d5be8fd91ab  vmovaps [rsp+0x20], xmm2
00007d5be8fd91b1  vmovaps [rsp+0x30], xmm3
00007d5be8fd91b7  vmovaps [rsp+0x40], xmm4
00007d5be8fd91bd  vmovaps [rsp+0x50], xmm6
00007d5be8fd91c3  vmovaps [rsp+0x60], xmm7
00007d5be8fd91c9  vmovaps [rsp+0x70], xmm8
00007d5be8fd91cf  vmovaps [rsp+0x80], xmm9
00007d5be8fd91d8  vmovaps [rsp+0x90], xmm10
00007d5be8fd91e1  vmovaps [rsp+0xA0], xmm11
00007d5be8fd91ea  vmovaps [rsp+0xB0], xmm12
00007d5be8fd91f3  vmovaps [rsp+0xC0], xmm13
00007d5be8fd91fc  vmovaps [rsp+0xD0], xmm14
00007d5be8fd9205  vmovaps [rsp+0xE0], xmm15
00007d5be8fd920e  sub rsp, 0x30
00007d5be8fd9212  movaps [rsp], xmm5
00007d5be8fd9216  movaps [rsp+0x10], xmm8
00007d5be8fd921c  movaps [rsp+0x20], xmm6
00007d5be8fd9221  lea rdi, [rsp]
00007d5be8fd9225  mov esi, 0x00
00007d5be8fd922a  mov rax, 0x5D345705A530
00007d5be8fd9234  call rax
00007d5be8fd9236  movaps xmm5, [rsp]
00007d5be8fd923a  add rsp, 0x30
00007d5be8fd923e  vmovaps xmm0, [rsp]
00007d5be8fd9243  vmovaps xmm1, [rsp+0x10]
00007d5be8fd9249  vmovaps xmm2, [rsp+0x20]
00007d5be8fd924f  vmovaps xmm3, [rsp+0x30]
00007d5be8fd9255  vmovaps xmm4, [rsp+0x40]
00007d5be8fd925b  vmovaps xmm6, [rsp+0x50]
00007d5be8fd9261  vmovaps xmm7, [rsp+0x60]
00007d5be8fd9267  vmovaps xmm8, [rsp+0x70]
00007d5be8fd926d  vmovaps xmm9, [rsp+0x80]
00007d5be8fd9276  vmovaps xmm10, [rsp+0x90]
00007d5be8fd927f  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd9288  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd9291  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd929a  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd92a3  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd92ac  add rsp, 0xF0
00007d5be8fd92b3  pop r11
00007d5be8fd92b5  pop r10
00007d5be8fd92b7  pop r9
00007d5be8fd92b9  pop r8
00007d5be8fd92bb  pop rsi
00007d5be8fd92bc  pop rdi
00007d5be8fd92bd  pop rdx
00007d5be8fd92be  pop rcx
00007d5be8fd92bf  pop rax
00007d5be8fd92c0  add rsp, 0x08
00007d5be8fd92c4  jmp 0x00007D5BE8FD6200
00007d5be8fd92c9  sub rsp, 0x08
00007d5be8fd92cd  push rax
00007d5be8fd92ce  push rcx
00007d5be8fd92cf  push rdx
00007d5be8fd92d0  push rdi
00007d5be8fd92d1  push rsi
00007d5be8fd92d2  push r8
00007d5be8fd92d4  push r9
00007d5be8fd92d6  push r10
00007d5be8fd92d8  push r11
00007d5be8fd92da  sub rsp, 0xF0
00007d5be8fd92e1  vmovaps [rsp], xmm0
00007d5be8fd92e6  vmovaps [rsp+0x10], xmm1
00007d5be8fd92ec  vmovaps [rsp+0x20], xmm2
00007d5be8fd92f2  vmovaps [rsp+0x30], xmm3
00007d5be8fd92f8  vmovaps [rsp+0x40], xmm4
00007d5be8fd92fe  vmovaps [rsp+0x50], xmm5
00007d5be8fd9304  vmovaps [rsp+0x60], xmm7
00007d5be8fd930a  vmovaps [rsp+0x70], xmm8
00007d5be8fd9310  vmovaps [rsp+0x80], xmm9
00007d5be8fd9319  vmovaps [rsp+0x90], xmm10
00007d5be8fd9322  vmovaps [rsp+0xA0], xmm11
00007d5be8fd932b  vmovaps [rsp+0xB0], xmm12
00007d5be8fd9334  vmovaps [rsp+0xC0], xmm13
00007d5be8fd933d  vmovaps [rsp+0xD0], xmm14
00007d5be8fd9346  vmovaps [rsp+0xE0], xmm15
00007d5be8fd934f  sub rsp, 0x30
00007d5be8fd9353  movaps [rsp], xmm6
00007d5be8fd9357  movaps [rsp+0x10], xmm10
00007d5be8fd935d  movaps [rsp+0x20], xmm8
00007d5be8fd9363  lea rdi, [rsp]
00007d5be8fd9367  mov esi, 0x00
00007d5be8fd936c  mov rax, 0x5D345705A530
00007d5be8fd9376  call rax
00007d5be8fd9378  movaps xmm6, [rsp]
00007d5be8fd937c  add rsp, 0x30
00007d5be8fd9380  vmovaps xmm0, [rsp]
00007d5be8fd9385  vmovaps xmm1, [rsp+0x10]
00007d5be8fd938b  vmovaps xmm2, [rsp+0x20]
00007d5be8fd9391  vmovaps xmm3, [rsp+0x30]
00007d5be8fd9397  vmovaps xmm4, [rsp+0x40]
00007d5be8fd939d  vmovaps xmm5, [rsp+0x50]
00007d5be8fd93a3  vmovaps xmm7, [rsp+0x60]
00007d5be8fd93a9  vmovaps xmm8, [rsp+0x70]
00007d5be8fd93af  vmovaps xmm9, [rsp+0x80]
00007d5be8fd93b8  vmovaps xmm10, [rsp+0x90]
00007d5be8fd93c1  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd93ca  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd93d3  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd93dc  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd93e5  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd93ee  add rsp, 0xF0
00007d5be8fd93f5  pop r11
00007d5be8fd93f7  pop r10
00007d5be8fd93f9  pop r9
00007d5be8fd93fb  pop r8
00007d5be8fd93fd  pop rsi
00007d5be8fd93fe  pop rdi
00007d5be8fd93ff  pop rdx
00007d5be8fd9400  pop rcx
00007d5be8fd9401  pop rax
00007d5be8fd9402  add rsp, 0x08
00007d5be8fd9406  jmp 0x00007D5BE8FD6225
00007d5be8fd940b  sub rsp, 0x08
00007d5be8fd940f  push rax
00007d5be8fd9410  push rcx
00007d5be8fd9411  push rdx
00007d5be8fd9412  push rdi
00007d5be8fd9413  push rsi
00007d5be8fd9414  push r8
00007d5be8fd9416  push r9
00007d5be8fd9418  push r10
00007d5be8fd941a  push r11
00007d5be8fd941c  sub rsp, 0xF0
00007d5be8fd9423  vmovaps [rsp], xmm0
00007d5be8fd9428  vmovaps [rsp+0x10], xmm1
00007d5be8fd942e  vmovaps [rsp+0x20], xmm2
00007d5be8fd9434  vmovaps [rsp+0x30], xmm3
00007d5be8fd943a  vmovaps [rsp+0x40], xmm4
00007d5be8fd9440  vmovaps [rsp+0x50], xmm5
00007d5be8fd9446  vmovaps [rsp+0x60], xmm6
00007d5be8fd944c  vmovaps [rsp+0x70], xmm7
00007d5be8fd9452  vmovaps [rsp+0x80], xmm8
00007d5be8fd945b  vmovaps [rsp+0x90], xmm9
00007d5be8fd9464  vmovaps [rsp+0xA0], xmm11
00007d5be8fd946d  vmovaps [rsp+0xB0], xmm12
00007d5be8fd9476  vmovaps [rsp+0xC0], xmm13
00007d5be8fd947f  vmovaps [rsp+0xD0], xmm14
00007d5be8fd9488  vmovaps [rsp+0xE0], xmm15
00007d5be8fd9491  sub rsp, 0x30
00007d5be8fd9495  movaps [rsp], xmm10
00007d5be8fd949a  movaps [rsp+0x10], xmm8
00007d5be8fd94a0  movaps [rsp+0x20], xmm14
00007d5be8fd94a6  lea rdi, [rsp]
00007d5be8fd94aa  mov esi, 0x00
00007d5be8fd94af  mov rax, 0x5D345705A530
00007d5be8fd94b9  call rax
00007d5be8fd94bb  movaps xmm10, [rsp]
00007d5be8fd94c0  add rsp, 0x30
00007d5be8fd94c4  vmovaps xmm0, [rsp]
00007d5be8fd94c9  vmovaps xmm1, [rsp+0x10]
00007d5be8fd94cf  vmovaps xmm2, [rsp+0x20]
00007d5be8fd94d5  vmovaps xmm3, [rsp+0x30]
00007d5be8fd94db  vmovaps xmm4, [rsp+0x40]
00007d5be8fd94e1  vmovaps xmm5, [rsp+0x50]
00007d5be8fd94e7  vmovaps xmm6, [rsp+0x60]
00007d5be8fd94ed  vmovaps xmm7, [rsp+0x70]
00007d5be8fd94f3  vmovaps xmm8, [rsp+0x80]
00007d5be8fd94fc  vmovaps xmm9, [rsp+0x90]
00007d5be8fd9505  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd950e  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd9517  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd9520  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd9529  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd9532  add rsp, 0xF0
00007d5be8fd9539  pop r11
00007d5be8fd953b  pop r10
00007d5be8fd953d  pop r9
00007d5be8fd953f  pop r8
00007d5be8fd9541  pop rsi
00007d5be8fd9542  pop rdi
00007d5be8fd9543  pop rdx
00007d5be8fd9544  pop rcx
00007d5be8fd9545  pop rax
00007d5be8fd9546  add rsp, 0x08
00007d5be8fd954a  jmp 0x00007D5BE8FD6245
00007d5be8fd954f  sub rsp, 0x08
00007d5be8fd9553  push rax
00007d5be8fd9554  push rcx
00007d5be8fd9555  push rdx
00007d5be8fd9556  push rdi
00007d5be8fd9557  push rsi
00007d5be8fd9558  push r8
00007d5be8fd955a  push r9
00007d5be8fd955c  push r10
00007d5be8fd955e  push r11
00007d5be8fd9560  sub rsp, 0xF0
00007d5be8fd9567  vmovaps [rsp], xmm0
00007d5be8fd956c  vmovaps [rsp+0x10], xmm1
00007d5be8fd9572  vmovaps [rsp+0x20], xmm2
00007d5be8fd9578  vmovaps [rsp+0x30], xmm3
00007d5be8fd957e  vmovaps [rsp+0x40], xmm4
00007d5be8fd9584  vmovaps [rsp+0x50], xmm5
00007d5be8fd958a  vmovaps [rsp+0x60], xmm6
00007d5be8fd9590  vmovaps [rsp+0x70], xmm7
00007d5be8fd9596  vmovaps [rsp+0x80], xmm8
00007d5be8fd959f  vmovaps [rsp+0x90], xmm9
00007d5be8fd95a8  vmovaps [rsp+0xA0], xmm10
00007d5be8fd95b1  vmovaps [rsp+0xB0], xmm11
00007d5be8fd95ba  vmovaps [rsp+0xC0], xmm12
00007d5be8fd95c3  vmovaps [rsp+0xD0], xmm13
00007d5be8fd95cc  vmovaps [rsp+0xE0], xmm15
00007d5be8fd95d5  sub rsp, 0x30
00007d5be8fd95d9  movaps [rsp], xmm14
00007d5be8fd95de  movaps [rsp+0x10], xmm8
00007d5be8fd95e4  movaps [rsp+0x20], xmm4
00007d5be8fd95e9  lea rdi, [rsp]
00007d5be8fd95ed  mov esi, 0x00
00007d5be8fd95f2  mov rax, 0x5D345705A530
00007d5be8fd95fc  call rax
00007d5be8fd95fe  movaps xmm14, [rsp]
00007d5be8fd9603  add rsp, 0x30
00007d5be8fd9607  vmovaps xmm0, [rsp]
00007d5be8fd960c  vmovaps xmm1, [rsp+0x10]
00007d5be8fd9612  vmovaps xmm2, [rsp+0x20]
00007d5be8fd9618  vmovaps xmm3, [rsp+0x30]
00007d5be8fd961e  vmovaps xmm4, [rsp+0x40]
00007d5be8fd9624  vmovaps xmm5, [rsp+0x50]
00007d5be8fd962a  vmovaps xmm6, [rsp+0x60]
00007d5be8fd9630  vmovaps xmm7, [rsp+0x70]
00007d5be8fd9636  vmovaps xmm8, [rsp+0x80]
00007d5be8fd963f  vmovaps xmm9, [rsp+0x90]
00007d5be8fd9648  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd9651  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd965a  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd9663  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd966c  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd9675  add rsp, 0xF0
00007d5be8fd967c  pop r11
00007d5be8fd967e  pop r10
00007d5be8fd9680  pop r9
00007d5be8fd9682  pop r8
00007d5be8fd9684  pop rsi
00007d5be8fd9685  pop rdi
00007d5be8fd9686  pop rdx
00007d5be8fd9687  pop rcx
00007d5be8fd9688  pop rax
00007d5be8fd9689  add rsp, 0x08
00007d5be8fd968d  jmp 0x00007D5BE8FD6265
00007d5be8fd9692  sub rsp, 0x08
00007d5be8fd9696  push rax
00007d5be8fd9697  push rcx
00007d5be8fd9698  push rdx
00007d5be8fd9699  push rdi
00007d5be8fd969a  push rsi
00007d5be8fd969b  push r8
00007d5be8fd969d  push r9
00007d5be8fd969f  push r10
00007d5be8fd96a1  push r11
00007d5be8fd96a3  sub rsp, 0xF0
00007d5be8fd96aa  vmovaps [rsp], xmm0
00007d5be8fd96af  vmovaps [rsp+0x10], xmm1
00007d5be8fd96b5  vmovaps [rsp+0x20], xmm2
00007d5be8fd96bb  vmovaps [rsp+0x30], xmm3
00007d5be8fd96c1  vmovaps [rsp+0x40], xmm5
00007d5be8fd96c7  vmovaps [rsp+0x50], xmm6
00007d5be8fd96cd  vmovaps [rsp+0x60], xmm7
00007d5be8fd96d3  vmovaps [rsp+0x70], xmm8
00007d5be8fd96d9  vmovaps [rsp+0x80], xmm9
00007d5be8fd96e2  vmovaps [rsp+0x90], xmm10
00007d5be8fd96eb  vmovaps [rsp+0xA0], xmm11
00007d5be8fd96f4  vmovaps [rsp+0xB0], xmm12
00007d5be8fd96fd  vmovaps [rsp+0xC0], xmm13
00007d5be8fd9706  vmovaps [rsp+0xD0], xmm14
00007d5be8fd970f  vmovaps [rsp+0xE0], xmm15
00007d5be8fd9718  sub rsp, 0x30
00007d5be8fd971c  movaps [rsp], xmm4
00007d5be8fd9720  movaps [rsp+0x10], xmm13
00007d5be8fd9726  movaps [rsp+0x20], xmm8
00007d5be8fd972c  lea rdi, [rsp]
00007d5be8fd9730  mov esi, 0x00
00007d5be8fd9735  mov rax, 0x5D345705A530
00007d5be8fd973f  call rax
00007d5be8fd9741  movaps xmm4, [rsp]
00007d5be8fd9745  add rsp, 0x30
00007d5be8fd9749  vmovaps xmm0, [rsp]
00007d5be8fd974e  vmovaps xmm1, [rsp+0x10]
00007d5be8fd9754  vmovaps xmm2, [rsp+0x20]
00007d5be8fd975a  vmovaps xmm3, [rsp+0x30]
00007d5be8fd9760  vmovaps xmm5, [rsp+0x40]
00007d5be8fd9766  vmovaps xmm6, [rsp+0x50]
00007d5be8fd976c  vmovaps xmm7, [rsp+0x60]
00007d5be8fd9772  vmovaps xmm8, [rsp+0x70]
00007d5be8fd9778  vmovaps xmm9, [rsp+0x80]
00007d5be8fd9781  vmovaps xmm10, [rsp+0x90]
00007d5be8fd978a  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd9793  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd979c  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd97a5  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd97ae  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd97b7  add rsp, 0xF0
00007d5be8fd97be  pop r11
00007d5be8fd97c0  pop r10
00007d5be8fd97c2  pop r9
00007d5be8fd97c4  pop r8
00007d5be8fd97c6  pop rsi
00007d5be8fd97c7  pop rdi
00007d5be8fd97c8  pop rdx
00007d5be8fd97c9  pop rcx
00007d5be8fd97ca  pop rax
00007d5be8fd97cb  add rsp, 0x08
00007d5be8fd97cf  jmp 0x00007D5BE8FD628A
00007d5be8fd97d4  sub rsp, 0x08
00007d5be8fd97d8  push rax
00007d5be8fd97d9  push rcx
00007d5be8fd97da  push rdx
00007d5be8fd97db  push rdi
00007d5be8fd97dc  push rsi
00007d5be8fd97dd  push r8
00007d5be8fd97df  push r9
00007d5be8fd97e1  push r10
00007d5be8fd97e3  push r11
00007d5be8fd97e5  sub rsp, 0xF0
00007d5be8fd97ec  vmovaps [rsp], xmm0
00007d5be8fd97f1  vmovaps [rsp+0x10], xmm1
00007d5be8fd97f7  vmovaps [rsp+0x20], xmm2
00007d5be8fd97fd  vmovaps [rsp+0x30], xmm3
00007d5be8fd9803  vmovaps [rsp+0x40], xmm4
00007d5be8fd9809  vmovaps [rsp+0x50], xmm5
00007d5be8fd980f  vmovaps [rsp+0x60], xmm6
00007d5be8fd9815  vmovaps [rsp+0x70], xmm7
00007d5be8fd981b  vmovaps [rsp+0x80], xmm8
00007d5be8fd9824  vmovaps [rsp+0x90], xmm9
00007d5be8fd982d  vmovaps [rsp+0xA0], xmm10
00007d5be8fd9836  vmovaps [rsp+0xB0], xmm11
00007d5be8fd983f  vmovaps [rsp+0xC0], xmm12
00007d5be8fd9848  vmovaps [rsp+0xD0], xmm14
00007d5be8fd9851  vmovaps [rsp+0xE0], xmm15
00007d5be8fd985a  sub rsp, 0x30
00007d5be8fd985e  movaps [rsp], xmm13
00007d5be8fd9863  movaps [rsp+0x10], xmm15
00007d5be8fd9869  movaps [rsp+0x20], xmm9
00007d5be8fd986f  lea rdi, [rsp]
00007d5be8fd9873  mov esi, 0x00
00007d5be8fd9878  mov rax, 0x5D345705A530
00007d5be8fd9882  call rax
00007d5be8fd9884  movaps xmm13, [rsp]
00007d5be8fd9889  add rsp, 0x30
00007d5be8fd988d  vmovaps xmm0, [rsp]
00007d5be8fd9892  vmovaps xmm1, [rsp+0x10]
00007d5be8fd9898  vmovaps xmm2, [rsp+0x20]
00007d5be8fd989e  vmovaps xmm3, [rsp+0x30]
00007d5be8fd98a4  vmovaps xmm4, [rsp+0x40]
00007d5be8fd98aa  vmovaps xmm5, [rsp+0x50]
00007d5be8fd98b0  vmovaps xmm6, [rsp+0x60]
00007d5be8fd98b6  vmovaps xmm7, [rsp+0x70]
00007d5be8fd98bc  vmovaps xmm8, [rsp+0x80]
00007d5be8fd98c5  vmovaps xmm9, [rsp+0x90]
00007d5be8fd98ce  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd98d7  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd98e0  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd98e9  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd98f2  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd98fb  add rsp, 0xF0
00007d5be8fd9902  pop r11
00007d5be8fd9904  pop r10
00007d5be8fd9906  pop r9
00007d5be8fd9908  pop r8
00007d5be8fd990a  pop rsi
00007d5be8fd990b  pop rdi
00007d5be8fd990c  pop rdx
00007d5be8fd990d  pop rcx
00007d5be8fd990e  pop rax
00007d5be8fd990f  add rsp, 0x08
00007d5be8fd9913  jmp 0x00007D5BE8FD62A5
00007d5be8fd9918  sub rsp, 0x08
00007d5be8fd991c  push rax
00007d5be8fd991d  push rcx
00007d5be8fd991e  push rdx
00007d5be8fd991f  push rdi
00007d5be8fd9920  push rsi
00007d5be8fd9921  push r8
00007d5be8fd9923  push r9
00007d5be8fd9925  push r10
00007d5be8fd9927  push r11
00007d5be8fd9929  sub rsp, 0xF0
00007d5be8fd9930  vmovaps [rsp], xmm0
00007d5be8fd9935  vmovaps [rsp+0x10], xmm1
00007d5be8fd993b  vmovaps [rsp+0x20], xmm2
00007d5be8fd9941  vmovaps [rsp+0x30], xmm3
00007d5be8fd9947  vmovaps [rsp+0x40], xmm4
00007d5be8fd994d  vmovaps [rsp+0x50], xmm5
00007d5be8fd9953  vmovaps [rsp+0x60], xmm6
00007d5be8fd9959  vmovaps [rsp+0x70], xmm7
00007d5be8fd995f  vmovaps [rsp+0x80], xmm8
00007d5be8fd9968  vmovaps [rsp+0x90], xmm9
00007d5be8fd9971  vmovaps [rsp+0xA0], xmm10
00007d5be8fd997a  vmovaps [rsp+0xB0], xmm11
00007d5be8fd9983  vmovaps [rsp+0xC0], xmm12
00007d5be8fd998c  vmovaps [rsp+0xD0], xmm13
00007d5be8fd9995  vmovaps [rsp+0xE0], xmm14
00007d5be8fd999e  sub rsp, 0x30
00007d5be8fd99a2  movaps [rsp], xmm15
00007d5be8fd99a7  movaps [rsp+0x10], xmm1
00007d5be8fd99ac  movaps [rsp+0x20], xmm5
00007d5be8fd99b1  lea rdi, [rsp]
00007d5be8fd99b5  mov esi, 0x00
00007d5be8fd99ba  mov rax, 0x5D345705A530
00007d5be8fd99c4  call rax
00007d5be8fd99c6  movaps xmm15, [rsp]
00007d5be8fd99cb  add rsp, 0x30
00007d5be8fd99cf  vmovaps xmm0, [rsp]
00007d5be8fd99d4  vmovaps xmm1, [rsp+0x10]
00007d5be8fd99da  vmovaps xmm2, [rsp+0x20]
00007d5be8fd99e0  vmovaps xmm3, [rsp+0x30]
00007d5be8fd99e6  vmovaps xmm4, [rsp+0x40]
00007d5be8fd99ec  vmovaps xmm5, [rsp+0x50]
00007d5be8fd99f2  vmovaps xmm6, [rsp+0x60]
00007d5be8fd99f8  vmovaps xmm7, [rsp+0x70]
00007d5be8fd99fe  vmovaps xmm8, [rsp+0x80]
00007d5be8fd9a07  vmovaps xmm9, [rsp+0x90]
00007d5be8fd9a10  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd9a19  vmovaps xmm11, [rsp+0xB0]
00007d5be8fd9a22  vmovaps xmm12, [rsp+0xC0]
00007d5be8fd9a2b  vmovaps xmm13, [rsp+0xD0]
00007d5be8fd9a34  vmovaps xmm14, [rsp+0xE0]
00007d5be8fd9a3d  add rsp, 0xF0
00007d5be8fd9a44  pop r11
00007d5be8fd9a46  pop r10
00007d5be8fd9a48  pop r9
00007d5be8fd9a4a  pop r8
00007d5be8fd9a4c  pop rsi
00007d5be8fd9a4d  pop rdi
00007d5be8fd9a4e  pop rdx
00007d5be8fd9a4f  pop rcx
00007d5be8fd9a50  pop rax
00007d5be8fd9a51  add rsp, 0x08
00007d5be8fd9a55  jmp 0x00007D5BE8FD62C0
00007d5be8fd9a5a  call 0x00007D5BE8ED64F0
00007d5be8fd9a5f  jmp 0x00007D5BE8FD631B
00007d5be8fd9a64  sub rsp, 0x08
00007d5be8fd9a68  push rax
00007d5be8fd9a69  push rcx
00007d5be8fd9a6a  push rdx
00007d5be8fd9a6b  push rdi
00007d5be8fd9a6c  push rsi
00007d5be8fd9a6d  push r8
00007d5be8fd9a6f  push r9
00007d5be8fd9a71  push r10
00007d5be8fd9a73  push r11
00007d5be8fd9a75  sub rsp, 0xF0
00007d5be8fd9a7c  vmovaps [rsp], xmm0
00007d5be8fd9a81  vmovaps [rsp+0x10], xmm1
00007d5be8fd9a87  vmovaps [rsp+0x20], xmm2
00007d5be8fd9a8d  vmovaps [rsp+0x30], xmm3
00007d5be8fd9a93  vmovaps [rsp+0x40], xmm4
00007d5be8fd9a99  vmovaps [rsp+0x50], xmm5
00007d5be8fd9a9f  vmovaps [rsp+0x60], xmm6
00007d5be8fd9aa5  vmovaps [rsp+0x70], xmm7
00007d5be8fd9aab  vmovaps [rsp+0x80], xmm8
00007d5be8fd9ab4  vmovaps [rsp+0x90], xmm10
00007d5be8fd9abd  vmovaps [rsp+0xA0], xmm11
00007d5be8fd9ac6  vmovaps [rsp+0xB0], xmm12
00007d5be8fd9acf  vmovaps [rsp+0xC0], xmm13
00007d5be8fd9ad8  vmovaps [rsp+0xD0], xmm14
00007d5be8fd9ae1  vmovaps [rsp+0xE0], xmm15
00007d5be8fd9aea  sub rsp, 0x30
00007d5be8fd9aee  movaps [rsp], xmm9
00007d5be8fd9af3  movaps [rsp+0x10], xmm8
00007d5be8fd9af9  movaps [rsp+0x20], xmm11
00007d5be8fd9aff  lea rdi, [rsp]
00007d5be8fd9b03  mov esi, 0x00
00007d5be8fd9b08  mov rax, 0x5D345705A530
00007d5be8fd9b12  call rax
00007d5be8fd9b14  movaps xmm9, [rsp]
00007d5be8fd9b19  add rsp, 0x30
00007d5be8fd9b1d  vmovaps xmm0, [rsp]
00007d5be8fd9b22  vmovaps xmm1, [rsp+0x10]
00007d5be8fd9b28  vmovaps xmm2, [rsp+0x20]
00007d5be8fd9b2e  vmovaps xmm3, [rsp+0x30]
00007d5be8fd9b34  vmovaps xmm4, [rsp+0x40]
00007d5be8fd9b3a  vmovaps xmm5, [rsp+0x50]
00007d5be8fd9b40  vmovaps xmm6, [rsp+0x60]
00007d5be8fd9b46  vmovaps xmm7, [rsp+0x70]
00007d5be8fd9b4c  vmovaps xmm8, [rsp+0x80]
00007d5be8fd9b55  vmovaps xmm10, [rsp+0x90]
00007d5be8fd9b5e  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd9b67  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd9b70  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd9b79  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd9b82  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd9b8b  add rsp, 0xF0
00007d5be8fd9b92  pop r11
00007d5be8fd9b94  pop r10
00007d5be8fd9b96  pop r9
00007d5be8fd9b98  pop r8
00007d5be8fd9b9a  pop rsi
00007d5be8fd9b9b  pop rdi
00007d5be8fd9b9c  pop rdx
00007d5be8fd9b9d  pop rcx
00007d5be8fd9b9e  pop rax
00007d5be8fd9b9f  add rsp, 0x08
00007d5be8fd9ba3  jmp 0x00007D5BE8FD6352
00007d5be8fd9ba8  sub rsp, 0x08
00007d5be8fd9bac  push rax
00007d5be8fd9bad  push rcx
00007d5be8fd9bae  push rdx
00007d5be8fd9baf  push rdi
00007d5be8fd9bb0  push rsi
00007d5be8fd9bb1  push r8
00007d5be8fd9bb3  push r9
00007d5be8fd9bb5  push r10
00007d5be8fd9bb7  push r11
00007d5be8fd9bb9  sub rsp, 0xF0
00007d5be8fd9bc0  vmovaps [rsp], xmm0
00007d5be8fd9bc5  vmovaps [rsp+0x10], xmm1
00007d5be8fd9bcb  vmovaps [rsp+0x20], xmm2
00007d5be8fd9bd1  vmovaps [rsp+0x30], xmm3
00007d5be8fd9bd7  vmovaps [rsp+0x40], xmm4
00007d5be8fd9bdd  vmovaps [rsp+0x50], xmm5
00007d5be8fd9be3  vmovaps [rsp+0x60], xmm6
00007d5be8fd9be9  vmovaps [rsp+0x70], xmm7
00007d5be8fd9bef  vmovaps [rsp+0x80], xmm8
00007d5be8fd9bf8  vmovaps [rsp+0x90], xmm9
00007d5be8fd9c01  vmovaps [rsp+0xA0], xmm10
00007d5be8fd9c0a  vmovaps [rsp+0xB0], xmm12
00007d5be8fd9c13  vmovaps [rsp+0xC0], xmm13
00007d5be8fd9c1c  vmovaps [rsp+0xD0], xmm14
00007d5be8fd9c25  vmovaps [rsp+0xE0], xmm15
00007d5be8fd9c2e  sub rsp, 0x30
00007d5be8fd9c32  movaps [rsp], xmm11
00007d5be8fd9c37  movaps [rsp+0x10], xmm10
00007d5be8fd9c3d  movaps [rsp+0x20], xmm6
00007d5be8fd9c42  lea rdi, [rsp]
00007d5be8fd9c46  mov esi, 0x00
00007d5be8fd9c4b  mov rax, 0x5D345705A530
00007d5be8fd9c55  call rax
00007d5be8fd9c57  movaps xmm11, [rsp]
00007d5be8fd9c5c  add rsp, 0x30
00007d5be8fd9c60  vmovaps xmm0, [rsp]
00007d5be8fd9c65  vmovaps xmm1, [rsp+0x10]
00007d5be8fd9c6b  vmovaps xmm2, [rsp+0x20]
00007d5be8fd9c71  vmovaps xmm3, [rsp+0x30]
00007d5be8fd9c77  vmovaps xmm4, [rsp+0x40]
00007d5be8fd9c7d  vmovaps xmm5, [rsp+0x50]
00007d5be8fd9c83  vmovaps xmm6, [rsp+0x60]
00007d5be8fd9c89  vmovaps xmm7, [rsp+0x70]
00007d5be8fd9c8f  vmovaps xmm8, [rsp+0x80]
00007d5be8fd9c98  vmovaps xmm9, [rsp+0x90]
00007d5be8fd9ca1  vmovaps xmm10, [rsp+0xA0]
00007d5be8fd9caa  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd9cb3  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd9cbc  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd9cc5  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd9cce  add rsp, 0xF0
00007d5be8fd9cd5  pop r11
00007d5be8fd9cd7  pop r10
00007d5be8fd9cd9  pop r9
00007d5be8fd9cdb  pop r8
00007d5be8fd9cdd  pop rsi
00007d5be8fd9cde  pop rdi
00007d5be8fd9cdf  pop rdx
00007d5be8fd9ce0  pop rcx
00007d5be8fd9ce1  pop rax
00007d5be8fd9ce2  add rsp, 0x08
00007d5be8fd9ce6  jmp 0x00007D5BE8FD636D
00007d5be8fd9ceb  sub rsp, 0x08
00007d5be8fd9cef  push rax
00007d5be8fd9cf0  push rcx
00007d5be8fd9cf1  push rdx
00007d5be8fd9cf2  push rdi
00007d5be8fd9cf3  push rsi
00007d5be8fd9cf4  push r8
00007d5be8fd9cf6  push r9
00007d5be8fd9cf8  push r10
00007d5be8fd9cfa  push r11
00007d5be8fd9cfc  sub rsp, 0xF0
00007d5be8fd9d03  vmovaps [rsp], xmm0
00007d5be8fd9d08  vmovaps [rsp+0x10], xmm1
00007d5be8fd9d0e  vmovaps [rsp+0x20], xmm2
00007d5be8fd9d14  vmovaps [rsp+0x30], xmm3
00007d5be8fd9d1a  vmovaps [rsp+0x40], xmm4
00007d5be8fd9d20  vmovaps [rsp+0x50], xmm5
00007d5be8fd9d26  vmovaps [rsp+0x60], xmm6
00007d5be8fd9d2c  vmovaps [rsp+0x70], xmm7
00007d5be8fd9d32  vmovaps [rsp+0x80], xmm8
00007d5be8fd9d3b  vmovaps [rsp+0x90], xmm9
00007d5be8fd9d44  vmovaps [rsp+0xA0], xmm11
00007d5be8fd9d4d  vmovaps [rsp+0xB0], xmm12
00007d5be8fd9d56  vmovaps [rsp+0xC0], xmm13
00007d5be8fd9d5f  vmovaps [rsp+0xD0], xmm14
00007d5be8fd9d68  vmovaps [rsp+0xE0], xmm15
00007d5be8fd9d71  sub rsp, 0x30
00007d5be8fd9d75  movaps [rsp], xmm10
00007d5be8fd9d7a  movaps [rsp+0x10], xmm14
00007d5be8fd9d80  movaps [rsp+0x20], xmm4
00007d5be8fd9d85  lea rdi, [rsp]
00007d5be8fd9d89  mov esi, 0x00
00007d5be8fd9d8e  mov rax, 0x5D345705A530
00007d5be8fd9d98  call rax
00007d5be8fd9d9a  movaps xmm10, [rsp]
00007d5be8fd9d9f  add rsp, 0x30
00007d5be8fd9da3  vmovaps xmm0, [rsp]
00007d5be8fd9da8  vmovaps xmm1, [rsp+0x10]
00007d5be8fd9dae  vmovaps xmm2, [rsp+0x20]
00007d5be8fd9db4  vmovaps xmm3, [rsp+0x30]
00007d5be8fd9dba  vmovaps xmm4, [rsp+0x40]
00007d5be8fd9dc0  vmovaps xmm5, [rsp+0x50]
00007d5be8fd9dc6  vmovaps xmm6, [rsp+0x60]
00007d5be8fd9dcc  vmovaps xmm7, [rsp+0x70]
00007d5be8fd9dd2  vmovaps xmm8, [rsp+0x80]
00007d5be8fd9ddb  vmovaps xmm9, [rsp+0x90]
00007d5be8fd9de4  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd9ded  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd9df6  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd9dff  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd9e08  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd9e11  add rsp, 0xF0
00007d5be8fd9e18  pop r11
00007d5be8fd9e1a  pop r10
00007d5be8fd9e1c  pop r9
00007d5be8fd9e1e  pop r8
00007d5be8fd9e20  pop rsi
00007d5be8fd9e21  pop rdi
00007d5be8fd9e22  pop rdx
00007d5be8fd9e23  pop rcx
00007d5be8fd9e24  pop rax
00007d5be8fd9e25  add rsp, 0x08
00007d5be8fd9e29  jmp 0x00007D5BE8FD6388
00007d5be8fd9e2e  sub rsp, 0x08
00007d5be8fd9e32  push rax
00007d5be8fd9e33  push rcx
00007d5be8fd9e34  push rdx
00007d5be8fd9e35  push rdi
00007d5be8fd9e36  push rsi
00007d5be8fd9e37  push r8
00007d5be8fd9e39  push r9
00007d5be8fd9e3b  push r10
00007d5be8fd9e3d  push r11
00007d5be8fd9e3f  sub rsp, 0xF0
00007d5be8fd9e46  vmovaps [rsp], xmm0
00007d5be8fd9e4b  vmovaps [rsp+0x10], xmm1
00007d5be8fd9e51  vmovaps [rsp+0x20], xmm2
00007d5be8fd9e57  vmovaps [rsp+0x30], xmm3
00007d5be8fd9e5d  vmovaps [rsp+0x40], xmm4
00007d5be8fd9e63  vmovaps [rsp+0x50], xmm5
00007d5be8fd9e69  vmovaps [rsp+0x60], xmm6
00007d5be8fd9e6f  vmovaps [rsp+0x70], xmm7
00007d5be8fd9e75  vmovaps [rsp+0x80], xmm9
00007d5be8fd9e7e  vmovaps [rsp+0x90], xmm10
00007d5be8fd9e87  vmovaps [rsp+0xA0], xmm11
00007d5be8fd9e90  vmovaps [rsp+0xB0], xmm12
00007d5be8fd9e99  vmovaps [rsp+0xC0], xmm13
00007d5be8fd9ea2  vmovaps [rsp+0xD0], xmm14
00007d5be8fd9eab  vmovaps [rsp+0xE0], xmm15
00007d5be8fd9eb4  sub rsp, 0x30
00007d5be8fd9eb8  movaps [rsp], xmm8
00007d5be8fd9ebd  movaps [rsp+0x10], xmm1
00007d5be8fd9ec2  movaps [rsp+0x20], xmm14
00007d5be8fd9ec8  lea rdi, [rsp]
00007d5be8fd9ecc  mov esi, 0x00
00007d5be8fd9ed1  mov rax, 0x5D345705A530
00007d5be8fd9edb  call rax
00007d5be8fd9edd  movaps xmm8, [rsp]
00007d5be8fd9ee2  add rsp, 0x30
00007d5be8fd9ee6  vmovaps xmm0, [rsp]
00007d5be8fd9eeb  vmovaps xmm1, [rsp+0x10]
00007d5be8fd9ef1  vmovaps xmm2, [rsp+0x20]
00007d5be8fd9ef7  vmovaps xmm3, [rsp+0x30]
00007d5be8fd9efd  vmovaps xmm4, [rsp+0x40]
00007d5be8fd9f03  vmovaps xmm5, [rsp+0x50]
00007d5be8fd9f09  vmovaps xmm6, [rsp+0x60]
00007d5be8fd9f0f  vmovaps xmm7, [rsp+0x70]
00007d5be8fd9f15  vmovaps xmm9, [rsp+0x80]
00007d5be8fd9f1e  vmovaps xmm10, [rsp+0x90]
00007d5be8fd9f27  vmovaps xmm11, [rsp+0xA0]
00007d5be8fd9f30  vmovaps xmm12, [rsp+0xB0]
00007d5be8fd9f39  vmovaps xmm13, [rsp+0xC0]
00007d5be8fd9f42  vmovaps xmm14, [rsp+0xD0]
00007d5be8fd9f4b  vmovaps xmm15, [rsp+0xE0]
00007d5be8fd9f54  add rsp, 0xF0
00007d5be8fd9f5b  pop r11
00007d5be8fd9f5d  pop r10
00007d5be8fd9f5f  pop r9
00007d5be8fd9f61  pop r8
00007d5be8fd9f63  pop rsi
00007d5be8fd9f64  pop rdi
00007d5be8fd9f65  pop rdx
00007d5be8fd9f66  pop rcx
00007d5be8fd9f67  pop rax
00007d5be8fd9f68  add rsp, 0x08
00007d5be8fd9f6c  jmp 0x00007D5BE8FD63AE
00007d5be8fd9f71  sub rsp, 0x08
00007d5be8fd9f75  push rax
00007d5be8fd9f76  push rcx
00007d5be8fd9f77  push rdx
00007d5be8fd9f78  push rdi
00007d5be8fd9f79  push rsi
00007d5be8fd9f7a  push r8
00007d5be8fd9f7c  push r9
00007d5be8fd9f7e  push r10
00007d5be8fd9f80  push r11
00007d5be8fd9f82  sub rsp, 0xF0
00007d5be8fd9f89  vmovaps [rsp], xmm0
00007d5be8fd9f8e  vmovaps [rsp+0x10], xmm1
00007d5be8fd9f94  vmovaps [rsp+0x20], xmm2
00007d5be8fd9f9a  vmovaps [rsp+0x30], xmm3
00007d5be8fd9fa0  vmovaps [rsp+0x40], xmm4
00007d5be8fd9fa6  vmovaps [rsp+0x50], xmm5
00007d5be8fd9fac  vmovaps [rsp+0x60], xmm7
00007d5be8fd9fb2  vmovaps [rsp+0x70], xmm8
00007d5be8fd9fb8  vmovaps [rsp+0x80], xmm9
00007d5be8fd9fc1  vmovaps [rsp+0x90], xmm10
00007d5be8fd9fca  vmovaps [rsp+0xA0], xmm11
00007d5be8fd9fd3  vmovaps [rsp+0xB0], xmm12
00007d5be8fd9fdc  vmovaps [rsp+0xC0], xmm13
00007d5be8fd9fe5  vmovaps [rsp+0xD0], xmm14
00007d5be8fd9fee  vmovaps [rsp+0xE0], xmm15
00007d5be8fd9ff7  sub rsp, 0x30
00007d5be8fd9ffb  movaps [rsp], xmm6
00007d5be8fd9fff  movaps [rsp+0x10], xmm1
00007d5be8fda004  movaps [rsp+0x20], xmm14
00007d5be8fda00a  lea rdi, [rsp]
00007d5be8fda00e  mov esi, 0x00
00007d5be8fda013  mov rax, 0x5D345705A530
00007d5be8fda01d  call rax
00007d5be8fda01f  movaps xmm6, [rsp]
00007d5be8fda023  add rsp, 0x30
00007d5be8fda027  vmovaps xmm0, [rsp]
00007d5be8fda02c  vmovaps xmm1, [rsp+0x10]
00007d5be8fda032  vmovaps xmm2, [rsp+0x20]
00007d5be8fda038  vmovaps xmm3, [rsp+0x30]
00007d5be8fda03e  vmovaps xmm4, [rsp+0x40]
00007d5be8fda044  vmovaps xmm5, [rsp+0x50]
00007d5be8fda04a  vmovaps xmm7, [rsp+0x60]
00007d5be8fda050  vmovaps xmm8, [rsp+0x70]
00007d5be8fda056  vmovaps xmm9, [rsp+0x80]
00007d5be8fda05f  vmovaps xmm10, [rsp+0x90]
00007d5be8fda068  vmovaps xmm11, [rsp+0xA0]
00007d5be8fda071  vmovaps xmm12, [rsp+0xB0]
00007d5be8fda07a  vmovaps xmm13, [rsp+0xC0]
00007d5be8fda083  vmovaps xmm14, [rsp+0xD0]
00007d5be8fda08c  vmovaps xmm15, [rsp+0xE0]
00007d5be8fda095  add rsp, 0xF0
00007d5be8fda09c  pop r11
00007d5be8fda09e  pop r10
00007d5be8fda0a0  pop r9
00007d5be8fda0a2  pop r8
00007d5be8fda0a4  pop rsi
00007d5be8fda0a5  pop rdi
00007d5be8fda0a6  pop rdx
00007d5be8fda0a7  pop rcx
00007d5be8fda0a8  pop rax
00007d5be8fda0a9  add rsp, 0x08
00007d5be8fda0ad  jmp 0x00007D5BE8FD63DA
00007d5be8fda0b2  sub rsp, 0x08
00007d5be8fda0b6  push rax
00007d5be8fda0b7  push rcx
00007d5be8fda0b8  push rdx
00007d5be8fda0b9  push rdi
00007d5be8fda0ba  push rsi
00007d5be8fda0bb  push r8
00007d5be8fda0bd  push r9
00007d5be8fda0bf  push r10
00007d5be8fda0c1  push r11
00007d5be8fda0c3  sub rsp, 0xF0
00007d5be8fda0ca  vmovaps [rsp], xmm0
00007d5be8fda0cf  vmovaps [rsp+0x10], xmm1
00007d5be8fda0d5  vmovaps [rsp+0x20], xmm2
00007d5be8fda0db  vmovaps [rsp+0x30], xmm3
00007d5be8fda0e1  vmovaps [rsp+0x40], xmm4
00007d5be8fda0e7  vmovaps [rsp+0x50], xmm5
00007d5be8fda0ed  vmovaps [rsp+0x60], xmm6
00007d5be8fda0f3  vmovaps [rsp+0x70], xmm7
00007d5be8fda0f9  vmovaps [rsp+0x80], xmm8
00007d5be8fda102  vmovaps [rsp+0x90], xmm9
00007d5be8fda10b  vmovaps [rsp+0xA0], xmm10
00007d5be8fda114  vmovaps [rsp+0xB0], xmm11
00007d5be8fda11d  vmovaps [rsp+0xC0], xmm12
00007d5be8fda126  vmovaps [rsp+0xD0], xmm13
00007d5be8fda12f  vmovaps [rsp+0xE0], xmm15
00007d5be8fda138  sub rsp, 0x30
00007d5be8fda13c  movaps [rsp], xmm14
00007d5be8fda141  movaps [rsp+0x10], xmm12
00007d5be8fda147  movaps [rsp+0x20], xmm1
00007d5be8fda14c  lea rdi, [rsp]
00007d5be8fda150  mov esi, 0x00
00007d5be8fda155  mov rax, 0x5D345705A530
00007d5be8fda15f  call rax
00007d5be8fda161  movaps xmm14, [rsp]
00007d5be8fda166  add rsp, 0x30
00007d5be8fda16a  vmovaps xmm0, [rsp]
00007d5be8fda16f  vmovaps xmm1, [rsp+0x10]
00007d5be8fda175  vmovaps xmm2, [rsp+0x20]
00007d5be8fda17b  vmovaps xmm3, [rsp+0x30]
00007d5be8fda181  vmovaps xmm4, [rsp+0x40]
00007d5be8fda187  vmovaps xmm5, [rsp+0x50]
00007d5be8fda18d  vmovaps xmm6, [rsp+0x60]
00007d5be8fda193  vmovaps xmm7, [rsp+0x70]
00007d5be8fda199  vmovaps xmm8, [rsp+0x80]
00007d5be8fda1a2  vmovaps xmm9, [rsp+0x90]
00007d5be8fda1ab  vmovaps xmm10, [rsp+0xA0]
00007d5be8fda1b4  vmovaps xmm11, [rsp+0xB0]
00007d5be8fda1bd  vmovaps xmm12, [rsp+0xC0]
00007d5be8fda1c6  vmovaps xmm13, [rsp+0xD0]
00007d5be8fda1cf  vmovaps xmm15, [rsp+0xE0]
00007d5be8fda1d8  add rsp, 0xF0
00007d5be8fda1df  pop r11
00007d5be8fda1e1  pop r10
00007d5be8fda1e3  pop r9
00007d5be8fda1e5  pop r8
00007d5be8fda1e7  pop rsi
00007d5be8fda1e8  pop rdi
00007d5be8fda1e9  pop rdx
00007d5be8fda1ea  pop rcx
00007d5be8fda1eb  pop rax
00007d5be8fda1ec  add rsp, 0x08
00007d5be8fda1f0  jmp 0x00007D5BE8FD6400
00007d5be8fda1f5  sub rsp, 0x08
00007d5be8fda1f9  push rax
00007d5be8fda1fa  push rcx
00007d5be8fda1fb  push rdx
00007d5be8fda1fc  push rdi
00007d5be8fda1fd  push rsi
00007d5be8fda1fe  push r8
00007d5be8fda200  push r9
00007d5be8fda202  push r10
00007d5be8fda204  push r11
00007d5be8fda206  sub rsp, 0xF0
00007d5be8fda20d  vmovaps [rsp], xmm0
00007d5be8fda212  vmovaps [rsp+0x10], xmm2
00007d5be8fda218  vmovaps [rsp+0x20], xmm3
00007d5be8fda21e  vmovaps [rsp+0x30], xmm4
00007d5be8fda224  vmovaps [rsp+0x40], xmm5
00007d5be8fda22a  vmovaps [rsp+0x50], xmm6
00007d5be8fda230  vmovaps [rsp+0x60], xmm7
00007d5be8fda236  vmovaps [rsp+0x70], xmm8
00007d5be8fda23c  vmovaps [rsp+0x80], xmm9
00007d5be8fda245  vmovaps [rsp+0x90], xmm10
00007d5be8fda24e  vmovaps [rsp+0xA0], xmm11
00007d5be8fda257  vmovaps [rsp+0xB0], xmm12
00007d5be8fda260  vmovaps [rsp+0xC0], xmm13
00007d5be8fda269  vmovaps [rsp+0xD0], xmm14
00007d5be8fda272  vmovaps [rsp+0xE0], xmm15
00007d5be8fda27b  sub rsp, 0x30
00007d5be8fda27f  movaps [rsp], xmm1
00007d5be8fda283  movaps [rsp+0x10], xmm13
00007d5be8fda289  movaps [rsp+0x20], xmm9
00007d5be8fda28f  lea rdi, [rsp]
00007d5be8fda293  mov esi, 0x00
00007d5be8fda298  mov rax, 0x5D345705A530
00007d5be8fda2a2  call rax
00007d5be8fda2a4  movaps xmm1, [rsp]
00007d5be8fda2a8  add rsp, 0x30
00007d5be8fda2ac  vmovaps xmm0, [rsp]
00007d5be8fda2b1  vmovaps xmm2, [rsp+0x10]
00007d5be8fda2b7  vmovaps xmm3, [rsp+0x20]
00007d5be8fda2bd  vmovaps xmm4, [rsp+0x30]
00007d5be8fda2c3  vmovaps xmm5, [rsp+0x40]
00007d5be8fda2c9  vmovaps xmm6, [rsp+0x50]
00007d5be8fda2cf  vmovaps xmm7, [rsp+0x60]
00007d5be8fda2d5  vmovaps xmm8, [rsp+0x70]
00007d5be8fda2db  vmovaps xmm9, [rsp+0x80]
00007d5be8fda2e4  vmovaps xmm10, [rsp+0x90]
00007d5be8fda2ed  vmovaps xmm11, [rsp+0xA0]
00007d5be8fda2f6  vmovaps xmm12, [rsp+0xB0]
00007d5be8fda2ff  vmovaps xmm13, [rsp+0xC0]
00007d5be8fda308  vmovaps xmm14, [rsp+0xD0]
00007d5be8fda311  vmovaps xmm15, [rsp+0xE0]
00007d5be8fda31a  add rsp, 0xF0
00007d5be8fda321  pop r11
00007d5be8fda323  pop r10
00007d5be8fda325  pop r9
00007d5be8fda327  pop r8
00007d5be8fda329  pop rsi
00007d5be8fda32a  pop rdi
00007d5be8fda32b  pop rdx
00007d5be8fda32c  pop rcx
00007d5be8fda32d  pop rax
00007d5be8fda32e  add rsp, 0x08
00007d5be8fda332  jmp 0x00007D5BE8FD641A
00007d5be8fda337  sub rsp, 0x08
00007d5be8fda33b  push rax
00007d5be8fda33c  push rcx
00007d5be8fda33d  push rdx
00007d5be8fda33e  push rdi
00007d5be8fda33f  push rsi
00007d5be8fda340  push r8
00007d5be8fda342  push r9
00007d5be8fda344  push r10
00007d5be8fda346  push r11
00007d5be8fda348  sub rsp, 0xF0
00007d5be8fda34f  vmovaps [rsp], xmm0
00007d5be8fda354  vmovaps [rsp+0x10], xmm1
00007d5be8fda35a  vmovaps [rsp+0x20], xmm2
00007d5be8fda360  vmovaps [rsp+0x30], xmm3
00007d5be8fda366  vmovaps [rsp+0x40], xmm4
00007d5be8fda36c  vmovaps [rsp+0x50], xmm5
00007d5be8fda372  vmovaps [rsp+0x60], xmm6
00007d5be8fda378  vmovaps [rsp+0x70], xmm7
00007d5be8fda37e  vmovaps [rsp+0x80], xmm8
00007d5be8fda387  vmovaps [rsp+0x90], xmm9
00007d5be8fda390  vmovaps [rsp+0xA0], xmm10
00007d5be8fda399  vmovaps [rsp+0xB0], xmm11
00007d5be8fda3a2  vmovaps [rsp+0xC0], xmm13
00007d5be8fda3ab  vmovaps [rsp+0xD0], xmm14
00007d5be8fda3b4  vmovaps [rsp+0xE0], xmm15
00007d5be8fda3bd  sub rsp, 0x30
00007d5be8fda3c1  movaps [rsp], xmm12
00007d5be8fda3c6  movaps [rsp+0x10], xmm7
00007d5be8fda3cb  movaps [rsp+0x20], xmm13
00007d5be8fda3d1  lea rdi, [rsp]
00007d5be8fda3d5  mov esi, 0x00
00007d5be8fda3da  mov rax, 0x5D345705A530
00007d5be8fda3e4  call rax
00007d5be8fda3e6  movaps xmm12, [rsp]
00007d5be8fda3eb  add rsp, 0x30
00007d5be8fda3ef  vmovaps xmm0, [rsp]
00007d5be8fda3f4  vmovaps xmm1, [rsp+0x10]
00007d5be8fda3fa  vmovaps xmm2, [rsp+0x20]
00007d5be8fda400  vmovaps xmm3, [rsp+0x30]
00007d5be8fda406  vmovaps xmm4, [rsp+0x40]
00007d5be8fda40c  vmovaps xmm5, [rsp+0x50]
00007d5be8fda412  vmovaps xmm6, [rsp+0x60]
00007d5be8fda418  vmovaps xmm7, [rsp+0x70]
00007d5be8fda41e  vmovaps xmm8, [rsp+0x80]
00007d5be8fda427  vmovaps xmm9, [rsp+0x90]
00007d5be8fda430  vmovaps xmm10, [rsp+0xA0]
00007d5be8fda439  vmovaps xmm11, [rsp+0xB0]
00007d5be8fda442  vmovaps xmm13, [rsp+0xC0]
00007d5be8fda44b  vmovaps xmm14, [rsp+0xD0]
00007d5be8fda454  vmovaps xmm15, [rsp+0xE0]
00007d5be8fda45d  add rsp, 0xF0
00007d5be8fda464  pop r11
00007d5be8fda466  pop r10
00007d5be8fda468  pop r9
00007d5be8fda46a  pop r8
00007d5be8fda46c  pop rsi
00007d5be8fda46d  pop rdi
00007d5be8fda46e  pop rdx
00007d5be8fda46f  pop rcx
00007d5be8fda470  pop rax
00007d5be8fda471  add rsp, 0x08
00007d5be8fda475  jmp 0x00007D5BE8FD6441
00007d5be8fda47a  sub rsp, 0x08
00007d5be8fda47e  push rax
00007d5be8fda47f  push rcx
00007d5be8fda480  push rdx
00007d5be8fda481  push rdi
00007d5be8fda482  push rsi
00007d5be8fda483  push r8
00007d5be8fda485  push r9
00007d5be8fda487  push r10
00007d5be8fda489  push r11
00007d5be8fda48b  sub rsp, 0xF0
00007d5be8fda492  vmovaps [rsp], xmm0
00007d5be8fda497  vmovaps [rsp+0x10], xmm1
00007d5be8fda49d  vmovaps [rsp+0x20], xmm2
00007d5be8fda4a3  vmovaps [rsp+0x30], xmm3
00007d5be8fda4a9  vmovaps [rsp+0x40], xmm4
00007d5be8fda4af  vmovaps [rsp+0x50], xmm5
00007d5be8fda4b5  vmovaps [rsp+0x60], xmm6
00007d5be8fda4bb  vmovaps [rsp+0x70], xmm7
00007d5be8fda4c1  vmovaps [rsp+0x80], xmm8
00007d5be8fda4ca  vmovaps [rsp+0x90], xmm9
00007d5be8fda4d3  vmovaps [rsp+0xA0], xmm10
00007d5be8fda4dc  vmovaps [rsp+0xB0], xmm11
00007d5be8fda4e5  vmovaps [rsp+0xC0], xmm12
00007d5be8fda4ee  vmovaps [rsp+0xD0], xmm14
00007d5be8fda4f7  vmovaps [rsp+0xE0], xmm15
00007d5be8fda500  sub rsp, 0x30
00007d5be8fda504  movaps [rsp], xmm13
00007d5be8fda509  movaps [rsp+0x10], xmm15
00007d5be8fda50f  movaps [rsp+0x20], xmm8
00007d5be8fda515  lea rdi, [rsp]
00007d5be8fda519  mov esi, 0x00
00007d5be8fda51e  mov rax, 0x5D345705A530
00007d5be8fda528  call rax
00007d5be8fda52a  movaps xmm13, [rsp]
00007d5be8fda52f  add rsp, 0x30
00007d5be8fda533  vmovaps xmm0, [rsp]
00007d5be8fda538  vmovaps xmm1, [rsp+0x10]
00007d5be8fda53e  vmovaps xmm2, [rsp+0x20]
00007d5be8fda544  vmovaps xmm3, [rsp+0x30]
00007d5be8fda54a  vmovaps xmm4, [rsp+0x40]
00007d5be8fda550  vmovaps xmm5, [rsp+0x50]
00007d5be8fda556  vmovaps xmm6, [rsp+0x60]
00007d5be8fda55c  vmovaps xmm7, [rsp+0x70]
00007d5be8fda562  vmovaps xmm8, [rsp+0x80]
00007d5be8fda56b  vmovaps xmm9, [rsp+0x90]
00007d5be8fda574  vmovaps xmm10, [rsp+0xA0]
00007d5be8fda57d  vmovaps xmm11, [rsp+0xB0]
00007d5be8fda586  vmovaps xmm12, [rsp+0xC0]
00007d5be8fda58f  vmovaps xmm14, [rsp+0xD0]
00007d5be8fda598  vmovaps xmm15, [rsp+0xE0]
00007d5be8fda5a1  add rsp, 0xF0
00007d5be8fda5a8  pop r11
00007d5be8fda5aa  pop r10
00007d5be8fda5ac  pop r9
00007d5be8fda5ae  pop r8
00007d5be8fda5b0  pop rsi
00007d5be8fda5b1  pop rdi
00007d5be8fda5b2  pop rdx
00007d5be8fda5b3  pop rcx
00007d5be8fda5b4  pop rax
00007d5be8fda5b5  add rsp, 0x08
00007d5be8fda5b9  jmp 0x00007D5BE8FD645C
00007d5be8fda5be  sub rsp, 0x08
00007d5be8fda5c2  push rax
00007d5be8fda5c3  push rcx
00007d5be8fda5c4  push rdx
00007d5be8fda5c5  push rdi
00007d5be8fda5c6  push rsi
00007d5be8fda5c7  push r8
00007d5be8fda5c9  push r9
00007d5be8fda5cb  push r10
00007d5be8fda5cd  push r11
00007d5be8fda5cf  sub rsp, 0xF0
00007d5be8fda5d6  vmovaps [rsp], xmm0
00007d5be8fda5db  vmovaps [rsp+0x10], xmm1
00007d5be8fda5e1  vmovaps [rsp+0x20], xmm2
00007d5be8fda5e7  vmovaps [rsp+0x30], xmm3
00007d5be8fda5ed  vmovaps [rsp+0x40], xmm4
00007d5be8fda5f3  vmovaps [rsp+0x50], xmm5
00007d5be8fda5f9  vmovaps [rsp+0x60], xmm6
00007d5be8fda5ff  vmovaps [rsp+0x70], xmm7
00007d5be8fda605  vmovaps [rsp+0x80], xmm9
00007d5be8fda60e  vmovaps [rsp+0x90], xmm10
00007d5be8fda617  vmovaps [rsp+0xA0], xmm11
00007d5be8fda620  vmovaps [rsp+0xB0], xmm12
00007d5be8fda629  vmovaps [rsp+0xC0], xmm13
00007d5be8fda632  vmovaps [rsp+0xD0], xmm14
00007d5be8fda63b  vmovaps [rsp+0xE0], xmm15
00007d5be8fda644  sub rsp, 0x30
00007d5be8fda648  movaps [rsp], xmm8
00007d5be8fda64d  movaps [rsp+0x10], xmm15
00007d5be8fda653  movaps [rsp+0x20], xmm9
00007d5be8fda659  lea rdi, [rsp]
00007d5be8fda65d  mov esi, 0x00
00007d5be8fda662  mov rax, 0x5D345705A530
00007d5be8fda66c  call rax
00007d5be8fda66e  movaps xmm8, [rsp]
00007d5be8fda673  add rsp, 0x30
00007d5be8fda677  vmovaps xmm0, [rsp]
00007d5be8fda67c  vmovaps xmm1, [rsp+0x10]
00007d5be8fda682  vmovaps xmm2, [rsp+0x20]
00007d5be8fda688  vmovaps xmm3, [rsp+0x30]
00007d5be8fda68e  vmovaps xmm4, [rsp+0x40]
00007d5be8fda694  vmovaps xmm5, [rsp+0x50]
00007d5be8fda69a  vmovaps xmm6, [rsp+0x60]
00007d5be8fda6a0  vmovaps xmm7, [rsp+0x70]
00007d5be8fda6a6  vmovaps xmm9, [rsp+0x80]
00007d5be8fda6af  vmovaps xmm10, [rsp+0x90]
00007d5be8fda6b8  vmovaps xmm11, [rsp+0xA0]
00007d5be8fda6c1  vmovaps xmm12, [rsp+0xB0]
00007d5be8fda6ca  vmovaps xmm13, [rsp+0xC0]
00007d5be8fda6d3  vmovaps xmm14, [rsp+0xD0]
00007d5be8fda6dc  vmovaps xmm15, [rsp+0xE0]
00007d5be8fda6e5  add rsp, 0xF0
00007d5be8fda6ec  pop r11
00007d5be8fda6ee  pop r10
00007d5be8fda6f0  pop r9
00007d5be8fda6f2  pop r8
00007d5be8fda6f4  pop rsi
00007d5be8fda6f5  pop rdi
00007d5be8fda6f6  pop rdx
00007d5be8fda6f7  pop rcx
00007d5be8fda6f8  pop rax
00007d5be8fda6f9  add rsp, 0x08
00007d5be8fda6fd  jmp 0x00007D5BE8FD648A
00007d5be8fda702  sub rsp, 0x08
00007d5be8fda706  push rax
00007d5be8fda707  push rcx
00007d5be8fda708  push rdx
00007d5be8fda709  push rdi
00007d5be8fda70a  push rsi
00007d5be8fda70b  push r8
00007d5be8fda70d  push r9
00007d5be8fda70f  push r10
00007d5be8fda711  push r11
00007d5be8fda713  sub rsp, 0xF0
00007d5be8fda71a  vmovaps [rsp], xmm0
00007d5be8fda71f  vmovaps [rsp+0x10], xmm1
00007d5be8fda725  vmovaps [rsp+0x20], xmm2
00007d5be8fda72b  vmovaps [rsp+0x30], xmm3
00007d5be8fda731  vmovaps [rsp+0x40], xmm4
00007d5be8fda737  vmovaps [rsp+0x50], xmm5
00007d5be8fda73d  vmovaps [rsp+0x60], xmm6
00007d5be8fda743  vmovaps [rsp+0x70], xmm7
00007d5be8fda749  vmovaps [rsp+0x80], xmm8
00007d5be8fda752  vmovaps [rsp+0x90], xmm9
00007d5be8fda75b  vmovaps [rsp+0xA0], xmm10
00007d5be8fda764  vmovaps [rsp+0xB0], xmm11
00007d5be8fda76d  vmovaps [rsp+0xC0], xmm12
00007d5be8fda776  vmovaps [rsp+0xD0], xmm13
00007d5be8fda77f  vmovaps [rsp+0xE0], xmm14
00007d5be8fda788  sub rsp, 0x30
00007d5be8fda78c  movaps [rsp], xmm15
00007d5be8fda791  movaps [rsp+0x10], xmm11
00007d5be8fda797  movaps [rsp+0x20], xmm6
00007d5be8fda79c  lea rdi, [rsp]
00007d5be8fda7a0  mov esi, 0x00
00007d5be8fda7a5  mov rax, 0x5D345705A530
00007d5be8fda7af  call rax
00007d5be8fda7b1  movaps xmm15, [rsp]
00007d5be8fda7b6  add rsp, 0x30
00007d5be8fda7ba  vmovaps xmm0, [rsp]
00007d5be8fda7bf  vmovaps xmm1, [rsp+0x10]
00007d5be8fda7c5  vmovaps xmm2, [rsp+0x20]
00007d5be8fda7cb  vmovaps xmm3, [rsp+0x30]
00007d5be8fda7d1  vmovaps xmm4, [rsp+0x40]
00007d5be8fda7d7  vmovaps xmm5, [rsp+0x50]
00007d5be8fda7dd  vmovaps xmm6, [rsp+0x60]
00007d5be8fda7e3  vmovaps xmm7, [rsp+0x70]
00007d5be8fda7e9  vmovaps xmm8, [rsp+0x80]
00007d5be8fda7f2  vmovaps xmm9, [rsp+0x90]
00007d5be8fda7fb  vmovaps xmm10, [rsp+0xA0]
00007d5be8fda804  vmovaps xmm11, [rsp+0xB0]
00007d5be8fda80d  vmovaps xmm12, [rsp+0xC0]
00007d5be8fda816  vmovaps xmm13, [rsp+0xD0]
00007d5be8fda81f  vmovaps xmm14, [rsp+0xE0]
00007d5be8fda828  add rsp, 0xF0
00007d5be8fda82f  pop r11
00007d5be8fda831  pop r10
00007d5be8fda833  pop r9
00007d5be8fda835  pop r8
00007d5be8fda837  pop rsi
00007d5be8fda838  pop rdi
00007d5be8fda839  pop rdx
00007d5be8fda83a  pop rcx
00007d5be8fda83b  pop rax
00007d5be8fda83c  add rsp, 0x08
00007d5be8fda840  jmp 0x00007D5BE8FD64A5
00007d5be8fda845  sub rsp, 0x08
00007d5be8fda849  push rax
00007d5be8fda84a  push rcx
00007d5be8fda84b  push rdx
00007d5be8fda84c  push rdi
00007d5be8fda84d  push rsi
00007d5be8fda84e  push r8
00007d5be8fda850  push r9
00007d5be8fda852  push r10
00007d5be8fda854  push r11
00007d5be8fda856  sub rsp, 0xF0
00007d5be8fda85d  vmovaps [rsp], xmm0
00007d5be8fda862  vmovaps [rsp+0x10], xmm1
00007d5be8fda868  vmovaps [rsp+0x20], xmm2
00007d5be8fda86e  vmovaps [rsp+0x30], xmm3
00007d5be8fda874  vmovaps [rsp+0x40], xmm4
00007d5be8fda87a  vmovaps [rsp+0x50], xmm5
00007d5be8fda880  vmovaps [rsp+0x60], xmm6
00007d5be8fda886  vmovaps [rsp+0x70], xmm8
00007d5be8fda88c  vmovaps [rsp+0x80], xmm9
00007d5be8fda895  vmovaps [rsp+0x90], xmm10
00007d5be8fda89e  vmovaps [rsp+0xA0], xmm11
00007d5be8fda8a7  vmovaps [rsp+0xB0], xmm12
00007d5be8fda8b0  vmovaps [rsp+0xC0], xmm13
00007d5be8fda8b9  vmovaps [rsp+0xD0], xmm14
00007d5be8fda8c2  vmovaps [rsp+0xE0], xmm15
00007d5be8fda8cb  sub rsp, 0x30
00007d5be8fda8cf  movaps [rsp], xmm7
00007d5be8fda8d3  movaps [rsp+0x10], xmm11
00007d5be8fda8d9  movaps [rsp+0x20], xmm9
00007d5be8fda8df  lea rdi, [rsp]
00007d5be8fda8e3  mov esi, 0x00
00007d5be8fda8e8  mov rax, 0x5D345705A530
00007d5be8fda8f2  call rax
00007d5be8fda8f4  movaps xmm7, [rsp]
00007d5be8fda8f8  add rsp, 0x30
00007d5be8fda8fc  vmovaps xmm0, [rsp]
00007d5be8fda901  vmovaps xmm1, [rsp+0x10]
00007d5be8fda907  vmovaps xmm2, [rsp+0x20]
00007d5be8fda90d  vmovaps xmm3, [rsp+0x30]
00007d5be8fda913  vmovaps xmm4, [rsp+0x40]
00007d5be8fda919  vmovaps xmm5, [rsp+0x50]
00007d5be8fda91f  vmovaps xmm6, [rsp+0x60]
00007d5be8fda925  vmovaps xmm8, [rsp+0x70]
00007d5be8fda92b  vmovaps xmm9, [rsp+0x80]
00007d5be8fda934  vmovaps xmm10, [rsp+0x90]
00007d5be8fda93d  vmovaps xmm11, [rsp+0xA0]
00007d5be8fda946  vmovaps xmm12, [rsp+0xB0]
00007d5be8fda94f  vmovaps xmm13, [rsp+0xC0]
00007d5be8fda958  vmovaps xmm14, [rsp+0xD0]
00007d5be8fda961  vmovaps xmm15, [rsp+0xE0]
00007d5be8fda96a  add rsp, 0xF0
00007d5be8fda971  pop r11
00007d5be8fda973  pop r10
00007d5be8fda975  pop r9
00007d5be8fda977  pop r8
00007d5be8fda979  pop rsi
00007d5be8fda97a  pop rdi
00007d5be8fda97b  pop rdx
00007d5be8fda97c  pop rcx
00007d5be8fda97d  pop rax
00007d5be8fda97e  add rsp, 0x08
00007d5be8fda982  jmp 0x00007D5BE8FD64D2
00007d5be8fda987  sub rsp, 0x08
00007d5be8fda98b  push rax
00007d5be8fda98c  push rcx
00007d5be8fda98d  push rdx
00007d5be8fda98e  push rdi
00007d5be8fda98f  push rsi
00007d5be8fda990  push r8
00007d5be8fda992  push r9
00007d5be8fda994  push r10
00007d5be8fda996  push r11
00007d5be8fda998  sub rsp, 0xF0
00007d5be8fda99f  vmovaps [rsp], xmm0
00007d5be8fda9a4  vmovaps [rsp+0x10], xmm1
00007d5be8fda9aa  vmovaps [rsp+0x20], xmm2
00007d5be8fda9b0  vmovaps [rsp+0x30], xmm3
00007d5be8fda9b6  vmovaps [rsp+0x40], xmm4
00007d5be8fda9bc  vmovaps [rsp+0x50], xmm5
00007d5be8fda9c2  vmovaps [rsp+0x60], xmm6
00007d5be8fda9c8  vmovaps [rsp+0x70], xmm7
00007d5be8fda9ce  vmovaps [rsp+0x80], xmm8
00007d5be8fda9d7  vmovaps [rsp+0x90], xmm9
00007d5be8fda9e0  vmovaps [rsp+0xA0], xmm10
00007d5be8fda9e9  vmovaps [rsp+0xB0], xmm12
00007d5be8fda9f2  vmovaps [rsp+0xC0], xmm13
00007d5be8fda9fb  vmovaps [rsp+0xD0], xmm14
00007d5be8fdaa04  vmovaps [rsp+0xE0], xmm15
00007d5be8fdaa0d  sub rsp, 0x30
00007d5be8fdaa11  movaps [rsp], xmm11
00007d5be8fdaa16  movaps [rsp+0x10], xmm10
00007d5be8fdaa1c  movaps [rsp+0x20], xmm14
00007d5be8fdaa22  lea rdi, [rsp]
00007d5be8fdaa26  mov esi, 0x00
00007d5be8fdaa2b  mov rax, 0x5D345705A530
00007d5be8fdaa35  call rax
00007d5be8fdaa37  movaps xmm11, [rsp]
00007d5be8fdaa3c  add rsp, 0x30
00007d5be8fdaa40  vmovaps xmm0, [rsp]
00007d5be8fdaa45  vmovaps xmm1, [rsp+0x10]
00007d5be8fdaa4b  vmovaps xmm2, [rsp+0x20]
00007d5be8fdaa51  vmovaps xmm3, [rsp+0x30]
00007d5be8fdaa57  vmovaps xmm4, [rsp+0x40]
00007d5be8fdaa5d  vmovaps xmm5, [rsp+0x50]
00007d5be8fdaa63  vmovaps xmm6, [rsp+0x60]
00007d5be8fdaa69  vmovaps xmm7, [rsp+0x70]
00007d5be8fdaa6f  vmovaps xmm8, [rsp+0x80]
00007d5be8fdaa78  vmovaps xmm9, [rsp+0x90]
00007d5be8fdaa81  vmovaps xmm10, [rsp+0xA0]
00007d5be8fdaa8a  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdaa93  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdaa9c  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdaaa5  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdaaae  add rsp, 0xF0
00007d5be8fdaab5  pop r11
00007d5be8fdaab7  pop r10
00007d5be8fdaab9  pop r9
00007d5be8fdaabb  pop r8
00007d5be8fdaabd  pop rsi
00007d5be8fdaabe  pop rdi
00007d5be8fdaabf  pop rdx
00007d5be8fdaac0  pop rcx
00007d5be8fdaac1  pop rax
00007d5be8fdaac2  add rsp, 0x08
00007d5be8fdaac6  jmp 0x00007D5BE8FD64ED
00007d5be8fdaacb  call 0x00007D5BE8EE45A0
00007d5be8fdaad0  jmp 0x00007D5BE8FD64F7
00007d5be8fdaad5  sub rsp, 0x08
00007d5be8fdaad9  push rax
00007d5be8fdaada  push rcx
00007d5be8fdaadb  push rdx
00007d5be8fdaadc  push rdi
00007d5be8fdaadd  push rsi
00007d5be8fdaade  push r8
00007d5be8fdaae0  push r9
00007d5be8fdaae2  push r10
00007d5be8fdaae4  push r11
00007d5be8fdaae6  sub rsp, 0xF0
00007d5be8fdaaed  vmovaps [rsp], xmm0
00007d5be8fdaaf2  vmovaps [rsp+0x10], xmm1
00007d5be8fdaaf8  vmovaps [rsp+0x20], xmm2
00007d5be8fdaafe  vmovaps [rsp+0x30], xmm3
00007d5be8fdab04  vmovaps [rsp+0x40], xmm4
00007d5be8fdab0a  vmovaps [rsp+0x50], xmm5
00007d5be8fdab10  vmovaps [rsp+0x60], xmm6
00007d5be8fdab16  vmovaps [rsp+0x70], xmm7
00007d5be8fdab1c  vmovaps [rsp+0x80], xmm8
00007d5be8fdab25  vmovaps [rsp+0x90], xmm9
00007d5be8fdab2e  vmovaps [rsp+0xA0], xmm11
00007d5be8fdab37  vmovaps [rsp+0xB0], xmm12
00007d5be8fdab40  vmovaps [rsp+0xC0], xmm13
00007d5be8fdab49  vmovaps [rsp+0xD0], xmm14
00007d5be8fdab52  vmovaps [rsp+0xE0], xmm15
00007d5be8fdab5b  sub rsp, 0x30
00007d5be8fdab5f  movaps [rsp], xmm10
00007d5be8fdab64  movaps [rsp+0x10], xmm1
00007d5be8fdab69  movaps [rsp+0x20], xmm12
00007d5be8fdab6f  lea rdi, [rsp]
00007d5be8fdab73  mov esi, 0x00
00007d5be8fdab78  mov rax, 0x5D345705A530
00007d5be8fdab82  call rax
00007d5be8fdab84  movaps xmm10, [rsp]
00007d5be8fdab89  add rsp, 0x30
00007d5be8fdab8d  vmovaps xmm0, [rsp]
00007d5be8fdab92  vmovaps xmm1, [rsp+0x10]
00007d5be8fdab98  vmovaps xmm2, [rsp+0x20]
00007d5be8fdab9e  vmovaps xmm3, [rsp+0x30]
00007d5be8fdaba4  vmovaps xmm4, [rsp+0x40]
00007d5be8fdabaa  vmovaps xmm5, [rsp+0x50]
00007d5be8fdabb0  vmovaps xmm6, [rsp+0x60]
00007d5be8fdabb6  vmovaps xmm7, [rsp+0x70]
00007d5be8fdabbc  vmovaps xmm8, [rsp+0x80]
00007d5be8fdabc5  vmovaps xmm9, [rsp+0x90]
00007d5be8fdabce  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdabd7  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdabe0  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdabe9  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdabf2  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdabfb  add rsp, 0xF0
00007d5be8fdac02  pop r11
00007d5be8fdac04  pop r10
00007d5be8fdac06  pop r9
00007d5be8fdac08  pop r8
00007d5be8fdac0a  pop rsi
00007d5be8fdac0b  pop rdi
00007d5be8fdac0c  pop rdx
00007d5be8fdac0d  pop rcx
00007d5be8fdac0e  pop rax
00007d5be8fdac0f  add rsp, 0x08
00007d5be8fdac13  jmp 0x00007D5BE8FD651A
00007d5be8fdac18  sub rsp, 0x08
00007d5be8fdac1c  push rax
00007d5be8fdac1d  push rcx
00007d5be8fdac1e  push rdx
00007d5be8fdac1f  push rdi
00007d5be8fdac20  push rsi
00007d5be8fdac21  push r8
00007d5be8fdac23  push r9
00007d5be8fdac25  push r10
00007d5be8fdac27  push r11
00007d5be8fdac29  sub rsp, 0xF0
00007d5be8fdac30  vmovaps [rsp], xmm0
00007d5be8fdac35  vmovaps [rsp+0x10], xmm1
00007d5be8fdac3b  vmovaps [rsp+0x20], xmm2
00007d5be8fdac41  vmovaps [rsp+0x30], xmm3
00007d5be8fdac47  vmovaps [rsp+0x40], xmm4
00007d5be8fdac4d  vmovaps [rsp+0x50], xmm5
00007d5be8fdac53  vmovaps [rsp+0x60], xmm6
00007d5be8fdac59  vmovaps [rsp+0x70], xmm7
00007d5be8fdac5f  vmovaps [rsp+0x80], xmm8
00007d5be8fdac68  vmovaps [rsp+0x90], xmm9
00007d5be8fdac71  vmovaps [rsp+0xA0], xmm10
00007d5be8fdac7a  vmovaps [rsp+0xB0], xmm11
00007d5be8fdac83  vmovaps [rsp+0xC0], xmm13
00007d5be8fdac8c  vmovaps [rsp+0xD0], xmm14
00007d5be8fdac95  vmovaps [rsp+0xE0], xmm15
00007d5be8fdac9e  sub rsp, 0x30
00007d5be8fdaca2  movaps [rsp], xmm12
00007d5be8fdaca7  movaps [rsp+0x10], xmm14
00007d5be8fdacad  movaps [rsp+0x20], xmm1
00007d5be8fdacb2  lea rdi, [rsp]
00007d5be8fdacb6  mov esi, 0x00
00007d5be8fdacbb  mov rax, 0x5D345705A530
00007d5be8fdacc5  call rax
00007d5be8fdacc7  movaps xmm12, [rsp]
00007d5be8fdaccc  add rsp, 0x30
00007d5be8fdacd0  vmovaps xmm0, [rsp]
00007d5be8fdacd5  vmovaps xmm1, [rsp+0x10]
00007d5be8fdacdb  vmovaps xmm2, [rsp+0x20]
00007d5be8fdace1  vmovaps xmm3, [rsp+0x30]
00007d5be8fdace7  vmovaps xmm4, [rsp+0x40]
00007d5be8fdaced  vmovaps xmm5, [rsp+0x50]
00007d5be8fdacf3  vmovaps xmm6, [rsp+0x60]
00007d5be8fdacf9  vmovaps xmm7, [rsp+0x70]
00007d5be8fdacff  vmovaps xmm8, [rsp+0x80]
00007d5be8fdad08  vmovaps xmm9, [rsp+0x90]
00007d5be8fdad11  vmovaps xmm10, [rsp+0xA0]
00007d5be8fdad1a  vmovaps xmm11, [rsp+0xB0]
00007d5be8fdad23  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdad2c  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdad35  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdad3e  add rsp, 0xF0
00007d5be8fdad45  pop r11
00007d5be8fdad47  pop r10
00007d5be8fdad49  pop r9
00007d5be8fdad4b  pop r8
00007d5be8fdad4d  pop rsi
00007d5be8fdad4e  pop rdi
00007d5be8fdad4f  pop rdx
00007d5be8fdad50  pop rcx
00007d5be8fdad51  pop rax
00007d5be8fdad52  add rsp, 0x08
00007d5be8fdad56  jmp 0x00007D5BE8FD6549
00007d5be8fdad5b  sub rsp, 0x08
00007d5be8fdad5f  push rax
00007d5be8fdad60  push rcx
00007d5be8fdad61  push rdx
00007d5be8fdad62  push rdi
00007d5be8fdad63  push rsi
00007d5be8fdad64  push r8
00007d5be8fdad66  push r9
00007d5be8fdad68  push r10
00007d5be8fdad6a  push r11
00007d5be8fdad6c  sub rsp, 0xF0
00007d5be8fdad73  vmovaps [rsp], xmm0
00007d5be8fdad78  vmovaps [rsp+0x10], xmm1
00007d5be8fdad7e  vmovaps [rsp+0x20], xmm2
00007d5be8fdad84  vmovaps [rsp+0x30], xmm3
00007d5be8fdad8a  vmovaps [rsp+0x40], xmm4
00007d5be8fdad90  vmovaps [rsp+0x50], xmm5
00007d5be8fdad96  vmovaps [rsp+0x60], xmm6
00007d5be8fdad9c  vmovaps [rsp+0x70], xmm7
00007d5be8fdada2  vmovaps [rsp+0x80], xmm8
00007d5be8fdadab  vmovaps [rsp+0x90], xmm9
00007d5be8fdadb4  vmovaps [rsp+0xA0], xmm10
00007d5be8fdadbd  vmovaps [rsp+0xB0], xmm11
00007d5be8fdadc6  vmovaps [rsp+0xC0], xmm12
00007d5be8fdadcf  vmovaps [rsp+0xD0], xmm13
00007d5be8fdadd8  vmovaps [rsp+0xE0], xmm15
00007d5be8fdade1  sub rsp, 0x30
00007d5be8fdade5  movaps [rsp], xmm14
00007d5be8fdadea  movaps [rsp+0x10], xmm9
00007d5be8fdadf0  movaps [rsp+0x20], xmm1
00007d5be8fdadf5  lea rdi, [rsp]
00007d5be8fdadf9  mov esi, 0x00
00007d5be8fdadfe  mov rax, 0x5D345705A530
00007d5be8fdae08  call rax
00007d5be8fdae0a  movaps xmm14, [rsp]
00007d5be8fdae0f  add rsp, 0x30
00007d5be8fdae13  vmovaps xmm0, [rsp]
00007d5be8fdae18  vmovaps xmm1, [rsp+0x10]
00007d5be8fdae1e  vmovaps xmm2, [rsp+0x20]
00007d5be8fdae24  vmovaps xmm3, [rsp+0x30]
00007d5be8fdae2a  vmovaps xmm4, [rsp+0x40]
00007d5be8fdae30  vmovaps xmm5, [rsp+0x50]
00007d5be8fdae36  vmovaps xmm6, [rsp+0x60]
00007d5be8fdae3c  vmovaps xmm7, [rsp+0x70]
00007d5be8fdae42  vmovaps xmm8, [rsp+0x80]
00007d5be8fdae4b  vmovaps xmm9, [rsp+0x90]
00007d5be8fdae54  vmovaps xmm10, [rsp+0xA0]
00007d5be8fdae5d  vmovaps xmm11, [rsp+0xB0]
00007d5be8fdae66  vmovaps xmm12, [rsp+0xC0]
00007d5be8fdae6f  vmovaps xmm13, [rsp+0xD0]
00007d5be8fdae78  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdae81  add rsp, 0xF0
00007d5be8fdae88  pop r11
00007d5be8fdae8a  pop r10
00007d5be8fdae8c  pop r9
00007d5be8fdae8e  pop r8
00007d5be8fdae90  pop rsi
00007d5be8fdae91  pop rdi
00007d5be8fdae92  pop rdx
00007d5be8fdae93  pop rcx
00007d5be8fdae94  pop rax
00007d5be8fdae95  add rsp, 0x08
00007d5be8fdae99  jmp 0x00007D5BE8FD6578
00007d5be8fdae9e  sub rsp, 0x08
00007d5be8fdaea2  push rax
00007d5be8fdaea3  push rcx
00007d5be8fdaea4  push rdx
00007d5be8fdaea5  push rdi
00007d5be8fdaea6  push rsi
00007d5be8fdaea7  push r8
00007d5be8fdaea9  push r9
00007d5be8fdaeab  push r10
00007d5be8fdaead  push r11
00007d5be8fdaeaf  sub rsp, 0xF0
00007d5be8fdaeb6  vmovaps [rsp], xmm0
00007d5be8fdaebb  vmovaps [rsp+0x10], xmm2
00007d5be8fdaec1  vmovaps [rsp+0x20], xmm3
00007d5be8fdaec7  vmovaps [rsp+0x30], xmm4
00007d5be8fdaecd  vmovaps [rsp+0x40], xmm5
00007d5be8fdaed3  vmovaps [rsp+0x50], xmm6
00007d5be8fdaed9  vmovaps [rsp+0x60], xmm7
00007d5be8fdaedf  vmovaps [rsp+0x70], xmm8
00007d5be8fdaee5  vmovaps [rsp+0x80], xmm9
00007d5be8fdaeee  vmovaps [rsp+0x90], xmm10
00007d5be8fdaef7  vmovaps [rsp+0xA0], xmm11
00007d5be8fdaf00  vmovaps [rsp+0xB0], xmm12
00007d5be8fdaf09  vmovaps [rsp+0xC0], xmm13
00007d5be8fdaf12  vmovaps [rsp+0xD0], xmm14
00007d5be8fdaf1b  vmovaps [rsp+0xE0], xmm15
00007d5be8fdaf24  sub rsp, 0x30
00007d5be8fdaf28  movaps [rsp], xmm1
00007d5be8fdaf2c  movaps [rsp+0x10], xmm13
00007d5be8fdaf32  movaps [rsp+0x20], xmm8
00007d5be8fdaf38  lea rdi, [rsp]
00007d5be8fdaf3c  mov esi, 0x00
00007d5be8fdaf41  mov rax, 0x5D345705A530
00007d5be8fdaf4b  call rax
00007d5be8fdaf4d  movaps xmm1, [rsp]
00007d5be8fdaf51  add rsp, 0x30
00007d5be8fdaf55  vmovaps xmm0, [rsp]
00007d5be8fdaf5a  vmovaps xmm2, [rsp+0x10]
00007d5be8fdaf60  vmovaps xmm3, [rsp+0x20]
00007d5be8fdaf66  vmovaps xmm4, [rsp+0x30]
00007d5be8fdaf6c  vmovaps xmm5, [rsp+0x40]
00007d5be8fdaf72  vmovaps xmm6, [rsp+0x50]
00007d5be8fdaf78  vmovaps xmm7, [rsp+0x60]
00007d5be8fdaf7e  vmovaps xmm8, [rsp+0x70]
00007d5be8fdaf84  vmovaps xmm9, [rsp+0x80]
00007d5be8fdaf8d  vmovaps xmm10, [rsp+0x90]
00007d5be8fdaf96  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdaf9f  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdafa8  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdafb1  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdafba  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdafc3  add rsp, 0xF0
00007d5be8fdafca  pop r11
00007d5be8fdafcc  pop r10
00007d5be8fdafce  pop r9
00007d5be8fdafd0  pop r8
00007d5be8fdafd2  pop rsi
00007d5be8fdafd3  pop rdi
00007d5be8fdafd4  pop rdx
00007d5be8fdafd5  pop rcx
00007d5be8fdafd6  pop rax
00007d5be8fdafd7  add rsp, 0x08
00007d5be8fdafdb  jmp 0x00007D5BE8FD659A
00007d5be8fdafe0  call 0x00007D5BE8E0C260
00007d5be8fdafe5  jmp 0x00007D5BE8FD65A8
00007d5be8fdafea  call 0x00007D5BE8EDE950
00007d5be8fdafef  jmp 0x00007D5BE8FD65B2
00007d5be8fdaff4  sub rsp, 0x08
00007d5be8fdaff8  push rax
00007d5be8fdaff9  push rcx
00007d5be8fdaffa  push rdx
00007d5be8fdaffb  push rdi
00007d5be8fdaffc  push rsi
00007d5be8fdaffd  push r8
00007d5be8fdafff  push r9
00007d5be8fdb001  push r10
00007d5be8fdb003  push r11
00007d5be8fdb005  sub rsp, 0xF0
00007d5be8fdb00c  vmovaps [rsp], xmm0
00007d5be8fdb011  vmovaps [rsp+0x10], xmm1
00007d5be8fdb017  vmovaps [rsp+0x20], xmm2
00007d5be8fdb01d  vmovaps [rsp+0x30], xmm3
00007d5be8fdb023  vmovaps [rsp+0x40], xmm4
00007d5be8fdb029  vmovaps [rsp+0x50], xmm5
00007d5be8fdb02f  vmovaps [rsp+0x60], xmm6
00007d5be8fdb035  vmovaps [rsp+0x70], xmm7
00007d5be8fdb03b  vmovaps [rsp+0x80], xmm9
00007d5be8fdb044  vmovaps [rsp+0x90], xmm10
00007d5be8fdb04d  vmovaps [rsp+0xA0], xmm11
00007d5be8fdb056  vmovaps [rsp+0xB0], xmm12
00007d5be8fdb05f  vmovaps [rsp+0xC0], xmm13
00007d5be8fdb068  vmovaps [rsp+0xD0], xmm14
00007d5be8fdb071  vmovaps [rsp+0xE0], xmm15
00007d5be8fdb07a  sub rsp, 0x30
00007d5be8fdb07e  movaps [rsp], xmm8
00007d5be8fdb083  movaps [rsp+0x10], xmm15
00007d5be8fdb089  movaps [rsp+0x20], xmm7
00007d5be8fdb08e  lea rdi, [rsp]
00007d5be8fdb092  mov esi, 0x00
00007d5be8fdb097  mov rax, 0x5D345705A530
00007d5be8fdb0a1  call rax
00007d5be8fdb0a3  movaps xmm8, [rsp]
00007d5be8fdb0a8  add rsp, 0x30
00007d5be8fdb0ac  vmovaps xmm0, [rsp]
00007d5be8fdb0b1  vmovaps xmm1, [rsp+0x10]
00007d5be8fdb0b7  vmovaps xmm2, [rsp+0x20]
00007d5be8fdb0bd  vmovaps xmm3, [rsp+0x30]
00007d5be8fdb0c3  vmovaps xmm4, [rsp+0x40]
00007d5be8fdb0c9  vmovaps xmm5, [rsp+0x50]
00007d5be8fdb0cf  vmovaps xmm6, [rsp+0x60]
00007d5be8fdb0d5  vmovaps xmm7, [rsp+0x70]
00007d5be8fdb0db  vmovaps xmm9, [rsp+0x80]
00007d5be8fdb0e4  vmovaps xmm10, [rsp+0x90]
00007d5be8fdb0ed  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdb0f6  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdb0ff  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdb108  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdb111  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdb11a  add rsp, 0xF0
00007d5be8fdb121  pop r11
00007d5be8fdb123  pop r10
00007d5be8fdb125  pop r9
00007d5be8fdb127  pop r8
00007d5be8fdb129  pop rsi
00007d5be8fdb12a  pop rdi
00007d5be8fdb12b  pop rdx
00007d5be8fdb12c  pop rcx
00007d5be8fdb12d  pop rax
00007d5be8fdb12e  add rsp, 0x08
00007d5be8fdb132  jmp 0x00007D5BE8FD65D4
00007d5be8fdb137  sub rsp, 0x08
00007d5be8fdb13b  push rax
00007d5be8fdb13c  push rcx
00007d5be8fdb13d  push rdx
00007d5be8fdb13e  push rdi
00007d5be8fdb13f  push rsi
00007d5be8fdb140  push r8
00007d5be8fdb142  push r9
00007d5be8fdb144  push r10
00007d5be8fdb146  push r11
00007d5be8fdb148  sub rsp, 0xF0
00007d5be8fdb14f  vmovaps [rsp], xmm0
00007d5be8fdb154  vmovaps [rsp+0x10], xmm1
00007d5be8fdb15a  vmovaps [rsp+0x20], xmm2
00007d5be8fdb160  vmovaps [rsp+0x30], xmm3
00007d5be8fdb166  vmovaps [rsp+0x40], xmm4
00007d5be8fdb16c  vmovaps [rsp+0x50], xmm5
00007d5be8fdb172  vmovaps [rsp+0x60], xmm6
00007d5be8fdb178  vmovaps [rsp+0x70], xmm8
00007d5be8fdb17e  vmovaps [rsp+0x80], xmm9
00007d5be8fdb187  vmovaps [rsp+0x90], xmm10
00007d5be8fdb190  vmovaps [rsp+0xA0], xmm11
00007d5be8fdb199  vmovaps [rsp+0xB0], xmm12
00007d5be8fdb1a2  vmovaps [rsp+0xC0], xmm13
00007d5be8fdb1ab  vmovaps [rsp+0xD0], xmm14
00007d5be8fdb1b4  vmovaps [rsp+0xE0], xmm15
00007d5be8fdb1bd  sub rsp, 0x30
00007d5be8fdb1c1  movaps [rsp], xmm7
00007d5be8fdb1c5  movaps [rsp+0x10], xmm9
00007d5be8fdb1cb  movaps [rsp+0x20], xmm15
00007d5be8fdb1d1  lea rdi, [rsp]
00007d5be8fdb1d5  mov esi, 0x00
00007d5be8fdb1da  mov rax, 0x5D345705A530
00007d5be8fdb1e4  call rax
00007d5be8fdb1e6  movaps xmm7, [rsp]
00007d5be8fdb1ea  add rsp, 0x30
00007d5be8fdb1ee  vmovaps xmm0, [rsp]
00007d5be8fdb1f3  vmovaps xmm1, [rsp+0x10]
00007d5be8fdb1f9  vmovaps xmm2, [rsp+0x20]
00007d5be8fdb1ff  vmovaps xmm3, [rsp+0x30]
00007d5be8fdb205  vmovaps xmm4, [rsp+0x40]
00007d5be8fdb20b  vmovaps xmm5, [rsp+0x50]
00007d5be8fdb211  vmovaps xmm6, [rsp+0x60]
00007d5be8fdb217  vmovaps xmm8, [rsp+0x70]
00007d5be8fdb21d  vmovaps xmm9, [rsp+0x80]
00007d5be8fdb226  vmovaps xmm10, [rsp+0x90]
00007d5be8fdb22f  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdb238  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdb241  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdb24a  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdb253  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdb25c  add rsp, 0xF0
00007d5be8fdb263  pop r11
00007d5be8fdb265  pop r10
00007d5be8fdb267  pop r9
00007d5be8fdb269  pop r8
00007d5be8fdb26b  pop rsi
00007d5be8fdb26c  pop rdi
00007d5be8fdb26d  pop rdx
00007d5be8fdb26e  pop rcx
00007d5be8fdb26f  pop rax
00007d5be8fdb270  add rsp, 0x08
00007d5be8fdb274  jmp 0x00007D5BE8FD6601
00007d5be8fdb279  sub rsp, 0x08
00007d5be8fdb27d  push rax
00007d5be8fdb27e  push rcx
00007d5be8fdb27f  push rdx
00007d5be8fdb280  push rdi
00007d5be8fdb281  push rsi
00007d5be8fdb282  push r8
00007d5be8fdb284  push r9
00007d5be8fdb286  push r10
00007d5be8fdb288  push r11
00007d5be8fdb28a  sub rsp, 0xF0
00007d5be8fdb291  vmovaps [rsp], xmm0
00007d5be8fdb296  vmovaps [rsp+0x10], xmm1
00007d5be8fdb29c  vmovaps [rsp+0x20], xmm2
00007d5be8fdb2a2  vmovaps [rsp+0x30], xmm3
00007d5be8fdb2a8  vmovaps [rsp+0x40], xmm4
00007d5be8fdb2ae  vmovaps [rsp+0x50], xmm5
00007d5be8fdb2b4  vmovaps [rsp+0x60], xmm6
00007d5be8fdb2ba  vmovaps [rsp+0x70], xmm7
00007d5be8fdb2c0  vmovaps [rsp+0x80], xmm8
00007d5be8fdb2c9  vmovaps [rsp+0x90], xmm10
00007d5be8fdb2d2  vmovaps [rsp+0xA0], xmm11
00007d5be8fdb2db  vmovaps [rsp+0xB0], xmm12
00007d5be8fdb2e4  vmovaps [rsp+0xC0], xmm13
00007d5be8fdb2ed  vmovaps [rsp+0xD0], xmm14
00007d5be8fdb2f6  vmovaps [rsp+0xE0], xmm15
00007d5be8fdb2ff  sub rsp, 0x30
00007d5be8fdb303  movaps [rsp], xmm9
00007d5be8fdb308  movaps [rsp+0x10], xmm13
00007d5be8fdb30e  movaps [rsp+0x20], xmm15
00007d5be8fdb314  lea rdi, [rsp]
00007d5be8fdb318  mov esi, 0x00
00007d5be8fdb31d  mov rax, 0x5D345705A530
00007d5be8fdb327  call rax
00007d5be8fdb329  movaps xmm9, [rsp]
00007d5be8fdb32e  add rsp, 0x30
00007d5be8fdb332  vmovaps xmm0, [rsp]
00007d5be8fdb337  vmovaps xmm1, [rsp+0x10]
00007d5be8fdb33d  vmovaps xmm2, [rsp+0x20]
00007d5be8fdb343  vmovaps xmm3, [rsp+0x30]
00007d5be8fdb349  vmovaps xmm4, [rsp+0x40]
00007d5be8fdb34f  vmovaps xmm5, [rsp+0x50]
00007d5be8fdb355  vmovaps xmm6, [rsp+0x60]
00007d5be8fdb35b  vmovaps xmm7, [rsp+0x70]
00007d5be8fdb361  vmovaps xmm8, [rsp+0x80]
00007d5be8fdb36a  vmovaps xmm10, [rsp+0x90]
00007d5be8fdb373  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdb37c  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdb385  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdb38e  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdb397  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdb3a0  add rsp, 0xF0
00007d5be8fdb3a7  pop r11
00007d5be8fdb3a9  pop r10
00007d5be8fdb3ab  pop r9
00007d5be8fdb3ad  pop r8
00007d5be8fdb3af  pop rsi
00007d5be8fdb3b0  pop rdi
00007d5be8fdb3b1  pop rdx
00007d5be8fdb3b2  pop rcx
00007d5be8fdb3b3  pop rax
00007d5be8fdb3b4  add rsp, 0x08
00007d5be8fdb3b8  jmp 0x00007D5BE8FD662F
00007d5be8fdb3bd  sub rsp, 0x08
00007d5be8fdb3c1  push rax
00007d5be8fdb3c2  push rcx
00007d5be8fdb3c3  push rdx
00007d5be8fdb3c4  push rdi
00007d5be8fdb3c5  push rsi
00007d5be8fdb3c6  push r8
00007d5be8fdb3c8  push r9
00007d5be8fdb3ca  push r10
00007d5be8fdb3cc  push r11
00007d5be8fdb3ce  sub rsp, 0xF0
00007d5be8fdb3d5  vmovaps [rsp], xmm0
00007d5be8fdb3da  vmovaps [rsp+0x10], xmm1
00007d5be8fdb3e0  vmovaps [rsp+0x20], xmm2
00007d5be8fdb3e6  vmovaps [rsp+0x30], xmm3
00007d5be8fdb3ec  vmovaps [rsp+0x40], xmm4
00007d5be8fdb3f2  vmovaps [rsp+0x50], xmm5
00007d5be8fdb3f8  vmovaps [rsp+0x60], xmm6
00007d5be8fdb3fe  vmovaps [rsp+0x70], xmm7
00007d5be8fdb404  vmovaps [rsp+0x80], xmm8
00007d5be8fdb40d  vmovaps [rsp+0x90], xmm9
00007d5be8fdb416  vmovaps [rsp+0xA0], xmm10
00007d5be8fdb41f  vmovaps [rsp+0xB0], xmm11
00007d5be8fdb428  vmovaps [rsp+0xC0], xmm12
00007d5be8fdb431  vmovaps [rsp+0xD0], xmm13
00007d5be8fdb43a  vmovaps [rsp+0xE0], xmm14
00007d5be8fdb443  sub rsp, 0x30
00007d5be8fdb447  movaps [rsp], xmm15
00007d5be8fdb44c  movaps [rsp+0x10], xmm11
00007d5be8fdb452  movaps [rsp+0x20], xmm12
00007d5be8fdb458  lea rdi, [rsp]
00007d5be8fdb45c  mov esi, 0x00
00007d5be8fdb461  mov rax, 0x5D345705A530
00007d5be8fdb46b  call rax
00007d5be8fdb46d  movaps xmm15, [rsp]
00007d5be8fdb472  add rsp, 0x30
00007d5be8fdb476  vmovaps xmm0, [rsp]
00007d5be8fdb47b  vmovaps xmm1, [rsp+0x10]
00007d5be8fdb481  vmovaps xmm2, [rsp+0x20]
00007d5be8fdb487  vmovaps xmm3, [rsp+0x30]
00007d5be8fdb48d  vmovaps xmm4, [rsp+0x40]
00007d5be8fdb493  vmovaps xmm5, [rsp+0x50]
00007d5be8fdb499  vmovaps xmm6, [rsp+0x60]
00007d5be8fdb49f  vmovaps xmm7, [rsp+0x70]
00007d5be8fdb4a5  vmovaps xmm8, [rsp+0x80]
00007d5be8fdb4ae  vmovaps xmm9, [rsp+0x90]
00007d5be8fdb4b7  vmovaps xmm10, [rsp+0xA0]
00007d5be8fdb4c0  vmovaps xmm11, [rsp+0xB0]
00007d5be8fdb4c9  vmovaps xmm12, [rsp+0xC0]
00007d5be8fdb4d2  vmovaps xmm13, [rsp+0xD0]
00007d5be8fdb4db  vmovaps xmm14, [rsp+0xE0]
00007d5be8fdb4e4  add rsp, 0xF0
00007d5be8fdb4eb  pop r11
00007d5be8fdb4ed  pop r10
00007d5be8fdb4ef  pop r9
00007d5be8fdb4f1  pop r8
00007d5be8fdb4f3  pop rsi
00007d5be8fdb4f4  pop rdi
00007d5be8fdb4f5  pop rdx
00007d5be8fdb4f6  pop rcx
00007d5be8fdb4f7  pop rax
00007d5be8fdb4f8  add rsp, 0x08
00007d5be8fdb4fc  jmp 0x00007D5BE8FD664A
00007d5be8fdb501  sub rsp, 0x08
00007d5be8fdb505  push rax
00007d5be8fdb506  push rcx
00007d5be8fdb507  push rdx
00007d5be8fdb508  push rdi
00007d5be8fdb509  push rsi
00007d5be8fdb50a  push r8
00007d5be8fdb50c  push r9
00007d5be8fdb50e  push r10
00007d5be8fdb510  push r11
00007d5be8fdb512  sub rsp, 0xF0
00007d5be8fdb519  vmovaps [rsp], xmm0
00007d5be8fdb51e  vmovaps [rsp+0x10], xmm1
00007d5be8fdb524  vmovaps [rsp+0x20], xmm2
00007d5be8fdb52a  vmovaps [rsp+0x30], xmm3
00007d5be8fdb530  vmovaps [rsp+0x40], xmm4
00007d5be8fdb536  vmovaps [rsp+0x50], xmm5
00007d5be8fdb53c  vmovaps [rsp+0x60], xmm6
00007d5be8fdb542  vmovaps [rsp+0x70], xmm7
00007d5be8fdb548  vmovaps [rsp+0x80], xmm8
00007d5be8fdb551  vmovaps [rsp+0x90], xmm9
00007d5be8fdb55a  vmovaps [rsp+0xA0], xmm10
00007d5be8fdb563  vmovaps [rsp+0xB0], xmm11
00007d5be8fdb56c  vmovaps [rsp+0xC0], xmm12
00007d5be8fdb575  vmovaps [rsp+0xD0], xmm14
00007d5be8fdb57e  vmovaps [rsp+0xE0], xmm15
00007d5be8fdb587  sub rsp, 0x30
00007d5be8fdb58b  movaps [rsp], xmm13
00007d5be8fdb590  movaps [rsp+0x10], xmm10
00007d5be8fdb596  movaps [rsp+0x20], xmm14
00007d5be8fdb59c  lea rdi, [rsp]
00007d5be8fdb5a0  mov esi, 0x00
00007d5be8fdb5a5  mov rax, 0x5D345705A530
00007d5be8fdb5af  call rax
00007d5be8fdb5b1  movaps xmm13, [rsp]
00007d5be8fdb5b6  add rsp, 0x30
00007d5be8fdb5ba  vmovaps xmm0, [rsp]
00007d5be8fdb5bf  vmovaps xmm1, [rsp+0x10]
00007d5be8fdb5c5  vmovaps xmm2, [rsp+0x20]
00007d5be8fdb5cb  vmovaps xmm3, [rsp+0x30]
00007d5be8fdb5d1  vmovaps xmm4, [rsp+0x40]
00007d5be8fdb5d7  vmovaps xmm5, [rsp+0x50]
00007d5be8fdb5dd  vmovaps xmm6, [rsp+0x60]
00007d5be8fdb5e3  vmovaps xmm7, [rsp+0x70]
00007d5be8fdb5e9  vmovaps xmm8, [rsp+0x80]
00007d5be8fdb5f2  vmovaps xmm9, [rsp+0x90]
00007d5be8fdb5fb  vmovaps xmm10, [rsp+0xA0]
00007d5be8fdb604  vmovaps xmm11, [rsp+0xB0]
00007d5be8fdb60d  vmovaps xmm12, [rsp+0xC0]
00007d5be8fdb616  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdb61f  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdb628  add rsp, 0xF0
00007d5be8fdb62f  pop r11
00007d5be8fdb631  pop r10
00007d5be8fdb633  pop r9
00007d5be8fdb635  pop r8
00007d5be8fdb637  pop rsi
00007d5be8fdb638  pop rdi
00007d5be8fdb639  pop rdx
00007d5be8fdb63a  pop rcx
00007d5be8fdb63b  pop rax
00007d5be8fdb63c  add rsp, 0x08
00007d5be8fdb640  jmp 0x00007D5BE8FD666D
00007d5be8fdb645  sub rsp, 0x08
00007d5be8fdb649  push rax
00007d5be8fdb64a  push rcx
00007d5be8fdb64b  push rdx
00007d5be8fdb64c  push rdi
00007d5be8fdb64d  push rsi
00007d5be8fdb64e  push r8
00007d5be8fdb650  push r9
00007d5be8fdb652  push r10
00007d5be8fdb654  push r11
00007d5be8fdb656  sub rsp, 0xF0
00007d5be8fdb65d  vmovaps [rsp], xmm0
00007d5be8fdb662  vmovaps [rsp+0x10], xmm1
00007d5be8fdb668  vmovaps [rsp+0x20], xmm2
00007d5be8fdb66e  vmovaps [rsp+0x30], xmm3
00007d5be8fdb674  vmovaps [rsp+0x40], xmm4
00007d5be8fdb67a  vmovaps [rsp+0x50], xmm5
00007d5be8fdb680  vmovaps [rsp+0x60], xmm6
00007d5be8fdb686  vmovaps [rsp+0x70], xmm7
00007d5be8fdb68c  vmovaps [rsp+0x80], xmm8
00007d5be8fdb695  vmovaps [rsp+0x90], xmm9
00007d5be8fdb69e  vmovaps [rsp+0xA0], xmm10
00007d5be8fdb6a7  vmovaps [rsp+0xB0], xmm11
00007d5be8fdb6b0  vmovaps [rsp+0xC0], xmm12
00007d5be8fdb6b9  vmovaps [rsp+0xD0], xmm13
00007d5be8fdb6c2  vmovaps [rsp+0xE0], xmm15
00007d5be8fdb6cb  sub rsp, 0x30
00007d5be8fdb6cf  movaps [rsp], xmm14
00007d5be8fdb6d4  movaps [rsp+0x10], xmm1
00007d5be8fdb6d9  movaps [rsp+0x20], xmm7
00007d5be8fdb6de  lea rdi, [rsp]
00007d5be8fdb6e2  mov esi, 0x00
00007d5be8fdb6e7  mov rax, 0x5D345705A530
00007d5be8fdb6f1  call rax
00007d5be8fdb6f3  movaps xmm14, [rsp]
00007d5be8fdb6f8  add rsp, 0x30
00007d5be8fdb6fc  vmovaps xmm0, [rsp]
00007d5be8fdb701  vmovaps xmm1, [rsp+0x10]
00007d5be8fdb707  vmovaps xmm2, [rsp+0x20]
00007d5be8fdb70d  vmovaps xmm3, [rsp+0x30]
00007d5be8fdb713  vmovaps xmm4, [rsp+0x40]
00007d5be8fdb719  vmovaps xmm5, [rsp+0x50]
00007d5be8fdb71f  vmovaps xmm6, [rsp+0x60]
00007d5be8fdb725  vmovaps xmm7, [rsp+0x70]
00007d5be8fdb72b  vmovaps xmm8, [rsp+0x80]
00007d5be8fdb734  vmovaps xmm9, [rsp+0x90]
00007d5be8fdb73d  vmovaps xmm10, [rsp+0xA0]
00007d5be8fdb746  vmovaps xmm11, [rsp+0xB0]
00007d5be8fdb74f  vmovaps xmm12, [rsp+0xC0]
00007d5be8fdb758  vmovaps xmm13, [rsp+0xD0]
00007d5be8fdb761  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdb76a  add rsp, 0xF0
00007d5be8fdb771  pop r11
00007d5be8fdb773  pop r10
00007d5be8fdb775  pop r9
00007d5be8fdb777  pop r8
00007d5be8fdb779  pop rsi
00007d5be8fdb77a  pop rdi
00007d5be8fdb77b  pop rdx
00007d5be8fdb77c  pop rcx
00007d5be8fdb77d  pop rax
00007d5be8fdb77e  add rsp, 0x08
00007d5be8fdb782  jmp 0x00007D5BE8FD6690
00007d5be8fdb787  sub rsp, 0x08
00007d5be8fdb78b  push rax
00007d5be8fdb78c  push rcx
00007d5be8fdb78d  push rdx
00007d5be8fdb78e  push rdi
00007d5be8fdb78f  push rsi
00007d5be8fdb790  push r8
00007d5be8fdb792  push r9
00007d5be8fdb794  push r10
00007d5be8fdb796  push r11
00007d5be8fdb798  sub rsp, 0xF0
00007d5be8fdb79f  vmovaps [rsp], xmm0
00007d5be8fdb7a4  vmovaps [rsp+0x10], xmm2
00007d5be8fdb7aa  vmovaps [rsp+0x20], xmm3
00007d5be8fdb7b0  vmovaps [rsp+0x30], xmm4
00007d5be8fdb7b6  vmovaps [rsp+0x40], xmm5
00007d5be8fdb7bc  vmovaps [rsp+0x50], xmm6
00007d5be8fdb7c2  vmovaps [rsp+0x60], xmm7
00007d5be8fdb7c8  vmovaps [rsp+0x70], xmm8
00007d5be8fdb7ce  vmovaps [rsp+0x80], xmm9
00007d5be8fdb7d7  vmovaps [rsp+0x90], xmm10
00007d5be8fdb7e0  vmovaps [rsp+0xA0], xmm11
00007d5be8fdb7e9  vmovaps [rsp+0xB0], xmm12
00007d5be8fdb7f2  vmovaps [rsp+0xC0], xmm13
00007d5be8fdb7fb  vmovaps [rsp+0xD0], xmm14
00007d5be8fdb804  vmovaps [rsp+0xE0], xmm15
00007d5be8fdb80d  sub rsp, 0x30
00007d5be8fdb811  movaps [rsp], xmm1
00007d5be8fdb815  movaps [rsp+0x10], xmm8
00007d5be8fdb81b  movaps [rsp+0x20], xmm9
00007d5be8fdb821  lea rdi, [rsp]
00007d5be8fdb825  mov esi, 0x00
00007d5be8fdb82a  mov rax, 0x5D345705A530
00007d5be8fdb834  call rax
00007d5be8fdb836  movaps xmm1, [rsp]
00007d5be8fdb83a  add rsp, 0x30
00007d5be8fdb83e  vmovaps xmm0, [rsp]
00007d5be8fdb843  vmovaps xmm2, [rsp+0x10]
00007d5be8fdb849  vmovaps xmm3, [rsp+0x20]
00007d5be8fdb84f  vmovaps xmm4, [rsp+0x30]
00007d5be8fdb855  vmovaps xmm5, [rsp+0x40]
00007d5be8fdb85b  vmovaps xmm6, [rsp+0x50]
00007d5be8fdb861  vmovaps xmm7, [rsp+0x60]
00007d5be8fdb867  vmovaps xmm8, [rsp+0x70]
00007d5be8fdb86d  vmovaps xmm9, [rsp+0x80]
00007d5be8fdb876  vmovaps xmm10, [rsp+0x90]
00007d5be8fdb87f  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdb888  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdb891  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdb89a  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdb8a3  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdb8ac  add rsp, 0xF0
00007d5be8fdb8b3  pop r11
00007d5be8fdb8b5  pop r10
00007d5be8fdb8b7  pop r9
00007d5be8fdb8b9  pop r8
00007d5be8fdb8bb  pop rsi
00007d5be8fdb8bc  pop rdi
00007d5be8fdb8bd  pop rdx
00007d5be8fdb8be  pop rcx
00007d5be8fdb8bf  pop rax
00007d5be8fdb8c0  add rsp, 0x08
00007d5be8fdb8c4  jmp 0x00007D5BE8FD66B2
00007d5be8fdb8c9  call 0x00007D5BE8EB3E40
00007d5be8fdb8ce  jmp 0x00007D5BE8FD66C0
00007d5be8fdb8d3  call 0x00007D5BE8E0C380
00007d5be8fdb8d8  jmp 0x00007D5BE8FD66CA
00007d5be8fdb8dd  call 0x00007D5BE8E0D600
00007d5be8fdb8e2  jmp 0x00007D5BE8FD66D4
00007d5be8fdb8e7  call 0x00007D5BE8DFF540
00007d5be8fdb8ec  jmp 0x00007D5BE8FD66DE
00007d5be8fdb8f1  int3
00007d5be8fdb8f2  nop [rax+rax*1], ax
00007d5be8fdb8fb  nop [rax+rax*1], eax
00007d5be8fdb900  mov eax, [r15+0x48]
00007d5be8fdb904  lea r14d, [eax+0x01]
00007d5be8fdb909  mov [rsp+0x10], r14d
00007d5be8fdb90e  mov r14d, r14d
00007d5be8fdb911  mov [r15+0x48], r14
00007d5be8fdb915  xor eax, eax
00007d5be8fdb917  mov r14d, [rsp+0x10]
00007d5be8fdb91c  cmp r14d, 0x1F4
00007d5be8fdb923  cmc
00007d5be8fdb924  lahf
00007d5be8fdb925  seto al
00007d5be8fdb928  mov [r15+0x108], eax
00007d5be8fdb92f  mov eax, [r15+0x108]
00007d5be8fdb936  sahf
00007d5be8fdb937  jnz 0x00007D5BE8FDB969
00007d5be8fdb939  cmp dword ptr [r15+0x318], 0x00
00007d5be8fdb941  jz 0x00007D5BE8FE1AB0
00007d5be8fdb947  nop [rax+rax*1], ax
00007d5be8fdb950  nop [rax+rax*1], eax
00007d5be8fdb958  mov eax, 0x410450
00007d5be8fdb95d  mov [r15+0x100], rax
00007d5be8fdb964  jmp 0x00007D5BE8DFE110
00007d5be8fdb969  cmp dword ptr [r15+0x318], 0x00
00007d5be8fdb971  jz 0x00007D5BE8FDB9A0
00007d5be8fdb977  nop [rax+rax*1], ax
00007d5be8fdb980  nop [rax+rax*1], eax
00007d5be8fdb988  mov eax, 0x410274
00007d5be8fdb98d  mov [r15+0x100], rax
00007d5be8fdb994  jmp 0x00007D5BE8DFE110
00007d5be8fdb999  int3
00007d5be8fdb99a  int3
00007d5be8fdb99b  nop [rax+rax*1], eax
00007d5be8fdb9a0  mov rax, [r15+0x40]
00007d5be8fdb9a4  movaps xmm1, [r15+0x1D0]
00007d5be8fdb9ac  vmovaps [rsp+0x10], xmm1
00007d5be8fdb9b2  vmovaps xmm15, [rsp+0x10]
00007d5be8fdb9b8  por xmm1, xmm15
00007d5be8fdb9bd  movaps xmm14, [r15+0x1A0]
00007d5be8fdb9c5  vmovaps [rsp+0x10], xmm14
00007d5be8fdb9cb  vmovaps xmm13, [rsp+0x10]
00007d5be8fdb9d1  por xmm14, xmm13
00007d5be8fdb9d6  lea r14, [rax+0x30]
00007d5be8fdb9da  mov r12, [r13+r14*1]
00007d5be8fdb9df  lea r14, [rax+0x38]
00007d5be8fdb9e3  mov r11, [r13+r14*1]
00007d5be8fdb9e8  movq xmm13, r12
00007d5be8fdb9ed  movq xmm12, r11
00007d5be8fdb9f2  movq xmm13, xmm13
00007d5be8fdb9f7  vmovaps [rsp+0x10], xmm13
00007d5be8fdb9fd  movq xmm13, xmm13
00007d5be8fdba02  movaps [r15+0x130], xmm13
00007d5be8fdba0a  movq xmm12, xmm12
00007d5be8fdba0f  vmovaps [rsp+0x20], xmm12
00007d5be8fdba15  movq xmm12, xmm12
00007d5be8fdba1a  movaps [r15+0x280], xmm12
00007d5be8fdba22  movaps xmm13, [r15+0x270]
00007d5be8fdba2a  vmovaps [rsp+0x30], xmm13
00007d5be8fdba30  vmovaps xmm12, [rsp+0x30]
00007d5be8fdba36  por xmm13, xmm12
00007d5be8fdba3b  lea r14, [rax+0x20]
00007d5be8fdba3f  mov r12, [r13+r14*1]
00007d5be8fdba44  lea r14, [rax+0x28]
00007d5be8fdba48  mov r11, [r13+r14*1]
00007d5be8fdba4d  movq xmm12, r12
00007d5be8fdba52  movq xmm11, r11
00007d5be8fdba57  movq xmm12, xmm12
00007d5be8fdba5c  vmovaps [rsp+0x30], xmm12
00007d5be8fdba62  movq xmm12, xmm12
00007d5be8fdba67  movaps [r15+0x150], xmm12
00007d5be8fdba6f  movq xmm11, xmm11
00007d5be8fdba74  vmovaps [rsp+0x40], xmm11
00007d5be8fdba7a  movq xmm11, xmm11
00007d5be8fdba7f  movaps [r15+0x140], xmm11
00007d5be8fdba87  lea r14, [rax+0x10]
00007d5be8fdba8b  mov r12, [r13+r14*1]
00007d5be8fdba90  lea r14, [rax+0x18]
00007d5be8fdba94  mov r11, [r13+r14*1]
00007d5be8fdba99  movq xmm12, r12
00007d5be8fdba9e  movq xmm11, r11
00007d5be8fdbaa3  movq xmm12, xmm12
00007d5be8fdbaa8  vmovaps [rsp+0x50], xmm12
00007d5be8fdbaae  movq xmm12, xmm12
00007d5be8fdbab3  movaps [r15+0x170], xmm12
00007d5be8fdbabb  movq xmm11, xmm11
00007d5be8fdbac0  vmovaps [rsp+0x60], xmm11
00007d5be8fdbac6  movq xmm11, xmm11
00007d5be8fdbacb  movaps [r15+0x160], xmm11
00007d5be8fdbad3  mov r14, [r13+rax*1]
00007d5be8fdbad8  vmovq xmm12, r14
00007d5be8fdbadd  vpbroadcastq xmm12, xmm12
00007d5be8fdbae2  lea r14, [rax+0x08]
00007d5be8fdbae6  mov rax, [r13+r14*1]
00007d5be8fdbaeb  movq xmm11, rax
00007d5be8fdbaf0  movaps [r15+0x230], xmm11
00007d5be8fdbaf8  mov rax, [r15+0xF8]
00007d5be8fdbaff  lea r14, [rax+0x50]
00007d5be8fdbb03  movups xmm11, [r13+r14*1]
00007d5be8fdbb09  lea r14, [rax+0x60]
00007d5be8fdbb0d  movups xmm10, [r13+r14*1]
00007d5be8fdbb13  lea r14, [rax+0x30]
00007d5be8fdbb17  movups xmm9, [r13+r14*1]
00007d5be8fdbb1d  mov r14, [r15+0x50]
00007d5be8fdbb21  mov [r15+0x60], r14
00007d5be8fdbb25  mov qword ptr [r15+0x58], 0x40
00007d5be8fdbb2d  movaps xmm8, xmm12
00007d5be8fdbb31  mulpd xmm8, xmm15
00007d5be8fdbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007d5be8fdbb3c  ptest xmm7, xmm7
00007d5be8fdbb41  jnz 0x00007D5BE8FDC96A
00007d5be8fdbb47  movq xmm15, qword ptr [r15+0x230]
00007d5be8fdbb50  vmovaps [rsp+0x70], xmm15
00007d5be8fdbb56  vpermilpd xmm15, xmm15, 0x00
00007d5be8fdbb5c  movaps xmm7, xmm9
00007d5be8fdbb60  mulpd xmm7, xmm15
00007d5be8fdbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007d5be8fdbb6a  ptest xmm6, xmm6
00007d5be8fdbb6f  jnz 0x00007D5BE8FDCAAE
00007d5be8fdbb75  vxorps xmm15, xmm15, xmm15
00007d5be8fdbb7a  vpbroadcastq xmm15, xmm15
00007d5be8fdbb7f  movaps xmm9, xmm12
00007d5be8fdbb83  mulpd xmm9, xmm10
00007d5be8fdbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007d5be8fdbb8e  ptest xmm6, xmm6
00007d5be8fdbb93  jnz 0x00007D5BE8FDCBF0
00007d5be8fdbb99  movaps xmm10, xmm12
00007d5be8fdbb9d  mulpd xmm10, xmm11
00007d5be8fdbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007d5be8fdbba8  ptest xmm6, xmm6
00007d5be8fdbbad  jnz 0x00007D5BE8FDCD34
00007d5be8fdbbb3  movaps xmm11, [r15+0x1F0]
00007d5be8fdbbbb  movaps xmm6, xmm12
00007d5be8fdbbbf  mulpd xmm6, xmm11
00007d5be8fdbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007d5be8fdbbc9  ptest xmm5, xmm5
00007d5be8fdbbce  jnz 0x00007D5BE8FDCE78
00007d5be8fdbbd4  movaps xmm12, [r15+0x2A0]
00007d5be8fdbbdc  vmovaps [rsp+0x80], xmm12
00007d5be8fdbbe5  vmovaps xmm11, [rsp+0x80]
00007d5be8fdbbee  por xmm12, xmm11
00007d5be8fdbbf3  movaps xmm11, [r15+0x250]
00007d5be8fdbbfb  vmovaps [rsp+0x80], xmm11
00007d5be8fdbc04  vmovaps xmm5, [rsp+0x80]
00007d5be8fdbc0d  por xmm11, xmm5
00007d5be8fdbc12  vmovaps xmm4, [rsp+0x70]
00007d5be8fdbc18  vpermilpd xmm4, xmm4, 0x00
00007d5be8fdbc1e  movaps xmm3, xmm5
00007d5be8fdbc21  mulpd xmm3, xmm4
00007d5be8fdbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007d5be8fdbc2a  ptest xmm2, xmm2
00007d5be8fdbc2f  jnz 0x00007D5BE8FDCFBA
00007d5be8fdbc35  mov [rsp+0x80], rax
00007d5be8fdbc3d  xor eax, eax
00007d5be8fdbc3f  mov r12d, 0x40
00007d5be8fdbc45  mov r11d, 0x200
00007d5be8fdbc4b  cmp r12, r11
00007d5be8fdbc4e  cmc
00007d5be8fdbc4f  lahf
00007d5be8fdbc50  seto al
00007d5be8fdbc53  mov [r15+0x108], eax
00007d5be8fdbc5a  movaps xmm5, xmm8
00007d5be8fdbc5e  addpd xmm5, xmm15
00007d5be8fdbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007d5be8fdbc68  ptest xmm4, xmm4
00007d5be8fdbc6d  jnz 0x00007D5BE8FDD0FA
00007d5be8fdbc73  movaps xmm8, [r15+0x1B0]
00007d5be8fdbc7b  movaps xmm4, xmm9
00007d5be8fdbc7f  addpd xmm4, xmm8
00007d5be8fdbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007d5be8fdbc89  ptest xmm2, xmm2
00007d5be8fdbc8e  jnz 0x00007D5BE8FDD23C
00007d5be8fdbc94  movaps xmm9, xmm10
00007d5be8fdbc98  addpd xmm9, xmm8
00007d5be8fdbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007d5be8fdbca3  ptest xmm2, xmm2
00007d5be8fdbca8  jnz 0x00007D5BE8FDD37E
00007d5be8fdbcae  movaps xmm10, [r15+0x2F0]
00007d5be8fdbcb6  vmovaps [rsp+0x90], xmm10
00007d5be8fdbcbf  vmovaps xmm8, [rsp+0x90]
00007d5be8fdbcc8  por xmm10, xmm8
00007d5be8fdbccd  movaps xmm8, [r15+0x2E0]
00007d5be8fdbcd5  vmovaps [rsp+0x90], xmm8
00007d5be8fdbcde  vmovaps xmm2, [rsp+0x90]
00007d5be8fdbce7  por xmm8, xmm2
00007d5be8fdbcec  movaps xmm2, [r15+0x2D0]
00007d5be8fdbcf4  vmovaps [rsp+0x90], xmm2
00007d5be8fdbcfd  vmovaps [rsp+0xA0], xmm1
00007d5be8fdbd06  vmovaps xmm1, [rsp+0x90]
00007d5be8fdbd0f  por xmm2, xmm1
00007d5be8fdbd13  movaps xmm1, [r15+0x200]
00007d5be8fdbd1b  vmovaps [rsp+0x90], xmm1
00007d5be8fdbd24  vmovaps [rsp+0xB0], xmm15
00007d5be8fdbd2d  vmovaps xmm15, [rsp+0x90]
00007d5be8fdbd36  por xmm1, xmm15
00007d5be8fdbd3b  movaps xmm15, [r15+0x1C0]
00007d5be8fdbd43  vmovaps [rsp+0x90], xmm15
00007d5be8fdbd4c  vmovaps [rsp+0xC0], xmm1
00007d5be8fdbd55  vmovaps xmm1, [rsp+0x90]
00007d5be8fdbd5e  por xmm15, xmm1
00007d5be8fdbd63  movaps xmm1, [r15+0x190]
00007d5be8fdbd6b  vmovaps [rsp+0x90], xmm1
00007d5be8fdbd74  vmovaps [rsp+0xD0], xmm15
00007d5be8fdbd7d  vmovaps xmm15, [rsp+0x90]
00007d5be8fdbd86  por xmm1, xmm15
00007d5be8fdbd8b  movaps xmm15, [r15+0x300]
00007d5be8fdbd93  vmovaps [rsp+0x90], xmm15
00007d5be8fdbd9c  vmovaps [rsp+0xE0], xmm1
00007d5be8fdbda5  vmovaps xmm1, [rsp+0x90]
00007d5be8fdbdae  por xmm15, xmm1
00007d5be8fdbdb3  mov rax, [rsp+0x80]
00007d5be8fdbdbb  lea r12, [rax+0xA0]
00007d5be8fdbdc2  movups xmm1, [r13+r12*1]
00007d5be8fdbdc8  lea r12, [rax+0xB0]
00007d5be8fdbdcf  vmovaps [rsp+0x80], xmm1
00007d5be8fdbdd8  movups xmm1, [r13+r12*1]
00007d5be8fdbdde  vmovaps [rsp+0x90], xmm1
00007d5be8fdbde7  vmovaps [rsp+0xF0], xmm15
00007d5be8fdbdf0  vmovaps xmm15, [rsp+0xB0]
00007d5be8fdbdf9  vmovaps [rsp+0xB0], xmm14
00007d5be8fdbe02  movaps xmm1, xmm6
00007d5be8fdbe05  addpd xmm1, xmm15
00007d5be8fdbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007d5be8fdbe0f  ptest xmm14, xmm14
00007d5be8fdbe15  jnz 0x00007D5BE8FDD4D6
00007d5be8fdbe1b  lea r12, [rax+0xF0]
00007d5be8fdbe22  movups xmm15, [r13+r12*1]
00007d5be8fdbe28  movaps xmm14, xmm4
00007d5be8fdbe2c  addpd xmm14, xmm3
00007d5be8fdbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007d5be8fdbe37  ptest xmm6, xmm6
00007d5be8fdbe3c  jnz 0x00007D5BE8FDD621
00007d5be8fdbe42  movaps xmm6, xmm9
00007d5be8fdbe46  addpd xmm6, xmm7
00007d5be8fdbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007d5be8fdbe4f  ptest xmm4, xmm4
00007d5be8fdbe54  jnz 0x00007D5BE8FDD763
00007d5be8fdbe5a  vmovaps xmm9, [rsp+0x70]
00007d5be8fdbe60  vpermilpd xmm9, xmm9, 0x00
00007d5be8fdbe66  vmovaps xmm4, [rsp+0x90]
00007d5be8fdbe6f  movaps xmm7, xmm4
00007d5be8fdbe72  mulpd xmm7, xmm9
00007d5be8fdbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007d5be8fdbe7c  ptest xmm3, xmm3
00007d5be8fdbe81  jnz 0x00007D5BE8FDD8A4
00007d5be8fdbe87  vmovaps xmm9, [rsp+0x50]
00007d5be8fdbe8d  vpermilpd xmm9, xmm9, 0x00
00007d5be8fdbe93  movaps xmm4, xmm15
00007d5be8fdbe97  mulpd xmm4, xmm9
00007d5be8fdbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007d5be8fdbea1  ptest xmm3, xmm3
00007d5be8fdbea6  jnz 0x00007D5BE8FDD9E5
00007d5be8fdbeac  lea r12, [rax+0xE0]
00007d5be8fdbeb3  movups xmm15, [r13+r12*1]
00007d5be8fdbeb9  vmovaps xmm9, [rsp+0x70]
00007d5be8fdbebf  vpermilpd xmm9, xmm9, 0x00
00007d5be8fdbec5  vmovaps [rsp+0x70], xmm1
00007d5be8fdbecb  vmovaps xmm1, [rsp+0x80]
00007d5be8fdbed4  vmovaps [rsp+0x80], xmm15
00007d5be8fdbedd  movaps xmm3, xmm1
00007d5be8fdbee0  mulpd xmm3, xmm9
00007d5be8fdbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007d5be8fdbeea  ptest xmm15, xmm15
00007d5be8fdbef0  jnz 0x00007D5BE8FDDB31
00007d5be8fdbef6  vmovaps xmm1, [rsp+0xF0]
00007d5be8fdbeff  vmovaps xmm15, [rsp+0xF0]
00007d5be8fdbf08  por xmm1, xmm15
00007d5be8fdbf0d  movaps [r15+0x300], xmm1
00007d5be8fdbf15  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdbf1e  vmovaps xmm9, [rsp+0xE0]
00007d5be8fdbf27  por xmm15, xmm9
00007d5be8fdbf2c  movaps [r15+0x190], xmm15
00007d5be8fdbf34  vmovaps xmm9, [rsp+0x50]
00007d5be8fdbf3a  vpermilpd xmm9, xmm9, 0x00
00007d5be8fdbf40  vmovaps [rsp+0x90], xmm1
00007d5be8fdbf49  vmovaps [rsp+0xE0], xmm15
00007d5be8fdbf52  vmovaps xmm15, [rsp+0x80]
00007d5be8fdbf5b  vmovaps [rsp+0x80], xmm14
00007d5be8fdbf64  movaps xmm1, xmm15
00007d5be8fdbf68  mulpd xmm1, xmm9
00007d5be8fdbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007d5be8fdbf72  ptest xmm14, xmm14
00007d5be8fdbf78  jnz 0x00007D5BE8FDDC72
00007d5be8fdbf7e  lea r12, [rax+0x90]
00007d5be8fdbf85  movups xmm15, [r13+r12*1]
00007d5be8fdbf8b  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdbf94  vmovaps xmm9, [rsp+0xD0]
00007d5be8fdbf9d  por xmm14, xmm9
00007d5be8fdbfa2  movaps [r15+0x1C0], xmm14
00007d5be8fdbfaa  vmovaps xmm9, [rsp+0xC0]
00007d5be8fdbfb3  vmovaps [rsp+0xD0], xmm1
00007d5be8fdbfbc  vmovaps xmm1, [rsp+0xC0]
00007d5be8fdbfc5  por xmm9, xmm1
00007d5be8fdbfca  movaps [r15+0x200], xmm9
00007d5be8fdbfd2  vmovaps [rsp+0xC0], xmm2
00007d5be8fdbfdb  vmovaps xmm1, [rsp+0xC0]
00007d5be8fdbfe4  por xmm2, xmm1
00007d5be8fdbfe8  movaps [r15+0x2D0], xmm2
00007d5be8fdbff0  vmovaps [rsp+0xC0], xmm8
00007d5be8fdbff9  vmovaps xmm1, [rsp+0xC0]
00007d5be8fdc002  por xmm8, xmm1
00007d5be8fdc007  movaps [r15+0x2E0], xmm8
00007d5be8fdc00f  vmovaps [rsp+0xC0], xmm15
00007d5be8fdc018  movaps xmm1, xmm5
00007d5be8fdc01b  addpd xmm1, xmm7
00007d5be8fdc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007d5be8fdc024  ptest xmm15, xmm15
00007d5be8fdc02a  jnz 0x00007D5BE8FDDDBE
00007d5be8fdc030  vmovaps xmm15, [rsp+0x50]
00007d5be8fdc036  vpermilpd xmm15, xmm15, 0x00
00007d5be8fdc03c  vmovaps xmm5, [rsp+0xC0]
00007d5be8fdc045  vmovaps [rsp+0xC0], xmm1
00007d5be8fdc04e  movaps xmm7, xmm5
00007d5be8fdc051  mulpd xmm7, xmm15
00007d5be8fdc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007d5be8fdc05b  ptest xmm1, xmm1
00007d5be8fdc060  jnz 0x00007D5BE8FDDEFE
00007d5be8fdc066  lea r12, [rax+0x80]
00007d5be8fdc06d  movups xmm1, [r13+r12*1]
00007d5be8fdc073  vmovaps xmm5, [rsp+0x70]
00007d5be8fdc079  vmovaps [rsp+0x70], xmm1
00007d5be8fdc07f  movaps xmm15, xmm5
00007d5be8fdc083  addpd xmm15, xmm3
00007d5be8fdc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007d5be8fdc08e  ptest xmm1, xmm1
00007d5be8fdc093  jnz 0x00007D5BE8FDE049
00007d5be8fdc099  vmovaps xmm5, [rsp+0x80]
00007d5be8fdc0a2  movaps xmm1, xmm5
00007d5be8fdc0a5  addpd xmm1, xmm4
00007d5be8fdc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007d5be8fdc0ae  ptest xmm3, xmm3
00007d5be8fdc0b3  jnz 0x00007D5BE8FDE18B
00007d5be8fdc0b9  vmovaps [rsp+0x80], xmm10
00007d5be8fdc0c2  vmovaps xmm5, [rsp+0x80]
00007d5be8fdc0cb  por xmm10, xmm5
00007d5be8fdc0d0  movaps [r15+0x2F0], xmm10
00007d5be8fdc0d8  vmovaps xmm5, [rsp+0x50]
00007d5be8fdc0de  vpermilpd xmm5, xmm5, 0x00
00007d5be8fdc0e4  vmovaps xmm3, [rsp+0x70]
00007d5be8fdc0ea  vmovaps [rsp+0x50], xmm1
00007d5be8fdc0f0  movaps xmm4, xmm3
00007d5be8fdc0f3  mulpd xmm4, xmm5
00007d5be8fdc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007d5be8fdc0fc  ptest xmm1, xmm1
00007d5be8fdc101  jnz 0x00007D5BE8FDE2CB
00007d5be8fdc107  lea r12, [rax+0xD0]
00007d5be8fdc10e  movups xmm1, [r13+r12*1]
00007d5be8fdc114  vmovaps xmm3, [rsp+0xD0]
00007d5be8fdc11d  vmovaps [rsp+0x70], xmm1
00007d5be8fdc123  movaps xmm5, xmm6
00007d5be8fdc126  addpd xmm5, xmm3
00007d5be8fdc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007d5be8fdc12f  ptest xmm1, xmm1
00007d5be8fdc134  jnz 0x00007D5BE8FDE415
00007d5be8fdc13a  vmovaps xmm1, [rsp+0x60]
00007d5be8fdc140  vpermilpd xmm1, xmm1, 0x00
00007d5be8fdc146  movaps xmm6, xmm9
00007d5be8fdc14a  mulpd xmm6, xmm1
00007d5be8fdc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007d5be8fdc153  ptest xmm3, xmm3
00007d5be8fdc158  jnz 0x00007D5BE8FDE555
00007d5be8fdc15e  movaps [r15+0x260], xmm6
00007d5be8fdc166  vxorps xmm1, xmm1, xmm1
00007d5be8fdc16a  vpbroadcastq xmm1, xmm1
00007d5be8fdc16f  movaps [r15+0x1B0], xmm1
00007d5be8fdc177  vmovaps xmm1, [rsp+0x60]
00007d5be8fdc17d  vpermilpd xmm1, xmm1, 0x00
00007d5be8fdc183  vmovaps xmm3, [rsp+0x70]
00007d5be8fdc189  vmovaps [rsp+0x70], xmm15
00007d5be8fdc18f  movaps xmm9, xmm3
00007d5be8fdc193  mulpd xmm9, xmm1
00007d5be8fdc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007d5be8fdc19e  ptest xmm15, xmm15
00007d5be8fdc1a4  jnz 0x00007D5BE8FDE696
00007d5be8fdc1aa  lea r12, [rax+0xC0]
00007d5be8fdc1b1  movups xmm1, [r13+r12*1]
00007d5be8fdc1b7  vmovaps xmm3, [rsp+0xC0]
00007d5be8fdc1c0  vmovaps [rsp+0x80], xmm1
00007d5be8fdc1c9  movaps xmm15, xmm3
00007d5be8fdc1cd  addpd xmm15, xmm7
00007d5be8fdc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007d5be8fdc1d8  ptest xmm1, xmm1
00007d5be8fdc1dd  jnz 0x00007D5BE8FDE7E2
00007d5be8fdc1e3  vmovaps [rsp+0xC0], xmm13
00007d5be8fdc1ec  vmovaps xmm1, [rsp+0xC0]
00007d5be8fdc1f5  por xmm13, xmm1
00007d5be8fdc1fa  movaps [r15+0x270], xmm13
00007d5be8fdc202  vmovaps xmm1, [rsp+0xB0]
00007d5be8fdc20b  vmovaps xmm7, [rsp+0xB0]
00007d5be8fdc214  por xmm1, xmm7
00007d5be8fdc218  movaps [r15+0x1A0], xmm1
00007d5be8fdc220  vmovaps xmm1, [rsp+0x60]
00007d5be8fdc226  vpermilpd xmm1, xmm1, 0x00
00007d5be8fdc22c  vmovaps [rsp+0xB0], xmm1
00007d5be8fdc235  vmovaps xmm1, [rsp+0x80]
00007d5be8fdc23e  vmovaps [rsp+0x80], xmm15
00007d5be8fdc247  vmovaps xmm15, [rsp+0xB0]
00007d5be8fdc250  vmovaps [rsp+0xB0], xmm14
00007d5be8fdc259  movaps xmm3, xmm1
00007d5be8fdc25c  mulpd xmm3, xmm15
00007d5be8fdc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007d5be8fdc266  ptest xmm14, xmm14
00007d5be8fdc26c  jnz 0x00007D5BE8FDE924
00007d5be8fdc272  lea r12, [rax+0x20]
00007d5be8fdc276  movups xmm1, [r13+r12*1]
00007d5be8fdc27c  movaps [r15+0x110], xmm1
00007d5be8fdc284  vmovaps xmm14, [rsp+0x70]
00007d5be8fdc28a  vmovaps [rsp+0x70], xmm1
00007d5be8fdc290  movaps xmm15, xmm14
00007d5be8fdc294  addpd xmm15, xmm4
00007d5be8fdc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007d5be8fdc29f  ptest xmm1, xmm1
00007d5be8fdc2a4  jnz 0x00007D5BE8FDEA6F
00007d5be8fdc2aa  vmovaps xmm1, [rsp+0x60]
00007d5be8fdc2b0  vpermilpd xmm1, xmm1, 0x00
00007d5be8fdc2b6  movaps xmm14, xmm2
00007d5be8fdc2ba  mulpd xmm14, xmm1
00007d5be8fdc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007d5be8fdc2c5  ptest xmm4, xmm4
00007d5be8fdc2ca  jnz 0x00007D5BE8FDEBB2
00007d5be8fdc2d0  vmovaps xmm4, [rsp+0x50]
00007d5be8fdc2d6  movaps xmm1, xmm4
00007d5be8fdc2d9  addpd xmm1, xmm9
00007d5be8fdc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007d5be8fdc2e3  ptest xmm2, xmm2
00007d5be8fdc2e8  jnz 0x00007D5BE8FDECF4
00007d5be8fdc2ee  vmovaps xmm9, [rsp+0x30]
00007d5be8fdc2f4  vpermilpd xmm9, xmm9, 0x00
00007d5be8fdc2fa  vmovaps xmm2, [rsp+0x70]
00007d5be8fdc300  vmovaps [rsp+0x50], xmm1
00007d5be8fdc306  movaps xmm4, xmm2
00007d5be8fdc309  mulpd xmm4, xmm9
00007d5be8fdc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007d5be8fdc313  ptest xmm1, xmm1
00007d5be8fdc318  jnz 0x00007D5BE8FDEE35
00007d5be8fdc31e  vmovaps xmm1, [rsp+0x30]
00007d5be8fdc324  vpermilpd xmm1, xmm1, 0x00
00007d5be8fdc32a  vmovaps xmm2, [rsp+0x90]
00007d5be8fdc333  vmovaps [rsp+0x60], xmm15
00007d5be8fdc339  movaps xmm9, xmm2
00007d5be8fdc33d  mulpd xmm9, xmm1
00007d5be8fdc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007d5be8fdc348  ptest xmm15, xmm15
00007d5be8fdc34e  jnz 0x00007D5BE8FDEF76
00007d5be8fdc354  vmovaps xmm15, [rsp+0x80]
00007d5be8fdc35d  movaps xmm1, xmm15
00007d5be8fdc361  addpd xmm1, xmm6
00007d5be8fdc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007d5be8fdc36a  ptest xmm2, xmm2
00007d5be8fdc36f  jnz 0x00007D5BE8FDF0B8
00007d5be8fdc375  movaps xmm15, xmm5
00007d5be8fdc379  addpd xmm15, xmm3
00007d5be8fdc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007d5be8fdc384  ptest xmm6, xmm6
00007d5be8fdc389  jnz 0x00007D5BE8FDF1F9
00007d5be8fdc38f  vmovaps xmm6, [rsp+0x30]
00007d5be8fdc395  vpermilpd xmm6, xmm6, 0x00
00007d5be8fdc39b  movaps xmm5, xmm8
00007d5be8fdc39f  mulpd xmm5, xmm6
00007d5be8fdc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007d5be8fdc3a8  ptest xmm3, xmm3
00007d5be8fdc3ad  jnz 0x00007D5BE8FDF33B
00007d5be8fdc3b3  vmovaps xmm8, [rsp+0x30]
00007d5be8fdc3b9  vpermilpd xmm8, xmm8, 0x00
00007d5be8fdc3bf  movaps xmm6, xmm10
00007d5be8fdc3c3  mulpd xmm6, xmm8
00007d5be8fdc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007d5be8fdc3cd  ptest xmm3, xmm3
00007d5be8fdc3d2  jnz 0x00007D5BE8FDF47C
00007d5be8fdc3d8  vmovaps xmm8, [rsp+0x60]
00007d5be8fdc3de  movaps xmm10, xmm8
00007d5be8fdc3e2  addpd xmm10, xmm14
00007d5be8fdc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007d5be8fdc3ed  ptest xmm3, xmm3
00007d5be8fdc3f2  jnz 0x00007D5BE8FDF5BE
00007d5be8fdc3f8  vmovaps xmm8, [rsp+0x50]
00007d5be8fdc3fe  movaps xmm14, xmm8
00007d5be8fdc402  addpd xmm14, xmm4
00007d5be8fdc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007d5be8fdc40d  ptest xmm3, xmm3
00007d5be8fdc412  jnz 0x00007D5BE8FDF702
00007d5be8fdc418  vmovaps xmm8, [rsp+0x40]
00007d5be8fdc41e  vpermilpd xmm8, xmm8, 0x00
00007d5be8fdc424  movaps xmm4, xmm13
00007d5be8fdc428  mulpd xmm4, xmm8
00007d5be8fdc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007d5be8fdc432  ptest xmm3, xmm3
00007d5be8fdc437  jnz 0x00007D5BE8FDF845
00007d5be8fdc43d  movaps xmm13, xmm15
00007d5be8fdc441  addpd xmm13, xmm9
00007d5be8fdc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007d5be8fdc44c  ptest xmm8, xmm8
00007d5be8fdc452  jnz 0x00007D5BE8FDF987
00007d5be8fdc458  movaps xmm15, xmm1
00007d5be8fdc45c  addpd xmm15, xmm5
00007d5be8fdc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007d5be8fdc467  ptest xmm9, xmm9
00007d5be8fdc46d  jnz 0x00007D5BE8FDFACB
00007d5be8fdc473  vmovaps [rsp+0x30], xmm11
00007d5be8fdc479  vmovaps xmm1, [rsp+0x30]
00007d5be8fdc47f  por xmm11, xmm1
00007d5be8fdc484  movaps [r15+0x250], xmm11
00007d5be8fdc48c  vmovaps [rsp+0x30], xmm12
00007d5be8fdc492  vmovaps xmm1, [rsp+0x30]
00007d5be8fdc498  por xmm12, xmm1
00007d5be8fdc49d  movaps [r15+0x2A0], xmm12
00007d5be8fdc4a5  vmovaps xmm1, [rsp+0xA0]
00007d5be8fdc4ae  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdc4b7  por xmm1, xmm11
00007d5be8fdc4bc  movaps [r15+0x1D0], xmm1
00007d5be8fdc4c4  lea r12, [rax+0x40]
00007d5be8fdc4c8  movups xmm1, [r13+r12*1]
00007d5be8fdc4ce  movaps [r15+0x2C0], xmm1
00007d5be8fdc4d6  vmovaps xmm11, [rsp+0x40]
00007d5be8fdc4dc  vpermilpd xmm11, xmm11, 0x00
00007d5be8fdc4e2  vmovaps xmm8, [rsp+0xE0]
00007d5be8fdc4eb  movaps xmm9, xmm8
00007d5be8fdc4ef  mulpd xmm9, xmm11
00007d5be8fdc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007d5be8fdc4fa  ptest xmm5, xmm5
00007d5be8fdc4ff  jnz 0x00007D5BE8FDFC17
00007d5be8fdc505  movaps xmm11, xmm10
00007d5be8fdc509  addpd xmm11, xmm6
00007d5be8fdc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007d5be8fdc514  ptest xmm8, xmm8
00007d5be8fdc51a  jnz 0x00007D5BE8FDFD5B
00007d5be8fdc520  movaps xmm10, xmm14
00007d5be8fdc524  addpd xmm10, xmm4
00007d5be8fdc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007d5be8fdc52f  ptest xmm8, xmm8
00007d5be8fdc535  jnz 0x00007D5BE8FDFE9E
00007d5be8fdc53b  vmovaps xmm14, [rsp+0x40]
00007d5be8fdc541  vpermilpd xmm14, xmm14, 0x00
00007d5be8fdc547  movaps xmm8, xmm1
00007d5be8fdc54b  mulpd xmm8, xmm14
00007d5be8fdc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007d5be8fdc556  ptest xmm6, xmm6
00007d5be8fdc55b  jnz 0x00007D5BE8FDFFE1
00007d5be8fdc561  movaps xmm1, [r15+0x2B0]
00007d5be8fdc569  vmovaps xmm14, [rsp+0x40]
00007d5be8fdc56f  vpermilpd xmm14, xmm14, 0x00
00007d5be8fdc575  movaps xmm6, xmm1
00007d5be8fdc578  mulpd xmm6, xmm14
00007d5be8fdc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007d5be8fdc582  ptest xmm5, xmm5
00007d5be8fdc587  jnz 0x00007D5BE8FE0124
00007d5be8fdc58d  vmovaps xmm1, [rsp+0x10]
00007d5be8fdc593  vpermilpd xmm1, xmm1, 0x00
00007d5be8fdc599  movaps xmm14, xmm12
00007d5be8fdc59d  mulpd xmm14, xmm1
00007d5be8fdc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007d5be8fdc5a8  ptest xmm5, xmm5
00007d5be8fdc5ad  jnz 0x00007D5BE8FE0265
00007d5be8fdc5b3  movaps xmm1, xmm13
00007d5be8fdc5b7  addpd xmm1, xmm9
00007d5be8fdc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007d5be8fdc5c1  ptest xmm12, xmm12
00007d5be8fdc5c7  jnz 0x00007D5BE8FE03A8
00007d5be8fdc5cd  vmovaps xmm13, [rsp+0x10]
00007d5be8fdc5d3  vpermilpd xmm13, xmm13, 0x00
00007d5be8fdc5d9  movaps xmm12, xmm7
00007d5be8fdc5dd  mulpd xmm12, xmm13
00007d5be8fdc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007d5be8fdc5e8  ptest xmm9, xmm9
00007d5be8fdc5ee  jnz 0x00007D5BE8FE04EA
00007d5be8fdc5f4  movaps xmm13, xmm15
00007d5be8fdc5f8  addpd xmm13, xmm8
00007d5be8fdc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007d5be8fdc603  ptest xmm9, xmm9
00007d5be8fdc609  jnz 0x00007D5BE8FE062D
00007d5be8fdc60f  movaps xmm15, [r15+0x290]
00007d5be8fdc617  vmovaps xmm9, [rsp+0x10]
00007d5be8fdc61d  vpermilpd xmm9, xmm9, 0x00
00007d5be8fdc623  movaps xmm8, xmm15
00007d5be8fdc627  mulpd xmm8, xmm9
00007d5be8fdc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007d5be8fdc632  ptest xmm7, xmm7
00007d5be8fdc637  jnz 0x00007D5BE8FE0771
00007d5be8fdc63d  movaps xmm15, xmm11
00007d5be8fdc641  addpd xmm15, xmm6
00007d5be8fdc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007d5be8fdc64c  ptest xmm9, xmm9
00007d5be8fdc652  jnz 0x00007D5BE8FE08B5
00007d5be8fdc658  movaps xmm11, [r15+0x1E0]
00007d5be8fdc660  vmovaps xmm9, [rsp+0x10]
00007d5be8fdc666  vpermilpd xmm9, xmm9, 0x00
00007d5be8fdc66c  movaps xmm7, xmm11
00007d5be8fdc670  mulpd xmm7, xmm9
00007d5be8fdc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007d5be8fdc67a  ptest xmm6, xmm6
00007d5be8fdc67f  jnz 0x00007D5BE8FE09F8
00007d5be8fdc685  movaps xmm11, xmm10
00007d5be8fdc689  addpd xmm11, xmm14
00007d5be8fdc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007d5be8fdc694  ptest xmm9, xmm9
00007d5be8fdc69a  jnz 0x00007D5BE8FE0B3A
00007d5be8fdc6a0  lea r12, [rax+0x70]
00007d5be8fdc6a4  movups xmm14, [r13+r12*1]
00007d5be8fdc6aa  movaps [r15+0x240], xmm14
00007d5be8fdc6b2  movaps xmm10, xmm1
00007d5be8fdc6b6  addpd xmm10, xmm12
00007d5be8fdc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007d5be8fdc6c1  ptest xmm9, xmm9
00007d5be8fdc6c7  jnz 0x00007D5BE8FE0C88
00007d5be8fdc6cd  movaps [r15+0x170], xmm10
00007d5be8fdc6d5  vmovaps xmm1, [rsp+0x20]
00007d5be8fdc6db  vpermilpd xmm1, xmm1, 0x00
00007d5be8fdc6e1  movaps xmm12, xmm14
00007d5be8fdc6e5  mulpd xmm12, xmm1
00007d5be8fdc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007d5be8fdc6f0  ptest xmm9, xmm9
00007d5be8fdc6f6  jnz 0x00007D5BE8FE0DCB
00007d5be8fdc6fc  vmovaps xmm1, [rsp+0x20]
00007d5be8fdc702  vpermilpd xmm1, xmm1, 0x00
00007d5be8fdc708  vmovaps xmm9, [rsp+0xB0]
00007d5be8fdc711  movaps xmm14, xmm9
00007d5be8fdc715  mulpd xmm14, xmm1
00007d5be8fdc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007d5be8fdc720  ptest xmm6, xmm6
00007d5be8fdc725  jnz 0x00007D5BE8FE0F0E
00007d5be8fdc72b  movaps [r15+0x180], xmm14
00007d5be8fdc733  movaps xmm1, xmm13
00007d5be8fdc737  addpd xmm1, xmm8
00007d5be8fdc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007d5be8fdc741  ptest xmm9, xmm9
00007d5be8fdc747  jnz 0x00007D5BE8FE1051
00007d5be8fdc74d  movaps [r15+0x210], xmm1
00007d5be8fdc755  movups xmm13, [r13+rax*1]
00007d5be8fdc75b  lea r12, [rax+0x10]
00007d5be8fdc75f  movups xmm9, [r13+r12*1]
00007d5be8fdc765  movaps [r15+0x230], xmm9
00007d5be8fdc76d  movaps xmm8, xmm15
00007d5be8fdc771  addpd xmm8, xmm7
00007d5be8fdc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007d5be8fdc77c  ptest xmm6, xmm6
00007d5be8fdc781  jnz 0x00007D5BE8FE11A7
00007d5be8fdc787  movaps [r15+0x130], xmm8
00007d5be8fdc78f  vmovaps xmm15, [rsp+0x20]
00007d5be8fdc795  vpermilpd xmm15, xmm15, 0x00
00007d5be8fdc79b  movaps xmm7, xmm9
00007d5be8fdc79f  mulpd xmm7, xmm15
00007d5be8fdc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007d5be8fdc7a9  ptest xmm6, xmm6
00007d5be8fdc7ae  jnz 0x00007D5BE8FE12EA
00007d5be8fdc7b4  movaps [r15+0x220], xmm7
00007d5be8fdc7bc  vmovaps xmm15, [rsp+0x20]
00007d5be8fdc7c2  vpermilpd xmm15, xmm15, 0x00
00007d5be8fdc7c8  movaps xmm9, xmm13
00007d5be8fdc7cc  mulpd xmm9, xmm15
00007d5be8fdc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007d5be8fdc7d7  ptest xmm6, xmm6
00007d5be8fdc7dc  jnz 0x00007D5BE8FE142C
00007d5be8fdc7e2  movaps xmm15, xmm11
00007d5be8fdc7e6  addpd xmm15, xmm12
00007d5be8fdc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007d5be8fdc7f1  ptest xmm13, xmm13
00007d5be8fdc7f7  jnz 0x00007D5BE8FE1570
00007d5be8fdc7fd  movaps [r15+0x140], xmm15
00007d5be8fdc805  movaps xmm13, xmm10
00007d5be8fdc809  addpd xmm13, xmm14
00007d5be8fdc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007d5be8fdc814  ptest xmm12, xmm12
00007d5be8fdc81a  jnz 0x00007D5BE8FE16B4
00007d5be8fdc820  movaps [r15+0x150], xmm13
00007d5be8fdc828  movaps xmm14, xmm1
00007d5be8fdc82c  addpd xmm14, xmm7
00007d5be8fdc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007d5be8fdc837  ptest xmm12, xmm12
00007d5be8fdc83d  jnz 0x00007D5BE8FE17F8
00007d5be8fdc843  movaps [r15+0x160], xmm14
00007d5be8fdc84b  movaps xmm1, xmm8
00007d5be8fdc84f  addpd xmm1, xmm9
00007d5be8fdc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007d5be8fdc859  ptest xmm12, xmm12
00007d5be8fdc85f  jnz 0x00007D5BE8FE193A
00007d5be8fdc865  movaps [r15+0x120], xmm1
00007d5be8fdc86d  movups [r13+r14*1], xmm15
00007d5be8fdc873  lea rax, [r14+0x10]
00007d5be8fdc877  movups [r13+rax*1], xmm13
00007d5be8fdc87d  lea rax, [r14+0x20]
00007d5be8fdc881  movups [r13+rax*1], xmm14
00007d5be8fdc887  lea rax, [r14+0x30]
00007d5be8fdc88b  movups [r13+rax*1], xmm1
00007d5be8fdc891  mov eax, [r15+0x108]
00007d5be8fdc898  sahf
00007d5be8fdc899  jnz 0x00007D5BE8FDC8CB
00007d5be8fdc89b  cmp dword ptr [r15+0x318], 0x00
00007d5be8fdc8a3  jz 0x00007D5BE8FDB900
00007d5be8fdc8a9  nop [rax+rax*1], ax
00007d5be8fdc8b2  nop [rax+rax*1], eax
00007d5be8fdc8ba  mov eax, 0x410444
00007d5be8fdc8bf  mov [r15+0x100], rax
00007d5be8fdc8c6  jmp 0x00007D5BE8DFE110
00007d5be8fdc8cb  cmp dword ptr [r15+0x318], 0x00
00007d5be8fdc8d3  jz 0x00007D5BE8FD57E0
00007d5be8fdc8d9  nop [rax+rax*1], ax
00007d5be8fdc8e2  nop [rax+rax*1], eax
00007d5be8fdc8ea  mov eax, 0x410278
00007d5be8fdc8ef  mov [r15+0x100], rax
00007d5be8fdc8f6  jmp 0x00007D5BE8DFE110
00007d5be8fdc8fb  int3
00007d5be8fdc8fc  call 0x00007D5BE8EE27E0
00007d5be8fdc901  jmp 0x00007D5BE8FDB9DF
00007d5be8fdc906  call 0x00007D5BE8EE1570
00007d5be8fdc90b  jmp 0x00007D5BE8FDB9E8
00007d5be8fdc910  call 0x00007D5BE8EE27E0
00007d5be8fdc915  jmp 0x00007D5BE8FDBA44
00007d5be8fdc91a  call 0x00007D5BE8EE1570
00007d5be8fdc91f  jmp 0x00007D5BE8FDBA4D
00007d5be8fdc924  call 0x00007D5BE8EE27E0
00007d5be8fdc929  jmp 0x00007D5BE8FDBA90
00007d5be8fdc92e  call 0x00007D5BE8EE1570
00007d5be8fdc933  jmp 0x00007D5BE8FDBA99
00007d5be8fdc938  call 0x00007D5BE8E0DC20
00007d5be8fdc93d  jmp 0x00007D5BE8FDBAD8
00007d5be8fdc942  call 0x00007D5BE8ED59C0
00007d5be8fdc947  jmp 0x00007D5BE8FDBAEB
00007d5be8fdc94c  call 0x00007D5BE8EE0E30
00007d5be8fdc951  jmp 0x00007D5BE8FDBB09
00007d5be8fdc956  call 0x00007D5BE8EDFBC0
00007d5be8fdc95b  jmp 0x00007D5BE8FDBB13
00007d5be8fdc960  call 0x00007D5BE8EDE950
00007d5be8fdc965  jmp 0x00007D5BE8FDBB1D
00007d5be8fdc96a  sub rsp, 0x08
00007d5be8fdc96e  push rax
00007d5be8fdc96f  push rcx
00007d5be8fdc970  push rdx
00007d5be8fdc971  push rdi
00007d5be8fdc972  push rsi
00007d5be8fdc973  push r8
00007d5be8fdc975  push r9
00007d5be8fdc977  push r10
00007d5be8fdc979  push r11
00007d5be8fdc97b  sub rsp, 0xF0
00007d5be8fdc982  vmovaps [rsp], xmm0
00007d5be8fdc987  vmovaps [rsp+0x10], xmm1
00007d5be8fdc98d  vmovaps [rsp+0x20], xmm2
00007d5be8fdc993  vmovaps [rsp+0x30], xmm3
00007d5be8fdc999  vmovaps [rsp+0x40], xmm4
00007d5be8fdc99f  vmovaps [rsp+0x50], xmm5
00007d5be8fdc9a5  vmovaps [rsp+0x60], xmm6
00007d5be8fdc9ab  vmovaps [rsp+0x70], xmm7
00007d5be8fdc9b1  vmovaps [rsp+0x80], xmm9
00007d5be8fdc9ba  vmovaps [rsp+0x90], xmm10
00007d5be8fdc9c3  vmovaps [rsp+0xA0], xmm11
00007d5be8fdc9cc  vmovaps [rsp+0xB0], xmm12
00007d5be8fdc9d5  vmovaps [rsp+0xC0], xmm13
00007d5be8fdc9de  vmovaps [rsp+0xD0], xmm14
00007d5be8fdc9e7  vmovaps [rsp+0xE0], xmm15
00007d5be8fdc9f0  sub rsp, 0x30
00007d5be8fdc9f4  movaps [rsp], xmm8
00007d5be8fdc9f9  movaps [rsp+0x10], xmm12
00007d5be8fdc9ff  movaps [rsp+0x20], xmm15
00007d5be8fdca05  lea rdi, [rsp]
00007d5be8fdca09  mov esi, 0x00
00007d5be8fdca0e  mov rax, 0x5D345705A530
00007d5be8fdca18  call rax
00007d5be8fdca1a  movaps xmm8, [rsp]
00007d5be8fdca1f  add rsp, 0x30
00007d5be8fdca23  vmovaps xmm0, [rsp]
00007d5be8fdca28  vmovaps xmm1, [rsp+0x10]
00007d5be8fdca2e  vmovaps xmm2, [rsp+0x20]
00007d5be8fdca34  vmovaps xmm3, [rsp+0x30]
00007d5be8fdca3a  vmovaps xmm4, [rsp+0x40]
00007d5be8fdca40  vmovaps xmm5, [rsp+0x50]
00007d5be8fdca46  vmovaps xmm6, [rsp+0x60]
00007d5be8fdca4c  vmovaps xmm7, [rsp+0x70]
00007d5be8fdca52  vmovaps xmm9, [rsp+0x80]
00007d5be8fdca5b  vmovaps xmm10, [rsp+0x90]
00007d5be8fdca64  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdca6d  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdca76  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdca7f  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdca88  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdca91  add rsp, 0xF0
00007d5be8fdca98  pop r11
00007d5be8fdca9a  pop r10
00007d5be8fdca9c  pop r9
00007d5be8fdca9e  pop r8
00007d5be8fdcaa0  pop rsi
00007d5be8fdcaa1  pop rdi
00007d5be8fdcaa2  pop rdx
00007d5be8fdcaa3  pop rcx
00007d5be8fdcaa4  pop rax
00007d5be8fdcaa5  add rsp, 0x08
00007d5be8fdcaa9  jmp 0x00007D5BE8FDBB47
00007d5be8fdcaae  sub rsp, 0x08
00007d5be8fdcab2  push rax
00007d5be8fdcab3  push rcx
00007d5be8fdcab4  push rdx
00007d5be8fdcab5  push rdi
00007d5be8fdcab6  push rsi
00007d5be8fdcab7  push r8
00007d5be8fdcab9  push r9
00007d5be8fdcabb  push r10
00007d5be8fdcabd  push r11
00007d5be8fdcabf  sub rsp, 0xF0
00007d5be8fdcac6  vmovaps [rsp], xmm0
00007d5be8fdcacb  vmovaps [rsp+0x10], xmm1
00007d5be8fdcad1  vmovaps [rsp+0x20], xmm2
00007d5be8fdcad7  vmovaps [rsp+0x30], xmm3
00007d5be8fdcadd  vmovaps [rsp+0x40], xmm4
00007d5be8fdcae3  vmovaps [rsp+0x50], xmm5
00007d5be8fdcae9  vmovaps [rsp+0x60], xmm6
00007d5be8fdcaef  vmovaps [rsp+0x70], xmm8
00007d5be8fdcaf5  vmovaps [rsp+0x80], xmm9
00007d5be8fdcafe  vmovaps [rsp+0x90], xmm10
00007d5be8fdcb07  vmovaps [rsp+0xA0], xmm11
00007d5be8fdcb10  vmovaps [rsp+0xB0], xmm12
00007d5be8fdcb19  vmovaps [rsp+0xC0], xmm13
00007d5be8fdcb22  vmovaps [rsp+0xD0], xmm14
00007d5be8fdcb2b  vmovaps [rsp+0xE0], xmm15
00007d5be8fdcb34  sub rsp, 0x30
00007d5be8fdcb38  movaps [rsp], xmm7
00007d5be8fdcb3c  movaps [rsp+0x10], xmm9
00007d5be8fdcb42  movaps [rsp+0x20], xmm15
00007d5be8fdcb48  lea rdi, [rsp]
00007d5be8fdcb4c  mov esi, 0x00
00007d5be8fdcb51  mov rax, 0x5D345705A530
00007d5be8fdcb5b  call rax
00007d5be8fdcb5d  movaps xmm7, [rsp]
00007d5be8fdcb61  add rsp, 0x30
00007d5be8fdcb65  vmovaps xmm0, [rsp]
00007d5be8fdcb6a  vmovaps xmm1, [rsp+0x10]
00007d5be8fdcb70  vmovaps xmm2, [rsp+0x20]
00007d5be8fdcb76  vmovaps xmm3, [rsp+0x30]
00007d5be8fdcb7c  vmovaps xmm4, [rsp+0x40]
00007d5be8fdcb82  vmovaps xmm5, [rsp+0x50]
00007d5be8fdcb88  vmovaps xmm6, [rsp+0x60]
00007d5be8fdcb8e  vmovaps xmm8, [rsp+0x70]
00007d5be8fdcb94  vmovaps xmm9, [rsp+0x80]
00007d5be8fdcb9d  vmovaps xmm10, [rsp+0x90]
00007d5be8fdcba6  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdcbaf  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdcbb8  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdcbc1  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdcbca  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdcbd3  add rsp, 0xF0
00007d5be8fdcbda  pop r11
00007d5be8fdcbdc  pop r10
00007d5be8fdcbde  pop r9
00007d5be8fdcbe0  pop r8
00007d5be8fdcbe2  pop rsi
00007d5be8fdcbe3  pop rdi
00007d5be8fdcbe4  pop rdx
00007d5be8fdcbe5  pop rcx
00007d5be8fdcbe6  pop rax
00007d5be8fdcbe7  add rsp, 0x08
00007d5be8fdcbeb  jmp 0x00007D5BE8FDBB75
00007d5be8fdcbf0  sub rsp, 0x08
00007d5be8fdcbf4  push rax
00007d5be8fdcbf5  push rcx
00007d5be8fdcbf6  push rdx
00007d5be8fdcbf7  push rdi
00007d5be8fdcbf8  push rsi
00007d5be8fdcbf9  push r8
00007d5be8fdcbfb  push r9
00007d5be8fdcbfd  push r10
00007d5be8fdcbff  push r11
00007d5be8fdcc01  sub rsp, 0xF0
00007d5be8fdcc08  vmovaps [rsp], xmm0
00007d5be8fdcc0d  vmovaps [rsp+0x10], xmm1
00007d5be8fdcc13  vmovaps [rsp+0x20], xmm2
00007d5be8fdcc19  vmovaps [rsp+0x30], xmm3
00007d5be8fdcc1f  vmovaps [rsp+0x40], xmm4
00007d5be8fdcc25  vmovaps [rsp+0x50], xmm5
00007d5be8fdcc2b  vmovaps [rsp+0x60], xmm6
00007d5be8fdcc31  vmovaps [rsp+0x70], xmm7
00007d5be8fdcc37  vmovaps [rsp+0x80], xmm8
00007d5be8fdcc40  vmovaps [rsp+0x90], xmm10
00007d5be8fdcc49  vmovaps [rsp+0xA0], xmm11
00007d5be8fdcc52  vmovaps [rsp+0xB0], xmm12
00007d5be8fdcc5b  vmovaps [rsp+0xC0], xmm13
00007d5be8fdcc64  vmovaps [rsp+0xD0], xmm14
00007d5be8fdcc6d  vmovaps [rsp+0xE0], xmm15
00007d5be8fdcc76  sub rsp, 0x30
00007d5be8fdcc7a  movaps [rsp], xmm9
00007d5be8fdcc7f  movaps [rsp+0x10], xmm12
00007d5be8fdcc85  movaps [rsp+0x20], xmm10
00007d5be8fdcc8b  lea rdi, [rsp]
00007d5be8fdcc8f  mov esi, 0x00
00007d5be8fdcc94  mov rax, 0x5D345705A530
00007d5be8fdcc9e  call rax
00007d5be8fdcca0  movaps xmm9, [rsp]
00007d5be8fdcca5  add rsp, 0x30
00007d5be8fdcca9  vmovaps xmm0, [rsp]
00007d5be8fdccae  vmovaps xmm1, [rsp+0x10]
00007d5be8fdccb4  vmovaps xmm2, [rsp+0x20]
00007d5be8fdccba  vmovaps xmm3, [rsp+0x30]
00007d5be8fdccc0  vmovaps xmm4, [rsp+0x40]
00007d5be8fdccc6  vmovaps xmm5, [rsp+0x50]
00007d5be8fdcccc  vmovaps xmm6, [rsp+0x60]
00007d5be8fdccd2  vmovaps xmm7, [rsp+0x70]
00007d5be8fdccd8  vmovaps xmm8, [rsp+0x80]
00007d5be8fdcce1  vmovaps xmm10, [rsp+0x90]
00007d5be8fdccea  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdccf3  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdccfc  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdcd05  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdcd0e  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdcd17  add rsp, 0xF0
00007d5be8fdcd1e  pop r11
00007d5be8fdcd20  pop r10
00007d5be8fdcd22  pop r9
00007d5be8fdcd24  pop r8
00007d5be8fdcd26  pop rsi
00007d5be8fdcd27  pop rdi
00007d5be8fdcd28  pop rdx
00007d5be8fdcd29  pop rcx
00007d5be8fdcd2a  pop rax
00007d5be8fdcd2b  add rsp, 0x08
00007d5be8fdcd2f  jmp 0x00007D5BE8FDBB99
00007d5be8fdcd34  sub rsp, 0x08
00007d5be8fdcd38  push rax
00007d5be8fdcd39  push rcx
00007d5be8fdcd3a  push rdx
00007d5be8fdcd3b  push rdi
00007d5be8fdcd3c  push rsi
00007d5be8fdcd3d  push r8
00007d5be8fdcd3f  push r9
00007d5be8fdcd41  push r10
00007d5be8fdcd43  push r11
00007d5be8fdcd45  sub rsp, 0xF0
00007d5be8fdcd4c  vmovaps [rsp], xmm0
00007d5be8fdcd51  vmovaps [rsp+0x10], xmm1
00007d5be8fdcd57  vmovaps [rsp+0x20], xmm2
00007d5be8fdcd5d  vmovaps [rsp+0x30], xmm3
00007d5be8fdcd63  vmovaps [rsp+0x40], xmm4
00007d5be8fdcd69  vmovaps [rsp+0x50], xmm5
00007d5be8fdcd6f  vmovaps [rsp+0x60], xmm6
00007d5be8fdcd75  vmovaps [rsp+0x70], xmm7
00007d5be8fdcd7b  vmovaps [rsp+0x80], xmm8
00007d5be8fdcd84  vmovaps [rsp+0x90], xmm9
00007d5be8fdcd8d  vmovaps [rsp+0xA0], xmm11
00007d5be8fdcd96  vmovaps [rsp+0xB0], xmm12
00007d5be8fdcd9f  vmovaps [rsp+0xC0], xmm13
00007d5be8fdcda8  vmovaps [rsp+0xD0], xmm14
00007d5be8fdcdb1  vmovaps [rsp+0xE0], xmm15
00007d5be8fdcdba  sub rsp, 0x30
00007d5be8fdcdbe  movaps [rsp], xmm10
00007d5be8fdcdc3  movaps [rsp+0x10], xmm12
00007d5be8fdcdc9  movaps [rsp+0x20], xmm11
00007d5be8fdcdcf  lea rdi, [rsp]
00007d5be8fdcdd3  mov esi, 0x00
00007d5be8fdcdd8  mov rax, 0x5D345705A530
00007d5be8fdcde2  call rax
00007d5be8fdcde4  movaps xmm10, [rsp]
00007d5be8fdcde9  add rsp, 0x30
00007d5be8fdcded  vmovaps xmm0, [rsp]
00007d5be8fdcdf2  vmovaps xmm1, [rsp+0x10]
00007d5be8fdcdf8  vmovaps xmm2, [rsp+0x20]
00007d5be8fdcdfe  vmovaps xmm3, [rsp+0x30]
00007d5be8fdce04  vmovaps xmm4, [rsp+0x40]
00007d5be8fdce0a  vmovaps xmm5, [rsp+0x50]
00007d5be8fdce10  vmovaps xmm6, [rsp+0x60]
00007d5be8fdce16  vmovaps xmm7, [rsp+0x70]
00007d5be8fdce1c  vmovaps xmm8, [rsp+0x80]
00007d5be8fdce25  vmovaps xmm9, [rsp+0x90]
00007d5be8fdce2e  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdce37  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdce40  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdce49  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdce52  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdce5b  add rsp, 0xF0
00007d5be8fdce62  pop r11
00007d5be8fdce64  pop r10
00007d5be8fdce66  pop r9
00007d5be8fdce68  pop r8
00007d5be8fdce6a  pop rsi
00007d5be8fdce6b  pop rdi
00007d5be8fdce6c  pop rdx
00007d5be8fdce6d  pop rcx
00007d5be8fdce6e  pop rax
00007d5be8fdce6f  add rsp, 0x08
00007d5be8fdce73  jmp 0x00007D5BE8FDBBB3
00007d5be8fdce78  sub rsp, 0x08
00007d5be8fdce7c  push rax
00007d5be8fdce7d  push rcx
00007d5be8fdce7e  push rdx
00007d5be8fdce7f  push rdi
00007d5be8fdce80  push rsi
00007d5be8fdce81  push r8
00007d5be8fdce83  push r9
00007d5be8fdce85  push r10
00007d5be8fdce87  push r11
00007d5be8fdce89  sub rsp, 0xF0
00007d5be8fdce90  vmovaps [rsp], xmm0
00007d5be8fdce95  vmovaps [rsp+0x10], xmm1
00007d5be8fdce9b  vmovaps [rsp+0x20], xmm2
00007d5be8fdcea1  vmovaps [rsp+0x30], xmm3
00007d5be8fdcea7  vmovaps [rsp+0x40], xmm4
00007d5be8fdcead  vmovaps [rsp+0x50], xmm5
00007d5be8fdceb3  vmovaps [rsp+0x60], xmm7
00007d5be8fdceb9  vmovaps [rsp+0x70], xmm8
00007d5be8fdcebf  vmovaps [rsp+0x80], xmm9
00007d5be8fdcec8  vmovaps [rsp+0x90], xmm10
00007d5be8fdced1  vmovaps [rsp+0xA0], xmm11
00007d5be8fdceda  vmovaps [rsp+0xB0], xmm12
00007d5be8fdcee3  vmovaps [rsp+0xC0], xmm13
00007d5be8fdceec  vmovaps [rsp+0xD0], xmm14
00007d5be8fdcef5  vmovaps [rsp+0xE0], xmm15
00007d5be8fdcefe  sub rsp, 0x30
00007d5be8fdcf02  movaps [rsp], xmm6
00007d5be8fdcf06  movaps [rsp+0x10], xmm12
00007d5be8fdcf0c  movaps [rsp+0x20], xmm11
00007d5be8fdcf12  lea rdi, [rsp]
00007d5be8fdcf16  mov esi, 0x00
00007d5be8fdcf1b  mov rax, 0x5D345705A530
00007d5be8fdcf25  call rax
00007d5be8fdcf27  movaps xmm6, [rsp]
00007d5be8fdcf2b  add rsp, 0x30
00007d5be8fdcf2f  vmovaps xmm0, [rsp]
00007d5be8fdcf34  vmovaps xmm1, [rsp+0x10]
00007d5be8fdcf3a  vmovaps xmm2, [rsp+0x20]
00007d5be8fdcf40  vmovaps xmm3, [rsp+0x30]
00007d5be8fdcf46  vmovaps xmm4, [rsp+0x40]
00007d5be8fdcf4c  vmovaps xmm5, [rsp+0x50]
00007d5be8fdcf52  vmovaps xmm7, [rsp+0x60]
00007d5be8fdcf58  vmovaps xmm8, [rsp+0x70]
00007d5be8fdcf5e  vmovaps xmm9, [rsp+0x80]
00007d5be8fdcf67  vmovaps xmm10, [rsp+0x90]
00007d5be8fdcf70  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdcf79  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdcf82  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdcf8b  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdcf94  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdcf9d  add rsp, 0xF0
00007d5be8fdcfa4  pop r11
00007d5be8fdcfa6  pop r10
00007d5be8fdcfa8  pop r9
00007d5be8fdcfaa  pop r8
00007d5be8fdcfac  pop rsi
00007d5be8fdcfad  pop rdi
00007d5be8fdcfae  pop rdx
00007d5be8fdcfaf  pop rcx
00007d5be8fdcfb0  pop rax
00007d5be8fdcfb1  add rsp, 0x08
00007d5be8fdcfb5  jmp 0x00007D5BE8FDBBD4
00007d5be8fdcfba  sub rsp, 0x08
00007d5be8fdcfbe  push rax
00007d5be8fdcfbf  push rcx
00007d5be8fdcfc0  push rdx
00007d5be8fdcfc1  push rdi
00007d5be8fdcfc2  push rsi
00007d5be8fdcfc3  push r8
00007d5be8fdcfc5  push r9
00007d5be8fdcfc7  push r10
00007d5be8fdcfc9  push r11
00007d5be8fdcfcb  sub rsp, 0xF0
00007d5be8fdcfd2  vmovaps [rsp], xmm0
00007d5be8fdcfd7  vmovaps [rsp+0x10], xmm1
00007d5be8fdcfdd  vmovaps [rsp+0x20], xmm2
00007d5be8fdcfe3  vmovaps [rsp+0x30], xmm4
00007d5be8fdcfe9  vmovaps [rsp+0x40], xmm5
00007d5be8fdcfef  vmovaps [rsp+0x50], xmm6
00007d5be8fdcff5  vmovaps [rsp+0x60], xmm7
00007d5be8fdcffb  vmovaps [rsp+0x70], xmm8
00007d5be8fdd001  vmovaps [rsp+0x80], xmm9
00007d5be8fdd00a  vmovaps [rsp+0x90], xmm10
00007d5be8fdd013  vmovaps [rsp+0xA0], xmm11
00007d5be8fdd01c  vmovaps [rsp+0xB0], xmm12
00007d5be8fdd025  vmovaps [rsp+0xC0], xmm13
00007d5be8fdd02e  vmovaps [rsp+0xD0], xmm14
00007d5be8fdd037  vmovaps [rsp+0xE0], xmm15
00007d5be8fdd040  sub rsp, 0x30
00007d5be8fdd044  movaps [rsp], xmm3
00007d5be8fdd048  movaps [rsp+0x10], xmm5
00007d5be8fdd04d  movaps [rsp+0x20], xmm4
00007d5be8fdd052  lea rdi, [rsp]
00007d5be8fdd056  mov esi, 0x00
00007d5be8fdd05b  mov rax, 0x5D345705A530
00007d5be8fdd065  call rax
00007d5be8fdd067  movaps xmm3, [rsp]
00007d5be8fdd06b  add rsp, 0x30
00007d5be8fdd06f  vmovaps xmm0, [rsp]
00007d5be8fdd074  vmovaps xmm1, [rsp+0x10]
00007d5be8fdd07a  vmovaps xmm2, [rsp+0x20]
00007d5be8fdd080  vmovaps xmm4, [rsp+0x30]
00007d5be8fdd086  vmovaps xmm5, [rsp+0x40]
00007d5be8fdd08c  vmovaps xmm6, [rsp+0x50]
00007d5be8fdd092  vmovaps xmm7, [rsp+0x60]
00007d5be8fdd098  vmovaps xmm8, [rsp+0x70]
00007d5be8fdd09e  vmovaps xmm9, [rsp+0x80]
00007d5be8fdd0a7  vmovaps xmm10, [rsp+0x90]
00007d5be8fdd0b0  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdd0b9  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdd0c2  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdd0cb  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdd0d4  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdd0dd  add rsp, 0xF0
00007d5be8fdd0e4  pop r11
00007d5be8fdd0e6  pop r10
00007d5be8fdd0e8  pop r9
00007d5be8fdd0ea  pop r8
00007d5be8fdd0ec  pop rsi
00007d5be8fdd0ed  pop rdi
00007d5be8fdd0ee  pop rdx
00007d5be8fdd0ef  pop rcx
00007d5be8fdd0f0  pop rax
00007d5be8fdd0f1  add rsp, 0x08
00007d5be8fdd0f5  jmp 0x00007D5BE8FDBC35
00007d5be8fdd0fa  sub rsp, 0x08
00007d5be8fdd0fe  push rax
00007d5be8fdd0ff  push rcx
00007d5be8fdd100  push rdx
00007d5be8fdd101  push rdi
00007d5be8fdd102  push rsi
00007d5be8fdd103  push r8
00007d5be8fdd105  push r9
00007d5be8fdd107  push r10
00007d5be8fdd109  push r11
00007d5be8fdd10b  sub rsp, 0xF0
00007d5be8fdd112  vmovaps [rsp], xmm0
00007d5be8fdd117  vmovaps [rsp+0x10], xmm1
00007d5be8fdd11d  vmovaps [rsp+0x20], xmm2
00007d5be8fdd123  vmovaps [rsp+0x30], xmm3
00007d5be8fdd129  vmovaps [rsp+0x40], xmm4
00007d5be8fdd12f  vmovaps [rsp+0x50], xmm6
00007d5be8fdd135  vmovaps [rsp+0x60], xmm7
00007d5be8fdd13b  vmovaps [rsp+0x70], xmm8
00007d5be8fdd141  vmovaps [rsp+0x80], xmm9
00007d5be8fdd14a  vmovaps [rsp+0x90], xmm10
00007d5be8fdd153  vmovaps [rsp+0xA0], xmm11
00007d5be8fdd15c  vmovaps [rsp+0xB0], xmm12
00007d5be8fdd165  vmovaps [rsp+0xC0], xmm13
00007d5be8fdd16e  vmovaps [rsp+0xD0], xmm14
00007d5be8fdd177  vmovaps [rsp+0xE0], xmm15
00007d5be8fdd180  sub rsp, 0x30
00007d5be8fdd184  movaps [rsp], xmm5
00007d5be8fdd188  movaps [rsp+0x10], xmm8
00007d5be8fdd18e  movaps [rsp+0x20], xmm15
00007d5be8fdd194  lea rdi, [rsp]
00007d5be8fdd198  mov esi, 0x00
00007d5be8fdd19d  mov rax, 0x5D345705A530
00007d5be8fdd1a7  call rax
00007d5be8fdd1a9  movaps xmm5, [rsp]
00007d5be8fdd1ad  add rsp, 0x30
00007d5be8fdd1b1  vmovaps xmm0, [rsp]
00007d5be8fdd1b6  vmovaps xmm1, [rsp+0x10]
00007d5be8fdd1bc  vmovaps xmm2, [rsp+0x20]
00007d5be8fdd1c2  vmovaps xmm3, [rsp+0x30]
00007d5be8fdd1c8  vmovaps xmm4, [rsp+0x40]
00007d5be8fdd1ce  vmovaps xmm6, [rsp+0x50]
00007d5be8fdd1d4  vmovaps xmm7, [rsp+0x60]
00007d5be8fdd1da  vmovaps xmm8, [rsp+0x70]
00007d5be8fdd1e0  vmovaps xmm9, [rsp+0x80]
00007d5be8fdd1e9  vmovaps xmm10, [rsp+0x90]
00007d5be8fdd1f2  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdd1fb  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdd204  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdd20d  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdd216  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdd21f  add rsp, 0xF0
00007d5be8fdd226  pop r11
00007d5be8fdd228  pop r10
00007d5be8fdd22a  pop r9
00007d5be8fdd22c  pop r8
00007d5be8fdd22e  pop rsi
00007d5be8fdd22f  pop rdi
00007d5be8fdd230  pop rdx
00007d5be8fdd231  pop rcx
00007d5be8fdd232  pop rax
00007d5be8fdd233  add rsp, 0x08
00007d5be8fdd237  jmp 0x00007D5BE8FDBC73
00007d5be8fdd23c  sub rsp, 0x08
00007d5be8fdd240  push rax
00007d5be8fdd241  push rcx
00007d5be8fdd242  push rdx
00007d5be8fdd243  push rdi
00007d5be8fdd244  push rsi
00007d5be8fdd245  push r8
00007d5be8fdd247  push r9
00007d5be8fdd249  push r10
00007d5be8fdd24b  push r11
00007d5be8fdd24d  sub rsp, 0xF0
00007d5be8fdd254  vmovaps [rsp], xmm0
00007d5be8fdd259  vmovaps [rsp+0x10], xmm1
00007d5be8fdd25f  vmovaps [rsp+0x20], xmm2
00007d5be8fdd265  vmovaps [rsp+0x30], xmm3
00007d5be8fdd26b  vmovaps [rsp+0x40], xmm5
00007d5be8fdd271  vmovaps [rsp+0x50], xmm6
00007d5be8fdd277  vmovaps [rsp+0x60], xmm7
00007d5be8fdd27d  vmovaps [rsp+0x70], xmm8
00007d5be8fdd283  vmovaps [rsp+0x80], xmm9
00007d5be8fdd28c  vmovaps [rsp+0x90], xmm10
00007d5be8fdd295  vmovaps [rsp+0xA0], xmm11
00007d5be8fdd29e  vmovaps [rsp+0xB0], xmm12
00007d5be8fdd2a7  vmovaps [rsp+0xC0], xmm13
00007d5be8fdd2b0  vmovaps [rsp+0xD0], xmm14
00007d5be8fdd2b9  vmovaps [rsp+0xE0], xmm15
00007d5be8fdd2c2  sub rsp, 0x30
00007d5be8fdd2c6  movaps [rsp], xmm4
00007d5be8fdd2ca  movaps [rsp+0x10], xmm9
00007d5be8fdd2d0  movaps [rsp+0x20], xmm8
00007d5be8fdd2d6  lea rdi, [rsp]
00007d5be8fdd2da  mov esi, 0x00
00007d5be8fdd2df  mov rax, 0x5D345705A530
00007d5be8fdd2e9  call rax
00007d5be8fdd2eb  movaps xmm4, [rsp]
00007d5be8fdd2ef  add rsp, 0x30
00007d5be8fdd2f3  vmovaps xmm0, [rsp]
00007d5be8fdd2f8  vmovaps xmm1, [rsp+0x10]
00007d5be8fdd2fe  vmovaps xmm2, [rsp+0x20]
00007d5be8fdd304  vmovaps xmm3, [rsp+0x30]
00007d5be8fdd30a  vmovaps xmm5, [rsp+0x40]
00007d5be8fdd310  vmovaps xmm6, [rsp+0x50]
00007d5be8fdd316  vmovaps xmm7, [rsp+0x60]
00007d5be8fdd31c  vmovaps xmm8, [rsp+0x70]
00007d5be8fdd322  vmovaps xmm9, [rsp+0x80]
00007d5be8fdd32b  vmovaps xmm10, [rsp+0x90]
00007d5be8fdd334  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdd33d  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdd346  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdd34f  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdd358  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdd361  add rsp, 0xF0
00007d5be8fdd368  pop r11
00007d5be8fdd36a  pop r10
00007d5be8fdd36c  pop r9
00007d5be8fdd36e  pop r8
00007d5be8fdd370  pop rsi
00007d5be8fdd371  pop rdi
00007d5be8fdd372  pop rdx
00007d5be8fdd373  pop rcx
00007d5be8fdd374  pop rax
00007d5be8fdd375  add rsp, 0x08
00007d5be8fdd379  jmp 0x00007D5BE8FDBC94
00007d5be8fdd37e  sub rsp, 0x08
00007d5be8fdd382  push rax
00007d5be8fdd383  push rcx
00007d5be8fdd384  push rdx
00007d5be8fdd385  push rdi
00007d5be8fdd386  push rsi
00007d5be8fdd387  push r8
00007d5be8fdd389  push r9
00007d5be8fdd38b  push r10
00007d5be8fdd38d  push r11
00007d5be8fdd38f  sub rsp, 0xF0
00007d5be8fdd396  vmovaps [rsp], xmm0
00007d5be8fdd39b  vmovaps [rsp+0x10], xmm1
00007d5be8fdd3a1  vmovaps [rsp+0x20], xmm2
00007d5be8fdd3a7  vmovaps [rsp+0x30], xmm3
00007d5be8fdd3ad  vmovaps [rsp+0x40], xmm4
00007d5be8fdd3b3  vmovaps [rsp+0x50], xmm5
00007d5be8fdd3b9  vmovaps [rsp+0x60], xmm6
00007d5be8fdd3bf  vmovaps [rsp+0x70], xmm7
00007d5be8fdd3c5  vmovaps [rsp+0x80], xmm8
00007d5be8fdd3ce  vmovaps [rsp+0x90], xmm10
00007d5be8fdd3d7  vmovaps [rsp+0xA0], xmm11
00007d5be8fdd3e0  vmovaps [rsp+0xB0], xmm12
00007d5be8fdd3e9  vmovaps [rsp+0xC0], xmm13
00007d5be8fdd3f2  vmovaps [rsp+0xD0], xmm14
00007d5be8fdd3fb  vmovaps [rsp+0xE0], xmm15
00007d5be8fdd404  sub rsp, 0x30
00007d5be8fdd408  movaps [rsp], xmm9
00007d5be8fdd40d  movaps [rsp+0x10], xmm10
00007d5be8fdd413  movaps [rsp+0x20], xmm8
00007d5be8fdd419  lea rdi, [rsp]
00007d5be8fdd41d  mov esi, 0x00
00007d5be8fdd422  mov rax, 0x5D345705A530
00007d5be8fdd42c  call rax
00007d5be8fdd42e  movaps xmm9, [rsp]
00007d5be8fdd433  add rsp, 0x30
00007d5be8fdd437  vmovaps xmm0, [rsp]
00007d5be8fdd43c  vmovaps xmm1, [rsp+0x10]
00007d5be8fdd442  vmovaps xmm2, [rsp+0x20]
00007d5be8fdd448  vmovaps xmm3, [rsp+0x30]
00007d5be8fdd44e  vmovaps xmm4, [rsp+0x40]
00007d5be8fdd454  vmovaps xmm5, [rsp+0x50]
00007d5be8fdd45a  vmovaps xmm6, [rsp+0x60]
00007d5be8fdd460  vmovaps xmm7, [rsp+0x70]
00007d5be8fdd466  vmovaps xmm8, [rsp+0x80]
00007d5be8fdd46f  vmovaps xmm10, [rsp+0x90]
00007d5be8fdd478  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdd481  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdd48a  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdd493  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdd49c  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdd4a5  add rsp, 0xF0
00007d5be8fdd4ac  pop r11
00007d5be8fdd4ae  pop r10
00007d5be8fdd4b0  pop r9
00007d5be8fdd4b2  pop r8
00007d5be8fdd4b4  pop rsi
00007d5be8fdd4b5  pop rdi
00007d5be8fdd4b6  pop rdx
00007d5be8fdd4b7  pop rcx
00007d5be8fdd4b8  pop rax
00007d5be8fdd4b9  add rsp, 0x08
00007d5be8fdd4bd  jmp 0x00007D5BE8FDBCAE
00007d5be8fdd4c2  call 0x00007D5BE8EB52F0
00007d5be8fdd4c7  jmp 0x00007D5BE8FDBDC8
00007d5be8fdd4cc  call 0x00007D5BE8EB52F0
00007d5be8fdd4d1  jmp 0x00007D5BE8FDBDDE
00007d5be8fdd4d6  sub rsp, 0x08
00007d5be8fdd4da  push rax
00007d5be8fdd4db  push rcx
00007d5be8fdd4dc  push rdx
00007d5be8fdd4dd  push rdi
00007d5be8fdd4de  push rsi
00007d5be8fdd4df  push r8
00007d5be8fdd4e1  push r9
00007d5be8fdd4e3  push r10
00007d5be8fdd4e5  push r11
00007d5be8fdd4e7  sub rsp, 0xF0
00007d5be8fdd4ee  vmovaps [rsp], xmm0
00007d5be8fdd4f3  vmovaps [rsp+0x10], xmm2
00007d5be8fdd4f9  vmovaps [rsp+0x20], xmm3
00007d5be8fdd4ff  vmovaps [rsp+0x30], xmm4
00007d5be8fdd505  vmovaps [rsp+0x40], xmm5
00007d5be8fdd50b  vmovaps [rsp+0x50], xmm6
00007d5be8fdd511  vmovaps [rsp+0x60], xmm7
00007d5be8fdd517  vmovaps [rsp+0x70], xmm8
00007d5be8fdd51d  vmovaps [rsp+0x80], xmm9
00007d5be8fdd526  vmovaps [rsp+0x90], xmm10
00007d5be8fdd52f  vmovaps [rsp+0xA0], xmm11
00007d5be8fdd538  vmovaps [rsp+0xB0], xmm12
00007d5be8fdd541  vmovaps [rsp+0xC0], xmm13
00007d5be8fdd54a  vmovaps [rsp+0xD0], xmm14
00007d5be8fdd553  vmovaps [rsp+0xE0], xmm15
00007d5be8fdd55c  sub rsp, 0x30
00007d5be8fdd560  movaps [rsp], xmm1
00007d5be8fdd564  movaps [rsp+0x10], xmm6
00007d5be8fdd569  movaps [rsp+0x20], xmm15
00007d5be8fdd56f  lea rdi, [rsp]
00007d5be8fdd573  mov esi, 0x00
00007d5be8fdd578  mov rax, 0x5D345705A530
00007d5be8fdd582  call rax
00007d5be8fdd584  movaps xmm1, [rsp]
00007d5be8fdd588  add rsp, 0x30
00007d5be8fdd58c  vmovaps xmm0, [rsp]
00007d5be8fdd591  vmovaps xmm2, [rsp+0x10]
00007d5be8fdd597  vmovaps xmm3, [rsp+0x20]
00007d5be8fdd59d  vmovaps xmm4, [rsp+0x30]
00007d5be8fdd5a3  vmovaps xmm5, [rsp+0x40]
00007d5be8fdd5a9  vmovaps xmm6, [rsp+0x50]
00007d5be8fdd5af  vmovaps xmm7, [rsp+0x60]
00007d5be8fdd5b5  vmovaps xmm8, [rsp+0x70]
00007d5be8fdd5bb  vmovaps xmm9, [rsp+0x80]
00007d5be8fdd5c4  vmovaps xmm10, [rsp+0x90]
00007d5be8fdd5cd  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdd5d6  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdd5df  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdd5e8  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdd5f1  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdd5fa  add rsp, 0xF0
00007d5be8fdd601  pop r11
00007d5be8fdd603  pop r10
00007d5be8fdd605  pop r9
00007d5be8fdd607  pop r8
00007d5be8fdd609  pop rsi
00007d5be8fdd60a  pop rdi
00007d5be8fdd60b  pop rdx
00007d5be8fdd60c  pop rcx
00007d5be8fdd60d  pop rax
00007d5be8fdd60e  add rsp, 0x08
00007d5be8fdd612  jmp 0x00007D5BE8FDBE1B
00007d5be8fdd617  call 0x00007D5BE8EC4620
00007d5be8fdd61c  jmp 0x00007D5BE8FDBE28
00007d5be8fdd621  sub rsp, 0x08
00007d5be8fdd625  push rax
00007d5be8fdd626  push rcx
00007d5be8fdd627  push rdx
00007d5be8fdd628  push rdi
00007d5be8fdd629  push rsi
00007d5be8fdd62a  push r8
00007d5be8fdd62c  push r9
00007d5be8fdd62e  push r10
00007d5be8fdd630  push r11
00007d5be8fdd632  sub rsp, 0xF0
00007d5be8fdd639  vmovaps [rsp], xmm0
00007d5be8fdd63e  vmovaps [rsp+0x10], xmm1
00007d5be8fdd644  vmovaps [rsp+0x20], xmm2
00007d5be8fdd64a  vmovaps [rsp+0x30], xmm3
00007d5be8fdd650  vmovaps [rsp+0x40], xmm4
00007d5be8fdd656  vmovaps [rsp+0x50], xmm5
00007d5be8fdd65c  vmovaps [rsp+0x60], xmm6
00007d5be8fdd662  vmovaps [rsp+0x70], xmm7
00007d5be8fdd668  vmovaps [rsp+0x80], xmm8
00007d5be8fdd671  vmovaps [rsp+0x90], xmm9
00007d5be8fdd67a  vmovaps [rsp+0xA0], xmm10
00007d5be8fdd683  vmovaps [rsp+0xB0], xmm11
00007d5be8fdd68c  vmovaps [rsp+0xC0], xmm12
00007d5be8fdd695  vmovaps [rsp+0xD0], xmm13
00007d5be8fdd69e  vmovaps [rsp+0xE0], xmm15
00007d5be8fdd6a7  sub rsp, 0x30
00007d5be8fdd6ab  movaps [rsp], xmm14
00007d5be8fdd6b0  movaps [rsp+0x10], xmm4
00007d5be8fdd6b5  movaps [rsp+0x20], xmm3
00007d5be8fdd6ba  lea rdi, [rsp]
00007d5be8fdd6be  mov esi, 0x00
00007d5be8fdd6c3  mov rax, 0x5D345705A530
00007d5be8fdd6cd  call rax
00007d5be8fdd6cf  movaps xmm14, [rsp]
00007d5be8fdd6d4  add rsp, 0x30
00007d5be8fdd6d8  vmovaps xmm0, [rsp]
00007d5be8fdd6dd  vmovaps xmm1, [rsp+0x10]
00007d5be8fdd6e3  vmovaps xmm2, [rsp+0x20]
00007d5be8fdd6e9  vmovaps xmm3, [rsp+0x30]
00007d5be8fdd6ef  vmovaps xmm4, [rsp+0x40]
00007d5be8fdd6f5  vmovaps xmm5, [rsp+0x50]
00007d5be8fdd6fb  vmovaps xmm6, [rsp+0x60]
00007d5be8fdd701  vmovaps xmm7, [rsp+0x70]
00007d5be8fdd707  vmovaps xmm8, [rsp+0x80]
00007d5be8fdd710  vmovaps xmm9, [rsp+0x90]
00007d5be8fdd719  vmovaps xmm10, [rsp+0xA0]
00007d5be8fdd722  vmovaps xmm11, [rsp+0xB0]
00007d5be8fdd72b  vmovaps xmm12, [rsp+0xC0]
00007d5be8fdd734  vmovaps xmm13, [rsp+0xD0]
00007d5be8fdd73d  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdd746  add rsp, 0xF0
00007d5be8fdd74d  pop r11
00007d5be8fdd74f  pop r10
00007d5be8fdd751  pop r9
00007d5be8fdd753  pop r8
00007d5be8fdd755  pop rsi
00007d5be8fdd756  pop rdi
00007d5be8fdd757  pop rdx
00007d5be8fdd758  pop rcx
00007d5be8fdd759  pop rax
00007d5be8fdd75a  add rsp, 0x08
00007d5be8fdd75e  jmp 0x00007D5BE8FDBE42
00007d5be8fdd763  sub rsp, 0x08
00007d5be8fdd767  push rax
00007d5be8fdd768  push rcx
00007d5be8fdd769  push rdx
00007d5be8fdd76a  push rdi
00007d5be8fdd76b  push rsi
00007d5be8fdd76c  push r8
00007d5be8fdd76e  push r9
00007d5be8fdd770  push r10
00007d5be8fdd772  push r11
00007d5be8fdd774  sub rsp, 0xF0
00007d5be8fdd77b  vmovaps [rsp], xmm0
00007d5be8fdd780  vmovaps [rsp+0x10], xmm1
00007d5be8fdd786  vmovaps [rsp+0x20], xmm2
00007d5be8fdd78c  vmovaps [rsp+0x30], xmm3
00007d5be8fdd792  vmovaps [rsp+0x40], xmm4
00007d5be8fdd798  vmovaps [rsp+0x50], xmm5
00007d5be8fdd79e  vmovaps [rsp+0x60], xmm7
00007d5be8fdd7a4  vmovaps [rsp+0x70], xmm8
00007d5be8fdd7aa  vmovaps [rsp+0x80], xmm9
00007d5be8fdd7b3  vmovaps [rsp+0x90], xmm10
00007d5be8fdd7bc  vmovaps [rsp+0xA0], xmm11
00007d5be8fdd7c5  vmovaps [rsp+0xB0], xmm12
00007d5be8fdd7ce  vmovaps [rsp+0xC0], xmm13
00007d5be8fdd7d7  vmovaps [rsp+0xD0], xmm14
00007d5be8fdd7e0  vmovaps [rsp+0xE0], xmm15
00007d5be8fdd7e9  sub rsp, 0x30
00007d5be8fdd7ed  movaps [rsp], xmm6
00007d5be8fdd7f1  movaps [rsp+0x10], xmm9
00007d5be8fdd7f7  movaps [rsp+0x20], xmm7
00007d5be8fdd7fc  lea rdi, [rsp]
00007d5be8fdd800  mov esi, 0x00
00007d5be8fdd805  mov rax, 0x5D345705A530
00007d5be8fdd80f  call rax
00007d5be8fdd811  movaps xmm6, [rsp]
00007d5be8fdd815  add rsp, 0x30
00007d5be8fdd819  vmovaps xmm0, [rsp]
00007d5be8fdd81e  vmovaps xmm1, [rsp+0x10]
00007d5be8fdd824  vmovaps xmm2, [rsp+0x20]
00007d5be8fdd82a  vmovaps xmm3, [rsp+0x30]
00007d5be8fdd830  vmovaps xmm4, [rsp+0x40]
00007d5be8fdd836  vmovaps xmm5, [rsp+0x50]
00007d5be8fdd83c  vmovaps xmm7, [rsp+0x60]
00007d5be8fdd842  vmovaps xmm8, [rsp+0x70]
00007d5be8fdd848  vmovaps xmm9, [rsp+0x80]
00007d5be8fdd851  vmovaps xmm10, [rsp+0x90]
00007d5be8fdd85a  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdd863  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdd86c  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdd875  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdd87e  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdd887  add rsp, 0xF0
00007d5be8fdd88e  pop r11
00007d5be8fdd890  pop r10
00007d5be8fdd892  pop r9
00007d5be8fdd894  pop r8
00007d5be8fdd896  pop rsi
00007d5be8fdd897  pop rdi
00007d5be8fdd898  pop rdx
00007d5be8fdd899  pop rcx
00007d5be8fdd89a  pop rax
00007d5be8fdd89b  add rsp, 0x08
00007d5be8fdd89f  jmp 0x00007D5BE8FDBE5A
00007d5be8fdd8a4  sub rsp, 0x08
00007d5be8fdd8a8  push rax
00007d5be8fdd8a9  push rcx
00007d5be8fdd8aa  push rdx
00007d5be8fdd8ab  push rdi
00007d5be8fdd8ac  push rsi
00007d5be8fdd8ad  push r8
00007d5be8fdd8af  push r9
00007d5be8fdd8b1  push r10
00007d5be8fdd8b3  push r11
00007d5be8fdd8b5  sub rsp, 0xF0
00007d5be8fdd8bc  vmovaps [rsp], xmm0
00007d5be8fdd8c1  vmovaps [rsp+0x10], xmm1
00007d5be8fdd8c7  vmovaps [rsp+0x20], xmm2
00007d5be8fdd8cd  vmovaps [rsp+0x30], xmm3
00007d5be8fdd8d3  vmovaps [rsp+0x40], xmm4
00007d5be8fdd8d9  vmovaps [rsp+0x50], xmm5
00007d5be8fdd8df  vmovaps [rsp+0x60], xmm6
00007d5be8fdd8e5  vmovaps [rsp+0x70], xmm8
00007d5be8fdd8eb  vmovaps [rsp+0x80], xmm9
00007d5be8fdd8f4  vmovaps [rsp+0x90], xmm10
00007d5be8fdd8fd  vmovaps [rsp+0xA0], xmm11
00007d5be8fdd906  vmovaps [rsp+0xB0], xmm12
00007d5be8fdd90f  vmovaps [rsp+0xC0], xmm13
00007d5be8fdd918  vmovaps [rsp+0xD0], xmm14
00007d5be8fdd921  vmovaps [rsp+0xE0], xmm15
00007d5be8fdd92a  sub rsp, 0x30
00007d5be8fdd92e  movaps [rsp], xmm7
00007d5be8fdd932  movaps [rsp+0x10], xmm4
00007d5be8fdd937  movaps [rsp+0x20], xmm9
00007d5be8fdd93d  lea rdi, [rsp]
00007d5be8fdd941  mov esi, 0x00
00007d5be8fdd946  mov rax, 0x5D345705A530
00007d5be8fdd950  call rax
00007d5be8fdd952  movaps xmm7, [rsp]
00007d5be8fdd956  add rsp, 0x30
00007d5be8fdd95a  vmovaps xmm0, [rsp]
00007d5be8fdd95f  vmovaps xmm1, [rsp+0x10]
00007d5be8fdd965  vmovaps xmm2, [rsp+0x20]
00007d5be8fdd96b  vmovaps xmm3, [rsp+0x30]
00007d5be8fdd971  vmovaps xmm4, [rsp+0x40]
00007d5be8fdd977  vmovaps xmm5, [rsp+0x50]
00007d5be8fdd97d  vmovaps xmm6, [rsp+0x60]
00007d5be8fdd983  vmovaps xmm8, [rsp+0x70]
00007d5be8fdd989  vmovaps xmm9, [rsp+0x80]
00007d5be8fdd992  vmovaps xmm10, [rsp+0x90]
00007d5be8fdd99b  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdd9a4  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdd9ad  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdd9b6  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdd9bf  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdd9c8  add rsp, 0xF0
00007d5be8fdd9cf  pop r11
00007d5be8fdd9d1  pop r10
00007d5be8fdd9d3  pop r9
00007d5be8fdd9d5  pop r8
00007d5be8fdd9d7  pop rsi
00007d5be8fdd9d8  pop rdi
00007d5be8fdd9d9  pop rdx
00007d5be8fdd9da  pop rcx
00007d5be8fdd9db  pop rax
00007d5be8fdd9dc  add rsp, 0x08
00007d5be8fdd9e0  jmp 0x00007D5BE8FDBE87
00007d5be8fdd9e5  sub rsp, 0x08
00007d5be8fdd9e9  push rax
00007d5be8fdd9ea  push rcx
00007d5be8fdd9eb  push rdx
00007d5be8fdd9ec  push rdi
00007d5be8fdd9ed  push rsi
00007d5be8fdd9ee  push r8
00007d5be8fdd9f0  push r9
00007d5be8fdd9f2  push r10
00007d5be8fdd9f4  push r11
00007d5be8fdd9f6  sub rsp, 0xF0
00007d5be8fdd9fd  vmovaps [rsp], xmm0
00007d5be8fdda02  vmovaps [rsp+0x10], xmm1
00007d5be8fdda08  vmovaps [rsp+0x20], xmm2
00007d5be8fdda0e  vmovaps [rsp+0x30], xmm3
00007d5be8fdda14  vmovaps [rsp+0x40], xmm5
00007d5be8fdda1a  vmovaps [rsp+0x50], xmm6
00007d5be8fdda20  vmovaps [rsp+0x60], xmm7
00007d5be8fdda26  vmovaps [rsp+0x70], xmm8
00007d5be8fdda2c  vmovaps [rsp+0x80], xmm9
00007d5be8fdda35  vmovaps [rsp+0x90], xmm10
00007d5be8fdda3e  vmovaps [rsp+0xA0], xmm11
00007d5be8fdda47  vmovaps [rsp+0xB0], xmm12
00007d5be8fdda50  vmovaps [rsp+0xC0], xmm13
00007d5be8fdda59  vmovaps [rsp+0xD0], xmm14
00007d5be8fdda62  vmovaps [rsp+0xE0], xmm15
00007d5be8fdda6b  sub rsp, 0x30
00007d5be8fdda6f  movaps [rsp], xmm4
00007d5be8fdda73  movaps [rsp+0x10], xmm15
00007d5be8fdda79  movaps [rsp+0x20], xmm9
00007d5be8fdda7f  lea rdi, [rsp]
00007d5be8fdda83  mov esi, 0x00
00007d5be8fdda88  mov rax, 0x5D345705A530
00007d5be8fdda92  call rax
00007d5be8fdda94  movaps xmm4, [rsp]
00007d5be8fdda98  add rsp, 0x30
00007d5be8fdda9c  vmovaps xmm0, [rsp]
00007d5be8fddaa1  vmovaps xmm1, [rsp+0x10]
00007d5be8fddaa7  vmovaps xmm2, [rsp+0x20]
00007d5be8fddaad  vmovaps xmm3, [rsp+0x30]
00007d5be8fddab3  vmovaps xmm5, [rsp+0x40]
00007d5be8fddab9  vmovaps xmm6, [rsp+0x50]
00007d5be8fddabf  vmovaps xmm7, [rsp+0x60]
00007d5be8fddac5  vmovaps xmm8, [rsp+0x70]
00007d5be8fddacb  vmovaps xmm9, [rsp+0x80]
00007d5be8fddad4  vmovaps xmm10, [rsp+0x90]
00007d5be8fddadd  vmovaps xmm11, [rsp+0xA0]
00007d5be8fddae6  vmovaps xmm12, [rsp+0xB0]
00007d5be8fddaef  vmovaps xmm13, [rsp+0xC0]
00007d5be8fddaf8  vmovaps xmm14, [rsp+0xD0]
00007d5be8fddb01  vmovaps xmm15, [rsp+0xE0]
00007d5be8fddb0a  add rsp, 0xF0
00007d5be8fddb11  pop r11
00007d5be8fddb13  pop r10
00007d5be8fddb15  pop r9
00007d5be8fddb17  pop r8
00007d5be8fddb19  pop rsi
00007d5be8fddb1a  pop rdi
00007d5be8fddb1b  pop rdx
00007d5be8fddb1c  pop rcx
00007d5be8fddb1d  pop rax
00007d5be8fddb1e  add rsp, 0x08
00007d5be8fddb22  jmp 0x00007D5BE8FDBEAC
00007d5be8fddb27  call 0x00007D5BE8EC4620
00007d5be8fddb2c  jmp 0x00007D5BE8FDBEB9
00007d5be8fddb31  sub rsp, 0x08
00007d5be8fddb35  push rax
00007d5be8fddb36  push rcx
00007d5be8fddb37  push rdx
00007d5be8fddb38  push rdi
00007d5be8fddb39  push rsi
00007d5be8fddb3a  push r8
00007d5be8fddb3c  push r9
00007d5be8fddb3e  push r10
00007d5be8fddb40  push r11
00007d5be8fddb42  sub rsp, 0xF0
00007d5be8fddb49  vmovaps [rsp], xmm0
00007d5be8fddb4e  vmovaps [rsp+0x10], xmm1
00007d5be8fddb54  vmovaps [rsp+0x20], xmm2
00007d5be8fddb5a  vmovaps [rsp+0x30], xmm4
00007d5be8fddb60  vmovaps [rsp+0x40], xmm5
00007d5be8fddb66  vmovaps [rsp+0x50], xmm6
00007d5be8fddb6c  vmovaps [rsp+0x60], xmm7
00007d5be8fddb72  vmovaps [rsp+0x70], xmm8
00007d5be8fddb78  vmovaps [rsp+0x80], xmm9
00007d5be8fddb81  vmovaps [rsp+0x90], xmm10
00007d5be8fddb8a  vmovaps [rsp+0xA0], xmm11
00007d5be8fddb93  vmovaps [rsp+0xB0], xmm12
00007d5be8fddb9c  vmovaps [rsp+0xC0], xmm13
00007d5be8fddba5  vmovaps [rsp+0xD0], xmm14
00007d5be8fddbae  vmovaps [rsp+0xE0], xmm15
00007d5be8fddbb7  sub rsp, 0x30
00007d5be8fddbbb  movaps [rsp], xmm3
00007d5be8fddbbf  movaps [rsp+0x10], xmm1
00007d5be8fddbc4  movaps [rsp+0x20], xmm9
00007d5be8fddbca  lea rdi, [rsp]
00007d5be8fddbce  mov esi, 0x00
00007d5be8fddbd3  mov rax, 0x5D345705A530
00007d5be8fddbdd  call rax
00007d5be8fddbdf  movaps xmm3, [rsp]
00007d5be8fddbe3  add rsp, 0x30
00007d5be8fddbe7  vmovaps xmm0, [rsp]
00007d5be8fddbec  vmovaps xmm1, [rsp+0x10]
00007d5be8fddbf2  vmovaps xmm2, [rsp+0x20]
00007d5be8fddbf8  vmovaps xmm4, [rsp+0x30]
00007d5be8fddbfe  vmovaps xmm5, [rsp+0x40]
00007d5be8fddc04  vmovaps xmm6, [rsp+0x50]
00007d5be8fddc0a  vmovaps xmm7, [rsp+0x60]
00007d5be8fddc10  vmovaps xmm8, [rsp+0x70]
00007d5be8fddc16  vmovaps xmm9, [rsp+0x80]
00007d5be8fddc1f  vmovaps xmm10, [rsp+0x90]
00007d5be8fddc28  vmovaps xmm11, [rsp+0xA0]
00007d5be8fddc31  vmovaps xmm12, [rsp+0xB0]
00007d5be8fddc3a  vmovaps xmm13, [rsp+0xC0]
00007d5be8fddc43  vmovaps xmm14, [rsp+0xD0]
00007d5be8fddc4c  vmovaps xmm15, [rsp+0xE0]
00007d5be8fddc55  add rsp, 0xF0
00007d5be8fddc5c  pop r11
00007d5be8fddc5e  pop r10
00007d5be8fddc60  pop r9
00007d5be8fddc62  pop r8
00007d5be8fddc64  pop rsi
00007d5be8fddc65  pop rdi
00007d5be8fddc66  pop rdx
00007d5be8fddc67  pop rcx
00007d5be8fddc68  pop rax
00007d5be8fddc69  add rsp, 0x08
00007d5be8fddc6d  jmp 0x00007D5BE8FDBEF6
00007d5be8fddc72  sub rsp, 0x08
00007d5be8fddc76  push rax
00007d5be8fddc77  push rcx
00007d5be8fddc78  push rdx
00007d5be8fddc79  push rdi
00007d5be8fddc7a  push rsi
00007d5be8fddc7b  push r8
00007d5be8fddc7d  push r9
00007d5be8fddc7f  push r10
00007d5be8fddc81  push r11
00007d5be8fddc83  sub rsp, 0xF0
00007d5be8fddc8a  vmovaps [rsp], xmm0
00007d5be8fddc8f  vmovaps [rsp+0x10], xmm2
00007d5be8fddc95  vmovaps [rsp+0x20], xmm3
00007d5be8fddc9b  vmovaps [rsp+0x30], xmm4
00007d5be8fddca1  vmovaps [rsp+0x40], xmm5
00007d5be8fddca7  vmovaps [rsp+0x50], xmm6
00007d5be8fddcad  vmovaps [rsp+0x60], xmm7
00007d5be8fddcb3  vmovaps [rsp+0x70], xmm8
00007d5be8fddcb9  vmovaps [rsp+0x80], xmm9
00007d5be8fddcc2  vmovaps [rsp+0x90], xmm10
00007d5be8fddccb  vmovaps [rsp+0xA0], xmm11
00007d5be8fddcd4  vmovaps [rsp+0xB0], xmm12
00007d5be8fddcdd  vmovaps [rsp+0xC0], xmm13
00007d5be8fddce6  vmovaps [rsp+0xD0], xmm14
00007d5be8fddcef  vmovaps [rsp+0xE0], xmm15
00007d5be8fddcf8  sub rsp, 0x30
00007d5be8fddcfc  movaps [rsp], xmm1
00007d5be8fddd00  movaps [rsp+0x10], xmm15
00007d5be8fddd06  movaps [rsp+0x20], xmm9
00007d5be8fddd0c  lea rdi, [rsp]
00007d5be8fddd10  mov esi, 0x00
00007d5be8fddd15  mov rax, 0x5D345705A530
00007d5be8fddd1f  call rax
00007d5be8fddd21  movaps xmm1, [rsp]
00007d5be8fddd25  add rsp, 0x30
00007d5be8fddd29  vmovaps xmm0, [rsp]
00007d5be8fddd2e  vmovaps xmm2, [rsp+0x10]
00007d5be8fddd34  vmovaps xmm3, [rsp+0x20]
00007d5be8fddd3a  vmovaps xmm4, [rsp+0x30]
00007d5be8fddd40  vmovaps xmm5, [rsp+0x40]
00007d5be8fddd46  vmovaps xmm6, [rsp+0x50]
00007d5be8fddd4c  vmovaps xmm7, [rsp+0x60]
00007d5be8fddd52  vmovaps xmm8, [rsp+0x70]
00007d5be8fddd58  vmovaps xmm9, [rsp+0x80]
00007d5be8fddd61  vmovaps xmm10, [rsp+0x90]
00007d5be8fddd6a  vmovaps xmm11, [rsp+0xA0]
00007d5be8fddd73  vmovaps xmm12, [rsp+0xB0]
00007d5be8fddd7c  vmovaps xmm13, [rsp+0xC0]
00007d5be8fddd85  vmovaps xmm14, [rsp+0xD0]
00007d5be8fddd8e  vmovaps xmm15, [rsp+0xE0]
00007d5be8fddd97  add rsp, 0xF0
00007d5be8fddd9e  pop r11
00007d5be8fddda0  pop r10
00007d5be8fddda2  pop r9
00007d5be8fddda4  pop r8
00007d5be8fddda6  pop rsi
00007d5be8fddda7  pop rdi
00007d5be8fddda8  pop rdx
00007d5be8fddda9  pop rcx
00007d5be8fdddaa  pop rax
00007d5be8fdddab  add rsp, 0x08
00007d5be8fdddaf  jmp 0x00007D5BE8FDBF7E
00007d5be8fdddb4  call 0x00007D5BE8EC4620
00007d5be8fdddb9  jmp 0x00007D5BE8FDBF8B
00007d5be8fdddbe  sub rsp, 0x08
00007d5be8fdddc2  push rax
00007d5be8fdddc3  push rcx
00007d5be8fdddc4  push rdx
00007d5be8fdddc5  push rdi
00007d5be8fdddc6  push rsi
00007d5be8fdddc7  push r8
00007d5be8fdddc9  push r9
00007d5be8fdddcb  push r10
00007d5be8fdddcd  push r11
00007d5be8fdddcf  sub rsp, 0xF0
00007d5be8fdddd6  vmovaps [rsp], xmm0
00007d5be8fddddb  vmovaps [rsp+0x10], xmm2
00007d5be8fddde1  vmovaps [rsp+0x20], xmm3
00007d5be8fddde7  vmovaps [rsp+0x30], xmm4
00007d5be8fddded  vmovaps [rsp+0x40], xmm5
00007d5be8fdddf3  vmovaps [rsp+0x50], xmm6
00007d5be8fdddf9  vmovaps [rsp+0x60], xmm7
00007d5be8fdddff  vmovaps [rsp+0x70], xmm8
00007d5be8fdde05  vmovaps [rsp+0x80], xmm9
00007d5be8fdde0e  vmovaps [rsp+0x90], xmm10
00007d5be8fdde17  vmovaps [rsp+0xA0], xmm11
00007d5be8fdde20  vmovaps [rsp+0xB0], xmm12
00007d5be8fdde29  vmovaps [rsp+0xC0], xmm13
00007d5be8fdde32  vmovaps [rsp+0xD0], xmm14
00007d5be8fdde3b  vmovaps [rsp+0xE0], xmm15
00007d5be8fdde44  sub rsp, 0x30
00007d5be8fdde48  movaps [rsp], xmm1
00007d5be8fdde4c  movaps [rsp+0x10], xmm5
00007d5be8fdde51  movaps [rsp+0x20], xmm7
00007d5be8fdde56  lea rdi, [rsp]
00007d5be8fdde5a  mov esi, 0x00
00007d5be8fdde5f  mov rax, 0x5D345705A530
00007d5be8fdde69  call rax
00007d5be8fdde6b  movaps xmm1, [rsp]
00007d5be8fdde6f  add rsp, 0x30
00007d5be8fdde73  vmovaps xmm0, [rsp]
00007d5be8fdde78  vmovaps xmm2, [rsp+0x10]
00007d5be8fdde7e  vmovaps xmm3, [rsp+0x20]
00007d5be8fdde84  vmovaps xmm4, [rsp+0x30]
00007d5be8fdde8a  vmovaps xmm5, [rsp+0x40]
00007d5be8fdde90  vmovaps xmm6, [rsp+0x50]
00007d5be8fdde96  vmovaps xmm7, [rsp+0x60]
00007d5be8fdde9c  vmovaps xmm8, [rsp+0x70]
00007d5be8fddea2  vmovaps xmm9, [rsp+0x80]
00007d5be8fddeab  vmovaps xmm10, [rsp+0x90]
00007d5be8fddeb4  vmovaps xmm11, [rsp+0xA0]
00007d5be8fddebd  vmovaps xmm12, [rsp+0xB0]
00007d5be8fddec6  vmovaps xmm13, [rsp+0xC0]
00007d5be8fddecf  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdded8  vmovaps xmm15, [rsp+0xE0]
00007d5be8fddee1  add rsp, 0xF0
00007d5be8fddee8  pop r11
00007d5be8fddeea  pop r10
00007d5be8fddeec  pop r9
00007d5be8fddeee  pop r8
00007d5be8fddef0  pop rsi
00007d5be8fddef1  pop rdi
00007d5be8fddef2  pop rdx
00007d5be8fddef3  pop rcx
00007d5be8fddef4  pop rax
00007d5be8fddef5  add rsp, 0x08
00007d5be8fddef9  jmp 0x00007D5BE8FDC030
00007d5be8fddefe  sub rsp, 0x08
00007d5be8fddf02  push rax
00007d5be8fddf03  push rcx
00007d5be8fddf04  push rdx
00007d5be8fddf05  push rdi
00007d5be8fddf06  push rsi
00007d5be8fddf07  push r8
00007d5be8fddf09  push r9
00007d5be8fddf0b  push r10
00007d5be8fddf0d  push r11
00007d5be8fddf0f  sub rsp, 0xF0
00007d5be8fddf16  vmovaps [rsp], xmm0
00007d5be8fddf1b  vmovaps [rsp+0x10], xmm1
00007d5be8fddf21  vmovaps [rsp+0x20], xmm2
00007d5be8fddf27  vmovaps [rsp+0x30], xmm3
00007d5be8fddf2d  vmovaps [rsp+0x40], xmm4
00007d5be8fddf33  vmovaps [rsp+0x50], xmm5
00007d5be8fddf39  vmovaps [rsp+0x60], xmm6
00007d5be8fddf3f  vmovaps [rsp+0x70], xmm8
00007d5be8fddf45  vmovaps [rsp+0x80], xmm9
00007d5be8fddf4e  vmovaps [rsp+0x90], xmm10
00007d5be8fddf57  vmovaps [rsp+0xA0], xmm11
00007d5be8fddf60  vmovaps [rsp+0xB0], xmm12
00007d5be8fddf69  vmovaps [rsp+0xC0], xmm13
00007d5be8fddf72  vmovaps [rsp+0xD0], xmm14
00007d5be8fddf7b  vmovaps [rsp+0xE0], xmm15
00007d5be8fddf84  sub rsp, 0x30
00007d5be8fddf88  movaps [rsp], xmm7
00007d5be8fddf8c  movaps [rsp+0x10], xmm5
00007d5be8fddf91  movaps [rsp+0x20], xmm15
00007d5be8fddf97  lea rdi, [rsp]
00007d5be8fddf9b  mov esi, 0x00
00007d5be8fddfa0  mov rax, 0x5D345705A530
00007d5be8fddfaa  call rax
00007d5be8fddfac  movaps xmm7, [rsp]
00007d5be8fddfb0  add rsp, 0x30
00007d5be8fddfb4  vmovaps xmm0, [rsp]
00007d5be8fddfb9  vmovaps xmm1, [rsp+0x10]
00007d5be8fddfbf  vmovaps xmm2, [rsp+0x20]
00007d5be8fddfc5  vmovaps xmm3, [rsp+0x30]
00007d5be8fddfcb  vmovaps xmm4, [rsp+0x40]
00007d5be8fddfd1  vmovaps xmm5, [rsp+0x50]
00007d5be8fddfd7  vmovaps xmm6, [rsp+0x60]
00007d5be8fddfdd  vmovaps xmm8, [rsp+0x70]
00007d5be8fddfe3  vmovaps xmm9, [rsp+0x80]
00007d5be8fddfec  vmovaps xmm10, [rsp+0x90]
00007d5be8fddff5  vmovaps xmm11, [rsp+0xA0]
00007d5be8fddffe  vmovaps xmm12, [rsp+0xB0]
00007d5be8fde007  vmovaps xmm13, [rsp+0xC0]
00007d5be8fde010  vmovaps xmm14, [rsp+0xD0]
00007d5be8fde019  vmovaps xmm15, [rsp+0xE0]
00007d5be8fde022  add rsp, 0xF0
00007d5be8fde029  pop r11
00007d5be8fde02b  pop r10
00007d5be8fde02d  pop r9
00007d5be8fde02f  pop r8
00007d5be8fde031  pop rsi
00007d5be8fde032  pop rdi
00007d5be8fde033  pop rdx
00007d5be8fde034  pop rcx
00007d5be8fde035  pop rax
00007d5be8fde036  add rsp, 0x08
00007d5be8fde03a  jmp 0x00007D5BE8FDC066
00007d5be8fde03f  call 0x00007D5BE8EB52F0
00007d5be8fde044  jmp 0x00007D5BE8FDC073
00007d5be8fde049  sub rsp, 0x08
00007d5be8fde04d  push rax
00007d5be8fde04e  push rcx
00007d5be8fde04f  push rdx
00007d5be8fde050  push rdi
00007d5be8fde051  push rsi
00007d5be8fde052  push r8
00007d5be8fde054  push r9
00007d5be8fde056  push r10
00007d5be8fde058  push r11
00007d5be8fde05a  sub rsp, 0xF0
00007d5be8fde061  vmovaps [rsp], xmm0
00007d5be8fde066  vmovaps [rsp+0x10], xmm1
00007d5be8fde06c  vmovaps [rsp+0x20], xmm2
00007d5be8fde072  vmovaps [rsp+0x30], xmm3
00007d5be8fde078  vmovaps [rsp+0x40], xmm4
00007d5be8fde07e  vmovaps [rsp+0x50], xmm5
00007d5be8fde084  vmovaps [rsp+0x60], xmm6
00007d5be8fde08a  vmovaps [rsp+0x70], xmm7
00007d5be8fde090  vmovaps [rsp+0x80], xmm8
00007d5be8fde099  vmovaps [rsp+0x90], xmm9
00007d5be8fde0a2  vmovaps [rsp+0xA0], xmm10
00007d5be8fde0ab  vmovaps [rsp+0xB0], xmm11
00007d5be8fde0b4  vmovaps [rsp+0xC0], xmm12
00007d5be8fde0bd  vmovaps [rsp+0xD0], xmm13
00007d5be8fde0c6  vmovaps [rsp+0xE0], xmm14
00007d5be8fde0cf  sub rsp, 0x30
00007d5be8fde0d3  movaps [rsp], xmm15
00007d5be8fde0d8  movaps [rsp+0x10], xmm5
00007d5be8fde0dd  movaps [rsp+0x20], xmm3
00007d5be8fde0e2  lea rdi, [rsp]
00007d5be8fde0e6  mov esi, 0x00
00007d5be8fde0eb  mov rax, 0x5D345705A530
00007d5be8fde0f5  call rax
00007d5be8fde0f7  movaps xmm15, [rsp]
00007d5be8fde0fc  add rsp, 0x30
00007d5be8fde100  vmovaps xmm0, [rsp]
00007d5be8fde105  vmovaps xmm1, [rsp+0x10]
00007d5be8fde10b  vmovaps xmm2, [rsp+0x20]
00007d5be8fde111  vmovaps xmm3, [rsp+0x30]
00007d5be8fde117  vmovaps xmm4, [rsp+0x40]
00007d5be8fde11d  vmovaps xmm5, [rsp+0x50]
00007d5be8fde123  vmovaps xmm6, [rsp+0x60]
00007d5be8fde129  vmovaps xmm7, [rsp+0x70]
00007d5be8fde12f  vmovaps xmm8, [rsp+0x80]
00007d5be8fde138  vmovaps xmm9, [rsp+0x90]
00007d5be8fde141  vmovaps xmm10, [rsp+0xA0]
00007d5be8fde14a  vmovaps xmm11, [rsp+0xB0]
00007d5be8fde153  vmovaps xmm12, [rsp+0xC0]
00007d5be8fde15c  vmovaps xmm13, [rsp+0xD0]
00007d5be8fde165  vmovaps xmm14, [rsp+0xE0]
00007d5be8fde16e  add rsp, 0xF0
00007d5be8fde175  pop r11
00007d5be8fde177  pop r10
00007d5be8fde179  pop r9
00007d5be8fde17b  pop r8
00007d5be8fde17d  pop rsi
00007d5be8fde17e  pop rdi
00007d5be8fde17f  pop rdx
00007d5be8fde180  pop rcx
00007d5be8fde181  pop rax
00007d5be8fde182  add rsp, 0x08
00007d5be8fde186  jmp 0x00007D5BE8FDC099
00007d5be8fde18b  sub rsp, 0x08
00007d5be8fde18f  push rax
00007d5be8fde190  push rcx
00007d5be8fde191  push rdx
00007d5be8fde192  push rdi
00007d5be8fde193  push rsi
00007d5be8fde194  push r8
00007d5be8fde196  push r9
00007d5be8fde198  push r10
00007d5be8fde19a  push r11
00007d5be8fde19c  sub rsp, 0xF0
00007d5be8fde1a3  vmovaps [rsp], xmm0
00007d5be8fde1a8  vmovaps [rsp+0x10], xmm2
00007d5be8fde1ae  vmovaps [rsp+0x20], xmm3
00007d5be8fde1b4  vmovaps [rsp+0x30], xmm4
00007d5be8fde1ba  vmovaps [rsp+0x40], xmm5
00007d5be8fde1c0  vmovaps [rsp+0x50], xmm6
00007d5be8fde1c6  vmovaps [rsp+0x60], xmm7
00007d5be8fde1cc  vmovaps [rsp+0x70], xmm8
00007d5be8fde1d2  vmovaps [rsp+0x80], xmm9
00007d5be8fde1db  vmovaps [rsp+0x90], xmm10
00007d5be8fde1e4  vmovaps [rsp+0xA0], xmm11
00007d5be8fde1ed  vmovaps [rsp+0xB0], xmm12
00007d5be8fde1f6  vmovaps [rsp+0xC0], xmm13
00007d5be8fde1ff  vmovaps [rsp+0xD0], xmm14
00007d5be8fde208  vmovaps [rsp+0xE0], xmm15
00007d5be8fde211  sub rsp, 0x30
00007d5be8fde215  movaps [rsp], xmm1
00007d5be8fde219  movaps [rsp+0x10], xmm5
00007d5be8fde21e  movaps [rsp+0x20], xmm4
00007d5be8fde223  lea rdi, [rsp]
00007d5be8fde227  mov esi, 0x00
00007d5be8fde22c  mov rax, 0x5D345705A530
00007d5be8fde236  call rax
00007d5be8fde238  movaps xmm1, [rsp]
00007d5be8fde23c  add rsp, 0x30
00007d5be8fde240  vmovaps xmm0, [rsp]
00007d5be8fde245  vmovaps xmm2, [rsp+0x10]
00007d5be8fde24b  vmovaps xmm3, [rsp+0x20]
00007d5be8fde251  vmovaps xmm4, [rsp+0x30]
00007d5be8fde257  vmovaps xmm5, [rsp+0x40]
00007d5be8fde25d  vmovaps xmm6, [rsp+0x50]
00007d5be8fde263  vmovaps xmm7, [rsp+0x60]
00007d5be8fde269  vmovaps xmm8, [rsp+0x70]
00007d5be8fde26f  vmovaps xmm9, [rsp+0x80]
00007d5be8fde278  vmovaps xmm10, [rsp+0x90]
00007d5be8fde281  vmovaps xmm11, [rsp+0xA0]
00007d5be8fde28a  vmovaps xmm12, [rsp+0xB0]
00007d5be8fde293  vmovaps xmm13, [rsp+0xC0]
00007d5be8fde29c  vmovaps xmm14, [rsp+0xD0]
00007d5be8fde2a5  vmovaps xmm15, [rsp+0xE0]
00007d5be8fde2ae  add rsp, 0xF0
00007d5be8fde2b5  pop r11
00007d5be8fde2b7  pop r10
00007d5be8fde2b9  pop r9
00007d5be8fde2bb  pop r8
00007d5be8fde2bd  pop rsi
00007d5be8fde2be  pop rdi
00007d5be8fde2bf  pop rdx
00007d5be8fde2c0  pop rcx
00007d5be8fde2c1  pop rax
00007d5be8fde2c2  add rsp, 0x08
00007d5be8fde2c6  jmp 0x00007D5BE8FDC0B9
00007d5be8fde2cb  sub rsp, 0x08
00007d5be8fde2cf  push rax
00007d5be8fde2d0  push rcx
00007d5be8fde2d1  push rdx
00007d5be8fde2d2  push rdi
00007d5be8fde2d3  push rsi
00007d5be8fde2d4  push r8
00007d5be8fde2d6  push r9
00007d5be8fde2d8  push r10
00007d5be8fde2da  push r11
00007d5be8fde2dc  sub rsp, 0xF0
00007d5be8fde2e3  vmovaps [rsp], xmm0
00007d5be8fde2e8  vmovaps [rsp+0x10], xmm1
00007d5be8fde2ee  vmovaps [rsp+0x20], xmm2
00007d5be8fde2f4  vmovaps [rsp+0x30], xmm3
00007d5be8fde2fa  vmovaps [rsp+0x40], xmm5
00007d5be8fde300  vmovaps [rsp+0x50], xmm6
00007d5be8fde306  vmovaps [rsp+0x60], xmm7
00007d5be8fde30c  vmovaps [rsp+0x70], xmm8
00007d5be8fde312  vmovaps [rsp+0x80], xmm9
00007d5be8fde31b  vmovaps [rsp+0x90], xmm10
00007d5be8fde324  vmovaps [rsp+0xA0], xmm11
00007d5be8fde32d  vmovaps [rsp+0xB0], xmm12
00007d5be8fde336  vmovaps [rsp+0xC0], xmm13
00007d5be8fde33f  vmovaps [rsp+0xD0], xmm14
00007d5be8fde348  vmovaps [rsp+0xE0], xmm15
00007d5be8fde351  sub rsp, 0x30
00007d5be8fde355  movaps [rsp], xmm4
00007d5be8fde359  movaps [rsp+0x10], xmm3
00007d5be8fde35e  movaps [rsp+0x20], xmm5
00007d5be8fde363  lea rdi, [rsp]
00007d5be8fde367  mov esi, 0x00
00007d5be8fde36c  mov rax, 0x5D345705A530
00007d5be8fde376  call rax
00007d5be8fde378  movaps xmm4, [rsp]
00007d5be8fde37c  add rsp, 0x30
00007d5be8fde380  vmovaps xmm0, [rsp]
00007d5be8fde385  vmovaps xmm1, [rsp+0x10]
00007d5be8fde38b  vmovaps xmm2, [rsp+0x20]
00007d5be8fde391  vmovaps xmm3, [rsp+0x30]
00007d5be8fde397  vmovaps xmm5, [rsp+0x40]
00007d5be8fde39d  vmovaps xmm6, [rsp+0x50]
00007d5be8fde3a3  vmovaps xmm7, [rsp+0x60]
00007d5be8fde3a9  vmovaps xmm8, [rsp+0x70]
00007d5be8fde3af  vmovaps xmm9, [rsp+0x80]
00007d5be8fde3b8  vmovaps xmm10, [rsp+0x90]
00007d5be8fde3c1  vmovaps xmm11, [rsp+0xA0]
00007d5be8fde3ca  vmovaps xmm12, [rsp+0xB0]
00007d5be8fde3d3  vmovaps xmm13, [rsp+0xC0]
00007d5be8fde3dc  vmovaps xmm14, [rsp+0xD0]
00007d5be8fde3e5  vmovaps xmm15, [rsp+0xE0]
00007d5be8fde3ee  add rsp, 0xF0
00007d5be8fde3f5  pop r11
00007d5be8fde3f7  pop r10
00007d5be8fde3f9  pop r9
00007d5be8fde3fb  pop r8
00007d5be8fde3fd  pop rsi
00007d5be8fde3fe  pop rdi
00007d5be8fde3ff  pop rdx
00007d5be8fde400  pop rcx
00007d5be8fde401  pop rax
00007d5be8fde402  add rsp, 0x08
00007d5be8fde406  jmp 0x00007D5BE8FDC107
00007d5be8fde40b  call 0x00007D5BE8EB52F0
00007d5be8fde410  jmp 0x00007D5BE8FDC114
00007d5be8fde415  sub rsp, 0x08
00007d5be8fde419  push rax
00007d5be8fde41a  push rcx
00007d5be8fde41b  push rdx
00007d5be8fde41c  push rdi
00007d5be8fde41d  push rsi
00007d5be8fde41e  push r8
00007d5be8fde420  push r9
00007d5be8fde422  push r10
00007d5be8fde424  push r11
00007d5be8fde426  sub rsp, 0xF0
00007d5be8fde42d  vmovaps [rsp], xmm0
00007d5be8fde432  vmovaps [rsp+0x10], xmm1
00007d5be8fde438  vmovaps [rsp+0x20], xmm2
00007d5be8fde43e  vmovaps [rsp+0x30], xmm3
00007d5be8fde444  vmovaps [rsp+0x40], xmm4
00007d5be8fde44a  vmovaps [rsp+0x50], xmm6
00007d5be8fde450  vmovaps [rsp+0x60], xmm7
00007d5be8fde456  vmovaps [rsp+0x70], xmm8
00007d5be8fde45c  vmovaps [rsp+0x80], xmm9
00007d5be8fde465  vmovaps [rsp+0x90], xmm10
00007d5be8fde46e  vmovaps [rsp+0xA0], xmm11
00007d5be8fde477  vmovaps [rsp+0xB0], xmm12
00007d5be8fde480  vmovaps [rsp+0xC0], xmm13
00007d5be8fde489  vmovaps [rsp+0xD0], xmm14
00007d5be8fde492  vmovaps [rsp+0xE0], xmm15
00007d5be8fde49b  sub rsp, 0x30
00007d5be8fde49f  movaps [rsp], xmm5
00007d5be8fde4a3  movaps [rsp+0x10], xmm6
00007d5be8fde4a8  movaps [rsp+0x20], xmm3
00007d5be8fde4ad  lea rdi, [rsp]
00007d5be8fde4b1  mov esi, 0x00
00007d5be8fde4b6  mov rax, 0x5D345705A530
00007d5be8fde4c0  call rax
00007d5be8fde4c2  movaps xmm5, [rsp]
00007d5be8fde4c6  add rsp, 0x30
00007d5be8fde4ca  vmovaps xmm0, [rsp]
00007d5be8fde4cf  vmovaps xmm1, [rsp+0x10]
00007d5be8fde4d5  vmovaps xmm2, [rsp+0x20]
00007d5be8fde4db  vmovaps xmm3, [rsp+0x30]
00007d5be8fde4e1  vmovaps xmm4, [rsp+0x40]
00007d5be8fde4e7  vmovaps xmm6, [rsp+0x50]
00007d5be8fde4ed  vmovaps xmm7, [rsp+0x60]
00007d5be8fde4f3  vmovaps xmm8, [rsp+0x70]
00007d5be8fde4f9  vmovaps xmm9, [rsp+0x80]
00007d5be8fde502  vmovaps xmm10, [rsp+0x90]
00007d5be8fde50b  vmovaps xmm11, [rsp+0xA0]
00007d5be8fde514  vmovaps xmm12, [rsp+0xB0]
00007d5be8fde51d  vmovaps xmm13, [rsp+0xC0]
00007d5be8fde526  vmovaps xmm14, [rsp+0xD0]
00007d5be8fde52f  vmovaps xmm15, [rsp+0xE0]
00007d5be8fde538  add rsp, 0xF0
00007d5be8fde53f  pop r11
00007d5be8fde541  pop r10
00007d5be8fde543  pop r9
00007d5be8fde545  pop r8
00007d5be8fde547  pop rsi
00007d5be8fde548  pop rdi
00007d5be8fde549  pop rdx
00007d5be8fde54a  pop rcx
00007d5be8fde54b  pop rax
00007d5be8fde54c  add rsp, 0x08
00007d5be8fde550  jmp 0x00007D5BE8FDC13A
00007d5be8fde555  sub rsp, 0x08
00007d5be8fde559  push rax
00007d5be8fde55a  push rcx
00007d5be8fde55b  push rdx
00007d5be8fde55c  push rdi
00007d5be8fde55d  push rsi
00007d5be8fde55e  push r8
00007d5be8fde560  push r9
00007d5be8fde562  push r10
00007d5be8fde564  push r11
00007d5be8fde566  sub rsp, 0xF0
00007d5be8fde56d  vmovaps [rsp], xmm0
00007d5be8fde572  vmovaps [rsp+0x10], xmm1
00007d5be8fde578  vmovaps [rsp+0x20], xmm2
00007d5be8fde57e  vmovaps [rsp+0x30], xmm3
00007d5be8fde584  vmovaps [rsp+0x40], xmm4
00007d5be8fde58a  vmovaps [rsp+0x50], xmm5
00007d5be8fde590  vmovaps [rsp+0x60], xmm7
00007d5be8fde596  vmovaps [rsp+0x70], xmm8
00007d5be8fde59c  vmovaps [rsp+0x80], xmm9
00007d5be8fde5a5  vmovaps [rsp+0x90], xmm10
00007d5be8fde5ae  vmovaps [rsp+0xA0], xmm11
00007d5be8fde5b7  vmovaps [rsp+0xB0], xmm12
00007d5be8fde5c0  vmovaps [rsp+0xC0], xmm13
00007d5be8fde5c9  vmovaps [rsp+0xD0], xmm14
00007d5be8fde5d2  vmovaps [rsp+0xE0], xmm15
00007d5be8fde5db  sub rsp, 0x30
00007d5be8fde5df  movaps [rsp], xmm6
00007d5be8fde5e3  movaps [rsp+0x10], xmm9
00007d5be8fde5e9  movaps [rsp+0x20], xmm1
00007d5be8fde5ee  lea rdi, [rsp]
00007d5be8fde5f2  mov esi, 0x00
00007d5be8fde5f7  mov rax, 0x5D345705A530
00007d5be8fde601  call rax
00007d5be8fde603  movaps xmm6, [rsp]
00007d5be8fde607  add rsp, 0x30
00007d5be8fde60b  vmovaps xmm0, [rsp]
00007d5be8fde610  vmovaps xmm1, [rsp+0x10]
00007d5be8fde616  vmovaps xmm2, [rsp+0x20]
00007d5be8fde61c  vmovaps xmm3, [rsp+0x30]
00007d5be8fde622  vmovaps xmm4, [rsp+0x40]
00007d5be8fde628  vmovaps xmm5, [rsp+0x50]
00007d5be8fde62e  vmovaps xmm7, [rsp+0x60]
00007d5be8fde634  vmovaps xmm8, [rsp+0x70]
00007d5be8fde63a  vmovaps xmm9, [rsp+0x80]
00007d5be8fde643  vmovaps xmm10, [rsp+0x90]
00007d5be8fde64c  vmovaps xmm11, [rsp+0xA0]
00007d5be8fde655  vmovaps xmm12, [rsp+0xB0]
00007d5be8fde65e  vmovaps xmm13, [rsp+0xC0]
00007d5be8fde667  vmovaps xmm14, [rsp+0xD0]
00007d5be8fde670  vmovaps xmm15, [rsp+0xE0]
00007d5be8fde679  add rsp, 0xF0
00007d5be8fde680  pop r11
00007d5be8fde682  pop r10
00007d5be8fde684  pop r9
00007d5be8fde686  pop r8
00007d5be8fde688  pop rsi
00007d5be8fde689  pop rdi
00007d5be8fde68a  pop rdx
00007d5be8fde68b  pop rcx
00007d5be8fde68c  pop rax
00007d5be8fde68d  add rsp, 0x08
00007d5be8fde691  jmp 0x00007D5BE8FDC15E
00007d5be8fde696  sub rsp, 0x08
00007d5be8fde69a  push rax
00007d5be8fde69b  push rcx
00007d5be8fde69c  push rdx
00007d5be8fde69d  push rdi
00007d5be8fde69e  push rsi
00007d5be8fde69f  push r8
00007d5be8fde6a1  push r9
00007d5be8fde6a3  push r10
00007d5be8fde6a5  push r11
00007d5be8fde6a7  sub rsp, 0xF0
00007d5be8fde6ae  vmovaps [rsp], xmm0
00007d5be8fde6b3  vmovaps [rsp+0x10], xmm1
00007d5be8fde6b9  vmovaps [rsp+0x20], xmm2
00007d5be8fde6bf  vmovaps [rsp+0x30], xmm3
00007d5be8fde6c5  vmovaps [rsp+0x40], xmm4
00007d5be8fde6cb  vmovaps [rsp+0x50], xmm5
00007d5be8fde6d1  vmovaps [rsp+0x60], xmm6
00007d5be8fde6d7  vmovaps [rsp+0x70], xmm7
00007d5be8fde6dd  vmovaps [rsp+0x80], xmm8
00007d5be8fde6e6  vmovaps [rsp+0x90], xmm10
00007d5be8fde6ef  vmovaps [rsp+0xA0], xmm11
00007d5be8fde6f8  vmovaps [rsp+0xB0], xmm12
00007d5be8fde701  vmovaps [rsp+0xC0], xmm13
00007d5be8fde70a  vmovaps [rsp+0xD0], xmm14
00007d5be8fde713  vmovaps [rsp+0xE0], xmm15
00007d5be8fde71c  sub rsp, 0x30
00007d5be8fde720  movaps [rsp], xmm9
00007d5be8fde725  movaps [rsp+0x10], xmm3
00007d5be8fde72a  movaps [rsp+0x20], xmm1
00007d5be8fde72f  lea rdi, [rsp]
00007d5be8fde733  mov esi, 0x00
00007d5be8fde738  mov rax, 0x5D345705A530
00007d5be8fde742  call rax
00007d5be8fde744  movaps xmm9, [rsp]
00007d5be8fde749  add rsp, 0x30
00007d5be8fde74d  vmovaps xmm0, [rsp]
00007d5be8fde752  vmovaps xmm1, [rsp+0x10]
00007d5be8fde758  vmovaps xmm2, [rsp+0x20]
00007d5be8fde75e  vmovaps xmm3, [rsp+0x30]
00007d5be8fde764  vmovaps xmm4, [rsp+0x40]
00007d5be8fde76a  vmovaps xmm5, [rsp+0x50]
00007d5be8fde770  vmovaps xmm6, [rsp+0x60]
00007d5be8fde776  vmovaps xmm7, [rsp+0x70]
00007d5be8fde77c  vmovaps xmm8, [rsp+0x80]
00007d5be8fde785  vmovaps xmm10, [rsp+0x90]
00007d5be8fde78e  vmovaps xmm11, [rsp+0xA0]
00007d5be8fde797  vmovaps xmm12, [rsp+0xB0]
00007d5be8fde7a0  vmovaps xmm13, [rsp+0xC0]
00007d5be8fde7a9  vmovaps xmm14, [rsp+0xD0]
00007d5be8fde7b2  vmovaps xmm15, [rsp+0xE0]
00007d5be8fde7bb  add rsp, 0xF0
00007d5be8fde7c2  pop r11
00007d5be8fde7c4  pop r10
00007d5be8fde7c6  pop r9
00007d5be8fde7c8  pop r8
00007d5be8fde7ca  pop rsi
00007d5be8fde7cb  pop rdi
00007d5be8fde7cc  pop rdx
00007d5be8fde7cd  pop rcx
00007d5be8fde7ce  pop rax
00007d5be8fde7cf  add rsp, 0x08
00007d5be8fde7d3  jmp 0x00007D5BE8FDC1AA
00007d5be8fde7d8  call 0x00007D5BE8EB52F0
00007d5be8fde7dd  jmp 0x00007D5BE8FDC1B7
00007d5be8fde7e2  sub rsp, 0x08
00007d5be8fde7e6  push rax
00007d5be8fde7e7  push rcx
00007d5be8fde7e8  push rdx
00007d5be8fde7e9  push rdi
00007d5be8fde7ea  push rsi
00007d5be8fde7eb  push r8
00007d5be8fde7ed  push r9
00007d5be8fde7ef  push r10
00007d5be8fde7f1  push r11
00007d5be8fde7f3  sub rsp, 0xF0
00007d5be8fde7fa  vmovaps [rsp], xmm0
00007d5be8fde7ff  vmovaps [rsp+0x10], xmm1
00007d5be8fde805  vmovaps [rsp+0x20], xmm2
00007d5be8fde80b  vmovaps [rsp+0x30], xmm3
00007d5be8fde811  vmovaps [rsp+0x40], xmm4
00007d5be8fde817  vmovaps [rsp+0x50], xmm5
00007d5be8fde81d  vmovaps [rsp+0x60], xmm6
00007d5be8fde823  vmovaps [rsp+0x70], xmm7
00007d5be8fde829  vmovaps [rsp+0x80], xmm8
00007d5be8fde832  vmovaps [rsp+0x90], xmm9
00007d5be8fde83b  vmovaps [rsp+0xA0], xmm10
00007d5be8fde844  vmovaps [rsp+0xB0], xmm11
00007d5be8fde84d  vmovaps [rsp+0xC0], xmm12
00007d5be8fde856  vmovaps [rsp+0xD0], xmm13
00007d5be8fde85f  vmovaps [rsp+0xE0], xmm14
00007d5be8fde868  sub rsp, 0x30
00007d5be8fde86c  movaps [rsp], xmm15
00007d5be8fde871  movaps [rsp+0x10], xmm3
00007d5be8fde876  movaps [rsp+0x20], xmm7
00007d5be8fde87b  lea rdi, [rsp]
00007d5be8fde87f  mov esi, 0x00
00007d5be8fde884  mov rax, 0x5D345705A530
00007d5be8fde88e  call rax
00007d5be8fde890  movaps xmm15, [rsp]
00007d5be8fde895  add rsp, 0x30
00007d5be8fde899  vmovaps xmm0, [rsp]
00007d5be8fde89e  vmovaps xmm1, [rsp+0x10]
00007d5be8fde8a4  vmovaps xmm2, [rsp+0x20]
00007d5be8fde8aa  vmovaps xmm3, [rsp+0x30]
00007d5be8fde8b0  vmovaps xmm4, [rsp+0x40]
00007d5be8fde8b6  vmovaps xmm5, [rsp+0x50]
00007d5be8fde8bc  vmovaps xmm6, [rsp+0x60]
00007d5be8fde8c2  vmovaps xmm7, [rsp+0x70]
00007d5be8fde8c8  vmovaps xmm8, [rsp+0x80]
00007d5be8fde8d1  vmovaps xmm9, [rsp+0x90]
00007d5be8fde8da  vmovaps xmm10, [rsp+0xA0]
00007d5be8fde8e3  vmovaps xmm11, [rsp+0xB0]
00007d5be8fde8ec  vmovaps xmm12, [rsp+0xC0]
00007d5be8fde8f5  vmovaps xmm13, [rsp+0xD0]
00007d5be8fde8fe  vmovaps xmm14, [rsp+0xE0]
00007d5be8fde907  add rsp, 0xF0
00007d5be8fde90e  pop r11
00007d5be8fde910  pop r10
00007d5be8fde912  pop r9
00007d5be8fde914  pop r8
00007d5be8fde916  pop rsi
00007d5be8fde917  pop rdi
00007d5be8fde918  pop rdx
00007d5be8fde919  pop rcx
00007d5be8fde91a  pop rax
00007d5be8fde91b  add rsp, 0x08
00007d5be8fde91f  jmp 0x00007D5BE8FDC1E3
00007d5be8fde924  sub rsp, 0x08
00007d5be8fde928  push rax
00007d5be8fde929  push rcx
00007d5be8fde92a  push rdx
00007d5be8fde92b  push rdi
00007d5be8fde92c  push rsi
00007d5be8fde92d  push r8
00007d5be8fde92f  push r9
00007d5be8fde931  push r10
00007d5be8fde933  push r11
00007d5be8fde935  sub rsp, 0xF0
00007d5be8fde93c  vmovaps [rsp], xmm0
00007d5be8fde941  vmovaps [rsp+0x10], xmm1
00007d5be8fde947  vmovaps [rsp+0x20], xmm2
00007d5be8fde94d  vmovaps [rsp+0x30], xmm4
00007d5be8fde953  vmovaps [rsp+0x40], xmm5
00007d5be8fde959  vmovaps [rsp+0x50], xmm6
00007d5be8fde95f  vmovaps [rsp+0x60], xmm7
00007d5be8fde965  vmovaps [rsp+0x70], xmm8
00007d5be8fde96b  vmovaps [rsp+0x80], xmm9
00007d5be8fde974  vmovaps [rsp+0x90], xmm10
00007d5be8fde97d  vmovaps [rsp+0xA0], xmm11
00007d5be8fde986  vmovaps [rsp+0xB0], xmm12
00007d5be8fde98f  vmovaps [rsp+0xC0], xmm13
00007d5be8fde998  vmovaps [rsp+0xD0], xmm14
00007d5be8fde9a1  vmovaps [rsp+0xE0], xmm15
00007d5be8fde9aa  sub rsp, 0x30
00007d5be8fde9ae  movaps [rsp], xmm3
00007d5be8fde9b2  movaps [rsp+0x10], xmm1
00007d5be8fde9b7  movaps [rsp+0x20], xmm15
00007d5be8fde9bd  lea rdi, [rsp]
00007d5be8fde9c1  mov esi, 0x00
00007d5be8fde9c6  mov rax, 0x5D345705A530
00007d5be8fde9d0  call rax
00007d5be8fde9d2  movaps xmm3, [rsp]
00007d5be8fde9d6  add rsp, 0x30
00007d5be8fde9da  vmovaps xmm0, [rsp]
00007d5be8fde9df  vmovaps xmm1, [rsp+0x10]
00007d5be8fde9e5  vmovaps xmm2, [rsp+0x20]
00007d5be8fde9eb  vmovaps xmm4, [rsp+0x30]
00007d5be8fde9f1  vmovaps xmm5, [rsp+0x40]
00007d5be8fde9f7  vmovaps xmm6, [rsp+0x50]
00007d5be8fde9fd  vmovaps xmm7, [rsp+0x60]
00007d5be8fdea03  vmovaps xmm8, [rsp+0x70]
00007d5be8fdea09  vmovaps xmm9, [rsp+0x80]
00007d5be8fdea12  vmovaps xmm10, [rsp+0x90]
00007d5be8fdea1b  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdea24  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdea2d  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdea36  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdea3f  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdea48  add rsp, 0xF0
00007d5be8fdea4f  pop r11
00007d5be8fdea51  pop r10
00007d5be8fdea53  pop r9
00007d5be8fdea55  pop r8
00007d5be8fdea57  pop rsi
00007d5be8fdea58  pop rdi
00007d5be8fdea59  pop rdx
00007d5be8fdea5a  pop rcx
00007d5be8fdea5b  pop rax
00007d5be8fdea5c  add rsp, 0x08
00007d5be8fdea60  jmp 0x00007D5BE8FDC272
00007d5be8fdea65  call 0x00007D5BE8EB52F0
00007d5be8fdea6a  jmp 0x00007D5BE8FDC27C
00007d5be8fdea6f  sub rsp, 0x08
00007d5be8fdea73  push rax
00007d5be8fdea74  push rcx
00007d5be8fdea75  push rdx
00007d5be8fdea76  push rdi
00007d5be8fdea77  push rsi
00007d5be8fdea78  push r8
00007d5be8fdea7a  push r9
00007d5be8fdea7c  push r10
00007d5be8fdea7e  push r11
00007d5be8fdea80  sub rsp, 0xF0
00007d5be8fdea87  vmovaps [rsp], xmm0
00007d5be8fdea8c  vmovaps [rsp+0x10], xmm1
00007d5be8fdea92  vmovaps [rsp+0x20], xmm2
00007d5be8fdea98  vmovaps [rsp+0x30], xmm3
00007d5be8fdea9e  vmovaps [rsp+0x40], xmm4
00007d5be8fdeaa4  vmovaps [rsp+0x50], xmm5
00007d5be8fdeaaa  vmovaps [rsp+0x60], xmm6
00007d5be8fdeab0  vmovaps [rsp+0x70], xmm7
00007d5be8fdeab6  vmovaps [rsp+0x80], xmm8
00007d5be8fdeabf  vmovaps [rsp+0x90], xmm9
00007d5be8fdeac8  vmovaps [rsp+0xA0], xmm10
00007d5be8fdead1  vmovaps [rsp+0xB0], xmm11
00007d5be8fdeada  vmovaps [rsp+0xC0], xmm12
00007d5be8fdeae3  vmovaps [rsp+0xD0], xmm13
00007d5be8fdeaec  vmovaps [rsp+0xE0], xmm14
00007d5be8fdeaf5  sub rsp, 0x30
00007d5be8fdeaf9  movaps [rsp], xmm15
00007d5be8fdeafe  movaps [rsp+0x10], xmm14
00007d5be8fdeb04  movaps [rsp+0x20], xmm4
00007d5be8fdeb09  lea rdi, [rsp]
00007d5be8fdeb0d  mov esi, 0x00
00007d5be8fdeb12  mov rax, 0x5D345705A530
00007d5be8fdeb1c  call rax
00007d5be8fdeb1e  movaps xmm15, [rsp]
00007d5be8fdeb23  add rsp, 0x30
00007d5be8fdeb27  vmovaps xmm0, [rsp]
00007d5be8fdeb2c  vmovaps xmm1, [rsp+0x10]
00007d5be8fdeb32  vmovaps xmm2, [rsp+0x20]
00007d5be8fdeb38  vmovaps xmm3, [rsp+0x30]
00007d5be8fdeb3e  vmovaps xmm4, [rsp+0x40]
00007d5be8fdeb44  vmovaps xmm5, [rsp+0x50]
00007d5be8fdeb4a  vmovaps xmm6, [rsp+0x60]
00007d5be8fdeb50  vmovaps xmm7, [rsp+0x70]
00007d5be8fdeb56  vmovaps xmm8, [rsp+0x80]
00007d5be8fdeb5f  vmovaps xmm9, [rsp+0x90]
00007d5be8fdeb68  vmovaps xmm10, [rsp+0xA0]
00007d5be8fdeb71  vmovaps xmm11, [rsp+0xB0]
00007d5be8fdeb7a  vmovaps xmm12, [rsp+0xC0]
00007d5be8fdeb83  vmovaps xmm13, [rsp+0xD0]
00007d5be8fdeb8c  vmovaps xmm14, [rsp+0xE0]
00007d5be8fdeb95  add rsp, 0xF0
00007d5be8fdeb9c  pop r11
00007d5be8fdeb9e  pop r10
00007d5be8fdeba0  pop r9
00007d5be8fdeba2  pop r8
00007d5be8fdeba4  pop rsi
00007d5be8fdeba5  pop rdi
00007d5be8fdeba6  pop rdx
00007d5be8fdeba7  pop rcx
00007d5be8fdeba8  pop rax
00007d5be8fdeba9  add rsp, 0x08
00007d5be8fdebad  jmp 0x00007D5BE8FDC2AA
00007d5be8fdebb2  sub rsp, 0x08
00007d5be8fdebb6  push rax
00007d5be8fdebb7  push rcx
00007d5be8fdebb8  push rdx
00007d5be8fdebb9  push rdi
00007d5be8fdebba  push rsi
00007d5be8fdebbb  push r8
00007d5be8fdebbd  push r9
00007d5be8fdebbf  push r10
00007d5be8fdebc1  push r11
00007d5be8fdebc3  sub rsp, 0xF0
00007d5be8fdebca  vmovaps [rsp], xmm0
00007d5be8fdebcf  vmovaps [rsp+0x10], xmm1
00007d5be8fdebd5  vmovaps [rsp+0x20], xmm2
00007d5be8fdebdb  vmovaps [rsp+0x30], xmm3
00007d5be8fdebe1  vmovaps [rsp+0x40], xmm4
00007d5be8fdebe7  vmovaps [rsp+0x50], xmm5
00007d5be8fdebed  vmovaps [rsp+0x60], xmm6
00007d5be8fdebf3  vmovaps [rsp+0x70], xmm7
00007d5be8fdebf9  vmovaps [rsp+0x80], xmm8
00007d5be8fdec02  vmovaps [rsp+0x90], xmm9
00007d5be8fdec0b  vmovaps [rsp+0xA0], xmm10
00007d5be8fdec14  vmovaps [rsp+0xB0], xmm11
00007d5be8fdec1d  vmovaps [rsp+0xC0], xmm12
00007d5be8fdec26  vmovaps [rsp+0xD0], xmm13
00007d5be8fdec2f  vmovaps [rsp+0xE0], xmm15
00007d5be8fdec38  sub rsp, 0x30
00007d5be8fdec3c  movaps [rsp], xmm14
00007d5be8fdec41  movaps [rsp+0x10], xmm2
00007d5be8fdec46  movaps [rsp+0x20], xmm1
00007d5be8fdec4b  lea rdi, [rsp]
00007d5be8fdec4f  mov esi, 0x00
00007d5be8fdec54  mov rax, 0x5D345705A530
00007d5be8fdec5e  call rax
00007d5be8fdec60  movaps xmm14, [rsp]
00007d5be8fdec65  add rsp, 0x30
00007d5be8fdec69  vmovaps xmm0, [rsp]
00007d5be8fdec6e  vmovaps xmm1, [rsp+0x10]
00007d5be8fdec74  vmovaps xmm2, [rsp+0x20]
00007d5be8fdec7a  vmovaps xmm3, [rsp+0x30]
00007d5be8fdec80  vmovaps xmm4, [rsp+0x40]
00007d5be8fdec86  vmovaps xmm5, [rsp+0x50]
00007d5be8fdec8c  vmovaps xmm6, [rsp+0x60]
00007d5be8fdec92  vmovaps xmm7, [rsp+0x70]
00007d5be8fdec98  vmovaps xmm8, [rsp+0x80]
00007d5be8fdeca1  vmovaps xmm9, [rsp+0x90]
00007d5be8fdecaa  vmovaps xmm10, [rsp+0xA0]
00007d5be8fdecb3  vmovaps xmm11, [rsp+0xB0]
00007d5be8fdecbc  vmovaps xmm12, [rsp+0xC0]
00007d5be8fdecc5  vmovaps xmm13, [rsp+0xD0]
00007d5be8fdecce  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdecd7  add rsp, 0xF0
00007d5be8fdecde  pop r11
00007d5be8fdece0  pop r10
00007d5be8fdece2  pop r9
00007d5be8fdece4  pop r8
00007d5be8fdece6  pop rsi
00007d5be8fdece7  pop rdi
00007d5be8fdece8  pop rdx
00007d5be8fdece9  pop rcx
00007d5be8fdecea  pop rax
00007d5be8fdeceb  add rsp, 0x08
00007d5be8fdecef  jmp 0x00007D5BE8FDC2D0
00007d5be8fdecf4  sub rsp, 0x08
00007d5be8fdecf8  push rax
00007d5be8fdecf9  push rcx
00007d5be8fdecfa  push rdx
00007d5be8fdecfb  push rdi
00007d5be8fdecfc  push rsi
00007d5be8fdecfd  push r8
00007d5be8fdecff  push r9
00007d5be8fded01  push r10
00007d5be8fded03  push r11
00007d5be8fded05  sub rsp, 0xF0
00007d5be8fded0c  vmovaps [rsp], xmm0
00007d5be8fded11  vmovaps [rsp+0x10], xmm2
00007d5be8fded17  vmovaps [rsp+0x20], xmm3
00007d5be8fded1d  vmovaps [rsp+0x30], xmm4
00007d5be8fded23  vmovaps [rsp+0x40], xmm5
00007d5be8fded29  vmovaps [rsp+0x50], xmm6
00007d5be8fded2f  vmovaps [rsp+0x60], xmm7
00007d5be8fded35  vmovaps [rsp+0x70], xmm8
00007d5be8fded3b  vmovaps [rsp+0x80], xmm9
00007d5be8fded44  vmovaps [rsp+0x90], xmm10
00007d5be8fded4d  vmovaps [rsp+0xA0], xmm11
00007d5be8fded56  vmovaps [rsp+0xB0], xmm12
00007d5be8fded5f  vmovaps [rsp+0xC0], xmm13
00007d5be8fded68  vmovaps [rsp+0xD0], xmm14
00007d5be8fded71  vmovaps [rsp+0xE0], xmm15
00007d5be8fded7a  sub rsp, 0x30
00007d5be8fded7e  movaps [rsp], xmm1
00007d5be8fded82  movaps [rsp+0x10], xmm4
00007d5be8fded87  movaps [rsp+0x20], xmm9
00007d5be8fded8d  lea rdi, [rsp]
00007d5be8fded91  mov esi, 0x00
00007d5be8fded96  mov rax, 0x5D345705A530
00007d5be8fdeda0  call rax
00007d5be8fdeda2  movaps xmm1, [rsp]
00007d5be8fdeda6  add rsp, 0x30
00007d5be8fdedaa  vmovaps xmm0, [rsp]
00007d5be8fdedaf  vmovaps xmm2, [rsp+0x10]
00007d5be8fdedb5  vmovaps xmm3, [rsp+0x20]
00007d5be8fdedbb  vmovaps xmm4, [rsp+0x30]
00007d5be8fdedc1  vmovaps xmm5, [rsp+0x40]
00007d5be8fdedc7  vmovaps xmm6, [rsp+0x50]
00007d5be8fdedcd  vmovaps xmm7, [rsp+0x60]
00007d5be8fdedd3  vmovaps xmm8, [rsp+0x70]
00007d5be8fdedd9  vmovaps xmm9, [rsp+0x80]
00007d5be8fdede2  vmovaps xmm10, [rsp+0x90]
00007d5be8fdedeb  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdedf4  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdedfd  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdee06  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdee0f  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdee18  add rsp, 0xF0
00007d5be8fdee1f  pop r11
00007d5be8fdee21  pop r10
00007d5be8fdee23  pop r9
00007d5be8fdee25  pop r8
00007d5be8fdee27  pop rsi
00007d5be8fdee28  pop rdi
00007d5be8fdee29  pop rdx
00007d5be8fdee2a  pop rcx
00007d5be8fdee2b  pop rax
00007d5be8fdee2c  add rsp, 0x08
00007d5be8fdee30  jmp 0x00007D5BE8FDC2EE
00007d5be8fdee35  sub rsp, 0x08
00007d5be8fdee39  push rax
00007d5be8fdee3a  push rcx
00007d5be8fdee3b  push rdx
00007d5be8fdee3c  push rdi
00007d5be8fdee3d  push rsi
00007d5be8fdee3e  push r8
00007d5be8fdee40  push r9
00007d5be8fdee42  push r10
00007d5be8fdee44  push r11
00007d5be8fdee46  sub rsp, 0xF0
00007d5be8fdee4d  vmovaps [rsp], xmm0
00007d5be8fdee52  vmovaps [rsp+0x10], xmm1
00007d5be8fdee58  vmovaps [rsp+0x20], xmm2
00007d5be8fdee5e  vmovaps [rsp+0x30], xmm3
00007d5be8fdee64  vmovaps [rsp+0x40], xmm5
00007d5be8fdee6a  vmovaps [rsp+0x50], xmm6
00007d5be8fdee70  vmovaps [rsp+0x60], xmm7
00007d5be8fdee76  vmovaps [rsp+0x70], xmm8
00007d5be8fdee7c  vmovaps [rsp+0x80], xmm9
00007d5be8fdee85  vmovaps [rsp+0x90], xmm10
00007d5be8fdee8e  vmovaps [rsp+0xA0], xmm11
00007d5be8fdee97  vmovaps [rsp+0xB0], xmm12
00007d5be8fdeea0  vmovaps [rsp+0xC0], xmm13
00007d5be8fdeea9  vmovaps [rsp+0xD0], xmm14
00007d5be8fdeeb2  vmovaps [rsp+0xE0], xmm15
00007d5be8fdeebb  sub rsp, 0x30
00007d5be8fdeebf  movaps [rsp], xmm4
00007d5be8fdeec3  movaps [rsp+0x10], xmm2
00007d5be8fdeec8  movaps [rsp+0x20], xmm9
00007d5be8fdeece  lea rdi, [rsp]
00007d5be8fdeed2  mov esi, 0x00
00007d5be8fdeed7  mov rax, 0x5D345705A530
00007d5be8fdeee1  call rax
00007d5be8fdeee3  movaps xmm4, [rsp]
00007d5be8fdeee7  add rsp, 0x30
00007d5be8fdeeeb  vmovaps xmm0, [rsp]
00007d5be8fdeef0  vmovaps xmm1, [rsp+0x10]
00007d5be8fdeef6  vmovaps xmm2, [rsp+0x20]
00007d5be8fdeefc  vmovaps xmm3, [rsp+0x30]
00007d5be8fdef02  vmovaps xmm5, [rsp+0x40]
00007d5be8fdef08  vmovaps xmm6, [rsp+0x50]
00007d5be8fdef0e  vmovaps xmm7, [rsp+0x60]
00007d5be8fdef14  vmovaps xmm8, [rsp+0x70]
00007d5be8fdef1a  vmovaps xmm9, [rsp+0x80]
00007d5be8fdef23  vmovaps xmm10, [rsp+0x90]
00007d5be8fdef2c  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdef35  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdef3e  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdef47  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdef50  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdef59  add rsp, 0xF0
00007d5be8fdef60  pop r11
00007d5be8fdef62  pop r10
00007d5be8fdef64  pop r9
00007d5be8fdef66  pop r8
00007d5be8fdef68  pop rsi
00007d5be8fdef69  pop rdi
00007d5be8fdef6a  pop rdx
00007d5be8fdef6b  pop rcx
00007d5be8fdef6c  pop rax
00007d5be8fdef6d  add rsp, 0x08
00007d5be8fdef71  jmp 0x00007D5BE8FDC31E
00007d5be8fdef76  sub rsp, 0x08
00007d5be8fdef7a  push rax
00007d5be8fdef7b  push rcx
00007d5be8fdef7c  push rdx
00007d5be8fdef7d  push rdi
00007d5be8fdef7e  push rsi
00007d5be8fdef7f  push r8
00007d5be8fdef81  push r9
00007d5be8fdef83  push r10
00007d5be8fdef85  push r11
00007d5be8fdef87  sub rsp, 0xF0
00007d5be8fdef8e  vmovaps [rsp], xmm0
00007d5be8fdef93  vmovaps [rsp+0x10], xmm1
00007d5be8fdef99  vmovaps [rsp+0x20], xmm2
00007d5be8fdef9f  vmovaps [rsp+0x30], xmm3
00007d5be8fdefa5  vmovaps [rsp+0x40], xmm4
00007d5be8fdefab  vmovaps [rsp+0x50], xmm5
00007d5be8fdefb1  vmovaps [rsp+0x60], xmm6
00007d5be8fdefb7  vmovaps [rsp+0x70], xmm7
00007d5be8fdefbd  vmovaps [rsp+0x80], xmm8
00007d5be8fdefc6  vmovaps [rsp+0x90], xmm10
00007d5be8fdefcf  vmovaps [rsp+0xA0], xmm11
00007d5be8fdefd8  vmovaps [rsp+0xB0], xmm12
00007d5be8fdefe1  vmovaps [rsp+0xC0], xmm13
00007d5be8fdefea  vmovaps [rsp+0xD0], xmm14
00007d5be8fdeff3  vmovaps [rsp+0xE0], xmm15
00007d5be8fdeffc  sub rsp, 0x30
00007d5be8fdf000  movaps [rsp], xmm9
00007d5be8fdf005  movaps [rsp+0x10], xmm2
00007d5be8fdf00a  movaps [rsp+0x20], xmm1
00007d5be8fdf00f  lea rdi, [rsp]
00007d5be8fdf013  mov esi, 0x00
00007d5be8fdf018  mov rax, 0x5D345705A530
00007d5be8fdf022  call rax
00007d5be8fdf024  movaps xmm9, [rsp]
00007d5be8fdf029  add rsp, 0x30
00007d5be8fdf02d  vmovaps xmm0, [rsp]
00007d5be8fdf032  vmovaps xmm1, [rsp+0x10]
00007d5be8fdf038  vmovaps xmm2, [rsp+0x20]
00007d5be8fdf03e  vmovaps xmm3, [rsp+0x30]
00007d5be8fdf044  vmovaps xmm4, [rsp+0x40]
00007d5be8fdf04a  vmovaps xmm5, [rsp+0x50]
00007d5be8fdf050  vmovaps xmm6, [rsp+0x60]
00007d5be8fdf056  vmovaps xmm7, [rsp+0x70]
00007d5be8fdf05c  vmovaps xmm8, [rsp+0x80]
00007d5be8fdf065  vmovaps xmm10, [rsp+0x90]
00007d5be8fdf06e  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdf077  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdf080  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdf089  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdf092  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdf09b  add rsp, 0xF0
00007d5be8fdf0a2  pop r11
00007d5be8fdf0a4  pop r10
00007d5be8fdf0a6  pop r9
00007d5be8fdf0a8  pop r8
00007d5be8fdf0aa  pop rsi
00007d5be8fdf0ab  pop rdi
00007d5be8fdf0ac  pop rdx
00007d5be8fdf0ad  pop rcx
00007d5be8fdf0ae  pop rax
00007d5be8fdf0af  add rsp, 0x08
00007d5be8fdf0b3  jmp 0x00007D5BE8FDC354
00007d5be8fdf0b8  sub rsp, 0x08
00007d5be8fdf0bc  push rax
00007d5be8fdf0bd  push rcx
00007d5be8fdf0be  push rdx
00007d5be8fdf0bf  push rdi
00007d5be8fdf0c0  push rsi
00007d5be8fdf0c1  push r8
00007d5be8fdf0c3  push r9
00007d5be8fdf0c5  push r10
00007d5be8fdf0c7  push r11
00007d5be8fdf0c9  sub rsp, 0xF0
00007d5be8fdf0d0  vmovaps [rsp], xmm0
00007d5be8fdf0d5  vmovaps [rsp+0x10], xmm2
00007d5be8fdf0db  vmovaps [rsp+0x20], xmm3
00007d5be8fdf0e1  vmovaps [rsp+0x30], xmm4
00007d5be8fdf0e7  vmovaps [rsp+0x40], xmm5
00007d5be8fdf0ed  vmovaps [rsp+0x50], xmm6
00007d5be8fdf0f3  vmovaps [rsp+0x60], xmm7
00007d5be8fdf0f9  vmovaps [rsp+0x70], xmm8
00007d5be8fdf0ff  vmovaps [rsp+0x80], xmm9
00007d5be8fdf108  vmovaps [rsp+0x90], xmm10
00007d5be8fdf111  vmovaps [rsp+0xA0], xmm11
00007d5be8fdf11a  vmovaps [rsp+0xB0], xmm12
00007d5be8fdf123  vmovaps [rsp+0xC0], xmm13
00007d5be8fdf12c  vmovaps [rsp+0xD0], xmm14
00007d5be8fdf135  vmovaps [rsp+0xE0], xmm15
00007d5be8fdf13e  sub rsp, 0x30
00007d5be8fdf142  movaps [rsp], xmm1
00007d5be8fdf146  movaps [rsp+0x10], xmm15
00007d5be8fdf14c  movaps [rsp+0x20], xmm6
00007d5be8fdf151  lea rdi, [rsp]
00007d5be8fdf155  mov esi, 0x00
00007d5be8fdf15a  mov rax, 0x5D345705A530
00007d5be8fdf164  call rax
00007d5be8fdf166  movaps xmm1, [rsp]
00007d5be8fdf16a  add rsp, 0x30
00007d5be8fdf16e  vmovaps xmm0, [rsp]
00007d5be8fdf173  vmovaps xmm2, [rsp+0x10]
00007d5be8fdf179  vmovaps xmm3, [rsp+0x20]
00007d5be8fdf17f  vmovaps xmm4, [rsp+0x30]
00007d5be8fdf185  vmovaps xmm5, [rsp+0x40]
00007d5be8fdf18b  vmovaps xmm6, [rsp+0x50]
00007d5be8fdf191  vmovaps xmm7, [rsp+0x60]
00007d5be8fdf197  vmovaps xmm8, [rsp+0x70]
00007d5be8fdf19d  vmovaps xmm9, [rsp+0x80]
00007d5be8fdf1a6  vmovaps xmm10, [rsp+0x90]
00007d5be8fdf1af  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdf1b8  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdf1c1  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdf1ca  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdf1d3  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdf1dc  add rsp, 0xF0
00007d5be8fdf1e3  pop r11
00007d5be8fdf1e5  pop r10
00007d5be8fdf1e7  pop r9
00007d5be8fdf1e9  pop r8
00007d5be8fdf1eb  pop rsi
00007d5be8fdf1ec  pop rdi
00007d5be8fdf1ed  pop rdx
00007d5be8fdf1ee  pop rcx
00007d5be8fdf1ef  pop rax
00007d5be8fdf1f0  add rsp, 0x08
00007d5be8fdf1f4  jmp 0x00007D5BE8FDC375
00007d5be8fdf1f9  sub rsp, 0x08
00007d5be8fdf1fd  push rax
00007d5be8fdf1fe  push rcx
00007d5be8fdf1ff  push rdx
00007d5be8fdf200  push rdi
00007d5be8fdf201  push rsi
00007d5be8fdf202  push r8
00007d5be8fdf204  push r9
00007d5be8fdf206  push r10
00007d5be8fdf208  push r11
00007d5be8fdf20a  sub rsp, 0xF0
00007d5be8fdf211  vmovaps [rsp], xmm0
00007d5be8fdf216  vmovaps [rsp+0x10], xmm1
00007d5be8fdf21c  vmovaps [rsp+0x20], xmm2
00007d5be8fdf222  vmovaps [rsp+0x30], xmm3
00007d5be8fdf228  vmovaps [rsp+0x40], xmm4
00007d5be8fdf22e  vmovaps [rsp+0x50], xmm5
00007d5be8fdf234  vmovaps [rsp+0x60], xmm6
00007d5be8fdf23a  vmovaps [rsp+0x70], xmm7
00007d5be8fdf240  vmovaps [rsp+0x80], xmm8
00007d5be8fdf249  vmovaps [rsp+0x90], xmm9
00007d5be8fdf252  vmovaps [rsp+0xA0], xmm10
00007d5be8fdf25b  vmovaps [rsp+0xB0], xmm11
00007d5be8fdf264  vmovaps [rsp+0xC0], xmm12
00007d5be8fdf26d  vmovaps [rsp+0xD0], xmm13
00007d5be8fdf276  vmovaps [rsp+0xE0], xmm14
00007d5be8fdf27f  sub rsp, 0x30
00007d5be8fdf283  movaps [rsp], xmm15
00007d5be8fdf288  movaps [rsp+0x10], xmm5
00007d5be8fdf28d  movaps [rsp+0x20], xmm3
00007d5be8fdf292  lea rdi, [rsp]
00007d5be8fdf296  mov esi, 0x00
00007d5be8fdf29b  mov rax, 0x5D345705A530
00007d5be8fdf2a5  call rax
00007d5be8fdf2a7  movaps xmm15, [rsp]
00007d5be8fdf2ac  add rsp, 0x30
00007d5be8fdf2b0  vmovaps xmm0, [rsp]
00007d5be8fdf2b5  vmovaps xmm1, [rsp+0x10]
00007d5be8fdf2bb  vmovaps xmm2, [rsp+0x20]
00007d5be8fdf2c1  vmovaps xmm3, [rsp+0x30]
00007d5be8fdf2c7  vmovaps xmm4, [rsp+0x40]
00007d5be8fdf2cd  vmovaps xmm5, [rsp+0x50]
00007d5be8fdf2d3  vmovaps xmm6, [rsp+0x60]
00007d5be8fdf2d9  vmovaps xmm7, [rsp+0x70]
00007d5be8fdf2df  vmovaps xmm8, [rsp+0x80]
00007d5be8fdf2e8  vmovaps xmm9, [rsp+0x90]
00007d5be8fdf2f1  vmovaps xmm10, [rsp+0xA0]
00007d5be8fdf2fa  vmovaps xmm11, [rsp+0xB0]
00007d5be8fdf303  vmovaps xmm12, [rsp+0xC0]
00007d5be8fdf30c  vmovaps xmm13, [rsp+0xD0]
00007d5be8fdf315  vmovaps xmm14, [rsp+0xE0]
00007d5be8fdf31e  add rsp, 0xF0
00007d5be8fdf325  pop r11
00007d5be8fdf327  pop r10
00007d5be8fdf329  pop r9
00007d5be8fdf32b  pop r8
00007d5be8fdf32d  pop rsi
00007d5be8fdf32e  pop rdi
00007d5be8fdf32f  pop rdx
00007d5be8fdf330  pop rcx
00007d5be8fdf331  pop rax
00007d5be8fdf332  add rsp, 0x08
00007d5be8fdf336  jmp 0x00007D5BE8FDC38F
00007d5be8fdf33b  sub rsp, 0x08
00007d5be8fdf33f  push rax
00007d5be8fdf340  push rcx
00007d5be8fdf341  push rdx
00007d5be8fdf342  push rdi
00007d5be8fdf343  push rsi
00007d5be8fdf344  push r8
00007d5be8fdf346  push r9
00007d5be8fdf348  push r10
00007d5be8fdf34a  push r11
00007d5be8fdf34c  sub rsp, 0xF0
00007d5be8fdf353  vmovaps [rsp], xmm0
00007d5be8fdf358  vmovaps [rsp+0x10], xmm1
00007d5be8fdf35e  vmovaps [rsp+0x20], xmm2
00007d5be8fdf364  vmovaps [rsp+0x30], xmm3
00007d5be8fdf36a  vmovaps [rsp+0x40], xmm4
00007d5be8fdf370  vmovaps [rsp+0x50], xmm6
00007d5be8fdf376  vmovaps [rsp+0x60], xmm7
00007d5be8fdf37c  vmovaps [rsp+0x70], xmm8
00007d5be8fdf382  vmovaps [rsp+0x80], xmm9
00007d5be8fdf38b  vmovaps [rsp+0x90], xmm10
00007d5be8fdf394  vmovaps [rsp+0xA0], xmm11
00007d5be8fdf39d  vmovaps [rsp+0xB0], xmm12
00007d5be8fdf3a6  vmovaps [rsp+0xC0], xmm13
00007d5be8fdf3af  vmovaps [rsp+0xD0], xmm14
00007d5be8fdf3b8  vmovaps [rsp+0xE0], xmm15
00007d5be8fdf3c1  sub rsp, 0x30
00007d5be8fdf3c5  movaps [rsp], xmm5
00007d5be8fdf3c9  movaps [rsp+0x10], xmm8
00007d5be8fdf3cf  movaps [rsp+0x20], xmm6
00007d5be8fdf3d4  lea rdi, [rsp]
00007d5be8fdf3d8  mov esi, 0x00
00007d5be8fdf3dd  mov rax, 0x5D345705A530
00007d5be8fdf3e7  call rax
00007d5be8fdf3e9  movaps xmm5, [rsp]
00007d5be8fdf3ed  add rsp, 0x30
00007d5be8fdf3f1  vmovaps xmm0, [rsp]
00007d5be8fdf3f6  vmovaps xmm1, [rsp+0x10]
00007d5be8fdf3fc  vmovaps xmm2, [rsp+0x20]
00007d5be8fdf402  vmovaps xmm3, [rsp+0x30]
00007d5be8fdf408  vmovaps xmm4, [rsp+0x40]
00007d5be8fdf40e  vmovaps xmm6, [rsp+0x50]
00007d5be8fdf414  vmovaps xmm7, [rsp+0x60]
00007d5be8fdf41a  vmovaps xmm8, [rsp+0x70]
00007d5be8fdf420  vmovaps xmm9, [rsp+0x80]
00007d5be8fdf429  vmovaps xmm10, [rsp+0x90]
00007d5be8fdf432  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdf43b  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdf444  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdf44d  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdf456  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdf45f  add rsp, 0xF0
00007d5be8fdf466  pop r11
00007d5be8fdf468  pop r10
00007d5be8fdf46a  pop r9
00007d5be8fdf46c  pop r8
00007d5be8fdf46e  pop rsi
00007d5be8fdf46f  pop rdi
00007d5be8fdf470  pop rdx
00007d5be8fdf471  pop rcx
00007d5be8fdf472  pop rax
00007d5be8fdf473  add rsp, 0x08
00007d5be8fdf477  jmp 0x00007D5BE8FDC3B3
00007d5be8fdf47c  sub rsp, 0x08
00007d5be8fdf480  push rax
00007d5be8fdf481  push rcx
00007d5be8fdf482  push rdx
00007d5be8fdf483  push rdi
00007d5be8fdf484  push rsi
00007d5be8fdf485  push r8
00007d5be8fdf487  push r9
00007d5be8fdf489  push r10
00007d5be8fdf48b  push r11
00007d5be8fdf48d  sub rsp, 0xF0
00007d5be8fdf494  vmovaps [rsp], xmm0
00007d5be8fdf499  vmovaps [rsp+0x10], xmm1
00007d5be8fdf49f  vmovaps [rsp+0x20], xmm2
00007d5be8fdf4a5  vmovaps [rsp+0x30], xmm3
00007d5be8fdf4ab  vmovaps [rsp+0x40], xmm4
00007d5be8fdf4b1  vmovaps [rsp+0x50], xmm5
00007d5be8fdf4b7  vmovaps [rsp+0x60], xmm7
00007d5be8fdf4bd  vmovaps [rsp+0x70], xmm8
00007d5be8fdf4c3  vmovaps [rsp+0x80], xmm9
00007d5be8fdf4cc  vmovaps [rsp+0x90], xmm10
00007d5be8fdf4d5  vmovaps [rsp+0xA0], xmm11
00007d5be8fdf4de  vmovaps [rsp+0xB0], xmm12
00007d5be8fdf4e7  vmovaps [rsp+0xC0], xmm13
00007d5be8fdf4f0  vmovaps [rsp+0xD0], xmm14
00007d5be8fdf4f9  vmovaps [rsp+0xE0], xmm15
00007d5be8fdf502  sub rsp, 0x30
00007d5be8fdf506  movaps [rsp], xmm6
00007d5be8fdf50a  movaps [rsp+0x10], xmm10
00007d5be8fdf510  movaps [rsp+0x20], xmm8
00007d5be8fdf516  lea rdi, [rsp]
00007d5be8fdf51a  mov esi, 0x00
00007d5be8fdf51f  mov rax, 0x5D345705A530
00007d5be8fdf529  call rax
00007d5be8fdf52b  movaps xmm6, [rsp]
00007d5be8fdf52f  add rsp, 0x30
00007d5be8fdf533  vmovaps xmm0, [rsp]
00007d5be8fdf538  vmovaps xmm1, [rsp+0x10]
00007d5be8fdf53e  vmovaps xmm2, [rsp+0x20]
00007d5be8fdf544  vmovaps xmm3, [rsp+0x30]
00007d5be8fdf54a  vmovaps xmm4, [rsp+0x40]
00007d5be8fdf550  vmovaps xmm5, [rsp+0x50]
00007d5be8fdf556  vmovaps xmm7, [rsp+0x60]
00007d5be8fdf55c  vmovaps xmm8, [rsp+0x70]
00007d5be8fdf562  vmovaps xmm9, [rsp+0x80]
00007d5be8fdf56b  vmovaps xmm10, [rsp+0x90]
00007d5be8fdf574  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdf57d  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdf586  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdf58f  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdf598  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdf5a1  add rsp, 0xF0
00007d5be8fdf5a8  pop r11
00007d5be8fdf5aa  pop r10
00007d5be8fdf5ac  pop r9
00007d5be8fdf5ae  pop r8
00007d5be8fdf5b0  pop rsi
00007d5be8fdf5b1  pop rdi
00007d5be8fdf5b2  pop rdx
00007d5be8fdf5b3  pop rcx
00007d5be8fdf5b4  pop rax
00007d5be8fdf5b5  add rsp, 0x08
00007d5be8fdf5b9  jmp 0x00007D5BE8FDC3D8
00007d5be8fdf5be  sub rsp, 0x08
00007d5be8fdf5c2  push rax
00007d5be8fdf5c3  push rcx
00007d5be8fdf5c4  push rdx
00007d5be8fdf5c5  push rdi
00007d5be8fdf5c6  push rsi
00007d5be8fdf5c7  push r8
00007d5be8fdf5c9  push r9
00007d5be8fdf5cb  push r10
00007d5be8fdf5cd  push r11
00007d5be8fdf5cf  sub rsp, 0xF0
00007d5be8fdf5d6  vmovaps [rsp], xmm0
00007d5be8fdf5db  vmovaps [rsp+0x10], xmm1
00007d5be8fdf5e1  vmovaps [rsp+0x20], xmm2
00007d5be8fdf5e7  vmovaps [rsp+0x30], xmm3
00007d5be8fdf5ed  vmovaps [rsp+0x40], xmm4
00007d5be8fdf5f3  vmovaps [rsp+0x50], xmm5
00007d5be8fdf5f9  vmovaps [rsp+0x60], xmm6
00007d5be8fdf5ff  vmovaps [rsp+0x70], xmm7
00007d5be8fdf605  vmovaps [rsp+0x80], xmm8
00007d5be8fdf60e  vmovaps [rsp+0x90], xmm9
00007d5be8fdf617  vmovaps [rsp+0xA0], xmm11
00007d5be8fdf620  vmovaps [rsp+0xB0], xmm12
00007d5be8fdf629  vmovaps [rsp+0xC0], xmm13
00007d5be8fdf632  vmovaps [rsp+0xD0], xmm14
00007d5be8fdf63b  vmovaps [rsp+0xE0], xmm15
00007d5be8fdf644  sub rsp, 0x30
00007d5be8fdf648  movaps [rsp], xmm10
00007d5be8fdf64d  movaps [rsp+0x10], xmm8
00007d5be8fdf653  movaps [rsp+0x20], xmm14
00007d5be8fdf659  lea rdi, [rsp]
00007d5be8fdf65d  mov esi, 0x00
00007d5be8fdf662  mov rax, 0x5D345705A530
00007d5be8fdf66c  call rax
00007d5be8fdf66e  movaps xmm10, [rsp]
00007d5be8fdf673  add rsp, 0x30
00007d5be8fdf677  vmovaps xmm0, [rsp]
00007d5be8fdf67c  vmovaps xmm1, [rsp+0x10]
00007d5be8fdf682  vmovaps xmm2, [rsp+0x20]
00007d5be8fdf688  vmovaps xmm3, [rsp+0x30]
00007d5be8fdf68e  vmovaps xmm4, [rsp+0x40]
00007d5be8fdf694  vmovaps xmm5, [rsp+0x50]
00007d5be8fdf69a  vmovaps xmm6, [rsp+0x60]
00007d5be8fdf6a0  vmovaps xmm7, [rsp+0x70]
00007d5be8fdf6a6  vmovaps xmm8, [rsp+0x80]
00007d5be8fdf6af  vmovaps xmm9, [rsp+0x90]
00007d5be8fdf6b8  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdf6c1  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdf6ca  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdf6d3  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdf6dc  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdf6e5  add rsp, 0xF0
00007d5be8fdf6ec  pop r11
00007d5be8fdf6ee  pop r10
00007d5be8fdf6f0  pop r9
00007d5be8fdf6f2  pop r8
00007d5be8fdf6f4  pop rsi
00007d5be8fdf6f5  pop rdi
00007d5be8fdf6f6  pop rdx
00007d5be8fdf6f7  pop rcx
00007d5be8fdf6f8  pop rax
00007d5be8fdf6f9  add rsp, 0x08
00007d5be8fdf6fd  jmp 0x00007D5BE8FDC3F8
00007d5be8fdf702  sub rsp, 0x08
00007d5be8fdf706  push rax
00007d5be8fdf707  push rcx
00007d5be8fdf708  push rdx
00007d5be8fdf709  push rdi
00007d5be8fdf70a  push rsi
00007d5be8fdf70b  push r8
00007d5be8fdf70d  push r9
00007d5be8fdf70f  push r10
00007d5be8fdf711  push r11
00007d5be8fdf713  sub rsp, 0xF0
00007d5be8fdf71a  vmovaps [rsp], xmm0
00007d5be8fdf71f  vmovaps [rsp+0x10], xmm1
00007d5be8fdf725  vmovaps [rsp+0x20], xmm2
00007d5be8fdf72b  vmovaps [rsp+0x30], xmm3
00007d5be8fdf731  vmovaps [rsp+0x40], xmm4
00007d5be8fdf737  vmovaps [rsp+0x50], xmm5
00007d5be8fdf73d  vmovaps [rsp+0x60], xmm6
00007d5be8fdf743  vmovaps [rsp+0x70], xmm7
00007d5be8fdf749  vmovaps [rsp+0x80], xmm8
00007d5be8fdf752  vmovaps [rsp+0x90], xmm9
00007d5be8fdf75b  vmovaps [rsp+0xA0], xmm10
00007d5be8fdf764  vmovaps [rsp+0xB0], xmm11
00007d5be8fdf76d  vmovaps [rsp+0xC0], xmm12
00007d5be8fdf776  vmovaps [rsp+0xD0], xmm13
00007d5be8fdf77f  vmovaps [rsp+0xE0], xmm15
00007d5be8fdf788  sub rsp, 0x30
00007d5be8fdf78c  movaps [rsp], xmm14
00007d5be8fdf791  movaps [rsp+0x10], xmm8
00007d5be8fdf797  movaps [rsp+0x20], xmm4
00007d5be8fdf79c  lea rdi, [rsp]
00007d5be8fdf7a0  mov esi, 0x00
00007d5be8fdf7a5  mov rax, 0x5D345705A530
00007d5be8fdf7af  call rax
00007d5be8fdf7b1  movaps xmm14, [rsp]
00007d5be8fdf7b6  add rsp, 0x30
00007d5be8fdf7ba  vmovaps xmm0, [rsp]
00007d5be8fdf7bf  vmovaps xmm1, [rsp+0x10]
00007d5be8fdf7c5  vmovaps xmm2, [rsp+0x20]
00007d5be8fdf7cb  vmovaps xmm3, [rsp+0x30]
00007d5be8fdf7d1  vmovaps xmm4, [rsp+0x40]
00007d5be8fdf7d7  vmovaps xmm5, [rsp+0x50]
00007d5be8fdf7dd  vmovaps xmm6, [rsp+0x60]
00007d5be8fdf7e3  vmovaps xmm7, [rsp+0x70]
00007d5be8fdf7e9  vmovaps xmm8, [rsp+0x80]
00007d5be8fdf7f2  vmovaps xmm9, [rsp+0x90]
00007d5be8fdf7fb  vmovaps xmm10, [rsp+0xA0]
00007d5be8fdf804  vmovaps xmm11, [rsp+0xB0]
00007d5be8fdf80d  vmovaps xmm12, [rsp+0xC0]
00007d5be8fdf816  vmovaps xmm13, [rsp+0xD0]
00007d5be8fdf81f  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdf828  add rsp, 0xF0
00007d5be8fdf82f  pop r11
00007d5be8fdf831  pop r10
00007d5be8fdf833  pop r9
00007d5be8fdf835  pop r8
00007d5be8fdf837  pop rsi
00007d5be8fdf838  pop rdi
00007d5be8fdf839  pop rdx
00007d5be8fdf83a  pop rcx
00007d5be8fdf83b  pop rax
00007d5be8fdf83c  add rsp, 0x08
00007d5be8fdf840  jmp 0x00007D5BE8FDC418
00007d5be8fdf845  sub rsp, 0x08
00007d5be8fdf849  push rax
00007d5be8fdf84a  push rcx
00007d5be8fdf84b  push rdx
00007d5be8fdf84c  push rdi
00007d5be8fdf84d  push rsi
00007d5be8fdf84e  push r8
00007d5be8fdf850  push r9
00007d5be8fdf852  push r10
00007d5be8fdf854  push r11
00007d5be8fdf856  sub rsp, 0xF0
00007d5be8fdf85d  vmovaps [rsp], xmm0
00007d5be8fdf862  vmovaps [rsp+0x10], xmm1
00007d5be8fdf868  vmovaps [rsp+0x20], xmm2
00007d5be8fdf86e  vmovaps [rsp+0x30], xmm3
00007d5be8fdf874  vmovaps [rsp+0x40], xmm5
00007d5be8fdf87a  vmovaps [rsp+0x50], xmm6
00007d5be8fdf880  vmovaps [rsp+0x60], xmm7
00007d5be8fdf886  vmovaps [rsp+0x70], xmm8
00007d5be8fdf88c  vmovaps [rsp+0x80], xmm9
00007d5be8fdf895  vmovaps [rsp+0x90], xmm10
00007d5be8fdf89e  vmovaps [rsp+0xA0], xmm11
00007d5be8fdf8a7  vmovaps [rsp+0xB0], xmm12
00007d5be8fdf8b0  vmovaps [rsp+0xC0], xmm13
00007d5be8fdf8b9  vmovaps [rsp+0xD0], xmm14
00007d5be8fdf8c2  vmovaps [rsp+0xE0], xmm15
00007d5be8fdf8cb  sub rsp, 0x30
00007d5be8fdf8cf  movaps [rsp], xmm4
00007d5be8fdf8d3  movaps [rsp+0x10], xmm13
00007d5be8fdf8d9  movaps [rsp+0x20], xmm8
00007d5be8fdf8df  lea rdi, [rsp]
00007d5be8fdf8e3  mov esi, 0x00
00007d5be8fdf8e8  mov rax, 0x5D345705A530
00007d5be8fdf8f2  call rax
00007d5be8fdf8f4  movaps xmm4, [rsp]
00007d5be8fdf8f8  add rsp, 0x30
00007d5be8fdf8fc  vmovaps xmm0, [rsp]
00007d5be8fdf901  vmovaps xmm1, [rsp+0x10]
00007d5be8fdf907  vmovaps xmm2, [rsp+0x20]
00007d5be8fdf90d  vmovaps xmm3, [rsp+0x30]
00007d5be8fdf913  vmovaps xmm5, [rsp+0x40]
00007d5be8fdf919  vmovaps xmm6, [rsp+0x50]
00007d5be8fdf91f  vmovaps xmm7, [rsp+0x60]
00007d5be8fdf925  vmovaps xmm8, [rsp+0x70]
00007d5be8fdf92b  vmovaps xmm9, [rsp+0x80]
00007d5be8fdf934  vmovaps xmm10, [rsp+0x90]
00007d5be8fdf93d  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdf946  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdf94f  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdf958  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdf961  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdf96a  add rsp, 0xF0
00007d5be8fdf971  pop r11
00007d5be8fdf973  pop r10
00007d5be8fdf975  pop r9
00007d5be8fdf977  pop r8
00007d5be8fdf979  pop rsi
00007d5be8fdf97a  pop rdi
00007d5be8fdf97b  pop rdx
00007d5be8fdf97c  pop rcx
00007d5be8fdf97d  pop rax
00007d5be8fdf97e  add rsp, 0x08
00007d5be8fdf982  jmp 0x00007D5BE8FDC43D
00007d5be8fdf987  sub rsp, 0x08
00007d5be8fdf98b  push rax
00007d5be8fdf98c  push rcx
00007d5be8fdf98d  push rdx
00007d5be8fdf98e  push rdi
00007d5be8fdf98f  push rsi
00007d5be8fdf990  push r8
00007d5be8fdf992  push r9
00007d5be8fdf994  push r10
00007d5be8fdf996  push r11
00007d5be8fdf998  sub rsp, 0xF0
00007d5be8fdf99f  vmovaps [rsp], xmm0
00007d5be8fdf9a4  vmovaps [rsp+0x10], xmm1
00007d5be8fdf9aa  vmovaps [rsp+0x20], xmm2
00007d5be8fdf9b0  vmovaps [rsp+0x30], xmm3
00007d5be8fdf9b6  vmovaps [rsp+0x40], xmm4
00007d5be8fdf9bc  vmovaps [rsp+0x50], xmm5
00007d5be8fdf9c2  vmovaps [rsp+0x60], xmm6
00007d5be8fdf9c8  vmovaps [rsp+0x70], xmm7
00007d5be8fdf9ce  vmovaps [rsp+0x80], xmm8
00007d5be8fdf9d7  vmovaps [rsp+0x90], xmm9
00007d5be8fdf9e0  vmovaps [rsp+0xA0], xmm10
00007d5be8fdf9e9  vmovaps [rsp+0xB0], xmm11
00007d5be8fdf9f2  vmovaps [rsp+0xC0], xmm12
00007d5be8fdf9fb  vmovaps [rsp+0xD0], xmm14
00007d5be8fdfa04  vmovaps [rsp+0xE0], xmm15
00007d5be8fdfa0d  sub rsp, 0x30
00007d5be8fdfa11  movaps [rsp], xmm13
00007d5be8fdfa16  movaps [rsp+0x10], xmm15
00007d5be8fdfa1c  movaps [rsp+0x20], xmm9
00007d5be8fdfa22  lea rdi, [rsp]
00007d5be8fdfa26  mov esi, 0x00
00007d5be8fdfa2b  mov rax, 0x5D345705A530
00007d5be8fdfa35  call rax
00007d5be8fdfa37  movaps xmm13, [rsp]
00007d5be8fdfa3c  add rsp, 0x30
00007d5be8fdfa40  vmovaps xmm0, [rsp]
00007d5be8fdfa45  vmovaps xmm1, [rsp+0x10]
00007d5be8fdfa4b  vmovaps xmm2, [rsp+0x20]
00007d5be8fdfa51  vmovaps xmm3, [rsp+0x30]
00007d5be8fdfa57  vmovaps xmm4, [rsp+0x40]
00007d5be8fdfa5d  vmovaps xmm5, [rsp+0x50]
00007d5be8fdfa63  vmovaps xmm6, [rsp+0x60]
00007d5be8fdfa69  vmovaps xmm7, [rsp+0x70]
00007d5be8fdfa6f  vmovaps xmm8, [rsp+0x80]
00007d5be8fdfa78  vmovaps xmm9, [rsp+0x90]
00007d5be8fdfa81  vmovaps xmm10, [rsp+0xA0]
00007d5be8fdfa8a  vmovaps xmm11, [rsp+0xB0]
00007d5be8fdfa93  vmovaps xmm12, [rsp+0xC0]
00007d5be8fdfa9c  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdfaa5  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdfaae  add rsp, 0xF0
00007d5be8fdfab5  pop r11
00007d5be8fdfab7  pop r10
00007d5be8fdfab9  pop r9
00007d5be8fdfabb  pop r8
00007d5be8fdfabd  pop rsi
00007d5be8fdfabe  pop rdi
00007d5be8fdfabf  pop rdx
00007d5be8fdfac0  pop rcx
00007d5be8fdfac1  pop rax
00007d5be8fdfac2  add rsp, 0x08
00007d5be8fdfac6  jmp 0x00007D5BE8FDC458
00007d5be8fdfacb  sub rsp, 0x08
00007d5be8fdfacf  push rax
00007d5be8fdfad0  push rcx
00007d5be8fdfad1  push rdx
00007d5be8fdfad2  push rdi
00007d5be8fdfad3  push rsi
00007d5be8fdfad4  push r8
00007d5be8fdfad6  push r9
00007d5be8fdfad8  push r10
00007d5be8fdfada  push r11
00007d5be8fdfadc  sub rsp, 0xF0
00007d5be8fdfae3  vmovaps [rsp], xmm0
00007d5be8fdfae8  vmovaps [rsp+0x10], xmm1
00007d5be8fdfaee  vmovaps [rsp+0x20], xmm2
00007d5be8fdfaf4  vmovaps [rsp+0x30], xmm3
00007d5be8fdfafa  vmovaps [rsp+0x40], xmm4
00007d5be8fdfb00  vmovaps [rsp+0x50], xmm5
00007d5be8fdfb06  vmovaps [rsp+0x60], xmm6
00007d5be8fdfb0c  vmovaps [rsp+0x70], xmm7
00007d5be8fdfb12  vmovaps [rsp+0x80], xmm8
00007d5be8fdfb1b  vmovaps [rsp+0x90], xmm9
00007d5be8fdfb24  vmovaps [rsp+0xA0], xmm10
00007d5be8fdfb2d  vmovaps [rsp+0xB0], xmm11
00007d5be8fdfb36  vmovaps [rsp+0xC0], xmm12
00007d5be8fdfb3f  vmovaps [rsp+0xD0], xmm13
00007d5be8fdfb48  vmovaps [rsp+0xE0], xmm14
00007d5be8fdfb51  sub rsp, 0x30
00007d5be8fdfb55  movaps [rsp], xmm15
00007d5be8fdfb5a  movaps [rsp+0x10], xmm1
00007d5be8fdfb5f  movaps [rsp+0x20], xmm5
00007d5be8fdfb64  lea rdi, [rsp]
00007d5be8fdfb68  mov esi, 0x00
00007d5be8fdfb6d  mov rax, 0x5D345705A530
00007d5be8fdfb77  call rax
00007d5be8fdfb79  movaps xmm15, [rsp]
00007d5be8fdfb7e  add rsp, 0x30
00007d5be8fdfb82  vmovaps xmm0, [rsp]
00007d5be8fdfb87  vmovaps xmm1, [rsp+0x10]
00007d5be8fdfb8d  vmovaps xmm2, [rsp+0x20]
00007d5be8fdfb93  vmovaps xmm3, [rsp+0x30]
00007d5be8fdfb99  vmovaps xmm4, [rsp+0x40]
00007d5be8fdfb9f  vmovaps xmm5, [rsp+0x50]
00007d5be8fdfba5  vmovaps xmm6, [rsp+0x60]
00007d5be8fdfbab  vmovaps xmm7, [rsp+0x70]
00007d5be8fdfbb1  vmovaps xmm8, [rsp+0x80]
00007d5be8fdfbba  vmovaps xmm9, [rsp+0x90]
00007d5be8fdfbc3  vmovaps xmm10, [rsp+0xA0]
00007d5be8fdfbcc  vmovaps xmm11, [rsp+0xB0]
00007d5be8fdfbd5  vmovaps xmm12, [rsp+0xC0]
00007d5be8fdfbde  vmovaps xmm13, [rsp+0xD0]
00007d5be8fdfbe7  vmovaps xmm14, [rsp+0xE0]
00007d5be8fdfbf0  add rsp, 0xF0
00007d5be8fdfbf7  pop r11
00007d5be8fdfbf9  pop r10
00007d5be8fdfbfb  pop r9
00007d5be8fdfbfd  pop r8
00007d5be8fdfbff  pop rsi
00007d5be8fdfc00  pop rdi
00007d5be8fdfc01  pop rdx
00007d5be8fdfc02  pop rcx
00007d5be8fdfc03  pop rax
00007d5be8fdfc04  add rsp, 0x08
00007d5be8fdfc08  jmp 0x00007D5BE8FDC473
00007d5be8fdfc0d  call 0x00007D5BE8EB52F0
00007d5be8fdfc12  jmp 0x00007D5BE8FDC4CE
00007d5be8fdfc17  sub rsp, 0x08
00007d5be8fdfc1b  push rax
00007d5be8fdfc1c  push rcx
00007d5be8fdfc1d  push rdx
00007d5be8fdfc1e  push rdi
00007d5be8fdfc1f  push rsi
00007d5be8fdfc20  push r8
00007d5be8fdfc22  push r9
00007d5be8fdfc24  push r10
00007d5be8fdfc26  push r11
00007d5be8fdfc28  sub rsp, 0xF0
00007d5be8fdfc2f  vmovaps [rsp], xmm0
00007d5be8fdfc34  vmovaps [rsp+0x10], xmm1
00007d5be8fdfc3a  vmovaps [rsp+0x20], xmm2
00007d5be8fdfc40  vmovaps [rsp+0x30], xmm3
00007d5be8fdfc46  vmovaps [rsp+0x40], xmm4
00007d5be8fdfc4c  vmovaps [rsp+0x50], xmm5
00007d5be8fdfc52  vmovaps [rsp+0x60], xmm6
00007d5be8fdfc58  vmovaps [rsp+0x70], xmm7
00007d5be8fdfc5e  vmovaps [rsp+0x80], xmm8
00007d5be8fdfc67  vmovaps [rsp+0x90], xmm10
00007d5be8fdfc70  vmovaps [rsp+0xA0], xmm11
00007d5be8fdfc79  vmovaps [rsp+0xB0], xmm12
00007d5be8fdfc82  vmovaps [rsp+0xC0], xmm13
00007d5be8fdfc8b  vmovaps [rsp+0xD0], xmm14
00007d5be8fdfc94  vmovaps [rsp+0xE0], xmm15
00007d5be8fdfc9d  sub rsp, 0x30
00007d5be8fdfca1  movaps [rsp], xmm9
00007d5be8fdfca6  movaps [rsp+0x10], xmm8
00007d5be8fdfcac  movaps [rsp+0x20], xmm11
00007d5be8fdfcb2  lea rdi, [rsp]
00007d5be8fdfcb6  mov esi, 0x00
00007d5be8fdfcbb  mov rax, 0x5D345705A530
00007d5be8fdfcc5  call rax
00007d5be8fdfcc7  movaps xmm9, [rsp]
00007d5be8fdfccc  add rsp, 0x30
00007d5be8fdfcd0  vmovaps xmm0, [rsp]
00007d5be8fdfcd5  vmovaps xmm1, [rsp+0x10]
00007d5be8fdfcdb  vmovaps xmm2, [rsp+0x20]
00007d5be8fdfce1  vmovaps xmm3, [rsp+0x30]
00007d5be8fdfce7  vmovaps xmm4, [rsp+0x40]
00007d5be8fdfced  vmovaps xmm5, [rsp+0x50]
00007d5be8fdfcf3  vmovaps xmm6, [rsp+0x60]
00007d5be8fdfcf9  vmovaps xmm7, [rsp+0x70]
00007d5be8fdfcff  vmovaps xmm8, [rsp+0x80]
00007d5be8fdfd08  vmovaps xmm10, [rsp+0x90]
00007d5be8fdfd11  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdfd1a  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdfd23  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdfd2c  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdfd35  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdfd3e  add rsp, 0xF0
00007d5be8fdfd45  pop r11
00007d5be8fdfd47  pop r10
00007d5be8fdfd49  pop r9
00007d5be8fdfd4b  pop r8
00007d5be8fdfd4d  pop rsi
00007d5be8fdfd4e  pop rdi
00007d5be8fdfd4f  pop rdx
00007d5be8fdfd50  pop rcx
00007d5be8fdfd51  pop rax
00007d5be8fdfd52  add rsp, 0x08
00007d5be8fdfd56  jmp 0x00007D5BE8FDC505
00007d5be8fdfd5b  sub rsp, 0x08
00007d5be8fdfd5f  push rax
00007d5be8fdfd60  push rcx
00007d5be8fdfd61  push rdx
00007d5be8fdfd62  push rdi
00007d5be8fdfd63  push rsi
00007d5be8fdfd64  push r8
00007d5be8fdfd66  push r9
00007d5be8fdfd68  push r10
00007d5be8fdfd6a  push r11
00007d5be8fdfd6c  sub rsp, 0xF0
00007d5be8fdfd73  vmovaps [rsp], xmm0
00007d5be8fdfd78  vmovaps [rsp+0x10], xmm1
00007d5be8fdfd7e  vmovaps [rsp+0x20], xmm2
00007d5be8fdfd84  vmovaps [rsp+0x30], xmm3
00007d5be8fdfd8a  vmovaps [rsp+0x40], xmm4
00007d5be8fdfd90  vmovaps [rsp+0x50], xmm5
00007d5be8fdfd96  vmovaps [rsp+0x60], xmm6
00007d5be8fdfd9c  vmovaps [rsp+0x70], xmm7
00007d5be8fdfda2  vmovaps [rsp+0x80], xmm8
00007d5be8fdfdab  vmovaps [rsp+0x90], xmm9
00007d5be8fdfdb4  vmovaps [rsp+0xA0], xmm10
00007d5be8fdfdbd  vmovaps [rsp+0xB0], xmm12
00007d5be8fdfdc6  vmovaps [rsp+0xC0], xmm13
00007d5be8fdfdcf  vmovaps [rsp+0xD0], xmm14
00007d5be8fdfdd8  vmovaps [rsp+0xE0], xmm15
00007d5be8fdfde1  sub rsp, 0x30
00007d5be8fdfde5  movaps [rsp], xmm11
00007d5be8fdfdea  movaps [rsp+0x10], xmm10
00007d5be8fdfdf0  movaps [rsp+0x20], xmm6
00007d5be8fdfdf5  lea rdi, [rsp]
00007d5be8fdfdf9  mov esi, 0x00
00007d5be8fdfdfe  mov rax, 0x5D345705A530
00007d5be8fdfe08  call rax
00007d5be8fdfe0a  movaps xmm11, [rsp]
00007d5be8fdfe0f  add rsp, 0x30
00007d5be8fdfe13  vmovaps xmm0, [rsp]
00007d5be8fdfe18  vmovaps xmm1, [rsp+0x10]
00007d5be8fdfe1e  vmovaps xmm2, [rsp+0x20]
00007d5be8fdfe24  vmovaps xmm3, [rsp+0x30]
00007d5be8fdfe2a  vmovaps xmm4, [rsp+0x40]
00007d5be8fdfe30  vmovaps xmm5, [rsp+0x50]
00007d5be8fdfe36  vmovaps xmm6, [rsp+0x60]
00007d5be8fdfe3c  vmovaps xmm7, [rsp+0x70]
00007d5be8fdfe42  vmovaps xmm8, [rsp+0x80]
00007d5be8fdfe4b  vmovaps xmm9, [rsp+0x90]
00007d5be8fdfe54  vmovaps xmm10, [rsp+0xA0]
00007d5be8fdfe5d  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdfe66  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdfe6f  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdfe78  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdfe81  add rsp, 0xF0
00007d5be8fdfe88  pop r11
00007d5be8fdfe8a  pop r10
00007d5be8fdfe8c  pop r9
00007d5be8fdfe8e  pop r8
00007d5be8fdfe90  pop rsi
00007d5be8fdfe91  pop rdi
00007d5be8fdfe92  pop rdx
00007d5be8fdfe93  pop rcx
00007d5be8fdfe94  pop rax
00007d5be8fdfe95  add rsp, 0x08
00007d5be8fdfe99  jmp 0x00007D5BE8FDC520
00007d5be8fdfe9e  sub rsp, 0x08
00007d5be8fdfea2  push rax
00007d5be8fdfea3  push rcx
00007d5be8fdfea4  push rdx
00007d5be8fdfea5  push rdi
00007d5be8fdfea6  push rsi
00007d5be8fdfea7  push r8
00007d5be8fdfea9  push r9
00007d5be8fdfeab  push r10
00007d5be8fdfead  push r11
00007d5be8fdfeaf  sub rsp, 0xF0
00007d5be8fdfeb6  vmovaps [rsp], xmm0
00007d5be8fdfebb  vmovaps [rsp+0x10], xmm1
00007d5be8fdfec1  vmovaps [rsp+0x20], xmm2
00007d5be8fdfec7  vmovaps [rsp+0x30], xmm3
00007d5be8fdfecd  vmovaps [rsp+0x40], xmm4
00007d5be8fdfed3  vmovaps [rsp+0x50], xmm5
00007d5be8fdfed9  vmovaps [rsp+0x60], xmm6
00007d5be8fdfedf  vmovaps [rsp+0x70], xmm7
00007d5be8fdfee5  vmovaps [rsp+0x80], xmm8
00007d5be8fdfeee  vmovaps [rsp+0x90], xmm9
00007d5be8fdfef7  vmovaps [rsp+0xA0], xmm11
00007d5be8fdff00  vmovaps [rsp+0xB0], xmm12
00007d5be8fdff09  vmovaps [rsp+0xC0], xmm13
00007d5be8fdff12  vmovaps [rsp+0xD0], xmm14
00007d5be8fdff1b  vmovaps [rsp+0xE0], xmm15
00007d5be8fdff24  sub rsp, 0x30
00007d5be8fdff28  movaps [rsp], xmm10
00007d5be8fdff2d  movaps [rsp+0x10], xmm14
00007d5be8fdff33  movaps [rsp+0x20], xmm4
00007d5be8fdff38  lea rdi, [rsp]
00007d5be8fdff3c  mov esi, 0x00
00007d5be8fdff41  mov rax, 0x5D345705A530
00007d5be8fdff4b  call rax
00007d5be8fdff4d  movaps xmm10, [rsp]
00007d5be8fdff52  add rsp, 0x30
00007d5be8fdff56  vmovaps xmm0, [rsp]
00007d5be8fdff5b  vmovaps xmm1, [rsp+0x10]
00007d5be8fdff61  vmovaps xmm2, [rsp+0x20]
00007d5be8fdff67  vmovaps xmm3, [rsp+0x30]
00007d5be8fdff6d  vmovaps xmm4, [rsp+0x40]
00007d5be8fdff73  vmovaps xmm5, [rsp+0x50]
00007d5be8fdff79  vmovaps xmm6, [rsp+0x60]
00007d5be8fdff7f  vmovaps xmm7, [rsp+0x70]
00007d5be8fdff85  vmovaps xmm8, [rsp+0x80]
00007d5be8fdff8e  vmovaps xmm9, [rsp+0x90]
00007d5be8fdff97  vmovaps xmm11, [rsp+0xA0]
00007d5be8fdffa0  vmovaps xmm12, [rsp+0xB0]
00007d5be8fdffa9  vmovaps xmm13, [rsp+0xC0]
00007d5be8fdffb2  vmovaps xmm14, [rsp+0xD0]
00007d5be8fdffbb  vmovaps xmm15, [rsp+0xE0]
00007d5be8fdffc4  add rsp, 0xF0
00007d5be8fdffcb  pop r11
00007d5be8fdffcd  pop r10
00007d5be8fdffcf  pop r9
00007d5be8fdffd1  pop r8
00007d5be8fdffd3  pop rsi
00007d5be8fdffd4  pop rdi
00007d5be8fdffd5  pop rdx
00007d5be8fdffd6  pop rcx
00007d5be8fdffd7  pop rax
00007d5be8fdffd8  add rsp, 0x08
00007d5be8fdffdc  jmp 0x00007D5BE8FDC53B
00007d5be8fdffe1  sub rsp, 0x08
00007d5be8fdffe5  push rax
00007d5be8fdffe6  push rcx
00007d5be8fdffe7  push rdx
00007d5be8fdffe8  push rdi
00007d5be8fdffe9  push rsi
00007d5be8fdffea  push r8
00007d5be8fdffec  push r9
00007d5be8fdffee  push r10
00007d5be8fdfff0  push r11
00007d5be8fdfff2  sub rsp, 0xF0
00007d5be8fdfff9  vmovaps [rsp], xmm0
00007d5be8fdfffe  vmovaps [rsp+0x10], xmm1
00007d5be8fe0004  vmovaps [rsp+0x20], xmm2
00007d5be8fe000a  vmovaps [rsp+0x30], xmm3
00007d5be8fe0010  vmovaps [rsp+0x40], xmm4
00007d5be8fe0016  vmovaps [rsp+0x50], xmm5
00007d5be8fe001c  vmovaps [rsp+0x60], xmm6
00007d5be8fe0022  vmovaps [rsp+0x70], xmm7
00007d5be8fe0028  vmovaps [rsp+0x80], xmm9
00007d5be8fe0031  vmovaps [rsp+0x90], xmm10
00007d5be8fe003a  vmovaps [rsp+0xA0], xmm11
00007d5be8fe0043  vmovaps [rsp+0xB0], xmm12
00007d5be8fe004c  vmovaps [rsp+0xC0], xmm13
00007d5be8fe0055  vmovaps [rsp+0xD0], xmm14
00007d5be8fe005e  vmovaps [rsp+0xE0], xmm15
00007d5be8fe0067  sub rsp, 0x30
00007d5be8fe006b  movaps [rsp], xmm8
00007d5be8fe0070  movaps [rsp+0x10], xmm1
00007d5be8fe0075  movaps [rsp+0x20], xmm14
00007d5be8fe007b  lea rdi, [rsp]
00007d5be8fe007f  mov esi, 0x00
00007d5be8fe0084  mov rax, 0x5D345705A530
00007d5be8fe008e  call rax
00007d5be8fe0090  movaps xmm8, [rsp]
00007d5be8fe0095  add rsp, 0x30
00007d5be8fe0099  vmovaps xmm0, [rsp]
00007d5be8fe009e  vmovaps xmm1, [rsp+0x10]
00007d5be8fe00a4  vmovaps xmm2, [rsp+0x20]
00007d5be8fe00aa  vmovaps xmm3, [rsp+0x30]
00007d5be8fe00b0  vmovaps xmm4, [rsp+0x40]
00007d5be8fe00b6  vmovaps xmm5, [rsp+0x50]
00007d5be8fe00bc  vmovaps xmm6, [rsp+0x60]
00007d5be8fe00c2  vmovaps xmm7, [rsp+0x70]
00007d5be8fe00c8  vmovaps xmm9, [rsp+0x80]
00007d5be8fe00d1  vmovaps xmm10, [rsp+0x90]
00007d5be8fe00da  vmovaps xmm11, [rsp+0xA0]
00007d5be8fe00e3  vmovaps xmm12, [rsp+0xB0]
00007d5be8fe00ec  vmovaps xmm13, [rsp+0xC0]
00007d5be8fe00f5  vmovaps xmm14, [rsp+0xD0]
00007d5be8fe00fe  vmovaps xmm15, [rsp+0xE0]
00007d5be8fe0107  add rsp, 0xF0
00007d5be8fe010e  pop r11
00007d5be8fe0110  pop r10
00007d5be8fe0112  pop r9
00007d5be8fe0114  pop r8
00007d5be8fe0116  pop rsi
00007d5be8fe0117  pop rdi
00007d5be8fe0118  pop rdx
00007d5be8fe0119  pop rcx
00007d5be8fe011a  pop rax
00007d5be8fe011b  add rsp, 0x08
00007d5be8fe011f  jmp 0x00007D5BE8FDC561
00007d5be8fe0124  sub rsp, 0x08
00007d5be8fe0128  push rax
00007d5be8fe0129  push rcx
00007d5be8fe012a  push rdx
00007d5be8fe012b  push rdi
00007d5be8fe012c  push rsi
00007d5be8fe012d  push r8
00007d5be8fe012f  push r9
00007d5be8fe0131  push r10
00007d5be8fe0133  push r11
00007d5be8fe0135  sub rsp, 0xF0
00007d5be8fe013c  vmovaps [rsp], xmm0
00007d5be8fe0141  vmovaps [rsp+0x10], xmm1
00007d5be8fe0147  vmovaps [rsp+0x20], xmm2
00007d5be8fe014d  vmovaps [rsp+0x30], xmm3
00007d5be8fe0153  vmovaps [rsp+0x40], xmm4
00007d5be8fe0159  vmovaps [rsp+0x50], xmm5
00007d5be8fe015f  vmovaps [rsp+0x60], xmm7
00007d5be8fe0165  vmovaps [rsp+0x70], xmm8
00007d5be8fe016b  vmovaps [rsp+0x80], xmm9
00007d5be8fe0174  vmovaps [rsp+0x90], xmm10
00007d5be8fe017d  vmovaps [rsp+0xA0], xmm11
00007d5be8fe0186  vmovaps [rsp+0xB0], xmm12
00007d5be8fe018f  vmovaps [rsp+0xC0], xmm13
00007d5be8fe0198  vmovaps [rsp+0xD0], xmm14
00007d5be8fe01a1  vmovaps [rsp+0xE0], xmm15
00007d5be8fe01aa  sub rsp, 0x30
00007d5be8fe01ae  movaps [rsp], xmm6
00007d5be8fe01b2  movaps [rsp+0x10], xmm1
00007d5be8fe01b7  movaps [rsp+0x20], xmm14
00007d5be8fe01bd  lea rdi, [rsp]
00007d5be8fe01c1  mov esi, 0x00
00007d5be8fe01c6  mov rax, 0x5D345705A530
00007d5be8fe01d0  call rax
00007d5be8fe01d2  movaps xmm6, [rsp]
00007d5be8fe01d6  add rsp, 0x30
00007d5be8fe01da  vmovaps xmm0, [rsp]
00007d5be8fe01df  vmovaps xmm1, [rsp+0x10]
00007d5be8fe01e5  vmovaps xmm2, [rsp+0x20]
00007d5be8fe01eb  vmovaps xmm3, [rsp+0x30]
00007d5be8fe01f1  vmovaps xmm4, [rsp+0x40]
00007d5be8fe01f7  vmovaps xmm5, [rsp+0x50]
00007d5be8fe01fd  vmovaps xmm7, [rsp+0x60]
00007d5be8fe0203  vmovaps xmm8, [rsp+0x70]
00007d5be8fe0209  vmovaps xmm9, [rsp+0x80]
00007d5be8fe0212  vmovaps xmm10, [rsp+0x90]
00007d5be8fe021b  vmovaps xmm11, [rsp+0xA0]
00007d5be8fe0224  vmovaps xmm12, [rsp+0xB0]
00007d5be8fe022d  vmovaps xmm13, [rsp+0xC0]
00007d5be8fe0236  vmovaps xmm14, [rsp+0xD0]
00007d5be8fe023f  vmovaps xmm15, [rsp+0xE0]
00007d5be8fe0248  add rsp, 0xF0
00007d5be8fe024f  pop r11
00007d5be8fe0251  pop r10
00007d5be8fe0253  pop r9
00007d5be8fe0255  pop r8
00007d5be8fe0257  pop rsi
00007d5be8fe0258  pop rdi
00007d5be8fe0259  pop rdx
00007d5be8fe025a  pop rcx
00007d5be8fe025b  pop rax
00007d5be8fe025c  add rsp, 0x08
00007d5be8fe0260  jmp 0x00007D5BE8FDC58D
00007d5be8fe0265  sub rsp, 0x08
00007d5be8fe0269  push rax
00007d5be8fe026a  push rcx
00007d5be8fe026b  push rdx
00007d5be8fe026c  push rdi
00007d5be8fe026d  push rsi
00007d5be8fe026e  push r8
00007d5be8fe0270  push r9
00007d5be8fe0272  push r10
00007d5be8fe0274  push r11
00007d5be8fe0276  sub rsp, 0xF0
00007d5be8fe027d  vmovaps [rsp], xmm0
00007d5be8fe0282  vmovaps [rsp+0x10], xmm1
00007d5be8fe0288  vmovaps [rsp+0x20], xmm2
00007d5be8fe028e  vmovaps [rsp+0x30], xmm3
00007d5be8fe0294  vmovaps [rsp+0x40], xmm4
00007d5be8fe029a  vmovaps [rsp+0x50], xmm5
00007d5be8fe02a0  vmovaps [rsp+0x60], xmm6
00007d5be8fe02a6  vmovaps [rsp+0x70], xmm7
00007d5be8fe02ac  vmovaps [rsp+0x80], xmm8
00007d5be8fe02b5  vmovaps [rsp+0x90], xmm9
00007d5be8fe02be  vmovaps [rsp+0xA0], xmm10
00007d5be8fe02c7  vmovaps [rsp+0xB0], xmm11
00007d5be8fe02d0  vmovaps [rsp+0xC0], xmm12
00007d5be8fe02d9  vmovaps [rsp+0xD0], xmm13
00007d5be8fe02e2  vmovaps [rsp+0xE0], xmm15
00007d5be8fe02eb  sub rsp, 0x30
00007d5be8fe02ef  movaps [rsp], xmm14
00007d5be8fe02f4  movaps [rsp+0x10], xmm12
00007d5be8fe02fa  movaps [rsp+0x20], xmm1
00007d5be8fe02ff  lea rdi, [rsp]
00007d5be8fe0303  mov esi, 0x00
00007d5be8fe0308  mov rax, 0x5D345705A530
00007d5be8fe0312  call rax
00007d5be8fe0314  movaps xmm14, [rsp]
00007d5be8fe0319  add rsp, 0x30
00007d5be8fe031d  vmovaps xmm0, [rsp]
00007d5be8fe0322  vmovaps xmm1, [rsp+0x10]
00007d5be8fe0328  vmovaps xmm2, [rsp+0x20]
00007d5be8fe032e  vmovaps xmm3, [rsp+0x30]
00007d5be8fe0334  vmovaps xmm4, [rsp+0x40]
00007d5be8fe033a  vmovaps xmm5, [rsp+0x50]
00007d5be8fe0340  vmovaps xmm6, [rsp+0x60]
00007d5be8fe0346  vmovaps xmm7, [rsp+0x70]
00007d5be8fe034c  vmovaps xmm8, [rsp+0x80]
00007d5be8fe0355  vmovaps xmm9, [rsp+0x90]
00007d5be8fe035e  vmovaps xmm10, [rsp+0xA0]
00007d5be8fe0367  vmovaps xmm11, [rsp+0xB0]
00007d5be8fe0370  vmovaps xmm12, [rsp+0xC0]
00007d5be8fe0379  vmovaps xmm13, [rsp+0xD0]
00007d5be8fe0382  vmovaps xmm15, [rsp+0xE0]
00007d5be8fe038b  add rsp, 0xF0
00007d5be8fe0392  pop r11
00007d5be8fe0394  pop r10
00007d5be8fe0396  pop r9
00007d5be8fe0398  pop r8
00007d5be8fe039a  pop rsi
00007d5be8fe039b  pop rdi
00007d5be8fe039c  pop rdx
00007d5be8fe039d  pop rcx
00007d5be8fe039e  pop rax
00007d5be8fe039f  add rsp, 0x08
00007d5be8fe03a3  jmp 0x00007D5BE8FDC5B3
00007d5be8fe03a8  sub rsp, 0x08
00007d5be8fe03ac  push rax
00007d5be8fe03ad  push rcx
00007d5be8fe03ae  push rdx
00007d5be8fe03af  push rdi
00007d5be8fe03b0  push rsi
00007d5be8fe03b1  push r8
00007d5be8fe03b3  push r9
00007d5be8fe03b5  push r10
00007d5be8fe03b7  push r11
00007d5be8fe03b9  sub rsp, 0xF0
00007d5be8fe03c0  vmovaps [rsp], xmm0
00007d5be8fe03c5  vmovaps [rsp+0x10], xmm2
00007d5be8fe03cb  vmovaps [rsp+0x20], xmm3
00007d5be8fe03d1  vmovaps [rsp+0x30], xmm4
00007d5be8fe03d7  vmovaps [rsp+0x40], xmm5
00007d5be8fe03dd  vmovaps [rsp+0x50], xmm6
00007d5be8fe03e3  vmovaps [rsp+0x60], xmm7
00007d5be8fe03e9  vmovaps [rsp+0x70], xmm8
00007d5be8fe03ef  vmovaps [rsp+0x80], xmm9
00007d5be8fe03f8  vmovaps [rsp+0x90], xmm10
00007d5be8fe0401  vmovaps [rsp+0xA0], xmm11
00007d5be8fe040a  vmovaps [rsp+0xB0], xmm12
00007d5be8fe0413  vmovaps [rsp+0xC0], xmm13
00007d5be8fe041c  vmovaps [rsp+0xD0], xmm14
00007d5be8fe0425  vmovaps [rsp+0xE0], xmm15
00007d5be8fe042e  sub rsp, 0x30
00007d5be8fe0432  movaps [rsp], xmm1
00007d5be8fe0436  movaps [rsp+0x10], xmm13
00007d5be8fe043c  movaps [rsp+0x20], xmm9
00007d5be8fe0442  lea rdi, [rsp]
00007d5be8fe0446  mov esi, 0x00
00007d5be8fe044b  mov rax, 0x5D345705A530
00007d5be8fe0455  call rax
00007d5be8fe0457  movaps xmm1, [rsp]
00007d5be8fe045b  add rsp, 0x30
00007d5be8fe045f  vmovaps xmm0, [rsp]
00007d5be8fe0464  vmovaps xmm2, [rsp+0x10]
00007d5be8fe046a  vmovaps xmm3, [rsp+0x20]
00007d5be8fe0470  vmovaps xmm4, [rsp+0x30]
00007d5be8fe0476  vmovaps xmm5, [rsp+0x40]
00007d5be8fe047c  vmovaps xmm6, [rsp+0x50]
00007d5be8fe0482  vmovaps xmm7, [rsp+0x60]
00007d5be8fe0488  vmovaps xmm8, [rsp+0x70]
00007d5be8fe048e  vmovaps xmm9, [rsp+0x80]
00007d5be8fe0497  vmovaps xmm10, [rsp+0x90]
00007d5be8fe04a0  vmovaps xmm11, [rsp+0xA0]
00007d5be8fe04a9  vmovaps xmm12, [rsp+0xB0]
00007d5be8fe04b2  vmovaps xmm13, [rsp+0xC0]
00007d5be8fe04bb  vmovaps xmm14, [rsp+0xD0]
00007d5be8fe04c4  vmovaps xmm15, [rsp+0xE0]
00007d5be8fe04cd  add rsp, 0xF0
00007d5be8fe04d4  pop r11
00007d5be8fe04d6  pop r10
00007d5be8fe04d8  pop r9
00007d5be8fe04da  pop r8
00007d5be8fe04dc  pop rsi
00007d5be8fe04dd  pop rdi
00007d5be8fe04de  pop rdx
00007d5be8fe04df  pop rcx
00007d5be8fe04e0  pop rax
00007d5be8fe04e1  add rsp, 0x08
00007d5be8fe04e5  jmp 0x00007D5BE8FDC5CD
00007d5be8fe04ea  sub rsp, 0x08
00007d5be8fe04ee  push rax
00007d5be8fe04ef  push rcx
00007d5be8fe04f0  push rdx
00007d5be8fe04f1  push rdi
00007d5be8fe04f2  push rsi
00007d5be8fe04f3  push r8
00007d5be8fe04f5  push r9
00007d5be8fe04f7  push r10
00007d5be8fe04f9  push r11
00007d5be8fe04fb  sub rsp, 0xF0
00007d5be8fe0502  vmovaps [rsp], xmm0
00007d5be8fe0507  vmovaps [rsp+0x10], xmm1
00007d5be8fe050d  vmovaps [rsp+0x20], xmm2
00007d5be8fe0513  vmovaps [rsp+0x30], xmm3
00007d5be8fe0519  vmovaps [rsp+0x40], xmm4
00007d5be8fe051f  vmovaps [rsp+0x50], xmm5
00007d5be8fe0525  vmovaps [rsp+0x60], xmm6
00007d5be8fe052b  vmovaps [rsp+0x70], xmm7
00007d5be8fe0531  vmovaps [rsp+0x80], xmm8
00007d5be8fe053a  vmovaps [rsp+0x90], xmm9
00007d5be8fe0543  vmovaps [rsp+0xA0], xmm10
00007d5be8fe054c  vmovaps [rsp+0xB0], xmm11
00007d5be8fe0555  vmovaps [rsp+0xC0], xmm13
00007d5be8fe055e  vmovaps [rsp+0xD0], xmm14
00007d5be8fe0567  vmovaps [rsp+0xE0], xmm15
00007d5be8fe0570  sub rsp, 0x30
00007d5be8fe0574  movaps [rsp], xmm12
00007d5be8fe0579  movaps [rsp+0x10], xmm7
00007d5be8fe057e  movaps [rsp+0x20], xmm13
00007d5be8fe0584  lea rdi, [rsp]
00007d5be8fe0588  mov esi, 0x00
00007d5be8fe058d  mov rax, 0x5D345705A530
00007d5be8fe0597  call rax
00007d5be8fe0599  movaps xmm12, [rsp]
00007d5be8fe059e  add rsp, 0x30
00007d5be8fe05a2  vmovaps xmm0, [rsp]
00007d5be8fe05a7  vmovaps xmm1, [rsp+0x10]
00007d5be8fe05ad  vmovaps xmm2, [rsp+0x20]
00007d5be8fe05b3  vmovaps xmm3, [rsp+0x30]
00007d5be8fe05b9  vmovaps xmm4, [rsp+0x40]
00007d5be8fe05bf  vmovaps xmm5, [rsp+0x50]
00007d5be8fe05c5  vmovaps xmm6, [rsp+0x60]
00007d5be8fe05cb  vmovaps xmm7, [rsp+0x70]
00007d5be8fe05d1  vmovaps xmm8, [rsp+0x80]
00007d5be8fe05da  vmovaps xmm9, [rsp+0x90]
00007d5be8fe05e3  vmovaps xmm10, [rsp+0xA0]
00007d5be8fe05ec  vmovaps xmm11, [rsp+0xB0]
00007d5be8fe05f5  vmovaps xmm13, [rsp+0xC0]
00007d5be8fe05fe  vmovaps xmm14, [rsp+0xD0]
00007d5be8fe0607  vmovaps xmm15, [rsp+0xE0]
00007d5be8fe0610  add rsp, 0xF0
00007d5be8fe0617  pop r11
00007d5be8fe0619  pop r10
00007d5be8fe061b  pop r9
00007d5be8fe061d  pop r8
00007d5be8fe061f  pop rsi
00007d5be8fe0620  pop rdi
00007d5be8fe0621  pop rdx
00007d5be8fe0622  pop rcx
00007d5be8fe0623  pop rax
00007d5be8fe0624  add rsp, 0x08
00007d5be8fe0628  jmp 0x00007D5BE8FDC5F4
00007d5be8fe062d  sub rsp, 0x08
00007d5be8fe0631  push rax
00007d5be8fe0632  push rcx
00007d5be8fe0633  push rdx
00007d5be8fe0634  push rdi
00007d5be8fe0635  push rsi
00007d5be8fe0636  push r8
00007d5be8fe0638  push r9
00007d5be8fe063a  push r10
00007d5be8fe063c  push r11
00007d5be8fe063e  sub rsp, 0xF0
00007d5be8fe0645  vmovaps [rsp], xmm0
00007d5be8fe064a  vmovaps [rsp+0x10], xmm1
00007d5be8fe0650  vmovaps [rsp+0x20], xmm2
00007d5be8fe0656  vmovaps [rsp+0x30], xmm3
00007d5be8fe065c  vmovaps [rsp+0x40], xmm4
00007d5be8fe0662  vmovaps [rsp+0x50], xmm5
00007d5be8fe0668  vmovaps [rsp+0x60], xmm6
00007d5be8fe066e  vmovaps [rsp+0x70], xmm7
00007d5be8fe0674  vmovaps [rsp+0x80], xmm8
00007d5be8fe067d  vmovaps [rsp+0x90], xmm9
00007d5be8fe0686  vmovaps [rsp+0xA0], xmm10
00007d5be8fe068f  vmovaps [rsp+0xB0], xmm11
00007d5be8fe0698  vmovaps [rsp+0xC0], xmm12
00007d5be8fe06a1  vmovaps [rsp+0xD0], xmm14
00007d5be8fe06aa  vmovaps [rsp+0xE0], xmm15
00007d5be8fe06b3  sub rsp, 0x30
00007d5be8fe06b7  movaps [rsp], xmm13
00007d5be8fe06bc  movaps [rsp+0x10], xmm15
00007d5be8fe06c2  movaps [rsp+0x20], xmm8
00007d5be8fe06c8  lea rdi, [rsp]
00007d5be8fe06cc  mov esi, 0x00
00007d5be8fe06d1  mov rax, 0x5D345705A530
00007d5be8fe06db  call rax
00007d5be8fe06dd  movaps xmm13, [rsp]
00007d5be8fe06e2  add rsp, 0x30
00007d5be8fe06e6  vmovaps xmm0, [rsp]
00007d5be8fe06eb  vmovaps xmm1, [rsp+0x10]
00007d5be8fe06f1  vmovaps xmm2, [rsp+0x20]
00007d5be8fe06f7  vmovaps xmm3, [rsp+0x30]
00007d5be8fe06fd  vmovaps xmm4, [rsp+0x40]
00007d5be8fe0703  vmovaps xmm5, [rsp+0x50]
00007d5be8fe0709  vmovaps xmm6, [rsp+0x60]
00007d5be8fe070f  vmovaps xmm7, [rsp+0x70]
00007d5be8fe0715  vmovaps xmm8, [rsp+0x80]
00007d5be8fe071e  vmovaps xmm9, [rsp+0x90]
00007d5be8fe0727  vmovaps xmm10, [rsp+0xA0]
00007d5be8fe0730  vmovaps xmm11, [rsp+0xB0]
00007d5be8fe0739  vmovaps xmm12, [rsp+0xC0]
00007d5be8fe0742  vmovaps xmm14, [rsp+0xD0]
00007d5be8fe074b  vmovaps xmm15, [rsp+0xE0]
00007d5be8fe0754  add rsp, 0xF0
00007d5be8fe075b  pop r11
00007d5be8fe075d  pop r10
00007d5be8fe075f  pop r9
00007d5be8fe0761  pop r8
00007d5be8fe0763  pop rsi
00007d5be8fe0764  pop rdi
00007d5be8fe0765  pop rdx
00007d5be8fe0766  pop rcx
00007d5be8fe0767  pop rax
00007d5be8fe0768  add rsp, 0x08
00007d5be8fe076c  jmp 0x00007D5BE8FDC60F
00007d5be8fe0771  sub rsp, 0x08
00007d5be8fe0775  push rax
00007d5be8fe0776  push rcx
00007d5be8fe0777  push rdx
00007d5be8fe0778  push rdi
00007d5be8fe0779  push rsi
00007d5be8fe077a  push r8
00007d5be8fe077c  push r9
00007d5be8fe077e  push r10
00007d5be8fe0780  push r11
00007d5be8fe0782  sub rsp, 0xF0
00007d5be8fe0789  vmovaps [rsp], xmm0
00007d5be8fe078e  vmovaps [rsp+0x10], xmm1
00007d5be8fe0794  vmovaps [rsp+0x20], xmm2
00007d5be8fe079a  vmovaps [rsp+0x30], xmm3
00007d5be8fe07a0  vmovaps [rsp+0x40], xmm4
00007d5be8fe07a6  vmovaps [rsp+0x50], xmm5
00007d5be8fe07ac  vmovaps [rsp+0x60], xmm6
00007d5be8fe07b2  vmovaps [rsp+0x70], xmm7
00007d5be8fe07b8  vmovaps [rsp+0x80], xmm9
00007d5be8fe07c1  vmovaps [rsp+0x90], xmm10
00007d5be8fe07ca  vmovaps [rsp+0xA0], xmm11
00007d5be8fe07d3  vmovaps [rsp+0xB0], xmm12
00007d5be8fe07dc  vmovaps [rsp+0xC0], xmm13
00007d5be8fe07e5  vmovaps [rsp+0xD0], xmm14
00007d5be8fe07ee  vmovaps [rsp+0xE0], xmm15
00007d5be8fe07f7  sub rsp, 0x30
00007d5be8fe07fb  movaps [rsp], xmm8
00007d5be8fe0800  movaps [rsp+0x10], xmm15
00007d5be8fe0806  movaps [rsp+0x20], xmm9
00007d5be8fe080c  lea rdi, [rsp]
00007d5be8fe0810  mov esi, 0x00
00007d5be8fe0815  mov rax, 0x5D345705A530
00007d5be8fe081f  call rax
00007d5be8fe0821  movaps xmm8, [rsp]
00007d5be8fe0826  add rsp, 0x30
00007d5be8fe082a  vmovaps xmm0, [rsp]
00007d5be8fe082f  vmovaps xmm1, [rsp+0x10]
00007d5be8fe0835  vmovaps xmm2, [rsp+0x20]
00007d5be8fe083b  vmovaps xmm3, [rsp+0x30]
00007d5be8fe0841  vmovaps xmm4, [rsp+0x40]
00007d5be8fe0847  vmovaps xmm5, [rsp+0x50]
00007d5be8fe084d  vmovaps xmm6, [rsp+0x60]
00007d5be8fe0853  vmovaps xmm7, [rsp+0x70]
00007d5be8fe0859  vmovaps xmm9, [rsp+0x80]
00007d5be8fe0862  vmovaps xmm10, [rsp+0x90]
00007d5be8fe086b  vmovaps xmm11, [rsp+0xA0]
00007d5be8fe0874  vmovaps xmm12, [rsp+0xB0]
00007d5be8fe087d  vmovaps xmm13, [rsp+0xC0]
00007d5be8fe0886  vmovaps xmm14, [rsp+0xD0]
00007d5be8fe088f  vmovaps xmm15, [rsp+0xE0]
00007d5be8fe0898  add rsp, 0xF0
00007d5be8fe089f  pop r11
00007d5be8fe08a1  pop r10
00007d5be8fe08a3  pop r9
00007d5be8fe08a5  pop r8
00007d5be8fe08a7  pop rsi
00007d5be8fe08a8  pop rdi
00007d5be8fe08a9  pop rdx
00007d5be8fe08aa  pop rcx
00007d5be8fe08ab  pop rax
00007d5be8fe08ac  add rsp, 0x08
00007d5be8fe08b0  jmp 0x00007D5BE8FDC63D
00007d5be8fe08b5  sub rsp, 0x08
00007d5be8fe08b9  push rax
00007d5be8fe08ba  push rcx
00007d5be8fe08bb  push rdx
00007d5be8fe08bc  push rdi
00007d5be8fe08bd  push rsi
00007d5be8fe08be  push r8
00007d5be8fe08c0  push r9
00007d5be8fe08c2  push r10
00007d5be8fe08c4  push r11
00007d5be8fe08c6  sub rsp, 0xF0
00007d5be8fe08cd  vmovaps [rsp], xmm0
00007d5be8fe08d2  vmovaps [rsp+0x10], xmm1
00007d5be8fe08d8  vmovaps [rsp+0x20], xmm2
00007d5be8fe08de  vmovaps [rsp+0x30], xmm3
00007d5be8fe08e4  vmovaps [rsp+0x40], xmm4
00007d5be8fe08ea  vmovaps [rsp+0x50], xmm5
00007d5be8fe08f0  vmovaps [rsp+0x60], xmm6
00007d5be8fe08f6  vmovaps [rsp+0x70], xmm7
00007d5be8fe08fc  vmovaps [rsp+0x80], xmm8
00007d5be8fe0905  vmovaps [rsp+0x90], xmm9
00007d5be8fe090e  vmovaps [rsp+0xA0], xmm10
00007d5be8fe0917  vmovaps [rsp+0xB0], xmm11
00007d5be8fe0920  vmovaps [rsp+0xC0], xmm12
00007d5be8fe0929  vmovaps [rsp+0xD0], xmm13
00007d5be8fe0932  vmovaps [rsp+0xE0], xmm14
00007d5be8fe093b  sub rsp, 0x30
00007d5be8fe093f  movaps [rsp], xmm15
00007d5be8fe0944  movaps [rsp+0x10], xmm11
00007d5be8fe094a  movaps [rsp+0x20], xmm6
00007d5be8fe094f  lea rdi, [rsp]
00007d5be8fe0953  mov esi, 0x00
00007d5be8fe0958  mov rax, 0x5D345705A530
00007d5be8fe0962  call rax
00007d5be8fe0964  movaps xmm15, [rsp]
00007d5be8fe0969  add rsp, 0x30
00007d5be8fe096d  vmovaps xmm0, [rsp]
00007d5be8fe0972  vmovaps xmm1, [rsp+0x10]
00007d5be8fe0978  vmovaps xmm2, [rsp+0x20]
00007d5be8fe097e  vmovaps xmm3, [rsp+0x30]
00007d5be8fe0984  vmovaps xmm4, [rsp+0x40]
00007d5be8fe098a  vmovaps xmm5, [rsp+0x50]
00007d5be8fe0990  vmovaps xmm6, [rsp+0x60]
00007d5be8fe0996  vmovaps xmm7, [rsp+0x70]
00007d5be8fe099c  vmovaps xmm8, [rsp+0x80]
00007d5be8fe09a5  vmovaps xmm9, [rsp+0x90]
00007d5be8fe09ae  vmovaps xmm10, [rsp+0xA0]
00007d5be8fe09b7  vmovaps xmm11, [rsp+0xB0]
00007d5be8fe09c0  vmovaps xmm12, [rsp+0xC0]
00007d5be8fe09c9  vmovaps xmm13, [rsp+0xD0]
00007d5be8fe09d2  vmovaps xmm14, [rsp+0xE0]
00007d5be8fe09db  add rsp, 0xF0
00007d5be8fe09e2  pop r11
00007d5be8fe09e4  pop r10
00007d5be8fe09e6  pop r9
00007d5be8fe09e8  pop r8
00007d5be8fe09ea  pop rsi
00007d5be8fe09eb  pop rdi
00007d5be8fe09ec  pop rdx
00007d5be8fe09ed  pop rcx
00007d5be8fe09ee  pop rax
00007d5be8fe09ef  add rsp, 0x08
00007d5be8fe09f3  jmp 0x00007D5BE8FDC658
00007d5be8fe09f8  sub rsp, 0x08
00007d5be8fe09fc  push rax
00007d5be8fe09fd  push rcx
00007d5be8fe09fe  push rdx
00007d5be8fe09ff  push rdi
00007d5be8fe0a00  push rsi
00007d5be8fe0a01  push r8
00007d5be8fe0a03  push r9
00007d5be8fe0a05  push r10
00007d5be8fe0a07  push r11
00007d5be8fe0a09  sub rsp, 0xF0
00007d5be8fe0a10  vmovaps [rsp], xmm0
00007d5be8fe0a15  vmovaps [rsp+0x10], xmm1
00007d5be8fe0a1b  vmovaps [rsp+0x20], xmm2
00007d5be8fe0a21  vmovaps [rsp+0x30], xmm3
00007d5be8fe0a27  vmovaps [rsp+0x40], xmm4
00007d5be8fe0a2d  vmovaps [rsp+0x50], xmm5
00007d5be8fe0a33  vmovaps [rsp+0x60], xmm6
00007d5be8fe0a39  vmovaps [rsp+0x70], xmm8
00007d5be8fe0a3f  vmovaps [rsp+0x80], xmm9
00007d5be8fe0a48  vmovaps [rsp+0x90], xmm10
00007d5be8fe0a51  vmovaps [rsp+0xA0], xmm11
00007d5be8fe0a5a  vmovaps [rsp+0xB0], xmm12
00007d5be8fe0a63  vmovaps [rsp+0xC0], xmm13
00007d5be8fe0a6c  vmovaps [rsp+0xD0], xmm14
00007d5be8fe0a75  vmovaps [rsp+0xE0], xmm15
00007d5be8fe0a7e  sub rsp, 0x30
00007d5be8fe0a82  movaps [rsp], xmm7
00007d5be8fe0a86  movaps [rsp+0x10], xmm11
00007d5be8fe0a8c  movaps [rsp+0x20], xmm9
00007d5be8fe0a92  lea rdi, [rsp]
00007d5be8fe0a96  mov esi, 0x00
00007d5be8fe0a9b  mov rax, 0x5D345705A530
00007d5be8fe0aa5  call rax
00007d5be8fe0aa7  movaps xmm7, [rsp]
00007d5be8fe0aab  add rsp, 0x30
00007d5be8fe0aaf  vmovaps xmm0, [rsp]
00007d5be8fe0ab4  vmovaps xmm1, [rsp+0x10]
00007d5be8fe0aba  vmovaps xmm2, [rsp+0x20]
00007d5be8fe0ac0  vmovaps xmm3, [rsp+0x30]
00007d5be8fe0ac6  vmovaps xmm4, [rsp+0x40]
00007d5be8fe0acc  vmovaps xmm5, [rsp+0x50]
00007d5be8fe0ad2  vmovaps xmm6, [rsp+0x60]
00007d5be8fe0ad8  vmovaps xmm8, [rsp+0x70]
00007d5be8fe0ade  vmovaps xmm9, [rsp+0x80]
00007d5be8fe0ae7  vmovaps xmm10, [rsp+0x90]
00007d5be8fe0af0  vmovaps xmm11, [rsp+0xA0]
00007d5be8fe0af9  vmovaps xmm12, [rsp+0xB0]
00007d5be8fe0b02  vmovaps xmm13, [rsp+0xC0]
00007d5be8fe0b0b  vmovaps xmm14, [rsp+0xD0]
00007d5be8fe0b14  vmovaps xmm15, [rsp+0xE0]
00007d5be8fe0b1d  add rsp, 0xF0
00007d5be8fe0b24  pop r11
00007d5be8fe0b26  pop r10
00007d5be8fe0b28  pop r9
00007d5be8fe0b2a  pop r8
00007d5be8fe0b2c  pop rsi
00007d5be8fe0b2d  pop rdi
00007d5be8fe0b2e  pop rdx
00007d5be8fe0b2f  pop rcx
00007d5be8fe0b30  pop rax
00007d5be8fe0b31  add rsp, 0x08
00007d5be8fe0b35  jmp 0x00007D5BE8FDC685
00007d5be8fe0b3a  sub rsp, 0x08
00007d5be8fe0b3e  push rax
00007d5be8fe0b3f  push rcx
00007d5be8fe0b40  push rdx
00007d5be8fe0b41  push rdi
00007d5be8fe0b42  push rsi
00007d5be8fe0b43  push r8
00007d5be8fe0b45  push r9
00007d5be8fe0b47  push r10
00007d5be8fe0b49  push r11
00007d5be8fe0b4b  sub rsp, 0xF0
00007d5be8fe0b52  vmovaps [rsp], xmm0
00007d5be8fe0b57  vmovaps [rsp+0x10], xmm1
00007d5be8fe0b5d  vmovaps [rsp+0x20], xmm2
00007d5be8fe0b63  vmovaps [rsp+0x30], xmm3
00007d5be8fe0b69  vmovaps [rsp+0x40], xmm4
00007d5be8fe0b6f  vmovaps [rsp+0x50], xmm5
00007d5be8fe0b75  vmovaps [rsp+0x60], xmm6
00007d5be8fe0b7b  vmovaps [rsp+0x70], xmm7
00007d5be8fe0b81  vmovaps [rsp+0x80], xmm8
00007d5be8fe0b8a  vmovaps [rsp+0x90], xmm9
00007d5be8fe0b93  vmovaps [rsp+0xA0], xmm10
00007d5be8fe0b9c  vmovaps [rsp+0xB0], xmm12
00007d5be8fe0ba5  vmovaps [rsp+0xC0], xmm13
00007d5be8fe0bae  vmovaps [rsp+0xD0], xmm14
00007d5be8fe0bb7  vmovaps [rsp+0xE0], xmm15
00007d5be8fe0bc0  sub rsp, 0x30
00007d5be8fe0bc4  movaps [rsp], xmm11
00007d5be8fe0bc9  movaps [rsp+0x10], xmm10
00007d5be8fe0bcf  movaps [rsp+0x20], xmm14
00007d5be8fe0bd5  lea rdi, [rsp]
00007d5be8fe0bd9  mov esi, 0x00
00007d5be8fe0bde  mov rax, 0x5D345705A530
00007d5be8fe0be8  call rax
00007d5be8fe0bea  movaps xmm11, [rsp]
00007d5be8fe0bef  add rsp, 0x30
00007d5be8fe0bf3  vmovaps xmm0, [rsp]
00007d5be8fe0bf8  vmovaps xmm1, [rsp+0x10]
00007d5be8fe0bfe  vmovaps xmm2, [rsp+0x20]
00007d5be8fe0c04  vmovaps xmm3, [rsp+0x30]
00007d5be8fe0c0a  vmovaps xmm4, [rsp+0x40]
00007d5be8fe0c10  vmovaps xmm5, [rsp+0x50]
00007d5be8fe0c16  vmovaps xmm6, [rsp+0x60]
00007d5be8fe0c1c  vmovaps xmm7, [rsp+0x70]
00007d5be8fe0c22  vmovaps xmm8, [rsp+0x80]
00007d5be8fe0c2b  vmovaps xmm9, [rsp+0x90]
00007d5be8fe0c34  vmovaps xmm10, [rsp+0xA0]
00007d5be8fe0c3d  vmovaps xmm12, [rsp+0xB0]
00007d5be8fe0c46  vmovaps xmm13, [rsp+0xC0]
00007d5be8fe0c4f  vmovaps xmm14, [rsp+0xD0]
00007d5be8fe0c58  vmovaps xmm15, [rsp+0xE0]
00007d5be8fe0c61  add rsp, 0xF0
00007d5be8fe0c68  pop r11
00007d5be8fe0c6a  pop r10
00007d5be8fe0c6c  pop r9
00007d5be8fe0c6e  pop r8
00007d5be8fe0c70  pop rsi
00007d5be8fe0c71  pop rdi
00007d5be8fe0c72  pop rdx
00007d5be8fe0c73  pop rcx
00007d5be8fe0c74  pop rax
00007d5be8fe0c75  add rsp, 0x08
00007d5be8fe0c79  jmp 0x00007D5BE8FDC6A0
00007d5be8fe0c7e  call 0x00007D5BE8EC33A0
00007d5be8fe0c83  jmp 0x00007D5BE8FDC6AA
00007d5be8fe0c88  sub rsp, 0x08
00007d5be8fe0c8c  push rax
00007d5be8fe0c8d  push rcx
00007d5be8fe0c8e  push rdx
00007d5be8fe0c8f  push rdi
00007d5be8fe0c90  push rsi
00007d5be8fe0c91  push r8
00007d5be8fe0c93  push r9
00007d5be8fe0c95  push r10
00007d5be8fe0c97  push r11
00007d5be8fe0c99  sub rsp, 0xF0
00007d5be8fe0ca0  vmovaps [rsp], xmm0
00007d5be8fe0ca5  vmovaps [rsp+0x10], xmm1
00007d5be8fe0cab  vmovaps [rsp+0x20], xmm2
00007d5be8fe0cb1  vmovaps [rsp+0x30], xmm3
00007d5be8fe0cb7  vmovaps [rsp+0x40], xmm4
00007d5be8fe0cbd  vmovaps [rsp+0x50], xmm5
00007d5be8fe0cc3  vmovaps [rsp+0x60], xmm6
00007d5be8fe0cc9  vmovaps [rsp+0x70], xmm7
00007d5be8fe0ccf  vmovaps [rsp+0x80], xmm8
00007d5be8fe0cd8  vmovaps [rsp+0x90], xmm9
00007d5be8fe0ce1  vmovaps [rsp+0xA0], xmm11
00007d5be8fe0cea  vmovaps [rsp+0xB0], xmm12
00007d5be8fe0cf3  vmovaps [rsp+0xC0], xmm13
00007d5be8fe0cfc  vmovaps [rsp+0xD0], xmm14
00007d5be8fe0d05  vmovaps [rsp+0xE0], xmm15
00007d5be8fe0d0e  sub rsp, 0x30
00007d5be8fe0d12  movaps [rsp], xmm10
00007d5be8fe0d17  movaps [rsp+0x10], xmm1
00007d5be8fe0d1c  movaps [rsp+0x20], xmm12
00007d5be8fe0d22  lea rdi, [rsp]
00007d5be8fe0d26  mov esi, 0x00
00007d5be8fe0d2b  mov rax, 0x5D345705A530
00007d5be8fe0d35  call rax
00007d5be8fe0d37  movaps xmm10, [rsp]
00007d5be8fe0d3c  add rsp, 0x30
00007d5be8fe0d40  vmovaps xmm0, [rsp]
00007d5be8fe0d45  vmovaps xmm1, [rsp+0x10]
00007d5be8fe0d4b  vmovaps xmm2, [rsp+0x20]
00007d5be8fe0d51  vmovaps xmm3, [rsp+0x30]
00007d5be8fe0d57  vmovaps xmm4, [rsp+0x40]
00007d5be8fe0d5d  vmovaps xmm5, [rsp+0x50]
00007d5be8fe0d63  vmovaps xmm6, [rsp+0x60]
00007d5be8fe0d69  vmovaps xmm7, [rsp+0x70]
00007d5be8fe0d6f  vmovaps xmm8, [rsp+0x80]
00007d5be8fe0d78  vmovaps xmm9, [rsp+0x90]
00007d5be8fe0d81  vmovaps xmm11, [rsp+0xA0]
00007d5be8fe0d8a  vmovaps xmm12, [rsp+0xB0]
00007d5be8fe0d93  vmovaps xmm13, [rsp+0xC0]
00007d5be8fe0d9c  vmovaps xmm14, [rsp+0xD0]
00007d5be8fe0da5  vmovaps xmm15, [rsp+0xE0]
00007d5be8fe0dae  add rsp, 0xF0
00007d5be8fe0db5  pop r11
00007d5be8fe0db7  pop r10
00007d5be8fe0db9  pop r9
00007d5be8fe0dbb  pop r8
00007d5be8fe0dbd  pop rsi
00007d5be8fe0dbe  pop rdi
00007d5be8fe0dbf  pop rdx
00007d5be8fe0dc0  pop rcx
00007d5be8fe0dc1  pop rax
00007d5be8fe0dc2  add rsp, 0x08
00007d5be8fe0dc6  jmp 0x00007D5BE8FDC6CD
00007d5be8fe0dcb  sub rsp, 0x08
00007d5be8fe0dcf  push rax
00007d5be8fe0dd0  push rcx
00007d5be8fe0dd1  push rdx
00007d5be8fe0dd2  push rdi
00007d5be8fe0dd3  push rsi
00007d5be8fe0dd4  push r8
00007d5be8fe0dd6  push r9
00007d5be8fe0dd8  push r10
00007d5be8fe0dda  push r11
00007d5be8fe0ddc  sub rsp, 0xF0
00007d5be8fe0de3  vmovaps [rsp], xmm0
00007d5be8fe0de8  vmovaps [rsp+0x10], xmm1
00007d5be8fe0dee  vmovaps [rsp+0x20], xmm2
00007d5be8fe0df4  vmovaps [rsp+0x30], xmm3
00007d5be8fe0dfa  vmovaps [rsp+0x40], xmm4
00007d5be8fe0e00  vmovaps [rsp+0x50], xmm5
00007d5be8fe0e06  vmovaps [rsp+0x60], xmm6
00007d5be8fe0e0c  vmovaps [rsp+0x70], xmm7
00007d5be8fe0e12  vmovaps [rsp+0x80], xmm8
00007d5be8fe0e1b  vmovaps [rsp+0x90], xmm9
00007d5be8fe0e24  vmovaps [rsp+0xA0], xmm10
00007d5be8fe0e2d  vmovaps [rsp+0xB0], xmm11
00007d5be8fe0e36  vmovaps [rsp+0xC0], xmm13
00007d5be8fe0e3f  vmovaps [rsp+0xD0], xmm14
00007d5be8fe0e48  vmovaps [rsp+0xE0], xmm15
00007d5be8fe0e51  sub rsp, 0x30
00007d5be8fe0e55  movaps [rsp], xmm12
00007d5be8fe0e5a  movaps [rsp+0x10], xmm14
00007d5be8fe0e60  movaps [rsp+0x20], xmm1
00007d5be8fe0e65  lea rdi, [rsp]
00007d5be8fe0e69  mov esi, 0x00
00007d5be8fe0e6e  mov rax, 0x5D345705A530
00007d5be8fe0e78  call rax
00007d5be8fe0e7a  movaps xmm12, [rsp]
00007d5be8fe0e7f  add rsp, 0x30
00007d5be8fe0e83  vmovaps xmm0, [rsp]
00007d5be8fe0e88  vmovaps xmm1, [rsp+0x10]
00007d5be8fe0e8e  vmovaps xmm2, [rsp+0x20]
00007d5be8fe0e94  vmovaps xmm3, [rsp+0x30]
00007d5be8fe0e9a  vmovaps xmm4, [rsp+0x40]
00007d5be8fe0ea0  vmovaps xmm5, [rsp+0x50]
00007d5be8fe0ea6  vmovaps xmm6, [rsp+0x60]
00007d5be8fe0eac  vmovaps xmm7, [rsp+0x70]
00007d5be8fe0eb2  vmovaps xmm8, [rsp+0x80]
00007d5be8fe0ebb  vmovaps xmm9, [rsp+0x90]
00007d5be8fe0ec4  vmovaps xmm10, [rsp+0xA0]
00007d5be8fe0ecd  vmovaps xmm11, [rsp+0xB0]
00007d5be8fe0ed6  vmovaps xmm13, [rsp+0xC0]
00007d5be8fe0edf  vmovaps xmm14, [rsp+0xD0]
00007d5be8fe0ee8  vmovaps xmm15, [rsp+0xE0]
00007d5be8fe0ef1  add rsp, 0xF0
00007d5be8fe0ef8  pop r11
00007d5be8fe0efa  pop r10
00007d5be8fe0efc  pop r9
00007d5be8fe0efe  pop r8
00007d5be8fe0f00  pop rsi
00007d5be8fe0f01  pop rdi
00007d5be8fe0f02  pop rdx
00007d5be8fe0f03  pop rcx
00007d5be8fe0f04  pop rax
00007d5be8fe0f05  add rsp, 0x08
00007d5be8fe0f09  jmp 0x00007D5BE8FDC6FC
00007d5be8fe0f0e  sub rsp, 0x08
00007d5be8fe0f12  push rax
00007d5be8fe0f13  push rcx
00007d5be8fe0f14  push rdx
00007d5be8fe0f15  push rdi
00007d5be8fe0f16  push rsi
00007d5be8fe0f17  push r8
00007d5be8fe0f19  push r9
00007d5be8fe0f1b  push r10
00007d5be8fe0f1d  push r11
00007d5be8fe0f1f  sub rsp, 0xF0
00007d5be8fe0f26  vmovaps [rsp], xmm0
00007d5be8fe0f2b  vmovaps [rsp+0x10], xmm1
00007d5be8fe0f31  vmovaps [rsp+0x20], xmm2
00007d5be8fe0f37  vmovaps [rsp+0x30], xmm3
00007d5be8fe0f3d  vmovaps [rsp+0x40], xmm4
00007d5be8fe0f43  vmovaps [rsp+0x50], xmm5
00007d5be8fe0f49  vmovaps [rsp+0x60], xmm6
00007d5be8fe0f4f  vmovaps [rsp+0x70], xmm7
00007d5be8fe0f55  vmovaps [rsp+0x80], xmm8
00007d5be8fe0f5e  vmovaps [rsp+0x90], xmm9
00007d5be8fe0f67  vmovaps [rsp+0xA0], xmm10
00007d5be8fe0f70  vmovaps [rsp+0xB0], xmm11
00007d5be8fe0f79  vmovaps [rsp+0xC0], xmm12
00007d5be8fe0f82  vmovaps [rsp+0xD0], xmm13
00007d5be8fe0f8b  vmovaps [rsp+0xE0], xmm15
00007d5be8fe0f94  sub rsp, 0x30
00007d5be8fe0f98  movaps [rsp], xmm14
00007d5be8fe0f9d  movaps [rsp+0x10], xmm9
00007d5be8fe0fa3  movaps [rsp+0x20], xmm1
00007d5be8fe0fa8  lea rdi, [rsp]
00007d5be8fe0fac  mov esi, 0x00
00007d5be8fe0fb1  mov rax, 0x5D345705A530
00007d5be8fe0fbb  call rax
00007d5be8fe0fbd  movaps xmm14, [rsp]
00007d5be8fe0fc2  add rsp, 0x30
00007d5be8fe0fc6  vmovaps xmm0, [rsp]
00007d5be8fe0fcb  vmovaps xmm1, [rsp+0x10]
00007d5be8fe0fd1  vmovaps xmm2, [rsp+0x20]
00007d5be8fe0fd7  vmovaps xmm3, [rsp+0x30]
00007d5be8fe0fdd  vmovaps xmm4, [rsp+0x40]
00007d5be8fe0fe3  vmovaps xmm5, [rsp+0x50]
00007d5be8fe0fe9  vmovaps xmm6, [rsp+0x60]
00007d5be8fe0fef  vmovaps xmm7, [rsp+0x70]
00007d5be8fe0ff5  vmovaps xmm8, [rsp+0x80]
00007d5be8fe0ffe  vmovaps xmm9, [rsp+0x90]
00007d5be8fe1007  vmovaps xmm10, [rsp+0xA0]
00007d5be8fe1010  vmovaps xmm11, [rsp+0xB0]
00007d5be8fe1019  vmovaps xmm12, [rsp+0xC0]
00007d5be8fe1022  vmovaps xmm13, [rsp+0xD0]
00007d5be8fe102b  vmovaps xmm15, [rsp+0xE0]
00007d5be8fe1034  add rsp, 0xF0
00007d5be8fe103b  pop r11
00007d5be8fe103d  pop r10
00007d5be8fe103f  pop r9
00007d5be8fe1041  pop r8
00007d5be8fe1043  pop rsi
00007d5be8fe1044  pop rdi
00007d5be8fe1045  pop rdx
00007d5be8fe1046  pop rcx
00007d5be8fe1047  pop rax
00007d5be8fe1048  add rsp, 0x08
00007d5be8fe104c  jmp 0x00007D5BE8FDC72B
00007d5be8fe1051  sub rsp, 0x08
00007d5be8fe1055  push rax
00007d5be8fe1056  push rcx
00007d5be8fe1057  push rdx
00007d5be8fe1058  push rdi
00007d5be8fe1059  push rsi
00007d5be8fe105a  push r8
00007d5be8fe105c  push r9
00007d5be8fe105e  push r10
00007d5be8fe1060  push r11
00007d5be8fe1062  sub rsp, 0xF0
00007d5be8fe1069  vmovaps [rsp], xmm0
00007d5be8fe106e  vmovaps [rsp+0x10], xmm2
00007d5be8fe1074  vmovaps [rsp+0x20], xmm3
00007d5be8fe107a  vmovaps [rsp+0x30], xmm4
00007d5be8fe1080  vmovaps [rsp+0x40], xmm5
00007d5be8fe1086  vmovaps [rsp+0x50], xmm6
00007d5be8fe108c  vmovaps [rsp+0x60], xmm7
00007d5be8fe1092  vmovaps [rsp+0x70], xmm8
00007d5be8fe1098  vmovaps [rsp+0x80], xmm9
00007d5be8fe10a1  vmovaps [rsp+0x90], xmm10
00007d5be8fe10aa  vmovaps [rsp+0xA0], xmm11
00007d5be8fe10b3  vmovaps [rsp+0xB0], xmm12
00007d5be8fe10bc  vmovaps [rsp+0xC0], xmm13
00007d5be8fe10c5  vmovaps [rsp+0xD0], xmm14
00007d5be8fe10ce  vmovaps [rsp+0xE0], xmm15
00007d5be8fe10d7  sub rsp, 0x30
00007d5be8fe10db  movaps [rsp], xmm1
00007d5be8fe10df  movaps [rsp+0x10], xmm13
00007d5be8fe10e5  movaps [rsp+0x20], xmm8
00007d5be8fe10eb  lea rdi, [rsp]
00007d5be8fe10ef  mov esi, 0x00
00007d5be8fe10f4  mov rax, 0x5D345705A530
00007d5be8fe10fe  call rax
00007d5be8fe1100  movaps xmm1, [rsp]
00007d5be8fe1104  add rsp, 0x30
00007d5be8fe1108  vmovaps xmm0, [rsp]
00007d5be8fe110d  vmovaps xmm2, [rsp+0x10]
00007d5be8fe1113  vmovaps xmm3, [rsp+0x20]
00007d5be8fe1119  vmovaps xmm4, [rsp+0x30]
00007d5be8fe111f  vmovaps xmm5, [rsp+0x40]
00007d5be8fe1125  vmovaps xmm6, [rsp+0x50]
00007d5be8fe112b  vmovaps xmm7, [rsp+0x60]
00007d5be8fe1131  vmovaps xmm8, [rsp+0x70]
00007d5be8fe1137  vmovaps xmm9, [rsp+0x80]
00007d5be8fe1140  vmovaps xmm10, [rsp+0x90]
00007d5be8fe1149  vmovaps xmm11, [rsp+0xA0]
00007d5be8fe1152  vmovaps xmm12, [rsp+0xB0]
00007d5be8fe115b  vmovaps xmm13, [rsp+0xC0]
00007d5be8fe1164  vmovaps xmm14, [rsp+0xD0]
00007d5be8fe116d  vmovaps xmm15, [rsp+0xE0]
00007d5be8fe1176  add rsp, 0xF0
00007d5be8fe117d  pop r11
00007d5be8fe117f  pop r10
00007d5be8fe1181  pop r9
00007d5be8fe1183  pop r8
00007d5be8fe1185  pop rsi
00007d5be8fe1186  pop rdi
00007d5be8fe1187  pop rdx
00007d5be8fe1188  pop rcx
00007d5be8fe1189  pop rax
00007d5be8fe118a  add rsp, 0x08
00007d5be8fe118e  jmp 0x00007D5BE8FDC74D
00007d5be8fe1193  call 0x00007D5BE8E0C260
00007d5be8fe1198  jmp 0x00007D5BE8FDC75B
00007d5be8fe119d  call 0x00007D5BE8EBD750
00007d5be8fe11a2  jmp 0x00007D5BE8FDC765
00007d5be8fe11a7  sub rsp, 0x08
00007d5be8fe11ab  push rax
00007d5be8fe11ac  push rcx
00007d5be8fe11ad  push rdx
00007d5be8fe11ae  push rdi
00007d5be8fe11af  push rsi
00007d5be8fe11b0  push r8
00007d5be8fe11b2  push r9
00007d5be8fe11b4  push r10
00007d5be8fe11b6  push r11
00007d5be8fe11b8  sub rsp, 0xF0
00007d5be8fe11bf  vmovaps [rsp], xmm0
00007d5be8fe11c4  vmovaps [rsp+0x10], xmm1
00007d5be8fe11ca  vmovaps [rsp+0x20], xmm2
00007d5be8fe11d0  vmovaps [rsp+0x30], xmm3
00007d5be8fe11d6  vmovaps [rsp+0x40], xmm4
00007d5be8fe11dc  vmovaps [rsp+0x50], xmm5
00007d5be8fe11e2  vmovaps [rsp+0x60], xmm6
00007d5be8fe11e8  vmovaps [rsp+0x70], xmm7
00007d5be8fe11ee  vmovaps [rsp+0x80], xmm9
00007d5be8fe11f7  vmovaps [rsp+0x90], xmm10
00007d5be8fe1200  vmovaps [rsp+0xA0], xmm11
00007d5be8fe1209  vmovaps [rsp+0xB0], xmm12
00007d5be8fe1212  vmovaps [rsp+0xC0], xmm13
00007d5be8fe121b  vmovaps [rsp+0xD0], xmm14
00007d5be8fe1224  vmovaps [rsp+0xE0], xmm15
00007d5be8fe122d  sub rsp, 0x30
00007d5be8fe1231  movaps [rsp], xmm8
00007d5be8fe1236  movaps [rsp+0x10], xmm15
00007d5be8fe123c  movaps [rsp+0x20], xmm7
00007d5be8fe1241  lea rdi, [rsp]
00007d5be8fe1245  mov esi, 0x00
00007d5be8fe124a  mov rax, 0x5D345705A530
00007d5be8fe1254  call rax
00007d5be8fe1256  movaps xmm8, [rsp]
00007d5be8fe125b  add rsp, 0x30
00007d5be8fe125f  vmovaps xmm0, [rsp]
00007d5be8fe1264  vmovaps xmm1, [rsp+0x10]
00007d5be8fe126a  vmovaps xmm2, [rsp+0x20]
00007d5be8fe1270  vmovaps xmm3, [rsp+0x30]
00007d5be8fe1276  vmovaps xmm4, [rsp+0x40]
00007d5be8fe127c  vmovaps xmm5, [rsp+0x50]
00007d5be8fe1282  vmovaps xmm6, [rsp+0x60]
00007d5be8fe1288  vmovaps xmm7, [rsp+0x70]
00007d5be8fe128e  vmovaps xmm9, [rsp+0x80]
00007d5be8fe1297  vmovaps xmm10, [rsp+0x90]
00007d5be8fe12a0  vmovaps xmm11, [rsp+0xA0]
00007d5be8fe12a9  vmovaps xmm12, [rsp+0xB0]
00007d5be8fe12b2  vmovaps xmm13, [rsp+0xC0]
00007d5be8fe12bb  vmovaps xmm14, [rsp+0xD0]
00007d5be8fe12c4  vmovaps xmm15, [rsp+0xE0]
00007d5be8fe12cd  add rsp, 0xF0
00007d5be8fe12d4  pop r11
00007d5be8fe12d6  pop r10
00007d5be8fe12d8  pop r9
00007d5be8fe12da  pop r8
00007d5be8fe12dc  pop rsi
00007d5be8fe12dd  pop rdi
00007d5be8fe12de  pop rdx
00007d5be8fe12df  pop rcx
00007d5be8fe12e0  pop rax
00007d5be8fe12e1  add rsp, 0x08
00007d5be8fe12e5  jmp 0x00007D5BE8FDC787
00007d5be8fe12ea  sub rsp, 0x08
00007d5be8fe12ee  push rax
00007d5be8fe12ef  push rcx
00007d5be8fe12f0  push rdx
00007d5be8fe12f1  push rdi
00007d5be8fe12f2  push rsi
00007d5be8fe12f3  push r8
00007d5be8fe12f5  push r9
00007d5be8fe12f7  push r10
00007d5be8fe12f9  push r11
00007d5be8fe12fb  sub rsp, 0xF0
00007d5be8fe1302  vmovaps [rsp], xmm0
00007d5be8fe1307  vmovaps [rsp+0x10], xmm1
00007d5be8fe130d  vmovaps [rsp+0x20], xmm2
00007d5be8fe1313  vmovaps [rsp+0x30], xmm3
00007d5be8fe1319  vmovaps [rsp+0x40], xmm4
00007d5be8fe131f  vmovaps [rsp+0x50], xmm5
00007d5be8fe1325  vmovaps [rsp+0x60], xmm6
00007d5be8fe132b  vmovaps [rsp+0x70], xmm8
00007d5be8fe1331  vmovaps [rsp+0x80], xmm9
00007d5be8fe133a  vmovaps [rsp+0x90], xmm10
00007d5be8fe1343  vmovaps [rsp+0xA0], xmm11
00007d5be8fe134c  vmovaps [rsp+0xB0], xmm12
00007d5be8fe1355  vmovaps [rsp+0xC0], xmm13
00007d5be8fe135e  vmovaps [rsp+0xD0], xmm14
00007d5be8fe1367  vmovaps [rsp+0xE0], xmm15
00007d5be8fe1370  sub rsp, 0x30
00007d5be8fe1374  movaps [rsp], xmm7
00007d5be8fe1378  movaps [rsp+0x10], xmm9
00007d5be8fe137e  movaps [rsp+0x20], xmm15
00007d5be8fe1384  lea rdi, [rsp]
00007d5be8fe1388  mov esi, 0x00
00007d5be8fe138d  mov rax, 0x5D345705A530
00007d5be8fe1397  call rax
00007d5be8fe1399  movaps xmm7, [rsp]
00007d5be8fe139d  add rsp, 0x30
00007d5be8fe13a1  vmovaps xmm0, [rsp]
00007d5be8fe13a6  vmovaps xmm1, [rsp+0x10]
00007d5be8fe13ac  vmovaps xmm2, [rsp+0x20]
00007d5be8fe13b2  vmovaps xmm3, [rsp+0x30]
00007d5be8fe13b8  vmovaps xmm4, [rsp+0x40]
00007d5be8fe13be  vmovaps xmm5, [rsp+0x50]
00007d5be8fe13c4  vmovaps xmm6, [rsp+0x60]
00007d5be8fe13ca  vmovaps xmm8, [rsp+0x70]
00007d5be8fe13d0  vmovaps xmm9, [rsp+0x80]
00007d5be8fe13d9  vmovaps xmm10, [rsp+0x90]
00007d5be8fe13e2  vmovaps xmm11, [rsp+0xA0]
00007d5be8fe13eb  vmovaps xmm12, [rsp+0xB0]
00007d5be8fe13f4  vmovaps xmm13, [rsp+0xC0]
00007d5be8fe13fd  vmovaps xmm14, [rsp+0xD0]
00007d5be8fe1406  vmovaps xmm15, [rsp+0xE0]
00007d5be8fe140f  add rsp, 0xF0
00007d5be8fe1416  pop r11
00007d5be8fe1418  pop r10
00007d5be8fe141a  pop r9
00007d5be8fe141c  pop r8
00007d5be8fe141e  pop rsi
00007d5be8fe141f  pop rdi
00007d5be8fe1420  pop rdx
00007d5be8fe1421  pop rcx
00007d5be8fe1422  pop rax
00007d5be8fe1423  add rsp, 0x08
00007d5be8fe1427  jmp 0x00007D5BE8FDC7B4
00007d5be8fe142c  sub rsp, 0x08
00007d5be8fe1430  push rax
00007d5be8fe1431  push rcx
00007d5be8fe1432  push rdx
00007d5be8fe1433  push rdi
00007d5be8fe1434  push rsi
00007d5be8fe1435  push r8
00007d5be8fe1437  push r9
00007d5be8fe1439  push r10
00007d5be8fe143b  push r11
00007d5be8fe143d  sub rsp, 0xF0
00007d5be8fe1444  vmovaps [rsp], xmm0
00007d5be8fe1449  vmovaps [rsp+0x10], xmm1
00007d5be8fe144f  vmovaps [rsp+0x20], xmm2
00007d5be8fe1455  vmovaps [rsp+0x30], xmm3
00007d5be8fe145b  vmovaps [rsp+0x40], xmm4
00007d5be8fe1461  vmovaps [rsp+0x50], xmm5
00007d5be8fe1467  vmovaps [rsp+0x60], xmm6
00007d5be8fe146d  vmovaps [rsp+0x70], xmm7
00007d5be8fe1473  vmovaps [rsp+0x80], xmm8
00007d5be8fe147c  vmovaps [rsp+0x90], xmm10
00007d5be8fe1485  vmovaps [rsp+0xA0], xmm11
00007d5be8fe148e  vmovaps [rsp+0xB0], xmm12
00007d5be8fe1497  vmovaps [rsp+0xC0], xmm13
00007d5be8fe14a0  vmovaps [rsp+0xD0], xmm14
00007d5be8fe14a9  vmovaps [rsp+0xE0], xmm15
00007d5be8fe14b2  sub rsp, 0x30
00007d5be8fe14b6  movaps [rsp], xmm9
00007d5be8fe14bb  movaps [rsp+0x10], xmm13
00007d5be8fe14c1  movaps [rsp+0x20], xmm15
00007d5be8fe14c7  lea rdi, [rsp]
00007d5be8fe14cb  mov esi, 0x00
00007d5be8fe14d0  mov rax, 0x5D345705A530
00007d5be8fe14da  call rax
00007d5be8fe14dc  movaps xmm9, [rsp]
00007d5be8fe14e1  add rsp, 0x30
00007d5be8fe14e5  vmovaps xmm0, [rsp]
00007d5be8fe14ea  vmovaps xmm1, [rsp+0x10]
00007d5be8fe14f0  vmovaps xmm2, [rsp+0x20]
00007d5be8fe14f6  vmovaps xmm3, [rsp+0x30]
00007d5be8fe14fc  vmovaps xmm4, [rsp+0x40]
00007d5be8fe1502  vmovaps xmm5, [rsp+0x50]
00007d5be8fe1508  vmovaps xmm6, [rsp+0x60]
00007d5be8fe150e  vmovaps xmm7, [rsp+0x70]
00007d5be8fe1514  vmovaps xmm8, [rsp+0x80]
00007d5be8fe151d  vmovaps xmm10, [rsp+0x90]
00007d5be8fe1526  vmovaps xmm11, [rsp+0xA0]
00007d5be8fe152f  vmovaps xmm12, [rsp+0xB0]
00007d5be8fe1538  vmovaps xmm13, [rsp+0xC0]
00007d5be8fe1541  vmovaps xmm14, [rsp+0xD0]
00007d5be8fe154a  vmovaps xmm15, [rsp+0xE0]
00007d5be8fe1553  add rsp, 0xF0
00007d5be8fe155a  pop r11
00007d5be8fe155c  pop r10
00007d5be8fe155e  pop r9
00007d5be8fe1560  pop r8
00007d5be8fe1562  pop rsi
00007d5be8fe1563  pop rdi
00007d5be8fe1564  pop rdx
00007d5be8fe1565  pop rcx
00007d5be8fe1566  pop rax
00007d5be8fe1567  add rsp, 0x08
00007d5be8fe156b  jmp 0x00007D5BE8FDC7E2
00007d5be8fe1570  sub rsp, 0x08
00007d5be8fe1574  push rax
00007d5be8fe1575  push rcx
00007d5be8fe1576  push rdx
00007d5be8fe1577  push rdi
00007d5be8fe1578  push rsi
00007d5be8fe1579  push r8
00007d5be8fe157b  push r9
00007d5be8fe157d  push r10
00007d5be8fe157f  push r11
00007d5be8fe1581  sub rsp, 0xF0
00007d5be8fe1588  vmovaps [rsp], xmm0
00007d5be8fe158d  vmovaps [rsp+0x10], xmm1
00007d5be8fe1593  vmovaps [rsp+0x20], xmm2
00007d5be8fe1599  vmovaps [rsp+0x30], xmm3
00007d5be8fe159f  vmovaps [rsp+0x40], xmm4
00007d5be8fe15a5  vmovaps [rsp+0x50], xmm5
00007d5be8fe15ab  vmovaps [rsp+0x60], xmm6
00007d5be8fe15b1  vmovaps [rsp+0x70], xmm7
00007d5be8fe15b7  vmovaps [rsp+0x80], xmm8
00007d5be8fe15c0  vmovaps [rsp+0x90], xmm9
00007d5be8fe15c9  vmovaps [rsp+0xA0], xmm10
00007d5be8fe15d2  vmovaps [rsp+0xB0], xmm11
00007d5be8fe15db  vmovaps [rsp+0xC0], xmm12
00007d5be8fe15e4  vmovaps [rsp+0xD0], xmm13
00007d5be8fe15ed  vmovaps [rsp+0xE0], xmm14
00007d5be8fe15f6  sub rsp, 0x30
00007d5be8fe15fa  movaps [rsp], xmm15
00007d5be8fe15ff  movaps [rsp+0x10], xmm11
00007d5be8fe1605  movaps [rsp+0x20], xmm12
00007d5be8fe160b  lea rdi, [rsp]
00007d5be8fe160f  mov esi, 0x00
00007d5be8fe1614  mov rax, 0x5D345705A530
00007d5be8fe161e  call rax
00007d5be8fe1620  movaps xmm15, [rsp]
00007d5be8fe1625  add rsp, 0x30
00007d5be8fe1629  vmovaps xmm0, [rsp]
00007d5be8fe162e  vmovaps xmm1, [rsp+0x10]
00007d5be8fe1634  vmovaps xmm2, [rsp+0x20]
00007d5be8fe163a  vmovaps xmm3, [rsp+0x30]
00007d5be8fe1640  vmovaps xmm4, [rsp+0x40]
00007d5be8fe1646  vmovaps xmm5, [rsp+0x50]
00007d5be8fe164c  vmovaps xmm6, [rsp+0x60]
00007d5be8fe1652  vmovaps xmm7, [rsp+0x70]
00007d5be8fe1658  vmovaps xmm8, [rsp+0x80]
00007d5be8fe1661  vmovaps xmm9, [rsp+0x90]
00007d5be8fe166a  vmovaps xmm10, [rsp+0xA0]
00007d5be8fe1673  vmovaps xmm11, [rsp+0xB0]
00007d5be8fe167c  vmovaps xmm12, [rsp+0xC0]
00007d5be8fe1685  vmovaps xmm13, [rsp+0xD0]
00007d5be8fe168e  vmovaps xmm14, [rsp+0xE0]
00007d5be8fe1697  add rsp, 0xF0
00007d5be8fe169e  pop r11
00007d5be8fe16a0  pop r10
00007d5be8fe16a2  pop r9
00007d5be8fe16a4  pop r8
00007d5be8fe16a6  pop rsi
00007d5be8fe16a7  pop rdi
00007d5be8fe16a8  pop rdx
00007d5be8fe16a9  pop rcx
00007d5be8fe16aa  pop rax
00007d5be8fe16ab  add rsp, 0x08
00007d5be8fe16af  jmp 0x00007D5BE8FDC7FD
00007d5be8fe16b4  sub rsp, 0x08
00007d5be8fe16b8  push rax
00007d5be8fe16b9  push rcx
00007d5be8fe16ba  push rdx
00007d5be8fe16bb  push rdi
00007d5be8fe16bc  push rsi
00007d5be8fe16bd  push r8
00007d5be8fe16bf  push r9
00007d5be8fe16c1  push r10
00007d5be8fe16c3  push r11
00007d5be8fe16c5  sub rsp, 0xF0
00007d5be8fe16cc  vmovaps [rsp], xmm0
00007d5be8fe16d1  vmovaps [rsp+0x10], xmm1
00007d5be8fe16d7  vmovaps [rsp+0x20], xmm2
00007d5be8fe16dd  vmovaps [rsp+0x30], xmm3
00007d5be8fe16e3  vmovaps [rsp+0x40], xmm4
00007d5be8fe16e9  vmovaps [rsp+0x50], xmm5
00007d5be8fe16ef  vmovaps [rsp+0x60], xmm6
00007d5be8fe16f5  vmovaps [rsp+0x70], xmm7
00007d5be8fe16fb  vmovaps [rsp+0x80], xmm8
00007d5be8fe1704  vmovaps [rsp+0x90], xmm9
00007d5be8fe170d  vmovaps [rsp+0xA0], xmm10
00007d5be8fe1716  vmovaps [rsp+0xB0], xmm11
00007d5be8fe171f  vmovaps [rsp+0xC0], xmm12
00007d5be8fe1728  vmovaps [rsp+0xD0], xmm14
00007d5be8fe1731  vmovaps [rsp+0xE0], xmm15
00007d5be8fe173a  sub rsp, 0x30
00007d5be8fe173e  movaps [rsp], xmm13
00007d5be8fe1743  movaps [rsp+0x10], xmm10
00007d5be8fe1749  movaps [rsp+0x20], xmm14
00007d5be8fe174f  lea rdi, [rsp]
00007d5be8fe1753  mov esi, 0x00
00007d5be8fe1758  mov rax, 0x5D345705A530
00007d5be8fe1762  call rax
00007d5be8fe1764  movaps xmm13, [rsp]
00007d5be8fe1769  add rsp, 0x30
00007d5be8fe176d  vmovaps xmm0, [rsp]
00007d5be8fe1772  vmovaps xmm1, [rsp+0x10]
00007d5be8fe1778  vmovaps xmm2, [rsp+0x20]
00007d5be8fe177e  vmovaps xmm3, [rsp+0x30]
00007d5be8fe1784  vmovaps xmm4, [rsp+0x40]
00007d5be8fe178a  vmovaps xmm5, [rsp+0x50]
00007d5be8fe1790  vmovaps xmm6, [rsp+0x60]
00007d5be8fe1796  vmovaps xmm7, [rsp+0x70]
00007d5be8fe179c  vmovaps xmm8, [rsp+0x80]
00007d5be8fe17a5  vmovaps xmm9, [rsp+0x90]
00007d5be8fe17ae  vmovaps xmm10, [rsp+0xA0]
00007d5be8fe17b7  vmovaps xmm11, [rsp+0xB0]
00007d5be8fe17c0  vmovaps xmm12, [rsp+0xC0]
00007d5be8fe17c9  vmovaps xmm14, [rsp+0xD0]
00007d5be8fe17d2  vmovaps xmm15, [rsp+0xE0]
00007d5be8fe17db  add rsp, 0xF0
00007d5be8fe17e2  pop r11
00007d5be8fe17e4  pop r10
00007d5be8fe17e6  pop r9
00007d5be8fe17e8  pop r8
00007d5be8fe17ea  pop rsi
00007d5be8fe17eb  pop rdi
00007d5be8fe17ec  pop rdx
00007d5be8fe17ed  pop rcx
00007d5be8fe17ee  pop rax
00007d5be8fe17ef  add rsp, 0x08
00007d5be8fe17f3  jmp 0x00007D5BE8FDC820
00007d5be8fe17f8  sub rsp, 0x08
00007d5be8fe17fc  push rax
00007d5be8fe17fd  push rcx
00007d5be8fe17fe  push rdx
00007d5be8fe17ff  push rdi
00007d5be8fe1800  push rsi
00007d5be8fe1801  push r8
00007d5be8fe1803  push r9
00007d5be8fe1805  push r10
00007d5be8fe1807  push r11
00007d5be8fe1809  sub rsp, 0xF0
00007d5be8fe1810  vmovaps [rsp], xmm0
00007d5be8fe1815  vmovaps [rsp+0x10], xmm1
00007d5be8fe181b  vmovaps [rsp+0x20], xmm2
00007d5be8fe1821  vmovaps [rsp+0x30], xmm3
00007d5be8fe1827  vmovaps [rsp+0x40], xmm4
00007d5be8fe182d  vmovaps [rsp+0x50], xmm5
00007d5be8fe1833  vmovaps [rsp+0x60], xmm6
00007d5be8fe1839  vmovaps [rsp+0x70], xmm7
00007d5be8fe183f  vmovaps [rsp+0x80], xmm8
00007d5be8fe1848  vmovaps [rsp+0x90], xmm9
00007d5be8fe1851  vmovaps [rsp+0xA0], xmm10
00007d5be8fe185a  vmovaps [rsp+0xB0], xmm11
00007d5be8fe1863  vmovaps [rsp+0xC0], xmm12
00007d5be8fe186c  vmovaps [rsp+0xD0], xmm13
00007d5be8fe1875  vmovaps [rsp+0xE0], xmm15
00007d5be8fe187e  sub rsp, 0x30
00007d5be8fe1882  movaps [rsp], xmm14
00007d5be8fe1887  movaps [rsp+0x10], xmm1
00007d5be8fe188c  movaps [rsp+0x20], xmm7
00007d5be8fe1891  lea rdi, [rsp]
00007d5be8fe1895  mov esi, 0x00
00007d5be8fe189a  mov rax, 0x5D345705A530
00007d5be8fe18a4  call rax
00007d5be8fe18a6  movaps xmm14, [rsp]
00007d5be8fe18ab  add rsp, 0x30
00007d5be8fe18af  vmovaps xmm0, [rsp]
00007d5be8fe18b4  vmovaps xmm1, [rsp+0x10]
00007d5be8fe18ba  vmovaps xmm2, [rsp+0x20]
00007d5be8fe18c0  vmovaps xmm3, [rsp+0x30]
00007d5be8fe18c6  vmovaps xmm4, [rsp+0x40]
00007d5be8fe18cc  vmovaps xmm5, [rsp+0x50]
00007d5be8fe18d2  vmovaps xmm6, [rsp+0x60]
00007d5be8fe18d8  vmovaps xmm7, [rsp+0x70]
00007d5be8fe18de  vmovaps xmm8, [rsp+0x80]
00007d5be8fe18e7  vmovaps xmm9, [rsp+0x90]
00007d5be8fe18f0  vmovaps xmm10, [rsp+0xA0]
00007d5be8fe18f9  vmovaps xmm11, [rsp+0xB0]
00007d5be8fe1902  vmovaps xmm12, [rsp+0xC0]
00007d5be8fe190b  vmovaps xmm13, [rsp+0xD0]
00007d5be8fe1914  vmovaps xmm15, [rsp+0xE0]
00007d5be8fe191d  add rsp, 0xF0
00007d5be8fe1924  pop r11
00007d5be8fe1926  pop r10
00007d5be8fe1928  pop r9
00007d5be8fe192a  pop r8
00007d5be8fe192c  pop rsi
00007d5be8fe192d  pop rdi
00007d5be8fe192e  pop rdx
00007d5be8fe192f  pop rcx
00007d5be8fe1930  pop rax
00007d5be8fe1931  add rsp, 0x08
00007d5be8fe1935  jmp 0x00007D5BE8FDC843
00007d5be8fe193a  sub rsp, 0x08
00007d5be8fe193e  push rax
00007d5be8fe193f  push rcx
00007d5be8fe1940  push rdx
00007d5be8fe1941  push rdi
00007d5be8fe1942  push rsi
00007d5be8fe1943  push r8
00007d5be8fe1945  push r9
00007d5be8fe1947  push r10
00007d5be8fe1949  push r11
00007d5be8fe194b  sub rsp, 0xF0
00007d5be8fe1952  vmovaps [rsp], xmm0
00007d5be8fe1957  vmovaps [rsp+0x10], xmm2
00007d5be8fe195d  vmovaps [rsp+0x20], xmm3
00007d5be8fe1963  vmovaps [rsp+0x30], xmm4
00007d5be8fe1969  vmovaps [rsp+0x40], xmm5
00007d5be8fe196f  vmovaps [rsp+0x50], xmm6
00007d5be8fe1975  vmovaps [rsp+0x60], xmm7
00007d5be8fe197b  vmovaps [rsp+0x70], xmm8
00007d5be8fe1981  vmovaps [rsp+0x80], xmm9
00007d5be8fe198a  vmovaps [rsp+0x90], xmm10
00007d5be8fe1993  vmovaps [rsp+0xA0], xmm11
00007d5be8fe199c  vmovaps [rsp+0xB0], xmm12
00007d5be8fe19a5  vmovaps [rsp+0xC0], xmm13
00007d5be8fe19ae  vmovaps [rsp+0xD0], xmm14
00007d5be8fe19b7  vmovaps [rsp+0xE0], xmm15
00007d5be8fe19c0  sub rsp, 0x30
00007d5be8fe19c4  movaps [rsp], xmm1
00007d5be8fe19c8  movaps [rsp+0x10], xmm8
00007d5be8fe19ce  movaps [rsp+0x20], xmm9
00007d5be8fe19d4  lea rdi, [rsp]
00007d5be8fe19d8  mov esi, 0x00
00007d5be8fe19dd  mov rax, 0x5D345705A530
00007d5be8fe19e7  call rax
00007d5be8fe19e9  movaps xmm1, [rsp]
00007d5be8fe19ed  add rsp, 0x30
00007d5be8fe19f1  vmovaps xmm0, [rsp]
00007d5be8fe19f6  vmovaps xmm2, [rsp+0x10]
00007d5be8fe19fc  vmovaps xmm3, [rsp+0x20]
00007d5be8fe1a02  vmovaps xmm4, [rsp+0x30]
00007d5be8fe1a08  vmovaps xmm5, [rsp+0x40]
00007d5be8fe1a0e  vmovaps xmm6, [rsp+0x50]
00007d5be8fe1a14  vmovaps xmm7, [rsp+0x60]
00007d5be8fe1a1a  vmovaps xmm8, [rsp+0x70]
00007d5be8fe1a20  vmovaps xmm9, [rsp+0x80]
00007d5be8fe1a29  vmovaps xmm10, [rsp+0x90]
00007d5be8fe1a32  vmovaps xmm11, [rsp+0xA0]
00007d5be8fe1a3b  vmovaps xmm12, [rsp+0xB0]
00007d5be8fe1a44  vmovaps xmm13, [rsp+0xC0]
00007d5be8fe1a4d  vmovaps xmm14, [rsp+0xD0]
00007d5be8fe1a56  vmovaps xmm15, [rsp+0xE0]
00007d5be8fe1a5f  add rsp, 0xF0
00007d5be8fe1a66  pop r11
00007d5be8fe1a68  pop r10
00007d5be8fe1a6a  pop r9
00007d5be8fe1a6c  pop r8
00007d5be8fe1a6e  pop rsi
00007d5be8fe1a6f  pop rdi
00007d5be8fe1a70  pop rdx
00007d5be8fe1a71  pop rcx
00007d5be8fe1a72  pop rax
00007d5be8fe1a73  add rsp, 0x08
00007d5be8fe1a77  jmp 0x00007D5BE8FDC865
00007d5be8fe1a7c  call 0x00007D5BE8EE5940
00007d5be8fe1a81  jmp 0x00007D5BE8FDC873
00007d5be8fe1a86  call 0x00007D5BE8E0C380
00007d5be8fe1a8b  jmp 0x00007D5BE8FDC87D
00007d5be8fe1a90  call 0x00007D5BE8E0D600
00007d5be8fe1a95  jmp 0x00007D5BE8FDC887
00007d5be8fe1a9a  call 0x00007D5BE8DFF540
00007d5be8fe1a9f  jmp 0x00007D5BE8FDC891
00007d5be8fe1aa4  int3
00007d5be8fe1aa5  nop [rax+rax*1], ax
00007d5be8fe1aae  nop
00007d5be8fe1ab0  mov rax, [r15+0xF8]
00007d5be8fe1ab7  lea r14, [rax+0x140]
00007d5be8fe1abe  mov r12, [r13+r14*1]
00007d5be8fe1ac3  mov [r15+0xE8], r12
00007d5be8fe1aca  lea r14, [rax+0x130]
00007d5be8fe1ad1  mov r12, [r13+r14*1]
00007d5be8fe1ad6  lea r14, [rax+0x138]
00007d5be8fe1add  mov r11, [r13+r14*1]
00007d5be8fe1ae2  movq xmm1, r12
00007d5be8fe1ae7  movq xmm15, r11
00007d5be8fe1aec  movq xmm1, xmm1
00007d5be8fe1af0  movq xmm1, xmm1
00007d5be8fe1af4  movaps [r15+0x1A0], xmm1
00007d5be8fe1afc  movq xmm15, xmm15
00007d5be8fe1b01  movq xmm15, xmm15
00007d5be8fe1b06  movaps [r15+0x190], xmm15
00007d5be8fe1b0e  lea r14, [rax+0x120]
00007d5be8fe1b15  mov r12, [r13+r14*1]
00007d5be8fe1b1a  lea r14, [rax+0x128]
00007d5be8fe1b21  mov r11, [r13+r14*1]
00007d5be8fe1b26  movq xmm1, r12
00007d5be8fe1b2b  movq xmm15, r11
00007d5be8fe1b30  movq xmm1, xmm1
00007d5be8fe1b34  movq xmm1, xmm1
00007d5be8fe1b38  movaps [r15+0x1C0], xmm1
00007d5be8fe1b40  movq xmm15, xmm15
00007d5be8fe1b45  movq xmm15, xmm15
00007d5be8fe1b4a  movaps [r15+0x1B0], xmm15
00007d5be8fe1b52  lea r14, [rax+0x110]
00007d5be8fe1b59  mov r12, [r13+r14*1]
00007d5be8fe1b5e  lea r14, [rax+0x118]
00007d5be8fe1b65  mov r11, [r13+r14*1]
00007d5be8fe1b6a  movq xmm1, r12
00007d5be8fe1b6f  movq xmm15, r11
00007d5be8fe1b74  movq xmm1, xmm1
00007d5be8fe1b78  movq xmm1, xmm1
00007d5be8fe1b7c  movaps [r15+0x1E0], xmm1
00007d5be8fe1b84  movq xmm15, xmm15
00007d5be8fe1b89  movq xmm15, xmm15
00007d5be8fe1b8e  movaps [r15+0x1D0], xmm15
00007d5be8fe1b96  lea r14, [rax+0x100]
00007d5be8fe1b9d  mov r12, [r13+r14*1]
00007d5be8fe1ba2  lea r14, [rax+0x108]
00007d5be8fe1ba9  mov r11, [r13+r14*1]
00007d5be8fe1bae  movq xmm1, r12
00007d5be8fe1bb3  movq xmm15, r11
00007d5be8fe1bb8  movq xmm1, xmm1
00007d5be8fe1bbc  movq xmm1, xmm1
00007d5be8fe1bc0  movaps [r15+0x200], xmm1
00007d5be8fe1bc8  movq xmm15, xmm15
00007d5be8fe1bcd  movq xmm15, xmm15
00007d5be8fe1bd2  movaps [r15+0x1F0], xmm15
00007d5be8fe1bda  mov qword ptr [r15+0x40], 0x430000
00007d5be8fe1be2  mov r14d, 0x430510
00007d5be8fe1be8  mov r12, [r13+r14*1]
00007d5be8fe1bed  movq xmm1, r12
00007d5be8fe1bf2  lea r14, [rax+0x150]
00007d5be8fe1bf9  mov [r15+0xF8], r14
00007d5be8fe1c00  mov rax, [r15+0x50]
00007d5be8fe1c04  movups xmm15, [r13+rax*1]
00007d5be8fe1c0a  movaps [r15+0x120], xmm15
00007d5be8fe1c12  mov qword ptr [r15+0x48], 0x10
00007d5be8fe1c1a  xor eax, eax
00007d5be8fe1c1c  mov r14d, 0x10
00007d5be8fe1c22  mov r12d, 0x200
00007d5be8fe1c28  cmp r14, r12
00007d5be8fe1c2b  cmc
00007d5be8fe1c2c  lahf
00007d5be8fe1c2d  seto al
00007d5be8fe1c30  mov [r15+0x108], eax
00007d5be8fe1c37  pextrq rax, xmm15, 0x01
00007d5be8fe1c3e  movq xmm14, rax
00007d5be8fe1c43  movaps [r15+0x130], xmm14
00007d5be8fe1c4b  movq rax, xmm1
00007d5be8fe1c50  movq r14, xmm15
00007d5be8fe1c55  vmovq xmm1, rax
00007d5be8fe1c5a  vmovq xmm15, r14
00007d5be8fe1c5f  movaps xmm13, xmm1
00007d5be8fe1c63  addsd xmm13, xmm15
00007d5be8fe1c68  ucomisd xmm13, xmm13
00007d5be8fe1c6d  jp 0x00007D5BE8FE1D86
00007d5be8fe1c73  movq xmm13, xmm13
00007d5be8fe1c78  movq rax, xmm13
00007d5be8fe1c7d  movq r14, xmm14
00007d5be8fe1c82  vmovq xmm1, rax
00007d5be8fe1c87  vmovq xmm15, r14
00007d5be8fe1c8c  movaps xmm14, xmm1
00007d5be8fe1c90  addsd xmm14, xmm15
00007d5be8fe1c95  ucomisd xmm14, xmm14
00007d5be8fe1c9a  jp 0x00007D5BE8FE1DCE
00007d5be8fe1ca0  movq xmm14, xmm14
00007d5be8fe1ca5  movaps [r15+0x110], xmm14
00007d5be8fe1cad  mov eax, [r15+0x108]
00007d5be8fe1cb4  sahf
00007d5be8fe1cb5  jnz 0x00007D5BE8FE1CE7
00007d5be8fe1cb7  cmp dword ptr [r15+0x318], 0x00
00007d5be8fe1cbf  jz 0x00007D5BE8FE1FE0
00007d5be8fe1cc5  nop [rax+rax*1], ax
00007d5be8fe1cce  nop [rax+rax*1], eax
00007d5be8fe1cd6  mov eax, 0x410490
00007d5be8fe1cdb  mov [r15+0x100], rax
00007d5be8fe1ce2  jmp 0x00007D5BE8DFE110
00007d5be8fe1ce7  cmp dword ptr [r15+0x318], 0x00
00007d5be8fe1cef  jz 0x00007D5BE8FE1E20
00007d5be8fe1cf5  nop [rax+rax*1], ax
00007d5be8fe1cfe  nop [rax+rax*1], eax
00007d5be8fe1d06  mov eax, 0x410474
00007d5be8fe1d0b  mov [r15+0x100], rax
00007d5be8fe1d12  jmp 0x00007D5BE8DFE110
00007d5be8fe1d17  int3
00007d5be8fe1d18  call 0x00007D5BE8EE27E0
00007d5be8fe1d1d  jmp 0x00007D5BE8FE1AC3
00007d5be8fe1d22  call 0x00007D5BE8EE27E0
00007d5be8fe1d27  jmp 0x00007D5BE8FE1AD6
00007d5be8fe1d2c  call 0x00007D5BE8EE1570
00007d5be8fe1d31  jmp 0x00007D5BE8FE1AE2
00007d5be8fe1d36  call 0x00007D5BE8EE27E0
00007d5be8fe1d3b  jmp 0x00007D5BE8FE1B1A
00007d5be8fe1d40  call 0x00007D5BE8EE1570
00007d5be8fe1d45  jmp 0x00007D5BE8FE1B26
00007d5be8fe1d4a  call 0x00007D5BE8EE27E0
00007d5be8fe1d4f  jmp 0x00007D5BE8FE1B5E
00007d5be8fe1d54  call 0x00007D5BE8EE1570
00007d5be8fe1d59  jmp 0x00007D5BE8FE1B6A
00007d5be8fe1d5e  call 0x00007D5BE8EE27E0
00007d5be8fe1d63  jmp 0x00007D5BE8FE1BA2
00007d5be8fe1d68  call 0x00007D5BE8EE1570
00007d5be8fe1d6d  jmp 0x00007D5BE8FE1BAE
00007d5be8fe1d72  call 0x00007D5BE8EE27E0
00007d5be8fe1d77  jmp 0x00007D5BE8FE1BED
00007d5be8fe1d7c  call 0x00007D5BE8E0E760
00007d5be8fe1d81  jmp 0x00007D5BE8FE1C0A
00007d5be8fe1d86  ucomisd xmm1, xmm15
00007d5be8fe1d8b  jp 0x00007D5BE8FE1D9A
00007d5be8fe1d8d  movaps xmm13, [0x00007D5BE8BFE060]
00007d5be8fe1d95  jmp 0x00007D5BE8FE1C73
00007d5be8fe1d9a  vxorps xmm0, xmm1, xmm15
00007d5be8fe1d9f  pextrw eax, xmm0, 0x03
00007d5be8fe1da4  and eax, 0x7FF8
00007d5be8fe1da9  cmp eax, 0x08
00007d5be8fe1dac  jnz 0x00007D5BE8FE1C73
00007d5be8fe1db2  movq rax, xmm15
00007d5be8fe1db7  shl rax, 0x0D
00007d5be8fe1dbb  jbe 0x00007D5BE8FE1C73
00007d5be8fe1dc1  vorps xmm13, xmm15, [0x00007D5BE8BFE070]
00007d5be8fe1dc9  jmp 0x00007D5BE8FE1C73
00007d5be8fe1dce  ucomisd xmm1, xmm15
00007d5be8fe1dd3  jp 0x00007D5BE8FE1DE2
00007d5be8fe1dd5  movaps xmm14, [0x00007D5BE8BFE060]
00007d5be8fe1ddd  jmp 0x00007D5BE8FE1CA0
00007d5be8fe1de2  vxorps xmm0, xmm1, xmm15
00007d5be8fe1de7  pextrw eax, xmm0, 0x03
00007d5be8fe1dec  and eax, 0x7FF8
00007d5be8fe1df1  cmp eax, 0x08
00007d5be8fe1df4  jnz 0x00007D5BE8FE1CA0
00007d5be8fe1dfa  movq rax, xmm15
00007d5be8fe1dff  shl rax, 0x0D
00007d5be8fe1e03  jbe 0x00007D5BE8FE1CA0
00007d5be8fe1e09  vorps xmm14, xmm15, [0x00007D5BE8BFE070]
00007d5be8fe1e11  jmp 0x00007D5BE8FE1CA0
00007d5be8fe1e16  int3
00007d5be8fe1e17  nop [rax+rax*1], ax
00007d5be8fe1e20  mov rax, [r15+0x48]
00007d5be8fe1e24  mov r14, [r15+0x50]
00007d5be8fe1e28  lea r12, [r14+rax*1]
00007d5be8fe1e2c  movups xmm1, [r13+r12*1]
00007d5be8fe1e32  movaps [r15+0x120], xmm1
00007d5be8fe1e3a  lea r14, [rax+0x10]
00007d5be8fe1e3e  mov [r15+0x48], r14
00007d5be8fe1e42  xor eax, eax
00007d5be8fe1e44  mov r12d, 0x200
00007d5be8fe1e4a  cmp r14, r12
00007d5be8fe1e4d  cmc
00007d5be8fe1e4e  lahf
00007d5be8fe1e4f  seto al
00007d5be8fe1e52  mov [r15+0x108], eax
00007d5be8fe1e59  pextrq rax, xmm1, 0x01
00007d5be8fe1e60  movq xmm15, rax
00007d5be8fe1e65  movaps [r15+0x130], xmm15
00007d5be8fe1e6d  movaps xmm14, [r15+0x110]
00007d5be8fe1e75  movq rax, xmm14
00007d5be8fe1e7a  movq r14, xmm1
00007d5be8fe1e7f  vmovq xmm1, rax
00007d5be8fe1e84  vmovq xmm14, r14
00007d5be8fe1e89  movaps xmm13, xmm1
00007d5be8fe1e8d  addsd xmm13, xmm14
00007d5be8fe1e92  ucomisd xmm13, xmm13
00007d5be8fe1e97  jp 0x00007D5BE8FE1F4C
00007d5be8fe1e9d  movq xmm13, xmm13
00007d5be8fe1ea2  movq rax, xmm13
00007d5be8fe1ea7  movq r14, xmm15
00007d5be8fe1eac  vmovq xmm1, rax
00007d5be8fe1eb1  vmovq xmm15, r14
00007d5be8fe1eb6  movaps xmm14, xmm1
00007d5be8fe1eba  addsd xmm14, xmm15
00007d5be8fe1ebf  ucomisd xmm14, xmm14
00007d5be8fe1ec4  jp 0x00007D5BE8FE1F94
00007d5be8fe1eca  movq xmm14, xmm14
00007d5be8fe1ecf  movaps [r15+0x110], xmm14
00007d5be8fe1ed7  mov eax, [r15+0x108]
00007d5be8fe1ede  sahf
00007d5be8fe1edf  jnz 0x00007D5BE8FE1F11
00007d5be8fe1ee1  cmp dword ptr [r15+0x318], 0x00
00007d5be8fe1ee9  jz 0x00007D5BE8FE1FE0
00007d5be8fe1eef  nop [rax+rax*1], ax
00007d5be8fe1ef8  nop [rax+rax*1], eax
00007d5be8fe1f00  mov eax, 0x410490
00007d5be8fe1f05  mov [r15+0x100], rax
00007d5be8fe1f0c  jmp 0x00007D5BE8DFE110
00007d5be8fe1f11  cmp dword ptr [r15+0x318], 0x00
00007d5be8fe1f19  jz 0x00007D5BE8FE1E20
00007d5be8fe1f1f  nop [rax+rax*1], ax
00007d5be8fe1f28  nop [rax+rax*1], eax
00007d5be8fe1f30  mov eax, 0x410474
00007d5be8fe1f35  mov [r15+0x100], rax
00007d5be8fe1f3c  jmp 0x00007D5BE8DFE110
00007d5be8fe1f41  int3
00007d5be8fe1f42  call 0x00007D5BE8EB52F0
00007d5be8fe1f47  jmp 0x00007D5BE8FE1E32
00007d5be8fe1f4c  ucomisd xmm1, xmm14
00007d5be8fe1f51  jp 0x00007D5BE8FE1F60
00007d5be8fe1f53  movaps xmm13, [0x00007D5BE8BFE060]
00007d5be8fe1f5b  jmp 0x00007D5BE8FE1E9D
00007d5be8fe1f60  vxorps xmm0, xmm1, xmm14
00007d5be8fe1f65  pextrw eax, xmm0, 0x03
00007d5be8fe1f6a  and eax, 0x7FF8
00007d5be8fe1f6f  cmp eax, 0x08
00007d5be8fe1f72  jnz 0x00007D5BE8FE1E9D
00007d5be8fe1f78  movq rax, xmm14
00007d5be8fe1f7d  shl rax, 0x0D
00007d5be8fe1f81  jbe 0x00007D5BE8FE1E9D
00007d5be8fe1f87  vorps xmm13, xmm14, [0x00007D5BE8BFE070]
00007d5be8fe1f8f  jmp 0x00007D5BE8FE1E9D
00007d5be8fe1f94  ucomisd xmm1, xmm15
00007d5be8fe1f99  jp 0x00007D5BE8FE1FA8
00007d5be8fe1f9b  movaps xmm14, [0x00007D5BE8BFE060]
00007d5be8fe1fa3  jmp 0x00007D5BE8FE1ECA
00007d5be8fe1fa8  vxorps xmm0, xmm1, xmm15
00007d5be8fe1fad  pextrw eax, xmm0, 0x03
00007d5be8fe1fb2  and eax, 0x7FF8
00007d5be8fe1fb7  cmp eax, 0x08
00007d5be8fe1fba  jnz 0x00007D5BE8FE1ECA
00007d5be8fe1fc0  movq rax, xmm15
00007d5be8fe1fc5  shl rax, 0x0D
00007d5be8fe1fc9  jbe 0x00007D5BE8FE1ECA
00007d5be8fe1fcf  vorps xmm14, xmm15, [0x00007D5BE8BFE070]
00007d5be8fe1fd7  jmp 0x00007D5BE8FE1ECA
00007d5be8fe1fdc  int3
00007d5be8fe1fdd  nop [rax], eax
00007d5be8fe1fe0  mov rax, [r15+0x40]
00007d5be8fe1fe4  lea r14, [rax+0x510]
00007d5be8fe1feb  movaps xmm1, [r15+0x110]
00007d5be8fe1ff3  movq rax, xmm1
00007d5be8fe1ff8  mov [r13+r14*1], rax
00007d5be8fe1ffd  mov rax, [r15+0xF0]
00007d5be8fe2004  mov [r15+0x100], rax
00007d5be8fe200b  jmp 0x00007D5BE8FCE5C0
00007d5be8fe2010  int3
00007d5be8fe2011  call 0x00007D5BE8ED5EB0
00007d5be8fe2016  jmp 0x00007D5BE8FE1FFD
00007d5be8fe201b  int3
00007d5be8fe201c  nop [rax], eax
00007d5be8fe2020  mov qword ptr [r15+0x100], 0x04
00007d5be8fe202b  mov esi, 0x00
00007d5be8fe2030  mov edx, 0x09
00007d5be8fe2035  mov rdi, 0x7FFE89479550
00007d5be8fe203f  mov rax, 0x5D3456EED970
00007d5be8fe2049  call rax
00007d5be8fe204b  cmp dword ptr [r15+0x318], 0x00
00007d5be8fe2053  jnz 0x00007D5BE8DFE110
00007d5be8fe2059  jmp 0x00007D5BE8DFE0A0
00007d5be8fe205e  int3
00007d5be8fe205f  int3
