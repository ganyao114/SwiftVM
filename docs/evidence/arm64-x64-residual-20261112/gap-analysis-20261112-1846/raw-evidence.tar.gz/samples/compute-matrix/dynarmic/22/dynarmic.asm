00007f828abce69b  nop [rax+rax*1], eax
00007f828abce6a0  vmovaps xmm1, [0x00007F828A7FE010]
00007f828abce6a8  movq xmm1, xmm1
00007f828abce6ac  movaps [r15+0x110], xmm1
00007f828abce6b4  vmovaps xmm1, [0x00007F828A7FE020]
00007f828abce6bc  movq xmm1, xmm1
00007f828abce6c0  movaps [r15+0x120], xmm1
00007f828abce6c8  mov eax, 0x4204C0
00007f828abce6cd  mov r14, [r13+rax*1]
00007f828abce6d2  movq xmm1, r14
00007f828abce6d7  movaps [r15+0x130], xmm1
00007f828abce6df  vmovaps xmm1, [0x00007F828A7FE030]
00007f828abce6e7  vpbroadcastq xmm1, xmm1
00007f828abce6ec  movaps [r15+0x140], xmm1
00007f828abce6f4  mov qword ptr [r15+0x40], 0x02
00007f828abce6fc  vmovaps xmm15, [0x00007F828A7FE040]
00007f828abce704  movq xmm15, xmm15
00007f828abce709  movaps [r15+0x150], xmm15
00007f828abce711  mov qword ptr [r15+0x58], 0x420000
00007f828abce719  vmovaps xmm15, [0x00007F828A7FE050]
00007f828abce721  vpbroadcastq xmm15, xmm15
00007f828abce726  movaps [r15+0x160], xmm15
00007f828abce72e  mov rax, [r15+0x40]
00007f828abce732  vmovq xmm14, rax
00007f828abce737  vpbroadcastq xmm14, xmm14
00007f828abce73c  movaps [r15+0x170], xmm14
00007f828abce744  mov eax, 0x4204D0
00007f828abce749  movups xmm13, [r13+rax*1]
00007f828abce74f  mov qword ptr [r15+0x40], 0x430518
00007f828abce757  mov qword ptr [r15+0x50], 0x430720
00007f828abce75f  vpmovqd xmm12, xmm13
00007f828abce765  pxor xmm11, xmm11
00007f828abce76a  punpcklqdq xmm12, xmm11
00007f828abce76f  movaps [r15+0x210], xmm12
00007f828abce777  movq xmm12, qword ptr [r15+0x120]
00007f828abce780  movq xmm11, qword ptr [r15+0x130]
00007f828abce789  psubd xmm12, xmm11
00007f828abce78e  movq xmm12, xmm12
00007f828abce793  paddq xmm13, xmm14
00007f828abce798  movaps [r15+0x180], xmm13
00007f828abce7a0  movq xmm14, qword ptr [r15+0x150]
00007f828abce7a9  paddd xmm11, xmm14
00007f828abce7ae  movq xmm11, xmm11
00007f828abce7b3  movq xmm11, xmm11
00007f828abce7b8  movaps [r15+0x130], xmm11
00007f828abce7c0  pmovzxdq xmm12, xmm12
00007f828abce7c6  psllq xmm12, 0x00
00007f828abce7cc  movq xmm14, qword ptr [r15+0x210]
00007f828abce7d5  movq xmm13, qword ptr [r15+0x110]
00007f828abce7de  paddd xmm14, xmm13
00007f828abce7e3  movq xmm14, xmm14
00007f828abce7e8  vcvtuqq2pd xmm12, xmm12
00007f828abce7ee  pmovzxdq xmm14, xmm14
00007f828abce7f4  psllq xmm14, 0x00
00007f828abce7fa  vcvtuqq2pd xmm14, xmm14
00007f828abce800  movaps xmm13, xmm12
00007f828abce804  mulpd xmm13, xmm1
00007f828abce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007f828abce80f  ptest xmm11, xmm11
00007f828abce815  jnz 0x00007F828ABCE8FF
00007f828abce81b  movaps [r15+0x220], xmm13
00007f828abce823  mov eax, 0x430720
00007f828abce828  movups [r13+rax*1], xmm13
00007f828abce82e  movaps xmm1, xmm14
00007f828abce832  mulpd xmm1, xmm15
00007f828abce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007f828abce83c  ptest xmm13, xmm13
00007f828abce842  jnz 0x00007F828ABCEA4C
00007f828abce848  movaps [r15+0x210], xmm1
00007f828abce850  mov eax, 0x430518
00007f828abce855  movups [r13+rax*1], xmm1
00007f828abce85b  mov qword ptr [r15+0x48], 0x10
00007f828abce863  xor eax, eax
00007f828abce865  mov r14d, 0x10
00007f828abce86b  mov r12d, 0x200
00007f828abce871  cmp r14, r12
00007f828abce874  cmc
00007f828abce875  lahf
00007f828abce876  seto al
00007f828abce879  mov [r15+0x108], eax
00007f828abce880  mov eax, [r15+0x108]
00007f828abce887  sahf
00007f828abce888  jnz 0x00007F828ABCE8BA
00007f828abce88a  cmp dword ptr [r15+0x318], 0x00
00007f828abce892  jz 0x00007F828ABCEFF0
00007f828abce898  nop [rax+rax*1], ax
00007f828abce8a1  nop [rax+rax*1], eax
00007f828abce8a9  mov eax, 0x4101EC
00007f828abce8ae  mov [r15+0x100], rax
00007f828abce8b5  jmp 0x00007F828A9FE110
00007f828abce8ba  cmp dword ptr [r15+0x318], 0x00
00007f828abce8c2  jz 0x00007F828ABCEBA0
00007f828abce8c8  nop [rax+rax*1], ax
00007f828abce8d1  nop [rax+rax*1], eax
00007f828abce8d9  mov eax, 0x4101AC
00007f828abce8de  mov [r15+0x100], rax
00007f828abce8e5  jmp 0x00007F828A9FE110
00007f828abce8ea  int3
00007f828abce8eb  call 0x00007F828AA0DC20
00007f828abce8f0  jmp 0x00007F828ABCE6D2
00007f828abce8f5  call 0x00007F828AA0C260
00007f828abce8fa  jmp 0x00007F828ABCE74F
00007f828abce8ff  sub rsp, 0x08
00007f828abce903  push rax
00007f828abce904  push rcx
00007f828abce905  push rdx
00007f828abce906  push rdi
00007f828abce907  push rsi
00007f828abce908  push r8
00007f828abce90a  push r9
00007f828abce90c  push r10
00007f828abce90e  push r11
00007f828abce910  sub rsp, 0xF0
00007f828abce917  vmovaps [rsp], xmm0
00007f828abce91c  vmovaps [rsp+0x10], xmm1
00007f828abce922  vmovaps [rsp+0x20], xmm2
00007f828abce928  vmovaps [rsp+0x30], xmm3
00007f828abce92e  vmovaps [rsp+0x40], xmm4
00007f828abce934  vmovaps [rsp+0x50], xmm5
00007f828abce93a  vmovaps [rsp+0x60], xmm6
00007f828abce940  vmovaps [rsp+0x70], xmm7
00007f828abce946  vmovaps [rsp+0x80], xmm8
00007f828abce94f  vmovaps [rsp+0x90], xmm9
00007f828abce958  vmovaps [rsp+0xA0], xmm10
00007f828abce961  vmovaps [rsp+0xB0], xmm11
00007f828abce96a  vmovaps [rsp+0xC0], xmm12
00007f828abce973  vmovaps [rsp+0xD0], xmm14
00007f828abce97c  vmovaps [rsp+0xE0], xmm15
00007f828abce985  sub rsp, 0x30
00007f828abce989  movaps [rsp], xmm13
00007f828abce98e  movaps [rsp+0x10], xmm12
00007f828abce994  movaps [rsp+0x20], xmm1
00007f828abce999  lea rdi, [rsp]
00007f828abce99d  mov esi, 0x00
00007f828abce9a2  mov rax, 0x5BFE27FA6530
00007f828abce9ac  call rax
00007f828abce9ae  movaps xmm13, [rsp]
00007f828abce9b3  add rsp, 0x30
00007f828abce9b7  vmovaps xmm0, [rsp]
00007f828abce9bc  vmovaps xmm1, [rsp+0x10]
00007f828abce9c2  vmovaps xmm2, [rsp+0x20]
00007f828abce9c8  vmovaps xmm3, [rsp+0x30]
00007f828abce9ce  vmovaps xmm4, [rsp+0x40]
00007f828abce9d4  vmovaps xmm5, [rsp+0x50]
00007f828abce9da  vmovaps xmm6, [rsp+0x60]
00007f828abce9e0  vmovaps xmm7, [rsp+0x70]
00007f828abce9e6  vmovaps xmm8, [rsp+0x80]
00007f828abce9ef  vmovaps xmm9, [rsp+0x90]
00007f828abce9f8  vmovaps xmm10, [rsp+0xA0]
00007f828abcea01  vmovaps xmm11, [rsp+0xB0]
00007f828abcea0a  vmovaps xmm12, [rsp+0xC0]
00007f828abcea13  vmovaps xmm14, [rsp+0xD0]
00007f828abcea1c  vmovaps xmm15, [rsp+0xE0]
00007f828abcea25  add rsp, 0xF0
00007f828abcea2c  pop r11
00007f828abcea2e  pop r10
00007f828abcea30  pop r9
00007f828abcea32  pop r8
00007f828abcea34  pop rsi
00007f828abcea35  pop rdi
00007f828abcea36  pop rdx
00007f828abcea37  pop rcx
00007f828abcea38  pop rax
00007f828abcea39  add rsp, 0x08
00007f828abcea3d  jmp 0x00007F828ABCE81B
00007f828abcea42  call 0x00007F828AA0C380
00007f828abcea47  jmp 0x00007F828ABCE82E
00007f828abcea4c  sub rsp, 0x08
00007f828abcea50  push rax
00007f828abcea51  push rcx
00007f828abcea52  push rdx
00007f828abcea53  push rdi
00007f828abcea54  push rsi
00007f828abcea55  push r8
00007f828abcea57  push r9
00007f828abcea59  push r10
00007f828abcea5b  push r11
00007f828abcea5d  sub rsp, 0xF0
00007f828abcea64  vmovaps [rsp], xmm0
00007f828abcea69  vmovaps [rsp+0x10], xmm2
00007f828abcea6f  vmovaps [rsp+0x20], xmm3
00007f828abcea75  vmovaps [rsp+0x30], xmm4
00007f828abcea7b  vmovaps [rsp+0x40], xmm5
00007f828abcea81  vmovaps [rsp+0x50], xmm6
00007f828abcea87  vmovaps [rsp+0x60], xmm7
00007f828abcea8d  vmovaps [rsp+0x70], xmm8
00007f828abcea93  vmovaps [rsp+0x80], xmm9
00007f828abcea9c  vmovaps [rsp+0x90], xmm10
00007f828abceaa5  vmovaps [rsp+0xA0], xmm11
00007f828abceaae  vmovaps [rsp+0xB0], xmm12
00007f828abceab7  vmovaps [rsp+0xC0], xmm13
00007f828abceac0  vmovaps [rsp+0xD0], xmm14
00007f828abceac9  vmovaps [rsp+0xE0], xmm15
00007f828abcead2  sub rsp, 0x30
00007f828abcead6  movaps [rsp], xmm1
00007f828abceada  movaps [rsp+0x10], xmm14
00007f828abceae0  movaps [rsp+0x20], xmm15
00007f828abceae6  lea rdi, [rsp]
00007f828abceaea  mov esi, 0x00
00007f828abceaef  mov rax, 0x5BFE27FA6530
00007f828abceaf9  call rax
00007f828abceafb  movaps xmm1, [rsp]
00007f828abceaff  add rsp, 0x30
00007f828abceb03  vmovaps xmm0, [rsp]
00007f828abceb08  vmovaps xmm2, [rsp+0x10]
00007f828abceb0e  vmovaps xmm3, [rsp+0x20]
00007f828abceb14  vmovaps xmm4, [rsp+0x30]
00007f828abceb1a  vmovaps xmm5, [rsp+0x40]
00007f828abceb20  vmovaps xmm6, [rsp+0x50]
00007f828abceb26  vmovaps xmm7, [rsp+0x60]
00007f828abceb2c  vmovaps xmm8, [rsp+0x70]
00007f828abceb32  vmovaps xmm9, [rsp+0x80]
00007f828abceb3b  vmovaps xmm10, [rsp+0x90]
00007f828abceb44  vmovaps xmm11, [rsp+0xA0]
00007f828abceb4d  vmovaps xmm12, [rsp+0xB0]
00007f828abceb56  vmovaps xmm13, [rsp+0xC0]
00007f828abceb5f  vmovaps xmm14, [rsp+0xD0]
00007f828abceb68  vmovaps xmm15, [rsp+0xE0]
00007f828abceb71  add rsp, 0xF0
00007f828abceb78  pop r11
00007f828abceb7a  pop r10
00007f828abceb7c  pop r9
00007f828abceb7e  pop r8
00007f828abceb80  pop rsi
00007f828abceb81  pop rdi
00007f828abceb82  pop rdx
00007f828abceb83  pop rcx
00007f828abceb84  pop rax
00007f828abceb85  add rsp, 0x08
00007f828abceb89  jmp 0x00007F828ABCE848
00007f828abceb8e  call 0x00007F828A9FF540
00007f828abceb93  jmp 0x00007F828ABCE85B
00007f828abceb98  int3
00007f828abceb99  nop [rax], eax
00007f828abceba0  movaps xmm1, [r15+0x180]
00007f828abceba8  vpmovqd xmm15, xmm1
00007f828abcebae  pxor xmm14, xmm14
00007f828abcebb3  punpcklqdq xmm15, xmm14
00007f828abcebb8  movaps [r15+0x210], xmm15
00007f828abcebc0  movq xmm15, qword ptr [r15+0x120]
00007f828abcebc9  movq xmm14, qword ptr [r15+0x130]
00007f828abcebd2  psubd xmm15, xmm14
00007f828abcebd7  movq xmm15, xmm15
00007f828abcebdc  movaps xmm13, [r15+0x170]
00007f828abcebe4  paddq xmm1, xmm13
00007f828abcebe9  movaps [r15+0x180], xmm1
00007f828abcebf1  movq xmm1, qword ptr [r15+0x150]
00007f828abcebfa  paddd xmm14, xmm1
00007f828abcebff  movq xmm14, xmm14
00007f828abcec04  movq xmm14, xmm14
00007f828abcec09  movaps [r15+0x130], xmm14
00007f828abcec11  pmovzxdq xmm15, xmm15
00007f828abcec17  psllq xmm15, 0x00
00007f828abcec1d  movq xmm1, qword ptr [r15+0x210]
00007f828abcec26  movq xmm14, qword ptr [r15+0x110]
00007f828abcec2f  paddd xmm1, xmm14
00007f828abcec34  movq xmm1, xmm1
00007f828abcec38  vcvtuqq2pd xmm15, xmm15
00007f828abcec3e  pmovzxdq xmm1, xmm1
00007f828abcec43  psllq xmm1, 0x00
00007f828abcec48  vcvtuqq2pd xmm1, xmm1
00007f828abcec4e  movaps xmm14, [r15+0x140]
00007f828abcec56  movaps xmm13, xmm15
00007f828abcec5a  mulpd xmm13, xmm14
00007f828abcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007f828abcec65  ptest xmm12, xmm12
00007f828abcec6b  jnz 0x00007F828ABCED4E
00007f828abcec71  movaps [r15+0x220], xmm13
00007f828abcec79  mov rax, [r15+0x48]
00007f828abcec7d  mov r14, [r15+0x50]
00007f828abcec81  lea r12, [r14+rax*1]
00007f828abcec85  movups [r13+r12*1], xmm13
00007f828abcec8b  movaps xmm15, [r15+0x160]
00007f828abcec93  movaps xmm14, xmm1
00007f828abcec97  mulpd xmm14, xmm15
00007f828abcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007f828abceca2  ptest xmm13, xmm13
00007f828abceca8  jnz 0x00007F828ABCEE9C
00007f828abcecae  movaps [r15+0x210], xmm14
00007f828abcecb6  mov r14, [r15+0x40]
00007f828abcecba  lea r12, [r14+rax*1]
00007f828abcecbe  movups [r13+r12*1], xmm14
00007f828abcecc4  lea r14, [rax+0x10]
00007f828abcecc8  mov [r15+0x48], r14
00007f828abceccc  xor eax, eax
00007f828abcecce  mov r12d, 0x200
00007f828abcecd4  cmp r14, r12
00007f828abcecd7  cmc
00007f828abcecd8  lahf
00007f828abcecd9  seto al
00007f828abcecdc  mov [r15+0x108], eax
00007f828abcece3  mov eax, [r15+0x108]
00007f828abcecea  sahf
00007f828abceceb  jnz 0x00007F828ABCED1D
00007f828abceced  cmp dword ptr [r15+0x318], 0x00
00007f828abcecf5  jz 0x00007F828ABCEFF0
00007f828abcecfb  nop [rax+rax*1], ax
00007f828abced04  nop [rax+rax*1], eax
00007f828abced0c  mov eax, 0x4101EC
00007f828abced11  mov [r15+0x100], rax
00007f828abced18  jmp 0x00007F828A9FE110
00007f828abced1d  cmp dword ptr [r15+0x318], 0x00
00007f828abced25  jz 0x00007F828ABCEBA0
00007f828abced2b  nop [rax+rax*1], ax
00007f828abced34  nop [rax+rax*1], eax
00007f828abced3c  mov eax, 0x4101AC
00007f828abced41  mov [r15+0x100], rax
00007f828abced48  jmp 0x00007F828A9FE110
00007f828abced4d  int3
00007f828abced4e  sub rsp, 0x08
00007f828abced52  push rax
00007f828abced53  push rcx
00007f828abced54  push rdx
00007f828abced55  push rdi
00007f828abced56  push rsi
00007f828abced57  push r8
00007f828abced59  push r9
00007f828abced5b  push r10
00007f828abced5d  push r11
00007f828abced5f  sub rsp, 0xF0
00007f828abced66  vmovaps [rsp], xmm0
00007f828abced6b  vmovaps [rsp+0x10], xmm1
00007f828abced71  vmovaps [rsp+0x20], xmm2
00007f828abced77  vmovaps [rsp+0x30], xmm3
00007f828abced7d  vmovaps [rsp+0x40], xmm4
00007f828abced83  vmovaps [rsp+0x50], xmm5
00007f828abced89  vmovaps [rsp+0x60], xmm6
00007f828abced8f  vmovaps [rsp+0x70], xmm7
00007f828abced95  vmovaps [rsp+0x80], xmm8
00007f828abced9e  vmovaps [rsp+0x90], xmm9
00007f828abceda7  vmovaps [rsp+0xA0], xmm10
00007f828abcedb0  vmovaps [rsp+0xB0], xmm11
00007f828abcedb9  vmovaps [rsp+0xC0], xmm12
00007f828abcedc2  vmovaps [rsp+0xD0], xmm14
00007f828abcedcb  vmovaps [rsp+0xE0], xmm15
00007f828abcedd4  sub rsp, 0x30
00007f828abcedd8  movaps [rsp], xmm13
00007f828abceddd  movaps [rsp+0x10], xmm15
00007f828abcede3  movaps [rsp+0x20], xmm14
00007f828abcede9  lea rdi, [rsp]
00007f828abceded  mov esi, 0x00
00007f828abcedf2  mov rax, 0x5BFE27FA6530
00007f828abcedfc  call rax
00007f828abcedfe  movaps xmm13, [rsp]
00007f828abcee03  add rsp, 0x30
00007f828abcee07  vmovaps xmm0, [rsp]
00007f828abcee0c  vmovaps xmm1, [rsp+0x10]
00007f828abcee12  vmovaps xmm2, [rsp+0x20]
00007f828abcee18  vmovaps xmm3, [rsp+0x30]
00007f828abcee1e  vmovaps xmm4, [rsp+0x40]
00007f828abcee24  vmovaps xmm5, [rsp+0x50]
00007f828abcee2a  vmovaps xmm6, [rsp+0x60]
00007f828abcee30  vmovaps xmm7, [rsp+0x70]
00007f828abcee36  vmovaps xmm8, [rsp+0x80]
00007f828abcee3f  vmovaps xmm9, [rsp+0x90]
00007f828abcee48  vmovaps xmm10, [rsp+0xA0]
00007f828abcee51  vmovaps xmm11, [rsp+0xB0]
00007f828abcee5a  vmovaps xmm12, [rsp+0xC0]
00007f828abcee63  vmovaps xmm14, [rsp+0xD0]
00007f828abcee6c  vmovaps xmm15, [rsp+0xE0]
00007f828abcee75  add rsp, 0xF0
00007f828abcee7c  pop r11
00007f828abcee7e  pop r10
00007f828abcee80  pop r9
00007f828abcee82  pop r8
00007f828abcee84  pop rsi
00007f828abcee85  pop rdi
00007f828abcee86  pop rdx
00007f828abcee87  pop rcx
00007f828abcee88  pop rax
00007f828abcee89  add rsp, 0x08
00007f828abcee8d  jmp 0x00007F828ABCEC71
00007f828abcee92  call 0x00007F828AAC2240
00007f828abcee97  jmp 0x00007F828ABCEC8B
00007f828abcee9c  sub rsp, 0x08
00007f828abceea0  push rax
00007f828abceea1  push rcx
00007f828abceea2  push rdx
00007f828abceea3  push rdi
00007f828abceea4  push rsi
00007f828abceea5  push r8
00007f828abceea7  push r9
00007f828abceea9  push r10
00007f828abceeab  push r11
00007f828abceead  sub rsp, 0xF0
00007f828abceeb4  vmovaps [rsp], xmm0
00007f828abceeb9  vmovaps [rsp+0x10], xmm1
00007f828abceebf  vmovaps [rsp+0x20], xmm2
00007f828abceec5  vmovaps [rsp+0x30], xmm3
00007f828abceecb  vmovaps [rsp+0x40], xmm4
00007f828abceed1  vmovaps [rsp+0x50], xmm5
00007f828abceed7  vmovaps [rsp+0x60], xmm6
00007f828abceedd  vmovaps [rsp+0x70], xmm7
00007f828abceee3  vmovaps [rsp+0x80], xmm8
00007f828abceeec  vmovaps [rsp+0x90], xmm9
00007f828abceef5  vmovaps [rsp+0xA0], xmm10
00007f828abceefe  vmovaps [rsp+0xB0], xmm11
00007f828abcef07  vmovaps [rsp+0xC0], xmm12
00007f828abcef10  vmovaps [rsp+0xD0], xmm13
00007f828abcef19  vmovaps [rsp+0xE0], xmm15
00007f828abcef22  sub rsp, 0x30
00007f828abcef26  movaps [rsp], xmm14
00007f828abcef2b  movaps [rsp+0x10], xmm1
00007f828abcef30  movaps [rsp+0x20], xmm15
00007f828abcef36  lea rdi, [rsp]
00007f828abcef3a  mov esi, 0x00
00007f828abcef3f  mov rax, 0x5BFE27FA6530
00007f828abcef49  call rax
00007f828abcef4b  movaps xmm14, [rsp]
00007f828abcef50  add rsp, 0x30
00007f828abcef54  vmovaps xmm0, [rsp]
00007f828abcef59  vmovaps xmm1, [rsp+0x10]
00007f828abcef5f  vmovaps xmm2, [rsp+0x20]
00007f828abcef65  vmovaps xmm3, [rsp+0x30]
00007f828abcef6b  vmovaps xmm4, [rsp+0x40]
00007f828abcef71  vmovaps xmm5, [rsp+0x50]
00007f828abcef77  vmovaps xmm6, [rsp+0x60]
00007f828abcef7d  vmovaps xmm7, [rsp+0x70]
00007f828abcef83  vmovaps xmm8, [rsp+0x80]
00007f828abcef8c  vmovaps xmm9, [rsp+0x90]
00007f828abcef95  vmovaps xmm10, [rsp+0xA0]
00007f828abcef9e  vmovaps xmm11, [rsp+0xB0]
00007f828abcefa7  vmovaps xmm12, [rsp+0xC0]
00007f828abcefb0  vmovaps xmm13, [rsp+0xD0]
00007f828abcefb9  vmovaps xmm15, [rsp+0xE0]
00007f828abcefc2  add rsp, 0xF0
00007f828abcefc9  pop r11
00007f828abcefcb  pop r10
00007f828abcefcd  pop r9
00007f828abcefcf  pop r8
00007f828abcefd1  pop rsi
00007f828abcefd2  pop rdi
00007f828abcefd3  pop rdx
00007f828abcefd4  pop rcx
00007f828abcefd5  pop rax
00007f828abcefd6  add rsp, 0x08
00007f828abcefda  jmp 0x00007F828ABCECAE
00007f828abcefdf  call 0x00007F828AAC34C0
00007f828abcefe4  jmp 0x00007F828ABCECC4
00007f828abcefe9  int3
00007f828abcefea  nop [rax+rax*1], ax
00007f828abceff0  mov rax, [r15+0xF8]
00007f828abceff7  lea r14, [rax-0x150]
00007f828abceffe  mov [r15+0xF8], r14
00007f828abcf005  mov rax, [r15+0x50]
00007f828abcf009  lea r12, [rax+0x80]
00007f828abcf010  movups xmm1, [r13+r12*1]
00007f828abcf016  lea r12, [rax+0x90]
00007f828abcf01d  movups xmm15, [r13+r12*1]
00007f828abcf023  mov qword ptr [r15+0x48], 0x00
00007f828abcf02b  lea r12, [rax+0x40]
00007f828abcf02f  movups xmm14, [r13+r12*1]
00007f828abcf035  lea r12, [rax+0x50]
00007f828abcf039  movups xmm13, [r13+r12*1]
00007f828abcf03f  lea r12, [r14+0x120]
00007f828abcf046  movq xmm12, qword ptr [r15+0x1C0]
00007f828abcf04f  movq xmm11, qword ptr [r15+0x1B0]
00007f828abcf058  movq r11, xmm12
00007f828abcf05d  movq r10, xmm11
00007f828abcf062  mov [r13+r12*1], r11
00007f828abcf067  lea r12, [r14+0x128]
00007f828abcf06e  mov [r13+r12*1], r10
00007f828abcf073  vxorps xmm12, xmm12, xmm12
00007f828abcf078  vpbroadcastq xmm12, xmm12
00007f828abcf07d  lea r12, [r14+0x100]
00007f828abcf084  movq xmm11, qword ptr [r15+0x200]
00007f828abcf08d  movq xmm10, qword ptr [r15+0x1F0]
00007f828abcf096  movq r11, xmm11
00007f828abcf09b  movq r10, xmm10
00007f828abcf0a0  mov [r13+r12*1], r11
00007f828abcf0a5  lea r12, [r14+0x108]
00007f828abcf0ac  mov [r13+r12*1], r10
00007f828abcf0b1  lea r12, [r14+0xE0]
00007f828abcf0b8  movups [r13+r12*1], xmm15
00007f828abcf0be  lea r12, [r14+0xF0]
00007f828abcf0c5  movups [r13+r12*1], xmm1
00007f828abcf0cb  lea r12, [rax+0xC0]
00007f828abcf0d2  movups xmm1, [r13+r12*1]
00007f828abcf0d8  lea r12, [rax+0xD0]
00007f828abcf0df  movups xmm15, [r13+r12*1]
00007f828abcf0e5  lea r12, [r14+0x110]
00007f828abcf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007f828abcf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007f828abcf0fe  movq r11, xmm11
00007f828abcf103  movq r10, xmm10
00007f828abcf108  mov [r13+r12*1], r11
00007f828abcf10d  lea r12, [r14+0x118]
00007f828abcf114  mov [r13+r12*1], r10
00007f828abcf119  movups xmm11, [r13+rax*1]
00007f828abcf11f  lea r12, [rax+0x10]
00007f828abcf123  movups xmm10, [r13+r12*1]
00007f828abcf129  lea r12, [r14+0x130]
00007f828abcf130  movq xmm9, qword ptr [r15+0x1A0]
00007f828abcf139  movq xmm8, qword ptr [r15+0x190]
00007f828abcf142  movq r11, xmm9
00007f828abcf147  movq r10, xmm8
00007f828abcf14c  mov [r13+r12*1], r11
00007f828abcf151  lea r12, [r14+0x138]
00007f828abcf158  mov [r13+r12*1], r10
00007f828abcf15d  lea r12, [rax+0x140]
00007f828abcf164  movups xmm9, [r13+r12*1]
00007f828abcf16a  lea r12, [rax+0x150]
00007f828abcf171  movups xmm8, [r13+r12*1]
00007f828abcf177  lea r12, [r14+0xC0]
00007f828abcf17e  movups [r13+r12*1], xmm15
00007f828abcf184  lea r12, [r14+0xD0]
00007f828abcf18b  movups [r13+r12*1], xmm1
00007f828abcf191  lea r12, [rax+0x100]
00007f828abcf198  movups xmm1, [r13+r12*1]
00007f828abcf19e  lea r12, [rax+0x110]
00007f828abcf1a5  movups xmm15, [r13+r12*1]
00007f828abcf1ab  lea r12, [r14+0x140]
00007f828abcf1b2  mov r11, [r15+0xE8]
00007f828abcf1b9  mov [r13+r12*1], r11
00007f828abcf1be  lea r12, [rax+0x180]
00007f828abcf1c5  movups xmm7, [r13+r12*1]
00007f828abcf1cb  lea r12, [rax+0x190]
00007f828abcf1d2  movups xmm6, [r13+r12*1]
00007f828abcf1d8  lea r12, [rax+0x1C0]
00007f828abcf1df  movups xmm5, [r13+r12*1]
00007f828abcf1e5  lea r12, [rax+0x1D0]
00007f828abcf1ec  movups xmm4, [r13+r12*1]
00007f828abcf1f2  lea r12, [r14+0x20]
00007f828abcf1f6  movups [r13+r12*1], xmm1
00007f828abcf1fc  lea r12, [r14+0x30]
00007f828abcf200  movups [r13+r12*1], xmm13
00007f828abcf206  lea r12, [rax+0x60]
00007f828abcf20a  movups xmm1, [r13+r12*1]
00007f828abcf210  lea r12, [rax+0x70]
00007f828abcf214  movups xmm13, [r13+r12*1]
00007f828abcf21a  lea r12, [rax+0x20]
00007f828abcf21e  movups xmm3, [r13+r12*1]
00007f828abcf224  lea r12, [rax+0x30]
00007f828abcf228  movups xmm2, [r13+r12*1]
00007f828abcf22e  movaps [r15+0x1F0], xmm2
00007f828abcf236  lea r12, [r14+0x60]
00007f828abcf23a  movups [r13+r12*1], xmm11
00007f828abcf240  lea r12, [r14+0x70]
00007f828abcf244  movups [r13+r12*1], xmm5
00007f828abcf24a  lea r12, [rax+0xE0]
00007f828abcf251  movups xmm11, [r13+r12*1]
00007f828abcf257  lea r12, [rax+0xF0]
00007f828abcf25e  movups xmm5, [r13+r12*1]
00007f828abcf264  lea r12, [r14+0xA0]
00007f828abcf26b  movups [r13+r12*1], xmm13
00007f828abcf271  lea r12, [r14+0xB0]
00007f828abcf278  movups [r13+r12*1], xmm1
00007f828abcf27e  lea r12, [rax+0xA0]
00007f828abcf285  movups xmm1, [r13+r12*1]
00007f828abcf28b  lea r12, [rax+0xB0]
00007f828abcf292  movups xmm13, [r13+r12*1]
00007f828abcf298  lea r12, [rax+0x120]
00007f828abcf29f  vmovaps [rsp+0x10], xmm1
00007f828abcf2a5  movups xmm1, [r13+r12*1]
00007f828abcf2ab  lea r12, [rax+0x130]
00007f828abcf2b2  vmovaps [rsp+0x20], xmm1
00007f828abcf2b8  movups xmm1, [r13+r12*1]
00007f828abcf2be  lea r12, [rax+0x160]
00007f828abcf2c5  vmovaps [rsp+0x30], xmm1
00007f828abcf2cb  movups xmm1, [r13+r12*1]
00007f828abcf2d1  lea r12, [rax+0x170]
00007f828abcf2d8  vmovaps [rsp+0x40], xmm1
00007f828abcf2de  movups xmm1, [r13+r12*1]
00007f828abcf2e4  movaps [r15+0x2B0], xmm1
00007f828abcf2ec  lea r12, [r14+0x80]
00007f828abcf2f3  movups [r13+r12*1], xmm13
00007f828abcf2f9  lea r12, [r14+0x90]
00007f828abcf300  vmovaps xmm13, [rsp+0x10]
00007f828abcf306  movups [r13+r12*1], xmm13
00007f828abcf30c  lea r12, [rax+0x1A0]
00007f828abcf313  movups xmm13, [r13+r12*1]
00007f828abcf319  lea r12, [rax+0x1B0]
00007f828abcf320  vmovaps [rsp+0x10], xmm1
00007f828abcf326  movups xmm1, [r13+r12*1]
00007f828abcf32c  movaps [r15+0x290], xmm13
00007f828abcf334  movaps [r15+0x1E0], xmm1
00007f828abcf33c  lea r12, [rax+0x1E0]
00007f828abcf343  vmovaps [rsp+0x50], xmm1
00007f828abcf349  movups xmm1, [r13+r12*1]
00007f828abcf34f  lea r12, [rax+0x1F0]
00007f828abcf356  vmovaps [rsp+0x60], xmm1
00007f828abcf35c  movups xmm1, [r13+r12*1]
00007f828abcf362  mov qword ptr [r15+0x50], 0x430920
00007f828abcf36a  lea rax, [r14+0x40]
00007f828abcf36e  vmovaps [rsp+0x70], xmm1
00007f828abcf374  vmovaps xmm1, [rsp+0x40]
00007f828abcf37a  movups [r13+rax*1], xmm1
00007f828abcf380  lea rax, [r14+0x50]
00007f828abcf384  movups [r13+rax*1], xmm10
00007f828abcf38a  vmovaps xmm1, [rsp+0x70]
00007f828abcf390  movups [r13+r14*1], xmm1
00007f828abcf396  lea rax, [r14+0x10]
00007f828abcf39a  vmovaps xmm1, [rsp+0x60]
00007f828abcf3a0  movups [r13+rax*1], xmm1
00007f828abcf3a6  mov rax, [r15+0x40]
00007f828abcf3aa  vmovaps [rsp+0x40], xmm3
00007f828abcf3b0  vmovaps xmm1, [rsp+0x40]
00007f828abcf3b6  por xmm3, xmm1
00007f828abcf3ba  vmovaps [rsp+0x40], xmm6
00007f828abcf3c0  vmovaps xmm10, [rsp+0x40]
00007f828abcf3c6  por xmm6, xmm10
00007f828abcf3cb  lea r12, [rax+0x30]
00007f828abcf3cf  mov r11, [r13+r12*1]
00007f828abcf3d4  lea r12, [rax+0x38]
00007f828abcf3d8  mov r10, [r13+r12*1]
00007f828abcf3dd  movq xmm10, r11
00007f828abcf3e2  vmovaps [rsp+0x40], xmm1
00007f828abcf3e8  movq xmm1, r10
00007f828abcf3ed  movq xmm10, xmm10
00007f828abcf3f2  vmovaps [rsp+0x60], xmm10
00007f828abcf3f8  movq xmm10, xmm10
00007f828abcf3fd  movaps [r15+0x130], xmm10
00007f828abcf405  movq xmm1, xmm1
00007f828abcf409  vmovaps [rsp+0x70], xmm1
00007f828abcf40f  movq xmm1, xmm1
00007f828abcf413  movaps [r15+0x280], xmm1
00007f828abcf41b  vmovaps [rsp+0x80], xmm9
00007f828abcf424  vmovaps xmm1, [rsp+0x80]
00007f828abcf42d  por xmm9, xmm1
00007f828abcf432  lea r12, [rax+0x20]
00007f828abcf436  mov r11, [r13+r12*1]
00007f828abcf43b  lea r12, [rax+0x28]
00007f828abcf43f  mov r10, [r13+r12*1]
00007f828abcf444  movq xmm1, r11
00007f828abcf449  movq xmm10, r10
00007f828abcf44e  movq xmm1, xmm1
00007f828abcf452  vmovaps [rsp+0x80], xmm1
00007f828abcf45b  movq xmm1, xmm1
00007f828abcf45f  movaps [r15+0x150], xmm1
00007f828abcf467  movq xmm10, xmm10
00007f828abcf46c  vmovaps [rsp+0x90], xmm10
00007f828abcf475  movq xmm10, xmm10
00007f828abcf47a  movaps [r15+0x140], xmm10
00007f828abcf482  lea r12, [rax+0x10]
00007f828abcf486  mov r11, [r13+r12*1]
00007f828abcf48b  lea r12, [rax+0x18]
00007f828abcf48f  mov r10, [r13+r12*1]
00007f828abcf494  movq xmm1, r11
00007f828abcf499  movq xmm10, r10
00007f828abcf49e  movq xmm1, xmm1
00007f828abcf4a2  vmovaps [rsp+0xA0], xmm1
00007f828abcf4ab  movq xmm1, xmm1
00007f828abcf4af  movaps [r15+0x170], xmm1
00007f828abcf4b7  movq xmm10, xmm10
00007f828abcf4bc  vmovaps [rsp+0xB0], xmm10
00007f828abcf4c5  movq xmm10, xmm10
00007f828abcf4ca  movaps [r15+0x160], xmm10
00007f828abcf4d2  mov r12, [r13+rax*1]
00007f828abcf4d7  vmovq xmm1, r12
00007f828abcf4dc  vpbroadcastq xmm1, xmm1
00007f828abcf4e1  lea r12, [rax+0x08]
00007f828abcf4e5  mov rax, [r13+r12*1]
00007f828abcf4ea  movq xmm10, rax
00007f828abcf4ef  movaps [r15+0x230], xmm10
00007f828abcf4f7  lea rax, [r14+0x50]
00007f828abcf4fb  movups xmm10, [r13+rax*1]
00007f828abcf501  lea rax, [r14+0x60]
00007f828abcf505  vmovaps [rsp+0xC0], xmm1
00007f828abcf50e  movups xmm1, [r13+rax*1]
00007f828abcf514  lea rax, [r14+0x30]
00007f828abcf518  vmovaps [rsp+0xD0], xmm1
00007f828abcf521  movups xmm1, [r13+rax*1]
00007f828abcf527  mov qword ptr [r15+0x60], 0x430920
00007f828abcf52f  mov qword ptr [r15+0x58], 0x40
00007f828abcf537  vmovaps [rsp+0xE0], xmm1
00007f828abcf540  vmovaps [rsp+0xF0], xmm15
00007f828abcf549  vmovaps xmm15, [rsp+0xC0]
00007f828abcf552  vmovaps [rsp+0xC0], xmm14
00007f828abcf55b  vmovaps xmm14, [rsp+0x40]
00007f828abcf561  vmovaps [rsp+0x40], xmm13
00007f828abcf567  movaps xmm1, xmm15
00007f828abcf56b  mulpd xmm1, xmm14
00007f828abcf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007f828abcf575  ptest xmm13, xmm13
00007f828abcf57b  jnz 0x00007F828ABD0682
00007f828abcf581  movq xmm14, qword ptr [r15+0x230]
00007f828abcf58a  vmovaps [rsp+0x100], xmm14
00007f828abcf593  vpermilpd xmm14, xmm14, 0x00
00007f828abcf599  vmovaps [rsp+0x110], xmm1
00007f828abcf5a2  vmovaps xmm1, [rsp+0xE0]
00007f828abcf5ab  vmovaps [rsp+0xE0], xmm15
00007f828abcf5b4  movaps xmm13, xmm1
00007f828abcf5b8  mulpd xmm13, xmm14
00007f828abcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007f828abcf5c3  ptest xmm15, xmm15
00007f828abcf5c9  jnz 0x00007F828ABD07C4
00007f828abcf5cf  vxorps xmm1, xmm1, xmm1
00007f828abcf5d3  vpbroadcastq xmm1, xmm1
00007f828abcf5d8  vmovaps xmm14, [rsp+0xE0]
00007f828abcf5e1  vmovaps [rsp+0xE0], xmm1
00007f828abcf5ea  vmovaps xmm1, [rsp+0xD0]
00007f828abcf5f3  vmovaps [rsp+0xD0], xmm13
00007f828abcf5fc  movaps xmm15, xmm14
00007f828abcf600  mulpd xmm15, xmm1
00007f828abcf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007f828abcf60b  ptest xmm13, xmm13
00007f828abcf611  jnz 0x00007F828ABD0907
00007f828abcf617  movaps xmm1, xmm14
00007f828abcf61b  mulpd xmm1, xmm10
00007f828abcf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007f828abcf625  ptest xmm13, xmm13
00007f828abcf62b  jnz 0x00007F828ABD0A4A
00007f828abcf631  movaps xmm13, xmm14
00007f828abcf635  mulpd xmm13, xmm2
00007f828abcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007f828abcf640  ptest xmm10, xmm10
00007f828abcf646  jnz 0x00007F828ABD0B8C
00007f828abcf64c  vmovaps [rsp+0x120], xmm7
00007f828abcf655  vmovaps xmm14, [rsp+0x120]
00007f828abcf65e  por xmm7, xmm14
00007f828abcf663  vmovaps xmm14, [rsp+0xC0]
00007f828abcf66c  vmovaps xmm10, [rsp+0xC0]
00007f828abcf675  por xmm14, xmm10
00007f828abcf67a  vmovaps xmm2, [rsp+0x100]
00007f828abcf683  vpermilpd xmm2, xmm2, 0x00
00007f828abcf689  vmovaps [rsp+0xC0], xmm1
00007f828abcf692  vmovaps [rsp+0x120], xmm15
00007f828abcf69b  movaps xmm1, xmm10
00007f828abcf69f  mulpd xmm1, xmm2
00007f828abcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007f828abcf6a8  ptest xmm15, xmm15
00007f828abcf6ae  jnz 0x00007F828ABD0CCF
00007f828abcf6b4  xor eax, eax
00007f828abcf6b6  mov r12d, 0x40
00007f828abcf6bc  mov r11d, 0x200
00007f828abcf6c2  cmp r12, r11
00007f828abcf6c5  cmc
00007f828abcf6c6  lahf
00007f828abcf6c7  seto al
00007f828abcf6ca  mov [r15+0x108], eax
00007f828abcf6d1  vmovaps xmm10, [rsp+0x110]
00007f828abcf6da  vmovaps xmm2, [rsp+0xE0]
00007f828abcf6e3  vmovaps [rsp+0xE0], xmm1
00007f828abcf6ec  movaps xmm15, xmm10
00007f828abcf6f0  addpd xmm15, xmm2
00007f828abcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007f828abcf6fb  ptest xmm1, xmm1
00007f828abcf700  jnz 0x00007F828ABD0E10
00007f828abcf706  vmovaps xmm10, [rsp+0x120]
00007f828abcf70f  vmovaps [rsp+0x110], xmm15
00007f828abcf718  movaps xmm1, xmm10
00007f828abcf71c  addpd xmm1, xmm12
00007f828abcf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007f828abcf726  ptest xmm15, xmm15
00007f828abcf72c  jnz 0x00007F828ABD0F53
00007f828abcf732  vmovaps xmm10, [rsp+0xC0]
00007f828abcf73b  vmovaps [rsp+0xC0], xmm1
00007f828abcf744  movaps xmm15, xmm10
00007f828abcf748  addpd xmm15, xmm12
00007f828abcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007f828abcf753  ptest xmm1, xmm1
00007f828abcf758  jnz 0x00007F828ABD1095
00007f828abcf75e  vmovaps xmm1, [rsp+0x30]
00007f828abcf764  vmovaps xmm12, [rsp+0x30]
00007f828abcf76a  por xmm1, xmm12
00007f828abcf76f  vmovaps xmm12, [rsp+0x20]
00007f828abcf775  vmovaps xmm10, [rsp+0x20]
00007f828abcf77b  por xmm12, xmm10
00007f828abcf780  vmovaps [rsp+0x20], xmm5
00007f828abcf786  vmovaps xmm10, [rsp+0x20]
00007f828abcf78c  por xmm5, xmm10
00007f828abcf791  vmovaps [rsp+0x20], xmm11
00007f828abcf797  vmovaps xmm10, [rsp+0x20]
00007f828abcf79d  por xmm11, xmm10
00007f828abcf7a2  vmovaps [rsp+0x20], xmm4
00007f828abcf7a8  vmovaps xmm10, [rsp+0x20]
00007f828abcf7ae  por xmm4, xmm10
00007f828abcf7b3  vmovaps [rsp+0x20], xmm8
00007f828abcf7b9  vmovaps xmm10, [rsp+0x20]
00007f828abcf7bf  por xmm8, xmm10
00007f828abcf7c4  vmovaps xmm10, [rsp+0xF0]
00007f828abcf7cd  vmovaps [rsp+0x20], xmm1
00007f828abcf7d3  vmovaps xmm1, [rsp+0xF0]
00007f828abcf7dc  por xmm10, xmm1
00007f828abcf7e1  lea rax, [r14+0xA0]
00007f828abcf7e8  movups xmm1, [r13+rax*1]
00007f828abcf7ee  lea rax, [r14+0xB0]
00007f828abcf7f5  vmovaps [rsp+0x30], xmm1
00007f828abcf7fb  movups xmm1, [r13+rax*1]
00007f828abcf801  vmovaps [rsp+0xF0], xmm1
00007f828abcf80a  vmovaps [rsp+0x120], xmm15
00007f828abcf813  movaps xmm1, xmm13
00007f828abcf817  addpd xmm1, xmm2
00007f828abcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007f828abcf820  ptest xmm15, xmm15
00007f828abcf826  jnz 0x00007F828ABD11ED
00007f828abcf82c  lea rax, [r14+0xF0]
00007f828abcf833  movups xmm15, [r13+rax*1]
00007f828abcf839  vmovaps xmm2, [rsp+0xC0]
00007f828abcf842  vmovaps [rsp+0xC0], xmm1
00007f828abcf84b  vmovaps xmm1, [rsp+0xE0]
00007f828abcf854  vmovaps [rsp+0xE0], xmm15
00007f828abcf85d  movaps xmm13, xmm2
00007f828abcf861  addpd xmm13, xmm1
00007f828abcf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007f828abcf86c  ptest xmm15, xmm15
00007f828abcf872  jnz 0x00007F828ABD1338
00007f828abcf878  vmovaps xmm15, [rsp+0x120]
00007f828abcf881  vmovaps xmm2, [rsp+0xD0]
00007f828abcf88a  vmovaps [rsp+0xD0], xmm14
00007f828abcf893  movaps xmm1, xmm15
00007f828abcf897  addpd xmm1, xmm2
00007f828abcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007f828abcf8a0  ptest xmm14, xmm14
00007f828abcf8a6  jnz 0x00007F828ABD147A
00007f828abcf8ac  vmovaps xmm15, [rsp+0x100]
00007f828abcf8b5  vpermilpd xmm15, xmm15, 0x00
00007f828abcf8bb  vmovaps xmm2, [rsp+0xF0]
00007f828abcf8c4  vmovaps [rsp+0xF0], xmm1
00007f828abcf8cd  movaps xmm14, xmm2
00007f828abcf8d1  mulpd xmm14, xmm15
00007f828abcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007f828abcf8dc  ptest xmm1, xmm1
00007f828abcf8e1  jnz 0x00007F828ABD15BB
00007f828abcf8e7  vmovaps xmm1, [rsp+0xA0]
00007f828abcf8f0  vpermilpd xmm1, xmm1, 0x00
00007f828abcf8f6  vmovaps xmm2, [rsp+0xE0]
00007f828abcf8ff  vmovaps [rsp+0xE0], xmm14
00007f828abcf908  movaps xmm15, xmm2
00007f828abcf90c  mulpd xmm15, xmm1
00007f828abcf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007f828abcf917  ptest xmm14, xmm14
00007f828abcf91d  jnz 0x00007F828ABD16FE
00007f828abcf923  lea rax, [r14+0xE0]
00007f828abcf92a  movups xmm1, [r13+rax*1]
00007f828abcf930  vmovaps xmm14, [rsp+0x100]
00007f828abcf939  vpermilpd xmm14, xmm14, 0x00
00007f828abcf93f  vmovaps [rsp+0x100], xmm1
00007f828abcf948  vmovaps xmm1, [rsp+0x30]
00007f828abcf94e  vmovaps [rsp+0x30], xmm15
00007f828abcf954  movaps xmm2, xmm1
00007f828abcf957  mulpd xmm2, xmm14
00007f828abcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007f828abcf961  ptest xmm15, xmm15
00007f828abcf967  jnz 0x00007F828ABD184A
00007f828abcf96d  vmovaps [rsp+0x120], xmm10
00007f828abcf976  vmovaps xmm1, [rsp+0x120]
00007f828abcf97f  por xmm10, xmm1
00007f828abcf984  movaps [r15+0x300], xmm10
00007f828abcf98c  vmovaps [rsp+0x120], xmm8
00007f828abcf995  vmovaps xmm1, [rsp+0x120]
00007f828abcf99e  por xmm8, xmm1
00007f828abcf9a3  movaps [r15+0x190], xmm8
00007f828abcf9ab  vmovaps xmm1, [rsp+0xA0]
00007f828abcf9b4  vpermilpd xmm1, xmm1, 0x00
00007f828abcf9ba  vmovaps xmm14, [rsp+0x100]
00007f828abcf9c3  vmovaps [rsp+0x100], xmm13
00007f828abcf9cc  movaps xmm15, xmm14
00007f828abcf9d0  mulpd xmm15, xmm1
00007f828abcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007f828abcf9db  ptest xmm13, xmm13
00007f828abcf9e1  jnz 0x00007F828ABD198B
00007f828abcf9e7  lea rax, [r14+0x90]
00007f828abcf9ee  movups xmm1, [r13+rax*1]
00007f828abcf9f4  vmovaps [rsp+0x120], xmm4
00007f828abcf9fd  vmovaps xmm14, [rsp+0x120]
00007f828abcfa06  por xmm4, xmm14
00007f828abcfa0b  movaps [r15+0x1C0], xmm4
00007f828abcfa13  vmovaps [rsp+0x120], xmm11
00007f828abcfa1c  vmovaps xmm14, [rsp+0x120]
00007f828abcfa25  por xmm11, xmm14
00007f828abcfa2a  movaps [r15+0x200], xmm11
00007f828abcfa32  vmovaps [rsp+0x120], xmm5
00007f828abcfa3b  vmovaps xmm14, [rsp+0x120]
00007f828abcfa44  por xmm5, xmm14
00007f828abcfa49  movaps [r15+0x2D0], xmm5
00007f828abcfa51  vmovaps [rsp+0x120], xmm12
00007f828abcfa5a  vmovaps xmm14, [rsp+0x120]
00007f828abcfa63  por xmm12, xmm14
00007f828abcfa68  movaps [r15+0x2E0], xmm12
00007f828abcfa70  vmovaps xmm13, [rsp+0x110]
00007f828abcfa79  vmovaps [rsp+0x110], xmm1
00007f828abcfa82  vmovaps xmm1, [rsp+0xE0]
00007f828abcfa8b  vmovaps [rsp+0xE0], xmm15
00007f828abcfa94  movaps xmm14, xmm13
00007f828abcfa98  addpd xmm14, xmm1
00007f828abcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007f828abcfaa3  ptest xmm15, xmm15
00007f828abcfaa9  jnz 0x00007F828ABD1AD8
00007f828abcfaaf  vmovaps xmm1, [rsp+0xA0]
00007f828abcfab8  vpermilpd xmm1, xmm1, 0x00
00007f828abcfabe  vmovaps xmm13, [rsp+0x110]
00007f828abcfac7  vmovaps [rsp+0x110], xmm14
00007f828abcfad0  movaps xmm15, xmm13
00007f828abcfad4  mulpd xmm15, xmm1
00007f828abcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007f828abcfadf  ptest xmm14, xmm14
00007f828abcfae5  jnz 0x00007F828ABD1C1B
00007f828abcfaeb  lea rax, [r14+0x80]
00007f828abcfaf2  movups xmm1, [r13+rax*1]
00007f828abcfaf8  vmovaps xmm13, [rsp+0xC0]
00007f828abcfb01  vmovaps [rsp+0xC0], xmm1
00007f828abcfb0a  movaps xmm14, xmm13
00007f828abcfb0e  addpd xmm14, xmm2
00007f828abcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007f828abcfb19  ptest xmm1, xmm1
00007f828abcfb1e  jnz 0x00007F828ABD1D68
00007f828abcfb24  vmovaps xmm13, [rsp+0x100]
00007f828abcfb2d  vmovaps xmm2, [rsp+0x30]
00007f828abcfb33  vmovaps [rsp+0x30], xmm15
00007f828abcfb39  movaps xmm1, xmm13
00007f828abcfb3d  addpd xmm1, xmm2
00007f828abcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007f828abcfb46  ptest xmm15, xmm15
00007f828abcfb4c  jnz 0x00007F828ABD1EAB
00007f828abcfb52  vmovaps xmm15, [rsp+0x20]
00007f828abcfb58  vmovaps xmm13, [rsp+0x20]
00007f828abcfb5e  por xmm15, xmm13
00007f828abcfb63  movaps [r15+0x2F0], xmm15
00007f828abcfb6b  vmovaps xmm13, [rsp+0xA0]
00007f828abcfb74  vpermilpd xmm13, xmm13, 0x00
00007f828abcfb7a  vmovaps [rsp+0x20], xmm1
00007f828abcfb80  vmovaps xmm1, [rsp+0xC0]
00007f828abcfb89  vmovaps [rsp+0xA0], xmm15
00007f828abcfb92  movaps xmm2, xmm1
00007f828abcfb95  mulpd xmm2, xmm13
00007f828abcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007f828abcfb9f  ptest xmm15, xmm15
00007f828abcfba5  jnz 0x00007F828ABD1FEC
00007f828abcfbab  lea rax, [r14+0xD0]
00007f828abcfbb2  movups xmm1, [r13+rax*1]
00007f828abcfbb8  vmovaps xmm13, [rsp+0xF0]
00007f828abcfbc1  vmovaps [rsp+0xC0], xmm1
00007f828abcfbca  vmovaps xmm1, [rsp+0xE0]
00007f828abcfbd3  vmovaps [rsp+0xE0], xmm14
00007f828abcfbdc  movaps xmm15, xmm13
00007f828abcfbe0  addpd xmm15, xmm1
00007f828abcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007f828abcfbeb  ptest xmm14, xmm14
00007f828abcfbf1  jnz 0x00007F828ABD2137
00007f828abcfbf7  vmovaps xmm1, [rsp+0xB0]
00007f828abcfc00  vpermilpd xmm1, xmm1, 0x00
00007f828abcfc06  movaps xmm14, xmm11
00007f828abcfc0a  mulpd xmm14, xmm1
00007f828abcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007f828abcfc15  ptest xmm13, xmm13
00007f828abcfc1b  jnz 0x00007F828ABD227A
00007f828abcfc21  movaps [r15+0x260], xmm14
00007f828abcfc29  vxorps xmm1, xmm1, xmm1
00007f828abcfc2d  vpbroadcastq xmm1, xmm1
00007f828abcfc32  movaps [r15+0x1B0], xmm1
00007f828abcfc3a  vmovaps xmm1, [rsp+0xB0]
00007f828abcfc43  vpermilpd xmm1, xmm1, 0x00
00007f828abcfc49  vmovaps xmm11, [rsp+0xC0]
00007f828abcfc52  vmovaps [rsp+0xC0], xmm15
00007f828abcfc5b  movaps xmm13, xmm11
00007f828abcfc5f  mulpd xmm13, xmm1
00007f828abcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007f828abcfc6a  ptest xmm15, xmm15
00007f828abcfc70  jnz 0x00007F828ABD23BD
00007f828abcfc76  lea rax, [r14+0xC0]
00007f828abcfc7d  movups xmm1, [r13+rax*1]
00007f828abcfc83  vmovaps xmm11, [rsp+0x110]
00007f828abcfc8c  vmovaps [rsp+0xF0], xmm1
00007f828abcfc95  vmovaps xmm1, [rsp+0x30]
00007f828abcfc9b  vmovaps [rsp+0x30], xmm14
00007f828abcfca1  movaps xmm15, xmm11
00007f828abcfca5  addpd xmm15, xmm1
00007f828abcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007f828abcfcb0  ptest xmm14, xmm14
00007f828abcfcb6  jnz 0x00007F828ABD250A
00007f828abcfcbc  vmovaps [rsp+0x100], xmm9
00007f828abcfcc5  vmovaps xmm1, [rsp+0x100]
00007f828abcfcce  por xmm9, xmm1
00007f828abcfcd3  movaps [r15+0x270], xmm9
00007f828abcfcdb  vmovaps [rsp+0x100], xmm6
00007f828abcfce4  vmovaps xmm1, [rsp+0x100]
00007f828abcfced  por xmm6, xmm1
00007f828abcfcf1  movaps [r15+0x1A0], xmm6
00007f828abcfcf9  vmovaps xmm14, [rsp+0xB0]
00007f828abcfd02  vpermilpd xmm14, xmm14, 0x00
00007f828abcfd08  vmovaps xmm6, [rsp+0xF0]
00007f828abcfd11  vmovaps [rsp+0xF0], xmm1
00007f828abcfd1a  movaps xmm11, xmm6
00007f828abcfd1e  mulpd xmm11, xmm14
00007f828abcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007f828abcfd29  ptest xmm1, xmm1
00007f828abcfd2e  jnz 0x00007F828ABD264D
00007f828abcfd34  lea rax, [r14+0x20]
00007f828abcfd38  movups xmm1, [r13+rax*1]
00007f828abcfd3e  movaps [r15+0x110], xmm1
00007f828abcfd46  vmovaps xmm6, [rsp+0xE0]
00007f828abcfd4f  vmovaps [rsp+0xE0], xmm1
00007f828abcfd58  movaps xmm14, xmm6
00007f828abcfd5c  addpd xmm14, xmm2
00007f828abcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007f828abcfd67  ptest xmm1, xmm1
00007f828abcfd6c  jnz 0x00007F828ABD279A
00007f828abcfd72  vmovaps xmm1, [rsp+0xB0]
00007f828abcfd7b  vpermilpd xmm1, xmm1, 0x00
00007f828abcfd81  movaps xmm6, xmm5
00007f828abcfd84  mulpd xmm6, xmm1
00007f828abcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007f828abcfd8d  ptest xmm2, xmm2
00007f828abcfd92  jnz 0x00007F828ABD28DC
00007f828abcfd98  vmovaps xmm5, [rsp+0x20]
00007f828abcfd9e  movaps xmm1, xmm5
00007f828abcfda1  addpd xmm1, xmm13
00007f828abcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007f828abcfdab  ptest xmm2, xmm2
00007f828abcfdb0  jnz 0x00007F828ABD2A1C
00007f828abcfdb6  vmovaps xmm13, [rsp+0x80]
00007f828abcfdbf  vpermilpd xmm13, xmm13, 0x00
00007f828abcfdc5  vmovaps xmm2, [rsp+0xE0]
00007f828abcfdce  vmovaps [rsp+0x20], xmm1
00007f828abcfdd4  movaps xmm5, xmm2
00007f828abcfdd7  mulpd xmm5, xmm13
00007f828abcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007f828abcfde1  ptest xmm1, xmm1
00007f828abcfde6  jnz 0x00007F828ABD2B5D
00007f828abcfdec  vmovaps xmm1, [rsp+0x80]
00007f828abcfdf5  vpermilpd xmm1, xmm1, 0x00
00007f828abcfdfb  movaps xmm13, xmm10
00007f828abcfdff  mulpd xmm13, xmm1
00007f828abcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007f828abcfe0a  ptest xmm2, xmm2
00007f828abcfe0f  jnz 0x00007F828ABD2C9E
00007f828abcfe15  vmovaps xmm10, [rsp+0x30]
00007f828abcfe1b  movaps xmm1, xmm15
00007f828abcfe1f  addpd xmm1, xmm10
00007f828abcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007f828abcfe29  ptest xmm2, xmm2
00007f828abcfe2e  jnz 0x00007F828ABD2DE1
00007f828abcfe34  vmovaps xmm10, [rsp+0xC0]
00007f828abcfe3d  movaps xmm15, xmm10
00007f828abcfe41  addpd xmm15, xmm11
00007f828abcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007f828abcfe4c  ptest xmm2, xmm2
00007f828abcfe51  jnz 0x00007F828ABD2F23
00007f828abcfe57  vmovaps xmm11, [rsp+0x80]
00007f828abcfe60  vpermilpd xmm11, xmm11, 0x00
00007f828abcfe66  movaps xmm10, xmm12
00007f828abcfe6a  mulpd xmm10, xmm11
00007f828abcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007f828abcfe75  ptest xmm2, xmm2
00007f828abcfe7a  jnz 0x00007F828ABD3067
00007f828abcfe80  vmovaps xmm12, [rsp+0x80]
00007f828abcfe89  vpermilpd xmm12, xmm12, 0x00
00007f828abcfe8f  vmovaps xmm2, [rsp+0xA0]
00007f828abcfe98  vmovaps [rsp+0x30], xmm1
00007f828abcfe9e  movaps xmm11, xmm2
00007f828abcfea2  mulpd xmm11, xmm12
00007f828abcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007f828abcfead  ptest xmm1, xmm1
00007f828abcfeb2  jnz 0x00007F828ABD31AB
00007f828abcfeb8  movaps xmm1, xmm14
00007f828abcfebc  addpd xmm1, xmm6
00007f828abcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007f828abcfec5  ptest xmm12, xmm12
00007f828abcfecb  jnz 0x00007F828ABD32EE
00007f828abcfed1  vmovaps xmm12, [rsp+0x20]
00007f828abcfed7  movaps xmm14, xmm12
00007f828abcfedb  addpd xmm14, xmm5
00007f828abcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007f828abcfee6  ptest xmm6, xmm6
00007f828abcfeeb  jnz 0x00007F828ABD342F
00007f828abcfef1  vmovaps xmm12, [rsp+0x90]
00007f828abcfefa  vpermilpd xmm12, xmm12, 0x00
00007f828abcff00  movaps xmm6, xmm9
00007f828abcff04  mulpd xmm6, xmm12
00007f828abcff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007f828abcff0e  ptest xmm5, xmm5
00007f828abcff13  jnz 0x00007F828ABD3572
00007f828abcff19  movaps xmm12, xmm15
00007f828abcff1d  addpd xmm12, xmm13
00007f828abcff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007f828abcff28  ptest xmm9, xmm9
00007f828abcff2e  jnz 0x00007F828ABD36B4
00007f828abcff34  vmovaps xmm13, [rsp+0x30]
00007f828abcff3a  movaps xmm15, xmm13
00007f828abcff3e  addpd xmm15, xmm10
00007f828abcff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007f828abcff49  ptest xmm9, xmm9
00007f828abcff4f  jnz 0x00007F828ABD37F8
00007f828abcff55  vmovaps xmm13, [rsp+0xD0]
00007f828abcff5e  vmovaps xmm10, [rsp+0xD0]
00007f828abcff67  por xmm13, xmm10
00007f828abcff6c  movaps [r15+0x250], xmm13
00007f828abcff74  vmovaps [rsp+0x20], xmm7
00007f828abcff7a  vmovaps xmm13, [rsp+0x20]
00007f828abcff80  por xmm7, xmm13
00007f828abcff85  movaps [r15+0x2A0], xmm7
00007f828abcff8d  vmovaps [rsp+0x20], xmm3
00007f828abcff93  vmovaps xmm13, [rsp+0x20]
00007f828abcff99  por xmm3, xmm13
00007f828abcff9e  movaps [r15+0x1D0], xmm3
00007f828abcffa6  lea rax, [r14+0x40]
00007f828abcffaa  movups xmm13, [r13+rax*1]
00007f828abcffb0  movaps [r15+0x2C0], xmm13
00007f828abcffb8  vmovaps xmm10, [rsp+0x90]
00007f828abcffc1  vpermilpd xmm10, xmm10, 0x00
00007f828abcffc7  movaps xmm9, xmm8
00007f828abcffcb  mulpd xmm9, xmm10
00007f828abcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007f828abcffd6  ptest xmm5, xmm5
00007f828abcffdb  jnz 0x00007F828ABD3946
00007f828abcffe1  movaps xmm10, xmm1
00007f828abcffe5  addpd xmm10, xmm11
00007f828abcffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007f828abcfff0  ptest xmm8, xmm8
00007f828abcfff6  jnz 0x00007F828ABD3A8A
00007f828abcfffc  movaps xmm1, xmm14
00007f828abd0000  addpd xmm1, xmm6
00007f828abd0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007f828abd0009  ptest xmm11, xmm11
00007f828abd000f  jnz 0x00007F828ABD3BCD
00007f828abd0015  vmovaps xmm14, [rsp+0x90]
00007f828abd001e  vpermilpd xmm14, xmm14, 0x00
00007f828abd0024  movaps xmm11, xmm13
00007f828abd0028  mulpd xmm11, xmm14
00007f828abd002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007f828abd0033  ptest xmm8, xmm8
00007f828abd0039  jnz 0x00007F828ABD3D0E
00007f828abd003f  vmovaps xmm14, [rsp+0x90]
00007f828abd0048  vpermilpd xmm14, xmm14, 0x00
00007f828abd004e  vmovaps xmm8, [rsp+0x10]
00007f828abd0054  movaps xmm13, xmm8
00007f828abd0058  mulpd xmm13, xmm14
00007f828abd005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007f828abd0063  ptest xmm6, xmm6
00007f828abd0068  jnz 0x00007F828ABD3E52
00007f828abd006e  vmovaps xmm14, [rsp+0x60]
00007f828abd0074  vpermilpd xmm14, xmm14, 0x00
00007f828abd007a  movaps xmm8, xmm7
00007f828abd007e  mulpd xmm8, xmm14
00007f828abd0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007f828abd0089  ptest xmm6, xmm6
00007f828abd008e  jnz 0x00007F828ABD3F96
00007f828abd0094  movaps xmm14, xmm12
00007f828abd0098  addpd xmm14, xmm9
00007f828abd009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007f828abd00a3  ptest xmm7, xmm7
00007f828abd00a8  jnz 0x00007F828ABD40D9
00007f828abd00ae  vmovaps xmm12, [rsp+0x60]
00007f828abd00b4  vpermilpd xmm12, xmm12, 0x00
00007f828abd00ba  vmovaps xmm7, [rsp+0xF0]
00007f828abd00c3  movaps xmm9, xmm7
00007f828abd00c7  mulpd xmm9, xmm12
00007f828abd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007f828abd00d2  ptest xmm6, xmm6
00007f828abd00d7  jnz 0x00007F828ABD421D
00007f828abd00dd  movaps xmm12, xmm15
00007f828abd00e1  addpd xmm12, xmm11
00007f828abd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007f828abd00ec  ptest xmm7, xmm7
00007f828abd00f1  jnz 0x00007F828ABD4360
00007f828abd00f7  vmovaps xmm15, [rsp+0x60]
00007f828abd00fd  vpermilpd xmm15, xmm15, 0x00
00007f828abd0103  vmovaps xmm7, [rsp+0x40]
00007f828abd0109  movaps xmm11, xmm7
00007f828abd010d  mulpd xmm11, xmm15
00007f828abd0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007f828abd0118  ptest xmm6, xmm6
00007f828abd011d  jnz 0x00007F828ABD44A4
00007f828abd0123  movaps xmm15, xmm10
00007f828abd0127  addpd xmm15, xmm13
00007f828abd012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007f828abd0132  ptest xmm7, xmm7
00007f828abd0137  jnz 0x00007F828ABD45E7
00007f828abd013d  vmovaps xmm13, [rsp+0x60]
00007f828abd0143  vpermilpd xmm13, xmm13, 0x00
00007f828abd0149  vmovaps xmm7, [rsp+0x50]
00007f828abd014f  movaps xmm10, xmm7
00007f828abd0153  mulpd xmm10, xmm13
00007f828abd0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007f828abd015e  ptest xmm6, xmm6
00007f828abd0163  jnz 0x00007F828ABD472B
00007f828abd0169  movaps xmm13, xmm1
00007f828abd016d  addpd xmm13, xmm8
00007f828abd0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007f828abd0178  ptest xmm7, xmm7
00007f828abd017d  jnz 0x00007F828ABD486E
00007f828abd0183  lea rax, [r14+0x70]
00007f828abd0187  movups xmm1, [r13+rax*1]
00007f828abd018d  movaps [r15+0x240], xmm1
00007f828abd0195  movaps xmm8, xmm14
00007f828abd0199  addpd xmm8, xmm9
00007f828abd019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007f828abd01a4  ptest xmm7, xmm7
00007f828abd01a9  jnz 0x00007F828ABD49BB
00007f828abd01af  movaps [r15+0x170], xmm8
00007f828abd01b7  vmovaps xmm14, [rsp+0x70]
00007f828abd01bd  vpermilpd xmm14, xmm14, 0x00
00007f828abd01c3  movaps xmm9, xmm1
00007f828abd01c7  mulpd xmm9, xmm14
00007f828abd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007f828abd01d2  ptest xmm7, xmm7
00007f828abd01d7  jnz 0x00007F828ABD4AFF
00007f828abd01dd  vmovaps xmm1, [rsp+0x70]
00007f828abd01e3  vpermilpd xmm1, xmm1, 0x00
00007f828abd01e9  movaps xmm14, xmm4
00007f828abd01ed  mulpd xmm14, xmm1
00007f828abd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007f828abd01f8  ptest xmm7, xmm7
00007f828abd01fd  jnz 0x00007F828ABD4C42
00007f828abd0203  movaps [r15+0x180], xmm14
00007f828abd020b  movaps xmm1, xmm12
00007f828abd020f  addpd xmm1, xmm11
00007f828abd0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007f828abd0219  ptest xmm7, xmm7
00007f828abd021e  jnz 0x00007F828ABD4D84
00007f828abd0224  movaps [r15+0x210], xmm1
00007f828abd022c  movups xmm12, [r13+r14*1]
00007f828abd0232  lea rax, [r14+0x10]
00007f828abd0236  movups xmm11, [r13+rax*1]
00007f828abd023c  movaps [r15+0x230], xmm11
00007f828abd0244  movaps xmm7, xmm15
00007f828abd0248  addpd xmm7, xmm10
00007f828abd024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007f828abd0252  ptest xmm6, xmm6
00007f828abd0257  jnz 0x00007F828ABD4EDA
00007f828abd025d  movaps [r15+0x130], xmm7
00007f828abd0265  vmovaps xmm15, [rsp+0x70]
00007f828abd026b  vpermilpd xmm15, xmm15, 0x00
00007f828abd0271  movaps xmm10, xmm11
00007f828abd0275  mulpd xmm10, xmm15
00007f828abd027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007f828abd0280  ptest xmm6, xmm6
00007f828abd0285  jnz 0x00007F828ABD501C
00007f828abd028b  movaps [r15+0x220], xmm10
00007f828abd0293  vmovaps xmm15, [rsp+0x70]
00007f828abd0299  vpermilpd xmm15, xmm15, 0x00
00007f828abd029f  movaps xmm11, xmm12
00007f828abd02a3  mulpd xmm11, xmm15
00007f828abd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007f828abd02ae  ptest xmm6, xmm6
00007f828abd02b3  jnz 0x00007F828ABD5160
00007f828abd02b9  movaps xmm15, xmm13
00007f828abd02bd  addpd xmm15, xmm9
00007f828abd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007f828abd02c8  ptest xmm12, xmm12
00007f828abd02ce  jnz 0x00007F828ABD52A4
00007f828abd02d4  movaps [r15+0x140], xmm15
00007f828abd02dc  movaps xmm13, xmm8
00007f828abd02e0  addpd xmm13, xmm14
00007f828abd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007f828abd02eb  ptest xmm12, xmm12
00007f828abd02f1  jnz 0x00007F828ABD53E8
00007f828abd02f7  movaps [r15+0x150], xmm13
00007f828abd02ff  movaps xmm14, xmm1
00007f828abd0303  addpd xmm14, xmm10
00007f828abd0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007f828abd030e  ptest xmm12, xmm12
00007f828abd0314  jnz 0x00007F828ABD552C
00007f828abd031a  movaps [r15+0x160], xmm14
00007f828abd0322  movaps xmm1, xmm7
00007f828abd0325  addpd xmm1, xmm11
00007f828abd032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007f828abd032f  ptest xmm12, xmm12
00007f828abd0335  jnz 0x00007F828ABD566F
00007f828abd033b  movaps [r15+0x120], xmm1
00007f828abd0343  mov eax, 0x430920
00007f828abd0348  movups [r13+rax*1], xmm15
00007f828abd034e  mov eax, 0x430930
00007f828abd0353  movups [r13+rax*1], xmm13
00007f828abd0359  mov eax, 0x430940
00007f828abd035e  movups [r13+rax*1], xmm14
00007f828abd0364  mov eax, 0x430950
00007f828abd0369  movups [r13+rax*1], xmm1
00007f828abd036f  mov eax, [r15+0x108]
00007f828abd0376  sahf
00007f828abd0377  jnz 0x00007F828ABD03A9
00007f828abd0379  cmp dword ptr [r15+0x318], 0x00
00007f828abd0381  jz 0x00007F828ABDB900
00007f828abd0387  nop [rax+rax*1], ax
00007f828abd0390  nop [rax+rax*1], eax
00007f828abd0398  mov eax, 0x410444
00007f828abd039d  mov [r15+0x100], rax
00007f828abd03a4  jmp 0x00007F828A9FE110
00007f828abd03a9  cmp dword ptr [r15+0x318], 0x00
00007f828abd03b1  jz 0x00007F828ABD57E0
00007f828abd03b7  nop [rax+rax*1], ax
00007f828abd03c0  nop [rax+rax*1], eax
00007f828abd03c8  mov eax, 0x410278
00007f828abd03cd  mov [r15+0x100], rax
00007f828abd03d4  jmp 0x00007F828A9FE110
00007f828abd03d9  int3
00007f828abd03da  call 0x00007F828AAB52F0
00007f828abd03df  jmp 0x00007F828ABCF016
00007f828abd03e4  call 0x00007F828AAC4620
00007f828abd03e9  jmp 0x00007F828ABCF023
00007f828abd03ee  call 0x00007F828AAC33A0
00007f828abd03f3  jmp 0x00007F828ABCF035
00007f828abd03f8  call 0x00007F828AAC2120
00007f828abd03fd  jmp 0x00007F828ABCF03F
00007f828abd0402  call 0x00007F828AAC0860
00007f828abd0407  jmp 0x00007F828ABCF067
00007f828abd040c  call 0x00007F828AABF5F0
00007f828abd0411  jmp 0x00007F828ABCF073
00007f828abd0416  call 0x00007F828AAC0860
00007f828abd041b  jmp 0x00007F828ABCF0A5
00007f828abd0420  call 0x00007F828AABF5F0
00007f828abd0425  jmp 0x00007F828ABCF0B1
00007f828abd042a  call 0x00007F828AAC4740
00007f828abd042f  jmp 0x00007F828ABCF0BE
00007f828abd0434  call 0x00007F828AAB5400
00007f828abd0439  jmp 0x00007F828ABCF0CB
00007f828abd043e  call 0x00007F828AAB52F0
00007f828abd0443  jmp 0x00007F828ABCF0D8
00007f828abd0448  call 0x00007F828AAC4620
00007f828abd044d  jmp 0x00007F828ABCF0E5
00007f828abd0452  call 0x00007F828AAC0860
00007f828abd0457  jmp 0x00007F828ABCF10D
00007f828abd045c  call 0x00007F828AABF5F0
00007f828abd0461  jmp 0x00007F828ABCF119
00007f828abd0466  call 0x00007F828AA09D70
00007f828abd046b  jmp 0x00007F828ABCF11F
00007f828abd0470  call 0x00007F828AABE9C0
00007f828abd0475  jmp 0x00007F828ABCF129
00007f828abd047a  call 0x00007F828AAC0860
00007f828abd047f  jmp 0x00007F828ABCF151
00007f828abd0484  call 0x00007F828AABF5F0
00007f828abd0489  jmp 0x00007F828ABCF15D
00007f828abd048e  call 0x00007F828AABD750
00007f828abd0493  jmp 0x00007F828ABCF16A
00007f828abd0498  call 0x00007F828AABC4E0
00007f828abd049d  jmp 0x00007F828ABCF177
00007f828abd04a2  call 0x00007F828AAC4740
00007f828abd04a7  jmp 0x00007F828ABCF184
00007f828abd04ac  call 0x00007F828AAB5400
00007f828abd04b1  jmp 0x00007F828ABCF191
00007f828abd04b6  call 0x00007F828AAB52F0
00007f828abd04bb  jmp 0x00007F828ABCF19E
00007f828abd04c0  call 0x00007F828AAC4620
00007f828abd04c5  jmp 0x00007F828ABCF1AB
00007f828abd04ca  call 0x00007F828AAC0860
00007f828abd04cf  jmp 0x00007F828ABCF1BE
00007f828abd04d4  call 0x00007F828AABB270
00007f828abd04d9  jmp 0x00007F828ABCF1CB
00007f828abd04de  call 0x00007F828AABA000
00007f828abd04e3  jmp 0x00007F828ABCF1D8
00007f828abd04e8  call 0x00007F828AAB8D90
00007f828abd04ed  jmp 0x00007F828ABCF1E5
00007f828abd04f2  call 0x00007F828AAB8A20
00007f828abd04f7  jmp 0x00007F828ABCF1F2
00007f828abd04fc  call 0x00007F828AAB5400
00007f828abd0501  jmp 0x00007F828ABCF1FC
00007f828abd0506  call 0x00007F828AAC2240
00007f828abd050b  jmp 0x00007F828ABCF206
00007f828abd0510  call 0x00007F828AAB52F0
00007f828abd0515  jmp 0x00007F828ABCF210
00007f828abd051a  call 0x00007F828AAC2120
00007f828abd051f  jmp 0x00007F828ABCF21A
00007f828abd0524  call 0x00007F828AAB77B0
00007f828abd0529  jmp 0x00007F828ABCF224
00007f828abd052e  call 0x00007F828AAB6550
00007f828abd0533  jmp 0x00007F828ABCF22E
00007f828abd0538  call 0x00007F828AABFD50
00007f828abd053d  jmp 0x00007F828ABCF240
00007f828abd0542  call 0x00007F828AAB8EA0
00007f828abd0547  jmp 0x00007F828ABCF24A
00007f828abd054c  call 0x00007F828AABFC30
00007f828abd0551  jmp 0x00007F828ABCF257
00007f828abd0556  call 0x00007F828AAB8D90
00007f828abd055b  jmp 0x00007F828ABCF264
00007f828abd0560  call 0x00007F828AAC2240
00007f828abd0565  jmp 0x00007F828ABCF271
00007f828abd056a  call 0x00007F828AAB5400
00007f828abd056f  jmp 0x00007F828ABCF27E
00007f828abd0574  call 0x00007F828AAB52F0
00007f828abd0579  jmp 0x00007F828ABCF28B
00007f828abd057e  call 0x00007F828AAC2120
00007f828abd0583  jmp 0x00007F828ABCF298
00007f828abd0588  call 0x00007F828AAB52F0
00007f828abd058d  jmp 0x00007F828ABCF2AB
00007f828abd0592  call 0x00007F828AAB52F0
00007f828abd0597  jmp 0x00007F828ABCF2BE
00007f828abd059c  call 0x00007F828AAB52F0
00007f828abd05a1  jmp 0x00007F828ABCF2D1
00007f828abd05a6  call 0x00007F828AAB52F0
00007f828abd05ab  jmp 0x00007F828ABCF2E4
00007f828abd05b0  call 0x00007F828AAC2240
00007f828abd05b5  jmp 0x00007F828ABCF2F9
00007f828abd05ba  call 0x00007F828AAC2240
00007f828abd05bf  jmp 0x00007F828ABCF30C
00007f828abd05c4  call 0x00007F828AAC2120
00007f828abd05c9  jmp 0x00007F828ABCF319
00007f828abd05ce  call 0x00007F828AAB52F0
00007f828abd05d3  jmp 0x00007F828ABCF32C
00007f828abd05d8  call 0x00007F828AAB52F0
00007f828abd05dd  jmp 0x00007F828ABCF34F
00007f828abd05e2  call 0x00007F828AAB52F0
00007f828abd05e7  jmp 0x00007F828ABCF362
00007f828abd05ec  call 0x00007F828A9FF540
00007f828abd05f1  jmp 0x00007F828ABCF380
00007f828abd05f6  call 0x00007F828AA08C20
00007f828abd05fb  jmp 0x00007F828ABCF38A
00007f828abd0600  call 0x00007F828AAD6600
00007f828abd0605  jmp 0x00007F828ABCF396
00007f828abd060a  call 0x00007F828A9FF540
00007f828abd060f  jmp 0x00007F828ABCF3A6
00007f828abd0614  call 0x00007F828AAC0370
00007f828abd0619  jmp 0x00007F828ABCF3D4
00007f828abd061e  call 0x00007F828AABF100
00007f828abd0623  jmp 0x00007F828ABCF3DD
00007f828abd0628  call 0x00007F828AAC0370
00007f828abd062d  jmp 0x00007F828ABCF43B
00007f828abd0632  call 0x00007F828AABF100
00007f828abd0637  jmp 0x00007F828ABCF444
00007f828abd063c  call 0x00007F828AAC0370
00007f828abd0641  jmp 0x00007F828ABCF48B
00007f828abd0646  call 0x00007F828AABF100
00007f828abd064b  jmp 0x00007F828ABCF494
00007f828abd0650  call 0x00007F828AA0B720
00007f828abd0655  jmp 0x00007F828ABCF4D7
00007f828abd065a  call 0x00007F828AAB47C0
00007f828abd065f  jmp 0x00007F828ABCF4EA
00007f828abd0664  call 0x00007F828AA08B00
00007f828abd0669  jmp 0x00007F828ABCF501
00007f828abd066e  call 0x00007F828A9FF430
00007f828abd0673  jmp 0x00007F828ABCF514
00007f828abd0678  call 0x00007F828A9FF430
00007f828abd067d  jmp 0x00007F828ABCF527
00007f828abd0682  sub rsp, 0x08
00007f828abd0686  push rax
00007f828abd0687  push rcx
00007f828abd0688  push rdx
00007f828abd0689  push rdi
00007f828abd068a  push rsi
00007f828abd068b  push r8
00007f828abd068d  push r9
00007f828abd068f  push r10
00007f828abd0691  push r11
00007f828abd0693  sub rsp, 0xF0
00007f828abd069a  vmovaps [rsp], xmm0
00007f828abd069f  vmovaps [rsp+0x10], xmm2
00007f828abd06a5  vmovaps [rsp+0x20], xmm3
00007f828abd06ab  vmovaps [rsp+0x30], xmm4
00007f828abd06b1  vmovaps [rsp+0x40], xmm5
00007f828abd06b7  vmovaps [rsp+0x50], xmm6
00007f828abd06bd  vmovaps [rsp+0x60], xmm7
00007f828abd06c3  vmovaps [rsp+0x70], xmm8
00007f828abd06c9  vmovaps [rsp+0x80], xmm9
00007f828abd06d2  vmovaps [rsp+0x90], xmm10
00007f828abd06db  vmovaps [rsp+0xA0], xmm11
00007f828abd06e4  vmovaps [rsp+0xB0], xmm12
00007f828abd06ed  vmovaps [rsp+0xC0], xmm13
00007f828abd06f6  vmovaps [rsp+0xD0], xmm14
00007f828abd06ff  vmovaps [rsp+0xE0], xmm15
00007f828abd0708  sub rsp, 0x30
00007f828abd070c  movaps [rsp], xmm1
00007f828abd0710  movaps [rsp+0x10], xmm15
00007f828abd0716  movaps [rsp+0x20], xmm14
00007f828abd071c  lea rdi, [rsp]
00007f828abd0720  mov esi, 0x00
00007f828abd0725  mov rax, 0x5BFE27FA6530
00007f828abd072f  call rax
00007f828abd0731  movaps xmm1, [rsp]
00007f828abd0735  add rsp, 0x30
00007f828abd0739  vmovaps xmm0, [rsp]
00007f828abd073e  vmovaps xmm2, [rsp+0x10]
00007f828abd0744  vmovaps xmm3, [rsp+0x20]
00007f828abd074a  vmovaps xmm4, [rsp+0x30]
00007f828abd0750  vmovaps xmm5, [rsp+0x40]
00007f828abd0756  vmovaps xmm6, [rsp+0x50]
00007f828abd075c  vmovaps xmm7, [rsp+0x60]
00007f828abd0762  vmovaps xmm8, [rsp+0x70]
00007f828abd0768  vmovaps xmm9, [rsp+0x80]
00007f828abd0771  vmovaps xmm10, [rsp+0x90]
00007f828abd077a  vmovaps xmm11, [rsp+0xA0]
00007f828abd0783  vmovaps xmm12, [rsp+0xB0]
00007f828abd078c  vmovaps xmm13, [rsp+0xC0]
00007f828abd0795  vmovaps xmm14, [rsp+0xD0]
00007f828abd079e  vmovaps xmm15, [rsp+0xE0]
00007f828abd07a7  add rsp, 0xF0
00007f828abd07ae  pop r11
00007f828abd07b0  pop r10
00007f828abd07b2  pop r9
00007f828abd07b4  pop r8
00007f828abd07b6  pop rsi
00007f828abd07b7  pop rdi
00007f828abd07b8  pop rdx
00007f828abd07b9  pop rcx
00007f828abd07ba  pop rax
00007f828abd07bb  add rsp, 0x08
00007f828abd07bf  jmp 0x00007F828ABCF581
00007f828abd07c4  sub rsp, 0x08
00007f828abd07c8  push rax
00007f828abd07c9  push rcx
00007f828abd07ca  push rdx
00007f828abd07cb  push rdi
00007f828abd07cc  push rsi
00007f828abd07cd  push r8
00007f828abd07cf  push r9
00007f828abd07d1  push r10
00007f828abd07d3  push r11
00007f828abd07d5  sub rsp, 0xF0
00007f828abd07dc  vmovaps [rsp], xmm0
00007f828abd07e1  vmovaps [rsp+0x10], xmm1
00007f828abd07e7  vmovaps [rsp+0x20], xmm2
00007f828abd07ed  vmovaps [rsp+0x30], xmm3
00007f828abd07f3  vmovaps [rsp+0x40], xmm4
00007f828abd07f9  vmovaps [rsp+0x50], xmm5
00007f828abd07ff  vmovaps [rsp+0x60], xmm6
00007f828abd0805  vmovaps [rsp+0x70], xmm7
00007f828abd080b  vmovaps [rsp+0x80], xmm8
00007f828abd0814  vmovaps [rsp+0x90], xmm9
00007f828abd081d  vmovaps [rsp+0xA0], xmm10
00007f828abd0826  vmovaps [rsp+0xB0], xmm11
00007f828abd082f  vmovaps [rsp+0xC0], xmm12
00007f828abd0838  vmovaps [rsp+0xD0], xmm14
00007f828abd0841  vmovaps [rsp+0xE0], xmm15
00007f828abd084a  sub rsp, 0x30
00007f828abd084e  movaps [rsp], xmm13
00007f828abd0853  movaps [rsp+0x10], xmm1
00007f828abd0858  movaps [rsp+0x20], xmm14
00007f828abd085e  lea rdi, [rsp]
00007f828abd0862  mov esi, 0x00
00007f828abd0867  mov rax, 0x5BFE27FA6530
00007f828abd0871  call rax
00007f828abd0873  movaps xmm13, [rsp]
00007f828abd0878  add rsp, 0x30
00007f828abd087c  vmovaps xmm0, [rsp]
00007f828abd0881  vmovaps xmm1, [rsp+0x10]
00007f828abd0887  vmovaps xmm2, [rsp+0x20]
00007f828abd088d  vmovaps xmm3, [rsp+0x30]
00007f828abd0893  vmovaps xmm4, [rsp+0x40]
00007f828abd0899  vmovaps xmm5, [rsp+0x50]
00007f828abd089f  vmovaps xmm6, [rsp+0x60]
00007f828abd08a5  vmovaps xmm7, [rsp+0x70]
00007f828abd08ab  vmovaps xmm8, [rsp+0x80]
00007f828abd08b4  vmovaps xmm9, [rsp+0x90]
00007f828abd08bd  vmovaps xmm10, [rsp+0xA0]
00007f828abd08c6  vmovaps xmm11, [rsp+0xB0]
00007f828abd08cf  vmovaps xmm12, [rsp+0xC0]
00007f828abd08d8  vmovaps xmm14, [rsp+0xD0]
00007f828abd08e1  vmovaps xmm15, [rsp+0xE0]
00007f828abd08ea  add rsp, 0xF0
00007f828abd08f1  pop r11
00007f828abd08f3  pop r10
00007f828abd08f5  pop r9
00007f828abd08f7  pop r8
00007f828abd08f9  pop rsi
00007f828abd08fa  pop rdi
00007f828abd08fb  pop rdx
00007f828abd08fc  pop rcx
00007f828abd08fd  pop rax
00007f828abd08fe  add rsp, 0x08
00007f828abd0902  jmp 0x00007F828ABCF5CF
00007f828abd0907  sub rsp, 0x08
00007f828abd090b  push rax
00007f828abd090c  push rcx
00007f828abd090d  push rdx
00007f828abd090e  push rdi
00007f828abd090f  push rsi
00007f828abd0910  push r8
00007f828abd0912  push r9
00007f828abd0914  push r10
00007f828abd0916  push r11
00007f828abd0918  sub rsp, 0xF0
00007f828abd091f  vmovaps [rsp], xmm0
00007f828abd0924  vmovaps [rsp+0x10], xmm1
00007f828abd092a  vmovaps [rsp+0x20], xmm2
00007f828abd0930  vmovaps [rsp+0x30], xmm3
00007f828abd0936  vmovaps [rsp+0x40], xmm4
00007f828abd093c  vmovaps [rsp+0x50], xmm5
00007f828abd0942  vmovaps [rsp+0x60], xmm6
00007f828abd0948  vmovaps [rsp+0x70], xmm7
00007f828abd094e  vmovaps [rsp+0x80], xmm8
00007f828abd0957  vmovaps [rsp+0x90], xmm9
00007f828abd0960  vmovaps [rsp+0xA0], xmm10
00007f828abd0969  vmovaps [rsp+0xB0], xmm11
00007f828abd0972  vmovaps [rsp+0xC0], xmm12
00007f828abd097b  vmovaps [rsp+0xD0], xmm13
00007f828abd0984  vmovaps [rsp+0xE0], xmm14
00007f828abd098d  sub rsp, 0x30
00007f828abd0991  movaps [rsp], xmm15
00007f828abd0996  movaps [rsp+0x10], xmm14
00007f828abd099c  movaps [rsp+0x20], xmm1
00007f828abd09a1  lea rdi, [rsp]
00007f828abd09a5  mov esi, 0x00
00007f828abd09aa  mov rax, 0x5BFE27FA6530
00007f828abd09b4  call rax
00007f828abd09b6  movaps xmm15, [rsp]
00007f828abd09bb  add rsp, 0x30
00007f828abd09bf  vmovaps xmm0, [rsp]
00007f828abd09c4  vmovaps xmm1, [rsp+0x10]
00007f828abd09ca  vmovaps xmm2, [rsp+0x20]
00007f828abd09d0  vmovaps xmm3, [rsp+0x30]
00007f828abd09d6  vmovaps xmm4, [rsp+0x40]
00007f828abd09dc  vmovaps xmm5, [rsp+0x50]
00007f828abd09e2  vmovaps xmm6, [rsp+0x60]
00007f828abd09e8  vmovaps xmm7, [rsp+0x70]
00007f828abd09ee  vmovaps xmm8, [rsp+0x80]
00007f828abd09f7  vmovaps xmm9, [rsp+0x90]
00007f828abd0a00  vmovaps xmm10, [rsp+0xA0]
00007f828abd0a09  vmovaps xmm11, [rsp+0xB0]
00007f828abd0a12  vmovaps xmm12, [rsp+0xC0]
00007f828abd0a1b  vmovaps xmm13, [rsp+0xD0]
00007f828abd0a24  vmovaps xmm14, [rsp+0xE0]
00007f828abd0a2d  add rsp, 0xF0
00007f828abd0a34  pop r11
00007f828abd0a36  pop r10
00007f828abd0a38  pop r9
00007f828abd0a3a  pop r8
00007f828abd0a3c  pop rsi
00007f828abd0a3d  pop rdi
00007f828abd0a3e  pop rdx
00007f828abd0a3f  pop rcx
00007f828abd0a40  pop rax
00007f828abd0a41  add rsp, 0x08
00007f828abd0a45  jmp 0x00007F828ABCF617
00007f828abd0a4a  sub rsp, 0x08
00007f828abd0a4e  push rax
00007f828abd0a4f  push rcx
00007f828abd0a50  push rdx
00007f828abd0a51  push rdi
00007f828abd0a52  push rsi
00007f828abd0a53  push r8
00007f828abd0a55  push r9
00007f828abd0a57  push r10
00007f828abd0a59  push r11
00007f828abd0a5b  sub rsp, 0xF0
00007f828abd0a62  vmovaps [rsp], xmm0
00007f828abd0a67  vmovaps [rsp+0x10], xmm2
00007f828abd0a6d  vmovaps [rsp+0x20], xmm3
00007f828abd0a73  vmovaps [rsp+0x30], xmm4
00007f828abd0a79  vmovaps [rsp+0x40], xmm5
00007f828abd0a7f  vmovaps [rsp+0x50], xmm6
00007f828abd0a85  vmovaps [rsp+0x60], xmm7
00007f828abd0a8b  vmovaps [rsp+0x70], xmm8
00007f828abd0a91  vmovaps [rsp+0x80], xmm9
00007f828abd0a9a  vmovaps [rsp+0x90], xmm10
00007f828abd0aa3  vmovaps [rsp+0xA0], xmm11
00007f828abd0aac  vmovaps [rsp+0xB0], xmm12
00007f828abd0ab5  vmovaps [rsp+0xC0], xmm13
00007f828abd0abe  vmovaps [rsp+0xD0], xmm14
00007f828abd0ac7  vmovaps [rsp+0xE0], xmm15
00007f828abd0ad0  sub rsp, 0x30
00007f828abd0ad4  movaps [rsp], xmm1
00007f828abd0ad8  movaps [rsp+0x10], xmm14
00007f828abd0ade  movaps [rsp+0x20], xmm10
00007f828abd0ae4  lea rdi, [rsp]
00007f828abd0ae8  mov esi, 0x00
00007f828abd0aed  mov rax, 0x5BFE27FA6530
00007f828abd0af7  call rax
00007f828abd0af9  movaps xmm1, [rsp]
00007f828abd0afd  add rsp, 0x30
00007f828abd0b01  vmovaps xmm0, [rsp]
00007f828abd0b06  vmovaps xmm2, [rsp+0x10]
00007f828abd0b0c  vmovaps xmm3, [rsp+0x20]
00007f828abd0b12  vmovaps xmm4, [rsp+0x30]
00007f828abd0b18  vmovaps xmm5, [rsp+0x40]
00007f828abd0b1e  vmovaps xmm6, [rsp+0x50]
00007f828abd0b24  vmovaps xmm7, [rsp+0x60]
00007f828abd0b2a  vmovaps xmm8, [rsp+0x70]
00007f828abd0b30  vmovaps xmm9, [rsp+0x80]
00007f828abd0b39  vmovaps xmm10, [rsp+0x90]
00007f828abd0b42  vmovaps xmm11, [rsp+0xA0]
00007f828abd0b4b  vmovaps xmm12, [rsp+0xB0]
00007f828abd0b54  vmovaps xmm13, [rsp+0xC0]
00007f828abd0b5d  vmovaps xmm14, [rsp+0xD0]
00007f828abd0b66  vmovaps xmm15, [rsp+0xE0]
00007f828abd0b6f  add rsp, 0xF0
00007f828abd0b76  pop r11
00007f828abd0b78  pop r10
00007f828abd0b7a  pop r9
00007f828abd0b7c  pop r8
00007f828abd0b7e  pop rsi
00007f828abd0b7f  pop rdi
00007f828abd0b80  pop rdx
00007f828abd0b81  pop rcx
00007f828abd0b82  pop rax
00007f828abd0b83  add rsp, 0x08
00007f828abd0b87  jmp 0x00007F828ABCF631
00007f828abd0b8c  sub rsp, 0x08
00007f828abd0b90  push rax
00007f828abd0b91  push rcx
00007f828abd0b92  push rdx
00007f828abd0b93  push rdi
00007f828abd0b94  push rsi
00007f828abd0b95  push r8
00007f828abd0b97  push r9
00007f828abd0b99  push r10
00007f828abd0b9b  push r11
00007f828abd0b9d  sub rsp, 0xF0
00007f828abd0ba4  vmovaps [rsp], xmm0
00007f828abd0ba9  vmovaps [rsp+0x10], xmm1
00007f828abd0baf  vmovaps [rsp+0x20], xmm2
00007f828abd0bb5  vmovaps [rsp+0x30], xmm3
00007f828abd0bbb  vmovaps [rsp+0x40], xmm4
00007f828abd0bc1  vmovaps [rsp+0x50], xmm5
00007f828abd0bc7  vmovaps [rsp+0x60], xmm6
00007f828abd0bcd  vmovaps [rsp+0x70], xmm7
00007f828abd0bd3  vmovaps [rsp+0x80], xmm8
00007f828abd0bdc  vmovaps [rsp+0x90], xmm9
00007f828abd0be5  vmovaps [rsp+0xA0], xmm10
00007f828abd0bee  vmovaps [rsp+0xB0], xmm11
00007f828abd0bf7  vmovaps [rsp+0xC0], xmm12
00007f828abd0c00  vmovaps [rsp+0xD0], xmm14
00007f828abd0c09  vmovaps [rsp+0xE0], xmm15
00007f828abd0c12  sub rsp, 0x30
00007f828abd0c16  movaps [rsp], xmm13
00007f828abd0c1b  movaps [rsp+0x10], xmm14
00007f828abd0c21  movaps [rsp+0x20], xmm2
00007f828abd0c26  lea rdi, [rsp]
00007f828abd0c2a  mov esi, 0x00
00007f828abd0c2f  mov rax, 0x5BFE27FA6530
00007f828abd0c39  call rax
00007f828abd0c3b  movaps xmm13, [rsp]
00007f828abd0c40  add rsp, 0x30
00007f828abd0c44  vmovaps xmm0, [rsp]
00007f828abd0c49  vmovaps xmm1, [rsp+0x10]
00007f828abd0c4f  vmovaps xmm2, [rsp+0x20]
00007f828abd0c55  vmovaps xmm3, [rsp+0x30]
00007f828abd0c5b  vmovaps xmm4, [rsp+0x40]
00007f828abd0c61  vmovaps xmm5, [rsp+0x50]
00007f828abd0c67  vmovaps xmm6, [rsp+0x60]
00007f828abd0c6d  vmovaps xmm7, [rsp+0x70]
00007f828abd0c73  vmovaps xmm8, [rsp+0x80]
00007f828abd0c7c  vmovaps xmm9, [rsp+0x90]
00007f828abd0c85  vmovaps xmm10, [rsp+0xA0]
00007f828abd0c8e  vmovaps xmm11, [rsp+0xB0]
00007f828abd0c97  vmovaps xmm12, [rsp+0xC0]
00007f828abd0ca0  vmovaps xmm14, [rsp+0xD0]
00007f828abd0ca9  vmovaps xmm15, [rsp+0xE0]
00007f828abd0cb2  add rsp, 0xF0
00007f828abd0cb9  pop r11
00007f828abd0cbb  pop r10
00007f828abd0cbd  pop r9
00007f828abd0cbf  pop r8
00007f828abd0cc1  pop rsi
00007f828abd0cc2  pop rdi
00007f828abd0cc3  pop rdx
00007f828abd0cc4  pop rcx
00007f828abd0cc5  pop rax
00007f828abd0cc6  add rsp, 0x08
00007f828abd0cca  jmp 0x00007F828ABCF64C
00007f828abd0ccf  sub rsp, 0x08
00007f828abd0cd3  push rax
00007f828abd0cd4  push rcx
00007f828abd0cd5  push rdx
00007f828abd0cd6  push rdi
00007f828abd0cd7  push rsi
00007f828abd0cd8  push r8
00007f828abd0cda  push r9
00007f828abd0cdc  push r10
00007f828abd0cde  push r11
00007f828abd0ce0  sub rsp, 0xF0
00007f828abd0ce7  vmovaps [rsp], xmm0
00007f828abd0cec  vmovaps [rsp+0x10], xmm2
00007f828abd0cf2  vmovaps [rsp+0x20], xmm3
00007f828abd0cf8  vmovaps [rsp+0x30], xmm4
00007f828abd0cfe  vmovaps [rsp+0x40], xmm5
00007f828abd0d04  vmovaps [rsp+0x50], xmm6
00007f828abd0d0a  vmovaps [rsp+0x60], xmm7
00007f828abd0d10  vmovaps [rsp+0x70], xmm8
00007f828abd0d16  vmovaps [rsp+0x80], xmm9
00007f828abd0d1f  vmovaps [rsp+0x90], xmm10
00007f828abd0d28  vmovaps [rsp+0xA0], xmm11
00007f828abd0d31  vmovaps [rsp+0xB0], xmm12
00007f828abd0d3a  vmovaps [rsp+0xC0], xmm13
00007f828abd0d43  vmovaps [rsp+0xD0], xmm14
00007f828abd0d4c  vmovaps [rsp+0xE0], xmm15
00007f828abd0d55  sub rsp, 0x30
00007f828abd0d59  movaps [rsp], xmm1
00007f828abd0d5d  movaps [rsp+0x10], xmm10
00007f828abd0d63  movaps [rsp+0x20], xmm2
00007f828abd0d68  lea rdi, [rsp]
00007f828abd0d6c  mov esi, 0x00
00007f828abd0d71  mov rax, 0x5BFE27FA6530
00007f828abd0d7b  call rax
00007f828abd0d7d  movaps xmm1, [rsp]
00007f828abd0d81  add rsp, 0x30
00007f828abd0d85  vmovaps xmm0, [rsp]
00007f828abd0d8a  vmovaps xmm2, [rsp+0x10]
00007f828abd0d90  vmovaps xmm3, [rsp+0x20]
00007f828abd0d96  vmovaps xmm4, [rsp+0x30]
00007f828abd0d9c  vmovaps xmm5, [rsp+0x40]
00007f828abd0da2  vmovaps xmm6, [rsp+0x50]
00007f828abd0da8  vmovaps xmm7, [rsp+0x60]
00007f828abd0dae  vmovaps xmm8, [rsp+0x70]
00007f828abd0db4  vmovaps xmm9, [rsp+0x80]
00007f828abd0dbd  vmovaps xmm10, [rsp+0x90]
00007f828abd0dc6  vmovaps xmm11, [rsp+0xA0]
00007f828abd0dcf  vmovaps xmm12, [rsp+0xB0]
00007f828abd0dd8  vmovaps xmm13, [rsp+0xC0]
00007f828abd0de1  vmovaps xmm14, [rsp+0xD0]
00007f828abd0dea  vmovaps xmm15, [rsp+0xE0]
00007f828abd0df3  add rsp, 0xF0
00007f828abd0dfa  pop r11
00007f828abd0dfc  pop r10
00007f828abd0dfe  pop r9
00007f828abd0e00  pop r8
00007f828abd0e02  pop rsi
00007f828abd0e03  pop rdi
00007f828abd0e04  pop rdx
00007f828abd0e05  pop rcx
00007f828abd0e06  pop rax
00007f828abd0e07  add rsp, 0x08
00007f828abd0e0b  jmp 0x00007F828ABCF6B4
00007f828abd0e10  sub rsp, 0x08
00007f828abd0e14  push rax
00007f828abd0e15  push rcx
00007f828abd0e16  push rdx
00007f828abd0e17  push rdi
00007f828abd0e18  push rsi
00007f828abd0e19  push r8
00007f828abd0e1b  push r9
00007f828abd0e1d  push r10
00007f828abd0e1f  push r11
00007f828abd0e21  sub rsp, 0xF0
00007f828abd0e28  vmovaps [rsp], xmm0
00007f828abd0e2d  vmovaps [rsp+0x10], xmm1
00007f828abd0e33  vmovaps [rsp+0x20], xmm2
00007f828abd0e39  vmovaps [rsp+0x30], xmm3
00007f828abd0e3f  vmovaps [rsp+0x40], xmm4
00007f828abd0e45  vmovaps [rsp+0x50], xmm5
00007f828abd0e4b  vmovaps [rsp+0x60], xmm6
00007f828abd0e51  vmovaps [rsp+0x70], xmm7
00007f828abd0e57  vmovaps [rsp+0x80], xmm8
00007f828abd0e60  vmovaps [rsp+0x90], xmm9
00007f828abd0e69  vmovaps [rsp+0xA0], xmm10
00007f828abd0e72  vmovaps [rsp+0xB0], xmm11
00007f828abd0e7b  vmovaps [rsp+0xC0], xmm12
00007f828abd0e84  vmovaps [rsp+0xD0], xmm13
00007f828abd0e8d  vmovaps [rsp+0xE0], xmm14
00007f828abd0e96  sub rsp, 0x30
00007f828abd0e9a  movaps [rsp], xmm15
00007f828abd0e9f  movaps [rsp+0x10], xmm10
00007f828abd0ea5  movaps [rsp+0x20], xmm2
00007f828abd0eaa  lea rdi, [rsp]
00007f828abd0eae  mov esi, 0x00
00007f828abd0eb3  mov rax, 0x5BFE27FA6530
00007f828abd0ebd  call rax
00007f828abd0ebf  movaps xmm15, [rsp]
00007f828abd0ec4  add rsp, 0x30
00007f828abd0ec8  vmovaps xmm0, [rsp]
00007f828abd0ecd  vmovaps xmm1, [rsp+0x10]
00007f828abd0ed3  vmovaps xmm2, [rsp+0x20]
00007f828abd0ed9  vmovaps xmm3, [rsp+0x30]
00007f828abd0edf  vmovaps xmm4, [rsp+0x40]
00007f828abd0ee5  vmovaps xmm5, [rsp+0x50]
00007f828abd0eeb  vmovaps xmm6, [rsp+0x60]
00007f828abd0ef1  vmovaps xmm7, [rsp+0x70]
00007f828abd0ef7  vmovaps xmm8, [rsp+0x80]
00007f828abd0f00  vmovaps xmm9, [rsp+0x90]
00007f828abd0f09  vmovaps xmm10, [rsp+0xA0]
00007f828abd0f12  vmovaps xmm11, [rsp+0xB0]
00007f828abd0f1b  vmovaps xmm12, [rsp+0xC0]
00007f828abd0f24  vmovaps xmm13, [rsp+0xD0]
00007f828abd0f2d  vmovaps xmm14, [rsp+0xE0]
00007f828abd0f36  add rsp, 0xF0
00007f828abd0f3d  pop r11
00007f828abd0f3f  pop r10
00007f828abd0f41  pop r9
00007f828abd0f43  pop r8
00007f828abd0f45  pop rsi
00007f828abd0f46  pop rdi
00007f828abd0f47  pop rdx
00007f828abd0f48  pop rcx
00007f828abd0f49  pop rax
00007f828abd0f4a  add rsp, 0x08
00007f828abd0f4e  jmp 0x00007F828ABCF706
00007f828abd0f53  sub rsp, 0x08
00007f828abd0f57  push rax
00007f828abd0f58  push rcx
00007f828abd0f59  push rdx
00007f828abd0f5a  push rdi
00007f828abd0f5b  push rsi
00007f828abd0f5c  push r8
00007f828abd0f5e  push r9
00007f828abd0f60  push r10
00007f828abd0f62  push r11
00007f828abd0f64  sub rsp, 0xF0
00007f828abd0f6b  vmovaps [rsp], xmm0
00007f828abd0f70  vmovaps [rsp+0x10], xmm2
00007f828abd0f76  vmovaps [rsp+0x20], xmm3
00007f828abd0f7c  vmovaps [rsp+0x30], xmm4
00007f828abd0f82  vmovaps [rsp+0x40], xmm5
00007f828abd0f88  vmovaps [rsp+0x50], xmm6
00007f828abd0f8e  vmovaps [rsp+0x60], xmm7
00007f828abd0f94  vmovaps [rsp+0x70], xmm8
00007f828abd0f9a  vmovaps [rsp+0x80], xmm9
00007f828abd0fa3  vmovaps [rsp+0x90], xmm10
00007f828abd0fac  vmovaps [rsp+0xA0], xmm11
00007f828abd0fb5  vmovaps [rsp+0xB0], xmm12
00007f828abd0fbe  vmovaps [rsp+0xC0], xmm13
00007f828abd0fc7  vmovaps [rsp+0xD0], xmm14
00007f828abd0fd0  vmovaps [rsp+0xE0], xmm15
00007f828abd0fd9  sub rsp, 0x30
00007f828abd0fdd  movaps [rsp], xmm1
00007f828abd0fe1  movaps [rsp+0x10], xmm10
00007f828abd0fe7  movaps [rsp+0x20], xmm12
00007f828abd0fed  lea rdi, [rsp]
00007f828abd0ff1  mov esi, 0x00
00007f828abd0ff6  mov rax, 0x5BFE27FA6530
00007f828abd1000  call rax
00007f828abd1002  movaps xmm1, [rsp]
00007f828abd1006  add rsp, 0x30
00007f828abd100a  vmovaps xmm0, [rsp]
00007f828abd100f  vmovaps xmm2, [rsp+0x10]
00007f828abd1015  vmovaps xmm3, [rsp+0x20]
00007f828abd101b  vmovaps xmm4, [rsp+0x30]
00007f828abd1021  vmovaps xmm5, [rsp+0x40]
00007f828abd1027  vmovaps xmm6, [rsp+0x50]
00007f828abd102d  vmovaps xmm7, [rsp+0x60]
00007f828abd1033  vmovaps xmm8, [rsp+0x70]
00007f828abd1039  vmovaps xmm9, [rsp+0x80]
00007f828abd1042  vmovaps xmm10, [rsp+0x90]
00007f828abd104b  vmovaps xmm11, [rsp+0xA0]
00007f828abd1054  vmovaps xmm12, [rsp+0xB0]
00007f828abd105d  vmovaps xmm13, [rsp+0xC0]
00007f828abd1066  vmovaps xmm14, [rsp+0xD0]
00007f828abd106f  vmovaps xmm15, [rsp+0xE0]
00007f828abd1078  add rsp, 0xF0
00007f828abd107f  pop r11
00007f828abd1081  pop r10
00007f828abd1083  pop r9
00007f828abd1085  pop r8
00007f828abd1087  pop rsi
00007f828abd1088  pop rdi
00007f828abd1089  pop rdx
00007f828abd108a  pop rcx
00007f828abd108b  pop rax
00007f828abd108c  add rsp, 0x08
00007f828abd1090  jmp 0x00007F828ABCF732
00007f828abd1095  sub rsp, 0x08
00007f828abd1099  push rax
00007f828abd109a  push rcx
00007f828abd109b  push rdx
00007f828abd109c  push rdi
00007f828abd109d  push rsi
00007f828abd109e  push r8
00007f828abd10a0  push r9
00007f828abd10a2  push r10
00007f828abd10a4  push r11
00007f828abd10a6  sub rsp, 0xF0
00007f828abd10ad  vmovaps [rsp], xmm0
00007f828abd10b2  vmovaps [rsp+0x10], xmm1
00007f828abd10b8  vmovaps [rsp+0x20], xmm2
00007f828abd10be  vmovaps [rsp+0x30], xmm3
00007f828abd10c4  vmovaps [rsp+0x40], xmm4
00007f828abd10ca  vmovaps [rsp+0x50], xmm5
00007f828abd10d0  vmovaps [rsp+0x60], xmm6
00007f828abd10d6  vmovaps [rsp+0x70], xmm7
00007f828abd10dc  vmovaps [rsp+0x80], xmm8
00007f828abd10e5  vmovaps [rsp+0x90], xmm9
00007f828abd10ee  vmovaps [rsp+0xA0], xmm10
00007f828abd10f7  vmovaps [rsp+0xB0], xmm11
00007f828abd1100  vmovaps [rsp+0xC0], xmm12
00007f828abd1109  vmovaps [rsp+0xD0], xmm13
00007f828abd1112  vmovaps [rsp+0xE0], xmm14
00007f828abd111b  sub rsp, 0x30
00007f828abd111f  movaps [rsp], xmm15
00007f828abd1124  movaps [rsp+0x10], xmm10
00007f828abd112a  movaps [rsp+0x20], xmm12
00007f828abd1130  lea rdi, [rsp]
00007f828abd1134  mov esi, 0x00
00007f828abd1139  mov rax, 0x5BFE27FA6530
00007f828abd1143  call rax
00007f828abd1145  movaps xmm15, [rsp]
00007f828abd114a  add rsp, 0x30
00007f828abd114e  vmovaps xmm0, [rsp]
00007f828abd1153  vmovaps xmm1, [rsp+0x10]
00007f828abd1159  vmovaps xmm2, [rsp+0x20]
00007f828abd115f  vmovaps xmm3, [rsp+0x30]
00007f828abd1165  vmovaps xmm4, [rsp+0x40]
00007f828abd116b  vmovaps xmm5, [rsp+0x50]
00007f828abd1171  vmovaps xmm6, [rsp+0x60]
00007f828abd1177  vmovaps xmm7, [rsp+0x70]
00007f828abd117d  vmovaps xmm8, [rsp+0x80]
00007f828abd1186  vmovaps xmm9, [rsp+0x90]
00007f828abd118f  vmovaps xmm10, [rsp+0xA0]
00007f828abd1198  vmovaps xmm11, [rsp+0xB0]
00007f828abd11a1  vmovaps xmm12, [rsp+0xC0]
00007f828abd11aa  vmovaps xmm13, [rsp+0xD0]
00007f828abd11b3  vmovaps xmm14, [rsp+0xE0]
00007f828abd11bc  add rsp, 0xF0
00007f828abd11c3  pop r11
00007f828abd11c5  pop r10
00007f828abd11c7  pop r9
00007f828abd11c9  pop r8
00007f828abd11cb  pop rsi
00007f828abd11cc  pop rdi
00007f828abd11cd  pop rdx
00007f828abd11ce  pop rcx
00007f828abd11cf  pop rax
00007f828abd11d0  add rsp, 0x08
00007f828abd11d4  jmp 0x00007F828ABCF75E
00007f828abd11d9  call 0x00007F828A9FF430
00007f828abd11de  jmp 0x00007F828ABCF7EE
00007f828abd11e3  call 0x00007F828A9FF430
00007f828abd11e8  jmp 0x00007F828ABCF801
00007f828abd11ed  sub rsp, 0x08
00007f828abd11f1  push rax
00007f828abd11f2  push rcx
00007f828abd11f3  push rdx
00007f828abd11f4  push rdi
00007f828abd11f5  push rsi
00007f828abd11f6  push r8
00007f828abd11f8  push r9
00007f828abd11fa  push r10
00007f828abd11fc  push r11
00007f828abd11fe  sub rsp, 0xF0
00007f828abd1205  vmovaps [rsp], xmm0
00007f828abd120a  vmovaps [rsp+0x10], xmm2
00007f828abd1210  vmovaps [rsp+0x20], xmm3
00007f828abd1216  vmovaps [rsp+0x30], xmm4
00007f828abd121c  vmovaps [rsp+0x40], xmm5
00007f828abd1222  vmovaps [rsp+0x50], xmm6
00007f828abd1228  vmovaps [rsp+0x60], xmm7
00007f828abd122e  vmovaps [rsp+0x70], xmm8
00007f828abd1234  vmovaps [rsp+0x80], xmm9
00007f828abd123d  vmovaps [rsp+0x90], xmm10
00007f828abd1246  vmovaps [rsp+0xA0], xmm11
00007f828abd124f  vmovaps [rsp+0xB0], xmm12
00007f828abd1258  vmovaps [rsp+0xC0], xmm13
00007f828abd1261  vmovaps [rsp+0xD0], xmm14
00007f828abd126a  vmovaps [rsp+0xE0], xmm15
00007f828abd1273  sub rsp, 0x30
00007f828abd1277  movaps [rsp], xmm1
00007f828abd127b  movaps [rsp+0x10], xmm13
00007f828abd1281  movaps [rsp+0x20], xmm2
00007f828abd1286  lea rdi, [rsp]
00007f828abd128a  mov esi, 0x00
00007f828abd128f  mov rax, 0x5BFE27FA6530
00007f828abd1299  call rax
00007f828abd129b  movaps xmm1, [rsp]
00007f828abd129f  add rsp, 0x30
00007f828abd12a3  vmovaps xmm0, [rsp]
00007f828abd12a8  vmovaps xmm2, [rsp+0x10]
00007f828abd12ae  vmovaps xmm3, [rsp+0x20]
00007f828abd12b4  vmovaps xmm4, [rsp+0x30]
00007f828abd12ba  vmovaps xmm5, [rsp+0x40]
00007f828abd12c0  vmovaps xmm6, [rsp+0x50]
00007f828abd12c6  vmovaps xmm7, [rsp+0x60]
00007f828abd12cc  vmovaps xmm8, [rsp+0x70]
00007f828abd12d2  vmovaps xmm9, [rsp+0x80]
00007f828abd12db  vmovaps xmm10, [rsp+0x90]
00007f828abd12e4  vmovaps xmm11, [rsp+0xA0]
00007f828abd12ed  vmovaps xmm12, [rsp+0xB0]
00007f828abd12f6  vmovaps xmm13, [rsp+0xC0]
00007f828abd12ff  vmovaps xmm14, [rsp+0xD0]
00007f828abd1308  vmovaps xmm15, [rsp+0xE0]
00007f828abd1311  add rsp, 0xF0
00007f828abd1318  pop r11
00007f828abd131a  pop r10
00007f828abd131c  pop r9
00007f828abd131e  pop r8
00007f828abd1320  pop rsi
00007f828abd1321  pop rdi
00007f828abd1322  pop rdx
00007f828abd1323  pop rcx
00007f828abd1324  pop rax
00007f828abd1325  add rsp, 0x08
00007f828abd1329  jmp 0x00007F828ABCF82C
00007f828abd132e  call 0x00007F828AA0E760
00007f828abd1333  jmp 0x00007F828ABCF839
00007f828abd1338  sub rsp, 0x08
00007f828abd133c  push rax
00007f828abd133d  push rcx
00007f828abd133e  push rdx
00007f828abd133f  push rdi
00007f828abd1340  push rsi
00007f828abd1341  push r8
00007f828abd1343  push r9
00007f828abd1345  push r10
00007f828abd1347  push r11
00007f828abd1349  sub rsp, 0xF0
00007f828abd1350  vmovaps [rsp], xmm0
00007f828abd1355  vmovaps [rsp+0x10], xmm1
00007f828abd135b  vmovaps [rsp+0x20], xmm2
00007f828abd1361  vmovaps [rsp+0x30], xmm3
00007f828abd1367  vmovaps [rsp+0x40], xmm4
00007f828abd136d  vmovaps [rsp+0x50], xmm5
00007f828abd1373  vmovaps [rsp+0x60], xmm6
00007f828abd1379  vmovaps [rsp+0x70], xmm7
00007f828abd137f  vmovaps [rsp+0x80], xmm8
00007f828abd1388  vmovaps [rsp+0x90], xmm9
00007f828abd1391  vmovaps [rsp+0xA0], xmm10
00007f828abd139a  vmovaps [rsp+0xB0], xmm11
00007f828abd13a3  vmovaps [rsp+0xC0], xmm12
00007f828abd13ac  vmovaps [rsp+0xD0], xmm14
00007f828abd13b5  vmovaps [rsp+0xE0], xmm15
00007f828abd13be  sub rsp, 0x30
00007f828abd13c2  movaps [rsp], xmm13
00007f828abd13c7  movaps [rsp+0x10], xmm2
00007f828abd13cc  movaps [rsp+0x20], xmm1
00007f828abd13d1  lea rdi, [rsp]
00007f828abd13d5  mov esi, 0x00
00007f828abd13da  mov rax, 0x5BFE27FA6530
00007f828abd13e4  call rax
00007f828abd13e6  movaps xmm13, [rsp]
00007f828abd13eb  add rsp, 0x30
00007f828abd13ef  vmovaps xmm0, [rsp]
00007f828abd13f4  vmovaps xmm1, [rsp+0x10]
00007f828abd13fa  vmovaps xmm2, [rsp+0x20]
00007f828abd1400  vmovaps xmm3, [rsp+0x30]
00007f828abd1406  vmovaps xmm4, [rsp+0x40]
00007f828abd140c  vmovaps xmm5, [rsp+0x50]
00007f828abd1412  vmovaps xmm6, [rsp+0x60]
00007f828abd1418  vmovaps xmm7, [rsp+0x70]
00007f828abd141e  vmovaps xmm8, [rsp+0x80]
00007f828abd1427  vmovaps xmm9, [rsp+0x90]
00007f828abd1430  vmovaps xmm10, [rsp+0xA0]
00007f828abd1439  vmovaps xmm11, [rsp+0xB0]
00007f828abd1442  vmovaps xmm12, [rsp+0xC0]
00007f828abd144b  vmovaps xmm14, [rsp+0xD0]
00007f828abd1454  vmovaps xmm15, [rsp+0xE0]
00007f828abd145d  add rsp, 0xF0
00007f828abd1464  pop r11
00007f828abd1466  pop r10
00007f828abd1468  pop r9
00007f828abd146a  pop r8
00007f828abd146c  pop rsi
00007f828abd146d  pop rdi
00007f828abd146e  pop rdx
00007f828abd146f  pop rcx
00007f828abd1470  pop rax
00007f828abd1471  add rsp, 0x08
00007f828abd1475  jmp 0x00007F828ABCF878
00007f828abd147a  sub rsp, 0x08
00007f828abd147e  push rax
00007f828abd147f  push rcx
00007f828abd1480  push rdx
00007f828abd1481  push rdi
00007f828abd1482  push rsi
00007f828abd1483  push r8
00007f828abd1485  push r9
00007f828abd1487  push r10
00007f828abd1489  push r11
00007f828abd148b  sub rsp, 0xF0
00007f828abd1492  vmovaps [rsp], xmm0
00007f828abd1497  vmovaps [rsp+0x10], xmm2
00007f828abd149d  vmovaps [rsp+0x20], xmm3
00007f828abd14a3  vmovaps [rsp+0x30], xmm4
00007f828abd14a9  vmovaps [rsp+0x40], xmm5
00007f828abd14af  vmovaps [rsp+0x50], xmm6
00007f828abd14b5  vmovaps [rsp+0x60], xmm7
00007f828abd14bb  vmovaps [rsp+0x70], xmm8
00007f828abd14c1  vmovaps [rsp+0x80], xmm9
00007f828abd14ca  vmovaps [rsp+0x90], xmm10
00007f828abd14d3  vmovaps [rsp+0xA0], xmm11
00007f828abd14dc  vmovaps [rsp+0xB0], xmm12
00007f828abd14e5  vmovaps [rsp+0xC0], xmm13
00007f828abd14ee  vmovaps [rsp+0xD0], xmm14
00007f828abd14f7  vmovaps [rsp+0xE0], xmm15
00007f828abd1500  sub rsp, 0x30
00007f828abd1504  movaps [rsp], xmm1
00007f828abd1508  movaps [rsp+0x10], xmm15
00007f828abd150e  movaps [rsp+0x20], xmm2
00007f828abd1513  lea rdi, [rsp]
00007f828abd1517  mov esi, 0x00
00007f828abd151c  mov rax, 0x5BFE27FA6530
00007f828abd1526  call rax
00007f828abd1528  movaps xmm1, [rsp]
00007f828abd152c  add rsp, 0x30
00007f828abd1530  vmovaps xmm0, [rsp]
00007f828abd1535  vmovaps xmm2, [rsp+0x10]
00007f828abd153b  vmovaps xmm3, [rsp+0x20]
00007f828abd1541  vmovaps xmm4, [rsp+0x30]
00007f828abd1547  vmovaps xmm5, [rsp+0x40]
00007f828abd154d  vmovaps xmm6, [rsp+0x50]
00007f828abd1553  vmovaps xmm7, [rsp+0x60]
00007f828abd1559  vmovaps xmm8, [rsp+0x70]
00007f828abd155f  vmovaps xmm9, [rsp+0x80]
00007f828abd1568  vmovaps xmm10, [rsp+0x90]
00007f828abd1571  vmovaps xmm11, [rsp+0xA0]
00007f828abd157a  vmovaps xmm12, [rsp+0xB0]
00007f828abd1583  vmovaps xmm13, [rsp+0xC0]
00007f828abd158c  vmovaps xmm14, [rsp+0xD0]
00007f828abd1595  vmovaps xmm15, [rsp+0xE0]
00007f828abd159e  add rsp, 0xF0
00007f828abd15a5  pop r11
00007f828abd15a7  pop r10
00007f828abd15a9  pop r9
00007f828abd15ab  pop r8
00007f828abd15ad  pop rsi
00007f828abd15ae  pop rdi
00007f828abd15af  pop rdx
00007f828abd15b0  pop rcx
00007f828abd15b1  pop rax
00007f828abd15b2  add rsp, 0x08
00007f828abd15b6  jmp 0x00007F828ABCF8AC
00007f828abd15bb  sub rsp, 0x08
00007f828abd15bf  push rax
00007f828abd15c0  push rcx
00007f828abd15c1  push rdx
00007f828abd15c2  push rdi
00007f828abd15c3  push rsi
00007f828abd15c4  push r8
00007f828abd15c6  push r9
00007f828abd15c8  push r10
00007f828abd15ca  push r11
00007f828abd15cc  sub rsp, 0xF0
00007f828abd15d3  vmovaps [rsp], xmm0
00007f828abd15d8  vmovaps [rsp+0x10], xmm1
00007f828abd15de  vmovaps [rsp+0x20], xmm2
00007f828abd15e4  vmovaps [rsp+0x30], xmm3
00007f828abd15ea  vmovaps [rsp+0x40], xmm4
00007f828abd15f0  vmovaps [rsp+0x50], xmm5
00007f828abd15f6  vmovaps [rsp+0x60], xmm6
00007f828abd15fc  vmovaps [rsp+0x70], xmm7
00007f828abd1602  vmovaps [rsp+0x80], xmm8
00007f828abd160b  vmovaps [rsp+0x90], xmm9
00007f828abd1614  vmovaps [rsp+0xA0], xmm10
00007f828abd161d  vmovaps [rsp+0xB0], xmm11
00007f828abd1626  vmovaps [rsp+0xC0], xmm12
00007f828abd162f  vmovaps [rsp+0xD0], xmm13
00007f828abd1638  vmovaps [rsp+0xE0], xmm15
00007f828abd1641  sub rsp, 0x30
00007f828abd1645  movaps [rsp], xmm14
00007f828abd164a  movaps [rsp+0x10], xmm2
00007f828abd164f  movaps [rsp+0x20], xmm15
00007f828abd1655  lea rdi, [rsp]
00007f828abd1659  mov esi, 0x00
00007f828abd165e  mov rax, 0x5BFE27FA6530
00007f828abd1668  call rax
00007f828abd166a  movaps xmm14, [rsp]
00007f828abd166f  add rsp, 0x30
00007f828abd1673  vmovaps xmm0, [rsp]
00007f828abd1678  vmovaps xmm1, [rsp+0x10]
00007f828abd167e  vmovaps xmm2, [rsp+0x20]
00007f828abd1684  vmovaps xmm3, [rsp+0x30]
00007f828abd168a  vmovaps xmm4, [rsp+0x40]
00007f828abd1690  vmovaps xmm5, [rsp+0x50]
00007f828abd1696  vmovaps xmm6, [rsp+0x60]
00007f828abd169c  vmovaps xmm7, [rsp+0x70]
00007f828abd16a2  vmovaps xmm8, [rsp+0x80]
00007f828abd16ab  vmovaps xmm9, [rsp+0x90]
00007f828abd16b4  vmovaps xmm10, [rsp+0xA0]
00007f828abd16bd  vmovaps xmm11, [rsp+0xB0]
00007f828abd16c6  vmovaps xmm12, [rsp+0xC0]
00007f828abd16cf  vmovaps xmm13, [rsp+0xD0]
00007f828abd16d8  vmovaps xmm15, [rsp+0xE0]
00007f828abd16e1  add rsp, 0xF0
00007f828abd16e8  pop r11
00007f828abd16ea  pop r10
00007f828abd16ec  pop r9
00007f828abd16ee  pop r8
00007f828abd16f0  pop rsi
00007f828abd16f1  pop rdi
00007f828abd16f2  pop rdx
00007f828abd16f3  pop rcx
00007f828abd16f4  pop rax
00007f828abd16f5  add rsp, 0x08
00007f828abd16f9  jmp 0x00007F828ABCF8E7
00007f828abd16fe  sub rsp, 0x08
00007f828abd1702  push rax
00007f828abd1703  push rcx
00007f828abd1704  push rdx
00007f828abd1705  push rdi
00007f828abd1706  push rsi
00007f828abd1707  push r8
00007f828abd1709  push r9
00007f828abd170b  push r10
00007f828abd170d  push r11
00007f828abd170f  sub rsp, 0xF0
00007f828abd1716  vmovaps [rsp], xmm0
00007f828abd171b  vmovaps [rsp+0x10], xmm1
00007f828abd1721  vmovaps [rsp+0x20], xmm2
00007f828abd1727  vmovaps [rsp+0x30], xmm3
00007f828abd172d  vmovaps [rsp+0x40], xmm4
00007f828abd1733  vmovaps [rsp+0x50], xmm5
00007f828abd1739  vmovaps [rsp+0x60], xmm6
00007f828abd173f  vmovaps [rsp+0x70], xmm7
00007f828abd1745  vmovaps [rsp+0x80], xmm8
00007f828abd174e  vmovaps [rsp+0x90], xmm9
00007f828abd1757  vmovaps [rsp+0xA0], xmm10
00007f828abd1760  vmovaps [rsp+0xB0], xmm11
00007f828abd1769  vmovaps [rsp+0xC0], xmm12
00007f828abd1772  vmovaps [rsp+0xD0], xmm13
00007f828abd177b  vmovaps [rsp+0xE0], xmm14
00007f828abd1784  sub rsp, 0x30
00007f828abd1788  movaps [rsp], xmm15
00007f828abd178d  movaps [rsp+0x10], xmm2
00007f828abd1792  movaps [rsp+0x20], xmm1
00007f828abd1797  lea rdi, [rsp]
00007f828abd179b  mov esi, 0x00
00007f828abd17a0  mov rax, 0x5BFE27FA6530
00007f828abd17aa  call rax
00007f828abd17ac  movaps xmm15, [rsp]
00007f828abd17b1  add rsp, 0x30
00007f828abd17b5  vmovaps xmm0, [rsp]
00007f828abd17ba  vmovaps xmm1, [rsp+0x10]
00007f828abd17c0  vmovaps xmm2, [rsp+0x20]
00007f828abd17c6  vmovaps xmm3, [rsp+0x30]
00007f828abd17cc  vmovaps xmm4, [rsp+0x40]
00007f828abd17d2  vmovaps xmm5, [rsp+0x50]
00007f828abd17d8  vmovaps xmm6, [rsp+0x60]
00007f828abd17de  vmovaps xmm7, [rsp+0x70]
00007f828abd17e4  vmovaps xmm8, [rsp+0x80]
00007f828abd17ed  vmovaps xmm9, [rsp+0x90]
00007f828abd17f6  vmovaps xmm10, [rsp+0xA0]
00007f828abd17ff  vmovaps xmm11, [rsp+0xB0]
00007f828abd1808  vmovaps xmm12, [rsp+0xC0]
00007f828abd1811  vmovaps xmm13, [rsp+0xD0]
00007f828abd181a  vmovaps xmm14, [rsp+0xE0]
00007f828abd1823  add rsp, 0xF0
00007f828abd182a  pop r11
00007f828abd182c  pop r10
00007f828abd182e  pop r9
00007f828abd1830  pop r8
00007f828abd1832  pop rsi
00007f828abd1833  pop rdi
00007f828abd1834  pop rdx
00007f828abd1835  pop rcx
00007f828abd1836  pop rax
00007f828abd1837  add rsp, 0x08
00007f828abd183b  jmp 0x00007F828ABCF923
00007f828abd1840  call 0x00007F828A9FF430
00007f828abd1845  jmp 0x00007F828ABCF930
00007f828abd184a  sub rsp, 0x08
00007f828abd184e  push rax
00007f828abd184f  push rcx
00007f828abd1850  push rdx
00007f828abd1851  push rdi
00007f828abd1852  push rsi
00007f828abd1853  push r8
00007f828abd1855  push r9
00007f828abd1857  push r10
00007f828abd1859  push r11
00007f828abd185b  sub rsp, 0xF0
00007f828abd1862  vmovaps [rsp], xmm0
00007f828abd1867  vmovaps [rsp+0x10], xmm1
00007f828abd186d  vmovaps [rsp+0x20], xmm3
00007f828abd1873  vmovaps [rsp+0x30], xmm4
00007f828abd1879  vmovaps [rsp+0x40], xmm5
00007f828abd187f  vmovaps [rsp+0x50], xmm6
00007f828abd1885  vmovaps [rsp+0x60], xmm7
00007f828abd188b  vmovaps [rsp+0x70], xmm8
00007f828abd1891  vmovaps [rsp+0x80], xmm9
00007f828abd189a  vmovaps [rsp+0x90], xmm10
00007f828abd18a3  vmovaps [rsp+0xA0], xmm11
00007f828abd18ac  vmovaps [rsp+0xB0], xmm12
00007f828abd18b5  vmovaps [rsp+0xC0], xmm13
00007f828abd18be  vmovaps [rsp+0xD0], xmm14
00007f828abd18c7  vmovaps [rsp+0xE0], xmm15
00007f828abd18d0  sub rsp, 0x30
00007f828abd18d4  movaps [rsp], xmm2
00007f828abd18d8  movaps [rsp+0x10], xmm1
00007f828abd18dd  movaps [rsp+0x20], xmm14
00007f828abd18e3  lea rdi, [rsp]
00007f828abd18e7  mov esi, 0x00
00007f828abd18ec  mov rax, 0x5BFE27FA6530
00007f828abd18f6  call rax
00007f828abd18f8  movaps xmm2, [rsp]
00007f828abd18fc  add rsp, 0x30
00007f828abd1900  vmovaps xmm0, [rsp]
00007f828abd1905  vmovaps xmm1, [rsp+0x10]
00007f828abd190b  vmovaps xmm3, [rsp+0x20]
00007f828abd1911  vmovaps xmm4, [rsp+0x30]
00007f828abd1917  vmovaps xmm5, [rsp+0x40]
00007f828abd191d  vmovaps xmm6, [rsp+0x50]
00007f828abd1923  vmovaps xmm7, [rsp+0x60]
00007f828abd1929  vmovaps xmm8, [rsp+0x70]
00007f828abd192f  vmovaps xmm9, [rsp+0x80]
00007f828abd1938  vmovaps xmm10, [rsp+0x90]
00007f828abd1941  vmovaps xmm11, [rsp+0xA0]
00007f828abd194a  vmovaps xmm12, [rsp+0xB0]
00007f828abd1953  vmovaps xmm13, [rsp+0xC0]
00007f828abd195c  vmovaps xmm14, [rsp+0xD0]
00007f828abd1965  vmovaps xmm15, [rsp+0xE0]
00007f828abd196e  add rsp, 0xF0
00007f828abd1975  pop r11
00007f828abd1977  pop r10
00007f828abd1979  pop r9
00007f828abd197b  pop r8
00007f828abd197d  pop rsi
00007f828abd197e  pop rdi
00007f828abd197f  pop rdx
00007f828abd1980  pop rcx
00007f828abd1981  pop rax
00007f828abd1982  add rsp, 0x08
00007f828abd1986  jmp 0x00007F828ABCF96D
00007f828abd198b  sub rsp, 0x08
00007f828abd198f  push rax
00007f828abd1990  push rcx
00007f828abd1991  push rdx
00007f828abd1992  push rdi
00007f828abd1993  push rsi
00007f828abd1994  push r8
00007f828abd1996  push r9
00007f828abd1998  push r10
00007f828abd199a  push r11
00007f828abd199c  sub rsp, 0xF0
00007f828abd19a3  vmovaps [rsp], xmm0
00007f828abd19a8  vmovaps [rsp+0x10], xmm1
00007f828abd19ae  vmovaps [rsp+0x20], xmm2
00007f828abd19b4  vmovaps [rsp+0x30], xmm3
00007f828abd19ba  vmovaps [rsp+0x40], xmm4
00007f828abd19c0  vmovaps [rsp+0x50], xmm5
00007f828abd19c6  vmovaps [rsp+0x60], xmm6
00007f828abd19cc  vmovaps [rsp+0x70], xmm7
00007f828abd19d2  vmovaps [rsp+0x80], xmm8
00007f828abd19db  vmovaps [rsp+0x90], xmm9
00007f828abd19e4  vmovaps [rsp+0xA0], xmm10
00007f828abd19ed  vmovaps [rsp+0xB0], xmm11
00007f828abd19f6  vmovaps [rsp+0xC0], xmm12
00007f828abd19ff  vmovaps [rsp+0xD0], xmm13
00007f828abd1a08  vmovaps [rsp+0xE0], xmm14
00007f828abd1a11  sub rsp, 0x30
00007f828abd1a15  movaps [rsp], xmm15
00007f828abd1a1a  movaps [rsp+0x10], xmm14
00007f828abd1a20  movaps [rsp+0x20], xmm1
00007f828abd1a25  lea rdi, [rsp]
00007f828abd1a29  mov esi, 0x00
00007f828abd1a2e  mov rax, 0x5BFE27FA6530
00007f828abd1a38  call rax
00007f828abd1a3a  movaps xmm15, [rsp]
00007f828abd1a3f  add rsp, 0x30
00007f828abd1a43  vmovaps xmm0, [rsp]
00007f828abd1a48  vmovaps xmm1, [rsp+0x10]
00007f828abd1a4e  vmovaps xmm2, [rsp+0x20]
00007f828abd1a54  vmovaps xmm3, [rsp+0x30]
00007f828abd1a5a  vmovaps xmm4, [rsp+0x40]
00007f828abd1a60  vmovaps xmm5, [rsp+0x50]
00007f828abd1a66  vmovaps xmm6, [rsp+0x60]
00007f828abd1a6c  vmovaps xmm7, [rsp+0x70]
00007f828abd1a72  vmovaps xmm8, [rsp+0x80]
00007f828abd1a7b  vmovaps xmm9, [rsp+0x90]
00007f828abd1a84  vmovaps xmm10, [rsp+0xA0]
00007f828abd1a8d  vmovaps xmm11, [rsp+0xB0]
00007f828abd1a96  vmovaps xmm12, [rsp+0xC0]
00007f828abd1a9f  vmovaps xmm13, [rsp+0xD0]
00007f828abd1aa8  vmovaps xmm14, [rsp+0xE0]
00007f828abd1ab1  add rsp, 0xF0
00007f828abd1ab8  pop r11
00007f828abd1aba  pop r10
00007f828abd1abc  pop r9
00007f828abd1abe  pop r8
00007f828abd1ac0  pop rsi
00007f828abd1ac1  pop rdi
00007f828abd1ac2  pop rdx
00007f828abd1ac3  pop rcx
00007f828abd1ac4  pop rax
00007f828abd1ac5  add rsp, 0x08
00007f828abd1ac9  jmp 0x00007F828ABCF9E7
00007f828abd1ace  call 0x00007F828A9FF430
00007f828abd1ad3  jmp 0x00007F828ABCF9F4
00007f828abd1ad8  sub rsp, 0x08
00007f828abd1adc  push rax
00007f828abd1add  push rcx
00007f828abd1ade  push rdx
00007f828abd1adf  push rdi
00007f828abd1ae0  push rsi
00007f828abd1ae1  push r8
00007f828abd1ae3  push r9
00007f828abd1ae5  push r10
00007f828abd1ae7  push r11
00007f828abd1ae9  sub rsp, 0xF0
00007f828abd1af0  vmovaps [rsp], xmm0
00007f828abd1af5  vmovaps [rsp+0x10], xmm1
00007f828abd1afb  vmovaps [rsp+0x20], xmm2
00007f828abd1b01  vmovaps [rsp+0x30], xmm3
00007f828abd1b07  vmovaps [rsp+0x40], xmm4
00007f828abd1b0d  vmovaps [rsp+0x50], xmm5
00007f828abd1b13  vmovaps [rsp+0x60], xmm6
00007f828abd1b19  vmovaps [rsp+0x70], xmm7
00007f828abd1b1f  vmovaps [rsp+0x80], xmm8
00007f828abd1b28  vmovaps [rsp+0x90], xmm9
00007f828abd1b31  vmovaps [rsp+0xA0], xmm10
00007f828abd1b3a  vmovaps [rsp+0xB0], xmm11
00007f828abd1b43  vmovaps [rsp+0xC0], xmm12
00007f828abd1b4c  vmovaps [rsp+0xD0], xmm13
00007f828abd1b55  vmovaps [rsp+0xE0], xmm15
00007f828abd1b5e  sub rsp, 0x30
00007f828abd1b62  movaps [rsp], xmm14
00007f828abd1b67  movaps [rsp+0x10], xmm13
00007f828abd1b6d  movaps [rsp+0x20], xmm1
00007f828abd1b72  lea rdi, [rsp]
00007f828abd1b76  mov esi, 0x00
00007f828abd1b7b  mov rax, 0x5BFE27FA6530
00007f828abd1b85  call rax
00007f828abd1b87  movaps xmm14, [rsp]
00007f828abd1b8c  add rsp, 0x30
00007f828abd1b90  vmovaps xmm0, [rsp]
00007f828abd1b95  vmovaps xmm1, [rsp+0x10]
00007f828abd1b9b  vmovaps xmm2, [rsp+0x20]
00007f828abd1ba1  vmovaps xmm3, [rsp+0x30]
00007f828abd1ba7  vmovaps xmm4, [rsp+0x40]
00007f828abd1bad  vmovaps xmm5, [rsp+0x50]
00007f828abd1bb3  vmovaps xmm6, [rsp+0x60]
00007f828abd1bb9  vmovaps xmm7, [rsp+0x70]
00007f828abd1bbf  vmovaps xmm8, [rsp+0x80]
00007f828abd1bc8  vmovaps xmm9, [rsp+0x90]
00007f828abd1bd1  vmovaps xmm10, [rsp+0xA0]
00007f828abd1bda  vmovaps xmm11, [rsp+0xB0]
00007f828abd1be3  vmovaps xmm12, [rsp+0xC0]
00007f828abd1bec  vmovaps xmm13, [rsp+0xD0]
00007f828abd1bf5  vmovaps xmm15, [rsp+0xE0]
00007f828abd1bfe  add rsp, 0xF0
00007f828abd1c05  pop r11
00007f828abd1c07  pop r10
00007f828abd1c09  pop r9
00007f828abd1c0b  pop r8
00007f828abd1c0d  pop rsi
00007f828abd1c0e  pop rdi
00007f828abd1c0f  pop rdx
00007f828abd1c10  pop rcx
00007f828abd1c11  pop rax
00007f828abd1c12  add rsp, 0x08
00007f828abd1c16  jmp 0x00007F828ABCFAAF
00007f828abd1c1b  sub rsp, 0x08
00007f828abd1c1f  push rax
00007f828abd1c20  push rcx
00007f828abd1c21  push rdx
00007f828abd1c22  push rdi
00007f828abd1c23  push rsi
00007f828abd1c24  push r8
00007f828abd1c26  push r9
00007f828abd1c28  push r10
00007f828abd1c2a  push r11
00007f828abd1c2c  sub rsp, 0xF0
00007f828abd1c33  vmovaps [rsp], xmm0
00007f828abd1c38  vmovaps [rsp+0x10], xmm1
00007f828abd1c3e  vmovaps [rsp+0x20], xmm2
00007f828abd1c44  vmovaps [rsp+0x30], xmm3
00007f828abd1c4a  vmovaps [rsp+0x40], xmm4
00007f828abd1c50  vmovaps [rsp+0x50], xmm5
00007f828abd1c56  vmovaps [rsp+0x60], xmm6
00007f828abd1c5c  vmovaps [rsp+0x70], xmm7
00007f828abd1c62  vmovaps [rsp+0x80], xmm8
00007f828abd1c6b  vmovaps [rsp+0x90], xmm9
00007f828abd1c74  vmovaps [rsp+0xA0], xmm10
00007f828abd1c7d  vmovaps [rsp+0xB0], xmm11
00007f828abd1c86  vmovaps [rsp+0xC0], xmm12
00007f828abd1c8f  vmovaps [rsp+0xD0], xmm13
00007f828abd1c98  vmovaps [rsp+0xE0], xmm14
00007f828abd1ca1  sub rsp, 0x30
00007f828abd1ca5  movaps [rsp], xmm15
00007f828abd1caa  movaps [rsp+0x10], xmm13
00007f828abd1cb0  movaps [rsp+0x20], xmm1
00007f828abd1cb5  lea rdi, [rsp]
00007f828abd1cb9  mov esi, 0x00
00007f828abd1cbe  mov rax, 0x5BFE27FA6530
00007f828abd1cc8  call rax
00007f828abd1cca  movaps xmm15, [rsp]
00007f828abd1ccf  add rsp, 0x30
00007f828abd1cd3  vmovaps xmm0, [rsp]
00007f828abd1cd8  vmovaps xmm1, [rsp+0x10]
00007f828abd1cde  vmovaps xmm2, [rsp+0x20]
00007f828abd1ce4  vmovaps xmm3, [rsp+0x30]
00007f828abd1cea  vmovaps xmm4, [rsp+0x40]
00007f828abd1cf0  vmovaps xmm5, [rsp+0x50]
00007f828abd1cf6  vmovaps xmm6, [rsp+0x60]
00007f828abd1cfc  vmovaps xmm7, [rsp+0x70]
00007f828abd1d02  vmovaps xmm8, [rsp+0x80]
00007f828abd1d0b  vmovaps xmm9, [rsp+0x90]
00007f828abd1d14  vmovaps xmm10, [rsp+0xA0]
00007f828abd1d1d  vmovaps xmm11, [rsp+0xB0]
00007f828abd1d26  vmovaps xmm12, [rsp+0xC0]
00007f828abd1d2f  vmovaps xmm13, [rsp+0xD0]
00007f828abd1d38  vmovaps xmm14, [rsp+0xE0]
00007f828abd1d41  add rsp, 0xF0
00007f828abd1d48  pop r11
00007f828abd1d4a  pop r10
00007f828abd1d4c  pop r9
00007f828abd1d4e  pop r8
00007f828abd1d50  pop rsi
00007f828abd1d51  pop rdi
00007f828abd1d52  pop rdx
00007f828abd1d53  pop rcx
00007f828abd1d54  pop rax
00007f828abd1d55  add rsp, 0x08
00007f828abd1d59  jmp 0x00007F828ABCFAEB
00007f828abd1d5e  call 0x00007F828A9FF430
00007f828abd1d63  jmp 0x00007F828ABCFAF8
00007f828abd1d68  sub rsp, 0x08
00007f828abd1d6c  push rax
00007f828abd1d6d  push rcx
00007f828abd1d6e  push rdx
00007f828abd1d6f  push rdi
00007f828abd1d70  push rsi
00007f828abd1d71  push r8
00007f828abd1d73  push r9
00007f828abd1d75  push r10
00007f828abd1d77  push r11
00007f828abd1d79  sub rsp, 0xF0
00007f828abd1d80  vmovaps [rsp], xmm0
00007f828abd1d85  vmovaps [rsp+0x10], xmm1
00007f828abd1d8b  vmovaps [rsp+0x20], xmm2
00007f828abd1d91  vmovaps [rsp+0x30], xmm3
00007f828abd1d97  vmovaps [rsp+0x40], xmm4
00007f828abd1d9d  vmovaps [rsp+0x50], xmm5
00007f828abd1da3  vmovaps [rsp+0x60], xmm6
00007f828abd1da9  vmovaps [rsp+0x70], xmm7
00007f828abd1daf  vmovaps [rsp+0x80], xmm8
00007f828abd1db8  vmovaps [rsp+0x90], xmm9
00007f828abd1dc1  vmovaps [rsp+0xA0], xmm10
00007f828abd1dca  vmovaps [rsp+0xB0], xmm11
00007f828abd1dd3  vmovaps [rsp+0xC0], xmm12
00007f828abd1ddc  vmovaps [rsp+0xD0], xmm13
00007f828abd1de5  vmovaps [rsp+0xE0], xmm15
00007f828abd1dee  sub rsp, 0x30
00007f828abd1df2  movaps [rsp], xmm14
00007f828abd1df7  movaps [rsp+0x10], xmm13
00007f828abd1dfd  movaps [rsp+0x20], xmm2
00007f828abd1e02  lea rdi, [rsp]
00007f828abd1e06  mov esi, 0x00
00007f828abd1e0b  mov rax, 0x5BFE27FA6530
00007f828abd1e15  call rax
00007f828abd1e17  movaps xmm14, [rsp]
00007f828abd1e1c  add rsp, 0x30
00007f828abd1e20  vmovaps xmm0, [rsp]
00007f828abd1e25  vmovaps xmm1, [rsp+0x10]
00007f828abd1e2b  vmovaps xmm2, [rsp+0x20]
00007f828abd1e31  vmovaps xmm3, [rsp+0x30]
00007f828abd1e37  vmovaps xmm4, [rsp+0x40]
00007f828abd1e3d  vmovaps xmm5, [rsp+0x50]
00007f828abd1e43  vmovaps xmm6, [rsp+0x60]
00007f828abd1e49  vmovaps xmm7, [rsp+0x70]
00007f828abd1e4f  vmovaps xmm8, [rsp+0x80]
00007f828abd1e58  vmovaps xmm9, [rsp+0x90]
00007f828abd1e61  vmovaps xmm10, [rsp+0xA0]
00007f828abd1e6a  vmovaps xmm11, [rsp+0xB0]
00007f828abd1e73  vmovaps xmm12, [rsp+0xC0]
00007f828abd1e7c  vmovaps xmm13, [rsp+0xD0]
00007f828abd1e85  vmovaps xmm15, [rsp+0xE0]
00007f828abd1e8e  add rsp, 0xF0
00007f828abd1e95  pop r11
00007f828abd1e97  pop r10
00007f828abd1e99  pop r9
00007f828abd1e9b  pop r8
00007f828abd1e9d  pop rsi
00007f828abd1e9e  pop rdi
00007f828abd1e9f  pop rdx
00007f828abd1ea0  pop rcx
00007f828abd1ea1  pop rax
00007f828abd1ea2  add rsp, 0x08
00007f828abd1ea6  jmp 0x00007F828ABCFB24
00007f828abd1eab  sub rsp, 0x08
00007f828abd1eaf  push rax
00007f828abd1eb0  push rcx
00007f828abd1eb1  push rdx
00007f828abd1eb2  push rdi
00007f828abd1eb3  push rsi
00007f828abd1eb4  push r8
00007f828abd1eb6  push r9
00007f828abd1eb8  push r10
00007f828abd1eba  push r11
00007f828abd1ebc  sub rsp, 0xF0
00007f828abd1ec3  vmovaps [rsp], xmm0
00007f828abd1ec8  vmovaps [rsp+0x10], xmm2
00007f828abd1ece  vmovaps [rsp+0x20], xmm3
00007f828abd1ed4  vmovaps [rsp+0x30], xmm4
00007f828abd1eda  vmovaps [rsp+0x40], xmm5
00007f828abd1ee0  vmovaps [rsp+0x50], xmm6
00007f828abd1ee6  vmovaps [rsp+0x60], xmm7
00007f828abd1eec  vmovaps [rsp+0x70], xmm8
00007f828abd1ef2  vmovaps [rsp+0x80], xmm9
00007f828abd1efb  vmovaps [rsp+0x90], xmm10
00007f828abd1f04  vmovaps [rsp+0xA0], xmm11
00007f828abd1f0d  vmovaps [rsp+0xB0], xmm12
00007f828abd1f16  vmovaps [rsp+0xC0], xmm13
00007f828abd1f1f  vmovaps [rsp+0xD0], xmm14
00007f828abd1f28  vmovaps [rsp+0xE0], xmm15
00007f828abd1f31  sub rsp, 0x30
00007f828abd1f35  movaps [rsp], xmm1
00007f828abd1f39  movaps [rsp+0x10], xmm13
00007f828abd1f3f  movaps [rsp+0x20], xmm2
00007f828abd1f44  lea rdi, [rsp]
00007f828abd1f48  mov esi, 0x00
00007f828abd1f4d  mov rax, 0x5BFE27FA6530
00007f828abd1f57  call rax
00007f828abd1f59  movaps xmm1, [rsp]
00007f828abd1f5d  add rsp, 0x30
00007f828abd1f61  vmovaps xmm0, [rsp]
00007f828abd1f66  vmovaps xmm2, [rsp+0x10]
00007f828abd1f6c  vmovaps xmm3, [rsp+0x20]
00007f828abd1f72  vmovaps xmm4, [rsp+0x30]
00007f828abd1f78  vmovaps xmm5, [rsp+0x40]
00007f828abd1f7e  vmovaps xmm6, [rsp+0x50]
00007f828abd1f84  vmovaps xmm7, [rsp+0x60]
00007f828abd1f8a  vmovaps xmm8, [rsp+0x70]
00007f828abd1f90  vmovaps xmm9, [rsp+0x80]
00007f828abd1f99  vmovaps xmm10, [rsp+0x90]
00007f828abd1fa2  vmovaps xmm11, [rsp+0xA0]
00007f828abd1fab  vmovaps xmm12, [rsp+0xB0]
00007f828abd1fb4  vmovaps xmm13, [rsp+0xC0]
00007f828abd1fbd  vmovaps xmm14, [rsp+0xD0]
00007f828abd1fc6  vmovaps xmm15, [rsp+0xE0]
00007f828abd1fcf  add rsp, 0xF0
00007f828abd1fd6  pop r11
00007f828abd1fd8  pop r10
00007f828abd1fda  pop r9
00007f828abd1fdc  pop r8
00007f828abd1fde  pop rsi
00007f828abd1fdf  pop rdi
00007f828abd1fe0  pop rdx
00007f828abd1fe1  pop rcx
00007f828abd1fe2  pop rax
00007f828abd1fe3  add rsp, 0x08
00007f828abd1fe7  jmp 0x00007F828ABCFB52
00007f828abd1fec  sub rsp, 0x08
00007f828abd1ff0  push rax
00007f828abd1ff1  push rcx
00007f828abd1ff2  push rdx
00007f828abd1ff3  push rdi
00007f828abd1ff4  push rsi
00007f828abd1ff5  push r8
00007f828abd1ff7  push r9
00007f828abd1ff9  push r10
00007f828abd1ffb  push r11
00007f828abd1ffd  sub rsp, 0xF0
00007f828abd2004  vmovaps [rsp], xmm0
00007f828abd2009  vmovaps [rsp+0x10], xmm1
00007f828abd200f  vmovaps [rsp+0x20], xmm3
00007f828abd2015  vmovaps [rsp+0x30], xmm4
00007f828abd201b  vmovaps [rsp+0x40], xmm5
00007f828abd2021  vmovaps [rsp+0x50], xmm6
00007f828abd2027  vmovaps [rsp+0x60], xmm7
00007f828abd202d  vmovaps [rsp+0x70], xmm8
00007f828abd2033  vmovaps [rsp+0x80], xmm9
00007f828abd203c  vmovaps [rsp+0x90], xmm10
00007f828abd2045  vmovaps [rsp+0xA0], xmm11
00007f828abd204e  vmovaps [rsp+0xB0], xmm12
00007f828abd2057  vmovaps [rsp+0xC0], xmm13
00007f828abd2060  vmovaps [rsp+0xD0], xmm14
00007f828abd2069  vmovaps [rsp+0xE0], xmm15
00007f828abd2072  sub rsp, 0x30
00007f828abd2076  movaps [rsp], xmm2
00007f828abd207a  movaps [rsp+0x10], xmm1
00007f828abd207f  movaps [rsp+0x20], xmm13
00007f828abd2085  lea rdi, [rsp]
00007f828abd2089  mov esi, 0x00
00007f828abd208e  mov rax, 0x5BFE27FA6530
00007f828abd2098  call rax
00007f828abd209a  movaps xmm2, [rsp]
00007f828abd209e  add rsp, 0x30
00007f828abd20a2  vmovaps xmm0, [rsp]
00007f828abd20a7  vmovaps xmm1, [rsp+0x10]
00007f828abd20ad  vmovaps xmm3, [rsp+0x20]
00007f828abd20b3  vmovaps xmm4, [rsp+0x30]
00007f828abd20b9  vmovaps xmm5, [rsp+0x40]
00007f828abd20bf  vmovaps xmm6, [rsp+0x50]
00007f828abd20c5  vmovaps xmm7, [rsp+0x60]
00007f828abd20cb  vmovaps xmm8, [rsp+0x70]
00007f828abd20d1  vmovaps xmm9, [rsp+0x80]
00007f828abd20da  vmovaps xmm10, [rsp+0x90]
00007f828abd20e3  vmovaps xmm11, [rsp+0xA0]
00007f828abd20ec  vmovaps xmm12, [rsp+0xB0]
00007f828abd20f5  vmovaps xmm13, [rsp+0xC0]
00007f828abd20fe  vmovaps xmm14, [rsp+0xD0]
00007f828abd2107  vmovaps xmm15, [rsp+0xE0]
00007f828abd2110  add rsp, 0xF0
00007f828abd2117  pop r11
00007f828abd2119  pop r10
00007f828abd211b  pop r9
00007f828abd211d  pop r8
00007f828abd211f  pop rsi
00007f828abd2120  pop rdi
00007f828abd2121  pop rdx
00007f828abd2122  pop rcx
00007f828abd2123  pop rax
00007f828abd2124  add rsp, 0x08
00007f828abd2128  jmp 0x00007F828ABCFBAB
00007f828abd212d  call 0x00007F828A9FF430
00007f828abd2132  jmp 0x00007F828ABCFBB8
00007f828abd2137  sub rsp, 0x08
00007f828abd213b  push rax
00007f828abd213c  push rcx
00007f828abd213d  push rdx
00007f828abd213e  push rdi
00007f828abd213f  push rsi
00007f828abd2140  push r8
00007f828abd2142  push r9
00007f828abd2144  push r10
00007f828abd2146  push r11
00007f828abd2148  sub rsp, 0xF0
00007f828abd214f  vmovaps [rsp], xmm0
00007f828abd2154  vmovaps [rsp+0x10], xmm1
00007f828abd215a  vmovaps [rsp+0x20], xmm2
00007f828abd2160  vmovaps [rsp+0x30], xmm3
00007f828abd2166  vmovaps [rsp+0x40], xmm4
00007f828abd216c  vmovaps [rsp+0x50], xmm5
00007f828abd2172  vmovaps [rsp+0x60], xmm6
00007f828abd2178  vmovaps [rsp+0x70], xmm7
00007f828abd217e  vmovaps [rsp+0x80], xmm8
00007f828abd2187  vmovaps [rsp+0x90], xmm9
00007f828abd2190  vmovaps [rsp+0xA0], xmm10
00007f828abd2199  vmovaps [rsp+0xB0], xmm11
00007f828abd21a2  vmovaps [rsp+0xC0], xmm12
00007f828abd21ab  vmovaps [rsp+0xD0], xmm13
00007f828abd21b4  vmovaps [rsp+0xE0], xmm14
00007f828abd21bd  sub rsp, 0x30
00007f828abd21c1  movaps [rsp], xmm15
00007f828abd21c6  movaps [rsp+0x10], xmm13
00007f828abd21cc  movaps [rsp+0x20], xmm1
00007f828abd21d1  lea rdi, [rsp]
00007f828abd21d5  mov esi, 0x00
00007f828abd21da  mov rax, 0x5BFE27FA6530
00007f828abd21e4  call rax
00007f828abd21e6  movaps xmm15, [rsp]
00007f828abd21eb  add rsp, 0x30
00007f828abd21ef  vmovaps xmm0, [rsp]
00007f828abd21f4  vmovaps xmm1, [rsp+0x10]
00007f828abd21fa  vmovaps xmm2, [rsp+0x20]
00007f828abd2200  vmovaps xmm3, [rsp+0x30]
00007f828abd2206  vmovaps xmm4, [rsp+0x40]
00007f828abd220c  vmovaps xmm5, [rsp+0x50]
00007f828abd2212  vmovaps xmm6, [rsp+0x60]
00007f828abd2218  vmovaps xmm7, [rsp+0x70]
00007f828abd221e  vmovaps xmm8, [rsp+0x80]
00007f828abd2227  vmovaps xmm9, [rsp+0x90]
00007f828abd2230  vmovaps xmm10, [rsp+0xA0]
00007f828abd2239  vmovaps xmm11, [rsp+0xB0]
00007f828abd2242  vmovaps xmm12, [rsp+0xC0]
00007f828abd224b  vmovaps xmm13, [rsp+0xD0]
00007f828abd2254  vmovaps xmm14, [rsp+0xE0]
00007f828abd225d  add rsp, 0xF0
00007f828abd2264  pop r11
00007f828abd2266  pop r10
00007f828abd2268  pop r9
00007f828abd226a  pop r8
00007f828abd226c  pop rsi
00007f828abd226d  pop rdi
00007f828abd226e  pop rdx
00007f828abd226f  pop rcx
00007f828abd2270  pop rax
00007f828abd2271  add rsp, 0x08
00007f828abd2275  jmp 0x00007F828ABCFBF7
00007f828abd227a  sub rsp, 0x08
00007f828abd227e  push rax
00007f828abd227f  push rcx
00007f828abd2280  push rdx
00007f828abd2281  push rdi
00007f828abd2282  push rsi
00007f828abd2283  push r8
00007f828abd2285  push r9
00007f828abd2287  push r10
00007f828abd2289  push r11
00007f828abd228b  sub rsp, 0xF0
00007f828abd2292  vmovaps [rsp], xmm0
00007f828abd2297  vmovaps [rsp+0x10], xmm1
00007f828abd229d  vmovaps [rsp+0x20], xmm2
00007f828abd22a3  vmovaps [rsp+0x30], xmm3
00007f828abd22a9  vmovaps [rsp+0x40], xmm4
00007f828abd22af  vmovaps [rsp+0x50], xmm5
00007f828abd22b5  vmovaps [rsp+0x60], xmm6
00007f828abd22bb  vmovaps [rsp+0x70], xmm7
00007f828abd22c1  vmovaps [rsp+0x80], xmm8
00007f828abd22ca  vmovaps [rsp+0x90], xmm9
00007f828abd22d3  vmovaps [rsp+0xA0], xmm10
00007f828abd22dc  vmovaps [rsp+0xB0], xmm11
00007f828abd22e5  vmovaps [rsp+0xC0], xmm12
00007f828abd22ee  vmovaps [rsp+0xD0], xmm13
00007f828abd22f7  vmovaps [rsp+0xE0], xmm15
00007f828abd2300  sub rsp, 0x30
00007f828abd2304  movaps [rsp], xmm14
00007f828abd2309  movaps [rsp+0x10], xmm11
00007f828abd230f  movaps [rsp+0x20], xmm1
00007f828abd2314  lea rdi, [rsp]
00007f828abd2318  mov esi, 0x00
00007f828abd231d  mov rax, 0x5BFE27FA6530
00007f828abd2327  call rax
00007f828abd2329  movaps xmm14, [rsp]
00007f828abd232e  add rsp, 0x30
00007f828abd2332  vmovaps xmm0, [rsp]
00007f828abd2337  vmovaps xmm1, [rsp+0x10]
00007f828abd233d  vmovaps xmm2, [rsp+0x20]
00007f828abd2343  vmovaps xmm3, [rsp+0x30]
00007f828abd2349  vmovaps xmm4, [rsp+0x40]
00007f828abd234f  vmovaps xmm5, [rsp+0x50]
00007f828abd2355  vmovaps xmm6, [rsp+0x60]
00007f828abd235b  vmovaps xmm7, [rsp+0x70]
00007f828abd2361  vmovaps xmm8, [rsp+0x80]
00007f828abd236a  vmovaps xmm9, [rsp+0x90]
00007f828abd2373  vmovaps xmm10, [rsp+0xA0]
00007f828abd237c  vmovaps xmm11, [rsp+0xB0]
00007f828abd2385  vmovaps xmm12, [rsp+0xC0]
00007f828abd238e  vmovaps xmm13, [rsp+0xD0]
00007f828abd2397  vmovaps xmm15, [rsp+0xE0]
00007f828abd23a0  add rsp, 0xF0
00007f828abd23a7  pop r11
00007f828abd23a9  pop r10
00007f828abd23ab  pop r9
00007f828abd23ad  pop r8
00007f828abd23af  pop rsi
00007f828abd23b0  pop rdi
00007f828abd23b1  pop rdx
00007f828abd23b2  pop rcx
00007f828abd23b3  pop rax
00007f828abd23b4  add rsp, 0x08
00007f828abd23b8  jmp 0x00007F828ABCFC21
00007f828abd23bd  sub rsp, 0x08
00007f828abd23c1  push rax
00007f828abd23c2  push rcx
00007f828abd23c3  push rdx
00007f828abd23c4  push rdi
00007f828abd23c5  push rsi
00007f828abd23c6  push r8
00007f828abd23c8  push r9
00007f828abd23ca  push r10
00007f828abd23cc  push r11
00007f828abd23ce  sub rsp, 0xF0
00007f828abd23d5  vmovaps [rsp], xmm0
00007f828abd23da  vmovaps [rsp+0x10], xmm1
00007f828abd23e0  vmovaps [rsp+0x20], xmm2
00007f828abd23e6  vmovaps [rsp+0x30], xmm3
00007f828abd23ec  vmovaps [rsp+0x40], xmm4
00007f828abd23f2  vmovaps [rsp+0x50], xmm5
00007f828abd23f8  vmovaps [rsp+0x60], xmm6
00007f828abd23fe  vmovaps [rsp+0x70], xmm7
00007f828abd2404  vmovaps [rsp+0x80], xmm8
00007f828abd240d  vmovaps [rsp+0x90], xmm9
00007f828abd2416  vmovaps [rsp+0xA0], xmm10
00007f828abd241f  vmovaps [rsp+0xB0], xmm11
00007f828abd2428  vmovaps [rsp+0xC0], xmm12
00007f828abd2431  vmovaps [rsp+0xD0], xmm14
00007f828abd243a  vmovaps [rsp+0xE0], xmm15
00007f828abd2443  sub rsp, 0x30
00007f828abd2447  movaps [rsp], xmm13
00007f828abd244c  movaps [rsp+0x10], xmm11
00007f828abd2452  movaps [rsp+0x20], xmm1
00007f828abd2457  lea rdi, [rsp]
00007f828abd245b  mov esi, 0x00
00007f828abd2460  mov rax, 0x5BFE27FA6530
00007f828abd246a  call rax
00007f828abd246c  movaps xmm13, [rsp]
00007f828abd2471  add rsp, 0x30
00007f828abd2475  vmovaps xmm0, [rsp]
00007f828abd247a  vmovaps xmm1, [rsp+0x10]
00007f828abd2480  vmovaps xmm2, [rsp+0x20]
00007f828abd2486  vmovaps xmm3, [rsp+0x30]
00007f828abd248c  vmovaps xmm4, [rsp+0x40]
00007f828abd2492  vmovaps xmm5, [rsp+0x50]
00007f828abd2498  vmovaps xmm6, [rsp+0x60]
00007f828abd249e  vmovaps xmm7, [rsp+0x70]
00007f828abd24a4  vmovaps xmm8, [rsp+0x80]
00007f828abd24ad  vmovaps xmm9, [rsp+0x90]
00007f828abd24b6  vmovaps xmm10, [rsp+0xA0]
00007f828abd24bf  vmovaps xmm11, [rsp+0xB0]
00007f828abd24c8  vmovaps xmm12, [rsp+0xC0]
00007f828abd24d1  vmovaps xmm14, [rsp+0xD0]
00007f828abd24da  vmovaps xmm15, [rsp+0xE0]
00007f828abd24e3  add rsp, 0xF0
00007f828abd24ea  pop r11
00007f828abd24ec  pop r10
00007f828abd24ee  pop r9
00007f828abd24f0  pop r8
00007f828abd24f2  pop rsi
00007f828abd24f3  pop rdi
00007f828abd24f4  pop rdx
00007f828abd24f5  pop rcx
00007f828abd24f6  pop rax
00007f828abd24f7  add rsp, 0x08
00007f828abd24fb  jmp 0x00007F828ABCFC76
00007f828abd2500  call 0x00007F828A9FF430
00007f828abd2505  jmp 0x00007F828ABCFC83
00007f828abd250a  sub rsp, 0x08
00007f828abd250e  push rax
00007f828abd250f  push rcx
00007f828abd2510  push rdx
00007f828abd2511  push rdi
00007f828abd2512  push rsi
00007f828abd2513  push r8
00007f828abd2515  push r9
00007f828abd2517  push r10
00007f828abd2519  push r11
00007f828abd251b  sub rsp, 0xF0
00007f828abd2522  vmovaps [rsp], xmm0
00007f828abd2527  vmovaps [rsp+0x10], xmm1
00007f828abd252d  vmovaps [rsp+0x20], xmm2
00007f828abd2533  vmovaps [rsp+0x30], xmm3
00007f828abd2539  vmovaps [rsp+0x40], xmm4
00007f828abd253f  vmovaps [rsp+0x50], xmm5
00007f828abd2545  vmovaps [rsp+0x60], xmm6
00007f828abd254b  vmovaps [rsp+0x70], xmm7
00007f828abd2551  vmovaps [rsp+0x80], xmm8
00007f828abd255a  vmovaps [rsp+0x90], xmm9
00007f828abd2563  vmovaps [rsp+0xA0], xmm10
00007f828abd256c  vmovaps [rsp+0xB0], xmm11
00007f828abd2575  vmovaps [rsp+0xC0], xmm12
00007f828abd257e  vmovaps [rsp+0xD0], xmm13
00007f828abd2587  vmovaps [rsp+0xE0], xmm14
00007f828abd2590  sub rsp, 0x30
00007f828abd2594  movaps [rsp], xmm15
00007f828abd2599  movaps [rsp+0x10], xmm11
00007f828abd259f  movaps [rsp+0x20], xmm1
00007f828abd25a4  lea rdi, [rsp]
00007f828abd25a8  mov esi, 0x00
00007f828abd25ad  mov rax, 0x5BFE27FA6530
00007f828abd25b7  call rax
00007f828abd25b9  movaps xmm15, [rsp]
00007f828abd25be  add rsp, 0x30
00007f828abd25c2  vmovaps xmm0, [rsp]
00007f828abd25c7  vmovaps xmm1, [rsp+0x10]
00007f828abd25cd  vmovaps xmm2, [rsp+0x20]
00007f828abd25d3  vmovaps xmm3, [rsp+0x30]
00007f828abd25d9  vmovaps xmm4, [rsp+0x40]
00007f828abd25df  vmovaps xmm5, [rsp+0x50]
00007f828abd25e5  vmovaps xmm6, [rsp+0x60]
00007f828abd25eb  vmovaps xmm7, [rsp+0x70]
00007f828abd25f1  vmovaps xmm8, [rsp+0x80]
00007f828abd25fa  vmovaps xmm9, [rsp+0x90]
00007f828abd2603  vmovaps xmm10, [rsp+0xA0]
00007f828abd260c  vmovaps xmm11, [rsp+0xB0]
00007f828abd2615  vmovaps xmm12, [rsp+0xC0]
00007f828abd261e  vmovaps xmm13, [rsp+0xD0]
00007f828abd2627  vmovaps xmm14, [rsp+0xE0]
00007f828abd2630  add rsp, 0xF0
00007f828abd2637  pop r11
00007f828abd2639  pop r10
00007f828abd263b  pop r9
00007f828abd263d  pop r8
00007f828abd263f  pop rsi
00007f828abd2640  pop rdi
00007f828abd2641  pop rdx
00007f828abd2642  pop rcx
00007f828abd2643  pop rax
00007f828abd2644  add rsp, 0x08
00007f828abd2648  jmp 0x00007F828ABCFCBC
00007f828abd264d  sub rsp, 0x08
00007f828abd2651  push rax
00007f828abd2652  push rcx
00007f828abd2653  push rdx
00007f828abd2654  push rdi
00007f828abd2655  push rsi
00007f828abd2656  push r8
00007f828abd2658  push r9
00007f828abd265a  push r10
00007f828abd265c  push r11
00007f828abd265e  sub rsp, 0xF0
00007f828abd2665  vmovaps [rsp], xmm0
00007f828abd266a  vmovaps [rsp+0x10], xmm1
00007f828abd2670  vmovaps [rsp+0x20], xmm2
00007f828abd2676  vmovaps [rsp+0x30], xmm3
00007f828abd267c  vmovaps [rsp+0x40], xmm4
00007f828abd2682  vmovaps [rsp+0x50], xmm5
00007f828abd2688  vmovaps [rsp+0x60], xmm6
00007f828abd268e  vmovaps [rsp+0x70], xmm7
00007f828abd2694  vmovaps [rsp+0x80], xmm8
00007f828abd269d  vmovaps [rsp+0x90], xmm9
00007f828abd26a6  vmovaps [rsp+0xA0], xmm10
00007f828abd26af  vmovaps [rsp+0xB0], xmm12
00007f828abd26b8  vmovaps [rsp+0xC0], xmm13
00007f828abd26c1  vmovaps [rsp+0xD0], xmm14
00007f828abd26ca  vmovaps [rsp+0xE0], xmm15
00007f828abd26d3  sub rsp, 0x30
00007f828abd26d7  movaps [rsp], xmm11
00007f828abd26dc  movaps [rsp+0x10], xmm6
00007f828abd26e1  movaps [rsp+0x20], xmm14
00007f828abd26e7  lea rdi, [rsp]
00007f828abd26eb  mov esi, 0x00
00007f828abd26f0  mov rax, 0x5BFE27FA6530
00007f828abd26fa  call rax
00007f828abd26fc  movaps xmm11, [rsp]
00007f828abd2701  add rsp, 0x30
00007f828abd2705  vmovaps xmm0, [rsp]
00007f828abd270a  vmovaps xmm1, [rsp+0x10]
00007f828abd2710  vmovaps xmm2, [rsp+0x20]
00007f828abd2716  vmovaps xmm3, [rsp+0x30]
00007f828abd271c  vmovaps xmm4, [rsp+0x40]
00007f828abd2722  vmovaps xmm5, [rsp+0x50]
00007f828abd2728  vmovaps xmm6, [rsp+0x60]
00007f828abd272e  vmovaps xmm7, [rsp+0x70]
00007f828abd2734  vmovaps xmm8, [rsp+0x80]
00007f828abd273d  vmovaps xmm9, [rsp+0x90]
00007f828abd2746  vmovaps xmm10, [rsp+0xA0]
00007f828abd274f  vmovaps xmm12, [rsp+0xB0]
00007f828abd2758  vmovaps xmm13, [rsp+0xC0]
00007f828abd2761  vmovaps xmm14, [rsp+0xD0]
00007f828abd276a  vmovaps xmm15, [rsp+0xE0]
00007f828abd2773  add rsp, 0xF0
00007f828abd277a  pop r11
00007f828abd277c  pop r10
00007f828abd277e  pop r9
00007f828abd2780  pop r8
00007f828abd2782  pop rsi
00007f828abd2783  pop rdi
00007f828abd2784  pop rdx
00007f828abd2785  pop rcx
00007f828abd2786  pop rax
00007f828abd2787  add rsp, 0x08
00007f828abd278b  jmp 0x00007F828ABCFD34
00007f828abd2790  call 0x00007F828A9FF430
00007f828abd2795  jmp 0x00007F828ABCFD3E
00007f828abd279a  sub rsp, 0x08
00007f828abd279e  push rax
00007f828abd279f  push rcx
00007f828abd27a0  push rdx
00007f828abd27a1  push rdi
00007f828abd27a2  push rsi
00007f828abd27a3  push r8
00007f828abd27a5  push r9
00007f828abd27a7  push r10
00007f828abd27a9  push r11
00007f828abd27ab  sub rsp, 0xF0
00007f828abd27b2  vmovaps [rsp], xmm0
00007f828abd27b7  vmovaps [rsp+0x10], xmm1
00007f828abd27bd  vmovaps [rsp+0x20], xmm2
00007f828abd27c3  vmovaps [rsp+0x30], xmm3
00007f828abd27c9  vmovaps [rsp+0x40], xmm4
00007f828abd27cf  vmovaps [rsp+0x50], xmm5
00007f828abd27d5  vmovaps [rsp+0x60], xmm6
00007f828abd27db  vmovaps [rsp+0x70], xmm7
00007f828abd27e1  vmovaps [rsp+0x80], xmm8
00007f828abd27ea  vmovaps [rsp+0x90], xmm9
00007f828abd27f3  vmovaps [rsp+0xA0], xmm10
00007f828abd27fc  vmovaps [rsp+0xB0], xmm11
00007f828abd2805  vmovaps [rsp+0xC0], xmm12
00007f828abd280e  vmovaps [rsp+0xD0], xmm13
00007f828abd2817  vmovaps [rsp+0xE0], xmm15
00007f828abd2820  sub rsp, 0x30
00007f828abd2824  movaps [rsp], xmm14
00007f828abd2829  movaps [rsp+0x10], xmm6
00007f828abd282e  movaps [rsp+0x20], xmm2
00007f828abd2833  lea rdi, [rsp]
00007f828abd2837  mov esi, 0x00
00007f828abd283c  mov rax, 0x5BFE27FA6530
00007f828abd2846  call rax
00007f828abd2848  movaps xmm14, [rsp]
00007f828abd284d  add rsp, 0x30
00007f828abd2851  vmovaps xmm0, [rsp]
00007f828abd2856  vmovaps xmm1, [rsp+0x10]
00007f828abd285c  vmovaps xmm2, [rsp+0x20]
00007f828abd2862  vmovaps xmm3, [rsp+0x30]
00007f828abd2868  vmovaps xmm4, [rsp+0x40]
00007f828abd286e  vmovaps xmm5, [rsp+0x50]
00007f828abd2874  vmovaps xmm6, [rsp+0x60]
00007f828abd287a  vmovaps xmm7, [rsp+0x70]
00007f828abd2880  vmovaps xmm8, [rsp+0x80]
00007f828abd2889  vmovaps xmm9, [rsp+0x90]
00007f828abd2892  vmovaps xmm10, [rsp+0xA0]
00007f828abd289b  vmovaps xmm11, [rsp+0xB0]
00007f828abd28a4  vmovaps xmm12, [rsp+0xC0]
00007f828abd28ad  vmovaps xmm13, [rsp+0xD0]
00007f828abd28b6  vmovaps xmm15, [rsp+0xE0]
00007f828abd28bf  add rsp, 0xF0
00007f828abd28c6  pop r11
00007f828abd28c8  pop r10
00007f828abd28ca  pop r9
00007f828abd28cc  pop r8
00007f828abd28ce  pop rsi
00007f828abd28cf  pop rdi
00007f828abd28d0  pop rdx
00007f828abd28d1  pop rcx
00007f828abd28d2  pop rax
00007f828abd28d3  add rsp, 0x08
00007f828abd28d7  jmp 0x00007F828ABCFD72
00007f828abd28dc  sub rsp, 0x08
00007f828abd28e0  push rax
00007f828abd28e1  push rcx
00007f828abd28e2  push rdx
00007f828abd28e3  push rdi
00007f828abd28e4  push rsi
00007f828abd28e5  push r8
00007f828abd28e7  push r9
00007f828abd28e9  push r10
00007f828abd28eb  push r11
00007f828abd28ed  sub rsp, 0xF0
00007f828abd28f4  vmovaps [rsp], xmm0
00007f828abd28f9  vmovaps [rsp+0x10], xmm1
00007f828abd28ff  vmovaps [rsp+0x20], xmm2
00007f828abd2905  vmovaps [rsp+0x30], xmm3
00007f828abd290b  vmovaps [rsp+0x40], xmm4
00007f828abd2911  vmovaps [rsp+0x50], xmm5
00007f828abd2917  vmovaps [rsp+0x60], xmm7
00007f828abd291d  vmovaps [rsp+0x70], xmm8
00007f828abd2923  vmovaps [rsp+0x80], xmm9
00007f828abd292c  vmovaps [rsp+0x90], xmm10
00007f828abd2935  vmovaps [rsp+0xA0], xmm11
00007f828abd293e  vmovaps [rsp+0xB0], xmm12
00007f828abd2947  vmovaps [rsp+0xC0], xmm13
00007f828abd2950  vmovaps [rsp+0xD0], xmm14
00007f828abd2959  vmovaps [rsp+0xE0], xmm15
00007f828abd2962  sub rsp, 0x30
00007f828abd2966  movaps [rsp], xmm6
00007f828abd296a  movaps [rsp+0x10], xmm5
00007f828abd296f  movaps [rsp+0x20], xmm1
00007f828abd2974  lea rdi, [rsp]
00007f828abd2978  mov esi, 0x00
00007f828abd297d  mov rax, 0x5BFE27FA6530
00007f828abd2987  call rax
00007f828abd2989  movaps xmm6, [rsp]
00007f828abd298d  add rsp, 0x30
00007f828abd2991  vmovaps xmm0, [rsp]
00007f828abd2996  vmovaps xmm1, [rsp+0x10]
00007f828abd299c  vmovaps xmm2, [rsp+0x20]
00007f828abd29a2  vmovaps xmm3, [rsp+0x30]
00007f828abd29a8  vmovaps xmm4, [rsp+0x40]
00007f828abd29ae  vmovaps xmm5, [rsp+0x50]
00007f828abd29b4  vmovaps xmm7, [rsp+0x60]
00007f828abd29ba  vmovaps xmm8, [rsp+0x70]
00007f828abd29c0  vmovaps xmm9, [rsp+0x80]
00007f828abd29c9  vmovaps xmm10, [rsp+0x90]
00007f828abd29d2  vmovaps xmm11, [rsp+0xA0]
00007f828abd29db  vmovaps xmm12, [rsp+0xB0]
00007f828abd29e4  vmovaps xmm13, [rsp+0xC0]
00007f828abd29ed  vmovaps xmm14, [rsp+0xD0]
00007f828abd29f6  vmovaps xmm15, [rsp+0xE0]
00007f828abd29ff  add rsp, 0xF0
00007f828abd2a06  pop r11
00007f828abd2a08  pop r10
00007f828abd2a0a  pop r9
00007f828abd2a0c  pop r8
00007f828abd2a0e  pop rsi
00007f828abd2a0f  pop rdi
00007f828abd2a10  pop rdx
00007f828abd2a11  pop rcx
00007f828abd2a12  pop rax
00007f828abd2a13  add rsp, 0x08
00007f828abd2a17  jmp 0x00007F828ABCFD98
00007f828abd2a1c  sub rsp, 0x08
00007f828abd2a20  push rax
00007f828abd2a21  push rcx
00007f828abd2a22  push rdx
00007f828abd2a23  push rdi
00007f828abd2a24  push rsi
00007f828abd2a25  push r8
00007f828abd2a27  push r9
00007f828abd2a29  push r10
00007f828abd2a2b  push r11
00007f828abd2a2d  sub rsp, 0xF0
00007f828abd2a34  vmovaps [rsp], xmm0
00007f828abd2a39  vmovaps [rsp+0x10], xmm2
00007f828abd2a3f  vmovaps [rsp+0x20], xmm3
00007f828abd2a45  vmovaps [rsp+0x30], xmm4
00007f828abd2a4b  vmovaps [rsp+0x40], xmm5
00007f828abd2a51  vmovaps [rsp+0x50], xmm6
00007f828abd2a57  vmovaps [rsp+0x60], xmm7
00007f828abd2a5d  vmovaps [rsp+0x70], xmm8
00007f828abd2a63  vmovaps [rsp+0x80], xmm9
00007f828abd2a6c  vmovaps [rsp+0x90], xmm10
00007f828abd2a75  vmovaps [rsp+0xA0], xmm11
00007f828abd2a7e  vmovaps [rsp+0xB0], xmm12
00007f828abd2a87  vmovaps [rsp+0xC0], xmm13
00007f828abd2a90  vmovaps [rsp+0xD0], xmm14
00007f828abd2a99  vmovaps [rsp+0xE0], xmm15
00007f828abd2aa2  sub rsp, 0x30
00007f828abd2aa6  movaps [rsp], xmm1
00007f828abd2aaa  movaps [rsp+0x10], xmm5
00007f828abd2aaf  movaps [rsp+0x20], xmm13
00007f828abd2ab5  lea rdi, [rsp]
00007f828abd2ab9  mov esi, 0x00
00007f828abd2abe  mov rax, 0x5BFE27FA6530
00007f828abd2ac8  call rax
00007f828abd2aca  movaps xmm1, [rsp]
00007f828abd2ace  add rsp, 0x30
00007f828abd2ad2  vmovaps xmm0, [rsp]
00007f828abd2ad7  vmovaps xmm2, [rsp+0x10]
00007f828abd2add  vmovaps xmm3, [rsp+0x20]
00007f828abd2ae3  vmovaps xmm4, [rsp+0x30]
00007f828abd2ae9  vmovaps xmm5, [rsp+0x40]
00007f828abd2aef  vmovaps xmm6, [rsp+0x50]
00007f828abd2af5  vmovaps xmm7, [rsp+0x60]
00007f828abd2afb  vmovaps xmm8, [rsp+0x70]
00007f828abd2b01  vmovaps xmm9, [rsp+0x80]
00007f828abd2b0a  vmovaps xmm10, [rsp+0x90]
00007f828abd2b13  vmovaps xmm11, [rsp+0xA0]
00007f828abd2b1c  vmovaps xmm12, [rsp+0xB0]
00007f828abd2b25  vmovaps xmm13, [rsp+0xC0]
00007f828abd2b2e  vmovaps xmm14, [rsp+0xD0]
00007f828abd2b37  vmovaps xmm15, [rsp+0xE0]
00007f828abd2b40  add rsp, 0xF0
00007f828abd2b47  pop r11
00007f828abd2b49  pop r10
00007f828abd2b4b  pop r9
00007f828abd2b4d  pop r8
00007f828abd2b4f  pop rsi
00007f828abd2b50  pop rdi
00007f828abd2b51  pop rdx
00007f828abd2b52  pop rcx
00007f828abd2b53  pop rax
00007f828abd2b54  add rsp, 0x08
00007f828abd2b58  jmp 0x00007F828ABCFDB6
00007f828abd2b5d  sub rsp, 0x08
00007f828abd2b61  push rax
00007f828abd2b62  push rcx
00007f828abd2b63  push rdx
00007f828abd2b64  push rdi
00007f828abd2b65  push rsi
00007f828abd2b66  push r8
00007f828abd2b68  push r9
00007f828abd2b6a  push r10
00007f828abd2b6c  push r11
00007f828abd2b6e  sub rsp, 0xF0
00007f828abd2b75  vmovaps [rsp], xmm0
00007f828abd2b7a  vmovaps [rsp+0x10], xmm1
00007f828abd2b80  vmovaps [rsp+0x20], xmm2
00007f828abd2b86  vmovaps [rsp+0x30], xmm3
00007f828abd2b8c  vmovaps [rsp+0x40], xmm4
00007f828abd2b92  vmovaps [rsp+0x50], xmm6
00007f828abd2b98  vmovaps [rsp+0x60], xmm7
00007f828abd2b9e  vmovaps [rsp+0x70], xmm8
00007f828abd2ba4  vmovaps [rsp+0x80], xmm9
00007f828abd2bad  vmovaps [rsp+0x90], xmm10
00007f828abd2bb6  vmovaps [rsp+0xA0], xmm11
00007f828abd2bbf  vmovaps [rsp+0xB0], xmm12
00007f828abd2bc8  vmovaps [rsp+0xC0], xmm13
00007f828abd2bd1  vmovaps [rsp+0xD0], xmm14
00007f828abd2bda  vmovaps [rsp+0xE0], xmm15
00007f828abd2be3  sub rsp, 0x30
00007f828abd2be7  movaps [rsp], xmm5
00007f828abd2beb  movaps [rsp+0x10], xmm2
00007f828abd2bf0  movaps [rsp+0x20], xmm13
00007f828abd2bf6  lea rdi, [rsp]
00007f828abd2bfa  mov esi, 0x00
00007f828abd2bff  mov rax, 0x5BFE27FA6530
00007f828abd2c09  call rax
00007f828abd2c0b  movaps xmm5, [rsp]
00007f828abd2c0f  add rsp, 0x30
00007f828abd2c13  vmovaps xmm0, [rsp]
00007f828abd2c18  vmovaps xmm1, [rsp+0x10]
00007f828abd2c1e  vmovaps xmm2, [rsp+0x20]
00007f828abd2c24  vmovaps xmm3, [rsp+0x30]
00007f828abd2c2a  vmovaps xmm4, [rsp+0x40]
00007f828abd2c30  vmovaps xmm6, [rsp+0x50]
00007f828abd2c36  vmovaps xmm7, [rsp+0x60]
00007f828abd2c3c  vmovaps xmm8, [rsp+0x70]
00007f828abd2c42  vmovaps xmm9, [rsp+0x80]
00007f828abd2c4b  vmovaps xmm10, [rsp+0x90]
00007f828abd2c54  vmovaps xmm11, [rsp+0xA0]
00007f828abd2c5d  vmovaps xmm12, [rsp+0xB0]
00007f828abd2c66  vmovaps xmm13, [rsp+0xC0]
00007f828abd2c6f  vmovaps xmm14, [rsp+0xD0]
00007f828abd2c78  vmovaps xmm15, [rsp+0xE0]
00007f828abd2c81  add rsp, 0xF0
00007f828abd2c88  pop r11
00007f828abd2c8a  pop r10
00007f828abd2c8c  pop r9
00007f828abd2c8e  pop r8
00007f828abd2c90  pop rsi
00007f828abd2c91  pop rdi
00007f828abd2c92  pop rdx
00007f828abd2c93  pop rcx
00007f828abd2c94  pop rax
00007f828abd2c95  add rsp, 0x08
00007f828abd2c99  jmp 0x00007F828ABCFDEC
00007f828abd2c9e  sub rsp, 0x08
00007f828abd2ca2  push rax
00007f828abd2ca3  push rcx
00007f828abd2ca4  push rdx
00007f828abd2ca5  push rdi
00007f828abd2ca6  push rsi
00007f828abd2ca7  push r8
00007f828abd2ca9  push r9
00007f828abd2cab  push r10
00007f828abd2cad  push r11
00007f828abd2caf  sub rsp, 0xF0
00007f828abd2cb6  vmovaps [rsp], xmm0
00007f828abd2cbb  vmovaps [rsp+0x10], xmm1
00007f828abd2cc1  vmovaps [rsp+0x20], xmm2
00007f828abd2cc7  vmovaps [rsp+0x30], xmm3
00007f828abd2ccd  vmovaps [rsp+0x40], xmm4
00007f828abd2cd3  vmovaps [rsp+0x50], xmm5
00007f828abd2cd9  vmovaps [rsp+0x60], xmm6
00007f828abd2cdf  vmovaps [rsp+0x70], xmm7
00007f828abd2ce5  vmovaps [rsp+0x80], xmm8
00007f828abd2cee  vmovaps [rsp+0x90], xmm9
00007f828abd2cf7  vmovaps [rsp+0xA0], xmm10
00007f828abd2d00  vmovaps [rsp+0xB0], xmm11
00007f828abd2d09  vmovaps [rsp+0xC0], xmm12
00007f828abd2d12  vmovaps [rsp+0xD0], xmm14
00007f828abd2d1b  vmovaps [rsp+0xE0], xmm15
00007f828abd2d24  sub rsp, 0x30
00007f828abd2d28  movaps [rsp], xmm13
00007f828abd2d2d  movaps [rsp+0x10], xmm10
00007f828abd2d33  movaps [rsp+0x20], xmm1
00007f828abd2d38  lea rdi, [rsp]
00007f828abd2d3c  mov esi, 0x00
00007f828abd2d41  mov rax, 0x5BFE27FA6530
00007f828abd2d4b  call rax
00007f828abd2d4d  movaps xmm13, [rsp]
00007f828abd2d52  add rsp, 0x30
00007f828abd2d56  vmovaps xmm0, [rsp]
00007f828abd2d5b  vmovaps xmm1, [rsp+0x10]
00007f828abd2d61  vmovaps xmm2, [rsp+0x20]
00007f828abd2d67  vmovaps xmm3, [rsp+0x30]
00007f828abd2d6d  vmovaps xmm4, [rsp+0x40]
00007f828abd2d73  vmovaps xmm5, [rsp+0x50]
00007f828abd2d79  vmovaps xmm6, [rsp+0x60]
00007f828abd2d7f  vmovaps xmm7, [rsp+0x70]
00007f828abd2d85  vmovaps xmm8, [rsp+0x80]
00007f828abd2d8e  vmovaps xmm9, [rsp+0x90]
00007f828abd2d97  vmovaps xmm10, [rsp+0xA0]
00007f828abd2da0  vmovaps xmm11, [rsp+0xB0]
00007f828abd2da9  vmovaps xmm12, [rsp+0xC0]
00007f828abd2db2  vmovaps xmm14, [rsp+0xD0]
00007f828abd2dbb  vmovaps xmm15, [rsp+0xE0]
00007f828abd2dc4  add rsp, 0xF0
00007f828abd2dcb  pop r11
00007f828abd2dcd  pop r10
00007f828abd2dcf  pop r9
00007f828abd2dd1  pop r8
00007f828abd2dd3  pop rsi
00007f828abd2dd4  pop rdi
00007f828abd2dd5  pop rdx
00007f828abd2dd6  pop rcx
00007f828abd2dd7  pop rax
00007f828abd2dd8  add rsp, 0x08
00007f828abd2ddc  jmp 0x00007F828ABCFE15
00007f828abd2de1  sub rsp, 0x08
00007f828abd2de5  push rax
00007f828abd2de6  push rcx
00007f828abd2de7  push rdx
00007f828abd2de8  push rdi
00007f828abd2de9  push rsi
00007f828abd2dea  push r8
00007f828abd2dec  push r9
00007f828abd2dee  push r10
00007f828abd2df0  push r11
00007f828abd2df2  sub rsp, 0xF0
00007f828abd2df9  vmovaps [rsp], xmm0
00007f828abd2dfe  vmovaps [rsp+0x10], xmm2
00007f828abd2e04  vmovaps [rsp+0x20], xmm3
00007f828abd2e0a  vmovaps [rsp+0x30], xmm4
00007f828abd2e10  vmovaps [rsp+0x40], xmm5
00007f828abd2e16  vmovaps [rsp+0x50], xmm6
00007f828abd2e1c  vmovaps [rsp+0x60], xmm7
00007f828abd2e22  vmovaps [rsp+0x70], xmm8
00007f828abd2e28  vmovaps [rsp+0x80], xmm9
00007f828abd2e31  vmovaps [rsp+0x90], xmm10
00007f828abd2e3a  vmovaps [rsp+0xA0], xmm11
00007f828abd2e43  vmovaps [rsp+0xB0], xmm12
00007f828abd2e4c  vmovaps [rsp+0xC0], xmm13
00007f828abd2e55  vmovaps [rsp+0xD0], xmm14
00007f828abd2e5e  vmovaps [rsp+0xE0], xmm15
00007f828abd2e67  sub rsp, 0x30
00007f828abd2e6b  movaps [rsp], xmm1
00007f828abd2e6f  movaps [rsp+0x10], xmm15
00007f828abd2e75  movaps [rsp+0x20], xmm10
00007f828abd2e7b  lea rdi, [rsp]
00007f828abd2e7f  mov esi, 0x00
00007f828abd2e84  mov rax, 0x5BFE27FA6530
00007f828abd2e8e  call rax
00007f828abd2e90  movaps xmm1, [rsp]
00007f828abd2e94  add rsp, 0x30
00007f828abd2e98  vmovaps xmm0, [rsp]
00007f828abd2e9d  vmovaps xmm2, [rsp+0x10]
00007f828abd2ea3  vmovaps xmm3, [rsp+0x20]
00007f828abd2ea9  vmovaps xmm4, [rsp+0x30]
00007f828abd2eaf  vmovaps xmm5, [rsp+0x40]
00007f828abd2eb5  vmovaps xmm6, [rsp+0x50]
00007f828abd2ebb  vmovaps xmm7, [rsp+0x60]
00007f828abd2ec1  vmovaps xmm8, [rsp+0x70]
00007f828abd2ec7  vmovaps xmm9, [rsp+0x80]
00007f828abd2ed0  vmovaps xmm10, [rsp+0x90]
00007f828abd2ed9  vmovaps xmm11, [rsp+0xA0]
00007f828abd2ee2  vmovaps xmm12, [rsp+0xB0]
00007f828abd2eeb  vmovaps xmm13, [rsp+0xC0]
00007f828abd2ef4  vmovaps xmm14, [rsp+0xD0]
00007f828abd2efd  vmovaps xmm15, [rsp+0xE0]
00007f828abd2f06  add rsp, 0xF0
00007f828abd2f0d  pop r11
00007f828abd2f0f  pop r10
00007f828abd2f11  pop r9
00007f828abd2f13  pop r8
00007f828abd2f15  pop rsi
00007f828abd2f16  pop rdi
00007f828abd2f17  pop rdx
00007f828abd2f18  pop rcx
00007f828abd2f19  pop rax
00007f828abd2f1a  add rsp, 0x08
00007f828abd2f1e  jmp 0x00007F828ABCFE34
00007f828abd2f23  sub rsp, 0x08
00007f828abd2f27  push rax
00007f828abd2f28  push rcx
00007f828abd2f29  push rdx
00007f828abd2f2a  push rdi
00007f828abd2f2b  push rsi
00007f828abd2f2c  push r8
00007f828abd2f2e  push r9
00007f828abd2f30  push r10
00007f828abd2f32  push r11
00007f828abd2f34  sub rsp, 0xF0
00007f828abd2f3b  vmovaps [rsp], xmm0
00007f828abd2f40  vmovaps [rsp+0x10], xmm1
00007f828abd2f46  vmovaps [rsp+0x20], xmm2
00007f828abd2f4c  vmovaps [rsp+0x30], xmm3
00007f828abd2f52  vmovaps [rsp+0x40], xmm4
00007f828abd2f58  vmovaps [rsp+0x50], xmm5
00007f828abd2f5e  vmovaps [rsp+0x60], xmm6
00007f828abd2f64  vmovaps [rsp+0x70], xmm7
00007f828abd2f6a  vmovaps [rsp+0x80], xmm8
00007f828abd2f73  vmovaps [rsp+0x90], xmm9
00007f828abd2f7c  vmovaps [rsp+0xA0], xmm10
00007f828abd2f85  vmovaps [rsp+0xB0], xmm11
00007f828abd2f8e  vmovaps [rsp+0xC0], xmm12
00007f828abd2f97  vmovaps [rsp+0xD0], xmm13
00007f828abd2fa0  vmovaps [rsp+0xE0], xmm14
00007f828abd2fa9  sub rsp, 0x30
00007f828abd2fad  movaps [rsp], xmm15
00007f828abd2fb2  movaps [rsp+0x10], xmm10
00007f828abd2fb8  movaps [rsp+0x20], xmm11
00007f828abd2fbe  lea rdi, [rsp]
00007f828abd2fc2  mov esi, 0x00
00007f828abd2fc7  mov rax, 0x5BFE27FA6530
00007f828abd2fd1  call rax
00007f828abd2fd3  movaps xmm15, [rsp]
00007f828abd2fd8  add rsp, 0x30
00007f828abd2fdc  vmovaps xmm0, [rsp]
00007f828abd2fe1  vmovaps xmm1, [rsp+0x10]
00007f828abd2fe7  vmovaps xmm2, [rsp+0x20]
00007f828abd2fed  vmovaps xmm3, [rsp+0x30]
00007f828abd2ff3  vmovaps xmm4, [rsp+0x40]
00007f828abd2ff9  vmovaps xmm5, [rsp+0x50]
00007f828abd2fff  vmovaps xmm6, [rsp+0x60]
00007f828abd3005  vmovaps xmm7, [rsp+0x70]
00007f828abd300b  vmovaps xmm8, [rsp+0x80]
00007f828abd3014  vmovaps xmm9, [rsp+0x90]
00007f828abd301d  vmovaps xmm10, [rsp+0xA0]
00007f828abd3026  vmovaps xmm11, [rsp+0xB0]
00007f828abd302f  vmovaps xmm12, [rsp+0xC0]
00007f828abd3038  vmovaps xmm13, [rsp+0xD0]
00007f828abd3041  vmovaps xmm14, [rsp+0xE0]
00007f828abd304a  add rsp, 0xF0
00007f828abd3051  pop r11
00007f828abd3053  pop r10
00007f828abd3055  pop r9
00007f828abd3057  pop r8
00007f828abd3059  pop rsi
00007f828abd305a  pop rdi
00007f828abd305b  pop rdx
00007f828abd305c  pop rcx
00007f828abd305d  pop rax
00007f828abd305e  add rsp, 0x08
00007f828abd3062  jmp 0x00007F828ABCFE57
00007f828abd3067  sub rsp, 0x08
00007f828abd306b  push rax
00007f828abd306c  push rcx
00007f828abd306d  push rdx
00007f828abd306e  push rdi
00007f828abd306f  push rsi
00007f828abd3070  push r8
00007f828abd3072  push r9
00007f828abd3074  push r10
00007f828abd3076  push r11
00007f828abd3078  sub rsp, 0xF0
00007f828abd307f  vmovaps [rsp], xmm0
00007f828abd3084  vmovaps [rsp+0x10], xmm1
00007f828abd308a  vmovaps [rsp+0x20], xmm2
00007f828abd3090  vmovaps [rsp+0x30], xmm3
00007f828abd3096  vmovaps [rsp+0x40], xmm4
00007f828abd309c  vmovaps [rsp+0x50], xmm5
00007f828abd30a2  vmovaps [rsp+0x60], xmm6
00007f828abd30a8  vmovaps [rsp+0x70], xmm7
00007f828abd30ae  vmovaps [rsp+0x80], xmm8
00007f828abd30b7  vmovaps [rsp+0x90], xmm9
00007f828abd30c0  vmovaps [rsp+0xA0], xmm11
00007f828abd30c9  vmovaps [rsp+0xB0], xmm12
00007f828abd30d2  vmovaps [rsp+0xC0], xmm13
00007f828abd30db  vmovaps [rsp+0xD0], xmm14
00007f828abd30e4  vmovaps [rsp+0xE0], xmm15
00007f828abd30ed  sub rsp, 0x30
00007f828abd30f1  movaps [rsp], xmm10
00007f828abd30f6  movaps [rsp+0x10], xmm12
00007f828abd30fc  movaps [rsp+0x20], xmm11
00007f828abd3102  lea rdi, [rsp]
00007f828abd3106  mov esi, 0x00
00007f828abd310b  mov rax, 0x5BFE27FA6530
00007f828abd3115  call rax
00007f828abd3117  movaps xmm10, [rsp]
00007f828abd311c  add rsp, 0x30
00007f828abd3120  vmovaps xmm0, [rsp]
00007f828abd3125  vmovaps xmm1, [rsp+0x10]
00007f828abd312b  vmovaps xmm2, [rsp+0x20]
00007f828abd3131  vmovaps xmm3, [rsp+0x30]
00007f828abd3137  vmovaps xmm4, [rsp+0x40]
00007f828abd313d  vmovaps xmm5, [rsp+0x50]
00007f828abd3143  vmovaps xmm6, [rsp+0x60]
00007f828abd3149  vmovaps xmm7, [rsp+0x70]
00007f828abd314f  vmovaps xmm8, [rsp+0x80]
00007f828abd3158  vmovaps xmm9, [rsp+0x90]
00007f828abd3161  vmovaps xmm11, [rsp+0xA0]
00007f828abd316a  vmovaps xmm12, [rsp+0xB0]
00007f828abd3173  vmovaps xmm13, [rsp+0xC0]
00007f828abd317c  vmovaps xmm14, [rsp+0xD0]
00007f828abd3185  vmovaps xmm15, [rsp+0xE0]
00007f828abd318e  add rsp, 0xF0
00007f828abd3195  pop r11
00007f828abd3197  pop r10
00007f828abd3199  pop r9
00007f828abd319b  pop r8
00007f828abd319d  pop rsi
00007f828abd319e  pop rdi
00007f828abd319f  pop rdx
00007f828abd31a0  pop rcx
00007f828abd31a1  pop rax
00007f828abd31a2  add rsp, 0x08
00007f828abd31a6  jmp 0x00007F828ABCFE80
00007f828abd31ab  sub rsp, 0x08
00007f828abd31af  push rax
00007f828abd31b0  push rcx
00007f828abd31b1  push rdx
00007f828abd31b2  push rdi
00007f828abd31b3  push rsi
00007f828abd31b4  push r8
00007f828abd31b6  push r9
00007f828abd31b8  push r10
00007f828abd31ba  push r11
00007f828abd31bc  sub rsp, 0xF0
00007f828abd31c3  vmovaps [rsp], xmm0
00007f828abd31c8  vmovaps [rsp+0x10], xmm1
00007f828abd31ce  vmovaps [rsp+0x20], xmm2
00007f828abd31d4  vmovaps [rsp+0x30], xmm3
00007f828abd31da  vmovaps [rsp+0x40], xmm4
00007f828abd31e0  vmovaps [rsp+0x50], xmm5
00007f828abd31e6  vmovaps [rsp+0x60], xmm6
00007f828abd31ec  vmovaps [rsp+0x70], xmm7
00007f828abd31f2  vmovaps [rsp+0x80], xmm8
00007f828abd31fb  vmovaps [rsp+0x90], xmm9
00007f828abd3204  vmovaps [rsp+0xA0], xmm10
00007f828abd320d  vmovaps [rsp+0xB0], xmm12
00007f828abd3216  vmovaps [rsp+0xC0], xmm13
00007f828abd321f  vmovaps [rsp+0xD0], xmm14
00007f828abd3228  vmovaps [rsp+0xE0], xmm15
00007f828abd3231  sub rsp, 0x30
00007f828abd3235  movaps [rsp], xmm11
00007f828abd323a  movaps [rsp+0x10], xmm2
00007f828abd323f  movaps [rsp+0x20], xmm12
00007f828abd3245  lea rdi, [rsp]
00007f828abd3249  mov esi, 0x00
00007f828abd324e  mov rax, 0x5BFE27FA6530
00007f828abd3258  call rax
00007f828abd325a  movaps xmm11, [rsp]
00007f828abd325f  add rsp, 0x30
00007f828abd3263  vmovaps xmm0, [rsp]
00007f828abd3268  vmovaps xmm1, [rsp+0x10]
00007f828abd326e  vmovaps xmm2, [rsp+0x20]
00007f828abd3274  vmovaps xmm3, [rsp+0x30]
00007f828abd327a  vmovaps xmm4, [rsp+0x40]
00007f828abd3280  vmovaps xmm5, [rsp+0x50]
00007f828abd3286  vmovaps xmm6, [rsp+0x60]
00007f828abd328c  vmovaps xmm7, [rsp+0x70]
00007f828abd3292  vmovaps xmm8, [rsp+0x80]
00007f828abd329b  vmovaps xmm9, [rsp+0x90]
00007f828abd32a4  vmovaps xmm10, [rsp+0xA0]
00007f828abd32ad  vmovaps xmm12, [rsp+0xB0]
00007f828abd32b6  vmovaps xmm13, [rsp+0xC0]
00007f828abd32bf  vmovaps xmm14, [rsp+0xD0]
00007f828abd32c8  vmovaps xmm15, [rsp+0xE0]
00007f828abd32d1  add rsp, 0xF0
00007f828abd32d8  pop r11
00007f828abd32da  pop r10
00007f828abd32dc  pop r9
00007f828abd32de  pop r8
00007f828abd32e0  pop rsi
00007f828abd32e1  pop rdi
00007f828abd32e2  pop rdx
00007f828abd32e3  pop rcx
00007f828abd32e4  pop rax
00007f828abd32e5  add rsp, 0x08
00007f828abd32e9  jmp 0x00007F828ABCFEB8
00007f828abd32ee  sub rsp, 0x08
00007f828abd32f2  push rax
00007f828abd32f3  push rcx
00007f828abd32f4  push rdx
00007f828abd32f5  push rdi
00007f828abd32f6  push rsi
00007f828abd32f7  push r8
00007f828abd32f9  push r9
00007f828abd32fb  push r10
00007f828abd32fd  push r11
00007f828abd32ff  sub rsp, 0xF0
00007f828abd3306  vmovaps [rsp], xmm0
00007f828abd330b  vmovaps [rsp+0x10], xmm2
00007f828abd3311  vmovaps [rsp+0x20], xmm3
00007f828abd3317  vmovaps [rsp+0x30], xmm4
00007f828abd331d  vmovaps [rsp+0x40], xmm5
00007f828abd3323  vmovaps [rsp+0x50], xmm6
00007f828abd3329  vmovaps [rsp+0x60], xmm7
00007f828abd332f  vmovaps [rsp+0x70], xmm8
00007f828abd3335  vmovaps [rsp+0x80], xmm9
00007f828abd333e  vmovaps [rsp+0x90], xmm10
00007f828abd3347  vmovaps [rsp+0xA0], xmm11
00007f828abd3350  vmovaps [rsp+0xB0], xmm12
00007f828abd3359  vmovaps [rsp+0xC0], xmm13
00007f828abd3362  vmovaps [rsp+0xD0], xmm14
00007f828abd336b  vmovaps [rsp+0xE0], xmm15
00007f828abd3374  sub rsp, 0x30
00007f828abd3378  movaps [rsp], xmm1
00007f828abd337c  movaps [rsp+0x10], xmm14
00007f828abd3382  movaps [rsp+0x20], xmm6
00007f828abd3387  lea rdi, [rsp]
00007f828abd338b  mov esi, 0x00
00007f828abd3390  mov rax, 0x5BFE27FA6530
00007f828abd339a  call rax
00007f828abd339c  movaps xmm1, [rsp]
00007f828abd33a0  add rsp, 0x30
00007f828abd33a4  vmovaps xmm0, [rsp]
00007f828abd33a9  vmovaps xmm2, [rsp+0x10]
00007f828abd33af  vmovaps xmm3, [rsp+0x20]
00007f828abd33b5  vmovaps xmm4, [rsp+0x30]
00007f828abd33bb  vmovaps xmm5, [rsp+0x40]
00007f828abd33c1  vmovaps xmm6, [rsp+0x50]
00007f828abd33c7  vmovaps xmm7, [rsp+0x60]
00007f828abd33cd  vmovaps xmm8, [rsp+0x70]
00007f828abd33d3  vmovaps xmm9, [rsp+0x80]
00007f828abd33dc  vmovaps xmm10, [rsp+0x90]
00007f828abd33e5  vmovaps xmm11, [rsp+0xA0]
00007f828abd33ee  vmovaps xmm12, [rsp+0xB0]
00007f828abd33f7  vmovaps xmm13, [rsp+0xC0]
00007f828abd3400  vmovaps xmm14, [rsp+0xD0]
00007f828abd3409  vmovaps xmm15, [rsp+0xE0]
00007f828abd3412  add rsp, 0xF0
00007f828abd3419  pop r11
00007f828abd341b  pop r10
00007f828abd341d  pop r9
00007f828abd341f  pop r8
00007f828abd3421  pop rsi
00007f828abd3422  pop rdi
00007f828abd3423  pop rdx
00007f828abd3424  pop rcx
00007f828abd3425  pop rax
00007f828abd3426  add rsp, 0x08
00007f828abd342a  jmp 0x00007F828ABCFED1
00007f828abd342f  sub rsp, 0x08
00007f828abd3433  push rax
00007f828abd3434  push rcx
00007f828abd3435  push rdx
00007f828abd3436  push rdi
00007f828abd3437  push rsi
00007f828abd3438  push r8
00007f828abd343a  push r9
00007f828abd343c  push r10
00007f828abd343e  push r11
00007f828abd3440  sub rsp, 0xF0
00007f828abd3447  vmovaps [rsp], xmm0
00007f828abd344c  vmovaps [rsp+0x10], xmm1
00007f828abd3452  vmovaps [rsp+0x20], xmm2
00007f828abd3458  vmovaps [rsp+0x30], xmm3
00007f828abd345e  vmovaps [rsp+0x40], xmm4
00007f828abd3464  vmovaps [rsp+0x50], xmm5
00007f828abd346a  vmovaps [rsp+0x60], xmm6
00007f828abd3470  vmovaps [rsp+0x70], xmm7
00007f828abd3476  vmovaps [rsp+0x80], xmm8
00007f828abd347f  vmovaps [rsp+0x90], xmm9
00007f828abd3488  vmovaps [rsp+0xA0], xmm10
00007f828abd3491  vmovaps [rsp+0xB0], xmm11
00007f828abd349a  vmovaps [rsp+0xC0], xmm12
00007f828abd34a3  vmovaps [rsp+0xD0], xmm13
00007f828abd34ac  vmovaps [rsp+0xE0], xmm15
00007f828abd34b5  sub rsp, 0x30
00007f828abd34b9  movaps [rsp], xmm14
00007f828abd34be  movaps [rsp+0x10], xmm12
00007f828abd34c4  movaps [rsp+0x20], xmm5
00007f828abd34c9  lea rdi, [rsp]
00007f828abd34cd  mov esi, 0x00
00007f828abd34d2  mov rax, 0x5BFE27FA6530
00007f828abd34dc  call rax
00007f828abd34de  movaps xmm14, [rsp]
00007f828abd34e3  add rsp, 0x30
00007f828abd34e7  vmovaps xmm0, [rsp]
00007f828abd34ec  vmovaps xmm1, [rsp+0x10]
00007f828abd34f2  vmovaps xmm2, [rsp+0x20]
00007f828abd34f8  vmovaps xmm3, [rsp+0x30]
00007f828abd34fe  vmovaps xmm4, [rsp+0x40]
00007f828abd3504  vmovaps xmm5, [rsp+0x50]
00007f828abd350a  vmovaps xmm6, [rsp+0x60]
00007f828abd3510  vmovaps xmm7, [rsp+0x70]
00007f828abd3516  vmovaps xmm8, [rsp+0x80]
00007f828abd351f  vmovaps xmm9, [rsp+0x90]
00007f828abd3528  vmovaps xmm10, [rsp+0xA0]
00007f828abd3531  vmovaps xmm11, [rsp+0xB0]
00007f828abd353a  vmovaps xmm12, [rsp+0xC0]
00007f828abd3543  vmovaps xmm13, [rsp+0xD0]
00007f828abd354c  vmovaps xmm15, [rsp+0xE0]
00007f828abd3555  add rsp, 0xF0
00007f828abd355c  pop r11
00007f828abd355e  pop r10
00007f828abd3560  pop r9
00007f828abd3562  pop r8
00007f828abd3564  pop rsi
00007f828abd3565  pop rdi
00007f828abd3566  pop rdx
00007f828abd3567  pop rcx
00007f828abd3568  pop rax
00007f828abd3569  add rsp, 0x08
00007f828abd356d  jmp 0x00007F828ABCFEF1
00007f828abd3572  sub rsp, 0x08
00007f828abd3576  push rax
00007f828abd3577  push rcx
00007f828abd3578  push rdx
00007f828abd3579  push rdi
00007f828abd357a  push rsi
00007f828abd357b  push r8
00007f828abd357d  push r9
00007f828abd357f  push r10
00007f828abd3581  push r11
00007f828abd3583  sub rsp, 0xF0
00007f828abd358a  vmovaps [rsp], xmm0
00007f828abd358f  vmovaps [rsp+0x10], xmm1
00007f828abd3595  vmovaps [rsp+0x20], xmm2
00007f828abd359b  vmovaps [rsp+0x30], xmm3
00007f828abd35a1  vmovaps [rsp+0x40], xmm4
00007f828abd35a7  vmovaps [rsp+0x50], xmm5
00007f828abd35ad  vmovaps [rsp+0x60], xmm7
00007f828abd35b3  vmovaps [rsp+0x70], xmm8
00007f828abd35b9  vmovaps [rsp+0x80], xmm9
00007f828abd35c2  vmovaps [rsp+0x90], xmm10
00007f828abd35cb  vmovaps [rsp+0xA0], xmm11
00007f828abd35d4  vmovaps [rsp+0xB0], xmm12
00007f828abd35dd  vmovaps [rsp+0xC0], xmm13
00007f828abd35e6  vmovaps [rsp+0xD0], xmm14
00007f828abd35ef  vmovaps [rsp+0xE0], xmm15
00007f828abd35f8  sub rsp, 0x30
00007f828abd35fc  movaps [rsp], xmm6
00007f828abd3600  movaps [rsp+0x10], xmm9
00007f828abd3606  movaps [rsp+0x20], xmm12
00007f828abd360c  lea rdi, [rsp]
00007f828abd3610  mov esi, 0x00
00007f828abd3615  mov rax, 0x5BFE27FA6530
00007f828abd361f  call rax
00007f828abd3621  movaps xmm6, [rsp]
00007f828abd3625  add rsp, 0x30
00007f828abd3629  vmovaps xmm0, [rsp]
00007f828abd362e  vmovaps xmm1, [rsp+0x10]
00007f828abd3634  vmovaps xmm2, [rsp+0x20]
00007f828abd363a  vmovaps xmm3, [rsp+0x30]
00007f828abd3640  vmovaps xmm4, [rsp+0x40]
00007f828abd3646  vmovaps xmm5, [rsp+0x50]
00007f828abd364c  vmovaps xmm7, [rsp+0x60]
00007f828abd3652  vmovaps xmm8, [rsp+0x70]
00007f828abd3658  vmovaps xmm9, [rsp+0x80]
00007f828abd3661  vmovaps xmm10, [rsp+0x90]
00007f828abd366a  vmovaps xmm11, [rsp+0xA0]
00007f828abd3673  vmovaps xmm12, [rsp+0xB0]
00007f828abd367c  vmovaps xmm13, [rsp+0xC0]
00007f828abd3685  vmovaps xmm14, [rsp+0xD0]
00007f828abd368e  vmovaps xmm15, [rsp+0xE0]
00007f828abd3697  add rsp, 0xF0
00007f828abd369e  pop r11
00007f828abd36a0  pop r10
00007f828abd36a2  pop r9
00007f828abd36a4  pop r8
00007f828abd36a6  pop rsi
00007f828abd36a7  pop rdi
00007f828abd36a8  pop rdx
00007f828abd36a9  pop rcx
00007f828abd36aa  pop rax
00007f828abd36ab  add rsp, 0x08
00007f828abd36af  jmp 0x00007F828ABCFF19
00007f828abd36b4  sub rsp, 0x08
00007f828abd36b8  push rax
00007f828abd36b9  push rcx
00007f828abd36ba  push rdx
00007f828abd36bb  push rdi
00007f828abd36bc  push rsi
00007f828abd36bd  push r8
00007f828abd36bf  push r9
00007f828abd36c1  push r10
00007f828abd36c3  push r11
00007f828abd36c5  sub rsp, 0xF0
00007f828abd36cc  vmovaps [rsp], xmm0
00007f828abd36d1  vmovaps [rsp+0x10], xmm1
00007f828abd36d7  vmovaps [rsp+0x20], xmm2
00007f828abd36dd  vmovaps [rsp+0x30], xmm3
00007f828abd36e3  vmovaps [rsp+0x40], xmm4
00007f828abd36e9  vmovaps [rsp+0x50], xmm5
00007f828abd36ef  vmovaps [rsp+0x60], xmm6
00007f828abd36f5  vmovaps [rsp+0x70], xmm7
00007f828abd36fb  vmovaps [rsp+0x80], xmm8
00007f828abd3704  vmovaps [rsp+0x90], xmm9
00007f828abd370d  vmovaps [rsp+0xA0], xmm10
00007f828abd3716  vmovaps [rsp+0xB0], xmm11
00007f828abd371f  vmovaps [rsp+0xC0], xmm13
00007f828abd3728  vmovaps [rsp+0xD0], xmm14
00007f828abd3731  vmovaps [rsp+0xE0], xmm15
00007f828abd373a  sub rsp, 0x30
00007f828abd373e  movaps [rsp], xmm12
00007f828abd3743  movaps [rsp+0x10], xmm15
00007f828abd3749  movaps [rsp+0x20], xmm13
00007f828abd374f  lea rdi, [rsp]
00007f828abd3753  mov esi, 0x00
00007f828abd3758  mov rax, 0x5BFE27FA6530
00007f828abd3762  call rax
00007f828abd3764  movaps xmm12, [rsp]
00007f828abd3769  add rsp, 0x30
00007f828abd376d  vmovaps xmm0, [rsp]
00007f828abd3772  vmovaps xmm1, [rsp+0x10]
00007f828abd3778  vmovaps xmm2, [rsp+0x20]
00007f828abd377e  vmovaps xmm3, [rsp+0x30]
00007f828abd3784  vmovaps xmm4, [rsp+0x40]
00007f828abd378a  vmovaps xmm5, [rsp+0x50]
00007f828abd3790  vmovaps xmm6, [rsp+0x60]
00007f828abd3796  vmovaps xmm7, [rsp+0x70]
00007f828abd379c  vmovaps xmm8, [rsp+0x80]
00007f828abd37a5  vmovaps xmm9, [rsp+0x90]
00007f828abd37ae  vmovaps xmm10, [rsp+0xA0]
00007f828abd37b7  vmovaps xmm11, [rsp+0xB0]
00007f828abd37c0  vmovaps xmm13, [rsp+0xC0]
00007f828abd37c9  vmovaps xmm14, [rsp+0xD0]
00007f828abd37d2  vmovaps xmm15, [rsp+0xE0]
00007f828abd37db  add rsp, 0xF0
00007f828abd37e2  pop r11
00007f828abd37e4  pop r10
00007f828abd37e6  pop r9
00007f828abd37e8  pop r8
00007f828abd37ea  pop rsi
00007f828abd37eb  pop rdi
00007f828abd37ec  pop rdx
00007f828abd37ed  pop rcx
00007f828abd37ee  pop rax
00007f828abd37ef  add rsp, 0x08
00007f828abd37f3  jmp 0x00007F828ABCFF34
00007f828abd37f8  sub rsp, 0x08
00007f828abd37fc  push rax
00007f828abd37fd  push rcx
00007f828abd37fe  push rdx
00007f828abd37ff  push rdi
00007f828abd3800  push rsi
00007f828abd3801  push r8
00007f828abd3803  push r9
00007f828abd3805  push r10
00007f828abd3807  push r11
00007f828abd3809  sub rsp, 0xF0
00007f828abd3810  vmovaps [rsp], xmm0
00007f828abd3815  vmovaps [rsp+0x10], xmm1
00007f828abd381b  vmovaps [rsp+0x20], xmm2
00007f828abd3821  vmovaps [rsp+0x30], xmm3
00007f828abd3827  vmovaps [rsp+0x40], xmm4
00007f828abd382d  vmovaps [rsp+0x50], xmm5
00007f828abd3833  vmovaps [rsp+0x60], xmm6
00007f828abd3839  vmovaps [rsp+0x70], xmm7
00007f828abd383f  vmovaps [rsp+0x80], xmm8
00007f828abd3848  vmovaps [rsp+0x90], xmm9
00007f828abd3851  vmovaps [rsp+0xA0], xmm10
00007f828abd385a  vmovaps [rsp+0xB0], xmm11
00007f828abd3863  vmovaps [rsp+0xC0], xmm12
00007f828abd386c  vmovaps [rsp+0xD0], xmm13
00007f828abd3875  vmovaps [rsp+0xE0], xmm14
00007f828abd387e  sub rsp, 0x30
00007f828abd3882  movaps [rsp], xmm15
00007f828abd3887  movaps [rsp+0x10], xmm13
00007f828abd388d  movaps [rsp+0x20], xmm10
00007f828abd3893  lea rdi, [rsp]
00007f828abd3897  mov esi, 0x00
00007f828abd389c  mov rax, 0x5BFE27FA6530
00007f828abd38a6  call rax
00007f828abd38a8  movaps xmm15, [rsp]
00007f828abd38ad  add rsp, 0x30
00007f828abd38b1  vmovaps xmm0, [rsp]
00007f828abd38b6  vmovaps xmm1, [rsp+0x10]
00007f828abd38bc  vmovaps xmm2, [rsp+0x20]
00007f828abd38c2  vmovaps xmm3, [rsp+0x30]
00007f828abd38c8  vmovaps xmm4, [rsp+0x40]
00007f828abd38ce  vmovaps xmm5, [rsp+0x50]
00007f828abd38d4  vmovaps xmm6, [rsp+0x60]
00007f828abd38da  vmovaps xmm7, [rsp+0x70]
00007f828abd38e0  vmovaps xmm8, [rsp+0x80]
00007f828abd38e9  vmovaps xmm9, [rsp+0x90]
00007f828abd38f2  vmovaps xmm10, [rsp+0xA0]
00007f828abd38fb  vmovaps xmm11, [rsp+0xB0]
00007f828abd3904  vmovaps xmm12, [rsp+0xC0]
00007f828abd390d  vmovaps xmm13, [rsp+0xD0]
00007f828abd3916  vmovaps xmm14, [rsp+0xE0]
00007f828abd391f  add rsp, 0xF0
00007f828abd3926  pop r11
00007f828abd3928  pop r10
00007f828abd392a  pop r9
00007f828abd392c  pop r8
00007f828abd392e  pop rsi
00007f828abd392f  pop rdi
00007f828abd3930  pop rdx
00007f828abd3931  pop rcx
00007f828abd3932  pop rax
00007f828abd3933  add rsp, 0x08
00007f828abd3937  jmp 0x00007F828ABCFF55
00007f828abd393c  call 0x00007F828AA0C260
00007f828abd3941  jmp 0x00007F828ABCFFB0
00007f828abd3946  sub rsp, 0x08
00007f828abd394a  push rax
00007f828abd394b  push rcx
00007f828abd394c  push rdx
00007f828abd394d  push rdi
00007f828abd394e  push rsi
00007f828abd394f  push r8
00007f828abd3951  push r9
00007f828abd3953  push r10
00007f828abd3955  push r11
00007f828abd3957  sub rsp, 0xF0
00007f828abd395e  vmovaps [rsp], xmm0
00007f828abd3963  vmovaps [rsp+0x10], xmm1
00007f828abd3969  vmovaps [rsp+0x20], xmm2
00007f828abd396f  vmovaps [rsp+0x30], xmm3
00007f828abd3975  vmovaps [rsp+0x40], xmm4
00007f828abd397b  vmovaps [rsp+0x50], xmm5
00007f828abd3981  vmovaps [rsp+0x60], xmm6
00007f828abd3987  vmovaps [rsp+0x70], xmm7
00007f828abd398d  vmovaps [rsp+0x80], xmm8
00007f828abd3996  vmovaps [rsp+0x90], xmm10
00007f828abd399f  vmovaps [rsp+0xA0], xmm11
00007f828abd39a8  vmovaps [rsp+0xB0], xmm12
00007f828abd39b1  vmovaps [rsp+0xC0], xmm13
00007f828abd39ba  vmovaps [rsp+0xD0], xmm14
00007f828abd39c3  vmovaps [rsp+0xE0], xmm15
00007f828abd39cc  sub rsp, 0x30
00007f828abd39d0  movaps [rsp], xmm9
00007f828abd39d5  movaps [rsp+0x10], xmm8
00007f828abd39db  movaps [rsp+0x20], xmm10
00007f828abd39e1  lea rdi, [rsp]
00007f828abd39e5  mov esi, 0x00
00007f828abd39ea  mov rax, 0x5BFE27FA6530
00007f828abd39f4  call rax
00007f828abd39f6  movaps xmm9, [rsp]
00007f828abd39fb  add rsp, 0x30
00007f828abd39ff  vmovaps xmm0, [rsp]
00007f828abd3a04  vmovaps xmm1, [rsp+0x10]
00007f828abd3a0a  vmovaps xmm2, [rsp+0x20]
00007f828abd3a10  vmovaps xmm3, [rsp+0x30]
00007f828abd3a16  vmovaps xmm4, [rsp+0x40]
00007f828abd3a1c  vmovaps xmm5, [rsp+0x50]
00007f828abd3a22  vmovaps xmm6, [rsp+0x60]
00007f828abd3a28  vmovaps xmm7, [rsp+0x70]
00007f828abd3a2e  vmovaps xmm8, [rsp+0x80]
00007f828abd3a37  vmovaps xmm10, [rsp+0x90]
00007f828abd3a40  vmovaps xmm11, [rsp+0xA0]
00007f828abd3a49  vmovaps xmm12, [rsp+0xB0]
00007f828abd3a52  vmovaps xmm13, [rsp+0xC0]
00007f828abd3a5b  vmovaps xmm14, [rsp+0xD0]
00007f828abd3a64  vmovaps xmm15, [rsp+0xE0]
00007f828abd3a6d  add rsp, 0xF0
00007f828abd3a74  pop r11
00007f828abd3a76  pop r10
00007f828abd3a78  pop r9
00007f828abd3a7a  pop r8
00007f828abd3a7c  pop rsi
00007f828abd3a7d  pop rdi
00007f828abd3a7e  pop rdx
00007f828abd3a7f  pop rcx
00007f828abd3a80  pop rax
00007f828abd3a81  add rsp, 0x08
00007f828abd3a85  jmp 0x00007F828ABCFFE1
00007f828abd3a8a  sub rsp, 0x08
00007f828abd3a8e  push rax
00007f828abd3a8f  push rcx
00007f828abd3a90  push rdx
00007f828abd3a91  push rdi
00007f828abd3a92  push rsi
00007f828abd3a93  push r8
00007f828abd3a95  push r9
00007f828abd3a97  push r10
00007f828abd3a99  push r11
00007f828abd3a9b  sub rsp, 0xF0
00007f828abd3aa2  vmovaps [rsp], xmm0
00007f828abd3aa7  vmovaps [rsp+0x10], xmm1
00007f828abd3aad  vmovaps [rsp+0x20], xmm2
00007f828abd3ab3  vmovaps [rsp+0x30], xmm3
00007f828abd3ab9  vmovaps [rsp+0x40], xmm4
00007f828abd3abf  vmovaps [rsp+0x50], xmm5
00007f828abd3ac5  vmovaps [rsp+0x60], xmm6
00007f828abd3acb  vmovaps [rsp+0x70], xmm7
00007f828abd3ad1  vmovaps [rsp+0x80], xmm8
00007f828abd3ada  vmovaps [rsp+0x90], xmm9
00007f828abd3ae3  vmovaps [rsp+0xA0], xmm11
00007f828abd3aec  vmovaps [rsp+0xB0], xmm12
00007f828abd3af5  vmovaps [rsp+0xC0], xmm13
00007f828abd3afe  vmovaps [rsp+0xD0], xmm14
00007f828abd3b07  vmovaps [rsp+0xE0], xmm15
00007f828abd3b10  sub rsp, 0x30
00007f828abd3b14  movaps [rsp], xmm10
00007f828abd3b19  movaps [rsp+0x10], xmm1
00007f828abd3b1e  movaps [rsp+0x20], xmm11
00007f828abd3b24  lea rdi, [rsp]
00007f828abd3b28  mov esi, 0x00
00007f828abd3b2d  mov rax, 0x5BFE27FA6530
00007f828abd3b37  call rax
00007f828abd3b39  movaps xmm10, [rsp]
00007f828abd3b3e  add rsp, 0x30
00007f828abd3b42  vmovaps xmm0, [rsp]
00007f828abd3b47  vmovaps xmm1, [rsp+0x10]
00007f828abd3b4d  vmovaps xmm2, [rsp+0x20]
00007f828abd3b53  vmovaps xmm3, [rsp+0x30]
00007f828abd3b59  vmovaps xmm4, [rsp+0x40]
00007f828abd3b5f  vmovaps xmm5, [rsp+0x50]
00007f828abd3b65  vmovaps xmm6, [rsp+0x60]
00007f828abd3b6b  vmovaps xmm7, [rsp+0x70]
00007f828abd3b71  vmovaps xmm8, [rsp+0x80]
00007f828abd3b7a  vmovaps xmm9, [rsp+0x90]
00007f828abd3b83  vmovaps xmm11, [rsp+0xA0]
00007f828abd3b8c  vmovaps xmm12, [rsp+0xB0]
00007f828abd3b95  vmovaps xmm13, [rsp+0xC0]
00007f828abd3b9e  vmovaps xmm14, [rsp+0xD0]
00007f828abd3ba7  vmovaps xmm15, [rsp+0xE0]
00007f828abd3bb0  add rsp, 0xF0
00007f828abd3bb7  pop r11
00007f828abd3bb9  pop r10
00007f828abd3bbb  pop r9
00007f828abd3bbd  pop r8
00007f828abd3bbf  pop rsi
00007f828abd3bc0  pop rdi
00007f828abd3bc1  pop rdx
00007f828abd3bc2  pop rcx
00007f828abd3bc3  pop rax
00007f828abd3bc4  add rsp, 0x08
00007f828abd3bc8  jmp 0x00007F828ABCFFFC
00007f828abd3bcd  sub rsp, 0x08
00007f828abd3bd1  push rax
00007f828abd3bd2  push rcx
00007f828abd3bd3  push rdx
00007f828abd3bd4  push rdi
00007f828abd3bd5  push rsi
00007f828abd3bd6  push r8
00007f828abd3bd8  push r9
00007f828abd3bda  push r10
00007f828abd3bdc  push r11
00007f828abd3bde  sub rsp, 0xF0
00007f828abd3be5  vmovaps [rsp], xmm0
00007f828abd3bea  vmovaps [rsp+0x10], xmm2
00007f828abd3bf0  vmovaps [rsp+0x20], xmm3
00007f828abd3bf6  vmovaps [rsp+0x30], xmm4
00007f828abd3bfc  vmovaps [rsp+0x40], xmm5
00007f828abd3c02  vmovaps [rsp+0x50], xmm6
00007f828abd3c08  vmovaps [rsp+0x60], xmm7
00007f828abd3c0e  vmovaps [rsp+0x70], xmm8
00007f828abd3c14  vmovaps [rsp+0x80], xmm9
00007f828abd3c1d  vmovaps [rsp+0x90], xmm10
00007f828abd3c26  vmovaps [rsp+0xA0], xmm11
00007f828abd3c2f  vmovaps [rsp+0xB0], xmm12
00007f828abd3c38  vmovaps [rsp+0xC0], xmm13
00007f828abd3c41  vmovaps [rsp+0xD0], xmm14
00007f828abd3c4a  vmovaps [rsp+0xE0], xmm15
00007f828abd3c53  sub rsp, 0x30
00007f828abd3c57  movaps [rsp], xmm1
00007f828abd3c5b  movaps [rsp+0x10], xmm14
00007f828abd3c61  movaps [rsp+0x20], xmm6
00007f828abd3c66  lea rdi, [rsp]
00007f828abd3c6a  mov esi, 0x00
00007f828abd3c6f  mov rax, 0x5BFE27FA6530
00007f828abd3c79  call rax
00007f828abd3c7b  movaps xmm1, [rsp]
00007f828abd3c7f  add rsp, 0x30
00007f828abd3c83  vmovaps xmm0, [rsp]
00007f828abd3c88  vmovaps xmm2, [rsp+0x10]
00007f828abd3c8e  vmovaps xmm3, [rsp+0x20]
00007f828abd3c94  vmovaps xmm4, [rsp+0x30]
00007f828abd3c9a  vmovaps xmm5, [rsp+0x40]
00007f828abd3ca0  vmovaps xmm6, [rsp+0x50]
00007f828abd3ca6  vmovaps xmm7, [rsp+0x60]
00007f828abd3cac  vmovaps xmm8, [rsp+0x70]
00007f828abd3cb2  vmovaps xmm9, [rsp+0x80]
00007f828abd3cbb  vmovaps xmm10, [rsp+0x90]
00007f828abd3cc4  vmovaps xmm11, [rsp+0xA0]
00007f828abd3ccd  vmovaps xmm12, [rsp+0xB0]
00007f828abd3cd6  vmovaps xmm13, [rsp+0xC0]
00007f828abd3cdf  vmovaps xmm14, [rsp+0xD0]
00007f828abd3ce8  vmovaps xmm15, [rsp+0xE0]
00007f828abd3cf1  add rsp, 0xF0
00007f828abd3cf8  pop r11
00007f828abd3cfa  pop r10
00007f828abd3cfc  pop r9
00007f828abd3cfe  pop r8
00007f828abd3d00  pop rsi
00007f828abd3d01  pop rdi
00007f828abd3d02  pop rdx
00007f828abd3d03  pop rcx
00007f828abd3d04  pop rax
00007f828abd3d05  add rsp, 0x08
00007f828abd3d09  jmp 0x00007F828ABD0015
00007f828abd3d0e  sub rsp, 0x08
00007f828abd3d12  push rax
00007f828abd3d13  push rcx
00007f828abd3d14  push rdx
00007f828abd3d15  push rdi
00007f828abd3d16  push rsi
00007f828abd3d17  push r8
00007f828abd3d19  push r9
00007f828abd3d1b  push r10
00007f828abd3d1d  push r11
00007f828abd3d1f  sub rsp, 0xF0
00007f828abd3d26  vmovaps [rsp], xmm0
00007f828abd3d2b  vmovaps [rsp+0x10], xmm1
00007f828abd3d31  vmovaps [rsp+0x20], xmm2
00007f828abd3d37  vmovaps [rsp+0x30], xmm3
00007f828abd3d3d  vmovaps [rsp+0x40], xmm4
00007f828abd3d43  vmovaps [rsp+0x50], xmm5
00007f828abd3d49  vmovaps [rsp+0x60], xmm6
00007f828abd3d4f  vmovaps [rsp+0x70], xmm7
00007f828abd3d55  vmovaps [rsp+0x80], xmm8
00007f828abd3d5e  vmovaps [rsp+0x90], xmm9
00007f828abd3d67  vmovaps [rsp+0xA0], xmm10
00007f828abd3d70  vmovaps [rsp+0xB0], xmm12
00007f828abd3d79  vmovaps [rsp+0xC0], xmm13
00007f828abd3d82  vmovaps [rsp+0xD0], xmm14
00007f828abd3d8b  vmovaps [rsp+0xE0], xmm15
00007f828abd3d94  sub rsp, 0x30
00007f828abd3d98  movaps [rsp], xmm11
00007f828abd3d9d  movaps [rsp+0x10], xmm13
00007f828abd3da3  movaps [rsp+0x20], xmm14
00007f828abd3da9  lea rdi, [rsp]
00007f828abd3dad  mov esi, 0x00
00007f828abd3db2  mov rax, 0x5BFE27FA6530
00007f828abd3dbc  call rax
00007f828abd3dbe  movaps xmm11, [rsp]
00007f828abd3dc3  add rsp, 0x30
00007f828abd3dc7  vmovaps xmm0, [rsp]
00007f828abd3dcc  vmovaps xmm1, [rsp+0x10]
00007f828abd3dd2  vmovaps xmm2, [rsp+0x20]
00007f828abd3dd8  vmovaps xmm3, [rsp+0x30]
00007f828abd3dde  vmovaps xmm4, [rsp+0x40]
00007f828abd3de4  vmovaps xmm5, [rsp+0x50]
00007f828abd3dea  vmovaps xmm6, [rsp+0x60]
00007f828abd3df0  vmovaps xmm7, [rsp+0x70]
00007f828abd3df6  vmovaps xmm8, [rsp+0x80]
00007f828abd3dff  vmovaps xmm9, [rsp+0x90]
00007f828abd3e08  vmovaps xmm10, [rsp+0xA0]
00007f828abd3e11  vmovaps xmm12, [rsp+0xB0]
00007f828abd3e1a  vmovaps xmm13, [rsp+0xC0]
00007f828abd3e23  vmovaps xmm14, [rsp+0xD0]
00007f828abd3e2c  vmovaps xmm15, [rsp+0xE0]
00007f828abd3e35  add rsp, 0xF0
00007f828abd3e3c  pop r11
00007f828abd3e3e  pop r10
00007f828abd3e40  pop r9
00007f828abd3e42  pop r8
00007f828abd3e44  pop rsi
00007f828abd3e45  pop rdi
00007f828abd3e46  pop rdx
00007f828abd3e47  pop rcx
00007f828abd3e48  pop rax
00007f828abd3e49  add rsp, 0x08
00007f828abd3e4d  jmp 0x00007F828ABD003F
00007f828abd3e52  sub rsp, 0x08
00007f828abd3e56  push rax
00007f828abd3e57  push rcx
00007f828abd3e58  push rdx
00007f828abd3e59  push rdi
00007f828abd3e5a  push rsi
00007f828abd3e5b  push r8
00007f828abd3e5d  push r9
00007f828abd3e5f  push r10
00007f828abd3e61  push r11
00007f828abd3e63  sub rsp, 0xF0
00007f828abd3e6a  vmovaps [rsp], xmm0
00007f828abd3e6f  vmovaps [rsp+0x10], xmm1
00007f828abd3e75  vmovaps [rsp+0x20], xmm2
00007f828abd3e7b  vmovaps [rsp+0x30], xmm3
00007f828abd3e81  vmovaps [rsp+0x40], xmm4
00007f828abd3e87  vmovaps [rsp+0x50], xmm5
00007f828abd3e8d  vmovaps [rsp+0x60], xmm6
00007f828abd3e93  vmovaps [rsp+0x70], xmm7
00007f828abd3e99  vmovaps [rsp+0x80], xmm8
00007f828abd3ea2  vmovaps [rsp+0x90], xmm9
00007f828abd3eab  vmovaps [rsp+0xA0], xmm10
00007f828abd3eb4  vmovaps [rsp+0xB0], xmm11
00007f828abd3ebd  vmovaps [rsp+0xC0], xmm12
00007f828abd3ec6  vmovaps [rsp+0xD0], xmm14
00007f828abd3ecf  vmovaps [rsp+0xE0], xmm15
00007f828abd3ed8  sub rsp, 0x30
00007f828abd3edc  movaps [rsp], xmm13
00007f828abd3ee1  movaps [rsp+0x10], xmm8
00007f828abd3ee7  movaps [rsp+0x20], xmm14
00007f828abd3eed  lea rdi, [rsp]
00007f828abd3ef1  mov esi, 0x00
00007f828abd3ef6  mov rax, 0x5BFE27FA6530
00007f828abd3f00  call rax
00007f828abd3f02  movaps xmm13, [rsp]
00007f828abd3f07  add rsp, 0x30
00007f828abd3f0b  vmovaps xmm0, [rsp]
00007f828abd3f10  vmovaps xmm1, [rsp+0x10]
00007f828abd3f16  vmovaps xmm2, [rsp+0x20]
00007f828abd3f1c  vmovaps xmm3, [rsp+0x30]
00007f828abd3f22  vmovaps xmm4, [rsp+0x40]
00007f828abd3f28  vmovaps xmm5, [rsp+0x50]
00007f828abd3f2e  vmovaps xmm6, [rsp+0x60]
00007f828abd3f34  vmovaps xmm7, [rsp+0x70]
00007f828abd3f3a  vmovaps xmm8, [rsp+0x80]
00007f828abd3f43  vmovaps xmm9, [rsp+0x90]
00007f828abd3f4c  vmovaps xmm10, [rsp+0xA0]
00007f828abd3f55  vmovaps xmm11, [rsp+0xB0]
00007f828abd3f5e  vmovaps xmm12, [rsp+0xC0]
00007f828abd3f67  vmovaps xmm14, [rsp+0xD0]
00007f828abd3f70  vmovaps xmm15, [rsp+0xE0]
00007f828abd3f79  add rsp, 0xF0
00007f828abd3f80  pop r11
00007f828abd3f82  pop r10
00007f828abd3f84  pop r9
00007f828abd3f86  pop r8
00007f828abd3f88  pop rsi
00007f828abd3f89  pop rdi
00007f828abd3f8a  pop rdx
00007f828abd3f8b  pop rcx
00007f828abd3f8c  pop rax
00007f828abd3f8d  add rsp, 0x08
00007f828abd3f91  jmp 0x00007F828ABD006E
00007f828abd3f96  sub rsp, 0x08
00007f828abd3f9a  push rax
00007f828abd3f9b  push rcx
00007f828abd3f9c  push rdx
00007f828abd3f9d  push rdi
00007f828abd3f9e  push rsi
00007f828abd3f9f  push r8
00007f828abd3fa1  push r9
00007f828abd3fa3  push r10
00007f828abd3fa5  push r11
00007f828abd3fa7  sub rsp, 0xF0
00007f828abd3fae  vmovaps [rsp], xmm0
00007f828abd3fb3  vmovaps [rsp+0x10], xmm1
00007f828abd3fb9  vmovaps [rsp+0x20], xmm2
00007f828abd3fbf  vmovaps [rsp+0x30], xmm3
00007f828abd3fc5  vmovaps [rsp+0x40], xmm4
00007f828abd3fcb  vmovaps [rsp+0x50], xmm5
00007f828abd3fd1  vmovaps [rsp+0x60], xmm6
00007f828abd3fd7  vmovaps [rsp+0x70], xmm7
00007f828abd3fdd  vmovaps [rsp+0x80], xmm9
00007f828abd3fe6  vmovaps [rsp+0x90], xmm10
00007f828abd3fef  vmovaps [rsp+0xA0], xmm11
00007f828abd3ff8  vmovaps [rsp+0xB0], xmm12
00007f828abd4001  vmovaps [rsp+0xC0], xmm13
00007f828abd400a  vmovaps [rsp+0xD0], xmm14
00007f828abd4013  vmovaps [rsp+0xE0], xmm15
00007f828abd401c  sub rsp, 0x30
00007f828abd4020  movaps [rsp], xmm8
00007f828abd4025  movaps [rsp+0x10], xmm7
00007f828abd402a  movaps [rsp+0x20], xmm14
00007f828abd4030  lea rdi, [rsp]
00007f828abd4034  mov esi, 0x00
00007f828abd4039  mov rax, 0x5BFE27FA6530
00007f828abd4043  call rax
00007f828abd4045  movaps xmm8, [rsp]
00007f828abd404a  add rsp, 0x30
00007f828abd404e  vmovaps xmm0, [rsp]
00007f828abd4053  vmovaps xmm1, [rsp+0x10]
00007f828abd4059  vmovaps xmm2, [rsp+0x20]
00007f828abd405f  vmovaps xmm3, [rsp+0x30]
00007f828abd4065  vmovaps xmm4, [rsp+0x40]
00007f828abd406b  vmovaps xmm5, [rsp+0x50]
00007f828abd4071  vmovaps xmm6, [rsp+0x60]
00007f828abd4077  vmovaps xmm7, [rsp+0x70]
00007f828abd407d  vmovaps xmm9, [rsp+0x80]
00007f828abd4086  vmovaps xmm10, [rsp+0x90]
00007f828abd408f  vmovaps xmm11, [rsp+0xA0]
00007f828abd4098  vmovaps xmm12, [rsp+0xB0]
00007f828abd40a1  vmovaps xmm13, [rsp+0xC0]
00007f828abd40aa  vmovaps xmm14, [rsp+0xD0]
00007f828abd40b3  vmovaps xmm15, [rsp+0xE0]
00007f828abd40bc  add rsp, 0xF0
00007f828abd40c3  pop r11
00007f828abd40c5  pop r10
00007f828abd40c7  pop r9
00007f828abd40c9  pop r8
00007f828abd40cb  pop rsi
00007f828abd40cc  pop rdi
00007f828abd40cd  pop rdx
00007f828abd40ce  pop rcx
00007f828abd40cf  pop rax
00007f828abd40d0  add rsp, 0x08
00007f828abd40d4  jmp 0x00007F828ABD0094
00007f828abd40d9  sub rsp, 0x08
00007f828abd40dd  push rax
00007f828abd40de  push rcx
00007f828abd40df  push rdx
00007f828abd40e0  push rdi
00007f828abd40e1  push rsi
00007f828abd40e2  push r8
00007f828abd40e4  push r9
00007f828abd40e6  push r10
00007f828abd40e8  push r11
00007f828abd40ea  sub rsp, 0xF0
00007f828abd40f1  vmovaps [rsp], xmm0
00007f828abd40f6  vmovaps [rsp+0x10], xmm1
00007f828abd40fc  vmovaps [rsp+0x20], xmm2
00007f828abd4102  vmovaps [rsp+0x30], xmm3
00007f828abd4108  vmovaps [rsp+0x40], xmm4
00007f828abd410e  vmovaps [rsp+0x50], xmm5
00007f828abd4114  vmovaps [rsp+0x60], xmm6
00007f828abd411a  vmovaps [rsp+0x70], xmm7
00007f828abd4120  vmovaps [rsp+0x80], xmm8
00007f828abd4129  vmovaps [rsp+0x90], xmm9
00007f828abd4132  vmovaps [rsp+0xA0], xmm10
00007f828abd413b  vmovaps [rsp+0xB0], xmm11
00007f828abd4144  vmovaps [rsp+0xC0], xmm12
00007f828abd414d  vmovaps [rsp+0xD0], xmm13
00007f828abd4156  vmovaps [rsp+0xE0], xmm15
00007f828abd415f  sub rsp, 0x30
00007f828abd4163  movaps [rsp], xmm14
00007f828abd4168  movaps [rsp+0x10], xmm12
00007f828abd416e  movaps [rsp+0x20], xmm9
00007f828abd4174  lea rdi, [rsp]
00007f828abd4178  mov esi, 0x00
00007f828abd417d  mov rax, 0x5BFE27FA6530
00007f828abd4187  call rax
00007f828abd4189  movaps xmm14, [rsp]
00007f828abd418e  add rsp, 0x30
00007f828abd4192  vmovaps xmm0, [rsp]
00007f828abd4197  vmovaps xmm1, [rsp+0x10]
00007f828abd419d  vmovaps xmm2, [rsp+0x20]
00007f828abd41a3  vmovaps xmm3, [rsp+0x30]
00007f828abd41a9  vmovaps xmm4, [rsp+0x40]
00007f828abd41af  vmovaps xmm5, [rsp+0x50]
00007f828abd41b5  vmovaps xmm6, [rsp+0x60]
00007f828abd41bb  vmovaps xmm7, [rsp+0x70]
00007f828abd41c1  vmovaps xmm8, [rsp+0x80]
00007f828abd41ca  vmovaps xmm9, [rsp+0x90]
00007f828abd41d3  vmovaps xmm10, [rsp+0xA0]
00007f828abd41dc  vmovaps xmm11, [rsp+0xB0]
00007f828abd41e5  vmovaps xmm12, [rsp+0xC0]
00007f828abd41ee  vmovaps xmm13, [rsp+0xD0]
00007f828abd41f7  vmovaps xmm15, [rsp+0xE0]
00007f828abd4200  add rsp, 0xF0
00007f828abd4207  pop r11
00007f828abd4209  pop r10
00007f828abd420b  pop r9
00007f828abd420d  pop r8
00007f828abd420f  pop rsi
00007f828abd4210  pop rdi
00007f828abd4211  pop rdx
00007f828abd4212  pop rcx
00007f828abd4213  pop rax
00007f828abd4214  add rsp, 0x08
00007f828abd4218  jmp 0x00007F828ABD00AE
00007f828abd421d  sub rsp, 0x08
00007f828abd4221  push rax
00007f828abd4222  push rcx
00007f828abd4223  push rdx
00007f828abd4224  push rdi
00007f828abd4225  push rsi
00007f828abd4226  push r8
00007f828abd4228  push r9
00007f828abd422a  push r10
00007f828abd422c  push r11
00007f828abd422e  sub rsp, 0xF0
00007f828abd4235  vmovaps [rsp], xmm0
00007f828abd423a  vmovaps [rsp+0x10], xmm1
00007f828abd4240  vmovaps [rsp+0x20], xmm2
00007f828abd4246  vmovaps [rsp+0x30], xmm3
00007f828abd424c  vmovaps [rsp+0x40], xmm4
00007f828abd4252  vmovaps [rsp+0x50], xmm5
00007f828abd4258  vmovaps [rsp+0x60], xmm6
00007f828abd425e  vmovaps [rsp+0x70], xmm7
00007f828abd4264  vmovaps [rsp+0x80], xmm8
00007f828abd426d  vmovaps [rsp+0x90], xmm10
00007f828abd4276  vmovaps [rsp+0xA0], xmm11
00007f828abd427f  vmovaps [rsp+0xB0], xmm12
00007f828abd4288  vmovaps [rsp+0xC0], xmm13
00007f828abd4291  vmovaps [rsp+0xD0], xmm14
00007f828abd429a  vmovaps [rsp+0xE0], xmm15
00007f828abd42a3  sub rsp, 0x30
00007f828abd42a7  movaps [rsp], xmm9
00007f828abd42ac  movaps [rsp+0x10], xmm7
00007f828abd42b1  movaps [rsp+0x20], xmm12
00007f828abd42b7  lea rdi, [rsp]
00007f828abd42bb  mov esi, 0x00
00007f828abd42c0  mov rax, 0x5BFE27FA6530
00007f828abd42ca  call rax
00007f828abd42cc  movaps xmm9, [rsp]
00007f828abd42d1  add rsp, 0x30
00007f828abd42d5  vmovaps xmm0, [rsp]
00007f828abd42da  vmovaps xmm1, [rsp+0x10]
00007f828abd42e0  vmovaps xmm2, [rsp+0x20]
00007f828abd42e6  vmovaps xmm3, [rsp+0x30]
00007f828abd42ec  vmovaps xmm4, [rsp+0x40]
00007f828abd42f2  vmovaps xmm5, [rsp+0x50]
00007f828abd42f8  vmovaps xmm6, [rsp+0x60]
00007f828abd42fe  vmovaps xmm7, [rsp+0x70]
00007f828abd4304  vmovaps xmm8, [rsp+0x80]
00007f828abd430d  vmovaps xmm10, [rsp+0x90]
00007f828abd4316  vmovaps xmm11, [rsp+0xA0]
00007f828abd431f  vmovaps xmm12, [rsp+0xB0]
00007f828abd4328  vmovaps xmm13, [rsp+0xC0]
00007f828abd4331  vmovaps xmm14, [rsp+0xD0]
00007f828abd433a  vmovaps xmm15, [rsp+0xE0]
00007f828abd4343  add rsp, 0xF0
00007f828abd434a  pop r11
00007f828abd434c  pop r10
00007f828abd434e  pop r9
00007f828abd4350  pop r8
00007f828abd4352  pop rsi
00007f828abd4353  pop rdi
00007f828abd4354  pop rdx
00007f828abd4355  pop rcx
00007f828abd4356  pop rax
00007f828abd4357  add rsp, 0x08
00007f828abd435b  jmp 0x00007F828ABD00DD
00007f828abd4360  sub rsp, 0x08
00007f828abd4364  push rax
00007f828abd4365  push rcx
00007f828abd4366  push rdx
00007f828abd4367  push rdi
00007f828abd4368  push rsi
00007f828abd4369  push r8
00007f828abd436b  push r9
00007f828abd436d  push r10
00007f828abd436f  push r11
00007f828abd4371  sub rsp, 0xF0
00007f828abd4378  vmovaps [rsp], xmm0
00007f828abd437d  vmovaps [rsp+0x10], xmm1
00007f828abd4383  vmovaps [rsp+0x20], xmm2
00007f828abd4389  vmovaps [rsp+0x30], xmm3
00007f828abd438f  vmovaps [rsp+0x40], xmm4
00007f828abd4395  vmovaps [rsp+0x50], xmm5
00007f828abd439b  vmovaps [rsp+0x60], xmm6
00007f828abd43a1  vmovaps [rsp+0x70], xmm7
00007f828abd43a7  vmovaps [rsp+0x80], xmm8
00007f828abd43b0  vmovaps [rsp+0x90], xmm9
00007f828abd43b9  vmovaps [rsp+0xA0], xmm10
00007f828abd43c2  vmovaps [rsp+0xB0], xmm11
00007f828abd43cb  vmovaps [rsp+0xC0], xmm13
00007f828abd43d4  vmovaps [rsp+0xD0], xmm14
00007f828abd43dd  vmovaps [rsp+0xE0], xmm15
00007f828abd43e6  sub rsp, 0x30
00007f828abd43ea  movaps [rsp], xmm12
00007f828abd43ef  movaps [rsp+0x10], xmm15
00007f828abd43f5  movaps [rsp+0x20], xmm11
00007f828abd43fb  lea rdi, [rsp]
00007f828abd43ff  mov esi, 0x00
00007f828abd4404  mov rax, 0x5BFE27FA6530
00007f828abd440e  call rax
00007f828abd4410  movaps xmm12, [rsp]
00007f828abd4415  add rsp, 0x30
00007f828abd4419  vmovaps xmm0, [rsp]
00007f828abd441e  vmovaps xmm1, [rsp+0x10]
00007f828abd4424  vmovaps xmm2, [rsp+0x20]
00007f828abd442a  vmovaps xmm3, [rsp+0x30]
00007f828abd4430  vmovaps xmm4, [rsp+0x40]
00007f828abd4436  vmovaps xmm5, [rsp+0x50]
00007f828abd443c  vmovaps xmm6, [rsp+0x60]
00007f828abd4442  vmovaps xmm7, [rsp+0x70]
00007f828abd4448  vmovaps xmm8, [rsp+0x80]
00007f828abd4451  vmovaps xmm9, [rsp+0x90]
00007f828abd445a  vmovaps xmm10, [rsp+0xA0]
00007f828abd4463  vmovaps xmm11, [rsp+0xB0]
00007f828abd446c  vmovaps xmm13, [rsp+0xC0]
00007f828abd4475  vmovaps xmm14, [rsp+0xD0]
00007f828abd447e  vmovaps xmm15, [rsp+0xE0]
00007f828abd4487  add rsp, 0xF0
00007f828abd448e  pop r11
00007f828abd4490  pop r10
00007f828abd4492  pop r9
00007f828abd4494  pop r8
00007f828abd4496  pop rsi
00007f828abd4497  pop rdi
00007f828abd4498  pop rdx
00007f828abd4499  pop rcx
00007f828abd449a  pop rax
00007f828abd449b  add rsp, 0x08
00007f828abd449f  jmp 0x00007F828ABD00F7
00007f828abd44a4  sub rsp, 0x08
00007f828abd44a8  push rax
00007f828abd44a9  push rcx
00007f828abd44aa  push rdx
00007f828abd44ab  push rdi
00007f828abd44ac  push rsi
00007f828abd44ad  push r8
00007f828abd44af  push r9
00007f828abd44b1  push r10
00007f828abd44b3  push r11
00007f828abd44b5  sub rsp, 0xF0
00007f828abd44bc  vmovaps [rsp], xmm0
00007f828abd44c1  vmovaps [rsp+0x10], xmm1
00007f828abd44c7  vmovaps [rsp+0x20], xmm2
00007f828abd44cd  vmovaps [rsp+0x30], xmm3
00007f828abd44d3  vmovaps [rsp+0x40], xmm4
00007f828abd44d9  vmovaps [rsp+0x50], xmm5
00007f828abd44df  vmovaps [rsp+0x60], xmm6
00007f828abd44e5  vmovaps [rsp+0x70], xmm7
00007f828abd44eb  vmovaps [rsp+0x80], xmm8
00007f828abd44f4  vmovaps [rsp+0x90], xmm9
00007f828abd44fd  vmovaps [rsp+0xA0], xmm10
00007f828abd4506  vmovaps [rsp+0xB0], xmm12
00007f828abd450f  vmovaps [rsp+0xC0], xmm13
00007f828abd4518  vmovaps [rsp+0xD0], xmm14
00007f828abd4521  vmovaps [rsp+0xE0], xmm15
00007f828abd452a  sub rsp, 0x30
00007f828abd452e  movaps [rsp], xmm11
00007f828abd4533  movaps [rsp+0x10], xmm7
00007f828abd4538  movaps [rsp+0x20], xmm15
00007f828abd453e  lea rdi, [rsp]
00007f828abd4542  mov esi, 0x00
00007f828abd4547  mov rax, 0x5BFE27FA6530
00007f828abd4551  call rax
00007f828abd4553  movaps xmm11, [rsp]
00007f828abd4558  add rsp, 0x30
00007f828abd455c  vmovaps xmm0, [rsp]
00007f828abd4561  vmovaps xmm1, [rsp+0x10]
00007f828abd4567  vmovaps xmm2, [rsp+0x20]
00007f828abd456d  vmovaps xmm3, [rsp+0x30]
00007f828abd4573  vmovaps xmm4, [rsp+0x40]
00007f828abd4579  vmovaps xmm5, [rsp+0x50]
00007f828abd457f  vmovaps xmm6, [rsp+0x60]
00007f828abd4585  vmovaps xmm7, [rsp+0x70]
00007f828abd458b  vmovaps xmm8, [rsp+0x80]
00007f828abd4594  vmovaps xmm9, [rsp+0x90]
00007f828abd459d  vmovaps xmm10, [rsp+0xA0]
00007f828abd45a6  vmovaps xmm12, [rsp+0xB0]
00007f828abd45af  vmovaps xmm13, [rsp+0xC0]
00007f828abd45b8  vmovaps xmm14, [rsp+0xD0]
00007f828abd45c1  vmovaps xmm15, [rsp+0xE0]
00007f828abd45ca  add rsp, 0xF0
00007f828abd45d1  pop r11
00007f828abd45d3  pop r10
00007f828abd45d5  pop r9
00007f828abd45d7  pop r8
00007f828abd45d9  pop rsi
00007f828abd45da  pop rdi
00007f828abd45db  pop rdx
00007f828abd45dc  pop rcx
00007f828abd45dd  pop rax
00007f828abd45de  add rsp, 0x08
00007f828abd45e2  jmp 0x00007F828ABD0123
00007f828abd45e7  sub rsp, 0x08
00007f828abd45eb  push rax
00007f828abd45ec  push rcx
00007f828abd45ed  push rdx
00007f828abd45ee  push rdi
00007f828abd45ef  push rsi
00007f828abd45f0  push r8
00007f828abd45f2  push r9
00007f828abd45f4  push r10
00007f828abd45f6  push r11
00007f828abd45f8  sub rsp, 0xF0
00007f828abd45ff  vmovaps [rsp], xmm0
00007f828abd4604  vmovaps [rsp+0x10], xmm1
00007f828abd460a  vmovaps [rsp+0x20], xmm2
00007f828abd4610  vmovaps [rsp+0x30], xmm3
00007f828abd4616  vmovaps [rsp+0x40], xmm4
00007f828abd461c  vmovaps [rsp+0x50], xmm5
00007f828abd4622  vmovaps [rsp+0x60], xmm6
00007f828abd4628  vmovaps [rsp+0x70], xmm7
00007f828abd462e  vmovaps [rsp+0x80], xmm8
00007f828abd4637  vmovaps [rsp+0x90], xmm9
00007f828abd4640  vmovaps [rsp+0xA0], xmm10
00007f828abd4649  vmovaps [rsp+0xB0], xmm11
00007f828abd4652  vmovaps [rsp+0xC0], xmm12
00007f828abd465b  vmovaps [rsp+0xD0], xmm13
00007f828abd4664  vmovaps [rsp+0xE0], xmm14
00007f828abd466d  sub rsp, 0x30
00007f828abd4671  movaps [rsp], xmm15
00007f828abd4676  movaps [rsp+0x10], xmm10
00007f828abd467c  movaps [rsp+0x20], xmm13
00007f828abd4682  lea rdi, [rsp]
00007f828abd4686  mov esi, 0x00
00007f828abd468b  mov rax, 0x5BFE27FA6530
00007f828abd4695  call rax
00007f828abd4697  movaps xmm15, [rsp]
00007f828abd469c  add rsp, 0x30
00007f828abd46a0  vmovaps xmm0, [rsp]
00007f828abd46a5  vmovaps xmm1, [rsp+0x10]
00007f828abd46ab  vmovaps xmm2, [rsp+0x20]
00007f828abd46b1  vmovaps xmm3, [rsp+0x30]
00007f828abd46b7  vmovaps xmm4, [rsp+0x40]
00007f828abd46bd  vmovaps xmm5, [rsp+0x50]
00007f828abd46c3  vmovaps xmm6, [rsp+0x60]
00007f828abd46c9  vmovaps xmm7, [rsp+0x70]
00007f828abd46cf  vmovaps xmm8, [rsp+0x80]
00007f828abd46d8  vmovaps xmm9, [rsp+0x90]
00007f828abd46e1  vmovaps xmm10, [rsp+0xA0]
00007f828abd46ea  vmovaps xmm11, [rsp+0xB0]
00007f828abd46f3  vmovaps xmm12, [rsp+0xC0]
00007f828abd46fc  vmovaps xmm13, [rsp+0xD0]
00007f828abd4705  vmovaps xmm14, [rsp+0xE0]
00007f828abd470e  add rsp, 0xF0
00007f828abd4715  pop r11
00007f828abd4717  pop r10
00007f828abd4719  pop r9
00007f828abd471b  pop r8
00007f828abd471d  pop rsi
00007f828abd471e  pop rdi
00007f828abd471f  pop rdx
00007f828abd4720  pop rcx
00007f828abd4721  pop rax
00007f828abd4722  add rsp, 0x08
00007f828abd4726  jmp 0x00007F828ABD013D
00007f828abd472b  sub rsp, 0x08
00007f828abd472f  push rax
00007f828abd4730  push rcx
00007f828abd4731  push rdx
00007f828abd4732  push rdi
00007f828abd4733  push rsi
00007f828abd4734  push r8
00007f828abd4736  push r9
00007f828abd4738  push r10
00007f828abd473a  push r11
00007f828abd473c  sub rsp, 0xF0
00007f828abd4743  vmovaps [rsp], xmm0
00007f828abd4748  vmovaps [rsp+0x10], xmm1
00007f828abd474e  vmovaps [rsp+0x20], xmm2
00007f828abd4754  vmovaps [rsp+0x30], xmm3
00007f828abd475a  vmovaps [rsp+0x40], xmm4
00007f828abd4760  vmovaps [rsp+0x50], xmm5
00007f828abd4766  vmovaps [rsp+0x60], xmm6
00007f828abd476c  vmovaps [rsp+0x70], xmm7
00007f828abd4772  vmovaps [rsp+0x80], xmm8
00007f828abd477b  vmovaps [rsp+0x90], xmm9
00007f828abd4784  vmovaps [rsp+0xA0], xmm11
00007f828abd478d  vmovaps [rsp+0xB0], xmm12
00007f828abd4796  vmovaps [rsp+0xC0], xmm13
00007f828abd479f  vmovaps [rsp+0xD0], xmm14
00007f828abd47a8  vmovaps [rsp+0xE0], xmm15
00007f828abd47b1  sub rsp, 0x30
00007f828abd47b5  movaps [rsp], xmm10
00007f828abd47ba  movaps [rsp+0x10], xmm7
00007f828abd47bf  movaps [rsp+0x20], xmm13
00007f828abd47c5  lea rdi, [rsp]
00007f828abd47c9  mov esi, 0x00
00007f828abd47ce  mov rax, 0x5BFE27FA6530
00007f828abd47d8  call rax
00007f828abd47da  movaps xmm10, [rsp]
00007f828abd47df  add rsp, 0x30
00007f828abd47e3  vmovaps xmm0, [rsp]
00007f828abd47e8  vmovaps xmm1, [rsp+0x10]
00007f828abd47ee  vmovaps xmm2, [rsp+0x20]
00007f828abd47f4  vmovaps xmm3, [rsp+0x30]
00007f828abd47fa  vmovaps xmm4, [rsp+0x40]
00007f828abd4800  vmovaps xmm5, [rsp+0x50]
00007f828abd4806  vmovaps xmm6, [rsp+0x60]
00007f828abd480c  vmovaps xmm7, [rsp+0x70]
00007f828abd4812  vmovaps xmm8, [rsp+0x80]
00007f828abd481b  vmovaps xmm9, [rsp+0x90]
00007f828abd4824  vmovaps xmm11, [rsp+0xA0]
00007f828abd482d  vmovaps xmm12, [rsp+0xB0]
00007f828abd4836  vmovaps xmm13, [rsp+0xC0]
00007f828abd483f  vmovaps xmm14, [rsp+0xD0]
00007f828abd4848  vmovaps xmm15, [rsp+0xE0]
00007f828abd4851  add rsp, 0xF0
00007f828abd4858  pop r11
00007f828abd485a  pop r10
00007f828abd485c  pop r9
00007f828abd485e  pop r8
00007f828abd4860  pop rsi
00007f828abd4861  pop rdi
00007f828abd4862  pop rdx
00007f828abd4863  pop rcx
00007f828abd4864  pop rax
00007f828abd4865  add rsp, 0x08
00007f828abd4869  jmp 0x00007F828ABD0169
00007f828abd486e  sub rsp, 0x08
00007f828abd4872  push rax
00007f828abd4873  push rcx
00007f828abd4874  push rdx
00007f828abd4875  push rdi
00007f828abd4876  push rsi
00007f828abd4877  push r8
00007f828abd4879  push r9
00007f828abd487b  push r10
00007f828abd487d  push r11
00007f828abd487f  sub rsp, 0xF0
00007f828abd4886  vmovaps [rsp], xmm0
00007f828abd488b  vmovaps [rsp+0x10], xmm1
00007f828abd4891  vmovaps [rsp+0x20], xmm2
00007f828abd4897  vmovaps [rsp+0x30], xmm3
00007f828abd489d  vmovaps [rsp+0x40], xmm4
00007f828abd48a3  vmovaps [rsp+0x50], xmm5
00007f828abd48a9  vmovaps [rsp+0x60], xmm6
00007f828abd48af  vmovaps [rsp+0x70], xmm7
00007f828abd48b5  vmovaps [rsp+0x80], xmm8
00007f828abd48be  vmovaps [rsp+0x90], xmm9
00007f828abd48c7  vmovaps [rsp+0xA0], xmm10
00007f828abd48d0  vmovaps [rsp+0xB0], xmm11
00007f828abd48d9  vmovaps [rsp+0xC0], xmm12
00007f828abd48e2  vmovaps [rsp+0xD0], xmm14
00007f828abd48eb  vmovaps [rsp+0xE0], xmm15
00007f828abd48f4  sub rsp, 0x30
00007f828abd48f8  movaps [rsp], xmm13
00007f828abd48fd  movaps [rsp+0x10], xmm1
00007f828abd4902  movaps [rsp+0x20], xmm8
00007f828abd4908  lea rdi, [rsp]
00007f828abd490c  mov esi, 0x00
00007f828abd4911  mov rax, 0x5BFE27FA6530
00007f828abd491b  call rax
00007f828abd491d  movaps xmm13, [rsp]
00007f828abd4922  add rsp, 0x30
00007f828abd4926  vmovaps xmm0, [rsp]
00007f828abd492b  vmovaps xmm1, [rsp+0x10]
00007f828abd4931  vmovaps xmm2, [rsp+0x20]
00007f828abd4937  vmovaps xmm3, [rsp+0x30]
00007f828abd493d  vmovaps xmm4, [rsp+0x40]
00007f828abd4943  vmovaps xmm5, [rsp+0x50]
00007f828abd4949  vmovaps xmm6, [rsp+0x60]
00007f828abd494f  vmovaps xmm7, [rsp+0x70]
00007f828abd4955  vmovaps xmm8, [rsp+0x80]
00007f828abd495e  vmovaps xmm9, [rsp+0x90]
00007f828abd4967  vmovaps xmm10, [rsp+0xA0]
00007f828abd4970  vmovaps xmm11, [rsp+0xB0]
00007f828abd4979  vmovaps xmm12, [rsp+0xC0]
00007f828abd4982  vmovaps xmm14, [rsp+0xD0]
00007f828abd498b  vmovaps xmm15, [rsp+0xE0]
00007f828abd4994  add rsp, 0xF0
00007f828abd499b  pop r11
00007f828abd499d  pop r10
00007f828abd499f  pop r9
00007f828abd49a1  pop r8
00007f828abd49a3  pop rsi
00007f828abd49a4  pop rdi
00007f828abd49a5  pop rdx
00007f828abd49a6  pop rcx
00007f828abd49a7  pop rax
00007f828abd49a8  add rsp, 0x08
00007f828abd49ac  jmp 0x00007F828ABD0183
00007f828abd49b1  call 0x00007F828A9FF430
00007f828abd49b6  jmp 0x00007F828ABD018D
00007f828abd49bb  sub rsp, 0x08
00007f828abd49bf  push rax
00007f828abd49c0  push rcx
00007f828abd49c1  push rdx
00007f828abd49c2  push rdi
00007f828abd49c3  push rsi
00007f828abd49c4  push r8
00007f828abd49c6  push r9
00007f828abd49c8  push r10
00007f828abd49ca  push r11
00007f828abd49cc  sub rsp, 0xF0
00007f828abd49d3  vmovaps [rsp], xmm0
00007f828abd49d8  vmovaps [rsp+0x10], xmm1
00007f828abd49de  vmovaps [rsp+0x20], xmm2
00007f828abd49e4  vmovaps [rsp+0x30], xmm3
00007f828abd49ea  vmovaps [rsp+0x40], xmm4
00007f828abd49f0  vmovaps [rsp+0x50], xmm5
00007f828abd49f6  vmovaps [rsp+0x60], xmm6
00007f828abd49fc  vmovaps [rsp+0x70], xmm7
00007f828abd4a02  vmovaps [rsp+0x80], xmm9
00007f828abd4a0b  vmovaps [rsp+0x90], xmm10
00007f828abd4a14  vmovaps [rsp+0xA0], xmm11
00007f828abd4a1d  vmovaps [rsp+0xB0], xmm12
00007f828abd4a26  vmovaps [rsp+0xC0], xmm13
00007f828abd4a2f  vmovaps [rsp+0xD0], xmm14
00007f828abd4a38  vmovaps [rsp+0xE0], xmm15
00007f828abd4a41  sub rsp, 0x30
00007f828abd4a45  movaps [rsp], xmm8
00007f828abd4a4a  movaps [rsp+0x10], xmm14
00007f828abd4a50  movaps [rsp+0x20], xmm9
00007f828abd4a56  lea rdi, [rsp]
00007f828abd4a5a  mov esi, 0x00
00007f828abd4a5f  mov rax, 0x5BFE27FA6530
00007f828abd4a69  call rax
00007f828abd4a6b  movaps xmm8, [rsp]
00007f828abd4a70  add rsp, 0x30
00007f828abd4a74  vmovaps xmm0, [rsp]
00007f828abd4a79  vmovaps xmm1, [rsp+0x10]
00007f828abd4a7f  vmovaps xmm2, [rsp+0x20]
00007f828abd4a85  vmovaps xmm3, [rsp+0x30]
00007f828abd4a8b  vmovaps xmm4, [rsp+0x40]
00007f828abd4a91  vmovaps xmm5, [rsp+0x50]
00007f828abd4a97  vmovaps xmm6, [rsp+0x60]
00007f828abd4a9d  vmovaps xmm7, [rsp+0x70]
00007f828abd4aa3  vmovaps xmm9, [rsp+0x80]
00007f828abd4aac  vmovaps xmm10, [rsp+0x90]
00007f828abd4ab5  vmovaps xmm11, [rsp+0xA0]
00007f828abd4abe  vmovaps xmm12, [rsp+0xB0]
00007f828abd4ac7  vmovaps xmm13, [rsp+0xC0]
00007f828abd4ad0  vmovaps xmm14, [rsp+0xD0]
00007f828abd4ad9  vmovaps xmm15, [rsp+0xE0]
00007f828abd4ae2  add rsp, 0xF0
00007f828abd4ae9  pop r11
00007f828abd4aeb  pop r10
00007f828abd4aed  pop r9
00007f828abd4aef  pop r8
00007f828abd4af1  pop rsi
00007f828abd4af2  pop rdi
00007f828abd4af3  pop rdx
00007f828abd4af4  pop rcx
00007f828abd4af5  pop rax
00007f828abd4af6  add rsp, 0x08
00007f828abd4afa  jmp 0x00007F828ABD01AF
00007f828abd4aff  sub rsp, 0x08
00007f828abd4b03  push rax
00007f828abd4b04  push rcx
00007f828abd4b05  push rdx
00007f828abd4b06  push rdi
00007f828abd4b07  push rsi
00007f828abd4b08  push r8
00007f828abd4b0a  push r9
00007f828abd4b0c  push r10
00007f828abd4b0e  push r11
00007f828abd4b10  sub rsp, 0xF0
00007f828abd4b17  vmovaps [rsp], xmm0
00007f828abd4b1c  vmovaps [rsp+0x10], xmm1
00007f828abd4b22  vmovaps [rsp+0x20], xmm2
00007f828abd4b28  vmovaps [rsp+0x30], xmm3
00007f828abd4b2e  vmovaps [rsp+0x40], xmm4
00007f828abd4b34  vmovaps [rsp+0x50], xmm5
00007f828abd4b3a  vmovaps [rsp+0x60], xmm6
00007f828abd4b40  vmovaps [rsp+0x70], xmm7
00007f828abd4b46  vmovaps [rsp+0x80], xmm8
00007f828abd4b4f  vmovaps [rsp+0x90], xmm10
00007f828abd4b58  vmovaps [rsp+0xA0], xmm11
00007f828abd4b61  vmovaps [rsp+0xB0], xmm12
00007f828abd4b6a  vmovaps [rsp+0xC0], xmm13
00007f828abd4b73  vmovaps [rsp+0xD0], xmm14
00007f828abd4b7c  vmovaps [rsp+0xE0], xmm15
00007f828abd4b85  sub rsp, 0x30
00007f828abd4b89  movaps [rsp], xmm9
00007f828abd4b8e  movaps [rsp+0x10], xmm1
00007f828abd4b93  movaps [rsp+0x20], xmm14
00007f828abd4b99  lea rdi, [rsp]
00007f828abd4b9d  mov esi, 0x00
00007f828abd4ba2  mov rax, 0x5BFE27FA6530
00007f828abd4bac  call rax
00007f828abd4bae  movaps xmm9, [rsp]
00007f828abd4bb3  add rsp, 0x30
00007f828abd4bb7  vmovaps xmm0, [rsp]
00007f828abd4bbc  vmovaps xmm1, [rsp+0x10]
00007f828abd4bc2  vmovaps xmm2, [rsp+0x20]
00007f828abd4bc8  vmovaps xmm3, [rsp+0x30]
00007f828abd4bce  vmovaps xmm4, [rsp+0x40]
00007f828abd4bd4  vmovaps xmm5, [rsp+0x50]
00007f828abd4bda  vmovaps xmm6, [rsp+0x60]
00007f828abd4be0  vmovaps xmm7, [rsp+0x70]
00007f828abd4be6  vmovaps xmm8, [rsp+0x80]
00007f828abd4bef  vmovaps xmm10, [rsp+0x90]
00007f828abd4bf8  vmovaps xmm11, [rsp+0xA0]
00007f828abd4c01  vmovaps xmm12, [rsp+0xB0]
00007f828abd4c0a  vmovaps xmm13, [rsp+0xC0]
00007f828abd4c13  vmovaps xmm14, [rsp+0xD0]
00007f828abd4c1c  vmovaps xmm15, [rsp+0xE0]
00007f828abd4c25  add rsp, 0xF0
00007f828abd4c2c  pop r11
00007f828abd4c2e  pop r10
00007f828abd4c30  pop r9
00007f828abd4c32  pop r8
00007f828abd4c34  pop rsi
00007f828abd4c35  pop rdi
00007f828abd4c36  pop rdx
00007f828abd4c37  pop rcx
00007f828abd4c38  pop rax
00007f828abd4c39  add rsp, 0x08
00007f828abd4c3d  jmp 0x00007F828ABD01DD
00007f828abd4c42  sub rsp, 0x08
00007f828abd4c46  push rax
00007f828abd4c47  push rcx
00007f828abd4c48  push rdx
00007f828abd4c49  push rdi
00007f828abd4c4a  push rsi
00007f828abd4c4b  push r8
00007f828abd4c4d  push r9
00007f828abd4c4f  push r10
00007f828abd4c51  push r11
00007f828abd4c53  sub rsp, 0xF0
00007f828abd4c5a  vmovaps [rsp], xmm0
00007f828abd4c5f  vmovaps [rsp+0x10], xmm1
00007f828abd4c65  vmovaps [rsp+0x20], xmm2
00007f828abd4c6b  vmovaps [rsp+0x30], xmm3
00007f828abd4c71  vmovaps [rsp+0x40], xmm4
00007f828abd4c77  vmovaps [rsp+0x50], xmm5
00007f828abd4c7d  vmovaps [rsp+0x60], xmm6
00007f828abd4c83  vmovaps [rsp+0x70], xmm7
00007f828abd4c89  vmovaps [rsp+0x80], xmm8
00007f828abd4c92  vmovaps [rsp+0x90], xmm9
00007f828abd4c9b  vmovaps [rsp+0xA0], xmm10
00007f828abd4ca4  vmovaps [rsp+0xB0], xmm11
00007f828abd4cad  vmovaps [rsp+0xC0], xmm12
00007f828abd4cb6  vmovaps [rsp+0xD0], xmm13
00007f828abd4cbf  vmovaps [rsp+0xE0], xmm15
00007f828abd4cc8  sub rsp, 0x30
00007f828abd4ccc  movaps [rsp], xmm14
00007f828abd4cd1  movaps [rsp+0x10], xmm4
00007f828abd4cd6  movaps [rsp+0x20], xmm1
00007f828abd4cdb  lea rdi, [rsp]
00007f828abd4cdf  mov esi, 0x00
00007f828abd4ce4  mov rax, 0x5BFE27FA6530
00007f828abd4cee  call rax
00007f828abd4cf0  movaps xmm14, [rsp]
00007f828abd4cf5  add rsp, 0x30
00007f828abd4cf9  vmovaps xmm0, [rsp]
00007f828abd4cfe  vmovaps xmm1, [rsp+0x10]
00007f828abd4d04  vmovaps xmm2, [rsp+0x20]
00007f828abd4d0a  vmovaps xmm3, [rsp+0x30]
00007f828abd4d10  vmovaps xmm4, [rsp+0x40]
00007f828abd4d16  vmovaps xmm5, [rsp+0x50]
00007f828abd4d1c  vmovaps xmm6, [rsp+0x60]
00007f828abd4d22  vmovaps xmm7, [rsp+0x70]
00007f828abd4d28  vmovaps xmm8, [rsp+0x80]
00007f828abd4d31  vmovaps xmm9, [rsp+0x90]
00007f828abd4d3a  vmovaps xmm10, [rsp+0xA0]
00007f828abd4d43  vmovaps xmm11, [rsp+0xB0]
00007f828abd4d4c  vmovaps xmm12, [rsp+0xC0]
00007f828abd4d55  vmovaps xmm13, [rsp+0xD0]
00007f828abd4d5e  vmovaps xmm15, [rsp+0xE0]
00007f828abd4d67  add rsp, 0xF0
00007f828abd4d6e  pop r11
00007f828abd4d70  pop r10
00007f828abd4d72  pop r9
00007f828abd4d74  pop r8
00007f828abd4d76  pop rsi
00007f828abd4d77  pop rdi
00007f828abd4d78  pop rdx
00007f828abd4d79  pop rcx
00007f828abd4d7a  pop rax
00007f828abd4d7b  add rsp, 0x08
00007f828abd4d7f  jmp 0x00007F828ABD0203
00007f828abd4d84  sub rsp, 0x08
00007f828abd4d88  push rax
00007f828abd4d89  push rcx
00007f828abd4d8a  push rdx
00007f828abd4d8b  push rdi
00007f828abd4d8c  push rsi
00007f828abd4d8d  push r8
00007f828abd4d8f  push r9
00007f828abd4d91  push r10
00007f828abd4d93  push r11
00007f828abd4d95  sub rsp, 0xF0
00007f828abd4d9c  vmovaps [rsp], xmm0
00007f828abd4da1  vmovaps [rsp+0x10], xmm2
00007f828abd4da7  vmovaps [rsp+0x20], xmm3
00007f828abd4dad  vmovaps [rsp+0x30], xmm4
00007f828abd4db3  vmovaps [rsp+0x40], xmm5
00007f828abd4db9  vmovaps [rsp+0x50], xmm6
00007f828abd4dbf  vmovaps [rsp+0x60], xmm7
00007f828abd4dc5  vmovaps [rsp+0x70], xmm8
00007f828abd4dcb  vmovaps [rsp+0x80], xmm9
00007f828abd4dd4  vmovaps [rsp+0x90], xmm10
00007f828abd4ddd  vmovaps [rsp+0xA0], xmm11
00007f828abd4de6  vmovaps [rsp+0xB0], xmm12
00007f828abd4def  vmovaps [rsp+0xC0], xmm13
00007f828abd4df8  vmovaps [rsp+0xD0], xmm14
00007f828abd4e01  vmovaps [rsp+0xE0], xmm15
00007f828abd4e0a  sub rsp, 0x30
00007f828abd4e0e  movaps [rsp], xmm1
00007f828abd4e12  movaps [rsp+0x10], xmm12
00007f828abd4e18  movaps [rsp+0x20], xmm11
00007f828abd4e1e  lea rdi, [rsp]
00007f828abd4e22  mov esi, 0x00
00007f828abd4e27  mov rax, 0x5BFE27FA6530
00007f828abd4e31  call rax
00007f828abd4e33  movaps xmm1, [rsp]
00007f828abd4e37  add rsp, 0x30
00007f828abd4e3b  vmovaps xmm0, [rsp]
00007f828abd4e40  vmovaps xmm2, [rsp+0x10]
00007f828abd4e46  vmovaps xmm3, [rsp+0x20]
00007f828abd4e4c  vmovaps xmm4, [rsp+0x30]
00007f828abd4e52  vmovaps xmm5, [rsp+0x40]
00007f828abd4e58  vmovaps xmm6, [rsp+0x50]
00007f828abd4e5e  vmovaps xmm7, [rsp+0x60]
00007f828abd4e64  vmovaps xmm8, [rsp+0x70]
00007f828abd4e6a  vmovaps xmm9, [rsp+0x80]
00007f828abd4e73  vmovaps xmm10, [rsp+0x90]
00007f828abd4e7c  vmovaps xmm11, [rsp+0xA0]
00007f828abd4e85  vmovaps xmm12, [rsp+0xB0]
00007f828abd4e8e  vmovaps xmm13, [rsp+0xC0]
00007f828abd4e97  vmovaps xmm14, [rsp+0xD0]
00007f828abd4ea0  vmovaps xmm15, [rsp+0xE0]
00007f828abd4ea9  add rsp, 0xF0
00007f828abd4eb0  pop r11
00007f828abd4eb2  pop r10
00007f828abd4eb4  pop r9
00007f828abd4eb6  pop r8
00007f828abd4eb8  pop rsi
00007f828abd4eb9  pop rdi
00007f828abd4eba  pop rdx
00007f828abd4ebb  pop rcx
00007f828abd4ebc  pop rax
00007f828abd4ebd  add rsp, 0x08
00007f828abd4ec1  jmp 0x00007F828ABD0224
00007f828abd4ec6  call 0x00007F828AAE20A0
00007f828abd4ecb  jmp 0x00007F828ABD0232
00007f828abd4ed0  call 0x00007F828AA09D70
00007f828abd4ed5  jmp 0x00007F828ABD023C
00007f828abd4eda  sub rsp, 0x08
00007f828abd4ede  push rax
00007f828abd4edf  push rcx
00007f828abd4ee0  push rdx
00007f828abd4ee1  push rdi
00007f828abd4ee2  push rsi
00007f828abd4ee3  push r8
00007f828abd4ee5  push r9
00007f828abd4ee7  push r10
00007f828abd4ee9  push r11
00007f828abd4eeb  sub rsp, 0xF0
00007f828abd4ef2  vmovaps [rsp], xmm0
00007f828abd4ef7  vmovaps [rsp+0x10], xmm1
00007f828abd4efd  vmovaps [rsp+0x20], xmm2
00007f828abd4f03  vmovaps [rsp+0x30], xmm3
00007f828abd4f09  vmovaps [rsp+0x40], xmm4
00007f828abd4f0f  vmovaps [rsp+0x50], xmm5
00007f828abd4f15  vmovaps [rsp+0x60], xmm6
00007f828abd4f1b  vmovaps [rsp+0x70], xmm8
00007f828abd4f21  vmovaps [rsp+0x80], xmm9
00007f828abd4f2a  vmovaps [rsp+0x90], xmm10
00007f828abd4f33  vmovaps [rsp+0xA0], xmm11
00007f828abd4f3c  vmovaps [rsp+0xB0], xmm12
00007f828abd4f45  vmovaps [rsp+0xC0], xmm13
00007f828abd4f4e  vmovaps [rsp+0xD0], xmm14
00007f828abd4f57  vmovaps [rsp+0xE0], xmm15
00007f828abd4f60  sub rsp, 0x30
00007f828abd4f64  movaps [rsp], xmm7
00007f828abd4f68  movaps [rsp+0x10], xmm15
00007f828abd4f6e  movaps [rsp+0x20], xmm10
00007f828abd4f74  lea rdi, [rsp]
00007f828abd4f78  mov esi, 0x00
00007f828abd4f7d  mov rax, 0x5BFE27FA6530
00007f828abd4f87  call rax
00007f828abd4f89  movaps xmm7, [rsp]
00007f828abd4f8d  add rsp, 0x30
00007f828abd4f91  vmovaps xmm0, [rsp]
00007f828abd4f96  vmovaps xmm1, [rsp+0x10]
00007f828abd4f9c  vmovaps xmm2, [rsp+0x20]
00007f828abd4fa2  vmovaps xmm3, [rsp+0x30]
00007f828abd4fa8  vmovaps xmm4, [rsp+0x40]
00007f828abd4fae  vmovaps xmm5, [rsp+0x50]
00007f828abd4fb4  vmovaps xmm6, [rsp+0x60]
00007f828abd4fba  vmovaps xmm8, [rsp+0x70]
00007f828abd4fc0  vmovaps xmm9, [rsp+0x80]
00007f828abd4fc9  vmovaps xmm10, [rsp+0x90]
00007f828abd4fd2  vmovaps xmm11, [rsp+0xA0]
00007f828abd4fdb  vmovaps xmm12, [rsp+0xB0]
00007f828abd4fe4  vmovaps xmm13, [rsp+0xC0]
00007f828abd4fed  vmovaps xmm14, [rsp+0xD0]
00007f828abd4ff6  vmovaps xmm15, [rsp+0xE0]
00007f828abd4fff  add rsp, 0xF0
00007f828abd5006  pop r11
00007f828abd5008  pop r10
00007f828abd500a  pop r9
00007f828abd500c  pop r8
00007f828abd500e  pop rsi
00007f828abd500f  pop rdi
00007f828abd5010  pop rdx
00007f828abd5011  pop rcx
00007f828abd5012  pop rax
00007f828abd5013  add rsp, 0x08
00007f828abd5017  jmp 0x00007F828ABD025D
00007f828abd501c  sub rsp, 0x08
00007f828abd5020  push rax
00007f828abd5021  push rcx
00007f828abd5022  push rdx
00007f828abd5023  push rdi
00007f828abd5024  push rsi
00007f828abd5025  push r8
00007f828abd5027  push r9
00007f828abd5029  push r10
00007f828abd502b  push r11
00007f828abd502d  sub rsp, 0xF0
00007f828abd5034  vmovaps [rsp], xmm0
00007f828abd5039  vmovaps [rsp+0x10], xmm1
00007f828abd503f  vmovaps [rsp+0x20], xmm2
00007f828abd5045  vmovaps [rsp+0x30], xmm3
00007f828abd504b  vmovaps [rsp+0x40], xmm4
00007f828abd5051  vmovaps [rsp+0x50], xmm5
00007f828abd5057  vmovaps [rsp+0x60], xmm6
00007f828abd505d  vmovaps [rsp+0x70], xmm7
00007f828abd5063  vmovaps [rsp+0x80], xmm8
00007f828abd506c  vmovaps [rsp+0x90], xmm9
00007f828abd5075  vmovaps [rsp+0xA0], xmm11
00007f828abd507e  vmovaps [rsp+0xB0], xmm12
00007f828abd5087  vmovaps [rsp+0xC0], xmm13
00007f828abd5090  vmovaps [rsp+0xD0], xmm14
00007f828abd5099  vmovaps [rsp+0xE0], xmm15
00007f828abd50a2  sub rsp, 0x30
00007f828abd50a6  movaps [rsp], xmm10
00007f828abd50ab  movaps [rsp+0x10], xmm11
00007f828abd50b1  movaps [rsp+0x20], xmm15
00007f828abd50b7  lea rdi, [rsp]
00007f828abd50bb  mov esi, 0x00
00007f828abd50c0  mov rax, 0x5BFE27FA6530
00007f828abd50ca  call rax
00007f828abd50cc  movaps xmm10, [rsp]
00007f828abd50d1  add rsp, 0x30
00007f828abd50d5  vmovaps xmm0, [rsp]
00007f828abd50da  vmovaps xmm1, [rsp+0x10]
00007f828abd50e0  vmovaps xmm2, [rsp+0x20]
00007f828abd50e6  vmovaps xmm3, [rsp+0x30]
00007f828abd50ec  vmovaps xmm4, [rsp+0x40]
00007f828abd50f2  vmovaps xmm5, [rsp+0x50]
00007f828abd50f8  vmovaps xmm6, [rsp+0x60]
00007f828abd50fe  vmovaps xmm7, [rsp+0x70]
00007f828abd5104  vmovaps xmm8, [rsp+0x80]
00007f828abd510d  vmovaps xmm9, [rsp+0x90]
00007f828abd5116  vmovaps xmm11, [rsp+0xA0]
00007f828abd511f  vmovaps xmm12, [rsp+0xB0]
00007f828abd5128  vmovaps xmm13, [rsp+0xC0]
00007f828abd5131  vmovaps xmm14, [rsp+0xD0]
00007f828abd513a  vmovaps xmm15, [rsp+0xE0]
00007f828abd5143  add rsp, 0xF0
00007f828abd514a  pop r11
00007f828abd514c  pop r10
00007f828abd514e  pop r9
00007f828abd5150  pop r8
00007f828abd5152  pop rsi
00007f828abd5153  pop rdi
00007f828abd5154  pop rdx
00007f828abd5155  pop rcx
00007f828abd5156  pop rax
00007f828abd5157  add rsp, 0x08
00007f828abd515b  jmp 0x00007F828ABD028B
00007f828abd5160  sub rsp, 0x08
00007f828abd5164  push rax
00007f828abd5165  push rcx
00007f828abd5166  push rdx
00007f828abd5167  push rdi
00007f828abd5168  push rsi
00007f828abd5169  push r8
00007f828abd516b  push r9
00007f828abd516d  push r10
00007f828abd516f  push r11
00007f828abd5171  sub rsp, 0xF0
00007f828abd5178  vmovaps [rsp], xmm0
00007f828abd517d  vmovaps [rsp+0x10], xmm1
00007f828abd5183  vmovaps [rsp+0x20], xmm2
00007f828abd5189  vmovaps [rsp+0x30], xmm3
00007f828abd518f  vmovaps [rsp+0x40], xmm4
00007f828abd5195  vmovaps [rsp+0x50], xmm5
00007f828abd519b  vmovaps [rsp+0x60], xmm6
00007f828abd51a1  vmovaps [rsp+0x70], xmm7
00007f828abd51a7  vmovaps [rsp+0x80], xmm8
00007f828abd51b0  vmovaps [rsp+0x90], xmm9
00007f828abd51b9  vmovaps [rsp+0xA0], xmm10
00007f828abd51c2  vmovaps [rsp+0xB0], xmm12
00007f828abd51cb  vmovaps [rsp+0xC0], xmm13
00007f828abd51d4  vmovaps [rsp+0xD0], xmm14
00007f828abd51dd  vmovaps [rsp+0xE0], xmm15
00007f828abd51e6  sub rsp, 0x30
00007f828abd51ea  movaps [rsp], xmm11
00007f828abd51ef  movaps [rsp+0x10], xmm12
00007f828abd51f5  movaps [rsp+0x20], xmm15
00007f828abd51fb  lea rdi, [rsp]
00007f828abd51ff  mov esi, 0x00
00007f828abd5204  mov rax, 0x5BFE27FA6530
00007f828abd520e  call rax
00007f828abd5210  movaps xmm11, [rsp]
00007f828abd5215  add rsp, 0x30
00007f828abd5219  vmovaps xmm0, [rsp]
00007f828abd521e  vmovaps xmm1, [rsp+0x10]
00007f828abd5224  vmovaps xmm2, [rsp+0x20]
00007f828abd522a  vmovaps xmm3, [rsp+0x30]
00007f828abd5230  vmovaps xmm4, [rsp+0x40]
00007f828abd5236  vmovaps xmm5, [rsp+0x50]
00007f828abd523c  vmovaps xmm6, [rsp+0x60]
00007f828abd5242  vmovaps xmm7, [rsp+0x70]
00007f828abd5248  vmovaps xmm8, [rsp+0x80]
00007f828abd5251  vmovaps xmm9, [rsp+0x90]
00007f828abd525a  vmovaps xmm10, [rsp+0xA0]
00007f828abd5263  vmovaps xmm12, [rsp+0xB0]
00007f828abd526c  vmovaps xmm13, [rsp+0xC0]
00007f828abd5275  vmovaps xmm14, [rsp+0xD0]
00007f828abd527e  vmovaps xmm15, [rsp+0xE0]
00007f828abd5287  add rsp, 0xF0
00007f828abd528e  pop r11
00007f828abd5290  pop r10
00007f828abd5292  pop r9
00007f828abd5294  pop r8
00007f828abd5296  pop rsi
00007f828abd5297  pop rdi
00007f828abd5298  pop rdx
00007f828abd5299  pop rcx
00007f828abd529a  pop rax
00007f828abd529b  add rsp, 0x08
00007f828abd529f  jmp 0x00007F828ABD02B9
00007f828abd52a4  sub rsp, 0x08
00007f828abd52a8  push rax
00007f828abd52a9  push rcx
00007f828abd52aa  push rdx
00007f828abd52ab  push rdi
00007f828abd52ac  push rsi
00007f828abd52ad  push r8
00007f828abd52af  push r9
00007f828abd52b1  push r10
00007f828abd52b3  push r11
00007f828abd52b5  sub rsp, 0xF0
00007f828abd52bc  vmovaps [rsp], xmm0
00007f828abd52c1  vmovaps [rsp+0x10], xmm1
00007f828abd52c7  vmovaps [rsp+0x20], xmm2
00007f828abd52cd  vmovaps [rsp+0x30], xmm3
00007f828abd52d3  vmovaps [rsp+0x40], xmm4
00007f828abd52d9  vmovaps [rsp+0x50], xmm5
00007f828abd52df  vmovaps [rsp+0x60], xmm6
00007f828abd52e5  vmovaps [rsp+0x70], xmm7
00007f828abd52eb  vmovaps [rsp+0x80], xmm8
00007f828abd52f4  vmovaps [rsp+0x90], xmm9
00007f828abd52fd  vmovaps [rsp+0xA0], xmm10
00007f828abd5306  vmovaps [rsp+0xB0], xmm11
00007f828abd530f  vmovaps [rsp+0xC0], xmm12
00007f828abd5318  vmovaps [rsp+0xD0], xmm13
00007f828abd5321  vmovaps [rsp+0xE0], xmm14
00007f828abd532a  sub rsp, 0x30
00007f828abd532e  movaps [rsp], xmm15
00007f828abd5333  movaps [rsp+0x10], xmm13
00007f828abd5339  movaps [rsp+0x20], xmm9
00007f828abd533f  lea rdi, [rsp]
00007f828abd5343  mov esi, 0x00
00007f828abd5348  mov rax, 0x5BFE27FA6530
00007f828abd5352  call rax
00007f828abd5354  movaps xmm15, [rsp]
00007f828abd5359  add rsp, 0x30
00007f828abd535d  vmovaps xmm0, [rsp]
00007f828abd5362  vmovaps xmm1, [rsp+0x10]
00007f828abd5368  vmovaps xmm2, [rsp+0x20]
00007f828abd536e  vmovaps xmm3, [rsp+0x30]
00007f828abd5374  vmovaps xmm4, [rsp+0x40]
00007f828abd537a  vmovaps xmm5, [rsp+0x50]
00007f828abd5380  vmovaps xmm6, [rsp+0x60]
00007f828abd5386  vmovaps xmm7, [rsp+0x70]
00007f828abd538c  vmovaps xmm8, [rsp+0x80]
00007f828abd5395  vmovaps xmm9, [rsp+0x90]
00007f828abd539e  vmovaps xmm10, [rsp+0xA0]
00007f828abd53a7  vmovaps xmm11, [rsp+0xB0]
00007f828abd53b0  vmovaps xmm12, [rsp+0xC0]
00007f828abd53b9  vmovaps xmm13, [rsp+0xD0]
00007f828abd53c2  vmovaps xmm14, [rsp+0xE0]
00007f828abd53cb  add rsp, 0xF0
00007f828abd53d2  pop r11
00007f828abd53d4  pop r10
00007f828abd53d6  pop r9
00007f828abd53d8  pop r8
00007f828abd53da  pop rsi
00007f828abd53db  pop rdi
00007f828abd53dc  pop rdx
00007f828abd53dd  pop rcx
00007f828abd53de  pop rax
00007f828abd53df  add rsp, 0x08
00007f828abd53e3  jmp 0x00007F828ABD02D4
00007f828abd53e8  sub rsp, 0x08
00007f828abd53ec  push rax
00007f828abd53ed  push rcx
00007f828abd53ee  push rdx
00007f828abd53ef  push rdi
00007f828abd53f0  push rsi
00007f828abd53f1  push r8
00007f828abd53f3  push r9
00007f828abd53f5  push r10
00007f828abd53f7  push r11
00007f828abd53f9  sub rsp, 0xF0
00007f828abd5400  vmovaps [rsp], xmm0
00007f828abd5405  vmovaps [rsp+0x10], xmm1
00007f828abd540b  vmovaps [rsp+0x20], xmm2
00007f828abd5411  vmovaps [rsp+0x30], xmm3
00007f828abd5417  vmovaps [rsp+0x40], xmm4
00007f828abd541d  vmovaps [rsp+0x50], xmm5
00007f828abd5423  vmovaps [rsp+0x60], xmm6
00007f828abd5429  vmovaps [rsp+0x70], xmm7
00007f828abd542f  vmovaps [rsp+0x80], xmm8
00007f828abd5438  vmovaps [rsp+0x90], xmm9
00007f828abd5441  vmovaps [rsp+0xA0], xmm10
00007f828abd544a  vmovaps [rsp+0xB0], xmm11
00007f828abd5453  vmovaps [rsp+0xC0], xmm12
00007f828abd545c  vmovaps [rsp+0xD0], xmm14
00007f828abd5465  vmovaps [rsp+0xE0], xmm15
00007f828abd546e  sub rsp, 0x30
00007f828abd5472  movaps [rsp], xmm13
00007f828abd5477  movaps [rsp+0x10], xmm8
00007f828abd547d  movaps [rsp+0x20], xmm14
00007f828abd5483  lea rdi, [rsp]
00007f828abd5487  mov esi, 0x00
00007f828abd548c  mov rax, 0x5BFE27FA6530
00007f828abd5496  call rax
00007f828abd5498  movaps xmm13, [rsp]
00007f828abd549d  add rsp, 0x30
00007f828abd54a1  vmovaps xmm0, [rsp]
00007f828abd54a6  vmovaps xmm1, [rsp+0x10]
00007f828abd54ac  vmovaps xmm2, [rsp+0x20]
00007f828abd54b2  vmovaps xmm3, [rsp+0x30]
00007f828abd54b8  vmovaps xmm4, [rsp+0x40]
00007f828abd54be  vmovaps xmm5, [rsp+0x50]
00007f828abd54c4  vmovaps xmm6, [rsp+0x60]
00007f828abd54ca  vmovaps xmm7, [rsp+0x70]
00007f828abd54d0  vmovaps xmm8, [rsp+0x80]
00007f828abd54d9  vmovaps xmm9, [rsp+0x90]
00007f828abd54e2  vmovaps xmm10, [rsp+0xA0]
00007f828abd54eb  vmovaps xmm11, [rsp+0xB0]
00007f828abd54f4  vmovaps xmm12, [rsp+0xC0]
00007f828abd54fd  vmovaps xmm14, [rsp+0xD0]
00007f828abd5506  vmovaps xmm15, [rsp+0xE0]
00007f828abd550f  add rsp, 0xF0
00007f828abd5516  pop r11
00007f828abd5518  pop r10
00007f828abd551a  pop r9
00007f828abd551c  pop r8
00007f828abd551e  pop rsi
00007f828abd551f  pop rdi
00007f828abd5520  pop rdx
00007f828abd5521  pop rcx
00007f828abd5522  pop rax
00007f828abd5523  add rsp, 0x08
00007f828abd5527  jmp 0x00007F828ABD02F7
00007f828abd552c  sub rsp, 0x08
00007f828abd5530  push rax
00007f828abd5531  push rcx
00007f828abd5532  push rdx
00007f828abd5533  push rdi
00007f828abd5534  push rsi
00007f828abd5535  push r8
00007f828abd5537  push r9
00007f828abd5539  push r10
00007f828abd553b  push r11
00007f828abd553d  sub rsp, 0xF0
00007f828abd5544  vmovaps [rsp], xmm0
00007f828abd5549  vmovaps [rsp+0x10], xmm1
00007f828abd554f  vmovaps [rsp+0x20], xmm2
00007f828abd5555  vmovaps [rsp+0x30], xmm3
00007f828abd555b  vmovaps [rsp+0x40], xmm4
00007f828abd5561  vmovaps [rsp+0x50], xmm5
00007f828abd5567  vmovaps [rsp+0x60], xmm6
00007f828abd556d  vmovaps [rsp+0x70], xmm7
00007f828abd5573  vmovaps [rsp+0x80], xmm8
00007f828abd557c  vmovaps [rsp+0x90], xmm9
00007f828abd5585  vmovaps [rsp+0xA0], xmm10
00007f828abd558e  vmovaps [rsp+0xB0], xmm11
00007f828abd5597  vmovaps [rsp+0xC0], xmm12
00007f828abd55a0  vmovaps [rsp+0xD0], xmm13
00007f828abd55a9  vmovaps [rsp+0xE0], xmm15
00007f828abd55b2  sub rsp, 0x30
00007f828abd55b6  movaps [rsp], xmm14
00007f828abd55bb  movaps [rsp+0x10], xmm1
00007f828abd55c0  movaps [rsp+0x20], xmm10
00007f828abd55c6  lea rdi, [rsp]
00007f828abd55ca  mov esi, 0x00
00007f828abd55cf  mov rax, 0x5BFE27FA6530
00007f828abd55d9  call rax
00007f828abd55db  movaps xmm14, [rsp]
00007f828abd55e0  add rsp, 0x30
00007f828abd55e4  vmovaps xmm0, [rsp]
00007f828abd55e9  vmovaps xmm1, [rsp+0x10]
00007f828abd55ef  vmovaps xmm2, [rsp+0x20]
00007f828abd55f5  vmovaps xmm3, [rsp+0x30]
00007f828abd55fb  vmovaps xmm4, [rsp+0x40]
00007f828abd5601  vmovaps xmm5, [rsp+0x50]
00007f828abd5607  vmovaps xmm6, [rsp+0x60]
00007f828abd560d  vmovaps xmm7, [rsp+0x70]
00007f828abd5613  vmovaps xmm8, [rsp+0x80]
00007f828abd561c  vmovaps xmm9, [rsp+0x90]
00007f828abd5625  vmovaps xmm10, [rsp+0xA0]
00007f828abd562e  vmovaps xmm11, [rsp+0xB0]
00007f828abd5637  vmovaps xmm12, [rsp+0xC0]
00007f828abd5640  vmovaps xmm13, [rsp+0xD0]
00007f828abd5649  vmovaps xmm15, [rsp+0xE0]
00007f828abd5652  add rsp, 0xF0
00007f828abd5659  pop r11
00007f828abd565b  pop r10
00007f828abd565d  pop r9
00007f828abd565f  pop r8
00007f828abd5661  pop rsi
00007f828abd5662  pop rdi
00007f828abd5663  pop rdx
00007f828abd5664  pop rcx
00007f828abd5665  pop rax
00007f828abd5666  add rsp, 0x08
00007f828abd566a  jmp 0x00007F828ABD031A
00007f828abd566f  sub rsp, 0x08
00007f828abd5673  push rax
00007f828abd5674  push rcx
00007f828abd5675  push rdx
00007f828abd5676  push rdi
00007f828abd5677  push rsi
00007f828abd5678  push r8
00007f828abd567a  push r9
00007f828abd567c  push r10
00007f828abd567e  push r11
00007f828abd5680  sub rsp, 0xF0
00007f828abd5687  vmovaps [rsp], xmm0
00007f828abd568c  vmovaps [rsp+0x10], xmm2
00007f828abd5692  vmovaps [rsp+0x20], xmm3
00007f828abd5698  vmovaps [rsp+0x30], xmm4
00007f828abd569e  vmovaps [rsp+0x40], xmm5
00007f828abd56a4  vmovaps [rsp+0x50], xmm6
00007f828abd56aa  vmovaps [rsp+0x60], xmm7
00007f828abd56b0  vmovaps [rsp+0x70], xmm8
00007f828abd56b6  vmovaps [rsp+0x80], xmm9
00007f828abd56bf  vmovaps [rsp+0x90], xmm10
00007f828abd56c8  vmovaps [rsp+0xA0], xmm11
00007f828abd56d1  vmovaps [rsp+0xB0], xmm12
00007f828abd56da  vmovaps [rsp+0xC0], xmm13
00007f828abd56e3  vmovaps [rsp+0xD0], xmm14
00007f828abd56ec  vmovaps [rsp+0xE0], xmm15
00007f828abd56f5  sub rsp, 0x30
00007f828abd56f9  movaps [rsp], xmm1
00007f828abd56fd  movaps [rsp+0x10], xmm7
00007f828abd5702  movaps [rsp+0x20], xmm11
00007f828abd5708  lea rdi, [rsp]
00007f828abd570c  mov esi, 0x00
00007f828abd5711  mov rax, 0x5BFE27FA6530
00007f828abd571b  call rax
00007f828abd571d  movaps xmm1, [rsp]
00007f828abd5721  add rsp, 0x30
00007f828abd5725  vmovaps xmm0, [rsp]
00007f828abd572a  vmovaps xmm2, [rsp+0x10]
00007f828abd5730  vmovaps xmm3, [rsp+0x20]
00007f828abd5736  vmovaps xmm4, [rsp+0x30]
00007f828abd573c  vmovaps xmm5, [rsp+0x40]
00007f828abd5742  vmovaps xmm6, [rsp+0x50]
00007f828abd5748  vmovaps xmm7, [rsp+0x60]
00007f828abd574e  vmovaps xmm8, [rsp+0x70]
00007f828abd5754  vmovaps xmm9, [rsp+0x80]
00007f828abd575d  vmovaps xmm10, [rsp+0x90]
00007f828abd5766  vmovaps xmm11, [rsp+0xA0]
00007f828abd576f  vmovaps xmm12, [rsp+0xB0]
00007f828abd5778  vmovaps xmm13, [rsp+0xC0]
00007f828abd5781  vmovaps xmm14, [rsp+0xD0]
00007f828abd578a  vmovaps xmm15, [rsp+0xE0]
00007f828abd5793  add rsp, 0xF0
00007f828abd579a  pop r11
00007f828abd579c  pop r10
00007f828abd579e  pop r9
00007f828abd57a0  pop r8
00007f828abd57a2  pop rsi
00007f828abd57a3  pop rdi
00007f828abd57a4  pop rdx
00007f828abd57a5  pop rcx
00007f828abd57a6  pop rax
00007f828abd57a7  add rsp, 0x08
00007f828abd57ab  jmp 0x00007F828ABD033B
00007f828abd57b0  call 0x00007F828AA0E880
00007f828abd57b5  jmp 0x00007F828ABD034E
00007f828abd57ba  call 0x00007F828AA0C380
00007f828abd57bf  jmp 0x00007F828ABD0359
00007f828abd57c4  call 0x00007F828AA0D600
00007f828abd57c9  jmp 0x00007F828ABD0364
00007f828abd57ce  call 0x00007F828A9FF540
00007f828abd57d3  jmp 0x00007F828ABD036F
00007f828abd57d8  int3
00007f828abd57d9  nop [rax], eax
00007f828abd57e0  mov rax, [r15+0x40]
00007f828abd57e4  mov r14, [r15+0x58]
00007f828abd57e8  lea r12, [rax+r14*1]
00007f828abd57ec  movaps xmm1, [r15+0x1D0]
00007f828abd57f4  vmovaps [rsp+0x10], xmm1
00007f828abd57fa  vmovaps xmm15, [rsp+0x10]
00007f828abd5800  por xmm1, xmm15
00007f828abd5805  movaps xmm14, [r15+0x1A0]
00007f828abd580d  vmovaps [rsp+0x10], xmm14
00007f828abd5813  vmovaps xmm13, [rsp+0x10]
00007f828abd5819  por xmm14, xmm13
00007f828abd581e  lea rax, [r12+0x30]
00007f828abd5823  mov r11, [r13+rax*1]
00007f828abd5828  lea rax, [r12+0x38]
00007f828abd582d  mov r10, [r13+rax*1]
00007f828abd5832  movq xmm13, r11
00007f828abd5837  movq xmm12, r10
00007f828abd583c  movq xmm13, xmm13
00007f828abd5841  vmovaps [rsp+0x10], xmm13
00007f828abd5847  movq xmm13, xmm13
00007f828abd584c  movaps [r15+0x130], xmm13
00007f828abd5854  movq xmm12, xmm12
00007f828abd5859  vmovaps [rsp+0x20], xmm12
00007f828abd585f  movq xmm12, xmm12
00007f828abd5864  movaps [r15+0x280], xmm12
00007f828abd586c  movaps xmm13, [r15+0x270]
00007f828abd5874  vmovaps [rsp+0x30], xmm13
00007f828abd587a  vmovaps xmm12, [rsp+0x30]
00007f828abd5880  por xmm13, xmm12
00007f828abd5885  lea rax, [r12+0x20]
00007f828abd588a  mov r11, [r13+rax*1]
00007f828abd588f  lea rax, [r12+0x28]
00007f828abd5894  mov r10, [r13+rax*1]
00007f828abd5899  movq xmm12, r11
00007f828abd589e  movq xmm11, r10
00007f828abd58a3  movq xmm12, xmm12
00007f828abd58a8  vmovaps [rsp+0x30], xmm12
00007f828abd58ae  movq xmm12, xmm12
00007f828abd58b3  movaps [r15+0x150], xmm12
00007f828abd58bb  movq xmm11, xmm11
00007f828abd58c0  vmovaps [rsp+0x40], xmm11
00007f828abd58c6  movq xmm11, xmm11
00007f828abd58cb  movaps [r15+0x140], xmm11
00007f828abd58d3  lea rax, [r12+0x10]
00007f828abd58d8  mov r11, [r13+rax*1]
00007f828abd58dd  lea rax, [r12+0x18]
00007f828abd58e2  mov r10, [r13+rax*1]
00007f828abd58e7  movq xmm12, r11
00007f828abd58ec  movq xmm11, r10
00007f828abd58f1  movq xmm12, xmm12
00007f828abd58f6  vmovaps [rsp+0x50], xmm12
00007f828abd58fc  movq xmm12, xmm12
00007f828abd5901  movaps [r15+0x170], xmm12
00007f828abd5909  movq xmm11, xmm11
00007f828abd590e  vmovaps [rsp+0x60], xmm11
00007f828abd5914  movq xmm11, xmm11
00007f828abd5919  movaps [r15+0x160], xmm11
00007f828abd5921  mov rax, [r13+r12*1]
00007f828abd5926  vmovq xmm12, rax
00007f828abd592b  vpbroadcastq xmm12, xmm12
00007f828abd5930  lea rax, [r12+0x08]
00007f828abd5935  mov r12, [r13+rax*1]
00007f828abd593a  movq xmm11, r12
00007f828abd593f  movaps [r15+0x230], xmm11
00007f828abd5947  mov rax, [r15+0xF8]
00007f828abd594e  lea r12, [rax+0x50]
00007f828abd5952  movups xmm11, [r13+r12*1]
00007f828abd5958  lea r12, [rax+0x60]
00007f828abd595c  movups xmm10, [r13+r12*1]
00007f828abd5962  lea r12, [rax+0x30]
00007f828abd5966  movups xmm9, [r13+r12*1]
00007f828abd596c  mov r12, [r15+0x50]
00007f828abd5970  lea r11, [r12+r14*1]
00007f828abd5974  mov [r15+0x60], r11
00007f828abd5978  lea r12, [r14+0x40]
00007f828abd597c  mov [r15+0x58], r12
00007f828abd5980  movaps xmm8, xmm12
00007f828abd5984  mulpd xmm8, xmm15
00007f828abd5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007f828abd598f  ptest xmm7, xmm7
00007f828abd5994  jnz 0x00007F828ABD67B7
00007f828abd599a  movq xmm15, qword ptr [r15+0x230]
00007f828abd59a3  vmovaps [rsp+0x70], xmm15
00007f828abd59a9  vpermilpd xmm15, xmm15, 0x00
00007f828abd59af  movaps xmm7, xmm9
00007f828abd59b3  mulpd xmm7, xmm15
00007f828abd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007f828abd59bd  ptest xmm6, xmm6
00007f828abd59c2  jnz 0x00007F828ABD68FB
00007f828abd59c8  vxorps xmm15, xmm15, xmm15
00007f828abd59cd  vpbroadcastq xmm15, xmm15
00007f828abd59d2  movaps xmm9, xmm12
00007f828abd59d6  mulpd xmm9, xmm10
00007f828abd59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007f828abd59e1  ptest xmm6, xmm6
00007f828abd59e6  jnz 0x00007F828ABD6A3D
00007f828abd59ec  movaps xmm10, xmm12
00007f828abd59f0  mulpd xmm10, xmm11
00007f828abd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007f828abd59fb  ptest xmm6, xmm6
00007f828abd5a00  jnz 0x00007F828ABD6B81
00007f828abd5a06  movaps xmm11, [r15+0x1F0]
00007f828abd5a0e  movaps xmm6, xmm12
00007f828abd5a12  mulpd xmm6, xmm11
00007f828abd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007f828abd5a1c  ptest xmm5, xmm5
00007f828abd5a21  jnz 0x00007F828ABD6CC5
00007f828abd5a27  movaps xmm12, [r15+0x2A0]
00007f828abd5a2f  vmovaps [rsp+0x80], xmm12
00007f828abd5a38  vmovaps xmm11, [rsp+0x80]
00007f828abd5a41  por xmm12, xmm11
00007f828abd5a46  movaps xmm11, [r15+0x250]
00007f828abd5a4e  vmovaps [rsp+0x80], xmm11
00007f828abd5a57  vmovaps xmm5, [rsp+0x80]
00007f828abd5a60  por xmm11, xmm5
00007f828abd5a65  vmovaps xmm4, [rsp+0x70]
00007f828abd5a6b  vpermilpd xmm4, xmm4, 0x00
00007f828abd5a71  movaps xmm3, xmm5
00007f828abd5a74  mulpd xmm3, xmm4
00007f828abd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007f828abd5a7d  ptest xmm2, xmm2
00007f828abd5a82  jnz 0x00007F828ABD6E07
00007f828abd5a88  mov [rsp+0x80], rax
00007f828abd5a90  xor eax, eax
00007f828abd5a92  mov r14d, 0x200
00007f828abd5a98  cmp r12, r14
00007f828abd5a9b  cmc
00007f828abd5a9c  lahf
00007f828abd5a9d  seto al
00007f828abd5aa0  mov [r15+0x108], eax
00007f828abd5aa7  movaps xmm5, xmm8
00007f828abd5aab  addpd xmm5, xmm15
00007f828abd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007f828abd5ab5  ptest xmm4, xmm4
00007f828abd5aba  jnz 0x00007F828ABD6F47
00007f828abd5ac0  movaps xmm8, [r15+0x1B0]
00007f828abd5ac8  movaps xmm4, xmm9
00007f828abd5acc  addpd xmm4, xmm8
00007f828abd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007f828abd5ad6  ptest xmm2, xmm2
00007f828abd5adb  jnz 0x00007F828ABD7089
00007f828abd5ae1  movaps xmm9, xmm10
00007f828abd5ae5  addpd xmm9, xmm8
00007f828abd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007f828abd5af0  ptest xmm2, xmm2
00007f828abd5af5  jnz 0x00007F828ABD71CB
00007f828abd5afb  movaps xmm10, [r15+0x2F0]
00007f828abd5b03  vmovaps [rsp+0x90], xmm10
00007f828abd5b0c  vmovaps xmm8, [rsp+0x90]
00007f828abd5b15  por xmm10, xmm8
00007f828abd5b1a  movaps xmm8, [r15+0x2E0]
00007f828abd5b22  vmovaps [rsp+0x90], xmm8
00007f828abd5b2b  vmovaps xmm2, [rsp+0x90]
00007f828abd5b34  por xmm8, xmm2
00007f828abd5b39  movaps xmm2, [r15+0x2D0]
00007f828abd5b41  vmovaps [rsp+0x90], xmm2
00007f828abd5b4a  vmovaps [rsp+0xA0], xmm1
00007f828abd5b53  vmovaps xmm1, [rsp+0x90]
00007f828abd5b5c  por xmm2, xmm1
00007f828abd5b60  movaps xmm1, [r15+0x200]
00007f828abd5b68  vmovaps [rsp+0x90], xmm1
00007f828abd5b71  vmovaps [rsp+0xB0], xmm15
00007f828abd5b7a  vmovaps xmm15, [rsp+0x90]
00007f828abd5b83  por xmm1, xmm15
00007f828abd5b88  movaps xmm15, [r15+0x1C0]
00007f828abd5b90  vmovaps [rsp+0x90], xmm15
00007f828abd5b99  vmovaps [rsp+0xC0], xmm1
00007f828abd5ba2  vmovaps xmm1, [rsp+0x90]
00007f828abd5bab  por xmm15, xmm1
00007f828abd5bb0  movaps xmm1, [r15+0x190]
00007f828abd5bb8  vmovaps [rsp+0x90], xmm1
00007f828abd5bc1  vmovaps [rsp+0xD0], xmm15
00007f828abd5bca  vmovaps xmm15, [rsp+0x90]
00007f828abd5bd3  por xmm1, xmm15
00007f828abd5bd8  movaps xmm15, [r15+0x300]
00007f828abd5be0  vmovaps [rsp+0x90], xmm15
00007f828abd5be9  vmovaps [rsp+0xE0], xmm1
00007f828abd5bf2  vmovaps xmm1, [rsp+0x90]
00007f828abd5bfb  por xmm15, xmm1
00007f828abd5c00  mov rax, [rsp+0x80]
00007f828abd5c08  lea r14, [rax+0xA0]
00007f828abd5c0f  movups xmm1, [r13+r14*1]
00007f828abd5c15  lea r14, [rax+0xB0]
00007f828abd5c1c  vmovaps [rsp+0x80], xmm1
00007f828abd5c25  movups xmm1, [r13+r14*1]
00007f828abd5c2b  vmovaps [rsp+0x90], xmm1
00007f828abd5c34  vmovaps [rsp+0xF0], xmm15
00007f828abd5c3d  vmovaps xmm15, [rsp+0xB0]
00007f828abd5c46  vmovaps [rsp+0xB0], xmm14
00007f828abd5c4f  movaps xmm1, xmm6
00007f828abd5c52  addpd xmm1, xmm15
00007f828abd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007f828abd5c5c  ptest xmm14, xmm14
00007f828abd5c62  jnz 0x00007F828ABD7323
00007f828abd5c68  lea r14, [rax+0xF0]
00007f828abd5c6f  movups xmm15, [r13+r14*1]
00007f828abd5c75  movaps xmm14, xmm4
00007f828abd5c79  addpd xmm14, xmm3
00007f828abd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007f828abd5c84  ptest xmm6, xmm6
00007f828abd5c89  jnz 0x00007F828ABD746E
00007f828abd5c8f  movaps xmm6, xmm9
00007f828abd5c93  addpd xmm6, xmm7
00007f828abd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007f828abd5c9c  ptest xmm4, xmm4
00007f828abd5ca1  jnz 0x00007F828ABD75B0
00007f828abd5ca7  vmovaps xmm9, [rsp+0x70]
00007f828abd5cad  vpermilpd xmm9, xmm9, 0x00
00007f828abd5cb3  vmovaps xmm4, [rsp+0x90]
00007f828abd5cbc  movaps xmm7, xmm4
00007f828abd5cbf  mulpd xmm7, xmm9
00007f828abd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007f828abd5cc9  ptest xmm3, xmm3
00007f828abd5cce  jnz 0x00007F828ABD76F1
00007f828abd5cd4  vmovaps xmm9, [rsp+0x50]
00007f828abd5cda  vpermilpd xmm9, xmm9, 0x00
00007f828abd5ce0  movaps xmm4, xmm15
00007f828abd5ce4  mulpd xmm4, xmm9
00007f828abd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007f828abd5cee  ptest xmm3, xmm3
00007f828abd5cf3  jnz 0x00007F828ABD7832
00007f828abd5cf9  lea r14, [rax+0xE0]
00007f828abd5d00  movups xmm15, [r13+r14*1]
00007f828abd5d06  vmovaps xmm9, [rsp+0x70]
00007f828abd5d0c  vpermilpd xmm9, xmm9, 0x00
00007f828abd5d12  vmovaps [rsp+0x70], xmm1
00007f828abd5d18  vmovaps xmm1, [rsp+0x80]
00007f828abd5d21  vmovaps [rsp+0x80], xmm15
00007f828abd5d2a  movaps xmm3, xmm1
00007f828abd5d2d  mulpd xmm3, xmm9
00007f828abd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007f828abd5d37  ptest xmm15, xmm15
00007f828abd5d3d  jnz 0x00007F828ABD797E
00007f828abd5d43  vmovaps xmm1, [rsp+0xF0]
00007f828abd5d4c  vmovaps xmm15, [rsp+0xF0]
00007f828abd5d55  por xmm1, xmm15
00007f828abd5d5a  movaps [r15+0x300], xmm1
00007f828abd5d62  vmovaps xmm15, [rsp+0xE0]
00007f828abd5d6b  vmovaps xmm9, [rsp+0xE0]
00007f828abd5d74  por xmm15, xmm9
00007f828abd5d79  movaps [r15+0x190], xmm15
00007f828abd5d81  vmovaps xmm9, [rsp+0x50]
00007f828abd5d87  vpermilpd xmm9, xmm9, 0x00
00007f828abd5d8d  vmovaps [rsp+0x90], xmm1
00007f828abd5d96  vmovaps [rsp+0xE0], xmm15
00007f828abd5d9f  vmovaps xmm15, [rsp+0x80]
00007f828abd5da8  vmovaps [rsp+0x80], xmm14
00007f828abd5db1  movaps xmm1, xmm15
00007f828abd5db5  mulpd xmm1, xmm9
00007f828abd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007f828abd5dbf  ptest xmm14, xmm14
00007f828abd5dc5  jnz 0x00007F828ABD7ABF
00007f828abd5dcb  lea r14, [rax+0x90]
00007f828abd5dd2  movups xmm15, [r13+r14*1]
00007f828abd5dd8  vmovaps xmm14, [rsp+0xD0]
00007f828abd5de1  vmovaps xmm9, [rsp+0xD0]
00007f828abd5dea  por xmm14, xmm9
00007f828abd5def  movaps [r15+0x1C0], xmm14
00007f828abd5df7  vmovaps xmm9, [rsp+0xC0]
00007f828abd5e00  vmovaps [rsp+0xD0], xmm1
00007f828abd5e09  vmovaps xmm1, [rsp+0xC0]
00007f828abd5e12  por xmm9, xmm1
00007f828abd5e17  movaps [r15+0x200], xmm9
00007f828abd5e1f  vmovaps [rsp+0xC0], xmm2
00007f828abd5e28  vmovaps xmm1, [rsp+0xC0]
00007f828abd5e31  por xmm2, xmm1
00007f828abd5e35  movaps [r15+0x2D0], xmm2
00007f828abd5e3d  vmovaps [rsp+0xC0], xmm8
00007f828abd5e46  vmovaps xmm1, [rsp+0xC0]
00007f828abd5e4f  por xmm8, xmm1
00007f828abd5e54  movaps [r15+0x2E0], xmm8
00007f828abd5e5c  vmovaps [rsp+0xC0], xmm15
00007f828abd5e65  movaps xmm1, xmm5
00007f828abd5e68  addpd xmm1, xmm7
00007f828abd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007f828abd5e71  ptest xmm15, xmm15
00007f828abd5e77  jnz 0x00007F828ABD7C0B
00007f828abd5e7d  vmovaps xmm15, [rsp+0x50]
00007f828abd5e83  vpermilpd xmm15, xmm15, 0x00
00007f828abd5e89  vmovaps xmm5, [rsp+0xC0]
00007f828abd5e92  vmovaps [rsp+0xC0], xmm1
00007f828abd5e9b  movaps xmm7, xmm5
00007f828abd5e9e  mulpd xmm7, xmm15
00007f828abd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007f828abd5ea8  ptest xmm1, xmm1
00007f828abd5ead  jnz 0x00007F828ABD7D4B
00007f828abd5eb3  lea r14, [rax+0x80]
00007f828abd5eba  movups xmm1, [r13+r14*1]
00007f828abd5ec0  vmovaps xmm5, [rsp+0x70]
00007f828abd5ec6  vmovaps [rsp+0x70], xmm1
00007f828abd5ecc  movaps xmm15, xmm5
00007f828abd5ed0  addpd xmm15, xmm3
00007f828abd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007f828abd5edb  ptest xmm1, xmm1
00007f828abd5ee0  jnz 0x00007F828ABD7E96
00007f828abd5ee6  vmovaps xmm5, [rsp+0x80]
00007f828abd5eef  movaps xmm1, xmm5
00007f828abd5ef2  addpd xmm1, xmm4
00007f828abd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007f828abd5efb  ptest xmm3, xmm3
00007f828abd5f00  jnz 0x00007F828ABD7FD8
00007f828abd5f06  vmovaps [rsp+0x80], xmm10
00007f828abd5f0f  vmovaps xmm5, [rsp+0x80]
00007f828abd5f18  por xmm10, xmm5
00007f828abd5f1d  movaps [r15+0x2F0], xmm10
00007f828abd5f25  vmovaps xmm5, [rsp+0x50]
00007f828abd5f2b  vpermilpd xmm5, xmm5, 0x00
00007f828abd5f31  vmovaps xmm3, [rsp+0x70]
00007f828abd5f37  vmovaps [rsp+0x50], xmm1
00007f828abd5f3d  movaps xmm4, xmm3
00007f828abd5f40  mulpd xmm4, xmm5
00007f828abd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007f828abd5f49  ptest xmm1, xmm1
00007f828abd5f4e  jnz 0x00007F828ABD8118
00007f828abd5f54  lea r14, [rax+0xD0]
00007f828abd5f5b  movups xmm1, [r13+r14*1]
00007f828abd5f61  vmovaps xmm3, [rsp+0xD0]
00007f828abd5f6a  vmovaps [rsp+0x70], xmm1
00007f828abd5f70  movaps xmm5, xmm6
00007f828abd5f73  addpd xmm5, xmm3
00007f828abd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007f828abd5f7c  ptest xmm1, xmm1
00007f828abd5f81  jnz 0x00007F828ABD8262
00007f828abd5f87  vmovaps xmm1, [rsp+0x60]
00007f828abd5f8d  vpermilpd xmm1, xmm1, 0x00
00007f828abd5f93  movaps xmm6, xmm9
00007f828abd5f97  mulpd xmm6, xmm1
00007f828abd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007f828abd5fa0  ptest xmm3, xmm3
00007f828abd5fa5  jnz 0x00007F828ABD83A2
00007f828abd5fab  movaps [r15+0x260], xmm6
00007f828abd5fb3  vxorps xmm1, xmm1, xmm1
00007f828abd5fb7  vpbroadcastq xmm1, xmm1
00007f828abd5fbc  movaps [r15+0x1B0], xmm1
00007f828abd5fc4  vmovaps xmm1, [rsp+0x60]
00007f828abd5fca  vpermilpd xmm1, xmm1, 0x00
00007f828abd5fd0  vmovaps xmm3, [rsp+0x70]
00007f828abd5fd6  vmovaps [rsp+0x70], xmm15
00007f828abd5fdc  movaps xmm9, xmm3
00007f828abd5fe0  mulpd xmm9, xmm1
00007f828abd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007f828abd5feb  ptest xmm15, xmm15
00007f828abd5ff1  jnz 0x00007F828ABD84E3
00007f828abd5ff7  lea r14, [rax+0xC0]
00007f828abd5ffe  movups xmm1, [r13+r14*1]
00007f828abd6004  vmovaps xmm3, [rsp+0xC0]
00007f828abd600d  vmovaps [rsp+0x80], xmm1
00007f828abd6016  movaps xmm15, xmm3
00007f828abd601a  addpd xmm15, xmm7
00007f828abd601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007f828abd6025  ptest xmm1, xmm1
00007f828abd602a  jnz 0x00007F828ABD862F
00007f828abd6030  vmovaps [rsp+0xC0], xmm13
00007f828abd6039  vmovaps xmm1, [rsp+0xC0]
00007f828abd6042  por xmm13, xmm1
00007f828abd6047  movaps [r15+0x270], xmm13
00007f828abd604f  vmovaps xmm1, [rsp+0xB0]
00007f828abd6058  vmovaps xmm7, [rsp+0xB0]
00007f828abd6061  por xmm1, xmm7
00007f828abd6065  movaps [r15+0x1A0], xmm1
00007f828abd606d  vmovaps xmm1, [rsp+0x60]
00007f828abd6073  vpermilpd xmm1, xmm1, 0x00
00007f828abd6079  vmovaps [rsp+0xB0], xmm1
00007f828abd6082  vmovaps xmm1, [rsp+0x80]
00007f828abd608b  vmovaps [rsp+0x80], xmm15
00007f828abd6094  vmovaps xmm15, [rsp+0xB0]
00007f828abd609d  vmovaps [rsp+0xB0], xmm14
00007f828abd60a6  movaps xmm3, xmm1
00007f828abd60a9  mulpd xmm3, xmm15
00007f828abd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007f828abd60b3  ptest xmm14, xmm14
00007f828abd60b9  jnz 0x00007F828ABD8771
00007f828abd60bf  lea r14, [rax+0x20]
00007f828abd60c3  movups xmm1, [r13+r14*1]
00007f828abd60c9  movaps [r15+0x110], xmm1
00007f828abd60d1  vmovaps xmm14, [rsp+0x70]
00007f828abd60d7  vmovaps [rsp+0x70], xmm1
00007f828abd60dd  movaps xmm15, xmm14
00007f828abd60e1  addpd xmm15, xmm4
00007f828abd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007f828abd60ec  ptest xmm1, xmm1
00007f828abd60f1  jnz 0x00007F828ABD88BC
00007f828abd60f7  vmovaps xmm1, [rsp+0x60]
00007f828abd60fd  vpermilpd xmm1, xmm1, 0x00
00007f828abd6103  movaps xmm14, xmm2
00007f828abd6107  mulpd xmm14, xmm1
00007f828abd610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007f828abd6112  ptest xmm4, xmm4
00007f828abd6117  jnz 0x00007F828ABD89FF
00007f828abd611d  vmovaps xmm4, [rsp+0x50]
00007f828abd6123  movaps xmm1, xmm4
00007f828abd6126  addpd xmm1, xmm9
00007f828abd612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007f828abd6130  ptest xmm2, xmm2
00007f828abd6135  jnz 0x00007F828ABD8B41
00007f828abd613b  vmovaps xmm9, [rsp+0x30]
00007f828abd6141  vpermilpd xmm9, xmm9, 0x00
00007f828abd6147  vmovaps xmm2, [rsp+0x70]
00007f828abd614d  vmovaps [rsp+0x50], xmm1
00007f828abd6153  movaps xmm4, xmm2
00007f828abd6156  mulpd xmm4, xmm9
00007f828abd615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007f828abd6160  ptest xmm1, xmm1
00007f828abd6165  jnz 0x00007F828ABD8C82
00007f828abd616b  vmovaps xmm1, [rsp+0x30]
00007f828abd6171  vpermilpd xmm1, xmm1, 0x00
00007f828abd6177  vmovaps xmm2, [rsp+0x90]
00007f828abd6180  vmovaps [rsp+0x60], xmm15
00007f828abd6186  movaps xmm9, xmm2
00007f828abd618a  mulpd xmm9, xmm1
00007f828abd618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007f828abd6195  ptest xmm15, xmm15
00007f828abd619b  jnz 0x00007F828ABD8DC3
00007f828abd61a1  vmovaps xmm15, [rsp+0x80]
00007f828abd61aa  movaps xmm1, xmm15
00007f828abd61ae  addpd xmm1, xmm6
00007f828abd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007f828abd61b7  ptest xmm2, xmm2
00007f828abd61bc  jnz 0x00007F828ABD8F05
00007f828abd61c2  movaps xmm15, xmm5
00007f828abd61c6  addpd xmm15, xmm3
00007f828abd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007f828abd61d1  ptest xmm6, xmm6
00007f828abd61d6  jnz 0x00007F828ABD9046
00007f828abd61dc  vmovaps xmm6, [rsp+0x30]
00007f828abd61e2  vpermilpd xmm6, xmm6, 0x00
00007f828abd61e8  movaps xmm5, xmm8
00007f828abd61ec  mulpd xmm5, xmm6
00007f828abd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007f828abd61f5  ptest xmm3, xmm3
00007f828abd61fa  jnz 0x00007F828ABD9188
00007f828abd6200  vmovaps xmm8, [rsp+0x30]
00007f828abd6206  vpermilpd xmm8, xmm8, 0x00
00007f828abd620c  movaps xmm6, xmm10
00007f828abd6210  mulpd xmm6, xmm8
00007f828abd6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007f828abd621a  ptest xmm3, xmm3
00007f828abd621f  jnz 0x00007F828ABD92C9
00007f828abd6225  vmovaps xmm8, [rsp+0x60]
00007f828abd622b  movaps xmm10, xmm8
00007f828abd622f  addpd xmm10, xmm14
00007f828abd6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007f828abd623a  ptest xmm3, xmm3
00007f828abd623f  jnz 0x00007F828ABD940B
00007f828abd6245  vmovaps xmm8, [rsp+0x50]
00007f828abd624b  movaps xmm14, xmm8
00007f828abd624f  addpd xmm14, xmm4
00007f828abd6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007f828abd625a  ptest xmm3, xmm3
00007f828abd625f  jnz 0x00007F828ABD954F
00007f828abd6265  vmovaps xmm8, [rsp+0x40]
00007f828abd626b  vpermilpd xmm8, xmm8, 0x00
00007f828abd6271  movaps xmm4, xmm13
00007f828abd6275  mulpd xmm4, xmm8
00007f828abd627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007f828abd627f  ptest xmm3, xmm3
00007f828abd6284  jnz 0x00007F828ABD9692
00007f828abd628a  movaps xmm13, xmm15
00007f828abd628e  addpd xmm13, xmm9
00007f828abd6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007f828abd6299  ptest xmm8, xmm8
00007f828abd629f  jnz 0x00007F828ABD97D4
00007f828abd62a5  movaps xmm15, xmm1
00007f828abd62a9  addpd xmm15, xmm5
00007f828abd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007f828abd62b4  ptest xmm9, xmm9
00007f828abd62ba  jnz 0x00007F828ABD9918
00007f828abd62c0  vmovaps [rsp+0x30], xmm11
00007f828abd62c6  vmovaps xmm1, [rsp+0x30]
00007f828abd62cc  por xmm11, xmm1
00007f828abd62d1  movaps [r15+0x250], xmm11
00007f828abd62d9  vmovaps [rsp+0x30], xmm12
00007f828abd62df  vmovaps xmm1, [rsp+0x30]
00007f828abd62e5  por xmm12, xmm1
00007f828abd62ea  movaps [r15+0x2A0], xmm12
00007f828abd62f2  vmovaps xmm1, [rsp+0xA0]
00007f828abd62fb  vmovaps xmm11, [rsp+0xA0]
00007f828abd6304  por xmm1, xmm11
00007f828abd6309  movaps [r15+0x1D0], xmm1
00007f828abd6311  lea r14, [rax+0x40]
00007f828abd6315  movups xmm1, [r13+r14*1]
00007f828abd631b  movaps [r15+0x2C0], xmm1
00007f828abd6323  vmovaps xmm11, [rsp+0x40]
00007f828abd6329  vpermilpd xmm11, xmm11, 0x00
00007f828abd632f  vmovaps xmm8, [rsp+0xE0]
00007f828abd6338  movaps xmm9, xmm8
00007f828abd633c  mulpd xmm9, xmm11
00007f828abd6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007f828abd6347  ptest xmm5, xmm5
00007f828abd634c  jnz 0x00007F828ABD9A64
00007f828abd6352  movaps xmm11, xmm10
00007f828abd6356  addpd xmm11, xmm6
00007f828abd635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007f828abd6361  ptest xmm8, xmm8
00007f828abd6367  jnz 0x00007F828ABD9BA8
00007f828abd636d  movaps xmm10, xmm14
00007f828abd6371  addpd xmm10, xmm4
00007f828abd6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007f828abd637c  ptest xmm8, xmm8
00007f828abd6382  jnz 0x00007F828ABD9CEB
00007f828abd6388  vmovaps xmm14, [rsp+0x40]
00007f828abd638e  vpermilpd xmm14, xmm14, 0x00
00007f828abd6394  movaps xmm8, xmm1
00007f828abd6398  mulpd xmm8, xmm14
00007f828abd639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007f828abd63a3  ptest xmm6, xmm6
00007f828abd63a8  jnz 0x00007F828ABD9E2E
00007f828abd63ae  movaps xmm1, [r15+0x2B0]
00007f828abd63b6  vmovaps xmm14, [rsp+0x40]
00007f828abd63bc  vpermilpd xmm14, xmm14, 0x00
00007f828abd63c2  movaps xmm6, xmm1
00007f828abd63c5  mulpd xmm6, xmm14
00007f828abd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007f828abd63cf  ptest xmm5, xmm5
00007f828abd63d4  jnz 0x00007F828ABD9F71
00007f828abd63da  vmovaps xmm1, [rsp+0x10]
00007f828abd63e0  vpermilpd xmm1, xmm1, 0x00
00007f828abd63e6  movaps xmm14, xmm12
00007f828abd63ea  mulpd xmm14, xmm1
00007f828abd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007f828abd63f5  ptest xmm5, xmm5
00007f828abd63fa  jnz 0x00007F828ABDA0B2
00007f828abd6400  movaps xmm1, xmm13
00007f828abd6404  addpd xmm1, xmm9
00007f828abd6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007f828abd640e  ptest xmm12, xmm12
00007f828abd6414  jnz 0x00007F828ABDA1F5
00007f828abd641a  vmovaps xmm13, [rsp+0x10]
00007f828abd6420  vpermilpd xmm13, xmm13, 0x00
00007f828abd6426  movaps xmm12, xmm7
00007f828abd642a  mulpd xmm12, xmm13
00007f828abd642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007f828abd6435  ptest xmm9, xmm9
00007f828abd643b  jnz 0x00007F828ABDA337
00007f828abd6441  movaps xmm13, xmm15
00007f828abd6445  addpd xmm13, xmm8
00007f828abd644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007f828abd6450  ptest xmm9, xmm9
00007f828abd6456  jnz 0x00007F828ABDA47A
00007f828abd645c  movaps xmm15, [r15+0x290]
00007f828abd6464  vmovaps xmm9, [rsp+0x10]
00007f828abd646a  vpermilpd xmm9, xmm9, 0x00
00007f828abd6470  movaps xmm8, xmm15
00007f828abd6474  mulpd xmm8, xmm9
00007f828abd6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007f828abd647f  ptest xmm7, xmm7
00007f828abd6484  jnz 0x00007F828ABDA5BE
00007f828abd648a  movaps xmm15, xmm11
00007f828abd648e  addpd xmm15, xmm6
00007f828abd6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007f828abd6499  ptest xmm9, xmm9
00007f828abd649f  jnz 0x00007F828ABDA702
00007f828abd64a5  movaps xmm11, [r15+0x1E0]
00007f828abd64ad  vmovaps xmm9, [rsp+0x10]
00007f828abd64b3  vpermilpd xmm9, xmm9, 0x00
00007f828abd64b9  movaps xmm7, xmm11
00007f828abd64bd  mulpd xmm7, xmm9
00007f828abd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007f828abd64c7  ptest xmm6, xmm6
00007f828abd64cc  jnz 0x00007F828ABDA845
00007f828abd64d2  movaps xmm11, xmm10
00007f828abd64d6  addpd xmm11, xmm14
00007f828abd64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007f828abd64e1  ptest xmm9, xmm9
00007f828abd64e7  jnz 0x00007F828ABDA987
00007f828abd64ed  lea r14, [rax+0x70]
00007f828abd64f1  movups xmm14, [r13+r14*1]
00007f828abd64f7  movaps [r15+0x240], xmm14
00007f828abd64ff  movaps xmm10, xmm1
00007f828abd6503  addpd xmm10, xmm12
00007f828abd6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007f828abd650e  ptest xmm9, xmm9
00007f828abd6514  jnz 0x00007F828ABDAAD5
00007f828abd651a  movaps [r15+0x170], xmm10
00007f828abd6522  vmovaps xmm1, [rsp+0x20]
00007f828abd6528  vpermilpd xmm1, xmm1, 0x00
00007f828abd652e  movaps xmm12, xmm14
00007f828abd6532  mulpd xmm12, xmm1
00007f828abd6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007f828abd653d  ptest xmm9, xmm9
00007f828abd6543  jnz 0x00007F828ABDAC18
00007f828abd6549  vmovaps xmm1, [rsp+0x20]
00007f828abd654f  vpermilpd xmm1, xmm1, 0x00
00007f828abd6555  vmovaps xmm9, [rsp+0xB0]
00007f828abd655e  movaps xmm14, xmm9
00007f828abd6562  mulpd xmm14, xmm1
00007f828abd6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007f828abd656d  ptest xmm6, xmm6
00007f828abd6572  jnz 0x00007F828ABDAD5B
00007f828abd6578  movaps [r15+0x180], xmm14
00007f828abd6580  movaps xmm1, xmm13
00007f828abd6584  addpd xmm1, xmm8
00007f828abd6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007f828abd658e  ptest xmm9, xmm9
00007f828abd6594  jnz 0x00007F828ABDAE9E
00007f828abd659a  movaps [r15+0x210], xmm1
00007f828abd65a2  movups xmm13, [r13+rax*1]
00007f828abd65a8  lea r14, [rax+0x10]
00007f828abd65ac  movups xmm9, [r13+r14*1]
00007f828abd65b2  movaps [r15+0x230], xmm9
00007f828abd65ba  movaps xmm8, xmm15
00007f828abd65be  addpd xmm8, xmm7
00007f828abd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007f828abd65c9  ptest xmm6, xmm6
00007f828abd65ce  jnz 0x00007F828ABDAFF4
00007f828abd65d4  movaps [r15+0x130], xmm8
00007f828abd65dc  vmovaps xmm15, [rsp+0x20]
00007f828abd65e2  vpermilpd xmm15, xmm15, 0x00
00007f828abd65e8  movaps xmm7, xmm9
00007f828abd65ec  mulpd xmm7, xmm15
00007f828abd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007f828abd65f6  ptest xmm6, xmm6
00007f828abd65fb  jnz 0x00007F828ABDB137
00007f828abd6601  movaps [r15+0x220], xmm7
00007f828abd6609  vmovaps xmm15, [rsp+0x20]
00007f828abd660f  vpermilpd xmm15, xmm15, 0x00
00007f828abd6615  movaps xmm9, xmm13
00007f828abd6619  mulpd xmm9, xmm15
00007f828abd661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007f828abd6624  ptest xmm6, xmm6
00007f828abd6629  jnz 0x00007F828ABDB279
00007f828abd662f  movaps xmm15, xmm11
00007f828abd6633  addpd xmm15, xmm12
00007f828abd6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007f828abd663e  ptest xmm13, xmm13
00007f828abd6644  jnz 0x00007F828ABDB3BD
00007f828abd664a  movaps [r15+0x140], xmm15
00007f828abd6652  movaps xmm13, xmm10
00007f828abd6656  addpd xmm13, xmm14
00007f828abd665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007f828abd6661  ptest xmm12, xmm12
00007f828abd6667  jnz 0x00007F828ABDB501
00007f828abd666d  movaps [r15+0x150], xmm13
00007f828abd6675  movaps xmm14, xmm1
00007f828abd6679  addpd xmm14, xmm7
00007f828abd667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007f828abd6684  ptest xmm12, xmm12
00007f828abd668a  jnz 0x00007F828ABDB645
00007f828abd6690  movaps [r15+0x160], xmm14
00007f828abd6698  movaps xmm1, xmm8
00007f828abd669c  addpd xmm1, xmm9
00007f828abd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007f828abd66a6  ptest xmm12, xmm12
00007f828abd66ac  jnz 0x00007F828ABDB787
00007f828abd66b2  movaps [r15+0x120], xmm1
00007f828abd66ba  movups [r13+r11*1], xmm15
00007f828abd66c0  lea rax, [r11+0x10]
00007f828abd66c4  movups [r13+rax*1], xmm13
00007f828abd66ca  lea rax, [r11+0x20]
00007f828abd66ce  movups [r13+rax*1], xmm14
00007f828abd66d4  lea rax, [r11+0x30]
00007f828abd66d8  movups [r13+rax*1], xmm1
00007f828abd66de  mov eax, [r15+0x108]
00007f828abd66e5  sahf
00007f828abd66e6  jnz 0x00007F828ABD6718
00007f828abd66e8  cmp dword ptr [r15+0x318], 0x00
00007f828abd66f0  jz 0x00007F828ABDB900
00007f828abd66f6  nop [rax+rax*1], ax
00007f828abd66ff  nop [rax+rax*1], eax
00007f828abd6707  mov eax, 0x410444
00007f828abd670c  mov [r15+0x100], rax
00007f828abd6713  jmp 0x00007F828A9FE110
00007f828abd6718  cmp dword ptr [r15+0x318], 0x00
00007f828abd6720  jz 0x00007F828ABD57E0
00007f828abd6726  nop [rax+rax*1], ax
00007f828abd672f  nop [rax+rax*1], eax
00007f828abd6737  mov eax, 0x410278
00007f828abd673c  mov [r15+0x100], rax
00007f828abd6743  jmp 0x00007F828A9FE110
00007f828abd6748  int3
00007f828abd6749  call 0x00007F828AA0A4B0
00007f828abd674e  jmp 0x00007F828ABD5828
00007f828abd6753  call 0x00007F828AA09240
00007f828abd6758  jmp 0x00007F828ABD5832
00007f828abd675d  call 0x00007F828AA0A4B0
00007f828abd6762  jmp 0x00007F828ABD588F
00007f828abd6767  call 0x00007F828AA09240
00007f828abd676c  jmp 0x00007F828ABD5899
00007f828abd6771  call 0x00007F828AA0A4B0
00007f828abd6776  jmp 0x00007F828ABD58DD
00007f828abd677b  call 0x00007F828AA09240
00007f828abd6780  jmp 0x00007F828ABD58E7
00007f828abd6785  call 0x00007F828AAB47C0
00007f828abd678a  jmp 0x00007F828ABD5926
00007f828abd678f  call 0x00007F828AA0B720
00007f828abd6794  jmp 0x00007F828ABD593A
00007f828abd6799  call 0x00007F828AABFC30
00007f828abd679e  jmp 0x00007F828ABD5958
00007f828abd67a3  call 0x00007F828AABE9C0
00007f828abd67a8  jmp 0x00007F828ABD5962
00007f828abd67ad  call 0x00007F828AABD750
00007f828abd67b2  jmp 0x00007F828ABD596C
00007f828abd67b7  sub rsp, 0x08
00007f828abd67bb  push rax
00007f828abd67bc  push rcx
00007f828abd67bd  push rdx
00007f828abd67be  push rdi
00007f828abd67bf  push rsi
00007f828abd67c0  push r8
00007f828abd67c2  push r9
00007f828abd67c4  push r10
00007f828abd67c6  push r11
00007f828abd67c8  sub rsp, 0xF0
00007f828abd67cf  vmovaps [rsp], xmm0
00007f828abd67d4  vmovaps [rsp+0x10], xmm1
00007f828abd67da  vmovaps [rsp+0x20], xmm2
00007f828abd67e0  vmovaps [rsp+0x30], xmm3
00007f828abd67e6  vmovaps [rsp+0x40], xmm4
00007f828abd67ec  vmovaps [rsp+0x50], xmm5
00007f828abd67f2  vmovaps [rsp+0x60], xmm6
00007f828abd67f8  vmovaps [rsp+0x70], xmm7
00007f828abd67fe  vmovaps [rsp+0x80], xmm9
00007f828abd6807  vmovaps [rsp+0x90], xmm10
00007f828abd6810  vmovaps [rsp+0xA0], xmm11
00007f828abd6819  vmovaps [rsp+0xB0], xmm12
00007f828abd6822  vmovaps [rsp+0xC0], xmm13
00007f828abd682b  vmovaps [rsp+0xD0], xmm14
00007f828abd6834  vmovaps [rsp+0xE0], xmm15
00007f828abd683d  sub rsp, 0x30
00007f828abd6841  movaps [rsp], xmm8
00007f828abd6846  movaps [rsp+0x10], xmm12
00007f828abd684c  movaps [rsp+0x20], xmm15
00007f828abd6852  lea rdi, [rsp]
00007f828abd6856  mov esi, 0x00
00007f828abd685b  mov rax, 0x5BFE27FA6530
00007f828abd6865  call rax
00007f828abd6867  movaps xmm8, [rsp]
00007f828abd686c  add rsp, 0x30
00007f828abd6870  vmovaps xmm0, [rsp]
00007f828abd6875  vmovaps xmm1, [rsp+0x10]
00007f828abd687b  vmovaps xmm2, [rsp+0x20]
00007f828abd6881  vmovaps xmm3, [rsp+0x30]
00007f828abd6887  vmovaps xmm4, [rsp+0x40]
00007f828abd688d  vmovaps xmm5, [rsp+0x50]
00007f828abd6893  vmovaps xmm6, [rsp+0x60]
00007f828abd6899  vmovaps xmm7, [rsp+0x70]
00007f828abd689f  vmovaps xmm9, [rsp+0x80]
00007f828abd68a8  vmovaps xmm10, [rsp+0x90]
00007f828abd68b1  vmovaps xmm11, [rsp+0xA0]
00007f828abd68ba  vmovaps xmm12, [rsp+0xB0]
00007f828abd68c3  vmovaps xmm13, [rsp+0xC0]
00007f828abd68cc  vmovaps xmm14, [rsp+0xD0]
00007f828abd68d5  vmovaps xmm15, [rsp+0xE0]
00007f828abd68de  add rsp, 0xF0
00007f828abd68e5  pop r11
00007f828abd68e7  pop r10
00007f828abd68e9  pop r9
00007f828abd68eb  pop r8
00007f828abd68ed  pop rsi
00007f828abd68ee  pop rdi
00007f828abd68ef  pop rdx
00007f828abd68f0  pop rcx
00007f828abd68f1  pop rax
00007f828abd68f2  add rsp, 0x08
00007f828abd68f6  jmp 0x00007F828ABD599A
00007f828abd68fb  sub rsp, 0x08
00007f828abd68ff  push rax
00007f828abd6900  push rcx
00007f828abd6901  push rdx
00007f828abd6902  push rdi
00007f828abd6903  push rsi
00007f828abd6904  push r8
00007f828abd6906  push r9
00007f828abd6908  push r10
00007f828abd690a  push r11
00007f828abd690c  sub rsp, 0xF0
00007f828abd6913  vmovaps [rsp], xmm0
00007f828abd6918  vmovaps [rsp+0x10], xmm1
00007f828abd691e  vmovaps [rsp+0x20], xmm2
00007f828abd6924  vmovaps [rsp+0x30], xmm3
00007f828abd692a  vmovaps [rsp+0x40], xmm4
00007f828abd6930  vmovaps [rsp+0x50], xmm5
00007f828abd6936  vmovaps [rsp+0x60], xmm6
00007f828abd693c  vmovaps [rsp+0x70], xmm8
00007f828abd6942  vmovaps [rsp+0x80], xmm9
00007f828abd694b  vmovaps [rsp+0x90], xmm10
00007f828abd6954  vmovaps [rsp+0xA0], xmm11
00007f828abd695d  vmovaps [rsp+0xB0], xmm12
00007f828abd6966  vmovaps [rsp+0xC0], xmm13
00007f828abd696f  vmovaps [rsp+0xD0], xmm14
00007f828abd6978  vmovaps [rsp+0xE0], xmm15
00007f828abd6981  sub rsp, 0x30
00007f828abd6985  movaps [rsp], xmm7
00007f828abd6989  movaps [rsp+0x10], xmm9
00007f828abd698f  movaps [rsp+0x20], xmm15
00007f828abd6995  lea rdi, [rsp]
00007f828abd6999  mov esi, 0x00
00007f828abd699e  mov rax, 0x5BFE27FA6530
00007f828abd69a8  call rax
00007f828abd69aa  movaps xmm7, [rsp]
00007f828abd69ae  add rsp, 0x30
00007f828abd69b2  vmovaps xmm0, [rsp]
00007f828abd69b7  vmovaps xmm1, [rsp+0x10]
00007f828abd69bd  vmovaps xmm2, [rsp+0x20]
00007f828abd69c3  vmovaps xmm3, [rsp+0x30]
00007f828abd69c9  vmovaps xmm4, [rsp+0x40]
00007f828abd69cf  vmovaps xmm5, [rsp+0x50]
00007f828abd69d5  vmovaps xmm6, [rsp+0x60]
00007f828abd69db  vmovaps xmm8, [rsp+0x70]
00007f828abd69e1  vmovaps xmm9, [rsp+0x80]
00007f828abd69ea  vmovaps xmm10, [rsp+0x90]
00007f828abd69f3  vmovaps xmm11, [rsp+0xA0]
00007f828abd69fc  vmovaps xmm12, [rsp+0xB0]
00007f828abd6a05  vmovaps xmm13, [rsp+0xC0]
00007f828abd6a0e  vmovaps xmm14, [rsp+0xD0]
00007f828abd6a17  vmovaps xmm15, [rsp+0xE0]
00007f828abd6a20  add rsp, 0xF0
00007f828abd6a27  pop r11
00007f828abd6a29  pop r10
00007f828abd6a2b  pop r9
00007f828abd6a2d  pop r8
00007f828abd6a2f  pop rsi
00007f828abd6a30  pop rdi
00007f828abd6a31  pop rdx
00007f828abd6a32  pop rcx
00007f828abd6a33  pop rax
00007f828abd6a34  add rsp, 0x08
00007f828abd6a38  jmp 0x00007F828ABD59C8
00007f828abd6a3d  sub rsp, 0x08
00007f828abd6a41  push rax
00007f828abd6a42  push rcx
00007f828abd6a43  push rdx
00007f828abd6a44  push rdi
00007f828abd6a45  push rsi
00007f828abd6a46  push r8
00007f828abd6a48  push r9
00007f828abd6a4a  push r10
00007f828abd6a4c  push r11
00007f828abd6a4e  sub rsp, 0xF0
00007f828abd6a55  vmovaps [rsp], xmm0
00007f828abd6a5a  vmovaps [rsp+0x10], xmm1
00007f828abd6a60  vmovaps [rsp+0x20], xmm2
00007f828abd6a66  vmovaps [rsp+0x30], xmm3
00007f828abd6a6c  vmovaps [rsp+0x40], xmm4
00007f828abd6a72  vmovaps [rsp+0x50], xmm5
00007f828abd6a78  vmovaps [rsp+0x60], xmm6
00007f828abd6a7e  vmovaps [rsp+0x70], xmm7
00007f828abd6a84  vmovaps [rsp+0x80], xmm8
00007f828abd6a8d  vmovaps [rsp+0x90], xmm10
00007f828abd6a96  vmovaps [rsp+0xA0], xmm11
00007f828abd6a9f  vmovaps [rsp+0xB0], xmm12
00007f828abd6aa8  vmovaps [rsp+0xC0], xmm13
00007f828abd6ab1  vmovaps [rsp+0xD0], xmm14
00007f828abd6aba  vmovaps [rsp+0xE0], xmm15
00007f828abd6ac3  sub rsp, 0x30
00007f828abd6ac7  movaps [rsp], xmm9
00007f828abd6acc  movaps [rsp+0x10], xmm12
00007f828abd6ad2  movaps [rsp+0x20], xmm10
00007f828abd6ad8  lea rdi, [rsp]
00007f828abd6adc  mov esi, 0x00
00007f828abd6ae1  mov rax, 0x5BFE27FA6530
00007f828abd6aeb  call rax
00007f828abd6aed  movaps xmm9, [rsp]
00007f828abd6af2  add rsp, 0x30
00007f828abd6af6  vmovaps xmm0, [rsp]
00007f828abd6afb  vmovaps xmm1, [rsp+0x10]
00007f828abd6b01  vmovaps xmm2, [rsp+0x20]
00007f828abd6b07  vmovaps xmm3, [rsp+0x30]
00007f828abd6b0d  vmovaps xmm4, [rsp+0x40]
00007f828abd6b13  vmovaps xmm5, [rsp+0x50]
00007f828abd6b19  vmovaps xmm6, [rsp+0x60]
00007f828abd6b1f  vmovaps xmm7, [rsp+0x70]
00007f828abd6b25  vmovaps xmm8, [rsp+0x80]
00007f828abd6b2e  vmovaps xmm10, [rsp+0x90]
00007f828abd6b37  vmovaps xmm11, [rsp+0xA0]
00007f828abd6b40  vmovaps xmm12, [rsp+0xB0]
00007f828abd6b49  vmovaps xmm13, [rsp+0xC0]
00007f828abd6b52  vmovaps xmm14, [rsp+0xD0]
00007f828abd6b5b  vmovaps xmm15, [rsp+0xE0]
00007f828abd6b64  add rsp, 0xF0
00007f828abd6b6b  pop r11
00007f828abd6b6d  pop r10
00007f828abd6b6f  pop r9
00007f828abd6b71  pop r8
00007f828abd6b73  pop rsi
00007f828abd6b74  pop rdi
00007f828abd6b75  pop rdx
00007f828abd6b76  pop rcx
00007f828abd6b77  pop rax
00007f828abd6b78  add rsp, 0x08
00007f828abd6b7c  jmp 0x00007F828ABD59EC
00007f828abd6b81  sub rsp, 0x08
00007f828abd6b85  push rax
00007f828abd6b86  push rcx
00007f828abd6b87  push rdx
00007f828abd6b88  push rdi
00007f828abd6b89  push rsi
00007f828abd6b8a  push r8
00007f828abd6b8c  push r9
00007f828abd6b8e  push r10
00007f828abd6b90  push r11
00007f828abd6b92  sub rsp, 0xF0
00007f828abd6b99  vmovaps [rsp], xmm0
00007f828abd6b9e  vmovaps [rsp+0x10], xmm1
00007f828abd6ba4  vmovaps [rsp+0x20], xmm2
00007f828abd6baa  vmovaps [rsp+0x30], xmm3
00007f828abd6bb0  vmovaps [rsp+0x40], xmm4
00007f828abd6bb6  vmovaps [rsp+0x50], xmm5
00007f828abd6bbc  vmovaps [rsp+0x60], xmm6
00007f828abd6bc2  vmovaps [rsp+0x70], xmm7
00007f828abd6bc8  vmovaps [rsp+0x80], xmm8
00007f828abd6bd1  vmovaps [rsp+0x90], xmm9
00007f828abd6bda  vmovaps [rsp+0xA0], xmm11
00007f828abd6be3  vmovaps [rsp+0xB0], xmm12
00007f828abd6bec  vmovaps [rsp+0xC0], xmm13
00007f828abd6bf5  vmovaps [rsp+0xD0], xmm14
00007f828abd6bfe  vmovaps [rsp+0xE0], xmm15
00007f828abd6c07  sub rsp, 0x30
00007f828abd6c0b  movaps [rsp], xmm10
00007f828abd6c10  movaps [rsp+0x10], xmm12
00007f828abd6c16  movaps [rsp+0x20], xmm11
00007f828abd6c1c  lea rdi, [rsp]
00007f828abd6c20  mov esi, 0x00
00007f828abd6c25  mov rax, 0x5BFE27FA6530
00007f828abd6c2f  call rax
00007f828abd6c31  movaps xmm10, [rsp]
00007f828abd6c36  add rsp, 0x30
00007f828abd6c3a  vmovaps xmm0, [rsp]
00007f828abd6c3f  vmovaps xmm1, [rsp+0x10]
00007f828abd6c45  vmovaps xmm2, [rsp+0x20]
00007f828abd6c4b  vmovaps xmm3, [rsp+0x30]
00007f828abd6c51  vmovaps xmm4, [rsp+0x40]
00007f828abd6c57  vmovaps xmm5, [rsp+0x50]
00007f828abd6c5d  vmovaps xmm6, [rsp+0x60]
00007f828abd6c63  vmovaps xmm7, [rsp+0x70]
00007f828abd6c69  vmovaps xmm8, [rsp+0x80]
00007f828abd6c72  vmovaps xmm9, [rsp+0x90]
00007f828abd6c7b  vmovaps xmm11, [rsp+0xA0]
00007f828abd6c84  vmovaps xmm12, [rsp+0xB0]
00007f828abd6c8d  vmovaps xmm13, [rsp+0xC0]
00007f828abd6c96  vmovaps xmm14, [rsp+0xD0]
00007f828abd6c9f  vmovaps xmm15, [rsp+0xE0]
00007f828abd6ca8  add rsp, 0xF0
00007f828abd6caf  pop r11
00007f828abd6cb1  pop r10
00007f828abd6cb3  pop r9
00007f828abd6cb5  pop r8
00007f828abd6cb7  pop rsi
00007f828abd6cb8  pop rdi
00007f828abd6cb9  pop rdx
00007f828abd6cba  pop rcx
00007f828abd6cbb  pop rax
00007f828abd6cbc  add rsp, 0x08
00007f828abd6cc0  jmp 0x00007F828ABD5A06
00007f828abd6cc5  sub rsp, 0x08
00007f828abd6cc9  push rax
00007f828abd6cca  push rcx
00007f828abd6ccb  push rdx
00007f828abd6ccc  push rdi
00007f828abd6ccd  push rsi
00007f828abd6cce  push r8
00007f828abd6cd0  push r9
00007f828abd6cd2  push r10
00007f828abd6cd4  push r11
00007f828abd6cd6  sub rsp, 0xF0
00007f828abd6cdd  vmovaps [rsp], xmm0
00007f828abd6ce2  vmovaps [rsp+0x10], xmm1
00007f828abd6ce8  vmovaps [rsp+0x20], xmm2
00007f828abd6cee  vmovaps [rsp+0x30], xmm3
00007f828abd6cf4  vmovaps [rsp+0x40], xmm4
00007f828abd6cfa  vmovaps [rsp+0x50], xmm5
00007f828abd6d00  vmovaps [rsp+0x60], xmm7
00007f828abd6d06  vmovaps [rsp+0x70], xmm8
00007f828abd6d0c  vmovaps [rsp+0x80], xmm9
00007f828abd6d15  vmovaps [rsp+0x90], xmm10
00007f828abd6d1e  vmovaps [rsp+0xA0], xmm11
00007f828abd6d27  vmovaps [rsp+0xB0], xmm12
00007f828abd6d30  vmovaps [rsp+0xC0], xmm13
00007f828abd6d39  vmovaps [rsp+0xD0], xmm14
00007f828abd6d42  vmovaps [rsp+0xE0], xmm15
00007f828abd6d4b  sub rsp, 0x30
00007f828abd6d4f  movaps [rsp], xmm6
00007f828abd6d53  movaps [rsp+0x10], xmm12
00007f828abd6d59  movaps [rsp+0x20], xmm11
00007f828abd6d5f  lea rdi, [rsp]
00007f828abd6d63  mov esi, 0x00
00007f828abd6d68  mov rax, 0x5BFE27FA6530
00007f828abd6d72  call rax
00007f828abd6d74  movaps xmm6, [rsp]
00007f828abd6d78  add rsp, 0x30
00007f828abd6d7c  vmovaps xmm0, [rsp]
00007f828abd6d81  vmovaps xmm1, [rsp+0x10]
00007f828abd6d87  vmovaps xmm2, [rsp+0x20]
00007f828abd6d8d  vmovaps xmm3, [rsp+0x30]
00007f828abd6d93  vmovaps xmm4, [rsp+0x40]
00007f828abd6d99  vmovaps xmm5, [rsp+0x50]
00007f828abd6d9f  vmovaps xmm7, [rsp+0x60]
00007f828abd6da5  vmovaps xmm8, [rsp+0x70]
00007f828abd6dab  vmovaps xmm9, [rsp+0x80]
00007f828abd6db4  vmovaps xmm10, [rsp+0x90]
00007f828abd6dbd  vmovaps xmm11, [rsp+0xA0]
00007f828abd6dc6  vmovaps xmm12, [rsp+0xB0]
00007f828abd6dcf  vmovaps xmm13, [rsp+0xC0]
00007f828abd6dd8  vmovaps xmm14, [rsp+0xD0]
00007f828abd6de1  vmovaps xmm15, [rsp+0xE0]
00007f828abd6dea  add rsp, 0xF0
00007f828abd6df1  pop r11
00007f828abd6df3  pop r10
00007f828abd6df5  pop r9
00007f828abd6df7  pop r8
00007f828abd6df9  pop rsi
00007f828abd6dfa  pop rdi
00007f828abd6dfb  pop rdx
00007f828abd6dfc  pop rcx
00007f828abd6dfd  pop rax
00007f828abd6dfe  add rsp, 0x08
00007f828abd6e02  jmp 0x00007F828ABD5A27
00007f828abd6e07  sub rsp, 0x08
00007f828abd6e0b  push rax
00007f828abd6e0c  push rcx
00007f828abd6e0d  push rdx
00007f828abd6e0e  push rdi
00007f828abd6e0f  push rsi
00007f828abd6e10  push r8
00007f828abd6e12  push r9
00007f828abd6e14  push r10
00007f828abd6e16  push r11
00007f828abd6e18  sub rsp, 0xF0
00007f828abd6e1f  vmovaps [rsp], xmm0
00007f828abd6e24  vmovaps [rsp+0x10], xmm1
00007f828abd6e2a  vmovaps [rsp+0x20], xmm2
00007f828abd6e30  vmovaps [rsp+0x30], xmm4
00007f828abd6e36  vmovaps [rsp+0x40], xmm5
00007f828abd6e3c  vmovaps [rsp+0x50], xmm6
00007f828abd6e42  vmovaps [rsp+0x60], xmm7
00007f828abd6e48  vmovaps [rsp+0x70], xmm8
00007f828abd6e4e  vmovaps [rsp+0x80], xmm9
00007f828abd6e57  vmovaps [rsp+0x90], xmm10
00007f828abd6e60  vmovaps [rsp+0xA0], xmm11
00007f828abd6e69  vmovaps [rsp+0xB0], xmm12
00007f828abd6e72  vmovaps [rsp+0xC0], xmm13
00007f828abd6e7b  vmovaps [rsp+0xD0], xmm14
00007f828abd6e84  vmovaps [rsp+0xE0], xmm15
00007f828abd6e8d  sub rsp, 0x30
00007f828abd6e91  movaps [rsp], xmm3
00007f828abd6e95  movaps [rsp+0x10], xmm5
00007f828abd6e9a  movaps [rsp+0x20], xmm4
00007f828abd6e9f  lea rdi, [rsp]
00007f828abd6ea3  mov esi, 0x00
00007f828abd6ea8  mov rax, 0x5BFE27FA6530
00007f828abd6eb2  call rax
00007f828abd6eb4  movaps xmm3, [rsp]
00007f828abd6eb8  add rsp, 0x30
00007f828abd6ebc  vmovaps xmm0, [rsp]
00007f828abd6ec1  vmovaps xmm1, [rsp+0x10]
00007f828abd6ec7  vmovaps xmm2, [rsp+0x20]
00007f828abd6ecd  vmovaps xmm4, [rsp+0x30]
00007f828abd6ed3  vmovaps xmm5, [rsp+0x40]
00007f828abd6ed9  vmovaps xmm6, [rsp+0x50]
00007f828abd6edf  vmovaps xmm7, [rsp+0x60]
00007f828abd6ee5  vmovaps xmm8, [rsp+0x70]
00007f828abd6eeb  vmovaps xmm9, [rsp+0x80]
00007f828abd6ef4  vmovaps xmm10, [rsp+0x90]
00007f828abd6efd  vmovaps xmm11, [rsp+0xA0]
00007f828abd6f06  vmovaps xmm12, [rsp+0xB0]
00007f828abd6f0f  vmovaps xmm13, [rsp+0xC0]
00007f828abd6f18  vmovaps xmm14, [rsp+0xD0]
00007f828abd6f21  vmovaps xmm15, [rsp+0xE0]
00007f828abd6f2a  add rsp, 0xF0
00007f828abd6f31  pop r11
00007f828abd6f33  pop r10
00007f828abd6f35  pop r9
00007f828abd6f37  pop r8
00007f828abd6f39  pop rsi
00007f828abd6f3a  pop rdi
00007f828abd6f3b  pop rdx
00007f828abd6f3c  pop rcx
00007f828abd6f3d  pop rax
00007f828abd6f3e  add rsp, 0x08
00007f828abd6f42  jmp 0x00007F828ABD5A88
00007f828abd6f47  sub rsp, 0x08
00007f828abd6f4b  push rax
00007f828abd6f4c  push rcx
00007f828abd6f4d  push rdx
00007f828abd6f4e  push rdi
00007f828abd6f4f  push rsi
00007f828abd6f50  push r8
00007f828abd6f52  push r9
00007f828abd6f54  push r10
00007f828abd6f56  push r11
00007f828abd6f58  sub rsp, 0xF0
00007f828abd6f5f  vmovaps [rsp], xmm0
00007f828abd6f64  vmovaps [rsp+0x10], xmm1
00007f828abd6f6a  vmovaps [rsp+0x20], xmm2
00007f828abd6f70  vmovaps [rsp+0x30], xmm3
00007f828abd6f76  vmovaps [rsp+0x40], xmm4
00007f828abd6f7c  vmovaps [rsp+0x50], xmm6
00007f828abd6f82  vmovaps [rsp+0x60], xmm7
00007f828abd6f88  vmovaps [rsp+0x70], xmm8
00007f828abd6f8e  vmovaps [rsp+0x80], xmm9
00007f828abd6f97  vmovaps [rsp+0x90], xmm10
00007f828abd6fa0  vmovaps [rsp+0xA0], xmm11
00007f828abd6fa9  vmovaps [rsp+0xB0], xmm12
00007f828abd6fb2  vmovaps [rsp+0xC0], xmm13
00007f828abd6fbb  vmovaps [rsp+0xD0], xmm14
00007f828abd6fc4  vmovaps [rsp+0xE0], xmm15
00007f828abd6fcd  sub rsp, 0x30
00007f828abd6fd1  movaps [rsp], xmm5
00007f828abd6fd5  movaps [rsp+0x10], xmm8
00007f828abd6fdb  movaps [rsp+0x20], xmm15
00007f828abd6fe1  lea rdi, [rsp]
00007f828abd6fe5  mov esi, 0x00
00007f828abd6fea  mov rax, 0x5BFE27FA6530
00007f828abd6ff4  call rax
00007f828abd6ff6  movaps xmm5, [rsp]
00007f828abd6ffa  add rsp, 0x30
00007f828abd6ffe  vmovaps xmm0, [rsp]
00007f828abd7003  vmovaps xmm1, [rsp+0x10]
00007f828abd7009  vmovaps xmm2, [rsp+0x20]
00007f828abd700f  vmovaps xmm3, [rsp+0x30]
00007f828abd7015  vmovaps xmm4, [rsp+0x40]
00007f828abd701b  vmovaps xmm6, [rsp+0x50]
00007f828abd7021  vmovaps xmm7, [rsp+0x60]
00007f828abd7027  vmovaps xmm8, [rsp+0x70]
00007f828abd702d  vmovaps xmm9, [rsp+0x80]
00007f828abd7036  vmovaps xmm10, [rsp+0x90]
00007f828abd703f  vmovaps xmm11, [rsp+0xA0]
00007f828abd7048  vmovaps xmm12, [rsp+0xB0]
00007f828abd7051  vmovaps xmm13, [rsp+0xC0]
00007f828abd705a  vmovaps xmm14, [rsp+0xD0]
00007f828abd7063  vmovaps xmm15, [rsp+0xE0]
00007f828abd706c  add rsp, 0xF0
00007f828abd7073  pop r11
00007f828abd7075  pop r10
00007f828abd7077  pop r9
00007f828abd7079  pop r8
00007f828abd707b  pop rsi
00007f828abd707c  pop rdi
00007f828abd707d  pop rdx
00007f828abd707e  pop rcx
00007f828abd707f  pop rax
00007f828abd7080  add rsp, 0x08
00007f828abd7084  jmp 0x00007F828ABD5AC0
00007f828abd7089  sub rsp, 0x08
00007f828abd708d  push rax
00007f828abd708e  push rcx
00007f828abd708f  push rdx
00007f828abd7090  push rdi
00007f828abd7091  push rsi
00007f828abd7092  push r8
00007f828abd7094  push r9
00007f828abd7096  push r10
00007f828abd7098  push r11
00007f828abd709a  sub rsp, 0xF0
00007f828abd70a1  vmovaps [rsp], xmm0
00007f828abd70a6  vmovaps [rsp+0x10], xmm1
00007f828abd70ac  vmovaps [rsp+0x20], xmm2
00007f828abd70b2  vmovaps [rsp+0x30], xmm3
00007f828abd70b8  vmovaps [rsp+0x40], xmm5
00007f828abd70be  vmovaps [rsp+0x50], xmm6
00007f828abd70c4  vmovaps [rsp+0x60], xmm7
00007f828abd70ca  vmovaps [rsp+0x70], xmm8
00007f828abd70d0  vmovaps [rsp+0x80], xmm9
00007f828abd70d9  vmovaps [rsp+0x90], xmm10
00007f828abd70e2  vmovaps [rsp+0xA0], xmm11
00007f828abd70eb  vmovaps [rsp+0xB0], xmm12
00007f828abd70f4  vmovaps [rsp+0xC0], xmm13
00007f828abd70fd  vmovaps [rsp+0xD0], xmm14
00007f828abd7106  vmovaps [rsp+0xE0], xmm15
00007f828abd710f  sub rsp, 0x30
00007f828abd7113  movaps [rsp], xmm4
00007f828abd7117  movaps [rsp+0x10], xmm9
00007f828abd711d  movaps [rsp+0x20], xmm8
00007f828abd7123  lea rdi, [rsp]
00007f828abd7127  mov esi, 0x00
00007f828abd712c  mov rax, 0x5BFE27FA6530
00007f828abd7136  call rax
00007f828abd7138  movaps xmm4, [rsp]
00007f828abd713c  add rsp, 0x30
00007f828abd7140  vmovaps xmm0, [rsp]
00007f828abd7145  vmovaps xmm1, [rsp+0x10]
00007f828abd714b  vmovaps xmm2, [rsp+0x20]
00007f828abd7151  vmovaps xmm3, [rsp+0x30]
00007f828abd7157  vmovaps xmm5, [rsp+0x40]
00007f828abd715d  vmovaps xmm6, [rsp+0x50]
00007f828abd7163  vmovaps xmm7, [rsp+0x60]
00007f828abd7169  vmovaps xmm8, [rsp+0x70]
00007f828abd716f  vmovaps xmm9, [rsp+0x80]
00007f828abd7178  vmovaps xmm10, [rsp+0x90]
00007f828abd7181  vmovaps xmm11, [rsp+0xA0]
00007f828abd718a  vmovaps xmm12, [rsp+0xB0]
00007f828abd7193  vmovaps xmm13, [rsp+0xC0]
00007f828abd719c  vmovaps xmm14, [rsp+0xD0]
00007f828abd71a5  vmovaps xmm15, [rsp+0xE0]
00007f828abd71ae  add rsp, 0xF0
00007f828abd71b5  pop r11
00007f828abd71b7  pop r10
00007f828abd71b9  pop r9
00007f828abd71bb  pop r8
00007f828abd71bd  pop rsi
00007f828abd71be  pop rdi
00007f828abd71bf  pop rdx
00007f828abd71c0  pop rcx
00007f828abd71c1  pop rax
00007f828abd71c2  add rsp, 0x08
00007f828abd71c6  jmp 0x00007F828ABD5AE1
00007f828abd71cb  sub rsp, 0x08
00007f828abd71cf  push rax
00007f828abd71d0  push rcx
00007f828abd71d1  push rdx
00007f828abd71d2  push rdi
00007f828abd71d3  push rsi
00007f828abd71d4  push r8
00007f828abd71d6  push r9
00007f828abd71d8  push r10
00007f828abd71da  push r11
00007f828abd71dc  sub rsp, 0xF0
00007f828abd71e3  vmovaps [rsp], xmm0
00007f828abd71e8  vmovaps [rsp+0x10], xmm1
00007f828abd71ee  vmovaps [rsp+0x20], xmm2
00007f828abd71f4  vmovaps [rsp+0x30], xmm3
00007f828abd71fa  vmovaps [rsp+0x40], xmm4
00007f828abd7200  vmovaps [rsp+0x50], xmm5
00007f828abd7206  vmovaps [rsp+0x60], xmm6
00007f828abd720c  vmovaps [rsp+0x70], xmm7
00007f828abd7212  vmovaps [rsp+0x80], xmm8
00007f828abd721b  vmovaps [rsp+0x90], xmm10
00007f828abd7224  vmovaps [rsp+0xA0], xmm11
00007f828abd722d  vmovaps [rsp+0xB0], xmm12
00007f828abd7236  vmovaps [rsp+0xC0], xmm13
00007f828abd723f  vmovaps [rsp+0xD0], xmm14
00007f828abd7248  vmovaps [rsp+0xE0], xmm15
00007f828abd7251  sub rsp, 0x30
00007f828abd7255  movaps [rsp], xmm9
00007f828abd725a  movaps [rsp+0x10], xmm10
00007f828abd7260  movaps [rsp+0x20], xmm8
00007f828abd7266  lea rdi, [rsp]
00007f828abd726a  mov esi, 0x00
00007f828abd726f  mov rax, 0x5BFE27FA6530
00007f828abd7279  call rax
00007f828abd727b  movaps xmm9, [rsp]
00007f828abd7280  add rsp, 0x30
00007f828abd7284  vmovaps xmm0, [rsp]
00007f828abd7289  vmovaps xmm1, [rsp+0x10]
00007f828abd728f  vmovaps xmm2, [rsp+0x20]
00007f828abd7295  vmovaps xmm3, [rsp+0x30]
00007f828abd729b  vmovaps xmm4, [rsp+0x40]
00007f828abd72a1  vmovaps xmm5, [rsp+0x50]
00007f828abd72a7  vmovaps xmm6, [rsp+0x60]
00007f828abd72ad  vmovaps xmm7, [rsp+0x70]
00007f828abd72b3  vmovaps xmm8, [rsp+0x80]
00007f828abd72bc  vmovaps xmm10, [rsp+0x90]
00007f828abd72c5  vmovaps xmm11, [rsp+0xA0]
00007f828abd72ce  vmovaps xmm12, [rsp+0xB0]
00007f828abd72d7  vmovaps xmm13, [rsp+0xC0]
00007f828abd72e0  vmovaps xmm14, [rsp+0xD0]
00007f828abd72e9  vmovaps xmm15, [rsp+0xE0]
00007f828abd72f2  add rsp, 0xF0
00007f828abd72f9  pop r11
00007f828abd72fb  pop r10
00007f828abd72fd  pop r9
00007f828abd72ff  pop r8
00007f828abd7301  pop rsi
00007f828abd7302  pop rdi
00007f828abd7303  pop rdx
00007f828abd7304  pop rcx
00007f828abd7305  pop rax
00007f828abd7306  add rsp, 0x08
00007f828abd730a  jmp 0x00007F828ABD5AFB
00007f828abd730f  call 0x00007F828AAD64F0
00007f828abd7314  jmp 0x00007F828ABD5C15
00007f828abd7319  call 0x00007F828AAD64F0
00007f828abd731e  jmp 0x00007F828ABD5C2B
00007f828abd7323  sub rsp, 0x08
00007f828abd7327  push rax
00007f828abd7328  push rcx
00007f828abd7329  push rdx
00007f828abd732a  push rdi
00007f828abd732b  push rsi
00007f828abd732c  push r8
00007f828abd732e  push r9
00007f828abd7330  push r10
00007f828abd7332  push r11
00007f828abd7334  sub rsp, 0xF0
00007f828abd733b  vmovaps [rsp], xmm0
00007f828abd7340  vmovaps [rsp+0x10], xmm2
00007f828abd7346  vmovaps [rsp+0x20], xmm3
00007f828abd734c  vmovaps [rsp+0x30], xmm4
00007f828abd7352  vmovaps [rsp+0x40], xmm5
00007f828abd7358  vmovaps [rsp+0x50], xmm6
00007f828abd735e  vmovaps [rsp+0x60], xmm7
00007f828abd7364  vmovaps [rsp+0x70], xmm8
00007f828abd736a  vmovaps [rsp+0x80], xmm9
00007f828abd7373  vmovaps [rsp+0x90], xmm10
00007f828abd737c  vmovaps [rsp+0xA0], xmm11
00007f828abd7385  vmovaps [rsp+0xB0], xmm12
00007f828abd738e  vmovaps [rsp+0xC0], xmm13
00007f828abd7397  vmovaps [rsp+0xD0], xmm14
00007f828abd73a0  vmovaps [rsp+0xE0], xmm15
00007f828abd73a9  sub rsp, 0x30
00007f828abd73ad  movaps [rsp], xmm1
00007f828abd73b1  movaps [rsp+0x10], xmm6
00007f828abd73b6  movaps [rsp+0x20], xmm15
00007f828abd73bc  lea rdi, [rsp]
00007f828abd73c0  mov esi, 0x00
00007f828abd73c5  mov rax, 0x5BFE27FA6530
00007f828abd73cf  call rax
00007f828abd73d1  movaps xmm1, [rsp]
00007f828abd73d5  add rsp, 0x30
00007f828abd73d9  vmovaps xmm0, [rsp]
00007f828abd73de  vmovaps xmm2, [rsp+0x10]
00007f828abd73e4  vmovaps xmm3, [rsp+0x20]
00007f828abd73ea  vmovaps xmm4, [rsp+0x30]
00007f828abd73f0  vmovaps xmm5, [rsp+0x40]
00007f828abd73f6  vmovaps xmm6, [rsp+0x50]
00007f828abd73fc  vmovaps xmm7, [rsp+0x60]
00007f828abd7402  vmovaps xmm8, [rsp+0x70]
00007f828abd7408  vmovaps xmm9, [rsp+0x80]
00007f828abd7411  vmovaps xmm10, [rsp+0x90]
00007f828abd741a  vmovaps xmm11, [rsp+0xA0]
00007f828abd7423  vmovaps xmm12, [rsp+0xB0]
00007f828abd742c  vmovaps xmm13, [rsp+0xC0]
00007f828abd7435  vmovaps xmm14, [rsp+0xD0]
00007f828abd743e  vmovaps xmm15, [rsp+0xE0]
00007f828abd7447  add rsp, 0xF0
00007f828abd744e  pop r11
00007f828abd7450  pop r10
00007f828abd7452  pop r9
00007f828abd7454  pop r8
00007f828abd7456  pop rsi
00007f828abd7457  pop rdi
00007f828abd7458  pop rdx
00007f828abd7459  pop rcx
00007f828abd745a  pop rax
00007f828abd745b  add rsp, 0x08
00007f828abd745f  jmp 0x00007F828ABD5C68
00007f828abd7464  call 0x00007F828AAE5820
00007f828abd7469  jmp 0x00007F828ABD5C75
00007f828abd746e  sub rsp, 0x08
00007f828abd7472  push rax
00007f828abd7473  push rcx
00007f828abd7474  push rdx
00007f828abd7475  push rdi
00007f828abd7476  push rsi
00007f828abd7477  push r8
00007f828abd7479  push r9
00007f828abd747b  push r10
00007f828abd747d  push r11
00007f828abd747f  sub rsp, 0xF0
00007f828abd7486  vmovaps [rsp], xmm0
00007f828abd748b  vmovaps [rsp+0x10], xmm1
00007f828abd7491  vmovaps [rsp+0x20], xmm2
00007f828abd7497  vmovaps [rsp+0x30], xmm3
00007f828abd749d  vmovaps [rsp+0x40], xmm4
00007f828abd74a3  vmovaps [rsp+0x50], xmm5
00007f828abd74a9  vmovaps [rsp+0x60], xmm6
00007f828abd74af  vmovaps [rsp+0x70], xmm7
00007f828abd74b5  vmovaps [rsp+0x80], xmm8
00007f828abd74be  vmovaps [rsp+0x90], xmm9
00007f828abd74c7  vmovaps [rsp+0xA0], xmm10
00007f828abd74d0  vmovaps [rsp+0xB0], xmm11
00007f828abd74d9  vmovaps [rsp+0xC0], xmm12
00007f828abd74e2  vmovaps [rsp+0xD0], xmm13
00007f828abd74eb  vmovaps [rsp+0xE0], xmm15
00007f828abd74f4  sub rsp, 0x30
00007f828abd74f8  movaps [rsp], xmm14
00007f828abd74fd  movaps [rsp+0x10], xmm4
00007f828abd7502  movaps [rsp+0x20], xmm3
00007f828abd7507  lea rdi, [rsp]
00007f828abd750b  mov esi, 0x00
00007f828abd7510  mov rax, 0x5BFE27FA6530
00007f828abd751a  call rax
00007f828abd751c  movaps xmm14, [rsp]
00007f828abd7521  add rsp, 0x30
00007f828abd7525  vmovaps xmm0, [rsp]
00007f828abd752a  vmovaps xmm1, [rsp+0x10]
00007f828abd7530  vmovaps xmm2, [rsp+0x20]
00007f828abd7536  vmovaps xmm3, [rsp+0x30]
00007f828abd753c  vmovaps xmm4, [rsp+0x40]
00007f828abd7542  vmovaps xmm5, [rsp+0x50]
00007f828abd7548  vmovaps xmm6, [rsp+0x60]
00007f828abd754e  vmovaps xmm7, [rsp+0x70]
00007f828abd7554  vmovaps xmm8, [rsp+0x80]
00007f828abd755d  vmovaps xmm9, [rsp+0x90]
00007f828abd7566  vmovaps xmm10, [rsp+0xA0]
00007f828abd756f  vmovaps xmm11, [rsp+0xB0]
00007f828abd7578  vmovaps xmm12, [rsp+0xC0]
00007f828abd7581  vmovaps xmm13, [rsp+0xD0]
00007f828abd758a  vmovaps xmm15, [rsp+0xE0]
00007f828abd7593  add rsp, 0xF0
00007f828abd759a  pop r11
00007f828abd759c  pop r10
00007f828abd759e  pop r9
00007f828abd75a0  pop r8
00007f828abd75a2  pop rsi
00007f828abd75a3  pop rdi
00007f828abd75a4  pop rdx
00007f828abd75a5  pop rcx
00007f828abd75a6  pop rax
00007f828abd75a7  add rsp, 0x08
00007f828abd75ab  jmp 0x00007F828ABD5C8F
00007f828abd75b0  sub rsp, 0x08
00007f828abd75b4  push rax
00007f828abd75b5  push rcx
00007f828abd75b6  push rdx
00007f828abd75b7  push rdi
00007f828abd75b8  push rsi
00007f828abd75b9  push r8
00007f828abd75bb  push r9
00007f828abd75bd  push r10
00007f828abd75bf  push r11
00007f828abd75c1  sub rsp, 0xF0
00007f828abd75c8  vmovaps [rsp], xmm0
00007f828abd75cd  vmovaps [rsp+0x10], xmm1
00007f828abd75d3  vmovaps [rsp+0x20], xmm2
00007f828abd75d9  vmovaps [rsp+0x30], xmm3
00007f828abd75df  vmovaps [rsp+0x40], xmm4
00007f828abd75e5  vmovaps [rsp+0x50], xmm5
00007f828abd75eb  vmovaps [rsp+0x60], xmm7
00007f828abd75f1  vmovaps [rsp+0x70], xmm8
00007f828abd75f7  vmovaps [rsp+0x80], xmm9
00007f828abd7600  vmovaps [rsp+0x90], xmm10
00007f828abd7609  vmovaps [rsp+0xA0], xmm11
00007f828abd7612  vmovaps [rsp+0xB0], xmm12
00007f828abd761b  vmovaps [rsp+0xC0], xmm13
00007f828abd7624  vmovaps [rsp+0xD0], xmm14
00007f828abd762d  vmovaps [rsp+0xE0], xmm15
00007f828abd7636  sub rsp, 0x30
00007f828abd763a  movaps [rsp], xmm6
00007f828abd763e  movaps [rsp+0x10], xmm9
00007f828abd7644  movaps [rsp+0x20], xmm7
00007f828abd7649  lea rdi, [rsp]
00007f828abd764d  mov esi, 0x00
00007f828abd7652  mov rax, 0x5BFE27FA6530
00007f828abd765c  call rax
00007f828abd765e  movaps xmm6, [rsp]
00007f828abd7662  add rsp, 0x30
00007f828abd7666  vmovaps xmm0, [rsp]
00007f828abd766b  vmovaps xmm1, [rsp+0x10]
00007f828abd7671  vmovaps xmm2, [rsp+0x20]
00007f828abd7677  vmovaps xmm3, [rsp+0x30]
00007f828abd767d  vmovaps xmm4, [rsp+0x40]
00007f828abd7683  vmovaps xmm5, [rsp+0x50]
00007f828abd7689  vmovaps xmm7, [rsp+0x60]
00007f828abd768f  vmovaps xmm8, [rsp+0x70]
00007f828abd7695  vmovaps xmm9, [rsp+0x80]
00007f828abd769e  vmovaps xmm10, [rsp+0x90]
00007f828abd76a7  vmovaps xmm11, [rsp+0xA0]
00007f828abd76b0  vmovaps xmm12, [rsp+0xB0]
00007f828abd76b9  vmovaps xmm13, [rsp+0xC0]
00007f828abd76c2  vmovaps xmm14, [rsp+0xD0]
00007f828abd76cb  vmovaps xmm15, [rsp+0xE0]
00007f828abd76d4  add rsp, 0xF0
00007f828abd76db  pop r11
00007f828abd76dd  pop r10
00007f828abd76df  pop r9
00007f828abd76e1  pop r8
00007f828abd76e3  pop rsi
00007f828abd76e4  pop rdi
00007f828abd76e5  pop rdx
00007f828abd76e6  pop rcx
00007f828abd76e7  pop rax
00007f828abd76e8  add rsp, 0x08
00007f828abd76ec  jmp 0x00007F828ABD5CA7
00007f828abd76f1  sub rsp, 0x08
00007f828abd76f5  push rax
00007f828abd76f6  push rcx
00007f828abd76f7  push rdx
00007f828abd76f8  push rdi
00007f828abd76f9  push rsi
00007f828abd76fa  push r8
00007f828abd76fc  push r9
00007f828abd76fe  push r10
00007f828abd7700  push r11
00007f828abd7702  sub rsp, 0xF0
00007f828abd7709  vmovaps [rsp], xmm0
00007f828abd770e  vmovaps [rsp+0x10], xmm1
00007f828abd7714  vmovaps [rsp+0x20], xmm2
00007f828abd771a  vmovaps [rsp+0x30], xmm3
00007f828abd7720  vmovaps [rsp+0x40], xmm4
00007f828abd7726  vmovaps [rsp+0x50], xmm5
00007f828abd772c  vmovaps [rsp+0x60], xmm6
00007f828abd7732  vmovaps [rsp+0x70], xmm8
00007f828abd7738  vmovaps [rsp+0x80], xmm9
00007f828abd7741  vmovaps [rsp+0x90], xmm10
00007f828abd774a  vmovaps [rsp+0xA0], xmm11
00007f828abd7753  vmovaps [rsp+0xB0], xmm12
00007f828abd775c  vmovaps [rsp+0xC0], xmm13
00007f828abd7765  vmovaps [rsp+0xD0], xmm14
00007f828abd776e  vmovaps [rsp+0xE0], xmm15
00007f828abd7777  sub rsp, 0x30
00007f828abd777b  movaps [rsp], xmm7
00007f828abd777f  movaps [rsp+0x10], xmm4
00007f828abd7784  movaps [rsp+0x20], xmm9
00007f828abd778a  lea rdi, [rsp]
00007f828abd778e  mov esi, 0x00
00007f828abd7793  mov rax, 0x5BFE27FA6530
00007f828abd779d  call rax
00007f828abd779f  movaps xmm7, [rsp]
00007f828abd77a3  add rsp, 0x30
00007f828abd77a7  vmovaps xmm0, [rsp]
00007f828abd77ac  vmovaps xmm1, [rsp+0x10]
00007f828abd77b2  vmovaps xmm2, [rsp+0x20]
00007f828abd77b8  vmovaps xmm3, [rsp+0x30]
00007f828abd77be  vmovaps xmm4, [rsp+0x40]
00007f828abd77c4  vmovaps xmm5, [rsp+0x50]
00007f828abd77ca  vmovaps xmm6, [rsp+0x60]
00007f828abd77d0  vmovaps xmm8, [rsp+0x70]
00007f828abd77d6  vmovaps xmm9, [rsp+0x80]
00007f828abd77df  vmovaps xmm10, [rsp+0x90]
00007f828abd77e8  vmovaps xmm11, [rsp+0xA0]
00007f828abd77f1  vmovaps xmm12, [rsp+0xB0]
00007f828abd77fa  vmovaps xmm13, [rsp+0xC0]
00007f828abd7803  vmovaps xmm14, [rsp+0xD0]
00007f828abd780c  vmovaps xmm15, [rsp+0xE0]
00007f828abd7815  add rsp, 0xF0
00007f828abd781c  pop r11
00007f828abd781e  pop r10
00007f828abd7820  pop r9
00007f828abd7822  pop r8
00007f828abd7824  pop rsi
00007f828abd7825  pop rdi
00007f828abd7826  pop rdx
00007f828abd7827  pop rcx
00007f828abd7828  pop rax
00007f828abd7829  add rsp, 0x08
00007f828abd782d  jmp 0x00007F828ABD5CD4
00007f828abd7832  sub rsp, 0x08
00007f828abd7836  push rax
00007f828abd7837  push rcx
00007f828abd7838  push rdx
00007f828abd7839  push rdi
00007f828abd783a  push rsi
00007f828abd783b  push r8
00007f828abd783d  push r9
00007f828abd783f  push r10
00007f828abd7841  push r11
00007f828abd7843  sub rsp, 0xF0
00007f828abd784a  vmovaps [rsp], xmm0
00007f828abd784f  vmovaps [rsp+0x10], xmm1
00007f828abd7855  vmovaps [rsp+0x20], xmm2
00007f828abd785b  vmovaps [rsp+0x30], xmm3
00007f828abd7861  vmovaps [rsp+0x40], xmm5
00007f828abd7867  vmovaps [rsp+0x50], xmm6
00007f828abd786d  vmovaps [rsp+0x60], xmm7
00007f828abd7873  vmovaps [rsp+0x70], xmm8
00007f828abd7879  vmovaps [rsp+0x80], xmm9
00007f828abd7882  vmovaps [rsp+0x90], xmm10
00007f828abd788b  vmovaps [rsp+0xA0], xmm11
00007f828abd7894  vmovaps [rsp+0xB0], xmm12
00007f828abd789d  vmovaps [rsp+0xC0], xmm13
00007f828abd78a6  vmovaps [rsp+0xD0], xmm14
00007f828abd78af  vmovaps [rsp+0xE0], xmm15
00007f828abd78b8  sub rsp, 0x30
00007f828abd78bc  movaps [rsp], xmm4
00007f828abd78c0  movaps [rsp+0x10], xmm15
00007f828abd78c6  movaps [rsp+0x20], xmm9
00007f828abd78cc  lea rdi, [rsp]
00007f828abd78d0  mov esi, 0x00
00007f828abd78d5  mov rax, 0x5BFE27FA6530
00007f828abd78df  call rax
00007f828abd78e1  movaps xmm4, [rsp]
00007f828abd78e5  add rsp, 0x30
00007f828abd78e9  vmovaps xmm0, [rsp]
00007f828abd78ee  vmovaps xmm1, [rsp+0x10]
00007f828abd78f4  vmovaps xmm2, [rsp+0x20]
00007f828abd78fa  vmovaps xmm3, [rsp+0x30]
00007f828abd7900  vmovaps xmm5, [rsp+0x40]
00007f828abd7906  vmovaps xmm6, [rsp+0x50]
00007f828abd790c  vmovaps xmm7, [rsp+0x60]
00007f828abd7912  vmovaps xmm8, [rsp+0x70]
00007f828abd7918  vmovaps xmm9, [rsp+0x80]
00007f828abd7921  vmovaps xmm10, [rsp+0x90]
00007f828abd792a  vmovaps xmm11, [rsp+0xA0]
00007f828abd7933  vmovaps xmm12, [rsp+0xB0]
00007f828abd793c  vmovaps xmm13, [rsp+0xC0]
00007f828abd7945  vmovaps xmm14, [rsp+0xD0]
00007f828abd794e  vmovaps xmm15, [rsp+0xE0]
00007f828abd7957  add rsp, 0xF0
00007f828abd795e  pop r11
00007f828abd7960  pop r10
00007f828abd7962  pop r9
00007f828abd7964  pop r8
00007f828abd7966  pop rsi
00007f828abd7967  pop rdi
00007f828abd7968  pop rdx
00007f828abd7969  pop rcx
00007f828abd796a  pop rax
00007f828abd796b  add rsp, 0x08
00007f828abd796f  jmp 0x00007F828ABD5CF9
00007f828abd7974  call 0x00007F828AAE5820
00007f828abd7979  jmp 0x00007F828ABD5D06
00007f828abd797e  sub rsp, 0x08
00007f828abd7982  push rax
00007f828abd7983  push rcx
00007f828abd7984  push rdx
00007f828abd7985  push rdi
00007f828abd7986  push rsi
00007f828abd7987  push r8
00007f828abd7989  push r9
00007f828abd798b  push r10
00007f828abd798d  push r11
00007f828abd798f  sub rsp, 0xF0
00007f828abd7996  vmovaps [rsp], xmm0
00007f828abd799b  vmovaps [rsp+0x10], xmm1
00007f828abd79a1  vmovaps [rsp+0x20], xmm2
00007f828abd79a7  vmovaps [rsp+0x30], xmm4
00007f828abd79ad  vmovaps [rsp+0x40], xmm5
00007f828abd79b3  vmovaps [rsp+0x50], xmm6
00007f828abd79b9  vmovaps [rsp+0x60], xmm7
00007f828abd79bf  vmovaps [rsp+0x70], xmm8
00007f828abd79c5  vmovaps [rsp+0x80], xmm9
00007f828abd79ce  vmovaps [rsp+0x90], xmm10
00007f828abd79d7  vmovaps [rsp+0xA0], xmm11
00007f828abd79e0  vmovaps [rsp+0xB0], xmm12
00007f828abd79e9  vmovaps [rsp+0xC0], xmm13
00007f828abd79f2  vmovaps [rsp+0xD0], xmm14
00007f828abd79fb  vmovaps [rsp+0xE0], xmm15
00007f828abd7a04  sub rsp, 0x30
00007f828abd7a08  movaps [rsp], xmm3
00007f828abd7a0c  movaps [rsp+0x10], xmm1
00007f828abd7a11  movaps [rsp+0x20], xmm9
00007f828abd7a17  lea rdi, [rsp]
00007f828abd7a1b  mov esi, 0x00
00007f828abd7a20  mov rax, 0x5BFE27FA6530
00007f828abd7a2a  call rax
00007f828abd7a2c  movaps xmm3, [rsp]
00007f828abd7a30  add rsp, 0x30
00007f828abd7a34  vmovaps xmm0, [rsp]
00007f828abd7a39  vmovaps xmm1, [rsp+0x10]
00007f828abd7a3f  vmovaps xmm2, [rsp+0x20]
00007f828abd7a45  vmovaps xmm4, [rsp+0x30]
00007f828abd7a4b  vmovaps xmm5, [rsp+0x40]
00007f828abd7a51  vmovaps xmm6, [rsp+0x50]
00007f828abd7a57  vmovaps xmm7, [rsp+0x60]
00007f828abd7a5d  vmovaps xmm8, [rsp+0x70]
00007f828abd7a63  vmovaps xmm9, [rsp+0x80]
00007f828abd7a6c  vmovaps xmm10, [rsp+0x90]
00007f828abd7a75  vmovaps xmm11, [rsp+0xA0]
00007f828abd7a7e  vmovaps xmm12, [rsp+0xB0]
00007f828abd7a87  vmovaps xmm13, [rsp+0xC0]
00007f828abd7a90  vmovaps xmm14, [rsp+0xD0]
00007f828abd7a99  vmovaps xmm15, [rsp+0xE0]
00007f828abd7aa2  add rsp, 0xF0
00007f828abd7aa9  pop r11
00007f828abd7aab  pop r10
00007f828abd7aad  pop r9
00007f828abd7aaf  pop r8
00007f828abd7ab1  pop rsi
00007f828abd7ab2  pop rdi
00007f828abd7ab3  pop rdx
00007f828abd7ab4  pop rcx
00007f828abd7ab5  pop rax
00007f828abd7ab6  add rsp, 0x08
00007f828abd7aba  jmp 0x00007F828ABD5D43
00007f828abd7abf  sub rsp, 0x08
00007f828abd7ac3  push rax
00007f828abd7ac4  push rcx
00007f828abd7ac5  push rdx
00007f828abd7ac6  push rdi
00007f828abd7ac7  push rsi
00007f828abd7ac8  push r8
00007f828abd7aca  push r9
00007f828abd7acc  push r10
00007f828abd7ace  push r11
00007f828abd7ad0  sub rsp, 0xF0
00007f828abd7ad7  vmovaps [rsp], xmm0
00007f828abd7adc  vmovaps [rsp+0x10], xmm2
00007f828abd7ae2  vmovaps [rsp+0x20], xmm3
00007f828abd7ae8  vmovaps [rsp+0x30], xmm4
00007f828abd7aee  vmovaps [rsp+0x40], xmm5
00007f828abd7af4  vmovaps [rsp+0x50], xmm6
00007f828abd7afa  vmovaps [rsp+0x60], xmm7
00007f828abd7b00  vmovaps [rsp+0x70], xmm8
00007f828abd7b06  vmovaps [rsp+0x80], xmm9
00007f828abd7b0f  vmovaps [rsp+0x90], xmm10
00007f828abd7b18  vmovaps [rsp+0xA0], xmm11
00007f828abd7b21  vmovaps [rsp+0xB0], xmm12
00007f828abd7b2a  vmovaps [rsp+0xC0], xmm13
00007f828abd7b33  vmovaps [rsp+0xD0], xmm14
00007f828abd7b3c  vmovaps [rsp+0xE0], xmm15
00007f828abd7b45  sub rsp, 0x30
00007f828abd7b49  movaps [rsp], xmm1
00007f828abd7b4d  movaps [rsp+0x10], xmm15
00007f828abd7b53  movaps [rsp+0x20], xmm9
00007f828abd7b59  lea rdi, [rsp]
00007f828abd7b5d  mov esi, 0x00
00007f828abd7b62  mov rax, 0x5BFE27FA6530
00007f828abd7b6c  call rax
00007f828abd7b6e  movaps xmm1, [rsp]
00007f828abd7b72  add rsp, 0x30
00007f828abd7b76  vmovaps xmm0, [rsp]
00007f828abd7b7b  vmovaps xmm2, [rsp+0x10]
00007f828abd7b81  vmovaps xmm3, [rsp+0x20]
00007f828abd7b87  vmovaps xmm4, [rsp+0x30]
00007f828abd7b8d  vmovaps xmm5, [rsp+0x40]
00007f828abd7b93  vmovaps xmm6, [rsp+0x50]
00007f828abd7b99  vmovaps xmm7, [rsp+0x60]
00007f828abd7b9f  vmovaps xmm8, [rsp+0x70]
00007f828abd7ba5  vmovaps xmm9, [rsp+0x80]
00007f828abd7bae  vmovaps xmm10, [rsp+0x90]
00007f828abd7bb7  vmovaps xmm11, [rsp+0xA0]
00007f828abd7bc0  vmovaps xmm12, [rsp+0xB0]
00007f828abd7bc9  vmovaps xmm13, [rsp+0xC0]
00007f828abd7bd2  vmovaps xmm14, [rsp+0xD0]
00007f828abd7bdb  vmovaps xmm15, [rsp+0xE0]
00007f828abd7be4  add rsp, 0xF0
00007f828abd7beb  pop r11
00007f828abd7bed  pop r10
00007f828abd7bef  pop r9
00007f828abd7bf1  pop r8
00007f828abd7bf3  pop rsi
00007f828abd7bf4  pop rdi
00007f828abd7bf5  pop rdx
00007f828abd7bf6  pop rcx
00007f828abd7bf7  pop rax
00007f828abd7bf8  add rsp, 0x08
00007f828abd7bfc  jmp 0x00007F828ABD5DCB
00007f828abd7c01  call 0x00007F828AAE5820
00007f828abd7c06  jmp 0x00007F828ABD5DD8
00007f828abd7c0b  sub rsp, 0x08
00007f828abd7c0f  push rax
00007f828abd7c10  push rcx
00007f828abd7c11  push rdx
00007f828abd7c12  push rdi
00007f828abd7c13  push rsi
00007f828abd7c14  push r8
00007f828abd7c16  push r9
00007f828abd7c18  push r10
00007f828abd7c1a  push r11
00007f828abd7c1c  sub rsp, 0xF0
00007f828abd7c23  vmovaps [rsp], xmm0
00007f828abd7c28  vmovaps [rsp+0x10], xmm2
00007f828abd7c2e  vmovaps [rsp+0x20], xmm3
00007f828abd7c34  vmovaps [rsp+0x30], xmm4
00007f828abd7c3a  vmovaps [rsp+0x40], xmm5
00007f828abd7c40  vmovaps [rsp+0x50], xmm6
00007f828abd7c46  vmovaps [rsp+0x60], xmm7
00007f828abd7c4c  vmovaps [rsp+0x70], xmm8
00007f828abd7c52  vmovaps [rsp+0x80], xmm9
00007f828abd7c5b  vmovaps [rsp+0x90], xmm10
00007f828abd7c64  vmovaps [rsp+0xA0], xmm11
00007f828abd7c6d  vmovaps [rsp+0xB0], xmm12
00007f828abd7c76  vmovaps [rsp+0xC0], xmm13
00007f828abd7c7f  vmovaps [rsp+0xD0], xmm14
00007f828abd7c88  vmovaps [rsp+0xE0], xmm15
00007f828abd7c91  sub rsp, 0x30
00007f828abd7c95  movaps [rsp], xmm1
00007f828abd7c99  movaps [rsp+0x10], xmm5
00007f828abd7c9e  movaps [rsp+0x20], xmm7
00007f828abd7ca3  lea rdi, [rsp]
00007f828abd7ca7  mov esi, 0x00
00007f828abd7cac  mov rax, 0x5BFE27FA6530
00007f828abd7cb6  call rax
00007f828abd7cb8  movaps xmm1, [rsp]
00007f828abd7cbc  add rsp, 0x30
00007f828abd7cc0  vmovaps xmm0, [rsp]
00007f828abd7cc5  vmovaps xmm2, [rsp+0x10]
00007f828abd7ccb  vmovaps xmm3, [rsp+0x20]
00007f828abd7cd1  vmovaps xmm4, [rsp+0x30]
00007f828abd7cd7  vmovaps xmm5, [rsp+0x40]
00007f828abd7cdd  vmovaps xmm6, [rsp+0x50]
00007f828abd7ce3  vmovaps xmm7, [rsp+0x60]
00007f828abd7ce9  vmovaps xmm8, [rsp+0x70]
00007f828abd7cef  vmovaps xmm9, [rsp+0x80]
00007f828abd7cf8  vmovaps xmm10, [rsp+0x90]
00007f828abd7d01  vmovaps xmm11, [rsp+0xA0]
00007f828abd7d0a  vmovaps xmm12, [rsp+0xB0]
00007f828abd7d13  vmovaps xmm13, [rsp+0xC0]
00007f828abd7d1c  vmovaps xmm14, [rsp+0xD0]
00007f828abd7d25  vmovaps xmm15, [rsp+0xE0]
00007f828abd7d2e  add rsp, 0xF0
00007f828abd7d35  pop r11
00007f828abd7d37  pop r10
00007f828abd7d39  pop r9
00007f828abd7d3b  pop r8
00007f828abd7d3d  pop rsi
00007f828abd7d3e  pop rdi
00007f828abd7d3f  pop rdx
00007f828abd7d40  pop rcx
00007f828abd7d41  pop rax
00007f828abd7d42  add rsp, 0x08
00007f828abd7d46  jmp 0x00007F828ABD5E7D
00007f828abd7d4b  sub rsp, 0x08
00007f828abd7d4f  push rax
00007f828abd7d50  push rcx
00007f828abd7d51  push rdx
00007f828abd7d52  push rdi
00007f828abd7d53  push rsi
00007f828abd7d54  push r8
00007f828abd7d56  push r9
00007f828abd7d58  push r10
00007f828abd7d5a  push r11
00007f828abd7d5c  sub rsp, 0xF0
00007f828abd7d63  vmovaps [rsp], xmm0
00007f828abd7d68  vmovaps [rsp+0x10], xmm1
00007f828abd7d6e  vmovaps [rsp+0x20], xmm2
00007f828abd7d74  vmovaps [rsp+0x30], xmm3
00007f828abd7d7a  vmovaps [rsp+0x40], xmm4
00007f828abd7d80  vmovaps [rsp+0x50], xmm5
00007f828abd7d86  vmovaps [rsp+0x60], xmm6
00007f828abd7d8c  vmovaps [rsp+0x70], xmm8
00007f828abd7d92  vmovaps [rsp+0x80], xmm9
00007f828abd7d9b  vmovaps [rsp+0x90], xmm10
00007f828abd7da4  vmovaps [rsp+0xA0], xmm11
00007f828abd7dad  vmovaps [rsp+0xB0], xmm12
00007f828abd7db6  vmovaps [rsp+0xC0], xmm13
00007f828abd7dbf  vmovaps [rsp+0xD0], xmm14
00007f828abd7dc8  vmovaps [rsp+0xE0], xmm15
00007f828abd7dd1  sub rsp, 0x30
00007f828abd7dd5  movaps [rsp], xmm7
00007f828abd7dd9  movaps [rsp+0x10], xmm5
00007f828abd7dde  movaps [rsp+0x20], xmm15
00007f828abd7de4  lea rdi, [rsp]
00007f828abd7de8  mov esi, 0x00
00007f828abd7ded  mov rax, 0x5BFE27FA6530
00007f828abd7df7  call rax
00007f828abd7df9  movaps xmm7, [rsp]
00007f828abd7dfd  add rsp, 0x30
00007f828abd7e01  vmovaps xmm0, [rsp]
00007f828abd7e06  vmovaps xmm1, [rsp+0x10]
00007f828abd7e0c  vmovaps xmm2, [rsp+0x20]
00007f828abd7e12  vmovaps xmm3, [rsp+0x30]
00007f828abd7e18  vmovaps xmm4, [rsp+0x40]
00007f828abd7e1e  vmovaps xmm5, [rsp+0x50]
00007f828abd7e24  vmovaps xmm6, [rsp+0x60]
00007f828abd7e2a  vmovaps xmm8, [rsp+0x70]
00007f828abd7e30  vmovaps xmm9, [rsp+0x80]
00007f828abd7e39  vmovaps xmm10, [rsp+0x90]
00007f828abd7e42  vmovaps xmm11, [rsp+0xA0]
00007f828abd7e4b  vmovaps xmm12, [rsp+0xB0]
00007f828abd7e54  vmovaps xmm13, [rsp+0xC0]
00007f828abd7e5d  vmovaps xmm14, [rsp+0xD0]
00007f828abd7e66  vmovaps xmm15, [rsp+0xE0]
00007f828abd7e6f  add rsp, 0xF0
00007f828abd7e76  pop r11
00007f828abd7e78  pop r10
00007f828abd7e7a  pop r9
00007f828abd7e7c  pop r8
00007f828abd7e7e  pop rsi
00007f828abd7e7f  pop rdi
00007f828abd7e80  pop rdx
00007f828abd7e81  pop rcx
00007f828abd7e82  pop rax
00007f828abd7e83  add rsp, 0x08
00007f828abd7e87  jmp 0x00007F828ABD5EB3
00007f828abd7e8c  call 0x00007F828AAD64F0
00007f828abd7e91  jmp 0x00007F828ABD5EC0
00007f828abd7e96  sub rsp, 0x08
00007f828abd7e9a  push rax
00007f828abd7e9b  push rcx
00007f828abd7e9c  push rdx
00007f828abd7e9d  push rdi
00007f828abd7e9e  push rsi
00007f828abd7e9f  push r8
00007f828abd7ea1  push r9
00007f828abd7ea3  push r10
00007f828abd7ea5  push r11
00007f828abd7ea7  sub rsp, 0xF0
00007f828abd7eae  vmovaps [rsp], xmm0
00007f828abd7eb3  vmovaps [rsp+0x10], xmm1
00007f828abd7eb9  vmovaps [rsp+0x20], xmm2
00007f828abd7ebf  vmovaps [rsp+0x30], xmm3
00007f828abd7ec5  vmovaps [rsp+0x40], xmm4
00007f828abd7ecb  vmovaps [rsp+0x50], xmm5
00007f828abd7ed1  vmovaps [rsp+0x60], xmm6
00007f828abd7ed7  vmovaps [rsp+0x70], xmm7
00007f828abd7edd  vmovaps [rsp+0x80], xmm8
00007f828abd7ee6  vmovaps [rsp+0x90], xmm9
00007f828abd7eef  vmovaps [rsp+0xA0], xmm10
00007f828abd7ef8  vmovaps [rsp+0xB0], xmm11
00007f828abd7f01  vmovaps [rsp+0xC0], xmm12
00007f828abd7f0a  vmovaps [rsp+0xD0], xmm13
00007f828abd7f13  vmovaps [rsp+0xE0], xmm14
00007f828abd7f1c  sub rsp, 0x30
00007f828abd7f20  movaps [rsp], xmm15
00007f828abd7f25  movaps [rsp+0x10], xmm5
00007f828abd7f2a  movaps [rsp+0x20], xmm3
00007f828abd7f2f  lea rdi, [rsp]
00007f828abd7f33  mov esi, 0x00
00007f828abd7f38  mov rax, 0x5BFE27FA6530
00007f828abd7f42  call rax
00007f828abd7f44  movaps xmm15, [rsp]
00007f828abd7f49  add rsp, 0x30
00007f828abd7f4d  vmovaps xmm0, [rsp]
00007f828abd7f52  vmovaps xmm1, [rsp+0x10]
00007f828abd7f58  vmovaps xmm2, [rsp+0x20]
00007f828abd7f5e  vmovaps xmm3, [rsp+0x30]
00007f828abd7f64  vmovaps xmm4, [rsp+0x40]
00007f828abd7f6a  vmovaps xmm5, [rsp+0x50]
00007f828abd7f70  vmovaps xmm6, [rsp+0x60]
00007f828abd7f76  vmovaps xmm7, [rsp+0x70]
00007f828abd7f7c  vmovaps xmm8, [rsp+0x80]
00007f828abd7f85  vmovaps xmm9, [rsp+0x90]
00007f828abd7f8e  vmovaps xmm10, [rsp+0xA0]
00007f828abd7f97  vmovaps xmm11, [rsp+0xB0]
00007f828abd7fa0  vmovaps xmm12, [rsp+0xC0]
00007f828abd7fa9  vmovaps xmm13, [rsp+0xD0]
00007f828abd7fb2  vmovaps xmm14, [rsp+0xE0]
00007f828abd7fbb  add rsp, 0xF0
00007f828abd7fc2  pop r11
00007f828abd7fc4  pop r10
00007f828abd7fc6  pop r9
00007f828abd7fc8  pop r8
00007f828abd7fca  pop rsi
00007f828abd7fcb  pop rdi
00007f828abd7fcc  pop rdx
00007f828abd7fcd  pop rcx
00007f828abd7fce  pop rax
00007f828abd7fcf  add rsp, 0x08
00007f828abd7fd3  jmp 0x00007F828ABD5EE6
00007f828abd7fd8  sub rsp, 0x08
00007f828abd7fdc  push rax
00007f828abd7fdd  push rcx
00007f828abd7fde  push rdx
00007f828abd7fdf  push rdi
00007f828abd7fe0  push rsi
00007f828abd7fe1  push r8
00007f828abd7fe3  push r9
00007f828abd7fe5  push r10
00007f828abd7fe7  push r11
00007f828abd7fe9  sub rsp, 0xF0
00007f828abd7ff0  vmovaps [rsp], xmm0
00007f828abd7ff5  vmovaps [rsp+0x10], xmm2
00007f828abd7ffb  vmovaps [rsp+0x20], xmm3
00007f828abd8001  vmovaps [rsp+0x30], xmm4
00007f828abd8007  vmovaps [rsp+0x40], xmm5
00007f828abd800d  vmovaps [rsp+0x50], xmm6
00007f828abd8013  vmovaps [rsp+0x60], xmm7
00007f828abd8019  vmovaps [rsp+0x70], xmm8
00007f828abd801f  vmovaps [rsp+0x80], xmm9
00007f828abd8028  vmovaps [rsp+0x90], xmm10
00007f828abd8031  vmovaps [rsp+0xA0], xmm11
00007f828abd803a  vmovaps [rsp+0xB0], xmm12
00007f828abd8043  vmovaps [rsp+0xC0], xmm13
00007f828abd804c  vmovaps [rsp+0xD0], xmm14
00007f828abd8055  vmovaps [rsp+0xE0], xmm15
00007f828abd805e  sub rsp, 0x30
00007f828abd8062  movaps [rsp], xmm1
00007f828abd8066  movaps [rsp+0x10], xmm5
00007f828abd806b  movaps [rsp+0x20], xmm4
00007f828abd8070  lea rdi, [rsp]
00007f828abd8074  mov esi, 0x00
00007f828abd8079  mov rax, 0x5BFE27FA6530
00007f828abd8083  call rax
00007f828abd8085  movaps xmm1, [rsp]
00007f828abd8089  add rsp, 0x30
00007f828abd808d  vmovaps xmm0, [rsp]
00007f828abd8092  vmovaps xmm2, [rsp+0x10]
00007f828abd8098  vmovaps xmm3, [rsp+0x20]
00007f828abd809e  vmovaps xmm4, [rsp+0x30]
00007f828abd80a4  vmovaps xmm5, [rsp+0x40]
00007f828abd80aa  vmovaps xmm6, [rsp+0x50]
00007f828abd80b0  vmovaps xmm7, [rsp+0x60]
00007f828abd80b6  vmovaps xmm8, [rsp+0x70]
00007f828abd80bc  vmovaps xmm9, [rsp+0x80]
00007f828abd80c5  vmovaps xmm10, [rsp+0x90]
00007f828abd80ce  vmovaps xmm11, [rsp+0xA0]
00007f828abd80d7  vmovaps xmm12, [rsp+0xB0]
00007f828abd80e0  vmovaps xmm13, [rsp+0xC0]
00007f828abd80e9  vmovaps xmm14, [rsp+0xD0]
00007f828abd80f2  vmovaps xmm15, [rsp+0xE0]
00007f828abd80fb  add rsp, 0xF0
00007f828abd8102  pop r11
00007f828abd8104  pop r10
00007f828abd8106  pop r9
00007f828abd8108  pop r8
00007f828abd810a  pop rsi
00007f828abd810b  pop rdi
00007f828abd810c  pop rdx
00007f828abd810d  pop rcx
00007f828abd810e  pop rax
00007f828abd810f  add rsp, 0x08
00007f828abd8113  jmp 0x00007F828ABD5F06
00007f828abd8118  sub rsp, 0x08
00007f828abd811c  push rax
00007f828abd811d  push rcx
00007f828abd811e  push rdx
00007f828abd811f  push rdi
00007f828abd8120  push rsi
00007f828abd8121  push r8
00007f828abd8123  push r9
00007f828abd8125  push r10
00007f828abd8127  push r11
00007f828abd8129  sub rsp, 0xF0
00007f828abd8130  vmovaps [rsp], xmm0
00007f828abd8135  vmovaps [rsp+0x10], xmm1
00007f828abd813b  vmovaps [rsp+0x20], xmm2
00007f828abd8141  vmovaps [rsp+0x30], xmm3
00007f828abd8147  vmovaps [rsp+0x40], xmm5
00007f828abd814d  vmovaps [rsp+0x50], xmm6
00007f828abd8153  vmovaps [rsp+0x60], xmm7
00007f828abd8159  vmovaps [rsp+0x70], xmm8
00007f828abd815f  vmovaps [rsp+0x80], xmm9
00007f828abd8168  vmovaps [rsp+0x90], xmm10
00007f828abd8171  vmovaps [rsp+0xA0], xmm11
00007f828abd817a  vmovaps [rsp+0xB0], xmm12
00007f828abd8183  vmovaps [rsp+0xC0], xmm13
00007f828abd818c  vmovaps [rsp+0xD0], xmm14
00007f828abd8195  vmovaps [rsp+0xE0], xmm15
00007f828abd819e  sub rsp, 0x30
00007f828abd81a2  movaps [rsp], xmm4
00007f828abd81a6  movaps [rsp+0x10], xmm3
00007f828abd81ab  movaps [rsp+0x20], xmm5
00007f828abd81b0  lea rdi, [rsp]
00007f828abd81b4  mov esi, 0x00
00007f828abd81b9  mov rax, 0x5BFE27FA6530
00007f828abd81c3  call rax
00007f828abd81c5  movaps xmm4, [rsp]
00007f828abd81c9  add rsp, 0x30
00007f828abd81cd  vmovaps xmm0, [rsp]
00007f828abd81d2  vmovaps xmm1, [rsp+0x10]
00007f828abd81d8  vmovaps xmm2, [rsp+0x20]
00007f828abd81de  vmovaps xmm3, [rsp+0x30]
00007f828abd81e4  vmovaps xmm5, [rsp+0x40]
00007f828abd81ea  vmovaps xmm6, [rsp+0x50]
00007f828abd81f0  vmovaps xmm7, [rsp+0x60]
00007f828abd81f6  vmovaps xmm8, [rsp+0x70]
00007f828abd81fc  vmovaps xmm9, [rsp+0x80]
00007f828abd8205  vmovaps xmm10, [rsp+0x90]
00007f828abd820e  vmovaps xmm11, [rsp+0xA0]
00007f828abd8217  vmovaps xmm12, [rsp+0xB0]
00007f828abd8220  vmovaps xmm13, [rsp+0xC0]
00007f828abd8229  vmovaps xmm14, [rsp+0xD0]
00007f828abd8232  vmovaps xmm15, [rsp+0xE0]
00007f828abd823b  add rsp, 0xF0
00007f828abd8242  pop r11
00007f828abd8244  pop r10
00007f828abd8246  pop r9
00007f828abd8248  pop r8
00007f828abd824a  pop rsi
00007f828abd824b  pop rdi
00007f828abd824c  pop rdx
00007f828abd824d  pop rcx
00007f828abd824e  pop rax
00007f828abd824f  add rsp, 0x08
00007f828abd8253  jmp 0x00007F828ABD5F54
00007f828abd8258  call 0x00007F828AAD64F0
00007f828abd825d  jmp 0x00007F828ABD5F61
00007f828abd8262  sub rsp, 0x08
00007f828abd8266  push rax
00007f828abd8267  push rcx
00007f828abd8268  push rdx
00007f828abd8269  push rdi
00007f828abd826a  push rsi
00007f828abd826b  push r8
00007f828abd826d  push r9
00007f828abd826f  push r10
00007f828abd8271  push r11
00007f828abd8273  sub rsp, 0xF0
00007f828abd827a  vmovaps [rsp], xmm0
00007f828abd827f  vmovaps [rsp+0x10], xmm1
00007f828abd8285  vmovaps [rsp+0x20], xmm2
00007f828abd828b  vmovaps [rsp+0x30], xmm3
00007f828abd8291  vmovaps [rsp+0x40], xmm4
00007f828abd8297  vmovaps [rsp+0x50], xmm6
00007f828abd829d  vmovaps [rsp+0x60], xmm7
00007f828abd82a3  vmovaps [rsp+0x70], xmm8
00007f828abd82a9  vmovaps [rsp+0x80], xmm9
00007f828abd82b2  vmovaps [rsp+0x90], xmm10
00007f828abd82bb  vmovaps [rsp+0xA0], xmm11
00007f828abd82c4  vmovaps [rsp+0xB0], xmm12
00007f828abd82cd  vmovaps [rsp+0xC0], xmm13
00007f828abd82d6  vmovaps [rsp+0xD0], xmm14
00007f828abd82df  vmovaps [rsp+0xE0], xmm15
00007f828abd82e8  sub rsp, 0x30
00007f828abd82ec  movaps [rsp], xmm5
00007f828abd82f0  movaps [rsp+0x10], xmm6
00007f828abd82f5  movaps [rsp+0x20], xmm3
00007f828abd82fa  lea rdi, [rsp]
00007f828abd82fe  mov esi, 0x00
00007f828abd8303  mov rax, 0x5BFE27FA6530
00007f828abd830d  call rax
00007f828abd830f  movaps xmm5, [rsp]
00007f828abd8313  add rsp, 0x30
00007f828abd8317  vmovaps xmm0, [rsp]
00007f828abd831c  vmovaps xmm1, [rsp+0x10]
00007f828abd8322  vmovaps xmm2, [rsp+0x20]
00007f828abd8328  vmovaps xmm3, [rsp+0x30]
00007f828abd832e  vmovaps xmm4, [rsp+0x40]
00007f828abd8334  vmovaps xmm6, [rsp+0x50]
00007f828abd833a  vmovaps xmm7, [rsp+0x60]
00007f828abd8340  vmovaps xmm8, [rsp+0x70]
00007f828abd8346  vmovaps xmm9, [rsp+0x80]
00007f828abd834f  vmovaps xmm10, [rsp+0x90]
00007f828abd8358  vmovaps xmm11, [rsp+0xA0]
00007f828abd8361  vmovaps xmm12, [rsp+0xB0]
00007f828abd836a  vmovaps xmm13, [rsp+0xC0]
00007f828abd8373  vmovaps xmm14, [rsp+0xD0]
00007f828abd837c  vmovaps xmm15, [rsp+0xE0]
00007f828abd8385  add rsp, 0xF0
00007f828abd838c  pop r11
00007f828abd838e  pop r10
00007f828abd8390  pop r9
00007f828abd8392  pop r8
00007f828abd8394  pop rsi
00007f828abd8395  pop rdi
00007f828abd8396  pop rdx
00007f828abd8397  pop rcx
00007f828abd8398  pop rax
00007f828abd8399  add rsp, 0x08
00007f828abd839d  jmp 0x00007F828ABD5F87
00007f828abd83a2  sub rsp, 0x08
00007f828abd83a6  push rax
00007f828abd83a7  push rcx
00007f828abd83a8  push rdx
00007f828abd83a9  push rdi
00007f828abd83aa  push rsi
00007f828abd83ab  push r8
00007f828abd83ad  push r9
00007f828abd83af  push r10
00007f828abd83b1  push r11
00007f828abd83b3  sub rsp, 0xF0
00007f828abd83ba  vmovaps [rsp], xmm0
00007f828abd83bf  vmovaps [rsp+0x10], xmm1
00007f828abd83c5  vmovaps [rsp+0x20], xmm2
00007f828abd83cb  vmovaps [rsp+0x30], xmm3
00007f828abd83d1  vmovaps [rsp+0x40], xmm4
00007f828abd83d7  vmovaps [rsp+0x50], xmm5
00007f828abd83dd  vmovaps [rsp+0x60], xmm7
00007f828abd83e3  vmovaps [rsp+0x70], xmm8
00007f828abd83e9  vmovaps [rsp+0x80], xmm9
00007f828abd83f2  vmovaps [rsp+0x90], xmm10
00007f828abd83fb  vmovaps [rsp+0xA0], xmm11
00007f828abd8404  vmovaps [rsp+0xB0], xmm12
00007f828abd840d  vmovaps [rsp+0xC0], xmm13
00007f828abd8416  vmovaps [rsp+0xD0], xmm14
00007f828abd841f  vmovaps [rsp+0xE0], xmm15
00007f828abd8428  sub rsp, 0x30
00007f828abd842c  movaps [rsp], xmm6
00007f828abd8430  movaps [rsp+0x10], xmm9
00007f828abd8436  movaps [rsp+0x20], xmm1
00007f828abd843b  lea rdi, [rsp]
00007f828abd843f  mov esi, 0x00
00007f828abd8444  mov rax, 0x5BFE27FA6530
00007f828abd844e  call rax
00007f828abd8450  movaps xmm6, [rsp]
00007f828abd8454  add rsp, 0x30
00007f828abd8458  vmovaps xmm0, [rsp]
00007f828abd845d  vmovaps xmm1, [rsp+0x10]
00007f828abd8463  vmovaps xmm2, [rsp+0x20]
00007f828abd8469  vmovaps xmm3, [rsp+0x30]
00007f828abd846f  vmovaps xmm4, [rsp+0x40]
00007f828abd8475  vmovaps xmm5, [rsp+0x50]
00007f828abd847b  vmovaps xmm7, [rsp+0x60]
00007f828abd8481  vmovaps xmm8, [rsp+0x70]
00007f828abd8487  vmovaps xmm9, [rsp+0x80]
00007f828abd8490  vmovaps xmm10, [rsp+0x90]
00007f828abd8499  vmovaps xmm11, [rsp+0xA0]
00007f828abd84a2  vmovaps xmm12, [rsp+0xB0]
00007f828abd84ab  vmovaps xmm13, [rsp+0xC0]
00007f828abd84b4  vmovaps xmm14, [rsp+0xD0]
00007f828abd84bd  vmovaps xmm15, [rsp+0xE0]
00007f828abd84c6  add rsp, 0xF0
00007f828abd84cd  pop r11
00007f828abd84cf  pop r10
00007f828abd84d1  pop r9
00007f828abd84d3  pop r8
00007f828abd84d5  pop rsi
00007f828abd84d6  pop rdi
00007f828abd84d7  pop rdx
00007f828abd84d8  pop rcx
00007f828abd84d9  pop rax
00007f828abd84da  add rsp, 0x08
00007f828abd84de  jmp 0x00007F828ABD5FAB
00007f828abd84e3  sub rsp, 0x08
00007f828abd84e7  push rax
00007f828abd84e8  push rcx
00007f828abd84e9  push rdx
00007f828abd84ea  push rdi
00007f828abd84eb  push rsi
00007f828abd84ec  push r8
00007f828abd84ee  push r9
00007f828abd84f0  push r10
00007f828abd84f2  push r11
00007f828abd84f4  sub rsp, 0xF0
00007f828abd84fb  vmovaps [rsp], xmm0
00007f828abd8500  vmovaps [rsp+0x10], xmm1
00007f828abd8506  vmovaps [rsp+0x20], xmm2
00007f828abd850c  vmovaps [rsp+0x30], xmm3
00007f828abd8512  vmovaps [rsp+0x40], xmm4
00007f828abd8518  vmovaps [rsp+0x50], xmm5
00007f828abd851e  vmovaps [rsp+0x60], xmm6
00007f828abd8524  vmovaps [rsp+0x70], xmm7
00007f828abd852a  vmovaps [rsp+0x80], xmm8
00007f828abd8533  vmovaps [rsp+0x90], xmm10
00007f828abd853c  vmovaps [rsp+0xA0], xmm11
00007f828abd8545  vmovaps [rsp+0xB0], xmm12
00007f828abd854e  vmovaps [rsp+0xC0], xmm13
00007f828abd8557  vmovaps [rsp+0xD0], xmm14
00007f828abd8560  vmovaps [rsp+0xE0], xmm15
00007f828abd8569  sub rsp, 0x30
00007f828abd856d  movaps [rsp], xmm9
00007f828abd8572  movaps [rsp+0x10], xmm3
00007f828abd8577  movaps [rsp+0x20], xmm1
00007f828abd857c  lea rdi, [rsp]
00007f828abd8580  mov esi, 0x00
00007f828abd8585  mov rax, 0x5BFE27FA6530
00007f828abd858f  call rax
00007f828abd8591  movaps xmm9, [rsp]
00007f828abd8596  add rsp, 0x30
00007f828abd859a  vmovaps xmm0, [rsp]
00007f828abd859f  vmovaps xmm1, [rsp+0x10]
00007f828abd85a5  vmovaps xmm2, [rsp+0x20]
00007f828abd85ab  vmovaps xmm3, [rsp+0x30]
00007f828abd85b1  vmovaps xmm4, [rsp+0x40]
00007f828abd85b7  vmovaps xmm5, [rsp+0x50]
00007f828abd85bd  vmovaps xmm6, [rsp+0x60]
00007f828abd85c3  vmovaps xmm7, [rsp+0x70]
00007f828abd85c9  vmovaps xmm8, [rsp+0x80]
00007f828abd85d2  vmovaps xmm10, [rsp+0x90]
00007f828abd85db  vmovaps xmm11, [rsp+0xA0]
00007f828abd85e4  vmovaps xmm12, [rsp+0xB0]
00007f828abd85ed  vmovaps xmm13, [rsp+0xC0]
00007f828abd85f6  vmovaps xmm14, [rsp+0xD0]
00007f828abd85ff  vmovaps xmm15, [rsp+0xE0]
00007f828abd8608  add rsp, 0xF0
00007f828abd860f  pop r11
00007f828abd8611  pop r10
00007f828abd8613  pop r9
00007f828abd8615  pop r8
00007f828abd8617  pop rsi
00007f828abd8618  pop rdi
00007f828abd8619  pop rdx
00007f828abd861a  pop rcx
00007f828abd861b  pop rax
00007f828abd861c  add rsp, 0x08
00007f828abd8620  jmp 0x00007F828ABD5FF7
00007f828abd8625  call 0x00007F828AAD64F0
00007f828abd862a  jmp 0x00007F828ABD6004
00007f828abd862f  sub rsp, 0x08
00007f828abd8633  push rax
00007f828abd8634  push rcx
00007f828abd8635  push rdx
00007f828abd8636  push rdi
00007f828abd8637  push rsi
00007f828abd8638  push r8
00007f828abd863a  push r9
00007f828abd863c  push r10
00007f828abd863e  push r11
00007f828abd8640  sub rsp, 0xF0
00007f828abd8647  vmovaps [rsp], xmm0
00007f828abd864c  vmovaps [rsp+0x10], xmm1
00007f828abd8652  vmovaps [rsp+0x20], xmm2
00007f828abd8658  vmovaps [rsp+0x30], xmm3
00007f828abd865e  vmovaps [rsp+0x40], xmm4
00007f828abd8664  vmovaps [rsp+0x50], xmm5
00007f828abd866a  vmovaps [rsp+0x60], xmm6
00007f828abd8670  vmovaps [rsp+0x70], xmm7
00007f828abd8676  vmovaps [rsp+0x80], xmm8
00007f828abd867f  vmovaps [rsp+0x90], xmm9
00007f828abd8688  vmovaps [rsp+0xA0], xmm10
00007f828abd8691  vmovaps [rsp+0xB0], xmm11
00007f828abd869a  vmovaps [rsp+0xC0], xmm12
00007f828abd86a3  vmovaps [rsp+0xD0], xmm13
00007f828abd86ac  vmovaps [rsp+0xE0], xmm14
00007f828abd86b5  sub rsp, 0x30
00007f828abd86b9  movaps [rsp], xmm15
00007f828abd86be  movaps [rsp+0x10], xmm3
00007f828abd86c3  movaps [rsp+0x20], xmm7
00007f828abd86c8  lea rdi, [rsp]
00007f828abd86cc  mov esi, 0x00
00007f828abd86d1  mov rax, 0x5BFE27FA6530
00007f828abd86db  call rax
00007f828abd86dd  movaps xmm15, [rsp]
00007f828abd86e2  add rsp, 0x30
00007f828abd86e6  vmovaps xmm0, [rsp]
00007f828abd86eb  vmovaps xmm1, [rsp+0x10]
00007f828abd86f1  vmovaps xmm2, [rsp+0x20]
00007f828abd86f7  vmovaps xmm3, [rsp+0x30]
00007f828abd86fd  vmovaps xmm4, [rsp+0x40]
00007f828abd8703  vmovaps xmm5, [rsp+0x50]
00007f828abd8709  vmovaps xmm6, [rsp+0x60]
00007f828abd870f  vmovaps xmm7, [rsp+0x70]
00007f828abd8715  vmovaps xmm8, [rsp+0x80]
00007f828abd871e  vmovaps xmm9, [rsp+0x90]
00007f828abd8727  vmovaps xmm10, [rsp+0xA0]
00007f828abd8730  vmovaps xmm11, [rsp+0xB0]
00007f828abd8739  vmovaps xmm12, [rsp+0xC0]
00007f828abd8742  vmovaps xmm13, [rsp+0xD0]
00007f828abd874b  vmovaps xmm14, [rsp+0xE0]
00007f828abd8754  add rsp, 0xF0
00007f828abd875b  pop r11
00007f828abd875d  pop r10
00007f828abd875f  pop r9
00007f828abd8761  pop r8
00007f828abd8763  pop rsi
00007f828abd8764  pop rdi
00007f828abd8765  pop rdx
00007f828abd8766  pop rcx
00007f828abd8767  pop rax
00007f828abd8768  add rsp, 0x08
00007f828abd876c  jmp 0x00007F828ABD6030
00007f828abd8771  sub rsp, 0x08
00007f828abd8775  push rax
00007f828abd8776  push rcx
00007f828abd8777  push rdx
00007f828abd8778  push rdi
00007f828abd8779  push rsi
00007f828abd877a  push r8
00007f828abd877c  push r9
00007f828abd877e  push r10
00007f828abd8780  push r11
00007f828abd8782  sub rsp, 0xF0
00007f828abd8789  vmovaps [rsp], xmm0
00007f828abd878e  vmovaps [rsp+0x10], xmm1
00007f828abd8794  vmovaps [rsp+0x20], xmm2
00007f828abd879a  vmovaps [rsp+0x30], xmm4
00007f828abd87a0  vmovaps [rsp+0x40], xmm5
00007f828abd87a6  vmovaps [rsp+0x50], xmm6
00007f828abd87ac  vmovaps [rsp+0x60], xmm7
00007f828abd87b2  vmovaps [rsp+0x70], xmm8
00007f828abd87b8  vmovaps [rsp+0x80], xmm9
00007f828abd87c1  vmovaps [rsp+0x90], xmm10
00007f828abd87ca  vmovaps [rsp+0xA0], xmm11
00007f828abd87d3  vmovaps [rsp+0xB0], xmm12
00007f828abd87dc  vmovaps [rsp+0xC0], xmm13
00007f828abd87e5  vmovaps [rsp+0xD0], xmm14
00007f828abd87ee  vmovaps [rsp+0xE0], xmm15
00007f828abd87f7  sub rsp, 0x30
00007f828abd87fb  movaps [rsp], xmm3
00007f828abd87ff  movaps [rsp+0x10], xmm1
00007f828abd8804  movaps [rsp+0x20], xmm15
00007f828abd880a  lea rdi, [rsp]
00007f828abd880e  mov esi, 0x00
00007f828abd8813  mov rax, 0x5BFE27FA6530
00007f828abd881d  call rax
00007f828abd881f  movaps xmm3, [rsp]
00007f828abd8823  add rsp, 0x30
00007f828abd8827  vmovaps xmm0, [rsp]
00007f828abd882c  vmovaps xmm1, [rsp+0x10]
00007f828abd8832  vmovaps xmm2, [rsp+0x20]
00007f828abd8838  vmovaps xmm4, [rsp+0x30]
00007f828abd883e  vmovaps xmm5, [rsp+0x40]
00007f828abd8844  vmovaps xmm6, [rsp+0x50]
00007f828abd884a  vmovaps xmm7, [rsp+0x60]
00007f828abd8850  vmovaps xmm8, [rsp+0x70]
00007f828abd8856  vmovaps xmm9, [rsp+0x80]
00007f828abd885f  vmovaps xmm10, [rsp+0x90]
00007f828abd8868  vmovaps xmm11, [rsp+0xA0]
00007f828abd8871  vmovaps xmm12, [rsp+0xB0]
00007f828abd887a  vmovaps xmm13, [rsp+0xC0]
00007f828abd8883  vmovaps xmm14, [rsp+0xD0]
00007f828abd888c  vmovaps xmm15, [rsp+0xE0]
00007f828abd8895  add rsp, 0xF0
00007f828abd889c  pop r11
00007f828abd889e  pop r10
00007f828abd88a0  pop r9
00007f828abd88a2  pop r8
00007f828abd88a4  pop rsi
00007f828abd88a5  pop rdi
00007f828abd88a6  pop rdx
00007f828abd88a7  pop rcx
00007f828abd88a8  pop rax
00007f828abd88a9  add rsp, 0x08
00007f828abd88ad  jmp 0x00007F828ABD60BF
00007f828abd88b2  call 0x00007F828AAD64F0
00007f828abd88b7  jmp 0x00007F828ABD60C9
00007f828abd88bc  sub rsp, 0x08
00007f828abd88c0  push rax
00007f828abd88c1  push rcx
00007f828abd88c2  push rdx
00007f828abd88c3  push rdi
00007f828abd88c4  push rsi
00007f828abd88c5  push r8
00007f828abd88c7  push r9
00007f828abd88c9  push r10
00007f828abd88cb  push r11
00007f828abd88cd  sub rsp, 0xF0
00007f828abd88d4  vmovaps [rsp], xmm0
00007f828abd88d9  vmovaps [rsp+0x10], xmm1
00007f828abd88df  vmovaps [rsp+0x20], xmm2
00007f828abd88e5  vmovaps [rsp+0x30], xmm3
00007f828abd88eb  vmovaps [rsp+0x40], xmm4
00007f828abd88f1  vmovaps [rsp+0x50], xmm5
00007f828abd88f7  vmovaps [rsp+0x60], xmm6
00007f828abd88fd  vmovaps [rsp+0x70], xmm7
00007f828abd8903  vmovaps [rsp+0x80], xmm8
00007f828abd890c  vmovaps [rsp+0x90], xmm9
00007f828abd8915  vmovaps [rsp+0xA0], xmm10
00007f828abd891e  vmovaps [rsp+0xB0], xmm11
00007f828abd8927  vmovaps [rsp+0xC0], xmm12
00007f828abd8930  vmovaps [rsp+0xD0], xmm13
00007f828abd8939  vmovaps [rsp+0xE0], xmm14
00007f828abd8942  sub rsp, 0x30
00007f828abd8946  movaps [rsp], xmm15
00007f828abd894b  movaps [rsp+0x10], xmm14
00007f828abd8951  movaps [rsp+0x20], xmm4
00007f828abd8956  lea rdi, [rsp]
00007f828abd895a  mov esi, 0x00
00007f828abd895f  mov rax, 0x5BFE27FA6530
00007f828abd8969  call rax
00007f828abd896b  movaps xmm15, [rsp]
00007f828abd8970  add rsp, 0x30
00007f828abd8974  vmovaps xmm0, [rsp]
00007f828abd8979  vmovaps xmm1, [rsp+0x10]
00007f828abd897f  vmovaps xmm2, [rsp+0x20]
00007f828abd8985  vmovaps xmm3, [rsp+0x30]
00007f828abd898b  vmovaps xmm4, [rsp+0x40]
00007f828abd8991  vmovaps xmm5, [rsp+0x50]
00007f828abd8997  vmovaps xmm6, [rsp+0x60]
00007f828abd899d  vmovaps xmm7, [rsp+0x70]
00007f828abd89a3  vmovaps xmm8, [rsp+0x80]
00007f828abd89ac  vmovaps xmm9, [rsp+0x90]
00007f828abd89b5  vmovaps xmm10, [rsp+0xA0]
00007f828abd89be  vmovaps xmm11, [rsp+0xB0]
00007f828abd89c7  vmovaps xmm12, [rsp+0xC0]
00007f828abd89d0  vmovaps xmm13, [rsp+0xD0]
00007f828abd89d9  vmovaps xmm14, [rsp+0xE0]
00007f828abd89e2  add rsp, 0xF0
00007f828abd89e9  pop r11
00007f828abd89eb  pop r10
00007f828abd89ed  pop r9
00007f828abd89ef  pop r8
00007f828abd89f1  pop rsi
00007f828abd89f2  pop rdi
00007f828abd89f3  pop rdx
00007f828abd89f4  pop rcx
00007f828abd89f5  pop rax
00007f828abd89f6  add rsp, 0x08
00007f828abd89fa  jmp 0x00007F828ABD60F7
00007f828abd89ff  sub rsp, 0x08
00007f828abd8a03  push rax
00007f828abd8a04  push rcx
00007f828abd8a05  push rdx
00007f828abd8a06  push rdi
00007f828abd8a07  push rsi
00007f828abd8a08  push r8
00007f828abd8a0a  push r9
00007f828abd8a0c  push r10
00007f828abd8a0e  push r11
00007f828abd8a10  sub rsp, 0xF0
00007f828abd8a17  vmovaps [rsp], xmm0
00007f828abd8a1c  vmovaps [rsp+0x10], xmm1
00007f828abd8a22  vmovaps [rsp+0x20], xmm2
00007f828abd8a28  vmovaps [rsp+0x30], xmm3
00007f828abd8a2e  vmovaps [rsp+0x40], xmm4
00007f828abd8a34  vmovaps [rsp+0x50], xmm5
00007f828abd8a3a  vmovaps [rsp+0x60], xmm6
00007f828abd8a40  vmovaps [rsp+0x70], xmm7
00007f828abd8a46  vmovaps [rsp+0x80], xmm8
00007f828abd8a4f  vmovaps [rsp+0x90], xmm9
00007f828abd8a58  vmovaps [rsp+0xA0], xmm10
00007f828abd8a61  vmovaps [rsp+0xB0], xmm11
00007f828abd8a6a  vmovaps [rsp+0xC0], xmm12
00007f828abd8a73  vmovaps [rsp+0xD0], xmm13
00007f828abd8a7c  vmovaps [rsp+0xE0], xmm15
00007f828abd8a85  sub rsp, 0x30
00007f828abd8a89  movaps [rsp], xmm14
00007f828abd8a8e  movaps [rsp+0x10], xmm2
00007f828abd8a93  movaps [rsp+0x20], xmm1
00007f828abd8a98  lea rdi, [rsp]
00007f828abd8a9c  mov esi, 0x00
00007f828abd8aa1  mov rax, 0x5BFE27FA6530
00007f828abd8aab  call rax
00007f828abd8aad  movaps xmm14, [rsp]
00007f828abd8ab2  add rsp, 0x30
00007f828abd8ab6  vmovaps xmm0, [rsp]
00007f828abd8abb  vmovaps xmm1, [rsp+0x10]
00007f828abd8ac1  vmovaps xmm2, [rsp+0x20]
00007f828abd8ac7  vmovaps xmm3, [rsp+0x30]
00007f828abd8acd  vmovaps xmm4, [rsp+0x40]
00007f828abd8ad3  vmovaps xmm5, [rsp+0x50]
00007f828abd8ad9  vmovaps xmm6, [rsp+0x60]
00007f828abd8adf  vmovaps xmm7, [rsp+0x70]
00007f828abd8ae5  vmovaps xmm8, [rsp+0x80]
00007f828abd8aee  vmovaps xmm9, [rsp+0x90]
00007f828abd8af7  vmovaps xmm10, [rsp+0xA0]
00007f828abd8b00  vmovaps xmm11, [rsp+0xB0]
00007f828abd8b09  vmovaps xmm12, [rsp+0xC0]
00007f828abd8b12  vmovaps xmm13, [rsp+0xD0]
00007f828abd8b1b  vmovaps xmm15, [rsp+0xE0]
00007f828abd8b24  add rsp, 0xF0
00007f828abd8b2b  pop r11
00007f828abd8b2d  pop r10
00007f828abd8b2f  pop r9
00007f828abd8b31  pop r8
00007f828abd8b33  pop rsi
00007f828abd8b34  pop rdi
00007f828abd8b35  pop rdx
00007f828abd8b36  pop rcx
00007f828abd8b37  pop rax
00007f828abd8b38  add rsp, 0x08
00007f828abd8b3c  jmp 0x00007F828ABD611D
00007f828abd8b41  sub rsp, 0x08
00007f828abd8b45  push rax
00007f828abd8b46  push rcx
00007f828abd8b47  push rdx
00007f828abd8b48  push rdi
00007f828abd8b49  push rsi
00007f828abd8b4a  push r8
00007f828abd8b4c  push r9
00007f828abd8b4e  push r10
00007f828abd8b50  push r11
00007f828abd8b52  sub rsp, 0xF0
00007f828abd8b59  vmovaps [rsp], xmm0
00007f828abd8b5e  vmovaps [rsp+0x10], xmm2
00007f828abd8b64  vmovaps [rsp+0x20], xmm3
00007f828abd8b6a  vmovaps [rsp+0x30], xmm4
00007f828abd8b70  vmovaps [rsp+0x40], xmm5
00007f828abd8b76  vmovaps [rsp+0x50], xmm6
00007f828abd8b7c  vmovaps [rsp+0x60], xmm7
00007f828abd8b82  vmovaps [rsp+0x70], xmm8
00007f828abd8b88  vmovaps [rsp+0x80], xmm9
00007f828abd8b91  vmovaps [rsp+0x90], xmm10
00007f828abd8b9a  vmovaps [rsp+0xA0], xmm11
00007f828abd8ba3  vmovaps [rsp+0xB0], xmm12
00007f828abd8bac  vmovaps [rsp+0xC0], xmm13
00007f828abd8bb5  vmovaps [rsp+0xD0], xmm14
00007f828abd8bbe  vmovaps [rsp+0xE0], xmm15
00007f828abd8bc7  sub rsp, 0x30
00007f828abd8bcb  movaps [rsp], xmm1
00007f828abd8bcf  movaps [rsp+0x10], xmm4
00007f828abd8bd4  movaps [rsp+0x20], xmm9
00007f828abd8bda  lea rdi, [rsp]
00007f828abd8bde  mov esi, 0x00
00007f828abd8be3  mov rax, 0x5BFE27FA6530
00007f828abd8bed  call rax
00007f828abd8bef  movaps xmm1, [rsp]
00007f828abd8bf3  add rsp, 0x30
00007f828abd8bf7  vmovaps xmm0, [rsp]
00007f828abd8bfc  vmovaps xmm2, [rsp+0x10]
00007f828abd8c02  vmovaps xmm3, [rsp+0x20]
00007f828abd8c08  vmovaps xmm4, [rsp+0x30]
00007f828abd8c0e  vmovaps xmm5, [rsp+0x40]
00007f828abd8c14  vmovaps xmm6, [rsp+0x50]
00007f828abd8c1a  vmovaps xmm7, [rsp+0x60]
00007f828abd8c20  vmovaps xmm8, [rsp+0x70]
00007f828abd8c26  vmovaps xmm9, [rsp+0x80]
00007f828abd8c2f  vmovaps xmm10, [rsp+0x90]
00007f828abd8c38  vmovaps xmm11, [rsp+0xA0]
00007f828abd8c41  vmovaps xmm12, [rsp+0xB0]
00007f828abd8c4a  vmovaps xmm13, [rsp+0xC0]
00007f828abd8c53  vmovaps xmm14, [rsp+0xD0]
00007f828abd8c5c  vmovaps xmm15, [rsp+0xE0]
00007f828abd8c65  add rsp, 0xF0
00007f828abd8c6c  pop r11
00007f828abd8c6e  pop r10
00007f828abd8c70  pop r9
00007f828abd8c72  pop r8
00007f828abd8c74  pop rsi
00007f828abd8c75  pop rdi
00007f828abd8c76  pop rdx
00007f828abd8c77  pop rcx
00007f828abd8c78  pop rax
00007f828abd8c79  add rsp, 0x08
00007f828abd8c7d  jmp 0x00007F828ABD613B
00007f828abd8c82  sub rsp, 0x08
00007f828abd8c86  push rax
00007f828abd8c87  push rcx
00007f828abd8c88  push rdx
00007f828abd8c89  push rdi
00007f828abd8c8a  push rsi
00007f828abd8c8b  push r8
00007f828abd8c8d  push r9
00007f828abd8c8f  push r10
00007f828abd8c91  push r11
00007f828abd8c93  sub rsp, 0xF0
00007f828abd8c9a  vmovaps [rsp], xmm0
00007f828abd8c9f  vmovaps [rsp+0x10], xmm1
00007f828abd8ca5  vmovaps [rsp+0x20], xmm2
00007f828abd8cab  vmovaps [rsp+0x30], xmm3
00007f828abd8cb1  vmovaps [rsp+0x40], xmm5
00007f828abd8cb7  vmovaps [rsp+0x50], xmm6
00007f828abd8cbd  vmovaps [rsp+0x60], xmm7
00007f828abd8cc3  vmovaps [rsp+0x70], xmm8
00007f828abd8cc9  vmovaps [rsp+0x80], xmm9
00007f828abd8cd2  vmovaps [rsp+0x90], xmm10
00007f828abd8cdb  vmovaps [rsp+0xA0], xmm11
00007f828abd8ce4  vmovaps [rsp+0xB0], xmm12
00007f828abd8ced  vmovaps [rsp+0xC0], xmm13
00007f828abd8cf6  vmovaps [rsp+0xD0], xmm14
00007f828abd8cff  vmovaps [rsp+0xE0], xmm15
00007f828abd8d08  sub rsp, 0x30
00007f828abd8d0c  movaps [rsp], xmm4
00007f828abd8d10  movaps [rsp+0x10], xmm2
00007f828abd8d15  movaps [rsp+0x20], xmm9
00007f828abd8d1b  lea rdi, [rsp]
00007f828abd8d1f  mov esi, 0x00
00007f828abd8d24  mov rax, 0x5BFE27FA6530
00007f828abd8d2e  call rax
00007f828abd8d30  movaps xmm4, [rsp]
00007f828abd8d34  add rsp, 0x30
00007f828abd8d38  vmovaps xmm0, [rsp]
00007f828abd8d3d  vmovaps xmm1, [rsp+0x10]
00007f828abd8d43  vmovaps xmm2, [rsp+0x20]
00007f828abd8d49  vmovaps xmm3, [rsp+0x30]
00007f828abd8d4f  vmovaps xmm5, [rsp+0x40]
00007f828abd8d55  vmovaps xmm6, [rsp+0x50]
00007f828abd8d5b  vmovaps xmm7, [rsp+0x60]
00007f828abd8d61  vmovaps xmm8, [rsp+0x70]
00007f828abd8d67  vmovaps xmm9, [rsp+0x80]
00007f828abd8d70  vmovaps xmm10, [rsp+0x90]
00007f828abd8d79  vmovaps xmm11, [rsp+0xA0]
00007f828abd8d82  vmovaps xmm12, [rsp+0xB0]
00007f828abd8d8b  vmovaps xmm13, [rsp+0xC0]
00007f828abd8d94  vmovaps xmm14, [rsp+0xD0]
00007f828abd8d9d  vmovaps xmm15, [rsp+0xE0]
00007f828abd8da6  add rsp, 0xF0
00007f828abd8dad  pop r11
00007f828abd8daf  pop r10
00007f828abd8db1  pop r9
00007f828abd8db3  pop r8
00007f828abd8db5  pop rsi
00007f828abd8db6  pop rdi
00007f828abd8db7  pop rdx
00007f828abd8db8  pop rcx
00007f828abd8db9  pop rax
00007f828abd8dba  add rsp, 0x08
00007f828abd8dbe  jmp 0x00007F828ABD616B
00007f828abd8dc3  sub rsp, 0x08
00007f828abd8dc7  push rax
00007f828abd8dc8  push rcx
00007f828abd8dc9  push rdx
00007f828abd8dca  push rdi
00007f828abd8dcb  push rsi
00007f828abd8dcc  push r8
00007f828abd8dce  push r9
00007f828abd8dd0  push r10
00007f828abd8dd2  push r11
00007f828abd8dd4  sub rsp, 0xF0
00007f828abd8ddb  vmovaps [rsp], xmm0
00007f828abd8de0  vmovaps [rsp+0x10], xmm1
00007f828abd8de6  vmovaps [rsp+0x20], xmm2
00007f828abd8dec  vmovaps [rsp+0x30], xmm3
00007f828abd8df2  vmovaps [rsp+0x40], xmm4
00007f828abd8df8  vmovaps [rsp+0x50], xmm5
00007f828abd8dfe  vmovaps [rsp+0x60], xmm6
00007f828abd8e04  vmovaps [rsp+0x70], xmm7
00007f828abd8e0a  vmovaps [rsp+0x80], xmm8
00007f828abd8e13  vmovaps [rsp+0x90], xmm10
00007f828abd8e1c  vmovaps [rsp+0xA0], xmm11
00007f828abd8e25  vmovaps [rsp+0xB0], xmm12
00007f828abd8e2e  vmovaps [rsp+0xC0], xmm13
00007f828abd8e37  vmovaps [rsp+0xD0], xmm14
00007f828abd8e40  vmovaps [rsp+0xE0], xmm15
00007f828abd8e49  sub rsp, 0x30
00007f828abd8e4d  movaps [rsp], xmm9
00007f828abd8e52  movaps [rsp+0x10], xmm2
00007f828abd8e57  movaps [rsp+0x20], xmm1
00007f828abd8e5c  lea rdi, [rsp]
00007f828abd8e60  mov esi, 0x00
00007f828abd8e65  mov rax, 0x5BFE27FA6530
00007f828abd8e6f  call rax
00007f828abd8e71  movaps xmm9, [rsp]
00007f828abd8e76  add rsp, 0x30
00007f828abd8e7a  vmovaps xmm0, [rsp]
00007f828abd8e7f  vmovaps xmm1, [rsp+0x10]
00007f828abd8e85  vmovaps xmm2, [rsp+0x20]
00007f828abd8e8b  vmovaps xmm3, [rsp+0x30]
00007f828abd8e91  vmovaps xmm4, [rsp+0x40]
00007f828abd8e97  vmovaps xmm5, [rsp+0x50]
00007f828abd8e9d  vmovaps xmm6, [rsp+0x60]
00007f828abd8ea3  vmovaps xmm7, [rsp+0x70]
00007f828abd8ea9  vmovaps xmm8, [rsp+0x80]
00007f828abd8eb2  vmovaps xmm10, [rsp+0x90]
00007f828abd8ebb  vmovaps xmm11, [rsp+0xA0]
00007f828abd8ec4  vmovaps xmm12, [rsp+0xB0]
00007f828abd8ecd  vmovaps xmm13, [rsp+0xC0]
00007f828abd8ed6  vmovaps xmm14, [rsp+0xD0]
00007f828abd8edf  vmovaps xmm15, [rsp+0xE0]
00007f828abd8ee8  add rsp, 0xF0
00007f828abd8eef  pop r11
00007f828abd8ef1  pop r10
00007f828abd8ef3  pop r9
00007f828abd8ef5  pop r8
00007f828abd8ef7  pop rsi
00007f828abd8ef8  pop rdi
00007f828abd8ef9  pop rdx
00007f828abd8efa  pop rcx
00007f828abd8efb  pop rax
00007f828abd8efc  add rsp, 0x08
00007f828abd8f00  jmp 0x00007F828ABD61A1
00007f828abd8f05  sub rsp, 0x08
00007f828abd8f09  push rax
00007f828abd8f0a  push rcx
00007f828abd8f0b  push rdx
00007f828abd8f0c  push rdi
00007f828abd8f0d  push rsi
00007f828abd8f0e  push r8
00007f828abd8f10  push r9
00007f828abd8f12  push r10
00007f828abd8f14  push r11
00007f828abd8f16  sub rsp, 0xF0
00007f828abd8f1d  vmovaps [rsp], xmm0
00007f828abd8f22  vmovaps [rsp+0x10], xmm2
00007f828abd8f28  vmovaps [rsp+0x20], xmm3
00007f828abd8f2e  vmovaps [rsp+0x30], xmm4
00007f828abd8f34  vmovaps [rsp+0x40], xmm5
00007f828abd8f3a  vmovaps [rsp+0x50], xmm6
00007f828abd8f40  vmovaps [rsp+0x60], xmm7
00007f828abd8f46  vmovaps [rsp+0x70], xmm8
00007f828abd8f4c  vmovaps [rsp+0x80], xmm9
00007f828abd8f55  vmovaps [rsp+0x90], xmm10
00007f828abd8f5e  vmovaps [rsp+0xA0], xmm11
00007f828abd8f67  vmovaps [rsp+0xB0], xmm12
00007f828abd8f70  vmovaps [rsp+0xC0], xmm13
00007f828abd8f79  vmovaps [rsp+0xD0], xmm14
00007f828abd8f82  vmovaps [rsp+0xE0], xmm15
00007f828abd8f8b  sub rsp, 0x30
00007f828abd8f8f  movaps [rsp], xmm1
00007f828abd8f93  movaps [rsp+0x10], xmm15
00007f828abd8f99  movaps [rsp+0x20], xmm6
00007f828abd8f9e  lea rdi, [rsp]
00007f828abd8fa2  mov esi, 0x00
00007f828abd8fa7  mov rax, 0x5BFE27FA6530
00007f828abd8fb1  call rax
00007f828abd8fb3  movaps xmm1, [rsp]
00007f828abd8fb7  add rsp, 0x30
00007f828abd8fbb  vmovaps xmm0, [rsp]
00007f828abd8fc0  vmovaps xmm2, [rsp+0x10]
00007f828abd8fc6  vmovaps xmm3, [rsp+0x20]
00007f828abd8fcc  vmovaps xmm4, [rsp+0x30]
00007f828abd8fd2  vmovaps xmm5, [rsp+0x40]
00007f828abd8fd8  vmovaps xmm6, [rsp+0x50]
00007f828abd8fde  vmovaps xmm7, [rsp+0x60]
00007f828abd8fe4  vmovaps xmm8, [rsp+0x70]
00007f828abd8fea  vmovaps xmm9, [rsp+0x80]
00007f828abd8ff3  vmovaps xmm10, [rsp+0x90]
00007f828abd8ffc  vmovaps xmm11, [rsp+0xA0]
00007f828abd9005  vmovaps xmm12, [rsp+0xB0]
00007f828abd900e  vmovaps xmm13, [rsp+0xC0]
00007f828abd9017  vmovaps xmm14, [rsp+0xD0]
00007f828abd9020  vmovaps xmm15, [rsp+0xE0]
00007f828abd9029  add rsp, 0xF0
00007f828abd9030  pop r11
00007f828abd9032  pop r10
00007f828abd9034  pop r9
00007f828abd9036  pop r8
00007f828abd9038  pop rsi
00007f828abd9039  pop rdi
00007f828abd903a  pop rdx
00007f828abd903b  pop rcx
00007f828abd903c  pop rax
00007f828abd903d  add rsp, 0x08
00007f828abd9041  jmp 0x00007F828ABD61C2
00007f828abd9046  sub rsp, 0x08
00007f828abd904a  push rax
00007f828abd904b  push rcx
00007f828abd904c  push rdx
00007f828abd904d  push rdi
00007f828abd904e  push rsi
00007f828abd904f  push r8
00007f828abd9051  push r9
00007f828abd9053  push r10
00007f828abd9055  push r11
00007f828abd9057  sub rsp, 0xF0
00007f828abd905e  vmovaps [rsp], xmm0
00007f828abd9063  vmovaps [rsp+0x10], xmm1
00007f828abd9069  vmovaps [rsp+0x20], xmm2
00007f828abd906f  vmovaps [rsp+0x30], xmm3
00007f828abd9075  vmovaps [rsp+0x40], xmm4
00007f828abd907b  vmovaps [rsp+0x50], xmm5
00007f828abd9081  vmovaps [rsp+0x60], xmm6
00007f828abd9087  vmovaps [rsp+0x70], xmm7
00007f828abd908d  vmovaps [rsp+0x80], xmm8
00007f828abd9096  vmovaps [rsp+0x90], xmm9
00007f828abd909f  vmovaps [rsp+0xA0], xmm10
00007f828abd90a8  vmovaps [rsp+0xB0], xmm11
00007f828abd90b1  vmovaps [rsp+0xC0], xmm12
00007f828abd90ba  vmovaps [rsp+0xD0], xmm13
00007f828abd90c3  vmovaps [rsp+0xE0], xmm14
00007f828abd90cc  sub rsp, 0x30
00007f828abd90d0  movaps [rsp], xmm15
00007f828abd90d5  movaps [rsp+0x10], xmm5
00007f828abd90da  movaps [rsp+0x20], xmm3
00007f828abd90df  lea rdi, [rsp]
00007f828abd90e3  mov esi, 0x00
00007f828abd90e8  mov rax, 0x5BFE27FA6530
00007f828abd90f2  call rax
00007f828abd90f4  movaps xmm15, [rsp]
00007f828abd90f9  add rsp, 0x30
00007f828abd90fd  vmovaps xmm0, [rsp]
00007f828abd9102  vmovaps xmm1, [rsp+0x10]
00007f828abd9108  vmovaps xmm2, [rsp+0x20]
00007f828abd910e  vmovaps xmm3, [rsp+0x30]
00007f828abd9114  vmovaps xmm4, [rsp+0x40]
00007f828abd911a  vmovaps xmm5, [rsp+0x50]
00007f828abd9120  vmovaps xmm6, [rsp+0x60]
00007f828abd9126  vmovaps xmm7, [rsp+0x70]
00007f828abd912c  vmovaps xmm8, [rsp+0x80]
00007f828abd9135  vmovaps xmm9, [rsp+0x90]
00007f828abd913e  vmovaps xmm10, [rsp+0xA0]
00007f828abd9147  vmovaps xmm11, [rsp+0xB0]
00007f828abd9150  vmovaps xmm12, [rsp+0xC0]
00007f828abd9159  vmovaps xmm13, [rsp+0xD0]
00007f828abd9162  vmovaps xmm14, [rsp+0xE0]
00007f828abd916b  add rsp, 0xF0
00007f828abd9172  pop r11
00007f828abd9174  pop r10
00007f828abd9176  pop r9
00007f828abd9178  pop r8
00007f828abd917a  pop rsi
00007f828abd917b  pop rdi
00007f828abd917c  pop rdx
00007f828abd917d  pop rcx
00007f828abd917e  pop rax
00007f828abd917f  add rsp, 0x08
00007f828abd9183  jmp 0x00007F828ABD61DC
00007f828abd9188  sub rsp, 0x08
00007f828abd918c  push rax
00007f828abd918d  push rcx
00007f828abd918e  push rdx
00007f828abd918f  push rdi
00007f828abd9190  push rsi
00007f828abd9191  push r8
00007f828abd9193  push r9
00007f828abd9195  push r10
00007f828abd9197  push r11
00007f828abd9199  sub rsp, 0xF0
00007f828abd91a0  vmovaps [rsp], xmm0
00007f828abd91a5  vmovaps [rsp+0x10], xmm1
00007f828abd91ab  vmovaps [rsp+0x20], xmm2
00007f828abd91b1  vmovaps [rsp+0x30], xmm3
00007f828abd91b7  vmovaps [rsp+0x40], xmm4
00007f828abd91bd  vmovaps [rsp+0x50], xmm6
00007f828abd91c3  vmovaps [rsp+0x60], xmm7
00007f828abd91c9  vmovaps [rsp+0x70], xmm8
00007f828abd91cf  vmovaps [rsp+0x80], xmm9
00007f828abd91d8  vmovaps [rsp+0x90], xmm10
00007f828abd91e1  vmovaps [rsp+0xA0], xmm11
00007f828abd91ea  vmovaps [rsp+0xB0], xmm12
00007f828abd91f3  vmovaps [rsp+0xC0], xmm13
00007f828abd91fc  vmovaps [rsp+0xD0], xmm14
00007f828abd9205  vmovaps [rsp+0xE0], xmm15
00007f828abd920e  sub rsp, 0x30
00007f828abd9212  movaps [rsp], xmm5
00007f828abd9216  movaps [rsp+0x10], xmm8
00007f828abd921c  movaps [rsp+0x20], xmm6
00007f828abd9221  lea rdi, [rsp]
00007f828abd9225  mov esi, 0x00
00007f828abd922a  mov rax, 0x5BFE27FA6530
00007f828abd9234  call rax
00007f828abd9236  movaps xmm5, [rsp]
00007f828abd923a  add rsp, 0x30
00007f828abd923e  vmovaps xmm0, [rsp]
00007f828abd9243  vmovaps xmm1, [rsp+0x10]
00007f828abd9249  vmovaps xmm2, [rsp+0x20]
00007f828abd924f  vmovaps xmm3, [rsp+0x30]
00007f828abd9255  vmovaps xmm4, [rsp+0x40]
00007f828abd925b  vmovaps xmm6, [rsp+0x50]
00007f828abd9261  vmovaps xmm7, [rsp+0x60]
00007f828abd9267  vmovaps xmm8, [rsp+0x70]
00007f828abd926d  vmovaps xmm9, [rsp+0x80]
00007f828abd9276  vmovaps xmm10, [rsp+0x90]
00007f828abd927f  vmovaps xmm11, [rsp+0xA0]
00007f828abd9288  vmovaps xmm12, [rsp+0xB0]
00007f828abd9291  vmovaps xmm13, [rsp+0xC0]
00007f828abd929a  vmovaps xmm14, [rsp+0xD0]
00007f828abd92a3  vmovaps xmm15, [rsp+0xE0]
00007f828abd92ac  add rsp, 0xF0
00007f828abd92b3  pop r11
00007f828abd92b5  pop r10
00007f828abd92b7  pop r9
00007f828abd92b9  pop r8
00007f828abd92bb  pop rsi
00007f828abd92bc  pop rdi
00007f828abd92bd  pop rdx
00007f828abd92be  pop rcx
00007f828abd92bf  pop rax
00007f828abd92c0  add rsp, 0x08
00007f828abd92c4  jmp 0x00007F828ABD6200
00007f828abd92c9  sub rsp, 0x08
00007f828abd92cd  push rax
00007f828abd92ce  push rcx
00007f828abd92cf  push rdx
00007f828abd92d0  push rdi
00007f828abd92d1  push rsi
00007f828abd92d2  push r8
00007f828abd92d4  push r9
00007f828abd92d6  push r10
00007f828abd92d8  push r11
00007f828abd92da  sub rsp, 0xF0
00007f828abd92e1  vmovaps [rsp], xmm0
00007f828abd92e6  vmovaps [rsp+0x10], xmm1
00007f828abd92ec  vmovaps [rsp+0x20], xmm2
00007f828abd92f2  vmovaps [rsp+0x30], xmm3
00007f828abd92f8  vmovaps [rsp+0x40], xmm4
00007f828abd92fe  vmovaps [rsp+0x50], xmm5
00007f828abd9304  vmovaps [rsp+0x60], xmm7
00007f828abd930a  vmovaps [rsp+0x70], xmm8
00007f828abd9310  vmovaps [rsp+0x80], xmm9
00007f828abd9319  vmovaps [rsp+0x90], xmm10
00007f828abd9322  vmovaps [rsp+0xA0], xmm11
00007f828abd932b  vmovaps [rsp+0xB0], xmm12
00007f828abd9334  vmovaps [rsp+0xC0], xmm13
00007f828abd933d  vmovaps [rsp+0xD0], xmm14
00007f828abd9346  vmovaps [rsp+0xE0], xmm15
00007f828abd934f  sub rsp, 0x30
00007f828abd9353  movaps [rsp], xmm6
00007f828abd9357  movaps [rsp+0x10], xmm10
00007f828abd935d  movaps [rsp+0x20], xmm8
00007f828abd9363  lea rdi, [rsp]
00007f828abd9367  mov esi, 0x00
00007f828abd936c  mov rax, 0x5BFE27FA6530
00007f828abd9376  call rax
00007f828abd9378  movaps xmm6, [rsp]
00007f828abd937c  add rsp, 0x30
00007f828abd9380  vmovaps xmm0, [rsp]
00007f828abd9385  vmovaps xmm1, [rsp+0x10]
00007f828abd938b  vmovaps xmm2, [rsp+0x20]
00007f828abd9391  vmovaps xmm3, [rsp+0x30]
00007f828abd9397  vmovaps xmm4, [rsp+0x40]
00007f828abd939d  vmovaps xmm5, [rsp+0x50]
00007f828abd93a3  vmovaps xmm7, [rsp+0x60]
00007f828abd93a9  vmovaps xmm8, [rsp+0x70]
00007f828abd93af  vmovaps xmm9, [rsp+0x80]
00007f828abd93b8  vmovaps xmm10, [rsp+0x90]
00007f828abd93c1  vmovaps xmm11, [rsp+0xA0]
00007f828abd93ca  vmovaps xmm12, [rsp+0xB0]
00007f828abd93d3  vmovaps xmm13, [rsp+0xC0]
00007f828abd93dc  vmovaps xmm14, [rsp+0xD0]
00007f828abd93e5  vmovaps xmm15, [rsp+0xE0]
00007f828abd93ee  add rsp, 0xF0
00007f828abd93f5  pop r11
00007f828abd93f7  pop r10
00007f828abd93f9  pop r9
00007f828abd93fb  pop r8
00007f828abd93fd  pop rsi
00007f828abd93fe  pop rdi
00007f828abd93ff  pop rdx
00007f828abd9400  pop rcx
00007f828abd9401  pop rax
00007f828abd9402  add rsp, 0x08
00007f828abd9406  jmp 0x00007F828ABD6225
00007f828abd940b  sub rsp, 0x08
00007f828abd940f  push rax
00007f828abd9410  push rcx
00007f828abd9411  push rdx
00007f828abd9412  push rdi
00007f828abd9413  push rsi
00007f828abd9414  push r8
00007f828abd9416  push r9
00007f828abd9418  push r10
00007f828abd941a  push r11
00007f828abd941c  sub rsp, 0xF0
00007f828abd9423  vmovaps [rsp], xmm0
00007f828abd9428  vmovaps [rsp+0x10], xmm1
00007f828abd942e  vmovaps [rsp+0x20], xmm2
00007f828abd9434  vmovaps [rsp+0x30], xmm3
00007f828abd943a  vmovaps [rsp+0x40], xmm4
00007f828abd9440  vmovaps [rsp+0x50], xmm5
00007f828abd9446  vmovaps [rsp+0x60], xmm6
00007f828abd944c  vmovaps [rsp+0x70], xmm7
00007f828abd9452  vmovaps [rsp+0x80], xmm8
00007f828abd945b  vmovaps [rsp+0x90], xmm9
00007f828abd9464  vmovaps [rsp+0xA0], xmm11
00007f828abd946d  vmovaps [rsp+0xB0], xmm12
00007f828abd9476  vmovaps [rsp+0xC0], xmm13
00007f828abd947f  vmovaps [rsp+0xD0], xmm14
00007f828abd9488  vmovaps [rsp+0xE0], xmm15
00007f828abd9491  sub rsp, 0x30
00007f828abd9495  movaps [rsp], xmm10
00007f828abd949a  movaps [rsp+0x10], xmm8
00007f828abd94a0  movaps [rsp+0x20], xmm14
00007f828abd94a6  lea rdi, [rsp]
00007f828abd94aa  mov esi, 0x00
00007f828abd94af  mov rax, 0x5BFE27FA6530
00007f828abd94b9  call rax
00007f828abd94bb  movaps xmm10, [rsp]
00007f828abd94c0  add rsp, 0x30
00007f828abd94c4  vmovaps xmm0, [rsp]
00007f828abd94c9  vmovaps xmm1, [rsp+0x10]
00007f828abd94cf  vmovaps xmm2, [rsp+0x20]
00007f828abd94d5  vmovaps xmm3, [rsp+0x30]
00007f828abd94db  vmovaps xmm4, [rsp+0x40]
00007f828abd94e1  vmovaps xmm5, [rsp+0x50]
00007f828abd94e7  vmovaps xmm6, [rsp+0x60]
00007f828abd94ed  vmovaps xmm7, [rsp+0x70]
00007f828abd94f3  vmovaps xmm8, [rsp+0x80]
00007f828abd94fc  vmovaps xmm9, [rsp+0x90]
00007f828abd9505  vmovaps xmm11, [rsp+0xA0]
00007f828abd950e  vmovaps xmm12, [rsp+0xB0]
00007f828abd9517  vmovaps xmm13, [rsp+0xC0]
00007f828abd9520  vmovaps xmm14, [rsp+0xD0]
00007f828abd9529  vmovaps xmm15, [rsp+0xE0]
00007f828abd9532  add rsp, 0xF0
00007f828abd9539  pop r11
00007f828abd953b  pop r10
00007f828abd953d  pop r9
00007f828abd953f  pop r8
00007f828abd9541  pop rsi
00007f828abd9542  pop rdi
00007f828abd9543  pop rdx
00007f828abd9544  pop rcx
00007f828abd9545  pop rax
00007f828abd9546  add rsp, 0x08
00007f828abd954a  jmp 0x00007F828ABD6245
00007f828abd954f  sub rsp, 0x08
00007f828abd9553  push rax
00007f828abd9554  push rcx
00007f828abd9555  push rdx
00007f828abd9556  push rdi
00007f828abd9557  push rsi
00007f828abd9558  push r8
00007f828abd955a  push r9
00007f828abd955c  push r10
00007f828abd955e  push r11
00007f828abd9560  sub rsp, 0xF0
00007f828abd9567  vmovaps [rsp], xmm0
00007f828abd956c  vmovaps [rsp+0x10], xmm1
00007f828abd9572  vmovaps [rsp+0x20], xmm2
00007f828abd9578  vmovaps [rsp+0x30], xmm3
00007f828abd957e  vmovaps [rsp+0x40], xmm4
00007f828abd9584  vmovaps [rsp+0x50], xmm5
00007f828abd958a  vmovaps [rsp+0x60], xmm6
00007f828abd9590  vmovaps [rsp+0x70], xmm7
00007f828abd9596  vmovaps [rsp+0x80], xmm8
00007f828abd959f  vmovaps [rsp+0x90], xmm9
00007f828abd95a8  vmovaps [rsp+0xA0], xmm10
00007f828abd95b1  vmovaps [rsp+0xB0], xmm11
00007f828abd95ba  vmovaps [rsp+0xC0], xmm12
00007f828abd95c3  vmovaps [rsp+0xD0], xmm13
00007f828abd95cc  vmovaps [rsp+0xE0], xmm15
00007f828abd95d5  sub rsp, 0x30
00007f828abd95d9  movaps [rsp], xmm14
00007f828abd95de  movaps [rsp+0x10], xmm8
00007f828abd95e4  movaps [rsp+0x20], xmm4
00007f828abd95e9  lea rdi, [rsp]
00007f828abd95ed  mov esi, 0x00
00007f828abd95f2  mov rax, 0x5BFE27FA6530
00007f828abd95fc  call rax
00007f828abd95fe  movaps xmm14, [rsp]
00007f828abd9603  add rsp, 0x30
00007f828abd9607  vmovaps xmm0, [rsp]
00007f828abd960c  vmovaps xmm1, [rsp+0x10]
00007f828abd9612  vmovaps xmm2, [rsp+0x20]
00007f828abd9618  vmovaps xmm3, [rsp+0x30]
00007f828abd961e  vmovaps xmm4, [rsp+0x40]
00007f828abd9624  vmovaps xmm5, [rsp+0x50]
00007f828abd962a  vmovaps xmm6, [rsp+0x60]
00007f828abd9630  vmovaps xmm7, [rsp+0x70]
00007f828abd9636  vmovaps xmm8, [rsp+0x80]
00007f828abd963f  vmovaps xmm9, [rsp+0x90]
00007f828abd9648  vmovaps xmm10, [rsp+0xA0]
00007f828abd9651  vmovaps xmm11, [rsp+0xB0]
00007f828abd965a  vmovaps xmm12, [rsp+0xC0]
00007f828abd9663  vmovaps xmm13, [rsp+0xD0]
00007f828abd966c  vmovaps xmm15, [rsp+0xE0]
00007f828abd9675  add rsp, 0xF0
00007f828abd967c  pop r11
00007f828abd967e  pop r10
00007f828abd9680  pop r9
00007f828abd9682  pop r8
00007f828abd9684  pop rsi
00007f828abd9685  pop rdi
00007f828abd9686  pop rdx
00007f828abd9687  pop rcx
00007f828abd9688  pop rax
00007f828abd9689  add rsp, 0x08
00007f828abd968d  jmp 0x00007F828ABD6265
00007f828abd9692  sub rsp, 0x08
00007f828abd9696  push rax
00007f828abd9697  push rcx
00007f828abd9698  push rdx
00007f828abd9699  push rdi
00007f828abd969a  push rsi
00007f828abd969b  push r8
00007f828abd969d  push r9
00007f828abd969f  push r10
00007f828abd96a1  push r11
00007f828abd96a3  sub rsp, 0xF0
00007f828abd96aa  vmovaps [rsp], xmm0
00007f828abd96af  vmovaps [rsp+0x10], xmm1
00007f828abd96b5  vmovaps [rsp+0x20], xmm2
00007f828abd96bb  vmovaps [rsp+0x30], xmm3
00007f828abd96c1  vmovaps [rsp+0x40], xmm5
00007f828abd96c7  vmovaps [rsp+0x50], xmm6
00007f828abd96cd  vmovaps [rsp+0x60], xmm7
00007f828abd96d3  vmovaps [rsp+0x70], xmm8
00007f828abd96d9  vmovaps [rsp+0x80], xmm9
00007f828abd96e2  vmovaps [rsp+0x90], xmm10
00007f828abd96eb  vmovaps [rsp+0xA0], xmm11
00007f828abd96f4  vmovaps [rsp+0xB0], xmm12
00007f828abd96fd  vmovaps [rsp+0xC0], xmm13
00007f828abd9706  vmovaps [rsp+0xD0], xmm14
00007f828abd970f  vmovaps [rsp+0xE0], xmm15
00007f828abd9718  sub rsp, 0x30
00007f828abd971c  movaps [rsp], xmm4
00007f828abd9720  movaps [rsp+0x10], xmm13
00007f828abd9726  movaps [rsp+0x20], xmm8
00007f828abd972c  lea rdi, [rsp]
00007f828abd9730  mov esi, 0x00
00007f828abd9735  mov rax, 0x5BFE27FA6530
00007f828abd973f  call rax
00007f828abd9741  movaps xmm4, [rsp]
00007f828abd9745  add rsp, 0x30
00007f828abd9749  vmovaps xmm0, [rsp]
00007f828abd974e  vmovaps xmm1, [rsp+0x10]
00007f828abd9754  vmovaps xmm2, [rsp+0x20]
00007f828abd975a  vmovaps xmm3, [rsp+0x30]
00007f828abd9760  vmovaps xmm5, [rsp+0x40]
00007f828abd9766  vmovaps xmm6, [rsp+0x50]
00007f828abd976c  vmovaps xmm7, [rsp+0x60]
00007f828abd9772  vmovaps xmm8, [rsp+0x70]
00007f828abd9778  vmovaps xmm9, [rsp+0x80]
00007f828abd9781  vmovaps xmm10, [rsp+0x90]
00007f828abd978a  vmovaps xmm11, [rsp+0xA0]
00007f828abd9793  vmovaps xmm12, [rsp+0xB0]
00007f828abd979c  vmovaps xmm13, [rsp+0xC0]
00007f828abd97a5  vmovaps xmm14, [rsp+0xD0]
00007f828abd97ae  vmovaps xmm15, [rsp+0xE0]
00007f828abd97b7  add rsp, 0xF0
00007f828abd97be  pop r11
00007f828abd97c0  pop r10
00007f828abd97c2  pop r9
00007f828abd97c4  pop r8
00007f828abd97c6  pop rsi
00007f828abd97c7  pop rdi
00007f828abd97c8  pop rdx
00007f828abd97c9  pop rcx
00007f828abd97ca  pop rax
00007f828abd97cb  add rsp, 0x08
00007f828abd97cf  jmp 0x00007F828ABD628A
00007f828abd97d4  sub rsp, 0x08
00007f828abd97d8  push rax
00007f828abd97d9  push rcx
00007f828abd97da  push rdx
00007f828abd97db  push rdi
00007f828abd97dc  push rsi
00007f828abd97dd  push r8
00007f828abd97df  push r9
00007f828abd97e1  push r10
00007f828abd97e3  push r11
00007f828abd97e5  sub rsp, 0xF0
00007f828abd97ec  vmovaps [rsp], xmm0
00007f828abd97f1  vmovaps [rsp+0x10], xmm1
00007f828abd97f7  vmovaps [rsp+0x20], xmm2
00007f828abd97fd  vmovaps [rsp+0x30], xmm3
00007f828abd9803  vmovaps [rsp+0x40], xmm4
00007f828abd9809  vmovaps [rsp+0x50], xmm5
00007f828abd980f  vmovaps [rsp+0x60], xmm6
00007f828abd9815  vmovaps [rsp+0x70], xmm7
00007f828abd981b  vmovaps [rsp+0x80], xmm8
00007f828abd9824  vmovaps [rsp+0x90], xmm9
00007f828abd982d  vmovaps [rsp+0xA0], xmm10
00007f828abd9836  vmovaps [rsp+0xB0], xmm11
00007f828abd983f  vmovaps [rsp+0xC0], xmm12
00007f828abd9848  vmovaps [rsp+0xD0], xmm14
00007f828abd9851  vmovaps [rsp+0xE0], xmm15
00007f828abd985a  sub rsp, 0x30
00007f828abd985e  movaps [rsp], xmm13
00007f828abd9863  movaps [rsp+0x10], xmm15
00007f828abd9869  movaps [rsp+0x20], xmm9
00007f828abd986f  lea rdi, [rsp]
00007f828abd9873  mov esi, 0x00
00007f828abd9878  mov rax, 0x5BFE27FA6530
00007f828abd9882  call rax
00007f828abd9884  movaps xmm13, [rsp]
00007f828abd9889  add rsp, 0x30
00007f828abd988d  vmovaps xmm0, [rsp]
00007f828abd9892  vmovaps xmm1, [rsp+0x10]
00007f828abd9898  vmovaps xmm2, [rsp+0x20]
00007f828abd989e  vmovaps xmm3, [rsp+0x30]
00007f828abd98a4  vmovaps xmm4, [rsp+0x40]
00007f828abd98aa  vmovaps xmm5, [rsp+0x50]
00007f828abd98b0  vmovaps xmm6, [rsp+0x60]
00007f828abd98b6  vmovaps xmm7, [rsp+0x70]
00007f828abd98bc  vmovaps xmm8, [rsp+0x80]
00007f828abd98c5  vmovaps xmm9, [rsp+0x90]
00007f828abd98ce  vmovaps xmm10, [rsp+0xA0]
00007f828abd98d7  vmovaps xmm11, [rsp+0xB0]
00007f828abd98e0  vmovaps xmm12, [rsp+0xC0]
00007f828abd98e9  vmovaps xmm14, [rsp+0xD0]
00007f828abd98f2  vmovaps xmm15, [rsp+0xE0]
00007f828abd98fb  add rsp, 0xF0
00007f828abd9902  pop r11
00007f828abd9904  pop r10
00007f828abd9906  pop r9
00007f828abd9908  pop r8
00007f828abd990a  pop rsi
00007f828abd990b  pop rdi
00007f828abd990c  pop rdx
00007f828abd990d  pop rcx
00007f828abd990e  pop rax
00007f828abd990f  add rsp, 0x08
00007f828abd9913  jmp 0x00007F828ABD62A5
00007f828abd9918  sub rsp, 0x08
00007f828abd991c  push rax
00007f828abd991d  push rcx
00007f828abd991e  push rdx
00007f828abd991f  push rdi
00007f828abd9920  push rsi
00007f828abd9921  push r8
00007f828abd9923  push r9
00007f828abd9925  push r10
00007f828abd9927  push r11
00007f828abd9929  sub rsp, 0xF0
00007f828abd9930  vmovaps [rsp], xmm0
00007f828abd9935  vmovaps [rsp+0x10], xmm1
00007f828abd993b  vmovaps [rsp+0x20], xmm2
00007f828abd9941  vmovaps [rsp+0x30], xmm3
00007f828abd9947  vmovaps [rsp+0x40], xmm4
00007f828abd994d  vmovaps [rsp+0x50], xmm5
00007f828abd9953  vmovaps [rsp+0x60], xmm6
00007f828abd9959  vmovaps [rsp+0x70], xmm7
00007f828abd995f  vmovaps [rsp+0x80], xmm8
00007f828abd9968  vmovaps [rsp+0x90], xmm9
00007f828abd9971  vmovaps [rsp+0xA0], xmm10
00007f828abd997a  vmovaps [rsp+0xB0], xmm11
00007f828abd9983  vmovaps [rsp+0xC0], xmm12
00007f828abd998c  vmovaps [rsp+0xD0], xmm13
00007f828abd9995  vmovaps [rsp+0xE0], xmm14
00007f828abd999e  sub rsp, 0x30
00007f828abd99a2  movaps [rsp], xmm15
00007f828abd99a7  movaps [rsp+0x10], xmm1
00007f828abd99ac  movaps [rsp+0x20], xmm5
00007f828abd99b1  lea rdi, [rsp]
00007f828abd99b5  mov esi, 0x00
00007f828abd99ba  mov rax, 0x5BFE27FA6530
00007f828abd99c4  call rax
00007f828abd99c6  movaps xmm15, [rsp]
00007f828abd99cb  add rsp, 0x30
00007f828abd99cf  vmovaps xmm0, [rsp]
00007f828abd99d4  vmovaps xmm1, [rsp+0x10]
00007f828abd99da  vmovaps xmm2, [rsp+0x20]
00007f828abd99e0  vmovaps xmm3, [rsp+0x30]
00007f828abd99e6  vmovaps xmm4, [rsp+0x40]
00007f828abd99ec  vmovaps xmm5, [rsp+0x50]
00007f828abd99f2  vmovaps xmm6, [rsp+0x60]
00007f828abd99f8  vmovaps xmm7, [rsp+0x70]
00007f828abd99fe  vmovaps xmm8, [rsp+0x80]
00007f828abd9a07  vmovaps xmm9, [rsp+0x90]
00007f828abd9a10  vmovaps xmm10, [rsp+0xA0]
00007f828abd9a19  vmovaps xmm11, [rsp+0xB0]
00007f828abd9a22  vmovaps xmm12, [rsp+0xC0]
00007f828abd9a2b  vmovaps xmm13, [rsp+0xD0]
00007f828abd9a34  vmovaps xmm14, [rsp+0xE0]
00007f828abd9a3d  add rsp, 0xF0
00007f828abd9a44  pop r11
00007f828abd9a46  pop r10
00007f828abd9a48  pop r9
00007f828abd9a4a  pop r8
00007f828abd9a4c  pop rsi
00007f828abd9a4d  pop rdi
00007f828abd9a4e  pop rdx
00007f828abd9a4f  pop rcx
00007f828abd9a50  pop rax
00007f828abd9a51  add rsp, 0x08
00007f828abd9a55  jmp 0x00007F828ABD62C0
00007f828abd9a5a  call 0x00007F828AAD64F0
00007f828abd9a5f  jmp 0x00007F828ABD631B
00007f828abd9a64  sub rsp, 0x08
00007f828abd9a68  push rax
00007f828abd9a69  push rcx
00007f828abd9a6a  push rdx
00007f828abd9a6b  push rdi
00007f828abd9a6c  push rsi
00007f828abd9a6d  push r8
00007f828abd9a6f  push r9
00007f828abd9a71  push r10
00007f828abd9a73  push r11
00007f828abd9a75  sub rsp, 0xF0
00007f828abd9a7c  vmovaps [rsp], xmm0
00007f828abd9a81  vmovaps [rsp+0x10], xmm1
00007f828abd9a87  vmovaps [rsp+0x20], xmm2
00007f828abd9a8d  vmovaps [rsp+0x30], xmm3
00007f828abd9a93  vmovaps [rsp+0x40], xmm4
00007f828abd9a99  vmovaps [rsp+0x50], xmm5
00007f828abd9a9f  vmovaps [rsp+0x60], xmm6
00007f828abd9aa5  vmovaps [rsp+0x70], xmm7
00007f828abd9aab  vmovaps [rsp+0x80], xmm8
00007f828abd9ab4  vmovaps [rsp+0x90], xmm10
00007f828abd9abd  vmovaps [rsp+0xA0], xmm11
00007f828abd9ac6  vmovaps [rsp+0xB0], xmm12
00007f828abd9acf  vmovaps [rsp+0xC0], xmm13
00007f828abd9ad8  vmovaps [rsp+0xD0], xmm14
00007f828abd9ae1  vmovaps [rsp+0xE0], xmm15
00007f828abd9aea  sub rsp, 0x30
00007f828abd9aee  movaps [rsp], xmm9
00007f828abd9af3  movaps [rsp+0x10], xmm8
00007f828abd9af9  movaps [rsp+0x20], xmm11
00007f828abd9aff  lea rdi, [rsp]
00007f828abd9b03  mov esi, 0x00
00007f828abd9b08  mov rax, 0x5BFE27FA6530
00007f828abd9b12  call rax
00007f828abd9b14  movaps xmm9, [rsp]
00007f828abd9b19  add rsp, 0x30
00007f828abd9b1d  vmovaps xmm0, [rsp]
00007f828abd9b22  vmovaps xmm1, [rsp+0x10]
00007f828abd9b28  vmovaps xmm2, [rsp+0x20]
00007f828abd9b2e  vmovaps xmm3, [rsp+0x30]
00007f828abd9b34  vmovaps xmm4, [rsp+0x40]
00007f828abd9b3a  vmovaps xmm5, [rsp+0x50]
00007f828abd9b40  vmovaps xmm6, [rsp+0x60]
00007f828abd9b46  vmovaps xmm7, [rsp+0x70]
00007f828abd9b4c  vmovaps xmm8, [rsp+0x80]
00007f828abd9b55  vmovaps xmm10, [rsp+0x90]
00007f828abd9b5e  vmovaps xmm11, [rsp+0xA0]
00007f828abd9b67  vmovaps xmm12, [rsp+0xB0]
00007f828abd9b70  vmovaps xmm13, [rsp+0xC0]
00007f828abd9b79  vmovaps xmm14, [rsp+0xD0]
00007f828abd9b82  vmovaps xmm15, [rsp+0xE0]
00007f828abd9b8b  add rsp, 0xF0
00007f828abd9b92  pop r11
00007f828abd9b94  pop r10
00007f828abd9b96  pop r9
00007f828abd9b98  pop r8
00007f828abd9b9a  pop rsi
00007f828abd9b9b  pop rdi
00007f828abd9b9c  pop rdx
00007f828abd9b9d  pop rcx
00007f828abd9b9e  pop rax
00007f828abd9b9f  add rsp, 0x08
00007f828abd9ba3  jmp 0x00007F828ABD6352
00007f828abd9ba8  sub rsp, 0x08
00007f828abd9bac  push rax
00007f828abd9bad  push rcx
00007f828abd9bae  push rdx
00007f828abd9baf  push rdi
00007f828abd9bb0  push rsi
00007f828abd9bb1  push r8
00007f828abd9bb3  push r9
00007f828abd9bb5  push r10
00007f828abd9bb7  push r11
00007f828abd9bb9  sub rsp, 0xF0
00007f828abd9bc0  vmovaps [rsp], xmm0
00007f828abd9bc5  vmovaps [rsp+0x10], xmm1
00007f828abd9bcb  vmovaps [rsp+0x20], xmm2
00007f828abd9bd1  vmovaps [rsp+0x30], xmm3
00007f828abd9bd7  vmovaps [rsp+0x40], xmm4
00007f828abd9bdd  vmovaps [rsp+0x50], xmm5
00007f828abd9be3  vmovaps [rsp+0x60], xmm6
00007f828abd9be9  vmovaps [rsp+0x70], xmm7
00007f828abd9bef  vmovaps [rsp+0x80], xmm8
00007f828abd9bf8  vmovaps [rsp+0x90], xmm9
00007f828abd9c01  vmovaps [rsp+0xA0], xmm10
00007f828abd9c0a  vmovaps [rsp+0xB0], xmm12
00007f828abd9c13  vmovaps [rsp+0xC0], xmm13
00007f828abd9c1c  vmovaps [rsp+0xD0], xmm14
00007f828abd9c25  vmovaps [rsp+0xE0], xmm15
00007f828abd9c2e  sub rsp, 0x30
00007f828abd9c32  movaps [rsp], xmm11
00007f828abd9c37  movaps [rsp+0x10], xmm10
00007f828abd9c3d  movaps [rsp+0x20], xmm6
00007f828abd9c42  lea rdi, [rsp]
00007f828abd9c46  mov esi, 0x00
00007f828abd9c4b  mov rax, 0x5BFE27FA6530
00007f828abd9c55  call rax
00007f828abd9c57  movaps xmm11, [rsp]
00007f828abd9c5c  add rsp, 0x30
00007f828abd9c60  vmovaps xmm0, [rsp]
00007f828abd9c65  vmovaps xmm1, [rsp+0x10]
00007f828abd9c6b  vmovaps xmm2, [rsp+0x20]
00007f828abd9c71  vmovaps xmm3, [rsp+0x30]
00007f828abd9c77  vmovaps xmm4, [rsp+0x40]
00007f828abd9c7d  vmovaps xmm5, [rsp+0x50]
00007f828abd9c83  vmovaps xmm6, [rsp+0x60]
00007f828abd9c89  vmovaps xmm7, [rsp+0x70]
00007f828abd9c8f  vmovaps xmm8, [rsp+0x80]
00007f828abd9c98  vmovaps xmm9, [rsp+0x90]
00007f828abd9ca1  vmovaps xmm10, [rsp+0xA0]
00007f828abd9caa  vmovaps xmm12, [rsp+0xB0]
00007f828abd9cb3  vmovaps xmm13, [rsp+0xC0]
00007f828abd9cbc  vmovaps xmm14, [rsp+0xD0]
00007f828abd9cc5  vmovaps xmm15, [rsp+0xE0]
00007f828abd9cce  add rsp, 0xF0
00007f828abd9cd5  pop r11
00007f828abd9cd7  pop r10
00007f828abd9cd9  pop r9
00007f828abd9cdb  pop r8
00007f828abd9cdd  pop rsi
00007f828abd9cde  pop rdi
00007f828abd9cdf  pop rdx
00007f828abd9ce0  pop rcx
00007f828abd9ce1  pop rax
00007f828abd9ce2  add rsp, 0x08
00007f828abd9ce6  jmp 0x00007F828ABD636D
00007f828abd9ceb  sub rsp, 0x08
00007f828abd9cef  push rax
00007f828abd9cf0  push rcx
00007f828abd9cf1  push rdx
00007f828abd9cf2  push rdi
00007f828abd9cf3  push rsi
00007f828abd9cf4  push r8
00007f828abd9cf6  push r9
00007f828abd9cf8  push r10
00007f828abd9cfa  push r11
00007f828abd9cfc  sub rsp, 0xF0
00007f828abd9d03  vmovaps [rsp], xmm0
00007f828abd9d08  vmovaps [rsp+0x10], xmm1
00007f828abd9d0e  vmovaps [rsp+0x20], xmm2
00007f828abd9d14  vmovaps [rsp+0x30], xmm3
00007f828abd9d1a  vmovaps [rsp+0x40], xmm4
00007f828abd9d20  vmovaps [rsp+0x50], xmm5
00007f828abd9d26  vmovaps [rsp+0x60], xmm6
00007f828abd9d2c  vmovaps [rsp+0x70], xmm7
00007f828abd9d32  vmovaps [rsp+0x80], xmm8
00007f828abd9d3b  vmovaps [rsp+0x90], xmm9
00007f828abd9d44  vmovaps [rsp+0xA0], xmm11
00007f828abd9d4d  vmovaps [rsp+0xB0], xmm12
00007f828abd9d56  vmovaps [rsp+0xC0], xmm13
00007f828abd9d5f  vmovaps [rsp+0xD0], xmm14
00007f828abd9d68  vmovaps [rsp+0xE0], xmm15
00007f828abd9d71  sub rsp, 0x30
00007f828abd9d75  movaps [rsp], xmm10
00007f828abd9d7a  movaps [rsp+0x10], xmm14
00007f828abd9d80  movaps [rsp+0x20], xmm4
00007f828abd9d85  lea rdi, [rsp]
00007f828abd9d89  mov esi, 0x00
00007f828abd9d8e  mov rax, 0x5BFE27FA6530
00007f828abd9d98  call rax
00007f828abd9d9a  movaps xmm10, [rsp]
00007f828abd9d9f  add rsp, 0x30
00007f828abd9da3  vmovaps xmm0, [rsp]
00007f828abd9da8  vmovaps xmm1, [rsp+0x10]
00007f828abd9dae  vmovaps xmm2, [rsp+0x20]
00007f828abd9db4  vmovaps xmm3, [rsp+0x30]
00007f828abd9dba  vmovaps xmm4, [rsp+0x40]
00007f828abd9dc0  vmovaps xmm5, [rsp+0x50]
00007f828abd9dc6  vmovaps xmm6, [rsp+0x60]
00007f828abd9dcc  vmovaps xmm7, [rsp+0x70]
00007f828abd9dd2  vmovaps xmm8, [rsp+0x80]
00007f828abd9ddb  vmovaps xmm9, [rsp+0x90]
00007f828abd9de4  vmovaps xmm11, [rsp+0xA0]
00007f828abd9ded  vmovaps xmm12, [rsp+0xB0]
00007f828abd9df6  vmovaps xmm13, [rsp+0xC0]
00007f828abd9dff  vmovaps xmm14, [rsp+0xD0]
00007f828abd9e08  vmovaps xmm15, [rsp+0xE0]
00007f828abd9e11  add rsp, 0xF0
00007f828abd9e18  pop r11
00007f828abd9e1a  pop r10
00007f828abd9e1c  pop r9
00007f828abd9e1e  pop r8
00007f828abd9e20  pop rsi
00007f828abd9e21  pop rdi
00007f828abd9e22  pop rdx
00007f828abd9e23  pop rcx
00007f828abd9e24  pop rax
00007f828abd9e25  add rsp, 0x08
00007f828abd9e29  jmp 0x00007F828ABD6388
00007f828abd9e2e  sub rsp, 0x08
00007f828abd9e32  push rax
00007f828abd9e33  push rcx
00007f828abd9e34  push rdx
00007f828abd9e35  push rdi
00007f828abd9e36  push rsi
00007f828abd9e37  push r8
00007f828abd9e39  push r9
00007f828abd9e3b  push r10
00007f828abd9e3d  push r11
00007f828abd9e3f  sub rsp, 0xF0
00007f828abd9e46  vmovaps [rsp], xmm0
00007f828abd9e4b  vmovaps [rsp+0x10], xmm1
00007f828abd9e51  vmovaps [rsp+0x20], xmm2
00007f828abd9e57  vmovaps [rsp+0x30], xmm3
00007f828abd9e5d  vmovaps [rsp+0x40], xmm4
00007f828abd9e63  vmovaps [rsp+0x50], xmm5
00007f828abd9e69  vmovaps [rsp+0x60], xmm6
00007f828abd9e6f  vmovaps [rsp+0x70], xmm7
00007f828abd9e75  vmovaps [rsp+0x80], xmm9
00007f828abd9e7e  vmovaps [rsp+0x90], xmm10
00007f828abd9e87  vmovaps [rsp+0xA0], xmm11
00007f828abd9e90  vmovaps [rsp+0xB0], xmm12
00007f828abd9e99  vmovaps [rsp+0xC0], xmm13
00007f828abd9ea2  vmovaps [rsp+0xD0], xmm14
00007f828abd9eab  vmovaps [rsp+0xE0], xmm15
00007f828abd9eb4  sub rsp, 0x30
00007f828abd9eb8  movaps [rsp], xmm8
00007f828abd9ebd  movaps [rsp+0x10], xmm1
00007f828abd9ec2  movaps [rsp+0x20], xmm14
00007f828abd9ec8  lea rdi, [rsp]
00007f828abd9ecc  mov esi, 0x00
00007f828abd9ed1  mov rax, 0x5BFE27FA6530
00007f828abd9edb  call rax
00007f828abd9edd  movaps xmm8, [rsp]
00007f828abd9ee2  add rsp, 0x30
00007f828abd9ee6  vmovaps xmm0, [rsp]
00007f828abd9eeb  vmovaps xmm1, [rsp+0x10]
00007f828abd9ef1  vmovaps xmm2, [rsp+0x20]
00007f828abd9ef7  vmovaps xmm3, [rsp+0x30]
00007f828abd9efd  vmovaps xmm4, [rsp+0x40]
00007f828abd9f03  vmovaps xmm5, [rsp+0x50]
00007f828abd9f09  vmovaps xmm6, [rsp+0x60]
00007f828abd9f0f  vmovaps xmm7, [rsp+0x70]
00007f828abd9f15  vmovaps xmm9, [rsp+0x80]
00007f828abd9f1e  vmovaps xmm10, [rsp+0x90]
00007f828abd9f27  vmovaps xmm11, [rsp+0xA0]
00007f828abd9f30  vmovaps xmm12, [rsp+0xB0]
00007f828abd9f39  vmovaps xmm13, [rsp+0xC0]
00007f828abd9f42  vmovaps xmm14, [rsp+0xD0]
00007f828abd9f4b  vmovaps xmm15, [rsp+0xE0]
00007f828abd9f54  add rsp, 0xF0
00007f828abd9f5b  pop r11
00007f828abd9f5d  pop r10
00007f828abd9f5f  pop r9
00007f828abd9f61  pop r8
00007f828abd9f63  pop rsi
00007f828abd9f64  pop rdi
00007f828abd9f65  pop rdx
00007f828abd9f66  pop rcx
00007f828abd9f67  pop rax
00007f828abd9f68  add rsp, 0x08
00007f828abd9f6c  jmp 0x00007F828ABD63AE
00007f828abd9f71  sub rsp, 0x08
00007f828abd9f75  push rax
00007f828abd9f76  push rcx
00007f828abd9f77  push rdx
00007f828abd9f78  push rdi
00007f828abd9f79  push rsi
00007f828abd9f7a  push r8
00007f828abd9f7c  push r9
00007f828abd9f7e  push r10
00007f828abd9f80  push r11
00007f828abd9f82  sub rsp, 0xF0
00007f828abd9f89  vmovaps [rsp], xmm0
00007f828abd9f8e  vmovaps [rsp+0x10], xmm1
00007f828abd9f94  vmovaps [rsp+0x20], xmm2
00007f828abd9f9a  vmovaps [rsp+0x30], xmm3
00007f828abd9fa0  vmovaps [rsp+0x40], xmm4
00007f828abd9fa6  vmovaps [rsp+0x50], xmm5
00007f828abd9fac  vmovaps [rsp+0x60], xmm7
00007f828abd9fb2  vmovaps [rsp+0x70], xmm8
00007f828abd9fb8  vmovaps [rsp+0x80], xmm9
00007f828abd9fc1  vmovaps [rsp+0x90], xmm10
00007f828abd9fca  vmovaps [rsp+0xA0], xmm11
00007f828abd9fd3  vmovaps [rsp+0xB0], xmm12
00007f828abd9fdc  vmovaps [rsp+0xC0], xmm13
00007f828abd9fe5  vmovaps [rsp+0xD0], xmm14
00007f828abd9fee  vmovaps [rsp+0xE0], xmm15
00007f828abd9ff7  sub rsp, 0x30
00007f828abd9ffb  movaps [rsp], xmm6
00007f828abd9fff  movaps [rsp+0x10], xmm1
00007f828abda004  movaps [rsp+0x20], xmm14
00007f828abda00a  lea rdi, [rsp]
00007f828abda00e  mov esi, 0x00
00007f828abda013  mov rax, 0x5BFE27FA6530
00007f828abda01d  call rax
00007f828abda01f  movaps xmm6, [rsp]
00007f828abda023  add rsp, 0x30
00007f828abda027  vmovaps xmm0, [rsp]
00007f828abda02c  vmovaps xmm1, [rsp+0x10]
00007f828abda032  vmovaps xmm2, [rsp+0x20]
00007f828abda038  vmovaps xmm3, [rsp+0x30]
00007f828abda03e  vmovaps xmm4, [rsp+0x40]
00007f828abda044  vmovaps xmm5, [rsp+0x50]
00007f828abda04a  vmovaps xmm7, [rsp+0x60]
00007f828abda050  vmovaps xmm8, [rsp+0x70]
00007f828abda056  vmovaps xmm9, [rsp+0x80]
00007f828abda05f  vmovaps xmm10, [rsp+0x90]
00007f828abda068  vmovaps xmm11, [rsp+0xA0]
00007f828abda071  vmovaps xmm12, [rsp+0xB0]
00007f828abda07a  vmovaps xmm13, [rsp+0xC0]
00007f828abda083  vmovaps xmm14, [rsp+0xD0]
00007f828abda08c  vmovaps xmm15, [rsp+0xE0]
00007f828abda095  add rsp, 0xF0
00007f828abda09c  pop r11
00007f828abda09e  pop r10
00007f828abda0a0  pop r9
00007f828abda0a2  pop r8
00007f828abda0a4  pop rsi
00007f828abda0a5  pop rdi
00007f828abda0a6  pop rdx
00007f828abda0a7  pop rcx
00007f828abda0a8  pop rax
00007f828abda0a9  add rsp, 0x08
00007f828abda0ad  jmp 0x00007F828ABD63DA
00007f828abda0b2  sub rsp, 0x08
00007f828abda0b6  push rax
00007f828abda0b7  push rcx
00007f828abda0b8  push rdx
00007f828abda0b9  push rdi
00007f828abda0ba  push rsi
00007f828abda0bb  push r8
00007f828abda0bd  push r9
00007f828abda0bf  push r10
00007f828abda0c1  push r11
00007f828abda0c3  sub rsp, 0xF0
00007f828abda0ca  vmovaps [rsp], xmm0
00007f828abda0cf  vmovaps [rsp+0x10], xmm1
00007f828abda0d5  vmovaps [rsp+0x20], xmm2
00007f828abda0db  vmovaps [rsp+0x30], xmm3
00007f828abda0e1  vmovaps [rsp+0x40], xmm4
00007f828abda0e7  vmovaps [rsp+0x50], xmm5
00007f828abda0ed  vmovaps [rsp+0x60], xmm6
00007f828abda0f3  vmovaps [rsp+0x70], xmm7
00007f828abda0f9  vmovaps [rsp+0x80], xmm8
00007f828abda102  vmovaps [rsp+0x90], xmm9
00007f828abda10b  vmovaps [rsp+0xA0], xmm10
00007f828abda114  vmovaps [rsp+0xB0], xmm11
00007f828abda11d  vmovaps [rsp+0xC0], xmm12
00007f828abda126  vmovaps [rsp+0xD0], xmm13
00007f828abda12f  vmovaps [rsp+0xE0], xmm15
00007f828abda138  sub rsp, 0x30
00007f828abda13c  movaps [rsp], xmm14
00007f828abda141  movaps [rsp+0x10], xmm12
00007f828abda147  movaps [rsp+0x20], xmm1
00007f828abda14c  lea rdi, [rsp]
00007f828abda150  mov esi, 0x00
00007f828abda155  mov rax, 0x5BFE27FA6530
00007f828abda15f  call rax
00007f828abda161  movaps xmm14, [rsp]
00007f828abda166  add rsp, 0x30
00007f828abda16a  vmovaps xmm0, [rsp]
00007f828abda16f  vmovaps xmm1, [rsp+0x10]
00007f828abda175  vmovaps xmm2, [rsp+0x20]
00007f828abda17b  vmovaps xmm3, [rsp+0x30]
00007f828abda181  vmovaps xmm4, [rsp+0x40]
00007f828abda187  vmovaps xmm5, [rsp+0x50]
00007f828abda18d  vmovaps xmm6, [rsp+0x60]
00007f828abda193  vmovaps xmm7, [rsp+0x70]
00007f828abda199  vmovaps xmm8, [rsp+0x80]
00007f828abda1a2  vmovaps xmm9, [rsp+0x90]
00007f828abda1ab  vmovaps xmm10, [rsp+0xA0]
00007f828abda1b4  vmovaps xmm11, [rsp+0xB0]
00007f828abda1bd  vmovaps xmm12, [rsp+0xC0]
00007f828abda1c6  vmovaps xmm13, [rsp+0xD0]
00007f828abda1cf  vmovaps xmm15, [rsp+0xE0]
00007f828abda1d8  add rsp, 0xF0
00007f828abda1df  pop r11
00007f828abda1e1  pop r10
00007f828abda1e3  pop r9
00007f828abda1e5  pop r8
00007f828abda1e7  pop rsi
00007f828abda1e8  pop rdi
00007f828abda1e9  pop rdx
00007f828abda1ea  pop rcx
00007f828abda1eb  pop rax
00007f828abda1ec  add rsp, 0x08
00007f828abda1f0  jmp 0x00007F828ABD6400
00007f828abda1f5  sub rsp, 0x08
00007f828abda1f9  push rax
00007f828abda1fa  push rcx
00007f828abda1fb  push rdx
00007f828abda1fc  push rdi
00007f828abda1fd  push rsi
00007f828abda1fe  push r8
00007f828abda200  push r9
00007f828abda202  push r10
00007f828abda204  push r11
00007f828abda206  sub rsp, 0xF0
00007f828abda20d  vmovaps [rsp], xmm0
00007f828abda212  vmovaps [rsp+0x10], xmm2
00007f828abda218  vmovaps [rsp+0x20], xmm3
00007f828abda21e  vmovaps [rsp+0x30], xmm4
00007f828abda224  vmovaps [rsp+0x40], xmm5
00007f828abda22a  vmovaps [rsp+0x50], xmm6
00007f828abda230  vmovaps [rsp+0x60], xmm7
00007f828abda236  vmovaps [rsp+0x70], xmm8
00007f828abda23c  vmovaps [rsp+0x80], xmm9
00007f828abda245  vmovaps [rsp+0x90], xmm10
00007f828abda24e  vmovaps [rsp+0xA0], xmm11
00007f828abda257  vmovaps [rsp+0xB0], xmm12
00007f828abda260  vmovaps [rsp+0xC0], xmm13
00007f828abda269  vmovaps [rsp+0xD0], xmm14
00007f828abda272  vmovaps [rsp+0xE0], xmm15
00007f828abda27b  sub rsp, 0x30
00007f828abda27f  movaps [rsp], xmm1
00007f828abda283  movaps [rsp+0x10], xmm13
00007f828abda289  movaps [rsp+0x20], xmm9
00007f828abda28f  lea rdi, [rsp]
00007f828abda293  mov esi, 0x00
00007f828abda298  mov rax, 0x5BFE27FA6530
00007f828abda2a2  call rax
00007f828abda2a4  movaps xmm1, [rsp]
00007f828abda2a8  add rsp, 0x30
00007f828abda2ac  vmovaps xmm0, [rsp]
00007f828abda2b1  vmovaps xmm2, [rsp+0x10]
00007f828abda2b7  vmovaps xmm3, [rsp+0x20]
00007f828abda2bd  vmovaps xmm4, [rsp+0x30]
00007f828abda2c3  vmovaps xmm5, [rsp+0x40]
00007f828abda2c9  vmovaps xmm6, [rsp+0x50]
00007f828abda2cf  vmovaps xmm7, [rsp+0x60]
00007f828abda2d5  vmovaps xmm8, [rsp+0x70]
00007f828abda2db  vmovaps xmm9, [rsp+0x80]
00007f828abda2e4  vmovaps xmm10, [rsp+0x90]
00007f828abda2ed  vmovaps xmm11, [rsp+0xA0]
00007f828abda2f6  vmovaps xmm12, [rsp+0xB0]
00007f828abda2ff  vmovaps xmm13, [rsp+0xC0]
00007f828abda308  vmovaps xmm14, [rsp+0xD0]
00007f828abda311  vmovaps xmm15, [rsp+0xE0]
00007f828abda31a  add rsp, 0xF0
00007f828abda321  pop r11
00007f828abda323  pop r10
00007f828abda325  pop r9
00007f828abda327  pop r8
00007f828abda329  pop rsi
00007f828abda32a  pop rdi
00007f828abda32b  pop rdx
00007f828abda32c  pop rcx
00007f828abda32d  pop rax
00007f828abda32e  add rsp, 0x08
00007f828abda332  jmp 0x00007F828ABD641A
00007f828abda337  sub rsp, 0x08
00007f828abda33b  push rax
00007f828abda33c  push rcx
00007f828abda33d  push rdx
00007f828abda33e  push rdi
00007f828abda33f  push rsi
00007f828abda340  push r8
00007f828abda342  push r9
00007f828abda344  push r10
00007f828abda346  push r11
00007f828abda348  sub rsp, 0xF0
00007f828abda34f  vmovaps [rsp], xmm0
00007f828abda354  vmovaps [rsp+0x10], xmm1
00007f828abda35a  vmovaps [rsp+0x20], xmm2
00007f828abda360  vmovaps [rsp+0x30], xmm3
00007f828abda366  vmovaps [rsp+0x40], xmm4
00007f828abda36c  vmovaps [rsp+0x50], xmm5
00007f828abda372  vmovaps [rsp+0x60], xmm6
00007f828abda378  vmovaps [rsp+0x70], xmm7
00007f828abda37e  vmovaps [rsp+0x80], xmm8
00007f828abda387  vmovaps [rsp+0x90], xmm9
00007f828abda390  vmovaps [rsp+0xA0], xmm10
00007f828abda399  vmovaps [rsp+0xB0], xmm11
00007f828abda3a2  vmovaps [rsp+0xC0], xmm13
00007f828abda3ab  vmovaps [rsp+0xD0], xmm14
00007f828abda3b4  vmovaps [rsp+0xE0], xmm15
00007f828abda3bd  sub rsp, 0x30
00007f828abda3c1  movaps [rsp], xmm12
00007f828abda3c6  movaps [rsp+0x10], xmm7
00007f828abda3cb  movaps [rsp+0x20], xmm13
00007f828abda3d1  lea rdi, [rsp]
00007f828abda3d5  mov esi, 0x00
00007f828abda3da  mov rax, 0x5BFE27FA6530
00007f828abda3e4  call rax
00007f828abda3e6  movaps xmm12, [rsp]
00007f828abda3eb  add rsp, 0x30
00007f828abda3ef  vmovaps xmm0, [rsp]
00007f828abda3f4  vmovaps xmm1, [rsp+0x10]
00007f828abda3fa  vmovaps xmm2, [rsp+0x20]
00007f828abda400  vmovaps xmm3, [rsp+0x30]
00007f828abda406  vmovaps xmm4, [rsp+0x40]
00007f828abda40c  vmovaps xmm5, [rsp+0x50]
00007f828abda412  vmovaps xmm6, [rsp+0x60]
00007f828abda418  vmovaps xmm7, [rsp+0x70]
00007f828abda41e  vmovaps xmm8, [rsp+0x80]
00007f828abda427  vmovaps xmm9, [rsp+0x90]
00007f828abda430  vmovaps xmm10, [rsp+0xA0]
00007f828abda439  vmovaps xmm11, [rsp+0xB0]
00007f828abda442  vmovaps xmm13, [rsp+0xC0]
00007f828abda44b  vmovaps xmm14, [rsp+0xD0]
00007f828abda454  vmovaps xmm15, [rsp+0xE0]
00007f828abda45d  add rsp, 0xF0
00007f828abda464  pop r11
00007f828abda466  pop r10
00007f828abda468  pop r9
00007f828abda46a  pop r8
00007f828abda46c  pop rsi
00007f828abda46d  pop rdi
00007f828abda46e  pop rdx
00007f828abda46f  pop rcx
00007f828abda470  pop rax
00007f828abda471  add rsp, 0x08
00007f828abda475  jmp 0x00007F828ABD6441
00007f828abda47a  sub rsp, 0x08
00007f828abda47e  push rax
00007f828abda47f  push rcx
00007f828abda480  push rdx
00007f828abda481  push rdi
00007f828abda482  push rsi
00007f828abda483  push r8
00007f828abda485  push r9
00007f828abda487  push r10
00007f828abda489  push r11
00007f828abda48b  sub rsp, 0xF0
00007f828abda492  vmovaps [rsp], xmm0
00007f828abda497  vmovaps [rsp+0x10], xmm1
00007f828abda49d  vmovaps [rsp+0x20], xmm2
00007f828abda4a3  vmovaps [rsp+0x30], xmm3
00007f828abda4a9  vmovaps [rsp+0x40], xmm4
00007f828abda4af  vmovaps [rsp+0x50], xmm5
00007f828abda4b5  vmovaps [rsp+0x60], xmm6
00007f828abda4bb  vmovaps [rsp+0x70], xmm7
00007f828abda4c1  vmovaps [rsp+0x80], xmm8
00007f828abda4ca  vmovaps [rsp+0x90], xmm9
00007f828abda4d3  vmovaps [rsp+0xA0], xmm10
00007f828abda4dc  vmovaps [rsp+0xB0], xmm11
00007f828abda4e5  vmovaps [rsp+0xC0], xmm12
00007f828abda4ee  vmovaps [rsp+0xD0], xmm14
00007f828abda4f7  vmovaps [rsp+0xE0], xmm15
00007f828abda500  sub rsp, 0x30
00007f828abda504  movaps [rsp], xmm13
00007f828abda509  movaps [rsp+0x10], xmm15
00007f828abda50f  movaps [rsp+0x20], xmm8
00007f828abda515  lea rdi, [rsp]
00007f828abda519  mov esi, 0x00
00007f828abda51e  mov rax, 0x5BFE27FA6530
00007f828abda528  call rax
00007f828abda52a  movaps xmm13, [rsp]
00007f828abda52f  add rsp, 0x30
00007f828abda533  vmovaps xmm0, [rsp]
00007f828abda538  vmovaps xmm1, [rsp+0x10]
00007f828abda53e  vmovaps xmm2, [rsp+0x20]
00007f828abda544  vmovaps xmm3, [rsp+0x30]
00007f828abda54a  vmovaps xmm4, [rsp+0x40]
00007f828abda550  vmovaps xmm5, [rsp+0x50]
00007f828abda556  vmovaps xmm6, [rsp+0x60]
00007f828abda55c  vmovaps xmm7, [rsp+0x70]
00007f828abda562  vmovaps xmm8, [rsp+0x80]
00007f828abda56b  vmovaps xmm9, [rsp+0x90]
00007f828abda574  vmovaps xmm10, [rsp+0xA0]
00007f828abda57d  vmovaps xmm11, [rsp+0xB0]
00007f828abda586  vmovaps xmm12, [rsp+0xC0]
00007f828abda58f  vmovaps xmm14, [rsp+0xD0]
00007f828abda598  vmovaps xmm15, [rsp+0xE0]
00007f828abda5a1  add rsp, 0xF0
00007f828abda5a8  pop r11
00007f828abda5aa  pop r10
00007f828abda5ac  pop r9
00007f828abda5ae  pop r8
00007f828abda5b0  pop rsi
00007f828abda5b1  pop rdi
00007f828abda5b2  pop rdx
00007f828abda5b3  pop rcx
00007f828abda5b4  pop rax
00007f828abda5b5  add rsp, 0x08
00007f828abda5b9  jmp 0x00007F828ABD645C
00007f828abda5be  sub rsp, 0x08
00007f828abda5c2  push rax
00007f828abda5c3  push rcx
00007f828abda5c4  push rdx
00007f828abda5c5  push rdi
00007f828abda5c6  push rsi
00007f828abda5c7  push r8
00007f828abda5c9  push r9
00007f828abda5cb  push r10
00007f828abda5cd  push r11
00007f828abda5cf  sub rsp, 0xF0
00007f828abda5d6  vmovaps [rsp], xmm0
00007f828abda5db  vmovaps [rsp+0x10], xmm1
00007f828abda5e1  vmovaps [rsp+0x20], xmm2
00007f828abda5e7  vmovaps [rsp+0x30], xmm3
00007f828abda5ed  vmovaps [rsp+0x40], xmm4
00007f828abda5f3  vmovaps [rsp+0x50], xmm5
00007f828abda5f9  vmovaps [rsp+0x60], xmm6
00007f828abda5ff  vmovaps [rsp+0x70], xmm7
00007f828abda605  vmovaps [rsp+0x80], xmm9
00007f828abda60e  vmovaps [rsp+0x90], xmm10
00007f828abda617  vmovaps [rsp+0xA0], xmm11
00007f828abda620  vmovaps [rsp+0xB0], xmm12
00007f828abda629  vmovaps [rsp+0xC0], xmm13
00007f828abda632  vmovaps [rsp+0xD0], xmm14
00007f828abda63b  vmovaps [rsp+0xE0], xmm15
00007f828abda644  sub rsp, 0x30
00007f828abda648  movaps [rsp], xmm8
00007f828abda64d  movaps [rsp+0x10], xmm15
00007f828abda653  movaps [rsp+0x20], xmm9
00007f828abda659  lea rdi, [rsp]
00007f828abda65d  mov esi, 0x00
00007f828abda662  mov rax, 0x5BFE27FA6530
00007f828abda66c  call rax
00007f828abda66e  movaps xmm8, [rsp]
00007f828abda673  add rsp, 0x30
00007f828abda677  vmovaps xmm0, [rsp]
00007f828abda67c  vmovaps xmm1, [rsp+0x10]
00007f828abda682  vmovaps xmm2, [rsp+0x20]
00007f828abda688  vmovaps xmm3, [rsp+0x30]
00007f828abda68e  vmovaps xmm4, [rsp+0x40]
00007f828abda694  vmovaps xmm5, [rsp+0x50]
00007f828abda69a  vmovaps xmm6, [rsp+0x60]
00007f828abda6a0  vmovaps xmm7, [rsp+0x70]
00007f828abda6a6  vmovaps xmm9, [rsp+0x80]
00007f828abda6af  vmovaps xmm10, [rsp+0x90]
00007f828abda6b8  vmovaps xmm11, [rsp+0xA0]
00007f828abda6c1  vmovaps xmm12, [rsp+0xB0]
00007f828abda6ca  vmovaps xmm13, [rsp+0xC0]
00007f828abda6d3  vmovaps xmm14, [rsp+0xD0]
00007f828abda6dc  vmovaps xmm15, [rsp+0xE0]
00007f828abda6e5  add rsp, 0xF0
00007f828abda6ec  pop r11
00007f828abda6ee  pop r10
00007f828abda6f0  pop r9
00007f828abda6f2  pop r8
00007f828abda6f4  pop rsi
00007f828abda6f5  pop rdi
00007f828abda6f6  pop rdx
00007f828abda6f7  pop rcx
00007f828abda6f8  pop rax
00007f828abda6f9  add rsp, 0x08
00007f828abda6fd  jmp 0x00007F828ABD648A
00007f828abda702  sub rsp, 0x08
00007f828abda706  push rax
00007f828abda707  push rcx
00007f828abda708  push rdx
00007f828abda709  push rdi
00007f828abda70a  push rsi
00007f828abda70b  push r8
00007f828abda70d  push r9
00007f828abda70f  push r10
00007f828abda711  push r11
00007f828abda713  sub rsp, 0xF0
00007f828abda71a  vmovaps [rsp], xmm0
00007f828abda71f  vmovaps [rsp+0x10], xmm1
00007f828abda725  vmovaps [rsp+0x20], xmm2
00007f828abda72b  vmovaps [rsp+0x30], xmm3
00007f828abda731  vmovaps [rsp+0x40], xmm4
00007f828abda737  vmovaps [rsp+0x50], xmm5
00007f828abda73d  vmovaps [rsp+0x60], xmm6
00007f828abda743  vmovaps [rsp+0x70], xmm7
00007f828abda749  vmovaps [rsp+0x80], xmm8
00007f828abda752  vmovaps [rsp+0x90], xmm9
00007f828abda75b  vmovaps [rsp+0xA0], xmm10
00007f828abda764  vmovaps [rsp+0xB0], xmm11
00007f828abda76d  vmovaps [rsp+0xC0], xmm12
00007f828abda776  vmovaps [rsp+0xD0], xmm13
00007f828abda77f  vmovaps [rsp+0xE0], xmm14
00007f828abda788  sub rsp, 0x30
00007f828abda78c  movaps [rsp], xmm15
00007f828abda791  movaps [rsp+0x10], xmm11
00007f828abda797  movaps [rsp+0x20], xmm6
00007f828abda79c  lea rdi, [rsp]
00007f828abda7a0  mov esi, 0x00
00007f828abda7a5  mov rax, 0x5BFE27FA6530
00007f828abda7af  call rax
00007f828abda7b1  movaps xmm15, [rsp]
00007f828abda7b6  add rsp, 0x30
00007f828abda7ba  vmovaps xmm0, [rsp]
00007f828abda7bf  vmovaps xmm1, [rsp+0x10]
00007f828abda7c5  vmovaps xmm2, [rsp+0x20]
00007f828abda7cb  vmovaps xmm3, [rsp+0x30]
00007f828abda7d1  vmovaps xmm4, [rsp+0x40]
00007f828abda7d7  vmovaps xmm5, [rsp+0x50]
00007f828abda7dd  vmovaps xmm6, [rsp+0x60]
00007f828abda7e3  vmovaps xmm7, [rsp+0x70]
00007f828abda7e9  vmovaps xmm8, [rsp+0x80]
00007f828abda7f2  vmovaps xmm9, [rsp+0x90]
00007f828abda7fb  vmovaps xmm10, [rsp+0xA0]
00007f828abda804  vmovaps xmm11, [rsp+0xB0]
00007f828abda80d  vmovaps xmm12, [rsp+0xC0]
00007f828abda816  vmovaps xmm13, [rsp+0xD0]
00007f828abda81f  vmovaps xmm14, [rsp+0xE0]
00007f828abda828  add rsp, 0xF0
00007f828abda82f  pop r11
00007f828abda831  pop r10
00007f828abda833  pop r9
00007f828abda835  pop r8
00007f828abda837  pop rsi
00007f828abda838  pop rdi
00007f828abda839  pop rdx
00007f828abda83a  pop rcx
00007f828abda83b  pop rax
00007f828abda83c  add rsp, 0x08
00007f828abda840  jmp 0x00007F828ABD64A5
00007f828abda845  sub rsp, 0x08
00007f828abda849  push rax
00007f828abda84a  push rcx
00007f828abda84b  push rdx
00007f828abda84c  push rdi
00007f828abda84d  push rsi
00007f828abda84e  push r8
00007f828abda850  push r9
00007f828abda852  push r10
00007f828abda854  push r11
00007f828abda856  sub rsp, 0xF0
00007f828abda85d  vmovaps [rsp], xmm0
00007f828abda862  vmovaps [rsp+0x10], xmm1
00007f828abda868  vmovaps [rsp+0x20], xmm2
00007f828abda86e  vmovaps [rsp+0x30], xmm3
00007f828abda874  vmovaps [rsp+0x40], xmm4
00007f828abda87a  vmovaps [rsp+0x50], xmm5
00007f828abda880  vmovaps [rsp+0x60], xmm6
00007f828abda886  vmovaps [rsp+0x70], xmm8
00007f828abda88c  vmovaps [rsp+0x80], xmm9
00007f828abda895  vmovaps [rsp+0x90], xmm10
00007f828abda89e  vmovaps [rsp+0xA0], xmm11
00007f828abda8a7  vmovaps [rsp+0xB0], xmm12
00007f828abda8b0  vmovaps [rsp+0xC0], xmm13
00007f828abda8b9  vmovaps [rsp+0xD0], xmm14
00007f828abda8c2  vmovaps [rsp+0xE0], xmm15
00007f828abda8cb  sub rsp, 0x30
00007f828abda8cf  movaps [rsp], xmm7
00007f828abda8d3  movaps [rsp+0x10], xmm11
00007f828abda8d9  movaps [rsp+0x20], xmm9
00007f828abda8df  lea rdi, [rsp]
00007f828abda8e3  mov esi, 0x00
00007f828abda8e8  mov rax, 0x5BFE27FA6530
00007f828abda8f2  call rax
00007f828abda8f4  movaps xmm7, [rsp]
00007f828abda8f8  add rsp, 0x30
00007f828abda8fc  vmovaps xmm0, [rsp]
00007f828abda901  vmovaps xmm1, [rsp+0x10]
00007f828abda907  vmovaps xmm2, [rsp+0x20]
00007f828abda90d  vmovaps xmm3, [rsp+0x30]
00007f828abda913  vmovaps xmm4, [rsp+0x40]
00007f828abda919  vmovaps xmm5, [rsp+0x50]
00007f828abda91f  vmovaps xmm6, [rsp+0x60]
00007f828abda925  vmovaps xmm8, [rsp+0x70]
00007f828abda92b  vmovaps xmm9, [rsp+0x80]
00007f828abda934  vmovaps xmm10, [rsp+0x90]
00007f828abda93d  vmovaps xmm11, [rsp+0xA0]
00007f828abda946  vmovaps xmm12, [rsp+0xB0]
00007f828abda94f  vmovaps xmm13, [rsp+0xC0]
00007f828abda958  vmovaps xmm14, [rsp+0xD0]
00007f828abda961  vmovaps xmm15, [rsp+0xE0]
00007f828abda96a  add rsp, 0xF0
00007f828abda971  pop r11
00007f828abda973  pop r10
00007f828abda975  pop r9
00007f828abda977  pop r8
00007f828abda979  pop rsi
00007f828abda97a  pop rdi
00007f828abda97b  pop rdx
00007f828abda97c  pop rcx
00007f828abda97d  pop rax
00007f828abda97e  add rsp, 0x08
00007f828abda982  jmp 0x00007F828ABD64D2
00007f828abda987  sub rsp, 0x08
00007f828abda98b  push rax
00007f828abda98c  push rcx
00007f828abda98d  push rdx
00007f828abda98e  push rdi
00007f828abda98f  push rsi
00007f828abda990  push r8
00007f828abda992  push r9
00007f828abda994  push r10
00007f828abda996  push r11
00007f828abda998  sub rsp, 0xF0
00007f828abda99f  vmovaps [rsp], xmm0
00007f828abda9a4  vmovaps [rsp+0x10], xmm1
00007f828abda9aa  vmovaps [rsp+0x20], xmm2
00007f828abda9b0  vmovaps [rsp+0x30], xmm3
00007f828abda9b6  vmovaps [rsp+0x40], xmm4
00007f828abda9bc  vmovaps [rsp+0x50], xmm5
00007f828abda9c2  vmovaps [rsp+0x60], xmm6
00007f828abda9c8  vmovaps [rsp+0x70], xmm7
00007f828abda9ce  vmovaps [rsp+0x80], xmm8
00007f828abda9d7  vmovaps [rsp+0x90], xmm9
00007f828abda9e0  vmovaps [rsp+0xA0], xmm10
00007f828abda9e9  vmovaps [rsp+0xB0], xmm12
00007f828abda9f2  vmovaps [rsp+0xC0], xmm13
00007f828abda9fb  vmovaps [rsp+0xD0], xmm14
00007f828abdaa04  vmovaps [rsp+0xE0], xmm15
00007f828abdaa0d  sub rsp, 0x30
00007f828abdaa11  movaps [rsp], xmm11
00007f828abdaa16  movaps [rsp+0x10], xmm10
00007f828abdaa1c  movaps [rsp+0x20], xmm14
00007f828abdaa22  lea rdi, [rsp]
00007f828abdaa26  mov esi, 0x00
00007f828abdaa2b  mov rax, 0x5BFE27FA6530
00007f828abdaa35  call rax
00007f828abdaa37  movaps xmm11, [rsp]
00007f828abdaa3c  add rsp, 0x30
00007f828abdaa40  vmovaps xmm0, [rsp]
00007f828abdaa45  vmovaps xmm1, [rsp+0x10]
00007f828abdaa4b  vmovaps xmm2, [rsp+0x20]
00007f828abdaa51  vmovaps xmm3, [rsp+0x30]
00007f828abdaa57  vmovaps xmm4, [rsp+0x40]
00007f828abdaa5d  vmovaps xmm5, [rsp+0x50]
00007f828abdaa63  vmovaps xmm6, [rsp+0x60]
00007f828abdaa69  vmovaps xmm7, [rsp+0x70]
00007f828abdaa6f  vmovaps xmm8, [rsp+0x80]
00007f828abdaa78  vmovaps xmm9, [rsp+0x90]
00007f828abdaa81  vmovaps xmm10, [rsp+0xA0]
00007f828abdaa8a  vmovaps xmm12, [rsp+0xB0]
00007f828abdaa93  vmovaps xmm13, [rsp+0xC0]
00007f828abdaa9c  vmovaps xmm14, [rsp+0xD0]
00007f828abdaaa5  vmovaps xmm15, [rsp+0xE0]
00007f828abdaaae  add rsp, 0xF0
00007f828abdaab5  pop r11
00007f828abdaab7  pop r10
00007f828abdaab9  pop r9
00007f828abdaabb  pop r8
00007f828abdaabd  pop rsi
00007f828abdaabe  pop rdi
00007f828abdaabf  pop rdx
00007f828abdaac0  pop rcx
00007f828abdaac1  pop rax
00007f828abdaac2  add rsp, 0x08
00007f828abdaac6  jmp 0x00007F828ABD64ED
00007f828abdaacb  call 0x00007F828AAE45A0
00007f828abdaad0  jmp 0x00007F828ABD64F7
00007f828abdaad5  sub rsp, 0x08
00007f828abdaad9  push rax
00007f828abdaada  push rcx
00007f828abdaadb  push rdx
00007f828abdaadc  push rdi
00007f828abdaadd  push rsi
00007f828abdaade  push r8
00007f828abdaae0  push r9
00007f828abdaae2  push r10
00007f828abdaae4  push r11
00007f828abdaae6  sub rsp, 0xF0
00007f828abdaaed  vmovaps [rsp], xmm0
00007f828abdaaf2  vmovaps [rsp+0x10], xmm1
00007f828abdaaf8  vmovaps [rsp+0x20], xmm2
00007f828abdaafe  vmovaps [rsp+0x30], xmm3
00007f828abdab04  vmovaps [rsp+0x40], xmm4
00007f828abdab0a  vmovaps [rsp+0x50], xmm5
00007f828abdab10  vmovaps [rsp+0x60], xmm6
00007f828abdab16  vmovaps [rsp+0x70], xmm7
00007f828abdab1c  vmovaps [rsp+0x80], xmm8
00007f828abdab25  vmovaps [rsp+0x90], xmm9
00007f828abdab2e  vmovaps [rsp+0xA0], xmm11
00007f828abdab37  vmovaps [rsp+0xB0], xmm12
00007f828abdab40  vmovaps [rsp+0xC0], xmm13
00007f828abdab49  vmovaps [rsp+0xD0], xmm14
00007f828abdab52  vmovaps [rsp+0xE0], xmm15
00007f828abdab5b  sub rsp, 0x30
00007f828abdab5f  movaps [rsp], xmm10
00007f828abdab64  movaps [rsp+0x10], xmm1
00007f828abdab69  movaps [rsp+0x20], xmm12
00007f828abdab6f  lea rdi, [rsp]
00007f828abdab73  mov esi, 0x00
00007f828abdab78  mov rax, 0x5BFE27FA6530
00007f828abdab82  call rax
00007f828abdab84  movaps xmm10, [rsp]
00007f828abdab89  add rsp, 0x30
00007f828abdab8d  vmovaps xmm0, [rsp]
00007f828abdab92  vmovaps xmm1, [rsp+0x10]
00007f828abdab98  vmovaps xmm2, [rsp+0x20]
00007f828abdab9e  vmovaps xmm3, [rsp+0x30]
00007f828abdaba4  vmovaps xmm4, [rsp+0x40]
00007f828abdabaa  vmovaps xmm5, [rsp+0x50]
00007f828abdabb0  vmovaps xmm6, [rsp+0x60]
00007f828abdabb6  vmovaps xmm7, [rsp+0x70]
00007f828abdabbc  vmovaps xmm8, [rsp+0x80]
00007f828abdabc5  vmovaps xmm9, [rsp+0x90]
00007f828abdabce  vmovaps xmm11, [rsp+0xA0]
00007f828abdabd7  vmovaps xmm12, [rsp+0xB0]
00007f828abdabe0  vmovaps xmm13, [rsp+0xC0]
00007f828abdabe9  vmovaps xmm14, [rsp+0xD0]
00007f828abdabf2  vmovaps xmm15, [rsp+0xE0]
00007f828abdabfb  add rsp, 0xF0
00007f828abdac02  pop r11
00007f828abdac04  pop r10
00007f828abdac06  pop r9
00007f828abdac08  pop r8
00007f828abdac0a  pop rsi
00007f828abdac0b  pop rdi
00007f828abdac0c  pop rdx
00007f828abdac0d  pop rcx
00007f828abdac0e  pop rax
00007f828abdac0f  add rsp, 0x08
00007f828abdac13  jmp 0x00007F828ABD651A
00007f828abdac18  sub rsp, 0x08
00007f828abdac1c  push rax
00007f828abdac1d  push rcx
00007f828abdac1e  push rdx
00007f828abdac1f  push rdi
00007f828abdac20  push rsi
00007f828abdac21  push r8
00007f828abdac23  push r9
00007f828abdac25  push r10
00007f828abdac27  push r11
00007f828abdac29  sub rsp, 0xF0
00007f828abdac30  vmovaps [rsp], xmm0
00007f828abdac35  vmovaps [rsp+0x10], xmm1
00007f828abdac3b  vmovaps [rsp+0x20], xmm2
00007f828abdac41  vmovaps [rsp+0x30], xmm3
00007f828abdac47  vmovaps [rsp+0x40], xmm4
00007f828abdac4d  vmovaps [rsp+0x50], xmm5
00007f828abdac53  vmovaps [rsp+0x60], xmm6
00007f828abdac59  vmovaps [rsp+0x70], xmm7
00007f828abdac5f  vmovaps [rsp+0x80], xmm8
00007f828abdac68  vmovaps [rsp+0x90], xmm9
00007f828abdac71  vmovaps [rsp+0xA0], xmm10
00007f828abdac7a  vmovaps [rsp+0xB0], xmm11
00007f828abdac83  vmovaps [rsp+0xC0], xmm13
00007f828abdac8c  vmovaps [rsp+0xD0], xmm14
00007f828abdac95  vmovaps [rsp+0xE0], xmm15
00007f828abdac9e  sub rsp, 0x30
00007f828abdaca2  movaps [rsp], xmm12
00007f828abdaca7  movaps [rsp+0x10], xmm14
00007f828abdacad  movaps [rsp+0x20], xmm1
00007f828abdacb2  lea rdi, [rsp]
00007f828abdacb6  mov esi, 0x00
00007f828abdacbb  mov rax, 0x5BFE27FA6530
00007f828abdacc5  call rax
00007f828abdacc7  movaps xmm12, [rsp]
00007f828abdaccc  add rsp, 0x30
00007f828abdacd0  vmovaps xmm0, [rsp]
00007f828abdacd5  vmovaps xmm1, [rsp+0x10]
00007f828abdacdb  vmovaps xmm2, [rsp+0x20]
00007f828abdace1  vmovaps xmm3, [rsp+0x30]
00007f828abdace7  vmovaps xmm4, [rsp+0x40]
00007f828abdaced  vmovaps xmm5, [rsp+0x50]
00007f828abdacf3  vmovaps xmm6, [rsp+0x60]
00007f828abdacf9  vmovaps xmm7, [rsp+0x70]
00007f828abdacff  vmovaps xmm8, [rsp+0x80]
00007f828abdad08  vmovaps xmm9, [rsp+0x90]
00007f828abdad11  vmovaps xmm10, [rsp+0xA0]
00007f828abdad1a  vmovaps xmm11, [rsp+0xB0]
00007f828abdad23  vmovaps xmm13, [rsp+0xC0]
00007f828abdad2c  vmovaps xmm14, [rsp+0xD0]
00007f828abdad35  vmovaps xmm15, [rsp+0xE0]
00007f828abdad3e  add rsp, 0xF0
00007f828abdad45  pop r11
00007f828abdad47  pop r10
00007f828abdad49  pop r9
00007f828abdad4b  pop r8
00007f828abdad4d  pop rsi
00007f828abdad4e  pop rdi
00007f828abdad4f  pop rdx
00007f828abdad50  pop rcx
00007f828abdad51  pop rax
00007f828abdad52  add rsp, 0x08
00007f828abdad56  jmp 0x00007F828ABD6549
00007f828abdad5b  sub rsp, 0x08
00007f828abdad5f  push rax
00007f828abdad60  push rcx
00007f828abdad61  push rdx
00007f828abdad62  push rdi
00007f828abdad63  push rsi
00007f828abdad64  push r8
00007f828abdad66  push r9
00007f828abdad68  push r10
00007f828abdad6a  push r11
00007f828abdad6c  sub rsp, 0xF0
00007f828abdad73  vmovaps [rsp], xmm0
00007f828abdad78  vmovaps [rsp+0x10], xmm1
00007f828abdad7e  vmovaps [rsp+0x20], xmm2
00007f828abdad84  vmovaps [rsp+0x30], xmm3
00007f828abdad8a  vmovaps [rsp+0x40], xmm4
00007f828abdad90  vmovaps [rsp+0x50], xmm5
00007f828abdad96  vmovaps [rsp+0x60], xmm6
00007f828abdad9c  vmovaps [rsp+0x70], xmm7
00007f828abdada2  vmovaps [rsp+0x80], xmm8
00007f828abdadab  vmovaps [rsp+0x90], xmm9
00007f828abdadb4  vmovaps [rsp+0xA0], xmm10
00007f828abdadbd  vmovaps [rsp+0xB0], xmm11
00007f828abdadc6  vmovaps [rsp+0xC0], xmm12
00007f828abdadcf  vmovaps [rsp+0xD0], xmm13
00007f828abdadd8  vmovaps [rsp+0xE0], xmm15
00007f828abdade1  sub rsp, 0x30
00007f828abdade5  movaps [rsp], xmm14
00007f828abdadea  movaps [rsp+0x10], xmm9
00007f828abdadf0  movaps [rsp+0x20], xmm1
00007f828abdadf5  lea rdi, [rsp]
00007f828abdadf9  mov esi, 0x00
00007f828abdadfe  mov rax, 0x5BFE27FA6530
00007f828abdae08  call rax
00007f828abdae0a  movaps xmm14, [rsp]
00007f828abdae0f  add rsp, 0x30
00007f828abdae13  vmovaps xmm0, [rsp]
00007f828abdae18  vmovaps xmm1, [rsp+0x10]
00007f828abdae1e  vmovaps xmm2, [rsp+0x20]
00007f828abdae24  vmovaps xmm3, [rsp+0x30]
00007f828abdae2a  vmovaps xmm4, [rsp+0x40]
00007f828abdae30  vmovaps xmm5, [rsp+0x50]
00007f828abdae36  vmovaps xmm6, [rsp+0x60]
00007f828abdae3c  vmovaps xmm7, [rsp+0x70]
00007f828abdae42  vmovaps xmm8, [rsp+0x80]
00007f828abdae4b  vmovaps xmm9, [rsp+0x90]
00007f828abdae54  vmovaps xmm10, [rsp+0xA0]
00007f828abdae5d  vmovaps xmm11, [rsp+0xB0]
00007f828abdae66  vmovaps xmm12, [rsp+0xC0]
00007f828abdae6f  vmovaps xmm13, [rsp+0xD0]
00007f828abdae78  vmovaps xmm15, [rsp+0xE0]
00007f828abdae81  add rsp, 0xF0
00007f828abdae88  pop r11
00007f828abdae8a  pop r10
00007f828abdae8c  pop r9
00007f828abdae8e  pop r8
00007f828abdae90  pop rsi
00007f828abdae91  pop rdi
00007f828abdae92  pop rdx
00007f828abdae93  pop rcx
00007f828abdae94  pop rax
00007f828abdae95  add rsp, 0x08
00007f828abdae99  jmp 0x00007F828ABD6578
00007f828abdae9e  sub rsp, 0x08
00007f828abdaea2  push rax
00007f828abdaea3  push rcx
00007f828abdaea4  push rdx
00007f828abdaea5  push rdi
00007f828abdaea6  push rsi
00007f828abdaea7  push r8
00007f828abdaea9  push r9
00007f828abdaeab  push r10
00007f828abdaead  push r11
00007f828abdaeaf  sub rsp, 0xF0
00007f828abdaeb6  vmovaps [rsp], xmm0
00007f828abdaebb  vmovaps [rsp+0x10], xmm2
00007f828abdaec1  vmovaps [rsp+0x20], xmm3
00007f828abdaec7  vmovaps [rsp+0x30], xmm4
00007f828abdaecd  vmovaps [rsp+0x40], xmm5
00007f828abdaed3  vmovaps [rsp+0x50], xmm6
00007f828abdaed9  vmovaps [rsp+0x60], xmm7
00007f828abdaedf  vmovaps [rsp+0x70], xmm8
00007f828abdaee5  vmovaps [rsp+0x80], xmm9
00007f828abdaeee  vmovaps [rsp+0x90], xmm10
00007f828abdaef7  vmovaps [rsp+0xA0], xmm11
00007f828abdaf00  vmovaps [rsp+0xB0], xmm12
00007f828abdaf09  vmovaps [rsp+0xC0], xmm13
00007f828abdaf12  vmovaps [rsp+0xD0], xmm14
00007f828abdaf1b  vmovaps [rsp+0xE0], xmm15
00007f828abdaf24  sub rsp, 0x30
00007f828abdaf28  movaps [rsp], xmm1
00007f828abdaf2c  movaps [rsp+0x10], xmm13
00007f828abdaf32  movaps [rsp+0x20], xmm8
00007f828abdaf38  lea rdi, [rsp]
00007f828abdaf3c  mov esi, 0x00
00007f828abdaf41  mov rax, 0x5BFE27FA6530
00007f828abdaf4b  call rax
00007f828abdaf4d  movaps xmm1, [rsp]
00007f828abdaf51  add rsp, 0x30
00007f828abdaf55  vmovaps xmm0, [rsp]
00007f828abdaf5a  vmovaps xmm2, [rsp+0x10]
00007f828abdaf60  vmovaps xmm3, [rsp+0x20]
00007f828abdaf66  vmovaps xmm4, [rsp+0x30]
00007f828abdaf6c  vmovaps xmm5, [rsp+0x40]
00007f828abdaf72  vmovaps xmm6, [rsp+0x50]
00007f828abdaf78  vmovaps xmm7, [rsp+0x60]
00007f828abdaf7e  vmovaps xmm8, [rsp+0x70]
00007f828abdaf84  vmovaps xmm9, [rsp+0x80]
00007f828abdaf8d  vmovaps xmm10, [rsp+0x90]
00007f828abdaf96  vmovaps xmm11, [rsp+0xA0]
00007f828abdaf9f  vmovaps xmm12, [rsp+0xB0]
00007f828abdafa8  vmovaps xmm13, [rsp+0xC0]
00007f828abdafb1  vmovaps xmm14, [rsp+0xD0]
00007f828abdafba  vmovaps xmm15, [rsp+0xE0]
00007f828abdafc3  add rsp, 0xF0
00007f828abdafca  pop r11
00007f828abdafcc  pop r10
00007f828abdafce  pop r9
00007f828abdafd0  pop r8
00007f828abdafd2  pop rsi
00007f828abdafd3  pop rdi
00007f828abdafd4  pop rdx
00007f828abdafd5  pop rcx
00007f828abdafd6  pop rax
00007f828abdafd7  add rsp, 0x08
00007f828abdafdb  jmp 0x00007F828ABD659A
00007f828abdafe0  call 0x00007F828AA0C260
00007f828abdafe5  jmp 0x00007F828ABD65A8
00007f828abdafea  call 0x00007F828AADE950
00007f828abdafef  jmp 0x00007F828ABD65B2
00007f828abdaff4  sub rsp, 0x08
00007f828abdaff8  push rax
00007f828abdaff9  push rcx
00007f828abdaffa  push rdx
00007f828abdaffb  push rdi
00007f828abdaffc  push rsi
00007f828abdaffd  push r8
00007f828abdafff  push r9
00007f828abdb001  push r10
00007f828abdb003  push r11
00007f828abdb005  sub rsp, 0xF0
00007f828abdb00c  vmovaps [rsp], xmm0
00007f828abdb011  vmovaps [rsp+0x10], xmm1
00007f828abdb017  vmovaps [rsp+0x20], xmm2
00007f828abdb01d  vmovaps [rsp+0x30], xmm3
00007f828abdb023  vmovaps [rsp+0x40], xmm4
00007f828abdb029  vmovaps [rsp+0x50], xmm5
00007f828abdb02f  vmovaps [rsp+0x60], xmm6
00007f828abdb035  vmovaps [rsp+0x70], xmm7
00007f828abdb03b  vmovaps [rsp+0x80], xmm9
00007f828abdb044  vmovaps [rsp+0x90], xmm10
00007f828abdb04d  vmovaps [rsp+0xA0], xmm11
00007f828abdb056  vmovaps [rsp+0xB0], xmm12
00007f828abdb05f  vmovaps [rsp+0xC0], xmm13
00007f828abdb068  vmovaps [rsp+0xD0], xmm14
00007f828abdb071  vmovaps [rsp+0xE0], xmm15
00007f828abdb07a  sub rsp, 0x30
00007f828abdb07e  movaps [rsp], xmm8
00007f828abdb083  movaps [rsp+0x10], xmm15
00007f828abdb089  movaps [rsp+0x20], xmm7
00007f828abdb08e  lea rdi, [rsp]
00007f828abdb092  mov esi, 0x00
00007f828abdb097  mov rax, 0x5BFE27FA6530
00007f828abdb0a1  call rax
00007f828abdb0a3  movaps xmm8, [rsp]
00007f828abdb0a8  add rsp, 0x30
00007f828abdb0ac  vmovaps xmm0, [rsp]
00007f828abdb0b1  vmovaps xmm1, [rsp+0x10]
00007f828abdb0b7  vmovaps xmm2, [rsp+0x20]
00007f828abdb0bd  vmovaps xmm3, [rsp+0x30]
00007f828abdb0c3  vmovaps xmm4, [rsp+0x40]
00007f828abdb0c9  vmovaps xmm5, [rsp+0x50]
00007f828abdb0cf  vmovaps xmm6, [rsp+0x60]
00007f828abdb0d5  vmovaps xmm7, [rsp+0x70]
00007f828abdb0db  vmovaps xmm9, [rsp+0x80]
00007f828abdb0e4  vmovaps xmm10, [rsp+0x90]
00007f828abdb0ed  vmovaps xmm11, [rsp+0xA0]
00007f828abdb0f6  vmovaps xmm12, [rsp+0xB0]
00007f828abdb0ff  vmovaps xmm13, [rsp+0xC0]
00007f828abdb108  vmovaps xmm14, [rsp+0xD0]
00007f828abdb111  vmovaps xmm15, [rsp+0xE0]
00007f828abdb11a  add rsp, 0xF0
00007f828abdb121  pop r11
00007f828abdb123  pop r10
00007f828abdb125  pop r9
00007f828abdb127  pop r8
00007f828abdb129  pop rsi
00007f828abdb12a  pop rdi
00007f828abdb12b  pop rdx
00007f828abdb12c  pop rcx
00007f828abdb12d  pop rax
00007f828abdb12e  add rsp, 0x08
00007f828abdb132  jmp 0x00007F828ABD65D4
00007f828abdb137  sub rsp, 0x08
00007f828abdb13b  push rax
00007f828abdb13c  push rcx
00007f828abdb13d  push rdx
00007f828abdb13e  push rdi
00007f828abdb13f  push rsi
00007f828abdb140  push r8
00007f828abdb142  push r9
00007f828abdb144  push r10
00007f828abdb146  push r11
00007f828abdb148  sub rsp, 0xF0
00007f828abdb14f  vmovaps [rsp], xmm0
00007f828abdb154  vmovaps [rsp+0x10], xmm1
00007f828abdb15a  vmovaps [rsp+0x20], xmm2
00007f828abdb160  vmovaps [rsp+0x30], xmm3
00007f828abdb166  vmovaps [rsp+0x40], xmm4
00007f828abdb16c  vmovaps [rsp+0x50], xmm5
00007f828abdb172  vmovaps [rsp+0x60], xmm6
00007f828abdb178  vmovaps [rsp+0x70], xmm8
00007f828abdb17e  vmovaps [rsp+0x80], xmm9
00007f828abdb187  vmovaps [rsp+0x90], xmm10
00007f828abdb190  vmovaps [rsp+0xA0], xmm11
00007f828abdb199  vmovaps [rsp+0xB0], xmm12
00007f828abdb1a2  vmovaps [rsp+0xC0], xmm13
00007f828abdb1ab  vmovaps [rsp+0xD0], xmm14
00007f828abdb1b4  vmovaps [rsp+0xE0], xmm15
00007f828abdb1bd  sub rsp, 0x30
00007f828abdb1c1  movaps [rsp], xmm7
00007f828abdb1c5  movaps [rsp+0x10], xmm9
00007f828abdb1cb  movaps [rsp+0x20], xmm15
00007f828abdb1d1  lea rdi, [rsp]
00007f828abdb1d5  mov esi, 0x00
00007f828abdb1da  mov rax, 0x5BFE27FA6530
00007f828abdb1e4  call rax
00007f828abdb1e6  movaps xmm7, [rsp]
00007f828abdb1ea  add rsp, 0x30
00007f828abdb1ee  vmovaps xmm0, [rsp]
00007f828abdb1f3  vmovaps xmm1, [rsp+0x10]
00007f828abdb1f9  vmovaps xmm2, [rsp+0x20]
00007f828abdb1ff  vmovaps xmm3, [rsp+0x30]
00007f828abdb205  vmovaps xmm4, [rsp+0x40]
00007f828abdb20b  vmovaps xmm5, [rsp+0x50]
00007f828abdb211  vmovaps xmm6, [rsp+0x60]
00007f828abdb217  vmovaps xmm8, [rsp+0x70]
00007f828abdb21d  vmovaps xmm9, [rsp+0x80]
00007f828abdb226  vmovaps xmm10, [rsp+0x90]
00007f828abdb22f  vmovaps xmm11, [rsp+0xA0]
00007f828abdb238  vmovaps xmm12, [rsp+0xB0]
00007f828abdb241  vmovaps xmm13, [rsp+0xC0]
00007f828abdb24a  vmovaps xmm14, [rsp+0xD0]
00007f828abdb253  vmovaps xmm15, [rsp+0xE0]
00007f828abdb25c  add rsp, 0xF0
00007f828abdb263  pop r11
00007f828abdb265  pop r10
00007f828abdb267  pop r9
00007f828abdb269  pop r8
00007f828abdb26b  pop rsi
00007f828abdb26c  pop rdi
00007f828abdb26d  pop rdx
00007f828abdb26e  pop rcx
00007f828abdb26f  pop rax
00007f828abdb270  add rsp, 0x08
00007f828abdb274  jmp 0x00007F828ABD6601
00007f828abdb279  sub rsp, 0x08
00007f828abdb27d  push rax
00007f828abdb27e  push rcx
00007f828abdb27f  push rdx
00007f828abdb280  push rdi
00007f828abdb281  push rsi
00007f828abdb282  push r8
00007f828abdb284  push r9
00007f828abdb286  push r10
00007f828abdb288  push r11
00007f828abdb28a  sub rsp, 0xF0
00007f828abdb291  vmovaps [rsp], xmm0
00007f828abdb296  vmovaps [rsp+0x10], xmm1
00007f828abdb29c  vmovaps [rsp+0x20], xmm2
00007f828abdb2a2  vmovaps [rsp+0x30], xmm3
00007f828abdb2a8  vmovaps [rsp+0x40], xmm4
00007f828abdb2ae  vmovaps [rsp+0x50], xmm5
00007f828abdb2b4  vmovaps [rsp+0x60], xmm6
00007f828abdb2ba  vmovaps [rsp+0x70], xmm7
00007f828abdb2c0  vmovaps [rsp+0x80], xmm8
00007f828abdb2c9  vmovaps [rsp+0x90], xmm10
00007f828abdb2d2  vmovaps [rsp+0xA0], xmm11
00007f828abdb2db  vmovaps [rsp+0xB0], xmm12
00007f828abdb2e4  vmovaps [rsp+0xC0], xmm13
00007f828abdb2ed  vmovaps [rsp+0xD0], xmm14
00007f828abdb2f6  vmovaps [rsp+0xE0], xmm15
00007f828abdb2ff  sub rsp, 0x30
00007f828abdb303  movaps [rsp], xmm9
00007f828abdb308  movaps [rsp+0x10], xmm13
00007f828abdb30e  movaps [rsp+0x20], xmm15
00007f828abdb314  lea rdi, [rsp]
00007f828abdb318  mov esi, 0x00
00007f828abdb31d  mov rax, 0x5BFE27FA6530
00007f828abdb327  call rax
00007f828abdb329  movaps xmm9, [rsp]
00007f828abdb32e  add rsp, 0x30
00007f828abdb332  vmovaps xmm0, [rsp]
00007f828abdb337  vmovaps xmm1, [rsp+0x10]
00007f828abdb33d  vmovaps xmm2, [rsp+0x20]
00007f828abdb343  vmovaps xmm3, [rsp+0x30]
00007f828abdb349  vmovaps xmm4, [rsp+0x40]
00007f828abdb34f  vmovaps xmm5, [rsp+0x50]
00007f828abdb355  vmovaps xmm6, [rsp+0x60]
00007f828abdb35b  vmovaps xmm7, [rsp+0x70]
00007f828abdb361  vmovaps xmm8, [rsp+0x80]
00007f828abdb36a  vmovaps xmm10, [rsp+0x90]
00007f828abdb373  vmovaps xmm11, [rsp+0xA0]
00007f828abdb37c  vmovaps xmm12, [rsp+0xB0]
00007f828abdb385  vmovaps xmm13, [rsp+0xC0]
00007f828abdb38e  vmovaps xmm14, [rsp+0xD0]
00007f828abdb397  vmovaps xmm15, [rsp+0xE0]
00007f828abdb3a0  add rsp, 0xF0
00007f828abdb3a7  pop r11
00007f828abdb3a9  pop r10
00007f828abdb3ab  pop r9
00007f828abdb3ad  pop r8
00007f828abdb3af  pop rsi
00007f828abdb3b0  pop rdi
00007f828abdb3b1  pop rdx
00007f828abdb3b2  pop rcx
00007f828abdb3b3  pop rax
00007f828abdb3b4  add rsp, 0x08
00007f828abdb3b8  jmp 0x00007F828ABD662F
00007f828abdb3bd  sub rsp, 0x08
00007f828abdb3c1  push rax
00007f828abdb3c2  push rcx
00007f828abdb3c3  push rdx
00007f828abdb3c4  push rdi
00007f828abdb3c5  push rsi
00007f828abdb3c6  push r8
00007f828abdb3c8  push r9
00007f828abdb3ca  push r10
00007f828abdb3cc  push r11
00007f828abdb3ce  sub rsp, 0xF0
00007f828abdb3d5  vmovaps [rsp], xmm0
00007f828abdb3da  vmovaps [rsp+0x10], xmm1
00007f828abdb3e0  vmovaps [rsp+0x20], xmm2
00007f828abdb3e6  vmovaps [rsp+0x30], xmm3
00007f828abdb3ec  vmovaps [rsp+0x40], xmm4
00007f828abdb3f2  vmovaps [rsp+0x50], xmm5
00007f828abdb3f8  vmovaps [rsp+0x60], xmm6
00007f828abdb3fe  vmovaps [rsp+0x70], xmm7
00007f828abdb404  vmovaps [rsp+0x80], xmm8
00007f828abdb40d  vmovaps [rsp+0x90], xmm9
00007f828abdb416  vmovaps [rsp+0xA0], xmm10
00007f828abdb41f  vmovaps [rsp+0xB0], xmm11
00007f828abdb428  vmovaps [rsp+0xC0], xmm12
00007f828abdb431  vmovaps [rsp+0xD0], xmm13
00007f828abdb43a  vmovaps [rsp+0xE0], xmm14
00007f828abdb443  sub rsp, 0x30
00007f828abdb447  movaps [rsp], xmm15
00007f828abdb44c  movaps [rsp+0x10], xmm11
00007f828abdb452  movaps [rsp+0x20], xmm12
00007f828abdb458  lea rdi, [rsp]
00007f828abdb45c  mov esi, 0x00
00007f828abdb461  mov rax, 0x5BFE27FA6530
00007f828abdb46b  call rax
00007f828abdb46d  movaps xmm15, [rsp]
00007f828abdb472  add rsp, 0x30
00007f828abdb476  vmovaps xmm0, [rsp]
00007f828abdb47b  vmovaps xmm1, [rsp+0x10]
00007f828abdb481  vmovaps xmm2, [rsp+0x20]
00007f828abdb487  vmovaps xmm3, [rsp+0x30]
00007f828abdb48d  vmovaps xmm4, [rsp+0x40]
00007f828abdb493  vmovaps xmm5, [rsp+0x50]
00007f828abdb499  vmovaps xmm6, [rsp+0x60]
00007f828abdb49f  vmovaps xmm7, [rsp+0x70]
00007f828abdb4a5  vmovaps xmm8, [rsp+0x80]
00007f828abdb4ae  vmovaps xmm9, [rsp+0x90]
00007f828abdb4b7  vmovaps xmm10, [rsp+0xA0]
00007f828abdb4c0  vmovaps xmm11, [rsp+0xB0]
00007f828abdb4c9  vmovaps xmm12, [rsp+0xC0]
00007f828abdb4d2  vmovaps xmm13, [rsp+0xD0]
00007f828abdb4db  vmovaps xmm14, [rsp+0xE0]
00007f828abdb4e4  add rsp, 0xF0
00007f828abdb4eb  pop r11
00007f828abdb4ed  pop r10
00007f828abdb4ef  pop r9
00007f828abdb4f1  pop r8
00007f828abdb4f3  pop rsi
00007f828abdb4f4  pop rdi
00007f828abdb4f5  pop rdx
00007f828abdb4f6  pop rcx
00007f828abdb4f7  pop rax
00007f828abdb4f8  add rsp, 0x08
00007f828abdb4fc  jmp 0x00007F828ABD664A
00007f828abdb501  sub rsp, 0x08
00007f828abdb505  push rax
00007f828abdb506  push rcx
00007f828abdb507  push rdx
00007f828abdb508  push rdi
00007f828abdb509  push rsi
00007f828abdb50a  push r8
00007f828abdb50c  push r9
00007f828abdb50e  push r10
00007f828abdb510  push r11
00007f828abdb512  sub rsp, 0xF0
00007f828abdb519  vmovaps [rsp], xmm0
00007f828abdb51e  vmovaps [rsp+0x10], xmm1
00007f828abdb524  vmovaps [rsp+0x20], xmm2
00007f828abdb52a  vmovaps [rsp+0x30], xmm3
00007f828abdb530  vmovaps [rsp+0x40], xmm4
00007f828abdb536  vmovaps [rsp+0x50], xmm5
00007f828abdb53c  vmovaps [rsp+0x60], xmm6
00007f828abdb542  vmovaps [rsp+0x70], xmm7
00007f828abdb548  vmovaps [rsp+0x80], xmm8
00007f828abdb551  vmovaps [rsp+0x90], xmm9
00007f828abdb55a  vmovaps [rsp+0xA0], xmm10
00007f828abdb563  vmovaps [rsp+0xB0], xmm11
00007f828abdb56c  vmovaps [rsp+0xC0], xmm12
00007f828abdb575  vmovaps [rsp+0xD0], xmm14
00007f828abdb57e  vmovaps [rsp+0xE0], xmm15
00007f828abdb587  sub rsp, 0x30
00007f828abdb58b  movaps [rsp], xmm13
00007f828abdb590  movaps [rsp+0x10], xmm10
00007f828abdb596  movaps [rsp+0x20], xmm14
00007f828abdb59c  lea rdi, [rsp]
00007f828abdb5a0  mov esi, 0x00
00007f828abdb5a5  mov rax, 0x5BFE27FA6530
00007f828abdb5af  call rax
00007f828abdb5b1  movaps xmm13, [rsp]
00007f828abdb5b6  add rsp, 0x30
00007f828abdb5ba  vmovaps xmm0, [rsp]
00007f828abdb5bf  vmovaps xmm1, [rsp+0x10]
00007f828abdb5c5  vmovaps xmm2, [rsp+0x20]
00007f828abdb5cb  vmovaps xmm3, [rsp+0x30]
00007f828abdb5d1  vmovaps xmm4, [rsp+0x40]
00007f828abdb5d7  vmovaps xmm5, [rsp+0x50]
00007f828abdb5dd  vmovaps xmm6, [rsp+0x60]
00007f828abdb5e3  vmovaps xmm7, [rsp+0x70]
00007f828abdb5e9  vmovaps xmm8, [rsp+0x80]
00007f828abdb5f2  vmovaps xmm9, [rsp+0x90]
00007f828abdb5fb  vmovaps xmm10, [rsp+0xA0]
00007f828abdb604  vmovaps xmm11, [rsp+0xB0]
00007f828abdb60d  vmovaps xmm12, [rsp+0xC0]
00007f828abdb616  vmovaps xmm14, [rsp+0xD0]
00007f828abdb61f  vmovaps xmm15, [rsp+0xE0]
00007f828abdb628  add rsp, 0xF0
00007f828abdb62f  pop r11
00007f828abdb631  pop r10
00007f828abdb633  pop r9
00007f828abdb635  pop r8
00007f828abdb637  pop rsi
00007f828abdb638  pop rdi
00007f828abdb639  pop rdx
00007f828abdb63a  pop rcx
00007f828abdb63b  pop rax
00007f828abdb63c  add rsp, 0x08
00007f828abdb640  jmp 0x00007F828ABD666D
00007f828abdb645  sub rsp, 0x08
00007f828abdb649  push rax
00007f828abdb64a  push rcx
00007f828abdb64b  push rdx
00007f828abdb64c  push rdi
00007f828abdb64d  push rsi
00007f828abdb64e  push r8
00007f828abdb650  push r9
00007f828abdb652  push r10
00007f828abdb654  push r11
00007f828abdb656  sub rsp, 0xF0
00007f828abdb65d  vmovaps [rsp], xmm0
00007f828abdb662  vmovaps [rsp+0x10], xmm1
00007f828abdb668  vmovaps [rsp+0x20], xmm2
00007f828abdb66e  vmovaps [rsp+0x30], xmm3
00007f828abdb674  vmovaps [rsp+0x40], xmm4
00007f828abdb67a  vmovaps [rsp+0x50], xmm5
00007f828abdb680  vmovaps [rsp+0x60], xmm6
00007f828abdb686  vmovaps [rsp+0x70], xmm7
00007f828abdb68c  vmovaps [rsp+0x80], xmm8
00007f828abdb695  vmovaps [rsp+0x90], xmm9
00007f828abdb69e  vmovaps [rsp+0xA0], xmm10
00007f828abdb6a7  vmovaps [rsp+0xB0], xmm11
00007f828abdb6b0  vmovaps [rsp+0xC0], xmm12
00007f828abdb6b9  vmovaps [rsp+0xD0], xmm13
00007f828abdb6c2  vmovaps [rsp+0xE0], xmm15
00007f828abdb6cb  sub rsp, 0x30
00007f828abdb6cf  movaps [rsp], xmm14
00007f828abdb6d4  movaps [rsp+0x10], xmm1
00007f828abdb6d9  movaps [rsp+0x20], xmm7
00007f828abdb6de  lea rdi, [rsp]
00007f828abdb6e2  mov esi, 0x00
00007f828abdb6e7  mov rax, 0x5BFE27FA6530
00007f828abdb6f1  call rax
00007f828abdb6f3  movaps xmm14, [rsp]
00007f828abdb6f8  add rsp, 0x30
00007f828abdb6fc  vmovaps xmm0, [rsp]
00007f828abdb701  vmovaps xmm1, [rsp+0x10]
00007f828abdb707  vmovaps xmm2, [rsp+0x20]
00007f828abdb70d  vmovaps xmm3, [rsp+0x30]
00007f828abdb713  vmovaps xmm4, [rsp+0x40]
00007f828abdb719  vmovaps xmm5, [rsp+0x50]
00007f828abdb71f  vmovaps xmm6, [rsp+0x60]
00007f828abdb725  vmovaps xmm7, [rsp+0x70]
00007f828abdb72b  vmovaps xmm8, [rsp+0x80]
00007f828abdb734  vmovaps xmm9, [rsp+0x90]
00007f828abdb73d  vmovaps xmm10, [rsp+0xA0]
00007f828abdb746  vmovaps xmm11, [rsp+0xB0]
00007f828abdb74f  vmovaps xmm12, [rsp+0xC0]
00007f828abdb758  vmovaps xmm13, [rsp+0xD0]
00007f828abdb761  vmovaps xmm15, [rsp+0xE0]
00007f828abdb76a  add rsp, 0xF0
00007f828abdb771  pop r11
00007f828abdb773  pop r10
00007f828abdb775  pop r9
00007f828abdb777  pop r8
00007f828abdb779  pop rsi
00007f828abdb77a  pop rdi
00007f828abdb77b  pop rdx
00007f828abdb77c  pop rcx
00007f828abdb77d  pop rax
00007f828abdb77e  add rsp, 0x08
00007f828abdb782  jmp 0x00007F828ABD6690
00007f828abdb787  sub rsp, 0x08
00007f828abdb78b  push rax
00007f828abdb78c  push rcx
00007f828abdb78d  push rdx
00007f828abdb78e  push rdi
00007f828abdb78f  push rsi
00007f828abdb790  push r8
00007f828abdb792  push r9
00007f828abdb794  push r10
00007f828abdb796  push r11
00007f828abdb798  sub rsp, 0xF0
00007f828abdb79f  vmovaps [rsp], xmm0
00007f828abdb7a4  vmovaps [rsp+0x10], xmm2
00007f828abdb7aa  vmovaps [rsp+0x20], xmm3
00007f828abdb7b0  vmovaps [rsp+0x30], xmm4
00007f828abdb7b6  vmovaps [rsp+0x40], xmm5
00007f828abdb7bc  vmovaps [rsp+0x50], xmm6
00007f828abdb7c2  vmovaps [rsp+0x60], xmm7
00007f828abdb7c8  vmovaps [rsp+0x70], xmm8
00007f828abdb7ce  vmovaps [rsp+0x80], xmm9
00007f828abdb7d7  vmovaps [rsp+0x90], xmm10
00007f828abdb7e0  vmovaps [rsp+0xA0], xmm11
00007f828abdb7e9  vmovaps [rsp+0xB0], xmm12
00007f828abdb7f2  vmovaps [rsp+0xC0], xmm13
00007f828abdb7fb  vmovaps [rsp+0xD0], xmm14
00007f828abdb804  vmovaps [rsp+0xE0], xmm15
00007f828abdb80d  sub rsp, 0x30
00007f828abdb811  movaps [rsp], xmm1
00007f828abdb815  movaps [rsp+0x10], xmm8
00007f828abdb81b  movaps [rsp+0x20], xmm9
00007f828abdb821  lea rdi, [rsp]
00007f828abdb825  mov esi, 0x00
00007f828abdb82a  mov rax, 0x5BFE27FA6530
00007f828abdb834  call rax
00007f828abdb836  movaps xmm1, [rsp]
00007f828abdb83a  add rsp, 0x30
00007f828abdb83e  vmovaps xmm0, [rsp]
00007f828abdb843  vmovaps xmm2, [rsp+0x10]
00007f828abdb849  vmovaps xmm3, [rsp+0x20]
00007f828abdb84f  vmovaps xmm4, [rsp+0x30]
00007f828abdb855  vmovaps xmm5, [rsp+0x40]
00007f828abdb85b  vmovaps xmm6, [rsp+0x50]
00007f828abdb861  vmovaps xmm7, [rsp+0x60]
00007f828abdb867  vmovaps xmm8, [rsp+0x70]
00007f828abdb86d  vmovaps xmm9, [rsp+0x80]
00007f828abdb876  vmovaps xmm10, [rsp+0x90]
00007f828abdb87f  vmovaps xmm11, [rsp+0xA0]
00007f828abdb888  vmovaps xmm12, [rsp+0xB0]
00007f828abdb891  vmovaps xmm13, [rsp+0xC0]
00007f828abdb89a  vmovaps xmm14, [rsp+0xD0]
00007f828abdb8a3  vmovaps xmm15, [rsp+0xE0]
00007f828abdb8ac  add rsp, 0xF0
00007f828abdb8b3  pop r11
00007f828abdb8b5  pop r10
00007f828abdb8b7  pop r9
00007f828abdb8b9  pop r8
00007f828abdb8bb  pop rsi
00007f828abdb8bc  pop rdi
00007f828abdb8bd  pop rdx
00007f828abdb8be  pop rcx
00007f828abdb8bf  pop rax
00007f828abdb8c0  add rsp, 0x08
00007f828abdb8c4  jmp 0x00007F828ABD66B2
00007f828abdb8c9  call 0x00007F828AAB3E40
00007f828abdb8ce  jmp 0x00007F828ABD66C0
00007f828abdb8d3  call 0x00007F828AA0C380
00007f828abdb8d8  jmp 0x00007F828ABD66CA
00007f828abdb8dd  call 0x00007F828AA0D600
00007f828abdb8e2  jmp 0x00007F828ABD66D4
00007f828abdb8e7  call 0x00007F828A9FF540
00007f828abdb8ec  jmp 0x00007F828ABD66DE
00007f828abdb8f1  int3
00007f828abdb8f2  nop [rax+rax*1], ax
00007f828abdb8fb  nop [rax+rax*1], eax
00007f828abdb900  mov eax, [r15+0x48]
00007f828abdb904  lea r14d, [eax+0x01]
00007f828abdb909  mov [rsp+0x10], r14d
00007f828abdb90e  mov r14d, r14d
00007f828abdb911  mov [r15+0x48], r14
00007f828abdb915  xor eax, eax
00007f828abdb917  mov r14d, [rsp+0x10]
00007f828abdb91c  cmp r14d, 0x1F4
00007f828abdb923  cmc
00007f828abdb924  lahf
00007f828abdb925  seto al
00007f828abdb928  mov [r15+0x108], eax
00007f828abdb92f  mov eax, [r15+0x108]
00007f828abdb936  sahf
00007f828abdb937  jnz 0x00007F828ABDB969
00007f828abdb939  cmp dword ptr [r15+0x318], 0x00
00007f828abdb941  jz 0x00007F828ABE1AB0
00007f828abdb947  nop [rax+rax*1], ax
00007f828abdb950  nop [rax+rax*1], eax
00007f828abdb958  mov eax, 0x410450
00007f828abdb95d  mov [r15+0x100], rax
00007f828abdb964  jmp 0x00007F828A9FE110
00007f828abdb969  cmp dword ptr [r15+0x318], 0x00
00007f828abdb971  jz 0x00007F828ABDB9A0
00007f828abdb977  nop [rax+rax*1], ax
00007f828abdb980  nop [rax+rax*1], eax
00007f828abdb988  mov eax, 0x410274
00007f828abdb98d  mov [r15+0x100], rax
00007f828abdb994  jmp 0x00007F828A9FE110
00007f828abdb999  int3
00007f828abdb99a  int3
00007f828abdb99b  nop [rax+rax*1], eax
00007f828abdb9a0  mov rax, [r15+0x40]
00007f828abdb9a4  movaps xmm1, [r15+0x1D0]
00007f828abdb9ac  vmovaps [rsp+0x10], xmm1
00007f828abdb9b2  vmovaps xmm15, [rsp+0x10]
00007f828abdb9b8  por xmm1, xmm15
00007f828abdb9bd  movaps xmm14, [r15+0x1A0]
00007f828abdb9c5  vmovaps [rsp+0x10], xmm14
00007f828abdb9cb  vmovaps xmm13, [rsp+0x10]
00007f828abdb9d1  por xmm14, xmm13
00007f828abdb9d6  lea r14, [rax+0x30]
00007f828abdb9da  mov r12, [r13+r14*1]
00007f828abdb9df  lea r14, [rax+0x38]
00007f828abdb9e3  mov r11, [r13+r14*1]
00007f828abdb9e8  movq xmm13, r12
00007f828abdb9ed  movq xmm12, r11
00007f828abdb9f2  movq xmm13, xmm13
00007f828abdb9f7  vmovaps [rsp+0x10], xmm13
00007f828abdb9fd  movq xmm13, xmm13
00007f828abdba02  movaps [r15+0x130], xmm13
00007f828abdba0a  movq xmm12, xmm12
00007f828abdba0f  vmovaps [rsp+0x20], xmm12
00007f828abdba15  movq xmm12, xmm12
00007f828abdba1a  movaps [r15+0x280], xmm12
00007f828abdba22  movaps xmm13, [r15+0x270]
00007f828abdba2a  vmovaps [rsp+0x30], xmm13
00007f828abdba30  vmovaps xmm12, [rsp+0x30]
00007f828abdba36  por xmm13, xmm12
00007f828abdba3b  lea r14, [rax+0x20]
00007f828abdba3f  mov r12, [r13+r14*1]
00007f828abdba44  lea r14, [rax+0x28]
00007f828abdba48  mov r11, [r13+r14*1]
00007f828abdba4d  movq xmm12, r12
00007f828abdba52  movq xmm11, r11
00007f828abdba57  movq xmm12, xmm12
00007f828abdba5c  vmovaps [rsp+0x30], xmm12
00007f828abdba62  movq xmm12, xmm12
00007f828abdba67  movaps [r15+0x150], xmm12
00007f828abdba6f  movq xmm11, xmm11
00007f828abdba74  vmovaps [rsp+0x40], xmm11
00007f828abdba7a  movq xmm11, xmm11
00007f828abdba7f  movaps [r15+0x140], xmm11
00007f828abdba87  lea r14, [rax+0x10]
00007f828abdba8b  mov r12, [r13+r14*1]
00007f828abdba90  lea r14, [rax+0x18]
00007f828abdba94  mov r11, [r13+r14*1]
00007f828abdba99  movq xmm12, r12
00007f828abdba9e  movq xmm11, r11
00007f828abdbaa3  movq xmm12, xmm12
00007f828abdbaa8  vmovaps [rsp+0x50], xmm12
00007f828abdbaae  movq xmm12, xmm12
00007f828abdbab3  movaps [r15+0x170], xmm12
00007f828abdbabb  movq xmm11, xmm11
00007f828abdbac0  vmovaps [rsp+0x60], xmm11
00007f828abdbac6  movq xmm11, xmm11
00007f828abdbacb  movaps [r15+0x160], xmm11
00007f828abdbad3  mov r14, [r13+rax*1]
00007f828abdbad8  vmovq xmm12, r14
00007f828abdbadd  vpbroadcastq xmm12, xmm12
00007f828abdbae2  lea r14, [rax+0x08]
00007f828abdbae6  mov rax, [r13+r14*1]
00007f828abdbaeb  movq xmm11, rax
00007f828abdbaf0  movaps [r15+0x230], xmm11
00007f828abdbaf8  mov rax, [r15+0xF8]
00007f828abdbaff  lea r14, [rax+0x50]
00007f828abdbb03  movups xmm11, [r13+r14*1]
00007f828abdbb09  lea r14, [rax+0x60]
00007f828abdbb0d  movups xmm10, [r13+r14*1]
00007f828abdbb13  lea r14, [rax+0x30]
00007f828abdbb17  movups xmm9, [r13+r14*1]
00007f828abdbb1d  mov r14, [r15+0x50]
00007f828abdbb21  mov [r15+0x60], r14
00007f828abdbb25  mov qword ptr [r15+0x58], 0x40
00007f828abdbb2d  movaps xmm8, xmm12
00007f828abdbb31  mulpd xmm8, xmm15
00007f828abdbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007f828abdbb3c  ptest xmm7, xmm7
00007f828abdbb41  jnz 0x00007F828ABDC96A
00007f828abdbb47  movq xmm15, qword ptr [r15+0x230]
00007f828abdbb50  vmovaps [rsp+0x70], xmm15
00007f828abdbb56  vpermilpd xmm15, xmm15, 0x00
00007f828abdbb5c  movaps xmm7, xmm9
00007f828abdbb60  mulpd xmm7, xmm15
00007f828abdbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007f828abdbb6a  ptest xmm6, xmm6
00007f828abdbb6f  jnz 0x00007F828ABDCAAE
00007f828abdbb75  vxorps xmm15, xmm15, xmm15
00007f828abdbb7a  vpbroadcastq xmm15, xmm15
00007f828abdbb7f  movaps xmm9, xmm12
00007f828abdbb83  mulpd xmm9, xmm10
00007f828abdbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007f828abdbb8e  ptest xmm6, xmm6
00007f828abdbb93  jnz 0x00007F828ABDCBF0
00007f828abdbb99  movaps xmm10, xmm12
00007f828abdbb9d  mulpd xmm10, xmm11
00007f828abdbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007f828abdbba8  ptest xmm6, xmm6
00007f828abdbbad  jnz 0x00007F828ABDCD34
00007f828abdbbb3  movaps xmm11, [r15+0x1F0]
00007f828abdbbbb  movaps xmm6, xmm12
00007f828abdbbbf  mulpd xmm6, xmm11
00007f828abdbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007f828abdbbc9  ptest xmm5, xmm5
00007f828abdbbce  jnz 0x00007F828ABDCE78
00007f828abdbbd4  movaps xmm12, [r15+0x2A0]
00007f828abdbbdc  vmovaps [rsp+0x80], xmm12
00007f828abdbbe5  vmovaps xmm11, [rsp+0x80]
00007f828abdbbee  por xmm12, xmm11
00007f828abdbbf3  movaps xmm11, [r15+0x250]
00007f828abdbbfb  vmovaps [rsp+0x80], xmm11
00007f828abdbc04  vmovaps xmm5, [rsp+0x80]
00007f828abdbc0d  por xmm11, xmm5
00007f828abdbc12  vmovaps xmm4, [rsp+0x70]
00007f828abdbc18  vpermilpd xmm4, xmm4, 0x00
00007f828abdbc1e  movaps xmm3, xmm5
00007f828abdbc21  mulpd xmm3, xmm4
00007f828abdbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007f828abdbc2a  ptest xmm2, xmm2
00007f828abdbc2f  jnz 0x00007F828ABDCFBA
00007f828abdbc35  mov [rsp+0x80], rax
00007f828abdbc3d  xor eax, eax
00007f828abdbc3f  mov r12d, 0x40
00007f828abdbc45  mov r11d, 0x200
00007f828abdbc4b  cmp r12, r11
00007f828abdbc4e  cmc
00007f828abdbc4f  lahf
00007f828abdbc50  seto al
00007f828abdbc53  mov [r15+0x108], eax
00007f828abdbc5a  movaps xmm5, xmm8
00007f828abdbc5e  addpd xmm5, xmm15
00007f828abdbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007f828abdbc68  ptest xmm4, xmm4
00007f828abdbc6d  jnz 0x00007F828ABDD0FA
00007f828abdbc73  movaps xmm8, [r15+0x1B0]
00007f828abdbc7b  movaps xmm4, xmm9
00007f828abdbc7f  addpd xmm4, xmm8
00007f828abdbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007f828abdbc89  ptest xmm2, xmm2
00007f828abdbc8e  jnz 0x00007F828ABDD23C
00007f828abdbc94  movaps xmm9, xmm10
00007f828abdbc98  addpd xmm9, xmm8
00007f828abdbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007f828abdbca3  ptest xmm2, xmm2
00007f828abdbca8  jnz 0x00007F828ABDD37E
00007f828abdbcae  movaps xmm10, [r15+0x2F0]
00007f828abdbcb6  vmovaps [rsp+0x90], xmm10
00007f828abdbcbf  vmovaps xmm8, [rsp+0x90]
00007f828abdbcc8  por xmm10, xmm8
00007f828abdbccd  movaps xmm8, [r15+0x2E0]
00007f828abdbcd5  vmovaps [rsp+0x90], xmm8
00007f828abdbcde  vmovaps xmm2, [rsp+0x90]
00007f828abdbce7  por xmm8, xmm2
00007f828abdbcec  movaps xmm2, [r15+0x2D0]
00007f828abdbcf4  vmovaps [rsp+0x90], xmm2
00007f828abdbcfd  vmovaps [rsp+0xA0], xmm1
00007f828abdbd06  vmovaps xmm1, [rsp+0x90]
00007f828abdbd0f  por xmm2, xmm1
00007f828abdbd13  movaps xmm1, [r15+0x200]
00007f828abdbd1b  vmovaps [rsp+0x90], xmm1
00007f828abdbd24  vmovaps [rsp+0xB0], xmm15
00007f828abdbd2d  vmovaps xmm15, [rsp+0x90]
00007f828abdbd36  por xmm1, xmm15
00007f828abdbd3b  movaps xmm15, [r15+0x1C0]
00007f828abdbd43  vmovaps [rsp+0x90], xmm15
00007f828abdbd4c  vmovaps [rsp+0xC0], xmm1
00007f828abdbd55  vmovaps xmm1, [rsp+0x90]
00007f828abdbd5e  por xmm15, xmm1
00007f828abdbd63  movaps xmm1, [r15+0x190]
00007f828abdbd6b  vmovaps [rsp+0x90], xmm1
00007f828abdbd74  vmovaps [rsp+0xD0], xmm15
00007f828abdbd7d  vmovaps xmm15, [rsp+0x90]
00007f828abdbd86  por xmm1, xmm15
00007f828abdbd8b  movaps xmm15, [r15+0x300]
00007f828abdbd93  vmovaps [rsp+0x90], xmm15
00007f828abdbd9c  vmovaps [rsp+0xE0], xmm1
00007f828abdbda5  vmovaps xmm1, [rsp+0x90]
00007f828abdbdae  por xmm15, xmm1
00007f828abdbdb3  mov rax, [rsp+0x80]
00007f828abdbdbb  lea r12, [rax+0xA0]
00007f828abdbdc2  movups xmm1, [r13+r12*1]
00007f828abdbdc8  lea r12, [rax+0xB0]
00007f828abdbdcf  vmovaps [rsp+0x80], xmm1
00007f828abdbdd8  movups xmm1, [r13+r12*1]
00007f828abdbdde  vmovaps [rsp+0x90], xmm1
00007f828abdbde7  vmovaps [rsp+0xF0], xmm15
00007f828abdbdf0  vmovaps xmm15, [rsp+0xB0]
00007f828abdbdf9  vmovaps [rsp+0xB0], xmm14
00007f828abdbe02  movaps xmm1, xmm6
00007f828abdbe05  addpd xmm1, xmm15
00007f828abdbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007f828abdbe0f  ptest xmm14, xmm14
00007f828abdbe15  jnz 0x00007F828ABDD4D6
00007f828abdbe1b  lea r12, [rax+0xF0]
00007f828abdbe22  movups xmm15, [r13+r12*1]
00007f828abdbe28  movaps xmm14, xmm4
00007f828abdbe2c  addpd xmm14, xmm3
00007f828abdbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007f828abdbe37  ptest xmm6, xmm6
00007f828abdbe3c  jnz 0x00007F828ABDD621
00007f828abdbe42  movaps xmm6, xmm9
00007f828abdbe46  addpd xmm6, xmm7
00007f828abdbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007f828abdbe4f  ptest xmm4, xmm4
00007f828abdbe54  jnz 0x00007F828ABDD763
00007f828abdbe5a  vmovaps xmm9, [rsp+0x70]
00007f828abdbe60  vpermilpd xmm9, xmm9, 0x00
00007f828abdbe66  vmovaps xmm4, [rsp+0x90]
00007f828abdbe6f  movaps xmm7, xmm4
00007f828abdbe72  mulpd xmm7, xmm9
00007f828abdbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007f828abdbe7c  ptest xmm3, xmm3
00007f828abdbe81  jnz 0x00007F828ABDD8A4
00007f828abdbe87  vmovaps xmm9, [rsp+0x50]
00007f828abdbe8d  vpermilpd xmm9, xmm9, 0x00
00007f828abdbe93  movaps xmm4, xmm15
00007f828abdbe97  mulpd xmm4, xmm9
00007f828abdbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007f828abdbea1  ptest xmm3, xmm3
00007f828abdbea6  jnz 0x00007F828ABDD9E5
00007f828abdbeac  lea r12, [rax+0xE0]
00007f828abdbeb3  movups xmm15, [r13+r12*1]
00007f828abdbeb9  vmovaps xmm9, [rsp+0x70]
00007f828abdbebf  vpermilpd xmm9, xmm9, 0x00
00007f828abdbec5  vmovaps [rsp+0x70], xmm1
00007f828abdbecb  vmovaps xmm1, [rsp+0x80]
00007f828abdbed4  vmovaps [rsp+0x80], xmm15
00007f828abdbedd  movaps xmm3, xmm1
00007f828abdbee0  mulpd xmm3, xmm9
00007f828abdbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007f828abdbeea  ptest xmm15, xmm15
00007f828abdbef0  jnz 0x00007F828ABDDB31
00007f828abdbef6  vmovaps xmm1, [rsp+0xF0]
00007f828abdbeff  vmovaps xmm15, [rsp+0xF0]
00007f828abdbf08  por xmm1, xmm15
00007f828abdbf0d  movaps [r15+0x300], xmm1
00007f828abdbf15  vmovaps xmm15, [rsp+0xE0]
00007f828abdbf1e  vmovaps xmm9, [rsp+0xE0]
00007f828abdbf27  por xmm15, xmm9
00007f828abdbf2c  movaps [r15+0x190], xmm15
00007f828abdbf34  vmovaps xmm9, [rsp+0x50]
00007f828abdbf3a  vpermilpd xmm9, xmm9, 0x00
00007f828abdbf40  vmovaps [rsp+0x90], xmm1
00007f828abdbf49  vmovaps [rsp+0xE0], xmm15
00007f828abdbf52  vmovaps xmm15, [rsp+0x80]
00007f828abdbf5b  vmovaps [rsp+0x80], xmm14
00007f828abdbf64  movaps xmm1, xmm15
00007f828abdbf68  mulpd xmm1, xmm9
00007f828abdbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007f828abdbf72  ptest xmm14, xmm14
00007f828abdbf78  jnz 0x00007F828ABDDC72
00007f828abdbf7e  lea r12, [rax+0x90]
00007f828abdbf85  movups xmm15, [r13+r12*1]
00007f828abdbf8b  vmovaps xmm14, [rsp+0xD0]
00007f828abdbf94  vmovaps xmm9, [rsp+0xD0]
00007f828abdbf9d  por xmm14, xmm9
00007f828abdbfa2  movaps [r15+0x1C0], xmm14
00007f828abdbfaa  vmovaps xmm9, [rsp+0xC0]
00007f828abdbfb3  vmovaps [rsp+0xD0], xmm1
00007f828abdbfbc  vmovaps xmm1, [rsp+0xC0]
00007f828abdbfc5  por xmm9, xmm1
00007f828abdbfca  movaps [r15+0x200], xmm9
00007f828abdbfd2  vmovaps [rsp+0xC0], xmm2
00007f828abdbfdb  vmovaps xmm1, [rsp+0xC0]
00007f828abdbfe4  por xmm2, xmm1
00007f828abdbfe8  movaps [r15+0x2D0], xmm2
00007f828abdbff0  vmovaps [rsp+0xC0], xmm8
00007f828abdbff9  vmovaps xmm1, [rsp+0xC0]
00007f828abdc002  por xmm8, xmm1
00007f828abdc007  movaps [r15+0x2E0], xmm8
00007f828abdc00f  vmovaps [rsp+0xC0], xmm15
00007f828abdc018  movaps xmm1, xmm5
00007f828abdc01b  addpd xmm1, xmm7
00007f828abdc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007f828abdc024  ptest xmm15, xmm15
00007f828abdc02a  jnz 0x00007F828ABDDDBE
00007f828abdc030  vmovaps xmm15, [rsp+0x50]
00007f828abdc036  vpermilpd xmm15, xmm15, 0x00
00007f828abdc03c  vmovaps xmm5, [rsp+0xC0]
00007f828abdc045  vmovaps [rsp+0xC0], xmm1
00007f828abdc04e  movaps xmm7, xmm5
00007f828abdc051  mulpd xmm7, xmm15
00007f828abdc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007f828abdc05b  ptest xmm1, xmm1
00007f828abdc060  jnz 0x00007F828ABDDEFE
00007f828abdc066  lea r12, [rax+0x80]
00007f828abdc06d  movups xmm1, [r13+r12*1]
00007f828abdc073  vmovaps xmm5, [rsp+0x70]
00007f828abdc079  vmovaps [rsp+0x70], xmm1
00007f828abdc07f  movaps xmm15, xmm5
00007f828abdc083  addpd xmm15, xmm3
00007f828abdc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007f828abdc08e  ptest xmm1, xmm1
00007f828abdc093  jnz 0x00007F828ABDE049
00007f828abdc099  vmovaps xmm5, [rsp+0x80]
00007f828abdc0a2  movaps xmm1, xmm5
00007f828abdc0a5  addpd xmm1, xmm4
00007f828abdc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007f828abdc0ae  ptest xmm3, xmm3
00007f828abdc0b3  jnz 0x00007F828ABDE18B
00007f828abdc0b9  vmovaps [rsp+0x80], xmm10
00007f828abdc0c2  vmovaps xmm5, [rsp+0x80]
00007f828abdc0cb  por xmm10, xmm5
00007f828abdc0d0  movaps [r15+0x2F0], xmm10
00007f828abdc0d8  vmovaps xmm5, [rsp+0x50]
00007f828abdc0de  vpermilpd xmm5, xmm5, 0x00
00007f828abdc0e4  vmovaps xmm3, [rsp+0x70]
00007f828abdc0ea  vmovaps [rsp+0x50], xmm1
00007f828abdc0f0  movaps xmm4, xmm3
00007f828abdc0f3  mulpd xmm4, xmm5
00007f828abdc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007f828abdc0fc  ptest xmm1, xmm1
00007f828abdc101  jnz 0x00007F828ABDE2CB
00007f828abdc107  lea r12, [rax+0xD0]
00007f828abdc10e  movups xmm1, [r13+r12*1]
00007f828abdc114  vmovaps xmm3, [rsp+0xD0]
00007f828abdc11d  vmovaps [rsp+0x70], xmm1
00007f828abdc123  movaps xmm5, xmm6
00007f828abdc126  addpd xmm5, xmm3
00007f828abdc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007f828abdc12f  ptest xmm1, xmm1
00007f828abdc134  jnz 0x00007F828ABDE415
00007f828abdc13a  vmovaps xmm1, [rsp+0x60]
00007f828abdc140  vpermilpd xmm1, xmm1, 0x00
00007f828abdc146  movaps xmm6, xmm9
00007f828abdc14a  mulpd xmm6, xmm1
00007f828abdc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007f828abdc153  ptest xmm3, xmm3
00007f828abdc158  jnz 0x00007F828ABDE555
00007f828abdc15e  movaps [r15+0x260], xmm6
00007f828abdc166  vxorps xmm1, xmm1, xmm1
00007f828abdc16a  vpbroadcastq xmm1, xmm1
00007f828abdc16f  movaps [r15+0x1B0], xmm1
00007f828abdc177  vmovaps xmm1, [rsp+0x60]
00007f828abdc17d  vpermilpd xmm1, xmm1, 0x00
00007f828abdc183  vmovaps xmm3, [rsp+0x70]
00007f828abdc189  vmovaps [rsp+0x70], xmm15
00007f828abdc18f  movaps xmm9, xmm3
00007f828abdc193  mulpd xmm9, xmm1
00007f828abdc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007f828abdc19e  ptest xmm15, xmm15
00007f828abdc1a4  jnz 0x00007F828ABDE696
00007f828abdc1aa  lea r12, [rax+0xC0]
00007f828abdc1b1  movups xmm1, [r13+r12*1]
00007f828abdc1b7  vmovaps xmm3, [rsp+0xC0]
00007f828abdc1c0  vmovaps [rsp+0x80], xmm1
00007f828abdc1c9  movaps xmm15, xmm3
00007f828abdc1cd  addpd xmm15, xmm7
00007f828abdc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007f828abdc1d8  ptest xmm1, xmm1
00007f828abdc1dd  jnz 0x00007F828ABDE7E2
00007f828abdc1e3  vmovaps [rsp+0xC0], xmm13
00007f828abdc1ec  vmovaps xmm1, [rsp+0xC0]
00007f828abdc1f5  por xmm13, xmm1
00007f828abdc1fa  movaps [r15+0x270], xmm13
00007f828abdc202  vmovaps xmm1, [rsp+0xB0]
00007f828abdc20b  vmovaps xmm7, [rsp+0xB0]
00007f828abdc214  por xmm1, xmm7
00007f828abdc218  movaps [r15+0x1A0], xmm1
00007f828abdc220  vmovaps xmm1, [rsp+0x60]
00007f828abdc226  vpermilpd xmm1, xmm1, 0x00
00007f828abdc22c  vmovaps [rsp+0xB0], xmm1
00007f828abdc235  vmovaps xmm1, [rsp+0x80]
00007f828abdc23e  vmovaps [rsp+0x80], xmm15
00007f828abdc247  vmovaps xmm15, [rsp+0xB0]
00007f828abdc250  vmovaps [rsp+0xB0], xmm14
00007f828abdc259  movaps xmm3, xmm1
00007f828abdc25c  mulpd xmm3, xmm15
00007f828abdc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007f828abdc266  ptest xmm14, xmm14
00007f828abdc26c  jnz 0x00007F828ABDE924
00007f828abdc272  lea r12, [rax+0x20]
00007f828abdc276  movups xmm1, [r13+r12*1]
00007f828abdc27c  movaps [r15+0x110], xmm1
00007f828abdc284  vmovaps xmm14, [rsp+0x70]
00007f828abdc28a  vmovaps [rsp+0x70], xmm1
00007f828abdc290  movaps xmm15, xmm14
00007f828abdc294  addpd xmm15, xmm4
00007f828abdc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007f828abdc29f  ptest xmm1, xmm1
00007f828abdc2a4  jnz 0x00007F828ABDEA6F
00007f828abdc2aa  vmovaps xmm1, [rsp+0x60]
00007f828abdc2b0  vpermilpd xmm1, xmm1, 0x00
00007f828abdc2b6  movaps xmm14, xmm2
00007f828abdc2ba  mulpd xmm14, xmm1
00007f828abdc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007f828abdc2c5  ptest xmm4, xmm4
00007f828abdc2ca  jnz 0x00007F828ABDEBB2
00007f828abdc2d0  vmovaps xmm4, [rsp+0x50]
00007f828abdc2d6  movaps xmm1, xmm4
00007f828abdc2d9  addpd xmm1, xmm9
00007f828abdc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007f828abdc2e3  ptest xmm2, xmm2
00007f828abdc2e8  jnz 0x00007F828ABDECF4
00007f828abdc2ee  vmovaps xmm9, [rsp+0x30]
00007f828abdc2f4  vpermilpd xmm9, xmm9, 0x00
00007f828abdc2fa  vmovaps xmm2, [rsp+0x70]
00007f828abdc300  vmovaps [rsp+0x50], xmm1
00007f828abdc306  movaps xmm4, xmm2
00007f828abdc309  mulpd xmm4, xmm9
00007f828abdc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007f828abdc313  ptest xmm1, xmm1
00007f828abdc318  jnz 0x00007F828ABDEE35
00007f828abdc31e  vmovaps xmm1, [rsp+0x30]
00007f828abdc324  vpermilpd xmm1, xmm1, 0x00
00007f828abdc32a  vmovaps xmm2, [rsp+0x90]
00007f828abdc333  vmovaps [rsp+0x60], xmm15
00007f828abdc339  movaps xmm9, xmm2
00007f828abdc33d  mulpd xmm9, xmm1
00007f828abdc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007f828abdc348  ptest xmm15, xmm15
00007f828abdc34e  jnz 0x00007F828ABDEF76
00007f828abdc354  vmovaps xmm15, [rsp+0x80]
00007f828abdc35d  movaps xmm1, xmm15
00007f828abdc361  addpd xmm1, xmm6
00007f828abdc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007f828abdc36a  ptest xmm2, xmm2
00007f828abdc36f  jnz 0x00007F828ABDF0B8
00007f828abdc375  movaps xmm15, xmm5
00007f828abdc379  addpd xmm15, xmm3
00007f828abdc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007f828abdc384  ptest xmm6, xmm6
00007f828abdc389  jnz 0x00007F828ABDF1F9
00007f828abdc38f  vmovaps xmm6, [rsp+0x30]
00007f828abdc395  vpermilpd xmm6, xmm6, 0x00
00007f828abdc39b  movaps xmm5, xmm8
00007f828abdc39f  mulpd xmm5, xmm6
00007f828abdc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007f828abdc3a8  ptest xmm3, xmm3
00007f828abdc3ad  jnz 0x00007F828ABDF33B
00007f828abdc3b3  vmovaps xmm8, [rsp+0x30]
00007f828abdc3b9  vpermilpd xmm8, xmm8, 0x00
00007f828abdc3bf  movaps xmm6, xmm10
00007f828abdc3c3  mulpd xmm6, xmm8
00007f828abdc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007f828abdc3cd  ptest xmm3, xmm3
00007f828abdc3d2  jnz 0x00007F828ABDF47C
00007f828abdc3d8  vmovaps xmm8, [rsp+0x60]
00007f828abdc3de  movaps xmm10, xmm8
00007f828abdc3e2  addpd xmm10, xmm14
00007f828abdc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007f828abdc3ed  ptest xmm3, xmm3
00007f828abdc3f2  jnz 0x00007F828ABDF5BE
00007f828abdc3f8  vmovaps xmm8, [rsp+0x50]
00007f828abdc3fe  movaps xmm14, xmm8
00007f828abdc402  addpd xmm14, xmm4
00007f828abdc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007f828abdc40d  ptest xmm3, xmm3
00007f828abdc412  jnz 0x00007F828ABDF702
00007f828abdc418  vmovaps xmm8, [rsp+0x40]
00007f828abdc41e  vpermilpd xmm8, xmm8, 0x00
00007f828abdc424  movaps xmm4, xmm13
00007f828abdc428  mulpd xmm4, xmm8
00007f828abdc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007f828abdc432  ptest xmm3, xmm3
00007f828abdc437  jnz 0x00007F828ABDF845
00007f828abdc43d  movaps xmm13, xmm15
00007f828abdc441  addpd xmm13, xmm9
00007f828abdc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007f828abdc44c  ptest xmm8, xmm8
00007f828abdc452  jnz 0x00007F828ABDF987
00007f828abdc458  movaps xmm15, xmm1
00007f828abdc45c  addpd xmm15, xmm5
00007f828abdc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007f828abdc467  ptest xmm9, xmm9
00007f828abdc46d  jnz 0x00007F828ABDFACB
00007f828abdc473  vmovaps [rsp+0x30], xmm11
00007f828abdc479  vmovaps xmm1, [rsp+0x30]
00007f828abdc47f  por xmm11, xmm1
00007f828abdc484  movaps [r15+0x250], xmm11
00007f828abdc48c  vmovaps [rsp+0x30], xmm12
00007f828abdc492  vmovaps xmm1, [rsp+0x30]
00007f828abdc498  por xmm12, xmm1
00007f828abdc49d  movaps [r15+0x2A0], xmm12
00007f828abdc4a5  vmovaps xmm1, [rsp+0xA0]
00007f828abdc4ae  vmovaps xmm11, [rsp+0xA0]
00007f828abdc4b7  por xmm1, xmm11
00007f828abdc4bc  movaps [r15+0x1D0], xmm1
00007f828abdc4c4  lea r12, [rax+0x40]
00007f828abdc4c8  movups xmm1, [r13+r12*1]
00007f828abdc4ce  movaps [r15+0x2C0], xmm1
00007f828abdc4d6  vmovaps xmm11, [rsp+0x40]
00007f828abdc4dc  vpermilpd xmm11, xmm11, 0x00
00007f828abdc4e2  vmovaps xmm8, [rsp+0xE0]
00007f828abdc4eb  movaps xmm9, xmm8
00007f828abdc4ef  mulpd xmm9, xmm11
00007f828abdc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007f828abdc4fa  ptest xmm5, xmm5
00007f828abdc4ff  jnz 0x00007F828ABDFC17
00007f828abdc505  movaps xmm11, xmm10
00007f828abdc509  addpd xmm11, xmm6
00007f828abdc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007f828abdc514  ptest xmm8, xmm8
00007f828abdc51a  jnz 0x00007F828ABDFD5B
00007f828abdc520  movaps xmm10, xmm14
00007f828abdc524  addpd xmm10, xmm4
00007f828abdc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007f828abdc52f  ptest xmm8, xmm8
00007f828abdc535  jnz 0x00007F828ABDFE9E
00007f828abdc53b  vmovaps xmm14, [rsp+0x40]
00007f828abdc541  vpermilpd xmm14, xmm14, 0x00
00007f828abdc547  movaps xmm8, xmm1
00007f828abdc54b  mulpd xmm8, xmm14
00007f828abdc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007f828abdc556  ptest xmm6, xmm6
00007f828abdc55b  jnz 0x00007F828ABDFFE1
00007f828abdc561  movaps xmm1, [r15+0x2B0]
00007f828abdc569  vmovaps xmm14, [rsp+0x40]
00007f828abdc56f  vpermilpd xmm14, xmm14, 0x00
00007f828abdc575  movaps xmm6, xmm1
00007f828abdc578  mulpd xmm6, xmm14
00007f828abdc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007f828abdc582  ptest xmm5, xmm5
00007f828abdc587  jnz 0x00007F828ABE0124
00007f828abdc58d  vmovaps xmm1, [rsp+0x10]
00007f828abdc593  vpermilpd xmm1, xmm1, 0x00
00007f828abdc599  movaps xmm14, xmm12
00007f828abdc59d  mulpd xmm14, xmm1
00007f828abdc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007f828abdc5a8  ptest xmm5, xmm5
00007f828abdc5ad  jnz 0x00007F828ABE0265
00007f828abdc5b3  movaps xmm1, xmm13
00007f828abdc5b7  addpd xmm1, xmm9
00007f828abdc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007f828abdc5c1  ptest xmm12, xmm12
00007f828abdc5c7  jnz 0x00007F828ABE03A8
00007f828abdc5cd  vmovaps xmm13, [rsp+0x10]
00007f828abdc5d3  vpermilpd xmm13, xmm13, 0x00
00007f828abdc5d9  movaps xmm12, xmm7
00007f828abdc5dd  mulpd xmm12, xmm13
00007f828abdc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007f828abdc5e8  ptest xmm9, xmm9
00007f828abdc5ee  jnz 0x00007F828ABE04EA
00007f828abdc5f4  movaps xmm13, xmm15
00007f828abdc5f8  addpd xmm13, xmm8
00007f828abdc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007f828abdc603  ptest xmm9, xmm9
00007f828abdc609  jnz 0x00007F828ABE062D
00007f828abdc60f  movaps xmm15, [r15+0x290]
00007f828abdc617  vmovaps xmm9, [rsp+0x10]
00007f828abdc61d  vpermilpd xmm9, xmm9, 0x00
00007f828abdc623  movaps xmm8, xmm15
00007f828abdc627  mulpd xmm8, xmm9
00007f828abdc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007f828abdc632  ptest xmm7, xmm7
00007f828abdc637  jnz 0x00007F828ABE0771
00007f828abdc63d  movaps xmm15, xmm11
00007f828abdc641  addpd xmm15, xmm6
00007f828abdc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007f828abdc64c  ptest xmm9, xmm9
00007f828abdc652  jnz 0x00007F828ABE08B5
00007f828abdc658  movaps xmm11, [r15+0x1E0]
00007f828abdc660  vmovaps xmm9, [rsp+0x10]
00007f828abdc666  vpermilpd xmm9, xmm9, 0x00
00007f828abdc66c  movaps xmm7, xmm11
00007f828abdc670  mulpd xmm7, xmm9
00007f828abdc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007f828abdc67a  ptest xmm6, xmm6
00007f828abdc67f  jnz 0x00007F828ABE09F8
00007f828abdc685  movaps xmm11, xmm10
00007f828abdc689  addpd xmm11, xmm14
00007f828abdc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007f828abdc694  ptest xmm9, xmm9
00007f828abdc69a  jnz 0x00007F828ABE0B3A
00007f828abdc6a0  lea r12, [rax+0x70]
00007f828abdc6a4  movups xmm14, [r13+r12*1]
00007f828abdc6aa  movaps [r15+0x240], xmm14
00007f828abdc6b2  movaps xmm10, xmm1
00007f828abdc6b6  addpd xmm10, xmm12
00007f828abdc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007f828abdc6c1  ptest xmm9, xmm9
00007f828abdc6c7  jnz 0x00007F828ABE0C88
00007f828abdc6cd  movaps [r15+0x170], xmm10
00007f828abdc6d5  vmovaps xmm1, [rsp+0x20]
00007f828abdc6db  vpermilpd xmm1, xmm1, 0x00
00007f828abdc6e1  movaps xmm12, xmm14
00007f828abdc6e5  mulpd xmm12, xmm1
00007f828abdc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007f828abdc6f0  ptest xmm9, xmm9
00007f828abdc6f6  jnz 0x00007F828ABE0DCB
00007f828abdc6fc  vmovaps xmm1, [rsp+0x20]
00007f828abdc702  vpermilpd xmm1, xmm1, 0x00
00007f828abdc708  vmovaps xmm9, [rsp+0xB0]
00007f828abdc711  movaps xmm14, xmm9
00007f828abdc715  mulpd xmm14, xmm1
00007f828abdc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007f828abdc720  ptest xmm6, xmm6
00007f828abdc725  jnz 0x00007F828ABE0F0E
00007f828abdc72b  movaps [r15+0x180], xmm14
00007f828abdc733  movaps xmm1, xmm13
00007f828abdc737  addpd xmm1, xmm8
00007f828abdc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007f828abdc741  ptest xmm9, xmm9
00007f828abdc747  jnz 0x00007F828ABE1051
00007f828abdc74d  movaps [r15+0x210], xmm1
00007f828abdc755  movups xmm13, [r13+rax*1]
00007f828abdc75b  lea r12, [rax+0x10]
00007f828abdc75f  movups xmm9, [r13+r12*1]
00007f828abdc765  movaps [r15+0x230], xmm9
00007f828abdc76d  movaps xmm8, xmm15
00007f828abdc771  addpd xmm8, xmm7
00007f828abdc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007f828abdc77c  ptest xmm6, xmm6
00007f828abdc781  jnz 0x00007F828ABE11A7
00007f828abdc787  movaps [r15+0x130], xmm8
00007f828abdc78f  vmovaps xmm15, [rsp+0x20]
00007f828abdc795  vpermilpd xmm15, xmm15, 0x00
00007f828abdc79b  movaps xmm7, xmm9
00007f828abdc79f  mulpd xmm7, xmm15
00007f828abdc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007f828abdc7a9  ptest xmm6, xmm6
00007f828abdc7ae  jnz 0x00007F828ABE12EA
00007f828abdc7b4  movaps [r15+0x220], xmm7
00007f828abdc7bc  vmovaps xmm15, [rsp+0x20]
00007f828abdc7c2  vpermilpd xmm15, xmm15, 0x00
00007f828abdc7c8  movaps xmm9, xmm13
00007f828abdc7cc  mulpd xmm9, xmm15
00007f828abdc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007f828abdc7d7  ptest xmm6, xmm6
00007f828abdc7dc  jnz 0x00007F828ABE142C
00007f828abdc7e2  movaps xmm15, xmm11
00007f828abdc7e6  addpd xmm15, xmm12
00007f828abdc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007f828abdc7f1  ptest xmm13, xmm13
00007f828abdc7f7  jnz 0x00007F828ABE1570
00007f828abdc7fd  movaps [r15+0x140], xmm15
00007f828abdc805  movaps xmm13, xmm10
00007f828abdc809  addpd xmm13, xmm14
00007f828abdc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007f828abdc814  ptest xmm12, xmm12
00007f828abdc81a  jnz 0x00007F828ABE16B4
00007f828abdc820  movaps [r15+0x150], xmm13
00007f828abdc828  movaps xmm14, xmm1
00007f828abdc82c  addpd xmm14, xmm7
00007f828abdc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007f828abdc837  ptest xmm12, xmm12
00007f828abdc83d  jnz 0x00007F828ABE17F8
00007f828abdc843  movaps [r15+0x160], xmm14
00007f828abdc84b  movaps xmm1, xmm8
00007f828abdc84f  addpd xmm1, xmm9
00007f828abdc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007f828abdc859  ptest xmm12, xmm12
00007f828abdc85f  jnz 0x00007F828ABE193A
00007f828abdc865  movaps [r15+0x120], xmm1
00007f828abdc86d  movups [r13+r14*1], xmm15
00007f828abdc873  lea rax, [r14+0x10]
00007f828abdc877  movups [r13+rax*1], xmm13
00007f828abdc87d  lea rax, [r14+0x20]
00007f828abdc881  movups [r13+rax*1], xmm14
00007f828abdc887  lea rax, [r14+0x30]
00007f828abdc88b  movups [r13+rax*1], xmm1
00007f828abdc891  mov eax, [r15+0x108]
00007f828abdc898  sahf
00007f828abdc899  jnz 0x00007F828ABDC8CB
00007f828abdc89b  cmp dword ptr [r15+0x318], 0x00
00007f828abdc8a3  jz 0x00007F828ABDB900
00007f828abdc8a9  nop [rax+rax*1], ax
00007f828abdc8b2  nop [rax+rax*1], eax
00007f828abdc8ba  mov eax, 0x410444
00007f828abdc8bf  mov [r15+0x100], rax
00007f828abdc8c6  jmp 0x00007F828A9FE110
00007f828abdc8cb  cmp dword ptr [r15+0x318], 0x00
00007f828abdc8d3  jz 0x00007F828ABD57E0
00007f828abdc8d9  nop [rax+rax*1], ax
00007f828abdc8e2  nop [rax+rax*1], eax
00007f828abdc8ea  mov eax, 0x410278
00007f828abdc8ef  mov [r15+0x100], rax
00007f828abdc8f6  jmp 0x00007F828A9FE110
00007f828abdc8fb  int3
00007f828abdc8fc  call 0x00007F828AAE27E0
00007f828abdc901  jmp 0x00007F828ABDB9DF
00007f828abdc906  call 0x00007F828AAE1570
00007f828abdc90b  jmp 0x00007F828ABDB9E8
00007f828abdc910  call 0x00007F828AAE27E0
00007f828abdc915  jmp 0x00007F828ABDBA44
00007f828abdc91a  call 0x00007F828AAE1570
00007f828abdc91f  jmp 0x00007F828ABDBA4D
00007f828abdc924  call 0x00007F828AAE27E0
00007f828abdc929  jmp 0x00007F828ABDBA90
00007f828abdc92e  call 0x00007F828AAE1570
00007f828abdc933  jmp 0x00007F828ABDBA99
00007f828abdc938  call 0x00007F828AA0DC20
00007f828abdc93d  jmp 0x00007F828ABDBAD8
00007f828abdc942  call 0x00007F828AAD59C0
00007f828abdc947  jmp 0x00007F828ABDBAEB
00007f828abdc94c  call 0x00007F828AAE0E30
00007f828abdc951  jmp 0x00007F828ABDBB09
00007f828abdc956  call 0x00007F828AADFBC0
00007f828abdc95b  jmp 0x00007F828ABDBB13
00007f828abdc960  call 0x00007F828AADE950
00007f828abdc965  jmp 0x00007F828ABDBB1D
00007f828abdc96a  sub rsp, 0x08
00007f828abdc96e  push rax
00007f828abdc96f  push rcx
00007f828abdc970  push rdx
00007f828abdc971  push rdi
00007f828abdc972  push rsi
00007f828abdc973  push r8
00007f828abdc975  push r9
00007f828abdc977  push r10
00007f828abdc979  push r11
00007f828abdc97b  sub rsp, 0xF0
00007f828abdc982  vmovaps [rsp], xmm0
00007f828abdc987  vmovaps [rsp+0x10], xmm1
00007f828abdc98d  vmovaps [rsp+0x20], xmm2
00007f828abdc993  vmovaps [rsp+0x30], xmm3
00007f828abdc999  vmovaps [rsp+0x40], xmm4
00007f828abdc99f  vmovaps [rsp+0x50], xmm5
00007f828abdc9a5  vmovaps [rsp+0x60], xmm6
00007f828abdc9ab  vmovaps [rsp+0x70], xmm7
00007f828abdc9b1  vmovaps [rsp+0x80], xmm9
00007f828abdc9ba  vmovaps [rsp+0x90], xmm10
00007f828abdc9c3  vmovaps [rsp+0xA0], xmm11
00007f828abdc9cc  vmovaps [rsp+0xB0], xmm12
00007f828abdc9d5  vmovaps [rsp+0xC0], xmm13
00007f828abdc9de  vmovaps [rsp+0xD0], xmm14
00007f828abdc9e7  vmovaps [rsp+0xE0], xmm15
00007f828abdc9f0  sub rsp, 0x30
00007f828abdc9f4  movaps [rsp], xmm8
00007f828abdc9f9  movaps [rsp+0x10], xmm12
00007f828abdc9ff  movaps [rsp+0x20], xmm15
00007f828abdca05  lea rdi, [rsp]
00007f828abdca09  mov esi, 0x00
00007f828abdca0e  mov rax, 0x5BFE27FA6530
00007f828abdca18  call rax
00007f828abdca1a  movaps xmm8, [rsp]
00007f828abdca1f  add rsp, 0x30
00007f828abdca23  vmovaps xmm0, [rsp]
00007f828abdca28  vmovaps xmm1, [rsp+0x10]
00007f828abdca2e  vmovaps xmm2, [rsp+0x20]
00007f828abdca34  vmovaps xmm3, [rsp+0x30]
00007f828abdca3a  vmovaps xmm4, [rsp+0x40]
00007f828abdca40  vmovaps xmm5, [rsp+0x50]
00007f828abdca46  vmovaps xmm6, [rsp+0x60]
00007f828abdca4c  vmovaps xmm7, [rsp+0x70]
00007f828abdca52  vmovaps xmm9, [rsp+0x80]
00007f828abdca5b  vmovaps xmm10, [rsp+0x90]
00007f828abdca64  vmovaps xmm11, [rsp+0xA0]
00007f828abdca6d  vmovaps xmm12, [rsp+0xB0]
00007f828abdca76  vmovaps xmm13, [rsp+0xC0]
00007f828abdca7f  vmovaps xmm14, [rsp+0xD0]
00007f828abdca88  vmovaps xmm15, [rsp+0xE0]
00007f828abdca91  add rsp, 0xF0
00007f828abdca98  pop r11
00007f828abdca9a  pop r10
00007f828abdca9c  pop r9
00007f828abdca9e  pop r8
00007f828abdcaa0  pop rsi
00007f828abdcaa1  pop rdi
00007f828abdcaa2  pop rdx
00007f828abdcaa3  pop rcx
00007f828abdcaa4  pop rax
00007f828abdcaa5  add rsp, 0x08
00007f828abdcaa9  jmp 0x00007F828ABDBB47
00007f828abdcaae  sub rsp, 0x08
00007f828abdcab2  push rax
00007f828abdcab3  push rcx
00007f828abdcab4  push rdx
00007f828abdcab5  push rdi
00007f828abdcab6  push rsi
00007f828abdcab7  push r8
00007f828abdcab9  push r9
00007f828abdcabb  push r10
00007f828abdcabd  push r11
00007f828abdcabf  sub rsp, 0xF0
00007f828abdcac6  vmovaps [rsp], xmm0
00007f828abdcacb  vmovaps [rsp+0x10], xmm1
00007f828abdcad1  vmovaps [rsp+0x20], xmm2
00007f828abdcad7  vmovaps [rsp+0x30], xmm3
00007f828abdcadd  vmovaps [rsp+0x40], xmm4
00007f828abdcae3  vmovaps [rsp+0x50], xmm5
00007f828abdcae9  vmovaps [rsp+0x60], xmm6
00007f828abdcaef  vmovaps [rsp+0x70], xmm8
00007f828abdcaf5  vmovaps [rsp+0x80], xmm9
00007f828abdcafe  vmovaps [rsp+0x90], xmm10
00007f828abdcb07  vmovaps [rsp+0xA0], xmm11
00007f828abdcb10  vmovaps [rsp+0xB0], xmm12
00007f828abdcb19  vmovaps [rsp+0xC0], xmm13
00007f828abdcb22  vmovaps [rsp+0xD0], xmm14
00007f828abdcb2b  vmovaps [rsp+0xE0], xmm15
00007f828abdcb34  sub rsp, 0x30
00007f828abdcb38  movaps [rsp], xmm7
00007f828abdcb3c  movaps [rsp+0x10], xmm9
00007f828abdcb42  movaps [rsp+0x20], xmm15
00007f828abdcb48  lea rdi, [rsp]
00007f828abdcb4c  mov esi, 0x00
00007f828abdcb51  mov rax, 0x5BFE27FA6530
00007f828abdcb5b  call rax
00007f828abdcb5d  movaps xmm7, [rsp]
00007f828abdcb61  add rsp, 0x30
00007f828abdcb65  vmovaps xmm0, [rsp]
00007f828abdcb6a  vmovaps xmm1, [rsp+0x10]
00007f828abdcb70  vmovaps xmm2, [rsp+0x20]
00007f828abdcb76  vmovaps xmm3, [rsp+0x30]
00007f828abdcb7c  vmovaps xmm4, [rsp+0x40]
00007f828abdcb82  vmovaps xmm5, [rsp+0x50]
00007f828abdcb88  vmovaps xmm6, [rsp+0x60]
00007f828abdcb8e  vmovaps xmm8, [rsp+0x70]
00007f828abdcb94  vmovaps xmm9, [rsp+0x80]
00007f828abdcb9d  vmovaps xmm10, [rsp+0x90]
00007f828abdcba6  vmovaps xmm11, [rsp+0xA0]
00007f828abdcbaf  vmovaps xmm12, [rsp+0xB0]
00007f828abdcbb8  vmovaps xmm13, [rsp+0xC0]
00007f828abdcbc1  vmovaps xmm14, [rsp+0xD0]
00007f828abdcbca  vmovaps xmm15, [rsp+0xE0]
00007f828abdcbd3  add rsp, 0xF0
00007f828abdcbda  pop r11
00007f828abdcbdc  pop r10
00007f828abdcbde  pop r9
00007f828abdcbe0  pop r8
00007f828abdcbe2  pop rsi
00007f828abdcbe3  pop rdi
00007f828abdcbe4  pop rdx
00007f828abdcbe5  pop rcx
00007f828abdcbe6  pop rax
00007f828abdcbe7  add rsp, 0x08
00007f828abdcbeb  jmp 0x00007F828ABDBB75
00007f828abdcbf0  sub rsp, 0x08
00007f828abdcbf4  push rax
00007f828abdcbf5  push rcx
00007f828abdcbf6  push rdx
00007f828abdcbf7  push rdi
00007f828abdcbf8  push rsi
00007f828abdcbf9  push r8
00007f828abdcbfb  push r9
00007f828abdcbfd  push r10
00007f828abdcbff  push r11
00007f828abdcc01  sub rsp, 0xF0
00007f828abdcc08  vmovaps [rsp], xmm0
00007f828abdcc0d  vmovaps [rsp+0x10], xmm1
00007f828abdcc13  vmovaps [rsp+0x20], xmm2
00007f828abdcc19  vmovaps [rsp+0x30], xmm3
00007f828abdcc1f  vmovaps [rsp+0x40], xmm4
00007f828abdcc25  vmovaps [rsp+0x50], xmm5
00007f828abdcc2b  vmovaps [rsp+0x60], xmm6
00007f828abdcc31  vmovaps [rsp+0x70], xmm7
00007f828abdcc37  vmovaps [rsp+0x80], xmm8
00007f828abdcc40  vmovaps [rsp+0x90], xmm10
00007f828abdcc49  vmovaps [rsp+0xA0], xmm11
00007f828abdcc52  vmovaps [rsp+0xB0], xmm12
00007f828abdcc5b  vmovaps [rsp+0xC0], xmm13
00007f828abdcc64  vmovaps [rsp+0xD0], xmm14
00007f828abdcc6d  vmovaps [rsp+0xE0], xmm15
00007f828abdcc76  sub rsp, 0x30
00007f828abdcc7a  movaps [rsp], xmm9
00007f828abdcc7f  movaps [rsp+0x10], xmm12
00007f828abdcc85  movaps [rsp+0x20], xmm10
00007f828abdcc8b  lea rdi, [rsp]
00007f828abdcc8f  mov esi, 0x00
00007f828abdcc94  mov rax, 0x5BFE27FA6530
00007f828abdcc9e  call rax
00007f828abdcca0  movaps xmm9, [rsp]
00007f828abdcca5  add rsp, 0x30
00007f828abdcca9  vmovaps xmm0, [rsp]
00007f828abdccae  vmovaps xmm1, [rsp+0x10]
00007f828abdccb4  vmovaps xmm2, [rsp+0x20]
00007f828abdccba  vmovaps xmm3, [rsp+0x30]
00007f828abdccc0  vmovaps xmm4, [rsp+0x40]
00007f828abdccc6  vmovaps xmm5, [rsp+0x50]
00007f828abdcccc  vmovaps xmm6, [rsp+0x60]
00007f828abdccd2  vmovaps xmm7, [rsp+0x70]
00007f828abdccd8  vmovaps xmm8, [rsp+0x80]
00007f828abdcce1  vmovaps xmm10, [rsp+0x90]
00007f828abdccea  vmovaps xmm11, [rsp+0xA0]
00007f828abdccf3  vmovaps xmm12, [rsp+0xB0]
00007f828abdccfc  vmovaps xmm13, [rsp+0xC0]
00007f828abdcd05  vmovaps xmm14, [rsp+0xD0]
00007f828abdcd0e  vmovaps xmm15, [rsp+0xE0]
00007f828abdcd17  add rsp, 0xF0
00007f828abdcd1e  pop r11
00007f828abdcd20  pop r10
00007f828abdcd22  pop r9
00007f828abdcd24  pop r8
00007f828abdcd26  pop rsi
00007f828abdcd27  pop rdi
00007f828abdcd28  pop rdx
00007f828abdcd29  pop rcx
00007f828abdcd2a  pop rax
00007f828abdcd2b  add rsp, 0x08
00007f828abdcd2f  jmp 0x00007F828ABDBB99
00007f828abdcd34  sub rsp, 0x08
00007f828abdcd38  push rax
00007f828abdcd39  push rcx
00007f828abdcd3a  push rdx
00007f828abdcd3b  push rdi
00007f828abdcd3c  push rsi
00007f828abdcd3d  push r8
00007f828abdcd3f  push r9
00007f828abdcd41  push r10
00007f828abdcd43  push r11
00007f828abdcd45  sub rsp, 0xF0
00007f828abdcd4c  vmovaps [rsp], xmm0
00007f828abdcd51  vmovaps [rsp+0x10], xmm1
00007f828abdcd57  vmovaps [rsp+0x20], xmm2
00007f828abdcd5d  vmovaps [rsp+0x30], xmm3
00007f828abdcd63  vmovaps [rsp+0x40], xmm4
00007f828abdcd69  vmovaps [rsp+0x50], xmm5
00007f828abdcd6f  vmovaps [rsp+0x60], xmm6
00007f828abdcd75  vmovaps [rsp+0x70], xmm7
00007f828abdcd7b  vmovaps [rsp+0x80], xmm8
00007f828abdcd84  vmovaps [rsp+0x90], xmm9
00007f828abdcd8d  vmovaps [rsp+0xA0], xmm11
00007f828abdcd96  vmovaps [rsp+0xB0], xmm12
00007f828abdcd9f  vmovaps [rsp+0xC0], xmm13
00007f828abdcda8  vmovaps [rsp+0xD0], xmm14
00007f828abdcdb1  vmovaps [rsp+0xE0], xmm15
00007f828abdcdba  sub rsp, 0x30
00007f828abdcdbe  movaps [rsp], xmm10
00007f828abdcdc3  movaps [rsp+0x10], xmm12
00007f828abdcdc9  movaps [rsp+0x20], xmm11
00007f828abdcdcf  lea rdi, [rsp]
00007f828abdcdd3  mov esi, 0x00
00007f828abdcdd8  mov rax, 0x5BFE27FA6530
00007f828abdcde2  call rax
00007f828abdcde4  movaps xmm10, [rsp]
00007f828abdcde9  add rsp, 0x30
00007f828abdcded  vmovaps xmm0, [rsp]
00007f828abdcdf2  vmovaps xmm1, [rsp+0x10]
00007f828abdcdf8  vmovaps xmm2, [rsp+0x20]
00007f828abdcdfe  vmovaps xmm3, [rsp+0x30]
00007f828abdce04  vmovaps xmm4, [rsp+0x40]
00007f828abdce0a  vmovaps xmm5, [rsp+0x50]
00007f828abdce10  vmovaps xmm6, [rsp+0x60]
00007f828abdce16  vmovaps xmm7, [rsp+0x70]
00007f828abdce1c  vmovaps xmm8, [rsp+0x80]
00007f828abdce25  vmovaps xmm9, [rsp+0x90]
00007f828abdce2e  vmovaps xmm11, [rsp+0xA0]
00007f828abdce37  vmovaps xmm12, [rsp+0xB0]
00007f828abdce40  vmovaps xmm13, [rsp+0xC0]
00007f828abdce49  vmovaps xmm14, [rsp+0xD0]
00007f828abdce52  vmovaps xmm15, [rsp+0xE0]
00007f828abdce5b  add rsp, 0xF0
00007f828abdce62  pop r11
00007f828abdce64  pop r10
00007f828abdce66  pop r9
00007f828abdce68  pop r8
00007f828abdce6a  pop rsi
00007f828abdce6b  pop rdi
00007f828abdce6c  pop rdx
00007f828abdce6d  pop rcx
00007f828abdce6e  pop rax
00007f828abdce6f  add rsp, 0x08
00007f828abdce73  jmp 0x00007F828ABDBBB3
00007f828abdce78  sub rsp, 0x08
00007f828abdce7c  push rax
00007f828abdce7d  push rcx
00007f828abdce7e  push rdx
00007f828abdce7f  push rdi
00007f828abdce80  push rsi
00007f828abdce81  push r8
00007f828abdce83  push r9
00007f828abdce85  push r10
00007f828abdce87  push r11
00007f828abdce89  sub rsp, 0xF0
00007f828abdce90  vmovaps [rsp], xmm0
00007f828abdce95  vmovaps [rsp+0x10], xmm1
00007f828abdce9b  vmovaps [rsp+0x20], xmm2
00007f828abdcea1  vmovaps [rsp+0x30], xmm3
00007f828abdcea7  vmovaps [rsp+0x40], xmm4
00007f828abdcead  vmovaps [rsp+0x50], xmm5
00007f828abdceb3  vmovaps [rsp+0x60], xmm7
00007f828abdceb9  vmovaps [rsp+0x70], xmm8
00007f828abdcebf  vmovaps [rsp+0x80], xmm9
00007f828abdcec8  vmovaps [rsp+0x90], xmm10
00007f828abdced1  vmovaps [rsp+0xA0], xmm11
00007f828abdceda  vmovaps [rsp+0xB0], xmm12
00007f828abdcee3  vmovaps [rsp+0xC0], xmm13
00007f828abdceec  vmovaps [rsp+0xD0], xmm14
00007f828abdcef5  vmovaps [rsp+0xE0], xmm15
00007f828abdcefe  sub rsp, 0x30
00007f828abdcf02  movaps [rsp], xmm6
00007f828abdcf06  movaps [rsp+0x10], xmm12
00007f828abdcf0c  movaps [rsp+0x20], xmm11
00007f828abdcf12  lea rdi, [rsp]
00007f828abdcf16  mov esi, 0x00
00007f828abdcf1b  mov rax, 0x5BFE27FA6530
00007f828abdcf25  call rax
00007f828abdcf27  movaps xmm6, [rsp]
00007f828abdcf2b  add rsp, 0x30
00007f828abdcf2f  vmovaps xmm0, [rsp]
00007f828abdcf34  vmovaps xmm1, [rsp+0x10]
00007f828abdcf3a  vmovaps xmm2, [rsp+0x20]
00007f828abdcf40  vmovaps xmm3, [rsp+0x30]
00007f828abdcf46  vmovaps xmm4, [rsp+0x40]
00007f828abdcf4c  vmovaps xmm5, [rsp+0x50]
00007f828abdcf52  vmovaps xmm7, [rsp+0x60]
00007f828abdcf58  vmovaps xmm8, [rsp+0x70]
00007f828abdcf5e  vmovaps xmm9, [rsp+0x80]
00007f828abdcf67  vmovaps xmm10, [rsp+0x90]
00007f828abdcf70  vmovaps xmm11, [rsp+0xA0]
00007f828abdcf79  vmovaps xmm12, [rsp+0xB0]
00007f828abdcf82  vmovaps xmm13, [rsp+0xC0]
00007f828abdcf8b  vmovaps xmm14, [rsp+0xD0]
00007f828abdcf94  vmovaps xmm15, [rsp+0xE0]
00007f828abdcf9d  add rsp, 0xF0
00007f828abdcfa4  pop r11
00007f828abdcfa6  pop r10
00007f828abdcfa8  pop r9
00007f828abdcfaa  pop r8
00007f828abdcfac  pop rsi
00007f828abdcfad  pop rdi
00007f828abdcfae  pop rdx
00007f828abdcfaf  pop rcx
00007f828abdcfb0  pop rax
00007f828abdcfb1  add rsp, 0x08
00007f828abdcfb5  jmp 0x00007F828ABDBBD4
00007f828abdcfba  sub rsp, 0x08
00007f828abdcfbe  push rax
00007f828abdcfbf  push rcx
00007f828abdcfc0  push rdx
00007f828abdcfc1  push rdi
00007f828abdcfc2  push rsi
00007f828abdcfc3  push r8
00007f828abdcfc5  push r9
00007f828abdcfc7  push r10
00007f828abdcfc9  push r11
00007f828abdcfcb  sub rsp, 0xF0
00007f828abdcfd2  vmovaps [rsp], xmm0
00007f828abdcfd7  vmovaps [rsp+0x10], xmm1
00007f828abdcfdd  vmovaps [rsp+0x20], xmm2
00007f828abdcfe3  vmovaps [rsp+0x30], xmm4
00007f828abdcfe9  vmovaps [rsp+0x40], xmm5
00007f828abdcfef  vmovaps [rsp+0x50], xmm6
00007f828abdcff5  vmovaps [rsp+0x60], xmm7
00007f828abdcffb  vmovaps [rsp+0x70], xmm8
00007f828abdd001  vmovaps [rsp+0x80], xmm9
00007f828abdd00a  vmovaps [rsp+0x90], xmm10
00007f828abdd013  vmovaps [rsp+0xA0], xmm11
00007f828abdd01c  vmovaps [rsp+0xB0], xmm12
00007f828abdd025  vmovaps [rsp+0xC0], xmm13
00007f828abdd02e  vmovaps [rsp+0xD0], xmm14
00007f828abdd037  vmovaps [rsp+0xE0], xmm15
00007f828abdd040  sub rsp, 0x30
00007f828abdd044  movaps [rsp], xmm3
00007f828abdd048  movaps [rsp+0x10], xmm5
00007f828abdd04d  movaps [rsp+0x20], xmm4
00007f828abdd052  lea rdi, [rsp]
00007f828abdd056  mov esi, 0x00
00007f828abdd05b  mov rax, 0x5BFE27FA6530
00007f828abdd065  call rax
00007f828abdd067  movaps xmm3, [rsp]
00007f828abdd06b  add rsp, 0x30
00007f828abdd06f  vmovaps xmm0, [rsp]
00007f828abdd074  vmovaps xmm1, [rsp+0x10]
00007f828abdd07a  vmovaps xmm2, [rsp+0x20]
00007f828abdd080  vmovaps xmm4, [rsp+0x30]
00007f828abdd086  vmovaps xmm5, [rsp+0x40]
00007f828abdd08c  vmovaps xmm6, [rsp+0x50]
00007f828abdd092  vmovaps xmm7, [rsp+0x60]
00007f828abdd098  vmovaps xmm8, [rsp+0x70]
00007f828abdd09e  vmovaps xmm9, [rsp+0x80]
00007f828abdd0a7  vmovaps xmm10, [rsp+0x90]
00007f828abdd0b0  vmovaps xmm11, [rsp+0xA0]
00007f828abdd0b9  vmovaps xmm12, [rsp+0xB0]
00007f828abdd0c2  vmovaps xmm13, [rsp+0xC0]
00007f828abdd0cb  vmovaps xmm14, [rsp+0xD0]
00007f828abdd0d4  vmovaps xmm15, [rsp+0xE0]
00007f828abdd0dd  add rsp, 0xF0
00007f828abdd0e4  pop r11
00007f828abdd0e6  pop r10
00007f828abdd0e8  pop r9
00007f828abdd0ea  pop r8
00007f828abdd0ec  pop rsi
00007f828abdd0ed  pop rdi
00007f828abdd0ee  pop rdx
00007f828abdd0ef  pop rcx
00007f828abdd0f0  pop rax
00007f828abdd0f1  add rsp, 0x08
00007f828abdd0f5  jmp 0x00007F828ABDBC35
00007f828abdd0fa  sub rsp, 0x08
00007f828abdd0fe  push rax
00007f828abdd0ff  push rcx
00007f828abdd100  push rdx
00007f828abdd101  push rdi
00007f828abdd102  push rsi
00007f828abdd103  push r8
00007f828abdd105  push r9
00007f828abdd107  push r10
00007f828abdd109  push r11
00007f828abdd10b  sub rsp, 0xF0
00007f828abdd112  vmovaps [rsp], xmm0
00007f828abdd117  vmovaps [rsp+0x10], xmm1
00007f828abdd11d  vmovaps [rsp+0x20], xmm2
00007f828abdd123  vmovaps [rsp+0x30], xmm3
00007f828abdd129  vmovaps [rsp+0x40], xmm4
00007f828abdd12f  vmovaps [rsp+0x50], xmm6
00007f828abdd135  vmovaps [rsp+0x60], xmm7
00007f828abdd13b  vmovaps [rsp+0x70], xmm8
00007f828abdd141  vmovaps [rsp+0x80], xmm9
00007f828abdd14a  vmovaps [rsp+0x90], xmm10
00007f828abdd153  vmovaps [rsp+0xA0], xmm11
00007f828abdd15c  vmovaps [rsp+0xB0], xmm12
00007f828abdd165  vmovaps [rsp+0xC0], xmm13
00007f828abdd16e  vmovaps [rsp+0xD0], xmm14
00007f828abdd177  vmovaps [rsp+0xE0], xmm15
00007f828abdd180  sub rsp, 0x30
00007f828abdd184  movaps [rsp], xmm5
00007f828abdd188  movaps [rsp+0x10], xmm8
00007f828abdd18e  movaps [rsp+0x20], xmm15
00007f828abdd194  lea rdi, [rsp]
00007f828abdd198  mov esi, 0x00
00007f828abdd19d  mov rax, 0x5BFE27FA6530
00007f828abdd1a7  call rax
00007f828abdd1a9  movaps xmm5, [rsp]
00007f828abdd1ad  add rsp, 0x30
00007f828abdd1b1  vmovaps xmm0, [rsp]
00007f828abdd1b6  vmovaps xmm1, [rsp+0x10]
00007f828abdd1bc  vmovaps xmm2, [rsp+0x20]
00007f828abdd1c2  vmovaps xmm3, [rsp+0x30]
00007f828abdd1c8  vmovaps xmm4, [rsp+0x40]
00007f828abdd1ce  vmovaps xmm6, [rsp+0x50]
00007f828abdd1d4  vmovaps xmm7, [rsp+0x60]
00007f828abdd1da  vmovaps xmm8, [rsp+0x70]
00007f828abdd1e0  vmovaps xmm9, [rsp+0x80]
00007f828abdd1e9  vmovaps xmm10, [rsp+0x90]
00007f828abdd1f2  vmovaps xmm11, [rsp+0xA0]
00007f828abdd1fb  vmovaps xmm12, [rsp+0xB0]
00007f828abdd204  vmovaps xmm13, [rsp+0xC0]
00007f828abdd20d  vmovaps xmm14, [rsp+0xD0]
00007f828abdd216  vmovaps xmm15, [rsp+0xE0]
00007f828abdd21f  add rsp, 0xF0
00007f828abdd226  pop r11
00007f828abdd228  pop r10
00007f828abdd22a  pop r9
00007f828abdd22c  pop r8
00007f828abdd22e  pop rsi
00007f828abdd22f  pop rdi
00007f828abdd230  pop rdx
00007f828abdd231  pop rcx
00007f828abdd232  pop rax
00007f828abdd233  add rsp, 0x08
00007f828abdd237  jmp 0x00007F828ABDBC73
00007f828abdd23c  sub rsp, 0x08
00007f828abdd240  push rax
00007f828abdd241  push rcx
00007f828abdd242  push rdx
00007f828abdd243  push rdi
00007f828abdd244  push rsi
00007f828abdd245  push r8
00007f828abdd247  push r9
00007f828abdd249  push r10
00007f828abdd24b  push r11
00007f828abdd24d  sub rsp, 0xF0
00007f828abdd254  vmovaps [rsp], xmm0
00007f828abdd259  vmovaps [rsp+0x10], xmm1
00007f828abdd25f  vmovaps [rsp+0x20], xmm2
00007f828abdd265  vmovaps [rsp+0x30], xmm3
00007f828abdd26b  vmovaps [rsp+0x40], xmm5
00007f828abdd271  vmovaps [rsp+0x50], xmm6
00007f828abdd277  vmovaps [rsp+0x60], xmm7
00007f828abdd27d  vmovaps [rsp+0x70], xmm8
00007f828abdd283  vmovaps [rsp+0x80], xmm9
00007f828abdd28c  vmovaps [rsp+0x90], xmm10
00007f828abdd295  vmovaps [rsp+0xA0], xmm11
00007f828abdd29e  vmovaps [rsp+0xB0], xmm12
00007f828abdd2a7  vmovaps [rsp+0xC0], xmm13
00007f828abdd2b0  vmovaps [rsp+0xD0], xmm14
00007f828abdd2b9  vmovaps [rsp+0xE0], xmm15
00007f828abdd2c2  sub rsp, 0x30
00007f828abdd2c6  movaps [rsp], xmm4
00007f828abdd2ca  movaps [rsp+0x10], xmm9
00007f828abdd2d0  movaps [rsp+0x20], xmm8
00007f828abdd2d6  lea rdi, [rsp]
00007f828abdd2da  mov esi, 0x00
00007f828abdd2df  mov rax, 0x5BFE27FA6530
00007f828abdd2e9  call rax
00007f828abdd2eb  movaps xmm4, [rsp]
00007f828abdd2ef  add rsp, 0x30
00007f828abdd2f3  vmovaps xmm0, [rsp]
00007f828abdd2f8  vmovaps xmm1, [rsp+0x10]
00007f828abdd2fe  vmovaps xmm2, [rsp+0x20]
00007f828abdd304  vmovaps xmm3, [rsp+0x30]
00007f828abdd30a  vmovaps xmm5, [rsp+0x40]
00007f828abdd310  vmovaps xmm6, [rsp+0x50]
00007f828abdd316  vmovaps xmm7, [rsp+0x60]
00007f828abdd31c  vmovaps xmm8, [rsp+0x70]
00007f828abdd322  vmovaps xmm9, [rsp+0x80]
00007f828abdd32b  vmovaps xmm10, [rsp+0x90]
00007f828abdd334  vmovaps xmm11, [rsp+0xA0]
00007f828abdd33d  vmovaps xmm12, [rsp+0xB0]
00007f828abdd346  vmovaps xmm13, [rsp+0xC0]
00007f828abdd34f  vmovaps xmm14, [rsp+0xD0]
00007f828abdd358  vmovaps xmm15, [rsp+0xE0]
00007f828abdd361  add rsp, 0xF0
00007f828abdd368  pop r11
00007f828abdd36a  pop r10
00007f828abdd36c  pop r9
00007f828abdd36e  pop r8
00007f828abdd370  pop rsi
00007f828abdd371  pop rdi
00007f828abdd372  pop rdx
00007f828abdd373  pop rcx
00007f828abdd374  pop rax
00007f828abdd375  add rsp, 0x08
00007f828abdd379  jmp 0x00007F828ABDBC94
00007f828abdd37e  sub rsp, 0x08
00007f828abdd382  push rax
00007f828abdd383  push rcx
00007f828abdd384  push rdx
00007f828abdd385  push rdi
00007f828abdd386  push rsi
00007f828abdd387  push r8
00007f828abdd389  push r9
00007f828abdd38b  push r10
00007f828abdd38d  push r11
00007f828abdd38f  sub rsp, 0xF0
00007f828abdd396  vmovaps [rsp], xmm0
00007f828abdd39b  vmovaps [rsp+0x10], xmm1
00007f828abdd3a1  vmovaps [rsp+0x20], xmm2
00007f828abdd3a7  vmovaps [rsp+0x30], xmm3
00007f828abdd3ad  vmovaps [rsp+0x40], xmm4
00007f828abdd3b3  vmovaps [rsp+0x50], xmm5
00007f828abdd3b9  vmovaps [rsp+0x60], xmm6
00007f828abdd3bf  vmovaps [rsp+0x70], xmm7
00007f828abdd3c5  vmovaps [rsp+0x80], xmm8
00007f828abdd3ce  vmovaps [rsp+0x90], xmm10
00007f828abdd3d7  vmovaps [rsp+0xA0], xmm11
00007f828abdd3e0  vmovaps [rsp+0xB0], xmm12
00007f828abdd3e9  vmovaps [rsp+0xC0], xmm13
00007f828abdd3f2  vmovaps [rsp+0xD0], xmm14
00007f828abdd3fb  vmovaps [rsp+0xE0], xmm15
00007f828abdd404  sub rsp, 0x30
00007f828abdd408  movaps [rsp], xmm9
00007f828abdd40d  movaps [rsp+0x10], xmm10
00007f828abdd413  movaps [rsp+0x20], xmm8
00007f828abdd419  lea rdi, [rsp]
00007f828abdd41d  mov esi, 0x00
00007f828abdd422  mov rax, 0x5BFE27FA6530
00007f828abdd42c  call rax
00007f828abdd42e  movaps xmm9, [rsp]
00007f828abdd433  add rsp, 0x30
00007f828abdd437  vmovaps xmm0, [rsp]
00007f828abdd43c  vmovaps xmm1, [rsp+0x10]
00007f828abdd442  vmovaps xmm2, [rsp+0x20]
00007f828abdd448  vmovaps xmm3, [rsp+0x30]
00007f828abdd44e  vmovaps xmm4, [rsp+0x40]
00007f828abdd454  vmovaps xmm5, [rsp+0x50]
00007f828abdd45a  vmovaps xmm6, [rsp+0x60]
00007f828abdd460  vmovaps xmm7, [rsp+0x70]
00007f828abdd466  vmovaps xmm8, [rsp+0x80]
00007f828abdd46f  vmovaps xmm10, [rsp+0x90]
00007f828abdd478  vmovaps xmm11, [rsp+0xA0]
00007f828abdd481  vmovaps xmm12, [rsp+0xB0]
00007f828abdd48a  vmovaps xmm13, [rsp+0xC0]
00007f828abdd493  vmovaps xmm14, [rsp+0xD0]
00007f828abdd49c  vmovaps xmm15, [rsp+0xE0]
00007f828abdd4a5  add rsp, 0xF0
00007f828abdd4ac  pop r11
00007f828abdd4ae  pop r10
00007f828abdd4b0  pop r9
00007f828abdd4b2  pop r8
00007f828abdd4b4  pop rsi
00007f828abdd4b5  pop rdi
00007f828abdd4b6  pop rdx
00007f828abdd4b7  pop rcx
00007f828abdd4b8  pop rax
00007f828abdd4b9  add rsp, 0x08
00007f828abdd4bd  jmp 0x00007F828ABDBCAE
00007f828abdd4c2  call 0x00007F828AAB52F0
00007f828abdd4c7  jmp 0x00007F828ABDBDC8
00007f828abdd4cc  call 0x00007F828AAB52F0
00007f828abdd4d1  jmp 0x00007F828ABDBDDE
00007f828abdd4d6  sub rsp, 0x08
00007f828abdd4da  push rax
00007f828abdd4db  push rcx
00007f828abdd4dc  push rdx
00007f828abdd4dd  push rdi
00007f828abdd4de  push rsi
00007f828abdd4df  push r8
00007f828abdd4e1  push r9
00007f828abdd4e3  push r10
00007f828abdd4e5  push r11
00007f828abdd4e7  sub rsp, 0xF0
00007f828abdd4ee  vmovaps [rsp], xmm0
00007f828abdd4f3  vmovaps [rsp+0x10], xmm2
00007f828abdd4f9  vmovaps [rsp+0x20], xmm3
00007f828abdd4ff  vmovaps [rsp+0x30], xmm4
00007f828abdd505  vmovaps [rsp+0x40], xmm5
00007f828abdd50b  vmovaps [rsp+0x50], xmm6
00007f828abdd511  vmovaps [rsp+0x60], xmm7
00007f828abdd517  vmovaps [rsp+0x70], xmm8
00007f828abdd51d  vmovaps [rsp+0x80], xmm9
00007f828abdd526  vmovaps [rsp+0x90], xmm10
00007f828abdd52f  vmovaps [rsp+0xA0], xmm11
00007f828abdd538  vmovaps [rsp+0xB0], xmm12
00007f828abdd541  vmovaps [rsp+0xC0], xmm13
00007f828abdd54a  vmovaps [rsp+0xD0], xmm14
00007f828abdd553  vmovaps [rsp+0xE0], xmm15
00007f828abdd55c  sub rsp, 0x30
00007f828abdd560  movaps [rsp], xmm1
00007f828abdd564  movaps [rsp+0x10], xmm6
00007f828abdd569  movaps [rsp+0x20], xmm15
00007f828abdd56f  lea rdi, [rsp]
00007f828abdd573  mov esi, 0x00
00007f828abdd578  mov rax, 0x5BFE27FA6530
00007f828abdd582  call rax
00007f828abdd584  movaps xmm1, [rsp]
00007f828abdd588  add rsp, 0x30
00007f828abdd58c  vmovaps xmm0, [rsp]
00007f828abdd591  vmovaps xmm2, [rsp+0x10]
00007f828abdd597  vmovaps xmm3, [rsp+0x20]
00007f828abdd59d  vmovaps xmm4, [rsp+0x30]
00007f828abdd5a3  vmovaps xmm5, [rsp+0x40]
00007f828abdd5a9  vmovaps xmm6, [rsp+0x50]
00007f828abdd5af  vmovaps xmm7, [rsp+0x60]
00007f828abdd5b5  vmovaps xmm8, [rsp+0x70]
00007f828abdd5bb  vmovaps xmm9, [rsp+0x80]
00007f828abdd5c4  vmovaps xmm10, [rsp+0x90]
00007f828abdd5cd  vmovaps xmm11, [rsp+0xA0]
00007f828abdd5d6  vmovaps xmm12, [rsp+0xB0]
00007f828abdd5df  vmovaps xmm13, [rsp+0xC0]
00007f828abdd5e8  vmovaps xmm14, [rsp+0xD0]
00007f828abdd5f1  vmovaps xmm15, [rsp+0xE0]
00007f828abdd5fa  add rsp, 0xF0
00007f828abdd601  pop r11
00007f828abdd603  pop r10
00007f828abdd605  pop r9
00007f828abdd607  pop r8
00007f828abdd609  pop rsi
00007f828abdd60a  pop rdi
00007f828abdd60b  pop rdx
00007f828abdd60c  pop rcx
00007f828abdd60d  pop rax
00007f828abdd60e  add rsp, 0x08
00007f828abdd612  jmp 0x00007F828ABDBE1B
00007f828abdd617  call 0x00007F828AAC4620
00007f828abdd61c  jmp 0x00007F828ABDBE28
00007f828abdd621  sub rsp, 0x08
00007f828abdd625  push rax
00007f828abdd626  push rcx
00007f828abdd627  push rdx
00007f828abdd628  push rdi
00007f828abdd629  push rsi
00007f828abdd62a  push r8
00007f828abdd62c  push r9
00007f828abdd62e  push r10
00007f828abdd630  push r11
00007f828abdd632  sub rsp, 0xF0
00007f828abdd639  vmovaps [rsp], xmm0
00007f828abdd63e  vmovaps [rsp+0x10], xmm1
00007f828abdd644  vmovaps [rsp+0x20], xmm2
00007f828abdd64a  vmovaps [rsp+0x30], xmm3
00007f828abdd650  vmovaps [rsp+0x40], xmm4
00007f828abdd656  vmovaps [rsp+0x50], xmm5
00007f828abdd65c  vmovaps [rsp+0x60], xmm6
00007f828abdd662  vmovaps [rsp+0x70], xmm7
00007f828abdd668  vmovaps [rsp+0x80], xmm8
00007f828abdd671  vmovaps [rsp+0x90], xmm9
00007f828abdd67a  vmovaps [rsp+0xA0], xmm10
00007f828abdd683  vmovaps [rsp+0xB0], xmm11
00007f828abdd68c  vmovaps [rsp+0xC0], xmm12
00007f828abdd695  vmovaps [rsp+0xD0], xmm13
00007f828abdd69e  vmovaps [rsp+0xE0], xmm15
00007f828abdd6a7  sub rsp, 0x30
00007f828abdd6ab  movaps [rsp], xmm14
00007f828abdd6b0  movaps [rsp+0x10], xmm4
00007f828abdd6b5  movaps [rsp+0x20], xmm3
00007f828abdd6ba  lea rdi, [rsp]
00007f828abdd6be  mov esi, 0x00
00007f828abdd6c3  mov rax, 0x5BFE27FA6530
00007f828abdd6cd  call rax
00007f828abdd6cf  movaps xmm14, [rsp]
00007f828abdd6d4  add rsp, 0x30
00007f828abdd6d8  vmovaps xmm0, [rsp]
00007f828abdd6dd  vmovaps xmm1, [rsp+0x10]
00007f828abdd6e3  vmovaps xmm2, [rsp+0x20]
00007f828abdd6e9  vmovaps xmm3, [rsp+0x30]
00007f828abdd6ef  vmovaps xmm4, [rsp+0x40]
00007f828abdd6f5  vmovaps xmm5, [rsp+0x50]
00007f828abdd6fb  vmovaps xmm6, [rsp+0x60]
00007f828abdd701  vmovaps xmm7, [rsp+0x70]
00007f828abdd707  vmovaps xmm8, [rsp+0x80]
00007f828abdd710  vmovaps xmm9, [rsp+0x90]
00007f828abdd719  vmovaps xmm10, [rsp+0xA0]
00007f828abdd722  vmovaps xmm11, [rsp+0xB0]
00007f828abdd72b  vmovaps xmm12, [rsp+0xC0]
00007f828abdd734  vmovaps xmm13, [rsp+0xD0]
00007f828abdd73d  vmovaps xmm15, [rsp+0xE0]
00007f828abdd746  add rsp, 0xF0
00007f828abdd74d  pop r11
00007f828abdd74f  pop r10
00007f828abdd751  pop r9
00007f828abdd753  pop r8
00007f828abdd755  pop rsi
00007f828abdd756  pop rdi
00007f828abdd757  pop rdx
00007f828abdd758  pop rcx
00007f828abdd759  pop rax
00007f828abdd75a  add rsp, 0x08
00007f828abdd75e  jmp 0x00007F828ABDBE42
00007f828abdd763  sub rsp, 0x08
00007f828abdd767  push rax
00007f828abdd768  push rcx
00007f828abdd769  push rdx
00007f828abdd76a  push rdi
00007f828abdd76b  push rsi
00007f828abdd76c  push r8
00007f828abdd76e  push r9
00007f828abdd770  push r10
00007f828abdd772  push r11
00007f828abdd774  sub rsp, 0xF0
00007f828abdd77b  vmovaps [rsp], xmm0
00007f828abdd780  vmovaps [rsp+0x10], xmm1
00007f828abdd786  vmovaps [rsp+0x20], xmm2
00007f828abdd78c  vmovaps [rsp+0x30], xmm3
00007f828abdd792  vmovaps [rsp+0x40], xmm4
00007f828abdd798  vmovaps [rsp+0x50], xmm5
00007f828abdd79e  vmovaps [rsp+0x60], xmm7
00007f828abdd7a4  vmovaps [rsp+0x70], xmm8
00007f828abdd7aa  vmovaps [rsp+0x80], xmm9
00007f828abdd7b3  vmovaps [rsp+0x90], xmm10
00007f828abdd7bc  vmovaps [rsp+0xA0], xmm11
00007f828abdd7c5  vmovaps [rsp+0xB0], xmm12
00007f828abdd7ce  vmovaps [rsp+0xC0], xmm13
00007f828abdd7d7  vmovaps [rsp+0xD0], xmm14
00007f828abdd7e0  vmovaps [rsp+0xE0], xmm15
00007f828abdd7e9  sub rsp, 0x30
00007f828abdd7ed  movaps [rsp], xmm6
00007f828abdd7f1  movaps [rsp+0x10], xmm9
00007f828abdd7f7  movaps [rsp+0x20], xmm7
00007f828abdd7fc  lea rdi, [rsp]
00007f828abdd800  mov esi, 0x00
00007f828abdd805  mov rax, 0x5BFE27FA6530
00007f828abdd80f  call rax
00007f828abdd811  movaps xmm6, [rsp]
00007f828abdd815  add rsp, 0x30
00007f828abdd819  vmovaps xmm0, [rsp]
00007f828abdd81e  vmovaps xmm1, [rsp+0x10]
00007f828abdd824  vmovaps xmm2, [rsp+0x20]
00007f828abdd82a  vmovaps xmm3, [rsp+0x30]
00007f828abdd830  vmovaps xmm4, [rsp+0x40]
00007f828abdd836  vmovaps xmm5, [rsp+0x50]
00007f828abdd83c  vmovaps xmm7, [rsp+0x60]
00007f828abdd842  vmovaps xmm8, [rsp+0x70]
00007f828abdd848  vmovaps xmm9, [rsp+0x80]
00007f828abdd851  vmovaps xmm10, [rsp+0x90]
00007f828abdd85a  vmovaps xmm11, [rsp+0xA0]
00007f828abdd863  vmovaps xmm12, [rsp+0xB0]
00007f828abdd86c  vmovaps xmm13, [rsp+0xC0]
00007f828abdd875  vmovaps xmm14, [rsp+0xD0]
00007f828abdd87e  vmovaps xmm15, [rsp+0xE0]
00007f828abdd887  add rsp, 0xF0
00007f828abdd88e  pop r11
00007f828abdd890  pop r10
00007f828abdd892  pop r9
00007f828abdd894  pop r8
00007f828abdd896  pop rsi
00007f828abdd897  pop rdi
00007f828abdd898  pop rdx
00007f828abdd899  pop rcx
00007f828abdd89a  pop rax
00007f828abdd89b  add rsp, 0x08
00007f828abdd89f  jmp 0x00007F828ABDBE5A
00007f828abdd8a4  sub rsp, 0x08
00007f828abdd8a8  push rax
00007f828abdd8a9  push rcx
00007f828abdd8aa  push rdx
00007f828abdd8ab  push rdi
00007f828abdd8ac  push rsi
00007f828abdd8ad  push r8
00007f828abdd8af  push r9
00007f828abdd8b1  push r10
00007f828abdd8b3  push r11
00007f828abdd8b5  sub rsp, 0xF0
00007f828abdd8bc  vmovaps [rsp], xmm0
00007f828abdd8c1  vmovaps [rsp+0x10], xmm1
00007f828abdd8c7  vmovaps [rsp+0x20], xmm2
00007f828abdd8cd  vmovaps [rsp+0x30], xmm3
00007f828abdd8d3  vmovaps [rsp+0x40], xmm4
00007f828abdd8d9  vmovaps [rsp+0x50], xmm5
00007f828abdd8df  vmovaps [rsp+0x60], xmm6
00007f828abdd8e5  vmovaps [rsp+0x70], xmm8
00007f828abdd8eb  vmovaps [rsp+0x80], xmm9
00007f828abdd8f4  vmovaps [rsp+0x90], xmm10
00007f828abdd8fd  vmovaps [rsp+0xA0], xmm11
00007f828abdd906  vmovaps [rsp+0xB0], xmm12
00007f828abdd90f  vmovaps [rsp+0xC0], xmm13
00007f828abdd918  vmovaps [rsp+0xD0], xmm14
00007f828abdd921  vmovaps [rsp+0xE0], xmm15
00007f828abdd92a  sub rsp, 0x30
00007f828abdd92e  movaps [rsp], xmm7
00007f828abdd932  movaps [rsp+0x10], xmm4
00007f828abdd937  movaps [rsp+0x20], xmm9
00007f828abdd93d  lea rdi, [rsp]
00007f828abdd941  mov esi, 0x00
00007f828abdd946  mov rax, 0x5BFE27FA6530
00007f828abdd950  call rax
00007f828abdd952  movaps xmm7, [rsp]
00007f828abdd956  add rsp, 0x30
00007f828abdd95a  vmovaps xmm0, [rsp]
00007f828abdd95f  vmovaps xmm1, [rsp+0x10]
00007f828abdd965  vmovaps xmm2, [rsp+0x20]
00007f828abdd96b  vmovaps xmm3, [rsp+0x30]
00007f828abdd971  vmovaps xmm4, [rsp+0x40]
00007f828abdd977  vmovaps xmm5, [rsp+0x50]
00007f828abdd97d  vmovaps xmm6, [rsp+0x60]
00007f828abdd983  vmovaps xmm8, [rsp+0x70]
00007f828abdd989  vmovaps xmm9, [rsp+0x80]
00007f828abdd992  vmovaps xmm10, [rsp+0x90]
00007f828abdd99b  vmovaps xmm11, [rsp+0xA0]
00007f828abdd9a4  vmovaps xmm12, [rsp+0xB0]
00007f828abdd9ad  vmovaps xmm13, [rsp+0xC0]
00007f828abdd9b6  vmovaps xmm14, [rsp+0xD0]
00007f828abdd9bf  vmovaps xmm15, [rsp+0xE0]
00007f828abdd9c8  add rsp, 0xF0
00007f828abdd9cf  pop r11
00007f828abdd9d1  pop r10
00007f828abdd9d3  pop r9
00007f828abdd9d5  pop r8
00007f828abdd9d7  pop rsi
00007f828abdd9d8  pop rdi
00007f828abdd9d9  pop rdx
00007f828abdd9da  pop rcx
00007f828abdd9db  pop rax
00007f828abdd9dc  add rsp, 0x08
00007f828abdd9e0  jmp 0x00007F828ABDBE87
00007f828abdd9e5  sub rsp, 0x08
00007f828abdd9e9  push rax
00007f828abdd9ea  push rcx
00007f828abdd9eb  push rdx
00007f828abdd9ec  push rdi
00007f828abdd9ed  push rsi
00007f828abdd9ee  push r8
00007f828abdd9f0  push r9
00007f828abdd9f2  push r10
00007f828abdd9f4  push r11
00007f828abdd9f6  sub rsp, 0xF0
00007f828abdd9fd  vmovaps [rsp], xmm0
00007f828abdda02  vmovaps [rsp+0x10], xmm1
00007f828abdda08  vmovaps [rsp+0x20], xmm2
00007f828abdda0e  vmovaps [rsp+0x30], xmm3
00007f828abdda14  vmovaps [rsp+0x40], xmm5
00007f828abdda1a  vmovaps [rsp+0x50], xmm6
00007f828abdda20  vmovaps [rsp+0x60], xmm7
00007f828abdda26  vmovaps [rsp+0x70], xmm8
00007f828abdda2c  vmovaps [rsp+0x80], xmm9
00007f828abdda35  vmovaps [rsp+0x90], xmm10
00007f828abdda3e  vmovaps [rsp+0xA0], xmm11
00007f828abdda47  vmovaps [rsp+0xB0], xmm12
00007f828abdda50  vmovaps [rsp+0xC0], xmm13
00007f828abdda59  vmovaps [rsp+0xD0], xmm14
00007f828abdda62  vmovaps [rsp+0xE0], xmm15
00007f828abdda6b  sub rsp, 0x30
00007f828abdda6f  movaps [rsp], xmm4
00007f828abdda73  movaps [rsp+0x10], xmm15
00007f828abdda79  movaps [rsp+0x20], xmm9
00007f828abdda7f  lea rdi, [rsp]
00007f828abdda83  mov esi, 0x00
00007f828abdda88  mov rax, 0x5BFE27FA6530
00007f828abdda92  call rax
00007f828abdda94  movaps xmm4, [rsp]
00007f828abdda98  add rsp, 0x30
00007f828abdda9c  vmovaps xmm0, [rsp]
00007f828abddaa1  vmovaps xmm1, [rsp+0x10]
00007f828abddaa7  vmovaps xmm2, [rsp+0x20]
00007f828abddaad  vmovaps xmm3, [rsp+0x30]
00007f828abddab3  vmovaps xmm5, [rsp+0x40]
00007f828abddab9  vmovaps xmm6, [rsp+0x50]
00007f828abddabf  vmovaps xmm7, [rsp+0x60]
00007f828abddac5  vmovaps xmm8, [rsp+0x70]
00007f828abddacb  vmovaps xmm9, [rsp+0x80]
00007f828abddad4  vmovaps xmm10, [rsp+0x90]
00007f828abddadd  vmovaps xmm11, [rsp+0xA0]
00007f828abddae6  vmovaps xmm12, [rsp+0xB0]
00007f828abddaef  vmovaps xmm13, [rsp+0xC0]
00007f828abddaf8  vmovaps xmm14, [rsp+0xD0]
00007f828abddb01  vmovaps xmm15, [rsp+0xE0]
00007f828abddb0a  add rsp, 0xF0
00007f828abddb11  pop r11
00007f828abddb13  pop r10
00007f828abddb15  pop r9
00007f828abddb17  pop r8
00007f828abddb19  pop rsi
00007f828abddb1a  pop rdi
00007f828abddb1b  pop rdx
00007f828abddb1c  pop rcx
00007f828abddb1d  pop rax
00007f828abddb1e  add rsp, 0x08
00007f828abddb22  jmp 0x00007F828ABDBEAC
00007f828abddb27  call 0x00007F828AAC4620
00007f828abddb2c  jmp 0x00007F828ABDBEB9
00007f828abddb31  sub rsp, 0x08
00007f828abddb35  push rax
00007f828abddb36  push rcx
00007f828abddb37  push rdx
00007f828abddb38  push rdi
00007f828abddb39  push rsi
00007f828abddb3a  push r8
00007f828abddb3c  push r9
00007f828abddb3e  push r10
00007f828abddb40  push r11
00007f828abddb42  sub rsp, 0xF0
00007f828abddb49  vmovaps [rsp], xmm0
00007f828abddb4e  vmovaps [rsp+0x10], xmm1
00007f828abddb54  vmovaps [rsp+0x20], xmm2
00007f828abddb5a  vmovaps [rsp+0x30], xmm4
00007f828abddb60  vmovaps [rsp+0x40], xmm5
00007f828abddb66  vmovaps [rsp+0x50], xmm6
00007f828abddb6c  vmovaps [rsp+0x60], xmm7
00007f828abddb72  vmovaps [rsp+0x70], xmm8
00007f828abddb78  vmovaps [rsp+0x80], xmm9
00007f828abddb81  vmovaps [rsp+0x90], xmm10
00007f828abddb8a  vmovaps [rsp+0xA0], xmm11
00007f828abddb93  vmovaps [rsp+0xB0], xmm12
00007f828abddb9c  vmovaps [rsp+0xC0], xmm13
00007f828abddba5  vmovaps [rsp+0xD0], xmm14
00007f828abddbae  vmovaps [rsp+0xE0], xmm15
00007f828abddbb7  sub rsp, 0x30
00007f828abddbbb  movaps [rsp], xmm3
00007f828abddbbf  movaps [rsp+0x10], xmm1
00007f828abddbc4  movaps [rsp+0x20], xmm9
00007f828abddbca  lea rdi, [rsp]
00007f828abddbce  mov esi, 0x00
00007f828abddbd3  mov rax, 0x5BFE27FA6530
00007f828abddbdd  call rax
00007f828abddbdf  movaps xmm3, [rsp]
00007f828abddbe3  add rsp, 0x30
00007f828abddbe7  vmovaps xmm0, [rsp]
00007f828abddbec  vmovaps xmm1, [rsp+0x10]
00007f828abddbf2  vmovaps xmm2, [rsp+0x20]
00007f828abddbf8  vmovaps xmm4, [rsp+0x30]
00007f828abddbfe  vmovaps xmm5, [rsp+0x40]
00007f828abddc04  vmovaps xmm6, [rsp+0x50]
00007f828abddc0a  vmovaps xmm7, [rsp+0x60]
00007f828abddc10  vmovaps xmm8, [rsp+0x70]
00007f828abddc16  vmovaps xmm9, [rsp+0x80]
00007f828abddc1f  vmovaps xmm10, [rsp+0x90]
00007f828abddc28  vmovaps xmm11, [rsp+0xA0]
00007f828abddc31  vmovaps xmm12, [rsp+0xB0]
00007f828abddc3a  vmovaps xmm13, [rsp+0xC0]
00007f828abddc43  vmovaps xmm14, [rsp+0xD0]
00007f828abddc4c  vmovaps xmm15, [rsp+0xE0]
00007f828abddc55  add rsp, 0xF0
00007f828abddc5c  pop r11
00007f828abddc5e  pop r10
00007f828abddc60  pop r9
00007f828abddc62  pop r8
00007f828abddc64  pop rsi
00007f828abddc65  pop rdi
00007f828abddc66  pop rdx
00007f828abddc67  pop rcx
00007f828abddc68  pop rax
00007f828abddc69  add rsp, 0x08
00007f828abddc6d  jmp 0x00007F828ABDBEF6
00007f828abddc72  sub rsp, 0x08
00007f828abddc76  push rax
00007f828abddc77  push rcx
00007f828abddc78  push rdx
00007f828abddc79  push rdi
00007f828abddc7a  push rsi
00007f828abddc7b  push r8
00007f828abddc7d  push r9
00007f828abddc7f  push r10
00007f828abddc81  push r11
00007f828abddc83  sub rsp, 0xF0
00007f828abddc8a  vmovaps [rsp], xmm0
00007f828abddc8f  vmovaps [rsp+0x10], xmm2
00007f828abddc95  vmovaps [rsp+0x20], xmm3
00007f828abddc9b  vmovaps [rsp+0x30], xmm4
00007f828abddca1  vmovaps [rsp+0x40], xmm5
00007f828abddca7  vmovaps [rsp+0x50], xmm6
00007f828abddcad  vmovaps [rsp+0x60], xmm7
00007f828abddcb3  vmovaps [rsp+0x70], xmm8
00007f828abddcb9  vmovaps [rsp+0x80], xmm9
00007f828abddcc2  vmovaps [rsp+0x90], xmm10
00007f828abddccb  vmovaps [rsp+0xA0], xmm11
00007f828abddcd4  vmovaps [rsp+0xB0], xmm12
00007f828abddcdd  vmovaps [rsp+0xC0], xmm13
00007f828abddce6  vmovaps [rsp+0xD0], xmm14
00007f828abddcef  vmovaps [rsp+0xE0], xmm15
00007f828abddcf8  sub rsp, 0x30
00007f828abddcfc  movaps [rsp], xmm1
00007f828abddd00  movaps [rsp+0x10], xmm15
00007f828abddd06  movaps [rsp+0x20], xmm9
00007f828abddd0c  lea rdi, [rsp]
00007f828abddd10  mov esi, 0x00
00007f828abddd15  mov rax, 0x5BFE27FA6530
00007f828abddd1f  call rax
00007f828abddd21  movaps xmm1, [rsp]
00007f828abddd25  add rsp, 0x30
00007f828abddd29  vmovaps xmm0, [rsp]
00007f828abddd2e  vmovaps xmm2, [rsp+0x10]
00007f828abddd34  vmovaps xmm3, [rsp+0x20]
00007f828abddd3a  vmovaps xmm4, [rsp+0x30]
00007f828abddd40  vmovaps xmm5, [rsp+0x40]
00007f828abddd46  vmovaps xmm6, [rsp+0x50]
00007f828abddd4c  vmovaps xmm7, [rsp+0x60]
00007f828abddd52  vmovaps xmm8, [rsp+0x70]
00007f828abddd58  vmovaps xmm9, [rsp+0x80]
00007f828abddd61  vmovaps xmm10, [rsp+0x90]
00007f828abddd6a  vmovaps xmm11, [rsp+0xA0]
00007f828abddd73  vmovaps xmm12, [rsp+0xB0]
00007f828abddd7c  vmovaps xmm13, [rsp+0xC0]
00007f828abddd85  vmovaps xmm14, [rsp+0xD0]
00007f828abddd8e  vmovaps xmm15, [rsp+0xE0]
00007f828abddd97  add rsp, 0xF0
00007f828abddd9e  pop r11
00007f828abddda0  pop r10
00007f828abddda2  pop r9
00007f828abddda4  pop r8
00007f828abddda6  pop rsi
00007f828abddda7  pop rdi
00007f828abddda8  pop rdx
00007f828abddda9  pop rcx
00007f828abdddaa  pop rax
00007f828abdddab  add rsp, 0x08
00007f828abdddaf  jmp 0x00007F828ABDBF7E
00007f828abdddb4  call 0x00007F828AAC4620
00007f828abdddb9  jmp 0x00007F828ABDBF8B
00007f828abdddbe  sub rsp, 0x08
00007f828abdddc2  push rax
00007f828abdddc3  push rcx
00007f828abdddc4  push rdx
00007f828abdddc5  push rdi
00007f828abdddc6  push rsi
00007f828abdddc7  push r8
00007f828abdddc9  push r9
00007f828abdddcb  push r10
00007f828abdddcd  push r11
00007f828abdddcf  sub rsp, 0xF0
00007f828abdddd6  vmovaps [rsp], xmm0
00007f828abddddb  vmovaps [rsp+0x10], xmm2
00007f828abddde1  vmovaps [rsp+0x20], xmm3
00007f828abddde7  vmovaps [rsp+0x30], xmm4
00007f828abddded  vmovaps [rsp+0x40], xmm5
00007f828abdddf3  vmovaps [rsp+0x50], xmm6
00007f828abdddf9  vmovaps [rsp+0x60], xmm7
00007f828abdddff  vmovaps [rsp+0x70], xmm8
00007f828abdde05  vmovaps [rsp+0x80], xmm9
00007f828abdde0e  vmovaps [rsp+0x90], xmm10
00007f828abdde17  vmovaps [rsp+0xA0], xmm11
00007f828abdde20  vmovaps [rsp+0xB0], xmm12
00007f828abdde29  vmovaps [rsp+0xC0], xmm13
00007f828abdde32  vmovaps [rsp+0xD0], xmm14
00007f828abdde3b  vmovaps [rsp+0xE0], xmm15
00007f828abdde44  sub rsp, 0x30
00007f828abdde48  movaps [rsp], xmm1
00007f828abdde4c  movaps [rsp+0x10], xmm5
00007f828abdde51  movaps [rsp+0x20], xmm7
00007f828abdde56  lea rdi, [rsp]
00007f828abdde5a  mov esi, 0x00
00007f828abdde5f  mov rax, 0x5BFE27FA6530
00007f828abdde69  call rax
00007f828abdde6b  movaps xmm1, [rsp]
00007f828abdde6f  add rsp, 0x30
00007f828abdde73  vmovaps xmm0, [rsp]
00007f828abdde78  vmovaps xmm2, [rsp+0x10]
00007f828abdde7e  vmovaps xmm3, [rsp+0x20]
00007f828abdde84  vmovaps xmm4, [rsp+0x30]
00007f828abdde8a  vmovaps xmm5, [rsp+0x40]
00007f828abdde90  vmovaps xmm6, [rsp+0x50]
00007f828abdde96  vmovaps xmm7, [rsp+0x60]
00007f828abdde9c  vmovaps xmm8, [rsp+0x70]
00007f828abddea2  vmovaps xmm9, [rsp+0x80]
00007f828abddeab  vmovaps xmm10, [rsp+0x90]
00007f828abddeb4  vmovaps xmm11, [rsp+0xA0]
00007f828abddebd  vmovaps xmm12, [rsp+0xB0]
00007f828abddec6  vmovaps xmm13, [rsp+0xC0]
00007f828abddecf  vmovaps xmm14, [rsp+0xD0]
00007f828abdded8  vmovaps xmm15, [rsp+0xE0]
00007f828abddee1  add rsp, 0xF0
00007f828abddee8  pop r11
00007f828abddeea  pop r10
00007f828abddeec  pop r9
00007f828abddeee  pop r8
00007f828abddef0  pop rsi
00007f828abddef1  pop rdi
00007f828abddef2  pop rdx
00007f828abddef3  pop rcx
00007f828abddef4  pop rax
00007f828abddef5  add rsp, 0x08
00007f828abddef9  jmp 0x00007F828ABDC030
00007f828abddefe  sub rsp, 0x08
00007f828abddf02  push rax
00007f828abddf03  push rcx
00007f828abddf04  push rdx
00007f828abddf05  push rdi
00007f828abddf06  push rsi
00007f828abddf07  push r8
00007f828abddf09  push r9
00007f828abddf0b  push r10
00007f828abddf0d  push r11
00007f828abddf0f  sub rsp, 0xF0
00007f828abddf16  vmovaps [rsp], xmm0
00007f828abddf1b  vmovaps [rsp+0x10], xmm1
00007f828abddf21  vmovaps [rsp+0x20], xmm2
00007f828abddf27  vmovaps [rsp+0x30], xmm3
00007f828abddf2d  vmovaps [rsp+0x40], xmm4
00007f828abddf33  vmovaps [rsp+0x50], xmm5
00007f828abddf39  vmovaps [rsp+0x60], xmm6
00007f828abddf3f  vmovaps [rsp+0x70], xmm8
00007f828abddf45  vmovaps [rsp+0x80], xmm9
00007f828abddf4e  vmovaps [rsp+0x90], xmm10
00007f828abddf57  vmovaps [rsp+0xA0], xmm11
00007f828abddf60  vmovaps [rsp+0xB0], xmm12
00007f828abddf69  vmovaps [rsp+0xC0], xmm13
00007f828abddf72  vmovaps [rsp+0xD0], xmm14
00007f828abddf7b  vmovaps [rsp+0xE0], xmm15
00007f828abddf84  sub rsp, 0x30
00007f828abddf88  movaps [rsp], xmm7
00007f828abddf8c  movaps [rsp+0x10], xmm5
00007f828abddf91  movaps [rsp+0x20], xmm15
00007f828abddf97  lea rdi, [rsp]
00007f828abddf9b  mov esi, 0x00
00007f828abddfa0  mov rax, 0x5BFE27FA6530
00007f828abddfaa  call rax
00007f828abddfac  movaps xmm7, [rsp]
00007f828abddfb0  add rsp, 0x30
00007f828abddfb4  vmovaps xmm0, [rsp]
00007f828abddfb9  vmovaps xmm1, [rsp+0x10]
00007f828abddfbf  vmovaps xmm2, [rsp+0x20]
00007f828abddfc5  vmovaps xmm3, [rsp+0x30]
00007f828abddfcb  vmovaps xmm4, [rsp+0x40]
00007f828abddfd1  vmovaps xmm5, [rsp+0x50]
00007f828abddfd7  vmovaps xmm6, [rsp+0x60]
00007f828abddfdd  vmovaps xmm8, [rsp+0x70]
00007f828abddfe3  vmovaps xmm9, [rsp+0x80]
00007f828abddfec  vmovaps xmm10, [rsp+0x90]
00007f828abddff5  vmovaps xmm11, [rsp+0xA0]
00007f828abddffe  vmovaps xmm12, [rsp+0xB0]
00007f828abde007  vmovaps xmm13, [rsp+0xC0]
00007f828abde010  vmovaps xmm14, [rsp+0xD0]
00007f828abde019  vmovaps xmm15, [rsp+0xE0]
00007f828abde022  add rsp, 0xF0
00007f828abde029  pop r11
00007f828abde02b  pop r10
00007f828abde02d  pop r9
00007f828abde02f  pop r8
00007f828abde031  pop rsi
00007f828abde032  pop rdi
00007f828abde033  pop rdx
00007f828abde034  pop rcx
00007f828abde035  pop rax
00007f828abde036  add rsp, 0x08
00007f828abde03a  jmp 0x00007F828ABDC066
00007f828abde03f  call 0x00007F828AAB52F0
00007f828abde044  jmp 0x00007F828ABDC073
00007f828abde049  sub rsp, 0x08
00007f828abde04d  push rax
00007f828abde04e  push rcx
00007f828abde04f  push rdx
00007f828abde050  push rdi
00007f828abde051  push rsi
00007f828abde052  push r8
00007f828abde054  push r9
00007f828abde056  push r10
00007f828abde058  push r11
00007f828abde05a  sub rsp, 0xF0
00007f828abde061  vmovaps [rsp], xmm0
00007f828abde066  vmovaps [rsp+0x10], xmm1
00007f828abde06c  vmovaps [rsp+0x20], xmm2
00007f828abde072  vmovaps [rsp+0x30], xmm3
00007f828abde078  vmovaps [rsp+0x40], xmm4
00007f828abde07e  vmovaps [rsp+0x50], xmm5
00007f828abde084  vmovaps [rsp+0x60], xmm6
00007f828abde08a  vmovaps [rsp+0x70], xmm7
00007f828abde090  vmovaps [rsp+0x80], xmm8
00007f828abde099  vmovaps [rsp+0x90], xmm9
00007f828abde0a2  vmovaps [rsp+0xA0], xmm10
00007f828abde0ab  vmovaps [rsp+0xB0], xmm11
00007f828abde0b4  vmovaps [rsp+0xC0], xmm12
00007f828abde0bd  vmovaps [rsp+0xD0], xmm13
00007f828abde0c6  vmovaps [rsp+0xE0], xmm14
00007f828abde0cf  sub rsp, 0x30
00007f828abde0d3  movaps [rsp], xmm15
00007f828abde0d8  movaps [rsp+0x10], xmm5
00007f828abde0dd  movaps [rsp+0x20], xmm3
00007f828abde0e2  lea rdi, [rsp]
00007f828abde0e6  mov esi, 0x00
00007f828abde0eb  mov rax, 0x5BFE27FA6530
00007f828abde0f5  call rax
00007f828abde0f7  movaps xmm15, [rsp]
00007f828abde0fc  add rsp, 0x30
00007f828abde100  vmovaps xmm0, [rsp]
00007f828abde105  vmovaps xmm1, [rsp+0x10]
00007f828abde10b  vmovaps xmm2, [rsp+0x20]
00007f828abde111  vmovaps xmm3, [rsp+0x30]
00007f828abde117  vmovaps xmm4, [rsp+0x40]
00007f828abde11d  vmovaps xmm5, [rsp+0x50]
00007f828abde123  vmovaps xmm6, [rsp+0x60]
00007f828abde129  vmovaps xmm7, [rsp+0x70]
00007f828abde12f  vmovaps xmm8, [rsp+0x80]
00007f828abde138  vmovaps xmm9, [rsp+0x90]
00007f828abde141  vmovaps xmm10, [rsp+0xA0]
00007f828abde14a  vmovaps xmm11, [rsp+0xB0]
00007f828abde153  vmovaps xmm12, [rsp+0xC0]
00007f828abde15c  vmovaps xmm13, [rsp+0xD0]
00007f828abde165  vmovaps xmm14, [rsp+0xE0]
00007f828abde16e  add rsp, 0xF0
00007f828abde175  pop r11
00007f828abde177  pop r10
00007f828abde179  pop r9
00007f828abde17b  pop r8
00007f828abde17d  pop rsi
00007f828abde17e  pop rdi
00007f828abde17f  pop rdx
00007f828abde180  pop rcx
00007f828abde181  pop rax
00007f828abde182  add rsp, 0x08
00007f828abde186  jmp 0x00007F828ABDC099
00007f828abde18b  sub rsp, 0x08
00007f828abde18f  push rax
00007f828abde190  push rcx
00007f828abde191  push rdx
00007f828abde192  push rdi
00007f828abde193  push rsi
00007f828abde194  push r8
00007f828abde196  push r9
00007f828abde198  push r10
00007f828abde19a  push r11
00007f828abde19c  sub rsp, 0xF0
00007f828abde1a3  vmovaps [rsp], xmm0
00007f828abde1a8  vmovaps [rsp+0x10], xmm2
00007f828abde1ae  vmovaps [rsp+0x20], xmm3
00007f828abde1b4  vmovaps [rsp+0x30], xmm4
00007f828abde1ba  vmovaps [rsp+0x40], xmm5
00007f828abde1c0  vmovaps [rsp+0x50], xmm6
00007f828abde1c6  vmovaps [rsp+0x60], xmm7
00007f828abde1cc  vmovaps [rsp+0x70], xmm8
00007f828abde1d2  vmovaps [rsp+0x80], xmm9
00007f828abde1db  vmovaps [rsp+0x90], xmm10
00007f828abde1e4  vmovaps [rsp+0xA0], xmm11
00007f828abde1ed  vmovaps [rsp+0xB0], xmm12
00007f828abde1f6  vmovaps [rsp+0xC0], xmm13
00007f828abde1ff  vmovaps [rsp+0xD0], xmm14
00007f828abde208  vmovaps [rsp+0xE0], xmm15
00007f828abde211  sub rsp, 0x30
00007f828abde215  movaps [rsp], xmm1
00007f828abde219  movaps [rsp+0x10], xmm5
00007f828abde21e  movaps [rsp+0x20], xmm4
00007f828abde223  lea rdi, [rsp]
00007f828abde227  mov esi, 0x00
00007f828abde22c  mov rax, 0x5BFE27FA6530
00007f828abde236  call rax
00007f828abde238  movaps xmm1, [rsp]
00007f828abde23c  add rsp, 0x30
00007f828abde240  vmovaps xmm0, [rsp]
00007f828abde245  vmovaps xmm2, [rsp+0x10]
00007f828abde24b  vmovaps xmm3, [rsp+0x20]
00007f828abde251  vmovaps xmm4, [rsp+0x30]
00007f828abde257  vmovaps xmm5, [rsp+0x40]
00007f828abde25d  vmovaps xmm6, [rsp+0x50]
00007f828abde263  vmovaps xmm7, [rsp+0x60]
00007f828abde269  vmovaps xmm8, [rsp+0x70]
00007f828abde26f  vmovaps xmm9, [rsp+0x80]
00007f828abde278  vmovaps xmm10, [rsp+0x90]
00007f828abde281  vmovaps xmm11, [rsp+0xA0]
00007f828abde28a  vmovaps xmm12, [rsp+0xB0]
00007f828abde293  vmovaps xmm13, [rsp+0xC0]
00007f828abde29c  vmovaps xmm14, [rsp+0xD0]
00007f828abde2a5  vmovaps xmm15, [rsp+0xE0]
00007f828abde2ae  add rsp, 0xF0
00007f828abde2b5  pop r11
00007f828abde2b7  pop r10
00007f828abde2b9  pop r9
00007f828abde2bb  pop r8
00007f828abde2bd  pop rsi
00007f828abde2be  pop rdi
00007f828abde2bf  pop rdx
00007f828abde2c0  pop rcx
00007f828abde2c1  pop rax
00007f828abde2c2  add rsp, 0x08
00007f828abde2c6  jmp 0x00007F828ABDC0B9
00007f828abde2cb  sub rsp, 0x08
00007f828abde2cf  push rax
00007f828abde2d0  push rcx
00007f828abde2d1  push rdx
00007f828abde2d2  push rdi
00007f828abde2d3  push rsi
00007f828abde2d4  push r8
00007f828abde2d6  push r9
00007f828abde2d8  push r10
00007f828abde2da  push r11
00007f828abde2dc  sub rsp, 0xF0
00007f828abde2e3  vmovaps [rsp], xmm0
00007f828abde2e8  vmovaps [rsp+0x10], xmm1
00007f828abde2ee  vmovaps [rsp+0x20], xmm2
00007f828abde2f4  vmovaps [rsp+0x30], xmm3
00007f828abde2fa  vmovaps [rsp+0x40], xmm5
00007f828abde300  vmovaps [rsp+0x50], xmm6
00007f828abde306  vmovaps [rsp+0x60], xmm7
00007f828abde30c  vmovaps [rsp+0x70], xmm8
00007f828abde312  vmovaps [rsp+0x80], xmm9
00007f828abde31b  vmovaps [rsp+0x90], xmm10
00007f828abde324  vmovaps [rsp+0xA0], xmm11
00007f828abde32d  vmovaps [rsp+0xB0], xmm12
00007f828abde336  vmovaps [rsp+0xC0], xmm13
00007f828abde33f  vmovaps [rsp+0xD0], xmm14
00007f828abde348  vmovaps [rsp+0xE0], xmm15
00007f828abde351  sub rsp, 0x30
00007f828abde355  movaps [rsp], xmm4
00007f828abde359  movaps [rsp+0x10], xmm3
00007f828abde35e  movaps [rsp+0x20], xmm5
00007f828abde363  lea rdi, [rsp]
00007f828abde367  mov esi, 0x00
00007f828abde36c  mov rax, 0x5BFE27FA6530
00007f828abde376  call rax
00007f828abde378  movaps xmm4, [rsp]
00007f828abde37c  add rsp, 0x30
00007f828abde380  vmovaps xmm0, [rsp]
00007f828abde385  vmovaps xmm1, [rsp+0x10]
00007f828abde38b  vmovaps xmm2, [rsp+0x20]
00007f828abde391  vmovaps xmm3, [rsp+0x30]
00007f828abde397  vmovaps xmm5, [rsp+0x40]
00007f828abde39d  vmovaps xmm6, [rsp+0x50]
00007f828abde3a3  vmovaps xmm7, [rsp+0x60]
00007f828abde3a9  vmovaps xmm8, [rsp+0x70]
00007f828abde3af  vmovaps xmm9, [rsp+0x80]
00007f828abde3b8  vmovaps xmm10, [rsp+0x90]
00007f828abde3c1  vmovaps xmm11, [rsp+0xA0]
00007f828abde3ca  vmovaps xmm12, [rsp+0xB0]
00007f828abde3d3  vmovaps xmm13, [rsp+0xC0]
00007f828abde3dc  vmovaps xmm14, [rsp+0xD0]
00007f828abde3e5  vmovaps xmm15, [rsp+0xE0]
00007f828abde3ee  add rsp, 0xF0
00007f828abde3f5  pop r11
00007f828abde3f7  pop r10
00007f828abde3f9  pop r9
00007f828abde3fb  pop r8
00007f828abde3fd  pop rsi
00007f828abde3fe  pop rdi
00007f828abde3ff  pop rdx
00007f828abde400  pop rcx
00007f828abde401  pop rax
00007f828abde402  add rsp, 0x08
00007f828abde406  jmp 0x00007F828ABDC107
00007f828abde40b  call 0x00007F828AAB52F0
00007f828abde410  jmp 0x00007F828ABDC114
00007f828abde415  sub rsp, 0x08
00007f828abde419  push rax
00007f828abde41a  push rcx
00007f828abde41b  push rdx
00007f828abde41c  push rdi
00007f828abde41d  push rsi
00007f828abde41e  push r8
00007f828abde420  push r9
00007f828abde422  push r10
00007f828abde424  push r11
00007f828abde426  sub rsp, 0xF0
00007f828abde42d  vmovaps [rsp], xmm0
00007f828abde432  vmovaps [rsp+0x10], xmm1
00007f828abde438  vmovaps [rsp+0x20], xmm2
00007f828abde43e  vmovaps [rsp+0x30], xmm3
00007f828abde444  vmovaps [rsp+0x40], xmm4
00007f828abde44a  vmovaps [rsp+0x50], xmm6
00007f828abde450  vmovaps [rsp+0x60], xmm7
00007f828abde456  vmovaps [rsp+0x70], xmm8
00007f828abde45c  vmovaps [rsp+0x80], xmm9
00007f828abde465  vmovaps [rsp+0x90], xmm10
00007f828abde46e  vmovaps [rsp+0xA0], xmm11
00007f828abde477  vmovaps [rsp+0xB0], xmm12
00007f828abde480  vmovaps [rsp+0xC0], xmm13
00007f828abde489  vmovaps [rsp+0xD0], xmm14
00007f828abde492  vmovaps [rsp+0xE0], xmm15
00007f828abde49b  sub rsp, 0x30
00007f828abde49f  movaps [rsp], xmm5
00007f828abde4a3  movaps [rsp+0x10], xmm6
00007f828abde4a8  movaps [rsp+0x20], xmm3
00007f828abde4ad  lea rdi, [rsp]
00007f828abde4b1  mov esi, 0x00
00007f828abde4b6  mov rax, 0x5BFE27FA6530
00007f828abde4c0  call rax
00007f828abde4c2  movaps xmm5, [rsp]
00007f828abde4c6  add rsp, 0x30
00007f828abde4ca  vmovaps xmm0, [rsp]
00007f828abde4cf  vmovaps xmm1, [rsp+0x10]
00007f828abde4d5  vmovaps xmm2, [rsp+0x20]
00007f828abde4db  vmovaps xmm3, [rsp+0x30]
00007f828abde4e1  vmovaps xmm4, [rsp+0x40]
00007f828abde4e7  vmovaps xmm6, [rsp+0x50]
00007f828abde4ed  vmovaps xmm7, [rsp+0x60]
00007f828abde4f3  vmovaps xmm8, [rsp+0x70]
00007f828abde4f9  vmovaps xmm9, [rsp+0x80]
00007f828abde502  vmovaps xmm10, [rsp+0x90]
00007f828abde50b  vmovaps xmm11, [rsp+0xA0]
00007f828abde514  vmovaps xmm12, [rsp+0xB0]
00007f828abde51d  vmovaps xmm13, [rsp+0xC0]
00007f828abde526  vmovaps xmm14, [rsp+0xD0]
00007f828abde52f  vmovaps xmm15, [rsp+0xE0]
00007f828abde538  add rsp, 0xF0
00007f828abde53f  pop r11
00007f828abde541  pop r10
00007f828abde543  pop r9
00007f828abde545  pop r8
00007f828abde547  pop rsi
00007f828abde548  pop rdi
00007f828abde549  pop rdx
00007f828abde54a  pop rcx
00007f828abde54b  pop rax
00007f828abde54c  add rsp, 0x08
00007f828abde550  jmp 0x00007F828ABDC13A
00007f828abde555  sub rsp, 0x08
00007f828abde559  push rax
00007f828abde55a  push rcx
00007f828abde55b  push rdx
00007f828abde55c  push rdi
00007f828abde55d  push rsi
00007f828abde55e  push r8
00007f828abde560  push r9
00007f828abde562  push r10
00007f828abde564  push r11
00007f828abde566  sub rsp, 0xF0
00007f828abde56d  vmovaps [rsp], xmm0
00007f828abde572  vmovaps [rsp+0x10], xmm1
00007f828abde578  vmovaps [rsp+0x20], xmm2
00007f828abde57e  vmovaps [rsp+0x30], xmm3
00007f828abde584  vmovaps [rsp+0x40], xmm4
00007f828abde58a  vmovaps [rsp+0x50], xmm5
00007f828abde590  vmovaps [rsp+0x60], xmm7
00007f828abde596  vmovaps [rsp+0x70], xmm8
00007f828abde59c  vmovaps [rsp+0x80], xmm9
00007f828abde5a5  vmovaps [rsp+0x90], xmm10
00007f828abde5ae  vmovaps [rsp+0xA0], xmm11
00007f828abde5b7  vmovaps [rsp+0xB0], xmm12
00007f828abde5c0  vmovaps [rsp+0xC0], xmm13
00007f828abde5c9  vmovaps [rsp+0xD0], xmm14
00007f828abde5d2  vmovaps [rsp+0xE0], xmm15
00007f828abde5db  sub rsp, 0x30
00007f828abde5df  movaps [rsp], xmm6
00007f828abde5e3  movaps [rsp+0x10], xmm9
00007f828abde5e9  movaps [rsp+0x20], xmm1
00007f828abde5ee  lea rdi, [rsp]
00007f828abde5f2  mov esi, 0x00
00007f828abde5f7  mov rax, 0x5BFE27FA6530
00007f828abde601  call rax
00007f828abde603  movaps xmm6, [rsp]
00007f828abde607  add rsp, 0x30
00007f828abde60b  vmovaps xmm0, [rsp]
00007f828abde610  vmovaps xmm1, [rsp+0x10]
00007f828abde616  vmovaps xmm2, [rsp+0x20]
00007f828abde61c  vmovaps xmm3, [rsp+0x30]
00007f828abde622  vmovaps xmm4, [rsp+0x40]
00007f828abde628  vmovaps xmm5, [rsp+0x50]
00007f828abde62e  vmovaps xmm7, [rsp+0x60]
00007f828abde634  vmovaps xmm8, [rsp+0x70]
00007f828abde63a  vmovaps xmm9, [rsp+0x80]
00007f828abde643  vmovaps xmm10, [rsp+0x90]
00007f828abde64c  vmovaps xmm11, [rsp+0xA0]
00007f828abde655  vmovaps xmm12, [rsp+0xB0]
00007f828abde65e  vmovaps xmm13, [rsp+0xC0]
00007f828abde667  vmovaps xmm14, [rsp+0xD0]
00007f828abde670  vmovaps xmm15, [rsp+0xE0]
00007f828abde679  add rsp, 0xF0
00007f828abde680  pop r11
00007f828abde682  pop r10
00007f828abde684  pop r9
00007f828abde686  pop r8
00007f828abde688  pop rsi
00007f828abde689  pop rdi
00007f828abde68a  pop rdx
00007f828abde68b  pop rcx
00007f828abde68c  pop rax
00007f828abde68d  add rsp, 0x08
00007f828abde691  jmp 0x00007F828ABDC15E
00007f828abde696  sub rsp, 0x08
00007f828abde69a  push rax
00007f828abde69b  push rcx
00007f828abde69c  push rdx
00007f828abde69d  push rdi
00007f828abde69e  push rsi
00007f828abde69f  push r8
00007f828abde6a1  push r9
00007f828abde6a3  push r10
00007f828abde6a5  push r11
00007f828abde6a7  sub rsp, 0xF0
00007f828abde6ae  vmovaps [rsp], xmm0
00007f828abde6b3  vmovaps [rsp+0x10], xmm1
00007f828abde6b9  vmovaps [rsp+0x20], xmm2
00007f828abde6bf  vmovaps [rsp+0x30], xmm3
00007f828abde6c5  vmovaps [rsp+0x40], xmm4
00007f828abde6cb  vmovaps [rsp+0x50], xmm5
00007f828abde6d1  vmovaps [rsp+0x60], xmm6
00007f828abde6d7  vmovaps [rsp+0x70], xmm7
00007f828abde6dd  vmovaps [rsp+0x80], xmm8
00007f828abde6e6  vmovaps [rsp+0x90], xmm10
00007f828abde6ef  vmovaps [rsp+0xA0], xmm11
00007f828abde6f8  vmovaps [rsp+0xB0], xmm12
00007f828abde701  vmovaps [rsp+0xC0], xmm13
00007f828abde70a  vmovaps [rsp+0xD0], xmm14
00007f828abde713  vmovaps [rsp+0xE0], xmm15
00007f828abde71c  sub rsp, 0x30
00007f828abde720  movaps [rsp], xmm9
00007f828abde725  movaps [rsp+0x10], xmm3
00007f828abde72a  movaps [rsp+0x20], xmm1
00007f828abde72f  lea rdi, [rsp]
00007f828abde733  mov esi, 0x00
00007f828abde738  mov rax, 0x5BFE27FA6530
00007f828abde742  call rax
00007f828abde744  movaps xmm9, [rsp]
00007f828abde749  add rsp, 0x30
00007f828abde74d  vmovaps xmm0, [rsp]
00007f828abde752  vmovaps xmm1, [rsp+0x10]
00007f828abde758  vmovaps xmm2, [rsp+0x20]
00007f828abde75e  vmovaps xmm3, [rsp+0x30]
00007f828abde764  vmovaps xmm4, [rsp+0x40]
00007f828abde76a  vmovaps xmm5, [rsp+0x50]
00007f828abde770  vmovaps xmm6, [rsp+0x60]
00007f828abde776  vmovaps xmm7, [rsp+0x70]
00007f828abde77c  vmovaps xmm8, [rsp+0x80]
00007f828abde785  vmovaps xmm10, [rsp+0x90]
00007f828abde78e  vmovaps xmm11, [rsp+0xA0]
00007f828abde797  vmovaps xmm12, [rsp+0xB0]
00007f828abde7a0  vmovaps xmm13, [rsp+0xC0]
00007f828abde7a9  vmovaps xmm14, [rsp+0xD0]
00007f828abde7b2  vmovaps xmm15, [rsp+0xE0]
00007f828abde7bb  add rsp, 0xF0
00007f828abde7c2  pop r11
00007f828abde7c4  pop r10
00007f828abde7c6  pop r9
00007f828abde7c8  pop r8
00007f828abde7ca  pop rsi
00007f828abde7cb  pop rdi
00007f828abde7cc  pop rdx
00007f828abde7cd  pop rcx
00007f828abde7ce  pop rax
00007f828abde7cf  add rsp, 0x08
00007f828abde7d3  jmp 0x00007F828ABDC1AA
00007f828abde7d8  call 0x00007F828AAB52F0
00007f828abde7dd  jmp 0x00007F828ABDC1B7
00007f828abde7e2  sub rsp, 0x08
00007f828abde7e6  push rax
00007f828abde7e7  push rcx
00007f828abde7e8  push rdx
00007f828abde7e9  push rdi
00007f828abde7ea  push rsi
00007f828abde7eb  push r8
00007f828abde7ed  push r9
00007f828abde7ef  push r10
00007f828abde7f1  push r11
00007f828abde7f3  sub rsp, 0xF0
00007f828abde7fa  vmovaps [rsp], xmm0
00007f828abde7ff  vmovaps [rsp+0x10], xmm1
00007f828abde805  vmovaps [rsp+0x20], xmm2
00007f828abde80b  vmovaps [rsp+0x30], xmm3
00007f828abde811  vmovaps [rsp+0x40], xmm4
00007f828abde817  vmovaps [rsp+0x50], xmm5
00007f828abde81d  vmovaps [rsp+0x60], xmm6
00007f828abde823  vmovaps [rsp+0x70], xmm7
00007f828abde829  vmovaps [rsp+0x80], xmm8
00007f828abde832  vmovaps [rsp+0x90], xmm9
00007f828abde83b  vmovaps [rsp+0xA0], xmm10
00007f828abde844  vmovaps [rsp+0xB0], xmm11
00007f828abde84d  vmovaps [rsp+0xC0], xmm12
00007f828abde856  vmovaps [rsp+0xD0], xmm13
00007f828abde85f  vmovaps [rsp+0xE0], xmm14
00007f828abde868  sub rsp, 0x30
00007f828abde86c  movaps [rsp], xmm15
00007f828abde871  movaps [rsp+0x10], xmm3
00007f828abde876  movaps [rsp+0x20], xmm7
00007f828abde87b  lea rdi, [rsp]
00007f828abde87f  mov esi, 0x00
00007f828abde884  mov rax, 0x5BFE27FA6530
00007f828abde88e  call rax
00007f828abde890  movaps xmm15, [rsp]
00007f828abde895  add rsp, 0x30
00007f828abde899  vmovaps xmm0, [rsp]
00007f828abde89e  vmovaps xmm1, [rsp+0x10]
00007f828abde8a4  vmovaps xmm2, [rsp+0x20]
00007f828abde8aa  vmovaps xmm3, [rsp+0x30]
00007f828abde8b0  vmovaps xmm4, [rsp+0x40]
00007f828abde8b6  vmovaps xmm5, [rsp+0x50]
00007f828abde8bc  vmovaps xmm6, [rsp+0x60]
00007f828abde8c2  vmovaps xmm7, [rsp+0x70]
00007f828abde8c8  vmovaps xmm8, [rsp+0x80]
00007f828abde8d1  vmovaps xmm9, [rsp+0x90]
00007f828abde8da  vmovaps xmm10, [rsp+0xA0]
00007f828abde8e3  vmovaps xmm11, [rsp+0xB0]
00007f828abde8ec  vmovaps xmm12, [rsp+0xC0]
00007f828abde8f5  vmovaps xmm13, [rsp+0xD0]
00007f828abde8fe  vmovaps xmm14, [rsp+0xE0]
00007f828abde907  add rsp, 0xF0
00007f828abde90e  pop r11
00007f828abde910  pop r10
00007f828abde912  pop r9
00007f828abde914  pop r8
00007f828abde916  pop rsi
00007f828abde917  pop rdi
00007f828abde918  pop rdx
00007f828abde919  pop rcx
00007f828abde91a  pop rax
00007f828abde91b  add rsp, 0x08
00007f828abde91f  jmp 0x00007F828ABDC1E3
00007f828abde924  sub rsp, 0x08
00007f828abde928  push rax
00007f828abde929  push rcx
00007f828abde92a  push rdx
00007f828abde92b  push rdi
00007f828abde92c  push rsi
00007f828abde92d  push r8
00007f828abde92f  push r9
00007f828abde931  push r10
00007f828abde933  push r11
00007f828abde935  sub rsp, 0xF0
00007f828abde93c  vmovaps [rsp], xmm0
00007f828abde941  vmovaps [rsp+0x10], xmm1
00007f828abde947  vmovaps [rsp+0x20], xmm2
00007f828abde94d  vmovaps [rsp+0x30], xmm4
00007f828abde953  vmovaps [rsp+0x40], xmm5
00007f828abde959  vmovaps [rsp+0x50], xmm6
00007f828abde95f  vmovaps [rsp+0x60], xmm7
00007f828abde965  vmovaps [rsp+0x70], xmm8
00007f828abde96b  vmovaps [rsp+0x80], xmm9
00007f828abde974  vmovaps [rsp+0x90], xmm10
00007f828abde97d  vmovaps [rsp+0xA0], xmm11
00007f828abde986  vmovaps [rsp+0xB0], xmm12
00007f828abde98f  vmovaps [rsp+0xC0], xmm13
00007f828abde998  vmovaps [rsp+0xD0], xmm14
00007f828abde9a1  vmovaps [rsp+0xE0], xmm15
00007f828abde9aa  sub rsp, 0x30
00007f828abde9ae  movaps [rsp], xmm3
00007f828abde9b2  movaps [rsp+0x10], xmm1
00007f828abde9b7  movaps [rsp+0x20], xmm15
00007f828abde9bd  lea rdi, [rsp]
00007f828abde9c1  mov esi, 0x00
00007f828abde9c6  mov rax, 0x5BFE27FA6530
00007f828abde9d0  call rax
00007f828abde9d2  movaps xmm3, [rsp]
00007f828abde9d6  add rsp, 0x30
00007f828abde9da  vmovaps xmm0, [rsp]
00007f828abde9df  vmovaps xmm1, [rsp+0x10]
00007f828abde9e5  vmovaps xmm2, [rsp+0x20]
00007f828abde9eb  vmovaps xmm4, [rsp+0x30]
00007f828abde9f1  vmovaps xmm5, [rsp+0x40]
00007f828abde9f7  vmovaps xmm6, [rsp+0x50]
00007f828abde9fd  vmovaps xmm7, [rsp+0x60]
00007f828abdea03  vmovaps xmm8, [rsp+0x70]
00007f828abdea09  vmovaps xmm9, [rsp+0x80]
00007f828abdea12  vmovaps xmm10, [rsp+0x90]
00007f828abdea1b  vmovaps xmm11, [rsp+0xA0]
00007f828abdea24  vmovaps xmm12, [rsp+0xB0]
00007f828abdea2d  vmovaps xmm13, [rsp+0xC0]
00007f828abdea36  vmovaps xmm14, [rsp+0xD0]
00007f828abdea3f  vmovaps xmm15, [rsp+0xE0]
00007f828abdea48  add rsp, 0xF0
00007f828abdea4f  pop r11
00007f828abdea51  pop r10
00007f828abdea53  pop r9
00007f828abdea55  pop r8
00007f828abdea57  pop rsi
00007f828abdea58  pop rdi
00007f828abdea59  pop rdx
00007f828abdea5a  pop rcx
00007f828abdea5b  pop rax
00007f828abdea5c  add rsp, 0x08
00007f828abdea60  jmp 0x00007F828ABDC272
00007f828abdea65  call 0x00007F828AAB52F0
00007f828abdea6a  jmp 0x00007F828ABDC27C
00007f828abdea6f  sub rsp, 0x08
00007f828abdea73  push rax
00007f828abdea74  push rcx
00007f828abdea75  push rdx
00007f828abdea76  push rdi
00007f828abdea77  push rsi
00007f828abdea78  push r8
00007f828abdea7a  push r9
00007f828abdea7c  push r10
00007f828abdea7e  push r11
00007f828abdea80  sub rsp, 0xF0
00007f828abdea87  vmovaps [rsp], xmm0
00007f828abdea8c  vmovaps [rsp+0x10], xmm1
00007f828abdea92  vmovaps [rsp+0x20], xmm2
00007f828abdea98  vmovaps [rsp+0x30], xmm3
00007f828abdea9e  vmovaps [rsp+0x40], xmm4
00007f828abdeaa4  vmovaps [rsp+0x50], xmm5
00007f828abdeaaa  vmovaps [rsp+0x60], xmm6
00007f828abdeab0  vmovaps [rsp+0x70], xmm7
00007f828abdeab6  vmovaps [rsp+0x80], xmm8
00007f828abdeabf  vmovaps [rsp+0x90], xmm9
00007f828abdeac8  vmovaps [rsp+0xA0], xmm10
00007f828abdead1  vmovaps [rsp+0xB0], xmm11
00007f828abdeada  vmovaps [rsp+0xC0], xmm12
00007f828abdeae3  vmovaps [rsp+0xD0], xmm13
00007f828abdeaec  vmovaps [rsp+0xE0], xmm14
00007f828abdeaf5  sub rsp, 0x30
00007f828abdeaf9  movaps [rsp], xmm15
00007f828abdeafe  movaps [rsp+0x10], xmm14
00007f828abdeb04  movaps [rsp+0x20], xmm4
00007f828abdeb09  lea rdi, [rsp]
00007f828abdeb0d  mov esi, 0x00
00007f828abdeb12  mov rax, 0x5BFE27FA6530
00007f828abdeb1c  call rax
00007f828abdeb1e  movaps xmm15, [rsp]
00007f828abdeb23  add rsp, 0x30
00007f828abdeb27  vmovaps xmm0, [rsp]
00007f828abdeb2c  vmovaps xmm1, [rsp+0x10]
00007f828abdeb32  vmovaps xmm2, [rsp+0x20]
00007f828abdeb38  vmovaps xmm3, [rsp+0x30]
00007f828abdeb3e  vmovaps xmm4, [rsp+0x40]
00007f828abdeb44  vmovaps xmm5, [rsp+0x50]
00007f828abdeb4a  vmovaps xmm6, [rsp+0x60]
00007f828abdeb50  vmovaps xmm7, [rsp+0x70]
00007f828abdeb56  vmovaps xmm8, [rsp+0x80]
00007f828abdeb5f  vmovaps xmm9, [rsp+0x90]
00007f828abdeb68  vmovaps xmm10, [rsp+0xA0]
00007f828abdeb71  vmovaps xmm11, [rsp+0xB0]
00007f828abdeb7a  vmovaps xmm12, [rsp+0xC0]
00007f828abdeb83  vmovaps xmm13, [rsp+0xD0]
00007f828abdeb8c  vmovaps xmm14, [rsp+0xE0]
00007f828abdeb95  add rsp, 0xF0
00007f828abdeb9c  pop r11
00007f828abdeb9e  pop r10
00007f828abdeba0  pop r9
00007f828abdeba2  pop r8
00007f828abdeba4  pop rsi
00007f828abdeba5  pop rdi
00007f828abdeba6  pop rdx
00007f828abdeba7  pop rcx
00007f828abdeba8  pop rax
00007f828abdeba9  add rsp, 0x08
00007f828abdebad  jmp 0x00007F828ABDC2AA
00007f828abdebb2  sub rsp, 0x08
00007f828abdebb6  push rax
00007f828abdebb7  push rcx
00007f828abdebb8  push rdx
00007f828abdebb9  push rdi
00007f828abdebba  push rsi
00007f828abdebbb  push r8
00007f828abdebbd  push r9
00007f828abdebbf  push r10
00007f828abdebc1  push r11
00007f828abdebc3  sub rsp, 0xF0
00007f828abdebca  vmovaps [rsp], xmm0
00007f828abdebcf  vmovaps [rsp+0x10], xmm1
00007f828abdebd5  vmovaps [rsp+0x20], xmm2
00007f828abdebdb  vmovaps [rsp+0x30], xmm3
00007f828abdebe1  vmovaps [rsp+0x40], xmm4
00007f828abdebe7  vmovaps [rsp+0x50], xmm5
00007f828abdebed  vmovaps [rsp+0x60], xmm6
00007f828abdebf3  vmovaps [rsp+0x70], xmm7
00007f828abdebf9  vmovaps [rsp+0x80], xmm8
00007f828abdec02  vmovaps [rsp+0x90], xmm9
00007f828abdec0b  vmovaps [rsp+0xA0], xmm10
00007f828abdec14  vmovaps [rsp+0xB0], xmm11
00007f828abdec1d  vmovaps [rsp+0xC0], xmm12
00007f828abdec26  vmovaps [rsp+0xD0], xmm13
00007f828abdec2f  vmovaps [rsp+0xE0], xmm15
00007f828abdec38  sub rsp, 0x30
00007f828abdec3c  movaps [rsp], xmm14
00007f828abdec41  movaps [rsp+0x10], xmm2
00007f828abdec46  movaps [rsp+0x20], xmm1
00007f828abdec4b  lea rdi, [rsp]
00007f828abdec4f  mov esi, 0x00
00007f828abdec54  mov rax, 0x5BFE27FA6530
00007f828abdec5e  call rax
00007f828abdec60  movaps xmm14, [rsp]
00007f828abdec65  add rsp, 0x30
00007f828abdec69  vmovaps xmm0, [rsp]
00007f828abdec6e  vmovaps xmm1, [rsp+0x10]
00007f828abdec74  vmovaps xmm2, [rsp+0x20]
00007f828abdec7a  vmovaps xmm3, [rsp+0x30]
00007f828abdec80  vmovaps xmm4, [rsp+0x40]
00007f828abdec86  vmovaps xmm5, [rsp+0x50]
00007f828abdec8c  vmovaps xmm6, [rsp+0x60]
00007f828abdec92  vmovaps xmm7, [rsp+0x70]
00007f828abdec98  vmovaps xmm8, [rsp+0x80]
00007f828abdeca1  vmovaps xmm9, [rsp+0x90]
00007f828abdecaa  vmovaps xmm10, [rsp+0xA0]
00007f828abdecb3  vmovaps xmm11, [rsp+0xB0]
00007f828abdecbc  vmovaps xmm12, [rsp+0xC0]
00007f828abdecc5  vmovaps xmm13, [rsp+0xD0]
00007f828abdecce  vmovaps xmm15, [rsp+0xE0]
00007f828abdecd7  add rsp, 0xF0
00007f828abdecde  pop r11
00007f828abdece0  pop r10
00007f828abdece2  pop r9
00007f828abdece4  pop r8
00007f828abdece6  pop rsi
00007f828abdece7  pop rdi
00007f828abdece8  pop rdx
00007f828abdece9  pop rcx
00007f828abdecea  pop rax
00007f828abdeceb  add rsp, 0x08
00007f828abdecef  jmp 0x00007F828ABDC2D0
00007f828abdecf4  sub rsp, 0x08
00007f828abdecf8  push rax
00007f828abdecf9  push rcx
00007f828abdecfa  push rdx
00007f828abdecfb  push rdi
00007f828abdecfc  push rsi
00007f828abdecfd  push r8
00007f828abdecff  push r9
00007f828abded01  push r10
00007f828abded03  push r11
00007f828abded05  sub rsp, 0xF0
00007f828abded0c  vmovaps [rsp], xmm0
00007f828abded11  vmovaps [rsp+0x10], xmm2
00007f828abded17  vmovaps [rsp+0x20], xmm3
00007f828abded1d  vmovaps [rsp+0x30], xmm4
00007f828abded23  vmovaps [rsp+0x40], xmm5
00007f828abded29  vmovaps [rsp+0x50], xmm6
00007f828abded2f  vmovaps [rsp+0x60], xmm7
00007f828abded35  vmovaps [rsp+0x70], xmm8
00007f828abded3b  vmovaps [rsp+0x80], xmm9
00007f828abded44  vmovaps [rsp+0x90], xmm10
00007f828abded4d  vmovaps [rsp+0xA0], xmm11
00007f828abded56  vmovaps [rsp+0xB0], xmm12
00007f828abded5f  vmovaps [rsp+0xC0], xmm13
00007f828abded68  vmovaps [rsp+0xD0], xmm14
00007f828abded71  vmovaps [rsp+0xE0], xmm15
00007f828abded7a  sub rsp, 0x30
00007f828abded7e  movaps [rsp], xmm1
00007f828abded82  movaps [rsp+0x10], xmm4
00007f828abded87  movaps [rsp+0x20], xmm9
00007f828abded8d  lea rdi, [rsp]
00007f828abded91  mov esi, 0x00
00007f828abded96  mov rax, 0x5BFE27FA6530
00007f828abdeda0  call rax
00007f828abdeda2  movaps xmm1, [rsp]
00007f828abdeda6  add rsp, 0x30
00007f828abdedaa  vmovaps xmm0, [rsp]
00007f828abdedaf  vmovaps xmm2, [rsp+0x10]
00007f828abdedb5  vmovaps xmm3, [rsp+0x20]
00007f828abdedbb  vmovaps xmm4, [rsp+0x30]
00007f828abdedc1  vmovaps xmm5, [rsp+0x40]
00007f828abdedc7  vmovaps xmm6, [rsp+0x50]
00007f828abdedcd  vmovaps xmm7, [rsp+0x60]
00007f828abdedd3  vmovaps xmm8, [rsp+0x70]
00007f828abdedd9  vmovaps xmm9, [rsp+0x80]
00007f828abdede2  vmovaps xmm10, [rsp+0x90]
00007f828abdedeb  vmovaps xmm11, [rsp+0xA0]
00007f828abdedf4  vmovaps xmm12, [rsp+0xB0]
00007f828abdedfd  vmovaps xmm13, [rsp+0xC0]
00007f828abdee06  vmovaps xmm14, [rsp+0xD0]
00007f828abdee0f  vmovaps xmm15, [rsp+0xE0]
00007f828abdee18  add rsp, 0xF0
00007f828abdee1f  pop r11
00007f828abdee21  pop r10
00007f828abdee23  pop r9
00007f828abdee25  pop r8
00007f828abdee27  pop rsi
00007f828abdee28  pop rdi
00007f828abdee29  pop rdx
00007f828abdee2a  pop rcx
00007f828abdee2b  pop rax
00007f828abdee2c  add rsp, 0x08
00007f828abdee30  jmp 0x00007F828ABDC2EE
00007f828abdee35  sub rsp, 0x08
00007f828abdee39  push rax
00007f828abdee3a  push rcx
00007f828abdee3b  push rdx
00007f828abdee3c  push rdi
00007f828abdee3d  push rsi
00007f828abdee3e  push r8
00007f828abdee40  push r9
00007f828abdee42  push r10
00007f828abdee44  push r11
00007f828abdee46  sub rsp, 0xF0
00007f828abdee4d  vmovaps [rsp], xmm0
00007f828abdee52  vmovaps [rsp+0x10], xmm1
00007f828abdee58  vmovaps [rsp+0x20], xmm2
00007f828abdee5e  vmovaps [rsp+0x30], xmm3
00007f828abdee64  vmovaps [rsp+0x40], xmm5
00007f828abdee6a  vmovaps [rsp+0x50], xmm6
00007f828abdee70  vmovaps [rsp+0x60], xmm7
00007f828abdee76  vmovaps [rsp+0x70], xmm8
00007f828abdee7c  vmovaps [rsp+0x80], xmm9
00007f828abdee85  vmovaps [rsp+0x90], xmm10
00007f828abdee8e  vmovaps [rsp+0xA0], xmm11
00007f828abdee97  vmovaps [rsp+0xB0], xmm12
00007f828abdeea0  vmovaps [rsp+0xC0], xmm13
00007f828abdeea9  vmovaps [rsp+0xD0], xmm14
00007f828abdeeb2  vmovaps [rsp+0xE0], xmm15
00007f828abdeebb  sub rsp, 0x30
00007f828abdeebf  movaps [rsp], xmm4
00007f828abdeec3  movaps [rsp+0x10], xmm2
00007f828abdeec8  movaps [rsp+0x20], xmm9
00007f828abdeece  lea rdi, [rsp]
00007f828abdeed2  mov esi, 0x00
00007f828abdeed7  mov rax, 0x5BFE27FA6530
00007f828abdeee1  call rax
00007f828abdeee3  movaps xmm4, [rsp]
00007f828abdeee7  add rsp, 0x30
00007f828abdeeeb  vmovaps xmm0, [rsp]
00007f828abdeef0  vmovaps xmm1, [rsp+0x10]
00007f828abdeef6  vmovaps xmm2, [rsp+0x20]
00007f828abdeefc  vmovaps xmm3, [rsp+0x30]
00007f828abdef02  vmovaps xmm5, [rsp+0x40]
00007f828abdef08  vmovaps xmm6, [rsp+0x50]
00007f828abdef0e  vmovaps xmm7, [rsp+0x60]
00007f828abdef14  vmovaps xmm8, [rsp+0x70]
00007f828abdef1a  vmovaps xmm9, [rsp+0x80]
00007f828abdef23  vmovaps xmm10, [rsp+0x90]
00007f828abdef2c  vmovaps xmm11, [rsp+0xA0]
00007f828abdef35  vmovaps xmm12, [rsp+0xB0]
00007f828abdef3e  vmovaps xmm13, [rsp+0xC0]
00007f828abdef47  vmovaps xmm14, [rsp+0xD0]
00007f828abdef50  vmovaps xmm15, [rsp+0xE0]
00007f828abdef59  add rsp, 0xF0
00007f828abdef60  pop r11
00007f828abdef62  pop r10
00007f828abdef64  pop r9
00007f828abdef66  pop r8
00007f828abdef68  pop rsi
00007f828abdef69  pop rdi
00007f828abdef6a  pop rdx
00007f828abdef6b  pop rcx
00007f828abdef6c  pop rax
00007f828abdef6d  add rsp, 0x08
00007f828abdef71  jmp 0x00007F828ABDC31E
00007f828abdef76  sub rsp, 0x08
00007f828abdef7a  push rax
00007f828abdef7b  push rcx
00007f828abdef7c  push rdx
00007f828abdef7d  push rdi
00007f828abdef7e  push rsi
00007f828abdef7f  push r8
00007f828abdef81  push r9
00007f828abdef83  push r10
00007f828abdef85  push r11
00007f828abdef87  sub rsp, 0xF0
00007f828abdef8e  vmovaps [rsp], xmm0
00007f828abdef93  vmovaps [rsp+0x10], xmm1
00007f828abdef99  vmovaps [rsp+0x20], xmm2
00007f828abdef9f  vmovaps [rsp+0x30], xmm3
00007f828abdefa5  vmovaps [rsp+0x40], xmm4
00007f828abdefab  vmovaps [rsp+0x50], xmm5
00007f828abdefb1  vmovaps [rsp+0x60], xmm6
00007f828abdefb7  vmovaps [rsp+0x70], xmm7
00007f828abdefbd  vmovaps [rsp+0x80], xmm8
00007f828abdefc6  vmovaps [rsp+0x90], xmm10
00007f828abdefcf  vmovaps [rsp+0xA0], xmm11
00007f828abdefd8  vmovaps [rsp+0xB0], xmm12
00007f828abdefe1  vmovaps [rsp+0xC0], xmm13
00007f828abdefea  vmovaps [rsp+0xD0], xmm14
00007f828abdeff3  vmovaps [rsp+0xE0], xmm15
00007f828abdeffc  sub rsp, 0x30
00007f828abdf000  movaps [rsp], xmm9
00007f828abdf005  movaps [rsp+0x10], xmm2
00007f828abdf00a  movaps [rsp+0x20], xmm1
00007f828abdf00f  lea rdi, [rsp]
00007f828abdf013  mov esi, 0x00
00007f828abdf018  mov rax, 0x5BFE27FA6530
00007f828abdf022  call rax
00007f828abdf024  movaps xmm9, [rsp]
00007f828abdf029  add rsp, 0x30
00007f828abdf02d  vmovaps xmm0, [rsp]
00007f828abdf032  vmovaps xmm1, [rsp+0x10]
00007f828abdf038  vmovaps xmm2, [rsp+0x20]
00007f828abdf03e  vmovaps xmm3, [rsp+0x30]
00007f828abdf044  vmovaps xmm4, [rsp+0x40]
00007f828abdf04a  vmovaps xmm5, [rsp+0x50]
00007f828abdf050  vmovaps xmm6, [rsp+0x60]
00007f828abdf056  vmovaps xmm7, [rsp+0x70]
00007f828abdf05c  vmovaps xmm8, [rsp+0x80]
00007f828abdf065  vmovaps xmm10, [rsp+0x90]
00007f828abdf06e  vmovaps xmm11, [rsp+0xA0]
00007f828abdf077  vmovaps xmm12, [rsp+0xB0]
00007f828abdf080  vmovaps xmm13, [rsp+0xC0]
00007f828abdf089  vmovaps xmm14, [rsp+0xD0]
00007f828abdf092  vmovaps xmm15, [rsp+0xE0]
00007f828abdf09b  add rsp, 0xF0
00007f828abdf0a2  pop r11
00007f828abdf0a4  pop r10
00007f828abdf0a6  pop r9
00007f828abdf0a8  pop r8
00007f828abdf0aa  pop rsi
00007f828abdf0ab  pop rdi
00007f828abdf0ac  pop rdx
00007f828abdf0ad  pop rcx
00007f828abdf0ae  pop rax
00007f828abdf0af  add rsp, 0x08
00007f828abdf0b3  jmp 0x00007F828ABDC354
00007f828abdf0b8  sub rsp, 0x08
00007f828abdf0bc  push rax
00007f828abdf0bd  push rcx
00007f828abdf0be  push rdx
00007f828abdf0bf  push rdi
00007f828abdf0c0  push rsi
00007f828abdf0c1  push r8
00007f828abdf0c3  push r9
00007f828abdf0c5  push r10
00007f828abdf0c7  push r11
00007f828abdf0c9  sub rsp, 0xF0
00007f828abdf0d0  vmovaps [rsp], xmm0
00007f828abdf0d5  vmovaps [rsp+0x10], xmm2
00007f828abdf0db  vmovaps [rsp+0x20], xmm3
00007f828abdf0e1  vmovaps [rsp+0x30], xmm4
00007f828abdf0e7  vmovaps [rsp+0x40], xmm5
00007f828abdf0ed  vmovaps [rsp+0x50], xmm6
00007f828abdf0f3  vmovaps [rsp+0x60], xmm7
00007f828abdf0f9  vmovaps [rsp+0x70], xmm8
00007f828abdf0ff  vmovaps [rsp+0x80], xmm9
00007f828abdf108  vmovaps [rsp+0x90], xmm10
00007f828abdf111  vmovaps [rsp+0xA0], xmm11
00007f828abdf11a  vmovaps [rsp+0xB0], xmm12
00007f828abdf123  vmovaps [rsp+0xC0], xmm13
00007f828abdf12c  vmovaps [rsp+0xD0], xmm14
00007f828abdf135  vmovaps [rsp+0xE0], xmm15
00007f828abdf13e  sub rsp, 0x30
00007f828abdf142  movaps [rsp], xmm1
00007f828abdf146  movaps [rsp+0x10], xmm15
00007f828abdf14c  movaps [rsp+0x20], xmm6
00007f828abdf151  lea rdi, [rsp]
00007f828abdf155  mov esi, 0x00
00007f828abdf15a  mov rax, 0x5BFE27FA6530
00007f828abdf164  call rax
00007f828abdf166  movaps xmm1, [rsp]
00007f828abdf16a  add rsp, 0x30
00007f828abdf16e  vmovaps xmm0, [rsp]
00007f828abdf173  vmovaps xmm2, [rsp+0x10]
00007f828abdf179  vmovaps xmm3, [rsp+0x20]
00007f828abdf17f  vmovaps xmm4, [rsp+0x30]
00007f828abdf185  vmovaps xmm5, [rsp+0x40]
00007f828abdf18b  vmovaps xmm6, [rsp+0x50]
00007f828abdf191  vmovaps xmm7, [rsp+0x60]
00007f828abdf197  vmovaps xmm8, [rsp+0x70]
00007f828abdf19d  vmovaps xmm9, [rsp+0x80]
00007f828abdf1a6  vmovaps xmm10, [rsp+0x90]
00007f828abdf1af  vmovaps xmm11, [rsp+0xA0]
00007f828abdf1b8  vmovaps xmm12, [rsp+0xB0]
00007f828abdf1c1  vmovaps xmm13, [rsp+0xC0]
00007f828abdf1ca  vmovaps xmm14, [rsp+0xD0]
00007f828abdf1d3  vmovaps xmm15, [rsp+0xE0]
00007f828abdf1dc  add rsp, 0xF0
00007f828abdf1e3  pop r11
00007f828abdf1e5  pop r10
00007f828abdf1e7  pop r9
00007f828abdf1e9  pop r8
00007f828abdf1eb  pop rsi
00007f828abdf1ec  pop rdi
00007f828abdf1ed  pop rdx
00007f828abdf1ee  pop rcx
00007f828abdf1ef  pop rax
00007f828abdf1f0  add rsp, 0x08
00007f828abdf1f4  jmp 0x00007F828ABDC375
00007f828abdf1f9  sub rsp, 0x08
00007f828abdf1fd  push rax
00007f828abdf1fe  push rcx
00007f828abdf1ff  push rdx
00007f828abdf200  push rdi
00007f828abdf201  push rsi
00007f828abdf202  push r8
00007f828abdf204  push r9
00007f828abdf206  push r10
00007f828abdf208  push r11
00007f828abdf20a  sub rsp, 0xF0
00007f828abdf211  vmovaps [rsp], xmm0
00007f828abdf216  vmovaps [rsp+0x10], xmm1
00007f828abdf21c  vmovaps [rsp+0x20], xmm2
00007f828abdf222  vmovaps [rsp+0x30], xmm3
00007f828abdf228  vmovaps [rsp+0x40], xmm4
00007f828abdf22e  vmovaps [rsp+0x50], xmm5
00007f828abdf234  vmovaps [rsp+0x60], xmm6
00007f828abdf23a  vmovaps [rsp+0x70], xmm7
00007f828abdf240  vmovaps [rsp+0x80], xmm8
00007f828abdf249  vmovaps [rsp+0x90], xmm9
00007f828abdf252  vmovaps [rsp+0xA0], xmm10
00007f828abdf25b  vmovaps [rsp+0xB0], xmm11
00007f828abdf264  vmovaps [rsp+0xC0], xmm12
00007f828abdf26d  vmovaps [rsp+0xD0], xmm13
00007f828abdf276  vmovaps [rsp+0xE0], xmm14
00007f828abdf27f  sub rsp, 0x30
00007f828abdf283  movaps [rsp], xmm15
00007f828abdf288  movaps [rsp+0x10], xmm5
00007f828abdf28d  movaps [rsp+0x20], xmm3
00007f828abdf292  lea rdi, [rsp]
00007f828abdf296  mov esi, 0x00
00007f828abdf29b  mov rax, 0x5BFE27FA6530
00007f828abdf2a5  call rax
00007f828abdf2a7  movaps xmm15, [rsp]
00007f828abdf2ac  add rsp, 0x30
00007f828abdf2b0  vmovaps xmm0, [rsp]
00007f828abdf2b5  vmovaps xmm1, [rsp+0x10]
00007f828abdf2bb  vmovaps xmm2, [rsp+0x20]
00007f828abdf2c1  vmovaps xmm3, [rsp+0x30]
00007f828abdf2c7  vmovaps xmm4, [rsp+0x40]
00007f828abdf2cd  vmovaps xmm5, [rsp+0x50]
00007f828abdf2d3  vmovaps xmm6, [rsp+0x60]
00007f828abdf2d9  vmovaps xmm7, [rsp+0x70]
00007f828abdf2df  vmovaps xmm8, [rsp+0x80]
00007f828abdf2e8  vmovaps xmm9, [rsp+0x90]
00007f828abdf2f1  vmovaps xmm10, [rsp+0xA0]
00007f828abdf2fa  vmovaps xmm11, [rsp+0xB0]
00007f828abdf303  vmovaps xmm12, [rsp+0xC0]
00007f828abdf30c  vmovaps xmm13, [rsp+0xD0]
00007f828abdf315  vmovaps xmm14, [rsp+0xE0]
00007f828abdf31e  add rsp, 0xF0
00007f828abdf325  pop r11
00007f828abdf327  pop r10
00007f828abdf329  pop r9
00007f828abdf32b  pop r8
00007f828abdf32d  pop rsi
00007f828abdf32e  pop rdi
00007f828abdf32f  pop rdx
00007f828abdf330  pop rcx
00007f828abdf331  pop rax
00007f828abdf332  add rsp, 0x08
00007f828abdf336  jmp 0x00007F828ABDC38F
00007f828abdf33b  sub rsp, 0x08
00007f828abdf33f  push rax
00007f828abdf340  push rcx
00007f828abdf341  push rdx
00007f828abdf342  push rdi
00007f828abdf343  push rsi
00007f828abdf344  push r8
00007f828abdf346  push r9
00007f828abdf348  push r10
00007f828abdf34a  push r11
00007f828abdf34c  sub rsp, 0xF0
00007f828abdf353  vmovaps [rsp], xmm0
00007f828abdf358  vmovaps [rsp+0x10], xmm1
00007f828abdf35e  vmovaps [rsp+0x20], xmm2
00007f828abdf364  vmovaps [rsp+0x30], xmm3
00007f828abdf36a  vmovaps [rsp+0x40], xmm4
00007f828abdf370  vmovaps [rsp+0x50], xmm6
00007f828abdf376  vmovaps [rsp+0x60], xmm7
00007f828abdf37c  vmovaps [rsp+0x70], xmm8
00007f828abdf382  vmovaps [rsp+0x80], xmm9
00007f828abdf38b  vmovaps [rsp+0x90], xmm10
00007f828abdf394  vmovaps [rsp+0xA0], xmm11
00007f828abdf39d  vmovaps [rsp+0xB0], xmm12
00007f828abdf3a6  vmovaps [rsp+0xC0], xmm13
00007f828abdf3af  vmovaps [rsp+0xD0], xmm14
00007f828abdf3b8  vmovaps [rsp+0xE0], xmm15
00007f828abdf3c1  sub rsp, 0x30
00007f828abdf3c5  movaps [rsp], xmm5
00007f828abdf3c9  movaps [rsp+0x10], xmm8
00007f828abdf3cf  movaps [rsp+0x20], xmm6
00007f828abdf3d4  lea rdi, [rsp]
00007f828abdf3d8  mov esi, 0x00
00007f828abdf3dd  mov rax, 0x5BFE27FA6530
00007f828abdf3e7  call rax
00007f828abdf3e9  movaps xmm5, [rsp]
00007f828abdf3ed  add rsp, 0x30
00007f828abdf3f1  vmovaps xmm0, [rsp]
00007f828abdf3f6  vmovaps xmm1, [rsp+0x10]
00007f828abdf3fc  vmovaps xmm2, [rsp+0x20]
00007f828abdf402  vmovaps xmm3, [rsp+0x30]
00007f828abdf408  vmovaps xmm4, [rsp+0x40]
00007f828abdf40e  vmovaps xmm6, [rsp+0x50]
00007f828abdf414  vmovaps xmm7, [rsp+0x60]
00007f828abdf41a  vmovaps xmm8, [rsp+0x70]
00007f828abdf420  vmovaps xmm9, [rsp+0x80]
00007f828abdf429  vmovaps xmm10, [rsp+0x90]
00007f828abdf432  vmovaps xmm11, [rsp+0xA0]
00007f828abdf43b  vmovaps xmm12, [rsp+0xB0]
00007f828abdf444  vmovaps xmm13, [rsp+0xC0]
00007f828abdf44d  vmovaps xmm14, [rsp+0xD0]
00007f828abdf456  vmovaps xmm15, [rsp+0xE0]
00007f828abdf45f  add rsp, 0xF0
00007f828abdf466  pop r11
00007f828abdf468  pop r10
00007f828abdf46a  pop r9
00007f828abdf46c  pop r8
00007f828abdf46e  pop rsi
00007f828abdf46f  pop rdi
00007f828abdf470  pop rdx
00007f828abdf471  pop rcx
00007f828abdf472  pop rax
00007f828abdf473  add rsp, 0x08
00007f828abdf477  jmp 0x00007F828ABDC3B3
00007f828abdf47c  sub rsp, 0x08
00007f828abdf480  push rax
00007f828abdf481  push rcx
00007f828abdf482  push rdx
00007f828abdf483  push rdi
00007f828abdf484  push rsi
00007f828abdf485  push r8
00007f828abdf487  push r9
00007f828abdf489  push r10
00007f828abdf48b  push r11
00007f828abdf48d  sub rsp, 0xF0
00007f828abdf494  vmovaps [rsp], xmm0
00007f828abdf499  vmovaps [rsp+0x10], xmm1
00007f828abdf49f  vmovaps [rsp+0x20], xmm2
00007f828abdf4a5  vmovaps [rsp+0x30], xmm3
00007f828abdf4ab  vmovaps [rsp+0x40], xmm4
00007f828abdf4b1  vmovaps [rsp+0x50], xmm5
00007f828abdf4b7  vmovaps [rsp+0x60], xmm7
00007f828abdf4bd  vmovaps [rsp+0x70], xmm8
00007f828abdf4c3  vmovaps [rsp+0x80], xmm9
00007f828abdf4cc  vmovaps [rsp+0x90], xmm10
00007f828abdf4d5  vmovaps [rsp+0xA0], xmm11
00007f828abdf4de  vmovaps [rsp+0xB0], xmm12
00007f828abdf4e7  vmovaps [rsp+0xC0], xmm13
00007f828abdf4f0  vmovaps [rsp+0xD0], xmm14
00007f828abdf4f9  vmovaps [rsp+0xE0], xmm15
00007f828abdf502  sub rsp, 0x30
00007f828abdf506  movaps [rsp], xmm6
00007f828abdf50a  movaps [rsp+0x10], xmm10
00007f828abdf510  movaps [rsp+0x20], xmm8
00007f828abdf516  lea rdi, [rsp]
00007f828abdf51a  mov esi, 0x00
00007f828abdf51f  mov rax, 0x5BFE27FA6530
00007f828abdf529  call rax
00007f828abdf52b  movaps xmm6, [rsp]
00007f828abdf52f  add rsp, 0x30
00007f828abdf533  vmovaps xmm0, [rsp]
00007f828abdf538  vmovaps xmm1, [rsp+0x10]
00007f828abdf53e  vmovaps xmm2, [rsp+0x20]
00007f828abdf544  vmovaps xmm3, [rsp+0x30]
00007f828abdf54a  vmovaps xmm4, [rsp+0x40]
00007f828abdf550  vmovaps xmm5, [rsp+0x50]
00007f828abdf556  vmovaps xmm7, [rsp+0x60]
00007f828abdf55c  vmovaps xmm8, [rsp+0x70]
00007f828abdf562  vmovaps xmm9, [rsp+0x80]
00007f828abdf56b  vmovaps xmm10, [rsp+0x90]
00007f828abdf574  vmovaps xmm11, [rsp+0xA0]
00007f828abdf57d  vmovaps xmm12, [rsp+0xB0]
00007f828abdf586  vmovaps xmm13, [rsp+0xC0]
00007f828abdf58f  vmovaps xmm14, [rsp+0xD0]
00007f828abdf598  vmovaps xmm15, [rsp+0xE0]
00007f828abdf5a1  add rsp, 0xF0
00007f828abdf5a8  pop r11
00007f828abdf5aa  pop r10
00007f828abdf5ac  pop r9
00007f828abdf5ae  pop r8
00007f828abdf5b0  pop rsi
00007f828abdf5b1  pop rdi
00007f828abdf5b2  pop rdx
00007f828abdf5b3  pop rcx
00007f828abdf5b4  pop rax
00007f828abdf5b5  add rsp, 0x08
00007f828abdf5b9  jmp 0x00007F828ABDC3D8
00007f828abdf5be  sub rsp, 0x08
00007f828abdf5c2  push rax
00007f828abdf5c3  push rcx
00007f828abdf5c4  push rdx
00007f828abdf5c5  push rdi
00007f828abdf5c6  push rsi
00007f828abdf5c7  push r8
00007f828abdf5c9  push r9
00007f828abdf5cb  push r10
00007f828abdf5cd  push r11
00007f828abdf5cf  sub rsp, 0xF0
00007f828abdf5d6  vmovaps [rsp], xmm0
00007f828abdf5db  vmovaps [rsp+0x10], xmm1
00007f828abdf5e1  vmovaps [rsp+0x20], xmm2
00007f828abdf5e7  vmovaps [rsp+0x30], xmm3
00007f828abdf5ed  vmovaps [rsp+0x40], xmm4
00007f828abdf5f3  vmovaps [rsp+0x50], xmm5
00007f828abdf5f9  vmovaps [rsp+0x60], xmm6
00007f828abdf5ff  vmovaps [rsp+0x70], xmm7
00007f828abdf605  vmovaps [rsp+0x80], xmm8
00007f828abdf60e  vmovaps [rsp+0x90], xmm9
00007f828abdf617  vmovaps [rsp+0xA0], xmm11
00007f828abdf620  vmovaps [rsp+0xB0], xmm12
00007f828abdf629  vmovaps [rsp+0xC0], xmm13
00007f828abdf632  vmovaps [rsp+0xD0], xmm14
00007f828abdf63b  vmovaps [rsp+0xE0], xmm15
00007f828abdf644  sub rsp, 0x30
00007f828abdf648  movaps [rsp], xmm10
00007f828abdf64d  movaps [rsp+0x10], xmm8
00007f828abdf653  movaps [rsp+0x20], xmm14
00007f828abdf659  lea rdi, [rsp]
00007f828abdf65d  mov esi, 0x00
00007f828abdf662  mov rax, 0x5BFE27FA6530
00007f828abdf66c  call rax
00007f828abdf66e  movaps xmm10, [rsp]
00007f828abdf673  add rsp, 0x30
00007f828abdf677  vmovaps xmm0, [rsp]
00007f828abdf67c  vmovaps xmm1, [rsp+0x10]
00007f828abdf682  vmovaps xmm2, [rsp+0x20]
00007f828abdf688  vmovaps xmm3, [rsp+0x30]
00007f828abdf68e  vmovaps xmm4, [rsp+0x40]
00007f828abdf694  vmovaps xmm5, [rsp+0x50]
00007f828abdf69a  vmovaps xmm6, [rsp+0x60]
00007f828abdf6a0  vmovaps xmm7, [rsp+0x70]
00007f828abdf6a6  vmovaps xmm8, [rsp+0x80]
00007f828abdf6af  vmovaps xmm9, [rsp+0x90]
00007f828abdf6b8  vmovaps xmm11, [rsp+0xA0]
00007f828abdf6c1  vmovaps xmm12, [rsp+0xB0]
00007f828abdf6ca  vmovaps xmm13, [rsp+0xC0]
00007f828abdf6d3  vmovaps xmm14, [rsp+0xD0]
00007f828abdf6dc  vmovaps xmm15, [rsp+0xE0]
00007f828abdf6e5  add rsp, 0xF0
00007f828abdf6ec  pop r11
00007f828abdf6ee  pop r10
00007f828abdf6f0  pop r9
00007f828abdf6f2  pop r8
00007f828abdf6f4  pop rsi
00007f828abdf6f5  pop rdi
00007f828abdf6f6  pop rdx
00007f828abdf6f7  pop rcx
00007f828abdf6f8  pop rax
00007f828abdf6f9  add rsp, 0x08
00007f828abdf6fd  jmp 0x00007F828ABDC3F8
00007f828abdf702  sub rsp, 0x08
00007f828abdf706  push rax
00007f828abdf707  push rcx
00007f828abdf708  push rdx
00007f828abdf709  push rdi
00007f828abdf70a  push rsi
00007f828abdf70b  push r8
00007f828abdf70d  push r9
00007f828abdf70f  push r10
00007f828abdf711  push r11
00007f828abdf713  sub rsp, 0xF0
00007f828abdf71a  vmovaps [rsp], xmm0
00007f828abdf71f  vmovaps [rsp+0x10], xmm1
00007f828abdf725  vmovaps [rsp+0x20], xmm2
00007f828abdf72b  vmovaps [rsp+0x30], xmm3
00007f828abdf731  vmovaps [rsp+0x40], xmm4
00007f828abdf737  vmovaps [rsp+0x50], xmm5
00007f828abdf73d  vmovaps [rsp+0x60], xmm6
00007f828abdf743  vmovaps [rsp+0x70], xmm7
00007f828abdf749  vmovaps [rsp+0x80], xmm8
00007f828abdf752  vmovaps [rsp+0x90], xmm9
00007f828abdf75b  vmovaps [rsp+0xA0], xmm10
00007f828abdf764  vmovaps [rsp+0xB0], xmm11
00007f828abdf76d  vmovaps [rsp+0xC0], xmm12
00007f828abdf776  vmovaps [rsp+0xD0], xmm13
00007f828abdf77f  vmovaps [rsp+0xE0], xmm15
00007f828abdf788  sub rsp, 0x30
00007f828abdf78c  movaps [rsp], xmm14
00007f828abdf791  movaps [rsp+0x10], xmm8
00007f828abdf797  movaps [rsp+0x20], xmm4
00007f828abdf79c  lea rdi, [rsp]
00007f828abdf7a0  mov esi, 0x00
00007f828abdf7a5  mov rax, 0x5BFE27FA6530
00007f828abdf7af  call rax
00007f828abdf7b1  movaps xmm14, [rsp]
00007f828abdf7b6  add rsp, 0x30
00007f828abdf7ba  vmovaps xmm0, [rsp]
00007f828abdf7bf  vmovaps xmm1, [rsp+0x10]
00007f828abdf7c5  vmovaps xmm2, [rsp+0x20]
00007f828abdf7cb  vmovaps xmm3, [rsp+0x30]
00007f828abdf7d1  vmovaps xmm4, [rsp+0x40]
00007f828abdf7d7  vmovaps xmm5, [rsp+0x50]
00007f828abdf7dd  vmovaps xmm6, [rsp+0x60]
00007f828abdf7e3  vmovaps xmm7, [rsp+0x70]
00007f828abdf7e9  vmovaps xmm8, [rsp+0x80]
00007f828abdf7f2  vmovaps xmm9, [rsp+0x90]
00007f828abdf7fb  vmovaps xmm10, [rsp+0xA0]
00007f828abdf804  vmovaps xmm11, [rsp+0xB0]
00007f828abdf80d  vmovaps xmm12, [rsp+0xC0]
00007f828abdf816  vmovaps xmm13, [rsp+0xD0]
00007f828abdf81f  vmovaps xmm15, [rsp+0xE0]
00007f828abdf828  add rsp, 0xF0
00007f828abdf82f  pop r11
00007f828abdf831  pop r10
00007f828abdf833  pop r9
00007f828abdf835  pop r8
00007f828abdf837  pop rsi
00007f828abdf838  pop rdi
00007f828abdf839  pop rdx
00007f828abdf83a  pop rcx
00007f828abdf83b  pop rax
00007f828abdf83c  add rsp, 0x08
00007f828abdf840  jmp 0x00007F828ABDC418
00007f828abdf845  sub rsp, 0x08
00007f828abdf849  push rax
00007f828abdf84a  push rcx
00007f828abdf84b  push rdx
00007f828abdf84c  push rdi
00007f828abdf84d  push rsi
00007f828abdf84e  push r8
00007f828abdf850  push r9
00007f828abdf852  push r10
00007f828abdf854  push r11
00007f828abdf856  sub rsp, 0xF0
00007f828abdf85d  vmovaps [rsp], xmm0
00007f828abdf862  vmovaps [rsp+0x10], xmm1
00007f828abdf868  vmovaps [rsp+0x20], xmm2
00007f828abdf86e  vmovaps [rsp+0x30], xmm3
00007f828abdf874  vmovaps [rsp+0x40], xmm5
00007f828abdf87a  vmovaps [rsp+0x50], xmm6
00007f828abdf880  vmovaps [rsp+0x60], xmm7
00007f828abdf886  vmovaps [rsp+0x70], xmm8
00007f828abdf88c  vmovaps [rsp+0x80], xmm9
00007f828abdf895  vmovaps [rsp+0x90], xmm10
00007f828abdf89e  vmovaps [rsp+0xA0], xmm11
00007f828abdf8a7  vmovaps [rsp+0xB0], xmm12
00007f828abdf8b0  vmovaps [rsp+0xC0], xmm13
00007f828abdf8b9  vmovaps [rsp+0xD0], xmm14
00007f828abdf8c2  vmovaps [rsp+0xE0], xmm15
00007f828abdf8cb  sub rsp, 0x30
00007f828abdf8cf  movaps [rsp], xmm4
00007f828abdf8d3  movaps [rsp+0x10], xmm13
00007f828abdf8d9  movaps [rsp+0x20], xmm8
00007f828abdf8df  lea rdi, [rsp]
00007f828abdf8e3  mov esi, 0x00
00007f828abdf8e8  mov rax, 0x5BFE27FA6530
00007f828abdf8f2  call rax
00007f828abdf8f4  movaps xmm4, [rsp]
00007f828abdf8f8  add rsp, 0x30
00007f828abdf8fc  vmovaps xmm0, [rsp]
00007f828abdf901  vmovaps xmm1, [rsp+0x10]
00007f828abdf907  vmovaps xmm2, [rsp+0x20]
00007f828abdf90d  vmovaps xmm3, [rsp+0x30]
00007f828abdf913  vmovaps xmm5, [rsp+0x40]
00007f828abdf919  vmovaps xmm6, [rsp+0x50]
00007f828abdf91f  vmovaps xmm7, [rsp+0x60]
00007f828abdf925  vmovaps xmm8, [rsp+0x70]
00007f828abdf92b  vmovaps xmm9, [rsp+0x80]
00007f828abdf934  vmovaps xmm10, [rsp+0x90]
00007f828abdf93d  vmovaps xmm11, [rsp+0xA0]
00007f828abdf946  vmovaps xmm12, [rsp+0xB0]
00007f828abdf94f  vmovaps xmm13, [rsp+0xC0]
00007f828abdf958  vmovaps xmm14, [rsp+0xD0]
00007f828abdf961  vmovaps xmm15, [rsp+0xE0]
00007f828abdf96a  add rsp, 0xF0
00007f828abdf971  pop r11
00007f828abdf973  pop r10
00007f828abdf975  pop r9
00007f828abdf977  pop r8
00007f828abdf979  pop rsi
00007f828abdf97a  pop rdi
00007f828abdf97b  pop rdx
00007f828abdf97c  pop rcx
00007f828abdf97d  pop rax
00007f828abdf97e  add rsp, 0x08
00007f828abdf982  jmp 0x00007F828ABDC43D
00007f828abdf987  sub rsp, 0x08
00007f828abdf98b  push rax
00007f828abdf98c  push rcx
00007f828abdf98d  push rdx
00007f828abdf98e  push rdi
00007f828abdf98f  push rsi
00007f828abdf990  push r8
00007f828abdf992  push r9
00007f828abdf994  push r10
00007f828abdf996  push r11
00007f828abdf998  sub rsp, 0xF0
00007f828abdf99f  vmovaps [rsp], xmm0
00007f828abdf9a4  vmovaps [rsp+0x10], xmm1
00007f828abdf9aa  vmovaps [rsp+0x20], xmm2
00007f828abdf9b0  vmovaps [rsp+0x30], xmm3
00007f828abdf9b6  vmovaps [rsp+0x40], xmm4
00007f828abdf9bc  vmovaps [rsp+0x50], xmm5
00007f828abdf9c2  vmovaps [rsp+0x60], xmm6
00007f828abdf9c8  vmovaps [rsp+0x70], xmm7
00007f828abdf9ce  vmovaps [rsp+0x80], xmm8
00007f828abdf9d7  vmovaps [rsp+0x90], xmm9
00007f828abdf9e0  vmovaps [rsp+0xA0], xmm10
00007f828abdf9e9  vmovaps [rsp+0xB0], xmm11
00007f828abdf9f2  vmovaps [rsp+0xC0], xmm12
00007f828abdf9fb  vmovaps [rsp+0xD0], xmm14
00007f828abdfa04  vmovaps [rsp+0xE0], xmm15
00007f828abdfa0d  sub rsp, 0x30
00007f828abdfa11  movaps [rsp], xmm13
00007f828abdfa16  movaps [rsp+0x10], xmm15
00007f828abdfa1c  movaps [rsp+0x20], xmm9
00007f828abdfa22  lea rdi, [rsp]
00007f828abdfa26  mov esi, 0x00
00007f828abdfa2b  mov rax, 0x5BFE27FA6530
00007f828abdfa35  call rax
00007f828abdfa37  movaps xmm13, [rsp]
00007f828abdfa3c  add rsp, 0x30
00007f828abdfa40  vmovaps xmm0, [rsp]
00007f828abdfa45  vmovaps xmm1, [rsp+0x10]
00007f828abdfa4b  vmovaps xmm2, [rsp+0x20]
00007f828abdfa51  vmovaps xmm3, [rsp+0x30]
00007f828abdfa57  vmovaps xmm4, [rsp+0x40]
00007f828abdfa5d  vmovaps xmm5, [rsp+0x50]
00007f828abdfa63  vmovaps xmm6, [rsp+0x60]
00007f828abdfa69  vmovaps xmm7, [rsp+0x70]
00007f828abdfa6f  vmovaps xmm8, [rsp+0x80]
00007f828abdfa78  vmovaps xmm9, [rsp+0x90]
00007f828abdfa81  vmovaps xmm10, [rsp+0xA0]
00007f828abdfa8a  vmovaps xmm11, [rsp+0xB0]
00007f828abdfa93  vmovaps xmm12, [rsp+0xC0]
00007f828abdfa9c  vmovaps xmm14, [rsp+0xD0]
00007f828abdfaa5  vmovaps xmm15, [rsp+0xE0]
00007f828abdfaae  add rsp, 0xF0
00007f828abdfab5  pop r11
00007f828abdfab7  pop r10
00007f828abdfab9  pop r9
00007f828abdfabb  pop r8
00007f828abdfabd  pop rsi
00007f828abdfabe  pop rdi
00007f828abdfabf  pop rdx
00007f828abdfac0  pop rcx
00007f828abdfac1  pop rax
00007f828abdfac2  add rsp, 0x08
00007f828abdfac6  jmp 0x00007F828ABDC458
00007f828abdfacb  sub rsp, 0x08
00007f828abdfacf  push rax
00007f828abdfad0  push rcx
00007f828abdfad1  push rdx
00007f828abdfad2  push rdi
00007f828abdfad3  push rsi
00007f828abdfad4  push r8
00007f828abdfad6  push r9
00007f828abdfad8  push r10
00007f828abdfada  push r11
00007f828abdfadc  sub rsp, 0xF0
00007f828abdfae3  vmovaps [rsp], xmm0
00007f828abdfae8  vmovaps [rsp+0x10], xmm1
00007f828abdfaee  vmovaps [rsp+0x20], xmm2
00007f828abdfaf4  vmovaps [rsp+0x30], xmm3
00007f828abdfafa  vmovaps [rsp+0x40], xmm4
00007f828abdfb00  vmovaps [rsp+0x50], xmm5
00007f828abdfb06  vmovaps [rsp+0x60], xmm6
00007f828abdfb0c  vmovaps [rsp+0x70], xmm7
00007f828abdfb12  vmovaps [rsp+0x80], xmm8
00007f828abdfb1b  vmovaps [rsp+0x90], xmm9
00007f828abdfb24  vmovaps [rsp+0xA0], xmm10
00007f828abdfb2d  vmovaps [rsp+0xB0], xmm11
00007f828abdfb36  vmovaps [rsp+0xC0], xmm12
00007f828abdfb3f  vmovaps [rsp+0xD0], xmm13
00007f828abdfb48  vmovaps [rsp+0xE0], xmm14
00007f828abdfb51  sub rsp, 0x30
00007f828abdfb55  movaps [rsp], xmm15
00007f828abdfb5a  movaps [rsp+0x10], xmm1
00007f828abdfb5f  movaps [rsp+0x20], xmm5
00007f828abdfb64  lea rdi, [rsp]
00007f828abdfb68  mov esi, 0x00
00007f828abdfb6d  mov rax, 0x5BFE27FA6530
00007f828abdfb77  call rax
00007f828abdfb79  movaps xmm15, [rsp]
00007f828abdfb7e  add rsp, 0x30
00007f828abdfb82  vmovaps xmm0, [rsp]
00007f828abdfb87  vmovaps xmm1, [rsp+0x10]
00007f828abdfb8d  vmovaps xmm2, [rsp+0x20]
00007f828abdfb93  vmovaps xmm3, [rsp+0x30]
00007f828abdfb99  vmovaps xmm4, [rsp+0x40]
00007f828abdfb9f  vmovaps xmm5, [rsp+0x50]
00007f828abdfba5  vmovaps xmm6, [rsp+0x60]
00007f828abdfbab  vmovaps xmm7, [rsp+0x70]
00007f828abdfbb1  vmovaps xmm8, [rsp+0x80]
00007f828abdfbba  vmovaps xmm9, [rsp+0x90]
00007f828abdfbc3  vmovaps xmm10, [rsp+0xA0]
00007f828abdfbcc  vmovaps xmm11, [rsp+0xB0]
00007f828abdfbd5  vmovaps xmm12, [rsp+0xC0]
00007f828abdfbde  vmovaps xmm13, [rsp+0xD0]
00007f828abdfbe7  vmovaps xmm14, [rsp+0xE0]
00007f828abdfbf0  add rsp, 0xF0
00007f828abdfbf7  pop r11
00007f828abdfbf9  pop r10
00007f828abdfbfb  pop r9
00007f828abdfbfd  pop r8
00007f828abdfbff  pop rsi
00007f828abdfc00  pop rdi
00007f828abdfc01  pop rdx
00007f828abdfc02  pop rcx
00007f828abdfc03  pop rax
00007f828abdfc04  add rsp, 0x08
00007f828abdfc08  jmp 0x00007F828ABDC473
00007f828abdfc0d  call 0x00007F828AAB52F0
00007f828abdfc12  jmp 0x00007F828ABDC4CE
00007f828abdfc17  sub rsp, 0x08
00007f828abdfc1b  push rax
00007f828abdfc1c  push rcx
00007f828abdfc1d  push rdx
00007f828abdfc1e  push rdi
00007f828abdfc1f  push rsi
00007f828abdfc20  push r8
00007f828abdfc22  push r9
00007f828abdfc24  push r10
00007f828abdfc26  push r11
00007f828abdfc28  sub rsp, 0xF0
00007f828abdfc2f  vmovaps [rsp], xmm0
00007f828abdfc34  vmovaps [rsp+0x10], xmm1
00007f828abdfc3a  vmovaps [rsp+0x20], xmm2
00007f828abdfc40  vmovaps [rsp+0x30], xmm3
00007f828abdfc46  vmovaps [rsp+0x40], xmm4
00007f828abdfc4c  vmovaps [rsp+0x50], xmm5
00007f828abdfc52  vmovaps [rsp+0x60], xmm6
00007f828abdfc58  vmovaps [rsp+0x70], xmm7
00007f828abdfc5e  vmovaps [rsp+0x80], xmm8
00007f828abdfc67  vmovaps [rsp+0x90], xmm10
00007f828abdfc70  vmovaps [rsp+0xA0], xmm11
00007f828abdfc79  vmovaps [rsp+0xB0], xmm12
00007f828abdfc82  vmovaps [rsp+0xC0], xmm13
00007f828abdfc8b  vmovaps [rsp+0xD0], xmm14
00007f828abdfc94  vmovaps [rsp+0xE0], xmm15
00007f828abdfc9d  sub rsp, 0x30
00007f828abdfca1  movaps [rsp], xmm9
00007f828abdfca6  movaps [rsp+0x10], xmm8
00007f828abdfcac  movaps [rsp+0x20], xmm11
00007f828abdfcb2  lea rdi, [rsp]
00007f828abdfcb6  mov esi, 0x00
00007f828abdfcbb  mov rax, 0x5BFE27FA6530
00007f828abdfcc5  call rax
00007f828abdfcc7  movaps xmm9, [rsp]
00007f828abdfccc  add rsp, 0x30
00007f828abdfcd0  vmovaps xmm0, [rsp]
00007f828abdfcd5  vmovaps xmm1, [rsp+0x10]
00007f828abdfcdb  vmovaps xmm2, [rsp+0x20]
00007f828abdfce1  vmovaps xmm3, [rsp+0x30]
00007f828abdfce7  vmovaps xmm4, [rsp+0x40]
00007f828abdfced  vmovaps xmm5, [rsp+0x50]
00007f828abdfcf3  vmovaps xmm6, [rsp+0x60]
00007f828abdfcf9  vmovaps xmm7, [rsp+0x70]
00007f828abdfcff  vmovaps xmm8, [rsp+0x80]
00007f828abdfd08  vmovaps xmm10, [rsp+0x90]
00007f828abdfd11  vmovaps xmm11, [rsp+0xA0]
00007f828abdfd1a  vmovaps xmm12, [rsp+0xB0]
00007f828abdfd23  vmovaps xmm13, [rsp+0xC0]
00007f828abdfd2c  vmovaps xmm14, [rsp+0xD0]
00007f828abdfd35  vmovaps xmm15, [rsp+0xE0]
00007f828abdfd3e  add rsp, 0xF0
00007f828abdfd45  pop r11
00007f828abdfd47  pop r10
00007f828abdfd49  pop r9
00007f828abdfd4b  pop r8
00007f828abdfd4d  pop rsi
00007f828abdfd4e  pop rdi
00007f828abdfd4f  pop rdx
00007f828abdfd50  pop rcx
00007f828abdfd51  pop rax
00007f828abdfd52  add rsp, 0x08
00007f828abdfd56  jmp 0x00007F828ABDC505
00007f828abdfd5b  sub rsp, 0x08
00007f828abdfd5f  push rax
00007f828abdfd60  push rcx
00007f828abdfd61  push rdx
00007f828abdfd62  push rdi
00007f828abdfd63  push rsi
00007f828abdfd64  push r8
00007f828abdfd66  push r9
00007f828abdfd68  push r10
00007f828abdfd6a  push r11
00007f828abdfd6c  sub rsp, 0xF0
00007f828abdfd73  vmovaps [rsp], xmm0
00007f828abdfd78  vmovaps [rsp+0x10], xmm1
00007f828abdfd7e  vmovaps [rsp+0x20], xmm2
00007f828abdfd84  vmovaps [rsp+0x30], xmm3
00007f828abdfd8a  vmovaps [rsp+0x40], xmm4
00007f828abdfd90  vmovaps [rsp+0x50], xmm5
00007f828abdfd96  vmovaps [rsp+0x60], xmm6
00007f828abdfd9c  vmovaps [rsp+0x70], xmm7
00007f828abdfda2  vmovaps [rsp+0x80], xmm8
00007f828abdfdab  vmovaps [rsp+0x90], xmm9
00007f828abdfdb4  vmovaps [rsp+0xA0], xmm10
00007f828abdfdbd  vmovaps [rsp+0xB0], xmm12
00007f828abdfdc6  vmovaps [rsp+0xC0], xmm13
00007f828abdfdcf  vmovaps [rsp+0xD0], xmm14
00007f828abdfdd8  vmovaps [rsp+0xE0], xmm15
00007f828abdfde1  sub rsp, 0x30
00007f828abdfde5  movaps [rsp], xmm11
00007f828abdfdea  movaps [rsp+0x10], xmm10
00007f828abdfdf0  movaps [rsp+0x20], xmm6
00007f828abdfdf5  lea rdi, [rsp]
00007f828abdfdf9  mov esi, 0x00
00007f828abdfdfe  mov rax, 0x5BFE27FA6530
00007f828abdfe08  call rax
00007f828abdfe0a  movaps xmm11, [rsp]
00007f828abdfe0f  add rsp, 0x30
00007f828abdfe13  vmovaps xmm0, [rsp]
00007f828abdfe18  vmovaps xmm1, [rsp+0x10]
00007f828abdfe1e  vmovaps xmm2, [rsp+0x20]
00007f828abdfe24  vmovaps xmm3, [rsp+0x30]
00007f828abdfe2a  vmovaps xmm4, [rsp+0x40]
00007f828abdfe30  vmovaps xmm5, [rsp+0x50]
00007f828abdfe36  vmovaps xmm6, [rsp+0x60]
00007f828abdfe3c  vmovaps xmm7, [rsp+0x70]
00007f828abdfe42  vmovaps xmm8, [rsp+0x80]
00007f828abdfe4b  vmovaps xmm9, [rsp+0x90]
00007f828abdfe54  vmovaps xmm10, [rsp+0xA0]
00007f828abdfe5d  vmovaps xmm12, [rsp+0xB0]
00007f828abdfe66  vmovaps xmm13, [rsp+0xC0]
00007f828abdfe6f  vmovaps xmm14, [rsp+0xD0]
00007f828abdfe78  vmovaps xmm15, [rsp+0xE0]
00007f828abdfe81  add rsp, 0xF0
00007f828abdfe88  pop r11
00007f828abdfe8a  pop r10
00007f828abdfe8c  pop r9
00007f828abdfe8e  pop r8
00007f828abdfe90  pop rsi
00007f828abdfe91  pop rdi
00007f828abdfe92  pop rdx
00007f828abdfe93  pop rcx
00007f828abdfe94  pop rax
00007f828abdfe95  add rsp, 0x08
00007f828abdfe99  jmp 0x00007F828ABDC520
00007f828abdfe9e  sub rsp, 0x08
00007f828abdfea2  push rax
00007f828abdfea3  push rcx
00007f828abdfea4  push rdx
00007f828abdfea5  push rdi
00007f828abdfea6  push rsi
00007f828abdfea7  push r8
00007f828abdfea9  push r9
00007f828abdfeab  push r10
00007f828abdfead  push r11
00007f828abdfeaf  sub rsp, 0xF0
00007f828abdfeb6  vmovaps [rsp], xmm0
00007f828abdfebb  vmovaps [rsp+0x10], xmm1
00007f828abdfec1  vmovaps [rsp+0x20], xmm2
00007f828abdfec7  vmovaps [rsp+0x30], xmm3
00007f828abdfecd  vmovaps [rsp+0x40], xmm4
00007f828abdfed3  vmovaps [rsp+0x50], xmm5
00007f828abdfed9  vmovaps [rsp+0x60], xmm6
00007f828abdfedf  vmovaps [rsp+0x70], xmm7
00007f828abdfee5  vmovaps [rsp+0x80], xmm8
00007f828abdfeee  vmovaps [rsp+0x90], xmm9
00007f828abdfef7  vmovaps [rsp+0xA0], xmm11
00007f828abdff00  vmovaps [rsp+0xB0], xmm12
00007f828abdff09  vmovaps [rsp+0xC0], xmm13
00007f828abdff12  vmovaps [rsp+0xD0], xmm14
00007f828abdff1b  vmovaps [rsp+0xE0], xmm15
00007f828abdff24  sub rsp, 0x30
00007f828abdff28  movaps [rsp], xmm10
00007f828abdff2d  movaps [rsp+0x10], xmm14
00007f828abdff33  movaps [rsp+0x20], xmm4
00007f828abdff38  lea rdi, [rsp]
00007f828abdff3c  mov esi, 0x00
00007f828abdff41  mov rax, 0x5BFE27FA6530
00007f828abdff4b  call rax
00007f828abdff4d  movaps xmm10, [rsp]
00007f828abdff52  add rsp, 0x30
00007f828abdff56  vmovaps xmm0, [rsp]
00007f828abdff5b  vmovaps xmm1, [rsp+0x10]
00007f828abdff61  vmovaps xmm2, [rsp+0x20]
00007f828abdff67  vmovaps xmm3, [rsp+0x30]
00007f828abdff6d  vmovaps xmm4, [rsp+0x40]
00007f828abdff73  vmovaps xmm5, [rsp+0x50]
00007f828abdff79  vmovaps xmm6, [rsp+0x60]
00007f828abdff7f  vmovaps xmm7, [rsp+0x70]
00007f828abdff85  vmovaps xmm8, [rsp+0x80]
00007f828abdff8e  vmovaps xmm9, [rsp+0x90]
00007f828abdff97  vmovaps xmm11, [rsp+0xA0]
00007f828abdffa0  vmovaps xmm12, [rsp+0xB0]
00007f828abdffa9  vmovaps xmm13, [rsp+0xC0]
00007f828abdffb2  vmovaps xmm14, [rsp+0xD0]
00007f828abdffbb  vmovaps xmm15, [rsp+0xE0]
00007f828abdffc4  add rsp, 0xF0
00007f828abdffcb  pop r11
00007f828abdffcd  pop r10
00007f828abdffcf  pop r9
00007f828abdffd1  pop r8
00007f828abdffd3  pop rsi
00007f828abdffd4  pop rdi
00007f828abdffd5  pop rdx
00007f828abdffd6  pop rcx
00007f828abdffd7  pop rax
00007f828abdffd8  add rsp, 0x08
00007f828abdffdc  jmp 0x00007F828ABDC53B
00007f828abdffe1  sub rsp, 0x08
00007f828abdffe5  push rax
00007f828abdffe6  push rcx
00007f828abdffe7  push rdx
00007f828abdffe8  push rdi
00007f828abdffe9  push rsi
00007f828abdffea  push r8
00007f828abdffec  push r9
00007f828abdffee  push r10
00007f828abdfff0  push r11
00007f828abdfff2  sub rsp, 0xF0
00007f828abdfff9  vmovaps [rsp], xmm0
00007f828abdfffe  vmovaps [rsp+0x10], xmm1
00007f828abe0004  vmovaps [rsp+0x20], xmm2
00007f828abe000a  vmovaps [rsp+0x30], xmm3
00007f828abe0010  vmovaps [rsp+0x40], xmm4
00007f828abe0016  vmovaps [rsp+0x50], xmm5
00007f828abe001c  vmovaps [rsp+0x60], xmm6
00007f828abe0022  vmovaps [rsp+0x70], xmm7
00007f828abe0028  vmovaps [rsp+0x80], xmm9
00007f828abe0031  vmovaps [rsp+0x90], xmm10
00007f828abe003a  vmovaps [rsp+0xA0], xmm11
00007f828abe0043  vmovaps [rsp+0xB0], xmm12
00007f828abe004c  vmovaps [rsp+0xC0], xmm13
00007f828abe0055  vmovaps [rsp+0xD0], xmm14
00007f828abe005e  vmovaps [rsp+0xE0], xmm15
00007f828abe0067  sub rsp, 0x30
00007f828abe006b  movaps [rsp], xmm8
00007f828abe0070  movaps [rsp+0x10], xmm1
00007f828abe0075  movaps [rsp+0x20], xmm14
00007f828abe007b  lea rdi, [rsp]
00007f828abe007f  mov esi, 0x00
00007f828abe0084  mov rax, 0x5BFE27FA6530
00007f828abe008e  call rax
00007f828abe0090  movaps xmm8, [rsp]
00007f828abe0095  add rsp, 0x30
00007f828abe0099  vmovaps xmm0, [rsp]
00007f828abe009e  vmovaps xmm1, [rsp+0x10]
00007f828abe00a4  vmovaps xmm2, [rsp+0x20]
00007f828abe00aa  vmovaps xmm3, [rsp+0x30]
00007f828abe00b0  vmovaps xmm4, [rsp+0x40]
00007f828abe00b6  vmovaps xmm5, [rsp+0x50]
00007f828abe00bc  vmovaps xmm6, [rsp+0x60]
00007f828abe00c2  vmovaps xmm7, [rsp+0x70]
00007f828abe00c8  vmovaps xmm9, [rsp+0x80]
00007f828abe00d1  vmovaps xmm10, [rsp+0x90]
00007f828abe00da  vmovaps xmm11, [rsp+0xA0]
00007f828abe00e3  vmovaps xmm12, [rsp+0xB0]
00007f828abe00ec  vmovaps xmm13, [rsp+0xC0]
00007f828abe00f5  vmovaps xmm14, [rsp+0xD0]
00007f828abe00fe  vmovaps xmm15, [rsp+0xE0]
00007f828abe0107  add rsp, 0xF0
00007f828abe010e  pop r11
00007f828abe0110  pop r10
00007f828abe0112  pop r9
00007f828abe0114  pop r8
00007f828abe0116  pop rsi
00007f828abe0117  pop rdi
00007f828abe0118  pop rdx
00007f828abe0119  pop rcx
00007f828abe011a  pop rax
00007f828abe011b  add rsp, 0x08
00007f828abe011f  jmp 0x00007F828ABDC561
00007f828abe0124  sub rsp, 0x08
00007f828abe0128  push rax
00007f828abe0129  push rcx
00007f828abe012a  push rdx
00007f828abe012b  push rdi
00007f828abe012c  push rsi
00007f828abe012d  push r8
00007f828abe012f  push r9
00007f828abe0131  push r10
00007f828abe0133  push r11
00007f828abe0135  sub rsp, 0xF0
00007f828abe013c  vmovaps [rsp], xmm0
00007f828abe0141  vmovaps [rsp+0x10], xmm1
00007f828abe0147  vmovaps [rsp+0x20], xmm2
00007f828abe014d  vmovaps [rsp+0x30], xmm3
00007f828abe0153  vmovaps [rsp+0x40], xmm4
00007f828abe0159  vmovaps [rsp+0x50], xmm5
00007f828abe015f  vmovaps [rsp+0x60], xmm7
00007f828abe0165  vmovaps [rsp+0x70], xmm8
00007f828abe016b  vmovaps [rsp+0x80], xmm9
00007f828abe0174  vmovaps [rsp+0x90], xmm10
00007f828abe017d  vmovaps [rsp+0xA0], xmm11
00007f828abe0186  vmovaps [rsp+0xB0], xmm12
00007f828abe018f  vmovaps [rsp+0xC0], xmm13
00007f828abe0198  vmovaps [rsp+0xD0], xmm14
00007f828abe01a1  vmovaps [rsp+0xE0], xmm15
00007f828abe01aa  sub rsp, 0x30
00007f828abe01ae  movaps [rsp], xmm6
00007f828abe01b2  movaps [rsp+0x10], xmm1
00007f828abe01b7  movaps [rsp+0x20], xmm14
00007f828abe01bd  lea rdi, [rsp]
00007f828abe01c1  mov esi, 0x00
00007f828abe01c6  mov rax, 0x5BFE27FA6530
00007f828abe01d0  call rax
00007f828abe01d2  movaps xmm6, [rsp]
00007f828abe01d6  add rsp, 0x30
00007f828abe01da  vmovaps xmm0, [rsp]
00007f828abe01df  vmovaps xmm1, [rsp+0x10]
00007f828abe01e5  vmovaps xmm2, [rsp+0x20]
00007f828abe01eb  vmovaps xmm3, [rsp+0x30]
00007f828abe01f1  vmovaps xmm4, [rsp+0x40]
00007f828abe01f7  vmovaps xmm5, [rsp+0x50]
00007f828abe01fd  vmovaps xmm7, [rsp+0x60]
00007f828abe0203  vmovaps xmm8, [rsp+0x70]
00007f828abe0209  vmovaps xmm9, [rsp+0x80]
00007f828abe0212  vmovaps xmm10, [rsp+0x90]
00007f828abe021b  vmovaps xmm11, [rsp+0xA0]
00007f828abe0224  vmovaps xmm12, [rsp+0xB0]
00007f828abe022d  vmovaps xmm13, [rsp+0xC0]
00007f828abe0236  vmovaps xmm14, [rsp+0xD0]
00007f828abe023f  vmovaps xmm15, [rsp+0xE0]
00007f828abe0248  add rsp, 0xF0
00007f828abe024f  pop r11
00007f828abe0251  pop r10
00007f828abe0253  pop r9
00007f828abe0255  pop r8
00007f828abe0257  pop rsi
00007f828abe0258  pop rdi
00007f828abe0259  pop rdx
00007f828abe025a  pop rcx
00007f828abe025b  pop rax
00007f828abe025c  add rsp, 0x08
00007f828abe0260  jmp 0x00007F828ABDC58D
00007f828abe0265  sub rsp, 0x08
00007f828abe0269  push rax
00007f828abe026a  push rcx
00007f828abe026b  push rdx
00007f828abe026c  push rdi
00007f828abe026d  push rsi
00007f828abe026e  push r8
00007f828abe0270  push r9
00007f828abe0272  push r10
00007f828abe0274  push r11
00007f828abe0276  sub rsp, 0xF0
00007f828abe027d  vmovaps [rsp], xmm0
00007f828abe0282  vmovaps [rsp+0x10], xmm1
00007f828abe0288  vmovaps [rsp+0x20], xmm2
00007f828abe028e  vmovaps [rsp+0x30], xmm3
00007f828abe0294  vmovaps [rsp+0x40], xmm4
00007f828abe029a  vmovaps [rsp+0x50], xmm5
00007f828abe02a0  vmovaps [rsp+0x60], xmm6
00007f828abe02a6  vmovaps [rsp+0x70], xmm7
00007f828abe02ac  vmovaps [rsp+0x80], xmm8
00007f828abe02b5  vmovaps [rsp+0x90], xmm9
00007f828abe02be  vmovaps [rsp+0xA0], xmm10
00007f828abe02c7  vmovaps [rsp+0xB0], xmm11
00007f828abe02d0  vmovaps [rsp+0xC0], xmm12
00007f828abe02d9  vmovaps [rsp+0xD0], xmm13
00007f828abe02e2  vmovaps [rsp+0xE0], xmm15
00007f828abe02eb  sub rsp, 0x30
00007f828abe02ef  movaps [rsp], xmm14
00007f828abe02f4  movaps [rsp+0x10], xmm12
00007f828abe02fa  movaps [rsp+0x20], xmm1
00007f828abe02ff  lea rdi, [rsp]
00007f828abe0303  mov esi, 0x00
00007f828abe0308  mov rax, 0x5BFE27FA6530
00007f828abe0312  call rax
00007f828abe0314  movaps xmm14, [rsp]
00007f828abe0319  add rsp, 0x30
00007f828abe031d  vmovaps xmm0, [rsp]
00007f828abe0322  vmovaps xmm1, [rsp+0x10]
00007f828abe0328  vmovaps xmm2, [rsp+0x20]
00007f828abe032e  vmovaps xmm3, [rsp+0x30]
00007f828abe0334  vmovaps xmm4, [rsp+0x40]
00007f828abe033a  vmovaps xmm5, [rsp+0x50]
00007f828abe0340  vmovaps xmm6, [rsp+0x60]
00007f828abe0346  vmovaps xmm7, [rsp+0x70]
00007f828abe034c  vmovaps xmm8, [rsp+0x80]
00007f828abe0355  vmovaps xmm9, [rsp+0x90]
00007f828abe035e  vmovaps xmm10, [rsp+0xA0]
00007f828abe0367  vmovaps xmm11, [rsp+0xB0]
00007f828abe0370  vmovaps xmm12, [rsp+0xC0]
00007f828abe0379  vmovaps xmm13, [rsp+0xD0]
00007f828abe0382  vmovaps xmm15, [rsp+0xE0]
00007f828abe038b  add rsp, 0xF0
00007f828abe0392  pop r11
00007f828abe0394  pop r10
00007f828abe0396  pop r9
00007f828abe0398  pop r8
00007f828abe039a  pop rsi
00007f828abe039b  pop rdi
00007f828abe039c  pop rdx
00007f828abe039d  pop rcx
00007f828abe039e  pop rax
00007f828abe039f  add rsp, 0x08
00007f828abe03a3  jmp 0x00007F828ABDC5B3
00007f828abe03a8  sub rsp, 0x08
00007f828abe03ac  push rax
00007f828abe03ad  push rcx
00007f828abe03ae  push rdx
00007f828abe03af  push rdi
00007f828abe03b0  push rsi
00007f828abe03b1  push r8
00007f828abe03b3  push r9
00007f828abe03b5  push r10
00007f828abe03b7  push r11
00007f828abe03b9  sub rsp, 0xF0
00007f828abe03c0  vmovaps [rsp], xmm0
00007f828abe03c5  vmovaps [rsp+0x10], xmm2
00007f828abe03cb  vmovaps [rsp+0x20], xmm3
00007f828abe03d1  vmovaps [rsp+0x30], xmm4
00007f828abe03d7  vmovaps [rsp+0x40], xmm5
00007f828abe03dd  vmovaps [rsp+0x50], xmm6
00007f828abe03e3  vmovaps [rsp+0x60], xmm7
00007f828abe03e9  vmovaps [rsp+0x70], xmm8
00007f828abe03ef  vmovaps [rsp+0x80], xmm9
00007f828abe03f8  vmovaps [rsp+0x90], xmm10
00007f828abe0401  vmovaps [rsp+0xA0], xmm11
00007f828abe040a  vmovaps [rsp+0xB0], xmm12
00007f828abe0413  vmovaps [rsp+0xC0], xmm13
00007f828abe041c  vmovaps [rsp+0xD0], xmm14
00007f828abe0425  vmovaps [rsp+0xE0], xmm15
00007f828abe042e  sub rsp, 0x30
00007f828abe0432  movaps [rsp], xmm1
00007f828abe0436  movaps [rsp+0x10], xmm13
00007f828abe043c  movaps [rsp+0x20], xmm9
00007f828abe0442  lea rdi, [rsp]
00007f828abe0446  mov esi, 0x00
00007f828abe044b  mov rax, 0x5BFE27FA6530
00007f828abe0455  call rax
00007f828abe0457  movaps xmm1, [rsp]
00007f828abe045b  add rsp, 0x30
00007f828abe045f  vmovaps xmm0, [rsp]
00007f828abe0464  vmovaps xmm2, [rsp+0x10]
00007f828abe046a  vmovaps xmm3, [rsp+0x20]
00007f828abe0470  vmovaps xmm4, [rsp+0x30]
00007f828abe0476  vmovaps xmm5, [rsp+0x40]
00007f828abe047c  vmovaps xmm6, [rsp+0x50]
00007f828abe0482  vmovaps xmm7, [rsp+0x60]
00007f828abe0488  vmovaps xmm8, [rsp+0x70]
00007f828abe048e  vmovaps xmm9, [rsp+0x80]
00007f828abe0497  vmovaps xmm10, [rsp+0x90]
00007f828abe04a0  vmovaps xmm11, [rsp+0xA0]
00007f828abe04a9  vmovaps xmm12, [rsp+0xB0]
00007f828abe04b2  vmovaps xmm13, [rsp+0xC0]
00007f828abe04bb  vmovaps xmm14, [rsp+0xD0]
00007f828abe04c4  vmovaps xmm15, [rsp+0xE0]
00007f828abe04cd  add rsp, 0xF0
00007f828abe04d4  pop r11
00007f828abe04d6  pop r10
00007f828abe04d8  pop r9
00007f828abe04da  pop r8
00007f828abe04dc  pop rsi
00007f828abe04dd  pop rdi
00007f828abe04de  pop rdx
00007f828abe04df  pop rcx
00007f828abe04e0  pop rax
00007f828abe04e1  add rsp, 0x08
00007f828abe04e5  jmp 0x00007F828ABDC5CD
00007f828abe04ea  sub rsp, 0x08
00007f828abe04ee  push rax
00007f828abe04ef  push rcx
00007f828abe04f0  push rdx
00007f828abe04f1  push rdi
00007f828abe04f2  push rsi
00007f828abe04f3  push r8
00007f828abe04f5  push r9
00007f828abe04f7  push r10
00007f828abe04f9  push r11
00007f828abe04fb  sub rsp, 0xF0
00007f828abe0502  vmovaps [rsp], xmm0
00007f828abe0507  vmovaps [rsp+0x10], xmm1
00007f828abe050d  vmovaps [rsp+0x20], xmm2
00007f828abe0513  vmovaps [rsp+0x30], xmm3
00007f828abe0519  vmovaps [rsp+0x40], xmm4
00007f828abe051f  vmovaps [rsp+0x50], xmm5
00007f828abe0525  vmovaps [rsp+0x60], xmm6
00007f828abe052b  vmovaps [rsp+0x70], xmm7
00007f828abe0531  vmovaps [rsp+0x80], xmm8
00007f828abe053a  vmovaps [rsp+0x90], xmm9
00007f828abe0543  vmovaps [rsp+0xA0], xmm10
00007f828abe054c  vmovaps [rsp+0xB0], xmm11
00007f828abe0555  vmovaps [rsp+0xC0], xmm13
00007f828abe055e  vmovaps [rsp+0xD0], xmm14
00007f828abe0567  vmovaps [rsp+0xE0], xmm15
00007f828abe0570  sub rsp, 0x30
00007f828abe0574  movaps [rsp], xmm12
00007f828abe0579  movaps [rsp+0x10], xmm7
00007f828abe057e  movaps [rsp+0x20], xmm13
00007f828abe0584  lea rdi, [rsp]
00007f828abe0588  mov esi, 0x00
00007f828abe058d  mov rax, 0x5BFE27FA6530
00007f828abe0597  call rax
00007f828abe0599  movaps xmm12, [rsp]
00007f828abe059e  add rsp, 0x30
00007f828abe05a2  vmovaps xmm0, [rsp]
00007f828abe05a7  vmovaps xmm1, [rsp+0x10]
00007f828abe05ad  vmovaps xmm2, [rsp+0x20]
00007f828abe05b3  vmovaps xmm3, [rsp+0x30]
00007f828abe05b9  vmovaps xmm4, [rsp+0x40]
00007f828abe05bf  vmovaps xmm5, [rsp+0x50]
00007f828abe05c5  vmovaps xmm6, [rsp+0x60]
00007f828abe05cb  vmovaps xmm7, [rsp+0x70]
00007f828abe05d1  vmovaps xmm8, [rsp+0x80]
00007f828abe05da  vmovaps xmm9, [rsp+0x90]
00007f828abe05e3  vmovaps xmm10, [rsp+0xA0]
00007f828abe05ec  vmovaps xmm11, [rsp+0xB0]
00007f828abe05f5  vmovaps xmm13, [rsp+0xC0]
00007f828abe05fe  vmovaps xmm14, [rsp+0xD0]
00007f828abe0607  vmovaps xmm15, [rsp+0xE0]
00007f828abe0610  add rsp, 0xF0
00007f828abe0617  pop r11
00007f828abe0619  pop r10
00007f828abe061b  pop r9
00007f828abe061d  pop r8
00007f828abe061f  pop rsi
00007f828abe0620  pop rdi
00007f828abe0621  pop rdx
00007f828abe0622  pop rcx
00007f828abe0623  pop rax
00007f828abe0624  add rsp, 0x08
00007f828abe0628  jmp 0x00007F828ABDC5F4
00007f828abe062d  sub rsp, 0x08
00007f828abe0631  push rax
00007f828abe0632  push rcx
00007f828abe0633  push rdx
00007f828abe0634  push rdi
00007f828abe0635  push rsi
00007f828abe0636  push r8
00007f828abe0638  push r9
00007f828abe063a  push r10
00007f828abe063c  push r11
00007f828abe063e  sub rsp, 0xF0
00007f828abe0645  vmovaps [rsp], xmm0
00007f828abe064a  vmovaps [rsp+0x10], xmm1
00007f828abe0650  vmovaps [rsp+0x20], xmm2
00007f828abe0656  vmovaps [rsp+0x30], xmm3
00007f828abe065c  vmovaps [rsp+0x40], xmm4
00007f828abe0662  vmovaps [rsp+0x50], xmm5
00007f828abe0668  vmovaps [rsp+0x60], xmm6
00007f828abe066e  vmovaps [rsp+0x70], xmm7
00007f828abe0674  vmovaps [rsp+0x80], xmm8
00007f828abe067d  vmovaps [rsp+0x90], xmm9
00007f828abe0686  vmovaps [rsp+0xA0], xmm10
00007f828abe068f  vmovaps [rsp+0xB0], xmm11
00007f828abe0698  vmovaps [rsp+0xC0], xmm12
00007f828abe06a1  vmovaps [rsp+0xD0], xmm14
00007f828abe06aa  vmovaps [rsp+0xE0], xmm15
00007f828abe06b3  sub rsp, 0x30
00007f828abe06b7  movaps [rsp], xmm13
00007f828abe06bc  movaps [rsp+0x10], xmm15
00007f828abe06c2  movaps [rsp+0x20], xmm8
00007f828abe06c8  lea rdi, [rsp]
00007f828abe06cc  mov esi, 0x00
00007f828abe06d1  mov rax, 0x5BFE27FA6530
00007f828abe06db  call rax
00007f828abe06dd  movaps xmm13, [rsp]
00007f828abe06e2  add rsp, 0x30
00007f828abe06e6  vmovaps xmm0, [rsp]
00007f828abe06eb  vmovaps xmm1, [rsp+0x10]
00007f828abe06f1  vmovaps xmm2, [rsp+0x20]
00007f828abe06f7  vmovaps xmm3, [rsp+0x30]
00007f828abe06fd  vmovaps xmm4, [rsp+0x40]
00007f828abe0703  vmovaps xmm5, [rsp+0x50]
00007f828abe0709  vmovaps xmm6, [rsp+0x60]
00007f828abe070f  vmovaps xmm7, [rsp+0x70]
00007f828abe0715  vmovaps xmm8, [rsp+0x80]
00007f828abe071e  vmovaps xmm9, [rsp+0x90]
00007f828abe0727  vmovaps xmm10, [rsp+0xA0]
00007f828abe0730  vmovaps xmm11, [rsp+0xB0]
00007f828abe0739  vmovaps xmm12, [rsp+0xC0]
00007f828abe0742  vmovaps xmm14, [rsp+0xD0]
00007f828abe074b  vmovaps xmm15, [rsp+0xE0]
00007f828abe0754  add rsp, 0xF0
00007f828abe075b  pop r11
00007f828abe075d  pop r10
00007f828abe075f  pop r9
00007f828abe0761  pop r8
00007f828abe0763  pop rsi
00007f828abe0764  pop rdi
00007f828abe0765  pop rdx
00007f828abe0766  pop rcx
00007f828abe0767  pop rax
00007f828abe0768  add rsp, 0x08
00007f828abe076c  jmp 0x00007F828ABDC60F
00007f828abe0771  sub rsp, 0x08
00007f828abe0775  push rax
00007f828abe0776  push rcx
00007f828abe0777  push rdx
00007f828abe0778  push rdi
00007f828abe0779  push rsi
00007f828abe077a  push r8
00007f828abe077c  push r9
00007f828abe077e  push r10
00007f828abe0780  push r11
00007f828abe0782  sub rsp, 0xF0
00007f828abe0789  vmovaps [rsp], xmm0
00007f828abe078e  vmovaps [rsp+0x10], xmm1
00007f828abe0794  vmovaps [rsp+0x20], xmm2
00007f828abe079a  vmovaps [rsp+0x30], xmm3
00007f828abe07a0  vmovaps [rsp+0x40], xmm4
00007f828abe07a6  vmovaps [rsp+0x50], xmm5
00007f828abe07ac  vmovaps [rsp+0x60], xmm6
00007f828abe07b2  vmovaps [rsp+0x70], xmm7
00007f828abe07b8  vmovaps [rsp+0x80], xmm9
00007f828abe07c1  vmovaps [rsp+0x90], xmm10
00007f828abe07ca  vmovaps [rsp+0xA0], xmm11
00007f828abe07d3  vmovaps [rsp+0xB0], xmm12
00007f828abe07dc  vmovaps [rsp+0xC0], xmm13
00007f828abe07e5  vmovaps [rsp+0xD0], xmm14
00007f828abe07ee  vmovaps [rsp+0xE0], xmm15
00007f828abe07f7  sub rsp, 0x30
00007f828abe07fb  movaps [rsp], xmm8
00007f828abe0800  movaps [rsp+0x10], xmm15
00007f828abe0806  movaps [rsp+0x20], xmm9
00007f828abe080c  lea rdi, [rsp]
00007f828abe0810  mov esi, 0x00
00007f828abe0815  mov rax, 0x5BFE27FA6530
00007f828abe081f  call rax
00007f828abe0821  movaps xmm8, [rsp]
00007f828abe0826  add rsp, 0x30
00007f828abe082a  vmovaps xmm0, [rsp]
00007f828abe082f  vmovaps xmm1, [rsp+0x10]
00007f828abe0835  vmovaps xmm2, [rsp+0x20]
00007f828abe083b  vmovaps xmm3, [rsp+0x30]
00007f828abe0841  vmovaps xmm4, [rsp+0x40]
00007f828abe0847  vmovaps xmm5, [rsp+0x50]
00007f828abe084d  vmovaps xmm6, [rsp+0x60]
00007f828abe0853  vmovaps xmm7, [rsp+0x70]
00007f828abe0859  vmovaps xmm9, [rsp+0x80]
00007f828abe0862  vmovaps xmm10, [rsp+0x90]
00007f828abe086b  vmovaps xmm11, [rsp+0xA0]
00007f828abe0874  vmovaps xmm12, [rsp+0xB0]
00007f828abe087d  vmovaps xmm13, [rsp+0xC0]
00007f828abe0886  vmovaps xmm14, [rsp+0xD0]
00007f828abe088f  vmovaps xmm15, [rsp+0xE0]
00007f828abe0898  add rsp, 0xF0
00007f828abe089f  pop r11
00007f828abe08a1  pop r10
00007f828abe08a3  pop r9
00007f828abe08a5  pop r8
00007f828abe08a7  pop rsi
00007f828abe08a8  pop rdi
00007f828abe08a9  pop rdx
00007f828abe08aa  pop rcx
00007f828abe08ab  pop rax
00007f828abe08ac  add rsp, 0x08
00007f828abe08b0  jmp 0x00007F828ABDC63D
00007f828abe08b5  sub rsp, 0x08
00007f828abe08b9  push rax
00007f828abe08ba  push rcx
00007f828abe08bb  push rdx
00007f828abe08bc  push rdi
00007f828abe08bd  push rsi
00007f828abe08be  push r8
00007f828abe08c0  push r9
00007f828abe08c2  push r10
00007f828abe08c4  push r11
00007f828abe08c6  sub rsp, 0xF0
00007f828abe08cd  vmovaps [rsp], xmm0
00007f828abe08d2  vmovaps [rsp+0x10], xmm1
00007f828abe08d8  vmovaps [rsp+0x20], xmm2
00007f828abe08de  vmovaps [rsp+0x30], xmm3
00007f828abe08e4  vmovaps [rsp+0x40], xmm4
00007f828abe08ea  vmovaps [rsp+0x50], xmm5
00007f828abe08f0  vmovaps [rsp+0x60], xmm6
00007f828abe08f6  vmovaps [rsp+0x70], xmm7
00007f828abe08fc  vmovaps [rsp+0x80], xmm8
00007f828abe0905  vmovaps [rsp+0x90], xmm9
00007f828abe090e  vmovaps [rsp+0xA0], xmm10
00007f828abe0917  vmovaps [rsp+0xB0], xmm11
00007f828abe0920  vmovaps [rsp+0xC0], xmm12
00007f828abe0929  vmovaps [rsp+0xD0], xmm13
00007f828abe0932  vmovaps [rsp+0xE0], xmm14
00007f828abe093b  sub rsp, 0x30
00007f828abe093f  movaps [rsp], xmm15
00007f828abe0944  movaps [rsp+0x10], xmm11
00007f828abe094a  movaps [rsp+0x20], xmm6
00007f828abe094f  lea rdi, [rsp]
00007f828abe0953  mov esi, 0x00
00007f828abe0958  mov rax, 0x5BFE27FA6530
00007f828abe0962  call rax
00007f828abe0964  movaps xmm15, [rsp]
00007f828abe0969  add rsp, 0x30
00007f828abe096d  vmovaps xmm0, [rsp]
00007f828abe0972  vmovaps xmm1, [rsp+0x10]
00007f828abe0978  vmovaps xmm2, [rsp+0x20]
00007f828abe097e  vmovaps xmm3, [rsp+0x30]
00007f828abe0984  vmovaps xmm4, [rsp+0x40]
00007f828abe098a  vmovaps xmm5, [rsp+0x50]
00007f828abe0990  vmovaps xmm6, [rsp+0x60]
00007f828abe0996  vmovaps xmm7, [rsp+0x70]
00007f828abe099c  vmovaps xmm8, [rsp+0x80]
00007f828abe09a5  vmovaps xmm9, [rsp+0x90]
00007f828abe09ae  vmovaps xmm10, [rsp+0xA0]
00007f828abe09b7  vmovaps xmm11, [rsp+0xB0]
00007f828abe09c0  vmovaps xmm12, [rsp+0xC0]
00007f828abe09c9  vmovaps xmm13, [rsp+0xD0]
00007f828abe09d2  vmovaps xmm14, [rsp+0xE0]
00007f828abe09db  add rsp, 0xF0
00007f828abe09e2  pop r11
00007f828abe09e4  pop r10
00007f828abe09e6  pop r9
00007f828abe09e8  pop r8
00007f828abe09ea  pop rsi
00007f828abe09eb  pop rdi
00007f828abe09ec  pop rdx
00007f828abe09ed  pop rcx
00007f828abe09ee  pop rax
00007f828abe09ef  add rsp, 0x08
00007f828abe09f3  jmp 0x00007F828ABDC658
00007f828abe09f8  sub rsp, 0x08
00007f828abe09fc  push rax
00007f828abe09fd  push rcx
00007f828abe09fe  push rdx
00007f828abe09ff  push rdi
00007f828abe0a00  push rsi
00007f828abe0a01  push r8
00007f828abe0a03  push r9
00007f828abe0a05  push r10
00007f828abe0a07  push r11
00007f828abe0a09  sub rsp, 0xF0
00007f828abe0a10  vmovaps [rsp], xmm0
00007f828abe0a15  vmovaps [rsp+0x10], xmm1
00007f828abe0a1b  vmovaps [rsp+0x20], xmm2
00007f828abe0a21  vmovaps [rsp+0x30], xmm3
00007f828abe0a27  vmovaps [rsp+0x40], xmm4
00007f828abe0a2d  vmovaps [rsp+0x50], xmm5
00007f828abe0a33  vmovaps [rsp+0x60], xmm6
00007f828abe0a39  vmovaps [rsp+0x70], xmm8
00007f828abe0a3f  vmovaps [rsp+0x80], xmm9
00007f828abe0a48  vmovaps [rsp+0x90], xmm10
00007f828abe0a51  vmovaps [rsp+0xA0], xmm11
00007f828abe0a5a  vmovaps [rsp+0xB0], xmm12
00007f828abe0a63  vmovaps [rsp+0xC0], xmm13
00007f828abe0a6c  vmovaps [rsp+0xD0], xmm14
00007f828abe0a75  vmovaps [rsp+0xE0], xmm15
00007f828abe0a7e  sub rsp, 0x30
00007f828abe0a82  movaps [rsp], xmm7
00007f828abe0a86  movaps [rsp+0x10], xmm11
00007f828abe0a8c  movaps [rsp+0x20], xmm9
00007f828abe0a92  lea rdi, [rsp]
00007f828abe0a96  mov esi, 0x00
00007f828abe0a9b  mov rax, 0x5BFE27FA6530
00007f828abe0aa5  call rax
00007f828abe0aa7  movaps xmm7, [rsp]
00007f828abe0aab  add rsp, 0x30
00007f828abe0aaf  vmovaps xmm0, [rsp]
00007f828abe0ab4  vmovaps xmm1, [rsp+0x10]
00007f828abe0aba  vmovaps xmm2, [rsp+0x20]
00007f828abe0ac0  vmovaps xmm3, [rsp+0x30]
00007f828abe0ac6  vmovaps xmm4, [rsp+0x40]
00007f828abe0acc  vmovaps xmm5, [rsp+0x50]
00007f828abe0ad2  vmovaps xmm6, [rsp+0x60]
00007f828abe0ad8  vmovaps xmm8, [rsp+0x70]
00007f828abe0ade  vmovaps xmm9, [rsp+0x80]
00007f828abe0ae7  vmovaps xmm10, [rsp+0x90]
00007f828abe0af0  vmovaps xmm11, [rsp+0xA0]
00007f828abe0af9  vmovaps xmm12, [rsp+0xB0]
00007f828abe0b02  vmovaps xmm13, [rsp+0xC0]
00007f828abe0b0b  vmovaps xmm14, [rsp+0xD0]
00007f828abe0b14  vmovaps xmm15, [rsp+0xE0]
00007f828abe0b1d  add rsp, 0xF0
00007f828abe0b24  pop r11
00007f828abe0b26  pop r10
00007f828abe0b28  pop r9
00007f828abe0b2a  pop r8
00007f828abe0b2c  pop rsi
00007f828abe0b2d  pop rdi
00007f828abe0b2e  pop rdx
00007f828abe0b2f  pop rcx
00007f828abe0b30  pop rax
00007f828abe0b31  add rsp, 0x08
00007f828abe0b35  jmp 0x00007F828ABDC685
00007f828abe0b3a  sub rsp, 0x08
00007f828abe0b3e  push rax
00007f828abe0b3f  push rcx
00007f828abe0b40  push rdx
00007f828abe0b41  push rdi
00007f828abe0b42  push rsi
00007f828abe0b43  push r8
00007f828abe0b45  push r9
00007f828abe0b47  push r10
00007f828abe0b49  push r11
00007f828abe0b4b  sub rsp, 0xF0
00007f828abe0b52  vmovaps [rsp], xmm0
00007f828abe0b57  vmovaps [rsp+0x10], xmm1
00007f828abe0b5d  vmovaps [rsp+0x20], xmm2
00007f828abe0b63  vmovaps [rsp+0x30], xmm3
00007f828abe0b69  vmovaps [rsp+0x40], xmm4
00007f828abe0b6f  vmovaps [rsp+0x50], xmm5
00007f828abe0b75  vmovaps [rsp+0x60], xmm6
00007f828abe0b7b  vmovaps [rsp+0x70], xmm7
00007f828abe0b81  vmovaps [rsp+0x80], xmm8
00007f828abe0b8a  vmovaps [rsp+0x90], xmm9
00007f828abe0b93  vmovaps [rsp+0xA0], xmm10
00007f828abe0b9c  vmovaps [rsp+0xB0], xmm12
00007f828abe0ba5  vmovaps [rsp+0xC0], xmm13
00007f828abe0bae  vmovaps [rsp+0xD0], xmm14
00007f828abe0bb7  vmovaps [rsp+0xE0], xmm15
00007f828abe0bc0  sub rsp, 0x30
00007f828abe0bc4  movaps [rsp], xmm11
00007f828abe0bc9  movaps [rsp+0x10], xmm10
00007f828abe0bcf  movaps [rsp+0x20], xmm14
00007f828abe0bd5  lea rdi, [rsp]
00007f828abe0bd9  mov esi, 0x00
00007f828abe0bde  mov rax, 0x5BFE27FA6530
00007f828abe0be8  call rax
00007f828abe0bea  movaps xmm11, [rsp]
00007f828abe0bef  add rsp, 0x30
00007f828abe0bf3  vmovaps xmm0, [rsp]
00007f828abe0bf8  vmovaps xmm1, [rsp+0x10]
00007f828abe0bfe  vmovaps xmm2, [rsp+0x20]
00007f828abe0c04  vmovaps xmm3, [rsp+0x30]
00007f828abe0c0a  vmovaps xmm4, [rsp+0x40]
00007f828abe0c10  vmovaps xmm5, [rsp+0x50]
00007f828abe0c16  vmovaps xmm6, [rsp+0x60]
00007f828abe0c1c  vmovaps xmm7, [rsp+0x70]
00007f828abe0c22  vmovaps xmm8, [rsp+0x80]
00007f828abe0c2b  vmovaps xmm9, [rsp+0x90]
00007f828abe0c34  vmovaps xmm10, [rsp+0xA0]
00007f828abe0c3d  vmovaps xmm12, [rsp+0xB0]
00007f828abe0c46  vmovaps xmm13, [rsp+0xC0]
00007f828abe0c4f  vmovaps xmm14, [rsp+0xD0]
00007f828abe0c58  vmovaps xmm15, [rsp+0xE0]
00007f828abe0c61  add rsp, 0xF0
00007f828abe0c68  pop r11
00007f828abe0c6a  pop r10
00007f828abe0c6c  pop r9
00007f828abe0c6e  pop r8
00007f828abe0c70  pop rsi
00007f828abe0c71  pop rdi
00007f828abe0c72  pop rdx
00007f828abe0c73  pop rcx
00007f828abe0c74  pop rax
00007f828abe0c75  add rsp, 0x08
00007f828abe0c79  jmp 0x00007F828ABDC6A0
00007f828abe0c7e  call 0x00007F828AAC33A0
00007f828abe0c83  jmp 0x00007F828ABDC6AA
00007f828abe0c88  sub rsp, 0x08
00007f828abe0c8c  push rax
00007f828abe0c8d  push rcx
00007f828abe0c8e  push rdx
00007f828abe0c8f  push rdi
00007f828abe0c90  push rsi
00007f828abe0c91  push r8
00007f828abe0c93  push r9
00007f828abe0c95  push r10
00007f828abe0c97  push r11
00007f828abe0c99  sub rsp, 0xF0
00007f828abe0ca0  vmovaps [rsp], xmm0
00007f828abe0ca5  vmovaps [rsp+0x10], xmm1
00007f828abe0cab  vmovaps [rsp+0x20], xmm2
00007f828abe0cb1  vmovaps [rsp+0x30], xmm3
00007f828abe0cb7  vmovaps [rsp+0x40], xmm4
00007f828abe0cbd  vmovaps [rsp+0x50], xmm5
00007f828abe0cc3  vmovaps [rsp+0x60], xmm6
00007f828abe0cc9  vmovaps [rsp+0x70], xmm7
00007f828abe0ccf  vmovaps [rsp+0x80], xmm8
00007f828abe0cd8  vmovaps [rsp+0x90], xmm9
00007f828abe0ce1  vmovaps [rsp+0xA0], xmm11
00007f828abe0cea  vmovaps [rsp+0xB0], xmm12
00007f828abe0cf3  vmovaps [rsp+0xC0], xmm13
00007f828abe0cfc  vmovaps [rsp+0xD0], xmm14
00007f828abe0d05  vmovaps [rsp+0xE0], xmm15
00007f828abe0d0e  sub rsp, 0x30
00007f828abe0d12  movaps [rsp], xmm10
00007f828abe0d17  movaps [rsp+0x10], xmm1
00007f828abe0d1c  movaps [rsp+0x20], xmm12
00007f828abe0d22  lea rdi, [rsp]
00007f828abe0d26  mov esi, 0x00
00007f828abe0d2b  mov rax, 0x5BFE27FA6530
00007f828abe0d35  call rax
00007f828abe0d37  movaps xmm10, [rsp]
00007f828abe0d3c  add rsp, 0x30
00007f828abe0d40  vmovaps xmm0, [rsp]
00007f828abe0d45  vmovaps xmm1, [rsp+0x10]
00007f828abe0d4b  vmovaps xmm2, [rsp+0x20]
00007f828abe0d51  vmovaps xmm3, [rsp+0x30]
00007f828abe0d57  vmovaps xmm4, [rsp+0x40]
00007f828abe0d5d  vmovaps xmm5, [rsp+0x50]
00007f828abe0d63  vmovaps xmm6, [rsp+0x60]
00007f828abe0d69  vmovaps xmm7, [rsp+0x70]
00007f828abe0d6f  vmovaps xmm8, [rsp+0x80]
00007f828abe0d78  vmovaps xmm9, [rsp+0x90]
00007f828abe0d81  vmovaps xmm11, [rsp+0xA0]
00007f828abe0d8a  vmovaps xmm12, [rsp+0xB0]
00007f828abe0d93  vmovaps xmm13, [rsp+0xC0]
00007f828abe0d9c  vmovaps xmm14, [rsp+0xD0]
00007f828abe0da5  vmovaps xmm15, [rsp+0xE0]
00007f828abe0dae  add rsp, 0xF0
00007f828abe0db5  pop r11
00007f828abe0db7  pop r10
00007f828abe0db9  pop r9
00007f828abe0dbb  pop r8
00007f828abe0dbd  pop rsi
00007f828abe0dbe  pop rdi
00007f828abe0dbf  pop rdx
00007f828abe0dc0  pop rcx
00007f828abe0dc1  pop rax
00007f828abe0dc2  add rsp, 0x08
00007f828abe0dc6  jmp 0x00007F828ABDC6CD
00007f828abe0dcb  sub rsp, 0x08
00007f828abe0dcf  push rax
00007f828abe0dd0  push rcx
00007f828abe0dd1  push rdx
00007f828abe0dd2  push rdi
00007f828abe0dd3  push rsi
00007f828abe0dd4  push r8
00007f828abe0dd6  push r9
00007f828abe0dd8  push r10
00007f828abe0dda  push r11
00007f828abe0ddc  sub rsp, 0xF0
00007f828abe0de3  vmovaps [rsp], xmm0
00007f828abe0de8  vmovaps [rsp+0x10], xmm1
00007f828abe0dee  vmovaps [rsp+0x20], xmm2
00007f828abe0df4  vmovaps [rsp+0x30], xmm3
00007f828abe0dfa  vmovaps [rsp+0x40], xmm4
00007f828abe0e00  vmovaps [rsp+0x50], xmm5
00007f828abe0e06  vmovaps [rsp+0x60], xmm6
00007f828abe0e0c  vmovaps [rsp+0x70], xmm7
00007f828abe0e12  vmovaps [rsp+0x80], xmm8
00007f828abe0e1b  vmovaps [rsp+0x90], xmm9
00007f828abe0e24  vmovaps [rsp+0xA0], xmm10
00007f828abe0e2d  vmovaps [rsp+0xB0], xmm11
00007f828abe0e36  vmovaps [rsp+0xC0], xmm13
00007f828abe0e3f  vmovaps [rsp+0xD0], xmm14
00007f828abe0e48  vmovaps [rsp+0xE0], xmm15
00007f828abe0e51  sub rsp, 0x30
00007f828abe0e55  movaps [rsp], xmm12
00007f828abe0e5a  movaps [rsp+0x10], xmm14
00007f828abe0e60  movaps [rsp+0x20], xmm1
00007f828abe0e65  lea rdi, [rsp]
00007f828abe0e69  mov esi, 0x00
00007f828abe0e6e  mov rax, 0x5BFE27FA6530
00007f828abe0e78  call rax
00007f828abe0e7a  movaps xmm12, [rsp]
00007f828abe0e7f  add rsp, 0x30
00007f828abe0e83  vmovaps xmm0, [rsp]
00007f828abe0e88  vmovaps xmm1, [rsp+0x10]
00007f828abe0e8e  vmovaps xmm2, [rsp+0x20]
00007f828abe0e94  vmovaps xmm3, [rsp+0x30]
00007f828abe0e9a  vmovaps xmm4, [rsp+0x40]
00007f828abe0ea0  vmovaps xmm5, [rsp+0x50]
00007f828abe0ea6  vmovaps xmm6, [rsp+0x60]
00007f828abe0eac  vmovaps xmm7, [rsp+0x70]
00007f828abe0eb2  vmovaps xmm8, [rsp+0x80]
00007f828abe0ebb  vmovaps xmm9, [rsp+0x90]
00007f828abe0ec4  vmovaps xmm10, [rsp+0xA0]
00007f828abe0ecd  vmovaps xmm11, [rsp+0xB0]
00007f828abe0ed6  vmovaps xmm13, [rsp+0xC0]
00007f828abe0edf  vmovaps xmm14, [rsp+0xD0]
00007f828abe0ee8  vmovaps xmm15, [rsp+0xE0]
00007f828abe0ef1  add rsp, 0xF0
00007f828abe0ef8  pop r11
00007f828abe0efa  pop r10
00007f828abe0efc  pop r9
00007f828abe0efe  pop r8
00007f828abe0f00  pop rsi
00007f828abe0f01  pop rdi
00007f828abe0f02  pop rdx
00007f828abe0f03  pop rcx
00007f828abe0f04  pop rax
00007f828abe0f05  add rsp, 0x08
00007f828abe0f09  jmp 0x00007F828ABDC6FC
00007f828abe0f0e  sub rsp, 0x08
00007f828abe0f12  push rax
00007f828abe0f13  push rcx
00007f828abe0f14  push rdx
00007f828abe0f15  push rdi
00007f828abe0f16  push rsi
00007f828abe0f17  push r8
00007f828abe0f19  push r9
00007f828abe0f1b  push r10
00007f828abe0f1d  push r11
00007f828abe0f1f  sub rsp, 0xF0
00007f828abe0f26  vmovaps [rsp], xmm0
00007f828abe0f2b  vmovaps [rsp+0x10], xmm1
00007f828abe0f31  vmovaps [rsp+0x20], xmm2
00007f828abe0f37  vmovaps [rsp+0x30], xmm3
00007f828abe0f3d  vmovaps [rsp+0x40], xmm4
00007f828abe0f43  vmovaps [rsp+0x50], xmm5
00007f828abe0f49  vmovaps [rsp+0x60], xmm6
00007f828abe0f4f  vmovaps [rsp+0x70], xmm7
00007f828abe0f55  vmovaps [rsp+0x80], xmm8
00007f828abe0f5e  vmovaps [rsp+0x90], xmm9
00007f828abe0f67  vmovaps [rsp+0xA0], xmm10
00007f828abe0f70  vmovaps [rsp+0xB0], xmm11
00007f828abe0f79  vmovaps [rsp+0xC0], xmm12
00007f828abe0f82  vmovaps [rsp+0xD0], xmm13
00007f828abe0f8b  vmovaps [rsp+0xE0], xmm15
00007f828abe0f94  sub rsp, 0x30
00007f828abe0f98  movaps [rsp], xmm14
00007f828abe0f9d  movaps [rsp+0x10], xmm9
00007f828abe0fa3  movaps [rsp+0x20], xmm1
00007f828abe0fa8  lea rdi, [rsp]
00007f828abe0fac  mov esi, 0x00
00007f828abe0fb1  mov rax, 0x5BFE27FA6530
00007f828abe0fbb  call rax
00007f828abe0fbd  movaps xmm14, [rsp]
00007f828abe0fc2  add rsp, 0x30
00007f828abe0fc6  vmovaps xmm0, [rsp]
00007f828abe0fcb  vmovaps xmm1, [rsp+0x10]
00007f828abe0fd1  vmovaps xmm2, [rsp+0x20]
00007f828abe0fd7  vmovaps xmm3, [rsp+0x30]
00007f828abe0fdd  vmovaps xmm4, [rsp+0x40]
00007f828abe0fe3  vmovaps xmm5, [rsp+0x50]
00007f828abe0fe9  vmovaps xmm6, [rsp+0x60]
00007f828abe0fef  vmovaps xmm7, [rsp+0x70]
00007f828abe0ff5  vmovaps xmm8, [rsp+0x80]
00007f828abe0ffe  vmovaps xmm9, [rsp+0x90]
00007f828abe1007  vmovaps xmm10, [rsp+0xA0]
00007f828abe1010  vmovaps xmm11, [rsp+0xB0]
00007f828abe1019  vmovaps xmm12, [rsp+0xC0]
00007f828abe1022  vmovaps xmm13, [rsp+0xD0]
00007f828abe102b  vmovaps xmm15, [rsp+0xE0]
00007f828abe1034  add rsp, 0xF0
00007f828abe103b  pop r11
00007f828abe103d  pop r10
00007f828abe103f  pop r9
00007f828abe1041  pop r8
00007f828abe1043  pop rsi
00007f828abe1044  pop rdi
00007f828abe1045  pop rdx
00007f828abe1046  pop rcx
00007f828abe1047  pop rax
00007f828abe1048  add rsp, 0x08
00007f828abe104c  jmp 0x00007F828ABDC72B
00007f828abe1051  sub rsp, 0x08
00007f828abe1055  push rax
00007f828abe1056  push rcx
00007f828abe1057  push rdx
00007f828abe1058  push rdi
00007f828abe1059  push rsi
00007f828abe105a  push r8
00007f828abe105c  push r9
00007f828abe105e  push r10
00007f828abe1060  push r11
00007f828abe1062  sub rsp, 0xF0
00007f828abe1069  vmovaps [rsp], xmm0
00007f828abe106e  vmovaps [rsp+0x10], xmm2
00007f828abe1074  vmovaps [rsp+0x20], xmm3
00007f828abe107a  vmovaps [rsp+0x30], xmm4
00007f828abe1080  vmovaps [rsp+0x40], xmm5
00007f828abe1086  vmovaps [rsp+0x50], xmm6
00007f828abe108c  vmovaps [rsp+0x60], xmm7
00007f828abe1092  vmovaps [rsp+0x70], xmm8
00007f828abe1098  vmovaps [rsp+0x80], xmm9
00007f828abe10a1  vmovaps [rsp+0x90], xmm10
00007f828abe10aa  vmovaps [rsp+0xA0], xmm11
00007f828abe10b3  vmovaps [rsp+0xB0], xmm12
00007f828abe10bc  vmovaps [rsp+0xC0], xmm13
00007f828abe10c5  vmovaps [rsp+0xD0], xmm14
00007f828abe10ce  vmovaps [rsp+0xE0], xmm15
00007f828abe10d7  sub rsp, 0x30
00007f828abe10db  movaps [rsp], xmm1
00007f828abe10df  movaps [rsp+0x10], xmm13
00007f828abe10e5  movaps [rsp+0x20], xmm8
00007f828abe10eb  lea rdi, [rsp]
00007f828abe10ef  mov esi, 0x00
00007f828abe10f4  mov rax, 0x5BFE27FA6530
00007f828abe10fe  call rax
00007f828abe1100  movaps xmm1, [rsp]
00007f828abe1104  add rsp, 0x30
00007f828abe1108  vmovaps xmm0, [rsp]
00007f828abe110d  vmovaps xmm2, [rsp+0x10]
00007f828abe1113  vmovaps xmm3, [rsp+0x20]
00007f828abe1119  vmovaps xmm4, [rsp+0x30]
00007f828abe111f  vmovaps xmm5, [rsp+0x40]
00007f828abe1125  vmovaps xmm6, [rsp+0x50]
00007f828abe112b  vmovaps xmm7, [rsp+0x60]
00007f828abe1131  vmovaps xmm8, [rsp+0x70]
00007f828abe1137  vmovaps xmm9, [rsp+0x80]
00007f828abe1140  vmovaps xmm10, [rsp+0x90]
00007f828abe1149  vmovaps xmm11, [rsp+0xA0]
00007f828abe1152  vmovaps xmm12, [rsp+0xB0]
00007f828abe115b  vmovaps xmm13, [rsp+0xC0]
00007f828abe1164  vmovaps xmm14, [rsp+0xD0]
00007f828abe116d  vmovaps xmm15, [rsp+0xE0]
00007f828abe1176  add rsp, 0xF0
00007f828abe117d  pop r11
00007f828abe117f  pop r10
00007f828abe1181  pop r9
00007f828abe1183  pop r8
00007f828abe1185  pop rsi
00007f828abe1186  pop rdi
00007f828abe1187  pop rdx
00007f828abe1188  pop rcx
00007f828abe1189  pop rax
00007f828abe118a  add rsp, 0x08
00007f828abe118e  jmp 0x00007F828ABDC74D
00007f828abe1193  call 0x00007F828AA0C260
00007f828abe1198  jmp 0x00007F828ABDC75B
00007f828abe119d  call 0x00007F828AABD750
00007f828abe11a2  jmp 0x00007F828ABDC765
00007f828abe11a7  sub rsp, 0x08
00007f828abe11ab  push rax
00007f828abe11ac  push rcx
00007f828abe11ad  push rdx
00007f828abe11ae  push rdi
00007f828abe11af  push rsi
00007f828abe11b0  push r8
00007f828abe11b2  push r9
00007f828abe11b4  push r10
00007f828abe11b6  push r11
00007f828abe11b8  sub rsp, 0xF0
00007f828abe11bf  vmovaps [rsp], xmm0
00007f828abe11c4  vmovaps [rsp+0x10], xmm1
00007f828abe11ca  vmovaps [rsp+0x20], xmm2
00007f828abe11d0  vmovaps [rsp+0x30], xmm3
00007f828abe11d6  vmovaps [rsp+0x40], xmm4
00007f828abe11dc  vmovaps [rsp+0x50], xmm5
00007f828abe11e2  vmovaps [rsp+0x60], xmm6
00007f828abe11e8  vmovaps [rsp+0x70], xmm7
00007f828abe11ee  vmovaps [rsp+0x80], xmm9
00007f828abe11f7  vmovaps [rsp+0x90], xmm10
00007f828abe1200  vmovaps [rsp+0xA0], xmm11
00007f828abe1209  vmovaps [rsp+0xB0], xmm12
00007f828abe1212  vmovaps [rsp+0xC0], xmm13
00007f828abe121b  vmovaps [rsp+0xD0], xmm14
00007f828abe1224  vmovaps [rsp+0xE0], xmm15
00007f828abe122d  sub rsp, 0x30
00007f828abe1231  movaps [rsp], xmm8
00007f828abe1236  movaps [rsp+0x10], xmm15
00007f828abe123c  movaps [rsp+0x20], xmm7
00007f828abe1241  lea rdi, [rsp]
00007f828abe1245  mov esi, 0x00
00007f828abe124a  mov rax, 0x5BFE27FA6530
00007f828abe1254  call rax
00007f828abe1256  movaps xmm8, [rsp]
00007f828abe125b  add rsp, 0x30
00007f828abe125f  vmovaps xmm0, [rsp]
00007f828abe1264  vmovaps xmm1, [rsp+0x10]
00007f828abe126a  vmovaps xmm2, [rsp+0x20]
00007f828abe1270  vmovaps xmm3, [rsp+0x30]
00007f828abe1276  vmovaps xmm4, [rsp+0x40]
00007f828abe127c  vmovaps xmm5, [rsp+0x50]
00007f828abe1282  vmovaps xmm6, [rsp+0x60]
00007f828abe1288  vmovaps xmm7, [rsp+0x70]
00007f828abe128e  vmovaps xmm9, [rsp+0x80]
00007f828abe1297  vmovaps xmm10, [rsp+0x90]
00007f828abe12a0  vmovaps xmm11, [rsp+0xA0]
00007f828abe12a9  vmovaps xmm12, [rsp+0xB0]
00007f828abe12b2  vmovaps xmm13, [rsp+0xC0]
00007f828abe12bb  vmovaps xmm14, [rsp+0xD0]
00007f828abe12c4  vmovaps xmm15, [rsp+0xE0]
00007f828abe12cd  add rsp, 0xF0
00007f828abe12d4  pop r11
00007f828abe12d6  pop r10
00007f828abe12d8  pop r9
00007f828abe12da  pop r8
00007f828abe12dc  pop rsi
00007f828abe12dd  pop rdi
00007f828abe12de  pop rdx
00007f828abe12df  pop rcx
00007f828abe12e0  pop rax
00007f828abe12e1  add rsp, 0x08
00007f828abe12e5  jmp 0x00007F828ABDC787
00007f828abe12ea  sub rsp, 0x08
00007f828abe12ee  push rax
00007f828abe12ef  push rcx
00007f828abe12f0  push rdx
00007f828abe12f1  push rdi
00007f828abe12f2  push rsi
00007f828abe12f3  push r8
00007f828abe12f5  push r9
00007f828abe12f7  push r10
00007f828abe12f9  push r11
00007f828abe12fb  sub rsp, 0xF0
00007f828abe1302  vmovaps [rsp], xmm0
00007f828abe1307  vmovaps [rsp+0x10], xmm1
00007f828abe130d  vmovaps [rsp+0x20], xmm2
00007f828abe1313  vmovaps [rsp+0x30], xmm3
00007f828abe1319  vmovaps [rsp+0x40], xmm4
00007f828abe131f  vmovaps [rsp+0x50], xmm5
00007f828abe1325  vmovaps [rsp+0x60], xmm6
00007f828abe132b  vmovaps [rsp+0x70], xmm8
00007f828abe1331  vmovaps [rsp+0x80], xmm9
00007f828abe133a  vmovaps [rsp+0x90], xmm10
00007f828abe1343  vmovaps [rsp+0xA0], xmm11
00007f828abe134c  vmovaps [rsp+0xB0], xmm12
00007f828abe1355  vmovaps [rsp+0xC0], xmm13
00007f828abe135e  vmovaps [rsp+0xD0], xmm14
00007f828abe1367  vmovaps [rsp+0xE0], xmm15
00007f828abe1370  sub rsp, 0x30
00007f828abe1374  movaps [rsp], xmm7
00007f828abe1378  movaps [rsp+0x10], xmm9
00007f828abe137e  movaps [rsp+0x20], xmm15
00007f828abe1384  lea rdi, [rsp]
00007f828abe1388  mov esi, 0x00
00007f828abe138d  mov rax, 0x5BFE27FA6530
00007f828abe1397  call rax
00007f828abe1399  movaps xmm7, [rsp]
00007f828abe139d  add rsp, 0x30
00007f828abe13a1  vmovaps xmm0, [rsp]
00007f828abe13a6  vmovaps xmm1, [rsp+0x10]
00007f828abe13ac  vmovaps xmm2, [rsp+0x20]
00007f828abe13b2  vmovaps xmm3, [rsp+0x30]
00007f828abe13b8  vmovaps xmm4, [rsp+0x40]
00007f828abe13be  vmovaps xmm5, [rsp+0x50]
00007f828abe13c4  vmovaps xmm6, [rsp+0x60]
00007f828abe13ca  vmovaps xmm8, [rsp+0x70]
00007f828abe13d0  vmovaps xmm9, [rsp+0x80]
00007f828abe13d9  vmovaps xmm10, [rsp+0x90]
00007f828abe13e2  vmovaps xmm11, [rsp+0xA0]
00007f828abe13eb  vmovaps xmm12, [rsp+0xB0]
00007f828abe13f4  vmovaps xmm13, [rsp+0xC0]
00007f828abe13fd  vmovaps xmm14, [rsp+0xD0]
00007f828abe1406  vmovaps xmm15, [rsp+0xE0]
00007f828abe140f  add rsp, 0xF0
00007f828abe1416  pop r11
00007f828abe1418  pop r10
00007f828abe141a  pop r9
00007f828abe141c  pop r8
00007f828abe141e  pop rsi
00007f828abe141f  pop rdi
00007f828abe1420  pop rdx
00007f828abe1421  pop rcx
00007f828abe1422  pop rax
00007f828abe1423  add rsp, 0x08
00007f828abe1427  jmp 0x00007F828ABDC7B4
00007f828abe142c  sub rsp, 0x08
00007f828abe1430  push rax
00007f828abe1431  push rcx
00007f828abe1432  push rdx
00007f828abe1433  push rdi
00007f828abe1434  push rsi
00007f828abe1435  push r8
00007f828abe1437  push r9
00007f828abe1439  push r10
00007f828abe143b  push r11
00007f828abe143d  sub rsp, 0xF0
00007f828abe1444  vmovaps [rsp], xmm0
00007f828abe1449  vmovaps [rsp+0x10], xmm1
00007f828abe144f  vmovaps [rsp+0x20], xmm2
00007f828abe1455  vmovaps [rsp+0x30], xmm3
00007f828abe145b  vmovaps [rsp+0x40], xmm4
00007f828abe1461  vmovaps [rsp+0x50], xmm5
00007f828abe1467  vmovaps [rsp+0x60], xmm6
00007f828abe146d  vmovaps [rsp+0x70], xmm7
00007f828abe1473  vmovaps [rsp+0x80], xmm8
00007f828abe147c  vmovaps [rsp+0x90], xmm10
00007f828abe1485  vmovaps [rsp+0xA0], xmm11
00007f828abe148e  vmovaps [rsp+0xB0], xmm12
00007f828abe1497  vmovaps [rsp+0xC0], xmm13
00007f828abe14a0  vmovaps [rsp+0xD0], xmm14
00007f828abe14a9  vmovaps [rsp+0xE0], xmm15
00007f828abe14b2  sub rsp, 0x30
00007f828abe14b6  movaps [rsp], xmm9
00007f828abe14bb  movaps [rsp+0x10], xmm13
00007f828abe14c1  movaps [rsp+0x20], xmm15
00007f828abe14c7  lea rdi, [rsp]
00007f828abe14cb  mov esi, 0x00
00007f828abe14d0  mov rax, 0x5BFE27FA6530
00007f828abe14da  call rax
00007f828abe14dc  movaps xmm9, [rsp]
00007f828abe14e1  add rsp, 0x30
00007f828abe14e5  vmovaps xmm0, [rsp]
00007f828abe14ea  vmovaps xmm1, [rsp+0x10]
00007f828abe14f0  vmovaps xmm2, [rsp+0x20]
00007f828abe14f6  vmovaps xmm3, [rsp+0x30]
00007f828abe14fc  vmovaps xmm4, [rsp+0x40]
00007f828abe1502  vmovaps xmm5, [rsp+0x50]
00007f828abe1508  vmovaps xmm6, [rsp+0x60]
00007f828abe150e  vmovaps xmm7, [rsp+0x70]
00007f828abe1514  vmovaps xmm8, [rsp+0x80]
00007f828abe151d  vmovaps xmm10, [rsp+0x90]
00007f828abe1526  vmovaps xmm11, [rsp+0xA0]
00007f828abe152f  vmovaps xmm12, [rsp+0xB0]
00007f828abe1538  vmovaps xmm13, [rsp+0xC0]
00007f828abe1541  vmovaps xmm14, [rsp+0xD0]
00007f828abe154a  vmovaps xmm15, [rsp+0xE0]
00007f828abe1553  add rsp, 0xF0
00007f828abe155a  pop r11
00007f828abe155c  pop r10
00007f828abe155e  pop r9
00007f828abe1560  pop r8
00007f828abe1562  pop rsi
00007f828abe1563  pop rdi
00007f828abe1564  pop rdx
00007f828abe1565  pop rcx
00007f828abe1566  pop rax
00007f828abe1567  add rsp, 0x08
00007f828abe156b  jmp 0x00007F828ABDC7E2
00007f828abe1570  sub rsp, 0x08
00007f828abe1574  push rax
00007f828abe1575  push rcx
00007f828abe1576  push rdx
00007f828abe1577  push rdi
00007f828abe1578  push rsi
00007f828abe1579  push r8
00007f828abe157b  push r9
00007f828abe157d  push r10
00007f828abe157f  push r11
00007f828abe1581  sub rsp, 0xF0
00007f828abe1588  vmovaps [rsp], xmm0
00007f828abe158d  vmovaps [rsp+0x10], xmm1
00007f828abe1593  vmovaps [rsp+0x20], xmm2
00007f828abe1599  vmovaps [rsp+0x30], xmm3
00007f828abe159f  vmovaps [rsp+0x40], xmm4
00007f828abe15a5  vmovaps [rsp+0x50], xmm5
00007f828abe15ab  vmovaps [rsp+0x60], xmm6
00007f828abe15b1  vmovaps [rsp+0x70], xmm7
00007f828abe15b7  vmovaps [rsp+0x80], xmm8
00007f828abe15c0  vmovaps [rsp+0x90], xmm9
00007f828abe15c9  vmovaps [rsp+0xA0], xmm10
00007f828abe15d2  vmovaps [rsp+0xB0], xmm11
00007f828abe15db  vmovaps [rsp+0xC0], xmm12
00007f828abe15e4  vmovaps [rsp+0xD0], xmm13
00007f828abe15ed  vmovaps [rsp+0xE0], xmm14
00007f828abe15f6  sub rsp, 0x30
00007f828abe15fa  movaps [rsp], xmm15
00007f828abe15ff  movaps [rsp+0x10], xmm11
00007f828abe1605  movaps [rsp+0x20], xmm12
00007f828abe160b  lea rdi, [rsp]
00007f828abe160f  mov esi, 0x00
00007f828abe1614  mov rax, 0x5BFE27FA6530
00007f828abe161e  call rax
00007f828abe1620  movaps xmm15, [rsp]
00007f828abe1625  add rsp, 0x30
00007f828abe1629  vmovaps xmm0, [rsp]
00007f828abe162e  vmovaps xmm1, [rsp+0x10]
00007f828abe1634  vmovaps xmm2, [rsp+0x20]
00007f828abe163a  vmovaps xmm3, [rsp+0x30]
00007f828abe1640  vmovaps xmm4, [rsp+0x40]
00007f828abe1646  vmovaps xmm5, [rsp+0x50]
00007f828abe164c  vmovaps xmm6, [rsp+0x60]
00007f828abe1652  vmovaps xmm7, [rsp+0x70]
00007f828abe1658  vmovaps xmm8, [rsp+0x80]
00007f828abe1661  vmovaps xmm9, [rsp+0x90]
00007f828abe166a  vmovaps xmm10, [rsp+0xA0]
00007f828abe1673  vmovaps xmm11, [rsp+0xB0]
00007f828abe167c  vmovaps xmm12, [rsp+0xC0]
00007f828abe1685  vmovaps xmm13, [rsp+0xD0]
00007f828abe168e  vmovaps xmm14, [rsp+0xE0]
00007f828abe1697  add rsp, 0xF0
00007f828abe169e  pop r11
00007f828abe16a0  pop r10
00007f828abe16a2  pop r9
00007f828abe16a4  pop r8
00007f828abe16a6  pop rsi
00007f828abe16a7  pop rdi
00007f828abe16a8  pop rdx
00007f828abe16a9  pop rcx
00007f828abe16aa  pop rax
00007f828abe16ab  add rsp, 0x08
00007f828abe16af  jmp 0x00007F828ABDC7FD
00007f828abe16b4  sub rsp, 0x08
00007f828abe16b8  push rax
00007f828abe16b9  push rcx
00007f828abe16ba  push rdx
00007f828abe16bb  push rdi
00007f828abe16bc  push rsi
00007f828abe16bd  push r8
00007f828abe16bf  push r9
00007f828abe16c1  push r10
00007f828abe16c3  push r11
00007f828abe16c5  sub rsp, 0xF0
00007f828abe16cc  vmovaps [rsp], xmm0
00007f828abe16d1  vmovaps [rsp+0x10], xmm1
00007f828abe16d7  vmovaps [rsp+0x20], xmm2
00007f828abe16dd  vmovaps [rsp+0x30], xmm3
00007f828abe16e3  vmovaps [rsp+0x40], xmm4
00007f828abe16e9  vmovaps [rsp+0x50], xmm5
00007f828abe16ef  vmovaps [rsp+0x60], xmm6
00007f828abe16f5  vmovaps [rsp+0x70], xmm7
00007f828abe16fb  vmovaps [rsp+0x80], xmm8
00007f828abe1704  vmovaps [rsp+0x90], xmm9
00007f828abe170d  vmovaps [rsp+0xA0], xmm10
00007f828abe1716  vmovaps [rsp+0xB0], xmm11
00007f828abe171f  vmovaps [rsp+0xC0], xmm12
00007f828abe1728  vmovaps [rsp+0xD0], xmm14
00007f828abe1731  vmovaps [rsp+0xE0], xmm15
00007f828abe173a  sub rsp, 0x30
00007f828abe173e  movaps [rsp], xmm13
00007f828abe1743  movaps [rsp+0x10], xmm10
00007f828abe1749  movaps [rsp+0x20], xmm14
00007f828abe174f  lea rdi, [rsp]
00007f828abe1753  mov esi, 0x00
00007f828abe1758  mov rax, 0x5BFE27FA6530
00007f828abe1762  call rax
00007f828abe1764  movaps xmm13, [rsp]
00007f828abe1769  add rsp, 0x30
00007f828abe176d  vmovaps xmm0, [rsp]
00007f828abe1772  vmovaps xmm1, [rsp+0x10]
00007f828abe1778  vmovaps xmm2, [rsp+0x20]
00007f828abe177e  vmovaps xmm3, [rsp+0x30]
00007f828abe1784  vmovaps xmm4, [rsp+0x40]
00007f828abe178a  vmovaps xmm5, [rsp+0x50]
00007f828abe1790  vmovaps xmm6, [rsp+0x60]
00007f828abe1796  vmovaps xmm7, [rsp+0x70]
00007f828abe179c  vmovaps xmm8, [rsp+0x80]
00007f828abe17a5  vmovaps xmm9, [rsp+0x90]
00007f828abe17ae  vmovaps xmm10, [rsp+0xA0]
00007f828abe17b7  vmovaps xmm11, [rsp+0xB0]
00007f828abe17c0  vmovaps xmm12, [rsp+0xC0]
00007f828abe17c9  vmovaps xmm14, [rsp+0xD0]
00007f828abe17d2  vmovaps xmm15, [rsp+0xE0]
00007f828abe17db  add rsp, 0xF0
00007f828abe17e2  pop r11
00007f828abe17e4  pop r10
00007f828abe17e6  pop r9
00007f828abe17e8  pop r8
00007f828abe17ea  pop rsi
00007f828abe17eb  pop rdi
00007f828abe17ec  pop rdx
00007f828abe17ed  pop rcx
00007f828abe17ee  pop rax
00007f828abe17ef  add rsp, 0x08
00007f828abe17f3  jmp 0x00007F828ABDC820
00007f828abe17f8  sub rsp, 0x08
00007f828abe17fc  push rax
00007f828abe17fd  push rcx
00007f828abe17fe  push rdx
00007f828abe17ff  push rdi
00007f828abe1800  push rsi
00007f828abe1801  push r8
00007f828abe1803  push r9
00007f828abe1805  push r10
00007f828abe1807  push r11
00007f828abe1809  sub rsp, 0xF0
00007f828abe1810  vmovaps [rsp], xmm0
00007f828abe1815  vmovaps [rsp+0x10], xmm1
00007f828abe181b  vmovaps [rsp+0x20], xmm2
00007f828abe1821  vmovaps [rsp+0x30], xmm3
00007f828abe1827  vmovaps [rsp+0x40], xmm4
00007f828abe182d  vmovaps [rsp+0x50], xmm5
00007f828abe1833  vmovaps [rsp+0x60], xmm6
00007f828abe1839  vmovaps [rsp+0x70], xmm7
00007f828abe183f  vmovaps [rsp+0x80], xmm8
00007f828abe1848  vmovaps [rsp+0x90], xmm9
00007f828abe1851  vmovaps [rsp+0xA0], xmm10
00007f828abe185a  vmovaps [rsp+0xB0], xmm11
00007f828abe1863  vmovaps [rsp+0xC0], xmm12
00007f828abe186c  vmovaps [rsp+0xD0], xmm13
00007f828abe1875  vmovaps [rsp+0xE0], xmm15
00007f828abe187e  sub rsp, 0x30
00007f828abe1882  movaps [rsp], xmm14
00007f828abe1887  movaps [rsp+0x10], xmm1
00007f828abe188c  movaps [rsp+0x20], xmm7
00007f828abe1891  lea rdi, [rsp]
00007f828abe1895  mov esi, 0x00
00007f828abe189a  mov rax, 0x5BFE27FA6530
00007f828abe18a4  call rax
00007f828abe18a6  movaps xmm14, [rsp]
00007f828abe18ab  add rsp, 0x30
00007f828abe18af  vmovaps xmm0, [rsp]
00007f828abe18b4  vmovaps xmm1, [rsp+0x10]
00007f828abe18ba  vmovaps xmm2, [rsp+0x20]
00007f828abe18c0  vmovaps xmm3, [rsp+0x30]
00007f828abe18c6  vmovaps xmm4, [rsp+0x40]
00007f828abe18cc  vmovaps xmm5, [rsp+0x50]
00007f828abe18d2  vmovaps xmm6, [rsp+0x60]
00007f828abe18d8  vmovaps xmm7, [rsp+0x70]
00007f828abe18de  vmovaps xmm8, [rsp+0x80]
00007f828abe18e7  vmovaps xmm9, [rsp+0x90]
00007f828abe18f0  vmovaps xmm10, [rsp+0xA0]
00007f828abe18f9  vmovaps xmm11, [rsp+0xB0]
00007f828abe1902  vmovaps xmm12, [rsp+0xC0]
00007f828abe190b  vmovaps xmm13, [rsp+0xD0]
00007f828abe1914  vmovaps xmm15, [rsp+0xE0]
00007f828abe191d  add rsp, 0xF0
00007f828abe1924  pop r11
00007f828abe1926  pop r10
00007f828abe1928  pop r9
00007f828abe192a  pop r8
00007f828abe192c  pop rsi
00007f828abe192d  pop rdi
00007f828abe192e  pop rdx
00007f828abe192f  pop rcx
00007f828abe1930  pop rax
00007f828abe1931  add rsp, 0x08
00007f828abe1935  jmp 0x00007F828ABDC843
00007f828abe193a  sub rsp, 0x08
00007f828abe193e  push rax
00007f828abe193f  push rcx
00007f828abe1940  push rdx
00007f828abe1941  push rdi
00007f828abe1942  push rsi
00007f828abe1943  push r8
00007f828abe1945  push r9
00007f828abe1947  push r10
00007f828abe1949  push r11
00007f828abe194b  sub rsp, 0xF0
00007f828abe1952  vmovaps [rsp], xmm0
00007f828abe1957  vmovaps [rsp+0x10], xmm2
00007f828abe195d  vmovaps [rsp+0x20], xmm3
00007f828abe1963  vmovaps [rsp+0x30], xmm4
00007f828abe1969  vmovaps [rsp+0x40], xmm5
00007f828abe196f  vmovaps [rsp+0x50], xmm6
00007f828abe1975  vmovaps [rsp+0x60], xmm7
00007f828abe197b  vmovaps [rsp+0x70], xmm8
00007f828abe1981  vmovaps [rsp+0x80], xmm9
00007f828abe198a  vmovaps [rsp+0x90], xmm10
00007f828abe1993  vmovaps [rsp+0xA0], xmm11
00007f828abe199c  vmovaps [rsp+0xB0], xmm12
00007f828abe19a5  vmovaps [rsp+0xC0], xmm13
00007f828abe19ae  vmovaps [rsp+0xD0], xmm14
00007f828abe19b7  vmovaps [rsp+0xE0], xmm15
00007f828abe19c0  sub rsp, 0x30
00007f828abe19c4  movaps [rsp], xmm1
00007f828abe19c8  movaps [rsp+0x10], xmm8
00007f828abe19ce  movaps [rsp+0x20], xmm9
00007f828abe19d4  lea rdi, [rsp]
00007f828abe19d8  mov esi, 0x00
00007f828abe19dd  mov rax, 0x5BFE27FA6530
00007f828abe19e7  call rax
00007f828abe19e9  movaps xmm1, [rsp]
00007f828abe19ed  add rsp, 0x30
00007f828abe19f1  vmovaps xmm0, [rsp]
00007f828abe19f6  vmovaps xmm2, [rsp+0x10]
00007f828abe19fc  vmovaps xmm3, [rsp+0x20]
00007f828abe1a02  vmovaps xmm4, [rsp+0x30]
00007f828abe1a08  vmovaps xmm5, [rsp+0x40]
00007f828abe1a0e  vmovaps xmm6, [rsp+0x50]
00007f828abe1a14  vmovaps xmm7, [rsp+0x60]
00007f828abe1a1a  vmovaps xmm8, [rsp+0x70]
00007f828abe1a20  vmovaps xmm9, [rsp+0x80]
00007f828abe1a29  vmovaps xmm10, [rsp+0x90]
00007f828abe1a32  vmovaps xmm11, [rsp+0xA0]
00007f828abe1a3b  vmovaps xmm12, [rsp+0xB0]
00007f828abe1a44  vmovaps xmm13, [rsp+0xC0]
00007f828abe1a4d  vmovaps xmm14, [rsp+0xD0]
00007f828abe1a56  vmovaps xmm15, [rsp+0xE0]
00007f828abe1a5f  add rsp, 0xF0
00007f828abe1a66  pop r11
00007f828abe1a68  pop r10
00007f828abe1a6a  pop r9
00007f828abe1a6c  pop r8
00007f828abe1a6e  pop rsi
00007f828abe1a6f  pop rdi
00007f828abe1a70  pop rdx
00007f828abe1a71  pop rcx
00007f828abe1a72  pop rax
00007f828abe1a73  add rsp, 0x08
00007f828abe1a77  jmp 0x00007F828ABDC865
00007f828abe1a7c  call 0x00007F828AAE5940
00007f828abe1a81  jmp 0x00007F828ABDC873
00007f828abe1a86  call 0x00007F828AA0C380
00007f828abe1a8b  jmp 0x00007F828ABDC87D
00007f828abe1a90  call 0x00007F828AA0D600
00007f828abe1a95  jmp 0x00007F828ABDC887
00007f828abe1a9a  call 0x00007F828A9FF540
00007f828abe1a9f  jmp 0x00007F828ABDC891
00007f828abe1aa4  int3
00007f828abe1aa5  nop [rax+rax*1], ax
00007f828abe1aae  nop
00007f828abe1ab0  mov rax, [r15+0xF8]
00007f828abe1ab7  lea r14, [rax+0x140]
00007f828abe1abe  mov r12, [r13+r14*1]
00007f828abe1ac3  mov [r15+0xE8], r12
00007f828abe1aca  lea r14, [rax+0x130]
00007f828abe1ad1  mov r12, [r13+r14*1]
00007f828abe1ad6  lea r14, [rax+0x138]
00007f828abe1add  mov r11, [r13+r14*1]
00007f828abe1ae2  movq xmm1, r12
00007f828abe1ae7  movq xmm15, r11
00007f828abe1aec  movq xmm1, xmm1
00007f828abe1af0  movq xmm1, xmm1
00007f828abe1af4  movaps [r15+0x1A0], xmm1
00007f828abe1afc  movq xmm15, xmm15
00007f828abe1b01  movq xmm15, xmm15
00007f828abe1b06  movaps [r15+0x190], xmm15
00007f828abe1b0e  lea r14, [rax+0x120]
00007f828abe1b15  mov r12, [r13+r14*1]
00007f828abe1b1a  lea r14, [rax+0x128]
00007f828abe1b21  mov r11, [r13+r14*1]
00007f828abe1b26  movq xmm1, r12
00007f828abe1b2b  movq xmm15, r11
00007f828abe1b30  movq xmm1, xmm1
00007f828abe1b34  movq xmm1, xmm1
00007f828abe1b38  movaps [r15+0x1C0], xmm1
00007f828abe1b40  movq xmm15, xmm15
00007f828abe1b45  movq xmm15, xmm15
00007f828abe1b4a  movaps [r15+0x1B0], xmm15
00007f828abe1b52  lea r14, [rax+0x110]
00007f828abe1b59  mov r12, [r13+r14*1]
00007f828abe1b5e  lea r14, [rax+0x118]
00007f828abe1b65  mov r11, [r13+r14*1]
00007f828abe1b6a  movq xmm1, r12
00007f828abe1b6f  movq xmm15, r11
00007f828abe1b74  movq xmm1, xmm1
00007f828abe1b78  movq xmm1, xmm1
00007f828abe1b7c  movaps [r15+0x1E0], xmm1
00007f828abe1b84  movq xmm15, xmm15
00007f828abe1b89  movq xmm15, xmm15
00007f828abe1b8e  movaps [r15+0x1D0], xmm15
00007f828abe1b96  lea r14, [rax+0x100]
00007f828abe1b9d  mov r12, [r13+r14*1]
00007f828abe1ba2  lea r14, [rax+0x108]
00007f828abe1ba9  mov r11, [r13+r14*1]
00007f828abe1bae  movq xmm1, r12
00007f828abe1bb3  movq xmm15, r11
00007f828abe1bb8  movq xmm1, xmm1
00007f828abe1bbc  movq xmm1, xmm1
00007f828abe1bc0  movaps [r15+0x200], xmm1
00007f828abe1bc8  movq xmm15, xmm15
00007f828abe1bcd  movq xmm15, xmm15
00007f828abe1bd2  movaps [r15+0x1F0], xmm15
00007f828abe1bda  mov qword ptr [r15+0x40], 0x430000
00007f828abe1be2  mov r14d, 0x430510
00007f828abe1be8  mov r12, [r13+r14*1]
00007f828abe1bed  movq xmm1, r12
00007f828abe1bf2  lea r14, [rax+0x150]
00007f828abe1bf9  mov [r15+0xF8], r14
00007f828abe1c00  mov rax, [r15+0x50]
00007f828abe1c04  movups xmm15, [r13+rax*1]
00007f828abe1c0a  movaps [r15+0x120], xmm15
00007f828abe1c12  mov qword ptr [r15+0x48], 0x10
00007f828abe1c1a  xor eax, eax
00007f828abe1c1c  mov r14d, 0x10
00007f828abe1c22  mov r12d, 0x200
00007f828abe1c28  cmp r14, r12
00007f828abe1c2b  cmc
00007f828abe1c2c  lahf
00007f828abe1c2d  seto al
00007f828abe1c30  mov [r15+0x108], eax
00007f828abe1c37  pextrq rax, xmm15, 0x01
00007f828abe1c3e  movq xmm14, rax
00007f828abe1c43  movaps [r15+0x130], xmm14
00007f828abe1c4b  movq rax, xmm1
00007f828abe1c50  movq r14, xmm15
00007f828abe1c55  vmovq xmm1, rax
00007f828abe1c5a  vmovq xmm15, r14
00007f828abe1c5f  movaps xmm13, xmm1
00007f828abe1c63  addsd xmm13, xmm15
00007f828abe1c68  ucomisd xmm13, xmm13
00007f828abe1c6d  jp 0x00007F828ABE1D86
00007f828abe1c73  movq xmm13, xmm13
00007f828abe1c78  movq rax, xmm13
00007f828abe1c7d  movq r14, xmm14
00007f828abe1c82  vmovq xmm1, rax
00007f828abe1c87  vmovq xmm15, r14
00007f828abe1c8c  movaps xmm14, xmm1
00007f828abe1c90  addsd xmm14, xmm15
00007f828abe1c95  ucomisd xmm14, xmm14
00007f828abe1c9a  jp 0x00007F828ABE1DCE
00007f828abe1ca0  movq xmm14, xmm14
00007f828abe1ca5  movaps [r15+0x110], xmm14
00007f828abe1cad  mov eax, [r15+0x108]
00007f828abe1cb4  sahf
00007f828abe1cb5  jnz 0x00007F828ABE1CE7
00007f828abe1cb7  cmp dword ptr [r15+0x318], 0x00
00007f828abe1cbf  jz 0x00007F828ABE1FE0
00007f828abe1cc5  nop [rax+rax*1], ax
00007f828abe1cce  nop [rax+rax*1], eax
00007f828abe1cd6  mov eax, 0x410490
00007f828abe1cdb  mov [r15+0x100], rax
00007f828abe1ce2  jmp 0x00007F828A9FE110
00007f828abe1ce7  cmp dword ptr [r15+0x318], 0x00
00007f828abe1cef  jz 0x00007F828ABE1E20
00007f828abe1cf5  nop [rax+rax*1], ax
00007f828abe1cfe  nop [rax+rax*1], eax
00007f828abe1d06  mov eax, 0x410474
00007f828abe1d0b  mov [r15+0x100], rax
00007f828abe1d12  jmp 0x00007F828A9FE110
00007f828abe1d17  int3
00007f828abe1d18  call 0x00007F828AAE27E0
00007f828abe1d1d  jmp 0x00007F828ABE1AC3
00007f828abe1d22  call 0x00007F828AAE27E0
00007f828abe1d27  jmp 0x00007F828ABE1AD6
00007f828abe1d2c  call 0x00007F828AAE1570
00007f828abe1d31  jmp 0x00007F828ABE1AE2
00007f828abe1d36  call 0x00007F828AAE27E0
00007f828abe1d3b  jmp 0x00007F828ABE1B1A
00007f828abe1d40  call 0x00007F828AAE1570
00007f828abe1d45  jmp 0x00007F828ABE1B26
00007f828abe1d4a  call 0x00007F828AAE27E0
00007f828abe1d4f  jmp 0x00007F828ABE1B5E
00007f828abe1d54  call 0x00007F828AAE1570
00007f828abe1d59  jmp 0x00007F828ABE1B6A
00007f828abe1d5e  call 0x00007F828AAE27E0
00007f828abe1d63  jmp 0x00007F828ABE1BA2
00007f828abe1d68  call 0x00007F828AAE1570
00007f828abe1d6d  jmp 0x00007F828ABE1BAE
00007f828abe1d72  call 0x00007F828AAE27E0
00007f828abe1d77  jmp 0x00007F828ABE1BED
00007f828abe1d7c  call 0x00007F828AA0E760
00007f828abe1d81  jmp 0x00007F828ABE1C0A
00007f828abe1d86  ucomisd xmm1, xmm15
00007f828abe1d8b  jp 0x00007F828ABE1D9A
00007f828abe1d8d  movaps xmm13, [0x00007F828A7FE060]
00007f828abe1d95  jmp 0x00007F828ABE1C73
00007f828abe1d9a  vxorps xmm0, xmm1, xmm15
00007f828abe1d9f  pextrw eax, xmm0, 0x03
00007f828abe1da4  and eax, 0x7FF8
00007f828abe1da9  cmp eax, 0x08
00007f828abe1dac  jnz 0x00007F828ABE1C73
00007f828abe1db2  movq rax, xmm15
00007f828abe1db7  shl rax, 0x0D
00007f828abe1dbb  jbe 0x00007F828ABE1C73
00007f828abe1dc1  vorps xmm13, xmm15, [0x00007F828A7FE070]
00007f828abe1dc9  jmp 0x00007F828ABE1C73
00007f828abe1dce  ucomisd xmm1, xmm15
00007f828abe1dd3  jp 0x00007F828ABE1DE2
00007f828abe1dd5  movaps xmm14, [0x00007F828A7FE060]
00007f828abe1ddd  jmp 0x00007F828ABE1CA0
00007f828abe1de2  vxorps xmm0, xmm1, xmm15
00007f828abe1de7  pextrw eax, xmm0, 0x03
00007f828abe1dec  and eax, 0x7FF8
00007f828abe1df1  cmp eax, 0x08
00007f828abe1df4  jnz 0x00007F828ABE1CA0
00007f828abe1dfa  movq rax, xmm15
00007f828abe1dff  shl rax, 0x0D
00007f828abe1e03  jbe 0x00007F828ABE1CA0
00007f828abe1e09  vorps xmm14, xmm15, [0x00007F828A7FE070]
00007f828abe1e11  jmp 0x00007F828ABE1CA0
00007f828abe1e16  int3
00007f828abe1e17  nop [rax+rax*1], ax
00007f828abe1e20  mov rax, [r15+0x48]
00007f828abe1e24  mov r14, [r15+0x50]
00007f828abe1e28  lea r12, [r14+rax*1]
00007f828abe1e2c  movups xmm1, [r13+r12*1]
00007f828abe1e32  movaps [r15+0x120], xmm1
00007f828abe1e3a  lea r14, [rax+0x10]
00007f828abe1e3e  mov [r15+0x48], r14
00007f828abe1e42  xor eax, eax
00007f828abe1e44  mov r12d, 0x200
00007f828abe1e4a  cmp r14, r12
00007f828abe1e4d  cmc
00007f828abe1e4e  lahf
00007f828abe1e4f  seto al
00007f828abe1e52  mov [r15+0x108], eax
00007f828abe1e59  pextrq rax, xmm1, 0x01
00007f828abe1e60  movq xmm15, rax
00007f828abe1e65  movaps [r15+0x130], xmm15
00007f828abe1e6d  movaps xmm14, [r15+0x110]
00007f828abe1e75  movq rax, xmm14
00007f828abe1e7a  movq r14, xmm1
00007f828abe1e7f  vmovq xmm1, rax
00007f828abe1e84  vmovq xmm14, r14
00007f828abe1e89  movaps xmm13, xmm1
00007f828abe1e8d  addsd xmm13, xmm14
00007f828abe1e92  ucomisd xmm13, xmm13
00007f828abe1e97  jp 0x00007F828ABE1F4C
00007f828abe1e9d  movq xmm13, xmm13
00007f828abe1ea2  movq rax, xmm13
00007f828abe1ea7  movq r14, xmm15
00007f828abe1eac  vmovq xmm1, rax
00007f828abe1eb1  vmovq xmm15, r14
00007f828abe1eb6  movaps xmm14, xmm1
00007f828abe1eba  addsd xmm14, xmm15
00007f828abe1ebf  ucomisd xmm14, xmm14
00007f828abe1ec4  jp 0x00007F828ABE1F94
00007f828abe1eca  movq xmm14, xmm14
00007f828abe1ecf  movaps [r15+0x110], xmm14
00007f828abe1ed7  mov eax, [r15+0x108]
00007f828abe1ede  sahf
00007f828abe1edf  jnz 0x00007F828ABE1F11
00007f828abe1ee1  cmp dword ptr [r15+0x318], 0x00
00007f828abe1ee9  jz 0x00007F828ABE1FE0
00007f828abe1eef  nop [rax+rax*1], ax
00007f828abe1ef8  nop [rax+rax*1], eax
00007f828abe1f00  mov eax, 0x410490
00007f828abe1f05  mov [r15+0x100], rax
00007f828abe1f0c  jmp 0x00007F828A9FE110
00007f828abe1f11  cmp dword ptr [r15+0x318], 0x00
00007f828abe1f19  jz 0x00007F828ABE1E20
00007f828abe1f1f  nop [rax+rax*1], ax
00007f828abe1f28  nop [rax+rax*1], eax
00007f828abe1f30  mov eax, 0x410474
00007f828abe1f35  mov [r15+0x100], rax
00007f828abe1f3c  jmp 0x00007F828A9FE110
00007f828abe1f41  int3
00007f828abe1f42  call 0x00007F828AAB52F0
00007f828abe1f47  jmp 0x00007F828ABE1E32
00007f828abe1f4c  ucomisd xmm1, xmm14
00007f828abe1f51  jp 0x00007F828ABE1F60
00007f828abe1f53  movaps xmm13, [0x00007F828A7FE060]
00007f828abe1f5b  jmp 0x00007F828ABE1E9D
00007f828abe1f60  vxorps xmm0, xmm1, xmm14
00007f828abe1f65  pextrw eax, xmm0, 0x03
00007f828abe1f6a  and eax, 0x7FF8
00007f828abe1f6f  cmp eax, 0x08
00007f828abe1f72  jnz 0x00007F828ABE1E9D
00007f828abe1f78  movq rax, xmm14
00007f828abe1f7d  shl rax, 0x0D
00007f828abe1f81  jbe 0x00007F828ABE1E9D
00007f828abe1f87  vorps xmm13, xmm14, [0x00007F828A7FE070]
00007f828abe1f8f  jmp 0x00007F828ABE1E9D
00007f828abe1f94  ucomisd xmm1, xmm15
00007f828abe1f99  jp 0x00007F828ABE1FA8
00007f828abe1f9b  movaps xmm14, [0x00007F828A7FE060]
00007f828abe1fa3  jmp 0x00007F828ABE1ECA
00007f828abe1fa8  vxorps xmm0, xmm1, xmm15
00007f828abe1fad  pextrw eax, xmm0, 0x03
00007f828abe1fb2  and eax, 0x7FF8
00007f828abe1fb7  cmp eax, 0x08
00007f828abe1fba  jnz 0x00007F828ABE1ECA
00007f828abe1fc0  movq rax, xmm15
00007f828abe1fc5  shl rax, 0x0D
00007f828abe1fc9  jbe 0x00007F828ABE1ECA
00007f828abe1fcf  vorps xmm14, xmm15, [0x00007F828A7FE070]
00007f828abe1fd7  jmp 0x00007F828ABE1ECA
00007f828abe1fdc  int3
00007f828abe1fdd  nop [rax], eax
00007f828abe1fe0  mov rax, [r15+0x40]
00007f828abe1fe4  lea r14, [rax+0x510]
00007f828abe1feb  movaps xmm1, [r15+0x110]
00007f828abe1ff3  movq rax, xmm1
00007f828abe1ff8  mov [r13+r14*1], rax
00007f828abe1ffd  mov rax, [r15+0xF0]
00007f828abe2004  mov [r15+0x100], rax
00007f828abe200b  jmp 0x00007F828ABCE5C0
00007f828abe2010  int3
00007f828abe2011  call 0x00007F828AAD5EB0
00007f828abe2016  jmp 0x00007F828ABE1FFD
00007f828abe201b  int3
00007f828abe201c  nop [rax], eax
00007f828abe2020  mov qword ptr [r15+0x100], 0x04
00007f828abe202b  mov esi, 0x00
00007f828abe2030  mov edx, 0x09
00007f828abe2035  mov rdi, 0x7FFDFEE832A0
00007f828abe203f  mov rax, 0x5BFE27E39970
00007f828abe2049  call rax
00007f828abe204b  cmp dword ptr [r15+0x318], 0x00
00007f828abe2053  jnz 0x00007F828A9FE110
00007f828abe2059  jmp 0x00007F828A9FE0A0
00007f828abe205e  int3
00007f828abe205f  int3
