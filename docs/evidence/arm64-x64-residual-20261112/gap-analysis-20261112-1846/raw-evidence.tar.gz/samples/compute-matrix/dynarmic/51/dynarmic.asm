0000796d027ce69b  nop [rax+rax*1], eax
0000796d027ce6a0  vmovaps xmm1, [0x0000796D023FE010]
0000796d027ce6a8  movq xmm1, xmm1
0000796d027ce6ac  movaps [r15+0x110], xmm1
0000796d027ce6b4  vmovaps xmm1, [0x0000796D023FE020]
0000796d027ce6bc  movq xmm1, xmm1
0000796d027ce6c0  movaps [r15+0x120], xmm1
0000796d027ce6c8  mov eax, 0x4204C0
0000796d027ce6cd  mov r14, [r13+rax*1]
0000796d027ce6d2  movq xmm1, r14
0000796d027ce6d7  movaps [r15+0x130], xmm1
0000796d027ce6df  vmovaps xmm1, [0x0000796D023FE030]
0000796d027ce6e7  vpbroadcastq xmm1, xmm1
0000796d027ce6ec  movaps [r15+0x140], xmm1
0000796d027ce6f4  mov qword ptr [r15+0x40], 0x02
0000796d027ce6fc  vmovaps xmm15, [0x0000796D023FE040]
0000796d027ce704  movq xmm15, xmm15
0000796d027ce709  movaps [r15+0x150], xmm15
0000796d027ce711  mov qword ptr [r15+0x58], 0x420000
0000796d027ce719  vmovaps xmm15, [0x0000796D023FE050]
0000796d027ce721  vpbroadcastq xmm15, xmm15
0000796d027ce726  movaps [r15+0x160], xmm15
0000796d027ce72e  mov rax, [r15+0x40]
0000796d027ce732  vmovq xmm14, rax
0000796d027ce737  vpbroadcastq xmm14, xmm14
0000796d027ce73c  movaps [r15+0x170], xmm14
0000796d027ce744  mov eax, 0x4204D0
0000796d027ce749  movups xmm13, [r13+rax*1]
0000796d027ce74f  mov qword ptr [r15+0x40], 0x430518
0000796d027ce757  mov qword ptr [r15+0x50], 0x430720
0000796d027ce75f  vpmovqd xmm12, xmm13
0000796d027ce765  pxor xmm11, xmm11
0000796d027ce76a  punpcklqdq xmm12, xmm11
0000796d027ce76f  movaps [r15+0x210], xmm12
0000796d027ce777  movq xmm12, qword ptr [r15+0x120]
0000796d027ce780  movq xmm11, qword ptr [r15+0x130]
0000796d027ce789  psubd xmm12, xmm11
0000796d027ce78e  movq xmm12, xmm12
0000796d027ce793  paddq xmm13, xmm14
0000796d027ce798  movaps [r15+0x180], xmm13
0000796d027ce7a0  movq xmm14, qword ptr [r15+0x150]
0000796d027ce7a9  paddd xmm11, xmm14
0000796d027ce7ae  movq xmm11, xmm11
0000796d027ce7b3  movq xmm11, xmm11
0000796d027ce7b8  movaps [r15+0x130], xmm11
0000796d027ce7c0  pmovzxdq xmm12, xmm12
0000796d027ce7c6  psllq xmm12, 0x00
0000796d027ce7cc  movq xmm14, qword ptr [r15+0x210]
0000796d027ce7d5  movq xmm13, qword ptr [r15+0x110]
0000796d027ce7de  paddd xmm14, xmm13
0000796d027ce7e3  movq xmm14, xmm14
0000796d027ce7e8  vcvtuqq2pd xmm12, xmm12
0000796d027ce7ee  pmovzxdq xmm14, xmm14
0000796d027ce7f4  psllq xmm14, 0x00
0000796d027ce7fa  vcvtuqq2pd xmm14, xmm14
0000796d027ce800  movaps xmm13, xmm12
0000796d027ce804  mulpd xmm13, xmm1
0000796d027ce809  vcmppd xmm11, xmm13, xmm13, 0x03
0000796d027ce80f  ptest xmm11, xmm11
0000796d027ce815  jnz 0x0000796D027CE8FF
0000796d027ce81b  movaps [r15+0x220], xmm13
0000796d027ce823  mov eax, 0x430720
0000796d027ce828  movups [r13+rax*1], xmm13
0000796d027ce82e  movaps xmm1, xmm14
0000796d027ce832  mulpd xmm1, xmm15
0000796d027ce837  vcmppd xmm13, xmm1, xmm1, 0x03
0000796d027ce83c  ptest xmm13, xmm13
0000796d027ce842  jnz 0x0000796D027CEA4C
0000796d027ce848  movaps [r15+0x210], xmm1
0000796d027ce850  mov eax, 0x430518
0000796d027ce855  movups [r13+rax*1], xmm1
0000796d027ce85b  mov qword ptr [r15+0x48], 0x10
0000796d027ce863  xor eax, eax
0000796d027ce865  mov r14d, 0x10
0000796d027ce86b  mov r12d, 0x200
0000796d027ce871  cmp r14, r12
0000796d027ce874  cmc
0000796d027ce875  lahf
0000796d027ce876  seto al
0000796d027ce879  mov [r15+0x108], eax
0000796d027ce880  mov eax, [r15+0x108]
0000796d027ce887  sahf
0000796d027ce888  jnz 0x0000796D027CE8BA
0000796d027ce88a  cmp dword ptr [r15+0x318], 0x00
0000796d027ce892  jz 0x0000796D027CEFF0
0000796d027ce898  nop [rax+rax*1], ax
0000796d027ce8a1  nop [rax+rax*1], eax
0000796d027ce8a9  mov eax, 0x4101EC
0000796d027ce8ae  mov [r15+0x100], rax
0000796d027ce8b5  jmp 0x0000796D025FE110
0000796d027ce8ba  cmp dword ptr [r15+0x318], 0x00
0000796d027ce8c2  jz 0x0000796D027CEBA0
0000796d027ce8c8  nop [rax+rax*1], ax
0000796d027ce8d1  nop [rax+rax*1], eax
0000796d027ce8d9  mov eax, 0x4101AC
0000796d027ce8de  mov [r15+0x100], rax
0000796d027ce8e5  jmp 0x0000796D025FE110
0000796d027ce8ea  int3
0000796d027ce8eb  call 0x0000796D0260DC20
0000796d027ce8f0  jmp 0x0000796D027CE6D2
0000796d027ce8f5  call 0x0000796D0260C260
0000796d027ce8fa  jmp 0x0000796D027CE74F
0000796d027ce8ff  sub rsp, 0x08
0000796d027ce903  push rax
0000796d027ce904  push rcx
0000796d027ce905  push rdx
0000796d027ce906  push rdi
0000796d027ce907  push rsi
0000796d027ce908  push r8
0000796d027ce90a  push r9
0000796d027ce90c  push r10
0000796d027ce90e  push r11
0000796d027ce910  sub rsp, 0xF0
0000796d027ce917  vmovaps [rsp], xmm0
0000796d027ce91c  vmovaps [rsp+0x10], xmm1
0000796d027ce922  vmovaps [rsp+0x20], xmm2
0000796d027ce928  vmovaps [rsp+0x30], xmm3
0000796d027ce92e  vmovaps [rsp+0x40], xmm4
0000796d027ce934  vmovaps [rsp+0x50], xmm5
0000796d027ce93a  vmovaps [rsp+0x60], xmm6
0000796d027ce940  vmovaps [rsp+0x70], xmm7
0000796d027ce946  vmovaps [rsp+0x80], xmm8
0000796d027ce94f  vmovaps [rsp+0x90], xmm9
0000796d027ce958  vmovaps [rsp+0xA0], xmm10
0000796d027ce961  vmovaps [rsp+0xB0], xmm11
0000796d027ce96a  vmovaps [rsp+0xC0], xmm12
0000796d027ce973  vmovaps [rsp+0xD0], xmm14
0000796d027ce97c  vmovaps [rsp+0xE0], xmm15
0000796d027ce985  sub rsp, 0x30
0000796d027ce989  movaps [rsp], xmm13
0000796d027ce98e  movaps [rsp+0x10], xmm12
0000796d027ce994  movaps [rsp+0x20], xmm1
0000796d027ce999  lea rdi, [rsp]
0000796d027ce99d  mov esi, 0x00
0000796d027ce9a2  mov rax, 0x635FBE957530
0000796d027ce9ac  call rax
0000796d027ce9ae  movaps xmm13, [rsp]
0000796d027ce9b3  add rsp, 0x30
0000796d027ce9b7  vmovaps xmm0, [rsp]
0000796d027ce9bc  vmovaps xmm1, [rsp+0x10]
0000796d027ce9c2  vmovaps xmm2, [rsp+0x20]
0000796d027ce9c8  vmovaps xmm3, [rsp+0x30]
0000796d027ce9ce  vmovaps xmm4, [rsp+0x40]
0000796d027ce9d4  vmovaps xmm5, [rsp+0x50]
0000796d027ce9da  vmovaps xmm6, [rsp+0x60]
0000796d027ce9e0  vmovaps xmm7, [rsp+0x70]
0000796d027ce9e6  vmovaps xmm8, [rsp+0x80]
0000796d027ce9ef  vmovaps xmm9, [rsp+0x90]
0000796d027ce9f8  vmovaps xmm10, [rsp+0xA0]
0000796d027cea01  vmovaps xmm11, [rsp+0xB0]
0000796d027cea0a  vmovaps xmm12, [rsp+0xC0]
0000796d027cea13  vmovaps xmm14, [rsp+0xD0]
0000796d027cea1c  vmovaps xmm15, [rsp+0xE0]
0000796d027cea25  add rsp, 0xF0
0000796d027cea2c  pop r11
0000796d027cea2e  pop r10
0000796d027cea30  pop r9
0000796d027cea32  pop r8
0000796d027cea34  pop rsi
0000796d027cea35  pop rdi
0000796d027cea36  pop rdx
0000796d027cea37  pop rcx
0000796d027cea38  pop rax
0000796d027cea39  add rsp, 0x08
0000796d027cea3d  jmp 0x0000796D027CE81B
0000796d027cea42  call 0x0000796D0260C380
0000796d027cea47  jmp 0x0000796D027CE82E
0000796d027cea4c  sub rsp, 0x08
0000796d027cea50  push rax
0000796d027cea51  push rcx
0000796d027cea52  push rdx
0000796d027cea53  push rdi
0000796d027cea54  push rsi
0000796d027cea55  push r8
0000796d027cea57  push r9
0000796d027cea59  push r10
0000796d027cea5b  push r11
0000796d027cea5d  sub rsp, 0xF0
0000796d027cea64  vmovaps [rsp], xmm0
0000796d027cea69  vmovaps [rsp+0x10], xmm2
0000796d027cea6f  vmovaps [rsp+0x20], xmm3
0000796d027cea75  vmovaps [rsp+0x30], xmm4
0000796d027cea7b  vmovaps [rsp+0x40], xmm5
0000796d027cea81  vmovaps [rsp+0x50], xmm6
0000796d027cea87  vmovaps [rsp+0x60], xmm7
0000796d027cea8d  vmovaps [rsp+0x70], xmm8
0000796d027cea93  vmovaps [rsp+0x80], xmm9
0000796d027cea9c  vmovaps [rsp+0x90], xmm10
0000796d027ceaa5  vmovaps [rsp+0xA0], xmm11
0000796d027ceaae  vmovaps [rsp+0xB0], xmm12
0000796d027ceab7  vmovaps [rsp+0xC0], xmm13
0000796d027ceac0  vmovaps [rsp+0xD0], xmm14
0000796d027ceac9  vmovaps [rsp+0xE0], xmm15
0000796d027cead2  sub rsp, 0x30
0000796d027cead6  movaps [rsp], xmm1
0000796d027ceada  movaps [rsp+0x10], xmm14
0000796d027ceae0  movaps [rsp+0x20], xmm15
0000796d027ceae6  lea rdi, [rsp]
0000796d027ceaea  mov esi, 0x00
0000796d027ceaef  mov rax, 0x635FBE957530
0000796d027ceaf9  call rax
0000796d027ceafb  movaps xmm1, [rsp]
0000796d027ceaff  add rsp, 0x30
0000796d027ceb03  vmovaps xmm0, [rsp]
0000796d027ceb08  vmovaps xmm2, [rsp+0x10]
0000796d027ceb0e  vmovaps xmm3, [rsp+0x20]
0000796d027ceb14  vmovaps xmm4, [rsp+0x30]
0000796d027ceb1a  vmovaps xmm5, [rsp+0x40]
0000796d027ceb20  vmovaps xmm6, [rsp+0x50]
0000796d027ceb26  vmovaps xmm7, [rsp+0x60]
0000796d027ceb2c  vmovaps xmm8, [rsp+0x70]
0000796d027ceb32  vmovaps xmm9, [rsp+0x80]
0000796d027ceb3b  vmovaps xmm10, [rsp+0x90]
0000796d027ceb44  vmovaps xmm11, [rsp+0xA0]
0000796d027ceb4d  vmovaps xmm12, [rsp+0xB0]
0000796d027ceb56  vmovaps xmm13, [rsp+0xC0]
0000796d027ceb5f  vmovaps xmm14, [rsp+0xD0]
0000796d027ceb68  vmovaps xmm15, [rsp+0xE0]
0000796d027ceb71  add rsp, 0xF0
0000796d027ceb78  pop r11
0000796d027ceb7a  pop r10
0000796d027ceb7c  pop r9
0000796d027ceb7e  pop r8
0000796d027ceb80  pop rsi
0000796d027ceb81  pop rdi
0000796d027ceb82  pop rdx
0000796d027ceb83  pop rcx
0000796d027ceb84  pop rax
0000796d027ceb85  add rsp, 0x08
0000796d027ceb89  jmp 0x0000796D027CE848
0000796d027ceb8e  call 0x0000796D025FF540
0000796d027ceb93  jmp 0x0000796D027CE85B
0000796d027ceb98  int3
0000796d027ceb99  nop [rax], eax
0000796d027ceba0  movaps xmm1, [r15+0x180]
0000796d027ceba8  vpmovqd xmm15, xmm1
0000796d027cebae  pxor xmm14, xmm14
0000796d027cebb3  punpcklqdq xmm15, xmm14
0000796d027cebb8  movaps [r15+0x210], xmm15
0000796d027cebc0  movq xmm15, qword ptr [r15+0x120]
0000796d027cebc9  movq xmm14, qword ptr [r15+0x130]
0000796d027cebd2  psubd xmm15, xmm14
0000796d027cebd7  movq xmm15, xmm15
0000796d027cebdc  movaps xmm13, [r15+0x170]
0000796d027cebe4  paddq xmm1, xmm13
0000796d027cebe9  movaps [r15+0x180], xmm1
0000796d027cebf1  movq xmm1, qword ptr [r15+0x150]
0000796d027cebfa  paddd xmm14, xmm1
0000796d027cebff  movq xmm14, xmm14
0000796d027cec04  movq xmm14, xmm14
0000796d027cec09  movaps [r15+0x130], xmm14
0000796d027cec11  pmovzxdq xmm15, xmm15
0000796d027cec17  psllq xmm15, 0x00
0000796d027cec1d  movq xmm1, qword ptr [r15+0x210]
0000796d027cec26  movq xmm14, qword ptr [r15+0x110]
0000796d027cec2f  paddd xmm1, xmm14
0000796d027cec34  movq xmm1, xmm1
0000796d027cec38  vcvtuqq2pd xmm15, xmm15
0000796d027cec3e  pmovzxdq xmm1, xmm1
0000796d027cec43  psllq xmm1, 0x00
0000796d027cec48  vcvtuqq2pd xmm1, xmm1
0000796d027cec4e  movaps xmm14, [r15+0x140]
0000796d027cec56  movaps xmm13, xmm15
0000796d027cec5a  mulpd xmm13, xmm14
0000796d027cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
0000796d027cec65  ptest xmm12, xmm12
0000796d027cec6b  jnz 0x0000796D027CED4E
0000796d027cec71  movaps [r15+0x220], xmm13
0000796d027cec79  mov rax, [r15+0x48]
0000796d027cec7d  mov r14, [r15+0x50]
0000796d027cec81  lea r12, [r14+rax*1]
0000796d027cec85  movups [r13+r12*1], xmm13
0000796d027cec8b  movaps xmm15, [r15+0x160]
0000796d027cec93  movaps xmm14, xmm1
0000796d027cec97  mulpd xmm14, xmm15
0000796d027cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
0000796d027ceca2  ptest xmm13, xmm13
0000796d027ceca8  jnz 0x0000796D027CEE9C
0000796d027cecae  movaps [r15+0x210], xmm14
0000796d027cecb6  mov r14, [r15+0x40]
0000796d027cecba  lea r12, [r14+rax*1]
0000796d027cecbe  movups [r13+r12*1], xmm14
0000796d027cecc4  lea r14, [rax+0x10]
0000796d027cecc8  mov [r15+0x48], r14
0000796d027ceccc  xor eax, eax
0000796d027cecce  mov r12d, 0x200
0000796d027cecd4  cmp r14, r12
0000796d027cecd7  cmc
0000796d027cecd8  lahf
0000796d027cecd9  seto al
0000796d027cecdc  mov [r15+0x108], eax
0000796d027cece3  mov eax, [r15+0x108]
0000796d027cecea  sahf
0000796d027ceceb  jnz 0x0000796D027CED1D
0000796d027ceced  cmp dword ptr [r15+0x318], 0x00
0000796d027cecf5  jz 0x0000796D027CEFF0
0000796d027cecfb  nop [rax+rax*1], ax
0000796d027ced04  nop [rax+rax*1], eax
0000796d027ced0c  mov eax, 0x4101EC
0000796d027ced11  mov [r15+0x100], rax
0000796d027ced18  jmp 0x0000796D025FE110
0000796d027ced1d  cmp dword ptr [r15+0x318], 0x00
0000796d027ced25  jz 0x0000796D027CEBA0
0000796d027ced2b  nop [rax+rax*1], ax
0000796d027ced34  nop [rax+rax*1], eax
0000796d027ced3c  mov eax, 0x4101AC
0000796d027ced41  mov [r15+0x100], rax
0000796d027ced48  jmp 0x0000796D025FE110
0000796d027ced4d  int3
0000796d027ced4e  sub rsp, 0x08
0000796d027ced52  push rax
0000796d027ced53  push rcx
0000796d027ced54  push rdx
0000796d027ced55  push rdi
0000796d027ced56  push rsi
0000796d027ced57  push r8
0000796d027ced59  push r9
0000796d027ced5b  push r10
0000796d027ced5d  push r11
0000796d027ced5f  sub rsp, 0xF0
0000796d027ced66  vmovaps [rsp], xmm0
0000796d027ced6b  vmovaps [rsp+0x10], xmm1
0000796d027ced71  vmovaps [rsp+0x20], xmm2
0000796d027ced77  vmovaps [rsp+0x30], xmm3
0000796d027ced7d  vmovaps [rsp+0x40], xmm4
0000796d027ced83  vmovaps [rsp+0x50], xmm5
0000796d027ced89  vmovaps [rsp+0x60], xmm6
0000796d027ced8f  vmovaps [rsp+0x70], xmm7
0000796d027ced95  vmovaps [rsp+0x80], xmm8
0000796d027ced9e  vmovaps [rsp+0x90], xmm9
0000796d027ceda7  vmovaps [rsp+0xA0], xmm10
0000796d027cedb0  vmovaps [rsp+0xB0], xmm11
0000796d027cedb9  vmovaps [rsp+0xC0], xmm12
0000796d027cedc2  vmovaps [rsp+0xD0], xmm14
0000796d027cedcb  vmovaps [rsp+0xE0], xmm15
0000796d027cedd4  sub rsp, 0x30
0000796d027cedd8  movaps [rsp], xmm13
0000796d027ceddd  movaps [rsp+0x10], xmm15
0000796d027cede3  movaps [rsp+0x20], xmm14
0000796d027cede9  lea rdi, [rsp]
0000796d027ceded  mov esi, 0x00
0000796d027cedf2  mov rax, 0x635FBE957530
0000796d027cedfc  call rax
0000796d027cedfe  movaps xmm13, [rsp]
0000796d027cee03  add rsp, 0x30
0000796d027cee07  vmovaps xmm0, [rsp]
0000796d027cee0c  vmovaps xmm1, [rsp+0x10]
0000796d027cee12  vmovaps xmm2, [rsp+0x20]
0000796d027cee18  vmovaps xmm3, [rsp+0x30]
0000796d027cee1e  vmovaps xmm4, [rsp+0x40]
0000796d027cee24  vmovaps xmm5, [rsp+0x50]
0000796d027cee2a  vmovaps xmm6, [rsp+0x60]
0000796d027cee30  vmovaps xmm7, [rsp+0x70]
0000796d027cee36  vmovaps xmm8, [rsp+0x80]
0000796d027cee3f  vmovaps xmm9, [rsp+0x90]
0000796d027cee48  vmovaps xmm10, [rsp+0xA0]
0000796d027cee51  vmovaps xmm11, [rsp+0xB0]
0000796d027cee5a  vmovaps xmm12, [rsp+0xC0]
0000796d027cee63  vmovaps xmm14, [rsp+0xD0]
0000796d027cee6c  vmovaps xmm15, [rsp+0xE0]
0000796d027cee75  add rsp, 0xF0
0000796d027cee7c  pop r11
0000796d027cee7e  pop r10
0000796d027cee80  pop r9
0000796d027cee82  pop r8
0000796d027cee84  pop rsi
0000796d027cee85  pop rdi
0000796d027cee86  pop rdx
0000796d027cee87  pop rcx
0000796d027cee88  pop rax
0000796d027cee89  add rsp, 0x08
0000796d027cee8d  jmp 0x0000796D027CEC71
0000796d027cee92  call 0x0000796D026C2240
0000796d027cee97  jmp 0x0000796D027CEC8B
0000796d027cee9c  sub rsp, 0x08
0000796d027ceea0  push rax
0000796d027ceea1  push rcx
0000796d027ceea2  push rdx
0000796d027ceea3  push rdi
0000796d027ceea4  push rsi
0000796d027ceea5  push r8
0000796d027ceea7  push r9
0000796d027ceea9  push r10
0000796d027ceeab  push r11
0000796d027ceead  sub rsp, 0xF0
0000796d027ceeb4  vmovaps [rsp], xmm0
0000796d027ceeb9  vmovaps [rsp+0x10], xmm1
0000796d027ceebf  vmovaps [rsp+0x20], xmm2
0000796d027ceec5  vmovaps [rsp+0x30], xmm3
0000796d027ceecb  vmovaps [rsp+0x40], xmm4
0000796d027ceed1  vmovaps [rsp+0x50], xmm5
0000796d027ceed7  vmovaps [rsp+0x60], xmm6
0000796d027ceedd  vmovaps [rsp+0x70], xmm7
0000796d027ceee3  vmovaps [rsp+0x80], xmm8
0000796d027ceeec  vmovaps [rsp+0x90], xmm9
0000796d027ceef5  vmovaps [rsp+0xA0], xmm10
0000796d027ceefe  vmovaps [rsp+0xB0], xmm11
0000796d027cef07  vmovaps [rsp+0xC0], xmm12
0000796d027cef10  vmovaps [rsp+0xD0], xmm13
0000796d027cef19  vmovaps [rsp+0xE0], xmm15
0000796d027cef22  sub rsp, 0x30
0000796d027cef26  movaps [rsp], xmm14
0000796d027cef2b  movaps [rsp+0x10], xmm1
0000796d027cef30  movaps [rsp+0x20], xmm15
0000796d027cef36  lea rdi, [rsp]
0000796d027cef3a  mov esi, 0x00
0000796d027cef3f  mov rax, 0x635FBE957530
0000796d027cef49  call rax
0000796d027cef4b  movaps xmm14, [rsp]
0000796d027cef50  add rsp, 0x30
0000796d027cef54  vmovaps xmm0, [rsp]
0000796d027cef59  vmovaps xmm1, [rsp+0x10]
0000796d027cef5f  vmovaps xmm2, [rsp+0x20]
0000796d027cef65  vmovaps xmm3, [rsp+0x30]
0000796d027cef6b  vmovaps xmm4, [rsp+0x40]
0000796d027cef71  vmovaps xmm5, [rsp+0x50]
0000796d027cef77  vmovaps xmm6, [rsp+0x60]
0000796d027cef7d  vmovaps xmm7, [rsp+0x70]
0000796d027cef83  vmovaps xmm8, [rsp+0x80]
0000796d027cef8c  vmovaps xmm9, [rsp+0x90]
0000796d027cef95  vmovaps xmm10, [rsp+0xA0]
0000796d027cef9e  vmovaps xmm11, [rsp+0xB0]
0000796d027cefa7  vmovaps xmm12, [rsp+0xC0]
0000796d027cefb0  vmovaps xmm13, [rsp+0xD0]
0000796d027cefb9  vmovaps xmm15, [rsp+0xE0]
0000796d027cefc2  add rsp, 0xF0
0000796d027cefc9  pop r11
0000796d027cefcb  pop r10
0000796d027cefcd  pop r9
0000796d027cefcf  pop r8
0000796d027cefd1  pop rsi
0000796d027cefd2  pop rdi
0000796d027cefd3  pop rdx
0000796d027cefd4  pop rcx
0000796d027cefd5  pop rax
0000796d027cefd6  add rsp, 0x08
0000796d027cefda  jmp 0x0000796D027CECAE
0000796d027cefdf  call 0x0000796D026C34C0
0000796d027cefe4  jmp 0x0000796D027CECC4
0000796d027cefe9  int3
0000796d027cefea  nop [rax+rax*1], ax
0000796d027ceff0  mov rax, [r15+0xF8]
0000796d027ceff7  lea r14, [rax-0x150]
0000796d027ceffe  mov [r15+0xF8], r14
0000796d027cf005  mov rax, [r15+0x50]
0000796d027cf009  lea r12, [rax+0x80]
0000796d027cf010  movups xmm1, [r13+r12*1]
0000796d027cf016  lea r12, [rax+0x90]
0000796d027cf01d  movups xmm15, [r13+r12*1]
0000796d027cf023  mov qword ptr [r15+0x48], 0x00
0000796d027cf02b  lea r12, [rax+0x40]
0000796d027cf02f  movups xmm14, [r13+r12*1]
0000796d027cf035  lea r12, [rax+0x50]
0000796d027cf039  movups xmm13, [r13+r12*1]
0000796d027cf03f  lea r12, [r14+0x120]
0000796d027cf046  movq xmm12, qword ptr [r15+0x1C0]
0000796d027cf04f  movq xmm11, qword ptr [r15+0x1B0]
0000796d027cf058  movq r11, xmm12
0000796d027cf05d  movq r10, xmm11
0000796d027cf062  mov [r13+r12*1], r11
0000796d027cf067  lea r12, [r14+0x128]
0000796d027cf06e  mov [r13+r12*1], r10
0000796d027cf073  vxorps xmm12, xmm12, xmm12
0000796d027cf078  vpbroadcastq xmm12, xmm12
0000796d027cf07d  lea r12, [r14+0x100]
0000796d027cf084  movq xmm11, qword ptr [r15+0x200]
0000796d027cf08d  movq xmm10, qword ptr [r15+0x1F0]
0000796d027cf096  movq r11, xmm11
0000796d027cf09b  movq r10, xmm10
0000796d027cf0a0  mov [r13+r12*1], r11
0000796d027cf0a5  lea r12, [r14+0x108]
0000796d027cf0ac  mov [r13+r12*1], r10
0000796d027cf0b1  lea r12, [r14+0xE0]
0000796d027cf0b8  movups [r13+r12*1], xmm15
0000796d027cf0be  lea r12, [r14+0xF0]
0000796d027cf0c5  movups [r13+r12*1], xmm1
0000796d027cf0cb  lea r12, [rax+0xC0]
0000796d027cf0d2  movups xmm1, [r13+r12*1]
0000796d027cf0d8  lea r12, [rax+0xD0]
0000796d027cf0df  movups xmm15, [r13+r12*1]
0000796d027cf0e5  lea r12, [r14+0x110]
0000796d027cf0ec  movq xmm11, qword ptr [r15+0x1E0]
0000796d027cf0f5  movq xmm10, qword ptr [r15+0x1D0]
0000796d027cf0fe  movq r11, xmm11
0000796d027cf103  movq r10, xmm10
0000796d027cf108  mov [r13+r12*1], r11
0000796d027cf10d  lea r12, [r14+0x118]
0000796d027cf114  mov [r13+r12*1], r10
0000796d027cf119  movups xmm11, [r13+rax*1]
0000796d027cf11f  lea r12, [rax+0x10]
0000796d027cf123  movups xmm10, [r13+r12*1]
0000796d027cf129  lea r12, [r14+0x130]
0000796d027cf130  movq xmm9, qword ptr [r15+0x1A0]
0000796d027cf139  movq xmm8, qword ptr [r15+0x190]
0000796d027cf142  movq r11, xmm9
0000796d027cf147  movq r10, xmm8
0000796d027cf14c  mov [r13+r12*1], r11
0000796d027cf151  lea r12, [r14+0x138]
0000796d027cf158  mov [r13+r12*1], r10
0000796d027cf15d  lea r12, [rax+0x140]
0000796d027cf164  movups xmm9, [r13+r12*1]
0000796d027cf16a  lea r12, [rax+0x150]
0000796d027cf171  movups xmm8, [r13+r12*1]
0000796d027cf177  lea r12, [r14+0xC0]
0000796d027cf17e  movups [r13+r12*1], xmm15
0000796d027cf184  lea r12, [r14+0xD0]
0000796d027cf18b  movups [r13+r12*1], xmm1
0000796d027cf191  lea r12, [rax+0x100]
0000796d027cf198  movups xmm1, [r13+r12*1]
0000796d027cf19e  lea r12, [rax+0x110]
0000796d027cf1a5  movups xmm15, [r13+r12*1]
0000796d027cf1ab  lea r12, [r14+0x140]
0000796d027cf1b2  mov r11, [r15+0xE8]
0000796d027cf1b9  mov [r13+r12*1], r11
0000796d027cf1be  lea r12, [rax+0x180]
0000796d027cf1c5  movups xmm7, [r13+r12*1]
0000796d027cf1cb  lea r12, [rax+0x190]
0000796d027cf1d2  movups xmm6, [r13+r12*1]
0000796d027cf1d8  lea r12, [rax+0x1C0]
0000796d027cf1df  movups xmm5, [r13+r12*1]
0000796d027cf1e5  lea r12, [rax+0x1D0]
0000796d027cf1ec  movups xmm4, [r13+r12*1]
0000796d027cf1f2  lea r12, [r14+0x20]
0000796d027cf1f6  movups [r13+r12*1], xmm1
0000796d027cf1fc  lea r12, [r14+0x30]
0000796d027cf200  movups [r13+r12*1], xmm13
0000796d027cf206  lea r12, [rax+0x60]
0000796d027cf20a  movups xmm1, [r13+r12*1]
0000796d027cf210  lea r12, [rax+0x70]
0000796d027cf214  movups xmm13, [r13+r12*1]
0000796d027cf21a  lea r12, [rax+0x20]
0000796d027cf21e  movups xmm3, [r13+r12*1]
0000796d027cf224  lea r12, [rax+0x30]
0000796d027cf228  movups xmm2, [r13+r12*1]
0000796d027cf22e  movaps [r15+0x1F0], xmm2
0000796d027cf236  lea r12, [r14+0x60]
0000796d027cf23a  movups [r13+r12*1], xmm11
0000796d027cf240  lea r12, [r14+0x70]
0000796d027cf244  movups [r13+r12*1], xmm5
0000796d027cf24a  lea r12, [rax+0xE0]
0000796d027cf251  movups xmm11, [r13+r12*1]
0000796d027cf257  lea r12, [rax+0xF0]
0000796d027cf25e  movups xmm5, [r13+r12*1]
0000796d027cf264  lea r12, [r14+0xA0]
0000796d027cf26b  movups [r13+r12*1], xmm13
0000796d027cf271  lea r12, [r14+0xB0]
0000796d027cf278  movups [r13+r12*1], xmm1
0000796d027cf27e  lea r12, [rax+0xA0]
0000796d027cf285  movups xmm1, [r13+r12*1]
0000796d027cf28b  lea r12, [rax+0xB0]
0000796d027cf292  movups xmm13, [r13+r12*1]
0000796d027cf298  lea r12, [rax+0x120]
0000796d027cf29f  vmovaps [rsp+0x10], xmm1
0000796d027cf2a5  movups xmm1, [r13+r12*1]
0000796d027cf2ab  lea r12, [rax+0x130]
0000796d027cf2b2  vmovaps [rsp+0x20], xmm1
0000796d027cf2b8  movups xmm1, [r13+r12*1]
0000796d027cf2be  lea r12, [rax+0x160]
0000796d027cf2c5  vmovaps [rsp+0x30], xmm1
0000796d027cf2cb  movups xmm1, [r13+r12*1]
0000796d027cf2d1  lea r12, [rax+0x170]
0000796d027cf2d8  vmovaps [rsp+0x40], xmm1
0000796d027cf2de  movups xmm1, [r13+r12*1]
0000796d027cf2e4  movaps [r15+0x2B0], xmm1
0000796d027cf2ec  lea r12, [r14+0x80]
0000796d027cf2f3  movups [r13+r12*1], xmm13
0000796d027cf2f9  lea r12, [r14+0x90]
0000796d027cf300  vmovaps xmm13, [rsp+0x10]
0000796d027cf306  movups [r13+r12*1], xmm13
0000796d027cf30c  lea r12, [rax+0x1A0]
0000796d027cf313  movups xmm13, [r13+r12*1]
0000796d027cf319  lea r12, [rax+0x1B0]
0000796d027cf320  vmovaps [rsp+0x10], xmm1
0000796d027cf326  movups xmm1, [r13+r12*1]
0000796d027cf32c  movaps [r15+0x290], xmm13
0000796d027cf334  movaps [r15+0x1E0], xmm1
0000796d027cf33c  lea r12, [rax+0x1E0]
0000796d027cf343  vmovaps [rsp+0x50], xmm1
0000796d027cf349  movups xmm1, [r13+r12*1]
0000796d027cf34f  lea r12, [rax+0x1F0]
0000796d027cf356  vmovaps [rsp+0x60], xmm1
0000796d027cf35c  movups xmm1, [r13+r12*1]
0000796d027cf362  mov qword ptr [r15+0x50], 0x430920
0000796d027cf36a  lea rax, [r14+0x40]
0000796d027cf36e  vmovaps [rsp+0x70], xmm1
0000796d027cf374  vmovaps xmm1, [rsp+0x40]
0000796d027cf37a  movups [r13+rax*1], xmm1
0000796d027cf380  lea rax, [r14+0x50]
0000796d027cf384  movups [r13+rax*1], xmm10
0000796d027cf38a  vmovaps xmm1, [rsp+0x70]
0000796d027cf390  movups [r13+r14*1], xmm1
0000796d027cf396  lea rax, [r14+0x10]
0000796d027cf39a  vmovaps xmm1, [rsp+0x60]
0000796d027cf3a0  movups [r13+rax*1], xmm1
0000796d027cf3a6  mov rax, [r15+0x40]
0000796d027cf3aa  vmovaps [rsp+0x40], xmm3
0000796d027cf3b0  vmovaps xmm1, [rsp+0x40]
0000796d027cf3b6  por xmm3, xmm1
0000796d027cf3ba  vmovaps [rsp+0x40], xmm6
0000796d027cf3c0  vmovaps xmm10, [rsp+0x40]
0000796d027cf3c6  por xmm6, xmm10
0000796d027cf3cb  lea r12, [rax+0x30]
0000796d027cf3cf  mov r11, [r13+r12*1]
0000796d027cf3d4  lea r12, [rax+0x38]
0000796d027cf3d8  mov r10, [r13+r12*1]
0000796d027cf3dd  movq xmm10, r11
0000796d027cf3e2  vmovaps [rsp+0x40], xmm1
0000796d027cf3e8  movq xmm1, r10
0000796d027cf3ed  movq xmm10, xmm10
0000796d027cf3f2  vmovaps [rsp+0x60], xmm10
0000796d027cf3f8  movq xmm10, xmm10
0000796d027cf3fd  movaps [r15+0x130], xmm10
0000796d027cf405  movq xmm1, xmm1
0000796d027cf409  vmovaps [rsp+0x70], xmm1
0000796d027cf40f  movq xmm1, xmm1
0000796d027cf413  movaps [r15+0x280], xmm1
0000796d027cf41b  vmovaps [rsp+0x80], xmm9
0000796d027cf424  vmovaps xmm1, [rsp+0x80]
0000796d027cf42d  por xmm9, xmm1
0000796d027cf432  lea r12, [rax+0x20]
0000796d027cf436  mov r11, [r13+r12*1]
0000796d027cf43b  lea r12, [rax+0x28]
0000796d027cf43f  mov r10, [r13+r12*1]
0000796d027cf444  movq xmm1, r11
0000796d027cf449  movq xmm10, r10
0000796d027cf44e  movq xmm1, xmm1
0000796d027cf452  vmovaps [rsp+0x80], xmm1
0000796d027cf45b  movq xmm1, xmm1
0000796d027cf45f  movaps [r15+0x150], xmm1
0000796d027cf467  movq xmm10, xmm10
0000796d027cf46c  vmovaps [rsp+0x90], xmm10
0000796d027cf475  movq xmm10, xmm10
0000796d027cf47a  movaps [r15+0x140], xmm10
0000796d027cf482  lea r12, [rax+0x10]
0000796d027cf486  mov r11, [r13+r12*1]
0000796d027cf48b  lea r12, [rax+0x18]
0000796d027cf48f  mov r10, [r13+r12*1]
0000796d027cf494  movq xmm1, r11
0000796d027cf499  movq xmm10, r10
0000796d027cf49e  movq xmm1, xmm1
0000796d027cf4a2  vmovaps [rsp+0xA0], xmm1
0000796d027cf4ab  movq xmm1, xmm1
0000796d027cf4af  movaps [r15+0x170], xmm1
0000796d027cf4b7  movq xmm10, xmm10
0000796d027cf4bc  vmovaps [rsp+0xB0], xmm10
0000796d027cf4c5  movq xmm10, xmm10
0000796d027cf4ca  movaps [r15+0x160], xmm10
0000796d027cf4d2  mov r12, [r13+rax*1]
0000796d027cf4d7  vmovq xmm1, r12
0000796d027cf4dc  vpbroadcastq xmm1, xmm1
0000796d027cf4e1  lea r12, [rax+0x08]
0000796d027cf4e5  mov rax, [r13+r12*1]
0000796d027cf4ea  movq xmm10, rax
0000796d027cf4ef  movaps [r15+0x230], xmm10
0000796d027cf4f7  lea rax, [r14+0x50]
0000796d027cf4fb  movups xmm10, [r13+rax*1]
0000796d027cf501  lea rax, [r14+0x60]
0000796d027cf505  vmovaps [rsp+0xC0], xmm1
0000796d027cf50e  movups xmm1, [r13+rax*1]
0000796d027cf514  lea rax, [r14+0x30]
0000796d027cf518  vmovaps [rsp+0xD0], xmm1
0000796d027cf521  movups xmm1, [r13+rax*1]
0000796d027cf527  mov qword ptr [r15+0x60], 0x430920
0000796d027cf52f  mov qword ptr [r15+0x58], 0x40
0000796d027cf537  vmovaps [rsp+0xE0], xmm1
0000796d027cf540  vmovaps [rsp+0xF0], xmm15
0000796d027cf549  vmovaps xmm15, [rsp+0xC0]
0000796d027cf552  vmovaps [rsp+0xC0], xmm14
0000796d027cf55b  vmovaps xmm14, [rsp+0x40]
0000796d027cf561  vmovaps [rsp+0x40], xmm13
0000796d027cf567  movaps xmm1, xmm15
0000796d027cf56b  mulpd xmm1, xmm14
0000796d027cf570  vcmppd xmm13, xmm1, xmm1, 0x03
0000796d027cf575  ptest xmm13, xmm13
0000796d027cf57b  jnz 0x0000796D027D0682
0000796d027cf581  movq xmm14, qword ptr [r15+0x230]
0000796d027cf58a  vmovaps [rsp+0x100], xmm14
0000796d027cf593  vpermilpd xmm14, xmm14, 0x00
0000796d027cf599  vmovaps [rsp+0x110], xmm1
0000796d027cf5a2  vmovaps xmm1, [rsp+0xE0]
0000796d027cf5ab  vmovaps [rsp+0xE0], xmm15
0000796d027cf5b4  movaps xmm13, xmm1
0000796d027cf5b8  mulpd xmm13, xmm14
0000796d027cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
0000796d027cf5c3  ptest xmm15, xmm15
0000796d027cf5c9  jnz 0x0000796D027D07C4
0000796d027cf5cf  vxorps xmm1, xmm1, xmm1
0000796d027cf5d3  vpbroadcastq xmm1, xmm1
0000796d027cf5d8  vmovaps xmm14, [rsp+0xE0]
0000796d027cf5e1  vmovaps [rsp+0xE0], xmm1
0000796d027cf5ea  vmovaps xmm1, [rsp+0xD0]
0000796d027cf5f3  vmovaps [rsp+0xD0], xmm13
0000796d027cf5fc  movaps xmm15, xmm14
0000796d027cf600  mulpd xmm15, xmm1
0000796d027cf605  vcmppd xmm13, xmm15, xmm15, 0x03
0000796d027cf60b  ptest xmm13, xmm13
0000796d027cf611  jnz 0x0000796D027D0907
0000796d027cf617  movaps xmm1, xmm14
0000796d027cf61b  mulpd xmm1, xmm10
0000796d027cf620  vcmppd xmm13, xmm1, xmm1, 0x03
0000796d027cf625  ptest xmm13, xmm13
0000796d027cf62b  jnz 0x0000796D027D0A4A
0000796d027cf631  movaps xmm13, xmm14
0000796d027cf635  mulpd xmm13, xmm2
0000796d027cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
0000796d027cf640  ptest xmm10, xmm10
0000796d027cf646  jnz 0x0000796D027D0B8C
0000796d027cf64c  vmovaps [rsp+0x120], xmm7
0000796d027cf655  vmovaps xmm14, [rsp+0x120]
0000796d027cf65e  por xmm7, xmm14
0000796d027cf663  vmovaps xmm14, [rsp+0xC0]
0000796d027cf66c  vmovaps xmm10, [rsp+0xC0]
0000796d027cf675  por xmm14, xmm10
0000796d027cf67a  vmovaps xmm2, [rsp+0x100]
0000796d027cf683  vpermilpd xmm2, xmm2, 0x00
0000796d027cf689  vmovaps [rsp+0xC0], xmm1
0000796d027cf692  vmovaps [rsp+0x120], xmm15
0000796d027cf69b  movaps xmm1, xmm10
0000796d027cf69f  mulpd xmm1, xmm2
0000796d027cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
0000796d027cf6a8  ptest xmm15, xmm15
0000796d027cf6ae  jnz 0x0000796D027D0CCF
0000796d027cf6b4  xor eax, eax
0000796d027cf6b6  mov r12d, 0x40
0000796d027cf6bc  mov r11d, 0x200
0000796d027cf6c2  cmp r12, r11
0000796d027cf6c5  cmc
0000796d027cf6c6  lahf
0000796d027cf6c7  seto al
0000796d027cf6ca  mov [r15+0x108], eax
0000796d027cf6d1  vmovaps xmm10, [rsp+0x110]
0000796d027cf6da  vmovaps xmm2, [rsp+0xE0]
0000796d027cf6e3  vmovaps [rsp+0xE0], xmm1
0000796d027cf6ec  movaps xmm15, xmm10
0000796d027cf6f0  addpd xmm15, xmm2
0000796d027cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
0000796d027cf6fb  ptest xmm1, xmm1
0000796d027cf700  jnz 0x0000796D027D0E10
0000796d027cf706  vmovaps xmm10, [rsp+0x120]
0000796d027cf70f  vmovaps [rsp+0x110], xmm15
0000796d027cf718  movaps xmm1, xmm10
0000796d027cf71c  addpd xmm1, xmm12
0000796d027cf721  vcmppd xmm15, xmm1, xmm1, 0x03
0000796d027cf726  ptest xmm15, xmm15
0000796d027cf72c  jnz 0x0000796D027D0F53
0000796d027cf732  vmovaps xmm10, [rsp+0xC0]
0000796d027cf73b  vmovaps [rsp+0xC0], xmm1
0000796d027cf744  movaps xmm15, xmm10
0000796d027cf748  addpd xmm15, xmm12
0000796d027cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
0000796d027cf753  ptest xmm1, xmm1
0000796d027cf758  jnz 0x0000796D027D1095
0000796d027cf75e  vmovaps xmm1, [rsp+0x30]
0000796d027cf764  vmovaps xmm12, [rsp+0x30]
0000796d027cf76a  por xmm1, xmm12
0000796d027cf76f  vmovaps xmm12, [rsp+0x20]
0000796d027cf775  vmovaps xmm10, [rsp+0x20]
0000796d027cf77b  por xmm12, xmm10
0000796d027cf780  vmovaps [rsp+0x20], xmm5
0000796d027cf786  vmovaps xmm10, [rsp+0x20]
0000796d027cf78c  por xmm5, xmm10
0000796d027cf791  vmovaps [rsp+0x20], xmm11
0000796d027cf797  vmovaps xmm10, [rsp+0x20]
0000796d027cf79d  por xmm11, xmm10
0000796d027cf7a2  vmovaps [rsp+0x20], xmm4
0000796d027cf7a8  vmovaps xmm10, [rsp+0x20]
0000796d027cf7ae  por xmm4, xmm10
0000796d027cf7b3  vmovaps [rsp+0x20], xmm8
0000796d027cf7b9  vmovaps xmm10, [rsp+0x20]
0000796d027cf7bf  por xmm8, xmm10
0000796d027cf7c4  vmovaps xmm10, [rsp+0xF0]
0000796d027cf7cd  vmovaps [rsp+0x20], xmm1
0000796d027cf7d3  vmovaps xmm1, [rsp+0xF0]
0000796d027cf7dc  por xmm10, xmm1
0000796d027cf7e1  lea rax, [r14+0xA0]
0000796d027cf7e8  movups xmm1, [r13+rax*1]
0000796d027cf7ee  lea rax, [r14+0xB0]
0000796d027cf7f5  vmovaps [rsp+0x30], xmm1
0000796d027cf7fb  movups xmm1, [r13+rax*1]
0000796d027cf801  vmovaps [rsp+0xF0], xmm1
0000796d027cf80a  vmovaps [rsp+0x120], xmm15
0000796d027cf813  movaps xmm1, xmm13
0000796d027cf817  addpd xmm1, xmm2
0000796d027cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
0000796d027cf820  ptest xmm15, xmm15
0000796d027cf826  jnz 0x0000796D027D11ED
0000796d027cf82c  lea rax, [r14+0xF0]
0000796d027cf833  movups xmm15, [r13+rax*1]
0000796d027cf839  vmovaps xmm2, [rsp+0xC0]
0000796d027cf842  vmovaps [rsp+0xC0], xmm1
0000796d027cf84b  vmovaps xmm1, [rsp+0xE0]
0000796d027cf854  vmovaps [rsp+0xE0], xmm15
0000796d027cf85d  movaps xmm13, xmm2
0000796d027cf861  addpd xmm13, xmm1
0000796d027cf866  vcmppd xmm15, xmm13, xmm13, 0x03
0000796d027cf86c  ptest xmm15, xmm15
0000796d027cf872  jnz 0x0000796D027D1338
0000796d027cf878  vmovaps xmm15, [rsp+0x120]
0000796d027cf881  vmovaps xmm2, [rsp+0xD0]
0000796d027cf88a  vmovaps [rsp+0xD0], xmm14
0000796d027cf893  movaps xmm1, xmm15
0000796d027cf897  addpd xmm1, xmm2
0000796d027cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
0000796d027cf8a0  ptest xmm14, xmm14
0000796d027cf8a6  jnz 0x0000796D027D147A
0000796d027cf8ac  vmovaps xmm15, [rsp+0x100]
0000796d027cf8b5  vpermilpd xmm15, xmm15, 0x00
0000796d027cf8bb  vmovaps xmm2, [rsp+0xF0]
0000796d027cf8c4  vmovaps [rsp+0xF0], xmm1
0000796d027cf8cd  movaps xmm14, xmm2
0000796d027cf8d1  mulpd xmm14, xmm15
0000796d027cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
0000796d027cf8dc  ptest xmm1, xmm1
0000796d027cf8e1  jnz 0x0000796D027D15BB
0000796d027cf8e7  vmovaps xmm1, [rsp+0xA0]
0000796d027cf8f0  vpermilpd xmm1, xmm1, 0x00
0000796d027cf8f6  vmovaps xmm2, [rsp+0xE0]
0000796d027cf8ff  vmovaps [rsp+0xE0], xmm14
0000796d027cf908  movaps xmm15, xmm2
0000796d027cf90c  mulpd xmm15, xmm1
0000796d027cf911  vcmppd xmm14, xmm15, xmm15, 0x03
0000796d027cf917  ptest xmm14, xmm14
0000796d027cf91d  jnz 0x0000796D027D16FE
0000796d027cf923  lea rax, [r14+0xE0]
0000796d027cf92a  movups xmm1, [r13+rax*1]
0000796d027cf930  vmovaps xmm14, [rsp+0x100]
0000796d027cf939  vpermilpd xmm14, xmm14, 0x00
0000796d027cf93f  vmovaps [rsp+0x100], xmm1
0000796d027cf948  vmovaps xmm1, [rsp+0x30]
0000796d027cf94e  vmovaps [rsp+0x30], xmm15
0000796d027cf954  movaps xmm2, xmm1
0000796d027cf957  mulpd xmm2, xmm14
0000796d027cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
0000796d027cf961  ptest xmm15, xmm15
0000796d027cf967  jnz 0x0000796D027D184A
0000796d027cf96d  vmovaps [rsp+0x120], xmm10
0000796d027cf976  vmovaps xmm1, [rsp+0x120]
0000796d027cf97f  por xmm10, xmm1
0000796d027cf984  movaps [r15+0x300], xmm10
0000796d027cf98c  vmovaps [rsp+0x120], xmm8
0000796d027cf995  vmovaps xmm1, [rsp+0x120]
0000796d027cf99e  por xmm8, xmm1
0000796d027cf9a3  movaps [r15+0x190], xmm8
0000796d027cf9ab  vmovaps xmm1, [rsp+0xA0]
0000796d027cf9b4  vpermilpd xmm1, xmm1, 0x00
0000796d027cf9ba  vmovaps xmm14, [rsp+0x100]
0000796d027cf9c3  vmovaps [rsp+0x100], xmm13
0000796d027cf9cc  movaps xmm15, xmm14
0000796d027cf9d0  mulpd xmm15, xmm1
0000796d027cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
0000796d027cf9db  ptest xmm13, xmm13
0000796d027cf9e1  jnz 0x0000796D027D198B
0000796d027cf9e7  lea rax, [r14+0x90]
0000796d027cf9ee  movups xmm1, [r13+rax*1]
0000796d027cf9f4  vmovaps [rsp+0x120], xmm4
0000796d027cf9fd  vmovaps xmm14, [rsp+0x120]
0000796d027cfa06  por xmm4, xmm14
0000796d027cfa0b  movaps [r15+0x1C0], xmm4
0000796d027cfa13  vmovaps [rsp+0x120], xmm11
0000796d027cfa1c  vmovaps xmm14, [rsp+0x120]
0000796d027cfa25  por xmm11, xmm14
0000796d027cfa2a  movaps [r15+0x200], xmm11
0000796d027cfa32  vmovaps [rsp+0x120], xmm5
0000796d027cfa3b  vmovaps xmm14, [rsp+0x120]
0000796d027cfa44  por xmm5, xmm14
0000796d027cfa49  movaps [r15+0x2D0], xmm5
0000796d027cfa51  vmovaps [rsp+0x120], xmm12
0000796d027cfa5a  vmovaps xmm14, [rsp+0x120]
0000796d027cfa63  por xmm12, xmm14
0000796d027cfa68  movaps [r15+0x2E0], xmm12
0000796d027cfa70  vmovaps xmm13, [rsp+0x110]
0000796d027cfa79  vmovaps [rsp+0x110], xmm1
0000796d027cfa82  vmovaps xmm1, [rsp+0xE0]
0000796d027cfa8b  vmovaps [rsp+0xE0], xmm15
0000796d027cfa94  movaps xmm14, xmm13
0000796d027cfa98  addpd xmm14, xmm1
0000796d027cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
0000796d027cfaa3  ptest xmm15, xmm15
0000796d027cfaa9  jnz 0x0000796D027D1AD8
0000796d027cfaaf  vmovaps xmm1, [rsp+0xA0]
0000796d027cfab8  vpermilpd xmm1, xmm1, 0x00
0000796d027cfabe  vmovaps xmm13, [rsp+0x110]
0000796d027cfac7  vmovaps [rsp+0x110], xmm14
0000796d027cfad0  movaps xmm15, xmm13
0000796d027cfad4  mulpd xmm15, xmm1
0000796d027cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
0000796d027cfadf  ptest xmm14, xmm14
0000796d027cfae5  jnz 0x0000796D027D1C1B
0000796d027cfaeb  lea rax, [r14+0x80]
0000796d027cfaf2  movups xmm1, [r13+rax*1]
0000796d027cfaf8  vmovaps xmm13, [rsp+0xC0]
0000796d027cfb01  vmovaps [rsp+0xC0], xmm1
0000796d027cfb0a  movaps xmm14, xmm13
0000796d027cfb0e  addpd xmm14, xmm2
0000796d027cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
0000796d027cfb19  ptest xmm1, xmm1
0000796d027cfb1e  jnz 0x0000796D027D1D68
0000796d027cfb24  vmovaps xmm13, [rsp+0x100]
0000796d027cfb2d  vmovaps xmm2, [rsp+0x30]
0000796d027cfb33  vmovaps [rsp+0x30], xmm15
0000796d027cfb39  movaps xmm1, xmm13
0000796d027cfb3d  addpd xmm1, xmm2
0000796d027cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
0000796d027cfb46  ptest xmm15, xmm15
0000796d027cfb4c  jnz 0x0000796D027D1EAB
0000796d027cfb52  vmovaps xmm15, [rsp+0x20]
0000796d027cfb58  vmovaps xmm13, [rsp+0x20]
0000796d027cfb5e  por xmm15, xmm13
0000796d027cfb63  movaps [r15+0x2F0], xmm15
0000796d027cfb6b  vmovaps xmm13, [rsp+0xA0]
0000796d027cfb74  vpermilpd xmm13, xmm13, 0x00
0000796d027cfb7a  vmovaps [rsp+0x20], xmm1
0000796d027cfb80  vmovaps xmm1, [rsp+0xC0]
0000796d027cfb89  vmovaps [rsp+0xA0], xmm15
0000796d027cfb92  movaps xmm2, xmm1
0000796d027cfb95  mulpd xmm2, xmm13
0000796d027cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
0000796d027cfb9f  ptest xmm15, xmm15
0000796d027cfba5  jnz 0x0000796D027D1FEC
0000796d027cfbab  lea rax, [r14+0xD0]
0000796d027cfbb2  movups xmm1, [r13+rax*1]
0000796d027cfbb8  vmovaps xmm13, [rsp+0xF0]
0000796d027cfbc1  vmovaps [rsp+0xC0], xmm1
0000796d027cfbca  vmovaps xmm1, [rsp+0xE0]
0000796d027cfbd3  vmovaps [rsp+0xE0], xmm14
0000796d027cfbdc  movaps xmm15, xmm13
0000796d027cfbe0  addpd xmm15, xmm1
0000796d027cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
0000796d027cfbeb  ptest xmm14, xmm14
0000796d027cfbf1  jnz 0x0000796D027D2137
0000796d027cfbf7  vmovaps xmm1, [rsp+0xB0]
0000796d027cfc00  vpermilpd xmm1, xmm1, 0x00
0000796d027cfc06  movaps xmm14, xmm11
0000796d027cfc0a  mulpd xmm14, xmm1
0000796d027cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
0000796d027cfc15  ptest xmm13, xmm13
0000796d027cfc1b  jnz 0x0000796D027D227A
0000796d027cfc21  movaps [r15+0x260], xmm14
0000796d027cfc29  vxorps xmm1, xmm1, xmm1
0000796d027cfc2d  vpbroadcastq xmm1, xmm1
0000796d027cfc32  movaps [r15+0x1B0], xmm1
0000796d027cfc3a  vmovaps xmm1, [rsp+0xB0]
0000796d027cfc43  vpermilpd xmm1, xmm1, 0x00
0000796d027cfc49  vmovaps xmm11, [rsp+0xC0]
0000796d027cfc52  vmovaps [rsp+0xC0], xmm15
0000796d027cfc5b  movaps xmm13, xmm11
0000796d027cfc5f  mulpd xmm13, xmm1
0000796d027cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
0000796d027cfc6a  ptest xmm15, xmm15
0000796d027cfc70  jnz 0x0000796D027D23BD
0000796d027cfc76  lea rax, [r14+0xC0]
0000796d027cfc7d  movups xmm1, [r13+rax*1]
0000796d027cfc83  vmovaps xmm11, [rsp+0x110]
0000796d027cfc8c  vmovaps [rsp+0xF0], xmm1
0000796d027cfc95  vmovaps xmm1, [rsp+0x30]
0000796d027cfc9b  vmovaps [rsp+0x30], xmm14
0000796d027cfca1  movaps xmm15, xmm11
0000796d027cfca5  addpd xmm15, xmm1
0000796d027cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
0000796d027cfcb0  ptest xmm14, xmm14
0000796d027cfcb6  jnz 0x0000796D027D250A
0000796d027cfcbc  vmovaps [rsp+0x100], xmm9
0000796d027cfcc5  vmovaps xmm1, [rsp+0x100]
0000796d027cfcce  por xmm9, xmm1
0000796d027cfcd3  movaps [r15+0x270], xmm9
0000796d027cfcdb  vmovaps [rsp+0x100], xmm6
0000796d027cfce4  vmovaps xmm1, [rsp+0x100]
0000796d027cfced  por xmm6, xmm1
0000796d027cfcf1  movaps [r15+0x1A0], xmm6
0000796d027cfcf9  vmovaps xmm14, [rsp+0xB0]
0000796d027cfd02  vpermilpd xmm14, xmm14, 0x00
0000796d027cfd08  vmovaps xmm6, [rsp+0xF0]
0000796d027cfd11  vmovaps [rsp+0xF0], xmm1
0000796d027cfd1a  movaps xmm11, xmm6
0000796d027cfd1e  mulpd xmm11, xmm14
0000796d027cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
0000796d027cfd29  ptest xmm1, xmm1
0000796d027cfd2e  jnz 0x0000796D027D264D
0000796d027cfd34  lea rax, [r14+0x20]
0000796d027cfd38  movups xmm1, [r13+rax*1]
0000796d027cfd3e  movaps [r15+0x110], xmm1
0000796d027cfd46  vmovaps xmm6, [rsp+0xE0]
0000796d027cfd4f  vmovaps [rsp+0xE0], xmm1
0000796d027cfd58  movaps xmm14, xmm6
0000796d027cfd5c  addpd xmm14, xmm2
0000796d027cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
0000796d027cfd67  ptest xmm1, xmm1
0000796d027cfd6c  jnz 0x0000796D027D279A
0000796d027cfd72  vmovaps xmm1, [rsp+0xB0]
0000796d027cfd7b  vpermilpd xmm1, xmm1, 0x00
0000796d027cfd81  movaps xmm6, xmm5
0000796d027cfd84  mulpd xmm6, xmm1
0000796d027cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
0000796d027cfd8d  ptest xmm2, xmm2
0000796d027cfd92  jnz 0x0000796D027D28DC
0000796d027cfd98  vmovaps xmm5, [rsp+0x20]
0000796d027cfd9e  movaps xmm1, xmm5
0000796d027cfda1  addpd xmm1, xmm13
0000796d027cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
0000796d027cfdab  ptest xmm2, xmm2
0000796d027cfdb0  jnz 0x0000796D027D2A1C
0000796d027cfdb6  vmovaps xmm13, [rsp+0x80]
0000796d027cfdbf  vpermilpd xmm13, xmm13, 0x00
0000796d027cfdc5  vmovaps xmm2, [rsp+0xE0]
0000796d027cfdce  vmovaps [rsp+0x20], xmm1
0000796d027cfdd4  movaps xmm5, xmm2
0000796d027cfdd7  mulpd xmm5, xmm13
0000796d027cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
0000796d027cfde1  ptest xmm1, xmm1
0000796d027cfde6  jnz 0x0000796D027D2B5D
0000796d027cfdec  vmovaps xmm1, [rsp+0x80]
0000796d027cfdf5  vpermilpd xmm1, xmm1, 0x00
0000796d027cfdfb  movaps xmm13, xmm10
0000796d027cfdff  mulpd xmm13, xmm1
0000796d027cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
0000796d027cfe0a  ptest xmm2, xmm2
0000796d027cfe0f  jnz 0x0000796D027D2C9E
0000796d027cfe15  vmovaps xmm10, [rsp+0x30]
0000796d027cfe1b  movaps xmm1, xmm15
0000796d027cfe1f  addpd xmm1, xmm10
0000796d027cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
0000796d027cfe29  ptest xmm2, xmm2
0000796d027cfe2e  jnz 0x0000796D027D2DE1
0000796d027cfe34  vmovaps xmm10, [rsp+0xC0]
0000796d027cfe3d  movaps xmm15, xmm10
0000796d027cfe41  addpd xmm15, xmm11
0000796d027cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
0000796d027cfe4c  ptest xmm2, xmm2
0000796d027cfe51  jnz 0x0000796D027D2F23
0000796d027cfe57  vmovaps xmm11, [rsp+0x80]
0000796d027cfe60  vpermilpd xmm11, xmm11, 0x00
0000796d027cfe66  movaps xmm10, xmm12
0000796d027cfe6a  mulpd xmm10, xmm11
0000796d027cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
0000796d027cfe75  ptest xmm2, xmm2
0000796d027cfe7a  jnz 0x0000796D027D3067
0000796d027cfe80  vmovaps xmm12, [rsp+0x80]
0000796d027cfe89  vpermilpd xmm12, xmm12, 0x00
0000796d027cfe8f  vmovaps xmm2, [rsp+0xA0]
0000796d027cfe98  vmovaps [rsp+0x30], xmm1
0000796d027cfe9e  movaps xmm11, xmm2
0000796d027cfea2  mulpd xmm11, xmm12
0000796d027cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
0000796d027cfead  ptest xmm1, xmm1
0000796d027cfeb2  jnz 0x0000796D027D31AB
0000796d027cfeb8  movaps xmm1, xmm14
0000796d027cfebc  addpd xmm1, xmm6
0000796d027cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
0000796d027cfec5  ptest xmm12, xmm12
0000796d027cfecb  jnz 0x0000796D027D32EE
0000796d027cfed1  vmovaps xmm12, [rsp+0x20]
0000796d027cfed7  movaps xmm14, xmm12
0000796d027cfedb  addpd xmm14, xmm5
0000796d027cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
0000796d027cfee6  ptest xmm6, xmm6
0000796d027cfeeb  jnz 0x0000796D027D342F
0000796d027cfef1  vmovaps xmm12, [rsp+0x90]
0000796d027cfefa  vpermilpd xmm12, xmm12, 0x00
0000796d027cff00  movaps xmm6, xmm9
0000796d027cff04  mulpd xmm6, xmm12
0000796d027cff09  vcmppd xmm5, xmm6, xmm6, 0x03
0000796d027cff0e  ptest xmm5, xmm5
0000796d027cff13  jnz 0x0000796D027D3572
0000796d027cff19  movaps xmm12, xmm15
0000796d027cff1d  addpd xmm12, xmm13
0000796d027cff22  vcmppd xmm9, xmm12, xmm12, 0x03
0000796d027cff28  ptest xmm9, xmm9
0000796d027cff2e  jnz 0x0000796D027D36B4
0000796d027cff34  vmovaps xmm13, [rsp+0x30]
0000796d027cff3a  movaps xmm15, xmm13
0000796d027cff3e  addpd xmm15, xmm10
0000796d027cff43  vcmppd xmm9, xmm15, xmm15, 0x03
0000796d027cff49  ptest xmm9, xmm9
0000796d027cff4f  jnz 0x0000796D027D37F8
0000796d027cff55  vmovaps xmm13, [rsp+0xD0]
0000796d027cff5e  vmovaps xmm10, [rsp+0xD0]
0000796d027cff67  por xmm13, xmm10
0000796d027cff6c  movaps [r15+0x250], xmm13
0000796d027cff74  vmovaps [rsp+0x20], xmm7
0000796d027cff7a  vmovaps xmm13, [rsp+0x20]
0000796d027cff80  por xmm7, xmm13
0000796d027cff85  movaps [r15+0x2A0], xmm7
0000796d027cff8d  vmovaps [rsp+0x20], xmm3
0000796d027cff93  vmovaps xmm13, [rsp+0x20]
0000796d027cff99  por xmm3, xmm13
0000796d027cff9e  movaps [r15+0x1D0], xmm3
0000796d027cffa6  lea rax, [r14+0x40]
0000796d027cffaa  movups xmm13, [r13+rax*1]
0000796d027cffb0  movaps [r15+0x2C0], xmm13
0000796d027cffb8  vmovaps xmm10, [rsp+0x90]
0000796d027cffc1  vpermilpd xmm10, xmm10, 0x00
0000796d027cffc7  movaps xmm9, xmm8
0000796d027cffcb  mulpd xmm9, xmm10
0000796d027cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
0000796d027cffd6  ptest xmm5, xmm5
0000796d027cffdb  jnz 0x0000796D027D3946
0000796d027cffe1  movaps xmm10, xmm1
0000796d027cffe5  addpd xmm10, xmm11
0000796d027cffea  vcmppd xmm8, xmm10, xmm10, 0x03
0000796d027cfff0  ptest xmm8, xmm8
0000796d027cfff6  jnz 0x0000796D027D3A8A
0000796d027cfffc  movaps xmm1, xmm14
0000796d027d0000  addpd xmm1, xmm6
0000796d027d0004  vcmppd xmm11, xmm1, xmm1, 0x03
0000796d027d0009  ptest xmm11, xmm11
0000796d027d000f  jnz 0x0000796D027D3BCD
0000796d027d0015  vmovaps xmm14, [rsp+0x90]
0000796d027d001e  vpermilpd xmm14, xmm14, 0x00
0000796d027d0024  movaps xmm11, xmm13
0000796d027d0028  mulpd xmm11, xmm14
0000796d027d002d  vcmppd xmm8, xmm11, xmm11, 0x03
0000796d027d0033  ptest xmm8, xmm8
0000796d027d0039  jnz 0x0000796D027D3D0E
0000796d027d003f  vmovaps xmm14, [rsp+0x90]
0000796d027d0048  vpermilpd xmm14, xmm14, 0x00
0000796d027d004e  vmovaps xmm8, [rsp+0x10]
0000796d027d0054  movaps xmm13, xmm8
0000796d027d0058  mulpd xmm13, xmm14
0000796d027d005d  vcmppd xmm6, xmm13, xmm13, 0x03
0000796d027d0063  ptest xmm6, xmm6
0000796d027d0068  jnz 0x0000796D027D3E52
0000796d027d006e  vmovaps xmm14, [rsp+0x60]
0000796d027d0074  vpermilpd xmm14, xmm14, 0x00
0000796d027d007a  movaps xmm8, xmm7
0000796d027d007e  mulpd xmm8, xmm14
0000796d027d0083  vcmppd xmm6, xmm8, xmm8, 0x03
0000796d027d0089  ptest xmm6, xmm6
0000796d027d008e  jnz 0x0000796D027D3F96
0000796d027d0094  movaps xmm14, xmm12
0000796d027d0098  addpd xmm14, xmm9
0000796d027d009d  vcmppd xmm7, xmm14, xmm14, 0x03
0000796d027d00a3  ptest xmm7, xmm7
0000796d027d00a8  jnz 0x0000796D027D40D9
0000796d027d00ae  vmovaps xmm12, [rsp+0x60]
0000796d027d00b4  vpermilpd xmm12, xmm12, 0x00
0000796d027d00ba  vmovaps xmm7, [rsp+0xF0]
0000796d027d00c3  movaps xmm9, xmm7
0000796d027d00c7  mulpd xmm9, xmm12
0000796d027d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
0000796d027d00d2  ptest xmm6, xmm6
0000796d027d00d7  jnz 0x0000796D027D421D
0000796d027d00dd  movaps xmm12, xmm15
0000796d027d00e1  addpd xmm12, xmm11
0000796d027d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
0000796d027d00ec  ptest xmm7, xmm7
0000796d027d00f1  jnz 0x0000796D027D4360
0000796d027d00f7  vmovaps xmm15, [rsp+0x60]
0000796d027d00fd  vpermilpd xmm15, xmm15, 0x00
0000796d027d0103  vmovaps xmm7, [rsp+0x40]
0000796d027d0109  movaps xmm11, xmm7
0000796d027d010d  mulpd xmm11, xmm15
0000796d027d0112  vcmppd xmm6, xmm11, xmm11, 0x03
0000796d027d0118  ptest xmm6, xmm6
0000796d027d011d  jnz 0x0000796D027D44A4
0000796d027d0123  movaps xmm15, xmm10
0000796d027d0127  addpd xmm15, xmm13
0000796d027d012c  vcmppd xmm7, xmm15, xmm15, 0x03
0000796d027d0132  ptest xmm7, xmm7
0000796d027d0137  jnz 0x0000796D027D45E7
0000796d027d013d  vmovaps xmm13, [rsp+0x60]
0000796d027d0143  vpermilpd xmm13, xmm13, 0x00
0000796d027d0149  vmovaps xmm7, [rsp+0x50]
0000796d027d014f  movaps xmm10, xmm7
0000796d027d0153  mulpd xmm10, xmm13
0000796d027d0158  vcmppd xmm6, xmm10, xmm10, 0x03
0000796d027d015e  ptest xmm6, xmm6
0000796d027d0163  jnz 0x0000796D027D472B
0000796d027d0169  movaps xmm13, xmm1
0000796d027d016d  addpd xmm13, xmm8
0000796d027d0172  vcmppd xmm7, xmm13, xmm13, 0x03
0000796d027d0178  ptest xmm7, xmm7
0000796d027d017d  jnz 0x0000796D027D486E
0000796d027d0183  lea rax, [r14+0x70]
0000796d027d0187  movups xmm1, [r13+rax*1]
0000796d027d018d  movaps [r15+0x240], xmm1
0000796d027d0195  movaps xmm8, xmm14
0000796d027d0199  addpd xmm8, xmm9
0000796d027d019e  vcmppd xmm7, xmm8, xmm8, 0x03
0000796d027d01a4  ptest xmm7, xmm7
0000796d027d01a9  jnz 0x0000796D027D49BB
0000796d027d01af  movaps [r15+0x170], xmm8
0000796d027d01b7  vmovaps xmm14, [rsp+0x70]
0000796d027d01bd  vpermilpd xmm14, xmm14, 0x00
0000796d027d01c3  movaps xmm9, xmm1
0000796d027d01c7  mulpd xmm9, xmm14
0000796d027d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
0000796d027d01d2  ptest xmm7, xmm7
0000796d027d01d7  jnz 0x0000796D027D4AFF
0000796d027d01dd  vmovaps xmm1, [rsp+0x70]
0000796d027d01e3  vpermilpd xmm1, xmm1, 0x00
0000796d027d01e9  movaps xmm14, xmm4
0000796d027d01ed  mulpd xmm14, xmm1
0000796d027d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
0000796d027d01f8  ptest xmm7, xmm7
0000796d027d01fd  jnz 0x0000796D027D4C42
0000796d027d0203  movaps [r15+0x180], xmm14
0000796d027d020b  movaps xmm1, xmm12
0000796d027d020f  addpd xmm1, xmm11
0000796d027d0214  vcmppd xmm7, xmm1, xmm1, 0x03
0000796d027d0219  ptest xmm7, xmm7
0000796d027d021e  jnz 0x0000796D027D4D84
0000796d027d0224  movaps [r15+0x210], xmm1
0000796d027d022c  movups xmm12, [r13+r14*1]
0000796d027d0232  lea rax, [r14+0x10]
0000796d027d0236  movups xmm11, [r13+rax*1]
0000796d027d023c  movaps [r15+0x230], xmm11
0000796d027d0244  movaps xmm7, xmm15
0000796d027d0248  addpd xmm7, xmm10
0000796d027d024d  vcmppd xmm6, xmm7, xmm7, 0x03
0000796d027d0252  ptest xmm6, xmm6
0000796d027d0257  jnz 0x0000796D027D4EDA
0000796d027d025d  movaps [r15+0x130], xmm7
0000796d027d0265  vmovaps xmm15, [rsp+0x70]
0000796d027d026b  vpermilpd xmm15, xmm15, 0x00
0000796d027d0271  movaps xmm10, xmm11
0000796d027d0275  mulpd xmm10, xmm15
0000796d027d027a  vcmppd xmm6, xmm10, xmm10, 0x03
0000796d027d0280  ptest xmm6, xmm6
0000796d027d0285  jnz 0x0000796D027D501C
0000796d027d028b  movaps [r15+0x220], xmm10
0000796d027d0293  vmovaps xmm15, [rsp+0x70]
0000796d027d0299  vpermilpd xmm15, xmm15, 0x00
0000796d027d029f  movaps xmm11, xmm12
0000796d027d02a3  mulpd xmm11, xmm15
0000796d027d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
0000796d027d02ae  ptest xmm6, xmm6
0000796d027d02b3  jnz 0x0000796D027D5160
0000796d027d02b9  movaps xmm15, xmm13
0000796d027d02bd  addpd xmm15, xmm9
0000796d027d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
0000796d027d02c8  ptest xmm12, xmm12
0000796d027d02ce  jnz 0x0000796D027D52A4
0000796d027d02d4  movaps [r15+0x140], xmm15
0000796d027d02dc  movaps xmm13, xmm8
0000796d027d02e0  addpd xmm13, xmm14
0000796d027d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
0000796d027d02eb  ptest xmm12, xmm12
0000796d027d02f1  jnz 0x0000796D027D53E8
0000796d027d02f7  movaps [r15+0x150], xmm13
0000796d027d02ff  movaps xmm14, xmm1
0000796d027d0303  addpd xmm14, xmm10
0000796d027d0308  vcmppd xmm12, xmm14, xmm14, 0x03
0000796d027d030e  ptest xmm12, xmm12
0000796d027d0314  jnz 0x0000796D027D552C
0000796d027d031a  movaps [r15+0x160], xmm14
0000796d027d0322  movaps xmm1, xmm7
0000796d027d0325  addpd xmm1, xmm11
0000796d027d032a  vcmppd xmm12, xmm1, xmm1, 0x03
0000796d027d032f  ptest xmm12, xmm12
0000796d027d0335  jnz 0x0000796D027D566F
0000796d027d033b  movaps [r15+0x120], xmm1
0000796d027d0343  mov eax, 0x430920
0000796d027d0348  movups [r13+rax*1], xmm15
0000796d027d034e  mov eax, 0x430930
0000796d027d0353  movups [r13+rax*1], xmm13
0000796d027d0359  mov eax, 0x430940
0000796d027d035e  movups [r13+rax*1], xmm14
0000796d027d0364  mov eax, 0x430950
0000796d027d0369  movups [r13+rax*1], xmm1
0000796d027d036f  mov eax, [r15+0x108]
0000796d027d0376  sahf
0000796d027d0377  jnz 0x0000796D027D03A9
0000796d027d0379  cmp dword ptr [r15+0x318], 0x00
0000796d027d0381  jz 0x0000796D027DB900
0000796d027d0387  nop [rax+rax*1], ax
0000796d027d0390  nop [rax+rax*1], eax
0000796d027d0398  mov eax, 0x410444
0000796d027d039d  mov [r15+0x100], rax
0000796d027d03a4  jmp 0x0000796D025FE110
0000796d027d03a9  cmp dword ptr [r15+0x318], 0x00
0000796d027d03b1  jz 0x0000796D027D57E0
0000796d027d03b7  nop [rax+rax*1], ax
0000796d027d03c0  nop [rax+rax*1], eax
0000796d027d03c8  mov eax, 0x410278
0000796d027d03cd  mov [r15+0x100], rax
0000796d027d03d4  jmp 0x0000796D025FE110
0000796d027d03d9  int3
0000796d027d03da  call 0x0000796D026B52F0
0000796d027d03df  jmp 0x0000796D027CF016
0000796d027d03e4  call 0x0000796D026C4620
0000796d027d03e9  jmp 0x0000796D027CF023
0000796d027d03ee  call 0x0000796D026C33A0
0000796d027d03f3  jmp 0x0000796D027CF035
0000796d027d03f8  call 0x0000796D026C2120
0000796d027d03fd  jmp 0x0000796D027CF03F
0000796d027d0402  call 0x0000796D026C0860
0000796d027d0407  jmp 0x0000796D027CF067
0000796d027d040c  call 0x0000796D026BF5F0
0000796d027d0411  jmp 0x0000796D027CF073
0000796d027d0416  call 0x0000796D026C0860
0000796d027d041b  jmp 0x0000796D027CF0A5
0000796d027d0420  call 0x0000796D026BF5F0
0000796d027d0425  jmp 0x0000796D027CF0B1
0000796d027d042a  call 0x0000796D026C4740
0000796d027d042f  jmp 0x0000796D027CF0BE
0000796d027d0434  call 0x0000796D026B5400
0000796d027d0439  jmp 0x0000796D027CF0CB
0000796d027d043e  call 0x0000796D026B52F0
0000796d027d0443  jmp 0x0000796D027CF0D8
0000796d027d0448  call 0x0000796D026C4620
0000796d027d044d  jmp 0x0000796D027CF0E5
0000796d027d0452  call 0x0000796D026C0860
0000796d027d0457  jmp 0x0000796D027CF10D
0000796d027d045c  call 0x0000796D026BF5F0
0000796d027d0461  jmp 0x0000796D027CF119
0000796d027d0466  call 0x0000796D02609D70
0000796d027d046b  jmp 0x0000796D027CF11F
0000796d027d0470  call 0x0000796D026BE9C0
0000796d027d0475  jmp 0x0000796D027CF129
0000796d027d047a  call 0x0000796D026C0860
0000796d027d047f  jmp 0x0000796D027CF151
0000796d027d0484  call 0x0000796D026BF5F0
0000796d027d0489  jmp 0x0000796D027CF15D
0000796d027d048e  call 0x0000796D026BD750
0000796d027d0493  jmp 0x0000796D027CF16A
0000796d027d0498  call 0x0000796D026BC4E0
0000796d027d049d  jmp 0x0000796D027CF177
0000796d027d04a2  call 0x0000796D026C4740
0000796d027d04a7  jmp 0x0000796D027CF184
0000796d027d04ac  call 0x0000796D026B5400
0000796d027d04b1  jmp 0x0000796D027CF191
0000796d027d04b6  call 0x0000796D026B52F0
0000796d027d04bb  jmp 0x0000796D027CF19E
0000796d027d04c0  call 0x0000796D026C4620
0000796d027d04c5  jmp 0x0000796D027CF1AB
0000796d027d04ca  call 0x0000796D026C0860
0000796d027d04cf  jmp 0x0000796D027CF1BE
0000796d027d04d4  call 0x0000796D026BB270
0000796d027d04d9  jmp 0x0000796D027CF1CB
0000796d027d04de  call 0x0000796D026BA000
0000796d027d04e3  jmp 0x0000796D027CF1D8
0000796d027d04e8  call 0x0000796D026B8D90
0000796d027d04ed  jmp 0x0000796D027CF1E5
0000796d027d04f2  call 0x0000796D026B8A20
0000796d027d04f7  jmp 0x0000796D027CF1F2
0000796d027d04fc  call 0x0000796D026B5400
0000796d027d0501  jmp 0x0000796D027CF1FC
0000796d027d0506  call 0x0000796D026C2240
0000796d027d050b  jmp 0x0000796D027CF206
0000796d027d0510  call 0x0000796D026B52F0
0000796d027d0515  jmp 0x0000796D027CF210
0000796d027d051a  call 0x0000796D026C2120
0000796d027d051f  jmp 0x0000796D027CF21A
0000796d027d0524  call 0x0000796D026B77B0
0000796d027d0529  jmp 0x0000796D027CF224
0000796d027d052e  call 0x0000796D026B6550
0000796d027d0533  jmp 0x0000796D027CF22E
0000796d027d0538  call 0x0000796D026BFD50
0000796d027d053d  jmp 0x0000796D027CF240
0000796d027d0542  call 0x0000796D026B8EA0
0000796d027d0547  jmp 0x0000796D027CF24A
0000796d027d054c  call 0x0000796D026BFC30
0000796d027d0551  jmp 0x0000796D027CF257
0000796d027d0556  call 0x0000796D026B8D90
0000796d027d055b  jmp 0x0000796D027CF264
0000796d027d0560  call 0x0000796D026C2240
0000796d027d0565  jmp 0x0000796D027CF271
0000796d027d056a  call 0x0000796D026B5400
0000796d027d056f  jmp 0x0000796D027CF27E
0000796d027d0574  call 0x0000796D026B52F0
0000796d027d0579  jmp 0x0000796D027CF28B
0000796d027d057e  call 0x0000796D026C2120
0000796d027d0583  jmp 0x0000796D027CF298
0000796d027d0588  call 0x0000796D026B52F0
0000796d027d058d  jmp 0x0000796D027CF2AB
0000796d027d0592  call 0x0000796D026B52F0
0000796d027d0597  jmp 0x0000796D027CF2BE
0000796d027d059c  call 0x0000796D026B52F0
0000796d027d05a1  jmp 0x0000796D027CF2D1
0000796d027d05a6  call 0x0000796D026B52F0
0000796d027d05ab  jmp 0x0000796D027CF2E4
0000796d027d05b0  call 0x0000796D026C2240
0000796d027d05b5  jmp 0x0000796D027CF2F9
0000796d027d05ba  call 0x0000796D026C2240
0000796d027d05bf  jmp 0x0000796D027CF30C
0000796d027d05c4  call 0x0000796D026C2120
0000796d027d05c9  jmp 0x0000796D027CF319
0000796d027d05ce  call 0x0000796D026B52F0
0000796d027d05d3  jmp 0x0000796D027CF32C
0000796d027d05d8  call 0x0000796D026B52F0
0000796d027d05dd  jmp 0x0000796D027CF34F
0000796d027d05e2  call 0x0000796D026B52F0
0000796d027d05e7  jmp 0x0000796D027CF362
0000796d027d05ec  call 0x0000796D025FF540
0000796d027d05f1  jmp 0x0000796D027CF380
0000796d027d05f6  call 0x0000796D02608C20
0000796d027d05fb  jmp 0x0000796D027CF38A
0000796d027d0600  call 0x0000796D026D6600
0000796d027d0605  jmp 0x0000796D027CF396
0000796d027d060a  call 0x0000796D025FF540
0000796d027d060f  jmp 0x0000796D027CF3A6
0000796d027d0614  call 0x0000796D026C0370
0000796d027d0619  jmp 0x0000796D027CF3D4
0000796d027d061e  call 0x0000796D026BF100
0000796d027d0623  jmp 0x0000796D027CF3DD
0000796d027d0628  call 0x0000796D026C0370
0000796d027d062d  jmp 0x0000796D027CF43B
0000796d027d0632  call 0x0000796D026BF100
0000796d027d0637  jmp 0x0000796D027CF444
0000796d027d063c  call 0x0000796D026C0370
0000796d027d0641  jmp 0x0000796D027CF48B
0000796d027d0646  call 0x0000796D026BF100
0000796d027d064b  jmp 0x0000796D027CF494
0000796d027d0650  call 0x0000796D0260B720
0000796d027d0655  jmp 0x0000796D027CF4D7
0000796d027d065a  call 0x0000796D026B47C0
0000796d027d065f  jmp 0x0000796D027CF4EA
0000796d027d0664  call 0x0000796D02608B00
0000796d027d0669  jmp 0x0000796D027CF501
0000796d027d066e  call 0x0000796D025FF430
0000796d027d0673  jmp 0x0000796D027CF514
0000796d027d0678  call 0x0000796D025FF430
0000796d027d067d  jmp 0x0000796D027CF527
0000796d027d0682  sub rsp, 0x08
0000796d027d0686  push rax
0000796d027d0687  push rcx
0000796d027d0688  push rdx
0000796d027d0689  push rdi
0000796d027d068a  push rsi
0000796d027d068b  push r8
0000796d027d068d  push r9
0000796d027d068f  push r10
0000796d027d0691  push r11
0000796d027d0693  sub rsp, 0xF0
0000796d027d069a  vmovaps [rsp], xmm0
0000796d027d069f  vmovaps [rsp+0x10], xmm2
0000796d027d06a5  vmovaps [rsp+0x20], xmm3
0000796d027d06ab  vmovaps [rsp+0x30], xmm4
0000796d027d06b1  vmovaps [rsp+0x40], xmm5
0000796d027d06b7  vmovaps [rsp+0x50], xmm6
0000796d027d06bd  vmovaps [rsp+0x60], xmm7
0000796d027d06c3  vmovaps [rsp+0x70], xmm8
0000796d027d06c9  vmovaps [rsp+0x80], xmm9
0000796d027d06d2  vmovaps [rsp+0x90], xmm10
0000796d027d06db  vmovaps [rsp+0xA0], xmm11
0000796d027d06e4  vmovaps [rsp+0xB0], xmm12
0000796d027d06ed  vmovaps [rsp+0xC0], xmm13
0000796d027d06f6  vmovaps [rsp+0xD0], xmm14
0000796d027d06ff  vmovaps [rsp+0xE0], xmm15
0000796d027d0708  sub rsp, 0x30
0000796d027d070c  movaps [rsp], xmm1
0000796d027d0710  movaps [rsp+0x10], xmm15
0000796d027d0716  movaps [rsp+0x20], xmm14
0000796d027d071c  lea rdi, [rsp]
0000796d027d0720  mov esi, 0x00
0000796d027d0725  mov rax, 0x635FBE957530
0000796d027d072f  call rax
0000796d027d0731  movaps xmm1, [rsp]
0000796d027d0735  add rsp, 0x30
0000796d027d0739  vmovaps xmm0, [rsp]
0000796d027d073e  vmovaps xmm2, [rsp+0x10]
0000796d027d0744  vmovaps xmm3, [rsp+0x20]
0000796d027d074a  vmovaps xmm4, [rsp+0x30]
0000796d027d0750  vmovaps xmm5, [rsp+0x40]
0000796d027d0756  vmovaps xmm6, [rsp+0x50]
0000796d027d075c  vmovaps xmm7, [rsp+0x60]
0000796d027d0762  vmovaps xmm8, [rsp+0x70]
0000796d027d0768  vmovaps xmm9, [rsp+0x80]
0000796d027d0771  vmovaps xmm10, [rsp+0x90]
0000796d027d077a  vmovaps xmm11, [rsp+0xA0]
0000796d027d0783  vmovaps xmm12, [rsp+0xB0]
0000796d027d078c  vmovaps xmm13, [rsp+0xC0]
0000796d027d0795  vmovaps xmm14, [rsp+0xD0]
0000796d027d079e  vmovaps xmm15, [rsp+0xE0]
0000796d027d07a7  add rsp, 0xF0
0000796d027d07ae  pop r11
0000796d027d07b0  pop r10
0000796d027d07b2  pop r9
0000796d027d07b4  pop r8
0000796d027d07b6  pop rsi
0000796d027d07b7  pop rdi
0000796d027d07b8  pop rdx
0000796d027d07b9  pop rcx
0000796d027d07ba  pop rax
0000796d027d07bb  add rsp, 0x08
0000796d027d07bf  jmp 0x0000796D027CF581
0000796d027d07c4  sub rsp, 0x08
0000796d027d07c8  push rax
0000796d027d07c9  push rcx
0000796d027d07ca  push rdx
0000796d027d07cb  push rdi
0000796d027d07cc  push rsi
0000796d027d07cd  push r8
0000796d027d07cf  push r9
0000796d027d07d1  push r10
0000796d027d07d3  push r11
0000796d027d07d5  sub rsp, 0xF0
0000796d027d07dc  vmovaps [rsp], xmm0
0000796d027d07e1  vmovaps [rsp+0x10], xmm1
0000796d027d07e7  vmovaps [rsp+0x20], xmm2
0000796d027d07ed  vmovaps [rsp+0x30], xmm3
0000796d027d07f3  vmovaps [rsp+0x40], xmm4
0000796d027d07f9  vmovaps [rsp+0x50], xmm5
0000796d027d07ff  vmovaps [rsp+0x60], xmm6
0000796d027d0805  vmovaps [rsp+0x70], xmm7
0000796d027d080b  vmovaps [rsp+0x80], xmm8
0000796d027d0814  vmovaps [rsp+0x90], xmm9
0000796d027d081d  vmovaps [rsp+0xA0], xmm10
0000796d027d0826  vmovaps [rsp+0xB0], xmm11
0000796d027d082f  vmovaps [rsp+0xC0], xmm12
0000796d027d0838  vmovaps [rsp+0xD0], xmm14
0000796d027d0841  vmovaps [rsp+0xE0], xmm15
0000796d027d084a  sub rsp, 0x30
0000796d027d084e  movaps [rsp], xmm13
0000796d027d0853  movaps [rsp+0x10], xmm1
0000796d027d0858  movaps [rsp+0x20], xmm14
0000796d027d085e  lea rdi, [rsp]
0000796d027d0862  mov esi, 0x00
0000796d027d0867  mov rax, 0x635FBE957530
0000796d027d0871  call rax
0000796d027d0873  movaps xmm13, [rsp]
0000796d027d0878  add rsp, 0x30
0000796d027d087c  vmovaps xmm0, [rsp]
0000796d027d0881  vmovaps xmm1, [rsp+0x10]
0000796d027d0887  vmovaps xmm2, [rsp+0x20]
0000796d027d088d  vmovaps xmm3, [rsp+0x30]
0000796d027d0893  vmovaps xmm4, [rsp+0x40]
0000796d027d0899  vmovaps xmm5, [rsp+0x50]
0000796d027d089f  vmovaps xmm6, [rsp+0x60]
0000796d027d08a5  vmovaps xmm7, [rsp+0x70]
0000796d027d08ab  vmovaps xmm8, [rsp+0x80]
0000796d027d08b4  vmovaps xmm9, [rsp+0x90]
0000796d027d08bd  vmovaps xmm10, [rsp+0xA0]
0000796d027d08c6  vmovaps xmm11, [rsp+0xB0]
0000796d027d08cf  vmovaps xmm12, [rsp+0xC0]
0000796d027d08d8  vmovaps xmm14, [rsp+0xD0]
0000796d027d08e1  vmovaps xmm15, [rsp+0xE0]
0000796d027d08ea  add rsp, 0xF0
0000796d027d08f1  pop r11
0000796d027d08f3  pop r10
0000796d027d08f5  pop r9
0000796d027d08f7  pop r8
0000796d027d08f9  pop rsi
0000796d027d08fa  pop rdi
0000796d027d08fb  pop rdx
0000796d027d08fc  pop rcx
0000796d027d08fd  pop rax
0000796d027d08fe  add rsp, 0x08
0000796d027d0902  jmp 0x0000796D027CF5CF
0000796d027d0907  sub rsp, 0x08
0000796d027d090b  push rax
0000796d027d090c  push rcx
0000796d027d090d  push rdx
0000796d027d090e  push rdi
0000796d027d090f  push rsi
0000796d027d0910  push r8
0000796d027d0912  push r9
0000796d027d0914  push r10
0000796d027d0916  push r11
0000796d027d0918  sub rsp, 0xF0
0000796d027d091f  vmovaps [rsp], xmm0
0000796d027d0924  vmovaps [rsp+0x10], xmm1
0000796d027d092a  vmovaps [rsp+0x20], xmm2
0000796d027d0930  vmovaps [rsp+0x30], xmm3
0000796d027d0936  vmovaps [rsp+0x40], xmm4
0000796d027d093c  vmovaps [rsp+0x50], xmm5
0000796d027d0942  vmovaps [rsp+0x60], xmm6
0000796d027d0948  vmovaps [rsp+0x70], xmm7
0000796d027d094e  vmovaps [rsp+0x80], xmm8
0000796d027d0957  vmovaps [rsp+0x90], xmm9
0000796d027d0960  vmovaps [rsp+0xA0], xmm10
0000796d027d0969  vmovaps [rsp+0xB0], xmm11
0000796d027d0972  vmovaps [rsp+0xC0], xmm12
0000796d027d097b  vmovaps [rsp+0xD0], xmm13
0000796d027d0984  vmovaps [rsp+0xE0], xmm14
0000796d027d098d  sub rsp, 0x30
0000796d027d0991  movaps [rsp], xmm15
0000796d027d0996  movaps [rsp+0x10], xmm14
0000796d027d099c  movaps [rsp+0x20], xmm1
0000796d027d09a1  lea rdi, [rsp]
0000796d027d09a5  mov esi, 0x00
0000796d027d09aa  mov rax, 0x635FBE957530
0000796d027d09b4  call rax
0000796d027d09b6  movaps xmm15, [rsp]
0000796d027d09bb  add rsp, 0x30
0000796d027d09bf  vmovaps xmm0, [rsp]
0000796d027d09c4  vmovaps xmm1, [rsp+0x10]
0000796d027d09ca  vmovaps xmm2, [rsp+0x20]
0000796d027d09d0  vmovaps xmm3, [rsp+0x30]
0000796d027d09d6  vmovaps xmm4, [rsp+0x40]
0000796d027d09dc  vmovaps xmm5, [rsp+0x50]
0000796d027d09e2  vmovaps xmm6, [rsp+0x60]
0000796d027d09e8  vmovaps xmm7, [rsp+0x70]
0000796d027d09ee  vmovaps xmm8, [rsp+0x80]
0000796d027d09f7  vmovaps xmm9, [rsp+0x90]
0000796d027d0a00  vmovaps xmm10, [rsp+0xA0]
0000796d027d0a09  vmovaps xmm11, [rsp+0xB0]
0000796d027d0a12  vmovaps xmm12, [rsp+0xC0]
0000796d027d0a1b  vmovaps xmm13, [rsp+0xD0]
0000796d027d0a24  vmovaps xmm14, [rsp+0xE0]
0000796d027d0a2d  add rsp, 0xF0
0000796d027d0a34  pop r11
0000796d027d0a36  pop r10
0000796d027d0a38  pop r9
0000796d027d0a3a  pop r8
0000796d027d0a3c  pop rsi
0000796d027d0a3d  pop rdi
0000796d027d0a3e  pop rdx
0000796d027d0a3f  pop rcx
0000796d027d0a40  pop rax
0000796d027d0a41  add rsp, 0x08
0000796d027d0a45  jmp 0x0000796D027CF617
0000796d027d0a4a  sub rsp, 0x08
0000796d027d0a4e  push rax
0000796d027d0a4f  push rcx
0000796d027d0a50  push rdx
0000796d027d0a51  push rdi
0000796d027d0a52  push rsi
0000796d027d0a53  push r8
0000796d027d0a55  push r9
0000796d027d0a57  push r10
0000796d027d0a59  push r11
0000796d027d0a5b  sub rsp, 0xF0
0000796d027d0a62  vmovaps [rsp], xmm0
0000796d027d0a67  vmovaps [rsp+0x10], xmm2
0000796d027d0a6d  vmovaps [rsp+0x20], xmm3
0000796d027d0a73  vmovaps [rsp+0x30], xmm4
0000796d027d0a79  vmovaps [rsp+0x40], xmm5
0000796d027d0a7f  vmovaps [rsp+0x50], xmm6
0000796d027d0a85  vmovaps [rsp+0x60], xmm7
0000796d027d0a8b  vmovaps [rsp+0x70], xmm8
0000796d027d0a91  vmovaps [rsp+0x80], xmm9
0000796d027d0a9a  vmovaps [rsp+0x90], xmm10
0000796d027d0aa3  vmovaps [rsp+0xA0], xmm11
0000796d027d0aac  vmovaps [rsp+0xB0], xmm12
0000796d027d0ab5  vmovaps [rsp+0xC0], xmm13
0000796d027d0abe  vmovaps [rsp+0xD0], xmm14
0000796d027d0ac7  vmovaps [rsp+0xE0], xmm15
0000796d027d0ad0  sub rsp, 0x30
0000796d027d0ad4  movaps [rsp], xmm1
0000796d027d0ad8  movaps [rsp+0x10], xmm14
0000796d027d0ade  movaps [rsp+0x20], xmm10
0000796d027d0ae4  lea rdi, [rsp]
0000796d027d0ae8  mov esi, 0x00
0000796d027d0aed  mov rax, 0x635FBE957530
0000796d027d0af7  call rax
0000796d027d0af9  movaps xmm1, [rsp]
0000796d027d0afd  add rsp, 0x30
0000796d027d0b01  vmovaps xmm0, [rsp]
0000796d027d0b06  vmovaps xmm2, [rsp+0x10]
0000796d027d0b0c  vmovaps xmm3, [rsp+0x20]
0000796d027d0b12  vmovaps xmm4, [rsp+0x30]
0000796d027d0b18  vmovaps xmm5, [rsp+0x40]
0000796d027d0b1e  vmovaps xmm6, [rsp+0x50]
0000796d027d0b24  vmovaps xmm7, [rsp+0x60]
0000796d027d0b2a  vmovaps xmm8, [rsp+0x70]
0000796d027d0b30  vmovaps xmm9, [rsp+0x80]
0000796d027d0b39  vmovaps xmm10, [rsp+0x90]
0000796d027d0b42  vmovaps xmm11, [rsp+0xA0]
0000796d027d0b4b  vmovaps xmm12, [rsp+0xB0]
0000796d027d0b54  vmovaps xmm13, [rsp+0xC0]
0000796d027d0b5d  vmovaps xmm14, [rsp+0xD0]
0000796d027d0b66  vmovaps xmm15, [rsp+0xE0]
0000796d027d0b6f  add rsp, 0xF0
0000796d027d0b76  pop r11
0000796d027d0b78  pop r10
0000796d027d0b7a  pop r9
0000796d027d0b7c  pop r8
0000796d027d0b7e  pop rsi
0000796d027d0b7f  pop rdi
0000796d027d0b80  pop rdx
0000796d027d0b81  pop rcx
0000796d027d0b82  pop rax
0000796d027d0b83  add rsp, 0x08
0000796d027d0b87  jmp 0x0000796D027CF631
0000796d027d0b8c  sub rsp, 0x08
0000796d027d0b90  push rax
0000796d027d0b91  push rcx
0000796d027d0b92  push rdx
0000796d027d0b93  push rdi
0000796d027d0b94  push rsi
0000796d027d0b95  push r8
0000796d027d0b97  push r9
0000796d027d0b99  push r10
0000796d027d0b9b  push r11
0000796d027d0b9d  sub rsp, 0xF0
0000796d027d0ba4  vmovaps [rsp], xmm0
0000796d027d0ba9  vmovaps [rsp+0x10], xmm1
0000796d027d0baf  vmovaps [rsp+0x20], xmm2
0000796d027d0bb5  vmovaps [rsp+0x30], xmm3
0000796d027d0bbb  vmovaps [rsp+0x40], xmm4
0000796d027d0bc1  vmovaps [rsp+0x50], xmm5
0000796d027d0bc7  vmovaps [rsp+0x60], xmm6
0000796d027d0bcd  vmovaps [rsp+0x70], xmm7
0000796d027d0bd3  vmovaps [rsp+0x80], xmm8
0000796d027d0bdc  vmovaps [rsp+0x90], xmm9
0000796d027d0be5  vmovaps [rsp+0xA0], xmm10
0000796d027d0bee  vmovaps [rsp+0xB0], xmm11
0000796d027d0bf7  vmovaps [rsp+0xC0], xmm12
0000796d027d0c00  vmovaps [rsp+0xD0], xmm14
0000796d027d0c09  vmovaps [rsp+0xE0], xmm15
0000796d027d0c12  sub rsp, 0x30
0000796d027d0c16  movaps [rsp], xmm13
0000796d027d0c1b  movaps [rsp+0x10], xmm14
0000796d027d0c21  movaps [rsp+0x20], xmm2
0000796d027d0c26  lea rdi, [rsp]
0000796d027d0c2a  mov esi, 0x00
0000796d027d0c2f  mov rax, 0x635FBE957530
0000796d027d0c39  call rax
0000796d027d0c3b  movaps xmm13, [rsp]
0000796d027d0c40  add rsp, 0x30
0000796d027d0c44  vmovaps xmm0, [rsp]
0000796d027d0c49  vmovaps xmm1, [rsp+0x10]
0000796d027d0c4f  vmovaps xmm2, [rsp+0x20]
0000796d027d0c55  vmovaps xmm3, [rsp+0x30]
0000796d027d0c5b  vmovaps xmm4, [rsp+0x40]
0000796d027d0c61  vmovaps xmm5, [rsp+0x50]
0000796d027d0c67  vmovaps xmm6, [rsp+0x60]
0000796d027d0c6d  vmovaps xmm7, [rsp+0x70]
0000796d027d0c73  vmovaps xmm8, [rsp+0x80]
0000796d027d0c7c  vmovaps xmm9, [rsp+0x90]
0000796d027d0c85  vmovaps xmm10, [rsp+0xA0]
0000796d027d0c8e  vmovaps xmm11, [rsp+0xB0]
0000796d027d0c97  vmovaps xmm12, [rsp+0xC0]
0000796d027d0ca0  vmovaps xmm14, [rsp+0xD0]
0000796d027d0ca9  vmovaps xmm15, [rsp+0xE0]
0000796d027d0cb2  add rsp, 0xF0
0000796d027d0cb9  pop r11
0000796d027d0cbb  pop r10
0000796d027d0cbd  pop r9
0000796d027d0cbf  pop r8
0000796d027d0cc1  pop rsi
0000796d027d0cc2  pop rdi
0000796d027d0cc3  pop rdx
0000796d027d0cc4  pop rcx
0000796d027d0cc5  pop rax
0000796d027d0cc6  add rsp, 0x08
0000796d027d0cca  jmp 0x0000796D027CF64C
0000796d027d0ccf  sub rsp, 0x08
0000796d027d0cd3  push rax
0000796d027d0cd4  push rcx
0000796d027d0cd5  push rdx
0000796d027d0cd6  push rdi
0000796d027d0cd7  push rsi
0000796d027d0cd8  push r8
0000796d027d0cda  push r9
0000796d027d0cdc  push r10
0000796d027d0cde  push r11
0000796d027d0ce0  sub rsp, 0xF0
0000796d027d0ce7  vmovaps [rsp], xmm0
0000796d027d0cec  vmovaps [rsp+0x10], xmm2
0000796d027d0cf2  vmovaps [rsp+0x20], xmm3
0000796d027d0cf8  vmovaps [rsp+0x30], xmm4
0000796d027d0cfe  vmovaps [rsp+0x40], xmm5
0000796d027d0d04  vmovaps [rsp+0x50], xmm6
0000796d027d0d0a  vmovaps [rsp+0x60], xmm7
0000796d027d0d10  vmovaps [rsp+0x70], xmm8
0000796d027d0d16  vmovaps [rsp+0x80], xmm9
0000796d027d0d1f  vmovaps [rsp+0x90], xmm10
0000796d027d0d28  vmovaps [rsp+0xA0], xmm11
0000796d027d0d31  vmovaps [rsp+0xB0], xmm12
0000796d027d0d3a  vmovaps [rsp+0xC0], xmm13
0000796d027d0d43  vmovaps [rsp+0xD0], xmm14
0000796d027d0d4c  vmovaps [rsp+0xE0], xmm15
0000796d027d0d55  sub rsp, 0x30
0000796d027d0d59  movaps [rsp], xmm1
0000796d027d0d5d  movaps [rsp+0x10], xmm10
0000796d027d0d63  movaps [rsp+0x20], xmm2
0000796d027d0d68  lea rdi, [rsp]
0000796d027d0d6c  mov esi, 0x00
0000796d027d0d71  mov rax, 0x635FBE957530
0000796d027d0d7b  call rax
0000796d027d0d7d  movaps xmm1, [rsp]
0000796d027d0d81  add rsp, 0x30
0000796d027d0d85  vmovaps xmm0, [rsp]
0000796d027d0d8a  vmovaps xmm2, [rsp+0x10]
0000796d027d0d90  vmovaps xmm3, [rsp+0x20]
0000796d027d0d96  vmovaps xmm4, [rsp+0x30]
0000796d027d0d9c  vmovaps xmm5, [rsp+0x40]
0000796d027d0da2  vmovaps xmm6, [rsp+0x50]
0000796d027d0da8  vmovaps xmm7, [rsp+0x60]
0000796d027d0dae  vmovaps xmm8, [rsp+0x70]
0000796d027d0db4  vmovaps xmm9, [rsp+0x80]
0000796d027d0dbd  vmovaps xmm10, [rsp+0x90]
0000796d027d0dc6  vmovaps xmm11, [rsp+0xA0]
0000796d027d0dcf  vmovaps xmm12, [rsp+0xB0]
0000796d027d0dd8  vmovaps xmm13, [rsp+0xC0]
0000796d027d0de1  vmovaps xmm14, [rsp+0xD0]
0000796d027d0dea  vmovaps xmm15, [rsp+0xE0]
0000796d027d0df3  add rsp, 0xF0
0000796d027d0dfa  pop r11
0000796d027d0dfc  pop r10
0000796d027d0dfe  pop r9
0000796d027d0e00  pop r8
0000796d027d0e02  pop rsi
0000796d027d0e03  pop rdi
0000796d027d0e04  pop rdx
0000796d027d0e05  pop rcx
0000796d027d0e06  pop rax
0000796d027d0e07  add rsp, 0x08
0000796d027d0e0b  jmp 0x0000796D027CF6B4
0000796d027d0e10  sub rsp, 0x08
0000796d027d0e14  push rax
0000796d027d0e15  push rcx
0000796d027d0e16  push rdx
0000796d027d0e17  push rdi
0000796d027d0e18  push rsi
0000796d027d0e19  push r8
0000796d027d0e1b  push r9
0000796d027d0e1d  push r10
0000796d027d0e1f  push r11
0000796d027d0e21  sub rsp, 0xF0
0000796d027d0e28  vmovaps [rsp], xmm0
0000796d027d0e2d  vmovaps [rsp+0x10], xmm1
0000796d027d0e33  vmovaps [rsp+0x20], xmm2
0000796d027d0e39  vmovaps [rsp+0x30], xmm3
0000796d027d0e3f  vmovaps [rsp+0x40], xmm4
0000796d027d0e45  vmovaps [rsp+0x50], xmm5
0000796d027d0e4b  vmovaps [rsp+0x60], xmm6
0000796d027d0e51  vmovaps [rsp+0x70], xmm7
0000796d027d0e57  vmovaps [rsp+0x80], xmm8
0000796d027d0e60  vmovaps [rsp+0x90], xmm9
0000796d027d0e69  vmovaps [rsp+0xA0], xmm10
0000796d027d0e72  vmovaps [rsp+0xB0], xmm11
0000796d027d0e7b  vmovaps [rsp+0xC0], xmm12
0000796d027d0e84  vmovaps [rsp+0xD0], xmm13
0000796d027d0e8d  vmovaps [rsp+0xE0], xmm14
0000796d027d0e96  sub rsp, 0x30
0000796d027d0e9a  movaps [rsp], xmm15
0000796d027d0e9f  movaps [rsp+0x10], xmm10
0000796d027d0ea5  movaps [rsp+0x20], xmm2
0000796d027d0eaa  lea rdi, [rsp]
0000796d027d0eae  mov esi, 0x00
0000796d027d0eb3  mov rax, 0x635FBE957530
0000796d027d0ebd  call rax
0000796d027d0ebf  movaps xmm15, [rsp]
0000796d027d0ec4  add rsp, 0x30
0000796d027d0ec8  vmovaps xmm0, [rsp]
0000796d027d0ecd  vmovaps xmm1, [rsp+0x10]
0000796d027d0ed3  vmovaps xmm2, [rsp+0x20]
0000796d027d0ed9  vmovaps xmm3, [rsp+0x30]
0000796d027d0edf  vmovaps xmm4, [rsp+0x40]
0000796d027d0ee5  vmovaps xmm5, [rsp+0x50]
0000796d027d0eeb  vmovaps xmm6, [rsp+0x60]
0000796d027d0ef1  vmovaps xmm7, [rsp+0x70]
0000796d027d0ef7  vmovaps xmm8, [rsp+0x80]
0000796d027d0f00  vmovaps xmm9, [rsp+0x90]
0000796d027d0f09  vmovaps xmm10, [rsp+0xA0]
0000796d027d0f12  vmovaps xmm11, [rsp+0xB0]
0000796d027d0f1b  vmovaps xmm12, [rsp+0xC0]
0000796d027d0f24  vmovaps xmm13, [rsp+0xD0]
0000796d027d0f2d  vmovaps xmm14, [rsp+0xE0]
0000796d027d0f36  add rsp, 0xF0
0000796d027d0f3d  pop r11
0000796d027d0f3f  pop r10
0000796d027d0f41  pop r9
0000796d027d0f43  pop r8
0000796d027d0f45  pop rsi
0000796d027d0f46  pop rdi
0000796d027d0f47  pop rdx
0000796d027d0f48  pop rcx
0000796d027d0f49  pop rax
0000796d027d0f4a  add rsp, 0x08
0000796d027d0f4e  jmp 0x0000796D027CF706
0000796d027d0f53  sub rsp, 0x08
0000796d027d0f57  push rax
0000796d027d0f58  push rcx
0000796d027d0f59  push rdx
0000796d027d0f5a  push rdi
0000796d027d0f5b  push rsi
0000796d027d0f5c  push r8
0000796d027d0f5e  push r9
0000796d027d0f60  push r10
0000796d027d0f62  push r11
0000796d027d0f64  sub rsp, 0xF0
0000796d027d0f6b  vmovaps [rsp], xmm0
0000796d027d0f70  vmovaps [rsp+0x10], xmm2
0000796d027d0f76  vmovaps [rsp+0x20], xmm3
0000796d027d0f7c  vmovaps [rsp+0x30], xmm4
0000796d027d0f82  vmovaps [rsp+0x40], xmm5
0000796d027d0f88  vmovaps [rsp+0x50], xmm6
0000796d027d0f8e  vmovaps [rsp+0x60], xmm7
0000796d027d0f94  vmovaps [rsp+0x70], xmm8
0000796d027d0f9a  vmovaps [rsp+0x80], xmm9
0000796d027d0fa3  vmovaps [rsp+0x90], xmm10
0000796d027d0fac  vmovaps [rsp+0xA0], xmm11
0000796d027d0fb5  vmovaps [rsp+0xB0], xmm12
0000796d027d0fbe  vmovaps [rsp+0xC0], xmm13
0000796d027d0fc7  vmovaps [rsp+0xD0], xmm14
0000796d027d0fd0  vmovaps [rsp+0xE0], xmm15
0000796d027d0fd9  sub rsp, 0x30
0000796d027d0fdd  movaps [rsp], xmm1
0000796d027d0fe1  movaps [rsp+0x10], xmm10
0000796d027d0fe7  movaps [rsp+0x20], xmm12
0000796d027d0fed  lea rdi, [rsp]
0000796d027d0ff1  mov esi, 0x00
0000796d027d0ff6  mov rax, 0x635FBE957530
0000796d027d1000  call rax
0000796d027d1002  movaps xmm1, [rsp]
0000796d027d1006  add rsp, 0x30
0000796d027d100a  vmovaps xmm0, [rsp]
0000796d027d100f  vmovaps xmm2, [rsp+0x10]
0000796d027d1015  vmovaps xmm3, [rsp+0x20]
0000796d027d101b  vmovaps xmm4, [rsp+0x30]
0000796d027d1021  vmovaps xmm5, [rsp+0x40]
0000796d027d1027  vmovaps xmm6, [rsp+0x50]
0000796d027d102d  vmovaps xmm7, [rsp+0x60]
0000796d027d1033  vmovaps xmm8, [rsp+0x70]
0000796d027d1039  vmovaps xmm9, [rsp+0x80]
0000796d027d1042  vmovaps xmm10, [rsp+0x90]
0000796d027d104b  vmovaps xmm11, [rsp+0xA0]
0000796d027d1054  vmovaps xmm12, [rsp+0xB0]
0000796d027d105d  vmovaps xmm13, [rsp+0xC0]
0000796d027d1066  vmovaps xmm14, [rsp+0xD0]
0000796d027d106f  vmovaps xmm15, [rsp+0xE0]
0000796d027d1078  add rsp, 0xF0
0000796d027d107f  pop r11
0000796d027d1081  pop r10
0000796d027d1083  pop r9
0000796d027d1085  pop r8
0000796d027d1087  pop rsi
0000796d027d1088  pop rdi
0000796d027d1089  pop rdx
0000796d027d108a  pop rcx
0000796d027d108b  pop rax
0000796d027d108c  add rsp, 0x08
0000796d027d1090  jmp 0x0000796D027CF732
0000796d027d1095  sub rsp, 0x08
0000796d027d1099  push rax
0000796d027d109a  push rcx
0000796d027d109b  push rdx
0000796d027d109c  push rdi
0000796d027d109d  push rsi
0000796d027d109e  push r8
0000796d027d10a0  push r9
0000796d027d10a2  push r10
0000796d027d10a4  push r11
0000796d027d10a6  sub rsp, 0xF0
0000796d027d10ad  vmovaps [rsp], xmm0
0000796d027d10b2  vmovaps [rsp+0x10], xmm1
0000796d027d10b8  vmovaps [rsp+0x20], xmm2
0000796d027d10be  vmovaps [rsp+0x30], xmm3
0000796d027d10c4  vmovaps [rsp+0x40], xmm4
0000796d027d10ca  vmovaps [rsp+0x50], xmm5
0000796d027d10d0  vmovaps [rsp+0x60], xmm6
0000796d027d10d6  vmovaps [rsp+0x70], xmm7
0000796d027d10dc  vmovaps [rsp+0x80], xmm8
0000796d027d10e5  vmovaps [rsp+0x90], xmm9
0000796d027d10ee  vmovaps [rsp+0xA0], xmm10
0000796d027d10f7  vmovaps [rsp+0xB0], xmm11
0000796d027d1100  vmovaps [rsp+0xC0], xmm12
0000796d027d1109  vmovaps [rsp+0xD0], xmm13
0000796d027d1112  vmovaps [rsp+0xE0], xmm14
0000796d027d111b  sub rsp, 0x30
0000796d027d111f  movaps [rsp], xmm15
0000796d027d1124  movaps [rsp+0x10], xmm10
0000796d027d112a  movaps [rsp+0x20], xmm12
0000796d027d1130  lea rdi, [rsp]
0000796d027d1134  mov esi, 0x00
0000796d027d1139  mov rax, 0x635FBE957530
0000796d027d1143  call rax
0000796d027d1145  movaps xmm15, [rsp]
0000796d027d114a  add rsp, 0x30
0000796d027d114e  vmovaps xmm0, [rsp]
0000796d027d1153  vmovaps xmm1, [rsp+0x10]
0000796d027d1159  vmovaps xmm2, [rsp+0x20]
0000796d027d115f  vmovaps xmm3, [rsp+0x30]
0000796d027d1165  vmovaps xmm4, [rsp+0x40]
0000796d027d116b  vmovaps xmm5, [rsp+0x50]
0000796d027d1171  vmovaps xmm6, [rsp+0x60]
0000796d027d1177  vmovaps xmm7, [rsp+0x70]
0000796d027d117d  vmovaps xmm8, [rsp+0x80]
0000796d027d1186  vmovaps xmm9, [rsp+0x90]
0000796d027d118f  vmovaps xmm10, [rsp+0xA0]
0000796d027d1198  vmovaps xmm11, [rsp+0xB0]
0000796d027d11a1  vmovaps xmm12, [rsp+0xC0]
0000796d027d11aa  vmovaps xmm13, [rsp+0xD0]
0000796d027d11b3  vmovaps xmm14, [rsp+0xE0]
0000796d027d11bc  add rsp, 0xF0
0000796d027d11c3  pop r11
0000796d027d11c5  pop r10
0000796d027d11c7  pop r9
0000796d027d11c9  pop r8
0000796d027d11cb  pop rsi
0000796d027d11cc  pop rdi
0000796d027d11cd  pop rdx
0000796d027d11ce  pop rcx
0000796d027d11cf  pop rax
0000796d027d11d0  add rsp, 0x08
0000796d027d11d4  jmp 0x0000796D027CF75E
0000796d027d11d9  call 0x0000796D025FF430
0000796d027d11de  jmp 0x0000796D027CF7EE
0000796d027d11e3  call 0x0000796D025FF430
0000796d027d11e8  jmp 0x0000796D027CF801
0000796d027d11ed  sub rsp, 0x08
0000796d027d11f1  push rax
0000796d027d11f2  push rcx
0000796d027d11f3  push rdx
0000796d027d11f4  push rdi
0000796d027d11f5  push rsi
0000796d027d11f6  push r8
0000796d027d11f8  push r9
0000796d027d11fa  push r10
0000796d027d11fc  push r11
0000796d027d11fe  sub rsp, 0xF0
0000796d027d1205  vmovaps [rsp], xmm0
0000796d027d120a  vmovaps [rsp+0x10], xmm2
0000796d027d1210  vmovaps [rsp+0x20], xmm3
0000796d027d1216  vmovaps [rsp+0x30], xmm4
0000796d027d121c  vmovaps [rsp+0x40], xmm5
0000796d027d1222  vmovaps [rsp+0x50], xmm6
0000796d027d1228  vmovaps [rsp+0x60], xmm7
0000796d027d122e  vmovaps [rsp+0x70], xmm8
0000796d027d1234  vmovaps [rsp+0x80], xmm9
0000796d027d123d  vmovaps [rsp+0x90], xmm10
0000796d027d1246  vmovaps [rsp+0xA0], xmm11
0000796d027d124f  vmovaps [rsp+0xB0], xmm12
0000796d027d1258  vmovaps [rsp+0xC0], xmm13
0000796d027d1261  vmovaps [rsp+0xD0], xmm14
0000796d027d126a  vmovaps [rsp+0xE0], xmm15
0000796d027d1273  sub rsp, 0x30
0000796d027d1277  movaps [rsp], xmm1
0000796d027d127b  movaps [rsp+0x10], xmm13
0000796d027d1281  movaps [rsp+0x20], xmm2
0000796d027d1286  lea rdi, [rsp]
0000796d027d128a  mov esi, 0x00
0000796d027d128f  mov rax, 0x635FBE957530
0000796d027d1299  call rax
0000796d027d129b  movaps xmm1, [rsp]
0000796d027d129f  add rsp, 0x30
0000796d027d12a3  vmovaps xmm0, [rsp]
0000796d027d12a8  vmovaps xmm2, [rsp+0x10]
0000796d027d12ae  vmovaps xmm3, [rsp+0x20]
0000796d027d12b4  vmovaps xmm4, [rsp+0x30]
0000796d027d12ba  vmovaps xmm5, [rsp+0x40]
0000796d027d12c0  vmovaps xmm6, [rsp+0x50]
0000796d027d12c6  vmovaps xmm7, [rsp+0x60]
0000796d027d12cc  vmovaps xmm8, [rsp+0x70]
0000796d027d12d2  vmovaps xmm9, [rsp+0x80]
0000796d027d12db  vmovaps xmm10, [rsp+0x90]
0000796d027d12e4  vmovaps xmm11, [rsp+0xA0]
0000796d027d12ed  vmovaps xmm12, [rsp+0xB0]
0000796d027d12f6  vmovaps xmm13, [rsp+0xC0]
0000796d027d12ff  vmovaps xmm14, [rsp+0xD0]
0000796d027d1308  vmovaps xmm15, [rsp+0xE0]
0000796d027d1311  add rsp, 0xF0
0000796d027d1318  pop r11
0000796d027d131a  pop r10
0000796d027d131c  pop r9
0000796d027d131e  pop r8
0000796d027d1320  pop rsi
0000796d027d1321  pop rdi
0000796d027d1322  pop rdx
0000796d027d1323  pop rcx
0000796d027d1324  pop rax
0000796d027d1325  add rsp, 0x08
0000796d027d1329  jmp 0x0000796D027CF82C
0000796d027d132e  call 0x0000796D0260E760
0000796d027d1333  jmp 0x0000796D027CF839
0000796d027d1338  sub rsp, 0x08
0000796d027d133c  push rax
0000796d027d133d  push rcx
0000796d027d133e  push rdx
0000796d027d133f  push rdi
0000796d027d1340  push rsi
0000796d027d1341  push r8
0000796d027d1343  push r9
0000796d027d1345  push r10
0000796d027d1347  push r11
0000796d027d1349  sub rsp, 0xF0
0000796d027d1350  vmovaps [rsp], xmm0
0000796d027d1355  vmovaps [rsp+0x10], xmm1
0000796d027d135b  vmovaps [rsp+0x20], xmm2
0000796d027d1361  vmovaps [rsp+0x30], xmm3
0000796d027d1367  vmovaps [rsp+0x40], xmm4
0000796d027d136d  vmovaps [rsp+0x50], xmm5
0000796d027d1373  vmovaps [rsp+0x60], xmm6
0000796d027d1379  vmovaps [rsp+0x70], xmm7
0000796d027d137f  vmovaps [rsp+0x80], xmm8
0000796d027d1388  vmovaps [rsp+0x90], xmm9
0000796d027d1391  vmovaps [rsp+0xA0], xmm10
0000796d027d139a  vmovaps [rsp+0xB0], xmm11
0000796d027d13a3  vmovaps [rsp+0xC0], xmm12
0000796d027d13ac  vmovaps [rsp+0xD0], xmm14
0000796d027d13b5  vmovaps [rsp+0xE0], xmm15
0000796d027d13be  sub rsp, 0x30
0000796d027d13c2  movaps [rsp], xmm13
0000796d027d13c7  movaps [rsp+0x10], xmm2
0000796d027d13cc  movaps [rsp+0x20], xmm1
0000796d027d13d1  lea rdi, [rsp]
0000796d027d13d5  mov esi, 0x00
0000796d027d13da  mov rax, 0x635FBE957530
0000796d027d13e4  call rax
0000796d027d13e6  movaps xmm13, [rsp]
0000796d027d13eb  add rsp, 0x30
0000796d027d13ef  vmovaps xmm0, [rsp]
0000796d027d13f4  vmovaps xmm1, [rsp+0x10]
0000796d027d13fa  vmovaps xmm2, [rsp+0x20]
0000796d027d1400  vmovaps xmm3, [rsp+0x30]
0000796d027d1406  vmovaps xmm4, [rsp+0x40]
0000796d027d140c  vmovaps xmm5, [rsp+0x50]
0000796d027d1412  vmovaps xmm6, [rsp+0x60]
0000796d027d1418  vmovaps xmm7, [rsp+0x70]
0000796d027d141e  vmovaps xmm8, [rsp+0x80]
0000796d027d1427  vmovaps xmm9, [rsp+0x90]
0000796d027d1430  vmovaps xmm10, [rsp+0xA0]
0000796d027d1439  vmovaps xmm11, [rsp+0xB0]
0000796d027d1442  vmovaps xmm12, [rsp+0xC0]
0000796d027d144b  vmovaps xmm14, [rsp+0xD0]
0000796d027d1454  vmovaps xmm15, [rsp+0xE0]
0000796d027d145d  add rsp, 0xF0
0000796d027d1464  pop r11
0000796d027d1466  pop r10
0000796d027d1468  pop r9
0000796d027d146a  pop r8
0000796d027d146c  pop rsi
0000796d027d146d  pop rdi
0000796d027d146e  pop rdx
0000796d027d146f  pop rcx
0000796d027d1470  pop rax
0000796d027d1471  add rsp, 0x08
0000796d027d1475  jmp 0x0000796D027CF878
0000796d027d147a  sub rsp, 0x08
0000796d027d147e  push rax
0000796d027d147f  push rcx
0000796d027d1480  push rdx
0000796d027d1481  push rdi
0000796d027d1482  push rsi
0000796d027d1483  push r8
0000796d027d1485  push r9
0000796d027d1487  push r10
0000796d027d1489  push r11
0000796d027d148b  sub rsp, 0xF0
0000796d027d1492  vmovaps [rsp], xmm0
0000796d027d1497  vmovaps [rsp+0x10], xmm2
0000796d027d149d  vmovaps [rsp+0x20], xmm3
0000796d027d14a3  vmovaps [rsp+0x30], xmm4
0000796d027d14a9  vmovaps [rsp+0x40], xmm5
0000796d027d14af  vmovaps [rsp+0x50], xmm6
0000796d027d14b5  vmovaps [rsp+0x60], xmm7
0000796d027d14bb  vmovaps [rsp+0x70], xmm8
0000796d027d14c1  vmovaps [rsp+0x80], xmm9
0000796d027d14ca  vmovaps [rsp+0x90], xmm10
0000796d027d14d3  vmovaps [rsp+0xA0], xmm11
0000796d027d14dc  vmovaps [rsp+0xB0], xmm12
0000796d027d14e5  vmovaps [rsp+0xC0], xmm13
0000796d027d14ee  vmovaps [rsp+0xD0], xmm14
0000796d027d14f7  vmovaps [rsp+0xE0], xmm15
0000796d027d1500  sub rsp, 0x30
0000796d027d1504  movaps [rsp], xmm1
0000796d027d1508  movaps [rsp+0x10], xmm15
0000796d027d150e  movaps [rsp+0x20], xmm2
0000796d027d1513  lea rdi, [rsp]
0000796d027d1517  mov esi, 0x00
0000796d027d151c  mov rax, 0x635FBE957530
0000796d027d1526  call rax
0000796d027d1528  movaps xmm1, [rsp]
0000796d027d152c  add rsp, 0x30
0000796d027d1530  vmovaps xmm0, [rsp]
0000796d027d1535  vmovaps xmm2, [rsp+0x10]
0000796d027d153b  vmovaps xmm3, [rsp+0x20]
0000796d027d1541  vmovaps xmm4, [rsp+0x30]
0000796d027d1547  vmovaps xmm5, [rsp+0x40]
0000796d027d154d  vmovaps xmm6, [rsp+0x50]
0000796d027d1553  vmovaps xmm7, [rsp+0x60]
0000796d027d1559  vmovaps xmm8, [rsp+0x70]
0000796d027d155f  vmovaps xmm9, [rsp+0x80]
0000796d027d1568  vmovaps xmm10, [rsp+0x90]
0000796d027d1571  vmovaps xmm11, [rsp+0xA0]
0000796d027d157a  vmovaps xmm12, [rsp+0xB0]
0000796d027d1583  vmovaps xmm13, [rsp+0xC0]
0000796d027d158c  vmovaps xmm14, [rsp+0xD0]
0000796d027d1595  vmovaps xmm15, [rsp+0xE0]
0000796d027d159e  add rsp, 0xF0
0000796d027d15a5  pop r11
0000796d027d15a7  pop r10
0000796d027d15a9  pop r9
0000796d027d15ab  pop r8
0000796d027d15ad  pop rsi
0000796d027d15ae  pop rdi
0000796d027d15af  pop rdx
0000796d027d15b0  pop rcx
0000796d027d15b1  pop rax
0000796d027d15b2  add rsp, 0x08
0000796d027d15b6  jmp 0x0000796D027CF8AC
0000796d027d15bb  sub rsp, 0x08
0000796d027d15bf  push rax
0000796d027d15c0  push rcx
0000796d027d15c1  push rdx
0000796d027d15c2  push rdi
0000796d027d15c3  push rsi
0000796d027d15c4  push r8
0000796d027d15c6  push r9
0000796d027d15c8  push r10
0000796d027d15ca  push r11
0000796d027d15cc  sub rsp, 0xF0
0000796d027d15d3  vmovaps [rsp], xmm0
0000796d027d15d8  vmovaps [rsp+0x10], xmm1
0000796d027d15de  vmovaps [rsp+0x20], xmm2
0000796d027d15e4  vmovaps [rsp+0x30], xmm3
0000796d027d15ea  vmovaps [rsp+0x40], xmm4
0000796d027d15f0  vmovaps [rsp+0x50], xmm5
0000796d027d15f6  vmovaps [rsp+0x60], xmm6
0000796d027d15fc  vmovaps [rsp+0x70], xmm7
0000796d027d1602  vmovaps [rsp+0x80], xmm8
0000796d027d160b  vmovaps [rsp+0x90], xmm9
0000796d027d1614  vmovaps [rsp+0xA0], xmm10
0000796d027d161d  vmovaps [rsp+0xB0], xmm11
0000796d027d1626  vmovaps [rsp+0xC0], xmm12
0000796d027d162f  vmovaps [rsp+0xD0], xmm13
0000796d027d1638  vmovaps [rsp+0xE0], xmm15
0000796d027d1641  sub rsp, 0x30
0000796d027d1645  movaps [rsp], xmm14
0000796d027d164a  movaps [rsp+0x10], xmm2
0000796d027d164f  movaps [rsp+0x20], xmm15
0000796d027d1655  lea rdi, [rsp]
0000796d027d1659  mov esi, 0x00
0000796d027d165e  mov rax, 0x635FBE957530
0000796d027d1668  call rax
0000796d027d166a  movaps xmm14, [rsp]
0000796d027d166f  add rsp, 0x30
0000796d027d1673  vmovaps xmm0, [rsp]
0000796d027d1678  vmovaps xmm1, [rsp+0x10]
0000796d027d167e  vmovaps xmm2, [rsp+0x20]
0000796d027d1684  vmovaps xmm3, [rsp+0x30]
0000796d027d168a  vmovaps xmm4, [rsp+0x40]
0000796d027d1690  vmovaps xmm5, [rsp+0x50]
0000796d027d1696  vmovaps xmm6, [rsp+0x60]
0000796d027d169c  vmovaps xmm7, [rsp+0x70]
0000796d027d16a2  vmovaps xmm8, [rsp+0x80]
0000796d027d16ab  vmovaps xmm9, [rsp+0x90]
0000796d027d16b4  vmovaps xmm10, [rsp+0xA0]
0000796d027d16bd  vmovaps xmm11, [rsp+0xB0]
0000796d027d16c6  vmovaps xmm12, [rsp+0xC0]
0000796d027d16cf  vmovaps xmm13, [rsp+0xD0]
0000796d027d16d8  vmovaps xmm15, [rsp+0xE0]
0000796d027d16e1  add rsp, 0xF0
0000796d027d16e8  pop r11
0000796d027d16ea  pop r10
0000796d027d16ec  pop r9
0000796d027d16ee  pop r8
0000796d027d16f0  pop rsi
0000796d027d16f1  pop rdi
0000796d027d16f2  pop rdx
0000796d027d16f3  pop rcx
0000796d027d16f4  pop rax
0000796d027d16f5  add rsp, 0x08
0000796d027d16f9  jmp 0x0000796D027CF8E7
0000796d027d16fe  sub rsp, 0x08
0000796d027d1702  push rax
0000796d027d1703  push rcx
0000796d027d1704  push rdx
0000796d027d1705  push rdi
0000796d027d1706  push rsi
0000796d027d1707  push r8
0000796d027d1709  push r9
0000796d027d170b  push r10
0000796d027d170d  push r11
0000796d027d170f  sub rsp, 0xF0
0000796d027d1716  vmovaps [rsp], xmm0
0000796d027d171b  vmovaps [rsp+0x10], xmm1
0000796d027d1721  vmovaps [rsp+0x20], xmm2
0000796d027d1727  vmovaps [rsp+0x30], xmm3
0000796d027d172d  vmovaps [rsp+0x40], xmm4
0000796d027d1733  vmovaps [rsp+0x50], xmm5
0000796d027d1739  vmovaps [rsp+0x60], xmm6
0000796d027d173f  vmovaps [rsp+0x70], xmm7
0000796d027d1745  vmovaps [rsp+0x80], xmm8
0000796d027d174e  vmovaps [rsp+0x90], xmm9
0000796d027d1757  vmovaps [rsp+0xA0], xmm10
0000796d027d1760  vmovaps [rsp+0xB0], xmm11
0000796d027d1769  vmovaps [rsp+0xC0], xmm12
0000796d027d1772  vmovaps [rsp+0xD0], xmm13
0000796d027d177b  vmovaps [rsp+0xE0], xmm14
0000796d027d1784  sub rsp, 0x30
0000796d027d1788  movaps [rsp], xmm15
0000796d027d178d  movaps [rsp+0x10], xmm2
0000796d027d1792  movaps [rsp+0x20], xmm1
0000796d027d1797  lea rdi, [rsp]
0000796d027d179b  mov esi, 0x00
0000796d027d17a0  mov rax, 0x635FBE957530
0000796d027d17aa  call rax
0000796d027d17ac  movaps xmm15, [rsp]
0000796d027d17b1  add rsp, 0x30
0000796d027d17b5  vmovaps xmm0, [rsp]
0000796d027d17ba  vmovaps xmm1, [rsp+0x10]
0000796d027d17c0  vmovaps xmm2, [rsp+0x20]
0000796d027d17c6  vmovaps xmm3, [rsp+0x30]
0000796d027d17cc  vmovaps xmm4, [rsp+0x40]
0000796d027d17d2  vmovaps xmm5, [rsp+0x50]
0000796d027d17d8  vmovaps xmm6, [rsp+0x60]
0000796d027d17de  vmovaps xmm7, [rsp+0x70]
0000796d027d17e4  vmovaps xmm8, [rsp+0x80]
0000796d027d17ed  vmovaps xmm9, [rsp+0x90]
0000796d027d17f6  vmovaps xmm10, [rsp+0xA0]
0000796d027d17ff  vmovaps xmm11, [rsp+0xB0]
0000796d027d1808  vmovaps xmm12, [rsp+0xC0]
0000796d027d1811  vmovaps xmm13, [rsp+0xD0]
0000796d027d181a  vmovaps xmm14, [rsp+0xE0]
0000796d027d1823  add rsp, 0xF0
0000796d027d182a  pop r11
0000796d027d182c  pop r10
0000796d027d182e  pop r9
0000796d027d1830  pop r8
0000796d027d1832  pop rsi
0000796d027d1833  pop rdi
0000796d027d1834  pop rdx
0000796d027d1835  pop rcx
0000796d027d1836  pop rax
0000796d027d1837  add rsp, 0x08
0000796d027d183b  jmp 0x0000796D027CF923
0000796d027d1840  call 0x0000796D025FF430
0000796d027d1845  jmp 0x0000796D027CF930
0000796d027d184a  sub rsp, 0x08
0000796d027d184e  push rax
0000796d027d184f  push rcx
0000796d027d1850  push rdx
0000796d027d1851  push rdi
0000796d027d1852  push rsi
0000796d027d1853  push r8
0000796d027d1855  push r9
0000796d027d1857  push r10
0000796d027d1859  push r11
0000796d027d185b  sub rsp, 0xF0
0000796d027d1862  vmovaps [rsp], xmm0
0000796d027d1867  vmovaps [rsp+0x10], xmm1
0000796d027d186d  vmovaps [rsp+0x20], xmm3
0000796d027d1873  vmovaps [rsp+0x30], xmm4
0000796d027d1879  vmovaps [rsp+0x40], xmm5
0000796d027d187f  vmovaps [rsp+0x50], xmm6
0000796d027d1885  vmovaps [rsp+0x60], xmm7
0000796d027d188b  vmovaps [rsp+0x70], xmm8
0000796d027d1891  vmovaps [rsp+0x80], xmm9
0000796d027d189a  vmovaps [rsp+0x90], xmm10
0000796d027d18a3  vmovaps [rsp+0xA0], xmm11
0000796d027d18ac  vmovaps [rsp+0xB0], xmm12
0000796d027d18b5  vmovaps [rsp+0xC0], xmm13
0000796d027d18be  vmovaps [rsp+0xD0], xmm14
0000796d027d18c7  vmovaps [rsp+0xE0], xmm15
0000796d027d18d0  sub rsp, 0x30
0000796d027d18d4  movaps [rsp], xmm2
0000796d027d18d8  movaps [rsp+0x10], xmm1
0000796d027d18dd  movaps [rsp+0x20], xmm14
0000796d027d18e3  lea rdi, [rsp]
0000796d027d18e7  mov esi, 0x00
0000796d027d18ec  mov rax, 0x635FBE957530
0000796d027d18f6  call rax
0000796d027d18f8  movaps xmm2, [rsp]
0000796d027d18fc  add rsp, 0x30
0000796d027d1900  vmovaps xmm0, [rsp]
0000796d027d1905  vmovaps xmm1, [rsp+0x10]
0000796d027d190b  vmovaps xmm3, [rsp+0x20]
0000796d027d1911  vmovaps xmm4, [rsp+0x30]
0000796d027d1917  vmovaps xmm5, [rsp+0x40]
0000796d027d191d  vmovaps xmm6, [rsp+0x50]
0000796d027d1923  vmovaps xmm7, [rsp+0x60]
0000796d027d1929  vmovaps xmm8, [rsp+0x70]
0000796d027d192f  vmovaps xmm9, [rsp+0x80]
0000796d027d1938  vmovaps xmm10, [rsp+0x90]
0000796d027d1941  vmovaps xmm11, [rsp+0xA0]
0000796d027d194a  vmovaps xmm12, [rsp+0xB0]
0000796d027d1953  vmovaps xmm13, [rsp+0xC0]
0000796d027d195c  vmovaps xmm14, [rsp+0xD0]
0000796d027d1965  vmovaps xmm15, [rsp+0xE0]
0000796d027d196e  add rsp, 0xF0
0000796d027d1975  pop r11
0000796d027d1977  pop r10
0000796d027d1979  pop r9
0000796d027d197b  pop r8
0000796d027d197d  pop rsi
0000796d027d197e  pop rdi
0000796d027d197f  pop rdx
0000796d027d1980  pop rcx
0000796d027d1981  pop rax
0000796d027d1982  add rsp, 0x08
0000796d027d1986  jmp 0x0000796D027CF96D
0000796d027d198b  sub rsp, 0x08
0000796d027d198f  push rax
0000796d027d1990  push rcx
0000796d027d1991  push rdx
0000796d027d1992  push rdi
0000796d027d1993  push rsi
0000796d027d1994  push r8
0000796d027d1996  push r9
0000796d027d1998  push r10
0000796d027d199a  push r11
0000796d027d199c  sub rsp, 0xF0
0000796d027d19a3  vmovaps [rsp], xmm0
0000796d027d19a8  vmovaps [rsp+0x10], xmm1
0000796d027d19ae  vmovaps [rsp+0x20], xmm2
0000796d027d19b4  vmovaps [rsp+0x30], xmm3
0000796d027d19ba  vmovaps [rsp+0x40], xmm4
0000796d027d19c0  vmovaps [rsp+0x50], xmm5
0000796d027d19c6  vmovaps [rsp+0x60], xmm6
0000796d027d19cc  vmovaps [rsp+0x70], xmm7
0000796d027d19d2  vmovaps [rsp+0x80], xmm8
0000796d027d19db  vmovaps [rsp+0x90], xmm9
0000796d027d19e4  vmovaps [rsp+0xA0], xmm10
0000796d027d19ed  vmovaps [rsp+0xB0], xmm11
0000796d027d19f6  vmovaps [rsp+0xC0], xmm12
0000796d027d19ff  vmovaps [rsp+0xD0], xmm13
0000796d027d1a08  vmovaps [rsp+0xE0], xmm14
0000796d027d1a11  sub rsp, 0x30
0000796d027d1a15  movaps [rsp], xmm15
0000796d027d1a1a  movaps [rsp+0x10], xmm14
0000796d027d1a20  movaps [rsp+0x20], xmm1
0000796d027d1a25  lea rdi, [rsp]
0000796d027d1a29  mov esi, 0x00
0000796d027d1a2e  mov rax, 0x635FBE957530
0000796d027d1a38  call rax
0000796d027d1a3a  movaps xmm15, [rsp]
0000796d027d1a3f  add rsp, 0x30
0000796d027d1a43  vmovaps xmm0, [rsp]
0000796d027d1a48  vmovaps xmm1, [rsp+0x10]
0000796d027d1a4e  vmovaps xmm2, [rsp+0x20]
0000796d027d1a54  vmovaps xmm3, [rsp+0x30]
0000796d027d1a5a  vmovaps xmm4, [rsp+0x40]
0000796d027d1a60  vmovaps xmm5, [rsp+0x50]
0000796d027d1a66  vmovaps xmm6, [rsp+0x60]
0000796d027d1a6c  vmovaps xmm7, [rsp+0x70]
0000796d027d1a72  vmovaps xmm8, [rsp+0x80]
0000796d027d1a7b  vmovaps xmm9, [rsp+0x90]
0000796d027d1a84  vmovaps xmm10, [rsp+0xA0]
0000796d027d1a8d  vmovaps xmm11, [rsp+0xB0]
0000796d027d1a96  vmovaps xmm12, [rsp+0xC0]
0000796d027d1a9f  vmovaps xmm13, [rsp+0xD0]
0000796d027d1aa8  vmovaps xmm14, [rsp+0xE0]
0000796d027d1ab1  add rsp, 0xF0
0000796d027d1ab8  pop r11
0000796d027d1aba  pop r10
0000796d027d1abc  pop r9
0000796d027d1abe  pop r8
0000796d027d1ac0  pop rsi
0000796d027d1ac1  pop rdi
0000796d027d1ac2  pop rdx
0000796d027d1ac3  pop rcx
0000796d027d1ac4  pop rax
0000796d027d1ac5  add rsp, 0x08
0000796d027d1ac9  jmp 0x0000796D027CF9E7
0000796d027d1ace  call 0x0000796D025FF430
0000796d027d1ad3  jmp 0x0000796D027CF9F4
0000796d027d1ad8  sub rsp, 0x08
0000796d027d1adc  push rax
0000796d027d1add  push rcx
0000796d027d1ade  push rdx
0000796d027d1adf  push rdi
0000796d027d1ae0  push rsi
0000796d027d1ae1  push r8
0000796d027d1ae3  push r9
0000796d027d1ae5  push r10
0000796d027d1ae7  push r11
0000796d027d1ae9  sub rsp, 0xF0
0000796d027d1af0  vmovaps [rsp], xmm0
0000796d027d1af5  vmovaps [rsp+0x10], xmm1
0000796d027d1afb  vmovaps [rsp+0x20], xmm2
0000796d027d1b01  vmovaps [rsp+0x30], xmm3
0000796d027d1b07  vmovaps [rsp+0x40], xmm4
0000796d027d1b0d  vmovaps [rsp+0x50], xmm5
0000796d027d1b13  vmovaps [rsp+0x60], xmm6
0000796d027d1b19  vmovaps [rsp+0x70], xmm7
0000796d027d1b1f  vmovaps [rsp+0x80], xmm8
0000796d027d1b28  vmovaps [rsp+0x90], xmm9
0000796d027d1b31  vmovaps [rsp+0xA0], xmm10
0000796d027d1b3a  vmovaps [rsp+0xB0], xmm11
0000796d027d1b43  vmovaps [rsp+0xC0], xmm12
0000796d027d1b4c  vmovaps [rsp+0xD0], xmm13
0000796d027d1b55  vmovaps [rsp+0xE0], xmm15
0000796d027d1b5e  sub rsp, 0x30
0000796d027d1b62  movaps [rsp], xmm14
0000796d027d1b67  movaps [rsp+0x10], xmm13
0000796d027d1b6d  movaps [rsp+0x20], xmm1
0000796d027d1b72  lea rdi, [rsp]
0000796d027d1b76  mov esi, 0x00
0000796d027d1b7b  mov rax, 0x635FBE957530
0000796d027d1b85  call rax
0000796d027d1b87  movaps xmm14, [rsp]
0000796d027d1b8c  add rsp, 0x30
0000796d027d1b90  vmovaps xmm0, [rsp]
0000796d027d1b95  vmovaps xmm1, [rsp+0x10]
0000796d027d1b9b  vmovaps xmm2, [rsp+0x20]
0000796d027d1ba1  vmovaps xmm3, [rsp+0x30]
0000796d027d1ba7  vmovaps xmm4, [rsp+0x40]
0000796d027d1bad  vmovaps xmm5, [rsp+0x50]
0000796d027d1bb3  vmovaps xmm6, [rsp+0x60]
0000796d027d1bb9  vmovaps xmm7, [rsp+0x70]
0000796d027d1bbf  vmovaps xmm8, [rsp+0x80]
0000796d027d1bc8  vmovaps xmm9, [rsp+0x90]
0000796d027d1bd1  vmovaps xmm10, [rsp+0xA0]
0000796d027d1bda  vmovaps xmm11, [rsp+0xB0]
0000796d027d1be3  vmovaps xmm12, [rsp+0xC0]
0000796d027d1bec  vmovaps xmm13, [rsp+0xD0]
0000796d027d1bf5  vmovaps xmm15, [rsp+0xE0]
0000796d027d1bfe  add rsp, 0xF0
0000796d027d1c05  pop r11
0000796d027d1c07  pop r10
0000796d027d1c09  pop r9
0000796d027d1c0b  pop r8
0000796d027d1c0d  pop rsi
0000796d027d1c0e  pop rdi
0000796d027d1c0f  pop rdx
0000796d027d1c10  pop rcx
0000796d027d1c11  pop rax
0000796d027d1c12  add rsp, 0x08
0000796d027d1c16  jmp 0x0000796D027CFAAF
0000796d027d1c1b  sub rsp, 0x08
0000796d027d1c1f  push rax
0000796d027d1c20  push rcx
0000796d027d1c21  push rdx
0000796d027d1c22  push rdi
0000796d027d1c23  push rsi
0000796d027d1c24  push r8
0000796d027d1c26  push r9
0000796d027d1c28  push r10
0000796d027d1c2a  push r11
0000796d027d1c2c  sub rsp, 0xF0
0000796d027d1c33  vmovaps [rsp], xmm0
0000796d027d1c38  vmovaps [rsp+0x10], xmm1
0000796d027d1c3e  vmovaps [rsp+0x20], xmm2
0000796d027d1c44  vmovaps [rsp+0x30], xmm3
0000796d027d1c4a  vmovaps [rsp+0x40], xmm4
0000796d027d1c50  vmovaps [rsp+0x50], xmm5
0000796d027d1c56  vmovaps [rsp+0x60], xmm6
0000796d027d1c5c  vmovaps [rsp+0x70], xmm7
0000796d027d1c62  vmovaps [rsp+0x80], xmm8
0000796d027d1c6b  vmovaps [rsp+0x90], xmm9
0000796d027d1c74  vmovaps [rsp+0xA0], xmm10
0000796d027d1c7d  vmovaps [rsp+0xB0], xmm11
0000796d027d1c86  vmovaps [rsp+0xC0], xmm12
0000796d027d1c8f  vmovaps [rsp+0xD0], xmm13
0000796d027d1c98  vmovaps [rsp+0xE0], xmm14
0000796d027d1ca1  sub rsp, 0x30
0000796d027d1ca5  movaps [rsp], xmm15
0000796d027d1caa  movaps [rsp+0x10], xmm13
0000796d027d1cb0  movaps [rsp+0x20], xmm1
0000796d027d1cb5  lea rdi, [rsp]
0000796d027d1cb9  mov esi, 0x00
0000796d027d1cbe  mov rax, 0x635FBE957530
0000796d027d1cc8  call rax
0000796d027d1cca  movaps xmm15, [rsp]
0000796d027d1ccf  add rsp, 0x30
0000796d027d1cd3  vmovaps xmm0, [rsp]
0000796d027d1cd8  vmovaps xmm1, [rsp+0x10]
0000796d027d1cde  vmovaps xmm2, [rsp+0x20]
0000796d027d1ce4  vmovaps xmm3, [rsp+0x30]
0000796d027d1cea  vmovaps xmm4, [rsp+0x40]
0000796d027d1cf0  vmovaps xmm5, [rsp+0x50]
0000796d027d1cf6  vmovaps xmm6, [rsp+0x60]
0000796d027d1cfc  vmovaps xmm7, [rsp+0x70]
0000796d027d1d02  vmovaps xmm8, [rsp+0x80]
0000796d027d1d0b  vmovaps xmm9, [rsp+0x90]
0000796d027d1d14  vmovaps xmm10, [rsp+0xA0]
0000796d027d1d1d  vmovaps xmm11, [rsp+0xB0]
0000796d027d1d26  vmovaps xmm12, [rsp+0xC0]
0000796d027d1d2f  vmovaps xmm13, [rsp+0xD0]
0000796d027d1d38  vmovaps xmm14, [rsp+0xE0]
0000796d027d1d41  add rsp, 0xF0
0000796d027d1d48  pop r11
0000796d027d1d4a  pop r10
0000796d027d1d4c  pop r9
0000796d027d1d4e  pop r8
0000796d027d1d50  pop rsi
0000796d027d1d51  pop rdi
0000796d027d1d52  pop rdx
0000796d027d1d53  pop rcx
0000796d027d1d54  pop rax
0000796d027d1d55  add rsp, 0x08
0000796d027d1d59  jmp 0x0000796D027CFAEB
0000796d027d1d5e  call 0x0000796D025FF430
0000796d027d1d63  jmp 0x0000796D027CFAF8
0000796d027d1d68  sub rsp, 0x08
0000796d027d1d6c  push rax
0000796d027d1d6d  push rcx
0000796d027d1d6e  push rdx
0000796d027d1d6f  push rdi
0000796d027d1d70  push rsi
0000796d027d1d71  push r8
0000796d027d1d73  push r9
0000796d027d1d75  push r10
0000796d027d1d77  push r11
0000796d027d1d79  sub rsp, 0xF0
0000796d027d1d80  vmovaps [rsp], xmm0
0000796d027d1d85  vmovaps [rsp+0x10], xmm1
0000796d027d1d8b  vmovaps [rsp+0x20], xmm2
0000796d027d1d91  vmovaps [rsp+0x30], xmm3
0000796d027d1d97  vmovaps [rsp+0x40], xmm4
0000796d027d1d9d  vmovaps [rsp+0x50], xmm5
0000796d027d1da3  vmovaps [rsp+0x60], xmm6
0000796d027d1da9  vmovaps [rsp+0x70], xmm7
0000796d027d1daf  vmovaps [rsp+0x80], xmm8
0000796d027d1db8  vmovaps [rsp+0x90], xmm9
0000796d027d1dc1  vmovaps [rsp+0xA0], xmm10
0000796d027d1dca  vmovaps [rsp+0xB0], xmm11
0000796d027d1dd3  vmovaps [rsp+0xC0], xmm12
0000796d027d1ddc  vmovaps [rsp+0xD0], xmm13
0000796d027d1de5  vmovaps [rsp+0xE0], xmm15
0000796d027d1dee  sub rsp, 0x30
0000796d027d1df2  movaps [rsp], xmm14
0000796d027d1df7  movaps [rsp+0x10], xmm13
0000796d027d1dfd  movaps [rsp+0x20], xmm2
0000796d027d1e02  lea rdi, [rsp]
0000796d027d1e06  mov esi, 0x00
0000796d027d1e0b  mov rax, 0x635FBE957530
0000796d027d1e15  call rax
0000796d027d1e17  movaps xmm14, [rsp]
0000796d027d1e1c  add rsp, 0x30
0000796d027d1e20  vmovaps xmm0, [rsp]
0000796d027d1e25  vmovaps xmm1, [rsp+0x10]
0000796d027d1e2b  vmovaps xmm2, [rsp+0x20]
0000796d027d1e31  vmovaps xmm3, [rsp+0x30]
0000796d027d1e37  vmovaps xmm4, [rsp+0x40]
0000796d027d1e3d  vmovaps xmm5, [rsp+0x50]
0000796d027d1e43  vmovaps xmm6, [rsp+0x60]
0000796d027d1e49  vmovaps xmm7, [rsp+0x70]
0000796d027d1e4f  vmovaps xmm8, [rsp+0x80]
0000796d027d1e58  vmovaps xmm9, [rsp+0x90]
0000796d027d1e61  vmovaps xmm10, [rsp+0xA0]
0000796d027d1e6a  vmovaps xmm11, [rsp+0xB0]
0000796d027d1e73  vmovaps xmm12, [rsp+0xC0]
0000796d027d1e7c  vmovaps xmm13, [rsp+0xD0]
0000796d027d1e85  vmovaps xmm15, [rsp+0xE0]
0000796d027d1e8e  add rsp, 0xF0
0000796d027d1e95  pop r11
0000796d027d1e97  pop r10
0000796d027d1e99  pop r9
0000796d027d1e9b  pop r8
0000796d027d1e9d  pop rsi
0000796d027d1e9e  pop rdi
0000796d027d1e9f  pop rdx
0000796d027d1ea0  pop rcx
0000796d027d1ea1  pop rax
0000796d027d1ea2  add rsp, 0x08
0000796d027d1ea6  jmp 0x0000796D027CFB24
0000796d027d1eab  sub rsp, 0x08
0000796d027d1eaf  push rax
0000796d027d1eb0  push rcx
0000796d027d1eb1  push rdx
0000796d027d1eb2  push rdi
0000796d027d1eb3  push rsi
0000796d027d1eb4  push r8
0000796d027d1eb6  push r9
0000796d027d1eb8  push r10
0000796d027d1eba  push r11
0000796d027d1ebc  sub rsp, 0xF0
0000796d027d1ec3  vmovaps [rsp], xmm0
0000796d027d1ec8  vmovaps [rsp+0x10], xmm2
0000796d027d1ece  vmovaps [rsp+0x20], xmm3
0000796d027d1ed4  vmovaps [rsp+0x30], xmm4
0000796d027d1eda  vmovaps [rsp+0x40], xmm5
0000796d027d1ee0  vmovaps [rsp+0x50], xmm6
0000796d027d1ee6  vmovaps [rsp+0x60], xmm7
0000796d027d1eec  vmovaps [rsp+0x70], xmm8
0000796d027d1ef2  vmovaps [rsp+0x80], xmm9
0000796d027d1efb  vmovaps [rsp+0x90], xmm10
0000796d027d1f04  vmovaps [rsp+0xA0], xmm11
0000796d027d1f0d  vmovaps [rsp+0xB0], xmm12
0000796d027d1f16  vmovaps [rsp+0xC0], xmm13
0000796d027d1f1f  vmovaps [rsp+0xD0], xmm14
0000796d027d1f28  vmovaps [rsp+0xE0], xmm15
0000796d027d1f31  sub rsp, 0x30
0000796d027d1f35  movaps [rsp], xmm1
0000796d027d1f39  movaps [rsp+0x10], xmm13
0000796d027d1f3f  movaps [rsp+0x20], xmm2
0000796d027d1f44  lea rdi, [rsp]
0000796d027d1f48  mov esi, 0x00
0000796d027d1f4d  mov rax, 0x635FBE957530
0000796d027d1f57  call rax
0000796d027d1f59  movaps xmm1, [rsp]
0000796d027d1f5d  add rsp, 0x30
0000796d027d1f61  vmovaps xmm0, [rsp]
0000796d027d1f66  vmovaps xmm2, [rsp+0x10]
0000796d027d1f6c  vmovaps xmm3, [rsp+0x20]
0000796d027d1f72  vmovaps xmm4, [rsp+0x30]
0000796d027d1f78  vmovaps xmm5, [rsp+0x40]
0000796d027d1f7e  vmovaps xmm6, [rsp+0x50]
0000796d027d1f84  vmovaps xmm7, [rsp+0x60]
0000796d027d1f8a  vmovaps xmm8, [rsp+0x70]
0000796d027d1f90  vmovaps xmm9, [rsp+0x80]
0000796d027d1f99  vmovaps xmm10, [rsp+0x90]
0000796d027d1fa2  vmovaps xmm11, [rsp+0xA0]
0000796d027d1fab  vmovaps xmm12, [rsp+0xB0]
0000796d027d1fb4  vmovaps xmm13, [rsp+0xC0]
0000796d027d1fbd  vmovaps xmm14, [rsp+0xD0]
0000796d027d1fc6  vmovaps xmm15, [rsp+0xE0]
0000796d027d1fcf  add rsp, 0xF0
0000796d027d1fd6  pop r11
0000796d027d1fd8  pop r10
0000796d027d1fda  pop r9
0000796d027d1fdc  pop r8
0000796d027d1fde  pop rsi
0000796d027d1fdf  pop rdi
0000796d027d1fe0  pop rdx
0000796d027d1fe1  pop rcx
0000796d027d1fe2  pop rax
0000796d027d1fe3  add rsp, 0x08
0000796d027d1fe7  jmp 0x0000796D027CFB52
0000796d027d1fec  sub rsp, 0x08
0000796d027d1ff0  push rax
0000796d027d1ff1  push rcx
0000796d027d1ff2  push rdx
0000796d027d1ff3  push rdi
0000796d027d1ff4  push rsi
0000796d027d1ff5  push r8
0000796d027d1ff7  push r9
0000796d027d1ff9  push r10
0000796d027d1ffb  push r11
0000796d027d1ffd  sub rsp, 0xF0
0000796d027d2004  vmovaps [rsp], xmm0
0000796d027d2009  vmovaps [rsp+0x10], xmm1
0000796d027d200f  vmovaps [rsp+0x20], xmm3
0000796d027d2015  vmovaps [rsp+0x30], xmm4
0000796d027d201b  vmovaps [rsp+0x40], xmm5
0000796d027d2021  vmovaps [rsp+0x50], xmm6
0000796d027d2027  vmovaps [rsp+0x60], xmm7
0000796d027d202d  vmovaps [rsp+0x70], xmm8
0000796d027d2033  vmovaps [rsp+0x80], xmm9
0000796d027d203c  vmovaps [rsp+0x90], xmm10
0000796d027d2045  vmovaps [rsp+0xA0], xmm11
0000796d027d204e  vmovaps [rsp+0xB0], xmm12
0000796d027d2057  vmovaps [rsp+0xC0], xmm13
0000796d027d2060  vmovaps [rsp+0xD0], xmm14
0000796d027d2069  vmovaps [rsp+0xE0], xmm15
0000796d027d2072  sub rsp, 0x30
0000796d027d2076  movaps [rsp], xmm2
0000796d027d207a  movaps [rsp+0x10], xmm1
0000796d027d207f  movaps [rsp+0x20], xmm13
0000796d027d2085  lea rdi, [rsp]
0000796d027d2089  mov esi, 0x00
0000796d027d208e  mov rax, 0x635FBE957530
0000796d027d2098  call rax
0000796d027d209a  movaps xmm2, [rsp]
0000796d027d209e  add rsp, 0x30
0000796d027d20a2  vmovaps xmm0, [rsp]
0000796d027d20a7  vmovaps xmm1, [rsp+0x10]
0000796d027d20ad  vmovaps xmm3, [rsp+0x20]
0000796d027d20b3  vmovaps xmm4, [rsp+0x30]
0000796d027d20b9  vmovaps xmm5, [rsp+0x40]
0000796d027d20bf  vmovaps xmm6, [rsp+0x50]
0000796d027d20c5  vmovaps xmm7, [rsp+0x60]
0000796d027d20cb  vmovaps xmm8, [rsp+0x70]
0000796d027d20d1  vmovaps xmm9, [rsp+0x80]
0000796d027d20da  vmovaps xmm10, [rsp+0x90]
0000796d027d20e3  vmovaps xmm11, [rsp+0xA0]
0000796d027d20ec  vmovaps xmm12, [rsp+0xB0]
0000796d027d20f5  vmovaps xmm13, [rsp+0xC0]
0000796d027d20fe  vmovaps xmm14, [rsp+0xD0]
0000796d027d2107  vmovaps xmm15, [rsp+0xE0]
0000796d027d2110  add rsp, 0xF0
0000796d027d2117  pop r11
0000796d027d2119  pop r10
0000796d027d211b  pop r9
0000796d027d211d  pop r8
0000796d027d211f  pop rsi
0000796d027d2120  pop rdi
0000796d027d2121  pop rdx
0000796d027d2122  pop rcx
0000796d027d2123  pop rax
0000796d027d2124  add rsp, 0x08
0000796d027d2128  jmp 0x0000796D027CFBAB
0000796d027d212d  call 0x0000796D025FF430
0000796d027d2132  jmp 0x0000796D027CFBB8
0000796d027d2137  sub rsp, 0x08
0000796d027d213b  push rax
0000796d027d213c  push rcx
0000796d027d213d  push rdx
0000796d027d213e  push rdi
0000796d027d213f  push rsi
0000796d027d2140  push r8
0000796d027d2142  push r9
0000796d027d2144  push r10
0000796d027d2146  push r11
0000796d027d2148  sub rsp, 0xF0
0000796d027d214f  vmovaps [rsp], xmm0
0000796d027d2154  vmovaps [rsp+0x10], xmm1
0000796d027d215a  vmovaps [rsp+0x20], xmm2
0000796d027d2160  vmovaps [rsp+0x30], xmm3
0000796d027d2166  vmovaps [rsp+0x40], xmm4
0000796d027d216c  vmovaps [rsp+0x50], xmm5
0000796d027d2172  vmovaps [rsp+0x60], xmm6
0000796d027d2178  vmovaps [rsp+0x70], xmm7
0000796d027d217e  vmovaps [rsp+0x80], xmm8
0000796d027d2187  vmovaps [rsp+0x90], xmm9
0000796d027d2190  vmovaps [rsp+0xA0], xmm10
0000796d027d2199  vmovaps [rsp+0xB0], xmm11
0000796d027d21a2  vmovaps [rsp+0xC0], xmm12
0000796d027d21ab  vmovaps [rsp+0xD0], xmm13
0000796d027d21b4  vmovaps [rsp+0xE0], xmm14
0000796d027d21bd  sub rsp, 0x30
0000796d027d21c1  movaps [rsp], xmm15
0000796d027d21c6  movaps [rsp+0x10], xmm13
0000796d027d21cc  movaps [rsp+0x20], xmm1
0000796d027d21d1  lea rdi, [rsp]
0000796d027d21d5  mov esi, 0x00
0000796d027d21da  mov rax, 0x635FBE957530
0000796d027d21e4  call rax
0000796d027d21e6  movaps xmm15, [rsp]
0000796d027d21eb  add rsp, 0x30
0000796d027d21ef  vmovaps xmm0, [rsp]
0000796d027d21f4  vmovaps xmm1, [rsp+0x10]
0000796d027d21fa  vmovaps xmm2, [rsp+0x20]
0000796d027d2200  vmovaps xmm3, [rsp+0x30]
0000796d027d2206  vmovaps xmm4, [rsp+0x40]
0000796d027d220c  vmovaps xmm5, [rsp+0x50]
0000796d027d2212  vmovaps xmm6, [rsp+0x60]
0000796d027d2218  vmovaps xmm7, [rsp+0x70]
0000796d027d221e  vmovaps xmm8, [rsp+0x80]
0000796d027d2227  vmovaps xmm9, [rsp+0x90]
0000796d027d2230  vmovaps xmm10, [rsp+0xA0]
0000796d027d2239  vmovaps xmm11, [rsp+0xB0]
0000796d027d2242  vmovaps xmm12, [rsp+0xC0]
0000796d027d224b  vmovaps xmm13, [rsp+0xD0]
0000796d027d2254  vmovaps xmm14, [rsp+0xE0]
0000796d027d225d  add rsp, 0xF0
0000796d027d2264  pop r11
0000796d027d2266  pop r10
0000796d027d2268  pop r9
0000796d027d226a  pop r8
0000796d027d226c  pop rsi
0000796d027d226d  pop rdi
0000796d027d226e  pop rdx
0000796d027d226f  pop rcx
0000796d027d2270  pop rax
0000796d027d2271  add rsp, 0x08
0000796d027d2275  jmp 0x0000796D027CFBF7
0000796d027d227a  sub rsp, 0x08
0000796d027d227e  push rax
0000796d027d227f  push rcx
0000796d027d2280  push rdx
0000796d027d2281  push rdi
0000796d027d2282  push rsi
0000796d027d2283  push r8
0000796d027d2285  push r9
0000796d027d2287  push r10
0000796d027d2289  push r11
0000796d027d228b  sub rsp, 0xF0
0000796d027d2292  vmovaps [rsp], xmm0
0000796d027d2297  vmovaps [rsp+0x10], xmm1
0000796d027d229d  vmovaps [rsp+0x20], xmm2
0000796d027d22a3  vmovaps [rsp+0x30], xmm3
0000796d027d22a9  vmovaps [rsp+0x40], xmm4
0000796d027d22af  vmovaps [rsp+0x50], xmm5
0000796d027d22b5  vmovaps [rsp+0x60], xmm6
0000796d027d22bb  vmovaps [rsp+0x70], xmm7
0000796d027d22c1  vmovaps [rsp+0x80], xmm8
0000796d027d22ca  vmovaps [rsp+0x90], xmm9
0000796d027d22d3  vmovaps [rsp+0xA0], xmm10
0000796d027d22dc  vmovaps [rsp+0xB0], xmm11
0000796d027d22e5  vmovaps [rsp+0xC0], xmm12
0000796d027d22ee  vmovaps [rsp+0xD0], xmm13
0000796d027d22f7  vmovaps [rsp+0xE0], xmm15
0000796d027d2300  sub rsp, 0x30
0000796d027d2304  movaps [rsp], xmm14
0000796d027d2309  movaps [rsp+0x10], xmm11
0000796d027d230f  movaps [rsp+0x20], xmm1
0000796d027d2314  lea rdi, [rsp]
0000796d027d2318  mov esi, 0x00
0000796d027d231d  mov rax, 0x635FBE957530
0000796d027d2327  call rax
0000796d027d2329  movaps xmm14, [rsp]
0000796d027d232e  add rsp, 0x30
0000796d027d2332  vmovaps xmm0, [rsp]
0000796d027d2337  vmovaps xmm1, [rsp+0x10]
0000796d027d233d  vmovaps xmm2, [rsp+0x20]
0000796d027d2343  vmovaps xmm3, [rsp+0x30]
0000796d027d2349  vmovaps xmm4, [rsp+0x40]
0000796d027d234f  vmovaps xmm5, [rsp+0x50]
0000796d027d2355  vmovaps xmm6, [rsp+0x60]
0000796d027d235b  vmovaps xmm7, [rsp+0x70]
0000796d027d2361  vmovaps xmm8, [rsp+0x80]
0000796d027d236a  vmovaps xmm9, [rsp+0x90]
0000796d027d2373  vmovaps xmm10, [rsp+0xA0]
0000796d027d237c  vmovaps xmm11, [rsp+0xB0]
0000796d027d2385  vmovaps xmm12, [rsp+0xC0]
0000796d027d238e  vmovaps xmm13, [rsp+0xD0]
0000796d027d2397  vmovaps xmm15, [rsp+0xE0]
0000796d027d23a0  add rsp, 0xF0
0000796d027d23a7  pop r11
0000796d027d23a9  pop r10
0000796d027d23ab  pop r9
0000796d027d23ad  pop r8
0000796d027d23af  pop rsi
0000796d027d23b0  pop rdi
0000796d027d23b1  pop rdx
0000796d027d23b2  pop rcx
0000796d027d23b3  pop rax
0000796d027d23b4  add rsp, 0x08
0000796d027d23b8  jmp 0x0000796D027CFC21
0000796d027d23bd  sub rsp, 0x08
0000796d027d23c1  push rax
0000796d027d23c2  push rcx
0000796d027d23c3  push rdx
0000796d027d23c4  push rdi
0000796d027d23c5  push rsi
0000796d027d23c6  push r8
0000796d027d23c8  push r9
0000796d027d23ca  push r10
0000796d027d23cc  push r11
0000796d027d23ce  sub rsp, 0xF0
0000796d027d23d5  vmovaps [rsp], xmm0
0000796d027d23da  vmovaps [rsp+0x10], xmm1
0000796d027d23e0  vmovaps [rsp+0x20], xmm2
0000796d027d23e6  vmovaps [rsp+0x30], xmm3
0000796d027d23ec  vmovaps [rsp+0x40], xmm4
0000796d027d23f2  vmovaps [rsp+0x50], xmm5
0000796d027d23f8  vmovaps [rsp+0x60], xmm6
0000796d027d23fe  vmovaps [rsp+0x70], xmm7
0000796d027d2404  vmovaps [rsp+0x80], xmm8
0000796d027d240d  vmovaps [rsp+0x90], xmm9
0000796d027d2416  vmovaps [rsp+0xA0], xmm10
0000796d027d241f  vmovaps [rsp+0xB0], xmm11
0000796d027d2428  vmovaps [rsp+0xC0], xmm12
0000796d027d2431  vmovaps [rsp+0xD0], xmm14
0000796d027d243a  vmovaps [rsp+0xE0], xmm15
0000796d027d2443  sub rsp, 0x30
0000796d027d2447  movaps [rsp], xmm13
0000796d027d244c  movaps [rsp+0x10], xmm11
0000796d027d2452  movaps [rsp+0x20], xmm1
0000796d027d2457  lea rdi, [rsp]
0000796d027d245b  mov esi, 0x00
0000796d027d2460  mov rax, 0x635FBE957530
0000796d027d246a  call rax
0000796d027d246c  movaps xmm13, [rsp]
0000796d027d2471  add rsp, 0x30
0000796d027d2475  vmovaps xmm0, [rsp]
0000796d027d247a  vmovaps xmm1, [rsp+0x10]
0000796d027d2480  vmovaps xmm2, [rsp+0x20]
0000796d027d2486  vmovaps xmm3, [rsp+0x30]
0000796d027d248c  vmovaps xmm4, [rsp+0x40]
0000796d027d2492  vmovaps xmm5, [rsp+0x50]
0000796d027d2498  vmovaps xmm6, [rsp+0x60]
0000796d027d249e  vmovaps xmm7, [rsp+0x70]
0000796d027d24a4  vmovaps xmm8, [rsp+0x80]
0000796d027d24ad  vmovaps xmm9, [rsp+0x90]
0000796d027d24b6  vmovaps xmm10, [rsp+0xA0]
0000796d027d24bf  vmovaps xmm11, [rsp+0xB0]
0000796d027d24c8  vmovaps xmm12, [rsp+0xC0]
0000796d027d24d1  vmovaps xmm14, [rsp+0xD0]
0000796d027d24da  vmovaps xmm15, [rsp+0xE0]
0000796d027d24e3  add rsp, 0xF0
0000796d027d24ea  pop r11
0000796d027d24ec  pop r10
0000796d027d24ee  pop r9
0000796d027d24f0  pop r8
0000796d027d24f2  pop rsi
0000796d027d24f3  pop rdi
0000796d027d24f4  pop rdx
0000796d027d24f5  pop rcx
0000796d027d24f6  pop rax
0000796d027d24f7  add rsp, 0x08
0000796d027d24fb  jmp 0x0000796D027CFC76
0000796d027d2500  call 0x0000796D025FF430
0000796d027d2505  jmp 0x0000796D027CFC83
0000796d027d250a  sub rsp, 0x08
0000796d027d250e  push rax
0000796d027d250f  push rcx
0000796d027d2510  push rdx
0000796d027d2511  push rdi
0000796d027d2512  push rsi
0000796d027d2513  push r8
0000796d027d2515  push r9
0000796d027d2517  push r10
0000796d027d2519  push r11
0000796d027d251b  sub rsp, 0xF0
0000796d027d2522  vmovaps [rsp], xmm0
0000796d027d2527  vmovaps [rsp+0x10], xmm1
0000796d027d252d  vmovaps [rsp+0x20], xmm2
0000796d027d2533  vmovaps [rsp+0x30], xmm3
0000796d027d2539  vmovaps [rsp+0x40], xmm4
0000796d027d253f  vmovaps [rsp+0x50], xmm5
0000796d027d2545  vmovaps [rsp+0x60], xmm6
0000796d027d254b  vmovaps [rsp+0x70], xmm7
0000796d027d2551  vmovaps [rsp+0x80], xmm8
0000796d027d255a  vmovaps [rsp+0x90], xmm9
0000796d027d2563  vmovaps [rsp+0xA0], xmm10
0000796d027d256c  vmovaps [rsp+0xB0], xmm11
0000796d027d2575  vmovaps [rsp+0xC0], xmm12
0000796d027d257e  vmovaps [rsp+0xD0], xmm13
0000796d027d2587  vmovaps [rsp+0xE0], xmm14
0000796d027d2590  sub rsp, 0x30
0000796d027d2594  movaps [rsp], xmm15
0000796d027d2599  movaps [rsp+0x10], xmm11
0000796d027d259f  movaps [rsp+0x20], xmm1
0000796d027d25a4  lea rdi, [rsp]
0000796d027d25a8  mov esi, 0x00
0000796d027d25ad  mov rax, 0x635FBE957530
0000796d027d25b7  call rax
0000796d027d25b9  movaps xmm15, [rsp]
0000796d027d25be  add rsp, 0x30
0000796d027d25c2  vmovaps xmm0, [rsp]
0000796d027d25c7  vmovaps xmm1, [rsp+0x10]
0000796d027d25cd  vmovaps xmm2, [rsp+0x20]
0000796d027d25d3  vmovaps xmm3, [rsp+0x30]
0000796d027d25d9  vmovaps xmm4, [rsp+0x40]
0000796d027d25df  vmovaps xmm5, [rsp+0x50]
0000796d027d25e5  vmovaps xmm6, [rsp+0x60]
0000796d027d25eb  vmovaps xmm7, [rsp+0x70]
0000796d027d25f1  vmovaps xmm8, [rsp+0x80]
0000796d027d25fa  vmovaps xmm9, [rsp+0x90]
0000796d027d2603  vmovaps xmm10, [rsp+0xA0]
0000796d027d260c  vmovaps xmm11, [rsp+0xB0]
0000796d027d2615  vmovaps xmm12, [rsp+0xC0]
0000796d027d261e  vmovaps xmm13, [rsp+0xD0]
0000796d027d2627  vmovaps xmm14, [rsp+0xE0]
0000796d027d2630  add rsp, 0xF0
0000796d027d2637  pop r11
0000796d027d2639  pop r10
0000796d027d263b  pop r9
0000796d027d263d  pop r8
0000796d027d263f  pop rsi
0000796d027d2640  pop rdi
0000796d027d2641  pop rdx
0000796d027d2642  pop rcx
0000796d027d2643  pop rax
0000796d027d2644  add rsp, 0x08
0000796d027d2648  jmp 0x0000796D027CFCBC
0000796d027d264d  sub rsp, 0x08
0000796d027d2651  push rax
0000796d027d2652  push rcx
0000796d027d2653  push rdx
0000796d027d2654  push rdi
0000796d027d2655  push rsi
0000796d027d2656  push r8
0000796d027d2658  push r9
0000796d027d265a  push r10
0000796d027d265c  push r11
0000796d027d265e  sub rsp, 0xF0
0000796d027d2665  vmovaps [rsp], xmm0
0000796d027d266a  vmovaps [rsp+0x10], xmm1
0000796d027d2670  vmovaps [rsp+0x20], xmm2
0000796d027d2676  vmovaps [rsp+0x30], xmm3
0000796d027d267c  vmovaps [rsp+0x40], xmm4
0000796d027d2682  vmovaps [rsp+0x50], xmm5
0000796d027d2688  vmovaps [rsp+0x60], xmm6
0000796d027d268e  vmovaps [rsp+0x70], xmm7
0000796d027d2694  vmovaps [rsp+0x80], xmm8
0000796d027d269d  vmovaps [rsp+0x90], xmm9
0000796d027d26a6  vmovaps [rsp+0xA0], xmm10
0000796d027d26af  vmovaps [rsp+0xB0], xmm12
0000796d027d26b8  vmovaps [rsp+0xC0], xmm13
0000796d027d26c1  vmovaps [rsp+0xD0], xmm14
0000796d027d26ca  vmovaps [rsp+0xE0], xmm15
0000796d027d26d3  sub rsp, 0x30
0000796d027d26d7  movaps [rsp], xmm11
0000796d027d26dc  movaps [rsp+0x10], xmm6
0000796d027d26e1  movaps [rsp+0x20], xmm14
0000796d027d26e7  lea rdi, [rsp]
0000796d027d26eb  mov esi, 0x00
0000796d027d26f0  mov rax, 0x635FBE957530
0000796d027d26fa  call rax
0000796d027d26fc  movaps xmm11, [rsp]
0000796d027d2701  add rsp, 0x30
0000796d027d2705  vmovaps xmm0, [rsp]
0000796d027d270a  vmovaps xmm1, [rsp+0x10]
0000796d027d2710  vmovaps xmm2, [rsp+0x20]
0000796d027d2716  vmovaps xmm3, [rsp+0x30]
0000796d027d271c  vmovaps xmm4, [rsp+0x40]
0000796d027d2722  vmovaps xmm5, [rsp+0x50]
0000796d027d2728  vmovaps xmm6, [rsp+0x60]
0000796d027d272e  vmovaps xmm7, [rsp+0x70]
0000796d027d2734  vmovaps xmm8, [rsp+0x80]
0000796d027d273d  vmovaps xmm9, [rsp+0x90]
0000796d027d2746  vmovaps xmm10, [rsp+0xA0]
0000796d027d274f  vmovaps xmm12, [rsp+0xB0]
0000796d027d2758  vmovaps xmm13, [rsp+0xC0]
0000796d027d2761  vmovaps xmm14, [rsp+0xD0]
0000796d027d276a  vmovaps xmm15, [rsp+0xE0]
0000796d027d2773  add rsp, 0xF0
0000796d027d277a  pop r11
0000796d027d277c  pop r10
0000796d027d277e  pop r9
0000796d027d2780  pop r8
0000796d027d2782  pop rsi
0000796d027d2783  pop rdi
0000796d027d2784  pop rdx
0000796d027d2785  pop rcx
0000796d027d2786  pop rax
0000796d027d2787  add rsp, 0x08
0000796d027d278b  jmp 0x0000796D027CFD34
0000796d027d2790  call 0x0000796D025FF430
0000796d027d2795  jmp 0x0000796D027CFD3E
0000796d027d279a  sub rsp, 0x08
0000796d027d279e  push rax
0000796d027d279f  push rcx
0000796d027d27a0  push rdx
0000796d027d27a1  push rdi
0000796d027d27a2  push rsi
0000796d027d27a3  push r8
0000796d027d27a5  push r9
0000796d027d27a7  push r10
0000796d027d27a9  push r11
0000796d027d27ab  sub rsp, 0xF0
0000796d027d27b2  vmovaps [rsp], xmm0
0000796d027d27b7  vmovaps [rsp+0x10], xmm1
0000796d027d27bd  vmovaps [rsp+0x20], xmm2
0000796d027d27c3  vmovaps [rsp+0x30], xmm3
0000796d027d27c9  vmovaps [rsp+0x40], xmm4
0000796d027d27cf  vmovaps [rsp+0x50], xmm5
0000796d027d27d5  vmovaps [rsp+0x60], xmm6
0000796d027d27db  vmovaps [rsp+0x70], xmm7
0000796d027d27e1  vmovaps [rsp+0x80], xmm8
0000796d027d27ea  vmovaps [rsp+0x90], xmm9
0000796d027d27f3  vmovaps [rsp+0xA0], xmm10
0000796d027d27fc  vmovaps [rsp+0xB0], xmm11
0000796d027d2805  vmovaps [rsp+0xC0], xmm12
0000796d027d280e  vmovaps [rsp+0xD0], xmm13
0000796d027d2817  vmovaps [rsp+0xE0], xmm15
0000796d027d2820  sub rsp, 0x30
0000796d027d2824  movaps [rsp], xmm14
0000796d027d2829  movaps [rsp+0x10], xmm6
0000796d027d282e  movaps [rsp+0x20], xmm2
0000796d027d2833  lea rdi, [rsp]
0000796d027d2837  mov esi, 0x00
0000796d027d283c  mov rax, 0x635FBE957530
0000796d027d2846  call rax
0000796d027d2848  movaps xmm14, [rsp]
0000796d027d284d  add rsp, 0x30
0000796d027d2851  vmovaps xmm0, [rsp]
0000796d027d2856  vmovaps xmm1, [rsp+0x10]
0000796d027d285c  vmovaps xmm2, [rsp+0x20]
0000796d027d2862  vmovaps xmm3, [rsp+0x30]
0000796d027d2868  vmovaps xmm4, [rsp+0x40]
0000796d027d286e  vmovaps xmm5, [rsp+0x50]
0000796d027d2874  vmovaps xmm6, [rsp+0x60]
0000796d027d287a  vmovaps xmm7, [rsp+0x70]
0000796d027d2880  vmovaps xmm8, [rsp+0x80]
0000796d027d2889  vmovaps xmm9, [rsp+0x90]
0000796d027d2892  vmovaps xmm10, [rsp+0xA0]
0000796d027d289b  vmovaps xmm11, [rsp+0xB0]
0000796d027d28a4  vmovaps xmm12, [rsp+0xC0]
0000796d027d28ad  vmovaps xmm13, [rsp+0xD0]
0000796d027d28b6  vmovaps xmm15, [rsp+0xE0]
0000796d027d28bf  add rsp, 0xF0
0000796d027d28c6  pop r11
0000796d027d28c8  pop r10
0000796d027d28ca  pop r9
0000796d027d28cc  pop r8
0000796d027d28ce  pop rsi
0000796d027d28cf  pop rdi
0000796d027d28d0  pop rdx
0000796d027d28d1  pop rcx
0000796d027d28d2  pop rax
0000796d027d28d3  add rsp, 0x08
0000796d027d28d7  jmp 0x0000796D027CFD72
0000796d027d28dc  sub rsp, 0x08
0000796d027d28e0  push rax
0000796d027d28e1  push rcx
0000796d027d28e2  push rdx
0000796d027d28e3  push rdi
0000796d027d28e4  push rsi
0000796d027d28e5  push r8
0000796d027d28e7  push r9
0000796d027d28e9  push r10
0000796d027d28eb  push r11
0000796d027d28ed  sub rsp, 0xF0
0000796d027d28f4  vmovaps [rsp], xmm0
0000796d027d28f9  vmovaps [rsp+0x10], xmm1
0000796d027d28ff  vmovaps [rsp+0x20], xmm2
0000796d027d2905  vmovaps [rsp+0x30], xmm3
0000796d027d290b  vmovaps [rsp+0x40], xmm4
0000796d027d2911  vmovaps [rsp+0x50], xmm5
0000796d027d2917  vmovaps [rsp+0x60], xmm7
0000796d027d291d  vmovaps [rsp+0x70], xmm8
0000796d027d2923  vmovaps [rsp+0x80], xmm9
0000796d027d292c  vmovaps [rsp+0x90], xmm10
0000796d027d2935  vmovaps [rsp+0xA0], xmm11
0000796d027d293e  vmovaps [rsp+0xB0], xmm12
0000796d027d2947  vmovaps [rsp+0xC0], xmm13
0000796d027d2950  vmovaps [rsp+0xD0], xmm14
0000796d027d2959  vmovaps [rsp+0xE0], xmm15
0000796d027d2962  sub rsp, 0x30
0000796d027d2966  movaps [rsp], xmm6
0000796d027d296a  movaps [rsp+0x10], xmm5
0000796d027d296f  movaps [rsp+0x20], xmm1
0000796d027d2974  lea rdi, [rsp]
0000796d027d2978  mov esi, 0x00
0000796d027d297d  mov rax, 0x635FBE957530
0000796d027d2987  call rax
0000796d027d2989  movaps xmm6, [rsp]
0000796d027d298d  add rsp, 0x30
0000796d027d2991  vmovaps xmm0, [rsp]
0000796d027d2996  vmovaps xmm1, [rsp+0x10]
0000796d027d299c  vmovaps xmm2, [rsp+0x20]
0000796d027d29a2  vmovaps xmm3, [rsp+0x30]
0000796d027d29a8  vmovaps xmm4, [rsp+0x40]
0000796d027d29ae  vmovaps xmm5, [rsp+0x50]
0000796d027d29b4  vmovaps xmm7, [rsp+0x60]
0000796d027d29ba  vmovaps xmm8, [rsp+0x70]
0000796d027d29c0  vmovaps xmm9, [rsp+0x80]
0000796d027d29c9  vmovaps xmm10, [rsp+0x90]
0000796d027d29d2  vmovaps xmm11, [rsp+0xA0]
0000796d027d29db  vmovaps xmm12, [rsp+0xB0]
0000796d027d29e4  vmovaps xmm13, [rsp+0xC0]
0000796d027d29ed  vmovaps xmm14, [rsp+0xD0]
0000796d027d29f6  vmovaps xmm15, [rsp+0xE0]
0000796d027d29ff  add rsp, 0xF0
0000796d027d2a06  pop r11
0000796d027d2a08  pop r10
0000796d027d2a0a  pop r9
0000796d027d2a0c  pop r8
0000796d027d2a0e  pop rsi
0000796d027d2a0f  pop rdi
0000796d027d2a10  pop rdx
0000796d027d2a11  pop rcx
0000796d027d2a12  pop rax
0000796d027d2a13  add rsp, 0x08
0000796d027d2a17  jmp 0x0000796D027CFD98
0000796d027d2a1c  sub rsp, 0x08
0000796d027d2a20  push rax
0000796d027d2a21  push rcx
0000796d027d2a22  push rdx
0000796d027d2a23  push rdi
0000796d027d2a24  push rsi
0000796d027d2a25  push r8
0000796d027d2a27  push r9
0000796d027d2a29  push r10
0000796d027d2a2b  push r11
0000796d027d2a2d  sub rsp, 0xF0
0000796d027d2a34  vmovaps [rsp], xmm0
0000796d027d2a39  vmovaps [rsp+0x10], xmm2
0000796d027d2a3f  vmovaps [rsp+0x20], xmm3
0000796d027d2a45  vmovaps [rsp+0x30], xmm4
0000796d027d2a4b  vmovaps [rsp+0x40], xmm5
0000796d027d2a51  vmovaps [rsp+0x50], xmm6
0000796d027d2a57  vmovaps [rsp+0x60], xmm7
0000796d027d2a5d  vmovaps [rsp+0x70], xmm8
0000796d027d2a63  vmovaps [rsp+0x80], xmm9
0000796d027d2a6c  vmovaps [rsp+0x90], xmm10
0000796d027d2a75  vmovaps [rsp+0xA0], xmm11
0000796d027d2a7e  vmovaps [rsp+0xB0], xmm12
0000796d027d2a87  vmovaps [rsp+0xC0], xmm13
0000796d027d2a90  vmovaps [rsp+0xD0], xmm14
0000796d027d2a99  vmovaps [rsp+0xE0], xmm15
0000796d027d2aa2  sub rsp, 0x30
0000796d027d2aa6  movaps [rsp], xmm1
0000796d027d2aaa  movaps [rsp+0x10], xmm5
0000796d027d2aaf  movaps [rsp+0x20], xmm13
0000796d027d2ab5  lea rdi, [rsp]
0000796d027d2ab9  mov esi, 0x00
0000796d027d2abe  mov rax, 0x635FBE957530
0000796d027d2ac8  call rax
0000796d027d2aca  movaps xmm1, [rsp]
0000796d027d2ace  add rsp, 0x30
0000796d027d2ad2  vmovaps xmm0, [rsp]
0000796d027d2ad7  vmovaps xmm2, [rsp+0x10]
0000796d027d2add  vmovaps xmm3, [rsp+0x20]
0000796d027d2ae3  vmovaps xmm4, [rsp+0x30]
0000796d027d2ae9  vmovaps xmm5, [rsp+0x40]
0000796d027d2aef  vmovaps xmm6, [rsp+0x50]
0000796d027d2af5  vmovaps xmm7, [rsp+0x60]
0000796d027d2afb  vmovaps xmm8, [rsp+0x70]
0000796d027d2b01  vmovaps xmm9, [rsp+0x80]
0000796d027d2b0a  vmovaps xmm10, [rsp+0x90]
0000796d027d2b13  vmovaps xmm11, [rsp+0xA0]
0000796d027d2b1c  vmovaps xmm12, [rsp+0xB0]
0000796d027d2b25  vmovaps xmm13, [rsp+0xC0]
0000796d027d2b2e  vmovaps xmm14, [rsp+0xD0]
0000796d027d2b37  vmovaps xmm15, [rsp+0xE0]
0000796d027d2b40  add rsp, 0xF0
0000796d027d2b47  pop r11
0000796d027d2b49  pop r10
0000796d027d2b4b  pop r9
0000796d027d2b4d  pop r8
0000796d027d2b4f  pop rsi
0000796d027d2b50  pop rdi
0000796d027d2b51  pop rdx
0000796d027d2b52  pop rcx
0000796d027d2b53  pop rax
0000796d027d2b54  add rsp, 0x08
0000796d027d2b58  jmp 0x0000796D027CFDB6
0000796d027d2b5d  sub rsp, 0x08
0000796d027d2b61  push rax
0000796d027d2b62  push rcx
0000796d027d2b63  push rdx
0000796d027d2b64  push rdi
0000796d027d2b65  push rsi
0000796d027d2b66  push r8
0000796d027d2b68  push r9
0000796d027d2b6a  push r10
0000796d027d2b6c  push r11
0000796d027d2b6e  sub rsp, 0xF0
0000796d027d2b75  vmovaps [rsp], xmm0
0000796d027d2b7a  vmovaps [rsp+0x10], xmm1
0000796d027d2b80  vmovaps [rsp+0x20], xmm2
0000796d027d2b86  vmovaps [rsp+0x30], xmm3
0000796d027d2b8c  vmovaps [rsp+0x40], xmm4
0000796d027d2b92  vmovaps [rsp+0x50], xmm6
0000796d027d2b98  vmovaps [rsp+0x60], xmm7
0000796d027d2b9e  vmovaps [rsp+0x70], xmm8
0000796d027d2ba4  vmovaps [rsp+0x80], xmm9
0000796d027d2bad  vmovaps [rsp+0x90], xmm10
0000796d027d2bb6  vmovaps [rsp+0xA0], xmm11
0000796d027d2bbf  vmovaps [rsp+0xB0], xmm12
0000796d027d2bc8  vmovaps [rsp+0xC0], xmm13
0000796d027d2bd1  vmovaps [rsp+0xD0], xmm14
0000796d027d2bda  vmovaps [rsp+0xE0], xmm15
0000796d027d2be3  sub rsp, 0x30
0000796d027d2be7  movaps [rsp], xmm5
0000796d027d2beb  movaps [rsp+0x10], xmm2
0000796d027d2bf0  movaps [rsp+0x20], xmm13
0000796d027d2bf6  lea rdi, [rsp]
0000796d027d2bfa  mov esi, 0x00
0000796d027d2bff  mov rax, 0x635FBE957530
0000796d027d2c09  call rax
0000796d027d2c0b  movaps xmm5, [rsp]
0000796d027d2c0f  add rsp, 0x30
0000796d027d2c13  vmovaps xmm0, [rsp]
0000796d027d2c18  vmovaps xmm1, [rsp+0x10]
0000796d027d2c1e  vmovaps xmm2, [rsp+0x20]
0000796d027d2c24  vmovaps xmm3, [rsp+0x30]
0000796d027d2c2a  vmovaps xmm4, [rsp+0x40]
0000796d027d2c30  vmovaps xmm6, [rsp+0x50]
0000796d027d2c36  vmovaps xmm7, [rsp+0x60]
0000796d027d2c3c  vmovaps xmm8, [rsp+0x70]
0000796d027d2c42  vmovaps xmm9, [rsp+0x80]
0000796d027d2c4b  vmovaps xmm10, [rsp+0x90]
0000796d027d2c54  vmovaps xmm11, [rsp+0xA0]
0000796d027d2c5d  vmovaps xmm12, [rsp+0xB0]
0000796d027d2c66  vmovaps xmm13, [rsp+0xC0]
0000796d027d2c6f  vmovaps xmm14, [rsp+0xD0]
0000796d027d2c78  vmovaps xmm15, [rsp+0xE0]
0000796d027d2c81  add rsp, 0xF0
0000796d027d2c88  pop r11
0000796d027d2c8a  pop r10
0000796d027d2c8c  pop r9
0000796d027d2c8e  pop r8
0000796d027d2c90  pop rsi
0000796d027d2c91  pop rdi
0000796d027d2c92  pop rdx
0000796d027d2c93  pop rcx
0000796d027d2c94  pop rax
0000796d027d2c95  add rsp, 0x08
0000796d027d2c99  jmp 0x0000796D027CFDEC
0000796d027d2c9e  sub rsp, 0x08
0000796d027d2ca2  push rax
0000796d027d2ca3  push rcx
0000796d027d2ca4  push rdx
0000796d027d2ca5  push rdi
0000796d027d2ca6  push rsi
0000796d027d2ca7  push r8
0000796d027d2ca9  push r9
0000796d027d2cab  push r10
0000796d027d2cad  push r11
0000796d027d2caf  sub rsp, 0xF0
0000796d027d2cb6  vmovaps [rsp], xmm0
0000796d027d2cbb  vmovaps [rsp+0x10], xmm1
0000796d027d2cc1  vmovaps [rsp+0x20], xmm2
0000796d027d2cc7  vmovaps [rsp+0x30], xmm3
0000796d027d2ccd  vmovaps [rsp+0x40], xmm4
0000796d027d2cd3  vmovaps [rsp+0x50], xmm5
0000796d027d2cd9  vmovaps [rsp+0x60], xmm6
0000796d027d2cdf  vmovaps [rsp+0x70], xmm7
0000796d027d2ce5  vmovaps [rsp+0x80], xmm8
0000796d027d2cee  vmovaps [rsp+0x90], xmm9
0000796d027d2cf7  vmovaps [rsp+0xA0], xmm10
0000796d027d2d00  vmovaps [rsp+0xB0], xmm11
0000796d027d2d09  vmovaps [rsp+0xC0], xmm12
0000796d027d2d12  vmovaps [rsp+0xD0], xmm14
0000796d027d2d1b  vmovaps [rsp+0xE0], xmm15
0000796d027d2d24  sub rsp, 0x30
0000796d027d2d28  movaps [rsp], xmm13
0000796d027d2d2d  movaps [rsp+0x10], xmm10
0000796d027d2d33  movaps [rsp+0x20], xmm1
0000796d027d2d38  lea rdi, [rsp]
0000796d027d2d3c  mov esi, 0x00
0000796d027d2d41  mov rax, 0x635FBE957530
0000796d027d2d4b  call rax
0000796d027d2d4d  movaps xmm13, [rsp]
0000796d027d2d52  add rsp, 0x30
0000796d027d2d56  vmovaps xmm0, [rsp]
0000796d027d2d5b  vmovaps xmm1, [rsp+0x10]
0000796d027d2d61  vmovaps xmm2, [rsp+0x20]
0000796d027d2d67  vmovaps xmm3, [rsp+0x30]
0000796d027d2d6d  vmovaps xmm4, [rsp+0x40]
0000796d027d2d73  vmovaps xmm5, [rsp+0x50]
0000796d027d2d79  vmovaps xmm6, [rsp+0x60]
0000796d027d2d7f  vmovaps xmm7, [rsp+0x70]
0000796d027d2d85  vmovaps xmm8, [rsp+0x80]
0000796d027d2d8e  vmovaps xmm9, [rsp+0x90]
0000796d027d2d97  vmovaps xmm10, [rsp+0xA0]
0000796d027d2da0  vmovaps xmm11, [rsp+0xB0]
0000796d027d2da9  vmovaps xmm12, [rsp+0xC0]
0000796d027d2db2  vmovaps xmm14, [rsp+0xD0]
0000796d027d2dbb  vmovaps xmm15, [rsp+0xE0]
0000796d027d2dc4  add rsp, 0xF0
0000796d027d2dcb  pop r11
0000796d027d2dcd  pop r10
0000796d027d2dcf  pop r9
0000796d027d2dd1  pop r8
0000796d027d2dd3  pop rsi
0000796d027d2dd4  pop rdi
0000796d027d2dd5  pop rdx
0000796d027d2dd6  pop rcx
0000796d027d2dd7  pop rax
0000796d027d2dd8  add rsp, 0x08
0000796d027d2ddc  jmp 0x0000796D027CFE15
0000796d027d2de1  sub rsp, 0x08
0000796d027d2de5  push rax
0000796d027d2de6  push rcx
0000796d027d2de7  push rdx
0000796d027d2de8  push rdi
0000796d027d2de9  push rsi
0000796d027d2dea  push r8
0000796d027d2dec  push r9
0000796d027d2dee  push r10
0000796d027d2df0  push r11
0000796d027d2df2  sub rsp, 0xF0
0000796d027d2df9  vmovaps [rsp], xmm0
0000796d027d2dfe  vmovaps [rsp+0x10], xmm2
0000796d027d2e04  vmovaps [rsp+0x20], xmm3
0000796d027d2e0a  vmovaps [rsp+0x30], xmm4
0000796d027d2e10  vmovaps [rsp+0x40], xmm5
0000796d027d2e16  vmovaps [rsp+0x50], xmm6
0000796d027d2e1c  vmovaps [rsp+0x60], xmm7
0000796d027d2e22  vmovaps [rsp+0x70], xmm8
0000796d027d2e28  vmovaps [rsp+0x80], xmm9
0000796d027d2e31  vmovaps [rsp+0x90], xmm10
0000796d027d2e3a  vmovaps [rsp+0xA0], xmm11
0000796d027d2e43  vmovaps [rsp+0xB0], xmm12
0000796d027d2e4c  vmovaps [rsp+0xC0], xmm13
0000796d027d2e55  vmovaps [rsp+0xD0], xmm14
0000796d027d2e5e  vmovaps [rsp+0xE0], xmm15
0000796d027d2e67  sub rsp, 0x30
0000796d027d2e6b  movaps [rsp], xmm1
0000796d027d2e6f  movaps [rsp+0x10], xmm15
0000796d027d2e75  movaps [rsp+0x20], xmm10
0000796d027d2e7b  lea rdi, [rsp]
0000796d027d2e7f  mov esi, 0x00
0000796d027d2e84  mov rax, 0x635FBE957530
0000796d027d2e8e  call rax
0000796d027d2e90  movaps xmm1, [rsp]
0000796d027d2e94  add rsp, 0x30
0000796d027d2e98  vmovaps xmm0, [rsp]
0000796d027d2e9d  vmovaps xmm2, [rsp+0x10]
0000796d027d2ea3  vmovaps xmm3, [rsp+0x20]
0000796d027d2ea9  vmovaps xmm4, [rsp+0x30]
0000796d027d2eaf  vmovaps xmm5, [rsp+0x40]
0000796d027d2eb5  vmovaps xmm6, [rsp+0x50]
0000796d027d2ebb  vmovaps xmm7, [rsp+0x60]
0000796d027d2ec1  vmovaps xmm8, [rsp+0x70]
0000796d027d2ec7  vmovaps xmm9, [rsp+0x80]
0000796d027d2ed0  vmovaps xmm10, [rsp+0x90]
0000796d027d2ed9  vmovaps xmm11, [rsp+0xA0]
0000796d027d2ee2  vmovaps xmm12, [rsp+0xB0]
0000796d027d2eeb  vmovaps xmm13, [rsp+0xC0]
0000796d027d2ef4  vmovaps xmm14, [rsp+0xD0]
0000796d027d2efd  vmovaps xmm15, [rsp+0xE0]
0000796d027d2f06  add rsp, 0xF0
0000796d027d2f0d  pop r11
0000796d027d2f0f  pop r10
0000796d027d2f11  pop r9
0000796d027d2f13  pop r8
0000796d027d2f15  pop rsi
0000796d027d2f16  pop rdi
0000796d027d2f17  pop rdx
0000796d027d2f18  pop rcx
0000796d027d2f19  pop rax
0000796d027d2f1a  add rsp, 0x08
0000796d027d2f1e  jmp 0x0000796D027CFE34
0000796d027d2f23  sub rsp, 0x08
0000796d027d2f27  push rax
0000796d027d2f28  push rcx
0000796d027d2f29  push rdx
0000796d027d2f2a  push rdi
0000796d027d2f2b  push rsi
0000796d027d2f2c  push r8
0000796d027d2f2e  push r9
0000796d027d2f30  push r10
0000796d027d2f32  push r11
0000796d027d2f34  sub rsp, 0xF0
0000796d027d2f3b  vmovaps [rsp], xmm0
0000796d027d2f40  vmovaps [rsp+0x10], xmm1
0000796d027d2f46  vmovaps [rsp+0x20], xmm2
0000796d027d2f4c  vmovaps [rsp+0x30], xmm3
0000796d027d2f52  vmovaps [rsp+0x40], xmm4
0000796d027d2f58  vmovaps [rsp+0x50], xmm5
0000796d027d2f5e  vmovaps [rsp+0x60], xmm6
0000796d027d2f64  vmovaps [rsp+0x70], xmm7
0000796d027d2f6a  vmovaps [rsp+0x80], xmm8
0000796d027d2f73  vmovaps [rsp+0x90], xmm9
0000796d027d2f7c  vmovaps [rsp+0xA0], xmm10
0000796d027d2f85  vmovaps [rsp+0xB0], xmm11
0000796d027d2f8e  vmovaps [rsp+0xC0], xmm12
0000796d027d2f97  vmovaps [rsp+0xD0], xmm13
0000796d027d2fa0  vmovaps [rsp+0xE0], xmm14
0000796d027d2fa9  sub rsp, 0x30
0000796d027d2fad  movaps [rsp], xmm15
0000796d027d2fb2  movaps [rsp+0x10], xmm10
0000796d027d2fb8  movaps [rsp+0x20], xmm11
0000796d027d2fbe  lea rdi, [rsp]
0000796d027d2fc2  mov esi, 0x00
0000796d027d2fc7  mov rax, 0x635FBE957530
0000796d027d2fd1  call rax
0000796d027d2fd3  movaps xmm15, [rsp]
0000796d027d2fd8  add rsp, 0x30
0000796d027d2fdc  vmovaps xmm0, [rsp]
0000796d027d2fe1  vmovaps xmm1, [rsp+0x10]
0000796d027d2fe7  vmovaps xmm2, [rsp+0x20]
0000796d027d2fed  vmovaps xmm3, [rsp+0x30]
0000796d027d2ff3  vmovaps xmm4, [rsp+0x40]
0000796d027d2ff9  vmovaps xmm5, [rsp+0x50]
0000796d027d2fff  vmovaps xmm6, [rsp+0x60]
0000796d027d3005  vmovaps xmm7, [rsp+0x70]
0000796d027d300b  vmovaps xmm8, [rsp+0x80]
0000796d027d3014  vmovaps xmm9, [rsp+0x90]
0000796d027d301d  vmovaps xmm10, [rsp+0xA0]
0000796d027d3026  vmovaps xmm11, [rsp+0xB0]
0000796d027d302f  vmovaps xmm12, [rsp+0xC0]
0000796d027d3038  vmovaps xmm13, [rsp+0xD0]
0000796d027d3041  vmovaps xmm14, [rsp+0xE0]
0000796d027d304a  add rsp, 0xF0
0000796d027d3051  pop r11
0000796d027d3053  pop r10
0000796d027d3055  pop r9
0000796d027d3057  pop r8
0000796d027d3059  pop rsi
0000796d027d305a  pop rdi
0000796d027d305b  pop rdx
0000796d027d305c  pop rcx
0000796d027d305d  pop rax
0000796d027d305e  add rsp, 0x08
0000796d027d3062  jmp 0x0000796D027CFE57
0000796d027d3067  sub rsp, 0x08
0000796d027d306b  push rax
0000796d027d306c  push rcx
0000796d027d306d  push rdx
0000796d027d306e  push rdi
0000796d027d306f  push rsi
0000796d027d3070  push r8
0000796d027d3072  push r9
0000796d027d3074  push r10
0000796d027d3076  push r11
0000796d027d3078  sub rsp, 0xF0
0000796d027d307f  vmovaps [rsp], xmm0
0000796d027d3084  vmovaps [rsp+0x10], xmm1
0000796d027d308a  vmovaps [rsp+0x20], xmm2
0000796d027d3090  vmovaps [rsp+0x30], xmm3
0000796d027d3096  vmovaps [rsp+0x40], xmm4
0000796d027d309c  vmovaps [rsp+0x50], xmm5
0000796d027d30a2  vmovaps [rsp+0x60], xmm6
0000796d027d30a8  vmovaps [rsp+0x70], xmm7
0000796d027d30ae  vmovaps [rsp+0x80], xmm8
0000796d027d30b7  vmovaps [rsp+0x90], xmm9
0000796d027d30c0  vmovaps [rsp+0xA0], xmm11
0000796d027d30c9  vmovaps [rsp+0xB0], xmm12
0000796d027d30d2  vmovaps [rsp+0xC0], xmm13
0000796d027d30db  vmovaps [rsp+0xD0], xmm14
0000796d027d30e4  vmovaps [rsp+0xE0], xmm15
0000796d027d30ed  sub rsp, 0x30
0000796d027d30f1  movaps [rsp], xmm10
0000796d027d30f6  movaps [rsp+0x10], xmm12
0000796d027d30fc  movaps [rsp+0x20], xmm11
0000796d027d3102  lea rdi, [rsp]
0000796d027d3106  mov esi, 0x00
0000796d027d310b  mov rax, 0x635FBE957530
0000796d027d3115  call rax
0000796d027d3117  movaps xmm10, [rsp]
0000796d027d311c  add rsp, 0x30
0000796d027d3120  vmovaps xmm0, [rsp]
0000796d027d3125  vmovaps xmm1, [rsp+0x10]
0000796d027d312b  vmovaps xmm2, [rsp+0x20]
0000796d027d3131  vmovaps xmm3, [rsp+0x30]
0000796d027d3137  vmovaps xmm4, [rsp+0x40]
0000796d027d313d  vmovaps xmm5, [rsp+0x50]
0000796d027d3143  vmovaps xmm6, [rsp+0x60]
0000796d027d3149  vmovaps xmm7, [rsp+0x70]
0000796d027d314f  vmovaps xmm8, [rsp+0x80]
0000796d027d3158  vmovaps xmm9, [rsp+0x90]
0000796d027d3161  vmovaps xmm11, [rsp+0xA0]
0000796d027d316a  vmovaps xmm12, [rsp+0xB0]
0000796d027d3173  vmovaps xmm13, [rsp+0xC0]
0000796d027d317c  vmovaps xmm14, [rsp+0xD0]
0000796d027d3185  vmovaps xmm15, [rsp+0xE0]
0000796d027d318e  add rsp, 0xF0
0000796d027d3195  pop r11
0000796d027d3197  pop r10
0000796d027d3199  pop r9
0000796d027d319b  pop r8
0000796d027d319d  pop rsi
0000796d027d319e  pop rdi
0000796d027d319f  pop rdx
0000796d027d31a0  pop rcx
0000796d027d31a1  pop rax
0000796d027d31a2  add rsp, 0x08
0000796d027d31a6  jmp 0x0000796D027CFE80
0000796d027d31ab  sub rsp, 0x08
0000796d027d31af  push rax
0000796d027d31b0  push rcx
0000796d027d31b1  push rdx
0000796d027d31b2  push rdi
0000796d027d31b3  push rsi
0000796d027d31b4  push r8
0000796d027d31b6  push r9
0000796d027d31b8  push r10
0000796d027d31ba  push r11
0000796d027d31bc  sub rsp, 0xF0
0000796d027d31c3  vmovaps [rsp], xmm0
0000796d027d31c8  vmovaps [rsp+0x10], xmm1
0000796d027d31ce  vmovaps [rsp+0x20], xmm2
0000796d027d31d4  vmovaps [rsp+0x30], xmm3
0000796d027d31da  vmovaps [rsp+0x40], xmm4
0000796d027d31e0  vmovaps [rsp+0x50], xmm5
0000796d027d31e6  vmovaps [rsp+0x60], xmm6
0000796d027d31ec  vmovaps [rsp+0x70], xmm7
0000796d027d31f2  vmovaps [rsp+0x80], xmm8
0000796d027d31fb  vmovaps [rsp+0x90], xmm9
0000796d027d3204  vmovaps [rsp+0xA0], xmm10
0000796d027d320d  vmovaps [rsp+0xB0], xmm12
0000796d027d3216  vmovaps [rsp+0xC0], xmm13
0000796d027d321f  vmovaps [rsp+0xD0], xmm14
0000796d027d3228  vmovaps [rsp+0xE0], xmm15
0000796d027d3231  sub rsp, 0x30
0000796d027d3235  movaps [rsp], xmm11
0000796d027d323a  movaps [rsp+0x10], xmm2
0000796d027d323f  movaps [rsp+0x20], xmm12
0000796d027d3245  lea rdi, [rsp]
0000796d027d3249  mov esi, 0x00
0000796d027d324e  mov rax, 0x635FBE957530
0000796d027d3258  call rax
0000796d027d325a  movaps xmm11, [rsp]
0000796d027d325f  add rsp, 0x30
0000796d027d3263  vmovaps xmm0, [rsp]
0000796d027d3268  vmovaps xmm1, [rsp+0x10]
0000796d027d326e  vmovaps xmm2, [rsp+0x20]
0000796d027d3274  vmovaps xmm3, [rsp+0x30]
0000796d027d327a  vmovaps xmm4, [rsp+0x40]
0000796d027d3280  vmovaps xmm5, [rsp+0x50]
0000796d027d3286  vmovaps xmm6, [rsp+0x60]
0000796d027d328c  vmovaps xmm7, [rsp+0x70]
0000796d027d3292  vmovaps xmm8, [rsp+0x80]
0000796d027d329b  vmovaps xmm9, [rsp+0x90]
0000796d027d32a4  vmovaps xmm10, [rsp+0xA0]
0000796d027d32ad  vmovaps xmm12, [rsp+0xB0]
0000796d027d32b6  vmovaps xmm13, [rsp+0xC0]
0000796d027d32bf  vmovaps xmm14, [rsp+0xD0]
0000796d027d32c8  vmovaps xmm15, [rsp+0xE0]
0000796d027d32d1  add rsp, 0xF0
0000796d027d32d8  pop r11
0000796d027d32da  pop r10
0000796d027d32dc  pop r9
0000796d027d32de  pop r8
0000796d027d32e0  pop rsi
0000796d027d32e1  pop rdi
0000796d027d32e2  pop rdx
0000796d027d32e3  pop rcx
0000796d027d32e4  pop rax
0000796d027d32e5  add rsp, 0x08
0000796d027d32e9  jmp 0x0000796D027CFEB8
0000796d027d32ee  sub rsp, 0x08
0000796d027d32f2  push rax
0000796d027d32f3  push rcx
0000796d027d32f4  push rdx
0000796d027d32f5  push rdi
0000796d027d32f6  push rsi
0000796d027d32f7  push r8
0000796d027d32f9  push r9
0000796d027d32fb  push r10
0000796d027d32fd  push r11
0000796d027d32ff  sub rsp, 0xF0
0000796d027d3306  vmovaps [rsp], xmm0
0000796d027d330b  vmovaps [rsp+0x10], xmm2
0000796d027d3311  vmovaps [rsp+0x20], xmm3
0000796d027d3317  vmovaps [rsp+0x30], xmm4
0000796d027d331d  vmovaps [rsp+0x40], xmm5
0000796d027d3323  vmovaps [rsp+0x50], xmm6
0000796d027d3329  vmovaps [rsp+0x60], xmm7
0000796d027d332f  vmovaps [rsp+0x70], xmm8
0000796d027d3335  vmovaps [rsp+0x80], xmm9
0000796d027d333e  vmovaps [rsp+0x90], xmm10
0000796d027d3347  vmovaps [rsp+0xA0], xmm11
0000796d027d3350  vmovaps [rsp+0xB0], xmm12
0000796d027d3359  vmovaps [rsp+0xC0], xmm13
0000796d027d3362  vmovaps [rsp+0xD0], xmm14
0000796d027d336b  vmovaps [rsp+0xE0], xmm15
0000796d027d3374  sub rsp, 0x30
0000796d027d3378  movaps [rsp], xmm1
0000796d027d337c  movaps [rsp+0x10], xmm14
0000796d027d3382  movaps [rsp+0x20], xmm6
0000796d027d3387  lea rdi, [rsp]
0000796d027d338b  mov esi, 0x00
0000796d027d3390  mov rax, 0x635FBE957530
0000796d027d339a  call rax
0000796d027d339c  movaps xmm1, [rsp]
0000796d027d33a0  add rsp, 0x30
0000796d027d33a4  vmovaps xmm0, [rsp]
0000796d027d33a9  vmovaps xmm2, [rsp+0x10]
0000796d027d33af  vmovaps xmm3, [rsp+0x20]
0000796d027d33b5  vmovaps xmm4, [rsp+0x30]
0000796d027d33bb  vmovaps xmm5, [rsp+0x40]
0000796d027d33c1  vmovaps xmm6, [rsp+0x50]
0000796d027d33c7  vmovaps xmm7, [rsp+0x60]
0000796d027d33cd  vmovaps xmm8, [rsp+0x70]
0000796d027d33d3  vmovaps xmm9, [rsp+0x80]
0000796d027d33dc  vmovaps xmm10, [rsp+0x90]
0000796d027d33e5  vmovaps xmm11, [rsp+0xA0]
0000796d027d33ee  vmovaps xmm12, [rsp+0xB0]
0000796d027d33f7  vmovaps xmm13, [rsp+0xC0]
0000796d027d3400  vmovaps xmm14, [rsp+0xD0]
0000796d027d3409  vmovaps xmm15, [rsp+0xE0]
0000796d027d3412  add rsp, 0xF0
0000796d027d3419  pop r11
0000796d027d341b  pop r10
0000796d027d341d  pop r9
0000796d027d341f  pop r8
0000796d027d3421  pop rsi
0000796d027d3422  pop rdi
0000796d027d3423  pop rdx
0000796d027d3424  pop rcx
0000796d027d3425  pop rax
0000796d027d3426  add rsp, 0x08
0000796d027d342a  jmp 0x0000796D027CFED1
0000796d027d342f  sub rsp, 0x08
0000796d027d3433  push rax
0000796d027d3434  push rcx
0000796d027d3435  push rdx
0000796d027d3436  push rdi
0000796d027d3437  push rsi
0000796d027d3438  push r8
0000796d027d343a  push r9
0000796d027d343c  push r10
0000796d027d343e  push r11
0000796d027d3440  sub rsp, 0xF0
0000796d027d3447  vmovaps [rsp], xmm0
0000796d027d344c  vmovaps [rsp+0x10], xmm1
0000796d027d3452  vmovaps [rsp+0x20], xmm2
0000796d027d3458  vmovaps [rsp+0x30], xmm3
0000796d027d345e  vmovaps [rsp+0x40], xmm4
0000796d027d3464  vmovaps [rsp+0x50], xmm5
0000796d027d346a  vmovaps [rsp+0x60], xmm6
0000796d027d3470  vmovaps [rsp+0x70], xmm7
0000796d027d3476  vmovaps [rsp+0x80], xmm8
0000796d027d347f  vmovaps [rsp+0x90], xmm9
0000796d027d3488  vmovaps [rsp+0xA0], xmm10
0000796d027d3491  vmovaps [rsp+0xB0], xmm11
0000796d027d349a  vmovaps [rsp+0xC0], xmm12
0000796d027d34a3  vmovaps [rsp+0xD0], xmm13
0000796d027d34ac  vmovaps [rsp+0xE0], xmm15
0000796d027d34b5  sub rsp, 0x30
0000796d027d34b9  movaps [rsp], xmm14
0000796d027d34be  movaps [rsp+0x10], xmm12
0000796d027d34c4  movaps [rsp+0x20], xmm5
0000796d027d34c9  lea rdi, [rsp]
0000796d027d34cd  mov esi, 0x00
0000796d027d34d2  mov rax, 0x635FBE957530
0000796d027d34dc  call rax
0000796d027d34de  movaps xmm14, [rsp]
0000796d027d34e3  add rsp, 0x30
0000796d027d34e7  vmovaps xmm0, [rsp]
0000796d027d34ec  vmovaps xmm1, [rsp+0x10]
0000796d027d34f2  vmovaps xmm2, [rsp+0x20]
0000796d027d34f8  vmovaps xmm3, [rsp+0x30]
0000796d027d34fe  vmovaps xmm4, [rsp+0x40]
0000796d027d3504  vmovaps xmm5, [rsp+0x50]
0000796d027d350a  vmovaps xmm6, [rsp+0x60]
0000796d027d3510  vmovaps xmm7, [rsp+0x70]
0000796d027d3516  vmovaps xmm8, [rsp+0x80]
0000796d027d351f  vmovaps xmm9, [rsp+0x90]
0000796d027d3528  vmovaps xmm10, [rsp+0xA0]
0000796d027d3531  vmovaps xmm11, [rsp+0xB0]
0000796d027d353a  vmovaps xmm12, [rsp+0xC0]
0000796d027d3543  vmovaps xmm13, [rsp+0xD0]
0000796d027d354c  vmovaps xmm15, [rsp+0xE0]
0000796d027d3555  add rsp, 0xF0
0000796d027d355c  pop r11
0000796d027d355e  pop r10
0000796d027d3560  pop r9
0000796d027d3562  pop r8
0000796d027d3564  pop rsi
0000796d027d3565  pop rdi
0000796d027d3566  pop rdx
0000796d027d3567  pop rcx
0000796d027d3568  pop rax
0000796d027d3569  add rsp, 0x08
0000796d027d356d  jmp 0x0000796D027CFEF1
0000796d027d3572  sub rsp, 0x08
0000796d027d3576  push rax
0000796d027d3577  push rcx
0000796d027d3578  push rdx
0000796d027d3579  push rdi
0000796d027d357a  push rsi
0000796d027d357b  push r8
0000796d027d357d  push r9
0000796d027d357f  push r10
0000796d027d3581  push r11
0000796d027d3583  sub rsp, 0xF0
0000796d027d358a  vmovaps [rsp], xmm0
0000796d027d358f  vmovaps [rsp+0x10], xmm1
0000796d027d3595  vmovaps [rsp+0x20], xmm2
0000796d027d359b  vmovaps [rsp+0x30], xmm3
0000796d027d35a1  vmovaps [rsp+0x40], xmm4
0000796d027d35a7  vmovaps [rsp+0x50], xmm5
0000796d027d35ad  vmovaps [rsp+0x60], xmm7
0000796d027d35b3  vmovaps [rsp+0x70], xmm8
0000796d027d35b9  vmovaps [rsp+0x80], xmm9
0000796d027d35c2  vmovaps [rsp+0x90], xmm10
0000796d027d35cb  vmovaps [rsp+0xA0], xmm11
0000796d027d35d4  vmovaps [rsp+0xB0], xmm12
0000796d027d35dd  vmovaps [rsp+0xC0], xmm13
0000796d027d35e6  vmovaps [rsp+0xD0], xmm14
0000796d027d35ef  vmovaps [rsp+0xE0], xmm15
0000796d027d35f8  sub rsp, 0x30
0000796d027d35fc  movaps [rsp], xmm6
0000796d027d3600  movaps [rsp+0x10], xmm9
0000796d027d3606  movaps [rsp+0x20], xmm12
0000796d027d360c  lea rdi, [rsp]
0000796d027d3610  mov esi, 0x00
0000796d027d3615  mov rax, 0x635FBE957530
0000796d027d361f  call rax
0000796d027d3621  movaps xmm6, [rsp]
0000796d027d3625  add rsp, 0x30
0000796d027d3629  vmovaps xmm0, [rsp]
0000796d027d362e  vmovaps xmm1, [rsp+0x10]
0000796d027d3634  vmovaps xmm2, [rsp+0x20]
0000796d027d363a  vmovaps xmm3, [rsp+0x30]
0000796d027d3640  vmovaps xmm4, [rsp+0x40]
0000796d027d3646  vmovaps xmm5, [rsp+0x50]
0000796d027d364c  vmovaps xmm7, [rsp+0x60]
0000796d027d3652  vmovaps xmm8, [rsp+0x70]
0000796d027d3658  vmovaps xmm9, [rsp+0x80]
0000796d027d3661  vmovaps xmm10, [rsp+0x90]
0000796d027d366a  vmovaps xmm11, [rsp+0xA0]
0000796d027d3673  vmovaps xmm12, [rsp+0xB0]
0000796d027d367c  vmovaps xmm13, [rsp+0xC0]
0000796d027d3685  vmovaps xmm14, [rsp+0xD0]
0000796d027d368e  vmovaps xmm15, [rsp+0xE0]
0000796d027d3697  add rsp, 0xF0
0000796d027d369e  pop r11
0000796d027d36a0  pop r10
0000796d027d36a2  pop r9
0000796d027d36a4  pop r8
0000796d027d36a6  pop rsi
0000796d027d36a7  pop rdi
0000796d027d36a8  pop rdx
0000796d027d36a9  pop rcx
0000796d027d36aa  pop rax
0000796d027d36ab  add rsp, 0x08
0000796d027d36af  jmp 0x0000796D027CFF19
0000796d027d36b4  sub rsp, 0x08
0000796d027d36b8  push rax
0000796d027d36b9  push rcx
0000796d027d36ba  push rdx
0000796d027d36bb  push rdi
0000796d027d36bc  push rsi
0000796d027d36bd  push r8
0000796d027d36bf  push r9
0000796d027d36c1  push r10
0000796d027d36c3  push r11
0000796d027d36c5  sub rsp, 0xF0
0000796d027d36cc  vmovaps [rsp], xmm0
0000796d027d36d1  vmovaps [rsp+0x10], xmm1
0000796d027d36d7  vmovaps [rsp+0x20], xmm2
0000796d027d36dd  vmovaps [rsp+0x30], xmm3
0000796d027d36e3  vmovaps [rsp+0x40], xmm4
0000796d027d36e9  vmovaps [rsp+0x50], xmm5
0000796d027d36ef  vmovaps [rsp+0x60], xmm6
0000796d027d36f5  vmovaps [rsp+0x70], xmm7
0000796d027d36fb  vmovaps [rsp+0x80], xmm8
0000796d027d3704  vmovaps [rsp+0x90], xmm9
0000796d027d370d  vmovaps [rsp+0xA0], xmm10
0000796d027d3716  vmovaps [rsp+0xB0], xmm11
0000796d027d371f  vmovaps [rsp+0xC0], xmm13
0000796d027d3728  vmovaps [rsp+0xD0], xmm14
0000796d027d3731  vmovaps [rsp+0xE0], xmm15
0000796d027d373a  sub rsp, 0x30
0000796d027d373e  movaps [rsp], xmm12
0000796d027d3743  movaps [rsp+0x10], xmm15
0000796d027d3749  movaps [rsp+0x20], xmm13
0000796d027d374f  lea rdi, [rsp]
0000796d027d3753  mov esi, 0x00
0000796d027d3758  mov rax, 0x635FBE957530
0000796d027d3762  call rax
0000796d027d3764  movaps xmm12, [rsp]
0000796d027d3769  add rsp, 0x30
0000796d027d376d  vmovaps xmm0, [rsp]
0000796d027d3772  vmovaps xmm1, [rsp+0x10]
0000796d027d3778  vmovaps xmm2, [rsp+0x20]
0000796d027d377e  vmovaps xmm3, [rsp+0x30]
0000796d027d3784  vmovaps xmm4, [rsp+0x40]
0000796d027d378a  vmovaps xmm5, [rsp+0x50]
0000796d027d3790  vmovaps xmm6, [rsp+0x60]
0000796d027d3796  vmovaps xmm7, [rsp+0x70]
0000796d027d379c  vmovaps xmm8, [rsp+0x80]
0000796d027d37a5  vmovaps xmm9, [rsp+0x90]
0000796d027d37ae  vmovaps xmm10, [rsp+0xA0]
0000796d027d37b7  vmovaps xmm11, [rsp+0xB0]
0000796d027d37c0  vmovaps xmm13, [rsp+0xC0]
0000796d027d37c9  vmovaps xmm14, [rsp+0xD0]
0000796d027d37d2  vmovaps xmm15, [rsp+0xE0]
0000796d027d37db  add rsp, 0xF0
0000796d027d37e2  pop r11
0000796d027d37e4  pop r10
0000796d027d37e6  pop r9
0000796d027d37e8  pop r8
0000796d027d37ea  pop rsi
0000796d027d37eb  pop rdi
0000796d027d37ec  pop rdx
0000796d027d37ed  pop rcx
0000796d027d37ee  pop rax
0000796d027d37ef  add rsp, 0x08
0000796d027d37f3  jmp 0x0000796D027CFF34
0000796d027d37f8  sub rsp, 0x08
0000796d027d37fc  push rax
0000796d027d37fd  push rcx
0000796d027d37fe  push rdx
0000796d027d37ff  push rdi
0000796d027d3800  push rsi
0000796d027d3801  push r8
0000796d027d3803  push r9
0000796d027d3805  push r10
0000796d027d3807  push r11
0000796d027d3809  sub rsp, 0xF0
0000796d027d3810  vmovaps [rsp], xmm0
0000796d027d3815  vmovaps [rsp+0x10], xmm1
0000796d027d381b  vmovaps [rsp+0x20], xmm2
0000796d027d3821  vmovaps [rsp+0x30], xmm3
0000796d027d3827  vmovaps [rsp+0x40], xmm4
0000796d027d382d  vmovaps [rsp+0x50], xmm5
0000796d027d3833  vmovaps [rsp+0x60], xmm6
0000796d027d3839  vmovaps [rsp+0x70], xmm7
0000796d027d383f  vmovaps [rsp+0x80], xmm8
0000796d027d3848  vmovaps [rsp+0x90], xmm9
0000796d027d3851  vmovaps [rsp+0xA0], xmm10
0000796d027d385a  vmovaps [rsp+0xB0], xmm11
0000796d027d3863  vmovaps [rsp+0xC0], xmm12
0000796d027d386c  vmovaps [rsp+0xD0], xmm13
0000796d027d3875  vmovaps [rsp+0xE0], xmm14
0000796d027d387e  sub rsp, 0x30
0000796d027d3882  movaps [rsp], xmm15
0000796d027d3887  movaps [rsp+0x10], xmm13
0000796d027d388d  movaps [rsp+0x20], xmm10
0000796d027d3893  lea rdi, [rsp]
0000796d027d3897  mov esi, 0x00
0000796d027d389c  mov rax, 0x635FBE957530
0000796d027d38a6  call rax
0000796d027d38a8  movaps xmm15, [rsp]
0000796d027d38ad  add rsp, 0x30
0000796d027d38b1  vmovaps xmm0, [rsp]
0000796d027d38b6  vmovaps xmm1, [rsp+0x10]
0000796d027d38bc  vmovaps xmm2, [rsp+0x20]
0000796d027d38c2  vmovaps xmm3, [rsp+0x30]
0000796d027d38c8  vmovaps xmm4, [rsp+0x40]
0000796d027d38ce  vmovaps xmm5, [rsp+0x50]
0000796d027d38d4  vmovaps xmm6, [rsp+0x60]
0000796d027d38da  vmovaps xmm7, [rsp+0x70]
0000796d027d38e0  vmovaps xmm8, [rsp+0x80]
0000796d027d38e9  vmovaps xmm9, [rsp+0x90]
0000796d027d38f2  vmovaps xmm10, [rsp+0xA0]
0000796d027d38fb  vmovaps xmm11, [rsp+0xB0]
0000796d027d3904  vmovaps xmm12, [rsp+0xC0]
0000796d027d390d  vmovaps xmm13, [rsp+0xD0]
0000796d027d3916  vmovaps xmm14, [rsp+0xE0]
0000796d027d391f  add rsp, 0xF0
0000796d027d3926  pop r11
0000796d027d3928  pop r10
0000796d027d392a  pop r9
0000796d027d392c  pop r8
0000796d027d392e  pop rsi
0000796d027d392f  pop rdi
0000796d027d3930  pop rdx
0000796d027d3931  pop rcx
0000796d027d3932  pop rax
0000796d027d3933  add rsp, 0x08
0000796d027d3937  jmp 0x0000796D027CFF55
0000796d027d393c  call 0x0000796D0260C260
0000796d027d3941  jmp 0x0000796D027CFFB0
0000796d027d3946  sub rsp, 0x08
0000796d027d394a  push rax
0000796d027d394b  push rcx
0000796d027d394c  push rdx
0000796d027d394d  push rdi
0000796d027d394e  push rsi
0000796d027d394f  push r8
0000796d027d3951  push r9
0000796d027d3953  push r10
0000796d027d3955  push r11
0000796d027d3957  sub rsp, 0xF0
0000796d027d395e  vmovaps [rsp], xmm0
0000796d027d3963  vmovaps [rsp+0x10], xmm1
0000796d027d3969  vmovaps [rsp+0x20], xmm2
0000796d027d396f  vmovaps [rsp+0x30], xmm3
0000796d027d3975  vmovaps [rsp+0x40], xmm4
0000796d027d397b  vmovaps [rsp+0x50], xmm5
0000796d027d3981  vmovaps [rsp+0x60], xmm6
0000796d027d3987  vmovaps [rsp+0x70], xmm7
0000796d027d398d  vmovaps [rsp+0x80], xmm8
0000796d027d3996  vmovaps [rsp+0x90], xmm10
0000796d027d399f  vmovaps [rsp+0xA0], xmm11
0000796d027d39a8  vmovaps [rsp+0xB0], xmm12
0000796d027d39b1  vmovaps [rsp+0xC0], xmm13
0000796d027d39ba  vmovaps [rsp+0xD0], xmm14
0000796d027d39c3  vmovaps [rsp+0xE0], xmm15
0000796d027d39cc  sub rsp, 0x30
0000796d027d39d0  movaps [rsp], xmm9
0000796d027d39d5  movaps [rsp+0x10], xmm8
0000796d027d39db  movaps [rsp+0x20], xmm10
0000796d027d39e1  lea rdi, [rsp]
0000796d027d39e5  mov esi, 0x00
0000796d027d39ea  mov rax, 0x635FBE957530
0000796d027d39f4  call rax
0000796d027d39f6  movaps xmm9, [rsp]
0000796d027d39fb  add rsp, 0x30
0000796d027d39ff  vmovaps xmm0, [rsp]
0000796d027d3a04  vmovaps xmm1, [rsp+0x10]
0000796d027d3a0a  vmovaps xmm2, [rsp+0x20]
0000796d027d3a10  vmovaps xmm3, [rsp+0x30]
0000796d027d3a16  vmovaps xmm4, [rsp+0x40]
0000796d027d3a1c  vmovaps xmm5, [rsp+0x50]
0000796d027d3a22  vmovaps xmm6, [rsp+0x60]
0000796d027d3a28  vmovaps xmm7, [rsp+0x70]
0000796d027d3a2e  vmovaps xmm8, [rsp+0x80]
0000796d027d3a37  vmovaps xmm10, [rsp+0x90]
0000796d027d3a40  vmovaps xmm11, [rsp+0xA0]
0000796d027d3a49  vmovaps xmm12, [rsp+0xB0]
0000796d027d3a52  vmovaps xmm13, [rsp+0xC0]
0000796d027d3a5b  vmovaps xmm14, [rsp+0xD0]
0000796d027d3a64  vmovaps xmm15, [rsp+0xE0]
0000796d027d3a6d  add rsp, 0xF0
0000796d027d3a74  pop r11
0000796d027d3a76  pop r10
0000796d027d3a78  pop r9
0000796d027d3a7a  pop r8
0000796d027d3a7c  pop rsi
0000796d027d3a7d  pop rdi
0000796d027d3a7e  pop rdx
0000796d027d3a7f  pop rcx
0000796d027d3a80  pop rax
0000796d027d3a81  add rsp, 0x08
0000796d027d3a85  jmp 0x0000796D027CFFE1
0000796d027d3a8a  sub rsp, 0x08
0000796d027d3a8e  push rax
0000796d027d3a8f  push rcx
0000796d027d3a90  push rdx
0000796d027d3a91  push rdi
0000796d027d3a92  push rsi
0000796d027d3a93  push r8
0000796d027d3a95  push r9
0000796d027d3a97  push r10
0000796d027d3a99  push r11
0000796d027d3a9b  sub rsp, 0xF0
0000796d027d3aa2  vmovaps [rsp], xmm0
0000796d027d3aa7  vmovaps [rsp+0x10], xmm1
0000796d027d3aad  vmovaps [rsp+0x20], xmm2
0000796d027d3ab3  vmovaps [rsp+0x30], xmm3
0000796d027d3ab9  vmovaps [rsp+0x40], xmm4
0000796d027d3abf  vmovaps [rsp+0x50], xmm5
0000796d027d3ac5  vmovaps [rsp+0x60], xmm6
0000796d027d3acb  vmovaps [rsp+0x70], xmm7
0000796d027d3ad1  vmovaps [rsp+0x80], xmm8
0000796d027d3ada  vmovaps [rsp+0x90], xmm9
0000796d027d3ae3  vmovaps [rsp+0xA0], xmm11
0000796d027d3aec  vmovaps [rsp+0xB0], xmm12
0000796d027d3af5  vmovaps [rsp+0xC0], xmm13
0000796d027d3afe  vmovaps [rsp+0xD0], xmm14
0000796d027d3b07  vmovaps [rsp+0xE0], xmm15
0000796d027d3b10  sub rsp, 0x30
0000796d027d3b14  movaps [rsp], xmm10
0000796d027d3b19  movaps [rsp+0x10], xmm1
0000796d027d3b1e  movaps [rsp+0x20], xmm11
0000796d027d3b24  lea rdi, [rsp]
0000796d027d3b28  mov esi, 0x00
0000796d027d3b2d  mov rax, 0x635FBE957530
0000796d027d3b37  call rax
0000796d027d3b39  movaps xmm10, [rsp]
0000796d027d3b3e  add rsp, 0x30
0000796d027d3b42  vmovaps xmm0, [rsp]
0000796d027d3b47  vmovaps xmm1, [rsp+0x10]
0000796d027d3b4d  vmovaps xmm2, [rsp+0x20]
0000796d027d3b53  vmovaps xmm3, [rsp+0x30]
0000796d027d3b59  vmovaps xmm4, [rsp+0x40]
0000796d027d3b5f  vmovaps xmm5, [rsp+0x50]
0000796d027d3b65  vmovaps xmm6, [rsp+0x60]
0000796d027d3b6b  vmovaps xmm7, [rsp+0x70]
0000796d027d3b71  vmovaps xmm8, [rsp+0x80]
0000796d027d3b7a  vmovaps xmm9, [rsp+0x90]
0000796d027d3b83  vmovaps xmm11, [rsp+0xA0]
0000796d027d3b8c  vmovaps xmm12, [rsp+0xB0]
0000796d027d3b95  vmovaps xmm13, [rsp+0xC0]
0000796d027d3b9e  vmovaps xmm14, [rsp+0xD0]
0000796d027d3ba7  vmovaps xmm15, [rsp+0xE0]
0000796d027d3bb0  add rsp, 0xF0
0000796d027d3bb7  pop r11
0000796d027d3bb9  pop r10
0000796d027d3bbb  pop r9
0000796d027d3bbd  pop r8
0000796d027d3bbf  pop rsi
0000796d027d3bc0  pop rdi
0000796d027d3bc1  pop rdx
0000796d027d3bc2  pop rcx
0000796d027d3bc3  pop rax
0000796d027d3bc4  add rsp, 0x08
0000796d027d3bc8  jmp 0x0000796D027CFFFC
0000796d027d3bcd  sub rsp, 0x08
0000796d027d3bd1  push rax
0000796d027d3bd2  push rcx
0000796d027d3bd3  push rdx
0000796d027d3bd4  push rdi
0000796d027d3bd5  push rsi
0000796d027d3bd6  push r8
0000796d027d3bd8  push r9
0000796d027d3bda  push r10
0000796d027d3bdc  push r11
0000796d027d3bde  sub rsp, 0xF0
0000796d027d3be5  vmovaps [rsp], xmm0
0000796d027d3bea  vmovaps [rsp+0x10], xmm2
0000796d027d3bf0  vmovaps [rsp+0x20], xmm3
0000796d027d3bf6  vmovaps [rsp+0x30], xmm4
0000796d027d3bfc  vmovaps [rsp+0x40], xmm5
0000796d027d3c02  vmovaps [rsp+0x50], xmm6
0000796d027d3c08  vmovaps [rsp+0x60], xmm7
0000796d027d3c0e  vmovaps [rsp+0x70], xmm8
0000796d027d3c14  vmovaps [rsp+0x80], xmm9
0000796d027d3c1d  vmovaps [rsp+0x90], xmm10
0000796d027d3c26  vmovaps [rsp+0xA0], xmm11
0000796d027d3c2f  vmovaps [rsp+0xB0], xmm12
0000796d027d3c38  vmovaps [rsp+0xC0], xmm13
0000796d027d3c41  vmovaps [rsp+0xD0], xmm14
0000796d027d3c4a  vmovaps [rsp+0xE0], xmm15
0000796d027d3c53  sub rsp, 0x30
0000796d027d3c57  movaps [rsp], xmm1
0000796d027d3c5b  movaps [rsp+0x10], xmm14
0000796d027d3c61  movaps [rsp+0x20], xmm6
0000796d027d3c66  lea rdi, [rsp]
0000796d027d3c6a  mov esi, 0x00
0000796d027d3c6f  mov rax, 0x635FBE957530
0000796d027d3c79  call rax
0000796d027d3c7b  movaps xmm1, [rsp]
0000796d027d3c7f  add rsp, 0x30
0000796d027d3c83  vmovaps xmm0, [rsp]
0000796d027d3c88  vmovaps xmm2, [rsp+0x10]
0000796d027d3c8e  vmovaps xmm3, [rsp+0x20]
0000796d027d3c94  vmovaps xmm4, [rsp+0x30]
0000796d027d3c9a  vmovaps xmm5, [rsp+0x40]
0000796d027d3ca0  vmovaps xmm6, [rsp+0x50]
0000796d027d3ca6  vmovaps xmm7, [rsp+0x60]
0000796d027d3cac  vmovaps xmm8, [rsp+0x70]
0000796d027d3cb2  vmovaps xmm9, [rsp+0x80]
0000796d027d3cbb  vmovaps xmm10, [rsp+0x90]
0000796d027d3cc4  vmovaps xmm11, [rsp+0xA0]
0000796d027d3ccd  vmovaps xmm12, [rsp+0xB0]
0000796d027d3cd6  vmovaps xmm13, [rsp+0xC0]
0000796d027d3cdf  vmovaps xmm14, [rsp+0xD0]
0000796d027d3ce8  vmovaps xmm15, [rsp+0xE0]
0000796d027d3cf1  add rsp, 0xF0
0000796d027d3cf8  pop r11
0000796d027d3cfa  pop r10
0000796d027d3cfc  pop r9
0000796d027d3cfe  pop r8
0000796d027d3d00  pop rsi
0000796d027d3d01  pop rdi
0000796d027d3d02  pop rdx
0000796d027d3d03  pop rcx
0000796d027d3d04  pop rax
0000796d027d3d05  add rsp, 0x08
0000796d027d3d09  jmp 0x0000796D027D0015
0000796d027d3d0e  sub rsp, 0x08
0000796d027d3d12  push rax
0000796d027d3d13  push rcx
0000796d027d3d14  push rdx
0000796d027d3d15  push rdi
0000796d027d3d16  push rsi
0000796d027d3d17  push r8
0000796d027d3d19  push r9
0000796d027d3d1b  push r10
0000796d027d3d1d  push r11
0000796d027d3d1f  sub rsp, 0xF0
0000796d027d3d26  vmovaps [rsp], xmm0
0000796d027d3d2b  vmovaps [rsp+0x10], xmm1
0000796d027d3d31  vmovaps [rsp+0x20], xmm2
0000796d027d3d37  vmovaps [rsp+0x30], xmm3
0000796d027d3d3d  vmovaps [rsp+0x40], xmm4
0000796d027d3d43  vmovaps [rsp+0x50], xmm5
0000796d027d3d49  vmovaps [rsp+0x60], xmm6
0000796d027d3d4f  vmovaps [rsp+0x70], xmm7
0000796d027d3d55  vmovaps [rsp+0x80], xmm8
0000796d027d3d5e  vmovaps [rsp+0x90], xmm9
0000796d027d3d67  vmovaps [rsp+0xA0], xmm10
0000796d027d3d70  vmovaps [rsp+0xB0], xmm12
0000796d027d3d79  vmovaps [rsp+0xC0], xmm13
0000796d027d3d82  vmovaps [rsp+0xD0], xmm14
0000796d027d3d8b  vmovaps [rsp+0xE0], xmm15
0000796d027d3d94  sub rsp, 0x30
0000796d027d3d98  movaps [rsp], xmm11
0000796d027d3d9d  movaps [rsp+0x10], xmm13
0000796d027d3da3  movaps [rsp+0x20], xmm14
0000796d027d3da9  lea rdi, [rsp]
0000796d027d3dad  mov esi, 0x00
0000796d027d3db2  mov rax, 0x635FBE957530
0000796d027d3dbc  call rax
0000796d027d3dbe  movaps xmm11, [rsp]
0000796d027d3dc3  add rsp, 0x30
0000796d027d3dc7  vmovaps xmm0, [rsp]
0000796d027d3dcc  vmovaps xmm1, [rsp+0x10]
0000796d027d3dd2  vmovaps xmm2, [rsp+0x20]
0000796d027d3dd8  vmovaps xmm3, [rsp+0x30]
0000796d027d3dde  vmovaps xmm4, [rsp+0x40]
0000796d027d3de4  vmovaps xmm5, [rsp+0x50]
0000796d027d3dea  vmovaps xmm6, [rsp+0x60]
0000796d027d3df0  vmovaps xmm7, [rsp+0x70]
0000796d027d3df6  vmovaps xmm8, [rsp+0x80]
0000796d027d3dff  vmovaps xmm9, [rsp+0x90]
0000796d027d3e08  vmovaps xmm10, [rsp+0xA0]
0000796d027d3e11  vmovaps xmm12, [rsp+0xB0]
0000796d027d3e1a  vmovaps xmm13, [rsp+0xC0]
0000796d027d3e23  vmovaps xmm14, [rsp+0xD0]
0000796d027d3e2c  vmovaps xmm15, [rsp+0xE0]
0000796d027d3e35  add rsp, 0xF0
0000796d027d3e3c  pop r11
0000796d027d3e3e  pop r10
0000796d027d3e40  pop r9
0000796d027d3e42  pop r8
0000796d027d3e44  pop rsi
0000796d027d3e45  pop rdi
0000796d027d3e46  pop rdx
0000796d027d3e47  pop rcx
0000796d027d3e48  pop rax
0000796d027d3e49  add rsp, 0x08
0000796d027d3e4d  jmp 0x0000796D027D003F
0000796d027d3e52  sub rsp, 0x08
0000796d027d3e56  push rax
0000796d027d3e57  push rcx
0000796d027d3e58  push rdx
0000796d027d3e59  push rdi
0000796d027d3e5a  push rsi
0000796d027d3e5b  push r8
0000796d027d3e5d  push r9
0000796d027d3e5f  push r10
0000796d027d3e61  push r11
0000796d027d3e63  sub rsp, 0xF0
0000796d027d3e6a  vmovaps [rsp], xmm0
0000796d027d3e6f  vmovaps [rsp+0x10], xmm1
0000796d027d3e75  vmovaps [rsp+0x20], xmm2
0000796d027d3e7b  vmovaps [rsp+0x30], xmm3
0000796d027d3e81  vmovaps [rsp+0x40], xmm4
0000796d027d3e87  vmovaps [rsp+0x50], xmm5
0000796d027d3e8d  vmovaps [rsp+0x60], xmm6
0000796d027d3e93  vmovaps [rsp+0x70], xmm7
0000796d027d3e99  vmovaps [rsp+0x80], xmm8
0000796d027d3ea2  vmovaps [rsp+0x90], xmm9
0000796d027d3eab  vmovaps [rsp+0xA0], xmm10
0000796d027d3eb4  vmovaps [rsp+0xB0], xmm11
0000796d027d3ebd  vmovaps [rsp+0xC0], xmm12
0000796d027d3ec6  vmovaps [rsp+0xD0], xmm14
0000796d027d3ecf  vmovaps [rsp+0xE0], xmm15
0000796d027d3ed8  sub rsp, 0x30
0000796d027d3edc  movaps [rsp], xmm13
0000796d027d3ee1  movaps [rsp+0x10], xmm8
0000796d027d3ee7  movaps [rsp+0x20], xmm14
0000796d027d3eed  lea rdi, [rsp]
0000796d027d3ef1  mov esi, 0x00
0000796d027d3ef6  mov rax, 0x635FBE957530
0000796d027d3f00  call rax
0000796d027d3f02  movaps xmm13, [rsp]
0000796d027d3f07  add rsp, 0x30
0000796d027d3f0b  vmovaps xmm0, [rsp]
0000796d027d3f10  vmovaps xmm1, [rsp+0x10]
0000796d027d3f16  vmovaps xmm2, [rsp+0x20]
0000796d027d3f1c  vmovaps xmm3, [rsp+0x30]
0000796d027d3f22  vmovaps xmm4, [rsp+0x40]
0000796d027d3f28  vmovaps xmm5, [rsp+0x50]
0000796d027d3f2e  vmovaps xmm6, [rsp+0x60]
0000796d027d3f34  vmovaps xmm7, [rsp+0x70]
0000796d027d3f3a  vmovaps xmm8, [rsp+0x80]
0000796d027d3f43  vmovaps xmm9, [rsp+0x90]
0000796d027d3f4c  vmovaps xmm10, [rsp+0xA0]
0000796d027d3f55  vmovaps xmm11, [rsp+0xB0]
0000796d027d3f5e  vmovaps xmm12, [rsp+0xC0]
0000796d027d3f67  vmovaps xmm14, [rsp+0xD0]
0000796d027d3f70  vmovaps xmm15, [rsp+0xE0]
0000796d027d3f79  add rsp, 0xF0
0000796d027d3f80  pop r11
0000796d027d3f82  pop r10
0000796d027d3f84  pop r9
0000796d027d3f86  pop r8
0000796d027d3f88  pop rsi
0000796d027d3f89  pop rdi
0000796d027d3f8a  pop rdx
0000796d027d3f8b  pop rcx
0000796d027d3f8c  pop rax
0000796d027d3f8d  add rsp, 0x08
0000796d027d3f91  jmp 0x0000796D027D006E
0000796d027d3f96  sub rsp, 0x08
0000796d027d3f9a  push rax
0000796d027d3f9b  push rcx
0000796d027d3f9c  push rdx
0000796d027d3f9d  push rdi
0000796d027d3f9e  push rsi
0000796d027d3f9f  push r8
0000796d027d3fa1  push r9
0000796d027d3fa3  push r10
0000796d027d3fa5  push r11
0000796d027d3fa7  sub rsp, 0xF0
0000796d027d3fae  vmovaps [rsp], xmm0
0000796d027d3fb3  vmovaps [rsp+0x10], xmm1
0000796d027d3fb9  vmovaps [rsp+0x20], xmm2
0000796d027d3fbf  vmovaps [rsp+0x30], xmm3
0000796d027d3fc5  vmovaps [rsp+0x40], xmm4
0000796d027d3fcb  vmovaps [rsp+0x50], xmm5
0000796d027d3fd1  vmovaps [rsp+0x60], xmm6
0000796d027d3fd7  vmovaps [rsp+0x70], xmm7
0000796d027d3fdd  vmovaps [rsp+0x80], xmm9
0000796d027d3fe6  vmovaps [rsp+0x90], xmm10
0000796d027d3fef  vmovaps [rsp+0xA0], xmm11
0000796d027d3ff8  vmovaps [rsp+0xB0], xmm12
0000796d027d4001  vmovaps [rsp+0xC0], xmm13
0000796d027d400a  vmovaps [rsp+0xD0], xmm14
0000796d027d4013  vmovaps [rsp+0xE0], xmm15
0000796d027d401c  sub rsp, 0x30
0000796d027d4020  movaps [rsp], xmm8
0000796d027d4025  movaps [rsp+0x10], xmm7
0000796d027d402a  movaps [rsp+0x20], xmm14
0000796d027d4030  lea rdi, [rsp]
0000796d027d4034  mov esi, 0x00
0000796d027d4039  mov rax, 0x635FBE957530
0000796d027d4043  call rax
0000796d027d4045  movaps xmm8, [rsp]
0000796d027d404a  add rsp, 0x30
0000796d027d404e  vmovaps xmm0, [rsp]
0000796d027d4053  vmovaps xmm1, [rsp+0x10]
0000796d027d4059  vmovaps xmm2, [rsp+0x20]
0000796d027d405f  vmovaps xmm3, [rsp+0x30]
0000796d027d4065  vmovaps xmm4, [rsp+0x40]
0000796d027d406b  vmovaps xmm5, [rsp+0x50]
0000796d027d4071  vmovaps xmm6, [rsp+0x60]
0000796d027d4077  vmovaps xmm7, [rsp+0x70]
0000796d027d407d  vmovaps xmm9, [rsp+0x80]
0000796d027d4086  vmovaps xmm10, [rsp+0x90]
0000796d027d408f  vmovaps xmm11, [rsp+0xA0]
0000796d027d4098  vmovaps xmm12, [rsp+0xB0]
0000796d027d40a1  vmovaps xmm13, [rsp+0xC0]
0000796d027d40aa  vmovaps xmm14, [rsp+0xD0]
0000796d027d40b3  vmovaps xmm15, [rsp+0xE0]
0000796d027d40bc  add rsp, 0xF0
0000796d027d40c3  pop r11
0000796d027d40c5  pop r10
0000796d027d40c7  pop r9
0000796d027d40c9  pop r8
0000796d027d40cb  pop rsi
0000796d027d40cc  pop rdi
0000796d027d40cd  pop rdx
0000796d027d40ce  pop rcx
0000796d027d40cf  pop rax
0000796d027d40d0  add rsp, 0x08
0000796d027d40d4  jmp 0x0000796D027D0094
0000796d027d40d9  sub rsp, 0x08
0000796d027d40dd  push rax
0000796d027d40de  push rcx
0000796d027d40df  push rdx
0000796d027d40e0  push rdi
0000796d027d40e1  push rsi
0000796d027d40e2  push r8
0000796d027d40e4  push r9
0000796d027d40e6  push r10
0000796d027d40e8  push r11
0000796d027d40ea  sub rsp, 0xF0
0000796d027d40f1  vmovaps [rsp], xmm0
0000796d027d40f6  vmovaps [rsp+0x10], xmm1
0000796d027d40fc  vmovaps [rsp+0x20], xmm2
0000796d027d4102  vmovaps [rsp+0x30], xmm3
0000796d027d4108  vmovaps [rsp+0x40], xmm4
0000796d027d410e  vmovaps [rsp+0x50], xmm5
0000796d027d4114  vmovaps [rsp+0x60], xmm6
0000796d027d411a  vmovaps [rsp+0x70], xmm7
0000796d027d4120  vmovaps [rsp+0x80], xmm8
0000796d027d4129  vmovaps [rsp+0x90], xmm9
0000796d027d4132  vmovaps [rsp+0xA0], xmm10
0000796d027d413b  vmovaps [rsp+0xB0], xmm11
0000796d027d4144  vmovaps [rsp+0xC0], xmm12
0000796d027d414d  vmovaps [rsp+0xD0], xmm13
0000796d027d4156  vmovaps [rsp+0xE0], xmm15
0000796d027d415f  sub rsp, 0x30
0000796d027d4163  movaps [rsp], xmm14
0000796d027d4168  movaps [rsp+0x10], xmm12
0000796d027d416e  movaps [rsp+0x20], xmm9
0000796d027d4174  lea rdi, [rsp]
0000796d027d4178  mov esi, 0x00
0000796d027d417d  mov rax, 0x635FBE957530
0000796d027d4187  call rax
0000796d027d4189  movaps xmm14, [rsp]
0000796d027d418e  add rsp, 0x30
0000796d027d4192  vmovaps xmm0, [rsp]
0000796d027d4197  vmovaps xmm1, [rsp+0x10]
0000796d027d419d  vmovaps xmm2, [rsp+0x20]
0000796d027d41a3  vmovaps xmm3, [rsp+0x30]
0000796d027d41a9  vmovaps xmm4, [rsp+0x40]
0000796d027d41af  vmovaps xmm5, [rsp+0x50]
0000796d027d41b5  vmovaps xmm6, [rsp+0x60]
0000796d027d41bb  vmovaps xmm7, [rsp+0x70]
0000796d027d41c1  vmovaps xmm8, [rsp+0x80]
0000796d027d41ca  vmovaps xmm9, [rsp+0x90]
0000796d027d41d3  vmovaps xmm10, [rsp+0xA0]
0000796d027d41dc  vmovaps xmm11, [rsp+0xB0]
0000796d027d41e5  vmovaps xmm12, [rsp+0xC0]
0000796d027d41ee  vmovaps xmm13, [rsp+0xD0]
0000796d027d41f7  vmovaps xmm15, [rsp+0xE0]
0000796d027d4200  add rsp, 0xF0
0000796d027d4207  pop r11
0000796d027d4209  pop r10
0000796d027d420b  pop r9
0000796d027d420d  pop r8
0000796d027d420f  pop rsi
0000796d027d4210  pop rdi
0000796d027d4211  pop rdx
0000796d027d4212  pop rcx
0000796d027d4213  pop rax
0000796d027d4214  add rsp, 0x08
0000796d027d4218  jmp 0x0000796D027D00AE
0000796d027d421d  sub rsp, 0x08
0000796d027d4221  push rax
0000796d027d4222  push rcx
0000796d027d4223  push rdx
0000796d027d4224  push rdi
0000796d027d4225  push rsi
0000796d027d4226  push r8
0000796d027d4228  push r9
0000796d027d422a  push r10
0000796d027d422c  push r11
0000796d027d422e  sub rsp, 0xF0
0000796d027d4235  vmovaps [rsp], xmm0
0000796d027d423a  vmovaps [rsp+0x10], xmm1
0000796d027d4240  vmovaps [rsp+0x20], xmm2
0000796d027d4246  vmovaps [rsp+0x30], xmm3
0000796d027d424c  vmovaps [rsp+0x40], xmm4
0000796d027d4252  vmovaps [rsp+0x50], xmm5
0000796d027d4258  vmovaps [rsp+0x60], xmm6
0000796d027d425e  vmovaps [rsp+0x70], xmm7
0000796d027d4264  vmovaps [rsp+0x80], xmm8
0000796d027d426d  vmovaps [rsp+0x90], xmm10
0000796d027d4276  vmovaps [rsp+0xA0], xmm11
0000796d027d427f  vmovaps [rsp+0xB0], xmm12
0000796d027d4288  vmovaps [rsp+0xC0], xmm13
0000796d027d4291  vmovaps [rsp+0xD0], xmm14
0000796d027d429a  vmovaps [rsp+0xE0], xmm15
0000796d027d42a3  sub rsp, 0x30
0000796d027d42a7  movaps [rsp], xmm9
0000796d027d42ac  movaps [rsp+0x10], xmm7
0000796d027d42b1  movaps [rsp+0x20], xmm12
0000796d027d42b7  lea rdi, [rsp]
0000796d027d42bb  mov esi, 0x00
0000796d027d42c0  mov rax, 0x635FBE957530
0000796d027d42ca  call rax
0000796d027d42cc  movaps xmm9, [rsp]
0000796d027d42d1  add rsp, 0x30
0000796d027d42d5  vmovaps xmm0, [rsp]
0000796d027d42da  vmovaps xmm1, [rsp+0x10]
0000796d027d42e0  vmovaps xmm2, [rsp+0x20]
0000796d027d42e6  vmovaps xmm3, [rsp+0x30]
0000796d027d42ec  vmovaps xmm4, [rsp+0x40]
0000796d027d42f2  vmovaps xmm5, [rsp+0x50]
0000796d027d42f8  vmovaps xmm6, [rsp+0x60]
0000796d027d42fe  vmovaps xmm7, [rsp+0x70]
0000796d027d4304  vmovaps xmm8, [rsp+0x80]
0000796d027d430d  vmovaps xmm10, [rsp+0x90]
0000796d027d4316  vmovaps xmm11, [rsp+0xA0]
0000796d027d431f  vmovaps xmm12, [rsp+0xB0]
0000796d027d4328  vmovaps xmm13, [rsp+0xC0]
0000796d027d4331  vmovaps xmm14, [rsp+0xD0]
0000796d027d433a  vmovaps xmm15, [rsp+0xE0]
0000796d027d4343  add rsp, 0xF0
0000796d027d434a  pop r11
0000796d027d434c  pop r10
0000796d027d434e  pop r9
0000796d027d4350  pop r8
0000796d027d4352  pop rsi
0000796d027d4353  pop rdi
0000796d027d4354  pop rdx
0000796d027d4355  pop rcx
0000796d027d4356  pop rax
0000796d027d4357  add rsp, 0x08
0000796d027d435b  jmp 0x0000796D027D00DD
0000796d027d4360  sub rsp, 0x08
0000796d027d4364  push rax
0000796d027d4365  push rcx
0000796d027d4366  push rdx
0000796d027d4367  push rdi
0000796d027d4368  push rsi
0000796d027d4369  push r8
0000796d027d436b  push r9
0000796d027d436d  push r10
0000796d027d436f  push r11
0000796d027d4371  sub rsp, 0xF0
0000796d027d4378  vmovaps [rsp], xmm0
0000796d027d437d  vmovaps [rsp+0x10], xmm1
0000796d027d4383  vmovaps [rsp+0x20], xmm2
0000796d027d4389  vmovaps [rsp+0x30], xmm3
0000796d027d438f  vmovaps [rsp+0x40], xmm4
0000796d027d4395  vmovaps [rsp+0x50], xmm5
0000796d027d439b  vmovaps [rsp+0x60], xmm6
0000796d027d43a1  vmovaps [rsp+0x70], xmm7
0000796d027d43a7  vmovaps [rsp+0x80], xmm8
0000796d027d43b0  vmovaps [rsp+0x90], xmm9
0000796d027d43b9  vmovaps [rsp+0xA0], xmm10
0000796d027d43c2  vmovaps [rsp+0xB0], xmm11
0000796d027d43cb  vmovaps [rsp+0xC0], xmm13
0000796d027d43d4  vmovaps [rsp+0xD0], xmm14
0000796d027d43dd  vmovaps [rsp+0xE0], xmm15
0000796d027d43e6  sub rsp, 0x30
0000796d027d43ea  movaps [rsp], xmm12
0000796d027d43ef  movaps [rsp+0x10], xmm15
0000796d027d43f5  movaps [rsp+0x20], xmm11
0000796d027d43fb  lea rdi, [rsp]
0000796d027d43ff  mov esi, 0x00
0000796d027d4404  mov rax, 0x635FBE957530
0000796d027d440e  call rax
0000796d027d4410  movaps xmm12, [rsp]
0000796d027d4415  add rsp, 0x30
0000796d027d4419  vmovaps xmm0, [rsp]
0000796d027d441e  vmovaps xmm1, [rsp+0x10]
0000796d027d4424  vmovaps xmm2, [rsp+0x20]
0000796d027d442a  vmovaps xmm3, [rsp+0x30]
0000796d027d4430  vmovaps xmm4, [rsp+0x40]
0000796d027d4436  vmovaps xmm5, [rsp+0x50]
0000796d027d443c  vmovaps xmm6, [rsp+0x60]
0000796d027d4442  vmovaps xmm7, [rsp+0x70]
0000796d027d4448  vmovaps xmm8, [rsp+0x80]
0000796d027d4451  vmovaps xmm9, [rsp+0x90]
0000796d027d445a  vmovaps xmm10, [rsp+0xA0]
0000796d027d4463  vmovaps xmm11, [rsp+0xB0]
0000796d027d446c  vmovaps xmm13, [rsp+0xC0]
0000796d027d4475  vmovaps xmm14, [rsp+0xD0]
0000796d027d447e  vmovaps xmm15, [rsp+0xE0]
0000796d027d4487  add rsp, 0xF0
0000796d027d448e  pop r11
0000796d027d4490  pop r10
0000796d027d4492  pop r9
0000796d027d4494  pop r8
0000796d027d4496  pop rsi
0000796d027d4497  pop rdi
0000796d027d4498  pop rdx
0000796d027d4499  pop rcx
0000796d027d449a  pop rax
0000796d027d449b  add rsp, 0x08
0000796d027d449f  jmp 0x0000796D027D00F7
0000796d027d44a4  sub rsp, 0x08
0000796d027d44a8  push rax
0000796d027d44a9  push rcx
0000796d027d44aa  push rdx
0000796d027d44ab  push rdi
0000796d027d44ac  push rsi
0000796d027d44ad  push r8
0000796d027d44af  push r9
0000796d027d44b1  push r10
0000796d027d44b3  push r11
0000796d027d44b5  sub rsp, 0xF0
0000796d027d44bc  vmovaps [rsp], xmm0
0000796d027d44c1  vmovaps [rsp+0x10], xmm1
0000796d027d44c7  vmovaps [rsp+0x20], xmm2
0000796d027d44cd  vmovaps [rsp+0x30], xmm3
0000796d027d44d3  vmovaps [rsp+0x40], xmm4
0000796d027d44d9  vmovaps [rsp+0x50], xmm5
0000796d027d44df  vmovaps [rsp+0x60], xmm6
0000796d027d44e5  vmovaps [rsp+0x70], xmm7
0000796d027d44eb  vmovaps [rsp+0x80], xmm8
0000796d027d44f4  vmovaps [rsp+0x90], xmm9
0000796d027d44fd  vmovaps [rsp+0xA0], xmm10
0000796d027d4506  vmovaps [rsp+0xB0], xmm12
0000796d027d450f  vmovaps [rsp+0xC0], xmm13
0000796d027d4518  vmovaps [rsp+0xD0], xmm14
0000796d027d4521  vmovaps [rsp+0xE0], xmm15
0000796d027d452a  sub rsp, 0x30
0000796d027d452e  movaps [rsp], xmm11
0000796d027d4533  movaps [rsp+0x10], xmm7
0000796d027d4538  movaps [rsp+0x20], xmm15
0000796d027d453e  lea rdi, [rsp]
0000796d027d4542  mov esi, 0x00
0000796d027d4547  mov rax, 0x635FBE957530
0000796d027d4551  call rax
0000796d027d4553  movaps xmm11, [rsp]
0000796d027d4558  add rsp, 0x30
0000796d027d455c  vmovaps xmm0, [rsp]
0000796d027d4561  vmovaps xmm1, [rsp+0x10]
0000796d027d4567  vmovaps xmm2, [rsp+0x20]
0000796d027d456d  vmovaps xmm3, [rsp+0x30]
0000796d027d4573  vmovaps xmm4, [rsp+0x40]
0000796d027d4579  vmovaps xmm5, [rsp+0x50]
0000796d027d457f  vmovaps xmm6, [rsp+0x60]
0000796d027d4585  vmovaps xmm7, [rsp+0x70]
0000796d027d458b  vmovaps xmm8, [rsp+0x80]
0000796d027d4594  vmovaps xmm9, [rsp+0x90]
0000796d027d459d  vmovaps xmm10, [rsp+0xA0]
0000796d027d45a6  vmovaps xmm12, [rsp+0xB0]
0000796d027d45af  vmovaps xmm13, [rsp+0xC0]
0000796d027d45b8  vmovaps xmm14, [rsp+0xD0]
0000796d027d45c1  vmovaps xmm15, [rsp+0xE0]
0000796d027d45ca  add rsp, 0xF0
0000796d027d45d1  pop r11
0000796d027d45d3  pop r10
0000796d027d45d5  pop r9
0000796d027d45d7  pop r8
0000796d027d45d9  pop rsi
0000796d027d45da  pop rdi
0000796d027d45db  pop rdx
0000796d027d45dc  pop rcx
0000796d027d45dd  pop rax
0000796d027d45de  add rsp, 0x08
0000796d027d45e2  jmp 0x0000796D027D0123
0000796d027d45e7  sub rsp, 0x08
0000796d027d45eb  push rax
0000796d027d45ec  push rcx
0000796d027d45ed  push rdx
0000796d027d45ee  push rdi
0000796d027d45ef  push rsi
0000796d027d45f0  push r8
0000796d027d45f2  push r9
0000796d027d45f4  push r10
0000796d027d45f6  push r11
0000796d027d45f8  sub rsp, 0xF0
0000796d027d45ff  vmovaps [rsp], xmm0
0000796d027d4604  vmovaps [rsp+0x10], xmm1
0000796d027d460a  vmovaps [rsp+0x20], xmm2
0000796d027d4610  vmovaps [rsp+0x30], xmm3
0000796d027d4616  vmovaps [rsp+0x40], xmm4
0000796d027d461c  vmovaps [rsp+0x50], xmm5
0000796d027d4622  vmovaps [rsp+0x60], xmm6
0000796d027d4628  vmovaps [rsp+0x70], xmm7
0000796d027d462e  vmovaps [rsp+0x80], xmm8
0000796d027d4637  vmovaps [rsp+0x90], xmm9
0000796d027d4640  vmovaps [rsp+0xA0], xmm10
0000796d027d4649  vmovaps [rsp+0xB0], xmm11
0000796d027d4652  vmovaps [rsp+0xC0], xmm12
0000796d027d465b  vmovaps [rsp+0xD0], xmm13
0000796d027d4664  vmovaps [rsp+0xE0], xmm14
0000796d027d466d  sub rsp, 0x30
0000796d027d4671  movaps [rsp], xmm15
0000796d027d4676  movaps [rsp+0x10], xmm10
0000796d027d467c  movaps [rsp+0x20], xmm13
0000796d027d4682  lea rdi, [rsp]
0000796d027d4686  mov esi, 0x00
0000796d027d468b  mov rax, 0x635FBE957530
0000796d027d4695  call rax
0000796d027d4697  movaps xmm15, [rsp]
0000796d027d469c  add rsp, 0x30
0000796d027d46a0  vmovaps xmm0, [rsp]
0000796d027d46a5  vmovaps xmm1, [rsp+0x10]
0000796d027d46ab  vmovaps xmm2, [rsp+0x20]
0000796d027d46b1  vmovaps xmm3, [rsp+0x30]
0000796d027d46b7  vmovaps xmm4, [rsp+0x40]
0000796d027d46bd  vmovaps xmm5, [rsp+0x50]
0000796d027d46c3  vmovaps xmm6, [rsp+0x60]
0000796d027d46c9  vmovaps xmm7, [rsp+0x70]
0000796d027d46cf  vmovaps xmm8, [rsp+0x80]
0000796d027d46d8  vmovaps xmm9, [rsp+0x90]
0000796d027d46e1  vmovaps xmm10, [rsp+0xA0]
0000796d027d46ea  vmovaps xmm11, [rsp+0xB0]
0000796d027d46f3  vmovaps xmm12, [rsp+0xC0]
0000796d027d46fc  vmovaps xmm13, [rsp+0xD0]
0000796d027d4705  vmovaps xmm14, [rsp+0xE0]
0000796d027d470e  add rsp, 0xF0
0000796d027d4715  pop r11
0000796d027d4717  pop r10
0000796d027d4719  pop r9
0000796d027d471b  pop r8
0000796d027d471d  pop rsi
0000796d027d471e  pop rdi
0000796d027d471f  pop rdx
0000796d027d4720  pop rcx
0000796d027d4721  pop rax
0000796d027d4722  add rsp, 0x08
0000796d027d4726  jmp 0x0000796D027D013D
0000796d027d472b  sub rsp, 0x08
0000796d027d472f  push rax
0000796d027d4730  push rcx
0000796d027d4731  push rdx
0000796d027d4732  push rdi
0000796d027d4733  push rsi
0000796d027d4734  push r8
0000796d027d4736  push r9
0000796d027d4738  push r10
0000796d027d473a  push r11
0000796d027d473c  sub rsp, 0xF0
0000796d027d4743  vmovaps [rsp], xmm0
0000796d027d4748  vmovaps [rsp+0x10], xmm1
0000796d027d474e  vmovaps [rsp+0x20], xmm2
0000796d027d4754  vmovaps [rsp+0x30], xmm3
0000796d027d475a  vmovaps [rsp+0x40], xmm4
0000796d027d4760  vmovaps [rsp+0x50], xmm5
0000796d027d4766  vmovaps [rsp+0x60], xmm6
0000796d027d476c  vmovaps [rsp+0x70], xmm7
0000796d027d4772  vmovaps [rsp+0x80], xmm8
0000796d027d477b  vmovaps [rsp+0x90], xmm9
0000796d027d4784  vmovaps [rsp+0xA0], xmm11
0000796d027d478d  vmovaps [rsp+0xB0], xmm12
0000796d027d4796  vmovaps [rsp+0xC0], xmm13
0000796d027d479f  vmovaps [rsp+0xD0], xmm14
0000796d027d47a8  vmovaps [rsp+0xE0], xmm15
0000796d027d47b1  sub rsp, 0x30
0000796d027d47b5  movaps [rsp], xmm10
0000796d027d47ba  movaps [rsp+0x10], xmm7
0000796d027d47bf  movaps [rsp+0x20], xmm13
0000796d027d47c5  lea rdi, [rsp]
0000796d027d47c9  mov esi, 0x00
0000796d027d47ce  mov rax, 0x635FBE957530
0000796d027d47d8  call rax
0000796d027d47da  movaps xmm10, [rsp]
0000796d027d47df  add rsp, 0x30
0000796d027d47e3  vmovaps xmm0, [rsp]
0000796d027d47e8  vmovaps xmm1, [rsp+0x10]
0000796d027d47ee  vmovaps xmm2, [rsp+0x20]
0000796d027d47f4  vmovaps xmm3, [rsp+0x30]
0000796d027d47fa  vmovaps xmm4, [rsp+0x40]
0000796d027d4800  vmovaps xmm5, [rsp+0x50]
0000796d027d4806  vmovaps xmm6, [rsp+0x60]
0000796d027d480c  vmovaps xmm7, [rsp+0x70]
0000796d027d4812  vmovaps xmm8, [rsp+0x80]
0000796d027d481b  vmovaps xmm9, [rsp+0x90]
0000796d027d4824  vmovaps xmm11, [rsp+0xA0]
0000796d027d482d  vmovaps xmm12, [rsp+0xB0]
0000796d027d4836  vmovaps xmm13, [rsp+0xC0]
0000796d027d483f  vmovaps xmm14, [rsp+0xD0]
0000796d027d4848  vmovaps xmm15, [rsp+0xE0]
0000796d027d4851  add rsp, 0xF0
0000796d027d4858  pop r11
0000796d027d485a  pop r10
0000796d027d485c  pop r9
0000796d027d485e  pop r8
0000796d027d4860  pop rsi
0000796d027d4861  pop rdi
0000796d027d4862  pop rdx
0000796d027d4863  pop rcx
0000796d027d4864  pop rax
0000796d027d4865  add rsp, 0x08
0000796d027d4869  jmp 0x0000796D027D0169
0000796d027d486e  sub rsp, 0x08
0000796d027d4872  push rax
0000796d027d4873  push rcx
0000796d027d4874  push rdx
0000796d027d4875  push rdi
0000796d027d4876  push rsi
0000796d027d4877  push r8
0000796d027d4879  push r9
0000796d027d487b  push r10
0000796d027d487d  push r11
0000796d027d487f  sub rsp, 0xF0
0000796d027d4886  vmovaps [rsp], xmm0
0000796d027d488b  vmovaps [rsp+0x10], xmm1
0000796d027d4891  vmovaps [rsp+0x20], xmm2
0000796d027d4897  vmovaps [rsp+0x30], xmm3
0000796d027d489d  vmovaps [rsp+0x40], xmm4
0000796d027d48a3  vmovaps [rsp+0x50], xmm5
0000796d027d48a9  vmovaps [rsp+0x60], xmm6
0000796d027d48af  vmovaps [rsp+0x70], xmm7
0000796d027d48b5  vmovaps [rsp+0x80], xmm8
0000796d027d48be  vmovaps [rsp+0x90], xmm9
0000796d027d48c7  vmovaps [rsp+0xA0], xmm10
0000796d027d48d0  vmovaps [rsp+0xB0], xmm11
0000796d027d48d9  vmovaps [rsp+0xC0], xmm12
0000796d027d48e2  vmovaps [rsp+0xD0], xmm14
0000796d027d48eb  vmovaps [rsp+0xE0], xmm15
0000796d027d48f4  sub rsp, 0x30
0000796d027d48f8  movaps [rsp], xmm13
0000796d027d48fd  movaps [rsp+0x10], xmm1
0000796d027d4902  movaps [rsp+0x20], xmm8
0000796d027d4908  lea rdi, [rsp]
0000796d027d490c  mov esi, 0x00
0000796d027d4911  mov rax, 0x635FBE957530
0000796d027d491b  call rax
0000796d027d491d  movaps xmm13, [rsp]
0000796d027d4922  add rsp, 0x30
0000796d027d4926  vmovaps xmm0, [rsp]
0000796d027d492b  vmovaps xmm1, [rsp+0x10]
0000796d027d4931  vmovaps xmm2, [rsp+0x20]
0000796d027d4937  vmovaps xmm3, [rsp+0x30]
0000796d027d493d  vmovaps xmm4, [rsp+0x40]
0000796d027d4943  vmovaps xmm5, [rsp+0x50]
0000796d027d4949  vmovaps xmm6, [rsp+0x60]
0000796d027d494f  vmovaps xmm7, [rsp+0x70]
0000796d027d4955  vmovaps xmm8, [rsp+0x80]
0000796d027d495e  vmovaps xmm9, [rsp+0x90]
0000796d027d4967  vmovaps xmm10, [rsp+0xA0]
0000796d027d4970  vmovaps xmm11, [rsp+0xB0]
0000796d027d4979  vmovaps xmm12, [rsp+0xC0]
0000796d027d4982  vmovaps xmm14, [rsp+0xD0]
0000796d027d498b  vmovaps xmm15, [rsp+0xE0]
0000796d027d4994  add rsp, 0xF0
0000796d027d499b  pop r11
0000796d027d499d  pop r10
0000796d027d499f  pop r9
0000796d027d49a1  pop r8
0000796d027d49a3  pop rsi
0000796d027d49a4  pop rdi
0000796d027d49a5  pop rdx
0000796d027d49a6  pop rcx
0000796d027d49a7  pop rax
0000796d027d49a8  add rsp, 0x08
0000796d027d49ac  jmp 0x0000796D027D0183
0000796d027d49b1  call 0x0000796D025FF430
0000796d027d49b6  jmp 0x0000796D027D018D
0000796d027d49bb  sub rsp, 0x08
0000796d027d49bf  push rax
0000796d027d49c0  push rcx
0000796d027d49c1  push rdx
0000796d027d49c2  push rdi
0000796d027d49c3  push rsi
0000796d027d49c4  push r8
0000796d027d49c6  push r9
0000796d027d49c8  push r10
0000796d027d49ca  push r11
0000796d027d49cc  sub rsp, 0xF0
0000796d027d49d3  vmovaps [rsp], xmm0
0000796d027d49d8  vmovaps [rsp+0x10], xmm1
0000796d027d49de  vmovaps [rsp+0x20], xmm2
0000796d027d49e4  vmovaps [rsp+0x30], xmm3
0000796d027d49ea  vmovaps [rsp+0x40], xmm4
0000796d027d49f0  vmovaps [rsp+0x50], xmm5
0000796d027d49f6  vmovaps [rsp+0x60], xmm6
0000796d027d49fc  vmovaps [rsp+0x70], xmm7
0000796d027d4a02  vmovaps [rsp+0x80], xmm9
0000796d027d4a0b  vmovaps [rsp+0x90], xmm10
0000796d027d4a14  vmovaps [rsp+0xA0], xmm11
0000796d027d4a1d  vmovaps [rsp+0xB0], xmm12
0000796d027d4a26  vmovaps [rsp+0xC0], xmm13
0000796d027d4a2f  vmovaps [rsp+0xD0], xmm14
0000796d027d4a38  vmovaps [rsp+0xE0], xmm15
0000796d027d4a41  sub rsp, 0x30
0000796d027d4a45  movaps [rsp], xmm8
0000796d027d4a4a  movaps [rsp+0x10], xmm14
0000796d027d4a50  movaps [rsp+0x20], xmm9
0000796d027d4a56  lea rdi, [rsp]
0000796d027d4a5a  mov esi, 0x00
0000796d027d4a5f  mov rax, 0x635FBE957530
0000796d027d4a69  call rax
0000796d027d4a6b  movaps xmm8, [rsp]
0000796d027d4a70  add rsp, 0x30
0000796d027d4a74  vmovaps xmm0, [rsp]
0000796d027d4a79  vmovaps xmm1, [rsp+0x10]
0000796d027d4a7f  vmovaps xmm2, [rsp+0x20]
0000796d027d4a85  vmovaps xmm3, [rsp+0x30]
0000796d027d4a8b  vmovaps xmm4, [rsp+0x40]
0000796d027d4a91  vmovaps xmm5, [rsp+0x50]
0000796d027d4a97  vmovaps xmm6, [rsp+0x60]
0000796d027d4a9d  vmovaps xmm7, [rsp+0x70]
0000796d027d4aa3  vmovaps xmm9, [rsp+0x80]
0000796d027d4aac  vmovaps xmm10, [rsp+0x90]
0000796d027d4ab5  vmovaps xmm11, [rsp+0xA0]
0000796d027d4abe  vmovaps xmm12, [rsp+0xB0]
0000796d027d4ac7  vmovaps xmm13, [rsp+0xC0]
0000796d027d4ad0  vmovaps xmm14, [rsp+0xD0]
0000796d027d4ad9  vmovaps xmm15, [rsp+0xE0]
0000796d027d4ae2  add rsp, 0xF0
0000796d027d4ae9  pop r11
0000796d027d4aeb  pop r10
0000796d027d4aed  pop r9
0000796d027d4aef  pop r8
0000796d027d4af1  pop rsi
0000796d027d4af2  pop rdi
0000796d027d4af3  pop rdx
0000796d027d4af4  pop rcx
0000796d027d4af5  pop rax
0000796d027d4af6  add rsp, 0x08
0000796d027d4afa  jmp 0x0000796D027D01AF
0000796d027d4aff  sub rsp, 0x08
0000796d027d4b03  push rax
0000796d027d4b04  push rcx
0000796d027d4b05  push rdx
0000796d027d4b06  push rdi
0000796d027d4b07  push rsi
0000796d027d4b08  push r8
0000796d027d4b0a  push r9
0000796d027d4b0c  push r10
0000796d027d4b0e  push r11
0000796d027d4b10  sub rsp, 0xF0
0000796d027d4b17  vmovaps [rsp], xmm0
0000796d027d4b1c  vmovaps [rsp+0x10], xmm1
0000796d027d4b22  vmovaps [rsp+0x20], xmm2
0000796d027d4b28  vmovaps [rsp+0x30], xmm3
0000796d027d4b2e  vmovaps [rsp+0x40], xmm4
0000796d027d4b34  vmovaps [rsp+0x50], xmm5
0000796d027d4b3a  vmovaps [rsp+0x60], xmm6
0000796d027d4b40  vmovaps [rsp+0x70], xmm7
0000796d027d4b46  vmovaps [rsp+0x80], xmm8
0000796d027d4b4f  vmovaps [rsp+0x90], xmm10
0000796d027d4b58  vmovaps [rsp+0xA0], xmm11
0000796d027d4b61  vmovaps [rsp+0xB0], xmm12
0000796d027d4b6a  vmovaps [rsp+0xC0], xmm13
0000796d027d4b73  vmovaps [rsp+0xD0], xmm14
0000796d027d4b7c  vmovaps [rsp+0xE0], xmm15
0000796d027d4b85  sub rsp, 0x30
0000796d027d4b89  movaps [rsp], xmm9
0000796d027d4b8e  movaps [rsp+0x10], xmm1
0000796d027d4b93  movaps [rsp+0x20], xmm14
0000796d027d4b99  lea rdi, [rsp]
0000796d027d4b9d  mov esi, 0x00
0000796d027d4ba2  mov rax, 0x635FBE957530
0000796d027d4bac  call rax
0000796d027d4bae  movaps xmm9, [rsp]
0000796d027d4bb3  add rsp, 0x30
0000796d027d4bb7  vmovaps xmm0, [rsp]
0000796d027d4bbc  vmovaps xmm1, [rsp+0x10]
0000796d027d4bc2  vmovaps xmm2, [rsp+0x20]
0000796d027d4bc8  vmovaps xmm3, [rsp+0x30]
0000796d027d4bce  vmovaps xmm4, [rsp+0x40]
0000796d027d4bd4  vmovaps xmm5, [rsp+0x50]
0000796d027d4bda  vmovaps xmm6, [rsp+0x60]
0000796d027d4be0  vmovaps xmm7, [rsp+0x70]
0000796d027d4be6  vmovaps xmm8, [rsp+0x80]
0000796d027d4bef  vmovaps xmm10, [rsp+0x90]
0000796d027d4bf8  vmovaps xmm11, [rsp+0xA0]
0000796d027d4c01  vmovaps xmm12, [rsp+0xB0]
0000796d027d4c0a  vmovaps xmm13, [rsp+0xC0]
0000796d027d4c13  vmovaps xmm14, [rsp+0xD0]
0000796d027d4c1c  vmovaps xmm15, [rsp+0xE0]
0000796d027d4c25  add rsp, 0xF0
0000796d027d4c2c  pop r11
0000796d027d4c2e  pop r10
0000796d027d4c30  pop r9
0000796d027d4c32  pop r8
0000796d027d4c34  pop rsi
0000796d027d4c35  pop rdi
0000796d027d4c36  pop rdx
0000796d027d4c37  pop rcx
0000796d027d4c38  pop rax
0000796d027d4c39  add rsp, 0x08
0000796d027d4c3d  jmp 0x0000796D027D01DD
0000796d027d4c42  sub rsp, 0x08
0000796d027d4c46  push rax
0000796d027d4c47  push rcx
0000796d027d4c48  push rdx
0000796d027d4c49  push rdi
0000796d027d4c4a  push rsi
0000796d027d4c4b  push r8
0000796d027d4c4d  push r9
0000796d027d4c4f  push r10
0000796d027d4c51  push r11
0000796d027d4c53  sub rsp, 0xF0
0000796d027d4c5a  vmovaps [rsp], xmm0
0000796d027d4c5f  vmovaps [rsp+0x10], xmm1
0000796d027d4c65  vmovaps [rsp+0x20], xmm2
0000796d027d4c6b  vmovaps [rsp+0x30], xmm3
0000796d027d4c71  vmovaps [rsp+0x40], xmm4
0000796d027d4c77  vmovaps [rsp+0x50], xmm5
0000796d027d4c7d  vmovaps [rsp+0x60], xmm6
0000796d027d4c83  vmovaps [rsp+0x70], xmm7
0000796d027d4c89  vmovaps [rsp+0x80], xmm8
0000796d027d4c92  vmovaps [rsp+0x90], xmm9
0000796d027d4c9b  vmovaps [rsp+0xA0], xmm10
0000796d027d4ca4  vmovaps [rsp+0xB0], xmm11
0000796d027d4cad  vmovaps [rsp+0xC0], xmm12
0000796d027d4cb6  vmovaps [rsp+0xD0], xmm13
0000796d027d4cbf  vmovaps [rsp+0xE0], xmm15
0000796d027d4cc8  sub rsp, 0x30
0000796d027d4ccc  movaps [rsp], xmm14
0000796d027d4cd1  movaps [rsp+0x10], xmm4
0000796d027d4cd6  movaps [rsp+0x20], xmm1
0000796d027d4cdb  lea rdi, [rsp]
0000796d027d4cdf  mov esi, 0x00
0000796d027d4ce4  mov rax, 0x635FBE957530
0000796d027d4cee  call rax
0000796d027d4cf0  movaps xmm14, [rsp]
0000796d027d4cf5  add rsp, 0x30
0000796d027d4cf9  vmovaps xmm0, [rsp]
0000796d027d4cfe  vmovaps xmm1, [rsp+0x10]
0000796d027d4d04  vmovaps xmm2, [rsp+0x20]
0000796d027d4d0a  vmovaps xmm3, [rsp+0x30]
0000796d027d4d10  vmovaps xmm4, [rsp+0x40]
0000796d027d4d16  vmovaps xmm5, [rsp+0x50]
0000796d027d4d1c  vmovaps xmm6, [rsp+0x60]
0000796d027d4d22  vmovaps xmm7, [rsp+0x70]
0000796d027d4d28  vmovaps xmm8, [rsp+0x80]
0000796d027d4d31  vmovaps xmm9, [rsp+0x90]
0000796d027d4d3a  vmovaps xmm10, [rsp+0xA0]
0000796d027d4d43  vmovaps xmm11, [rsp+0xB0]
0000796d027d4d4c  vmovaps xmm12, [rsp+0xC0]
0000796d027d4d55  vmovaps xmm13, [rsp+0xD0]
0000796d027d4d5e  vmovaps xmm15, [rsp+0xE0]
0000796d027d4d67  add rsp, 0xF0
0000796d027d4d6e  pop r11
0000796d027d4d70  pop r10
0000796d027d4d72  pop r9
0000796d027d4d74  pop r8
0000796d027d4d76  pop rsi
0000796d027d4d77  pop rdi
0000796d027d4d78  pop rdx
0000796d027d4d79  pop rcx
0000796d027d4d7a  pop rax
0000796d027d4d7b  add rsp, 0x08
0000796d027d4d7f  jmp 0x0000796D027D0203
0000796d027d4d84  sub rsp, 0x08
0000796d027d4d88  push rax
0000796d027d4d89  push rcx
0000796d027d4d8a  push rdx
0000796d027d4d8b  push rdi
0000796d027d4d8c  push rsi
0000796d027d4d8d  push r8
0000796d027d4d8f  push r9
0000796d027d4d91  push r10
0000796d027d4d93  push r11
0000796d027d4d95  sub rsp, 0xF0
0000796d027d4d9c  vmovaps [rsp], xmm0
0000796d027d4da1  vmovaps [rsp+0x10], xmm2
0000796d027d4da7  vmovaps [rsp+0x20], xmm3
0000796d027d4dad  vmovaps [rsp+0x30], xmm4
0000796d027d4db3  vmovaps [rsp+0x40], xmm5
0000796d027d4db9  vmovaps [rsp+0x50], xmm6
0000796d027d4dbf  vmovaps [rsp+0x60], xmm7
0000796d027d4dc5  vmovaps [rsp+0x70], xmm8
0000796d027d4dcb  vmovaps [rsp+0x80], xmm9
0000796d027d4dd4  vmovaps [rsp+0x90], xmm10
0000796d027d4ddd  vmovaps [rsp+0xA0], xmm11
0000796d027d4de6  vmovaps [rsp+0xB0], xmm12
0000796d027d4def  vmovaps [rsp+0xC0], xmm13
0000796d027d4df8  vmovaps [rsp+0xD0], xmm14
0000796d027d4e01  vmovaps [rsp+0xE0], xmm15
0000796d027d4e0a  sub rsp, 0x30
0000796d027d4e0e  movaps [rsp], xmm1
0000796d027d4e12  movaps [rsp+0x10], xmm12
0000796d027d4e18  movaps [rsp+0x20], xmm11
0000796d027d4e1e  lea rdi, [rsp]
0000796d027d4e22  mov esi, 0x00
0000796d027d4e27  mov rax, 0x635FBE957530
0000796d027d4e31  call rax
0000796d027d4e33  movaps xmm1, [rsp]
0000796d027d4e37  add rsp, 0x30
0000796d027d4e3b  vmovaps xmm0, [rsp]
0000796d027d4e40  vmovaps xmm2, [rsp+0x10]
0000796d027d4e46  vmovaps xmm3, [rsp+0x20]
0000796d027d4e4c  vmovaps xmm4, [rsp+0x30]
0000796d027d4e52  vmovaps xmm5, [rsp+0x40]
0000796d027d4e58  vmovaps xmm6, [rsp+0x50]
0000796d027d4e5e  vmovaps xmm7, [rsp+0x60]
0000796d027d4e64  vmovaps xmm8, [rsp+0x70]
0000796d027d4e6a  vmovaps xmm9, [rsp+0x80]
0000796d027d4e73  vmovaps xmm10, [rsp+0x90]
0000796d027d4e7c  vmovaps xmm11, [rsp+0xA0]
0000796d027d4e85  vmovaps xmm12, [rsp+0xB0]
0000796d027d4e8e  vmovaps xmm13, [rsp+0xC0]
0000796d027d4e97  vmovaps xmm14, [rsp+0xD0]
0000796d027d4ea0  vmovaps xmm15, [rsp+0xE0]
0000796d027d4ea9  add rsp, 0xF0
0000796d027d4eb0  pop r11
0000796d027d4eb2  pop r10
0000796d027d4eb4  pop r9
0000796d027d4eb6  pop r8
0000796d027d4eb8  pop rsi
0000796d027d4eb9  pop rdi
0000796d027d4eba  pop rdx
0000796d027d4ebb  pop rcx
0000796d027d4ebc  pop rax
0000796d027d4ebd  add rsp, 0x08
0000796d027d4ec1  jmp 0x0000796D027D0224
0000796d027d4ec6  call 0x0000796D026E20A0
0000796d027d4ecb  jmp 0x0000796D027D0232
0000796d027d4ed0  call 0x0000796D02609D70
0000796d027d4ed5  jmp 0x0000796D027D023C
0000796d027d4eda  sub rsp, 0x08
0000796d027d4ede  push rax
0000796d027d4edf  push rcx
0000796d027d4ee0  push rdx
0000796d027d4ee1  push rdi
0000796d027d4ee2  push rsi
0000796d027d4ee3  push r8
0000796d027d4ee5  push r9
0000796d027d4ee7  push r10
0000796d027d4ee9  push r11
0000796d027d4eeb  sub rsp, 0xF0
0000796d027d4ef2  vmovaps [rsp], xmm0
0000796d027d4ef7  vmovaps [rsp+0x10], xmm1
0000796d027d4efd  vmovaps [rsp+0x20], xmm2
0000796d027d4f03  vmovaps [rsp+0x30], xmm3
0000796d027d4f09  vmovaps [rsp+0x40], xmm4
0000796d027d4f0f  vmovaps [rsp+0x50], xmm5
0000796d027d4f15  vmovaps [rsp+0x60], xmm6
0000796d027d4f1b  vmovaps [rsp+0x70], xmm8
0000796d027d4f21  vmovaps [rsp+0x80], xmm9
0000796d027d4f2a  vmovaps [rsp+0x90], xmm10
0000796d027d4f33  vmovaps [rsp+0xA0], xmm11
0000796d027d4f3c  vmovaps [rsp+0xB0], xmm12
0000796d027d4f45  vmovaps [rsp+0xC0], xmm13
0000796d027d4f4e  vmovaps [rsp+0xD0], xmm14
0000796d027d4f57  vmovaps [rsp+0xE0], xmm15
0000796d027d4f60  sub rsp, 0x30
0000796d027d4f64  movaps [rsp], xmm7
0000796d027d4f68  movaps [rsp+0x10], xmm15
0000796d027d4f6e  movaps [rsp+0x20], xmm10
0000796d027d4f74  lea rdi, [rsp]
0000796d027d4f78  mov esi, 0x00
0000796d027d4f7d  mov rax, 0x635FBE957530
0000796d027d4f87  call rax
0000796d027d4f89  movaps xmm7, [rsp]
0000796d027d4f8d  add rsp, 0x30
0000796d027d4f91  vmovaps xmm0, [rsp]
0000796d027d4f96  vmovaps xmm1, [rsp+0x10]
0000796d027d4f9c  vmovaps xmm2, [rsp+0x20]
0000796d027d4fa2  vmovaps xmm3, [rsp+0x30]
0000796d027d4fa8  vmovaps xmm4, [rsp+0x40]
0000796d027d4fae  vmovaps xmm5, [rsp+0x50]
0000796d027d4fb4  vmovaps xmm6, [rsp+0x60]
0000796d027d4fba  vmovaps xmm8, [rsp+0x70]
0000796d027d4fc0  vmovaps xmm9, [rsp+0x80]
0000796d027d4fc9  vmovaps xmm10, [rsp+0x90]
0000796d027d4fd2  vmovaps xmm11, [rsp+0xA0]
0000796d027d4fdb  vmovaps xmm12, [rsp+0xB0]
0000796d027d4fe4  vmovaps xmm13, [rsp+0xC0]
0000796d027d4fed  vmovaps xmm14, [rsp+0xD0]
0000796d027d4ff6  vmovaps xmm15, [rsp+0xE0]
0000796d027d4fff  add rsp, 0xF0
0000796d027d5006  pop r11
0000796d027d5008  pop r10
0000796d027d500a  pop r9
0000796d027d500c  pop r8
0000796d027d500e  pop rsi
0000796d027d500f  pop rdi
0000796d027d5010  pop rdx
0000796d027d5011  pop rcx
0000796d027d5012  pop rax
0000796d027d5013  add rsp, 0x08
0000796d027d5017  jmp 0x0000796D027D025D
0000796d027d501c  sub rsp, 0x08
0000796d027d5020  push rax
0000796d027d5021  push rcx
0000796d027d5022  push rdx
0000796d027d5023  push rdi
0000796d027d5024  push rsi
0000796d027d5025  push r8
0000796d027d5027  push r9
0000796d027d5029  push r10
0000796d027d502b  push r11
0000796d027d502d  sub rsp, 0xF0
0000796d027d5034  vmovaps [rsp], xmm0
0000796d027d5039  vmovaps [rsp+0x10], xmm1
0000796d027d503f  vmovaps [rsp+0x20], xmm2
0000796d027d5045  vmovaps [rsp+0x30], xmm3
0000796d027d504b  vmovaps [rsp+0x40], xmm4
0000796d027d5051  vmovaps [rsp+0x50], xmm5
0000796d027d5057  vmovaps [rsp+0x60], xmm6
0000796d027d505d  vmovaps [rsp+0x70], xmm7
0000796d027d5063  vmovaps [rsp+0x80], xmm8
0000796d027d506c  vmovaps [rsp+0x90], xmm9
0000796d027d5075  vmovaps [rsp+0xA0], xmm11
0000796d027d507e  vmovaps [rsp+0xB0], xmm12
0000796d027d5087  vmovaps [rsp+0xC0], xmm13
0000796d027d5090  vmovaps [rsp+0xD0], xmm14
0000796d027d5099  vmovaps [rsp+0xE0], xmm15
0000796d027d50a2  sub rsp, 0x30
0000796d027d50a6  movaps [rsp], xmm10
0000796d027d50ab  movaps [rsp+0x10], xmm11
0000796d027d50b1  movaps [rsp+0x20], xmm15
0000796d027d50b7  lea rdi, [rsp]
0000796d027d50bb  mov esi, 0x00
0000796d027d50c0  mov rax, 0x635FBE957530
0000796d027d50ca  call rax
0000796d027d50cc  movaps xmm10, [rsp]
0000796d027d50d1  add rsp, 0x30
0000796d027d50d5  vmovaps xmm0, [rsp]
0000796d027d50da  vmovaps xmm1, [rsp+0x10]
0000796d027d50e0  vmovaps xmm2, [rsp+0x20]
0000796d027d50e6  vmovaps xmm3, [rsp+0x30]
0000796d027d50ec  vmovaps xmm4, [rsp+0x40]
0000796d027d50f2  vmovaps xmm5, [rsp+0x50]
0000796d027d50f8  vmovaps xmm6, [rsp+0x60]
0000796d027d50fe  vmovaps xmm7, [rsp+0x70]
0000796d027d5104  vmovaps xmm8, [rsp+0x80]
0000796d027d510d  vmovaps xmm9, [rsp+0x90]
0000796d027d5116  vmovaps xmm11, [rsp+0xA0]
0000796d027d511f  vmovaps xmm12, [rsp+0xB0]
0000796d027d5128  vmovaps xmm13, [rsp+0xC0]
0000796d027d5131  vmovaps xmm14, [rsp+0xD0]
0000796d027d513a  vmovaps xmm15, [rsp+0xE0]
0000796d027d5143  add rsp, 0xF0
0000796d027d514a  pop r11
0000796d027d514c  pop r10
0000796d027d514e  pop r9
0000796d027d5150  pop r8
0000796d027d5152  pop rsi
0000796d027d5153  pop rdi
0000796d027d5154  pop rdx
0000796d027d5155  pop rcx
0000796d027d5156  pop rax
0000796d027d5157  add rsp, 0x08
0000796d027d515b  jmp 0x0000796D027D028B
0000796d027d5160  sub rsp, 0x08
0000796d027d5164  push rax
0000796d027d5165  push rcx
0000796d027d5166  push rdx
0000796d027d5167  push rdi
0000796d027d5168  push rsi
0000796d027d5169  push r8
0000796d027d516b  push r9
0000796d027d516d  push r10
0000796d027d516f  push r11
0000796d027d5171  sub rsp, 0xF0
0000796d027d5178  vmovaps [rsp], xmm0
0000796d027d517d  vmovaps [rsp+0x10], xmm1
0000796d027d5183  vmovaps [rsp+0x20], xmm2
0000796d027d5189  vmovaps [rsp+0x30], xmm3
0000796d027d518f  vmovaps [rsp+0x40], xmm4
0000796d027d5195  vmovaps [rsp+0x50], xmm5
0000796d027d519b  vmovaps [rsp+0x60], xmm6
0000796d027d51a1  vmovaps [rsp+0x70], xmm7
0000796d027d51a7  vmovaps [rsp+0x80], xmm8
0000796d027d51b0  vmovaps [rsp+0x90], xmm9
0000796d027d51b9  vmovaps [rsp+0xA0], xmm10
0000796d027d51c2  vmovaps [rsp+0xB0], xmm12
0000796d027d51cb  vmovaps [rsp+0xC0], xmm13
0000796d027d51d4  vmovaps [rsp+0xD0], xmm14
0000796d027d51dd  vmovaps [rsp+0xE0], xmm15
0000796d027d51e6  sub rsp, 0x30
0000796d027d51ea  movaps [rsp], xmm11
0000796d027d51ef  movaps [rsp+0x10], xmm12
0000796d027d51f5  movaps [rsp+0x20], xmm15
0000796d027d51fb  lea rdi, [rsp]
0000796d027d51ff  mov esi, 0x00
0000796d027d5204  mov rax, 0x635FBE957530
0000796d027d520e  call rax
0000796d027d5210  movaps xmm11, [rsp]
0000796d027d5215  add rsp, 0x30
0000796d027d5219  vmovaps xmm0, [rsp]
0000796d027d521e  vmovaps xmm1, [rsp+0x10]
0000796d027d5224  vmovaps xmm2, [rsp+0x20]
0000796d027d522a  vmovaps xmm3, [rsp+0x30]
0000796d027d5230  vmovaps xmm4, [rsp+0x40]
0000796d027d5236  vmovaps xmm5, [rsp+0x50]
0000796d027d523c  vmovaps xmm6, [rsp+0x60]
0000796d027d5242  vmovaps xmm7, [rsp+0x70]
0000796d027d5248  vmovaps xmm8, [rsp+0x80]
0000796d027d5251  vmovaps xmm9, [rsp+0x90]
0000796d027d525a  vmovaps xmm10, [rsp+0xA0]
0000796d027d5263  vmovaps xmm12, [rsp+0xB0]
0000796d027d526c  vmovaps xmm13, [rsp+0xC0]
0000796d027d5275  vmovaps xmm14, [rsp+0xD0]
0000796d027d527e  vmovaps xmm15, [rsp+0xE0]
0000796d027d5287  add rsp, 0xF0
0000796d027d528e  pop r11
0000796d027d5290  pop r10
0000796d027d5292  pop r9
0000796d027d5294  pop r8
0000796d027d5296  pop rsi
0000796d027d5297  pop rdi
0000796d027d5298  pop rdx
0000796d027d5299  pop rcx
0000796d027d529a  pop rax
0000796d027d529b  add rsp, 0x08
0000796d027d529f  jmp 0x0000796D027D02B9
0000796d027d52a4  sub rsp, 0x08
0000796d027d52a8  push rax
0000796d027d52a9  push rcx
0000796d027d52aa  push rdx
0000796d027d52ab  push rdi
0000796d027d52ac  push rsi
0000796d027d52ad  push r8
0000796d027d52af  push r9
0000796d027d52b1  push r10
0000796d027d52b3  push r11
0000796d027d52b5  sub rsp, 0xF0
0000796d027d52bc  vmovaps [rsp], xmm0
0000796d027d52c1  vmovaps [rsp+0x10], xmm1
0000796d027d52c7  vmovaps [rsp+0x20], xmm2
0000796d027d52cd  vmovaps [rsp+0x30], xmm3
0000796d027d52d3  vmovaps [rsp+0x40], xmm4
0000796d027d52d9  vmovaps [rsp+0x50], xmm5
0000796d027d52df  vmovaps [rsp+0x60], xmm6
0000796d027d52e5  vmovaps [rsp+0x70], xmm7
0000796d027d52eb  vmovaps [rsp+0x80], xmm8
0000796d027d52f4  vmovaps [rsp+0x90], xmm9
0000796d027d52fd  vmovaps [rsp+0xA0], xmm10
0000796d027d5306  vmovaps [rsp+0xB0], xmm11
0000796d027d530f  vmovaps [rsp+0xC0], xmm12
0000796d027d5318  vmovaps [rsp+0xD0], xmm13
0000796d027d5321  vmovaps [rsp+0xE0], xmm14
0000796d027d532a  sub rsp, 0x30
0000796d027d532e  movaps [rsp], xmm15
0000796d027d5333  movaps [rsp+0x10], xmm13
0000796d027d5339  movaps [rsp+0x20], xmm9
0000796d027d533f  lea rdi, [rsp]
0000796d027d5343  mov esi, 0x00
0000796d027d5348  mov rax, 0x635FBE957530
0000796d027d5352  call rax
0000796d027d5354  movaps xmm15, [rsp]
0000796d027d5359  add rsp, 0x30
0000796d027d535d  vmovaps xmm0, [rsp]
0000796d027d5362  vmovaps xmm1, [rsp+0x10]
0000796d027d5368  vmovaps xmm2, [rsp+0x20]
0000796d027d536e  vmovaps xmm3, [rsp+0x30]
0000796d027d5374  vmovaps xmm4, [rsp+0x40]
0000796d027d537a  vmovaps xmm5, [rsp+0x50]
0000796d027d5380  vmovaps xmm6, [rsp+0x60]
0000796d027d5386  vmovaps xmm7, [rsp+0x70]
0000796d027d538c  vmovaps xmm8, [rsp+0x80]
0000796d027d5395  vmovaps xmm9, [rsp+0x90]
0000796d027d539e  vmovaps xmm10, [rsp+0xA0]
0000796d027d53a7  vmovaps xmm11, [rsp+0xB0]
0000796d027d53b0  vmovaps xmm12, [rsp+0xC0]
0000796d027d53b9  vmovaps xmm13, [rsp+0xD0]
0000796d027d53c2  vmovaps xmm14, [rsp+0xE0]
0000796d027d53cb  add rsp, 0xF0
0000796d027d53d2  pop r11
0000796d027d53d4  pop r10
0000796d027d53d6  pop r9
0000796d027d53d8  pop r8
0000796d027d53da  pop rsi
0000796d027d53db  pop rdi
0000796d027d53dc  pop rdx
0000796d027d53dd  pop rcx
0000796d027d53de  pop rax
0000796d027d53df  add rsp, 0x08
0000796d027d53e3  jmp 0x0000796D027D02D4
0000796d027d53e8  sub rsp, 0x08
0000796d027d53ec  push rax
0000796d027d53ed  push rcx
0000796d027d53ee  push rdx
0000796d027d53ef  push rdi
0000796d027d53f0  push rsi
0000796d027d53f1  push r8
0000796d027d53f3  push r9
0000796d027d53f5  push r10
0000796d027d53f7  push r11
0000796d027d53f9  sub rsp, 0xF0
0000796d027d5400  vmovaps [rsp], xmm0
0000796d027d5405  vmovaps [rsp+0x10], xmm1
0000796d027d540b  vmovaps [rsp+0x20], xmm2
0000796d027d5411  vmovaps [rsp+0x30], xmm3
0000796d027d5417  vmovaps [rsp+0x40], xmm4
0000796d027d541d  vmovaps [rsp+0x50], xmm5
0000796d027d5423  vmovaps [rsp+0x60], xmm6
0000796d027d5429  vmovaps [rsp+0x70], xmm7
0000796d027d542f  vmovaps [rsp+0x80], xmm8
0000796d027d5438  vmovaps [rsp+0x90], xmm9
0000796d027d5441  vmovaps [rsp+0xA0], xmm10
0000796d027d544a  vmovaps [rsp+0xB0], xmm11
0000796d027d5453  vmovaps [rsp+0xC0], xmm12
0000796d027d545c  vmovaps [rsp+0xD0], xmm14
0000796d027d5465  vmovaps [rsp+0xE0], xmm15
0000796d027d546e  sub rsp, 0x30
0000796d027d5472  movaps [rsp], xmm13
0000796d027d5477  movaps [rsp+0x10], xmm8
0000796d027d547d  movaps [rsp+0x20], xmm14
0000796d027d5483  lea rdi, [rsp]
0000796d027d5487  mov esi, 0x00
0000796d027d548c  mov rax, 0x635FBE957530
0000796d027d5496  call rax
0000796d027d5498  movaps xmm13, [rsp]
0000796d027d549d  add rsp, 0x30
0000796d027d54a1  vmovaps xmm0, [rsp]
0000796d027d54a6  vmovaps xmm1, [rsp+0x10]
0000796d027d54ac  vmovaps xmm2, [rsp+0x20]
0000796d027d54b2  vmovaps xmm3, [rsp+0x30]
0000796d027d54b8  vmovaps xmm4, [rsp+0x40]
0000796d027d54be  vmovaps xmm5, [rsp+0x50]
0000796d027d54c4  vmovaps xmm6, [rsp+0x60]
0000796d027d54ca  vmovaps xmm7, [rsp+0x70]
0000796d027d54d0  vmovaps xmm8, [rsp+0x80]
0000796d027d54d9  vmovaps xmm9, [rsp+0x90]
0000796d027d54e2  vmovaps xmm10, [rsp+0xA0]
0000796d027d54eb  vmovaps xmm11, [rsp+0xB0]
0000796d027d54f4  vmovaps xmm12, [rsp+0xC0]
0000796d027d54fd  vmovaps xmm14, [rsp+0xD0]
0000796d027d5506  vmovaps xmm15, [rsp+0xE0]
0000796d027d550f  add rsp, 0xF0
0000796d027d5516  pop r11
0000796d027d5518  pop r10
0000796d027d551a  pop r9
0000796d027d551c  pop r8
0000796d027d551e  pop rsi
0000796d027d551f  pop rdi
0000796d027d5520  pop rdx
0000796d027d5521  pop rcx
0000796d027d5522  pop rax
0000796d027d5523  add rsp, 0x08
0000796d027d5527  jmp 0x0000796D027D02F7
0000796d027d552c  sub rsp, 0x08
0000796d027d5530  push rax
0000796d027d5531  push rcx
0000796d027d5532  push rdx
0000796d027d5533  push rdi
0000796d027d5534  push rsi
0000796d027d5535  push r8
0000796d027d5537  push r9
0000796d027d5539  push r10
0000796d027d553b  push r11
0000796d027d553d  sub rsp, 0xF0
0000796d027d5544  vmovaps [rsp], xmm0
0000796d027d5549  vmovaps [rsp+0x10], xmm1
0000796d027d554f  vmovaps [rsp+0x20], xmm2
0000796d027d5555  vmovaps [rsp+0x30], xmm3
0000796d027d555b  vmovaps [rsp+0x40], xmm4
0000796d027d5561  vmovaps [rsp+0x50], xmm5
0000796d027d5567  vmovaps [rsp+0x60], xmm6
0000796d027d556d  vmovaps [rsp+0x70], xmm7
0000796d027d5573  vmovaps [rsp+0x80], xmm8
0000796d027d557c  vmovaps [rsp+0x90], xmm9
0000796d027d5585  vmovaps [rsp+0xA0], xmm10
0000796d027d558e  vmovaps [rsp+0xB0], xmm11
0000796d027d5597  vmovaps [rsp+0xC0], xmm12
0000796d027d55a0  vmovaps [rsp+0xD0], xmm13
0000796d027d55a9  vmovaps [rsp+0xE0], xmm15
0000796d027d55b2  sub rsp, 0x30
0000796d027d55b6  movaps [rsp], xmm14
0000796d027d55bb  movaps [rsp+0x10], xmm1
0000796d027d55c0  movaps [rsp+0x20], xmm10
0000796d027d55c6  lea rdi, [rsp]
0000796d027d55ca  mov esi, 0x00
0000796d027d55cf  mov rax, 0x635FBE957530
0000796d027d55d9  call rax
0000796d027d55db  movaps xmm14, [rsp]
0000796d027d55e0  add rsp, 0x30
0000796d027d55e4  vmovaps xmm0, [rsp]
0000796d027d55e9  vmovaps xmm1, [rsp+0x10]
0000796d027d55ef  vmovaps xmm2, [rsp+0x20]
0000796d027d55f5  vmovaps xmm3, [rsp+0x30]
0000796d027d55fb  vmovaps xmm4, [rsp+0x40]
0000796d027d5601  vmovaps xmm5, [rsp+0x50]
0000796d027d5607  vmovaps xmm6, [rsp+0x60]
0000796d027d560d  vmovaps xmm7, [rsp+0x70]
0000796d027d5613  vmovaps xmm8, [rsp+0x80]
0000796d027d561c  vmovaps xmm9, [rsp+0x90]
0000796d027d5625  vmovaps xmm10, [rsp+0xA0]
0000796d027d562e  vmovaps xmm11, [rsp+0xB0]
0000796d027d5637  vmovaps xmm12, [rsp+0xC0]
0000796d027d5640  vmovaps xmm13, [rsp+0xD0]
0000796d027d5649  vmovaps xmm15, [rsp+0xE0]
0000796d027d5652  add rsp, 0xF0
0000796d027d5659  pop r11
0000796d027d565b  pop r10
0000796d027d565d  pop r9
0000796d027d565f  pop r8
0000796d027d5661  pop rsi
0000796d027d5662  pop rdi
0000796d027d5663  pop rdx
0000796d027d5664  pop rcx
0000796d027d5665  pop rax
0000796d027d5666  add rsp, 0x08
0000796d027d566a  jmp 0x0000796D027D031A
0000796d027d566f  sub rsp, 0x08
0000796d027d5673  push rax
0000796d027d5674  push rcx
0000796d027d5675  push rdx
0000796d027d5676  push rdi
0000796d027d5677  push rsi
0000796d027d5678  push r8
0000796d027d567a  push r9
0000796d027d567c  push r10
0000796d027d567e  push r11
0000796d027d5680  sub rsp, 0xF0
0000796d027d5687  vmovaps [rsp], xmm0
0000796d027d568c  vmovaps [rsp+0x10], xmm2
0000796d027d5692  vmovaps [rsp+0x20], xmm3
0000796d027d5698  vmovaps [rsp+0x30], xmm4
0000796d027d569e  vmovaps [rsp+0x40], xmm5
0000796d027d56a4  vmovaps [rsp+0x50], xmm6
0000796d027d56aa  vmovaps [rsp+0x60], xmm7
0000796d027d56b0  vmovaps [rsp+0x70], xmm8
0000796d027d56b6  vmovaps [rsp+0x80], xmm9
0000796d027d56bf  vmovaps [rsp+0x90], xmm10
0000796d027d56c8  vmovaps [rsp+0xA0], xmm11
0000796d027d56d1  vmovaps [rsp+0xB0], xmm12
0000796d027d56da  vmovaps [rsp+0xC0], xmm13
0000796d027d56e3  vmovaps [rsp+0xD0], xmm14
0000796d027d56ec  vmovaps [rsp+0xE0], xmm15
0000796d027d56f5  sub rsp, 0x30
0000796d027d56f9  movaps [rsp], xmm1
0000796d027d56fd  movaps [rsp+0x10], xmm7
0000796d027d5702  movaps [rsp+0x20], xmm11
0000796d027d5708  lea rdi, [rsp]
0000796d027d570c  mov esi, 0x00
0000796d027d5711  mov rax, 0x635FBE957530
0000796d027d571b  call rax
0000796d027d571d  movaps xmm1, [rsp]
0000796d027d5721  add rsp, 0x30
0000796d027d5725  vmovaps xmm0, [rsp]
0000796d027d572a  vmovaps xmm2, [rsp+0x10]
0000796d027d5730  vmovaps xmm3, [rsp+0x20]
0000796d027d5736  vmovaps xmm4, [rsp+0x30]
0000796d027d573c  vmovaps xmm5, [rsp+0x40]
0000796d027d5742  vmovaps xmm6, [rsp+0x50]
0000796d027d5748  vmovaps xmm7, [rsp+0x60]
0000796d027d574e  vmovaps xmm8, [rsp+0x70]
0000796d027d5754  vmovaps xmm9, [rsp+0x80]
0000796d027d575d  vmovaps xmm10, [rsp+0x90]
0000796d027d5766  vmovaps xmm11, [rsp+0xA0]
0000796d027d576f  vmovaps xmm12, [rsp+0xB0]
0000796d027d5778  vmovaps xmm13, [rsp+0xC0]
0000796d027d5781  vmovaps xmm14, [rsp+0xD0]
0000796d027d578a  vmovaps xmm15, [rsp+0xE0]
0000796d027d5793  add rsp, 0xF0
0000796d027d579a  pop r11
0000796d027d579c  pop r10
0000796d027d579e  pop r9
0000796d027d57a0  pop r8
0000796d027d57a2  pop rsi
0000796d027d57a3  pop rdi
0000796d027d57a4  pop rdx
0000796d027d57a5  pop rcx
0000796d027d57a6  pop rax
0000796d027d57a7  add rsp, 0x08
0000796d027d57ab  jmp 0x0000796D027D033B
0000796d027d57b0  call 0x0000796D0260E880
0000796d027d57b5  jmp 0x0000796D027D034E
0000796d027d57ba  call 0x0000796D0260C380
0000796d027d57bf  jmp 0x0000796D027D0359
0000796d027d57c4  call 0x0000796D0260D600
0000796d027d57c9  jmp 0x0000796D027D0364
0000796d027d57ce  call 0x0000796D025FF540
0000796d027d57d3  jmp 0x0000796D027D036F
0000796d027d57d8  int3
0000796d027d57d9  nop [rax], eax
0000796d027d57e0  mov rax, [r15+0x40]
0000796d027d57e4  mov r14, [r15+0x58]
0000796d027d57e8  lea r12, [rax+r14*1]
0000796d027d57ec  movaps xmm1, [r15+0x1D0]
0000796d027d57f4  vmovaps [rsp+0x10], xmm1
0000796d027d57fa  vmovaps xmm15, [rsp+0x10]
0000796d027d5800  por xmm1, xmm15
0000796d027d5805  movaps xmm14, [r15+0x1A0]
0000796d027d580d  vmovaps [rsp+0x10], xmm14
0000796d027d5813  vmovaps xmm13, [rsp+0x10]
0000796d027d5819  por xmm14, xmm13
0000796d027d581e  lea rax, [r12+0x30]
0000796d027d5823  mov r11, [r13+rax*1]
0000796d027d5828  lea rax, [r12+0x38]
0000796d027d582d  mov r10, [r13+rax*1]
0000796d027d5832  movq xmm13, r11
0000796d027d5837  movq xmm12, r10
0000796d027d583c  movq xmm13, xmm13
0000796d027d5841  vmovaps [rsp+0x10], xmm13
0000796d027d5847  movq xmm13, xmm13
0000796d027d584c  movaps [r15+0x130], xmm13
0000796d027d5854  movq xmm12, xmm12
0000796d027d5859  vmovaps [rsp+0x20], xmm12
0000796d027d585f  movq xmm12, xmm12
0000796d027d5864  movaps [r15+0x280], xmm12
0000796d027d586c  movaps xmm13, [r15+0x270]
0000796d027d5874  vmovaps [rsp+0x30], xmm13
0000796d027d587a  vmovaps xmm12, [rsp+0x30]
0000796d027d5880  por xmm13, xmm12
0000796d027d5885  lea rax, [r12+0x20]
0000796d027d588a  mov r11, [r13+rax*1]
0000796d027d588f  lea rax, [r12+0x28]
0000796d027d5894  mov r10, [r13+rax*1]
0000796d027d5899  movq xmm12, r11
0000796d027d589e  movq xmm11, r10
0000796d027d58a3  movq xmm12, xmm12
0000796d027d58a8  vmovaps [rsp+0x30], xmm12
0000796d027d58ae  movq xmm12, xmm12
0000796d027d58b3  movaps [r15+0x150], xmm12
0000796d027d58bb  movq xmm11, xmm11
0000796d027d58c0  vmovaps [rsp+0x40], xmm11
0000796d027d58c6  movq xmm11, xmm11
0000796d027d58cb  movaps [r15+0x140], xmm11
0000796d027d58d3  lea rax, [r12+0x10]
0000796d027d58d8  mov r11, [r13+rax*1]
0000796d027d58dd  lea rax, [r12+0x18]
0000796d027d58e2  mov r10, [r13+rax*1]
0000796d027d58e7  movq xmm12, r11
0000796d027d58ec  movq xmm11, r10
0000796d027d58f1  movq xmm12, xmm12
0000796d027d58f6  vmovaps [rsp+0x50], xmm12
0000796d027d58fc  movq xmm12, xmm12
0000796d027d5901  movaps [r15+0x170], xmm12
0000796d027d5909  movq xmm11, xmm11
0000796d027d590e  vmovaps [rsp+0x60], xmm11
0000796d027d5914  movq xmm11, xmm11
0000796d027d5919  movaps [r15+0x160], xmm11
0000796d027d5921  mov rax, [r13+r12*1]
0000796d027d5926  vmovq xmm12, rax
0000796d027d592b  vpbroadcastq xmm12, xmm12
0000796d027d5930  lea rax, [r12+0x08]
0000796d027d5935  mov r12, [r13+rax*1]
0000796d027d593a  movq xmm11, r12
0000796d027d593f  movaps [r15+0x230], xmm11
0000796d027d5947  mov rax, [r15+0xF8]
0000796d027d594e  lea r12, [rax+0x50]
0000796d027d5952  movups xmm11, [r13+r12*1]
0000796d027d5958  lea r12, [rax+0x60]
0000796d027d595c  movups xmm10, [r13+r12*1]
0000796d027d5962  lea r12, [rax+0x30]
0000796d027d5966  movups xmm9, [r13+r12*1]
0000796d027d596c  mov r12, [r15+0x50]
0000796d027d5970  lea r11, [r12+r14*1]
0000796d027d5974  mov [r15+0x60], r11
0000796d027d5978  lea r12, [r14+0x40]
0000796d027d597c  mov [r15+0x58], r12
0000796d027d5980  movaps xmm8, xmm12
0000796d027d5984  mulpd xmm8, xmm15
0000796d027d5989  vcmppd xmm7, xmm8, xmm8, 0x03
0000796d027d598f  ptest xmm7, xmm7
0000796d027d5994  jnz 0x0000796D027D67B7
0000796d027d599a  movq xmm15, qword ptr [r15+0x230]
0000796d027d59a3  vmovaps [rsp+0x70], xmm15
0000796d027d59a9  vpermilpd xmm15, xmm15, 0x00
0000796d027d59af  movaps xmm7, xmm9
0000796d027d59b3  mulpd xmm7, xmm15
0000796d027d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
0000796d027d59bd  ptest xmm6, xmm6
0000796d027d59c2  jnz 0x0000796D027D68FB
0000796d027d59c8  vxorps xmm15, xmm15, xmm15
0000796d027d59cd  vpbroadcastq xmm15, xmm15
0000796d027d59d2  movaps xmm9, xmm12
0000796d027d59d6  mulpd xmm9, xmm10
0000796d027d59db  vcmppd xmm6, xmm9, xmm9, 0x03
0000796d027d59e1  ptest xmm6, xmm6
0000796d027d59e6  jnz 0x0000796D027D6A3D
0000796d027d59ec  movaps xmm10, xmm12
0000796d027d59f0  mulpd xmm10, xmm11
0000796d027d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
0000796d027d59fb  ptest xmm6, xmm6
0000796d027d5a00  jnz 0x0000796D027D6B81
0000796d027d5a06  movaps xmm11, [r15+0x1F0]
0000796d027d5a0e  movaps xmm6, xmm12
0000796d027d5a12  mulpd xmm6, xmm11
0000796d027d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
0000796d027d5a1c  ptest xmm5, xmm5
0000796d027d5a21  jnz 0x0000796D027D6CC5
0000796d027d5a27  movaps xmm12, [r15+0x2A0]
0000796d027d5a2f  vmovaps [rsp+0x80], xmm12
0000796d027d5a38  vmovaps xmm11, [rsp+0x80]
0000796d027d5a41  por xmm12, xmm11
0000796d027d5a46  movaps xmm11, [r15+0x250]
0000796d027d5a4e  vmovaps [rsp+0x80], xmm11
0000796d027d5a57  vmovaps xmm5, [rsp+0x80]
0000796d027d5a60  por xmm11, xmm5
0000796d027d5a65  vmovaps xmm4, [rsp+0x70]
0000796d027d5a6b  vpermilpd xmm4, xmm4, 0x00
0000796d027d5a71  movaps xmm3, xmm5
0000796d027d5a74  mulpd xmm3, xmm4
0000796d027d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
0000796d027d5a7d  ptest xmm2, xmm2
0000796d027d5a82  jnz 0x0000796D027D6E07
0000796d027d5a88  mov [rsp+0x80], rax
0000796d027d5a90  xor eax, eax
0000796d027d5a92  mov r14d, 0x200
0000796d027d5a98  cmp r12, r14
0000796d027d5a9b  cmc
0000796d027d5a9c  lahf
0000796d027d5a9d  seto al
0000796d027d5aa0  mov [r15+0x108], eax
0000796d027d5aa7  movaps xmm5, xmm8
0000796d027d5aab  addpd xmm5, xmm15
0000796d027d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
0000796d027d5ab5  ptest xmm4, xmm4
0000796d027d5aba  jnz 0x0000796D027D6F47
0000796d027d5ac0  movaps xmm8, [r15+0x1B0]
0000796d027d5ac8  movaps xmm4, xmm9
0000796d027d5acc  addpd xmm4, xmm8
0000796d027d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
0000796d027d5ad6  ptest xmm2, xmm2
0000796d027d5adb  jnz 0x0000796D027D7089
0000796d027d5ae1  movaps xmm9, xmm10
0000796d027d5ae5  addpd xmm9, xmm8
0000796d027d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
0000796d027d5af0  ptest xmm2, xmm2
0000796d027d5af5  jnz 0x0000796D027D71CB
0000796d027d5afb  movaps xmm10, [r15+0x2F0]
0000796d027d5b03  vmovaps [rsp+0x90], xmm10
0000796d027d5b0c  vmovaps xmm8, [rsp+0x90]
0000796d027d5b15  por xmm10, xmm8
0000796d027d5b1a  movaps xmm8, [r15+0x2E0]
0000796d027d5b22  vmovaps [rsp+0x90], xmm8
0000796d027d5b2b  vmovaps xmm2, [rsp+0x90]
0000796d027d5b34  por xmm8, xmm2
0000796d027d5b39  movaps xmm2, [r15+0x2D0]
0000796d027d5b41  vmovaps [rsp+0x90], xmm2
0000796d027d5b4a  vmovaps [rsp+0xA0], xmm1
0000796d027d5b53  vmovaps xmm1, [rsp+0x90]
0000796d027d5b5c  por xmm2, xmm1
0000796d027d5b60  movaps xmm1, [r15+0x200]
0000796d027d5b68  vmovaps [rsp+0x90], xmm1
0000796d027d5b71  vmovaps [rsp+0xB0], xmm15
0000796d027d5b7a  vmovaps xmm15, [rsp+0x90]
0000796d027d5b83  por xmm1, xmm15
0000796d027d5b88  movaps xmm15, [r15+0x1C0]
0000796d027d5b90  vmovaps [rsp+0x90], xmm15
0000796d027d5b99  vmovaps [rsp+0xC0], xmm1
0000796d027d5ba2  vmovaps xmm1, [rsp+0x90]
0000796d027d5bab  por xmm15, xmm1
0000796d027d5bb0  movaps xmm1, [r15+0x190]
0000796d027d5bb8  vmovaps [rsp+0x90], xmm1
0000796d027d5bc1  vmovaps [rsp+0xD0], xmm15
0000796d027d5bca  vmovaps xmm15, [rsp+0x90]
0000796d027d5bd3  por xmm1, xmm15
0000796d027d5bd8  movaps xmm15, [r15+0x300]
0000796d027d5be0  vmovaps [rsp+0x90], xmm15
0000796d027d5be9  vmovaps [rsp+0xE0], xmm1
0000796d027d5bf2  vmovaps xmm1, [rsp+0x90]
0000796d027d5bfb  por xmm15, xmm1
0000796d027d5c00  mov rax, [rsp+0x80]
0000796d027d5c08  lea r14, [rax+0xA0]
0000796d027d5c0f  movups xmm1, [r13+r14*1]
0000796d027d5c15  lea r14, [rax+0xB0]
0000796d027d5c1c  vmovaps [rsp+0x80], xmm1
0000796d027d5c25  movups xmm1, [r13+r14*1]
0000796d027d5c2b  vmovaps [rsp+0x90], xmm1
0000796d027d5c34  vmovaps [rsp+0xF0], xmm15
0000796d027d5c3d  vmovaps xmm15, [rsp+0xB0]
0000796d027d5c46  vmovaps [rsp+0xB0], xmm14
0000796d027d5c4f  movaps xmm1, xmm6
0000796d027d5c52  addpd xmm1, xmm15
0000796d027d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
0000796d027d5c5c  ptest xmm14, xmm14
0000796d027d5c62  jnz 0x0000796D027D7323
0000796d027d5c68  lea r14, [rax+0xF0]
0000796d027d5c6f  movups xmm15, [r13+r14*1]
0000796d027d5c75  movaps xmm14, xmm4
0000796d027d5c79  addpd xmm14, xmm3
0000796d027d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
0000796d027d5c84  ptest xmm6, xmm6
0000796d027d5c89  jnz 0x0000796D027D746E
0000796d027d5c8f  movaps xmm6, xmm9
0000796d027d5c93  addpd xmm6, xmm7
0000796d027d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
0000796d027d5c9c  ptest xmm4, xmm4
0000796d027d5ca1  jnz 0x0000796D027D75B0
0000796d027d5ca7  vmovaps xmm9, [rsp+0x70]
0000796d027d5cad  vpermilpd xmm9, xmm9, 0x00
0000796d027d5cb3  vmovaps xmm4, [rsp+0x90]
0000796d027d5cbc  movaps xmm7, xmm4
0000796d027d5cbf  mulpd xmm7, xmm9
0000796d027d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
0000796d027d5cc9  ptest xmm3, xmm3
0000796d027d5cce  jnz 0x0000796D027D76F1
0000796d027d5cd4  vmovaps xmm9, [rsp+0x50]
0000796d027d5cda  vpermilpd xmm9, xmm9, 0x00
0000796d027d5ce0  movaps xmm4, xmm15
0000796d027d5ce4  mulpd xmm4, xmm9
0000796d027d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
0000796d027d5cee  ptest xmm3, xmm3
0000796d027d5cf3  jnz 0x0000796D027D7832
0000796d027d5cf9  lea r14, [rax+0xE0]
0000796d027d5d00  movups xmm15, [r13+r14*1]
0000796d027d5d06  vmovaps xmm9, [rsp+0x70]
0000796d027d5d0c  vpermilpd xmm9, xmm9, 0x00
0000796d027d5d12  vmovaps [rsp+0x70], xmm1
0000796d027d5d18  vmovaps xmm1, [rsp+0x80]
0000796d027d5d21  vmovaps [rsp+0x80], xmm15
0000796d027d5d2a  movaps xmm3, xmm1
0000796d027d5d2d  mulpd xmm3, xmm9
0000796d027d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
0000796d027d5d37  ptest xmm15, xmm15
0000796d027d5d3d  jnz 0x0000796D027D797E
0000796d027d5d43  vmovaps xmm1, [rsp+0xF0]
0000796d027d5d4c  vmovaps xmm15, [rsp+0xF0]
0000796d027d5d55  por xmm1, xmm15
0000796d027d5d5a  movaps [r15+0x300], xmm1
0000796d027d5d62  vmovaps xmm15, [rsp+0xE0]
0000796d027d5d6b  vmovaps xmm9, [rsp+0xE0]
0000796d027d5d74  por xmm15, xmm9
0000796d027d5d79  movaps [r15+0x190], xmm15
0000796d027d5d81  vmovaps xmm9, [rsp+0x50]
0000796d027d5d87  vpermilpd xmm9, xmm9, 0x00
0000796d027d5d8d  vmovaps [rsp+0x90], xmm1
0000796d027d5d96  vmovaps [rsp+0xE0], xmm15
0000796d027d5d9f  vmovaps xmm15, [rsp+0x80]
0000796d027d5da8  vmovaps [rsp+0x80], xmm14
0000796d027d5db1  movaps xmm1, xmm15
0000796d027d5db5  mulpd xmm1, xmm9
0000796d027d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
0000796d027d5dbf  ptest xmm14, xmm14
0000796d027d5dc5  jnz 0x0000796D027D7ABF
0000796d027d5dcb  lea r14, [rax+0x90]
0000796d027d5dd2  movups xmm15, [r13+r14*1]
0000796d027d5dd8  vmovaps xmm14, [rsp+0xD0]
0000796d027d5de1  vmovaps xmm9, [rsp+0xD0]
0000796d027d5dea  por xmm14, xmm9
0000796d027d5def  movaps [r15+0x1C0], xmm14
0000796d027d5df7  vmovaps xmm9, [rsp+0xC0]
0000796d027d5e00  vmovaps [rsp+0xD0], xmm1
0000796d027d5e09  vmovaps xmm1, [rsp+0xC0]
0000796d027d5e12  por xmm9, xmm1
0000796d027d5e17  movaps [r15+0x200], xmm9
0000796d027d5e1f  vmovaps [rsp+0xC0], xmm2
0000796d027d5e28  vmovaps xmm1, [rsp+0xC0]
0000796d027d5e31  por xmm2, xmm1
0000796d027d5e35  movaps [r15+0x2D0], xmm2
0000796d027d5e3d  vmovaps [rsp+0xC0], xmm8
0000796d027d5e46  vmovaps xmm1, [rsp+0xC0]
0000796d027d5e4f  por xmm8, xmm1
0000796d027d5e54  movaps [r15+0x2E0], xmm8
0000796d027d5e5c  vmovaps [rsp+0xC0], xmm15
0000796d027d5e65  movaps xmm1, xmm5
0000796d027d5e68  addpd xmm1, xmm7
0000796d027d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
0000796d027d5e71  ptest xmm15, xmm15
0000796d027d5e77  jnz 0x0000796D027D7C0B
0000796d027d5e7d  vmovaps xmm15, [rsp+0x50]
0000796d027d5e83  vpermilpd xmm15, xmm15, 0x00
0000796d027d5e89  vmovaps xmm5, [rsp+0xC0]
0000796d027d5e92  vmovaps [rsp+0xC0], xmm1
0000796d027d5e9b  movaps xmm7, xmm5
0000796d027d5e9e  mulpd xmm7, xmm15
0000796d027d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
0000796d027d5ea8  ptest xmm1, xmm1
0000796d027d5ead  jnz 0x0000796D027D7D4B
0000796d027d5eb3  lea r14, [rax+0x80]
0000796d027d5eba  movups xmm1, [r13+r14*1]
0000796d027d5ec0  vmovaps xmm5, [rsp+0x70]
0000796d027d5ec6  vmovaps [rsp+0x70], xmm1
0000796d027d5ecc  movaps xmm15, xmm5
0000796d027d5ed0  addpd xmm15, xmm3
0000796d027d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
0000796d027d5edb  ptest xmm1, xmm1
0000796d027d5ee0  jnz 0x0000796D027D7E96
0000796d027d5ee6  vmovaps xmm5, [rsp+0x80]
0000796d027d5eef  movaps xmm1, xmm5
0000796d027d5ef2  addpd xmm1, xmm4
0000796d027d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
0000796d027d5efb  ptest xmm3, xmm3
0000796d027d5f00  jnz 0x0000796D027D7FD8
0000796d027d5f06  vmovaps [rsp+0x80], xmm10
0000796d027d5f0f  vmovaps xmm5, [rsp+0x80]
0000796d027d5f18  por xmm10, xmm5
0000796d027d5f1d  movaps [r15+0x2F0], xmm10
0000796d027d5f25  vmovaps xmm5, [rsp+0x50]
0000796d027d5f2b  vpermilpd xmm5, xmm5, 0x00
0000796d027d5f31  vmovaps xmm3, [rsp+0x70]
0000796d027d5f37  vmovaps [rsp+0x50], xmm1
0000796d027d5f3d  movaps xmm4, xmm3
0000796d027d5f40  mulpd xmm4, xmm5
0000796d027d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
0000796d027d5f49  ptest xmm1, xmm1
0000796d027d5f4e  jnz 0x0000796D027D8118
0000796d027d5f54  lea r14, [rax+0xD0]
0000796d027d5f5b  movups xmm1, [r13+r14*1]
0000796d027d5f61  vmovaps xmm3, [rsp+0xD0]
0000796d027d5f6a  vmovaps [rsp+0x70], xmm1
0000796d027d5f70  movaps xmm5, xmm6
0000796d027d5f73  addpd xmm5, xmm3
0000796d027d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
0000796d027d5f7c  ptest xmm1, xmm1
0000796d027d5f81  jnz 0x0000796D027D8262
0000796d027d5f87  vmovaps xmm1, [rsp+0x60]
0000796d027d5f8d  vpermilpd xmm1, xmm1, 0x00
0000796d027d5f93  movaps xmm6, xmm9
0000796d027d5f97  mulpd xmm6, xmm1
0000796d027d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
0000796d027d5fa0  ptest xmm3, xmm3
0000796d027d5fa5  jnz 0x0000796D027D83A2
0000796d027d5fab  movaps [r15+0x260], xmm6
0000796d027d5fb3  vxorps xmm1, xmm1, xmm1
0000796d027d5fb7  vpbroadcastq xmm1, xmm1
0000796d027d5fbc  movaps [r15+0x1B0], xmm1
0000796d027d5fc4  vmovaps xmm1, [rsp+0x60]
0000796d027d5fca  vpermilpd xmm1, xmm1, 0x00
0000796d027d5fd0  vmovaps xmm3, [rsp+0x70]
0000796d027d5fd6  vmovaps [rsp+0x70], xmm15
0000796d027d5fdc  movaps xmm9, xmm3
0000796d027d5fe0  mulpd xmm9, xmm1
0000796d027d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
0000796d027d5feb  ptest xmm15, xmm15
0000796d027d5ff1  jnz 0x0000796D027D84E3
0000796d027d5ff7  lea r14, [rax+0xC0]
0000796d027d5ffe  movups xmm1, [r13+r14*1]
0000796d027d6004  vmovaps xmm3, [rsp+0xC0]
0000796d027d600d  vmovaps [rsp+0x80], xmm1
0000796d027d6016  movaps xmm15, xmm3
0000796d027d601a  addpd xmm15, xmm7
0000796d027d601f  vcmppd xmm1, xmm15, xmm15, 0x03
0000796d027d6025  ptest xmm1, xmm1
0000796d027d602a  jnz 0x0000796D027D862F
0000796d027d6030  vmovaps [rsp+0xC0], xmm13
0000796d027d6039  vmovaps xmm1, [rsp+0xC0]
0000796d027d6042  por xmm13, xmm1
0000796d027d6047  movaps [r15+0x270], xmm13
0000796d027d604f  vmovaps xmm1, [rsp+0xB0]
0000796d027d6058  vmovaps xmm7, [rsp+0xB0]
0000796d027d6061  por xmm1, xmm7
0000796d027d6065  movaps [r15+0x1A0], xmm1
0000796d027d606d  vmovaps xmm1, [rsp+0x60]
0000796d027d6073  vpermilpd xmm1, xmm1, 0x00
0000796d027d6079  vmovaps [rsp+0xB0], xmm1
0000796d027d6082  vmovaps xmm1, [rsp+0x80]
0000796d027d608b  vmovaps [rsp+0x80], xmm15
0000796d027d6094  vmovaps xmm15, [rsp+0xB0]
0000796d027d609d  vmovaps [rsp+0xB0], xmm14
0000796d027d60a6  movaps xmm3, xmm1
0000796d027d60a9  mulpd xmm3, xmm15
0000796d027d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
0000796d027d60b3  ptest xmm14, xmm14
0000796d027d60b9  jnz 0x0000796D027D8771
0000796d027d60bf  lea r14, [rax+0x20]
0000796d027d60c3  movups xmm1, [r13+r14*1]
0000796d027d60c9  movaps [r15+0x110], xmm1
0000796d027d60d1  vmovaps xmm14, [rsp+0x70]
0000796d027d60d7  vmovaps [rsp+0x70], xmm1
0000796d027d60dd  movaps xmm15, xmm14
0000796d027d60e1  addpd xmm15, xmm4
0000796d027d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
0000796d027d60ec  ptest xmm1, xmm1
0000796d027d60f1  jnz 0x0000796D027D88BC
0000796d027d60f7  vmovaps xmm1, [rsp+0x60]
0000796d027d60fd  vpermilpd xmm1, xmm1, 0x00
0000796d027d6103  movaps xmm14, xmm2
0000796d027d6107  mulpd xmm14, xmm1
0000796d027d610c  vcmppd xmm4, xmm14, xmm14, 0x03
0000796d027d6112  ptest xmm4, xmm4
0000796d027d6117  jnz 0x0000796D027D89FF
0000796d027d611d  vmovaps xmm4, [rsp+0x50]
0000796d027d6123  movaps xmm1, xmm4
0000796d027d6126  addpd xmm1, xmm9
0000796d027d612b  vcmppd xmm2, xmm1, xmm1, 0x03
0000796d027d6130  ptest xmm2, xmm2
0000796d027d6135  jnz 0x0000796D027D8B41
0000796d027d613b  vmovaps xmm9, [rsp+0x30]
0000796d027d6141  vpermilpd xmm9, xmm9, 0x00
0000796d027d6147  vmovaps xmm2, [rsp+0x70]
0000796d027d614d  vmovaps [rsp+0x50], xmm1
0000796d027d6153  movaps xmm4, xmm2
0000796d027d6156  mulpd xmm4, xmm9
0000796d027d615b  vcmppd xmm1, xmm4, xmm4, 0x03
0000796d027d6160  ptest xmm1, xmm1
0000796d027d6165  jnz 0x0000796D027D8C82
0000796d027d616b  vmovaps xmm1, [rsp+0x30]
0000796d027d6171  vpermilpd xmm1, xmm1, 0x00
0000796d027d6177  vmovaps xmm2, [rsp+0x90]
0000796d027d6180  vmovaps [rsp+0x60], xmm15
0000796d027d6186  movaps xmm9, xmm2
0000796d027d618a  mulpd xmm9, xmm1
0000796d027d618f  vcmppd xmm15, xmm9, xmm9, 0x03
0000796d027d6195  ptest xmm15, xmm15
0000796d027d619b  jnz 0x0000796D027D8DC3
0000796d027d61a1  vmovaps xmm15, [rsp+0x80]
0000796d027d61aa  movaps xmm1, xmm15
0000796d027d61ae  addpd xmm1, xmm6
0000796d027d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
0000796d027d61b7  ptest xmm2, xmm2
0000796d027d61bc  jnz 0x0000796D027D8F05
0000796d027d61c2  movaps xmm15, xmm5
0000796d027d61c6  addpd xmm15, xmm3
0000796d027d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
0000796d027d61d1  ptest xmm6, xmm6
0000796d027d61d6  jnz 0x0000796D027D9046
0000796d027d61dc  vmovaps xmm6, [rsp+0x30]
0000796d027d61e2  vpermilpd xmm6, xmm6, 0x00
0000796d027d61e8  movaps xmm5, xmm8
0000796d027d61ec  mulpd xmm5, xmm6
0000796d027d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
0000796d027d61f5  ptest xmm3, xmm3
0000796d027d61fa  jnz 0x0000796D027D9188
0000796d027d6200  vmovaps xmm8, [rsp+0x30]
0000796d027d6206  vpermilpd xmm8, xmm8, 0x00
0000796d027d620c  movaps xmm6, xmm10
0000796d027d6210  mulpd xmm6, xmm8
0000796d027d6215  vcmppd xmm3, xmm6, xmm6, 0x03
0000796d027d621a  ptest xmm3, xmm3
0000796d027d621f  jnz 0x0000796D027D92C9
0000796d027d6225  vmovaps xmm8, [rsp+0x60]
0000796d027d622b  movaps xmm10, xmm8
0000796d027d622f  addpd xmm10, xmm14
0000796d027d6234  vcmppd xmm3, xmm10, xmm10, 0x03
0000796d027d623a  ptest xmm3, xmm3
0000796d027d623f  jnz 0x0000796D027D940B
0000796d027d6245  vmovaps xmm8, [rsp+0x50]
0000796d027d624b  movaps xmm14, xmm8
0000796d027d624f  addpd xmm14, xmm4
0000796d027d6254  vcmppd xmm3, xmm14, xmm14, 0x03
0000796d027d625a  ptest xmm3, xmm3
0000796d027d625f  jnz 0x0000796D027D954F
0000796d027d6265  vmovaps xmm8, [rsp+0x40]
0000796d027d626b  vpermilpd xmm8, xmm8, 0x00
0000796d027d6271  movaps xmm4, xmm13
0000796d027d6275  mulpd xmm4, xmm8
0000796d027d627a  vcmppd xmm3, xmm4, xmm4, 0x03
0000796d027d627f  ptest xmm3, xmm3
0000796d027d6284  jnz 0x0000796D027D9692
0000796d027d628a  movaps xmm13, xmm15
0000796d027d628e  addpd xmm13, xmm9
0000796d027d6293  vcmppd xmm8, xmm13, xmm13, 0x03
0000796d027d6299  ptest xmm8, xmm8
0000796d027d629f  jnz 0x0000796D027D97D4
0000796d027d62a5  movaps xmm15, xmm1
0000796d027d62a9  addpd xmm15, xmm5
0000796d027d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
0000796d027d62b4  ptest xmm9, xmm9
0000796d027d62ba  jnz 0x0000796D027D9918
0000796d027d62c0  vmovaps [rsp+0x30], xmm11
0000796d027d62c6  vmovaps xmm1, [rsp+0x30]
0000796d027d62cc  por xmm11, xmm1
0000796d027d62d1  movaps [r15+0x250], xmm11
0000796d027d62d9  vmovaps [rsp+0x30], xmm12
0000796d027d62df  vmovaps xmm1, [rsp+0x30]
0000796d027d62e5  por xmm12, xmm1
0000796d027d62ea  movaps [r15+0x2A0], xmm12
0000796d027d62f2  vmovaps xmm1, [rsp+0xA0]
0000796d027d62fb  vmovaps xmm11, [rsp+0xA0]
0000796d027d6304  por xmm1, xmm11
0000796d027d6309  movaps [r15+0x1D0], xmm1
0000796d027d6311  lea r14, [rax+0x40]
0000796d027d6315  movups xmm1, [r13+r14*1]
0000796d027d631b  movaps [r15+0x2C0], xmm1
0000796d027d6323  vmovaps xmm11, [rsp+0x40]
0000796d027d6329  vpermilpd xmm11, xmm11, 0x00
0000796d027d632f  vmovaps xmm8, [rsp+0xE0]
0000796d027d6338  movaps xmm9, xmm8
0000796d027d633c  mulpd xmm9, xmm11
0000796d027d6341  vcmppd xmm5, xmm9, xmm9, 0x03
0000796d027d6347  ptest xmm5, xmm5
0000796d027d634c  jnz 0x0000796D027D9A64
0000796d027d6352  movaps xmm11, xmm10
0000796d027d6356  addpd xmm11, xmm6
0000796d027d635b  vcmppd xmm8, xmm11, xmm11, 0x03
0000796d027d6361  ptest xmm8, xmm8
0000796d027d6367  jnz 0x0000796D027D9BA8
0000796d027d636d  movaps xmm10, xmm14
0000796d027d6371  addpd xmm10, xmm4
0000796d027d6376  vcmppd xmm8, xmm10, xmm10, 0x03
0000796d027d637c  ptest xmm8, xmm8
0000796d027d6382  jnz 0x0000796D027D9CEB
0000796d027d6388  vmovaps xmm14, [rsp+0x40]
0000796d027d638e  vpermilpd xmm14, xmm14, 0x00
0000796d027d6394  movaps xmm8, xmm1
0000796d027d6398  mulpd xmm8, xmm14
0000796d027d639d  vcmppd xmm6, xmm8, xmm8, 0x03
0000796d027d63a3  ptest xmm6, xmm6
0000796d027d63a8  jnz 0x0000796D027D9E2E
0000796d027d63ae  movaps xmm1, [r15+0x2B0]
0000796d027d63b6  vmovaps xmm14, [rsp+0x40]
0000796d027d63bc  vpermilpd xmm14, xmm14, 0x00
0000796d027d63c2  movaps xmm6, xmm1
0000796d027d63c5  mulpd xmm6, xmm14
0000796d027d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
0000796d027d63cf  ptest xmm5, xmm5
0000796d027d63d4  jnz 0x0000796D027D9F71
0000796d027d63da  vmovaps xmm1, [rsp+0x10]
0000796d027d63e0  vpermilpd xmm1, xmm1, 0x00
0000796d027d63e6  movaps xmm14, xmm12
0000796d027d63ea  mulpd xmm14, xmm1
0000796d027d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
0000796d027d63f5  ptest xmm5, xmm5
0000796d027d63fa  jnz 0x0000796D027DA0B2
0000796d027d6400  movaps xmm1, xmm13
0000796d027d6404  addpd xmm1, xmm9
0000796d027d6409  vcmppd xmm12, xmm1, xmm1, 0x03
0000796d027d640e  ptest xmm12, xmm12
0000796d027d6414  jnz 0x0000796D027DA1F5
0000796d027d641a  vmovaps xmm13, [rsp+0x10]
0000796d027d6420  vpermilpd xmm13, xmm13, 0x00
0000796d027d6426  movaps xmm12, xmm7
0000796d027d642a  mulpd xmm12, xmm13
0000796d027d642f  vcmppd xmm9, xmm12, xmm12, 0x03
0000796d027d6435  ptest xmm9, xmm9
0000796d027d643b  jnz 0x0000796D027DA337
0000796d027d6441  movaps xmm13, xmm15
0000796d027d6445  addpd xmm13, xmm8
0000796d027d644a  vcmppd xmm9, xmm13, xmm13, 0x03
0000796d027d6450  ptest xmm9, xmm9
0000796d027d6456  jnz 0x0000796D027DA47A
0000796d027d645c  movaps xmm15, [r15+0x290]
0000796d027d6464  vmovaps xmm9, [rsp+0x10]
0000796d027d646a  vpermilpd xmm9, xmm9, 0x00
0000796d027d6470  movaps xmm8, xmm15
0000796d027d6474  mulpd xmm8, xmm9
0000796d027d6479  vcmppd xmm7, xmm8, xmm8, 0x03
0000796d027d647f  ptest xmm7, xmm7
0000796d027d6484  jnz 0x0000796D027DA5BE
0000796d027d648a  movaps xmm15, xmm11
0000796d027d648e  addpd xmm15, xmm6
0000796d027d6493  vcmppd xmm9, xmm15, xmm15, 0x03
0000796d027d6499  ptest xmm9, xmm9
0000796d027d649f  jnz 0x0000796D027DA702
0000796d027d64a5  movaps xmm11, [r15+0x1E0]
0000796d027d64ad  vmovaps xmm9, [rsp+0x10]
0000796d027d64b3  vpermilpd xmm9, xmm9, 0x00
0000796d027d64b9  movaps xmm7, xmm11
0000796d027d64bd  mulpd xmm7, xmm9
0000796d027d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
0000796d027d64c7  ptest xmm6, xmm6
0000796d027d64cc  jnz 0x0000796D027DA845
0000796d027d64d2  movaps xmm11, xmm10
0000796d027d64d6  addpd xmm11, xmm14
0000796d027d64db  vcmppd xmm9, xmm11, xmm11, 0x03
0000796d027d64e1  ptest xmm9, xmm9
0000796d027d64e7  jnz 0x0000796D027DA987
0000796d027d64ed  lea r14, [rax+0x70]
0000796d027d64f1  movups xmm14, [r13+r14*1]
0000796d027d64f7  movaps [r15+0x240], xmm14
0000796d027d64ff  movaps xmm10, xmm1
0000796d027d6503  addpd xmm10, xmm12
0000796d027d6508  vcmppd xmm9, xmm10, xmm10, 0x03
0000796d027d650e  ptest xmm9, xmm9
0000796d027d6514  jnz 0x0000796D027DAAD5
0000796d027d651a  movaps [r15+0x170], xmm10
0000796d027d6522  vmovaps xmm1, [rsp+0x20]
0000796d027d6528  vpermilpd xmm1, xmm1, 0x00
0000796d027d652e  movaps xmm12, xmm14
0000796d027d6532  mulpd xmm12, xmm1
0000796d027d6537  vcmppd xmm9, xmm12, xmm12, 0x03
0000796d027d653d  ptest xmm9, xmm9
0000796d027d6543  jnz 0x0000796D027DAC18
0000796d027d6549  vmovaps xmm1, [rsp+0x20]
0000796d027d654f  vpermilpd xmm1, xmm1, 0x00
0000796d027d6555  vmovaps xmm9, [rsp+0xB0]
0000796d027d655e  movaps xmm14, xmm9
0000796d027d6562  mulpd xmm14, xmm1
0000796d027d6567  vcmppd xmm6, xmm14, xmm14, 0x03
0000796d027d656d  ptest xmm6, xmm6
0000796d027d6572  jnz 0x0000796D027DAD5B
0000796d027d6578  movaps [r15+0x180], xmm14
0000796d027d6580  movaps xmm1, xmm13
0000796d027d6584  addpd xmm1, xmm8
0000796d027d6589  vcmppd xmm9, xmm1, xmm1, 0x03
0000796d027d658e  ptest xmm9, xmm9
0000796d027d6594  jnz 0x0000796D027DAE9E
0000796d027d659a  movaps [r15+0x210], xmm1
0000796d027d65a2  movups xmm13, [r13+rax*1]
0000796d027d65a8  lea r14, [rax+0x10]
0000796d027d65ac  movups xmm9, [r13+r14*1]
0000796d027d65b2  movaps [r15+0x230], xmm9
0000796d027d65ba  movaps xmm8, xmm15
0000796d027d65be  addpd xmm8, xmm7
0000796d027d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
0000796d027d65c9  ptest xmm6, xmm6
0000796d027d65ce  jnz 0x0000796D027DAFF4
0000796d027d65d4  movaps [r15+0x130], xmm8
0000796d027d65dc  vmovaps xmm15, [rsp+0x20]
0000796d027d65e2  vpermilpd xmm15, xmm15, 0x00
0000796d027d65e8  movaps xmm7, xmm9
0000796d027d65ec  mulpd xmm7, xmm15
0000796d027d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
0000796d027d65f6  ptest xmm6, xmm6
0000796d027d65fb  jnz 0x0000796D027DB137
0000796d027d6601  movaps [r15+0x220], xmm7
0000796d027d6609  vmovaps xmm15, [rsp+0x20]
0000796d027d660f  vpermilpd xmm15, xmm15, 0x00
0000796d027d6615  movaps xmm9, xmm13
0000796d027d6619  mulpd xmm9, xmm15
0000796d027d661e  vcmppd xmm6, xmm9, xmm9, 0x03
0000796d027d6624  ptest xmm6, xmm6
0000796d027d6629  jnz 0x0000796D027DB279
0000796d027d662f  movaps xmm15, xmm11
0000796d027d6633  addpd xmm15, xmm12
0000796d027d6638  vcmppd xmm13, xmm15, xmm15, 0x03
0000796d027d663e  ptest xmm13, xmm13
0000796d027d6644  jnz 0x0000796D027DB3BD
0000796d027d664a  movaps [r15+0x140], xmm15
0000796d027d6652  movaps xmm13, xmm10
0000796d027d6656  addpd xmm13, xmm14
0000796d027d665b  vcmppd xmm12, xmm13, xmm13, 0x03
0000796d027d6661  ptest xmm12, xmm12
0000796d027d6667  jnz 0x0000796D027DB501
0000796d027d666d  movaps [r15+0x150], xmm13
0000796d027d6675  movaps xmm14, xmm1
0000796d027d6679  addpd xmm14, xmm7
0000796d027d667e  vcmppd xmm12, xmm14, xmm14, 0x03
0000796d027d6684  ptest xmm12, xmm12
0000796d027d668a  jnz 0x0000796D027DB645
0000796d027d6690  movaps [r15+0x160], xmm14
0000796d027d6698  movaps xmm1, xmm8
0000796d027d669c  addpd xmm1, xmm9
0000796d027d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
0000796d027d66a6  ptest xmm12, xmm12
0000796d027d66ac  jnz 0x0000796D027DB787
0000796d027d66b2  movaps [r15+0x120], xmm1
0000796d027d66ba  movups [r13+r11*1], xmm15
0000796d027d66c0  lea rax, [r11+0x10]
0000796d027d66c4  movups [r13+rax*1], xmm13
0000796d027d66ca  lea rax, [r11+0x20]
0000796d027d66ce  movups [r13+rax*1], xmm14
0000796d027d66d4  lea rax, [r11+0x30]
0000796d027d66d8  movups [r13+rax*1], xmm1
0000796d027d66de  mov eax, [r15+0x108]
0000796d027d66e5  sahf
0000796d027d66e6  jnz 0x0000796D027D6718
0000796d027d66e8  cmp dword ptr [r15+0x318], 0x00
0000796d027d66f0  jz 0x0000796D027DB900
0000796d027d66f6  nop [rax+rax*1], ax
0000796d027d66ff  nop [rax+rax*1], eax
0000796d027d6707  mov eax, 0x410444
0000796d027d670c  mov [r15+0x100], rax
0000796d027d6713  jmp 0x0000796D025FE110
0000796d027d6718  cmp dword ptr [r15+0x318], 0x00
0000796d027d6720  jz 0x0000796D027D57E0
0000796d027d6726  nop [rax+rax*1], ax
0000796d027d672f  nop [rax+rax*1], eax
0000796d027d6737  mov eax, 0x410278
0000796d027d673c  mov [r15+0x100], rax
0000796d027d6743  jmp 0x0000796D025FE110
0000796d027d6748  int3
0000796d027d6749  call 0x0000796D0260A4B0
0000796d027d674e  jmp 0x0000796D027D5828
0000796d027d6753  call 0x0000796D02609240
0000796d027d6758  jmp 0x0000796D027D5832
0000796d027d675d  call 0x0000796D0260A4B0
0000796d027d6762  jmp 0x0000796D027D588F
0000796d027d6767  call 0x0000796D02609240
0000796d027d676c  jmp 0x0000796D027D5899
0000796d027d6771  call 0x0000796D0260A4B0
0000796d027d6776  jmp 0x0000796D027D58DD
0000796d027d677b  call 0x0000796D02609240
0000796d027d6780  jmp 0x0000796D027D58E7
0000796d027d6785  call 0x0000796D026B47C0
0000796d027d678a  jmp 0x0000796D027D5926
0000796d027d678f  call 0x0000796D0260B720
0000796d027d6794  jmp 0x0000796D027D593A
0000796d027d6799  call 0x0000796D026BFC30
0000796d027d679e  jmp 0x0000796D027D5958
0000796d027d67a3  call 0x0000796D026BE9C0
0000796d027d67a8  jmp 0x0000796D027D5962
0000796d027d67ad  call 0x0000796D026BD750
0000796d027d67b2  jmp 0x0000796D027D596C
0000796d027d67b7  sub rsp, 0x08
0000796d027d67bb  push rax
0000796d027d67bc  push rcx
0000796d027d67bd  push rdx
0000796d027d67be  push rdi
0000796d027d67bf  push rsi
0000796d027d67c0  push r8
0000796d027d67c2  push r9
0000796d027d67c4  push r10
0000796d027d67c6  push r11
0000796d027d67c8  sub rsp, 0xF0
0000796d027d67cf  vmovaps [rsp], xmm0
0000796d027d67d4  vmovaps [rsp+0x10], xmm1
0000796d027d67da  vmovaps [rsp+0x20], xmm2
0000796d027d67e0  vmovaps [rsp+0x30], xmm3
0000796d027d67e6  vmovaps [rsp+0x40], xmm4
0000796d027d67ec  vmovaps [rsp+0x50], xmm5
0000796d027d67f2  vmovaps [rsp+0x60], xmm6
0000796d027d67f8  vmovaps [rsp+0x70], xmm7
0000796d027d67fe  vmovaps [rsp+0x80], xmm9
0000796d027d6807  vmovaps [rsp+0x90], xmm10
0000796d027d6810  vmovaps [rsp+0xA0], xmm11
0000796d027d6819  vmovaps [rsp+0xB0], xmm12
0000796d027d6822  vmovaps [rsp+0xC0], xmm13
0000796d027d682b  vmovaps [rsp+0xD0], xmm14
0000796d027d6834  vmovaps [rsp+0xE0], xmm15
0000796d027d683d  sub rsp, 0x30
0000796d027d6841  movaps [rsp], xmm8
0000796d027d6846  movaps [rsp+0x10], xmm12
0000796d027d684c  movaps [rsp+0x20], xmm15
0000796d027d6852  lea rdi, [rsp]
0000796d027d6856  mov esi, 0x00
0000796d027d685b  mov rax, 0x635FBE957530
0000796d027d6865  call rax
0000796d027d6867  movaps xmm8, [rsp]
0000796d027d686c  add rsp, 0x30
0000796d027d6870  vmovaps xmm0, [rsp]
0000796d027d6875  vmovaps xmm1, [rsp+0x10]
0000796d027d687b  vmovaps xmm2, [rsp+0x20]
0000796d027d6881  vmovaps xmm3, [rsp+0x30]
0000796d027d6887  vmovaps xmm4, [rsp+0x40]
0000796d027d688d  vmovaps xmm5, [rsp+0x50]
0000796d027d6893  vmovaps xmm6, [rsp+0x60]
0000796d027d6899  vmovaps xmm7, [rsp+0x70]
0000796d027d689f  vmovaps xmm9, [rsp+0x80]
0000796d027d68a8  vmovaps xmm10, [rsp+0x90]
0000796d027d68b1  vmovaps xmm11, [rsp+0xA0]
0000796d027d68ba  vmovaps xmm12, [rsp+0xB0]
0000796d027d68c3  vmovaps xmm13, [rsp+0xC0]
0000796d027d68cc  vmovaps xmm14, [rsp+0xD0]
0000796d027d68d5  vmovaps xmm15, [rsp+0xE0]
0000796d027d68de  add rsp, 0xF0
0000796d027d68e5  pop r11
0000796d027d68e7  pop r10
0000796d027d68e9  pop r9
0000796d027d68eb  pop r8
0000796d027d68ed  pop rsi
0000796d027d68ee  pop rdi
0000796d027d68ef  pop rdx
0000796d027d68f0  pop rcx
0000796d027d68f1  pop rax
0000796d027d68f2  add rsp, 0x08
0000796d027d68f6  jmp 0x0000796D027D599A
0000796d027d68fb  sub rsp, 0x08
0000796d027d68ff  push rax
0000796d027d6900  push rcx
0000796d027d6901  push rdx
0000796d027d6902  push rdi
0000796d027d6903  push rsi
0000796d027d6904  push r8
0000796d027d6906  push r9
0000796d027d6908  push r10
0000796d027d690a  push r11
0000796d027d690c  sub rsp, 0xF0
0000796d027d6913  vmovaps [rsp], xmm0
0000796d027d6918  vmovaps [rsp+0x10], xmm1
0000796d027d691e  vmovaps [rsp+0x20], xmm2
0000796d027d6924  vmovaps [rsp+0x30], xmm3
0000796d027d692a  vmovaps [rsp+0x40], xmm4
0000796d027d6930  vmovaps [rsp+0x50], xmm5
0000796d027d6936  vmovaps [rsp+0x60], xmm6
0000796d027d693c  vmovaps [rsp+0x70], xmm8
0000796d027d6942  vmovaps [rsp+0x80], xmm9
0000796d027d694b  vmovaps [rsp+0x90], xmm10
0000796d027d6954  vmovaps [rsp+0xA0], xmm11
0000796d027d695d  vmovaps [rsp+0xB0], xmm12
0000796d027d6966  vmovaps [rsp+0xC0], xmm13
0000796d027d696f  vmovaps [rsp+0xD0], xmm14
0000796d027d6978  vmovaps [rsp+0xE0], xmm15
0000796d027d6981  sub rsp, 0x30
0000796d027d6985  movaps [rsp], xmm7
0000796d027d6989  movaps [rsp+0x10], xmm9
0000796d027d698f  movaps [rsp+0x20], xmm15
0000796d027d6995  lea rdi, [rsp]
0000796d027d6999  mov esi, 0x00
0000796d027d699e  mov rax, 0x635FBE957530
0000796d027d69a8  call rax
0000796d027d69aa  movaps xmm7, [rsp]
0000796d027d69ae  add rsp, 0x30
0000796d027d69b2  vmovaps xmm0, [rsp]
0000796d027d69b7  vmovaps xmm1, [rsp+0x10]
0000796d027d69bd  vmovaps xmm2, [rsp+0x20]
0000796d027d69c3  vmovaps xmm3, [rsp+0x30]
0000796d027d69c9  vmovaps xmm4, [rsp+0x40]
0000796d027d69cf  vmovaps xmm5, [rsp+0x50]
0000796d027d69d5  vmovaps xmm6, [rsp+0x60]
0000796d027d69db  vmovaps xmm8, [rsp+0x70]
0000796d027d69e1  vmovaps xmm9, [rsp+0x80]
0000796d027d69ea  vmovaps xmm10, [rsp+0x90]
0000796d027d69f3  vmovaps xmm11, [rsp+0xA0]
0000796d027d69fc  vmovaps xmm12, [rsp+0xB0]
0000796d027d6a05  vmovaps xmm13, [rsp+0xC0]
0000796d027d6a0e  vmovaps xmm14, [rsp+0xD0]
0000796d027d6a17  vmovaps xmm15, [rsp+0xE0]
0000796d027d6a20  add rsp, 0xF0
0000796d027d6a27  pop r11
0000796d027d6a29  pop r10
0000796d027d6a2b  pop r9
0000796d027d6a2d  pop r8
0000796d027d6a2f  pop rsi
0000796d027d6a30  pop rdi
0000796d027d6a31  pop rdx
0000796d027d6a32  pop rcx
0000796d027d6a33  pop rax
0000796d027d6a34  add rsp, 0x08
0000796d027d6a38  jmp 0x0000796D027D59C8
0000796d027d6a3d  sub rsp, 0x08
0000796d027d6a41  push rax
0000796d027d6a42  push rcx
0000796d027d6a43  push rdx
0000796d027d6a44  push rdi
0000796d027d6a45  push rsi
0000796d027d6a46  push r8
0000796d027d6a48  push r9
0000796d027d6a4a  push r10
0000796d027d6a4c  push r11
0000796d027d6a4e  sub rsp, 0xF0
0000796d027d6a55  vmovaps [rsp], xmm0
0000796d027d6a5a  vmovaps [rsp+0x10], xmm1
0000796d027d6a60  vmovaps [rsp+0x20], xmm2
0000796d027d6a66  vmovaps [rsp+0x30], xmm3
0000796d027d6a6c  vmovaps [rsp+0x40], xmm4
0000796d027d6a72  vmovaps [rsp+0x50], xmm5
0000796d027d6a78  vmovaps [rsp+0x60], xmm6
0000796d027d6a7e  vmovaps [rsp+0x70], xmm7
0000796d027d6a84  vmovaps [rsp+0x80], xmm8
0000796d027d6a8d  vmovaps [rsp+0x90], xmm10
0000796d027d6a96  vmovaps [rsp+0xA0], xmm11
0000796d027d6a9f  vmovaps [rsp+0xB0], xmm12
0000796d027d6aa8  vmovaps [rsp+0xC0], xmm13
0000796d027d6ab1  vmovaps [rsp+0xD0], xmm14
0000796d027d6aba  vmovaps [rsp+0xE0], xmm15
0000796d027d6ac3  sub rsp, 0x30
0000796d027d6ac7  movaps [rsp], xmm9
0000796d027d6acc  movaps [rsp+0x10], xmm12
0000796d027d6ad2  movaps [rsp+0x20], xmm10
0000796d027d6ad8  lea rdi, [rsp]
0000796d027d6adc  mov esi, 0x00
0000796d027d6ae1  mov rax, 0x635FBE957530
0000796d027d6aeb  call rax
0000796d027d6aed  movaps xmm9, [rsp]
0000796d027d6af2  add rsp, 0x30
0000796d027d6af6  vmovaps xmm0, [rsp]
0000796d027d6afb  vmovaps xmm1, [rsp+0x10]
0000796d027d6b01  vmovaps xmm2, [rsp+0x20]
0000796d027d6b07  vmovaps xmm3, [rsp+0x30]
0000796d027d6b0d  vmovaps xmm4, [rsp+0x40]
0000796d027d6b13  vmovaps xmm5, [rsp+0x50]
0000796d027d6b19  vmovaps xmm6, [rsp+0x60]
0000796d027d6b1f  vmovaps xmm7, [rsp+0x70]
0000796d027d6b25  vmovaps xmm8, [rsp+0x80]
0000796d027d6b2e  vmovaps xmm10, [rsp+0x90]
0000796d027d6b37  vmovaps xmm11, [rsp+0xA0]
0000796d027d6b40  vmovaps xmm12, [rsp+0xB0]
0000796d027d6b49  vmovaps xmm13, [rsp+0xC0]
0000796d027d6b52  vmovaps xmm14, [rsp+0xD0]
0000796d027d6b5b  vmovaps xmm15, [rsp+0xE0]
0000796d027d6b64  add rsp, 0xF0
0000796d027d6b6b  pop r11
0000796d027d6b6d  pop r10
0000796d027d6b6f  pop r9
0000796d027d6b71  pop r8
0000796d027d6b73  pop rsi
0000796d027d6b74  pop rdi
0000796d027d6b75  pop rdx
0000796d027d6b76  pop rcx
0000796d027d6b77  pop rax
0000796d027d6b78  add rsp, 0x08
0000796d027d6b7c  jmp 0x0000796D027D59EC
0000796d027d6b81  sub rsp, 0x08
0000796d027d6b85  push rax
0000796d027d6b86  push rcx
0000796d027d6b87  push rdx
0000796d027d6b88  push rdi
0000796d027d6b89  push rsi
0000796d027d6b8a  push r8
0000796d027d6b8c  push r9
0000796d027d6b8e  push r10
0000796d027d6b90  push r11
0000796d027d6b92  sub rsp, 0xF0
0000796d027d6b99  vmovaps [rsp], xmm0
0000796d027d6b9e  vmovaps [rsp+0x10], xmm1
0000796d027d6ba4  vmovaps [rsp+0x20], xmm2
0000796d027d6baa  vmovaps [rsp+0x30], xmm3
0000796d027d6bb0  vmovaps [rsp+0x40], xmm4
0000796d027d6bb6  vmovaps [rsp+0x50], xmm5
0000796d027d6bbc  vmovaps [rsp+0x60], xmm6
0000796d027d6bc2  vmovaps [rsp+0x70], xmm7
0000796d027d6bc8  vmovaps [rsp+0x80], xmm8
0000796d027d6bd1  vmovaps [rsp+0x90], xmm9
0000796d027d6bda  vmovaps [rsp+0xA0], xmm11
0000796d027d6be3  vmovaps [rsp+0xB0], xmm12
0000796d027d6bec  vmovaps [rsp+0xC0], xmm13
0000796d027d6bf5  vmovaps [rsp+0xD0], xmm14
0000796d027d6bfe  vmovaps [rsp+0xE0], xmm15
0000796d027d6c07  sub rsp, 0x30
0000796d027d6c0b  movaps [rsp], xmm10
0000796d027d6c10  movaps [rsp+0x10], xmm12
0000796d027d6c16  movaps [rsp+0x20], xmm11
0000796d027d6c1c  lea rdi, [rsp]
0000796d027d6c20  mov esi, 0x00
0000796d027d6c25  mov rax, 0x635FBE957530
0000796d027d6c2f  call rax
0000796d027d6c31  movaps xmm10, [rsp]
0000796d027d6c36  add rsp, 0x30
0000796d027d6c3a  vmovaps xmm0, [rsp]
0000796d027d6c3f  vmovaps xmm1, [rsp+0x10]
0000796d027d6c45  vmovaps xmm2, [rsp+0x20]
0000796d027d6c4b  vmovaps xmm3, [rsp+0x30]
0000796d027d6c51  vmovaps xmm4, [rsp+0x40]
0000796d027d6c57  vmovaps xmm5, [rsp+0x50]
0000796d027d6c5d  vmovaps xmm6, [rsp+0x60]
0000796d027d6c63  vmovaps xmm7, [rsp+0x70]
0000796d027d6c69  vmovaps xmm8, [rsp+0x80]
0000796d027d6c72  vmovaps xmm9, [rsp+0x90]
0000796d027d6c7b  vmovaps xmm11, [rsp+0xA0]
0000796d027d6c84  vmovaps xmm12, [rsp+0xB0]
0000796d027d6c8d  vmovaps xmm13, [rsp+0xC0]
0000796d027d6c96  vmovaps xmm14, [rsp+0xD0]
0000796d027d6c9f  vmovaps xmm15, [rsp+0xE0]
0000796d027d6ca8  add rsp, 0xF0
0000796d027d6caf  pop r11
0000796d027d6cb1  pop r10
0000796d027d6cb3  pop r9
0000796d027d6cb5  pop r8
0000796d027d6cb7  pop rsi
0000796d027d6cb8  pop rdi
0000796d027d6cb9  pop rdx
0000796d027d6cba  pop rcx
0000796d027d6cbb  pop rax
0000796d027d6cbc  add rsp, 0x08
0000796d027d6cc0  jmp 0x0000796D027D5A06
0000796d027d6cc5  sub rsp, 0x08
0000796d027d6cc9  push rax
0000796d027d6cca  push rcx
0000796d027d6ccb  push rdx
0000796d027d6ccc  push rdi
0000796d027d6ccd  push rsi
0000796d027d6cce  push r8
0000796d027d6cd0  push r9
0000796d027d6cd2  push r10
0000796d027d6cd4  push r11
0000796d027d6cd6  sub rsp, 0xF0
0000796d027d6cdd  vmovaps [rsp], xmm0
0000796d027d6ce2  vmovaps [rsp+0x10], xmm1
0000796d027d6ce8  vmovaps [rsp+0x20], xmm2
0000796d027d6cee  vmovaps [rsp+0x30], xmm3
0000796d027d6cf4  vmovaps [rsp+0x40], xmm4
0000796d027d6cfa  vmovaps [rsp+0x50], xmm5
0000796d027d6d00  vmovaps [rsp+0x60], xmm7
0000796d027d6d06  vmovaps [rsp+0x70], xmm8
0000796d027d6d0c  vmovaps [rsp+0x80], xmm9
0000796d027d6d15  vmovaps [rsp+0x90], xmm10
0000796d027d6d1e  vmovaps [rsp+0xA0], xmm11
0000796d027d6d27  vmovaps [rsp+0xB0], xmm12
0000796d027d6d30  vmovaps [rsp+0xC0], xmm13
0000796d027d6d39  vmovaps [rsp+0xD0], xmm14
0000796d027d6d42  vmovaps [rsp+0xE0], xmm15
0000796d027d6d4b  sub rsp, 0x30
0000796d027d6d4f  movaps [rsp], xmm6
0000796d027d6d53  movaps [rsp+0x10], xmm12
0000796d027d6d59  movaps [rsp+0x20], xmm11
0000796d027d6d5f  lea rdi, [rsp]
0000796d027d6d63  mov esi, 0x00
0000796d027d6d68  mov rax, 0x635FBE957530
0000796d027d6d72  call rax
0000796d027d6d74  movaps xmm6, [rsp]
0000796d027d6d78  add rsp, 0x30
0000796d027d6d7c  vmovaps xmm0, [rsp]
0000796d027d6d81  vmovaps xmm1, [rsp+0x10]
0000796d027d6d87  vmovaps xmm2, [rsp+0x20]
0000796d027d6d8d  vmovaps xmm3, [rsp+0x30]
0000796d027d6d93  vmovaps xmm4, [rsp+0x40]
0000796d027d6d99  vmovaps xmm5, [rsp+0x50]
0000796d027d6d9f  vmovaps xmm7, [rsp+0x60]
0000796d027d6da5  vmovaps xmm8, [rsp+0x70]
0000796d027d6dab  vmovaps xmm9, [rsp+0x80]
0000796d027d6db4  vmovaps xmm10, [rsp+0x90]
0000796d027d6dbd  vmovaps xmm11, [rsp+0xA0]
0000796d027d6dc6  vmovaps xmm12, [rsp+0xB0]
0000796d027d6dcf  vmovaps xmm13, [rsp+0xC0]
0000796d027d6dd8  vmovaps xmm14, [rsp+0xD0]
0000796d027d6de1  vmovaps xmm15, [rsp+0xE0]
0000796d027d6dea  add rsp, 0xF0
0000796d027d6df1  pop r11
0000796d027d6df3  pop r10
0000796d027d6df5  pop r9
0000796d027d6df7  pop r8
0000796d027d6df9  pop rsi
0000796d027d6dfa  pop rdi
0000796d027d6dfb  pop rdx
0000796d027d6dfc  pop rcx
0000796d027d6dfd  pop rax
0000796d027d6dfe  add rsp, 0x08
0000796d027d6e02  jmp 0x0000796D027D5A27
0000796d027d6e07  sub rsp, 0x08
0000796d027d6e0b  push rax
0000796d027d6e0c  push rcx
0000796d027d6e0d  push rdx
0000796d027d6e0e  push rdi
0000796d027d6e0f  push rsi
0000796d027d6e10  push r8
0000796d027d6e12  push r9
0000796d027d6e14  push r10
0000796d027d6e16  push r11
0000796d027d6e18  sub rsp, 0xF0
0000796d027d6e1f  vmovaps [rsp], xmm0
0000796d027d6e24  vmovaps [rsp+0x10], xmm1
0000796d027d6e2a  vmovaps [rsp+0x20], xmm2
0000796d027d6e30  vmovaps [rsp+0x30], xmm4
0000796d027d6e36  vmovaps [rsp+0x40], xmm5
0000796d027d6e3c  vmovaps [rsp+0x50], xmm6
0000796d027d6e42  vmovaps [rsp+0x60], xmm7
0000796d027d6e48  vmovaps [rsp+0x70], xmm8
0000796d027d6e4e  vmovaps [rsp+0x80], xmm9
0000796d027d6e57  vmovaps [rsp+0x90], xmm10
0000796d027d6e60  vmovaps [rsp+0xA0], xmm11
0000796d027d6e69  vmovaps [rsp+0xB0], xmm12
0000796d027d6e72  vmovaps [rsp+0xC0], xmm13
0000796d027d6e7b  vmovaps [rsp+0xD0], xmm14
0000796d027d6e84  vmovaps [rsp+0xE0], xmm15
0000796d027d6e8d  sub rsp, 0x30
0000796d027d6e91  movaps [rsp], xmm3
0000796d027d6e95  movaps [rsp+0x10], xmm5
0000796d027d6e9a  movaps [rsp+0x20], xmm4
0000796d027d6e9f  lea rdi, [rsp]
0000796d027d6ea3  mov esi, 0x00
0000796d027d6ea8  mov rax, 0x635FBE957530
0000796d027d6eb2  call rax
0000796d027d6eb4  movaps xmm3, [rsp]
0000796d027d6eb8  add rsp, 0x30
0000796d027d6ebc  vmovaps xmm0, [rsp]
0000796d027d6ec1  vmovaps xmm1, [rsp+0x10]
0000796d027d6ec7  vmovaps xmm2, [rsp+0x20]
0000796d027d6ecd  vmovaps xmm4, [rsp+0x30]
0000796d027d6ed3  vmovaps xmm5, [rsp+0x40]
0000796d027d6ed9  vmovaps xmm6, [rsp+0x50]
0000796d027d6edf  vmovaps xmm7, [rsp+0x60]
0000796d027d6ee5  vmovaps xmm8, [rsp+0x70]
0000796d027d6eeb  vmovaps xmm9, [rsp+0x80]
0000796d027d6ef4  vmovaps xmm10, [rsp+0x90]
0000796d027d6efd  vmovaps xmm11, [rsp+0xA0]
0000796d027d6f06  vmovaps xmm12, [rsp+0xB0]
0000796d027d6f0f  vmovaps xmm13, [rsp+0xC0]
0000796d027d6f18  vmovaps xmm14, [rsp+0xD0]
0000796d027d6f21  vmovaps xmm15, [rsp+0xE0]
0000796d027d6f2a  add rsp, 0xF0
0000796d027d6f31  pop r11
0000796d027d6f33  pop r10
0000796d027d6f35  pop r9
0000796d027d6f37  pop r8
0000796d027d6f39  pop rsi
0000796d027d6f3a  pop rdi
0000796d027d6f3b  pop rdx
0000796d027d6f3c  pop rcx
0000796d027d6f3d  pop rax
0000796d027d6f3e  add rsp, 0x08
0000796d027d6f42  jmp 0x0000796D027D5A88
0000796d027d6f47  sub rsp, 0x08
0000796d027d6f4b  push rax
0000796d027d6f4c  push rcx
0000796d027d6f4d  push rdx
0000796d027d6f4e  push rdi
0000796d027d6f4f  push rsi
0000796d027d6f50  push r8
0000796d027d6f52  push r9
0000796d027d6f54  push r10
0000796d027d6f56  push r11
0000796d027d6f58  sub rsp, 0xF0
0000796d027d6f5f  vmovaps [rsp], xmm0
0000796d027d6f64  vmovaps [rsp+0x10], xmm1
0000796d027d6f6a  vmovaps [rsp+0x20], xmm2
0000796d027d6f70  vmovaps [rsp+0x30], xmm3
0000796d027d6f76  vmovaps [rsp+0x40], xmm4
0000796d027d6f7c  vmovaps [rsp+0x50], xmm6
0000796d027d6f82  vmovaps [rsp+0x60], xmm7
0000796d027d6f88  vmovaps [rsp+0x70], xmm8
0000796d027d6f8e  vmovaps [rsp+0x80], xmm9
0000796d027d6f97  vmovaps [rsp+0x90], xmm10
0000796d027d6fa0  vmovaps [rsp+0xA0], xmm11
0000796d027d6fa9  vmovaps [rsp+0xB0], xmm12
0000796d027d6fb2  vmovaps [rsp+0xC0], xmm13
0000796d027d6fbb  vmovaps [rsp+0xD0], xmm14
0000796d027d6fc4  vmovaps [rsp+0xE0], xmm15
0000796d027d6fcd  sub rsp, 0x30
0000796d027d6fd1  movaps [rsp], xmm5
0000796d027d6fd5  movaps [rsp+0x10], xmm8
0000796d027d6fdb  movaps [rsp+0x20], xmm15
0000796d027d6fe1  lea rdi, [rsp]
0000796d027d6fe5  mov esi, 0x00
0000796d027d6fea  mov rax, 0x635FBE957530
0000796d027d6ff4  call rax
0000796d027d6ff6  movaps xmm5, [rsp]
0000796d027d6ffa  add rsp, 0x30
0000796d027d6ffe  vmovaps xmm0, [rsp]
0000796d027d7003  vmovaps xmm1, [rsp+0x10]
0000796d027d7009  vmovaps xmm2, [rsp+0x20]
0000796d027d700f  vmovaps xmm3, [rsp+0x30]
0000796d027d7015  vmovaps xmm4, [rsp+0x40]
0000796d027d701b  vmovaps xmm6, [rsp+0x50]
0000796d027d7021  vmovaps xmm7, [rsp+0x60]
0000796d027d7027  vmovaps xmm8, [rsp+0x70]
0000796d027d702d  vmovaps xmm9, [rsp+0x80]
0000796d027d7036  vmovaps xmm10, [rsp+0x90]
0000796d027d703f  vmovaps xmm11, [rsp+0xA0]
0000796d027d7048  vmovaps xmm12, [rsp+0xB0]
0000796d027d7051  vmovaps xmm13, [rsp+0xC0]
0000796d027d705a  vmovaps xmm14, [rsp+0xD0]
0000796d027d7063  vmovaps xmm15, [rsp+0xE0]
0000796d027d706c  add rsp, 0xF0
0000796d027d7073  pop r11
0000796d027d7075  pop r10
0000796d027d7077  pop r9
0000796d027d7079  pop r8
0000796d027d707b  pop rsi
0000796d027d707c  pop rdi
0000796d027d707d  pop rdx
0000796d027d707e  pop rcx
0000796d027d707f  pop rax
0000796d027d7080  add rsp, 0x08
0000796d027d7084  jmp 0x0000796D027D5AC0
0000796d027d7089  sub rsp, 0x08
0000796d027d708d  push rax
0000796d027d708e  push rcx
0000796d027d708f  push rdx
0000796d027d7090  push rdi
0000796d027d7091  push rsi
0000796d027d7092  push r8
0000796d027d7094  push r9
0000796d027d7096  push r10
0000796d027d7098  push r11
0000796d027d709a  sub rsp, 0xF0
0000796d027d70a1  vmovaps [rsp], xmm0
0000796d027d70a6  vmovaps [rsp+0x10], xmm1
0000796d027d70ac  vmovaps [rsp+0x20], xmm2
0000796d027d70b2  vmovaps [rsp+0x30], xmm3
0000796d027d70b8  vmovaps [rsp+0x40], xmm5
0000796d027d70be  vmovaps [rsp+0x50], xmm6
0000796d027d70c4  vmovaps [rsp+0x60], xmm7
0000796d027d70ca  vmovaps [rsp+0x70], xmm8
0000796d027d70d0  vmovaps [rsp+0x80], xmm9
0000796d027d70d9  vmovaps [rsp+0x90], xmm10
0000796d027d70e2  vmovaps [rsp+0xA0], xmm11
0000796d027d70eb  vmovaps [rsp+0xB0], xmm12
0000796d027d70f4  vmovaps [rsp+0xC0], xmm13
0000796d027d70fd  vmovaps [rsp+0xD0], xmm14
0000796d027d7106  vmovaps [rsp+0xE0], xmm15
0000796d027d710f  sub rsp, 0x30
0000796d027d7113  movaps [rsp], xmm4
0000796d027d7117  movaps [rsp+0x10], xmm9
0000796d027d711d  movaps [rsp+0x20], xmm8
0000796d027d7123  lea rdi, [rsp]
0000796d027d7127  mov esi, 0x00
0000796d027d712c  mov rax, 0x635FBE957530
0000796d027d7136  call rax
0000796d027d7138  movaps xmm4, [rsp]
0000796d027d713c  add rsp, 0x30
0000796d027d7140  vmovaps xmm0, [rsp]
0000796d027d7145  vmovaps xmm1, [rsp+0x10]
0000796d027d714b  vmovaps xmm2, [rsp+0x20]
0000796d027d7151  vmovaps xmm3, [rsp+0x30]
0000796d027d7157  vmovaps xmm5, [rsp+0x40]
0000796d027d715d  vmovaps xmm6, [rsp+0x50]
0000796d027d7163  vmovaps xmm7, [rsp+0x60]
0000796d027d7169  vmovaps xmm8, [rsp+0x70]
0000796d027d716f  vmovaps xmm9, [rsp+0x80]
0000796d027d7178  vmovaps xmm10, [rsp+0x90]
0000796d027d7181  vmovaps xmm11, [rsp+0xA0]
0000796d027d718a  vmovaps xmm12, [rsp+0xB0]
0000796d027d7193  vmovaps xmm13, [rsp+0xC0]
0000796d027d719c  vmovaps xmm14, [rsp+0xD0]
0000796d027d71a5  vmovaps xmm15, [rsp+0xE0]
0000796d027d71ae  add rsp, 0xF0
0000796d027d71b5  pop r11
0000796d027d71b7  pop r10
0000796d027d71b9  pop r9
0000796d027d71bb  pop r8
0000796d027d71bd  pop rsi
0000796d027d71be  pop rdi
0000796d027d71bf  pop rdx
0000796d027d71c0  pop rcx
0000796d027d71c1  pop rax
0000796d027d71c2  add rsp, 0x08
0000796d027d71c6  jmp 0x0000796D027D5AE1
0000796d027d71cb  sub rsp, 0x08
0000796d027d71cf  push rax
0000796d027d71d0  push rcx
0000796d027d71d1  push rdx
0000796d027d71d2  push rdi
0000796d027d71d3  push rsi
0000796d027d71d4  push r8
0000796d027d71d6  push r9
0000796d027d71d8  push r10
0000796d027d71da  push r11
0000796d027d71dc  sub rsp, 0xF0
0000796d027d71e3  vmovaps [rsp], xmm0
0000796d027d71e8  vmovaps [rsp+0x10], xmm1
0000796d027d71ee  vmovaps [rsp+0x20], xmm2
0000796d027d71f4  vmovaps [rsp+0x30], xmm3
0000796d027d71fa  vmovaps [rsp+0x40], xmm4
0000796d027d7200  vmovaps [rsp+0x50], xmm5
0000796d027d7206  vmovaps [rsp+0x60], xmm6
0000796d027d720c  vmovaps [rsp+0x70], xmm7
0000796d027d7212  vmovaps [rsp+0x80], xmm8
0000796d027d721b  vmovaps [rsp+0x90], xmm10
0000796d027d7224  vmovaps [rsp+0xA0], xmm11
0000796d027d722d  vmovaps [rsp+0xB0], xmm12
0000796d027d7236  vmovaps [rsp+0xC0], xmm13
0000796d027d723f  vmovaps [rsp+0xD0], xmm14
0000796d027d7248  vmovaps [rsp+0xE0], xmm15
0000796d027d7251  sub rsp, 0x30
0000796d027d7255  movaps [rsp], xmm9
0000796d027d725a  movaps [rsp+0x10], xmm10
0000796d027d7260  movaps [rsp+0x20], xmm8
0000796d027d7266  lea rdi, [rsp]
0000796d027d726a  mov esi, 0x00
0000796d027d726f  mov rax, 0x635FBE957530
0000796d027d7279  call rax
0000796d027d727b  movaps xmm9, [rsp]
0000796d027d7280  add rsp, 0x30
0000796d027d7284  vmovaps xmm0, [rsp]
0000796d027d7289  vmovaps xmm1, [rsp+0x10]
0000796d027d728f  vmovaps xmm2, [rsp+0x20]
0000796d027d7295  vmovaps xmm3, [rsp+0x30]
0000796d027d729b  vmovaps xmm4, [rsp+0x40]
0000796d027d72a1  vmovaps xmm5, [rsp+0x50]
0000796d027d72a7  vmovaps xmm6, [rsp+0x60]
0000796d027d72ad  vmovaps xmm7, [rsp+0x70]
0000796d027d72b3  vmovaps xmm8, [rsp+0x80]
0000796d027d72bc  vmovaps xmm10, [rsp+0x90]
0000796d027d72c5  vmovaps xmm11, [rsp+0xA0]
0000796d027d72ce  vmovaps xmm12, [rsp+0xB0]
0000796d027d72d7  vmovaps xmm13, [rsp+0xC0]
0000796d027d72e0  vmovaps xmm14, [rsp+0xD0]
0000796d027d72e9  vmovaps xmm15, [rsp+0xE0]
0000796d027d72f2  add rsp, 0xF0
0000796d027d72f9  pop r11
0000796d027d72fb  pop r10
0000796d027d72fd  pop r9
0000796d027d72ff  pop r8
0000796d027d7301  pop rsi
0000796d027d7302  pop rdi
0000796d027d7303  pop rdx
0000796d027d7304  pop rcx
0000796d027d7305  pop rax
0000796d027d7306  add rsp, 0x08
0000796d027d730a  jmp 0x0000796D027D5AFB
0000796d027d730f  call 0x0000796D026D64F0
0000796d027d7314  jmp 0x0000796D027D5C15
0000796d027d7319  call 0x0000796D026D64F0
0000796d027d731e  jmp 0x0000796D027D5C2B
0000796d027d7323  sub rsp, 0x08
0000796d027d7327  push rax
0000796d027d7328  push rcx
0000796d027d7329  push rdx
0000796d027d732a  push rdi
0000796d027d732b  push rsi
0000796d027d732c  push r8
0000796d027d732e  push r9
0000796d027d7330  push r10
0000796d027d7332  push r11
0000796d027d7334  sub rsp, 0xF0
0000796d027d733b  vmovaps [rsp], xmm0
0000796d027d7340  vmovaps [rsp+0x10], xmm2
0000796d027d7346  vmovaps [rsp+0x20], xmm3
0000796d027d734c  vmovaps [rsp+0x30], xmm4
0000796d027d7352  vmovaps [rsp+0x40], xmm5
0000796d027d7358  vmovaps [rsp+0x50], xmm6
0000796d027d735e  vmovaps [rsp+0x60], xmm7
0000796d027d7364  vmovaps [rsp+0x70], xmm8
0000796d027d736a  vmovaps [rsp+0x80], xmm9
0000796d027d7373  vmovaps [rsp+0x90], xmm10
0000796d027d737c  vmovaps [rsp+0xA0], xmm11
0000796d027d7385  vmovaps [rsp+0xB0], xmm12
0000796d027d738e  vmovaps [rsp+0xC0], xmm13
0000796d027d7397  vmovaps [rsp+0xD0], xmm14
0000796d027d73a0  vmovaps [rsp+0xE0], xmm15
0000796d027d73a9  sub rsp, 0x30
0000796d027d73ad  movaps [rsp], xmm1
0000796d027d73b1  movaps [rsp+0x10], xmm6
0000796d027d73b6  movaps [rsp+0x20], xmm15
0000796d027d73bc  lea rdi, [rsp]
0000796d027d73c0  mov esi, 0x00
0000796d027d73c5  mov rax, 0x635FBE957530
0000796d027d73cf  call rax
0000796d027d73d1  movaps xmm1, [rsp]
0000796d027d73d5  add rsp, 0x30
0000796d027d73d9  vmovaps xmm0, [rsp]
0000796d027d73de  vmovaps xmm2, [rsp+0x10]
0000796d027d73e4  vmovaps xmm3, [rsp+0x20]
0000796d027d73ea  vmovaps xmm4, [rsp+0x30]
0000796d027d73f0  vmovaps xmm5, [rsp+0x40]
0000796d027d73f6  vmovaps xmm6, [rsp+0x50]
0000796d027d73fc  vmovaps xmm7, [rsp+0x60]
0000796d027d7402  vmovaps xmm8, [rsp+0x70]
0000796d027d7408  vmovaps xmm9, [rsp+0x80]
0000796d027d7411  vmovaps xmm10, [rsp+0x90]
0000796d027d741a  vmovaps xmm11, [rsp+0xA0]
0000796d027d7423  vmovaps xmm12, [rsp+0xB0]
0000796d027d742c  vmovaps xmm13, [rsp+0xC0]
0000796d027d7435  vmovaps xmm14, [rsp+0xD0]
0000796d027d743e  vmovaps xmm15, [rsp+0xE0]
0000796d027d7447  add rsp, 0xF0
0000796d027d744e  pop r11
0000796d027d7450  pop r10
0000796d027d7452  pop r9
0000796d027d7454  pop r8
0000796d027d7456  pop rsi
0000796d027d7457  pop rdi
0000796d027d7458  pop rdx
0000796d027d7459  pop rcx
0000796d027d745a  pop rax
0000796d027d745b  add rsp, 0x08
0000796d027d745f  jmp 0x0000796D027D5C68
0000796d027d7464  call 0x0000796D026E5820
0000796d027d7469  jmp 0x0000796D027D5C75
0000796d027d746e  sub rsp, 0x08
0000796d027d7472  push rax
0000796d027d7473  push rcx
0000796d027d7474  push rdx
0000796d027d7475  push rdi
0000796d027d7476  push rsi
0000796d027d7477  push r8
0000796d027d7479  push r9
0000796d027d747b  push r10
0000796d027d747d  push r11
0000796d027d747f  sub rsp, 0xF0
0000796d027d7486  vmovaps [rsp], xmm0
0000796d027d748b  vmovaps [rsp+0x10], xmm1
0000796d027d7491  vmovaps [rsp+0x20], xmm2
0000796d027d7497  vmovaps [rsp+0x30], xmm3
0000796d027d749d  vmovaps [rsp+0x40], xmm4
0000796d027d74a3  vmovaps [rsp+0x50], xmm5
0000796d027d74a9  vmovaps [rsp+0x60], xmm6
0000796d027d74af  vmovaps [rsp+0x70], xmm7
0000796d027d74b5  vmovaps [rsp+0x80], xmm8
0000796d027d74be  vmovaps [rsp+0x90], xmm9
0000796d027d74c7  vmovaps [rsp+0xA0], xmm10
0000796d027d74d0  vmovaps [rsp+0xB0], xmm11
0000796d027d74d9  vmovaps [rsp+0xC0], xmm12
0000796d027d74e2  vmovaps [rsp+0xD0], xmm13
0000796d027d74eb  vmovaps [rsp+0xE0], xmm15
0000796d027d74f4  sub rsp, 0x30
0000796d027d74f8  movaps [rsp], xmm14
0000796d027d74fd  movaps [rsp+0x10], xmm4
0000796d027d7502  movaps [rsp+0x20], xmm3
0000796d027d7507  lea rdi, [rsp]
0000796d027d750b  mov esi, 0x00
0000796d027d7510  mov rax, 0x635FBE957530
0000796d027d751a  call rax
0000796d027d751c  movaps xmm14, [rsp]
0000796d027d7521  add rsp, 0x30
0000796d027d7525  vmovaps xmm0, [rsp]
0000796d027d752a  vmovaps xmm1, [rsp+0x10]
0000796d027d7530  vmovaps xmm2, [rsp+0x20]
0000796d027d7536  vmovaps xmm3, [rsp+0x30]
0000796d027d753c  vmovaps xmm4, [rsp+0x40]
0000796d027d7542  vmovaps xmm5, [rsp+0x50]
0000796d027d7548  vmovaps xmm6, [rsp+0x60]
0000796d027d754e  vmovaps xmm7, [rsp+0x70]
0000796d027d7554  vmovaps xmm8, [rsp+0x80]
0000796d027d755d  vmovaps xmm9, [rsp+0x90]
0000796d027d7566  vmovaps xmm10, [rsp+0xA0]
0000796d027d756f  vmovaps xmm11, [rsp+0xB0]
0000796d027d7578  vmovaps xmm12, [rsp+0xC0]
0000796d027d7581  vmovaps xmm13, [rsp+0xD0]
0000796d027d758a  vmovaps xmm15, [rsp+0xE0]
0000796d027d7593  add rsp, 0xF0
0000796d027d759a  pop r11
0000796d027d759c  pop r10
0000796d027d759e  pop r9
0000796d027d75a0  pop r8
0000796d027d75a2  pop rsi
0000796d027d75a3  pop rdi
0000796d027d75a4  pop rdx
0000796d027d75a5  pop rcx
0000796d027d75a6  pop rax
0000796d027d75a7  add rsp, 0x08
0000796d027d75ab  jmp 0x0000796D027D5C8F
0000796d027d75b0  sub rsp, 0x08
0000796d027d75b4  push rax
0000796d027d75b5  push rcx
0000796d027d75b6  push rdx
0000796d027d75b7  push rdi
0000796d027d75b8  push rsi
0000796d027d75b9  push r8
0000796d027d75bb  push r9
0000796d027d75bd  push r10
0000796d027d75bf  push r11
0000796d027d75c1  sub rsp, 0xF0
0000796d027d75c8  vmovaps [rsp], xmm0
0000796d027d75cd  vmovaps [rsp+0x10], xmm1
0000796d027d75d3  vmovaps [rsp+0x20], xmm2
0000796d027d75d9  vmovaps [rsp+0x30], xmm3
0000796d027d75df  vmovaps [rsp+0x40], xmm4
0000796d027d75e5  vmovaps [rsp+0x50], xmm5
0000796d027d75eb  vmovaps [rsp+0x60], xmm7
0000796d027d75f1  vmovaps [rsp+0x70], xmm8
0000796d027d75f7  vmovaps [rsp+0x80], xmm9
0000796d027d7600  vmovaps [rsp+0x90], xmm10
0000796d027d7609  vmovaps [rsp+0xA0], xmm11
0000796d027d7612  vmovaps [rsp+0xB0], xmm12
0000796d027d761b  vmovaps [rsp+0xC0], xmm13
0000796d027d7624  vmovaps [rsp+0xD0], xmm14
0000796d027d762d  vmovaps [rsp+0xE0], xmm15
0000796d027d7636  sub rsp, 0x30
0000796d027d763a  movaps [rsp], xmm6
0000796d027d763e  movaps [rsp+0x10], xmm9
0000796d027d7644  movaps [rsp+0x20], xmm7
0000796d027d7649  lea rdi, [rsp]
0000796d027d764d  mov esi, 0x00
0000796d027d7652  mov rax, 0x635FBE957530
0000796d027d765c  call rax
0000796d027d765e  movaps xmm6, [rsp]
0000796d027d7662  add rsp, 0x30
0000796d027d7666  vmovaps xmm0, [rsp]
0000796d027d766b  vmovaps xmm1, [rsp+0x10]
0000796d027d7671  vmovaps xmm2, [rsp+0x20]
0000796d027d7677  vmovaps xmm3, [rsp+0x30]
0000796d027d767d  vmovaps xmm4, [rsp+0x40]
0000796d027d7683  vmovaps xmm5, [rsp+0x50]
0000796d027d7689  vmovaps xmm7, [rsp+0x60]
0000796d027d768f  vmovaps xmm8, [rsp+0x70]
0000796d027d7695  vmovaps xmm9, [rsp+0x80]
0000796d027d769e  vmovaps xmm10, [rsp+0x90]
0000796d027d76a7  vmovaps xmm11, [rsp+0xA0]
0000796d027d76b0  vmovaps xmm12, [rsp+0xB0]
0000796d027d76b9  vmovaps xmm13, [rsp+0xC0]
0000796d027d76c2  vmovaps xmm14, [rsp+0xD0]
0000796d027d76cb  vmovaps xmm15, [rsp+0xE0]
0000796d027d76d4  add rsp, 0xF0
0000796d027d76db  pop r11
0000796d027d76dd  pop r10
0000796d027d76df  pop r9
0000796d027d76e1  pop r8
0000796d027d76e3  pop rsi
0000796d027d76e4  pop rdi
0000796d027d76e5  pop rdx
0000796d027d76e6  pop rcx
0000796d027d76e7  pop rax
0000796d027d76e8  add rsp, 0x08
0000796d027d76ec  jmp 0x0000796D027D5CA7
0000796d027d76f1  sub rsp, 0x08
0000796d027d76f5  push rax
0000796d027d76f6  push rcx
0000796d027d76f7  push rdx
0000796d027d76f8  push rdi
0000796d027d76f9  push rsi
0000796d027d76fa  push r8
0000796d027d76fc  push r9
0000796d027d76fe  push r10
0000796d027d7700  push r11
0000796d027d7702  sub rsp, 0xF0
0000796d027d7709  vmovaps [rsp], xmm0
0000796d027d770e  vmovaps [rsp+0x10], xmm1
0000796d027d7714  vmovaps [rsp+0x20], xmm2
0000796d027d771a  vmovaps [rsp+0x30], xmm3
0000796d027d7720  vmovaps [rsp+0x40], xmm4
0000796d027d7726  vmovaps [rsp+0x50], xmm5
0000796d027d772c  vmovaps [rsp+0x60], xmm6
0000796d027d7732  vmovaps [rsp+0x70], xmm8
0000796d027d7738  vmovaps [rsp+0x80], xmm9
0000796d027d7741  vmovaps [rsp+0x90], xmm10
0000796d027d774a  vmovaps [rsp+0xA0], xmm11
0000796d027d7753  vmovaps [rsp+0xB0], xmm12
0000796d027d775c  vmovaps [rsp+0xC0], xmm13
0000796d027d7765  vmovaps [rsp+0xD0], xmm14
0000796d027d776e  vmovaps [rsp+0xE0], xmm15
0000796d027d7777  sub rsp, 0x30
0000796d027d777b  movaps [rsp], xmm7
0000796d027d777f  movaps [rsp+0x10], xmm4
0000796d027d7784  movaps [rsp+0x20], xmm9
0000796d027d778a  lea rdi, [rsp]
0000796d027d778e  mov esi, 0x00
0000796d027d7793  mov rax, 0x635FBE957530
0000796d027d779d  call rax
0000796d027d779f  movaps xmm7, [rsp]
0000796d027d77a3  add rsp, 0x30
0000796d027d77a7  vmovaps xmm0, [rsp]
0000796d027d77ac  vmovaps xmm1, [rsp+0x10]
0000796d027d77b2  vmovaps xmm2, [rsp+0x20]
0000796d027d77b8  vmovaps xmm3, [rsp+0x30]
0000796d027d77be  vmovaps xmm4, [rsp+0x40]
0000796d027d77c4  vmovaps xmm5, [rsp+0x50]
0000796d027d77ca  vmovaps xmm6, [rsp+0x60]
0000796d027d77d0  vmovaps xmm8, [rsp+0x70]
0000796d027d77d6  vmovaps xmm9, [rsp+0x80]
0000796d027d77df  vmovaps xmm10, [rsp+0x90]
0000796d027d77e8  vmovaps xmm11, [rsp+0xA0]
0000796d027d77f1  vmovaps xmm12, [rsp+0xB0]
0000796d027d77fa  vmovaps xmm13, [rsp+0xC0]
0000796d027d7803  vmovaps xmm14, [rsp+0xD0]
0000796d027d780c  vmovaps xmm15, [rsp+0xE0]
0000796d027d7815  add rsp, 0xF0
0000796d027d781c  pop r11
0000796d027d781e  pop r10
0000796d027d7820  pop r9
0000796d027d7822  pop r8
0000796d027d7824  pop rsi
0000796d027d7825  pop rdi
0000796d027d7826  pop rdx
0000796d027d7827  pop rcx
0000796d027d7828  pop rax
0000796d027d7829  add rsp, 0x08
0000796d027d782d  jmp 0x0000796D027D5CD4
0000796d027d7832  sub rsp, 0x08
0000796d027d7836  push rax
0000796d027d7837  push rcx
0000796d027d7838  push rdx
0000796d027d7839  push rdi
0000796d027d783a  push rsi
0000796d027d783b  push r8
0000796d027d783d  push r9
0000796d027d783f  push r10
0000796d027d7841  push r11
0000796d027d7843  sub rsp, 0xF0
0000796d027d784a  vmovaps [rsp], xmm0
0000796d027d784f  vmovaps [rsp+0x10], xmm1
0000796d027d7855  vmovaps [rsp+0x20], xmm2
0000796d027d785b  vmovaps [rsp+0x30], xmm3
0000796d027d7861  vmovaps [rsp+0x40], xmm5
0000796d027d7867  vmovaps [rsp+0x50], xmm6
0000796d027d786d  vmovaps [rsp+0x60], xmm7
0000796d027d7873  vmovaps [rsp+0x70], xmm8
0000796d027d7879  vmovaps [rsp+0x80], xmm9
0000796d027d7882  vmovaps [rsp+0x90], xmm10
0000796d027d788b  vmovaps [rsp+0xA0], xmm11
0000796d027d7894  vmovaps [rsp+0xB0], xmm12
0000796d027d789d  vmovaps [rsp+0xC0], xmm13
0000796d027d78a6  vmovaps [rsp+0xD0], xmm14
0000796d027d78af  vmovaps [rsp+0xE0], xmm15
0000796d027d78b8  sub rsp, 0x30
0000796d027d78bc  movaps [rsp], xmm4
0000796d027d78c0  movaps [rsp+0x10], xmm15
0000796d027d78c6  movaps [rsp+0x20], xmm9
0000796d027d78cc  lea rdi, [rsp]
0000796d027d78d0  mov esi, 0x00
0000796d027d78d5  mov rax, 0x635FBE957530
0000796d027d78df  call rax
0000796d027d78e1  movaps xmm4, [rsp]
0000796d027d78e5  add rsp, 0x30
0000796d027d78e9  vmovaps xmm0, [rsp]
0000796d027d78ee  vmovaps xmm1, [rsp+0x10]
0000796d027d78f4  vmovaps xmm2, [rsp+0x20]
0000796d027d78fa  vmovaps xmm3, [rsp+0x30]
0000796d027d7900  vmovaps xmm5, [rsp+0x40]
0000796d027d7906  vmovaps xmm6, [rsp+0x50]
0000796d027d790c  vmovaps xmm7, [rsp+0x60]
0000796d027d7912  vmovaps xmm8, [rsp+0x70]
0000796d027d7918  vmovaps xmm9, [rsp+0x80]
0000796d027d7921  vmovaps xmm10, [rsp+0x90]
0000796d027d792a  vmovaps xmm11, [rsp+0xA0]
0000796d027d7933  vmovaps xmm12, [rsp+0xB0]
0000796d027d793c  vmovaps xmm13, [rsp+0xC0]
0000796d027d7945  vmovaps xmm14, [rsp+0xD0]
0000796d027d794e  vmovaps xmm15, [rsp+0xE0]
0000796d027d7957  add rsp, 0xF0
0000796d027d795e  pop r11
0000796d027d7960  pop r10
0000796d027d7962  pop r9
0000796d027d7964  pop r8
0000796d027d7966  pop rsi
0000796d027d7967  pop rdi
0000796d027d7968  pop rdx
0000796d027d7969  pop rcx
0000796d027d796a  pop rax
0000796d027d796b  add rsp, 0x08
0000796d027d796f  jmp 0x0000796D027D5CF9
0000796d027d7974  call 0x0000796D026E5820
0000796d027d7979  jmp 0x0000796D027D5D06
0000796d027d797e  sub rsp, 0x08
0000796d027d7982  push rax
0000796d027d7983  push rcx
0000796d027d7984  push rdx
0000796d027d7985  push rdi
0000796d027d7986  push rsi
0000796d027d7987  push r8
0000796d027d7989  push r9
0000796d027d798b  push r10
0000796d027d798d  push r11
0000796d027d798f  sub rsp, 0xF0
0000796d027d7996  vmovaps [rsp], xmm0
0000796d027d799b  vmovaps [rsp+0x10], xmm1
0000796d027d79a1  vmovaps [rsp+0x20], xmm2
0000796d027d79a7  vmovaps [rsp+0x30], xmm4
0000796d027d79ad  vmovaps [rsp+0x40], xmm5
0000796d027d79b3  vmovaps [rsp+0x50], xmm6
0000796d027d79b9  vmovaps [rsp+0x60], xmm7
0000796d027d79bf  vmovaps [rsp+0x70], xmm8
0000796d027d79c5  vmovaps [rsp+0x80], xmm9
0000796d027d79ce  vmovaps [rsp+0x90], xmm10
0000796d027d79d7  vmovaps [rsp+0xA0], xmm11
0000796d027d79e0  vmovaps [rsp+0xB0], xmm12
0000796d027d79e9  vmovaps [rsp+0xC0], xmm13
0000796d027d79f2  vmovaps [rsp+0xD0], xmm14
0000796d027d79fb  vmovaps [rsp+0xE0], xmm15
0000796d027d7a04  sub rsp, 0x30
0000796d027d7a08  movaps [rsp], xmm3
0000796d027d7a0c  movaps [rsp+0x10], xmm1
0000796d027d7a11  movaps [rsp+0x20], xmm9
0000796d027d7a17  lea rdi, [rsp]
0000796d027d7a1b  mov esi, 0x00
0000796d027d7a20  mov rax, 0x635FBE957530
0000796d027d7a2a  call rax
0000796d027d7a2c  movaps xmm3, [rsp]
0000796d027d7a30  add rsp, 0x30
0000796d027d7a34  vmovaps xmm0, [rsp]
0000796d027d7a39  vmovaps xmm1, [rsp+0x10]
0000796d027d7a3f  vmovaps xmm2, [rsp+0x20]
0000796d027d7a45  vmovaps xmm4, [rsp+0x30]
0000796d027d7a4b  vmovaps xmm5, [rsp+0x40]
0000796d027d7a51  vmovaps xmm6, [rsp+0x50]
0000796d027d7a57  vmovaps xmm7, [rsp+0x60]
0000796d027d7a5d  vmovaps xmm8, [rsp+0x70]
0000796d027d7a63  vmovaps xmm9, [rsp+0x80]
0000796d027d7a6c  vmovaps xmm10, [rsp+0x90]
0000796d027d7a75  vmovaps xmm11, [rsp+0xA0]
0000796d027d7a7e  vmovaps xmm12, [rsp+0xB0]
0000796d027d7a87  vmovaps xmm13, [rsp+0xC0]
0000796d027d7a90  vmovaps xmm14, [rsp+0xD0]
0000796d027d7a99  vmovaps xmm15, [rsp+0xE0]
0000796d027d7aa2  add rsp, 0xF0
0000796d027d7aa9  pop r11
0000796d027d7aab  pop r10
0000796d027d7aad  pop r9
0000796d027d7aaf  pop r8
0000796d027d7ab1  pop rsi
0000796d027d7ab2  pop rdi
0000796d027d7ab3  pop rdx
0000796d027d7ab4  pop rcx
0000796d027d7ab5  pop rax
0000796d027d7ab6  add rsp, 0x08
0000796d027d7aba  jmp 0x0000796D027D5D43
0000796d027d7abf  sub rsp, 0x08
0000796d027d7ac3  push rax
0000796d027d7ac4  push rcx
0000796d027d7ac5  push rdx
0000796d027d7ac6  push rdi
0000796d027d7ac7  push rsi
0000796d027d7ac8  push r8
0000796d027d7aca  push r9
0000796d027d7acc  push r10
0000796d027d7ace  push r11
0000796d027d7ad0  sub rsp, 0xF0
0000796d027d7ad7  vmovaps [rsp], xmm0
0000796d027d7adc  vmovaps [rsp+0x10], xmm2
0000796d027d7ae2  vmovaps [rsp+0x20], xmm3
0000796d027d7ae8  vmovaps [rsp+0x30], xmm4
0000796d027d7aee  vmovaps [rsp+0x40], xmm5
0000796d027d7af4  vmovaps [rsp+0x50], xmm6
0000796d027d7afa  vmovaps [rsp+0x60], xmm7
0000796d027d7b00  vmovaps [rsp+0x70], xmm8
0000796d027d7b06  vmovaps [rsp+0x80], xmm9
0000796d027d7b0f  vmovaps [rsp+0x90], xmm10
0000796d027d7b18  vmovaps [rsp+0xA0], xmm11
0000796d027d7b21  vmovaps [rsp+0xB0], xmm12
0000796d027d7b2a  vmovaps [rsp+0xC0], xmm13
0000796d027d7b33  vmovaps [rsp+0xD0], xmm14
0000796d027d7b3c  vmovaps [rsp+0xE0], xmm15
0000796d027d7b45  sub rsp, 0x30
0000796d027d7b49  movaps [rsp], xmm1
0000796d027d7b4d  movaps [rsp+0x10], xmm15
0000796d027d7b53  movaps [rsp+0x20], xmm9
0000796d027d7b59  lea rdi, [rsp]
0000796d027d7b5d  mov esi, 0x00
0000796d027d7b62  mov rax, 0x635FBE957530
0000796d027d7b6c  call rax
0000796d027d7b6e  movaps xmm1, [rsp]
0000796d027d7b72  add rsp, 0x30
0000796d027d7b76  vmovaps xmm0, [rsp]
0000796d027d7b7b  vmovaps xmm2, [rsp+0x10]
0000796d027d7b81  vmovaps xmm3, [rsp+0x20]
0000796d027d7b87  vmovaps xmm4, [rsp+0x30]
0000796d027d7b8d  vmovaps xmm5, [rsp+0x40]
0000796d027d7b93  vmovaps xmm6, [rsp+0x50]
0000796d027d7b99  vmovaps xmm7, [rsp+0x60]
0000796d027d7b9f  vmovaps xmm8, [rsp+0x70]
0000796d027d7ba5  vmovaps xmm9, [rsp+0x80]
0000796d027d7bae  vmovaps xmm10, [rsp+0x90]
0000796d027d7bb7  vmovaps xmm11, [rsp+0xA0]
0000796d027d7bc0  vmovaps xmm12, [rsp+0xB0]
0000796d027d7bc9  vmovaps xmm13, [rsp+0xC0]
0000796d027d7bd2  vmovaps xmm14, [rsp+0xD0]
0000796d027d7bdb  vmovaps xmm15, [rsp+0xE0]
0000796d027d7be4  add rsp, 0xF0
0000796d027d7beb  pop r11
0000796d027d7bed  pop r10
0000796d027d7bef  pop r9
0000796d027d7bf1  pop r8
0000796d027d7bf3  pop rsi
0000796d027d7bf4  pop rdi
0000796d027d7bf5  pop rdx
0000796d027d7bf6  pop rcx
0000796d027d7bf7  pop rax
0000796d027d7bf8  add rsp, 0x08
0000796d027d7bfc  jmp 0x0000796D027D5DCB
0000796d027d7c01  call 0x0000796D026E5820
0000796d027d7c06  jmp 0x0000796D027D5DD8
0000796d027d7c0b  sub rsp, 0x08
0000796d027d7c0f  push rax
0000796d027d7c10  push rcx
0000796d027d7c11  push rdx
0000796d027d7c12  push rdi
0000796d027d7c13  push rsi
0000796d027d7c14  push r8
0000796d027d7c16  push r9
0000796d027d7c18  push r10
0000796d027d7c1a  push r11
0000796d027d7c1c  sub rsp, 0xF0
0000796d027d7c23  vmovaps [rsp], xmm0
0000796d027d7c28  vmovaps [rsp+0x10], xmm2
0000796d027d7c2e  vmovaps [rsp+0x20], xmm3
0000796d027d7c34  vmovaps [rsp+0x30], xmm4
0000796d027d7c3a  vmovaps [rsp+0x40], xmm5
0000796d027d7c40  vmovaps [rsp+0x50], xmm6
0000796d027d7c46  vmovaps [rsp+0x60], xmm7
0000796d027d7c4c  vmovaps [rsp+0x70], xmm8
0000796d027d7c52  vmovaps [rsp+0x80], xmm9
0000796d027d7c5b  vmovaps [rsp+0x90], xmm10
0000796d027d7c64  vmovaps [rsp+0xA0], xmm11
0000796d027d7c6d  vmovaps [rsp+0xB0], xmm12
0000796d027d7c76  vmovaps [rsp+0xC0], xmm13
0000796d027d7c7f  vmovaps [rsp+0xD0], xmm14
0000796d027d7c88  vmovaps [rsp+0xE0], xmm15
0000796d027d7c91  sub rsp, 0x30
0000796d027d7c95  movaps [rsp], xmm1
0000796d027d7c99  movaps [rsp+0x10], xmm5
0000796d027d7c9e  movaps [rsp+0x20], xmm7
0000796d027d7ca3  lea rdi, [rsp]
0000796d027d7ca7  mov esi, 0x00
0000796d027d7cac  mov rax, 0x635FBE957530
0000796d027d7cb6  call rax
0000796d027d7cb8  movaps xmm1, [rsp]
0000796d027d7cbc  add rsp, 0x30
0000796d027d7cc0  vmovaps xmm0, [rsp]
0000796d027d7cc5  vmovaps xmm2, [rsp+0x10]
0000796d027d7ccb  vmovaps xmm3, [rsp+0x20]
0000796d027d7cd1  vmovaps xmm4, [rsp+0x30]
0000796d027d7cd7  vmovaps xmm5, [rsp+0x40]
0000796d027d7cdd  vmovaps xmm6, [rsp+0x50]
0000796d027d7ce3  vmovaps xmm7, [rsp+0x60]
0000796d027d7ce9  vmovaps xmm8, [rsp+0x70]
0000796d027d7cef  vmovaps xmm9, [rsp+0x80]
0000796d027d7cf8  vmovaps xmm10, [rsp+0x90]
0000796d027d7d01  vmovaps xmm11, [rsp+0xA0]
0000796d027d7d0a  vmovaps xmm12, [rsp+0xB0]
0000796d027d7d13  vmovaps xmm13, [rsp+0xC0]
0000796d027d7d1c  vmovaps xmm14, [rsp+0xD0]
0000796d027d7d25  vmovaps xmm15, [rsp+0xE0]
0000796d027d7d2e  add rsp, 0xF0
0000796d027d7d35  pop r11
0000796d027d7d37  pop r10
0000796d027d7d39  pop r9
0000796d027d7d3b  pop r8
0000796d027d7d3d  pop rsi
0000796d027d7d3e  pop rdi
0000796d027d7d3f  pop rdx
0000796d027d7d40  pop rcx
0000796d027d7d41  pop rax
0000796d027d7d42  add rsp, 0x08
0000796d027d7d46  jmp 0x0000796D027D5E7D
0000796d027d7d4b  sub rsp, 0x08
0000796d027d7d4f  push rax
0000796d027d7d50  push rcx
0000796d027d7d51  push rdx
0000796d027d7d52  push rdi
0000796d027d7d53  push rsi
0000796d027d7d54  push r8
0000796d027d7d56  push r9
0000796d027d7d58  push r10
0000796d027d7d5a  push r11
0000796d027d7d5c  sub rsp, 0xF0
0000796d027d7d63  vmovaps [rsp], xmm0
0000796d027d7d68  vmovaps [rsp+0x10], xmm1
0000796d027d7d6e  vmovaps [rsp+0x20], xmm2
0000796d027d7d74  vmovaps [rsp+0x30], xmm3
0000796d027d7d7a  vmovaps [rsp+0x40], xmm4
0000796d027d7d80  vmovaps [rsp+0x50], xmm5
0000796d027d7d86  vmovaps [rsp+0x60], xmm6
0000796d027d7d8c  vmovaps [rsp+0x70], xmm8
0000796d027d7d92  vmovaps [rsp+0x80], xmm9
0000796d027d7d9b  vmovaps [rsp+0x90], xmm10
0000796d027d7da4  vmovaps [rsp+0xA0], xmm11
0000796d027d7dad  vmovaps [rsp+0xB0], xmm12
0000796d027d7db6  vmovaps [rsp+0xC0], xmm13
0000796d027d7dbf  vmovaps [rsp+0xD0], xmm14
0000796d027d7dc8  vmovaps [rsp+0xE0], xmm15
0000796d027d7dd1  sub rsp, 0x30
0000796d027d7dd5  movaps [rsp], xmm7
0000796d027d7dd9  movaps [rsp+0x10], xmm5
0000796d027d7dde  movaps [rsp+0x20], xmm15
0000796d027d7de4  lea rdi, [rsp]
0000796d027d7de8  mov esi, 0x00
0000796d027d7ded  mov rax, 0x635FBE957530
0000796d027d7df7  call rax
0000796d027d7df9  movaps xmm7, [rsp]
0000796d027d7dfd  add rsp, 0x30
0000796d027d7e01  vmovaps xmm0, [rsp]
0000796d027d7e06  vmovaps xmm1, [rsp+0x10]
0000796d027d7e0c  vmovaps xmm2, [rsp+0x20]
0000796d027d7e12  vmovaps xmm3, [rsp+0x30]
0000796d027d7e18  vmovaps xmm4, [rsp+0x40]
0000796d027d7e1e  vmovaps xmm5, [rsp+0x50]
0000796d027d7e24  vmovaps xmm6, [rsp+0x60]
0000796d027d7e2a  vmovaps xmm8, [rsp+0x70]
0000796d027d7e30  vmovaps xmm9, [rsp+0x80]
0000796d027d7e39  vmovaps xmm10, [rsp+0x90]
0000796d027d7e42  vmovaps xmm11, [rsp+0xA0]
0000796d027d7e4b  vmovaps xmm12, [rsp+0xB0]
0000796d027d7e54  vmovaps xmm13, [rsp+0xC0]
0000796d027d7e5d  vmovaps xmm14, [rsp+0xD0]
0000796d027d7e66  vmovaps xmm15, [rsp+0xE0]
0000796d027d7e6f  add rsp, 0xF0
0000796d027d7e76  pop r11
0000796d027d7e78  pop r10
0000796d027d7e7a  pop r9
0000796d027d7e7c  pop r8
0000796d027d7e7e  pop rsi
0000796d027d7e7f  pop rdi
0000796d027d7e80  pop rdx
0000796d027d7e81  pop rcx
0000796d027d7e82  pop rax
0000796d027d7e83  add rsp, 0x08
0000796d027d7e87  jmp 0x0000796D027D5EB3
0000796d027d7e8c  call 0x0000796D026D64F0
0000796d027d7e91  jmp 0x0000796D027D5EC0
0000796d027d7e96  sub rsp, 0x08
0000796d027d7e9a  push rax
0000796d027d7e9b  push rcx
0000796d027d7e9c  push rdx
0000796d027d7e9d  push rdi
0000796d027d7e9e  push rsi
0000796d027d7e9f  push r8
0000796d027d7ea1  push r9
0000796d027d7ea3  push r10
0000796d027d7ea5  push r11
0000796d027d7ea7  sub rsp, 0xF0
0000796d027d7eae  vmovaps [rsp], xmm0
0000796d027d7eb3  vmovaps [rsp+0x10], xmm1
0000796d027d7eb9  vmovaps [rsp+0x20], xmm2
0000796d027d7ebf  vmovaps [rsp+0x30], xmm3
0000796d027d7ec5  vmovaps [rsp+0x40], xmm4
0000796d027d7ecb  vmovaps [rsp+0x50], xmm5
0000796d027d7ed1  vmovaps [rsp+0x60], xmm6
0000796d027d7ed7  vmovaps [rsp+0x70], xmm7
0000796d027d7edd  vmovaps [rsp+0x80], xmm8
0000796d027d7ee6  vmovaps [rsp+0x90], xmm9
0000796d027d7eef  vmovaps [rsp+0xA0], xmm10
0000796d027d7ef8  vmovaps [rsp+0xB0], xmm11
0000796d027d7f01  vmovaps [rsp+0xC0], xmm12
0000796d027d7f0a  vmovaps [rsp+0xD0], xmm13
0000796d027d7f13  vmovaps [rsp+0xE0], xmm14
0000796d027d7f1c  sub rsp, 0x30
0000796d027d7f20  movaps [rsp], xmm15
0000796d027d7f25  movaps [rsp+0x10], xmm5
0000796d027d7f2a  movaps [rsp+0x20], xmm3
0000796d027d7f2f  lea rdi, [rsp]
0000796d027d7f33  mov esi, 0x00
0000796d027d7f38  mov rax, 0x635FBE957530
0000796d027d7f42  call rax
0000796d027d7f44  movaps xmm15, [rsp]
0000796d027d7f49  add rsp, 0x30
0000796d027d7f4d  vmovaps xmm0, [rsp]
0000796d027d7f52  vmovaps xmm1, [rsp+0x10]
0000796d027d7f58  vmovaps xmm2, [rsp+0x20]
0000796d027d7f5e  vmovaps xmm3, [rsp+0x30]
0000796d027d7f64  vmovaps xmm4, [rsp+0x40]
0000796d027d7f6a  vmovaps xmm5, [rsp+0x50]
0000796d027d7f70  vmovaps xmm6, [rsp+0x60]
0000796d027d7f76  vmovaps xmm7, [rsp+0x70]
0000796d027d7f7c  vmovaps xmm8, [rsp+0x80]
0000796d027d7f85  vmovaps xmm9, [rsp+0x90]
0000796d027d7f8e  vmovaps xmm10, [rsp+0xA0]
0000796d027d7f97  vmovaps xmm11, [rsp+0xB0]
0000796d027d7fa0  vmovaps xmm12, [rsp+0xC0]
0000796d027d7fa9  vmovaps xmm13, [rsp+0xD0]
0000796d027d7fb2  vmovaps xmm14, [rsp+0xE0]
0000796d027d7fbb  add rsp, 0xF0
0000796d027d7fc2  pop r11
0000796d027d7fc4  pop r10
0000796d027d7fc6  pop r9
0000796d027d7fc8  pop r8
0000796d027d7fca  pop rsi
0000796d027d7fcb  pop rdi
0000796d027d7fcc  pop rdx
0000796d027d7fcd  pop rcx
0000796d027d7fce  pop rax
0000796d027d7fcf  add rsp, 0x08
0000796d027d7fd3  jmp 0x0000796D027D5EE6
0000796d027d7fd8  sub rsp, 0x08
0000796d027d7fdc  push rax
0000796d027d7fdd  push rcx
0000796d027d7fde  push rdx
0000796d027d7fdf  push rdi
0000796d027d7fe0  push rsi
0000796d027d7fe1  push r8
0000796d027d7fe3  push r9
0000796d027d7fe5  push r10
0000796d027d7fe7  push r11
0000796d027d7fe9  sub rsp, 0xF0
0000796d027d7ff0  vmovaps [rsp], xmm0
0000796d027d7ff5  vmovaps [rsp+0x10], xmm2
0000796d027d7ffb  vmovaps [rsp+0x20], xmm3
0000796d027d8001  vmovaps [rsp+0x30], xmm4
0000796d027d8007  vmovaps [rsp+0x40], xmm5
0000796d027d800d  vmovaps [rsp+0x50], xmm6
0000796d027d8013  vmovaps [rsp+0x60], xmm7
0000796d027d8019  vmovaps [rsp+0x70], xmm8
0000796d027d801f  vmovaps [rsp+0x80], xmm9
0000796d027d8028  vmovaps [rsp+0x90], xmm10
0000796d027d8031  vmovaps [rsp+0xA0], xmm11
0000796d027d803a  vmovaps [rsp+0xB0], xmm12
0000796d027d8043  vmovaps [rsp+0xC0], xmm13
0000796d027d804c  vmovaps [rsp+0xD0], xmm14
0000796d027d8055  vmovaps [rsp+0xE0], xmm15
0000796d027d805e  sub rsp, 0x30
0000796d027d8062  movaps [rsp], xmm1
0000796d027d8066  movaps [rsp+0x10], xmm5
0000796d027d806b  movaps [rsp+0x20], xmm4
0000796d027d8070  lea rdi, [rsp]
0000796d027d8074  mov esi, 0x00
0000796d027d8079  mov rax, 0x635FBE957530
0000796d027d8083  call rax
0000796d027d8085  movaps xmm1, [rsp]
0000796d027d8089  add rsp, 0x30
0000796d027d808d  vmovaps xmm0, [rsp]
0000796d027d8092  vmovaps xmm2, [rsp+0x10]
0000796d027d8098  vmovaps xmm3, [rsp+0x20]
0000796d027d809e  vmovaps xmm4, [rsp+0x30]
0000796d027d80a4  vmovaps xmm5, [rsp+0x40]
0000796d027d80aa  vmovaps xmm6, [rsp+0x50]
0000796d027d80b0  vmovaps xmm7, [rsp+0x60]
0000796d027d80b6  vmovaps xmm8, [rsp+0x70]
0000796d027d80bc  vmovaps xmm9, [rsp+0x80]
0000796d027d80c5  vmovaps xmm10, [rsp+0x90]
0000796d027d80ce  vmovaps xmm11, [rsp+0xA0]
0000796d027d80d7  vmovaps xmm12, [rsp+0xB0]
0000796d027d80e0  vmovaps xmm13, [rsp+0xC0]
0000796d027d80e9  vmovaps xmm14, [rsp+0xD0]
0000796d027d80f2  vmovaps xmm15, [rsp+0xE0]
0000796d027d80fb  add rsp, 0xF0
0000796d027d8102  pop r11
0000796d027d8104  pop r10
0000796d027d8106  pop r9
0000796d027d8108  pop r8
0000796d027d810a  pop rsi
0000796d027d810b  pop rdi
0000796d027d810c  pop rdx
0000796d027d810d  pop rcx
0000796d027d810e  pop rax
0000796d027d810f  add rsp, 0x08
0000796d027d8113  jmp 0x0000796D027D5F06
0000796d027d8118  sub rsp, 0x08
0000796d027d811c  push rax
0000796d027d811d  push rcx
0000796d027d811e  push rdx
0000796d027d811f  push rdi
0000796d027d8120  push rsi
0000796d027d8121  push r8
0000796d027d8123  push r9
0000796d027d8125  push r10
0000796d027d8127  push r11
0000796d027d8129  sub rsp, 0xF0
0000796d027d8130  vmovaps [rsp], xmm0
0000796d027d8135  vmovaps [rsp+0x10], xmm1
0000796d027d813b  vmovaps [rsp+0x20], xmm2
0000796d027d8141  vmovaps [rsp+0x30], xmm3
0000796d027d8147  vmovaps [rsp+0x40], xmm5
0000796d027d814d  vmovaps [rsp+0x50], xmm6
0000796d027d8153  vmovaps [rsp+0x60], xmm7
0000796d027d8159  vmovaps [rsp+0x70], xmm8
0000796d027d815f  vmovaps [rsp+0x80], xmm9
0000796d027d8168  vmovaps [rsp+0x90], xmm10
0000796d027d8171  vmovaps [rsp+0xA0], xmm11
0000796d027d817a  vmovaps [rsp+0xB0], xmm12
0000796d027d8183  vmovaps [rsp+0xC0], xmm13
0000796d027d818c  vmovaps [rsp+0xD0], xmm14
0000796d027d8195  vmovaps [rsp+0xE0], xmm15
0000796d027d819e  sub rsp, 0x30
0000796d027d81a2  movaps [rsp], xmm4
0000796d027d81a6  movaps [rsp+0x10], xmm3
0000796d027d81ab  movaps [rsp+0x20], xmm5
0000796d027d81b0  lea rdi, [rsp]
0000796d027d81b4  mov esi, 0x00
0000796d027d81b9  mov rax, 0x635FBE957530
0000796d027d81c3  call rax
0000796d027d81c5  movaps xmm4, [rsp]
0000796d027d81c9  add rsp, 0x30
0000796d027d81cd  vmovaps xmm0, [rsp]
0000796d027d81d2  vmovaps xmm1, [rsp+0x10]
0000796d027d81d8  vmovaps xmm2, [rsp+0x20]
0000796d027d81de  vmovaps xmm3, [rsp+0x30]
0000796d027d81e4  vmovaps xmm5, [rsp+0x40]
0000796d027d81ea  vmovaps xmm6, [rsp+0x50]
0000796d027d81f0  vmovaps xmm7, [rsp+0x60]
0000796d027d81f6  vmovaps xmm8, [rsp+0x70]
0000796d027d81fc  vmovaps xmm9, [rsp+0x80]
0000796d027d8205  vmovaps xmm10, [rsp+0x90]
0000796d027d820e  vmovaps xmm11, [rsp+0xA0]
0000796d027d8217  vmovaps xmm12, [rsp+0xB0]
0000796d027d8220  vmovaps xmm13, [rsp+0xC0]
0000796d027d8229  vmovaps xmm14, [rsp+0xD0]
0000796d027d8232  vmovaps xmm15, [rsp+0xE0]
0000796d027d823b  add rsp, 0xF0
0000796d027d8242  pop r11
0000796d027d8244  pop r10
0000796d027d8246  pop r9
0000796d027d8248  pop r8
0000796d027d824a  pop rsi
0000796d027d824b  pop rdi
0000796d027d824c  pop rdx
0000796d027d824d  pop rcx
0000796d027d824e  pop rax
0000796d027d824f  add rsp, 0x08
0000796d027d8253  jmp 0x0000796D027D5F54
0000796d027d8258  call 0x0000796D026D64F0
0000796d027d825d  jmp 0x0000796D027D5F61
0000796d027d8262  sub rsp, 0x08
0000796d027d8266  push rax
0000796d027d8267  push rcx
0000796d027d8268  push rdx
0000796d027d8269  push rdi
0000796d027d826a  push rsi
0000796d027d826b  push r8
0000796d027d826d  push r9
0000796d027d826f  push r10
0000796d027d8271  push r11
0000796d027d8273  sub rsp, 0xF0
0000796d027d827a  vmovaps [rsp], xmm0
0000796d027d827f  vmovaps [rsp+0x10], xmm1
0000796d027d8285  vmovaps [rsp+0x20], xmm2
0000796d027d828b  vmovaps [rsp+0x30], xmm3
0000796d027d8291  vmovaps [rsp+0x40], xmm4
0000796d027d8297  vmovaps [rsp+0x50], xmm6
0000796d027d829d  vmovaps [rsp+0x60], xmm7
0000796d027d82a3  vmovaps [rsp+0x70], xmm8
0000796d027d82a9  vmovaps [rsp+0x80], xmm9
0000796d027d82b2  vmovaps [rsp+0x90], xmm10
0000796d027d82bb  vmovaps [rsp+0xA0], xmm11
0000796d027d82c4  vmovaps [rsp+0xB0], xmm12
0000796d027d82cd  vmovaps [rsp+0xC0], xmm13
0000796d027d82d6  vmovaps [rsp+0xD0], xmm14
0000796d027d82df  vmovaps [rsp+0xE0], xmm15
0000796d027d82e8  sub rsp, 0x30
0000796d027d82ec  movaps [rsp], xmm5
0000796d027d82f0  movaps [rsp+0x10], xmm6
0000796d027d82f5  movaps [rsp+0x20], xmm3
0000796d027d82fa  lea rdi, [rsp]
0000796d027d82fe  mov esi, 0x00
0000796d027d8303  mov rax, 0x635FBE957530
0000796d027d830d  call rax
0000796d027d830f  movaps xmm5, [rsp]
0000796d027d8313  add rsp, 0x30
0000796d027d8317  vmovaps xmm0, [rsp]
0000796d027d831c  vmovaps xmm1, [rsp+0x10]
0000796d027d8322  vmovaps xmm2, [rsp+0x20]
0000796d027d8328  vmovaps xmm3, [rsp+0x30]
0000796d027d832e  vmovaps xmm4, [rsp+0x40]
0000796d027d8334  vmovaps xmm6, [rsp+0x50]
0000796d027d833a  vmovaps xmm7, [rsp+0x60]
0000796d027d8340  vmovaps xmm8, [rsp+0x70]
0000796d027d8346  vmovaps xmm9, [rsp+0x80]
0000796d027d834f  vmovaps xmm10, [rsp+0x90]
0000796d027d8358  vmovaps xmm11, [rsp+0xA0]
0000796d027d8361  vmovaps xmm12, [rsp+0xB0]
0000796d027d836a  vmovaps xmm13, [rsp+0xC0]
0000796d027d8373  vmovaps xmm14, [rsp+0xD0]
0000796d027d837c  vmovaps xmm15, [rsp+0xE0]
0000796d027d8385  add rsp, 0xF0
0000796d027d838c  pop r11
0000796d027d838e  pop r10
0000796d027d8390  pop r9
0000796d027d8392  pop r8
0000796d027d8394  pop rsi
0000796d027d8395  pop rdi
0000796d027d8396  pop rdx
0000796d027d8397  pop rcx
0000796d027d8398  pop rax
0000796d027d8399  add rsp, 0x08
0000796d027d839d  jmp 0x0000796D027D5F87
0000796d027d83a2  sub rsp, 0x08
0000796d027d83a6  push rax
0000796d027d83a7  push rcx
0000796d027d83a8  push rdx
0000796d027d83a9  push rdi
0000796d027d83aa  push rsi
0000796d027d83ab  push r8
0000796d027d83ad  push r9
0000796d027d83af  push r10
0000796d027d83b1  push r11
0000796d027d83b3  sub rsp, 0xF0
0000796d027d83ba  vmovaps [rsp], xmm0
0000796d027d83bf  vmovaps [rsp+0x10], xmm1
0000796d027d83c5  vmovaps [rsp+0x20], xmm2
0000796d027d83cb  vmovaps [rsp+0x30], xmm3
0000796d027d83d1  vmovaps [rsp+0x40], xmm4
0000796d027d83d7  vmovaps [rsp+0x50], xmm5
0000796d027d83dd  vmovaps [rsp+0x60], xmm7
0000796d027d83e3  vmovaps [rsp+0x70], xmm8
0000796d027d83e9  vmovaps [rsp+0x80], xmm9
0000796d027d83f2  vmovaps [rsp+0x90], xmm10
0000796d027d83fb  vmovaps [rsp+0xA0], xmm11
0000796d027d8404  vmovaps [rsp+0xB0], xmm12
0000796d027d840d  vmovaps [rsp+0xC0], xmm13
0000796d027d8416  vmovaps [rsp+0xD0], xmm14
0000796d027d841f  vmovaps [rsp+0xE0], xmm15
0000796d027d8428  sub rsp, 0x30
0000796d027d842c  movaps [rsp], xmm6
0000796d027d8430  movaps [rsp+0x10], xmm9
0000796d027d8436  movaps [rsp+0x20], xmm1
0000796d027d843b  lea rdi, [rsp]
0000796d027d843f  mov esi, 0x00
0000796d027d8444  mov rax, 0x635FBE957530
0000796d027d844e  call rax
0000796d027d8450  movaps xmm6, [rsp]
0000796d027d8454  add rsp, 0x30
0000796d027d8458  vmovaps xmm0, [rsp]
0000796d027d845d  vmovaps xmm1, [rsp+0x10]
0000796d027d8463  vmovaps xmm2, [rsp+0x20]
0000796d027d8469  vmovaps xmm3, [rsp+0x30]
0000796d027d846f  vmovaps xmm4, [rsp+0x40]
0000796d027d8475  vmovaps xmm5, [rsp+0x50]
0000796d027d847b  vmovaps xmm7, [rsp+0x60]
0000796d027d8481  vmovaps xmm8, [rsp+0x70]
0000796d027d8487  vmovaps xmm9, [rsp+0x80]
0000796d027d8490  vmovaps xmm10, [rsp+0x90]
0000796d027d8499  vmovaps xmm11, [rsp+0xA0]
0000796d027d84a2  vmovaps xmm12, [rsp+0xB0]
0000796d027d84ab  vmovaps xmm13, [rsp+0xC0]
0000796d027d84b4  vmovaps xmm14, [rsp+0xD0]
0000796d027d84bd  vmovaps xmm15, [rsp+0xE0]
0000796d027d84c6  add rsp, 0xF0
0000796d027d84cd  pop r11
0000796d027d84cf  pop r10
0000796d027d84d1  pop r9
0000796d027d84d3  pop r8
0000796d027d84d5  pop rsi
0000796d027d84d6  pop rdi
0000796d027d84d7  pop rdx
0000796d027d84d8  pop rcx
0000796d027d84d9  pop rax
0000796d027d84da  add rsp, 0x08
0000796d027d84de  jmp 0x0000796D027D5FAB
0000796d027d84e3  sub rsp, 0x08
0000796d027d84e7  push rax
0000796d027d84e8  push rcx
0000796d027d84e9  push rdx
0000796d027d84ea  push rdi
0000796d027d84eb  push rsi
0000796d027d84ec  push r8
0000796d027d84ee  push r9
0000796d027d84f0  push r10
0000796d027d84f2  push r11
0000796d027d84f4  sub rsp, 0xF0
0000796d027d84fb  vmovaps [rsp], xmm0
0000796d027d8500  vmovaps [rsp+0x10], xmm1
0000796d027d8506  vmovaps [rsp+0x20], xmm2
0000796d027d850c  vmovaps [rsp+0x30], xmm3
0000796d027d8512  vmovaps [rsp+0x40], xmm4
0000796d027d8518  vmovaps [rsp+0x50], xmm5
0000796d027d851e  vmovaps [rsp+0x60], xmm6
0000796d027d8524  vmovaps [rsp+0x70], xmm7
0000796d027d852a  vmovaps [rsp+0x80], xmm8
0000796d027d8533  vmovaps [rsp+0x90], xmm10
0000796d027d853c  vmovaps [rsp+0xA0], xmm11
0000796d027d8545  vmovaps [rsp+0xB0], xmm12
0000796d027d854e  vmovaps [rsp+0xC0], xmm13
0000796d027d8557  vmovaps [rsp+0xD0], xmm14
0000796d027d8560  vmovaps [rsp+0xE0], xmm15
0000796d027d8569  sub rsp, 0x30
0000796d027d856d  movaps [rsp], xmm9
0000796d027d8572  movaps [rsp+0x10], xmm3
0000796d027d8577  movaps [rsp+0x20], xmm1
0000796d027d857c  lea rdi, [rsp]
0000796d027d8580  mov esi, 0x00
0000796d027d8585  mov rax, 0x635FBE957530
0000796d027d858f  call rax
0000796d027d8591  movaps xmm9, [rsp]
0000796d027d8596  add rsp, 0x30
0000796d027d859a  vmovaps xmm0, [rsp]
0000796d027d859f  vmovaps xmm1, [rsp+0x10]
0000796d027d85a5  vmovaps xmm2, [rsp+0x20]
0000796d027d85ab  vmovaps xmm3, [rsp+0x30]
0000796d027d85b1  vmovaps xmm4, [rsp+0x40]
0000796d027d85b7  vmovaps xmm5, [rsp+0x50]
0000796d027d85bd  vmovaps xmm6, [rsp+0x60]
0000796d027d85c3  vmovaps xmm7, [rsp+0x70]
0000796d027d85c9  vmovaps xmm8, [rsp+0x80]
0000796d027d85d2  vmovaps xmm10, [rsp+0x90]
0000796d027d85db  vmovaps xmm11, [rsp+0xA0]
0000796d027d85e4  vmovaps xmm12, [rsp+0xB0]
0000796d027d85ed  vmovaps xmm13, [rsp+0xC0]
0000796d027d85f6  vmovaps xmm14, [rsp+0xD0]
0000796d027d85ff  vmovaps xmm15, [rsp+0xE0]
0000796d027d8608  add rsp, 0xF0
0000796d027d860f  pop r11
0000796d027d8611  pop r10
0000796d027d8613  pop r9
0000796d027d8615  pop r8
0000796d027d8617  pop rsi
0000796d027d8618  pop rdi
0000796d027d8619  pop rdx
0000796d027d861a  pop rcx
0000796d027d861b  pop rax
0000796d027d861c  add rsp, 0x08
0000796d027d8620  jmp 0x0000796D027D5FF7
0000796d027d8625  call 0x0000796D026D64F0
0000796d027d862a  jmp 0x0000796D027D6004
0000796d027d862f  sub rsp, 0x08
0000796d027d8633  push rax
0000796d027d8634  push rcx
0000796d027d8635  push rdx
0000796d027d8636  push rdi
0000796d027d8637  push rsi
0000796d027d8638  push r8
0000796d027d863a  push r9
0000796d027d863c  push r10
0000796d027d863e  push r11
0000796d027d8640  sub rsp, 0xF0
0000796d027d8647  vmovaps [rsp], xmm0
0000796d027d864c  vmovaps [rsp+0x10], xmm1
0000796d027d8652  vmovaps [rsp+0x20], xmm2
0000796d027d8658  vmovaps [rsp+0x30], xmm3
0000796d027d865e  vmovaps [rsp+0x40], xmm4
0000796d027d8664  vmovaps [rsp+0x50], xmm5
0000796d027d866a  vmovaps [rsp+0x60], xmm6
0000796d027d8670  vmovaps [rsp+0x70], xmm7
0000796d027d8676  vmovaps [rsp+0x80], xmm8
0000796d027d867f  vmovaps [rsp+0x90], xmm9
0000796d027d8688  vmovaps [rsp+0xA0], xmm10
0000796d027d8691  vmovaps [rsp+0xB0], xmm11
0000796d027d869a  vmovaps [rsp+0xC0], xmm12
0000796d027d86a3  vmovaps [rsp+0xD0], xmm13
0000796d027d86ac  vmovaps [rsp+0xE0], xmm14
0000796d027d86b5  sub rsp, 0x30
0000796d027d86b9  movaps [rsp], xmm15
0000796d027d86be  movaps [rsp+0x10], xmm3
0000796d027d86c3  movaps [rsp+0x20], xmm7
0000796d027d86c8  lea rdi, [rsp]
0000796d027d86cc  mov esi, 0x00
0000796d027d86d1  mov rax, 0x635FBE957530
0000796d027d86db  call rax
0000796d027d86dd  movaps xmm15, [rsp]
0000796d027d86e2  add rsp, 0x30
0000796d027d86e6  vmovaps xmm0, [rsp]
0000796d027d86eb  vmovaps xmm1, [rsp+0x10]
0000796d027d86f1  vmovaps xmm2, [rsp+0x20]
0000796d027d86f7  vmovaps xmm3, [rsp+0x30]
0000796d027d86fd  vmovaps xmm4, [rsp+0x40]
0000796d027d8703  vmovaps xmm5, [rsp+0x50]
0000796d027d8709  vmovaps xmm6, [rsp+0x60]
0000796d027d870f  vmovaps xmm7, [rsp+0x70]
0000796d027d8715  vmovaps xmm8, [rsp+0x80]
0000796d027d871e  vmovaps xmm9, [rsp+0x90]
0000796d027d8727  vmovaps xmm10, [rsp+0xA0]
0000796d027d8730  vmovaps xmm11, [rsp+0xB0]
0000796d027d8739  vmovaps xmm12, [rsp+0xC0]
0000796d027d8742  vmovaps xmm13, [rsp+0xD0]
0000796d027d874b  vmovaps xmm14, [rsp+0xE0]
0000796d027d8754  add rsp, 0xF0
0000796d027d875b  pop r11
0000796d027d875d  pop r10
0000796d027d875f  pop r9
0000796d027d8761  pop r8
0000796d027d8763  pop rsi
0000796d027d8764  pop rdi
0000796d027d8765  pop rdx
0000796d027d8766  pop rcx
0000796d027d8767  pop rax
0000796d027d8768  add rsp, 0x08
0000796d027d876c  jmp 0x0000796D027D6030
0000796d027d8771  sub rsp, 0x08
0000796d027d8775  push rax
0000796d027d8776  push rcx
0000796d027d8777  push rdx
0000796d027d8778  push rdi
0000796d027d8779  push rsi
0000796d027d877a  push r8
0000796d027d877c  push r9
0000796d027d877e  push r10
0000796d027d8780  push r11
0000796d027d8782  sub rsp, 0xF0
0000796d027d8789  vmovaps [rsp], xmm0
0000796d027d878e  vmovaps [rsp+0x10], xmm1
0000796d027d8794  vmovaps [rsp+0x20], xmm2
0000796d027d879a  vmovaps [rsp+0x30], xmm4
0000796d027d87a0  vmovaps [rsp+0x40], xmm5
0000796d027d87a6  vmovaps [rsp+0x50], xmm6
0000796d027d87ac  vmovaps [rsp+0x60], xmm7
0000796d027d87b2  vmovaps [rsp+0x70], xmm8
0000796d027d87b8  vmovaps [rsp+0x80], xmm9
0000796d027d87c1  vmovaps [rsp+0x90], xmm10
0000796d027d87ca  vmovaps [rsp+0xA0], xmm11
0000796d027d87d3  vmovaps [rsp+0xB0], xmm12
0000796d027d87dc  vmovaps [rsp+0xC0], xmm13
0000796d027d87e5  vmovaps [rsp+0xD0], xmm14
0000796d027d87ee  vmovaps [rsp+0xE0], xmm15
0000796d027d87f7  sub rsp, 0x30
0000796d027d87fb  movaps [rsp], xmm3
0000796d027d87ff  movaps [rsp+0x10], xmm1
0000796d027d8804  movaps [rsp+0x20], xmm15
0000796d027d880a  lea rdi, [rsp]
0000796d027d880e  mov esi, 0x00
0000796d027d8813  mov rax, 0x635FBE957530
0000796d027d881d  call rax
0000796d027d881f  movaps xmm3, [rsp]
0000796d027d8823  add rsp, 0x30
0000796d027d8827  vmovaps xmm0, [rsp]
0000796d027d882c  vmovaps xmm1, [rsp+0x10]
0000796d027d8832  vmovaps xmm2, [rsp+0x20]
0000796d027d8838  vmovaps xmm4, [rsp+0x30]
0000796d027d883e  vmovaps xmm5, [rsp+0x40]
0000796d027d8844  vmovaps xmm6, [rsp+0x50]
0000796d027d884a  vmovaps xmm7, [rsp+0x60]
0000796d027d8850  vmovaps xmm8, [rsp+0x70]
0000796d027d8856  vmovaps xmm9, [rsp+0x80]
0000796d027d885f  vmovaps xmm10, [rsp+0x90]
0000796d027d8868  vmovaps xmm11, [rsp+0xA0]
0000796d027d8871  vmovaps xmm12, [rsp+0xB0]
0000796d027d887a  vmovaps xmm13, [rsp+0xC0]
0000796d027d8883  vmovaps xmm14, [rsp+0xD0]
0000796d027d888c  vmovaps xmm15, [rsp+0xE0]
0000796d027d8895  add rsp, 0xF0
0000796d027d889c  pop r11
0000796d027d889e  pop r10
0000796d027d88a0  pop r9
0000796d027d88a2  pop r8
0000796d027d88a4  pop rsi
0000796d027d88a5  pop rdi
0000796d027d88a6  pop rdx
0000796d027d88a7  pop rcx
0000796d027d88a8  pop rax
0000796d027d88a9  add rsp, 0x08
0000796d027d88ad  jmp 0x0000796D027D60BF
0000796d027d88b2  call 0x0000796D026D64F0
0000796d027d88b7  jmp 0x0000796D027D60C9
0000796d027d88bc  sub rsp, 0x08
0000796d027d88c0  push rax
0000796d027d88c1  push rcx
0000796d027d88c2  push rdx
0000796d027d88c3  push rdi
0000796d027d88c4  push rsi
0000796d027d88c5  push r8
0000796d027d88c7  push r9
0000796d027d88c9  push r10
0000796d027d88cb  push r11
0000796d027d88cd  sub rsp, 0xF0
0000796d027d88d4  vmovaps [rsp], xmm0
0000796d027d88d9  vmovaps [rsp+0x10], xmm1
0000796d027d88df  vmovaps [rsp+0x20], xmm2
0000796d027d88e5  vmovaps [rsp+0x30], xmm3
0000796d027d88eb  vmovaps [rsp+0x40], xmm4
0000796d027d88f1  vmovaps [rsp+0x50], xmm5
0000796d027d88f7  vmovaps [rsp+0x60], xmm6
0000796d027d88fd  vmovaps [rsp+0x70], xmm7
0000796d027d8903  vmovaps [rsp+0x80], xmm8
0000796d027d890c  vmovaps [rsp+0x90], xmm9
0000796d027d8915  vmovaps [rsp+0xA0], xmm10
0000796d027d891e  vmovaps [rsp+0xB0], xmm11
0000796d027d8927  vmovaps [rsp+0xC0], xmm12
0000796d027d8930  vmovaps [rsp+0xD0], xmm13
0000796d027d8939  vmovaps [rsp+0xE0], xmm14
0000796d027d8942  sub rsp, 0x30
0000796d027d8946  movaps [rsp], xmm15
0000796d027d894b  movaps [rsp+0x10], xmm14
0000796d027d8951  movaps [rsp+0x20], xmm4
0000796d027d8956  lea rdi, [rsp]
0000796d027d895a  mov esi, 0x00
0000796d027d895f  mov rax, 0x635FBE957530
0000796d027d8969  call rax
0000796d027d896b  movaps xmm15, [rsp]
0000796d027d8970  add rsp, 0x30
0000796d027d8974  vmovaps xmm0, [rsp]
0000796d027d8979  vmovaps xmm1, [rsp+0x10]
0000796d027d897f  vmovaps xmm2, [rsp+0x20]
0000796d027d8985  vmovaps xmm3, [rsp+0x30]
0000796d027d898b  vmovaps xmm4, [rsp+0x40]
0000796d027d8991  vmovaps xmm5, [rsp+0x50]
0000796d027d8997  vmovaps xmm6, [rsp+0x60]
0000796d027d899d  vmovaps xmm7, [rsp+0x70]
0000796d027d89a3  vmovaps xmm8, [rsp+0x80]
0000796d027d89ac  vmovaps xmm9, [rsp+0x90]
0000796d027d89b5  vmovaps xmm10, [rsp+0xA0]
0000796d027d89be  vmovaps xmm11, [rsp+0xB0]
0000796d027d89c7  vmovaps xmm12, [rsp+0xC0]
0000796d027d89d0  vmovaps xmm13, [rsp+0xD0]
0000796d027d89d9  vmovaps xmm14, [rsp+0xE0]
0000796d027d89e2  add rsp, 0xF0
0000796d027d89e9  pop r11
0000796d027d89eb  pop r10
0000796d027d89ed  pop r9
0000796d027d89ef  pop r8
0000796d027d89f1  pop rsi
0000796d027d89f2  pop rdi
0000796d027d89f3  pop rdx
0000796d027d89f4  pop rcx
0000796d027d89f5  pop rax
0000796d027d89f6  add rsp, 0x08
0000796d027d89fa  jmp 0x0000796D027D60F7
0000796d027d89ff  sub rsp, 0x08
0000796d027d8a03  push rax
0000796d027d8a04  push rcx
0000796d027d8a05  push rdx
0000796d027d8a06  push rdi
0000796d027d8a07  push rsi
0000796d027d8a08  push r8
0000796d027d8a0a  push r9
0000796d027d8a0c  push r10
0000796d027d8a0e  push r11
0000796d027d8a10  sub rsp, 0xF0
0000796d027d8a17  vmovaps [rsp], xmm0
0000796d027d8a1c  vmovaps [rsp+0x10], xmm1
0000796d027d8a22  vmovaps [rsp+0x20], xmm2
0000796d027d8a28  vmovaps [rsp+0x30], xmm3
0000796d027d8a2e  vmovaps [rsp+0x40], xmm4
0000796d027d8a34  vmovaps [rsp+0x50], xmm5
0000796d027d8a3a  vmovaps [rsp+0x60], xmm6
0000796d027d8a40  vmovaps [rsp+0x70], xmm7
0000796d027d8a46  vmovaps [rsp+0x80], xmm8
0000796d027d8a4f  vmovaps [rsp+0x90], xmm9
0000796d027d8a58  vmovaps [rsp+0xA0], xmm10
0000796d027d8a61  vmovaps [rsp+0xB0], xmm11
0000796d027d8a6a  vmovaps [rsp+0xC0], xmm12
0000796d027d8a73  vmovaps [rsp+0xD0], xmm13
0000796d027d8a7c  vmovaps [rsp+0xE0], xmm15
0000796d027d8a85  sub rsp, 0x30
0000796d027d8a89  movaps [rsp], xmm14
0000796d027d8a8e  movaps [rsp+0x10], xmm2
0000796d027d8a93  movaps [rsp+0x20], xmm1
0000796d027d8a98  lea rdi, [rsp]
0000796d027d8a9c  mov esi, 0x00
0000796d027d8aa1  mov rax, 0x635FBE957530
0000796d027d8aab  call rax
0000796d027d8aad  movaps xmm14, [rsp]
0000796d027d8ab2  add rsp, 0x30
0000796d027d8ab6  vmovaps xmm0, [rsp]
0000796d027d8abb  vmovaps xmm1, [rsp+0x10]
0000796d027d8ac1  vmovaps xmm2, [rsp+0x20]
0000796d027d8ac7  vmovaps xmm3, [rsp+0x30]
0000796d027d8acd  vmovaps xmm4, [rsp+0x40]
0000796d027d8ad3  vmovaps xmm5, [rsp+0x50]
0000796d027d8ad9  vmovaps xmm6, [rsp+0x60]
0000796d027d8adf  vmovaps xmm7, [rsp+0x70]
0000796d027d8ae5  vmovaps xmm8, [rsp+0x80]
0000796d027d8aee  vmovaps xmm9, [rsp+0x90]
0000796d027d8af7  vmovaps xmm10, [rsp+0xA0]
0000796d027d8b00  vmovaps xmm11, [rsp+0xB0]
0000796d027d8b09  vmovaps xmm12, [rsp+0xC0]
0000796d027d8b12  vmovaps xmm13, [rsp+0xD0]
0000796d027d8b1b  vmovaps xmm15, [rsp+0xE0]
0000796d027d8b24  add rsp, 0xF0
0000796d027d8b2b  pop r11
0000796d027d8b2d  pop r10
0000796d027d8b2f  pop r9
0000796d027d8b31  pop r8
0000796d027d8b33  pop rsi
0000796d027d8b34  pop rdi
0000796d027d8b35  pop rdx
0000796d027d8b36  pop rcx
0000796d027d8b37  pop rax
0000796d027d8b38  add rsp, 0x08
0000796d027d8b3c  jmp 0x0000796D027D611D
0000796d027d8b41  sub rsp, 0x08
0000796d027d8b45  push rax
0000796d027d8b46  push rcx
0000796d027d8b47  push rdx
0000796d027d8b48  push rdi
0000796d027d8b49  push rsi
0000796d027d8b4a  push r8
0000796d027d8b4c  push r9
0000796d027d8b4e  push r10
0000796d027d8b50  push r11
0000796d027d8b52  sub rsp, 0xF0
0000796d027d8b59  vmovaps [rsp], xmm0
0000796d027d8b5e  vmovaps [rsp+0x10], xmm2
0000796d027d8b64  vmovaps [rsp+0x20], xmm3
0000796d027d8b6a  vmovaps [rsp+0x30], xmm4
0000796d027d8b70  vmovaps [rsp+0x40], xmm5
0000796d027d8b76  vmovaps [rsp+0x50], xmm6
0000796d027d8b7c  vmovaps [rsp+0x60], xmm7
0000796d027d8b82  vmovaps [rsp+0x70], xmm8
0000796d027d8b88  vmovaps [rsp+0x80], xmm9
0000796d027d8b91  vmovaps [rsp+0x90], xmm10
0000796d027d8b9a  vmovaps [rsp+0xA0], xmm11
0000796d027d8ba3  vmovaps [rsp+0xB0], xmm12
0000796d027d8bac  vmovaps [rsp+0xC0], xmm13
0000796d027d8bb5  vmovaps [rsp+0xD0], xmm14
0000796d027d8bbe  vmovaps [rsp+0xE0], xmm15
0000796d027d8bc7  sub rsp, 0x30
0000796d027d8bcb  movaps [rsp], xmm1
0000796d027d8bcf  movaps [rsp+0x10], xmm4
0000796d027d8bd4  movaps [rsp+0x20], xmm9
0000796d027d8bda  lea rdi, [rsp]
0000796d027d8bde  mov esi, 0x00
0000796d027d8be3  mov rax, 0x635FBE957530
0000796d027d8bed  call rax
0000796d027d8bef  movaps xmm1, [rsp]
0000796d027d8bf3  add rsp, 0x30
0000796d027d8bf7  vmovaps xmm0, [rsp]
0000796d027d8bfc  vmovaps xmm2, [rsp+0x10]
0000796d027d8c02  vmovaps xmm3, [rsp+0x20]
0000796d027d8c08  vmovaps xmm4, [rsp+0x30]
0000796d027d8c0e  vmovaps xmm5, [rsp+0x40]
0000796d027d8c14  vmovaps xmm6, [rsp+0x50]
0000796d027d8c1a  vmovaps xmm7, [rsp+0x60]
0000796d027d8c20  vmovaps xmm8, [rsp+0x70]
0000796d027d8c26  vmovaps xmm9, [rsp+0x80]
0000796d027d8c2f  vmovaps xmm10, [rsp+0x90]
0000796d027d8c38  vmovaps xmm11, [rsp+0xA0]
0000796d027d8c41  vmovaps xmm12, [rsp+0xB0]
0000796d027d8c4a  vmovaps xmm13, [rsp+0xC0]
0000796d027d8c53  vmovaps xmm14, [rsp+0xD0]
0000796d027d8c5c  vmovaps xmm15, [rsp+0xE0]
0000796d027d8c65  add rsp, 0xF0
0000796d027d8c6c  pop r11
0000796d027d8c6e  pop r10
0000796d027d8c70  pop r9
0000796d027d8c72  pop r8
0000796d027d8c74  pop rsi
0000796d027d8c75  pop rdi
0000796d027d8c76  pop rdx
0000796d027d8c77  pop rcx
0000796d027d8c78  pop rax
0000796d027d8c79  add rsp, 0x08
0000796d027d8c7d  jmp 0x0000796D027D613B
0000796d027d8c82  sub rsp, 0x08
0000796d027d8c86  push rax
0000796d027d8c87  push rcx
0000796d027d8c88  push rdx
0000796d027d8c89  push rdi
0000796d027d8c8a  push rsi
0000796d027d8c8b  push r8
0000796d027d8c8d  push r9
0000796d027d8c8f  push r10
0000796d027d8c91  push r11
0000796d027d8c93  sub rsp, 0xF0
0000796d027d8c9a  vmovaps [rsp], xmm0
0000796d027d8c9f  vmovaps [rsp+0x10], xmm1
0000796d027d8ca5  vmovaps [rsp+0x20], xmm2
0000796d027d8cab  vmovaps [rsp+0x30], xmm3
0000796d027d8cb1  vmovaps [rsp+0x40], xmm5
0000796d027d8cb7  vmovaps [rsp+0x50], xmm6
0000796d027d8cbd  vmovaps [rsp+0x60], xmm7
0000796d027d8cc3  vmovaps [rsp+0x70], xmm8
0000796d027d8cc9  vmovaps [rsp+0x80], xmm9
0000796d027d8cd2  vmovaps [rsp+0x90], xmm10
0000796d027d8cdb  vmovaps [rsp+0xA0], xmm11
0000796d027d8ce4  vmovaps [rsp+0xB0], xmm12
0000796d027d8ced  vmovaps [rsp+0xC0], xmm13
0000796d027d8cf6  vmovaps [rsp+0xD0], xmm14
0000796d027d8cff  vmovaps [rsp+0xE0], xmm15
0000796d027d8d08  sub rsp, 0x30
0000796d027d8d0c  movaps [rsp], xmm4
0000796d027d8d10  movaps [rsp+0x10], xmm2
0000796d027d8d15  movaps [rsp+0x20], xmm9
0000796d027d8d1b  lea rdi, [rsp]
0000796d027d8d1f  mov esi, 0x00
0000796d027d8d24  mov rax, 0x635FBE957530
0000796d027d8d2e  call rax
0000796d027d8d30  movaps xmm4, [rsp]
0000796d027d8d34  add rsp, 0x30
0000796d027d8d38  vmovaps xmm0, [rsp]
0000796d027d8d3d  vmovaps xmm1, [rsp+0x10]
0000796d027d8d43  vmovaps xmm2, [rsp+0x20]
0000796d027d8d49  vmovaps xmm3, [rsp+0x30]
0000796d027d8d4f  vmovaps xmm5, [rsp+0x40]
0000796d027d8d55  vmovaps xmm6, [rsp+0x50]
0000796d027d8d5b  vmovaps xmm7, [rsp+0x60]
0000796d027d8d61  vmovaps xmm8, [rsp+0x70]
0000796d027d8d67  vmovaps xmm9, [rsp+0x80]
0000796d027d8d70  vmovaps xmm10, [rsp+0x90]
0000796d027d8d79  vmovaps xmm11, [rsp+0xA0]
0000796d027d8d82  vmovaps xmm12, [rsp+0xB0]
0000796d027d8d8b  vmovaps xmm13, [rsp+0xC0]
0000796d027d8d94  vmovaps xmm14, [rsp+0xD0]
0000796d027d8d9d  vmovaps xmm15, [rsp+0xE0]
0000796d027d8da6  add rsp, 0xF0
0000796d027d8dad  pop r11
0000796d027d8daf  pop r10
0000796d027d8db1  pop r9
0000796d027d8db3  pop r8
0000796d027d8db5  pop rsi
0000796d027d8db6  pop rdi
0000796d027d8db7  pop rdx
0000796d027d8db8  pop rcx
0000796d027d8db9  pop rax
0000796d027d8dba  add rsp, 0x08
0000796d027d8dbe  jmp 0x0000796D027D616B
0000796d027d8dc3  sub rsp, 0x08
0000796d027d8dc7  push rax
0000796d027d8dc8  push rcx
0000796d027d8dc9  push rdx
0000796d027d8dca  push rdi
0000796d027d8dcb  push rsi
0000796d027d8dcc  push r8
0000796d027d8dce  push r9
0000796d027d8dd0  push r10
0000796d027d8dd2  push r11
0000796d027d8dd4  sub rsp, 0xF0
0000796d027d8ddb  vmovaps [rsp], xmm0
0000796d027d8de0  vmovaps [rsp+0x10], xmm1
0000796d027d8de6  vmovaps [rsp+0x20], xmm2
0000796d027d8dec  vmovaps [rsp+0x30], xmm3
0000796d027d8df2  vmovaps [rsp+0x40], xmm4
0000796d027d8df8  vmovaps [rsp+0x50], xmm5
0000796d027d8dfe  vmovaps [rsp+0x60], xmm6
0000796d027d8e04  vmovaps [rsp+0x70], xmm7
0000796d027d8e0a  vmovaps [rsp+0x80], xmm8
0000796d027d8e13  vmovaps [rsp+0x90], xmm10
0000796d027d8e1c  vmovaps [rsp+0xA0], xmm11
0000796d027d8e25  vmovaps [rsp+0xB0], xmm12
0000796d027d8e2e  vmovaps [rsp+0xC0], xmm13
0000796d027d8e37  vmovaps [rsp+0xD0], xmm14
0000796d027d8e40  vmovaps [rsp+0xE0], xmm15
0000796d027d8e49  sub rsp, 0x30
0000796d027d8e4d  movaps [rsp], xmm9
0000796d027d8e52  movaps [rsp+0x10], xmm2
0000796d027d8e57  movaps [rsp+0x20], xmm1
0000796d027d8e5c  lea rdi, [rsp]
0000796d027d8e60  mov esi, 0x00
0000796d027d8e65  mov rax, 0x635FBE957530
0000796d027d8e6f  call rax
0000796d027d8e71  movaps xmm9, [rsp]
0000796d027d8e76  add rsp, 0x30
0000796d027d8e7a  vmovaps xmm0, [rsp]
0000796d027d8e7f  vmovaps xmm1, [rsp+0x10]
0000796d027d8e85  vmovaps xmm2, [rsp+0x20]
0000796d027d8e8b  vmovaps xmm3, [rsp+0x30]
0000796d027d8e91  vmovaps xmm4, [rsp+0x40]
0000796d027d8e97  vmovaps xmm5, [rsp+0x50]
0000796d027d8e9d  vmovaps xmm6, [rsp+0x60]
0000796d027d8ea3  vmovaps xmm7, [rsp+0x70]
0000796d027d8ea9  vmovaps xmm8, [rsp+0x80]
0000796d027d8eb2  vmovaps xmm10, [rsp+0x90]
0000796d027d8ebb  vmovaps xmm11, [rsp+0xA0]
0000796d027d8ec4  vmovaps xmm12, [rsp+0xB0]
0000796d027d8ecd  vmovaps xmm13, [rsp+0xC0]
0000796d027d8ed6  vmovaps xmm14, [rsp+0xD0]
0000796d027d8edf  vmovaps xmm15, [rsp+0xE0]
0000796d027d8ee8  add rsp, 0xF0
0000796d027d8eef  pop r11
0000796d027d8ef1  pop r10
0000796d027d8ef3  pop r9
0000796d027d8ef5  pop r8
0000796d027d8ef7  pop rsi
0000796d027d8ef8  pop rdi
0000796d027d8ef9  pop rdx
0000796d027d8efa  pop rcx
0000796d027d8efb  pop rax
0000796d027d8efc  add rsp, 0x08
0000796d027d8f00  jmp 0x0000796D027D61A1
0000796d027d8f05  sub rsp, 0x08
0000796d027d8f09  push rax
0000796d027d8f0a  push rcx
0000796d027d8f0b  push rdx
0000796d027d8f0c  push rdi
0000796d027d8f0d  push rsi
0000796d027d8f0e  push r8
0000796d027d8f10  push r9
0000796d027d8f12  push r10
0000796d027d8f14  push r11
0000796d027d8f16  sub rsp, 0xF0
0000796d027d8f1d  vmovaps [rsp], xmm0
0000796d027d8f22  vmovaps [rsp+0x10], xmm2
0000796d027d8f28  vmovaps [rsp+0x20], xmm3
0000796d027d8f2e  vmovaps [rsp+0x30], xmm4
0000796d027d8f34  vmovaps [rsp+0x40], xmm5
0000796d027d8f3a  vmovaps [rsp+0x50], xmm6
0000796d027d8f40  vmovaps [rsp+0x60], xmm7
0000796d027d8f46  vmovaps [rsp+0x70], xmm8
0000796d027d8f4c  vmovaps [rsp+0x80], xmm9
0000796d027d8f55  vmovaps [rsp+0x90], xmm10
0000796d027d8f5e  vmovaps [rsp+0xA0], xmm11
0000796d027d8f67  vmovaps [rsp+0xB0], xmm12
0000796d027d8f70  vmovaps [rsp+0xC0], xmm13
0000796d027d8f79  vmovaps [rsp+0xD0], xmm14
0000796d027d8f82  vmovaps [rsp+0xE0], xmm15
0000796d027d8f8b  sub rsp, 0x30
0000796d027d8f8f  movaps [rsp], xmm1
0000796d027d8f93  movaps [rsp+0x10], xmm15
0000796d027d8f99  movaps [rsp+0x20], xmm6
0000796d027d8f9e  lea rdi, [rsp]
0000796d027d8fa2  mov esi, 0x00
0000796d027d8fa7  mov rax, 0x635FBE957530
0000796d027d8fb1  call rax
0000796d027d8fb3  movaps xmm1, [rsp]
0000796d027d8fb7  add rsp, 0x30
0000796d027d8fbb  vmovaps xmm0, [rsp]
0000796d027d8fc0  vmovaps xmm2, [rsp+0x10]
0000796d027d8fc6  vmovaps xmm3, [rsp+0x20]
0000796d027d8fcc  vmovaps xmm4, [rsp+0x30]
0000796d027d8fd2  vmovaps xmm5, [rsp+0x40]
0000796d027d8fd8  vmovaps xmm6, [rsp+0x50]
0000796d027d8fde  vmovaps xmm7, [rsp+0x60]
0000796d027d8fe4  vmovaps xmm8, [rsp+0x70]
0000796d027d8fea  vmovaps xmm9, [rsp+0x80]
0000796d027d8ff3  vmovaps xmm10, [rsp+0x90]
0000796d027d8ffc  vmovaps xmm11, [rsp+0xA0]
0000796d027d9005  vmovaps xmm12, [rsp+0xB0]
0000796d027d900e  vmovaps xmm13, [rsp+0xC0]
0000796d027d9017  vmovaps xmm14, [rsp+0xD0]
0000796d027d9020  vmovaps xmm15, [rsp+0xE0]
0000796d027d9029  add rsp, 0xF0
0000796d027d9030  pop r11
0000796d027d9032  pop r10
0000796d027d9034  pop r9
0000796d027d9036  pop r8
0000796d027d9038  pop rsi
0000796d027d9039  pop rdi
0000796d027d903a  pop rdx
0000796d027d903b  pop rcx
0000796d027d903c  pop rax
0000796d027d903d  add rsp, 0x08
0000796d027d9041  jmp 0x0000796D027D61C2
0000796d027d9046  sub rsp, 0x08
0000796d027d904a  push rax
0000796d027d904b  push rcx
0000796d027d904c  push rdx
0000796d027d904d  push rdi
0000796d027d904e  push rsi
0000796d027d904f  push r8
0000796d027d9051  push r9
0000796d027d9053  push r10
0000796d027d9055  push r11
0000796d027d9057  sub rsp, 0xF0
0000796d027d905e  vmovaps [rsp], xmm0
0000796d027d9063  vmovaps [rsp+0x10], xmm1
0000796d027d9069  vmovaps [rsp+0x20], xmm2
0000796d027d906f  vmovaps [rsp+0x30], xmm3
0000796d027d9075  vmovaps [rsp+0x40], xmm4
0000796d027d907b  vmovaps [rsp+0x50], xmm5
0000796d027d9081  vmovaps [rsp+0x60], xmm6
0000796d027d9087  vmovaps [rsp+0x70], xmm7
0000796d027d908d  vmovaps [rsp+0x80], xmm8
0000796d027d9096  vmovaps [rsp+0x90], xmm9
0000796d027d909f  vmovaps [rsp+0xA0], xmm10
0000796d027d90a8  vmovaps [rsp+0xB0], xmm11
0000796d027d90b1  vmovaps [rsp+0xC0], xmm12
0000796d027d90ba  vmovaps [rsp+0xD0], xmm13
0000796d027d90c3  vmovaps [rsp+0xE0], xmm14
0000796d027d90cc  sub rsp, 0x30
0000796d027d90d0  movaps [rsp], xmm15
0000796d027d90d5  movaps [rsp+0x10], xmm5
0000796d027d90da  movaps [rsp+0x20], xmm3
0000796d027d90df  lea rdi, [rsp]
0000796d027d90e3  mov esi, 0x00
0000796d027d90e8  mov rax, 0x635FBE957530
0000796d027d90f2  call rax
0000796d027d90f4  movaps xmm15, [rsp]
0000796d027d90f9  add rsp, 0x30
0000796d027d90fd  vmovaps xmm0, [rsp]
0000796d027d9102  vmovaps xmm1, [rsp+0x10]
0000796d027d9108  vmovaps xmm2, [rsp+0x20]
0000796d027d910e  vmovaps xmm3, [rsp+0x30]
0000796d027d9114  vmovaps xmm4, [rsp+0x40]
0000796d027d911a  vmovaps xmm5, [rsp+0x50]
0000796d027d9120  vmovaps xmm6, [rsp+0x60]
0000796d027d9126  vmovaps xmm7, [rsp+0x70]
0000796d027d912c  vmovaps xmm8, [rsp+0x80]
0000796d027d9135  vmovaps xmm9, [rsp+0x90]
0000796d027d913e  vmovaps xmm10, [rsp+0xA0]
0000796d027d9147  vmovaps xmm11, [rsp+0xB0]
0000796d027d9150  vmovaps xmm12, [rsp+0xC0]
0000796d027d9159  vmovaps xmm13, [rsp+0xD0]
0000796d027d9162  vmovaps xmm14, [rsp+0xE0]
0000796d027d916b  add rsp, 0xF0
0000796d027d9172  pop r11
0000796d027d9174  pop r10
0000796d027d9176  pop r9
0000796d027d9178  pop r8
0000796d027d917a  pop rsi
0000796d027d917b  pop rdi
0000796d027d917c  pop rdx
0000796d027d917d  pop rcx
0000796d027d917e  pop rax
0000796d027d917f  add rsp, 0x08
0000796d027d9183  jmp 0x0000796D027D61DC
0000796d027d9188  sub rsp, 0x08
0000796d027d918c  push rax
0000796d027d918d  push rcx
0000796d027d918e  push rdx
0000796d027d918f  push rdi
0000796d027d9190  push rsi
0000796d027d9191  push r8
0000796d027d9193  push r9
0000796d027d9195  push r10
0000796d027d9197  push r11
0000796d027d9199  sub rsp, 0xF0
0000796d027d91a0  vmovaps [rsp], xmm0
0000796d027d91a5  vmovaps [rsp+0x10], xmm1
0000796d027d91ab  vmovaps [rsp+0x20], xmm2
0000796d027d91b1  vmovaps [rsp+0x30], xmm3
0000796d027d91b7  vmovaps [rsp+0x40], xmm4
0000796d027d91bd  vmovaps [rsp+0x50], xmm6
0000796d027d91c3  vmovaps [rsp+0x60], xmm7
0000796d027d91c9  vmovaps [rsp+0x70], xmm8
0000796d027d91cf  vmovaps [rsp+0x80], xmm9
0000796d027d91d8  vmovaps [rsp+0x90], xmm10
0000796d027d91e1  vmovaps [rsp+0xA0], xmm11
0000796d027d91ea  vmovaps [rsp+0xB0], xmm12
0000796d027d91f3  vmovaps [rsp+0xC0], xmm13
0000796d027d91fc  vmovaps [rsp+0xD0], xmm14
0000796d027d9205  vmovaps [rsp+0xE0], xmm15
0000796d027d920e  sub rsp, 0x30
0000796d027d9212  movaps [rsp], xmm5
0000796d027d9216  movaps [rsp+0x10], xmm8
0000796d027d921c  movaps [rsp+0x20], xmm6
0000796d027d9221  lea rdi, [rsp]
0000796d027d9225  mov esi, 0x00
0000796d027d922a  mov rax, 0x635FBE957530
0000796d027d9234  call rax
0000796d027d9236  movaps xmm5, [rsp]
0000796d027d923a  add rsp, 0x30
0000796d027d923e  vmovaps xmm0, [rsp]
0000796d027d9243  vmovaps xmm1, [rsp+0x10]
0000796d027d9249  vmovaps xmm2, [rsp+0x20]
0000796d027d924f  vmovaps xmm3, [rsp+0x30]
0000796d027d9255  vmovaps xmm4, [rsp+0x40]
0000796d027d925b  vmovaps xmm6, [rsp+0x50]
0000796d027d9261  vmovaps xmm7, [rsp+0x60]
0000796d027d9267  vmovaps xmm8, [rsp+0x70]
0000796d027d926d  vmovaps xmm9, [rsp+0x80]
0000796d027d9276  vmovaps xmm10, [rsp+0x90]
0000796d027d927f  vmovaps xmm11, [rsp+0xA0]
0000796d027d9288  vmovaps xmm12, [rsp+0xB0]
0000796d027d9291  vmovaps xmm13, [rsp+0xC0]
0000796d027d929a  vmovaps xmm14, [rsp+0xD0]
0000796d027d92a3  vmovaps xmm15, [rsp+0xE0]
0000796d027d92ac  add rsp, 0xF0
0000796d027d92b3  pop r11
0000796d027d92b5  pop r10
0000796d027d92b7  pop r9
0000796d027d92b9  pop r8
0000796d027d92bb  pop rsi
0000796d027d92bc  pop rdi
0000796d027d92bd  pop rdx
0000796d027d92be  pop rcx
0000796d027d92bf  pop rax
0000796d027d92c0  add rsp, 0x08
0000796d027d92c4  jmp 0x0000796D027D6200
0000796d027d92c9  sub rsp, 0x08
0000796d027d92cd  push rax
0000796d027d92ce  push rcx
0000796d027d92cf  push rdx
0000796d027d92d0  push rdi
0000796d027d92d1  push rsi
0000796d027d92d2  push r8
0000796d027d92d4  push r9
0000796d027d92d6  push r10
0000796d027d92d8  push r11
0000796d027d92da  sub rsp, 0xF0
0000796d027d92e1  vmovaps [rsp], xmm0
0000796d027d92e6  vmovaps [rsp+0x10], xmm1
0000796d027d92ec  vmovaps [rsp+0x20], xmm2
0000796d027d92f2  vmovaps [rsp+0x30], xmm3
0000796d027d92f8  vmovaps [rsp+0x40], xmm4
0000796d027d92fe  vmovaps [rsp+0x50], xmm5
0000796d027d9304  vmovaps [rsp+0x60], xmm7
0000796d027d930a  vmovaps [rsp+0x70], xmm8
0000796d027d9310  vmovaps [rsp+0x80], xmm9
0000796d027d9319  vmovaps [rsp+0x90], xmm10
0000796d027d9322  vmovaps [rsp+0xA0], xmm11
0000796d027d932b  vmovaps [rsp+0xB0], xmm12
0000796d027d9334  vmovaps [rsp+0xC0], xmm13
0000796d027d933d  vmovaps [rsp+0xD0], xmm14
0000796d027d9346  vmovaps [rsp+0xE0], xmm15
0000796d027d934f  sub rsp, 0x30
0000796d027d9353  movaps [rsp], xmm6
0000796d027d9357  movaps [rsp+0x10], xmm10
0000796d027d935d  movaps [rsp+0x20], xmm8
0000796d027d9363  lea rdi, [rsp]
0000796d027d9367  mov esi, 0x00
0000796d027d936c  mov rax, 0x635FBE957530
0000796d027d9376  call rax
0000796d027d9378  movaps xmm6, [rsp]
0000796d027d937c  add rsp, 0x30
0000796d027d9380  vmovaps xmm0, [rsp]
0000796d027d9385  vmovaps xmm1, [rsp+0x10]
0000796d027d938b  vmovaps xmm2, [rsp+0x20]
0000796d027d9391  vmovaps xmm3, [rsp+0x30]
0000796d027d9397  vmovaps xmm4, [rsp+0x40]
0000796d027d939d  vmovaps xmm5, [rsp+0x50]
0000796d027d93a3  vmovaps xmm7, [rsp+0x60]
0000796d027d93a9  vmovaps xmm8, [rsp+0x70]
0000796d027d93af  vmovaps xmm9, [rsp+0x80]
0000796d027d93b8  vmovaps xmm10, [rsp+0x90]
0000796d027d93c1  vmovaps xmm11, [rsp+0xA0]
0000796d027d93ca  vmovaps xmm12, [rsp+0xB0]
0000796d027d93d3  vmovaps xmm13, [rsp+0xC0]
0000796d027d93dc  vmovaps xmm14, [rsp+0xD0]
0000796d027d93e5  vmovaps xmm15, [rsp+0xE0]
0000796d027d93ee  add rsp, 0xF0
0000796d027d93f5  pop r11
0000796d027d93f7  pop r10
0000796d027d93f9  pop r9
0000796d027d93fb  pop r8
0000796d027d93fd  pop rsi
0000796d027d93fe  pop rdi
0000796d027d93ff  pop rdx
0000796d027d9400  pop rcx
0000796d027d9401  pop rax
0000796d027d9402  add rsp, 0x08
0000796d027d9406  jmp 0x0000796D027D6225
0000796d027d940b  sub rsp, 0x08
0000796d027d940f  push rax
0000796d027d9410  push rcx
0000796d027d9411  push rdx
0000796d027d9412  push rdi
0000796d027d9413  push rsi
0000796d027d9414  push r8
0000796d027d9416  push r9
0000796d027d9418  push r10
0000796d027d941a  push r11
0000796d027d941c  sub rsp, 0xF0
0000796d027d9423  vmovaps [rsp], xmm0
0000796d027d9428  vmovaps [rsp+0x10], xmm1
0000796d027d942e  vmovaps [rsp+0x20], xmm2
0000796d027d9434  vmovaps [rsp+0x30], xmm3
0000796d027d943a  vmovaps [rsp+0x40], xmm4
0000796d027d9440  vmovaps [rsp+0x50], xmm5
0000796d027d9446  vmovaps [rsp+0x60], xmm6
0000796d027d944c  vmovaps [rsp+0x70], xmm7
0000796d027d9452  vmovaps [rsp+0x80], xmm8
0000796d027d945b  vmovaps [rsp+0x90], xmm9
0000796d027d9464  vmovaps [rsp+0xA0], xmm11
0000796d027d946d  vmovaps [rsp+0xB0], xmm12
0000796d027d9476  vmovaps [rsp+0xC0], xmm13
0000796d027d947f  vmovaps [rsp+0xD0], xmm14
0000796d027d9488  vmovaps [rsp+0xE0], xmm15
0000796d027d9491  sub rsp, 0x30
0000796d027d9495  movaps [rsp], xmm10
0000796d027d949a  movaps [rsp+0x10], xmm8
0000796d027d94a0  movaps [rsp+0x20], xmm14
0000796d027d94a6  lea rdi, [rsp]
0000796d027d94aa  mov esi, 0x00
0000796d027d94af  mov rax, 0x635FBE957530
0000796d027d94b9  call rax
0000796d027d94bb  movaps xmm10, [rsp]
0000796d027d94c0  add rsp, 0x30
0000796d027d94c4  vmovaps xmm0, [rsp]
0000796d027d94c9  vmovaps xmm1, [rsp+0x10]
0000796d027d94cf  vmovaps xmm2, [rsp+0x20]
0000796d027d94d5  vmovaps xmm3, [rsp+0x30]
0000796d027d94db  vmovaps xmm4, [rsp+0x40]
0000796d027d94e1  vmovaps xmm5, [rsp+0x50]
0000796d027d94e7  vmovaps xmm6, [rsp+0x60]
0000796d027d94ed  vmovaps xmm7, [rsp+0x70]
0000796d027d94f3  vmovaps xmm8, [rsp+0x80]
0000796d027d94fc  vmovaps xmm9, [rsp+0x90]
0000796d027d9505  vmovaps xmm11, [rsp+0xA0]
0000796d027d950e  vmovaps xmm12, [rsp+0xB0]
0000796d027d9517  vmovaps xmm13, [rsp+0xC0]
0000796d027d9520  vmovaps xmm14, [rsp+0xD0]
0000796d027d9529  vmovaps xmm15, [rsp+0xE0]
0000796d027d9532  add rsp, 0xF0
0000796d027d9539  pop r11
0000796d027d953b  pop r10
0000796d027d953d  pop r9
0000796d027d953f  pop r8
0000796d027d9541  pop rsi
0000796d027d9542  pop rdi
0000796d027d9543  pop rdx
0000796d027d9544  pop rcx
0000796d027d9545  pop rax
0000796d027d9546  add rsp, 0x08
0000796d027d954a  jmp 0x0000796D027D6245
0000796d027d954f  sub rsp, 0x08
0000796d027d9553  push rax
0000796d027d9554  push rcx
0000796d027d9555  push rdx
0000796d027d9556  push rdi
0000796d027d9557  push rsi
0000796d027d9558  push r8
0000796d027d955a  push r9
0000796d027d955c  push r10
0000796d027d955e  push r11
0000796d027d9560  sub rsp, 0xF0
0000796d027d9567  vmovaps [rsp], xmm0
0000796d027d956c  vmovaps [rsp+0x10], xmm1
0000796d027d9572  vmovaps [rsp+0x20], xmm2
0000796d027d9578  vmovaps [rsp+0x30], xmm3
0000796d027d957e  vmovaps [rsp+0x40], xmm4
0000796d027d9584  vmovaps [rsp+0x50], xmm5
0000796d027d958a  vmovaps [rsp+0x60], xmm6
0000796d027d9590  vmovaps [rsp+0x70], xmm7
0000796d027d9596  vmovaps [rsp+0x80], xmm8
0000796d027d959f  vmovaps [rsp+0x90], xmm9
0000796d027d95a8  vmovaps [rsp+0xA0], xmm10
0000796d027d95b1  vmovaps [rsp+0xB0], xmm11
0000796d027d95ba  vmovaps [rsp+0xC0], xmm12
0000796d027d95c3  vmovaps [rsp+0xD0], xmm13
0000796d027d95cc  vmovaps [rsp+0xE0], xmm15
0000796d027d95d5  sub rsp, 0x30
0000796d027d95d9  movaps [rsp], xmm14
0000796d027d95de  movaps [rsp+0x10], xmm8
0000796d027d95e4  movaps [rsp+0x20], xmm4
0000796d027d95e9  lea rdi, [rsp]
0000796d027d95ed  mov esi, 0x00
0000796d027d95f2  mov rax, 0x635FBE957530
0000796d027d95fc  call rax
0000796d027d95fe  movaps xmm14, [rsp]
0000796d027d9603  add rsp, 0x30
0000796d027d9607  vmovaps xmm0, [rsp]
0000796d027d960c  vmovaps xmm1, [rsp+0x10]
0000796d027d9612  vmovaps xmm2, [rsp+0x20]
0000796d027d9618  vmovaps xmm3, [rsp+0x30]
0000796d027d961e  vmovaps xmm4, [rsp+0x40]
0000796d027d9624  vmovaps xmm5, [rsp+0x50]
0000796d027d962a  vmovaps xmm6, [rsp+0x60]
0000796d027d9630  vmovaps xmm7, [rsp+0x70]
0000796d027d9636  vmovaps xmm8, [rsp+0x80]
0000796d027d963f  vmovaps xmm9, [rsp+0x90]
0000796d027d9648  vmovaps xmm10, [rsp+0xA0]
0000796d027d9651  vmovaps xmm11, [rsp+0xB0]
0000796d027d965a  vmovaps xmm12, [rsp+0xC0]
0000796d027d9663  vmovaps xmm13, [rsp+0xD0]
0000796d027d966c  vmovaps xmm15, [rsp+0xE0]
0000796d027d9675  add rsp, 0xF0
0000796d027d967c  pop r11
0000796d027d967e  pop r10
0000796d027d9680  pop r9
0000796d027d9682  pop r8
0000796d027d9684  pop rsi
0000796d027d9685  pop rdi
0000796d027d9686  pop rdx
0000796d027d9687  pop rcx
0000796d027d9688  pop rax
0000796d027d9689  add rsp, 0x08
0000796d027d968d  jmp 0x0000796D027D6265
0000796d027d9692  sub rsp, 0x08
0000796d027d9696  push rax
0000796d027d9697  push rcx
0000796d027d9698  push rdx
0000796d027d9699  push rdi
0000796d027d969a  push rsi
0000796d027d969b  push r8
0000796d027d969d  push r9
0000796d027d969f  push r10
0000796d027d96a1  push r11
0000796d027d96a3  sub rsp, 0xF0
0000796d027d96aa  vmovaps [rsp], xmm0
0000796d027d96af  vmovaps [rsp+0x10], xmm1
0000796d027d96b5  vmovaps [rsp+0x20], xmm2
0000796d027d96bb  vmovaps [rsp+0x30], xmm3
0000796d027d96c1  vmovaps [rsp+0x40], xmm5
0000796d027d96c7  vmovaps [rsp+0x50], xmm6
0000796d027d96cd  vmovaps [rsp+0x60], xmm7
0000796d027d96d3  vmovaps [rsp+0x70], xmm8
0000796d027d96d9  vmovaps [rsp+0x80], xmm9
0000796d027d96e2  vmovaps [rsp+0x90], xmm10
0000796d027d96eb  vmovaps [rsp+0xA0], xmm11
0000796d027d96f4  vmovaps [rsp+0xB0], xmm12
0000796d027d96fd  vmovaps [rsp+0xC0], xmm13
0000796d027d9706  vmovaps [rsp+0xD0], xmm14
0000796d027d970f  vmovaps [rsp+0xE0], xmm15
0000796d027d9718  sub rsp, 0x30
0000796d027d971c  movaps [rsp], xmm4
0000796d027d9720  movaps [rsp+0x10], xmm13
0000796d027d9726  movaps [rsp+0x20], xmm8
0000796d027d972c  lea rdi, [rsp]
0000796d027d9730  mov esi, 0x00
0000796d027d9735  mov rax, 0x635FBE957530
0000796d027d973f  call rax
0000796d027d9741  movaps xmm4, [rsp]
0000796d027d9745  add rsp, 0x30
0000796d027d9749  vmovaps xmm0, [rsp]
0000796d027d974e  vmovaps xmm1, [rsp+0x10]
0000796d027d9754  vmovaps xmm2, [rsp+0x20]
0000796d027d975a  vmovaps xmm3, [rsp+0x30]
0000796d027d9760  vmovaps xmm5, [rsp+0x40]
0000796d027d9766  vmovaps xmm6, [rsp+0x50]
0000796d027d976c  vmovaps xmm7, [rsp+0x60]
0000796d027d9772  vmovaps xmm8, [rsp+0x70]
0000796d027d9778  vmovaps xmm9, [rsp+0x80]
0000796d027d9781  vmovaps xmm10, [rsp+0x90]
0000796d027d978a  vmovaps xmm11, [rsp+0xA0]
0000796d027d9793  vmovaps xmm12, [rsp+0xB0]
0000796d027d979c  vmovaps xmm13, [rsp+0xC0]
0000796d027d97a5  vmovaps xmm14, [rsp+0xD0]
0000796d027d97ae  vmovaps xmm15, [rsp+0xE0]
0000796d027d97b7  add rsp, 0xF0
0000796d027d97be  pop r11
0000796d027d97c0  pop r10
0000796d027d97c2  pop r9
0000796d027d97c4  pop r8
0000796d027d97c6  pop rsi
0000796d027d97c7  pop rdi
0000796d027d97c8  pop rdx
0000796d027d97c9  pop rcx
0000796d027d97ca  pop rax
0000796d027d97cb  add rsp, 0x08
0000796d027d97cf  jmp 0x0000796D027D628A
0000796d027d97d4  sub rsp, 0x08
0000796d027d97d8  push rax
0000796d027d97d9  push rcx
0000796d027d97da  push rdx
0000796d027d97db  push rdi
0000796d027d97dc  push rsi
0000796d027d97dd  push r8
0000796d027d97df  push r9
0000796d027d97e1  push r10
0000796d027d97e3  push r11
0000796d027d97e5  sub rsp, 0xF0
0000796d027d97ec  vmovaps [rsp], xmm0
0000796d027d97f1  vmovaps [rsp+0x10], xmm1
0000796d027d97f7  vmovaps [rsp+0x20], xmm2
0000796d027d97fd  vmovaps [rsp+0x30], xmm3
0000796d027d9803  vmovaps [rsp+0x40], xmm4
0000796d027d9809  vmovaps [rsp+0x50], xmm5
0000796d027d980f  vmovaps [rsp+0x60], xmm6
0000796d027d9815  vmovaps [rsp+0x70], xmm7
0000796d027d981b  vmovaps [rsp+0x80], xmm8
0000796d027d9824  vmovaps [rsp+0x90], xmm9
0000796d027d982d  vmovaps [rsp+0xA0], xmm10
0000796d027d9836  vmovaps [rsp+0xB0], xmm11
0000796d027d983f  vmovaps [rsp+0xC0], xmm12
0000796d027d9848  vmovaps [rsp+0xD0], xmm14
0000796d027d9851  vmovaps [rsp+0xE0], xmm15
0000796d027d985a  sub rsp, 0x30
0000796d027d985e  movaps [rsp], xmm13
0000796d027d9863  movaps [rsp+0x10], xmm15
0000796d027d9869  movaps [rsp+0x20], xmm9
0000796d027d986f  lea rdi, [rsp]
0000796d027d9873  mov esi, 0x00
0000796d027d9878  mov rax, 0x635FBE957530
0000796d027d9882  call rax
0000796d027d9884  movaps xmm13, [rsp]
0000796d027d9889  add rsp, 0x30
0000796d027d988d  vmovaps xmm0, [rsp]
0000796d027d9892  vmovaps xmm1, [rsp+0x10]
0000796d027d9898  vmovaps xmm2, [rsp+0x20]
0000796d027d989e  vmovaps xmm3, [rsp+0x30]
0000796d027d98a4  vmovaps xmm4, [rsp+0x40]
0000796d027d98aa  vmovaps xmm5, [rsp+0x50]
0000796d027d98b0  vmovaps xmm6, [rsp+0x60]
0000796d027d98b6  vmovaps xmm7, [rsp+0x70]
0000796d027d98bc  vmovaps xmm8, [rsp+0x80]
0000796d027d98c5  vmovaps xmm9, [rsp+0x90]
0000796d027d98ce  vmovaps xmm10, [rsp+0xA0]
0000796d027d98d7  vmovaps xmm11, [rsp+0xB0]
0000796d027d98e0  vmovaps xmm12, [rsp+0xC0]
0000796d027d98e9  vmovaps xmm14, [rsp+0xD0]
0000796d027d98f2  vmovaps xmm15, [rsp+0xE0]
0000796d027d98fb  add rsp, 0xF0
0000796d027d9902  pop r11
0000796d027d9904  pop r10
0000796d027d9906  pop r9
0000796d027d9908  pop r8
0000796d027d990a  pop rsi
0000796d027d990b  pop rdi
0000796d027d990c  pop rdx
0000796d027d990d  pop rcx
0000796d027d990e  pop rax
0000796d027d990f  add rsp, 0x08
0000796d027d9913  jmp 0x0000796D027D62A5
0000796d027d9918  sub rsp, 0x08
0000796d027d991c  push rax
0000796d027d991d  push rcx
0000796d027d991e  push rdx
0000796d027d991f  push rdi
0000796d027d9920  push rsi
0000796d027d9921  push r8
0000796d027d9923  push r9
0000796d027d9925  push r10
0000796d027d9927  push r11
0000796d027d9929  sub rsp, 0xF0
0000796d027d9930  vmovaps [rsp], xmm0
0000796d027d9935  vmovaps [rsp+0x10], xmm1
0000796d027d993b  vmovaps [rsp+0x20], xmm2
0000796d027d9941  vmovaps [rsp+0x30], xmm3
0000796d027d9947  vmovaps [rsp+0x40], xmm4
0000796d027d994d  vmovaps [rsp+0x50], xmm5
0000796d027d9953  vmovaps [rsp+0x60], xmm6
0000796d027d9959  vmovaps [rsp+0x70], xmm7
0000796d027d995f  vmovaps [rsp+0x80], xmm8
0000796d027d9968  vmovaps [rsp+0x90], xmm9
0000796d027d9971  vmovaps [rsp+0xA0], xmm10
0000796d027d997a  vmovaps [rsp+0xB0], xmm11
0000796d027d9983  vmovaps [rsp+0xC0], xmm12
0000796d027d998c  vmovaps [rsp+0xD0], xmm13
0000796d027d9995  vmovaps [rsp+0xE0], xmm14
0000796d027d999e  sub rsp, 0x30
0000796d027d99a2  movaps [rsp], xmm15
0000796d027d99a7  movaps [rsp+0x10], xmm1
0000796d027d99ac  movaps [rsp+0x20], xmm5
0000796d027d99b1  lea rdi, [rsp]
0000796d027d99b5  mov esi, 0x00
0000796d027d99ba  mov rax, 0x635FBE957530
0000796d027d99c4  call rax
0000796d027d99c6  movaps xmm15, [rsp]
0000796d027d99cb  add rsp, 0x30
0000796d027d99cf  vmovaps xmm0, [rsp]
0000796d027d99d4  vmovaps xmm1, [rsp+0x10]
0000796d027d99da  vmovaps xmm2, [rsp+0x20]
0000796d027d99e0  vmovaps xmm3, [rsp+0x30]
0000796d027d99e6  vmovaps xmm4, [rsp+0x40]
0000796d027d99ec  vmovaps xmm5, [rsp+0x50]
0000796d027d99f2  vmovaps xmm6, [rsp+0x60]
0000796d027d99f8  vmovaps xmm7, [rsp+0x70]
0000796d027d99fe  vmovaps xmm8, [rsp+0x80]
0000796d027d9a07  vmovaps xmm9, [rsp+0x90]
0000796d027d9a10  vmovaps xmm10, [rsp+0xA0]
0000796d027d9a19  vmovaps xmm11, [rsp+0xB0]
0000796d027d9a22  vmovaps xmm12, [rsp+0xC0]
0000796d027d9a2b  vmovaps xmm13, [rsp+0xD0]
0000796d027d9a34  vmovaps xmm14, [rsp+0xE0]
0000796d027d9a3d  add rsp, 0xF0
0000796d027d9a44  pop r11
0000796d027d9a46  pop r10
0000796d027d9a48  pop r9
0000796d027d9a4a  pop r8
0000796d027d9a4c  pop rsi
0000796d027d9a4d  pop rdi
0000796d027d9a4e  pop rdx
0000796d027d9a4f  pop rcx
0000796d027d9a50  pop rax
0000796d027d9a51  add rsp, 0x08
0000796d027d9a55  jmp 0x0000796D027D62C0
0000796d027d9a5a  call 0x0000796D026D64F0
0000796d027d9a5f  jmp 0x0000796D027D631B
0000796d027d9a64  sub rsp, 0x08
0000796d027d9a68  push rax
0000796d027d9a69  push rcx
0000796d027d9a6a  push rdx
0000796d027d9a6b  push rdi
0000796d027d9a6c  push rsi
0000796d027d9a6d  push r8
0000796d027d9a6f  push r9
0000796d027d9a71  push r10
0000796d027d9a73  push r11
0000796d027d9a75  sub rsp, 0xF0
0000796d027d9a7c  vmovaps [rsp], xmm0
0000796d027d9a81  vmovaps [rsp+0x10], xmm1
0000796d027d9a87  vmovaps [rsp+0x20], xmm2
0000796d027d9a8d  vmovaps [rsp+0x30], xmm3
0000796d027d9a93  vmovaps [rsp+0x40], xmm4
0000796d027d9a99  vmovaps [rsp+0x50], xmm5
0000796d027d9a9f  vmovaps [rsp+0x60], xmm6
0000796d027d9aa5  vmovaps [rsp+0x70], xmm7
0000796d027d9aab  vmovaps [rsp+0x80], xmm8
0000796d027d9ab4  vmovaps [rsp+0x90], xmm10
0000796d027d9abd  vmovaps [rsp+0xA0], xmm11
0000796d027d9ac6  vmovaps [rsp+0xB0], xmm12
0000796d027d9acf  vmovaps [rsp+0xC0], xmm13
0000796d027d9ad8  vmovaps [rsp+0xD0], xmm14
0000796d027d9ae1  vmovaps [rsp+0xE0], xmm15
0000796d027d9aea  sub rsp, 0x30
0000796d027d9aee  movaps [rsp], xmm9
0000796d027d9af3  movaps [rsp+0x10], xmm8
0000796d027d9af9  movaps [rsp+0x20], xmm11
0000796d027d9aff  lea rdi, [rsp]
0000796d027d9b03  mov esi, 0x00
0000796d027d9b08  mov rax, 0x635FBE957530
0000796d027d9b12  call rax
0000796d027d9b14  movaps xmm9, [rsp]
0000796d027d9b19  add rsp, 0x30
0000796d027d9b1d  vmovaps xmm0, [rsp]
0000796d027d9b22  vmovaps xmm1, [rsp+0x10]
0000796d027d9b28  vmovaps xmm2, [rsp+0x20]
0000796d027d9b2e  vmovaps xmm3, [rsp+0x30]
0000796d027d9b34  vmovaps xmm4, [rsp+0x40]
0000796d027d9b3a  vmovaps xmm5, [rsp+0x50]
0000796d027d9b40  vmovaps xmm6, [rsp+0x60]
0000796d027d9b46  vmovaps xmm7, [rsp+0x70]
0000796d027d9b4c  vmovaps xmm8, [rsp+0x80]
0000796d027d9b55  vmovaps xmm10, [rsp+0x90]
0000796d027d9b5e  vmovaps xmm11, [rsp+0xA0]
0000796d027d9b67  vmovaps xmm12, [rsp+0xB0]
0000796d027d9b70  vmovaps xmm13, [rsp+0xC0]
0000796d027d9b79  vmovaps xmm14, [rsp+0xD0]
0000796d027d9b82  vmovaps xmm15, [rsp+0xE0]
0000796d027d9b8b  add rsp, 0xF0
0000796d027d9b92  pop r11
0000796d027d9b94  pop r10
0000796d027d9b96  pop r9
0000796d027d9b98  pop r8
0000796d027d9b9a  pop rsi
0000796d027d9b9b  pop rdi
0000796d027d9b9c  pop rdx
0000796d027d9b9d  pop rcx
0000796d027d9b9e  pop rax
0000796d027d9b9f  add rsp, 0x08
0000796d027d9ba3  jmp 0x0000796D027D6352
0000796d027d9ba8  sub rsp, 0x08
0000796d027d9bac  push rax
0000796d027d9bad  push rcx
0000796d027d9bae  push rdx
0000796d027d9baf  push rdi
0000796d027d9bb0  push rsi
0000796d027d9bb1  push r8
0000796d027d9bb3  push r9
0000796d027d9bb5  push r10
0000796d027d9bb7  push r11
0000796d027d9bb9  sub rsp, 0xF0
0000796d027d9bc0  vmovaps [rsp], xmm0
0000796d027d9bc5  vmovaps [rsp+0x10], xmm1
0000796d027d9bcb  vmovaps [rsp+0x20], xmm2
0000796d027d9bd1  vmovaps [rsp+0x30], xmm3
0000796d027d9bd7  vmovaps [rsp+0x40], xmm4
0000796d027d9bdd  vmovaps [rsp+0x50], xmm5
0000796d027d9be3  vmovaps [rsp+0x60], xmm6
0000796d027d9be9  vmovaps [rsp+0x70], xmm7
0000796d027d9bef  vmovaps [rsp+0x80], xmm8
0000796d027d9bf8  vmovaps [rsp+0x90], xmm9
0000796d027d9c01  vmovaps [rsp+0xA0], xmm10
0000796d027d9c0a  vmovaps [rsp+0xB0], xmm12
0000796d027d9c13  vmovaps [rsp+0xC0], xmm13
0000796d027d9c1c  vmovaps [rsp+0xD0], xmm14
0000796d027d9c25  vmovaps [rsp+0xE0], xmm15
0000796d027d9c2e  sub rsp, 0x30
0000796d027d9c32  movaps [rsp], xmm11
0000796d027d9c37  movaps [rsp+0x10], xmm10
0000796d027d9c3d  movaps [rsp+0x20], xmm6
0000796d027d9c42  lea rdi, [rsp]
0000796d027d9c46  mov esi, 0x00
0000796d027d9c4b  mov rax, 0x635FBE957530
0000796d027d9c55  call rax
0000796d027d9c57  movaps xmm11, [rsp]
0000796d027d9c5c  add rsp, 0x30
0000796d027d9c60  vmovaps xmm0, [rsp]
0000796d027d9c65  vmovaps xmm1, [rsp+0x10]
0000796d027d9c6b  vmovaps xmm2, [rsp+0x20]
0000796d027d9c71  vmovaps xmm3, [rsp+0x30]
0000796d027d9c77  vmovaps xmm4, [rsp+0x40]
0000796d027d9c7d  vmovaps xmm5, [rsp+0x50]
0000796d027d9c83  vmovaps xmm6, [rsp+0x60]
0000796d027d9c89  vmovaps xmm7, [rsp+0x70]
0000796d027d9c8f  vmovaps xmm8, [rsp+0x80]
0000796d027d9c98  vmovaps xmm9, [rsp+0x90]
0000796d027d9ca1  vmovaps xmm10, [rsp+0xA0]
0000796d027d9caa  vmovaps xmm12, [rsp+0xB0]
0000796d027d9cb3  vmovaps xmm13, [rsp+0xC0]
0000796d027d9cbc  vmovaps xmm14, [rsp+0xD0]
0000796d027d9cc5  vmovaps xmm15, [rsp+0xE0]
0000796d027d9cce  add rsp, 0xF0
0000796d027d9cd5  pop r11
0000796d027d9cd7  pop r10
0000796d027d9cd9  pop r9
0000796d027d9cdb  pop r8
0000796d027d9cdd  pop rsi
0000796d027d9cde  pop rdi
0000796d027d9cdf  pop rdx
0000796d027d9ce0  pop rcx
0000796d027d9ce1  pop rax
0000796d027d9ce2  add rsp, 0x08
0000796d027d9ce6  jmp 0x0000796D027D636D
0000796d027d9ceb  sub rsp, 0x08
0000796d027d9cef  push rax
0000796d027d9cf0  push rcx
0000796d027d9cf1  push rdx
0000796d027d9cf2  push rdi
0000796d027d9cf3  push rsi
0000796d027d9cf4  push r8
0000796d027d9cf6  push r9
0000796d027d9cf8  push r10
0000796d027d9cfa  push r11
0000796d027d9cfc  sub rsp, 0xF0
0000796d027d9d03  vmovaps [rsp], xmm0
0000796d027d9d08  vmovaps [rsp+0x10], xmm1
0000796d027d9d0e  vmovaps [rsp+0x20], xmm2
0000796d027d9d14  vmovaps [rsp+0x30], xmm3
0000796d027d9d1a  vmovaps [rsp+0x40], xmm4
0000796d027d9d20  vmovaps [rsp+0x50], xmm5
0000796d027d9d26  vmovaps [rsp+0x60], xmm6
0000796d027d9d2c  vmovaps [rsp+0x70], xmm7
0000796d027d9d32  vmovaps [rsp+0x80], xmm8
0000796d027d9d3b  vmovaps [rsp+0x90], xmm9
0000796d027d9d44  vmovaps [rsp+0xA0], xmm11
0000796d027d9d4d  vmovaps [rsp+0xB0], xmm12
0000796d027d9d56  vmovaps [rsp+0xC0], xmm13
0000796d027d9d5f  vmovaps [rsp+0xD0], xmm14
0000796d027d9d68  vmovaps [rsp+0xE0], xmm15
0000796d027d9d71  sub rsp, 0x30
0000796d027d9d75  movaps [rsp], xmm10
0000796d027d9d7a  movaps [rsp+0x10], xmm14
0000796d027d9d80  movaps [rsp+0x20], xmm4
0000796d027d9d85  lea rdi, [rsp]
0000796d027d9d89  mov esi, 0x00
0000796d027d9d8e  mov rax, 0x635FBE957530
0000796d027d9d98  call rax
0000796d027d9d9a  movaps xmm10, [rsp]
0000796d027d9d9f  add rsp, 0x30
0000796d027d9da3  vmovaps xmm0, [rsp]
0000796d027d9da8  vmovaps xmm1, [rsp+0x10]
0000796d027d9dae  vmovaps xmm2, [rsp+0x20]
0000796d027d9db4  vmovaps xmm3, [rsp+0x30]
0000796d027d9dba  vmovaps xmm4, [rsp+0x40]
0000796d027d9dc0  vmovaps xmm5, [rsp+0x50]
0000796d027d9dc6  vmovaps xmm6, [rsp+0x60]
0000796d027d9dcc  vmovaps xmm7, [rsp+0x70]
0000796d027d9dd2  vmovaps xmm8, [rsp+0x80]
0000796d027d9ddb  vmovaps xmm9, [rsp+0x90]
0000796d027d9de4  vmovaps xmm11, [rsp+0xA0]
0000796d027d9ded  vmovaps xmm12, [rsp+0xB0]
0000796d027d9df6  vmovaps xmm13, [rsp+0xC0]
0000796d027d9dff  vmovaps xmm14, [rsp+0xD0]
0000796d027d9e08  vmovaps xmm15, [rsp+0xE0]
0000796d027d9e11  add rsp, 0xF0
0000796d027d9e18  pop r11
0000796d027d9e1a  pop r10
0000796d027d9e1c  pop r9
0000796d027d9e1e  pop r8
0000796d027d9e20  pop rsi
0000796d027d9e21  pop rdi
0000796d027d9e22  pop rdx
0000796d027d9e23  pop rcx
0000796d027d9e24  pop rax
0000796d027d9e25  add rsp, 0x08
0000796d027d9e29  jmp 0x0000796D027D6388
0000796d027d9e2e  sub rsp, 0x08
0000796d027d9e32  push rax
0000796d027d9e33  push rcx
0000796d027d9e34  push rdx
0000796d027d9e35  push rdi
0000796d027d9e36  push rsi
0000796d027d9e37  push r8
0000796d027d9e39  push r9
0000796d027d9e3b  push r10
0000796d027d9e3d  push r11
0000796d027d9e3f  sub rsp, 0xF0
0000796d027d9e46  vmovaps [rsp], xmm0
0000796d027d9e4b  vmovaps [rsp+0x10], xmm1
0000796d027d9e51  vmovaps [rsp+0x20], xmm2
0000796d027d9e57  vmovaps [rsp+0x30], xmm3
0000796d027d9e5d  vmovaps [rsp+0x40], xmm4
0000796d027d9e63  vmovaps [rsp+0x50], xmm5
0000796d027d9e69  vmovaps [rsp+0x60], xmm6
0000796d027d9e6f  vmovaps [rsp+0x70], xmm7
0000796d027d9e75  vmovaps [rsp+0x80], xmm9
0000796d027d9e7e  vmovaps [rsp+0x90], xmm10
0000796d027d9e87  vmovaps [rsp+0xA0], xmm11
0000796d027d9e90  vmovaps [rsp+0xB0], xmm12
0000796d027d9e99  vmovaps [rsp+0xC0], xmm13
0000796d027d9ea2  vmovaps [rsp+0xD0], xmm14
0000796d027d9eab  vmovaps [rsp+0xE0], xmm15
0000796d027d9eb4  sub rsp, 0x30
0000796d027d9eb8  movaps [rsp], xmm8
0000796d027d9ebd  movaps [rsp+0x10], xmm1
0000796d027d9ec2  movaps [rsp+0x20], xmm14
0000796d027d9ec8  lea rdi, [rsp]
0000796d027d9ecc  mov esi, 0x00
0000796d027d9ed1  mov rax, 0x635FBE957530
0000796d027d9edb  call rax
0000796d027d9edd  movaps xmm8, [rsp]
0000796d027d9ee2  add rsp, 0x30
0000796d027d9ee6  vmovaps xmm0, [rsp]
0000796d027d9eeb  vmovaps xmm1, [rsp+0x10]
0000796d027d9ef1  vmovaps xmm2, [rsp+0x20]
0000796d027d9ef7  vmovaps xmm3, [rsp+0x30]
0000796d027d9efd  vmovaps xmm4, [rsp+0x40]
0000796d027d9f03  vmovaps xmm5, [rsp+0x50]
0000796d027d9f09  vmovaps xmm6, [rsp+0x60]
0000796d027d9f0f  vmovaps xmm7, [rsp+0x70]
0000796d027d9f15  vmovaps xmm9, [rsp+0x80]
0000796d027d9f1e  vmovaps xmm10, [rsp+0x90]
0000796d027d9f27  vmovaps xmm11, [rsp+0xA0]
0000796d027d9f30  vmovaps xmm12, [rsp+0xB0]
0000796d027d9f39  vmovaps xmm13, [rsp+0xC0]
0000796d027d9f42  vmovaps xmm14, [rsp+0xD0]
0000796d027d9f4b  vmovaps xmm15, [rsp+0xE0]
0000796d027d9f54  add rsp, 0xF0
0000796d027d9f5b  pop r11
0000796d027d9f5d  pop r10
0000796d027d9f5f  pop r9
0000796d027d9f61  pop r8
0000796d027d9f63  pop rsi
0000796d027d9f64  pop rdi
0000796d027d9f65  pop rdx
0000796d027d9f66  pop rcx
0000796d027d9f67  pop rax
0000796d027d9f68  add rsp, 0x08
0000796d027d9f6c  jmp 0x0000796D027D63AE
0000796d027d9f71  sub rsp, 0x08
0000796d027d9f75  push rax
0000796d027d9f76  push rcx
0000796d027d9f77  push rdx
0000796d027d9f78  push rdi
0000796d027d9f79  push rsi
0000796d027d9f7a  push r8
0000796d027d9f7c  push r9
0000796d027d9f7e  push r10
0000796d027d9f80  push r11
0000796d027d9f82  sub rsp, 0xF0
0000796d027d9f89  vmovaps [rsp], xmm0
0000796d027d9f8e  vmovaps [rsp+0x10], xmm1
0000796d027d9f94  vmovaps [rsp+0x20], xmm2
0000796d027d9f9a  vmovaps [rsp+0x30], xmm3
0000796d027d9fa0  vmovaps [rsp+0x40], xmm4
0000796d027d9fa6  vmovaps [rsp+0x50], xmm5
0000796d027d9fac  vmovaps [rsp+0x60], xmm7
0000796d027d9fb2  vmovaps [rsp+0x70], xmm8
0000796d027d9fb8  vmovaps [rsp+0x80], xmm9
0000796d027d9fc1  vmovaps [rsp+0x90], xmm10
0000796d027d9fca  vmovaps [rsp+0xA0], xmm11
0000796d027d9fd3  vmovaps [rsp+0xB0], xmm12
0000796d027d9fdc  vmovaps [rsp+0xC0], xmm13
0000796d027d9fe5  vmovaps [rsp+0xD0], xmm14
0000796d027d9fee  vmovaps [rsp+0xE0], xmm15
0000796d027d9ff7  sub rsp, 0x30
0000796d027d9ffb  movaps [rsp], xmm6
0000796d027d9fff  movaps [rsp+0x10], xmm1
0000796d027da004  movaps [rsp+0x20], xmm14
0000796d027da00a  lea rdi, [rsp]
0000796d027da00e  mov esi, 0x00
0000796d027da013  mov rax, 0x635FBE957530
0000796d027da01d  call rax
0000796d027da01f  movaps xmm6, [rsp]
0000796d027da023  add rsp, 0x30
0000796d027da027  vmovaps xmm0, [rsp]
0000796d027da02c  vmovaps xmm1, [rsp+0x10]
0000796d027da032  vmovaps xmm2, [rsp+0x20]
0000796d027da038  vmovaps xmm3, [rsp+0x30]
0000796d027da03e  vmovaps xmm4, [rsp+0x40]
0000796d027da044  vmovaps xmm5, [rsp+0x50]
0000796d027da04a  vmovaps xmm7, [rsp+0x60]
0000796d027da050  vmovaps xmm8, [rsp+0x70]
0000796d027da056  vmovaps xmm9, [rsp+0x80]
0000796d027da05f  vmovaps xmm10, [rsp+0x90]
0000796d027da068  vmovaps xmm11, [rsp+0xA0]
0000796d027da071  vmovaps xmm12, [rsp+0xB0]
0000796d027da07a  vmovaps xmm13, [rsp+0xC0]
0000796d027da083  vmovaps xmm14, [rsp+0xD0]
0000796d027da08c  vmovaps xmm15, [rsp+0xE0]
0000796d027da095  add rsp, 0xF0
0000796d027da09c  pop r11
0000796d027da09e  pop r10
0000796d027da0a0  pop r9
0000796d027da0a2  pop r8
0000796d027da0a4  pop rsi
0000796d027da0a5  pop rdi
0000796d027da0a6  pop rdx
0000796d027da0a7  pop rcx
0000796d027da0a8  pop rax
0000796d027da0a9  add rsp, 0x08
0000796d027da0ad  jmp 0x0000796D027D63DA
0000796d027da0b2  sub rsp, 0x08
0000796d027da0b6  push rax
0000796d027da0b7  push rcx
0000796d027da0b8  push rdx
0000796d027da0b9  push rdi
0000796d027da0ba  push rsi
0000796d027da0bb  push r8
0000796d027da0bd  push r9
0000796d027da0bf  push r10
0000796d027da0c1  push r11
0000796d027da0c3  sub rsp, 0xF0
0000796d027da0ca  vmovaps [rsp], xmm0
0000796d027da0cf  vmovaps [rsp+0x10], xmm1
0000796d027da0d5  vmovaps [rsp+0x20], xmm2
0000796d027da0db  vmovaps [rsp+0x30], xmm3
0000796d027da0e1  vmovaps [rsp+0x40], xmm4
0000796d027da0e7  vmovaps [rsp+0x50], xmm5
0000796d027da0ed  vmovaps [rsp+0x60], xmm6
0000796d027da0f3  vmovaps [rsp+0x70], xmm7
0000796d027da0f9  vmovaps [rsp+0x80], xmm8
0000796d027da102  vmovaps [rsp+0x90], xmm9
0000796d027da10b  vmovaps [rsp+0xA0], xmm10
0000796d027da114  vmovaps [rsp+0xB0], xmm11
0000796d027da11d  vmovaps [rsp+0xC0], xmm12
0000796d027da126  vmovaps [rsp+0xD0], xmm13
0000796d027da12f  vmovaps [rsp+0xE0], xmm15
0000796d027da138  sub rsp, 0x30
0000796d027da13c  movaps [rsp], xmm14
0000796d027da141  movaps [rsp+0x10], xmm12
0000796d027da147  movaps [rsp+0x20], xmm1
0000796d027da14c  lea rdi, [rsp]
0000796d027da150  mov esi, 0x00
0000796d027da155  mov rax, 0x635FBE957530
0000796d027da15f  call rax
0000796d027da161  movaps xmm14, [rsp]
0000796d027da166  add rsp, 0x30
0000796d027da16a  vmovaps xmm0, [rsp]
0000796d027da16f  vmovaps xmm1, [rsp+0x10]
0000796d027da175  vmovaps xmm2, [rsp+0x20]
0000796d027da17b  vmovaps xmm3, [rsp+0x30]
0000796d027da181  vmovaps xmm4, [rsp+0x40]
0000796d027da187  vmovaps xmm5, [rsp+0x50]
0000796d027da18d  vmovaps xmm6, [rsp+0x60]
0000796d027da193  vmovaps xmm7, [rsp+0x70]
0000796d027da199  vmovaps xmm8, [rsp+0x80]
0000796d027da1a2  vmovaps xmm9, [rsp+0x90]
0000796d027da1ab  vmovaps xmm10, [rsp+0xA0]
0000796d027da1b4  vmovaps xmm11, [rsp+0xB0]
0000796d027da1bd  vmovaps xmm12, [rsp+0xC0]
0000796d027da1c6  vmovaps xmm13, [rsp+0xD0]
0000796d027da1cf  vmovaps xmm15, [rsp+0xE0]
0000796d027da1d8  add rsp, 0xF0
0000796d027da1df  pop r11
0000796d027da1e1  pop r10
0000796d027da1e3  pop r9
0000796d027da1e5  pop r8
0000796d027da1e7  pop rsi
0000796d027da1e8  pop rdi
0000796d027da1e9  pop rdx
0000796d027da1ea  pop rcx
0000796d027da1eb  pop rax
0000796d027da1ec  add rsp, 0x08
0000796d027da1f0  jmp 0x0000796D027D6400
0000796d027da1f5  sub rsp, 0x08
0000796d027da1f9  push rax
0000796d027da1fa  push rcx
0000796d027da1fb  push rdx
0000796d027da1fc  push rdi
0000796d027da1fd  push rsi
0000796d027da1fe  push r8
0000796d027da200  push r9
0000796d027da202  push r10
0000796d027da204  push r11
0000796d027da206  sub rsp, 0xF0
0000796d027da20d  vmovaps [rsp], xmm0
0000796d027da212  vmovaps [rsp+0x10], xmm2
0000796d027da218  vmovaps [rsp+0x20], xmm3
0000796d027da21e  vmovaps [rsp+0x30], xmm4
0000796d027da224  vmovaps [rsp+0x40], xmm5
0000796d027da22a  vmovaps [rsp+0x50], xmm6
0000796d027da230  vmovaps [rsp+0x60], xmm7
0000796d027da236  vmovaps [rsp+0x70], xmm8
0000796d027da23c  vmovaps [rsp+0x80], xmm9
0000796d027da245  vmovaps [rsp+0x90], xmm10
0000796d027da24e  vmovaps [rsp+0xA0], xmm11
0000796d027da257  vmovaps [rsp+0xB0], xmm12
0000796d027da260  vmovaps [rsp+0xC0], xmm13
0000796d027da269  vmovaps [rsp+0xD0], xmm14
0000796d027da272  vmovaps [rsp+0xE0], xmm15
0000796d027da27b  sub rsp, 0x30
0000796d027da27f  movaps [rsp], xmm1
0000796d027da283  movaps [rsp+0x10], xmm13
0000796d027da289  movaps [rsp+0x20], xmm9
0000796d027da28f  lea rdi, [rsp]
0000796d027da293  mov esi, 0x00
0000796d027da298  mov rax, 0x635FBE957530
0000796d027da2a2  call rax
0000796d027da2a4  movaps xmm1, [rsp]
0000796d027da2a8  add rsp, 0x30
0000796d027da2ac  vmovaps xmm0, [rsp]
0000796d027da2b1  vmovaps xmm2, [rsp+0x10]
0000796d027da2b7  vmovaps xmm3, [rsp+0x20]
0000796d027da2bd  vmovaps xmm4, [rsp+0x30]
0000796d027da2c3  vmovaps xmm5, [rsp+0x40]
0000796d027da2c9  vmovaps xmm6, [rsp+0x50]
0000796d027da2cf  vmovaps xmm7, [rsp+0x60]
0000796d027da2d5  vmovaps xmm8, [rsp+0x70]
0000796d027da2db  vmovaps xmm9, [rsp+0x80]
0000796d027da2e4  vmovaps xmm10, [rsp+0x90]
0000796d027da2ed  vmovaps xmm11, [rsp+0xA0]
0000796d027da2f6  vmovaps xmm12, [rsp+0xB0]
0000796d027da2ff  vmovaps xmm13, [rsp+0xC0]
0000796d027da308  vmovaps xmm14, [rsp+0xD0]
0000796d027da311  vmovaps xmm15, [rsp+0xE0]
0000796d027da31a  add rsp, 0xF0
0000796d027da321  pop r11
0000796d027da323  pop r10
0000796d027da325  pop r9
0000796d027da327  pop r8
0000796d027da329  pop rsi
0000796d027da32a  pop rdi
0000796d027da32b  pop rdx
0000796d027da32c  pop rcx
0000796d027da32d  pop rax
0000796d027da32e  add rsp, 0x08
0000796d027da332  jmp 0x0000796D027D641A
0000796d027da337  sub rsp, 0x08
0000796d027da33b  push rax
0000796d027da33c  push rcx
0000796d027da33d  push rdx
0000796d027da33e  push rdi
0000796d027da33f  push rsi
0000796d027da340  push r8
0000796d027da342  push r9
0000796d027da344  push r10
0000796d027da346  push r11
0000796d027da348  sub rsp, 0xF0
0000796d027da34f  vmovaps [rsp], xmm0
0000796d027da354  vmovaps [rsp+0x10], xmm1
0000796d027da35a  vmovaps [rsp+0x20], xmm2
0000796d027da360  vmovaps [rsp+0x30], xmm3
0000796d027da366  vmovaps [rsp+0x40], xmm4
0000796d027da36c  vmovaps [rsp+0x50], xmm5
0000796d027da372  vmovaps [rsp+0x60], xmm6
0000796d027da378  vmovaps [rsp+0x70], xmm7
0000796d027da37e  vmovaps [rsp+0x80], xmm8
0000796d027da387  vmovaps [rsp+0x90], xmm9
0000796d027da390  vmovaps [rsp+0xA0], xmm10
0000796d027da399  vmovaps [rsp+0xB0], xmm11
0000796d027da3a2  vmovaps [rsp+0xC0], xmm13
0000796d027da3ab  vmovaps [rsp+0xD0], xmm14
0000796d027da3b4  vmovaps [rsp+0xE0], xmm15
0000796d027da3bd  sub rsp, 0x30
0000796d027da3c1  movaps [rsp], xmm12
0000796d027da3c6  movaps [rsp+0x10], xmm7
0000796d027da3cb  movaps [rsp+0x20], xmm13
0000796d027da3d1  lea rdi, [rsp]
0000796d027da3d5  mov esi, 0x00
0000796d027da3da  mov rax, 0x635FBE957530
0000796d027da3e4  call rax
0000796d027da3e6  movaps xmm12, [rsp]
0000796d027da3eb  add rsp, 0x30
0000796d027da3ef  vmovaps xmm0, [rsp]
0000796d027da3f4  vmovaps xmm1, [rsp+0x10]
0000796d027da3fa  vmovaps xmm2, [rsp+0x20]
0000796d027da400  vmovaps xmm3, [rsp+0x30]
0000796d027da406  vmovaps xmm4, [rsp+0x40]
0000796d027da40c  vmovaps xmm5, [rsp+0x50]
0000796d027da412  vmovaps xmm6, [rsp+0x60]
0000796d027da418  vmovaps xmm7, [rsp+0x70]
0000796d027da41e  vmovaps xmm8, [rsp+0x80]
0000796d027da427  vmovaps xmm9, [rsp+0x90]
0000796d027da430  vmovaps xmm10, [rsp+0xA0]
0000796d027da439  vmovaps xmm11, [rsp+0xB0]
0000796d027da442  vmovaps xmm13, [rsp+0xC0]
0000796d027da44b  vmovaps xmm14, [rsp+0xD0]
0000796d027da454  vmovaps xmm15, [rsp+0xE0]
0000796d027da45d  add rsp, 0xF0
0000796d027da464  pop r11
0000796d027da466  pop r10
0000796d027da468  pop r9
0000796d027da46a  pop r8
0000796d027da46c  pop rsi
0000796d027da46d  pop rdi
0000796d027da46e  pop rdx
0000796d027da46f  pop rcx
0000796d027da470  pop rax
0000796d027da471  add rsp, 0x08
0000796d027da475  jmp 0x0000796D027D6441
0000796d027da47a  sub rsp, 0x08
0000796d027da47e  push rax
0000796d027da47f  push rcx
0000796d027da480  push rdx
0000796d027da481  push rdi
0000796d027da482  push rsi
0000796d027da483  push r8
0000796d027da485  push r9
0000796d027da487  push r10
0000796d027da489  push r11
0000796d027da48b  sub rsp, 0xF0
0000796d027da492  vmovaps [rsp], xmm0
0000796d027da497  vmovaps [rsp+0x10], xmm1
0000796d027da49d  vmovaps [rsp+0x20], xmm2
0000796d027da4a3  vmovaps [rsp+0x30], xmm3
0000796d027da4a9  vmovaps [rsp+0x40], xmm4
0000796d027da4af  vmovaps [rsp+0x50], xmm5
0000796d027da4b5  vmovaps [rsp+0x60], xmm6
0000796d027da4bb  vmovaps [rsp+0x70], xmm7
0000796d027da4c1  vmovaps [rsp+0x80], xmm8
0000796d027da4ca  vmovaps [rsp+0x90], xmm9
0000796d027da4d3  vmovaps [rsp+0xA0], xmm10
0000796d027da4dc  vmovaps [rsp+0xB0], xmm11
0000796d027da4e5  vmovaps [rsp+0xC0], xmm12
0000796d027da4ee  vmovaps [rsp+0xD0], xmm14
0000796d027da4f7  vmovaps [rsp+0xE0], xmm15
0000796d027da500  sub rsp, 0x30
0000796d027da504  movaps [rsp], xmm13
0000796d027da509  movaps [rsp+0x10], xmm15
0000796d027da50f  movaps [rsp+0x20], xmm8
0000796d027da515  lea rdi, [rsp]
0000796d027da519  mov esi, 0x00
0000796d027da51e  mov rax, 0x635FBE957530
0000796d027da528  call rax
0000796d027da52a  movaps xmm13, [rsp]
0000796d027da52f  add rsp, 0x30
0000796d027da533  vmovaps xmm0, [rsp]
0000796d027da538  vmovaps xmm1, [rsp+0x10]
0000796d027da53e  vmovaps xmm2, [rsp+0x20]
0000796d027da544  vmovaps xmm3, [rsp+0x30]
0000796d027da54a  vmovaps xmm4, [rsp+0x40]
0000796d027da550  vmovaps xmm5, [rsp+0x50]
0000796d027da556  vmovaps xmm6, [rsp+0x60]
0000796d027da55c  vmovaps xmm7, [rsp+0x70]
0000796d027da562  vmovaps xmm8, [rsp+0x80]
0000796d027da56b  vmovaps xmm9, [rsp+0x90]
0000796d027da574  vmovaps xmm10, [rsp+0xA0]
0000796d027da57d  vmovaps xmm11, [rsp+0xB0]
0000796d027da586  vmovaps xmm12, [rsp+0xC0]
0000796d027da58f  vmovaps xmm14, [rsp+0xD0]
0000796d027da598  vmovaps xmm15, [rsp+0xE0]
0000796d027da5a1  add rsp, 0xF0
0000796d027da5a8  pop r11
0000796d027da5aa  pop r10
0000796d027da5ac  pop r9
0000796d027da5ae  pop r8
0000796d027da5b0  pop rsi
0000796d027da5b1  pop rdi
0000796d027da5b2  pop rdx
0000796d027da5b3  pop rcx
0000796d027da5b4  pop rax
0000796d027da5b5  add rsp, 0x08
0000796d027da5b9  jmp 0x0000796D027D645C
0000796d027da5be  sub rsp, 0x08
0000796d027da5c2  push rax
0000796d027da5c3  push rcx
0000796d027da5c4  push rdx
0000796d027da5c5  push rdi
0000796d027da5c6  push rsi
0000796d027da5c7  push r8
0000796d027da5c9  push r9
0000796d027da5cb  push r10
0000796d027da5cd  push r11
0000796d027da5cf  sub rsp, 0xF0
0000796d027da5d6  vmovaps [rsp], xmm0
0000796d027da5db  vmovaps [rsp+0x10], xmm1
0000796d027da5e1  vmovaps [rsp+0x20], xmm2
0000796d027da5e7  vmovaps [rsp+0x30], xmm3
0000796d027da5ed  vmovaps [rsp+0x40], xmm4
0000796d027da5f3  vmovaps [rsp+0x50], xmm5
0000796d027da5f9  vmovaps [rsp+0x60], xmm6
0000796d027da5ff  vmovaps [rsp+0x70], xmm7
0000796d027da605  vmovaps [rsp+0x80], xmm9
0000796d027da60e  vmovaps [rsp+0x90], xmm10
0000796d027da617  vmovaps [rsp+0xA0], xmm11
0000796d027da620  vmovaps [rsp+0xB0], xmm12
0000796d027da629  vmovaps [rsp+0xC0], xmm13
0000796d027da632  vmovaps [rsp+0xD0], xmm14
0000796d027da63b  vmovaps [rsp+0xE0], xmm15
0000796d027da644  sub rsp, 0x30
0000796d027da648  movaps [rsp], xmm8
0000796d027da64d  movaps [rsp+0x10], xmm15
0000796d027da653  movaps [rsp+0x20], xmm9
0000796d027da659  lea rdi, [rsp]
0000796d027da65d  mov esi, 0x00
0000796d027da662  mov rax, 0x635FBE957530
0000796d027da66c  call rax
0000796d027da66e  movaps xmm8, [rsp]
0000796d027da673  add rsp, 0x30
0000796d027da677  vmovaps xmm0, [rsp]
0000796d027da67c  vmovaps xmm1, [rsp+0x10]
0000796d027da682  vmovaps xmm2, [rsp+0x20]
0000796d027da688  vmovaps xmm3, [rsp+0x30]
0000796d027da68e  vmovaps xmm4, [rsp+0x40]
0000796d027da694  vmovaps xmm5, [rsp+0x50]
0000796d027da69a  vmovaps xmm6, [rsp+0x60]
0000796d027da6a0  vmovaps xmm7, [rsp+0x70]
0000796d027da6a6  vmovaps xmm9, [rsp+0x80]
0000796d027da6af  vmovaps xmm10, [rsp+0x90]
0000796d027da6b8  vmovaps xmm11, [rsp+0xA0]
0000796d027da6c1  vmovaps xmm12, [rsp+0xB0]
0000796d027da6ca  vmovaps xmm13, [rsp+0xC0]
0000796d027da6d3  vmovaps xmm14, [rsp+0xD0]
0000796d027da6dc  vmovaps xmm15, [rsp+0xE0]
0000796d027da6e5  add rsp, 0xF0
0000796d027da6ec  pop r11
0000796d027da6ee  pop r10
0000796d027da6f0  pop r9
0000796d027da6f2  pop r8
0000796d027da6f4  pop rsi
0000796d027da6f5  pop rdi
0000796d027da6f6  pop rdx
0000796d027da6f7  pop rcx
0000796d027da6f8  pop rax
0000796d027da6f9  add rsp, 0x08
0000796d027da6fd  jmp 0x0000796D027D648A
0000796d027da702  sub rsp, 0x08
0000796d027da706  push rax
0000796d027da707  push rcx
0000796d027da708  push rdx
0000796d027da709  push rdi
0000796d027da70a  push rsi
0000796d027da70b  push r8
0000796d027da70d  push r9
0000796d027da70f  push r10
0000796d027da711  push r11
0000796d027da713  sub rsp, 0xF0
0000796d027da71a  vmovaps [rsp], xmm0
0000796d027da71f  vmovaps [rsp+0x10], xmm1
0000796d027da725  vmovaps [rsp+0x20], xmm2
0000796d027da72b  vmovaps [rsp+0x30], xmm3
0000796d027da731  vmovaps [rsp+0x40], xmm4
0000796d027da737  vmovaps [rsp+0x50], xmm5
0000796d027da73d  vmovaps [rsp+0x60], xmm6
0000796d027da743  vmovaps [rsp+0x70], xmm7
0000796d027da749  vmovaps [rsp+0x80], xmm8
0000796d027da752  vmovaps [rsp+0x90], xmm9
0000796d027da75b  vmovaps [rsp+0xA0], xmm10
0000796d027da764  vmovaps [rsp+0xB0], xmm11
0000796d027da76d  vmovaps [rsp+0xC0], xmm12
0000796d027da776  vmovaps [rsp+0xD0], xmm13
0000796d027da77f  vmovaps [rsp+0xE0], xmm14
0000796d027da788  sub rsp, 0x30
0000796d027da78c  movaps [rsp], xmm15
0000796d027da791  movaps [rsp+0x10], xmm11
0000796d027da797  movaps [rsp+0x20], xmm6
0000796d027da79c  lea rdi, [rsp]
0000796d027da7a0  mov esi, 0x00
0000796d027da7a5  mov rax, 0x635FBE957530
0000796d027da7af  call rax
0000796d027da7b1  movaps xmm15, [rsp]
0000796d027da7b6  add rsp, 0x30
0000796d027da7ba  vmovaps xmm0, [rsp]
0000796d027da7bf  vmovaps xmm1, [rsp+0x10]
0000796d027da7c5  vmovaps xmm2, [rsp+0x20]
0000796d027da7cb  vmovaps xmm3, [rsp+0x30]
0000796d027da7d1  vmovaps xmm4, [rsp+0x40]
0000796d027da7d7  vmovaps xmm5, [rsp+0x50]
0000796d027da7dd  vmovaps xmm6, [rsp+0x60]
0000796d027da7e3  vmovaps xmm7, [rsp+0x70]
0000796d027da7e9  vmovaps xmm8, [rsp+0x80]
0000796d027da7f2  vmovaps xmm9, [rsp+0x90]
0000796d027da7fb  vmovaps xmm10, [rsp+0xA0]
0000796d027da804  vmovaps xmm11, [rsp+0xB0]
0000796d027da80d  vmovaps xmm12, [rsp+0xC0]
0000796d027da816  vmovaps xmm13, [rsp+0xD0]
0000796d027da81f  vmovaps xmm14, [rsp+0xE0]
0000796d027da828  add rsp, 0xF0
0000796d027da82f  pop r11
0000796d027da831  pop r10
0000796d027da833  pop r9
0000796d027da835  pop r8
0000796d027da837  pop rsi
0000796d027da838  pop rdi
0000796d027da839  pop rdx
0000796d027da83a  pop rcx
0000796d027da83b  pop rax
0000796d027da83c  add rsp, 0x08
0000796d027da840  jmp 0x0000796D027D64A5
0000796d027da845  sub rsp, 0x08
0000796d027da849  push rax
0000796d027da84a  push rcx
0000796d027da84b  push rdx
0000796d027da84c  push rdi
0000796d027da84d  push rsi
0000796d027da84e  push r8
0000796d027da850  push r9
0000796d027da852  push r10
0000796d027da854  push r11
0000796d027da856  sub rsp, 0xF0
0000796d027da85d  vmovaps [rsp], xmm0
0000796d027da862  vmovaps [rsp+0x10], xmm1
0000796d027da868  vmovaps [rsp+0x20], xmm2
0000796d027da86e  vmovaps [rsp+0x30], xmm3
0000796d027da874  vmovaps [rsp+0x40], xmm4
0000796d027da87a  vmovaps [rsp+0x50], xmm5
0000796d027da880  vmovaps [rsp+0x60], xmm6
0000796d027da886  vmovaps [rsp+0x70], xmm8
0000796d027da88c  vmovaps [rsp+0x80], xmm9
0000796d027da895  vmovaps [rsp+0x90], xmm10
0000796d027da89e  vmovaps [rsp+0xA0], xmm11
0000796d027da8a7  vmovaps [rsp+0xB0], xmm12
0000796d027da8b0  vmovaps [rsp+0xC0], xmm13
0000796d027da8b9  vmovaps [rsp+0xD0], xmm14
0000796d027da8c2  vmovaps [rsp+0xE0], xmm15
0000796d027da8cb  sub rsp, 0x30
0000796d027da8cf  movaps [rsp], xmm7
0000796d027da8d3  movaps [rsp+0x10], xmm11
0000796d027da8d9  movaps [rsp+0x20], xmm9
0000796d027da8df  lea rdi, [rsp]
0000796d027da8e3  mov esi, 0x00
0000796d027da8e8  mov rax, 0x635FBE957530
0000796d027da8f2  call rax
0000796d027da8f4  movaps xmm7, [rsp]
0000796d027da8f8  add rsp, 0x30
0000796d027da8fc  vmovaps xmm0, [rsp]
0000796d027da901  vmovaps xmm1, [rsp+0x10]
0000796d027da907  vmovaps xmm2, [rsp+0x20]
0000796d027da90d  vmovaps xmm3, [rsp+0x30]
0000796d027da913  vmovaps xmm4, [rsp+0x40]
0000796d027da919  vmovaps xmm5, [rsp+0x50]
0000796d027da91f  vmovaps xmm6, [rsp+0x60]
0000796d027da925  vmovaps xmm8, [rsp+0x70]
0000796d027da92b  vmovaps xmm9, [rsp+0x80]
0000796d027da934  vmovaps xmm10, [rsp+0x90]
0000796d027da93d  vmovaps xmm11, [rsp+0xA0]
0000796d027da946  vmovaps xmm12, [rsp+0xB0]
0000796d027da94f  vmovaps xmm13, [rsp+0xC0]
0000796d027da958  vmovaps xmm14, [rsp+0xD0]
0000796d027da961  vmovaps xmm15, [rsp+0xE0]
0000796d027da96a  add rsp, 0xF0
0000796d027da971  pop r11
0000796d027da973  pop r10
0000796d027da975  pop r9
0000796d027da977  pop r8
0000796d027da979  pop rsi
0000796d027da97a  pop rdi
0000796d027da97b  pop rdx
0000796d027da97c  pop rcx
0000796d027da97d  pop rax
0000796d027da97e  add rsp, 0x08
0000796d027da982  jmp 0x0000796D027D64D2
0000796d027da987  sub rsp, 0x08
0000796d027da98b  push rax
0000796d027da98c  push rcx
0000796d027da98d  push rdx
0000796d027da98e  push rdi
0000796d027da98f  push rsi
0000796d027da990  push r8
0000796d027da992  push r9
0000796d027da994  push r10
0000796d027da996  push r11
0000796d027da998  sub rsp, 0xF0
0000796d027da99f  vmovaps [rsp], xmm0
0000796d027da9a4  vmovaps [rsp+0x10], xmm1
0000796d027da9aa  vmovaps [rsp+0x20], xmm2
0000796d027da9b0  vmovaps [rsp+0x30], xmm3
0000796d027da9b6  vmovaps [rsp+0x40], xmm4
0000796d027da9bc  vmovaps [rsp+0x50], xmm5
0000796d027da9c2  vmovaps [rsp+0x60], xmm6
0000796d027da9c8  vmovaps [rsp+0x70], xmm7
0000796d027da9ce  vmovaps [rsp+0x80], xmm8
0000796d027da9d7  vmovaps [rsp+0x90], xmm9
0000796d027da9e0  vmovaps [rsp+0xA0], xmm10
0000796d027da9e9  vmovaps [rsp+0xB0], xmm12
0000796d027da9f2  vmovaps [rsp+0xC0], xmm13
0000796d027da9fb  vmovaps [rsp+0xD0], xmm14
0000796d027daa04  vmovaps [rsp+0xE0], xmm15
0000796d027daa0d  sub rsp, 0x30
0000796d027daa11  movaps [rsp], xmm11
0000796d027daa16  movaps [rsp+0x10], xmm10
0000796d027daa1c  movaps [rsp+0x20], xmm14
0000796d027daa22  lea rdi, [rsp]
0000796d027daa26  mov esi, 0x00
0000796d027daa2b  mov rax, 0x635FBE957530
0000796d027daa35  call rax
0000796d027daa37  movaps xmm11, [rsp]
0000796d027daa3c  add rsp, 0x30
0000796d027daa40  vmovaps xmm0, [rsp]
0000796d027daa45  vmovaps xmm1, [rsp+0x10]
0000796d027daa4b  vmovaps xmm2, [rsp+0x20]
0000796d027daa51  vmovaps xmm3, [rsp+0x30]
0000796d027daa57  vmovaps xmm4, [rsp+0x40]
0000796d027daa5d  vmovaps xmm5, [rsp+0x50]
0000796d027daa63  vmovaps xmm6, [rsp+0x60]
0000796d027daa69  vmovaps xmm7, [rsp+0x70]
0000796d027daa6f  vmovaps xmm8, [rsp+0x80]
0000796d027daa78  vmovaps xmm9, [rsp+0x90]
0000796d027daa81  vmovaps xmm10, [rsp+0xA0]
0000796d027daa8a  vmovaps xmm12, [rsp+0xB0]
0000796d027daa93  vmovaps xmm13, [rsp+0xC0]
0000796d027daa9c  vmovaps xmm14, [rsp+0xD0]
0000796d027daaa5  vmovaps xmm15, [rsp+0xE0]
0000796d027daaae  add rsp, 0xF0
0000796d027daab5  pop r11
0000796d027daab7  pop r10
0000796d027daab9  pop r9
0000796d027daabb  pop r8
0000796d027daabd  pop rsi
0000796d027daabe  pop rdi
0000796d027daabf  pop rdx
0000796d027daac0  pop rcx
0000796d027daac1  pop rax
0000796d027daac2  add rsp, 0x08
0000796d027daac6  jmp 0x0000796D027D64ED
0000796d027daacb  call 0x0000796D026E45A0
0000796d027daad0  jmp 0x0000796D027D64F7
0000796d027daad5  sub rsp, 0x08
0000796d027daad9  push rax
0000796d027daada  push rcx
0000796d027daadb  push rdx
0000796d027daadc  push rdi
0000796d027daadd  push rsi
0000796d027daade  push r8
0000796d027daae0  push r9
0000796d027daae2  push r10
0000796d027daae4  push r11
0000796d027daae6  sub rsp, 0xF0
0000796d027daaed  vmovaps [rsp], xmm0
0000796d027daaf2  vmovaps [rsp+0x10], xmm1
0000796d027daaf8  vmovaps [rsp+0x20], xmm2
0000796d027daafe  vmovaps [rsp+0x30], xmm3
0000796d027dab04  vmovaps [rsp+0x40], xmm4
0000796d027dab0a  vmovaps [rsp+0x50], xmm5
0000796d027dab10  vmovaps [rsp+0x60], xmm6
0000796d027dab16  vmovaps [rsp+0x70], xmm7
0000796d027dab1c  vmovaps [rsp+0x80], xmm8
0000796d027dab25  vmovaps [rsp+0x90], xmm9
0000796d027dab2e  vmovaps [rsp+0xA0], xmm11
0000796d027dab37  vmovaps [rsp+0xB0], xmm12
0000796d027dab40  vmovaps [rsp+0xC0], xmm13
0000796d027dab49  vmovaps [rsp+0xD0], xmm14
0000796d027dab52  vmovaps [rsp+0xE0], xmm15
0000796d027dab5b  sub rsp, 0x30
0000796d027dab5f  movaps [rsp], xmm10
0000796d027dab64  movaps [rsp+0x10], xmm1
0000796d027dab69  movaps [rsp+0x20], xmm12
0000796d027dab6f  lea rdi, [rsp]
0000796d027dab73  mov esi, 0x00
0000796d027dab78  mov rax, 0x635FBE957530
0000796d027dab82  call rax
0000796d027dab84  movaps xmm10, [rsp]
0000796d027dab89  add rsp, 0x30
0000796d027dab8d  vmovaps xmm0, [rsp]
0000796d027dab92  vmovaps xmm1, [rsp+0x10]
0000796d027dab98  vmovaps xmm2, [rsp+0x20]
0000796d027dab9e  vmovaps xmm3, [rsp+0x30]
0000796d027daba4  vmovaps xmm4, [rsp+0x40]
0000796d027dabaa  vmovaps xmm5, [rsp+0x50]
0000796d027dabb0  vmovaps xmm6, [rsp+0x60]
0000796d027dabb6  vmovaps xmm7, [rsp+0x70]
0000796d027dabbc  vmovaps xmm8, [rsp+0x80]
0000796d027dabc5  vmovaps xmm9, [rsp+0x90]
0000796d027dabce  vmovaps xmm11, [rsp+0xA0]
0000796d027dabd7  vmovaps xmm12, [rsp+0xB0]
0000796d027dabe0  vmovaps xmm13, [rsp+0xC0]
0000796d027dabe9  vmovaps xmm14, [rsp+0xD0]
0000796d027dabf2  vmovaps xmm15, [rsp+0xE0]
0000796d027dabfb  add rsp, 0xF0
0000796d027dac02  pop r11
0000796d027dac04  pop r10
0000796d027dac06  pop r9
0000796d027dac08  pop r8
0000796d027dac0a  pop rsi
0000796d027dac0b  pop rdi
0000796d027dac0c  pop rdx
0000796d027dac0d  pop rcx
0000796d027dac0e  pop rax
0000796d027dac0f  add rsp, 0x08
0000796d027dac13  jmp 0x0000796D027D651A
0000796d027dac18  sub rsp, 0x08
0000796d027dac1c  push rax
0000796d027dac1d  push rcx
0000796d027dac1e  push rdx
0000796d027dac1f  push rdi
0000796d027dac20  push rsi
0000796d027dac21  push r8
0000796d027dac23  push r9
0000796d027dac25  push r10
0000796d027dac27  push r11
0000796d027dac29  sub rsp, 0xF0
0000796d027dac30  vmovaps [rsp], xmm0
0000796d027dac35  vmovaps [rsp+0x10], xmm1
0000796d027dac3b  vmovaps [rsp+0x20], xmm2
0000796d027dac41  vmovaps [rsp+0x30], xmm3
0000796d027dac47  vmovaps [rsp+0x40], xmm4
0000796d027dac4d  vmovaps [rsp+0x50], xmm5
0000796d027dac53  vmovaps [rsp+0x60], xmm6
0000796d027dac59  vmovaps [rsp+0x70], xmm7
0000796d027dac5f  vmovaps [rsp+0x80], xmm8
0000796d027dac68  vmovaps [rsp+0x90], xmm9
0000796d027dac71  vmovaps [rsp+0xA0], xmm10
0000796d027dac7a  vmovaps [rsp+0xB0], xmm11
0000796d027dac83  vmovaps [rsp+0xC0], xmm13
0000796d027dac8c  vmovaps [rsp+0xD0], xmm14
0000796d027dac95  vmovaps [rsp+0xE0], xmm15
0000796d027dac9e  sub rsp, 0x30
0000796d027daca2  movaps [rsp], xmm12
0000796d027daca7  movaps [rsp+0x10], xmm14
0000796d027dacad  movaps [rsp+0x20], xmm1
0000796d027dacb2  lea rdi, [rsp]
0000796d027dacb6  mov esi, 0x00
0000796d027dacbb  mov rax, 0x635FBE957530
0000796d027dacc5  call rax
0000796d027dacc7  movaps xmm12, [rsp]
0000796d027daccc  add rsp, 0x30
0000796d027dacd0  vmovaps xmm0, [rsp]
0000796d027dacd5  vmovaps xmm1, [rsp+0x10]
0000796d027dacdb  vmovaps xmm2, [rsp+0x20]
0000796d027dace1  vmovaps xmm3, [rsp+0x30]
0000796d027dace7  vmovaps xmm4, [rsp+0x40]
0000796d027daced  vmovaps xmm5, [rsp+0x50]
0000796d027dacf3  vmovaps xmm6, [rsp+0x60]
0000796d027dacf9  vmovaps xmm7, [rsp+0x70]
0000796d027dacff  vmovaps xmm8, [rsp+0x80]
0000796d027dad08  vmovaps xmm9, [rsp+0x90]
0000796d027dad11  vmovaps xmm10, [rsp+0xA0]
0000796d027dad1a  vmovaps xmm11, [rsp+0xB0]
0000796d027dad23  vmovaps xmm13, [rsp+0xC0]
0000796d027dad2c  vmovaps xmm14, [rsp+0xD0]
0000796d027dad35  vmovaps xmm15, [rsp+0xE0]
0000796d027dad3e  add rsp, 0xF0
0000796d027dad45  pop r11
0000796d027dad47  pop r10
0000796d027dad49  pop r9
0000796d027dad4b  pop r8
0000796d027dad4d  pop rsi
0000796d027dad4e  pop rdi
0000796d027dad4f  pop rdx
0000796d027dad50  pop rcx
0000796d027dad51  pop rax
0000796d027dad52  add rsp, 0x08
0000796d027dad56  jmp 0x0000796D027D6549
0000796d027dad5b  sub rsp, 0x08
0000796d027dad5f  push rax
0000796d027dad60  push rcx
0000796d027dad61  push rdx
0000796d027dad62  push rdi
0000796d027dad63  push rsi
0000796d027dad64  push r8
0000796d027dad66  push r9
0000796d027dad68  push r10
0000796d027dad6a  push r11
0000796d027dad6c  sub rsp, 0xF0
0000796d027dad73  vmovaps [rsp], xmm0
0000796d027dad78  vmovaps [rsp+0x10], xmm1
0000796d027dad7e  vmovaps [rsp+0x20], xmm2
0000796d027dad84  vmovaps [rsp+0x30], xmm3
0000796d027dad8a  vmovaps [rsp+0x40], xmm4
0000796d027dad90  vmovaps [rsp+0x50], xmm5
0000796d027dad96  vmovaps [rsp+0x60], xmm6
0000796d027dad9c  vmovaps [rsp+0x70], xmm7
0000796d027dada2  vmovaps [rsp+0x80], xmm8
0000796d027dadab  vmovaps [rsp+0x90], xmm9
0000796d027dadb4  vmovaps [rsp+0xA0], xmm10
0000796d027dadbd  vmovaps [rsp+0xB0], xmm11
0000796d027dadc6  vmovaps [rsp+0xC0], xmm12
0000796d027dadcf  vmovaps [rsp+0xD0], xmm13
0000796d027dadd8  vmovaps [rsp+0xE0], xmm15
0000796d027dade1  sub rsp, 0x30
0000796d027dade5  movaps [rsp], xmm14
0000796d027dadea  movaps [rsp+0x10], xmm9
0000796d027dadf0  movaps [rsp+0x20], xmm1
0000796d027dadf5  lea rdi, [rsp]
0000796d027dadf9  mov esi, 0x00
0000796d027dadfe  mov rax, 0x635FBE957530
0000796d027dae08  call rax
0000796d027dae0a  movaps xmm14, [rsp]
0000796d027dae0f  add rsp, 0x30
0000796d027dae13  vmovaps xmm0, [rsp]
0000796d027dae18  vmovaps xmm1, [rsp+0x10]
0000796d027dae1e  vmovaps xmm2, [rsp+0x20]
0000796d027dae24  vmovaps xmm3, [rsp+0x30]
0000796d027dae2a  vmovaps xmm4, [rsp+0x40]
0000796d027dae30  vmovaps xmm5, [rsp+0x50]
0000796d027dae36  vmovaps xmm6, [rsp+0x60]
0000796d027dae3c  vmovaps xmm7, [rsp+0x70]
0000796d027dae42  vmovaps xmm8, [rsp+0x80]
0000796d027dae4b  vmovaps xmm9, [rsp+0x90]
0000796d027dae54  vmovaps xmm10, [rsp+0xA0]
0000796d027dae5d  vmovaps xmm11, [rsp+0xB0]
0000796d027dae66  vmovaps xmm12, [rsp+0xC0]
0000796d027dae6f  vmovaps xmm13, [rsp+0xD0]
0000796d027dae78  vmovaps xmm15, [rsp+0xE0]
0000796d027dae81  add rsp, 0xF0
0000796d027dae88  pop r11
0000796d027dae8a  pop r10
0000796d027dae8c  pop r9
0000796d027dae8e  pop r8
0000796d027dae90  pop rsi
0000796d027dae91  pop rdi
0000796d027dae92  pop rdx
0000796d027dae93  pop rcx
0000796d027dae94  pop rax
0000796d027dae95  add rsp, 0x08
0000796d027dae99  jmp 0x0000796D027D6578
0000796d027dae9e  sub rsp, 0x08
0000796d027daea2  push rax
0000796d027daea3  push rcx
0000796d027daea4  push rdx
0000796d027daea5  push rdi
0000796d027daea6  push rsi
0000796d027daea7  push r8
0000796d027daea9  push r9
0000796d027daeab  push r10
0000796d027daead  push r11
0000796d027daeaf  sub rsp, 0xF0
0000796d027daeb6  vmovaps [rsp], xmm0
0000796d027daebb  vmovaps [rsp+0x10], xmm2
0000796d027daec1  vmovaps [rsp+0x20], xmm3
0000796d027daec7  vmovaps [rsp+0x30], xmm4
0000796d027daecd  vmovaps [rsp+0x40], xmm5
0000796d027daed3  vmovaps [rsp+0x50], xmm6
0000796d027daed9  vmovaps [rsp+0x60], xmm7
0000796d027daedf  vmovaps [rsp+0x70], xmm8
0000796d027daee5  vmovaps [rsp+0x80], xmm9
0000796d027daeee  vmovaps [rsp+0x90], xmm10
0000796d027daef7  vmovaps [rsp+0xA0], xmm11
0000796d027daf00  vmovaps [rsp+0xB0], xmm12
0000796d027daf09  vmovaps [rsp+0xC0], xmm13
0000796d027daf12  vmovaps [rsp+0xD0], xmm14
0000796d027daf1b  vmovaps [rsp+0xE0], xmm15
0000796d027daf24  sub rsp, 0x30
0000796d027daf28  movaps [rsp], xmm1
0000796d027daf2c  movaps [rsp+0x10], xmm13
0000796d027daf32  movaps [rsp+0x20], xmm8
0000796d027daf38  lea rdi, [rsp]
0000796d027daf3c  mov esi, 0x00
0000796d027daf41  mov rax, 0x635FBE957530
0000796d027daf4b  call rax
0000796d027daf4d  movaps xmm1, [rsp]
0000796d027daf51  add rsp, 0x30
0000796d027daf55  vmovaps xmm0, [rsp]
0000796d027daf5a  vmovaps xmm2, [rsp+0x10]
0000796d027daf60  vmovaps xmm3, [rsp+0x20]
0000796d027daf66  vmovaps xmm4, [rsp+0x30]
0000796d027daf6c  vmovaps xmm5, [rsp+0x40]
0000796d027daf72  vmovaps xmm6, [rsp+0x50]
0000796d027daf78  vmovaps xmm7, [rsp+0x60]
0000796d027daf7e  vmovaps xmm8, [rsp+0x70]
0000796d027daf84  vmovaps xmm9, [rsp+0x80]
0000796d027daf8d  vmovaps xmm10, [rsp+0x90]
0000796d027daf96  vmovaps xmm11, [rsp+0xA0]
0000796d027daf9f  vmovaps xmm12, [rsp+0xB0]
0000796d027dafa8  vmovaps xmm13, [rsp+0xC0]
0000796d027dafb1  vmovaps xmm14, [rsp+0xD0]
0000796d027dafba  vmovaps xmm15, [rsp+0xE0]
0000796d027dafc3  add rsp, 0xF0
0000796d027dafca  pop r11
0000796d027dafcc  pop r10
0000796d027dafce  pop r9
0000796d027dafd0  pop r8
0000796d027dafd2  pop rsi
0000796d027dafd3  pop rdi
0000796d027dafd4  pop rdx
0000796d027dafd5  pop rcx
0000796d027dafd6  pop rax
0000796d027dafd7  add rsp, 0x08
0000796d027dafdb  jmp 0x0000796D027D659A
0000796d027dafe0  call 0x0000796D0260C260
0000796d027dafe5  jmp 0x0000796D027D65A8
0000796d027dafea  call 0x0000796D026DE950
0000796d027dafef  jmp 0x0000796D027D65B2
0000796d027daff4  sub rsp, 0x08
0000796d027daff8  push rax
0000796d027daff9  push rcx
0000796d027daffa  push rdx
0000796d027daffb  push rdi
0000796d027daffc  push rsi
0000796d027daffd  push r8
0000796d027dafff  push r9
0000796d027db001  push r10
0000796d027db003  push r11
0000796d027db005  sub rsp, 0xF0
0000796d027db00c  vmovaps [rsp], xmm0
0000796d027db011  vmovaps [rsp+0x10], xmm1
0000796d027db017  vmovaps [rsp+0x20], xmm2
0000796d027db01d  vmovaps [rsp+0x30], xmm3
0000796d027db023  vmovaps [rsp+0x40], xmm4
0000796d027db029  vmovaps [rsp+0x50], xmm5
0000796d027db02f  vmovaps [rsp+0x60], xmm6
0000796d027db035  vmovaps [rsp+0x70], xmm7
0000796d027db03b  vmovaps [rsp+0x80], xmm9
0000796d027db044  vmovaps [rsp+0x90], xmm10
0000796d027db04d  vmovaps [rsp+0xA0], xmm11
0000796d027db056  vmovaps [rsp+0xB0], xmm12
0000796d027db05f  vmovaps [rsp+0xC0], xmm13
0000796d027db068  vmovaps [rsp+0xD0], xmm14
0000796d027db071  vmovaps [rsp+0xE0], xmm15
0000796d027db07a  sub rsp, 0x30
0000796d027db07e  movaps [rsp], xmm8
0000796d027db083  movaps [rsp+0x10], xmm15
0000796d027db089  movaps [rsp+0x20], xmm7
0000796d027db08e  lea rdi, [rsp]
0000796d027db092  mov esi, 0x00
0000796d027db097  mov rax, 0x635FBE957530
0000796d027db0a1  call rax
0000796d027db0a3  movaps xmm8, [rsp]
0000796d027db0a8  add rsp, 0x30
0000796d027db0ac  vmovaps xmm0, [rsp]
0000796d027db0b1  vmovaps xmm1, [rsp+0x10]
0000796d027db0b7  vmovaps xmm2, [rsp+0x20]
0000796d027db0bd  vmovaps xmm3, [rsp+0x30]
0000796d027db0c3  vmovaps xmm4, [rsp+0x40]
0000796d027db0c9  vmovaps xmm5, [rsp+0x50]
0000796d027db0cf  vmovaps xmm6, [rsp+0x60]
0000796d027db0d5  vmovaps xmm7, [rsp+0x70]
0000796d027db0db  vmovaps xmm9, [rsp+0x80]
0000796d027db0e4  vmovaps xmm10, [rsp+0x90]
0000796d027db0ed  vmovaps xmm11, [rsp+0xA0]
0000796d027db0f6  vmovaps xmm12, [rsp+0xB0]
0000796d027db0ff  vmovaps xmm13, [rsp+0xC0]
0000796d027db108  vmovaps xmm14, [rsp+0xD0]
0000796d027db111  vmovaps xmm15, [rsp+0xE0]
0000796d027db11a  add rsp, 0xF0
0000796d027db121  pop r11
0000796d027db123  pop r10
0000796d027db125  pop r9
0000796d027db127  pop r8
0000796d027db129  pop rsi
0000796d027db12a  pop rdi
0000796d027db12b  pop rdx
0000796d027db12c  pop rcx
0000796d027db12d  pop rax
0000796d027db12e  add rsp, 0x08
0000796d027db132  jmp 0x0000796D027D65D4
0000796d027db137  sub rsp, 0x08
0000796d027db13b  push rax
0000796d027db13c  push rcx
0000796d027db13d  push rdx
0000796d027db13e  push rdi
0000796d027db13f  push rsi
0000796d027db140  push r8
0000796d027db142  push r9
0000796d027db144  push r10
0000796d027db146  push r11
0000796d027db148  sub rsp, 0xF0
0000796d027db14f  vmovaps [rsp], xmm0
0000796d027db154  vmovaps [rsp+0x10], xmm1
0000796d027db15a  vmovaps [rsp+0x20], xmm2
0000796d027db160  vmovaps [rsp+0x30], xmm3
0000796d027db166  vmovaps [rsp+0x40], xmm4
0000796d027db16c  vmovaps [rsp+0x50], xmm5
0000796d027db172  vmovaps [rsp+0x60], xmm6
0000796d027db178  vmovaps [rsp+0x70], xmm8
0000796d027db17e  vmovaps [rsp+0x80], xmm9
0000796d027db187  vmovaps [rsp+0x90], xmm10
0000796d027db190  vmovaps [rsp+0xA0], xmm11
0000796d027db199  vmovaps [rsp+0xB0], xmm12
0000796d027db1a2  vmovaps [rsp+0xC0], xmm13
0000796d027db1ab  vmovaps [rsp+0xD0], xmm14
0000796d027db1b4  vmovaps [rsp+0xE0], xmm15
0000796d027db1bd  sub rsp, 0x30
0000796d027db1c1  movaps [rsp], xmm7
0000796d027db1c5  movaps [rsp+0x10], xmm9
0000796d027db1cb  movaps [rsp+0x20], xmm15
0000796d027db1d1  lea rdi, [rsp]
0000796d027db1d5  mov esi, 0x00
0000796d027db1da  mov rax, 0x635FBE957530
0000796d027db1e4  call rax
0000796d027db1e6  movaps xmm7, [rsp]
0000796d027db1ea  add rsp, 0x30
0000796d027db1ee  vmovaps xmm0, [rsp]
0000796d027db1f3  vmovaps xmm1, [rsp+0x10]
0000796d027db1f9  vmovaps xmm2, [rsp+0x20]
0000796d027db1ff  vmovaps xmm3, [rsp+0x30]
0000796d027db205  vmovaps xmm4, [rsp+0x40]
0000796d027db20b  vmovaps xmm5, [rsp+0x50]
0000796d027db211  vmovaps xmm6, [rsp+0x60]
0000796d027db217  vmovaps xmm8, [rsp+0x70]
0000796d027db21d  vmovaps xmm9, [rsp+0x80]
0000796d027db226  vmovaps xmm10, [rsp+0x90]
0000796d027db22f  vmovaps xmm11, [rsp+0xA0]
0000796d027db238  vmovaps xmm12, [rsp+0xB0]
0000796d027db241  vmovaps xmm13, [rsp+0xC0]
0000796d027db24a  vmovaps xmm14, [rsp+0xD0]
0000796d027db253  vmovaps xmm15, [rsp+0xE0]
0000796d027db25c  add rsp, 0xF0
0000796d027db263  pop r11
0000796d027db265  pop r10
0000796d027db267  pop r9
0000796d027db269  pop r8
0000796d027db26b  pop rsi
0000796d027db26c  pop rdi
0000796d027db26d  pop rdx
0000796d027db26e  pop rcx
0000796d027db26f  pop rax
0000796d027db270  add rsp, 0x08
0000796d027db274  jmp 0x0000796D027D6601
0000796d027db279  sub rsp, 0x08
0000796d027db27d  push rax
0000796d027db27e  push rcx
0000796d027db27f  push rdx
0000796d027db280  push rdi
0000796d027db281  push rsi
0000796d027db282  push r8
0000796d027db284  push r9
0000796d027db286  push r10
0000796d027db288  push r11
0000796d027db28a  sub rsp, 0xF0
0000796d027db291  vmovaps [rsp], xmm0
0000796d027db296  vmovaps [rsp+0x10], xmm1
0000796d027db29c  vmovaps [rsp+0x20], xmm2
0000796d027db2a2  vmovaps [rsp+0x30], xmm3
0000796d027db2a8  vmovaps [rsp+0x40], xmm4
0000796d027db2ae  vmovaps [rsp+0x50], xmm5
0000796d027db2b4  vmovaps [rsp+0x60], xmm6
0000796d027db2ba  vmovaps [rsp+0x70], xmm7
0000796d027db2c0  vmovaps [rsp+0x80], xmm8
0000796d027db2c9  vmovaps [rsp+0x90], xmm10
0000796d027db2d2  vmovaps [rsp+0xA0], xmm11
0000796d027db2db  vmovaps [rsp+0xB0], xmm12
0000796d027db2e4  vmovaps [rsp+0xC0], xmm13
0000796d027db2ed  vmovaps [rsp+0xD0], xmm14
0000796d027db2f6  vmovaps [rsp+0xE0], xmm15
0000796d027db2ff  sub rsp, 0x30
0000796d027db303  movaps [rsp], xmm9
0000796d027db308  movaps [rsp+0x10], xmm13
0000796d027db30e  movaps [rsp+0x20], xmm15
0000796d027db314  lea rdi, [rsp]
0000796d027db318  mov esi, 0x00
0000796d027db31d  mov rax, 0x635FBE957530
0000796d027db327  call rax
0000796d027db329  movaps xmm9, [rsp]
0000796d027db32e  add rsp, 0x30
0000796d027db332  vmovaps xmm0, [rsp]
0000796d027db337  vmovaps xmm1, [rsp+0x10]
0000796d027db33d  vmovaps xmm2, [rsp+0x20]
0000796d027db343  vmovaps xmm3, [rsp+0x30]
0000796d027db349  vmovaps xmm4, [rsp+0x40]
0000796d027db34f  vmovaps xmm5, [rsp+0x50]
0000796d027db355  vmovaps xmm6, [rsp+0x60]
0000796d027db35b  vmovaps xmm7, [rsp+0x70]
0000796d027db361  vmovaps xmm8, [rsp+0x80]
0000796d027db36a  vmovaps xmm10, [rsp+0x90]
0000796d027db373  vmovaps xmm11, [rsp+0xA0]
0000796d027db37c  vmovaps xmm12, [rsp+0xB0]
0000796d027db385  vmovaps xmm13, [rsp+0xC0]
0000796d027db38e  vmovaps xmm14, [rsp+0xD0]
0000796d027db397  vmovaps xmm15, [rsp+0xE0]
0000796d027db3a0  add rsp, 0xF0
0000796d027db3a7  pop r11
0000796d027db3a9  pop r10
0000796d027db3ab  pop r9
0000796d027db3ad  pop r8
0000796d027db3af  pop rsi
0000796d027db3b0  pop rdi
0000796d027db3b1  pop rdx
0000796d027db3b2  pop rcx
0000796d027db3b3  pop rax
0000796d027db3b4  add rsp, 0x08
0000796d027db3b8  jmp 0x0000796D027D662F
0000796d027db3bd  sub rsp, 0x08
0000796d027db3c1  push rax
0000796d027db3c2  push rcx
0000796d027db3c3  push rdx
0000796d027db3c4  push rdi
0000796d027db3c5  push rsi
0000796d027db3c6  push r8
0000796d027db3c8  push r9
0000796d027db3ca  push r10
0000796d027db3cc  push r11
0000796d027db3ce  sub rsp, 0xF0
0000796d027db3d5  vmovaps [rsp], xmm0
0000796d027db3da  vmovaps [rsp+0x10], xmm1
0000796d027db3e0  vmovaps [rsp+0x20], xmm2
0000796d027db3e6  vmovaps [rsp+0x30], xmm3
0000796d027db3ec  vmovaps [rsp+0x40], xmm4
0000796d027db3f2  vmovaps [rsp+0x50], xmm5
0000796d027db3f8  vmovaps [rsp+0x60], xmm6
0000796d027db3fe  vmovaps [rsp+0x70], xmm7
0000796d027db404  vmovaps [rsp+0x80], xmm8
0000796d027db40d  vmovaps [rsp+0x90], xmm9
0000796d027db416  vmovaps [rsp+0xA0], xmm10
0000796d027db41f  vmovaps [rsp+0xB0], xmm11
0000796d027db428  vmovaps [rsp+0xC0], xmm12
0000796d027db431  vmovaps [rsp+0xD0], xmm13
0000796d027db43a  vmovaps [rsp+0xE0], xmm14
0000796d027db443  sub rsp, 0x30
0000796d027db447  movaps [rsp], xmm15
0000796d027db44c  movaps [rsp+0x10], xmm11
0000796d027db452  movaps [rsp+0x20], xmm12
0000796d027db458  lea rdi, [rsp]
0000796d027db45c  mov esi, 0x00
0000796d027db461  mov rax, 0x635FBE957530
0000796d027db46b  call rax
0000796d027db46d  movaps xmm15, [rsp]
0000796d027db472  add rsp, 0x30
0000796d027db476  vmovaps xmm0, [rsp]
0000796d027db47b  vmovaps xmm1, [rsp+0x10]
0000796d027db481  vmovaps xmm2, [rsp+0x20]
0000796d027db487  vmovaps xmm3, [rsp+0x30]
0000796d027db48d  vmovaps xmm4, [rsp+0x40]
0000796d027db493  vmovaps xmm5, [rsp+0x50]
0000796d027db499  vmovaps xmm6, [rsp+0x60]
0000796d027db49f  vmovaps xmm7, [rsp+0x70]
0000796d027db4a5  vmovaps xmm8, [rsp+0x80]
0000796d027db4ae  vmovaps xmm9, [rsp+0x90]
0000796d027db4b7  vmovaps xmm10, [rsp+0xA0]
0000796d027db4c0  vmovaps xmm11, [rsp+0xB0]
0000796d027db4c9  vmovaps xmm12, [rsp+0xC0]
0000796d027db4d2  vmovaps xmm13, [rsp+0xD0]
0000796d027db4db  vmovaps xmm14, [rsp+0xE0]
0000796d027db4e4  add rsp, 0xF0
0000796d027db4eb  pop r11
0000796d027db4ed  pop r10
0000796d027db4ef  pop r9
0000796d027db4f1  pop r8
0000796d027db4f3  pop rsi
0000796d027db4f4  pop rdi
0000796d027db4f5  pop rdx
0000796d027db4f6  pop rcx
0000796d027db4f7  pop rax
0000796d027db4f8  add rsp, 0x08
0000796d027db4fc  jmp 0x0000796D027D664A
0000796d027db501  sub rsp, 0x08
0000796d027db505  push rax
0000796d027db506  push rcx
0000796d027db507  push rdx
0000796d027db508  push rdi
0000796d027db509  push rsi
0000796d027db50a  push r8
0000796d027db50c  push r9
0000796d027db50e  push r10
0000796d027db510  push r11
0000796d027db512  sub rsp, 0xF0
0000796d027db519  vmovaps [rsp], xmm0
0000796d027db51e  vmovaps [rsp+0x10], xmm1
0000796d027db524  vmovaps [rsp+0x20], xmm2
0000796d027db52a  vmovaps [rsp+0x30], xmm3
0000796d027db530  vmovaps [rsp+0x40], xmm4
0000796d027db536  vmovaps [rsp+0x50], xmm5
0000796d027db53c  vmovaps [rsp+0x60], xmm6
0000796d027db542  vmovaps [rsp+0x70], xmm7
0000796d027db548  vmovaps [rsp+0x80], xmm8
0000796d027db551  vmovaps [rsp+0x90], xmm9
0000796d027db55a  vmovaps [rsp+0xA0], xmm10
0000796d027db563  vmovaps [rsp+0xB0], xmm11
0000796d027db56c  vmovaps [rsp+0xC0], xmm12
0000796d027db575  vmovaps [rsp+0xD0], xmm14
0000796d027db57e  vmovaps [rsp+0xE0], xmm15
0000796d027db587  sub rsp, 0x30
0000796d027db58b  movaps [rsp], xmm13
0000796d027db590  movaps [rsp+0x10], xmm10
0000796d027db596  movaps [rsp+0x20], xmm14
0000796d027db59c  lea rdi, [rsp]
0000796d027db5a0  mov esi, 0x00
0000796d027db5a5  mov rax, 0x635FBE957530
0000796d027db5af  call rax
0000796d027db5b1  movaps xmm13, [rsp]
0000796d027db5b6  add rsp, 0x30
0000796d027db5ba  vmovaps xmm0, [rsp]
0000796d027db5bf  vmovaps xmm1, [rsp+0x10]
0000796d027db5c5  vmovaps xmm2, [rsp+0x20]
0000796d027db5cb  vmovaps xmm3, [rsp+0x30]
0000796d027db5d1  vmovaps xmm4, [rsp+0x40]
0000796d027db5d7  vmovaps xmm5, [rsp+0x50]
0000796d027db5dd  vmovaps xmm6, [rsp+0x60]
0000796d027db5e3  vmovaps xmm7, [rsp+0x70]
0000796d027db5e9  vmovaps xmm8, [rsp+0x80]
0000796d027db5f2  vmovaps xmm9, [rsp+0x90]
0000796d027db5fb  vmovaps xmm10, [rsp+0xA0]
0000796d027db604  vmovaps xmm11, [rsp+0xB0]
0000796d027db60d  vmovaps xmm12, [rsp+0xC0]
0000796d027db616  vmovaps xmm14, [rsp+0xD0]
0000796d027db61f  vmovaps xmm15, [rsp+0xE0]
0000796d027db628  add rsp, 0xF0
0000796d027db62f  pop r11
0000796d027db631  pop r10
0000796d027db633  pop r9
0000796d027db635  pop r8
0000796d027db637  pop rsi
0000796d027db638  pop rdi
0000796d027db639  pop rdx
0000796d027db63a  pop rcx
0000796d027db63b  pop rax
0000796d027db63c  add rsp, 0x08
0000796d027db640  jmp 0x0000796D027D666D
0000796d027db645  sub rsp, 0x08
0000796d027db649  push rax
0000796d027db64a  push rcx
0000796d027db64b  push rdx
0000796d027db64c  push rdi
0000796d027db64d  push rsi
0000796d027db64e  push r8
0000796d027db650  push r9
0000796d027db652  push r10
0000796d027db654  push r11
0000796d027db656  sub rsp, 0xF0
0000796d027db65d  vmovaps [rsp], xmm0
0000796d027db662  vmovaps [rsp+0x10], xmm1
0000796d027db668  vmovaps [rsp+0x20], xmm2
0000796d027db66e  vmovaps [rsp+0x30], xmm3
0000796d027db674  vmovaps [rsp+0x40], xmm4
0000796d027db67a  vmovaps [rsp+0x50], xmm5
0000796d027db680  vmovaps [rsp+0x60], xmm6
0000796d027db686  vmovaps [rsp+0x70], xmm7
0000796d027db68c  vmovaps [rsp+0x80], xmm8
0000796d027db695  vmovaps [rsp+0x90], xmm9
0000796d027db69e  vmovaps [rsp+0xA0], xmm10
0000796d027db6a7  vmovaps [rsp+0xB0], xmm11
0000796d027db6b0  vmovaps [rsp+0xC0], xmm12
0000796d027db6b9  vmovaps [rsp+0xD0], xmm13
0000796d027db6c2  vmovaps [rsp+0xE0], xmm15
0000796d027db6cb  sub rsp, 0x30
0000796d027db6cf  movaps [rsp], xmm14
0000796d027db6d4  movaps [rsp+0x10], xmm1
0000796d027db6d9  movaps [rsp+0x20], xmm7
0000796d027db6de  lea rdi, [rsp]
0000796d027db6e2  mov esi, 0x00
0000796d027db6e7  mov rax, 0x635FBE957530
0000796d027db6f1  call rax
0000796d027db6f3  movaps xmm14, [rsp]
0000796d027db6f8  add rsp, 0x30
0000796d027db6fc  vmovaps xmm0, [rsp]
0000796d027db701  vmovaps xmm1, [rsp+0x10]
0000796d027db707  vmovaps xmm2, [rsp+0x20]
0000796d027db70d  vmovaps xmm3, [rsp+0x30]
0000796d027db713  vmovaps xmm4, [rsp+0x40]
0000796d027db719  vmovaps xmm5, [rsp+0x50]
0000796d027db71f  vmovaps xmm6, [rsp+0x60]
0000796d027db725  vmovaps xmm7, [rsp+0x70]
0000796d027db72b  vmovaps xmm8, [rsp+0x80]
0000796d027db734  vmovaps xmm9, [rsp+0x90]
0000796d027db73d  vmovaps xmm10, [rsp+0xA0]
0000796d027db746  vmovaps xmm11, [rsp+0xB0]
0000796d027db74f  vmovaps xmm12, [rsp+0xC0]
0000796d027db758  vmovaps xmm13, [rsp+0xD0]
0000796d027db761  vmovaps xmm15, [rsp+0xE0]
0000796d027db76a  add rsp, 0xF0
0000796d027db771  pop r11
0000796d027db773  pop r10
0000796d027db775  pop r9
0000796d027db777  pop r8
0000796d027db779  pop rsi
0000796d027db77a  pop rdi
0000796d027db77b  pop rdx
0000796d027db77c  pop rcx
0000796d027db77d  pop rax
0000796d027db77e  add rsp, 0x08
0000796d027db782  jmp 0x0000796D027D6690
0000796d027db787  sub rsp, 0x08
0000796d027db78b  push rax
0000796d027db78c  push rcx
0000796d027db78d  push rdx
0000796d027db78e  push rdi
0000796d027db78f  push rsi
0000796d027db790  push r8
0000796d027db792  push r9
0000796d027db794  push r10
0000796d027db796  push r11
0000796d027db798  sub rsp, 0xF0
0000796d027db79f  vmovaps [rsp], xmm0
0000796d027db7a4  vmovaps [rsp+0x10], xmm2
0000796d027db7aa  vmovaps [rsp+0x20], xmm3
0000796d027db7b0  vmovaps [rsp+0x30], xmm4
0000796d027db7b6  vmovaps [rsp+0x40], xmm5
0000796d027db7bc  vmovaps [rsp+0x50], xmm6
0000796d027db7c2  vmovaps [rsp+0x60], xmm7
0000796d027db7c8  vmovaps [rsp+0x70], xmm8
0000796d027db7ce  vmovaps [rsp+0x80], xmm9
0000796d027db7d7  vmovaps [rsp+0x90], xmm10
0000796d027db7e0  vmovaps [rsp+0xA0], xmm11
0000796d027db7e9  vmovaps [rsp+0xB0], xmm12
0000796d027db7f2  vmovaps [rsp+0xC0], xmm13
0000796d027db7fb  vmovaps [rsp+0xD0], xmm14
0000796d027db804  vmovaps [rsp+0xE0], xmm15
0000796d027db80d  sub rsp, 0x30
0000796d027db811  movaps [rsp], xmm1
0000796d027db815  movaps [rsp+0x10], xmm8
0000796d027db81b  movaps [rsp+0x20], xmm9
0000796d027db821  lea rdi, [rsp]
0000796d027db825  mov esi, 0x00
0000796d027db82a  mov rax, 0x635FBE957530
0000796d027db834  call rax
0000796d027db836  movaps xmm1, [rsp]
0000796d027db83a  add rsp, 0x30
0000796d027db83e  vmovaps xmm0, [rsp]
0000796d027db843  vmovaps xmm2, [rsp+0x10]
0000796d027db849  vmovaps xmm3, [rsp+0x20]
0000796d027db84f  vmovaps xmm4, [rsp+0x30]
0000796d027db855  vmovaps xmm5, [rsp+0x40]
0000796d027db85b  vmovaps xmm6, [rsp+0x50]
0000796d027db861  vmovaps xmm7, [rsp+0x60]
0000796d027db867  vmovaps xmm8, [rsp+0x70]
0000796d027db86d  vmovaps xmm9, [rsp+0x80]
0000796d027db876  vmovaps xmm10, [rsp+0x90]
0000796d027db87f  vmovaps xmm11, [rsp+0xA0]
0000796d027db888  vmovaps xmm12, [rsp+0xB0]
0000796d027db891  vmovaps xmm13, [rsp+0xC0]
0000796d027db89a  vmovaps xmm14, [rsp+0xD0]
0000796d027db8a3  vmovaps xmm15, [rsp+0xE0]
0000796d027db8ac  add rsp, 0xF0
0000796d027db8b3  pop r11
0000796d027db8b5  pop r10
0000796d027db8b7  pop r9
0000796d027db8b9  pop r8
0000796d027db8bb  pop rsi
0000796d027db8bc  pop rdi
0000796d027db8bd  pop rdx
0000796d027db8be  pop rcx
0000796d027db8bf  pop rax
0000796d027db8c0  add rsp, 0x08
0000796d027db8c4  jmp 0x0000796D027D66B2
0000796d027db8c9  call 0x0000796D026B3E40
0000796d027db8ce  jmp 0x0000796D027D66C0
0000796d027db8d3  call 0x0000796D0260C380
0000796d027db8d8  jmp 0x0000796D027D66CA
0000796d027db8dd  call 0x0000796D0260D600
0000796d027db8e2  jmp 0x0000796D027D66D4
0000796d027db8e7  call 0x0000796D025FF540
0000796d027db8ec  jmp 0x0000796D027D66DE
0000796d027db8f1  int3
0000796d027db8f2  nop [rax+rax*1], ax
0000796d027db8fb  nop [rax+rax*1], eax
0000796d027db900  mov eax, [r15+0x48]
0000796d027db904  lea r14d, [eax+0x01]
0000796d027db909  mov [rsp+0x10], r14d
0000796d027db90e  mov r14d, r14d
0000796d027db911  mov [r15+0x48], r14
0000796d027db915  xor eax, eax
0000796d027db917  mov r14d, [rsp+0x10]
0000796d027db91c  cmp r14d, 0x1F4
0000796d027db923  cmc
0000796d027db924  lahf
0000796d027db925  seto al
0000796d027db928  mov [r15+0x108], eax
0000796d027db92f  mov eax, [r15+0x108]
0000796d027db936  sahf
0000796d027db937  jnz 0x0000796D027DB969
0000796d027db939  cmp dword ptr [r15+0x318], 0x00
0000796d027db941  jz 0x0000796D027E1AB0
0000796d027db947  nop [rax+rax*1], ax
0000796d027db950  nop [rax+rax*1], eax
0000796d027db958  mov eax, 0x410450
0000796d027db95d  mov [r15+0x100], rax
0000796d027db964  jmp 0x0000796D025FE110
0000796d027db969  cmp dword ptr [r15+0x318], 0x00
0000796d027db971  jz 0x0000796D027DB9A0
0000796d027db977  nop [rax+rax*1], ax
0000796d027db980  nop [rax+rax*1], eax
0000796d027db988  mov eax, 0x410274
0000796d027db98d  mov [r15+0x100], rax
0000796d027db994  jmp 0x0000796D025FE110
0000796d027db999  int3
0000796d027db99a  int3
0000796d027db99b  nop [rax+rax*1], eax
0000796d027db9a0  mov rax, [r15+0x40]
0000796d027db9a4  movaps xmm1, [r15+0x1D0]
0000796d027db9ac  vmovaps [rsp+0x10], xmm1
0000796d027db9b2  vmovaps xmm15, [rsp+0x10]
0000796d027db9b8  por xmm1, xmm15
0000796d027db9bd  movaps xmm14, [r15+0x1A0]
0000796d027db9c5  vmovaps [rsp+0x10], xmm14
0000796d027db9cb  vmovaps xmm13, [rsp+0x10]
0000796d027db9d1  por xmm14, xmm13
0000796d027db9d6  lea r14, [rax+0x30]
0000796d027db9da  mov r12, [r13+r14*1]
0000796d027db9df  lea r14, [rax+0x38]
0000796d027db9e3  mov r11, [r13+r14*1]
0000796d027db9e8  movq xmm13, r12
0000796d027db9ed  movq xmm12, r11
0000796d027db9f2  movq xmm13, xmm13
0000796d027db9f7  vmovaps [rsp+0x10], xmm13
0000796d027db9fd  movq xmm13, xmm13
0000796d027dba02  movaps [r15+0x130], xmm13
0000796d027dba0a  movq xmm12, xmm12
0000796d027dba0f  vmovaps [rsp+0x20], xmm12
0000796d027dba15  movq xmm12, xmm12
0000796d027dba1a  movaps [r15+0x280], xmm12
0000796d027dba22  movaps xmm13, [r15+0x270]
0000796d027dba2a  vmovaps [rsp+0x30], xmm13
0000796d027dba30  vmovaps xmm12, [rsp+0x30]
0000796d027dba36  por xmm13, xmm12
0000796d027dba3b  lea r14, [rax+0x20]
0000796d027dba3f  mov r12, [r13+r14*1]
0000796d027dba44  lea r14, [rax+0x28]
0000796d027dba48  mov r11, [r13+r14*1]
0000796d027dba4d  movq xmm12, r12
0000796d027dba52  movq xmm11, r11
0000796d027dba57  movq xmm12, xmm12
0000796d027dba5c  vmovaps [rsp+0x30], xmm12
0000796d027dba62  movq xmm12, xmm12
0000796d027dba67  movaps [r15+0x150], xmm12
0000796d027dba6f  movq xmm11, xmm11
0000796d027dba74  vmovaps [rsp+0x40], xmm11
0000796d027dba7a  movq xmm11, xmm11
0000796d027dba7f  movaps [r15+0x140], xmm11
0000796d027dba87  lea r14, [rax+0x10]
0000796d027dba8b  mov r12, [r13+r14*1]
0000796d027dba90  lea r14, [rax+0x18]
0000796d027dba94  mov r11, [r13+r14*1]
0000796d027dba99  movq xmm12, r12
0000796d027dba9e  movq xmm11, r11
0000796d027dbaa3  movq xmm12, xmm12
0000796d027dbaa8  vmovaps [rsp+0x50], xmm12
0000796d027dbaae  movq xmm12, xmm12
0000796d027dbab3  movaps [r15+0x170], xmm12
0000796d027dbabb  movq xmm11, xmm11
0000796d027dbac0  vmovaps [rsp+0x60], xmm11
0000796d027dbac6  movq xmm11, xmm11
0000796d027dbacb  movaps [r15+0x160], xmm11
0000796d027dbad3  mov r14, [r13+rax*1]
0000796d027dbad8  vmovq xmm12, r14
0000796d027dbadd  vpbroadcastq xmm12, xmm12
0000796d027dbae2  lea r14, [rax+0x08]
0000796d027dbae6  mov rax, [r13+r14*1]
0000796d027dbaeb  movq xmm11, rax
0000796d027dbaf0  movaps [r15+0x230], xmm11
0000796d027dbaf8  mov rax, [r15+0xF8]
0000796d027dbaff  lea r14, [rax+0x50]
0000796d027dbb03  movups xmm11, [r13+r14*1]
0000796d027dbb09  lea r14, [rax+0x60]
0000796d027dbb0d  movups xmm10, [r13+r14*1]
0000796d027dbb13  lea r14, [rax+0x30]
0000796d027dbb17  movups xmm9, [r13+r14*1]
0000796d027dbb1d  mov r14, [r15+0x50]
0000796d027dbb21  mov [r15+0x60], r14
0000796d027dbb25  mov qword ptr [r15+0x58], 0x40
0000796d027dbb2d  movaps xmm8, xmm12
0000796d027dbb31  mulpd xmm8, xmm15
0000796d027dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
0000796d027dbb3c  ptest xmm7, xmm7
0000796d027dbb41  jnz 0x0000796D027DC96A
0000796d027dbb47  movq xmm15, qword ptr [r15+0x230]
0000796d027dbb50  vmovaps [rsp+0x70], xmm15
0000796d027dbb56  vpermilpd xmm15, xmm15, 0x00
0000796d027dbb5c  movaps xmm7, xmm9
0000796d027dbb60  mulpd xmm7, xmm15
0000796d027dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
0000796d027dbb6a  ptest xmm6, xmm6
0000796d027dbb6f  jnz 0x0000796D027DCAAE
0000796d027dbb75  vxorps xmm15, xmm15, xmm15
0000796d027dbb7a  vpbroadcastq xmm15, xmm15
0000796d027dbb7f  movaps xmm9, xmm12
0000796d027dbb83  mulpd xmm9, xmm10
0000796d027dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
0000796d027dbb8e  ptest xmm6, xmm6
0000796d027dbb93  jnz 0x0000796D027DCBF0
0000796d027dbb99  movaps xmm10, xmm12
0000796d027dbb9d  mulpd xmm10, xmm11
0000796d027dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
0000796d027dbba8  ptest xmm6, xmm6
0000796d027dbbad  jnz 0x0000796D027DCD34
0000796d027dbbb3  movaps xmm11, [r15+0x1F0]
0000796d027dbbbb  movaps xmm6, xmm12
0000796d027dbbbf  mulpd xmm6, xmm11
0000796d027dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
0000796d027dbbc9  ptest xmm5, xmm5
0000796d027dbbce  jnz 0x0000796D027DCE78
0000796d027dbbd4  movaps xmm12, [r15+0x2A0]
0000796d027dbbdc  vmovaps [rsp+0x80], xmm12
0000796d027dbbe5  vmovaps xmm11, [rsp+0x80]
0000796d027dbbee  por xmm12, xmm11
0000796d027dbbf3  movaps xmm11, [r15+0x250]
0000796d027dbbfb  vmovaps [rsp+0x80], xmm11
0000796d027dbc04  vmovaps xmm5, [rsp+0x80]
0000796d027dbc0d  por xmm11, xmm5
0000796d027dbc12  vmovaps xmm4, [rsp+0x70]
0000796d027dbc18  vpermilpd xmm4, xmm4, 0x00
0000796d027dbc1e  movaps xmm3, xmm5
0000796d027dbc21  mulpd xmm3, xmm4
0000796d027dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
0000796d027dbc2a  ptest xmm2, xmm2
0000796d027dbc2f  jnz 0x0000796D027DCFBA
0000796d027dbc35  mov [rsp+0x80], rax
0000796d027dbc3d  xor eax, eax
0000796d027dbc3f  mov r12d, 0x40
0000796d027dbc45  mov r11d, 0x200
0000796d027dbc4b  cmp r12, r11
0000796d027dbc4e  cmc
0000796d027dbc4f  lahf
0000796d027dbc50  seto al
0000796d027dbc53  mov [r15+0x108], eax
0000796d027dbc5a  movaps xmm5, xmm8
0000796d027dbc5e  addpd xmm5, xmm15
0000796d027dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
0000796d027dbc68  ptest xmm4, xmm4
0000796d027dbc6d  jnz 0x0000796D027DD0FA
0000796d027dbc73  movaps xmm8, [r15+0x1B0]
0000796d027dbc7b  movaps xmm4, xmm9
0000796d027dbc7f  addpd xmm4, xmm8
0000796d027dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
0000796d027dbc89  ptest xmm2, xmm2
0000796d027dbc8e  jnz 0x0000796D027DD23C
0000796d027dbc94  movaps xmm9, xmm10
0000796d027dbc98  addpd xmm9, xmm8
0000796d027dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
0000796d027dbca3  ptest xmm2, xmm2
0000796d027dbca8  jnz 0x0000796D027DD37E
0000796d027dbcae  movaps xmm10, [r15+0x2F0]
0000796d027dbcb6  vmovaps [rsp+0x90], xmm10
0000796d027dbcbf  vmovaps xmm8, [rsp+0x90]
0000796d027dbcc8  por xmm10, xmm8
0000796d027dbccd  movaps xmm8, [r15+0x2E0]
0000796d027dbcd5  vmovaps [rsp+0x90], xmm8
0000796d027dbcde  vmovaps xmm2, [rsp+0x90]
0000796d027dbce7  por xmm8, xmm2
0000796d027dbcec  movaps xmm2, [r15+0x2D0]
0000796d027dbcf4  vmovaps [rsp+0x90], xmm2
0000796d027dbcfd  vmovaps [rsp+0xA0], xmm1
0000796d027dbd06  vmovaps xmm1, [rsp+0x90]
0000796d027dbd0f  por xmm2, xmm1
0000796d027dbd13  movaps xmm1, [r15+0x200]
0000796d027dbd1b  vmovaps [rsp+0x90], xmm1
0000796d027dbd24  vmovaps [rsp+0xB0], xmm15
0000796d027dbd2d  vmovaps xmm15, [rsp+0x90]
0000796d027dbd36  por xmm1, xmm15
0000796d027dbd3b  movaps xmm15, [r15+0x1C0]
0000796d027dbd43  vmovaps [rsp+0x90], xmm15
0000796d027dbd4c  vmovaps [rsp+0xC0], xmm1
0000796d027dbd55  vmovaps xmm1, [rsp+0x90]
0000796d027dbd5e  por xmm15, xmm1
0000796d027dbd63  movaps xmm1, [r15+0x190]
0000796d027dbd6b  vmovaps [rsp+0x90], xmm1
0000796d027dbd74  vmovaps [rsp+0xD0], xmm15
0000796d027dbd7d  vmovaps xmm15, [rsp+0x90]
0000796d027dbd86  por xmm1, xmm15
0000796d027dbd8b  movaps xmm15, [r15+0x300]
0000796d027dbd93  vmovaps [rsp+0x90], xmm15
0000796d027dbd9c  vmovaps [rsp+0xE0], xmm1
0000796d027dbda5  vmovaps xmm1, [rsp+0x90]
0000796d027dbdae  por xmm15, xmm1
0000796d027dbdb3  mov rax, [rsp+0x80]
0000796d027dbdbb  lea r12, [rax+0xA0]
0000796d027dbdc2  movups xmm1, [r13+r12*1]
0000796d027dbdc8  lea r12, [rax+0xB0]
0000796d027dbdcf  vmovaps [rsp+0x80], xmm1
0000796d027dbdd8  movups xmm1, [r13+r12*1]
0000796d027dbdde  vmovaps [rsp+0x90], xmm1
0000796d027dbde7  vmovaps [rsp+0xF0], xmm15
0000796d027dbdf0  vmovaps xmm15, [rsp+0xB0]
0000796d027dbdf9  vmovaps [rsp+0xB0], xmm14
0000796d027dbe02  movaps xmm1, xmm6
0000796d027dbe05  addpd xmm1, xmm15
0000796d027dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
0000796d027dbe0f  ptest xmm14, xmm14
0000796d027dbe15  jnz 0x0000796D027DD4D6
0000796d027dbe1b  lea r12, [rax+0xF0]
0000796d027dbe22  movups xmm15, [r13+r12*1]
0000796d027dbe28  movaps xmm14, xmm4
0000796d027dbe2c  addpd xmm14, xmm3
0000796d027dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
0000796d027dbe37  ptest xmm6, xmm6
0000796d027dbe3c  jnz 0x0000796D027DD621
0000796d027dbe42  movaps xmm6, xmm9
0000796d027dbe46  addpd xmm6, xmm7
0000796d027dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
0000796d027dbe4f  ptest xmm4, xmm4
0000796d027dbe54  jnz 0x0000796D027DD763
0000796d027dbe5a  vmovaps xmm9, [rsp+0x70]
0000796d027dbe60  vpermilpd xmm9, xmm9, 0x00
0000796d027dbe66  vmovaps xmm4, [rsp+0x90]
0000796d027dbe6f  movaps xmm7, xmm4
0000796d027dbe72  mulpd xmm7, xmm9
0000796d027dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
0000796d027dbe7c  ptest xmm3, xmm3
0000796d027dbe81  jnz 0x0000796D027DD8A4
0000796d027dbe87  vmovaps xmm9, [rsp+0x50]
0000796d027dbe8d  vpermilpd xmm9, xmm9, 0x00
0000796d027dbe93  movaps xmm4, xmm15
0000796d027dbe97  mulpd xmm4, xmm9
0000796d027dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
0000796d027dbea1  ptest xmm3, xmm3
0000796d027dbea6  jnz 0x0000796D027DD9E5
0000796d027dbeac  lea r12, [rax+0xE0]
0000796d027dbeb3  movups xmm15, [r13+r12*1]
0000796d027dbeb9  vmovaps xmm9, [rsp+0x70]
0000796d027dbebf  vpermilpd xmm9, xmm9, 0x00
0000796d027dbec5  vmovaps [rsp+0x70], xmm1
0000796d027dbecb  vmovaps xmm1, [rsp+0x80]
0000796d027dbed4  vmovaps [rsp+0x80], xmm15
0000796d027dbedd  movaps xmm3, xmm1
0000796d027dbee0  mulpd xmm3, xmm9
0000796d027dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
0000796d027dbeea  ptest xmm15, xmm15
0000796d027dbef0  jnz 0x0000796D027DDB31
0000796d027dbef6  vmovaps xmm1, [rsp+0xF0]
0000796d027dbeff  vmovaps xmm15, [rsp+0xF0]
0000796d027dbf08  por xmm1, xmm15
0000796d027dbf0d  movaps [r15+0x300], xmm1
0000796d027dbf15  vmovaps xmm15, [rsp+0xE0]
0000796d027dbf1e  vmovaps xmm9, [rsp+0xE0]
0000796d027dbf27  por xmm15, xmm9
0000796d027dbf2c  movaps [r15+0x190], xmm15
0000796d027dbf34  vmovaps xmm9, [rsp+0x50]
0000796d027dbf3a  vpermilpd xmm9, xmm9, 0x00
0000796d027dbf40  vmovaps [rsp+0x90], xmm1
0000796d027dbf49  vmovaps [rsp+0xE0], xmm15
0000796d027dbf52  vmovaps xmm15, [rsp+0x80]
0000796d027dbf5b  vmovaps [rsp+0x80], xmm14
0000796d027dbf64  movaps xmm1, xmm15
0000796d027dbf68  mulpd xmm1, xmm9
0000796d027dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
0000796d027dbf72  ptest xmm14, xmm14
0000796d027dbf78  jnz 0x0000796D027DDC72
0000796d027dbf7e  lea r12, [rax+0x90]
0000796d027dbf85  movups xmm15, [r13+r12*1]
0000796d027dbf8b  vmovaps xmm14, [rsp+0xD0]
0000796d027dbf94  vmovaps xmm9, [rsp+0xD0]
0000796d027dbf9d  por xmm14, xmm9
0000796d027dbfa2  movaps [r15+0x1C0], xmm14
0000796d027dbfaa  vmovaps xmm9, [rsp+0xC0]
0000796d027dbfb3  vmovaps [rsp+0xD0], xmm1
0000796d027dbfbc  vmovaps xmm1, [rsp+0xC0]
0000796d027dbfc5  por xmm9, xmm1
0000796d027dbfca  movaps [r15+0x200], xmm9
0000796d027dbfd2  vmovaps [rsp+0xC0], xmm2
0000796d027dbfdb  vmovaps xmm1, [rsp+0xC0]
0000796d027dbfe4  por xmm2, xmm1
0000796d027dbfe8  movaps [r15+0x2D0], xmm2
0000796d027dbff0  vmovaps [rsp+0xC0], xmm8
0000796d027dbff9  vmovaps xmm1, [rsp+0xC0]
0000796d027dc002  por xmm8, xmm1
0000796d027dc007  movaps [r15+0x2E0], xmm8
0000796d027dc00f  vmovaps [rsp+0xC0], xmm15
0000796d027dc018  movaps xmm1, xmm5
0000796d027dc01b  addpd xmm1, xmm7
0000796d027dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
0000796d027dc024  ptest xmm15, xmm15
0000796d027dc02a  jnz 0x0000796D027DDDBE
0000796d027dc030  vmovaps xmm15, [rsp+0x50]
0000796d027dc036  vpermilpd xmm15, xmm15, 0x00
0000796d027dc03c  vmovaps xmm5, [rsp+0xC0]
0000796d027dc045  vmovaps [rsp+0xC0], xmm1
0000796d027dc04e  movaps xmm7, xmm5
0000796d027dc051  mulpd xmm7, xmm15
0000796d027dc056  vcmppd xmm1, xmm7, xmm7, 0x03
0000796d027dc05b  ptest xmm1, xmm1
0000796d027dc060  jnz 0x0000796D027DDEFE
0000796d027dc066  lea r12, [rax+0x80]
0000796d027dc06d  movups xmm1, [r13+r12*1]
0000796d027dc073  vmovaps xmm5, [rsp+0x70]
0000796d027dc079  vmovaps [rsp+0x70], xmm1
0000796d027dc07f  movaps xmm15, xmm5
0000796d027dc083  addpd xmm15, xmm3
0000796d027dc088  vcmppd xmm1, xmm15, xmm15, 0x03
0000796d027dc08e  ptest xmm1, xmm1
0000796d027dc093  jnz 0x0000796D027DE049
0000796d027dc099  vmovaps xmm5, [rsp+0x80]
0000796d027dc0a2  movaps xmm1, xmm5
0000796d027dc0a5  addpd xmm1, xmm4
0000796d027dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
0000796d027dc0ae  ptest xmm3, xmm3
0000796d027dc0b3  jnz 0x0000796D027DE18B
0000796d027dc0b9  vmovaps [rsp+0x80], xmm10
0000796d027dc0c2  vmovaps xmm5, [rsp+0x80]
0000796d027dc0cb  por xmm10, xmm5
0000796d027dc0d0  movaps [r15+0x2F0], xmm10
0000796d027dc0d8  vmovaps xmm5, [rsp+0x50]
0000796d027dc0de  vpermilpd xmm5, xmm5, 0x00
0000796d027dc0e4  vmovaps xmm3, [rsp+0x70]
0000796d027dc0ea  vmovaps [rsp+0x50], xmm1
0000796d027dc0f0  movaps xmm4, xmm3
0000796d027dc0f3  mulpd xmm4, xmm5
0000796d027dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
0000796d027dc0fc  ptest xmm1, xmm1
0000796d027dc101  jnz 0x0000796D027DE2CB
0000796d027dc107  lea r12, [rax+0xD0]
0000796d027dc10e  movups xmm1, [r13+r12*1]
0000796d027dc114  vmovaps xmm3, [rsp+0xD0]
0000796d027dc11d  vmovaps [rsp+0x70], xmm1
0000796d027dc123  movaps xmm5, xmm6
0000796d027dc126  addpd xmm5, xmm3
0000796d027dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
0000796d027dc12f  ptest xmm1, xmm1
0000796d027dc134  jnz 0x0000796D027DE415
0000796d027dc13a  vmovaps xmm1, [rsp+0x60]
0000796d027dc140  vpermilpd xmm1, xmm1, 0x00
0000796d027dc146  movaps xmm6, xmm9
0000796d027dc14a  mulpd xmm6, xmm1
0000796d027dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
0000796d027dc153  ptest xmm3, xmm3
0000796d027dc158  jnz 0x0000796D027DE555
0000796d027dc15e  movaps [r15+0x260], xmm6
0000796d027dc166  vxorps xmm1, xmm1, xmm1
0000796d027dc16a  vpbroadcastq xmm1, xmm1
0000796d027dc16f  movaps [r15+0x1B0], xmm1
0000796d027dc177  vmovaps xmm1, [rsp+0x60]
0000796d027dc17d  vpermilpd xmm1, xmm1, 0x00
0000796d027dc183  vmovaps xmm3, [rsp+0x70]
0000796d027dc189  vmovaps [rsp+0x70], xmm15
0000796d027dc18f  movaps xmm9, xmm3
0000796d027dc193  mulpd xmm9, xmm1
0000796d027dc198  vcmppd xmm15, xmm9, xmm9, 0x03
0000796d027dc19e  ptest xmm15, xmm15
0000796d027dc1a4  jnz 0x0000796D027DE696
0000796d027dc1aa  lea r12, [rax+0xC0]
0000796d027dc1b1  movups xmm1, [r13+r12*1]
0000796d027dc1b7  vmovaps xmm3, [rsp+0xC0]
0000796d027dc1c0  vmovaps [rsp+0x80], xmm1
0000796d027dc1c9  movaps xmm15, xmm3
0000796d027dc1cd  addpd xmm15, xmm7
0000796d027dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
0000796d027dc1d8  ptest xmm1, xmm1
0000796d027dc1dd  jnz 0x0000796D027DE7E2
0000796d027dc1e3  vmovaps [rsp+0xC0], xmm13
0000796d027dc1ec  vmovaps xmm1, [rsp+0xC0]
0000796d027dc1f5  por xmm13, xmm1
0000796d027dc1fa  movaps [r15+0x270], xmm13
0000796d027dc202  vmovaps xmm1, [rsp+0xB0]
0000796d027dc20b  vmovaps xmm7, [rsp+0xB0]
0000796d027dc214  por xmm1, xmm7
0000796d027dc218  movaps [r15+0x1A0], xmm1
0000796d027dc220  vmovaps xmm1, [rsp+0x60]
0000796d027dc226  vpermilpd xmm1, xmm1, 0x00
0000796d027dc22c  vmovaps [rsp+0xB0], xmm1
0000796d027dc235  vmovaps xmm1, [rsp+0x80]
0000796d027dc23e  vmovaps [rsp+0x80], xmm15
0000796d027dc247  vmovaps xmm15, [rsp+0xB0]
0000796d027dc250  vmovaps [rsp+0xB0], xmm14
0000796d027dc259  movaps xmm3, xmm1
0000796d027dc25c  mulpd xmm3, xmm15
0000796d027dc261  vcmppd xmm14, xmm3, xmm3, 0x03
0000796d027dc266  ptest xmm14, xmm14
0000796d027dc26c  jnz 0x0000796D027DE924
0000796d027dc272  lea r12, [rax+0x20]
0000796d027dc276  movups xmm1, [r13+r12*1]
0000796d027dc27c  movaps [r15+0x110], xmm1
0000796d027dc284  vmovaps xmm14, [rsp+0x70]
0000796d027dc28a  vmovaps [rsp+0x70], xmm1
0000796d027dc290  movaps xmm15, xmm14
0000796d027dc294  addpd xmm15, xmm4
0000796d027dc299  vcmppd xmm1, xmm15, xmm15, 0x03
0000796d027dc29f  ptest xmm1, xmm1
0000796d027dc2a4  jnz 0x0000796D027DEA6F
0000796d027dc2aa  vmovaps xmm1, [rsp+0x60]
0000796d027dc2b0  vpermilpd xmm1, xmm1, 0x00
0000796d027dc2b6  movaps xmm14, xmm2
0000796d027dc2ba  mulpd xmm14, xmm1
0000796d027dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
0000796d027dc2c5  ptest xmm4, xmm4
0000796d027dc2ca  jnz 0x0000796D027DEBB2
0000796d027dc2d0  vmovaps xmm4, [rsp+0x50]
0000796d027dc2d6  movaps xmm1, xmm4
0000796d027dc2d9  addpd xmm1, xmm9
0000796d027dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
0000796d027dc2e3  ptest xmm2, xmm2
0000796d027dc2e8  jnz 0x0000796D027DECF4
0000796d027dc2ee  vmovaps xmm9, [rsp+0x30]
0000796d027dc2f4  vpermilpd xmm9, xmm9, 0x00
0000796d027dc2fa  vmovaps xmm2, [rsp+0x70]
0000796d027dc300  vmovaps [rsp+0x50], xmm1
0000796d027dc306  movaps xmm4, xmm2
0000796d027dc309  mulpd xmm4, xmm9
0000796d027dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
0000796d027dc313  ptest xmm1, xmm1
0000796d027dc318  jnz 0x0000796D027DEE35
0000796d027dc31e  vmovaps xmm1, [rsp+0x30]
0000796d027dc324  vpermilpd xmm1, xmm1, 0x00
0000796d027dc32a  vmovaps xmm2, [rsp+0x90]
0000796d027dc333  vmovaps [rsp+0x60], xmm15
0000796d027dc339  movaps xmm9, xmm2
0000796d027dc33d  mulpd xmm9, xmm1
0000796d027dc342  vcmppd xmm15, xmm9, xmm9, 0x03
0000796d027dc348  ptest xmm15, xmm15
0000796d027dc34e  jnz 0x0000796D027DEF76
0000796d027dc354  vmovaps xmm15, [rsp+0x80]
0000796d027dc35d  movaps xmm1, xmm15
0000796d027dc361  addpd xmm1, xmm6
0000796d027dc365  vcmppd xmm2, xmm1, xmm1, 0x03
0000796d027dc36a  ptest xmm2, xmm2
0000796d027dc36f  jnz 0x0000796D027DF0B8
0000796d027dc375  movaps xmm15, xmm5
0000796d027dc379  addpd xmm15, xmm3
0000796d027dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
0000796d027dc384  ptest xmm6, xmm6
0000796d027dc389  jnz 0x0000796D027DF1F9
0000796d027dc38f  vmovaps xmm6, [rsp+0x30]
0000796d027dc395  vpermilpd xmm6, xmm6, 0x00
0000796d027dc39b  movaps xmm5, xmm8
0000796d027dc39f  mulpd xmm5, xmm6
0000796d027dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
0000796d027dc3a8  ptest xmm3, xmm3
0000796d027dc3ad  jnz 0x0000796D027DF33B
0000796d027dc3b3  vmovaps xmm8, [rsp+0x30]
0000796d027dc3b9  vpermilpd xmm8, xmm8, 0x00
0000796d027dc3bf  movaps xmm6, xmm10
0000796d027dc3c3  mulpd xmm6, xmm8
0000796d027dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
0000796d027dc3cd  ptest xmm3, xmm3
0000796d027dc3d2  jnz 0x0000796D027DF47C
0000796d027dc3d8  vmovaps xmm8, [rsp+0x60]
0000796d027dc3de  movaps xmm10, xmm8
0000796d027dc3e2  addpd xmm10, xmm14
0000796d027dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
0000796d027dc3ed  ptest xmm3, xmm3
0000796d027dc3f2  jnz 0x0000796D027DF5BE
0000796d027dc3f8  vmovaps xmm8, [rsp+0x50]
0000796d027dc3fe  movaps xmm14, xmm8
0000796d027dc402  addpd xmm14, xmm4
0000796d027dc407  vcmppd xmm3, xmm14, xmm14, 0x03
0000796d027dc40d  ptest xmm3, xmm3
0000796d027dc412  jnz 0x0000796D027DF702
0000796d027dc418  vmovaps xmm8, [rsp+0x40]
0000796d027dc41e  vpermilpd xmm8, xmm8, 0x00
0000796d027dc424  movaps xmm4, xmm13
0000796d027dc428  mulpd xmm4, xmm8
0000796d027dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
0000796d027dc432  ptest xmm3, xmm3
0000796d027dc437  jnz 0x0000796D027DF845
0000796d027dc43d  movaps xmm13, xmm15
0000796d027dc441  addpd xmm13, xmm9
0000796d027dc446  vcmppd xmm8, xmm13, xmm13, 0x03
0000796d027dc44c  ptest xmm8, xmm8
0000796d027dc452  jnz 0x0000796D027DF987
0000796d027dc458  movaps xmm15, xmm1
0000796d027dc45c  addpd xmm15, xmm5
0000796d027dc461  vcmppd xmm9, xmm15, xmm15, 0x03
0000796d027dc467  ptest xmm9, xmm9
0000796d027dc46d  jnz 0x0000796D027DFACB
0000796d027dc473  vmovaps [rsp+0x30], xmm11
0000796d027dc479  vmovaps xmm1, [rsp+0x30]
0000796d027dc47f  por xmm11, xmm1
0000796d027dc484  movaps [r15+0x250], xmm11
0000796d027dc48c  vmovaps [rsp+0x30], xmm12
0000796d027dc492  vmovaps xmm1, [rsp+0x30]
0000796d027dc498  por xmm12, xmm1
0000796d027dc49d  movaps [r15+0x2A0], xmm12
0000796d027dc4a5  vmovaps xmm1, [rsp+0xA0]
0000796d027dc4ae  vmovaps xmm11, [rsp+0xA0]
0000796d027dc4b7  por xmm1, xmm11
0000796d027dc4bc  movaps [r15+0x1D0], xmm1
0000796d027dc4c4  lea r12, [rax+0x40]
0000796d027dc4c8  movups xmm1, [r13+r12*1]
0000796d027dc4ce  movaps [r15+0x2C0], xmm1
0000796d027dc4d6  vmovaps xmm11, [rsp+0x40]
0000796d027dc4dc  vpermilpd xmm11, xmm11, 0x00
0000796d027dc4e2  vmovaps xmm8, [rsp+0xE0]
0000796d027dc4eb  movaps xmm9, xmm8
0000796d027dc4ef  mulpd xmm9, xmm11
0000796d027dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
0000796d027dc4fa  ptest xmm5, xmm5
0000796d027dc4ff  jnz 0x0000796D027DFC17
0000796d027dc505  movaps xmm11, xmm10
0000796d027dc509  addpd xmm11, xmm6
0000796d027dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
0000796d027dc514  ptest xmm8, xmm8
0000796d027dc51a  jnz 0x0000796D027DFD5B
0000796d027dc520  movaps xmm10, xmm14
0000796d027dc524  addpd xmm10, xmm4
0000796d027dc529  vcmppd xmm8, xmm10, xmm10, 0x03
0000796d027dc52f  ptest xmm8, xmm8
0000796d027dc535  jnz 0x0000796D027DFE9E
0000796d027dc53b  vmovaps xmm14, [rsp+0x40]
0000796d027dc541  vpermilpd xmm14, xmm14, 0x00
0000796d027dc547  movaps xmm8, xmm1
0000796d027dc54b  mulpd xmm8, xmm14
0000796d027dc550  vcmppd xmm6, xmm8, xmm8, 0x03
0000796d027dc556  ptest xmm6, xmm6
0000796d027dc55b  jnz 0x0000796D027DFFE1
0000796d027dc561  movaps xmm1, [r15+0x2B0]
0000796d027dc569  vmovaps xmm14, [rsp+0x40]
0000796d027dc56f  vpermilpd xmm14, xmm14, 0x00
0000796d027dc575  movaps xmm6, xmm1
0000796d027dc578  mulpd xmm6, xmm14
0000796d027dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
0000796d027dc582  ptest xmm5, xmm5
0000796d027dc587  jnz 0x0000796D027E0124
0000796d027dc58d  vmovaps xmm1, [rsp+0x10]
0000796d027dc593  vpermilpd xmm1, xmm1, 0x00
0000796d027dc599  movaps xmm14, xmm12
0000796d027dc59d  mulpd xmm14, xmm1
0000796d027dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
0000796d027dc5a8  ptest xmm5, xmm5
0000796d027dc5ad  jnz 0x0000796D027E0265
0000796d027dc5b3  movaps xmm1, xmm13
0000796d027dc5b7  addpd xmm1, xmm9
0000796d027dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
0000796d027dc5c1  ptest xmm12, xmm12
0000796d027dc5c7  jnz 0x0000796D027E03A8
0000796d027dc5cd  vmovaps xmm13, [rsp+0x10]
0000796d027dc5d3  vpermilpd xmm13, xmm13, 0x00
0000796d027dc5d9  movaps xmm12, xmm7
0000796d027dc5dd  mulpd xmm12, xmm13
0000796d027dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
0000796d027dc5e8  ptest xmm9, xmm9
0000796d027dc5ee  jnz 0x0000796D027E04EA
0000796d027dc5f4  movaps xmm13, xmm15
0000796d027dc5f8  addpd xmm13, xmm8
0000796d027dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
0000796d027dc603  ptest xmm9, xmm9
0000796d027dc609  jnz 0x0000796D027E062D
0000796d027dc60f  movaps xmm15, [r15+0x290]
0000796d027dc617  vmovaps xmm9, [rsp+0x10]
0000796d027dc61d  vpermilpd xmm9, xmm9, 0x00
0000796d027dc623  movaps xmm8, xmm15
0000796d027dc627  mulpd xmm8, xmm9
0000796d027dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
0000796d027dc632  ptest xmm7, xmm7
0000796d027dc637  jnz 0x0000796D027E0771
0000796d027dc63d  movaps xmm15, xmm11
0000796d027dc641  addpd xmm15, xmm6
0000796d027dc646  vcmppd xmm9, xmm15, xmm15, 0x03
0000796d027dc64c  ptest xmm9, xmm9
0000796d027dc652  jnz 0x0000796D027E08B5
0000796d027dc658  movaps xmm11, [r15+0x1E0]
0000796d027dc660  vmovaps xmm9, [rsp+0x10]
0000796d027dc666  vpermilpd xmm9, xmm9, 0x00
0000796d027dc66c  movaps xmm7, xmm11
0000796d027dc670  mulpd xmm7, xmm9
0000796d027dc675  vcmppd xmm6, xmm7, xmm7, 0x03
0000796d027dc67a  ptest xmm6, xmm6
0000796d027dc67f  jnz 0x0000796D027E09F8
0000796d027dc685  movaps xmm11, xmm10
0000796d027dc689  addpd xmm11, xmm14
0000796d027dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
0000796d027dc694  ptest xmm9, xmm9
0000796d027dc69a  jnz 0x0000796D027E0B3A
0000796d027dc6a0  lea r12, [rax+0x70]
0000796d027dc6a4  movups xmm14, [r13+r12*1]
0000796d027dc6aa  movaps [r15+0x240], xmm14
0000796d027dc6b2  movaps xmm10, xmm1
0000796d027dc6b6  addpd xmm10, xmm12
0000796d027dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
0000796d027dc6c1  ptest xmm9, xmm9
0000796d027dc6c7  jnz 0x0000796D027E0C88
0000796d027dc6cd  movaps [r15+0x170], xmm10
0000796d027dc6d5  vmovaps xmm1, [rsp+0x20]
0000796d027dc6db  vpermilpd xmm1, xmm1, 0x00
0000796d027dc6e1  movaps xmm12, xmm14
0000796d027dc6e5  mulpd xmm12, xmm1
0000796d027dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
0000796d027dc6f0  ptest xmm9, xmm9
0000796d027dc6f6  jnz 0x0000796D027E0DCB
0000796d027dc6fc  vmovaps xmm1, [rsp+0x20]
0000796d027dc702  vpermilpd xmm1, xmm1, 0x00
0000796d027dc708  vmovaps xmm9, [rsp+0xB0]
0000796d027dc711  movaps xmm14, xmm9
0000796d027dc715  mulpd xmm14, xmm1
0000796d027dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
0000796d027dc720  ptest xmm6, xmm6
0000796d027dc725  jnz 0x0000796D027E0F0E
0000796d027dc72b  movaps [r15+0x180], xmm14
0000796d027dc733  movaps xmm1, xmm13
0000796d027dc737  addpd xmm1, xmm8
0000796d027dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
0000796d027dc741  ptest xmm9, xmm9
0000796d027dc747  jnz 0x0000796D027E1051
0000796d027dc74d  movaps [r15+0x210], xmm1
0000796d027dc755  movups xmm13, [r13+rax*1]
0000796d027dc75b  lea r12, [rax+0x10]
0000796d027dc75f  movups xmm9, [r13+r12*1]
0000796d027dc765  movaps [r15+0x230], xmm9
0000796d027dc76d  movaps xmm8, xmm15
0000796d027dc771  addpd xmm8, xmm7
0000796d027dc776  vcmppd xmm6, xmm8, xmm8, 0x03
0000796d027dc77c  ptest xmm6, xmm6
0000796d027dc781  jnz 0x0000796D027E11A7
0000796d027dc787  movaps [r15+0x130], xmm8
0000796d027dc78f  vmovaps xmm15, [rsp+0x20]
0000796d027dc795  vpermilpd xmm15, xmm15, 0x00
0000796d027dc79b  movaps xmm7, xmm9
0000796d027dc79f  mulpd xmm7, xmm15
0000796d027dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
0000796d027dc7a9  ptest xmm6, xmm6
0000796d027dc7ae  jnz 0x0000796D027E12EA
0000796d027dc7b4  movaps [r15+0x220], xmm7
0000796d027dc7bc  vmovaps xmm15, [rsp+0x20]
0000796d027dc7c2  vpermilpd xmm15, xmm15, 0x00
0000796d027dc7c8  movaps xmm9, xmm13
0000796d027dc7cc  mulpd xmm9, xmm15
0000796d027dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
0000796d027dc7d7  ptest xmm6, xmm6
0000796d027dc7dc  jnz 0x0000796D027E142C
0000796d027dc7e2  movaps xmm15, xmm11
0000796d027dc7e6  addpd xmm15, xmm12
0000796d027dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
0000796d027dc7f1  ptest xmm13, xmm13
0000796d027dc7f7  jnz 0x0000796D027E1570
0000796d027dc7fd  movaps [r15+0x140], xmm15
0000796d027dc805  movaps xmm13, xmm10
0000796d027dc809  addpd xmm13, xmm14
0000796d027dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
0000796d027dc814  ptest xmm12, xmm12
0000796d027dc81a  jnz 0x0000796D027E16B4
0000796d027dc820  movaps [r15+0x150], xmm13
0000796d027dc828  movaps xmm14, xmm1
0000796d027dc82c  addpd xmm14, xmm7
0000796d027dc831  vcmppd xmm12, xmm14, xmm14, 0x03
0000796d027dc837  ptest xmm12, xmm12
0000796d027dc83d  jnz 0x0000796D027E17F8
0000796d027dc843  movaps [r15+0x160], xmm14
0000796d027dc84b  movaps xmm1, xmm8
0000796d027dc84f  addpd xmm1, xmm9
0000796d027dc854  vcmppd xmm12, xmm1, xmm1, 0x03
0000796d027dc859  ptest xmm12, xmm12
0000796d027dc85f  jnz 0x0000796D027E193A
0000796d027dc865  movaps [r15+0x120], xmm1
0000796d027dc86d  movups [r13+r14*1], xmm15
0000796d027dc873  lea rax, [r14+0x10]
0000796d027dc877  movups [r13+rax*1], xmm13
0000796d027dc87d  lea rax, [r14+0x20]
0000796d027dc881  movups [r13+rax*1], xmm14
0000796d027dc887  lea rax, [r14+0x30]
0000796d027dc88b  movups [r13+rax*1], xmm1
0000796d027dc891  mov eax, [r15+0x108]
0000796d027dc898  sahf
0000796d027dc899  jnz 0x0000796D027DC8CB
0000796d027dc89b  cmp dword ptr [r15+0x318], 0x00
0000796d027dc8a3  jz 0x0000796D027DB900
0000796d027dc8a9  nop [rax+rax*1], ax
0000796d027dc8b2  nop [rax+rax*1], eax
0000796d027dc8ba  mov eax, 0x410444
0000796d027dc8bf  mov [r15+0x100], rax
0000796d027dc8c6  jmp 0x0000796D025FE110
0000796d027dc8cb  cmp dword ptr [r15+0x318], 0x00
0000796d027dc8d3  jz 0x0000796D027D57E0
0000796d027dc8d9  nop [rax+rax*1], ax
0000796d027dc8e2  nop [rax+rax*1], eax
0000796d027dc8ea  mov eax, 0x410278
0000796d027dc8ef  mov [r15+0x100], rax
0000796d027dc8f6  jmp 0x0000796D025FE110
0000796d027dc8fb  int3
0000796d027dc8fc  call 0x0000796D026E27E0
0000796d027dc901  jmp 0x0000796D027DB9DF
0000796d027dc906  call 0x0000796D026E1570
0000796d027dc90b  jmp 0x0000796D027DB9E8
0000796d027dc910  call 0x0000796D026E27E0
0000796d027dc915  jmp 0x0000796D027DBA44
0000796d027dc91a  call 0x0000796D026E1570
0000796d027dc91f  jmp 0x0000796D027DBA4D
0000796d027dc924  call 0x0000796D026E27E0
0000796d027dc929  jmp 0x0000796D027DBA90
0000796d027dc92e  call 0x0000796D026E1570
0000796d027dc933  jmp 0x0000796D027DBA99
0000796d027dc938  call 0x0000796D0260DC20
0000796d027dc93d  jmp 0x0000796D027DBAD8
0000796d027dc942  call 0x0000796D026D59C0
0000796d027dc947  jmp 0x0000796D027DBAEB
0000796d027dc94c  call 0x0000796D026E0E30
0000796d027dc951  jmp 0x0000796D027DBB09
0000796d027dc956  call 0x0000796D026DFBC0
0000796d027dc95b  jmp 0x0000796D027DBB13
0000796d027dc960  call 0x0000796D026DE950
0000796d027dc965  jmp 0x0000796D027DBB1D
0000796d027dc96a  sub rsp, 0x08
0000796d027dc96e  push rax
0000796d027dc96f  push rcx
0000796d027dc970  push rdx
0000796d027dc971  push rdi
0000796d027dc972  push rsi
0000796d027dc973  push r8
0000796d027dc975  push r9
0000796d027dc977  push r10
0000796d027dc979  push r11
0000796d027dc97b  sub rsp, 0xF0
0000796d027dc982  vmovaps [rsp], xmm0
0000796d027dc987  vmovaps [rsp+0x10], xmm1
0000796d027dc98d  vmovaps [rsp+0x20], xmm2
0000796d027dc993  vmovaps [rsp+0x30], xmm3
0000796d027dc999  vmovaps [rsp+0x40], xmm4
0000796d027dc99f  vmovaps [rsp+0x50], xmm5
0000796d027dc9a5  vmovaps [rsp+0x60], xmm6
0000796d027dc9ab  vmovaps [rsp+0x70], xmm7
0000796d027dc9b1  vmovaps [rsp+0x80], xmm9
0000796d027dc9ba  vmovaps [rsp+0x90], xmm10
0000796d027dc9c3  vmovaps [rsp+0xA0], xmm11
0000796d027dc9cc  vmovaps [rsp+0xB0], xmm12
0000796d027dc9d5  vmovaps [rsp+0xC0], xmm13
0000796d027dc9de  vmovaps [rsp+0xD0], xmm14
0000796d027dc9e7  vmovaps [rsp+0xE0], xmm15
0000796d027dc9f0  sub rsp, 0x30
0000796d027dc9f4  movaps [rsp], xmm8
0000796d027dc9f9  movaps [rsp+0x10], xmm12
0000796d027dc9ff  movaps [rsp+0x20], xmm15
0000796d027dca05  lea rdi, [rsp]
0000796d027dca09  mov esi, 0x00
0000796d027dca0e  mov rax, 0x635FBE957530
0000796d027dca18  call rax
0000796d027dca1a  movaps xmm8, [rsp]
0000796d027dca1f  add rsp, 0x30
0000796d027dca23  vmovaps xmm0, [rsp]
0000796d027dca28  vmovaps xmm1, [rsp+0x10]
0000796d027dca2e  vmovaps xmm2, [rsp+0x20]
0000796d027dca34  vmovaps xmm3, [rsp+0x30]
0000796d027dca3a  vmovaps xmm4, [rsp+0x40]
0000796d027dca40  vmovaps xmm5, [rsp+0x50]
0000796d027dca46  vmovaps xmm6, [rsp+0x60]
0000796d027dca4c  vmovaps xmm7, [rsp+0x70]
0000796d027dca52  vmovaps xmm9, [rsp+0x80]
0000796d027dca5b  vmovaps xmm10, [rsp+0x90]
0000796d027dca64  vmovaps xmm11, [rsp+0xA0]
0000796d027dca6d  vmovaps xmm12, [rsp+0xB0]
0000796d027dca76  vmovaps xmm13, [rsp+0xC0]
0000796d027dca7f  vmovaps xmm14, [rsp+0xD0]
0000796d027dca88  vmovaps xmm15, [rsp+0xE0]
0000796d027dca91  add rsp, 0xF0
0000796d027dca98  pop r11
0000796d027dca9a  pop r10
0000796d027dca9c  pop r9
0000796d027dca9e  pop r8
0000796d027dcaa0  pop rsi
0000796d027dcaa1  pop rdi
0000796d027dcaa2  pop rdx
0000796d027dcaa3  pop rcx
0000796d027dcaa4  pop rax
0000796d027dcaa5  add rsp, 0x08
0000796d027dcaa9  jmp 0x0000796D027DBB47
0000796d027dcaae  sub rsp, 0x08
0000796d027dcab2  push rax
0000796d027dcab3  push rcx
0000796d027dcab4  push rdx
0000796d027dcab5  push rdi
0000796d027dcab6  push rsi
0000796d027dcab7  push r8
0000796d027dcab9  push r9
0000796d027dcabb  push r10
0000796d027dcabd  push r11
0000796d027dcabf  sub rsp, 0xF0
0000796d027dcac6  vmovaps [rsp], xmm0
0000796d027dcacb  vmovaps [rsp+0x10], xmm1
0000796d027dcad1  vmovaps [rsp+0x20], xmm2
0000796d027dcad7  vmovaps [rsp+0x30], xmm3
0000796d027dcadd  vmovaps [rsp+0x40], xmm4
0000796d027dcae3  vmovaps [rsp+0x50], xmm5
0000796d027dcae9  vmovaps [rsp+0x60], xmm6
0000796d027dcaef  vmovaps [rsp+0x70], xmm8
0000796d027dcaf5  vmovaps [rsp+0x80], xmm9
0000796d027dcafe  vmovaps [rsp+0x90], xmm10
0000796d027dcb07  vmovaps [rsp+0xA0], xmm11
0000796d027dcb10  vmovaps [rsp+0xB0], xmm12
0000796d027dcb19  vmovaps [rsp+0xC0], xmm13
0000796d027dcb22  vmovaps [rsp+0xD0], xmm14
0000796d027dcb2b  vmovaps [rsp+0xE0], xmm15
0000796d027dcb34  sub rsp, 0x30
0000796d027dcb38  movaps [rsp], xmm7
0000796d027dcb3c  movaps [rsp+0x10], xmm9
0000796d027dcb42  movaps [rsp+0x20], xmm15
0000796d027dcb48  lea rdi, [rsp]
0000796d027dcb4c  mov esi, 0x00
0000796d027dcb51  mov rax, 0x635FBE957530
0000796d027dcb5b  call rax
0000796d027dcb5d  movaps xmm7, [rsp]
0000796d027dcb61  add rsp, 0x30
0000796d027dcb65  vmovaps xmm0, [rsp]
0000796d027dcb6a  vmovaps xmm1, [rsp+0x10]
0000796d027dcb70  vmovaps xmm2, [rsp+0x20]
0000796d027dcb76  vmovaps xmm3, [rsp+0x30]
0000796d027dcb7c  vmovaps xmm4, [rsp+0x40]
0000796d027dcb82  vmovaps xmm5, [rsp+0x50]
0000796d027dcb88  vmovaps xmm6, [rsp+0x60]
0000796d027dcb8e  vmovaps xmm8, [rsp+0x70]
0000796d027dcb94  vmovaps xmm9, [rsp+0x80]
0000796d027dcb9d  vmovaps xmm10, [rsp+0x90]
0000796d027dcba6  vmovaps xmm11, [rsp+0xA0]
0000796d027dcbaf  vmovaps xmm12, [rsp+0xB0]
0000796d027dcbb8  vmovaps xmm13, [rsp+0xC0]
0000796d027dcbc1  vmovaps xmm14, [rsp+0xD0]
0000796d027dcbca  vmovaps xmm15, [rsp+0xE0]
0000796d027dcbd3  add rsp, 0xF0
0000796d027dcbda  pop r11
0000796d027dcbdc  pop r10
0000796d027dcbde  pop r9
0000796d027dcbe0  pop r8
0000796d027dcbe2  pop rsi
0000796d027dcbe3  pop rdi
0000796d027dcbe4  pop rdx
0000796d027dcbe5  pop rcx
0000796d027dcbe6  pop rax
0000796d027dcbe7  add rsp, 0x08
0000796d027dcbeb  jmp 0x0000796D027DBB75
0000796d027dcbf0  sub rsp, 0x08
0000796d027dcbf4  push rax
0000796d027dcbf5  push rcx
0000796d027dcbf6  push rdx
0000796d027dcbf7  push rdi
0000796d027dcbf8  push rsi
0000796d027dcbf9  push r8
0000796d027dcbfb  push r9
0000796d027dcbfd  push r10
0000796d027dcbff  push r11
0000796d027dcc01  sub rsp, 0xF0
0000796d027dcc08  vmovaps [rsp], xmm0
0000796d027dcc0d  vmovaps [rsp+0x10], xmm1
0000796d027dcc13  vmovaps [rsp+0x20], xmm2
0000796d027dcc19  vmovaps [rsp+0x30], xmm3
0000796d027dcc1f  vmovaps [rsp+0x40], xmm4
0000796d027dcc25  vmovaps [rsp+0x50], xmm5
0000796d027dcc2b  vmovaps [rsp+0x60], xmm6
0000796d027dcc31  vmovaps [rsp+0x70], xmm7
0000796d027dcc37  vmovaps [rsp+0x80], xmm8
0000796d027dcc40  vmovaps [rsp+0x90], xmm10
0000796d027dcc49  vmovaps [rsp+0xA0], xmm11
0000796d027dcc52  vmovaps [rsp+0xB0], xmm12
0000796d027dcc5b  vmovaps [rsp+0xC0], xmm13
0000796d027dcc64  vmovaps [rsp+0xD0], xmm14
0000796d027dcc6d  vmovaps [rsp+0xE0], xmm15
0000796d027dcc76  sub rsp, 0x30
0000796d027dcc7a  movaps [rsp], xmm9
0000796d027dcc7f  movaps [rsp+0x10], xmm12
0000796d027dcc85  movaps [rsp+0x20], xmm10
0000796d027dcc8b  lea rdi, [rsp]
0000796d027dcc8f  mov esi, 0x00
0000796d027dcc94  mov rax, 0x635FBE957530
0000796d027dcc9e  call rax
0000796d027dcca0  movaps xmm9, [rsp]
0000796d027dcca5  add rsp, 0x30
0000796d027dcca9  vmovaps xmm0, [rsp]
0000796d027dccae  vmovaps xmm1, [rsp+0x10]
0000796d027dccb4  vmovaps xmm2, [rsp+0x20]
0000796d027dccba  vmovaps xmm3, [rsp+0x30]
0000796d027dccc0  vmovaps xmm4, [rsp+0x40]
0000796d027dccc6  vmovaps xmm5, [rsp+0x50]
0000796d027dcccc  vmovaps xmm6, [rsp+0x60]
0000796d027dccd2  vmovaps xmm7, [rsp+0x70]
0000796d027dccd8  vmovaps xmm8, [rsp+0x80]
0000796d027dcce1  vmovaps xmm10, [rsp+0x90]
0000796d027dccea  vmovaps xmm11, [rsp+0xA0]
0000796d027dccf3  vmovaps xmm12, [rsp+0xB0]
0000796d027dccfc  vmovaps xmm13, [rsp+0xC0]
0000796d027dcd05  vmovaps xmm14, [rsp+0xD0]
0000796d027dcd0e  vmovaps xmm15, [rsp+0xE0]
0000796d027dcd17  add rsp, 0xF0
0000796d027dcd1e  pop r11
0000796d027dcd20  pop r10
0000796d027dcd22  pop r9
0000796d027dcd24  pop r8
0000796d027dcd26  pop rsi
0000796d027dcd27  pop rdi
0000796d027dcd28  pop rdx
0000796d027dcd29  pop rcx
0000796d027dcd2a  pop rax
0000796d027dcd2b  add rsp, 0x08
0000796d027dcd2f  jmp 0x0000796D027DBB99
0000796d027dcd34  sub rsp, 0x08
0000796d027dcd38  push rax
0000796d027dcd39  push rcx
0000796d027dcd3a  push rdx
0000796d027dcd3b  push rdi
0000796d027dcd3c  push rsi
0000796d027dcd3d  push r8
0000796d027dcd3f  push r9
0000796d027dcd41  push r10
0000796d027dcd43  push r11
0000796d027dcd45  sub rsp, 0xF0
0000796d027dcd4c  vmovaps [rsp], xmm0
0000796d027dcd51  vmovaps [rsp+0x10], xmm1
0000796d027dcd57  vmovaps [rsp+0x20], xmm2
0000796d027dcd5d  vmovaps [rsp+0x30], xmm3
0000796d027dcd63  vmovaps [rsp+0x40], xmm4
0000796d027dcd69  vmovaps [rsp+0x50], xmm5
0000796d027dcd6f  vmovaps [rsp+0x60], xmm6
0000796d027dcd75  vmovaps [rsp+0x70], xmm7
0000796d027dcd7b  vmovaps [rsp+0x80], xmm8
0000796d027dcd84  vmovaps [rsp+0x90], xmm9
0000796d027dcd8d  vmovaps [rsp+0xA0], xmm11
0000796d027dcd96  vmovaps [rsp+0xB0], xmm12
0000796d027dcd9f  vmovaps [rsp+0xC0], xmm13
0000796d027dcda8  vmovaps [rsp+0xD0], xmm14
0000796d027dcdb1  vmovaps [rsp+0xE0], xmm15
0000796d027dcdba  sub rsp, 0x30
0000796d027dcdbe  movaps [rsp], xmm10
0000796d027dcdc3  movaps [rsp+0x10], xmm12
0000796d027dcdc9  movaps [rsp+0x20], xmm11
0000796d027dcdcf  lea rdi, [rsp]
0000796d027dcdd3  mov esi, 0x00
0000796d027dcdd8  mov rax, 0x635FBE957530
0000796d027dcde2  call rax
0000796d027dcde4  movaps xmm10, [rsp]
0000796d027dcde9  add rsp, 0x30
0000796d027dcded  vmovaps xmm0, [rsp]
0000796d027dcdf2  vmovaps xmm1, [rsp+0x10]
0000796d027dcdf8  vmovaps xmm2, [rsp+0x20]
0000796d027dcdfe  vmovaps xmm3, [rsp+0x30]
0000796d027dce04  vmovaps xmm4, [rsp+0x40]
0000796d027dce0a  vmovaps xmm5, [rsp+0x50]
0000796d027dce10  vmovaps xmm6, [rsp+0x60]
0000796d027dce16  vmovaps xmm7, [rsp+0x70]
0000796d027dce1c  vmovaps xmm8, [rsp+0x80]
0000796d027dce25  vmovaps xmm9, [rsp+0x90]
0000796d027dce2e  vmovaps xmm11, [rsp+0xA0]
0000796d027dce37  vmovaps xmm12, [rsp+0xB0]
0000796d027dce40  vmovaps xmm13, [rsp+0xC0]
0000796d027dce49  vmovaps xmm14, [rsp+0xD0]
0000796d027dce52  vmovaps xmm15, [rsp+0xE0]
0000796d027dce5b  add rsp, 0xF0
0000796d027dce62  pop r11
0000796d027dce64  pop r10
0000796d027dce66  pop r9
0000796d027dce68  pop r8
0000796d027dce6a  pop rsi
0000796d027dce6b  pop rdi
0000796d027dce6c  pop rdx
0000796d027dce6d  pop rcx
0000796d027dce6e  pop rax
0000796d027dce6f  add rsp, 0x08
0000796d027dce73  jmp 0x0000796D027DBBB3
0000796d027dce78  sub rsp, 0x08
0000796d027dce7c  push rax
0000796d027dce7d  push rcx
0000796d027dce7e  push rdx
0000796d027dce7f  push rdi
0000796d027dce80  push rsi
0000796d027dce81  push r8
0000796d027dce83  push r9
0000796d027dce85  push r10
0000796d027dce87  push r11
0000796d027dce89  sub rsp, 0xF0
0000796d027dce90  vmovaps [rsp], xmm0
0000796d027dce95  vmovaps [rsp+0x10], xmm1
0000796d027dce9b  vmovaps [rsp+0x20], xmm2
0000796d027dcea1  vmovaps [rsp+0x30], xmm3
0000796d027dcea7  vmovaps [rsp+0x40], xmm4
0000796d027dcead  vmovaps [rsp+0x50], xmm5
0000796d027dceb3  vmovaps [rsp+0x60], xmm7
0000796d027dceb9  vmovaps [rsp+0x70], xmm8
0000796d027dcebf  vmovaps [rsp+0x80], xmm9
0000796d027dcec8  vmovaps [rsp+0x90], xmm10
0000796d027dced1  vmovaps [rsp+0xA0], xmm11
0000796d027dceda  vmovaps [rsp+0xB0], xmm12
0000796d027dcee3  vmovaps [rsp+0xC0], xmm13
0000796d027dceec  vmovaps [rsp+0xD0], xmm14
0000796d027dcef5  vmovaps [rsp+0xE0], xmm15
0000796d027dcefe  sub rsp, 0x30
0000796d027dcf02  movaps [rsp], xmm6
0000796d027dcf06  movaps [rsp+0x10], xmm12
0000796d027dcf0c  movaps [rsp+0x20], xmm11
0000796d027dcf12  lea rdi, [rsp]
0000796d027dcf16  mov esi, 0x00
0000796d027dcf1b  mov rax, 0x635FBE957530
0000796d027dcf25  call rax
0000796d027dcf27  movaps xmm6, [rsp]
0000796d027dcf2b  add rsp, 0x30
0000796d027dcf2f  vmovaps xmm0, [rsp]
0000796d027dcf34  vmovaps xmm1, [rsp+0x10]
0000796d027dcf3a  vmovaps xmm2, [rsp+0x20]
0000796d027dcf40  vmovaps xmm3, [rsp+0x30]
0000796d027dcf46  vmovaps xmm4, [rsp+0x40]
0000796d027dcf4c  vmovaps xmm5, [rsp+0x50]
0000796d027dcf52  vmovaps xmm7, [rsp+0x60]
0000796d027dcf58  vmovaps xmm8, [rsp+0x70]
0000796d027dcf5e  vmovaps xmm9, [rsp+0x80]
0000796d027dcf67  vmovaps xmm10, [rsp+0x90]
0000796d027dcf70  vmovaps xmm11, [rsp+0xA0]
0000796d027dcf79  vmovaps xmm12, [rsp+0xB0]
0000796d027dcf82  vmovaps xmm13, [rsp+0xC0]
0000796d027dcf8b  vmovaps xmm14, [rsp+0xD0]
0000796d027dcf94  vmovaps xmm15, [rsp+0xE0]
0000796d027dcf9d  add rsp, 0xF0
0000796d027dcfa4  pop r11
0000796d027dcfa6  pop r10
0000796d027dcfa8  pop r9
0000796d027dcfaa  pop r8
0000796d027dcfac  pop rsi
0000796d027dcfad  pop rdi
0000796d027dcfae  pop rdx
0000796d027dcfaf  pop rcx
0000796d027dcfb0  pop rax
0000796d027dcfb1  add rsp, 0x08
0000796d027dcfb5  jmp 0x0000796D027DBBD4
0000796d027dcfba  sub rsp, 0x08
0000796d027dcfbe  push rax
0000796d027dcfbf  push rcx
0000796d027dcfc0  push rdx
0000796d027dcfc1  push rdi
0000796d027dcfc2  push rsi
0000796d027dcfc3  push r8
0000796d027dcfc5  push r9
0000796d027dcfc7  push r10
0000796d027dcfc9  push r11
0000796d027dcfcb  sub rsp, 0xF0
0000796d027dcfd2  vmovaps [rsp], xmm0
0000796d027dcfd7  vmovaps [rsp+0x10], xmm1
0000796d027dcfdd  vmovaps [rsp+0x20], xmm2
0000796d027dcfe3  vmovaps [rsp+0x30], xmm4
0000796d027dcfe9  vmovaps [rsp+0x40], xmm5
0000796d027dcfef  vmovaps [rsp+0x50], xmm6
0000796d027dcff5  vmovaps [rsp+0x60], xmm7
0000796d027dcffb  vmovaps [rsp+0x70], xmm8
0000796d027dd001  vmovaps [rsp+0x80], xmm9
0000796d027dd00a  vmovaps [rsp+0x90], xmm10
0000796d027dd013  vmovaps [rsp+0xA0], xmm11
0000796d027dd01c  vmovaps [rsp+0xB0], xmm12
0000796d027dd025  vmovaps [rsp+0xC0], xmm13
0000796d027dd02e  vmovaps [rsp+0xD0], xmm14
0000796d027dd037  vmovaps [rsp+0xE0], xmm15
0000796d027dd040  sub rsp, 0x30
0000796d027dd044  movaps [rsp], xmm3
0000796d027dd048  movaps [rsp+0x10], xmm5
0000796d027dd04d  movaps [rsp+0x20], xmm4
0000796d027dd052  lea rdi, [rsp]
0000796d027dd056  mov esi, 0x00
0000796d027dd05b  mov rax, 0x635FBE957530
0000796d027dd065  call rax
0000796d027dd067  movaps xmm3, [rsp]
0000796d027dd06b  add rsp, 0x30
0000796d027dd06f  vmovaps xmm0, [rsp]
0000796d027dd074  vmovaps xmm1, [rsp+0x10]
0000796d027dd07a  vmovaps xmm2, [rsp+0x20]
0000796d027dd080  vmovaps xmm4, [rsp+0x30]
0000796d027dd086  vmovaps xmm5, [rsp+0x40]
0000796d027dd08c  vmovaps xmm6, [rsp+0x50]
0000796d027dd092  vmovaps xmm7, [rsp+0x60]
0000796d027dd098  vmovaps xmm8, [rsp+0x70]
0000796d027dd09e  vmovaps xmm9, [rsp+0x80]
0000796d027dd0a7  vmovaps xmm10, [rsp+0x90]
0000796d027dd0b0  vmovaps xmm11, [rsp+0xA0]
0000796d027dd0b9  vmovaps xmm12, [rsp+0xB0]
0000796d027dd0c2  vmovaps xmm13, [rsp+0xC0]
0000796d027dd0cb  vmovaps xmm14, [rsp+0xD0]
0000796d027dd0d4  vmovaps xmm15, [rsp+0xE0]
0000796d027dd0dd  add rsp, 0xF0
0000796d027dd0e4  pop r11
0000796d027dd0e6  pop r10
0000796d027dd0e8  pop r9
0000796d027dd0ea  pop r8
0000796d027dd0ec  pop rsi
0000796d027dd0ed  pop rdi
0000796d027dd0ee  pop rdx
0000796d027dd0ef  pop rcx
0000796d027dd0f0  pop rax
0000796d027dd0f1  add rsp, 0x08
0000796d027dd0f5  jmp 0x0000796D027DBC35
0000796d027dd0fa  sub rsp, 0x08
0000796d027dd0fe  push rax
0000796d027dd0ff  push rcx
0000796d027dd100  push rdx
0000796d027dd101  push rdi
0000796d027dd102  push rsi
0000796d027dd103  push r8
0000796d027dd105  push r9
0000796d027dd107  push r10
0000796d027dd109  push r11
0000796d027dd10b  sub rsp, 0xF0
0000796d027dd112  vmovaps [rsp], xmm0
0000796d027dd117  vmovaps [rsp+0x10], xmm1
0000796d027dd11d  vmovaps [rsp+0x20], xmm2
0000796d027dd123  vmovaps [rsp+0x30], xmm3
0000796d027dd129  vmovaps [rsp+0x40], xmm4
0000796d027dd12f  vmovaps [rsp+0x50], xmm6
0000796d027dd135  vmovaps [rsp+0x60], xmm7
0000796d027dd13b  vmovaps [rsp+0x70], xmm8
0000796d027dd141  vmovaps [rsp+0x80], xmm9
0000796d027dd14a  vmovaps [rsp+0x90], xmm10
0000796d027dd153  vmovaps [rsp+0xA0], xmm11
0000796d027dd15c  vmovaps [rsp+0xB0], xmm12
0000796d027dd165  vmovaps [rsp+0xC0], xmm13
0000796d027dd16e  vmovaps [rsp+0xD0], xmm14
0000796d027dd177  vmovaps [rsp+0xE0], xmm15
0000796d027dd180  sub rsp, 0x30
0000796d027dd184  movaps [rsp], xmm5
0000796d027dd188  movaps [rsp+0x10], xmm8
0000796d027dd18e  movaps [rsp+0x20], xmm15
0000796d027dd194  lea rdi, [rsp]
0000796d027dd198  mov esi, 0x00
0000796d027dd19d  mov rax, 0x635FBE957530
0000796d027dd1a7  call rax
0000796d027dd1a9  movaps xmm5, [rsp]
0000796d027dd1ad  add rsp, 0x30
0000796d027dd1b1  vmovaps xmm0, [rsp]
0000796d027dd1b6  vmovaps xmm1, [rsp+0x10]
0000796d027dd1bc  vmovaps xmm2, [rsp+0x20]
0000796d027dd1c2  vmovaps xmm3, [rsp+0x30]
0000796d027dd1c8  vmovaps xmm4, [rsp+0x40]
0000796d027dd1ce  vmovaps xmm6, [rsp+0x50]
0000796d027dd1d4  vmovaps xmm7, [rsp+0x60]
0000796d027dd1da  vmovaps xmm8, [rsp+0x70]
0000796d027dd1e0  vmovaps xmm9, [rsp+0x80]
0000796d027dd1e9  vmovaps xmm10, [rsp+0x90]
0000796d027dd1f2  vmovaps xmm11, [rsp+0xA0]
0000796d027dd1fb  vmovaps xmm12, [rsp+0xB0]
0000796d027dd204  vmovaps xmm13, [rsp+0xC0]
0000796d027dd20d  vmovaps xmm14, [rsp+0xD0]
0000796d027dd216  vmovaps xmm15, [rsp+0xE0]
0000796d027dd21f  add rsp, 0xF0
0000796d027dd226  pop r11
0000796d027dd228  pop r10
0000796d027dd22a  pop r9
0000796d027dd22c  pop r8
0000796d027dd22e  pop rsi
0000796d027dd22f  pop rdi
0000796d027dd230  pop rdx
0000796d027dd231  pop rcx
0000796d027dd232  pop rax
0000796d027dd233  add rsp, 0x08
0000796d027dd237  jmp 0x0000796D027DBC73
0000796d027dd23c  sub rsp, 0x08
0000796d027dd240  push rax
0000796d027dd241  push rcx
0000796d027dd242  push rdx
0000796d027dd243  push rdi
0000796d027dd244  push rsi
0000796d027dd245  push r8
0000796d027dd247  push r9
0000796d027dd249  push r10
0000796d027dd24b  push r11
0000796d027dd24d  sub rsp, 0xF0
0000796d027dd254  vmovaps [rsp], xmm0
0000796d027dd259  vmovaps [rsp+0x10], xmm1
0000796d027dd25f  vmovaps [rsp+0x20], xmm2
0000796d027dd265  vmovaps [rsp+0x30], xmm3
0000796d027dd26b  vmovaps [rsp+0x40], xmm5
0000796d027dd271  vmovaps [rsp+0x50], xmm6
0000796d027dd277  vmovaps [rsp+0x60], xmm7
0000796d027dd27d  vmovaps [rsp+0x70], xmm8
0000796d027dd283  vmovaps [rsp+0x80], xmm9
0000796d027dd28c  vmovaps [rsp+0x90], xmm10
0000796d027dd295  vmovaps [rsp+0xA0], xmm11
0000796d027dd29e  vmovaps [rsp+0xB0], xmm12
0000796d027dd2a7  vmovaps [rsp+0xC0], xmm13
0000796d027dd2b0  vmovaps [rsp+0xD0], xmm14
0000796d027dd2b9  vmovaps [rsp+0xE0], xmm15
0000796d027dd2c2  sub rsp, 0x30
0000796d027dd2c6  movaps [rsp], xmm4
0000796d027dd2ca  movaps [rsp+0x10], xmm9
0000796d027dd2d0  movaps [rsp+0x20], xmm8
0000796d027dd2d6  lea rdi, [rsp]
0000796d027dd2da  mov esi, 0x00
0000796d027dd2df  mov rax, 0x635FBE957530
0000796d027dd2e9  call rax
0000796d027dd2eb  movaps xmm4, [rsp]
0000796d027dd2ef  add rsp, 0x30
0000796d027dd2f3  vmovaps xmm0, [rsp]
0000796d027dd2f8  vmovaps xmm1, [rsp+0x10]
0000796d027dd2fe  vmovaps xmm2, [rsp+0x20]
0000796d027dd304  vmovaps xmm3, [rsp+0x30]
0000796d027dd30a  vmovaps xmm5, [rsp+0x40]
0000796d027dd310  vmovaps xmm6, [rsp+0x50]
0000796d027dd316  vmovaps xmm7, [rsp+0x60]
0000796d027dd31c  vmovaps xmm8, [rsp+0x70]
0000796d027dd322  vmovaps xmm9, [rsp+0x80]
0000796d027dd32b  vmovaps xmm10, [rsp+0x90]
0000796d027dd334  vmovaps xmm11, [rsp+0xA0]
0000796d027dd33d  vmovaps xmm12, [rsp+0xB0]
0000796d027dd346  vmovaps xmm13, [rsp+0xC0]
0000796d027dd34f  vmovaps xmm14, [rsp+0xD0]
0000796d027dd358  vmovaps xmm15, [rsp+0xE0]
0000796d027dd361  add rsp, 0xF0
0000796d027dd368  pop r11
0000796d027dd36a  pop r10
0000796d027dd36c  pop r9
0000796d027dd36e  pop r8
0000796d027dd370  pop rsi
0000796d027dd371  pop rdi
0000796d027dd372  pop rdx
0000796d027dd373  pop rcx
0000796d027dd374  pop rax
0000796d027dd375  add rsp, 0x08
0000796d027dd379  jmp 0x0000796D027DBC94
0000796d027dd37e  sub rsp, 0x08
0000796d027dd382  push rax
0000796d027dd383  push rcx
0000796d027dd384  push rdx
0000796d027dd385  push rdi
0000796d027dd386  push rsi
0000796d027dd387  push r8
0000796d027dd389  push r9
0000796d027dd38b  push r10
0000796d027dd38d  push r11
0000796d027dd38f  sub rsp, 0xF0
0000796d027dd396  vmovaps [rsp], xmm0
0000796d027dd39b  vmovaps [rsp+0x10], xmm1
0000796d027dd3a1  vmovaps [rsp+0x20], xmm2
0000796d027dd3a7  vmovaps [rsp+0x30], xmm3
0000796d027dd3ad  vmovaps [rsp+0x40], xmm4
0000796d027dd3b3  vmovaps [rsp+0x50], xmm5
0000796d027dd3b9  vmovaps [rsp+0x60], xmm6
0000796d027dd3bf  vmovaps [rsp+0x70], xmm7
0000796d027dd3c5  vmovaps [rsp+0x80], xmm8
0000796d027dd3ce  vmovaps [rsp+0x90], xmm10
0000796d027dd3d7  vmovaps [rsp+0xA0], xmm11
0000796d027dd3e0  vmovaps [rsp+0xB0], xmm12
0000796d027dd3e9  vmovaps [rsp+0xC0], xmm13
0000796d027dd3f2  vmovaps [rsp+0xD0], xmm14
0000796d027dd3fb  vmovaps [rsp+0xE0], xmm15
0000796d027dd404  sub rsp, 0x30
0000796d027dd408  movaps [rsp], xmm9
0000796d027dd40d  movaps [rsp+0x10], xmm10
0000796d027dd413  movaps [rsp+0x20], xmm8
0000796d027dd419  lea rdi, [rsp]
0000796d027dd41d  mov esi, 0x00
0000796d027dd422  mov rax, 0x635FBE957530
0000796d027dd42c  call rax
0000796d027dd42e  movaps xmm9, [rsp]
0000796d027dd433  add rsp, 0x30
0000796d027dd437  vmovaps xmm0, [rsp]
0000796d027dd43c  vmovaps xmm1, [rsp+0x10]
0000796d027dd442  vmovaps xmm2, [rsp+0x20]
0000796d027dd448  vmovaps xmm3, [rsp+0x30]
0000796d027dd44e  vmovaps xmm4, [rsp+0x40]
0000796d027dd454  vmovaps xmm5, [rsp+0x50]
0000796d027dd45a  vmovaps xmm6, [rsp+0x60]
0000796d027dd460  vmovaps xmm7, [rsp+0x70]
0000796d027dd466  vmovaps xmm8, [rsp+0x80]
0000796d027dd46f  vmovaps xmm10, [rsp+0x90]
0000796d027dd478  vmovaps xmm11, [rsp+0xA0]
0000796d027dd481  vmovaps xmm12, [rsp+0xB0]
0000796d027dd48a  vmovaps xmm13, [rsp+0xC0]
0000796d027dd493  vmovaps xmm14, [rsp+0xD0]
0000796d027dd49c  vmovaps xmm15, [rsp+0xE0]
0000796d027dd4a5  add rsp, 0xF0
0000796d027dd4ac  pop r11
0000796d027dd4ae  pop r10
0000796d027dd4b0  pop r9
0000796d027dd4b2  pop r8
0000796d027dd4b4  pop rsi
0000796d027dd4b5  pop rdi
0000796d027dd4b6  pop rdx
0000796d027dd4b7  pop rcx
0000796d027dd4b8  pop rax
0000796d027dd4b9  add rsp, 0x08
0000796d027dd4bd  jmp 0x0000796D027DBCAE
0000796d027dd4c2  call 0x0000796D026B52F0
0000796d027dd4c7  jmp 0x0000796D027DBDC8
0000796d027dd4cc  call 0x0000796D026B52F0
0000796d027dd4d1  jmp 0x0000796D027DBDDE
0000796d027dd4d6  sub rsp, 0x08
0000796d027dd4da  push rax
0000796d027dd4db  push rcx
0000796d027dd4dc  push rdx
0000796d027dd4dd  push rdi
0000796d027dd4de  push rsi
0000796d027dd4df  push r8
0000796d027dd4e1  push r9
0000796d027dd4e3  push r10
0000796d027dd4e5  push r11
0000796d027dd4e7  sub rsp, 0xF0
0000796d027dd4ee  vmovaps [rsp], xmm0
0000796d027dd4f3  vmovaps [rsp+0x10], xmm2
0000796d027dd4f9  vmovaps [rsp+0x20], xmm3
0000796d027dd4ff  vmovaps [rsp+0x30], xmm4
0000796d027dd505  vmovaps [rsp+0x40], xmm5
0000796d027dd50b  vmovaps [rsp+0x50], xmm6
0000796d027dd511  vmovaps [rsp+0x60], xmm7
0000796d027dd517  vmovaps [rsp+0x70], xmm8
0000796d027dd51d  vmovaps [rsp+0x80], xmm9
0000796d027dd526  vmovaps [rsp+0x90], xmm10
0000796d027dd52f  vmovaps [rsp+0xA0], xmm11
0000796d027dd538  vmovaps [rsp+0xB0], xmm12
0000796d027dd541  vmovaps [rsp+0xC0], xmm13
0000796d027dd54a  vmovaps [rsp+0xD0], xmm14
0000796d027dd553  vmovaps [rsp+0xE0], xmm15
0000796d027dd55c  sub rsp, 0x30
0000796d027dd560  movaps [rsp], xmm1
0000796d027dd564  movaps [rsp+0x10], xmm6
0000796d027dd569  movaps [rsp+0x20], xmm15
0000796d027dd56f  lea rdi, [rsp]
0000796d027dd573  mov esi, 0x00
0000796d027dd578  mov rax, 0x635FBE957530
0000796d027dd582  call rax
0000796d027dd584  movaps xmm1, [rsp]
0000796d027dd588  add rsp, 0x30
0000796d027dd58c  vmovaps xmm0, [rsp]
0000796d027dd591  vmovaps xmm2, [rsp+0x10]
0000796d027dd597  vmovaps xmm3, [rsp+0x20]
0000796d027dd59d  vmovaps xmm4, [rsp+0x30]
0000796d027dd5a3  vmovaps xmm5, [rsp+0x40]
0000796d027dd5a9  vmovaps xmm6, [rsp+0x50]
0000796d027dd5af  vmovaps xmm7, [rsp+0x60]
0000796d027dd5b5  vmovaps xmm8, [rsp+0x70]
0000796d027dd5bb  vmovaps xmm9, [rsp+0x80]
0000796d027dd5c4  vmovaps xmm10, [rsp+0x90]
0000796d027dd5cd  vmovaps xmm11, [rsp+0xA0]
0000796d027dd5d6  vmovaps xmm12, [rsp+0xB0]
0000796d027dd5df  vmovaps xmm13, [rsp+0xC0]
0000796d027dd5e8  vmovaps xmm14, [rsp+0xD0]
0000796d027dd5f1  vmovaps xmm15, [rsp+0xE0]
0000796d027dd5fa  add rsp, 0xF0
0000796d027dd601  pop r11
0000796d027dd603  pop r10
0000796d027dd605  pop r9
0000796d027dd607  pop r8
0000796d027dd609  pop rsi
0000796d027dd60a  pop rdi
0000796d027dd60b  pop rdx
0000796d027dd60c  pop rcx
0000796d027dd60d  pop rax
0000796d027dd60e  add rsp, 0x08
0000796d027dd612  jmp 0x0000796D027DBE1B
0000796d027dd617  call 0x0000796D026C4620
0000796d027dd61c  jmp 0x0000796D027DBE28
0000796d027dd621  sub rsp, 0x08
0000796d027dd625  push rax
0000796d027dd626  push rcx
0000796d027dd627  push rdx
0000796d027dd628  push rdi
0000796d027dd629  push rsi
0000796d027dd62a  push r8
0000796d027dd62c  push r9
0000796d027dd62e  push r10
0000796d027dd630  push r11
0000796d027dd632  sub rsp, 0xF0
0000796d027dd639  vmovaps [rsp], xmm0
0000796d027dd63e  vmovaps [rsp+0x10], xmm1
0000796d027dd644  vmovaps [rsp+0x20], xmm2
0000796d027dd64a  vmovaps [rsp+0x30], xmm3
0000796d027dd650  vmovaps [rsp+0x40], xmm4
0000796d027dd656  vmovaps [rsp+0x50], xmm5
0000796d027dd65c  vmovaps [rsp+0x60], xmm6
0000796d027dd662  vmovaps [rsp+0x70], xmm7
0000796d027dd668  vmovaps [rsp+0x80], xmm8
0000796d027dd671  vmovaps [rsp+0x90], xmm9
0000796d027dd67a  vmovaps [rsp+0xA0], xmm10
0000796d027dd683  vmovaps [rsp+0xB0], xmm11
0000796d027dd68c  vmovaps [rsp+0xC0], xmm12
0000796d027dd695  vmovaps [rsp+0xD0], xmm13
0000796d027dd69e  vmovaps [rsp+0xE0], xmm15
0000796d027dd6a7  sub rsp, 0x30
0000796d027dd6ab  movaps [rsp], xmm14
0000796d027dd6b0  movaps [rsp+0x10], xmm4
0000796d027dd6b5  movaps [rsp+0x20], xmm3
0000796d027dd6ba  lea rdi, [rsp]
0000796d027dd6be  mov esi, 0x00
0000796d027dd6c3  mov rax, 0x635FBE957530
0000796d027dd6cd  call rax
0000796d027dd6cf  movaps xmm14, [rsp]
0000796d027dd6d4  add rsp, 0x30
0000796d027dd6d8  vmovaps xmm0, [rsp]
0000796d027dd6dd  vmovaps xmm1, [rsp+0x10]
0000796d027dd6e3  vmovaps xmm2, [rsp+0x20]
0000796d027dd6e9  vmovaps xmm3, [rsp+0x30]
0000796d027dd6ef  vmovaps xmm4, [rsp+0x40]
0000796d027dd6f5  vmovaps xmm5, [rsp+0x50]
0000796d027dd6fb  vmovaps xmm6, [rsp+0x60]
0000796d027dd701  vmovaps xmm7, [rsp+0x70]
0000796d027dd707  vmovaps xmm8, [rsp+0x80]
0000796d027dd710  vmovaps xmm9, [rsp+0x90]
0000796d027dd719  vmovaps xmm10, [rsp+0xA0]
0000796d027dd722  vmovaps xmm11, [rsp+0xB0]
0000796d027dd72b  vmovaps xmm12, [rsp+0xC0]
0000796d027dd734  vmovaps xmm13, [rsp+0xD0]
0000796d027dd73d  vmovaps xmm15, [rsp+0xE0]
0000796d027dd746  add rsp, 0xF0
0000796d027dd74d  pop r11
0000796d027dd74f  pop r10
0000796d027dd751  pop r9
0000796d027dd753  pop r8
0000796d027dd755  pop rsi
0000796d027dd756  pop rdi
0000796d027dd757  pop rdx
0000796d027dd758  pop rcx
0000796d027dd759  pop rax
0000796d027dd75a  add rsp, 0x08
0000796d027dd75e  jmp 0x0000796D027DBE42
0000796d027dd763  sub rsp, 0x08
0000796d027dd767  push rax
0000796d027dd768  push rcx
0000796d027dd769  push rdx
0000796d027dd76a  push rdi
0000796d027dd76b  push rsi
0000796d027dd76c  push r8
0000796d027dd76e  push r9
0000796d027dd770  push r10
0000796d027dd772  push r11
0000796d027dd774  sub rsp, 0xF0
0000796d027dd77b  vmovaps [rsp], xmm0
0000796d027dd780  vmovaps [rsp+0x10], xmm1
0000796d027dd786  vmovaps [rsp+0x20], xmm2
0000796d027dd78c  vmovaps [rsp+0x30], xmm3
0000796d027dd792  vmovaps [rsp+0x40], xmm4
0000796d027dd798  vmovaps [rsp+0x50], xmm5
0000796d027dd79e  vmovaps [rsp+0x60], xmm7
0000796d027dd7a4  vmovaps [rsp+0x70], xmm8
0000796d027dd7aa  vmovaps [rsp+0x80], xmm9
0000796d027dd7b3  vmovaps [rsp+0x90], xmm10
0000796d027dd7bc  vmovaps [rsp+0xA0], xmm11
0000796d027dd7c5  vmovaps [rsp+0xB0], xmm12
0000796d027dd7ce  vmovaps [rsp+0xC0], xmm13
0000796d027dd7d7  vmovaps [rsp+0xD0], xmm14
0000796d027dd7e0  vmovaps [rsp+0xE0], xmm15
0000796d027dd7e9  sub rsp, 0x30
0000796d027dd7ed  movaps [rsp], xmm6
0000796d027dd7f1  movaps [rsp+0x10], xmm9
0000796d027dd7f7  movaps [rsp+0x20], xmm7
0000796d027dd7fc  lea rdi, [rsp]
0000796d027dd800  mov esi, 0x00
0000796d027dd805  mov rax, 0x635FBE957530
0000796d027dd80f  call rax
0000796d027dd811  movaps xmm6, [rsp]
0000796d027dd815  add rsp, 0x30
0000796d027dd819  vmovaps xmm0, [rsp]
0000796d027dd81e  vmovaps xmm1, [rsp+0x10]
0000796d027dd824  vmovaps xmm2, [rsp+0x20]
0000796d027dd82a  vmovaps xmm3, [rsp+0x30]
0000796d027dd830  vmovaps xmm4, [rsp+0x40]
0000796d027dd836  vmovaps xmm5, [rsp+0x50]
0000796d027dd83c  vmovaps xmm7, [rsp+0x60]
0000796d027dd842  vmovaps xmm8, [rsp+0x70]
0000796d027dd848  vmovaps xmm9, [rsp+0x80]
0000796d027dd851  vmovaps xmm10, [rsp+0x90]
0000796d027dd85a  vmovaps xmm11, [rsp+0xA0]
0000796d027dd863  vmovaps xmm12, [rsp+0xB0]
0000796d027dd86c  vmovaps xmm13, [rsp+0xC0]
0000796d027dd875  vmovaps xmm14, [rsp+0xD0]
0000796d027dd87e  vmovaps xmm15, [rsp+0xE0]
0000796d027dd887  add rsp, 0xF0
0000796d027dd88e  pop r11
0000796d027dd890  pop r10
0000796d027dd892  pop r9
0000796d027dd894  pop r8
0000796d027dd896  pop rsi
0000796d027dd897  pop rdi
0000796d027dd898  pop rdx
0000796d027dd899  pop rcx
0000796d027dd89a  pop rax
0000796d027dd89b  add rsp, 0x08
0000796d027dd89f  jmp 0x0000796D027DBE5A
0000796d027dd8a4  sub rsp, 0x08
0000796d027dd8a8  push rax
0000796d027dd8a9  push rcx
0000796d027dd8aa  push rdx
0000796d027dd8ab  push rdi
0000796d027dd8ac  push rsi
0000796d027dd8ad  push r8
0000796d027dd8af  push r9
0000796d027dd8b1  push r10
0000796d027dd8b3  push r11
0000796d027dd8b5  sub rsp, 0xF0
0000796d027dd8bc  vmovaps [rsp], xmm0
0000796d027dd8c1  vmovaps [rsp+0x10], xmm1
0000796d027dd8c7  vmovaps [rsp+0x20], xmm2
0000796d027dd8cd  vmovaps [rsp+0x30], xmm3
0000796d027dd8d3  vmovaps [rsp+0x40], xmm4
0000796d027dd8d9  vmovaps [rsp+0x50], xmm5
0000796d027dd8df  vmovaps [rsp+0x60], xmm6
0000796d027dd8e5  vmovaps [rsp+0x70], xmm8
0000796d027dd8eb  vmovaps [rsp+0x80], xmm9
0000796d027dd8f4  vmovaps [rsp+0x90], xmm10
0000796d027dd8fd  vmovaps [rsp+0xA0], xmm11
0000796d027dd906  vmovaps [rsp+0xB0], xmm12
0000796d027dd90f  vmovaps [rsp+0xC0], xmm13
0000796d027dd918  vmovaps [rsp+0xD0], xmm14
0000796d027dd921  vmovaps [rsp+0xE0], xmm15
0000796d027dd92a  sub rsp, 0x30
0000796d027dd92e  movaps [rsp], xmm7
0000796d027dd932  movaps [rsp+0x10], xmm4
0000796d027dd937  movaps [rsp+0x20], xmm9
0000796d027dd93d  lea rdi, [rsp]
0000796d027dd941  mov esi, 0x00
0000796d027dd946  mov rax, 0x635FBE957530
0000796d027dd950  call rax
0000796d027dd952  movaps xmm7, [rsp]
0000796d027dd956  add rsp, 0x30
0000796d027dd95a  vmovaps xmm0, [rsp]
0000796d027dd95f  vmovaps xmm1, [rsp+0x10]
0000796d027dd965  vmovaps xmm2, [rsp+0x20]
0000796d027dd96b  vmovaps xmm3, [rsp+0x30]
0000796d027dd971  vmovaps xmm4, [rsp+0x40]
0000796d027dd977  vmovaps xmm5, [rsp+0x50]
0000796d027dd97d  vmovaps xmm6, [rsp+0x60]
0000796d027dd983  vmovaps xmm8, [rsp+0x70]
0000796d027dd989  vmovaps xmm9, [rsp+0x80]
0000796d027dd992  vmovaps xmm10, [rsp+0x90]
0000796d027dd99b  vmovaps xmm11, [rsp+0xA0]
0000796d027dd9a4  vmovaps xmm12, [rsp+0xB0]
0000796d027dd9ad  vmovaps xmm13, [rsp+0xC0]
0000796d027dd9b6  vmovaps xmm14, [rsp+0xD0]
0000796d027dd9bf  vmovaps xmm15, [rsp+0xE0]
0000796d027dd9c8  add rsp, 0xF0
0000796d027dd9cf  pop r11
0000796d027dd9d1  pop r10
0000796d027dd9d3  pop r9
0000796d027dd9d5  pop r8
0000796d027dd9d7  pop rsi
0000796d027dd9d8  pop rdi
0000796d027dd9d9  pop rdx
0000796d027dd9da  pop rcx
0000796d027dd9db  pop rax
0000796d027dd9dc  add rsp, 0x08
0000796d027dd9e0  jmp 0x0000796D027DBE87
0000796d027dd9e5  sub rsp, 0x08
0000796d027dd9e9  push rax
0000796d027dd9ea  push rcx
0000796d027dd9eb  push rdx
0000796d027dd9ec  push rdi
0000796d027dd9ed  push rsi
0000796d027dd9ee  push r8
0000796d027dd9f0  push r9
0000796d027dd9f2  push r10
0000796d027dd9f4  push r11
0000796d027dd9f6  sub rsp, 0xF0
0000796d027dd9fd  vmovaps [rsp], xmm0
0000796d027dda02  vmovaps [rsp+0x10], xmm1
0000796d027dda08  vmovaps [rsp+0x20], xmm2
0000796d027dda0e  vmovaps [rsp+0x30], xmm3
0000796d027dda14  vmovaps [rsp+0x40], xmm5
0000796d027dda1a  vmovaps [rsp+0x50], xmm6
0000796d027dda20  vmovaps [rsp+0x60], xmm7
0000796d027dda26  vmovaps [rsp+0x70], xmm8
0000796d027dda2c  vmovaps [rsp+0x80], xmm9
0000796d027dda35  vmovaps [rsp+0x90], xmm10
0000796d027dda3e  vmovaps [rsp+0xA0], xmm11
0000796d027dda47  vmovaps [rsp+0xB0], xmm12
0000796d027dda50  vmovaps [rsp+0xC0], xmm13
0000796d027dda59  vmovaps [rsp+0xD0], xmm14
0000796d027dda62  vmovaps [rsp+0xE0], xmm15
0000796d027dda6b  sub rsp, 0x30
0000796d027dda6f  movaps [rsp], xmm4
0000796d027dda73  movaps [rsp+0x10], xmm15
0000796d027dda79  movaps [rsp+0x20], xmm9
0000796d027dda7f  lea rdi, [rsp]
0000796d027dda83  mov esi, 0x00
0000796d027dda88  mov rax, 0x635FBE957530
0000796d027dda92  call rax
0000796d027dda94  movaps xmm4, [rsp]
0000796d027dda98  add rsp, 0x30
0000796d027dda9c  vmovaps xmm0, [rsp]
0000796d027ddaa1  vmovaps xmm1, [rsp+0x10]
0000796d027ddaa7  vmovaps xmm2, [rsp+0x20]
0000796d027ddaad  vmovaps xmm3, [rsp+0x30]
0000796d027ddab3  vmovaps xmm5, [rsp+0x40]
0000796d027ddab9  vmovaps xmm6, [rsp+0x50]
0000796d027ddabf  vmovaps xmm7, [rsp+0x60]
0000796d027ddac5  vmovaps xmm8, [rsp+0x70]
0000796d027ddacb  vmovaps xmm9, [rsp+0x80]
0000796d027ddad4  vmovaps xmm10, [rsp+0x90]
0000796d027ddadd  vmovaps xmm11, [rsp+0xA0]
0000796d027ddae6  vmovaps xmm12, [rsp+0xB0]
0000796d027ddaef  vmovaps xmm13, [rsp+0xC0]
0000796d027ddaf8  vmovaps xmm14, [rsp+0xD0]
0000796d027ddb01  vmovaps xmm15, [rsp+0xE0]
0000796d027ddb0a  add rsp, 0xF0
0000796d027ddb11  pop r11
0000796d027ddb13  pop r10
0000796d027ddb15  pop r9
0000796d027ddb17  pop r8
0000796d027ddb19  pop rsi
0000796d027ddb1a  pop rdi
0000796d027ddb1b  pop rdx
0000796d027ddb1c  pop rcx
0000796d027ddb1d  pop rax
0000796d027ddb1e  add rsp, 0x08
0000796d027ddb22  jmp 0x0000796D027DBEAC
0000796d027ddb27  call 0x0000796D026C4620
0000796d027ddb2c  jmp 0x0000796D027DBEB9
0000796d027ddb31  sub rsp, 0x08
0000796d027ddb35  push rax
0000796d027ddb36  push rcx
0000796d027ddb37  push rdx
0000796d027ddb38  push rdi
0000796d027ddb39  push rsi
0000796d027ddb3a  push r8
0000796d027ddb3c  push r9
0000796d027ddb3e  push r10
0000796d027ddb40  push r11
0000796d027ddb42  sub rsp, 0xF0
0000796d027ddb49  vmovaps [rsp], xmm0
0000796d027ddb4e  vmovaps [rsp+0x10], xmm1
0000796d027ddb54  vmovaps [rsp+0x20], xmm2
0000796d027ddb5a  vmovaps [rsp+0x30], xmm4
0000796d027ddb60  vmovaps [rsp+0x40], xmm5
0000796d027ddb66  vmovaps [rsp+0x50], xmm6
0000796d027ddb6c  vmovaps [rsp+0x60], xmm7
0000796d027ddb72  vmovaps [rsp+0x70], xmm8
0000796d027ddb78  vmovaps [rsp+0x80], xmm9
0000796d027ddb81  vmovaps [rsp+0x90], xmm10
0000796d027ddb8a  vmovaps [rsp+0xA0], xmm11
0000796d027ddb93  vmovaps [rsp+0xB0], xmm12
0000796d027ddb9c  vmovaps [rsp+0xC0], xmm13
0000796d027ddba5  vmovaps [rsp+0xD0], xmm14
0000796d027ddbae  vmovaps [rsp+0xE0], xmm15
0000796d027ddbb7  sub rsp, 0x30
0000796d027ddbbb  movaps [rsp], xmm3
0000796d027ddbbf  movaps [rsp+0x10], xmm1
0000796d027ddbc4  movaps [rsp+0x20], xmm9
0000796d027ddbca  lea rdi, [rsp]
0000796d027ddbce  mov esi, 0x00
0000796d027ddbd3  mov rax, 0x635FBE957530
0000796d027ddbdd  call rax
0000796d027ddbdf  movaps xmm3, [rsp]
0000796d027ddbe3  add rsp, 0x30
0000796d027ddbe7  vmovaps xmm0, [rsp]
0000796d027ddbec  vmovaps xmm1, [rsp+0x10]
0000796d027ddbf2  vmovaps xmm2, [rsp+0x20]
0000796d027ddbf8  vmovaps xmm4, [rsp+0x30]
0000796d027ddbfe  vmovaps xmm5, [rsp+0x40]
0000796d027ddc04  vmovaps xmm6, [rsp+0x50]
0000796d027ddc0a  vmovaps xmm7, [rsp+0x60]
0000796d027ddc10  vmovaps xmm8, [rsp+0x70]
0000796d027ddc16  vmovaps xmm9, [rsp+0x80]
0000796d027ddc1f  vmovaps xmm10, [rsp+0x90]
0000796d027ddc28  vmovaps xmm11, [rsp+0xA0]
0000796d027ddc31  vmovaps xmm12, [rsp+0xB0]
0000796d027ddc3a  vmovaps xmm13, [rsp+0xC0]
0000796d027ddc43  vmovaps xmm14, [rsp+0xD0]
0000796d027ddc4c  vmovaps xmm15, [rsp+0xE0]
0000796d027ddc55  add rsp, 0xF0
0000796d027ddc5c  pop r11
0000796d027ddc5e  pop r10
0000796d027ddc60  pop r9
0000796d027ddc62  pop r8
0000796d027ddc64  pop rsi
0000796d027ddc65  pop rdi
0000796d027ddc66  pop rdx
0000796d027ddc67  pop rcx
0000796d027ddc68  pop rax
0000796d027ddc69  add rsp, 0x08
0000796d027ddc6d  jmp 0x0000796D027DBEF6
0000796d027ddc72  sub rsp, 0x08
0000796d027ddc76  push rax
0000796d027ddc77  push rcx
0000796d027ddc78  push rdx
0000796d027ddc79  push rdi
0000796d027ddc7a  push rsi
0000796d027ddc7b  push r8
0000796d027ddc7d  push r9
0000796d027ddc7f  push r10
0000796d027ddc81  push r11
0000796d027ddc83  sub rsp, 0xF0
0000796d027ddc8a  vmovaps [rsp], xmm0
0000796d027ddc8f  vmovaps [rsp+0x10], xmm2
0000796d027ddc95  vmovaps [rsp+0x20], xmm3
0000796d027ddc9b  vmovaps [rsp+0x30], xmm4
0000796d027ddca1  vmovaps [rsp+0x40], xmm5
0000796d027ddca7  vmovaps [rsp+0x50], xmm6
0000796d027ddcad  vmovaps [rsp+0x60], xmm7
0000796d027ddcb3  vmovaps [rsp+0x70], xmm8
0000796d027ddcb9  vmovaps [rsp+0x80], xmm9
0000796d027ddcc2  vmovaps [rsp+0x90], xmm10
0000796d027ddccb  vmovaps [rsp+0xA0], xmm11
0000796d027ddcd4  vmovaps [rsp+0xB0], xmm12
0000796d027ddcdd  vmovaps [rsp+0xC0], xmm13
0000796d027ddce6  vmovaps [rsp+0xD0], xmm14
0000796d027ddcef  vmovaps [rsp+0xE0], xmm15
0000796d027ddcf8  sub rsp, 0x30
0000796d027ddcfc  movaps [rsp], xmm1
0000796d027ddd00  movaps [rsp+0x10], xmm15
0000796d027ddd06  movaps [rsp+0x20], xmm9
0000796d027ddd0c  lea rdi, [rsp]
0000796d027ddd10  mov esi, 0x00
0000796d027ddd15  mov rax, 0x635FBE957530
0000796d027ddd1f  call rax
0000796d027ddd21  movaps xmm1, [rsp]
0000796d027ddd25  add rsp, 0x30
0000796d027ddd29  vmovaps xmm0, [rsp]
0000796d027ddd2e  vmovaps xmm2, [rsp+0x10]
0000796d027ddd34  vmovaps xmm3, [rsp+0x20]
0000796d027ddd3a  vmovaps xmm4, [rsp+0x30]
0000796d027ddd40  vmovaps xmm5, [rsp+0x40]
0000796d027ddd46  vmovaps xmm6, [rsp+0x50]
0000796d027ddd4c  vmovaps xmm7, [rsp+0x60]
0000796d027ddd52  vmovaps xmm8, [rsp+0x70]
0000796d027ddd58  vmovaps xmm9, [rsp+0x80]
0000796d027ddd61  vmovaps xmm10, [rsp+0x90]
0000796d027ddd6a  vmovaps xmm11, [rsp+0xA0]
0000796d027ddd73  vmovaps xmm12, [rsp+0xB0]
0000796d027ddd7c  vmovaps xmm13, [rsp+0xC0]
0000796d027ddd85  vmovaps xmm14, [rsp+0xD0]
0000796d027ddd8e  vmovaps xmm15, [rsp+0xE0]
0000796d027ddd97  add rsp, 0xF0
0000796d027ddd9e  pop r11
0000796d027ddda0  pop r10
0000796d027ddda2  pop r9
0000796d027ddda4  pop r8
0000796d027ddda6  pop rsi
0000796d027ddda7  pop rdi
0000796d027ddda8  pop rdx
0000796d027ddda9  pop rcx
0000796d027dddaa  pop rax
0000796d027dddab  add rsp, 0x08
0000796d027dddaf  jmp 0x0000796D027DBF7E
0000796d027dddb4  call 0x0000796D026C4620
0000796d027dddb9  jmp 0x0000796D027DBF8B
0000796d027dddbe  sub rsp, 0x08
0000796d027dddc2  push rax
0000796d027dddc3  push rcx
0000796d027dddc4  push rdx
0000796d027dddc5  push rdi
0000796d027dddc6  push rsi
0000796d027dddc7  push r8
0000796d027dddc9  push r9
0000796d027dddcb  push r10
0000796d027dddcd  push r11
0000796d027dddcf  sub rsp, 0xF0
0000796d027dddd6  vmovaps [rsp], xmm0
0000796d027ddddb  vmovaps [rsp+0x10], xmm2
0000796d027ddde1  vmovaps [rsp+0x20], xmm3
0000796d027ddde7  vmovaps [rsp+0x30], xmm4
0000796d027ddded  vmovaps [rsp+0x40], xmm5
0000796d027dddf3  vmovaps [rsp+0x50], xmm6
0000796d027dddf9  vmovaps [rsp+0x60], xmm7
0000796d027dddff  vmovaps [rsp+0x70], xmm8
0000796d027dde05  vmovaps [rsp+0x80], xmm9
0000796d027dde0e  vmovaps [rsp+0x90], xmm10
0000796d027dde17  vmovaps [rsp+0xA0], xmm11
0000796d027dde20  vmovaps [rsp+0xB0], xmm12
0000796d027dde29  vmovaps [rsp+0xC0], xmm13
0000796d027dde32  vmovaps [rsp+0xD0], xmm14
0000796d027dde3b  vmovaps [rsp+0xE0], xmm15
0000796d027dde44  sub rsp, 0x30
0000796d027dde48  movaps [rsp], xmm1
0000796d027dde4c  movaps [rsp+0x10], xmm5
0000796d027dde51  movaps [rsp+0x20], xmm7
0000796d027dde56  lea rdi, [rsp]
0000796d027dde5a  mov esi, 0x00
0000796d027dde5f  mov rax, 0x635FBE957530
0000796d027dde69  call rax
0000796d027dde6b  movaps xmm1, [rsp]
0000796d027dde6f  add rsp, 0x30
0000796d027dde73  vmovaps xmm0, [rsp]
0000796d027dde78  vmovaps xmm2, [rsp+0x10]
0000796d027dde7e  vmovaps xmm3, [rsp+0x20]
0000796d027dde84  vmovaps xmm4, [rsp+0x30]
0000796d027dde8a  vmovaps xmm5, [rsp+0x40]
0000796d027dde90  vmovaps xmm6, [rsp+0x50]
0000796d027dde96  vmovaps xmm7, [rsp+0x60]
0000796d027dde9c  vmovaps xmm8, [rsp+0x70]
0000796d027ddea2  vmovaps xmm9, [rsp+0x80]
0000796d027ddeab  vmovaps xmm10, [rsp+0x90]
0000796d027ddeb4  vmovaps xmm11, [rsp+0xA0]
0000796d027ddebd  vmovaps xmm12, [rsp+0xB0]
0000796d027ddec6  vmovaps xmm13, [rsp+0xC0]
0000796d027ddecf  vmovaps xmm14, [rsp+0xD0]
0000796d027dded8  vmovaps xmm15, [rsp+0xE0]
0000796d027ddee1  add rsp, 0xF0
0000796d027ddee8  pop r11
0000796d027ddeea  pop r10
0000796d027ddeec  pop r9
0000796d027ddeee  pop r8
0000796d027ddef0  pop rsi
0000796d027ddef1  pop rdi
0000796d027ddef2  pop rdx
0000796d027ddef3  pop rcx
0000796d027ddef4  pop rax
0000796d027ddef5  add rsp, 0x08
0000796d027ddef9  jmp 0x0000796D027DC030
0000796d027ddefe  sub rsp, 0x08
0000796d027ddf02  push rax
0000796d027ddf03  push rcx
0000796d027ddf04  push rdx
0000796d027ddf05  push rdi
0000796d027ddf06  push rsi
0000796d027ddf07  push r8
0000796d027ddf09  push r9
0000796d027ddf0b  push r10
0000796d027ddf0d  push r11
0000796d027ddf0f  sub rsp, 0xF0
0000796d027ddf16  vmovaps [rsp], xmm0
0000796d027ddf1b  vmovaps [rsp+0x10], xmm1
0000796d027ddf21  vmovaps [rsp+0x20], xmm2
0000796d027ddf27  vmovaps [rsp+0x30], xmm3
0000796d027ddf2d  vmovaps [rsp+0x40], xmm4
0000796d027ddf33  vmovaps [rsp+0x50], xmm5
0000796d027ddf39  vmovaps [rsp+0x60], xmm6
0000796d027ddf3f  vmovaps [rsp+0x70], xmm8
0000796d027ddf45  vmovaps [rsp+0x80], xmm9
0000796d027ddf4e  vmovaps [rsp+0x90], xmm10
0000796d027ddf57  vmovaps [rsp+0xA0], xmm11
0000796d027ddf60  vmovaps [rsp+0xB0], xmm12
0000796d027ddf69  vmovaps [rsp+0xC0], xmm13
0000796d027ddf72  vmovaps [rsp+0xD0], xmm14
0000796d027ddf7b  vmovaps [rsp+0xE0], xmm15
0000796d027ddf84  sub rsp, 0x30
0000796d027ddf88  movaps [rsp], xmm7
0000796d027ddf8c  movaps [rsp+0x10], xmm5
0000796d027ddf91  movaps [rsp+0x20], xmm15
0000796d027ddf97  lea rdi, [rsp]
0000796d027ddf9b  mov esi, 0x00
0000796d027ddfa0  mov rax, 0x635FBE957530
0000796d027ddfaa  call rax
0000796d027ddfac  movaps xmm7, [rsp]
0000796d027ddfb0  add rsp, 0x30
0000796d027ddfb4  vmovaps xmm0, [rsp]
0000796d027ddfb9  vmovaps xmm1, [rsp+0x10]
0000796d027ddfbf  vmovaps xmm2, [rsp+0x20]
0000796d027ddfc5  vmovaps xmm3, [rsp+0x30]
0000796d027ddfcb  vmovaps xmm4, [rsp+0x40]
0000796d027ddfd1  vmovaps xmm5, [rsp+0x50]
0000796d027ddfd7  vmovaps xmm6, [rsp+0x60]
0000796d027ddfdd  vmovaps xmm8, [rsp+0x70]
0000796d027ddfe3  vmovaps xmm9, [rsp+0x80]
0000796d027ddfec  vmovaps xmm10, [rsp+0x90]
0000796d027ddff5  vmovaps xmm11, [rsp+0xA0]
0000796d027ddffe  vmovaps xmm12, [rsp+0xB0]
0000796d027de007  vmovaps xmm13, [rsp+0xC0]
0000796d027de010  vmovaps xmm14, [rsp+0xD0]
0000796d027de019  vmovaps xmm15, [rsp+0xE0]
0000796d027de022  add rsp, 0xF0
0000796d027de029  pop r11
0000796d027de02b  pop r10
0000796d027de02d  pop r9
0000796d027de02f  pop r8
0000796d027de031  pop rsi
0000796d027de032  pop rdi
0000796d027de033  pop rdx
0000796d027de034  pop rcx
0000796d027de035  pop rax
0000796d027de036  add rsp, 0x08
0000796d027de03a  jmp 0x0000796D027DC066
0000796d027de03f  call 0x0000796D026B52F0
0000796d027de044  jmp 0x0000796D027DC073
0000796d027de049  sub rsp, 0x08
0000796d027de04d  push rax
0000796d027de04e  push rcx
0000796d027de04f  push rdx
0000796d027de050  push rdi
0000796d027de051  push rsi
0000796d027de052  push r8
0000796d027de054  push r9
0000796d027de056  push r10
0000796d027de058  push r11
0000796d027de05a  sub rsp, 0xF0
0000796d027de061  vmovaps [rsp], xmm0
0000796d027de066  vmovaps [rsp+0x10], xmm1
0000796d027de06c  vmovaps [rsp+0x20], xmm2
0000796d027de072  vmovaps [rsp+0x30], xmm3
0000796d027de078  vmovaps [rsp+0x40], xmm4
0000796d027de07e  vmovaps [rsp+0x50], xmm5
0000796d027de084  vmovaps [rsp+0x60], xmm6
0000796d027de08a  vmovaps [rsp+0x70], xmm7
0000796d027de090  vmovaps [rsp+0x80], xmm8
0000796d027de099  vmovaps [rsp+0x90], xmm9
0000796d027de0a2  vmovaps [rsp+0xA0], xmm10
0000796d027de0ab  vmovaps [rsp+0xB0], xmm11
0000796d027de0b4  vmovaps [rsp+0xC0], xmm12
0000796d027de0bd  vmovaps [rsp+0xD0], xmm13
0000796d027de0c6  vmovaps [rsp+0xE0], xmm14
0000796d027de0cf  sub rsp, 0x30
0000796d027de0d3  movaps [rsp], xmm15
0000796d027de0d8  movaps [rsp+0x10], xmm5
0000796d027de0dd  movaps [rsp+0x20], xmm3
0000796d027de0e2  lea rdi, [rsp]
0000796d027de0e6  mov esi, 0x00
0000796d027de0eb  mov rax, 0x635FBE957530
0000796d027de0f5  call rax
0000796d027de0f7  movaps xmm15, [rsp]
0000796d027de0fc  add rsp, 0x30
0000796d027de100  vmovaps xmm0, [rsp]
0000796d027de105  vmovaps xmm1, [rsp+0x10]
0000796d027de10b  vmovaps xmm2, [rsp+0x20]
0000796d027de111  vmovaps xmm3, [rsp+0x30]
0000796d027de117  vmovaps xmm4, [rsp+0x40]
0000796d027de11d  vmovaps xmm5, [rsp+0x50]
0000796d027de123  vmovaps xmm6, [rsp+0x60]
0000796d027de129  vmovaps xmm7, [rsp+0x70]
0000796d027de12f  vmovaps xmm8, [rsp+0x80]
0000796d027de138  vmovaps xmm9, [rsp+0x90]
0000796d027de141  vmovaps xmm10, [rsp+0xA0]
0000796d027de14a  vmovaps xmm11, [rsp+0xB0]
0000796d027de153  vmovaps xmm12, [rsp+0xC0]
0000796d027de15c  vmovaps xmm13, [rsp+0xD0]
0000796d027de165  vmovaps xmm14, [rsp+0xE0]
0000796d027de16e  add rsp, 0xF0
0000796d027de175  pop r11
0000796d027de177  pop r10
0000796d027de179  pop r9
0000796d027de17b  pop r8
0000796d027de17d  pop rsi
0000796d027de17e  pop rdi
0000796d027de17f  pop rdx
0000796d027de180  pop rcx
0000796d027de181  pop rax
0000796d027de182  add rsp, 0x08
0000796d027de186  jmp 0x0000796D027DC099
0000796d027de18b  sub rsp, 0x08
0000796d027de18f  push rax
0000796d027de190  push rcx
0000796d027de191  push rdx
0000796d027de192  push rdi
0000796d027de193  push rsi
0000796d027de194  push r8
0000796d027de196  push r9
0000796d027de198  push r10
0000796d027de19a  push r11
0000796d027de19c  sub rsp, 0xF0
0000796d027de1a3  vmovaps [rsp], xmm0
0000796d027de1a8  vmovaps [rsp+0x10], xmm2
0000796d027de1ae  vmovaps [rsp+0x20], xmm3
0000796d027de1b4  vmovaps [rsp+0x30], xmm4
0000796d027de1ba  vmovaps [rsp+0x40], xmm5
0000796d027de1c0  vmovaps [rsp+0x50], xmm6
0000796d027de1c6  vmovaps [rsp+0x60], xmm7
0000796d027de1cc  vmovaps [rsp+0x70], xmm8
0000796d027de1d2  vmovaps [rsp+0x80], xmm9
0000796d027de1db  vmovaps [rsp+0x90], xmm10
0000796d027de1e4  vmovaps [rsp+0xA0], xmm11
0000796d027de1ed  vmovaps [rsp+0xB0], xmm12
0000796d027de1f6  vmovaps [rsp+0xC0], xmm13
0000796d027de1ff  vmovaps [rsp+0xD0], xmm14
0000796d027de208  vmovaps [rsp+0xE0], xmm15
0000796d027de211  sub rsp, 0x30
0000796d027de215  movaps [rsp], xmm1
0000796d027de219  movaps [rsp+0x10], xmm5
0000796d027de21e  movaps [rsp+0x20], xmm4
0000796d027de223  lea rdi, [rsp]
0000796d027de227  mov esi, 0x00
0000796d027de22c  mov rax, 0x635FBE957530
0000796d027de236  call rax
0000796d027de238  movaps xmm1, [rsp]
0000796d027de23c  add rsp, 0x30
0000796d027de240  vmovaps xmm0, [rsp]
0000796d027de245  vmovaps xmm2, [rsp+0x10]
0000796d027de24b  vmovaps xmm3, [rsp+0x20]
0000796d027de251  vmovaps xmm4, [rsp+0x30]
0000796d027de257  vmovaps xmm5, [rsp+0x40]
0000796d027de25d  vmovaps xmm6, [rsp+0x50]
0000796d027de263  vmovaps xmm7, [rsp+0x60]
0000796d027de269  vmovaps xmm8, [rsp+0x70]
0000796d027de26f  vmovaps xmm9, [rsp+0x80]
0000796d027de278  vmovaps xmm10, [rsp+0x90]
0000796d027de281  vmovaps xmm11, [rsp+0xA0]
0000796d027de28a  vmovaps xmm12, [rsp+0xB0]
0000796d027de293  vmovaps xmm13, [rsp+0xC0]
0000796d027de29c  vmovaps xmm14, [rsp+0xD0]
0000796d027de2a5  vmovaps xmm15, [rsp+0xE0]
0000796d027de2ae  add rsp, 0xF0
0000796d027de2b5  pop r11
0000796d027de2b7  pop r10
0000796d027de2b9  pop r9
0000796d027de2bb  pop r8
0000796d027de2bd  pop rsi
0000796d027de2be  pop rdi
0000796d027de2bf  pop rdx
0000796d027de2c0  pop rcx
0000796d027de2c1  pop rax
0000796d027de2c2  add rsp, 0x08
0000796d027de2c6  jmp 0x0000796D027DC0B9
0000796d027de2cb  sub rsp, 0x08
0000796d027de2cf  push rax
0000796d027de2d0  push rcx
0000796d027de2d1  push rdx
0000796d027de2d2  push rdi
0000796d027de2d3  push rsi
0000796d027de2d4  push r8
0000796d027de2d6  push r9
0000796d027de2d8  push r10
0000796d027de2da  push r11
0000796d027de2dc  sub rsp, 0xF0
0000796d027de2e3  vmovaps [rsp], xmm0
0000796d027de2e8  vmovaps [rsp+0x10], xmm1
0000796d027de2ee  vmovaps [rsp+0x20], xmm2
0000796d027de2f4  vmovaps [rsp+0x30], xmm3
0000796d027de2fa  vmovaps [rsp+0x40], xmm5
0000796d027de300  vmovaps [rsp+0x50], xmm6
0000796d027de306  vmovaps [rsp+0x60], xmm7
0000796d027de30c  vmovaps [rsp+0x70], xmm8
0000796d027de312  vmovaps [rsp+0x80], xmm9
0000796d027de31b  vmovaps [rsp+0x90], xmm10
0000796d027de324  vmovaps [rsp+0xA0], xmm11
0000796d027de32d  vmovaps [rsp+0xB0], xmm12
0000796d027de336  vmovaps [rsp+0xC0], xmm13
0000796d027de33f  vmovaps [rsp+0xD0], xmm14
0000796d027de348  vmovaps [rsp+0xE0], xmm15
0000796d027de351  sub rsp, 0x30
0000796d027de355  movaps [rsp], xmm4
0000796d027de359  movaps [rsp+0x10], xmm3
0000796d027de35e  movaps [rsp+0x20], xmm5
0000796d027de363  lea rdi, [rsp]
0000796d027de367  mov esi, 0x00
0000796d027de36c  mov rax, 0x635FBE957530
0000796d027de376  call rax
0000796d027de378  movaps xmm4, [rsp]
0000796d027de37c  add rsp, 0x30
0000796d027de380  vmovaps xmm0, [rsp]
0000796d027de385  vmovaps xmm1, [rsp+0x10]
0000796d027de38b  vmovaps xmm2, [rsp+0x20]
0000796d027de391  vmovaps xmm3, [rsp+0x30]
0000796d027de397  vmovaps xmm5, [rsp+0x40]
0000796d027de39d  vmovaps xmm6, [rsp+0x50]
0000796d027de3a3  vmovaps xmm7, [rsp+0x60]
0000796d027de3a9  vmovaps xmm8, [rsp+0x70]
0000796d027de3af  vmovaps xmm9, [rsp+0x80]
0000796d027de3b8  vmovaps xmm10, [rsp+0x90]
0000796d027de3c1  vmovaps xmm11, [rsp+0xA0]
0000796d027de3ca  vmovaps xmm12, [rsp+0xB0]
0000796d027de3d3  vmovaps xmm13, [rsp+0xC0]
0000796d027de3dc  vmovaps xmm14, [rsp+0xD0]
0000796d027de3e5  vmovaps xmm15, [rsp+0xE0]
0000796d027de3ee  add rsp, 0xF0
0000796d027de3f5  pop r11
0000796d027de3f7  pop r10
0000796d027de3f9  pop r9
0000796d027de3fb  pop r8
0000796d027de3fd  pop rsi
0000796d027de3fe  pop rdi
0000796d027de3ff  pop rdx
0000796d027de400  pop rcx
0000796d027de401  pop rax
0000796d027de402  add rsp, 0x08
0000796d027de406  jmp 0x0000796D027DC107
0000796d027de40b  call 0x0000796D026B52F0
0000796d027de410  jmp 0x0000796D027DC114
0000796d027de415  sub rsp, 0x08
0000796d027de419  push rax
0000796d027de41a  push rcx
0000796d027de41b  push rdx
0000796d027de41c  push rdi
0000796d027de41d  push rsi
0000796d027de41e  push r8
0000796d027de420  push r9
0000796d027de422  push r10
0000796d027de424  push r11
0000796d027de426  sub rsp, 0xF0
0000796d027de42d  vmovaps [rsp], xmm0
0000796d027de432  vmovaps [rsp+0x10], xmm1
0000796d027de438  vmovaps [rsp+0x20], xmm2
0000796d027de43e  vmovaps [rsp+0x30], xmm3
0000796d027de444  vmovaps [rsp+0x40], xmm4
0000796d027de44a  vmovaps [rsp+0x50], xmm6
0000796d027de450  vmovaps [rsp+0x60], xmm7
0000796d027de456  vmovaps [rsp+0x70], xmm8
0000796d027de45c  vmovaps [rsp+0x80], xmm9
0000796d027de465  vmovaps [rsp+0x90], xmm10
0000796d027de46e  vmovaps [rsp+0xA0], xmm11
0000796d027de477  vmovaps [rsp+0xB0], xmm12
0000796d027de480  vmovaps [rsp+0xC0], xmm13
0000796d027de489  vmovaps [rsp+0xD0], xmm14
0000796d027de492  vmovaps [rsp+0xE0], xmm15
0000796d027de49b  sub rsp, 0x30
0000796d027de49f  movaps [rsp], xmm5
0000796d027de4a3  movaps [rsp+0x10], xmm6
0000796d027de4a8  movaps [rsp+0x20], xmm3
0000796d027de4ad  lea rdi, [rsp]
0000796d027de4b1  mov esi, 0x00
0000796d027de4b6  mov rax, 0x635FBE957530
0000796d027de4c0  call rax
0000796d027de4c2  movaps xmm5, [rsp]
0000796d027de4c6  add rsp, 0x30
0000796d027de4ca  vmovaps xmm0, [rsp]
0000796d027de4cf  vmovaps xmm1, [rsp+0x10]
0000796d027de4d5  vmovaps xmm2, [rsp+0x20]
0000796d027de4db  vmovaps xmm3, [rsp+0x30]
0000796d027de4e1  vmovaps xmm4, [rsp+0x40]
0000796d027de4e7  vmovaps xmm6, [rsp+0x50]
0000796d027de4ed  vmovaps xmm7, [rsp+0x60]
0000796d027de4f3  vmovaps xmm8, [rsp+0x70]
0000796d027de4f9  vmovaps xmm9, [rsp+0x80]
0000796d027de502  vmovaps xmm10, [rsp+0x90]
0000796d027de50b  vmovaps xmm11, [rsp+0xA0]
0000796d027de514  vmovaps xmm12, [rsp+0xB0]
0000796d027de51d  vmovaps xmm13, [rsp+0xC0]
0000796d027de526  vmovaps xmm14, [rsp+0xD0]
0000796d027de52f  vmovaps xmm15, [rsp+0xE0]
0000796d027de538  add rsp, 0xF0
0000796d027de53f  pop r11
0000796d027de541  pop r10
0000796d027de543  pop r9
0000796d027de545  pop r8
0000796d027de547  pop rsi
0000796d027de548  pop rdi
0000796d027de549  pop rdx
0000796d027de54a  pop rcx
0000796d027de54b  pop rax
0000796d027de54c  add rsp, 0x08
0000796d027de550  jmp 0x0000796D027DC13A
0000796d027de555  sub rsp, 0x08
0000796d027de559  push rax
0000796d027de55a  push rcx
0000796d027de55b  push rdx
0000796d027de55c  push rdi
0000796d027de55d  push rsi
0000796d027de55e  push r8
0000796d027de560  push r9
0000796d027de562  push r10
0000796d027de564  push r11
0000796d027de566  sub rsp, 0xF0
0000796d027de56d  vmovaps [rsp], xmm0
0000796d027de572  vmovaps [rsp+0x10], xmm1
0000796d027de578  vmovaps [rsp+0x20], xmm2
0000796d027de57e  vmovaps [rsp+0x30], xmm3
0000796d027de584  vmovaps [rsp+0x40], xmm4
0000796d027de58a  vmovaps [rsp+0x50], xmm5
0000796d027de590  vmovaps [rsp+0x60], xmm7
0000796d027de596  vmovaps [rsp+0x70], xmm8
0000796d027de59c  vmovaps [rsp+0x80], xmm9
0000796d027de5a5  vmovaps [rsp+0x90], xmm10
0000796d027de5ae  vmovaps [rsp+0xA0], xmm11
0000796d027de5b7  vmovaps [rsp+0xB0], xmm12
0000796d027de5c0  vmovaps [rsp+0xC0], xmm13
0000796d027de5c9  vmovaps [rsp+0xD0], xmm14
0000796d027de5d2  vmovaps [rsp+0xE0], xmm15
0000796d027de5db  sub rsp, 0x30
0000796d027de5df  movaps [rsp], xmm6
0000796d027de5e3  movaps [rsp+0x10], xmm9
0000796d027de5e9  movaps [rsp+0x20], xmm1
0000796d027de5ee  lea rdi, [rsp]
0000796d027de5f2  mov esi, 0x00
0000796d027de5f7  mov rax, 0x635FBE957530
0000796d027de601  call rax
0000796d027de603  movaps xmm6, [rsp]
0000796d027de607  add rsp, 0x30
0000796d027de60b  vmovaps xmm0, [rsp]
0000796d027de610  vmovaps xmm1, [rsp+0x10]
0000796d027de616  vmovaps xmm2, [rsp+0x20]
0000796d027de61c  vmovaps xmm3, [rsp+0x30]
0000796d027de622  vmovaps xmm4, [rsp+0x40]
0000796d027de628  vmovaps xmm5, [rsp+0x50]
0000796d027de62e  vmovaps xmm7, [rsp+0x60]
0000796d027de634  vmovaps xmm8, [rsp+0x70]
0000796d027de63a  vmovaps xmm9, [rsp+0x80]
0000796d027de643  vmovaps xmm10, [rsp+0x90]
0000796d027de64c  vmovaps xmm11, [rsp+0xA0]
0000796d027de655  vmovaps xmm12, [rsp+0xB0]
0000796d027de65e  vmovaps xmm13, [rsp+0xC0]
0000796d027de667  vmovaps xmm14, [rsp+0xD0]
0000796d027de670  vmovaps xmm15, [rsp+0xE0]
0000796d027de679  add rsp, 0xF0
0000796d027de680  pop r11
0000796d027de682  pop r10
0000796d027de684  pop r9
0000796d027de686  pop r8
0000796d027de688  pop rsi
0000796d027de689  pop rdi
0000796d027de68a  pop rdx
0000796d027de68b  pop rcx
0000796d027de68c  pop rax
0000796d027de68d  add rsp, 0x08
0000796d027de691  jmp 0x0000796D027DC15E
0000796d027de696  sub rsp, 0x08
0000796d027de69a  push rax
0000796d027de69b  push rcx
0000796d027de69c  push rdx
0000796d027de69d  push rdi
0000796d027de69e  push rsi
0000796d027de69f  push r8
0000796d027de6a1  push r9
0000796d027de6a3  push r10
0000796d027de6a5  push r11
0000796d027de6a7  sub rsp, 0xF0
0000796d027de6ae  vmovaps [rsp], xmm0
0000796d027de6b3  vmovaps [rsp+0x10], xmm1
0000796d027de6b9  vmovaps [rsp+0x20], xmm2
0000796d027de6bf  vmovaps [rsp+0x30], xmm3
0000796d027de6c5  vmovaps [rsp+0x40], xmm4
0000796d027de6cb  vmovaps [rsp+0x50], xmm5
0000796d027de6d1  vmovaps [rsp+0x60], xmm6
0000796d027de6d7  vmovaps [rsp+0x70], xmm7
0000796d027de6dd  vmovaps [rsp+0x80], xmm8
0000796d027de6e6  vmovaps [rsp+0x90], xmm10
0000796d027de6ef  vmovaps [rsp+0xA0], xmm11
0000796d027de6f8  vmovaps [rsp+0xB0], xmm12
0000796d027de701  vmovaps [rsp+0xC0], xmm13
0000796d027de70a  vmovaps [rsp+0xD0], xmm14
0000796d027de713  vmovaps [rsp+0xE0], xmm15
0000796d027de71c  sub rsp, 0x30
0000796d027de720  movaps [rsp], xmm9
0000796d027de725  movaps [rsp+0x10], xmm3
0000796d027de72a  movaps [rsp+0x20], xmm1
0000796d027de72f  lea rdi, [rsp]
0000796d027de733  mov esi, 0x00
0000796d027de738  mov rax, 0x635FBE957530
0000796d027de742  call rax
0000796d027de744  movaps xmm9, [rsp]
0000796d027de749  add rsp, 0x30
0000796d027de74d  vmovaps xmm0, [rsp]
0000796d027de752  vmovaps xmm1, [rsp+0x10]
0000796d027de758  vmovaps xmm2, [rsp+0x20]
0000796d027de75e  vmovaps xmm3, [rsp+0x30]
0000796d027de764  vmovaps xmm4, [rsp+0x40]
0000796d027de76a  vmovaps xmm5, [rsp+0x50]
0000796d027de770  vmovaps xmm6, [rsp+0x60]
0000796d027de776  vmovaps xmm7, [rsp+0x70]
0000796d027de77c  vmovaps xmm8, [rsp+0x80]
0000796d027de785  vmovaps xmm10, [rsp+0x90]
0000796d027de78e  vmovaps xmm11, [rsp+0xA0]
0000796d027de797  vmovaps xmm12, [rsp+0xB0]
0000796d027de7a0  vmovaps xmm13, [rsp+0xC0]
0000796d027de7a9  vmovaps xmm14, [rsp+0xD0]
0000796d027de7b2  vmovaps xmm15, [rsp+0xE0]
0000796d027de7bb  add rsp, 0xF0
0000796d027de7c2  pop r11
0000796d027de7c4  pop r10
0000796d027de7c6  pop r9
0000796d027de7c8  pop r8
0000796d027de7ca  pop rsi
0000796d027de7cb  pop rdi
0000796d027de7cc  pop rdx
0000796d027de7cd  pop rcx
0000796d027de7ce  pop rax
0000796d027de7cf  add rsp, 0x08
0000796d027de7d3  jmp 0x0000796D027DC1AA
0000796d027de7d8  call 0x0000796D026B52F0
0000796d027de7dd  jmp 0x0000796D027DC1B7
0000796d027de7e2  sub rsp, 0x08
0000796d027de7e6  push rax
0000796d027de7e7  push rcx
0000796d027de7e8  push rdx
0000796d027de7e9  push rdi
0000796d027de7ea  push rsi
0000796d027de7eb  push r8
0000796d027de7ed  push r9
0000796d027de7ef  push r10
0000796d027de7f1  push r11
0000796d027de7f3  sub rsp, 0xF0
0000796d027de7fa  vmovaps [rsp], xmm0
0000796d027de7ff  vmovaps [rsp+0x10], xmm1
0000796d027de805  vmovaps [rsp+0x20], xmm2
0000796d027de80b  vmovaps [rsp+0x30], xmm3
0000796d027de811  vmovaps [rsp+0x40], xmm4
0000796d027de817  vmovaps [rsp+0x50], xmm5
0000796d027de81d  vmovaps [rsp+0x60], xmm6
0000796d027de823  vmovaps [rsp+0x70], xmm7
0000796d027de829  vmovaps [rsp+0x80], xmm8
0000796d027de832  vmovaps [rsp+0x90], xmm9
0000796d027de83b  vmovaps [rsp+0xA0], xmm10
0000796d027de844  vmovaps [rsp+0xB0], xmm11
0000796d027de84d  vmovaps [rsp+0xC0], xmm12
0000796d027de856  vmovaps [rsp+0xD0], xmm13
0000796d027de85f  vmovaps [rsp+0xE0], xmm14
0000796d027de868  sub rsp, 0x30
0000796d027de86c  movaps [rsp], xmm15
0000796d027de871  movaps [rsp+0x10], xmm3
0000796d027de876  movaps [rsp+0x20], xmm7
0000796d027de87b  lea rdi, [rsp]
0000796d027de87f  mov esi, 0x00
0000796d027de884  mov rax, 0x635FBE957530
0000796d027de88e  call rax
0000796d027de890  movaps xmm15, [rsp]
0000796d027de895  add rsp, 0x30
0000796d027de899  vmovaps xmm0, [rsp]
0000796d027de89e  vmovaps xmm1, [rsp+0x10]
0000796d027de8a4  vmovaps xmm2, [rsp+0x20]
0000796d027de8aa  vmovaps xmm3, [rsp+0x30]
0000796d027de8b0  vmovaps xmm4, [rsp+0x40]
0000796d027de8b6  vmovaps xmm5, [rsp+0x50]
0000796d027de8bc  vmovaps xmm6, [rsp+0x60]
0000796d027de8c2  vmovaps xmm7, [rsp+0x70]
0000796d027de8c8  vmovaps xmm8, [rsp+0x80]
0000796d027de8d1  vmovaps xmm9, [rsp+0x90]
0000796d027de8da  vmovaps xmm10, [rsp+0xA0]
0000796d027de8e3  vmovaps xmm11, [rsp+0xB0]
0000796d027de8ec  vmovaps xmm12, [rsp+0xC0]
0000796d027de8f5  vmovaps xmm13, [rsp+0xD0]
0000796d027de8fe  vmovaps xmm14, [rsp+0xE0]
0000796d027de907  add rsp, 0xF0
0000796d027de90e  pop r11
0000796d027de910  pop r10
0000796d027de912  pop r9
0000796d027de914  pop r8
0000796d027de916  pop rsi
0000796d027de917  pop rdi
0000796d027de918  pop rdx
0000796d027de919  pop rcx
0000796d027de91a  pop rax
0000796d027de91b  add rsp, 0x08
0000796d027de91f  jmp 0x0000796D027DC1E3
0000796d027de924  sub rsp, 0x08
0000796d027de928  push rax
0000796d027de929  push rcx
0000796d027de92a  push rdx
0000796d027de92b  push rdi
0000796d027de92c  push rsi
0000796d027de92d  push r8
0000796d027de92f  push r9
0000796d027de931  push r10
0000796d027de933  push r11
0000796d027de935  sub rsp, 0xF0
0000796d027de93c  vmovaps [rsp], xmm0
0000796d027de941  vmovaps [rsp+0x10], xmm1
0000796d027de947  vmovaps [rsp+0x20], xmm2
0000796d027de94d  vmovaps [rsp+0x30], xmm4
0000796d027de953  vmovaps [rsp+0x40], xmm5
0000796d027de959  vmovaps [rsp+0x50], xmm6
0000796d027de95f  vmovaps [rsp+0x60], xmm7
0000796d027de965  vmovaps [rsp+0x70], xmm8
0000796d027de96b  vmovaps [rsp+0x80], xmm9
0000796d027de974  vmovaps [rsp+0x90], xmm10
0000796d027de97d  vmovaps [rsp+0xA0], xmm11
0000796d027de986  vmovaps [rsp+0xB0], xmm12
0000796d027de98f  vmovaps [rsp+0xC0], xmm13
0000796d027de998  vmovaps [rsp+0xD0], xmm14
0000796d027de9a1  vmovaps [rsp+0xE0], xmm15
0000796d027de9aa  sub rsp, 0x30
0000796d027de9ae  movaps [rsp], xmm3
0000796d027de9b2  movaps [rsp+0x10], xmm1
0000796d027de9b7  movaps [rsp+0x20], xmm15
0000796d027de9bd  lea rdi, [rsp]
0000796d027de9c1  mov esi, 0x00
0000796d027de9c6  mov rax, 0x635FBE957530
0000796d027de9d0  call rax
0000796d027de9d2  movaps xmm3, [rsp]
0000796d027de9d6  add rsp, 0x30
0000796d027de9da  vmovaps xmm0, [rsp]
0000796d027de9df  vmovaps xmm1, [rsp+0x10]
0000796d027de9e5  vmovaps xmm2, [rsp+0x20]
0000796d027de9eb  vmovaps xmm4, [rsp+0x30]
0000796d027de9f1  vmovaps xmm5, [rsp+0x40]
0000796d027de9f7  vmovaps xmm6, [rsp+0x50]
0000796d027de9fd  vmovaps xmm7, [rsp+0x60]
0000796d027dea03  vmovaps xmm8, [rsp+0x70]
0000796d027dea09  vmovaps xmm9, [rsp+0x80]
0000796d027dea12  vmovaps xmm10, [rsp+0x90]
0000796d027dea1b  vmovaps xmm11, [rsp+0xA0]
0000796d027dea24  vmovaps xmm12, [rsp+0xB0]
0000796d027dea2d  vmovaps xmm13, [rsp+0xC0]
0000796d027dea36  vmovaps xmm14, [rsp+0xD0]
0000796d027dea3f  vmovaps xmm15, [rsp+0xE0]
0000796d027dea48  add rsp, 0xF0
0000796d027dea4f  pop r11
0000796d027dea51  pop r10
0000796d027dea53  pop r9
0000796d027dea55  pop r8
0000796d027dea57  pop rsi
0000796d027dea58  pop rdi
0000796d027dea59  pop rdx
0000796d027dea5a  pop rcx
0000796d027dea5b  pop rax
0000796d027dea5c  add rsp, 0x08
0000796d027dea60  jmp 0x0000796D027DC272
0000796d027dea65  call 0x0000796D026B52F0
0000796d027dea6a  jmp 0x0000796D027DC27C
0000796d027dea6f  sub rsp, 0x08
0000796d027dea73  push rax
0000796d027dea74  push rcx
0000796d027dea75  push rdx
0000796d027dea76  push rdi
0000796d027dea77  push rsi
0000796d027dea78  push r8
0000796d027dea7a  push r9
0000796d027dea7c  push r10
0000796d027dea7e  push r11
0000796d027dea80  sub rsp, 0xF0
0000796d027dea87  vmovaps [rsp], xmm0
0000796d027dea8c  vmovaps [rsp+0x10], xmm1
0000796d027dea92  vmovaps [rsp+0x20], xmm2
0000796d027dea98  vmovaps [rsp+0x30], xmm3
0000796d027dea9e  vmovaps [rsp+0x40], xmm4
0000796d027deaa4  vmovaps [rsp+0x50], xmm5
0000796d027deaaa  vmovaps [rsp+0x60], xmm6
0000796d027deab0  vmovaps [rsp+0x70], xmm7
0000796d027deab6  vmovaps [rsp+0x80], xmm8
0000796d027deabf  vmovaps [rsp+0x90], xmm9
0000796d027deac8  vmovaps [rsp+0xA0], xmm10
0000796d027dead1  vmovaps [rsp+0xB0], xmm11
0000796d027deada  vmovaps [rsp+0xC0], xmm12
0000796d027deae3  vmovaps [rsp+0xD0], xmm13
0000796d027deaec  vmovaps [rsp+0xE0], xmm14
0000796d027deaf5  sub rsp, 0x30
0000796d027deaf9  movaps [rsp], xmm15
0000796d027deafe  movaps [rsp+0x10], xmm14
0000796d027deb04  movaps [rsp+0x20], xmm4
0000796d027deb09  lea rdi, [rsp]
0000796d027deb0d  mov esi, 0x00
0000796d027deb12  mov rax, 0x635FBE957530
0000796d027deb1c  call rax
0000796d027deb1e  movaps xmm15, [rsp]
0000796d027deb23  add rsp, 0x30
0000796d027deb27  vmovaps xmm0, [rsp]
0000796d027deb2c  vmovaps xmm1, [rsp+0x10]
0000796d027deb32  vmovaps xmm2, [rsp+0x20]
0000796d027deb38  vmovaps xmm3, [rsp+0x30]
0000796d027deb3e  vmovaps xmm4, [rsp+0x40]
0000796d027deb44  vmovaps xmm5, [rsp+0x50]
0000796d027deb4a  vmovaps xmm6, [rsp+0x60]
0000796d027deb50  vmovaps xmm7, [rsp+0x70]
0000796d027deb56  vmovaps xmm8, [rsp+0x80]
0000796d027deb5f  vmovaps xmm9, [rsp+0x90]
0000796d027deb68  vmovaps xmm10, [rsp+0xA0]
0000796d027deb71  vmovaps xmm11, [rsp+0xB0]
0000796d027deb7a  vmovaps xmm12, [rsp+0xC0]
0000796d027deb83  vmovaps xmm13, [rsp+0xD0]
0000796d027deb8c  vmovaps xmm14, [rsp+0xE0]
0000796d027deb95  add rsp, 0xF0
0000796d027deb9c  pop r11
0000796d027deb9e  pop r10
0000796d027deba0  pop r9
0000796d027deba2  pop r8
0000796d027deba4  pop rsi
0000796d027deba5  pop rdi
0000796d027deba6  pop rdx
0000796d027deba7  pop rcx
0000796d027deba8  pop rax
0000796d027deba9  add rsp, 0x08
0000796d027debad  jmp 0x0000796D027DC2AA
0000796d027debb2  sub rsp, 0x08
0000796d027debb6  push rax
0000796d027debb7  push rcx
0000796d027debb8  push rdx
0000796d027debb9  push rdi
0000796d027debba  push rsi
0000796d027debbb  push r8
0000796d027debbd  push r9
0000796d027debbf  push r10
0000796d027debc1  push r11
0000796d027debc3  sub rsp, 0xF0
0000796d027debca  vmovaps [rsp], xmm0
0000796d027debcf  vmovaps [rsp+0x10], xmm1
0000796d027debd5  vmovaps [rsp+0x20], xmm2
0000796d027debdb  vmovaps [rsp+0x30], xmm3
0000796d027debe1  vmovaps [rsp+0x40], xmm4
0000796d027debe7  vmovaps [rsp+0x50], xmm5
0000796d027debed  vmovaps [rsp+0x60], xmm6
0000796d027debf3  vmovaps [rsp+0x70], xmm7
0000796d027debf9  vmovaps [rsp+0x80], xmm8
0000796d027dec02  vmovaps [rsp+0x90], xmm9
0000796d027dec0b  vmovaps [rsp+0xA0], xmm10
0000796d027dec14  vmovaps [rsp+0xB0], xmm11
0000796d027dec1d  vmovaps [rsp+0xC0], xmm12
0000796d027dec26  vmovaps [rsp+0xD0], xmm13
0000796d027dec2f  vmovaps [rsp+0xE0], xmm15
0000796d027dec38  sub rsp, 0x30
0000796d027dec3c  movaps [rsp], xmm14
0000796d027dec41  movaps [rsp+0x10], xmm2
0000796d027dec46  movaps [rsp+0x20], xmm1
0000796d027dec4b  lea rdi, [rsp]
0000796d027dec4f  mov esi, 0x00
0000796d027dec54  mov rax, 0x635FBE957530
0000796d027dec5e  call rax
0000796d027dec60  movaps xmm14, [rsp]
0000796d027dec65  add rsp, 0x30
0000796d027dec69  vmovaps xmm0, [rsp]
0000796d027dec6e  vmovaps xmm1, [rsp+0x10]
0000796d027dec74  vmovaps xmm2, [rsp+0x20]
0000796d027dec7a  vmovaps xmm3, [rsp+0x30]
0000796d027dec80  vmovaps xmm4, [rsp+0x40]
0000796d027dec86  vmovaps xmm5, [rsp+0x50]
0000796d027dec8c  vmovaps xmm6, [rsp+0x60]
0000796d027dec92  vmovaps xmm7, [rsp+0x70]
0000796d027dec98  vmovaps xmm8, [rsp+0x80]
0000796d027deca1  vmovaps xmm9, [rsp+0x90]
0000796d027decaa  vmovaps xmm10, [rsp+0xA0]
0000796d027decb3  vmovaps xmm11, [rsp+0xB0]
0000796d027decbc  vmovaps xmm12, [rsp+0xC0]
0000796d027decc5  vmovaps xmm13, [rsp+0xD0]
0000796d027decce  vmovaps xmm15, [rsp+0xE0]
0000796d027decd7  add rsp, 0xF0
0000796d027decde  pop r11
0000796d027dece0  pop r10
0000796d027dece2  pop r9
0000796d027dece4  pop r8
0000796d027dece6  pop rsi
0000796d027dece7  pop rdi
0000796d027dece8  pop rdx
0000796d027dece9  pop rcx
0000796d027decea  pop rax
0000796d027deceb  add rsp, 0x08
0000796d027decef  jmp 0x0000796D027DC2D0
0000796d027decf4  sub rsp, 0x08
0000796d027decf8  push rax
0000796d027decf9  push rcx
0000796d027decfa  push rdx
0000796d027decfb  push rdi
0000796d027decfc  push rsi
0000796d027decfd  push r8
0000796d027decff  push r9
0000796d027ded01  push r10
0000796d027ded03  push r11
0000796d027ded05  sub rsp, 0xF0
0000796d027ded0c  vmovaps [rsp], xmm0
0000796d027ded11  vmovaps [rsp+0x10], xmm2
0000796d027ded17  vmovaps [rsp+0x20], xmm3
0000796d027ded1d  vmovaps [rsp+0x30], xmm4
0000796d027ded23  vmovaps [rsp+0x40], xmm5
0000796d027ded29  vmovaps [rsp+0x50], xmm6
0000796d027ded2f  vmovaps [rsp+0x60], xmm7
0000796d027ded35  vmovaps [rsp+0x70], xmm8
0000796d027ded3b  vmovaps [rsp+0x80], xmm9
0000796d027ded44  vmovaps [rsp+0x90], xmm10
0000796d027ded4d  vmovaps [rsp+0xA0], xmm11
0000796d027ded56  vmovaps [rsp+0xB0], xmm12
0000796d027ded5f  vmovaps [rsp+0xC0], xmm13
0000796d027ded68  vmovaps [rsp+0xD0], xmm14
0000796d027ded71  vmovaps [rsp+0xE0], xmm15
0000796d027ded7a  sub rsp, 0x30
0000796d027ded7e  movaps [rsp], xmm1
0000796d027ded82  movaps [rsp+0x10], xmm4
0000796d027ded87  movaps [rsp+0x20], xmm9
0000796d027ded8d  lea rdi, [rsp]
0000796d027ded91  mov esi, 0x00
0000796d027ded96  mov rax, 0x635FBE957530
0000796d027deda0  call rax
0000796d027deda2  movaps xmm1, [rsp]
0000796d027deda6  add rsp, 0x30
0000796d027dedaa  vmovaps xmm0, [rsp]
0000796d027dedaf  vmovaps xmm2, [rsp+0x10]
0000796d027dedb5  vmovaps xmm3, [rsp+0x20]
0000796d027dedbb  vmovaps xmm4, [rsp+0x30]
0000796d027dedc1  vmovaps xmm5, [rsp+0x40]
0000796d027dedc7  vmovaps xmm6, [rsp+0x50]
0000796d027dedcd  vmovaps xmm7, [rsp+0x60]
0000796d027dedd3  vmovaps xmm8, [rsp+0x70]
0000796d027dedd9  vmovaps xmm9, [rsp+0x80]
0000796d027dede2  vmovaps xmm10, [rsp+0x90]
0000796d027dedeb  vmovaps xmm11, [rsp+0xA0]
0000796d027dedf4  vmovaps xmm12, [rsp+0xB0]
0000796d027dedfd  vmovaps xmm13, [rsp+0xC0]
0000796d027dee06  vmovaps xmm14, [rsp+0xD0]
0000796d027dee0f  vmovaps xmm15, [rsp+0xE0]
0000796d027dee18  add rsp, 0xF0
0000796d027dee1f  pop r11
0000796d027dee21  pop r10
0000796d027dee23  pop r9
0000796d027dee25  pop r8
0000796d027dee27  pop rsi
0000796d027dee28  pop rdi
0000796d027dee29  pop rdx
0000796d027dee2a  pop rcx
0000796d027dee2b  pop rax
0000796d027dee2c  add rsp, 0x08
0000796d027dee30  jmp 0x0000796D027DC2EE
0000796d027dee35  sub rsp, 0x08
0000796d027dee39  push rax
0000796d027dee3a  push rcx
0000796d027dee3b  push rdx
0000796d027dee3c  push rdi
0000796d027dee3d  push rsi
0000796d027dee3e  push r8
0000796d027dee40  push r9
0000796d027dee42  push r10
0000796d027dee44  push r11
0000796d027dee46  sub rsp, 0xF0
0000796d027dee4d  vmovaps [rsp], xmm0
0000796d027dee52  vmovaps [rsp+0x10], xmm1
0000796d027dee58  vmovaps [rsp+0x20], xmm2
0000796d027dee5e  vmovaps [rsp+0x30], xmm3
0000796d027dee64  vmovaps [rsp+0x40], xmm5
0000796d027dee6a  vmovaps [rsp+0x50], xmm6
0000796d027dee70  vmovaps [rsp+0x60], xmm7
0000796d027dee76  vmovaps [rsp+0x70], xmm8
0000796d027dee7c  vmovaps [rsp+0x80], xmm9
0000796d027dee85  vmovaps [rsp+0x90], xmm10
0000796d027dee8e  vmovaps [rsp+0xA0], xmm11
0000796d027dee97  vmovaps [rsp+0xB0], xmm12
0000796d027deea0  vmovaps [rsp+0xC0], xmm13
0000796d027deea9  vmovaps [rsp+0xD0], xmm14
0000796d027deeb2  vmovaps [rsp+0xE0], xmm15
0000796d027deebb  sub rsp, 0x30
0000796d027deebf  movaps [rsp], xmm4
0000796d027deec3  movaps [rsp+0x10], xmm2
0000796d027deec8  movaps [rsp+0x20], xmm9
0000796d027deece  lea rdi, [rsp]
0000796d027deed2  mov esi, 0x00
0000796d027deed7  mov rax, 0x635FBE957530
0000796d027deee1  call rax
0000796d027deee3  movaps xmm4, [rsp]
0000796d027deee7  add rsp, 0x30
0000796d027deeeb  vmovaps xmm0, [rsp]
0000796d027deef0  vmovaps xmm1, [rsp+0x10]
0000796d027deef6  vmovaps xmm2, [rsp+0x20]
0000796d027deefc  vmovaps xmm3, [rsp+0x30]
0000796d027def02  vmovaps xmm5, [rsp+0x40]
0000796d027def08  vmovaps xmm6, [rsp+0x50]
0000796d027def0e  vmovaps xmm7, [rsp+0x60]
0000796d027def14  vmovaps xmm8, [rsp+0x70]
0000796d027def1a  vmovaps xmm9, [rsp+0x80]
0000796d027def23  vmovaps xmm10, [rsp+0x90]
0000796d027def2c  vmovaps xmm11, [rsp+0xA0]
0000796d027def35  vmovaps xmm12, [rsp+0xB0]
0000796d027def3e  vmovaps xmm13, [rsp+0xC0]
0000796d027def47  vmovaps xmm14, [rsp+0xD0]
0000796d027def50  vmovaps xmm15, [rsp+0xE0]
0000796d027def59  add rsp, 0xF0
0000796d027def60  pop r11
0000796d027def62  pop r10
0000796d027def64  pop r9
0000796d027def66  pop r8
0000796d027def68  pop rsi
0000796d027def69  pop rdi
0000796d027def6a  pop rdx
0000796d027def6b  pop rcx
0000796d027def6c  pop rax
0000796d027def6d  add rsp, 0x08
0000796d027def71  jmp 0x0000796D027DC31E
0000796d027def76  sub rsp, 0x08
0000796d027def7a  push rax
0000796d027def7b  push rcx
0000796d027def7c  push rdx
0000796d027def7d  push rdi
0000796d027def7e  push rsi
0000796d027def7f  push r8
0000796d027def81  push r9
0000796d027def83  push r10
0000796d027def85  push r11
0000796d027def87  sub rsp, 0xF0
0000796d027def8e  vmovaps [rsp], xmm0
0000796d027def93  vmovaps [rsp+0x10], xmm1
0000796d027def99  vmovaps [rsp+0x20], xmm2
0000796d027def9f  vmovaps [rsp+0x30], xmm3
0000796d027defa5  vmovaps [rsp+0x40], xmm4
0000796d027defab  vmovaps [rsp+0x50], xmm5
0000796d027defb1  vmovaps [rsp+0x60], xmm6
0000796d027defb7  vmovaps [rsp+0x70], xmm7
0000796d027defbd  vmovaps [rsp+0x80], xmm8
0000796d027defc6  vmovaps [rsp+0x90], xmm10
0000796d027defcf  vmovaps [rsp+0xA0], xmm11
0000796d027defd8  vmovaps [rsp+0xB0], xmm12
0000796d027defe1  vmovaps [rsp+0xC0], xmm13
0000796d027defea  vmovaps [rsp+0xD0], xmm14
0000796d027deff3  vmovaps [rsp+0xE0], xmm15
0000796d027deffc  sub rsp, 0x30
0000796d027df000  movaps [rsp], xmm9
0000796d027df005  movaps [rsp+0x10], xmm2
0000796d027df00a  movaps [rsp+0x20], xmm1
0000796d027df00f  lea rdi, [rsp]
0000796d027df013  mov esi, 0x00
0000796d027df018  mov rax, 0x635FBE957530
0000796d027df022  call rax
0000796d027df024  movaps xmm9, [rsp]
0000796d027df029  add rsp, 0x30
0000796d027df02d  vmovaps xmm0, [rsp]
0000796d027df032  vmovaps xmm1, [rsp+0x10]
0000796d027df038  vmovaps xmm2, [rsp+0x20]
0000796d027df03e  vmovaps xmm3, [rsp+0x30]
0000796d027df044  vmovaps xmm4, [rsp+0x40]
0000796d027df04a  vmovaps xmm5, [rsp+0x50]
0000796d027df050  vmovaps xmm6, [rsp+0x60]
0000796d027df056  vmovaps xmm7, [rsp+0x70]
0000796d027df05c  vmovaps xmm8, [rsp+0x80]
0000796d027df065  vmovaps xmm10, [rsp+0x90]
0000796d027df06e  vmovaps xmm11, [rsp+0xA0]
0000796d027df077  vmovaps xmm12, [rsp+0xB0]
0000796d027df080  vmovaps xmm13, [rsp+0xC0]
0000796d027df089  vmovaps xmm14, [rsp+0xD0]
0000796d027df092  vmovaps xmm15, [rsp+0xE0]
0000796d027df09b  add rsp, 0xF0
0000796d027df0a2  pop r11
0000796d027df0a4  pop r10
0000796d027df0a6  pop r9
0000796d027df0a8  pop r8
0000796d027df0aa  pop rsi
0000796d027df0ab  pop rdi
0000796d027df0ac  pop rdx
0000796d027df0ad  pop rcx
0000796d027df0ae  pop rax
0000796d027df0af  add rsp, 0x08
0000796d027df0b3  jmp 0x0000796D027DC354
0000796d027df0b8  sub rsp, 0x08
0000796d027df0bc  push rax
0000796d027df0bd  push rcx
0000796d027df0be  push rdx
0000796d027df0bf  push rdi
0000796d027df0c0  push rsi
0000796d027df0c1  push r8
0000796d027df0c3  push r9
0000796d027df0c5  push r10
0000796d027df0c7  push r11
0000796d027df0c9  sub rsp, 0xF0
0000796d027df0d0  vmovaps [rsp], xmm0
0000796d027df0d5  vmovaps [rsp+0x10], xmm2
0000796d027df0db  vmovaps [rsp+0x20], xmm3
0000796d027df0e1  vmovaps [rsp+0x30], xmm4
0000796d027df0e7  vmovaps [rsp+0x40], xmm5
0000796d027df0ed  vmovaps [rsp+0x50], xmm6
0000796d027df0f3  vmovaps [rsp+0x60], xmm7
0000796d027df0f9  vmovaps [rsp+0x70], xmm8
0000796d027df0ff  vmovaps [rsp+0x80], xmm9
0000796d027df108  vmovaps [rsp+0x90], xmm10
0000796d027df111  vmovaps [rsp+0xA0], xmm11
0000796d027df11a  vmovaps [rsp+0xB0], xmm12
0000796d027df123  vmovaps [rsp+0xC0], xmm13
0000796d027df12c  vmovaps [rsp+0xD0], xmm14
0000796d027df135  vmovaps [rsp+0xE0], xmm15
0000796d027df13e  sub rsp, 0x30
0000796d027df142  movaps [rsp], xmm1
0000796d027df146  movaps [rsp+0x10], xmm15
0000796d027df14c  movaps [rsp+0x20], xmm6
0000796d027df151  lea rdi, [rsp]
0000796d027df155  mov esi, 0x00
0000796d027df15a  mov rax, 0x635FBE957530
0000796d027df164  call rax
0000796d027df166  movaps xmm1, [rsp]
0000796d027df16a  add rsp, 0x30
0000796d027df16e  vmovaps xmm0, [rsp]
0000796d027df173  vmovaps xmm2, [rsp+0x10]
0000796d027df179  vmovaps xmm3, [rsp+0x20]
0000796d027df17f  vmovaps xmm4, [rsp+0x30]
0000796d027df185  vmovaps xmm5, [rsp+0x40]
0000796d027df18b  vmovaps xmm6, [rsp+0x50]
0000796d027df191  vmovaps xmm7, [rsp+0x60]
0000796d027df197  vmovaps xmm8, [rsp+0x70]
0000796d027df19d  vmovaps xmm9, [rsp+0x80]
0000796d027df1a6  vmovaps xmm10, [rsp+0x90]
0000796d027df1af  vmovaps xmm11, [rsp+0xA0]
0000796d027df1b8  vmovaps xmm12, [rsp+0xB0]
0000796d027df1c1  vmovaps xmm13, [rsp+0xC0]
0000796d027df1ca  vmovaps xmm14, [rsp+0xD0]
0000796d027df1d3  vmovaps xmm15, [rsp+0xE0]
0000796d027df1dc  add rsp, 0xF0
0000796d027df1e3  pop r11
0000796d027df1e5  pop r10
0000796d027df1e7  pop r9
0000796d027df1e9  pop r8
0000796d027df1eb  pop rsi
0000796d027df1ec  pop rdi
0000796d027df1ed  pop rdx
0000796d027df1ee  pop rcx
0000796d027df1ef  pop rax
0000796d027df1f0  add rsp, 0x08
0000796d027df1f4  jmp 0x0000796D027DC375
0000796d027df1f9  sub rsp, 0x08
0000796d027df1fd  push rax
0000796d027df1fe  push rcx
0000796d027df1ff  push rdx
0000796d027df200  push rdi
0000796d027df201  push rsi
0000796d027df202  push r8
0000796d027df204  push r9
0000796d027df206  push r10
0000796d027df208  push r11
0000796d027df20a  sub rsp, 0xF0
0000796d027df211  vmovaps [rsp], xmm0
0000796d027df216  vmovaps [rsp+0x10], xmm1
0000796d027df21c  vmovaps [rsp+0x20], xmm2
0000796d027df222  vmovaps [rsp+0x30], xmm3
0000796d027df228  vmovaps [rsp+0x40], xmm4
0000796d027df22e  vmovaps [rsp+0x50], xmm5
0000796d027df234  vmovaps [rsp+0x60], xmm6
0000796d027df23a  vmovaps [rsp+0x70], xmm7
0000796d027df240  vmovaps [rsp+0x80], xmm8
0000796d027df249  vmovaps [rsp+0x90], xmm9
0000796d027df252  vmovaps [rsp+0xA0], xmm10
0000796d027df25b  vmovaps [rsp+0xB0], xmm11
0000796d027df264  vmovaps [rsp+0xC0], xmm12
0000796d027df26d  vmovaps [rsp+0xD0], xmm13
0000796d027df276  vmovaps [rsp+0xE0], xmm14
0000796d027df27f  sub rsp, 0x30
0000796d027df283  movaps [rsp], xmm15
0000796d027df288  movaps [rsp+0x10], xmm5
0000796d027df28d  movaps [rsp+0x20], xmm3
0000796d027df292  lea rdi, [rsp]
0000796d027df296  mov esi, 0x00
0000796d027df29b  mov rax, 0x635FBE957530
0000796d027df2a5  call rax
0000796d027df2a7  movaps xmm15, [rsp]
0000796d027df2ac  add rsp, 0x30
0000796d027df2b0  vmovaps xmm0, [rsp]
0000796d027df2b5  vmovaps xmm1, [rsp+0x10]
0000796d027df2bb  vmovaps xmm2, [rsp+0x20]
0000796d027df2c1  vmovaps xmm3, [rsp+0x30]
0000796d027df2c7  vmovaps xmm4, [rsp+0x40]
0000796d027df2cd  vmovaps xmm5, [rsp+0x50]
0000796d027df2d3  vmovaps xmm6, [rsp+0x60]
0000796d027df2d9  vmovaps xmm7, [rsp+0x70]
0000796d027df2df  vmovaps xmm8, [rsp+0x80]
0000796d027df2e8  vmovaps xmm9, [rsp+0x90]
0000796d027df2f1  vmovaps xmm10, [rsp+0xA0]
0000796d027df2fa  vmovaps xmm11, [rsp+0xB0]
0000796d027df303  vmovaps xmm12, [rsp+0xC0]
0000796d027df30c  vmovaps xmm13, [rsp+0xD0]
0000796d027df315  vmovaps xmm14, [rsp+0xE0]
0000796d027df31e  add rsp, 0xF0
0000796d027df325  pop r11
0000796d027df327  pop r10
0000796d027df329  pop r9
0000796d027df32b  pop r8
0000796d027df32d  pop rsi
0000796d027df32e  pop rdi
0000796d027df32f  pop rdx
0000796d027df330  pop rcx
0000796d027df331  pop rax
0000796d027df332  add rsp, 0x08
0000796d027df336  jmp 0x0000796D027DC38F
0000796d027df33b  sub rsp, 0x08
0000796d027df33f  push rax
0000796d027df340  push rcx
0000796d027df341  push rdx
0000796d027df342  push rdi
0000796d027df343  push rsi
0000796d027df344  push r8
0000796d027df346  push r9
0000796d027df348  push r10
0000796d027df34a  push r11
0000796d027df34c  sub rsp, 0xF0
0000796d027df353  vmovaps [rsp], xmm0
0000796d027df358  vmovaps [rsp+0x10], xmm1
0000796d027df35e  vmovaps [rsp+0x20], xmm2
0000796d027df364  vmovaps [rsp+0x30], xmm3
0000796d027df36a  vmovaps [rsp+0x40], xmm4
0000796d027df370  vmovaps [rsp+0x50], xmm6
0000796d027df376  vmovaps [rsp+0x60], xmm7
0000796d027df37c  vmovaps [rsp+0x70], xmm8
0000796d027df382  vmovaps [rsp+0x80], xmm9
0000796d027df38b  vmovaps [rsp+0x90], xmm10
0000796d027df394  vmovaps [rsp+0xA0], xmm11
0000796d027df39d  vmovaps [rsp+0xB0], xmm12
0000796d027df3a6  vmovaps [rsp+0xC0], xmm13
0000796d027df3af  vmovaps [rsp+0xD0], xmm14
0000796d027df3b8  vmovaps [rsp+0xE0], xmm15
0000796d027df3c1  sub rsp, 0x30
0000796d027df3c5  movaps [rsp], xmm5
0000796d027df3c9  movaps [rsp+0x10], xmm8
0000796d027df3cf  movaps [rsp+0x20], xmm6
0000796d027df3d4  lea rdi, [rsp]
0000796d027df3d8  mov esi, 0x00
0000796d027df3dd  mov rax, 0x635FBE957530
0000796d027df3e7  call rax
0000796d027df3e9  movaps xmm5, [rsp]
0000796d027df3ed  add rsp, 0x30
0000796d027df3f1  vmovaps xmm0, [rsp]
0000796d027df3f6  vmovaps xmm1, [rsp+0x10]
0000796d027df3fc  vmovaps xmm2, [rsp+0x20]
0000796d027df402  vmovaps xmm3, [rsp+0x30]
0000796d027df408  vmovaps xmm4, [rsp+0x40]
0000796d027df40e  vmovaps xmm6, [rsp+0x50]
0000796d027df414  vmovaps xmm7, [rsp+0x60]
0000796d027df41a  vmovaps xmm8, [rsp+0x70]
0000796d027df420  vmovaps xmm9, [rsp+0x80]
0000796d027df429  vmovaps xmm10, [rsp+0x90]
0000796d027df432  vmovaps xmm11, [rsp+0xA0]
0000796d027df43b  vmovaps xmm12, [rsp+0xB0]
0000796d027df444  vmovaps xmm13, [rsp+0xC0]
0000796d027df44d  vmovaps xmm14, [rsp+0xD0]
0000796d027df456  vmovaps xmm15, [rsp+0xE0]
0000796d027df45f  add rsp, 0xF0
0000796d027df466  pop r11
0000796d027df468  pop r10
0000796d027df46a  pop r9
0000796d027df46c  pop r8
0000796d027df46e  pop rsi
0000796d027df46f  pop rdi
0000796d027df470  pop rdx
0000796d027df471  pop rcx
0000796d027df472  pop rax
0000796d027df473  add rsp, 0x08
0000796d027df477  jmp 0x0000796D027DC3B3
0000796d027df47c  sub rsp, 0x08
0000796d027df480  push rax
0000796d027df481  push rcx
0000796d027df482  push rdx
0000796d027df483  push rdi
0000796d027df484  push rsi
0000796d027df485  push r8
0000796d027df487  push r9
0000796d027df489  push r10
0000796d027df48b  push r11
0000796d027df48d  sub rsp, 0xF0
0000796d027df494  vmovaps [rsp], xmm0
0000796d027df499  vmovaps [rsp+0x10], xmm1
0000796d027df49f  vmovaps [rsp+0x20], xmm2
0000796d027df4a5  vmovaps [rsp+0x30], xmm3
0000796d027df4ab  vmovaps [rsp+0x40], xmm4
0000796d027df4b1  vmovaps [rsp+0x50], xmm5
0000796d027df4b7  vmovaps [rsp+0x60], xmm7
0000796d027df4bd  vmovaps [rsp+0x70], xmm8
0000796d027df4c3  vmovaps [rsp+0x80], xmm9
0000796d027df4cc  vmovaps [rsp+0x90], xmm10
0000796d027df4d5  vmovaps [rsp+0xA0], xmm11
0000796d027df4de  vmovaps [rsp+0xB0], xmm12
0000796d027df4e7  vmovaps [rsp+0xC0], xmm13
0000796d027df4f0  vmovaps [rsp+0xD0], xmm14
0000796d027df4f9  vmovaps [rsp+0xE0], xmm15
0000796d027df502  sub rsp, 0x30
0000796d027df506  movaps [rsp], xmm6
0000796d027df50a  movaps [rsp+0x10], xmm10
0000796d027df510  movaps [rsp+0x20], xmm8
0000796d027df516  lea rdi, [rsp]
0000796d027df51a  mov esi, 0x00
0000796d027df51f  mov rax, 0x635FBE957530
0000796d027df529  call rax
0000796d027df52b  movaps xmm6, [rsp]
0000796d027df52f  add rsp, 0x30
0000796d027df533  vmovaps xmm0, [rsp]
0000796d027df538  vmovaps xmm1, [rsp+0x10]
0000796d027df53e  vmovaps xmm2, [rsp+0x20]
0000796d027df544  vmovaps xmm3, [rsp+0x30]
0000796d027df54a  vmovaps xmm4, [rsp+0x40]
0000796d027df550  vmovaps xmm5, [rsp+0x50]
0000796d027df556  vmovaps xmm7, [rsp+0x60]
0000796d027df55c  vmovaps xmm8, [rsp+0x70]
0000796d027df562  vmovaps xmm9, [rsp+0x80]
0000796d027df56b  vmovaps xmm10, [rsp+0x90]
0000796d027df574  vmovaps xmm11, [rsp+0xA0]
0000796d027df57d  vmovaps xmm12, [rsp+0xB0]
0000796d027df586  vmovaps xmm13, [rsp+0xC0]
0000796d027df58f  vmovaps xmm14, [rsp+0xD0]
0000796d027df598  vmovaps xmm15, [rsp+0xE0]
0000796d027df5a1  add rsp, 0xF0
0000796d027df5a8  pop r11
0000796d027df5aa  pop r10
0000796d027df5ac  pop r9
0000796d027df5ae  pop r8
0000796d027df5b0  pop rsi
0000796d027df5b1  pop rdi
0000796d027df5b2  pop rdx
0000796d027df5b3  pop rcx
0000796d027df5b4  pop rax
0000796d027df5b5  add rsp, 0x08
0000796d027df5b9  jmp 0x0000796D027DC3D8
0000796d027df5be  sub rsp, 0x08
0000796d027df5c2  push rax
0000796d027df5c3  push rcx
0000796d027df5c4  push rdx
0000796d027df5c5  push rdi
0000796d027df5c6  push rsi
0000796d027df5c7  push r8
0000796d027df5c9  push r9
0000796d027df5cb  push r10
0000796d027df5cd  push r11
0000796d027df5cf  sub rsp, 0xF0
0000796d027df5d6  vmovaps [rsp], xmm0
0000796d027df5db  vmovaps [rsp+0x10], xmm1
0000796d027df5e1  vmovaps [rsp+0x20], xmm2
0000796d027df5e7  vmovaps [rsp+0x30], xmm3
0000796d027df5ed  vmovaps [rsp+0x40], xmm4
0000796d027df5f3  vmovaps [rsp+0x50], xmm5
0000796d027df5f9  vmovaps [rsp+0x60], xmm6
0000796d027df5ff  vmovaps [rsp+0x70], xmm7
0000796d027df605  vmovaps [rsp+0x80], xmm8
0000796d027df60e  vmovaps [rsp+0x90], xmm9
0000796d027df617  vmovaps [rsp+0xA0], xmm11
0000796d027df620  vmovaps [rsp+0xB0], xmm12
0000796d027df629  vmovaps [rsp+0xC0], xmm13
0000796d027df632  vmovaps [rsp+0xD0], xmm14
0000796d027df63b  vmovaps [rsp+0xE0], xmm15
0000796d027df644  sub rsp, 0x30
0000796d027df648  movaps [rsp], xmm10
0000796d027df64d  movaps [rsp+0x10], xmm8
0000796d027df653  movaps [rsp+0x20], xmm14
0000796d027df659  lea rdi, [rsp]
0000796d027df65d  mov esi, 0x00
0000796d027df662  mov rax, 0x635FBE957530
0000796d027df66c  call rax
0000796d027df66e  movaps xmm10, [rsp]
0000796d027df673  add rsp, 0x30
0000796d027df677  vmovaps xmm0, [rsp]
0000796d027df67c  vmovaps xmm1, [rsp+0x10]
0000796d027df682  vmovaps xmm2, [rsp+0x20]
0000796d027df688  vmovaps xmm3, [rsp+0x30]
0000796d027df68e  vmovaps xmm4, [rsp+0x40]
0000796d027df694  vmovaps xmm5, [rsp+0x50]
0000796d027df69a  vmovaps xmm6, [rsp+0x60]
0000796d027df6a0  vmovaps xmm7, [rsp+0x70]
0000796d027df6a6  vmovaps xmm8, [rsp+0x80]
0000796d027df6af  vmovaps xmm9, [rsp+0x90]
0000796d027df6b8  vmovaps xmm11, [rsp+0xA0]
0000796d027df6c1  vmovaps xmm12, [rsp+0xB0]
0000796d027df6ca  vmovaps xmm13, [rsp+0xC0]
0000796d027df6d3  vmovaps xmm14, [rsp+0xD0]
0000796d027df6dc  vmovaps xmm15, [rsp+0xE0]
0000796d027df6e5  add rsp, 0xF0
0000796d027df6ec  pop r11
0000796d027df6ee  pop r10
0000796d027df6f0  pop r9
0000796d027df6f2  pop r8
0000796d027df6f4  pop rsi
0000796d027df6f5  pop rdi
0000796d027df6f6  pop rdx
0000796d027df6f7  pop rcx
0000796d027df6f8  pop rax
0000796d027df6f9  add rsp, 0x08
0000796d027df6fd  jmp 0x0000796D027DC3F8
0000796d027df702  sub rsp, 0x08
0000796d027df706  push rax
0000796d027df707  push rcx
0000796d027df708  push rdx
0000796d027df709  push rdi
0000796d027df70a  push rsi
0000796d027df70b  push r8
0000796d027df70d  push r9
0000796d027df70f  push r10
0000796d027df711  push r11
0000796d027df713  sub rsp, 0xF0
0000796d027df71a  vmovaps [rsp], xmm0
0000796d027df71f  vmovaps [rsp+0x10], xmm1
0000796d027df725  vmovaps [rsp+0x20], xmm2
0000796d027df72b  vmovaps [rsp+0x30], xmm3
0000796d027df731  vmovaps [rsp+0x40], xmm4
0000796d027df737  vmovaps [rsp+0x50], xmm5
0000796d027df73d  vmovaps [rsp+0x60], xmm6
0000796d027df743  vmovaps [rsp+0x70], xmm7
0000796d027df749  vmovaps [rsp+0x80], xmm8
0000796d027df752  vmovaps [rsp+0x90], xmm9
0000796d027df75b  vmovaps [rsp+0xA0], xmm10
0000796d027df764  vmovaps [rsp+0xB0], xmm11
0000796d027df76d  vmovaps [rsp+0xC0], xmm12
0000796d027df776  vmovaps [rsp+0xD0], xmm13
0000796d027df77f  vmovaps [rsp+0xE0], xmm15
0000796d027df788  sub rsp, 0x30
0000796d027df78c  movaps [rsp], xmm14
0000796d027df791  movaps [rsp+0x10], xmm8
0000796d027df797  movaps [rsp+0x20], xmm4
0000796d027df79c  lea rdi, [rsp]
0000796d027df7a0  mov esi, 0x00
0000796d027df7a5  mov rax, 0x635FBE957530
0000796d027df7af  call rax
0000796d027df7b1  movaps xmm14, [rsp]
0000796d027df7b6  add rsp, 0x30
0000796d027df7ba  vmovaps xmm0, [rsp]
0000796d027df7bf  vmovaps xmm1, [rsp+0x10]
0000796d027df7c5  vmovaps xmm2, [rsp+0x20]
0000796d027df7cb  vmovaps xmm3, [rsp+0x30]
0000796d027df7d1  vmovaps xmm4, [rsp+0x40]
0000796d027df7d7  vmovaps xmm5, [rsp+0x50]
0000796d027df7dd  vmovaps xmm6, [rsp+0x60]
0000796d027df7e3  vmovaps xmm7, [rsp+0x70]
0000796d027df7e9  vmovaps xmm8, [rsp+0x80]
0000796d027df7f2  vmovaps xmm9, [rsp+0x90]
0000796d027df7fb  vmovaps xmm10, [rsp+0xA0]
0000796d027df804  vmovaps xmm11, [rsp+0xB0]
0000796d027df80d  vmovaps xmm12, [rsp+0xC0]
0000796d027df816  vmovaps xmm13, [rsp+0xD0]
0000796d027df81f  vmovaps xmm15, [rsp+0xE0]
0000796d027df828  add rsp, 0xF0
0000796d027df82f  pop r11
0000796d027df831  pop r10
0000796d027df833  pop r9
0000796d027df835  pop r8
0000796d027df837  pop rsi
0000796d027df838  pop rdi
0000796d027df839  pop rdx
0000796d027df83a  pop rcx
0000796d027df83b  pop rax
0000796d027df83c  add rsp, 0x08
0000796d027df840  jmp 0x0000796D027DC418
0000796d027df845  sub rsp, 0x08
0000796d027df849  push rax
0000796d027df84a  push rcx
0000796d027df84b  push rdx
0000796d027df84c  push rdi
0000796d027df84d  push rsi
0000796d027df84e  push r8
0000796d027df850  push r9
0000796d027df852  push r10
0000796d027df854  push r11
0000796d027df856  sub rsp, 0xF0
0000796d027df85d  vmovaps [rsp], xmm0
0000796d027df862  vmovaps [rsp+0x10], xmm1
0000796d027df868  vmovaps [rsp+0x20], xmm2
0000796d027df86e  vmovaps [rsp+0x30], xmm3
0000796d027df874  vmovaps [rsp+0x40], xmm5
0000796d027df87a  vmovaps [rsp+0x50], xmm6
0000796d027df880  vmovaps [rsp+0x60], xmm7
0000796d027df886  vmovaps [rsp+0x70], xmm8
0000796d027df88c  vmovaps [rsp+0x80], xmm9
0000796d027df895  vmovaps [rsp+0x90], xmm10
0000796d027df89e  vmovaps [rsp+0xA0], xmm11
0000796d027df8a7  vmovaps [rsp+0xB0], xmm12
0000796d027df8b0  vmovaps [rsp+0xC0], xmm13
0000796d027df8b9  vmovaps [rsp+0xD0], xmm14
0000796d027df8c2  vmovaps [rsp+0xE0], xmm15
0000796d027df8cb  sub rsp, 0x30
0000796d027df8cf  movaps [rsp], xmm4
0000796d027df8d3  movaps [rsp+0x10], xmm13
0000796d027df8d9  movaps [rsp+0x20], xmm8
0000796d027df8df  lea rdi, [rsp]
0000796d027df8e3  mov esi, 0x00
0000796d027df8e8  mov rax, 0x635FBE957530
0000796d027df8f2  call rax
0000796d027df8f4  movaps xmm4, [rsp]
0000796d027df8f8  add rsp, 0x30
0000796d027df8fc  vmovaps xmm0, [rsp]
0000796d027df901  vmovaps xmm1, [rsp+0x10]
0000796d027df907  vmovaps xmm2, [rsp+0x20]
0000796d027df90d  vmovaps xmm3, [rsp+0x30]
0000796d027df913  vmovaps xmm5, [rsp+0x40]
0000796d027df919  vmovaps xmm6, [rsp+0x50]
0000796d027df91f  vmovaps xmm7, [rsp+0x60]
0000796d027df925  vmovaps xmm8, [rsp+0x70]
0000796d027df92b  vmovaps xmm9, [rsp+0x80]
0000796d027df934  vmovaps xmm10, [rsp+0x90]
0000796d027df93d  vmovaps xmm11, [rsp+0xA0]
0000796d027df946  vmovaps xmm12, [rsp+0xB0]
0000796d027df94f  vmovaps xmm13, [rsp+0xC0]
0000796d027df958  vmovaps xmm14, [rsp+0xD0]
0000796d027df961  vmovaps xmm15, [rsp+0xE0]
0000796d027df96a  add rsp, 0xF0
0000796d027df971  pop r11
0000796d027df973  pop r10
0000796d027df975  pop r9
0000796d027df977  pop r8
0000796d027df979  pop rsi
0000796d027df97a  pop rdi
0000796d027df97b  pop rdx
0000796d027df97c  pop rcx
0000796d027df97d  pop rax
0000796d027df97e  add rsp, 0x08
0000796d027df982  jmp 0x0000796D027DC43D
0000796d027df987  sub rsp, 0x08
0000796d027df98b  push rax
0000796d027df98c  push rcx
0000796d027df98d  push rdx
0000796d027df98e  push rdi
0000796d027df98f  push rsi
0000796d027df990  push r8
0000796d027df992  push r9
0000796d027df994  push r10
0000796d027df996  push r11
0000796d027df998  sub rsp, 0xF0
0000796d027df99f  vmovaps [rsp], xmm0
0000796d027df9a4  vmovaps [rsp+0x10], xmm1
0000796d027df9aa  vmovaps [rsp+0x20], xmm2
0000796d027df9b0  vmovaps [rsp+0x30], xmm3
0000796d027df9b6  vmovaps [rsp+0x40], xmm4
0000796d027df9bc  vmovaps [rsp+0x50], xmm5
0000796d027df9c2  vmovaps [rsp+0x60], xmm6
0000796d027df9c8  vmovaps [rsp+0x70], xmm7
0000796d027df9ce  vmovaps [rsp+0x80], xmm8
0000796d027df9d7  vmovaps [rsp+0x90], xmm9
0000796d027df9e0  vmovaps [rsp+0xA0], xmm10
0000796d027df9e9  vmovaps [rsp+0xB0], xmm11
0000796d027df9f2  vmovaps [rsp+0xC0], xmm12
0000796d027df9fb  vmovaps [rsp+0xD0], xmm14
0000796d027dfa04  vmovaps [rsp+0xE0], xmm15
0000796d027dfa0d  sub rsp, 0x30
0000796d027dfa11  movaps [rsp], xmm13
0000796d027dfa16  movaps [rsp+0x10], xmm15
0000796d027dfa1c  movaps [rsp+0x20], xmm9
0000796d027dfa22  lea rdi, [rsp]
0000796d027dfa26  mov esi, 0x00
0000796d027dfa2b  mov rax, 0x635FBE957530
0000796d027dfa35  call rax
0000796d027dfa37  movaps xmm13, [rsp]
0000796d027dfa3c  add rsp, 0x30
0000796d027dfa40  vmovaps xmm0, [rsp]
0000796d027dfa45  vmovaps xmm1, [rsp+0x10]
0000796d027dfa4b  vmovaps xmm2, [rsp+0x20]
0000796d027dfa51  vmovaps xmm3, [rsp+0x30]
0000796d027dfa57  vmovaps xmm4, [rsp+0x40]
0000796d027dfa5d  vmovaps xmm5, [rsp+0x50]
0000796d027dfa63  vmovaps xmm6, [rsp+0x60]
0000796d027dfa69  vmovaps xmm7, [rsp+0x70]
0000796d027dfa6f  vmovaps xmm8, [rsp+0x80]
0000796d027dfa78  vmovaps xmm9, [rsp+0x90]
0000796d027dfa81  vmovaps xmm10, [rsp+0xA0]
0000796d027dfa8a  vmovaps xmm11, [rsp+0xB0]
0000796d027dfa93  vmovaps xmm12, [rsp+0xC0]
0000796d027dfa9c  vmovaps xmm14, [rsp+0xD0]
0000796d027dfaa5  vmovaps xmm15, [rsp+0xE0]
0000796d027dfaae  add rsp, 0xF0
0000796d027dfab5  pop r11
0000796d027dfab7  pop r10
0000796d027dfab9  pop r9
0000796d027dfabb  pop r8
0000796d027dfabd  pop rsi
0000796d027dfabe  pop rdi
0000796d027dfabf  pop rdx
0000796d027dfac0  pop rcx
0000796d027dfac1  pop rax
0000796d027dfac2  add rsp, 0x08
0000796d027dfac6  jmp 0x0000796D027DC458
0000796d027dfacb  sub rsp, 0x08
0000796d027dfacf  push rax
0000796d027dfad0  push rcx
0000796d027dfad1  push rdx
0000796d027dfad2  push rdi
0000796d027dfad3  push rsi
0000796d027dfad4  push r8
0000796d027dfad6  push r9
0000796d027dfad8  push r10
0000796d027dfada  push r11
0000796d027dfadc  sub rsp, 0xF0
0000796d027dfae3  vmovaps [rsp], xmm0
0000796d027dfae8  vmovaps [rsp+0x10], xmm1
0000796d027dfaee  vmovaps [rsp+0x20], xmm2
0000796d027dfaf4  vmovaps [rsp+0x30], xmm3
0000796d027dfafa  vmovaps [rsp+0x40], xmm4
0000796d027dfb00  vmovaps [rsp+0x50], xmm5
0000796d027dfb06  vmovaps [rsp+0x60], xmm6
0000796d027dfb0c  vmovaps [rsp+0x70], xmm7
0000796d027dfb12  vmovaps [rsp+0x80], xmm8
0000796d027dfb1b  vmovaps [rsp+0x90], xmm9
0000796d027dfb24  vmovaps [rsp+0xA0], xmm10
0000796d027dfb2d  vmovaps [rsp+0xB0], xmm11
0000796d027dfb36  vmovaps [rsp+0xC0], xmm12
0000796d027dfb3f  vmovaps [rsp+0xD0], xmm13
0000796d027dfb48  vmovaps [rsp+0xE0], xmm14
0000796d027dfb51  sub rsp, 0x30
0000796d027dfb55  movaps [rsp], xmm15
0000796d027dfb5a  movaps [rsp+0x10], xmm1
0000796d027dfb5f  movaps [rsp+0x20], xmm5
0000796d027dfb64  lea rdi, [rsp]
0000796d027dfb68  mov esi, 0x00
0000796d027dfb6d  mov rax, 0x635FBE957530
0000796d027dfb77  call rax
0000796d027dfb79  movaps xmm15, [rsp]
0000796d027dfb7e  add rsp, 0x30
0000796d027dfb82  vmovaps xmm0, [rsp]
0000796d027dfb87  vmovaps xmm1, [rsp+0x10]
0000796d027dfb8d  vmovaps xmm2, [rsp+0x20]
0000796d027dfb93  vmovaps xmm3, [rsp+0x30]
0000796d027dfb99  vmovaps xmm4, [rsp+0x40]
0000796d027dfb9f  vmovaps xmm5, [rsp+0x50]
0000796d027dfba5  vmovaps xmm6, [rsp+0x60]
0000796d027dfbab  vmovaps xmm7, [rsp+0x70]
0000796d027dfbb1  vmovaps xmm8, [rsp+0x80]
0000796d027dfbba  vmovaps xmm9, [rsp+0x90]
0000796d027dfbc3  vmovaps xmm10, [rsp+0xA0]
0000796d027dfbcc  vmovaps xmm11, [rsp+0xB0]
0000796d027dfbd5  vmovaps xmm12, [rsp+0xC0]
0000796d027dfbde  vmovaps xmm13, [rsp+0xD0]
0000796d027dfbe7  vmovaps xmm14, [rsp+0xE0]
0000796d027dfbf0  add rsp, 0xF0
0000796d027dfbf7  pop r11
0000796d027dfbf9  pop r10
0000796d027dfbfb  pop r9
0000796d027dfbfd  pop r8
0000796d027dfbff  pop rsi
0000796d027dfc00  pop rdi
0000796d027dfc01  pop rdx
0000796d027dfc02  pop rcx
0000796d027dfc03  pop rax
0000796d027dfc04  add rsp, 0x08
0000796d027dfc08  jmp 0x0000796D027DC473
0000796d027dfc0d  call 0x0000796D026B52F0
0000796d027dfc12  jmp 0x0000796D027DC4CE
0000796d027dfc17  sub rsp, 0x08
0000796d027dfc1b  push rax
0000796d027dfc1c  push rcx
0000796d027dfc1d  push rdx
0000796d027dfc1e  push rdi
0000796d027dfc1f  push rsi
0000796d027dfc20  push r8
0000796d027dfc22  push r9
0000796d027dfc24  push r10
0000796d027dfc26  push r11
0000796d027dfc28  sub rsp, 0xF0
0000796d027dfc2f  vmovaps [rsp], xmm0
0000796d027dfc34  vmovaps [rsp+0x10], xmm1
0000796d027dfc3a  vmovaps [rsp+0x20], xmm2
0000796d027dfc40  vmovaps [rsp+0x30], xmm3
0000796d027dfc46  vmovaps [rsp+0x40], xmm4
0000796d027dfc4c  vmovaps [rsp+0x50], xmm5
0000796d027dfc52  vmovaps [rsp+0x60], xmm6
0000796d027dfc58  vmovaps [rsp+0x70], xmm7
0000796d027dfc5e  vmovaps [rsp+0x80], xmm8
0000796d027dfc67  vmovaps [rsp+0x90], xmm10
0000796d027dfc70  vmovaps [rsp+0xA0], xmm11
0000796d027dfc79  vmovaps [rsp+0xB0], xmm12
0000796d027dfc82  vmovaps [rsp+0xC0], xmm13
0000796d027dfc8b  vmovaps [rsp+0xD0], xmm14
0000796d027dfc94  vmovaps [rsp+0xE0], xmm15
0000796d027dfc9d  sub rsp, 0x30
0000796d027dfca1  movaps [rsp], xmm9
0000796d027dfca6  movaps [rsp+0x10], xmm8
0000796d027dfcac  movaps [rsp+0x20], xmm11
0000796d027dfcb2  lea rdi, [rsp]
0000796d027dfcb6  mov esi, 0x00
0000796d027dfcbb  mov rax, 0x635FBE957530
0000796d027dfcc5  call rax
0000796d027dfcc7  movaps xmm9, [rsp]
0000796d027dfccc  add rsp, 0x30
0000796d027dfcd0  vmovaps xmm0, [rsp]
0000796d027dfcd5  vmovaps xmm1, [rsp+0x10]
0000796d027dfcdb  vmovaps xmm2, [rsp+0x20]
0000796d027dfce1  vmovaps xmm3, [rsp+0x30]
0000796d027dfce7  vmovaps xmm4, [rsp+0x40]
0000796d027dfced  vmovaps xmm5, [rsp+0x50]
0000796d027dfcf3  vmovaps xmm6, [rsp+0x60]
0000796d027dfcf9  vmovaps xmm7, [rsp+0x70]
0000796d027dfcff  vmovaps xmm8, [rsp+0x80]
0000796d027dfd08  vmovaps xmm10, [rsp+0x90]
0000796d027dfd11  vmovaps xmm11, [rsp+0xA0]
0000796d027dfd1a  vmovaps xmm12, [rsp+0xB0]
0000796d027dfd23  vmovaps xmm13, [rsp+0xC0]
0000796d027dfd2c  vmovaps xmm14, [rsp+0xD0]
0000796d027dfd35  vmovaps xmm15, [rsp+0xE0]
0000796d027dfd3e  add rsp, 0xF0
0000796d027dfd45  pop r11
0000796d027dfd47  pop r10
0000796d027dfd49  pop r9
0000796d027dfd4b  pop r8
0000796d027dfd4d  pop rsi
0000796d027dfd4e  pop rdi
0000796d027dfd4f  pop rdx
0000796d027dfd50  pop rcx
0000796d027dfd51  pop rax
0000796d027dfd52  add rsp, 0x08
0000796d027dfd56  jmp 0x0000796D027DC505
0000796d027dfd5b  sub rsp, 0x08
0000796d027dfd5f  push rax
0000796d027dfd60  push rcx
0000796d027dfd61  push rdx
0000796d027dfd62  push rdi
0000796d027dfd63  push rsi
0000796d027dfd64  push r8
0000796d027dfd66  push r9
0000796d027dfd68  push r10
0000796d027dfd6a  push r11
0000796d027dfd6c  sub rsp, 0xF0
0000796d027dfd73  vmovaps [rsp], xmm0
0000796d027dfd78  vmovaps [rsp+0x10], xmm1
0000796d027dfd7e  vmovaps [rsp+0x20], xmm2
0000796d027dfd84  vmovaps [rsp+0x30], xmm3
0000796d027dfd8a  vmovaps [rsp+0x40], xmm4
0000796d027dfd90  vmovaps [rsp+0x50], xmm5
0000796d027dfd96  vmovaps [rsp+0x60], xmm6
0000796d027dfd9c  vmovaps [rsp+0x70], xmm7
0000796d027dfda2  vmovaps [rsp+0x80], xmm8
0000796d027dfdab  vmovaps [rsp+0x90], xmm9
0000796d027dfdb4  vmovaps [rsp+0xA0], xmm10
0000796d027dfdbd  vmovaps [rsp+0xB0], xmm12
0000796d027dfdc6  vmovaps [rsp+0xC0], xmm13
0000796d027dfdcf  vmovaps [rsp+0xD0], xmm14
0000796d027dfdd8  vmovaps [rsp+0xE0], xmm15
0000796d027dfde1  sub rsp, 0x30
0000796d027dfde5  movaps [rsp], xmm11
0000796d027dfdea  movaps [rsp+0x10], xmm10
0000796d027dfdf0  movaps [rsp+0x20], xmm6
0000796d027dfdf5  lea rdi, [rsp]
0000796d027dfdf9  mov esi, 0x00
0000796d027dfdfe  mov rax, 0x635FBE957530
0000796d027dfe08  call rax
0000796d027dfe0a  movaps xmm11, [rsp]
0000796d027dfe0f  add rsp, 0x30
0000796d027dfe13  vmovaps xmm0, [rsp]
0000796d027dfe18  vmovaps xmm1, [rsp+0x10]
0000796d027dfe1e  vmovaps xmm2, [rsp+0x20]
0000796d027dfe24  vmovaps xmm3, [rsp+0x30]
0000796d027dfe2a  vmovaps xmm4, [rsp+0x40]
0000796d027dfe30  vmovaps xmm5, [rsp+0x50]
0000796d027dfe36  vmovaps xmm6, [rsp+0x60]
0000796d027dfe3c  vmovaps xmm7, [rsp+0x70]
0000796d027dfe42  vmovaps xmm8, [rsp+0x80]
0000796d027dfe4b  vmovaps xmm9, [rsp+0x90]
0000796d027dfe54  vmovaps xmm10, [rsp+0xA0]
0000796d027dfe5d  vmovaps xmm12, [rsp+0xB0]
0000796d027dfe66  vmovaps xmm13, [rsp+0xC0]
0000796d027dfe6f  vmovaps xmm14, [rsp+0xD0]
0000796d027dfe78  vmovaps xmm15, [rsp+0xE0]
0000796d027dfe81  add rsp, 0xF0
0000796d027dfe88  pop r11
0000796d027dfe8a  pop r10
0000796d027dfe8c  pop r9
0000796d027dfe8e  pop r8
0000796d027dfe90  pop rsi
0000796d027dfe91  pop rdi
0000796d027dfe92  pop rdx
0000796d027dfe93  pop rcx
0000796d027dfe94  pop rax
0000796d027dfe95  add rsp, 0x08
0000796d027dfe99  jmp 0x0000796D027DC520
0000796d027dfe9e  sub rsp, 0x08
0000796d027dfea2  push rax
0000796d027dfea3  push rcx
0000796d027dfea4  push rdx
0000796d027dfea5  push rdi
0000796d027dfea6  push rsi
0000796d027dfea7  push r8
0000796d027dfea9  push r9
0000796d027dfeab  push r10
0000796d027dfead  push r11
0000796d027dfeaf  sub rsp, 0xF0
0000796d027dfeb6  vmovaps [rsp], xmm0
0000796d027dfebb  vmovaps [rsp+0x10], xmm1
0000796d027dfec1  vmovaps [rsp+0x20], xmm2
0000796d027dfec7  vmovaps [rsp+0x30], xmm3
0000796d027dfecd  vmovaps [rsp+0x40], xmm4
0000796d027dfed3  vmovaps [rsp+0x50], xmm5
0000796d027dfed9  vmovaps [rsp+0x60], xmm6
0000796d027dfedf  vmovaps [rsp+0x70], xmm7
0000796d027dfee5  vmovaps [rsp+0x80], xmm8
0000796d027dfeee  vmovaps [rsp+0x90], xmm9
0000796d027dfef7  vmovaps [rsp+0xA0], xmm11
0000796d027dff00  vmovaps [rsp+0xB0], xmm12
0000796d027dff09  vmovaps [rsp+0xC0], xmm13
0000796d027dff12  vmovaps [rsp+0xD0], xmm14
0000796d027dff1b  vmovaps [rsp+0xE0], xmm15
0000796d027dff24  sub rsp, 0x30
0000796d027dff28  movaps [rsp], xmm10
0000796d027dff2d  movaps [rsp+0x10], xmm14
0000796d027dff33  movaps [rsp+0x20], xmm4
0000796d027dff38  lea rdi, [rsp]
0000796d027dff3c  mov esi, 0x00
0000796d027dff41  mov rax, 0x635FBE957530
0000796d027dff4b  call rax
0000796d027dff4d  movaps xmm10, [rsp]
0000796d027dff52  add rsp, 0x30
0000796d027dff56  vmovaps xmm0, [rsp]
0000796d027dff5b  vmovaps xmm1, [rsp+0x10]
0000796d027dff61  vmovaps xmm2, [rsp+0x20]
0000796d027dff67  vmovaps xmm3, [rsp+0x30]
0000796d027dff6d  vmovaps xmm4, [rsp+0x40]
0000796d027dff73  vmovaps xmm5, [rsp+0x50]
0000796d027dff79  vmovaps xmm6, [rsp+0x60]
0000796d027dff7f  vmovaps xmm7, [rsp+0x70]
0000796d027dff85  vmovaps xmm8, [rsp+0x80]
0000796d027dff8e  vmovaps xmm9, [rsp+0x90]
0000796d027dff97  vmovaps xmm11, [rsp+0xA0]
0000796d027dffa0  vmovaps xmm12, [rsp+0xB0]
0000796d027dffa9  vmovaps xmm13, [rsp+0xC0]
0000796d027dffb2  vmovaps xmm14, [rsp+0xD0]
0000796d027dffbb  vmovaps xmm15, [rsp+0xE0]
0000796d027dffc4  add rsp, 0xF0
0000796d027dffcb  pop r11
0000796d027dffcd  pop r10
0000796d027dffcf  pop r9
0000796d027dffd1  pop r8
0000796d027dffd3  pop rsi
0000796d027dffd4  pop rdi
0000796d027dffd5  pop rdx
0000796d027dffd6  pop rcx
0000796d027dffd7  pop rax
0000796d027dffd8  add rsp, 0x08
0000796d027dffdc  jmp 0x0000796D027DC53B
0000796d027dffe1  sub rsp, 0x08
0000796d027dffe5  push rax
0000796d027dffe6  push rcx
0000796d027dffe7  push rdx
0000796d027dffe8  push rdi
0000796d027dffe9  push rsi
0000796d027dffea  push r8
0000796d027dffec  push r9
0000796d027dffee  push r10
0000796d027dfff0  push r11
0000796d027dfff2  sub rsp, 0xF0
0000796d027dfff9  vmovaps [rsp], xmm0
0000796d027dfffe  vmovaps [rsp+0x10], xmm1
0000796d027e0004  vmovaps [rsp+0x20], xmm2
0000796d027e000a  vmovaps [rsp+0x30], xmm3
0000796d027e0010  vmovaps [rsp+0x40], xmm4
0000796d027e0016  vmovaps [rsp+0x50], xmm5
0000796d027e001c  vmovaps [rsp+0x60], xmm6
0000796d027e0022  vmovaps [rsp+0x70], xmm7
0000796d027e0028  vmovaps [rsp+0x80], xmm9
0000796d027e0031  vmovaps [rsp+0x90], xmm10
0000796d027e003a  vmovaps [rsp+0xA0], xmm11
0000796d027e0043  vmovaps [rsp+0xB0], xmm12
0000796d027e004c  vmovaps [rsp+0xC0], xmm13
0000796d027e0055  vmovaps [rsp+0xD0], xmm14
0000796d027e005e  vmovaps [rsp+0xE0], xmm15
0000796d027e0067  sub rsp, 0x30
0000796d027e006b  movaps [rsp], xmm8
0000796d027e0070  movaps [rsp+0x10], xmm1
0000796d027e0075  movaps [rsp+0x20], xmm14
0000796d027e007b  lea rdi, [rsp]
0000796d027e007f  mov esi, 0x00
0000796d027e0084  mov rax, 0x635FBE957530
0000796d027e008e  call rax
0000796d027e0090  movaps xmm8, [rsp]
0000796d027e0095  add rsp, 0x30
0000796d027e0099  vmovaps xmm0, [rsp]
0000796d027e009e  vmovaps xmm1, [rsp+0x10]
0000796d027e00a4  vmovaps xmm2, [rsp+0x20]
0000796d027e00aa  vmovaps xmm3, [rsp+0x30]
0000796d027e00b0  vmovaps xmm4, [rsp+0x40]
0000796d027e00b6  vmovaps xmm5, [rsp+0x50]
0000796d027e00bc  vmovaps xmm6, [rsp+0x60]
0000796d027e00c2  vmovaps xmm7, [rsp+0x70]
0000796d027e00c8  vmovaps xmm9, [rsp+0x80]
0000796d027e00d1  vmovaps xmm10, [rsp+0x90]
0000796d027e00da  vmovaps xmm11, [rsp+0xA0]
0000796d027e00e3  vmovaps xmm12, [rsp+0xB0]
0000796d027e00ec  vmovaps xmm13, [rsp+0xC0]
0000796d027e00f5  vmovaps xmm14, [rsp+0xD0]
0000796d027e00fe  vmovaps xmm15, [rsp+0xE0]
0000796d027e0107  add rsp, 0xF0
0000796d027e010e  pop r11
0000796d027e0110  pop r10
0000796d027e0112  pop r9
0000796d027e0114  pop r8
0000796d027e0116  pop rsi
0000796d027e0117  pop rdi
0000796d027e0118  pop rdx
0000796d027e0119  pop rcx
0000796d027e011a  pop rax
0000796d027e011b  add rsp, 0x08
0000796d027e011f  jmp 0x0000796D027DC561
0000796d027e0124  sub rsp, 0x08
0000796d027e0128  push rax
0000796d027e0129  push rcx
0000796d027e012a  push rdx
0000796d027e012b  push rdi
0000796d027e012c  push rsi
0000796d027e012d  push r8
0000796d027e012f  push r9
0000796d027e0131  push r10
0000796d027e0133  push r11
0000796d027e0135  sub rsp, 0xF0
0000796d027e013c  vmovaps [rsp], xmm0
0000796d027e0141  vmovaps [rsp+0x10], xmm1
0000796d027e0147  vmovaps [rsp+0x20], xmm2
0000796d027e014d  vmovaps [rsp+0x30], xmm3
0000796d027e0153  vmovaps [rsp+0x40], xmm4
0000796d027e0159  vmovaps [rsp+0x50], xmm5
0000796d027e015f  vmovaps [rsp+0x60], xmm7
0000796d027e0165  vmovaps [rsp+0x70], xmm8
0000796d027e016b  vmovaps [rsp+0x80], xmm9
0000796d027e0174  vmovaps [rsp+0x90], xmm10
0000796d027e017d  vmovaps [rsp+0xA0], xmm11
0000796d027e0186  vmovaps [rsp+0xB0], xmm12
0000796d027e018f  vmovaps [rsp+0xC0], xmm13
0000796d027e0198  vmovaps [rsp+0xD0], xmm14
0000796d027e01a1  vmovaps [rsp+0xE0], xmm15
0000796d027e01aa  sub rsp, 0x30
0000796d027e01ae  movaps [rsp], xmm6
0000796d027e01b2  movaps [rsp+0x10], xmm1
0000796d027e01b7  movaps [rsp+0x20], xmm14
0000796d027e01bd  lea rdi, [rsp]
0000796d027e01c1  mov esi, 0x00
0000796d027e01c6  mov rax, 0x635FBE957530
0000796d027e01d0  call rax
0000796d027e01d2  movaps xmm6, [rsp]
0000796d027e01d6  add rsp, 0x30
0000796d027e01da  vmovaps xmm0, [rsp]
0000796d027e01df  vmovaps xmm1, [rsp+0x10]
0000796d027e01e5  vmovaps xmm2, [rsp+0x20]
0000796d027e01eb  vmovaps xmm3, [rsp+0x30]
0000796d027e01f1  vmovaps xmm4, [rsp+0x40]
0000796d027e01f7  vmovaps xmm5, [rsp+0x50]
0000796d027e01fd  vmovaps xmm7, [rsp+0x60]
0000796d027e0203  vmovaps xmm8, [rsp+0x70]
0000796d027e0209  vmovaps xmm9, [rsp+0x80]
0000796d027e0212  vmovaps xmm10, [rsp+0x90]
0000796d027e021b  vmovaps xmm11, [rsp+0xA0]
0000796d027e0224  vmovaps xmm12, [rsp+0xB0]
0000796d027e022d  vmovaps xmm13, [rsp+0xC0]
0000796d027e0236  vmovaps xmm14, [rsp+0xD0]
0000796d027e023f  vmovaps xmm15, [rsp+0xE0]
0000796d027e0248  add rsp, 0xF0
0000796d027e024f  pop r11
0000796d027e0251  pop r10
0000796d027e0253  pop r9
0000796d027e0255  pop r8
0000796d027e0257  pop rsi
0000796d027e0258  pop rdi
0000796d027e0259  pop rdx
0000796d027e025a  pop rcx
0000796d027e025b  pop rax
0000796d027e025c  add rsp, 0x08
0000796d027e0260  jmp 0x0000796D027DC58D
0000796d027e0265  sub rsp, 0x08
0000796d027e0269  push rax
0000796d027e026a  push rcx
0000796d027e026b  push rdx
0000796d027e026c  push rdi
0000796d027e026d  push rsi
0000796d027e026e  push r8
0000796d027e0270  push r9
0000796d027e0272  push r10
0000796d027e0274  push r11
0000796d027e0276  sub rsp, 0xF0
0000796d027e027d  vmovaps [rsp], xmm0
0000796d027e0282  vmovaps [rsp+0x10], xmm1
0000796d027e0288  vmovaps [rsp+0x20], xmm2
0000796d027e028e  vmovaps [rsp+0x30], xmm3
0000796d027e0294  vmovaps [rsp+0x40], xmm4
0000796d027e029a  vmovaps [rsp+0x50], xmm5
0000796d027e02a0  vmovaps [rsp+0x60], xmm6
0000796d027e02a6  vmovaps [rsp+0x70], xmm7
0000796d027e02ac  vmovaps [rsp+0x80], xmm8
0000796d027e02b5  vmovaps [rsp+0x90], xmm9
0000796d027e02be  vmovaps [rsp+0xA0], xmm10
0000796d027e02c7  vmovaps [rsp+0xB0], xmm11
0000796d027e02d0  vmovaps [rsp+0xC0], xmm12
0000796d027e02d9  vmovaps [rsp+0xD0], xmm13
0000796d027e02e2  vmovaps [rsp+0xE0], xmm15
0000796d027e02eb  sub rsp, 0x30
0000796d027e02ef  movaps [rsp], xmm14
0000796d027e02f4  movaps [rsp+0x10], xmm12
0000796d027e02fa  movaps [rsp+0x20], xmm1
0000796d027e02ff  lea rdi, [rsp]
0000796d027e0303  mov esi, 0x00
0000796d027e0308  mov rax, 0x635FBE957530
0000796d027e0312  call rax
0000796d027e0314  movaps xmm14, [rsp]
0000796d027e0319  add rsp, 0x30
0000796d027e031d  vmovaps xmm0, [rsp]
0000796d027e0322  vmovaps xmm1, [rsp+0x10]
0000796d027e0328  vmovaps xmm2, [rsp+0x20]
0000796d027e032e  vmovaps xmm3, [rsp+0x30]
0000796d027e0334  vmovaps xmm4, [rsp+0x40]
0000796d027e033a  vmovaps xmm5, [rsp+0x50]
0000796d027e0340  vmovaps xmm6, [rsp+0x60]
0000796d027e0346  vmovaps xmm7, [rsp+0x70]
0000796d027e034c  vmovaps xmm8, [rsp+0x80]
0000796d027e0355  vmovaps xmm9, [rsp+0x90]
0000796d027e035e  vmovaps xmm10, [rsp+0xA0]
0000796d027e0367  vmovaps xmm11, [rsp+0xB0]
0000796d027e0370  vmovaps xmm12, [rsp+0xC0]
0000796d027e0379  vmovaps xmm13, [rsp+0xD0]
0000796d027e0382  vmovaps xmm15, [rsp+0xE0]
0000796d027e038b  add rsp, 0xF0
0000796d027e0392  pop r11
0000796d027e0394  pop r10
0000796d027e0396  pop r9
0000796d027e0398  pop r8
0000796d027e039a  pop rsi
0000796d027e039b  pop rdi
0000796d027e039c  pop rdx
0000796d027e039d  pop rcx
0000796d027e039e  pop rax
0000796d027e039f  add rsp, 0x08
0000796d027e03a3  jmp 0x0000796D027DC5B3
0000796d027e03a8  sub rsp, 0x08
0000796d027e03ac  push rax
0000796d027e03ad  push rcx
0000796d027e03ae  push rdx
0000796d027e03af  push rdi
0000796d027e03b0  push rsi
0000796d027e03b1  push r8
0000796d027e03b3  push r9
0000796d027e03b5  push r10
0000796d027e03b7  push r11
0000796d027e03b9  sub rsp, 0xF0
0000796d027e03c0  vmovaps [rsp], xmm0
0000796d027e03c5  vmovaps [rsp+0x10], xmm2
0000796d027e03cb  vmovaps [rsp+0x20], xmm3
0000796d027e03d1  vmovaps [rsp+0x30], xmm4
0000796d027e03d7  vmovaps [rsp+0x40], xmm5
0000796d027e03dd  vmovaps [rsp+0x50], xmm6
0000796d027e03e3  vmovaps [rsp+0x60], xmm7
0000796d027e03e9  vmovaps [rsp+0x70], xmm8
0000796d027e03ef  vmovaps [rsp+0x80], xmm9
0000796d027e03f8  vmovaps [rsp+0x90], xmm10
0000796d027e0401  vmovaps [rsp+0xA0], xmm11
0000796d027e040a  vmovaps [rsp+0xB0], xmm12
0000796d027e0413  vmovaps [rsp+0xC0], xmm13
0000796d027e041c  vmovaps [rsp+0xD0], xmm14
0000796d027e0425  vmovaps [rsp+0xE0], xmm15
0000796d027e042e  sub rsp, 0x30
0000796d027e0432  movaps [rsp], xmm1
0000796d027e0436  movaps [rsp+0x10], xmm13
0000796d027e043c  movaps [rsp+0x20], xmm9
0000796d027e0442  lea rdi, [rsp]
0000796d027e0446  mov esi, 0x00
0000796d027e044b  mov rax, 0x635FBE957530
0000796d027e0455  call rax
0000796d027e0457  movaps xmm1, [rsp]
0000796d027e045b  add rsp, 0x30
0000796d027e045f  vmovaps xmm0, [rsp]
0000796d027e0464  vmovaps xmm2, [rsp+0x10]
0000796d027e046a  vmovaps xmm3, [rsp+0x20]
0000796d027e0470  vmovaps xmm4, [rsp+0x30]
0000796d027e0476  vmovaps xmm5, [rsp+0x40]
0000796d027e047c  vmovaps xmm6, [rsp+0x50]
0000796d027e0482  vmovaps xmm7, [rsp+0x60]
0000796d027e0488  vmovaps xmm8, [rsp+0x70]
0000796d027e048e  vmovaps xmm9, [rsp+0x80]
0000796d027e0497  vmovaps xmm10, [rsp+0x90]
0000796d027e04a0  vmovaps xmm11, [rsp+0xA0]
0000796d027e04a9  vmovaps xmm12, [rsp+0xB0]
0000796d027e04b2  vmovaps xmm13, [rsp+0xC0]
0000796d027e04bb  vmovaps xmm14, [rsp+0xD0]
0000796d027e04c4  vmovaps xmm15, [rsp+0xE0]
0000796d027e04cd  add rsp, 0xF0
0000796d027e04d4  pop r11
0000796d027e04d6  pop r10
0000796d027e04d8  pop r9
0000796d027e04da  pop r8
0000796d027e04dc  pop rsi
0000796d027e04dd  pop rdi
0000796d027e04de  pop rdx
0000796d027e04df  pop rcx
0000796d027e04e0  pop rax
0000796d027e04e1  add rsp, 0x08
0000796d027e04e5  jmp 0x0000796D027DC5CD
0000796d027e04ea  sub rsp, 0x08
0000796d027e04ee  push rax
0000796d027e04ef  push rcx
0000796d027e04f0  push rdx
0000796d027e04f1  push rdi
0000796d027e04f2  push rsi
0000796d027e04f3  push r8
0000796d027e04f5  push r9
0000796d027e04f7  push r10
0000796d027e04f9  push r11
0000796d027e04fb  sub rsp, 0xF0
0000796d027e0502  vmovaps [rsp], xmm0
0000796d027e0507  vmovaps [rsp+0x10], xmm1
0000796d027e050d  vmovaps [rsp+0x20], xmm2
0000796d027e0513  vmovaps [rsp+0x30], xmm3
0000796d027e0519  vmovaps [rsp+0x40], xmm4
0000796d027e051f  vmovaps [rsp+0x50], xmm5
0000796d027e0525  vmovaps [rsp+0x60], xmm6
0000796d027e052b  vmovaps [rsp+0x70], xmm7
0000796d027e0531  vmovaps [rsp+0x80], xmm8
0000796d027e053a  vmovaps [rsp+0x90], xmm9
0000796d027e0543  vmovaps [rsp+0xA0], xmm10
0000796d027e054c  vmovaps [rsp+0xB0], xmm11
0000796d027e0555  vmovaps [rsp+0xC0], xmm13
0000796d027e055e  vmovaps [rsp+0xD0], xmm14
0000796d027e0567  vmovaps [rsp+0xE0], xmm15
0000796d027e0570  sub rsp, 0x30
0000796d027e0574  movaps [rsp], xmm12
0000796d027e0579  movaps [rsp+0x10], xmm7
0000796d027e057e  movaps [rsp+0x20], xmm13
0000796d027e0584  lea rdi, [rsp]
0000796d027e0588  mov esi, 0x00
0000796d027e058d  mov rax, 0x635FBE957530
0000796d027e0597  call rax
0000796d027e0599  movaps xmm12, [rsp]
0000796d027e059e  add rsp, 0x30
0000796d027e05a2  vmovaps xmm0, [rsp]
0000796d027e05a7  vmovaps xmm1, [rsp+0x10]
0000796d027e05ad  vmovaps xmm2, [rsp+0x20]
0000796d027e05b3  vmovaps xmm3, [rsp+0x30]
0000796d027e05b9  vmovaps xmm4, [rsp+0x40]
0000796d027e05bf  vmovaps xmm5, [rsp+0x50]
0000796d027e05c5  vmovaps xmm6, [rsp+0x60]
0000796d027e05cb  vmovaps xmm7, [rsp+0x70]
0000796d027e05d1  vmovaps xmm8, [rsp+0x80]
0000796d027e05da  vmovaps xmm9, [rsp+0x90]
0000796d027e05e3  vmovaps xmm10, [rsp+0xA0]
0000796d027e05ec  vmovaps xmm11, [rsp+0xB0]
0000796d027e05f5  vmovaps xmm13, [rsp+0xC0]
0000796d027e05fe  vmovaps xmm14, [rsp+0xD0]
0000796d027e0607  vmovaps xmm15, [rsp+0xE0]
0000796d027e0610  add rsp, 0xF0
0000796d027e0617  pop r11
0000796d027e0619  pop r10
0000796d027e061b  pop r9
0000796d027e061d  pop r8
0000796d027e061f  pop rsi
0000796d027e0620  pop rdi
0000796d027e0621  pop rdx
0000796d027e0622  pop rcx
0000796d027e0623  pop rax
0000796d027e0624  add rsp, 0x08
0000796d027e0628  jmp 0x0000796D027DC5F4
0000796d027e062d  sub rsp, 0x08
0000796d027e0631  push rax
0000796d027e0632  push rcx
0000796d027e0633  push rdx
0000796d027e0634  push rdi
0000796d027e0635  push rsi
0000796d027e0636  push r8
0000796d027e0638  push r9
0000796d027e063a  push r10
0000796d027e063c  push r11
0000796d027e063e  sub rsp, 0xF0
0000796d027e0645  vmovaps [rsp], xmm0
0000796d027e064a  vmovaps [rsp+0x10], xmm1
0000796d027e0650  vmovaps [rsp+0x20], xmm2
0000796d027e0656  vmovaps [rsp+0x30], xmm3
0000796d027e065c  vmovaps [rsp+0x40], xmm4
0000796d027e0662  vmovaps [rsp+0x50], xmm5
0000796d027e0668  vmovaps [rsp+0x60], xmm6
0000796d027e066e  vmovaps [rsp+0x70], xmm7
0000796d027e0674  vmovaps [rsp+0x80], xmm8
0000796d027e067d  vmovaps [rsp+0x90], xmm9
0000796d027e0686  vmovaps [rsp+0xA0], xmm10
0000796d027e068f  vmovaps [rsp+0xB0], xmm11
0000796d027e0698  vmovaps [rsp+0xC0], xmm12
0000796d027e06a1  vmovaps [rsp+0xD0], xmm14
0000796d027e06aa  vmovaps [rsp+0xE0], xmm15
0000796d027e06b3  sub rsp, 0x30
0000796d027e06b7  movaps [rsp], xmm13
0000796d027e06bc  movaps [rsp+0x10], xmm15
0000796d027e06c2  movaps [rsp+0x20], xmm8
0000796d027e06c8  lea rdi, [rsp]
0000796d027e06cc  mov esi, 0x00
0000796d027e06d1  mov rax, 0x635FBE957530
0000796d027e06db  call rax
0000796d027e06dd  movaps xmm13, [rsp]
0000796d027e06e2  add rsp, 0x30
0000796d027e06e6  vmovaps xmm0, [rsp]
0000796d027e06eb  vmovaps xmm1, [rsp+0x10]
0000796d027e06f1  vmovaps xmm2, [rsp+0x20]
0000796d027e06f7  vmovaps xmm3, [rsp+0x30]
0000796d027e06fd  vmovaps xmm4, [rsp+0x40]
0000796d027e0703  vmovaps xmm5, [rsp+0x50]
0000796d027e0709  vmovaps xmm6, [rsp+0x60]
0000796d027e070f  vmovaps xmm7, [rsp+0x70]
0000796d027e0715  vmovaps xmm8, [rsp+0x80]
0000796d027e071e  vmovaps xmm9, [rsp+0x90]
0000796d027e0727  vmovaps xmm10, [rsp+0xA0]
0000796d027e0730  vmovaps xmm11, [rsp+0xB0]
0000796d027e0739  vmovaps xmm12, [rsp+0xC0]
0000796d027e0742  vmovaps xmm14, [rsp+0xD0]
0000796d027e074b  vmovaps xmm15, [rsp+0xE0]
0000796d027e0754  add rsp, 0xF0
0000796d027e075b  pop r11
0000796d027e075d  pop r10
0000796d027e075f  pop r9
0000796d027e0761  pop r8
0000796d027e0763  pop rsi
0000796d027e0764  pop rdi
0000796d027e0765  pop rdx
0000796d027e0766  pop rcx
0000796d027e0767  pop rax
0000796d027e0768  add rsp, 0x08
0000796d027e076c  jmp 0x0000796D027DC60F
0000796d027e0771  sub rsp, 0x08
0000796d027e0775  push rax
0000796d027e0776  push rcx
0000796d027e0777  push rdx
0000796d027e0778  push rdi
0000796d027e0779  push rsi
0000796d027e077a  push r8
0000796d027e077c  push r9
0000796d027e077e  push r10
0000796d027e0780  push r11
0000796d027e0782  sub rsp, 0xF0
0000796d027e0789  vmovaps [rsp], xmm0
0000796d027e078e  vmovaps [rsp+0x10], xmm1
0000796d027e0794  vmovaps [rsp+0x20], xmm2
0000796d027e079a  vmovaps [rsp+0x30], xmm3
0000796d027e07a0  vmovaps [rsp+0x40], xmm4
0000796d027e07a6  vmovaps [rsp+0x50], xmm5
0000796d027e07ac  vmovaps [rsp+0x60], xmm6
0000796d027e07b2  vmovaps [rsp+0x70], xmm7
0000796d027e07b8  vmovaps [rsp+0x80], xmm9
0000796d027e07c1  vmovaps [rsp+0x90], xmm10
0000796d027e07ca  vmovaps [rsp+0xA0], xmm11
0000796d027e07d3  vmovaps [rsp+0xB0], xmm12
0000796d027e07dc  vmovaps [rsp+0xC0], xmm13
0000796d027e07e5  vmovaps [rsp+0xD0], xmm14
0000796d027e07ee  vmovaps [rsp+0xE0], xmm15
0000796d027e07f7  sub rsp, 0x30
0000796d027e07fb  movaps [rsp], xmm8
0000796d027e0800  movaps [rsp+0x10], xmm15
0000796d027e0806  movaps [rsp+0x20], xmm9
0000796d027e080c  lea rdi, [rsp]
0000796d027e0810  mov esi, 0x00
0000796d027e0815  mov rax, 0x635FBE957530
0000796d027e081f  call rax
0000796d027e0821  movaps xmm8, [rsp]
0000796d027e0826  add rsp, 0x30
0000796d027e082a  vmovaps xmm0, [rsp]
0000796d027e082f  vmovaps xmm1, [rsp+0x10]
0000796d027e0835  vmovaps xmm2, [rsp+0x20]
0000796d027e083b  vmovaps xmm3, [rsp+0x30]
0000796d027e0841  vmovaps xmm4, [rsp+0x40]
0000796d027e0847  vmovaps xmm5, [rsp+0x50]
0000796d027e084d  vmovaps xmm6, [rsp+0x60]
0000796d027e0853  vmovaps xmm7, [rsp+0x70]
0000796d027e0859  vmovaps xmm9, [rsp+0x80]
0000796d027e0862  vmovaps xmm10, [rsp+0x90]
0000796d027e086b  vmovaps xmm11, [rsp+0xA0]
0000796d027e0874  vmovaps xmm12, [rsp+0xB0]
0000796d027e087d  vmovaps xmm13, [rsp+0xC0]
0000796d027e0886  vmovaps xmm14, [rsp+0xD0]
0000796d027e088f  vmovaps xmm15, [rsp+0xE0]
0000796d027e0898  add rsp, 0xF0
0000796d027e089f  pop r11
0000796d027e08a1  pop r10
0000796d027e08a3  pop r9
0000796d027e08a5  pop r8
0000796d027e08a7  pop rsi
0000796d027e08a8  pop rdi
0000796d027e08a9  pop rdx
0000796d027e08aa  pop rcx
0000796d027e08ab  pop rax
0000796d027e08ac  add rsp, 0x08
0000796d027e08b0  jmp 0x0000796D027DC63D
0000796d027e08b5  sub rsp, 0x08
0000796d027e08b9  push rax
0000796d027e08ba  push rcx
0000796d027e08bb  push rdx
0000796d027e08bc  push rdi
0000796d027e08bd  push rsi
0000796d027e08be  push r8
0000796d027e08c0  push r9
0000796d027e08c2  push r10
0000796d027e08c4  push r11
0000796d027e08c6  sub rsp, 0xF0
0000796d027e08cd  vmovaps [rsp], xmm0
0000796d027e08d2  vmovaps [rsp+0x10], xmm1
0000796d027e08d8  vmovaps [rsp+0x20], xmm2
0000796d027e08de  vmovaps [rsp+0x30], xmm3
0000796d027e08e4  vmovaps [rsp+0x40], xmm4
0000796d027e08ea  vmovaps [rsp+0x50], xmm5
0000796d027e08f0  vmovaps [rsp+0x60], xmm6
0000796d027e08f6  vmovaps [rsp+0x70], xmm7
0000796d027e08fc  vmovaps [rsp+0x80], xmm8
0000796d027e0905  vmovaps [rsp+0x90], xmm9
0000796d027e090e  vmovaps [rsp+0xA0], xmm10
0000796d027e0917  vmovaps [rsp+0xB0], xmm11
0000796d027e0920  vmovaps [rsp+0xC0], xmm12
0000796d027e0929  vmovaps [rsp+0xD0], xmm13
0000796d027e0932  vmovaps [rsp+0xE0], xmm14
0000796d027e093b  sub rsp, 0x30
0000796d027e093f  movaps [rsp], xmm15
0000796d027e0944  movaps [rsp+0x10], xmm11
0000796d027e094a  movaps [rsp+0x20], xmm6
0000796d027e094f  lea rdi, [rsp]
0000796d027e0953  mov esi, 0x00
0000796d027e0958  mov rax, 0x635FBE957530
0000796d027e0962  call rax
0000796d027e0964  movaps xmm15, [rsp]
0000796d027e0969  add rsp, 0x30
0000796d027e096d  vmovaps xmm0, [rsp]
0000796d027e0972  vmovaps xmm1, [rsp+0x10]
0000796d027e0978  vmovaps xmm2, [rsp+0x20]
0000796d027e097e  vmovaps xmm3, [rsp+0x30]
0000796d027e0984  vmovaps xmm4, [rsp+0x40]
0000796d027e098a  vmovaps xmm5, [rsp+0x50]
0000796d027e0990  vmovaps xmm6, [rsp+0x60]
0000796d027e0996  vmovaps xmm7, [rsp+0x70]
0000796d027e099c  vmovaps xmm8, [rsp+0x80]
0000796d027e09a5  vmovaps xmm9, [rsp+0x90]
0000796d027e09ae  vmovaps xmm10, [rsp+0xA0]
0000796d027e09b7  vmovaps xmm11, [rsp+0xB0]
0000796d027e09c0  vmovaps xmm12, [rsp+0xC0]
0000796d027e09c9  vmovaps xmm13, [rsp+0xD0]
0000796d027e09d2  vmovaps xmm14, [rsp+0xE0]
0000796d027e09db  add rsp, 0xF0
0000796d027e09e2  pop r11
0000796d027e09e4  pop r10
0000796d027e09e6  pop r9
0000796d027e09e8  pop r8
0000796d027e09ea  pop rsi
0000796d027e09eb  pop rdi
0000796d027e09ec  pop rdx
0000796d027e09ed  pop rcx
0000796d027e09ee  pop rax
0000796d027e09ef  add rsp, 0x08
0000796d027e09f3  jmp 0x0000796D027DC658
0000796d027e09f8  sub rsp, 0x08
0000796d027e09fc  push rax
0000796d027e09fd  push rcx
0000796d027e09fe  push rdx
0000796d027e09ff  push rdi
0000796d027e0a00  push rsi
0000796d027e0a01  push r8
0000796d027e0a03  push r9
0000796d027e0a05  push r10
0000796d027e0a07  push r11
0000796d027e0a09  sub rsp, 0xF0
0000796d027e0a10  vmovaps [rsp], xmm0
0000796d027e0a15  vmovaps [rsp+0x10], xmm1
0000796d027e0a1b  vmovaps [rsp+0x20], xmm2
0000796d027e0a21  vmovaps [rsp+0x30], xmm3
0000796d027e0a27  vmovaps [rsp+0x40], xmm4
0000796d027e0a2d  vmovaps [rsp+0x50], xmm5
0000796d027e0a33  vmovaps [rsp+0x60], xmm6
0000796d027e0a39  vmovaps [rsp+0x70], xmm8
0000796d027e0a3f  vmovaps [rsp+0x80], xmm9
0000796d027e0a48  vmovaps [rsp+0x90], xmm10
0000796d027e0a51  vmovaps [rsp+0xA0], xmm11
0000796d027e0a5a  vmovaps [rsp+0xB0], xmm12
0000796d027e0a63  vmovaps [rsp+0xC0], xmm13
0000796d027e0a6c  vmovaps [rsp+0xD0], xmm14
0000796d027e0a75  vmovaps [rsp+0xE0], xmm15
0000796d027e0a7e  sub rsp, 0x30
0000796d027e0a82  movaps [rsp], xmm7
0000796d027e0a86  movaps [rsp+0x10], xmm11
0000796d027e0a8c  movaps [rsp+0x20], xmm9
0000796d027e0a92  lea rdi, [rsp]
0000796d027e0a96  mov esi, 0x00
0000796d027e0a9b  mov rax, 0x635FBE957530
0000796d027e0aa5  call rax
0000796d027e0aa7  movaps xmm7, [rsp]
0000796d027e0aab  add rsp, 0x30
0000796d027e0aaf  vmovaps xmm0, [rsp]
0000796d027e0ab4  vmovaps xmm1, [rsp+0x10]
0000796d027e0aba  vmovaps xmm2, [rsp+0x20]
0000796d027e0ac0  vmovaps xmm3, [rsp+0x30]
0000796d027e0ac6  vmovaps xmm4, [rsp+0x40]
0000796d027e0acc  vmovaps xmm5, [rsp+0x50]
0000796d027e0ad2  vmovaps xmm6, [rsp+0x60]
0000796d027e0ad8  vmovaps xmm8, [rsp+0x70]
0000796d027e0ade  vmovaps xmm9, [rsp+0x80]
0000796d027e0ae7  vmovaps xmm10, [rsp+0x90]
0000796d027e0af0  vmovaps xmm11, [rsp+0xA0]
0000796d027e0af9  vmovaps xmm12, [rsp+0xB0]
0000796d027e0b02  vmovaps xmm13, [rsp+0xC0]
0000796d027e0b0b  vmovaps xmm14, [rsp+0xD0]
0000796d027e0b14  vmovaps xmm15, [rsp+0xE0]
0000796d027e0b1d  add rsp, 0xF0
0000796d027e0b24  pop r11
0000796d027e0b26  pop r10
0000796d027e0b28  pop r9
0000796d027e0b2a  pop r8
0000796d027e0b2c  pop rsi
0000796d027e0b2d  pop rdi
0000796d027e0b2e  pop rdx
0000796d027e0b2f  pop rcx
0000796d027e0b30  pop rax
0000796d027e0b31  add rsp, 0x08
0000796d027e0b35  jmp 0x0000796D027DC685
0000796d027e0b3a  sub rsp, 0x08
0000796d027e0b3e  push rax
0000796d027e0b3f  push rcx
0000796d027e0b40  push rdx
0000796d027e0b41  push rdi
0000796d027e0b42  push rsi
0000796d027e0b43  push r8
0000796d027e0b45  push r9
0000796d027e0b47  push r10
0000796d027e0b49  push r11
0000796d027e0b4b  sub rsp, 0xF0
0000796d027e0b52  vmovaps [rsp], xmm0
0000796d027e0b57  vmovaps [rsp+0x10], xmm1
0000796d027e0b5d  vmovaps [rsp+0x20], xmm2
0000796d027e0b63  vmovaps [rsp+0x30], xmm3
0000796d027e0b69  vmovaps [rsp+0x40], xmm4
0000796d027e0b6f  vmovaps [rsp+0x50], xmm5
0000796d027e0b75  vmovaps [rsp+0x60], xmm6
0000796d027e0b7b  vmovaps [rsp+0x70], xmm7
0000796d027e0b81  vmovaps [rsp+0x80], xmm8
0000796d027e0b8a  vmovaps [rsp+0x90], xmm9
0000796d027e0b93  vmovaps [rsp+0xA0], xmm10
0000796d027e0b9c  vmovaps [rsp+0xB0], xmm12
0000796d027e0ba5  vmovaps [rsp+0xC0], xmm13
0000796d027e0bae  vmovaps [rsp+0xD0], xmm14
0000796d027e0bb7  vmovaps [rsp+0xE0], xmm15
0000796d027e0bc0  sub rsp, 0x30
0000796d027e0bc4  movaps [rsp], xmm11
0000796d027e0bc9  movaps [rsp+0x10], xmm10
0000796d027e0bcf  movaps [rsp+0x20], xmm14
0000796d027e0bd5  lea rdi, [rsp]
0000796d027e0bd9  mov esi, 0x00
0000796d027e0bde  mov rax, 0x635FBE957530
0000796d027e0be8  call rax
0000796d027e0bea  movaps xmm11, [rsp]
0000796d027e0bef  add rsp, 0x30
0000796d027e0bf3  vmovaps xmm0, [rsp]
0000796d027e0bf8  vmovaps xmm1, [rsp+0x10]
0000796d027e0bfe  vmovaps xmm2, [rsp+0x20]
0000796d027e0c04  vmovaps xmm3, [rsp+0x30]
0000796d027e0c0a  vmovaps xmm4, [rsp+0x40]
0000796d027e0c10  vmovaps xmm5, [rsp+0x50]
0000796d027e0c16  vmovaps xmm6, [rsp+0x60]
0000796d027e0c1c  vmovaps xmm7, [rsp+0x70]
0000796d027e0c22  vmovaps xmm8, [rsp+0x80]
0000796d027e0c2b  vmovaps xmm9, [rsp+0x90]
0000796d027e0c34  vmovaps xmm10, [rsp+0xA0]
0000796d027e0c3d  vmovaps xmm12, [rsp+0xB0]
0000796d027e0c46  vmovaps xmm13, [rsp+0xC0]
0000796d027e0c4f  vmovaps xmm14, [rsp+0xD0]
0000796d027e0c58  vmovaps xmm15, [rsp+0xE0]
0000796d027e0c61  add rsp, 0xF0
0000796d027e0c68  pop r11
0000796d027e0c6a  pop r10
0000796d027e0c6c  pop r9
0000796d027e0c6e  pop r8
0000796d027e0c70  pop rsi
0000796d027e0c71  pop rdi
0000796d027e0c72  pop rdx
0000796d027e0c73  pop rcx
0000796d027e0c74  pop rax
0000796d027e0c75  add rsp, 0x08
0000796d027e0c79  jmp 0x0000796D027DC6A0
0000796d027e0c7e  call 0x0000796D026C33A0
0000796d027e0c83  jmp 0x0000796D027DC6AA
0000796d027e0c88  sub rsp, 0x08
0000796d027e0c8c  push rax
0000796d027e0c8d  push rcx
0000796d027e0c8e  push rdx
0000796d027e0c8f  push rdi
0000796d027e0c90  push rsi
0000796d027e0c91  push r8
0000796d027e0c93  push r9
0000796d027e0c95  push r10
0000796d027e0c97  push r11
0000796d027e0c99  sub rsp, 0xF0
0000796d027e0ca0  vmovaps [rsp], xmm0
0000796d027e0ca5  vmovaps [rsp+0x10], xmm1
0000796d027e0cab  vmovaps [rsp+0x20], xmm2
0000796d027e0cb1  vmovaps [rsp+0x30], xmm3
0000796d027e0cb7  vmovaps [rsp+0x40], xmm4
0000796d027e0cbd  vmovaps [rsp+0x50], xmm5
0000796d027e0cc3  vmovaps [rsp+0x60], xmm6
0000796d027e0cc9  vmovaps [rsp+0x70], xmm7
0000796d027e0ccf  vmovaps [rsp+0x80], xmm8
0000796d027e0cd8  vmovaps [rsp+0x90], xmm9
0000796d027e0ce1  vmovaps [rsp+0xA0], xmm11
0000796d027e0cea  vmovaps [rsp+0xB0], xmm12
0000796d027e0cf3  vmovaps [rsp+0xC0], xmm13
0000796d027e0cfc  vmovaps [rsp+0xD0], xmm14
0000796d027e0d05  vmovaps [rsp+0xE0], xmm15
0000796d027e0d0e  sub rsp, 0x30
0000796d027e0d12  movaps [rsp], xmm10
0000796d027e0d17  movaps [rsp+0x10], xmm1
0000796d027e0d1c  movaps [rsp+0x20], xmm12
0000796d027e0d22  lea rdi, [rsp]
0000796d027e0d26  mov esi, 0x00
0000796d027e0d2b  mov rax, 0x635FBE957530
0000796d027e0d35  call rax
0000796d027e0d37  movaps xmm10, [rsp]
0000796d027e0d3c  add rsp, 0x30
0000796d027e0d40  vmovaps xmm0, [rsp]
0000796d027e0d45  vmovaps xmm1, [rsp+0x10]
0000796d027e0d4b  vmovaps xmm2, [rsp+0x20]
0000796d027e0d51  vmovaps xmm3, [rsp+0x30]
0000796d027e0d57  vmovaps xmm4, [rsp+0x40]
0000796d027e0d5d  vmovaps xmm5, [rsp+0x50]
0000796d027e0d63  vmovaps xmm6, [rsp+0x60]
0000796d027e0d69  vmovaps xmm7, [rsp+0x70]
0000796d027e0d6f  vmovaps xmm8, [rsp+0x80]
0000796d027e0d78  vmovaps xmm9, [rsp+0x90]
0000796d027e0d81  vmovaps xmm11, [rsp+0xA0]
0000796d027e0d8a  vmovaps xmm12, [rsp+0xB0]
0000796d027e0d93  vmovaps xmm13, [rsp+0xC0]
0000796d027e0d9c  vmovaps xmm14, [rsp+0xD0]
0000796d027e0da5  vmovaps xmm15, [rsp+0xE0]
0000796d027e0dae  add rsp, 0xF0
0000796d027e0db5  pop r11
0000796d027e0db7  pop r10
0000796d027e0db9  pop r9
0000796d027e0dbb  pop r8
0000796d027e0dbd  pop rsi
0000796d027e0dbe  pop rdi
0000796d027e0dbf  pop rdx
0000796d027e0dc0  pop rcx
0000796d027e0dc1  pop rax
0000796d027e0dc2  add rsp, 0x08
0000796d027e0dc6  jmp 0x0000796D027DC6CD
0000796d027e0dcb  sub rsp, 0x08
0000796d027e0dcf  push rax
0000796d027e0dd0  push rcx
0000796d027e0dd1  push rdx
0000796d027e0dd2  push rdi
0000796d027e0dd3  push rsi
0000796d027e0dd4  push r8
0000796d027e0dd6  push r9
0000796d027e0dd8  push r10
0000796d027e0dda  push r11
0000796d027e0ddc  sub rsp, 0xF0
0000796d027e0de3  vmovaps [rsp], xmm0
0000796d027e0de8  vmovaps [rsp+0x10], xmm1
0000796d027e0dee  vmovaps [rsp+0x20], xmm2
0000796d027e0df4  vmovaps [rsp+0x30], xmm3
0000796d027e0dfa  vmovaps [rsp+0x40], xmm4
0000796d027e0e00  vmovaps [rsp+0x50], xmm5
0000796d027e0e06  vmovaps [rsp+0x60], xmm6
0000796d027e0e0c  vmovaps [rsp+0x70], xmm7
0000796d027e0e12  vmovaps [rsp+0x80], xmm8
0000796d027e0e1b  vmovaps [rsp+0x90], xmm9
0000796d027e0e24  vmovaps [rsp+0xA0], xmm10
0000796d027e0e2d  vmovaps [rsp+0xB0], xmm11
0000796d027e0e36  vmovaps [rsp+0xC0], xmm13
0000796d027e0e3f  vmovaps [rsp+0xD0], xmm14
0000796d027e0e48  vmovaps [rsp+0xE0], xmm15
0000796d027e0e51  sub rsp, 0x30
0000796d027e0e55  movaps [rsp], xmm12
0000796d027e0e5a  movaps [rsp+0x10], xmm14
0000796d027e0e60  movaps [rsp+0x20], xmm1
0000796d027e0e65  lea rdi, [rsp]
0000796d027e0e69  mov esi, 0x00
0000796d027e0e6e  mov rax, 0x635FBE957530
0000796d027e0e78  call rax
0000796d027e0e7a  movaps xmm12, [rsp]
0000796d027e0e7f  add rsp, 0x30
0000796d027e0e83  vmovaps xmm0, [rsp]
0000796d027e0e88  vmovaps xmm1, [rsp+0x10]
0000796d027e0e8e  vmovaps xmm2, [rsp+0x20]
0000796d027e0e94  vmovaps xmm3, [rsp+0x30]
0000796d027e0e9a  vmovaps xmm4, [rsp+0x40]
0000796d027e0ea0  vmovaps xmm5, [rsp+0x50]
0000796d027e0ea6  vmovaps xmm6, [rsp+0x60]
0000796d027e0eac  vmovaps xmm7, [rsp+0x70]
0000796d027e0eb2  vmovaps xmm8, [rsp+0x80]
0000796d027e0ebb  vmovaps xmm9, [rsp+0x90]
0000796d027e0ec4  vmovaps xmm10, [rsp+0xA0]
0000796d027e0ecd  vmovaps xmm11, [rsp+0xB0]
0000796d027e0ed6  vmovaps xmm13, [rsp+0xC0]
0000796d027e0edf  vmovaps xmm14, [rsp+0xD0]
0000796d027e0ee8  vmovaps xmm15, [rsp+0xE0]
0000796d027e0ef1  add rsp, 0xF0
0000796d027e0ef8  pop r11
0000796d027e0efa  pop r10
0000796d027e0efc  pop r9
0000796d027e0efe  pop r8
0000796d027e0f00  pop rsi
0000796d027e0f01  pop rdi
0000796d027e0f02  pop rdx
0000796d027e0f03  pop rcx
0000796d027e0f04  pop rax
0000796d027e0f05  add rsp, 0x08
0000796d027e0f09  jmp 0x0000796D027DC6FC
0000796d027e0f0e  sub rsp, 0x08
0000796d027e0f12  push rax
0000796d027e0f13  push rcx
0000796d027e0f14  push rdx
0000796d027e0f15  push rdi
0000796d027e0f16  push rsi
0000796d027e0f17  push r8
0000796d027e0f19  push r9
0000796d027e0f1b  push r10
0000796d027e0f1d  push r11
0000796d027e0f1f  sub rsp, 0xF0
0000796d027e0f26  vmovaps [rsp], xmm0
0000796d027e0f2b  vmovaps [rsp+0x10], xmm1
0000796d027e0f31  vmovaps [rsp+0x20], xmm2
0000796d027e0f37  vmovaps [rsp+0x30], xmm3
0000796d027e0f3d  vmovaps [rsp+0x40], xmm4
0000796d027e0f43  vmovaps [rsp+0x50], xmm5
0000796d027e0f49  vmovaps [rsp+0x60], xmm6
0000796d027e0f4f  vmovaps [rsp+0x70], xmm7
0000796d027e0f55  vmovaps [rsp+0x80], xmm8
0000796d027e0f5e  vmovaps [rsp+0x90], xmm9
0000796d027e0f67  vmovaps [rsp+0xA0], xmm10
0000796d027e0f70  vmovaps [rsp+0xB0], xmm11
0000796d027e0f79  vmovaps [rsp+0xC0], xmm12
0000796d027e0f82  vmovaps [rsp+0xD0], xmm13
0000796d027e0f8b  vmovaps [rsp+0xE0], xmm15
0000796d027e0f94  sub rsp, 0x30
0000796d027e0f98  movaps [rsp], xmm14
0000796d027e0f9d  movaps [rsp+0x10], xmm9
0000796d027e0fa3  movaps [rsp+0x20], xmm1
0000796d027e0fa8  lea rdi, [rsp]
0000796d027e0fac  mov esi, 0x00
0000796d027e0fb1  mov rax, 0x635FBE957530
0000796d027e0fbb  call rax
0000796d027e0fbd  movaps xmm14, [rsp]
0000796d027e0fc2  add rsp, 0x30
0000796d027e0fc6  vmovaps xmm0, [rsp]
0000796d027e0fcb  vmovaps xmm1, [rsp+0x10]
0000796d027e0fd1  vmovaps xmm2, [rsp+0x20]
0000796d027e0fd7  vmovaps xmm3, [rsp+0x30]
0000796d027e0fdd  vmovaps xmm4, [rsp+0x40]
0000796d027e0fe3  vmovaps xmm5, [rsp+0x50]
0000796d027e0fe9  vmovaps xmm6, [rsp+0x60]
0000796d027e0fef  vmovaps xmm7, [rsp+0x70]
0000796d027e0ff5  vmovaps xmm8, [rsp+0x80]
0000796d027e0ffe  vmovaps xmm9, [rsp+0x90]
0000796d027e1007  vmovaps xmm10, [rsp+0xA0]
0000796d027e1010  vmovaps xmm11, [rsp+0xB0]
0000796d027e1019  vmovaps xmm12, [rsp+0xC0]
0000796d027e1022  vmovaps xmm13, [rsp+0xD0]
0000796d027e102b  vmovaps xmm15, [rsp+0xE0]
0000796d027e1034  add rsp, 0xF0
0000796d027e103b  pop r11
0000796d027e103d  pop r10
0000796d027e103f  pop r9
0000796d027e1041  pop r8
0000796d027e1043  pop rsi
0000796d027e1044  pop rdi
0000796d027e1045  pop rdx
0000796d027e1046  pop rcx
0000796d027e1047  pop rax
0000796d027e1048  add rsp, 0x08
0000796d027e104c  jmp 0x0000796D027DC72B
0000796d027e1051  sub rsp, 0x08
0000796d027e1055  push rax
0000796d027e1056  push rcx
0000796d027e1057  push rdx
0000796d027e1058  push rdi
0000796d027e1059  push rsi
0000796d027e105a  push r8
0000796d027e105c  push r9
0000796d027e105e  push r10
0000796d027e1060  push r11
0000796d027e1062  sub rsp, 0xF0
0000796d027e1069  vmovaps [rsp], xmm0
0000796d027e106e  vmovaps [rsp+0x10], xmm2
0000796d027e1074  vmovaps [rsp+0x20], xmm3
0000796d027e107a  vmovaps [rsp+0x30], xmm4
0000796d027e1080  vmovaps [rsp+0x40], xmm5
0000796d027e1086  vmovaps [rsp+0x50], xmm6
0000796d027e108c  vmovaps [rsp+0x60], xmm7
0000796d027e1092  vmovaps [rsp+0x70], xmm8
0000796d027e1098  vmovaps [rsp+0x80], xmm9
0000796d027e10a1  vmovaps [rsp+0x90], xmm10
0000796d027e10aa  vmovaps [rsp+0xA0], xmm11
0000796d027e10b3  vmovaps [rsp+0xB0], xmm12
0000796d027e10bc  vmovaps [rsp+0xC0], xmm13
0000796d027e10c5  vmovaps [rsp+0xD0], xmm14
0000796d027e10ce  vmovaps [rsp+0xE0], xmm15
0000796d027e10d7  sub rsp, 0x30
0000796d027e10db  movaps [rsp], xmm1
0000796d027e10df  movaps [rsp+0x10], xmm13
0000796d027e10e5  movaps [rsp+0x20], xmm8
0000796d027e10eb  lea rdi, [rsp]
0000796d027e10ef  mov esi, 0x00
0000796d027e10f4  mov rax, 0x635FBE957530
0000796d027e10fe  call rax
0000796d027e1100  movaps xmm1, [rsp]
0000796d027e1104  add rsp, 0x30
0000796d027e1108  vmovaps xmm0, [rsp]
0000796d027e110d  vmovaps xmm2, [rsp+0x10]
0000796d027e1113  vmovaps xmm3, [rsp+0x20]
0000796d027e1119  vmovaps xmm4, [rsp+0x30]
0000796d027e111f  vmovaps xmm5, [rsp+0x40]
0000796d027e1125  vmovaps xmm6, [rsp+0x50]
0000796d027e112b  vmovaps xmm7, [rsp+0x60]
0000796d027e1131  vmovaps xmm8, [rsp+0x70]
0000796d027e1137  vmovaps xmm9, [rsp+0x80]
0000796d027e1140  vmovaps xmm10, [rsp+0x90]
0000796d027e1149  vmovaps xmm11, [rsp+0xA0]
0000796d027e1152  vmovaps xmm12, [rsp+0xB0]
0000796d027e115b  vmovaps xmm13, [rsp+0xC0]
0000796d027e1164  vmovaps xmm14, [rsp+0xD0]
0000796d027e116d  vmovaps xmm15, [rsp+0xE0]
0000796d027e1176  add rsp, 0xF0
0000796d027e117d  pop r11
0000796d027e117f  pop r10
0000796d027e1181  pop r9
0000796d027e1183  pop r8
0000796d027e1185  pop rsi
0000796d027e1186  pop rdi
0000796d027e1187  pop rdx
0000796d027e1188  pop rcx
0000796d027e1189  pop rax
0000796d027e118a  add rsp, 0x08
0000796d027e118e  jmp 0x0000796D027DC74D
0000796d027e1193  call 0x0000796D0260C260
0000796d027e1198  jmp 0x0000796D027DC75B
0000796d027e119d  call 0x0000796D026BD750
0000796d027e11a2  jmp 0x0000796D027DC765
0000796d027e11a7  sub rsp, 0x08
0000796d027e11ab  push rax
0000796d027e11ac  push rcx
0000796d027e11ad  push rdx
0000796d027e11ae  push rdi
0000796d027e11af  push rsi
0000796d027e11b0  push r8
0000796d027e11b2  push r9
0000796d027e11b4  push r10
0000796d027e11b6  push r11
0000796d027e11b8  sub rsp, 0xF0
0000796d027e11bf  vmovaps [rsp], xmm0
0000796d027e11c4  vmovaps [rsp+0x10], xmm1
0000796d027e11ca  vmovaps [rsp+0x20], xmm2
0000796d027e11d0  vmovaps [rsp+0x30], xmm3
0000796d027e11d6  vmovaps [rsp+0x40], xmm4
0000796d027e11dc  vmovaps [rsp+0x50], xmm5
0000796d027e11e2  vmovaps [rsp+0x60], xmm6
0000796d027e11e8  vmovaps [rsp+0x70], xmm7
0000796d027e11ee  vmovaps [rsp+0x80], xmm9
0000796d027e11f7  vmovaps [rsp+0x90], xmm10
0000796d027e1200  vmovaps [rsp+0xA0], xmm11
0000796d027e1209  vmovaps [rsp+0xB0], xmm12
0000796d027e1212  vmovaps [rsp+0xC0], xmm13
0000796d027e121b  vmovaps [rsp+0xD0], xmm14
0000796d027e1224  vmovaps [rsp+0xE0], xmm15
0000796d027e122d  sub rsp, 0x30
0000796d027e1231  movaps [rsp], xmm8
0000796d027e1236  movaps [rsp+0x10], xmm15
0000796d027e123c  movaps [rsp+0x20], xmm7
0000796d027e1241  lea rdi, [rsp]
0000796d027e1245  mov esi, 0x00
0000796d027e124a  mov rax, 0x635FBE957530
0000796d027e1254  call rax
0000796d027e1256  movaps xmm8, [rsp]
0000796d027e125b  add rsp, 0x30
0000796d027e125f  vmovaps xmm0, [rsp]
0000796d027e1264  vmovaps xmm1, [rsp+0x10]
0000796d027e126a  vmovaps xmm2, [rsp+0x20]
0000796d027e1270  vmovaps xmm3, [rsp+0x30]
0000796d027e1276  vmovaps xmm4, [rsp+0x40]
0000796d027e127c  vmovaps xmm5, [rsp+0x50]
0000796d027e1282  vmovaps xmm6, [rsp+0x60]
0000796d027e1288  vmovaps xmm7, [rsp+0x70]
0000796d027e128e  vmovaps xmm9, [rsp+0x80]
0000796d027e1297  vmovaps xmm10, [rsp+0x90]
0000796d027e12a0  vmovaps xmm11, [rsp+0xA0]
0000796d027e12a9  vmovaps xmm12, [rsp+0xB0]
0000796d027e12b2  vmovaps xmm13, [rsp+0xC0]
0000796d027e12bb  vmovaps xmm14, [rsp+0xD0]
0000796d027e12c4  vmovaps xmm15, [rsp+0xE0]
0000796d027e12cd  add rsp, 0xF0
0000796d027e12d4  pop r11
0000796d027e12d6  pop r10
0000796d027e12d8  pop r9
0000796d027e12da  pop r8
0000796d027e12dc  pop rsi
0000796d027e12dd  pop rdi
0000796d027e12de  pop rdx
0000796d027e12df  pop rcx
0000796d027e12e0  pop rax
0000796d027e12e1  add rsp, 0x08
0000796d027e12e5  jmp 0x0000796D027DC787
0000796d027e12ea  sub rsp, 0x08
0000796d027e12ee  push rax
0000796d027e12ef  push rcx
0000796d027e12f0  push rdx
0000796d027e12f1  push rdi
0000796d027e12f2  push rsi
0000796d027e12f3  push r8
0000796d027e12f5  push r9
0000796d027e12f7  push r10
0000796d027e12f9  push r11
0000796d027e12fb  sub rsp, 0xF0
0000796d027e1302  vmovaps [rsp], xmm0
0000796d027e1307  vmovaps [rsp+0x10], xmm1
0000796d027e130d  vmovaps [rsp+0x20], xmm2
0000796d027e1313  vmovaps [rsp+0x30], xmm3
0000796d027e1319  vmovaps [rsp+0x40], xmm4
0000796d027e131f  vmovaps [rsp+0x50], xmm5
0000796d027e1325  vmovaps [rsp+0x60], xmm6
0000796d027e132b  vmovaps [rsp+0x70], xmm8
0000796d027e1331  vmovaps [rsp+0x80], xmm9
0000796d027e133a  vmovaps [rsp+0x90], xmm10
0000796d027e1343  vmovaps [rsp+0xA0], xmm11
0000796d027e134c  vmovaps [rsp+0xB0], xmm12
0000796d027e1355  vmovaps [rsp+0xC0], xmm13
0000796d027e135e  vmovaps [rsp+0xD0], xmm14
0000796d027e1367  vmovaps [rsp+0xE0], xmm15
0000796d027e1370  sub rsp, 0x30
0000796d027e1374  movaps [rsp], xmm7
0000796d027e1378  movaps [rsp+0x10], xmm9
0000796d027e137e  movaps [rsp+0x20], xmm15
0000796d027e1384  lea rdi, [rsp]
0000796d027e1388  mov esi, 0x00
0000796d027e138d  mov rax, 0x635FBE957530
0000796d027e1397  call rax
0000796d027e1399  movaps xmm7, [rsp]
0000796d027e139d  add rsp, 0x30
0000796d027e13a1  vmovaps xmm0, [rsp]
0000796d027e13a6  vmovaps xmm1, [rsp+0x10]
0000796d027e13ac  vmovaps xmm2, [rsp+0x20]
0000796d027e13b2  vmovaps xmm3, [rsp+0x30]
0000796d027e13b8  vmovaps xmm4, [rsp+0x40]
0000796d027e13be  vmovaps xmm5, [rsp+0x50]
0000796d027e13c4  vmovaps xmm6, [rsp+0x60]
0000796d027e13ca  vmovaps xmm8, [rsp+0x70]
0000796d027e13d0  vmovaps xmm9, [rsp+0x80]
0000796d027e13d9  vmovaps xmm10, [rsp+0x90]
0000796d027e13e2  vmovaps xmm11, [rsp+0xA0]
0000796d027e13eb  vmovaps xmm12, [rsp+0xB0]
0000796d027e13f4  vmovaps xmm13, [rsp+0xC0]
0000796d027e13fd  vmovaps xmm14, [rsp+0xD0]
0000796d027e1406  vmovaps xmm15, [rsp+0xE0]
0000796d027e140f  add rsp, 0xF0
0000796d027e1416  pop r11
0000796d027e1418  pop r10
0000796d027e141a  pop r9
0000796d027e141c  pop r8
0000796d027e141e  pop rsi
0000796d027e141f  pop rdi
0000796d027e1420  pop rdx
0000796d027e1421  pop rcx
0000796d027e1422  pop rax
0000796d027e1423  add rsp, 0x08
0000796d027e1427  jmp 0x0000796D027DC7B4
0000796d027e142c  sub rsp, 0x08
0000796d027e1430  push rax
0000796d027e1431  push rcx
0000796d027e1432  push rdx
0000796d027e1433  push rdi
0000796d027e1434  push rsi
0000796d027e1435  push r8
0000796d027e1437  push r9
0000796d027e1439  push r10
0000796d027e143b  push r11
0000796d027e143d  sub rsp, 0xF0
0000796d027e1444  vmovaps [rsp], xmm0
0000796d027e1449  vmovaps [rsp+0x10], xmm1
0000796d027e144f  vmovaps [rsp+0x20], xmm2
0000796d027e1455  vmovaps [rsp+0x30], xmm3
0000796d027e145b  vmovaps [rsp+0x40], xmm4
0000796d027e1461  vmovaps [rsp+0x50], xmm5
0000796d027e1467  vmovaps [rsp+0x60], xmm6
0000796d027e146d  vmovaps [rsp+0x70], xmm7
0000796d027e1473  vmovaps [rsp+0x80], xmm8
0000796d027e147c  vmovaps [rsp+0x90], xmm10
0000796d027e1485  vmovaps [rsp+0xA0], xmm11
0000796d027e148e  vmovaps [rsp+0xB0], xmm12
0000796d027e1497  vmovaps [rsp+0xC0], xmm13
0000796d027e14a0  vmovaps [rsp+0xD0], xmm14
0000796d027e14a9  vmovaps [rsp+0xE0], xmm15
0000796d027e14b2  sub rsp, 0x30
0000796d027e14b6  movaps [rsp], xmm9
0000796d027e14bb  movaps [rsp+0x10], xmm13
0000796d027e14c1  movaps [rsp+0x20], xmm15
0000796d027e14c7  lea rdi, [rsp]
0000796d027e14cb  mov esi, 0x00
0000796d027e14d0  mov rax, 0x635FBE957530
0000796d027e14da  call rax
0000796d027e14dc  movaps xmm9, [rsp]
0000796d027e14e1  add rsp, 0x30
0000796d027e14e5  vmovaps xmm0, [rsp]
0000796d027e14ea  vmovaps xmm1, [rsp+0x10]
0000796d027e14f0  vmovaps xmm2, [rsp+0x20]
0000796d027e14f6  vmovaps xmm3, [rsp+0x30]
0000796d027e14fc  vmovaps xmm4, [rsp+0x40]
0000796d027e1502  vmovaps xmm5, [rsp+0x50]
0000796d027e1508  vmovaps xmm6, [rsp+0x60]
0000796d027e150e  vmovaps xmm7, [rsp+0x70]
0000796d027e1514  vmovaps xmm8, [rsp+0x80]
0000796d027e151d  vmovaps xmm10, [rsp+0x90]
0000796d027e1526  vmovaps xmm11, [rsp+0xA0]
0000796d027e152f  vmovaps xmm12, [rsp+0xB0]
0000796d027e1538  vmovaps xmm13, [rsp+0xC0]
0000796d027e1541  vmovaps xmm14, [rsp+0xD0]
0000796d027e154a  vmovaps xmm15, [rsp+0xE0]
0000796d027e1553  add rsp, 0xF0
0000796d027e155a  pop r11
0000796d027e155c  pop r10
0000796d027e155e  pop r9
0000796d027e1560  pop r8
0000796d027e1562  pop rsi
0000796d027e1563  pop rdi
0000796d027e1564  pop rdx
0000796d027e1565  pop rcx
0000796d027e1566  pop rax
0000796d027e1567  add rsp, 0x08
0000796d027e156b  jmp 0x0000796D027DC7E2
0000796d027e1570  sub rsp, 0x08
0000796d027e1574  push rax
0000796d027e1575  push rcx
0000796d027e1576  push rdx
0000796d027e1577  push rdi
0000796d027e1578  push rsi
0000796d027e1579  push r8
0000796d027e157b  push r9
0000796d027e157d  push r10
0000796d027e157f  push r11
0000796d027e1581  sub rsp, 0xF0
0000796d027e1588  vmovaps [rsp], xmm0
0000796d027e158d  vmovaps [rsp+0x10], xmm1
0000796d027e1593  vmovaps [rsp+0x20], xmm2
0000796d027e1599  vmovaps [rsp+0x30], xmm3
0000796d027e159f  vmovaps [rsp+0x40], xmm4
0000796d027e15a5  vmovaps [rsp+0x50], xmm5
0000796d027e15ab  vmovaps [rsp+0x60], xmm6
0000796d027e15b1  vmovaps [rsp+0x70], xmm7
0000796d027e15b7  vmovaps [rsp+0x80], xmm8
0000796d027e15c0  vmovaps [rsp+0x90], xmm9
0000796d027e15c9  vmovaps [rsp+0xA0], xmm10
0000796d027e15d2  vmovaps [rsp+0xB0], xmm11
0000796d027e15db  vmovaps [rsp+0xC0], xmm12
0000796d027e15e4  vmovaps [rsp+0xD0], xmm13
0000796d027e15ed  vmovaps [rsp+0xE0], xmm14
0000796d027e15f6  sub rsp, 0x30
0000796d027e15fa  movaps [rsp], xmm15
0000796d027e15ff  movaps [rsp+0x10], xmm11
0000796d027e1605  movaps [rsp+0x20], xmm12
0000796d027e160b  lea rdi, [rsp]
0000796d027e160f  mov esi, 0x00
0000796d027e1614  mov rax, 0x635FBE957530
0000796d027e161e  call rax
0000796d027e1620  movaps xmm15, [rsp]
0000796d027e1625  add rsp, 0x30
0000796d027e1629  vmovaps xmm0, [rsp]
0000796d027e162e  vmovaps xmm1, [rsp+0x10]
0000796d027e1634  vmovaps xmm2, [rsp+0x20]
0000796d027e163a  vmovaps xmm3, [rsp+0x30]
0000796d027e1640  vmovaps xmm4, [rsp+0x40]
0000796d027e1646  vmovaps xmm5, [rsp+0x50]
0000796d027e164c  vmovaps xmm6, [rsp+0x60]
0000796d027e1652  vmovaps xmm7, [rsp+0x70]
0000796d027e1658  vmovaps xmm8, [rsp+0x80]
0000796d027e1661  vmovaps xmm9, [rsp+0x90]
0000796d027e166a  vmovaps xmm10, [rsp+0xA0]
0000796d027e1673  vmovaps xmm11, [rsp+0xB0]
0000796d027e167c  vmovaps xmm12, [rsp+0xC0]
0000796d027e1685  vmovaps xmm13, [rsp+0xD0]
0000796d027e168e  vmovaps xmm14, [rsp+0xE0]
0000796d027e1697  add rsp, 0xF0
0000796d027e169e  pop r11
0000796d027e16a0  pop r10
0000796d027e16a2  pop r9
0000796d027e16a4  pop r8
0000796d027e16a6  pop rsi
0000796d027e16a7  pop rdi
0000796d027e16a8  pop rdx
0000796d027e16a9  pop rcx
0000796d027e16aa  pop rax
0000796d027e16ab  add rsp, 0x08
0000796d027e16af  jmp 0x0000796D027DC7FD
0000796d027e16b4  sub rsp, 0x08
0000796d027e16b8  push rax
0000796d027e16b9  push rcx
0000796d027e16ba  push rdx
0000796d027e16bb  push rdi
0000796d027e16bc  push rsi
0000796d027e16bd  push r8
0000796d027e16bf  push r9
0000796d027e16c1  push r10
0000796d027e16c3  push r11
0000796d027e16c5  sub rsp, 0xF0
0000796d027e16cc  vmovaps [rsp], xmm0
0000796d027e16d1  vmovaps [rsp+0x10], xmm1
0000796d027e16d7  vmovaps [rsp+0x20], xmm2
0000796d027e16dd  vmovaps [rsp+0x30], xmm3
0000796d027e16e3  vmovaps [rsp+0x40], xmm4
0000796d027e16e9  vmovaps [rsp+0x50], xmm5
0000796d027e16ef  vmovaps [rsp+0x60], xmm6
0000796d027e16f5  vmovaps [rsp+0x70], xmm7
0000796d027e16fb  vmovaps [rsp+0x80], xmm8
0000796d027e1704  vmovaps [rsp+0x90], xmm9
0000796d027e170d  vmovaps [rsp+0xA0], xmm10
0000796d027e1716  vmovaps [rsp+0xB0], xmm11
0000796d027e171f  vmovaps [rsp+0xC0], xmm12
0000796d027e1728  vmovaps [rsp+0xD0], xmm14
0000796d027e1731  vmovaps [rsp+0xE0], xmm15
0000796d027e173a  sub rsp, 0x30
0000796d027e173e  movaps [rsp], xmm13
0000796d027e1743  movaps [rsp+0x10], xmm10
0000796d027e1749  movaps [rsp+0x20], xmm14
0000796d027e174f  lea rdi, [rsp]
0000796d027e1753  mov esi, 0x00
0000796d027e1758  mov rax, 0x635FBE957530
0000796d027e1762  call rax
0000796d027e1764  movaps xmm13, [rsp]
0000796d027e1769  add rsp, 0x30
0000796d027e176d  vmovaps xmm0, [rsp]
0000796d027e1772  vmovaps xmm1, [rsp+0x10]
0000796d027e1778  vmovaps xmm2, [rsp+0x20]
0000796d027e177e  vmovaps xmm3, [rsp+0x30]
0000796d027e1784  vmovaps xmm4, [rsp+0x40]
0000796d027e178a  vmovaps xmm5, [rsp+0x50]
0000796d027e1790  vmovaps xmm6, [rsp+0x60]
0000796d027e1796  vmovaps xmm7, [rsp+0x70]
0000796d027e179c  vmovaps xmm8, [rsp+0x80]
0000796d027e17a5  vmovaps xmm9, [rsp+0x90]
0000796d027e17ae  vmovaps xmm10, [rsp+0xA0]
0000796d027e17b7  vmovaps xmm11, [rsp+0xB0]
0000796d027e17c0  vmovaps xmm12, [rsp+0xC0]
0000796d027e17c9  vmovaps xmm14, [rsp+0xD0]
0000796d027e17d2  vmovaps xmm15, [rsp+0xE0]
0000796d027e17db  add rsp, 0xF0
0000796d027e17e2  pop r11
0000796d027e17e4  pop r10
0000796d027e17e6  pop r9
0000796d027e17e8  pop r8
0000796d027e17ea  pop rsi
0000796d027e17eb  pop rdi
0000796d027e17ec  pop rdx
0000796d027e17ed  pop rcx
0000796d027e17ee  pop rax
0000796d027e17ef  add rsp, 0x08
0000796d027e17f3  jmp 0x0000796D027DC820
0000796d027e17f8  sub rsp, 0x08
0000796d027e17fc  push rax
0000796d027e17fd  push rcx
0000796d027e17fe  push rdx
0000796d027e17ff  push rdi
0000796d027e1800  push rsi
0000796d027e1801  push r8
0000796d027e1803  push r9
0000796d027e1805  push r10
0000796d027e1807  push r11
0000796d027e1809  sub rsp, 0xF0
0000796d027e1810  vmovaps [rsp], xmm0
0000796d027e1815  vmovaps [rsp+0x10], xmm1
0000796d027e181b  vmovaps [rsp+0x20], xmm2
0000796d027e1821  vmovaps [rsp+0x30], xmm3
0000796d027e1827  vmovaps [rsp+0x40], xmm4
0000796d027e182d  vmovaps [rsp+0x50], xmm5
0000796d027e1833  vmovaps [rsp+0x60], xmm6
0000796d027e1839  vmovaps [rsp+0x70], xmm7
0000796d027e183f  vmovaps [rsp+0x80], xmm8
0000796d027e1848  vmovaps [rsp+0x90], xmm9
0000796d027e1851  vmovaps [rsp+0xA0], xmm10
0000796d027e185a  vmovaps [rsp+0xB0], xmm11
0000796d027e1863  vmovaps [rsp+0xC0], xmm12
0000796d027e186c  vmovaps [rsp+0xD0], xmm13
0000796d027e1875  vmovaps [rsp+0xE0], xmm15
0000796d027e187e  sub rsp, 0x30
0000796d027e1882  movaps [rsp], xmm14
0000796d027e1887  movaps [rsp+0x10], xmm1
0000796d027e188c  movaps [rsp+0x20], xmm7
0000796d027e1891  lea rdi, [rsp]
0000796d027e1895  mov esi, 0x00
0000796d027e189a  mov rax, 0x635FBE957530
0000796d027e18a4  call rax
0000796d027e18a6  movaps xmm14, [rsp]
0000796d027e18ab  add rsp, 0x30
0000796d027e18af  vmovaps xmm0, [rsp]
0000796d027e18b4  vmovaps xmm1, [rsp+0x10]
0000796d027e18ba  vmovaps xmm2, [rsp+0x20]
0000796d027e18c0  vmovaps xmm3, [rsp+0x30]
0000796d027e18c6  vmovaps xmm4, [rsp+0x40]
0000796d027e18cc  vmovaps xmm5, [rsp+0x50]
0000796d027e18d2  vmovaps xmm6, [rsp+0x60]
0000796d027e18d8  vmovaps xmm7, [rsp+0x70]
0000796d027e18de  vmovaps xmm8, [rsp+0x80]
0000796d027e18e7  vmovaps xmm9, [rsp+0x90]
0000796d027e18f0  vmovaps xmm10, [rsp+0xA0]
0000796d027e18f9  vmovaps xmm11, [rsp+0xB0]
0000796d027e1902  vmovaps xmm12, [rsp+0xC0]
0000796d027e190b  vmovaps xmm13, [rsp+0xD0]
0000796d027e1914  vmovaps xmm15, [rsp+0xE0]
0000796d027e191d  add rsp, 0xF0
0000796d027e1924  pop r11
0000796d027e1926  pop r10
0000796d027e1928  pop r9
0000796d027e192a  pop r8
0000796d027e192c  pop rsi
0000796d027e192d  pop rdi
0000796d027e192e  pop rdx
0000796d027e192f  pop rcx
0000796d027e1930  pop rax
0000796d027e1931  add rsp, 0x08
0000796d027e1935  jmp 0x0000796D027DC843
0000796d027e193a  sub rsp, 0x08
0000796d027e193e  push rax
0000796d027e193f  push rcx
0000796d027e1940  push rdx
0000796d027e1941  push rdi
0000796d027e1942  push rsi
0000796d027e1943  push r8
0000796d027e1945  push r9
0000796d027e1947  push r10
0000796d027e1949  push r11
0000796d027e194b  sub rsp, 0xF0
0000796d027e1952  vmovaps [rsp], xmm0
0000796d027e1957  vmovaps [rsp+0x10], xmm2
0000796d027e195d  vmovaps [rsp+0x20], xmm3
0000796d027e1963  vmovaps [rsp+0x30], xmm4
0000796d027e1969  vmovaps [rsp+0x40], xmm5
0000796d027e196f  vmovaps [rsp+0x50], xmm6
0000796d027e1975  vmovaps [rsp+0x60], xmm7
0000796d027e197b  vmovaps [rsp+0x70], xmm8
0000796d027e1981  vmovaps [rsp+0x80], xmm9
0000796d027e198a  vmovaps [rsp+0x90], xmm10
0000796d027e1993  vmovaps [rsp+0xA0], xmm11
0000796d027e199c  vmovaps [rsp+0xB0], xmm12
0000796d027e19a5  vmovaps [rsp+0xC0], xmm13
0000796d027e19ae  vmovaps [rsp+0xD0], xmm14
0000796d027e19b7  vmovaps [rsp+0xE0], xmm15
0000796d027e19c0  sub rsp, 0x30
0000796d027e19c4  movaps [rsp], xmm1
0000796d027e19c8  movaps [rsp+0x10], xmm8
0000796d027e19ce  movaps [rsp+0x20], xmm9
0000796d027e19d4  lea rdi, [rsp]
0000796d027e19d8  mov esi, 0x00
0000796d027e19dd  mov rax, 0x635FBE957530
0000796d027e19e7  call rax
0000796d027e19e9  movaps xmm1, [rsp]
0000796d027e19ed  add rsp, 0x30
0000796d027e19f1  vmovaps xmm0, [rsp]
0000796d027e19f6  vmovaps xmm2, [rsp+0x10]
0000796d027e19fc  vmovaps xmm3, [rsp+0x20]
0000796d027e1a02  vmovaps xmm4, [rsp+0x30]
0000796d027e1a08  vmovaps xmm5, [rsp+0x40]
0000796d027e1a0e  vmovaps xmm6, [rsp+0x50]
0000796d027e1a14  vmovaps xmm7, [rsp+0x60]
0000796d027e1a1a  vmovaps xmm8, [rsp+0x70]
0000796d027e1a20  vmovaps xmm9, [rsp+0x80]
0000796d027e1a29  vmovaps xmm10, [rsp+0x90]
0000796d027e1a32  vmovaps xmm11, [rsp+0xA0]
0000796d027e1a3b  vmovaps xmm12, [rsp+0xB0]
0000796d027e1a44  vmovaps xmm13, [rsp+0xC0]
0000796d027e1a4d  vmovaps xmm14, [rsp+0xD0]
0000796d027e1a56  vmovaps xmm15, [rsp+0xE0]
0000796d027e1a5f  add rsp, 0xF0
0000796d027e1a66  pop r11
0000796d027e1a68  pop r10
0000796d027e1a6a  pop r9
0000796d027e1a6c  pop r8
0000796d027e1a6e  pop rsi
0000796d027e1a6f  pop rdi
0000796d027e1a70  pop rdx
0000796d027e1a71  pop rcx
0000796d027e1a72  pop rax
0000796d027e1a73  add rsp, 0x08
0000796d027e1a77  jmp 0x0000796D027DC865
0000796d027e1a7c  call 0x0000796D026E5940
0000796d027e1a81  jmp 0x0000796D027DC873
0000796d027e1a86  call 0x0000796D0260C380
0000796d027e1a8b  jmp 0x0000796D027DC87D
0000796d027e1a90  call 0x0000796D0260D600
0000796d027e1a95  jmp 0x0000796D027DC887
0000796d027e1a9a  call 0x0000796D025FF540
0000796d027e1a9f  jmp 0x0000796D027DC891
0000796d027e1aa4  int3
0000796d027e1aa5  nop [rax+rax*1], ax
0000796d027e1aae  nop
0000796d027e1ab0  mov rax, [r15+0xF8]
0000796d027e1ab7  lea r14, [rax+0x140]
0000796d027e1abe  mov r12, [r13+r14*1]
0000796d027e1ac3  mov [r15+0xE8], r12
0000796d027e1aca  lea r14, [rax+0x130]
0000796d027e1ad1  mov r12, [r13+r14*1]
0000796d027e1ad6  lea r14, [rax+0x138]
0000796d027e1add  mov r11, [r13+r14*1]
0000796d027e1ae2  movq xmm1, r12
0000796d027e1ae7  movq xmm15, r11
0000796d027e1aec  movq xmm1, xmm1
0000796d027e1af0  movq xmm1, xmm1
0000796d027e1af4  movaps [r15+0x1A0], xmm1
0000796d027e1afc  movq xmm15, xmm15
0000796d027e1b01  movq xmm15, xmm15
0000796d027e1b06  movaps [r15+0x190], xmm15
0000796d027e1b0e  lea r14, [rax+0x120]
0000796d027e1b15  mov r12, [r13+r14*1]
0000796d027e1b1a  lea r14, [rax+0x128]
0000796d027e1b21  mov r11, [r13+r14*1]
0000796d027e1b26  movq xmm1, r12
0000796d027e1b2b  movq xmm15, r11
0000796d027e1b30  movq xmm1, xmm1
0000796d027e1b34  movq xmm1, xmm1
0000796d027e1b38  movaps [r15+0x1C0], xmm1
0000796d027e1b40  movq xmm15, xmm15
0000796d027e1b45  movq xmm15, xmm15
0000796d027e1b4a  movaps [r15+0x1B0], xmm15
0000796d027e1b52  lea r14, [rax+0x110]
0000796d027e1b59  mov r12, [r13+r14*1]
0000796d027e1b5e  lea r14, [rax+0x118]
0000796d027e1b65  mov r11, [r13+r14*1]
0000796d027e1b6a  movq xmm1, r12
0000796d027e1b6f  movq xmm15, r11
0000796d027e1b74  movq xmm1, xmm1
0000796d027e1b78  movq xmm1, xmm1
0000796d027e1b7c  movaps [r15+0x1E0], xmm1
0000796d027e1b84  movq xmm15, xmm15
0000796d027e1b89  movq xmm15, xmm15
0000796d027e1b8e  movaps [r15+0x1D0], xmm15
0000796d027e1b96  lea r14, [rax+0x100]
0000796d027e1b9d  mov r12, [r13+r14*1]
0000796d027e1ba2  lea r14, [rax+0x108]
0000796d027e1ba9  mov r11, [r13+r14*1]
0000796d027e1bae  movq xmm1, r12
0000796d027e1bb3  movq xmm15, r11
0000796d027e1bb8  movq xmm1, xmm1
0000796d027e1bbc  movq xmm1, xmm1
0000796d027e1bc0  movaps [r15+0x200], xmm1
0000796d027e1bc8  movq xmm15, xmm15
0000796d027e1bcd  movq xmm15, xmm15
0000796d027e1bd2  movaps [r15+0x1F0], xmm15
0000796d027e1bda  mov qword ptr [r15+0x40], 0x430000
0000796d027e1be2  mov r14d, 0x430510
0000796d027e1be8  mov r12, [r13+r14*1]
0000796d027e1bed  movq xmm1, r12
0000796d027e1bf2  lea r14, [rax+0x150]
0000796d027e1bf9  mov [r15+0xF8], r14
0000796d027e1c00  mov rax, [r15+0x50]
0000796d027e1c04  movups xmm15, [r13+rax*1]
0000796d027e1c0a  movaps [r15+0x120], xmm15
0000796d027e1c12  mov qword ptr [r15+0x48], 0x10
0000796d027e1c1a  xor eax, eax
0000796d027e1c1c  mov r14d, 0x10
0000796d027e1c22  mov r12d, 0x200
0000796d027e1c28  cmp r14, r12
0000796d027e1c2b  cmc
0000796d027e1c2c  lahf
0000796d027e1c2d  seto al
0000796d027e1c30  mov [r15+0x108], eax
0000796d027e1c37  pextrq rax, xmm15, 0x01
0000796d027e1c3e  movq xmm14, rax
0000796d027e1c43  movaps [r15+0x130], xmm14
0000796d027e1c4b  movq rax, xmm1
0000796d027e1c50  movq r14, xmm15
0000796d027e1c55  vmovq xmm1, rax
0000796d027e1c5a  vmovq xmm15, r14
0000796d027e1c5f  movaps xmm13, xmm1
0000796d027e1c63  addsd xmm13, xmm15
0000796d027e1c68  ucomisd xmm13, xmm13
0000796d027e1c6d  jp 0x0000796D027E1D86
0000796d027e1c73  movq xmm13, xmm13
0000796d027e1c78  movq rax, xmm13
0000796d027e1c7d  movq r14, xmm14
0000796d027e1c82  vmovq xmm1, rax
0000796d027e1c87  vmovq xmm15, r14
0000796d027e1c8c  movaps xmm14, xmm1
0000796d027e1c90  addsd xmm14, xmm15
0000796d027e1c95  ucomisd xmm14, xmm14
0000796d027e1c9a  jp 0x0000796D027E1DCE
0000796d027e1ca0  movq xmm14, xmm14
0000796d027e1ca5  movaps [r15+0x110], xmm14
0000796d027e1cad  mov eax, [r15+0x108]
0000796d027e1cb4  sahf
0000796d027e1cb5  jnz 0x0000796D027E1CE7
0000796d027e1cb7  cmp dword ptr [r15+0x318], 0x00
0000796d027e1cbf  jz 0x0000796D027E1FE0
0000796d027e1cc5  nop [rax+rax*1], ax
0000796d027e1cce  nop [rax+rax*1], eax
0000796d027e1cd6  mov eax, 0x410490
0000796d027e1cdb  mov [r15+0x100], rax
0000796d027e1ce2  jmp 0x0000796D025FE110
0000796d027e1ce7  cmp dword ptr [r15+0x318], 0x00
0000796d027e1cef  jz 0x0000796D027E1E20
0000796d027e1cf5  nop [rax+rax*1], ax
0000796d027e1cfe  nop [rax+rax*1], eax
0000796d027e1d06  mov eax, 0x410474
0000796d027e1d0b  mov [r15+0x100], rax
0000796d027e1d12  jmp 0x0000796D025FE110
0000796d027e1d17  int3
0000796d027e1d18  call 0x0000796D026E27E0
0000796d027e1d1d  jmp 0x0000796D027E1AC3
0000796d027e1d22  call 0x0000796D026E27E0
0000796d027e1d27  jmp 0x0000796D027E1AD6
0000796d027e1d2c  call 0x0000796D026E1570
0000796d027e1d31  jmp 0x0000796D027E1AE2
0000796d027e1d36  call 0x0000796D026E27E0
0000796d027e1d3b  jmp 0x0000796D027E1B1A
0000796d027e1d40  call 0x0000796D026E1570
0000796d027e1d45  jmp 0x0000796D027E1B26
0000796d027e1d4a  call 0x0000796D026E27E0
0000796d027e1d4f  jmp 0x0000796D027E1B5E
0000796d027e1d54  call 0x0000796D026E1570
0000796d027e1d59  jmp 0x0000796D027E1B6A
0000796d027e1d5e  call 0x0000796D026E27E0
0000796d027e1d63  jmp 0x0000796D027E1BA2
0000796d027e1d68  call 0x0000796D026E1570
0000796d027e1d6d  jmp 0x0000796D027E1BAE
0000796d027e1d72  call 0x0000796D026E27E0
0000796d027e1d77  jmp 0x0000796D027E1BED
0000796d027e1d7c  call 0x0000796D0260E760
0000796d027e1d81  jmp 0x0000796D027E1C0A
0000796d027e1d86  ucomisd xmm1, xmm15
0000796d027e1d8b  jp 0x0000796D027E1D9A
0000796d027e1d8d  movaps xmm13, [0x0000796D023FE060]
0000796d027e1d95  jmp 0x0000796D027E1C73
0000796d027e1d9a  vxorps xmm0, xmm1, xmm15
0000796d027e1d9f  pextrw eax, xmm0, 0x03
0000796d027e1da4  and eax, 0x7FF8
0000796d027e1da9  cmp eax, 0x08
0000796d027e1dac  jnz 0x0000796D027E1C73
0000796d027e1db2  movq rax, xmm15
0000796d027e1db7  shl rax, 0x0D
0000796d027e1dbb  jbe 0x0000796D027E1C73
0000796d027e1dc1  vorps xmm13, xmm15, [0x0000796D023FE070]
0000796d027e1dc9  jmp 0x0000796D027E1C73
0000796d027e1dce  ucomisd xmm1, xmm15
0000796d027e1dd3  jp 0x0000796D027E1DE2
0000796d027e1dd5  movaps xmm14, [0x0000796D023FE060]
0000796d027e1ddd  jmp 0x0000796D027E1CA0
0000796d027e1de2  vxorps xmm0, xmm1, xmm15
0000796d027e1de7  pextrw eax, xmm0, 0x03
0000796d027e1dec  and eax, 0x7FF8
0000796d027e1df1  cmp eax, 0x08
0000796d027e1df4  jnz 0x0000796D027E1CA0
0000796d027e1dfa  movq rax, xmm15
0000796d027e1dff  shl rax, 0x0D
0000796d027e1e03  jbe 0x0000796D027E1CA0
0000796d027e1e09  vorps xmm14, xmm15, [0x0000796D023FE070]
0000796d027e1e11  jmp 0x0000796D027E1CA0
0000796d027e1e16  int3
0000796d027e1e17  nop [rax+rax*1], ax
0000796d027e1e20  mov rax, [r15+0x48]
0000796d027e1e24  mov r14, [r15+0x50]
0000796d027e1e28  lea r12, [r14+rax*1]
0000796d027e1e2c  movups xmm1, [r13+r12*1]
0000796d027e1e32  movaps [r15+0x120], xmm1
0000796d027e1e3a  lea r14, [rax+0x10]
0000796d027e1e3e  mov [r15+0x48], r14
0000796d027e1e42  xor eax, eax
0000796d027e1e44  mov r12d, 0x200
0000796d027e1e4a  cmp r14, r12
0000796d027e1e4d  cmc
0000796d027e1e4e  lahf
0000796d027e1e4f  seto al
0000796d027e1e52  mov [r15+0x108], eax
0000796d027e1e59  pextrq rax, xmm1, 0x01
0000796d027e1e60  movq xmm15, rax
0000796d027e1e65  movaps [r15+0x130], xmm15
0000796d027e1e6d  movaps xmm14, [r15+0x110]
0000796d027e1e75  movq rax, xmm14
0000796d027e1e7a  movq r14, xmm1
0000796d027e1e7f  vmovq xmm1, rax
0000796d027e1e84  vmovq xmm14, r14
0000796d027e1e89  movaps xmm13, xmm1
0000796d027e1e8d  addsd xmm13, xmm14
0000796d027e1e92  ucomisd xmm13, xmm13
0000796d027e1e97  jp 0x0000796D027E1F4C
0000796d027e1e9d  movq xmm13, xmm13
0000796d027e1ea2  movq rax, xmm13
0000796d027e1ea7  movq r14, xmm15
0000796d027e1eac  vmovq xmm1, rax
0000796d027e1eb1  vmovq xmm15, r14
0000796d027e1eb6  movaps xmm14, xmm1
0000796d027e1eba  addsd xmm14, xmm15
0000796d027e1ebf  ucomisd xmm14, xmm14
0000796d027e1ec4  jp 0x0000796D027E1F94
0000796d027e1eca  movq xmm14, xmm14
0000796d027e1ecf  movaps [r15+0x110], xmm14
0000796d027e1ed7  mov eax, [r15+0x108]
0000796d027e1ede  sahf
0000796d027e1edf  jnz 0x0000796D027E1F11
0000796d027e1ee1  cmp dword ptr [r15+0x318], 0x00
0000796d027e1ee9  jz 0x0000796D027E1FE0
0000796d027e1eef  nop [rax+rax*1], ax
0000796d027e1ef8  nop [rax+rax*1], eax
0000796d027e1f00  mov eax, 0x410490
0000796d027e1f05  mov [r15+0x100], rax
0000796d027e1f0c  jmp 0x0000796D025FE110
0000796d027e1f11  cmp dword ptr [r15+0x318], 0x00
0000796d027e1f19  jz 0x0000796D027E1E20
0000796d027e1f1f  nop [rax+rax*1], ax
0000796d027e1f28  nop [rax+rax*1], eax
0000796d027e1f30  mov eax, 0x410474
0000796d027e1f35  mov [r15+0x100], rax
0000796d027e1f3c  jmp 0x0000796D025FE110
0000796d027e1f41  int3
0000796d027e1f42  call 0x0000796D026B52F0
0000796d027e1f47  jmp 0x0000796D027E1E32
0000796d027e1f4c  ucomisd xmm1, xmm14
0000796d027e1f51  jp 0x0000796D027E1F60
0000796d027e1f53  movaps xmm13, [0x0000796D023FE060]
0000796d027e1f5b  jmp 0x0000796D027E1E9D
0000796d027e1f60  vxorps xmm0, xmm1, xmm14
0000796d027e1f65  pextrw eax, xmm0, 0x03
0000796d027e1f6a  and eax, 0x7FF8
0000796d027e1f6f  cmp eax, 0x08
0000796d027e1f72  jnz 0x0000796D027E1E9D
0000796d027e1f78  movq rax, xmm14
0000796d027e1f7d  shl rax, 0x0D
0000796d027e1f81  jbe 0x0000796D027E1E9D
0000796d027e1f87  vorps xmm13, xmm14, [0x0000796D023FE070]
0000796d027e1f8f  jmp 0x0000796D027E1E9D
0000796d027e1f94  ucomisd xmm1, xmm15
0000796d027e1f99  jp 0x0000796D027E1FA8
0000796d027e1f9b  movaps xmm14, [0x0000796D023FE060]
0000796d027e1fa3  jmp 0x0000796D027E1ECA
0000796d027e1fa8  vxorps xmm0, xmm1, xmm15
0000796d027e1fad  pextrw eax, xmm0, 0x03
0000796d027e1fb2  and eax, 0x7FF8
0000796d027e1fb7  cmp eax, 0x08
0000796d027e1fba  jnz 0x0000796D027E1ECA
0000796d027e1fc0  movq rax, xmm15
0000796d027e1fc5  shl rax, 0x0D
0000796d027e1fc9  jbe 0x0000796D027E1ECA
0000796d027e1fcf  vorps xmm14, xmm15, [0x0000796D023FE070]
0000796d027e1fd7  jmp 0x0000796D027E1ECA
0000796d027e1fdc  int3
0000796d027e1fdd  nop [rax], eax
0000796d027e1fe0  mov rax, [r15+0x40]
0000796d027e1fe4  lea r14, [rax+0x510]
0000796d027e1feb  movaps xmm1, [r15+0x110]
0000796d027e1ff3  movq rax, xmm1
0000796d027e1ff8  mov [r13+r14*1], rax
0000796d027e1ffd  mov rax, [r15+0xF0]
0000796d027e2004  mov [r15+0x100], rax
0000796d027e200b  jmp 0x0000796D027CE5C0
0000796d027e2010  int3
0000796d027e2011  call 0x0000796D026D5EB0
0000796d027e2016  jmp 0x0000796D027E1FFD
0000796d027e201b  int3
0000796d027e201c  nop [rax], eax
0000796d027e2020  mov qword ptr [r15+0x100], 0x04
0000796d027e202b  mov esi, 0x00
0000796d027e2030  mov edx, 0x09
0000796d027e2035  mov rdi, 0x7FFF694D6F30
0000796d027e203f  mov rax, 0x635FBE7EA970
0000796d027e2049  call rax
0000796d027e204b  cmp dword ptr [r15+0x318], 0x00
0000796d027e2053  jnz 0x0000796D025FE110
0000796d027e2059  jmp 0x0000796D025FE0A0
0000796d027e205e  int3
0000796d027e205f  int3
