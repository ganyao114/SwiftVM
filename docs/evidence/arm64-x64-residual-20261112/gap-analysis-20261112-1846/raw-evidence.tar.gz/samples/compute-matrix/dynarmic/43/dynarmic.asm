00007767631ce69b  nop [rax+rax*1], eax
00007767631ce6a0  vmovaps xmm1, [0x0000776762DFE010]
00007767631ce6a8  movq xmm1, xmm1
00007767631ce6ac  movaps [r15+0x110], xmm1
00007767631ce6b4  vmovaps xmm1, [0x0000776762DFE020]
00007767631ce6bc  movq xmm1, xmm1
00007767631ce6c0  movaps [r15+0x120], xmm1
00007767631ce6c8  mov eax, 0x4204C0
00007767631ce6cd  mov r14, [r13+rax*1]
00007767631ce6d2  movq xmm1, r14
00007767631ce6d7  movaps [r15+0x130], xmm1
00007767631ce6df  vmovaps xmm1, [0x0000776762DFE030]
00007767631ce6e7  vpbroadcastq xmm1, xmm1
00007767631ce6ec  movaps [r15+0x140], xmm1
00007767631ce6f4  mov qword ptr [r15+0x40], 0x02
00007767631ce6fc  vmovaps xmm15, [0x0000776762DFE040]
00007767631ce704  movq xmm15, xmm15
00007767631ce709  movaps [r15+0x150], xmm15
00007767631ce711  mov qword ptr [r15+0x58], 0x420000
00007767631ce719  vmovaps xmm15, [0x0000776762DFE050]
00007767631ce721  vpbroadcastq xmm15, xmm15
00007767631ce726  movaps [r15+0x160], xmm15
00007767631ce72e  mov rax, [r15+0x40]
00007767631ce732  vmovq xmm14, rax
00007767631ce737  vpbroadcastq xmm14, xmm14
00007767631ce73c  movaps [r15+0x170], xmm14
00007767631ce744  mov eax, 0x4204D0
00007767631ce749  movups xmm13, [r13+rax*1]
00007767631ce74f  mov qword ptr [r15+0x40], 0x430518
00007767631ce757  mov qword ptr [r15+0x50], 0x430720
00007767631ce75f  vpmovqd xmm12, xmm13
00007767631ce765  pxor xmm11, xmm11
00007767631ce76a  punpcklqdq xmm12, xmm11
00007767631ce76f  movaps [r15+0x210], xmm12
00007767631ce777  movq xmm12, qword ptr [r15+0x120]
00007767631ce780  movq xmm11, qword ptr [r15+0x130]
00007767631ce789  psubd xmm12, xmm11
00007767631ce78e  movq xmm12, xmm12
00007767631ce793  paddq xmm13, xmm14
00007767631ce798  movaps [r15+0x180], xmm13
00007767631ce7a0  movq xmm14, qword ptr [r15+0x150]
00007767631ce7a9  paddd xmm11, xmm14
00007767631ce7ae  movq xmm11, xmm11
00007767631ce7b3  movq xmm11, xmm11
00007767631ce7b8  movaps [r15+0x130], xmm11
00007767631ce7c0  pmovzxdq xmm12, xmm12
00007767631ce7c6  psllq xmm12, 0x00
00007767631ce7cc  movq xmm14, qword ptr [r15+0x210]
00007767631ce7d5  movq xmm13, qword ptr [r15+0x110]
00007767631ce7de  paddd xmm14, xmm13
00007767631ce7e3  movq xmm14, xmm14
00007767631ce7e8  vcvtuqq2pd xmm12, xmm12
00007767631ce7ee  pmovzxdq xmm14, xmm14
00007767631ce7f4  psllq xmm14, 0x00
00007767631ce7fa  vcvtuqq2pd xmm14, xmm14
00007767631ce800  movaps xmm13, xmm12
00007767631ce804  mulpd xmm13, xmm1
00007767631ce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007767631ce80f  ptest xmm11, xmm11
00007767631ce815  jnz 0x00007767631CE8FF
00007767631ce81b  movaps [r15+0x220], xmm13
00007767631ce823  mov eax, 0x430720
00007767631ce828  movups [r13+rax*1], xmm13
00007767631ce82e  movaps xmm1, xmm14
00007767631ce832  mulpd xmm1, xmm15
00007767631ce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007767631ce83c  ptest xmm13, xmm13
00007767631ce842  jnz 0x00007767631CEA4C
00007767631ce848  movaps [r15+0x210], xmm1
00007767631ce850  mov eax, 0x430518
00007767631ce855  movups [r13+rax*1], xmm1
00007767631ce85b  mov qword ptr [r15+0x48], 0x10
00007767631ce863  xor eax, eax
00007767631ce865  mov r14d, 0x10
00007767631ce86b  mov r12d, 0x200
00007767631ce871  cmp r14, r12
00007767631ce874  cmc
00007767631ce875  lahf
00007767631ce876  seto al
00007767631ce879  mov [r15+0x108], eax
00007767631ce880  mov eax, [r15+0x108]
00007767631ce887  sahf
00007767631ce888  jnz 0x00007767631CE8BA
00007767631ce88a  cmp dword ptr [r15+0x318], 0x00
00007767631ce892  jz 0x00007767631CEFF0
00007767631ce898  nop [rax+rax*1], ax
00007767631ce8a1  nop [rax+rax*1], eax
00007767631ce8a9  mov eax, 0x4101EC
00007767631ce8ae  mov [r15+0x100], rax
00007767631ce8b5  jmp 0x0000776762FFE110
00007767631ce8ba  cmp dword ptr [r15+0x318], 0x00
00007767631ce8c2  jz 0x00007767631CEBA0
00007767631ce8c8  nop [rax+rax*1], ax
00007767631ce8d1  nop [rax+rax*1], eax
00007767631ce8d9  mov eax, 0x4101AC
00007767631ce8de  mov [r15+0x100], rax
00007767631ce8e5  jmp 0x0000776762FFE110
00007767631ce8ea  int3
00007767631ce8eb  call 0x000077676300DC20
00007767631ce8f0  jmp 0x00007767631CE6D2
00007767631ce8f5  call 0x000077676300C260
00007767631ce8fa  jmp 0x00007767631CE74F
00007767631ce8ff  sub rsp, 0x08
00007767631ce903  push rax
00007767631ce904  push rcx
00007767631ce905  push rdx
00007767631ce906  push rdi
00007767631ce907  push rsi
00007767631ce908  push r8
00007767631ce90a  push r9
00007767631ce90c  push r10
00007767631ce90e  push r11
00007767631ce910  sub rsp, 0xF0
00007767631ce917  vmovaps [rsp], xmm0
00007767631ce91c  vmovaps [rsp+0x10], xmm1
00007767631ce922  vmovaps [rsp+0x20], xmm2
00007767631ce928  vmovaps [rsp+0x30], xmm3
00007767631ce92e  vmovaps [rsp+0x40], xmm4
00007767631ce934  vmovaps [rsp+0x50], xmm5
00007767631ce93a  vmovaps [rsp+0x60], xmm6
00007767631ce940  vmovaps [rsp+0x70], xmm7
00007767631ce946  vmovaps [rsp+0x80], xmm8
00007767631ce94f  vmovaps [rsp+0x90], xmm9
00007767631ce958  vmovaps [rsp+0xA0], xmm10
00007767631ce961  vmovaps [rsp+0xB0], xmm11
00007767631ce96a  vmovaps [rsp+0xC0], xmm12
00007767631ce973  vmovaps [rsp+0xD0], xmm14
00007767631ce97c  vmovaps [rsp+0xE0], xmm15
00007767631ce985  sub rsp, 0x30
00007767631ce989  movaps [rsp], xmm13
00007767631ce98e  movaps [rsp+0x10], xmm12
00007767631ce994  movaps [rsp+0x20], xmm1
00007767631ce999  lea rdi, [rsp]
00007767631ce99d  mov esi, 0x00
00007767631ce9a2  mov rax, 0x617961CDB530
00007767631ce9ac  call rax
00007767631ce9ae  movaps xmm13, [rsp]
00007767631ce9b3  add rsp, 0x30
00007767631ce9b7  vmovaps xmm0, [rsp]
00007767631ce9bc  vmovaps xmm1, [rsp+0x10]
00007767631ce9c2  vmovaps xmm2, [rsp+0x20]
00007767631ce9c8  vmovaps xmm3, [rsp+0x30]
00007767631ce9ce  vmovaps xmm4, [rsp+0x40]
00007767631ce9d4  vmovaps xmm5, [rsp+0x50]
00007767631ce9da  vmovaps xmm6, [rsp+0x60]
00007767631ce9e0  vmovaps xmm7, [rsp+0x70]
00007767631ce9e6  vmovaps xmm8, [rsp+0x80]
00007767631ce9ef  vmovaps xmm9, [rsp+0x90]
00007767631ce9f8  vmovaps xmm10, [rsp+0xA0]
00007767631cea01  vmovaps xmm11, [rsp+0xB0]
00007767631cea0a  vmovaps xmm12, [rsp+0xC0]
00007767631cea13  vmovaps xmm14, [rsp+0xD0]
00007767631cea1c  vmovaps xmm15, [rsp+0xE0]
00007767631cea25  add rsp, 0xF0
00007767631cea2c  pop r11
00007767631cea2e  pop r10
00007767631cea30  pop r9
00007767631cea32  pop r8
00007767631cea34  pop rsi
00007767631cea35  pop rdi
00007767631cea36  pop rdx
00007767631cea37  pop rcx
00007767631cea38  pop rax
00007767631cea39  add rsp, 0x08
00007767631cea3d  jmp 0x00007767631CE81B
00007767631cea42  call 0x000077676300C380
00007767631cea47  jmp 0x00007767631CE82E
00007767631cea4c  sub rsp, 0x08
00007767631cea50  push rax
00007767631cea51  push rcx
00007767631cea52  push rdx
00007767631cea53  push rdi
00007767631cea54  push rsi
00007767631cea55  push r8
00007767631cea57  push r9
00007767631cea59  push r10
00007767631cea5b  push r11
00007767631cea5d  sub rsp, 0xF0
00007767631cea64  vmovaps [rsp], xmm0
00007767631cea69  vmovaps [rsp+0x10], xmm2
00007767631cea6f  vmovaps [rsp+0x20], xmm3
00007767631cea75  vmovaps [rsp+0x30], xmm4
00007767631cea7b  vmovaps [rsp+0x40], xmm5
00007767631cea81  vmovaps [rsp+0x50], xmm6
00007767631cea87  vmovaps [rsp+0x60], xmm7
00007767631cea8d  vmovaps [rsp+0x70], xmm8
00007767631cea93  vmovaps [rsp+0x80], xmm9
00007767631cea9c  vmovaps [rsp+0x90], xmm10
00007767631ceaa5  vmovaps [rsp+0xA0], xmm11
00007767631ceaae  vmovaps [rsp+0xB0], xmm12
00007767631ceab7  vmovaps [rsp+0xC0], xmm13
00007767631ceac0  vmovaps [rsp+0xD0], xmm14
00007767631ceac9  vmovaps [rsp+0xE0], xmm15
00007767631cead2  sub rsp, 0x30
00007767631cead6  movaps [rsp], xmm1
00007767631ceada  movaps [rsp+0x10], xmm14
00007767631ceae0  movaps [rsp+0x20], xmm15
00007767631ceae6  lea rdi, [rsp]
00007767631ceaea  mov esi, 0x00
00007767631ceaef  mov rax, 0x617961CDB530
00007767631ceaf9  call rax
00007767631ceafb  movaps xmm1, [rsp]
00007767631ceaff  add rsp, 0x30
00007767631ceb03  vmovaps xmm0, [rsp]
00007767631ceb08  vmovaps xmm2, [rsp+0x10]
00007767631ceb0e  vmovaps xmm3, [rsp+0x20]
00007767631ceb14  vmovaps xmm4, [rsp+0x30]
00007767631ceb1a  vmovaps xmm5, [rsp+0x40]
00007767631ceb20  vmovaps xmm6, [rsp+0x50]
00007767631ceb26  vmovaps xmm7, [rsp+0x60]
00007767631ceb2c  vmovaps xmm8, [rsp+0x70]
00007767631ceb32  vmovaps xmm9, [rsp+0x80]
00007767631ceb3b  vmovaps xmm10, [rsp+0x90]
00007767631ceb44  vmovaps xmm11, [rsp+0xA0]
00007767631ceb4d  vmovaps xmm12, [rsp+0xB0]
00007767631ceb56  vmovaps xmm13, [rsp+0xC0]
00007767631ceb5f  vmovaps xmm14, [rsp+0xD0]
00007767631ceb68  vmovaps xmm15, [rsp+0xE0]
00007767631ceb71  add rsp, 0xF0
00007767631ceb78  pop r11
00007767631ceb7a  pop r10
00007767631ceb7c  pop r9
00007767631ceb7e  pop r8
00007767631ceb80  pop rsi
00007767631ceb81  pop rdi
00007767631ceb82  pop rdx
00007767631ceb83  pop rcx
00007767631ceb84  pop rax
00007767631ceb85  add rsp, 0x08
00007767631ceb89  jmp 0x00007767631CE848
00007767631ceb8e  call 0x0000776762FFF540
00007767631ceb93  jmp 0x00007767631CE85B
00007767631ceb98  int3
00007767631ceb99  nop [rax], eax
00007767631ceba0  movaps xmm1, [r15+0x180]
00007767631ceba8  vpmovqd xmm15, xmm1
00007767631cebae  pxor xmm14, xmm14
00007767631cebb3  punpcklqdq xmm15, xmm14
00007767631cebb8  movaps [r15+0x210], xmm15
00007767631cebc0  movq xmm15, qword ptr [r15+0x120]
00007767631cebc9  movq xmm14, qword ptr [r15+0x130]
00007767631cebd2  psubd xmm15, xmm14
00007767631cebd7  movq xmm15, xmm15
00007767631cebdc  movaps xmm13, [r15+0x170]
00007767631cebe4  paddq xmm1, xmm13
00007767631cebe9  movaps [r15+0x180], xmm1
00007767631cebf1  movq xmm1, qword ptr [r15+0x150]
00007767631cebfa  paddd xmm14, xmm1
00007767631cebff  movq xmm14, xmm14
00007767631cec04  movq xmm14, xmm14
00007767631cec09  movaps [r15+0x130], xmm14
00007767631cec11  pmovzxdq xmm15, xmm15
00007767631cec17  psllq xmm15, 0x00
00007767631cec1d  movq xmm1, qword ptr [r15+0x210]
00007767631cec26  movq xmm14, qword ptr [r15+0x110]
00007767631cec2f  paddd xmm1, xmm14
00007767631cec34  movq xmm1, xmm1
00007767631cec38  vcvtuqq2pd xmm15, xmm15
00007767631cec3e  pmovzxdq xmm1, xmm1
00007767631cec43  psllq xmm1, 0x00
00007767631cec48  vcvtuqq2pd xmm1, xmm1
00007767631cec4e  movaps xmm14, [r15+0x140]
00007767631cec56  movaps xmm13, xmm15
00007767631cec5a  mulpd xmm13, xmm14
00007767631cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007767631cec65  ptest xmm12, xmm12
00007767631cec6b  jnz 0x00007767631CED4E
00007767631cec71  movaps [r15+0x220], xmm13
00007767631cec79  mov rax, [r15+0x48]
00007767631cec7d  mov r14, [r15+0x50]
00007767631cec81  lea r12, [r14+rax*1]
00007767631cec85  movups [r13+r12*1], xmm13
00007767631cec8b  movaps xmm15, [r15+0x160]
00007767631cec93  movaps xmm14, xmm1
00007767631cec97  mulpd xmm14, xmm15
00007767631cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007767631ceca2  ptest xmm13, xmm13
00007767631ceca8  jnz 0x00007767631CEE9C
00007767631cecae  movaps [r15+0x210], xmm14
00007767631cecb6  mov r14, [r15+0x40]
00007767631cecba  lea r12, [r14+rax*1]
00007767631cecbe  movups [r13+r12*1], xmm14
00007767631cecc4  lea r14, [rax+0x10]
00007767631cecc8  mov [r15+0x48], r14
00007767631ceccc  xor eax, eax
00007767631cecce  mov r12d, 0x200
00007767631cecd4  cmp r14, r12
00007767631cecd7  cmc
00007767631cecd8  lahf
00007767631cecd9  seto al
00007767631cecdc  mov [r15+0x108], eax
00007767631cece3  mov eax, [r15+0x108]
00007767631cecea  sahf
00007767631ceceb  jnz 0x00007767631CED1D
00007767631ceced  cmp dword ptr [r15+0x318], 0x00
00007767631cecf5  jz 0x00007767631CEFF0
00007767631cecfb  nop [rax+rax*1], ax
00007767631ced04  nop [rax+rax*1], eax
00007767631ced0c  mov eax, 0x4101EC
00007767631ced11  mov [r15+0x100], rax
00007767631ced18  jmp 0x0000776762FFE110
00007767631ced1d  cmp dword ptr [r15+0x318], 0x00
00007767631ced25  jz 0x00007767631CEBA0
00007767631ced2b  nop [rax+rax*1], ax
00007767631ced34  nop [rax+rax*1], eax
00007767631ced3c  mov eax, 0x4101AC
00007767631ced41  mov [r15+0x100], rax
00007767631ced48  jmp 0x0000776762FFE110
00007767631ced4d  int3
00007767631ced4e  sub rsp, 0x08
00007767631ced52  push rax
00007767631ced53  push rcx
00007767631ced54  push rdx
00007767631ced55  push rdi
00007767631ced56  push rsi
00007767631ced57  push r8
00007767631ced59  push r9
00007767631ced5b  push r10
00007767631ced5d  push r11
00007767631ced5f  sub rsp, 0xF0
00007767631ced66  vmovaps [rsp], xmm0
00007767631ced6b  vmovaps [rsp+0x10], xmm1
00007767631ced71  vmovaps [rsp+0x20], xmm2
00007767631ced77  vmovaps [rsp+0x30], xmm3
00007767631ced7d  vmovaps [rsp+0x40], xmm4
00007767631ced83  vmovaps [rsp+0x50], xmm5
00007767631ced89  vmovaps [rsp+0x60], xmm6
00007767631ced8f  vmovaps [rsp+0x70], xmm7
00007767631ced95  vmovaps [rsp+0x80], xmm8
00007767631ced9e  vmovaps [rsp+0x90], xmm9
00007767631ceda7  vmovaps [rsp+0xA0], xmm10
00007767631cedb0  vmovaps [rsp+0xB0], xmm11
00007767631cedb9  vmovaps [rsp+0xC0], xmm12
00007767631cedc2  vmovaps [rsp+0xD0], xmm14
00007767631cedcb  vmovaps [rsp+0xE0], xmm15
00007767631cedd4  sub rsp, 0x30
00007767631cedd8  movaps [rsp], xmm13
00007767631ceddd  movaps [rsp+0x10], xmm15
00007767631cede3  movaps [rsp+0x20], xmm14
00007767631cede9  lea rdi, [rsp]
00007767631ceded  mov esi, 0x00
00007767631cedf2  mov rax, 0x617961CDB530
00007767631cedfc  call rax
00007767631cedfe  movaps xmm13, [rsp]
00007767631cee03  add rsp, 0x30
00007767631cee07  vmovaps xmm0, [rsp]
00007767631cee0c  vmovaps xmm1, [rsp+0x10]
00007767631cee12  vmovaps xmm2, [rsp+0x20]
00007767631cee18  vmovaps xmm3, [rsp+0x30]
00007767631cee1e  vmovaps xmm4, [rsp+0x40]
00007767631cee24  vmovaps xmm5, [rsp+0x50]
00007767631cee2a  vmovaps xmm6, [rsp+0x60]
00007767631cee30  vmovaps xmm7, [rsp+0x70]
00007767631cee36  vmovaps xmm8, [rsp+0x80]
00007767631cee3f  vmovaps xmm9, [rsp+0x90]
00007767631cee48  vmovaps xmm10, [rsp+0xA0]
00007767631cee51  vmovaps xmm11, [rsp+0xB0]
00007767631cee5a  vmovaps xmm12, [rsp+0xC0]
00007767631cee63  vmovaps xmm14, [rsp+0xD0]
00007767631cee6c  vmovaps xmm15, [rsp+0xE0]
00007767631cee75  add rsp, 0xF0
00007767631cee7c  pop r11
00007767631cee7e  pop r10
00007767631cee80  pop r9
00007767631cee82  pop r8
00007767631cee84  pop rsi
00007767631cee85  pop rdi
00007767631cee86  pop rdx
00007767631cee87  pop rcx
00007767631cee88  pop rax
00007767631cee89  add rsp, 0x08
00007767631cee8d  jmp 0x00007767631CEC71
00007767631cee92  call 0x00007767630C2240
00007767631cee97  jmp 0x00007767631CEC8B
00007767631cee9c  sub rsp, 0x08
00007767631ceea0  push rax
00007767631ceea1  push rcx
00007767631ceea2  push rdx
00007767631ceea3  push rdi
00007767631ceea4  push rsi
00007767631ceea5  push r8
00007767631ceea7  push r9
00007767631ceea9  push r10
00007767631ceeab  push r11
00007767631ceead  sub rsp, 0xF0
00007767631ceeb4  vmovaps [rsp], xmm0
00007767631ceeb9  vmovaps [rsp+0x10], xmm1
00007767631ceebf  vmovaps [rsp+0x20], xmm2
00007767631ceec5  vmovaps [rsp+0x30], xmm3
00007767631ceecb  vmovaps [rsp+0x40], xmm4
00007767631ceed1  vmovaps [rsp+0x50], xmm5
00007767631ceed7  vmovaps [rsp+0x60], xmm6
00007767631ceedd  vmovaps [rsp+0x70], xmm7
00007767631ceee3  vmovaps [rsp+0x80], xmm8
00007767631ceeec  vmovaps [rsp+0x90], xmm9
00007767631ceef5  vmovaps [rsp+0xA0], xmm10
00007767631ceefe  vmovaps [rsp+0xB0], xmm11
00007767631cef07  vmovaps [rsp+0xC0], xmm12
00007767631cef10  vmovaps [rsp+0xD0], xmm13
00007767631cef19  vmovaps [rsp+0xE0], xmm15
00007767631cef22  sub rsp, 0x30
00007767631cef26  movaps [rsp], xmm14
00007767631cef2b  movaps [rsp+0x10], xmm1
00007767631cef30  movaps [rsp+0x20], xmm15
00007767631cef36  lea rdi, [rsp]
00007767631cef3a  mov esi, 0x00
00007767631cef3f  mov rax, 0x617961CDB530
00007767631cef49  call rax
00007767631cef4b  movaps xmm14, [rsp]
00007767631cef50  add rsp, 0x30
00007767631cef54  vmovaps xmm0, [rsp]
00007767631cef59  vmovaps xmm1, [rsp+0x10]
00007767631cef5f  vmovaps xmm2, [rsp+0x20]
00007767631cef65  vmovaps xmm3, [rsp+0x30]
00007767631cef6b  vmovaps xmm4, [rsp+0x40]
00007767631cef71  vmovaps xmm5, [rsp+0x50]
00007767631cef77  vmovaps xmm6, [rsp+0x60]
00007767631cef7d  vmovaps xmm7, [rsp+0x70]
00007767631cef83  vmovaps xmm8, [rsp+0x80]
00007767631cef8c  vmovaps xmm9, [rsp+0x90]
00007767631cef95  vmovaps xmm10, [rsp+0xA0]
00007767631cef9e  vmovaps xmm11, [rsp+0xB0]
00007767631cefa7  vmovaps xmm12, [rsp+0xC0]
00007767631cefb0  vmovaps xmm13, [rsp+0xD0]
00007767631cefb9  vmovaps xmm15, [rsp+0xE0]
00007767631cefc2  add rsp, 0xF0
00007767631cefc9  pop r11
00007767631cefcb  pop r10
00007767631cefcd  pop r9
00007767631cefcf  pop r8
00007767631cefd1  pop rsi
00007767631cefd2  pop rdi
00007767631cefd3  pop rdx
00007767631cefd4  pop rcx
00007767631cefd5  pop rax
00007767631cefd6  add rsp, 0x08
00007767631cefda  jmp 0x00007767631CECAE
00007767631cefdf  call 0x00007767630C34C0
00007767631cefe4  jmp 0x00007767631CECC4
00007767631cefe9  int3
00007767631cefea  nop [rax+rax*1], ax
00007767631ceff0  mov rax, [r15+0xF8]
00007767631ceff7  lea r14, [rax-0x150]
00007767631ceffe  mov [r15+0xF8], r14
00007767631cf005  mov rax, [r15+0x50]
00007767631cf009  lea r12, [rax+0x80]
00007767631cf010  movups xmm1, [r13+r12*1]
00007767631cf016  lea r12, [rax+0x90]
00007767631cf01d  movups xmm15, [r13+r12*1]
00007767631cf023  mov qword ptr [r15+0x48], 0x00
00007767631cf02b  lea r12, [rax+0x40]
00007767631cf02f  movups xmm14, [r13+r12*1]
00007767631cf035  lea r12, [rax+0x50]
00007767631cf039  movups xmm13, [r13+r12*1]
00007767631cf03f  lea r12, [r14+0x120]
00007767631cf046  movq xmm12, qword ptr [r15+0x1C0]
00007767631cf04f  movq xmm11, qword ptr [r15+0x1B0]
00007767631cf058  movq r11, xmm12
00007767631cf05d  movq r10, xmm11
00007767631cf062  mov [r13+r12*1], r11
00007767631cf067  lea r12, [r14+0x128]
00007767631cf06e  mov [r13+r12*1], r10
00007767631cf073  vxorps xmm12, xmm12, xmm12
00007767631cf078  vpbroadcastq xmm12, xmm12
00007767631cf07d  lea r12, [r14+0x100]
00007767631cf084  movq xmm11, qword ptr [r15+0x200]
00007767631cf08d  movq xmm10, qword ptr [r15+0x1F0]
00007767631cf096  movq r11, xmm11
00007767631cf09b  movq r10, xmm10
00007767631cf0a0  mov [r13+r12*1], r11
00007767631cf0a5  lea r12, [r14+0x108]
00007767631cf0ac  mov [r13+r12*1], r10
00007767631cf0b1  lea r12, [r14+0xE0]
00007767631cf0b8  movups [r13+r12*1], xmm15
00007767631cf0be  lea r12, [r14+0xF0]
00007767631cf0c5  movups [r13+r12*1], xmm1
00007767631cf0cb  lea r12, [rax+0xC0]
00007767631cf0d2  movups xmm1, [r13+r12*1]
00007767631cf0d8  lea r12, [rax+0xD0]
00007767631cf0df  movups xmm15, [r13+r12*1]
00007767631cf0e5  lea r12, [r14+0x110]
00007767631cf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007767631cf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007767631cf0fe  movq r11, xmm11
00007767631cf103  movq r10, xmm10
00007767631cf108  mov [r13+r12*1], r11
00007767631cf10d  lea r12, [r14+0x118]
00007767631cf114  mov [r13+r12*1], r10
00007767631cf119  movups xmm11, [r13+rax*1]
00007767631cf11f  lea r12, [rax+0x10]
00007767631cf123  movups xmm10, [r13+r12*1]
00007767631cf129  lea r12, [r14+0x130]
00007767631cf130  movq xmm9, qword ptr [r15+0x1A0]
00007767631cf139  movq xmm8, qword ptr [r15+0x190]
00007767631cf142  movq r11, xmm9
00007767631cf147  movq r10, xmm8
00007767631cf14c  mov [r13+r12*1], r11
00007767631cf151  lea r12, [r14+0x138]
00007767631cf158  mov [r13+r12*1], r10
00007767631cf15d  lea r12, [rax+0x140]
00007767631cf164  movups xmm9, [r13+r12*1]
00007767631cf16a  lea r12, [rax+0x150]
00007767631cf171  movups xmm8, [r13+r12*1]
00007767631cf177  lea r12, [r14+0xC0]
00007767631cf17e  movups [r13+r12*1], xmm15
00007767631cf184  lea r12, [r14+0xD0]
00007767631cf18b  movups [r13+r12*1], xmm1
00007767631cf191  lea r12, [rax+0x100]
00007767631cf198  movups xmm1, [r13+r12*1]
00007767631cf19e  lea r12, [rax+0x110]
00007767631cf1a5  movups xmm15, [r13+r12*1]
00007767631cf1ab  lea r12, [r14+0x140]
00007767631cf1b2  mov r11, [r15+0xE8]
00007767631cf1b9  mov [r13+r12*1], r11
00007767631cf1be  lea r12, [rax+0x180]
00007767631cf1c5  movups xmm7, [r13+r12*1]
00007767631cf1cb  lea r12, [rax+0x190]
00007767631cf1d2  movups xmm6, [r13+r12*1]
00007767631cf1d8  lea r12, [rax+0x1C0]
00007767631cf1df  movups xmm5, [r13+r12*1]
00007767631cf1e5  lea r12, [rax+0x1D0]
00007767631cf1ec  movups xmm4, [r13+r12*1]
00007767631cf1f2  lea r12, [r14+0x20]
00007767631cf1f6  movups [r13+r12*1], xmm1
00007767631cf1fc  lea r12, [r14+0x30]
00007767631cf200  movups [r13+r12*1], xmm13
00007767631cf206  lea r12, [rax+0x60]
00007767631cf20a  movups xmm1, [r13+r12*1]
00007767631cf210  lea r12, [rax+0x70]
00007767631cf214  movups xmm13, [r13+r12*1]
00007767631cf21a  lea r12, [rax+0x20]
00007767631cf21e  movups xmm3, [r13+r12*1]
00007767631cf224  lea r12, [rax+0x30]
00007767631cf228  movups xmm2, [r13+r12*1]
00007767631cf22e  movaps [r15+0x1F0], xmm2
00007767631cf236  lea r12, [r14+0x60]
00007767631cf23a  movups [r13+r12*1], xmm11
00007767631cf240  lea r12, [r14+0x70]
00007767631cf244  movups [r13+r12*1], xmm5
00007767631cf24a  lea r12, [rax+0xE0]
00007767631cf251  movups xmm11, [r13+r12*1]
00007767631cf257  lea r12, [rax+0xF0]
00007767631cf25e  movups xmm5, [r13+r12*1]
00007767631cf264  lea r12, [r14+0xA0]
00007767631cf26b  movups [r13+r12*1], xmm13
00007767631cf271  lea r12, [r14+0xB0]
00007767631cf278  movups [r13+r12*1], xmm1
00007767631cf27e  lea r12, [rax+0xA0]
00007767631cf285  movups xmm1, [r13+r12*1]
00007767631cf28b  lea r12, [rax+0xB0]
00007767631cf292  movups xmm13, [r13+r12*1]
00007767631cf298  lea r12, [rax+0x120]
00007767631cf29f  vmovaps [rsp+0x10], xmm1
00007767631cf2a5  movups xmm1, [r13+r12*1]
00007767631cf2ab  lea r12, [rax+0x130]
00007767631cf2b2  vmovaps [rsp+0x20], xmm1
00007767631cf2b8  movups xmm1, [r13+r12*1]
00007767631cf2be  lea r12, [rax+0x160]
00007767631cf2c5  vmovaps [rsp+0x30], xmm1
00007767631cf2cb  movups xmm1, [r13+r12*1]
00007767631cf2d1  lea r12, [rax+0x170]
00007767631cf2d8  vmovaps [rsp+0x40], xmm1
00007767631cf2de  movups xmm1, [r13+r12*1]
00007767631cf2e4  movaps [r15+0x2B0], xmm1
00007767631cf2ec  lea r12, [r14+0x80]
00007767631cf2f3  movups [r13+r12*1], xmm13
00007767631cf2f9  lea r12, [r14+0x90]
00007767631cf300  vmovaps xmm13, [rsp+0x10]
00007767631cf306  movups [r13+r12*1], xmm13
00007767631cf30c  lea r12, [rax+0x1A0]
00007767631cf313  movups xmm13, [r13+r12*1]
00007767631cf319  lea r12, [rax+0x1B0]
00007767631cf320  vmovaps [rsp+0x10], xmm1
00007767631cf326  movups xmm1, [r13+r12*1]
00007767631cf32c  movaps [r15+0x290], xmm13
00007767631cf334  movaps [r15+0x1E0], xmm1
00007767631cf33c  lea r12, [rax+0x1E0]
00007767631cf343  vmovaps [rsp+0x50], xmm1
00007767631cf349  movups xmm1, [r13+r12*1]
00007767631cf34f  lea r12, [rax+0x1F0]
00007767631cf356  vmovaps [rsp+0x60], xmm1
00007767631cf35c  movups xmm1, [r13+r12*1]
00007767631cf362  mov qword ptr [r15+0x50], 0x430920
00007767631cf36a  lea rax, [r14+0x40]
00007767631cf36e  vmovaps [rsp+0x70], xmm1
00007767631cf374  vmovaps xmm1, [rsp+0x40]
00007767631cf37a  movups [r13+rax*1], xmm1
00007767631cf380  lea rax, [r14+0x50]
00007767631cf384  movups [r13+rax*1], xmm10
00007767631cf38a  vmovaps xmm1, [rsp+0x70]
00007767631cf390  movups [r13+r14*1], xmm1
00007767631cf396  lea rax, [r14+0x10]
00007767631cf39a  vmovaps xmm1, [rsp+0x60]
00007767631cf3a0  movups [r13+rax*1], xmm1
00007767631cf3a6  mov rax, [r15+0x40]
00007767631cf3aa  vmovaps [rsp+0x40], xmm3
00007767631cf3b0  vmovaps xmm1, [rsp+0x40]
00007767631cf3b6  por xmm3, xmm1
00007767631cf3ba  vmovaps [rsp+0x40], xmm6
00007767631cf3c0  vmovaps xmm10, [rsp+0x40]
00007767631cf3c6  por xmm6, xmm10
00007767631cf3cb  lea r12, [rax+0x30]
00007767631cf3cf  mov r11, [r13+r12*1]
00007767631cf3d4  lea r12, [rax+0x38]
00007767631cf3d8  mov r10, [r13+r12*1]
00007767631cf3dd  movq xmm10, r11
00007767631cf3e2  vmovaps [rsp+0x40], xmm1
00007767631cf3e8  movq xmm1, r10
00007767631cf3ed  movq xmm10, xmm10
00007767631cf3f2  vmovaps [rsp+0x60], xmm10
00007767631cf3f8  movq xmm10, xmm10
00007767631cf3fd  movaps [r15+0x130], xmm10
00007767631cf405  movq xmm1, xmm1
00007767631cf409  vmovaps [rsp+0x70], xmm1
00007767631cf40f  movq xmm1, xmm1
00007767631cf413  movaps [r15+0x280], xmm1
00007767631cf41b  vmovaps [rsp+0x80], xmm9
00007767631cf424  vmovaps xmm1, [rsp+0x80]
00007767631cf42d  por xmm9, xmm1
00007767631cf432  lea r12, [rax+0x20]
00007767631cf436  mov r11, [r13+r12*1]
00007767631cf43b  lea r12, [rax+0x28]
00007767631cf43f  mov r10, [r13+r12*1]
00007767631cf444  movq xmm1, r11
00007767631cf449  movq xmm10, r10
00007767631cf44e  movq xmm1, xmm1
00007767631cf452  vmovaps [rsp+0x80], xmm1
00007767631cf45b  movq xmm1, xmm1
00007767631cf45f  movaps [r15+0x150], xmm1
00007767631cf467  movq xmm10, xmm10
00007767631cf46c  vmovaps [rsp+0x90], xmm10
00007767631cf475  movq xmm10, xmm10
00007767631cf47a  movaps [r15+0x140], xmm10
00007767631cf482  lea r12, [rax+0x10]
00007767631cf486  mov r11, [r13+r12*1]
00007767631cf48b  lea r12, [rax+0x18]
00007767631cf48f  mov r10, [r13+r12*1]
00007767631cf494  movq xmm1, r11
00007767631cf499  movq xmm10, r10
00007767631cf49e  movq xmm1, xmm1
00007767631cf4a2  vmovaps [rsp+0xA0], xmm1
00007767631cf4ab  movq xmm1, xmm1
00007767631cf4af  movaps [r15+0x170], xmm1
00007767631cf4b7  movq xmm10, xmm10
00007767631cf4bc  vmovaps [rsp+0xB0], xmm10
00007767631cf4c5  movq xmm10, xmm10
00007767631cf4ca  movaps [r15+0x160], xmm10
00007767631cf4d2  mov r12, [r13+rax*1]
00007767631cf4d7  vmovq xmm1, r12
00007767631cf4dc  vpbroadcastq xmm1, xmm1
00007767631cf4e1  lea r12, [rax+0x08]
00007767631cf4e5  mov rax, [r13+r12*1]
00007767631cf4ea  movq xmm10, rax
00007767631cf4ef  movaps [r15+0x230], xmm10
00007767631cf4f7  lea rax, [r14+0x50]
00007767631cf4fb  movups xmm10, [r13+rax*1]
00007767631cf501  lea rax, [r14+0x60]
00007767631cf505  vmovaps [rsp+0xC0], xmm1
00007767631cf50e  movups xmm1, [r13+rax*1]
00007767631cf514  lea rax, [r14+0x30]
00007767631cf518  vmovaps [rsp+0xD0], xmm1
00007767631cf521  movups xmm1, [r13+rax*1]
00007767631cf527  mov qword ptr [r15+0x60], 0x430920
00007767631cf52f  mov qword ptr [r15+0x58], 0x40
00007767631cf537  vmovaps [rsp+0xE0], xmm1
00007767631cf540  vmovaps [rsp+0xF0], xmm15
00007767631cf549  vmovaps xmm15, [rsp+0xC0]
00007767631cf552  vmovaps [rsp+0xC0], xmm14
00007767631cf55b  vmovaps xmm14, [rsp+0x40]
00007767631cf561  vmovaps [rsp+0x40], xmm13
00007767631cf567  movaps xmm1, xmm15
00007767631cf56b  mulpd xmm1, xmm14
00007767631cf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007767631cf575  ptest xmm13, xmm13
00007767631cf57b  jnz 0x00007767631D0682
00007767631cf581  movq xmm14, qword ptr [r15+0x230]
00007767631cf58a  vmovaps [rsp+0x100], xmm14
00007767631cf593  vpermilpd xmm14, xmm14, 0x00
00007767631cf599  vmovaps [rsp+0x110], xmm1
00007767631cf5a2  vmovaps xmm1, [rsp+0xE0]
00007767631cf5ab  vmovaps [rsp+0xE0], xmm15
00007767631cf5b4  movaps xmm13, xmm1
00007767631cf5b8  mulpd xmm13, xmm14
00007767631cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007767631cf5c3  ptest xmm15, xmm15
00007767631cf5c9  jnz 0x00007767631D07C4
00007767631cf5cf  vxorps xmm1, xmm1, xmm1
00007767631cf5d3  vpbroadcastq xmm1, xmm1
00007767631cf5d8  vmovaps xmm14, [rsp+0xE0]
00007767631cf5e1  vmovaps [rsp+0xE0], xmm1
00007767631cf5ea  vmovaps xmm1, [rsp+0xD0]
00007767631cf5f3  vmovaps [rsp+0xD0], xmm13
00007767631cf5fc  movaps xmm15, xmm14
00007767631cf600  mulpd xmm15, xmm1
00007767631cf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007767631cf60b  ptest xmm13, xmm13
00007767631cf611  jnz 0x00007767631D0907
00007767631cf617  movaps xmm1, xmm14
00007767631cf61b  mulpd xmm1, xmm10
00007767631cf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007767631cf625  ptest xmm13, xmm13
00007767631cf62b  jnz 0x00007767631D0A4A
00007767631cf631  movaps xmm13, xmm14
00007767631cf635  mulpd xmm13, xmm2
00007767631cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007767631cf640  ptest xmm10, xmm10
00007767631cf646  jnz 0x00007767631D0B8C
00007767631cf64c  vmovaps [rsp+0x120], xmm7
00007767631cf655  vmovaps xmm14, [rsp+0x120]
00007767631cf65e  por xmm7, xmm14
00007767631cf663  vmovaps xmm14, [rsp+0xC0]
00007767631cf66c  vmovaps xmm10, [rsp+0xC0]
00007767631cf675  por xmm14, xmm10
00007767631cf67a  vmovaps xmm2, [rsp+0x100]
00007767631cf683  vpermilpd xmm2, xmm2, 0x00
00007767631cf689  vmovaps [rsp+0xC0], xmm1
00007767631cf692  vmovaps [rsp+0x120], xmm15
00007767631cf69b  movaps xmm1, xmm10
00007767631cf69f  mulpd xmm1, xmm2
00007767631cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007767631cf6a8  ptest xmm15, xmm15
00007767631cf6ae  jnz 0x00007767631D0CCF
00007767631cf6b4  xor eax, eax
00007767631cf6b6  mov r12d, 0x40
00007767631cf6bc  mov r11d, 0x200
00007767631cf6c2  cmp r12, r11
00007767631cf6c5  cmc
00007767631cf6c6  lahf
00007767631cf6c7  seto al
00007767631cf6ca  mov [r15+0x108], eax
00007767631cf6d1  vmovaps xmm10, [rsp+0x110]
00007767631cf6da  vmovaps xmm2, [rsp+0xE0]
00007767631cf6e3  vmovaps [rsp+0xE0], xmm1
00007767631cf6ec  movaps xmm15, xmm10
00007767631cf6f0  addpd xmm15, xmm2
00007767631cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007767631cf6fb  ptest xmm1, xmm1
00007767631cf700  jnz 0x00007767631D0E10
00007767631cf706  vmovaps xmm10, [rsp+0x120]
00007767631cf70f  vmovaps [rsp+0x110], xmm15
00007767631cf718  movaps xmm1, xmm10
00007767631cf71c  addpd xmm1, xmm12
00007767631cf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007767631cf726  ptest xmm15, xmm15
00007767631cf72c  jnz 0x00007767631D0F53
00007767631cf732  vmovaps xmm10, [rsp+0xC0]
00007767631cf73b  vmovaps [rsp+0xC0], xmm1
00007767631cf744  movaps xmm15, xmm10
00007767631cf748  addpd xmm15, xmm12
00007767631cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007767631cf753  ptest xmm1, xmm1
00007767631cf758  jnz 0x00007767631D1095
00007767631cf75e  vmovaps xmm1, [rsp+0x30]
00007767631cf764  vmovaps xmm12, [rsp+0x30]
00007767631cf76a  por xmm1, xmm12
00007767631cf76f  vmovaps xmm12, [rsp+0x20]
00007767631cf775  vmovaps xmm10, [rsp+0x20]
00007767631cf77b  por xmm12, xmm10
00007767631cf780  vmovaps [rsp+0x20], xmm5
00007767631cf786  vmovaps xmm10, [rsp+0x20]
00007767631cf78c  por xmm5, xmm10
00007767631cf791  vmovaps [rsp+0x20], xmm11
00007767631cf797  vmovaps xmm10, [rsp+0x20]
00007767631cf79d  por xmm11, xmm10
00007767631cf7a2  vmovaps [rsp+0x20], xmm4
00007767631cf7a8  vmovaps xmm10, [rsp+0x20]
00007767631cf7ae  por xmm4, xmm10
00007767631cf7b3  vmovaps [rsp+0x20], xmm8
00007767631cf7b9  vmovaps xmm10, [rsp+0x20]
00007767631cf7bf  por xmm8, xmm10
00007767631cf7c4  vmovaps xmm10, [rsp+0xF0]
00007767631cf7cd  vmovaps [rsp+0x20], xmm1
00007767631cf7d3  vmovaps xmm1, [rsp+0xF0]
00007767631cf7dc  por xmm10, xmm1
00007767631cf7e1  lea rax, [r14+0xA0]
00007767631cf7e8  movups xmm1, [r13+rax*1]
00007767631cf7ee  lea rax, [r14+0xB0]
00007767631cf7f5  vmovaps [rsp+0x30], xmm1
00007767631cf7fb  movups xmm1, [r13+rax*1]
00007767631cf801  vmovaps [rsp+0xF0], xmm1
00007767631cf80a  vmovaps [rsp+0x120], xmm15
00007767631cf813  movaps xmm1, xmm13
00007767631cf817  addpd xmm1, xmm2
00007767631cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007767631cf820  ptest xmm15, xmm15
00007767631cf826  jnz 0x00007767631D11ED
00007767631cf82c  lea rax, [r14+0xF0]
00007767631cf833  movups xmm15, [r13+rax*1]
00007767631cf839  vmovaps xmm2, [rsp+0xC0]
00007767631cf842  vmovaps [rsp+0xC0], xmm1
00007767631cf84b  vmovaps xmm1, [rsp+0xE0]
00007767631cf854  vmovaps [rsp+0xE0], xmm15
00007767631cf85d  movaps xmm13, xmm2
00007767631cf861  addpd xmm13, xmm1
00007767631cf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007767631cf86c  ptest xmm15, xmm15
00007767631cf872  jnz 0x00007767631D1338
00007767631cf878  vmovaps xmm15, [rsp+0x120]
00007767631cf881  vmovaps xmm2, [rsp+0xD0]
00007767631cf88a  vmovaps [rsp+0xD0], xmm14
00007767631cf893  movaps xmm1, xmm15
00007767631cf897  addpd xmm1, xmm2
00007767631cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007767631cf8a0  ptest xmm14, xmm14
00007767631cf8a6  jnz 0x00007767631D147A
00007767631cf8ac  vmovaps xmm15, [rsp+0x100]
00007767631cf8b5  vpermilpd xmm15, xmm15, 0x00
00007767631cf8bb  vmovaps xmm2, [rsp+0xF0]
00007767631cf8c4  vmovaps [rsp+0xF0], xmm1
00007767631cf8cd  movaps xmm14, xmm2
00007767631cf8d1  mulpd xmm14, xmm15
00007767631cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007767631cf8dc  ptest xmm1, xmm1
00007767631cf8e1  jnz 0x00007767631D15BB
00007767631cf8e7  vmovaps xmm1, [rsp+0xA0]
00007767631cf8f0  vpermilpd xmm1, xmm1, 0x00
00007767631cf8f6  vmovaps xmm2, [rsp+0xE0]
00007767631cf8ff  vmovaps [rsp+0xE0], xmm14
00007767631cf908  movaps xmm15, xmm2
00007767631cf90c  mulpd xmm15, xmm1
00007767631cf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007767631cf917  ptest xmm14, xmm14
00007767631cf91d  jnz 0x00007767631D16FE
00007767631cf923  lea rax, [r14+0xE0]
00007767631cf92a  movups xmm1, [r13+rax*1]
00007767631cf930  vmovaps xmm14, [rsp+0x100]
00007767631cf939  vpermilpd xmm14, xmm14, 0x00
00007767631cf93f  vmovaps [rsp+0x100], xmm1
00007767631cf948  vmovaps xmm1, [rsp+0x30]
00007767631cf94e  vmovaps [rsp+0x30], xmm15
00007767631cf954  movaps xmm2, xmm1
00007767631cf957  mulpd xmm2, xmm14
00007767631cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007767631cf961  ptest xmm15, xmm15
00007767631cf967  jnz 0x00007767631D184A
00007767631cf96d  vmovaps [rsp+0x120], xmm10
00007767631cf976  vmovaps xmm1, [rsp+0x120]
00007767631cf97f  por xmm10, xmm1
00007767631cf984  movaps [r15+0x300], xmm10
00007767631cf98c  vmovaps [rsp+0x120], xmm8
00007767631cf995  vmovaps xmm1, [rsp+0x120]
00007767631cf99e  por xmm8, xmm1
00007767631cf9a3  movaps [r15+0x190], xmm8
00007767631cf9ab  vmovaps xmm1, [rsp+0xA0]
00007767631cf9b4  vpermilpd xmm1, xmm1, 0x00
00007767631cf9ba  vmovaps xmm14, [rsp+0x100]
00007767631cf9c3  vmovaps [rsp+0x100], xmm13
00007767631cf9cc  movaps xmm15, xmm14
00007767631cf9d0  mulpd xmm15, xmm1
00007767631cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007767631cf9db  ptest xmm13, xmm13
00007767631cf9e1  jnz 0x00007767631D198B
00007767631cf9e7  lea rax, [r14+0x90]
00007767631cf9ee  movups xmm1, [r13+rax*1]
00007767631cf9f4  vmovaps [rsp+0x120], xmm4
00007767631cf9fd  vmovaps xmm14, [rsp+0x120]
00007767631cfa06  por xmm4, xmm14
00007767631cfa0b  movaps [r15+0x1C0], xmm4
00007767631cfa13  vmovaps [rsp+0x120], xmm11
00007767631cfa1c  vmovaps xmm14, [rsp+0x120]
00007767631cfa25  por xmm11, xmm14
00007767631cfa2a  movaps [r15+0x200], xmm11
00007767631cfa32  vmovaps [rsp+0x120], xmm5
00007767631cfa3b  vmovaps xmm14, [rsp+0x120]
00007767631cfa44  por xmm5, xmm14
00007767631cfa49  movaps [r15+0x2D0], xmm5
00007767631cfa51  vmovaps [rsp+0x120], xmm12
00007767631cfa5a  vmovaps xmm14, [rsp+0x120]
00007767631cfa63  por xmm12, xmm14
00007767631cfa68  movaps [r15+0x2E0], xmm12
00007767631cfa70  vmovaps xmm13, [rsp+0x110]
00007767631cfa79  vmovaps [rsp+0x110], xmm1
00007767631cfa82  vmovaps xmm1, [rsp+0xE0]
00007767631cfa8b  vmovaps [rsp+0xE0], xmm15
00007767631cfa94  movaps xmm14, xmm13
00007767631cfa98  addpd xmm14, xmm1
00007767631cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007767631cfaa3  ptest xmm15, xmm15
00007767631cfaa9  jnz 0x00007767631D1AD8
00007767631cfaaf  vmovaps xmm1, [rsp+0xA0]
00007767631cfab8  vpermilpd xmm1, xmm1, 0x00
00007767631cfabe  vmovaps xmm13, [rsp+0x110]
00007767631cfac7  vmovaps [rsp+0x110], xmm14
00007767631cfad0  movaps xmm15, xmm13
00007767631cfad4  mulpd xmm15, xmm1
00007767631cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007767631cfadf  ptest xmm14, xmm14
00007767631cfae5  jnz 0x00007767631D1C1B
00007767631cfaeb  lea rax, [r14+0x80]
00007767631cfaf2  movups xmm1, [r13+rax*1]
00007767631cfaf8  vmovaps xmm13, [rsp+0xC0]
00007767631cfb01  vmovaps [rsp+0xC0], xmm1
00007767631cfb0a  movaps xmm14, xmm13
00007767631cfb0e  addpd xmm14, xmm2
00007767631cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007767631cfb19  ptest xmm1, xmm1
00007767631cfb1e  jnz 0x00007767631D1D68
00007767631cfb24  vmovaps xmm13, [rsp+0x100]
00007767631cfb2d  vmovaps xmm2, [rsp+0x30]
00007767631cfb33  vmovaps [rsp+0x30], xmm15
00007767631cfb39  movaps xmm1, xmm13
00007767631cfb3d  addpd xmm1, xmm2
00007767631cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007767631cfb46  ptest xmm15, xmm15
00007767631cfb4c  jnz 0x00007767631D1EAB
00007767631cfb52  vmovaps xmm15, [rsp+0x20]
00007767631cfb58  vmovaps xmm13, [rsp+0x20]
00007767631cfb5e  por xmm15, xmm13
00007767631cfb63  movaps [r15+0x2F0], xmm15
00007767631cfb6b  vmovaps xmm13, [rsp+0xA0]
00007767631cfb74  vpermilpd xmm13, xmm13, 0x00
00007767631cfb7a  vmovaps [rsp+0x20], xmm1
00007767631cfb80  vmovaps xmm1, [rsp+0xC0]
00007767631cfb89  vmovaps [rsp+0xA0], xmm15
00007767631cfb92  movaps xmm2, xmm1
00007767631cfb95  mulpd xmm2, xmm13
00007767631cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007767631cfb9f  ptest xmm15, xmm15
00007767631cfba5  jnz 0x00007767631D1FEC
00007767631cfbab  lea rax, [r14+0xD0]
00007767631cfbb2  movups xmm1, [r13+rax*1]
00007767631cfbb8  vmovaps xmm13, [rsp+0xF0]
00007767631cfbc1  vmovaps [rsp+0xC0], xmm1
00007767631cfbca  vmovaps xmm1, [rsp+0xE0]
00007767631cfbd3  vmovaps [rsp+0xE0], xmm14
00007767631cfbdc  movaps xmm15, xmm13
00007767631cfbe0  addpd xmm15, xmm1
00007767631cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007767631cfbeb  ptest xmm14, xmm14
00007767631cfbf1  jnz 0x00007767631D2137
00007767631cfbf7  vmovaps xmm1, [rsp+0xB0]
00007767631cfc00  vpermilpd xmm1, xmm1, 0x00
00007767631cfc06  movaps xmm14, xmm11
00007767631cfc0a  mulpd xmm14, xmm1
00007767631cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007767631cfc15  ptest xmm13, xmm13
00007767631cfc1b  jnz 0x00007767631D227A
00007767631cfc21  movaps [r15+0x260], xmm14
00007767631cfc29  vxorps xmm1, xmm1, xmm1
00007767631cfc2d  vpbroadcastq xmm1, xmm1
00007767631cfc32  movaps [r15+0x1B0], xmm1
00007767631cfc3a  vmovaps xmm1, [rsp+0xB0]
00007767631cfc43  vpermilpd xmm1, xmm1, 0x00
00007767631cfc49  vmovaps xmm11, [rsp+0xC0]
00007767631cfc52  vmovaps [rsp+0xC0], xmm15
00007767631cfc5b  movaps xmm13, xmm11
00007767631cfc5f  mulpd xmm13, xmm1
00007767631cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007767631cfc6a  ptest xmm15, xmm15
00007767631cfc70  jnz 0x00007767631D23BD
00007767631cfc76  lea rax, [r14+0xC0]
00007767631cfc7d  movups xmm1, [r13+rax*1]
00007767631cfc83  vmovaps xmm11, [rsp+0x110]
00007767631cfc8c  vmovaps [rsp+0xF0], xmm1
00007767631cfc95  vmovaps xmm1, [rsp+0x30]
00007767631cfc9b  vmovaps [rsp+0x30], xmm14
00007767631cfca1  movaps xmm15, xmm11
00007767631cfca5  addpd xmm15, xmm1
00007767631cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007767631cfcb0  ptest xmm14, xmm14
00007767631cfcb6  jnz 0x00007767631D250A
00007767631cfcbc  vmovaps [rsp+0x100], xmm9
00007767631cfcc5  vmovaps xmm1, [rsp+0x100]
00007767631cfcce  por xmm9, xmm1
00007767631cfcd3  movaps [r15+0x270], xmm9
00007767631cfcdb  vmovaps [rsp+0x100], xmm6
00007767631cfce4  vmovaps xmm1, [rsp+0x100]
00007767631cfced  por xmm6, xmm1
00007767631cfcf1  movaps [r15+0x1A0], xmm6
00007767631cfcf9  vmovaps xmm14, [rsp+0xB0]
00007767631cfd02  vpermilpd xmm14, xmm14, 0x00
00007767631cfd08  vmovaps xmm6, [rsp+0xF0]
00007767631cfd11  vmovaps [rsp+0xF0], xmm1
00007767631cfd1a  movaps xmm11, xmm6
00007767631cfd1e  mulpd xmm11, xmm14
00007767631cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007767631cfd29  ptest xmm1, xmm1
00007767631cfd2e  jnz 0x00007767631D264D
00007767631cfd34  lea rax, [r14+0x20]
00007767631cfd38  movups xmm1, [r13+rax*1]
00007767631cfd3e  movaps [r15+0x110], xmm1
00007767631cfd46  vmovaps xmm6, [rsp+0xE0]
00007767631cfd4f  vmovaps [rsp+0xE0], xmm1
00007767631cfd58  movaps xmm14, xmm6
00007767631cfd5c  addpd xmm14, xmm2
00007767631cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007767631cfd67  ptest xmm1, xmm1
00007767631cfd6c  jnz 0x00007767631D279A
00007767631cfd72  vmovaps xmm1, [rsp+0xB0]
00007767631cfd7b  vpermilpd xmm1, xmm1, 0x00
00007767631cfd81  movaps xmm6, xmm5
00007767631cfd84  mulpd xmm6, xmm1
00007767631cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007767631cfd8d  ptest xmm2, xmm2
00007767631cfd92  jnz 0x00007767631D28DC
00007767631cfd98  vmovaps xmm5, [rsp+0x20]
00007767631cfd9e  movaps xmm1, xmm5
00007767631cfda1  addpd xmm1, xmm13
00007767631cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007767631cfdab  ptest xmm2, xmm2
00007767631cfdb0  jnz 0x00007767631D2A1C
00007767631cfdb6  vmovaps xmm13, [rsp+0x80]
00007767631cfdbf  vpermilpd xmm13, xmm13, 0x00
00007767631cfdc5  vmovaps xmm2, [rsp+0xE0]
00007767631cfdce  vmovaps [rsp+0x20], xmm1
00007767631cfdd4  movaps xmm5, xmm2
00007767631cfdd7  mulpd xmm5, xmm13
00007767631cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007767631cfde1  ptest xmm1, xmm1
00007767631cfde6  jnz 0x00007767631D2B5D
00007767631cfdec  vmovaps xmm1, [rsp+0x80]
00007767631cfdf5  vpermilpd xmm1, xmm1, 0x00
00007767631cfdfb  movaps xmm13, xmm10
00007767631cfdff  mulpd xmm13, xmm1
00007767631cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007767631cfe0a  ptest xmm2, xmm2
00007767631cfe0f  jnz 0x00007767631D2C9E
00007767631cfe15  vmovaps xmm10, [rsp+0x30]
00007767631cfe1b  movaps xmm1, xmm15
00007767631cfe1f  addpd xmm1, xmm10
00007767631cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007767631cfe29  ptest xmm2, xmm2
00007767631cfe2e  jnz 0x00007767631D2DE1
00007767631cfe34  vmovaps xmm10, [rsp+0xC0]
00007767631cfe3d  movaps xmm15, xmm10
00007767631cfe41  addpd xmm15, xmm11
00007767631cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007767631cfe4c  ptest xmm2, xmm2
00007767631cfe51  jnz 0x00007767631D2F23
00007767631cfe57  vmovaps xmm11, [rsp+0x80]
00007767631cfe60  vpermilpd xmm11, xmm11, 0x00
00007767631cfe66  movaps xmm10, xmm12
00007767631cfe6a  mulpd xmm10, xmm11
00007767631cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007767631cfe75  ptest xmm2, xmm2
00007767631cfe7a  jnz 0x00007767631D3067
00007767631cfe80  vmovaps xmm12, [rsp+0x80]
00007767631cfe89  vpermilpd xmm12, xmm12, 0x00
00007767631cfe8f  vmovaps xmm2, [rsp+0xA0]
00007767631cfe98  vmovaps [rsp+0x30], xmm1
00007767631cfe9e  movaps xmm11, xmm2
00007767631cfea2  mulpd xmm11, xmm12
00007767631cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007767631cfead  ptest xmm1, xmm1
00007767631cfeb2  jnz 0x00007767631D31AB
00007767631cfeb8  movaps xmm1, xmm14
00007767631cfebc  addpd xmm1, xmm6
00007767631cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007767631cfec5  ptest xmm12, xmm12
00007767631cfecb  jnz 0x00007767631D32EE
00007767631cfed1  vmovaps xmm12, [rsp+0x20]
00007767631cfed7  movaps xmm14, xmm12
00007767631cfedb  addpd xmm14, xmm5
00007767631cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007767631cfee6  ptest xmm6, xmm6
00007767631cfeeb  jnz 0x00007767631D342F
00007767631cfef1  vmovaps xmm12, [rsp+0x90]
00007767631cfefa  vpermilpd xmm12, xmm12, 0x00
00007767631cff00  movaps xmm6, xmm9
00007767631cff04  mulpd xmm6, xmm12
00007767631cff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007767631cff0e  ptest xmm5, xmm5
00007767631cff13  jnz 0x00007767631D3572
00007767631cff19  movaps xmm12, xmm15
00007767631cff1d  addpd xmm12, xmm13
00007767631cff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007767631cff28  ptest xmm9, xmm9
00007767631cff2e  jnz 0x00007767631D36B4
00007767631cff34  vmovaps xmm13, [rsp+0x30]
00007767631cff3a  movaps xmm15, xmm13
00007767631cff3e  addpd xmm15, xmm10
00007767631cff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007767631cff49  ptest xmm9, xmm9
00007767631cff4f  jnz 0x00007767631D37F8
00007767631cff55  vmovaps xmm13, [rsp+0xD0]
00007767631cff5e  vmovaps xmm10, [rsp+0xD0]
00007767631cff67  por xmm13, xmm10
00007767631cff6c  movaps [r15+0x250], xmm13
00007767631cff74  vmovaps [rsp+0x20], xmm7
00007767631cff7a  vmovaps xmm13, [rsp+0x20]
00007767631cff80  por xmm7, xmm13
00007767631cff85  movaps [r15+0x2A0], xmm7
00007767631cff8d  vmovaps [rsp+0x20], xmm3
00007767631cff93  vmovaps xmm13, [rsp+0x20]
00007767631cff99  por xmm3, xmm13
00007767631cff9e  movaps [r15+0x1D0], xmm3
00007767631cffa6  lea rax, [r14+0x40]
00007767631cffaa  movups xmm13, [r13+rax*1]
00007767631cffb0  movaps [r15+0x2C0], xmm13
00007767631cffb8  vmovaps xmm10, [rsp+0x90]
00007767631cffc1  vpermilpd xmm10, xmm10, 0x00
00007767631cffc7  movaps xmm9, xmm8
00007767631cffcb  mulpd xmm9, xmm10
00007767631cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007767631cffd6  ptest xmm5, xmm5
00007767631cffdb  jnz 0x00007767631D3946
00007767631cffe1  movaps xmm10, xmm1
00007767631cffe5  addpd xmm10, xmm11
00007767631cffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007767631cfff0  ptest xmm8, xmm8
00007767631cfff6  jnz 0x00007767631D3A8A
00007767631cfffc  movaps xmm1, xmm14
00007767631d0000  addpd xmm1, xmm6
00007767631d0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007767631d0009  ptest xmm11, xmm11
00007767631d000f  jnz 0x00007767631D3BCD
00007767631d0015  vmovaps xmm14, [rsp+0x90]
00007767631d001e  vpermilpd xmm14, xmm14, 0x00
00007767631d0024  movaps xmm11, xmm13
00007767631d0028  mulpd xmm11, xmm14
00007767631d002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007767631d0033  ptest xmm8, xmm8
00007767631d0039  jnz 0x00007767631D3D0E
00007767631d003f  vmovaps xmm14, [rsp+0x90]
00007767631d0048  vpermilpd xmm14, xmm14, 0x00
00007767631d004e  vmovaps xmm8, [rsp+0x10]
00007767631d0054  movaps xmm13, xmm8
00007767631d0058  mulpd xmm13, xmm14
00007767631d005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007767631d0063  ptest xmm6, xmm6
00007767631d0068  jnz 0x00007767631D3E52
00007767631d006e  vmovaps xmm14, [rsp+0x60]
00007767631d0074  vpermilpd xmm14, xmm14, 0x00
00007767631d007a  movaps xmm8, xmm7
00007767631d007e  mulpd xmm8, xmm14
00007767631d0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007767631d0089  ptest xmm6, xmm6
00007767631d008e  jnz 0x00007767631D3F96
00007767631d0094  movaps xmm14, xmm12
00007767631d0098  addpd xmm14, xmm9
00007767631d009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007767631d00a3  ptest xmm7, xmm7
00007767631d00a8  jnz 0x00007767631D40D9
00007767631d00ae  vmovaps xmm12, [rsp+0x60]
00007767631d00b4  vpermilpd xmm12, xmm12, 0x00
00007767631d00ba  vmovaps xmm7, [rsp+0xF0]
00007767631d00c3  movaps xmm9, xmm7
00007767631d00c7  mulpd xmm9, xmm12
00007767631d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007767631d00d2  ptest xmm6, xmm6
00007767631d00d7  jnz 0x00007767631D421D
00007767631d00dd  movaps xmm12, xmm15
00007767631d00e1  addpd xmm12, xmm11
00007767631d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007767631d00ec  ptest xmm7, xmm7
00007767631d00f1  jnz 0x00007767631D4360
00007767631d00f7  vmovaps xmm15, [rsp+0x60]
00007767631d00fd  vpermilpd xmm15, xmm15, 0x00
00007767631d0103  vmovaps xmm7, [rsp+0x40]
00007767631d0109  movaps xmm11, xmm7
00007767631d010d  mulpd xmm11, xmm15
00007767631d0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007767631d0118  ptest xmm6, xmm6
00007767631d011d  jnz 0x00007767631D44A4
00007767631d0123  movaps xmm15, xmm10
00007767631d0127  addpd xmm15, xmm13
00007767631d012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007767631d0132  ptest xmm7, xmm7
00007767631d0137  jnz 0x00007767631D45E7
00007767631d013d  vmovaps xmm13, [rsp+0x60]
00007767631d0143  vpermilpd xmm13, xmm13, 0x00
00007767631d0149  vmovaps xmm7, [rsp+0x50]
00007767631d014f  movaps xmm10, xmm7
00007767631d0153  mulpd xmm10, xmm13
00007767631d0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007767631d015e  ptest xmm6, xmm6
00007767631d0163  jnz 0x00007767631D472B
00007767631d0169  movaps xmm13, xmm1
00007767631d016d  addpd xmm13, xmm8
00007767631d0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007767631d0178  ptest xmm7, xmm7
00007767631d017d  jnz 0x00007767631D486E
00007767631d0183  lea rax, [r14+0x70]
00007767631d0187  movups xmm1, [r13+rax*1]
00007767631d018d  movaps [r15+0x240], xmm1
00007767631d0195  movaps xmm8, xmm14
00007767631d0199  addpd xmm8, xmm9
00007767631d019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007767631d01a4  ptest xmm7, xmm7
00007767631d01a9  jnz 0x00007767631D49BB
00007767631d01af  movaps [r15+0x170], xmm8
00007767631d01b7  vmovaps xmm14, [rsp+0x70]
00007767631d01bd  vpermilpd xmm14, xmm14, 0x00
00007767631d01c3  movaps xmm9, xmm1
00007767631d01c7  mulpd xmm9, xmm14
00007767631d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007767631d01d2  ptest xmm7, xmm7
00007767631d01d7  jnz 0x00007767631D4AFF
00007767631d01dd  vmovaps xmm1, [rsp+0x70]
00007767631d01e3  vpermilpd xmm1, xmm1, 0x00
00007767631d01e9  movaps xmm14, xmm4
00007767631d01ed  mulpd xmm14, xmm1
00007767631d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007767631d01f8  ptest xmm7, xmm7
00007767631d01fd  jnz 0x00007767631D4C42
00007767631d0203  movaps [r15+0x180], xmm14
00007767631d020b  movaps xmm1, xmm12
00007767631d020f  addpd xmm1, xmm11
00007767631d0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007767631d0219  ptest xmm7, xmm7
00007767631d021e  jnz 0x00007767631D4D84
00007767631d0224  movaps [r15+0x210], xmm1
00007767631d022c  movups xmm12, [r13+r14*1]
00007767631d0232  lea rax, [r14+0x10]
00007767631d0236  movups xmm11, [r13+rax*1]
00007767631d023c  movaps [r15+0x230], xmm11
00007767631d0244  movaps xmm7, xmm15
00007767631d0248  addpd xmm7, xmm10
00007767631d024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007767631d0252  ptest xmm6, xmm6
00007767631d0257  jnz 0x00007767631D4EDA
00007767631d025d  movaps [r15+0x130], xmm7
00007767631d0265  vmovaps xmm15, [rsp+0x70]
00007767631d026b  vpermilpd xmm15, xmm15, 0x00
00007767631d0271  movaps xmm10, xmm11
00007767631d0275  mulpd xmm10, xmm15
00007767631d027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007767631d0280  ptest xmm6, xmm6
00007767631d0285  jnz 0x00007767631D501C
00007767631d028b  movaps [r15+0x220], xmm10
00007767631d0293  vmovaps xmm15, [rsp+0x70]
00007767631d0299  vpermilpd xmm15, xmm15, 0x00
00007767631d029f  movaps xmm11, xmm12
00007767631d02a3  mulpd xmm11, xmm15
00007767631d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007767631d02ae  ptest xmm6, xmm6
00007767631d02b3  jnz 0x00007767631D5160
00007767631d02b9  movaps xmm15, xmm13
00007767631d02bd  addpd xmm15, xmm9
00007767631d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007767631d02c8  ptest xmm12, xmm12
00007767631d02ce  jnz 0x00007767631D52A4
00007767631d02d4  movaps [r15+0x140], xmm15
00007767631d02dc  movaps xmm13, xmm8
00007767631d02e0  addpd xmm13, xmm14
00007767631d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007767631d02eb  ptest xmm12, xmm12
00007767631d02f1  jnz 0x00007767631D53E8
00007767631d02f7  movaps [r15+0x150], xmm13
00007767631d02ff  movaps xmm14, xmm1
00007767631d0303  addpd xmm14, xmm10
00007767631d0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007767631d030e  ptest xmm12, xmm12
00007767631d0314  jnz 0x00007767631D552C
00007767631d031a  movaps [r15+0x160], xmm14
00007767631d0322  movaps xmm1, xmm7
00007767631d0325  addpd xmm1, xmm11
00007767631d032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007767631d032f  ptest xmm12, xmm12
00007767631d0335  jnz 0x00007767631D566F
00007767631d033b  movaps [r15+0x120], xmm1
00007767631d0343  mov eax, 0x430920
00007767631d0348  movups [r13+rax*1], xmm15
00007767631d034e  mov eax, 0x430930
00007767631d0353  movups [r13+rax*1], xmm13
00007767631d0359  mov eax, 0x430940
00007767631d035e  movups [r13+rax*1], xmm14
00007767631d0364  mov eax, 0x430950
00007767631d0369  movups [r13+rax*1], xmm1
00007767631d036f  mov eax, [r15+0x108]
00007767631d0376  sahf
00007767631d0377  jnz 0x00007767631D03A9
00007767631d0379  cmp dword ptr [r15+0x318], 0x00
00007767631d0381  jz 0x00007767631DB900
00007767631d0387  nop [rax+rax*1], ax
00007767631d0390  nop [rax+rax*1], eax
00007767631d0398  mov eax, 0x410444
00007767631d039d  mov [r15+0x100], rax
00007767631d03a4  jmp 0x0000776762FFE110
00007767631d03a9  cmp dword ptr [r15+0x318], 0x00
00007767631d03b1  jz 0x00007767631D57E0
00007767631d03b7  nop [rax+rax*1], ax
00007767631d03c0  nop [rax+rax*1], eax
00007767631d03c8  mov eax, 0x410278
00007767631d03cd  mov [r15+0x100], rax
00007767631d03d4  jmp 0x0000776762FFE110
00007767631d03d9  int3
00007767631d03da  call 0x00007767630B52F0
00007767631d03df  jmp 0x00007767631CF016
00007767631d03e4  call 0x00007767630C4620
00007767631d03e9  jmp 0x00007767631CF023
00007767631d03ee  call 0x00007767630C33A0
00007767631d03f3  jmp 0x00007767631CF035
00007767631d03f8  call 0x00007767630C2120
00007767631d03fd  jmp 0x00007767631CF03F
00007767631d0402  call 0x00007767630C0860
00007767631d0407  jmp 0x00007767631CF067
00007767631d040c  call 0x00007767630BF5F0
00007767631d0411  jmp 0x00007767631CF073
00007767631d0416  call 0x00007767630C0860
00007767631d041b  jmp 0x00007767631CF0A5
00007767631d0420  call 0x00007767630BF5F0
00007767631d0425  jmp 0x00007767631CF0B1
00007767631d042a  call 0x00007767630C4740
00007767631d042f  jmp 0x00007767631CF0BE
00007767631d0434  call 0x00007767630B5400
00007767631d0439  jmp 0x00007767631CF0CB
00007767631d043e  call 0x00007767630B52F0
00007767631d0443  jmp 0x00007767631CF0D8
00007767631d0448  call 0x00007767630C4620
00007767631d044d  jmp 0x00007767631CF0E5
00007767631d0452  call 0x00007767630C0860
00007767631d0457  jmp 0x00007767631CF10D
00007767631d045c  call 0x00007767630BF5F0
00007767631d0461  jmp 0x00007767631CF119
00007767631d0466  call 0x0000776763009D70
00007767631d046b  jmp 0x00007767631CF11F
00007767631d0470  call 0x00007767630BE9C0
00007767631d0475  jmp 0x00007767631CF129
00007767631d047a  call 0x00007767630C0860
00007767631d047f  jmp 0x00007767631CF151
00007767631d0484  call 0x00007767630BF5F0
00007767631d0489  jmp 0x00007767631CF15D
00007767631d048e  call 0x00007767630BD750
00007767631d0493  jmp 0x00007767631CF16A
00007767631d0498  call 0x00007767630BC4E0
00007767631d049d  jmp 0x00007767631CF177
00007767631d04a2  call 0x00007767630C4740
00007767631d04a7  jmp 0x00007767631CF184
00007767631d04ac  call 0x00007767630B5400
00007767631d04b1  jmp 0x00007767631CF191
00007767631d04b6  call 0x00007767630B52F0
00007767631d04bb  jmp 0x00007767631CF19E
00007767631d04c0  call 0x00007767630C4620
00007767631d04c5  jmp 0x00007767631CF1AB
00007767631d04ca  call 0x00007767630C0860
00007767631d04cf  jmp 0x00007767631CF1BE
00007767631d04d4  call 0x00007767630BB270
00007767631d04d9  jmp 0x00007767631CF1CB
00007767631d04de  call 0x00007767630BA000
00007767631d04e3  jmp 0x00007767631CF1D8
00007767631d04e8  call 0x00007767630B8D90
00007767631d04ed  jmp 0x00007767631CF1E5
00007767631d04f2  call 0x00007767630B8A20
00007767631d04f7  jmp 0x00007767631CF1F2
00007767631d04fc  call 0x00007767630B5400
00007767631d0501  jmp 0x00007767631CF1FC
00007767631d0506  call 0x00007767630C2240
00007767631d050b  jmp 0x00007767631CF206
00007767631d0510  call 0x00007767630B52F0
00007767631d0515  jmp 0x00007767631CF210
00007767631d051a  call 0x00007767630C2120
00007767631d051f  jmp 0x00007767631CF21A
00007767631d0524  call 0x00007767630B77B0
00007767631d0529  jmp 0x00007767631CF224
00007767631d052e  call 0x00007767630B6550
00007767631d0533  jmp 0x00007767631CF22E
00007767631d0538  call 0x00007767630BFD50
00007767631d053d  jmp 0x00007767631CF240
00007767631d0542  call 0x00007767630B8EA0
00007767631d0547  jmp 0x00007767631CF24A
00007767631d054c  call 0x00007767630BFC30
00007767631d0551  jmp 0x00007767631CF257
00007767631d0556  call 0x00007767630B8D90
00007767631d055b  jmp 0x00007767631CF264
00007767631d0560  call 0x00007767630C2240
00007767631d0565  jmp 0x00007767631CF271
00007767631d056a  call 0x00007767630B5400
00007767631d056f  jmp 0x00007767631CF27E
00007767631d0574  call 0x00007767630B52F0
00007767631d0579  jmp 0x00007767631CF28B
00007767631d057e  call 0x00007767630C2120
00007767631d0583  jmp 0x00007767631CF298
00007767631d0588  call 0x00007767630B52F0
00007767631d058d  jmp 0x00007767631CF2AB
00007767631d0592  call 0x00007767630B52F0
00007767631d0597  jmp 0x00007767631CF2BE
00007767631d059c  call 0x00007767630B52F0
00007767631d05a1  jmp 0x00007767631CF2D1
00007767631d05a6  call 0x00007767630B52F0
00007767631d05ab  jmp 0x00007767631CF2E4
00007767631d05b0  call 0x00007767630C2240
00007767631d05b5  jmp 0x00007767631CF2F9
00007767631d05ba  call 0x00007767630C2240
00007767631d05bf  jmp 0x00007767631CF30C
00007767631d05c4  call 0x00007767630C2120
00007767631d05c9  jmp 0x00007767631CF319
00007767631d05ce  call 0x00007767630B52F0
00007767631d05d3  jmp 0x00007767631CF32C
00007767631d05d8  call 0x00007767630B52F0
00007767631d05dd  jmp 0x00007767631CF34F
00007767631d05e2  call 0x00007767630B52F0
00007767631d05e7  jmp 0x00007767631CF362
00007767631d05ec  call 0x0000776762FFF540
00007767631d05f1  jmp 0x00007767631CF380
00007767631d05f6  call 0x0000776763008C20
00007767631d05fb  jmp 0x00007767631CF38A
00007767631d0600  call 0x00007767630D6600
00007767631d0605  jmp 0x00007767631CF396
00007767631d060a  call 0x0000776762FFF540
00007767631d060f  jmp 0x00007767631CF3A6
00007767631d0614  call 0x00007767630C0370
00007767631d0619  jmp 0x00007767631CF3D4
00007767631d061e  call 0x00007767630BF100
00007767631d0623  jmp 0x00007767631CF3DD
00007767631d0628  call 0x00007767630C0370
00007767631d062d  jmp 0x00007767631CF43B
00007767631d0632  call 0x00007767630BF100
00007767631d0637  jmp 0x00007767631CF444
00007767631d063c  call 0x00007767630C0370
00007767631d0641  jmp 0x00007767631CF48B
00007767631d0646  call 0x00007767630BF100
00007767631d064b  jmp 0x00007767631CF494
00007767631d0650  call 0x000077676300B720
00007767631d0655  jmp 0x00007767631CF4D7
00007767631d065a  call 0x00007767630B47C0
00007767631d065f  jmp 0x00007767631CF4EA
00007767631d0664  call 0x0000776763008B00
00007767631d0669  jmp 0x00007767631CF501
00007767631d066e  call 0x0000776762FFF430
00007767631d0673  jmp 0x00007767631CF514
00007767631d0678  call 0x0000776762FFF430
00007767631d067d  jmp 0x00007767631CF527
00007767631d0682  sub rsp, 0x08
00007767631d0686  push rax
00007767631d0687  push rcx
00007767631d0688  push rdx
00007767631d0689  push rdi
00007767631d068a  push rsi
00007767631d068b  push r8
00007767631d068d  push r9
00007767631d068f  push r10
00007767631d0691  push r11
00007767631d0693  sub rsp, 0xF0
00007767631d069a  vmovaps [rsp], xmm0
00007767631d069f  vmovaps [rsp+0x10], xmm2
00007767631d06a5  vmovaps [rsp+0x20], xmm3
00007767631d06ab  vmovaps [rsp+0x30], xmm4
00007767631d06b1  vmovaps [rsp+0x40], xmm5
00007767631d06b7  vmovaps [rsp+0x50], xmm6
00007767631d06bd  vmovaps [rsp+0x60], xmm7
00007767631d06c3  vmovaps [rsp+0x70], xmm8
00007767631d06c9  vmovaps [rsp+0x80], xmm9
00007767631d06d2  vmovaps [rsp+0x90], xmm10
00007767631d06db  vmovaps [rsp+0xA0], xmm11
00007767631d06e4  vmovaps [rsp+0xB0], xmm12
00007767631d06ed  vmovaps [rsp+0xC0], xmm13
00007767631d06f6  vmovaps [rsp+0xD0], xmm14
00007767631d06ff  vmovaps [rsp+0xE0], xmm15
00007767631d0708  sub rsp, 0x30
00007767631d070c  movaps [rsp], xmm1
00007767631d0710  movaps [rsp+0x10], xmm15
00007767631d0716  movaps [rsp+0x20], xmm14
00007767631d071c  lea rdi, [rsp]
00007767631d0720  mov esi, 0x00
00007767631d0725  mov rax, 0x617961CDB530
00007767631d072f  call rax
00007767631d0731  movaps xmm1, [rsp]
00007767631d0735  add rsp, 0x30
00007767631d0739  vmovaps xmm0, [rsp]
00007767631d073e  vmovaps xmm2, [rsp+0x10]
00007767631d0744  vmovaps xmm3, [rsp+0x20]
00007767631d074a  vmovaps xmm4, [rsp+0x30]
00007767631d0750  vmovaps xmm5, [rsp+0x40]
00007767631d0756  vmovaps xmm6, [rsp+0x50]
00007767631d075c  vmovaps xmm7, [rsp+0x60]
00007767631d0762  vmovaps xmm8, [rsp+0x70]
00007767631d0768  vmovaps xmm9, [rsp+0x80]
00007767631d0771  vmovaps xmm10, [rsp+0x90]
00007767631d077a  vmovaps xmm11, [rsp+0xA0]
00007767631d0783  vmovaps xmm12, [rsp+0xB0]
00007767631d078c  vmovaps xmm13, [rsp+0xC0]
00007767631d0795  vmovaps xmm14, [rsp+0xD0]
00007767631d079e  vmovaps xmm15, [rsp+0xE0]
00007767631d07a7  add rsp, 0xF0
00007767631d07ae  pop r11
00007767631d07b0  pop r10
00007767631d07b2  pop r9
00007767631d07b4  pop r8
00007767631d07b6  pop rsi
00007767631d07b7  pop rdi
00007767631d07b8  pop rdx
00007767631d07b9  pop rcx
00007767631d07ba  pop rax
00007767631d07bb  add rsp, 0x08
00007767631d07bf  jmp 0x00007767631CF581
00007767631d07c4  sub rsp, 0x08
00007767631d07c8  push rax
00007767631d07c9  push rcx
00007767631d07ca  push rdx
00007767631d07cb  push rdi
00007767631d07cc  push rsi
00007767631d07cd  push r8
00007767631d07cf  push r9
00007767631d07d1  push r10
00007767631d07d3  push r11
00007767631d07d5  sub rsp, 0xF0
00007767631d07dc  vmovaps [rsp], xmm0
00007767631d07e1  vmovaps [rsp+0x10], xmm1
00007767631d07e7  vmovaps [rsp+0x20], xmm2
00007767631d07ed  vmovaps [rsp+0x30], xmm3
00007767631d07f3  vmovaps [rsp+0x40], xmm4
00007767631d07f9  vmovaps [rsp+0x50], xmm5
00007767631d07ff  vmovaps [rsp+0x60], xmm6
00007767631d0805  vmovaps [rsp+0x70], xmm7
00007767631d080b  vmovaps [rsp+0x80], xmm8
00007767631d0814  vmovaps [rsp+0x90], xmm9
00007767631d081d  vmovaps [rsp+0xA0], xmm10
00007767631d0826  vmovaps [rsp+0xB0], xmm11
00007767631d082f  vmovaps [rsp+0xC0], xmm12
00007767631d0838  vmovaps [rsp+0xD0], xmm14
00007767631d0841  vmovaps [rsp+0xE0], xmm15
00007767631d084a  sub rsp, 0x30
00007767631d084e  movaps [rsp], xmm13
00007767631d0853  movaps [rsp+0x10], xmm1
00007767631d0858  movaps [rsp+0x20], xmm14
00007767631d085e  lea rdi, [rsp]
00007767631d0862  mov esi, 0x00
00007767631d0867  mov rax, 0x617961CDB530
00007767631d0871  call rax
00007767631d0873  movaps xmm13, [rsp]
00007767631d0878  add rsp, 0x30
00007767631d087c  vmovaps xmm0, [rsp]
00007767631d0881  vmovaps xmm1, [rsp+0x10]
00007767631d0887  vmovaps xmm2, [rsp+0x20]
00007767631d088d  vmovaps xmm3, [rsp+0x30]
00007767631d0893  vmovaps xmm4, [rsp+0x40]
00007767631d0899  vmovaps xmm5, [rsp+0x50]
00007767631d089f  vmovaps xmm6, [rsp+0x60]
00007767631d08a5  vmovaps xmm7, [rsp+0x70]
00007767631d08ab  vmovaps xmm8, [rsp+0x80]
00007767631d08b4  vmovaps xmm9, [rsp+0x90]
00007767631d08bd  vmovaps xmm10, [rsp+0xA0]
00007767631d08c6  vmovaps xmm11, [rsp+0xB0]
00007767631d08cf  vmovaps xmm12, [rsp+0xC0]
00007767631d08d8  vmovaps xmm14, [rsp+0xD0]
00007767631d08e1  vmovaps xmm15, [rsp+0xE0]
00007767631d08ea  add rsp, 0xF0
00007767631d08f1  pop r11
00007767631d08f3  pop r10
00007767631d08f5  pop r9
00007767631d08f7  pop r8
00007767631d08f9  pop rsi
00007767631d08fa  pop rdi
00007767631d08fb  pop rdx
00007767631d08fc  pop rcx
00007767631d08fd  pop rax
00007767631d08fe  add rsp, 0x08
00007767631d0902  jmp 0x00007767631CF5CF
00007767631d0907  sub rsp, 0x08
00007767631d090b  push rax
00007767631d090c  push rcx
00007767631d090d  push rdx
00007767631d090e  push rdi
00007767631d090f  push rsi
00007767631d0910  push r8
00007767631d0912  push r9
00007767631d0914  push r10
00007767631d0916  push r11
00007767631d0918  sub rsp, 0xF0
00007767631d091f  vmovaps [rsp], xmm0
00007767631d0924  vmovaps [rsp+0x10], xmm1
00007767631d092a  vmovaps [rsp+0x20], xmm2
00007767631d0930  vmovaps [rsp+0x30], xmm3
00007767631d0936  vmovaps [rsp+0x40], xmm4
00007767631d093c  vmovaps [rsp+0x50], xmm5
00007767631d0942  vmovaps [rsp+0x60], xmm6
00007767631d0948  vmovaps [rsp+0x70], xmm7
00007767631d094e  vmovaps [rsp+0x80], xmm8
00007767631d0957  vmovaps [rsp+0x90], xmm9
00007767631d0960  vmovaps [rsp+0xA0], xmm10
00007767631d0969  vmovaps [rsp+0xB0], xmm11
00007767631d0972  vmovaps [rsp+0xC0], xmm12
00007767631d097b  vmovaps [rsp+0xD0], xmm13
00007767631d0984  vmovaps [rsp+0xE0], xmm14
00007767631d098d  sub rsp, 0x30
00007767631d0991  movaps [rsp], xmm15
00007767631d0996  movaps [rsp+0x10], xmm14
00007767631d099c  movaps [rsp+0x20], xmm1
00007767631d09a1  lea rdi, [rsp]
00007767631d09a5  mov esi, 0x00
00007767631d09aa  mov rax, 0x617961CDB530
00007767631d09b4  call rax
00007767631d09b6  movaps xmm15, [rsp]
00007767631d09bb  add rsp, 0x30
00007767631d09bf  vmovaps xmm0, [rsp]
00007767631d09c4  vmovaps xmm1, [rsp+0x10]
00007767631d09ca  vmovaps xmm2, [rsp+0x20]
00007767631d09d0  vmovaps xmm3, [rsp+0x30]
00007767631d09d6  vmovaps xmm4, [rsp+0x40]
00007767631d09dc  vmovaps xmm5, [rsp+0x50]
00007767631d09e2  vmovaps xmm6, [rsp+0x60]
00007767631d09e8  vmovaps xmm7, [rsp+0x70]
00007767631d09ee  vmovaps xmm8, [rsp+0x80]
00007767631d09f7  vmovaps xmm9, [rsp+0x90]
00007767631d0a00  vmovaps xmm10, [rsp+0xA0]
00007767631d0a09  vmovaps xmm11, [rsp+0xB0]
00007767631d0a12  vmovaps xmm12, [rsp+0xC0]
00007767631d0a1b  vmovaps xmm13, [rsp+0xD0]
00007767631d0a24  vmovaps xmm14, [rsp+0xE0]
00007767631d0a2d  add rsp, 0xF0
00007767631d0a34  pop r11
00007767631d0a36  pop r10
00007767631d0a38  pop r9
00007767631d0a3a  pop r8
00007767631d0a3c  pop rsi
00007767631d0a3d  pop rdi
00007767631d0a3e  pop rdx
00007767631d0a3f  pop rcx
00007767631d0a40  pop rax
00007767631d0a41  add rsp, 0x08
00007767631d0a45  jmp 0x00007767631CF617
00007767631d0a4a  sub rsp, 0x08
00007767631d0a4e  push rax
00007767631d0a4f  push rcx
00007767631d0a50  push rdx
00007767631d0a51  push rdi
00007767631d0a52  push rsi
00007767631d0a53  push r8
00007767631d0a55  push r9
00007767631d0a57  push r10
00007767631d0a59  push r11
00007767631d0a5b  sub rsp, 0xF0
00007767631d0a62  vmovaps [rsp], xmm0
00007767631d0a67  vmovaps [rsp+0x10], xmm2
00007767631d0a6d  vmovaps [rsp+0x20], xmm3
00007767631d0a73  vmovaps [rsp+0x30], xmm4
00007767631d0a79  vmovaps [rsp+0x40], xmm5
00007767631d0a7f  vmovaps [rsp+0x50], xmm6
00007767631d0a85  vmovaps [rsp+0x60], xmm7
00007767631d0a8b  vmovaps [rsp+0x70], xmm8
00007767631d0a91  vmovaps [rsp+0x80], xmm9
00007767631d0a9a  vmovaps [rsp+0x90], xmm10
00007767631d0aa3  vmovaps [rsp+0xA0], xmm11
00007767631d0aac  vmovaps [rsp+0xB0], xmm12
00007767631d0ab5  vmovaps [rsp+0xC0], xmm13
00007767631d0abe  vmovaps [rsp+0xD0], xmm14
00007767631d0ac7  vmovaps [rsp+0xE0], xmm15
00007767631d0ad0  sub rsp, 0x30
00007767631d0ad4  movaps [rsp], xmm1
00007767631d0ad8  movaps [rsp+0x10], xmm14
00007767631d0ade  movaps [rsp+0x20], xmm10
00007767631d0ae4  lea rdi, [rsp]
00007767631d0ae8  mov esi, 0x00
00007767631d0aed  mov rax, 0x617961CDB530
00007767631d0af7  call rax
00007767631d0af9  movaps xmm1, [rsp]
00007767631d0afd  add rsp, 0x30
00007767631d0b01  vmovaps xmm0, [rsp]
00007767631d0b06  vmovaps xmm2, [rsp+0x10]
00007767631d0b0c  vmovaps xmm3, [rsp+0x20]
00007767631d0b12  vmovaps xmm4, [rsp+0x30]
00007767631d0b18  vmovaps xmm5, [rsp+0x40]
00007767631d0b1e  vmovaps xmm6, [rsp+0x50]
00007767631d0b24  vmovaps xmm7, [rsp+0x60]
00007767631d0b2a  vmovaps xmm8, [rsp+0x70]
00007767631d0b30  vmovaps xmm9, [rsp+0x80]
00007767631d0b39  vmovaps xmm10, [rsp+0x90]
00007767631d0b42  vmovaps xmm11, [rsp+0xA0]
00007767631d0b4b  vmovaps xmm12, [rsp+0xB0]
00007767631d0b54  vmovaps xmm13, [rsp+0xC0]
00007767631d0b5d  vmovaps xmm14, [rsp+0xD0]
00007767631d0b66  vmovaps xmm15, [rsp+0xE0]
00007767631d0b6f  add rsp, 0xF0
00007767631d0b76  pop r11
00007767631d0b78  pop r10
00007767631d0b7a  pop r9
00007767631d0b7c  pop r8
00007767631d0b7e  pop rsi
00007767631d0b7f  pop rdi
00007767631d0b80  pop rdx
00007767631d0b81  pop rcx
00007767631d0b82  pop rax
00007767631d0b83  add rsp, 0x08
00007767631d0b87  jmp 0x00007767631CF631
00007767631d0b8c  sub rsp, 0x08
00007767631d0b90  push rax
00007767631d0b91  push rcx
00007767631d0b92  push rdx
00007767631d0b93  push rdi
00007767631d0b94  push rsi
00007767631d0b95  push r8
00007767631d0b97  push r9
00007767631d0b99  push r10
00007767631d0b9b  push r11
00007767631d0b9d  sub rsp, 0xF0
00007767631d0ba4  vmovaps [rsp], xmm0
00007767631d0ba9  vmovaps [rsp+0x10], xmm1
00007767631d0baf  vmovaps [rsp+0x20], xmm2
00007767631d0bb5  vmovaps [rsp+0x30], xmm3
00007767631d0bbb  vmovaps [rsp+0x40], xmm4
00007767631d0bc1  vmovaps [rsp+0x50], xmm5
00007767631d0bc7  vmovaps [rsp+0x60], xmm6
00007767631d0bcd  vmovaps [rsp+0x70], xmm7
00007767631d0bd3  vmovaps [rsp+0x80], xmm8
00007767631d0bdc  vmovaps [rsp+0x90], xmm9
00007767631d0be5  vmovaps [rsp+0xA0], xmm10
00007767631d0bee  vmovaps [rsp+0xB0], xmm11
00007767631d0bf7  vmovaps [rsp+0xC0], xmm12
00007767631d0c00  vmovaps [rsp+0xD0], xmm14
00007767631d0c09  vmovaps [rsp+0xE0], xmm15
00007767631d0c12  sub rsp, 0x30
00007767631d0c16  movaps [rsp], xmm13
00007767631d0c1b  movaps [rsp+0x10], xmm14
00007767631d0c21  movaps [rsp+0x20], xmm2
00007767631d0c26  lea rdi, [rsp]
00007767631d0c2a  mov esi, 0x00
00007767631d0c2f  mov rax, 0x617961CDB530
00007767631d0c39  call rax
00007767631d0c3b  movaps xmm13, [rsp]
00007767631d0c40  add rsp, 0x30
00007767631d0c44  vmovaps xmm0, [rsp]
00007767631d0c49  vmovaps xmm1, [rsp+0x10]
00007767631d0c4f  vmovaps xmm2, [rsp+0x20]
00007767631d0c55  vmovaps xmm3, [rsp+0x30]
00007767631d0c5b  vmovaps xmm4, [rsp+0x40]
00007767631d0c61  vmovaps xmm5, [rsp+0x50]
00007767631d0c67  vmovaps xmm6, [rsp+0x60]
00007767631d0c6d  vmovaps xmm7, [rsp+0x70]
00007767631d0c73  vmovaps xmm8, [rsp+0x80]
00007767631d0c7c  vmovaps xmm9, [rsp+0x90]
00007767631d0c85  vmovaps xmm10, [rsp+0xA0]
00007767631d0c8e  vmovaps xmm11, [rsp+0xB0]
00007767631d0c97  vmovaps xmm12, [rsp+0xC0]
00007767631d0ca0  vmovaps xmm14, [rsp+0xD0]
00007767631d0ca9  vmovaps xmm15, [rsp+0xE0]
00007767631d0cb2  add rsp, 0xF0
00007767631d0cb9  pop r11
00007767631d0cbb  pop r10
00007767631d0cbd  pop r9
00007767631d0cbf  pop r8
00007767631d0cc1  pop rsi
00007767631d0cc2  pop rdi
00007767631d0cc3  pop rdx
00007767631d0cc4  pop rcx
00007767631d0cc5  pop rax
00007767631d0cc6  add rsp, 0x08
00007767631d0cca  jmp 0x00007767631CF64C
00007767631d0ccf  sub rsp, 0x08
00007767631d0cd3  push rax
00007767631d0cd4  push rcx
00007767631d0cd5  push rdx
00007767631d0cd6  push rdi
00007767631d0cd7  push rsi
00007767631d0cd8  push r8
00007767631d0cda  push r9
00007767631d0cdc  push r10
00007767631d0cde  push r11
00007767631d0ce0  sub rsp, 0xF0
00007767631d0ce7  vmovaps [rsp], xmm0
00007767631d0cec  vmovaps [rsp+0x10], xmm2
00007767631d0cf2  vmovaps [rsp+0x20], xmm3
00007767631d0cf8  vmovaps [rsp+0x30], xmm4
00007767631d0cfe  vmovaps [rsp+0x40], xmm5
00007767631d0d04  vmovaps [rsp+0x50], xmm6
00007767631d0d0a  vmovaps [rsp+0x60], xmm7
00007767631d0d10  vmovaps [rsp+0x70], xmm8
00007767631d0d16  vmovaps [rsp+0x80], xmm9
00007767631d0d1f  vmovaps [rsp+0x90], xmm10
00007767631d0d28  vmovaps [rsp+0xA0], xmm11
00007767631d0d31  vmovaps [rsp+0xB0], xmm12
00007767631d0d3a  vmovaps [rsp+0xC0], xmm13
00007767631d0d43  vmovaps [rsp+0xD0], xmm14
00007767631d0d4c  vmovaps [rsp+0xE0], xmm15
00007767631d0d55  sub rsp, 0x30
00007767631d0d59  movaps [rsp], xmm1
00007767631d0d5d  movaps [rsp+0x10], xmm10
00007767631d0d63  movaps [rsp+0x20], xmm2
00007767631d0d68  lea rdi, [rsp]
00007767631d0d6c  mov esi, 0x00
00007767631d0d71  mov rax, 0x617961CDB530
00007767631d0d7b  call rax
00007767631d0d7d  movaps xmm1, [rsp]
00007767631d0d81  add rsp, 0x30
00007767631d0d85  vmovaps xmm0, [rsp]
00007767631d0d8a  vmovaps xmm2, [rsp+0x10]
00007767631d0d90  vmovaps xmm3, [rsp+0x20]
00007767631d0d96  vmovaps xmm4, [rsp+0x30]
00007767631d0d9c  vmovaps xmm5, [rsp+0x40]
00007767631d0da2  vmovaps xmm6, [rsp+0x50]
00007767631d0da8  vmovaps xmm7, [rsp+0x60]
00007767631d0dae  vmovaps xmm8, [rsp+0x70]
00007767631d0db4  vmovaps xmm9, [rsp+0x80]
00007767631d0dbd  vmovaps xmm10, [rsp+0x90]
00007767631d0dc6  vmovaps xmm11, [rsp+0xA0]
00007767631d0dcf  vmovaps xmm12, [rsp+0xB0]
00007767631d0dd8  vmovaps xmm13, [rsp+0xC0]
00007767631d0de1  vmovaps xmm14, [rsp+0xD0]
00007767631d0dea  vmovaps xmm15, [rsp+0xE0]
00007767631d0df3  add rsp, 0xF0
00007767631d0dfa  pop r11
00007767631d0dfc  pop r10
00007767631d0dfe  pop r9
00007767631d0e00  pop r8
00007767631d0e02  pop rsi
00007767631d0e03  pop rdi
00007767631d0e04  pop rdx
00007767631d0e05  pop rcx
00007767631d0e06  pop rax
00007767631d0e07  add rsp, 0x08
00007767631d0e0b  jmp 0x00007767631CF6B4
00007767631d0e10  sub rsp, 0x08
00007767631d0e14  push rax
00007767631d0e15  push rcx
00007767631d0e16  push rdx
00007767631d0e17  push rdi
00007767631d0e18  push rsi
00007767631d0e19  push r8
00007767631d0e1b  push r9
00007767631d0e1d  push r10
00007767631d0e1f  push r11
00007767631d0e21  sub rsp, 0xF0
00007767631d0e28  vmovaps [rsp], xmm0
00007767631d0e2d  vmovaps [rsp+0x10], xmm1
00007767631d0e33  vmovaps [rsp+0x20], xmm2
00007767631d0e39  vmovaps [rsp+0x30], xmm3
00007767631d0e3f  vmovaps [rsp+0x40], xmm4
00007767631d0e45  vmovaps [rsp+0x50], xmm5
00007767631d0e4b  vmovaps [rsp+0x60], xmm6
00007767631d0e51  vmovaps [rsp+0x70], xmm7
00007767631d0e57  vmovaps [rsp+0x80], xmm8
00007767631d0e60  vmovaps [rsp+0x90], xmm9
00007767631d0e69  vmovaps [rsp+0xA0], xmm10
00007767631d0e72  vmovaps [rsp+0xB0], xmm11
00007767631d0e7b  vmovaps [rsp+0xC0], xmm12
00007767631d0e84  vmovaps [rsp+0xD0], xmm13
00007767631d0e8d  vmovaps [rsp+0xE0], xmm14
00007767631d0e96  sub rsp, 0x30
00007767631d0e9a  movaps [rsp], xmm15
00007767631d0e9f  movaps [rsp+0x10], xmm10
00007767631d0ea5  movaps [rsp+0x20], xmm2
00007767631d0eaa  lea rdi, [rsp]
00007767631d0eae  mov esi, 0x00
00007767631d0eb3  mov rax, 0x617961CDB530
00007767631d0ebd  call rax
00007767631d0ebf  movaps xmm15, [rsp]
00007767631d0ec4  add rsp, 0x30
00007767631d0ec8  vmovaps xmm0, [rsp]
00007767631d0ecd  vmovaps xmm1, [rsp+0x10]
00007767631d0ed3  vmovaps xmm2, [rsp+0x20]
00007767631d0ed9  vmovaps xmm3, [rsp+0x30]
00007767631d0edf  vmovaps xmm4, [rsp+0x40]
00007767631d0ee5  vmovaps xmm5, [rsp+0x50]
00007767631d0eeb  vmovaps xmm6, [rsp+0x60]
00007767631d0ef1  vmovaps xmm7, [rsp+0x70]
00007767631d0ef7  vmovaps xmm8, [rsp+0x80]
00007767631d0f00  vmovaps xmm9, [rsp+0x90]
00007767631d0f09  vmovaps xmm10, [rsp+0xA0]
00007767631d0f12  vmovaps xmm11, [rsp+0xB0]
00007767631d0f1b  vmovaps xmm12, [rsp+0xC0]
00007767631d0f24  vmovaps xmm13, [rsp+0xD0]
00007767631d0f2d  vmovaps xmm14, [rsp+0xE0]
00007767631d0f36  add rsp, 0xF0
00007767631d0f3d  pop r11
00007767631d0f3f  pop r10
00007767631d0f41  pop r9
00007767631d0f43  pop r8
00007767631d0f45  pop rsi
00007767631d0f46  pop rdi
00007767631d0f47  pop rdx
00007767631d0f48  pop rcx
00007767631d0f49  pop rax
00007767631d0f4a  add rsp, 0x08
00007767631d0f4e  jmp 0x00007767631CF706
00007767631d0f53  sub rsp, 0x08
00007767631d0f57  push rax
00007767631d0f58  push rcx
00007767631d0f59  push rdx
00007767631d0f5a  push rdi
00007767631d0f5b  push rsi
00007767631d0f5c  push r8
00007767631d0f5e  push r9
00007767631d0f60  push r10
00007767631d0f62  push r11
00007767631d0f64  sub rsp, 0xF0
00007767631d0f6b  vmovaps [rsp], xmm0
00007767631d0f70  vmovaps [rsp+0x10], xmm2
00007767631d0f76  vmovaps [rsp+0x20], xmm3
00007767631d0f7c  vmovaps [rsp+0x30], xmm4
00007767631d0f82  vmovaps [rsp+0x40], xmm5
00007767631d0f88  vmovaps [rsp+0x50], xmm6
00007767631d0f8e  vmovaps [rsp+0x60], xmm7
00007767631d0f94  vmovaps [rsp+0x70], xmm8
00007767631d0f9a  vmovaps [rsp+0x80], xmm9
00007767631d0fa3  vmovaps [rsp+0x90], xmm10
00007767631d0fac  vmovaps [rsp+0xA0], xmm11
00007767631d0fb5  vmovaps [rsp+0xB0], xmm12
00007767631d0fbe  vmovaps [rsp+0xC0], xmm13
00007767631d0fc7  vmovaps [rsp+0xD0], xmm14
00007767631d0fd0  vmovaps [rsp+0xE0], xmm15
00007767631d0fd9  sub rsp, 0x30
00007767631d0fdd  movaps [rsp], xmm1
00007767631d0fe1  movaps [rsp+0x10], xmm10
00007767631d0fe7  movaps [rsp+0x20], xmm12
00007767631d0fed  lea rdi, [rsp]
00007767631d0ff1  mov esi, 0x00
00007767631d0ff6  mov rax, 0x617961CDB530
00007767631d1000  call rax
00007767631d1002  movaps xmm1, [rsp]
00007767631d1006  add rsp, 0x30
00007767631d100a  vmovaps xmm0, [rsp]
00007767631d100f  vmovaps xmm2, [rsp+0x10]
00007767631d1015  vmovaps xmm3, [rsp+0x20]
00007767631d101b  vmovaps xmm4, [rsp+0x30]
00007767631d1021  vmovaps xmm5, [rsp+0x40]
00007767631d1027  vmovaps xmm6, [rsp+0x50]
00007767631d102d  vmovaps xmm7, [rsp+0x60]
00007767631d1033  vmovaps xmm8, [rsp+0x70]
00007767631d1039  vmovaps xmm9, [rsp+0x80]
00007767631d1042  vmovaps xmm10, [rsp+0x90]
00007767631d104b  vmovaps xmm11, [rsp+0xA0]
00007767631d1054  vmovaps xmm12, [rsp+0xB0]
00007767631d105d  vmovaps xmm13, [rsp+0xC0]
00007767631d1066  vmovaps xmm14, [rsp+0xD0]
00007767631d106f  vmovaps xmm15, [rsp+0xE0]
00007767631d1078  add rsp, 0xF0
00007767631d107f  pop r11
00007767631d1081  pop r10
00007767631d1083  pop r9
00007767631d1085  pop r8
00007767631d1087  pop rsi
00007767631d1088  pop rdi
00007767631d1089  pop rdx
00007767631d108a  pop rcx
00007767631d108b  pop rax
00007767631d108c  add rsp, 0x08
00007767631d1090  jmp 0x00007767631CF732
00007767631d1095  sub rsp, 0x08
00007767631d1099  push rax
00007767631d109a  push rcx
00007767631d109b  push rdx
00007767631d109c  push rdi
00007767631d109d  push rsi
00007767631d109e  push r8
00007767631d10a0  push r9
00007767631d10a2  push r10
00007767631d10a4  push r11
00007767631d10a6  sub rsp, 0xF0
00007767631d10ad  vmovaps [rsp], xmm0
00007767631d10b2  vmovaps [rsp+0x10], xmm1
00007767631d10b8  vmovaps [rsp+0x20], xmm2
00007767631d10be  vmovaps [rsp+0x30], xmm3
00007767631d10c4  vmovaps [rsp+0x40], xmm4
00007767631d10ca  vmovaps [rsp+0x50], xmm5
00007767631d10d0  vmovaps [rsp+0x60], xmm6
00007767631d10d6  vmovaps [rsp+0x70], xmm7
00007767631d10dc  vmovaps [rsp+0x80], xmm8
00007767631d10e5  vmovaps [rsp+0x90], xmm9
00007767631d10ee  vmovaps [rsp+0xA0], xmm10
00007767631d10f7  vmovaps [rsp+0xB0], xmm11
00007767631d1100  vmovaps [rsp+0xC0], xmm12
00007767631d1109  vmovaps [rsp+0xD0], xmm13
00007767631d1112  vmovaps [rsp+0xE0], xmm14
00007767631d111b  sub rsp, 0x30
00007767631d111f  movaps [rsp], xmm15
00007767631d1124  movaps [rsp+0x10], xmm10
00007767631d112a  movaps [rsp+0x20], xmm12
00007767631d1130  lea rdi, [rsp]
00007767631d1134  mov esi, 0x00
00007767631d1139  mov rax, 0x617961CDB530
00007767631d1143  call rax
00007767631d1145  movaps xmm15, [rsp]
00007767631d114a  add rsp, 0x30
00007767631d114e  vmovaps xmm0, [rsp]
00007767631d1153  vmovaps xmm1, [rsp+0x10]
00007767631d1159  vmovaps xmm2, [rsp+0x20]
00007767631d115f  vmovaps xmm3, [rsp+0x30]
00007767631d1165  vmovaps xmm4, [rsp+0x40]
00007767631d116b  vmovaps xmm5, [rsp+0x50]
00007767631d1171  vmovaps xmm6, [rsp+0x60]
00007767631d1177  vmovaps xmm7, [rsp+0x70]
00007767631d117d  vmovaps xmm8, [rsp+0x80]
00007767631d1186  vmovaps xmm9, [rsp+0x90]
00007767631d118f  vmovaps xmm10, [rsp+0xA0]
00007767631d1198  vmovaps xmm11, [rsp+0xB0]
00007767631d11a1  vmovaps xmm12, [rsp+0xC0]
00007767631d11aa  vmovaps xmm13, [rsp+0xD0]
00007767631d11b3  vmovaps xmm14, [rsp+0xE0]
00007767631d11bc  add rsp, 0xF0
00007767631d11c3  pop r11
00007767631d11c5  pop r10
00007767631d11c7  pop r9
00007767631d11c9  pop r8
00007767631d11cb  pop rsi
00007767631d11cc  pop rdi
00007767631d11cd  pop rdx
00007767631d11ce  pop rcx
00007767631d11cf  pop rax
00007767631d11d0  add rsp, 0x08
00007767631d11d4  jmp 0x00007767631CF75E
00007767631d11d9  call 0x0000776762FFF430
00007767631d11de  jmp 0x00007767631CF7EE
00007767631d11e3  call 0x0000776762FFF430
00007767631d11e8  jmp 0x00007767631CF801
00007767631d11ed  sub rsp, 0x08
00007767631d11f1  push rax
00007767631d11f2  push rcx
00007767631d11f3  push rdx
00007767631d11f4  push rdi
00007767631d11f5  push rsi
00007767631d11f6  push r8
00007767631d11f8  push r9
00007767631d11fa  push r10
00007767631d11fc  push r11
00007767631d11fe  sub rsp, 0xF0
00007767631d1205  vmovaps [rsp], xmm0
00007767631d120a  vmovaps [rsp+0x10], xmm2
00007767631d1210  vmovaps [rsp+0x20], xmm3
00007767631d1216  vmovaps [rsp+0x30], xmm4
00007767631d121c  vmovaps [rsp+0x40], xmm5
00007767631d1222  vmovaps [rsp+0x50], xmm6
00007767631d1228  vmovaps [rsp+0x60], xmm7
00007767631d122e  vmovaps [rsp+0x70], xmm8
00007767631d1234  vmovaps [rsp+0x80], xmm9
00007767631d123d  vmovaps [rsp+0x90], xmm10
00007767631d1246  vmovaps [rsp+0xA0], xmm11
00007767631d124f  vmovaps [rsp+0xB0], xmm12
00007767631d1258  vmovaps [rsp+0xC0], xmm13
00007767631d1261  vmovaps [rsp+0xD0], xmm14
00007767631d126a  vmovaps [rsp+0xE0], xmm15
00007767631d1273  sub rsp, 0x30
00007767631d1277  movaps [rsp], xmm1
00007767631d127b  movaps [rsp+0x10], xmm13
00007767631d1281  movaps [rsp+0x20], xmm2
00007767631d1286  lea rdi, [rsp]
00007767631d128a  mov esi, 0x00
00007767631d128f  mov rax, 0x617961CDB530
00007767631d1299  call rax
00007767631d129b  movaps xmm1, [rsp]
00007767631d129f  add rsp, 0x30
00007767631d12a3  vmovaps xmm0, [rsp]
00007767631d12a8  vmovaps xmm2, [rsp+0x10]
00007767631d12ae  vmovaps xmm3, [rsp+0x20]
00007767631d12b4  vmovaps xmm4, [rsp+0x30]
00007767631d12ba  vmovaps xmm5, [rsp+0x40]
00007767631d12c0  vmovaps xmm6, [rsp+0x50]
00007767631d12c6  vmovaps xmm7, [rsp+0x60]
00007767631d12cc  vmovaps xmm8, [rsp+0x70]
00007767631d12d2  vmovaps xmm9, [rsp+0x80]
00007767631d12db  vmovaps xmm10, [rsp+0x90]
00007767631d12e4  vmovaps xmm11, [rsp+0xA0]
00007767631d12ed  vmovaps xmm12, [rsp+0xB0]
00007767631d12f6  vmovaps xmm13, [rsp+0xC0]
00007767631d12ff  vmovaps xmm14, [rsp+0xD0]
00007767631d1308  vmovaps xmm15, [rsp+0xE0]
00007767631d1311  add rsp, 0xF0
00007767631d1318  pop r11
00007767631d131a  pop r10
00007767631d131c  pop r9
00007767631d131e  pop r8
00007767631d1320  pop rsi
00007767631d1321  pop rdi
00007767631d1322  pop rdx
00007767631d1323  pop rcx
00007767631d1324  pop rax
00007767631d1325  add rsp, 0x08
00007767631d1329  jmp 0x00007767631CF82C
00007767631d132e  call 0x000077676300E760
00007767631d1333  jmp 0x00007767631CF839
00007767631d1338  sub rsp, 0x08
00007767631d133c  push rax
00007767631d133d  push rcx
00007767631d133e  push rdx
00007767631d133f  push rdi
00007767631d1340  push rsi
00007767631d1341  push r8
00007767631d1343  push r9
00007767631d1345  push r10
00007767631d1347  push r11
00007767631d1349  sub rsp, 0xF0
00007767631d1350  vmovaps [rsp], xmm0
00007767631d1355  vmovaps [rsp+0x10], xmm1
00007767631d135b  vmovaps [rsp+0x20], xmm2
00007767631d1361  vmovaps [rsp+0x30], xmm3
00007767631d1367  vmovaps [rsp+0x40], xmm4
00007767631d136d  vmovaps [rsp+0x50], xmm5
00007767631d1373  vmovaps [rsp+0x60], xmm6
00007767631d1379  vmovaps [rsp+0x70], xmm7
00007767631d137f  vmovaps [rsp+0x80], xmm8
00007767631d1388  vmovaps [rsp+0x90], xmm9
00007767631d1391  vmovaps [rsp+0xA0], xmm10
00007767631d139a  vmovaps [rsp+0xB0], xmm11
00007767631d13a3  vmovaps [rsp+0xC0], xmm12
00007767631d13ac  vmovaps [rsp+0xD0], xmm14
00007767631d13b5  vmovaps [rsp+0xE0], xmm15
00007767631d13be  sub rsp, 0x30
00007767631d13c2  movaps [rsp], xmm13
00007767631d13c7  movaps [rsp+0x10], xmm2
00007767631d13cc  movaps [rsp+0x20], xmm1
00007767631d13d1  lea rdi, [rsp]
00007767631d13d5  mov esi, 0x00
00007767631d13da  mov rax, 0x617961CDB530
00007767631d13e4  call rax
00007767631d13e6  movaps xmm13, [rsp]
00007767631d13eb  add rsp, 0x30
00007767631d13ef  vmovaps xmm0, [rsp]
00007767631d13f4  vmovaps xmm1, [rsp+0x10]
00007767631d13fa  vmovaps xmm2, [rsp+0x20]
00007767631d1400  vmovaps xmm3, [rsp+0x30]
00007767631d1406  vmovaps xmm4, [rsp+0x40]
00007767631d140c  vmovaps xmm5, [rsp+0x50]
00007767631d1412  vmovaps xmm6, [rsp+0x60]
00007767631d1418  vmovaps xmm7, [rsp+0x70]
00007767631d141e  vmovaps xmm8, [rsp+0x80]
00007767631d1427  vmovaps xmm9, [rsp+0x90]
00007767631d1430  vmovaps xmm10, [rsp+0xA0]
00007767631d1439  vmovaps xmm11, [rsp+0xB0]
00007767631d1442  vmovaps xmm12, [rsp+0xC0]
00007767631d144b  vmovaps xmm14, [rsp+0xD0]
00007767631d1454  vmovaps xmm15, [rsp+0xE0]
00007767631d145d  add rsp, 0xF0
00007767631d1464  pop r11
00007767631d1466  pop r10
00007767631d1468  pop r9
00007767631d146a  pop r8
00007767631d146c  pop rsi
00007767631d146d  pop rdi
00007767631d146e  pop rdx
00007767631d146f  pop rcx
00007767631d1470  pop rax
00007767631d1471  add rsp, 0x08
00007767631d1475  jmp 0x00007767631CF878
00007767631d147a  sub rsp, 0x08
00007767631d147e  push rax
00007767631d147f  push rcx
00007767631d1480  push rdx
00007767631d1481  push rdi
00007767631d1482  push rsi
00007767631d1483  push r8
00007767631d1485  push r9
00007767631d1487  push r10
00007767631d1489  push r11
00007767631d148b  sub rsp, 0xF0
00007767631d1492  vmovaps [rsp], xmm0
00007767631d1497  vmovaps [rsp+0x10], xmm2
00007767631d149d  vmovaps [rsp+0x20], xmm3
00007767631d14a3  vmovaps [rsp+0x30], xmm4
00007767631d14a9  vmovaps [rsp+0x40], xmm5
00007767631d14af  vmovaps [rsp+0x50], xmm6
00007767631d14b5  vmovaps [rsp+0x60], xmm7
00007767631d14bb  vmovaps [rsp+0x70], xmm8
00007767631d14c1  vmovaps [rsp+0x80], xmm9
00007767631d14ca  vmovaps [rsp+0x90], xmm10
00007767631d14d3  vmovaps [rsp+0xA0], xmm11
00007767631d14dc  vmovaps [rsp+0xB0], xmm12
00007767631d14e5  vmovaps [rsp+0xC0], xmm13
00007767631d14ee  vmovaps [rsp+0xD0], xmm14
00007767631d14f7  vmovaps [rsp+0xE0], xmm15
00007767631d1500  sub rsp, 0x30
00007767631d1504  movaps [rsp], xmm1
00007767631d1508  movaps [rsp+0x10], xmm15
00007767631d150e  movaps [rsp+0x20], xmm2
00007767631d1513  lea rdi, [rsp]
00007767631d1517  mov esi, 0x00
00007767631d151c  mov rax, 0x617961CDB530
00007767631d1526  call rax
00007767631d1528  movaps xmm1, [rsp]
00007767631d152c  add rsp, 0x30
00007767631d1530  vmovaps xmm0, [rsp]
00007767631d1535  vmovaps xmm2, [rsp+0x10]
00007767631d153b  vmovaps xmm3, [rsp+0x20]
00007767631d1541  vmovaps xmm4, [rsp+0x30]
00007767631d1547  vmovaps xmm5, [rsp+0x40]
00007767631d154d  vmovaps xmm6, [rsp+0x50]
00007767631d1553  vmovaps xmm7, [rsp+0x60]
00007767631d1559  vmovaps xmm8, [rsp+0x70]
00007767631d155f  vmovaps xmm9, [rsp+0x80]
00007767631d1568  vmovaps xmm10, [rsp+0x90]
00007767631d1571  vmovaps xmm11, [rsp+0xA0]
00007767631d157a  vmovaps xmm12, [rsp+0xB0]
00007767631d1583  vmovaps xmm13, [rsp+0xC0]
00007767631d158c  vmovaps xmm14, [rsp+0xD0]
00007767631d1595  vmovaps xmm15, [rsp+0xE0]
00007767631d159e  add rsp, 0xF0
00007767631d15a5  pop r11
00007767631d15a7  pop r10
00007767631d15a9  pop r9
00007767631d15ab  pop r8
00007767631d15ad  pop rsi
00007767631d15ae  pop rdi
00007767631d15af  pop rdx
00007767631d15b0  pop rcx
00007767631d15b1  pop rax
00007767631d15b2  add rsp, 0x08
00007767631d15b6  jmp 0x00007767631CF8AC
00007767631d15bb  sub rsp, 0x08
00007767631d15bf  push rax
00007767631d15c0  push rcx
00007767631d15c1  push rdx
00007767631d15c2  push rdi
00007767631d15c3  push rsi
00007767631d15c4  push r8
00007767631d15c6  push r9
00007767631d15c8  push r10
00007767631d15ca  push r11
00007767631d15cc  sub rsp, 0xF0
00007767631d15d3  vmovaps [rsp], xmm0
00007767631d15d8  vmovaps [rsp+0x10], xmm1
00007767631d15de  vmovaps [rsp+0x20], xmm2
00007767631d15e4  vmovaps [rsp+0x30], xmm3
00007767631d15ea  vmovaps [rsp+0x40], xmm4
00007767631d15f0  vmovaps [rsp+0x50], xmm5
00007767631d15f6  vmovaps [rsp+0x60], xmm6
00007767631d15fc  vmovaps [rsp+0x70], xmm7
00007767631d1602  vmovaps [rsp+0x80], xmm8
00007767631d160b  vmovaps [rsp+0x90], xmm9
00007767631d1614  vmovaps [rsp+0xA0], xmm10
00007767631d161d  vmovaps [rsp+0xB0], xmm11
00007767631d1626  vmovaps [rsp+0xC0], xmm12
00007767631d162f  vmovaps [rsp+0xD0], xmm13
00007767631d1638  vmovaps [rsp+0xE0], xmm15
00007767631d1641  sub rsp, 0x30
00007767631d1645  movaps [rsp], xmm14
00007767631d164a  movaps [rsp+0x10], xmm2
00007767631d164f  movaps [rsp+0x20], xmm15
00007767631d1655  lea rdi, [rsp]
00007767631d1659  mov esi, 0x00
00007767631d165e  mov rax, 0x617961CDB530
00007767631d1668  call rax
00007767631d166a  movaps xmm14, [rsp]
00007767631d166f  add rsp, 0x30
00007767631d1673  vmovaps xmm0, [rsp]
00007767631d1678  vmovaps xmm1, [rsp+0x10]
00007767631d167e  vmovaps xmm2, [rsp+0x20]
00007767631d1684  vmovaps xmm3, [rsp+0x30]
00007767631d168a  vmovaps xmm4, [rsp+0x40]
00007767631d1690  vmovaps xmm5, [rsp+0x50]
00007767631d1696  vmovaps xmm6, [rsp+0x60]
00007767631d169c  vmovaps xmm7, [rsp+0x70]
00007767631d16a2  vmovaps xmm8, [rsp+0x80]
00007767631d16ab  vmovaps xmm9, [rsp+0x90]
00007767631d16b4  vmovaps xmm10, [rsp+0xA0]
00007767631d16bd  vmovaps xmm11, [rsp+0xB0]
00007767631d16c6  vmovaps xmm12, [rsp+0xC0]
00007767631d16cf  vmovaps xmm13, [rsp+0xD0]
00007767631d16d8  vmovaps xmm15, [rsp+0xE0]
00007767631d16e1  add rsp, 0xF0
00007767631d16e8  pop r11
00007767631d16ea  pop r10
00007767631d16ec  pop r9
00007767631d16ee  pop r8
00007767631d16f0  pop rsi
00007767631d16f1  pop rdi
00007767631d16f2  pop rdx
00007767631d16f3  pop rcx
00007767631d16f4  pop rax
00007767631d16f5  add rsp, 0x08
00007767631d16f9  jmp 0x00007767631CF8E7
00007767631d16fe  sub rsp, 0x08
00007767631d1702  push rax
00007767631d1703  push rcx
00007767631d1704  push rdx
00007767631d1705  push rdi
00007767631d1706  push rsi
00007767631d1707  push r8
00007767631d1709  push r9
00007767631d170b  push r10
00007767631d170d  push r11
00007767631d170f  sub rsp, 0xF0
00007767631d1716  vmovaps [rsp], xmm0
00007767631d171b  vmovaps [rsp+0x10], xmm1
00007767631d1721  vmovaps [rsp+0x20], xmm2
00007767631d1727  vmovaps [rsp+0x30], xmm3
00007767631d172d  vmovaps [rsp+0x40], xmm4
00007767631d1733  vmovaps [rsp+0x50], xmm5
00007767631d1739  vmovaps [rsp+0x60], xmm6
00007767631d173f  vmovaps [rsp+0x70], xmm7
00007767631d1745  vmovaps [rsp+0x80], xmm8
00007767631d174e  vmovaps [rsp+0x90], xmm9
00007767631d1757  vmovaps [rsp+0xA0], xmm10
00007767631d1760  vmovaps [rsp+0xB0], xmm11
00007767631d1769  vmovaps [rsp+0xC0], xmm12
00007767631d1772  vmovaps [rsp+0xD0], xmm13
00007767631d177b  vmovaps [rsp+0xE0], xmm14
00007767631d1784  sub rsp, 0x30
00007767631d1788  movaps [rsp], xmm15
00007767631d178d  movaps [rsp+0x10], xmm2
00007767631d1792  movaps [rsp+0x20], xmm1
00007767631d1797  lea rdi, [rsp]
00007767631d179b  mov esi, 0x00
00007767631d17a0  mov rax, 0x617961CDB530
00007767631d17aa  call rax
00007767631d17ac  movaps xmm15, [rsp]
00007767631d17b1  add rsp, 0x30
00007767631d17b5  vmovaps xmm0, [rsp]
00007767631d17ba  vmovaps xmm1, [rsp+0x10]
00007767631d17c0  vmovaps xmm2, [rsp+0x20]
00007767631d17c6  vmovaps xmm3, [rsp+0x30]
00007767631d17cc  vmovaps xmm4, [rsp+0x40]
00007767631d17d2  vmovaps xmm5, [rsp+0x50]
00007767631d17d8  vmovaps xmm6, [rsp+0x60]
00007767631d17de  vmovaps xmm7, [rsp+0x70]
00007767631d17e4  vmovaps xmm8, [rsp+0x80]
00007767631d17ed  vmovaps xmm9, [rsp+0x90]
00007767631d17f6  vmovaps xmm10, [rsp+0xA0]
00007767631d17ff  vmovaps xmm11, [rsp+0xB0]
00007767631d1808  vmovaps xmm12, [rsp+0xC0]
00007767631d1811  vmovaps xmm13, [rsp+0xD0]
00007767631d181a  vmovaps xmm14, [rsp+0xE0]
00007767631d1823  add rsp, 0xF0
00007767631d182a  pop r11
00007767631d182c  pop r10
00007767631d182e  pop r9
00007767631d1830  pop r8
00007767631d1832  pop rsi
00007767631d1833  pop rdi
00007767631d1834  pop rdx
00007767631d1835  pop rcx
00007767631d1836  pop rax
00007767631d1837  add rsp, 0x08
00007767631d183b  jmp 0x00007767631CF923
00007767631d1840  call 0x0000776762FFF430
00007767631d1845  jmp 0x00007767631CF930
00007767631d184a  sub rsp, 0x08
00007767631d184e  push rax
00007767631d184f  push rcx
00007767631d1850  push rdx
00007767631d1851  push rdi
00007767631d1852  push rsi
00007767631d1853  push r8
00007767631d1855  push r9
00007767631d1857  push r10
00007767631d1859  push r11
00007767631d185b  sub rsp, 0xF0
00007767631d1862  vmovaps [rsp], xmm0
00007767631d1867  vmovaps [rsp+0x10], xmm1
00007767631d186d  vmovaps [rsp+0x20], xmm3
00007767631d1873  vmovaps [rsp+0x30], xmm4
00007767631d1879  vmovaps [rsp+0x40], xmm5
00007767631d187f  vmovaps [rsp+0x50], xmm6
00007767631d1885  vmovaps [rsp+0x60], xmm7
00007767631d188b  vmovaps [rsp+0x70], xmm8
00007767631d1891  vmovaps [rsp+0x80], xmm9
00007767631d189a  vmovaps [rsp+0x90], xmm10
00007767631d18a3  vmovaps [rsp+0xA0], xmm11
00007767631d18ac  vmovaps [rsp+0xB0], xmm12
00007767631d18b5  vmovaps [rsp+0xC0], xmm13
00007767631d18be  vmovaps [rsp+0xD0], xmm14
00007767631d18c7  vmovaps [rsp+0xE0], xmm15
00007767631d18d0  sub rsp, 0x30
00007767631d18d4  movaps [rsp], xmm2
00007767631d18d8  movaps [rsp+0x10], xmm1
00007767631d18dd  movaps [rsp+0x20], xmm14
00007767631d18e3  lea rdi, [rsp]
00007767631d18e7  mov esi, 0x00
00007767631d18ec  mov rax, 0x617961CDB530
00007767631d18f6  call rax
00007767631d18f8  movaps xmm2, [rsp]
00007767631d18fc  add rsp, 0x30
00007767631d1900  vmovaps xmm0, [rsp]
00007767631d1905  vmovaps xmm1, [rsp+0x10]
00007767631d190b  vmovaps xmm3, [rsp+0x20]
00007767631d1911  vmovaps xmm4, [rsp+0x30]
00007767631d1917  vmovaps xmm5, [rsp+0x40]
00007767631d191d  vmovaps xmm6, [rsp+0x50]
00007767631d1923  vmovaps xmm7, [rsp+0x60]
00007767631d1929  vmovaps xmm8, [rsp+0x70]
00007767631d192f  vmovaps xmm9, [rsp+0x80]
00007767631d1938  vmovaps xmm10, [rsp+0x90]
00007767631d1941  vmovaps xmm11, [rsp+0xA0]
00007767631d194a  vmovaps xmm12, [rsp+0xB0]
00007767631d1953  vmovaps xmm13, [rsp+0xC0]
00007767631d195c  vmovaps xmm14, [rsp+0xD0]
00007767631d1965  vmovaps xmm15, [rsp+0xE0]
00007767631d196e  add rsp, 0xF0
00007767631d1975  pop r11
00007767631d1977  pop r10
00007767631d1979  pop r9
00007767631d197b  pop r8
00007767631d197d  pop rsi
00007767631d197e  pop rdi
00007767631d197f  pop rdx
00007767631d1980  pop rcx
00007767631d1981  pop rax
00007767631d1982  add rsp, 0x08
00007767631d1986  jmp 0x00007767631CF96D
00007767631d198b  sub rsp, 0x08
00007767631d198f  push rax
00007767631d1990  push rcx
00007767631d1991  push rdx
00007767631d1992  push rdi
00007767631d1993  push rsi
00007767631d1994  push r8
00007767631d1996  push r9
00007767631d1998  push r10
00007767631d199a  push r11
00007767631d199c  sub rsp, 0xF0
00007767631d19a3  vmovaps [rsp], xmm0
00007767631d19a8  vmovaps [rsp+0x10], xmm1
00007767631d19ae  vmovaps [rsp+0x20], xmm2
00007767631d19b4  vmovaps [rsp+0x30], xmm3
00007767631d19ba  vmovaps [rsp+0x40], xmm4
00007767631d19c0  vmovaps [rsp+0x50], xmm5
00007767631d19c6  vmovaps [rsp+0x60], xmm6
00007767631d19cc  vmovaps [rsp+0x70], xmm7
00007767631d19d2  vmovaps [rsp+0x80], xmm8
00007767631d19db  vmovaps [rsp+0x90], xmm9
00007767631d19e4  vmovaps [rsp+0xA0], xmm10
00007767631d19ed  vmovaps [rsp+0xB0], xmm11
00007767631d19f6  vmovaps [rsp+0xC0], xmm12
00007767631d19ff  vmovaps [rsp+0xD0], xmm13
00007767631d1a08  vmovaps [rsp+0xE0], xmm14
00007767631d1a11  sub rsp, 0x30
00007767631d1a15  movaps [rsp], xmm15
00007767631d1a1a  movaps [rsp+0x10], xmm14
00007767631d1a20  movaps [rsp+0x20], xmm1
00007767631d1a25  lea rdi, [rsp]
00007767631d1a29  mov esi, 0x00
00007767631d1a2e  mov rax, 0x617961CDB530
00007767631d1a38  call rax
00007767631d1a3a  movaps xmm15, [rsp]
00007767631d1a3f  add rsp, 0x30
00007767631d1a43  vmovaps xmm0, [rsp]
00007767631d1a48  vmovaps xmm1, [rsp+0x10]
00007767631d1a4e  vmovaps xmm2, [rsp+0x20]
00007767631d1a54  vmovaps xmm3, [rsp+0x30]
00007767631d1a5a  vmovaps xmm4, [rsp+0x40]
00007767631d1a60  vmovaps xmm5, [rsp+0x50]
00007767631d1a66  vmovaps xmm6, [rsp+0x60]
00007767631d1a6c  vmovaps xmm7, [rsp+0x70]
00007767631d1a72  vmovaps xmm8, [rsp+0x80]
00007767631d1a7b  vmovaps xmm9, [rsp+0x90]
00007767631d1a84  vmovaps xmm10, [rsp+0xA0]
00007767631d1a8d  vmovaps xmm11, [rsp+0xB0]
00007767631d1a96  vmovaps xmm12, [rsp+0xC0]
00007767631d1a9f  vmovaps xmm13, [rsp+0xD0]
00007767631d1aa8  vmovaps xmm14, [rsp+0xE0]
00007767631d1ab1  add rsp, 0xF0
00007767631d1ab8  pop r11
00007767631d1aba  pop r10
00007767631d1abc  pop r9
00007767631d1abe  pop r8
00007767631d1ac0  pop rsi
00007767631d1ac1  pop rdi
00007767631d1ac2  pop rdx
00007767631d1ac3  pop rcx
00007767631d1ac4  pop rax
00007767631d1ac5  add rsp, 0x08
00007767631d1ac9  jmp 0x00007767631CF9E7
00007767631d1ace  call 0x0000776762FFF430
00007767631d1ad3  jmp 0x00007767631CF9F4
00007767631d1ad8  sub rsp, 0x08
00007767631d1adc  push rax
00007767631d1add  push rcx
00007767631d1ade  push rdx
00007767631d1adf  push rdi
00007767631d1ae0  push rsi
00007767631d1ae1  push r8
00007767631d1ae3  push r9
00007767631d1ae5  push r10
00007767631d1ae7  push r11
00007767631d1ae9  sub rsp, 0xF0
00007767631d1af0  vmovaps [rsp], xmm0
00007767631d1af5  vmovaps [rsp+0x10], xmm1
00007767631d1afb  vmovaps [rsp+0x20], xmm2
00007767631d1b01  vmovaps [rsp+0x30], xmm3
00007767631d1b07  vmovaps [rsp+0x40], xmm4
00007767631d1b0d  vmovaps [rsp+0x50], xmm5
00007767631d1b13  vmovaps [rsp+0x60], xmm6
00007767631d1b19  vmovaps [rsp+0x70], xmm7
00007767631d1b1f  vmovaps [rsp+0x80], xmm8
00007767631d1b28  vmovaps [rsp+0x90], xmm9
00007767631d1b31  vmovaps [rsp+0xA0], xmm10
00007767631d1b3a  vmovaps [rsp+0xB0], xmm11
00007767631d1b43  vmovaps [rsp+0xC0], xmm12
00007767631d1b4c  vmovaps [rsp+0xD0], xmm13
00007767631d1b55  vmovaps [rsp+0xE0], xmm15
00007767631d1b5e  sub rsp, 0x30
00007767631d1b62  movaps [rsp], xmm14
00007767631d1b67  movaps [rsp+0x10], xmm13
00007767631d1b6d  movaps [rsp+0x20], xmm1
00007767631d1b72  lea rdi, [rsp]
00007767631d1b76  mov esi, 0x00
00007767631d1b7b  mov rax, 0x617961CDB530
00007767631d1b85  call rax
00007767631d1b87  movaps xmm14, [rsp]
00007767631d1b8c  add rsp, 0x30
00007767631d1b90  vmovaps xmm0, [rsp]
00007767631d1b95  vmovaps xmm1, [rsp+0x10]
00007767631d1b9b  vmovaps xmm2, [rsp+0x20]
00007767631d1ba1  vmovaps xmm3, [rsp+0x30]
00007767631d1ba7  vmovaps xmm4, [rsp+0x40]
00007767631d1bad  vmovaps xmm5, [rsp+0x50]
00007767631d1bb3  vmovaps xmm6, [rsp+0x60]
00007767631d1bb9  vmovaps xmm7, [rsp+0x70]
00007767631d1bbf  vmovaps xmm8, [rsp+0x80]
00007767631d1bc8  vmovaps xmm9, [rsp+0x90]
00007767631d1bd1  vmovaps xmm10, [rsp+0xA0]
00007767631d1bda  vmovaps xmm11, [rsp+0xB0]
00007767631d1be3  vmovaps xmm12, [rsp+0xC0]
00007767631d1bec  vmovaps xmm13, [rsp+0xD0]
00007767631d1bf5  vmovaps xmm15, [rsp+0xE0]
00007767631d1bfe  add rsp, 0xF0
00007767631d1c05  pop r11
00007767631d1c07  pop r10
00007767631d1c09  pop r9
00007767631d1c0b  pop r8
00007767631d1c0d  pop rsi
00007767631d1c0e  pop rdi
00007767631d1c0f  pop rdx
00007767631d1c10  pop rcx
00007767631d1c11  pop rax
00007767631d1c12  add rsp, 0x08
00007767631d1c16  jmp 0x00007767631CFAAF
00007767631d1c1b  sub rsp, 0x08
00007767631d1c1f  push rax
00007767631d1c20  push rcx
00007767631d1c21  push rdx
00007767631d1c22  push rdi
00007767631d1c23  push rsi
00007767631d1c24  push r8
00007767631d1c26  push r9
00007767631d1c28  push r10
00007767631d1c2a  push r11
00007767631d1c2c  sub rsp, 0xF0
00007767631d1c33  vmovaps [rsp], xmm0
00007767631d1c38  vmovaps [rsp+0x10], xmm1
00007767631d1c3e  vmovaps [rsp+0x20], xmm2
00007767631d1c44  vmovaps [rsp+0x30], xmm3
00007767631d1c4a  vmovaps [rsp+0x40], xmm4
00007767631d1c50  vmovaps [rsp+0x50], xmm5
00007767631d1c56  vmovaps [rsp+0x60], xmm6
00007767631d1c5c  vmovaps [rsp+0x70], xmm7
00007767631d1c62  vmovaps [rsp+0x80], xmm8
00007767631d1c6b  vmovaps [rsp+0x90], xmm9
00007767631d1c74  vmovaps [rsp+0xA0], xmm10
00007767631d1c7d  vmovaps [rsp+0xB0], xmm11
00007767631d1c86  vmovaps [rsp+0xC0], xmm12
00007767631d1c8f  vmovaps [rsp+0xD0], xmm13
00007767631d1c98  vmovaps [rsp+0xE0], xmm14
00007767631d1ca1  sub rsp, 0x30
00007767631d1ca5  movaps [rsp], xmm15
00007767631d1caa  movaps [rsp+0x10], xmm13
00007767631d1cb0  movaps [rsp+0x20], xmm1
00007767631d1cb5  lea rdi, [rsp]
00007767631d1cb9  mov esi, 0x00
00007767631d1cbe  mov rax, 0x617961CDB530
00007767631d1cc8  call rax
00007767631d1cca  movaps xmm15, [rsp]
00007767631d1ccf  add rsp, 0x30
00007767631d1cd3  vmovaps xmm0, [rsp]
00007767631d1cd8  vmovaps xmm1, [rsp+0x10]
00007767631d1cde  vmovaps xmm2, [rsp+0x20]
00007767631d1ce4  vmovaps xmm3, [rsp+0x30]
00007767631d1cea  vmovaps xmm4, [rsp+0x40]
00007767631d1cf0  vmovaps xmm5, [rsp+0x50]
00007767631d1cf6  vmovaps xmm6, [rsp+0x60]
00007767631d1cfc  vmovaps xmm7, [rsp+0x70]
00007767631d1d02  vmovaps xmm8, [rsp+0x80]
00007767631d1d0b  vmovaps xmm9, [rsp+0x90]
00007767631d1d14  vmovaps xmm10, [rsp+0xA0]
00007767631d1d1d  vmovaps xmm11, [rsp+0xB0]
00007767631d1d26  vmovaps xmm12, [rsp+0xC0]
00007767631d1d2f  vmovaps xmm13, [rsp+0xD0]
00007767631d1d38  vmovaps xmm14, [rsp+0xE0]
00007767631d1d41  add rsp, 0xF0
00007767631d1d48  pop r11
00007767631d1d4a  pop r10
00007767631d1d4c  pop r9
00007767631d1d4e  pop r8
00007767631d1d50  pop rsi
00007767631d1d51  pop rdi
00007767631d1d52  pop rdx
00007767631d1d53  pop rcx
00007767631d1d54  pop rax
00007767631d1d55  add rsp, 0x08
00007767631d1d59  jmp 0x00007767631CFAEB
00007767631d1d5e  call 0x0000776762FFF430
00007767631d1d63  jmp 0x00007767631CFAF8
00007767631d1d68  sub rsp, 0x08
00007767631d1d6c  push rax
00007767631d1d6d  push rcx
00007767631d1d6e  push rdx
00007767631d1d6f  push rdi
00007767631d1d70  push rsi
00007767631d1d71  push r8
00007767631d1d73  push r9
00007767631d1d75  push r10
00007767631d1d77  push r11
00007767631d1d79  sub rsp, 0xF0
00007767631d1d80  vmovaps [rsp], xmm0
00007767631d1d85  vmovaps [rsp+0x10], xmm1
00007767631d1d8b  vmovaps [rsp+0x20], xmm2
00007767631d1d91  vmovaps [rsp+0x30], xmm3
00007767631d1d97  vmovaps [rsp+0x40], xmm4
00007767631d1d9d  vmovaps [rsp+0x50], xmm5
00007767631d1da3  vmovaps [rsp+0x60], xmm6
00007767631d1da9  vmovaps [rsp+0x70], xmm7
00007767631d1daf  vmovaps [rsp+0x80], xmm8
00007767631d1db8  vmovaps [rsp+0x90], xmm9
00007767631d1dc1  vmovaps [rsp+0xA0], xmm10
00007767631d1dca  vmovaps [rsp+0xB0], xmm11
00007767631d1dd3  vmovaps [rsp+0xC0], xmm12
00007767631d1ddc  vmovaps [rsp+0xD0], xmm13
00007767631d1de5  vmovaps [rsp+0xE0], xmm15
00007767631d1dee  sub rsp, 0x30
00007767631d1df2  movaps [rsp], xmm14
00007767631d1df7  movaps [rsp+0x10], xmm13
00007767631d1dfd  movaps [rsp+0x20], xmm2
00007767631d1e02  lea rdi, [rsp]
00007767631d1e06  mov esi, 0x00
00007767631d1e0b  mov rax, 0x617961CDB530
00007767631d1e15  call rax
00007767631d1e17  movaps xmm14, [rsp]
00007767631d1e1c  add rsp, 0x30
00007767631d1e20  vmovaps xmm0, [rsp]
00007767631d1e25  vmovaps xmm1, [rsp+0x10]
00007767631d1e2b  vmovaps xmm2, [rsp+0x20]
00007767631d1e31  vmovaps xmm3, [rsp+0x30]
00007767631d1e37  vmovaps xmm4, [rsp+0x40]
00007767631d1e3d  vmovaps xmm5, [rsp+0x50]
00007767631d1e43  vmovaps xmm6, [rsp+0x60]
00007767631d1e49  vmovaps xmm7, [rsp+0x70]
00007767631d1e4f  vmovaps xmm8, [rsp+0x80]
00007767631d1e58  vmovaps xmm9, [rsp+0x90]
00007767631d1e61  vmovaps xmm10, [rsp+0xA0]
00007767631d1e6a  vmovaps xmm11, [rsp+0xB0]
00007767631d1e73  vmovaps xmm12, [rsp+0xC0]
00007767631d1e7c  vmovaps xmm13, [rsp+0xD0]
00007767631d1e85  vmovaps xmm15, [rsp+0xE0]
00007767631d1e8e  add rsp, 0xF0
00007767631d1e95  pop r11
00007767631d1e97  pop r10
00007767631d1e99  pop r9
00007767631d1e9b  pop r8
00007767631d1e9d  pop rsi
00007767631d1e9e  pop rdi
00007767631d1e9f  pop rdx
00007767631d1ea0  pop rcx
00007767631d1ea1  pop rax
00007767631d1ea2  add rsp, 0x08
00007767631d1ea6  jmp 0x00007767631CFB24
00007767631d1eab  sub rsp, 0x08
00007767631d1eaf  push rax
00007767631d1eb0  push rcx
00007767631d1eb1  push rdx
00007767631d1eb2  push rdi
00007767631d1eb3  push rsi
00007767631d1eb4  push r8
00007767631d1eb6  push r9
00007767631d1eb8  push r10
00007767631d1eba  push r11
00007767631d1ebc  sub rsp, 0xF0
00007767631d1ec3  vmovaps [rsp], xmm0
00007767631d1ec8  vmovaps [rsp+0x10], xmm2
00007767631d1ece  vmovaps [rsp+0x20], xmm3
00007767631d1ed4  vmovaps [rsp+0x30], xmm4
00007767631d1eda  vmovaps [rsp+0x40], xmm5
00007767631d1ee0  vmovaps [rsp+0x50], xmm6
00007767631d1ee6  vmovaps [rsp+0x60], xmm7
00007767631d1eec  vmovaps [rsp+0x70], xmm8
00007767631d1ef2  vmovaps [rsp+0x80], xmm9
00007767631d1efb  vmovaps [rsp+0x90], xmm10
00007767631d1f04  vmovaps [rsp+0xA0], xmm11
00007767631d1f0d  vmovaps [rsp+0xB0], xmm12
00007767631d1f16  vmovaps [rsp+0xC0], xmm13
00007767631d1f1f  vmovaps [rsp+0xD0], xmm14
00007767631d1f28  vmovaps [rsp+0xE0], xmm15
00007767631d1f31  sub rsp, 0x30
00007767631d1f35  movaps [rsp], xmm1
00007767631d1f39  movaps [rsp+0x10], xmm13
00007767631d1f3f  movaps [rsp+0x20], xmm2
00007767631d1f44  lea rdi, [rsp]
00007767631d1f48  mov esi, 0x00
00007767631d1f4d  mov rax, 0x617961CDB530
00007767631d1f57  call rax
00007767631d1f59  movaps xmm1, [rsp]
00007767631d1f5d  add rsp, 0x30
00007767631d1f61  vmovaps xmm0, [rsp]
00007767631d1f66  vmovaps xmm2, [rsp+0x10]
00007767631d1f6c  vmovaps xmm3, [rsp+0x20]
00007767631d1f72  vmovaps xmm4, [rsp+0x30]
00007767631d1f78  vmovaps xmm5, [rsp+0x40]
00007767631d1f7e  vmovaps xmm6, [rsp+0x50]
00007767631d1f84  vmovaps xmm7, [rsp+0x60]
00007767631d1f8a  vmovaps xmm8, [rsp+0x70]
00007767631d1f90  vmovaps xmm9, [rsp+0x80]
00007767631d1f99  vmovaps xmm10, [rsp+0x90]
00007767631d1fa2  vmovaps xmm11, [rsp+0xA0]
00007767631d1fab  vmovaps xmm12, [rsp+0xB0]
00007767631d1fb4  vmovaps xmm13, [rsp+0xC0]
00007767631d1fbd  vmovaps xmm14, [rsp+0xD0]
00007767631d1fc6  vmovaps xmm15, [rsp+0xE0]
00007767631d1fcf  add rsp, 0xF0
00007767631d1fd6  pop r11
00007767631d1fd8  pop r10
00007767631d1fda  pop r9
00007767631d1fdc  pop r8
00007767631d1fde  pop rsi
00007767631d1fdf  pop rdi
00007767631d1fe0  pop rdx
00007767631d1fe1  pop rcx
00007767631d1fe2  pop rax
00007767631d1fe3  add rsp, 0x08
00007767631d1fe7  jmp 0x00007767631CFB52
00007767631d1fec  sub rsp, 0x08
00007767631d1ff0  push rax
00007767631d1ff1  push rcx
00007767631d1ff2  push rdx
00007767631d1ff3  push rdi
00007767631d1ff4  push rsi
00007767631d1ff5  push r8
00007767631d1ff7  push r9
00007767631d1ff9  push r10
00007767631d1ffb  push r11
00007767631d1ffd  sub rsp, 0xF0
00007767631d2004  vmovaps [rsp], xmm0
00007767631d2009  vmovaps [rsp+0x10], xmm1
00007767631d200f  vmovaps [rsp+0x20], xmm3
00007767631d2015  vmovaps [rsp+0x30], xmm4
00007767631d201b  vmovaps [rsp+0x40], xmm5
00007767631d2021  vmovaps [rsp+0x50], xmm6
00007767631d2027  vmovaps [rsp+0x60], xmm7
00007767631d202d  vmovaps [rsp+0x70], xmm8
00007767631d2033  vmovaps [rsp+0x80], xmm9
00007767631d203c  vmovaps [rsp+0x90], xmm10
00007767631d2045  vmovaps [rsp+0xA0], xmm11
00007767631d204e  vmovaps [rsp+0xB0], xmm12
00007767631d2057  vmovaps [rsp+0xC0], xmm13
00007767631d2060  vmovaps [rsp+0xD0], xmm14
00007767631d2069  vmovaps [rsp+0xE0], xmm15
00007767631d2072  sub rsp, 0x30
00007767631d2076  movaps [rsp], xmm2
00007767631d207a  movaps [rsp+0x10], xmm1
00007767631d207f  movaps [rsp+0x20], xmm13
00007767631d2085  lea rdi, [rsp]
00007767631d2089  mov esi, 0x00
00007767631d208e  mov rax, 0x617961CDB530
00007767631d2098  call rax
00007767631d209a  movaps xmm2, [rsp]
00007767631d209e  add rsp, 0x30
00007767631d20a2  vmovaps xmm0, [rsp]
00007767631d20a7  vmovaps xmm1, [rsp+0x10]
00007767631d20ad  vmovaps xmm3, [rsp+0x20]
00007767631d20b3  vmovaps xmm4, [rsp+0x30]
00007767631d20b9  vmovaps xmm5, [rsp+0x40]
00007767631d20bf  vmovaps xmm6, [rsp+0x50]
00007767631d20c5  vmovaps xmm7, [rsp+0x60]
00007767631d20cb  vmovaps xmm8, [rsp+0x70]
00007767631d20d1  vmovaps xmm9, [rsp+0x80]
00007767631d20da  vmovaps xmm10, [rsp+0x90]
00007767631d20e3  vmovaps xmm11, [rsp+0xA0]
00007767631d20ec  vmovaps xmm12, [rsp+0xB0]
00007767631d20f5  vmovaps xmm13, [rsp+0xC0]
00007767631d20fe  vmovaps xmm14, [rsp+0xD0]
00007767631d2107  vmovaps xmm15, [rsp+0xE0]
00007767631d2110  add rsp, 0xF0
00007767631d2117  pop r11
00007767631d2119  pop r10
00007767631d211b  pop r9
00007767631d211d  pop r8
00007767631d211f  pop rsi
00007767631d2120  pop rdi
00007767631d2121  pop rdx
00007767631d2122  pop rcx
00007767631d2123  pop rax
00007767631d2124  add rsp, 0x08
00007767631d2128  jmp 0x00007767631CFBAB
00007767631d212d  call 0x0000776762FFF430
00007767631d2132  jmp 0x00007767631CFBB8
00007767631d2137  sub rsp, 0x08
00007767631d213b  push rax
00007767631d213c  push rcx
00007767631d213d  push rdx
00007767631d213e  push rdi
00007767631d213f  push rsi
00007767631d2140  push r8
00007767631d2142  push r9
00007767631d2144  push r10
00007767631d2146  push r11
00007767631d2148  sub rsp, 0xF0
00007767631d214f  vmovaps [rsp], xmm0
00007767631d2154  vmovaps [rsp+0x10], xmm1
00007767631d215a  vmovaps [rsp+0x20], xmm2
00007767631d2160  vmovaps [rsp+0x30], xmm3
00007767631d2166  vmovaps [rsp+0x40], xmm4
00007767631d216c  vmovaps [rsp+0x50], xmm5
00007767631d2172  vmovaps [rsp+0x60], xmm6
00007767631d2178  vmovaps [rsp+0x70], xmm7
00007767631d217e  vmovaps [rsp+0x80], xmm8
00007767631d2187  vmovaps [rsp+0x90], xmm9
00007767631d2190  vmovaps [rsp+0xA0], xmm10
00007767631d2199  vmovaps [rsp+0xB0], xmm11
00007767631d21a2  vmovaps [rsp+0xC0], xmm12
00007767631d21ab  vmovaps [rsp+0xD0], xmm13
00007767631d21b4  vmovaps [rsp+0xE0], xmm14
00007767631d21bd  sub rsp, 0x30
00007767631d21c1  movaps [rsp], xmm15
00007767631d21c6  movaps [rsp+0x10], xmm13
00007767631d21cc  movaps [rsp+0x20], xmm1
00007767631d21d1  lea rdi, [rsp]
00007767631d21d5  mov esi, 0x00
00007767631d21da  mov rax, 0x617961CDB530
00007767631d21e4  call rax
00007767631d21e6  movaps xmm15, [rsp]
00007767631d21eb  add rsp, 0x30
00007767631d21ef  vmovaps xmm0, [rsp]
00007767631d21f4  vmovaps xmm1, [rsp+0x10]
00007767631d21fa  vmovaps xmm2, [rsp+0x20]
00007767631d2200  vmovaps xmm3, [rsp+0x30]
00007767631d2206  vmovaps xmm4, [rsp+0x40]
00007767631d220c  vmovaps xmm5, [rsp+0x50]
00007767631d2212  vmovaps xmm6, [rsp+0x60]
00007767631d2218  vmovaps xmm7, [rsp+0x70]
00007767631d221e  vmovaps xmm8, [rsp+0x80]
00007767631d2227  vmovaps xmm9, [rsp+0x90]
00007767631d2230  vmovaps xmm10, [rsp+0xA0]
00007767631d2239  vmovaps xmm11, [rsp+0xB0]
00007767631d2242  vmovaps xmm12, [rsp+0xC0]
00007767631d224b  vmovaps xmm13, [rsp+0xD0]
00007767631d2254  vmovaps xmm14, [rsp+0xE0]
00007767631d225d  add rsp, 0xF0
00007767631d2264  pop r11
00007767631d2266  pop r10
00007767631d2268  pop r9
00007767631d226a  pop r8
00007767631d226c  pop rsi
00007767631d226d  pop rdi
00007767631d226e  pop rdx
00007767631d226f  pop rcx
00007767631d2270  pop rax
00007767631d2271  add rsp, 0x08
00007767631d2275  jmp 0x00007767631CFBF7
00007767631d227a  sub rsp, 0x08
00007767631d227e  push rax
00007767631d227f  push rcx
00007767631d2280  push rdx
00007767631d2281  push rdi
00007767631d2282  push rsi
00007767631d2283  push r8
00007767631d2285  push r9
00007767631d2287  push r10
00007767631d2289  push r11
00007767631d228b  sub rsp, 0xF0
00007767631d2292  vmovaps [rsp], xmm0
00007767631d2297  vmovaps [rsp+0x10], xmm1
00007767631d229d  vmovaps [rsp+0x20], xmm2
00007767631d22a3  vmovaps [rsp+0x30], xmm3
00007767631d22a9  vmovaps [rsp+0x40], xmm4
00007767631d22af  vmovaps [rsp+0x50], xmm5
00007767631d22b5  vmovaps [rsp+0x60], xmm6
00007767631d22bb  vmovaps [rsp+0x70], xmm7
00007767631d22c1  vmovaps [rsp+0x80], xmm8
00007767631d22ca  vmovaps [rsp+0x90], xmm9
00007767631d22d3  vmovaps [rsp+0xA0], xmm10
00007767631d22dc  vmovaps [rsp+0xB0], xmm11
00007767631d22e5  vmovaps [rsp+0xC0], xmm12
00007767631d22ee  vmovaps [rsp+0xD0], xmm13
00007767631d22f7  vmovaps [rsp+0xE0], xmm15
00007767631d2300  sub rsp, 0x30
00007767631d2304  movaps [rsp], xmm14
00007767631d2309  movaps [rsp+0x10], xmm11
00007767631d230f  movaps [rsp+0x20], xmm1
00007767631d2314  lea rdi, [rsp]
00007767631d2318  mov esi, 0x00
00007767631d231d  mov rax, 0x617961CDB530
00007767631d2327  call rax
00007767631d2329  movaps xmm14, [rsp]
00007767631d232e  add rsp, 0x30
00007767631d2332  vmovaps xmm0, [rsp]
00007767631d2337  vmovaps xmm1, [rsp+0x10]
00007767631d233d  vmovaps xmm2, [rsp+0x20]
00007767631d2343  vmovaps xmm3, [rsp+0x30]
00007767631d2349  vmovaps xmm4, [rsp+0x40]
00007767631d234f  vmovaps xmm5, [rsp+0x50]
00007767631d2355  vmovaps xmm6, [rsp+0x60]
00007767631d235b  vmovaps xmm7, [rsp+0x70]
00007767631d2361  vmovaps xmm8, [rsp+0x80]
00007767631d236a  vmovaps xmm9, [rsp+0x90]
00007767631d2373  vmovaps xmm10, [rsp+0xA0]
00007767631d237c  vmovaps xmm11, [rsp+0xB0]
00007767631d2385  vmovaps xmm12, [rsp+0xC0]
00007767631d238e  vmovaps xmm13, [rsp+0xD0]
00007767631d2397  vmovaps xmm15, [rsp+0xE0]
00007767631d23a0  add rsp, 0xF0
00007767631d23a7  pop r11
00007767631d23a9  pop r10
00007767631d23ab  pop r9
00007767631d23ad  pop r8
00007767631d23af  pop rsi
00007767631d23b0  pop rdi
00007767631d23b1  pop rdx
00007767631d23b2  pop rcx
00007767631d23b3  pop rax
00007767631d23b4  add rsp, 0x08
00007767631d23b8  jmp 0x00007767631CFC21
00007767631d23bd  sub rsp, 0x08
00007767631d23c1  push rax
00007767631d23c2  push rcx
00007767631d23c3  push rdx
00007767631d23c4  push rdi
00007767631d23c5  push rsi
00007767631d23c6  push r8
00007767631d23c8  push r9
00007767631d23ca  push r10
00007767631d23cc  push r11
00007767631d23ce  sub rsp, 0xF0
00007767631d23d5  vmovaps [rsp], xmm0
00007767631d23da  vmovaps [rsp+0x10], xmm1
00007767631d23e0  vmovaps [rsp+0x20], xmm2
00007767631d23e6  vmovaps [rsp+0x30], xmm3
00007767631d23ec  vmovaps [rsp+0x40], xmm4
00007767631d23f2  vmovaps [rsp+0x50], xmm5
00007767631d23f8  vmovaps [rsp+0x60], xmm6
00007767631d23fe  vmovaps [rsp+0x70], xmm7
00007767631d2404  vmovaps [rsp+0x80], xmm8
00007767631d240d  vmovaps [rsp+0x90], xmm9
00007767631d2416  vmovaps [rsp+0xA0], xmm10
00007767631d241f  vmovaps [rsp+0xB0], xmm11
00007767631d2428  vmovaps [rsp+0xC0], xmm12
00007767631d2431  vmovaps [rsp+0xD0], xmm14
00007767631d243a  vmovaps [rsp+0xE0], xmm15
00007767631d2443  sub rsp, 0x30
00007767631d2447  movaps [rsp], xmm13
00007767631d244c  movaps [rsp+0x10], xmm11
00007767631d2452  movaps [rsp+0x20], xmm1
00007767631d2457  lea rdi, [rsp]
00007767631d245b  mov esi, 0x00
00007767631d2460  mov rax, 0x617961CDB530
00007767631d246a  call rax
00007767631d246c  movaps xmm13, [rsp]
00007767631d2471  add rsp, 0x30
00007767631d2475  vmovaps xmm0, [rsp]
00007767631d247a  vmovaps xmm1, [rsp+0x10]
00007767631d2480  vmovaps xmm2, [rsp+0x20]
00007767631d2486  vmovaps xmm3, [rsp+0x30]
00007767631d248c  vmovaps xmm4, [rsp+0x40]
00007767631d2492  vmovaps xmm5, [rsp+0x50]
00007767631d2498  vmovaps xmm6, [rsp+0x60]
00007767631d249e  vmovaps xmm7, [rsp+0x70]
00007767631d24a4  vmovaps xmm8, [rsp+0x80]
00007767631d24ad  vmovaps xmm9, [rsp+0x90]
00007767631d24b6  vmovaps xmm10, [rsp+0xA0]
00007767631d24bf  vmovaps xmm11, [rsp+0xB0]
00007767631d24c8  vmovaps xmm12, [rsp+0xC0]
00007767631d24d1  vmovaps xmm14, [rsp+0xD0]
00007767631d24da  vmovaps xmm15, [rsp+0xE0]
00007767631d24e3  add rsp, 0xF0
00007767631d24ea  pop r11
00007767631d24ec  pop r10
00007767631d24ee  pop r9
00007767631d24f0  pop r8
00007767631d24f2  pop rsi
00007767631d24f3  pop rdi
00007767631d24f4  pop rdx
00007767631d24f5  pop rcx
00007767631d24f6  pop rax
00007767631d24f7  add rsp, 0x08
00007767631d24fb  jmp 0x00007767631CFC76
00007767631d2500  call 0x0000776762FFF430
00007767631d2505  jmp 0x00007767631CFC83
00007767631d250a  sub rsp, 0x08
00007767631d250e  push rax
00007767631d250f  push rcx
00007767631d2510  push rdx
00007767631d2511  push rdi
00007767631d2512  push rsi
00007767631d2513  push r8
00007767631d2515  push r9
00007767631d2517  push r10
00007767631d2519  push r11
00007767631d251b  sub rsp, 0xF0
00007767631d2522  vmovaps [rsp], xmm0
00007767631d2527  vmovaps [rsp+0x10], xmm1
00007767631d252d  vmovaps [rsp+0x20], xmm2
00007767631d2533  vmovaps [rsp+0x30], xmm3
00007767631d2539  vmovaps [rsp+0x40], xmm4
00007767631d253f  vmovaps [rsp+0x50], xmm5
00007767631d2545  vmovaps [rsp+0x60], xmm6
00007767631d254b  vmovaps [rsp+0x70], xmm7
00007767631d2551  vmovaps [rsp+0x80], xmm8
00007767631d255a  vmovaps [rsp+0x90], xmm9
00007767631d2563  vmovaps [rsp+0xA0], xmm10
00007767631d256c  vmovaps [rsp+0xB0], xmm11
00007767631d2575  vmovaps [rsp+0xC0], xmm12
00007767631d257e  vmovaps [rsp+0xD0], xmm13
00007767631d2587  vmovaps [rsp+0xE0], xmm14
00007767631d2590  sub rsp, 0x30
00007767631d2594  movaps [rsp], xmm15
00007767631d2599  movaps [rsp+0x10], xmm11
00007767631d259f  movaps [rsp+0x20], xmm1
00007767631d25a4  lea rdi, [rsp]
00007767631d25a8  mov esi, 0x00
00007767631d25ad  mov rax, 0x617961CDB530
00007767631d25b7  call rax
00007767631d25b9  movaps xmm15, [rsp]
00007767631d25be  add rsp, 0x30
00007767631d25c2  vmovaps xmm0, [rsp]
00007767631d25c7  vmovaps xmm1, [rsp+0x10]
00007767631d25cd  vmovaps xmm2, [rsp+0x20]
00007767631d25d3  vmovaps xmm3, [rsp+0x30]
00007767631d25d9  vmovaps xmm4, [rsp+0x40]
00007767631d25df  vmovaps xmm5, [rsp+0x50]
00007767631d25e5  vmovaps xmm6, [rsp+0x60]
00007767631d25eb  vmovaps xmm7, [rsp+0x70]
00007767631d25f1  vmovaps xmm8, [rsp+0x80]
00007767631d25fa  vmovaps xmm9, [rsp+0x90]
00007767631d2603  vmovaps xmm10, [rsp+0xA0]
00007767631d260c  vmovaps xmm11, [rsp+0xB0]
00007767631d2615  vmovaps xmm12, [rsp+0xC0]
00007767631d261e  vmovaps xmm13, [rsp+0xD0]
00007767631d2627  vmovaps xmm14, [rsp+0xE0]
00007767631d2630  add rsp, 0xF0
00007767631d2637  pop r11
00007767631d2639  pop r10
00007767631d263b  pop r9
00007767631d263d  pop r8
00007767631d263f  pop rsi
00007767631d2640  pop rdi
00007767631d2641  pop rdx
00007767631d2642  pop rcx
00007767631d2643  pop rax
00007767631d2644  add rsp, 0x08
00007767631d2648  jmp 0x00007767631CFCBC
00007767631d264d  sub rsp, 0x08
00007767631d2651  push rax
00007767631d2652  push rcx
00007767631d2653  push rdx
00007767631d2654  push rdi
00007767631d2655  push rsi
00007767631d2656  push r8
00007767631d2658  push r9
00007767631d265a  push r10
00007767631d265c  push r11
00007767631d265e  sub rsp, 0xF0
00007767631d2665  vmovaps [rsp], xmm0
00007767631d266a  vmovaps [rsp+0x10], xmm1
00007767631d2670  vmovaps [rsp+0x20], xmm2
00007767631d2676  vmovaps [rsp+0x30], xmm3
00007767631d267c  vmovaps [rsp+0x40], xmm4
00007767631d2682  vmovaps [rsp+0x50], xmm5
00007767631d2688  vmovaps [rsp+0x60], xmm6
00007767631d268e  vmovaps [rsp+0x70], xmm7
00007767631d2694  vmovaps [rsp+0x80], xmm8
00007767631d269d  vmovaps [rsp+0x90], xmm9
00007767631d26a6  vmovaps [rsp+0xA0], xmm10
00007767631d26af  vmovaps [rsp+0xB0], xmm12
00007767631d26b8  vmovaps [rsp+0xC0], xmm13
00007767631d26c1  vmovaps [rsp+0xD0], xmm14
00007767631d26ca  vmovaps [rsp+0xE0], xmm15
00007767631d26d3  sub rsp, 0x30
00007767631d26d7  movaps [rsp], xmm11
00007767631d26dc  movaps [rsp+0x10], xmm6
00007767631d26e1  movaps [rsp+0x20], xmm14
00007767631d26e7  lea rdi, [rsp]
00007767631d26eb  mov esi, 0x00
00007767631d26f0  mov rax, 0x617961CDB530
00007767631d26fa  call rax
00007767631d26fc  movaps xmm11, [rsp]
00007767631d2701  add rsp, 0x30
00007767631d2705  vmovaps xmm0, [rsp]
00007767631d270a  vmovaps xmm1, [rsp+0x10]
00007767631d2710  vmovaps xmm2, [rsp+0x20]
00007767631d2716  vmovaps xmm3, [rsp+0x30]
00007767631d271c  vmovaps xmm4, [rsp+0x40]
00007767631d2722  vmovaps xmm5, [rsp+0x50]
00007767631d2728  vmovaps xmm6, [rsp+0x60]
00007767631d272e  vmovaps xmm7, [rsp+0x70]
00007767631d2734  vmovaps xmm8, [rsp+0x80]
00007767631d273d  vmovaps xmm9, [rsp+0x90]
00007767631d2746  vmovaps xmm10, [rsp+0xA0]
00007767631d274f  vmovaps xmm12, [rsp+0xB0]
00007767631d2758  vmovaps xmm13, [rsp+0xC0]
00007767631d2761  vmovaps xmm14, [rsp+0xD0]
00007767631d276a  vmovaps xmm15, [rsp+0xE0]
00007767631d2773  add rsp, 0xF0
00007767631d277a  pop r11
00007767631d277c  pop r10
00007767631d277e  pop r9
00007767631d2780  pop r8
00007767631d2782  pop rsi
00007767631d2783  pop rdi
00007767631d2784  pop rdx
00007767631d2785  pop rcx
00007767631d2786  pop rax
00007767631d2787  add rsp, 0x08
00007767631d278b  jmp 0x00007767631CFD34
00007767631d2790  call 0x0000776762FFF430
00007767631d2795  jmp 0x00007767631CFD3E
00007767631d279a  sub rsp, 0x08
00007767631d279e  push rax
00007767631d279f  push rcx
00007767631d27a0  push rdx
00007767631d27a1  push rdi
00007767631d27a2  push rsi
00007767631d27a3  push r8
00007767631d27a5  push r9
00007767631d27a7  push r10
00007767631d27a9  push r11
00007767631d27ab  sub rsp, 0xF0
00007767631d27b2  vmovaps [rsp], xmm0
00007767631d27b7  vmovaps [rsp+0x10], xmm1
00007767631d27bd  vmovaps [rsp+0x20], xmm2
00007767631d27c3  vmovaps [rsp+0x30], xmm3
00007767631d27c9  vmovaps [rsp+0x40], xmm4
00007767631d27cf  vmovaps [rsp+0x50], xmm5
00007767631d27d5  vmovaps [rsp+0x60], xmm6
00007767631d27db  vmovaps [rsp+0x70], xmm7
00007767631d27e1  vmovaps [rsp+0x80], xmm8
00007767631d27ea  vmovaps [rsp+0x90], xmm9
00007767631d27f3  vmovaps [rsp+0xA0], xmm10
00007767631d27fc  vmovaps [rsp+0xB0], xmm11
00007767631d2805  vmovaps [rsp+0xC0], xmm12
00007767631d280e  vmovaps [rsp+0xD0], xmm13
00007767631d2817  vmovaps [rsp+0xE0], xmm15
00007767631d2820  sub rsp, 0x30
00007767631d2824  movaps [rsp], xmm14
00007767631d2829  movaps [rsp+0x10], xmm6
00007767631d282e  movaps [rsp+0x20], xmm2
00007767631d2833  lea rdi, [rsp]
00007767631d2837  mov esi, 0x00
00007767631d283c  mov rax, 0x617961CDB530
00007767631d2846  call rax
00007767631d2848  movaps xmm14, [rsp]
00007767631d284d  add rsp, 0x30
00007767631d2851  vmovaps xmm0, [rsp]
00007767631d2856  vmovaps xmm1, [rsp+0x10]
00007767631d285c  vmovaps xmm2, [rsp+0x20]
00007767631d2862  vmovaps xmm3, [rsp+0x30]
00007767631d2868  vmovaps xmm4, [rsp+0x40]
00007767631d286e  vmovaps xmm5, [rsp+0x50]
00007767631d2874  vmovaps xmm6, [rsp+0x60]
00007767631d287a  vmovaps xmm7, [rsp+0x70]
00007767631d2880  vmovaps xmm8, [rsp+0x80]
00007767631d2889  vmovaps xmm9, [rsp+0x90]
00007767631d2892  vmovaps xmm10, [rsp+0xA0]
00007767631d289b  vmovaps xmm11, [rsp+0xB0]
00007767631d28a4  vmovaps xmm12, [rsp+0xC0]
00007767631d28ad  vmovaps xmm13, [rsp+0xD0]
00007767631d28b6  vmovaps xmm15, [rsp+0xE0]
00007767631d28bf  add rsp, 0xF0
00007767631d28c6  pop r11
00007767631d28c8  pop r10
00007767631d28ca  pop r9
00007767631d28cc  pop r8
00007767631d28ce  pop rsi
00007767631d28cf  pop rdi
00007767631d28d0  pop rdx
00007767631d28d1  pop rcx
00007767631d28d2  pop rax
00007767631d28d3  add rsp, 0x08
00007767631d28d7  jmp 0x00007767631CFD72
00007767631d28dc  sub rsp, 0x08
00007767631d28e0  push rax
00007767631d28e1  push rcx
00007767631d28e2  push rdx
00007767631d28e3  push rdi
00007767631d28e4  push rsi
00007767631d28e5  push r8
00007767631d28e7  push r9
00007767631d28e9  push r10
00007767631d28eb  push r11
00007767631d28ed  sub rsp, 0xF0
00007767631d28f4  vmovaps [rsp], xmm0
00007767631d28f9  vmovaps [rsp+0x10], xmm1
00007767631d28ff  vmovaps [rsp+0x20], xmm2
00007767631d2905  vmovaps [rsp+0x30], xmm3
00007767631d290b  vmovaps [rsp+0x40], xmm4
00007767631d2911  vmovaps [rsp+0x50], xmm5
00007767631d2917  vmovaps [rsp+0x60], xmm7
00007767631d291d  vmovaps [rsp+0x70], xmm8
00007767631d2923  vmovaps [rsp+0x80], xmm9
00007767631d292c  vmovaps [rsp+0x90], xmm10
00007767631d2935  vmovaps [rsp+0xA0], xmm11
00007767631d293e  vmovaps [rsp+0xB0], xmm12
00007767631d2947  vmovaps [rsp+0xC0], xmm13
00007767631d2950  vmovaps [rsp+0xD0], xmm14
00007767631d2959  vmovaps [rsp+0xE0], xmm15
00007767631d2962  sub rsp, 0x30
00007767631d2966  movaps [rsp], xmm6
00007767631d296a  movaps [rsp+0x10], xmm5
00007767631d296f  movaps [rsp+0x20], xmm1
00007767631d2974  lea rdi, [rsp]
00007767631d2978  mov esi, 0x00
00007767631d297d  mov rax, 0x617961CDB530
00007767631d2987  call rax
00007767631d2989  movaps xmm6, [rsp]
00007767631d298d  add rsp, 0x30
00007767631d2991  vmovaps xmm0, [rsp]
00007767631d2996  vmovaps xmm1, [rsp+0x10]
00007767631d299c  vmovaps xmm2, [rsp+0x20]
00007767631d29a2  vmovaps xmm3, [rsp+0x30]
00007767631d29a8  vmovaps xmm4, [rsp+0x40]
00007767631d29ae  vmovaps xmm5, [rsp+0x50]
00007767631d29b4  vmovaps xmm7, [rsp+0x60]
00007767631d29ba  vmovaps xmm8, [rsp+0x70]
00007767631d29c0  vmovaps xmm9, [rsp+0x80]
00007767631d29c9  vmovaps xmm10, [rsp+0x90]
00007767631d29d2  vmovaps xmm11, [rsp+0xA0]
00007767631d29db  vmovaps xmm12, [rsp+0xB0]
00007767631d29e4  vmovaps xmm13, [rsp+0xC0]
00007767631d29ed  vmovaps xmm14, [rsp+0xD0]
00007767631d29f6  vmovaps xmm15, [rsp+0xE0]
00007767631d29ff  add rsp, 0xF0
00007767631d2a06  pop r11
00007767631d2a08  pop r10
00007767631d2a0a  pop r9
00007767631d2a0c  pop r8
00007767631d2a0e  pop rsi
00007767631d2a0f  pop rdi
00007767631d2a10  pop rdx
00007767631d2a11  pop rcx
00007767631d2a12  pop rax
00007767631d2a13  add rsp, 0x08
00007767631d2a17  jmp 0x00007767631CFD98
00007767631d2a1c  sub rsp, 0x08
00007767631d2a20  push rax
00007767631d2a21  push rcx
00007767631d2a22  push rdx
00007767631d2a23  push rdi
00007767631d2a24  push rsi
00007767631d2a25  push r8
00007767631d2a27  push r9
00007767631d2a29  push r10
00007767631d2a2b  push r11
00007767631d2a2d  sub rsp, 0xF0
00007767631d2a34  vmovaps [rsp], xmm0
00007767631d2a39  vmovaps [rsp+0x10], xmm2
00007767631d2a3f  vmovaps [rsp+0x20], xmm3
00007767631d2a45  vmovaps [rsp+0x30], xmm4
00007767631d2a4b  vmovaps [rsp+0x40], xmm5
00007767631d2a51  vmovaps [rsp+0x50], xmm6
00007767631d2a57  vmovaps [rsp+0x60], xmm7
00007767631d2a5d  vmovaps [rsp+0x70], xmm8
00007767631d2a63  vmovaps [rsp+0x80], xmm9
00007767631d2a6c  vmovaps [rsp+0x90], xmm10
00007767631d2a75  vmovaps [rsp+0xA0], xmm11
00007767631d2a7e  vmovaps [rsp+0xB0], xmm12
00007767631d2a87  vmovaps [rsp+0xC0], xmm13
00007767631d2a90  vmovaps [rsp+0xD0], xmm14
00007767631d2a99  vmovaps [rsp+0xE0], xmm15
00007767631d2aa2  sub rsp, 0x30
00007767631d2aa6  movaps [rsp], xmm1
00007767631d2aaa  movaps [rsp+0x10], xmm5
00007767631d2aaf  movaps [rsp+0x20], xmm13
00007767631d2ab5  lea rdi, [rsp]
00007767631d2ab9  mov esi, 0x00
00007767631d2abe  mov rax, 0x617961CDB530
00007767631d2ac8  call rax
00007767631d2aca  movaps xmm1, [rsp]
00007767631d2ace  add rsp, 0x30
00007767631d2ad2  vmovaps xmm0, [rsp]
00007767631d2ad7  vmovaps xmm2, [rsp+0x10]
00007767631d2add  vmovaps xmm3, [rsp+0x20]
00007767631d2ae3  vmovaps xmm4, [rsp+0x30]
00007767631d2ae9  vmovaps xmm5, [rsp+0x40]
00007767631d2aef  vmovaps xmm6, [rsp+0x50]
00007767631d2af5  vmovaps xmm7, [rsp+0x60]
00007767631d2afb  vmovaps xmm8, [rsp+0x70]
00007767631d2b01  vmovaps xmm9, [rsp+0x80]
00007767631d2b0a  vmovaps xmm10, [rsp+0x90]
00007767631d2b13  vmovaps xmm11, [rsp+0xA0]
00007767631d2b1c  vmovaps xmm12, [rsp+0xB0]
00007767631d2b25  vmovaps xmm13, [rsp+0xC0]
00007767631d2b2e  vmovaps xmm14, [rsp+0xD0]
00007767631d2b37  vmovaps xmm15, [rsp+0xE0]
00007767631d2b40  add rsp, 0xF0
00007767631d2b47  pop r11
00007767631d2b49  pop r10
00007767631d2b4b  pop r9
00007767631d2b4d  pop r8
00007767631d2b4f  pop rsi
00007767631d2b50  pop rdi
00007767631d2b51  pop rdx
00007767631d2b52  pop rcx
00007767631d2b53  pop rax
00007767631d2b54  add rsp, 0x08
00007767631d2b58  jmp 0x00007767631CFDB6
00007767631d2b5d  sub rsp, 0x08
00007767631d2b61  push rax
00007767631d2b62  push rcx
00007767631d2b63  push rdx
00007767631d2b64  push rdi
00007767631d2b65  push rsi
00007767631d2b66  push r8
00007767631d2b68  push r9
00007767631d2b6a  push r10
00007767631d2b6c  push r11
00007767631d2b6e  sub rsp, 0xF0
00007767631d2b75  vmovaps [rsp], xmm0
00007767631d2b7a  vmovaps [rsp+0x10], xmm1
00007767631d2b80  vmovaps [rsp+0x20], xmm2
00007767631d2b86  vmovaps [rsp+0x30], xmm3
00007767631d2b8c  vmovaps [rsp+0x40], xmm4
00007767631d2b92  vmovaps [rsp+0x50], xmm6
00007767631d2b98  vmovaps [rsp+0x60], xmm7
00007767631d2b9e  vmovaps [rsp+0x70], xmm8
00007767631d2ba4  vmovaps [rsp+0x80], xmm9
00007767631d2bad  vmovaps [rsp+0x90], xmm10
00007767631d2bb6  vmovaps [rsp+0xA0], xmm11
00007767631d2bbf  vmovaps [rsp+0xB0], xmm12
00007767631d2bc8  vmovaps [rsp+0xC0], xmm13
00007767631d2bd1  vmovaps [rsp+0xD0], xmm14
00007767631d2bda  vmovaps [rsp+0xE0], xmm15
00007767631d2be3  sub rsp, 0x30
00007767631d2be7  movaps [rsp], xmm5
00007767631d2beb  movaps [rsp+0x10], xmm2
00007767631d2bf0  movaps [rsp+0x20], xmm13
00007767631d2bf6  lea rdi, [rsp]
00007767631d2bfa  mov esi, 0x00
00007767631d2bff  mov rax, 0x617961CDB530
00007767631d2c09  call rax
00007767631d2c0b  movaps xmm5, [rsp]
00007767631d2c0f  add rsp, 0x30
00007767631d2c13  vmovaps xmm0, [rsp]
00007767631d2c18  vmovaps xmm1, [rsp+0x10]
00007767631d2c1e  vmovaps xmm2, [rsp+0x20]
00007767631d2c24  vmovaps xmm3, [rsp+0x30]
00007767631d2c2a  vmovaps xmm4, [rsp+0x40]
00007767631d2c30  vmovaps xmm6, [rsp+0x50]
00007767631d2c36  vmovaps xmm7, [rsp+0x60]
00007767631d2c3c  vmovaps xmm8, [rsp+0x70]
00007767631d2c42  vmovaps xmm9, [rsp+0x80]
00007767631d2c4b  vmovaps xmm10, [rsp+0x90]
00007767631d2c54  vmovaps xmm11, [rsp+0xA0]
00007767631d2c5d  vmovaps xmm12, [rsp+0xB0]
00007767631d2c66  vmovaps xmm13, [rsp+0xC0]
00007767631d2c6f  vmovaps xmm14, [rsp+0xD0]
00007767631d2c78  vmovaps xmm15, [rsp+0xE0]
00007767631d2c81  add rsp, 0xF0
00007767631d2c88  pop r11
00007767631d2c8a  pop r10
00007767631d2c8c  pop r9
00007767631d2c8e  pop r8
00007767631d2c90  pop rsi
00007767631d2c91  pop rdi
00007767631d2c92  pop rdx
00007767631d2c93  pop rcx
00007767631d2c94  pop rax
00007767631d2c95  add rsp, 0x08
00007767631d2c99  jmp 0x00007767631CFDEC
00007767631d2c9e  sub rsp, 0x08
00007767631d2ca2  push rax
00007767631d2ca3  push rcx
00007767631d2ca4  push rdx
00007767631d2ca5  push rdi
00007767631d2ca6  push rsi
00007767631d2ca7  push r8
00007767631d2ca9  push r9
00007767631d2cab  push r10
00007767631d2cad  push r11
00007767631d2caf  sub rsp, 0xF0
00007767631d2cb6  vmovaps [rsp], xmm0
00007767631d2cbb  vmovaps [rsp+0x10], xmm1
00007767631d2cc1  vmovaps [rsp+0x20], xmm2
00007767631d2cc7  vmovaps [rsp+0x30], xmm3
00007767631d2ccd  vmovaps [rsp+0x40], xmm4
00007767631d2cd3  vmovaps [rsp+0x50], xmm5
00007767631d2cd9  vmovaps [rsp+0x60], xmm6
00007767631d2cdf  vmovaps [rsp+0x70], xmm7
00007767631d2ce5  vmovaps [rsp+0x80], xmm8
00007767631d2cee  vmovaps [rsp+0x90], xmm9
00007767631d2cf7  vmovaps [rsp+0xA0], xmm10
00007767631d2d00  vmovaps [rsp+0xB0], xmm11
00007767631d2d09  vmovaps [rsp+0xC0], xmm12
00007767631d2d12  vmovaps [rsp+0xD0], xmm14
00007767631d2d1b  vmovaps [rsp+0xE0], xmm15
00007767631d2d24  sub rsp, 0x30
00007767631d2d28  movaps [rsp], xmm13
00007767631d2d2d  movaps [rsp+0x10], xmm10
00007767631d2d33  movaps [rsp+0x20], xmm1
00007767631d2d38  lea rdi, [rsp]
00007767631d2d3c  mov esi, 0x00
00007767631d2d41  mov rax, 0x617961CDB530
00007767631d2d4b  call rax
00007767631d2d4d  movaps xmm13, [rsp]
00007767631d2d52  add rsp, 0x30
00007767631d2d56  vmovaps xmm0, [rsp]
00007767631d2d5b  vmovaps xmm1, [rsp+0x10]
00007767631d2d61  vmovaps xmm2, [rsp+0x20]
00007767631d2d67  vmovaps xmm3, [rsp+0x30]
00007767631d2d6d  vmovaps xmm4, [rsp+0x40]
00007767631d2d73  vmovaps xmm5, [rsp+0x50]
00007767631d2d79  vmovaps xmm6, [rsp+0x60]
00007767631d2d7f  vmovaps xmm7, [rsp+0x70]
00007767631d2d85  vmovaps xmm8, [rsp+0x80]
00007767631d2d8e  vmovaps xmm9, [rsp+0x90]
00007767631d2d97  vmovaps xmm10, [rsp+0xA0]
00007767631d2da0  vmovaps xmm11, [rsp+0xB0]
00007767631d2da9  vmovaps xmm12, [rsp+0xC0]
00007767631d2db2  vmovaps xmm14, [rsp+0xD0]
00007767631d2dbb  vmovaps xmm15, [rsp+0xE0]
00007767631d2dc4  add rsp, 0xF0
00007767631d2dcb  pop r11
00007767631d2dcd  pop r10
00007767631d2dcf  pop r9
00007767631d2dd1  pop r8
00007767631d2dd3  pop rsi
00007767631d2dd4  pop rdi
00007767631d2dd5  pop rdx
00007767631d2dd6  pop rcx
00007767631d2dd7  pop rax
00007767631d2dd8  add rsp, 0x08
00007767631d2ddc  jmp 0x00007767631CFE15
00007767631d2de1  sub rsp, 0x08
00007767631d2de5  push rax
00007767631d2de6  push rcx
00007767631d2de7  push rdx
00007767631d2de8  push rdi
00007767631d2de9  push rsi
00007767631d2dea  push r8
00007767631d2dec  push r9
00007767631d2dee  push r10
00007767631d2df0  push r11
00007767631d2df2  sub rsp, 0xF0
00007767631d2df9  vmovaps [rsp], xmm0
00007767631d2dfe  vmovaps [rsp+0x10], xmm2
00007767631d2e04  vmovaps [rsp+0x20], xmm3
00007767631d2e0a  vmovaps [rsp+0x30], xmm4
00007767631d2e10  vmovaps [rsp+0x40], xmm5
00007767631d2e16  vmovaps [rsp+0x50], xmm6
00007767631d2e1c  vmovaps [rsp+0x60], xmm7
00007767631d2e22  vmovaps [rsp+0x70], xmm8
00007767631d2e28  vmovaps [rsp+0x80], xmm9
00007767631d2e31  vmovaps [rsp+0x90], xmm10
00007767631d2e3a  vmovaps [rsp+0xA0], xmm11
00007767631d2e43  vmovaps [rsp+0xB0], xmm12
00007767631d2e4c  vmovaps [rsp+0xC0], xmm13
00007767631d2e55  vmovaps [rsp+0xD0], xmm14
00007767631d2e5e  vmovaps [rsp+0xE0], xmm15
00007767631d2e67  sub rsp, 0x30
00007767631d2e6b  movaps [rsp], xmm1
00007767631d2e6f  movaps [rsp+0x10], xmm15
00007767631d2e75  movaps [rsp+0x20], xmm10
00007767631d2e7b  lea rdi, [rsp]
00007767631d2e7f  mov esi, 0x00
00007767631d2e84  mov rax, 0x617961CDB530
00007767631d2e8e  call rax
00007767631d2e90  movaps xmm1, [rsp]
00007767631d2e94  add rsp, 0x30
00007767631d2e98  vmovaps xmm0, [rsp]
00007767631d2e9d  vmovaps xmm2, [rsp+0x10]
00007767631d2ea3  vmovaps xmm3, [rsp+0x20]
00007767631d2ea9  vmovaps xmm4, [rsp+0x30]
00007767631d2eaf  vmovaps xmm5, [rsp+0x40]
00007767631d2eb5  vmovaps xmm6, [rsp+0x50]
00007767631d2ebb  vmovaps xmm7, [rsp+0x60]
00007767631d2ec1  vmovaps xmm8, [rsp+0x70]
00007767631d2ec7  vmovaps xmm9, [rsp+0x80]
00007767631d2ed0  vmovaps xmm10, [rsp+0x90]
00007767631d2ed9  vmovaps xmm11, [rsp+0xA0]
00007767631d2ee2  vmovaps xmm12, [rsp+0xB0]
00007767631d2eeb  vmovaps xmm13, [rsp+0xC0]
00007767631d2ef4  vmovaps xmm14, [rsp+0xD0]
00007767631d2efd  vmovaps xmm15, [rsp+0xE0]
00007767631d2f06  add rsp, 0xF0
00007767631d2f0d  pop r11
00007767631d2f0f  pop r10
00007767631d2f11  pop r9
00007767631d2f13  pop r8
00007767631d2f15  pop rsi
00007767631d2f16  pop rdi
00007767631d2f17  pop rdx
00007767631d2f18  pop rcx
00007767631d2f19  pop rax
00007767631d2f1a  add rsp, 0x08
00007767631d2f1e  jmp 0x00007767631CFE34
00007767631d2f23  sub rsp, 0x08
00007767631d2f27  push rax
00007767631d2f28  push rcx
00007767631d2f29  push rdx
00007767631d2f2a  push rdi
00007767631d2f2b  push rsi
00007767631d2f2c  push r8
00007767631d2f2e  push r9
00007767631d2f30  push r10
00007767631d2f32  push r11
00007767631d2f34  sub rsp, 0xF0
00007767631d2f3b  vmovaps [rsp], xmm0
00007767631d2f40  vmovaps [rsp+0x10], xmm1
00007767631d2f46  vmovaps [rsp+0x20], xmm2
00007767631d2f4c  vmovaps [rsp+0x30], xmm3
00007767631d2f52  vmovaps [rsp+0x40], xmm4
00007767631d2f58  vmovaps [rsp+0x50], xmm5
00007767631d2f5e  vmovaps [rsp+0x60], xmm6
00007767631d2f64  vmovaps [rsp+0x70], xmm7
00007767631d2f6a  vmovaps [rsp+0x80], xmm8
00007767631d2f73  vmovaps [rsp+0x90], xmm9
00007767631d2f7c  vmovaps [rsp+0xA0], xmm10
00007767631d2f85  vmovaps [rsp+0xB0], xmm11
00007767631d2f8e  vmovaps [rsp+0xC0], xmm12
00007767631d2f97  vmovaps [rsp+0xD0], xmm13
00007767631d2fa0  vmovaps [rsp+0xE0], xmm14
00007767631d2fa9  sub rsp, 0x30
00007767631d2fad  movaps [rsp], xmm15
00007767631d2fb2  movaps [rsp+0x10], xmm10
00007767631d2fb8  movaps [rsp+0x20], xmm11
00007767631d2fbe  lea rdi, [rsp]
00007767631d2fc2  mov esi, 0x00
00007767631d2fc7  mov rax, 0x617961CDB530
00007767631d2fd1  call rax
00007767631d2fd3  movaps xmm15, [rsp]
00007767631d2fd8  add rsp, 0x30
00007767631d2fdc  vmovaps xmm0, [rsp]
00007767631d2fe1  vmovaps xmm1, [rsp+0x10]
00007767631d2fe7  vmovaps xmm2, [rsp+0x20]
00007767631d2fed  vmovaps xmm3, [rsp+0x30]
00007767631d2ff3  vmovaps xmm4, [rsp+0x40]
00007767631d2ff9  vmovaps xmm5, [rsp+0x50]
00007767631d2fff  vmovaps xmm6, [rsp+0x60]
00007767631d3005  vmovaps xmm7, [rsp+0x70]
00007767631d300b  vmovaps xmm8, [rsp+0x80]
00007767631d3014  vmovaps xmm9, [rsp+0x90]
00007767631d301d  vmovaps xmm10, [rsp+0xA0]
00007767631d3026  vmovaps xmm11, [rsp+0xB0]
00007767631d302f  vmovaps xmm12, [rsp+0xC0]
00007767631d3038  vmovaps xmm13, [rsp+0xD0]
00007767631d3041  vmovaps xmm14, [rsp+0xE0]
00007767631d304a  add rsp, 0xF0
00007767631d3051  pop r11
00007767631d3053  pop r10
00007767631d3055  pop r9
00007767631d3057  pop r8
00007767631d3059  pop rsi
00007767631d305a  pop rdi
00007767631d305b  pop rdx
00007767631d305c  pop rcx
00007767631d305d  pop rax
00007767631d305e  add rsp, 0x08
00007767631d3062  jmp 0x00007767631CFE57
00007767631d3067  sub rsp, 0x08
00007767631d306b  push rax
00007767631d306c  push rcx
00007767631d306d  push rdx
00007767631d306e  push rdi
00007767631d306f  push rsi
00007767631d3070  push r8
00007767631d3072  push r9
00007767631d3074  push r10
00007767631d3076  push r11
00007767631d3078  sub rsp, 0xF0
00007767631d307f  vmovaps [rsp], xmm0
00007767631d3084  vmovaps [rsp+0x10], xmm1
00007767631d308a  vmovaps [rsp+0x20], xmm2
00007767631d3090  vmovaps [rsp+0x30], xmm3
00007767631d3096  vmovaps [rsp+0x40], xmm4
00007767631d309c  vmovaps [rsp+0x50], xmm5
00007767631d30a2  vmovaps [rsp+0x60], xmm6
00007767631d30a8  vmovaps [rsp+0x70], xmm7
00007767631d30ae  vmovaps [rsp+0x80], xmm8
00007767631d30b7  vmovaps [rsp+0x90], xmm9
00007767631d30c0  vmovaps [rsp+0xA0], xmm11
00007767631d30c9  vmovaps [rsp+0xB0], xmm12
00007767631d30d2  vmovaps [rsp+0xC0], xmm13
00007767631d30db  vmovaps [rsp+0xD0], xmm14
00007767631d30e4  vmovaps [rsp+0xE0], xmm15
00007767631d30ed  sub rsp, 0x30
00007767631d30f1  movaps [rsp], xmm10
00007767631d30f6  movaps [rsp+0x10], xmm12
00007767631d30fc  movaps [rsp+0x20], xmm11
00007767631d3102  lea rdi, [rsp]
00007767631d3106  mov esi, 0x00
00007767631d310b  mov rax, 0x617961CDB530
00007767631d3115  call rax
00007767631d3117  movaps xmm10, [rsp]
00007767631d311c  add rsp, 0x30
00007767631d3120  vmovaps xmm0, [rsp]
00007767631d3125  vmovaps xmm1, [rsp+0x10]
00007767631d312b  vmovaps xmm2, [rsp+0x20]
00007767631d3131  vmovaps xmm3, [rsp+0x30]
00007767631d3137  vmovaps xmm4, [rsp+0x40]
00007767631d313d  vmovaps xmm5, [rsp+0x50]
00007767631d3143  vmovaps xmm6, [rsp+0x60]
00007767631d3149  vmovaps xmm7, [rsp+0x70]
00007767631d314f  vmovaps xmm8, [rsp+0x80]
00007767631d3158  vmovaps xmm9, [rsp+0x90]
00007767631d3161  vmovaps xmm11, [rsp+0xA0]
00007767631d316a  vmovaps xmm12, [rsp+0xB0]
00007767631d3173  vmovaps xmm13, [rsp+0xC0]
00007767631d317c  vmovaps xmm14, [rsp+0xD0]
00007767631d3185  vmovaps xmm15, [rsp+0xE0]
00007767631d318e  add rsp, 0xF0
00007767631d3195  pop r11
00007767631d3197  pop r10
00007767631d3199  pop r9
00007767631d319b  pop r8
00007767631d319d  pop rsi
00007767631d319e  pop rdi
00007767631d319f  pop rdx
00007767631d31a0  pop rcx
00007767631d31a1  pop rax
00007767631d31a2  add rsp, 0x08
00007767631d31a6  jmp 0x00007767631CFE80
00007767631d31ab  sub rsp, 0x08
00007767631d31af  push rax
00007767631d31b0  push rcx
00007767631d31b1  push rdx
00007767631d31b2  push rdi
00007767631d31b3  push rsi
00007767631d31b4  push r8
00007767631d31b6  push r9
00007767631d31b8  push r10
00007767631d31ba  push r11
00007767631d31bc  sub rsp, 0xF0
00007767631d31c3  vmovaps [rsp], xmm0
00007767631d31c8  vmovaps [rsp+0x10], xmm1
00007767631d31ce  vmovaps [rsp+0x20], xmm2
00007767631d31d4  vmovaps [rsp+0x30], xmm3
00007767631d31da  vmovaps [rsp+0x40], xmm4
00007767631d31e0  vmovaps [rsp+0x50], xmm5
00007767631d31e6  vmovaps [rsp+0x60], xmm6
00007767631d31ec  vmovaps [rsp+0x70], xmm7
00007767631d31f2  vmovaps [rsp+0x80], xmm8
00007767631d31fb  vmovaps [rsp+0x90], xmm9
00007767631d3204  vmovaps [rsp+0xA0], xmm10
00007767631d320d  vmovaps [rsp+0xB0], xmm12
00007767631d3216  vmovaps [rsp+0xC0], xmm13
00007767631d321f  vmovaps [rsp+0xD0], xmm14
00007767631d3228  vmovaps [rsp+0xE0], xmm15
00007767631d3231  sub rsp, 0x30
00007767631d3235  movaps [rsp], xmm11
00007767631d323a  movaps [rsp+0x10], xmm2
00007767631d323f  movaps [rsp+0x20], xmm12
00007767631d3245  lea rdi, [rsp]
00007767631d3249  mov esi, 0x00
00007767631d324e  mov rax, 0x617961CDB530
00007767631d3258  call rax
00007767631d325a  movaps xmm11, [rsp]
00007767631d325f  add rsp, 0x30
00007767631d3263  vmovaps xmm0, [rsp]
00007767631d3268  vmovaps xmm1, [rsp+0x10]
00007767631d326e  vmovaps xmm2, [rsp+0x20]
00007767631d3274  vmovaps xmm3, [rsp+0x30]
00007767631d327a  vmovaps xmm4, [rsp+0x40]
00007767631d3280  vmovaps xmm5, [rsp+0x50]
00007767631d3286  vmovaps xmm6, [rsp+0x60]
00007767631d328c  vmovaps xmm7, [rsp+0x70]
00007767631d3292  vmovaps xmm8, [rsp+0x80]
00007767631d329b  vmovaps xmm9, [rsp+0x90]
00007767631d32a4  vmovaps xmm10, [rsp+0xA0]
00007767631d32ad  vmovaps xmm12, [rsp+0xB0]
00007767631d32b6  vmovaps xmm13, [rsp+0xC0]
00007767631d32bf  vmovaps xmm14, [rsp+0xD0]
00007767631d32c8  vmovaps xmm15, [rsp+0xE0]
00007767631d32d1  add rsp, 0xF0
00007767631d32d8  pop r11
00007767631d32da  pop r10
00007767631d32dc  pop r9
00007767631d32de  pop r8
00007767631d32e0  pop rsi
00007767631d32e1  pop rdi
00007767631d32e2  pop rdx
00007767631d32e3  pop rcx
00007767631d32e4  pop rax
00007767631d32e5  add rsp, 0x08
00007767631d32e9  jmp 0x00007767631CFEB8
00007767631d32ee  sub rsp, 0x08
00007767631d32f2  push rax
00007767631d32f3  push rcx
00007767631d32f4  push rdx
00007767631d32f5  push rdi
00007767631d32f6  push rsi
00007767631d32f7  push r8
00007767631d32f9  push r9
00007767631d32fb  push r10
00007767631d32fd  push r11
00007767631d32ff  sub rsp, 0xF0
00007767631d3306  vmovaps [rsp], xmm0
00007767631d330b  vmovaps [rsp+0x10], xmm2
00007767631d3311  vmovaps [rsp+0x20], xmm3
00007767631d3317  vmovaps [rsp+0x30], xmm4
00007767631d331d  vmovaps [rsp+0x40], xmm5
00007767631d3323  vmovaps [rsp+0x50], xmm6
00007767631d3329  vmovaps [rsp+0x60], xmm7
00007767631d332f  vmovaps [rsp+0x70], xmm8
00007767631d3335  vmovaps [rsp+0x80], xmm9
00007767631d333e  vmovaps [rsp+0x90], xmm10
00007767631d3347  vmovaps [rsp+0xA0], xmm11
00007767631d3350  vmovaps [rsp+0xB0], xmm12
00007767631d3359  vmovaps [rsp+0xC0], xmm13
00007767631d3362  vmovaps [rsp+0xD0], xmm14
00007767631d336b  vmovaps [rsp+0xE0], xmm15
00007767631d3374  sub rsp, 0x30
00007767631d3378  movaps [rsp], xmm1
00007767631d337c  movaps [rsp+0x10], xmm14
00007767631d3382  movaps [rsp+0x20], xmm6
00007767631d3387  lea rdi, [rsp]
00007767631d338b  mov esi, 0x00
00007767631d3390  mov rax, 0x617961CDB530
00007767631d339a  call rax
00007767631d339c  movaps xmm1, [rsp]
00007767631d33a0  add rsp, 0x30
00007767631d33a4  vmovaps xmm0, [rsp]
00007767631d33a9  vmovaps xmm2, [rsp+0x10]
00007767631d33af  vmovaps xmm3, [rsp+0x20]
00007767631d33b5  vmovaps xmm4, [rsp+0x30]
00007767631d33bb  vmovaps xmm5, [rsp+0x40]
00007767631d33c1  vmovaps xmm6, [rsp+0x50]
00007767631d33c7  vmovaps xmm7, [rsp+0x60]
00007767631d33cd  vmovaps xmm8, [rsp+0x70]
00007767631d33d3  vmovaps xmm9, [rsp+0x80]
00007767631d33dc  vmovaps xmm10, [rsp+0x90]
00007767631d33e5  vmovaps xmm11, [rsp+0xA0]
00007767631d33ee  vmovaps xmm12, [rsp+0xB0]
00007767631d33f7  vmovaps xmm13, [rsp+0xC0]
00007767631d3400  vmovaps xmm14, [rsp+0xD0]
00007767631d3409  vmovaps xmm15, [rsp+0xE0]
00007767631d3412  add rsp, 0xF0
00007767631d3419  pop r11
00007767631d341b  pop r10
00007767631d341d  pop r9
00007767631d341f  pop r8
00007767631d3421  pop rsi
00007767631d3422  pop rdi
00007767631d3423  pop rdx
00007767631d3424  pop rcx
00007767631d3425  pop rax
00007767631d3426  add rsp, 0x08
00007767631d342a  jmp 0x00007767631CFED1
00007767631d342f  sub rsp, 0x08
00007767631d3433  push rax
00007767631d3434  push rcx
00007767631d3435  push rdx
00007767631d3436  push rdi
00007767631d3437  push rsi
00007767631d3438  push r8
00007767631d343a  push r9
00007767631d343c  push r10
00007767631d343e  push r11
00007767631d3440  sub rsp, 0xF0
00007767631d3447  vmovaps [rsp], xmm0
00007767631d344c  vmovaps [rsp+0x10], xmm1
00007767631d3452  vmovaps [rsp+0x20], xmm2
00007767631d3458  vmovaps [rsp+0x30], xmm3
00007767631d345e  vmovaps [rsp+0x40], xmm4
00007767631d3464  vmovaps [rsp+0x50], xmm5
00007767631d346a  vmovaps [rsp+0x60], xmm6
00007767631d3470  vmovaps [rsp+0x70], xmm7
00007767631d3476  vmovaps [rsp+0x80], xmm8
00007767631d347f  vmovaps [rsp+0x90], xmm9
00007767631d3488  vmovaps [rsp+0xA0], xmm10
00007767631d3491  vmovaps [rsp+0xB0], xmm11
00007767631d349a  vmovaps [rsp+0xC0], xmm12
00007767631d34a3  vmovaps [rsp+0xD0], xmm13
00007767631d34ac  vmovaps [rsp+0xE0], xmm15
00007767631d34b5  sub rsp, 0x30
00007767631d34b9  movaps [rsp], xmm14
00007767631d34be  movaps [rsp+0x10], xmm12
00007767631d34c4  movaps [rsp+0x20], xmm5
00007767631d34c9  lea rdi, [rsp]
00007767631d34cd  mov esi, 0x00
00007767631d34d2  mov rax, 0x617961CDB530
00007767631d34dc  call rax
00007767631d34de  movaps xmm14, [rsp]
00007767631d34e3  add rsp, 0x30
00007767631d34e7  vmovaps xmm0, [rsp]
00007767631d34ec  vmovaps xmm1, [rsp+0x10]
00007767631d34f2  vmovaps xmm2, [rsp+0x20]
00007767631d34f8  vmovaps xmm3, [rsp+0x30]
00007767631d34fe  vmovaps xmm4, [rsp+0x40]
00007767631d3504  vmovaps xmm5, [rsp+0x50]
00007767631d350a  vmovaps xmm6, [rsp+0x60]
00007767631d3510  vmovaps xmm7, [rsp+0x70]
00007767631d3516  vmovaps xmm8, [rsp+0x80]
00007767631d351f  vmovaps xmm9, [rsp+0x90]
00007767631d3528  vmovaps xmm10, [rsp+0xA0]
00007767631d3531  vmovaps xmm11, [rsp+0xB0]
00007767631d353a  vmovaps xmm12, [rsp+0xC0]
00007767631d3543  vmovaps xmm13, [rsp+0xD0]
00007767631d354c  vmovaps xmm15, [rsp+0xE0]
00007767631d3555  add rsp, 0xF0
00007767631d355c  pop r11
00007767631d355e  pop r10
00007767631d3560  pop r9
00007767631d3562  pop r8
00007767631d3564  pop rsi
00007767631d3565  pop rdi
00007767631d3566  pop rdx
00007767631d3567  pop rcx
00007767631d3568  pop rax
00007767631d3569  add rsp, 0x08
00007767631d356d  jmp 0x00007767631CFEF1
00007767631d3572  sub rsp, 0x08
00007767631d3576  push rax
00007767631d3577  push rcx
00007767631d3578  push rdx
00007767631d3579  push rdi
00007767631d357a  push rsi
00007767631d357b  push r8
00007767631d357d  push r9
00007767631d357f  push r10
00007767631d3581  push r11
00007767631d3583  sub rsp, 0xF0
00007767631d358a  vmovaps [rsp], xmm0
00007767631d358f  vmovaps [rsp+0x10], xmm1
00007767631d3595  vmovaps [rsp+0x20], xmm2
00007767631d359b  vmovaps [rsp+0x30], xmm3
00007767631d35a1  vmovaps [rsp+0x40], xmm4
00007767631d35a7  vmovaps [rsp+0x50], xmm5
00007767631d35ad  vmovaps [rsp+0x60], xmm7
00007767631d35b3  vmovaps [rsp+0x70], xmm8
00007767631d35b9  vmovaps [rsp+0x80], xmm9
00007767631d35c2  vmovaps [rsp+0x90], xmm10
00007767631d35cb  vmovaps [rsp+0xA0], xmm11
00007767631d35d4  vmovaps [rsp+0xB0], xmm12
00007767631d35dd  vmovaps [rsp+0xC0], xmm13
00007767631d35e6  vmovaps [rsp+0xD0], xmm14
00007767631d35ef  vmovaps [rsp+0xE0], xmm15
00007767631d35f8  sub rsp, 0x30
00007767631d35fc  movaps [rsp], xmm6
00007767631d3600  movaps [rsp+0x10], xmm9
00007767631d3606  movaps [rsp+0x20], xmm12
00007767631d360c  lea rdi, [rsp]
00007767631d3610  mov esi, 0x00
00007767631d3615  mov rax, 0x617961CDB530
00007767631d361f  call rax
00007767631d3621  movaps xmm6, [rsp]
00007767631d3625  add rsp, 0x30
00007767631d3629  vmovaps xmm0, [rsp]
00007767631d362e  vmovaps xmm1, [rsp+0x10]
00007767631d3634  vmovaps xmm2, [rsp+0x20]
00007767631d363a  vmovaps xmm3, [rsp+0x30]
00007767631d3640  vmovaps xmm4, [rsp+0x40]
00007767631d3646  vmovaps xmm5, [rsp+0x50]
00007767631d364c  vmovaps xmm7, [rsp+0x60]
00007767631d3652  vmovaps xmm8, [rsp+0x70]
00007767631d3658  vmovaps xmm9, [rsp+0x80]
00007767631d3661  vmovaps xmm10, [rsp+0x90]
00007767631d366a  vmovaps xmm11, [rsp+0xA0]
00007767631d3673  vmovaps xmm12, [rsp+0xB0]
00007767631d367c  vmovaps xmm13, [rsp+0xC0]
00007767631d3685  vmovaps xmm14, [rsp+0xD0]
00007767631d368e  vmovaps xmm15, [rsp+0xE0]
00007767631d3697  add rsp, 0xF0
00007767631d369e  pop r11
00007767631d36a0  pop r10
00007767631d36a2  pop r9
00007767631d36a4  pop r8
00007767631d36a6  pop rsi
00007767631d36a7  pop rdi
00007767631d36a8  pop rdx
00007767631d36a9  pop rcx
00007767631d36aa  pop rax
00007767631d36ab  add rsp, 0x08
00007767631d36af  jmp 0x00007767631CFF19
00007767631d36b4  sub rsp, 0x08
00007767631d36b8  push rax
00007767631d36b9  push rcx
00007767631d36ba  push rdx
00007767631d36bb  push rdi
00007767631d36bc  push rsi
00007767631d36bd  push r8
00007767631d36bf  push r9
00007767631d36c1  push r10
00007767631d36c3  push r11
00007767631d36c5  sub rsp, 0xF0
00007767631d36cc  vmovaps [rsp], xmm0
00007767631d36d1  vmovaps [rsp+0x10], xmm1
00007767631d36d7  vmovaps [rsp+0x20], xmm2
00007767631d36dd  vmovaps [rsp+0x30], xmm3
00007767631d36e3  vmovaps [rsp+0x40], xmm4
00007767631d36e9  vmovaps [rsp+0x50], xmm5
00007767631d36ef  vmovaps [rsp+0x60], xmm6
00007767631d36f5  vmovaps [rsp+0x70], xmm7
00007767631d36fb  vmovaps [rsp+0x80], xmm8
00007767631d3704  vmovaps [rsp+0x90], xmm9
00007767631d370d  vmovaps [rsp+0xA0], xmm10
00007767631d3716  vmovaps [rsp+0xB0], xmm11
00007767631d371f  vmovaps [rsp+0xC0], xmm13
00007767631d3728  vmovaps [rsp+0xD0], xmm14
00007767631d3731  vmovaps [rsp+0xE0], xmm15
00007767631d373a  sub rsp, 0x30
00007767631d373e  movaps [rsp], xmm12
00007767631d3743  movaps [rsp+0x10], xmm15
00007767631d3749  movaps [rsp+0x20], xmm13
00007767631d374f  lea rdi, [rsp]
00007767631d3753  mov esi, 0x00
00007767631d3758  mov rax, 0x617961CDB530
00007767631d3762  call rax
00007767631d3764  movaps xmm12, [rsp]
00007767631d3769  add rsp, 0x30
00007767631d376d  vmovaps xmm0, [rsp]
00007767631d3772  vmovaps xmm1, [rsp+0x10]
00007767631d3778  vmovaps xmm2, [rsp+0x20]
00007767631d377e  vmovaps xmm3, [rsp+0x30]
00007767631d3784  vmovaps xmm4, [rsp+0x40]
00007767631d378a  vmovaps xmm5, [rsp+0x50]
00007767631d3790  vmovaps xmm6, [rsp+0x60]
00007767631d3796  vmovaps xmm7, [rsp+0x70]
00007767631d379c  vmovaps xmm8, [rsp+0x80]
00007767631d37a5  vmovaps xmm9, [rsp+0x90]
00007767631d37ae  vmovaps xmm10, [rsp+0xA0]
00007767631d37b7  vmovaps xmm11, [rsp+0xB0]
00007767631d37c0  vmovaps xmm13, [rsp+0xC0]
00007767631d37c9  vmovaps xmm14, [rsp+0xD0]
00007767631d37d2  vmovaps xmm15, [rsp+0xE0]
00007767631d37db  add rsp, 0xF0
00007767631d37e2  pop r11
00007767631d37e4  pop r10
00007767631d37e6  pop r9
00007767631d37e8  pop r8
00007767631d37ea  pop rsi
00007767631d37eb  pop rdi
00007767631d37ec  pop rdx
00007767631d37ed  pop rcx
00007767631d37ee  pop rax
00007767631d37ef  add rsp, 0x08
00007767631d37f3  jmp 0x00007767631CFF34
00007767631d37f8  sub rsp, 0x08
00007767631d37fc  push rax
00007767631d37fd  push rcx
00007767631d37fe  push rdx
00007767631d37ff  push rdi
00007767631d3800  push rsi
00007767631d3801  push r8
00007767631d3803  push r9
00007767631d3805  push r10
00007767631d3807  push r11
00007767631d3809  sub rsp, 0xF0
00007767631d3810  vmovaps [rsp], xmm0
00007767631d3815  vmovaps [rsp+0x10], xmm1
00007767631d381b  vmovaps [rsp+0x20], xmm2
00007767631d3821  vmovaps [rsp+0x30], xmm3
00007767631d3827  vmovaps [rsp+0x40], xmm4
00007767631d382d  vmovaps [rsp+0x50], xmm5
00007767631d3833  vmovaps [rsp+0x60], xmm6
00007767631d3839  vmovaps [rsp+0x70], xmm7
00007767631d383f  vmovaps [rsp+0x80], xmm8
00007767631d3848  vmovaps [rsp+0x90], xmm9
00007767631d3851  vmovaps [rsp+0xA0], xmm10
00007767631d385a  vmovaps [rsp+0xB0], xmm11
00007767631d3863  vmovaps [rsp+0xC0], xmm12
00007767631d386c  vmovaps [rsp+0xD0], xmm13
00007767631d3875  vmovaps [rsp+0xE0], xmm14
00007767631d387e  sub rsp, 0x30
00007767631d3882  movaps [rsp], xmm15
00007767631d3887  movaps [rsp+0x10], xmm13
00007767631d388d  movaps [rsp+0x20], xmm10
00007767631d3893  lea rdi, [rsp]
00007767631d3897  mov esi, 0x00
00007767631d389c  mov rax, 0x617961CDB530
00007767631d38a6  call rax
00007767631d38a8  movaps xmm15, [rsp]
00007767631d38ad  add rsp, 0x30
00007767631d38b1  vmovaps xmm0, [rsp]
00007767631d38b6  vmovaps xmm1, [rsp+0x10]
00007767631d38bc  vmovaps xmm2, [rsp+0x20]
00007767631d38c2  vmovaps xmm3, [rsp+0x30]
00007767631d38c8  vmovaps xmm4, [rsp+0x40]
00007767631d38ce  vmovaps xmm5, [rsp+0x50]
00007767631d38d4  vmovaps xmm6, [rsp+0x60]
00007767631d38da  vmovaps xmm7, [rsp+0x70]
00007767631d38e0  vmovaps xmm8, [rsp+0x80]
00007767631d38e9  vmovaps xmm9, [rsp+0x90]
00007767631d38f2  vmovaps xmm10, [rsp+0xA0]
00007767631d38fb  vmovaps xmm11, [rsp+0xB0]
00007767631d3904  vmovaps xmm12, [rsp+0xC0]
00007767631d390d  vmovaps xmm13, [rsp+0xD0]
00007767631d3916  vmovaps xmm14, [rsp+0xE0]
00007767631d391f  add rsp, 0xF0
00007767631d3926  pop r11
00007767631d3928  pop r10
00007767631d392a  pop r9
00007767631d392c  pop r8
00007767631d392e  pop rsi
00007767631d392f  pop rdi
00007767631d3930  pop rdx
00007767631d3931  pop rcx
00007767631d3932  pop rax
00007767631d3933  add rsp, 0x08
00007767631d3937  jmp 0x00007767631CFF55
00007767631d393c  call 0x000077676300C260
00007767631d3941  jmp 0x00007767631CFFB0
00007767631d3946  sub rsp, 0x08
00007767631d394a  push rax
00007767631d394b  push rcx
00007767631d394c  push rdx
00007767631d394d  push rdi
00007767631d394e  push rsi
00007767631d394f  push r8
00007767631d3951  push r9
00007767631d3953  push r10
00007767631d3955  push r11
00007767631d3957  sub rsp, 0xF0
00007767631d395e  vmovaps [rsp], xmm0
00007767631d3963  vmovaps [rsp+0x10], xmm1
00007767631d3969  vmovaps [rsp+0x20], xmm2
00007767631d396f  vmovaps [rsp+0x30], xmm3
00007767631d3975  vmovaps [rsp+0x40], xmm4
00007767631d397b  vmovaps [rsp+0x50], xmm5
00007767631d3981  vmovaps [rsp+0x60], xmm6
00007767631d3987  vmovaps [rsp+0x70], xmm7
00007767631d398d  vmovaps [rsp+0x80], xmm8
00007767631d3996  vmovaps [rsp+0x90], xmm10
00007767631d399f  vmovaps [rsp+0xA0], xmm11
00007767631d39a8  vmovaps [rsp+0xB0], xmm12
00007767631d39b1  vmovaps [rsp+0xC0], xmm13
00007767631d39ba  vmovaps [rsp+0xD0], xmm14
00007767631d39c3  vmovaps [rsp+0xE0], xmm15
00007767631d39cc  sub rsp, 0x30
00007767631d39d0  movaps [rsp], xmm9
00007767631d39d5  movaps [rsp+0x10], xmm8
00007767631d39db  movaps [rsp+0x20], xmm10
00007767631d39e1  lea rdi, [rsp]
00007767631d39e5  mov esi, 0x00
00007767631d39ea  mov rax, 0x617961CDB530
00007767631d39f4  call rax
00007767631d39f6  movaps xmm9, [rsp]
00007767631d39fb  add rsp, 0x30
00007767631d39ff  vmovaps xmm0, [rsp]
00007767631d3a04  vmovaps xmm1, [rsp+0x10]
00007767631d3a0a  vmovaps xmm2, [rsp+0x20]
00007767631d3a10  vmovaps xmm3, [rsp+0x30]
00007767631d3a16  vmovaps xmm4, [rsp+0x40]
00007767631d3a1c  vmovaps xmm5, [rsp+0x50]
00007767631d3a22  vmovaps xmm6, [rsp+0x60]
00007767631d3a28  vmovaps xmm7, [rsp+0x70]
00007767631d3a2e  vmovaps xmm8, [rsp+0x80]
00007767631d3a37  vmovaps xmm10, [rsp+0x90]
00007767631d3a40  vmovaps xmm11, [rsp+0xA0]
00007767631d3a49  vmovaps xmm12, [rsp+0xB0]
00007767631d3a52  vmovaps xmm13, [rsp+0xC0]
00007767631d3a5b  vmovaps xmm14, [rsp+0xD0]
00007767631d3a64  vmovaps xmm15, [rsp+0xE0]
00007767631d3a6d  add rsp, 0xF0
00007767631d3a74  pop r11
00007767631d3a76  pop r10
00007767631d3a78  pop r9
00007767631d3a7a  pop r8
00007767631d3a7c  pop rsi
00007767631d3a7d  pop rdi
00007767631d3a7e  pop rdx
00007767631d3a7f  pop rcx
00007767631d3a80  pop rax
00007767631d3a81  add rsp, 0x08
00007767631d3a85  jmp 0x00007767631CFFE1
00007767631d3a8a  sub rsp, 0x08
00007767631d3a8e  push rax
00007767631d3a8f  push rcx
00007767631d3a90  push rdx
00007767631d3a91  push rdi
00007767631d3a92  push rsi
00007767631d3a93  push r8
00007767631d3a95  push r9
00007767631d3a97  push r10
00007767631d3a99  push r11
00007767631d3a9b  sub rsp, 0xF0
00007767631d3aa2  vmovaps [rsp], xmm0
00007767631d3aa7  vmovaps [rsp+0x10], xmm1
00007767631d3aad  vmovaps [rsp+0x20], xmm2
00007767631d3ab3  vmovaps [rsp+0x30], xmm3
00007767631d3ab9  vmovaps [rsp+0x40], xmm4
00007767631d3abf  vmovaps [rsp+0x50], xmm5
00007767631d3ac5  vmovaps [rsp+0x60], xmm6
00007767631d3acb  vmovaps [rsp+0x70], xmm7
00007767631d3ad1  vmovaps [rsp+0x80], xmm8
00007767631d3ada  vmovaps [rsp+0x90], xmm9
00007767631d3ae3  vmovaps [rsp+0xA0], xmm11
00007767631d3aec  vmovaps [rsp+0xB0], xmm12
00007767631d3af5  vmovaps [rsp+0xC0], xmm13
00007767631d3afe  vmovaps [rsp+0xD0], xmm14
00007767631d3b07  vmovaps [rsp+0xE0], xmm15
00007767631d3b10  sub rsp, 0x30
00007767631d3b14  movaps [rsp], xmm10
00007767631d3b19  movaps [rsp+0x10], xmm1
00007767631d3b1e  movaps [rsp+0x20], xmm11
00007767631d3b24  lea rdi, [rsp]
00007767631d3b28  mov esi, 0x00
00007767631d3b2d  mov rax, 0x617961CDB530
00007767631d3b37  call rax
00007767631d3b39  movaps xmm10, [rsp]
00007767631d3b3e  add rsp, 0x30
00007767631d3b42  vmovaps xmm0, [rsp]
00007767631d3b47  vmovaps xmm1, [rsp+0x10]
00007767631d3b4d  vmovaps xmm2, [rsp+0x20]
00007767631d3b53  vmovaps xmm3, [rsp+0x30]
00007767631d3b59  vmovaps xmm4, [rsp+0x40]
00007767631d3b5f  vmovaps xmm5, [rsp+0x50]
00007767631d3b65  vmovaps xmm6, [rsp+0x60]
00007767631d3b6b  vmovaps xmm7, [rsp+0x70]
00007767631d3b71  vmovaps xmm8, [rsp+0x80]
00007767631d3b7a  vmovaps xmm9, [rsp+0x90]
00007767631d3b83  vmovaps xmm11, [rsp+0xA0]
00007767631d3b8c  vmovaps xmm12, [rsp+0xB0]
00007767631d3b95  vmovaps xmm13, [rsp+0xC0]
00007767631d3b9e  vmovaps xmm14, [rsp+0xD0]
00007767631d3ba7  vmovaps xmm15, [rsp+0xE0]
00007767631d3bb0  add rsp, 0xF0
00007767631d3bb7  pop r11
00007767631d3bb9  pop r10
00007767631d3bbb  pop r9
00007767631d3bbd  pop r8
00007767631d3bbf  pop rsi
00007767631d3bc0  pop rdi
00007767631d3bc1  pop rdx
00007767631d3bc2  pop rcx
00007767631d3bc3  pop rax
00007767631d3bc4  add rsp, 0x08
00007767631d3bc8  jmp 0x00007767631CFFFC
00007767631d3bcd  sub rsp, 0x08
00007767631d3bd1  push rax
00007767631d3bd2  push rcx
00007767631d3bd3  push rdx
00007767631d3bd4  push rdi
00007767631d3bd5  push rsi
00007767631d3bd6  push r8
00007767631d3bd8  push r9
00007767631d3bda  push r10
00007767631d3bdc  push r11
00007767631d3bde  sub rsp, 0xF0
00007767631d3be5  vmovaps [rsp], xmm0
00007767631d3bea  vmovaps [rsp+0x10], xmm2
00007767631d3bf0  vmovaps [rsp+0x20], xmm3
00007767631d3bf6  vmovaps [rsp+0x30], xmm4
00007767631d3bfc  vmovaps [rsp+0x40], xmm5
00007767631d3c02  vmovaps [rsp+0x50], xmm6
00007767631d3c08  vmovaps [rsp+0x60], xmm7
00007767631d3c0e  vmovaps [rsp+0x70], xmm8
00007767631d3c14  vmovaps [rsp+0x80], xmm9
00007767631d3c1d  vmovaps [rsp+0x90], xmm10
00007767631d3c26  vmovaps [rsp+0xA0], xmm11
00007767631d3c2f  vmovaps [rsp+0xB0], xmm12
00007767631d3c38  vmovaps [rsp+0xC0], xmm13
00007767631d3c41  vmovaps [rsp+0xD0], xmm14
00007767631d3c4a  vmovaps [rsp+0xE0], xmm15
00007767631d3c53  sub rsp, 0x30
00007767631d3c57  movaps [rsp], xmm1
00007767631d3c5b  movaps [rsp+0x10], xmm14
00007767631d3c61  movaps [rsp+0x20], xmm6
00007767631d3c66  lea rdi, [rsp]
00007767631d3c6a  mov esi, 0x00
00007767631d3c6f  mov rax, 0x617961CDB530
00007767631d3c79  call rax
00007767631d3c7b  movaps xmm1, [rsp]
00007767631d3c7f  add rsp, 0x30
00007767631d3c83  vmovaps xmm0, [rsp]
00007767631d3c88  vmovaps xmm2, [rsp+0x10]
00007767631d3c8e  vmovaps xmm3, [rsp+0x20]
00007767631d3c94  vmovaps xmm4, [rsp+0x30]
00007767631d3c9a  vmovaps xmm5, [rsp+0x40]
00007767631d3ca0  vmovaps xmm6, [rsp+0x50]
00007767631d3ca6  vmovaps xmm7, [rsp+0x60]
00007767631d3cac  vmovaps xmm8, [rsp+0x70]
00007767631d3cb2  vmovaps xmm9, [rsp+0x80]
00007767631d3cbb  vmovaps xmm10, [rsp+0x90]
00007767631d3cc4  vmovaps xmm11, [rsp+0xA0]
00007767631d3ccd  vmovaps xmm12, [rsp+0xB0]
00007767631d3cd6  vmovaps xmm13, [rsp+0xC0]
00007767631d3cdf  vmovaps xmm14, [rsp+0xD0]
00007767631d3ce8  vmovaps xmm15, [rsp+0xE0]
00007767631d3cf1  add rsp, 0xF0
00007767631d3cf8  pop r11
00007767631d3cfa  pop r10
00007767631d3cfc  pop r9
00007767631d3cfe  pop r8
00007767631d3d00  pop rsi
00007767631d3d01  pop rdi
00007767631d3d02  pop rdx
00007767631d3d03  pop rcx
00007767631d3d04  pop rax
00007767631d3d05  add rsp, 0x08
00007767631d3d09  jmp 0x00007767631D0015
00007767631d3d0e  sub rsp, 0x08
00007767631d3d12  push rax
00007767631d3d13  push rcx
00007767631d3d14  push rdx
00007767631d3d15  push rdi
00007767631d3d16  push rsi
00007767631d3d17  push r8
00007767631d3d19  push r9
00007767631d3d1b  push r10
00007767631d3d1d  push r11
00007767631d3d1f  sub rsp, 0xF0
00007767631d3d26  vmovaps [rsp], xmm0
00007767631d3d2b  vmovaps [rsp+0x10], xmm1
00007767631d3d31  vmovaps [rsp+0x20], xmm2
00007767631d3d37  vmovaps [rsp+0x30], xmm3
00007767631d3d3d  vmovaps [rsp+0x40], xmm4
00007767631d3d43  vmovaps [rsp+0x50], xmm5
00007767631d3d49  vmovaps [rsp+0x60], xmm6
00007767631d3d4f  vmovaps [rsp+0x70], xmm7
00007767631d3d55  vmovaps [rsp+0x80], xmm8
00007767631d3d5e  vmovaps [rsp+0x90], xmm9
00007767631d3d67  vmovaps [rsp+0xA0], xmm10
00007767631d3d70  vmovaps [rsp+0xB0], xmm12
00007767631d3d79  vmovaps [rsp+0xC0], xmm13
00007767631d3d82  vmovaps [rsp+0xD0], xmm14
00007767631d3d8b  vmovaps [rsp+0xE0], xmm15
00007767631d3d94  sub rsp, 0x30
00007767631d3d98  movaps [rsp], xmm11
00007767631d3d9d  movaps [rsp+0x10], xmm13
00007767631d3da3  movaps [rsp+0x20], xmm14
00007767631d3da9  lea rdi, [rsp]
00007767631d3dad  mov esi, 0x00
00007767631d3db2  mov rax, 0x617961CDB530
00007767631d3dbc  call rax
00007767631d3dbe  movaps xmm11, [rsp]
00007767631d3dc3  add rsp, 0x30
00007767631d3dc7  vmovaps xmm0, [rsp]
00007767631d3dcc  vmovaps xmm1, [rsp+0x10]
00007767631d3dd2  vmovaps xmm2, [rsp+0x20]
00007767631d3dd8  vmovaps xmm3, [rsp+0x30]
00007767631d3dde  vmovaps xmm4, [rsp+0x40]
00007767631d3de4  vmovaps xmm5, [rsp+0x50]
00007767631d3dea  vmovaps xmm6, [rsp+0x60]
00007767631d3df0  vmovaps xmm7, [rsp+0x70]
00007767631d3df6  vmovaps xmm8, [rsp+0x80]
00007767631d3dff  vmovaps xmm9, [rsp+0x90]
00007767631d3e08  vmovaps xmm10, [rsp+0xA0]
00007767631d3e11  vmovaps xmm12, [rsp+0xB0]
00007767631d3e1a  vmovaps xmm13, [rsp+0xC0]
00007767631d3e23  vmovaps xmm14, [rsp+0xD0]
00007767631d3e2c  vmovaps xmm15, [rsp+0xE0]
00007767631d3e35  add rsp, 0xF0
00007767631d3e3c  pop r11
00007767631d3e3e  pop r10
00007767631d3e40  pop r9
00007767631d3e42  pop r8
00007767631d3e44  pop rsi
00007767631d3e45  pop rdi
00007767631d3e46  pop rdx
00007767631d3e47  pop rcx
00007767631d3e48  pop rax
00007767631d3e49  add rsp, 0x08
00007767631d3e4d  jmp 0x00007767631D003F
00007767631d3e52  sub rsp, 0x08
00007767631d3e56  push rax
00007767631d3e57  push rcx
00007767631d3e58  push rdx
00007767631d3e59  push rdi
00007767631d3e5a  push rsi
00007767631d3e5b  push r8
00007767631d3e5d  push r9
00007767631d3e5f  push r10
00007767631d3e61  push r11
00007767631d3e63  sub rsp, 0xF0
00007767631d3e6a  vmovaps [rsp], xmm0
00007767631d3e6f  vmovaps [rsp+0x10], xmm1
00007767631d3e75  vmovaps [rsp+0x20], xmm2
00007767631d3e7b  vmovaps [rsp+0x30], xmm3
00007767631d3e81  vmovaps [rsp+0x40], xmm4
00007767631d3e87  vmovaps [rsp+0x50], xmm5
00007767631d3e8d  vmovaps [rsp+0x60], xmm6
00007767631d3e93  vmovaps [rsp+0x70], xmm7
00007767631d3e99  vmovaps [rsp+0x80], xmm8
00007767631d3ea2  vmovaps [rsp+0x90], xmm9
00007767631d3eab  vmovaps [rsp+0xA0], xmm10
00007767631d3eb4  vmovaps [rsp+0xB0], xmm11
00007767631d3ebd  vmovaps [rsp+0xC0], xmm12
00007767631d3ec6  vmovaps [rsp+0xD0], xmm14
00007767631d3ecf  vmovaps [rsp+0xE0], xmm15
00007767631d3ed8  sub rsp, 0x30
00007767631d3edc  movaps [rsp], xmm13
00007767631d3ee1  movaps [rsp+0x10], xmm8
00007767631d3ee7  movaps [rsp+0x20], xmm14
00007767631d3eed  lea rdi, [rsp]
00007767631d3ef1  mov esi, 0x00
00007767631d3ef6  mov rax, 0x617961CDB530
00007767631d3f00  call rax
00007767631d3f02  movaps xmm13, [rsp]
00007767631d3f07  add rsp, 0x30
00007767631d3f0b  vmovaps xmm0, [rsp]
00007767631d3f10  vmovaps xmm1, [rsp+0x10]
00007767631d3f16  vmovaps xmm2, [rsp+0x20]
00007767631d3f1c  vmovaps xmm3, [rsp+0x30]
00007767631d3f22  vmovaps xmm4, [rsp+0x40]
00007767631d3f28  vmovaps xmm5, [rsp+0x50]
00007767631d3f2e  vmovaps xmm6, [rsp+0x60]
00007767631d3f34  vmovaps xmm7, [rsp+0x70]
00007767631d3f3a  vmovaps xmm8, [rsp+0x80]
00007767631d3f43  vmovaps xmm9, [rsp+0x90]
00007767631d3f4c  vmovaps xmm10, [rsp+0xA0]
00007767631d3f55  vmovaps xmm11, [rsp+0xB0]
00007767631d3f5e  vmovaps xmm12, [rsp+0xC0]
00007767631d3f67  vmovaps xmm14, [rsp+0xD0]
00007767631d3f70  vmovaps xmm15, [rsp+0xE0]
00007767631d3f79  add rsp, 0xF0
00007767631d3f80  pop r11
00007767631d3f82  pop r10
00007767631d3f84  pop r9
00007767631d3f86  pop r8
00007767631d3f88  pop rsi
00007767631d3f89  pop rdi
00007767631d3f8a  pop rdx
00007767631d3f8b  pop rcx
00007767631d3f8c  pop rax
00007767631d3f8d  add rsp, 0x08
00007767631d3f91  jmp 0x00007767631D006E
00007767631d3f96  sub rsp, 0x08
00007767631d3f9a  push rax
00007767631d3f9b  push rcx
00007767631d3f9c  push rdx
00007767631d3f9d  push rdi
00007767631d3f9e  push rsi
00007767631d3f9f  push r8
00007767631d3fa1  push r9
00007767631d3fa3  push r10
00007767631d3fa5  push r11
00007767631d3fa7  sub rsp, 0xF0
00007767631d3fae  vmovaps [rsp], xmm0
00007767631d3fb3  vmovaps [rsp+0x10], xmm1
00007767631d3fb9  vmovaps [rsp+0x20], xmm2
00007767631d3fbf  vmovaps [rsp+0x30], xmm3
00007767631d3fc5  vmovaps [rsp+0x40], xmm4
00007767631d3fcb  vmovaps [rsp+0x50], xmm5
00007767631d3fd1  vmovaps [rsp+0x60], xmm6
00007767631d3fd7  vmovaps [rsp+0x70], xmm7
00007767631d3fdd  vmovaps [rsp+0x80], xmm9
00007767631d3fe6  vmovaps [rsp+0x90], xmm10
00007767631d3fef  vmovaps [rsp+0xA0], xmm11
00007767631d3ff8  vmovaps [rsp+0xB0], xmm12
00007767631d4001  vmovaps [rsp+0xC0], xmm13
00007767631d400a  vmovaps [rsp+0xD0], xmm14
00007767631d4013  vmovaps [rsp+0xE0], xmm15
00007767631d401c  sub rsp, 0x30
00007767631d4020  movaps [rsp], xmm8
00007767631d4025  movaps [rsp+0x10], xmm7
00007767631d402a  movaps [rsp+0x20], xmm14
00007767631d4030  lea rdi, [rsp]
00007767631d4034  mov esi, 0x00
00007767631d4039  mov rax, 0x617961CDB530
00007767631d4043  call rax
00007767631d4045  movaps xmm8, [rsp]
00007767631d404a  add rsp, 0x30
00007767631d404e  vmovaps xmm0, [rsp]
00007767631d4053  vmovaps xmm1, [rsp+0x10]
00007767631d4059  vmovaps xmm2, [rsp+0x20]
00007767631d405f  vmovaps xmm3, [rsp+0x30]
00007767631d4065  vmovaps xmm4, [rsp+0x40]
00007767631d406b  vmovaps xmm5, [rsp+0x50]
00007767631d4071  vmovaps xmm6, [rsp+0x60]
00007767631d4077  vmovaps xmm7, [rsp+0x70]
00007767631d407d  vmovaps xmm9, [rsp+0x80]
00007767631d4086  vmovaps xmm10, [rsp+0x90]
00007767631d408f  vmovaps xmm11, [rsp+0xA0]
00007767631d4098  vmovaps xmm12, [rsp+0xB0]
00007767631d40a1  vmovaps xmm13, [rsp+0xC0]
00007767631d40aa  vmovaps xmm14, [rsp+0xD0]
00007767631d40b3  vmovaps xmm15, [rsp+0xE0]
00007767631d40bc  add rsp, 0xF0
00007767631d40c3  pop r11
00007767631d40c5  pop r10
00007767631d40c7  pop r9
00007767631d40c9  pop r8
00007767631d40cb  pop rsi
00007767631d40cc  pop rdi
00007767631d40cd  pop rdx
00007767631d40ce  pop rcx
00007767631d40cf  pop rax
00007767631d40d0  add rsp, 0x08
00007767631d40d4  jmp 0x00007767631D0094
00007767631d40d9  sub rsp, 0x08
00007767631d40dd  push rax
00007767631d40de  push rcx
00007767631d40df  push rdx
00007767631d40e0  push rdi
00007767631d40e1  push rsi
00007767631d40e2  push r8
00007767631d40e4  push r9
00007767631d40e6  push r10
00007767631d40e8  push r11
00007767631d40ea  sub rsp, 0xF0
00007767631d40f1  vmovaps [rsp], xmm0
00007767631d40f6  vmovaps [rsp+0x10], xmm1
00007767631d40fc  vmovaps [rsp+0x20], xmm2
00007767631d4102  vmovaps [rsp+0x30], xmm3
00007767631d4108  vmovaps [rsp+0x40], xmm4
00007767631d410e  vmovaps [rsp+0x50], xmm5
00007767631d4114  vmovaps [rsp+0x60], xmm6
00007767631d411a  vmovaps [rsp+0x70], xmm7
00007767631d4120  vmovaps [rsp+0x80], xmm8
00007767631d4129  vmovaps [rsp+0x90], xmm9
00007767631d4132  vmovaps [rsp+0xA0], xmm10
00007767631d413b  vmovaps [rsp+0xB0], xmm11
00007767631d4144  vmovaps [rsp+0xC0], xmm12
00007767631d414d  vmovaps [rsp+0xD0], xmm13
00007767631d4156  vmovaps [rsp+0xE0], xmm15
00007767631d415f  sub rsp, 0x30
00007767631d4163  movaps [rsp], xmm14
00007767631d4168  movaps [rsp+0x10], xmm12
00007767631d416e  movaps [rsp+0x20], xmm9
00007767631d4174  lea rdi, [rsp]
00007767631d4178  mov esi, 0x00
00007767631d417d  mov rax, 0x617961CDB530
00007767631d4187  call rax
00007767631d4189  movaps xmm14, [rsp]
00007767631d418e  add rsp, 0x30
00007767631d4192  vmovaps xmm0, [rsp]
00007767631d4197  vmovaps xmm1, [rsp+0x10]
00007767631d419d  vmovaps xmm2, [rsp+0x20]
00007767631d41a3  vmovaps xmm3, [rsp+0x30]
00007767631d41a9  vmovaps xmm4, [rsp+0x40]
00007767631d41af  vmovaps xmm5, [rsp+0x50]
00007767631d41b5  vmovaps xmm6, [rsp+0x60]
00007767631d41bb  vmovaps xmm7, [rsp+0x70]
00007767631d41c1  vmovaps xmm8, [rsp+0x80]
00007767631d41ca  vmovaps xmm9, [rsp+0x90]
00007767631d41d3  vmovaps xmm10, [rsp+0xA0]
00007767631d41dc  vmovaps xmm11, [rsp+0xB0]
00007767631d41e5  vmovaps xmm12, [rsp+0xC0]
00007767631d41ee  vmovaps xmm13, [rsp+0xD0]
00007767631d41f7  vmovaps xmm15, [rsp+0xE0]
00007767631d4200  add rsp, 0xF0
00007767631d4207  pop r11
00007767631d4209  pop r10
00007767631d420b  pop r9
00007767631d420d  pop r8
00007767631d420f  pop rsi
00007767631d4210  pop rdi
00007767631d4211  pop rdx
00007767631d4212  pop rcx
00007767631d4213  pop rax
00007767631d4214  add rsp, 0x08
00007767631d4218  jmp 0x00007767631D00AE
00007767631d421d  sub rsp, 0x08
00007767631d4221  push rax
00007767631d4222  push rcx
00007767631d4223  push rdx
00007767631d4224  push rdi
00007767631d4225  push rsi
00007767631d4226  push r8
00007767631d4228  push r9
00007767631d422a  push r10
00007767631d422c  push r11
00007767631d422e  sub rsp, 0xF0
00007767631d4235  vmovaps [rsp], xmm0
00007767631d423a  vmovaps [rsp+0x10], xmm1
00007767631d4240  vmovaps [rsp+0x20], xmm2
00007767631d4246  vmovaps [rsp+0x30], xmm3
00007767631d424c  vmovaps [rsp+0x40], xmm4
00007767631d4252  vmovaps [rsp+0x50], xmm5
00007767631d4258  vmovaps [rsp+0x60], xmm6
00007767631d425e  vmovaps [rsp+0x70], xmm7
00007767631d4264  vmovaps [rsp+0x80], xmm8
00007767631d426d  vmovaps [rsp+0x90], xmm10
00007767631d4276  vmovaps [rsp+0xA0], xmm11
00007767631d427f  vmovaps [rsp+0xB0], xmm12
00007767631d4288  vmovaps [rsp+0xC0], xmm13
00007767631d4291  vmovaps [rsp+0xD0], xmm14
00007767631d429a  vmovaps [rsp+0xE0], xmm15
00007767631d42a3  sub rsp, 0x30
00007767631d42a7  movaps [rsp], xmm9
00007767631d42ac  movaps [rsp+0x10], xmm7
00007767631d42b1  movaps [rsp+0x20], xmm12
00007767631d42b7  lea rdi, [rsp]
00007767631d42bb  mov esi, 0x00
00007767631d42c0  mov rax, 0x617961CDB530
00007767631d42ca  call rax
00007767631d42cc  movaps xmm9, [rsp]
00007767631d42d1  add rsp, 0x30
00007767631d42d5  vmovaps xmm0, [rsp]
00007767631d42da  vmovaps xmm1, [rsp+0x10]
00007767631d42e0  vmovaps xmm2, [rsp+0x20]
00007767631d42e6  vmovaps xmm3, [rsp+0x30]
00007767631d42ec  vmovaps xmm4, [rsp+0x40]
00007767631d42f2  vmovaps xmm5, [rsp+0x50]
00007767631d42f8  vmovaps xmm6, [rsp+0x60]
00007767631d42fe  vmovaps xmm7, [rsp+0x70]
00007767631d4304  vmovaps xmm8, [rsp+0x80]
00007767631d430d  vmovaps xmm10, [rsp+0x90]
00007767631d4316  vmovaps xmm11, [rsp+0xA0]
00007767631d431f  vmovaps xmm12, [rsp+0xB0]
00007767631d4328  vmovaps xmm13, [rsp+0xC0]
00007767631d4331  vmovaps xmm14, [rsp+0xD0]
00007767631d433a  vmovaps xmm15, [rsp+0xE0]
00007767631d4343  add rsp, 0xF0
00007767631d434a  pop r11
00007767631d434c  pop r10
00007767631d434e  pop r9
00007767631d4350  pop r8
00007767631d4352  pop rsi
00007767631d4353  pop rdi
00007767631d4354  pop rdx
00007767631d4355  pop rcx
00007767631d4356  pop rax
00007767631d4357  add rsp, 0x08
00007767631d435b  jmp 0x00007767631D00DD
00007767631d4360  sub rsp, 0x08
00007767631d4364  push rax
00007767631d4365  push rcx
00007767631d4366  push rdx
00007767631d4367  push rdi
00007767631d4368  push rsi
00007767631d4369  push r8
00007767631d436b  push r9
00007767631d436d  push r10
00007767631d436f  push r11
00007767631d4371  sub rsp, 0xF0
00007767631d4378  vmovaps [rsp], xmm0
00007767631d437d  vmovaps [rsp+0x10], xmm1
00007767631d4383  vmovaps [rsp+0x20], xmm2
00007767631d4389  vmovaps [rsp+0x30], xmm3
00007767631d438f  vmovaps [rsp+0x40], xmm4
00007767631d4395  vmovaps [rsp+0x50], xmm5
00007767631d439b  vmovaps [rsp+0x60], xmm6
00007767631d43a1  vmovaps [rsp+0x70], xmm7
00007767631d43a7  vmovaps [rsp+0x80], xmm8
00007767631d43b0  vmovaps [rsp+0x90], xmm9
00007767631d43b9  vmovaps [rsp+0xA0], xmm10
00007767631d43c2  vmovaps [rsp+0xB0], xmm11
00007767631d43cb  vmovaps [rsp+0xC0], xmm13
00007767631d43d4  vmovaps [rsp+0xD0], xmm14
00007767631d43dd  vmovaps [rsp+0xE0], xmm15
00007767631d43e6  sub rsp, 0x30
00007767631d43ea  movaps [rsp], xmm12
00007767631d43ef  movaps [rsp+0x10], xmm15
00007767631d43f5  movaps [rsp+0x20], xmm11
00007767631d43fb  lea rdi, [rsp]
00007767631d43ff  mov esi, 0x00
00007767631d4404  mov rax, 0x617961CDB530
00007767631d440e  call rax
00007767631d4410  movaps xmm12, [rsp]
00007767631d4415  add rsp, 0x30
00007767631d4419  vmovaps xmm0, [rsp]
00007767631d441e  vmovaps xmm1, [rsp+0x10]
00007767631d4424  vmovaps xmm2, [rsp+0x20]
00007767631d442a  vmovaps xmm3, [rsp+0x30]
00007767631d4430  vmovaps xmm4, [rsp+0x40]
00007767631d4436  vmovaps xmm5, [rsp+0x50]
00007767631d443c  vmovaps xmm6, [rsp+0x60]
00007767631d4442  vmovaps xmm7, [rsp+0x70]
00007767631d4448  vmovaps xmm8, [rsp+0x80]
00007767631d4451  vmovaps xmm9, [rsp+0x90]
00007767631d445a  vmovaps xmm10, [rsp+0xA0]
00007767631d4463  vmovaps xmm11, [rsp+0xB0]
00007767631d446c  vmovaps xmm13, [rsp+0xC0]
00007767631d4475  vmovaps xmm14, [rsp+0xD0]
00007767631d447e  vmovaps xmm15, [rsp+0xE0]
00007767631d4487  add rsp, 0xF0
00007767631d448e  pop r11
00007767631d4490  pop r10
00007767631d4492  pop r9
00007767631d4494  pop r8
00007767631d4496  pop rsi
00007767631d4497  pop rdi
00007767631d4498  pop rdx
00007767631d4499  pop rcx
00007767631d449a  pop rax
00007767631d449b  add rsp, 0x08
00007767631d449f  jmp 0x00007767631D00F7
00007767631d44a4  sub rsp, 0x08
00007767631d44a8  push rax
00007767631d44a9  push rcx
00007767631d44aa  push rdx
00007767631d44ab  push rdi
00007767631d44ac  push rsi
00007767631d44ad  push r8
00007767631d44af  push r9
00007767631d44b1  push r10
00007767631d44b3  push r11
00007767631d44b5  sub rsp, 0xF0
00007767631d44bc  vmovaps [rsp], xmm0
00007767631d44c1  vmovaps [rsp+0x10], xmm1
00007767631d44c7  vmovaps [rsp+0x20], xmm2
00007767631d44cd  vmovaps [rsp+0x30], xmm3
00007767631d44d3  vmovaps [rsp+0x40], xmm4
00007767631d44d9  vmovaps [rsp+0x50], xmm5
00007767631d44df  vmovaps [rsp+0x60], xmm6
00007767631d44e5  vmovaps [rsp+0x70], xmm7
00007767631d44eb  vmovaps [rsp+0x80], xmm8
00007767631d44f4  vmovaps [rsp+0x90], xmm9
00007767631d44fd  vmovaps [rsp+0xA0], xmm10
00007767631d4506  vmovaps [rsp+0xB0], xmm12
00007767631d450f  vmovaps [rsp+0xC0], xmm13
00007767631d4518  vmovaps [rsp+0xD0], xmm14
00007767631d4521  vmovaps [rsp+0xE0], xmm15
00007767631d452a  sub rsp, 0x30
00007767631d452e  movaps [rsp], xmm11
00007767631d4533  movaps [rsp+0x10], xmm7
00007767631d4538  movaps [rsp+0x20], xmm15
00007767631d453e  lea rdi, [rsp]
00007767631d4542  mov esi, 0x00
00007767631d4547  mov rax, 0x617961CDB530
00007767631d4551  call rax
00007767631d4553  movaps xmm11, [rsp]
00007767631d4558  add rsp, 0x30
00007767631d455c  vmovaps xmm0, [rsp]
00007767631d4561  vmovaps xmm1, [rsp+0x10]
00007767631d4567  vmovaps xmm2, [rsp+0x20]
00007767631d456d  vmovaps xmm3, [rsp+0x30]
00007767631d4573  vmovaps xmm4, [rsp+0x40]
00007767631d4579  vmovaps xmm5, [rsp+0x50]
00007767631d457f  vmovaps xmm6, [rsp+0x60]
00007767631d4585  vmovaps xmm7, [rsp+0x70]
00007767631d458b  vmovaps xmm8, [rsp+0x80]
00007767631d4594  vmovaps xmm9, [rsp+0x90]
00007767631d459d  vmovaps xmm10, [rsp+0xA0]
00007767631d45a6  vmovaps xmm12, [rsp+0xB0]
00007767631d45af  vmovaps xmm13, [rsp+0xC0]
00007767631d45b8  vmovaps xmm14, [rsp+0xD0]
00007767631d45c1  vmovaps xmm15, [rsp+0xE0]
00007767631d45ca  add rsp, 0xF0
00007767631d45d1  pop r11
00007767631d45d3  pop r10
00007767631d45d5  pop r9
00007767631d45d7  pop r8
00007767631d45d9  pop rsi
00007767631d45da  pop rdi
00007767631d45db  pop rdx
00007767631d45dc  pop rcx
00007767631d45dd  pop rax
00007767631d45de  add rsp, 0x08
00007767631d45e2  jmp 0x00007767631D0123
00007767631d45e7  sub rsp, 0x08
00007767631d45eb  push rax
00007767631d45ec  push rcx
00007767631d45ed  push rdx
00007767631d45ee  push rdi
00007767631d45ef  push rsi
00007767631d45f0  push r8
00007767631d45f2  push r9
00007767631d45f4  push r10
00007767631d45f6  push r11
00007767631d45f8  sub rsp, 0xF0
00007767631d45ff  vmovaps [rsp], xmm0
00007767631d4604  vmovaps [rsp+0x10], xmm1
00007767631d460a  vmovaps [rsp+0x20], xmm2
00007767631d4610  vmovaps [rsp+0x30], xmm3
00007767631d4616  vmovaps [rsp+0x40], xmm4
00007767631d461c  vmovaps [rsp+0x50], xmm5
00007767631d4622  vmovaps [rsp+0x60], xmm6
00007767631d4628  vmovaps [rsp+0x70], xmm7
00007767631d462e  vmovaps [rsp+0x80], xmm8
00007767631d4637  vmovaps [rsp+0x90], xmm9
00007767631d4640  vmovaps [rsp+0xA0], xmm10
00007767631d4649  vmovaps [rsp+0xB0], xmm11
00007767631d4652  vmovaps [rsp+0xC0], xmm12
00007767631d465b  vmovaps [rsp+0xD0], xmm13
00007767631d4664  vmovaps [rsp+0xE0], xmm14
00007767631d466d  sub rsp, 0x30
00007767631d4671  movaps [rsp], xmm15
00007767631d4676  movaps [rsp+0x10], xmm10
00007767631d467c  movaps [rsp+0x20], xmm13
00007767631d4682  lea rdi, [rsp]
00007767631d4686  mov esi, 0x00
00007767631d468b  mov rax, 0x617961CDB530
00007767631d4695  call rax
00007767631d4697  movaps xmm15, [rsp]
00007767631d469c  add rsp, 0x30
00007767631d46a0  vmovaps xmm0, [rsp]
00007767631d46a5  vmovaps xmm1, [rsp+0x10]
00007767631d46ab  vmovaps xmm2, [rsp+0x20]
00007767631d46b1  vmovaps xmm3, [rsp+0x30]
00007767631d46b7  vmovaps xmm4, [rsp+0x40]
00007767631d46bd  vmovaps xmm5, [rsp+0x50]
00007767631d46c3  vmovaps xmm6, [rsp+0x60]
00007767631d46c9  vmovaps xmm7, [rsp+0x70]
00007767631d46cf  vmovaps xmm8, [rsp+0x80]
00007767631d46d8  vmovaps xmm9, [rsp+0x90]
00007767631d46e1  vmovaps xmm10, [rsp+0xA0]
00007767631d46ea  vmovaps xmm11, [rsp+0xB0]
00007767631d46f3  vmovaps xmm12, [rsp+0xC0]
00007767631d46fc  vmovaps xmm13, [rsp+0xD0]
00007767631d4705  vmovaps xmm14, [rsp+0xE0]
00007767631d470e  add rsp, 0xF0
00007767631d4715  pop r11
00007767631d4717  pop r10
00007767631d4719  pop r9
00007767631d471b  pop r8
00007767631d471d  pop rsi
00007767631d471e  pop rdi
00007767631d471f  pop rdx
00007767631d4720  pop rcx
00007767631d4721  pop rax
00007767631d4722  add rsp, 0x08
00007767631d4726  jmp 0x00007767631D013D
00007767631d472b  sub rsp, 0x08
00007767631d472f  push rax
00007767631d4730  push rcx
00007767631d4731  push rdx
00007767631d4732  push rdi
00007767631d4733  push rsi
00007767631d4734  push r8
00007767631d4736  push r9
00007767631d4738  push r10
00007767631d473a  push r11
00007767631d473c  sub rsp, 0xF0
00007767631d4743  vmovaps [rsp], xmm0
00007767631d4748  vmovaps [rsp+0x10], xmm1
00007767631d474e  vmovaps [rsp+0x20], xmm2
00007767631d4754  vmovaps [rsp+0x30], xmm3
00007767631d475a  vmovaps [rsp+0x40], xmm4
00007767631d4760  vmovaps [rsp+0x50], xmm5
00007767631d4766  vmovaps [rsp+0x60], xmm6
00007767631d476c  vmovaps [rsp+0x70], xmm7
00007767631d4772  vmovaps [rsp+0x80], xmm8
00007767631d477b  vmovaps [rsp+0x90], xmm9
00007767631d4784  vmovaps [rsp+0xA0], xmm11
00007767631d478d  vmovaps [rsp+0xB0], xmm12
00007767631d4796  vmovaps [rsp+0xC0], xmm13
00007767631d479f  vmovaps [rsp+0xD0], xmm14
00007767631d47a8  vmovaps [rsp+0xE0], xmm15
00007767631d47b1  sub rsp, 0x30
00007767631d47b5  movaps [rsp], xmm10
00007767631d47ba  movaps [rsp+0x10], xmm7
00007767631d47bf  movaps [rsp+0x20], xmm13
00007767631d47c5  lea rdi, [rsp]
00007767631d47c9  mov esi, 0x00
00007767631d47ce  mov rax, 0x617961CDB530
00007767631d47d8  call rax
00007767631d47da  movaps xmm10, [rsp]
00007767631d47df  add rsp, 0x30
00007767631d47e3  vmovaps xmm0, [rsp]
00007767631d47e8  vmovaps xmm1, [rsp+0x10]
00007767631d47ee  vmovaps xmm2, [rsp+0x20]
00007767631d47f4  vmovaps xmm3, [rsp+0x30]
00007767631d47fa  vmovaps xmm4, [rsp+0x40]
00007767631d4800  vmovaps xmm5, [rsp+0x50]
00007767631d4806  vmovaps xmm6, [rsp+0x60]
00007767631d480c  vmovaps xmm7, [rsp+0x70]
00007767631d4812  vmovaps xmm8, [rsp+0x80]
00007767631d481b  vmovaps xmm9, [rsp+0x90]
00007767631d4824  vmovaps xmm11, [rsp+0xA0]
00007767631d482d  vmovaps xmm12, [rsp+0xB0]
00007767631d4836  vmovaps xmm13, [rsp+0xC0]
00007767631d483f  vmovaps xmm14, [rsp+0xD0]
00007767631d4848  vmovaps xmm15, [rsp+0xE0]
00007767631d4851  add rsp, 0xF0
00007767631d4858  pop r11
00007767631d485a  pop r10
00007767631d485c  pop r9
00007767631d485e  pop r8
00007767631d4860  pop rsi
00007767631d4861  pop rdi
00007767631d4862  pop rdx
00007767631d4863  pop rcx
00007767631d4864  pop rax
00007767631d4865  add rsp, 0x08
00007767631d4869  jmp 0x00007767631D0169
00007767631d486e  sub rsp, 0x08
00007767631d4872  push rax
00007767631d4873  push rcx
00007767631d4874  push rdx
00007767631d4875  push rdi
00007767631d4876  push rsi
00007767631d4877  push r8
00007767631d4879  push r9
00007767631d487b  push r10
00007767631d487d  push r11
00007767631d487f  sub rsp, 0xF0
00007767631d4886  vmovaps [rsp], xmm0
00007767631d488b  vmovaps [rsp+0x10], xmm1
00007767631d4891  vmovaps [rsp+0x20], xmm2
00007767631d4897  vmovaps [rsp+0x30], xmm3
00007767631d489d  vmovaps [rsp+0x40], xmm4
00007767631d48a3  vmovaps [rsp+0x50], xmm5
00007767631d48a9  vmovaps [rsp+0x60], xmm6
00007767631d48af  vmovaps [rsp+0x70], xmm7
00007767631d48b5  vmovaps [rsp+0x80], xmm8
00007767631d48be  vmovaps [rsp+0x90], xmm9
00007767631d48c7  vmovaps [rsp+0xA0], xmm10
00007767631d48d0  vmovaps [rsp+0xB0], xmm11
00007767631d48d9  vmovaps [rsp+0xC0], xmm12
00007767631d48e2  vmovaps [rsp+0xD0], xmm14
00007767631d48eb  vmovaps [rsp+0xE0], xmm15
00007767631d48f4  sub rsp, 0x30
00007767631d48f8  movaps [rsp], xmm13
00007767631d48fd  movaps [rsp+0x10], xmm1
00007767631d4902  movaps [rsp+0x20], xmm8
00007767631d4908  lea rdi, [rsp]
00007767631d490c  mov esi, 0x00
00007767631d4911  mov rax, 0x617961CDB530
00007767631d491b  call rax
00007767631d491d  movaps xmm13, [rsp]
00007767631d4922  add rsp, 0x30
00007767631d4926  vmovaps xmm0, [rsp]
00007767631d492b  vmovaps xmm1, [rsp+0x10]
00007767631d4931  vmovaps xmm2, [rsp+0x20]
00007767631d4937  vmovaps xmm3, [rsp+0x30]
00007767631d493d  vmovaps xmm4, [rsp+0x40]
00007767631d4943  vmovaps xmm5, [rsp+0x50]
00007767631d4949  vmovaps xmm6, [rsp+0x60]
00007767631d494f  vmovaps xmm7, [rsp+0x70]
00007767631d4955  vmovaps xmm8, [rsp+0x80]
00007767631d495e  vmovaps xmm9, [rsp+0x90]
00007767631d4967  vmovaps xmm10, [rsp+0xA0]
00007767631d4970  vmovaps xmm11, [rsp+0xB0]
00007767631d4979  vmovaps xmm12, [rsp+0xC0]
00007767631d4982  vmovaps xmm14, [rsp+0xD0]
00007767631d498b  vmovaps xmm15, [rsp+0xE0]
00007767631d4994  add rsp, 0xF0
00007767631d499b  pop r11
00007767631d499d  pop r10
00007767631d499f  pop r9
00007767631d49a1  pop r8
00007767631d49a3  pop rsi
00007767631d49a4  pop rdi
00007767631d49a5  pop rdx
00007767631d49a6  pop rcx
00007767631d49a7  pop rax
00007767631d49a8  add rsp, 0x08
00007767631d49ac  jmp 0x00007767631D0183
00007767631d49b1  call 0x0000776762FFF430
00007767631d49b6  jmp 0x00007767631D018D
00007767631d49bb  sub rsp, 0x08
00007767631d49bf  push rax
00007767631d49c0  push rcx
00007767631d49c1  push rdx
00007767631d49c2  push rdi
00007767631d49c3  push rsi
00007767631d49c4  push r8
00007767631d49c6  push r9
00007767631d49c8  push r10
00007767631d49ca  push r11
00007767631d49cc  sub rsp, 0xF0
00007767631d49d3  vmovaps [rsp], xmm0
00007767631d49d8  vmovaps [rsp+0x10], xmm1
00007767631d49de  vmovaps [rsp+0x20], xmm2
00007767631d49e4  vmovaps [rsp+0x30], xmm3
00007767631d49ea  vmovaps [rsp+0x40], xmm4
00007767631d49f0  vmovaps [rsp+0x50], xmm5
00007767631d49f6  vmovaps [rsp+0x60], xmm6
00007767631d49fc  vmovaps [rsp+0x70], xmm7
00007767631d4a02  vmovaps [rsp+0x80], xmm9
00007767631d4a0b  vmovaps [rsp+0x90], xmm10
00007767631d4a14  vmovaps [rsp+0xA0], xmm11
00007767631d4a1d  vmovaps [rsp+0xB0], xmm12
00007767631d4a26  vmovaps [rsp+0xC0], xmm13
00007767631d4a2f  vmovaps [rsp+0xD0], xmm14
00007767631d4a38  vmovaps [rsp+0xE0], xmm15
00007767631d4a41  sub rsp, 0x30
00007767631d4a45  movaps [rsp], xmm8
00007767631d4a4a  movaps [rsp+0x10], xmm14
00007767631d4a50  movaps [rsp+0x20], xmm9
00007767631d4a56  lea rdi, [rsp]
00007767631d4a5a  mov esi, 0x00
00007767631d4a5f  mov rax, 0x617961CDB530
00007767631d4a69  call rax
00007767631d4a6b  movaps xmm8, [rsp]
00007767631d4a70  add rsp, 0x30
00007767631d4a74  vmovaps xmm0, [rsp]
00007767631d4a79  vmovaps xmm1, [rsp+0x10]
00007767631d4a7f  vmovaps xmm2, [rsp+0x20]
00007767631d4a85  vmovaps xmm3, [rsp+0x30]
00007767631d4a8b  vmovaps xmm4, [rsp+0x40]
00007767631d4a91  vmovaps xmm5, [rsp+0x50]
00007767631d4a97  vmovaps xmm6, [rsp+0x60]
00007767631d4a9d  vmovaps xmm7, [rsp+0x70]
00007767631d4aa3  vmovaps xmm9, [rsp+0x80]
00007767631d4aac  vmovaps xmm10, [rsp+0x90]
00007767631d4ab5  vmovaps xmm11, [rsp+0xA0]
00007767631d4abe  vmovaps xmm12, [rsp+0xB0]
00007767631d4ac7  vmovaps xmm13, [rsp+0xC0]
00007767631d4ad0  vmovaps xmm14, [rsp+0xD0]
00007767631d4ad9  vmovaps xmm15, [rsp+0xE0]
00007767631d4ae2  add rsp, 0xF0
00007767631d4ae9  pop r11
00007767631d4aeb  pop r10
00007767631d4aed  pop r9
00007767631d4aef  pop r8
00007767631d4af1  pop rsi
00007767631d4af2  pop rdi
00007767631d4af3  pop rdx
00007767631d4af4  pop rcx
00007767631d4af5  pop rax
00007767631d4af6  add rsp, 0x08
00007767631d4afa  jmp 0x00007767631D01AF
00007767631d4aff  sub rsp, 0x08
00007767631d4b03  push rax
00007767631d4b04  push rcx
00007767631d4b05  push rdx
00007767631d4b06  push rdi
00007767631d4b07  push rsi
00007767631d4b08  push r8
00007767631d4b0a  push r9
00007767631d4b0c  push r10
00007767631d4b0e  push r11
00007767631d4b10  sub rsp, 0xF0
00007767631d4b17  vmovaps [rsp], xmm0
00007767631d4b1c  vmovaps [rsp+0x10], xmm1
00007767631d4b22  vmovaps [rsp+0x20], xmm2
00007767631d4b28  vmovaps [rsp+0x30], xmm3
00007767631d4b2e  vmovaps [rsp+0x40], xmm4
00007767631d4b34  vmovaps [rsp+0x50], xmm5
00007767631d4b3a  vmovaps [rsp+0x60], xmm6
00007767631d4b40  vmovaps [rsp+0x70], xmm7
00007767631d4b46  vmovaps [rsp+0x80], xmm8
00007767631d4b4f  vmovaps [rsp+0x90], xmm10
00007767631d4b58  vmovaps [rsp+0xA0], xmm11
00007767631d4b61  vmovaps [rsp+0xB0], xmm12
00007767631d4b6a  vmovaps [rsp+0xC0], xmm13
00007767631d4b73  vmovaps [rsp+0xD0], xmm14
00007767631d4b7c  vmovaps [rsp+0xE0], xmm15
00007767631d4b85  sub rsp, 0x30
00007767631d4b89  movaps [rsp], xmm9
00007767631d4b8e  movaps [rsp+0x10], xmm1
00007767631d4b93  movaps [rsp+0x20], xmm14
00007767631d4b99  lea rdi, [rsp]
00007767631d4b9d  mov esi, 0x00
00007767631d4ba2  mov rax, 0x617961CDB530
00007767631d4bac  call rax
00007767631d4bae  movaps xmm9, [rsp]
00007767631d4bb3  add rsp, 0x30
00007767631d4bb7  vmovaps xmm0, [rsp]
00007767631d4bbc  vmovaps xmm1, [rsp+0x10]
00007767631d4bc2  vmovaps xmm2, [rsp+0x20]
00007767631d4bc8  vmovaps xmm3, [rsp+0x30]
00007767631d4bce  vmovaps xmm4, [rsp+0x40]
00007767631d4bd4  vmovaps xmm5, [rsp+0x50]
00007767631d4bda  vmovaps xmm6, [rsp+0x60]
00007767631d4be0  vmovaps xmm7, [rsp+0x70]
00007767631d4be6  vmovaps xmm8, [rsp+0x80]
00007767631d4bef  vmovaps xmm10, [rsp+0x90]
00007767631d4bf8  vmovaps xmm11, [rsp+0xA0]
00007767631d4c01  vmovaps xmm12, [rsp+0xB0]
00007767631d4c0a  vmovaps xmm13, [rsp+0xC0]
00007767631d4c13  vmovaps xmm14, [rsp+0xD0]
00007767631d4c1c  vmovaps xmm15, [rsp+0xE0]
00007767631d4c25  add rsp, 0xF0
00007767631d4c2c  pop r11
00007767631d4c2e  pop r10
00007767631d4c30  pop r9
00007767631d4c32  pop r8
00007767631d4c34  pop rsi
00007767631d4c35  pop rdi
00007767631d4c36  pop rdx
00007767631d4c37  pop rcx
00007767631d4c38  pop rax
00007767631d4c39  add rsp, 0x08
00007767631d4c3d  jmp 0x00007767631D01DD
00007767631d4c42  sub rsp, 0x08
00007767631d4c46  push rax
00007767631d4c47  push rcx
00007767631d4c48  push rdx
00007767631d4c49  push rdi
00007767631d4c4a  push rsi
00007767631d4c4b  push r8
00007767631d4c4d  push r9
00007767631d4c4f  push r10
00007767631d4c51  push r11
00007767631d4c53  sub rsp, 0xF0
00007767631d4c5a  vmovaps [rsp], xmm0
00007767631d4c5f  vmovaps [rsp+0x10], xmm1
00007767631d4c65  vmovaps [rsp+0x20], xmm2
00007767631d4c6b  vmovaps [rsp+0x30], xmm3
00007767631d4c71  vmovaps [rsp+0x40], xmm4
00007767631d4c77  vmovaps [rsp+0x50], xmm5
00007767631d4c7d  vmovaps [rsp+0x60], xmm6
00007767631d4c83  vmovaps [rsp+0x70], xmm7
00007767631d4c89  vmovaps [rsp+0x80], xmm8
00007767631d4c92  vmovaps [rsp+0x90], xmm9
00007767631d4c9b  vmovaps [rsp+0xA0], xmm10
00007767631d4ca4  vmovaps [rsp+0xB0], xmm11
00007767631d4cad  vmovaps [rsp+0xC0], xmm12
00007767631d4cb6  vmovaps [rsp+0xD0], xmm13
00007767631d4cbf  vmovaps [rsp+0xE0], xmm15
00007767631d4cc8  sub rsp, 0x30
00007767631d4ccc  movaps [rsp], xmm14
00007767631d4cd1  movaps [rsp+0x10], xmm4
00007767631d4cd6  movaps [rsp+0x20], xmm1
00007767631d4cdb  lea rdi, [rsp]
00007767631d4cdf  mov esi, 0x00
00007767631d4ce4  mov rax, 0x617961CDB530
00007767631d4cee  call rax
00007767631d4cf0  movaps xmm14, [rsp]
00007767631d4cf5  add rsp, 0x30
00007767631d4cf9  vmovaps xmm0, [rsp]
00007767631d4cfe  vmovaps xmm1, [rsp+0x10]
00007767631d4d04  vmovaps xmm2, [rsp+0x20]
00007767631d4d0a  vmovaps xmm3, [rsp+0x30]
00007767631d4d10  vmovaps xmm4, [rsp+0x40]
00007767631d4d16  vmovaps xmm5, [rsp+0x50]
00007767631d4d1c  vmovaps xmm6, [rsp+0x60]
00007767631d4d22  vmovaps xmm7, [rsp+0x70]
00007767631d4d28  vmovaps xmm8, [rsp+0x80]
00007767631d4d31  vmovaps xmm9, [rsp+0x90]
00007767631d4d3a  vmovaps xmm10, [rsp+0xA0]
00007767631d4d43  vmovaps xmm11, [rsp+0xB0]
00007767631d4d4c  vmovaps xmm12, [rsp+0xC0]
00007767631d4d55  vmovaps xmm13, [rsp+0xD0]
00007767631d4d5e  vmovaps xmm15, [rsp+0xE0]
00007767631d4d67  add rsp, 0xF0
00007767631d4d6e  pop r11
00007767631d4d70  pop r10
00007767631d4d72  pop r9
00007767631d4d74  pop r8
00007767631d4d76  pop rsi
00007767631d4d77  pop rdi
00007767631d4d78  pop rdx
00007767631d4d79  pop rcx
00007767631d4d7a  pop rax
00007767631d4d7b  add rsp, 0x08
00007767631d4d7f  jmp 0x00007767631D0203
00007767631d4d84  sub rsp, 0x08
00007767631d4d88  push rax
00007767631d4d89  push rcx
00007767631d4d8a  push rdx
00007767631d4d8b  push rdi
00007767631d4d8c  push rsi
00007767631d4d8d  push r8
00007767631d4d8f  push r9
00007767631d4d91  push r10
00007767631d4d93  push r11
00007767631d4d95  sub rsp, 0xF0
00007767631d4d9c  vmovaps [rsp], xmm0
00007767631d4da1  vmovaps [rsp+0x10], xmm2
00007767631d4da7  vmovaps [rsp+0x20], xmm3
00007767631d4dad  vmovaps [rsp+0x30], xmm4
00007767631d4db3  vmovaps [rsp+0x40], xmm5
00007767631d4db9  vmovaps [rsp+0x50], xmm6
00007767631d4dbf  vmovaps [rsp+0x60], xmm7
00007767631d4dc5  vmovaps [rsp+0x70], xmm8
00007767631d4dcb  vmovaps [rsp+0x80], xmm9
00007767631d4dd4  vmovaps [rsp+0x90], xmm10
00007767631d4ddd  vmovaps [rsp+0xA0], xmm11
00007767631d4de6  vmovaps [rsp+0xB0], xmm12
00007767631d4def  vmovaps [rsp+0xC0], xmm13
00007767631d4df8  vmovaps [rsp+0xD0], xmm14
00007767631d4e01  vmovaps [rsp+0xE0], xmm15
00007767631d4e0a  sub rsp, 0x30
00007767631d4e0e  movaps [rsp], xmm1
00007767631d4e12  movaps [rsp+0x10], xmm12
00007767631d4e18  movaps [rsp+0x20], xmm11
00007767631d4e1e  lea rdi, [rsp]
00007767631d4e22  mov esi, 0x00
00007767631d4e27  mov rax, 0x617961CDB530
00007767631d4e31  call rax
00007767631d4e33  movaps xmm1, [rsp]
00007767631d4e37  add rsp, 0x30
00007767631d4e3b  vmovaps xmm0, [rsp]
00007767631d4e40  vmovaps xmm2, [rsp+0x10]
00007767631d4e46  vmovaps xmm3, [rsp+0x20]
00007767631d4e4c  vmovaps xmm4, [rsp+0x30]
00007767631d4e52  vmovaps xmm5, [rsp+0x40]
00007767631d4e58  vmovaps xmm6, [rsp+0x50]
00007767631d4e5e  vmovaps xmm7, [rsp+0x60]
00007767631d4e64  vmovaps xmm8, [rsp+0x70]
00007767631d4e6a  vmovaps xmm9, [rsp+0x80]
00007767631d4e73  vmovaps xmm10, [rsp+0x90]
00007767631d4e7c  vmovaps xmm11, [rsp+0xA0]
00007767631d4e85  vmovaps xmm12, [rsp+0xB0]
00007767631d4e8e  vmovaps xmm13, [rsp+0xC0]
00007767631d4e97  vmovaps xmm14, [rsp+0xD0]
00007767631d4ea0  vmovaps xmm15, [rsp+0xE0]
00007767631d4ea9  add rsp, 0xF0
00007767631d4eb0  pop r11
00007767631d4eb2  pop r10
00007767631d4eb4  pop r9
00007767631d4eb6  pop r8
00007767631d4eb8  pop rsi
00007767631d4eb9  pop rdi
00007767631d4eba  pop rdx
00007767631d4ebb  pop rcx
00007767631d4ebc  pop rax
00007767631d4ebd  add rsp, 0x08
00007767631d4ec1  jmp 0x00007767631D0224
00007767631d4ec6  call 0x00007767630E20A0
00007767631d4ecb  jmp 0x00007767631D0232
00007767631d4ed0  call 0x0000776763009D70
00007767631d4ed5  jmp 0x00007767631D023C
00007767631d4eda  sub rsp, 0x08
00007767631d4ede  push rax
00007767631d4edf  push rcx
00007767631d4ee0  push rdx
00007767631d4ee1  push rdi
00007767631d4ee2  push rsi
00007767631d4ee3  push r8
00007767631d4ee5  push r9
00007767631d4ee7  push r10
00007767631d4ee9  push r11
00007767631d4eeb  sub rsp, 0xF0
00007767631d4ef2  vmovaps [rsp], xmm0
00007767631d4ef7  vmovaps [rsp+0x10], xmm1
00007767631d4efd  vmovaps [rsp+0x20], xmm2
00007767631d4f03  vmovaps [rsp+0x30], xmm3
00007767631d4f09  vmovaps [rsp+0x40], xmm4
00007767631d4f0f  vmovaps [rsp+0x50], xmm5
00007767631d4f15  vmovaps [rsp+0x60], xmm6
00007767631d4f1b  vmovaps [rsp+0x70], xmm8
00007767631d4f21  vmovaps [rsp+0x80], xmm9
00007767631d4f2a  vmovaps [rsp+0x90], xmm10
00007767631d4f33  vmovaps [rsp+0xA0], xmm11
00007767631d4f3c  vmovaps [rsp+0xB0], xmm12
00007767631d4f45  vmovaps [rsp+0xC0], xmm13
00007767631d4f4e  vmovaps [rsp+0xD0], xmm14
00007767631d4f57  vmovaps [rsp+0xE0], xmm15
00007767631d4f60  sub rsp, 0x30
00007767631d4f64  movaps [rsp], xmm7
00007767631d4f68  movaps [rsp+0x10], xmm15
00007767631d4f6e  movaps [rsp+0x20], xmm10
00007767631d4f74  lea rdi, [rsp]
00007767631d4f78  mov esi, 0x00
00007767631d4f7d  mov rax, 0x617961CDB530
00007767631d4f87  call rax
00007767631d4f89  movaps xmm7, [rsp]
00007767631d4f8d  add rsp, 0x30
00007767631d4f91  vmovaps xmm0, [rsp]
00007767631d4f96  vmovaps xmm1, [rsp+0x10]
00007767631d4f9c  vmovaps xmm2, [rsp+0x20]
00007767631d4fa2  vmovaps xmm3, [rsp+0x30]
00007767631d4fa8  vmovaps xmm4, [rsp+0x40]
00007767631d4fae  vmovaps xmm5, [rsp+0x50]
00007767631d4fb4  vmovaps xmm6, [rsp+0x60]
00007767631d4fba  vmovaps xmm8, [rsp+0x70]
00007767631d4fc0  vmovaps xmm9, [rsp+0x80]
00007767631d4fc9  vmovaps xmm10, [rsp+0x90]
00007767631d4fd2  vmovaps xmm11, [rsp+0xA0]
00007767631d4fdb  vmovaps xmm12, [rsp+0xB0]
00007767631d4fe4  vmovaps xmm13, [rsp+0xC0]
00007767631d4fed  vmovaps xmm14, [rsp+0xD0]
00007767631d4ff6  vmovaps xmm15, [rsp+0xE0]
00007767631d4fff  add rsp, 0xF0
00007767631d5006  pop r11
00007767631d5008  pop r10
00007767631d500a  pop r9
00007767631d500c  pop r8
00007767631d500e  pop rsi
00007767631d500f  pop rdi
00007767631d5010  pop rdx
00007767631d5011  pop rcx
00007767631d5012  pop rax
00007767631d5013  add rsp, 0x08
00007767631d5017  jmp 0x00007767631D025D
00007767631d501c  sub rsp, 0x08
00007767631d5020  push rax
00007767631d5021  push rcx
00007767631d5022  push rdx
00007767631d5023  push rdi
00007767631d5024  push rsi
00007767631d5025  push r8
00007767631d5027  push r9
00007767631d5029  push r10
00007767631d502b  push r11
00007767631d502d  sub rsp, 0xF0
00007767631d5034  vmovaps [rsp], xmm0
00007767631d5039  vmovaps [rsp+0x10], xmm1
00007767631d503f  vmovaps [rsp+0x20], xmm2
00007767631d5045  vmovaps [rsp+0x30], xmm3
00007767631d504b  vmovaps [rsp+0x40], xmm4
00007767631d5051  vmovaps [rsp+0x50], xmm5
00007767631d5057  vmovaps [rsp+0x60], xmm6
00007767631d505d  vmovaps [rsp+0x70], xmm7
00007767631d5063  vmovaps [rsp+0x80], xmm8
00007767631d506c  vmovaps [rsp+0x90], xmm9
00007767631d5075  vmovaps [rsp+0xA0], xmm11
00007767631d507e  vmovaps [rsp+0xB0], xmm12
00007767631d5087  vmovaps [rsp+0xC0], xmm13
00007767631d5090  vmovaps [rsp+0xD0], xmm14
00007767631d5099  vmovaps [rsp+0xE0], xmm15
00007767631d50a2  sub rsp, 0x30
00007767631d50a6  movaps [rsp], xmm10
00007767631d50ab  movaps [rsp+0x10], xmm11
00007767631d50b1  movaps [rsp+0x20], xmm15
00007767631d50b7  lea rdi, [rsp]
00007767631d50bb  mov esi, 0x00
00007767631d50c0  mov rax, 0x617961CDB530
00007767631d50ca  call rax
00007767631d50cc  movaps xmm10, [rsp]
00007767631d50d1  add rsp, 0x30
00007767631d50d5  vmovaps xmm0, [rsp]
00007767631d50da  vmovaps xmm1, [rsp+0x10]
00007767631d50e0  vmovaps xmm2, [rsp+0x20]
00007767631d50e6  vmovaps xmm3, [rsp+0x30]
00007767631d50ec  vmovaps xmm4, [rsp+0x40]
00007767631d50f2  vmovaps xmm5, [rsp+0x50]
00007767631d50f8  vmovaps xmm6, [rsp+0x60]
00007767631d50fe  vmovaps xmm7, [rsp+0x70]
00007767631d5104  vmovaps xmm8, [rsp+0x80]
00007767631d510d  vmovaps xmm9, [rsp+0x90]
00007767631d5116  vmovaps xmm11, [rsp+0xA0]
00007767631d511f  vmovaps xmm12, [rsp+0xB0]
00007767631d5128  vmovaps xmm13, [rsp+0xC0]
00007767631d5131  vmovaps xmm14, [rsp+0xD0]
00007767631d513a  vmovaps xmm15, [rsp+0xE0]
00007767631d5143  add rsp, 0xF0
00007767631d514a  pop r11
00007767631d514c  pop r10
00007767631d514e  pop r9
00007767631d5150  pop r8
00007767631d5152  pop rsi
00007767631d5153  pop rdi
00007767631d5154  pop rdx
00007767631d5155  pop rcx
00007767631d5156  pop rax
00007767631d5157  add rsp, 0x08
00007767631d515b  jmp 0x00007767631D028B
00007767631d5160  sub rsp, 0x08
00007767631d5164  push rax
00007767631d5165  push rcx
00007767631d5166  push rdx
00007767631d5167  push rdi
00007767631d5168  push rsi
00007767631d5169  push r8
00007767631d516b  push r9
00007767631d516d  push r10
00007767631d516f  push r11
00007767631d5171  sub rsp, 0xF0
00007767631d5178  vmovaps [rsp], xmm0
00007767631d517d  vmovaps [rsp+0x10], xmm1
00007767631d5183  vmovaps [rsp+0x20], xmm2
00007767631d5189  vmovaps [rsp+0x30], xmm3
00007767631d518f  vmovaps [rsp+0x40], xmm4
00007767631d5195  vmovaps [rsp+0x50], xmm5
00007767631d519b  vmovaps [rsp+0x60], xmm6
00007767631d51a1  vmovaps [rsp+0x70], xmm7
00007767631d51a7  vmovaps [rsp+0x80], xmm8
00007767631d51b0  vmovaps [rsp+0x90], xmm9
00007767631d51b9  vmovaps [rsp+0xA0], xmm10
00007767631d51c2  vmovaps [rsp+0xB0], xmm12
00007767631d51cb  vmovaps [rsp+0xC0], xmm13
00007767631d51d4  vmovaps [rsp+0xD0], xmm14
00007767631d51dd  vmovaps [rsp+0xE0], xmm15
00007767631d51e6  sub rsp, 0x30
00007767631d51ea  movaps [rsp], xmm11
00007767631d51ef  movaps [rsp+0x10], xmm12
00007767631d51f5  movaps [rsp+0x20], xmm15
00007767631d51fb  lea rdi, [rsp]
00007767631d51ff  mov esi, 0x00
00007767631d5204  mov rax, 0x617961CDB530
00007767631d520e  call rax
00007767631d5210  movaps xmm11, [rsp]
00007767631d5215  add rsp, 0x30
00007767631d5219  vmovaps xmm0, [rsp]
00007767631d521e  vmovaps xmm1, [rsp+0x10]
00007767631d5224  vmovaps xmm2, [rsp+0x20]
00007767631d522a  vmovaps xmm3, [rsp+0x30]
00007767631d5230  vmovaps xmm4, [rsp+0x40]
00007767631d5236  vmovaps xmm5, [rsp+0x50]
00007767631d523c  vmovaps xmm6, [rsp+0x60]
00007767631d5242  vmovaps xmm7, [rsp+0x70]
00007767631d5248  vmovaps xmm8, [rsp+0x80]
00007767631d5251  vmovaps xmm9, [rsp+0x90]
00007767631d525a  vmovaps xmm10, [rsp+0xA0]
00007767631d5263  vmovaps xmm12, [rsp+0xB0]
00007767631d526c  vmovaps xmm13, [rsp+0xC0]
00007767631d5275  vmovaps xmm14, [rsp+0xD0]
00007767631d527e  vmovaps xmm15, [rsp+0xE0]
00007767631d5287  add rsp, 0xF0
00007767631d528e  pop r11
00007767631d5290  pop r10
00007767631d5292  pop r9
00007767631d5294  pop r8
00007767631d5296  pop rsi
00007767631d5297  pop rdi
00007767631d5298  pop rdx
00007767631d5299  pop rcx
00007767631d529a  pop rax
00007767631d529b  add rsp, 0x08
00007767631d529f  jmp 0x00007767631D02B9
00007767631d52a4  sub rsp, 0x08
00007767631d52a8  push rax
00007767631d52a9  push rcx
00007767631d52aa  push rdx
00007767631d52ab  push rdi
00007767631d52ac  push rsi
00007767631d52ad  push r8
00007767631d52af  push r9
00007767631d52b1  push r10
00007767631d52b3  push r11
00007767631d52b5  sub rsp, 0xF0
00007767631d52bc  vmovaps [rsp], xmm0
00007767631d52c1  vmovaps [rsp+0x10], xmm1
00007767631d52c7  vmovaps [rsp+0x20], xmm2
00007767631d52cd  vmovaps [rsp+0x30], xmm3
00007767631d52d3  vmovaps [rsp+0x40], xmm4
00007767631d52d9  vmovaps [rsp+0x50], xmm5
00007767631d52df  vmovaps [rsp+0x60], xmm6
00007767631d52e5  vmovaps [rsp+0x70], xmm7
00007767631d52eb  vmovaps [rsp+0x80], xmm8
00007767631d52f4  vmovaps [rsp+0x90], xmm9
00007767631d52fd  vmovaps [rsp+0xA0], xmm10
00007767631d5306  vmovaps [rsp+0xB0], xmm11
00007767631d530f  vmovaps [rsp+0xC0], xmm12
00007767631d5318  vmovaps [rsp+0xD0], xmm13
00007767631d5321  vmovaps [rsp+0xE0], xmm14
00007767631d532a  sub rsp, 0x30
00007767631d532e  movaps [rsp], xmm15
00007767631d5333  movaps [rsp+0x10], xmm13
00007767631d5339  movaps [rsp+0x20], xmm9
00007767631d533f  lea rdi, [rsp]
00007767631d5343  mov esi, 0x00
00007767631d5348  mov rax, 0x617961CDB530
00007767631d5352  call rax
00007767631d5354  movaps xmm15, [rsp]
00007767631d5359  add rsp, 0x30
00007767631d535d  vmovaps xmm0, [rsp]
00007767631d5362  vmovaps xmm1, [rsp+0x10]
00007767631d5368  vmovaps xmm2, [rsp+0x20]
00007767631d536e  vmovaps xmm3, [rsp+0x30]
00007767631d5374  vmovaps xmm4, [rsp+0x40]
00007767631d537a  vmovaps xmm5, [rsp+0x50]
00007767631d5380  vmovaps xmm6, [rsp+0x60]
00007767631d5386  vmovaps xmm7, [rsp+0x70]
00007767631d538c  vmovaps xmm8, [rsp+0x80]
00007767631d5395  vmovaps xmm9, [rsp+0x90]
00007767631d539e  vmovaps xmm10, [rsp+0xA0]
00007767631d53a7  vmovaps xmm11, [rsp+0xB0]
00007767631d53b0  vmovaps xmm12, [rsp+0xC0]
00007767631d53b9  vmovaps xmm13, [rsp+0xD0]
00007767631d53c2  vmovaps xmm14, [rsp+0xE0]
00007767631d53cb  add rsp, 0xF0
00007767631d53d2  pop r11
00007767631d53d4  pop r10
00007767631d53d6  pop r9
00007767631d53d8  pop r8
00007767631d53da  pop rsi
00007767631d53db  pop rdi
00007767631d53dc  pop rdx
00007767631d53dd  pop rcx
00007767631d53de  pop rax
00007767631d53df  add rsp, 0x08
00007767631d53e3  jmp 0x00007767631D02D4
00007767631d53e8  sub rsp, 0x08
00007767631d53ec  push rax
00007767631d53ed  push rcx
00007767631d53ee  push rdx
00007767631d53ef  push rdi
00007767631d53f0  push rsi
00007767631d53f1  push r8
00007767631d53f3  push r9
00007767631d53f5  push r10
00007767631d53f7  push r11
00007767631d53f9  sub rsp, 0xF0
00007767631d5400  vmovaps [rsp], xmm0
00007767631d5405  vmovaps [rsp+0x10], xmm1
00007767631d540b  vmovaps [rsp+0x20], xmm2
00007767631d5411  vmovaps [rsp+0x30], xmm3
00007767631d5417  vmovaps [rsp+0x40], xmm4
00007767631d541d  vmovaps [rsp+0x50], xmm5
00007767631d5423  vmovaps [rsp+0x60], xmm6
00007767631d5429  vmovaps [rsp+0x70], xmm7
00007767631d542f  vmovaps [rsp+0x80], xmm8
00007767631d5438  vmovaps [rsp+0x90], xmm9
00007767631d5441  vmovaps [rsp+0xA0], xmm10
00007767631d544a  vmovaps [rsp+0xB0], xmm11
00007767631d5453  vmovaps [rsp+0xC0], xmm12
00007767631d545c  vmovaps [rsp+0xD0], xmm14
00007767631d5465  vmovaps [rsp+0xE0], xmm15
00007767631d546e  sub rsp, 0x30
00007767631d5472  movaps [rsp], xmm13
00007767631d5477  movaps [rsp+0x10], xmm8
00007767631d547d  movaps [rsp+0x20], xmm14
00007767631d5483  lea rdi, [rsp]
00007767631d5487  mov esi, 0x00
00007767631d548c  mov rax, 0x617961CDB530
00007767631d5496  call rax
00007767631d5498  movaps xmm13, [rsp]
00007767631d549d  add rsp, 0x30
00007767631d54a1  vmovaps xmm0, [rsp]
00007767631d54a6  vmovaps xmm1, [rsp+0x10]
00007767631d54ac  vmovaps xmm2, [rsp+0x20]
00007767631d54b2  vmovaps xmm3, [rsp+0x30]
00007767631d54b8  vmovaps xmm4, [rsp+0x40]
00007767631d54be  vmovaps xmm5, [rsp+0x50]
00007767631d54c4  vmovaps xmm6, [rsp+0x60]
00007767631d54ca  vmovaps xmm7, [rsp+0x70]
00007767631d54d0  vmovaps xmm8, [rsp+0x80]
00007767631d54d9  vmovaps xmm9, [rsp+0x90]
00007767631d54e2  vmovaps xmm10, [rsp+0xA0]
00007767631d54eb  vmovaps xmm11, [rsp+0xB0]
00007767631d54f4  vmovaps xmm12, [rsp+0xC0]
00007767631d54fd  vmovaps xmm14, [rsp+0xD0]
00007767631d5506  vmovaps xmm15, [rsp+0xE0]
00007767631d550f  add rsp, 0xF0
00007767631d5516  pop r11
00007767631d5518  pop r10
00007767631d551a  pop r9
00007767631d551c  pop r8
00007767631d551e  pop rsi
00007767631d551f  pop rdi
00007767631d5520  pop rdx
00007767631d5521  pop rcx
00007767631d5522  pop rax
00007767631d5523  add rsp, 0x08
00007767631d5527  jmp 0x00007767631D02F7
00007767631d552c  sub rsp, 0x08
00007767631d5530  push rax
00007767631d5531  push rcx
00007767631d5532  push rdx
00007767631d5533  push rdi
00007767631d5534  push rsi
00007767631d5535  push r8
00007767631d5537  push r9
00007767631d5539  push r10
00007767631d553b  push r11
00007767631d553d  sub rsp, 0xF0
00007767631d5544  vmovaps [rsp], xmm0
00007767631d5549  vmovaps [rsp+0x10], xmm1
00007767631d554f  vmovaps [rsp+0x20], xmm2
00007767631d5555  vmovaps [rsp+0x30], xmm3
00007767631d555b  vmovaps [rsp+0x40], xmm4
00007767631d5561  vmovaps [rsp+0x50], xmm5
00007767631d5567  vmovaps [rsp+0x60], xmm6
00007767631d556d  vmovaps [rsp+0x70], xmm7
00007767631d5573  vmovaps [rsp+0x80], xmm8
00007767631d557c  vmovaps [rsp+0x90], xmm9
00007767631d5585  vmovaps [rsp+0xA0], xmm10
00007767631d558e  vmovaps [rsp+0xB0], xmm11
00007767631d5597  vmovaps [rsp+0xC0], xmm12
00007767631d55a0  vmovaps [rsp+0xD0], xmm13
00007767631d55a9  vmovaps [rsp+0xE0], xmm15
00007767631d55b2  sub rsp, 0x30
00007767631d55b6  movaps [rsp], xmm14
00007767631d55bb  movaps [rsp+0x10], xmm1
00007767631d55c0  movaps [rsp+0x20], xmm10
00007767631d55c6  lea rdi, [rsp]
00007767631d55ca  mov esi, 0x00
00007767631d55cf  mov rax, 0x617961CDB530
00007767631d55d9  call rax
00007767631d55db  movaps xmm14, [rsp]
00007767631d55e0  add rsp, 0x30
00007767631d55e4  vmovaps xmm0, [rsp]
00007767631d55e9  vmovaps xmm1, [rsp+0x10]
00007767631d55ef  vmovaps xmm2, [rsp+0x20]
00007767631d55f5  vmovaps xmm3, [rsp+0x30]
00007767631d55fb  vmovaps xmm4, [rsp+0x40]
00007767631d5601  vmovaps xmm5, [rsp+0x50]
00007767631d5607  vmovaps xmm6, [rsp+0x60]
00007767631d560d  vmovaps xmm7, [rsp+0x70]
00007767631d5613  vmovaps xmm8, [rsp+0x80]
00007767631d561c  vmovaps xmm9, [rsp+0x90]
00007767631d5625  vmovaps xmm10, [rsp+0xA0]
00007767631d562e  vmovaps xmm11, [rsp+0xB0]
00007767631d5637  vmovaps xmm12, [rsp+0xC0]
00007767631d5640  vmovaps xmm13, [rsp+0xD0]
00007767631d5649  vmovaps xmm15, [rsp+0xE0]
00007767631d5652  add rsp, 0xF0
00007767631d5659  pop r11
00007767631d565b  pop r10
00007767631d565d  pop r9
00007767631d565f  pop r8
00007767631d5661  pop rsi
00007767631d5662  pop rdi
00007767631d5663  pop rdx
00007767631d5664  pop rcx
00007767631d5665  pop rax
00007767631d5666  add rsp, 0x08
00007767631d566a  jmp 0x00007767631D031A
00007767631d566f  sub rsp, 0x08
00007767631d5673  push rax
00007767631d5674  push rcx
00007767631d5675  push rdx
00007767631d5676  push rdi
00007767631d5677  push rsi
00007767631d5678  push r8
00007767631d567a  push r9
00007767631d567c  push r10
00007767631d567e  push r11
00007767631d5680  sub rsp, 0xF0
00007767631d5687  vmovaps [rsp], xmm0
00007767631d568c  vmovaps [rsp+0x10], xmm2
00007767631d5692  vmovaps [rsp+0x20], xmm3
00007767631d5698  vmovaps [rsp+0x30], xmm4
00007767631d569e  vmovaps [rsp+0x40], xmm5
00007767631d56a4  vmovaps [rsp+0x50], xmm6
00007767631d56aa  vmovaps [rsp+0x60], xmm7
00007767631d56b0  vmovaps [rsp+0x70], xmm8
00007767631d56b6  vmovaps [rsp+0x80], xmm9
00007767631d56bf  vmovaps [rsp+0x90], xmm10
00007767631d56c8  vmovaps [rsp+0xA0], xmm11
00007767631d56d1  vmovaps [rsp+0xB0], xmm12
00007767631d56da  vmovaps [rsp+0xC0], xmm13
00007767631d56e3  vmovaps [rsp+0xD0], xmm14
00007767631d56ec  vmovaps [rsp+0xE0], xmm15
00007767631d56f5  sub rsp, 0x30
00007767631d56f9  movaps [rsp], xmm1
00007767631d56fd  movaps [rsp+0x10], xmm7
00007767631d5702  movaps [rsp+0x20], xmm11
00007767631d5708  lea rdi, [rsp]
00007767631d570c  mov esi, 0x00
00007767631d5711  mov rax, 0x617961CDB530
00007767631d571b  call rax
00007767631d571d  movaps xmm1, [rsp]
00007767631d5721  add rsp, 0x30
00007767631d5725  vmovaps xmm0, [rsp]
00007767631d572a  vmovaps xmm2, [rsp+0x10]
00007767631d5730  vmovaps xmm3, [rsp+0x20]
00007767631d5736  vmovaps xmm4, [rsp+0x30]
00007767631d573c  vmovaps xmm5, [rsp+0x40]
00007767631d5742  vmovaps xmm6, [rsp+0x50]
00007767631d5748  vmovaps xmm7, [rsp+0x60]
00007767631d574e  vmovaps xmm8, [rsp+0x70]
00007767631d5754  vmovaps xmm9, [rsp+0x80]
00007767631d575d  vmovaps xmm10, [rsp+0x90]
00007767631d5766  vmovaps xmm11, [rsp+0xA0]
00007767631d576f  vmovaps xmm12, [rsp+0xB0]
00007767631d5778  vmovaps xmm13, [rsp+0xC0]
00007767631d5781  vmovaps xmm14, [rsp+0xD0]
00007767631d578a  vmovaps xmm15, [rsp+0xE0]
00007767631d5793  add rsp, 0xF0
00007767631d579a  pop r11
00007767631d579c  pop r10
00007767631d579e  pop r9
00007767631d57a0  pop r8
00007767631d57a2  pop rsi
00007767631d57a3  pop rdi
00007767631d57a4  pop rdx
00007767631d57a5  pop rcx
00007767631d57a6  pop rax
00007767631d57a7  add rsp, 0x08
00007767631d57ab  jmp 0x00007767631D033B
00007767631d57b0  call 0x000077676300E880
00007767631d57b5  jmp 0x00007767631D034E
00007767631d57ba  call 0x000077676300C380
00007767631d57bf  jmp 0x00007767631D0359
00007767631d57c4  call 0x000077676300D600
00007767631d57c9  jmp 0x00007767631D0364
00007767631d57ce  call 0x0000776762FFF540
00007767631d57d3  jmp 0x00007767631D036F
00007767631d57d8  int3
00007767631d57d9  nop [rax], eax
00007767631d57e0  mov rax, [r15+0x40]
00007767631d57e4  mov r14, [r15+0x58]
00007767631d57e8  lea r12, [rax+r14*1]
00007767631d57ec  movaps xmm1, [r15+0x1D0]
00007767631d57f4  vmovaps [rsp+0x10], xmm1
00007767631d57fa  vmovaps xmm15, [rsp+0x10]
00007767631d5800  por xmm1, xmm15
00007767631d5805  movaps xmm14, [r15+0x1A0]
00007767631d580d  vmovaps [rsp+0x10], xmm14
00007767631d5813  vmovaps xmm13, [rsp+0x10]
00007767631d5819  por xmm14, xmm13
00007767631d581e  lea rax, [r12+0x30]
00007767631d5823  mov r11, [r13+rax*1]
00007767631d5828  lea rax, [r12+0x38]
00007767631d582d  mov r10, [r13+rax*1]
00007767631d5832  movq xmm13, r11
00007767631d5837  movq xmm12, r10
00007767631d583c  movq xmm13, xmm13
00007767631d5841  vmovaps [rsp+0x10], xmm13
00007767631d5847  movq xmm13, xmm13
00007767631d584c  movaps [r15+0x130], xmm13
00007767631d5854  movq xmm12, xmm12
00007767631d5859  vmovaps [rsp+0x20], xmm12
00007767631d585f  movq xmm12, xmm12
00007767631d5864  movaps [r15+0x280], xmm12
00007767631d586c  movaps xmm13, [r15+0x270]
00007767631d5874  vmovaps [rsp+0x30], xmm13
00007767631d587a  vmovaps xmm12, [rsp+0x30]
00007767631d5880  por xmm13, xmm12
00007767631d5885  lea rax, [r12+0x20]
00007767631d588a  mov r11, [r13+rax*1]
00007767631d588f  lea rax, [r12+0x28]
00007767631d5894  mov r10, [r13+rax*1]
00007767631d5899  movq xmm12, r11
00007767631d589e  movq xmm11, r10
00007767631d58a3  movq xmm12, xmm12
00007767631d58a8  vmovaps [rsp+0x30], xmm12
00007767631d58ae  movq xmm12, xmm12
00007767631d58b3  movaps [r15+0x150], xmm12
00007767631d58bb  movq xmm11, xmm11
00007767631d58c0  vmovaps [rsp+0x40], xmm11
00007767631d58c6  movq xmm11, xmm11
00007767631d58cb  movaps [r15+0x140], xmm11
00007767631d58d3  lea rax, [r12+0x10]
00007767631d58d8  mov r11, [r13+rax*1]
00007767631d58dd  lea rax, [r12+0x18]
00007767631d58e2  mov r10, [r13+rax*1]
00007767631d58e7  movq xmm12, r11
00007767631d58ec  movq xmm11, r10
00007767631d58f1  movq xmm12, xmm12
00007767631d58f6  vmovaps [rsp+0x50], xmm12
00007767631d58fc  movq xmm12, xmm12
00007767631d5901  movaps [r15+0x170], xmm12
00007767631d5909  movq xmm11, xmm11
00007767631d590e  vmovaps [rsp+0x60], xmm11
00007767631d5914  movq xmm11, xmm11
00007767631d5919  movaps [r15+0x160], xmm11
00007767631d5921  mov rax, [r13+r12*1]
00007767631d5926  vmovq xmm12, rax
00007767631d592b  vpbroadcastq xmm12, xmm12
00007767631d5930  lea rax, [r12+0x08]
00007767631d5935  mov r12, [r13+rax*1]
00007767631d593a  movq xmm11, r12
00007767631d593f  movaps [r15+0x230], xmm11
00007767631d5947  mov rax, [r15+0xF8]
00007767631d594e  lea r12, [rax+0x50]
00007767631d5952  movups xmm11, [r13+r12*1]
00007767631d5958  lea r12, [rax+0x60]
00007767631d595c  movups xmm10, [r13+r12*1]
00007767631d5962  lea r12, [rax+0x30]
00007767631d5966  movups xmm9, [r13+r12*1]
00007767631d596c  mov r12, [r15+0x50]
00007767631d5970  lea r11, [r12+r14*1]
00007767631d5974  mov [r15+0x60], r11
00007767631d5978  lea r12, [r14+0x40]
00007767631d597c  mov [r15+0x58], r12
00007767631d5980  movaps xmm8, xmm12
00007767631d5984  mulpd xmm8, xmm15
00007767631d5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007767631d598f  ptest xmm7, xmm7
00007767631d5994  jnz 0x00007767631D67B7
00007767631d599a  movq xmm15, qword ptr [r15+0x230]
00007767631d59a3  vmovaps [rsp+0x70], xmm15
00007767631d59a9  vpermilpd xmm15, xmm15, 0x00
00007767631d59af  movaps xmm7, xmm9
00007767631d59b3  mulpd xmm7, xmm15
00007767631d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007767631d59bd  ptest xmm6, xmm6
00007767631d59c2  jnz 0x00007767631D68FB
00007767631d59c8  vxorps xmm15, xmm15, xmm15
00007767631d59cd  vpbroadcastq xmm15, xmm15
00007767631d59d2  movaps xmm9, xmm12
00007767631d59d6  mulpd xmm9, xmm10
00007767631d59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007767631d59e1  ptest xmm6, xmm6
00007767631d59e6  jnz 0x00007767631D6A3D
00007767631d59ec  movaps xmm10, xmm12
00007767631d59f0  mulpd xmm10, xmm11
00007767631d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007767631d59fb  ptest xmm6, xmm6
00007767631d5a00  jnz 0x00007767631D6B81
00007767631d5a06  movaps xmm11, [r15+0x1F0]
00007767631d5a0e  movaps xmm6, xmm12
00007767631d5a12  mulpd xmm6, xmm11
00007767631d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007767631d5a1c  ptest xmm5, xmm5
00007767631d5a21  jnz 0x00007767631D6CC5
00007767631d5a27  movaps xmm12, [r15+0x2A0]
00007767631d5a2f  vmovaps [rsp+0x80], xmm12
00007767631d5a38  vmovaps xmm11, [rsp+0x80]
00007767631d5a41  por xmm12, xmm11
00007767631d5a46  movaps xmm11, [r15+0x250]
00007767631d5a4e  vmovaps [rsp+0x80], xmm11
00007767631d5a57  vmovaps xmm5, [rsp+0x80]
00007767631d5a60  por xmm11, xmm5
00007767631d5a65  vmovaps xmm4, [rsp+0x70]
00007767631d5a6b  vpermilpd xmm4, xmm4, 0x00
00007767631d5a71  movaps xmm3, xmm5
00007767631d5a74  mulpd xmm3, xmm4
00007767631d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007767631d5a7d  ptest xmm2, xmm2
00007767631d5a82  jnz 0x00007767631D6E07
00007767631d5a88  mov [rsp+0x80], rax
00007767631d5a90  xor eax, eax
00007767631d5a92  mov r14d, 0x200
00007767631d5a98  cmp r12, r14
00007767631d5a9b  cmc
00007767631d5a9c  lahf
00007767631d5a9d  seto al
00007767631d5aa0  mov [r15+0x108], eax
00007767631d5aa7  movaps xmm5, xmm8
00007767631d5aab  addpd xmm5, xmm15
00007767631d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007767631d5ab5  ptest xmm4, xmm4
00007767631d5aba  jnz 0x00007767631D6F47
00007767631d5ac0  movaps xmm8, [r15+0x1B0]
00007767631d5ac8  movaps xmm4, xmm9
00007767631d5acc  addpd xmm4, xmm8
00007767631d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007767631d5ad6  ptest xmm2, xmm2
00007767631d5adb  jnz 0x00007767631D7089
00007767631d5ae1  movaps xmm9, xmm10
00007767631d5ae5  addpd xmm9, xmm8
00007767631d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007767631d5af0  ptest xmm2, xmm2
00007767631d5af5  jnz 0x00007767631D71CB
00007767631d5afb  movaps xmm10, [r15+0x2F0]
00007767631d5b03  vmovaps [rsp+0x90], xmm10
00007767631d5b0c  vmovaps xmm8, [rsp+0x90]
00007767631d5b15  por xmm10, xmm8
00007767631d5b1a  movaps xmm8, [r15+0x2E0]
00007767631d5b22  vmovaps [rsp+0x90], xmm8
00007767631d5b2b  vmovaps xmm2, [rsp+0x90]
00007767631d5b34  por xmm8, xmm2
00007767631d5b39  movaps xmm2, [r15+0x2D0]
00007767631d5b41  vmovaps [rsp+0x90], xmm2
00007767631d5b4a  vmovaps [rsp+0xA0], xmm1
00007767631d5b53  vmovaps xmm1, [rsp+0x90]
00007767631d5b5c  por xmm2, xmm1
00007767631d5b60  movaps xmm1, [r15+0x200]
00007767631d5b68  vmovaps [rsp+0x90], xmm1
00007767631d5b71  vmovaps [rsp+0xB0], xmm15
00007767631d5b7a  vmovaps xmm15, [rsp+0x90]
00007767631d5b83  por xmm1, xmm15
00007767631d5b88  movaps xmm15, [r15+0x1C0]
00007767631d5b90  vmovaps [rsp+0x90], xmm15
00007767631d5b99  vmovaps [rsp+0xC0], xmm1
00007767631d5ba2  vmovaps xmm1, [rsp+0x90]
00007767631d5bab  por xmm15, xmm1
00007767631d5bb0  movaps xmm1, [r15+0x190]
00007767631d5bb8  vmovaps [rsp+0x90], xmm1
00007767631d5bc1  vmovaps [rsp+0xD0], xmm15
00007767631d5bca  vmovaps xmm15, [rsp+0x90]
00007767631d5bd3  por xmm1, xmm15
00007767631d5bd8  movaps xmm15, [r15+0x300]
00007767631d5be0  vmovaps [rsp+0x90], xmm15
00007767631d5be9  vmovaps [rsp+0xE0], xmm1
00007767631d5bf2  vmovaps xmm1, [rsp+0x90]
00007767631d5bfb  por xmm15, xmm1
00007767631d5c00  mov rax, [rsp+0x80]
00007767631d5c08  lea r14, [rax+0xA0]
00007767631d5c0f  movups xmm1, [r13+r14*1]
00007767631d5c15  lea r14, [rax+0xB0]
00007767631d5c1c  vmovaps [rsp+0x80], xmm1
00007767631d5c25  movups xmm1, [r13+r14*1]
00007767631d5c2b  vmovaps [rsp+0x90], xmm1
00007767631d5c34  vmovaps [rsp+0xF0], xmm15
00007767631d5c3d  vmovaps xmm15, [rsp+0xB0]
00007767631d5c46  vmovaps [rsp+0xB0], xmm14
00007767631d5c4f  movaps xmm1, xmm6
00007767631d5c52  addpd xmm1, xmm15
00007767631d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007767631d5c5c  ptest xmm14, xmm14
00007767631d5c62  jnz 0x00007767631D7323
00007767631d5c68  lea r14, [rax+0xF0]
00007767631d5c6f  movups xmm15, [r13+r14*1]
00007767631d5c75  movaps xmm14, xmm4
00007767631d5c79  addpd xmm14, xmm3
00007767631d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007767631d5c84  ptest xmm6, xmm6
00007767631d5c89  jnz 0x00007767631D746E
00007767631d5c8f  movaps xmm6, xmm9
00007767631d5c93  addpd xmm6, xmm7
00007767631d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007767631d5c9c  ptest xmm4, xmm4
00007767631d5ca1  jnz 0x00007767631D75B0
00007767631d5ca7  vmovaps xmm9, [rsp+0x70]
00007767631d5cad  vpermilpd xmm9, xmm9, 0x00
00007767631d5cb3  vmovaps xmm4, [rsp+0x90]
00007767631d5cbc  movaps xmm7, xmm4
00007767631d5cbf  mulpd xmm7, xmm9
00007767631d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007767631d5cc9  ptest xmm3, xmm3
00007767631d5cce  jnz 0x00007767631D76F1
00007767631d5cd4  vmovaps xmm9, [rsp+0x50]
00007767631d5cda  vpermilpd xmm9, xmm9, 0x00
00007767631d5ce0  movaps xmm4, xmm15
00007767631d5ce4  mulpd xmm4, xmm9
00007767631d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007767631d5cee  ptest xmm3, xmm3
00007767631d5cf3  jnz 0x00007767631D7832
00007767631d5cf9  lea r14, [rax+0xE0]
00007767631d5d00  movups xmm15, [r13+r14*1]
00007767631d5d06  vmovaps xmm9, [rsp+0x70]
00007767631d5d0c  vpermilpd xmm9, xmm9, 0x00
00007767631d5d12  vmovaps [rsp+0x70], xmm1
00007767631d5d18  vmovaps xmm1, [rsp+0x80]
00007767631d5d21  vmovaps [rsp+0x80], xmm15
00007767631d5d2a  movaps xmm3, xmm1
00007767631d5d2d  mulpd xmm3, xmm9
00007767631d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007767631d5d37  ptest xmm15, xmm15
00007767631d5d3d  jnz 0x00007767631D797E
00007767631d5d43  vmovaps xmm1, [rsp+0xF0]
00007767631d5d4c  vmovaps xmm15, [rsp+0xF0]
00007767631d5d55  por xmm1, xmm15
00007767631d5d5a  movaps [r15+0x300], xmm1
00007767631d5d62  vmovaps xmm15, [rsp+0xE0]
00007767631d5d6b  vmovaps xmm9, [rsp+0xE0]
00007767631d5d74  por xmm15, xmm9
00007767631d5d79  movaps [r15+0x190], xmm15
00007767631d5d81  vmovaps xmm9, [rsp+0x50]
00007767631d5d87  vpermilpd xmm9, xmm9, 0x00
00007767631d5d8d  vmovaps [rsp+0x90], xmm1
00007767631d5d96  vmovaps [rsp+0xE0], xmm15
00007767631d5d9f  vmovaps xmm15, [rsp+0x80]
00007767631d5da8  vmovaps [rsp+0x80], xmm14
00007767631d5db1  movaps xmm1, xmm15
00007767631d5db5  mulpd xmm1, xmm9
00007767631d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007767631d5dbf  ptest xmm14, xmm14
00007767631d5dc5  jnz 0x00007767631D7ABF
00007767631d5dcb  lea r14, [rax+0x90]
00007767631d5dd2  movups xmm15, [r13+r14*1]
00007767631d5dd8  vmovaps xmm14, [rsp+0xD0]
00007767631d5de1  vmovaps xmm9, [rsp+0xD0]
00007767631d5dea  por xmm14, xmm9
00007767631d5def  movaps [r15+0x1C0], xmm14
00007767631d5df7  vmovaps xmm9, [rsp+0xC0]
00007767631d5e00  vmovaps [rsp+0xD0], xmm1
00007767631d5e09  vmovaps xmm1, [rsp+0xC0]
00007767631d5e12  por xmm9, xmm1
00007767631d5e17  movaps [r15+0x200], xmm9
00007767631d5e1f  vmovaps [rsp+0xC0], xmm2
00007767631d5e28  vmovaps xmm1, [rsp+0xC0]
00007767631d5e31  por xmm2, xmm1
00007767631d5e35  movaps [r15+0x2D0], xmm2
00007767631d5e3d  vmovaps [rsp+0xC0], xmm8
00007767631d5e46  vmovaps xmm1, [rsp+0xC0]
00007767631d5e4f  por xmm8, xmm1
00007767631d5e54  movaps [r15+0x2E0], xmm8
00007767631d5e5c  vmovaps [rsp+0xC0], xmm15
00007767631d5e65  movaps xmm1, xmm5
00007767631d5e68  addpd xmm1, xmm7
00007767631d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007767631d5e71  ptest xmm15, xmm15
00007767631d5e77  jnz 0x00007767631D7C0B
00007767631d5e7d  vmovaps xmm15, [rsp+0x50]
00007767631d5e83  vpermilpd xmm15, xmm15, 0x00
00007767631d5e89  vmovaps xmm5, [rsp+0xC0]
00007767631d5e92  vmovaps [rsp+0xC0], xmm1
00007767631d5e9b  movaps xmm7, xmm5
00007767631d5e9e  mulpd xmm7, xmm15
00007767631d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007767631d5ea8  ptest xmm1, xmm1
00007767631d5ead  jnz 0x00007767631D7D4B
00007767631d5eb3  lea r14, [rax+0x80]
00007767631d5eba  movups xmm1, [r13+r14*1]
00007767631d5ec0  vmovaps xmm5, [rsp+0x70]
00007767631d5ec6  vmovaps [rsp+0x70], xmm1
00007767631d5ecc  movaps xmm15, xmm5
00007767631d5ed0  addpd xmm15, xmm3
00007767631d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007767631d5edb  ptest xmm1, xmm1
00007767631d5ee0  jnz 0x00007767631D7E96
00007767631d5ee6  vmovaps xmm5, [rsp+0x80]
00007767631d5eef  movaps xmm1, xmm5
00007767631d5ef2  addpd xmm1, xmm4
00007767631d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007767631d5efb  ptest xmm3, xmm3
00007767631d5f00  jnz 0x00007767631D7FD8
00007767631d5f06  vmovaps [rsp+0x80], xmm10
00007767631d5f0f  vmovaps xmm5, [rsp+0x80]
00007767631d5f18  por xmm10, xmm5
00007767631d5f1d  movaps [r15+0x2F0], xmm10
00007767631d5f25  vmovaps xmm5, [rsp+0x50]
00007767631d5f2b  vpermilpd xmm5, xmm5, 0x00
00007767631d5f31  vmovaps xmm3, [rsp+0x70]
00007767631d5f37  vmovaps [rsp+0x50], xmm1
00007767631d5f3d  movaps xmm4, xmm3
00007767631d5f40  mulpd xmm4, xmm5
00007767631d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007767631d5f49  ptest xmm1, xmm1
00007767631d5f4e  jnz 0x00007767631D8118
00007767631d5f54  lea r14, [rax+0xD0]
00007767631d5f5b  movups xmm1, [r13+r14*1]
00007767631d5f61  vmovaps xmm3, [rsp+0xD0]
00007767631d5f6a  vmovaps [rsp+0x70], xmm1
00007767631d5f70  movaps xmm5, xmm6
00007767631d5f73  addpd xmm5, xmm3
00007767631d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007767631d5f7c  ptest xmm1, xmm1
00007767631d5f81  jnz 0x00007767631D8262
00007767631d5f87  vmovaps xmm1, [rsp+0x60]
00007767631d5f8d  vpermilpd xmm1, xmm1, 0x00
00007767631d5f93  movaps xmm6, xmm9
00007767631d5f97  mulpd xmm6, xmm1
00007767631d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007767631d5fa0  ptest xmm3, xmm3
00007767631d5fa5  jnz 0x00007767631D83A2
00007767631d5fab  movaps [r15+0x260], xmm6
00007767631d5fb3  vxorps xmm1, xmm1, xmm1
00007767631d5fb7  vpbroadcastq xmm1, xmm1
00007767631d5fbc  movaps [r15+0x1B0], xmm1
00007767631d5fc4  vmovaps xmm1, [rsp+0x60]
00007767631d5fca  vpermilpd xmm1, xmm1, 0x00
00007767631d5fd0  vmovaps xmm3, [rsp+0x70]
00007767631d5fd6  vmovaps [rsp+0x70], xmm15
00007767631d5fdc  movaps xmm9, xmm3
00007767631d5fe0  mulpd xmm9, xmm1
00007767631d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007767631d5feb  ptest xmm15, xmm15
00007767631d5ff1  jnz 0x00007767631D84E3
00007767631d5ff7  lea r14, [rax+0xC0]
00007767631d5ffe  movups xmm1, [r13+r14*1]
00007767631d6004  vmovaps xmm3, [rsp+0xC0]
00007767631d600d  vmovaps [rsp+0x80], xmm1
00007767631d6016  movaps xmm15, xmm3
00007767631d601a  addpd xmm15, xmm7
00007767631d601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007767631d6025  ptest xmm1, xmm1
00007767631d602a  jnz 0x00007767631D862F
00007767631d6030  vmovaps [rsp+0xC0], xmm13
00007767631d6039  vmovaps xmm1, [rsp+0xC0]
00007767631d6042  por xmm13, xmm1
00007767631d6047  movaps [r15+0x270], xmm13
00007767631d604f  vmovaps xmm1, [rsp+0xB0]
00007767631d6058  vmovaps xmm7, [rsp+0xB0]
00007767631d6061  por xmm1, xmm7
00007767631d6065  movaps [r15+0x1A0], xmm1
00007767631d606d  vmovaps xmm1, [rsp+0x60]
00007767631d6073  vpermilpd xmm1, xmm1, 0x00
00007767631d6079  vmovaps [rsp+0xB0], xmm1
00007767631d6082  vmovaps xmm1, [rsp+0x80]
00007767631d608b  vmovaps [rsp+0x80], xmm15
00007767631d6094  vmovaps xmm15, [rsp+0xB0]
00007767631d609d  vmovaps [rsp+0xB0], xmm14
00007767631d60a6  movaps xmm3, xmm1
00007767631d60a9  mulpd xmm3, xmm15
00007767631d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007767631d60b3  ptest xmm14, xmm14
00007767631d60b9  jnz 0x00007767631D8771
00007767631d60bf  lea r14, [rax+0x20]
00007767631d60c3  movups xmm1, [r13+r14*1]
00007767631d60c9  movaps [r15+0x110], xmm1
00007767631d60d1  vmovaps xmm14, [rsp+0x70]
00007767631d60d7  vmovaps [rsp+0x70], xmm1
00007767631d60dd  movaps xmm15, xmm14
00007767631d60e1  addpd xmm15, xmm4
00007767631d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007767631d60ec  ptest xmm1, xmm1
00007767631d60f1  jnz 0x00007767631D88BC
00007767631d60f7  vmovaps xmm1, [rsp+0x60]
00007767631d60fd  vpermilpd xmm1, xmm1, 0x00
00007767631d6103  movaps xmm14, xmm2
00007767631d6107  mulpd xmm14, xmm1
00007767631d610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007767631d6112  ptest xmm4, xmm4
00007767631d6117  jnz 0x00007767631D89FF
00007767631d611d  vmovaps xmm4, [rsp+0x50]
00007767631d6123  movaps xmm1, xmm4
00007767631d6126  addpd xmm1, xmm9
00007767631d612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007767631d6130  ptest xmm2, xmm2
00007767631d6135  jnz 0x00007767631D8B41
00007767631d613b  vmovaps xmm9, [rsp+0x30]
00007767631d6141  vpermilpd xmm9, xmm9, 0x00
00007767631d6147  vmovaps xmm2, [rsp+0x70]
00007767631d614d  vmovaps [rsp+0x50], xmm1
00007767631d6153  movaps xmm4, xmm2
00007767631d6156  mulpd xmm4, xmm9
00007767631d615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007767631d6160  ptest xmm1, xmm1
00007767631d6165  jnz 0x00007767631D8C82
00007767631d616b  vmovaps xmm1, [rsp+0x30]
00007767631d6171  vpermilpd xmm1, xmm1, 0x00
00007767631d6177  vmovaps xmm2, [rsp+0x90]
00007767631d6180  vmovaps [rsp+0x60], xmm15
00007767631d6186  movaps xmm9, xmm2
00007767631d618a  mulpd xmm9, xmm1
00007767631d618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007767631d6195  ptest xmm15, xmm15
00007767631d619b  jnz 0x00007767631D8DC3
00007767631d61a1  vmovaps xmm15, [rsp+0x80]
00007767631d61aa  movaps xmm1, xmm15
00007767631d61ae  addpd xmm1, xmm6
00007767631d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007767631d61b7  ptest xmm2, xmm2
00007767631d61bc  jnz 0x00007767631D8F05
00007767631d61c2  movaps xmm15, xmm5
00007767631d61c6  addpd xmm15, xmm3
00007767631d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007767631d61d1  ptest xmm6, xmm6
00007767631d61d6  jnz 0x00007767631D9046
00007767631d61dc  vmovaps xmm6, [rsp+0x30]
00007767631d61e2  vpermilpd xmm6, xmm6, 0x00
00007767631d61e8  movaps xmm5, xmm8
00007767631d61ec  mulpd xmm5, xmm6
00007767631d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007767631d61f5  ptest xmm3, xmm3
00007767631d61fa  jnz 0x00007767631D9188
00007767631d6200  vmovaps xmm8, [rsp+0x30]
00007767631d6206  vpermilpd xmm8, xmm8, 0x00
00007767631d620c  movaps xmm6, xmm10
00007767631d6210  mulpd xmm6, xmm8
00007767631d6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007767631d621a  ptest xmm3, xmm3
00007767631d621f  jnz 0x00007767631D92C9
00007767631d6225  vmovaps xmm8, [rsp+0x60]
00007767631d622b  movaps xmm10, xmm8
00007767631d622f  addpd xmm10, xmm14
00007767631d6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007767631d623a  ptest xmm3, xmm3
00007767631d623f  jnz 0x00007767631D940B
00007767631d6245  vmovaps xmm8, [rsp+0x50]
00007767631d624b  movaps xmm14, xmm8
00007767631d624f  addpd xmm14, xmm4
00007767631d6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007767631d625a  ptest xmm3, xmm3
00007767631d625f  jnz 0x00007767631D954F
00007767631d6265  vmovaps xmm8, [rsp+0x40]
00007767631d626b  vpermilpd xmm8, xmm8, 0x00
00007767631d6271  movaps xmm4, xmm13
00007767631d6275  mulpd xmm4, xmm8
00007767631d627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007767631d627f  ptest xmm3, xmm3
00007767631d6284  jnz 0x00007767631D9692
00007767631d628a  movaps xmm13, xmm15
00007767631d628e  addpd xmm13, xmm9
00007767631d6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007767631d6299  ptest xmm8, xmm8
00007767631d629f  jnz 0x00007767631D97D4
00007767631d62a5  movaps xmm15, xmm1
00007767631d62a9  addpd xmm15, xmm5
00007767631d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007767631d62b4  ptest xmm9, xmm9
00007767631d62ba  jnz 0x00007767631D9918
00007767631d62c0  vmovaps [rsp+0x30], xmm11
00007767631d62c6  vmovaps xmm1, [rsp+0x30]
00007767631d62cc  por xmm11, xmm1
00007767631d62d1  movaps [r15+0x250], xmm11
00007767631d62d9  vmovaps [rsp+0x30], xmm12
00007767631d62df  vmovaps xmm1, [rsp+0x30]
00007767631d62e5  por xmm12, xmm1
00007767631d62ea  movaps [r15+0x2A0], xmm12
00007767631d62f2  vmovaps xmm1, [rsp+0xA0]
00007767631d62fb  vmovaps xmm11, [rsp+0xA0]
00007767631d6304  por xmm1, xmm11
00007767631d6309  movaps [r15+0x1D0], xmm1
00007767631d6311  lea r14, [rax+0x40]
00007767631d6315  movups xmm1, [r13+r14*1]
00007767631d631b  movaps [r15+0x2C0], xmm1
00007767631d6323  vmovaps xmm11, [rsp+0x40]
00007767631d6329  vpermilpd xmm11, xmm11, 0x00
00007767631d632f  vmovaps xmm8, [rsp+0xE0]
00007767631d6338  movaps xmm9, xmm8
00007767631d633c  mulpd xmm9, xmm11
00007767631d6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007767631d6347  ptest xmm5, xmm5
00007767631d634c  jnz 0x00007767631D9A64
00007767631d6352  movaps xmm11, xmm10
00007767631d6356  addpd xmm11, xmm6
00007767631d635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007767631d6361  ptest xmm8, xmm8
00007767631d6367  jnz 0x00007767631D9BA8
00007767631d636d  movaps xmm10, xmm14
00007767631d6371  addpd xmm10, xmm4
00007767631d6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007767631d637c  ptest xmm8, xmm8
00007767631d6382  jnz 0x00007767631D9CEB
00007767631d6388  vmovaps xmm14, [rsp+0x40]
00007767631d638e  vpermilpd xmm14, xmm14, 0x00
00007767631d6394  movaps xmm8, xmm1
00007767631d6398  mulpd xmm8, xmm14
00007767631d639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007767631d63a3  ptest xmm6, xmm6
00007767631d63a8  jnz 0x00007767631D9E2E
00007767631d63ae  movaps xmm1, [r15+0x2B0]
00007767631d63b6  vmovaps xmm14, [rsp+0x40]
00007767631d63bc  vpermilpd xmm14, xmm14, 0x00
00007767631d63c2  movaps xmm6, xmm1
00007767631d63c5  mulpd xmm6, xmm14
00007767631d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007767631d63cf  ptest xmm5, xmm5
00007767631d63d4  jnz 0x00007767631D9F71
00007767631d63da  vmovaps xmm1, [rsp+0x10]
00007767631d63e0  vpermilpd xmm1, xmm1, 0x00
00007767631d63e6  movaps xmm14, xmm12
00007767631d63ea  mulpd xmm14, xmm1
00007767631d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007767631d63f5  ptest xmm5, xmm5
00007767631d63fa  jnz 0x00007767631DA0B2
00007767631d6400  movaps xmm1, xmm13
00007767631d6404  addpd xmm1, xmm9
00007767631d6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007767631d640e  ptest xmm12, xmm12
00007767631d6414  jnz 0x00007767631DA1F5
00007767631d641a  vmovaps xmm13, [rsp+0x10]
00007767631d6420  vpermilpd xmm13, xmm13, 0x00
00007767631d6426  movaps xmm12, xmm7
00007767631d642a  mulpd xmm12, xmm13
00007767631d642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007767631d6435  ptest xmm9, xmm9
00007767631d643b  jnz 0x00007767631DA337
00007767631d6441  movaps xmm13, xmm15
00007767631d6445  addpd xmm13, xmm8
00007767631d644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007767631d6450  ptest xmm9, xmm9
00007767631d6456  jnz 0x00007767631DA47A
00007767631d645c  movaps xmm15, [r15+0x290]
00007767631d6464  vmovaps xmm9, [rsp+0x10]
00007767631d646a  vpermilpd xmm9, xmm9, 0x00
00007767631d6470  movaps xmm8, xmm15
00007767631d6474  mulpd xmm8, xmm9
00007767631d6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007767631d647f  ptest xmm7, xmm7
00007767631d6484  jnz 0x00007767631DA5BE
00007767631d648a  movaps xmm15, xmm11
00007767631d648e  addpd xmm15, xmm6
00007767631d6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007767631d6499  ptest xmm9, xmm9
00007767631d649f  jnz 0x00007767631DA702
00007767631d64a5  movaps xmm11, [r15+0x1E0]
00007767631d64ad  vmovaps xmm9, [rsp+0x10]
00007767631d64b3  vpermilpd xmm9, xmm9, 0x00
00007767631d64b9  movaps xmm7, xmm11
00007767631d64bd  mulpd xmm7, xmm9
00007767631d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007767631d64c7  ptest xmm6, xmm6
00007767631d64cc  jnz 0x00007767631DA845
00007767631d64d2  movaps xmm11, xmm10
00007767631d64d6  addpd xmm11, xmm14
00007767631d64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007767631d64e1  ptest xmm9, xmm9
00007767631d64e7  jnz 0x00007767631DA987
00007767631d64ed  lea r14, [rax+0x70]
00007767631d64f1  movups xmm14, [r13+r14*1]
00007767631d64f7  movaps [r15+0x240], xmm14
00007767631d64ff  movaps xmm10, xmm1
00007767631d6503  addpd xmm10, xmm12
00007767631d6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007767631d650e  ptest xmm9, xmm9
00007767631d6514  jnz 0x00007767631DAAD5
00007767631d651a  movaps [r15+0x170], xmm10
00007767631d6522  vmovaps xmm1, [rsp+0x20]
00007767631d6528  vpermilpd xmm1, xmm1, 0x00
00007767631d652e  movaps xmm12, xmm14
00007767631d6532  mulpd xmm12, xmm1
00007767631d6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007767631d653d  ptest xmm9, xmm9
00007767631d6543  jnz 0x00007767631DAC18
00007767631d6549  vmovaps xmm1, [rsp+0x20]
00007767631d654f  vpermilpd xmm1, xmm1, 0x00
00007767631d6555  vmovaps xmm9, [rsp+0xB0]
00007767631d655e  movaps xmm14, xmm9
00007767631d6562  mulpd xmm14, xmm1
00007767631d6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007767631d656d  ptest xmm6, xmm6
00007767631d6572  jnz 0x00007767631DAD5B
00007767631d6578  movaps [r15+0x180], xmm14
00007767631d6580  movaps xmm1, xmm13
00007767631d6584  addpd xmm1, xmm8
00007767631d6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007767631d658e  ptest xmm9, xmm9
00007767631d6594  jnz 0x00007767631DAE9E
00007767631d659a  movaps [r15+0x210], xmm1
00007767631d65a2  movups xmm13, [r13+rax*1]
00007767631d65a8  lea r14, [rax+0x10]
00007767631d65ac  movups xmm9, [r13+r14*1]
00007767631d65b2  movaps [r15+0x230], xmm9
00007767631d65ba  movaps xmm8, xmm15
00007767631d65be  addpd xmm8, xmm7
00007767631d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007767631d65c9  ptest xmm6, xmm6
00007767631d65ce  jnz 0x00007767631DAFF4
00007767631d65d4  movaps [r15+0x130], xmm8
00007767631d65dc  vmovaps xmm15, [rsp+0x20]
00007767631d65e2  vpermilpd xmm15, xmm15, 0x00
00007767631d65e8  movaps xmm7, xmm9
00007767631d65ec  mulpd xmm7, xmm15
00007767631d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007767631d65f6  ptest xmm6, xmm6
00007767631d65fb  jnz 0x00007767631DB137
00007767631d6601  movaps [r15+0x220], xmm7
00007767631d6609  vmovaps xmm15, [rsp+0x20]
00007767631d660f  vpermilpd xmm15, xmm15, 0x00
00007767631d6615  movaps xmm9, xmm13
00007767631d6619  mulpd xmm9, xmm15
00007767631d661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007767631d6624  ptest xmm6, xmm6
00007767631d6629  jnz 0x00007767631DB279
00007767631d662f  movaps xmm15, xmm11
00007767631d6633  addpd xmm15, xmm12
00007767631d6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007767631d663e  ptest xmm13, xmm13
00007767631d6644  jnz 0x00007767631DB3BD
00007767631d664a  movaps [r15+0x140], xmm15
00007767631d6652  movaps xmm13, xmm10
00007767631d6656  addpd xmm13, xmm14
00007767631d665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007767631d6661  ptest xmm12, xmm12
00007767631d6667  jnz 0x00007767631DB501
00007767631d666d  movaps [r15+0x150], xmm13
00007767631d6675  movaps xmm14, xmm1
00007767631d6679  addpd xmm14, xmm7
00007767631d667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007767631d6684  ptest xmm12, xmm12
00007767631d668a  jnz 0x00007767631DB645
00007767631d6690  movaps [r15+0x160], xmm14
00007767631d6698  movaps xmm1, xmm8
00007767631d669c  addpd xmm1, xmm9
00007767631d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007767631d66a6  ptest xmm12, xmm12
00007767631d66ac  jnz 0x00007767631DB787
00007767631d66b2  movaps [r15+0x120], xmm1
00007767631d66ba  movups [r13+r11*1], xmm15
00007767631d66c0  lea rax, [r11+0x10]
00007767631d66c4  movups [r13+rax*1], xmm13
00007767631d66ca  lea rax, [r11+0x20]
00007767631d66ce  movups [r13+rax*1], xmm14
00007767631d66d4  lea rax, [r11+0x30]
00007767631d66d8  movups [r13+rax*1], xmm1
00007767631d66de  mov eax, [r15+0x108]
00007767631d66e5  sahf
00007767631d66e6  jnz 0x00007767631D6718
00007767631d66e8  cmp dword ptr [r15+0x318], 0x00
00007767631d66f0  jz 0x00007767631DB900
00007767631d66f6  nop [rax+rax*1], ax
00007767631d66ff  nop [rax+rax*1], eax
00007767631d6707  mov eax, 0x410444
00007767631d670c  mov [r15+0x100], rax
00007767631d6713  jmp 0x0000776762FFE110
00007767631d6718  cmp dword ptr [r15+0x318], 0x00
00007767631d6720  jz 0x00007767631D57E0
00007767631d6726  nop [rax+rax*1], ax
00007767631d672f  nop [rax+rax*1], eax
00007767631d6737  mov eax, 0x410278
00007767631d673c  mov [r15+0x100], rax
00007767631d6743  jmp 0x0000776762FFE110
00007767631d6748  int3
00007767631d6749  call 0x000077676300A4B0
00007767631d674e  jmp 0x00007767631D5828
00007767631d6753  call 0x0000776763009240
00007767631d6758  jmp 0x00007767631D5832
00007767631d675d  call 0x000077676300A4B0
00007767631d6762  jmp 0x00007767631D588F
00007767631d6767  call 0x0000776763009240
00007767631d676c  jmp 0x00007767631D5899
00007767631d6771  call 0x000077676300A4B0
00007767631d6776  jmp 0x00007767631D58DD
00007767631d677b  call 0x0000776763009240
00007767631d6780  jmp 0x00007767631D58E7
00007767631d6785  call 0x00007767630B47C0
00007767631d678a  jmp 0x00007767631D5926
00007767631d678f  call 0x000077676300B720
00007767631d6794  jmp 0x00007767631D593A
00007767631d6799  call 0x00007767630BFC30
00007767631d679e  jmp 0x00007767631D5958
00007767631d67a3  call 0x00007767630BE9C0
00007767631d67a8  jmp 0x00007767631D5962
00007767631d67ad  call 0x00007767630BD750
00007767631d67b2  jmp 0x00007767631D596C
00007767631d67b7  sub rsp, 0x08
00007767631d67bb  push rax
00007767631d67bc  push rcx
00007767631d67bd  push rdx
00007767631d67be  push rdi
00007767631d67bf  push rsi
00007767631d67c0  push r8
00007767631d67c2  push r9
00007767631d67c4  push r10
00007767631d67c6  push r11
00007767631d67c8  sub rsp, 0xF0
00007767631d67cf  vmovaps [rsp], xmm0
00007767631d67d4  vmovaps [rsp+0x10], xmm1
00007767631d67da  vmovaps [rsp+0x20], xmm2
00007767631d67e0  vmovaps [rsp+0x30], xmm3
00007767631d67e6  vmovaps [rsp+0x40], xmm4
00007767631d67ec  vmovaps [rsp+0x50], xmm5
00007767631d67f2  vmovaps [rsp+0x60], xmm6
00007767631d67f8  vmovaps [rsp+0x70], xmm7
00007767631d67fe  vmovaps [rsp+0x80], xmm9
00007767631d6807  vmovaps [rsp+0x90], xmm10
00007767631d6810  vmovaps [rsp+0xA0], xmm11
00007767631d6819  vmovaps [rsp+0xB0], xmm12
00007767631d6822  vmovaps [rsp+0xC0], xmm13
00007767631d682b  vmovaps [rsp+0xD0], xmm14
00007767631d6834  vmovaps [rsp+0xE0], xmm15
00007767631d683d  sub rsp, 0x30
00007767631d6841  movaps [rsp], xmm8
00007767631d6846  movaps [rsp+0x10], xmm12
00007767631d684c  movaps [rsp+0x20], xmm15
00007767631d6852  lea rdi, [rsp]
00007767631d6856  mov esi, 0x00
00007767631d685b  mov rax, 0x617961CDB530
00007767631d6865  call rax
00007767631d6867  movaps xmm8, [rsp]
00007767631d686c  add rsp, 0x30
00007767631d6870  vmovaps xmm0, [rsp]
00007767631d6875  vmovaps xmm1, [rsp+0x10]
00007767631d687b  vmovaps xmm2, [rsp+0x20]
00007767631d6881  vmovaps xmm3, [rsp+0x30]
00007767631d6887  vmovaps xmm4, [rsp+0x40]
00007767631d688d  vmovaps xmm5, [rsp+0x50]
00007767631d6893  vmovaps xmm6, [rsp+0x60]
00007767631d6899  vmovaps xmm7, [rsp+0x70]
00007767631d689f  vmovaps xmm9, [rsp+0x80]
00007767631d68a8  vmovaps xmm10, [rsp+0x90]
00007767631d68b1  vmovaps xmm11, [rsp+0xA0]
00007767631d68ba  vmovaps xmm12, [rsp+0xB0]
00007767631d68c3  vmovaps xmm13, [rsp+0xC0]
00007767631d68cc  vmovaps xmm14, [rsp+0xD0]
00007767631d68d5  vmovaps xmm15, [rsp+0xE0]
00007767631d68de  add rsp, 0xF0
00007767631d68e5  pop r11
00007767631d68e7  pop r10
00007767631d68e9  pop r9
00007767631d68eb  pop r8
00007767631d68ed  pop rsi
00007767631d68ee  pop rdi
00007767631d68ef  pop rdx
00007767631d68f0  pop rcx
00007767631d68f1  pop rax
00007767631d68f2  add rsp, 0x08
00007767631d68f6  jmp 0x00007767631D599A
00007767631d68fb  sub rsp, 0x08
00007767631d68ff  push rax
00007767631d6900  push rcx
00007767631d6901  push rdx
00007767631d6902  push rdi
00007767631d6903  push rsi
00007767631d6904  push r8
00007767631d6906  push r9
00007767631d6908  push r10
00007767631d690a  push r11
00007767631d690c  sub rsp, 0xF0
00007767631d6913  vmovaps [rsp], xmm0
00007767631d6918  vmovaps [rsp+0x10], xmm1
00007767631d691e  vmovaps [rsp+0x20], xmm2
00007767631d6924  vmovaps [rsp+0x30], xmm3
00007767631d692a  vmovaps [rsp+0x40], xmm4
00007767631d6930  vmovaps [rsp+0x50], xmm5
00007767631d6936  vmovaps [rsp+0x60], xmm6
00007767631d693c  vmovaps [rsp+0x70], xmm8
00007767631d6942  vmovaps [rsp+0x80], xmm9
00007767631d694b  vmovaps [rsp+0x90], xmm10
00007767631d6954  vmovaps [rsp+0xA0], xmm11
00007767631d695d  vmovaps [rsp+0xB0], xmm12
00007767631d6966  vmovaps [rsp+0xC0], xmm13
00007767631d696f  vmovaps [rsp+0xD0], xmm14
00007767631d6978  vmovaps [rsp+0xE0], xmm15
00007767631d6981  sub rsp, 0x30
00007767631d6985  movaps [rsp], xmm7
00007767631d6989  movaps [rsp+0x10], xmm9
00007767631d698f  movaps [rsp+0x20], xmm15
00007767631d6995  lea rdi, [rsp]
00007767631d6999  mov esi, 0x00
00007767631d699e  mov rax, 0x617961CDB530
00007767631d69a8  call rax
00007767631d69aa  movaps xmm7, [rsp]
00007767631d69ae  add rsp, 0x30
00007767631d69b2  vmovaps xmm0, [rsp]
00007767631d69b7  vmovaps xmm1, [rsp+0x10]
00007767631d69bd  vmovaps xmm2, [rsp+0x20]
00007767631d69c3  vmovaps xmm3, [rsp+0x30]
00007767631d69c9  vmovaps xmm4, [rsp+0x40]
00007767631d69cf  vmovaps xmm5, [rsp+0x50]
00007767631d69d5  vmovaps xmm6, [rsp+0x60]
00007767631d69db  vmovaps xmm8, [rsp+0x70]
00007767631d69e1  vmovaps xmm9, [rsp+0x80]
00007767631d69ea  vmovaps xmm10, [rsp+0x90]
00007767631d69f3  vmovaps xmm11, [rsp+0xA0]
00007767631d69fc  vmovaps xmm12, [rsp+0xB0]
00007767631d6a05  vmovaps xmm13, [rsp+0xC0]
00007767631d6a0e  vmovaps xmm14, [rsp+0xD0]
00007767631d6a17  vmovaps xmm15, [rsp+0xE0]
00007767631d6a20  add rsp, 0xF0
00007767631d6a27  pop r11
00007767631d6a29  pop r10
00007767631d6a2b  pop r9
00007767631d6a2d  pop r8
00007767631d6a2f  pop rsi
00007767631d6a30  pop rdi
00007767631d6a31  pop rdx
00007767631d6a32  pop rcx
00007767631d6a33  pop rax
00007767631d6a34  add rsp, 0x08
00007767631d6a38  jmp 0x00007767631D59C8
00007767631d6a3d  sub rsp, 0x08
00007767631d6a41  push rax
00007767631d6a42  push rcx
00007767631d6a43  push rdx
00007767631d6a44  push rdi
00007767631d6a45  push rsi
00007767631d6a46  push r8
00007767631d6a48  push r9
00007767631d6a4a  push r10
00007767631d6a4c  push r11
00007767631d6a4e  sub rsp, 0xF0
00007767631d6a55  vmovaps [rsp], xmm0
00007767631d6a5a  vmovaps [rsp+0x10], xmm1
00007767631d6a60  vmovaps [rsp+0x20], xmm2
00007767631d6a66  vmovaps [rsp+0x30], xmm3
00007767631d6a6c  vmovaps [rsp+0x40], xmm4
00007767631d6a72  vmovaps [rsp+0x50], xmm5
00007767631d6a78  vmovaps [rsp+0x60], xmm6
00007767631d6a7e  vmovaps [rsp+0x70], xmm7
00007767631d6a84  vmovaps [rsp+0x80], xmm8
00007767631d6a8d  vmovaps [rsp+0x90], xmm10
00007767631d6a96  vmovaps [rsp+0xA0], xmm11
00007767631d6a9f  vmovaps [rsp+0xB0], xmm12
00007767631d6aa8  vmovaps [rsp+0xC0], xmm13
00007767631d6ab1  vmovaps [rsp+0xD0], xmm14
00007767631d6aba  vmovaps [rsp+0xE0], xmm15
00007767631d6ac3  sub rsp, 0x30
00007767631d6ac7  movaps [rsp], xmm9
00007767631d6acc  movaps [rsp+0x10], xmm12
00007767631d6ad2  movaps [rsp+0x20], xmm10
00007767631d6ad8  lea rdi, [rsp]
00007767631d6adc  mov esi, 0x00
00007767631d6ae1  mov rax, 0x617961CDB530
00007767631d6aeb  call rax
00007767631d6aed  movaps xmm9, [rsp]
00007767631d6af2  add rsp, 0x30
00007767631d6af6  vmovaps xmm0, [rsp]
00007767631d6afb  vmovaps xmm1, [rsp+0x10]
00007767631d6b01  vmovaps xmm2, [rsp+0x20]
00007767631d6b07  vmovaps xmm3, [rsp+0x30]
00007767631d6b0d  vmovaps xmm4, [rsp+0x40]
00007767631d6b13  vmovaps xmm5, [rsp+0x50]
00007767631d6b19  vmovaps xmm6, [rsp+0x60]
00007767631d6b1f  vmovaps xmm7, [rsp+0x70]
00007767631d6b25  vmovaps xmm8, [rsp+0x80]
00007767631d6b2e  vmovaps xmm10, [rsp+0x90]
00007767631d6b37  vmovaps xmm11, [rsp+0xA0]
00007767631d6b40  vmovaps xmm12, [rsp+0xB0]
00007767631d6b49  vmovaps xmm13, [rsp+0xC0]
00007767631d6b52  vmovaps xmm14, [rsp+0xD0]
00007767631d6b5b  vmovaps xmm15, [rsp+0xE0]
00007767631d6b64  add rsp, 0xF0
00007767631d6b6b  pop r11
00007767631d6b6d  pop r10
00007767631d6b6f  pop r9
00007767631d6b71  pop r8
00007767631d6b73  pop rsi
00007767631d6b74  pop rdi
00007767631d6b75  pop rdx
00007767631d6b76  pop rcx
00007767631d6b77  pop rax
00007767631d6b78  add rsp, 0x08
00007767631d6b7c  jmp 0x00007767631D59EC
00007767631d6b81  sub rsp, 0x08
00007767631d6b85  push rax
00007767631d6b86  push rcx
00007767631d6b87  push rdx
00007767631d6b88  push rdi
00007767631d6b89  push rsi
00007767631d6b8a  push r8
00007767631d6b8c  push r9
00007767631d6b8e  push r10
00007767631d6b90  push r11
00007767631d6b92  sub rsp, 0xF0
00007767631d6b99  vmovaps [rsp], xmm0
00007767631d6b9e  vmovaps [rsp+0x10], xmm1
00007767631d6ba4  vmovaps [rsp+0x20], xmm2
00007767631d6baa  vmovaps [rsp+0x30], xmm3
00007767631d6bb0  vmovaps [rsp+0x40], xmm4
00007767631d6bb6  vmovaps [rsp+0x50], xmm5
00007767631d6bbc  vmovaps [rsp+0x60], xmm6
00007767631d6bc2  vmovaps [rsp+0x70], xmm7
00007767631d6bc8  vmovaps [rsp+0x80], xmm8
00007767631d6bd1  vmovaps [rsp+0x90], xmm9
00007767631d6bda  vmovaps [rsp+0xA0], xmm11
00007767631d6be3  vmovaps [rsp+0xB0], xmm12
00007767631d6bec  vmovaps [rsp+0xC0], xmm13
00007767631d6bf5  vmovaps [rsp+0xD0], xmm14
00007767631d6bfe  vmovaps [rsp+0xE0], xmm15
00007767631d6c07  sub rsp, 0x30
00007767631d6c0b  movaps [rsp], xmm10
00007767631d6c10  movaps [rsp+0x10], xmm12
00007767631d6c16  movaps [rsp+0x20], xmm11
00007767631d6c1c  lea rdi, [rsp]
00007767631d6c20  mov esi, 0x00
00007767631d6c25  mov rax, 0x617961CDB530
00007767631d6c2f  call rax
00007767631d6c31  movaps xmm10, [rsp]
00007767631d6c36  add rsp, 0x30
00007767631d6c3a  vmovaps xmm0, [rsp]
00007767631d6c3f  vmovaps xmm1, [rsp+0x10]
00007767631d6c45  vmovaps xmm2, [rsp+0x20]
00007767631d6c4b  vmovaps xmm3, [rsp+0x30]
00007767631d6c51  vmovaps xmm4, [rsp+0x40]
00007767631d6c57  vmovaps xmm5, [rsp+0x50]
00007767631d6c5d  vmovaps xmm6, [rsp+0x60]
00007767631d6c63  vmovaps xmm7, [rsp+0x70]
00007767631d6c69  vmovaps xmm8, [rsp+0x80]
00007767631d6c72  vmovaps xmm9, [rsp+0x90]
00007767631d6c7b  vmovaps xmm11, [rsp+0xA0]
00007767631d6c84  vmovaps xmm12, [rsp+0xB0]
00007767631d6c8d  vmovaps xmm13, [rsp+0xC0]
00007767631d6c96  vmovaps xmm14, [rsp+0xD0]
00007767631d6c9f  vmovaps xmm15, [rsp+0xE0]
00007767631d6ca8  add rsp, 0xF0
00007767631d6caf  pop r11
00007767631d6cb1  pop r10
00007767631d6cb3  pop r9
00007767631d6cb5  pop r8
00007767631d6cb7  pop rsi
00007767631d6cb8  pop rdi
00007767631d6cb9  pop rdx
00007767631d6cba  pop rcx
00007767631d6cbb  pop rax
00007767631d6cbc  add rsp, 0x08
00007767631d6cc0  jmp 0x00007767631D5A06
00007767631d6cc5  sub rsp, 0x08
00007767631d6cc9  push rax
00007767631d6cca  push rcx
00007767631d6ccb  push rdx
00007767631d6ccc  push rdi
00007767631d6ccd  push rsi
00007767631d6cce  push r8
00007767631d6cd0  push r9
00007767631d6cd2  push r10
00007767631d6cd4  push r11
00007767631d6cd6  sub rsp, 0xF0
00007767631d6cdd  vmovaps [rsp], xmm0
00007767631d6ce2  vmovaps [rsp+0x10], xmm1
00007767631d6ce8  vmovaps [rsp+0x20], xmm2
00007767631d6cee  vmovaps [rsp+0x30], xmm3
00007767631d6cf4  vmovaps [rsp+0x40], xmm4
00007767631d6cfa  vmovaps [rsp+0x50], xmm5
00007767631d6d00  vmovaps [rsp+0x60], xmm7
00007767631d6d06  vmovaps [rsp+0x70], xmm8
00007767631d6d0c  vmovaps [rsp+0x80], xmm9
00007767631d6d15  vmovaps [rsp+0x90], xmm10
00007767631d6d1e  vmovaps [rsp+0xA0], xmm11
00007767631d6d27  vmovaps [rsp+0xB0], xmm12
00007767631d6d30  vmovaps [rsp+0xC0], xmm13
00007767631d6d39  vmovaps [rsp+0xD0], xmm14
00007767631d6d42  vmovaps [rsp+0xE0], xmm15
00007767631d6d4b  sub rsp, 0x30
00007767631d6d4f  movaps [rsp], xmm6
00007767631d6d53  movaps [rsp+0x10], xmm12
00007767631d6d59  movaps [rsp+0x20], xmm11
00007767631d6d5f  lea rdi, [rsp]
00007767631d6d63  mov esi, 0x00
00007767631d6d68  mov rax, 0x617961CDB530
00007767631d6d72  call rax
00007767631d6d74  movaps xmm6, [rsp]
00007767631d6d78  add rsp, 0x30
00007767631d6d7c  vmovaps xmm0, [rsp]
00007767631d6d81  vmovaps xmm1, [rsp+0x10]
00007767631d6d87  vmovaps xmm2, [rsp+0x20]
00007767631d6d8d  vmovaps xmm3, [rsp+0x30]
00007767631d6d93  vmovaps xmm4, [rsp+0x40]
00007767631d6d99  vmovaps xmm5, [rsp+0x50]
00007767631d6d9f  vmovaps xmm7, [rsp+0x60]
00007767631d6da5  vmovaps xmm8, [rsp+0x70]
00007767631d6dab  vmovaps xmm9, [rsp+0x80]
00007767631d6db4  vmovaps xmm10, [rsp+0x90]
00007767631d6dbd  vmovaps xmm11, [rsp+0xA0]
00007767631d6dc6  vmovaps xmm12, [rsp+0xB0]
00007767631d6dcf  vmovaps xmm13, [rsp+0xC0]
00007767631d6dd8  vmovaps xmm14, [rsp+0xD0]
00007767631d6de1  vmovaps xmm15, [rsp+0xE0]
00007767631d6dea  add rsp, 0xF0
00007767631d6df1  pop r11
00007767631d6df3  pop r10
00007767631d6df5  pop r9
00007767631d6df7  pop r8
00007767631d6df9  pop rsi
00007767631d6dfa  pop rdi
00007767631d6dfb  pop rdx
00007767631d6dfc  pop rcx
00007767631d6dfd  pop rax
00007767631d6dfe  add rsp, 0x08
00007767631d6e02  jmp 0x00007767631D5A27
00007767631d6e07  sub rsp, 0x08
00007767631d6e0b  push rax
00007767631d6e0c  push rcx
00007767631d6e0d  push rdx
00007767631d6e0e  push rdi
00007767631d6e0f  push rsi
00007767631d6e10  push r8
00007767631d6e12  push r9
00007767631d6e14  push r10
00007767631d6e16  push r11
00007767631d6e18  sub rsp, 0xF0
00007767631d6e1f  vmovaps [rsp], xmm0
00007767631d6e24  vmovaps [rsp+0x10], xmm1
00007767631d6e2a  vmovaps [rsp+0x20], xmm2
00007767631d6e30  vmovaps [rsp+0x30], xmm4
00007767631d6e36  vmovaps [rsp+0x40], xmm5
00007767631d6e3c  vmovaps [rsp+0x50], xmm6
00007767631d6e42  vmovaps [rsp+0x60], xmm7
00007767631d6e48  vmovaps [rsp+0x70], xmm8
00007767631d6e4e  vmovaps [rsp+0x80], xmm9
00007767631d6e57  vmovaps [rsp+0x90], xmm10
00007767631d6e60  vmovaps [rsp+0xA0], xmm11
00007767631d6e69  vmovaps [rsp+0xB0], xmm12
00007767631d6e72  vmovaps [rsp+0xC0], xmm13
00007767631d6e7b  vmovaps [rsp+0xD0], xmm14
00007767631d6e84  vmovaps [rsp+0xE0], xmm15
00007767631d6e8d  sub rsp, 0x30
00007767631d6e91  movaps [rsp], xmm3
00007767631d6e95  movaps [rsp+0x10], xmm5
00007767631d6e9a  movaps [rsp+0x20], xmm4
00007767631d6e9f  lea rdi, [rsp]
00007767631d6ea3  mov esi, 0x00
00007767631d6ea8  mov rax, 0x617961CDB530
00007767631d6eb2  call rax
00007767631d6eb4  movaps xmm3, [rsp]
00007767631d6eb8  add rsp, 0x30
00007767631d6ebc  vmovaps xmm0, [rsp]
00007767631d6ec1  vmovaps xmm1, [rsp+0x10]
00007767631d6ec7  vmovaps xmm2, [rsp+0x20]
00007767631d6ecd  vmovaps xmm4, [rsp+0x30]
00007767631d6ed3  vmovaps xmm5, [rsp+0x40]
00007767631d6ed9  vmovaps xmm6, [rsp+0x50]
00007767631d6edf  vmovaps xmm7, [rsp+0x60]
00007767631d6ee5  vmovaps xmm8, [rsp+0x70]
00007767631d6eeb  vmovaps xmm9, [rsp+0x80]
00007767631d6ef4  vmovaps xmm10, [rsp+0x90]
00007767631d6efd  vmovaps xmm11, [rsp+0xA0]
00007767631d6f06  vmovaps xmm12, [rsp+0xB0]
00007767631d6f0f  vmovaps xmm13, [rsp+0xC0]
00007767631d6f18  vmovaps xmm14, [rsp+0xD0]
00007767631d6f21  vmovaps xmm15, [rsp+0xE0]
00007767631d6f2a  add rsp, 0xF0
00007767631d6f31  pop r11
00007767631d6f33  pop r10
00007767631d6f35  pop r9
00007767631d6f37  pop r8
00007767631d6f39  pop rsi
00007767631d6f3a  pop rdi
00007767631d6f3b  pop rdx
00007767631d6f3c  pop rcx
00007767631d6f3d  pop rax
00007767631d6f3e  add rsp, 0x08
00007767631d6f42  jmp 0x00007767631D5A88
00007767631d6f47  sub rsp, 0x08
00007767631d6f4b  push rax
00007767631d6f4c  push rcx
00007767631d6f4d  push rdx
00007767631d6f4e  push rdi
00007767631d6f4f  push rsi
00007767631d6f50  push r8
00007767631d6f52  push r9
00007767631d6f54  push r10
00007767631d6f56  push r11
00007767631d6f58  sub rsp, 0xF0
00007767631d6f5f  vmovaps [rsp], xmm0
00007767631d6f64  vmovaps [rsp+0x10], xmm1
00007767631d6f6a  vmovaps [rsp+0x20], xmm2
00007767631d6f70  vmovaps [rsp+0x30], xmm3
00007767631d6f76  vmovaps [rsp+0x40], xmm4
00007767631d6f7c  vmovaps [rsp+0x50], xmm6
00007767631d6f82  vmovaps [rsp+0x60], xmm7
00007767631d6f88  vmovaps [rsp+0x70], xmm8
00007767631d6f8e  vmovaps [rsp+0x80], xmm9
00007767631d6f97  vmovaps [rsp+0x90], xmm10
00007767631d6fa0  vmovaps [rsp+0xA0], xmm11
00007767631d6fa9  vmovaps [rsp+0xB0], xmm12
00007767631d6fb2  vmovaps [rsp+0xC0], xmm13
00007767631d6fbb  vmovaps [rsp+0xD0], xmm14
00007767631d6fc4  vmovaps [rsp+0xE0], xmm15
00007767631d6fcd  sub rsp, 0x30
00007767631d6fd1  movaps [rsp], xmm5
00007767631d6fd5  movaps [rsp+0x10], xmm8
00007767631d6fdb  movaps [rsp+0x20], xmm15
00007767631d6fe1  lea rdi, [rsp]
00007767631d6fe5  mov esi, 0x00
00007767631d6fea  mov rax, 0x617961CDB530
00007767631d6ff4  call rax
00007767631d6ff6  movaps xmm5, [rsp]
00007767631d6ffa  add rsp, 0x30
00007767631d6ffe  vmovaps xmm0, [rsp]
00007767631d7003  vmovaps xmm1, [rsp+0x10]
00007767631d7009  vmovaps xmm2, [rsp+0x20]
00007767631d700f  vmovaps xmm3, [rsp+0x30]
00007767631d7015  vmovaps xmm4, [rsp+0x40]
00007767631d701b  vmovaps xmm6, [rsp+0x50]
00007767631d7021  vmovaps xmm7, [rsp+0x60]
00007767631d7027  vmovaps xmm8, [rsp+0x70]
00007767631d702d  vmovaps xmm9, [rsp+0x80]
00007767631d7036  vmovaps xmm10, [rsp+0x90]
00007767631d703f  vmovaps xmm11, [rsp+0xA0]
00007767631d7048  vmovaps xmm12, [rsp+0xB0]
00007767631d7051  vmovaps xmm13, [rsp+0xC0]
00007767631d705a  vmovaps xmm14, [rsp+0xD0]
00007767631d7063  vmovaps xmm15, [rsp+0xE0]
00007767631d706c  add rsp, 0xF0
00007767631d7073  pop r11
00007767631d7075  pop r10
00007767631d7077  pop r9
00007767631d7079  pop r8
00007767631d707b  pop rsi
00007767631d707c  pop rdi
00007767631d707d  pop rdx
00007767631d707e  pop rcx
00007767631d707f  pop rax
00007767631d7080  add rsp, 0x08
00007767631d7084  jmp 0x00007767631D5AC0
00007767631d7089  sub rsp, 0x08
00007767631d708d  push rax
00007767631d708e  push rcx
00007767631d708f  push rdx
00007767631d7090  push rdi
00007767631d7091  push rsi
00007767631d7092  push r8
00007767631d7094  push r9
00007767631d7096  push r10
00007767631d7098  push r11
00007767631d709a  sub rsp, 0xF0
00007767631d70a1  vmovaps [rsp], xmm0
00007767631d70a6  vmovaps [rsp+0x10], xmm1
00007767631d70ac  vmovaps [rsp+0x20], xmm2
00007767631d70b2  vmovaps [rsp+0x30], xmm3
00007767631d70b8  vmovaps [rsp+0x40], xmm5
00007767631d70be  vmovaps [rsp+0x50], xmm6
00007767631d70c4  vmovaps [rsp+0x60], xmm7
00007767631d70ca  vmovaps [rsp+0x70], xmm8
00007767631d70d0  vmovaps [rsp+0x80], xmm9
00007767631d70d9  vmovaps [rsp+0x90], xmm10
00007767631d70e2  vmovaps [rsp+0xA0], xmm11
00007767631d70eb  vmovaps [rsp+0xB0], xmm12
00007767631d70f4  vmovaps [rsp+0xC0], xmm13
00007767631d70fd  vmovaps [rsp+0xD0], xmm14
00007767631d7106  vmovaps [rsp+0xE0], xmm15
00007767631d710f  sub rsp, 0x30
00007767631d7113  movaps [rsp], xmm4
00007767631d7117  movaps [rsp+0x10], xmm9
00007767631d711d  movaps [rsp+0x20], xmm8
00007767631d7123  lea rdi, [rsp]
00007767631d7127  mov esi, 0x00
00007767631d712c  mov rax, 0x617961CDB530
00007767631d7136  call rax
00007767631d7138  movaps xmm4, [rsp]
00007767631d713c  add rsp, 0x30
00007767631d7140  vmovaps xmm0, [rsp]
00007767631d7145  vmovaps xmm1, [rsp+0x10]
00007767631d714b  vmovaps xmm2, [rsp+0x20]
00007767631d7151  vmovaps xmm3, [rsp+0x30]
00007767631d7157  vmovaps xmm5, [rsp+0x40]
00007767631d715d  vmovaps xmm6, [rsp+0x50]
00007767631d7163  vmovaps xmm7, [rsp+0x60]
00007767631d7169  vmovaps xmm8, [rsp+0x70]
00007767631d716f  vmovaps xmm9, [rsp+0x80]
00007767631d7178  vmovaps xmm10, [rsp+0x90]
00007767631d7181  vmovaps xmm11, [rsp+0xA0]
00007767631d718a  vmovaps xmm12, [rsp+0xB0]
00007767631d7193  vmovaps xmm13, [rsp+0xC0]
00007767631d719c  vmovaps xmm14, [rsp+0xD0]
00007767631d71a5  vmovaps xmm15, [rsp+0xE0]
00007767631d71ae  add rsp, 0xF0
00007767631d71b5  pop r11
00007767631d71b7  pop r10
00007767631d71b9  pop r9
00007767631d71bb  pop r8
00007767631d71bd  pop rsi
00007767631d71be  pop rdi
00007767631d71bf  pop rdx
00007767631d71c0  pop rcx
00007767631d71c1  pop rax
00007767631d71c2  add rsp, 0x08
00007767631d71c6  jmp 0x00007767631D5AE1
00007767631d71cb  sub rsp, 0x08
00007767631d71cf  push rax
00007767631d71d0  push rcx
00007767631d71d1  push rdx
00007767631d71d2  push rdi
00007767631d71d3  push rsi
00007767631d71d4  push r8
00007767631d71d6  push r9
00007767631d71d8  push r10
00007767631d71da  push r11
00007767631d71dc  sub rsp, 0xF0
00007767631d71e3  vmovaps [rsp], xmm0
00007767631d71e8  vmovaps [rsp+0x10], xmm1
00007767631d71ee  vmovaps [rsp+0x20], xmm2
00007767631d71f4  vmovaps [rsp+0x30], xmm3
00007767631d71fa  vmovaps [rsp+0x40], xmm4
00007767631d7200  vmovaps [rsp+0x50], xmm5
00007767631d7206  vmovaps [rsp+0x60], xmm6
00007767631d720c  vmovaps [rsp+0x70], xmm7
00007767631d7212  vmovaps [rsp+0x80], xmm8
00007767631d721b  vmovaps [rsp+0x90], xmm10
00007767631d7224  vmovaps [rsp+0xA0], xmm11
00007767631d722d  vmovaps [rsp+0xB0], xmm12
00007767631d7236  vmovaps [rsp+0xC0], xmm13
00007767631d723f  vmovaps [rsp+0xD0], xmm14
00007767631d7248  vmovaps [rsp+0xE0], xmm15
00007767631d7251  sub rsp, 0x30
00007767631d7255  movaps [rsp], xmm9
00007767631d725a  movaps [rsp+0x10], xmm10
00007767631d7260  movaps [rsp+0x20], xmm8
00007767631d7266  lea rdi, [rsp]
00007767631d726a  mov esi, 0x00
00007767631d726f  mov rax, 0x617961CDB530
00007767631d7279  call rax
00007767631d727b  movaps xmm9, [rsp]
00007767631d7280  add rsp, 0x30
00007767631d7284  vmovaps xmm0, [rsp]
00007767631d7289  vmovaps xmm1, [rsp+0x10]
00007767631d728f  vmovaps xmm2, [rsp+0x20]
00007767631d7295  vmovaps xmm3, [rsp+0x30]
00007767631d729b  vmovaps xmm4, [rsp+0x40]
00007767631d72a1  vmovaps xmm5, [rsp+0x50]
00007767631d72a7  vmovaps xmm6, [rsp+0x60]
00007767631d72ad  vmovaps xmm7, [rsp+0x70]
00007767631d72b3  vmovaps xmm8, [rsp+0x80]
00007767631d72bc  vmovaps xmm10, [rsp+0x90]
00007767631d72c5  vmovaps xmm11, [rsp+0xA0]
00007767631d72ce  vmovaps xmm12, [rsp+0xB0]
00007767631d72d7  vmovaps xmm13, [rsp+0xC0]
00007767631d72e0  vmovaps xmm14, [rsp+0xD0]
00007767631d72e9  vmovaps xmm15, [rsp+0xE0]
00007767631d72f2  add rsp, 0xF0
00007767631d72f9  pop r11
00007767631d72fb  pop r10
00007767631d72fd  pop r9
00007767631d72ff  pop r8
00007767631d7301  pop rsi
00007767631d7302  pop rdi
00007767631d7303  pop rdx
00007767631d7304  pop rcx
00007767631d7305  pop rax
00007767631d7306  add rsp, 0x08
00007767631d730a  jmp 0x00007767631D5AFB
00007767631d730f  call 0x00007767630D64F0
00007767631d7314  jmp 0x00007767631D5C15
00007767631d7319  call 0x00007767630D64F0
00007767631d731e  jmp 0x00007767631D5C2B
00007767631d7323  sub rsp, 0x08
00007767631d7327  push rax
00007767631d7328  push rcx
00007767631d7329  push rdx
00007767631d732a  push rdi
00007767631d732b  push rsi
00007767631d732c  push r8
00007767631d732e  push r9
00007767631d7330  push r10
00007767631d7332  push r11
00007767631d7334  sub rsp, 0xF0
00007767631d733b  vmovaps [rsp], xmm0
00007767631d7340  vmovaps [rsp+0x10], xmm2
00007767631d7346  vmovaps [rsp+0x20], xmm3
00007767631d734c  vmovaps [rsp+0x30], xmm4
00007767631d7352  vmovaps [rsp+0x40], xmm5
00007767631d7358  vmovaps [rsp+0x50], xmm6
00007767631d735e  vmovaps [rsp+0x60], xmm7
00007767631d7364  vmovaps [rsp+0x70], xmm8
00007767631d736a  vmovaps [rsp+0x80], xmm9
00007767631d7373  vmovaps [rsp+0x90], xmm10
00007767631d737c  vmovaps [rsp+0xA0], xmm11
00007767631d7385  vmovaps [rsp+0xB0], xmm12
00007767631d738e  vmovaps [rsp+0xC0], xmm13
00007767631d7397  vmovaps [rsp+0xD0], xmm14
00007767631d73a0  vmovaps [rsp+0xE0], xmm15
00007767631d73a9  sub rsp, 0x30
00007767631d73ad  movaps [rsp], xmm1
00007767631d73b1  movaps [rsp+0x10], xmm6
00007767631d73b6  movaps [rsp+0x20], xmm15
00007767631d73bc  lea rdi, [rsp]
00007767631d73c0  mov esi, 0x00
00007767631d73c5  mov rax, 0x617961CDB530
00007767631d73cf  call rax
00007767631d73d1  movaps xmm1, [rsp]
00007767631d73d5  add rsp, 0x30
00007767631d73d9  vmovaps xmm0, [rsp]
00007767631d73de  vmovaps xmm2, [rsp+0x10]
00007767631d73e4  vmovaps xmm3, [rsp+0x20]
00007767631d73ea  vmovaps xmm4, [rsp+0x30]
00007767631d73f0  vmovaps xmm5, [rsp+0x40]
00007767631d73f6  vmovaps xmm6, [rsp+0x50]
00007767631d73fc  vmovaps xmm7, [rsp+0x60]
00007767631d7402  vmovaps xmm8, [rsp+0x70]
00007767631d7408  vmovaps xmm9, [rsp+0x80]
00007767631d7411  vmovaps xmm10, [rsp+0x90]
00007767631d741a  vmovaps xmm11, [rsp+0xA0]
00007767631d7423  vmovaps xmm12, [rsp+0xB0]
00007767631d742c  vmovaps xmm13, [rsp+0xC0]
00007767631d7435  vmovaps xmm14, [rsp+0xD0]
00007767631d743e  vmovaps xmm15, [rsp+0xE0]
00007767631d7447  add rsp, 0xF0
00007767631d744e  pop r11
00007767631d7450  pop r10
00007767631d7452  pop r9
00007767631d7454  pop r8
00007767631d7456  pop rsi
00007767631d7457  pop rdi
00007767631d7458  pop rdx
00007767631d7459  pop rcx
00007767631d745a  pop rax
00007767631d745b  add rsp, 0x08
00007767631d745f  jmp 0x00007767631D5C68
00007767631d7464  call 0x00007767630E5820
00007767631d7469  jmp 0x00007767631D5C75
00007767631d746e  sub rsp, 0x08
00007767631d7472  push rax
00007767631d7473  push rcx
00007767631d7474  push rdx
00007767631d7475  push rdi
00007767631d7476  push rsi
00007767631d7477  push r8
00007767631d7479  push r9
00007767631d747b  push r10
00007767631d747d  push r11
00007767631d747f  sub rsp, 0xF0
00007767631d7486  vmovaps [rsp], xmm0
00007767631d748b  vmovaps [rsp+0x10], xmm1
00007767631d7491  vmovaps [rsp+0x20], xmm2
00007767631d7497  vmovaps [rsp+0x30], xmm3
00007767631d749d  vmovaps [rsp+0x40], xmm4
00007767631d74a3  vmovaps [rsp+0x50], xmm5
00007767631d74a9  vmovaps [rsp+0x60], xmm6
00007767631d74af  vmovaps [rsp+0x70], xmm7
00007767631d74b5  vmovaps [rsp+0x80], xmm8
00007767631d74be  vmovaps [rsp+0x90], xmm9
00007767631d74c7  vmovaps [rsp+0xA0], xmm10
00007767631d74d0  vmovaps [rsp+0xB0], xmm11
00007767631d74d9  vmovaps [rsp+0xC0], xmm12
00007767631d74e2  vmovaps [rsp+0xD0], xmm13
00007767631d74eb  vmovaps [rsp+0xE0], xmm15
00007767631d74f4  sub rsp, 0x30
00007767631d74f8  movaps [rsp], xmm14
00007767631d74fd  movaps [rsp+0x10], xmm4
00007767631d7502  movaps [rsp+0x20], xmm3
00007767631d7507  lea rdi, [rsp]
00007767631d750b  mov esi, 0x00
00007767631d7510  mov rax, 0x617961CDB530
00007767631d751a  call rax
00007767631d751c  movaps xmm14, [rsp]
00007767631d7521  add rsp, 0x30
00007767631d7525  vmovaps xmm0, [rsp]
00007767631d752a  vmovaps xmm1, [rsp+0x10]
00007767631d7530  vmovaps xmm2, [rsp+0x20]
00007767631d7536  vmovaps xmm3, [rsp+0x30]
00007767631d753c  vmovaps xmm4, [rsp+0x40]
00007767631d7542  vmovaps xmm5, [rsp+0x50]
00007767631d7548  vmovaps xmm6, [rsp+0x60]
00007767631d754e  vmovaps xmm7, [rsp+0x70]
00007767631d7554  vmovaps xmm8, [rsp+0x80]
00007767631d755d  vmovaps xmm9, [rsp+0x90]
00007767631d7566  vmovaps xmm10, [rsp+0xA0]
00007767631d756f  vmovaps xmm11, [rsp+0xB0]
00007767631d7578  vmovaps xmm12, [rsp+0xC0]
00007767631d7581  vmovaps xmm13, [rsp+0xD0]
00007767631d758a  vmovaps xmm15, [rsp+0xE0]
00007767631d7593  add rsp, 0xF0
00007767631d759a  pop r11
00007767631d759c  pop r10
00007767631d759e  pop r9
00007767631d75a0  pop r8
00007767631d75a2  pop rsi
00007767631d75a3  pop rdi
00007767631d75a4  pop rdx
00007767631d75a5  pop rcx
00007767631d75a6  pop rax
00007767631d75a7  add rsp, 0x08
00007767631d75ab  jmp 0x00007767631D5C8F
00007767631d75b0  sub rsp, 0x08
00007767631d75b4  push rax
00007767631d75b5  push rcx
00007767631d75b6  push rdx
00007767631d75b7  push rdi
00007767631d75b8  push rsi
00007767631d75b9  push r8
00007767631d75bb  push r9
00007767631d75bd  push r10
00007767631d75bf  push r11
00007767631d75c1  sub rsp, 0xF0
00007767631d75c8  vmovaps [rsp], xmm0
00007767631d75cd  vmovaps [rsp+0x10], xmm1
00007767631d75d3  vmovaps [rsp+0x20], xmm2
00007767631d75d9  vmovaps [rsp+0x30], xmm3
00007767631d75df  vmovaps [rsp+0x40], xmm4
00007767631d75e5  vmovaps [rsp+0x50], xmm5
00007767631d75eb  vmovaps [rsp+0x60], xmm7
00007767631d75f1  vmovaps [rsp+0x70], xmm8
00007767631d75f7  vmovaps [rsp+0x80], xmm9
00007767631d7600  vmovaps [rsp+0x90], xmm10
00007767631d7609  vmovaps [rsp+0xA0], xmm11
00007767631d7612  vmovaps [rsp+0xB0], xmm12
00007767631d761b  vmovaps [rsp+0xC0], xmm13
00007767631d7624  vmovaps [rsp+0xD0], xmm14
00007767631d762d  vmovaps [rsp+0xE0], xmm15
00007767631d7636  sub rsp, 0x30
00007767631d763a  movaps [rsp], xmm6
00007767631d763e  movaps [rsp+0x10], xmm9
00007767631d7644  movaps [rsp+0x20], xmm7
00007767631d7649  lea rdi, [rsp]
00007767631d764d  mov esi, 0x00
00007767631d7652  mov rax, 0x617961CDB530
00007767631d765c  call rax
00007767631d765e  movaps xmm6, [rsp]
00007767631d7662  add rsp, 0x30
00007767631d7666  vmovaps xmm0, [rsp]
00007767631d766b  vmovaps xmm1, [rsp+0x10]
00007767631d7671  vmovaps xmm2, [rsp+0x20]
00007767631d7677  vmovaps xmm3, [rsp+0x30]
00007767631d767d  vmovaps xmm4, [rsp+0x40]
00007767631d7683  vmovaps xmm5, [rsp+0x50]
00007767631d7689  vmovaps xmm7, [rsp+0x60]
00007767631d768f  vmovaps xmm8, [rsp+0x70]
00007767631d7695  vmovaps xmm9, [rsp+0x80]
00007767631d769e  vmovaps xmm10, [rsp+0x90]
00007767631d76a7  vmovaps xmm11, [rsp+0xA0]
00007767631d76b0  vmovaps xmm12, [rsp+0xB0]
00007767631d76b9  vmovaps xmm13, [rsp+0xC0]
00007767631d76c2  vmovaps xmm14, [rsp+0xD0]
00007767631d76cb  vmovaps xmm15, [rsp+0xE0]
00007767631d76d4  add rsp, 0xF0
00007767631d76db  pop r11
00007767631d76dd  pop r10
00007767631d76df  pop r9
00007767631d76e1  pop r8
00007767631d76e3  pop rsi
00007767631d76e4  pop rdi
00007767631d76e5  pop rdx
00007767631d76e6  pop rcx
00007767631d76e7  pop rax
00007767631d76e8  add rsp, 0x08
00007767631d76ec  jmp 0x00007767631D5CA7
00007767631d76f1  sub rsp, 0x08
00007767631d76f5  push rax
00007767631d76f6  push rcx
00007767631d76f7  push rdx
00007767631d76f8  push rdi
00007767631d76f9  push rsi
00007767631d76fa  push r8
00007767631d76fc  push r9
00007767631d76fe  push r10
00007767631d7700  push r11
00007767631d7702  sub rsp, 0xF0
00007767631d7709  vmovaps [rsp], xmm0
00007767631d770e  vmovaps [rsp+0x10], xmm1
00007767631d7714  vmovaps [rsp+0x20], xmm2
00007767631d771a  vmovaps [rsp+0x30], xmm3
00007767631d7720  vmovaps [rsp+0x40], xmm4
00007767631d7726  vmovaps [rsp+0x50], xmm5
00007767631d772c  vmovaps [rsp+0x60], xmm6
00007767631d7732  vmovaps [rsp+0x70], xmm8
00007767631d7738  vmovaps [rsp+0x80], xmm9
00007767631d7741  vmovaps [rsp+0x90], xmm10
00007767631d774a  vmovaps [rsp+0xA0], xmm11
00007767631d7753  vmovaps [rsp+0xB0], xmm12
00007767631d775c  vmovaps [rsp+0xC0], xmm13
00007767631d7765  vmovaps [rsp+0xD0], xmm14
00007767631d776e  vmovaps [rsp+0xE0], xmm15
00007767631d7777  sub rsp, 0x30
00007767631d777b  movaps [rsp], xmm7
00007767631d777f  movaps [rsp+0x10], xmm4
00007767631d7784  movaps [rsp+0x20], xmm9
00007767631d778a  lea rdi, [rsp]
00007767631d778e  mov esi, 0x00
00007767631d7793  mov rax, 0x617961CDB530
00007767631d779d  call rax
00007767631d779f  movaps xmm7, [rsp]
00007767631d77a3  add rsp, 0x30
00007767631d77a7  vmovaps xmm0, [rsp]
00007767631d77ac  vmovaps xmm1, [rsp+0x10]
00007767631d77b2  vmovaps xmm2, [rsp+0x20]
00007767631d77b8  vmovaps xmm3, [rsp+0x30]
00007767631d77be  vmovaps xmm4, [rsp+0x40]
00007767631d77c4  vmovaps xmm5, [rsp+0x50]
00007767631d77ca  vmovaps xmm6, [rsp+0x60]
00007767631d77d0  vmovaps xmm8, [rsp+0x70]
00007767631d77d6  vmovaps xmm9, [rsp+0x80]
00007767631d77df  vmovaps xmm10, [rsp+0x90]
00007767631d77e8  vmovaps xmm11, [rsp+0xA0]
00007767631d77f1  vmovaps xmm12, [rsp+0xB0]
00007767631d77fa  vmovaps xmm13, [rsp+0xC0]
00007767631d7803  vmovaps xmm14, [rsp+0xD0]
00007767631d780c  vmovaps xmm15, [rsp+0xE0]
00007767631d7815  add rsp, 0xF0
00007767631d781c  pop r11
00007767631d781e  pop r10
00007767631d7820  pop r9
00007767631d7822  pop r8
00007767631d7824  pop rsi
00007767631d7825  pop rdi
00007767631d7826  pop rdx
00007767631d7827  pop rcx
00007767631d7828  pop rax
00007767631d7829  add rsp, 0x08
00007767631d782d  jmp 0x00007767631D5CD4
00007767631d7832  sub rsp, 0x08
00007767631d7836  push rax
00007767631d7837  push rcx
00007767631d7838  push rdx
00007767631d7839  push rdi
00007767631d783a  push rsi
00007767631d783b  push r8
00007767631d783d  push r9
00007767631d783f  push r10
00007767631d7841  push r11
00007767631d7843  sub rsp, 0xF0
00007767631d784a  vmovaps [rsp], xmm0
00007767631d784f  vmovaps [rsp+0x10], xmm1
00007767631d7855  vmovaps [rsp+0x20], xmm2
00007767631d785b  vmovaps [rsp+0x30], xmm3
00007767631d7861  vmovaps [rsp+0x40], xmm5
00007767631d7867  vmovaps [rsp+0x50], xmm6
00007767631d786d  vmovaps [rsp+0x60], xmm7
00007767631d7873  vmovaps [rsp+0x70], xmm8
00007767631d7879  vmovaps [rsp+0x80], xmm9
00007767631d7882  vmovaps [rsp+0x90], xmm10
00007767631d788b  vmovaps [rsp+0xA0], xmm11
00007767631d7894  vmovaps [rsp+0xB0], xmm12
00007767631d789d  vmovaps [rsp+0xC0], xmm13
00007767631d78a6  vmovaps [rsp+0xD0], xmm14
00007767631d78af  vmovaps [rsp+0xE0], xmm15
00007767631d78b8  sub rsp, 0x30
00007767631d78bc  movaps [rsp], xmm4
00007767631d78c0  movaps [rsp+0x10], xmm15
00007767631d78c6  movaps [rsp+0x20], xmm9
00007767631d78cc  lea rdi, [rsp]
00007767631d78d0  mov esi, 0x00
00007767631d78d5  mov rax, 0x617961CDB530
00007767631d78df  call rax
00007767631d78e1  movaps xmm4, [rsp]
00007767631d78e5  add rsp, 0x30
00007767631d78e9  vmovaps xmm0, [rsp]
00007767631d78ee  vmovaps xmm1, [rsp+0x10]
00007767631d78f4  vmovaps xmm2, [rsp+0x20]
00007767631d78fa  vmovaps xmm3, [rsp+0x30]
00007767631d7900  vmovaps xmm5, [rsp+0x40]
00007767631d7906  vmovaps xmm6, [rsp+0x50]
00007767631d790c  vmovaps xmm7, [rsp+0x60]
00007767631d7912  vmovaps xmm8, [rsp+0x70]
00007767631d7918  vmovaps xmm9, [rsp+0x80]
00007767631d7921  vmovaps xmm10, [rsp+0x90]
00007767631d792a  vmovaps xmm11, [rsp+0xA0]
00007767631d7933  vmovaps xmm12, [rsp+0xB0]
00007767631d793c  vmovaps xmm13, [rsp+0xC0]
00007767631d7945  vmovaps xmm14, [rsp+0xD0]
00007767631d794e  vmovaps xmm15, [rsp+0xE0]
00007767631d7957  add rsp, 0xF0
00007767631d795e  pop r11
00007767631d7960  pop r10
00007767631d7962  pop r9
00007767631d7964  pop r8
00007767631d7966  pop rsi
00007767631d7967  pop rdi
00007767631d7968  pop rdx
00007767631d7969  pop rcx
00007767631d796a  pop rax
00007767631d796b  add rsp, 0x08
00007767631d796f  jmp 0x00007767631D5CF9
00007767631d7974  call 0x00007767630E5820
00007767631d7979  jmp 0x00007767631D5D06
00007767631d797e  sub rsp, 0x08
00007767631d7982  push rax
00007767631d7983  push rcx
00007767631d7984  push rdx
00007767631d7985  push rdi
00007767631d7986  push rsi
00007767631d7987  push r8
00007767631d7989  push r9
00007767631d798b  push r10
00007767631d798d  push r11
00007767631d798f  sub rsp, 0xF0
00007767631d7996  vmovaps [rsp], xmm0
00007767631d799b  vmovaps [rsp+0x10], xmm1
00007767631d79a1  vmovaps [rsp+0x20], xmm2
00007767631d79a7  vmovaps [rsp+0x30], xmm4
00007767631d79ad  vmovaps [rsp+0x40], xmm5
00007767631d79b3  vmovaps [rsp+0x50], xmm6
00007767631d79b9  vmovaps [rsp+0x60], xmm7
00007767631d79bf  vmovaps [rsp+0x70], xmm8
00007767631d79c5  vmovaps [rsp+0x80], xmm9
00007767631d79ce  vmovaps [rsp+0x90], xmm10
00007767631d79d7  vmovaps [rsp+0xA0], xmm11
00007767631d79e0  vmovaps [rsp+0xB0], xmm12
00007767631d79e9  vmovaps [rsp+0xC0], xmm13
00007767631d79f2  vmovaps [rsp+0xD0], xmm14
00007767631d79fb  vmovaps [rsp+0xE0], xmm15
00007767631d7a04  sub rsp, 0x30
00007767631d7a08  movaps [rsp], xmm3
00007767631d7a0c  movaps [rsp+0x10], xmm1
00007767631d7a11  movaps [rsp+0x20], xmm9
00007767631d7a17  lea rdi, [rsp]
00007767631d7a1b  mov esi, 0x00
00007767631d7a20  mov rax, 0x617961CDB530
00007767631d7a2a  call rax
00007767631d7a2c  movaps xmm3, [rsp]
00007767631d7a30  add rsp, 0x30
00007767631d7a34  vmovaps xmm0, [rsp]
00007767631d7a39  vmovaps xmm1, [rsp+0x10]
00007767631d7a3f  vmovaps xmm2, [rsp+0x20]
00007767631d7a45  vmovaps xmm4, [rsp+0x30]
00007767631d7a4b  vmovaps xmm5, [rsp+0x40]
00007767631d7a51  vmovaps xmm6, [rsp+0x50]
00007767631d7a57  vmovaps xmm7, [rsp+0x60]
00007767631d7a5d  vmovaps xmm8, [rsp+0x70]
00007767631d7a63  vmovaps xmm9, [rsp+0x80]
00007767631d7a6c  vmovaps xmm10, [rsp+0x90]
00007767631d7a75  vmovaps xmm11, [rsp+0xA0]
00007767631d7a7e  vmovaps xmm12, [rsp+0xB0]
00007767631d7a87  vmovaps xmm13, [rsp+0xC0]
00007767631d7a90  vmovaps xmm14, [rsp+0xD0]
00007767631d7a99  vmovaps xmm15, [rsp+0xE0]
00007767631d7aa2  add rsp, 0xF0
00007767631d7aa9  pop r11
00007767631d7aab  pop r10
00007767631d7aad  pop r9
00007767631d7aaf  pop r8
00007767631d7ab1  pop rsi
00007767631d7ab2  pop rdi
00007767631d7ab3  pop rdx
00007767631d7ab4  pop rcx
00007767631d7ab5  pop rax
00007767631d7ab6  add rsp, 0x08
00007767631d7aba  jmp 0x00007767631D5D43
00007767631d7abf  sub rsp, 0x08
00007767631d7ac3  push rax
00007767631d7ac4  push rcx
00007767631d7ac5  push rdx
00007767631d7ac6  push rdi
00007767631d7ac7  push rsi
00007767631d7ac8  push r8
00007767631d7aca  push r9
00007767631d7acc  push r10
00007767631d7ace  push r11
00007767631d7ad0  sub rsp, 0xF0
00007767631d7ad7  vmovaps [rsp], xmm0
00007767631d7adc  vmovaps [rsp+0x10], xmm2
00007767631d7ae2  vmovaps [rsp+0x20], xmm3
00007767631d7ae8  vmovaps [rsp+0x30], xmm4
00007767631d7aee  vmovaps [rsp+0x40], xmm5
00007767631d7af4  vmovaps [rsp+0x50], xmm6
00007767631d7afa  vmovaps [rsp+0x60], xmm7
00007767631d7b00  vmovaps [rsp+0x70], xmm8
00007767631d7b06  vmovaps [rsp+0x80], xmm9
00007767631d7b0f  vmovaps [rsp+0x90], xmm10
00007767631d7b18  vmovaps [rsp+0xA0], xmm11
00007767631d7b21  vmovaps [rsp+0xB0], xmm12
00007767631d7b2a  vmovaps [rsp+0xC0], xmm13
00007767631d7b33  vmovaps [rsp+0xD0], xmm14
00007767631d7b3c  vmovaps [rsp+0xE0], xmm15
00007767631d7b45  sub rsp, 0x30
00007767631d7b49  movaps [rsp], xmm1
00007767631d7b4d  movaps [rsp+0x10], xmm15
00007767631d7b53  movaps [rsp+0x20], xmm9
00007767631d7b59  lea rdi, [rsp]
00007767631d7b5d  mov esi, 0x00
00007767631d7b62  mov rax, 0x617961CDB530
00007767631d7b6c  call rax
00007767631d7b6e  movaps xmm1, [rsp]
00007767631d7b72  add rsp, 0x30
00007767631d7b76  vmovaps xmm0, [rsp]
00007767631d7b7b  vmovaps xmm2, [rsp+0x10]
00007767631d7b81  vmovaps xmm3, [rsp+0x20]
00007767631d7b87  vmovaps xmm4, [rsp+0x30]
00007767631d7b8d  vmovaps xmm5, [rsp+0x40]
00007767631d7b93  vmovaps xmm6, [rsp+0x50]
00007767631d7b99  vmovaps xmm7, [rsp+0x60]
00007767631d7b9f  vmovaps xmm8, [rsp+0x70]
00007767631d7ba5  vmovaps xmm9, [rsp+0x80]
00007767631d7bae  vmovaps xmm10, [rsp+0x90]
00007767631d7bb7  vmovaps xmm11, [rsp+0xA0]
00007767631d7bc0  vmovaps xmm12, [rsp+0xB0]
00007767631d7bc9  vmovaps xmm13, [rsp+0xC0]
00007767631d7bd2  vmovaps xmm14, [rsp+0xD0]
00007767631d7bdb  vmovaps xmm15, [rsp+0xE0]
00007767631d7be4  add rsp, 0xF0
00007767631d7beb  pop r11
00007767631d7bed  pop r10
00007767631d7bef  pop r9
00007767631d7bf1  pop r8
00007767631d7bf3  pop rsi
00007767631d7bf4  pop rdi
00007767631d7bf5  pop rdx
00007767631d7bf6  pop rcx
00007767631d7bf7  pop rax
00007767631d7bf8  add rsp, 0x08
00007767631d7bfc  jmp 0x00007767631D5DCB
00007767631d7c01  call 0x00007767630E5820
00007767631d7c06  jmp 0x00007767631D5DD8
00007767631d7c0b  sub rsp, 0x08
00007767631d7c0f  push rax
00007767631d7c10  push rcx
00007767631d7c11  push rdx
00007767631d7c12  push rdi
00007767631d7c13  push rsi
00007767631d7c14  push r8
00007767631d7c16  push r9
00007767631d7c18  push r10
00007767631d7c1a  push r11
00007767631d7c1c  sub rsp, 0xF0
00007767631d7c23  vmovaps [rsp], xmm0
00007767631d7c28  vmovaps [rsp+0x10], xmm2
00007767631d7c2e  vmovaps [rsp+0x20], xmm3
00007767631d7c34  vmovaps [rsp+0x30], xmm4
00007767631d7c3a  vmovaps [rsp+0x40], xmm5
00007767631d7c40  vmovaps [rsp+0x50], xmm6
00007767631d7c46  vmovaps [rsp+0x60], xmm7
00007767631d7c4c  vmovaps [rsp+0x70], xmm8
00007767631d7c52  vmovaps [rsp+0x80], xmm9
00007767631d7c5b  vmovaps [rsp+0x90], xmm10
00007767631d7c64  vmovaps [rsp+0xA0], xmm11
00007767631d7c6d  vmovaps [rsp+0xB0], xmm12
00007767631d7c76  vmovaps [rsp+0xC0], xmm13
00007767631d7c7f  vmovaps [rsp+0xD0], xmm14
00007767631d7c88  vmovaps [rsp+0xE0], xmm15
00007767631d7c91  sub rsp, 0x30
00007767631d7c95  movaps [rsp], xmm1
00007767631d7c99  movaps [rsp+0x10], xmm5
00007767631d7c9e  movaps [rsp+0x20], xmm7
00007767631d7ca3  lea rdi, [rsp]
00007767631d7ca7  mov esi, 0x00
00007767631d7cac  mov rax, 0x617961CDB530
00007767631d7cb6  call rax
00007767631d7cb8  movaps xmm1, [rsp]
00007767631d7cbc  add rsp, 0x30
00007767631d7cc0  vmovaps xmm0, [rsp]
00007767631d7cc5  vmovaps xmm2, [rsp+0x10]
00007767631d7ccb  vmovaps xmm3, [rsp+0x20]
00007767631d7cd1  vmovaps xmm4, [rsp+0x30]
00007767631d7cd7  vmovaps xmm5, [rsp+0x40]
00007767631d7cdd  vmovaps xmm6, [rsp+0x50]
00007767631d7ce3  vmovaps xmm7, [rsp+0x60]
00007767631d7ce9  vmovaps xmm8, [rsp+0x70]
00007767631d7cef  vmovaps xmm9, [rsp+0x80]
00007767631d7cf8  vmovaps xmm10, [rsp+0x90]
00007767631d7d01  vmovaps xmm11, [rsp+0xA0]
00007767631d7d0a  vmovaps xmm12, [rsp+0xB0]
00007767631d7d13  vmovaps xmm13, [rsp+0xC0]
00007767631d7d1c  vmovaps xmm14, [rsp+0xD0]
00007767631d7d25  vmovaps xmm15, [rsp+0xE0]
00007767631d7d2e  add rsp, 0xF0
00007767631d7d35  pop r11
00007767631d7d37  pop r10
00007767631d7d39  pop r9
00007767631d7d3b  pop r8
00007767631d7d3d  pop rsi
00007767631d7d3e  pop rdi
00007767631d7d3f  pop rdx
00007767631d7d40  pop rcx
00007767631d7d41  pop rax
00007767631d7d42  add rsp, 0x08
00007767631d7d46  jmp 0x00007767631D5E7D
00007767631d7d4b  sub rsp, 0x08
00007767631d7d4f  push rax
00007767631d7d50  push rcx
00007767631d7d51  push rdx
00007767631d7d52  push rdi
00007767631d7d53  push rsi
00007767631d7d54  push r8
00007767631d7d56  push r9
00007767631d7d58  push r10
00007767631d7d5a  push r11
00007767631d7d5c  sub rsp, 0xF0
00007767631d7d63  vmovaps [rsp], xmm0
00007767631d7d68  vmovaps [rsp+0x10], xmm1
00007767631d7d6e  vmovaps [rsp+0x20], xmm2
00007767631d7d74  vmovaps [rsp+0x30], xmm3
00007767631d7d7a  vmovaps [rsp+0x40], xmm4
00007767631d7d80  vmovaps [rsp+0x50], xmm5
00007767631d7d86  vmovaps [rsp+0x60], xmm6
00007767631d7d8c  vmovaps [rsp+0x70], xmm8
00007767631d7d92  vmovaps [rsp+0x80], xmm9
00007767631d7d9b  vmovaps [rsp+0x90], xmm10
00007767631d7da4  vmovaps [rsp+0xA0], xmm11
00007767631d7dad  vmovaps [rsp+0xB0], xmm12
00007767631d7db6  vmovaps [rsp+0xC0], xmm13
00007767631d7dbf  vmovaps [rsp+0xD0], xmm14
00007767631d7dc8  vmovaps [rsp+0xE0], xmm15
00007767631d7dd1  sub rsp, 0x30
00007767631d7dd5  movaps [rsp], xmm7
00007767631d7dd9  movaps [rsp+0x10], xmm5
00007767631d7dde  movaps [rsp+0x20], xmm15
00007767631d7de4  lea rdi, [rsp]
00007767631d7de8  mov esi, 0x00
00007767631d7ded  mov rax, 0x617961CDB530
00007767631d7df7  call rax
00007767631d7df9  movaps xmm7, [rsp]
00007767631d7dfd  add rsp, 0x30
00007767631d7e01  vmovaps xmm0, [rsp]
00007767631d7e06  vmovaps xmm1, [rsp+0x10]
00007767631d7e0c  vmovaps xmm2, [rsp+0x20]
00007767631d7e12  vmovaps xmm3, [rsp+0x30]
00007767631d7e18  vmovaps xmm4, [rsp+0x40]
00007767631d7e1e  vmovaps xmm5, [rsp+0x50]
00007767631d7e24  vmovaps xmm6, [rsp+0x60]
00007767631d7e2a  vmovaps xmm8, [rsp+0x70]
00007767631d7e30  vmovaps xmm9, [rsp+0x80]
00007767631d7e39  vmovaps xmm10, [rsp+0x90]
00007767631d7e42  vmovaps xmm11, [rsp+0xA0]
00007767631d7e4b  vmovaps xmm12, [rsp+0xB0]
00007767631d7e54  vmovaps xmm13, [rsp+0xC0]
00007767631d7e5d  vmovaps xmm14, [rsp+0xD0]
00007767631d7e66  vmovaps xmm15, [rsp+0xE0]
00007767631d7e6f  add rsp, 0xF0
00007767631d7e76  pop r11
00007767631d7e78  pop r10
00007767631d7e7a  pop r9
00007767631d7e7c  pop r8
00007767631d7e7e  pop rsi
00007767631d7e7f  pop rdi
00007767631d7e80  pop rdx
00007767631d7e81  pop rcx
00007767631d7e82  pop rax
00007767631d7e83  add rsp, 0x08
00007767631d7e87  jmp 0x00007767631D5EB3
00007767631d7e8c  call 0x00007767630D64F0
00007767631d7e91  jmp 0x00007767631D5EC0
00007767631d7e96  sub rsp, 0x08
00007767631d7e9a  push rax
00007767631d7e9b  push rcx
00007767631d7e9c  push rdx
00007767631d7e9d  push rdi
00007767631d7e9e  push rsi
00007767631d7e9f  push r8
00007767631d7ea1  push r9
00007767631d7ea3  push r10
00007767631d7ea5  push r11
00007767631d7ea7  sub rsp, 0xF0
00007767631d7eae  vmovaps [rsp], xmm0
00007767631d7eb3  vmovaps [rsp+0x10], xmm1
00007767631d7eb9  vmovaps [rsp+0x20], xmm2
00007767631d7ebf  vmovaps [rsp+0x30], xmm3
00007767631d7ec5  vmovaps [rsp+0x40], xmm4
00007767631d7ecb  vmovaps [rsp+0x50], xmm5
00007767631d7ed1  vmovaps [rsp+0x60], xmm6
00007767631d7ed7  vmovaps [rsp+0x70], xmm7
00007767631d7edd  vmovaps [rsp+0x80], xmm8
00007767631d7ee6  vmovaps [rsp+0x90], xmm9
00007767631d7eef  vmovaps [rsp+0xA0], xmm10
00007767631d7ef8  vmovaps [rsp+0xB0], xmm11
00007767631d7f01  vmovaps [rsp+0xC0], xmm12
00007767631d7f0a  vmovaps [rsp+0xD0], xmm13
00007767631d7f13  vmovaps [rsp+0xE0], xmm14
00007767631d7f1c  sub rsp, 0x30
00007767631d7f20  movaps [rsp], xmm15
00007767631d7f25  movaps [rsp+0x10], xmm5
00007767631d7f2a  movaps [rsp+0x20], xmm3
00007767631d7f2f  lea rdi, [rsp]
00007767631d7f33  mov esi, 0x00
00007767631d7f38  mov rax, 0x617961CDB530
00007767631d7f42  call rax
00007767631d7f44  movaps xmm15, [rsp]
00007767631d7f49  add rsp, 0x30
00007767631d7f4d  vmovaps xmm0, [rsp]
00007767631d7f52  vmovaps xmm1, [rsp+0x10]
00007767631d7f58  vmovaps xmm2, [rsp+0x20]
00007767631d7f5e  vmovaps xmm3, [rsp+0x30]
00007767631d7f64  vmovaps xmm4, [rsp+0x40]
00007767631d7f6a  vmovaps xmm5, [rsp+0x50]
00007767631d7f70  vmovaps xmm6, [rsp+0x60]
00007767631d7f76  vmovaps xmm7, [rsp+0x70]
00007767631d7f7c  vmovaps xmm8, [rsp+0x80]
00007767631d7f85  vmovaps xmm9, [rsp+0x90]
00007767631d7f8e  vmovaps xmm10, [rsp+0xA0]
00007767631d7f97  vmovaps xmm11, [rsp+0xB0]
00007767631d7fa0  vmovaps xmm12, [rsp+0xC0]
00007767631d7fa9  vmovaps xmm13, [rsp+0xD0]
00007767631d7fb2  vmovaps xmm14, [rsp+0xE0]
00007767631d7fbb  add rsp, 0xF0
00007767631d7fc2  pop r11
00007767631d7fc4  pop r10
00007767631d7fc6  pop r9
00007767631d7fc8  pop r8
00007767631d7fca  pop rsi
00007767631d7fcb  pop rdi
00007767631d7fcc  pop rdx
00007767631d7fcd  pop rcx
00007767631d7fce  pop rax
00007767631d7fcf  add rsp, 0x08
00007767631d7fd3  jmp 0x00007767631D5EE6
00007767631d7fd8  sub rsp, 0x08
00007767631d7fdc  push rax
00007767631d7fdd  push rcx
00007767631d7fde  push rdx
00007767631d7fdf  push rdi
00007767631d7fe0  push rsi
00007767631d7fe1  push r8
00007767631d7fe3  push r9
00007767631d7fe5  push r10
00007767631d7fe7  push r11
00007767631d7fe9  sub rsp, 0xF0
00007767631d7ff0  vmovaps [rsp], xmm0
00007767631d7ff5  vmovaps [rsp+0x10], xmm2
00007767631d7ffb  vmovaps [rsp+0x20], xmm3
00007767631d8001  vmovaps [rsp+0x30], xmm4
00007767631d8007  vmovaps [rsp+0x40], xmm5
00007767631d800d  vmovaps [rsp+0x50], xmm6
00007767631d8013  vmovaps [rsp+0x60], xmm7
00007767631d8019  vmovaps [rsp+0x70], xmm8
00007767631d801f  vmovaps [rsp+0x80], xmm9
00007767631d8028  vmovaps [rsp+0x90], xmm10
00007767631d8031  vmovaps [rsp+0xA0], xmm11
00007767631d803a  vmovaps [rsp+0xB0], xmm12
00007767631d8043  vmovaps [rsp+0xC0], xmm13
00007767631d804c  vmovaps [rsp+0xD0], xmm14
00007767631d8055  vmovaps [rsp+0xE0], xmm15
00007767631d805e  sub rsp, 0x30
00007767631d8062  movaps [rsp], xmm1
00007767631d8066  movaps [rsp+0x10], xmm5
00007767631d806b  movaps [rsp+0x20], xmm4
00007767631d8070  lea rdi, [rsp]
00007767631d8074  mov esi, 0x00
00007767631d8079  mov rax, 0x617961CDB530
00007767631d8083  call rax
00007767631d8085  movaps xmm1, [rsp]
00007767631d8089  add rsp, 0x30
00007767631d808d  vmovaps xmm0, [rsp]
00007767631d8092  vmovaps xmm2, [rsp+0x10]
00007767631d8098  vmovaps xmm3, [rsp+0x20]
00007767631d809e  vmovaps xmm4, [rsp+0x30]
00007767631d80a4  vmovaps xmm5, [rsp+0x40]
00007767631d80aa  vmovaps xmm6, [rsp+0x50]
00007767631d80b0  vmovaps xmm7, [rsp+0x60]
00007767631d80b6  vmovaps xmm8, [rsp+0x70]
00007767631d80bc  vmovaps xmm9, [rsp+0x80]
00007767631d80c5  vmovaps xmm10, [rsp+0x90]
00007767631d80ce  vmovaps xmm11, [rsp+0xA0]
00007767631d80d7  vmovaps xmm12, [rsp+0xB0]
00007767631d80e0  vmovaps xmm13, [rsp+0xC0]
00007767631d80e9  vmovaps xmm14, [rsp+0xD0]
00007767631d80f2  vmovaps xmm15, [rsp+0xE0]
00007767631d80fb  add rsp, 0xF0
00007767631d8102  pop r11
00007767631d8104  pop r10
00007767631d8106  pop r9
00007767631d8108  pop r8
00007767631d810a  pop rsi
00007767631d810b  pop rdi
00007767631d810c  pop rdx
00007767631d810d  pop rcx
00007767631d810e  pop rax
00007767631d810f  add rsp, 0x08
00007767631d8113  jmp 0x00007767631D5F06
00007767631d8118  sub rsp, 0x08
00007767631d811c  push rax
00007767631d811d  push rcx
00007767631d811e  push rdx
00007767631d811f  push rdi
00007767631d8120  push rsi
00007767631d8121  push r8
00007767631d8123  push r9
00007767631d8125  push r10
00007767631d8127  push r11
00007767631d8129  sub rsp, 0xF0
00007767631d8130  vmovaps [rsp], xmm0
00007767631d8135  vmovaps [rsp+0x10], xmm1
00007767631d813b  vmovaps [rsp+0x20], xmm2
00007767631d8141  vmovaps [rsp+0x30], xmm3
00007767631d8147  vmovaps [rsp+0x40], xmm5
00007767631d814d  vmovaps [rsp+0x50], xmm6
00007767631d8153  vmovaps [rsp+0x60], xmm7
00007767631d8159  vmovaps [rsp+0x70], xmm8
00007767631d815f  vmovaps [rsp+0x80], xmm9
00007767631d8168  vmovaps [rsp+0x90], xmm10
00007767631d8171  vmovaps [rsp+0xA0], xmm11
00007767631d817a  vmovaps [rsp+0xB0], xmm12
00007767631d8183  vmovaps [rsp+0xC0], xmm13
00007767631d818c  vmovaps [rsp+0xD0], xmm14
00007767631d8195  vmovaps [rsp+0xE0], xmm15
00007767631d819e  sub rsp, 0x30
00007767631d81a2  movaps [rsp], xmm4
00007767631d81a6  movaps [rsp+0x10], xmm3
00007767631d81ab  movaps [rsp+0x20], xmm5
00007767631d81b0  lea rdi, [rsp]
00007767631d81b4  mov esi, 0x00
00007767631d81b9  mov rax, 0x617961CDB530
00007767631d81c3  call rax
00007767631d81c5  movaps xmm4, [rsp]
00007767631d81c9  add rsp, 0x30
00007767631d81cd  vmovaps xmm0, [rsp]
00007767631d81d2  vmovaps xmm1, [rsp+0x10]
00007767631d81d8  vmovaps xmm2, [rsp+0x20]
00007767631d81de  vmovaps xmm3, [rsp+0x30]
00007767631d81e4  vmovaps xmm5, [rsp+0x40]
00007767631d81ea  vmovaps xmm6, [rsp+0x50]
00007767631d81f0  vmovaps xmm7, [rsp+0x60]
00007767631d81f6  vmovaps xmm8, [rsp+0x70]
00007767631d81fc  vmovaps xmm9, [rsp+0x80]
00007767631d8205  vmovaps xmm10, [rsp+0x90]
00007767631d820e  vmovaps xmm11, [rsp+0xA0]
00007767631d8217  vmovaps xmm12, [rsp+0xB0]
00007767631d8220  vmovaps xmm13, [rsp+0xC0]
00007767631d8229  vmovaps xmm14, [rsp+0xD0]
00007767631d8232  vmovaps xmm15, [rsp+0xE0]
00007767631d823b  add rsp, 0xF0
00007767631d8242  pop r11
00007767631d8244  pop r10
00007767631d8246  pop r9
00007767631d8248  pop r8
00007767631d824a  pop rsi
00007767631d824b  pop rdi
00007767631d824c  pop rdx
00007767631d824d  pop rcx
00007767631d824e  pop rax
00007767631d824f  add rsp, 0x08
00007767631d8253  jmp 0x00007767631D5F54
00007767631d8258  call 0x00007767630D64F0
00007767631d825d  jmp 0x00007767631D5F61
00007767631d8262  sub rsp, 0x08
00007767631d8266  push rax
00007767631d8267  push rcx
00007767631d8268  push rdx
00007767631d8269  push rdi
00007767631d826a  push rsi
00007767631d826b  push r8
00007767631d826d  push r9
00007767631d826f  push r10
00007767631d8271  push r11
00007767631d8273  sub rsp, 0xF0
00007767631d827a  vmovaps [rsp], xmm0
00007767631d827f  vmovaps [rsp+0x10], xmm1
00007767631d8285  vmovaps [rsp+0x20], xmm2
00007767631d828b  vmovaps [rsp+0x30], xmm3
00007767631d8291  vmovaps [rsp+0x40], xmm4
00007767631d8297  vmovaps [rsp+0x50], xmm6
00007767631d829d  vmovaps [rsp+0x60], xmm7
00007767631d82a3  vmovaps [rsp+0x70], xmm8
00007767631d82a9  vmovaps [rsp+0x80], xmm9
00007767631d82b2  vmovaps [rsp+0x90], xmm10
00007767631d82bb  vmovaps [rsp+0xA0], xmm11
00007767631d82c4  vmovaps [rsp+0xB0], xmm12
00007767631d82cd  vmovaps [rsp+0xC0], xmm13
00007767631d82d6  vmovaps [rsp+0xD0], xmm14
00007767631d82df  vmovaps [rsp+0xE0], xmm15
00007767631d82e8  sub rsp, 0x30
00007767631d82ec  movaps [rsp], xmm5
00007767631d82f0  movaps [rsp+0x10], xmm6
00007767631d82f5  movaps [rsp+0x20], xmm3
00007767631d82fa  lea rdi, [rsp]
00007767631d82fe  mov esi, 0x00
00007767631d8303  mov rax, 0x617961CDB530
00007767631d830d  call rax
00007767631d830f  movaps xmm5, [rsp]
00007767631d8313  add rsp, 0x30
00007767631d8317  vmovaps xmm0, [rsp]
00007767631d831c  vmovaps xmm1, [rsp+0x10]
00007767631d8322  vmovaps xmm2, [rsp+0x20]
00007767631d8328  vmovaps xmm3, [rsp+0x30]
00007767631d832e  vmovaps xmm4, [rsp+0x40]
00007767631d8334  vmovaps xmm6, [rsp+0x50]
00007767631d833a  vmovaps xmm7, [rsp+0x60]
00007767631d8340  vmovaps xmm8, [rsp+0x70]
00007767631d8346  vmovaps xmm9, [rsp+0x80]
00007767631d834f  vmovaps xmm10, [rsp+0x90]
00007767631d8358  vmovaps xmm11, [rsp+0xA0]
00007767631d8361  vmovaps xmm12, [rsp+0xB0]
00007767631d836a  vmovaps xmm13, [rsp+0xC0]
00007767631d8373  vmovaps xmm14, [rsp+0xD0]
00007767631d837c  vmovaps xmm15, [rsp+0xE0]
00007767631d8385  add rsp, 0xF0
00007767631d838c  pop r11
00007767631d838e  pop r10
00007767631d8390  pop r9
00007767631d8392  pop r8
00007767631d8394  pop rsi
00007767631d8395  pop rdi
00007767631d8396  pop rdx
00007767631d8397  pop rcx
00007767631d8398  pop rax
00007767631d8399  add rsp, 0x08
00007767631d839d  jmp 0x00007767631D5F87
00007767631d83a2  sub rsp, 0x08
00007767631d83a6  push rax
00007767631d83a7  push rcx
00007767631d83a8  push rdx
00007767631d83a9  push rdi
00007767631d83aa  push rsi
00007767631d83ab  push r8
00007767631d83ad  push r9
00007767631d83af  push r10
00007767631d83b1  push r11
00007767631d83b3  sub rsp, 0xF0
00007767631d83ba  vmovaps [rsp], xmm0
00007767631d83bf  vmovaps [rsp+0x10], xmm1
00007767631d83c5  vmovaps [rsp+0x20], xmm2
00007767631d83cb  vmovaps [rsp+0x30], xmm3
00007767631d83d1  vmovaps [rsp+0x40], xmm4
00007767631d83d7  vmovaps [rsp+0x50], xmm5
00007767631d83dd  vmovaps [rsp+0x60], xmm7
00007767631d83e3  vmovaps [rsp+0x70], xmm8
00007767631d83e9  vmovaps [rsp+0x80], xmm9
00007767631d83f2  vmovaps [rsp+0x90], xmm10
00007767631d83fb  vmovaps [rsp+0xA0], xmm11
00007767631d8404  vmovaps [rsp+0xB0], xmm12
00007767631d840d  vmovaps [rsp+0xC0], xmm13
00007767631d8416  vmovaps [rsp+0xD0], xmm14
00007767631d841f  vmovaps [rsp+0xE0], xmm15
00007767631d8428  sub rsp, 0x30
00007767631d842c  movaps [rsp], xmm6
00007767631d8430  movaps [rsp+0x10], xmm9
00007767631d8436  movaps [rsp+0x20], xmm1
00007767631d843b  lea rdi, [rsp]
00007767631d843f  mov esi, 0x00
00007767631d8444  mov rax, 0x617961CDB530
00007767631d844e  call rax
00007767631d8450  movaps xmm6, [rsp]
00007767631d8454  add rsp, 0x30
00007767631d8458  vmovaps xmm0, [rsp]
00007767631d845d  vmovaps xmm1, [rsp+0x10]
00007767631d8463  vmovaps xmm2, [rsp+0x20]
00007767631d8469  vmovaps xmm3, [rsp+0x30]
00007767631d846f  vmovaps xmm4, [rsp+0x40]
00007767631d8475  vmovaps xmm5, [rsp+0x50]
00007767631d847b  vmovaps xmm7, [rsp+0x60]
00007767631d8481  vmovaps xmm8, [rsp+0x70]
00007767631d8487  vmovaps xmm9, [rsp+0x80]
00007767631d8490  vmovaps xmm10, [rsp+0x90]
00007767631d8499  vmovaps xmm11, [rsp+0xA0]
00007767631d84a2  vmovaps xmm12, [rsp+0xB0]
00007767631d84ab  vmovaps xmm13, [rsp+0xC0]
00007767631d84b4  vmovaps xmm14, [rsp+0xD0]
00007767631d84bd  vmovaps xmm15, [rsp+0xE0]
00007767631d84c6  add rsp, 0xF0
00007767631d84cd  pop r11
00007767631d84cf  pop r10
00007767631d84d1  pop r9
00007767631d84d3  pop r8
00007767631d84d5  pop rsi
00007767631d84d6  pop rdi
00007767631d84d7  pop rdx
00007767631d84d8  pop rcx
00007767631d84d9  pop rax
00007767631d84da  add rsp, 0x08
00007767631d84de  jmp 0x00007767631D5FAB
00007767631d84e3  sub rsp, 0x08
00007767631d84e7  push rax
00007767631d84e8  push rcx
00007767631d84e9  push rdx
00007767631d84ea  push rdi
00007767631d84eb  push rsi
00007767631d84ec  push r8
00007767631d84ee  push r9
00007767631d84f0  push r10
00007767631d84f2  push r11
00007767631d84f4  sub rsp, 0xF0
00007767631d84fb  vmovaps [rsp], xmm0
00007767631d8500  vmovaps [rsp+0x10], xmm1
00007767631d8506  vmovaps [rsp+0x20], xmm2
00007767631d850c  vmovaps [rsp+0x30], xmm3
00007767631d8512  vmovaps [rsp+0x40], xmm4
00007767631d8518  vmovaps [rsp+0x50], xmm5
00007767631d851e  vmovaps [rsp+0x60], xmm6
00007767631d8524  vmovaps [rsp+0x70], xmm7
00007767631d852a  vmovaps [rsp+0x80], xmm8
00007767631d8533  vmovaps [rsp+0x90], xmm10
00007767631d853c  vmovaps [rsp+0xA0], xmm11
00007767631d8545  vmovaps [rsp+0xB0], xmm12
00007767631d854e  vmovaps [rsp+0xC0], xmm13
00007767631d8557  vmovaps [rsp+0xD0], xmm14
00007767631d8560  vmovaps [rsp+0xE0], xmm15
00007767631d8569  sub rsp, 0x30
00007767631d856d  movaps [rsp], xmm9
00007767631d8572  movaps [rsp+0x10], xmm3
00007767631d8577  movaps [rsp+0x20], xmm1
00007767631d857c  lea rdi, [rsp]
00007767631d8580  mov esi, 0x00
00007767631d8585  mov rax, 0x617961CDB530
00007767631d858f  call rax
00007767631d8591  movaps xmm9, [rsp]
00007767631d8596  add rsp, 0x30
00007767631d859a  vmovaps xmm0, [rsp]
00007767631d859f  vmovaps xmm1, [rsp+0x10]
00007767631d85a5  vmovaps xmm2, [rsp+0x20]
00007767631d85ab  vmovaps xmm3, [rsp+0x30]
00007767631d85b1  vmovaps xmm4, [rsp+0x40]
00007767631d85b7  vmovaps xmm5, [rsp+0x50]
00007767631d85bd  vmovaps xmm6, [rsp+0x60]
00007767631d85c3  vmovaps xmm7, [rsp+0x70]
00007767631d85c9  vmovaps xmm8, [rsp+0x80]
00007767631d85d2  vmovaps xmm10, [rsp+0x90]
00007767631d85db  vmovaps xmm11, [rsp+0xA0]
00007767631d85e4  vmovaps xmm12, [rsp+0xB0]
00007767631d85ed  vmovaps xmm13, [rsp+0xC0]
00007767631d85f6  vmovaps xmm14, [rsp+0xD0]
00007767631d85ff  vmovaps xmm15, [rsp+0xE0]
00007767631d8608  add rsp, 0xF0
00007767631d860f  pop r11
00007767631d8611  pop r10
00007767631d8613  pop r9
00007767631d8615  pop r8
00007767631d8617  pop rsi
00007767631d8618  pop rdi
00007767631d8619  pop rdx
00007767631d861a  pop rcx
00007767631d861b  pop rax
00007767631d861c  add rsp, 0x08
00007767631d8620  jmp 0x00007767631D5FF7
00007767631d8625  call 0x00007767630D64F0
00007767631d862a  jmp 0x00007767631D6004
00007767631d862f  sub rsp, 0x08
00007767631d8633  push rax
00007767631d8634  push rcx
00007767631d8635  push rdx
00007767631d8636  push rdi
00007767631d8637  push rsi
00007767631d8638  push r8
00007767631d863a  push r9
00007767631d863c  push r10
00007767631d863e  push r11
00007767631d8640  sub rsp, 0xF0
00007767631d8647  vmovaps [rsp], xmm0
00007767631d864c  vmovaps [rsp+0x10], xmm1
00007767631d8652  vmovaps [rsp+0x20], xmm2
00007767631d8658  vmovaps [rsp+0x30], xmm3
00007767631d865e  vmovaps [rsp+0x40], xmm4
00007767631d8664  vmovaps [rsp+0x50], xmm5
00007767631d866a  vmovaps [rsp+0x60], xmm6
00007767631d8670  vmovaps [rsp+0x70], xmm7
00007767631d8676  vmovaps [rsp+0x80], xmm8
00007767631d867f  vmovaps [rsp+0x90], xmm9
00007767631d8688  vmovaps [rsp+0xA0], xmm10
00007767631d8691  vmovaps [rsp+0xB0], xmm11
00007767631d869a  vmovaps [rsp+0xC0], xmm12
00007767631d86a3  vmovaps [rsp+0xD0], xmm13
00007767631d86ac  vmovaps [rsp+0xE0], xmm14
00007767631d86b5  sub rsp, 0x30
00007767631d86b9  movaps [rsp], xmm15
00007767631d86be  movaps [rsp+0x10], xmm3
00007767631d86c3  movaps [rsp+0x20], xmm7
00007767631d86c8  lea rdi, [rsp]
00007767631d86cc  mov esi, 0x00
00007767631d86d1  mov rax, 0x617961CDB530
00007767631d86db  call rax
00007767631d86dd  movaps xmm15, [rsp]
00007767631d86e2  add rsp, 0x30
00007767631d86e6  vmovaps xmm0, [rsp]
00007767631d86eb  vmovaps xmm1, [rsp+0x10]
00007767631d86f1  vmovaps xmm2, [rsp+0x20]
00007767631d86f7  vmovaps xmm3, [rsp+0x30]
00007767631d86fd  vmovaps xmm4, [rsp+0x40]
00007767631d8703  vmovaps xmm5, [rsp+0x50]
00007767631d8709  vmovaps xmm6, [rsp+0x60]
00007767631d870f  vmovaps xmm7, [rsp+0x70]
00007767631d8715  vmovaps xmm8, [rsp+0x80]
00007767631d871e  vmovaps xmm9, [rsp+0x90]
00007767631d8727  vmovaps xmm10, [rsp+0xA0]
00007767631d8730  vmovaps xmm11, [rsp+0xB0]
00007767631d8739  vmovaps xmm12, [rsp+0xC0]
00007767631d8742  vmovaps xmm13, [rsp+0xD0]
00007767631d874b  vmovaps xmm14, [rsp+0xE0]
00007767631d8754  add rsp, 0xF0
00007767631d875b  pop r11
00007767631d875d  pop r10
00007767631d875f  pop r9
00007767631d8761  pop r8
00007767631d8763  pop rsi
00007767631d8764  pop rdi
00007767631d8765  pop rdx
00007767631d8766  pop rcx
00007767631d8767  pop rax
00007767631d8768  add rsp, 0x08
00007767631d876c  jmp 0x00007767631D6030
00007767631d8771  sub rsp, 0x08
00007767631d8775  push rax
00007767631d8776  push rcx
00007767631d8777  push rdx
00007767631d8778  push rdi
00007767631d8779  push rsi
00007767631d877a  push r8
00007767631d877c  push r9
00007767631d877e  push r10
00007767631d8780  push r11
00007767631d8782  sub rsp, 0xF0
00007767631d8789  vmovaps [rsp], xmm0
00007767631d878e  vmovaps [rsp+0x10], xmm1
00007767631d8794  vmovaps [rsp+0x20], xmm2
00007767631d879a  vmovaps [rsp+0x30], xmm4
00007767631d87a0  vmovaps [rsp+0x40], xmm5
00007767631d87a6  vmovaps [rsp+0x50], xmm6
00007767631d87ac  vmovaps [rsp+0x60], xmm7
00007767631d87b2  vmovaps [rsp+0x70], xmm8
00007767631d87b8  vmovaps [rsp+0x80], xmm9
00007767631d87c1  vmovaps [rsp+0x90], xmm10
00007767631d87ca  vmovaps [rsp+0xA0], xmm11
00007767631d87d3  vmovaps [rsp+0xB0], xmm12
00007767631d87dc  vmovaps [rsp+0xC0], xmm13
00007767631d87e5  vmovaps [rsp+0xD0], xmm14
00007767631d87ee  vmovaps [rsp+0xE0], xmm15
00007767631d87f7  sub rsp, 0x30
00007767631d87fb  movaps [rsp], xmm3
00007767631d87ff  movaps [rsp+0x10], xmm1
00007767631d8804  movaps [rsp+0x20], xmm15
00007767631d880a  lea rdi, [rsp]
00007767631d880e  mov esi, 0x00
00007767631d8813  mov rax, 0x617961CDB530
00007767631d881d  call rax
00007767631d881f  movaps xmm3, [rsp]
00007767631d8823  add rsp, 0x30
00007767631d8827  vmovaps xmm0, [rsp]
00007767631d882c  vmovaps xmm1, [rsp+0x10]
00007767631d8832  vmovaps xmm2, [rsp+0x20]
00007767631d8838  vmovaps xmm4, [rsp+0x30]
00007767631d883e  vmovaps xmm5, [rsp+0x40]
00007767631d8844  vmovaps xmm6, [rsp+0x50]
00007767631d884a  vmovaps xmm7, [rsp+0x60]
00007767631d8850  vmovaps xmm8, [rsp+0x70]
00007767631d8856  vmovaps xmm9, [rsp+0x80]
00007767631d885f  vmovaps xmm10, [rsp+0x90]
00007767631d8868  vmovaps xmm11, [rsp+0xA0]
00007767631d8871  vmovaps xmm12, [rsp+0xB0]
00007767631d887a  vmovaps xmm13, [rsp+0xC0]
00007767631d8883  vmovaps xmm14, [rsp+0xD0]
00007767631d888c  vmovaps xmm15, [rsp+0xE0]
00007767631d8895  add rsp, 0xF0
00007767631d889c  pop r11
00007767631d889e  pop r10
00007767631d88a0  pop r9
00007767631d88a2  pop r8
00007767631d88a4  pop rsi
00007767631d88a5  pop rdi
00007767631d88a6  pop rdx
00007767631d88a7  pop rcx
00007767631d88a8  pop rax
00007767631d88a9  add rsp, 0x08
00007767631d88ad  jmp 0x00007767631D60BF
00007767631d88b2  call 0x00007767630D64F0
00007767631d88b7  jmp 0x00007767631D60C9
00007767631d88bc  sub rsp, 0x08
00007767631d88c0  push rax
00007767631d88c1  push rcx
00007767631d88c2  push rdx
00007767631d88c3  push rdi
00007767631d88c4  push rsi
00007767631d88c5  push r8
00007767631d88c7  push r9
00007767631d88c9  push r10
00007767631d88cb  push r11
00007767631d88cd  sub rsp, 0xF0
00007767631d88d4  vmovaps [rsp], xmm0
00007767631d88d9  vmovaps [rsp+0x10], xmm1
00007767631d88df  vmovaps [rsp+0x20], xmm2
00007767631d88e5  vmovaps [rsp+0x30], xmm3
00007767631d88eb  vmovaps [rsp+0x40], xmm4
00007767631d88f1  vmovaps [rsp+0x50], xmm5
00007767631d88f7  vmovaps [rsp+0x60], xmm6
00007767631d88fd  vmovaps [rsp+0x70], xmm7
00007767631d8903  vmovaps [rsp+0x80], xmm8
00007767631d890c  vmovaps [rsp+0x90], xmm9
00007767631d8915  vmovaps [rsp+0xA0], xmm10
00007767631d891e  vmovaps [rsp+0xB0], xmm11
00007767631d8927  vmovaps [rsp+0xC0], xmm12
00007767631d8930  vmovaps [rsp+0xD0], xmm13
00007767631d8939  vmovaps [rsp+0xE0], xmm14
00007767631d8942  sub rsp, 0x30
00007767631d8946  movaps [rsp], xmm15
00007767631d894b  movaps [rsp+0x10], xmm14
00007767631d8951  movaps [rsp+0x20], xmm4
00007767631d8956  lea rdi, [rsp]
00007767631d895a  mov esi, 0x00
00007767631d895f  mov rax, 0x617961CDB530
00007767631d8969  call rax
00007767631d896b  movaps xmm15, [rsp]
00007767631d8970  add rsp, 0x30
00007767631d8974  vmovaps xmm0, [rsp]
00007767631d8979  vmovaps xmm1, [rsp+0x10]
00007767631d897f  vmovaps xmm2, [rsp+0x20]
00007767631d8985  vmovaps xmm3, [rsp+0x30]
00007767631d898b  vmovaps xmm4, [rsp+0x40]
00007767631d8991  vmovaps xmm5, [rsp+0x50]
00007767631d8997  vmovaps xmm6, [rsp+0x60]
00007767631d899d  vmovaps xmm7, [rsp+0x70]
00007767631d89a3  vmovaps xmm8, [rsp+0x80]
00007767631d89ac  vmovaps xmm9, [rsp+0x90]
00007767631d89b5  vmovaps xmm10, [rsp+0xA0]
00007767631d89be  vmovaps xmm11, [rsp+0xB0]
00007767631d89c7  vmovaps xmm12, [rsp+0xC0]
00007767631d89d0  vmovaps xmm13, [rsp+0xD0]
00007767631d89d9  vmovaps xmm14, [rsp+0xE0]
00007767631d89e2  add rsp, 0xF0
00007767631d89e9  pop r11
00007767631d89eb  pop r10
00007767631d89ed  pop r9
00007767631d89ef  pop r8
00007767631d89f1  pop rsi
00007767631d89f2  pop rdi
00007767631d89f3  pop rdx
00007767631d89f4  pop rcx
00007767631d89f5  pop rax
00007767631d89f6  add rsp, 0x08
00007767631d89fa  jmp 0x00007767631D60F7
00007767631d89ff  sub rsp, 0x08
00007767631d8a03  push rax
00007767631d8a04  push rcx
00007767631d8a05  push rdx
00007767631d8a06  push rdi
00007767631d8a07  push rsi
00007767631d8a08  push r8
00007767631d8a0a  push r9
00007767631d8a0c  push r10
00007767631d8a0e  push r11
00007767631d8a10  sub rsp, 0xF0
00007767631d8a17  vmovaps [rsp], xmm0
00007767631d8a1c  vmovaps [rsp+0x10], xmm1
00007767631d8a22  vmovaps [rsp+0x20], xmm2
00007767631d8a28  vmovaps [rsp+0x30], xmm3
00007767631d8a2e  vmovaps [rsp+0x40], xmm4
00007767631d8a34  vmovaps [rsp+0x50], xmm5
00007767631d8a3a  vmovaps [rsp+0x60], xmm6
00007767631d8a40  vmovaps [rsp+0x70], xmm7
00007767631d8a46  vmovaps [rsp+0x80], xmm8
00007767631d8a4f  vmovaps [rsp+0x90], xmm9
00007767631d8a58  vmovaps [rsp+0xA0], xmm10
00007767631d8a61  vmovaps [rsp+0xB0], xmm11
00007767631d8a6a  vmovaps [rsp+0xC0], xmm12
00007767631d8a73  vmovaps [rsp+0xD0], xmm13
00007767631d8a7c  vmovaps [rsp+0xE0], xmm15
00007767631d8a85  sub rsp, 0x30
00007767631d8a89  movaps [rsp], xmm14
00007767631d8a8e  movaps [rsp+0x10], xmm2
00007767631d8a93  movaps [rsp+0x20], xmm1
00007767631d8a98  lea rdi, [rsp]
00007767631d8a9c  mov esi, 0x00
00007767631d8aa1  mov rax, 0x617961CDB530
00007767631d8aab  call rax
00007767631d8aad  movaps xmm14, [rsp]
00007767631d8ab2  add rsp, 0x30
00007767631d8ab6  vmovaps xmm0, [rsp]
00007767631d8abb  vmovaps xmm1, [rsp+0x10]
00007767631d8ac1  vmovaps xmm2, [rsp+0x20]
00007767631d8ac7  vmovaps xmm3, [rsp+0x30]
00007767631d8acd  vmovaps xmm4, [rsp+0x40]
00007767631d8ad3  vmovaps xmm5, [rsp+0x50]
00007767631d8ad9  vmovaps xmm6, [rsp+0x60]
00007767631d8adf  vmovaps xmm7, [rsp+0x70]
00007767631d8ae5  vmovaps xmm8, [rsp+0x80]
00007767631d8aee  vmovaps xmm9, [rsp+0x90]
00007767631d8af7  vmovaps xmm10, [rsp+0xA0]
00007767631d8b00  vmovaps xmm11, [rsp+0xB0]
00007767631d8b09  vmovaps xmm12, [rsp+0xC0]
00007767631d8b12  vmovaps xmm13, [rsp+0xD0]
00007767631d8b1b  vmovaps xmm15, [rsp+0xE0]
00007767631d8b24  add rsp, 0xF0
00007767631d8b2b  pop r11
00007767631d8b2d  pop r10
00007767631d8b2f  pop r9
00007767631d8b31  pop r8
00007767631d8b33  pop rsi
00007767631d8b34  pop rdi
00007767631d8b35  pop rdx
00007767631d8b36  pop rcx
00007767631d8b37  pop rax
00007767631d8b38  add rsp, 0x08
00007767631d8b3c  jmp 0x00007767631D611D
00007767631d8b41  sub rsp, 0x08
00007767631d8b45  push rax
00007767631d8b46  push rcx
00007767631d8b47  push rdx
00007767631d8b48  push rdi
00007767631d8b49  push rsi
00007767631d8b4a  push r8
00007767631d8b4c  push r9
00007767631d8b4e  push r10
00007767631d8b50  push r11
00007767631d8b52  sub rsp, 0xF0
00007767631d8b59  vmovaps [rsp], xmm0
00007767631d8b5e  vmovaps [rsp+0x10], xmm2
00007767631d8b64  vmovaps [rsp+0x20], xmm3
00007767631d8b6a  vmovaps [rsp+0x30], xmm4
00007767631d8b70  vmovaps [rsp+0x40], xmm5
00007767631d8b76  vmovaps [rsp+0x50], xmm6
00007767631d8b7c  vmovaps [rsp+0x60], xmm7
00007767631d8b82  vmovaps [rsp+0x70], xmm8
00007767631d8b88  vmovaps [rsp+0x80], xmm9
00007767631d8b91  vmovaps [rsp+0x90], xmm10
00007767631d8b9a  vmovaps [rsp+0xA0], xmm11
00007767631d8ba3  vmovaps [rsp+0xB0], xmm12
00007767631d8bac  vmovaps [rsp+0xC0], xmm13
00007767631d8bb5  vmovaps [rsp+0xD0], xmm14
00007767631d8bbe  vmovaps [rsp+0xE0], xmm15
00007767631d8bc7  sub rsp, 0x30
00007767631d8bcb  movaps [rsp], xmm1
00007767631d8bcf  movaps [rsp+0x10], xmm4
00007767631d8bd4  movaps [rsp+0x20], xmm9
00007767631d8bda  lea rdi, [rsp]
00007767631d8bde  mov esi, 0x00
00007767631d8be3  mov rax, 0x617961CDB530
00007767631d8bed  call rax
00007767631d8bef  movaps xmm1, [rsp]
00007767631d8bf3  add rsp, 0x30
00007767631d8bf7  vmovaps xmm0, [rsp]
00007767631d8bfc  vmovaps xmm2, [rsp+0x10]
00007767631d8c02  vmovaps xmm3, [rsp+0x20]
00007767631d8c08  vmovaps xmm4, [rsp+0x30]
00007767631d8c0e  vmovaps xmm5, [rsp+0x40]
00007767631d8c14  vmovaps xmm6, [rsp+0x50]
00007767631d8c1a  vmovaps xmm7, [rsp+0x60]
00007767631d8c20  vmovaps xmm8, [rsp+0x70]
00007767631d8c26  vmovaps xmm9, [rsp+0x80]
00007767631d8c2f  vmovaps xmm10, [rsp+0x90]
00007767631d8c38  vmovaps xmm11, [rsp+0xA0]
00007767631d8c41  vmovaps xmm12, [rsp+0xB0]
00007767631d8c4a  vmovaps xmm13, [rsp+0xC0]
00007767631d8c53  vmovaps xmm14, [rsp+0xD0]
00007767631d8c5c  vmovaps xmm15, [rsp+0xE0]
00007767631d8c65  add rsp, 0xF0
00007767631d8c6c  pop r11
00007767631d8c6e  pop r10
00007767631d8c70  pop r9
00007767631d8c72  pop r8
00007767631d8c74  pop rsi
00007767631d8c75  pop rdi
00007767631d8c76  pop rdx
00007767631d8c77  pop rcx
00007767631d8c78  pop rax
00007767631d8c79  add rsp, 0x08
00007767631d8c7d  jmp 0x00007767631D613B
00007767631d8c82  sub rsp, 0x08
00007767631d8c86  push rax
00007767631d8c87  push rcx
00007767631d8c88  push rdx
00007767631d8c89  push rdi
00007767631d8c8a  push rsi
00007767631d8c8b  push r8
00007767631d8c8d  push r9
00007767631d8c8f  push r10
00007767631d8c91  push r11
00007767631d8c93  sub rsp, 0xF0
00007767631d8c9a  vmovaps [rsp], xmm0
00007767631d8c9f  vmovaps [rsp+0x10], xmm1
00007767631d8ca5  vmovaps [rsp+0x20], xmm2
00007767631d8cab  vmovaps [rsp+0x30], xmm3
00007767631d8cb1  vmovaps [rsp+0x40], xmm5
00007767631d8cb7  vmovaps [rsp+0x50], xmm6
00007767631d8cbd  vmovaps [rsp+0x60], xmm7
00007767631d8cc3  vmovaps [rsp+0x70], xmm8
00007767631d8cc9  vmovaps [rsp+0x80], xmm9
00007767631d8cd2  vmovaps [rsp+0x90], xmm10
00007767631d8cdb  vmovaps [rsp+0xA0], xmm11
00007767631d8ce4  vmovaps [rsp+0xB0], xmm12
00007767631d8ced  vmovaps [rsp+0xC0], xmm13
00007767631d8cf6  vmovaps [rsp+0xD0], xmm14
00007767631d8cff  vmovaps [rsp+0xE0], xmm15
00007767631d8d08  sub rsp, 0x30
00007767631d8d0c  movaps [rsp], xmm4
00007767631d8d10  movaps [rsp+0x10], xmm2
00007767631d8d15  movaps [rsp+0x20], xmm9
00007767631d8d1b  lea rdi, [rsp]
00007767631d8d1f  mov esi, 0x00
00007767631d8d24  mov rax, 0x617961CDB530
00007767631d8d2e  call rax
00007767631d8d30  movaps xmm4, [rsp]
00007767631d8d34  add rsp, 0x30
00007767631d8d38  vmovaps xmm0, [rsp]
00007767631d8d3d  vmovaps xmm1, [rsp+0x10]
00007767631d8d43  vmovaps xmm2, [rsp+0x20]
00007767631d8d49  vmovaps xmm3, [rsp+0x30]
00007767631d8d4f  vmovaps xmm5, [rsp+0x40]
00007767631d8d55  vmovaps xmm6, [rsp+0x50]
00007767631d8d5b  vmovaps xmm7, [rsp+0x60]
00007767631d8d61  vmovaps xmm8, [rsp+0x70]
00007767631d8d67  vmovaps xmm9, [rsp+0x80]
00007767631d8d70  vmovaps xmm10, [rsp+0x90]
00007767631d8d79  vmovaps xmm11, [rsp+0xA0]
00007767631d8d82  vmovaps xmm12, [rsp+0xB0]
00007767631d8d8b  vmovaps xmm13, [rsp+0xC0]
00007767631d8d94  vmovaps xmm14, [rsp+0xD0]
00007767631d8d9d  vmovaps xmm15, [rsp+0xE0]
00007767631d8da6  add rsp, 0xF0
00007767631d8dad  pop r11
00007767631d8daf  pop r10
00007767631d8db1  pop r9
00007767631d8db3  pop r8
00007767631d8db5  pop rsi
00007767631d8db6  pop rdi
00007767631d8db7  pop rdx
00007767631d8db8  pop rcx
00007767631d8db9  pop rax
00007767631d8dba  add rsp, 0x08
00007767631d8dbe  jmp 0x00007767631D616B
00007767631d8dc3  sub rsp, 0x08
00007767631d8dc7  push rax
00007767631d8dc8  push rcx
00007767631d8dc9  push rdx
00007767631d8dca  push rdi
00007767631d8dcb  push rsi
00007767631d8dcc  push r8
00007767631d8dce  push r9
00007767631d8dd0  push r10
00007767631d8dd2  push r11
00007767631d8dd4  sub rsp, 0xF0
00007767631d8ddb  vmovaps [rsp], xmm0
00007767631d8de0  vmovaps [rsp+0x10], xmm1
00007767631d8de6  vmovaps [rsp+0x20], xmm2
00007767631d8dec  vmovaps [rsp+0x30], xmm3
00007767631d8df2  vmovaps [rsp+0x40], xmm4
00007767631d8df8  vmovaps [rsp+0x50], xmm5
00007767631d8dfe  vmovaps [rsp+0x60], xmm6
00007767631d8e04  vmovaps [rsp+0x70], xmm7
00007767631d8e0a  vmovaps [rsp+0x80], xmm8
00007767631d8e13  vmovaps [rsp+0x90], xmm10
00007767631d8e1c  vmovaps [rsp+0xA0], xmm11
00007767631d8e25  vmovaps [rsp+0xB0], xmm12
00007767631d8e2e  vmovaps [rsp+0xC0], xmm13
00007767631d8e37  vmovaps [rsp+0xD0], xmm14
00007767631d8e40  vmovaps [rsp+0xE0], xmm15
00007767631d8e49  sub rsp, 0x30
00007767631d8e4d  movaps [rsp], xmm9
00007767631d8e52  movaps [rsp+0x10], xmm2
00007767631d8e57  movaps [rsp+0x20], xmm1
00007767631d8e5c  lea rdi, [rsp]
00007767631d8e60  mov esi, 0x00
00007767631d8e65  mov rax, 0x617961CDB530
00007767631d8e6f  call rax
00007767631d8e71  movaps xmm9, [rsp]
00007767631d8e76  add rsp, 0x30
00007767631d8e7a  vmovaps xmm0, [rsp]
00007767631d8e7f  vmovaps xmm1, [rsp+0x10]
00007767631d8e85  vmovaps xmm2, [rsp+0x20]
00007767631d8e8b  vmovaps xmm3, [rsp+0x30]
00007767631d8e91  vmovaps xmm4, [rsp+0x40]
00007767631d8e97  vmovaps xmm5, [rsp+0x50]
00007767631d8e9d  vmovaps xmm6, [rsp+0x60]
00007767631d8ea3  vmovaps xmm7, [rsp+0x70]
00007767631d8ea9  vmovaps xmm8, [rsp+0x80]
00007767631d8eb2  vmovaps xmm10, [rsp+0x90]
00007767631d8ebb  vmovaps xmm11, [rsp+0xA0]
00007767631d8ec4  vmovaps xmm12, [rsp+0xB0]
00007767631d8ecd  vmovaps xmm13, [rsp+0xC0]
00007767631d8ed6  vmovaps xmm14, [rsp+0xD0]
00007767631d8edf  vmovaps xmm15, [rsp+0xE0]
00007767631d8ee8  add rsp, 0xF0
00007767631d8eef  pop r11
00007767631d8ef1  pop r10
00007767631d8ef3  pop r9
00007767631d8ef5  pop r8
00007767631d8ef7  pop rsi
00007767631d8ef8  pop rdi
00007767631d8ef9  pop rdx
00007767631d8efa  pop rcx
00007767631d8efb  pop rax
00007767631d8efc  add rsp, 0x08
00007767631d8f00  jmp 0x00007767631D61A1
00007767631d8f05  sub rsp, 0x08
00007767631d8f09  push rax
00007767631d8f0a  push rcx
00007767631d8f0b  push rdx
00007767631d8f0c  push rdi
00007767631d8f0d  push rsi
00007767631d8f0e  push r8
00007767631d8f10  push r9
00007767631d8f12  push r10
00007767631d8f14  push r11
00007767631d8f16  sub rsp, 0xF0
00007767631d8f1d  vmovaps [rsp], xmm0
00007767631d8f22  vmovaps [rsp+0x10], xmm2
00007767631d8f28  vmovaps [rsp+0x20], xmm3
00007767631d8f2e  vmovaps [rsp+0x30], xmm4
00007767631d8f34  vmovaps [rsp+0x40], xmm5
00007767631d8f3a  vmovaps [rsp+0x50], xmm6
00007767631d8f40  vmovaps [rsp+0x60], xmm7
00007767631d8f46  vmovaps [rsp+0x70], xmm8
00007767631d8f4c  vmovaps [rsp+0x80], xmm9
00007767631d8f55  vmovaps [rsp+0x90], xmm10
00007767631d8f5e  vmovaps [rsp+0xA0], xmm11
00007767631d8f67  vmovaps [rsp+0xB0], xmm12
00007767631d8f70  vmovaps [rsp+0xC0], xmm13
00007767631d8f79  vmovaps [rsp+0xD0], xmm14
00007767631d8f82  vmovaps [rsp+0xE0], xmm15
00007767631d8f8b  sub rsp, 0x30
00007767631d8f8f  movaps [rsp], xmm1
00007767631d8f93  movaps [rsp+0x10], xmm15
00007767631d8f99  movaps [rsp+0x20], xmm6
00007767631d8f9e  lea rdi, [rsp]
00007767631d8fa2  mov esi, 0x00
00007767631d8fa7  mov rax, 0x617961CDB530
00007767631d8fb1  call rax
00007767631d8fb3  movaps xmm1, [rsp]
00007767631d8fb7  add rsp, 0x30
00007767631d8fbb  vmovaps xmm0, [rsp]
00007767631d8fc0  vmovaps xmm2, [rsp+0x10]
00007767631d8fc6  vmovaps xmm3, [rsp+0x20]
00007767631d8fcc  vmovaps xmm4, [rsp+0x30]
00007767631d8fd2  vmovaps xmm5, [rsp+0x40]
00007767631d8fd8  vmovaps xmm6, [rsp+0x50]
00007767631d8fde  vmovaps xmm7, [rsp+0x60]
00007767631d8fe4  vmovaps xmm8, [rsp+0x70]
00007767631d8fea  vmovaps xmm9, [rsp+0x80]
00007767631d8ff3  vmovaps xmm10, [rsp+0x90]
00007767631d8ffc  vmovaps xmm11, [rsp+0xA0]
00007767631d9005  vmovaps xmm12, [rsp+0xB0]
00007767631d900e  vmovaps xmm13, [rsp+0xC0]
00007767631d9017  vmovaps xmm14, [rsp+0xD0]
00007767631d9020  vmovaps xmm15, [rsp+0xE0]
00007767631d9029  add rsp, 0xF0
00007767631d9030  pop r11
00007767631d9032  pop r10
00007767631d9034  pop r9
00007767631d9036  pop r8
00007767631d9038  pop rsi
00007767631d9039  pop rdi
00007767631d903a  pop rdx
00007767631d903b  pop rcx
00007767631d903c  pop rax
00007767631d903d  add rsp, 0x08
00007767631d9041  jmp 0x00007767631D61C2
00007767631d9046  sub rsp, 0x08
00007767631d904a  push rax
00007767631d904b  push rcx
00007767631d904c  push rdx
00007767631d904d  push rdi
00007767631d904e  push rsi
00007767631d904f  push r8
00007767631d9051  push r9
00007767631d9053  push r10
00007767631d9055  push r11
00007767631d9057  sub rsp, 0xF0
00007767631d905e  vmovaps [rsp], xmm0
00007767631d9063  vmovaps [rsp+0x10], xmm1
00007767631d9069  vmovaps [rsp+0x20], xmm2
00007767631d906f  vmovaps [rsp+0x30], xmm3
00007767631d9075  vmovaps [rsp+0x40], xmm4
00007767631d907b  vmovaps [rsp+0x50], xmm5
00007767631d9081  vmovaps [rsp+0x60], xmm6
00007767631d9087  vmovaps [rsp+0x70], xmm7
00007767631d908d  vmovaps [rsp+0x80], xmm8
00007767631d9096  vmovaps [rsp+0x90], xmm9
00007767631d909f  vmovaps [rsp+0xA0], xmm10
00007767631d90a8  vmovaps [rsp+0xB0], xmm11
00007767631d90b1  vmovaps [rsp+0xC0], xmm12
00007767631d90ba  vmovaps [rsp+0xD0], xmm13
00007767631d90c3  vmovaps [rsp+0xE0], xmm14
00007767631d90cc  sub rsp, 0x30
00007767631d90d0  movaps [rsp], xmm15
00007767631d90d5  movaps [rsp+0x10], xmm5
00007767631d90da  movaps [rsp+0x20], xmm3
00007767631d90df  lea rdi, [rsp]
00007767631d90e3  mov esi, 0x00
00007767631d90e8  mov rax, 0x617961CDB530
00007767631d90f2  call rax
00007767631d90f4  movaps xmm15, [rsp]
00007767631d90f9  add rsp, 0x30
00007767631d90fd  vmovaps xmm0, [rsp]
00007767631d9102  vmovaps xmm1, [rsp+0x10]
00007767631d9108  vmovaps xmm2, [rsp+0x20]
00007767631d910e  vmovaps xmm3, [rsp+0x30]
00007767631d9114  vmovaps xmm4, [rsp+0x40]
00007767631d911a  vmovaps xmm5, [rsp+0x50]
00007767631d9120  vmovaps xmm6, [rsp+0x60]
00007767631d9126  vmovaps xmm7, [rsp+0x70]
00007767631d912c  vmovaps xmm8, [rsp+0x80]
00007767631d9135  vmovaps xmm9, [rsp+0x90]
00007767631d913e  vmovaps xmm10, [rsp+0xA0]
00007767631d9147  vmovaps xmm11, [rsp+0xB0]
00007767631d9150  vmovaps xmm12, [rsp+0xC0]
00007767631d9159  vmovaps xmm13, [rsp+0xD0]
00007767631d9162  vmovaps xmm14, [rsp+0xE0]
00007767631d916b  add rsp, 0xF0
00007767631d9172  pop r11
00007767631d9174  pop r10
00007767631d9176  pop r9
00007767631d9178  pop r8
00007767631d917a  pop rsi
00007767631d917b  pop rdi
00007767631d917c  pop rdx
00007767631d917d  pop rcx
00007767631d917e  pop rax
00007767631d917f  add rsp, 0x08
00007767631d9183  jmp 0x00007767631D61DC
00007767631d9188  sub rsp, 0x08
00007767631d918c  push rax
00007767631d918d  push rcx
00007767631d918e  push rdx
00007767631d918f  push rdi
00007767631d9190  push rsi
00007767631d9191  push r8
00007767631d9193  push r9
00007767631d9195  push r10
00007767631d9197  push r11
00007767631d9199  sub rsp, 0xF0
00007767631d91a0  vmovaps [rsp], xmm0
00007767631d91a5  vmovaps [rsp+0x10], xmm1
00007767631d91ab  vmovaps [rsp+0x20], xmm2
00007767631d91b1  vmovaps [rsp+0x30], xmm3
00007767631d91b7  vmovaps [rsp+0x40], xmm4
00007767631d91bd  vmovaps [rsp+0x50], xmm6
00007767631d91c3  vmovaps [rsp+0x60], xmm7
00007767631d91c9  vmovaps [rsp+0x70], xmm8
00007767631d91cf  vmovaps [rsp+0x80], xmm9
00007767631d91d8  vmovaps [rsp+0x90], xmm10
00007767631d91e1  vmovaps [rsp+0xA0], xmm11
00007767631d91ea  vmovaps [rsp+0xB0], xmm12
00007767631d91f3  vmovaps [rsp+0xC0], xmm13
00007767631d91fc  vmovaps [rsp+0xD0], xmm14
00007767631d9205  vmovaps [rsp+0xE0], xmm15
00007767631d920e  sub rsp, 0x30
00007767631d9212  movaps [rsp], xmm5
00007767631d9216  movaps [rsp+0x10], xmm8
00007767631d921c  movaps [rsp+0x20], xmm6
00007767631d9221  lea rdi, [rsp]
00007767631d9225  mov esi, 0x00
00007767631d922a  mov rax, 0x617961CDB530
00007767631d9234  call rax
00007767631d9236  movaps xmm5, [rsp]
00007767631d923a  add rsp, 0x30
00007767631d923e  vmovaps xmm0, [rsp]
00007767631d9243  vmovaps xmm1, [rsp+0x10]
00007767631d9249  vmovaps xmm2, [rsp+0x20]
00007767631d924f  vmovaps xmm3, [rsp+0x30]
00007767631d9255  vmovaps xmm4, [rsp+0x40]
00007767631d925b  vmovaps xmm6, [rsp+0x50]
00007767631d9261  vmovaps xmm7, [rsp+0x60]
00007767631d9267  vmovaps xmm8, [rsp+0x70]
00007767631d926d  vmovaps xmm9, [rsp+0x80]
00007767631d9276  vmovaps xmm10, [rsp+0x90]
00007767631d927f  vmovaps xmm11, [rsp+0xA0]
00007767631d9288  vmovaps xmm12, [rsp+0xB0]
00007767631d9291  vmovaps xmm13, [rsp+0xC0]
00007767631d929a  vmovaps xmm14, [rsp+0xD0]
00007767631d92a3  vmovaps xmm15, [rsp+0xE0]
00007767631d92ac  add rsp, 0xF0
00007767631d92b3  pop r11
00007767631d92b5  pop r10
00007767631d92b7  pop r9
00007767631d92b9  pop r8
00007767631d92bb  pop rsi
00007767631d92bc  pop rdi
00007767631d92bd  pop rdx
00007767631d92be  pop rcx
00007767631d92bf  pop rax
00007767631d92c0  add rsp, 0x08
00007767631d92c4  jmp 0x00007767631D6200
00007767631d92c9  sub rsp, 0x08
00007767631d92cd  push rax
00007767631d92ce  push rcx
00007767631d92cf  push rdx
00007767631d92d0  push rdi
00007767631d92d1  push rsi
00007767631d92d2  push r8
00007767631d92d4  push r9
00007767631d92d6  push r10
00007767631d92d8  push r11
00007767631d92da  sub rsp, 0xF0
00007767631d92e1  vmovaps [rsp], xmm0
00007767631d92e6  vmovaps [rsp+0x10], xmm1
00007767631d92ec  vmovaps [rsp+0x20], xmm2
00007767631d92f2  vmovaps [rsp+0x30], xmm3
00007767631d92f8  vmovaps [rsp+0x40], xmm4
00007767631d92fe  vmovaps [rsp+0x50], xmm5
00007767631d9304  vmovaps [rsp+0x60], xmm7
00007767631d930a  vmovaps [rsp+0x70], xmm8
00007767631d9310  vmovaps [rsp+0x80], xmm9
00007767631d9319  vmovaps [rsp+0x90], xmm10
00007767631d9322  vmovaps [rsp+0xA0], xmm11
00007767631d932b  vmovaps [rsp+0xB0], xmm12
00007767631d9334  vmovaps [rsp+0xC0], xmm13
00007767631d933d  vmovaps [rsp+0xD0], xmm14
00007767631d9346  vmovaps [rsp+0xE0], xmm15
00007767631d934f  sub rsp, 0x30
00007767631d9353  movaps [rsp], xmm6
00007767631d9357  movaps [rsp+0x10], xmm10
00007767631d935d  movaps [rsp+0x20], xmm8
00007767631d9363  lea rdi, [rsp]
00007767631d9367  mov esi, 0x00
00007767631d936c  mov rax, 0x617961CDB530
00007767631d9376  call rax
00007767631d9378  movaps xmm6, [rsp]
00007767631d937c  add rsp, 0x30
00007767631d9380  vmovaps xmm0, [rsp]
00007767631d9385  vmovaps xmm1, [rsp+0x10]
00007767631d938b  vmovaps xmm2, [rsp+0x20]
00007767631d9391  vmovaps xmm3, [rsp+0x30]
00007767631d9397  vmovaps xmm4, [rsp+0x40]
00007767631d939d  vmovaps xmm5, [rsp+0x50]
00007767631d93a3  vmovaps xmm7, [rsp+0x60]
00007767631d93a9  vmovaps xmm8, [rsp+0x70]
00007767631d93af  vmovaps xmm9, [rsp+0x80]
00007767631d93b8  vmovaps xmm10, [rsp+0x90]
00007767631d93c1  vmovaps xmm11, [rsp+0xA0]
00007767631d93ca  vmovaps xmm12, [rsp+0xB0]
00007767631d93d3  vmovaps xmm13, [rsp+0xC0]
00007767631d93dc  vmovaps xmm14, [rsp+0xD0]
00007767631d93e5  vmovaps xmm15, [rsp+0xE0]
00007767631d93ee  add rsp, 0xF0
00007767631d93f5  pop r11
00007767631d93f7  pop r10
00007767631d93f9  pop r9
00007767631d93fb  pop r8
00007767631d93fd  pop rsi
00007767631d93fe  pop rdi
00007767631d93ff  pop rdx
00007767631d9400  pop rcx
00007767631d9401  pop rax
00007767631d9402  add rsp, 0x08
00007767631d9406  jmp 0x00007767631D6225
00007767631d940b  sub rsp, 0x08
00007767631d940f  push rax
00007767631d9410  push rcx
00007767631d9411  push rdx
00007767631d9412  push rdi
00007767631d9413  push rsi
00007767631d9414  push r8
00007767631d9416  push r9
00007767631d9418  push r10
00007767631d941a  push r11
00007767631d941c  sub rsp, 0xF0
00007767631d9423  vmovaps [rsp], xmm0
00007767631d9428  vmovaps [rsp+0x10], xmm1
00007767631d942e  vmovaps [rsp+0x20], xmm2
00007767631d9434  vmovaps [rsp+0x30], xmm3
00007767631d943a  vmovaps [rsp+0x40], xmm4
00007767631d9440  vmovaps [rsp+0x50], xmm5
00007767631d9446  vmovaps [rsp+0x60], xmm6
00007767631d944c  vmovaps [rsp+0x70], xmm7
00007767631d9452  vmovaps [rsp+0x80], xmm8
00007767631d945b  vmovaps [rsp+0x90], xmm9
00007767631d9464  vmovaps [rsp+0xA0], xmm11
00007767631d946d  vmovaps [rsp+0xB0], xmm12
00007767631d9476  vmovaps [rsp+0xC0], xmm13
00007767631d947f  vmovaps [rsp+0xD0], xmm14
00007767631d9488  vmovaps [rsp+0xE0], xmm15
00007767631d9491  sub rsp, 0x30
00007767631d9495  movaps [rsp], xmm10
00007767631d949a  movaps [rsp+0x10], xmm8
00007767631d94a0  movaps [rsp+0x20], xmm14
00007767631d94a6  lea rdi, [rsp]
00007767631d94aa  mov esi, 0x00
00007767631d94af  mov rax, 0x617961CDB530
00007767631d94b9  call rax
00007767631d94bb  movaps xmm10, [rsp]
00007767631d94c0  add rsp, 0x30
00007767631d94c4  vmovaps xmm0, [rsp]
00007767631d94c9  vmovaps xmm1, [rsp+0x10]
00007767631d94cf  vmovaps xmm2, [rsp+0x20]
00007767631d94d5  vmovaps xmm3, [rsp+0x30]
00007767631d94db  vmovaps xmm4, [rsp+0x40]
00007767631d94e1  vmovaps xmm5, [rsp+0x50]
00007767631d94e7  vmovaps xmm6, [rsp+0x60]
00007767631d94ed  vmovaps xmm7, [rsp+0x70]
00007767631d94f3  vmovaps xmm8, [rsp+0x80]
00007767631d94fc  vmovaps xmm9, [rsp+0x90]
00007767631d9505  vmovaps xmm11, [rsp+0xA0]
00007767631d950e  vmovaps xmm12, [rsp+0xB0]
00007767631d9517  vmovaps xmm13, [rsp+0xC0]
00007767631d9520  vmovaps xmm14, [rsp+0xD0]
00007767631d9529  vmovaps xmm15, [rsp+0xE0]
00007767631d9532  add rsp, 0xF0
00007767631d9539  pop r11
00007767631d953b  pop r10
00007767631d953d  pop r9
00007767631d953f  pop r8
00007767631d9541  pop rsi
00007767631d9542  pop rdi
00007767631d9543  pop rdx
00007767631d9544  pop rcx
00007767631d9545  pop rax
00007767631d9546  add rsp, 0x08
00007767631d954a  jmp 0x00007767631D6245
00007767631d954f  sub rsp, 0x08
00007767631d9553  push rax
00007767631d9554  push rcx
00007767631d9555  push rdx
00007767631d9556  push rdi
00007767631d9557  push rsi
00007767631d9558  push r8
00007767631d955a  push r9
00007767631d955c  push r10
00007767631d955e  push r11
00007767631d9560  sub rsp, 0xF0
00007767631d9567  vmovaps [rsp], xmm0
00007767631d956c  vmovaps [rsp+0x10], xmm1
00007767631d9572  vmovaps [rsp+0x20], xmm2
00007767631d9578  vmovaps [rsp+0x30], xmm3
00007767631d957e  vmovaps [rsp+0x40], xmm4
00007767631d9584  vmovaps [rsp+0x50], xmm5
00007767631d958a  vmovaps [rsp+0x60], xmm6
00007767631d9590  vmovaps [rsp+0x70], xmm7
00007767631d9596  vmovaps [rsp+0x80], xmm8
00007767631d959f  vmovaps [rsp+0x90], xmm9
00007767631d95a8  vmovaps [rsp+0xA0], xmm10
00007767631d95b1  vmovaps [rsp+0xB0], xmm11
00007767631d95ba  vmovaps [rsp+0xC0], xmm12
00007767631d95c3  vmovaps [rsp+0xD0], xmm13
00007767631d95cc  vmovaps [rsp+0xE0], xmm15
00007767631d95d5  sub rsp, 0x30
00007767631d95d9  movaps [rsp], xmm14
00007767631d95de  movaps [rsp+0x10], xmm8
00007767631d95e4  movaps [rsp+0x20], xmm4
00007767631d95e9  lea rdi, [rsp]
00007767631d95ed  mov esi, 0x00
00007767631d95f2  mov rax, 0x617961CDB530
00007767631d95fc  call rax
00007767631d95fe  movaps xmm14, [rsp]
00007767631d9603  add rsp, 0x30
00007767631d9607  vmovaps xmm0, [rsp]
00007767631d960c  vmovaps xmm1, [rsp+0x10]
00007767631d9612  vmovaps xmm2, [rsp+0x20]
00007767631d9618  vmovaps xmm3, [rsp+0x30]
00007767631d961e  vmovaps xmm4, [rsp+0x40]
00007767631d9624  vmovaps xmm5, [rsp+0x50]
00007767631d962a  vmovaps xmm6, [rsp+0x60]
00007767631d9630  vmovaps xmm7, [rsp+0x70]
00007767631d9636  vmovaps xmm8, [rsp+0x80]
00007767631d963f  vmovaps xmm9, [rsp+0x90]
00007767631d9648  vmovaps xmm10, [rsp+0xA0]
00007767631d9651  vmovaps xmm11, [rsp+0xB0]
00007767631d965a  vmovaps xmm12, [rsp+0xC0]
00007767631d9663  vmovaps xmm13, [rsp+0xD0]
00007767631d966c  vmovaps xmm15, [rsp+0xE0]
00007767631d9675  add rsp, 0xF0
00007767631d967c  pop r11
00007767631d967e  pop r10
00007767631d9680  pop r9
00007767631d9682  pop r8
00007767631d9684  pop rsi
00007767631d9685  pop rdi
00007767631d9686  pop rdx
00007767631d9687  pop rcx
00007767631d9688  pop rax
00007767631d9689  add rsp, 0x08
00007767631d968d  jmp 0x00007767631D6265
00007767631d9692  sub rsp, 0x08
00007767631d9696  push rax
00007767631d9697  push rcx
00007767631d9698  push rdx
00007767631d9699  push rdi
00007767631d969a  push rsi
00007767631d969b  push r8
00007767631d969d  push r9
00007767631d969f  push r10
00007767631d96a1  push r11
00007767631d96a3  sub rsp, 0xF0
00007767631d96aa  vmovaps [rsp], xmm0
00007767631d96af  vmovaps [rsp+0x10], xmm1
00007767631d96b5  vmovaps [rsp+0x20], xmm2
00007767631d96bb  vmovaps [rsp+0x30], xmm3
00007767631d96c1  vmovaps [rsp+0x40], xmm5
00007767631d96c7  vmovaps [rsp+0x50], xmm6
00007767631d96cd  vmovaps [rsp+0x60], xmm7
00007767631d96d3  vmovaps [rsp+0x70], xmm8
00007767631d96d9  vmovaps [rsp+0x80], xmm9
00007767631d96e2  vmovaps [rsp+0x90], xmm10
00007767631d96eb  vmovaps [rsp+0xA0], xmm11
00007767631d96f4  vmovaps [rsp+0xB0], xmm12
00007767631d96fd  vmovaps [rsp+0xC0], xmm13
00007767631d9706  vmovaps [rsp+0xD0], xmm14
00007767631d970f  vmovaps [rsp+0xE0], xmm15
00007767631d9718  sub rsp, 0x30
00007767631d971c  movaps [rsp], xmm4
00007767631d9720  movaps [rsp+0x10], xmm13
00007767631d9726  movaps [rsp+0x20], xmm8
00007767631d972c  lea rdi, [rsp]
00007767631d9730  mov esi, 0x00
00007767631d9735  mov rax, 0x617961CDB530
00007767631d973f  call rax
00007767631d9741  movaps xmm4, [rsp]
00007767631d9745  add rsp, 0x30
00007767631d9749  vmovaps xmm0, [rsp]
00007767631d974e  vmovaps xmm1, [rsp+0x10]
00007767631d9754  vmovaps xmm2, [rsp+0x20]
00007767631d975a  vmovaps xmm3, [rsp+0x30]
00007767631d9760  vmovaps xmm5, [rsp+0x40]
00007767631d9766  vmovaps xmm6, [rsp+0x50]
00007767631d976c  vmovaps xmm7, [rsp+0x60]
00007767631d9772  vmovaps xmm8, [rsp+0x70]
00007767631d9778  vmovaps xmm9, [rsp+0x80]
00007767631d9781  vmovaps xmm10, [rsp+0x90]
00007767631d978a  vmovaps xmm11, [rsp+0xA0]
00007767631d9793  vmovaps xmm12, [rsp+0xB0]
00007767631d979c  vmovaps xmm13, [rsp+0xC0]
00007767631d97a5  vmovaps xmm14, [rsp+0xD0]
00007767631d97ae  vmovaps xmm15, [rsp+0xE0]
00007767631d97b7  add rsp, 0xF0
00007767631d97be  pop r11
00007767631d97c0  pop r10
00007767631d97c2  pop r9
00007767631d97c4  pop r8
00007767631d97c6  pop rsi
00007767631d97c7  pop rdi
00007767631d97c8  pop rdx
00007767631d97c9  pop rcx
00007767631d97ca  pop rax
00007767631d97cb  add rsp, 0x08
00007767631d97cf  jmp 0x00007767631D628A
00007767631d97d4  sub rsp, 0x08
00007767631d97d8  push rax
00007767631d97d9  push rcx
00007767631d97da  push rdx
00007767631d97db  push rdi
00007767631d97dc  push rsi
00007767631d97dd  push r8
00007767631d97df  push r9
00007767631d97e1  push r10
00007767631d97e3  push r11
00007767631d97e5  sub rsp, 0xF0
00007767631d97ec  vmovaps [rsp], xmm0
00007767631d97f1  vmovaps [rsp+0x10], xmm1
00007767631d97f7  vmovaps [rsp+0x20], xmm2
00007767631d97fd  vmovaps [rsp+0x30], xmm3
00007767631d9803  vmovaps [rsp+0x40], xmm4
00007767631d9809  vmovaps [rsp+0x50], xmm5
00007767631d980f  vmovaps [rsp+0x60], xmm6
00007767631d9815  vmovaps [rsp+0x70], xmm7
00007767631d981b  vmovaps [rsp+0x80], xmm8
00007767631d9824  vmovaps [rsp+0x90], xmm9
00007767631d982d  vmovaps [rsp+0xA0], xmm10
00007767631d9836  vmovaps [rsp+0xB0], xmm11
00007767631d983f  vmovaps [rsp+0xC0], xmm12
00007767631d9848  vmovaps [rsp+0xD0], xmm14
00007767631d9851  vmovaps [rsp+0xE0], xmm15
00007767631d985a  sub rsp, 0x30
00007767631d985e  movaps [rsp], xmm13
00007767631d9863  movaps [rsp+0x10], xmm15
00007767631d9869  movaps [rsp+0x20], xmm9
00007767631d986f  lea rdi, [rsp]
00007767631d9873  mov esi, 0x00
00007767631d9878  mov rax, 0x617961CDB530
00007767631d9882  call rax
00007767631d9884  movaps xmm13, [rsp]
00007767631d9889  add rsp, 0x30
00007767631d988d  vmovaps xmm0, [rsp]
00007767631d9892  vmovaps xmm1, [rsp+0x10]
00007767631d9898  vmovaps xmm2, [rsp+0x20]
00007767631d989e  vmovaps xmm3, [rsp+0x30]
00007767631d98a4  vmovaps xmm4, [rsp+0x40]
00007767631d98aa  vmovaps xmm5, [rsp+0x50]
00007767631d98b0  vmovaps xmm6, [rsp+0x60]
00007767631d98b6  vmovaps xmm7, [rsp+0x70]
00007767631d98bc  vmovaps xmm8, [rsp+0x80]
00007767631d98c5  vmovaps xmm9, [rsp+0x90]
00007767631d98ce  vmovaps xmm10, [rsp+0xA0]
00007767631d98d7  vmovaps xmm11, [rsp+0xB0]
00007767631d98e0  vmovaps xmm12, [rsp+0xC0]
00007767631d98e9  vmovaps xmm14, [rsp+0xD0]
00007767631d98f2  vmovaps xmm15, [rsp+0xE0]
00007767631d98fb  add rsp, 0xF0
00007767631d9902  pop r11
00007767631d9904  pop r10
00007767631d9906  pop r9
00007767631d9908  pop r8
00007767631d990a  pop rsi
00007767631d990b  pop rdi
00007767631d990c  pop rdx
00007767631d990d  pop rcx
00007767631d990e  pop rax
00007767631d990f  add rsp, 0x08
00007767631d9913  jmp 0x00007767631D62A5
00007767631d9918  sub rsp, 0x08
00007767631d991c  push rax
00007767631d991d  push rcx
00007767631d991e  push rdx
00007767631d991f  push rdi
00007767631d9920  push rsi
00007767631d9921  push r8
00007767631d9923  push r9
00007767631d9925  push r10
00007767631d9927  push r11
00007767631d9929  sub rsp, 0xF0
00007767631d9930  vmovaps [rsp], xmm0
00007767631d9935  vmovaps [rsp+0x10], xmm1
00007767631d993b  vmovaps [rsp+0x20], xmm2
00007767631d9941  vmovaps [rsp+0x30], xmm3
00007767631d9947  vmovaps [rsp+0x40], xmm4
00007767631d994d  vmovaps [rsp+0x50], xmm5
00007767631d9953  vmovaps [rsp+0x60], xmm6
00007767631d9959  vmovaps [rsp+0x70], xmm7
00007767631d995f  vmovaps [rsp+0x80], xmm8
00007767631d9968  vmovaps [rsp+0x90], xmm9
00007767631d9971  vmovaps [rsp+0xA0], xmm10
00007767631d997a  vmovaps [rsp+0xB0], xmm11
00007767631d9983  vmovaps [rsp+0xC0], xmm12
00007767631d998c  vmovaps [rsp+0xD0], xmm13
00007767631d9995  vmovaps [rsp+0xE0], xmm14
00007767631d999e  sub rsp, 0x30
00007767631d99a2  movaps [rsp], xmm15
00007767631d99a7  movaps [rsp+0x10], xmm1
00007767631d99ac  movaps [rsp+0x20], xmm5
00007767631d99b1  lea rdi, [rsp]
00007767631d99b5  mov esi, 0x00
00007767631d99ba  mov rax, 0x617961CDB530
00007767631d99c4  call rax
00007767631d99c6  movaps xmm15, [rsp]
00007767631d99cb  add rsp, 0x30
00007767631d99cf  vmovaps xmm0, [rsp]
00007767631d99d4  vmovaps xmm1, [rsp+0x10]
00007767631d99da  vmovaps xmm2, [rsp+0x20]
00007767631d99e0  vmovaps xmm3, [rsp+0x30]
00007767631d99e6  vmovaps xmm4, [rsp+0x40]
00007767631d99ec  vmovaps xmm5, [rsp+0x50]
00007767631d99f2  vmovaps xmm6, [rsp+0x60]
00007767631d99f8  vmovaps xmm7, [rsp+0x70]
00007767631d99fe  vmovaps xmm8, [rsp+0x80]
00007767631d9a07  vmovaps xmm9, [rsp+0x90]
00007767631d9a10  vmovaps xmm10, [rsp+0xA0]
00007767631d9a19  vmovaps xmm11, [rsp+0xB0]
00007767631d9a22  vmovaps xmm12, [rsp+0xC0]
00007767631d9a2b  vmovaps xmm13, [rsp+0xD0]
00007767631d9a34  vmovaps xmm14, [rsp+0xE0]
00007767631d9a3d  add rsp, 0xF0
00007767631d9a44  pop r11
00007767631d9a46  pop r10
00007767631d9a48  pop r9
00007767631d9a4a  pop r8
00007767631d9a4c  pop rsi
00007767631d9a4d  pop rdi
00007767631d9a4e  pop rdx
00007767631d9a4f  pop rcx
00007767631d9a50  pop rax
00007767631d9a51  add rsp, 0x08
00007767631d9a55  jmp 0x00007767631D62C0
00007767631d9a5a  call 0x00007767630D64F0
00007767631d9a5f  jmp 0x00007767631D631B
00007767631d9a64  sub rsp, 0x08
00007767631d9a68  push rax
00007767631d9a69  push rcx
00007767631d9a6a  push rdx
00007767631d9a6b  push rdi
00007767631d9a6c  push rsi
00007767631d9a6d  push r8
00007767631d9a6f  push r9
00007767631d9a71  push r10
00007767631d9a73  push r11
00007767631d9a75  sub rsp, 0xF0
00007767631d9a7c  vmovaps [rsp], xmm0
00007767631d9a81  vmovaps [rsp+0x10], xmm1
00007767631d9a87  vmovaps [rsp+0x20], xmm2
00007767631d9a8d  vmovaps [rsp+0x30], xmm3
00007767631d9a93  vmovaps [rsp+0x40], xmm4
00007767631d9a99  vmovaps [rsp+0x50], xmm5
00007767631d9a9f  vmovaps [rsp+0x60], xmm6
00007767631d9aa5  vmovaps [rsp+0x70], xmm7
00007767631d9aab  vmovaps [rsp+0x80], xmm8
00007767631d9ab4  vmovaps [rsp+0x90], xmm10
00007767631d9abd  vmovaps [rsp+0xA0], xmm11
00007767631d9ac6  vmovaps [rsp+0xB0], xmm12
00007767631d9acf  vmovaps [rsp+0xC0], xmm13
00007767631d9ad8  vmovaps [rsp+0xD0], xmm14
00007767631d9ae1  vmovaps [rsp+0xE0], xmm15
00007767631d9aea  sub rsp, 0x30
00007767631d9aee  movaps [rsp], xmm9
00007767631d9af3  movaps [rsp+0x10], xmm8
00007767631d9af9  movaps [rsp+0x20], xmm11
00007767631d9aff  lea rdi, [rsp]
00007767631d9b03  mov esi, 0x00
00007767631d9b08  mov rax, 0x617961CDB530
00007767631d9b12  call rax
00007767631d9b14  movaps xmm9, [rsp]
00007767631d9b19  add rsp, 0x30
00007767631d9b1d  vmovaps xmm0, [rsp]
00007767631d9b22  vmovaps xmm1, [rsp+0x10]
00007767631d9b28  vmovaps xmm2, [rsp+0x20]
00007767631d9b2e  vmovaps xmm3, [rsp+0x30]
00007767631d9b34  vmovaps xmm4, [rsp+0x40]
00007767631d9b3a  vmovaps xmm5, [rsp+0x50]
00007767631d9b40  vmovaps xmm6, [rsp+0x60]
00007767631d9b46  vmovaps xmm7, [rsp+0x70]
00007767631d9b4c  vmovaps xmm8, [rsp+0x80]
00007767631d9b55  vmovaps xmm10, [rsp+0x90]
00007767631d9b5e  vmovaps xmm11, [rsp+0xA0]
00007767631d9b67  vmovaps xmm12, [rsp+0xB0]
00007767631d9b70  vmovaps xmm13, [rsp+0xC0]
00007767631d9b79  vmovaps xmm14, [rsp+0xD0]
00007767631d9b82  vmovaps xmm15, [rsp+0xE0]
00007767631d9b8b  add rsp, 0xF0
00007767631d9b92  pop r11
00007767631d9b94  pop r10
00007767631d9b96  pop r9
00007767631d9b98  pop r8
00007767631d9b9a  pop rsi
00007767631d9b9b  pop rdi
00007767631d9b9c  pop rdx
00007767631d9b9d  pop rcx
00007767631d9b9e  pop rax
00007767631d9b9f  add rsp, 0x08
00007767631d9ba3  jmp 0x00007767631D6352
00007767631d9ba8  sub rsp, 0x08
00007767631d9bac  push rax
00007767631d9bad  push rcx
00007767631d9bae  push rdx
00007767631d9baf  push rdi
00007767631d9bb0  push rsi
00007767631d9bb1  push r8
00007767631d9bb3  push r9
00007767631d9bb5  push r10
00007767631d9bb7  push r11
00007767631d9bb9  sub rsp, 0xF0
00007767631d9bc0  vmovaps [rsp], xmm0
00007767631d9bc5  vmovaps [rsp+0x10], xmm1
00007767631d9bcb  vmovaps [rsp+0x20], xmm2
00007767631d9bd1  vmovaps [rsp+0x30], xmm3
00007767631d9bd7  vmovaps [rsp+0x40], xmm4
00007767631d9bdd  vmovaps [rsp+0x50], xmm5
00007767631d9be3  vmovaps [rsp+0x60], xmm6
00007767631d9be9  vmovaps [rsp+0x70], xmm7
00007767631d9bef  vmovaps [rsp+0x80], xmm8
00007767631d9bf8  vmovaps [rsp+0x90], xmm9
00007767631d9c01  vmovaps [rsp+0xA0], xmm10
00007767631d9c0a  vmovaps [rsp+0xB0], xmm12
00007767631d9c13  vmovaps [rsp+0xC0], xmm13
00007767631d9c1c  vmovaps [rsp+0xD0], xmm14
00007767631d9c25  vmovaps [rsp+0xE0], xmm15
00007767631d9c2e  sub rsp, 0x30
00007767631d9c32  movaps [rsp], xmm11
00007767631d9c37  movaps [rsp+0x10], xmm10
00007767631d9c3d  movaps [rsp+0x20], xmm6
00007767631d9c42  lea rdi, [rsp]
00007767631d9c46  mov esi, 0x00
00007767631d9c4b  mov rax, 0x617961CDB530
00007767631d9c55  call rax
00007767631d9c57  movaps xmm11, [rsp]
00007767631d9c5c  add rsp, 0x30
00007767631d9c60  vmovaps xmm0, [rsp]
00007767631d9c65  vmovaps xmm1, [rsp+0x10]
00007767631d9c6b  vmovaps xmm2, [rsp+0x20]
00007767631d9c71  vmovaps xmm3, [rsp+0x30]
00007767631d9c77  vmovaps xmm4, [rsp+0x40]
00007767631d9c7d  vmovaps xmm5, [rsp+0x50]
00007767631d9c83  vmovaps xmm6, [rsp+0x60]
00007767631d9c89  vmovaps xmm7, [rsp+0x70]
00007767631d9c8f  vmovaps xmm8, [rsp+0x80]
00007767631d9c98  vmovaps xmm9, [rsp+0x90]
00007767631d9ca1  vmovaps xmm10, [rsp+0xA0]
00007767631d9caa  vmovaps xmm12, [rsp+0xB0]
00007767631d9cb3  vmovaps xmm13, [rsp+0xC0]
00007767631d9cbc  vmovaps xmm14, [rsp+0xD0]
00007767631d9cc5  vmovaps xmm15, [rsp+0xE0]
00007767631d9cce  add rsp, 0xF0
00007767631d9cd5  pop r11
00007767631d9cd7  pop r10
00007767631d9cd9  pop r9
00007767631d9cdb  pop r8
00007767631d9cdd  pop rsi
00007767631d9cde  pop rdi
00007767631d9cdf  pop rdx
00007767631d9ce0  pop rcx
00007767631d9ce1  pop rax
00007767631d9ce2  add rsp, 0x08
00007767631d9ce6  jmp 0x00007767631D636D
00007767631d9ceb  sub rsp, 0x08
00007767631d9cef  push rax
00007767631d9cf0  push rcx
00007767631d9cf1  push rdx
00007767631d9cf2  push rdi
00007767631d9cf3  push rsi
00007767631d9cf4  push r8
00007767631d9cf6  push r9
00007767631d9cf8  push r10
00007767631d9cfa  push r11
00007767631d9cfc  sub rsp, 0xF0
00007767631d9d03  vmovaps [rsp], xmm0
00007767631d9d08  vmovaps [rsp+0x10], xmm1
00007767631d9d0e  vmovaps [rsp+0x20], xmm2
00007767631d9d14  vmovaps [rsp+0x30], xmm3
00007767631d9d1a  vmovaps [rsp+0x40], xmm4
00007767631d9d20  vmovaps [rsp+0x50], xmm5
00007767631d9d26  vmovaps [rsp+0x60], xmm6
00007767631d9d2c  vmovaps [rsp+0x70], xmm7
00007767631d9d32  vmovaps [rsp+0x80], xmm8
00007767631d9d3b  vmovaps [rsp+0x90], xmm9
00007767631d9d44  vmovaps [rsp+0xA0], xmm11
00007767631d9d4d  vmovaps [rsp+0xB0], xmm12
00007767631d9d56  vmovaps [rsp+0xC0], xmm13
00007767631d9d5f  vmovaps [rsp+0xD0], xmm14
00007767631d9d68  vmovaps [rsp+0xE0], xmm15
00007767631d9d71  sub rsp, 0x30
00007767631d9d75  movaps [rsp], xmm10
00007767631d9d7a  movaps [rsp+0x10], xmm14
00007767631d9d80  movaps [rsp+0x20], xmm4
00007767631d9d85  lea rdi, [rsp]
00007767631d9d89  mov esi, 0x00
00007767631d9d8e  mov rax, 0x617961CDB530
00007767631d9d98  call rax
00007767631d9d9a  movaps xmm10, [rsp]
00007767631d9d9f  add rsp, 0x30
00007767631d9da3  vmovaps xmm0, [rsp]
00007767631d9da8  vmovaps xmm1, [rsp+0x10]
00007767631d9dae  vmovaps xmm2, [rsp+0x20]
00007767631d9db4  vmovaps xmm3, [rsp+0x30]
00007767631d9dba  vmovaps xmm4, [rsp+0x40]
00007767631d9dc0  vmovaps xmm5, [rsp+0x50]
00007767631d9dc6  vmovaps xmm6, [rsp+0x60]
00007767631d9dcc  vmovaps xmm7, [rsp+0x70]
00007767631d9dd2  vmovaps xmm8, [rsp+0x80]
00007767631d9ddb  vmovaps xmm9, [rsp+0x90]
00007767631d9de4  vmovaps xmm11, [rsp+0xA0]
00007767631d9ded  vmovaps xmm12, [rsp+0xB0]
00007767631d9df6  vmovaps xmm13, [rsp+0xC0]
00007767631d9dff  vmovaps xmm14, [rsp+0xD0]
00007767631d9e08  vmovaps xmm15, [rsp+0xE0]
00007767631d9e11  add rsp, 0xF0
00007767631d9e18  pop r11
00007767631d9e1a  pop r10
00007767631d9e1c  pop r9
00007767631d9e1e  pop r8
00007767631d9e20  pop rsi
00007767631d9e21  pop rdi
00007767631d9e22  pop rdx
00007767631d9e23  pop rcx
00007767631d9e24  pop rax
00007767631d9e25  add rsp, 0x08
00007767631d9e29  jmp 0x00007767631D6388
00007767631d9e2e  sub rsp, 0x08
00007767631d9e32  push rax
00007767631d9e33  push rcx
00007767631d9e34  push rdx
00007767631d9e35  push rdi
00007767631d9e36  push rsi
00007767631d9e37  push r8
00007767631d9e39  push r9
00007767631d9e3b  push r10
00007767631d9e3d  push r11
00007767631d9e3f  sub rsp, 0xF0
00007767631d9e46  vmovaps [rsp], xmm0
00007767631d9e4b  vmovaps [rsp+0x10], xmm1
00007767631d9e51  vmovaps [rsp+0x20], xmm2
00007767631d9e57  vmovaps [rsp+0x30], xmm3
00007767631d9e5d  vmovaps [rsp+0x40], xmm4
00007767631d9e63  vmovaps [rsp+0x50], xmm5
00007767631d9e69  vmovaps [rsp+0x60], xmm6
00007767631d9e6f  vmovaps [rsp+0x70], xmm7
00007767631d9e75  vmovaps [rsp+0x80], xmm9
00007767631d9e7e  vmovaps [rsp+0x90], xmm10
00007767631d9e87  vmovaps [rsp+0xA0], xmm11
00007767631d9e90  vmovaps [rsp+0xB0], xmm12
00007767631d9e99  vmovaps [rsp+0xC0], xmm13
00007767631d9ea2  vmovaps [rsp+0xD0], xmm14
00007767631d9eab  vmovaps [rsp+0xE0], xmm15
00007767631d9eb4  sub rsp, 0x30
00007767631d9eb8  movaps [rsp], xmm8
00007767631d9ebd  movaps [rsp+0x10], xmm1
00007767631d9ec2  movaps [rsp+0x20], xmm14
00007767631d9ec8  lea rdi, [rsp]
00007767631d9ecc  mov esi, 0x00
00007767631d9ed1  mov rax, 0x617961CDB530
00007767631d9edb  call rax
00007767631d9edd  movaps xmm8, [rsp]
00007767631d9ee2  add rsp, 0x30
00007767631d9ee6  vmovaps xmm0, [rsp]
00007767631d9eeb  vmovaps xmm1, [rsp+0x10]
00007767631d9ef1  vmovaps xmm2, [rsp+0x20]
00007767631d9ef7  vmovaps xmm3, [rsp+0x30]
00007767631d9efd  vmovaps xmm4, [rsp+0x40]
00007767631d9f03  vmovaps xmm5, [rsp+0x50]
00007767631d9f09  vmovaps xmm6, [rsp+0x60]
00007767631d9f0f  vmovaps xmm7, [rsp+0x70]
00007767631d9f15  vmovaps xmm9, [rsp+0x80]
00007767631d9f1e  vmovaps xmm10, [rsp+0x90]
00007767631d9f27  vmovaps xmm11, [rsp+0xA0]
00007767631d9f30  vmovaps xmm12, [rsp+0xB0]
00007767631d9f39  vmovaps xmm13, [rsp+0xC0]
00007767631d9f42  vmovaps xmm14, [rsp+0xD0]
00007767631d9f4b  vmovaps xmm15, [rsp+0xE0]
00007767631d9f54  add rsp, 0xF0
00007767631d9f5b  pop r11
00007767631d9f5d  pop r10
00007767631d9f5f  pop r9
00007767631d9f61  pop r8
00007767631d9f63  pop rsi
00007767631d9f64  pop rdi
00007767631d9f65  pop rdx
00007767631d9f66  pop rcx
00007767631d9f67  pop rax
00007767631d9f68  add rsp, 0x08
00007767631d9f6c  jmp 0x00007767631D63AE
00007767631d9f71  sub rsp, 0x08
00007767631d9f75  push rax
00007767631d9f76  push rcx
00007767631d9f77  push rdx
00007767631d9f78  push rdi
00007767631d9f79  push rsi
00007767631d9f7a  push r8
00007767631d9f7c  push r9
00007767631d9f7e  push r10
00007767631d9f80  push r11
00007767631d9f82  sub rsp, 0xF0
00007767631d9f89  vmovaps [rsp], xmm0
00007767631d9f8e  vmovaps [rsp+0x10], xmm1
00007767631d9f94  vmovaps [rsp+0x20], xmm2
00007767631d9f9a  vmovaps [rsp+0x30], xmm3
00007767631d9fa0  vmovaps [rsp+0x40], xmm4
00007767631d9fa6  vmovaps [rsp+0x50], xmm5
00007767631d9fac  vmovaps [rsp+0x60], xmm7
00007767631d9fb2  vmovaps [rsp+0x70], xmm8
00007767631d9fb8  vmovaps [rsp+0x80], xmm9
00007767631d9fc1  vmovaps [rsp+0x90], xmm10
00007767631d9fca  vmovaps [rsp+0xA0], xmm11
00007767631d9fd3  vmovaps [rsp+0xB0], xmm12
00007767631d9fdc  vmovaps [rsp+0xC0], xmm13
00007767631d9fe5  vmovaps [rsp+0xD0], xmm14
00007767631d9fee  vmovaps [rsp+0xE0], xmm15
00007767631d9ff7  sub rsp, 0x30
00007767631d9ffb  movaps [rsp], xmm6
00007767631d9fff  movaps [rsp+0x10], xmm1
00007767631da004  movaps [rsp+0x20], xmm14
00007767631da00a  lea rdi, [rsp]
00007767631da00e  mov esi, 0x00
00007767631da013  mov rax, 0x617961CDB530
00007767631da01d  call rax
00007767631da01f  movaps xmm6, [rsp]
00007767631da023  add rsp, 0x30
00007767631da027  vmovaps xmm0, [rsp]
00007767631da02c  vmovaps xmm1, [rsp+0x10]
00007767631da032  vmovaps xmm2, [rsp+0x20]
00007767631da038  vmovaps xmm3, [rsp+0x30]
00007767631da03e  vmovaps xmm4, [rsp+0x40]
00007767631da044  vmovaps xmm5, [rsp+0x50]
00007767631da04a  vmovaps xmm7, [rsp+0x60]
00007767631da050  vmovaps xmm8, [rsp+0x70]
00007767631da056  vmovaps xmm9, [rsp+0x80]
00007767631da05f  vmovaps xmm10, [rsp+0x90]
00007767631da068  vmovaps xmm11, [rsp+0xA0]
00007767631da071  vmovaps xmm12, [rsp+0xB0]
00007767631da07a  vmovaps xmm13, [rsp+0xC0]
00007767631da083  vmovaps xmm14, [rsp+0xD0]
00007767631da08c  vmovaps xmm15, [rsp+0xE0]
00007767631da095  add rsp, 0xF0
00007767631da09c  pop r11
00007767631da09e  pop r10
00007767631da0a0  pop r9
00007767631da0a2  pop r8
00007767631da0a4  pop rsi
00007767631da0a5  pop rdi
00007767631da0a6  pop rdx
00007767631da0a7  pop rcx
00007767631da0a8  pop rax
00007767631da0a9  add rsp, 0x08
00007767631da0ad  jmp 0x00007767631D63DA
00007767631da0b2  sub rsp, 0x08
00007767631da0b6  push rax
00007767631da0b7  push rcx
00007767631da0b8  push rdx
00007767631da0b9  push rdi
00007767631da0ba  push rsi
00007767631da0bb  push r8
00007767631da0bd  push r9
00007767631da0bf  push r10
00007767631da0c1  push r11
00007767631da0c3  sub rsp, 0xF0
00007767631da0ca  vmovaps [rsp], xmm0
00007767631da0cf  vmovaps [rsp+0x10], xmm1
00007767631da0d5  vmovaps [rsp+0x20], xmm2
00007767631da0db  vmovaps [rsp+0x30], xmm3
00007767631da0e1  vmovaps [rsp+0x40], xmm4
00007767631da0e7  vmovaps [rsp+0x50], xmm5
00007767631da0ed  vmovaps [rsp+0x60], xmm6
00007767631da0f3  vmovaps [rsp+0x70], xmm7
00007767631da0f9  vmovaps [rsp+0x80], xmm8
00007767631da102  vmovaps [rsp+0x90], xmm9
00007767631da10b  vmovaps [rsp+0xA0], xmm10
00007767631da114  vmovaps [rsp+0xB0], xmm11
00007767631da11d  vmovaps [rsp+0xC0], xmm12
00007767631da126  vmovaps [rsp+0xD0], xmm13
00007767631da12f  vmovaps [rsp+0xE0], xmm15
00007767631da138  sub rsp, 0x30
00007767631da13c  movaps [rsp], xmm14
00007767631da141  movaps [rsp+0x10], xmm12
00007767631da147  movaps [rsp+0x20], xmm1
00007767631da14c  lea rdi, [rsp]
00007767631da150  mov esi, 0x00
00007767631da155  mov rax, 0x617961CDB530
00007767631da15f  call rax
00007767631da161  movaps xmm14, [rsp]
00007767631da166  add rsp, 0x30
00007767631da16a  vmovaps xmm0, [rsp]
00007767631da16f  vmovaps xmm1, [rsp+0x10]
00007767631da175  vmovaps xmm2, [rsp+0x20]
00007767631da17b  vmovaps xmm3, [rsp+0x30]
00007767631da181  vmovaps xmm4, [rsp+0x40]
00007767631da187  vmovaps xmm5, [rsp+0x50]
00007767631da18d  vmovaps xmm6, [rsp+0x60]
00007767631da193  vmovaps xmm7, [rsp+0x70]
00007767631da199  vmovaps xmm8, [rsp+0x80]
00007767631da1a2  vmovaps xmm9, [rsp+0x90]
00007767631da1ab  vmovaps xmm10, [rsp+0xA0]
00007767631da1b4  vmovaps xmm11, [rsp+0xB0]
00007767631da1bd  vmovaps xmm12, [rsp+0xC0]
00007767631da1c6  vmovaps xmm13, [rsp+0xD0]
00007767631da1cf  vmovaps xmm15, [rsp+0xE0]
00007767631da1d8  add rsp, 0xF0
00007767631da1df  pop r11
00007767631da1e1  pop r10
00007767631da1e3  pop r9
00007767631da1e5  pop r8
00007767631da1e7  pop rsi
00007767631da1e8  pop rdi
00007767631da1e9  pop rdx
00007767631da1ea  pop rcx
00007767631da1eb  pop rax
00007767631da1ec  add rsp, 0x08
00007767631da1f0  jmp 0x00007767631D6400
00007767631da1f5  sub rsp, 0x08
00007767631da1f9  push rax
00007767631da1fa  push rcx
00007767631da1fb  push rdx
00007767631da1fc  push rdi
00007767631da1fd  push rsi
00007767631da1fe  push r8
00007767631da200  push r9
00007767631da202  push r10
00007767631da204  push r11
00007767631da206  sub rsp, 0xF0
00007767631da20d  vmovaps [rsp], xmm0
00007767631da212  vmovaps [rsp+0x10], xmm2
00007767631da218  vmovaps [rsp+0x20], xmm3
00007767631da21e  vmovaps [rsp+0x30], xmm4
00007767631da224  vmovaps [rsp+0x40], xmm5
00007767631da22a  vmovaps [rsp+0x50], xmm6
00007767631da230  vmovaps [rsp+0x60], xmm7
00007767631da236  vmovaps [rsp+0x70], xmm8
00007767631da23c  vmovaps [rsp+0x80], xmm9
00007767631da245  vmovaps [rsp+0x90], xmm10
00007767631da24e  vmovaps [rsp+0xA0], xmm11
00007767631da257  vmovaps [rsp+0xB0], xmm12
00007767631da260  vmovaps [rsp+0xC0], xmm13
00007767631da269  vmovaps [rsp+0xD0], xmm14
00007767631da272  vmovaps [rsp+0xE0], xmm15
00007767631da27b  sub rsp, 0x30
00007767631da27f  movaps [rsp], xmm1
00007767631da283  movaps [rsp+0x10], xmm13
00007767631da289  movaps [rsp+0x20], xmm9
00007767631da28f  lea rdi, [rsp]
00007767631da293  mov esi, 0x00
00007767631da298  mov rax, 0x617961CDB530
00007767631da2a2  call rax
00007767631da2a4  movaps xmm1, [rsp]
00007767631da2a8  add rsp, 0x30
00007767631da2ac  vmovaps xmm0, [rsp]
00007767631da2b1  vmovaps xmm2, [rsp+0x10]
00007767631da2b7  vmovaps xmm3, [rsp+0x20]
00007767631da2bd  vmovaps xmm4, [rsp+0x30]
00007767631da2c3  vmovaps xmm5, [rsp+0x40]
00007767631da2c9  vmovaps xmm6, [rsp+0x50]
00007767631da2cf  vmovaps xmm7, [rsp+0x60]
00007767631da2d5  vmovaps xmm8, [rsp+0x70]
00007767631da2db  vmovaps xmm9, [rsp+0x80]
00007767631da2e4  vmovaps xmm10, [rsp+0x90]
00007767631da2ed  vmovaps xmm11, [rsp+0xA0]
00007767631da2f6  vmovaps xmm12, [rsp+0xB0]
00007767631da2ff  vmovaps xmm13, [rsp+0xC0]
00007767631da308  vmovaps xmm14, [rsp+0xD0]
00007767631da311  vmovaps xmm15, [rsp+0xE0]
00007767631da31a  add rsp, 0xF0
00007767631da321  pop r11
00007767631da323  pop r10
00007767631da325  pop r9
00007767631da327  pop r8
00007767631da329  pop rsi
00007767631da32a  pop rdi
00007767631da32b  pop rdx
00007767631da32c  pop rcx
00007767631da32d  pop rax
00007767631da32e  add rsp, 0x08
00007767631da332  jmp 0x00007767631D641A
00007767631da337  sub rsp, 0x08
00007767631da33b  push rax
00007767631da33c  push rcx
00007767631da33d  push rdx
00007767631da33e  push rdi
00007767631da33f  push rsi
00007767631da340  push r8
00007767631da342  push r9
00007767631da344  push r10
00007767631da346  push r11
00007767631da348  sub rsp, 0xF0
00007767631da34f  vmovaps [rsp], xmm0
00007767631da354  vmovaps [rsp+0x10], xmm1
00007767631da35a  vmovaps [rsp+0x20], xmm2
00007767631da360  vmovaps [rsp+0x30], xmm3
00007767631da366  vmovaps [rsp+0x40], xmm4
00007767631da36c  vmovaps [rsp+0x50], xmm5
00007767631da372  vmovaps [rsp+0x60], xmm6
00007767631da378  vmovaps [rsp+0x70], xmm7
00007767631da37e  vmovaps [rsp+0x80], xmm8
00007767631da387  vmovaps [rsp+0x90], xmm9
00007767631da390  vmovaps [rsp+0xA0], xmm10
00007767631da399  vmovaps [rsp+0xB0], xmm11
00007767631da3a2  vmovaps [rsp+0xC0], xmm13
00007767631da3ab  vmovaps [rsp+0xD0], xmm14
00007767631da3b4  vmovaps [rsp+0xE0], xmm15
00007767631da3bd  sub rsp, 0x30
00007767631da3c1  movaps [rsp], xmm12
00007767631da3c6  movaps [rsp+0x10], xmm7
00007767631da3cb  movaps [rsp+0x20], xmm13
00007767631da3d1  lea rdi, [rsp]
00007767631da3d5  mov esi, 0x00
00007767631da3da  mov rax, 0x617961CDB530
00007767631da3e4  call rax
00007767631da3e6  movaps xmm12, [rsp]
00007767631da3eb  add rsp, 0x30
00007767631da3ef  vmovaps xmm0, [rsp]
00007767631da3f4  vmovaps xmm1, [rsp+0x10]
00007767631da3fa  vmovaps xmm2, [rsp+0x20]
00007767631da400  vmovaps xmm3, [rsp+0x30]
00007767631da406  vmovaps xmm4, [rsp+0x40]
00007767631da40c  vmovaps xmm5, [rsp+0x50]
00007767631da412  vmovaps xmm6, [rsp+0x60]
00007767631da418  vmovaps xmm7, [rsp+0x70]
00007767631da41e  vmovaps xmm8, [rsp+0x80]
00007767631da427  vmovaps xmm9, [rsp+0x90]
00007767631da430  vmovaps xmm10, [rsp+0xA0]
00007767631da439  vmovaps xmm11, [rsp+0xB0]
00007767631da442  vmovaps xmm13, [rsp+0xC0]
00007767631da44b  vmovaps xmm14, [rsp+0xD0]
00007767631da454  vmovaps xmm15, [rsp+0xE0]
00007767631da45d  add rsp, 0xF0
00007767631da464  pop r11
00007767631da466  pop r10
00007767631da468  pop r9
00007767631da46a  pop r8
00007767631da46c  pop rsi
00007767631da46d  pop rdi
00007767631da46e  pop rdx
00007767631da46f  pop rcx
00007767631da470  pop rax
00007767631da471  add rsp, 0x08
00007767631da475  jmp 0x00007767631D6441
00007767631da47a  sub rsp, 0x08
00007767631da47e  push rax
00007767631da47f  push rcx
00007767631da480  push rdx
00007767631da481  push rdi
00007767631da482  push rsi
00007767631da483  push r8
00007767631da485  push r9
00007767631da487  push r10
00007767631da489  push r11
00007767631da48b  sub rsp, 0xF0
00007767631da492  vmovaps [rsp], xmm0
00007767631da497  vmovaps [rsp+0x10], xmm1
00007767631da49d  vmovaps [rsp+0x20], xmm2
00007767631da4a3  vmovaps [rsp+0x30], xmm3
00007767631da4a9  vmovaps [rsp+0x40], xmm4
00007767631da4af  vmovaps [rsp+0x50], xmm5
00007767631da4b5  vmovaps [rsp+0x60], xmm6
00007767631da4bb  vmovaps [rsp+0x70], xmm7
00007767631da4c1  vmovaps [rsp+0x80], xmm8
00007767631da4ca  vmovaps [rsp+0x90], xmm9
00007767631da4d3  vmovaps [rsp+0xA0], xmm10
00007767631da4dc  vmovaps [rsp+0xB0], xmm11
00007767631da4e5  vmovaps [rsp+0xC0], xmm12
00007767631da4ee  vmovaps [rsp+0xD0], xmm14
00007767631da4f7  vmovaps [rsp+0xE0], xmm15
00007767631da500  sub rsp, 0x30
00007767631da504  movaps [rsp], xmm13
00007767631da509  movaps [rsp+0x10], xmm15
00007767631da50f  movaps [rsp+0x20], xmm8
00007767631da515  lea rdi, [rsp]
00007767631da519  mov esi, 0x00
00007767631da51e  mov rax, 0x617961CDB530
00007767631da528  call rax
00007767631da52a  movaps xmm13, [rsp]
00007767631da52f  add rsp, 0x30
00007767631da533  vmovaps xmm0, [rsp]
00007767631da538  vmovaps xmm1, [rsp+0x10]
00007767631da53e  vmovaps xmm2, [rsp+0x20]
00007767631da544  vmovaps xmm3, [rsp+0x30]
00007767631da54a  vmovaps xmm4, [rsp+0x40]
00007767631da550  vmovaps xmm5, [rsp+0x50]
00007767631da556  vmovaps xmm6, [rsp+0x60]
00007767631da55c  vmovaps xmm7, [rsp+0x70]
00007767631da562  vmovaps xmm8, [rsp+0x80]
00007767631da56b  vmovaps xmm9, [rsp+0x90]
00007767631da574  vmovaps xmm10, [rsp+0xA0]
00007767631da57d  vmovaps xmm11, [rsp+0xB0]
00007767631da586  vmovaps xmm12, [rsp+0xC0]
00007767631da58f  vmovaps xmm14, [rsp+0xD0]
00007767631da598  vmovaps xmm15, [rsp+0xE0]
00007767631da5a1  add rsp, 0xF0
00007767631da5a8  pop r11
00007767631da5aa  pop r10
00007767631da5ac  pop r9
00007767631da5ae  pop r8
00007767631da5b0  pop rsi
00007767631da5b1  pop rdi
00007767631da5b2  pop rdx
00007767631da5b3  pop rcx
00007767631da5b4  pop rax
00007767631da5b5  add rsp, 0x08
00007767631da5b9  jmp 0x00007767631D645C
00007767631da5be  sub rsp, 0x08
00007767631da5c2  push rax
00007767631da5c3  push rcx
00007767631da5c4  push rdx
00007767631da5c5  push rdi
00007767631da5c6  push rsi
00007767631da5c7  push r8
00007767631da5c9  push r9
00007767631da5cb  push r10
00007767631da5cd  push r11
00007767631da5cf  sub rsp, 0xF0
00007767631da5d6  vmovaps [rsp], xmm0
00007767631da5db  vmovaps [rsp+0x10], xmm1
00007767631da5e1  vmovaps [rsp+0x20], xmm2
00007767631da5e7  vmovaps [rsp+0x30], xmm3
00007767631da5ed  vmovaps [rsp+0x40], xmm4
00007767631da5f3  vmovaps [rsp+0x50], xmm5
00007767631da5f9  vmovaps [rsp+0x60], xmm6
00007767631da5ff  vmovaps [rsp+0x70], xmm7
00007767631da605  vmovaps [rsp+0x80], xmm9
00007767631da60e  vmovaps [rsp+0x90], xmm10
00007767631da617  vmovaps [rsp+0xA0], xmm11
00007767631da620  vmovaps [rsp+0xB0], xmm12
00007767631da629  vmovaps [rsp+0xC0], xmm13
00007767631da632  vmovaps [rsp+0xD0], xmm14
00007767631da63b  vmovaps [rsp+0xE0], xmm15
00007767631da644  sub rsp, 0x30
00007767631da648  movaps [rsp], xmm8
00007767631da64d  movaps [rsp+0x10], xmm15
00007767631da653  movaps [rsp+0x20], xmm9
00007767631da659  lea rdi, [rsp]
00007767631da65d  mov esi, 0x00
00007767631da662  mov rax, 0x617961CDB530
00007767631da66c  call rax
00007767631da66e  movaps xmm8, [rsp]
00007767631da673  add rsp, 0x30
00007767631da677  vmovaps xmm0, [rsp]
00007767631da67c  vmovaps xmm1, [rsp+0x10]
00007767631da682  vmovaps xmm2, [rsp+0x20]
00007767631da688  vmovaps xmm3, [rsp+0x30]
00007767631da68e  vmovaps xmm4, [rsp+0x40]
00007767631da694  vmovaps xmm5, [rsp+0x50]
00007767631da69a  vmovaps xmm6, [rsp+0x60]
00007767631da6a0  vmovaps xmm7, [rsp+0x70]
00007767631da6a6  vmovaps xmm9, [rsp+0x80]
00007767631da6af  vmovaps xmm10, [rsp+0x90]
00007767631da6b8  vmovaps xmm11, [rsp+0xA0]
00007767631da6c1  vmovaps xmm12, [rsp+0xB0]
00007767631da6ca  vmovaps xmm13, [rsp+0xC0]
00007767631da6d3  vmovaps xmm14, [rsp+0xD0]
00007767631da6dc  vmovaps xmm15, [rsp+0xE0]
00007767631da6e5  add rsp, 0xF0
00007767631da6ec  pop r11
00007767631da6ee  pop r10
00007767631da6f0  pop r9
00007767631da6f2  pop r8
00007767631da6f4  pop rsi
00007767631da6f5  pop rdi
00007767631da6f6  pop rdx
00007767631da6f7  pop rcx
00007767631da6f8  pop rax
00007767631da6f9  add rsp, 0x08
00007767631da6fd  jmp 0x00007767631D648A
00007767631da702  sub rsp, 0x08
00007767631da706  push rax
00007767631da707  push rcx
00007767631da708  push rdx
00007767631da709  push rdi
00007767631da70a  push rsi
00007767631da70b  push r8
00007767631da70d  push r9
00007767631da70f  push r10
00007767631da711  push r11
00007767631da713  sub rsp, 0xF0
00007767631da71a  vmovaps [rsp], xmm0
00007767631da71f  vmovaps [rsp+0x10], xmm1
00007767631da725  vmovaps [rsp+0x20], xmm2
00007767631da72b  vmovaps [rsp+0x30], xmm3
00007767631da731  vmovaps [rsp+0x40], xmm4
00007767631da737  vmovaps [rsp+0x50], xmm5
00007767631da73d  vmovaps [rsp+0x60], xmm6
00007767631da743  vmovaps [rsp+0x70], xmm7
00007767631da749  vmovaps [rsp+0x80], xmm8
00007767631da752  vmovaps [rsp+0x90], xmm9
00007767631da75b  vmovaps [rsp+0xA0], xmm10
00007767631da764  vmovaps [rsp+0xB0], xmm11
00007767631da76d  vmovaps [rsp+0xC0], xmm12
00007767631da776  vmovaps [rsp+0xD0], xmm13
00007767631da77f  vmovaps [rsp+0xE0], xmm14
00007767631da788  sub rsp, 0x30
00007767631da78c  movaps [rsp], xmm15
00007767631da791  movaps [rsp+0x10], xmm11
00007767631da797  movaps [rsp+0x20], xmm6
00007767631da79c  lea rdi, [rsp]
00007767631da7a0  mov esi, 0x00
00007767631da7a5  mov rax, 0x617961CDB530
00007767631da7af  call rax
00007767631da7b1  movaps xmm15, [rsp]
00007767631da7b6  add rsp, 0x30
00007767631da7ba  vmovaps xmm0, [rsp]
00007767631da7bf  vmovaps xmm1, [rsp+0x10]
00007767631da7c5  vmovaps xmm2, [rsp+0x20]
00007767631da7cb  vmovaps xmm3, [rsp+0x30]
00007767631da7d1  vmovaps xmm4, [rsp+0x40]
00007767631da7d7  vmovaps xmm5, [rsp+0x50]
00007767631da7dd  vmovaps xmm6, [rsp+0x60]
00007767631da7e3  vmovaps xmm7, [rsp+0x70]
00007767631da7e9  vmovaps xmm8, [rsp+0x80]
00007767631da7f2  vmovaps xmm9, [rsp+0x90]
00007767631da7fb  vmovaps xmm10, [rsp+0xA0]
00007767631da804  vmovaps xmm11, [rsp+0xB0]
00007767631da80d  vmovaps xmm12, [rsp+0xC0]
00007767631da816  vmovaps xmm13, [rsp+0xD0]
00007767631da81f  vmovaps xmm14, [rsp+0xE0]
00007767631da828  add rsp, 0xF0
00007767631da82f  pop r11
00007767631da831  pop r10
00007767631da833  pop r9
00007767631da835  pop r8
00007767631da837  pop rsi
00007767631da838  pop rdi
00007767631da839  pop rdx
00007767631da83a  pop rcx
00007767631da83b  pop rax
00007767631da83c  add rsp, 0x08
00007767631da840  jmp 0x00007767631D64A5
00007767631da845  sub rsp, 0x08
00007767631da849  push rax
00007767631da84a  push rcx
00007767631da84b  push rdx
00007767631da84c  push rdi
00007767631da84d  push rsi
00007767631da84e  push r8
00007767631da850  push r9
00007767631da852  push r10
00007767631da854  push r11
00007767631da856  sub rsp, 0xF0
00007767631da85d  vmovaps [rsp], xmm0
00007767631da862  vmovaps [rsp+0x10], xmm1
00007767631da868  vmovaps [rsp+0x20], xmm2
00007767631da86e  vmovaps [rsp+0x30], xmm3
00007767631da874  vmovaps [rsp+0x40], xmm4
00007767631da87a  vmovaps [rsp+0x50], xmm5
00007767631da880  vmovaps [rsp+0x60], xmm6
00007767631da886  vmovaps [rsp+0x70], xmm8
00007767631da88c  vmovaps [rsp+0x80], xmm9
00007767631da895  vmovaps [rsp+0x90], xmm10
00007767631da89e  vmovaps [rsp+0xA0], xmm11
00007767631da8a7  vmovaps [rsp+0xB0], xmm12
00007767631da8b0  vmovaps [rsp+0xC0], xmm13
00007767631da8b9  vmovaps [rsp+0xD0], xmm14
00007767631da8c2  vmovaps [rsp+0xE0], xmm15
00007767631da8cb  sub rsp, 0x30
00007767631da8cf  movaps [rsp], xmm7
00007767631da8d3  movaps [rsp+0x10], xmm11
00007767631da8d9  movaps [rsp+0x20], xmm9
00007767631da8df  lea rdi, [rsp]
00007767631da8e3  mov esi, 0x00
00007767631da8e8  mov rax, 0x617961CDB530
00007767631da8f2  call rax
00007767631da8f4  movaps xmm7, [rsp]
00007767631da8f8  add rsp, 0x30
00007767631da8fc  vmovaps xmm0, [rsp]
00007767631da901  vmovaps xmm1, [rsp+0x10]
00007767631da907  vmovaps xmm2, [rsp+0x20]
00007767631da90d  vmovaps xmm3, [rsp+0x30]
00007767631da913  vmovaps xmm4, [rsp+0x40]
00007767631da919  vmovaps xmm5, [rsp+0x50]
00007767631da91f  vmovaps xmm6, [rsp+0x60]
00007767631da925  vmovaps xmm8, [rsp+0x70]
00007767631da92b  vmovaps xmm9, [rsp+0x80]
00007767631da934  vmovaps xmm10, [rsp+0x90]
00007767631da93d  vmovaps xmm11, [rsp+0xA0]
00007767631da946  vmovaps xmm12, [rsp+0xB0]
00007767631da94f  vmovaps xmm13, [rsp+0xC0]
00007767631da958  vmovaps xmm14, [rsp+0xD0]
00007767631da961  vmovaps xmm15, [rsp+0xE0]
00007767631da96a  add rsp, 0xF0
00007767631da971  pop r11
00007767631da973  pop r10
00007767631da975  pop r9
00007767631da977  pop r8
00007767631da979  pop rsi
00007767631da97a  pop rdi
00007767631da97b  pop rdx
00007767631da97c  pop rcx
00007767631da97d  pop rax
00007767631da97e  add rsp, 0x08
00007767631da982  jmp 0x00007767631D64D2
00007767631da987  sub rsp, 0x08
00007767631da98b  push rax
00007767631da98c  push rcx
00007767631da98d  push rdx
00007767631da98e  push rdi
00007767631da98f  push rsi
00007767631da990  push r8
00007767631da992  push r9
00007767631da994  push r10
00007767631da996  push r11
00007767631da998  sub rsp, 0xF0
00007767631da99f  vmovaps [rsp], xmm0
00007767631da9a4  vmovaps [rsp+0x10], xmm1
00007767631da9aa  vmovaps [rsp+0x20], xmm2
00007767631da9b0  vmovaps [rsp+0x30], xmm3
00007767631da9b6  vmovaps [rsp+0x40], xmm4
00007767631da9bc  vmovaps [rsp+0x50], xmm5
00007767631da9c2  vmovaps [rsp+0x60], xmm6
00007767631da9c8  vmovaps [rsp+0x70], xmm7
00007767631da9ce  vmovaps [rsp+0x80], xmm8
00007767631da9d7  vmovaps [rsp+0x90], xmm9
00007767631da9e0  vmovaps [rsp+0xA0], xmm10
00007767631da9e9  vmovaps [rsp+0xB0], xmm12
00007767631da9f2  vmovaps [rsp+0xC0], xmm13
00007767631da9fb  vmovaps [rsp+0xD0], xmm14
00007767631daa04  vmovaps [rsp+0xE0], xmm15
00007767631daa0d  sub rsp, 0x30
00007767631daa11  movaps [rsp], xmm11
00007767631daa16  movaps [rsp+0x10], xmm10
00007767631daa1c  movaps [rsp+0x20], xmm14
00007767631daa22  lea rdi, [rsp]
00007767631daa26  mov esi, 0x00
00007767631daa2b  mov rax, 0x617961CDB530
00007767631daa35  call rax
00007767631daa37  movaps xmm11, [rsp]
00007767631daa3c  add rsp, 0x30
00007767631daa40  vmovaps xmm0, [rsp]
00007767631daa45  vmovaps xmm1, [rsp+0x10]
00007767631daa4b  vmovaps xmm2, [rsp+0x20]
00007767631daa51  vmovaps xmm3, [rsp+0x30]
00007767631daa57  vmovaps xmm4, [rsp+0x40]
00007767631daa5d  vmovaps xmm5, [rsp+0x50]
00007767631daa63  vmovaps xmm6, [rsp+0x60]
00007767631daa69  vmovaps xmm7, [rsp+0x70]
00007767631daa6f  vmovaps xmm8, [rsp+0x80]
00007767631daa78  vmovaps xmm9, [rsp+0x90]
00007767631daa81  vmovaps xmm10, [rsp+0xA0]
00007767631daa8a  vmovaps xmm12, [rsp+0xB0]
00007767631daa93  vmovaps xmm13, [rsp+0xC0]
00007767631daa9c  vmovaps xmm14, [rsp+0xD0]
00007767631daaa5  vmovaps xmm15, [rsp+0xE0]
00007767631daaae  add rsp, 0xF0
00007767631daab5  pop r11
00007767631daab7  pop r10
00007767631daab9  pop r9
00007767631daabb  pop r8
00007767631daabd  pop rsi
00007767631daabe  pop rdi
00007767631daabf  pop rdx
00007767631daac0  pop rcx
00007767631daac1  pop rax
00007767631daac2  add rsp, 0x08
00007767631daac6  jmp 0x00007767631D64ED
00007767631daacb  call 0x00007767630E45A0
00007767631daad0  jmp 0x00007767631D64F7
00007767631daad5  sub rsp, 0x08
00007767631daad9  push rax
00007767631daada  push rcx
00007767631daadb  push rdx
00007767631daadc  push rdi
00007767631daadd  push rsi
00007767631daade  push r8
00007767631daae0  push r9
00007767631daae2  push r10
00007767631daae4  push r11
00007767631daae6  sub rsp, 0xF0
00007767631daaed  vmovaps [rsp], xmm0
00007767631daaf2  vmovaps [rsp+0x10], xmm1
00007767631daaf8  vmovaps [rsp+0x20], xmm2
00007767631daafe  vmovaps [rsp+0x30], xmm3
00007767631dab04  vmovaps [rsp+0x40], xmm4
00007767631dab0a  vmovaps [rsp+0x50], xmm5
00007767631dab10  vmovaps [rsp+0x60], xmm6
00007767631dab16  vmovaps [rsp+0x70], xmm7
00007767631dab1c  vmovaps [rsp+0x80], xmm8
00007767631dab25  vmovaps [rsp+0x90], xmm9
00007767631dab2e  vmovaps [rsp+0xA0], xmm11
00007767631dab37  vmovaps [rsp+0xB0], xmm12
00007767631dab40  vmovaps [rsp+0xC0], xmm13
00007767631dab49  vmovaps [rsp+0xD0], xmm14
00007767631dab52  vmovaps [rsp+0xE0], xmm15
00007767631dab5b  sub rsp, 0x30
00007767631dab5f  movaps [rsp], xmm10
00007767631dab64  movaps [rsp+0x10], xmm1
00007767631dab69  movaps [rsp+0x20], xmm12
00007767631dab6f  lea rdi, [rsp]
00007767631dab73  mov esi, 0x00
00007767631dab78  mov rax, 0x617961CDB530
00007767631dab82  call rax
00007767631dab84  movaps xmm10, [rsp]
00007767631dab89  add rsp, 0x30
00007767631dab8d  vmovaps xmm0, [rsp]
00007767631dab92  vmovaps xmm1, [rsp+0x10]
00007767631dab98  vmovaps xmm2, [rsp+0x20]
00007767631dab9e  vmovaps xmm3, [rsp+0x30]
00007767631daba4  vmovaps xmm4, [rsp+0x40]
00007767631dabaa  vmovaps xmm5, [rsp+0x50]
00007767631dabb0  vmovaps xmm6, [rsp+0x60]
00007767631dabb6  vmovaps xmm7, [rsp+0x70]
00007767631dabbc  vmovaps xmm8, [rsp+0x80]
00007767631dabc5  vmovaps xmm9, [rsp+0x90]
00007767631dabce  vmovaps xmm11, [rsp+0xA0]
00007767631dabd7  vmovaps xmm12, [rsp+0xB0]
00007767631dabe0  vmovaps xmm13, [rsp+0xC0]
00007767631dabe9  vmovaps xmm14, [rsp+0xD0]
00007767631dabf2  vmovaps xmm15, [rsp+0xE0]
00007767631dabfb  add rsp, 0xF0
00007767631dac02  pop r11
00007767631dac04  pop r10
00007767631dac06  pop r9
00007767631dac08  pop r8
00007767631dac0a  pop rsi
00007767631dac0b  pop rdi
00007767631dac0c  pop rdx
00007767631dac0d  pop rcx
00007767631dac0e  pop rax
00007767631dac0f  add rsp, 0x08
00007767631dac13  jmp 0x00007767631D651A
00007767631dac18  sub rsp, 0x08
00007767631dac1c  push rax
00007767631dac1d  push rcx
00007767631dac1e  push rdx
00007767631dac1f  push rdi
00007767631dac20  push rsi
00007767631dac21  push r8
00007767631dac23  push r9
00007767631dac25  push r10
00007767631dac27  push r11
00007767631dac29  sub rsp, 0xF0
00007767631dac30  vmovaps [rsp], xmm0
00007767631dac35  vmovaps [rsp+0x10], xmm1
00007767631dac3b  vmovaps [rsp+0x20], xmm2
00007767631dac41  vmovaps [rsp+0x30], xmm3
00007767631dac47  vmovaps [rsp+0x40], xmm4
00007767631dac4d  vmovaps [rsp+0x50], xmm5
00007767631dac53  vmovaps [rsp+0x60], xmm6
00007767631dac59  vmovaps [rsp+0x70], xmm7
00007767631dac5f  vmovaps [rsp+0x80], xmm8
00007767631dac68  vmovaps [rsp+0x90], xmm9
00007767631dac71  vmovaps [rsp+0xA0], xmm10
00007767631dac7a  vmovaps [rsp+0xB0], xmm11
00007767631dac83  vmovaps [rsp+0xC0], xmm13
00007767631dac8c  vmovaps [rsp+0xD0], xmm14
00007767631dac95  vmovaps [rsp+0xE0], xmm15
00007767631dac9e  sub rsp, 0x30
00007767631daca2  movaps [rsp], xmm12
00007767631daca7  movaps [rsp+0x10], xmm14
00007767631dacad  movaps [rsp+0x20], xmm1
00007767631dacb2  lea rdi, [rsp]
00007767631dacb6  mov esi, 0x00
00007767631dacbb  mov rax, 0x617961CDB530
00007767631dacc5  call rax
00007767631dacc7  movaps xmm12, [rsp]
00007767631daccc  add rsp, 0x30
00007767631dacd0  vmovaps xmm0, [rsp]
00007767631dacd5  vmovaps xmm1, [rsp+0x10]
00007767631dacdb  vmovaps xmm2, [rsp+0x20]
00007767631dace1  vmovaps xmm3, [rsp+0x30]
00007767631dace7  vmovaps xmm4, [rsp+0x40]
00007767631daced  vmovaps xmm5, [rsp+0x50]
00007767631dacf3  vmovaps xmm6, [rsp+0x60]
00007767631dacf9  vmovaps xmm7, [rsp+0x70]
00007767631dacff  vmovaps xmm8, [rsp+0x80]
00007767631dad08  vmovaps xmm9, [rsp+0x90]
00007767631dad11  vmovaps xmm10, [rsp+0xA0]
00007767631dad1a  vmovaps xmm11, [rsp+0xB0]
00007767631dad23  vmovaps xmm13, [rsp+0xC0]
00007767631dad2c  vmovaps xmm14, [rsp+0xD0]
00007767631dad35  vmovaps xmm15, [rsp+0xE0]
00007767631dad3e  add rsp, 0xF0
00007767631dad45  pop r11
00007767631dad47  pop r10
00007767631dad49  pop r9
00007767631dad4b  pop r8
00007767631dad4d  pop rsi
00007767631dad4e  pop rdi
00007767631dad4f  pop rdx
00007767631dad50  pop rcx
00007767631dad51  pop rax
00007767631dad52  add rsp, 0x08
00007767631dad56  jmp 0x00007767631D6549
00007767631dad5b  sub rsp, 0x08
00007767631dad5f  push rax
00007767631dad60  push rcx
00007767631dad61  push rdx
00007767631dad62  push rdi
00007767631dad63  push rsi
00007767631dad64  push r8
00007767631dad66  push r9
00007767631dad68  push r10
00007767631dad6a  push r11
00007767631dad6c  sub rsp, 0xF0
00007767631dad73  vmovaps [rsp], xmm0
00007767631dad78  vmovaps [rsp+0x10], xmm1
00007767631dad7e  vmovaps [rsp+0x20], xmm2
00007767631dad84  vmovaps [rsp+0x30], xmm3
00007767631dad8a  vmovaps [rsp+0x40], xmm4
00007767631dad90  vmovaps [rsp+0x50], xmm5
00007767631dad96  vmovaps [rsp+0x60], xmm6
00007767631dad9c  vmovaps [rsp+0x70], xmm7
00007767631dada2  vmovaps [rsp+0x80], xmm8
00007767631dadab  vmovaps [rsp+0x90], xmm9
00007767631dadb4  vmovaps [rsp+0xA0], xmm10
00007767631dadbd  vmovaps [rsp+0xB0], xmm11
00007767631dadc6  vmovaps [rsp+0xC0], xmm12
00007767631dadcf  vmovaps [rsp+0xD0], xmm13
00007767631dadd8  vmovaps [rsp+0xE0], xmm15
00007767631dade1  sub rsp, 0x30
00007767631dade5  movaps [rsp], xmm14
00007767631dadea  movaps [rsp+0x10], xmm9
00007767631dadf0  movaps [rsp+0x20], xmm1
00007767631dadf5  lea rdi, [rsp]
00007767631dadf9  mov esi, 0x00
00007767631dadfe  mov rax, 0x617961CDB530
00007767631dae08  call rax
00007767631dae0a  movaps xmm14, [rsp]
00007767631dae0f  add rsp, 0x30
00007767631dae13  vmovaps xmm0, [rsp]
00007767631dae18  vmovaps xmm1, [rsp+0x10]
00007767631dae1e  vmovaps xmm2, [rsp+0x20]
00007767631dae24  vmovaps xmm3, [rsp+0x30]
00007767631dae2a  vmovaps xmm4, [rsp+0x40]
00007767631dae30  vmovaps xmm5, [rsp+0x50]
00007767631dae36  vmovaps xmm6, [rsp+0x60]
00007767631dae3c  vmovaps xmm7, [rsp+0x70]
00007767631dae42  vmovaps xmm8, [rsp+0x80]
00007767631dae4b  vmovaps xmm9, [rsp+0x90]
00007767631dae54  vmovaps xmm10, [rsp+0xA0]
00007767631dae5d  vmovaps xmm11, [rsp+0xB0]
00007767631dae66  vmovaps xmm12, [rsp+0xC0]
00007767631dae6f  vmovaps xmm13, [rsp+0xD0]
00007767631dae78  vmovaps xmm15, [rsp+0xE0]
00007767631dae81  add rsp, 0xF0
00007767631dae88  pop r11
00007767631dae8a  pop r10
00007767631dae8c  pop r9
00007767631dae8e  pop r8
00007767631dae90  pop rsi
00007767631dae91  pop rdi
00007767631dae92  pop rdx
00007767631dae93  pop rcx
00007767631dae94  pop rax
00007767631dae95  add rsp, 0x08
00007767631dae99  jmp 0x00007767631D6578
00007767631dae9e  sub rsp, 0x08
00007767631daea2  push rax
00007767631daea3  push rcx
00007767631daea4  push rdx
00007767631daea5  push rdi
00007767631daea6  push rsi
00007767631daea7  push r8
00007767631daea9  push r9
00007767631daeab  push r10
00007767631daead  push r11
00007767631daeaf  sub rsp, 0xF0
00007767631daeb6  vmovaps [rsp], xmm0
00007767631daebb  vmovaps [rsp+0x10], xmm2
00007767631daec1  vmovaps [rsp+0x20], xmm3
00007767631daec7  vmovaps [rsp+0x30], xmm4
00007767631daecd  vmovaps [rsp+0x40], xmm5
00007767631daed3  vmovaps [rsp+0x50], xmm6
00007767631daed9  vmovaps [rsp+0x60], xmm7
00007767631daedf  vmovaps [rsp+0x70], xmm8
00007767631daee5  vmovaps [rsp+0x80], xmm9
00007767631daeee  vmovaps [rsp+0x90], xmm10
00007767631daef7  vmovaps [rsp+0xA0], xmm11
00007767631daf00  vmovaps [rsp+0xB0], xmm12
00007767631daf09  vmovaps [rsp+0xC0], xmm13
00007767631daf12  vmovaps [rsp+0xD0], xmm14
00007767631daf1b  vmovaps [rsp+0xE0], xmm15
00007767631daf24  sub rsp, 0x30
00007767631daf28  movaps [rsp], xmm1
00007767631daf2c  movaps [rsp+0x10], xmm13
00007767631daf32  movaps [rsp+0x20], xmm8
00007767631daf38  lea rdi, [rsp]
00007767631daf3c  mov esi, 0x00
00007767631daf41  mov rax, 0x617961CDB530
00007767631daf4b  call rax
00007767631daf4d  movaps xmm1, [rsp]
00007767631daf51  add rsp, 0x30
00007767631daf55  vmovaps xmm0, [rsp]
00007767631daf5a  vmovaps xmm2, [rsp+0x10]
00007767631daf60  vmovaps xmm3, [rsp+0x20]
00007767631daf66  vmovaps xmm4, [rsp+0x30]
00007767631daf6c  vmovaps xmm5, [rsp+0x40]
00007767631daf72  vmovaps xmm6, [rsp+0x50]
00007767631daf78  vmovaps xmm7, [rsp+0x60]
00007767631daf7e  vmovaps xmm8, [rsp+0x70]
00007767631daf84  vmovaps xmm9, [rsp+0x80]
00007767631daf8d  vmovaps xmm10, [rsp+0x90]
00007767631daf96  vmovaps xmm11, [rsp+0xA0]
00007767631daf9f  vmovaps xmm12, [rsp+0xB0]
00007767631dafa8  vmovaps xmm13, [rsp+0xC0]
00007767631dafb1  vmovaps xmm14, [rsp+0xD0]
00007767631dafba  vmovaps xmm15, [rsp+0xE0]
00007767631dafc3  add rsp, 0xF0
00007767631dafca  pop r11
00007767631dafcc  pop r10
00007767631dafce  pop r9
00007767631dafd0  pop r8
00007767631dafd2  pop rsi
00007767631dafd3  pop rdi
00007767631dafd4  pop rdx
00007767631dafd5  pop rcx
00007767631dafd6  pop rax
00007767631dafd7  add rsp, 0x08
00007767631dafdb  jmp 0x00007767631D659A
00007767631dafe0  call 0x000077676300C260
00007767631dafe5  jmp 0x00007767631D65A8
00007767631dafea  call 0x00007767630DE950
00007767631dafef  jmp 0x00007767631D65B2
00007767631daff4  sub rsp, 0x08
00007767631daff8  push rax
00007767631daff9  push rcx
00007767631daffa  push rdx
00007767631daffb  push rdi
00007767631daffc  push rsi
00007767631daffd  push r8
00007767631dafff  push r9
00007767631db001  push r10
00007767631db003  push r11
00007767631db005  sub rsp, 0xF0
00007767631db00c  vmovaps [rsp], xmm0
00007767631db011  vmovaps [rsp+0x10], xmm1
00007767631db017  vmovaps [rsp+0x20], xmm2
00007767631db01d  vmovaps [rsp+0x30], xmm3
00007767631db023  vmovaps [rsp+0x40], xmm4
00007767631db029  vmovaps [rsp+0x50], xmm5
00007767631db02f  vmovaps [rsp+0x60], xmm6
00007767631db035  vmovaps [rsp+0x70], xmm7
00007767631db03b  vmovaps [rsp+0x80], xmm9
00007767631db044  vmovaps [rsp+0x90], xmm10
00007767631db04d  vmovaps [rsp+0xA0], xmm11
00007767631db056  vmovaps [rsp+0xB0], xmm12
00007767631db05f  vmovaps [rsp+0xC0], xmm13
00007767631db068  vmovaps [rsp+0xD0], xmm14
00007767631db071  vmovaps [rsp+0xE0], xmm15
00007767631db07a  sub rsp, 0x30
00007767631db07e  movaps [rsp], xmm8
00007767631db083  movaps [rsp+0x10], xmm15
00007767631db089  movaps [rsp+0x20], xmm7
00007767631db08e  lea rdi, [rsp]
00007767631db092  mov esi, 0x00
00007767631db097  mov rax, 0x617961CDB530
00007767631db0a1  call rax
00007767631db0a3  movaps xmm8, [rsp]
00007767631db0a8  add rsp, 0x30
00007767631db0ac  vmovaps xmm0, [rsp]
00007767631db0b1  vmovaps xmm1, [rsp+0x10]
00007767631db0b7  vmovaps xmm2, [rsp+0x20]
00007767631db0bd  vmovaps xmm3, [rsp+0x30]
00007767631db0c3  vmovaps xmm4, [rsp+0x40]
00007767631db0c9  vmovaps xmm5, [rsp+0x50]
00007767631db0cf  vmovaps xmm6, [rsp+0x60]
00007767631db0d5  vmovaps xmm7, [rsp+0x70]
00007767631db0db  vmovaps xmm9, [rsp+0x80]
00007767631db0e4  vmovaps xmm10, [rsp+0x90]
00007767631db0ed  vmovaps xmm11, [rsp+0xA0]
00007767631db0f6  vmovaps xmm12, [rsp+0xB0]
00007767631db0ff  vmovaps xmm13, [rsp+0xC0]
00007767631db108  vmovaps xmm14, [rsp+0xD0]
00007767631db111  vmovaps xmm15, [rsp+0xE0]
00007767631db11a  add rsp, 0xF0
00007767631db121  pop r11
00007767631db123  pop r10
00007767631db125  pop r9
00007767631db127  pop r8
00007767631db129  pop rsi
00007767631db12a  pop rdi
00007767631db12b  pop rdx
00007767631db12c  pop rcx
00007767631db12d  pop rax
00007767631db12e  add rsp, 0x08
00007767631db132  jmp 0x00007767631D65D4
00007767631db137  sub rsp, 0x08
00007767631db13b  push rax
00007767631db13c  push rcx
00007767631db13d  push rdx
00007767631db13e  push rdi
00007767631db13f  push rsi
00007767631db140  push r8
00007767631db142  push r9
00007767631db144  push r10
00007767631db146  push r11
00007767631db148  sub rsp, 0xF0
00007767631db14f  vmovaps [rsp], xmm0
00007767631db154  vmovaps [rsp+0x10], xmm1
00007767631db15a  vmovaps [rsp+0x20], xmm2
00007767631db160  vmovaps [rsp+0x30], xmm3
00007767631db166  vmovaps [rsp+0x40], xmm4
00007767631db16c  vmovaps [rsp+0x50], xmm5
00007767631db172  vmovaps [rsp+0x60], xmm6
00007767631db178  vmovaps [rsp+0x70], xmm8
00007767631db17e  vmovaps [rsp+0x80], xmm9
00007767631db187  vmovaps [rsp+0x90], xmm10
00007767631db190  vmovaps [rsp+0xA0], xmm11
00007767631db199  vmovaps [rsp+0xB0], xmm12
00007767631db1a2  vmovaps [rsp+0xC0], xmm13
00007767631db1ab  vmovaps [rsp+0xD0], xmm14
00007767631db1b4  vmovaps [rsp+0xE0], xmm15
00007767631db1bd  sub rsp, 0x30
00007767631db1c1  movaps [rsp], xmm7
00007767631db1c5  movaps [rsp+0x10], xmm9
00007767631db1cb  movaps [rsp+0x20], xmm15
00007767631db1d1  lea rdi, [rsp]
00007767631db1d5  mov esi, 0x00
00007767631db1da  mov rax, 0x617961CDB530
00007767631db1e4  call rax
00007767631db1e6  movaps xmm7, [rsp]
00007767631db1ea  add rsp, 0x30
00007767631db1ee  vmovaps xmm0, [rsp]
00007767631db1f3  vmovaps xmm1, [rsp+0x10]
00007767631db1f9  vmovaps xmm2, [rsp+0x20]
00007767631db1ff  vmovaps xmm3, [rsp+0x30]
00007767631db205  vmovaps xmm4, [rsp+0x40]
00007767631db20b  vmovaps xmm5, [rsp+0x50]
00007767631db211  vmovaps xmm6, [rsp+0x60]
00007767631db217  vmovaps xmm8, [rsp+0x70]
00007767631db21d  vmovaps xmm9, [rsp+0x80]
00007767631db226  vmovaps xmm10, [rsp+0x90]
00007767631db22f  vmovaps xmm11, [rsp+0xA0]
00007767631db238  vmovaps xmm12, [rsp+0xB0]
00007767631db241  vmovaps xmm13, [rsp+0xC0]
00007767631db24a  vmovaps xmm14, [rsp+0xD0]
00007767631db253  vmovaps xmm15, [rsp+0xE0]
00007767631db25c  add rsp, 0xF0
00007767631db263  pop r11
00007767631db265  pop r10
00007767631db267  pop r9
00007767631db269  pop r8
00007767631db26b  pop rsi
00007767631db26c  pop rdi
00007767631db26d  pop rdx
00007767631db26e  pop rcx
00007767631db26f  pop rax
00007767631db270  add rsp, 0x08
00007767631db274  jmp 0x00007767631D6601
00007767631db279  sub rsp, 0x08
00007767631db27d  push rax
00007767631db27e  push rcx
00007767631db27f  push rdx
00007767631db280  push rdi
00007767631db281  push rsi
00007767631db282  push r8
00007767631db284  push r9
00007767631db286  push r10
00007767631db288  push r11
00007767631db28a  sub rsp, 0xF0
00007767631db291  vmovaps [rsp], xmm0
00007767631db296  vmovaps [rsp+0x10], xmm1
00007767631db29c  vmovaps [rsp+0x20], xmm2
00007767631db2a2  vmovaps [rsp+0x30], xmm3
00007767631db2a8  vmovaps [rsp+0x40], xmm4
00007767631db2ae  vmovaps [rsp+0x50], xmm5
00007767631db2b4  vmovaps [rsp+0x60], xmm6
00007767631db2ba  vmovaps [rsp+0x70], xmm7
00007767631db2c0  vmovaps [rsp+0x80], xmm8
00007767631db2c9  vmovaps [rsp+0x90], xmm10
00007767631db2d2  vmovaps [rsp+0xA0], xmm11
00007767631db2db  vmovaps [rsp+0xB0], xmm12
00007767631db2e4  vmovaps [rsp+0xC0], xmm13
00007767631db2ed  vmovaps [rsp+0xD0], xmm14
00007767631db2f6  vmovaps [rsp+0xE0], xmm15
00007767631db2ff  sub rsp, 0x30
00007767631db303  movaps [rsp], xmm9
00007767631db308  movaps [rsp+0x10], xmm13
00007767631db30e  movaps [rsp+0x20], xmm15
00007767631db314  lea rdi, [rsp]
00007767631db318  mov esi, 0x00
00007767631db31d  mov rax, 0x617961CDB530
00007767631db327  call rax
00007767631db329  movaps xmm9, [rsp]
00007767631db32e  add rsp, 0x30
00007767631db332  vmovaps xmm0, [rsp]
00007767631db337  vmovaps xmm1, [rsp+0x10]
00007767631db33d  vmovaps xmm2, [rsp+0x20]
00007767631db343  vmovaps xmm3, [rsp+0x30]
00007767631db349  vmovaps xmm4, [rsp+0x40]
00007767631db34f  vmovaps xmm5, [rsp+0x50]
00007767631db355  vmovaps xmm6, [rsp+0x60]
00007767631db35b  vmovaps xmm7, [rsp+0x70]
00007767631db361  vmovaps xmm8, [rsp+0x80]
00007767631db36a  vmovaps xmm10, [rsp+0x90]
00007767631db373  vmovaps xmm11, [rsp+0xA0]
00007767631db37c  vmovaps xmm12, [rsp+0xB0]
00007767631db385  vmovaps xmm13, [rsp+0xC0]
00007767631db38e  vmovaps xmm14, [rsp+0xD0]
00007767631db397  vmovaps xmm15, [rsp+0xE0]
00007767631db3a0  add rsp, 0xF0
00007767631db3a7  pop r11
00007767631db3a9  pop r10
00007767631db3ab  pop r9
00007767631db3ad  pop r8
00007767631db3af  pop rsi
00007767631db3b0  pop rdi
00007767631db3b1  pop rdx
00007767631db3b2  pop rcx
00007767631db3b3  pop rax
00007767631db3b4  add rsp, 0x08
00007767631db3b8  jmp 0x00007767631D662F
00007767631db3bd  sub rsp, 0x08
00007767631db3c1  push rax
00007767631db3c2  push rcx
00007767631db3c3  push rdx
00007767631db3c4  push rdi
00007767631db3c5  push rsi
00007767631db3c6  push r8
00007767631db3c8  push r9
00007767631db3ca  push r10
00007767631db3cc  push r11
00007767631db3ce  sub rsp, 0xF0
00007767631db3d5  vmovaps [rsp], xmm0
00007767631db3da  vmovaps [rsp+0x10], xmm1
00007767631db3e0  vmovaps [rsp+0x20], xmm2
00007767631db3e6  vmovaps [rsp+0x30], xmm3
00007767631db3ec  vmovaps [rsp+0x40], xmm4
00007767631db3f2  vmovaps [rsp+0x50], xmm5
00007767631db3f8  vmovaps [rsp+0x60], xmm6
00007767631db3fe  vmovaps [rsp+0x70], xmm7
00007767631db404  vmovaps [rsp+0x80], xmm8
00007767631db40d  vmovaps [rsp+0x90], xmm9
00007767631db416  vmovaps [rsp+0xA0], xmm10
00007767631db41f  vmovaps [rsp+0xB0], xmm11
00007767631db428  vmovaps [rsp+0xC0], xmm12
00007767631db431  vmovaps [rsp+0xD0], xmm13
00007767631db43a  vmovaps [rsp+0xE0], xmm14
00007767631db443  sub rsp, 0x30
00007767631db447  movaps [rsp], xmm15
00007767631db44c  movaps [rsp+0x10], xmm11
00007767631db452  movaps [rsp+0x20], xmm12
00007767631db458  lea rdi, [rsp]
00007767631db45c  mov esi, 0x00
00007767631db461  mov rax, 0x617961CDB530
00007767631db46b  call rax
00007767631db46d  movaps xmm15, [rsp]
00007767631db472  add rsp, 0x30
00007767631db476  vmovaps xmm0, [rsp]
00007767631db47b  vmovaps xmm1, [rsp+0x10]
00007767631db481  vmovaps xmm2, [rsp+0x20]
00007767631db487  vmovaps xmm3, [rsp+0x30]
00007767631db48d  vmovaps xmm4, [rsp+0x40]
00007767631db493  vmovaps xmm5, [rsp+0x50]
00007767631db499  vmovaps xmm6, [rsp+0x60]
00007767631db49f  vmovaps xmm7, [rsp+0x70]
00007767631db4a5  vmovaps xmm8, [rsp+0x80]
00007767631db4ae  vmovaps xmm9, [rsp+0x90]
00007767631db4b7  vmovaps xmm10, [rsp+0xA0]
00007767631db4c0  vmovaps xmm11, [rsp+0xB0]
00007767631db4c9  vmovaps xmm12, [rsp+0xC0]
00007767631db4d2  vmovaps xmm13, [rsp+0xD0]
00007767631db4db  vmovaps xmm14, [rsp+0xE0]
00007767631db4e4  add rsp, 0xF0
00007767631db4eb  pop r11
00007767631db4ed  pop r10
00007767631db4ef  pop r9
00007767631db4f1  pop r8
00007767631db4f3  pop rsi
00007767631db4f4  pop rdi
00007767631db4f5  pop rdx
00007767631db4f6  pop rcx
00007767631db4f7  pop rax
00007767631db4f8  add rsp, 0x08
00007767631db4fc  jmp 0x00007767631D664A
00007767631db501  sub rsp, 0x08
00007767631db505  push rax
00007767631db506  push rcx
00007767631db507  push rdx
00007767631db508  push rdi
00007767631db509  push rsi
00007767631db50a  push r8
00007767631db50c  push r9
00007767631db50e  push r10
00007767631db510  push r11
00007767631db512  sub rsp, 0xF0
00007767631db519  vmovaps [rsp], xmm0
00007767631db51e  vmovaps [rsp+0x10], xmm1
00007767631db524  vmovaps [rsp+0x20], xmm2
00007767631db52a  vmovaps [rsp+0x30], xmm3
00007767631db530  vmovaps [rsp+0x40], xmm4
00007767631db536  vmovaps [rsp+0x50], xmm5
00007767631db53c  vmovaps [rsp+0x60], xmm6
00007767631db542  vmovaps [rsp+0x70], xmm7
00007767631db548  vmovaps [rsp+0x80], xmm8
00007767631db551  vmovaps [rsp+0x90], xmm9
00007767631db55a  vmovaps [rsp+0xA0], xmm10
00007767631db563  vmovaps [rsp+0xB0], xmm11
00007767631db56c  vmovaps [rsp+0xC0], xmm12
00007767631db575  vmovaps [rsp+0xD0], xmm14
00007767631db57e  vmovaps [rsp+0xE0], xmm15
00007767631db587  sub rsp, 0x30
00007767631db58b  movaps [rsp], xmm13
00007767631db590  movaps [rsp+0x10], xmm10
00007767631db596  movaps [rsp+0x20], xmm14
00007767631db59c  lea rdi, [rsp]
00007767631db5a0  mov esi, 0x00
00007767631db5a5  mov rax, 0x617961CDB530
00007767631db5af  call rax
00007767631db5b1  movaps xmm13, [rsp]
00007767631db5b6  add rsp, 0x30
00007767631db5ba  vmovaps xmm0, [rsp]
00007767631db5bf  vmovaps xmm1, [rsp+0x10]
00007767631db5c5  vmovaps xmm2, [rsp+0x20]
00007767631db5cb  vmovaps xmm3, [rsp+0x30]
00007767631db5d1  vmovaps xmm4, [rsp+0x40]
00007767631db5d7  vmovaps xmm5, [rsp+0x50]
00007767631db5dd  vmovaps xmm6, [rsp+0x60]
00007767631db5e3  vmovaps xmm7, [rsp+0x70]
00007767631db5e9  vmovaps xmm8, [rsp+0x80]
00007767631db5f2  vmovaps xmm9, [rsp+0x90]
00007767631db5fb  vmovaps xmm10, [rsp+0xA0]
00007767631db604  vmovaps xmm11, [rsp+0xB0]
00007767631db60d  vmovaps xmm12, [rsp+0xC0]
00007767631db616  vmovaps xmm14, [rsp+0xD0]
00007767631db61f  vmovaps xmm15, [rsp+0xE0]
00007767631db628  add rsp, 0xF0
00007767631db62f  pop r11
00007767631db631  pop r10
00007767631db633  pop r9
00007767631db635  pop r8
00007767631db637  pop rsi
00007767631db638  pop rdi
00007767631db639  pop rdx
00007767631db63a  pop rcx
00007767631db63b  pop rax
00007767631db63c  add rsp, 0x08
00007767631db640  jmp 0x00007767631D666D
00007767631db645  sub rsp, 0x08
00007767631db649  push rax
00007767631db64a  push rcx
00007767631db64b  push rdx
00007767631db64c  push rdi
00007767631db64d  push rsi
00007767631db64e  push r8
00007767631db650  push r9
00007767631db652  push r10
00007767631db654  push r11
00007767631db656  sub rsp, 0xF0
00007767631db65d  vmovaps [rsp], xmm0
00007767631db662  vmovaps [rsp+0x10], xmm1
00007767631db668  vmovaps [rsp+0x20], xmm2
00007767631db66e  vmovaps [rsp+0x30], xmm3
00007767631db674  vmovaps [rsp+0x40], xmm4
00007767631db67a  vmovaps [rsp+0x50], xmm5
00007767631db680  vmovaps [rsp+0x60], xmm6
00007767631db686  vmovaps [rsp+0x70], xmm7
00007767631db68c  vmovaps [rsp+0x80], xmm8
00007767631db695  vmovaps [rsp+0x90], xmm9
00007767631db69e  vmovaps [rsp+0xA0], xmm10
00007767631db6a7  vmovaps [rsp+0xB0], xmm11
00007767631db6b0  vmovaps [rsp+0xC0], xmm12
00007767631db6b9  vmovaps [rsp+0xD0], xmm13
00007767631db6c2  vmovaps [rsp+0xE0], xmm15
00007767631db6cb  sub rsp, 0x30
00007767631db6cf  movaps [rsp], xmm14
00007767631db6d4  movaps [rsp+0x10], xmm1
00007767631db6d9  movaps [rsp+0x20], xmm7
00007767631db6de  lea rdi, [rsp]
00007767631db6e2  mov esi, 0x00
00007767631db6e7  mov rax, 0x617961CDB530
00007767631db6f1  call rax
00007767631db6f3  movaps xmm14, [rsp]
00007767631db6f8  add rsp, 0x30
00007767631db6fc  vmovaps xmm0, [rsp]
00007767631db701  vmovaps xmm1, [rsp+0x10]
00007767631db707  vmovaps xmm2, [rsp+0x20]
00007767631db70d  vmovaps xmm3, [rsp+0x30]
00007767631db713  vmovaps xmm4, [rsp+0x40]
00007767631db719  vmovaps xmm5, [rsp+0x50]
00007767631db71f  vmovaps xmm6, [rsp+0x60]
00007767631db725  vmovaps xmm7, [rsp+0x70]
00007767631db72b  vmovaps xmm8, [rsp+0x80]
00007767631db734  vmovaps xmm9, [rsp+0x90]
00007767631db73d  vmovaps xmm10, [rsp+0xA0]
00007767631db746  vmovaps xmm11, [rsp+0xB0]
00007767631db74f  vmovaps xmm12, [rsp+0xC0]
00007767631db758  vmovaps xmm13, [rsp+0xD0]
00007767631db761  vmovaps xmm15, [rsp+0xE0]
00007767631db76a  add rsp, 0xF0
00007767631db771  pop r11
00007767631db773  pop r10
00007767631db775  pop r9
00007767631db777  pop r8
00007767631db779  pop rsi
00007767631db77a  pop rdi
00007767631db77b  pop rdx
00007767631db77c  pop rcx
00007767631db77d  pop rax
00007767631db77e  add rsp, 0x08
00007767631db782  jmp 0x00007767631D6690
00007767631db787  sub rsp, 0x08
00007767631db78b  push rax
00007767631db78c  push rcx
00007767631db78d  push rdx
00007767631db78e  push rdi
00007767631db78f  push rsi
00007767631db790  push r8
00007767631db792  push r9
00007767631db794  push r10
00007767631db796  push r11
00007767631db798  sub rsp, 0xF0
00007767631db79f  vmovaps [rsp], xmm0
00007767631db7a4  vmovaps [rsp+0x10], xmm2
00007767631db7aa  vmovaps [rsp+0x20], xmm3
00007767631db7b0  vmovaps [rsp+0x30], xmm4
00007767631db7b6  vmovaps [rsp+0x40], xmm5
00007767631db7bc  vmovaps [rsp+0x50], xmm6
00007767631db7c2  vmovaps [rsp+0x60], xmm7
00007767631db7c8  vmovaps [rsp+0x70], xmm8
00007767631db7ce  vmovaps [rsp+0x80], xmm9
00007767631db7d7  vmovaps [rsp+0x90], xmm10
00007767631db7e0  vmovaps [rsp+0xA0], xmm11
00007767631db7e9  vmovaps [rsp+0xB0], xmm12
00007767631db7f2  vmovaps [rsp+0xC0], xmm13
00007767631db7fb  vmovaps [rsp+0xD0], xmm14
00007767631db804  vmovaps [rsp+0xE0], xmm15
00007767631db80d  sub rsp, 0x30
00007767631db811  movaps [rsp], xmm1
00007767631db815  movaps [rsp+0x10], xmm8
00007767631db81b  movaps [rsp+0x20], xmm9
00007767631db821  lea rdi, [rsp]
00007767631db825  mov esi, 0x00
00007767631db82a  mov rax, 0x617961CDB530
00007767631db834  call rax
00007767631db836  movaps xmm1, [rsp]
00007767631db83a  add rsp, 0x30
00007767631db83e  vmovaps xmm0, [rsp]
00007767631db843  vmovaps xmm2, [rsp+0x10]
00007767631db849  vmovaps xmm3, [rsp+0x20]
00007767631db84f  vmovaps xmm4, [rsp+0x30]
00007767631db855  vmovaps xmm5, [rsp+0x40]
00007767631db85b  vmovaps xmm6, [rsp+0x50]
00007767631db861  vmovaps xmm7, [rsp+0x60]
00007767631db867  vmovaps xmm8, [rsp+0x70]
00007767631db86d  vmovaps xmm9, [rsp+0x80]
00007767631db876  vmovaps xmm10, [rsp+0x90]
00007767631db87f  vmovaps xmm11, [rsp+0xA0]
00007767631db888  vmovaps xmm12, [rsp+0xB0]
00007767631db891  vmovaps xmm13, [rsp+0xC0]
00007767631db89a  vmovaps xmm14, [rsp+0xD0]
00007767631db8a3  vmovaps xmm15, [rsp+0xE0]
00007767631db8ac  add rsp, 0xF0
00007767631db8b3  pop r11
00007767631db8b5  pop r10
00007767631db8b7  pop r9
00007767631db8b9  pop r8
00007767631db8bb  pop rsi
00007767631db8bc  pop rdi
00007767631db8bd  pop rdx
00007767631db8be  pop rcx
00007767631db8bf  pop rax
00007767631db8c0  add rsp, 0x08
00007767631db8c4  jmp 0x00007767631D66B2
00007767631db8c9  call 0x00007767630B3E40
00007767631db8ce  jmp 0x00007767631D66C0
00007767631db8d3  call 0x000077676300C380
00007767631db8d8  jmp 0x00007767631D66CA
00007767631db8dd  call 0x000077676300D600
00007767631db8e2  jmp 0x00007767631D66D4
00007767631db8e7  call 0x0000776762FFF540
00007767631db8ec  jmp 0x00007767631D66DE
00007767631db8f1  int3
00007767631db8f2  nop [rax+rax*1], ax
00007767631db8fb  nop [rax+rax*1], eax
00007767631db900  mov eax, [r15+0x48]
00007767631db904  lea r14d, [eax+0x01]
00007767631db909  mov [rsp+0x10], r14d
00007767631db90e  mov r14d, r14d
00007767631db911  mov [r15+0x48], r14
00007767631db915  xor eax, eax
00007767631db917  mov r14d, [rsp+0x10]
00007767631db91c  cmp r14d, 0x1F4
00007767631db923  cmc
00007767631db924  lahf
00007767631db925  seto al
00007767631db928  mov [r15+0x108], eax
00007767631db92f  mov eax, [r15+0x108]
00007767631db936  sahf
00007767631db937  jnz 0x00007767631DB969
00007767631db939  cmp dword ptr [r15+0x318], 0x00
00007767631db941  jz 0x00007767631E1AB0
00007767631db947  nop [rax+rax*1], ax
00007767631db950  nop [rax+rax*1], eax
00007767631db958  mov eax, 0x410450
00007767631db95d  mov [r15+0x100], rax
00007767631db964  jmp 0x0000776762FFE110
00007767631db969  cmp dword ptr [r15+0x318], 0x00
00007767631db971  jz 0x00007767631DB9A0
00007767631db977  nop [rax+rax*1], ax
00007767631db980  nop [rax+rax*1], eax
00007767631db988  mov eax, 0x410274
00007767631db98d  mov [r15+0x100], rax
00007767631db994  jmp 0x0000776762FFE110
00007767631db999  int3
00007767631db99a  int3
00007767631db99b  nop [rax+rax*1], eax
00007767631db9a0  mov rax, [r15+0x40]
00007767631db9a4  movaps xmm1, [r15+0x1D0]
00007767631db9ac  vmovaps [rsp+0x10], xmm1
00007767631db9b2  vmovaps xmm15, [rsp+0x10]
00007767631db9b8  por xmm1, xmm15
00007767631db9bd  movaps xmm14, [r15+0x1A0]
00007767631db9c5  vmovaps [rsp+0x10], xmm14
00007767631db9cb  vmovaps xmm13, [rsp+0x10]
00007767631db9d1  por xmm14, xmm13
00007767631db9d6  lea r14, [rax+0x30]
00007767631db9da  mov r12, [r13+r14*1]
00007767631db9df  lea r14, [rax+0x38]
00007767631db9e3  mov r11, [r13+r14*1]
00007767631db9e8  movq xmm13, r12
00007767631db9ed  movq xmm12, r11
00007767631db9f2  movq xmm13, xmm13
00007767631db9f7  vmovaps [rsp+0x10], xmm13
00007767631db9fd  movq xmm13, xmm13
00007767631dba02  movaps [r15+0x130], xmm13
00007767631dba0a  movq xmm12, xmm12
00007767631dba0f  vmovaps [rsp+0x20], xmm12
00007767631dba15  movq xmm12, xmm12
00007767631dba1a  movaps [r15+0x280], xmm12
00007767631dba22  movaps xmm13, [r15+0x270]
00007767631dba2a  vmovaps [rsp+0x30], xmm13
00007767631dba30  vmovaps xmm12, [rsp+0x30]
00007767631dba36  por xmm13, xmm12
00007767631dba3b  lea r14, [rax+0x20]
00007767631dba3f  mov r12, [r13+r14*1]
00007767631dba44  lea r14, [rax+0x28]
00007767631dba48  mov r11, [r13+r14*1]
00007767631dba4d  movq xmm12, r12
00007767631dba52  movq xmm11, r11
00007767631dba57  movq xmm12, xmm12
00007767631dba5c  vmovaps [rsp+0x30], xmm12
00007767631dba62  movq xmm12, xmm12
00007767631dba67  movaps [r15+0x150], xmm12
00007767631dba6f  movq xmm11, xmm11
00007767631dba74  vmovaps [rsp+0x40], xmm11
00007767631dba7a  movq xmm11, xmm11
00007767631dba7f  movaps [r15+0x140], xmm11
00007767631dba87  lea r14, [rax+0x10]
00007767631dba8b  mov r12, [r13+r14*1]
00007767631dba90  lea r14, [rax+0x18]
00007767631dba94  mov r11, [r13+r14*1]
00007767631dba99  movq xmm12, r12
00007767631dba9e  movq xmm11, r11
00007767631dbaa3  movq xmm12, xmm12
00007767631dbaa8  vmovaps [rsp+0x50], xmm12
00007767631dbaae  movq xmm12, xmm12
00007767631dbab3  movaps [r15+0x170], xmm12
00007767631dbabb  movq xmm11, xmm11
00007767631dbac0  vmovaps [rsp+0x60], xmm11
00007767631dbac6  movq xmm11, xmm11
00007767631dbacb  movaps [r15+0x160], xmm11
00007767631dbad3  mov r14, [r13+rax*1]
00007767631dbad8  vmovq xmm12, r14
00007767631dbadd  vpbroadcastq xmm12, xmm12
00007767631dbae2  lea r14, [rax+0x08]
00007767631dbae6  mov rax, [r13+r14*1]
00007767631dbaeb  movq xmm11, rax
00007767631dbaf0  movaps [r15+0x230], xmm11
00007767631dbaf8  mov rax, [r15+0xF8]
00007767631dbaff  lea r14, [rax+0x50]
00007767631dbb03  movups xmm11, [r13+r14*1]
00007767631dbb09  lea r14, [rax+0x60]
00007767631dbb0d  movups xmm10, [r13+r14*1]
00007767631dbb13  lea r14, [rax+0x30]
00007767631dbb17  movups xmm9, [r13+r14*1]
00007767631dbb1d  mov r14, [r15+0x50]
00007767631dbb21  mov [r15+0x60], r14
00007767631dbb25  mov qword ptr [r15+0x58], 0x40
00007767631dbb2d  movaps xmm8, xmm12
00007767631dbb31  mulpd xmm8, xmm15
00007767631dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007767631dbb3c  ptest xmm7, xmm7
00007767631dbb41  jnz 0x00007767631DC96A
00007767631dbb47  movq xmm15, qword ptr [r15+0x230]
00007767631dbb50  vmovaps [rsp+0x70], xmm15
00007767631dbb56  vpermilpd xmm15, xmm15, 0x00
00007767631dbb5c  movaps xmm7, xmm9
00007767631dbb60  mulpd xmm7, xmm15
00007767631dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007767631dbb6a  ptest xmm6, xmm6
00007767631dbb6f  jnz 0x00007767631DCAAE
00007767631dbb75  vxorps xmm15, xmm15, xmm15
00007767631dbb7a  vpbroadcastq xmm15, xmm15
00007767631dbb7f  movaps xmm9, xmm12
00007767631dbb83  mulpd xmm9, xmm10
00007767631dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007767631dbb8e  ptest xmm6, xmm6
00007767631dbb93  jnz 0x00007767631DCBF0
00007767631dbb99  movaps xmm10, xmm12
00007767631dbb9d  mulpd xmm10, xmm11
00007767631dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007767631dbba8  ptest xmm6, xmm6
00007767631dbbad  jnz 0x00007767631DCD34
00007767631dbbb3  movaps xmm11, [r15+0x1F0]
00007767631dbbbb  movaps xmm6, xmm12
00007767631dbbbf  mulpd xmm6, xmm11
00007767631dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007767631dbbc9  ptest xmm5, xmm5
00007767631dbbce  jnz 0x00007767631DCE78
00007767631dbbd4  movaps xmm12, [r15+0x2A0]
00007767631dbbdc  vmovaps [rsp+0x80], xmm12
00007767631dbbe5  vmovaps xmm11, [rsp+0x80]
00007767631dbbee  por xmm12, xmm11
00007767631dbbf3  movaps xmm11, [r15+0x250]
00007767631dbbfb  vmovaps [rsp+0x80], xmm11
00007767631dbc04  vmovaps xmm5, [rsp+0x80]
00007767631dbc0d  por xmm11, xmm5
00007767631dbc12  vmovaps xmm4, [rsp+0x70]
00007767631dbc18  vpermilpd xmm4, xmm4, 0x00
00007767631dbc1e  movaps xmm3, xmm5
00007767631dbc21  mulpd xmm3, xmm4
00007767631dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007767631dbc2a  ptest xmm2, xmm2
00007767631dbc2f  jnz 0x00007767631DCFBA
00007767631dbc35  mov [rsp+0x80], rax
00007767631dbc3d  xor eax, eax
00007767631dbc3f  mov r12d, 0x40
00007767631dbc45  mov r11d, 0x200
00007767631dbc4b  cmp r12, r11
00007767631dbc4e  cmc
00007767631dbc4f  lahf
00007767631dbc50  seto al
00007767631dbc53  mov [r15+0x108], eax
00007767631dbc5a  movaps xmm5, xmm8
00007767631dbc5e  addpd xmm5, xmm15
00007767631dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007767631dbc68  ptest xmm4, xmm4
00007767631dbc6d  jnz 0x00007767631DD0FA
00007767631dbc73  movaps xmm8, [r15+0x1B0]
00007767631dbc7b  movaps xmm4, xmm9
00007767631dbc7f  addpd xmm4, xmm8
00007767631dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007767631dbc89  ptest xmm2, xmm2
00007767631dbc8e  jnz 0x00007767631DD23C
00007767631dbc94  movaps xmm9, xmm10
00007767631dbc98  addpd xmm9, xmm8
00007767631dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007767631dbca3  ptest xmm2, xmm2
00007767631dbca8  jnz 0x00007767631DD37E
00007767631dbcae  movaps xmm10, [r15+0x2F0]
00007767631dbcb6  vmovaps [rsp+0x90], xmm10
00007767631dbcbf  vmovaps xmm8, [rsp+0x90]
00007767631dbcc8  por xmm10, xmm8
00007767631dbccd  movaps xmm8, [r15+0x2E0]
00007767631dbcd5  vmovaps [rsp+0x90], xmm8
00007767631dbcde  vmovaps xmm2, [rsp+0x90]
00007767631dbce7  por xmm8, xmm2
00007767631dbcec  movaps xmm2, [r15+0x2D0]
00007767631dbcf4  vmovaps [rsp+0x90], xmm2
00007767631dbcfd  vmovaps [rsp+0xA0], xmm1
00007767631dbd06  vmovaps xmm1, [rsp+0x90]
00007767631dbd0f  por xmm2, xmm1
00007767631dbd13  movaps xmm1, [r15+0x200]
00007767631dbd1b  vmovaps [rsp+0x90], xmm1
00007767631dbd24  vmovaps [rsp+0xB0], xmm15
00007767631dbd2d  vmovaps xmm15, [rsp+0x90]
00007767631dbd36  por xmm1, xmm15
00007767631dbd3b  movaps xmm15, [r15+0x1C0]
00007767631dbd43  vmovaps [rsp+0x90], xmm15
00007767631dbd4c  vmovaps [rsp+0xC0], xmm1
00007767631dbd55  vmovaps xmm1, [rsp+0x90]
00007767631dbd5e  por xmm15, xmm1
00007767631dbd63  movaps xmm1, [r15+0x190]
00007767631dbd6b  vmovaps [rsp+0x90], xmm1
00007767631dbd74  vmovaps [rsp+0xD0], xmm15
00007767631dbd7d  vmovaps xmm15, [rsp+0x90]
00007767631dbd86  por xmm1, xmm15
00007767631dbd8b  movaps xmm15, [r15+0x300]
00007767631dbd93  vmovaps [rsp+0x90], xmm15
00007767631dbd9c  vmovaps [rsp+0xE0], xmm1
00007767631dbda5  vmovaps xmm1, [rsp+0x90]
00007767631dbdae  por xmm15, xmm1
00007767631dbdb3  mov rax, [rsp+0x80]
00007767631dbdbb  lea r12, [rax+0xA0]
00007767631dbdc2  movups xmm1, [r13+r12*1]
00007767631dbdc8  lea r12, [rax+0xB0]
00007767631dbdcf  vmovaps [rsp+0x80], xmm1
00007767631dbdd8  movups xmm1, [r13+r12*1]
00007767631dbdde  vmovaps [rsp+0x90], xmm1
00007767631dbde7  vmovaps [rsp+0xF0], xmm15
00007767631dbdf0  vmovaps xmm15, [rsp+0xB0]
00007767631dbdf9  vmovaps [rsp+0xB0], xmm14
00007767631dbe02  movaps xmm1, xmm6
00007767631dbe05  addpd xmm1, xmm15
00007767631dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007767631dbe0f  ptest xmm14, xmm14
00007767631dbe15  jnz 0x00007767631DD4D6
00007767631dbe1b  lea r12, [rax+0xF0]
00007767631dbe22  movups xmm15, [r13+r12*1]
00007767631dbe28  movaps xmm14, xmm4
00007767631dbe2c  addpd xmm14, xmm3
00007767631dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007767631dbe37  ptest xmm6, xmm6
00007767631dbe3c  jnz 0x00007767631DD621
00007767631dbe42  movaps xmm6, xmm9
00007767631dbe46  addpd xmm6, xmm7
00007767631dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007767631dbe4f  ptest xmm4, xmm4
00007767631dbe54  jnz 0x00007767631DD763
00007767631dbe5a  vmovaps xmm9, [rsp+0x70]
00007767631dbe60  vpermilpd xmm9, xmm9, 0x00
00007767631dbe66  vmovaps xmm4, [rsp+0x90]
00007767631dbe6f  movaps xmm7, xmm4
00007767631dbe72  mulpd xmm7, xmm9
00007767631dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007767631dbe7c  ptest xmm3, xmm3
00007767631dbe81  jnz 0x00007767631DD8A4
00007767631dbe87  vmovaps xmm9, [rsp+0x50]
00007767631dbe8d  vpermilpd xmm9, xmm9, 0x00
00007767631dbe93  movaps xmm4, xmm15
00007767631dbe97  mulpd xmm4, xmm9
00007767631dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007767631dbea1  ptest xmm3, xmm3
00007767631dbea6  jnz 0x00007767631DD9E5
00007767631dbeac  lea r12, [rax+0xE0]
00007767631dbeb3  movups xmm15, [r13+r12*1]
00007767631dbeb9  vmovaps xmm9, [rsp+0x70]
00007767631dbebf  vpermilpd xmm9, xmm9, 0x00
00007767631dbec5  vmovaps [rsp+0x70], xmm1
00007767631dbecb  vmovaps xmm1, [rsp+0x80]
00007767631dbed4  vmovaps [rsp+0x80], xmm15
00007767631dbedd  movaps xmm3, xmm1
00007767631dbee0  mulpd xmm3, xmm9
00007767631dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007767631dbeea  ptest xmm15, xmm15
00007767631dbef0  jnz 0x00007767631DDB31
00007767631dbef6  vmovaps xmm1, [rsp+0xF0]
00007767631dbeff  vmovaps xmm15, [rsp+0xF0]
00007767631dbf08  por xmm1, xmm15
00007767631dbf0d  movaps [r15+0x300], xmm1
00007767631dbf15  vmovaps xmm15, [rsp+0xE0]
00007767631dbf1e  vmovaps xmm9, [rsp+0xE0]
00007767631dbf27  por xmm15, xmm9
00007767631dbf2c  movaps [r15+0x190], xmm15
00007767631dbf34  vmovaps xmm9, [rsp+0x50]
00007767631dbf3a  vpermilpd xmm9, xmm9, 0x00
00007767631dbf40  vmovaps [rsp+0x90], xmm1
00007767631dbf49  vmovaps [rsp+0xE0], xmm15
00007767631dbf52  vmovaps xmm15, [rsp+0x80]
00007767631dbf5b  vmovaps [rsp+0x80], xmm14
00007767631dbf64  movaps xmm1, xmm15
00007767631dbf68  mulpd xmm1, xmm9
00007767631dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007767631dbf72  ptest xmm14, xmm14
00007767631dbf78  jnz 0x00007767631DDC72
00007767631dbf7e  lea r12, [rax+0x90]
00007767631dbf85  movups xmm15, [r13+r12*1]
00007767631dbf8b  vmovaps xmm14, [rsp+0xD0]
00007767631dbf94  vmovaps xmm9, [rsp+0xD0]
00007767631dbf9d  por xmm14, xmm9
00007767631dbfa2  movaps [r15+0x1C0], xmm14
00007767631dbfaa  vmovaps xmm9, [rsp+0xC0]
00007767631dbfb3  vmovaps [rsp+0xD0], xmm1
00007767631dbfbc  vmovaps xmm1, [rsp+0xC0]
00007767631dbfc5  por xmm9, xmm1
00007767631dbfca  movaps [r15+0x200], xmm9
00007767631dbfd2  vmovaps [rsp+0xC0], xmm2
00007767631dbfdb  vmovaps xmm1, [rsp+0xC0]
00007767631dbfe4  por xmm2, xmm1
00007767631dbfe8  movaps [r15+0x2D0], xmm2
00007767631dbff0  vmovaps [rsp+0xC0], xmm8
00007767631dbff9  vmovaps xmm1, [rsp+0xC0]
00007767631dc002  por xmm8, xmm1
00007767631dc007  movaps [r15+0x2E0], xmm8
00007767631dc00f  vmovaps [rsp+0xC0], xmm15
00007767631dc018  movaps xmm1, xmm5
00007767631dc01b  addpd xmm1, xmm7
00007767631dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007767631dc024  ptest xmm15, xmm15
00007767631dc02a  jnz 0x00007767631DDDBE
00007767631dc030  vmovaps xmm15, [rsp+0x50]
00007767631dc036  vpermilpd xmm15, xmm15, 0x00
00007767631dc03c  vmovaps xmm5, [rsp+0xC0]
00007767631dc045  vmovaps [rsp+0xC0], xmm1
00007767631dc04e  movaps xmm7, xmm5
00007767631dc051  mulpd xmm7, xmm15
00007767631dc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007767631dc05b  ptest xmm1, xmm1
00007767631dc060  jnz 0x00007767631DDEFE
00007767631dc066  lea r12, [rax+0x80]
00007767631dc06d  movups xmm1, [r13+r12*1]
00007767631dc073  vmovaps xmm5, [rsp+0x70]
00007767631dc079  vmovaps [rsp+0x70], xmm1
00007767631dc07f  movaps xmm15, xmm5
00007767631dc083  addpd xmm15, xmm3
00007767631dc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007767631dc08e  ptest xmm1, xmm1
00007767631dc093  jnz 0x00007767631DE049
00007767631dc099  vmovaps xmm5, [rsp+0x80]
00007767631dc0a2  movaps xmm1, xmm5
00007767631dc0a5  addpd xmm1, xmm4
00007767631dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007767631dc0ae  ptest xmm3, xmm3
00007767631dc0b3  jnz 0x00007767631DE18B
00007767631dc0b9  vmovaps [rsp+0x80], xmm10
00007767631dc0c2  vmovaps xmm5, [rsp+0x80]
00007767631dc0cb  por xmm10, xmm5
00007767631dc0d0  movaps [r15+0x2F0], xmm10
00007767631dc0d8  vmovaps xmm5, [rsp+0x50]
00007767631dc0de  vpermilpd xmm5, xmm5, 0x00
00007767631dc0e4  vmovaps xmm3, [rsp+0x70]
00007767631dc0ea  vmovaps [rsp+0x50], xmm1
00007767631dc0f0  movaps xmm4, xmm3
00007767631dc0f3  mulpd xmm4, xmm5
00007767631dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007767631dc0fc  ptest xmm1, xmm1
00007767631dc101  jnz 0x00007767631DE2CB
00007767631dc107  lea r12, [rax+0xD0]
00007767631dc10e  movups xmm1, [r13+r12*1]
00007767631dc114  vmovaps xmm3, [rsp+0xD0]
00007767631dc11d  vmovaps [rsp+0x70], xmm1
00007767631dc123  movaps xmm5, xmm6
00007767631dc126  addpd xmm5, xmm3
00007767631dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007767631dc12f  ptest xmm1, xmm1
00007767631dc134  jnz 0x00007767631DE415
00007767631dc13a  vmovaps xmm1, [rsp+0x60]
00007767631dc140  vpermilpd xmm1, xmm1, 0x00
00007767631dc146  movaps xmm6, xmm9
00007767631dc14a  mulpd xmm6, xmm1
00007767631dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007767631dc153  ptest xmm3, xmm3
00007767631dc158  jnz 0x00007767631DE555
00007767631dc15e  movaps [r15+0x260], xmm6
00007767631dc166  vxorps xmm1, xmm1, xmm1
00007767631dc16a  vpbroadcastq xmm1, xmm1
00007767631dc16f  movaps [r15+0x1B0], xmm1
00007767631dc177  vmovaps xmm1, [rsp+0x60]
00007767631dc17d  vpermilpd xmm1, xmm1, 0x00
00007767631dc183  vmovaps xmm3, [rsp+0x70]
00007767631dc189  vmovaps [rsp+0x70], xmm15
00007767631dc18f  movaps xmm9, xmm3
00007767631dc193  mulpd xmm9, xmm1
00007767631dc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007767631dc19e  ptest xmm15, xmm15
00007767631dc1a4  jnz 0x00007767631DE696
00007767631dc1aa  lea r12, [rax+0xC0]
00007767631dc1b1  movups xmm1, [r13+r12*1]
00007767631dc1b7  vmovaps xmm3, [rsp+0xC0]
00007767631dc1c0  vmovaps [rsp+0x80], xmm1
00007767631dc1c9  movaps xmm15, xmm3
00007767631dc1cd  addpd xmm15, xmm7
00007767631dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007767631dc1d8  ptest xmm1, xmm1
00007767631dc1dd  jnz 0x00007767631DE7E2
00007767631dc1e3  vmovaps [rsp+0xC0], xmm13
00007767631dc1ec  vmovaps xmm1, [rsp+0xC0]
00007767631dc1f5  por xmm13, xmm1
00007767631dc1fa  movaps [r15+0x270], xmm13
00007767631dc202  vmovaps xmm1, [rsp+0xB0]
00007767631dc20b  vmovaps xmm7, [rsp+0xB0]
00007767631dc214  por xmm1, xmm7
00007767631dc218  movaps [r15+0x1A0], xmm1
00007767631dc220  vmovaps xmm1, [rsp+0x60]
00007767631dc226  vpermilpd xmm1, xmm1, 0x00
00007767631dc22c  vmovaps [rsp+0xB0], xmm1
00007767631dc235  vmovaps xmm1, [rsp+0x80]
00007767631dc23e  vmovaps [rsp+0x80], xmm15
00007767631dc247  vmovaps xmm15, [rsp+0xB0]
00007767631dc250  vmovaps [rsp+0xB0], xmm14
00007767631dc259  movaps xmm3, xmm1
00007767631dc25c  mulpd xmm3, xmm15
00007767631dc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007767631dc266  ptest xmm14, xmm14
00007767631dc26c  jnz 0x00007767631DE924
00007767631dc272  lea r12, [rax+0x20]
00007767631dc276  movups xmm1, [r13+r12*1]
00007767631dc27c  movaps [r15+0x110], xmm1
00007767631dc284  vmovaps xmm14, [rsp+0x70]
00007767631dc28a  vmovaps [rsp+0x70], xmm1
00007767631dc290  movaps xmm15, xmm14
00007767631dc294  addpd xmm15, xmm4
00007767631dc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007767631dc29f  ptest xmm1, xmm1
00007767631dc2a4  jnz 0x00007767631DEA6F
00007767631dc2aa  vmovaps xmm1, [rsp+0x60]
00007767631dc2b0  vpermilpd xmm1, xmm1, 0x00
00007767631dc2b6  movaps xmm14, xmm2
00007767631dc2ba  mulpd xmm14, xmm1
00007767631dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007767631dc2c5  ptest xmm4, xmm4
00007767631dc2ca  jnz 0x00007767631DEBB2
00007767631dc2d0  vmovaps xmm4, [rsp+0x50]
00007767631dc2d6  movaps xmm1, xmm4
00007767631dc2d9  addpd xmm1, xmm9
00007767631dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007767631dc2e3  ptest xmm2, xmm2
00007767631dc2e8  jnz 0x00007767631DECF4
00007767631dc2ee  vmovaps xmm9, [rsp+0x30]
00007767631dc2f4  vpermilpd xmm9, xmm9, 0x00
00007767631dc2fa  vmovaps xmm2, [rsp+0x70]
00007767631dc300  vmovaps [rsp+0x50], xmm1
00007767631dc306  movaps xmm4, xmm2
00007767631dc309  mulpd xmm4, xmm9
00007767631dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007767631dc313  ptest xmm1, xmm1
00007767631dc318  jnz 0x00007767631DEE35
00007767631dc31e  vmovaps xmm1, [rsp+0x30]
00007767631dc324  vpermilpd xmm1, xmm1, 0x00
00007767631dc32a  vmovaps xmm2, [rsp+0x90]
00007767631dc333  vmovaps [rsp+0x60], xmm15
00007767631dc339  movaps xmm9, xmm2
00007767631dc33d  mulpd xmm9, xmm1
00007767631dc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007767631dc348  ptest xmm15, xmm15
00007767631dc34e  jnz 0x00007767631DEF76
00007767631dc354  vmovaps xmm15, [rsp+0x80]
00007767631dc35d  movaps xmm1, xmm15
00007767631dc361  addpd xmm1, xmm6
00007767631dc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007767631dc36a  ptest xmm2, xmm2
00007767631dc36f  jnz 0x00007767631DF0B8
00007767631dc375  movaps xmm15, xmm5
00007767631dc379  addpd xmm15, xmm3
00007767631dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007767631dc384  ptest xmm6, xmm6
00007767631dc389  jnz 0x00007767631DF1F9
00007767631dc38f  vmovaps xmm6, [rsp+0x30]
00007767631dc395  vpermilpd xmm6, xmm6, 0x00
00007767631dc39b  movaps xmm5, xmm8
00007767631dc39f  mulpd xmm5, xmm6
00007767631dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007767631dc3a8  ptest xmm3, xmm3
00007767631dc3ad  jnz 0x00007767631DF33B
00007767631dc3b3  vmovaps xmm8, [rsp+0x30]
00007767631dc3b9  vpermilpd xmm8, xmm8, 0x00
00007767631dc3bf  movaps xmm6, xmm10
00007767631dc3c3  mulpd xmm6, xmm8
00007767631dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007767631dc3cd  ptest xmm3, xmm3
00007767631dc3d2  jnz 0x00007767631DF47C
00007767631dc3d8  vmovaps xmm8, [rsp+0x60]
00007767631dc3de  movaps xmm10, xmm8
00007767631dc3e2  addpd xmm10, xmm14
00007767631dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007767631dc3ed  ptest xmm3, xmm3
00007767631dc3f2  jnz 0x00007767631DF5BE
00007767631dc3f8  vmovaps xmm8, [rsp+0x50]
00007767631dc3fe  movaps xmm14, xmm8
00007767631dc402  addpd xmm14, xmm4
00007767631dc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007767631dc40d  ptest xmm3, xmm3
00007767631dc412  jnz 0x00007767631DF702
00007767631dc418  vmovaps xmm8, [rsp+0x40]
00007767631dc41e  vpermilpd xmm8, xmm8, 0x00
00007767631dc424  movaps xmm4, xmm13
00007767631dc428  mulpd xmm4, xmm8
00007767631dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007767631dc432  ptest xmm3, xmm3
00007767631dc437  jnz 0x00007767631DF845
00007767631dc43d  movaps xmm13, xmm15
00007767631dc441  addpd xmm13, xmm9
00007767631dc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007767631dc44c  ptest xmm8, xmm8
00007767631dc452  jnz 0x00007767631DF987
00007767631dc458  movaps xmm15, xmm1
00007767631dc45c  addpd xmm15, xmm5
00007767631dc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007767631dc467  ptest xmm9, xmm9
00007767631dc46d  jnz 0x00007767631DFACB
00007767631dc473  vmovaps [rsp+0x30], xmm11
00007767631dc479  vmovaps xmm1, [rsp+0x30]
00007767631dc47f  por xmm11, xmm1
00007767631dc484  movaps [r15+0x250], xmm11
00007767631dc48c  vmovaps [rsp+0x30], xmm12
00007767631dc492  vmovaps xmm1, [rsp+0x30]
00007767631dc498  por xmm12, xmm1
00007767631dc49d  movaps [r15+0x2A0], xmm12
00007767631dc4a5  vmovaps xmm1, [rsp+0xA0]
00007767631dc4ae  vmovaps xmm11, [rsp+0xA0]
00007767631dc4b7  por xmm1, xmm11
00007767631dc4bc  movaps [r15+0x1D0], xmm1
00007767631dc4c4  lea r12, [rax+0x40]
00007767631dc4c8  movups xmm1, [r13+r12*1]
00007767631dc4ce  movaps [r15+0x2C0], xmm1
00007767631dc4d6  vmovaps xmm11, [rsp+0x40]
00007767631dc4dc  vpermilpd xmm11, xmm11, 0x00
00007767631dc4e2  vmovaps xmm8, [rsp+0xE0]
00007767631dc4eb  movaps xmm9, xmm8
00007767631dc4ef  mulpd xmm9, xmm11
00007767631dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007767631dc4fa  ptest xmm5, xmm5
00007767631dc4ff  jnz 0x00007767631DFC17
00007767631dc505  movaps xmm11, xmm10
00007767631dc509  addpd xmm11, xmm6
00007767631dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007767631dc514  ptest xmm8, xmm8
00007767631dc51a  jnz 0x00007767631DFD5B
00007767631dc520  movaps xmm10, xmm14
00007767631dc524  addpd xmm10, xmm4
00007767631dc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007767631dc52f  ptest xmm8, xmm8
00007767631dc535  jnz 0x00007767631DFE9E
00007767631dc53b  vmovaps xmm14, [rsp+0x40]
00007767631dc541  vpermilpd xmm14, xmm14, 0x00
00007767631dc547  movaps xmm8, xmm1
00007767631dc54b  mulpd xmm8, xmm14
00007767631dc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007767631dc556  ptest xmm6, xmm6
00007767631dc55b  jnz 0x00007767631DFFE1
00007767631dc561  movaps xmm1, [r15+0x2B0]
00007767631dc569  vmovaps xmm14, [rsp+0x40]
00007767631dc56f  vpermilpd xmm14, xmm14, 0x00
00007767631dc575  movaps xmm6, xmm1
00007767631dc578  mulpd xmm6, xmm14
00007767631dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007767631dc582  ptest xmm5, xmm5
00007767631dc587  jnz 0x00007767631E0124
00007767631dc58d  vmovaps xmm1, [rsp+0x10]
00007767631dc593  vpermilpd xmm1, xmm1, 0x00
00007767631dc599  movaps xmm14, xmm12
00007767631dc59d  mulpd xmm14, xmm1
00007767631dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007767631dc5a8  ptest xmm5, xmm5
00007767631dc5ad  jnz 0x00007767631E0265
00007767631dc5b3  movaps xmm1, xmm13
00007767631dc5b7  addpd xmm1, xmm9
00007767631dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007767631dc5c1  ptest xmm12, xmm12
00007767631dc5c7  jnz 0x00007767631E03A8
00007767631dc5cd  vmovaps xmm13, [rsp+0x10]
00007767631dc5d3  vpermilpd xmm13, xmm13, 0x00
00007767631dc5d9  movaps xmm12, xmm7
00007767631dc5dd  mulpd xmm12, xmm13
00007767631dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007767631dc5e8  ptest xmm9, xmm9
00007767631dc5ee  jnz 0x00007767631E04EA
00007767631dc5f4  movaps xmm13, xmm15
00007767631dc5f8  addpd xmm13, xmm8
00007767631dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007767631dc603  ptest xmm9, xmm9
00007767631dc609  jnz 0x00007767631E062D
00007767631dc60f  movaps xmm15, [r15+0x290]
00007767631dc617  vmovaps xmm9, [rsp+0x10]
00007767631dc61d  vpermilpd xmm9, xmm9, 0x00
00007767631dc623  movaps xmm8, xmm15
00007767631dc627  mulpd xmm8, xmm9
00007767631dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007767631dc632  ptest xmm7, xmm7
00007767631dc637  jnz 0x00007767631E0771
00007767631dc63d  movaps xmm15, xmm11
00007767631dc641  addpd xmm15, xmm6
00007767631dc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007767631dc64c  ptest xmm9, xmm9
00007767631dc652  jnz 0x00007767631E08B5
00007767631dc658  movaps xmm11, [r15+0x1E0]
00007767631dc660  vmovaps xmm9, [rsp+0x10]
00007767631dc666  vpermilpd xmm9, xmm9, 0x00
00007767631dc66c  movaps xmm7, xmm11
00007767631dc670  mulpd xmm7, xmm9
00007767631dc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007767631dc67a  ptest xmm6, xmm6
00007767631dc67f  jnz 0x00007767631E09F8
00007767631dc685  movaps xmm11, xmm10
00007767631dc689  addpd xmm11, xmm14
00007767631dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007767631dc694  ptest xmm9, xmm9
00007767631dc69a  jnz 0x00007767631E0B3A
00007767631dc6a0  lea r12, [rax+0x70]
00007767631dc6a4  movups xmm14, [r13+r12*1]
00007767631dc6aa  movaps [r15+0x240], xmm14
00007767631dc6b2  movaps xmm10, xmm1
00007767631dc6b6  addpd xmm10, xmm12
00007767631dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007767631dc6c1  ptest xmm9, xmm9
00007767631dc6c7  jnz 0x00007767631E0C88
00007767631dc6cd  movaps [r15+0x170], xmm10
00007767631dc6d5  vmovaps xmm1, [rsp+0x20]
00007767631dc6db  vpermilpd xmm1, xmm1, 0x00
00007767631dc6e1  movaps xmm12, xmm14
00007767631dc6e5  mulpd xmm12, xmm1
00007767631dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007767631dc6f0  ptest xmm9, xmm9
00007767631dc6f6  jnz 0x00007767631E0DCB
00007767631dc6fc  vmovaps xmm1, [rsp+0x20]
00007767631dc702  vpermilpd xmm1, xmm1, 0x00
00007767631dc708  vmovaps xmm9, [rsp+0xB0]
00007767631dc711  movaps xmm14, xmm9
00007767631dc715  mulpd xmm14, xmm1
00007767631dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007767631dc720  ptest xmm6, xmm6
00007767631dc725  jnz 0x00007767631E0F0E
00007767631dc72b  movaps [r15+0x180], xmm14
00007767631dc733  movaps xmm1, xmm13
00007767631dc737  addpd xmm1, xmm8
00007767631dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007767631dc741  ptest xmm9, xmm9
00007767631dc747  jnz 0x00007767631E1051
00007767631dc74d  movaps [r15+0x210], xmm1
00007767631dc755  movups xmm13, [r13+rax*1]
00007767631dc75b  lea r12, [rax+0x10]
00007767631dc75f  movups xmm9, [r13+r12*1]
00007767631dc765  movaps [r15+0x230], xmm9
00007767631dc76d  movaps xmm8, xmm15
00007767631dc771  addpd xmm8, xmm7
00007767631dc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007767631dc77c  ptest xmm6, xmm6
00007767631dc781  jnz 0x00007767631E11A7
00007767631dc787  movaps [r15+0x130], xmm8
00007767631dc78f  vmovaps xmm15, [rsp+0x20]
00007767631dc795  vpermilpd xmm15, xmm15, 0x00
00007767631dc79b  movaps xmm7, xmm9
00007767631dc79f  mulpd xmm7, xmm15
00007767631dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007767631dc7a9  ptest xmm6, xmm6
00007767631dc7ae  jnz 0x00007767631E12EA
00007767631dc7b4  movaps [r15+0x220], xmm7
00007767631dc7bc  vmovaps xmm15, [rsp+0x20]
00007767631dc7c2  vpermilpd xmm15, xmm15, 0x00
00007767631dc7c8  movaps xmm9, xmm13
00007767631dc7cc  mulpd xmm9, xmm15
00007767631dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007767631dc7d7  ptest xmm6, xmm6
00007767631dc7dc  jnz 0x00007767631E142C
00007767631dc7e2  movaps xmm15, xmm11
00007767631dc7e6  addpd xmm15, xmm12
00007767631dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007767631dc7f1  ptest xmm13, xmm13
00007767631dc7f7  jnz 0x00007767631E1570
00007767631dc7fd  movaps [r15+0x140], xmm15
00007767631dc805  movaps xmm13, xmm10
00007767631dc809  addpd xmm13, xmm14
00007767631dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007767631dc814  ptest xmm12, xmm12
00007767631dc81a  jnz 0x00007767631E16B4
00007767631dc820  movaps [r15+0x150], xmm13
00007767631dc828  movaps xmm14, xmm1
00007767631dc82c  addpd xmm14, xmm7
00007767631dc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007767631dc837  ptest xmm12, xmm12
00007767631dc83d  jnz 0x00007767631E17F8
00007767631dc843  movaps [r15+0x160], xmm14
00007767631dc84b  movaps xmm1, xmm8
00007767631dc84f  addpd xmm1, xmm9
00007767631dc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007767631dc859  ptest xmm12, xmm12
00007767631dc85f  jnz 0x00007767631E193A
00007767631dc865  movaps [r15+0x120], xmm1
00007767631dc86d  movups [r13+r14*1], xmm15
00007767631dc873  lea rax, [r14+0x10]
00007767631dc877  movups [r13+rax*1], xmm13
00007767631dc87d  lea rax, [r14+0x20]
00007767631dc881  movups [r13+rax*1], xmm14
00007767631dc887  lea rax, [r14+0x30]
00007767631dc88b  movups [r13+rax*1], xmm1
00007767631dc891  mov eax, [r15+0x108]
00007767631dc898  sahf
00007767631dc899  jnz 0x00007767631DC8CB
00007767631dc89b  cmp dword ptr [r15+0x318], 0x00
00007767631dc8a3  jz 0x00007767631DB900
00007767631dc8a9  nop [rax+rax*1], ax
00007767631dc8b2  nop [rax+rax*1], eax
00007767631dc8ba  mov eax, 0x410444
00007767631dc8bf  mov [r15+0x100], rax
00007767631dc8c6  jmp 0x0000776762FFE110
00007767631dc8cb  cmp dword ptr [r15+0x318], 0x00
00007767631dc8d3  jz 0x00007767631D57E0
00007767631dc8d9  nop [rax+rax*1], ax
00007767631dc8e2  nop [rax+rax*1], eax
00007767631dc8ea  mov eax, 0x410278
00007767631dc8ef  mov [r15+0x100], rax
00007767631dc8f6  jmp 0x0000776762FFE110
00007767631dc8fb  int3
00007767631dc8fc  call 0x00007767630E27E0
00007767631dc901  jmp 0x00007767631DB9DF
00007767631dc906  call 0x00007767630E1570
00007767631dc90b  jmp 0x00007767631DB9E8
00007767631dc910  call 0x00007767630E27E0
00007767631dc915  jmp 0x00007767631DBA44
00007767631dc91a  call 0x00007767630E1570
00007767631dc91f  jmp 0x00007767631DBA4D
00007767631dc924  call 0x00007767630E27E0
00007767631dc929  jmp 0x00007767631DBA90
00007767631dc92e  call 0x00007767630E1570
00007767631dc933  jmp 0x00007767631DBA99
00007767631dc938  call 0x000077676300DC20
00007767631dc93d  jmp 0x00007767631DBAD8
00007767631dc942  call 0x00007767630D59C0
00007767631dc947  jmp 0x00007767631DBAEB
00007767631dc94c  call 0x00007767630E0E30
00007767631dc951  jmp 0x00007767631DBB09
00007767631dc956  call 0x00007767630DFBC0
00007767631dc95b  jmp 0x00007767631DBB13
00007767631dc960  call 0x00007767630DE950
00007767631dc965  jmp 0x00007767631DBB1D
00007767631dc96a  sub rsp, 0x08
00007767631dc96e  push rax
00007767631dc96f  push rcx
00007767631dc970  push rdx
00007767631dc971  push rdi
00007767631dc972  push rsi
00007767631dc973  push r8
00007767631dc975  push r9
00007767631dc977  push r10
00007767631dc979  push r11
00007767631dc97b  sub rsp, 0xF0
00007767631dc982  vmovaps [rsp], xmm0
00007767631dc987  vmovaps [rsp+0x10], xmm1
00007767631dc98d  vmovaps [rsp+0x20], xmm2
00007767631dc993  vmovaps [rsp+0x30], xmm3
00007767631dc999  vmovaps [rsp+0x40], xmm4
00007767631dc99f  vmovaps [rsp+0x50], xmm5
00007767631dc9a5  vmovaps [rsp+0x60], xmm6
00007767631dc9ab  vmovaps [rsp+0x70], xmm7
00007767631dc9b1  vmovaps [rsp+0x80], xmm9
00007767631dc9ba  vmovaps [rsp+0x90], xmm10
00007767631dc9c3  vmovaps [rsp+0xA0], xmm11
00007767631dc9cc  vmovaps [rsp+0xB0], xmm12
00007767631dc9d5  vmovaps [rsp+0xC0], xmm13
00007767631dc9de  vmovaps [rsp+0xD0], xmm14
00007767631dc9e7  vmovaps [rsp+0xE0], xmm15
00007767631dc9f0  sub rsp, 0x30
00007767631dc9f4  movaps [rsp], xmm8
00007767631dc9f9  movaps [rsp+0x10], xmm12
00007767631dc9ff  movaps [rsp+0x20], xmm15
00007767631dca05  lea rdi, [rsp]
00007767631dca09  mov esi, 0x00
00007767631dca0e  mov rax, 0x617961CDB530
00007767631dca18  call rax
00007767631dca1a  movaps xmm8, [rsp]
00007767631dca1f  add rsp, 0x30
00007767631dca23  vmovaps xmm0, [rsp]
00007767631dca28  vmovaps xmm1, [rsp+0x10]
00007767631dca2e  vmovaps xmm2, [rsp+0x20]
00007767631dca34  vmovaps xmm3, [rsp+0x30]
00007767631dca3a  vmovaps xmm4, [rsp+0x40]
00007767631dca40  vmovaps xmm5, [rsp+0x50]
00007767631dca46  vmovaps xmm6, [rsp+0x60]
00007767631dca4c  vmovaps xmm7, [rsp+0x70]
00007767631dca52  vmovaps xmm9, [rsp+0x80]
00007767631dca5b  vmovaps xmm10, [rsp+0x90]
00007767631dca64  vmovaps xmm11, [rsp+0xA0]
00007767631dca6d  vmovaps xmm12, [rsp+0xB0]
00007767631dca76  vmovaps xmm13, [rsp+0xC0]
00007767631dca7f  vmovaps xmm14, [rsp+0xD0]
00007767631dca88  vmovaps xmm15, [rsp+0xE0]
00007767631dca91  add rsp, 0xF0
00007767631dca98  pop r11
00007767631dca9a  pop r10
00007767631dca9c  pop r9
00007767631dca9e  pop r8
00007767631dcaa0  pop rsi
00007767631dcaa1  pop rdi
00007767631dcaa2  pop rdx
00007767631dcaa3  pop rcx
00007767631dcaa4  pop rax
00007767631dcaa5  add rsp, 0x08
00007767631dcaa9  jmp 0x00007767631DBB47
00007767631dcaae  sub rsp, 0x08
00007767631dcab2  push rax
00007767631dcab3  push rcx
00007767631dcab4  push rdx
00007767631dcab5  push rdi
00007767631dcab6  push rsi
00007767631dcab7  push r8
00007767631dcab9  push r9
00007767631dcabb  push r10
00007767631dcabd  push r11
00007767631dcabf  sub rsp, 0xF0
00007767631dcac6  vmovaps [rsp], xmm0
00007767631dcacb  vmovaps [rsp+0x10], xmm1
00007767631dcad1  vmovaps [rsp+0x20], xmm2
00007767631dcad7  vmovaps [rsp+0x30], xmm3
00007767631dcadd  vmovaps [rsp+0x40], xmm4
00007767631dcae3  vmovaps [rsp+0x50], xmm5
00007767631dcae9  vmovaps [rsp+0x60], xmm6
00007767631dcaef  vmovaps [rsp+0x70], xmm8
00007767631dcaf5  vmovaps [rsp+0x80], xmm9
00007767631dcafe  vmovaps [rsp+0x90], xmm10
00007767631dcb07  vmovaps [rsp+0xA0], xmm11
00007767631dcb10  vmovaps [rsp+0xB0], xmm12
00007767631dcb19  vmovaps [rsp+0xC0], xmm13
00007767631dcb22  vmovaps [rsp+0xD0], xmm14
00007767631dcb2b  vmovaps [rsp+0xE0], xmm15
00007767631dcb34  sub rsp, 0x30
00007767631dcb38  movaps [rsp], xmm7
00007767631dcb3c  movaps [rsp+0x10], xmm9
00007767631dcb42  movaps [rsp+0x20], xmm15
00007767631dcb48  lea rdi, [rsp]
00007767631dcb4c  mov esi, 0x00
00007767631dcb51  mov rax, 0x617961CDB530
00007767631dcb5b  call rax
00007767631dcb5d  movaps xmm7, [rsp]
00007767631dcb61  add rsp, 0x30
00007767631dcb65  vmovaps xmm0, [rsp]
00007767631dcb6a  vmovaps xmm1, [rsp+0x10]
00007767631dcb70  vmovaps xmm2, [rsp+0x20]
00007767631dcb76  vmovaps xmm3, [rsp+0x30]
00007767631dcb7c  vmovaps xmm4, [rsp+0x40]
00007767631dcb82  vmovaps xmm5, [rsp+0x50]
00007767631dcb88  vmovaps xmm6, [rsp+0x60]
00007767631dcb8e  vmovaps xmm8, [rsp+0x70]
00007767631dcb94  vmovaps xmm9, [rsp+0x80]
00007767631dcb9d  vmovaps xmm10, [rsp+0x90]
00007767631dcba6  vmovaps xmm11, [rsp+0xA0]
00007767631dcbaf  vmovaps xmm12, [rsp+0xB0]
00007767631dcbb8  vmovaps xmm13, [rsp+0xC0]
00007767631dcbc1  vmovaps xmm14, [rsp+0xD0]
00007767631dcbca  vmovaps xmm15, [rsp+0xE0]
00007767631dcbd3  add rsp, 0xF0
00007767631dcbda  pop r11
00007767631dcbdc  pop r10
00007767631dcbde  pop r9
00007767631dcbe0  pop r8
00007767631dcbe2  pop rsi
00007767631dcbe3  pop rdi
00007767631dcbe4  pop rdx
00007767631dcbe5  pop rcx
00007767631dcbe6  pop rax
00007767631dcbe7  add rsp, 0x08
00007767631dcbeb  jmp 0x00007767631DBB75
00007767631dcbf0  sub rsp, 0x08
00007767631dcbf4  push rax
00007767631dcbf5  push rcx
00007767631dcbf6  push rdx
00007767631dcbf7  push rdi
00007767631dcbf8  push rsi
00007767631dcbf9  push r8
00007767631dcbfb  push r9
00007767631dcbfd  push r10
00007767631dcbff  push r11
00007767631dcc01  sub rsp, 0xF0
00007767631dcc08  vmovaps [rsp], xmm0
00007767631dcc0d  vmovaps [rsp+0x10], xmm1
00007767631dcc13  vmovaps [rsp+0x20], xmm2
00007767631dcc19  vmovaps [rsp+0x30], xmm3
00007767631dcc1f  vmovaps [rsp+0x40], xmm4
00007767631dcc25  vmovaps [rsp+0x50], xmm5
00007767631dcc2b  vmovaps [rsp+0x60], xmm6
00007767631dcc31  vmovaps [rsp+0x70], xmm7
00007767631dcc37  vmovaps [rsp+0x80], xmm8
00007767631dcc40  vmovaps [rsp+0x90], xmm10
00007767631dcc49  vmovaps [rsp+0xA0], xmm11
00007767631dcc52  vmovaps [rsp+0xB0], xmm12
00007767631dcc5b  vmovaps [rsp+0xC0], xmm13
00007767631dcc64  vmovaps [rsp+0xD0], xmm14
00007767631dcc6d  vmovaps [rsp+0xE0], xmm15
00007767631dcc76  sub rsp, 0x30
00007767631dcc7a  movaps [rsp], xmm9
00007767631dcc7f  movaps [rsp+0x10], xmm12
00007767631dcc85  movaps [rsp+0x20], xmm10
00007767631dcc8b  lea rdi, [rsp]
00007767631dcc8f  mov esi, 0x00
00007767631dcc94  mov rax, 0x617961CDB530
00007767631dcc9e  call rax
00007767631dcca0  movaps xmm9, [rsp]
00007767631dcca5  add rsp, 0x30
00007767631dcca9  vmovaps xmm0, [rsp]
00007767631dccae  vmovaps xmm1, [rsp+0x10]
00007767631dccb4  vmovaps xmm2, [rsp+0x20]
00007767631dccba  vmovaps xmm3, [rsp+0x30]
00007767631dccc0  vmovaps xmm4, [rsp+0x40]
00007767631dccc6  vmovaps xmm5, [rsp+0x50]
00007767631dcccc  vmovaps xmm6, [rsp+0x60]
00007767631dccd2  vmovaps xmm7, [rsp+0x70]
00007767631dccd8  vmovaps xmm8, [rsp+0x80]
00007767631dcce1  vmovaps xmm10, [rsp+0x90]
00007767631dccea  vmovaps xmm11, [rsp+0xA0]
00007767631dccf3  vmovaps xmm12, [rsp+0xB0]
00007767631dccfc  vmovaps xmm13, [rsp+0xC0]
00007767631dcd05  vmovaps xmm14, [rsp+0xD0]
00007767631dcd0e  vmovaps xmm15, [rsp+0xE0]
00007767631dcd17  add rsp, 0xF0
00007767631dcd1e  pop r11
00007767631dcd20  pop r10
00007767631dcd22  pop r9
00007767631dcd24  pop r8
00007767631dcd26  pop rsi
00007767631dcd27  pop rdi
00007767631dcd28  pop rdx
00007767631dcd29  pop rcx
00007767631dcd2a  pop rax
00007767631dcd2b  add rsp, 0x08
00007767631dcd2f  jmp 0x00007767631DBB99
00007767631dcd34  sub rsp, 0x08
00007767631dcd38  push rax
00007767631dcd39  push rcx
00007767631dcd3a  push rdx
00007767631dcd3b  push rdi
00007767631dcd3c  push rsi
00007767631dcd3d  push r8
00007767631dcd3f  push r9
00007767631dcd41  push r10
00007767631dcd43  push r11
00007767631dcd45  sub rsp, 0xF0
00007767631dcd4c  vmovaps [rsp], xmm0
00007767631dcd51  vmovaps [rsp+0x10], xmm1
00007767631dcd57  vmovaps [rsp+0x20], xmm2
00007767631dcd5d  vmovaps [rsp+0x30], xmm3
00007767631dcd63  vmovaps [rsp+0x40], xmm4
00007767631dcd69  vmovaps [rsp+0x50], xmm5
00007767631dcd6f  vmovaps [rsp+0x60], xmm6
00007767631dcd75  vmovaps [rsp+0x70], xmm7
00007767631dcd7b  vmovaps [rsp+0x80], xmm8
00007767631dcd84  vmovaps [rsp+0x90], xmm9
00007767631dcd8d  vmovaps [rsp+0xA0], xmm11
00007767631dcd96  vmovaps [rsp+0xB0], xmm12
00007767631dcd9f  vmovaps [rsp+0xC0], xmm13
00007767631dcda8  vmovaps [rsp+0xD0], xmm14
00007767631dcdb1  vmovaps [rsp+0xE0], xmm15
00007767631dcdba  sub rsp, 0x30
00007767631dcdbe  movaps [rsp], xmm10
00007767631dcdc3  movaps [rsp+0x10], xmm12
00007767631dcdc9  movaps [rsp+0x20], xmm11
00007767631dcdcf  lea rdi, [rsp]
00007767631dcdd3  mov esi, 0x00
00007767631dcdd8  mov rax, 0x617961CDB530
00007767631dcde2  call rax
00007767631dcde4  movaps xmm10, [rsp]
00007767631dcde9  add rsp, 0x30
00007767631dcded  vmovaps xmm0, [rsp]
00007767631dcdf2  vmovaps xmm1, [rsp+0x10]
00007767631dcdf8  vmovaps xmm2, [rsp+0x20]
00007767631dcdfe  vmovaps xmm3, [rsp+0x30]
00007767631dce04  vmovaps xmm4, [rsp+0x40]
00007767631dce0a  vmovaps xmm5, [rsp+0x50]
00007767631dce10  vmovaps xmm6, [rsp+0x60]
00007767631dce16  vmovaps xmm7, [rsp+0x70]
00007767631dce1c  vmovaps xmm8, [rsp+0x80]
00007767631dce25  vmovaps xmm9, [rsp+0x90]
00007767631dce2e  vmovaps xmm11, [rsp+0xA0]
00007767631dce37  vmovaps xmm12, [rsp+0xB0]
00007767631dce40  vmovaps xmm13, [rsp+0xC0]
00007767631dce49  vmovaps xmm14, [rsp+0xD0]
00007767631dce52  vmovaps xmm15, [rsp+0xE0]
00007767631dce5b  add rsp, 0xF0
00007767631dce62  pop r11
00007767631dce64  pop r10
00007767631dce66  pop r9
00007767631dce68  pop r8
00007767631dce6a  pop rsi
00007767631dce6b  pop rdi
00007767631dce6c  pop rdx
00007767631dce6d  pop rcx
00007767631dce6e  pop rax
00007767631dce6f  add rsp, 0x08
00007767631dce73  jmp 0x00007767631DBBB3
00007767631dce78  sub rsp, 0x08
00007767631dce7c  push rax
00007767631dce7d  push rcx
00007767631dce7e  push rdx
00007767631dce7f  push rdi
00007767631dce80  push rsi
00007767631dce81  push r8
00007767631dce83  push r9
00007767631dce85  push r10
00007767631dce87  push r11
00007767631dce89  sub rsp, 0xF0
00007767631dce90  vmovaps [rsp], xmm0
00007767631dce95  vmovaps [rsp+0x10], xmm1
00007767631dce9b  vmovaps [rsp+0x20], xmm2
00007767631dcea1  vmovaps [rsp+0x30], xmm3
00007767631dcea7  vmovaps [rsp+0x40], xmm4
00007767631dcead  vmovaps [rsp+0x50], xmm5
00007767631dceb3  vmovaps [rsp+0x60], xmm7
00007767631dceb9  vmovaps [rsp+0x70], xmm8
00007767631dcebf  vmovaps [rsp+0x80], xmm9
00007767631dcec8  vmovaps [rsp+0x90], xmm10
00007767631dced1  vmovaps [rsp+0xA0], xmm11
00007767631dceda  vmovaps [rsp+0xB0], xmm12
00007767631dcee3  vmovaps [rsp+0xC0], xmm13
00007767631dceec  vmovaps [rsp+0xD0], xmm14
00007767631dcef5  vmovaps [rsp+0xE0], xmm15
00007767631dcefe  sub rsp, 0x30
00007767631dcf02  movaps [rsp], xmm6
00007767631dcf06  movaps [rsp+0x10], xmm12
00007767631dcf0c  movaps [rsp+0x20], xmm11
00007767631dcf12  lea rdi, [rsp]
00007767631dcf16  mov esi, 0x00
00007767631dcf1b  mov rax, 0x617961CDB530
00007767631dcf25  call rax
00007767631dcf27  movaps xmm6, [rsp]
00007767631dcf2b  add rsp, 0x30
00007767631dcf2f  vmovaps xmm0, [rsp]
00007767631dcf34  vmovaps xmm1, [rsp+0x10]
00007767631dcf3a  vmovaps xmm2, [rsp+0x20]
00007767631dcf40  vmovaps xmm3, [rsp+0x30]
00007767631dcf46  vmovaps xmm4, [rsp+0x40]
00007767631dcf4c  vmovaps xmm5, [rsp+0x50]
00007767631dcf52  vmovaps xmm7, [rsp+0x60]
00007767631dcf58  vmovaps xmm8, [rsp+0x70]
00007767631dcf5e  vmovaps xmm9, [rsp+0x80]
00007767631dcf67  vmovaps xmm10, [rsp+0x90]
00007767631dcf70  vmovaps xmm11, [rsp+0xA0]
00007767631dcf79  vmovaps xmm12, [rsp+0xB0]
00007767631dcf82  vmovaps xmm13, [rsp+0xC0]
00007767631dcf8b  vmovaps xmm14, [rsp+0xD0]
00007767631dcf94  vmovaps xmm15, [rsp+0xE0]
00007767631dcf9d  add rsp, 0xF0
00007767631dcfa4  pop r11
00007767631dcfa6  pop r10
00007767631dcfa8  pop r9
00007767631dcfaa  pop r8
00007767631dcfac  pop rsi
00007767631dcfad  pop rdi
00007767631dcfae  pop rdx
00007767631dcfaf  pop rcx
00007767631dcfb0  pop rax
00007767631dcfb1  add rsp, 0x08
00007767631dcfb5  jmp 0x00007767631DBBD4
00007767631dcfba  sub rsp, 0x08
00007767631dcfbe  push rax
00007767631dcfbf  push rcx
00007767631dcfc0  push rdx
00007767631dcfc1  push rdi
00007767631dcfc2  push rsi
00007767631dcfc3  push r8
00007767631dcfc5  push r9
00007767631dcfc7  push r10
00007767631dcfc9  push r11
00007767631dcfcb  sub rsp, 0xF0
00007767631dcfd2  vmovaps [rsp], xmm0
00007767631dcfd7  vmovaps [rsp+0x10], xmm1
00007767631dcfdd  vmovaps [rsp+0x20], xmm2
00007767631dcfe3  vmovaps [rsp+0x30], xmm4
00007767631dcfe9  vmovaps [rsp+0x40], xmm5
00007767631dcfef  vmovaps [rsp+0x50], xmm6
00007767631dcff5  vmovaps [rsp+0x60], xmm7
00007767631dcffb  vmovaps [rsp+0x70], xmm8
00007767631dd001  vmovaps [rsp+0x80], xmm9
00007767631dd00a  vmovaps [rsp+0x90], xmm10
00007767631dd013  vmovaps [rsp+0xA0], xmm11
00007767631dd01c  vmovaps [rsp+0xB0], xmm12
00007767631dd025  vmovaps [rsp+0xC0], xmm13
00007767631dd02e  vmovaps [rsp+0xD0], xmm14
00007767631dd037  vmovaps [rsp+0xE0], xmm15
00007767631dd040  sub rsp, 0x30
00007767631dd044  movaps [rsp], xmm3
00007767631dd048  movaps [rsp+0x10], xmm5
00007767631dd04d  movaps [rsp+0x20], xmm4
00007767631dd052  lea rdi, [rsp]
00007767631dd056  mov esi, 0x00
00007767631dd05b  mov rax, 0x617961CDB530
00007767631dd065  call rax
00007767631dd067  movaps xmm3, [rsp]
00007767631dd06b  add rsp, 0x30
00007767631dd06f  vmovaps xmm0, [rsp]
00007767631dd074  vmovaps xmm1, [rsp+0x10]
00007767631dd07a  vmovaps xmm2, [rsp+0x20]
00007767631dd080  vmovaps xmm4, [rsp+0x30]
00007767631dd086  vmovaps xmm5, [rsp+0x40]
00007767631dd08c  vmovaps xmm6, [rsp+0x50]
00007767631dd092  vmovaps xmm7, [rsp+0x60]
00007767631dd098  vmovaps xmm8, [rsp+0x70]
00007767631dd09e  vmovaps xmm9, [rsp+0x80]
00007767631dd0a7  vmovaps xmm10, [rsp+0x90]
00007767631dd0b0  vmovaps xmm11, [rsp+0xA0]
00007767631dd0b9  vmovaps xmm12, [rsp+0xB0]
00007767631dd0c2  vmovaps xmm13, [rsp+0xC0]
00007767631dd0cb  vmovaps xmm14, [rsp+0xD0]
00007767631dd0d4  vmovaps xmm15, [rsp+0xE0]
00007767631dd0dd  add rsp, 0xF0
00007767631dd0e4  pop r11
00007767631dd0e6  pop r10
00007767631dd0e8  pop r9
00007767631dd0ea  pop r8
00007767631dd0ec  pop rsi
00007767631dd0ed  pop rdi
00007767631dd0ee  pop rdx
00007767631dd0ef  pop rcx
00007767631dd0f0  pop rax
00007767631dd0f1  add rsp, 0x08
00007767631dd0f5  jmp 0x00007767631DBC35
00007767631dd0fa  sub rsp, 0x08
00007767631dd0fe  push rax
00007767631dd0ff  push rcx
00007767631dd100  push rdx
00007767631dd101  push rdi
00007767631dd102  push rsi
00007767631dd103  push r8
00007767631dd105  push r9
00007767631dd107  push r10
00007767631dd109  push r11
00007767631dd10b  sub rsp, 0xF0
00007767631dd112  vmovaps [rsp], xmm0
00007767631dd117  vmovaps [rsp+0x10], xmm1
00007767631dd11d  vmovaps [rsp+0x20], xmm2
00007767631dd123  vmovaps [rsp+0x30], xmm3
00007767631dd129  vmovaps [rsp+0x40], xmm4
00007767631dd12f  vmovaps [rsp+0x50], xmm6
00007767631dd135  vmovaps [rsp+0x60], xmm7
00007767631dd13b  vmovaps [rsp+0x70], xmm8
00007767631dd141  vmovaps [rsp+0x80], xmm9
00007767631dd14a  vmovaps [rsp+0x90], xmm10
00007767631dd153  vmovaps [rsp+0xA0], xmm11
00007767631dd15c  vmovaps [rsp+0xB0], xmm12
00007767631dd165  vmovaps [rsp+0xC0], xmm13
00007767631dd16e  vmovaps [rsp+0xD0], xmm14
00007767631dd177  vmovaps [rsp+0xE0], xmm15
00007767631dd180  sub rsp, 0x30
00007767631dd184  movaps [rsp], xmm5
00007767631dd188  movaps [rsp+0x10], xmm8
00007767631dd18e  movaps [rsp+0x20], xmm15
00007767631dd194  lea rdi, [rsp]
00007767631dd198  mov esi, 0x00
00007767631dd19d  mov rax, 0x617961CDB530
00007767631dd1a7  call rax
00007767631dd1a9  movaps xmm5, [rsp]
00007767631dd1ad  add rsp, 0x30
00007767631dd1b1  vmovaps xmm0, [rsp]
00007767631dd1b6  vmovaps xmm1, [rsp+0x10]
00007767631dd1bc  vmovaps xmm2, [rsp+0x20]
00007767631dd1c2  vmovaps xmm3, [rsp+0x30]
00007767631dd1c8  vmovaps xmm4, [rsp+0x40]
00007767631dd1ce  vmovaps xmm6, [rsp+0x50]
00007767631dd1d4  vmovaps xmm7, [rsp+0x60]
00007767631dd1da  vmovaps xmm8, [rsp+0x70]
00007767631dd1e0  vmovaps xmm9, [rsp+0x80]
00007767631dd1e9  vmovaps xmm10, [rsp+0x90]
00007767631dd1f2  vmovaps xmm11, [rsp+0xA0]
00007767631dd1fb  vmovaps xmm12, [rsp+0xB0]
00007767631dd204  vmovaps xmm13, [rsp+0xC0]
00007767631dd20d  vmovaps xmm14, [rsp+0xD0]
00007767631dd216  vmovaps xmm15, [rsp+0xE0]
00007767631dd21f  add rsp, 0xF0
00007767631dd226  pop r11
00007767631dd228  pop r10
00007767631dd22a  pop r9
00007767631dd22c  pop r8
00007767631dd22e  pop rsi
00007767631dd22f  pop rdi
00007767631dd230  pop rdx
00007767631dd231  pop rcx
00007767631dd232  pop rax
00007767631dd233  add rsp, 0x08
00007767631dd237  jmp 0x00007767631DBC73
00007767631dd23c  sub rsp, 0x08
00007767631dd240  push rax
00007767631dd241  push rcx
00007767631dd242  push rdx
00007767631dd243  push rdi
00007767631dd244  push rsi
00007767631dd245  push r8
00007767631dd247  push r9
00007767631dd249  push r10
00007767631dd24b  push r11
00007767631dd24d  sub rsp, 0xF0
00007767631dd254  vmovaps [rsp], xmm0
00007767631dd259  vmovaps [rsp+0x10], xmm1
00007767631dd25f  vmovaps [rsp+0x20], xmm2
00007767631dd265  vmovaps [rsp+0x30], xmm3
00007767631dd26b  vmovaps [rsp+0x40], xmm5
00007767631dd271  vmovaps [rsp+0x50], xmm6
00007767631dd277  vmovaps [rsp+0x60], xmm7
00007767631dd27d  vmovaps [rsp+0x70], xmm8
00007767631dd283  vmovaps [rsp+0x80], xmm9
00007767631dd28c  vmovaps [rsp+0x90], xmm10
00007767631dd295  vmovaps [rsp+0xA0], xmm11
00007767631dd29e  vmovaps [rsp+0xB0], xmm12
00007767631dd2a7  vmovaps [rsp+0xC0], xmm13
00007767631dd2b0  vmovaps [rsp+0xD0], xmm14
00007767631dd2b9  vmovaps [rsp+0xE0], xmm15
00007767631dd2c2  sub rsp, 0x30
00007767631dd2c6  movaps [rsp], xmm4
00007767631dd2ca  movaps [rsp+0x10], xmm9
00007767631dd2d0  movaps [rsp+0x20], xmm8
00007767631dd2d6  lea rdi, [rsp]
00007767631dd2da  mov esi, 0x00
00007767631dd2df  mov rax, 0x617961CDB530
00007767631dd2e9  call rax
00007767631dd2eb  movaps xmm4, [rsp]
00007767631dd2ef  add rsp, 0x30
00007767631dd2f3  vmovaps xmm0, [rsp]
00007767631dd2f8  vmovaps xmm1, [rsp+0x10]
00007767631dd2fe  vmovaps xmm2, [rsp+0x20]
00007767631dd304  vmovaps xmm3, [rsp+0x30]
00007767631dd30a  vmovaps xmm5, [rsp+0x40]
00007767631dd310  vmovaps xmm6, [rsp+0x50]
00007767631dd316  vmovaps xmm7, [rsp+0x60]
00007767631dd31c  vmovaps xmm8, [rsp+0x70]
00007767631dd322  vmovaps xmm9, [rsp+0x80]
00007767631dd32b  vmovaps xmm10, [rsp+0x90]
00007767631dd334  vmovaps xmm11, [rsp+0xA0]
00007767631dd33d  vmovaps xmm12, [rsp+0xB0]
00007767631dd346  vmovaps xmm13, [rsp+0xC0]
00007767631dd34f  vmovaps xmm14, [rsp+0xD0]
00007767631dd358  vmovaps xmm15, [rsp+0xE0]
00007767631dd361  add rsp, 0xF0
00007767631dd368  pop r11
00007767631dd36a  pop r10
00007767631dd36c  pop r9
00007767631dd36e  pop r8
00007767631dd370  pop rsi
00007767631dd371  pop rdi
00007767631dd372  pop rdx
00007767631dd373  pop rcx
00007767631dd374  pop rax
00007767631dd375  add rsp, 0x08
00007767631dd379  jmp 0x00007767631DBC94
00007767631dd37e  sub rsp, 0x08
00007767631dd382  push rax
00007767631dd383  push rcx
00007767631dd384  push rdx
00007767631dd385  push rdi
00007767631dd386  push rsi
00007767631dd387  push r8
00007767631dd389  push r9
00007767631dd38b  push r10
00007767631dd38d  push r11
00007767631dd38f  sub rsp, 0xF0
00007767631dd396  vmovaps [rsp], xmm0
00007767631dd39b  vmovaps [rsp+0x10], xmm1
00007767631dd3a1  vmovaps [rsp+0x20], xmm2
00007767631dd3a7  vmovaps [rsp+0x30], xmm3
00007767631dd3ad  vmovaps [rsp+0x40], xmm4
00007767631dd3b3  vmovaps [rsp+0x50], xmm5
00007767631dd3b9  vmovaps [rsp+0x60], xmm6
00007767631dd3bf  vmovaps [rsp+0x70], xmm7
00007767631dd3c5  vmovaps [rsp+0x80], xmm8
00007767631dd3ce  vmovaps [rsp+0x90], xmm10
00007767631dd3d7  vmovaps [rsp+0xA0], xmm11
00007767631dd3e0  vmovaps [rsp+0xB0], xmm12
00007767631dd3e9  vmovaps [rsp+0xC0], xmm13
00007767631dd3f2  vmovaps [rsp+0xD0], xmm14
00007767631dd3fb  vmovaps [rsp+0xE0], xmm15
00007767631dd404  sub rsp, 0x30
00007767631dd408  movaps [rsp], xmm9
00007767631dd40d  movaps [rsp+0x10], xmm10
00007767631dd413  movaps [rsp+0x20], xmm8
00007767631dd419  lea rdi, [rsp]
00007767631dd41d  mov esi, 0x00
00007767631dd422  mov rax, 0x617961CDB530
00007767631dd42c  call rax
00007767631dd42e  movaps xmm9, [rsp]
00007767631dd433  add rsp, 0x30
00007767631dd437  vmovaps xmm0, [rsp]
00007767631dd43c  vmovaps xmm1, [rsp+0x10]
00007767631dd442  vmovaps xmm2, [rsp+0x20]
00007767631dd448  vmovaps xmm3, [rsp+0x30]
00007767631dd44e  vmovaps xmm4, [rsp+0x40]
00007767631dd454  vmovaps xmm5, [rsp+0x50]
00007767631dd45a  vmovaps xmm6, [rsp+0x60]
00007767631dd460  vmovaps xmm7, [rsp+0x70]
00007767631dd466  vmovaps xmm8, [rsp+0x80]
00007767631dd46f  vmovaps xmm10, [rsp+0x90]
00007767631dd478  vmovaps xmm11, [rsp+0xA0]
00007767631dd481  vmovaps xmm12, [rsp+0xB0]
00007767631dd48a  vmovaps xmm13, [rsp+0xC0]
00007767631dd493  vmovaps xmm14, [rsp+0xD0]
00007767631dd49c  vmovaps xmm15, [rsp+0xE0]
00007767631dd4a5  add rsp, 0xF0
00007767631dd4ac  pop r11
00007767631dd4ae  pop r10
00007767631dd4b0  pop r9
00007767631dd4b2  pop r8
00007767631dd4b4  pop rsi
00007767631dd4b5  pop rdi
00007767631dd4b6  pop rdx
00007767631dd4b7  pop rcx
00007767631dd4b8  pop rax
00007767631dd4b9  add rsp, 0x08
00007767631dd4bd  jmp 0x00007767631DBCAE
00007767631dd4c2  call 0x00007767630B52F0
00007767631dd4c7  jmp 0x00007767631DBDC8
00007767631dd4cc  call 0x00007767630B52F0
00007767631dd4d1  jmp 0x00007767631DBDDE
00007767631dd4d6  sub rsp, 0x08
00007767631dd4da  push rax
00007767631dd4db  push rcx
00007767631dd4dc  push rdx
00007767631dd4dd  push rdi
00007767631dd4de  push rsi
00007767631dd4df  push r8
00007767631dd4e1  push r9
00007767631dd4e3  push r10
00007767631dd4e5  push r11
00007767631dd4e7  sub rsp, 0xF0
00007767631dd4ee  vmovaps [rsp], xmm0
00007767631dd4f3  vmovaps [rsp+0x10], xmm2
00007767631dd4f9  vmovaps [rsp+0x20], xmm3
00007767631dd4ff  vmovaps [rsp+0x30], xmm4
00007767631dd505  vmovaps [rsp+0x40], xmm5
00007767631dd50b  vmovaps [rsp+0x50], xmm6
00007767631dd511  vmovaps [rsp+0x60], xmm7
00007767631dd517  vmovaps [rsp+0x70], xmm8
00007767631dd51d  vmovaps [rsp+0x80], xmm9
00007767631dd526  vmovaps [rsp+0x90], xmm10
00007767631dd52f  vmovaps [rsp+0xA0], xmm11
00007767631dd538  vmovaps [rsp+0xB0], xmm12
00007767631dd541  vmovaps [rsp+0xC0], xmm13
00007767631dd54a  vmovaps [rsp+0xD0], xmm14
00007767631dd553  vmovaps [rsp+0xE0], xmm15
00007767631dd55c  sub rsp, 0x30
00007767631dd560  movaps [rsp], xmm1
00007767631dd564  movaps [rsp+0x10], xmm6
00007767631dd569  movaps [rsp+0x20], xmm15
00007767631dd56f  lea rdi, [rsp]
00007767631dd573  mov esi, 0x00
00007767631dd578  mov rax, 0x617961CDB530
00007767631dd582  call rax
00007767631dd584  movaps xmm1, [rsp]
00007767631dd588  add rsp, 0x30
00007767631dd58c  vmovaps xmm0, [rsp]
00007767631dd591  vmovaps xmm2, [rsp+0x10]
00007767631dd597  vmovaps xmm3, [rsp+0x20]
00007767631dd59d  vmovaps xmm4, [rsp+0x30]
00007767631dd5a3  vmovaps xmm5, [rsp+0x40]
00007767631dd5a9  vmovaps xmm6, [rsp+0x50]
00007767631dd5af  vmovaps xmm7, [rsp+0x60]
00007767631dd5b5  vmovaps xmm8, [rsp+0x70]
00007767631dd5bb  vmovaps xmm9, [rsp+0x80]
00007767631dd5c4  vmovaps xmm10, [rsp+0x90]
00007767631dd5cd  vmovaps xmm11, [rsp+0xA0]
00007767631dd5d6  vmovaps xmm12, [rsp+0xB0]
00007767631dd5df  vmovaps xmm13, [rsp+0xC0]
00007767631dd5e8  vmovaps xmm14, [rsp+0xD0]
00007767631dd5f1  vmovaps xmm15, [rsp+0xE0]
00007767631dd5fa  add rsp, 0xF0
00007767631dd601  pop r11
00007767631dd603  pop r10
00007767631dd605  pop r9
00007767631dd607  pop r8
00007767631dd609  pop rsi
00007767631dd60a  pop rdi
00007767631dd60b  pop rdx
00007767631dd60c  pop rcx
00007767631dd60d  pop rax
00007767631dd60e  add rsp, 0x08
00007767631dd612  jmp 0x00007767631DBE1B
00007767631dd617  call 0x00007767630C4620
00007767631dd61c  jmp 0x00007767631DBE28
00007767631dd621  sub rsp, 0x08
00007767631dd625  push rax
00007767631dd626  push rcx
00007767631dd627  push rdx
00007767631dd628  push rdi
00007767631dd629  push rsi
00007767631dd62a  push r8
00007767631dd62c  push r9
00007767631dd62e  push r10
00007767631dd630  push r11
00007767631dd632  sub rsp, 0xF0
00007767631dd639  vmovaps [rsp], xmm0
00007767631dd63e  vmovaps [rsp+0x10], xmm1
00007767631dd644  vmovaps [rsp+0x20], xmm2
00007767631dd64a  vmovaps [rsp+0x30], xmm3
00007767631dd650  vmovaps [rsp+0x40], xmm4
00007767631dd656  vmovaps [rsp+0x50], xmm5
00007767631dd65c  vmovaps [rsp+0x60], xmm6
00007767631dd662  vmovaps [rsp+0x70], xmm7
00007767631dd668  vmovaps [rsp+0x80], xmm8
00007767631dd671  vmovaps [rsp+0x90], xmm9
00007767631dd67a  vmovaps [rsp+0xA0], xmm10
00007767631dd683  vmovaps [rsp+0xB0], xmm11
00007767631dd68c  vmovaps [rsp+0xC0], xmm12
00007767631dd695  vmovaps [rsp+0xD0], xmm13
00007767631dd69e  vmovaps [rsp+0xE0], xmm15
00007767631dd6a7  sub rsp, 0x30
00007767631dd6ab  movaps [rsp], xmm14
00007767631dd6b0  movaps [rsp+0x10], xmm4
00007767631dd6b5  movaps [rsp+0x20], xmm3
00007767631dd6ba  lea rdi, [rsp]
00007767631dd6be  mov esi, 0x00
00007767631dd6c3  mov rax, 0x617961CDB530
00007767631dd6cd  call rax
00007767631dd6cf  movaps xmm14, [rsp]
00007767631dd6d4  add rsp, 0x30
00007767631dd6d8  vmovaps xmm0, [rsp]
00007767631dd6dd  vmovaps xmm1, [rsp+0x10]
00007767631dd6e3  vmovaps xmm2, [rsp+0x20]
00007767631dd6e9  vmovaps xmm3, [rsp+0x30]
00007767631dd6ef  vmovaps xmm4, [rsp+0x40]
00007767631dd6f5  vmovaps xmm5, [rsp+0x50]
00007767631dd6fb  vmovaps xmm6, [rsp+0x60]
00007767631dd701  vmovaps xmm7, [rsp+0x70]
00007767631dd707  vmovaps xmm8, [rsp+0x80]
00007767631dd710  vmovaps xmm9, [rsp+0x90]
00007767631dd719  vmovaps xmm10, [rsp+0xA0]
00007767631dd722  vmovaps xmm11, [rsp+0xB0]
00007767631dd72b  vmovaps xmm12, [rsp+0xC0]
00007767631dd734  vmovaps xmm13, [rsp+0xD0]
00007767631dd73d  vmovaps xmm15, [rsp+0xE0]
00007767631dd746  add rsp, 0xF0
00007767631dd74d  pop r11
00007767631dd74f  pop r10
00007767631dd751  pop r9
00007767631dd753  pop r8
00007767631dd755  pop rsi
00007767631dd756  pop rdi
00007767631dd757  pop rdx
00007767631dd758  pop rcx
00007767631dd759  pop rax
00007767631dd75a  add rsp, 0x08
00007767631dd75e  jmp 0x00007767631DBE42
00007767631dd763  sub rsp, 0x08
00007767631dd767  push rax
00007767631dd768  push rcx
00007767631dd769  push rdx
00007767631dd76a  push rdi
00007767631dd76b  push rsi
00007767631dd76c  push r8
00007767631dd76e  push r9
00007767631dd770  push r10
00007767631dd772  push r11
00007767631dd774  sub rsp, 0xF0
00007767631dd77b  vmovaps [rsp], xmm0
00007767631dd780  vmovaps [rsp+0x10], xmm1
00007767631dd786  vmovaps [rsp+0x20], xmm2
00007767631dd78c  vmovaps [rsp+0x30], xmm3
00007767631dd792  vmovaps [rsp+0x40], xmm4
00007767631dd798  vmovaps [rsp+0x50], xmm5
00007767631dd79e  vmovaps [rsp+0x60], xmm7
00007767631dd7a4  vmovaps [rsp+0x70], xmm8
00007767631dd7aa  vmovaps [rsp+0x80], xmm9
00007767631dd7b3  vmovaps [rsp+0x90], xmm10
00007767631dd7bc  vmovaps [rsp+0xA0], xmm11
00007767631dd7c5  vmovaps [rsp+0xB0], xmm12
00007767631dd7ce  vmovaps [rsp+0xC0], xmm13
00007767631dd7d7  vmovaps [rsp+0xD0], xmm14
00007767631dd7e0  vmovaps [rsp+0xE0], xmm15
00007767631dd7e9  sub rsp, 0x30
00007767631dd7ed  movaps [rsp], xmm6
00007767631dd7f1  movaps [rsp+0x10], xmm9
00007767631dd7f7  movaps [rsp+0x20], xmm7
00007767631dd7fc  lea rdi, [rsp]
00007767631dd800  mov esi, 0x00
00007767631dd805  mov rax, 0x617961CDB530
00007767631dd80f  call rax
00007767631dd811  movaps xmm6, [rsp]
00007767631dd815  add rsp, 0x30
00007767631dd819  vmovaps xmm0, [rsp]
00007767631dd81e  vmovaps xmm1, [rsp+0x10]
00007767631dd824  vmovaps xmm2, [rsp+0x20]
00007767631dd82a  vmovaps xmm3, [rsp+0x30]
00007767631dd830  vmovaps xmm4, [rsp+0x40]
00007767631dd836  vmovaps xmm5, [rsp+0x50]
00007767631dd83c  vmovaps xmm7, [rsp+0x60]
00007767631dd842  vmovaps xmm8, [rsp+0x70]
00007767631dd848  vmovaps xmm9, [rsp+0x80]
00007767631dd851  vmovaps xmm10, [rsp+0x90]
00007767631dd85a  vmovaps xmm11, [rsp+0xA0]
00007767631dd863  vmovaps xmm12, [rsp+0xB0]
00007767631dd86c  vmovaps xmm13, [rsp+0xC0]
00007767631dd875  vmovaps xmm14, [rsp+0xD0]
00007767631dd87e  vmovaps xmm15, [rsp+0xE0]
00007767631dd887  add rsp, 0xF0
00007767631dd88e  pop r11
00007767631dd890  pop r10
00007767631dd892  pop r9
00007767631dd894  pop r8
00007767631dd896  pop rsi
00007767631dd897  pop rdi
00007767631dd898  pop rdx
00007767631dd899  pop rcx
00007767631dd89a  pop rax
00007767631dd89b  add rsp, 0x08
00007767631dd89f  jmp 0x00007767631DBE5A
00007767631dd8a4  sub rsp, 0x08
00007767631dd8a8  push rax
00007767631dd8a9  push rcx
00007767631dd8aa  push rdx
00007767631dd8ab  push rdi
00007767631dd8ac  push rsi
00007767631dd8ad  push r8
00007767631dd8af  push r9
00007767631dd8b1  push r10
00007767631dd8b3  push r11
00007767631dd8b5  sub rsp, 0xF0
00007767631dd8bc  vmovaps [rsp], xmm0
00007767631dd8c1  vmovaps [rsp+0x10], xmm1
00007767631dd8c7  vmovaps [rsp+0x20], xmm2
00007767631dd8cd  vmovaps [rsp+0x30], xmm3
00007767631dd8d3  vmovaps [rsp+0x40], xmm4
00007767631dd8d9  vmovaps [rsp+0x50], xmm5
00007767631dd8df  vmovaps [rsp+0x60], xmm6
00007767631dd8e5  vmovaps [rsp+0x70], xmm8
00007767631dd8eb  vmovaps [rsp+0x80], xmm9
00007767631dd8f4  vmovaps [rsp+0x90], xmm10
00007767631dd8fd  vmovaps [rsp+0xA0], xmm11
00007767631dd906  vmovaps [rsp+0xB0], xmm12
00007767631dd90f  vmovaps [rsp+0xC0], xmm13
00007767631dd918  vmovaps [rsp+0xD0], xmm14
00007767631dd921  vmovaps [rsp+0xE0], xmm15
00007767631dd92a  sub rsp, 0x30
00007767631dd92e  movaps [rsp], xmm7
00007767631dd932  movaps [rsp+0x10], xmm4
00007767631dd937  movaps [rsp+0x20], xmm9
00007767631dd93d  lea rdi, [rsp]
00007767631dd941  mov esi, 0x00
00007767631dd946  mov rax, 0x617961CDB530
00007767631dd950  call rax
00007767631dd952  movaps xmm7, [rsp]
00007767631dd956  add rsp, 0x30
00007767631dd95a  vmovaps xmm0, [rsp]
00007767631dd95f  vmovaps xmm1, [rsp+0x10]
00007767631dd965  vmovaps xmm2, [rsp+0x20]
00007767631dd96b  vmovaps xmm3, [rsp+0x30]
00007767631dd971  vmovaps xmm4, [rsp+0x40]
00007767631dd977  vmovaps xmm5, [rsp+0x50]
00007767631dd97d  vmovaps xmm6, [rsp+0x60]
00007767631dd983  vmovaps xmm8, [rsp+0x70]
00007767631dd989  vmovaps xmm9, [rsp+0x80]
00007767631dd992  vmovaps xmm10, [rsp+0x90]
00007767631dd99b  vmovaps xmm11, [rsp+0xA0]
00007767631dd9a4  vmovaps xmm12, [rsp+0xB0]
00007767631dd9ad  vmovaps xmm13, [rsp+0xC0]
00007767631dd9b6  vmovaps xmm14, [rsp+0xD0]
00007767631dd9bf  vmovaps xmm15, [rsp+0xE0]
00007767631dd9c8  add rsp, 0xF0
00007767631dd9cf  pop r11
00007767631dd9d1  pop r10
00007767631dd9d3  pop r9
00007767631dd9d5  pop r8
00007767631dd9d7  pop rsi
00007767631dd9d8  pop rdi
00007767631dd9d9  pop rdx
00007767631dd9da  pop rcx
00007767631dd9db  pop rax
00007767631dd9dc  add rsp, 0x08
00007767631dd9e0  jmp 0x00007767631DBE87
00007767631dd9e5  sub rsp, 0x08
00007767631dd9e9  push rax
00007767631dd9ea  push rcx
00007767631dd9eb  push rdx
00007767631dd9ec  push rdi
00007767631dd9ed  push rsi
00007767631dd9ee  push r8
00007767631dd9f0  push r9
00007767631dd9f2  push r10
00007767631dd9f4  push r11
00007767631dd9f6  sub rsp, 0xF0
00007767631dd9fd  vmovaps [rsp], xmm0
00007767631dda02  vmovaps [rsp+0x10], xmm1
00007767631dda08  vmovaps [rsp+0x20], xmm2
00007767631dda0e  vmovaps [rsp+0x30], xmm3
00007767631dda14  vmovaps [rsp+0x40], xmm5
00007767631dda1a  vmovaps [rsp+0x50], xmm6
00007767631dda20  vmovaps [rsp+0x60], xmm7
00007767631dda26  vmovaps [rsp+0x70], xmm8
00007767631dda2c  vmovaps [rsp+0x80], xmm9
00007767631dda35  vmovaps [rsp+0x90], xmm10
00007767631dda3e  vmovaps [rsp+0xA0], xmm11
00007767631dda47  vmovaps [rsp+0xB0], xmm12
00007767631dda50  vmovaps [rsp+0xC0], xmm13
00007767631dda59  vmovaps [rsp+0xD0], xmm14
00007767631dda62  vmovaps [rsp+0xE0], xmm15
00007767631dda6b  sub rsp, 0x30
00007767631dda6f  movaps [rsp], xmm4
00007767631dda73  movaps [rsp+0x10], xmm15
00007767631dda79  movaps [rsp+0x20], xmm9
00007767631dda7f  lea rdi, [rsp]
00007767631dda83  mov esi, 0x00
00007767631dda88  mov rax, 0x617961CDB530
00007767631dda92  call rax
00007767631dda94  movaps xmm4, [rsp]
00007767631dda98  add rsp, 0x30
00007767631dda9c  vmovaps xmm0, [rsp]
00007767631ddaa1  vmovaps xmm1, [rsp+0x10]
00007767631ddaa7  vmovaps xmm2, [rsp+0x20]
00007767631ddaad  vmovaps xmm3, [rsp+0x30]
00007767631ddab3  vmovaps xmm5, [rsp+0x40]
00007767631ddab9  vmovaps xmm6, [rsp+0x50]
00007767631ddabf  vmovaps xmm7, [rsp+0x60]
00007767631ddac5  vmovaps xmm8, [rsp+0x70]
00007767631ddacb  vmovaps xmm9, [rsp+0x80]
00007767631ddad4  vmovaps xmm10, [rsp+0x90]
00007767631ddadd  vmovaps xmm11, [rsp+0xA0]
00007767631ddae6  vmovaps xmm12, [rsp+0xB0]
00007767631ddaef  vmovaps xmm13, [rsp+0xC0]
00007767631ddaf8  vmovaps xmm14, [rsp+0xD0]
00007767631ddb01  vmovaps xmm15, [rsp+0xE0]
00007767631ddb0a  add rsp, 0xF0
00007767631ddb11  pop r11
00007767631ddb13  pop r10
00007767631ddb15  pop r9
00007767631ddb17  pop r8
00007767631ddb19  pop rsi
00007767631ddb1a  pop rdi
00007767631ddb1b  pop rdx
00007767631ddb1c  pop rcx
00007767631ddb1d  pop rax
00007767631ddb1e  add rsp, 0x08
00007767631ddb22  jmp 0x00007767631DBEAC
00007767631ddb27  call 0x00007767630C4620
00007767631ddb2c  jmp 0x00007767631DBEB9
00007767631ddb31  sub rsp, 0x08
00007767631ddb35  push rax
00007767631ddb36  push rcx
00007767631ddb37  push rdx
00007767631ddb38  push rdi
00007767631ddb39  push rsi
00007767631ddb3a  push r8
00007767631ddb3c  push r9
00007767631ddb3e  push r10
00007767631ddb40  push r11
00007767631ddb42  sub rsp, 0xF0
00007767631ddb49  vmovaps [rsp], xmm0
00007767631ddb4e  vmovaps [rsp+0x10], xmm1
00007767631ddb54  vmovaps [rsp+0x20], xmm2
00007767631ddb5a  vmovaps [rsp+0x30], xmm4
00007767631ddb60  vmovaps [rsp+0x40], xmm5
00007767631ddb66  vmovaps [rsp+0x50], xmm6
00007767631ddb6c  vmovaps [rsp+0x60], xmm7
00007767631ddb72  vmovaps [rsp+0x70], xmm8
00007767631ddb78  vmovaps [rsp+0x80], xmm9
00007767631ddb81  vmovaps [rsp+0x90], xmm10
00007767631ddb8a  vmovaps [rsp+0xA0], xmm11
00007767631ddb93  vmovaps [rsp+0xB0], xmm12
00007767631ddb9c  vmovaps [rsp+0xC0], xmm13
00007767631ddba5  vmovaps [rsp+0xD0], xmm14
00007767631ddbae  vmovaps [rsp+0xE0], xmm15
00007767631ddbb7  sub rsp, 0x30
00007767631ddbbb  movaps [rsp], xmm3
00007767631ddbbf  movaps [rsp+0x10], xmm1
00007767631ddbc4  movaps [rsp+0x20], xmm9
00007767631ddbca  lea rdi, [rsp]
00007767631ddbce  mov esi, 0x00
00007767631ddbd3  mov rax, 0x617961CDB530
00007767631ddbdd  call rax
00007767631ddbdf  movaps xmm3, [rsp]
00007767631ddbe3  add rsp, 0x30
00007767631ddbe7  vmovaps xmm0, [rsp]
00007767631ddbec  vmovaps xmm1, [rsp+0x10]
00007767631ddbf2  vmovaps xmm2, [rsp+0x20]
00007767631ddbf8  vmovaps xmm4, [rsp+0x30]
00007767631ddbfe  vmovaps xmm5, [rsp+0x40]
00007767631ddc04  vmovaps xmm6, [rsp+0x50]
00007767631ddc0a  vmovaps xmm7, [rsp+0x60]
00007767631ddc10  vmovaps xmm8, [rsp+0x70]
00007767631ddc16  vmovaps xmm9, [rsp+0x80]
00007767631ddc1f  vmovaps xmm10, [rsp+0x90]
00007767631ddc28  vmovaps xmm11, [rsp+0xA0]
00007767631ddc31  vmovaps xmm12, [rsp+0xB0]
00007767631ddc3a  vmovaps xmm13, [rsp+0xC0]
00007767631ddc43  vmovaps xmm14, [rsp+0xD0]
00007767631ddc4c  vmovaps xmm15, [rsp+0xE0]
00007767631ddc55  add rsp, 0xF0
00007767631ddc5c  pop r11
00007767631ddc5e  pop r10
00007767631ddc60  pop r9
00007767631ddc62  pop r8
00007767631ddc64  pop rsi
00007767631ddc65  pop rdi
00007767631ddc66  pop rdx
00007767631ddc67  pop rcx
00007767631ddc68  pop rax
00007767631ddc69  add rsp, 0x08
00007767631ddc6d  jmp 0x00007767631DBEF6
00007767631ddc72  sub rsp, 0x08
00007767631ddc76  push rax
00007767631ddc77  push rcx
00007767631ddc78  push rdx
00007767631ddc79  push rdi
00007767631ddc7a  push rsi
00007767631ddc7b  push r8
00007767631ddc7d  push r9
00007767631ddc7f  push r10
00007767631ddc81  push r11
00007767631ddc83  sub rsp, 0xF0
00007767631ddc8a  vmovaps [rsp], xmm0
00007767631ddc8f  vmovaps [rsp+0x10], xmm2
00007767631ddc95  vmovaps [rsp+0x20], xmm3
00007767631ddc9b  vmovaps [rsp+0x30], xmm4
00007767631ddca1  vmovaps [rsp+0x40], xmm5
00007767631ddca7  vmovaps [rsp+0x50], xmm6
00007767631ddcad  vmovaps [rsp+0x60], xmm7
00007767631ddcb3  vmovaps [rsp+0x70], xmm8
00007767631ddcb9  vmovaps [rsp+0x80], xmm9
00007767631ddcc2  vmovaps [rsp+0x90], xmm10
00007767631ddccb  vmovaps [rsp+0xA0], xmm11
00007767631ddcd4  vmovaps [rsp+0xB0], xmm12
00007767631ddcdd  vmovaps [rsp+0xC0], xmm13
00007767631ddce6  vmovaps [rsp+0xD0], xmm14
00007767631ddcef  vmovaps [rsp+0xE0], xmm15
00007767631ddcf8  sub rsp, 0x30
00007767631ddcfc  movaps [rsp], xmm1
00007767631ddd00  movaps [rsp+0x10], xmm15
00007767631ddd06  movaps [rsp+0x20], xmm9
00007767631ddd0c  lea rdi, [rsp]
00007767631ddd10  mov esi, 0x00
00007767631ddd15  mov rax, 0x617961CDB530
00007767631ddd1f  call rax
00007767631ddd21  movaps xmm1, [rsp]
00007767631ddd25  add rsp, 0x30
00007767631ddd29  vmovaps xmm0, [rsp]
00007767631ddd2e  vmovaps xmm2, [rsp+0x10]
00007767631ddd34  vmovaps xmm3, [rsp+0x20]
00007767631ddd3a  vmovaps xmm4, [rsp+0x30]
00007767631ddd40  vmovaps xmm5, [rsp+0x40]
00007767631ddd46  vmovaps xmm6, [rsp+0x50]
00007767631ddd4c  vmovaps xmm7, [rsp+0x60]
00007767631ddd52  vmovaps xmm8, [rsp+0x70]
00007767631ddd58  vmovaps xmm9, [rsp+0x80]
00007767631ddd61  vmovaps xmm10, [rsp+0x90]
00007767631ddd6a  vmovaps xmm11, [rsp+0xA0]
00007767631ddd73  vmovaps xmm12, [rsp+0xB0]
00007767631ddd7c  vmovaps xmm13, [rsp+0xC0]
00007767631ddd85  vmovaps xmm14, [rsp+0xD0]
00007767631ddd8e  vmovaps xmm15, [rsp+0xE0]
00007767631ddd97  add rsp, 0xF0
00007767631ddd9e  pop r11
00007767631ddda0  pop r10
00007767631ddda2  pop r9
00007767631ddda4  pop r8
00007767631ddda6  pop rsi
00007767631ddda7  pop rdi
00007767631ddda8  pop rdx
00007767631ddda9  pop rcx
00007767631dddaa  pop rax
00007767631dddab  add rsp, 0x08
00007767631dddaf  jmp 0x00007767631DBF7E
00007767631dddb4  call 0x00007767630C4620
00007767631dddb9  jmp 0x00007767631DBF8B
00007767631dddbe  sub rsp, 0x08
00007767631dddc2  push rax
00007767631dddc3  push rcx
00007767631dddc4  push rdx
00007767631dddc5  push rdi
00007767631dddc6  push rsi
00007767631dddc7  push r8
00007767631dddc9  push r9
00007767631dddcb  push r10
00007767631dddcd  push r11
00007767631dddcf  sub rsp, 0xF0
00007767631dddd6  vmovaps [rsp], xmm0
00007767631ddddb  vmovaps [rsp+0x10], xmm2
00007767631ddde1  vmovaps [rsp+0x20], xmm3
00007767631ddde7  vmovaps [rsp+0x30], xmm4
00007767631ddded  vmovaps [rsp+0x40], xmm5
00007767631dddf3  vmovaps [rsp+0x50], xmm6
00007767631dddf9  vmovaps [rsp+0x60], xmm7
00007767631dddff  vmovaps [rsp+0x70], xmm8
00007767631dde05  vmovaps [rsp+0x80], xmm9
00007767631dde0e  vmovaps [rsp+0x90], xmm10
00007767631dde17  vmovaps [rsp+0xA0], xmm11
00007767631dde20  vmovaps [rsp+0xB0], xmm12
00007767631dde29  vmovaps [rsp+0xC0], xmm13
00007767631dde32  vmovaps [rsp+0xD0], xmm14
00007767631dde3b  vmovaps [rsp+0xE0], xmm15
00007767631dde44  sub rsp, 0x30
00007767631dde48  movaps [rsp], xmm1
00007767631dde4c  movaps [rsp+0x10], xmm5
00007767631dde51  movaps [rsp+0x20], xmm7
00007767631dde56  lea rdi, [rsp]
00007767631dde5a  mov esi, 0x00
00007767631dde5f  mov rax, 0x617961CDB530
00007767631dde69  call rax
00007767631dde6b  movaps xmm1, [rsp]
00007767631dde6f  add rsp, 0x30
00007767631dde73  vmovaps xmm0, [rsp]
00007767631dde78  vmovaps xmm2, [rsp+0x10]
00007767631dde7e  vmovaps xmm3, [rsp+0x20]
00007767631dde84  vmovaps xmm4, [rsp+0x30]
00007767631dde8a  vmovaps xmm5, [rsp+0x40]
00007767631dde90  vmovaps xmm6, [rsp+0x50]
00007767631dde96  vmovaps xmm7, [rsp+0x60]
00007767631dde9c  vmovaps xmm8, [rsp+0x70]
00007767631ddea2  vmovaps xmm9, [rsp+0x80]
00007767631ddeab  vmovaps xmm10, [rsp+0x90]
00007767631ddeb4  vmovaps xmm11, [rsp+0xA0]
00007767631ddebd  vmovaps xmm12, [rsp+0xB0]
00007767631ddec6  vmovaps xmm13, [rsp+0xC0]
00007767631ddecf  vmovaps xmm14, [rsp+0xD0]
00007767631dded8  vmovaps xmm15, [rsp+0xE0]
00007767631ddee1  add rsp, 0xF0
00007767631ddee8  pop r11
00007767631ddeea  pop r10
00007767631ddeec  pop r9
00007767631ddeee  pop r8
00007767631ddef0  pop rsi
00007767631ddef1  pop rdi
00007767631ddef2  pop rdx
00007767631ddef3  pop rcx
00007767631ddef4  pop rax
00007767631ddef5  add rsp, 0x08
00007767631ddef9  jmp 0x00007767631DC030
00007767631ddefe  sub rsp, 0x08
00007767631ddf02  push rax
00007767631ddf03  push rcx
00007767631ddf04  push rdx
00007767631ddf05  push rdi
00007767631ddf06  push rsi
00007767631ddf07  push r8
00007767631ddf09  push r9
00007767631ddf0b  push r10
00007767631ddf0d  push r11
00007767631ddf0f  sub rsp, 0xF0
00007767631ddf16  vmovaps [rsp], xmm0
00007767631ddf1b  vmovaps [rsp+0x10], xmm1
00007767631ddf21  vmovaps [rsp+0x20], xmm2
00007767631ddf27  vmovaps [rsp+0x30], xmm3
00007767631ddf2d  vmovaps [rsp+0x40], xmm4
00007767631ddf33  vmovaps [rsp+0x50], xmm5
00007767631ddf39  vmovaps [rsp+0x60], xmm6
00007767631ddf3f  vmovaps [rsp+0x70], xmm8
00007767631ddf45  vmovaps [rsp+0x80], xmm9
00007767631ddf4e  vmovaps [rsp+0x90], xmm10
00007767631ddf57  vmovaps [rsp+0xA0], xmm11
00007767631ddf60  vmovaps [rsp+0xB0], xmm12
00007767631ddf69  vmovaps [rsp+0xC0], xmm13
00007767631ddf72  vmovaps [rsp+0xD0], xmm14
00007767631ddf7b  vmovaps [rsp+0xE0], xmm15
00007767631ddf84  sub rsp, 0x30
00007767631ddf88  movaps [rsp], xmm7
00007767631ddf8c  movaps [rsp+0x10], xmm5
00007767631ddf91  movaps [rsp+0x20], xmm15
00007767631ddf97  lea rdi, [rsp]
00007767631ddf9b  mov esi, 0x00
00007767631ddfa0  mov rax, 0x617961CDB530
00007767631ddfaa  call rax
00007767631ddfac  movaps xmm7, [rsp]
00007767631ddfb0  add rsp, 0x30
00007767631ddfb4  vmovaps xmm0, [rsp]
00007767631ddfb9  vmovaps xmm1, [rsp+0x10]
00007767631ddfbf  vmovaps xmm2, [rsp+0x20]
00007767631ddfc5  vmovaps xmm3, [rsp+0x30]
00007767631ddfcb  vmovaps xmm4, [rsp+0x40]
00007767631ddfd1  vmovaps xmm5, [rsp+0x50]
00007767631ddfd7  vmovaps xmm6, [rsp+0x60]
00007767631ddfdd  vmovaps xmm8, [rsp+0x70]
00007767631ddfe3  vmovaps xmm9, [rsp+0x80]
00007767631ddfec  vmovaps xmm10, [rsp+0x90]
00007767631ddff5  vmovaps xmm11, [rsp+0xA0]
00007767631ddffe  vmovaps xmm12, [rsp+0xB0]
00007767631de007  vmovaps xmm13, [rsp+0xC0]
00007767631de010  vmovaps xmm14, [rsp+0xD0]
00007767631de019  vmovaps xmm15, [rsp+0xE0]
00007767631de022  add rsp, 0xF0
00007767631de029  pop r11
00007767631de02b  pop r10
00007767631de02d  pop r9
00007767631de02f  pop r8
00007767631de031  pop rsi
00007767631de032  pop rdi
00007767631de033  pop rdx
00007767631de034  pop rcx
00007767631de035  pop rax
00007767631de036  add rsp, 0x08
00007767631de03a  jmp 0x00007767631DC066
00007767631de03f  call 0x00007767630B52F0
00007767631de044  jmp 0x00007767631DC073
00007767631de049  sub rsp, 0x08
00007767631de04d  push rax
00007767631de04e  push rcx
00007767631de04f  push rdx
00007767631de050  push rdi
00007767631de051  push rsi
00007767631de052  push r8
00007767631de054  push r9
00007767631de056  push r10
00007767631de058  push r11
00007767631de05a  sub rsp, 0xF0
00007767631de061  vmovaps [rsp], xmm0
00007767631de066  vmovaps [rsp+0x10], xmm1
00007767631de06c  vmovaps [rsp+0x20], xmm2
00007767631de072  vmovaps [rsp+0x30], xmm3
00007767631de078  vmovaps [rsp+0x40], xmm4
00007767631de07e  vmovaps [rsp+0x50], xmm5
00007767631de084  vmovaps [rsp+0x60], xmm6
00007767631de08a  vmovaps [rsp+0x70], xmm7
00007767631de090  vmovaps [rsp+0x80], xmm8
00007767631de099  vmovaps [rsp+0x90], xmm9
00007767631de0a2  vmovaps [rsp+0xA0], xmm10
00007767631de0ab  vmovaps [rsp+0xB0], xmm11
00007767631de0b4  vmovaps [rsp+0xC0], xmm12
00007767631de0bd  vmovaps [rsp+0xD0], xmm13
00007767631de0c6  vmovaps [rsp+0xE0], xmm14
00007767631de0cf  sub rsp, 0x30
00007767631de0d3  movaps [rsp], xmm15
00007767631de0d8  movaps [rsp+0x10], xmm5
00007767631de0dd  movaps [rsp+0x20], xmm3
00007767631de0e2  lea rdi, [rsp]
00007767631de0e6  mov esi, 0x00
00007767631de0eb  mov rax, 0x617961CDB530
00007767631de0f5  call rax
00007767631de0f7  movaps xmm15, [rsp]
00007767631de0fc  add rsp, 0x30
00007767631de100  vmovaps xmm0, [rsp]
00007767631de105  vmovaps xmm1, [rsp+0x10]
00007767631de10b  vmovaps xmm2, [rsp+0x20]
00007767631de111  vmovaps xmm3, [rsp+0x30]
00007767631de117  vmovaps xmm4, [rsp+0x40]
00007767631de11d  vmovaps xmm5, [rsp+0x50]
00007767631de123  vmovaps xmm6, [rsp+0x60]
00007767631de129  vmovaps xmm7, [rsp+0x70]
00007767631de12f  vmovaps xmm8, [rsp+0x80]
00007767631de138  vmovaps xmm9, [rsp+0x90]
00007767631de141  vmovaps xmm10, [rsp+0xA0]
00007767631de14a  vmovaps xmm11, [rsp+0xB0]
00007767631de153  vmovaps xmm12, [rsp+0xC0]
00007767631de15c  vmovaps xmm13, [rsp+0xD0]
00007767631de165  vmovaps xmm14, [rsp+0xE0]
00007767631de16e  add rsp, 0xF0
00007767631de175  pop r11
00007767631de177  pop r10
00007767631de179  pop r9
00007767631de17b  pop r8
00007767631de17d  pop rsi
00007767631de17e  pop rdi
00007767631de17f  pop rdx
00007767631de180  pop rcx
00007767631de181  pop rax
00007767631de182  add rsp, 0x08
00007767631de186  jmp 0x00007767631DC099
00007767631de18b  sub rsp, 0x08
00007767631de18f  push rax
00007767631de190  push rcx
00007767631de191  push rdx
00007767631de192  push rdi
00007767631de193  push rsi
00007767631de194  push r8
00007767631de196  push r9
00007767631de198  push r10
00007767631de19a  push r11
00007767631de19c  sub rsp, 0xF0
00007767631de1a3  vmovaps [rsp], xmm0
00007767631de1a8  vmovaps [rsp+0x10], xmm2
00007767631de1ae  vmovaps [rsp+0x20], xmm3
00007767631de1b4  vmovaps [rsp+0x30], xmm4
00007767631de1ba  vmovaps [rsp+0x40], xmm5
00007767631de1c0  vmovaps [rsp+0x50], xmm6
00007767631de1c6  vmovaps [rsp+0x60], xmm7
00007767631de1cc  vmovaps [rsp+0x70], xmm8
00007767631de1d2  vmovaps [rsp+0x80], xmm9
00007767631de1db  vmovaps [rsp+0x90], xmm10
00007767631de1e4  vmovaps [rsp+0xA0], xmm11
00007767631de1ed  vmovaps [rsp+0xB0], xmm12
00007767631de1f6  vmovaps [rsp+0xC0], xmm13
00007767631de1ff  vmovaps [rsp+0xD0], xmm14
00007767631de208  vmovaps [rsp+0xE0], xmm15
00007767631de211  sub rsp, 0x30
00007767631de215  movaps [rsp], xmm1
00007767631de219  movaps [rsp+0x10], xmm5
00007767631de21e  movaps [rsp+0x20], xmm4
00007767631de223  lea rdi, [rsp]
00007767631de227  mov esi, 0x00
00007767631de22c  mov rax, 0x617961CDB530
00007767631de236  call rax
00007767631de238  movaps xmm1, [rsp]
00007767631de23c  add rsp, 0x30
00007767631de240  vmovaps xmm0, [rsp]
00007767631de245  vmovaps xmm2, [rsp+0x10]
00007767631de24b  vmovaps xmm3, [rsp+0x20]
00007767631de251  vmovaps xmm4, [rsp+0x30]
00007767631de257  vmovaps xmm5, [rsp+0x40]
00007767631de25d  vmovaps xmm6, [rsp+0x50]
00007767631de263  vmovaps xmm7, [rsp+0x60]
00007767631de269  vmovaps xmm8, [rsp+0x70]
00007767631de26f  vmovaps xmm9, [rsp+0x80]
00007767631de278  vmovaps xmm10, [rsp+0x90]
00007767631de281  vmovaps xmm11, [rsp+0xA0]
00007767631de28a  vmovaps xmm12, [rsp+0xB0]
00007767631de293  vmovaps xmm13, [rsp+0xC0]
00007767631de29c  vmovaps xmm14, [rsp+0xD0]
00007767631de2a5  vmovaps xmm15, [rsp+0xE0]
00007767631de2ae  add rsp, 0xF0
00007767631de2b5  pop r11
00007767631de2b7  pop r10
00007767631de2b9  pop r9
00007767631de2bb  pop r8
00007767631de2bd  pop rsi
00007767631de2be  pop rdi
00007767631de2bf  pop rdx
00007767631de2c0  pop rcx
00007767631de2c1  pop rax
00007767631de2c2  add rsp, 0x08
00007767631de2c6  jmp 0x00007767631DC0B9
00007767631de2cb  sub rsp, 0x08
00007767631de2cf  push rax
00007767631de2d0  push rcx
00007767631de2d1  push rdx
00007767631de2d2  push rdi
00007767631de2d3  push rsi
00007767631de2d4  push r8
00007767631de2d6  push r9
00007767631de2d8  push r10
00007767631de2da  push r11
00007767631de2dc  sub rsp, 0xF0
00007767631de2e3  vmovaps [rsp], xmm0
00007767631de2e8  vmovaps [rsp+0x10], xmm1
00007767631de2ee  vmovaps [rsp+0x20], xmm2
00007767631de2f4  vmovaps [rsp+0x30], xmm3
00007767631de2fa  vmovaps [rsp+0x40], xmm5
00007767631de300  vmovaps [rsp+0x50], xmm6
00007767631de306  vmovaps [rsp+0x60], xmm7
00007767631de30c  vmovaps [rsp+0x70], xmm8
00007767631de312  vmovaps [rsp+0x80], xmm9
00007767631de31b  vmovaps [rsp+0x90], xmm10
00007767631de324  vmovaps [rsp+0xA0], xmm11
00007767631de32d  vmovaps [rsp+0xB0], xmm12
00007767631de336  vmovaps [rsp+0xC0], xmm13
00007767631de33f  vmovaps [rsp+0xD0], xmm14
00007767631de348  vmovaps [rsp+0xE0], xmm15
00007767631de351  sub rsp, 0x30
00007767631de355  movaps [rsp], xmm4
00007767631de359  movaps [rsp+0x10], xmm3
00007767631de35e  movaps [rsp+0x20], xmm5
00007767631de363  lea rdi, [rsp]
00007767631de367  mov esi, 0x00
00007767631de36c  mov rax, 0x617961CDB530
00007767631de376  call rax
00007767631de378  movaps xmm4, [rsp]
00007767631de37c  add rsp, 0x30
00007767631de380  vmovaps xmm0, [rsp]
00007767631de385  vmovaps xmm1, [rsp+0x10]
00007767631de38b  vmovaps xmm2, [rsp+0x20]
00007767631de391  vmovaps xmm3, [rsp+0x30]
00007767631de397  vmovaps xmm5, [rsp+0x40]
00007767631de39d  vmovaps xmm6, [rsp+0x50]
00007767631de3a3  vmovaps xmm7, [rsp+0x60]
00007767631de3a9  vmovaps xmm8, [rsp+0x70]
00007767631de3af  vmovaps xmm9, [rsp+0x80]
00007767631de3b8  vmovaps xmm10, [rsp+0x90]
00007767631de3c1  vmovaps xmm11, [rsp+0xA0]
00007767631de3ca  vmovaps xmm12, [rsp+0xB0]
00007767631de3d3  vmovaps xmm13, [rsp+0xC0]
00007767631de3dc  vmovaps xmm14, [rsp+0xD0]
00007767631de3e5  vmovaps xmm15, [rsp+0xE0]
00007767631de3ee  add rsp, 0xF0
00007767631de3f5  pop r11
00007767631de3f7  pop r10
00007767631de3f9  pop r9
00007767631de3fb  pop r8
00007767631de3fd  pop rsi
00007767631de3fe  pop rdi
00007767631de3ff  pop rdx
00007767631de400  pop rcx
00007767631de401  pop rax
00007767631de402  add rsp, 0x08
00007767631de406  jmp 0x00007767631DC107
00007767631de40b  call 0x00007767630B52F0
00007767631de410  jmp 0x00007767631DC114
00007767631de415  sub rsp, 0x08
00007767631de419  push rax
00007767631de41a  push rcx
00007767631de41b  push rdx
00007767631de41c  push rdi
00007767631de41d  push rsi
00007767631de41e  push r8
00007767631de420  push r9
00007767631de422  push r10
00007767631de424  push r11
00007767631de426  sub rsp, 0xF0
00007767631de42d  vmovaps [rsp], xmm0
00007767631de432  vmovaps [rsp+0x10], xmm1
00007767631de438  vmovaps [rsp+0x20], xmm2
00007767631de43e  vmovaps [rsp+0x30], xmm3
00007767631de444  vmovaps [rsp+0x40], xmm4
00007767631de44a  vmovaps [rsp+0x50], xmm6
00007767631de450  vmovaps [rsp+0x60], xmm7
00007767631de456  vmovaps [rsp+0x70], xmm8
00007767631de45c  vmovaps [rsp+0x80], xmm9
00007767631de465  vmovaps [rsp+0x90], xmm10
00007767631de46e  vmovaps [rsp+0xA0], xmm11
00007767631de477  vmovaps [rsp+0xB0], xmm12
00007767631de480  vmovaps [rsp+0xC0], xmm13
00007767631de489  vmovaps [rsp+0xD0], xmm14
00007767631de492  vmovaps [rsp+0xE0], xmm15
00007767631de49b  sub rsp, 0x30
00007767631de49f  movaps [rsp], xmm5
00007767631de4a3  movaps [rsp+0x10], xmm6
00007767631de4a8  movaps [rsp+0x20], xmm3
00007767631de4ad  lea rdi, [rsp]
00007767631de4b1  mov esi, 0x00
00007767631de4b6  mov rax, 0x617961CDB530
00007767631de4c0  call rax
00007767631de4c2  movaps xmm5, [rsp]
00007767631de4c6  add rsp, 0x30
00007767631de4ca  vmovaps xmm0, [rsp]
00007767631de4cf  vmovaps xmm1, [rsp+0x10]
00007767631de4d5  vmovaps xmm2, [rsp+0x20]
00007767631de4db  vmovaps xmm3, [rsp+0x30]
00007767631de4e1  vmovaps xmm4, [rsp+0x40]
00007767631de4e7  vmovaps xmm6, [rsp+0x50]
00007767631de4ed  vmovaps xmm7, [rsp+0x60]
00007767631de4f3  vmovaps xmm8, [rsp+0x70]
00007767631de4f9  vmovaps xmm9, [rsp+0x80]
00007767631de502  vmovaps xmm10, [rsp+0x90]
00007767631de50b  vmovaps xmm11, [rsp+0xA0]
00007767631de514  vmovaps xmm12, [rsp+0xB0]
00007767631de51d  vmovaps xmm13, [rsp+0xC0]
00007767631de526  vmovaps xmm14, [rsp+0xD0]
00007767631de52f  vmovaps xmm15, [rsp+0xE0]
00007767631de538  add rsp, 0xF0
00007767631de53f  pop r11
00007767631de541  pop r10
00007767631de543  pop r9
00007767631de545  pop r8
00007767631de547  pop rsi
00007767631de548  pop rdi
00007767631de549  pop rdx
00007767631de54a  pop rcx
00007767631de54b  pop rax
00007767631de54c  add rsp, 0x08
00007767631de550  jmp 0x00007767631DC13A
00007767631de555  sub rsp, 0x08
00007767631de559  push rax
00007767631de55a  push rcx
00007767631de55b  push rdx
00007767631de55c  push rdi
00007767631de55d  push rsi
00007767631de55e  push r8
00007767631de560  push r9
00007767631de562  push r10
00007767631de564  push r11
00007767631de566  sub rsp, 0xF0
00007767631de56d  vmovaps [rsp], xmm0
00007767631de572  vmovaps [rsp+0x10], xmm1
00007767631de578  vmovaps [rsp+0x20], xmm2
00007767631de57e  vmovaps [rsp+0x30], xmm3
00007767631de584  vmovaps [rsp+0x40], xmm4
00007767631de58a  vmovaps [rsp+0x50], xmm5
00007767631de590  vmovaps [rsp+0x60], xmm7
00007767631de596  vmovaps [rsp+0x70], xmm8
00007767631de59c  vmovaps [rsp+0x80], xmm9
00007767631de5a5  vmovaps [rsp+0x90], xmm10
00007767631de5ae  vmovaps [rsp+0xA0], xmm11
00007767631de5b7  vmovaps [rsp+0xB0], xmm12
00007767631de5c0  vmovaps [rsp+0xC0], xmm13
00007767631de5c9  vmovaps [rsp+0xD0], xmm14
00007767631de5d2  vmovaps [rsp+0xE0], xmm15
00007767631de5db  sub rsp, 0x30
00007767631de5df  movaps [rsp], xmm6
00007767631de5e3  movaps [rsp+0x10], xmm9
00007767631de5e9  movaps [rsp+0x20], xmm1
00007767631de5ee  lea rdi, [rsp]
00007767631de5f2  mov esi, 0x00
00007767631de5f7  mov rax, 0x617961CDB530
00007767631de601  call rax
00007767631de603  movaps xmm6, [rsp]
00007767631de607  add rsp, 0x30
00007767631de60b  vmovaps xmm0, [rsp]
00007767631de610  vmovaps xmm1, [rsp+0x10]
00007767631de616  vmovaps xmm2, [rsp+0x20]
00007767631de61c  vmovaps xmm3, [rsp+0x30]
00007767631de622  vmovaps xmm4, [rsp+0x40]
00007767631de628  vmovaps xmm5, [rsp+0x50]
00007767631de62e  vmovaps xmm7, [rsp+0x60]
00007767631de634  vmovaps xmm8, [rsp+0x70]
00007767631de63a  vmovaps xmm9, [rsp+0x80]
00007767631de643  vmovaps xmm10, [rsp+0x90]
00007767631de64c  vmovaps xmm11, [rsp+0xA0]
00007767631de655  vmovaps xmm12, [rsp+0xB0]
00007767631de65e  vmovaps xmm13, [rsp+0xC0]
00007767631de667  vmovaps xmm14, [rsp+0xD0]
00007767631de670  vmovaps xmm15, [rsp+0xE0]
00007767631de679  add rsp, 0xF0
00007767631de680  pop r11
00007767631de682  pop r10
00007767631de684  pop r9
00007767631de686  pop r8
00007767631de688  pop rsi
00007767631de689  pop rdi
00007767631de68a  pop rdx
00007767631de68b  pop rcx
00007767631de68c  pop rax
00007767631de68d  add rsp, 0x08
00007767631de691  jmp 0x00007767631DC15E
00007767631de696  sub rsp, 0x08
00007767631de69a  push rax
00007767631de69b  push rcx
00007767631de69c  push rdx
00007767631de69d  push rdi
00007767631de69e  push rsi
00007767631de69f  push r8
00007767631de6a1  push r9
00007767631de6a3  push r10
00007767631de6a5  push r11
00007767631de6a7  sub rsp, 0xF0
00007767631de6ae  vmovaps [rsp], xmm0
00007767631de6b3  vmovaps [rsp+0x10], xmm1
00007767631de6b9  vmovaps [rsp+0x20], xmm2
00007767631de6bf  vmovaps [rsp+0x30], xmm3
00007767631de6c5  vmovaps [rsp+0x40], xmm4
00007767631de6cb  vmovaps [rsp+0x50], xmm5
00007767631de6d1  vmovaps [rsp+0x60], xmm6
00007767631de6d7  vmovaps [rsp+0x70], xmm7
00007767631de6dd  vmovaps [rsp+0x80], xmm8
00007767631de6e6  vmovaps [rsp+0x90], xmm10
00007767631de6ef  vmovaps [rsp+0xA0], xmm11
00007767631de6f8  vmovaps [rsp+0xB0], xmm12
00007767631de701  vmovaps [rsp+0xC0], xmm13
00007767631de70a  vmovaps [rsp+0xD0], xmm14
00007767631de713  vmovaps [rsp+0xE0], xmm15
00007767631de71c  sub rsp, 0x30
00007767631de720  movaps [rsp], xmm9
00007767631de725  movaps [rsp+0x10], xmm3
00007767631de72a  movaps [rsp+0x20], xmm1
00007767631de72f  lea rdi, [rsp]
00007767631de733  mov esi, 0x00
00007767631de738  mov rax, 0x617961CDB530
00007767631de742  call rax
00007767631de744  movaps xmm9, [rsp]
00007767631de749  add rsp, 0x30
00007767631de74d  vmovaps xmm0, [rsp]
00007767631de752  vmovaps xmm1, [rsp+0x10]
00007767631de758  vmovaps xmm2, [rsp+0x20]
00007767631de75e  vmovaps xmm3, [rsp+0x30]
00007767631de764  vmovaps xmm4, [rsp+0x40]
00007767631de76a  vmovaps xmm5, [rsp+0x50]
00007767631de770  vmovaps xmm6, [rsp+0x60]
00007767631de776  vmovaps xmm7, [rsp+0x70]
00007767631de77c  vmovaps xmm8, [rsp+0x80]
00007767631de785  vmovaps xmm10, [rsp+0x90]
00007767631de78e  vmovaps xmm11, [rsp+0xA0]
00007767631de797  vmovaps xmm12, [rsp+0xB0]
00007767631de7a0  vmovaps xmm13, [rsp+0xC0]
00007767631de7a9  vmovaps xmm14, [rsp+0xD0]
00007767631de7b2  vmovaps xmm15, [rsp+0xE0]
00007767631de7bb  add rsp, 0xF0
00007767631de7c2  pop r11
00007767631de7c4  pop r10
00007767631de7c6  pop r9
00007767631de7c8  pop r8
00007767631de7ca  pop rsi
00007767631de7cb  pop rdi
00007767631de7cc  pop rdx
00007767631de7cd  pop rcx
00007767631de7ce  pop rax
00007767631de7cf  add rsp, 0x08
00007767631de7d3  jmp 0x00007767631DC1AA
00007767631de7d8  call 0x00007767630B52F0
00007767631de7dd  jmp 0x00007767631DC1B7
00007767631de7e2  sub rsp, 0x08
00007767631de7e6  push rax
00007767631de7e7  push rcx
00007767631de7e8  push rdx
00007767631de7e9  push rdi
00007767631de7ea  push rsi
00007767631de7eb  push r8
00007767631de7ed  push r9
00007767631de7ef  push r10
00007767631de7f1  push r11
00007767631de7f3  sub rsp, 0xF0
00007767631de7fa  vmovaps [rsp], xmm0
00007767631de7ff  vmovaps [rsp+0x10], xmm1
00007767631de805  vmovaps [rsp+0x20], xmm2
00007767631de80b  vmovaps [rsp+0x30], xmm3
00007767631de811  vmovaps [rsp+0x40], xmm4
00007767631de817  vmovaps [rsp+0x50], xmm5
00007767631de81d  vmovaps [rsp+0x60], xmm6
00007767631de823  vmovaps [rsp+0x70], xmm7
00007767631de829  vmovaps [rsp+0x80], xmm8
00007767631de832  vmovaps [rsp+0x90], xmm9
00007767631de83b  vmovaps [rsp+0xA0], xmm10
00007767631de844  vmovaps [rsp+0xB0], xmm11
00007767631de84d  vmovaps [rsp+0xC0], xmm12
00007767631de856  vmovaps [rsp+0xD0], xmm13
00007767631de85f  vmovaps [rsp+0xE0], xmm14
00007767631de868  sub rsp, 0x30
00007767631de86c  movaps [rsp], xmm15
00007767631de871  movaps [rsp+0x10], xmm3
00007767631de876  movaps [rsp+0x20], xmm7
00007767631de87b  lea rdi, [rsp]
00007767631de87f  mov esi, 0x00
00007767631de884  mov rax, 0x617961CDB530
00007767631de88e  call rax
00007767631de890  movaps xmm15, [rsp]
00007767631de895  add rsp, 0x30
00007767631de899  vmovaps xmm0, [rsp]
00007767631de89e  vmovaps xmm1, [rsp+0x10]
00007767631de8a4  vmovaps xmm2, [rsp+0x20]
00007767631de8aa  vmovaps xmm3, [rsp+0x30]
00007767631de8b0  vmovaps xmm4, [rsp+0x40]
00007767631de8b6  vmovaps xmm5, [rsp+0x50]
00007767631de8bc  vmovaps xmm6, [rsp+0x60]
00007767631de8c2  vmovaps xmm7, [rsp+0x70]
00007767631de8c8  vmovaps xmm8, [rsp+0x80]
00007767631de8d1  vmovaps xmm9, [rsp+0x90]
00007767631de8da  vmovaps xmm10, [rsp+0xA0]
00007767631de8e3  vmovaps xmm11, [rsp+0xB0]
00007767631de8ec  vmovaps xmm12, [rsp+0xC0]
00007767631de8f5  vmovaps xmm13, [rsp+0xD0]
00007767631de8fe  vmovaps xmm14, [rsp+0xE0]
00007767631de907  add rsp, 0xF0
00007767631de90e  pop r11
00007767631de910  pop r10
00007767631de912  pop r9
00007767631de914  pop r8
00007767631de916  pop rsi
00007767631de917  pop rdi
00007767631de918  pop rdx
00007767631de919  pop rcx
00007767631de91a  pop rax
00007767631de91b  add rsp, 0x08
00007767631de91f  jmp 0x00007767631DC1E3
00007767631de924  sub rsp, 0x08
00007767631de928  push rax
00007767631de929  push rcx
00007767631de92a  push rdx
00007767631de92b  push rdi
00007767631de92c  push rsi
00007767631de92d  push r8
00007767631de92f  push r9
00007767631de931  push r10
00007767631de933  push r11
00007767631de935  sub rsp, 0xF0
00007767631de93c  vmovaps [rsp], xmm0
00007767631de941  vmovaps [rsp+0x10], xmm1
00007767631de947  vmovaps [rsp+0x20], xmm2
00007767631de94d  vmovaps [rsp+0x30], xmm4
00007767631de953  vmovaps [rsp+0x40], xmm5
00007767631de959  vmovaps [rsp+0x50], xmm6
00007767631de95f  vmovaps [rsp+0x60], xmm7
00007767631de965  vmovaps [rsp+0x70], xmm8
00007767631de96b  vmovaps [rsp+0x80], xmm9
00007767631de974  vmovaps [rsp+0x90], xmm10
00007767631de97d  vmovaps [rsp+0xA0], xmm11
00007767631de986  vmovaps [rsp+0xB0], xmm12
00007767631de98f  vmovaps [rsp+0xC0], xmm13
00007767631de998  vmovaps [rsp+0xD0], xmm14
00007767631de9a1  vmovaps [rsp+0xE0], xmm15
00007767631de9aa  sub rsp, 0x30
00007767631de9ae  movaps [rsp], xmm3
00007767631de9b2  movaps [rsp+0x10], xmm1
00007767631de9b7  movaps [rsp+0x20], xmm15
00007767631de9bd  lea rdi, [rsp]
00007767631de9c1  mov esi, 0x00
00007767631de9c6  mov rax, 0x617961CDB530
00007767631de9d0  call rax
00007767631de9d2  movaps xmm3, [rsp]
00007767631de9d6  add rsp, 0x30
00007767631de9da  vmovaps xmm0, [rsp]
00007767631de9df  vmovaps xmm1, [rsp+0x10]
00007767631de9e5  vmovaps xmm2, [rsp+0x20]
00007767631de9eb  vmovaps xmm4, [rsp+0x30]
00007767631de9f1  vmovaps xmm5, [rsp+0x40]
00007767631de9f7  vmovaps xmm6, [rsp+0x50]
00007767631de9fd  vmovaps xmm7, [rsp+0x60]
00007767631dea03  vmovaps xmm8, [rsp+0x70]
00007767631dea09  vmovaps xmm9, [rsp+0x80]
00007767631dea12  vmovaps xmm10, [rsp+0x90]
00007767631dea1b  vmovaps xmm11, [rsp+0xA0]
00007767631dea24  vmovaps xmm12, [rsp+0xB0]
00007767631dea2d  vmovaps xmm13, [rsp+0xC0]
00007767631dea36  vmovaps xmm14, [rsp+0xD0]
00007767631dea3f  vmovaps xmm15, [rsp+0xE0]
00007767631dea48  add rsp, 0xF0
00007767631dea4f  pop r11
00007767631dea51  pop r10
00007767631dea53  pop r9
00007767631dea55  pop r8
00007767631dea57  pop rsi
00007767631dea58  pop rdi
00007767631dea59  pop rdx
00007767631dea5a  pop rcx
00007767631dea5b  pop rax
00007767631dea5c  add rsp, 0x08
00007767631dea60  jmp 0x00007767631DC272
00007767631dea65  call 0x00007767630B52F0
00007767631dea6a  jmp 0x00007767631DC27C
00007767631dea6f  sub rsp, 0x08
00007767631dea73  push rax
00007767631dea74  push rcx
00007767631dea75  push rdx
00007767631dea76  push rdi
00007767631dea77  push rsi
00007767631dea78  push r8
00007767631dea7a  push r9
00007767631dea7c  push r10
00007767631dea7e  push r11
00007767631dea80  sub rsp, 0xF0
00007767631dea87  vmovaps [rsp], xmm0
00007767631dea8c  vmovaps [rsp+0x10], xmm1
00007767631dea92  vmovaps [rsp+0x20], xmm2
00007767631dea98  vmovaps [rsp+0x30], xmm3
00007767631dea9e  vmovaps [rsp+0x40], xmm4
00007767631deaa4  vmovaps [rsp+0x50], xmm5
00007767631deaaa  vmovaps [rsp+0x60], xmm6
00007767631deab0  vmovaps [rsp+0x70], xmm7
00007767631deab6  vmovaps [rsp+0x80], xmm8
00007767631deabf  vmovaps [rsp+0x90], xmm9
00007767631deac8  vmovaps [rsp+0xA0], xmm10
00007767631dead1  vmovaps [rsp+0xB0], xmm11
00007767631deada  vmovaps [rsp+0xC0], xmm12
00007767631deae3  vmovaps [rsp+0xD0], xmm13
00007767631deaec  vmovaps [rsp+0xE0], xmm14
00007767631deaf5  sub rsp, 0x30
00007767631deaf9  movaps [rsp], xmm15
00007767631deafe  movaps [rsp+0x10], xmm14
00007767631deb04  movaps [rsp+0x20], xmm4
00007767631deb09  lea rdi, [rsp]
00007767631deb0d  mov esi, 0x00
00007767631deb12  mov rax, 0x617961CDB530
00007767631deb1c  call rax
00007767631deb1e  movaps xmm15, [rsp]
00007767631deb23  add rsp, 0x30
00007767631deb27  vmovaps xmm0, [rsp]
00007767631deb2c  vmovaps xmm1, [rsp+0x10]
00007767631deb32  vmovaps xmm2, [rsp+0x20]
00007767631deb38  vmovaps xmm3, [rsp+0x30]
00007767631deb3e  vmovaps xmm4, [rsp+0x40]
00007767631deb44  vmovaps xmm5, [rsp+0x50]
00007767631deb4a  vmovaps xmm6, [rsp+0x60]
00007767631deb50  vmovaps xmm7, [rsp+0x70]
00007767631deb56  vmovaps xmm8, [rsp+0x80]
00007767631deb5f  vmovaps xmm9, [rsp+0x90]
00007767631deb68  vmovaps xmm10, [rsp+0xA0]
00007767631deb71  vmovaps xmm11, [rsp+0xB0]
00007767631deb7a  vmovaps xmm12, [rsp+0xC0]
00007767631deb83  vmovaps xmm13, [rsp+0xD0]
00007767631deb8c  vmovaps xmm14, [rsp+0xE0]
00007767631deb95  add rsp, 0xF0
00007767631deb9c  pop r11
00007767631deb9e  pop r10
00007767631deba0  pop r9
00007767631deba2  pop r8
00007767631deba4  pop rsi
00007767631deba5  pop rdi
00007767631deba6  pop rdx
00007767631deba7  pop rcx
00007767631deba8  pop rax
00007767631deba9  add rsp, 0x08
00007767631debad  jmp 0x00007767631DC2AA
00007767631debb2  sub rsp, 0x08
00007767631debb6  push rax
00007767631debb7  push rcx
00007767631debb8  push rdx
00007767631debb9  push rdi
00007767631debba  push rsi
00007767631debbb  push r8
00007767631debbd  push r9
00007767631debbf  push r10
00007767631debc1  push r11
00007767631debc3  sub rsp, 0xF0
00007767631debca  vmovaps [rsp], xmm0
00007767631debcf  vmovaps [rsp+0x10], xmm1
00007767631debd5  vmovaps [rsp+0x20], xmm2
00007767631debdb  vmovaps [rsp+0x30], xmm3
00007767631debe1  vmovaps [rsp+0x40], xmm4
00007767631debe7  vmovaps [rsp+0x50], xmm5
00007767631debed  vmovaps [rsp+0x60], xmm6
00007767631debf3  vmovaps [rsp+0x70], xmm7
00007767631debf9  vmovaps [rsp+0x80], xmm8
00007767631dec02  vmovaps [rsp+0x90], xmm9
00007767631dec0b  vmovaps [rsp+0xA0], xmm10
00007767631dec14  vmovaps [rsp+0xB0], xmm11
00007767631dec1d  vmovaps [rsp+0xC0], xmm12
00007767631dec26  vmovaps [rsp+0xD0], xmm13
00007767631dec2f  vmovaps [rsp+0xE0], xmm15
00007767631dec38  sub rsp, 0x30
00007767631dec3c  movaps [rsp], xmm14
00007767631dec41  movaps [rsp+0x10], xmm2
00007767631dec46  movaps [rsp+0x20], xmm1
00007767631dec4b  lea rdi, [rsp]
00007767631dec4f  mov esi, 0x00
00007767631dec54  mov rax, 0x617961CDB530
00007767631dec5e  call rax
00007767631dec60  movaps xmm14, [rsp]
00007767631dec65  add rsp, 0x30
00007767631dec69  vmovaps xmm0, [rsp]
00007767631dec6e  vmovaps xmm1, [rsp+0x10]
00007767631dec74  vmovaps xmm2, [rsp+0x20]
00007767631dec7a  vmovaps xmm3, [rsp+0x30]
00007767631dec80  vmovaps xmm4, [rsp+0x40]
00007767631dec86  vmovaps xmm5, [rsp+0x50]
00007767631dec8c  vmovaps xmm6, [rsp+0x60]
00007767631dec92  vmovaps xmm7, [rsp+0x70]
00007767631dec98  vmovaps xmm8, [rsp+0x80]
00007767631deca1  vmovaps xmm9, [rsp+0x90]
00007767631decaa  vmovaps xmm10, [rsp+0xA0]
00007767631decb3  vmovaps xmm11, [rsp+0xB0]
00007767631decbc  vmovaps xmm12, [rsp+0xC0]
00007767631decc5  vmovaps xmm13, [rsp+0xD0]
00007767631decce  vmovaps xmm15, [rsp+0xE0]
00007767631decd7  add rsp, 0xF0
00007767631decde  pop r11
00007767631dece0  pop r10
00007767631dece2  pop r9
00007767631dece4  pop r8
00007767631dece6  pop rsi
00007767631dece7  pop rdi
00007767631dece8  pop rdx
00007767631dece9  pop rcx
00007767631decea  pop rax
00007767631deceb  add rsp, 0x08
00007767631decef  jmp 0x00007767631DC2D0
00007767631decf4  sub rsp, 0x08
00007767631decf8  push rax
00007767631decf9  push rcx
00007767631decfa  push rdx
00007767631decfb  push rdi
00007767631decfc  push rsi
00007767631decfd  push r8
00007767631decff  push r9
00007767631ded01  push r10
00007767631ded03  push r11
00007767631ded05  sub rsp, 0xF0
00007767631ded0c  vmovaps [rsp], xmm0
00007767631ded11  vmovaps [rsp+0x10], xmm2
00007767631ded17  vmovaps [rsp+0x20], xmm3
00007767631ded1d  vmovaps [rsp+0x30], xmm4
00007767631ded23  vmovaps [rsp+0x40], xmm5
00007767631ded29  vmovaps [rsp+0x50], xmm6
00007767631ded2f  vmovaps [rsp+0x60], xmm7
00007767631ded35  vmovaps [rsp+0x70], xmm8
00007767631ded3b  vmovaps [rsp+0x80], xmm9
00007767631ded44  vmovaps [rsp+0x90], xmm10
00007767631ded4d  vmovaps [rsp+0xA0], xmm11
00007767631ded56  vmovaps [rsp+0xB0], xmm12
00007767631ded5f  vmovaps [rsp+0xC0], xmm13
00007767631ded68  vmovaps [rsp+0xD0], xmm14
00007767631ded71  vmovaps [rsp+0xE0], xmm15
00007767631ded7a  sub rsp, 0x30
00007767631ded7e  movaps [rsp], xmm1
00007767631ded82  movaps [rsp+0x10], xmm4
00007767631ded87  movaps [rsp+0x20], xmm9
00007767631ded8d  lea rdi, [rsp]
00007767631ded91  mov esi, 0x00
00007767631ded96  mov rax, 0x617961CDB530
00007767631deda0  call rax
00007767631deda2  movaps xmm1, [rsp]
00007767631deda6  add rsp, 0x30
00007767631dedaa  vmovaps xmm0, [rsp]
00007767631dedaf  vmovaps xmm2, [rsp+0x10]
00007767631dedb5  vmovaps xmm3, [rsp+0x20]
00007767631dedbb  vmovaps xmm4, [rsp+0x30]
00007767631dedc1  vmovaps xmm5, [rsp+0x40]
00007767631dedc7  vmovaps xmm6, [rsp+0x50]
00007767631dedcd  vmovaps xmm7, [rsp+0x60]
00007767631dedd3  vmovaps xmm8, [rsp+0x70]
00007767631dedd9  vmovaps xmm9, [rsp+0x80]
00007767631dede2  vmovaps xmm10, [rsp+0x90]
00007767631dedeb  vmovaps xmm11, [rsp+0xA0]
00007767631dedf4  vmovaps xmm12, [rsp+0xB0]
00007767631dedfd  vmovaps xmm13, [rsp+0xC0]
00007767631dee06  vmovaps xmm14, [rsp+0xD0]
00007767631dee0f  vmovaps xmm15, [rsp+0xE0]
00007767631dee18  add rsp, 0xF0
00007767631dee1f  pop r11
00007767631dee21  pop r10
00007767631dee23  pop r9
00007767631dee25  pop r8
00007767631dee27  pop rsi
00007767631dee28  pop rdi
00007767631dee29  pop rdx
00007767631dee2a  pop rcx
00007767631dee2b  pop rax
00007767631dee2c  add rsp, 0x08
00007767631dee30  jmp 0x00007767631DC2EE
00007767631dee35  sub rsp, 0x08
00007767631dee39  push rax
00007767631dee3a  push rcx
00007767631dee3b  push rdx
00007767631dee3c  push rdi
00007767631dee3d  push rsi
00007767631dee3e  push r8
00007767631dee40  push r9
00007767631dee42  push r10
00007767631dee44  push r11
00007767631dee46  sub rsp, 0xF0
00007767631dee4d  vmovaps [rsp], xmm0
00007767631dee52  vmovaps [rsp+0x10], xmm1
00007767631dee58  vmovaps [rsp+0x20], xmm2
00007767631dee5e  vmovaps [rsp+0x30], xmm3
00007767631dee64  vmovaps [rsp+0x40], xmm5
00007767631dee6a  vmovaps [rsp+0x50], xmm6
00007767631dee70  vmovaps [rsp+0x60], xmm7
00007767631dee76  vmovaps [rsp+0x70], xmm8
00007767631dee7c  vmovaps [rsp+0x80], xmm9
00007767631dee85  vmovaps [rsp+0x90], xmm10
00007767631dee8e  vmovaps [rsp+0xA0], xmm11
00007767631dee97  vmovaps [rsp+0xB0], xmm12
00007767631deea0  vmovaps [rsp+0xC0], xmm13
00007767631deea9  vmovaps [rsp+0xD0], xmm14
00007767631deeb2  vmovaps [rsp+0xE0], xmm15
00007767631deebb  sub rsp, 0x30
00007767631deebf  movaps [rsp], xmm4
00007767631deec3  movaps [rsp+0x10], xmm2
00007767631deec8  movaps [rsp+0x20], xmm9
00007767631deece  lea rdi, [rsp]
00007767631deed2  mov esi, 0x00
00007767631deed7  mov rax, 0x617961CDB530
00007767631deee1  call rax
00007767631deee3  movaps xmm4, [rsp]
00007767631deee7  add rsp, 0x30
00007767631deeeb  vmovaps xmm0, [rsp]
00007767631deef0  vmovaps xmm1, [rsp+0x10]
00007767631deef6  vmovaps xmm2, [rsp+0x20]
00007767631deefc  vmovaps xmm3, [rsp+0x30]
00007767631def02  vmovaps xmm5, [rsp+0x40]
00007767631def08  vmovaps xmm6, [rsp+0x50]
00007767631def0e  vmovaps xmm7, [rsp+0x60]
00007767631def14  vmovaps xmm8, [rsp+0x70]
00007767631def1a  vmovaps xmm9, [rsp+0x80]
00007767631def23  vmovaps xmm10, [rsp+0x90]
00007767631def2c  vmovaps xmm11, [rsp+0xA0]
00007767631def35  vmovaps xmm12, [rsp+0xB0]
00007767631def3e  vmovaps xmm13, [rsp+0xC0]
00007767631def47  vmovaps xmm14, [rsp+0xD0]
00007767631def50  vmovaps xmm15, [rsp+0xE0]
00007767631def59  add rsp, 0xF0
00007767631def60  pop r11
00007767631def62  pop r10
00007767631def64  pop r9
00007767631def66  pop r8
00007767631def68  pop rsi
00007767631def69  pop rdi
00007767631def6a  pop rdx
00007767631def6b  pop rcx
00007767631def6c  pop rax
00007767631def6d  add rsp, 0x08
00007767631def71  jmp 0x00007767631DC31E
00007767631def76  sub rsp, 0x08
00007767631def7a  push rax
00007767631def7b  push rcx
00007767631def7c  push rdx
00007767631def7d  push rdi
00007767631def7e  push rsi
00007767631def7f  push r8
00007767631def81  push r9
00007767631def83  push r10
00007767631def85  push r11
00007767631def87  sub rsp, 0xF0
00007767631def8e  vmovaps [rsp], xmm0
00007767631def93  vmovaps [rsp+0x10], xmm1
00007767631def99  vmovaps [rsp+0x20], xmm2
00007767631def9f  vmovaps [rsp+0x30], xmm3
00007767631defa5  vmovaps [rsp+0x40], xmm4
00007767631defab  vmovaps [rsp+0x50], xmm5
00007767631defb1  vmovaps [rsp+0x60], xmm6
00007767631defb7  vmovaps [rsp+0x70], xmm7
00007767631defbd  vmovaps [rsp+0x80], xmm8
00007767631defc6  vmovaps [rsp+0x90], xmm10
00007767631defcf  vmovaps [rsp+0xA0], xmm11
00007767631defd8  vmovaps [rsp+0xB0], xmm12
00007767631defe1  vmovaps [rsp+0xC0], xmm13
00007767631defea  vmovaps [rsp+0xD0], xmm14
00007767631deff3  vmovaps [rsp+0xE0], xmm15
00007767631deffc  sub rsp, 0x30
00007767631df000  movaps [rsp], xmm9
00007767631df005  movaps [rsp+0x10], xmm2
00007767631df00a  movaps [rsp+0x20], xmm1
00007767631df00f  lea rdi, [rsp]
00007767631df013  mov esi, 0x00
00007767631df018  mov rax, 0x617961CDB530
00007767631df022  call rax
00007767631df024  movaps xmm9, [rsp]
00007767631df029  add rsp, 0x30
00007767631df02d  vmovaps xmm0, [rsp]
00007767631df032  vmovaps xmm1, [rsp+0x10]
00007767631df038  vmovaps xmm2, [rsp+0x20]
00007767631df03e  vmovaps xmm3, [rsp+0x30]
00007767631df044  vmovaps xmm4, [rsp+0x40]
00007767631df04a  vmovaps xmm5, [rsp+0x50]
00007767631df050  vmovaps xmm6, [rsp+0x60]
00007767631df056  vmovaps xmm7, [rsp+0x70]
00007767631df05c  vmovaps xmm8, [rsp+0x80]
00007767631df065  vmovaps xmm10, [rsp+0x90]
00007767631df06e  vmovaps xmm11, [rsp+0xA0]
00007767631df077  vmovaps xmm12, [rsp+0xB0]
00007767631df080  vmovaps xmm13, [rsp+0xC0]
00007767631df089  vmovaps xmm14, [rsp+0xD0]
00007767631df092  vmovaps xmm15, [rsp+0xE0]
00007767631df09b  add rsp, 0xF0
00007767631df0a2  pop r11
00007767631df0a4  pop r10
00007767631df0a6  pop r9
00007767631df0a8  pop r8
00007767631df0aa  pop rsi
00007767631df0ab  pop rdi
00007767631df0ac  pop rdx
00007767631df0ad  pop rcx
00007767631df0ae  pop rax
00007767631df0af  add rsp, 0x08
00007767631df0b3  jmp 0x00007767631DC354
00007767631df0b8  sub rsp, 0x08
00007767631df0bc  push rax
00007767631df0bd  push rcx
00007767631df0be  push rdx
00007767631df0bf  push rdi
00007767631df0c0  push rsi
00007767631df0c1  push r8
00007767631df0c3  push r9
00007767631df0c5  push r10
00007767631df0c7  push r11
00007767631df0c9  sub rsp, 0xF0
00007767631df0d0  vmovaps [rsp], xmm0
00007767631df0d5  vmovaps [rsp+0x10], xmm2
00007767631df0db  vmovaps [rsp+0x20], xmm3
00007767631df0e1  vmovaps [rsp+0x30], xmm4
00007767631df0e7  vmovaps [rsp+0x40], xmm5
00007767631df0ed  vmovaps [rsp+0x50], xmm6
00007767631df0f3  vmovaps [rsp+0x60], xmm7
00007767631df0f9  vmovaps [rsp+0x70], xmm8
00007767631df0ff  vmovaps [rsp+0x80], xmm9
00007767631df108  vmovaps [rsp+0x90], xmm10
00007767631df111  vmovaps [rsp+0xA0], xmm11
00007767631df11a  vmovaps [rsp+0xB0], xmm12
00007767631df123  vmovaps [rsp+0xC0], xmm13
00007767631df12c  vmovaps [rsp+0xD0], xmm14
00007767631df135  vmovaps [rsp+0xE0], xmm15
00007767631df13e  sub rsp, 0x30
00007767631df142  movaps [rsp], xmm1
00007767631df146  movaps [rsp+0x10], xmm15
00007767631df14c  movaps [rsp+0x20], xmm6
00007767631df151  lea rdi, [rsp]
00007767631df155  mov esi, 0x00
00007767631df15a  mov rax, 0x617961CDB530
00007767631df164  call rax
00007767631df166  movaps xmm1, [rsp]
00007767631df16a  add rsp, 0x30
00007767631df16e  vmovaps xmm0, [rsp]
00007767631df173  vmovaps xmm2, [rsp+0x10]
00007767631df179  vmovaps xmm3, [rsp+0x20]
00007767631df17f  vmovaps xmm4, [rsp+0x30]
00007767631df185  vmovaps xmm5, [rsp+0x40]
00007767631df18b  vmovaps xmm6, [rsp+0x50]
00007767631df191  vmovaps xmm7, [rsp+0x60]
00007767631df197  vmovaps xmm8, [rsp+0x70]
00007767631df19d  vmovaps xmm9, [rsp+0x80]
00007767631df1a6  vmovaps xmm10, [rsp+0x90]
00007767631df1af  vmovaps xmm11, [rsp+0xA0]
00007767631df1b8  vmovaps xmm12, [rsp+0xB0]
00007767631df1c1  vmovaps xmm13, [rsp+0xC0]
00007767631df1ca  vmovaps xmm14, [rsp+0xD0]
00007767631df1d3  vmovaps xmm15, [rsp+0xE0]
00007767631df1dc  add rsp, 0xF0
00007767631df1e3  pop r11
00007767631df1e5  pop r10
00007767631df1e7  pop r9
00007767631df1e9  pop r8
00007767631df1eb  pop rsi
00007767631df1ec  pop rdi
00007767631df1ed  pop rdx
00007767631df1ee  pop rcx
00007767631df1ef  pop rax
00007767631df1f0  add rsp, 0x08
00007767631df1f4  jmp 0x00007767631DC375
00007767631df1f9  sub rsp, 0x08
00007767631df1fd  push rax
00007767631df1fe  push rcx
00007767631df1ff  push rdx
00007767631df200  push rdi
00007767631df201  push rsi
00007767631df202  push r8
00007767631df204  push r9
00007767631df206  push r10
00007767631df208  push r11
00007767631df20a  sub rsp, 0xF0
00007767631df211  vmovaps [rsp], xmm0
00007767631df216  vmovaps [rsp+0x10], xmm1
00007767631df21c  vmovaps [rsp+0x20], xmm2
00007767631df222  vmovaps [rsp+0x30], xmm3
00007767631df228  vmovaps [rsp+0x40], xmm4
00007767631df22e  vmovaps [rsp+0x50], xmm5
00007767631df234  vmovaps [rsp+0x60], xmm6
00007767631df23a  vmovaps [rsp+0x70], xmm7
00007767631df240  vmovaps [rsp+0x80], xmm8
00007767631df249  vmovaps [rsp+0x90], xmm9
00007767631df252  vmovaps [rsp+0xA0], xmm10
00007767631df25b  vmovaps [rsp+0xB0], xmm11
00007767631df264  vmovaps [rsp+0xC0], xmm12
00007767631df26d  vmovaps [rsp+0xD0], xmm13
00007767631df276  vmovaps [rsp+0xE0], xmm14
00007767631df27f  sub rsp, 0x30
00007767631df283  movaps [rsp], xmm15
00007767631df288  movaps [rsp+0x10], xmm5
00007767631df28d  movaps [rsp+0x20], xmm3
00007767631df292  lea rdi, [rsp]
00007767631df296  mov esi, 0x00
00007767631df29b  mov rax, 0x617961CDB530
00007767631df2a5  call rax
00007767631df2a7  movaps xmm15, [rsp]
00007767631df2ac  add rsp, 0x30
00007767631df2b0  vmovaps xmm0, [rsp]
00007767631df2b5  vmovaps xmm1, [rsp+0x10]
00007767631df2bb  vmovaps xmm2, [rsp+0x20]
00007767631df2c1  vmovaps xmm3, [rsp+0x30]
00007767631df2c7  vmovaps xmm4, [rsp+0x40]
00007767631df2cd  vmovaps xmm5, [rsp+0x50]
00007767631df2d3  vmovaps xmm6, [rsp+0x60]
00007767631df2d9  vmovaps xmm7, [rsp+0x70]
00007767631df2df  vmovaps xmm8, [rsp+0x80]
00007767631df2e8  vmovaps xmm9, [rsp+0x90]
00007767631df2f1  vmovaps xmm10, [rsp+0xA0]
00007767631df2fa  vmovaps xmm11, [rsp+0xB0]
00007767631df303  vmovaps xmm12, [rsp+0xC0]
00007767631df30c  vmovaps xmm13, [rsp+0xD0]
00007767631df315  vmovaps xmm14, [rsp+0xE0]
00007767631df31e  add rsp, 0xF0
00007767631df325  pop r11
00007767631df327  pop r10
00007767631df329  pop r9
00007767631df32b  pop r8
00007767631df32d  pop rsi
00007767631df32e  pop rdi
00007767631df32f  pop rdx
00007767631df330  pop rcx
00007767631df331  pop rax
00007767631df332  add rsp, 0x08
00007767631df336  jmp 0x00007767631DC38F
00007767631df33b  sub rsp, 0x08
00007767631df33f  push rax
00007767631df340  push rcx
00007767631df341  push rdx
00007767631df342  push rdi
00007767631df343  push rsi
00007767631df344  push r8
00007767631df346  push r9
00007767631df348  push r10
00007767631df34a  push r11
00007767631df34c  sub rsp, 0xF0
00007767631df353  vmovaps [rsp], xmm0
00007767631df358  vmovaps [rsp+0x10], xmm1
00007767631df35e  vmovaps [rsp+0x20], xmm2
00007767631df364  vmovaps [rsp+0x30], xmm3
00007767631df36a  vmovaps [rsp+0x40], xmm4
00007767631df370  vmovaps [rsp+0x50], xmm6
00007767631df376  vmovaps [rsp+0x60], xmm7
00007767631df37c  vmovaps [rsp+0x70], xmm8
00007767631df382  vmovaps [rsp+0x80], xmm9
00007767631df38b  vmovaps [rsp+0x90], xmm10
00007767631df394  vmovaps [rsp+0xA0], xmm11
00007767631df39d  vmovaps [rsp+0xB0], xmm12
00007767631df3a6  vmovaps [rsp+0xC0], xmm13
00007767631df3af  vmovaps [rsp+0xD0], xmm14
00007767631df3b8  vmovaps [rsp+0xE0], xmm15
00007767631df3c1  sub rsp, 0x30
00007767631df3c5  movaps [rsp], xmm5
00007767631df3c9  movaps [rsp+0x10], xmm8
00007767631df3cf  movaps [rsp+0x20], xmm6
00007767631df3d4  lea rdi, [rsp]
00007767631df3d8  mov esi, 0x00
00007767631df3dd  mov rax, 0x617961CDB530
00007767631df3e7  call rax
00007767631df3e9  movaps xmm5, [rsp]
00007767631df3ed  add rsp, 0x30
00007767631df3f1  vmovaps xmm0, [rsp]
00007767631df3f6  vmovaps xmm1, [rsp+0x10]
00007767631df3fc  vmovaps xmm2, [rsp+0x20]
00007767631df402  vmovaps xmm3, [rsp+0x30]
00007767631df408  vmovaps xmm4, [rsp+0x40]
00007767631df40e  vmovaps xmm6, [rsp+0x50]
00007767631df414  vmovaps xmm7, [rsp+0x60]
00007767631df41a  vmovaps xmm8, [rsp+0x70]
00007767631df420  vmovaps xmm9, [rsp+0x80]
00007767631df429  vmovaps xmm10, [rsp+0x90]
00007767631df432  vmovaps xmm11, [rsp+0xA0]
00007767631df43b  vmovaps xmm12, [rsp+0xB0]
00007767631df444  vmovaps xmm13, [rsp+0xC0]
00007767631df44d  vmovaps xmm14, [rsp+0xD0]
00007767631df456  vmovaps xmm15, [rsp+0xE0]
00007767631df45f  add rsp, 0xF0
00007767631df466  pop r11
00007767631df468  pop r10
00007767631df46a  pop r9
00007767631df46c  pop r8
00007767631df46e  pop rsi
00007767631df46f  pop rdi
00007767631df470  pop rdx
00007767631df471  pop rcx
00007767631df472  pop rax
00007767631df473  add rsp, 0x08
00007767631df477  jmp 0x00007767631DC3B3
00007767631df47c  sub rsp, 0x08
00007767631df480  push rax
00007767631df481  push rcx
00007767631df482  push rdx
00007767631df483  push rdi
00007767631df484  push rsi
00007767631df485  push r8
00007767631df487  push r9
00007767631df489  push r10
00007767631df48b  push r11
00007767631df48d  sub rsp, 0xF0
00007767631df494  vmovaps [rsp], xmm0
00007767631df499  vmovaps [rsp+0x10], xmm1
00007767631df49f  vmovaps [rsp+0x20], xmm2
00007767631df4a5  vmovaps [rsp+0x30], xmm3
00007767631df4ab  vmovaps [rsp+0x40], xmm4
00007767631df4b1  vmovaps [rsp+0x50], xmm5
00007767631df4b7  vmovaps [rsp+0x60], xmm7
00007767631df4bd  vmovaps [rsp+0x70], xmm8
00007767631df4c3  vmovaps [rsp+0x80], xmm9
00007767631df4cc  vmovaps [rsp+0x90], xmm10
00007767631df4d5  vmovaps [rsp+0xA0], xmm11
00007767631df4de  vmovaps [rsp+0xB0], xmm12
00007767631df4e7  vmovaps [rsp+0xC0], xmm13
00007767631df4f0  vmovaps [rsp+0xD0], xmm14
00007767631df4f9  vmovaps [rsp+0xE0], xmm15
00007767631df502  sub rsp, 0x30
00007767631df506  movaps [rsp], xmm6
00007767631df50a  movaps [rsp+0x10], xmm10
00007767631df510  movaps [rsp+0x20], xmm8
00007767631df516  lea rdi, [rsp]
00007767631df51a  mov esi, 0x00
00007767631df51f  mov rax, 0x617961CDB530
00007767631df529  call rax
00007767631df52b  movaps xmm6, [rsp]
00007767631df52f  add rsp, 0x30
00007767631df533  vmovaps xmm0, [rsp]
00007767631df538  vmovaps xmm1, [rsp+0x10]
00007767631df53e  vmovaps xmm2, [rsp+0x20]
00007767631df544  vmovaps xmm3, [rsp+0x30]
00007767631df54a  vmovaps xmm4, [rsp+0x40]
00007767631df550  vmovaps xmm5, [rsp+0x50]
00007767631df556  vmovaps xmm7, [rsp+0x60]
00007767631df55c  vmovaps xmm8, [rsp+0x70]
00007767631df562  vmovaps xmm9, [rsp+0x80]
00007767631df56b  vmovaps xmm10, [rsp+0x90]
00007767631df574  vmovaps xmm11, [rsp+0xA0]
00007767631df57d  vmovaps xmm12, [rsp+0xB0]
00007767631df586  vmovaps xmm13, [rsp+0xC0]
00007767631df58f  vmovaps xmm14, [rsp+0xD0]
00007767631df598  vmovaps xmm15, [rsp+0xE0]
00007767631df5a1  add rsp, 0xF0
00007767631df5a8  pop r11
00007767631df5aa  pop r10
00007767631df5ac  pop r9
00007767631df5ae  pop r8
00007767631df5b0  pop rsi
00007767631df5b1  pop rdi
00007767631df5b2  pop rdx
00007767631df5b3  pop rcx
00007767631df5b4  pop rax
00007767631df5b5  add rsp, 0x08
00007767631df5b9  jmp 0x00007767631DC3D8
00007767631df5be  sub rsp, 0x08
00007767631df5c2  push rax
00007767631df5c3  push rcx
00007767631df5c4  push rdx
00007767631df5c5  push rdi
00007767631df5c6  push rsi
00007767631df5c7  push r8
00007767631df5c9  push r9
00007767631df5cb  push r10
00007767631df5cd  push r11
00007767631df5cf  sub rsp, 0xF0
00007767631df5d6  vmovaps [rsp], xmm0
00007767631df5db  vmovaps [rsp+0x10], xmm1
00007767631df5e1  vmovaps [rsp+0x20], xmm2
00007767631df5e7  vmovaps [rsp+0x30], xmm3
00007767631df5ed  vmovaps [rsp+0x40], xmm4
00007767631df5f3  vmovaps [rsp+0x50], xmm5
00007767631df5f9  vmovaps [rsp+0x60], xmm6
00007767631df5ff  vmovaps [rsp+0x70], xmm7
00007767631df605  vmovaps [rsp+0x80], xmm8
00007767631df60e  vmovaps [rsp+0x90], xmm9
00007767631df617  vmovaps [rsp+0xA0], xmm11
00007767631df620  vmovaps [rsp+0xB0], xmm12
00007767631df629  vmovaps [rsp+0xC0], xmm13
00007767631df632  vmovaps [rsp+0xD0], xmm14
00007767631df63b  vmovaps [rsp+0xE0], xmm15
00007767631df644  sub rsp, 0x30
00007767631df648  movaps [rsp], xmm10
00007767631df64d  movaps [rsp+0x10], xmm8
00007767631df653  movaps [rsp+0x20], xmm14
00007767631df659  lea rdi, [rsp]
00007767631df65d  mov esi, 0x00
00007767631df662  mov rax, 0x617961CDB530
00007767631df66c  call rax
00007767631df66e  movaps xmm10, [rsp]
00007767631df673  add rsp, 0x30
00007767631df677  vmovaps xmm0, [rsp]
00007767631df67c  vmovaps xmm1, [rsp+0x10]
00007767631df682  vmovaps xmm2, [rsp+0x20]
00007767631df688  vmovaps xmm3, [rsp+0x30]
00007767631df68e  vmovaps xmm4, [rsp+0x40]
00007767631df694  vmovaps xmm5, [rsp+0x50]
00007767631df69a  vmovaps xmm6, [rsp+0x60]
00007767631df6a0  vmovaps xmm7, [rsp+0x70]
00007767631df6a6  vmovaps xmm8, [rsp+0x80]
00007767631df6af  vmovaps xmm9, [rsp+0x90]
00007767631df6b8  vmovaps xmm11, [rsp+0xA0]
00007767631df6c1  vmovaps xmm12, [rsp+0xB0]
00007767631df6ca  vmovaps xmm13, [rsp+0xC0]
00007767631df6d3  vmovaps xmm14, [rsp+0xD0]
00007767631df6dc  vmovaps xmm15, [rsp+0xE0]
00007767631df6e5  add rsp, 0xF0
00007767631df6ec  pop r11
00007767631df6ee  pop r10
00007767631df6f0  pop r9
00007767631df6f2  pop r8
00007767631df6f4  pop rsi
00007767631df6f5  pop rdi
00007767631df6f6  pop rdx
00007767631df6f7  pop rcx
00007767631df6f8  pop rax
00007767631df6f9  add rsp, 0x08
00007767631df6fd  jmp 0x00007767631DC3F8
00007767631df702  sub rsp, 0x08
00007767631df706  push rax
00007767631df707  push rcx
00007767631df708  push rdx
00007767631df709  push rdi
00007767631df70a  push rsi
00007767631df70b  push r8
00007767631df70d  push r9
00007767631df70f  push r10
00007767631df711  push r11
00007767631df713  sub rsp, 0xF0
00007767631df71a  vmovaps [rsp], xmm0
00007767631df71f  vmovaps [rsp+0x10], xmm1
00007767631df725  vmovaps [rsp+0x20], xmm2
00007767631df72b  vmovaps [rsp+0x30], xmm3
00007767631df731  vmovaps [rsp+0x40], xmm4
00007767631df737  vmovaps [rsp+0x50], xmm5
00007767631df73d  vmovaps [rsp+0x60], xmm6
00007767631df743  vmovaps [rsp+0x70], xmm7
00007767631df749  vmovaps [rsp+0x80], xmm8
00007767631df752  vmovaps [rsp+0x90], xmm9
00007767631df75b  vmovaps [rsp+0xA0], xmm10
00007767631df764  vmovaps [rsp+0xB0], xmm11
00007767631df76d  vmovaps [rsp+0xC0], xmm12
00007767631df776  vmovaps [rsp+0xD0], xmm13
00007767631df77f  vmovaps [rsp+0xE0], xmm15
00007767631df788  sub rsp, 0x30
00007767631df78c  movaps [rsp], xmm14
00007767631df791  movaps [rsp+0x10], xmm8
00007767631df797  movaps [rsp+0x20], xmm4
00007767631df79c  lea rdi, [rsp]
00007767631df7a0  mov esi, 0x00
00007767631df7a5  mov rax, 0x617961CDB530
00007767631df7af  call rax
00007767631df7b1  movaps xmm14, [rsp]
00007767631df7b6  add rsp, 0x30
00007767631df7ba  vmovaps xmm0, [rsp]
00007767631df7bf  vmovaps xmm1, [rsp+0x10]
00007767631df7c5  vmovaps xmm2, [rsp+0x20]
00007767631df7cb  vmovaps xmm3, [rsp+0x30]
00007767631df7d1  vmovaps xmm4, [rsp+0x40]
00007767631df7d7  vmovaps xmm5, [rsp+0x50]
00007767631df7dd  vmovaps xmm6, [rsp+0x60]
00007767631df7e3  vmovaps xmm7, [rsp+0x70]
00007767631df7e9  vmovaps xmm8, [rsp+0x80]
00007767631df7f2  vmovaps xmm9, [rsp+0x90]
00007767631df7fb  vmovaps xmm10, [rsp+0xA0]
00007767631df804  vmovaps xmm11, [rsp+0xB0]
00007767631df80d  vmovaps xmm12, [rsp+0xC0]
00007767631df816  vmovaps xmm13, [rsp+0xD0]
00007767631df81f  vmovaps xmm15, [rsp+0xE0]
00007767631df828  add rsp, 0xF0
00007767631df82f  pop r11
00007767631df831  pop r10
00007767631df833  pop r9
00007767631df835  pop r8
00007767631df837  pop rsi
00007767631df838  pop rdi
00007767631df839  pop rdx
00007767631df83a  pop rcx
00007767631df83b  pop rax
00007767631df83c  add rsp, 0x08
00007767631df840  jmp 0x00007767631DC418
00007767631df845  sub rsp, 0x08
00007767631df849  push rax
00007767631df84a  push rcx
00007767631df84b  push rdx
00007767631df84c  push rdi
00007767631df84d  push rsi
00007767631df84e  push r8
00007767631df850  push r9
00007767631df852  push r10
00007767631df854  push r11
00007767631df856  sub rsp, 0xF0
00007767631df85d  vmovaps [rsp], xmm0
00007767631df862  vmovaps [rsp+0x10], xmm1
00007767631df868  vmovaps [rsp+0x20], xmm2
00007767631df86e  vmovaps [rsp+0x30], xmm3
00007767631df874  vmovaps [rsp+0x40], xmm5
00007767631df87a  vmovaps [rsp+0x50], xmm6
00007767631df880  vmovaps [rsp+0x60], xmm7
00007767631df886  vmovaps [rsp+0x70], xmm8
00007767631df88c  vmovaps [rsp+0x80], xmm9
00007767631df895  vmovaps [rsp+0x90], xmm10
00007767631df89e  vmovaps [rsp+0xA0], xmm11
00007767631df8a7  vmovaps [rsp+0xB0], xmm12
00007767631df8b0  vmovaps [rsp+0xC0], xmm13
00007767631df8b9  vmovaps [rsp+0xD0], xmm14
00007767631df8c2  vmovaps [rsp+0xE0], xmm15
00007767631df8cb  sub rsp, 0x30
00007767631df8cf  movaps [rsp], xmm4
00007767631df8d3  movaps [rsp+0x10], xmm13
00007767631df8d9  movaps [rsp+0x20], xmm8
00007767631df8df  lea rdi, [rsp]
00007767631df8e3  mov esi, 0x00
00007767631df8e8  mov rax, 0x617961CDB530
00007767631df8f2  call rax
00007767631df8f4  movaps xmm4, [rsp]
00007767631df8f8  add rsp, 0x30
00007767631df8fc  vmovaps xmm0, [rsp]
00007767631df901  vmovaps xmm1, [rsp+0x10]
00007767631df907  vmovaps xmm2, [rsp+0x20]
00007767631df90d  vmovaps xmm3, [rsp+0x30]
00007767631df913  vmovaps xmm5, [rsp+0x40]
00007767631df919  vmovaps xmm6, [rsp+0x50]
00007767631df91f  vmovaps xmm7, [rsp+0x60]
00007767631df925  vmovaps xmm8, [rsp+0x70]
00007767631df92b  vmovaps xmm9, [rsp+0x80]
00007767631df934  vmovaps xmm10, [rsp+0x90]
00007767631df93d  vmovaps xmm11, [rsp+0xA0]
00007767631df946  vmovaps xmm12, [rsp+0xB0]
00007767631df94f  vmovaps xmm13, [rsp+0xC0]
00007767631df958  vmovaps xmm14, [rsp+0xD0]
00007767631df961  vmovaps xmm15, [rsp+0xE0]
00007767631df96a  add rsp, 0xF0
00007767631df971  pop r11
00007767631df973  pop r10
00007767631df975  pop r9
00007767631df977  pop r8
00007767631df979  pop rsi
00007767631df97a  pop rdi
00007767631df97b  pop rdx
00007767631df97c  pop rcx
00007767631df97d  pop rax
00007767631df97e  add rsp, 0x08
00007767631df982  jmp 0x00007767631DC43D
00007767631df987  sub rsp, 0x08
00007767631df98b  push rax
00007767631df98c  push rcx
00007767631df98d  push rdx
00007767631df98e  push rdi
00007767631df98f  push rsi
00007767631df990  push r8
00007767631df992  push r9
00007767631df994  push r10
00007767631df996  push r11
00007767631df998  sub rsp, 0xF0
00007767631df99f  vmovaps [rsp], xmm0
00007767631df9a4  vmovaps [rsp+0x10], xmm1
00007767631df9aa  vmovaps [rsp+0x20], xmm2
00007767631df9b0  vmovaps [rsp+0x30], xmm3
00007767631df9b6  vmovaps [rsp+0x40], xmm4
00007767631df9bc  vmovaps [rsp+0x50], xmm5
00007767631df9c2  vmovaps [rsp+0x60], xmm6
00007767631df9c8  vmovaps [rsp+0x70], xmm7
00007767631df9ce  vmovaps [rsp+0x80], xmm8
00007767631df9d7  vmovaps [rsp+0x90], xmm9
00007767631df9e0  vmovaps [rsp+0xA0], xmm10
00007767631df9e9  vmovaps [rsp+0xB0], xmm11
00007767631df9f2  vmovaps [rsp+0xC0], xmm12
00007767631df9fb  vmovaps [rsp+0xD0], xmm14
00007767631dfa04  vmovaps [rsp+0xE0], xmm15
00007767631dfa0d  sub rsp, 0x30
00007767631dfa11  movaps [rsp], xmm13
00007767631dfa16  movaps [rsp+0x10], xmm15
00007767631dfa1c  movaps [rsp+0x20], xmm9
00007767631dfa22  lea rdi, [rsp]
00007767631dfa26  mov esi, 0x00
00007767631dfa2b  mov rax, 0x617961CDB530
00007767631dfa35  call rax
00007767631dfa37  movaps xmm13, [rsp]
00007767631dfa3c  add rsp, 0x30
00007767631dfa40  vmovaps xmm0, [rsp]
00007767631dfa45  vmovaps xmm1, [rsp+0x10]
00007767631dfa4b  vmovaps xmm2, [rsp+0x20]
00007767631dfa51  vmovaps xmm3, [rsp+0x30]
00007767631dfa57  vmovaps xmm4, [rsp+0x40]
00007767631dfa5d  vmovaps xmm5, [rsp+0x50]
00007767631dfa63  vmovaps xmm6, [rsp+0x60]
00007767631dfa69  vmovaps xmm7, [rsp+0x70]
00007767631dfa6f  vmovaps xmm8, [rsp+0x80]
00007767631dfa78  vmovaps xmm9, [rsp+0x90]
00007767631dfa81  vmovaps xmm10, [rsp+0xA0]
00007767631dfa8a  vmovaps xmm11, [rsp+0xB0]
00007767631dfa93  vmovaps xmm12, [rsp+0xC0]
00007767631dfa9c  vmovaps xmm14, [rsp+0xD0]
00007767631dfaa5  vmovaps xmm15, [rsp+0xE0]
00007767631dfaae  add rsp, 0xF0
00007767631dfab5  pop r11
00007767631dfab7  pop r10
00007767631dfab9  pop r9
00007767631dfabb  pop r8
00007767631dfabd  pop rsi
00007767631dfabe  pop rdi
00007767631dfabf  pop rdx
00007767631dfac0  pop rcx
00007767631dfac1  pop rax
00007767631dfac2  add rsp, 0x08
00007767631dfac6  jmp 0x00007767631DC458
00007767631dfacb  sub rsp, 0x08
00007767631dfacf  push rax
00007767631dfad0  push rcx
00007767631dfad1  push rdx
00007767631dfad2  push rdi
00007767631dfad3  push rsi
00007767631dfad4  push r8
00007767631dfad6  push r9
00007767631dfad8  push r10
00007767631dfada  push r11
00007767631dfadc  sub rsp, 0xF0
00007767631dfae3  vmovaps [rsp], xmm0
00007767631dfae8  vmovaps [rsp+0x10], xmm1
00007767631dfaee  vmovaps [rsp+0x20], xmm2
00007767631dfaf4  vmovaps [rsp+0x30], xmm3
00007767631dfafa  vmovaps [rsp+0x40], xmm4
00007767631dfb00  vmovaps [rsp+0x50], xmm5
00007767631dfb06  vmovaps [rsp+0x60], xmm6
00007767631dfb0c  vmovaps [rsp+0x70], xmm7
00007767631dfb12  vmovaps [rsp+0x80], xmm8
00007767631dfb1b  vmovaps [rsp+0x90], xmm9
00007767631dfb24  vmovaps [rsp+0xA0], xmm10
00007767631dfb2d  vmovaps [rsp+0xB0], xmm11
00007767631dfb36  vmovaps [rsp+0xC0], xmm12
00007767631dfb3f  vmovaps [rsp+0xD0], xmm13
00007767631dfb48  vmovaps [rsp+0xE0], xmm14
00007767631dfb51  sub rsp, 0x30
00007767631dfb55  movaps [rsp], xmm15
00007767631dfb5a  movaps [rsp+0x10], xmm1
00007767631dfb5f  movaps [rsp+0x20], xmm5
00007767631dfb64  lea rdi, [rsp]
00007767631dfb68  mov esi, 0x00
00007767631dfb6d  mov rax, 0x617961CDB530
00007767631dfb77  call rax
00007767631dfb79  movaps xmm15, [rsp]
00007767631dfb7e  add rsp, 0x30
00007767631dfb82  vmovaps xmm0, [rsp]
00007767631dfb87  vmovaps xmm1, [rsp+0x10]
00007767631dfb8d  vmovaps xmm2, [rsp+0x20]
00007767631dfb93  vmovaps xmm3, [rsp+0x30]
00007767631dfb99  vmovaps xmm4, [rsp+0x40]
00007767631dfb9f  vmovaps xmm5, [rsp+0x50]
00007767631dfba5  vmovaps xmm6, [rsp+0x60]
00007767631dfbab  vmovaps xmm7, [rsp+0x70]
00007767631dfbb1  vmovaps xmm8, [rsp+0x80]
00007767631dfbba  vmovaps xmm9, [rsp+0x90]
00007767631dfbc3  vmovaps xmm10, [rsp+0xA0]
00007767631dfbcc  vmovaps xmm11, [rsp+0xB0]
00007767631dfbd5  vmovaps xmm12, [rsp+0xC0]
00007767631dfbde  vmovaps xmm13, [rsp+0xD0]
00007767631dfbe7  vmovaps xmm14, [rsp+0xE0]
00007767631dfbf0  add rsp, 0xF0
00007767631dfbf7  pop r11
00007767631dfbf9  pop r10
00007767631dfbfb  pop r9
00007767631dfbfd  pop r8
00007767631dfbff  pop rsi
00007767631dfc00  pop rdi
00007767631dfc01  pop rdx
00007767631dfc02  pop rcx
00007767631dfc03  pop rax
00007767631dfc04  add rsp, 0x08
00007767631dfc08  jmp 0x00007767631DC473
00007767631dfc0d  call 0x00007767630B52F0
00007767631dfc12  jmp 0x00007767631DC4CE
00007767631dfc17  sub rsp, 0x08
00007767631dfc1b  push rax
00007767631dfc1c  push rcx
00007767631dfc1d  push rdx
00007767631dfc1e  push rdi
00007767631dfc1f  push rsi
00007767631dfc20  push r8
00007767631dfc22  push r9
00007767631dfc24  push r10
00007767631dfc26  push r11
00007767631dfc28  sub rsp, 0xF0
00007767631dfc2f  vmovaps [rsp], xmm0
00007767631dfc34  vmovaps [rsp+0x10], xmm1
00007767631dfc3a  vmovaps [rsp+0x20], xmm2
00007767631dfc40  vmovaps [rsp+0x30], xmm3
00007767631dfc46  vmovaps [rsp+0x40], xmm4
00007767631dfc4c  vmovaps [rsp+0x50], xmm5
00007767631dfc52  vmovaps [rsp+0x60], xmm6
00007767631dfc58  vmovaps [rsp+0x70], xmm7
00007767631dfc5e  vmovaps [rsp+0x80], xmm8
00007767631dfc67  vmovaps [rsp+0x90], xmm10
00007767631dfc70  vmovaps [rsp+0xA0], xmm11
00007767631dfc79  vmovaps [rsp+0xB0], xmm12
00007767631dfc82  vmovaps [rsp+0xC0], xmm13
00007767631dfc8b  vmovaps [rsp+0xD0], xmm14
00007767631dfc94  vmovaps [rsp+0xE0], xmm15
00007767631dfc9d  sub rsp, 0x30
00007767631dfca1  movaps [rsp], xmm9
00007767631dfca6  movaps [rsp+0x10], xmm8
00007767631dfcac  movaps [rsp+0x20], xmm11
00007767631dfcb2  lea rdi, [rsp]
00007767631dfcb6  mov esi, 0x00
00007767631dfcbb  mov rax, 0x617961CDB530
00007767631dfcc5  call rax
00007767631dfcc7  movaps xmm9, [rsp]
00007767631dfccc  add rsp, 0x30
00007767631dfcd0  vmovaps xmm0, [rsp]
00007767631dfcd5  vmovaps xmm1, [rsp+0x10]
00007767631dfcdb  vmovaps xmm2, [rsp+0x20]
00007767631dfce1  vmovaps xmm3, [rsp+0x30]
00007767631dfce7  vmovaps xmm4, [rsp+0x40]
00007767631dfced  vmovaps xmm5, [rsp+0x50]
00007767631dfcf3  vmovaps xmm6, [rsp+0x60]
00007767631dfcf9  vmovaps xmm7, [rsp+0x70]
00007767631dfcff  vmovaps xmm8, [rsp+0x80]
00007767631dfd08  vmovaps xmm10, [rsp+0x90]
00007767631dfd11  vmovaps xmm11, [rsp+0xA0]
00007767631dfd1a  vmovaps xmm12, [rsp+0xB0]
00007767631dfd23  vmovaps xmm13, [rsp+0xC0]
00007767631dfd2c  vmovaps xmm14, [rsp+0xD0]
00007767631dfd35  vmovaps xmm15, [rsp+0xE0]
00007767631dfd3e  add rsp, 0xF0
00007767631dfd45  pop r11
00007767631dfd47  pop r10
00007767631dfd49  pop r9
00007767631dfd4b  pop r8
00007767631dfd4d  pop rsi
00007767631dfd4e  pop rdi
00007767631dfd4f  pop rdx
00007767631dfd50  pop rcx
00007767631dfd51  pop rax
00007767631dfd52  add rsp, 0x08
00007767631dfd56  jmp 0x00007767631DC505
00007767631dfd5b  sub rsp, 0x08
00007767631dfd5f  push rax
00007767631dfd60  push rcx
00007767631dfd61  push rdx
00007767631dfd62  push rdi
00007767631dfd63  push rsi
00007767631dfd64  push r8
00007767631dfd66  push r9
00007767631dfd68  push r10
00007767631dfd6a  push r11
00007767631dfd6c  sub rsp, 0xF0
00007767631dfd73  vmovaps [rsp], xmm0
00007767631dfd78  vmovaps [rsp+0x10], xmm1
00007767631dfd7e  vmovaps [rsp+0x20], xmm2
00007767631dfd84  vmovaps [rsp+0x30], xmm3
00007767631dfd8a  vmovaps [rsp+0x40], xmm4
00007767631dfd90  vmovaps [rsp+0x50], xmm5
00007767631dfd96  vmovaps [rsp+0x60], xmm6
00007767631dfd9c  vmovaps [rsp+0x70], xmm7
00007767631dfda2  vmovaps [rsp+0x80], xmm8
00007767631dfdab  vmovaps [rsp+0x90], xmm9
00007767631dfdb4  vmovaps [rsp+0xA0], xmm10
00007767631dfdbd  vmovaps [rsp+0xB0], xmm12
00007767631dfdc6  vmovaps [rsp+0xC0], xmm13
00007767631dfdcf  vmovaps [rsp+0xD0], xmm14
00007767631dfdd8  vmovaps [rsp+0xE0], xmm15
00007767631dfde1  sub rsp, 0x30
00007767631dfde5  movaps [rsp], xmm11
00007767631dfdea  movaps [rsp+0x10], xmm10
00007767631dfdf0  movaps [rsp+0x20], xmm6
00007767631dfdf5  lea rdi, [rsp]
00007767631dfdf9  mov esi, 0x00
00007767631dfdfe  mov rax, 0x617961CDB530
00007767631dfe08  call rax
00007767631dfe0a  movaps xmm11, [rsp]
00007767631dfe0f  add rsp, 0x30
00007767631dfe13  vmovaps xmm0, [rsp]
00007767631dfe18  vmovaps xmm1, [rsp+0x10]
00007767631dfe1e  vmovaps xmm2, [rsp+0x20]
00007767631dfe24  vmovaps xmm3, [rsp+0x30]
00007767631dfe2a  vmovaps xmm4, [rsp+0x40]
00007767631dfe30  vmovaps xmm5, [rsp+0x50]
00007767631dfe36  vmovaps xmm6, [rsp+0x60]
00007767631dfe3c  vmovaps xmm7, [rsp+0x70]
00007767631dfe42  vmovaps xmm8, [rsp+0x80]
00007767631dfe4b  vmovaps xmm9, [rsp+0x90]
00007767631dfe54  vmovaps xmm10, [rsp+0xA0]
00007767631dfe5d  vmovaps xmm12, [rsp+0xB0]
00007767631dfe66  vmovaps xmm13, [rsp+0xC0]
00007767631dfe6f  vmovaps xmm14, [rsp+0xD0]
00007767631dfe78  vmovaps xmm15, [rsp+0xE0]
00007767631dfe81  add rsp, 0xF0
00007767631dfe88  pop r11
00007767631dfe8a  pop r10
00007767631dfe8c  pop r9
00007767631dfe8e  pop r8
00007767631dfe90  pop rsi
00007767631dfe91  pop rdi
00007767631dfe92  pop rdx
00007767631dfe93  pop rcx
00007767631dfe94  pop rax
00007767631dfe95  add rsp, 0x08
00007767631dfe99  jmp 0x00007767631DC520
00007767631dfe9e  sub rsp, 0x08
00007767631dfea2  push rax
00007767631dfea3  push rcx
00007767631dfea4  push rdx
00007767631dfea5  push rdi
00007767631dfea6  push rsi
00007767631dfea7  push r8
00007767631dfea9  push r9
00007767631dfeab  push r10
00007767631dfead  push r11
00007767631dfeaf  sub rsp, 0xF0
00007767631dfeb6  vmovaps [rsp], xmm0
00007767631dfebb  vmovaps [rsp+0x10], xmm1
00007767631dfec1  vmovaps [rsp+0x20], xmm2
00007767631dfec7  vmovaps [rsp+0x30], xmm3
00007767631dfecd  vmovaps [rsp+0x40], xmm4
00007767631dfed3  vmovaps [rsp+0x50], xmm5
00007767631dfed9  vmovaps [rsp+0x60], xmm6
00007767631dfedf  vmovaps [rsp+0x70], xmm7
00007767631dfee5  vmovaps [rsp+0x80], xmm8
00007767631dfeee  vmovaps [rsp+0x90], xmm9
00007767631dfef7  vmovaps [rsp+0xA0], xmm11
00007767631dff00  vmovaps [rsp+0xB0], xmm12
00007767631dff09  vmovaps [rsp+0xC0], xmm13
00007767631dff12  vmovaps [rsp+0xD0], xmm14
00007767631dff1b  vmovaps [rsp+0xE0], xmm15
00007767631dff24  sub rsp, 0x30
00007767631dff28  movaps [rsp], xmm10
00007767631dff2d  movaps [rsp+0x10], xmm14
00007767631dff33  movaps [rsp+0x20], xmm4
00007767631dff38  lea rdi, [rsp]
00007767631dff3c  mov esi, 0x00
00007767631dff41  mov rax, 0x617961CDB530
00007767631dff4b  call rax
00007767631dff4d  movaps xmm10, [rsp]
00007767631dff52  add rsp, 0x30
00007767631dff56  vmovaps xmm0, [rsp]
00007767631dff5b  vmovaps xmm1, [rsp+0x10]
00007767631dff61  vmovaps xmm2, [rsp+0x20]
00007767631dff67  vmovaps xmm3, [rsp+0x30]
00007767631dff6d  vmovaps xmm4, [rsp+0x40]
00007767631dff73  vmovaps xmm5, [rsp+0x50]
00007767631dff79  vmovaps xmm6, [rsp+0x60]
00007767631dff7f  vmovaps xmm7, [rsp+0x70]
00007767631dff85  vmovaps xmm8, [rsp+0x80]
00007767631dff8e  vmovaps xmm9, [rsp+0x90]
00007767631dff97  vmovaps xmm11, [rsp+0xA0]
00007767631dffa0  vmovaps xmm12, [rsp+0xB0]
00007767631dffa9  vmovaps xmm13, [rsp+0xC0]
00007767631dffb2  vmovaps xmm14, [rsp+0xD0]
00007767631dffbb  vmovaps xmm15, [rsp+0xE0]
00007767631dffc4  add rsp, 0xF0
00007767631dffcb  pop r11
00007767631dffcd  pop r10
00007767631dffcf  pop r9
00007767631dffd1  pop r8
00007767631dffd3  pop rsi
00007767631dffd4  pop rdi
00007767631dffd5  pop rdx
00007767631dffd6  pop rcx
00007767631dffd7  pop rax
00007767631dffd8  add rsp, 0x08
00007767631dffdc  jmp 0x00007767631DC53B
00007767631dffe1  sub rsp, 0x08
00007767631dffe5  push rax
00007767631dffe6  push rcx
00007767631dffe7  push rdx
00007767631dffe8  push rdi
00007767631dffe9  push rsi
00007767631dffea  push r8
00007767631dffec  push r9
00007767631dffee  push r10
00007767631dfff0  push r11
00007767631dfff2  sub rsp, 0xF0
00007767631dfff9  vmovaps [rsp], xmm0
00007767631dfffe  vmovaps [rsp+0x10], xmm1
00007767631e0004  vmovaps [rsp+0x20], xmm2
00007767631e000a  vmovaps [rsp+0x30], xmm3
00007767631e0010  vmovaps [rsp+0x40], xmm4
00007767631e0016  vmovaps [rsp+0x50], xmm5
00007767631e001c  vmovaps [rsp+0x60], xmm6
00007767631e0022  vmovaps [rsp+0x70], xmm7
00007767631e0028  vmovaps [rsp+0x80], xmm9
00007767631e0031  vmovaps [rsp+0x90], xmm10
00007767631e003a  vmovaps [rsp+0xA0], xmm11
00007767631e0043  vmovaps [rsp+0xB0], xmm12
00007767631e004c  vmovaps [rsp+0xC0], xmm13
00007767631e0055  vmovaps [rsp+0xD0], xmm14
00007767631e005e  vmovaps [rsp+0xE0], xmm15
00007767631e0067  sub rsp, 0x30
00007767631e006b  movaps [rsp], xmm8
00007767631e0070  movaps [rsp+0x10], xmm1
00007767631e0075  movaps [rsp+0x20], xmm14
00007767631e007b  lea rdi, [rsp]
00007767631e007f  mov esi, 0x00
00007767631e0084  mov rax, 0x617961CDB530
00007767631e008e  call rax
00007767631e0090  movaps xmm8, [rsp]
00007767631e0095  add rsp, 0x30
00007767631e0099  vmovaps xmm0, [rsp]
00007767631e009e  vmovaps xmm1, [rsp+0x10]
00007767631e00a4  vmovaps xmm2, [rsp+0x20]
00007767631e00aa  vmovaps xmm3, [rsp+0x30]
00007767631e00b0  vmovaps xmm4, [rsp+0x40]
00007767631e00b6  vmovaps xmm5, [rsp+0x50]
00007767631e00bc  vmovaps xmm6, [rsp+0x60]
00007767631e00c2  vmovaps xmm7, [rsp+0x70]
00007767631e00c8  vmovaps xmm9, [rsp+0x80]
00007767631e00d1  vmovaps xmm10, [rsp+0x90]
00007767631e00da  vmovaps xmm11, [rsp+0xA0]
00007767631e00e3  vmovaps xmm12, [rsp+0xB0]
00007767631e00ec  vmovaps xmm13, [rsp+0xC0]
00007767631e00f5  vmovaps xmm14, [rsp+0xD0]
00007767631e00fe  vmovaps xmm15, [rsp+0xE0]
00007767631e0107  add rsp, 0xF0
00007767631e010e  pop r11
00007767631e0110  pop r10
00007767631e0112  pop r9
00007767631e0114  pop r8
00007767631e0116  pop rsi
00007767631e0117  pop rdi
00007767631e0118  pop rdx
00007767631e0119  pop rcx
00007767631e011a  pop rax
00007767631e011b  add rsp, 0x08
00007767631e011f  jmp 0x00007767631DC561
00007767631e0124  sub rsp, 0x08
00007767631e0128  push rax
00007767631e0129  push rcx
00007767631e012a  push rdx
00007767631e012b  push rdi
00007767631e012c  push rsi
00007767631e012d  push r8
00007767631e012f  push r9
00007767631e0131  push r10
00007767631e0133  push r11
00007767631e0135  sub rsp, 0xF0
00007767631e013c  vmovaps [rsp], xmm0
00007767631e0141  vmovaps [rsp+0x10], xmm1
00007767631e0147  vmovaps [rsp+0x20], xmm2
00007767631e014d  vmovaps [rsp+0x30], xmm3
00007767631e0153  vmovaps [rsp+0x40], xmm4
00007767631e0159  vmovaps [rsp+0x50], xmm5
00007767631e015f  vmovaps [rsp+0x60], xmm7
00007767631e0165  vmovaps [rsp+0x70], xmm8
00007767631e016b  vmovaps [rsp+0x80], xmm9
00007767631e0174  vmovaps [rsp+0x90], xmm10
00007767631e017d  vmovaps [rsp+0xA0], xmm11
00007767631e0186  vmovaps [rsp+0xB0], xmm12
00007767631e018f  vmovaps [rsp+0xC0], xmm13
00007767631e0198  vmovaps [rsp+0xD0], xmm14
00007767631e01a1  vmovaps [rsp+0xE0], xmm15
00007767631e01aa  sub rsp, 0x30
00007767631e01ae  movaps [rsp], xmm6
00007767631e01b2  movaps [rsp+0x10], xmm1
00007767631e01b7  movaps [rsp+0x20], xmm14
00007767631e01bd  lea rdi, [rsp]
00007767631e01c1  mov esi, 0x00
00007767631e01c6  mov rax, 0x617961CDB530
00007767631e01d0  call rax
00007767631e01d2  movaps xmm6, [rsp]
00007767631e01d6  add rsp, 0x30
00007767631e01da  vmovaps xmm0, [rsp]
00007767631e01df  vmovaps xmm1, [rsp+0x10]
00007767631e01e5  vmovaps xmm2, [rsp+0x20]
00007767631e01eb  vmovaps xmm3, [rsp+0x30]
00007767631e01f1  vmovaps xmm4, [rsp+0x40]
00007767631e01f7  vmovaps xmm5, [rsp+0x50]
00007767631e01fd  vmovaps xmm7, [rsp+0x60]
00007767631e0203  vmovaps xmm8, [rsp+0x70]
00007767631e0209  vmovaps xmm9, [rsp+0x80]
00007767631e0212  vmovaps xmm10, [rsp+0x90]
00007767631e021b  vmovaps xmm11, [rsp+0xA0]
00007767631e0224  vmovaps xmm12, [rsp+0xB0]
00007767631e022d  vmovaps xmm13, [rsp+0xC0]
00007767631e0236  vmovaps xmm14, [rsp+0xD0]
00007767631e023f  vmovaps xmm15, [rsp+0xE0]
00007767631e0248  add rsp, 0xF0
00007767631e024f  pop r11
00007767631e0251  pop r10
00007767631e0253  pop r9
00007767631e0255  pop r8
00007767631e0257  pop rsi
00007767631e0258  pop rdi
00007767631e0259  pop rdx
00007767631e025a  pop rcx
00007767631e025b  pop rax
00007767631e025c  add rsp, 0x08
00007767631e0260  jmp 0x00007767631DC58D
00007767631e0265  sub rsp, 0x08
00007767631e0269  push rax
00007767631e026a  push rcx
00007767631e026b  push rdx
00007767631e026c  push rdi
00007767631e026d  push rsi
00007767631e026e  push r8
00007767631e0270  push r9
00007767631e0272  push r10
00007767631e0274  push r11
00007767631e0276  sub rsp, 0xF0
00007767631e027d  vmovaps [rsp], xmm0
00007767631e0282  vmovaps [rsp+0x10], xmm1
00007767631e0288  vmovaps [rsp+0x20], xmm2
00007767631e028e  vmovaps [rsp+0x30], xmm3
00007767631e0294  vmovaps [rsp+0x40], xmm4
00007767631e029a  vmovaps [rsp+0x50], xmm5
00007767631e02a0  vmovaps [rsp+0x60], xmm6
00007767631e02a6  vmovaps [rsp+0x70], xmm7
00007767631e02ac  vmovaps [rsp+0x80], xmm8
00007767631e02b5  vmovaps [rsp+0x90], xmm9
00007767631e02be  vmovaps [rsp+0xA0], xmm10
00007767631e02c7  vmovaps [rsp+0xB0], xmm11
00007767631e02d0  vmovaps [rsp+0xC0], xmm12
00007767631e02d9  vmovaps [rsp+0xD0], xmm13
00007767631e02e2  vmovaps [rsp+0xE0], xmm15
00007767631e02eb  sub rsp, 0x30
00007767631e02ef  movaps [rsp], xmm14
00007767631e02f4  movaps [rsp+0x10], xmm12
00007767631e02fa  movaps [rsp+0x20], xmm1
00007767631e02ff  lea rdi, [rsp]
00007767631e0303  mov esi, 0x00
00007767631e0308  mov rax, 0x617961CDB530
00007767631e0312  call rax
00007767631e0314  movaps xmm14, [rsp]
00007767631e0319  add rsp, 0x30
00007767631e031d  vmovaps xmm0, [rsp]
00007767631e0322  vmovaps xmm1, [rsp+0x10]
00007767631e0328  vmovaps xmm2, [rsp+0x20]
00007767631e032e  vmovaps xmm3, [rsp+0x30]
00007767631e0334  vmovaps xmm4, [rsp+0x40]
00007767631e033a  vmovaps xmm5, [rsp+0x50]
00007767631e0340  vmovaps xmm6, [rsp+0x60]
00007767631e0346  vmovaps xmm7, [rsp+0x70]
00007767631e034c  vmovaps xmm8, [rsp+0x80]
00007767631e0355  vmovaps xmm9, [rsp+0x90]
00007767631e035e  vmovaps xmm10, [rsp+0xA0]
00007767631e0367  vmovaps xmm11, [rsp+0xB0]
00007767631e0370  vmovaps xmm12, [rsp+0xC0]
00007767631e0379  vmovaps xmm13, [rsp+0xD0]
00007767631e0382  vmovaps xmm15, [rsp+0xE0]
00007767631e038b  add rsp, 0xF0
00007767631e0392  pop r11
00007767631e0394  pop r10
00007767631e0396  pop r9
00007767631e0398  pop r8
00007767631e039a  pop rsi
00007767631e039b  pop rdi
00007767631e039c  pop rdx
00007767631e039d  pop rcx
00007767631e039e  pop rax
00007767631e039f  add rsp, 0x08
00007767631e03a3  jmp 0x00007767631DC5B3
00007767631e03a8  sub rsp, 0x08
00007767631e03ac  push rax
00007767631e03ad  push rcx
00007767631e03ae  push rdx
00007767631e03af  push rdi
00007767631e03b0  push rsi
00007767631e03b1  push r8
00007767631e03b3  push r9
00007767631e03b5  push r10
00007767631e03b7  push r11
00007767631e03b9  sub rsp, 0xF0
00007767631e03c0  vmovaps [rsp], xmm0
00007767631e03c5  vmovaps [rsp+0x10], xmm2
00007767631e03cb  vmovaps [rsp+0x20], xmm3
00007767631e03d1  vmovaps [rsp+0x30], xmm4
00007767631e03d7  vmovaps [rsp+0x40], xmm5
00007767631e03dd  vmovaps [rsp+0x50], xmm6
00007767631e03e3  vmovaps [rsp+0x60], xmm7
00007767631e03e9  vmovaps [rsp+0x70], xmm8
00007767631e03ef  vmovaps [rsp+0x80], xmm9
00007767631e03f8  vmovaps [rsp+0x90], xmm10
00007767631e0401  vmovaps [rsp+0xA0], xmm11
00007767631e040a  vmovaps [rsp+0xB0], xmm12
00007767631e0413  vmovaps [rsp+0xC0], xmm13
00007767631e041c  vmovaps [rsp+0xD0], xmm14
00007767631e0425  vmovaps [rsp+0xE0], xmm15
00007767631e042e  sub rsp, 0x30
00007767631e0432  movaps [rsp], xmm1
00007767631e0436  movaps [rsp+0x10], xmm13
00007767631e043c  movaps [rsp+0x20], xmm9
00007767631e0442  lea rdi, [rsp]
00007767631e0446  mov esi, 0x00
00007767631e044b  mov rax, 0x617961CDB530
00007767631e0455  call rax
00007767631e0457  movaps xmm1, [rsp]
00007767631e045b  add rsp, 0x30
00007767631e045f  vmovaps xmm0, [rsp]
00007767631e0464  vmovaps xmm2, [rsp+0x10]
00007767631e046a  vmovaps xmm3, [rsp+0x20]
00007767631e0470  vmovaps xmm4, [rsp+0x30]
00007767631e0476  vmovaps xmm5, [rsp+0x40]
00007767631e047c  vmovaps xmm6, [rsp+0x50]
00007767631e0482  vmovaps xmm7, [rsp+0x60]
00007767631e0488  vmovaps xmm8, [rsp+0x70]
00007767631e048e  vmovaps xmm9, [rsp+0x80]
00007767631e0497  vmovaps xmm10, [rsp+0x90]
00007767631e04a0  vmovaps xmm11, [rsp+0xA0]
00007767631e04a9  vmovaps xmm12, [rsp+0xB0]
00007767631e04b2  vmovaps xmm13, [rsp+0xC0]
00007767631e04bb  vmovaps xmm14, [rsp+0xD0]
00007767631e04c4  vmovaps xmm15, [rsp+0xE0]
00007767631e04cd  add rsp, 0xF0
00007767631e04d4  pop r11
00007767631e04d6  pop r10
00007767631e04d8  pop r9
00007767631e04da  pop r8
00007767631e04dc  pop rsi
00007767631e04dd  pop rdi
00007767631e04de  pop rdx
00007767631e04df  pop rcx
00007767631e04e0  pop rax
00007767631e04e1  add rsp, 0x08
00007767631e04e5  jmp 0x00007767631DC5CD
00007767631e04ea  sub rsp, 0x08
00007767631e04ee  push rax
00007767631e04ef  push rcx
00007767631e04f0  push rdx
00007767631e04f1  push rdi
00007767631e04f2  push rsi
00007767631e04f3  push r8
00007767631e04f5  push r9
00007767631e04f7  push r10
00007767631e04f9  push r11
00007767631e04fb  sub rsp, 0xF0
00007767631e0502  vmovaps [rsp], xmm0
00007767631e0507  vmovaps [rsp+0x10], xmm1
00007767631e050d  vmovaps [rsp+0x20], xmm2
00007767631e0513  vmovaps [rsp+0x30], xmm3
00007767631e0519  vmovaps [rsp+0x40], xmm4
00007767631e051f  vmovaps [rsp+0x50], xmm5
00007767631e0525  vmovaps [rsp+0x60], xmm6
00007767631e052b  vmovaps [rsp+0x70], xmm7
00007767631e0531  vmovaps [rsp+0x80], xmm8
00007767631e053a  vmovaps [rsp+0x90], xmm9
00007767631e0543  vmovaps [rsp+0xA0], xmm10
00007767631e054c  vmovaps [rsp+0xB0], xmm11
00007767631e0555  vmovaps [rsp+0xC0], xmm13
00007767631e055e  vmovaps [rsp+0xD0], xmm14
00007767631e0567  vmovaps [rsp+0xE0], xmm15
00007767631e0570  sub rsp, 0x30
00007767631e0574  movaps [rsp], xmm12
00007767631e0579  movaps [rsp+0x10], xmm7
00007767631e057e  movaps [rsp+0x20], xmm13
00007767631e0584  lea rdi, [rsp]
00007767631e0588  mov esi, 0x00
00007767631e058d  mov rax, 0x617961CDB530
00007767631e0597  call rax
00007767631e0599  movaps xmm12, [rsp]
00007767631e059e  add rsp, 0x30
00007767631e05a2  vmovaps xmm0, [rsp]
00007767631e05a7  vmovaps xmm1, [rsp+0x10]
00007767631e05ad  vmovaps xmm2, [rsp+0x20]
00007767631e05b3  vmovaps xmm3, [rsp+0x30]
00007767631e05b9  vmovaps xmm4, [rsp+0x40]
00007767631e05bf  vmovaps xmm5, [rsp+0x50]
00007767631e05c5  vmovaps xmm6, [rsp+0x60]
00007767631e05cb  vmovaps xmm7, [rsp+0x70]
00007767631e05d1  vmovaps xmm8, [rsp+0x80]
00007767631e05da  vmovaps xmm9, [rsp+0x90]
00007767631e05e3  vmovaps xmm10, [rsp+0xA0]
00007767631e05ec  vmovaps xmm11, [rsp+0xB0]
00007767631e05f5  vmovaps xmm13, [rsp+0xC0]
00007767631e05fe  vmovaps xmm14, [rsp+0xD0]
00007767631e0607  vmovaps xmm15, [rsp+0xE0]
00007767631e0610  add rsp, 0xF0
00007767631e0617  pop r11
00007767631e0619  pop r10
00007767631e061b  pop r9
00007767631e061d  pop r8
00007767631e061f  pop rsi
00007767631e0620  pop rdi
00007767631e0621  pop rdx
00007767631e0622  pop rcx
00007767631e0623  pop rax
00007767631e0624  add rsp, 0x08
00007767631e0628  jmp 0x00007767631DC5F4
00007767631e062d  sub rsp, 0x08
00007767631e0631  push rax
00007767631e0632  push rcx
00007767631e0633  push rdx
00007767631e0634  push rdi
00007767631e0635  push rsi
00007767631e0636  push r8
00007767631e0638  push r9
00007767631e063a  push r10
00007767631e063c  push r11
00007767631e063e  sub rsp, 0xF0
00007767631e0645  vmovaps [rsp], xmm0
00007767631e064a  vmovaps [rsp+0x10], xmm1
00007767631e0650  vmovaps [rsp+0x20], xmm2
00007767631e0656  vmovaps [rsp+0x30], xmm3
00007767631e065c  vmovaps [rsp+0x40], xmm4
00007767631e0662  vmovaps [rsp+0x50], xmm5
00007767631e0668  vmovaps [rsp+0x60], xmm6
00007767631e066e  vmovaps [rsp+0x70], xmm7
00007767631e0674  vmovaps [rsp+0x80], xmm8
00007767631e067d  vmovaps [rsp+0x90], xmm9
00007767631e0686  vmovaps [rsp+0xA0], xmm10
00007767631e068f  vmovaps [rsp+0xB0], xmm11
00007767631e0698  vmovaps [rsp+0xC0], xmm12
00007767631e06a1  vmovaps [rsp+0xD0], xmm14
00007767631e06aa  vmovaps [rsp+0xE0], xmm15
00007767631e06b3  sub rsp, 0x30
00007767631e06b7  movaps [rsp], xmm13
00007767631e06bc  movaps [rsp+0x10], xmm15
00007767631e06c2  movaps [rsp+0x20], xmm8
00007767631e06c8  lea rdi, [rsp]
00007767631e06cc  mov esi, 0x00
00007767631e06d1  mov rax, 0x617961CDB530
00007767631e06db  call rax
00007767631e06dd  movaps xmm13, [rsp]
00007767631e06e2  add rsp, 0x30
00007767631e06e6  vmovaps xmm0, [rsp]
00007767631e06eb  vmovaps xmm1, [rsp+0x10]
00007767631e06f1  vmovaps xmm2, [rsp+0x20]
00007767631e06f7  vmovaps xmm3, [rsp+0x30]
00007767631e06fd  vmovaps xmm4, [rsp+0x40]
00007767631e0703  vmovaps xmm5, [rsp+0x50]
00007767631e0709  vmovaps xmm6, [rsp+0x60]
00007767631e070f  vmovaps xmm7, [rsp+0x70]
00007767631e0715  vmovaps xmm8, [rsp+0x80]
00007767631e071e  vmovaps xmm9, [rsp+0x90]
00007767631e0727  vmovaps xmm10, [rsp+0xA0]
00007767631e0730  vmovaps xmm11, [rsp+0xB0]
00007767631e0739  vmovaps xmm12, [rsp+0xC0]
00007767631e0742  vmovaps xmm14, [rsp+0xD0]
00007767631e074b  vmovaps xmm15, [rsp+0xE0]
00007767631e0754  add rsp, 0xF0
00007767631e075b  pop r11
00007767631e075d  pop r10
00007767631e075f  pop r9
00007767631e0761  pop r8
00007767631e0763  pop rsi
00007767631e0764  pop rdi
00007767631e0765  pop rdx
00007767631e0766  pop rcx
00007767631e0767  pop rax
00007767631e0768  add rsp, 0x08
00007767631e076c  jmp 0x00007767631DC60F
00007767631e0771  sub rsp, 0x08
00007767631e0775  push rax
00007767631e0776  push rcx
00007767631e0777  push rdx
00007767631e0778  push rdi
00007767631e0779  push rsi
00007767631e077a  push r8
00007767631e077c  push r9
00007767631e077e  push r10
00007767631e0780  push r11
00007767631e0782  sub rsp, 0xF0
00007767631e0789  vmovaps [rsp], xmm0
00007767631e078e  vmovaps [rsp+0x10], xmm1
00007767631e0794  vmovaps [rsp+0x20], xmm2
00007767631e079a  vmovaps [rsp+0x30], xmm3
00007767631e07a0  vmovaps [rsp+0x40], xmm4
00007767631e07a6  vmovaps [rsp+0x50], xmm5
00007767631e07ac  vmovaps [rsp+0x60], xmm6
00007767631e07b2  vmovaps [rsp+0x70], xmm7
00007767631e07b8  vmovaps [rsp+0x80], xmm9
00007767631e07c1  vmovaps [rsp+0x90], xmm10
00007767631e07ca  vmovaps [rsp+0xA0], xmm11
00007767631e07d3  vmovaps [rsp+0xB0], xmm12
00007767631e07dc  vmovaps [rsp+0xC0], xmm13
00007767631e07e5  vmovaps [rsp+0xD0], xmm14
00007767631e07ee  vmovaps [rsp+0xE0], xmm15
00007767631e07f7  sub rsp, 0x30
00007767631e07fb  movaps [rsp], xmm8
00007767631e0800  movaps [rsp+0x10], xmm15
00007767631e0806  movaps [rsp+0x20], xmm9
00007767631e080c  lea rdi, [rsp]
00007767631e0810  mov esi, 0x00
00007767631e0815  mov rax, 0x617961CDB530
00007767631e081f  call rax
00007767631e0821  movaps xmm8, [rsp]
00007767631e0826  add rsp, 0x30
00007767631e082a  vmovaps xmm0, [rsp]
00007767631e082f  vmovaps xmm1, [rsp+0x10]
00007767631e0835  vmovaps xmm2, [rsp+0x20]
00007767631e083b  vmovaps xmm3, [rsp+0x30]
00007767631e0841  vmovaps xmm4, [rsp+0x40]
00007767631e0847  vmovaps xmm5, [rsp+0x50]
00007767631e084d  vmovaps xmm6, [rsp+0x60]
00007767631e0853  vmovaps xmm7, [rsp+0x70]
00007767631e0859  vmovaps xmm9, [rsp+0x80]
00007767631e0862  vmovaps xmm10, [rsp+0x90]
00007767631e086b  vmovaps xmm11, [rsp+0xA0]
00007767631e0874  vmovaps xmm12, [rsp+0xB0]
00007767631e087d  vmovaps xmm13, [rsp+0xC0]
00007767631e0886  vmovaps xmm14, [rsp+0xD0]
00007767631e088f  vmovaps xmm15, [rsp+0xE0]
00007767631e0898  add rsp, 0xF0
00007767631e089f  pop r11
00007767631e08a1  pop r10
00007767631e08a3  pop r9
00007767631e08a5  pop r8
00007767631e08a7  pop rsi
00007767631e08a8  pop rdi
00007767631e08a9  pop rdx
00007767631e08aa  pop rcx
00007767631e08ab  pop rax
00007767631e08ac  add rsp, 0x08
00007767631e08b0  jmp 0x00007767631DC63D
00007767631e08b5  sub rsp, 0x08
00007767631e08b9  push rax
00007767631e08ba  push rcx
00007767631e08bb  push rdx
00007767631e08bc  push rdi
00007767631e08bd  push rsi
00007767631e08be  push r8
00007767631e08c0  push r9
00007767631e08c2  push r10
00007767631e08c4  push r11
00007767631e08c6  sub rsp, 0xF0
00007767631e08cd  vmovaps [rsp], xmm0
00007767631e08d2  vmovaps [rsp+0x10], xmm1
00007767631e08d8  vmovaps [rsp+0x20], xmm2
00007767631e08de  vmovaps [rsp+0x30], xmm3
00007767631e08e4  vmovaps [rsp+0x40], xmm4
00007767631e08ea  vmovaps [rsp+0x50], xmm5
00007767631e08f0  vmovaps [rsp+0x60], xmm6
00007767631e08f6  vmovaps [rsp+0x70], xmm7
00007767631e08fc  vmovaps [rsp+0x80], xmm8
00007767631e0905  vmovaps [rsp+0x90], xmm9
00007767631e090e  vmovaps [rsp+0xA0], xmm10
00007767631e0917  vmovaps [rsp+0xB0], xmm11
00007767631e0920  vmovaps [rsp+0xC0], xmm12
00007767631e0929  vmovaps [rsp+0xD0], xmm13
00007767631e0932  vmovaps [rsp+0xE0], xmm14
00007767631e093b  sub rsp, 0x30
00007767631e093f  movaps [rsp], xmm15
00007767631e0944  movaps [rsp+0x10], xmm11
00007767631e094a  movaps [rsp+0x20], xmm6
00007767631e094f  lea rdi, [rsp]
00007767631e0953  mov esi, 0x00
00007767631e0958  mov rax, 0x617961CDB530
00007767631e0962  call rax
00007767631e0964  movaps xmm15, [rsp]
00007767631e0969  add rsp, 0x30
00007767631e096d  vmovaps xmm0, [rsp]
00007767631e0972  vmovaps xmm1, [rsp+0x10]
00007767631e0978  vmovaps xmm2, [rsp+0x20]
00007767631e097e  vmovaps xmm3, [rsp+0x30]
00007767631e0984  vmovaps xmm4, [rsp+0x40]
00007767631e098a  vmovaps xmm5, [rsp+0x50]
00007767631e0990  vmovaps xmm6, [rsp+0x60]
00007767631e0996  vmovaps xmm7, [rsp+0x70]
00007767631e099c  vmovaps xmm8, [rsp+0x80]
00007767631e09a5  vmovaps xmm9, [rsp+0x90]
00007767631e09ae  vmovaps xmm10, [rsp+0xA0]
00007767631e09b7  vmovaps xmm11, [rsp+0xB0]
00007767631e09c0  vmovaps xmm12, [rsp+0xC0]
00007767631e09c9  vmovaps xmm13, [rsp+0xD0]
00007767631e09d2  vmovaps xmm14, [rsp+0xE0]
00007767631e09db  add rsp, 0xF0
00007767631e09e2  pop r11
00007767631e09e4  pop r10
00007767631e09e6  pop r9
00007767631e09e8  pop r8
00007767631e09ea  pop rsi
00007767631e09eb  pop rdi
00007767631e09ec  pop rdx
00007767631e09ed  pop rcx
00007767631e09ee  pop rax
00007767631e09ef  add rsp, 0x08
00007767631e09f3  jmp 0x00007767631DC658
00007767631e09f8  sub rsp, 0x08
00007767631e09fc  push rax
00007767631e09fd  push rcx
00007767631e09fe  push rdx
00007767631e09ff  push rdi
00007767631e0a00  push rsi
00007767631e0a01  push r8
00007767631e0a03  push r9
00007767631e0a05  push r10
00007767631e0a07  push r11
00007767631e0a09  sub rsp, 0xF0
00007767631e0a10  vmovaps [rsp], xmm0
00007767631e0a15  vmovaps [rsp+0x10], xmm1
00007767631e0a1b  vmovaps [rsp+0x20], xmm2
00007767631e0a21  vmovaps [rsp+0x30], xmm3
00007767631e0a27  vmovaps [rsp+0x40], xmm4
00007767631e0a2d  vmovaps [rsp+0x50], xmm5
00007767631e0a33  vmovaps [rsp+0x60], xmm6
00007767631e0a39  vmovaps [rsp+0x70], xmm8
00007767631e0a3f  vmovaps [rsp+0x80], xmm9
00007767631e0a48  vmovaps [rsp+0x90], xmm10
00007767631e0a51  vmovaps [rsp+0xA0], xmm11
00007767631e0a5a  vmovaps [rsp+0xB0], xmm12
00007767631e0a63  vmovaps [rsp+0xC0], xmm13
00007767631e0a6c  vmovaps [rsp+0xD0], xmm14
00007767631e0a75  vmovaps [rsp+0xE0], xmm15
00007767631e0a7e  sub rsp, 0x30
00007767631e0a82  movaps [rsp], xmm7
00007767631e0a86  movaps [rsp+0x10], xmm11
00007767631e0a8c  movaps [rsp+0x20], xmm9
00007767631e0a92  lea rdi, [rsp]
00007767631e0a96  mov esi, 0x00
00007767631e0a9b  mov rax, 0x617961CDB530
00007767631e0aa5  call rax
00007767631e0aa7  movaps xmm7, [rsp]
00007767631e0aab  add rsp, 0x30
00007767631e0aaf  vmovaps xmm0, [rsp]
00007767631e0ab4  vmovaps xmm1, [rsp+0x10]
00007767631e0aba  vmovaps xmm2, [rsp+0x20]
00007767631e0ac0  vmovaps xmm3, [rsp+0x30]
00007767631e0ac6  vmovaps xmm4, [rsp+0x40]
00007767631e0acc  vmovaps xmm5, [rsp+0x50]
00007767631e0ad2  vmovaps xmm6, [rsp+0x60]
00007767631e0ad8  vmovaps xmm8, [rsp+0x70]
00007767631e0ade  vmovaps xmm9, [rsp+0x80]
00007767631e0ae7  vmovaps xmm10, [rsp+0x90]
00007767631e0af0  vmovaps xmm11, [rsp+0xA0]
00007767631e0af9  vmovaps xmm12, [rsp+0xB0]
00007767631e0b02  vmovaps xmm13, [rsp+0xC0]
00007767631e0b0b  vmovaps xmm14, [rsp+0xD0]
00007767631e0b14  vmovaps xmm15, [rsp+0xE0]
00007767631e0b1d  add rsp, 0xF0
00007767631e0b24  pop r11
00007767631e0b26  pop r10
00007767631e0b28  pop r9
00007767631e0b2a  pop r8
00007767631e0b2c  pop rsi
00007767631e0b2d  pop rdi
00007767631e0b2e  pop rdx
00007767631e0b2f  pop rcx
00007767631e0b30  pop rax
00007767631e0b31  add rsp, 0x08
00007767631e0b35  jmp 0x00007767631DC685
00007767631e0b3a  sub rsp, 0x08
00007767631e0b3e  push rax
00007767631e0b3f  push rcx
00007767631e0b40  push rdx
00007767631e0b41  push rdi
00007767631e0b42  push rsi
00007767631e0b43  push r8
00007767631e0b45  push r9
00007767631e0b47  push r10
00007767631e0b49  push r11
00007767631e0b4b  sub rsp, 0xF0
00007767631e0b52  vmovaps [rsp], xmm0
00007767631e0b57  vmovaps [rsp+0x10], xmm1
00007767631e0b5d  vmovaps [rsp+0x20], xmm2
00007767631e0b63  vmovaps [rsp+0x30], xmm3
00007767631e0b69  vmovaps [rsp+0x40], xmm4
00007767631e0b6f  vmovaps [rsp+0x50], xmm5
00007767631e0b75  vmovaps [rsp+0x60], xmm6
00007767631e0b7b  vmovaps [rsp+0x70], xmm7
00007767631e0b81  vmovaps [rsp+0x80], xmm8
00007767631e0b8a  vmovaps [rsp+0x90], xmm9
00007767631e0b93  vmovaps [rsp+0xA0], xmm10
00007767631e0b9c  vmovaps [rsp+0xB0], xmm12
00007767631e0ba5  vmovaps [rsp+0xC0], xmm13
00007767631e0bae  vmovaps [rsp+0xD0], xmm14
00007767631e0bb7  vmovaps [rsp+0xE0], xmm15
00007767631e0bc0  sub rsp, 0x30
00007767631e0bc4  movaps [rsp], xmm11
00007767631e0bc9  movaps [rsp+0x10], xmm10
00007767631e0bcf  movaps [rsp+0x20], xmm14
00007767631e0bd5  lea rdi, [rsp]
00007767631e0bd9  mov esi, 0x00
00007767631e0bde  mov rax, 0x617961CDB530
00007767631e0be8  call rax
00007767631e0bea  movaps xmm11, [rsp]
00007767631e0bef  add rsp, 0x30
00007767631e0bf3  vmovaps xmm0, [rsp]
00007767631e0bf8  vmovaps xmm1, [rsp+0x10]
00007767631e0bfe  vmovaps xmm2, [rsp+0x20]
00007767631e0c04  vmovaps xmm3, [rsp+0x30]
00007767631e0c0a  vmovaps xmm4, [rsp+0x40]
00007767631e0c10  vmovaps xmm5, [rsp+0x50]
00007767631e0c16  vmovaps xmm6, [rsp+0x60]
00007767631e0c1c  vmovaps xmm7, [rsp+0x70]
00007767631e0c22  vmovaps xmm8, [rsp+0x80]
00007767631e0c2b  vmovaps xmm9, [rsp+0x90]
00007767631e0c34  vmovaps xmm10, [rsp+0xA0]
00007767631e0c3d  vmovaps xmm12, [rsp+0xB0]
00007767631e0c46  vmovaps xmm13, [rsp+0xC0]
00007767631e0c4f  vmovaps xmm14, [rsp+0xD0]
00007767631e0c58  vmovaps xmm15, [rsp+0xE0]
00007767631e0c61  add rsp, 0xF0
00007767631e0c68  pop r11
00007767631e0c6a  pop r10
00007767631e0c6c  pop r9
00007767631e0c6e  pop r8
00007767631e0c70  pop rsi
00007767631e0c71  pop rdi
00007767631e0c72  pop rdx
00007767631e0c73  pop rcx
00007767631e0c74  pop rax
00007767631e0c75  add rsp, 0x08
00007767631e0c79  jmp 0x00007767631DC6A0
00007767631e0c7e  call 0x00007767630C33A0
00007767631e0c83  jmp 0x00007767631DC6AA
00007767631e0c88  sub rsp, 0x08
00007767631e0c8c  push rax
00007767631e0c8d  push rcx
00007767631e0c8e  push rdx
00007767631e0c8f  push rdi
00007767631e0c90  push rsi
00007767631e0c91  push r8
00007767631e0c93  push r9
00007767631e0c95  push r10
00007767631e0c97  push r11
00007767631e0c99  sub rsp, 0xF0
00007767631e0ca0  vmovaps [rsp], xmm0
00007767631e0ca5  vmovaps [rsp+0x10], xmm1
00007767631e0cab  vmovaps [rsp+0x20], xmm2
00007767631e0cb1  vmovaps [rsp+0x30], xmm3
00007767631e0cb7  vmovaps [rsp+0x40], xmm4
00007767631e0cbd  vmovaps [rsp+0x50], xmm5
00007767631e0cc3  vmovaps [rsp+0x60], xmm6
00007767631e0cc9  vmovaps [rsp+0x70], xmm7
00007767631e0ccf  vmovaps [rsp+0x80], xmm8
00007767631e0cd8  vmovaps [rsp+0x90], xmm9
00007767631e0ce1  vmovaps [rsp+0xA0], xmm11
00007767631e0cea  vmovaps [rsp+0xB0], xmm12
00007767631e0cf3  vmovaps [rsp+0xC0], xmm13
00007767631e0cfc  vmovaps [rsp+0xD0], xmm14
00007767631e0d05  vmovaps [rsp+0xE0], xmm15
00007767631e0d0e  sub rsp, 0x30
00007767631e0d12  movaps [rsp], xmm10
00007767631e0d17  movaps [rsp+0x10], xmm1
00007767631e0d1c  movaps [rsp+0x20], xmm12
00007767631e0d22  lea rdi, [rsp]
00007767631e0d26  mov esi, 0x00
00007767631e0d2b  mov rax, 0x617961CDB530
00007767631e0d35  call rax
00007767631e0d37  movaps xmm10, [rsp]
00007767631e0d3c  add rsp, 0x30
00007767631e0d40  vmovaps xmm0, [rsp]
00007767631e0d45  vmovaps xmm1, [rsp+0x10]
00007767631e0d4b  vmovaps xmm2, [rsp+0x20]
00007767631e0d51  vmovaps xmm3, [rsp+0x30]
00007767631e0d57  vmovaps xmm4, [rsp+0x40]
00007767631e0d5d  vmovaps xmm5, [rsp+0x50]
00007767631e0d63  vmovaps xmm6, [rsp+0x60]
00007767631e0d69  vmovaps xmm7, [rsp+0x70]
00007767631e0d6f  vmovaps xmm8, [rsp+0x80]
00007767631e0d78  vmovaps xmm9, [rsp+0x90]
00007767631e0d81  vmovaps xmm11, [rsp+0xA0]
00007767631e0d8a  vmovaps xmm12, [rsp+0xB0]
00007767631e0d93  vmovaps xmm13, [rsp+0xC0]
00007767631e0d9c  vmovaps xmm14, [rsp+0xD0]
00007767631e0da5  vmovaps xmm15, [rsp+0xE0]
00007767631e0dae  add rsp, 0xF0
00007767631e0db5  pop r11
00007767631e0db7  pop r10
00007767631e0db9  pop r9
00007767631e0dbb  pop r8
00007767631e0dbd  pop rsi
00007767631e0dbe  pop rdi
00007767631e0dbf  pop rdx
00007767631e0dc0  pop rcx
00007767631e0dc1  pop rax
00007767631e0dc2  add rsp, 0x08
00007767631e0dc6  jmp 0x00007767631DC6CD
00007767631e0dcb  sub rsp, 0x08
00007767631e0dcf  push rax
00007767631e0dd0  push rcx
00007767631e0dd1  push rdx
00007767631e0dd2  push rdi
00007767631e0dd3  push rsi
00007767631e0dd4  push r8
00007767631e0dd6  push r9
00007767631e0dd8  push r10
00007767631e0dda  push r11
00007767631e0ddc  sub rsp, 0xF0
00007767631e0de3  vmovaps [rsp], xmm0
00007767631e0de8  vmovaps [rsp+0x10], xmm1
00007767631e0dee  vmovaps [rsp+0x20], xmm2
00007767631e0df4  vmovaps [rsp+0x30], xmm3
00007767631e0dfa  vmovaps [rsp+0x40], xmm4
00007767631e0e00  vmovaps [rsp+0x50], xmm5
00007767631e0e06  vmovaps [rsp+0x60], xmm6
00007767631e0e0c  vmovaps [rsp+0x70], xmm7
00007767631e0e12  vmovaps [rsp+0x80], xmm8
00007767631e0e1b  vmovaps [rsp+0x90], xmm9
00007767631e0e24  vmovaps [rsp+0xA0], xmm10
00007767631e0e2d  vmovaps [rsp+0xB0], xmm11
00007767631e0e36  vmovaps [rsp+0xC0], xmm13
00007767631e0e3f  vmovaps [rsp+0xD0], xmm14
00007767631e0e48  vmovaps [rsp+0xE0], xmm15
00007767631e0e51  sub rsp, 0x30
00007767631e0e55  movaps [rsp], xmm12
00007767631e0e5a  movaps [rsp+0x10], xmm14
00007767631e0e60  movaps [rsp+0x20], xmm1
00007767631e0e65  lea rdi, [rsp]
00007767631e0e69  mov esi, 0x00
00007767631e0e6e  mov rax, 0x617961CDB530
00007767631e0e78  call rax
00007767631e0e7a  movaps xmm12, [rsp]
00007767631e0e7f  add rsp, 0x30
00007767631e0e83  vmovaps xmm0, [rsp]
00007767631e0e88  vmovaps xmm1, [rsp+0x10]
00007767631e0e8e  vmovaps xmm2, [rsp+0x20]
00007767631e0e94  vmovaps xmm3, [rsp+0x30]
00007767631e0e9a  vmovaps xmm4, [rsp+0x40]
00007767631e0ea0  vmovaps xmm5, [rsp+0x50]
00007767631e0ea6  vmovaps xmm6, [rsp+0x60]
00007767631e0eac  vmovaps xmm7, [rsp+0x70]
00007767631e0eb2  vmovaps xmm8, [rsp+0x80]
00007767631e0ebb  vmovaps xmm9, [rsp+0x90]
00007767631e0ec4  vmovaps xmm10, [rsp+0xA0]
00007767631e0ecd  vmovaps xmm11, [rsp+0xB0]
00007767631e0ed6  vmovaps xmm13, [rsp+0xC0]
00007767631e0edf  vmovaps xmm14, [rsp+0xD0]
00007767631e0ee8  vmovaps xmm15, [rsp+0xE0]
00007767631e0ef1  add rsp, 0xF0
00007767631e0ef8  pop r11
00007767631e0efa  pop r10
00007767631e0efc  pop r9
00007767631e0efe  pop r8
00007767631e0f00  pop rsi
00007767631e0f01  pop rdi
00007767631e0f02  pop rdx
00007767631e0f03  pop rcx
00007767631e0f04  pop rax
00007767631e0f05  add rsp, 0x08
00007767631e0f09  jmp 0x00007767631DC6FC
00007767631e0f0e  sub rsp, 0x08
00007767631e0f12  push rax
00007767631e0f13  push rcx
00007767631e0f14  push rdx
00007767631e0f15  push rdi
00007767631e0f16  push rsi
00007767631e0f17  push r8
00007767631e0f19  push r9
00007767631e0f1b  push r10
00007767631e0f1d  push r11
00007767631e0f1f  sub rsp, 0xF0
00007767631e0f26  vmovaps [rsp], xmm0
00007767631e0f2b  vmovaps [rsp+0x10], xmm1
00007767631e0f31  vmovaps [rsp+0x20], xmm2
00007767631e0f37  vmovaps [rsp+0x30], xmm3
00007767631e0f3d  vmovaps [rsp+0x40], xmm4
00007767631e0f43  vmovaps [rsp+0x50], xmm5
00007767631e0f49  vmovaps [rsp+0x60], xmm6
00007767631e0f4f  vmovaps [rsp+0x70], xmm7
00007767631e0f55  vmovaps [rsp+0x80], xmm8
00007767631e0f5e  vmovaps [rsp+0x90], xmm9
00007767631e0f67  vmovaps [rsp+0xA0], xmm10
00007767631e0f70  vmovaps [rsp+0xB0], xmm11
00007767631e0f79  vmovaps [rsp+0xC0], xmm12
00007767631e0f82  vmovaps [rsp+0xD0], xmm13
00007767631e0f8b  vmovaps [rsp+0xE0], xmm15
00007767631e0f94  sub rsp, 0x30
00007767631e0f98  movaps [rsp], xmm14
00007767631e0f9d  movaps [rsp+0x10], xmm9
00007767631e0fa3  movaps [rsp+0x20], xmm1
00007767631e0fa8  lea rdi, [rsp]
00007767631e0fac  mov esi, 0x00
00007767631e0fb1  mov rax, 0x617961CDB530
00007767631e0fbb  call rax
00007767631e0fbd  movaps xmm14, [rsp]
00007767631e0fc2  add rsp, 0x30
00007767631e0fc6  vmovaps xmm0, [rsp]
00007767631e0fcb  vmovaps xmm1, [rsp+0x10]
00007767631e0fd1  vmovaps xmm2, [rsp+0x20]
00007767631e0fd7  vmovaps xmm3, [rsp+0x30]
00007767631e0fdd  vmovaps xmm4, [rsp+0x40]
00007767631e0fe3  vmovaps xmm5, [rsp+0x50]
00007767631e0fe9  vmovaps xmm6, [rsp+0x60]
00007767631e0fef  vmovaps xmm7, [rsp+0x70]
00007767631e0ff5  vmovaps xmm8, [rsp+0x80]
00007767631e0ffe  vmovaps xmm9, [rsp+0x90]
00007767631e1007  vmovaps xmm10, [rsp+0xA0]
00007767631e1010  vmovaps xmm11, [rsp+0xB0]
00007767631e1019  vmovaps xmm12, [rsp+0xC0]
00007767631e1022  vmovaps xmm13, [rsp+0xD0]
00007767631e102b  vmovaps xmm15, [rsp+0xE0]
00007767631e1034  add rsp, 0xF0
00007767631e103b  pop r11
00007767631e103d  pop r10
00007767631e103f  pop r9
00007767631e1041  pop r8
00007767631e1043  pop rsi
00007767631e1044  pop rdi
00007767631e1045  pop rdx
00007767631e1046  pop rcx
00007767631e1047  pop rax
00007767631e1048  add rsp, 0x08
00007767631e104c  jmp 0x00007767631DC72B
00007767631e1051  sub rsp, 0x08
00007767631e1055  push rax
00007767631e1056  push rcx
00007767631e1057  push rdx
00007767631e1058  push rdi
00007767631e1059  push rsi
00007767631e105a  push r8
00007767631e105c  push r9
00007767631e105e  push r10
00007767631e1060  push r11
00007767631e1062  sub rsp, 0xF0
00007767631e1069  vmovaps [rsp], xmm0
00007767631e106e  vmovaps [rsp+0x10], xmm2
00007767631e1074  vmovaps [rsp+0x20], xmm3
00007767631e107a  vmovaps [rsp+0x30], xmm4
00007767631e1080  vmovaps [rsp+0x40], xmm5
00007767631e1086  vmovaps [rsp+0x50], xmm6
00007767631e108c  vmovaps [rsp+0x60], xmm7
00007767631e1092  vmovaps [rsp+0x70], xmm8
00007767631e1098  vmovaps [rsp+0x80], xmm9
00007767631e10a1  vmovaps [rsp+0x90], xmm10
00007767631e10aa  vmovaps [rsp+0xA0], xmm11
00007767631e10b3  vmovaps [rsp+0xB0], xmm12
00007767631e10bc  vmovaps [rsp+0xC0], xmm13
00007767631e10c5  vmovaps [rsp+0xD0], xmm14
00007767631e10ce  vmovaps [rsp+0xE0], xmm15
00007767631e10d7  sub rsp, 0x30
00007767631e10db  movaps [rsp], xmm1
00007767631e10df  movaps [rsp+0x10], xmm13
00007767631e10e5  movaps [rsp+0x20], xmm8
00007767631e10eb  lea rdi, [rsp]
00007767631e10ef  mov esi, 0x00
00007767631e10f4  mov rax, 0x617961CDB530
00007767631e10fe  call rax
00007767631e1100  movaps xmm1, [rsp]
00007767631e1104  add rsp, 0x30
00007767631e1108  vmovaps xmm0, [rsp]
00007767631e110d  vmovaps xmm2, [rsp+0x10]
00007767631e1113  vmovaps xmm3, [rsp+0x20]
00007767631e1119  vmovaps xmm4, [rsp+0x30]
00007767631e111f  vmovaps xmm5, [rsp+0x40]
00007767631e1125  vmovaps xmm6, [rsp+0x50]
00007767631e112b  vmovaps xmm7, [rsp+0x60]
00007767631e1131  vmovaps xmm8, [rsp+0x70]
00007767631e1137  vmovaps xmm9, [rsp+0x80]
00007767631e1140  vmovaps xmm10, [rsp+0x90]
00007767631e1149  vmovaps xmm11, [rsp+0xA0]
00007767631e1152  vmovaps xmm12, [rsp+0xB0]
00007767631e115b  vmovaps xmm13, [rsp+0xC0]
00007767631e1164  vmovaps xmm14, [rsp+0xD0]
00007767631e116d  vmovaps xmm15, [rsp+0xE0]
00007767631e1176  add rsp, 0xF0
00007767631e117d  pop r11
00007767631e117f  pop r10
00007767631e1181  pop r9
00007767631e1183  pop r8
00007767631e1185  pop rsi
00007767631e1186  pop rdi
00007767631e1187  pop rdx
00007767631e1188  pop rcx
00007767631e1189  pop rax
00007767631e118a  add rsp, 0x08
00007767631e118e  jmp 0x00007767631DC74D
00007767631e1193  call 0x000077676300C260
00007767631e1198  jmp 0x00007767631DC75B
00007767631e119d  call 0x00007767630BD750
00007767631e11a2  jmp 0x00007767631DC765
00007767631e11a7  sub rsp, 0x08
00007767631e11ab  push rax
00007767631e11ac  push rcx
00007767631e11ad  push rdx
00007767631e11ae  push rdi
00007767631e11af  push rsi
00007767631e11b0  push r8
00007767631e11b2  push r9
00007767631e11b4  push r10
00007767631e11b6  push r11
00007767631e11b8  sub rsp, 0xF0
00007767631e11bf  vmovaps [rsp], xmm0
00007767631e11c4  vmovaps [rsp+0x10], xmm1
00007767631e11ca  vmovaps [rsp+0x20], xmm2
00007767631e11d0  vmovaps [rsp+0x30], xmm3
00007767631e11d6  vmovaps [rsp+0x40], xmm4
00007767631e11dc  vmovaps [rsp+0x50], xmm5
00007767631e11e2  vmovaps [rsp+0x60], xmm6
00007767631e11e8  vmovaps [rsp+0x70], xmm7
00007767631e11ee  vmovaps [rsp+0x80], xmm9
00007767631e11f7  vmovaps [rsp+0x90], xmm10
00007767631e1200  vmovaps [rsp+0xA0], xmm11
00007767631e1209  vmovaps [rsp+0xB0], xmm12
00007767631e1212  vmovaps [rsp+0xC0], xmm13
00007767631e121b  vmovaps [rsp+0xD0], xmm14
00007767631e1224  vmovaps [rsp+0xE0], xmm15
00007767631e122d  sub rsp, 0x30
00007767631e1231  movaps [rsp], xmm8
00007767631e1236  movaps [rsp+0x10], xmm15
00007767631e123c  movaps [rsp+0x20], xmm7
00007767631e1241  lea rdi, [rsp]
00007767631e1245  mov esi, 0x00
00007767631e124a  mov rax, 0x617961CDB530
00007767631e1254  call rax
00007767631e1256  movaps xmm8, [rsp]
00007767631e125b  add rsp, 0x30
00007767631e125f  vmovaps xmm0, [rsp]
00007767631e1264  vmovaps xmm1, [rsp+0x10]
00007767631e126a  vmovaps xmm2, [rsp+0x20]
00007767631e1270  vmovaps xmm3, [rsp+0x30]
00007767631e1276  vmovaps xmm4, [rsp+0x40]
00007767631e127c  vmovaps xmm5, [rsp+0x50]
00007767631e1282  vmovaps xmm6, [rsp+0x60]
00007767631e1288  vmovaps xmm7, [rsp+0x70]
00007767631e128e  vmovaps xmm9, [rsp+0x80]
00007767631e1297  vmovaps xmm10, [rsp+0x90]
00007767631e12a0  vmovaps xmm11, [rsp+0xA0]
00007767631e12a9  vmovaps xmm12, [rsp+0xB0]
00007767631e12b2  vmovaps xmm13, [rsp+0xC0]
00007767631e12bb  vmovaps xmm14, [rsp+0xD0]
00007767631e12c4  vmovaps xmm15, [rsp+0xE0]
00007767631e12cd  add rsp, 0xF0
00007767631e12d4  pop r11
00007767631e12d6  pop r10
00007767631e12d8  pop r9
00007767631e12da  pop r8
00007767631e12dc  pop rsi
00007767631e12dd  pop rdi
00007767631e12de  pop rdx
00007767631e12df  pop rcx
00007767631e12e0  pop rax
00007767631e12e1  add rsp, 0x08
00007767631e12e5  jmp 0x00007767631DC787
00007767631e12ea  sub rsp, 0x08
00007767631e12ee  push rax
00007767631e12ef  push rcx
00007767631e12f0  push rdx
00007767631e12f1  push rdi
00007767631e12f2  push rsi
00007767631e12f3  push r8
00007767631e12f5  push r9
00007767631e12f7  push r10
00007767631e12f9  push r11
00007767631e12fb  sub rsp, 0xF0
00007767631e1302  vmovaps [rsp], xmm0
00007767631e1307  vmovaps [rsp+0x10], xmm1
00007767631e130d  vmovaps [rsp+0x20], xmm2
00007767631e1313  vmovaps [rsp+0x30], xmm3
00007767631e1319  vmovaps [rsp+0x40], xmm4
00007767631e131f  vmovaps [rsp+0x50], xmm5
00007767631e1325  vmovaps [rsp+0x60], xmm6
00007767631e132b  vmovaps [rsp+0x70], xmm8
00007767631e1331  vmovaps [rsp+0x80], xmm9
00007767631e133a  vmovaps [rsp+0x90], xmm10
00007767631e1343  vmovaps [rsp+0xA0], xmm11
00007767631e134c  vmovaps [rsp+0xB0], xmm12
00007767631e1355  vmovaps [rsp+0xC0], xmm13
00007767631e135e  vmovaps [rsp+0xD0], xmm14
00007767631e1367  vmovaps [rsp+0xE0], xmm15
00007767631e1370  sub rsp, 0x30
00007767631e1374  movaps [rsp], xmm7
00007767631e1378  movaps [rsp+0x10], xmm9
00007767631e137e  movaps [rsp+0x20], xmm15
00007767631e1384  lea rdi, [rsp]
00007767631e1388  mov esi, 0x00
00007767631e138d  mov rax, 0x617961CDB530
00007767631e1397  call rax
00007767631e1399  movaps xmm7, [rsp]
00007767631e139d  add rsp, 0x30
00007767631e13a1  vmovaps xmm0, [rsp]
00007767631e13a6  vmovaps xmm1, [rsp+0x10]
00007767631e13ac  vmovaps xmm2, [rsp+0x20]
00007767631e13b2  vmovaps xmm3, [rsp+0x30]
00007767631e13b8  vmovaps xmm4, [rsp+0x40]
00007767631e13be  vmovaps xmm5, [rsp+0x50]
00007767631e13c4  vmovaps xmm6, [rsp+0x60]
00007767631e13ca  vmovaps xmm8, [rsp+0x70]
00007767631e13d0  vmovaps xmm9, [rsp+0x80]
00007767631e13d9  vmovaps xmm10, [rsp+0x90]
00007767631e13e2  vmovaps xmm11, [rsp+0xA0]
00007767631e13eb  vmovaps xmm12, [rsp+0xB0]
00007767631e13f4  vmovaps xmm13, [rsp+0xC0]
00007767631e13fd  vmovaps xmm14, [rsp+0xD0]
00007767631e1406  vmovaps xmm15, [rsp+0xE0]
00007767631e140f  add rsp, 0xF0
00007767631e1416  pop r11
00007767631e1418  pop r10
00007767631e141a  pop r9
00007767631e141c  pop r8
00007767631e141e  pop rsi
00007767631e141f  pop rdi
00007767631e1420  pop rdx
00007767631e1421  pop rcx
00007767631e1422  pop rax
00007767631e1423  add rsp, 0x08
00007767631e1427  jmp 0x00007767631DC7B4
00007767631e142c  sub rsp, 0x08
00007767631e1430  push rax
00007767631e1431  push rcx
00007767631e1432  push rdx
00007767631e1433  push rdi
00007767631e1434  push rsi
00007767631e1435  push r8
00007767631e1437  push r9
00007767631e1439  push r10
00007767631e143b  push r11
00007767631e143d  sub rsp, 0xF0
00007767631e1444  vmovaps [rsp], xmm0
00007767631e1449  vmovaps [rsp+0x10], xmm1
00007767631e144f  vmovaps [rsp+0x20], xmm2
00007767631e1455  vmovaps [rsp+0x30], xmm3
00007767631e145b  vmovaps [rsp+0x40], xmm4
00007767631e1461  vmovaps [rsp+0x50], xmm5
00007767631e1467  vmovaps [rsp+0x60], xmm6
00007767631e146d  vmovaps [rsp+0x70], xmm7
00007767631e1473  vmovaps [rsp+0x80], xmm8
00007767631e147c  vmovaps [rsp+0x90], xmm10
00007767631e1485  vmovaps [rsp+0xA0], xmm11
00007767631e148e  vmovaps [rsp+0xB0], xmm12
00007767631e1497  vmovaps [rsp+0xC0], xmm13
00007767631e14a0  vmovaps [rsp+0xD0], xmm14
00007767631e14a9  vmovaps [rsp+0xE0], xmm15
00007767631e14b2  sub rsp, 0x30
00007767631e14b6  movaps [rsp], xmm9
00007767631e14bb  movaps [rsp+0x10], xmm13
00007767631e14c1  movaps [rsp+0x20], xmm15
00007767631e14c7  lea rdi, [rsp]
00007767631e14cb  mov esi, 0x00
00007767631e14d0  mov rax, 0x617961CDB530
00007767631e14da  call rax
00007767631e14dc  movaps xmm9, [rsp]
00007767631e14e1  add rsp, 0x30
00007767631e14e5  vmovaps xmm0, [rsp]
00007767631e14ea  vmovaps xmm1, [rsp+0x10]
00007767631e14f0  vmovaps xmm2, [rsp+0x20]
00007767631e14f6  vmovaps xmm3, [rsp+0x30]
00007767631e14fc  vmovaps xmm4, [rsp+0x40]
00007767631e1502  vmovaps xmm5, [rsp+0x50]
00007767631e1508  vmovaps xmm6, [rsp+0x60]
00007767631e150e  vmovaps xmm7, [rsp+0x70]
00007767631e1514  vmovaps xmm8, [rsp+0x80]
00007767631e151d  vmovaps xmm10, [rsp+0x90]
00007767631e1526  vmovaps xmm11, [rsp+0xA0]
00007767631e152f  vmovaps xmm12, [rsp+0xB0]
00007767631e1538  vmovaps xmm13, [rsp+0xC0]
00007767631e1541  vmovaps xmm14, [rsp+0xD0]
00007767631e154a  vmovaps xmm15, [rsp+0xE0]
00007767631e1553  add rsp, 0xF0
00007767631e155a  pop r11
00007767631e155c  pop r10
00007767631e155e  pop r9
00007767631e1560  pop r8
00007767631e1562  pop rsi
00007767631e1563  pop rdi
00007767631e1564  pop rdx
00007767631e1565  pop rcx
00007767631e1566  pop rax
00007767631e1567  add rsp, 0x08
00007767631e156b  jmp 0x00007767631DC7E2
00007767631e1570  sub rsp, 0x08
00007767631e1574  push rax
00007767631e1575  push rcx
00007767631e1576  push rdx
00007767631e1577  push rdi
00007767631e1578  push rsi
00007767631e1579  push r8
00007767631e157b  push r9
00007767631e157d  push r10
00007767631e157f  push r11
00007767631e1581  sub rsp, 0xF0
00007767631e1588  vmovaps [rsp], xmm0
00007767631e158d  vmovaps [rsp+0x10], xmm1
00007767631e1593  vmovaps [rsp+0x20], xmm2
00007767631e1599  vmovaps [rsp+0x30], xmm3
00007767631e159f  vmovaps [rsp+0x40], xmm4
00007767631e15a5  vmovaps [rsp+0x50], xmm5
00007767631e15ab  vmovaps [rsp+0x60], xmm6
00007767631e15b1  vmovaps [rsp+0x70], xmm7
00007767631e15b7  vmovaps [rsp+0x80], xmm8
00007767631e15c0  vmovaps [rsp+0x90], xmm9
00007767631e15c9  vmovaps [rsp+0xA0], xmm10
00007767631e15d2  vmovaps [rsp+0xB0], xmm11
00007767631e15db  vmovaps [rsp+0xC0], xmm12
00007767631e15e4  vmovaps [rsp+0xD0], xmm13
00007767631e15ed  vmovaps [rsp+0xE0], xmm14
00007767631e15f6  sub rsp, 0x30
00007767631e15fa  movaps [rsp], xmm15
00007767631e15ff  movaps [rsp+0x10], xmm11
00007767631e1605  movaps [rsp+0x20], xmm12
00007767631e160b  lea rdi, [rsp]
00007767631e160f  mov esi, 0x00
00007767631e1614  mov rax, 0x617961CDB530
00007767631e161e  call rax
00007767631e1620  movaps xmm15, [rsp]
00007767631e1625  add rsp, 0x30
00007767631e1629  vmovaps xmm0, [rsp]
00007767631e162e  vmovaps xmm1, [rsp+0x10]
00007767631e1634  vmovaps xmm2, [rsp+0x20]
00007767631e163a  vmovaps xmm3, [rsp+0x30]
00007767631e1640  vmovaps xmm4, [rsp+0x40]
00007767631e1646  vmovaps xmm5, [rsp+0x50]
00007767631e164c  vmovaps xmm6, [rsp+0x60]
00007767631e1652  vmovaps xmm7, [rsp+0x70]
00007767631e1658  vmovaps xmm8, [rsp+0x80]
00007767631e1661  vmovaps xmm9, [rsp+0x90]
00007767631e166a  vmovaps xmm10, [rsp+0xA0]
00007767631e1673  vmovaps xmm11, [rsp+0xB0]
00007767631e167c  vmovaps xmm12, [rsp+0xC0]
00007767631e1685  vmovaps xmm13, [rsp+0xD0]
00007767631e168e  vmovaps xmm14, [rsp+0xE0]
00007767631e1697  add rsp, 0xF0
00007767631e169e  pop r11
00007767631e16a0  pop r10
00007767631e16a2  pop r9
00007767631e16a4  pop r8
00007767631e16a6  pop rsi
00007767631e16a7  pop rdi
00007767631e16a8  pop rdx
00007767631e16a9  pop rcx
00007767631e16aa  pop rax
00007767631e16ab  add rsp, 0x08
00007767631e16af  jmp 0x00007767631DC7FD
00007767631e16b4  sub rsp, 0x08
00007767631e16b8  push rax
00007767631e16b9  push rcx
00007767631e16ba  push rdx
00007767631e16bb  push rdi
00007767631e16bc  push rsi
00007767631e16bd  push r8
00007767631e16bf  push r9
00007767631e16c1  push r10
00007767631e16c3  push r11
00007767631e16c5  sub rsp, 0xF0
00007767631e16cc  vmovaps [rsp], xmm0
00007767631e16d1  vmovaps [rsp+0x10], xmm1
00007767631e16d7  vmovaps [rsp+0x20], xmm2
00007767631e16dd  vmovaps [rsp+0x30], xmm3
00007767631e16e3  vmovaps [rsp+0x40], xmm4
00007767631e16e9  vmovaps [rsp+0x50], xmm5
00007767631e16ef  vmovaps [rsp+0x60], xmm6
00007767631e16f5  vmovaps [rsp+0x70], xmm7
00007767631e16fb  vmovaps [rsp+0x80], xmm8
00007767631e1704  vmovaps [rsp+0x90], xmm9
00007767631e170d  vmovaps [rsp+0xA0], xmm10
00007767631e1716  vmovaps [rsp+0xB0], xmm11
00007767631e171f  vmovaps [rsp+0xC0], xmm12
00007767631e1728  vmovaps [rsp+0xD0], xmm14
00007767631e1731  vmovaps [rsp+0xE0], xmm15
00007767631e173a  sub rsp, 0x30
00007767631e173e  movaps [rsp], xmm13
00007767631e1743  movaps [rsp+0x10], xmm10
00007767631e1749  movaps [rsp+0x20], xmm14
00007767631e174f  lea rdi, [rsp]
00007767631e1753  mov esi, 0x00
00007767631e1758  mov rax, 0x617961CDB530
00007767631e1762  call rax
00007767631e1764  movaps xmm13, [rsp]
00007767631e1769  add rsp, 0x30
00007767631e176d  vmovaps xmm0, [rsp]
00007767631e1772  vmovaps xmm1, [rsp+0x10]
00007767631e1778  vmovaps xmm2, [rsp+0x20]
00007767631e177e  vmovaps xmm3, [rsp+0x30]
00007767631e1784  vmovaps xmm4, [rsp+0x40]
00007767631e178a  vmovaps xmm5, [rsp+0x50]
00007767631e1790  vmovaps xmm6, [rsp+0x60]
00007767631e1796  vmovaps xmm7, [rsp+0x70]
00007767631e179c  vmovaps xmm8, [rsp+0x80]
00007767631e17a5  vmovaps xmm9, [rsp+0x90]
00007767631e17ae  vmovaps xmm10, [rsp+0xA0]
00007767631e17b7  vmovaps xmm11, [rsp+0xB0]
00007767631e17c0  vmovaps xmm12, [rsp+0xC0]
00007767631e17c9  vmovaps xmm14, [rsp+0xD0]
00007767631e17d2  vmovaps xmm15, [rsp+0xE0]
00007767631e17db  add rsp, 0xF0
00007767631e17e2  pop r11
00007767631e17e4  pop r10
00007767631e17e6  pop r9
00007767631e17e8  pop r8
00007767631e17ea  pop rsi
00007767631e17eb  pop rdi
00007767631e17ec  pop rdx
00007767631e17ed  pop rcx
00007767631e17ee  pop rax
00007767631e17ef  add rsp, 0x08
00007767631e17f3  jmp 0x00007767631DC820
00007767631e17f8  sub rsp, 0x08
00007767631e17fc  push rax
00007767631e17fd  push rcx
00007767631e17fe  push rdx
00007767631e17ff  push rdi
00007767631e1800  push rsi
00007767631e1801  push r8
00007767631e1803  push r9
00007767631e1805  push r10
00007767631e1807  push r11
00007767631e1809  sub rsp, 0xF0
00007767631e1810  vmovaps [rsp], xmm0
00007767631e1815  vmovaps [rsp+0x10], xmm1
00007767631e181b  vmovaps [rsp+0x20], xmm2
00007767631e1821  vmovaps [rsp+0x30], xmm3
00007767631e1827  vmovaps [rsp+0x40], xmm4
00007767631e182d  vmovaps [rsp+0x50], xmm5
00007767631e1833  vmovaps [rsp+0x60], xmm6
00007767631e1839  vmovaps [rsp+0x70], xmm7
00007767631e183f  vmovaps [rsp+0x80], xmm8
00007767631e1848  vmovaps [rsp+0x90], xmm9
00007767631e1851  vmovaps [rsp+0xA0], xmm10
00007767631e185a  vmovaps [rsp+0xB0], xmm11
00007767631e1863  vmovaps [rsp+0xC0], xmm12
00007767631e186c  vmovaps [rsp+0xD0], xmm13
00007767631e1875  vmovaps [rsp+0xE0], xmm15
00007767631e187e  sub rsp, 0x30
00007767631e1882  movaps [rsp], xmm14
00007767631e1887  movaps [rsp+0x10], xmm1
00007767631e188c  movaps [rsp+0x20], xmm7
00007767631e1891  lea rdi, [rsp]
00007767631e1895  mov esi, 0x00
00007767631e189a  mov rax, 0x617961CDB530
00007767631e18a4  call rax
00007767631e18a6  movaps xmm14, [rsp]
00007767631e18ab  add rsp, 0x30
00007767631e18af  vmovaps xmm0, [rsp]
00007767631e18b4  vmovaps xmm1, [rsp+0x10]
00007767631e18ba  vmovaps xmm2, [rsp+0x20]
00007767631e18c0  vmovaps xmm3, [rsp+0x30]
00007767631e18c6  vmovaps xmm4, [rsp+0x40]
00007767631e18cc  vmovaps xmm5, [rsp+0x50]
00007767631e18d2  vmovaps xmm6, [rsp+0x60]
00007767631e18d8  vmovaps xmm7, [rsp+0x70]
00007767631e18de  vmovaps xmm8, [rsp+0x80]
00007767631e18e7  vmovaps xmm9, [rsp+0x90]
00007767631e18f0  vmovaps xmm10, [rsp+0xA0]
00007767631e18f9  vmovaps xmm11, [rsp+0xB0]
00007767631e1902  vmovaps xmm12, [rsp+0xC0]
00007767631e190b  vmovaps xmm13, [rsp+0xD0]
00007767631e1914  vmovaps xmm15, [rsp+0xE0]
00007767631e191d  add rsp, 0xF0
00007767631e1924  pop r11
00007767631e1926  pop r10
00007767631e1928  pop r9
00007767631e192a  pop r8
00007767631e192c  pop rsi
00007767631e192d  pop rdi
00007767631e192e  pop rdx
00007767631e192f  pop rcx
00007767631e1930  pop rax
00007767631e1931  add rsp, 0x08
00007767631e1935  jmp 0x00007767631DC843
00007767631e193a  sub rsp, 0x08
00007767631e193e  push rax
00007767631e193f  push rcx
00007767631e1940  push rdx
00007767631e1941  push rdi
00007767631e1942  push rsi
00007767631e1943  push r8
00007767631e1945  push r9
00007767631e1947  push r10
00007767631e1949  push r11
00007767631e194b  sub rsp, 0xF0
00007767631e1952  vmovaps [rsp], xmm0
00007767631e1957  vmovaps [rsp+0x10], xmm2
00007767631e195d  vmovaps [rsp+0x20], xmm3
00007767631e1963  vmovaps [rsp+0x30], xmm4
00007767631e1969  vmovaps [rsp+0x40], xmm5
00007767631e196f  vmovaps [rsp+0x50], xmm6
00007767631e1975  vmovaps [rsp+0x60], xmm7
00007767631e197b  vmovaps [rsp+0x70], xmm8
00007767631e1981  vmovaps [rsp+0x80], xmm9
00007767631e198a  vmovaps [rsp+0x90], xmm10
00007767631e1993  vmovaps [rsp+0xA0], xmm11
00007767631e199c  vmovaps [rsp+0xB0], xmm12
00007767631e19a5  vmovaps [rsp+0xC0], xmm13
00007767631e19ae  vmovaps [rsp+0xD0], xmm14
00007767631e19b7  vmovaps [rsp+0xE0], xmm15
00007767631e19c0  sub rsp, 0x30
00007767631e19c4  movaps [rsp], xmm1
00007767631e19c8  movaps [rsp+0x10], xmm8
00007767631e19ce  movaps [rsp+0x20], xmm9
00007767631e19d4  lea rdi, [rsp]
00007767631e19d8  mov esi, 0x00
00007767631e19dd  mov rax, 0x617961CDB530
00007767631e19e7  call rax
00007767631e19e9  movaps xmm1, [rsp]
00007767631e19ed  add rsp, 0x30
00007767631e19f1  vmovaps xmm0, [rsp]
00007767631e19f6  vmovaps xmm2, [rsp+0x10]
00007767631e19fc  vmovaps xmm3, [rsp+0x20]
00007767631e1a02  vmovaps xmm4, [rsp+0x30]
00007767631e1a08  vmovaps xmm5, [rsp+0x40]
00007767631e1a0e  vmovaps xmm6, [rsp+0x50]
00007767631e1a14  vmovaps xmm7, [rsp+0x60]
00007767631e1a1a  vmovaps xmm8, [rsp+0x70]
00007767631e1a20  vmovaps xmm9, [rsp+0x80]
00007767631e1a29  vmovaps xmm10, [rsp+0x90]
00007767631e1a32  vmovaps xmm11, [rsp+0xA0]
00007767631e1a3b  vmovaps xmm12, [rsp+0xB0]
00007767631e1a44  vmovaps xmm13, [rsp+0xC0]
00007767631e1a4d  vmovaps xmm14, [rsp+0xD0]
00007767631e1a56  vmovaps xmm15, [rsp+0xE0]
00007767631e1a5f  add rsp, 0xF0
00007767631e1a66  pop r11
00007767631e1a68  pop r10
00007767631e1a6a  pop r9
00007767631e1a6c  pop r8
00007767631e1a6e  pop rsi
00007767631e1a6f  pop rdi
00007767631e1a70  pop rdx
00007767631e1a71  pop rcx
00007767631e1a72  pop rax
00007767631e1a73  add rsp, 0x08
00007767631e1a77  jmp 0x00007767631DC865
00007767631e1a7c  call 0x00007767630E5940
00007767631e1a81  jmp 0x00007767631DC873
00007767631e1a86  call 0x000077676300C380
00007767631e1a8b  jmp 0x00007767631DC87D
00007767631e1a90  call 0x000077676300D600
00007767631e1a95  jmp 0x00007767631DC887
00007767631e1a9a  call 0x0000776762FFF540
00007767631e1a9f  jmp 0x00007767631DC891
00007767631e1aa4  int3
00007767631e1aa5  nop [rax+rax*1], ax
00007767631e1aae  nop
00007767631e1ab0  mov rax, [r15+0xF8]
00007767631e1ab7  lea r14, [rax+0x140]
00007767631e1abe  mov r12, [r13+r14*1]
00007767631e1ac3  mov [r15+0xE8], r12
00007767631e1aca  lea r14, [rax+0x130]
00007767631e1ad1  mov r12, [r13+r14*1]
00007767631e1ad6  lea r14, [rax+0x138]
00007767631e1add  mov r11, [r13+r14*1]
00007767631e1ae2  movq xmm1, r12
00007767631e1ae7  movq xmm15, r11
00007767631e1aec  movq xmm1, xmm1
00007767631e1af0  movq xmm1, xmm1
00007767631e1af4  movaps [r15+0x1A0], xmm1
00007767631e1afc  movq xmm15, xmm15
00007767631e1b01  movq xmm15, xmm15
00007767631e1b06  movaps [r15+0x190], xmm15
00007767631e1b0e  lea r14, [rax+0x120]
00007767631e1b15  mov r12, [r13+r14*1]
00007767631e1b1a  lea r14, [rax+0x128]
00007767631e1b21  mov r11, [r13+r14*1]
00007767631e1b26  movq xmm1, r12
00007767631e1b2b  movq xmm15, r11
00007767631e1b30  movq xmm1, xmm1
00007767631e1b34  movq xmm1, xmm1
00007767631e1b38  movaps [r15+0x1C0], xmm1
00007767631e1b40  movq xmm15, xmm15
00007767631e1b45  movq xmm15, xmm15
00007767631e1b4a  movaps [r15+0x1B0], xmm15
00007767631e1b52  lea r14, [rax+0x110]
00007767631e1b59  mov r12, [r13+r14*1]
00007767631e1b5e  lea r14, [rax+0x118]
00007767631e1b65  mov r11, [r13+r14*1]
00007767631e1b6a  movq xmm1, r12
00007767631e1b6f  movq xmm15, r11
00007767631e1b74  movq xmm1, xmm1
00007767631e1b78  movq xmm1, xmm1
00007767631e1b7c  movaps [r15+0x1E0], xmm1
00007767631e1b84  movq xmm15, xmm15
00007767631e1b89  movq xmm15, xmm15
00007767631e1b8e  movaps [r15+0x1D0], xmm15
00007767631e1b96  lea r14, [rax+0x100]
00007767631e1b9d  mov r12, [r13+r14*1]
00007767631e1ba2  lea r14, [rax+0x108]
00007767631e1ba9  mov r11, [r13+r14*1]
00007767631e1bae  movq xmm1, r12
00007767631e1bb3  movq xmm15, r11
00007767631e1bb8  movq xmm1, xmm1
00007767631e1bbc  movq xmm1, xmm1
00007767631e1bc0  movaps [r15+0x200], xmm1
00007767631e1bc8  movq xmm15, xmm15
00007767631e1bcd  movq xmm15, xmm15
00007767631e1bd2  movaps [r15+0x1F0], xmm15
00007767631e1bda  mov qword ptr [r15+0x40], 0x430000
00007767631e1be2  mov r14d, 0x430510
00007767631e1be8  mov r12, [r13+r14*1]
00007767631e1bed  movq xmm1, r12
00007767631e1bf2  lea r14, [rax+0x150]
00007767631e1bf9  mov [r15+0xF8], r14
00007767631e1c00  mov rax, [r15+0x50]
00007767631e1c04  movups xmm15, [r13+rax*1]
00007767631e1c0a  movaps [r15+0x120], xmm15
00007767631e1c12  mov qword ptr [r15+0x48], 0x10
00007767631e1c1a  xor eax, eax
00007767631e1c1c  mov r14d, 0x10
00007767631e1c22  mov r12d, 0x200
00007767631e1c28  cmp r14, r12
00007767631e1c2b  cmc
00007767631e1c2c  lahf
00007767631e1c2d  seto al
00007767631e1c30  mov [r15+0x108], eax
00007767631e1c37  pextrq rax, xmm15, 0x01
00007767631e1c3e  movq xmm14, rax
00007767631e1c43  movaps [r15+0x130], xmm14
00007767631e1c4b  movq rax, xmm1
00007767631e1c50  movq r14, xmm15
00007767631e1c55  vmovq xmm1, rax
00007767631e1c5a  vmovq xmm15, r14
00007767631e1c5f  movaps xmm13, xmm1
00007767631e1c63  addsd xmm13, xmm15
00007767631e1c68  ucomisd xmm13, xmm13
00007767631e1c6d  jp 0x00007767631E1D86
00007767631e1c73  movq xmm13, xmm13
00007767631e1c78  movq rax, xmm13
00007767631e1c7d  movq r14, xmm14
00007767631e1c82  vmovq xmm1, rax
00007767631e1c87  vmovq xmm15, r14
00007767631e1c8c  movaps xmm14, xmm1
00007767631e1c90  addsd xmm14, xmm15
00007767631e1c95  ucomisd xmm14, xmm14
00007767631e1c9a  jp 0x00007767631E1DCE
00007767631e1ca0  movq xmm14, xmm14
00007767631e1ca5  movaps [r15+0x110], xmm14
00007767631e1cad  mov eax, [r15+0x108]
00007767631e1cb4  sahf
00007767631e1cb5  jnz 0x00007767631E1CE7
00007767631e1cb7  cmp dword ptr [r15+0x318], 0x00
00007767631e1cbf  jz 0x00007767631E1FE0
00007767631e1cc5  nop [rax+rax*1], ax
00007767631e1cce  nop [rax+rax*1], eax
00007767631e1cd6  mov eax, 0x410490
00007767631e1cdb  mov [r15+0x100], rax
00007767631e1ce2  jmp 0x0000776762FFE110
00007767631e1ce7  cmp dword ptr [r15+0x318], 0x00
00007767631e1cef  jz 0x00007767631E1E20
00007767631e1cf5  nop [rax+rax*1], ax
00007767631e1cfe  nop [rax+rax*1], eax
00007767631e1d06  mov eax, 0x410474
00007767631e1d0b  mov [r15+0x100], rax
00007767631e1d12  jmp 0x0000776762FFE110
00007767631e1d17  int3
00007767631e1d18  call 0x00007767630E27E0
00007767631e1d1d  jmp 0x00007767631E1AC3
00007767631e1d22  call 0x00007767630E27E0
00007767631e1d27  jmp 0x00007767631E1AD6
00007767631e1d2c  call 0x00007767630E1570
00007767631e1d31  jmp 0x00007767631E1AE2
00007767631e1d36  call 0x00007767630E27E0
00007767631e1d3b  jmp 0x00007767631E1B1A
00007767631e1d40  call 0x00007767630E1570
00007767631e1d45  jmp 0x00007767631E1B26
00007767631e1d4a  call 0x00007767630E27E0
00007767631e1d4f  jmp 0x00007767631E1B5E
00007767631e1d54  call 0x00007767630E1570
00007767631e1d59  jmp 0x00007767631E1B6A
00007767631e1d5e  call 0x00007767630E27E0
00007767631e1d63  jmp 0x00007767631E1BA2
00007767631e1d68  call 0x00007767630E1570
00007767631e1d6d  jmp 0x00007767631E1BAE
00007767631e1d72  call 0x00007767630E27E0
00007767631e1d77  jmp 0x00007767631E1BED
00007767631e1d7c  call 0x000077676300E760
00007767631e1d81  jmp 0x00007767631E1C0A
00007767631e1d86  ucomisd xmm1, xmm15
00007767631e1d8b  jp 0x00007767631E1D9A
00007767631e1d8d  movaps xmm13, [0x0000776762DFE060]
00007767631e1d95  jmp 0x00007767631E1C73
00007767631e1d9a  vxorps xmm0, xmm1, xmm15
00007767631e1d9f  pextrw eax, xmm0, 0x03
00007767631e1da4  and eax, 0x7FF8
00007767631e1da9  cmp eax, 0x08
00007767631e1dac  jnz 0x00007767631E1C73
00007767631e1db2  movq rax, xmm15
00007767631e1db7  shl rax, 0x0D
00007767631e1dbb  jbe 0x00007767631E1C73
00007767631e1dc1  vorps xmm13, xmm15, [0x0000776762DFE070]
00007767631e1dc9  jmp 0x00007767631E1C73
00007767631e1dce  ucomisd xmm1, xmm15
00007767631e1dd3  jp 0x00007767631E1DE2
00007767631e1dd5  movaps xmm14, [0x0000776762DFE060]
00007767631e1ddd  jmp 0x00007767631E1CA0
00007767631e1de2  vxorps xmm0, xmm1, xmm15
00007767631e1de7  pextrw eax, xmm0, 0x03
00007767631e1dec  and eax, 0x7FF8
00007767631e1df1  cmp eax, 0x08
00007767631e1df4  jnz 0x00007767631E1CA0
00007767631e1dfa  movq rax, xmm15
00007767631e1dff  shl rax, 0x0D
00007767631e1e03  jbe 0x00007767631E1CA0
00007767631e1e09  vorps xmm14, xmm15, [0x0000776762DFE070]
00007767631e1e11  jmp 0x00007767631E1CA0
00007767631e1e16  int3
00007767631e1e17  nop [rax+rax*1], ax
00007767631e1e20  mov rax, [r15+0x48]
00007767631e1e24  mov r14, [r15+0x50]
00007767631e1e28  lea r12, [r14+rax*1]
00007767631e1e2c  movups xmm1, [r13+r12*1]
00007767631e1e32  movaps [r15+0x120], xmm1
00007767631e1e3a  lea r14, [rax+0x10]
00007767631e1e3e  mov [r15+0x48], r14
00007767631e1e42  xor eax, eax
00007767631e1e44  mov r12d, 0x200
00007767631e1e4a  cmp r14, r12
00007767631e1e4d  cmc
00007767631e1e4e  lahf
00007767631e1e4f  seto al
00007767631e1e52  mov [r15+0x108], eax
00007767631e1e59  pextrq rax, xmm1, 0x01
00007767631e1e60  movq xmm15, rax
00007767631e1e65  movaps [r15+0x130], xmm15
00007767631e1e6d  movaps xmm14, [r15+0x110]
00007767631e1e75  movq rax, xmm14
00007767631e1e7a  movq r14, xmm1
00007767631e1e7f  vmovq xmm1, rax
00007767631e1e84  vmovq xmm14, r14
00007767631e1e89  movaps xmm13, xmm1
00007767631e1e8d  addsd xmm13, xmm14
00007767631e1e92  ucomisd xmm13, xmm13
00007767631e1e97  jp 0x00007767631E1F4C
00007767631e1e9d  movq xmm13, xmm13
00007767631e1ea2  movq rax, xmm13
00007767631e1ea7  movq r14, xmm15
00007767631e1eac  vmovq xmm1, rax
00007767631e1eb1  vmovq xmm15, r14
00007767631e1eb6  movaps xmm14, xmm1
00007767631e1eba  addsd xmm14, xmm15
00007767631e1ebf  ucomisd xmm14, xmm14
00007767631e1ec4  jp 0x00007767631E1F94
00007767631e1eca  movq xmm14, xmm14
00007767631e1ecf  movaps [r15+0x110], xmm14
00007767631e1ed7  mov eax, [r15+0x108]
00007767631e1ede  sahf
00007767631e1edf  jnz 0x00007767631E1F11
00007767631e1ee1  cmp dword ptr [r15+0x318], 0x00
00007767631e1ee9  jz 0x00007767631E1FE0
00007767631e1eef  nop [rax+rax*1], ax
00007767631e1ef8  nop [rax+rax*1], eax
00007767631e1f00  mov eax, 0x410490
00007767631e1f05  mov [r15+0x100], rax
00007767631e1f0c  jmp 0x0000776762FFE110
00007767631e1f11  cmp dword ptr [r15+0x318], 0x00
00007767631e1f19  jz 0x00007767631E1E20
00007767631e1f1f  nop [rax+rax*1], ax
00007767631e1f28  nop [rax+rax*1], eax
00007767631e1f30  mov eax, 0x410474
00007767631e1f35  mov [r15+0x100], rax
00007767631e1f3c  jmp 0x0000776762FFE110
00007767631e1f41  int3
00007767631e1f42  call 0x00007767630B52F0
00007767631e1f47  jmp 0x00007767631E1E32
00007767631e1f4c  ucomisd xmm1, xmm14
00007767631e1f51  jp 0x00007767631E1F60
00007767631e1f53  movaps xmm13, [0x0000776762DFE060]
00007767631e1f5b  jmp 0x00007767631E1E9D
00007767631e1f60  vxorps xmm0, xmm1, xmm14
00007767631e1f65  pextrw eax, xmm0, 0x03
00007767631e1f6a  and eax, 0x7FF8
00007767631e1f6f  cmp eax, 0x08
00007767631e1f72  jnz 0x00007767631E1E9D
00007767631e1f78  movq rax, xmm14
00007767631e1f7d  shl rax, 0x0D
00007767631e1f81  jbe 0x00007767631E1E9D
00007767631e1f87  vorps xmm13, xmm14, [0x0000776762DFE070]
00007767631e1f8f  jmp 0x00007767631E1E9D
00007767631e1f94  ucomisd xmm1, xmm15
00007767631e1f99  jp 0x00007767631E1FA8
00007767631e1f9b  movaps xmm14, [0x0000776762DFE060]
00007767631e1fa3  jmp 0x00007767631E1ECA
00007767631e1fa8  vxorps xmm0, xmm1, xmm15
00007767631e1fad  pextrw eax, xmm0, 0x03
00007767631e1fb2  and eax, 0x7FF8
00007767631e1fb7  cmp eax, 0x08
00007767631e1fba  jnz 0x00007767631E1ECA
00007767631e1fc0  movq rax, xmm15
00007767631e1fc5  shl rax, 0x0D
00007767631e1fc9  jbe 0x00007767631E1ECA
00007767631e1fcf  vorps xmm14, xmm15, [0x0000776762DFE070]
00007767631e1fd7  jmp 0x00007767631E1ECA
00007767631e1fdc  int3
00007767631e1fdd  nop [rax], eax
00007767631e1fe0  mov rax, [r15+0x40]
00007767631e1fe4  lea r14, [rax+0x510]
00007767631e1feb  movaps xmm1, [r15+0x110]
00007767631e1ff3  movq rax, xmm1
00007767631e1ff8  mov [r13+r14*1], rax
00007767631e1ffd  mov rax, [r15+0xF0]
00007767631e2004  mov [r15+0x100], rax
00007767631e200b  jmp 0x00007767631CE5C0
00007767631e2010  int3
00007767631e2011  call 0x00007767630D5EB0
00007767631e2016  jmp 0x00007767631E1FFD
00007767631e201b  int3
00007767631e201c  nop [rax], eax
00007767631e2020  mov qword ptr [r15+0x100], 0x04
00007767631e202b  mov esi, 0x00
00007767631e2030  mov edx, 0x09
00007767631e2035  mov rdi, 0x7FFFDE62FBD0
00007767631e203f  mov rax, 0x617961B6E970
00007767631e2049  call rax
00007767631e204b  cmp dword ptr [r15+0x318], 0x00
00007767631e2053  jnz 0x0000776762FFE110
00007767631e2059  jmp 0x0000776762FFE0A0
00007767631e205e  int3
00007767631e205f  int3
