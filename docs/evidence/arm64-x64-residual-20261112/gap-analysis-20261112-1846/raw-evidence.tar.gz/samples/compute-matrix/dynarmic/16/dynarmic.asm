000070dabbdce69b  nop [rax+rax*1], eax
000070dabbdce6a0  vmovaps xmm1, [0x000070DABB9FE010]
000070dabbdce6a8  movq xmm1, xmm1
000070dabbdce6ac  movaps [r15+0x110], xmm1
000070dabbdce6b4  vmovaps xmm1, [0x000070DABB9FE020]
000070dabbdce6bc  movq xmm1, xmm1
000070dabbdce6c0  movaps [r15+0x120], xmm1
000070dabbdce6c8  mov eax, 0x4204C0
000070dabbdce6cd  mov r14, [r13+rax*1]
000070dabbdce6d2  movq xmm1, r14
000070dabbdce6d7  movaps [r15+0x130], xmm1
000070dabbdce6df  vmovaps xmm1, [0x000070DABB9FE030]
000070dabbdce6e7  vpbroadcastq xmm1, xmm1
000070dabbdce6ec  movaps [r15+0x140], xmm1
000070dabbdce6f4  mov qword ptr [r15+0x40], 0x02
000070dabbdce6fc  vmovaps xmm15, [0x000070DABB9FE040]
000070dabbdce704  movq xmm15, xmm15
000070dabbdce709  movaps [r15+0x150], xmm15
000070dabbdce711  mov qword ptr [r15+0x58], 0x420000
000070dabbdce719  vmovaps xmm15, [0x000070DABB9FE050]
000070dabbdce721  vpbroadcastq xmm15, xmm15
000070dabbdce726  movaps [r15+0x160], xmm15
000070dabbdce72e  mov rax, [r15+0x40]
000070dabbdce732  vmovq xmm14, rax
000070dabbdce737  vpbroadcastq xmm14, xmm14
000070dabbdce73c  movaps [r15+0x170], xmm14
000070dabbdce744  mov eax, 0x4204D0
000070dabbdce749  movups xmm13, [r13+rax*1]
000070dabbdce74f  mov qword ptr [r15+0x40], 0x430518
000070dabbdce757  mov qword ptr [r15+0x50], 0x430720
000070dabbdce75f  vpmovqd xmm12, xmm13
000070dabbdce765  pxor xmm11, xmm11
000070dabbdce76a  punpcklqdq xmm12, xmm11
000070dabbdce76f  movaps [r15+0x210], xmm12
000070dabbdce777  movq xmm12, qword ptr [r15+0x120]
000070dabbdce780  movq xmm11, qword ptr [r15+0x130]
000070dabbdce789  psubd xmm12, xmm11
000070dabbdce78e  movq xmm12, xmm12
000070dabbdce793  paddq xmm13, xmm14
000070dabbdce798  movaps [r15+0x180], xmm13
000070dabbdce7a0  movq xmm14, qword ptr [r15+0x150]
000070dabbdce7a9  paddd xmm11, xmm14
000070dabbdce7ae  movq xmm11, xmm11
000070dabbdce7b3  movq xmm11, xmm11
000070dabbdce7b8  movaps [r15+0x130], xmm11
000070dabbdce7c0  pmovzxdq xmm12, xmm12
000070dabbdce7c6  psllq xmm12, 0x00
000070dabbdce7cc  movq xmm14, qword ptr [r15+0x210]
000070dabbdce7d5  movq xmm13, qword ptr [r15+0x110]
000070dabbdce7de  paddd xmm14, xmm13
000070dabbdce7e3  movq xmm14, xmm14
000070dabbdce7e8  vcvtuqq2pd xmm12, xmm12
000070dabbdce7ee  pmovzxdq xmm14, xmm14
000070dabbdce7f4  psllq xmm14, 0x00
000070dabbdce7fa  vcvtuqq2pd xmm14, xmm14
000070dabbdce800  movaps xmm13, xmm12
000070dabbdce804  mulpd xmm13, xmm1
000070dabbdce809  vcmppd xmm11, xmm13, xmm13, 0x03
000070dabbdce80f  ptest xmm11, xmm11
000070dabbdce815  jnz 0x000070DABBDCE8FF
000070dabbdce81b  movaps [r15+0x220], xmm13
000070dabbdce823  mov eax, 0x430720
000070dabbdce828  movups [r13+rax*1], xmm13
000070dabbdce82e  movaps xmm1, xmm14
000070dabbdce832  mulpd xmm1, xmm15
000070dabbdce837  vcmppd xmm13, xmm1, xmm1, 0x03
000070dabbdce83c  ptest xmm13, xmm13
000070dabbdce842  jnz 0x000070DABBDCEA4C
000070dabbdce848  movaps [r15+0x210], xmm1
000070dabbdce850  mov eax, 0x430518
000070dabbdce855  movups [r13+rax*1], xmm1
000070dabbdce85b  mov qword ptr [r15+0x48], 0x10
000070dabbdce863  xor eax, eax
000070dabbdce865  mov r14d, 0x10
000070dabbdce86b  mov r12d, 0x200
000070dabbdce871  cmp r14, r12
000070dabbdce874  cmc
000070dabbdce875  lahf
000070dabbdce876  seto al
000070dabbdce879  mov [r15+0x108], eax
000070dabbdce880  mov eax, [r15+0x108]
000070dabbdce887  sahf
000070dabbdce888  jnz 0x000070DABBDCE8BA
000070dabbdce88a  cmp dword ptr [r15+0x318], 0x00
000070dabbdce892  jz 0x000070DABBDCEFF0
000070dabbdce898  nop [rax+rax*1], ax
000070dabbdce8a1  nop [rax+rax*1], eax
000070dabbdce8a9  mov eax, 0x4101EC
000070dabbdce8ae  mov [r15+0x100], rax
000070dabbdce8b5  jmp 0x000070DABBBFE110
000070dabbdce8ba  cmp dword ptr [r15+0x318], 0x00
000070dabbdce8c2  jz 0x000070DABBDCEBA0
000070dabbdce8c8  nop [rax+rax*1], ax
000070dabbdce8d1  nop [rax+rax*1], eax
000070dabbdce8d9  mov eax, 0x4101AC
000070dabbdce8de  mov [r15+0x100], rax
000070dabbdce8e5  jmp 0x000070DABBBFE110
000070dabbdce8ea  int3
000070dabbdce8eb  call 0x000070DABBC0DC20
000070dabbdce8f0  jmp 0x000070DABBDCE6D2
000070dabbdce8f5  call 0x000070DABBC0C260
000070dabbdce8fa  jmp 0x000070DABBDCE74F
000070dabbdce8ff  sub rsp, 0x08
000070dabbdce903  push rax
000070dabbdce904  push rcx
000070dabbdce905  push rdx
000070dabbdce906  push rdi
000070dabbdce907  push rsi
000070dabbdce908  push r8
000070dabbdce90a  push r9
000070dabbdce90c  push r10
000070dabbdce90e  push r11
000070dabbdce910  sub rsp, 0xF0
000070dabbdce917  vmovaps [rsp], xmm0
000070dabbdce91c  vmovaps [rsp+0x10], xmm1
000070dabbdce922  vmovaps [rsp+0x20], xmm2
000070dabbdce928  vmovaps [rsp+0x30], xmm3
000070dabbdce92e  vmovaps [rsp+0x40], xmm4
000070dabbdce934  vmovaps [rsp+0x50], xmm5
000070dabbdce93a  vmovaps [rsp+0x60], xmm6
000070dabbdce940  vmovaps [rsp+0x70], xmm7
000070dabbdce946  vmovaps [rsp+0x80], xmm8
000070dabbdce94f  vmovaps [rsp+0x90], xmm9
000070dabbdce958  vmovaps [rsp+0xA0], xmm10
000070dabbdce961  vmovaps [rsp+0xB0], xmm11
000070dabbdce96a  vmovaps [rsp+0xC0], xmm12
000070dabbdce973  vmovaps [rsp+0xD0], xmm14
000070dabbdce97c  vmovaps [rsp+0xE0], xmm15
000070dabbdce985  sub rsp, 0x30
000070dabbdce989  movaps [rsp], xmm13
000070dabbdce98e  movaps [rsp+0x10], xmm12
000070dabbdce994  movaps [rsp+0x20], xmm1
000070dabbdce999  lea rdi, [rsp]
000070dabbdce99d  mov esi, 0x00
000070dabbdce9a2  mov rax, 0x5C2CF7B6F530
000070dabbdce9ac  call rax
000070dabbdce9ae  movaps xmm13, [rsp]
000070dabbdce9b3  add rsp, 0x30
000070dabbdce9b7  vmovaps xmm0, [rsp]
000070dabbdce9bc  vmovaps xmm1, [rsp+0x10]
000070dabbdce9c2  vmovaps xmm2, [rsp+0x20]
000070dabbdce9c8  vmovaps xmm3, [rsp+0x30]
000070dabbdce9ce  vmovaps xmm4, [rsp+0x40]
000070dabbdce9d4  vmovaps xmm5, [rsp+0x50]
000070dabbdce9da  vmovaps xmm6, [rsp+0x60]
000070dabbdce9e0  vmovaps xmm7, [rsp+0x70]
000070dabbdce9e6  vmovaps xmm8, [rsp+0x80]
000070dabbdce9ef  vmovaps xmm9, [rsp+0x90]
000070dabbdce9f8  vmovaps xmm10, [rsp+0xA0]
000070dabbdcea01  vmovaps xmm11, [rsp+0xB0]
000070dabbdcea0a  vmovaps xmm12, [rsp+0xC0]
000070dabbdcea13  vmovaps xmm14, [rsp+0xD0]
000070dabbdcea1c  vmovaps xmm15, [rsp+0xE0]
000070dabbdcea25  add rsp, 0xF0
000070dabbdcea2c  pop r11
000070dabbdcea2e  pop r10
000070dabbdcea30  pop r9
000070dabbdcea32  pop r8
000070dabbdcea34  pop rsi
000070dabbdcea35  pop rdi
000070dabbdcea36  pop rdx
000070dabbdcea37  pop rcx
000070dabbdcea38  pop rax
000070dabbdcea39  add rsp, 0x08
000070dabbdcea3d  jmp 0x000070DABBDCE81B
000070dabbdcea42  call 0x000070DABBC0C380
000070dabbdcea47  jmp 0x000070DABBDCE82E
000070dabbdcea4c  sub rsp, 0x08
000070dabbdcea50  push rax
000070dabbdcea51  push rcx
000070dabbdcea52  push rdx
000070dabbdcea53  push rdi
000070dabbdcea54  push rsi
000070dabbdcea55  push r8
000070dabbdcea57  push r9
000070dabbdcea59  push r10
000070dabbdcea5b  push r11
000070dabbdcea5d  sub rsp, 0xF0
000070dabbdcea64  vmovaps [rsp], xmm0
000070dabbdcea69  vmovaps [rsp+0x10], xmm2
000070dabbdcea6f  vmovaps [rsp+0x20], xmm3
000070dabbdcea75  vmovaps [rsp+0x30], xmm4
000070dabbdcea7b  vmovaps [rsp+0x40], xmm5
000070dabbdcea81  vmovaps [rsp+0x50], xmm6
000070dabbdcea87  vmovaps [rsp+0x60], xmm7
000070dabbdcea8d  vmovaps [rsp+0x70], xmm8
000070dabbdcea93  vmovaps [rsp+0x80], xmm9
000070dabbdcea9c  vmovaps [rsp+0x90], xmm10
000070dabbdceaa5  vmovaps [rsp+0xA0], xmm11
000070dabbdceaae  vmovaps [rsp+0xB0], xmm12
000070dabbdceab7  vmovaps [rsp+0xC0], xmm13
000070dabbdceac0  vmovaps [rsp+0xD0], xmm14
000070dabbdceac9  vmovaps [rsp+0xE0], xmm15
000070dabbdcead2  sub rsp, 0x30
000070dabbdcead6  movaps [rsp], xmm1
000070dabbdceada  movaps [rsp+0x10], xmm14
000070dabbdceae0  movaps [rsp+0x20], xmm15
000070dabbdceae6  lea rdi, [rsp]
000070dabbdceaea  mov esi, 0x00
000070dabbdceaef  mov rax, 0x5C2CF7B6F530
000070dabbdceaf9  call rax
000070dabbdceafb  movaps xmm1, [rsp]
000070dabbdceaff  add rsp, 0x30
000070dabbdceb03  vmovaps xmm0, [rsp]
000070dabbdceb08  vmovaps xmm2, [rsp+0x10]
000070dabbdceb0e  vmovaps xmm3, [rsp+0x20]
000070dabbdceb14  vmovaps xmm4, [rsp+0x30]
000070dabbdceb1a  vmovaps xmm5, [rsp+0x40]
000070dabbdceb20  vmovaps xmm6, [rsp+0x50]
000070dabbdceb26  vmovaps xmm7, [rsp+0x60]
000070dabbdceb2c  vmovaps xmm8, [rsp+0x70]
000070dabbdceb32  vmovaps xmm9, [rsp+0x80]
000070dabbdceb3b  vmovaps xmm10, [rsp+0x90]
000070dabbdceb44  vmovaps xmm11, [rsp+0xA0]
000070dabbdceb4d  vmovaps xmm12, [rsp+0xB0]
000070dabbdceb56  vmovaps xmm13, [rsp+0xC0]
000070dabbdceb5f  vmovaps xmm14, [rsp+0xD0]
000070dabbdceb68  vmovaps xmm15, [rsp+0xE0]
000070dabbdceb71  add rsp, 0xF0
000070dabbdceb78  pop r11
000070dabbdceb7a  pop r10
000070dabbdceb7c  pop r9
000070dabbdceb7e  pop r8
000070dabbdceb80  pop rsi
000070dabbdceb81  pop rdi
000070dabbdceb82  pop rdx
000070dabbdceb83  pop rcx
000070dabbdceb84  pop rax
000070dabbdceb85  add rsp, 0x08
000070dabbdceb89  jmp 0x000070DABBDCE848
000070dabbdceb8e  call 0x000070DABBBFF540
000070dabbdceb93  jmp 0x000070DABBDCE85B
000070dabbdceb98  int3
000070dabbdceb99  nop [rax], eax
000070dabbdceba0  movaps xmm1, [r15+0x180]
000070dabbdceba8  vpmovqd xmm15, xmm1
000070dabbdcebae  pxor xmm14, xmm14
000070dabbdcebb3  punpcklqdq xmm15, xmm14
000070dabbdcebb8  movaps [r15+0x210], xmm15
000070dabbdcebc0  movq xmm15, qword ptr [r15+0x120]
000070dabbdcebc9  movq xmm14, qword ptr [r15+0x130]
000070dabbdcebd2  psubd xmm15, xmm14
000070dabbdcebd7  movq xmm15, xmm15
000070dabbdcebdc  movaps xmm13, [r15+0x170]
000070dabbdcebe4  paddq xmm1, xmm13
000070dabbdcebe9  movaps [r15+0x180], xmm1
000070dabbdcebf1  movq xmm1, qword ptr [r15+0x150]
000070dabbdcebfa  paddd xmm14, xmm1
000070dabbdcebff  movq xmm14, xmm14
000070dabbdcec04  movq xmm14, xmm14
000070dabbdcec09  movaps [r15+0x130], xmm14
000070dabbdcec11  pmovzxdq xmm15, xmm15
000070dabbdcec17  psllq xmm15, 0x00
000070dabbdcec1d  movq xmm1, qword ptr [r15+0x210]
000070dabbdcec26  movq xmm14, qword ptr [r15+0x110]
000070dabbdcec2f  paddd xmm1, xmm14
000070dabbdcec34  movq xmm1, xmm1
000070dabbdcec38  vcvtuqq2pd xmm15, xmm15
000070dabbdcec3e  pmovzxdq xmm1, xmm1
000070dabbdcec43  psllq xmm1, 0x00
000070dabbdcec48  vcvtuqq2pd xmm1, xmm1
000070dabbdcec4e  movaps xmm14, [r15+0x140]
000070dabbdcec56  movaps xmm13, xmm15
000070dabbdcec5a  mulpd xmm13, xmm14
000070dabbdcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000070dabbdcec65  ptest xmm12, xmm12
000070dabbdcec6b  jnz 0x000070DABBDCED4E
000070dabbdcec71  movaps [r15+0x220], xmm13
000070dabbdcec79  mov rax, [r15+0x48]
000070dabbdcec7d  mov r14, [r15+0x50]
000070dabbdcec81  lea r12, [r14+rax*1]
000070dabbdcec85  movups [r13+r12*1], xmm13
000070dabbdcec8b  movaps xmm15, [r15+0x160]
000070dabbdcec93  movaps xmm14, xmm1
000070dabbdcec97  mulpd xmm14, xmm15
000070dabbdcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000070dabbdceca2  ptest xmm13, xmm13
000070dabbdceca8  jnz 0x000070DABBDCEE9C
000070dabbdcecae  movaps [r15+0x210], xmm14
000070dabbdcecb6  mov r14, [r15+0x40]
000070dabbdcecba  lea r12, [r14+rax*1]
000070dabbdcecbe  movups [r13+r12*1], xmm14
000070dabbdcecc4  lea r14, [rax+0x10]
000070dabbdcecc8  mov [r15+0x48], r14
000070dabbdceccc  xor eax, eax
000070dabbdcecce  mov r12d, 0x200
000070dabbdcecd4  cmp r14, r12
000070dabbdcecd7  cmc
000070dabbdcecd8  lahf
000070dabbdcecd9  seto al
000070dabbdcecdc  mov [r15+0x108], eax
000070dabbdcece3  mov eax, [r15+0x108]
000070dabbdcecea  sahf
000070dabbdceceb  jnz 0x000070DABBDCED1D
000070dabbdceced  cmp dword ptr [r15+0x318], 0x00
000070dabbdcecf5  jz 0x000070DABBDCEFF0
000070dabbdcecfb  nop [rax+rax*1], ax
000070dabbdced04  nop [rax+rax*1], eax
000070dabbdced0c  mov eax, 0x4101EC
000070dabbdced11  mov [r15+0x100], rax
000070dabbdced18  jmp 0x000070DABBBFE110
000070dabbdced1d  cmp dword ptr [r15+0x318], 0x00
000070dabbdced25  jz 0x000070DABBDCEBA0
000070dabbdced2b  nop [rax+rax*1], ax
000070dabbdced34  nop [rax+rax*1], eax
000070dabbdced3c  mov eax, 0x4101AC
000070dabbdced41  mov [r15+0x100], rax
000070dabbdced48  jmp 0x000070DABBBFE110
000070dabbdced4d  int3
000070dabbdced4e  sub rsp, 0x08
000070dabbdced52  push rax
000070dabbdced53  push rcx
000070dabbdced54  push rdx
000070dabbdced55  push rdi
000070dabbdced56  push rsi
000070dabbdced57  push r8
000070dabbdced59  push r9
000070dabbdced5b  push r10
000070dabbdced5d  push r11
000070dabbdced5f  sub rsp, 0xF0
000070dabbdced66  vmovaps [rsp], xmm0
000070dabbdced6b  vmovaps [rsp+0x10], xmm1
000070dabbdced71  vmovaps [rsp+0x20], xmm2
000070dabbdced77  vmovaps [rsp+0x30], xmm3
000070dabbdced7d  vmovaps [rsp+0x40], xmm4
000070dabbdced83  vmovaps [rsp+0x50], xmm5
000070dabbdced89  vmovaps [rsp+0x60], xmm6
000070dabbdced8f  vmovaps [rsp+0x70], xmm7
000070dabbdced95  vmovaps [rsp+0x80], xmm8
000070dabbdced9e  vmovaps [rsp+0x90], xmm9
000070dabbdceda7  vmovaps [rsp+0xA0], xmm10
000070dabbdcedb0  vmovaps [rsp+0xB0], xmm11
000070dabbdcedb9  vmovaps [rsp+0xC0], xmm12
000070dabbdcedc2  vmovaps [rsp+0xD0], xmm14
000070dabbdcedcb  vmovaps [rsp+0xE0], xmm15
000070dabbdcedd4  sub rsp, 0x30
000070dabbdcedd8  movaps [rsp], xmm13
000070dabbdceddd  movaps [rsp+0x10], xmm15
000070dabbdcede3  movaps [rsp+0x20], xmm14
000070dabbdcede9  lea rdi, [rsp]
000070dabbdceded  mov esi, 0x00
000070dabbdcedf2  mov rax, 0x5C2CF7B6F530
000070dabbdcedfc  call rax
000070dabbdcedfe  movaps xmm13, [rsp]
000070dabbdcee03  add rsp, 0x30
000070dabbdcee07  vmovaps xmm0, [rsp]
000070dabbdcee0c  vmovaps xmm1, [rsp+0x10]
000070dabbdcee12  vmovaps xmm2, [rsp+0x20]
000070dabbdcee18  vmovaps xmm3, [rsp+0x30]
000070dabbdcee1e  vmovaps xmm4, [rsp+0x40]
000070dabbdcee24  vmovaps xmm5, [rsp+0x50]
000070dabbdcee2a  vmovaps xmm6, [rsp+0x60]
000070dabbdcee30  vmovaps xmm7, [rsp+0x70]
000070dabbdcee36  vmovaps xmm8, [rsp+0x80]
000070dabbdcee3f  vmovaps xmm9, [rsp+0x90]
000070dabbdcee48  vmovaps xmm10, [rsp+0xA0]
000070dabbdcee51  vmovaps xmm11, [rsp+0xB0]
000070dabbdcee5a  vmovaps xmm12, [rsp+0xC0]
000070dabbdcee63  vmovaps xmm14, [rsp+0xD0]
000070dabbdcee6c  vmovaps xmm15, [rsp+0xE0]
000070dabbdcee75  add rsp, 0xF0
000070dabbdcee7c  pop r11
000070dabbdcee7e  pop r10
000070dabbdcee80  pop r9
000070dabbdcee82  pop r8
000070dabbdcee84  pop rsi
000070dabbdcee85  pop rdi
000070dabbdcee86  pop rdx
000070dabbdcee87  pop rcx
000070dabbdcee88  pop rax
000070dabbdcee89  add rsp, 0x08
000070dabbdcee8d  jmp 0x000070DABBDCEC71
000070dabbdcee92  call 0x000070DABBCC2240
000070dabbdcee97  jmp 0x000070DABBDCEC8B
000070dabbdcee9c  sub rsp, 0x08
000070dabbdceea0  push rax
000070dabbdceea1  push rcx
000070dabbdceea2  push rdx
000070dabbdceea3  push rdi
000070dabbdceea4  push rsi
000070dabbdceea5  push r8
000070dabbdceea7  push r9
000070dabbdceea9  push r10
000070dabbdceeab  push r11
000070dabbdceead  sub rsp, 0xF0
000070dabbdceeb4  vmovaps [rsp], xmm0
000070dabbdceeb9  vmovaps [rsp+0x10], xmm1
000070dabbdceebf  vmovaps [rsp+0x20], xmm2
000070dabbdceec5  vmovaps [rsp+0x30], xmm3
000070dabbdceecb  vmovaps [rsp+0x40], xmm4
000070dabbdceed1  vmovaps [rsp+0x50], xmm5
000070dabbdceed7  vmovaps [rsp+0x60], xmm6
000070dabbdceedd  vmovaps [rsp+0x70], xmm7
000070dabbdceee3  vmovaps [rsp+0x80], xmm8
000070dabbdceeec  vmovaps [rsp+0x90], xmm9
000070dabbdceef5  vmovaps [rsp+0xA0], xmm10
000070dabbdceefe  vmovaps [rsp+0xB0], xmm11
000070dabbdcef07  vmovaps [rsp+0xC0], xmm12
000070dabbdcef10  vmovaps [rsp+0xD0], xmm13
000070dabbdcef19  vmovaps [rsp+0xE0], xmm15
000070dabbdcef22  sub rsp, 0x30
000070dabbdcef26  movaps [rsp], xmm14
000070dabbdcef2b  movaps [rsp+0x10], xmm1
000070dabbdcef30  movaps [rsp+0x20], xmm15
000070dabbdcef36  lea rdi, [rsp]
000070dabbdcef3a  mov esi, 0x00
000070dabbdcef3f  mov rax, 0x5C2CF7B6F530
000070dabbdcef49  call rax
000070dabbdcef4b  movaps xmm14, [rsp]
000070dabbdcef50  add rsp, 0x30
000070dabbdcef54  vmovaps xmm0, [rsp]
000070dabbdcef59  vmovaps xmm1, [rsp+0x10]
000070dabbdcef5f  vmovaps xmm2, [rsp+0x20]
000070dabbdcef65  vmovaps xmm3, [rsp+0x30]
000070dabbdcef6b  vmovaps xmm4, [rsp+0x40]
000070dabbdcef71  vmovaps xmm5, [rsp+0x50]
000070dabbdcef77  vmovaps xmm6, [rsp+0x60]
000070dabbdcef7d  vmovaps xmm7, [rsp+0x70]
000070dabbdcef83  vmovaps xmm8, [rsp+0x80]
000070dabbdcef8c  vmovaps xmm9, [rsp+0x90]
000070dabbdcef95  vmovaps xmm10, [rsp+0xA0]
000070dabbdcef9e  vmovaps xmm11, [rsp+0xB0]
000070dabbdcefa7  vmovaps xmm12, [rsp+0xC0]
000070dabbdcefb0  vmovaps xmm13, [rsp+0xD0]
000070dabbdcefb9  vmovaps xmm15, [rsp+0xE0]
000070dabbdcefc2  add rsp, 0xF0
000070dabbdcefc9  pop r11
000070dabbdcefcb  pop r10
000070dabbdcefcd  pop r9
000070dabbdcefcf  pop r8
000070dabbdcefd1  pop rsi
000070dabbdcefd2  pop rdi
000070dabbdcefd3  pop rdx
000070dabbdcefd4  pop rcx
000070dabbdcefd5  pop rax
000070dabbdcefd6  add rsp, 0x08
000070dabbdcefda  jmp 0x000070DABBDCECAE
000070dabbdcefdf  call 0x000070DABBCC34C0
000070dabbdcefe4  jmp 0x000070DABBDCECC4
000070dabbdcefe9  int3
000070dabbdcefea  nop [rax+rax*1], ax
000070dabbdceff0  mov rax, [r15+0xF8]
000070dabbdceff7  lea r14, [rax-0x150]
000070dabbdceffe  mov [r15+0xF8], r14
000070dabbdcf005  mov rax, [r15+0x50]
000070dabbdcf009  lea r12, [rax+0x80]
000070dabbdcf010  movups xmm1, [r13+r12*1]
000070dabbdcf016  lea r12, [rax+0x90]
000070dabbdcf01d  movups xmm15, [r13+r12*1]
000070dabbdcf023  mov qword ptr [r15+0x48], 0x00
000070dabbdcf02b  lea r12, [rax+0x40]
000070dabbdcf02f  movups xmm14, [r13+r12*1]
000070dabbdcf035  lea r12, [rax+0x50]
000070dabbdcf039  movups xmm13, [r13+r12*1]
000070dabbdcf03f  lea r12, [r14+0x120]
000070dabbdcf046  movq xmm12, qword ptr [r15+0x1C0]
000070dabbdcf04f  movq xmm11, qword ptr [r15+0x1B0]
000070dabbdcf058  movq r11, xmm12
000070dabbdcf05d  movq r10, xmm11
000070dabbdcf062  mov [r13+r12*1], r11
000070dabbdcf067  lea r12, [r14+0x128]
000070dabbdcf06e  mov [r13+r12*1], r10
000070dabbdcf073  vxorps xmm12, xmm12, xmm12
000070dabbdcf078  vpbroadcastq xmm12, xmm12
000070dabbdcf07d  lea r12, [r14+0x100]
000070dabbdcf084  movq xmm11, qword ptr [r15+0x200]
000070dabbdcf08d  movq xmm10, qword ptr [r15+0x1F0]
000070dabbdcf096  movq r11, xmm11
000070dabbdcf09b  movq r10, xmm10
000070dabbdcf0a0  mov [r13+r12*1], r11
000070dabbdcf0a5  lea r12, [r14+0x108]
000070dabbdcf0ac  mov [r13+r12*1], r10
000070dabbdcf0b1  lea r12, [r14+0xE0]
000070dabbdcf0b8  movups [r13+r12*1], xmm15
000070dabbdcf0be  lea r12, [r14+0xF0]
000070dabbdcf0c5  movups [r13+r12*1], xmm1
000070dabbdcf0cb  lea r12, [rax+0xC0]
000070dabbdcf0d2  movups xmm1, [r13+r12*1]
000070dabbdcf0d8  lea r12, [rax+0xD0]
000070dabbdcf0df  movups xmm15, [r13+r12*1]
000070dabbdcf0e5  lea r12, [r14+0x110]
000070dabbdcf0ec  movq xmm11, qword ptr [r15+0x1E0]
000070dabbdcf0f5  movq xmm10, qword ptr [r15+0x1D0]
000070dabbdcf0fe  movq r11, xmm11
000070dabbdcf103  movq r10, xmm10
000070dabbdcf108  mov [r13+r12*1], r11
000070dabbdcf10d  lea r12, [r14+0x118]
000070dabbdcf114  mov [r13+r12*1], r10
000070dabbdcf119  movups xmm11, [r13+rax*1]
000070dabbdcf11f  lea r12, [rax+0x10]
000070dabbdcf123  movups xmm10, [r13+r12*1]
000070dabbdcf129  lea r12, [r14+0x130]
000070dabbdcf130  movq xmm9, qword ptr [r15+0x1A0]
000070dabbdcf139  movq xmm8, qword ptr [r15+0x190]
000070dabbdcf142  movq r11, xmm9
000070dabbdcf147  movq r10, xmm8
000070dabbdcf14c  mov [r13+r12*1], r11
000070dabbdcf151  lea r12, [r14+0x138]
000070dabbdcf158  mov [r13+r12*1], r10
000070dabbdcf15d  lea r12, [rax+0x140]
000070dabbdcf164  movups xmm9, [r13+r12*1]
000070dabbdcf16a  lea r12, [rax+0x150]
000070dabbdcf171  movups xmm8, [r13+r12*1]
000070dabbdcf177  lea r12, [r14+0xC0]
000070dabbdcf17e  movups [r13+r12*1], xmm15
000070dabbdcf184  lea r12, [r14+0xD0]
000070dabbdcf18b  movups [r13+r12*1], xmm1
000070dabbdcf191  lea r12, [rax+0x100]
000070dabbdcf198  movups xmm1, [r13+r12*1]
000070dabbdcf19e  lea r12, [rax+0x110]
000070dabbdcf1a5  movups xmm15, [r13+r12*1]
000070dabbdcf1ab  lea r12, [r14+0x140]
000070dabbdcf1b2  mov r11, [r15+0xE8]
000070dabbdcf1b9  mov [r13+r12*1], r11
000070dabbdcf1be  lea r12, [rax+0x180]
000070dabbdcf1c5  movups xmm7, [r13+r12*1]
000070dabbdcf1cb  lea r12, [rax+0x190]
000070dabbdcf1d2  movups xmm6, [r13+r12*1]
000070dabbdcf1d8  lea r12, [rax+0x1C0]
000070dabbdcf1df  movups xmm5, [r13+r12*1]
000070dabbdcf1e5  lea r12, [rax+0x1D0]
000070dabbdcf1ec  movups xmm4, [r13+r12*1]
000070dabbdcf1f2  lea r12, [r14+0x20]
000070dabbdcf1f6  movups [r13+r12*1], xmm1
000070dabbdcf1fc  lea r12, [r14+0x30]
000070dabbdcf200  movups [r13+r12*1], xmm13
000070dabbdcf206  lea r12, [rax+0x60]
000070dabbdcf20a  movups xmm1, [r13+r12*1]
000070dabbdcf210  lea r12, [rax+0x70]
000070dabbdcf214  movups xmm13, [r13+r12*1]
000070dabbdcf21a  lea r12, [rax+0x20]
000070dabbdcf21e  movups xmm3, [r13+r12*1]
000070dabbdcf224  lea r12, [rax+0x30]
000070dabbdcf228  movups xmm2, [r13+r12*1]
000070dabbdcf22e  movaps [r15+0x1F0], xmm2
000070dabbdcf236  lea r12, [r14+0x60]
000070dabbdcf23a  movups [r13+r12*1], xmm11
000070dabbdcf240  lea r12, [r14+0x70]
000070dabbdcf244  movups [r13+r12*1], xmm5
000070dabbdcf24a  lea r12, [rax+0xE0]
000070dabbdcf251  movups xmm11, [r13+r12*1]
000070dabbdcf257  lea r12, [rax+0xF0]
000070dabbdcf25e  movups xmm5, [r13+r12*1]
000070dabbdcf264  lea r12, [r14+0xA0]
000070dabbdcf26b  movups [r13+r12*1], xmm13
000070dabbdcf271  lea r12, [r14+0xB0]
000070dabbdcf278  movups [r13+r12*1], xmm1
000070dabbdcf27e  lea r12, [rax+0xA0]
000070dabbdcf285  movups xmm1, [r13+r12*1]
000070dabbdcf28b  lea r12, [rax+0xB0]
000070dabbdcf292  movups xmm13, [r13+r12*1]
000070dabbdcf298  lea r12, [rax+0x120]
000070dabbdcf29f  vmovaps [rsp+0x10], xmm1
000070dabbdcf2a5  movups xmm1, [r13+r12*1]
000070dabbdcf2ab  lea r12, [rax+0x130]
000070dabbdcf2b2  vmovaps [rsp+0x20], xmm1
000070dabbdcf2b8  movups xmm1, [r13+r12*1]
000070dabbdcf2be  lea r12, [rax+0x160]
000070dabbdcf2c5  vmovaps [rsp+0x30], xmm1
000070dabbdcf2cb  movups xmm1, [r13+r12*1]
000070dabbdcf2d1  lea r12, [rax+0x170]
000070dabbdcf2d8  vmovaps [rsp+0x40], xmm1
000070dabbdcf2de  movups xmm1, [r13+r12*1]
000070dabbdcf2e4  movaps [r15+0x2B0], xmm1
000070dabbdcf2ec  lea r12, [r14+0x80]
000070dabbdcf2f3  movups [r13+r12*1], xmm13
000070dabbdcf2f9  lea r12, [r14+0x90]
000070dabbdcf300  vmovaps xmm13, [rsp+0x10]
000070dabbdcf306  movups [r13+r12*1], xmm13
000070dabbdcf30c  lea r12, [rax+0x1A0]
000070dabbdcf313  movups xmm13, [r13+r12*1]
000070dabbdcf319  lea r12, [rax+0x1B0]
000070dabbdcf320  vmovaps [rsp+0x10], xmm1
000070dabbdcf326  movups xmm1, [r13+r12*1]
000070dabbdcf32c  movaps [r15+0x290], xmm13
000070dabbdcf334  movaps [r15+0x1E0], xmm1
000070dabbdcf33c  lea r12, [rax+0x1E0]
000070dabbdcf343  vmovaps [rsp+0x50], xmm1
000070dabbdcf349  movups xmm1, [r13+r12*1]
000070dabbdcf34f  lea r12, [rax+0x1F0]
000070dabbdcf356  vmovaps [rsp+0x60], xmm1
000070dabbdcf35c  movups xmm1, [r13+r12*1]
000070dabbdcf362  mov qword ptr [r15+0x50], 0x430920
000070dabbdcf36a  lea rax, [r14+0x40]
000070dabbdcf36e  vmovaps [rsp+0x70], xmm1
000070dabbdcf374  vmovaps xmm1, [rsp+0x40]
000070dabbdcf37a  movups [r13+rax*1], xmm1
000070dabbdcf380  lea rax, [r14+0x50]
000070dabbdcf384  movups [r13+rax*1], xmm10
000070dabbdcf38a  vmovaps xmm1, [rsp+0x70]
000070dabbdcf390  movups [r13+r14*1], xmm1
000070dabbdcf396  lea rax, [r14+0x10]
000070dabbdcf39a  vmovaps xmm1, [rsp+0x60]
000070dabbdcf3a0  movups [r13+rax*1], xmm1
000070dabbdcf3a6  mov rax, [r15+0x40]
000070dabbdcf3aa  vmovaps [rsp+0x40], xmm3
000070dabbdcf3b0  vmovaps xmm1, [rsp+0x40]
000070dabbdcf3b6  por xmm3, xmm1
000070dabbdcf3ba  vmovaps [rsp+0x40], xmm6
000070dabbdcf3c0  vmovaps xmm10, [rsp+0x40]
000070dabbdcf3c6  por xmm6, xmm10
000070dabbdcf3cb  lea r12, [rax+0x30]
000070dabbdcf3cf  mov r11, [r13+r12*1]
000070dabbdcf3d4  lea r12, [rax+0x38]
000070dabbdcf3d8  mov r10, [r13+r12*1]
000070dabbdcf3dd  movq xmm10, r11
000070dabbdcf3e2  vmovaps [rsp+0x40], xmm1
000070dabbdcf3e8  movq xmm1, r10
000070dabbdcf3ed  movq xmm10, xmm10
000070dabbdcf3f2  vmovaps [rsp+0x60], xmm10
000070dabbdcf3f8  movq xmm10, xmm10
000070dabbdcf3fd  movaps [r15+0x130], xmm10
000070dabbdcf405  movq xmm1, xmm1
000070dabbdcf409  vmovaps [rsp+0x70], xmm1
000070dabbdcf40f  movq xmm1, xmm1
000070dabbdcf413  movaps [r15+0x280], xmm1
000070dabbdcf41b  vmovaps [rsp+0x80], xmm9
000070dabbdcf424  vmovaps xmm1, [rsp+0x80]
000070dabbdcf42d  por xmm9, xmm1
000070dabbdcf432  lea r12, [rax+0x20]
000070dabbdcf436  mov r11, [r13+r12*1]
000070dabbdcf43b  lea r12, [rax+0x28]
000070dabbdcf43f  mov r10, [r13+r12*1]
000070dabbdcf444  movq xmm1, r11
000070dabbdcf449  movq xmm10, r10
000070dabbdcf44e  movq xmm1, xmm1
000070dabbdcf452  vmovaps [rsp+0x80], xmm1
000070dabbdcf45b  movq xmm1, xmm1
000070dabbdcf45f  movaps [r15+0x150], xmm1
000070dabbdcf467  movq xmm10, xmm10
000070dabbdcf46c  vmovaps [rsp+0x90], xmm10
000070dabbdcf475  movq xmm10, xmm10
000070dabbdcf47a  movaps [r15+0x140], xmm10
000070dabbdcf482  lea r12, [rax+0x10]
000070dabbdcf486  mov r11, [r13+r12*1]
000070dabbdcf48b  lea r12, [rax+0x18]
000070dabbdcf48f  mov r10, [r13+r12*1]
000070dabbdcf494  movq xmm1, r11
000070dabbdcf499  movq xmm10, r10
000070dabbdcf49e  movq xmm1, xmm1
000070dabbdcf4a2  vmovaps [rsp+0xA0], xmm1
000070dabbdcf4ab  movq xmm1, xmm1
000070dabbdcf4af  movaps [r15+0x170], xmm1
000070dabbdcf4b7  movq xmm10, xmm10
000070dabbdcf4bc  vmovaps [rsp+0xB0], xmm10
000070dabbdcf4c5  movq xmm10, xmm10
000070dabbdcf4ca  movaps [r15+0x160], xmm10
000070dabbdcf4d2  mov r12, [r13+rax*1]
000070dabbdcf4d7  vmovq xmm1, r12
000070dabbdcf4dc  vpbroadcastq xmm1, xmm1
000070dabbdcf4e1  lea r12, [rax+0x08]
000070dabbdcf4e5  mov rax, [r13+r12*1]
000070dabbdcf4ea  movq xmm10, rax
000070dabbdcf4ef  movaps [r15+0x230], xmm10
000070dabbdcf4f7  lea rax, [r14+0x50]
000070dabbdcf4fb  movups xmm10, [r13+rax*1]
000070dabbdcf501  lea rax, [r14+0x60]
000070dabbdcf505  vmovaps [rsp+0xC0], xmm1
000070dabbdcf50e  movups xmm1, [r13+rax*1]
000070dabbdcf514  lea rax, [r14+0x30]
000070dabbdcf518  vmovaps [rsp+0xD0], xmm1
000070dabbdcf521  movups xmm1, [r13+rax*1]
000070dabbdcf527  mov qword ptr [r15+0x60], 0x430920
000070dabbdcf52f  mov qword ptr [r15+0x58], 0x40
000070dabbdcf537  vmovaps [rsp+0xE0], xmm1
000070dabbdcf540  vmovaps [rsp+0xF0], xmm15
000070dabbdcf549  vmovaps xmm15, [rsp+0xC0]
000070dabbdcf552  vmovaps [rsp+0xC0], xmm14
000070dabbdcf55b  vmovaps xmm14, [rsp+0x40]
000070dabbdcf561  vmovaps [rsp+0x40], xmm13
000070dabbdcf567  movaps xmm1, xmm15
000070dabbdcf56b  mulpd xmm1, xmm14
000070dabbdcf570  vcmppd xmm13, xmm1, xmm1, 0x03
000070dabbdcf575  ptest xmm13, xmm13
000070dabbdcf57b  jnz 0x000070DABBDD0682
000070dabbdcf581  movq xmm14, qword ptr [r15+0x230]
000070dabbdcf58a  vmovaps [rsp+0x100], xmm14
000070dabbdcf593  vpermilpd xmm14, xmm14, 0x00
000070dabbdcf599  vmovaps [rsp+0x110], xmm1
000070dabbdcf5a2  vmovaps xmm1, [rsp+0xE0]
000070dabbdcf5ab  vmovaps [rsp+0xE0], xmm15
000070dabbdcf5b4  movaps xmm13, xmm1
000070dabbdcf5b8  mulpd xmm13, xmm14
000070dabbdcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000070dabbdcf5c3  ptest xmm15, xmm15
000070dabbdcf5c9  jnz 0x000070DABBDD07C4
000070dabbdcf5cf  vxorps xmm1, xmm1, xmm1
000070dabbdcf5d3  vpbroadcastq xmm1, xmm1
000070dabbdcf5d8  vmovaps xmm14, [rsp+0xE0]
000070dabbdcf5e1  vmovaps [rsp+0xE0], xmm1
000070dabbdcf5ea  vmovaps xmm1, [rsp+0xD0]
000070dabbdcf5f3  vmovaps [rsp+0xD0], xmm13
000070dabbdcf5fc  movaps xmm15, xmm14
000070dabbdcf600  mulpd xmm15, xmm1
000070dabbdcf605  vcmppd xmm13, xmm15, xmm15, 0x03
000070dabbdcf60b  ptest xmm13, xmm13
000070dabbdcf611  jnz 0x000070DABBDD0907
000070dabbdcf617  movaps xmm1, xmm14
000070dabbdcf61b  mulpd xmm1, xmm10
000070dabbdcf620  vcmppd xmm13, xmm1, xmm1, 0x03
000070dabbdcf625  ptest xmm13, xmm13
000070dabbdcf62b  jnz 0x000070DABBDD0A4A
000070dabbdcf631  movaps xmm13, xmm14
000070dabbdcf635  mulpd xmm13, xmm2
000070dabbdcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000070dabbdcf640  ptest xmm10, xmm10
000070dabbdcf646  jnz 0x000070DABBDD0B8C
000070dabbdcf64c  vmovaps [rsp+0x120], xmm7
000070dabbdcf655  vmovaps xmm14, [rsp+0x120]
000070dabbdcf65e  por xmm7, xmm14
000070dabbdcf663  vmovaps xmm14, [rsp+0xC0]
000070dabbdcf66c  vmovaps xmm10, [rsp+0xC0]
000070dabbdcf675  por xmm14, xmm10
000070dabbdcf67a  vmovaps xmm2, [rsp+0x100]
000070dabbdcf683  vpermilpd xmm2, xmm2, 0x00
000070dabbdcf689  vmovaps [rsp+0xC0], xmm1
000070dabbdcf692  vmovaps [rsp+0x120], xmm15
000070dabbdcf69b  movaps xmm1, xmm10
000070dabbdcf69f  mulpd xmm1, xmm2
000070dabbdcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000070dabbdcf6a8  ptest xmm15, xmm15
000070dabbdcf6ae  jnz 0x000070DABBDD0CCF
000070dabbdcf6b4  xor eax, eax
000070dabbdcf6b6  mov r12d, 0x40
000070dabbdcf6bc  mov r11d, 0x200
000070dabbdcf6c2  cmp r12, r11
000070dabbdcf6c5  cmc
000070dabbdcf6c6  lahf
000070dabbdcf6c7  seto al
000070dabbdcf6ca  mov [r15+0x108], eax
000070dabbdcf6d1  vmovaps xmm10, [rsp+0x110]
000070dabbdcf6da  vmovaps xmm2, [rsp+0xE0]
000070dabbdcf6e3  vmovaps [rsp+0xE0], xmm1
000070dabbdcf6ec  movaps xmm15, xmm10
000070dabbdcf6f0  addpd xmm15, xmm2
000070dabbdcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000070dabbdcf6fb  ptest xmm1, xmm1
000070dabbdcf700  jnz 0x000070DABBDD0E10
000070dabbdcf706  vmovaps xmm10, [rsp+0x120]
000070dabbdcf70f  vmovaps [rsp+0x110], xmm15
000070dabbdcf718  movaps xmm1, xmm10
000070dabbdcf71c  addpd xmm1, xmm12
000070dabbdcf721  vcmppd xmm15, xmm1, xmm1, 0x03
000070dabbdcf726  ptest xmm15, xmm15
000070dabbdcf72c  jnz 0x000070DABBDD0F53
000070dabbdcf732  vmovaps xmm10, [rsp+0xC0]
000070dabbdcf73b  vmovaps [rsp+0xC0], xmm1
000070dabbdcf744  movaps xmm15, xmm10
000070dabbdcf748  addpd xmm15, xmm12
000070dabbdcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000070dabbdcf753  ptest xmm1, xmm1
000070dabbdcf758  jnz 0x000070DABBDD1095
000070dabbdcf75e  vmovaps xmm1, [rsp+0x30]
000070dabbdcf764  vmovaps xmm12, [rsp+0x30]
000070dabbdcf76a  por xmm1, xmm12
000070dabbdcf76f  vmovaps xmm12, [rsp+0x20]
000070dabbdcf775  vmovaps xmm10, [rsp+0x20]
000070dabbdcf77b  por xmm12, xmm10
000070dabbdcf780  vmovaps [rsp+0x20], xmm5
000070dabbdcf786  vmovaps xmm10, [rsp+0x20]
000070dabbdcf78c  por xmm5, xmm10
000070dabbdcf791  vmovaps [rsp+0x20], xmm11
000070dabbdcf797  vmovaps xmm10, [rsp+0x20]
000070dabbdcf79d  por xmm11, xmm10
000070dabbdcf7a2  vmovaps [rsp+0x20], xmm4
000070dabbdcf7a8  vmovaps xmm10, [rsp+0x20]
000070dabbdcf7ae  por xmm4, xmm10
000070dabbdcf7b3  vmovaps [rsp+0x20], xmm8
000070dabbdcf7b9  vmovaps xmm10, [rsp+0x20]
000070dabbdcf7bf  por xmm8, xmm10
000070dabbdcf7c4  vmovaps xmm10, [rsp+0xF0]
000070dabbdcf7cd  vmovaps [rsp+0x20], xmm1
000070dabbdcf7d3  vmovaps xmm1, [rsp+0xF0]
000070dabbdcf7dc  por xmm10, xmm1
000070dabbdcf7e1  lea rax, [r14+0xA0]
000070dabbdcf7e8  movups xmm1, [r13+rax*1]
000070dabbdcf7ee  lea rax, [r14+0xB0]
000070dabbdcf7f5  vmovaps [rsp+0x30], xmm1
000070dabbdcf7fb  movups xmm1, [r13+rax*1]
000070dabbdcf801  vmovaps [rsp+0xF0], xmm1
000070dabbdcf80a  vmovaps [rsp+0x120], xmm15
000070dabbdcf813  movaps xmm1, xmm13
000070dabbdcf817  addpd xmm1, xmm2
000070dabbdcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000070dabbdcf820  ptest xmm15, xmm15
000070dabbdcf826  jnz 0x000070DABBDD11ED
000070dabbdcf82c  lea rax, [r14+0xF0]
000070dabbdcf833  movups xmm15, [r13+rax*1]
000070dabbdcf839  vmovaps xmm2, [rsp+0xC0]
000070dabbdcf842  vmovaps [rsp+0xC0], xmm1
000070dabbdcf84b  vmovaps xmm1, [rsp+0xE0]
000070dabbdcf854  vmovaps [rsp+0xE0], xmm15
000070dabbdcf85d  movaps xmm13, xmm2
000070dabbdcf861  addpd xmm13, xmm1
000070dabbdcf866  vcmppd xmm15, xmm13, xmm13, 0x03
000070dabbdcf86c  ptest xmm15, xmm15
000070dabbdcf872  jnz 0x000070DABBDD1338
000070dabbdcf878  vmovaps xmm15, [rsp+0x120]
000070dabbdcf881  vmovaps xmm2, [rsp+0xD0]
000070dabbdcf88a  vmovaps [rsp+0xD0], xmm14
000070dabbdcf893  movaps xmm1, xmm15
000070dabbdcf897  addpd xmm1, xmm2
000070dabbdcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000070dabbdcf8a0  ptest xmm14, xmm14
000070dabbdcf8a6  jnz 0x000070DABBDD147A
000070dabbdcf8ac  vmovaps xmm15, [rsp+0x100]
000070dabbdcf8b5  vpermilpd xmm15, xmm15, 0x00
000070dabbdcf8bb  vmovaps xmm2, [rsp+0xF0]
000070dabbdcf8c4  vmovaps [rsp+0xF0], xmm1
000070dabbdcf8cd  movaps xmm14, xmm2
000070dabbdcf8d1  mulpd xmm14, xmm15
000070dabbdcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000070dabbdcf8dc  ptest xmm1, xmm1
000070dabbdcf8e1  jnz 0x000070DABBDD15BB
000070dabbdcf8e7  vmovaps xmm1, [rsp+0xA0]
000070dabbdcf8f0  vpermilpd xmm1, xmm1, 0x00
000070dabbdcf8f6  vmovaps xmm2, [rsp+0xE0]
000070dabbdcf8ff  vmovaps [rsp+0xE0], xmm14
000070dabbdcf908  movaps xmm15, xmm2
000070dabbdcf90c  mulpd xmm15, xmm1
000070dabbdcf911  vcmppd xmm14, xmm15, xmm15, 0x03
000070dabbdcf917  ptest xmm14, xmm14
000070dabbdcf91d  jnz 0x000070DABBDD16FE
000070dabbdcf923  lea rax, [r14+0xE0]
000070dabbdcf92a  movups xmm1, [r13+rax*1]
000070dabbdcf930  vmovaps xmm14, [rsp+0x100]
000070dabbdcf939  vpermilpd xmm14, xmm14, 0x00
000070dabbdcf93f  vmovaps [rsp+0x100], xmm1
000070dabbdcf948  vmovaps xmm1, [rsp+0x30]
000070dabbdcf94e  vmovaps [rsp+0x30], xmm15
000070dabbdcf954  movaps xmm2, xmm1
000070dabbdcf957  mulpd xmm2, xmm14
000070dabbdcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000070dabbdcf961  ptest xmm15, xmm15
000070dabbdcf967  jnz 0x000070DABBDD184A
000070dabbdcf96d  vmovaps [rsp+0x120], xmm10
000070dabbdcf976  vmovaps xmm1, [rsp+0x120]
000070dabbdcf97f  por xmm10, xmm1
000070dabbdcf984  movaps [r15+0x300], xmm10
000070dabbdcf98c  vmovaps [rsp+0x120], xmm8
000070dabbdcf995  vmovaps xmm1, [rsp+0x120]
000070dabbdcf99e  por xmm8, xmm1
000070dabbdcf9a3  movaps [r15+0x190], xmm8
000070dabbdcf9ab  vmovaps xmm1, [rsp+0xA0]
000070dabbdcf9b4  vpermilpd xmm1, xmm1, 0x00
000070dabbdcf9ba  vmovaps xmm14, [rsp+0x100]
000070dabbdcf9c3  vmovaps [rsp+0x100], xmm13
000070dabbdcf9cc  movaps xmm15, xmm14
000070dabbdcf9d0  mulpd xmm15, xmm1
000070dabbdcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000070dabbdcf9db  ptest xmm13, xmm13
000070dabbdcf9e1  jnz 0x000070DABBDD198B
000070dabbdcf9e7  lea rax, [r14+0x90]
000070dabbdcf9ee  movups xmm1, [r13+rax*1]
000070dabbdcf9f4  vmovaps [rsp+0x120], xmm4
000070dabbdcf9fd  vmovaps xmm14, [rsp+0x120]
000070dabbdcfa06  por xmm4, xmm14
000070dabbdcfa0b  movaps [r15+0x1C0], xmm4
000070dabbdcfa13  vmovaps [rsp+0x120], xmm11
000070dabbdcfa1c  vmovaps xmm14, [rsp+0x120]
000070dabbdcfa25  por xmm11, xmm14
000070dabbdcfa2a  movaps [r15+0x200], xmm11
000070dabbdcfa32  vmovaps [rsp+0x120], xmm5
000070dabbdcfa3b  vmovaps xmm14, [rsp+0x120]
000070dabbdcfa44  por xmm5, xmm14
000070dabbdcfa49  movaps [r15+0x2D0], xmm5
000070dabbdcfa51  vmovaps [rsp+0x120], xmm12
000070dabbdcfa5a  vmovaps xmm14, [rsp+0x120]
000070dabbdcfa63  por xmm12, xmm14
000070dabbdcfa68  movaps [r15+0x2E0], xmm12
000070dabbdcfa70  vmovaps xmm13, [rsp+0x110]
000070dabbdcfa79  vmovaps [rsp+0x110], xmm1
000070dabbdcfa82  vmovaps xmm1, [rsp+0xE0]
000070dabbdcfa8b  vmovaps [rsp+0xE0], xmm15
000070dabbdcfa94  movaps xmm14, xmm13
000070dabbdcfa98  addpd xmm14, xmm1
000070dabbdcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000070dabbdcfaa3  ptest xmm15, xmm15
000070dabbdcfaa9  jnz 0x000070DABBDD1AD8
000070dabbdcfaaf  vmovaps xmm1, [rsp+0xA0]
000070dabbdcfab8  vpermilpd xmm1, xmm1, 0x00
000070dabbdcfabe  vmovaps xmm13, [rsp+0x110]
000070dabbdcfac7  vmovaps [rsp+0x110], xmm14
000070dabbdcfad0  movaps xmm15, xmm13
000070dabbdcfad4  mulpd xmm15, xmm1
000070dabbdcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000070dabbdcfadf  ptest xmm14, xmm14
000070dabbdcfae5  jnz 0x000070DABBDD1C1B
000070dabbdcfaeb  lea rax, [r14+0x80]
000070dabbdcfaf2  movups xmm1, [r13+rax*1]
000070dabbdcfaf8  vmovaps xmm13, [rsp+0xC0]
000070dabbdcfb01  vmovaps [rsp+0xC0], xmm1
000070dabbdcfb0a  movaps xmm14, xmm13
000070dabbdcfb0e  addpd xmm14, xmm2
000070dabbdcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000070dabbdcfb19  ptest xmm1, xmm1
000070dabbdcfb1e  jnz 0x000070DABBDD1D68
000070dabbdcfb24  vmovaps xmm13, [rsp+0x100]
000070dabbdcfb2d  vmovaps xmm2, [rsp+0x30]
000070dabbdcfb33  vmovaps [rsp+0x30], xmm15
000070dabbdcfb39  movaps xmm1, xmm13
000070dabbdcfb3d  addpd xmm1, xmm2
000070dabbdcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000070dabbdcfb46  ptest xmm15, xmm15
000070dabbdcfb4c  jnz 0x000070DABBDD1EAB
000070dabbdcfb52  vmovaps xmm15, [rsp+0x20]
000070dabbdcfb58  vmovaps xmm13, [rsp+0x20]
000070dabbdcfb5e  por xmm15, xmm13
000070dabbdcfb63  movaps [r15+0x2F0], xmm15
000070dabbdcfb6b  vmovaps xmm13, [rsp+0xA0]
000070dabbdcfb74  vpermilpd xmm13, xmm13, 0x00
000070dabbdcfb7a  vmovaps [rsp+0x20], xmm1
000070dabbdcfb80  vmovaps xmm1, [rsp+0xC0]
000070dabbdcfb89  vmovaps [rsp+0xA0], xmm15
000070dabbdcfb92  movaps xmm2, xmm1
000070dabbdcfb95  mulpd xmm2, xmm13
000070dabbdcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000070dabbdcfb9f  ptest xmm15, xmm15
000070dabbdcfba5  jnz 0x000070DABBDD1FEC
000070dabbdcfbab  lea rax, [r14+0xD0]
000070dabbdcfbb2  movups xmm1, [r13+rax*1]
000070dabbdcfbb8  vmovaps xmm13, [rsp+0xF0]
000070dabbdcfbc1  vmovaps [rsp+0xC0], xmm1
000070dabbdcfbca  vmovaps xmm1, [rsp+0xE0]
000070dabbdcfbd3  vmovaps [rsp+0xE0], xmm14
000070dabbdcfbdc  movaps xmm15, xmm13
000070dabbdcfbe0  addpd xmm15, xmm1
000070dabbdcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000070dabbdcfbeb  ptest xmm14, xmm14
000070dabbdcfbf1  jnz 0x000070DABBDD2137
000070dabbdcfbf7  vmovaps xmm1, [rsp+0xB0]
000070dabbdcfc00  vpermilpd xmm1, xmm1, 0x00
000070dabbdcfc06  movaps xmm14, xmm11
000070dabbdcfc0a  mulpd xmm14, xmm1
000070dabbdcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000070dabbdcfc15  ptest xmm13, xmm13
000070dabbdcfc1b  jnz 0x000070DABBDD227A
000070dabbdcfc21  movaps [r15+0x260], xmm14
000070dabbdcfc29  vxorps xmm1, xmm1, xmm1
000070dabbdcfc2d  vpbroadcastq xmm1, xmm1
000070dabbdcfc32  movaps [r15+0x1B0], xmm1
000070dabbdcfc3a  vmovaps xmm1, [rsp+0xB0]
000070dabbdcfc43  vpermilpd xmm1, xmm1, 0x00
000070dabbdcfc49  vmovaps xmm11, [rsp+0xC0]
000070dabbdcfc52  vmovaps [rsp+0xC0], xmm15
000070dabbdcfc5b  movaps xmm13, xmm11
000070dabbdcfc5f  mulpd xmm13, xmm1
000070dabbdcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000070dabbdcfc6a  ptest xmm15, xmm15
000070dabbdcfc70  jnz 0x000070DABBDD23BD
000070dabbdcfc76  lea rax, [r14+0xC0]
000070dabbdcfc7d  movups xmm1, [r13+rax*1]
000070dabbdcfc83  vmovaps xmm11, [rsp+0x110]
000070dabbdcfc8c  vmovaps [rsp+0xF0], xmm1
000070dabbdcfc95  vmovaps xmm1, [rsp+0x30]
000070dabbdcfc9b  vmovaps [rsp+0x30], xmm14
000070dabbdcfca1  movaps xmm15, xmm11
000070dabbdcfca5  addpd xmm15, xmm1
000070dabbdcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000070dabbdcfcb0  ptest xmm14, xmm14
000070dabbdcfcb6  jnz 0x000070DABBDD250A
000070dabbdcfcbc  vmovaps [rsp+0x100], xmm9
000070dabbdcfcc5  vmovaps xmm1, [rsp+0x100]
000070dabbdcfcce  por xmm9, xmm1
000070dabbdcfcd3  movaps [r15+0x270], xmm9
000070dabbdcfcdb  vmovaps [rsp+0x100], xmm6
000070dabbdcfce4  vmovaps xmm1, [rsp+0x100]
000070dabbdcfced  por xmm6, xmm1
000070dabbdcfcf1  movaps [r15+0x1A0], xmm6
000070dabbdcfcf9  vmovaps xmm14, [rsp+0xB0]
000070dabbdcfd02  vpermilpd xmm14, xmm14, 0x00
000070dabbdcfd08  vmovaps xmm6, [rsp+0xF0]
000070dabbdcfd11  vmovaps [rsp+0xF0], xmm1
000070dabbdcfd1a  movaps xmm11, xmm6
000070dabbdcfd1e  mulpd xmm11, xmm14
000070dabbdcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000070dabbdcfd29  ptest xmm1, xmm1
000070dabbdcfd2e  jnz 0x000070DABBDD264D
000070dabbdcfd34  lea rax, [r14+0x20]
000070dabbdcfd38  movups xmm1, [r13+rax*1]
000070dabbdcfd3e  movaps [r15+0x110], xmm1
000070dabbdcfd46  vmovaps xmm6, [rsp+0xE0]
000070dabbdcfd4f  vmovaps [rsp+0xE0], xmm1
000070dabbdcfd58  movaps xmm14, xmm6
000070dabbdcfd5c  addpd xmm14, xmm2
000070dabbdcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000070dabbdcfd67  ptest xmm1, xmm1
000070dabbdcfd6c  jnz 0x000070DABBDD279A
000070dabbdcfd72  vmovaps xmm1, [rsp+0xB0]
000070dabbdcfd7b  vpermilpd xmm1, xmm1, 0x00
000070dabbdcfd81  movaps xmm6, xmm5
000070dabbdcfd84  mulpd xmm6, xmm1
000070dabbdcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000070dabbdcfd8d  ptest xmm2, xmm2
000070dabbdcfd92  jnz 0x000070DABBDD28DC
000070dabbdcfd98  vmovaps xmm5, [rsp+0x20]
000070dabbdcfd9e  movaps xmm1, xmm5
000070dabbdcfda1  addpd xmm1, xmm13
000070dabbdcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000070dabbdcfdab  ptest xmm2, xmm2
000070dabbdcfdb0  jnz 0x000070DABBDD2A1C
000070dabbdcfdb6  vmovaps xmm13, [rsp+0x80]
000070dabbdcfdbf  vpermilpd xmm13, xmm13, 0x00
000070dabbdcfdc5  vmovaps xmm2, [rsp+0xE0]
000070dabbdcfdce  vmovaps [rsp+0x20], xmm1
000070dabbdcfdd4  movaps xmm5, xmm2
000070dabbdcfdd7  mulpd xmm5, xmm13
000070dabbdcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000070dabbdcfde1  ptest xmm1, xmm1
000070dabbdcfde6  jnz 0x000070DABBDD2B5D
000070dabbdcfdec  vmovaps xmm1, [rsp+0x80]
000070dabbdcfdf5  vpermilpd xmm1, xmm1, 0x00
000070dabbdcfdfb  movaps xmm13, xmm10
000070dabbdcfdff  mulpd xmm13, xmm1
000070dabbdcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000070dabbdcfe0a  ptest xmm2, xmm2
000070dabbdcfe0f  jnz 0x000070DABBDD2C9E
000070dabbdcfe15  vmovaps xmm10, [rsp+0x30]
000070dabbdcfe1b  movaps xmm1, xmm15
000070dabbdcfe1f  addpd xmm1, xmm10
000070dabbdcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000070dabbdcfe29  ptest xmm2, xmm2
000070dabbdcfe2e  jnz 0x000070DABBDD2DE1
000070dabbdcfe34  vmovaps xmm10, [rsp+0xC0]
000070dabbdcfe3d  movaps xmm15, xmm10
000070dabbdcfe41  addpd xmm15, xmm11
000070dabbdcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000070dabbdcfe4c  ptest xmm2, xmm2
000070dabbdcfe51  jnz 0x000070DABBDD2F23
000070dabbdcfe57  vmovaps xmm11, [rsp+0x80]
000070dabbdcfe60  vpermilpd xmm11, xmm11, 0x00
000070dabbdcfe66  movaps xmm10, xmm12
000070dabbdcfe6a  mulpd xmm10, xmm11
000070dabbdcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000070dabbdcfe75  ptest xmm2, xmm2
000070dabbdcfe7a  jnz 0x000070DABBDD3067
000070dabbdcfe80  vmovaps xmm12, [rsp+0x80]
000070dabbdcfe89  vpermilpd xmm12, xmm12, 0x00
000070dabbdcfe8f  vmovaps xmm2, [rsp+0xA0]
000070dabbdcfe98  vmovaps [rsp+0x30], xmm1
000070dabbdcfe9e  movaps xmm11, xmm2
000070dabbdcfea2  mulpd xmm11, xmm12
000070dabbdcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000070dabbdcfead  ptest xmm1, xmm1
000070dabbdcfeb2  jnz 0x000070DABBDD31AB
000070dabbdcfeb8  movaps xmm1, xmm14
000070dabbdcfebc  addpd xmm1, xmm6
000070dabbdcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000070dabbdcfec5  ptest xmm12, xmm12
000070dabbdcfecb  jnz 0x000070DABBDD32EE
000070dabbdcfed1  vmovaps xmm12, [rsp+0x20]
000070dabbdcfed7  movaps xmm14, xmm12
000070dabbdcfedb  addpd xmm14, xmm5
000070dabbdcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000070dabbdcfee6  ptest xmm6, xmm6
000070dabbdcfeeb  jnz 0x000070DABBDD342F
000070dabbdcfef1  vmovaps xmm12, [rsp+0x90]
000070dabbdcfefa  vpermilpd xmm12, xmm12, 0x00
000070dabbdcff00  movaps xmm6, xmm9
000070dabbdcff04  mulpd xmm6, xmm12
000070dabbdcff09  vcmppd xmm5, xmm6, xmm6, 0x03
000070dabbdcff0e  ptest xmm5, xmm5
000070dabbdcff13  jnz 0x000070DABBDD3572
000070dabbdcff19  movaps xmm12, xmm15
000070dabbdcff1d  addpd xmm12, xmm13
000070dabbdcff22  vcmppd xmm9, xmm12, xmm12, 0x03
000070dabbdcff28  ptest xmm9, xmm9
000070dabbdcff2e  jnz 0x000070DABBDD36B4
000070dabbdcff34  vmovaps xmm13, [rsp+0x30]
000070dabbdcff3a  movaps xmm15, xmm13
000070dabbdcff3e  addpd xmm15, xmm10
000070dabbdcff43  vcmppd xmm9, xmm15, xmm15, 0x03
000070dabbdcff49  ptest xmm9, xmm9
000070dabbdcff4f  jnz 0x000070DABBDD37F8
000070dabbdcff55  vmovaps xmm13, [rsp+0xD0]
000070dabbdcff5e  vmovaps xmm10, [rsp+0xD0]
000070dabbdcff67  por xmm13, xmm10
000070dabbdcff6c  movaps [r15+0x250], xmm13
000070dabbdcff74  vmovaps [rsp+0x20], xmm7
000070dabbdcff7a  vmovaps xmm13, [rsp+0x20]
000070dabbdcff80  por xmm7, xmm13
000070dabbdcff85  movaps [r15+0x2A0], xmm7
000070dabbdcff8d  vmovaps [rsp+0x20], xmm3
000070dabbdcff93  vmovaps xmm13, [rsp+0x20]
000070dabbdcff99  por xmm3, xmm13
000070dabbdcff9e  movaps [r15+0x1D0], xmm3
000070dabbdcffa6  lea rax, [r14+0x40]
000070dabbdcffaa  movups xmm13, [r13+rax*1]
000070dabbdcffb0  movaps [r15+0x2C0], xmm13
000070dabbdcffb8  vmovaps xmm10, [rsp+0x90]
000070dabbdcffc1  vpermilpd xmm10, xmm10, 0x00
000070dabbdcffc7  movaps xmm9, xmm8
000070dabbdcffcb  mulpd xmm9, xmm10
000070dabbdcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000070dabbdcffd6  ptest xmm5, xmm5
000070dabbdcffdb  jnz 0x000070DABBDD3946
000070dabbdcffe1  movaps xmm10, xmm1
000070dabbdcffe5  addpd xmm10, xmm11
000070dabbdcffea  vcmppd xmm8, xmm10, xmm10, 0x03
000070dabbdcfff0  ptest xmm8, xmm8
000070dabbdcfff6  jnz 0x000070DABBDD3A8A
000070dabbdcfffc  movaps xmm1, xmm14
000070dabbdd0000  addpd xmm1, xmm6
000070dabbdd0004  vcmppd xmm11, xmm1, xmm1, 0x03
000070dabbdd0009  ptest xmm11, xmm11
000070dabbdd000f  jnz 0x000070DABBDD3BCD
000070dabbdd0015  vmovaps xmm14, [rsp+0x90]
000070dabbdd001e  vpermilpd xmm14, xmm14, 0x00
000070dabbdd0024  movaps xmm11, xmm13
000070dabbdd0028  mulpd xmm11, xmm14
000070dabbdd002d  vcmppd xmm8, xmm11, xmm11, 0x03
000070dabbdd0033  ptest xmm8, xmm8
000070dabbdd0039  jnz 0x000070DABBDD3D0E
000070dabbdd003f  vmovaps xmm14, [rsp+0x90]
000070dabbdd0048  vpermilpd xmm14, xmm14, 0x00
000070dabbdd004e  vmovaps xmm8, [rsp+0x10]
000070dabbdd0054  movaps xmm13, xmm8
000070dabbdd0058  mulpd xmm13, xmm14
000070dabbdd005d  vcmppd xmm6, xmm13, xmm13, 0x03
000070dabbdd0063  ptest xmm6, xmm6
000070dabbdd0068  jnz 0x000070DABBDD3E52
000070dabbdd006e  vmovaps xmm14, [rsp+0x60]
000070dabbdd0074  vpermilpd xmm14, xmm14, 0x00
000070dabbdd007a  movaps xmm8, xmm7
000070dabbdd007e  mulpd xmm8, xmm14
000070dabbdd0083  vcmppd xmm6, xmm8, xmm8, 0x03
000070dabbdd0089  ptest xmm6, xmm6
000070dabbdd008e  jnz 0x000070DABBDD3F96
000070dabbdd0094  movaps xmm14, xmm12
000070dabbdd0098  addpd xmm14, xmm9
000070dabbdd009d  vcmppd xmm7, xmm14, xmm14, 0x03
000070dabbdd00a3  ptest xmm7, xmm7
000070dabbdd00a8  jnz 0x000070DABBDD40D9
000070dabbdd00ae  vmovaps xmm12, [rsp+0x60]
000070dabbdd00b4  vpermilpd xmm12, xmm12, 0x00
000070dabbdd00ba  vmovaps xmm7, [rsp+0xF0]
000070dabbdd00c3  movaps xmm9, xmm7
000070dabbdd00c7  mulpd xmm9, xmm12
000070dabbdd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000070dabbdd00d2  ptest xmm6, xmm6
000070dabbdd00d7  jnz 0x000070DABBDD421D
000070dabbdd00dd  movaps xmm12, xmm15
000070dabbdd00e1  addpd xmm12, xmm11
000070dabbdd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000070dabbdd00ec  ptest xmm7, xmm7
000070dabbdd00f1  jnz 0x000070DABBDD4360
000070dabbdd00f7  vmovaps xmm15, [rsp+0x60]
000070dabbdd00fd  vpermilpd xmm15, xmm15, 0x00
000070dabbdd0103  vmovaps xmm7, [rsp+0x40]
000070dabbdd0109  movaps xmm11, xmm7
000070dabbdd010d  mulpd xmm11, xmm15
000070dabbdd0112  vcmppd xmm6, xmm11, xmm11, 0x03
000070dabbdd0118  ptest xmm6, xmm6
000070dabbdd011d  jnz 0x000070DABBDD44A4
000070dabbdd0123  movaps xmm15, xmm10
000070dabbdd0127  addpd xmm15, xmm13
000070dabbdd012c  vcmppd xmm7, xmm15, xmm15, 0x03
000070dabbdd0132  ptest xmm7, xmm7
000070dabbdd0137  jnz 0x000070DABBDD45E7
000070dabbdd013d  vmovaps xmm13, [rsp+0x60]
000070dabbdd0143  vpermilpd xmm13, xmm13, 0x00
000070dabbdd0149  vmovaps xmm7, [rsp+0x50]
000070dabbdd014f  movaps xmm10, xmm7
000070dabbdd0153  mulpd xmm10, xmm13
000070dabbdd0158  vcmppd xmm6, xmm10, xmm10, 0x03
000070dabbdd015e  ptest xmm6, xmm6
000070dabbdd0163  jnz 0x000070DABBDD472B
000070dabbdd0169  movaps xmm13, xmm1
000070dabbdd016d  addpd xmm13, xmm8
000070dabbdd0172  vcmppd xmm7, xmm13, xmm13, 0x03
000070dabbdd0178  ptest xmm7, xmm7
000070dabbdd017d  jnz 0x000070DABBDD486E
000070dabbdd0183  lea rax, [r14+0x70]
000070dabbdd0187  movups xmm1, [r13+rax*1]
000070dabbdd018d  movaps [r15+0x240], xmm1
000070dabbdd0195  movaps xmm8, xmm14
000070dabbdd0199  addpd xmm8, xmm9
000070dabbdd019e  vcmppd xmm7, xmm8, xmm8, 0x03
000070dabbdd01a4  ptest xmm7, xmm7
000070dabbdd01a9  jnz 0x000070DABBDD49BB
000070dabbdd01af  movaps [r15+0x170], xmm8
000070dabbdd01b7  vmovaps xmm14, [rsp+0x70]
000070dabbdd01bd  vpermilpd xmm14, xmm14, 0x00
000070dabbdd01c3  movaps xmm9, xmm1
000070dabbdd01c7  mulpd xmm9, xmm14
000070dabbdd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000070dabbdd01d2  ptest xmm7, xmm7
000070dabbdd01d7  jnz 0x000070DABBDD4AFF
000070dabbdd01dd  vmovaps xmm1, [rsp+0x70]
000070dabbdd01e3  vpermilpd xmm1, xmm1, 0x00
000070dabbdd01e9  movaps xmm14, xmm4
000070dabbdd01ed  mulpd xmm14, xmm1
000070dabbdd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000070dabbdd01f8  ptest xmm7, xmm7
000070dabbdd01fd  jnz 0x000070DABBDD4C42
000070dabbdd0203  movaps [r15+0x180], xmm14
000070dabbdd020b  movaps xmm1, xmm12
000070dabbdd020f  addpd xmm1, xmm11
000070dabbdd0214  vcmppd xmm7, xmm1, xmm1, 0x03
000070dabbdd0219  ptest xmm7, xmm7
000070dabbdd021e  jnz 0x000070DABBDD4D84
000070dabbdd0224  movaps [r15+0x210], xmm1
000070dabbdd022c  movups xmm12, [r13+r14*1]
000070dabbdd0232  lea rax, [r14+0x10]
000070dabbdd0236  movups xmm11, [r13+rax*1]
000070dabbdd023c  movaps [r15+0x230], xmm11
000070dabbdd0244  movaps xmm7, xmm15
000070dabbdd0248  addpd xmm7, xmm10
000070dabbdd024d  vcmppd xmm6, xmm7, xmm7, 0x03
000070dabbdd0252  ptest xmm6, xmm6
000070dabbdd0257  jnz 0x000070DABBDD4EDA
000070dabbdd025d  movaps [r15+0x130], xmm7
000070dabbdd0265  vmovaps xmm15, [rsp+0x70]
000070dabbdd026b  vpermilpd xmm15, xmm15, 0x00
000070dabbdd0271  movaps xmm10, xmm11
000070dabbdd0275  mulpd xmm10, xmm15
000070dabbdd027a  vcmppd xmm6, xmm10, xmm10, 0x03
000070dabbdd0280  ptest xmm6, xmm6
000070dabbdd0285  jnz 0x000070DABBDD501C
000070dabbdd028b  movaps [r15+0x220], xmm10
000070dabbdd0293  vmovaps xmm15, [rsp+0x70]
000070dabbdd0299  vpermilpd xmm15, xmm15, 0x00
000070dabbdd029f  movaps xmm11, xmm12
000070dabbdd02a3  mulpd xmm11, xmm15
000070dabbdd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000070dabbdd02ae  ptest xmm6, xmm6
000070dabbdd02b3  jnz 0x000070DABBDD5160
000070dabbdd02b9  movaps xmm15, xmm13
000070dabbdd02bd  addpd xmm15, xmm9
000070dabbdd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000070dabbdd02c8  ptest xmm12, xmm12
000070dabbdd02ce  jnz 0x000070DABBDD52A4
000070dabbdd02d4  movaps [r15+0x140], xmm15
000070dabbdd02dc  movaps xmm13, xmm8
000070dabbdd02e0  addpd xmm13, xmm14
000070dabbdd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000070dabbdd02eb  ptest xmm12, xmm12
000070dabbdd02f1  jnz 0x000070DABBDD53E8
000070dabbdd02f7  movaps [r15+0x150], xmm13
000070dabbdd02ff  movaps xmm14, xmm1
000070dabbdd0303  addpd xmm14, xmm10
000070dabbdd0308  vcmppd xmm12, xmm14, xmm14, 0x03
000070dabbdd030e  ptest xmm12, xmm12
000070dabbdd0314  jnz 0x000070DABBDD552C
000070dabbdd031a  movaps [r15+0x160], xmm14
000070dabbdd0322  movaps xmm1, xmm7
000070dabbdd0325  addpd xmm1, xmm11
000070dabbdd032a  vcmppd xmm12, xmm1, xmm1, 0x03
000070dabbdd032f  ptest xmm12, xmm12
000070dabbdd0335  jnz 0x000070DABBDD566F
000070dabbdd033b  movaps [r15+0x120], xmm1
000070dabbdd0343  mov eax, 0x430920
000070dabbdd0348  movups [r13+rax*1], xmm15
000070dabbdd034e  mov eax, 0x430930
000070dabbdd0353  movups [r13+rax*1], xmm13
000070dabbdd0359  mov eax, 0x430940
000070dabbdd035e  movups [r13+rax*1], xmm14
000070dabbdd0364  mov eax, 0x430950
000070dabbdd0369  movups [r13+rax*1], xmm1
000070dabbdd036f  mov eax, [r15+0x108]
000070dabbdd0376  sahf
000070dabbdd0377  jnz 0x000070DABBDD03A9
000070dabbdd0379  cmp dword ptr [r15+0x318], 0x00
000070dabbdd0381  jz 0x000070DABBDDB900
000070dabbdd0387  nop [rax+rax*1], ax
000070dabbdd0390  nop [rax+rax*1], eax
000070dabbdd0398  mov eax, 0x410444
000070dabbdd039d  mov [r15+0x100], rax
000070dabbdd03a4  jmp 0x000070DABBBFE110
000070dabbdd03a9  cmp dword ptr [r15+0x318], 0x00
000070dabbdd03b1  jz 0x000070DABBDD57E0
000070dabbdd03b7  nop [rax+rax*1], ax
000070dabbdd03c0  nop [rax+rax*1], eax
000070dabbdd03c8  mov eax, 0x410278
000070dabbdd03cd  mov [r15+0x100], rax
000070dabbdd03d4  jmp 0x000070DABBBFE110
000070dabbdd03d9  int3
000070dabbdd03da  call 0x000070DABBCB52F0
000070dabbdd03df  jmp 0x000070DABBDCF016
000070dabbdd03e4  call 0x000070DABBCC4620
000070dabbdd03e9  jmp 0x000070DABBDCF023
000070dabbdd03ee  call 0x000070DABBCC33A0
000070dabbdd03f3  jmp 0x000070DABBDCF035
000070dabbdd03f8  call 0x000070DABBCC2120
000070dabbdd03fd  jmp 0x000070DABBDCF03F
000070dabbdd0402  call 0x000070DABBCC0860
000070dabbdd0407  jmp 0x000070DABBDCF067
000070dabbdd040c  call 0x000070DABBCBF5F0
000070dabbdd0411  jmp 0x000070DABBDCF073
000070dabbdd0416  call 0x000070DABBCC0860
000070dabbdd041b  jmp 0x000070DABBDCF0A5
000070dabbdd0420  call 0x000070DABBCBF5F0
000070dabbdd0425  jmp 0x000070DABBDCF0B1
000070dabbdd042a  call 0x000070DABBCC4740
000070dabbdd042f  jmp 0x000070DABBDCF0BE
000070dabbdd0434  call 0x000070DABBCB5400
000070dabbdd0439  jmp 0x000070DABBDCF0CB
000070dabbdd043e  call 0x000070DABBCB52F0
000070dabbdd0443  jmp 0x000070DABBDCF0D8
000070dabbdd0448  call 0x000070DABBCC4620
000070dabbdd044d  jmp 0x000070DABBDCF0E5
000070dabbdd0452  call 0x000070DABBCC0860
000070dabbdd0457  jmp 0x000070DABBDCF10D
000070dabbdd045c  call 0x000070DABBCBF5F0
000070dabbdd0461  jmp 0x000070DABBDCF119
000070dabbdd0466  call 0x000070DABBC09D70
000070dabbdd046b  jmp 0x000070DABBDCF11F
000070dabbdd0470  call 0x000070DABBCBE9C0
000070dabbdd0475  jmp 0x000070DABBDCF129
000070dabbdd047a  call 0x000070DABBCC0860
000070dabbdd047f  jmp 0x000070DABBDCF151
000070dabbdd0484  call 0x000070DABBCBF5F0
000070dabbdd0489  jmp 0x000070DABBDCF15D
000070dabbdd048e  call 0x000070DABBCBD750
000070dabbdd0493  jmp 0x000070DABBDCF16A
000070dabbdd0498  call 0x000070DABBCBC4E0
000070dabbdd049d  jmp 0x000070DABBDCF177
000070dabbdd04a2  call 0x000070DABBCC4740
000070dabbdd04a7  jmp 0x000070DABBDCF184
000070dabbdd04ac  call 0x000070DABBCB5400
000070dabbdd04b1  jmp 0x000070DABBDCF191
000070dabbdd04b6  call 0x000070DABBCB52F0
000070dabbdd04bb  jmp 0x000070DABBDCF19E
000070dabbdd04c0  call 0x000070DABBCC4620
000070dabbdd04c5  jmp 0x000070DABBDCF1AB
000070dabbdd04ca  call 0x000070DABBCC0860
000070dabbdd04cf  jmp 0x000070DABBDCF1BE
000070dabbdd04d4  call 0x000070DABBCBB270
000070dabbdd04d9  jmp 0x000070DABBDCF1CB
000070dabbdd04de  call 0x000070DABBCBA000
000070dabbdd04e3  jmp 0x000070DABBDCF1D8
000070dabbdd04e8  call 0x000070DABBCB8D90
000070dabbdd04ed  jmp 0x000070DABBDCF1E5
000070dabbdd04f2  call 0x000070DABBCB8A20
000070dabbdd04f7  jmp 0x000070DABBDCF1F2
000070dabbdd04fc  call 0x000070DABBCB5400
000070dabbdd0501  jmp 0x000070DABBDCF1FC
000070dabbdd0506  call 0x000070DABBCC2240
000070dabbdd050b  jmp 0x000070DABBDCF206
000070dabbdd0510  call 0x000070DABBCB52F0
000070dabbdd0515  jmp 0x000070DABBDCF210
000070dabbdd051a  call 0x000070DABBCC2120
000070dabbdd051f  jmp 0x000070DABBDCF21A
000070dabbdd0524  call 0x000070DABBCB77B0
000070dabbdd0529  jmp 0x000070DABBDCF224
000070dabbdd052e  call 0x000070DABBCB6550
000070dabbdd0533  jmp 0x000070DABBDCF22E
000070dabbdd0538  call 0x000070DABBCBFD50
000070dabbdd053d  jmp 0x000070DABBDCF240
000070dabbdd0542  call 0x000070DABBCB8EA0
000070dabbdd0547  jmp 0x000070DABBDCF24A
000070dabbdd054c  call 0x000070DABBCBFC30
000070dabbdd0551  jmp 0x000070DABBDCF257
000070dabbdd0556  call 0x000070DABBCB8D90
000070dabbdd055b  jmp 0x000070DABBDCF264
000070dabbdd0560  call 0x000070DABBCC2240
000070dabbdd0565  jmp 0x000070DABBDCF271
000070dabbdd056a  call 0x000070DABBCB5400
000070dabbdd056f  jmp 0x000070DABBDCF27E
000070dabbdd0574  call 0x000070DABBCB52F0
000070dabbdd0579  jmp 0x000070DABBDCF28B
000070dabbdd057e  call 0x000070DABBCC2120
000070dabbdd0583  jmp 0x000070DABBDCF298
000070dabbdd0588  call 0x000070DABBCB52F0
000070dabbdd058d  jmp 0x000070DABBDCF2AB
000070dabbdd0592  call 0x000070DABBCB52F0
000070dabbdd0597  jmp 0x000070DABBDCF2BE
000070dabbdd059c  call 0x000070DABBCB52F0
000070dabbdd05a1  jmp 0x000070DABBDCF2D1
000070dabbdd05a6  call 0x000070DABBCB52F0
000070dabbdd05ab  jmp 0x000070DABBDCF2E4
000070dabbdd05b0  call 0x000070DABBCC2240
000070dabbdd05b5  jmp 0x000070DABBDCF2F9
000070dabbdd05ba  call 0x000070DABBCC2240
000070dabbdd05bf  jmp 0x000070DABBDCF30C
000070dabbdd05c4  call 0x000070DABBCC2120
000070dabbdd05c9  jmp 0x000070DABBDCF319
000070dabbdd05ce  call 0x000070DABBCB52F0
000070dabbdd05d3  jmp 0x000070DABBDCF32C
000070dabbdd05d8  call 0x000070DABBCB52F0
000070dabbdd05dd  jmp 0x000070DABBDCF34F
000070dabbdd05e2  call 0x000070DABBCB52F0
000070dabbdd05e7  jmp 0x000070DABBDCF362
000070dabbdd05ec  call 0x000070DABBBFF540
000070dabbdd05f1  jmp 0x000070DABBDCF380
000070dabbdd05f6  call 0x000070DABBC08C20
000070dabbdd05fb  jmp 0x000070DABBDCF38A
000070dabbdd0600  call 0x000070DABBCD6600
000070dabbdd0605  jmp 0x000070DABBDCF396
000070dabbdd060a  call 0x000070DABBBFF540
000070dabbdd060f  jmp 0x000070DABBDCF3A6
000070dabbdd0614  call 0x000070DABBCC0370
000070dabbdd0619  jmp 0x000070DABBDCF3D4
000070dabbdd061e  call 0x000070DABBCBF100
000070dabbdd0623  jmp 0x000070DABBDCF3DD
000070dabbdd0628  call 0x000070DABBCC0370
000070dabbdd062d  jmp 0x000070DABBDCF43B
000070dabbdd0632  call 0x000070DABBCBF100
000070dabbdd0637  jmp 0x000070DABBDCF444
000070dabbdd063c  call 0x000070DABBCC0370
000070dabbdd0641  jmp 0x000070DABBDCF48B
000070dabbdd0646  call 0x000070DABBCBF100
000070dabbdd064b  jmp 0x000070DABBDCF494
000070dabbdd0650  call 0x000070DABBC0B720
000070dabbdd0655  jmp 0x000070DABBDCF4D7
000070dabbdd065a  call 0x000070DABBCB47C0
000070dabbdd065f  jmp 0x000070DABBDCF4EA
000070dabbdd0664  call 0x000070DABBC08B00
000070dabbdd0669  jmp 0x000070DABBDCF501
000070dabbdd066e  call 0x000070DABBBFF430
000070dabbdd0673  jmp 0x000070DABBDCF514
000070dabbdd0678  call 0x000070DABBBFF430
000070dabbdd067d  jmp 0x000070DABBDCF527
000070dabbdd0682  sub rsp, 0x08
000070dabbdd0686  push rax
000070dabbdd0687  push rcx
000070dabbdd0688  push rdx
000070dabbdd0689  push rdi
000070dabbdd068a  push rsi
000070dabbdd068b  push r8
000070dabbdd068d  push r9
000070dabbdd068f  push r10
000070dabbdd0691  push r11
000070dabbdd0693  sub rsp, 0xF0
000070dabbdd069a  vmovaps [rsp], xmm0
000070dabbdd069f  vmovaps [rsp+0x10], xmm2
000070dabbdd06a5  vmovaps [rsp+0x20], xmm3
000070dabbdd06ab  vmovaps [rsp+0x30], xmm4
000070dabbdd06b1  vmovaps [rsp+0x40], xmm5
000070dabbdd06b7  vmovaps [rsp+0x50], xmm6
000070dabbdd06bd  vmovaps [rsp+0x60], xmm7
000070dabbdd06c3  vmovaps [rsp+0x70], xmm8
000070dabbdd06c9  vmovaps [rsp+0x80], xmm9
000070dabbdd06d2  vmovaps [rsp+0x90], xmm10
000070dabbdd06db  vmovaps [rsp+0xA0], xmm11
000070dabbdd06e4  vmovaps [rsp+0xB0], xmm12
000070dabbdd06ed  vmovaps [rsp+0xC0], xmm13
000070dabbdd06f6  vmovaps [rsp+0xD0], xmm14
000070dabbdd06ff  vmovaps [rsp+0xE0], xmm15
000070dabbdd0708  sub rsp, 0x30
000070dabbdd070c  movaps [rsp], xmm1
000070dabbdd0710  movaps [rsp+0x10], xmm15
000070dabbdd0716  movaps [rsp+0x20], xmm14
000070dabbdd071c  lea rdi, [rsp]
000070dabbdd0720  mov esi, 0x00
000070dabbdd0725  mov rax, 0x5C2CF7B6F530
000070dabbdd072f  call rax
000070dabbdd0731  movaps xmm1, [rsp]
000070dabbdd0735  add rsp, 0x30
000070dabbdd0739  vmovaps xmm0, [rsp]
000070dabbdd073e  vmovaps xmm2, [rsp+0x10]
000070dabbdd0744  vmovaps xmm3, [rsp+0x20]
000070dabbdd074a  vmovaps xmm4, [rsp+0x30]
000070dabbdd0750  vmovaps xmm5, [rsp+0x40]
000070dabbdd0756  vmovaps xmm6, [rsp+0x50]
000070dabbdd075c  vmovaps xmm7, [rsp+0x60]
000070dabbdd0762  vmovaps xmm8, [rsp+0x70]
000070dabbdd0768  vmovaps xmm9, [rsp+0x80]
000070dabbdd0771  vmovaps xmm10, [rsp+0x90]
000070dabbdd077a  vmovaps xmm11, [rsp+0xA0]
000070dabbdd0783  vmovaps xmm12, [rsp+0xB0]
000070dabbdd078c  vmovaps xmm13, [rsp+0xC0]
000070dabbdd0795  vmovaps xmm14, [rsp+0xD0]
000070dabbdd079e  vmovaps xmm15, [rsp+0xE0]
000070dabbdd07a7  add rsp, 0xF0
000070dabbdd07ae  pop r11
000070dabbdd07b0  pop r10
000070dabbdd07b2  pop r9
000070dabbdd07b4  pop r8
000070dabbdd07b6  pop rsi
000070dabbdd07b7  pop rdi
000070dabbdd07b8  pop rdx
000070dabbdd07b9  pop rcx
000070dabbdd07ba  pop rax
000070dabbdd07bb  add rsp, 0x08
000070dabbdd07bf  jmp 0x000070DABBDCF581
000070dabbdd07c4  sub rsp, 0x08
000070dabbdd07c8  push rax
000070dabbdd07c9  push rcx
000070dabbdd07ca  push rdx
000070dabbdd07cb  push rdi
000070dabbdd07cc  push rsi
000070dabbdd07cd  push r8
000070dabbdd07cf  push r9
000070dabbdd07d1  push r10
000070dabbdd07d3  push r11
000070dabbdd07d5  sub rsp, 0xF0
000070dabbdd07dc  vmovaps [rsp], xmm0
000070dabbdd07e1  vmovaps [rsp+0x10], xmm1
000070dabbdd07e7  vmovaps [rsp+0x20], xmm2
000070dabbdd07ed  vmovaps [rsp+0x30], xmm3
000070dabbdd07f3  vmovaps [rsp+0x40], xmm4
000070dabbdd07f9  vmovaps [rsp+0x50], xmm5
000070dabbdd07ff  vmovaps [rsp+0x60], xmm6
000070dabbdd0805  vmovaps [rsp+0x70], xmm7
000070dabbdd080b  vmovaps [rsp+0x80], xmm8
000070dabbdd0814  vmovaps [rsp+0x90], xmm9
000070dabbdd081d  vmovaps [rsp+0xA0], xmm10
000070dabbdd0826  vmovaps [rsp+0xB0], xmm11
000070dabbdd082f  vmovaps [rsp+0xC0], xmm12
000070dabbdd0838  vmovaps [rsp+0xD0], xmm14
000070dabbdd0841  vmovaps [rsp+0xE0], xmm15
000070dabbdd084a  sub rsp, 0x30
000070dabbdd084e  movaps [rsp], xmm13
000070dabbdd0853  movaps [rsp+0x10], xmm1
000070dabbdd0858  movaps [rsp+0x20], xmm14
000070dabbdd085e  lea rdi, [rsp]
000070dabbdd0862  mov esi, 0x00
000070dabbdd0867  mov rax, 0x5C2CF7B6F530
000070dabbdd0871  call rax
000070dabbdd0873  movaps xmm13, [rsp]
000070dabbdd0878  add rsp, 0x30
000070dabbdd087c  vmovaps xmm0, [rsp]
000070dabbdd0881  vmovaps xmm1, [rsp+0x10]
000070dabbdd0887  vmovaps xmm2, [rsp+0x20]
000070dabbdd088d  vmovaps xmm3, [rsp+0x30]
000070dabbdd0893  vmovaps xmm4, [rsp+0x40]
000070dabbdd0899  vmovaps xmm5, [rsp+0x50]
000070dabbdd089f  vmovaps xmm6, [rsp+0x60]
000070dabbdd08a5  vmovaps xmm7, [rsp+0x70]
000070dabbdd08ab  vmovaps xmm8, [rsp+0x80]
000070dabbdd08b4  vmovaps xmm9, [rsp+0x90]
000070dabbdd08bd  vmovaps xmm10, [rsp+0xA0]
000070dabbdd08c6  vmovaps xmm11, [rsp+0xB0]
000070dabbdd08cf  vmovaps xmm12, [rsp+0xC0]
000070dabbdd08d8  vmovaps xmm14, [rsp+0xD0]
000070dabbdd08e1  vmovaps xmm15, [rsp+0xE0]
000070dabbdd08ea  add rsp, 0xF0
000070dabbdd08f1  pop r11
000070dabbdd08f3  pop r10
000070dabbdd08f5  pop r9
000070dabbdd08f7  pop r8
000070dabbdd08f9  pop rsi
000070dabbdd08fa  pop rdi
000070dabbdd08fb  pop rdx
000070dabbdd08fc  pop rcx
000070dabbdd08fd  pop rax
000070dabbdd08fe  add rsp, 0x08
000070dabbdd0902  jmp 0x000070DABBDCF5CF
000070dabbdd0907  sub rsp, 0x08
000070dabbdd090b  push rax
000070dabbdd090c  push rcx
000070dabbdd090d  push rdx
000070dabbdd090e  push rdi
000070dabbdd090f  push rsi
000070dabbdd0910  push r8
000070dabbdd0912  push r9
000070dabbdd0914  push r10
000070dabbdd0916  push r11
000070dabbdd0918  sub rsp, 0xF0
000070dabbdd091f  vmovaps [rsp], xmm0
000070dabbdd0924  vmovaps [rsp+0x10], xmm1
000070dabbdd092a  vmovaps [rsp+0x20], xmm2
000070dabbdd0930  vmovaps [rsp+0x30], xmm3
000070dabbdd0936  vmovaps [rsp+0x40], xmm4
000070dabbdd093c  vmovaps [rsp+0x50], xmm5
000070dabbdd0942  vmovaps [rsp+0x60], xmm6
000070dabbdd0948  vmovaps [rsp+0x70], xmm7
000070dabbdd094e  vmovaps [rsp+0x80], xmm8
000070dabbdd0957  vmovaps [rsp+0x90], xmm9
000070dabbdd0960  vmovaps [rsp+0xA0], xmm10
000070dabbdd0969  vmovaps [rsp+0xB0], xmm11
000070dabbdd0972  vmovaps [rsp+0xC0], xmm12
000070dabbdd097b  vmovaps [rsp+0xD0], xmm13
000070dabbdd0984  vmovaps [rsp+0xE0], xmm14
000070dabbdd098d  sub rsp, 0x30
000070dabbdd0991  movaps [rsp], xmm15
000070dabbdd0996  movaps [rsp+0x10], xmm14
000070dabbdd099c  movaps [rsp+0x20], xmm1
000070dabbdd09a1  lea rdi, [rsp]
000070dabbdd09a5  mov esi, 0x00
000070dabbdd09aa  mov rax, 0x5C2CF7B6F530
000070dabbdd09b4  call rax
000070dabbdd09b6  movaps xmm15, [rsp]
000070dabbdd09bb  add rsp, 0x30
000070dabbdd09bf  vmovaps xmm0, [rsp]
000070dabbdd09c4  vmovaps xmm1, [rsp+0x10]
000070dabbdd09ca  vmovaps xmm2, [rsp+0x20]
000070dabbdd09d0  vmovaps xmm3, [rsp+0x30]
000070dabbdd09d6  vmovaps xmm4, [rsp+0x40]
000070dabbdd09dc  vmovaps xmm5, [rsp+0x50]
000070dabbdd09e2  vmovaps xmm6, [rsp+0x60]
000070dabbdd09e8  vmovaps xmm7, [rsp+0x70]
000070dabbdd09ee  vmovaps xmm8, [rsp+0x80]
000070dabbdd09f7  vmovaps xmm9, [rsp+0x90]
000070dabbdd0a00  vmovaps xmm10, [rsp+0xA0]
000070dabbdd0a09  vmovaps xmm11, [rsp+0xB0]
000070dabbdd0a12  vmovaps xmm12, [rsp+0xC0]
000070dabbdd0a1b  vmovaps xmm13, [rsp+0xD0]
000070dabbdd0a24  vmovaps xmm14, [rsp+0xE0]
000070dabbdd0a2d  add rsp, 0xF0
000070dabbdd0a34  pop r11
000070dabbdd0a36  pop r10
000070dabbdd0a38  pop r9
000070dabbdd0a3a  pop r8
000070dabbdd0a3c  pop rsi
000070dabbdd0a3d  pop rdi
000070dabbdd0a3e  pop rdx
000070dabbdd0a3f  pop rcx
000070dabbdd0a40  pop rax
000070dabbdd0a41  add rsp, 0x08
000070dabbdd0a45  jmp 0x000070DABBDCF617
000070dabbdd0a4a  sub rsp, 0x08
000070dabbdd0a4e  push rax
000070dabbdd0a4f  push rcx
000070dabbdd0a50  push rdx
000070dabbdd0a51  push rdi
000070dabbdd0a52  push rsi
000070dabbdd0a53  push r8
000070dabbdd0a55  push r9
000070dabbdd0a57  push r10
000070dabbdd0a59  push r11
000070dabbdd0a5b  sub rsp, 0xF0
000070dabbdd0a62  vmovaps [rsp], xmm0
000070dabbdd0a67  vmovaps [rsp+0x10], xmm2
000070dabbdd0a6d  vmovaps [rsp+0x20], xmm3
000070dabbdd0a73  vmovaps [rsp+0x30], xmm4
000070dabbdd0a79  vmovaps [rsp+0x40], xmm5
000070dabbdd0a7f  vmovaps [rsp+0x50], xmm6
000070dabbdd0a85  vmovaps [rsp+0x60], xmm7
000070dabbdd0a8b  vmovaps [rsp+0x70], xmm8
000070dabbdd0a91  vmovaps [rsp+0x80], xmm9
000070dabbdd0a9a  vmovaps [rsp+0x90], xmm10
000070dabbdd0aa3  vmovaps [rsp+0xA0], xmm11
000070dabbdd0aac  vmovaps [rsp+0xB0], xmm12
000070dabbdd0ab5  vmovaps [rsp+0xC0], xmm13
000070dabbdd0abe  vmovaps [rsp+0xD0], xmm14
000070dabbdd0ac7  vmovaps [rsp+0xE0], xmm15
000070dabbdd0ad0  sub rsp, 0x30
000070dabbdd0ad4  movaps [rsp], xmm1
000070dabbdd0ad8  movaps [rsp+0x10], xmm14
000070dabbdd0ade  movaps [rsp+0x20], xmm10
000070dabbdd0ae4  lea rdi, [rsp]
000070dabbdd0ae8  mov esi, 0x00
000070dabbdd0aed  mov rax, 0x5C2CF7B6F530
000070dabbdd0af7  call rax
000070dabbdd0af9  movaps xmm1, [rsp]
000070dabbdd0afd  add rsp, 0x30
000070dabbdd0b01  vmovaps xmm0, [rsp]
000070dabbdd0b06  vmovaps xmm2, [rsp+0x10]
000070dabbdd0b0c  vmovaps xmm3, [rsp+0x20]
000070dabbdd0b12  vmovaps xmm4, [rsp+0x30]
000070dabbdd0b18  vmovaps xmm5, [rsp+0x40]
000070dabbdd0b1e  vmovaps xmm6, [rsp+0x50]
000070dabbdd0b24  vmovaps xmm7, [rsp+0x60]
000070dabbdd0b2a  vmovaps xmm8, [rsp+0x70]
000070dabbdd0b30  vmovaps xmm9, [rsp+0x80]
000070dabbdd0b39  vmovaps xmm10, [rsp+0x90]
000070dabbdd0b42  vmovaps xmm11, [rsp+0xA0]
000070dabbdd0b4b  vmovaps xmm12, [rsp+0xB0]
000070dabbdd0b54  vmovaps xmm13, [rsp+0xC0]
000070dabbdd0b5d  vmovaps xmm14, [rsp+0xD0]
000070dabbdd0b66  vmovaps xmm15, [rsp+0xE0]
000070dabbdd0b6f  add rsp, 0xF0
000070dabbdd0b76  pop r11
000070dabbdd0b78  pop r10
000070dabbdd0b7a  pop r9
000070dabbdd0b7c  pop r8
000070dabbdd0b7e  pop rsi
000070dabbdd0b7f  pop rdi
000070dabbdd0b80  pop rdx
000070dabbdd0b81  pop rcx
000070dabbdd0b82  pop rax
000070dabbdd0b83  add rsp, 0x08
000070dabbdd0b87  jmp 0x000070DABBDCF631
000070dabbdd0b8c  sub rsp, 0x08
000070dabbdd0b90  push rax
000070dabbdd0b91  push rcx
000070dabbdd0b92  push rdx
000070dabbdd0b93  push rdi
000070dabbdd0b94  push rsi
000070dabbdd0b95  push r8
000070dabbdd0b97  push r9
000070dabbdd0b99  push r10
000070dabbdd0b9b  push r11
000070dabbdd0b9d  sub rsp, 0xF0
000070dabbdd0ba4  vmovaps [rsp], xmm0
000070dabbdd0ba9  vmovaps [rsp+0x10], xmm1
000070dabbdd0baf  vmovaps [rsp+0x20], xmm2
000070dabbdd0bb5  vmovaps [rsp+0x30], xmm3
000070dabbdd0bbb  vmovaps [rsp+0x40], xmm4
000070dabbdd0bc1  vmovaps [rsp+0x50], xmm5
000070dabbdd0bc7  vmovaps [rsp+0x60], xmm6
000070dabbdd0bcd  vmovaps [rsp+0x70], xmm7
000070dabbdd0bd3  vmovaps [rsp+0x80], xmm8
000070dabbdd0bdc  vmovaps [rsp+0x90], xmm9
000070dabbdd0be5  vmovaps [rsp+0xA0], xmm10
000070dabbdd0bee  vmovaps [rsp+0xB0], xmm11
000070dabbdd0bf7  vmovaps [rsp+0xC0], xmm12
000070dabbdd0c00  vmovaps [rsp+0xD0], xmm14
000070dabbdd0c09  vmovaps [rsp+0xE0], xmm15
000070dabbdd0c12  sub rsp, 0x30
000070dabbdd0c16  movaps [rsp], xmm13
000070dabbdd0c1b  movaps [rsp+0x10], xmm14
000070dabbdd0c21  movaps [rsp+0x20], xmm2
000070dabbdd0c26  lea rdi, [rsp]
000070dabbdd0c2a  mov esi, 0x00
000070dabbdd0c2f  mov rax, 0x5C2CF7B6F530
000070dabbdd0c39  call rax
000070dabbdd0c3b  movaps xmm13, [rsp]
000070dabbdd0c40  add rsp, 0x30
000070dabbdd0c44  vmovaps xmm0, [rsp]
000070dabbdd0c49  vmovaps xmm1, [rsp+0x10]
000070dabbdd0c4f  vmovaps xmm2, [rsp+0x20]
000070dabbdd0c55  vmovaps xmm3, [rsp+0x30]
000070dabbdd0c5b  vmovaps xmm4, [rsp+0x40]
000070dabbdd0c61  vmovaps xmm5, [rsp+0x50]
000070dabbdd0c67  vmovaps xmm6, [rsp+0x60]
000070dabbdd0c6d  vmovaps xmm7, [rsp+0x70]
000070dabbdd0c73  vmovaps xmm8, [rsp+0x80]
000070dabbdd0c7c  vmovaps xmm9, [rsp+0x90]
000070dabbdd0c85  vmovaps xmm10, [rsp+0xA0]
000070dabbdd0c8e  vmovaps xmm11, [rsp+0xB0]
000070dabbdd0c97  vmovaps xmm12, [rsp+0xC0]
000070dabbdd0ca0  vmovaps xmm14, [rsp+0xD0]
000070dabbdd0ca9  vmovaps xmm15, [rsp+0xE0]
000070dabbdd0cb2  add rsp, 0xF0
000070dabbdd0cb9  pop r11
000070dabbdd0cbb  pop r10
000070dabbdd0cbd  pop r9
000070dabbdd0cbf  pop r8
000070dabbdd0cc1  pop rsi
000070dabbdd0cc2  pop rdi
000070dabbdd0cc3  pop rdx
000070dabbdd0cc4  pop rcx
000070dabbdd0cc5  pop rax
000070dabbdd0cc6  add rsp, 0x08
000070dabbdd0cca  jmp 0x000070DABBDCF64C
000070dabbdd0ccf  sub rsp, 0x08
000070dabbdd0cd3  push rax
000070dabbdd0cd4  push rcx
000070dabbdd0cd5  push rdx
000070dabbdd0cd6  push rdi
000070dabbdd0cd7  push rsi
000070dabbdd0cd8  push r8
000070dabbdd0cda  push r9
000070dabbdd0cdc  push r10
000070dabbdd0cde  push r11
000070dabbdd0ce0  sub rsp, 0xF0
000070dabbdd0ce7  vmovaps [rsp], xmm0
000070dabbdd0cec  vmovaps [rsp+0x10], xmm2
000070dabbdd0cf2  vmovaps [rsp+0x20], xmm3
000070dabbdd0cf8  vmovaps [rsp+0x30], xmm4
000070dabbdd0cfe  vmovaps [rsp+0x40], xmm5
000070dabbdd0d04  vmovaps [rsp+0x50], xmm6
000070dabbdd0d0a  vmovaps [rsp+0x60], xmm7
000070dabbdd0d10  vmovaps [rsp+0x70], xmm8
000070dabbdd0d16  vmovaps [rsp+0x80], xmm9
000070dabbdd0d1f  vmovaps [rsp+0x90], xmm10
000070dabbdd0d28  vmovaps [rsp+0xA0], xmm11
000070dabbdd0d31  vmovaps [rsp+0xB0], xmm12
000070dabbdd0d3a  vmovaps [rsp+0xC0], xmm13
000070dabbdd0d43  vmovaps [rsp+0xD0], xmm14
000070dabbdd0d4c  vmovaps [rsp+0xE0], xmm15
000070dabbdd0d55  sub rsp, 0x30
000070dabbdd0d59  movaps [rsp], xmm1
000070dabbdd0d5d  movaps [rsp+0x10], xmm10
000070dabbdd0d63  movaps [rsp+0x20], xmm2
000070dabbdd0d68  lea rdi, [rsp]
000070dabbdd0d6c  mov esi, 0x00
000070dabbdd0d71  mov rax, 0x5C2CF7B6F530
000070dabbdd0d7b  call rax
000070dabbdd0d7d  movaps xmm1, [rsp]
000070dabbdd0d81  add rsp, 0x30
000070dabbdd0d85  vmovaps xmm0, [rsp]
000070dabbdd0d8a  vmovaps xmm2, [rsp+0x10]
000070dabbdd0d90  vmovaps xmm3, [rsp+0x20]
000070dabbdd0d96  vmovaps xmm4, [rsp+0x30]
000070dabbdd0d9c  vmovaps xmm5, [rsp+0x40]
000070dabbdd0da2  vmovaps xmm6, [rsp+0x50]
000070dabbdd0da8  vmovaps xmm7, [rsp+0x60]
000070dabbdd0dae  vmovaps xmm8, [rsp+0x70]
000070dabbdd0db4  vmovaps xmm9, [rsp+0x80]
000070dabbdd0dbd  vmovaps xmm10, [rsp+0x90]
000070dabbdd0dc6  vmovaps xmm11, [rsp+0xA0]
000070dabbdd0dcf  vmovaps xmm12, [rsp+0xB0]
000070dabbdd0dd8  vmovaps xmm13, [rsp+0xC0]
000070dabbdd0de1  vmovaps xmm14, [rsp+0xD0]
000070dabbdd0dea  vmovaps xmm15, [rsp+0xE0]
000070dabbdd0df3  add rsp, 0xF0
000070dabbdd0dfa  pop r11
000070dabbdd0dfc  pop r10
000070dabbdd0dfe  pop r9
000070dabbdd0e00  pop r8
000070dabbdd0e02  pop rsi
000070dabbdd0e03  pop rdi
000070dabbdd0e04  pop rdx
000070dabbdd0e05  pop rcx
000070dabbdd0e06  pop rax
000070dabbdd0e07  add rsp, 0x08
000070dabbdd0e0b  jmp 0x000070DABBDCF6B4
000070dabbdd0e10  sub rsp, 0x08
000070dabbdd0e14  push rax
000070dabbdd0e15  push rcx
000070dabbdd0e16  push rdx
000070dabbdd0e17  push rdi
000070dabbdd0e18  push rsi
000070dabbdd0e19  push r8
000070dabbdd0e1b  push r9
000070dabbdd0e1d  push r10
000070dabbdd0e1f  push r11
000070dabbdd0e21  sub rsp, 0xF0
000070dabbdd0e28  vmovaps [rsp], xmm0
000070dabbdd0e2d  vmovaps [rsp+0x10], xmm1
000070dabbdd0e33  vmovaps [rsp+0x20], xmm2
000070dabbdd0e39  vmovaps [rsp+0x30], xmm3
000070dabbdd0e3f  vmovaps [rsp+0x40], xmm4
000070dabbdd0e45  vmovaps [rsp+0x50], xmm5
000070dabbdd0e4b  vmovaps [rsp+0x60], xmm6
000070dabbdd0e51  vmovaps [rsp+0x70], xmm7
000070dabbdd0e57  vmovaps [rsp+0x80], xmm8
000070dabbdd0e60  vmovaps [rsp+0x90], xmm9
000070dabbdd0e69  vmovaps [rsp+0xA0], xmm10
000070dabbdd0e72  vmovaps [rsp+0xB0], xmm11
000070dabbdd0e7b  vmovaps [rsp+0xC0], xmm12
000070dabbdd0e84  vmovaps [rsp+0xD0], xmm13
000070dabbdd0e8d  vmovaps [rsp+0xE0], xmm14
000070dabbdd0e96  sub rsp, 0x30
000070dabbdd0e9a  movaps [rsp], xmm15
000070dabbdd0e9f  movaps [rsp+0x10], xmm10
000070dabbdd0ea5  movaps [rsp+0x20], xmm2
000070dabbdd0eaa  lea rdi, [rsp]
000070dabbdd0eae  mov esi, 0x00
000070dabbdd0eb3  mov rax, 0x5C2CF7B6F530
000070dabbdd0ebd  call rax
000070dabbdd0ebf  movaps xmm15, [rsp]
000070dabbdd0ec4  add rsp, 0x30
000070dabbdd0ec8  vmovaps xmm0, [rsp]
000070dabbdd0ecd  vmovaps xmm1, [rsp+0x10]
000070dabbdd0ed3  vmovaps xmm2, [rsp+0x20]
000070dabbdd0ed9  vmovaps xmm3, [rsp+0x30]
000070dabbdd0edf  vmovaps xmm4, [rsp+0x40]
000070dabbdd0ee5  vmovaps xmm5, [rsp+0x50]
000070dabbdd0eeb  vmovaps xmm6, [rsp+0x60]
000070dabbdd0ef1  vmovaps xmm7, [rsp+0x70]
000070dabbdd0ef7  vmovaps xmm8, [rsp+0x80]
000070dabbdd0f00  vmovaps xmm9, [rsp+0x90]
000070dabbdd0f09  vmovaps xmm10, [rsp+0xA0]
000070dabbdd0f12  vmovaps xmm11, [rsp+0xB0]
000070dabbdd0f1b  vmovaps xmm12, [rsp+0xC0]
000070dabbdd0f24  vmovaps xmm13, [rsp+0xD0]
000070dabbdd0f2d  vmovaps xmm14, [rsp+0xE0]
000070dabbdd0f36  add rsp, 0xF0
000070dabbdd0f3d  pop r11
000070dabbdd0f3f  pop r10
000070dabbdd0f41  pop r9
000070dabbdd0f43  pop r8
000070dabbdd0f45  pop rsi
000070dabbdd0f46  pop rdi
000070dabbdd0f47  pop rdx
000070dabbdd0f48  pop rcx
000070dabbdd0f49  pop rax
000070dabbdd0f4a  add rsp, 0x08
000070dabbdd0f4e  jmp 0x000070DABBDCF706
000070dabbdd0f53  sub rsp, 0x08
000070dabbdd0f57  push rax
000070dabbdd0f58  push rcx
000070dabbdd0f59  push rdx
000070dabbdd0f5a  push rdi
000070dabbdd0f5b  push rsi
000070dabbdd0f5c  push r8
000070dabbdd0f5e  push r9
000070dabbdd0f60  push r10
000070dabbdd0f62  push r11
000070dabbdd0f64  sub rsp, 0xF0
000070dabbdd0f6b  vmovaps [rsp], xmm0
000070dabbdd0f70  vmovaps [rsp+0x10], xmm2
000070dabbdd0f76  vmovaps [rsp+0x20], xmm3
000070dabbdd0f7c  vmovaps [rsp+0x30], xmm4
000070dabbdd0f82  vmovaps [rsp+0x40], xmm5
000070dabbdd0f88  vmovaps [rsp+0x50], xmm6
000070dabbdd0f8e  vmovaps [rsp+0x60], xmm7
000070dabbdd0f94  vmovaps [rsp+0x70], xmm8
000070dabbdd0f9a  vmovaps [rsp+0x80], xmm9
000070dabbdd0fa3  vmovaps [rsp+0x90], xmm10
000070dabbdd0fac  vmovaps [rsp+0xA0], xmm11
000070dabbdd0fb5  vmovaps [rsp+0xB0], xmm12
000070dabbdd0fbe  vmovaps [rsp+0xC0], xmm13
000070dabbdd0fc7  vmovaps [rsp+0xD0], xmm14
000070dabbdd0fd0  vmovaps [rsp+0xE0], xmm15
000070dabbdd0fd9  sub rsp, 0x30
000070dabbdd0fdd  movaps [rsp], xmm1
000070dabbdd0fe1  movaps [rsp+0x10], xmm10
000070dabbdd0fe7  movaps [rsp+0x20], xmm12
000070dabbdd0fed  lea rdi, [rsp]
000070dabbdd0ff1  mov esi, 0x00
000070dabbdd0ff6  mov rax, 0x5C2CF7B6F530
000070dabbdd1000  call rax
000070dabbdd1002  movaps xmm1, [rsp]
000070dabbdd1006  add rsp, 0x30
000070dabbdd100a  vmovaps xmm0, [rsp]
000070dabbdd100f  vmovaps xmm2, [rsp+0x10]
000070dabbdd1015  vmovaps xmm3, [rsp+0x20]
000070dabbdd101b  vmovaps xmm4, [rsp+0x30]
000070dabbdd1021  vmovaps xmm5, [rsp+0x40]
000070dabbdd1027  vmovaps xmm6, [rsp+0x50]
000070dabbdd102d  vmovaps xmm7, [rsp+0x60]
000070dabbdd1033  vmovaps xmm8, [rsp+0x70]
000070dabbdd1039  vmovaps xmm9, [rsp+0x80]
000070dabbdd1042  vmovaps xmm10, [rsp+0x90]
000070dabbdd104b  vmovaps xmm11, [rsp+0xA0]
000070dabbdd1054  vmovaps xmm12, [rsp+0xB0]
000070dabbdd105d  vmovaps xmm13, [rsp+0xC0]
000070dabbdd1066  vmovaps xmm14, [rsp+0xD0]
000070dabbdd106f  vmovaps xmm15, [rsp+0xE0]
000070dabbdd1078  add rsp, 0xF0
000070dabbdd107f  pop r11
000070dabbdd1081  pop r10
000070dabbdd1083  pop r9
000070dabbdd1085  pop r8
000070dabbdd1087  pop rsi
000070dabbdd1088  pop rdi
000070dabbdd1089  pop rdx
000070dabbdd108a  pop rcx
000070dabbdd108b  pop rax
000070dabbdd108c  add rsp, 0x08
000070dabbdd1090  jmp 0x000070DABBDCF732
000070dabbdd1095  sub rsp, 0x08
000070dabbdd1099  push rax
000070dabbdd109a  push rcx
000070dabbdd109b  push rdx
000070dabbdd109c  push rdi
000070dabbdd109d  push rsi
000070dabbdd109e  push r8
000070dabbdd10a0  push r9
000070dabbdd10a2  push r10
000070dabbdd10a4  push r11
000070dabbdd10a6  sub rsp, 0xF0
000070dabbdd10ad  vmovaps [rsp], xmm0
000070dabbdd10b2  vmovaps [rsp+0x10], xmm1
000070dabbdd10b8  vmovaps [rsp+0x20], xmm2
000070dabbdd10be  vmovaps [rsp+0x30], xmm3
000070dabbdd10c4  vmovaps [rsp+0x40], xmm4
000070dabbdd10ca  vmovaps [rsp+0x50], xmm5
000070dabbdd10d0  vmovaps [rsp+0x60], xmm6
000070dabbdd10d6  vmovaps [rsp+0x70], xmm7
000070dabbdd10dc  vmovaps [rsp+0x80], xmm8
000070dabbdd10e5  vmovaps [rsp+0x90], xmm9
000070dabbdd10ee  vmovaps [rsp+0xA0], xmm10
000070dabbdd10f7  vmovaps [rsp+0xB0], xmm11
000070dabbdd1100  vmovaps [rsp+0xC0], xmm12
000070dabbdd1109  vmovaps [rsp+0xD0], xmm13
000070dabbdd1112  vmovaps [rsp+0xE0], xmm14
000070dabbdd111b  sub rsp, 0x30
000070dabbdd111f  movaps [rsp], xmm15
000070dabbdd1124  movaps [rsp+0x10], xmm10
000070dabbdd112a  movaps [rsp+0x20], xmm12
000070dabbdd1130  lea rdi, [rsp]
000070dabbdd1134  mov esi, 0x00
000070dabbdd1139  mov rax, 0x5C2CF7B6F530
000070dabbdd1143  call rax
000070dabbdd1145  movaps xmm15, [rsp]
000070dabbdd114a  add rsp, 0x30
000070dabbdd114e  vmovaps xmm0, [rsp]
000070dabbdd1153  vmovaps xmm1, [rsp+0x10]
000070dabbdd1159  vmovaps xmm2, [rsp+0x20]
000070dabbdd115f  vmovaps xmm3, [rsp+0x30]
000070dabbdd1165  vmovaps xmm4, [rsp+0x40]
000070dabbdd116b  vmovaps xmm5, [rsp+0x50]
000070dabbdd1171  vmovaps xmm6, [rsp+0x60]
000070dabbdd1177  vmovaps xmm7, [rsp+0x70]
000070dabbdd117d  vmovaps xmm8, [rsp+0x80]
000070dabbdd1186  vmovaps xmm9, [rsp+0x90]
000070dabbdd118f  vmovaps xmm10, [rsp+0xA0]
000070dabbdd1198  vmovaps xmm11, [rsp+0xB0]
000070dabbdd11a1  vmovaps xmm12, [rsp+0xC0]
000070dabbdd11aa  vmovaps xmm13, [rsp+0xD0]
000070dabbdd11b3  vmovaps xmm14, [rsp+0xE0]
000070dabbdd11bc  add rsp, 0xF0
000070dabbdd11c3  pop r11
000070dabbdd11c5  pop r10
000070dabbdd11c7  pop r9
000070dabbdd11c9  pop r8
000070dabbdd11cb  pop rsi
000070dabbdd11cc  pop rdi
000070dabbdd11cd  pop rdx
000070dabbdd11ce  pop rcx
000070dabbdd11cf  pop rax
000070dabbdd11d0  add rsp, 0x08
000070dabbdd11d4  jmp 0x000070DABBDCF75E
000070dabbdd11d9  call 0x000070DABBBFF430
000070dabbdd11de  jmp 0x000070DABBDCF7EE
000070dabbdd11e3  call 0x000070DABBBFF430
000070dabbdd11e8  jmp 0x000070DABBDCF801
000070dabbdd11ed  sub rsp, 0x08
000070dabbdd11f1  push rax
000070dabbdd11f2  push rcx
000070dabbdd11f3  push rdx
000070dabbdd11f4  push rdi
000070dabbdd11f5  push rsi
000070dabbdd11f6  push r8
000070dabbdd11f8  push r9
000070dabbdd11fa  push r10
000070dabbdd11fc  push r11
000070dabbdd11fe  sub rsp, 0xF0
000070dabbdd1205  vmovaps [rsp], xmm0
000070dabbdd120a  vmovaps [rsp+0x10], xmm2
000070dabbdd1210  vmovaps [rsp+0x20], xmm3
000070dabbdd1216  vmovaps [rsp+0x30], xmm4
000070dabbdd121c  vmovaps [rsp+0x40], xmm5
000070dabbdd1222  vmovaps [rsp+0x50], xmm6
000070dabbdd1228  vmovaps [rsp+0x60], xmm7
000070dabbdd122e  vmovaps [rsp+0x70], xmm8
000070dabbdd1234  vmovaps [rsp+0x80], xmm9
000070dabbdd123d  vmovaps [rsp+0x90], xmm10
000070dabbdd1246  vmovaps [rsp+0xA0], xmm11
000070dabbdd124f  vmovaps [rsp+0xB0], xmm12
000070dabbdd1258  vmovaps [rsp+0xC0], xmm13
000070dabbdd1261  vmovaps [rsp+0xD0], xmm14
000070dabbdd126a  vmovaps [rsp+0xE0], xmm15
000070dabbdd1273  sub rsp, 0x30
000070dabbdd1277  movaps [rsp], xmm1
000070dabbdd127b  movaps [rsp+0x10], xmm13
000070dabbdd1281  movaps [rsp+0x20], xmm2
000070dabbdd1286  lea rdi, [rsp]
000070dabbdd128a  mov esi, 0x00
000070dabbdd128f  mov rax, 0x5C2CF7B6F530
000070dabbdd1299  call rax
000070dabbdd129b  movaps xmm1, [rsp]
000070dabbdd129f  add rsp, 0x30
000070dabbdd12a3  vmovaps xmm0, [rsp]
000070dabbdd12a8  vmovaps xmm2, [rsp+0x10]
000070dabbdd12ae  vmovaps xmm3, [rsp+0x20]
000070dabbdd12b4  vmovaps xmm4, [rsp+0x30]
000070dabbdd12ba  vmovaps xmm5, [rsp+0x40]
000070dabbdd12c0  vmovaps xmm6, [rsp+0x50]
000070dabbdd12c6  vmovaps xmm7, [rsp+0x60]
000070dabbdd12cc  vmovaps xmm8, [rsp+0x70]
000070dabbdd12d2  vmovaps xmm9, [rsp+0x80]
000070dabbdd12db  vmovaps xmm10, [rsp+0x90]
000070dabbdd12e4  vmovaps xmm11, [rsp+0xA0]
000070dabbdd12ed  vmovaps xmm12, [rsp+0xB0]
000070dabbdd12f6  vmovaps xmm13, [rsp+0xC0]
000070dabbdd12ff  vmovaps xmm14, [rsp+0xD0]
000070dabbdd1308  vmovaps xmm15, [rsp+0xE0]
000070dabbdd1311  add rsp, 0xF0
000070dabbdd1318  pop r11
000070dabbdd131a  pop r10
000070dabbdd131c  pop r9
000070dabbdd131e  pop r8
000070dabbdd1320  pop rsi
000070dabbdd1321  pop rdi
000070dabbdd1322  pop rdx
000070dabbdd1323  pop rcx
000070dabbdd1324  pop rax
000070dabbdd1325  add rsp, 0x08
000070dabbdd1329  jmp 0x000070DABBDCF82C
000070dabbdd132e  call 0x000070DABBC0E760
000070dabbdd1333  jmp 0x000070DABBDCF839
000070dabbdd1338  sub rsp, 0x08
000070dabbdd133c  push rax
000070dabbdd133d  push rcx
000070dabbdd133e  push rdx
000070dabbdd133f  push rdi
000070dabbdd1340  push rsi
000070dabbdd1341  push r8
000070dabbdd1343  push r9
000070dabbdd1345  push r10
000070dabbdd1347  push r11
000070dabbdd1349  sub rsp, 0xF0
000070dabbdd1350  vmovaps [rsp], xmm0
000070dabbdd1355  vmovaps [rsp+0x10], xmm1
000070dabbdd135b  vmovaps [rsp+0x20], xmm2
000070dabbdd1361  vmovaps [rsp+0x30], xmm3
000070dabbdd1367  vmovaps [rsp+0x40], xmm4
000070dabbdd136d  vmovaps [rsp+0x50], xmm5
000070dabbdd1373  vmovaps [rsp+0x60], xmm6
000070dabbdd1379  vmovaps [rsp+0x70], xmm7
000070dabbdd137f  vmovaps [rsp+0x80], xmm8
000070dabbdd1388  vmovaps [rsp+0x90], xmm9
000070dabbdd1391  vmovaps [rsp+0xA0], xmm10
000070dabbdd139a  vmovaps [rsp+0xB0], xmm11
000070dabbdd13a3  vmovaps [rsp+0xC0], xmm12
000070dabbdd13ac  vmovaps [rsp+0xD0], xmm14
000070dabbdd13b5  vmovaps [rsp+0xE0], xmm15
000070dabbdd13be  sub rsp, 0x30
000070dabbdd13c2  movaps [rsp], xmm13
000070dabbdd13c7  movaps [rsp+0x10], xmm2
000070dabbdd13cc  movaps [rsp+0x20], xmm1
000070dabbdd13d1  lea rdi, [rsp]
000070dabbdd13d5  mov esi, 0x00
000070dabbdd13da  mov rax, 0x5C2CF7B6F530
000070dabbdd13e4  call rax
000070dabbdd13e6  movaps xmm13, [rsp]
000070dabbdd13eb  add rsp, 0x30
000070dabbdd13ef  vmovaps xmm0, [rsp]
000070dabbdd13f4  vmovaps xmm1, [rsp+0x10]
000070dabbdd13fa  vmovaps xmm2, [rsp+0x20]
000070dabbdd1400  vmovaps xmm3, [rsp+0x30]
000070dabbdd1406  vmovaps xmm4, [rsp+0x40]
000070dabbdd140c  vmovaps xmm5, [rsp+0x50]
000070dabbdd1412  vmovaps xmm6, [rsp+0x60]
000070dabbdd1418  vmovaps xmm7, [rsp+0x70]
000070dabbdd141e  vmovaps xmm8, [rsp+0x80]
000070dabbdd1427  vmovaps xmm9, [rsp+0x90]
000070dabbdd1430  vmovaps xmm10, [rsp+0xA0]
000070dabbdd1439  vmovaps xmm11, [rsp+0xB0]
000070dabbdd1442  vmovaps xmm12, [rsp+0xC0]
000070dabbdd144b  vmovaps xmm14, [rsp+0xD0]
000070dabbdd1454  vmovaps xmm15, [rsp+0xE0]
000070dabbdd145d  add rsp, 0xF0
000070dabbdd1464  pop r11
000070dabbdd1466  pop r10
000070dabbdd1468  pop r9
000070dabbdd146a  pop r8
000070dabbdd146c  pop rsi
000070dabbdd146d  pop rdi
000070dabbdd146e  pop rdx
000070dabbdd146f  pop rcx
000070dabbdd1470  pop rax
000070dabbdd1471  add rsp, 0x08
000070dabbdd1475  jmp 0x000070DABBDCF878
000070dabbdd147a  sub rsp, 0x08
000070dabbdd147e  push rax
000070dabbdd147f  push rcx
000070dabbdd1480  push rdx
000070dabbdd1481  push rdi
000070dabbdd1482  push rsi
000070dabbdd1483  push r8
000070dabbdd1485  push r9
000070dabbdd1487  push r10
000070dabbdd1489  push r11
000070dabbdd148b  sub rsp, 0xF0
000070dabbdd1492  vmovaps [rsp], xmm0
000070dabbdd1497  vmovaps [rsp+0x10], xmm2
000070dabbdd149d  vmovaps [rsp+0x20], xmm3
000070dabbdd14a3  vmovaps [rsp+0x30], xmm4
000070dabbdd14a9  vmovaps [rsp+0x40], xmm5
000070dabbdd14af  vmovaps [rsp+0x50], xmm6
000070dabbdd14b5  vmovaps [rsp+0x60], xmm7
000070dabbdd14bb  vmovaps [rsp+0x70], xmm8
000070dabbdd14c1  vmovaps [rsp+0x80], xmm9
000070dabbdd14ca  vmovaps [rsp+0x90], xmm10
000070dabbdd14d3  vmovaps [rsp+0xA0], xmm11
000070dabbdd14dc  vmovaps [rsp+0xB0], xmm12
000070dabbdd14e5  vmovaps [rsp+0xC0], xmm13
000070dabbdd14ee  vmovaps [rsp+0xD0], xmm14
000070dabbdd14f7  vmovaps [rsp+0xE0], xmm15
000070dabbdd1500  sub rsp, 0x30
000070dabbdd1504  movaps [rsp], xmm1
000070dabbdd1508  movaps [rsp+0x10], xmm15
000070dabbdd150e  movaps [rsp+0x20], xmm2
000070dabbdd1513  lea rdi, [rsp]
000070dabbdd1517  mov esi, 0x00
000070dabbdd151c  mov rax, 0x5C2CF7B6F530
000070dabbdd1526  call rax
000070dabbdd1528  movaps xmm1, [rsp]
000070dabbdd152c  add rsp, 0x30
000070dabbdd1530  vmovaps xmm0, [rsp]
000070dabbdd1535  vmovaps xmm2, [rsp+0x10]
000070dabbdd153b  vmovaps xmm3, [rsp+0x20]
000070dabbdd1541  vmovaps xmm4, [rsp+0x30]
000070dabbdd1547  vmovaps xmm5, [rsp+0x40]
000070dabbdd154d  vmovaps xmm6, [rsp+0x50]
000070dabbdd1553  vmovaps xmm7, [rsp+0x60]
000070dabbdd1559  vmovaps xmm8, [rsp+0x70]
000070dabbdd155f  vmovaps xmm9, [rsp+0x80]
000070dabbdd1568  vmovaps xmm10, [rsp+0x90]
000070dabbdd1571  vmovaps xmm11, [rsp+0xA0]
000070dabbdd157a  vmovaps xmm12, [rsp+0xB0]
000070dabbdd1583  vmovaps xmm13, [rsp+0xC0]
000070dabbdd158c  vmovaps xmm14, [rsp+0xD0]
000070dabbdd1595  vmovaps xmm15, [rsp+0xE0]
000070dabbdd159e  add rsp, 0xF0
000070dabbdd15a5  pop r11
000070dabbdd15a7  pop r10
000070dabbdd15a9  pop r9
000070dabbdd15ab  pop r8
000070dabbdd15ad  pop rsi
000070dabbdd15ae  pop rdi
000070dabbdd15af  pop rdx
000070dabbdd15b0  pop rcx
000070dabbdd15b1  pop rax
000070dabbdd15b2  add rsp, 0x08
000070dabbdd15b6  jmp 0x000070DABBDCF8AC
000070dabbdd15bb  sub rsp, 0x08
000070dabbdd15bf  push rax
000070dabbdd15c0  push rcx
000070dabbdd15c1  push rdx
000070dabbdd15c2  push rdi
000070dabbdd15c3  push rsi
000070dabbdd15c4  push r8
000070dabbdd15c6  push r9
000070dabbdd15c8  push r10
000070dabbdd15ca  push r11
000070dabbdd15cc  sub rsp, 0xF0
000070dabbdd15d3  vmovaps [rsp], xmm0
000070dabbdd15d8  vmovaps [rsp+0x10], xmm1
000070dabbdd15de  vmovaps [rsp+0x20], xmm2
000070dabbdd15e4  vmovaps [rsp+0x30], xmm3
000070dabbdd15ea  vmovaps [rsp+0x40], xmm4
000070dabbdd15f0  vmovaps [rsp+0x50], xmm5
000070dabbdd15f6  vmovaps [rsp+0x60], xmm6
000070dabbdd15fc  vmovaps [rsp+0x70], xmm7
000070dabbdd1602  vmovaps [rsp+0x80], xmm8
000070dabbdd160b  vmovaps [rsp+0x90], xmm9
000070dabbdd1614  vmovaps [rsp+0xA0], xmm10
000070dabbdd161d  vmovaps [rsp+0xB0], xmm11
000070dabbdd1626  vmovaps [rsp+0xC0], xmm12
000070dabbdd162f  vmovaps [rsp+0xD0], xmm13
000070dabbdd1638  vmovaps [rsp+0xE0], xmm15
000070dabbdd1641  sub rsp, 0x30
000070dabbdd1645  movaps [rsp], xmm14
000070dabbdd164a  movaps [rsp+0x10], xmm2
000070dabbdd164f  movaps [rsp+0x20], xmm15
000070dabbdd1655  lea rdi, [rsp]
000070dabbdd1659  mov esi, 0x00
000070dabbdd165e  mov rax, 0x5C2CF7B6F530
000070dabbdd1668  call rax
000070dabbdd166a  movaps xmm14, [rsp]
000070dabbdd166f  add rsp, 0x30
000070dabbdd1673  vmovaps xmm0, [rsp]
000070dabbdd1678  vmovaps xmm1, [rsp+0x10]
000070dabbdd167e  vmovaps xmm2, [rsp+0x20]
000070dabbdd1684  vmovaps xmm3, [rsp+0x30]
000070dabbdd168a  vmovaps xmm4, [rsp+0x40]
000070dabbdd1690  vmovaps xmm5, [rsp+0x50]
000070dabbdd1696  vmovaps xmm6, [rsp+0x60]
000070dabbdd169c  vmovaps xmm7, [rsp+0x70]
000070dabbdd16a2  vmovaps xmm8, [rsp+0x80]
000070dabbdd16ab  vmovaps xmm9, [rsp+0x90]
000070dabbdd16b4  vmovaps xmm10, [rsp+0xA0]
000070dabbdd16bd  vmovaps xmm11, [rsp+0xB0]
000070dabbdd16c6  vmovaps xmm12, [rsp+0xC0]
000070dabbdd16cf  vmovaps xmm13, [rsp+0xD0]
000070dabbdd16d8  vmovaps xmm15, [rsp+0xE0]
000070dabbdd16e1  add rsp, 0xF0
000070dabbdd16e8  pop r11
000070dabbdd16ea  pop r10
000070dabbdd16ec  pop r9
000070dabbdd16ee  pop r8
000070dabbdd16f0  pop rsi
000070dabbdd16f1  pop rdi
000070dabbdd16f2  pop rdx
000070dabbdd16f3  pop rcx
000070dabbdd16f4  pop rax
000070dabbdd16f5  add rsp, 0x08
000070dabbdd16f9  jmp 0x000070DABBDCF8E7
000070dabbdd16fe  sub rsp, 0x08
000070dabbdd1702  push rax
000070dabbdd1703  push rcx
000070dabbdd1704  push rdx
000070dabbdd1705  push rdi
000070dabbdd1706  push rsi
000070dabbdd1707  push r8
000070dabbdd1709  push r9
000070dabbdd170b  push r10
000070dabbdd170d  push r11
000070dabbdd170f  sub rsp, 0xF0
000070dabbdd1716  vmovaps [rsp], xmm0
000070dabbdd171b  vmovaps [rsp+0x10], xmm1
000070dabbdd1721  vmovaps [rsp+0x20], xmm2
000070dabbdd1727  vmovaps [rsp+0x30], xmm3
000070dabbdd172d  vmovaps [rsp+0x40], xmm4
000070dabbdd1733  vmovaps [rsp+0x50], xmm5
000070dabbdd1739  vmovaps [rsp+0x60], xmm6
000070dabbdd173f  vmovaps [rsp+0x70], xmm7
000070dabbdd1745  vmovaps [rsp+0x80], xmm8
000070dabbdd174e  vmovaps [rsp+0x90], xmm9
000070dabbdd1757  vmovaps [rsp+0xA0], xmm10
000070dabbdd1760  vmovaps [rsp+0xB0], xmm11
000070dabbdd1769  vmovaps [rsp+0xC0], xmm12
000070dabbdd1772  vmovaps [rsp+0xD0], xmm13
000070dabbdd177b  vmovaps [rsp+0xE0], xmm14
000070dabbdd1784  sub rsp, 0x30
000070dabbdd1788  movaps [rsp], xmm15
000070dabbdd178d  movaps [rsp+0x10], xmm2
000070dabbdd1792  movaps [rsp+0x20], xmm1
000070dabbdd1797  lea rdi, [rsp]
000070dabbdd179b  mov esi, 0x00
000070dabbdd17a0  mov rax, 0x5C2CF7B6F530
000070dabbdd17aa  call rax
000070dabbdd17ac  movaps xmm15, [rsp]
000070dabbdd17b1  add rsp, 0x30
000070dabbdd17b5  vmovaps xmm0, [rsp]
000070dabbdd17ba  vmovaps xmm1, [rsp+0x10]
000070dabbdd17c0  vmovaps xmm2, [rsp+0x20]
000070dabbdd17c6  vmovaps xmm3, [rsp+0x30]
000070dabbdd17cc  vmovaps xmm4, [rsp+0x40]
000070dabbdd17d2  vmovaps xmm5, [rsp+0x50]
000070dabbdd17d8  vmovaps xmm6, [rsp+0x60]
000070dabbdd17de  vmovaps xmm7, [rsp+0x70]
000070dabbdd17e4  vmovaps xmm8, [rsp+0x80]
000070dabbdd17ed  vmovaps xmm9, [rsp+0x90]
000070dabbdd17f6  vmovaps xmm10, [rsp+0xA0]
000070dabbdd17ff  vmovaps xmm11, [rsp+0xB0]
000070dabbdd1808  vmovaps xmm12, [rsp+0xC0]
000070dabbdd1811  vmovaps xmm13, [rsp+0xD0]
000070dabbdd181a  vmovaps xmm14, [rsp+0xE0]
000070dabbdd1823  add rsp, 0xF0
000070dabbdd182a  pop r11
000070dabbdd182c  pop r10
000070dabbdd182e  pop r9
000070dabbdd1830  pop r8
000070dabbdd1832  pop rsi
000070dabbdd1833  pop rdi
000070dabbdd1834  pop rdx
000070dabbdd1835  pop rcx
000070dabbdd1836  pop rax
000070dabbdd1837  add rsp, 0x08
000070dabbdd183b  jmp 0x000070DABBDCF923
000070dabbdd1840  call 0x000070DABBBFF430
000070dabbdd1845  jmp 0x000070DABBDCF930
000070dabbdd184a  sub rsp, 0x08
000070dabbdd184e  push rax
000070dabbdd184f  push rcx
000070dabbdd1850  push rdx
000070dabbdd1851  push rdi
000070dabbdd1852  push rsi
000070dabbdd1853  push r8
000070dabbdd1855  push r9
000070dabbdd1857  push r10
000070dabbdd1859  push r11
000070dabbdd185b  sub rsp, 0xF0
000070dabbdd1862  vmovaps [rsp], xmm0
000070dabbdd1867  vmovaps [rsp+0x10], xmm1
000070dabbdd186d  vmovaps [rsp+0x20], xmm3
000070dabbdd1873  vmovaps [rsp+0x30], xmm4
000070dabbdd1879  vmovaps [rsp+0x40], xmm5
000070dabbdd187f  vmovaps [rsp+0x50], xmm6
000070dabbdd1885  vmovaps [rsp+0x60], xmm7
000070dabbdd188b  vmovaps [rsp+0x70], xmm8
000070dabbdd1891  vmovaps [rsp+0x80], xmm9
000070dabbdd189a  vmovaps [rsp+0x90], xmm10
000070dabbdd18a3  vmovaps [rsp+0xA0], xmm11
000070dabbdd18ac  vmovaps [rsp+0xB0], xmm12
000070dabbdd18b5  vmovaps [rsp+0xC0], xmm13
000070dabbdd18be  vmovaps [rsp+0xD0], xmm14
000070dabbdd18c7  vmovaps [rsp+0xE0], xmm15
000070dabbdd18d0  sub rsp, 0x30
000070dabbdd18d4  movaps [rsp], xmm2
000070dabbdd18d8  movaps [rsp+0x10], xmm1
000070dabbdd18dd  movaps [rsp+0x20], xmm14
000070dabbdd18e3  lea rdi, [rsp]
000070dabbdd18e7  mov esi, 0x00
000070dabbdd18ec  mov rax, 0x5C2CF7B6F530
000070dabbdd18f6  call rax
000070dabbdd18f8  movaps xmm2, [rsp]
000070dabbdd18fc  add rsp, 0x30
000070dabbdd1900  vmovaps xmm0, [rsp]
000070dabbdd1905  vmovaps xmm1, [rsp+0x10]
000070dabbdd190b  vmovaps xmm3, [rsp+0x20]
000070dabbdd1911  vmovaps xmm4, [rsp+0x30]
000070dabbdd1917  vmovaps xmm5, [rsp+0x40]
000070dabbdd191d  vmovaps xmm6, [rsp+0x50]
000070dabbdd1923  vmovaps xmm7, [rsp+0x60]
000070dabbdd1929  vmovaps xmm8, [rsp+0x70]
000070dabbdd192f  vmovaps xmm9, [rsp+0x80]
000070dabbdd1938  vmovaps xmm10, [rsp+0x90]
000070dabbdd1941  vmovaps xmm11, [rsp+0xA0]
000070dabbdd194a  vmovaps xmm12, [rsp+0xB0]
000070dabbdd1953  vmovaps xmm13, [rsp+0xC0]
000070dabbdd195c  vmovaps xmm14, [rsp+0xD0]
000070dabbdd1965  vmovaps xmm15, [rsp+0xE0]
000070dabbdd196e  add rsp, 0xF0
000070dabbdd1975  pop r11
000070dabbdd1977  pop r10
000070dabbdd1979  pop r9
000070dabbdd197b  pop r8
000070dabbdd197d  pop rsi
000070dabbdd197e  pop rdi
000070dabbdd197f  pop rdx
000070dabbdd1980  pop rcx
000070dabbdd1981  pop rax
000070dabbdd1982  add rsp, 0x08
000070dabbdd1986  jmp 0x000070DABBDCF96D
000070dabbdd198b  sub rsp, 0x08
000070dabbdd198f  push rax
000070dabbdd1990  push rcx
000070dabbdd1991  push rdx
000070dabbdd1992  push rdi
000070dabbdd1993  push rsi
000070dabbdd1994  push r8
000070dabbdd1996  push r9
000070dabbdd1998  push r10
000070dabbdd199a  push r11
000070dabbdd199c  sub rsp, 0xF0
000070dabbdd19a3  vmovaps [rsp], xmm0
000070dabbdd19a8  vmovaps [rsp+0x10], xmm1
000070dabbdd19ae  vmovaps [rsp+0x20], xmm2
000070dabbdd19b4  vmovaps [rsp+0x30], xmm3
000070dabbdd19ba  vmovaps [rsp+0x40], xmm4
000070dabbdd19c0  vmovaps [rsp+0x50], xmm5
000070dabbdd19c6  vmovaps [rsp+0x60], xmm6
000070dabbdd19cc  vmovaps [rsp+0x70], xmm7
000070dabbdd19d2  vmovaps [rsp+0x80], xmm8
000070dabbdd19db  vmovaps [rsp+0x90], xmm9
000070dabbdd19e4  vmovaps [rsp+0xA0], xmm10
000070dabbdd19ed  vmovaps [rsp+0xB0], xmm11
000070dabbdd19f6  vmovaps [rsp+0xC0], xmm12
000070dabbdd19ff  vmovaps [rsp+0xD0], xmm13
000070dabbdd1a08  vmovaps [rsp+0xE0], xmm14
000070dabbdd1a11  sub rsp, 0x30
000070dabbdd1a15  movaps [rsp], xmm15
000070dabbdd1a1a  movaps [rsp+0x10], xmm14
000070dabbdd1a20  movaps [rsp+0x20], xmm1
000070dabbdd1a25  lea rdi, [rsp]
000070dabbdd1a29  mov esi, 0x00
000070dabbdd1a2e  mov rax, 0x5C2CF7B6F530
000070dabbdd1a38  call rax
000070dabbdd1a3a  movaps xmm15, [rsp]
000070dabbdd1a3f  add rsp, 0x30
000070dabbdd1a43  vmovaps xmm0, [rsp]
000070dabbdd1a48  vmovaps xmm1, [rsp+0x10]
000070dabbdd1a4e  vmovaps xmm2, [rsp+0x20]
000070dabbdd1a54  vmovaps xmm3, [rsp+0x30]
000070dabbdd1a5a  vmovaps xmm4, [rsp+0x40]
000070dabbdd1a60  vmovaps xmm5, [rsp+0x50]
000070dabbdd1a66  vmovaps xmm6, [rsp+0x60]
000070dabbdd1a6c  vmovaps xmm7, [rsp+0x70]
000070dabbdd1a72  vmovaps xmm8, [rsp+0x80]
000070dabbdd1a7b  vmovaps xmm9, [rsp+0x90]
000070dabbdd1a84  vmovaps xmm10, [rsp+0xA0]
000070dabbdd1a8d  vmovaps xmm11, [rsp+0xB0]
000070dabbdd1a96  vmovaps xmm12, [rsp+0xC0]
000070dabbdd1a9f  vmovaps xmm13, [rsp+0xD0]
000070dabbdd1aa8  vmovaps xmm14, [rsp+0xE0]
000070dabbdd1ab1  add rsp, 0xF0
000070dabbdd1ab8  pop r11
000070dabbdd1aba  pop r10
000070dabbdd1abc  pop r9
000070dabbdd1abe  pop r8
000070dabbdd1ac0  pop rsi
000070dabbdd1ac1  pop rdi
000070dabbdd1ac2  pop rdx
000070dabbdd1ac3  pop rcx
000070dabbdd1ac4  pop rax
000070dabbdd1ac5  add rsp, 0x08
000070dabbdd1ac9  jmp 0x000070DABBDCF9E7
000070dabbdd1ace  call 0x000070DABBBFF430
000070dabbdd1ad3  jmp 0x000070DABBDCF9F4
000070dabbdd1ad8  sub rsp, 0x08
000070dabbdd1adc  push rax
000070dabbdd1add  push rcx
000070dabbdd1ade  push rdx
000070dabbdd1adf  push rdi
000070dabbdd1ae0  push rsi
000070dabbdd1ae1  push r8
000070dabbdd1ae3  push r9
000070dabbdd1ae5  push r10
000070dabbdd1ae7  push r11
000070dabbdd1ae9  sub rsp, 0xF0
000070dabbdd1af0  vmovaps [rsp], xmm0
000070dabbdd1af5  vmovaps [rsp+0x10], xmm1
000070dabbdd1afb  vmovaps [rsp+0x20], xmm2
000070dabbdd1b01  vmovaps [rsp+0x30], xmm3
000070dabbdd1b07  vmovaps [rsp+0x40], xmm4
000070dabbdd1b0d  vmovaps [rsp+0x50], xmm5
000070dabbdd1b13  vmovaps [rsp+0x60], xmm6
000070dabbdd1b19  vmovaps [rsp+0x70], xmm7
000070dabbdd1b1f  vmovaps [rsp+0x80], xmm8
000070dabbdd1b28  vmovaps [rsp+0x90], xmm9
000070dabbdd1b31  vmovaps [rsp+0xA0], xmm10
000070dabbdd1b3a  vmovaps [rsp+0xB0], xmm11
000070dabbdd1b43  vmovaps [rsp+0xC0], xmm12
000070dabbdd1b4c  vmovaps [rsp+0xD0], xmm13
000070dabbdd1b55  vmovaps [rsp+0xE0], xmm15
000070dabbdd1b5e  sub rsp, 0x30
000070dabbdd1b62  movaps [rsp], xmm14
000070dabbdd1b67  movaps [rsp+0x10], xmm13
000070dabbdd1b6d  movaps [rsp+0x20], xmm1
000070dabbdd1b72  lea rdi, [rsp]
000070dabbdd1b76  mov esi, 0x00
000070dabbdd1b7b  mov rax, 0x5C2CF7B6F530
000070dabbdd1b85  call rax
000070dabbdd1b87  movaps xmm14, [rsp]
000070dabbdd1b8c  add rsp, 0x30
000070dabbdd1b90  vmovaps xmm0, [rsp]
000070dabbdd1b95  vmovaps xmm1, [rsp+0x10]
000070dabbdd1b9b  vmovaps xmm2, [rsp+0x20]
000070dabbdd1ba1  vmovaps xmm3, [rsp+0x30]
000070dabbdd1ba7  vmovaps xmm4, [rsp+0x40]
000070dabbdd1bad  vmovaps xmm5, [rsp+0x50]
000070dabbdd1bb3  vmovaps xmm6, [rsp+0x60]
000070dabbdd1bb9  vmovaps xmm7, [rsp+0x70]
000070dabbdd1bbf  vmovaps xmm8, [rsp+0x80]
000070dabbdd1bc8  vmovaps xmm9, [rsp+0x90]
000070dabbdd1bd1  vmovaps xmm10, [rsp+0xA0]
000070dabbdd1bda  vmovaps xmm11, [rsp+0xB0]
000070dabbdd1be3  vmovaps xmm12, [rsp+0xC0]
000070dabbdd1bec  vmovaps xmm13, [rsp+0xD0]
000070dabbdd1bf5  vmovaps xmm15, [rsp+0xE0]
000070dabbdd1bfe  add rsp, 0xF0
000070dabbdd1c05  pop r11
000070dabbdd1c07  pop r10
000070dabbdd1c09  pop r9
000070dabbdd1c0b  pop r8
000070dabbdd1c0d  pop rsi
000070dabbdd1c0e  pop rdi
000070dabbdd1c0f  pop rdx
000070dabbdd1c10  pop rcx
000070dabbdd1c11  pop rax
000070dabbdd1c12  add rsp, 0x08
000070dabbdd1c16  jmp 0x000070DABBDCFAAF
000070dabbdd1c1b  sub rsp, 0x08
000070dabbdd1c1f  push rax
000070dabbdd1c20  push rcx
000070dabbdd1c21  push rdx
000070dabbdd1c22  push rdi
000070dabbdd1c23  push rsi
000070dabbdd1c24  push r8
000070dabbdd1c26  push r9
000070dabbdd1c28  push r10
000070dabbdd1c2a  push r11
000070dabbdd1c2c  sub rsp, 0xF0
000070dabbdd1c33  vmovaps [rsp], xmm0
000070dabbdd1c38  vmovaps [rsp+0x10], xmm1
000070dabbdd1c3e  vmovaps [rsp+0x20], xmm2
000070dabbdd1c44  vmovaps [rsp+0x30], xmm3
000070dabbdd1c4a  vmovaps [rsp+0x40], xmm4
000070dabbdd1c50  vmovaps [rsp+0x50], xmm5
000070dabbdd1c56  vmovaps [rsp+0x60], xmm6
000070dabbdd1c5c  vmovaps [rsp+0x70], xmm7
000070dabbdd1c62  vmovaps [rsp+0x80], xmm8
000070dabbdd1c6b  vmovaps [rsp+0x90], xmm9
000070dabbdd1c74  vmovaps [rsp+0xA0], xmm10
000070dabbdd1c7d  vmovaps [rsp+0xB0], xmm11
000070dabbdd1c86  vmovaps [rsp+0xC0], xmm12
000070dabbdd1c8f  vmovaps [rsp+0xD0], xmm13
000070dabbdd1c98  vmovaps [rsp+0xE0], xmm14
000070dabbdd1ca1  sub rsp, 0x30
000070dabbdd1ca5  movaps [rsp], xmm15
000070dabbdd1caa  movaps [rsp+0x10], xmm13
000070dabbdd1cb0  movaps [rsp+0x20], xmm1
000070dabbdd1cb5  lea rdi, [rsp]
000070dabbdd1cb9  mov esi, 0x00
000070dabbdd1cbe  mov rax, 0x5C2CF7B6F530
000070dabbdd1cc8  call rax
000070dabbdd1cca  movaps xmm15, [rsp]
000070dabbdd1ccf  add rsp, 0x30
000070dabbdd1cd3  vmovaps xmm0, [rsp]
000070dabbdd1cd8  vmovaps xmm1, [rsp+0x10]
000070dabbdd1cde  vmovaps xmm2, [rsp+0x20]
000070dabbdd1ce4  vmovaps xmm3, [rsp+0x30]
000070dabbdd1cea  vmovaps xmm4, [rsp+0x40]
000070dabbdd1cf0  vmovaps xmm5, [rsp+0x50]
000070dabbdd1cf6  vmovaps xmm6, [rsp+0x60]
000070dabbdd1cfc  vmovaps xmm7, [rsp+0x70]
000070dabbdd1d02  vmovaps xmm8, [rsp+0x80]
000070dabbdd1d0b  vmovaps xmm9, [rsp+0x90]
000070dabbdd1d14  vmovaps xmm10, [rsp+0xA0]
000070dabbdd1d1d  vmovaps xmm11, [rsp+0xB0]
000070dabbdd1d26  vmovaps xmm12, [rsp+0xC0]
000070dabbdd1d2f  vmovaps xmm13, [rsp+0xD0]
000070dabbdd1d38  vmovaps xmm14, [rsp+0xE0]
000070dabbdd1d41  add rsp, 0xF0
000070dabbdd1d48  pop r11
000070dabbdd1d4a  pop r10
000070dabbdd1d4c  pop r9
000070dabbdd1d4e  pop r8
000070dabbdd1d50  pop rsi
000070dabbdd1d51  pop rdi
000070dabbdd1d52  pop rdx
000070dabbdd1d53  pop rcx
000070dabbdd1d54  pop rax
000070dabbdd1d55  add rsp, 0x08
000070dabbdd1d59  jmp 0x000070DABBDCFAEB
000070dabbdd1d5e  call 0x000070DABBBFF430
000070dabbdd1d63  jmp 0x000070DABBDCFAF8
000070dabbdd1d68  sub rsp, 0x08
000070dabbdd1d6c  push rax
000070dabbdd1d6d  push rcx
000070dabbdd1d6e  push rdx
000070dabbdd1d6f  push rdi
000070dabbdd1d70  push rsi
000070dabbdd1d71  push r8
000070dabbdd1d73  push r9
000070dabbdd1d75  push r10
000070dabbdd1d77  push r11
000070dabbdd1d79  sub rsp, 0xF0
000070dabbdd1d80  vmovaps [rsp], xmm0
000070dabbdd1d85  vmovaps [rsp+0x10], xmm1
000070dabbdd1d8b  vmovaps [rsp+0x20], xmm2
000070dabbdd1d91  vmovaps [rsp+0x30], xmm3
000070dabbdd1d97  vmovaps [rsp+0x40], xmm4
000070dabbdd1d9d  vmovaps [rsp+0x50], xmm5
000070dabbdd1da3  vmovaps [rsp+0x60], xmm6
000070dabbdd1da9  vmovaps [rsp+0x70], xmm7
000070dabbdd1daf  vmovaps [rsp+0x80], xmm8
000070dabbdd1db8  vmovaps [rsp+0x90], xmm9
000070dabbdd1dc1  vmovaps [rsp+0xA0], xmm10
000070dabbdd1dca  vmovaps [rsp+0xB0], xmm11
000070dabbdd1dd3  vmovaps [rsp+0xC0], xmm12
000070dabbdd1ddc  vmovaps [rsp+0xD0], xmm13
000070dabbdd1de5  vmovaps [rsp+0xE0], xmm15
000070dabbdd1dee  sub rsp, 0x30
000070dabbdd1df2  movaps [rsp], xmm14
000070dabbdd1df7  movaps [rsp+0x10], xmm13
000070dabbdd1dfd  movaps [rsp+0x20], xmm2
000070dabbdd1e02  lea rdi, [rsp]
000070dabbdd1e06  mov esi, 0x00
000070dabbdd1e0b  mov rax, 0x5C2CF7B6F530
000070dabbdd1e15  call rax
000070dabbdd1e17  movaps xmm14, [rsp]
000070dabbdd1e1c  add rsp, 0x30
000070dabbdd1e20  vmovaps xmm0, [rsp]
000070dabbdd1e25  vmovaps xmm1, [rsp+0x10]
000070dabbdd1e2b  vmovaps xmm2, [rsp+0x20]
000070dabbdd1e31  vmovaps xmm3, [rsp+0x30]
000070dabbdd1e37  vmovaps xmm4, [rsp+0x40]
000070dabbdd1e3d  vmovaps xmm5, [rsp+0x50]
000070dabbdd1e43  vmovaps xmm6, [rsp+0x60]
000070dabbdd1e49  vmovaps xmm7, [rsp+0x70]
000070dabbdd1e4f  vmovaps xmm8, [rsp+0x80]
000070dabbdd1e58  vmovaps xmm9, [rsp+0x90]
000070dabbdd1e61  vmovaps xmm10, [rsp+0xA0]
000070dabbdd1e6a  vmovaps xmm11, [rsp+0xB0]
000070dabbdd1e73  vmovaps xmm12, [rsp+0xC0]
000070dabbdd1e7c  vmovaps xmm13, [rsp+0xD0]
000070dabbdd1e85  vmovaps xmm15, [rsp+0xE0]
000070dabbdd1e8e  add rsp, 0xF0
000070dabbdd1e95  pop r11
000070dabbdd1e97  pop r10
000070dabbdd1e99  pop r9
000070dabbdd1e9b  pop r8
000070dabbdd1e9d  pop rsi
000070dabbdd1e9e  pop rdi
000070dabbdd1e9f  pop rdx
000070dabbdd1ea0  pop rcx
000070dabbdd1ea1  pop rax
000070dabbdd1ea2  add rsp, 0x08
000070dabbdd1ea6  jmp 0x000070DABBDCFB24
000070dabbdd1eab  sub rsp, 0x08
000070dabbdd1eaf  push rax
000070dabbdd1eb0  push rcx
000070dabbdd1eb1  push rdx
000070dabbdd1eb2  push rdi
000070dabbdd1eb3  push rsi
000070dabbdd1eb4  push r8
000070dabbdd1eb6  push r9
000070dabbdd1eb8  push r10
000070dabbdd1eba  push r11
000070dabbdd1ebc  sub rsp, 0xF0
000070dabbdd1ec3  vmovaps [rsp], xmm0
000070dabbdd1ec8  vmovaps [rsp+0x10], xmm2
000070dabbdd1ece  vmovaps [rsp+0x20], xmm3
000070dabbdd1ed4  vmovaps [rsp+0x30], xmm4
000070dabbdd1eda  vmovaps [rsp+0x40], xmm5
000070dabbdd1ee0  vmovaps [rsp+0x50], xmm6
000070dabbdd1ee6  vmovaps [rsp+0x60], xmm7
000070dabbdd1eec  vmovaps [rsp+0x70], xmm8
000070dabbdd1ef2  vmovaps [rsp+0x80], xmm9
000070dabbdd1efb  vmovaps [rsp+0x90], xmm10
000070dabbdd1f04  vmovaps [rsp+0xA0], xmm11
000070dabbdd1f0d  vmovaps [rsp+0xB0], xmm12
000070dabbdd1f16  vmovaps [rsp+0xC0], xmm13
000070dabbdd1f1f  vmovaps [rsp+0xD0], xmm14
000070dabbdd1f28  vmovaps [rsp+0xE0], xmm15
000070dabbdd1f31  sub rsp, 0x30
000070dabbdd1f35  movaps [rsp], xmm1
000070dabbdd1f39  movaps [rsp+0x10], xmm13
000070dabbdd1f3f  movaps [rsp+0x20], xmm2
000070dabbdd1f44  lea rdi, [rsp]
000070dabbdd1f48  mov esi, 0x00
000070dabbdd1f4d  mov rax, 0x5C2CF7B6F530
000070dabbdd1f57  call rax
000070dabbdd1f59  movaps xmm1, [rsp]
000070dabbdd1f5d  add rsp, 0x30
000070dabbdd1f61  vmovaps xmm0, [rsp]
000070dabbdd1f66  vmovaps xmm2, [rsp+0x10]
000070dabbdd1f6c  vmovaps xmm3, [rsp+0x20]
000070dabbdd1f72  vmovaps xmm4, [rsp+0x30]
000070dabbdd1f78  vmovaps xmm5, [rsp+0x40]
000070dabbdd1f7e  vmovaps xmm6, [rsp+0x50]
000070dabbdd1f84  vmovaps xmm7, [rsp+0x60]
000070dabbdd1f8a  vmovaps xmm8, [rsp+0x70]
000070dabbdd1f90  vmovaps xmm9, [rsp+0x80]
000070dabbdd1f99  vmovaps xmm10, [rsp+0x90]
000070dabbdd1fa2  vmovaps xmm11, [rsp+0xA0]
000070dabbdd1fab  vmovaps xmm12, [rsp+0xB0]
000070dabbdd1fb4  vmovaps xmm13, [rsp+0xC0]
000070dabbdd1fbd  vmovaps xmm14, [rsp+0xD0]
000070dabbdd1fc6  vmovaps xmm15, [rsp+0xE0]
000070dabbdd1fcf  add rsp, 0xF0
000070dabbdd1fd6  pop r11
000070dabbdd1fd8  pop r10
000070dabbdd1fda  pop r9
000070dabbdd1fdc  pop r8
000070dabbdd1fde  pop rsi
000070dabbdd1fdf  pop rdi
000070dabbdd1fe0  pop rdx
000070dabbdd1fe1  pop rcx
000070dabbdd1fe2  pop rax
000070dabbdd1fe3  add rsp, 0x08
000070dabbdd1fe7  jmp 0x000070DABBDCFB52
000070dabbdd1fec  sub rsp, 0x08
000070dabbdd1ff0  push rax
000070dabbdd1ff1  push rcx
000070dabbdd1ff2  push rdx
000070dabbdd1ff3  push rdi
000070dabbdd1ff4  push rsi
000070dabbdd1ff5  push r8
000070dabbdd1ff7  push r9
000070dabbdd1ff9  push r10
000070dabbdd1ffb  push r11
000070dabbdd1ffd  sub rsp, 0xF0
000070dabbdd2004  vmovaps [rsp], xmm0
000070dabbdd2009  vmovaps [rsp+0x10], xmm1
000070dabbdd200f  vmovaps [rsp+0x20], xmm3
000070dabbdd2015  vmovaps [rsp+0x30], xmm4
000070dabbdd201b  vmovaps [rsp+0x40], xmm5
000070dabbdd2021  vmovaps [rsp+0x50], xmm6
000070dabbdd2027  vmovaps [rsp+0x60], xmm7
000070dabbdd202d  vmovaps [rsp+0x70], xmm8
000070dabbdd2033  vmovaps [rsp+0x80], xmm9
000070dabbdd203c  vmovaps [rsp+0x90], xmm10
000070dabbdd2045  vmovaps [rsp+0xA0], xmm11
000070dabbdd204e  vmovaps [rsp+0xB0], xmm12
000070dabbdd2057  vmovaps [rsp+0xC0], xmm13
000070dabbdd2060  vmovaps [rsp+0xD0], xmm14
000070dabbdd2069  vmovaps [rsp+0xE0], xmm15
000070dabbdd2072  sub rsp, 0x30
000070dabbdd2076  movaps [rsp], xmm2
000070dabbdd207a  movaps [rsp+0x10], xmm1
000070dabbdd207f  movaps [rsp+0x20], xmm13
000070dabbdd2085  lea rdi, [rsp]
000070dabbdd2089  mov esi, 0x00
000070dabbdd208e  mov rax, 0x5C2CF7B6F530
000070dabbdd2098  call rax
000070dabbdd209a  movaps xmm2, [rsp]
000070dabbdd209e  add rsp, 0x30
000070dabbdd20a2  vmovaps xmm0, [rsp]
000070dabbdd20a7  vmovaps xmm1, [rsp+0x10]
000070dabbdd20ad  vmovaps xmm3, [rsp+0x20]
000070dabbdd20b3  vmovaps xmm4, [rsp+0x30]
000070dabbdd20b9  vmovaps xmm5, [rsp+0x40]
000070dabbdd20bf  vmovaps xmm6, [rsp+0x50]
000070dabbdd20c5  vmovaps xmm7, [rsp+0x60]
000070dabbdd20cb  vmovaps xmm8, [rsp+0x70]
000070dabbdd20d1  vmovaps xmm9, [rsp+0x80]
000070dabbdd20da  vmovaps xmm10, [rsp+0x90]
000070dabbdd20e3  vmovaps xmm11, [rsp+0xA0]
000070dabbdd20ec  vmovaps xmm12, [rsp+0xB0]
000070dabbdd20f5  vmovaps xmm13, [rsp+0xC0]
000070dabbdd20fe  vmovaps xmm14, [rsp+0xD0]
000070dabbdd2107  vmovaps xmm15, [rsp+0xE0]
000070dabbdd2110  add rsp, 0xF0
000070dabbdd2117  pop r11
000070dabbdd2119  pop r10
000070dabbdd211b  pop r9
000070dabbdd211d  pop r8
000070dabbdd211f  pop rsi
000070dabbdd2120  pop rdi
000070dabbdd2121  pop rdx
000070dabbdd2122  pop rcx
000070dabbdd2123  pop rax
000070dabbdd2124  add rsp, 0x08
000070dabbdd2128  jmp 0x000070DABBDCFBAB
000070dabbdd212d  call 0x000070DABBBFF430
000070dabbdd2132  jmp 0x000070DABBDCFBB8
000070dabbdd2137  sub rsp, 0x08
000070dabbdd213b  push rax
000070dabbdd213c  push rcx
000070dabbdd213d  push rdx
000070dabbdd213e  push rdi
000070dabbdd213f  push rsi
000070dabbdd2140  push r8
000070dabbdd2142  push r9
000070dabbdd2144  push r10
000070dabbdd2146  push r11
000070dabbdd2148  sub rsp, 0xF0
000070dabbdd214f  vmovaps [rsp], xmm0
000070dabbdd2154  vmovaps [rsp+0x10], xmm1
000070dabbdd215a  vmovaps [rsp+0x20], xmm2
000070dabbdd2160  vmovaps [rsp+0x30], xmm3
000070dabbdd2166  vmovaps [rsp+0x40], xmm4
000070dabbdd216c  vmovaps [rsp+0x50], xmm5
000070dabbdd2172  vmovaps [rsp+0x60], xmm6
000070dabbdd2178  vmovaps [rsp+0x70], xmm7
000070dabbdd217e  vmovaps [rsp+0x80], xmm8
000070dabbdd2187  vmovaps [rsp+0x90], xmm9
000070dabbdd2190  vmovaps [rsp+0xA0], xmm10
000070dabbdd2199  vmovaps [rsp+0xB0], xmm11
000070dabbdd21a2  vmovaps [rsp+0xC0], xmm12
000070dabbdd21ab  vmovaps [rsp+0xD0], xmm13
000070dabbdd21b4  vmovaps [rsp+0xE0], xmm14
000070dabbdd21bd  sub rsp, 0x30
000070dabbdd21c1  movaps [rsp], xmm15
000070dabbdd21c6  movaps [rsp+0x10], xmm13
000070dabbdd21cc  movaps [rsp+0x20], xmm1
000070dabbdd21d1  lea rdi, [rsp]
000070dabbdd21d5  mov esi, 0x00
000070dabbdd21da  mov rax, 0x5C2CF7B6F530
000070dabbdd21e4  call rax
000070dabbdd21e6  movaps xmm15, [rsp]
000070dabbdd21eb  add rsp, 0x30
000070dabbdd21ef  vmovaps xmm0, [rsp]
000070dabbdd21f4  vmovaps xmm1, [rsp+0x10]
000070dabbdd21fa  vmovaps xmm2, [rsp+0x20]
000070dabbdd2200  vmovaps xmm3, [rsp+0x30]
000070dabbdd2206  vmovaps xmm4, [rsp+0x40]
000070dabbdd220c  vmovaps xmm5, [rsp+0x50]
000070dabbdd2212  vmovaps xmm6, [rsp+0x60]
000070dabbdd2218  vmovaps xmm7, [rsp+0x70]
000070dabbdd221e  vmovaps xmm8, [rsp+0x80]
000070dabbdd2227  vmovaps xmm9, [rsp+0x90]
000070dabbdd2230  vmovaps xmm10, [rsp+0xA0]
000070dabbdd2239  vmovaps xmm11, [rsp+0xB0]
000070dabbdd2242  vmovaps xmm12, [rsp+0xC0]
000070dabbdd224b  vmovaps xmm13, [rsp+0xD0]
000070dabbdd2254  vmovaps xmm14, [rsp+0xE0]
000070dabbdd225d  add rsp, 0xF0
000070dabbdd2264  pop r11
000070dabbdd2266  pop r10
000070dabbdd2268  pop r9
000070dabbdd226a  pop r8
000070dabbdd226c  pop rsi
000070dabbdd226d  pop rdi
000070dabbdd226e  pop rdx
000070dabbdd226f  pop rcx
000070dabbdd2270  pop rax
000070dabbdd2271  add rsp, 0x08
000070dabbdd2275  jmp 0x000070DABBDCFBF7
000070dabbdd227a  sub rsp, 0x08
000070dabbdd227e  push rax
000070dabbdd227f  push rcx
000070dabbdd2280  push rdx
000070dabbdd2281  push rdi
000070dabbdd2282  push rsi
000070dabbdd2283  push r8
000070dabbdd2285  push r9
000070dabbdd2287  push r10
000070dabbdd2289  push r11
000070dabbdd228b  sub rsp, 0xF0
000070dabbdd2292  vmovaps [rsp], xmm0
000070dabbdd2297  vmovaps [rsp+0x10], xmm1
000070dabbdd229d  vmovaps [rsp+0x20], xmm2
000070dabbdd22a3  vmovaps [rsp+0x30], xmm3
000070dabbdd22a9  vmovaps [rsp+0x40], xmm4
000070dabbdd22af  vmovaps [rsp+0x50], xmm5
000070dabbdd22b5  vmovaps [rsp+0x60], xmm6
000070dabbdd22bb  vmovaps [rsp+0x70], xmm7
000070dabbdd22c1  vmovaps [rsp+0x80], xmm8
000070dabbdd22ca  vmovaps [rsp+0x90], xmm9
000070dabbdd22d3  vmovaps [rsp+0xA0], xmm10
000070dabbdd22dc  vmovaps [rsp+0xB0], xmm11
000070dabbdd22e5  vmovaps [rsp+0xC0], xmm12
000070dabbdd22ee  vmovaps [rsp+0xD0], xmm13
000070dabbdd22f7  vmovaps [rsp+0xE0], xmm15
000070dabbdd2300  sub rsp, 0x30
000070dabbdd2304  movaps [rsp], xmm14
000070dabbdd2309  movaps [rsp+0x10], xmm11
000070dabbdd230f  movaps [rsp+0x20], xmm1
000070dabbdd2314  lea rdi, [rsp]
000070dabbdd2318  mov esi, 0x00
000070dabbdd231d  mov rax, 0x5C2CF7B6F530
000070dabbdd2327  call rax
000070dabbdd2329  movaps xmm14, [rsp]
000070dabbdd232e  add rsp, 0x30
000070dabbdd2332  vmovaps xmm0, [rsp]
000070dabbdd2337  vmovaps xmm1, [rsp+0x10]
000070dabbdd233d  vmovaps xmm2, [rsp+0x20]
000070dabbdd2343  vmovaps xmm3, [rsp+0x30]
000070dabbdd2349  vmovaps xmm4, [rsp+0x40]
000070dabbdd234f  vmovaps xmm5, [rsp+0x50]
000070dabbdd2355  vmovaps xmm6, [rsp+0x60]
000070dabbdd235b  vmovaps xmm7, [rsp+0x70]
000070dabbdd2361  vmovaps xmm8, [rsp+0x80]
000070dabbdd236a  vmovaps xmm9, [rsp+0x90]
000070dabbdd2373  vmovaps xmm10, [rsp+0xA0]
000070dabbdd237c  vmovaps xmm11, [rsp+0xB0]
000070dabbdd2385  vmovaps xmm12, [rsp+0xC0]
000070dabbdd238e  vmovaps xmm13, [rsp+0xD0]
000070dabbdd2397  vmovaps xmm15, [rsp+0xE0]
000070dabbdd23a0  add rsp, 0xF0
000070dabbdd23a7  pop r11
000070dabbdd23a9  pop r10
000070dabbdd23ab  pop r9
000070dabbdd23ad  pop r8
000070dabbdd23af  pop rsi
000070dabbdd23b0  pop rdi
000070dabbdd23b1  pop rdx
000070dabbdd23b2  pop rcx
000070dabbdd23b3  pop rax
000070dabbdd23b4  add rsp, 0x08
000070dabbdd23b8  jmp 0x000070DABBDCFC21
000070dabbdd23bd  sub rsp, 0x08
000070dabbdd23c1  push rax
000070dabbdd23c2  push rcx
000070dabbdd23c3  push rdx
000070dabbdd23c4  push rdi
000070dabbdd23c5  push rsi
000070dabbdd23c6  push r8
000070dabbdd23c8  push r9
000070dabbdd23ca  push r10
000070dabbdd23cc  push r11
000070dabbdd23ce  sub rsp, 0xF0
000070dabbdd23d5  vmovaps [rsp], xmm0
000070dabbdd23da  vmovaps [rsp+0x10], xmm1
000070dabbdd23e0  vmovaps [rsp+0x20], xmm2
000070dabbdd23e6  vmovaps [rsp+0x30], xmm3
000070dabbdd23ec  vmovaps [rsp+0x40], xmm4
000070dabbdd23f2  vmovaps [rsp+0x50], xmm5
000070dabbdd23f8  vmovaps [rsp+0x60], xmm6
000070dabbdd23fe  vmovaps [rsp+0x70], xmm7
000070dabbdd2404  vmovaps [rsp+0x80], xmm8
000070dabbdd240d  vmovaps [rsp+0x90], xmm9
000070dabbdd2416  vmovaps [rsp+0xA0], xmm10
000070dabbdd241f  vmovaps [rsp+0xB0], xmm11
000070dabbdd2428  vmovaps [rsp+0xC0], xmm12
000070dabbdd2431  vmovaps [rsp+0xD0], xmm14
000070dabbdd243a  vmovaps [rsp+0xE0], xmm15
000070dabbdd2443  sub rsp, 0x30
000070dabbdd2447  movaps [rsp], xmm13
000070dabbdd244c  movaps [rsp+0x10], xmm11
000070dabbdd2452  movaps [rsp+0x20], xmm1
000070dabbdd2457  lea rdi, [rsp]
000070dabbdd245b  mov esi, 0x00
000070dabbdd2460  mov rax, 0x5C2CF7B6F530
000070dabbdd246a  call rax
000070dabbdd246c  movaps xmm13, [rsp]
000070dabbdd2471  add rsp, 0x30
000070dabbdd2475  vmovaps xmm0, [rsp]
000070dabbdd247a  vmovaps xmm1, [rsp+0x10]
000070dabbdd2480  vmovaps xmm2, [rsp+0x20]
000070dabbdd2486  vmovaps xmm3, [rsp+0x30]
000070dabbdd248c  vmovaps xmm4, [rsp+0x40]
000070dabbdd2492  vmovaps xmm5, [rsp+0x50]
000070dabbdd2498  vmovaps xmm6, [rsp+0x60]
000070dabbdd249e  vmovaps xmm7, [rsp+0x70]
000070dabbdd24a4  vmovaps xmm8, [rsp+0x80]
000070dabbdd24ad  vmovaps xmm9, [rsp+0x90]
000070dabbdd24b6  vmovaps xmm10, [rsp+0xA0]
000070dabbdd24bf  vmovaps xmm11, [rsp+0xB0]
000070dabbdd24c8  vmovaps xmm12, [rsp+0xC0]
000070dabbdd24d1  vmovaps xmm14, [rsp+0xD0]
000070dabbdd24da  vmovaps xmm15, [rsp+0xE0]
000070dabbdd24e3  add rsp, 0xF0
000070dabbdd24ea  pop r11
000070dabbdd24ec  pop r10
000070dabbdd24ee  pop r9
000070dabbdd24f0  pop r8
000070dabbdd24f2  pop rsi
000070dabbdd24f3  pop rdi
000070dabbdd24f4  pop rdx
000070dabbdd24f5  pop rcx
000070dabbdd24f6  pop rax
000070dabbdd24f7  add rsp, 0x08
000070dabbdd24fb  jmp 0x000070DABBDCFC76
000070dabbdd2500  call 0x000070DABBBFF430
000070dabbdd2505  jmp 0x000070DABBDCFC83
000070dabbdd250a  sub rsp, 0x08
000070dabbdd250e  push rax
000070dabbdd250f  push rcx
000070dabbdd2510  push rdx
000070dabbdd2511  push rdi
000070dabbdd2512  push rsi
000070dabbdd2513  push r8
000070dabbdd2515  push r9
000070dabbdd2517  push r10
000070dabbdd2519  push r11
000070dabbdd251b  sub rsp, 0xF0
000070dabbdd2522  vmovaps [rsp], xmm0
000070dabbdd2527  vmovaps [rsp+0x10], xmm1
000070dabbdd252d  vmovaps [rsp+0x20], xmm2
000070dabbdd2533  vmovaps [rsp+0x30], xmm3
000070dabbdd2539  vmovaps [rsp+0x40], xmm4
000070dabbdd253f  vmovaps [rsp+0x50], xmm5
000070dabbdd2545  vmovaps [rsp+0x60], xmm6
000070dabbdd254b  vmovaps [rsp+0x70], xmm7
000070dabbdd2551  vmovaps [rsp+0x80], xmm8
000070dabbdd255a  vmovaps [rsp+0x90], xmm9
000070dabbdd2563  vmovaps [rsp+0xA0], xmm10
000070dabbdd256c  vmovaps [rsp+0xB0], xmm11
000070dabbdd2575  vmovaps [rsp+0xC0], xmm12
000070dabbdd257e  vmovaps [rsp+0xD0], xmm13
000070dabbdd2587  vmovaps [rsp+0xE0], xmm14
000070dabbdd2590  sub rsp, 0x30
000070dabbdd2594  movaps [rsp], xmm15
000070dabbdd2599  movaps [rsp+0x10], xmm11
000070dabbdd259f  movaps [rsp+0x20], xmm1
000070dabbdd25a4  lea rdi, [rsp]
000070dabbdd25a8  mov esi, 0x00
000070dabbdd25ad  mov rax, 0x5C2CF7B6F530
000070dabbdd25b7  call rax
000070dabbdd25b9  movaps xmm15, [rsp]
000070dabbdd25be  add rsp, 0x30
000070dabbdd25c2  vmovaps xmm0, [rsp]
000070dabbdd25c7  vmovaps xmm1, [rsp+0x10]
000070dabbdd25cd  vmovaps xmm2, [rsp+0x20]
000070dabbdd25d3  vmovaps xmm3, [rsp+0x30]
000070dabbdd25d9  vmovaps xmm4, [rsp+0x40]
000070dabbdd25df  vmovaps xmm5, [rsp+0x50]
000070dabbdd25e5  vmovaps xmm6, [rsp+0x60]
000070dabbdd25eb  vmovaps xmm7, [rsp+0x70]
000070dabbdd25f1  vmovaps xmm8, [rsp+0x80]
000070dabbdd25fa  vmovaps xmm9, [rsp+0x90]
000070dabbdd2603  vmovaps xmm10, [rsp+0xA0]
000070dabbdd260c  vmovaps xmm11, [rsp+0xB0]
000070dabbdd2615  vmovaps xmm12, [rsp+0xC0]
000070dabbdd261e  vmovaps xmm13, [rsp+0xD0]
000070dabbdd2627  vmovaps xmm14, [rsp+0xE0]
000070dabbdd2630  add rsp, 0xF0
000070dabbdd2637  pop r11
000070dabbdd2639  pop r10
000070dabbdd263b  pop r9
000070dabbdd263d  pop r8
000070dabbdd263f  pop rsi
000070dabbdd2640  pop rdi
000070dabbdd2641  pop rdx
000070dabbdd2642  pop rcx
000070dabbdd2643  pop rax
000070dabbdd2644  add rsp, 0x08
000070dabbdd2648  jmp 0x000070DABBDCFCBC
000070dabbdd264d  sub rsp, 0x08
000070dabbdd2651  push rax
000070dabbdd2652  push rcx
000070dabbdd2653  push rdx
000070dabbdd2654  push rdi
000070dabbdd2655  push rsi
000070dabbdd2656  push r8
000070dabbdd2658  push r9
000070dabbdd265a  push r10
000070dabbdd265c  push r11
000070dabbdd265e  sub rsp, 0xF0
000070dabbdd2665  vmovaps [rsp], xmm0
000070dabbdd266a  vmovaps [rsp+0x10], xmm1
000070dabbdd2670  vmovaps [rsp+0x20], xmm2
000070dabbdd2676  vmovaps [rsp+0x30], xmm3
000070dabbdd267c  vmovaps [rsp+0x40], xmm4
000070dabbdd2682  vmovaps [rsp+0x50], xmm5
000070dabbdd2688  vmovaps [rsp+0x60], xmm6
000070dabbdd268e  vmovaps [rsp+0x70], xmm7
000070dabbdd2694  vmovaps [rsp+0x80], xmm8
000070dabbdd269d  vmovaps [rsp+0x90], xmm9
000070dabbdd26a6  vmovaps [rsp+0xA0], xmm10
000070dabbdd26af  vmovaps [rsp+0xB0], xmm12
000070dabbdd26b8  vmovaps [rsp+0xC0], xmm13
000070dabbdd26c1  vmovaps [rsp+0xD0], xmm14
000070dabbdd26ca  vmovaps [rsp+0xE0], xmm15
000070dabbdd26d3  sub rsp, 0x30
000070dabbdd26d7  movaps [rsp], xmm11
000070dabbdd26dc  movaps [rsp+0x10], xmm6
000070dabbdd26e1  movaps [rsp+0x20], xmm14
000070dabbdd26e7  lea rdi, [rsp]
000070dabbdd26eb  mov esi, 0x00
000070dabbdd26f0  mov rax, 0x5C2CF7B6F530
000070dabbdd26fa  call rax
000070dabbdd26fc  movaps xmm11, [rsp]
000070dabbdd2701  add rsp, 0x30
000070dabbdd2705  vmovaps xmm0, [rsp]
000070dabbdd270a  vmovaps xmm1, [rsp+0x10]
000070dabbdd2710  vmovaps xmm2, [rsp+0x20]
000070dabbdd2716  vmovaps xmm3, [rsp+0x30]
000070dabbdd271c  vmovaps xmm4, [rsp+0x40]
000070dabbdd2722  vmovaps xmm5, [rsp+0x50]
000070dabbdd2728  vmovaps xmm6, [rsp+0x60]
000070dabbdd272e  vmovaps xmm7, [rsp+0x70]
000070dabbdd2734  vmovaps xmm8, [rsp+0x80]
000070dabbdd273d  vmovaps xmm9, [rsp+0x90]
000070dabbdd2746  vmovaps xmm10, [rsp+0xA0]
000070dabbdd274f  vmovaps xmm12, [rsp+0xB0]
000070dabbdd2758  vmovaps xmm13, [rsp+0xC0]
000070dabbdd2761  vmovaps xmm14, [rsp+0xD0]
000070dabbdd276a  vmovaps xmm15, [rsp+0xE0]
000070dabbdd2773  add rsp, 0xF0
000070dabbdd277a  pop r11
000070dabbdd277c  pop r10
000070dabbdd277e  pop r9
000070dabbdd2780  pop r8
000070dabbdd2782  pop rsi
000070dabbdd2783  pop rdi
000070dabbdd2784  pop rdx
000070dabbdd2785  pop rcx
000070dabbdd2786  pop rax
000070dabbdd2787  add rsp, 0x08
000070dabbdd278b  jmp 0x000070DABBDCFD34
000070dabbdd2790  call 0x000070DABBBFF430
000070dabbdd2795  jmp 0x000070DABBDCFD3E
000070dabbdd279a  sub rsp, 0x08
000070dabbdd279e  push rax
000070dabbdd279f  push rcx
000070dabbdd27a0  push rdx
000070dabbdd27a1  push rdi
000070dabbdd27a2  push rsi
000070dabbdd27a3  push r8
000070dabbdd27a5  push r9
000070dabbdd27a7  push r10
000070dabbdd27a9  push r11
000070dabbdd27ab  sub rsp, 0xF0
000070dabbdd27b2  vmovaps [rsp], xmm0
000070dabbdd27b7  vmovaps [rsp+0x10], xmm1
000070dabbdd27bd  vmovaps [rsp+0x20], xmm2
000070dabbdd27c3  vmovaps [rsp+0x30], xmm3
000070dabbdd27c9  vmovaps [rsp+0x40], xmm4
000070dabbdd27cf  vmovaps [rsp+0x50], xmm5
000070dabbdd27d5  vmovaps [rsp+0x60], xmm6
000070dabbdd27db  vmovaps [rsp+0x70], xmm7
000070dabbdd27e1  vmovaps [rsp+0x80], xmm8
000070dabbdd27ea  vmovaps [rsp+0x90], xmm9
000070dabbdd27f3  vmovaps [rsp+0xA0], xmm10
000070dabbdd27fc  vmovaps [rsp+0xB0], xmm11
000070dabbdd2805  vmovaps [rsp+0xC0], xmm12
000070dabbdd280e  vmovaps [rsp+0xD0], xmm13
000070dabbdd2817  vmovaps [rsp+0xE0], xmm15
000070dabbdd2820  sub rsp, 0x30
000070dabbdd2824  movaps [rsp], xmm14
000070dabbdd2829  movaps [rsp+0x10], xmm6
000070dabbdd282e  movaps [rsp+0x20], xmm2
000070dabbdd2833  lea rdi, [rsp]
000070dabbdd2837  mov esi, 0x00
000070dabbdd283c  mov rax, 0x5C2CF7B6F530
000070dabbdd2846  call rax
000070dabbdd2848  movaps xmm14, [rsp]
000070dabbdd284d  add rsp, 0x30
000070dabbdd2851  vmovaps xmm0, [rsp]
000070dabbdd2856  vmovaps xmm1, [rsp+0x10]
000070dabbdd285c  vmovaps xmm2, [rsp+0x20]
000070dabbdd2862  vmovaps xmm3, [rsp+0x30]
000070dabbdd2868  vmovaps xmm4, [rsp+0x40]
000070dabbdd286e  vmovaps xmm5, [rsp+0x50]
000070dabbdd2874  vmovaps xmm6, [rsp+0x60]
000070dabbdd287a  vmovaps xmm7, [rsp+0x70]
000070dabbdd2880  vmovaps xmm8, [rsp+0x80]
000070dabbdd2889  vmovaps xmm9, [rsp+0x90]
000070dabbdd2892  vmovaps xmm10, [rsp+0xA0]
000070dabbdd289b  vmovaps xmm11, [rsp+0xB0]
000070dabbdd28a4  vmovaps xmm12, [rsp+0xC0]
000070dabbdd28ad  vmovaps xmm13, [rsp+0xD0]
000070dabbdd28b6  vmovaps xmm15, [rsp+0xE0]
000070dabbdd28bf  add rsp, 0xF0
000070dabbdd28c6  pop r11
000070dabbdd28c8  pop r10
000070dabbdd28ca  pop r9
000070dabbdd28cc  pop r8
000070dabbdd28ce  pop rsi
000070dabbdd28cf  pop rdi
000070dabbdd28d0  pop rdx
000070dabbdd28d1  pop rcx
000070dabbdd28d2  pop rax
000070dabbdd28d3  add rsp, 0x08
000070dabbdd28d7  jmp 0x000070DABBDCFD72
000070dabbdd28dc  sub rsp, 0x08
000070dabbdd28e0  push rax
000070dabbdd28e1  push rcx
000070dabbdd28e2  push rdx
000070dabbdd28e3  push rdi
000070dabbdd28e4  push rsi
000070dabbdd28e5  push r8
000070dabbdd28e7  push r9
000070dabbdd28e9  push r10
000070dabbdd28eb  push r11
000070dabbdd28ed  sub rsp, 0xF0
000070dabbdd28f4  vmovaps [rsp], xmm0
000070dabbdd28f9  vmovaps [rsp+0x10], xmm1
000070dabbdd28ff  vmovaps [rsp+0x20], xmm2
000070dabbdd2905  vmovaps [rsp+0x30], xmm3
000070dabbdd290b  vmovaps [rsp+0x40], xmm4
000070dabbdd2911  vmovaps [rsp+0x50], xmm5
000070dabbdd2917  vmovaps [rsp+0x60], xmm7
000070dabbdd291d  vmovaps [rsp+0x70], xmm8
000070dabbdd2923  vmovaps [rsp+0x80], xmm9
000070dabbdd292c  vmovaps [rsp+0x90], xmm10
000070dabbdd2935  vmovaps [rsp+0xA0], xmm11
000070dabbdd293e  vmovaps [rsp+0xB0], xmm12
000070dabbdd2947  vmovaps [rsp+0xC0], xmm13
000070dabbdd2950  vmovaps [rsp+0xD0], xmm14
000070dabbdd2959  vmovaps [rsp+0xE0], xmm15
000070dabbdd2962  sub rsp, 0x30
000070dabbdd2966  movaps [rsp], xmm6
000070dabbdd296a  movaps [rsp+0x10], xmm5
000070dabbdd296f  movaps [rsp+0x20], xmm1
000070dabbdd2974  lea rdi, [rsp]
000070dabbdd2978  mov esi, 0x00
000070dabbdd297d  mov rax, 0x5C2CF7B6F530
000070dabbdd2987  call rax
000070dabbdd2989  movaps xmm6, [rsp]
000070dabbdd298d  add rsp, 0x30
000070dabbdd2991  vmovaps xmm0, [rsp]
000070dabbdd2996  vmovaps xmm1, [rsp+0x10]
000070dabbdd299c  vmovaps xmm2, [rsp+0x20]
000070dabbdd29a2  vmovaps xmm3, [rsp+0x30]
000070dabbdd29a8  vmovaps xmm4, [rsp+0x40]
000070dabbdd29ae  vmovaps xmm5, [rsp+0x50]
000070dabbdd29b4  vmovaps xmm7, [rsp+0x60]
000070dabbdd29ba  vmovaps xmm8, [rsp+0x70]
000070dabbdd29c0  vmovaps xmm9, [rsp+0x80]
000070dabbdd29c9  vmovaps xmm10, [rsp+0x90]
000070dabbdd29d2  vmovaps xmm11, [rsp+0xA0]
000070dabbdd29db  vmovaps xmm12, [rsp+0xB0]
000070dabbdd29e4  vmovaps xmm13, [rsp+0xC0]
000070dabbdd29ed  vmovaps xmm14, [rsp+0xD0]
000070dabbdd29f6  vmovaps xmm15, [rsp+0xE0]
000070dabbdd29ff  add rsp, 0xF0
000070dabbdd2a06  pop r11
000070dabbdd2a08  pop r10
000070dabbdd2a0a  pop r9
000070dabbdd2a0c  pop r8
000070dabbdd2a0e  pop rsi
000070dabbdd2a0f  pop rdi
000070dabbdd2a10  pop rdx
000070dabbdd2a11  pop rcx
000070dabbdd2a12  pop rax
000070dabbdd2a13  add rsp, 0x08
000070dabbdd2a17  jmp 0x000070DABBDCFD98
000070dabbdd2a1c  sub rsp, 0x08
000070dabbdd2a20  push rax
000070dabbdd2a21  push rcx
000070dabbdd2a22  push rdx
000070dabbdd2a23  push rdi
000070dabbdd2a24  push rsi
000070dabbdd2a25  push r8
000070dabbdd2a27  push r9
000070dabbdd2a29  push r10
000070dabbdd2a2b  push r11
000070dabbdd2a2d  sub rsp, 0xF0
000070dabbdd2a34  vmovaps [rsp], xmm0
000070dabbdd2a39  vmovaps [rsp+0x10], xmm2
000070dabbdd2a3f  vmovaps [rsp+0x20], xmm3
000070dabbdd2a45  vmovaps [rsp+0x30], xmm4
000070dabbdd2a4b  vmovaps [rsp+0x40], xmm5
000070dabbdd2a51  vmovaps [rsp+0x50], xmm6
000070dabbdd2a57  vmovaps [rsp+0x60], xmm7
000070dabbdd2a5d  vmovaps [rsp+0x70], xmm8
000070dabbdd2a63  vmovaps [rsp+0x80], xmm9
000070dabbdd2a6c  vmovaps [rsp+0x90], xmm10
000070dabbdd2a75  vmovaps [rsp+0xA0], xmm11
000070dabbdd2a7e  vmovaps [rsp+0xB0], xmm12
000070dabbdd2a87  vmovaps [rsp+0xC0], xmm13
000070dabbdd2a90  vmovaps [rsp+0xD0], xmm14
000070dabbdd2a99  vmovaps [rsp+0xE0], xmm15
000070dabbdd2aa2  sub rsp, 0x30
000070dabbdd2aa6  movaps [rsp], xmm1
000070dabbdd2aaa  movaps [rsp+0x10], xmm5
000070dabbdd2aaf  movaps [rsp+0x20], xmm13
000070dabbdd2ab5  lea rdi, [rsp]
000070dabbdd2ab9  mov esi, 0x00
000070dabbdd2abe  mov rax, 0x5C2CF7B6F530
000070dabbdd2ac8  call rax
000070dabbdd2aca  movaps xmm1, [rsp]
000070dabbdd2ace  add rsp, 0x30
000070dabbdd2ad2  vmovaps xmm0, [rsp]
000070dabbdd2ad7  vmovaps xmm2, [rsp+0x10]
000070dabbdd2add  vmovaps xmm3, [rsp+0x20]
000070dabbdd2ae3  vmovaps xmm4, [rsp+0x30]
000070dabbdd2ae9  vmovaps xmm5, [rsp+0x40]
000070dabbdd2aef  vmovaps xmm6, [rsp+0x50]
000070dabbdd2af5  vmovaps xmm7, [rsp+0x60]
000070dabbdd2afb  vmovaps xmm8, [rsp+0x70]
000070dabbdd2b01  vmovaps xmm9, [rsp+0x80]
000070dabbdd2b0a  vmovaps xmm10, [rsp+0x90]
000070dabbdd2b13  vmovaps xmm11, [rsp+0xA0]
000070dabbdd2b1c  vmovaps xmm12, [rsp+0xB0]
000070dabbdd2b25  vmovaps xmm13, [rsp+0xC0]
000070dabbdd2b2e  vmovaps xmm14, [rsp+0xD0]
000070dabbdd2b37  vmovaps xmm15, [rsp+0xE0]
000070dabbdd2b40  add rsp, 0xF0
000070dabbdd2b47  pop r11
000070dabbdd2b49  pop r10
000070dabbdd2b4b  pop r9
000070dabbdd2b4d  pop r8
000070dabbdd2b4f  pop rsi
000070dabbdd2b50  pop rdi
000070dabbdd2b51  pop rdx
000070dabbdd2b52  pop rcx
000070dabbdd2b53  pop rax
000070dabbdd2b54  add rsp, 0x08
000070dabbdd2b58  jmp 0x000070DABBDCFDB6
000070dabbdd2b5d  sub rsp, 0x08
000070dabbdd2b61  push rax
000070dabbdd2b62  push rcx
000070dabbdd2b63  push rdx
000070dabbdd2b64  push rdi
000070dabbdd2b65  push rsi
000070dabbdd2b66  push r8
000070dabbdd2b68  push r9
000070dabbdd2b6a  push r10
000070dabbdd2b6c  push r11
000070dabbdd2b6e  sub rsp, 0xF0
000070dabbdd2b75  vmovaps [rsp], xmm0
000070dabbdd2b7a  vmovaps [rsp+0x10], xmm1
000070dabbdd2b80  vmovaps [rsp+0x20], xmm2
000070dabbdd2b86  vmovaps [rsp+0x30], xmm3
000070dabbdd2b8c  vmovaps [rsp+0x40], xmm4
000070dabbdd2b92  vmovaps [rsp+0x50], xmm6
000070dabbdd2b98  vmovaps [rsp+0x60], xmm7
000070dabbdd2b9e  vmovaps [rsp+0x70], xmm8
000070dabbdd2ba4  vmovaps [rsp+0x80], xmm9
000070dabbdd2bad  vmovaps [rsp+0x90], xmm10
000070dabbdd2bb6  vmovaps [rsp+0xA0], xmm11
000070dabbdd2bbf  vmovaps [rsp+0xB0], xmm12
000070dabbdd2bc8  vmovaps [rsp+0xC0], xmm13
000070dabbdd2bd1  vmovaps [rsp+0xD0], xmm14
000070dabbdd2bda  vmovaps [rsp+0xE0], xmm15
000070dabbdd2be3  sub rsp, 0x30
000070dabbdd2be7  movaps [rsp], xmm5
000070dabbdd2beb  movaps [rsp+0x10], xmm2
000070dabbdd2bf0  movaps [rsp+0x20], xmm13
000070dabbdd2bf6  lea rdi, [rsp]
000070dabbdd2bfa  mov esi, 0x00
000070dabbdd2bff  mov rax, 0x5C2CF7B6F530
000070dabbdd2c09  call rax
000070dabbdd2c0b  movaps xmm5, [rsp]
000070dabbdd2c0f  add rsp, 0x30
000070dabbdd2c13  vmovaps xmm0, [rsp]
000070dabbdd2c18  vmovaps xmm1, [rsp+0x10]
000070dabbdd2c1e  vmovaps xmm2, [rsp+0x20]
000070dabbdd2c24  vmovaps xmm3, [rsp+0x30]
000070dabbdd2c2a  vmovaps xmm4, [rsp+0x40]
000070dabbdd2c30  vmovaps xmm6, [rsp+0x50]
000070dabbdd2c36  vmovaps xmm7, [rsp+0x60]
000070dabbdd2c3c  vmovaps xmm8, [rsp+0x70]
000070dabbdd2c42  vmovaps xmm9, [rsp+0x80]
000070dabbdd2c4b  vmovaps xmm10, [rsp+0x90]
000070dabbdd2c54  vmovaps xmm11, [rsp+0xA0]
000070dabbdd2c5d  vmovaps xmm12, [rsp+0xB0]
000070dabbdd2c66  vmovaps xmm13, [rsp+0xC0]
000070dabbdd2c6f  vmovaps xmm14, [rsp+0xD0]
000070dabbdd2c78  vmovaps xmm15, [rsp+0xE0]
000070dabbdd2c81  add rsp, 0xF0
000070dabbdd2c88  pop r11
000070dabbdd2c8a  pop r10
000070dabbdd2c8c  pop r9
000070dabbdd2c8e  pop r8
000070dabbdd2c90  pop rsi
000070dabbdd2c91  pop rdi
000070dabbdd2c92  pop rdx
000070dabbdd2c93  pop rcx
000070dabbdd2c94  pop rax
000070dabbdd2c95  add rsp, 0x08
000070dabbdd2c99  jmp 0x000070DABBDCFDEC
000070dabbdd2c9e  sub rsp, 0x08
000070dabbdd2ca2  push rax
000070dabbdd2ca3  push rcx
000070dabbdd2ca4  push rdx
000070dabbdd2ca5  push rdi
000070dabbdd2ca6  push rsi
000070dabbdd2ca7  push r8
000070dabbdd2ca9  push r9
000070dabbdd2cab  push r10
000070dabbdd2cad  push r11
000070dabbdd2caf  sub rsp, 0xF0
000070dabbdd2cb6  vmovaps [rsp], xmm0
000070dabbdd2cbb  vmovaps [rsp+0x10], xmm1
000070dabbdd2cc1  vmovaps [rsp+0x20], xmm2
000070dabbdd2cc7  vmovaps [rsp+0x30], xmm3
000070dabbdd2ccd  vmovaps [rsp+0x40], xmm4
000070dabbdd2cd3  vmovaps [rsp+0x50], xmm5
000070dabbdd2cd9  vmovaps [rsp+0x60], xmm6
000070dabbdd2cdf  vmovaps [rsp+0x70], xmm7
000070dabbdd2ce5  vmovaps [rsp+0x80], xmm8
000070dabbdd2cee  vmovaps [rsp+0x90], xmm9
000070dabbdd2cf7  vmovaps [rsp+0xA0], xmm10
000070dabbdd2d00  vmovaps [rsp+0xB0], xmm11
000070dabbdd2d09  vmovaps [rsp+0xC0], xmm12
000070dabbdd2d12  vmovaps [rsp+0xD0], xmm14
000070dabbdd2d1b  vmovaps [rsp+0xE0], xmm15
000070dabbdd2d24  sub rsp, 0x30
000070dabbdd2d28  movaps [rsp], xmm13
000070dabbdd2d2d  movaps [rsp+0x10], xmm10
000070dabbdd2d33  movaps [rsp+0x20], xmm1
000070dabbdd2d38  lea rdi, [rsp]
000070dabbdd2d3c  mov esi, 0x00
000070dabbdd2d41  mov rax, 0x5C2CF7B6F530
000070dabbdd2d4b  call rax
000070dabbdd2d4d  movaps xmm13, [rsp]
000070dabbdd2d52  add rsp, 0x30
000070dabbdd2d56  vmovaps xmm0, [rsp]
000070dabbdd2d5b  vmovaps xmm1, [rsp+0x10]
000070dabbdd2d61  vmovaps xmm2, [rsp+0x20]
000070dabbdd2d67  vmovaps xmm3, [rsp+0x30]
000070dabbdd2d6d  vmovaps xmm4, [rsp+0x40]
000070dabbdd2d73  vmovaps xmm5, [rsp+0x50]
000070dabbdd2d79  vmovaps xmm6, [rsp+0x60]
000070dabbdd2d7f  vmovaps xmm7, [rsp+0x70]
000070dabbdd2d85  vmovaps xmm8, [rsp+0x80]
000070dabbdd2d8e  vmovaps xmm9, [rsp+0x90]
000070dabbdd2d97  vmovaps xmm10, [rsp+0xA0]
000070dabbdd2da0  vmovaps xmm11, [rsp+0xB0]
000070dabbdd2da9  vmovaps xmm12, [rsp+0xC0]
000070dabbdd2db2  vmovaps xmm14, [rsp+0xD0]
000070dabbdd2dbb  vmovaps xmm15, [rsp+0xE0]
000070dabbdd2dc4  add rsp, 0xF0
000070dabbdd2dcb  pop r11
000070dabbdd2dcd  pop r10
000070dabbdd2dcf  pop r9
000070dabbdd2dd1  pop r8
000070dabbdd2dd3  pop rsi
000070dabbdd2dd4  pop rdi
000070dabbdd2dd5  pop rdx
000070dabbdd2dd6  pop rcx
000070dabbdd2dd7  pop rax
000070dabbdd2dd8  add rsp, 0x08
000070dabbdd2ddc  jmp 0x000070DABBDCFE15
000070dabbdd2de1  sub rsp, 0x08
000070dabbdd2de5  push rax
000070dabbdd2de6  push rcx
000070dabbdd2de7  push rdx
000070dabbdd2de8  push rdi
000070dabbdd2de9  push rsi
000070dabbdd2dea  push r8
000070dabbdd2dec  push r9
000070dabbdd2dee  push r10
000070dabbdd2df0  push r11
000070dabbdd2df2  sub rsp, 0xF0
000070dabbdd2df9  vmovaps [rsp], xmm0
000070dabbdd2dfe  vmovaps [rsp+0x10], xmm2
000070dabbdd2e04  vmovaps [rsp+0x20], xmm3
000070dabbdd2e0a  vmovaps [rsp+0x30], xmm4
000070dabbdd2e10  vmovaps [rsp+0x40], xmm5
000070dabbdd2e16  vmovaps [rsp+0x50], xmm6
000070dabbdd2e1c  vmovaps [rsp+0x60], xmm7
000070dabbdd2e22  vmovaps [rsp+0x70], xmm8
000070dabbdd2e28  vmovaps [rsp+0x80], xmm9
000070dabbdd2e31  vmovaps [rsp+0x90], xmm10
000070dabbdd2e3a  vmovaps [rsp+0xA0], xmm11
000070dabbdd2e43  vmovaps [rsp+0xB0], xmm12
000070dabbdd2e4c  vmovaps [rsp+0xC0], xmm13
000070dabbdd2e55  vmovaps [rsp+0xD0], xmm14
000070dabbdd2e5e  vmovaps [rsp+0xE0], xmm15
000070dabbdd2e67  sub rsp, 0x30
000070dabbdd2e6b  movaps [rsp], xmm1
000070dabbdd2e6f  movaps [rsp+0x10], xmm15
000070dabbdd2e75  movaps [rsp+0x20], xmm10
000070dabbdd2e7b  lea rdi, [rsp]
000070dabbdd2e7f  mov esi, 0x00
000070dabbdd2e84  mov rax, 0x5C2CF7B6F530
000070dabbdd2e8e  call rax
000070dabbdd2e90  movaps xmm1, [rsp]
000070dabbdd2e94  add rsp, 0x30
000070dabbdd2e98  vmovaps xmm0, [rsp]
000070dabbdd2e9d  vmovaps xmm2, [rsp+0x10]
000070dabbdd2ea3  vmovaps xmm3, [rsp+0x20]
000070dabbdd2ea9  vmovaps xmm4, [rsp+0x30]
000070dabbdd2eaf  vmovaps xmm5, [rsp+0x40]
000070dabbdd2eb5  vmovaps xmm6, [rsp+0x50]
000070dabbdd2ebb  vmovaps xmm7, [rsp+0x60]
000070dabbdd2ec1  vmovaps xmm8, [rsp+0x70]
000070dabbdd2ec7  vmovaps xmm9, [rsp+0x80]
000070dabbdd2ed0  vmovaps xmm10, [rsp+0x90]
000070dabbdd2ed9  vmovaps xmm11, [rsp+0xA0]
000070dabbdd2ee2  vmovaps xmm12, [rsp+0xB0]
000070dabbdd2eeb  vmovaps xmm13, [rsp+0xC0]
000070dabbdd2ef4  vmovaps xmm14, [rsp+0xD0]
000070dabbdd2efd  vmovaps xmm15, [rsp+0xE0]
000070dabbdd2f06  add rsp, 0xF0
000070dabbdd2f0d  pop r11
000070dabbdd2f0f  pop r10
000070dabbdd2f11  pop r9
000070dabbdd2f13  pop r8
000070dabbdd2f15  pop rsi
000070dabbdd2f16  pop rdi
000070dabbdd2f17  pop rdx
000070dabbdd2f18  pop rcx
000070dabbdd2f19  pop rax
000070dabbdd2f1a  add rsp, 0x08
000070dabbdd2f1e  jmp 0x000070DABBDCFE34
000070dabbdd2f23  sub rsp, 0x08
000070dabbdd2f27  push rax
000070dabbdd2f28  push rcx
000070dabbdd2f29  push rdx
000070dabbdd2f2a  push rdi
000070dabbdd2f2b  push rsi
000070dabbdd2f2c  push r8
000070dabbdd2f2e  push r9
000070dabbdd2f30  push r10
000070dabbdd2f32  push r11
000070dabbdd2f34  sub rsp, 0xF0
000070dabbdd2f3b  vmovaps [rsp], xmm0
000070dabbdd2f40  vmovaps [rsp+0x10], xmm1
000070dabbdd2f46  vmovaps [rsp+0x20], xmm2
000070dabbdd2f4c  vmovaps [rsp+0x30], xmm3
000070dabbdd2f52  vmovaps [rsp+0x40], xmm4
000070dabbdd2f58  vmovaps [rsp+0x50], xmm5
000070dabbdd2f5e  vmovaps [rsp+0x60], xmm6
000070dabbdd2f64  vmovaps [rsp+0x70], xmm7
000070dabbdd2f6a  vmovaps [rsp+0x80], xmm8
000070dabbdd2f73  vmovaps [rsp+0x90], xmm9
000070dabbdd2f7c  vmovaps [rsp+0xA0], xmm10
000070dabbdd2f85  vmovaps [rsp+0xB0], xmm11
000070dabbdd2f8e  vmovaps [rsp+0xC0], xmm12
000070dabbdd2f97  vmovaps [rsp+0xD0], xmm13
000070dabbdd2fa0  vmovaps [rsp+0xE0], xmm14
000070dabbdd2fa9  sub rsp, 0x30
000070dabbdd2fad  movaps [rsp], xmm15
000070dabbdd2fb2  movaps [rsp+0x10], xmm10
000070dabbdd2fb8  movaps [rsp+0x20], xmm11
000070dabbdd2fbe  lea rdi, [rsp]
000070dabbdd2fc2  mov esi, 0x00
000070dabbdd2fc7  mov rax, 0x5C2CF7B6F530
000070dabbdd2fd1  call rax
000070dabbdd2fd3  movaps xmm15, [rsp]
000070dabbdd2fd8  add rsp, 0x30
000070dabbdd2fdc  vmovaps xmm0, [rsp]
000070dabbdd2fe1  vmovaps xmm1, [rsp+0x10]
000070dabbdd2fe7  vmovaps xmm2, [rsp+0x20]
000070dabbdd2fed  vmovaps xmm3, [rsp+0x30]
000070dabbdd2ff3  vmovaps xmm4, [rsp+0x40]
000070dabbdd2ff9  vmovaps xmm5, [rsp+0x50]
000070dabbdd2fff  vmovaps xmm6, [rsp+0x60]
000070dabbdd3005  vmovaps xmm7, [rsp+0x70]
000070dabbdd300b  vmovaps xmm8, [rsp+0x80]
000070dabbdd3014  vmovaps xmm9, [rsp+0x90]
000070dabbdd301d  vmovaps xmm10, [rsp+0xA0]
000070dabbdd3026  vmovaps xmm11, [rsp+0xB0]
000070dabbdd302f  vmovaps xmm12, [rsp+0xC0]
000070dabbdd3038  vmovaps xmm13, [rsp+0xD0]
000070dabbdd3041  vmovaps xmm14, [rsp+0xE0]
000070dabbdd304a  add rsp, 0xF0
000070dabbdd3051  pop r11
000070dabbdd3053  pop r10
000070dabbdd3055  pop r9
000070dabbdd3057  pop r8
000070dabbdd3059  pop rsi
000070dabbdd305a  pop rdi
000070dabbdd305b  pop rdx
000070dabbdd305c  pop rcx
000070dabbdd305d  pop rax
000070dabbdd305e  add rsp, 0x08
000070dabbdd3062  jmp 0x000070DABBDCFE57
000070dabbdd3067  sub rsp, 0x08
000070dabbdd306b  push rax
000070dabbdd306c  push rcx
000070dabbdd306d  push rdx
000070dabbdd306e  push rdi
000070dabbdd306f  push rsi
000070dabbdd3070  push r8
000070dabbdd3072  push r9
000070dabbdd3074  push r10
000070dabbdd3076  push r11
000070dabbdd3078  sub rsp, 0xF0
000070dabbdd307f  vmovaps [rsp], xmm0
000070dabbdd3084  vmovaps [rsp+0x10], xmm1
000070dabbdd308a  vmovaps [rsp+0x20], xmm2
000070dabbdd3090  vmovaps [rsp+0x30], xmm3
000070dabbdd3096  vmovaps [rsp+0x40], xmm4
000070dabbdd309c  vmovaps [rsp+0x50], xmm5
000070dabbdd30a2  vmovaps [rsp+0x60], xmm6
000070dabbdd30a8  vmovaps [rsp+0x70], xmm7
000070dabbdd30ae  vmovaps [rsp+0x80], xmm8
000070dabbdd30b7  vmovaps [rsp+0x90], xmm9
000070dabbdd30c0  vmovaps [rsp+0xA0], xmm11
000070dabbdd30c9  vmovaps [rsp+0xB0], xmm12
000070dabbdd30d2  vmovaps [rsp+0xC0], xmm13
000070dabbdd30db  vmovaps [rsp+0xD0], xmm14
000070dabbdd30e4  vmovaps [rsp+0xE0], xmm15
000070dabbdd30ed  sub rsp, 0x30
000070dabbdd30f1  movaps [rsp], xmm10
000070dabbdd30f6  movaps [rsp+0x10], xmm12
000070dabbdd30fc  movaps [rsp+0x20], xmm11
000070dabbdd3102  lea rdi, [rsp]
000070dabbdd3106  mov esi, 0x00
000070dabbdd310b  mov rax, 0x5C2CF7B6F530
000070dabbdd3115  call rax
000070dabbdd3117  movaps xmm10, [rsp]
000070dabbdd311c  add rsp, 0x30
000070dabbdd3120  vmovaps xmm0, [rsp]
000070dabbdd3125  vmovaps xmm1, [rsp+0x10]
000070dabbdd312b  vmovaps xmm2, [rsp+0x20]
000070dabbdd3131  vmovaps xmm3, [rsp+0x30]
000070dabbdd3137  vmovaps xmm4, [rsp+0x40]
000070dabbdd313d  vmovaps xmm5, [rsp+0x50]
000070dabbdd3143  vmovaps xmm6, [rsp+0x60]
000070dabbdd3149  vmovaps xmm7, [rsp+0x70]
000070dabbdd314f  vmovaps xmm8, [rsp+0x80]
000070dabbdd3158  vmovaps xmm9, [rsp+0x90]
000070dabbdd3161  vmovaps xmm11, [rsp+0xA0]
000070dabbdd316a  vmovaps xmm12, [rsp+0xB0]
000070dabbdd3173  vmovaps xmm13, [rsp+0xC0]
000070dabbdd317c  vmovaps xmm14, [rsp+0xD0]
000070dabbdd3185  vmovaps xmm15, [rsp+0xE0]
000070dabbdd318e  add rsp, 0xF0
000070dabbdd3195  pop r11
000070dabbdd3197  pop r10
000070dabbdd3199  pop r9
000070dabbdd319b  pop r8
000070dabbdd319d  pop rsi
000070dabbdd319e  pop rdi
000070dabbdd319f  pop rdx
000070dabbdd31a0  pop rcx
000070dabbdd31a1  pop rax
000070dabbdd31a2  add rsp, 0x08
000070dabbdd31a6  jmp 0x000070DABBDCFE80
000070dabbdd31ab  sub rsp, 0x08
000070dabbdd31af  push rax
000070dabbdd31b0  push rcx
000070dabbdd31b1  push rdx
000070dabbdd31b2  push rdi
000070dabbdd31b3  push rsi
000070dabbdd31b4  push r8
000070dabbdd31b6  push r9
000070dabbdd31b8  push r10
000070dabbdd31ba  push r11
000070dabbdd31bc  sub rsp, 0xF0
000070dabbdd31c3  vmovaps [rsp], xmm0
000070dabbdd31c8  vmovaps [rsp+0x10], xmm1
000070dabbdd31ce  vmovaps [rsp+0x20], xmm2
000070dabbdd31d4  vmovaps [rsp+0x30], xmm3
000070dabbdd31da  vmovaps [rsp+0x40], xmm4
000070dabbdd31e0  vmovaps [rsp+0x50], xmm5
000070dabbdd31e6  vmovaps [rsp+0x60], xmm6
000070dabbdd31ec  vmovaps [rsp+0x70], xmm7
000070dabbdd31f2  vmovaps [rsp+0x80], xmm8
000070dabbdd31fb  vmovaps [rsp+0x90], xmm9
000070dabbdd3204  vmovaps [rsp+0xA0], xmm10
000070dabbdd320d  vmovaps [rsp+0xB0], xmm12
000070dabbdd3216  vmovaps [rsp+0xC0], xmm13
000070dabbdd321f  vmovaps [rsp+0xD0], xmm14
000070dabbdd3228  vmovaps [rsp+0xE0], xmm15
000070dabbdd3231  sub rsp, 0x30
000070dabbdd3235  movaps [rsp], xmm11
000070dabbdd323a  movaps [rsp+0x10], xmm2
000070dabbdd323f  movaps [rsp+0x20], xmm12
000070dabbdd3245  lea rdi, [rsp]
000070dabbdd3249  mov esi, 0x00
000070dabbdd324e  mov rax, 0x5C2CF7B6F530
000070dabbdd3258  call rax
000070dabbdd325a  movaps xmm11, [rsp]
000070dabbdd325f  add rsp, 0x30
000070dabbdd3263  vmovaps xmm0, [rsp]
000070dabbdd3268  vmovaps xmm1, [rsp+0x10]
000070dabbdd326e  vmovaps xmm2, [rsp+0x20]
000070dabbdd3274  vmovaps xmm3, [rsp+0x30]
000070dabbdd327a  vmovaps xmm4, [rsp+0x40]
000070dabbdd3280  vmovaps xmm5, [rsp+0x50]
000070dabbdd3286  vmovaps xmm6, [rsp+0x60]
000070dabbdd328c  vmovaps xmm7, [rsp+0x70]
000070dabbdd3292  vmovaps xmm8, [rsp+0x80]
000070dabbdd329b  vmovaps xmm9, [rsp+0x90]
000070dabbdd32a4  vmovaps xmm10, [rsp+0xA0]
000070dabbdd32ad  vmovaps xmm12, [rsp+0xB0]
000070dabbdd32b6  vmovaps xmm13, [rsp+0xC0]
000070dabbdd32bf  vmovaps xmm14, [rsp+0xD0]
000070dabbdd32c8  vmovaps xmm15, [rsp+0xE0]
000070dabbdd32d1  add rsp, 0xF0
000070dabbdd32d8  pop r11
000070dabbdd32da  pop r10
000070dabbdd32dc  pop r9
000070dabbdd32de  pop r8
000070dabbdd32e0  pop rsi
000070dabbdd32e1  pop rdi
000070dabbdd32e2  pop rdx
000070dabbdd32e3  pop rcx
000070dabbdd32e4  pop rax
000070dabbdd32e5  add rsp, 0x08
000070dabbdd32e9  jmp 0x000070DABBDCFEB8
000070dabbdd32ee  sub rsp, 0x08
000070dabbdd32f2  push rax
000070dabbdd32f3  push rcx
000070dabbdd32f4  push rdx
000070dabbdd32f5  push rdi
000070dabbdd32f6  push rsi
000070dabbdd32f7  push r8
000070dabbdd32f9  push r9
000070dabbdd32fb  push r10
000070dabbdd32fd  push r11
000070dabbdd32ff  sub rsp, 0xF0
000070dabbdd3306  vmovaps [rsp], xmm0
000070dabbdd330b  vmovaps [rsp+0x10], xmm2
000070dabbdd3311  vmovaps [rsp+0x20], xmm3
000070dabbdd3317  vmovaps [rsp+0x30], xmm4
000070dabbdd331d  vmovaps [rsp+0x40], xmm5
000070dabbdd3323  vmovaps [rsp+0x50], xmm6
000070dabbdd3329  vmovaps [rsp+0x60], xmm7
000070dabbdd332f  vmovaps [rsp+0x70], xmm8
000070dabbdd3335  vmovaps [rsp+0x80], xmm9
000070dabbdd333e  vmovaps [rsp+0x90], xmm10
000070dabbdd3347  vmovaps [rsp+0xA0], xmm11
000070dabbdd3350  vmovaps [rsp+0xB0], xmm12
000070dabbdd3359  vmovaps [rsp+0xC0], xmm13
000070dabbdd3362  vmovaps [rsp+0xD0], xmm14
000070dabbdd336b  vmovaps [rsp+0xE0], xmm15
000070dabbdd3374  sub rsp, 0x30
000070dabbdd3378  movaps [rsp], xmm1
000070dabbdd337c  movaps [rsp+0x10], xmm14
000070dabbdd3382  movaps [rsp+0x20], xmm6
000070dabbdd3387  lea rdi, [rsp]
000070dabbdd338b  mov esi, 0x00
000070dabbdd3390  mov rax, 0x5C2CF7B6F530
000070dabbdd339a  call rax
000070dabbdd339c  movaps xmm1, [rsp]
000070dabbdd33a0  add rsp, 0x30
000070dabbdd33a4  vmovaps xmm0, [rsp]
000070dabbdd33a9  vmovaps xmm2, [rsp+0x10]
000070dabbdd33af  vmovaps xmm3, [rsp+0x20]
000070dabbdd33b5  vmovaps xmm4, [rsp+0x30]
000070dabbdd33bb  vmovaps xmm5, [rsp+0x40]
000070dabbdd33c1  vmovaps xmm6, [rsp+0x50]
000070dabbdd33c7  vmovaps xmm7, [rsp+0x60]
000070dabbdd33cd  vmovaps xmm8, [rsp+0x70]
000070dabbdd33d3  vmovaps xmm9, [rsp+0x80]
000070dabbdd33dc  vmovaps xmm10, [rsp+0x90]
000070dabbdd33e5  vmovaps xmm11, [rsp+0xA0]
000070dabbdd33ee  vmovaps xmm12, [rsp+0xB0]
000070dabbdd33f7  vmovaps xmm13, [rsp+0xC0]
000070dabbdd3400  vmovaps xmm14, [rsp+0xD0]
000070dabbdd3409  vmovaps xmm15, [rsp+0xE0]
000070dabbdd3412  add rsp, 0xF0
000070dabbdd3419  pop r11
000070dabbdd341b  pop r10
000070dabbdd341d  pop r9
000070dabbdd341f  pop r8
000070dabbdd3421  pop rsi
000070dabbdd3422  pop rdi
000070dabbdd3423  pop rdx
000070dabbdd3424  pop rcx
000070dabbdd3425  pop rax
000070dabbdd3426  add rsp, 0x08
000070dabbdd342a  jmp 0x000070DABBDCFED1
000070dabbdd342f  sub rsp, 0x08
000070dabbdd3433  push rax
000070dabbdd3434  push rcx
000070dabbdd3435  push rdx
000070dabbdd3436  push rdi
000070dabbdd3437  push rsi
000070dabbdd3438  push r8
000070dabbdd343a  push r9
000070dabbdd343c  push r10
000070dabbdd343e  push r11
000070dabbdd3440  sub rsp, 0xF0
000070dabbdd3447  vmovaps [rsp], xmm0
000070dabbdd344c  vmovaps [rsp+0x10], xmm1
000070dabbdd3452  vmovaps [rsp+0x20], xmm2
000070dabbdd3458  vmovaps [rsp+0x30], xmm3
000070dabbdd345e  vmovaps [rsp+0x40], xmm4
000070dabbdd3464  vmovaps [rsp+0x50], xmm5
000070dabbdd346a  vmovaps [rsp+0x60], xmm6
000070dabbdd3470  vmovaps [rsp+0x70], xmm7
000070dabbdd3476  vmovaps [rsp+0x80], xmm8
000070dabbdd347f  vmovaps [rsp+0x90], xmm9
000070dabbdd3488  vmovaps [rsp+0xA0], xmm10
000070dabbdd3491  vmovaps [rsp+0xB0], xmm11
000070dabbdd349a  vmovaps [rsp+0xC0], xmm12
000070dabbdd34a3  vmovaps [rsp+0xD0], xmm13
000070dabbdd34ac  vmovaps [rsp+0xE0], xmm15
000070dabbdd34b5  sub rsp, 0x30
000070dabbdd34b9  movaps [rsp], xmm14
000070dabbdd34be  movaps [rsp+0x10], xmm12
000070dabbdd34c4  movaps [rsp+0x20], xmm5
000070dabbdd34c9  lea rdi, [rsp]
000070dabbdd34cd  mov esi, 0x00
000070dabbdd34d2  mov rax, 0x5C2CF7B6F530
000070dabbdd34dc  call rax
000070dabbdd34de  movaps xmm14, [rsp]
000070dabbdd34e3  add rsp, 0x30
000070dabbdd34e7  vmovaps xmm0, [rsp]
000070dabbdd34ec  vmovaps xmm1, [rsp+0x10]
000070dabbdd34f2  vmovaps xmm2, [rsp+0x20]
000070dabbdd34f8  vmovaps xmm3, [rsp+0x30]
000070dabbdd34fe  vmovaps xmm4, [rsp+0x40]
000070dabbdd3504  vmovaps xmm5, [rsp+0x50]
000070dabbdd350a  vmovaps xmm6, [rsp+0x60]
000070dabbdd3510  vmovaps xmm7, [rsp+0x70]
000070dabbdd3516  vmovaps xmm8, [rsp+0x80]
000070dabbdd351f  vmovaps xmm9, [rsp+0x90]
000070dabbdd3528  vmovaps xmm10, [rsp+0xA0]
000070dabbdd3531  vmovaps xmm11, [rsp+0xB0]
000070dabbdd353a  vmovaps xmm12, [rsp+0xC0]
000070dabbdd3543  vmovaps xmm13, [rsp+0xD0]
000070dabbdd354c  vmovaps xmm15, [rsp+0xE0]
000070dabbdd3555  add rsp, 0xF0
000070dabbdd355c  pop r11
000070dabbdd355e  pop r10
000070dabbdd3560  pop r9
000070dabbdd3562  pop r8
000070dabbdd3564  pop rsi
000070dabbdd3565  pop rdi
000070dabbdd3566  pop rdx
000070dabbdd3567  pop rcx
000070dabbdd3568  pop rax
000070dabbdd3569  add rsp, 0x08
000070dabbdd356d  jmp 0x000070DABBDCFEF1
000070dabbdd3572  sub rsp, 0x08
000070dabbdd3576  push rax
000070dabbdd3577  push rcx
000070dabbdd3578  push rdx
000070dabbdd3579  push rdi
000070dabbdd357a  push rsi
000070dabbdd357b  push r8
000070dabbdd357d  push r9
000070dabbdd357f  push r10
000070dabbdd3581  push r11
000070dabbdd3583  sub rsp, 0xF0
000070dabbdd358a  vmovaps [rsp], xmm0
000070dabbdd358f  vmovaps [rsp+0x10], xmm1
000070dabbdd3595  vmovaps [rsp+0x20], xmm2
000070dabbdd359b  vmovaps [rsp+0x30], xmm3
000070dabbdd35a1  vmovaps [rsp+0x40], xmm4
000070dabbdd35a7  vmovaps [rsp+0x50], xmm5
000070dabbdd35ad  vmovaps [rsp+0x60], xmm7
000070dabbdd35b3  vmovaps [rsp+0x70], xmm8
000070dabbdd35b9  vmovaps [rsp+0x80], xmm9
000070dabbdd35c2  vmovaps [rsp+0x90], xmm10
000070dabbdd35cb  vmovaps [rsp+0xA0], xmm11
000070dabbdd35d4  vmovaps [rsp+0xB0], xmm12
000070dabbdd35dd  vmovaps [rsp+0xC0], xmm13
000070dabbdd35e6  vmovaps [rsp+0xD0], xmm14
000070dabbdd35ef  vmovaps [rsp+0xE0], xmm15
000070dabbdd35f8  sub rsp, 0x30
000070dabbdd35fc  movaps [rsp], xmm6
000070dabbdd3600  movaps [rsp+0x10], xmm9
000070dabbdd3606  movaps [rsp+0x20], xmm12
000070dabbdd360c  lea rdi, [rsp]
000070dabbdd3610  mov esi, 0x00
000070dabbdd3615  mov rax, 0x5C2CF7B6F530
000070dabbdd361f  call rax
000070dabbdd3621  movaps xmm6, [rsp]
000070dabbdd3625  add rsp, 0x30
000070dabbdd3629  vmovaps xmm0, [rsp]
000070dabbdd362e  vmovaps xmm1, [rsp+0x10]
000070dabbdd3634  vmovaps xmm2, [rsp+0x20]
000070dabbdd363a  vmovaps xmm3, [rsp+0x30]
000070dabbdd3640  vmovaps xmm4, [rsp+0x40]
000070dabbdd3646  vmovaps xmm5, [rsp+0x50]
000070dabbdd364c  vmovaps xmm7, [rsp+0x60]
000070dabbdd3652  vmovaps xmm8, [rsp+0x70]
000070dabbdd3658  vmovaps xmm9, [rsp+0x80]
000070dabbdd3661  vmovaps xmm10, [rsp+0x90]
000070dabbdd366a  vmovaps xmm11, [rsp+0xA0]
000070dabbdd3673  vmovaps xmm12, [rsp+0xB0]
000070dabbdd367c  vmovaps xmm13, [rsp+0xC0]
000070dabbdd3685  vmovaps xmm14, [rsp+0xD0]
000070dabbdd368e  vmovaps xmm15, [rsp+0xE0]
000070dabbdd3697  add rsp, 0xF0
000070dabbdd369e  pop r11
000070dabbdd36a0  pop r10
000070dabbdd36a2  pop r9
000070dabbdd36a4  pop r8
000070dabbdd36a6  pop rsi
000070dabbdd36a7  pop rdi
000070dabbdd36a8  pop rdx
000070dabbdd36a9  pop rcx
000070dabbdd36aa  pop rax
000070dabbdd36ab  add rsp, 0x08
000070dabbdd36af  jmp 0x000070DABBDCFF19
000070dabbdd36b4  sub rsp, 0x08
000070dabbdd36b8  push rax
000070dabbdd36b9  push rcx
000070dabbdd36ba  push rdx
000070dabbdd36bb  push rdi
000070dabbdd36bc  push rsi
000070dabbdd36bd  push r8
000070dabbdd36bf  push r9
000070dabbdd36c1  push r10
000070dabbdd36c3  push r11
000070dabbdd36c5  sub rsp, 0xF0
000070dabbdd36cc  vmovaps [rsp], xmm0
000070dabbdd36d1  vmovaps [rsp+0x10], xmm1
000070dabbdd36d7  vmovaps [rsp+0x20], xmm2
000070dabbdd36dd  vmovaps [rsp+0x30], xmm3
000070dabbdd36e3  vmovaps [rsp+0x40], xmm4
000070dabbdd36e9  vmovaps [rsp+0x50], xmm5
000070dabbdd36ef  vmovaps [rsp+0x60], xmm6
000070dabbdd36f5  vmovaps [rsp+0x70], xmm7
000070dabbdd36fb  vmovaps [rsp+0x80], xmm8
000070dabbdd3704  vmovaps [rsp+0x90], xmm9
000070dabbdd370d  vmovaps [rsp+0xA0], xmm10
000070dabbdd3716  vmovaps [rsp+0xB0], xmm11
000070dabbdd371f  vmovaps [rsp+0xC0], xmm13
000070dabbdd3728  vmovaps [rsp+0xD0], xmm14
000070dabbdd3731  vmovaps [rsp+0xE0], xmm15
000070dabbdd373a  sub rsp, 0x30
000070dabbdd373e  movaps [rsp], xmm12
000070dabbdd3743  movaps [rsp+0x10], xmm15
000070dabbdd3749  movaps [rsp+0x20], xmm13
000070dabbdd374f  lea rdi, [rsp]
000070dabbdd3753  mov esi, 0x00
000070dabbdd3758  mov rax, 0x5C2CF7B6F530
000070dabbdd3762  call rax
000070dabbdd3764  movaps xmm12, [rsp]
000070dabbdd3769  add rsp, 0x30
000070dabbdd376d  vmovaps xmm0, [rsp]
000070dabbdd3772  vmovaps xmm1, [rsp+0x10]
000070dabbdd3778  vmovaps xmm2, [rsp+0x20]
000070dabbdd377e  vmovaps xmm3, [rsp+0x30]
000070dabbdd3784  vmovaps xmm4, [rsp+0x40]
000070dabbdd378a  vmovaps xmm5, [rsp+0x50]
000070dabbdd3790  vmovaps xmm6, [rsp+0x60]
000070dabbdd3796  vmovaps xmm7, [rsp+0x70]
000070dabbdd379c  vmovaps xmm8, [rsp+0x80]
000070dabbdd37a5  vmovaps xmm9, [rsp+0x90]
000070dabbdd37ae  vmovaps xmm10, [rsp+0xA0]
000070dabbdd37b7  vmovaps xmm11, [rsp+0xB0]
000070dabbdd37c0  vmovaps xmm13, [rsp+0xC0]
000070dabbdd37c9  vmovaps xmm14, [rsp+0xD0]
000070dabbdd37d2  vmovaps xmm15, [rsp+0xE0]
000070dabbdd37db  add rsp, 0xF0
000070dabbdd37e2  pop r11
000070dabbdd37e4  pop r10
000070dabbdd37e6  pop r9
000070dabbdd37e8  pop r8
000070dabbdd37ea  pop rsi
000070dabbdd37eb  pop rdi
000070dabbdd37ec  pop rdx
000070dabbdd37ed  pop rcx
000070dabbdd37ee  pop rax
000070dabbdd37ef  add rsp, 0x08
000070dabbdd37f3  jmp 0x000070DABBDCFF34
000070dabbdd37f8  sub rsp, 0x08
000070dabbdd37fc  push rax
000070dabbdd37fd  push rcx
000070dabbdd37fe  push rdx
000070dabbdd37ff  push rdi
000070dabbdd3800  push rsi
000070dabbdd3801  push r8
000070dabbdd3803  push r9
000070dabbdd3805  push r10
000070dabbdd3807  push r11
000070dabbdd3809  sub rsp, 0xF0
000070dabbdd3810  vmovaps [rsp], xmm0
000070dabbdd3815  vmovaps [rsp+0x10], xmm1
000070dabbdd381b  vmovaps [rsp+0x20], xmm2
000070dabbdd3821  vmovaps [rsp+0x30], xmm3
000070dabbdd3827  vmovaps [rsp+0x40], xmm4
000070dabbdd382d  vmovaps [rsp+0x50], xmm5
000070dabbdd3833  vmovaps [rsp+0x60], xmm6
000070dabbdd3839  vmovaps [rsp+0x70], xmm7
000070dabbdd383f  vmovaps [rsp+0x80], xmm8
000070dabbdd3848  vmovaps [rsp+0x90], xmm9
000070dabbdd3851  vmovaps [rsp+0xA0], xmm10
000070dabbdd385a  vmovaps [rsp+0xB0], xmm11
000070dabbdd3863  vmovaps [rsp+0xC0], xmm12
000070dabbdd386c  vmovaps [rsp+0xD0], xmm13
000070dabbdd3875  vmovaps [rsp+0xE0], xmm14
000070dabbdd387e  sub rsp, 0x30
000070dabbdd3882  movaps [rsp], xmm15
000070dabbdd3887  movaps [rsp+0x10], xmm13
000070dabbdd388d  movaps [rsp+0x20], xmm10
000070dabbdd3893  lea rdi, [rsp]
000070dabbdd3897  mov esi, 0x00
000070dabbdd389c  mov rax, 0x5C2CF7B6F530
000070dabbdd38a6  call rax
000070dabbdd38a8  movaps xmm15, [rsp]
000070dabbdd38ad  add rsp, 0x30
000070dabbdd38b1  vmovaps xmm0, [rsp]
000070dabbdd38b6  vmovaps xmm1, [rsp+0x10]
000070dabbdd38bc  vmovaps xmm2, [rsp+0x20]
000070dabbdd38c2  vmovaps xmm3, [rsp+0x30]
000070dabbdd38c8  vmovaps xmm4, [rsp+0x40]
000070dabbdd38ce  vmovaps xmm5, [rsp+0x50]
000070dabbdd38d4  vmovaps xmm6, [rsp+0x60]
000070dabbdd38da  vmovaps xmm7, [rsp+0x70]
000070dabbdd38e0  vmovaps xmm8, [rsp+0x80]
000070dabbdd38e9  vmovaps xmm9, [rsp+0x90]
000070dabbdd38f2  vmovaps xmm10, [rsp+0xA0]
000070dabbdd38fb  vmovaps xmm11, [rsp+0xB0]
000070dabbdd3904  vmovaps xmm12, [rsp+0xC0]
000070dabbdd390d  vmovaps xmm13, [rsp+0xD0]
000070dabbdd3916  vmovaps xmm14, [rsp+0xE0]
000070dabbdd391f  add rsp, 0xF0
000070dabbdd3926  pop r11
000070dabbdd3928  pop r10
000070dabbdd392a  pop r9
000070dabbdd392c  pop r8
000070dabbdd392e  pop rsi
000070dabbdd392f  pop rdi
000070dabbdd3930  pop rdx
000070dabbdd3931  pop rcx
000070dabbdd3932  pop rax
000070dabbdd3933  add rsp, 0x08
000070dabbdd3937  jmp 0x000070DABBDCFF55
000070dabbdd393c  call 0x000070DABBC0C260
000070dabbdd3941  jmp 0x000070DABBDCFFB0
000070dabbdd3946  sub rsp, 0x08
000070dabbdd394a  push rax
000070dabbdd394b  push rcx
000070dabbdd394c  push rdx
000070dabbdd394d  push rdi
000070dabbdd394e  push rsi
000070dabbdd394f  push r8
000070dabbdd3951  push r9
000070dabbdd3953  push r10
000070dabbdd3955  push r11
000070dabbdd3957  sub rsp, 0xF0
000070dabbdd395e  vmovaps [rsp], xmm0
000070dabbdd3963  vmovaps [rsp+0x10], xmm1
000070dabbdd3969  vmovaps [rsp+0x20], xmm2
000070dabbdd396f  vmovaps [rsp+0x30], xmm3
000070dabbdd3975  vmovaps [rsp+0x40], xmm4
000070dabbdd397b  vmovaps [rsp+0x50], xmm5
000070dabbdd3981  vmovaps [rsp+0x60], xmm6
000070dabbdd3987  vmovaps [rsp+0x70], xmm7
000070dabbdd398d  vmovaps [rsp+0x80], xmm8
000070dabbdd3996  vmovaps [rsp+0x90], xmm10
000070dabbdd399f  vmovaps [rsp+0xA0], xmm11
000070dabbdd39a8  vmovaps [rsp+0xB0], xmm12
000070dabbdd39b1  vmovaps [rsp+0xC0], xmm13
000070dabbdd39ba  vmovaps [rsp+0xD0], xmm14
000070dabbdd39c3  vmovaps [rsp+0xE0], xmm15
000070dabbdd39cc  sub rsp, 0x30
000070dabbdd39d0  movaps [rsp], xmm9
000070dabbdd39d5  movaps [rsp+0x10], xmm8
000070dabbdd39db  movaps [rsp+0x20], xmm10
000070dabbdd39e1  lea rdi, [rsp]
000070dabbdd39e5  mov esi, 0x00
000070dabbdd39ea  mov rax, 0x5C2CF7B6F530
000070dabbdd39f4  call rax
000070dabbdd39f6  movaps xmm9, [rsp]
000070dabbdd39fb  add rsp, 0x30
000070dabbdd39ff  vmovaps xmm0, [rsp]
000070dabbdd3a04  vmovaps xmm1, [rsp+0x10]
000070dabbdd3a0a  vmovaps xmm2, [rsp+0x20]
000070dabbdd3a10  vmovaps xmm3, [rsp+0x30]
000070dabbdd3a16  vmovaps xmm4, [rsp+0x40]
000070dabbdd3a1c  vmovaps xmm5, [rsp+0x50]
000070dabbdd3a22  vmovaps xmm6, [rsp+0x60]
000070dabbdd3a28  vmovaps xmm7, [rsp+0x70]
000070dabbdd3a2e  vmovaps xmm8, [rsp+0x80]
000070dabbdd3a37  vmovaps xmm10, [rsp+0x90]
000070dabbdd3a40  vmovaps xmm11, [rsp+0xA0]
000070dabbdd3a49  vmovaps xmm12, [rsp+0xB0]
000070dabbdd3a52  vmovaps xmm13, [rsp+0xC0]
000070dabbdd3a5b  vmovaps xmm14, [rsp+0xD0]
000070dabbdd3a64  vmovaps xmm15, [rsp+0xE0]
000070dabbdd3a6d  add rsp, 0xF0
000070dabbdd3a74  pop r11
000070dabbdd3a76  pop r10
000070dabbdd3a78  pop r9
000070dabbdd3a7a  pop r8
000070dabbdd3a7c  pop rsi
000070dabbdd3a7d  pop rdi
000070dabbdd3a7e  pop rdx
000070dabbdd3a7f  pop rcx
000070dabbdd3a80  pop rax
000070dabbdd3a81  add rsp, 0x08
000070dabbdd3a85  jmp 0x000070DABBDCFFE1
000070dabbdd3a8a  sub rsp, 0x08
000070dabbdd3a8e  push rax
000070dabbdd3a8f  push rcx
000070dabbdd3a90  push rdx
000070dabbdd3a91  push rdi
000070dabbdd3a92  push rsi
000070dabbdd3a93  push r8
000070dabbdd3a95  push r9
000070dabbdd3a97  push r10
000070dabbdd3a99  push r11
000070dabbdd3a9b  sub rsp, 0xF0
000070dabbdd3aa2  vmovaps [rsp], xmm0
000070dabbdd3aa7  vmovaps [rsp+0x10], xmm1
000070dabbdd3aad  vmovaps [rsp+0x20], xmm2
000070dabbdd3ab3  vmovaps [rsp+0x30], xmm3
000070dabbdd3ab9  vmovaps [rsp+0x40], xmm4
000070dabbdd3abf  vmovaps [rsp+0x50], xmm5
000070dabbdd3ac5  vmovaps [rsp+0x60], xmm6
000070dabbdd3acb  vmovaps [rsp+0x70], xmm7
000070dabbdd3ad1  vmovaps [rsp+0x80], xmm8
000070dabbdd3ada  vmovaps [rsp+0x90], xmm9
000070dabbdd3ae3  vmovaps [rsp+0xA0], xmm11
000070dabbdd3aec  vmovaps [rsp+0xB0], xmm12
000070dabbdd3af5  vmovaps [rsp+0xC0], xmm13
000070dabbdd3afe  vmovaps [rsp+0xD0], xmm14
000070dabbdd3b07  vmovaps [rsp+0xE0], xmm15
000070dabbdd3b10  sub rsp, 0x30
000070dabbdd3b14  movaps [rsp], xmm10
000070dabbdd3b19  movaps [rsp+0x10], xmm1
000070dabbdd3b1e  movaps [rsp+0x20], xmm11
000070dabbdd3b24  lea rdi, [rsp]
000070dabbdd3b28  mov esi, 0x00
000070dabbdd3b2d  mov rax, 0x5C2CF7B6F530
000070dabbdd3b37  call rax
000070dabbdd3b39  movaps xmm10, [rsp]
000070dabbdd3b3e  add rsp, 0x30
000070dabbdd3b42  vmovaps xmm0, [rsp]
000070dabbdd3b47  vmovaps xmm1, [rsp+0x10]
000070dabbdd3b4d  vmovaps xmm2, [rsp+0x20]
000070dabbdd3b53  vmovaps xmm3, [rsp+0x30]
000070dabbdd3b59  vmovaps xmm4, [rsp+0x40]
000070dabbdd3b5f  vmovaps xmm5, [rsp+0x50]
000070dabbdd3b65  vmovaps xmm6, [rsp+0x60]
000070dabbdd3b6b  vmovaps xmm7, [rsp+0x70]
000070dabbdd3b71  vmovaps xmm8, [rsp+0x80]
000070dabbdd3b7a  vmovaps xmm9, [rsp+0x90]
000070dabbdd3b83  vmovaps xmm11, [rsp+0xA0]
000070dabbdd3b8c  vmovaps xmm12, [rsp+0xB0]
000070dabbdd3b95  vmovaps xmm13, [rsp+0xC0]
000070dabbdd3b9e  vmovaps xmm14, [rsp+0xD0]
000070dabbdd3ba7  vmovaps xmm15, [rsp+0xE0]
000070dabbdd3bb0  add rsp, 0xF0
000070dabbdd3bb7  pop r11
000070dabbdd3bb9  pop r10
000070dabbdd3bbb  pop r9
000070dabbdd3bbd  pop r8
000070dabbdd3bbf  pop rsi
000070dabbdd3bc0  pop rdi
000070dabbdd3bc1  pop rdx
000070dabbdd3bc2  pop rcx
000070dabbdd3bc3  pop rax
000070dabbdd3bc4  add rsp, 0x08
000070dabbdd3bc8  jmp 0x000070DABBDCFFFC
000070dabbdd3bcd  sub rsp, 0x08
000070dabbdd3bd1  push rax
000070dabbdd3bd2  push rcx
000070dabbdd3bd3  push rdx
000070dabbdd3bd4  push rdi
000070dabbdd3bd5  push rsi
000070dabbdd3bd6  push r8
000070dabbdd3bd8  push r9
000070dabbdd3bda  push r10
000070dabbdd3bdc  push r11
000070dabbdd3bde  sub rsp, 0xF0
000070dabbdd3be5  vmovaps [rsp], xmm0
000070dabbdd3bea  vmovaps [rsp+0x10], xmm2
000070dabbdd3bf0  vmovaps [rsp+0x20], xmm3
000070dabbdd3bf6  vmovaps [rsp+0x30], xmm4
000070dabbdd3bfc  vmovaps [rsp+0x40], xmm5
000070dabbdd3c02  vmovaps [rsp+0x50], xmm6
000070dabbdd3c08  vmovaps [rsp+0x60], xmm7
000070dabbdd3c0e  vmovaps [rsp+0x70], xmm8
000070dabbdd3c14  vmovaps [rsp+0x80], xmm9
000070dabbdd3c1d  vmovaps [rsp+0x90], xmm10
000070dabbdd3c26  vmovaps [rsp+0xA0], xmm11
000070dabbdd3c2f  vmovaps [rsp+0xB0], xmm12
000070dabbdd3c38  vmovaps [rsp+0xC0], xmm13
000070dabbdd3c41  vmovaps [rsp+0xD0], xmm14
000070dabbdd3c4a  vmovaps [rsp+0xE0], xmm15
000070dabbdd3c53  sub rsp, 0x30
000070dabbdd3c57  movaps [rsp], xmm1
000070dabbdd3c5b  movaps [rsp+0x10], xmm14
000070dabbdd3c61  movaps [rsp+0x20], xmm6
000070dabbdd3c66  lea rdi, [rsp]
000070dabbdd3c6a  mov esi, 0x00
000070dabbdd3c6f  mov rax, 0x5C2CF7B6F530
000070dabbdd3c79  call rax
000070dabbdd3c7b  movaps xmm1, [rsp]
000070dabbdd3c7f  add rsp, 0x30
000070dabbdd3c83  vmovaps xmm0, [rsp]
000070dabbdd3c88  vmovaps xmm2, [rsp+0x10]
000070dabbdd3c8e  vmovaps xmm3, [rsp+0x20]
000070dabbdd3c94  vmovaps xmm4, [rsp+0x30]
000070dabbdd3c9a  vmovaps xmm5, [rsp+0x40]
000070dabbdd3ca0  vmovaps xmm6, [rsp+0x50]
000070dabbdd3ca6  vmovaps xmm7, [rsp+0x60]
000070dabbdd3cac  vmovaps xmm8, [rsp+0x70]
000070dabbdd3cb2  vmovaps xmm9, [rsp+0x80]
000070dabbdd3cbb  vmovaps xmm10, [rsp+0x90]
000070dabbdd3cc4  vmovaps xmm11, [rsp+0xA0]
000070dabbdd3ccd  vmovaps xmm12, [rsp+0xB0]
000070dabbdd3cd6  vmovaps xmm13, [rsp+0xC0]
000070dabbdd3cdf  vmovaps xmm14, [rsp+0xD0]
000070dabbdd3ce8  vmovaps xmm15, [rsp+0xE0]
000070dabbdd3cf1  add rsp, 0xF0
000070dabbdd3cf8  pop r11
000070dabbdd3cfa  pop r10
000070dabbdd3cfc  pop r9
000070dabbdd3cfe  pop r8
000070dabbdd3d00  pop rsi
000070dabbdd3d01  pop rdi
000070dabbdd3d02  pop rdx
000070dabbdd3d03  pop rcx
000070dabbdd3d04  pop rax
000070dabbdd3d05  add rsp, 0x08
000070dabbdd3d09  jmp 0x000070DABBDD0015
000070dabbdd3d0e  sub rsp, 0x08
000070dabbdd3d12  push rax
000070dabbdd3d13  push rcx
000070dabbdd3d14  push rdx
000070dabbdd3d15  push rdi
000070dabbdd3d16  push rsi
000070dabbdd3d17  push r8
000070dabbdd3d19  push r9
000070dabbdd3d1b  push r10
000070dabbdd3d1d  push r11
000070dabbdd3d1f  sub rsp, 0xF0
000070dabbdd3d26  vmovaps [rsp], xmm0
000070dabbdd3d2b  vmovaps [rsp+0x10], xmm1
000070dabbdd3d31  vmovaps [rsp+0x20], xmm2
000070dabbdd3d37  vmovaps [rsp+0x30], xmm3
000070dabbdd3d3d  vmovaps [rsp+0x40], xmm4
000070dabbdd3d43  vmovaps [rsp+0x50], xmm5
000070dabbdd3d49  vmovaps [rsp+0x60], xmm6
000070dabbdd3d4f  vmovaps [rsp+0x70], xmm7
000070dabbdd3d55  vmovaps [rsp+0x80], xmm8
000070dabbdd3d5e  vmovaps [rsp+0x90], xmm9
000070dabbdd3d67  vmovaps [rsp+0xA0], xmm10
000070dabbdd3d70  vmovaps [rsp+0xB0], xmm12
000070dabbdd3d79  vmovaps [rsp+0xC0], xmm13
000070dabbdd3d82  vmovaps [rsp+0xD0], xmm14
000070dabbdd3d8b  vmovaps [rsp+0xE0], xmm15
000070dabbdd3d94  sub rsp, 0x30
000070dabbdd3d98  movaps [rsp], xmm11
000070dabbdd3d9d  movaps [rsp+0x10], xmm13
000070dabbdd3da3  movaps [rsp+0x20], xmm14
000070dabbdd3da9  lea rdi, [rsp]
000070dabbdd3dad  mov esi, 0x00
000070dabbdd3db2  mov rax, 0x5C2CF7B6F530
000070dabbdd3dbc  call rax
000070dabbdd3dbe  movaps xmm11, [rsp]
000070dabbdd3dc3  add rsp, 0x30
000070dabbdd3dc7  vmovaps xmm0, [rsp]
000070dabbdd3dcc  vmovaps xmm1, [rsp+0x10]
000070dabbdd3dd2  vmovaps xmm2, [rsp+0x20]
000070dabbdd3dd8  vmovaps xmm3, [rsp+0x30]
000070dabbdd3dde  vmovaps xmm4, [rsp+0x40]
000070dabbdd3de4  vmovaps xmm5, [rsp+0x50]
000070dabbdd3dea  vmovaps xmm6, [rsp+0x60]
000070dabbdd3df0  vmovaps xmm7, [rsp+0x70]
000070dabbdd3df6  vmovaps xmm8, [rsp+0x80]
000070dabbdd3dff  vmovaps xmm9, [rsp+0x90]
000070dabbdd3e08  vmovaps xmm10, [rsp+0xA0]
000070dabbdd3e11  vmovaps xmm12, [rsp+0xB0]
000070dabbdd3e1a  vmovaps xmm13, [rsp+0xC0]
000070dabbdd3e23  vmovaps xmm14, [rsp+0xD0]
000070dabbdd3e2c  vmovaps xmm15, [rsp+0xE0]
000070dabbdd3e35  add rsp, 0xF0
000070dabbdd3e3c  pop r11
000070dabbdd3e3e  pop r10
000070dabbdd3e40  pop r9
000070dabbdd3e42  pop r8
000070dabbdd3e44  pop rsi
000070dabbdd3e45  pop rdi
000070dabbdd3e46  pop rdx
000070dabbdd3e47  pop rcx
000070dabbdd3e48  pop rax
000070dabbdd3e49  add rsp, 0x08
000070dabbdd3e4d  jmp 0x000070DABBDD003F
000070dabbdd3e52  sub rsp, 0x08
000070dabbdd3e56  push rax
000070dabbdd3e57  push rcx
000070dabbdd3e58  push rdx
000070dabbdd3e59  push rdi
000070dabbdd3e5a  push rsi
000070dabbdd3e5b  push r8
000070dabbdd3e5d  push r9
000070dabbdd3e5f  push r10
000070dabbdd3e61  push r11
000070dabbdd3e63  sub rsp, 0xF0
000070dabbdd3e6a  vmovaps [rsp], xmm0
000070dabbdd3e6f  vmovaps [rsp+0x10], xmm1
000070dabbdd3e75  vmovaps [rsp+0x20], xmm2
000070dabbdd3e7b  vmovaps [rsp+0x30], xmm3
000070dabbdd3e81  vmovaps [rsp+0x40], xmm4
000070dabbdd3e87  vmovaps [rsp+0x50], xmm5
000070dabbdd3e8d  vmovaps [rsp+0x60], xmm6
000070dabbdd3e93  vmovaps [rsp+0x70], xmm7
000070dabbdd3e99  vmovaps [rsp+0x80], xmm8
000070dabbdd3ea2  vmovaps [rsp+0x90], xmm9
000070dabbdd3eab  vmovaps [rsp+0xA0], xmm10
000070dabbdd3eb4  vmovaps [rsp+0xB0], xmm11
000070dabbdd3ebd  vmovaps [rsp+0xC0], xmm12
000070dabbdd3ec6  vmovaps [rsp+0xD0], xmm14
000070dabbdd3ecf  vmovaps [rsp+0xE0], xmm15
000070dabbdd3ed8  sub rsp, 0x30
000070dabbdd3edc  movaps [rsp], xmm13
000070dabbdd3ee1  movaps [rsp+0x10], xmm8
000070dabbdd3ee7  movaps [rsp+0x20], xmm14
000070dabbdd3eed  lea rdi, [rsp]
000070dabbdd3ef1  mov esi, 0x00
000070dabbdd3ef6  mov rax, 0x5C2CF7B6F530
000070dabbdd3f00  call rax
000070dabbdd3f02  movaps xmm13, [rsp]
000070dabbdd3f07  add rsp, 0x30
000070dabbdd3f0b  vmovaps xmm0, [rsp]
000070dabbdd3f10  vmovaps xmm1, [rsp+0x10]
000070dabbdd3f16  vmovaps xmm2, [rsp+0x20]
000070dabbdd3f1c  vmovaps xmm3, [rsp+0x30]
000070dabbdd3f22  vmovaps xmm4, [rsp+0x40]
000070dabbdd3f28  vmovaps xmm5, [rsp+0x50]
000070dabbdd3f2e  vmovaps xmm6, [rsp+0x60]
000070dabbdd3f34  vmovaps xmm7, [rsp+0x70]
000070dabbdd3f3a  vmovaps xmm8, [rsp+0x80]
000070dabbdd3f43  vmovaps xmm9, [rsp+0x90]
000070dabbdd3f4c  vmovaps xmm10, [rsp+0xA0]
000070dabbdd3f55  vmovaps xmm11, [rsp+0xB0]
000070dabbdd3f5e  vmovaps xmm12, [rsp+0xC0]
000070dabbdd3f67  vmovaps xmm14, [rsp+0xD0]
000070dabbdd3f70  vmovaps xmm15, [rsp+0xE0]
000070dabbdd3f79  add rsp, 0xF0
000070dabbdd3f80  pop r11
000070dabbdd3f82  pop r10
000070dabbdd3f84  pop r9
000070dabbdd3f86  pop r8
000070dabbdd3f88  pop rsi
000070dabbdd3f89  pop rdi
000070dabbdd3f8a  pop rdx
000070dabbdd3f8b  pop rcx
000070dabbdd3f8c  pop rax
000070dabbdd3f8d  add rsp, 0x08
000070dabbdd3f91  jmp 0x000070DABBDD006E
000070dabbdd3f96  sub rsp, 0x08
000070dabbdd3f9a  push rax
000070dabbdd3f9b  push rcx
000070dabbdd3f9c  push rdx
000070dabbdd3f9d  push rdi
000070dabbdd3f9e  push rsi
000070dabbdd3f9f  push r8
000070dabbdd3fa1  push r9
000070dabbdd3fa3  push r10
000070dabbdd3fa5  push r11
000070dabbdd3fa7  sub rsp, 0xF0
000070dabbdd3fae  vmovaps [rsp], xmm0
000070dabbdd3fb3  vmovaps [rsp+0x10], xmm1
000070dabbdd3fb9  vmovaps [rsp+0x20], xmm2
000070dabbdd3fbf  vmovaps [rsp+0x30], xmm3
000070dabbdd3fc5  vmovaps [rsp+0x40], xmm4
000070dabbdd3fcb  vmovaps [rsp+0x50], xmm5
000070dabbdd3fd1  vmovaps [rsp+0x60], xmm6
000070dabbdd3fd7  vmovaps [rsp+0x70], xmm7
000070dabbdd3fdd  vmovaps [rsp+0x80], xmm9
000070dabbdd3fe6  vmovaps [rsp+0x90], xmm10
000070dabbdd3fef  vmovaps [rsp+0xA0], xmm11
000070dabbdd3ff8  vmovaps [rsp+0xB0], xmm12
000070dabbdd4001  vmovaps [rsp+0xC0], xmm13
000070dabbdd400a  vmovaps [rsp+0xD0], xmm14
000070dabbdd4013  vmovaps [rsp+0xE0], xmm15
000070dabbdd401c  sub rsp, 0x30
000070dabbdd4020  movaps [rsp], xmm8
000070dabbdd4025  movaps [rsp+0x10], xmm7
000070dabbdd402a  movaps [rsp+0x20], xmm14
000070dabbdd4030  lea rdi, [rsp]
000070dabbdd4034  mov esi, 0x00
000070dabbdd4039  mov rax, 0x5C2CF7B6F530
000070dabbdd4043  call rax
000070dabbdd4045  movaps xmm8, [rsp]
000070dabbdd404a  add rsp, 0x30
000070dabbdd404e  vmovaps xmm0, [rsp]
000070dabbdd4053  vmovaps xmm1, [rsp+0x10]
000070dabbdd4059  vmovaps xmm2, [rsp+0x20]
000070dabbdd405f  vmovaps xmm3, [rsp+0x30]
000070dabbdd4065  vmovaps xmm4, [rsp+0x40]
000070dabbdd406b  vmovaps xmm5, [rsp+0x50]
000070dabbdd4071  vmovaps xmm6, [rsp+0x60]
000070dabbdd4077  vmovaps xmm7, [rsp+0x70]
000070dabbdd407d  vmovaps xmm9, [rsp+0x80]
000070dabbdd4086  vmovaps xmm10, [rsp+0x90]
000070dabbdd408f  vmovaps xmm11, [rsp+0xA0]
000070dabbdd4098  vmovaps xmm12, [rsp+0xB0]
000070dabbdd40a1  vmovaps xmm13, [rsp+0xC0]
000070dabbdd40aa  vmovaps xmm14, [rsp+0xD0]
000070dabbdd40b3  vmovaps xmm15, [rsp+0xE0]
000070dabbdd40bc  add rsp, 0xF0
000070dabbdd40c3  pop r11
000070dabbdd40c5  pop r10
000070dabbdd40c7  pop r9
000070dabbdd40c9  pop r8
000070dabbdd40cb  pop rsi
000070dabbdd40cc  pop rdi
000070dabbdd40cd  pop rdx
000070dabbdd40ce  pop rcx
000070dabbdd40cf  pop rax
000070dabbdd40d0  add rsp, 0x08
000070dabbdd40d4  jmp 0x000070DABBDD0094
000070dabbdd40d9  sub rsp, 0x08
000070dabbdd40dd  push rax
000070dabbdd40de  push rcx
000070dabbdd40df  push rdx
000070dabbdd40e0  push rdi
000070dabbdd40e1  push rsi
000070dabbdd40e2  push r8
000070dabbdd40e4  push r9
000070dabbdd40e6  push r10
000070dabbdd40e8  push r11
000070dabbdd40ea  sub rsp, 0xF0
000070dabbdd40f1  vmovaps [rsp], xmm0
000070dabbdd40f6  vmovaps [rsp+0x10], xmm1
000070dabbdd40fc  vmovaps [rsp+0x20], xmm2
000070dabbdd4102  vmovaps [rsp+0x30], xmm3
000070dabbdd4108  vmovaps [rsp+0x40], xmm4
000070dabbdd410e  vmovaps [rsp+0x50], xmm5
000070dabbdd4114  vmovaps [rsp+0x60], xmm6
000070dabbdd411a  vmovaps [rsp+0x70], xmm7
000070dabbdd4120  vmovaps [rsp+0x80], xmm8
000070dabbdd4129  vmovaps [rsp+0x90], xmm9
000070dabbdd4132  vmovaps [rsp+0xA0], xmm10
000070dabbdd413b  vmovaps [rsp+0xB0], xmm11
000070dabbdd4144  vmovaps [rsp+0xC0], xmm12
000070dabbdd414d  vmovaps [rsp+0xD0], xmm13
000070dabbdd4156  vmovaps [rsp+0xE0], xmm15
000070dabbdd415f  sub rsp, 0x30
000070dabbdd4163  movaps [rsp], xmm14
000070dabbdd4168  movaps [rsp+0x10], xmm12
000070dabbdd416e  movaps [rsp+0x20], xmm9
000070dabbdd4174  lea rdi, [rsp]
000070dabbdd4178  mov esi, 0x00
000070dabbdd417d  mov rax, 0x5C2CF7B6F530
000070dabbdd4187  call rax
000070dabbdd4189  movaps xmm14, [rsp]
000070dabbdd418e  add rsp, 0x30
000070dabbdd4192  vmovaps xmm0, [rsp]
000070dabbdd4197  vmovaps xmm1, [rsp+0x10]
000070dabbdd419d  vmovaps xmm2, [rsp+0x20]
000070dabbdd41a3  vmovaps xmm3, [rsp+0x30]
000070dabbdd41a9  vmovaps xmm4, [rsp+0x40]
000070dabbdd41af  vmovaps xmm5, [rsp+0x50]
000070dabbdd41b5  vmovaps xmm6, [rsp+0x60]
000070dabbdd41bb  vmovaps xmm7, [rsp+0x70]
000070dabbdd41c1  vmovaps xmm8, [rsp+0x80]
000070dabbdd41ca  vmovaps xmm9, [rsp+0x90]
000070dabbdd41d3  vmovaps xmm10, [rsp+0xA0]
000070dabbdd41dc  vmovaps xmm11, [rsp+0xB0]
000070dabbdd41e5  vmovaps xmm12, [rsp+0xC0]
000070dabbdd41ee  vmovaps xmm13, [rsp+0xD0]
000070dabbdd41f7  vmovaps xmm15, [rsp+0xE0]
000070dabbdd4200  add rsp, 0xF0
000070dabbdd4207  pop r11
000070dabbdd4209  pop r10
000070dabbdd420b  pop r9
000070dabbdd420d  pop r8
000070dabbdd420f  pop rsi
000070dabbdd4210  pop rdi
000070dabbdd4211  pop rdx
000070dabbdd4212  pop rcx
000070dabbdd4213  pop rax
000070dabbdd4214  add rsp, 0x08
000070dabbdd4218  jmp 0x000070DABBDD00AE
000070dabbdd421d  sub rsp, 0x08
000070dabbdd4221  push rax
000070dabbdd4222  push rcx
000070dabbdd4223  push rdx
000070dabbdd4224  push rdi
000070dabbdd4225  push rsi
000070dabbdd4226  push r8
000070dabbdd4228  push r9
000070dabbdd422a  push r10
000070dabbdd422c  push r11
000070dabbdd422e  sub rsp, 0xF0
000070dabbdd4235  vmovaps [rsp], xmm0
000070dabbdd423a  vmovaps [rsp+0x10], xmm1
000070dabbdd4240  vmovaps [rsp+0x20], xmm2
000070dabbdd4246  vmovaps [rsp+0x30], xmm3
000070dabbdd424c  vmovaps [rsp+0x40], xmm4
000070dabbdd4252  vmovaps [rsp+0x50], xmm5
000070dabbdd4258  vmovaps [rsp+0x60], xmm6
000070dabbdd425e  vmovaps [rsp+0x70], xmm7
000070dabbdd4264  vmovaps [rsp+0x80], xmm8
000070dabbdd426d  vmovaps [rsp+0x90], xmm10
000070dabbdd4276  vmovaps [rsp+0xA0], xmm11
000070dabbdd427f  vmovaps [rsp+0xB0], xmm12
000070dabbdd4288  vmovaps [rsp+0xC0], xmm13
000070dabbdd4291  vmovaps [rsp+0xD0], xmm14
000070dabbdd429a  vmovaps [rsp+0xE0], xmm15
000070dabbdd42a3  sub rsp, 0x30
000070dabbdd42a7  movaps [rsp], xmm9
000070dabbdd42ac  movaps [rsp+0x10], xmm7
000070dabbdd42b1  movaps [rsp+0x20], xmm12
000070dabbdd42b7  lea rdi, [rsp]
000070dabbdd42bb  mov esi, 0x00
000070dabbdd42c0  mov rax, 0x5C2CF7B6F530
000070dabbdd42ca  call rax
000070dabbdd42cc  movaps xmm9, [rsp]
000070dabbdd42d1  add rsp, 0x30
000070dabbdd42d5  vmovaps xmm0, [rsp]
000070dabbdd42da  vmovaps xmm1, [rsp+0x10]
000070dabbdd42e0  vmovaps xmm2, [rsp+0x20]
000070dabbdd42e6  vmovaps xmm3, [rsp+0x30]
000070dabbdd42ec  vmovaps xmm4, [rsp+0x40]
000070dabbdd42f2  vmovaps xmm5, [rsp+0x50]
000070dabbdd42f8  vmovaps xmm6, [rsp+0x60]
000070dabbdd42fe  vmovaps xmm7, [rsp+0x70]
000070dabbdd4304  vmovaps xmm8, [rsp+0x80]
000070dabbdd430d  vmovaps xmm10, [rsp+0x90]
000070dabbdd4316  vmovaps xmm11, [rsp+0xA0]
000070dabbdd431f  vmovaps xmm12, [rsp+0xB0]
000070dabbdd4328  vmovaps xmm13, [rsp+0xC0]
000070dabbdd4331  vmovaps xmm14, [rsp+0xD0]
000070dabbdd433a  vmovaps xmm15, [rsp+0xE0]
000070dabbdd4343  add rsp, 0xF0
000070dabbdd434a  pop r11
000070dabbdd434c  pop r10
000070dabbdd434e  pop r9
000070dabbdd4350  pop r8
000070dabbdd4352  pop rsi
000070dabbdd4353  pop rdi
000070dabbdd4354  pop rdx
000070dabbdd4355  pop rcx
000070dabbdd4356  pop rax
000070dabbdd4357  add rsp, 0x08
000070dabbdd435b  jmp 0x000070DABBDD00DD
000070dabbdd4360  sub rsp, 0x08
000070dabbdd4364  push rax
000070dabbdd4365  push rcx
000070dabbdd4366  push rdx
000070dabbdd4367  push rdi
000070dabbdd4368  push rsi
000070dabbdd4369  push r8
000070dabbdd436b  push r9
000070dabbdd436d  push r10
000070dabbdd436f  push r11
000070dabbdd4371  sub rsp, 0xF0
000070dabbdd4378  vmovaps [rsp], xmm0
000070dabbdd437d  vmovaps [rsp+0x10], xmm1
000070dabbdd4383  vmovaps [rsp+0x20], xmm2
000070dabbdd4389  vmovaps [rsp+0x30], xmm3
000070dabbdd438f  vmovaps [rsp+0x40], xmm4
000070dabbdd4395  vmovaps [rsp+0x50], xmm5
000070dabbdd439b  vmovaps [rsp+0x60], xmm6
000070dabbdd43a1  vmovaps [rsp+0x70], xmm7
000070dabbdd43a7  vmovaps [rsp+0x80], xmm8
000070dabbdd43b0  vmovaps [rsp+0x90], xmm9
000070dabbdd43b9  vmovaps [rsp+0xA0], xmm10
000070dabbdd43c2  vmovaps [rsp+0xB0], xmm11
000070dabbdd43cb  vmovaps [rsp+0xC0], xmm13
000070dabbdd43d4  vmovaps [rsp+0xD0], xmm14
000070dabbdd43dd  vmovaps [rsp+0xE0], xmm15
000070dabbdd43e6  sub rsp, 0x30
000070dabbdd43ea  movaps [rsp], xmm12
000070dabbdd43ef  movaps [rsp+0x10], xmm15
000070dabbdd43f5  movaps [rsp+0x20], xmm11
000070dabbdd43fb  lea rdi, [rsp]
000070dabbdd43ff  mov esi, 0x00
000070dabbdd4404  mov rax, 0x5C2CF7B6F530
000070dabbdd440e  call rax
000070dabbdd4410  movaps xmm12, [rsp]
000070dabbdd4415  add rsp, 0x30
000070dabbdd4419  vmovaps xmm0, [rsp]
000070dabbdd441e  vmovaps xmm1, [rsp+0x10]
000070dabbdd4424  vmovaps xmm2, [rsp+0x20]
000070dabbdd442a  vmovaps xmm3, [rsp+0x30]
000070dabbdd4430  vmovaps xmm4, [rsp+0x40]
000070dabbdd4436  vmovaps xmm5, [rsp+0x50]
000070dabbdd443c  vmovaps xmm6, [rsp+0x60]
000070dabbdd4442  vmovaps xmm7, [rsp+0x70]
000070dabbdd4448  vmovaps xmm8, [rsp+0x80]
000070dabbdd4451  vmovaps xmm9, [rsp+0x90]
000070dabbdd445a  vmovaps xmm10, [rsp+0xA0]
000070dabbdd4463  vmovaps xmm11, [rsp+0xB0]
000070dabbdd446c  vmovaps xmm13, [rsp+0xC0]
000070dabbdd4475  vmovaps xmm14, [rsp+0xD0]
000070dabbdd447e  vmovaps xmm15, [rsp+0xE0]
000070dabbdd4487  add rsp, 0xF0
000070dabbdd448e  pop r11
000070dabbdd4490  pop r10
000070dabbdd4492  pop r9
000070dabbdd4494  pop r8
000070dabbdd4496  pop rsi
000070dabbdd4497  pop rdi
000070dabbdd4498  pop rdx
000070dabbdd4499  pop rcx
000070dabbdd449a  pop rax
000070dabbdd449b  add rsp, 0x08
000070dabbdd449f  jmp 0x000070DABBDD00F7
000070dabbdd44a4  sub rsp, 0x08
000070dabbdd44a8  push rax
000070dabbdd44a9  push rcx
000070dabbdd44aa  push rdx
000070dabbdd44ab  push rdi
000070dabbdd44ac  push rsi
000070dabbdd44ad  push r8
000070dabbdd44af  push r9
000070dabbdd44b1  push r10
000070dabbdd44b3  push r11
000070dabbdd44b5  sub rsp, 0xF0
000070dabbdd44bc  vmovaps [rsp], xmm0
000070dabbdd44c1  vmovaps [rsp+0x10], xmm1
000070dabbdd44c7  vmovaps [rsp+0x20], xmm2
000070dabbdd44cd  vmovaps [rsp+0x30], xmm3
000070dabbdd44d3  vmovaps [rsp+0x40], xmm4
000070dabbdd44d9  vmovaps [rsp+0x50], xmm5
000070dabbdd44df  vmovaps [rsp+0x60], xmm6
000070dabbdd44e5  vmovaps [rsp+0x70], xmm7
000070dabbdd44eb  vmovaps [rsp+0x80], xmm8
000070dabbdd44f4  vmovaps [rsp+0x90], xmm9
000070dabbdd44fd  vmovaps [rsp+0xA0], xmm10
000070dabbdd4506  vmovaps [rsp+0xB0], xmm12
000070dabbdd450f  vmovaps [rsp+0xC0], xmm13
000070dabbdd4518  vmovaps [rsp+0xD0], xmm14
000070dabbdd4521  vmovaps [rsp+0xE0], xmm15
000070dabbdd452a  sub rsp, 0x30
000070dabbdd452e  movaps [rsp], xmm11
000070dabbdd4533  movaps [rsp+0x10], xmm7
000070dabbdd4538  movaps [rsp+0x20], xmm15
000070dabbdd453e  lea rdi, [rsp]
000070dabbdd4542  mov esi, 0x00
000070dabbdd4547  mov rax, 0x5C2CF7B6F530
000070dabbdd4551  call rax
000070dabbdd4553  movaps xmm11, [rsp]
000070dabbdd4558  add rsp, 0x30
000070dabbdd455c  vmovaps xmm0, [rsp]
000070dabbdd4561  vmovaps xmm1, [rsp+0x10]
000070dabbdd4567  vmovaps xmm2, [rsp+0x20]
000070dabbdd456d  vmovaps xmm3, [rsp+0x30]
000070dabbdd4573  vmovaps xmm4, [rsp+0x40]
000070dabbdd4579  vmovaps xmm5, [rsp+0x50]
000070dabbdd457f  vmovaps xmm6, [rsp+0x60]
000070dabbdd4585  vmovaps xmm7, [rsp+0x70]
000070dabbdd458b  vmovaps xmm8, [rsp+0x80]
000070dabbdd4594  vmovaps xmm9, [rsp+0x90]
000070dabbdd459d  vmovaps xmm10, [rsp+0xA0]
000070dabbdd45a6  vmovaps xmm12, [rsp+0xB0]
000070dabbdd45af  vmovaps xmm13, [rsp+0xC0]
000070dabbdd45b8  vmovaps xmm14, [rsp+0xD0]
000070dabbdd45c1  vmovaps xmm15, [rsp+0xE0]
000070dabbdd45ca  add rsp, 0xF0
000070dabbdd45d1  pop r11
000070dabbdd45d3  pop r10
000070dabbdd45d5  pop r9
000070dabbdd45d7  pop r8
000070dabbdd45d9  pop rsi
000070dabbdd45da  pop rdi
000070dabbdd45db  pop rdx
000070dabbdd45dc  pop rcx
000070dabbdd45dd  pop rax
000070dabbdd45de  add rsp, 0x08
000070dabbdd45e2  jmp 0x000070DABBDD0123
000070dabbdd45e7  sub rsp, 0x08
000070dabbdd45eb  push rax
000070dabbdd45ec  push rcx
000070dabbdd45ed  push rdx
000070dabbdd45ee  push rdi
000070dabbdd45ef  push rsi
000070dabbdd45f0  push r8
000070dabbdd45f2  push r9
000070dabbdd45f4  push r10
000070dabbdd45f6  push r11
000070dabbdd45f8  sub rsp, 0xF0
000070dabbdd45ff  vmovaps [rsp], xmm0
000070dabbdd4604  vmovaps [rsp+0x10], xmm1
000070dabbdd460a  vmovaps [rsp+0x20], xmm2
000070dabbdd4610  vmovaps [rsp+0x30], xmm3
000070dabbdd4616  vmovaps [rsp+0x40], xmm4
000070dabbdd461c  vmovaps [rsp+0x50], xmm5
000070dabbdd4622  vmovaps [rsp+0x60], xmm6
000070dabbdd4628  vmovaps [rsp+0x70], xmm7
000070dabbdd462e  vmovaps [rsp+0x80], xmm8
000070dabbdd4637  vmovaps [rsp+0x90], xmm9
000070dabbdd4640  vmovaps [rsp+0xA0], xmm10
000070dabbdd4649  vmovaps [rsp+0xB0], xmm11
000070dabbdd4652  vmovaps [rsp+0xC0], xmm12
000070dabbdd465b  vmovaps [rsp+0xD0], xmm13
000070dabbdd4664  vmovaps [rsp+0xE0], xmm14
000070dabbdd466d  sub rsp, 0x30
000070dabbdd4671  movaps [rsp], xmm15
000070dabbdd4676  movaps [rsp+0x10], xmm10
000070dabbdd467c  movaps [rsp+0x20], xmm13
000070dabbdd4682  lea rdi, [rsp]
000070dabbdd4686  mov esi, 0x00
000070dabbdd468b  mov rax, 0x5C2CF7B6F530
000070dabbdd4695  call rax
000070dabbdd4697  movaps xmm15, [rsp]
000070dabbdd469c  add rsp, 0x30
000070dabbdd46a0  vmovaps xmm0, [rsp]
000070dabbdd46a5  vmovaps xmm1, [rsp+0x10]
000070dabbdd46ab  vmovaps xmm2, [rsp+0x20]
000070dabbdd46b1  vmovaps xmm3, [rsp+0x30]
000070dabbdd46b7  vmovaps xmm4, [rsp+0x40]
000070dabbdd46bd  vmovaps xmm5, [rsp+0x50]
000070dabbdd46c3  vmovaps xmm6, [rsp+0x60]
000070dabbdd46c9  vmovaps xmm7, [rsp+0x70]
000070dabbdd46cf  vmovaps xmm8, [rsp+0x80]
000070dabbdd46d8  vmovaps xmm9, [rsp+0x90]
000070dabbdd46e1  vmovaps xmm10, [rsp+0xA0]
000070dabbdd46ea  vmovaps xmm11, [rsp+0xB0]
000070dabbdd46f3  vmovaps xmm12, [rsp+0xC0]
000070dabbdd46fc  vmovaps xmm13, [rsp+0xD0]
000070dabbdd4705  vmovaps xmm14, [rsp+0xE0]
000070dabbdd470e  add rsp, 0xF0
000070dabbdd4715  pop r11
000070dabbdd4717  pop r10
000070dabbdd4719  pop r9
000070dabbdd471b  pop r8
000070dabbdd471d  pop rsi
000070dabbdd471e  pop rdi
000070dabbdd471f  pop rdx
000070dabbdd4720  pop rcx
000070dabbdd4721  pop rax
000070dabbdd4722  add rsp, 0x08
000070dabbdd4726  jmp 0x000070DABBDD013D
000070dabbdd472b  sub rsp, 0x08
000070dabbdd472f  push rax
000070dabbdd4730  push rcx
000070dabbdd4731  push rdx
000070dabbdd4732  push rdi
000070dabbdd4733  push rsi
000070dabbdd4734  push r8
000070dabbdd4736  push r9
000070dabbdd4738  push r10
000070dabbdd473a  push r11
000070dabbdd473c  sub rsp, 0xF0
000070dabbdd4743  vmovaps [rsp], xmm0
000070dabbdd4748  vmovaps [rsp+0x10], xmm1
000070dabbdd474e  vmovaps [rsp+0x20], xmm2
000070dabbdd4754  vmovaps [rsp+0x30], xmm3
000070dabbdd475a  vmovaps [rsp+0x40], xmm4
000070dabbdd4760  vmovaps [rsp+0x50], xmm5
000070dabbdd4766  vmovaps [rsp+0x60], xmm6
000070dabbdd476c  vmovaps [rsp+0x70], xmm7
000070dabbdd4772  vmovaps [rsp+0x80], xmm8
000070dabbdd477b  vmovaps [rsp+0x90], xmm9
000070dabbdd4784  vmovaps [rsp+0xA0], xmm11
000070dabbdd478d  vmovaps [rsp+0xB0], xmm12
000070dabbdd4796  vmovaps [rsp+0xC0], xmm13
000070dabbdd479f  vmovaps [rsp+0xD0], xmm14
000070dabbdd47a8  vmovaps [rsp+0xE0], xmm15
000070dabbdd47b1  sub rsp, 0x30
000070dabbdd47b5  movaps [rsp], xmm10
000070dabbdd47ba  movaps [rsp+0x10], xmm7
000070dabbdd47bf  movaps [rsp+0x20], xmm13
000070dabbdd47c5  lea rdi, [rsp]
000070dabbdd47c9  mov esi, 0x00
000070dabbdd47ce  mov rax, 0x5C2CF7B6F530
000070dabbdd47d8  call rax
000070dabbdd47da  movaps xmm10, [rsp]
000070dabbdd47df  add rsp, 0x30
000070dabbdd47e3  vmovaps xmm0, [rsp]
000070dabbdd47e8  vmovaps xmm1, [rsp+0x10]
000070dabbdd47ee  vmovaps xmm2, [rsp+0x20]
000070dabbdd47f4  vmovaps xmm3, [rsp+0x30]
000070dabbdd47fa  vmovaps xmm4, [rsp+0x40]
000070dabbdd4800  vmovaps xmm5, [rsp+0x50]
000070dabbdd4806  vmovaps xmm6, [rsp+0x60]
000070dabbdd480c  vmovaps xmm7, [rsp+0x70]
000070dabbdd4812  vmovaps xmm8, [rsp+0x80]
000070dabbdd481b  vmovaps xmm9, [rsp+0x90]
000070dabbdd4824  vmovaps xmm11, [rsp+0xA0]
000070dabbdd482d  vmovaps xmm12, [rsp+0xB0]
000070dabbdd4836  vmovaps xmm13, [rsp+0xC0]
000070dabbdd483f  vmovaps xmm14, [rsp+0xD0]
000070dabbdd4848  vmovaps xmm15, [rsp+0xE0]
000070dabbdd4851  add rsp, 0xF0
000070dabbdd4858  pop r11
000070dabbdd485a  pop r10
000070dabbdd485c  pop r9
000070dabbdd485e  pop r8
000070dabbdd4860  pop rsi
000070dabbdd4861  pop rdi
000070dabbdd4862  pop rdx
000070dabbdd4863  pop rcx
000070dabbdd4864  pop rax
000070dabbdd4865  add rsp, 0x08
000070dabbdd4869  jmp 0x000070DABBDD0169
000070dabbdd486e  sub rsp, 0x08
000070dabbdd4872  push rax
000070dabbdd4873  push rcx
000070dabbdd4874  push rdx
000070dabbdd4875  push rdi
000070dabbdd4876  push rsi
000070dabbdd4877  push r8
000070dabbdd4879  push r9
000070dabbdd487b  push r10
000070dabbdd487d  push r11
000070dabbdd487f  sub rsp, 0xF0
000070dabbdd4886  vmovaps [rsp], xmm0
000070dabbdd488b  vmovaps [rsp+0x10], xmm1
000070dabbdd4891  vmovaps [rsp+0x20], xmm2
000070dabbdd4897  vmovaps [rsp+0x30], xmm3
000070dabbdd489d  vmovaps [rsp+0x40], xmm4
000070dabbdd48a3  vmovaps [rsp+0x50], xmm5
000070dabbdd48a9  vmovaps [rsp+0x60], xmm6
000070dabbdd48af  vmovaps [rsp+0x70], xmm7
000070dabbdd48b5  vmovaps [rsp+0x80], xmm8
000070dabbdd48be  vmovaps [rsp+0x90], xmm9
000070dabbdd48c7  vmovaps [rsp+0xA0], xmm10
000070dabbdd48d0  vmovaps [rsp+0xB0], xmm11
000070dabbdd48d9  vmovaps [rsp+0xC0], xmm12
000070dabbdd48e2  vmovaps [rsp+0xD0], xmm14
000070dabbdd48eb  vmovaps [rsp+0xE0], xmm15
000070dabbdd48f4  sub rsp, 0x30
000070dabbdd48f8  movaps [rsp], xmm13
000070dabbdd48fd  movaps [rsp+0x10], xmm1
000070dabbdd4902  movaps [rsp+0x20], xmm8
000070dabbdd4908  lea rdi, [rsp]
000070dabbdd490c  mov esi, 0x00
000070dabbdd4911  mov rax, 0x5C2CF7B6F530
000070dabbdd491b  call rax
000070dabbdd491d  movaps xmm13, [rsp]
000070dabbdd4922  add rsp, 0x30
000070dabbdd4926  vmovaps xmm0, [rsp]
000070dabbdd492b  vmovaps xmm1, [rsp+0x10]
000070dabbdd4931  vmovaps xmm2, [rsp+0x20]
000070dabbdd4937  vmovaps xmm3, [rsp+0x30]
000070dabbdd493d  vmovaps xmm4, [rsp+0x40]
000070dabbdd4943  vmovaps xmm5, [rsp+0x50]
000070dabbdd4949  vmovaps xmm6, [rsp+0x60]
000070dabbdd494f  vmovaps xmm7, [rsp+0x70]
000070dabbdd4955  vmovaps xmm8, [rsp+0x80]
000070dabbdd495e  vmovaps xmm9, [rsp+0x90]
000070dabbdd4967  vmovaps xmm10, [rsp+0xA0]
000070dabbdd4970  vmovaps xmm11, [rsp+0xB0]
000070dabbdd4979  vmovaps xmm12, [rsp+0xC0]
000070dabbdd4982  vmovaps xmm14, [rsp+0xD0]
000070dabbdd498b  vmovaps xmm15, [rsp+0xE0]
000070dabbdd4994  add rsp, 0xF0
000070dabbdd499b  pop r11
000070dabbdd499d  pop r10
000070dabbdd499f  pop r9
000070dabbdd49a1  pop r8
000070dabbdd49a3  pop rsi
000070dabbdd49a4  pop rdi
000070dabbdd49a5  pop rdx
000070dabbdd49a6  pop rcx
000070dabbdd49a7  pop rax
000070dabbdd49a8  add rsp, 0x08
000070dabbdd49ac  jmp 0x000070DABBDD0183
000070dabbdd49b1  call 0x000070DABBBFF430
000070dabbdd49b6  jmp 0x000070DABBDD018D
000070dabbdd49bb  sub rsp, 0x08
000070dabbdd49bf  push rax
000070dabbdd49c0  push rcx
000070dabbdd49c1  push rdx
000070dabbdd49c2  push rdi
000070dabbdd49c3  push rsi
000070dabbdd49c4  push r8
000070dabbdd49c6  push r9
000070dabbdd49c8  push r10
000070dabbdd49ca  push r11
000070dabbdd49cc  sub rsp, 0xF0
000070dabbdd49d3  vmovaps [rsp], xmm0
000070dabbdd49d8  vmovaps [rsp+0x10], xmm1
000070dabbdd49de  vmovaps [rsp+0x20], xmm2
000070dabbdd49e4  vmovaps [rsp+0x30], xmm3
000070dabbdd49ea  vmovaps [rsp+0x40], xmm4
000070dabbdd49f0  vmovaps [rsp+0x50], xmm5
000070dabbdd49f6  vmovaps [rsp+0x60], xmm6
000070dabbdd49fc  vmovaps [rsp+0x70], xmm7
000070dabbdd4a02  vmovaps [rsp+0x80], xmm9
000070dabbdd4a0b  vmovaps [rsp+0x90], xmm10
000070dabbdd4a14  vmovaps [rsp+0xA0], xmm11
000070dabbdd4a1d  vmovaps [rsp+0xB0], xmm12
000070dabbdd4a26  vmovaps [rsp+0xC0], xmm13
000070dabbdd4a2f  vmovaps [rsp+0xD0], xmm14
000070dabbdd4a38  vmovaps [rsp+0xE0], xmm15
000070dabbdd4a41  sub rsp, 0x30
000070dabbdd4a45  movaps [rsp], xmm8
000070dabbdd4a4a  movaps [rsp+0x10], xmm14
000070dabbdd4a50  movaps [rsp+0x20], xmm9
000070dabbdd4a56  lea rdi, [rsp]
000070dabbdd4a5a  mov esi, 0x00
000070dabbdd4a5f  mov rax, 0x5C2CF7B6F530
000070dabbdd4a69  call rax
000070dabbdd4a6b  movaps xmm8, [rsp]
000070dabbdd4a70  add rsp, 0x30
000070dabbdd4a74  vmovaps xmm0, [rsp]
000070dabbdd4a79  vmovaps xmm1, [rsp+0x10]
000070dabbdd4a7f  vmovaps xmm2, [rsp+0x20]
000070dabbdd4a85  vmovaps xmm3, [rsp+0x30]
000070dabbdd4a8b  vmovaps xmm4, [rsp+0x40]
000070dabbdd4a91  vmovaps xmm5, [rsp+0x50]
000070dabbdd4a97  vmovaps xmm6, [rsp+0x60]
000070dabbdd4a9d  vmovaps xmm7, [rsp+0x70]
000070dabbdd4aa3  vmovaps xmm9, [rsp+0x80]
000070dabbdd4aac  vmovaps xmm10, [rsp+0x90]
000070dabbdd4ab5  vmovaps xmm11, [rsp+0xA0]
000070dabbdd4abe  vmovaps xmm12, [rsp+0xB0]
000070dabbdd4ac7  vmovaps xmm13, [rsp+0xC0]
000070dabbdd4ad0  vmovaps xmm14, [rsp+0xD0]
000070dabbdd4ad9  vmovaps xmm15, [rsp+0xE0]
000070dabbdd4ae2  add rsp, 0xF0
000070dabbdd4ae9  pop r11
000070dabbdd4aeb  pop r10
000070dabbdd4aed  pop r9
000070dabbdd4aef  pop r8
000070dabbdd4af1  pop rsi
000070dabbdd4af2  pop rdi
000070dabbdd4af3  pop rdx
000070dabbdd4af4  pop rcx
000070dabbdd4af5  pop rax
000070dabbdd4af6  add rsp, 0x08
000070dabbdd4afa  jmp 0x000070DABBDD01AF
000070dabbdd4aff  sub rsp, 0x08
000070dabbdd4b03  push rax
000070dabbdd4b04  push rcx
000070dabbdd4b05  push rdx
000070dabbdd4b06  push rdi
000070dabbdd4b07  push rsi
000070dabbdd4b08  push r8
000070dabbdd4b0a  push r9
000070dabbdd4b0c  push r10
000070dabbdd4b0e  push r11
000070dabbdd4b10  sub rsp, 0xF0
000070dabbdd4b17  vmovaps [rsp], xmm0
000070dabbdd4b1c  vmovaps [rsp+0x10], xmm1
000070dabbdd4b22  vmovaps [rsp+0x20], xmm2
000070dabbdd4b28  vmovaps [rsp+0x30], xmm3
000070dabbdd4b2e  vmovaps [rsp+0x40], xmm4
000070dabbdd4b34  vmovaps [rsp+0x50], xmm5
000070dabbdd4b3a  vmovaps [rsp+0x60], xmm6
000070dabbdd4b40  vmovaps [rsp+0x70], xmm7
000070dabbdd4b46  vmovaps [rsp+0x80], xmm8
000070dabbdd4b4f  vmovaps [rsp+0x90], xmm10
000070dabbdd4b58  vmovaps [rsp+0xA0], xmm11
000070dabbdd4b61  vmovaps [rsp+0xB0], xmm12
000070dabbdd4b6a  vmovaps [rsp+0xC0], xmm13
000070dabbdd4b73  vmovaps [rsp+0xD0], xmm14
000070dabbdd4b7c  vmovaps [rsp+0xE0], xmm15
000070dabbdd4b85  sub rsp, 0x30
000070dabbdd4b89  movaps [rsp], xmm9
000070dabbdd4b8e  movaps [rsp+0x10], xmm1
000070dabbdd4b93  movaps [rsp+0x20], xmm14
000070dabbdd4b99  lea rdi, [rsp]
000070dabbdd4b9d  mov esi, 0x00
000070dabbdd4ba2  mov rax, 0x5C2CF7B6F530
000070dabbdd4bac  call rax
000070dabbdd4bae  movaps xmm9, [rsp]
000070dabbdd4bb3  add rsp, 0x30
000070dabbdd4bb7  vmovaps xmm0, [rsp]
000070dabbdd4bbc  vmovaps xmm1, [rsp+0x10]
000070dabbdd4bc2  vmovaps xmm2, [rsp+0x20]
000070dabbdd4bc8  vmovaps xmm3, [rsp+0x30]
000070dabbdd4bce  vmovaps xmm4, [rsp+0x40]
000070dabbdd4bd4  vmovaps xmm5, [rsp+0x50]
000070dabbdd4bda  vmovaps xmm6, [rsp+0x60]
000070dabbdd4be0  vmovaps xmm7, [rsp+0x70]
000070dabbdd4be6  vmovaps xmm8, [rsp+0x80]
000070dabbdd4bef  vmovaps xmm10, [rsp+0x90]
000070dabbdd4bf8  vmovaps xmm11, [rsp+0xA0]
000070dabbdd4c01  vmovaps xmm12, [rsp+0xB0]
000070dabbdd4c0a  vmovaps xmm13, [rsp+0xC0]
000070dabbdd4c13  vmovaps xmm14, [rsp+0xD0]
000070dabbdd4c1c  vmovaps xmm15, [rsp+0xE0]
000070dabbdd4c25  add rsp, 0xF0
000070dabbdd4c2c  pop r11
000070dabbdd4c2e  pop r10
000070dabbdd4c30  pop r9
000070dabbdd4c32  pop r8
000070dabbdd4c34  pop rsi
000070dabbdd4c35  pop rdi
000070dabbdd4c36  pop rdx
000070dabbdd4c37  pop rcx
000070dabbdd4c38  pop rax
000070dabbdd4c39  add rsp, 0x08
000070dabbdd4c3d  jmp 0x000070DABBDD01DD
000070dabbdd4c42  sub rsp, 0x08
000070dabbdd4c46  push rax
000070dabbdd4c47  push rcx
000070dabbdd4c48  push rdx
000070dabbdd4c49  push rdi
000070dabbdd4c4a  push rsi
000070dabbdd4c4b  push r8
000070dabbdd4c4d  push r9
000070dabbdd4c4f  push r10
000070dabbdd4c51  push r11
000070dabbdd4c53  sub rsp, 0xF0
000070dabbdd4c5a  vmovaps [rsp], xmm0
000070dabbdd4c5f  vmovaps [rsp+0x10], xmm1
000070dabbdd4c65  vmovaps [rsp+0x20], xmm2
000070dabbdd4c6b  vmovaps [rsp+0x30], xmm3
000070dabbdd4c71  vmovaps [rsp+0x40], xmm4
000070dabbdd4c77  vmovaps [rsp+0x50], xmm5
000070dabbdd4c7d  vmovaps [rsp+0x60], xmm6
000070dabbdd4c83  vmovaps [rsp+0x70], xmm7
000070dabbdd4c89  vmovaps [rsp+0x80], xmm8
000070dabbdd4c92  vmovaps [rsp+0x90], xmm9
000070dabbdd4c9b  vmovaps [rsp+0xA0], xmm10
000070dabbdd4ca4  vmovaps [rsp+0xB0], xmm11
000070dabbdd4cad  vmovaps [rsp+0xC0], xmm12
000070dabbdd4cb6  vmovaps [rsp+0xD0], xmm13
000070dabbdd4cbf  vmovaps [rsp+0xE0], xmm15
000070dabbdd4cc8  sub rsp, 0x30
000070dabbdd4ccc  movaps [rsp], xmm14
000070dabbdd4cd1  movaps [rsp+0x10], xmm4
000070dabbdd4cd6  movaps [rsp+0x20], xmm1
000070dabbdd4cdb  lea rdi, [rsp]
000070dabbdd4cdf  mov esi, 0x00
000070dabbdd4ce4  mov rax, 0x5C2CF7B6F530
000070dabbdd4cee  call rax
000070dabbdd4cf0  movaps xmm14, [rsp]
000070dabbdd4cf5  add rsp, 0x30
000070dabbdd4cf9  vmovaps xmm0, [rsp]
000070dabbdd4cfe  vmovaps xmm1, [rsp+0x10]
000070dabbdd4d04  vmovaps xmm2, [rsp+0x20]
000070dabbdd4d0a  vmovaps xmm3, [rsp+0x30]
000070dabbdd4d10  vmovaps xmm4, [rsp+0x40]
000070dabbdd4d16  vmovaps xmm5, [rsp+0x50]
000070dabbdd4d1c  vmovaps xmm6, [rsp+0x60]
000070dabbdd4d22  vmovaps xmm7, [rsp+0x70]
000070dabbdd4d28  vmovaps xmm8, [rsp+0x80]
000070dabbdd4d31  vmovaps xmm9, [rsp+0x90]
000070dabbdd4d3a  vmovaps xmm10, [rsp+0xA0]
000070dabbdd4d43  vmovaps xmm11, [rsp+0xB0]
000070dabbdd4d4c  vmovaps xmm12, [rsp+0xC0]
000070dabbdd4d55  vmovaps xmm13, [rsp+0xD0]
000070dabbdd4d5e  vmovaps xmm15, [rsp+0xE0]
000070dabbdd4d67  add rsp, 0xF0
000070dabbdd4d6e  pop r11
000070dabbdd4d70  pop r10
000070dabbdd4d72  pop r9
000070dabbdd4d74  pop r8
000070dabbdd4d76  pop rsi
000070dabbdd4d77  pop rdi
000070dabbdd4d78  pop rdx
000070dabbdd4d79  pop rcx
000070dabbdd4d7a  pop rax
000070dabbdd4d7b  add rsp, 0x08
000070dabbdd4d7f  jmp 0x000070DABBDD0203
000070dabbdd4d84  sub rsp, 0x08
000070dabbdd4d88  push rax
000070dabbdd4d89  push rcx
000070dabbdd4d8a  push rdx
000070dabbdd4d8b  push rdi
000070dabbdd4d8c  push rsi
000070dabbdd4d8d  push r8
000070dabbdd4d8f  push r9
000070dabbdd4d91  push r10
000070dabbdd4d93  push r11
000070dabbdd4d95  sub rsp, 0xF0
000070dabbdd4d9c  vmovaps [rsp], xmm0
000070dabbdd4da1  vmovaps [rsp+0x10], xmm2
000070dabbdd4da7  vmovaps [rsp+0x20], xmm3
000070dabbdd4dad  vmovaps [rsp+0x30], xmm4
000070dabbdd4db3  vmovaps [rsp+0x40], xmm5
000070dabbdd4db9  vmovaps [rsp+0x50], xmm6
000070dabbdd4dbf  vmovaps [rsp+0x60], xmm7
000070dabbdd4dc5  vmovaps [rsp+0x70], xmm8
000070dabbdd4dcb  vmovaps [rsp+0x80], xmm9
000070dabbdd4dd4  vmovaps [rsp+0x90], xmm10
000070dabbdd4ddd  vmovaps [rsp+0xA0], xmm11
000070dabbdd4de6  vmovaps [rsp+0xB0], xmm12
000070dabbdd4def  vmovaps [rsp+0xC0], xmm13
000070dabbdd4df8  vmovaps [rsp+0xD0], xmm14
000070dabbdd4e01  vmovaps [rsp+0xE0], xmm15
000070dabbdd4e0a  sub rsp, 0x30
000070dabbdd4e0e  movaps [rsp], xmm1
000070dabbdd4e12  movaps [rsp+0x10], xmm12
000070dabbdd4e18  movaps [rsp+0x20], xmm11
000070dabbdd4e1e  lea rdi, [rsp]
000070dabbdd4e22  mov esi, 0x00
000070dabbdd4e27  mov rax, 0x5C2CF7B6F530
000070dabbdd4e31  call rax
000070dabbdd4e33  movaps xmm1, [rsp]
000070dabbdd4e37  add rsp, 0x30
000070dabbdd4e3b  vmovaps xmm0, [rsp]
000070dabbdd4e40  vmovaps xmm2, [rsp+0x10]
000070dabbdd4e46  vmovaps xmm3, [rsp+0x20]
000070dabbdd4e4c  vmovaps xmm4, [rsp+0x30]
000070dabbdd4e52  vmovaps xmm5, [rsp+0x40]
000070dabbdd4e58  vmovaps xmm6, [rsp+0x50]
000070dabbdd4e5e  vmovaps xmm7, [rsp+0x60]
000070dabbdd4e64  vmovaps xmm8, [rsp+0x70]
000070dabbdd4e6a  vmovaps xmm9, [rsp+0x80]
000070dabbdd4e73  vmovaps xmm10, [rsp+0x90]
000070dabbdd4e7c  vmovaps xmm11, [rsp+0xA0]
000070dabbdd4e85  vmovaps xmm12, [rsp+0xB0]
000070dabbdd4e8e  vmovaps xmm13, [rsp+0xC0]
000070dabbdd4e97  vmovaps xmm14, [rsp+0xD0]
000070dabbdd4ea0  vmovaps xmm15, [rsp+0xE0]
000070dabbdd4ea9  add rsp, 0xF0
000070dabbdd4eb0  pop r11
000070dabbdd4eb2  pop r10
000070dabbdd4eb4  pop r9
000070dabbdd4eb6  pop r8
000070dabbdd4eb8  pop rsi
000070dabbdd4eb9  pop rdi
000070dabbdd4eba  pop rdx
000070dabbdd4ebb  pop rcx
000070dabbdd4ebc  pop rax
000070dabbdd4ebd  add rsp, 0x08
000070dabbdd4ec1  jmp 0x000070DABBDD0224
000070dabbdd4ec6  call 0x000070DABBCE20A0
000070dabbdd4ecb  jmp 0x000070DABBDD0232
000070dabbdd4ed0  call 0x000070DABBC09D70
000070dabbdd4ed5  jmp 0x000070DABBDD023C
000070dabbdd4eda  sub rsp, 0x08
000070dabbdd4ede  push rax
000070dabbdd4edf  push rcx
000070dabbdd4ee0  push rdx
000070dabbdd4ee1  push rdi
000070dabbdd4ee2  push rsi
000070dabbdd4ee3  push r8
000070dabbdd4ee5  push r9
000070dabbdd4ee7  push r10
000070dabbdd4ee9  push r11
000070dabbdd4eeb  sub rsp, 0xF0
000070dabbdd4ef2  vmovaps [rsp], xmm0
000070dabbdd4ef7  vmovaps [rsp+0x10], xmm1
000070dabbdd4efd  vmovaps [rsp+0x20], xmm2
000070dabbdd4f03  vmovaps [rsp+0x30], xmm3
000070dabbdd4f09  vmovaps [rsp+0x40], xmm4
000070dabbdd4f0f  vmovaps [rsp+0x50], xmm5
000070dabbdd4f15  vmovaps [rsp+0x60], xmm6
000070dabbdd4f1b  vmovaps [rsp+0x70], xmm8
000070dabbdd4f21  vmovaps [rsp+0x80], xmm9
000070dabbdd4f2a  vmovaps [rsp+0x90], xmm10
000070dabbdd4f33  vmovaps [rsp+0xA0], xmm11
000070dabbdd4f3c  vmovaps [rsp+0xB0], xmm12
000070dabbdd4f45  vmovaps [rsp+0xC0], xmm13
000070dabbdd4f4e  vmovaps [rsp+0xD0], xmm14
000070dabbdd4f57  vmovaps [rsp+0xE0], xmm15
000070dabbdd4f60  sub rsp, 0x30
000070dabbdd4f64  movaps [rsp], xmm7
000070dabbdd4f68  movaps [rsp+0x10], xmm15
000070dabbdd4f6e  movaps [rsp+0x20], xmm10
000070dabbdd4f74  lea rdi, [rsp]
000070dabbdd4f78  mov esi, 0x00
000070dabbdd4f7d  mov rax, 0x5C2CF7B6F530
000070dabbdd4f87  call rax
000070dabbdd4f89  movaps xmm7, [rsp]
000070dabbdd4f8d  add rsp, 0x30
000070dabbdd4f91  vmovaps xmm0, [rsp]
000070dabbdd4f96  vmovaps xmm1, [rsp+0x10]
000070dabbdd4f9c  vmovaps xmm2, [rsp+0x20]
000070dabbdd4fa2  vmovaps xmm3, [rsp+0x30]
000070dabbdd4fa8  vmovaps xmm4, [rsp+0x40]
000070dabbdd4fae  vmovaps xmm5, [rsp+0x50]
000070dabbdd4fb4  vmovaps xmm6, [rsp+0x60]
000070dabbdd4fba  vmovaps xmm8, [rsp+0x70]
000070dabbdd4fc0  vmovaps xmm9, [rsp+0x80]
000070dabbdd4fc9  vmovaps xmm10, [rsp+0x90]
000070dabbdd4fd2  vmovaps xmm11, [rsp+0xA0]
000070dabbdd4fdb  vmovaps xmm12, [rsp+0xB0]
000070dabbdd4fe4  vmovaps xmm13, [rsp+0xC0]
000070dabbdd4fed  vmovaps xmm14, [rsp+0xD0]
000070dabbdd4ff6  vmovaps xmm15, [rsp+0xE0]
000070dabbdd4fff  add rsp, 0xF0
000070dabbdd5006  pop r11
000070dabbdd5008  pop r10
000070dabbdd500a  pop r9
000070dabbdd500c  pop r8
000070dabbdd500e  pop rsi
000070dabbdd500f  pop rdi
000070dabbdd5010  pop rdx
000070dabbdd5011  pop rcx
000070dabbdd5012  pop rax
000070dabbdd5013  add rsp, 0x08
000070dabbdd5017  jmp 0x000070DABBDD025D
000070dabbdd501c  sub rsp, 0x08
000070dabbdd5020  push rax
000070dabbdd5021  push rcx
000070dabbdd5022  push rdx
000070dabbdd5023  push rdi
000070dabbdd5024  push rsi
000070dabbdd5025  push r8
000070dabbdd5027  push r9
000070dabbdd5029  push r10
000070dabbdd502b  push r11
000070dabbdd502d  sub rsp, 0xF0
000070dabbdd5034  vmovaps [rsp], xmm0
000070dabbdd5039  vmovaps [rsp+0x10], xmm1
000070dabbdd503f  vmovaps [rsp+0x20], xmm2
000070dabbdd5045  vmovaps [rsp+0x30], xmm3
000070dabbdd504b  vmovaps [rsp+0x40], xmm4
000070dabbdd5051  vmovaps [rsp+0x50], xmm5
000070dabbdd5057  vmovaps [rsp+0x60], xmm6
000070dabbdd505d  vmovaps [rsp+0x70], xmm7
000070dabbdd5063  vmovaps [rsp+0x80], xmm8
000070dabbdd506c  vmovaps [rsp+0x90], xmm9
000070dabbdd5075  vmovaps [rsp+0xA0], xmm11
000070dabbdd507e  vmovaps [rsp+0xB0], xmm12
000070dabbdd5087  vmovaps [rsp+0xC0], xmm13
000070dabbdd5090  vmovaps [rsp+0xD0], xmm14
000070dabbdd5099  vmovaps [rsp+0xE0], xmm15
000070dabbdd50a2  sub rsp, 0x30
000070dabbdd50a6  movaps [rsp], xmm10
000070dabbdd50ab  movaps [rsp+0x10], xmm11
000070dabbdd50b1  movaps [rsp+0x20], xmm15
000070dabbdd50b7  lea rdi, [rsp]
000070dabbdd50bb  mov esi, 0x00
000070dabbdd50c0  mov rax, 0x5C2CF7B6F530
000070dabbdd50ca  call rax
000070dabbdd50cc  movaps xmm10, [rsp]
000070dabbdd50d1  add rsp, 0x30
000070dabbdd50d5  vmovaps xmm0, [rsp]
000070dabbdd50da  vmovaps xmm1, [rsp+0x10]
000070dabbdd50e0  vmovaps xmm2, [rsp+0x20]
000070dabbdd50e6  vmovaps xmm3, [rsp+0x30]
000070dabbdd50ec  vmovaps xmm4, [rsp+0x40]
000070dabbdd50f2  vmovaps xmm5, [rsp+0x50]
000070dabbdd50f8  vmovaps xmm6, [rsp+0x60]
000070dabbdd50fe  vmovaps xmm7, [rsp+0x70]
000070dabbdd5104  vmovaps xmm8, [rsp+0x80]
000070dabbdd510d  vmovaps xmm9, [rsp+0x90]
000070dabbdd5116  vmovaps xmm11, [rsp+0xA0]
000070dabbdd511f  vmovaps xmm12, [rsp+0xB0]
000070dabbdd5128  vmovaps xmm13, [rsp+0xC0]
000070dabbdd5131  vmovaps xmm14, [rsp+0xD0]
000070dabbdd513a  vmovaps xmm15, [rsp+0xE0]
000070dabbdd5143  add rsp, 0xF0
000070dabbdd514a  pop r11
000070dabbdd514c  pop r10
000070dabbdd514e  pop r9
000070dabbdd5150  pop r8
000070dabbdd5152  pop rsi
000070dabbdd5153  pop rdi
000070dabbdd5154  pop rdx
000070dabbdd5155  pop rcx
000070dabbdd5156  pop rax
000070dabbdd5157  add rsp, 0x08
000070dabbdd515b  jmp 0x000070DABBDD028B
000070dabbdd5160  sub rsp, 0x08
000070dabbdd5164  push rax
000070dabbdd5165  push rcx
000070dabbdd5166  push rdx
000070dabbdd5167  push rdi
000070dabbdd5168  push rsi
000070dabbdd5169  push r8
000070dabbdd516b  push r9
000070dabbdd516d  push r10
000070dabbdd516f  push r11
000070dabbdd5171  sub rsp, 0xF0
000070dabbdd5178  vmovaps [rsp], xmm0
000070dabbdd517d  vmovaps [rsp+0x10], xmm1
000070dabbdd5183  vmovaps [rsp+0x20], xmm2
000070dabbdd5189  vmovaps [rsp+0x30], xmm3
000070dabbdd518f  vmovaps [rsp+0x40], xmm4
000070dabbdd5195  vmovaps [rsp+0x50], xmm5
000070dabbdd519b  vmovaps [rsp+0x60], xmm6
000070dabbdd51a1  vmovaps [rsp+0x70], xmm7
000070dabbdd51a7  vmovaps [rsp+0x80], xmm8
000070dabbdd51b0  vmovaps [rsp+0x90], xmm9
000070dabbdd51b9  vmovaps [rsp+0xA0], xmm10
000070dabbdd51c2  vmovaps [rsp+0xB0], xmm12
000070dabbdd51cb  vmovaps [rsp+0xC0], xmm13
000070dabbdd51d4  vmovaps [rsp+0xD0], xmm14
000070dabbdd51dd  vmovaps [rsp+0xE0], xmm15
000070dabbdd51e6  sub rsp, 0x30
000070dabbdd51ea  movaps [rsp], xmm11
000070dabbdd51ef  movaps [rsp+0x10], xmm12
000070dabbdd51f5  movaps [rsp+0x20], xmm15
000070dabbdd51fb  lea rdi, [rsp]
000070dabbdd51ff  mov esi, 0x00
000070dabbdd5204  mov rax, 0x5C2CF7B6F530
000070dabbdd520e  call rax
000070dabbdd5210  movaps xmm11, [rsp]
000070dabbdd5215  add rsp, 0x30
000070dabbdd5219  vmovaps xmm0, [rsp]
000070dabbdd521e  vmovaps xmm1, [rsp+0x10]
000070dabbdd5224  vmovaps xmm2, [rsp+0x20]
000070dabbdd522a  vmovaps xmm3, [rsp+0x30]
000070dabbdd5230  vmovaps xmm4, [rsp+0x40]
000070dabbdd5236  vmovaps xmm5, [rsp+0x50]
000070dabbdd523c  vmovaps xmm6, [rsp+0x60]
000070dabbdd5242  vmovaps xmm7, [rsp+0x70]
000070dabbdd5248  vmovaps xmm8, [rsp+0x80]
000070dabbdd5251  vmovaps xmm9, [rsp+0x90]
000070dabbdd525a  vmovaps xmm10, [rsp+0xA0]
000070dabbdd5263  vmovaps xmm12, [rsp+0xB0]
000070dabbdd526c  vmovaps xmm13, [rsp+0xC0]
000070dabbdd5275  vmovaps xmm14, [rsp+0xD0]
000070dabbdd527e  vmovaps xmm15, [rsp+0xE0]
000070dabbdd5287  add rsp, 0xF0
000070dabbdd528e  pop r11
000070dabbdd5290  pop r10
000070dabbdd5292  pop r9
000070dabbdd5294  pop r8
000070dabbdd5296  pop rsi
000070dabbdd5297  pop rdi
000070dabbdd5298  pop rdx
000070dabbdd5299  pop rcx
000070dabbdd529a  pop rax
000070dabbdd529b  add rsp, 0x08
000070dabbdd529f  jmp 0x000070DABBDD02B9
000070dabbdd52a4  sub rsp, 0x08
000070dabbdd52a8  push rax
000070dabbdd52a9  push rcx
000070dabbdd52aa  push rdx
000070dabbdd52ab  push rdi
000070dabbdd52ac  push rsi
000070dabbdd52ad  push r8
000070dabbdd52af  push r9
000070dabbdd52b1  push r10
000070dabbdd52b3  push r11
000070dabbdd52b5  sub rsp, 0xF0
000070dabbdd52bc  vmovaps [rsp], xmm0
000070dabbdd52c1  vmovaps [rsp+0x10], xmm1
000070dabbdd52c7  vmovaps [rsp+0x20], xmm2
000070dabbdd52cd  vmovaps [rsp+0x30], xmm3
000070dabbdd52d3  vmovaps [rsp+0x40], xmm4
000070dabbdd52d9  vmovaps [rsp+0x50], xmm5
000070dabbdd52df  vmovaps [rsp+0x60], xmm6
000070dabbdd52e5  vmovaps [rsp+0x70], xmm7
000070dabbdd52eb  vmovaps [rsp+0x80], xmm8
000070dabbdd52f4  vmovaps [rsp+0x90], xmm9
000070dabbdd52fd  vmovaps [rsp+0xA0], xmm10
000070dabbdd5306  vmovaps [rsp+0xB0], xmm11
000070dabbdd530f  vmovaps [rsp+0xC0], xmm12
000070dabbdd5318  vmovaps [rsp+0xD0], xmm13
000070dabbdd5321  vmovaps [rsp+0xE0], xmm14
000070dabbdd532a  sub rsp, 0x30
000070dabbdd532e  movaps [rsp], xmm15
000070dabbdd5333  movaps [rsp+0x10], xmm13
000070dabbdd5339  movaps [rsp+0x20], xmm9
000070dabbdd533f  lea rdi, [rsp]
000070dabbdd5343  mov esi, 0x00
000070dabbdd5348  mov rax, 0x5C2CF7B6F530
000070dabbdd5352  call rax
000070dabbdd5354  movaps xmm15, [rsp]
000070dabbdd5359  add rsp, 0x30
000070dabbdd535d  vmovaps xmm0, [rsp]
000070dabbdd5362  vmovaps xmm1, [rsp+0x10]
000070dabbdd5368  vmovaps xmm2, [rsp+0x20]
000070dabbdd536e  vmovaps xmm3, [rsp+0x30]
000070dabbdd5374  vmovaps xmm4, [rsp+0x40]
000070dabbdd537a  vmovaps xmm5, [rsp+0x50]
000070dabbdd5380  vmovaps xmm6, [rsp+0x60]
000070dabbdd5386  vmovaps xmm7, [rsp+0x70]
000070dabbdd538c  vmovaps xmm8, [rsp+0x80]
000070dabbdd5395  vmovaps xmm9, [rsp+0x90]
000070dabbdd539e  vmovaps xmm10, [rsp+0xA0]
000070dabbdd53a7  vmovaps xmm11, [rsp+0xB0]
000070dabbdd53b0  vmovaps xmm12, [rsp+0xC0]
000070dabbdd53b9  vmovaps xmm13, [rsp+0xD0]
000070dabbdd53c2  vmovaps xmm14, [rsp+0xE0]
000070dabbdd53cb  add rsp, 0xF0
000070dabbdd53d2  pop r11
000070dabbdd53d4  pop r10
000070dabbdd53d6  pop r9
000070dabbdd53d8  pop r8
000070dabbdd53da  pop rsi
000070dabbdd53db  pop rdi
000070dabbdd53dc  pop rdx
000070dabbdd53dd  pop rcx
000070dabbdd53de  pop rax
000070dabbdd53df  add rsp, 0x08
000070dabbdd53e3  jmp 0x000070DABBDD02D4
000070dabbdd53e8  sub rsp, 0x08
000070dabbdd53ec  push rax
000070dabbdd53ed  push rcx
000070dabbdd53ee  push rdx
000070dabbdd53ef  push rdi
000070dabbdd53f0  push rsi
000070dabbdd53f1  push r8
000070dabbdd53f3  push r9
000070dabbdd53f5  push r10
000070dabbdd53f7  push r11
000070dabbdd53f9  sub rsp, 0xF0
000070dabbdd5400  vmovaps [rsp], xmm0
000070dabbdd5405  vmovaps [rsp+0x10], xmm1
000070dabbdd540b  vmovaps [rsp+0x20], xmm2
000070dabbdd5411  vmovaps [rsp+0x30], xmm3
000070dabbdd5417  vmovaps [rsp+0x40], xmm4
000070dabbdd541d  vmovaps [rsp+0x50], xmm5
000070dabbdd5423  vmovaps [rsp+0x60], xmm6
000070dabbdd5429  vmovaps [rsp+0x70], xmm7
000070dabbdd542f  vmovaps [rsp+0x80], xmm8
000070dabbdd5438  vmovaps [rsp+0x90], xmm9
000070dabbdd5441  vmovaps [rsp+0xA0], xmm10
000070dabbdd544a  vmovaps [rsp+0xB0], xmm11
000070dabbdd5453  vmovaps [rsp+0xC0], xmm12
000070dabbdd545c  vmovaps [rsp+0xD0], xmm14
000070dabbdd5465  vmovaps [rsp+0xE0], xmm15
000070dabbdd546e  sub rsp, 0x30
000070dabbdd5472  movaps [rsp], xmm13
000070dabbdd5477  movaps [rsp+0x10], xmm8
000070dabbdd547d  movaps [rsp+0x20], xmm14
000070dabbdd5483  lea rdi, [rsp]
000070dabbdd5487  mov esi, 0x00
000070dabbdd548c  mov rax, 0x5C2CF7B6F530
000070dabbdd5496  call rax
000070dabbdd5498  movaps xmm13, [rsp]
000070dabbdd549d  add rsp, 0x30
000070dabbdd54a1  vmovaps xmm0, [rsp]
000070dabbdd54a6  vmovaps xmm1, [rsp+0x10]
000070dabbdd54ac  vmovaps xmm2, [rsp+0x20]
000070dabbdd54b2  vmovaps xmm3, [rsp+0x30]
000070dabbdd54b8  vmovaps xmm4, [rsp+0x40]
000070dabbdd54be  vmovaps xmm5, [rsp+0x50]
000070dabbdd54c4  vmovaps xmm6, [rsp+0x60]
000070dabbdd54ca  vmovaps xmm7, [rsp+0x70]
000070dabbdd54d0  vmovaps xmm8, [rsp+0x80]
000070dabbdd54d9  vmovaps xmm9, [rsp+0x90]
000070dabbdd54e2  vmovaps xmm10, [rsp+0xA0]
000070dabbdd54eb  vmovaps xmm11, [rsp+0xB0]
000070dabbdd54f4  vmovaps xmm12, [rsp+0xC0]
000070dabbdd54fd  vmovaps xmm14, [rsp+0xD0]
000070dabbdd5506  vmovaps xmm15, [rsp+0xE0]
000070dabbdd550f  add rsp, 0xF0
000070dabbdd5516  pop r11
000070dabbdd5518  pop r10
000070dabbdd551a  pop r9
000070dabbdd551c  pop r8
000070dabbdd551e  pop rsi
000070dabbdd551f  pop rdi
000070dabbdd5520  pop rdx
000070dabbdd5521  pop rcx
000070dabbdd5522  pop rax
000070dabbdd5523  add rsp, 0x08
000070dabbdd5527  jmp 0x000070DABBDD02F7
000070dabbdd552c  sub rsp, 0x08
000070dabbdd5530  push rax
000070dabbdd5531  push rcx
000070dabbdd5532  push rdx
000070dabbdd5533  push rdi
000070dabbdd5534  push rsi
000070dabbdd5535  push r8
000070dabbdd5537  push r9
000070dabbdd5539  push r10
000070dabbdd553b  push r11
000070dabbdd553d  sub rsp, 0xF0
000070dabbdd5544  vmovaps [rsp], xmm0
000070dabbdd5549  vmovaps [rsp+0x10], xmm1
000070dabbdd554f  vmovaps [rsp+0x20], xmm2
000070dabbdd5555  vmovaps [rsp+0x30], xmm3
000070dabbdd555b  vmovaps [rsp+0x40], xmm4
000070dabbdd5561  vmovaps [rsp+0x50], xmm5
000070dabbdd5567  vmovaps [rsp+0x60], xmm6
000070dabbdd556d  vmovaps [rsp+0x70], xmm7
000070dabbdd5573  vmovaps [rsp+0x80], xmm8
000070dabbdd557c  vmovaps [rsp+0x90], xmm9
000070dabbdd5585  vmovaps [rsp+0xA0], xmm10
000070dabbdd558e  vmovaps [rsp+0xB0], xmm11
000070dabbdd5597  vmovaps [rsp+0xC0], xmm12
000070dabbdd55a0  vmovaps [rsp+0xD0], xmm13
000070dabbdd55a9  vmovaps [rsp+0xE0], xmm15
000070dabbdd55b2  sub rsp, 0x30
000070dabbdd55b6  movaps [rsp], xmm14
000070dabbdd55bb  movaps [rsp+0x10], xmm1
000070dabbdd55c0  movaps [rsp+0x20], xmm10
000070dabbdd55c6  lea rdi, [rsp]
000070dabbdd55ca  mov esi, 0x00
000070dabbdd55cf  mov rax, 0x5C2CF7B6F530
000070dabbdd55d9  call rax
000070dabbdd55db  movaps xmm14, [rsp]
000070dabbdd55e0  add rsp, 0x30
000070dabbdd55e4  vmovaps xmm0, [rsp]
000070dabbdd55e9  vmovaps xmm1, [rsp+0x10]
000070dabbdd55ef  vmovaps xmm2, [rsp+0x20]
000070dabbdd55f5  vmovaps xmm3, [rsp+0x30]
000070dabbdd55fb  vmovaps xmm4, [rsp+0x40]
000070dabbdd5601  vmovaps xmm5, [rsp+0x50]
000070dabbdd5607  vmovaps xmm6, [rsp+0x60]
000070dabbdd560d  vmovaps xmm7, [rsp+0x70]
000070dabbdd5613  vmovaps xmm8, [rsp+0x80]
000070dabbdd561c  vmovaps xmm9, [rsp+0x90]
000070dabbdd5625  vmovaps xmm10, [rsp+0xA0]
000070dabbdd562e  vmovaps xmm11, [rsp+0xB0]
000070dabbdd5637  vmovaps xmm12, [rsp+0xC0]
000070dabbdd5640  vmovaps xmm13, [rsp+0xD0]
000070dabbdd5649  vmovaps xmm15, [rsp+0xE0]
000070dabbdd5652  add rsp, 0xF0
000070dabbdd5659  pop r11
000070dabbdd565b  pop r10
000070dabbdd565d  pop r9
000070dabbdd565f  pop r8
000070dabbdd5661  pop rsi
000070dabbdd5662  pop rdi
000070dabbdd5663  pop rdx
000070dabbdd5664  pop rcx
000070dabbdd5665  pop rax
000070dabbdd5666  add rsp, 0x08
000070dabbdd566a  jmp 0x000070DABBDD031A
000070dabbdd566f  sub rsp, 0x08
000070dabbdd5673  push rax
000070dabbdd5674  push rcx
000070dabbdd5675  push rdx
000070dabbdd5676  push rdi
000070dabbdd5677  push rsi
000070dabbdd5678  push r8
000070dabbdd567a  push r9
000070dabbdd567c  push r10
000070dabbdd567e  push r11
000070dabbdd5680  sub rsp, 0xF0
000070dabbdd5687  vmovaps [rsp], xmm0
000070dabbdd568c  vmovaps [rsp+0x10], xmm2
000070dabbdd5692  vmovaps [rsp+0x20], xmm3
000070dabbdd5698  vmovaps [rsp+0x30], xmm4
000070dabbdd569e  vmovaps [rsp+0x40], xmm5
000070dabbdd56a4  vmovaps [rsp+0x50], xmm6
000070dabbdd56aa  vmovaps [rsp+0x60], xmm7
000070dabbdd56b0  vmovaps [rsp+0x70], xmm8
000070dabbdd56b6  vmovaps [rsp+0x80], xmm9
000070dabbdd56bf  vmovaps [rsp+0x90], xmm10
000070dabbdd56c8  vmovaps [rsp+0xA0], xmm11
000070dabbdd56d1  vmovaps [rsp+0xB0], xmm12
000070dabbdd56da  vmovaps [rsp+0xC0], xmm13
000070dabbdd56e3  vmovaps [rsp+0xD0], xmm14
000070dabbdd56ec  vmovaps [rsp+0xE0], xmm15
000070dabbdd56f5  sub rsp, 0x30
000070dabbdd56f9  movaps [rsp], xmm1
000070dabbdd56fd  movaps [rsp+0x10], xmm7
000070dabbdd5702  movaps [rsp+0x20], xmm11
000070dabbdd5708  lea rdi, [rsp]
000070dabbdd570c  mov esi, 0x00
000070dabbdd5711  mov rax, 0x5C2CF7B6F530
000070dabbdd571b  call rax
000070dabbdd571d  movaps xmm1, [rsp]
000070dabbdd5721  add rsp, 0x30
000070dabbdd5725  vmovaps xmm0, [rsp]
000070dabbdd572a  vmovaps xmm2, [rsp+0x10]
000070dabbdd5730  vmovaps xmm3, [rsp+0x20]
000070dabbdd5736  vmovaps xmm4, [rsp+0x30]
000070dabbdd573c  vmovaps xmm5, [rsp+0x40]
000070dabbdd5742  vmovaps xmm6, [rsp+0x50]
000070dabbdd5748  vmovaps xmm7, [rsp+0x60]
000070dabbdd574e  vmovaps xmm8, [rsp+0x70]
000070dabbdd5754  vmovaps xmm9, [rsp+0x80]
000070dabbdd575d  vmovaps xmm10, [rsp+0x90]
000070dabbdd5766  vmovaps xmm11, [rsp+0xA0]
000070dabbdd576f  vmovaps xmm12, [rsp+0xB0]
000070dabbdd5778  vmovaps xmm13, [rsp+0xC0]
000070dabbdd5781  vmovaps xmm14, [rsp+0xD0]
000070dabbdd578a  vmovaps xmm15, [rsp+0xE0]
000070dabbdd5793  add rsp, 0xF0
000070dabbdd579a  pop r11
000070dabbdd579c  pop r10
000070dabbdd579e  pop r9
000070dabbdd57a0  pop r8
000070dabbdd57a2  pop rsi
000070dabbdd57a3  pop rdi
000070dabbdd57a4  pop rdx
000070dabbdd57a5  pop rcx
000070dabbdd57a6  pop rax
000070dabbdd57a7  add rsp, 0x08
000070dabbdd57ab  jmp 0x000070DABBDD033B
000070dabbdd57b0  call 0x000070DABBC0E880
000070dabbdd57b5  jmp 0x000070DABBDD034E
000070dabbdd57ba  call 0x000070DABBC0C380
000070dabbdd57bf  jmp 0x000070DABBDD0359
000070dabbdd57c4  call 0x000070DABBC0D600
000070dabbdd57c9  jmp 0x000070DABBDD0364
000070dabbdd57ce  call 0x000070DABBBFF540
000070dabbdd57d3  jmp 0x000070DABBDD036F
000070dabbdd57d8  int3
000070dabbdd57d9  nop [rax], eax
000070dabbdd57e0  mov rax, [r15+0x40]
000070dabbdd57e4  mov r14, [r15+0x58]
000070dabbdd57e8  lea r12, [rax+r14*1]
000070dabbdd57ec  movaps xmm1, [r15+0x1D0]
000070dabbdd57f4  vmovaps [rsp+0x10], xmm1
000070dabbdd57fa  vmovaps xmm15, [rsp+0x10]
000070dabbdd5800  por xmm1, xmm15
000070dabbdd5805  movaps xmm14, [r15+0x1A0]
000070dabbdd580d  vmovaps [rsp+0x10], xmm14
000070dabbdd5813  vmovaps xmm13, [rsp+0x10]
000070dabbdd5819  por xmm14, xmm13
000070dabbdd581e  lea rax, [r12+0x30]
000070dabbdd5823  mov r11, [r13+rax*1]
000070dabbdd5828  lea rax, [r12+0x38]
000070dabbdd582d  mov r10, [r13+rax*1]
000070dabbdd5832  movq xmm13, r11
000070dabbdd5837  movq xmm12, r10
000070dabbdd583c  movq xmm13, xmm13
000070dabbdd5841  vmovaps [rsp+0x10], xmm13
000070dabbdd5847  movq xmm13, xmm13
000070dabbdd584c  movaps [r15+0x130], xmm13
000070dabbdd5854  movq xmm12, xmm12
000070dabbdd5859  vmovaps [rsp+0x20], xmm12
000070dabbdd585f  movq xmm12, xmm12
000070dabbdd5864  movaps [r15+0x280], xmm12
000070dabbdd586c  movaps xmm13, [r15+0x270]
000070dabbdd5874  vmovaps [rsp+0x30], xmm13
000070dabbdd587a  vmovaps xmm12, [rsp+0x30]
000070dabbdd5880  por xmm13, xmm12
000070dabbdd5885  lea rax, [r12+0x20]
000070dabbdd588a  mov r11, [r13+rax*1]
000070dabbdd588f  lea rax, [r12+0x28]
000070dabbdd5894  mov r10, [r13+rax*1]
000070dabbdd5899  movq xmm12, r11
000070dabbdd589e  movq xmm11, r10
000070dabbdd58a3  movq xmm12, xmm12
000070dabbdd58a8  vmovaps [rsp+0x30], xmm12
000070dabbdd58ae  movq xmm12, xmm12
000070dabbdd58b3  movaps [r15+0x150], xmm12
000070dabbdd58bb  movq xmm11, xmm11
000070dabbdd58c0  vmovaps [rsp+0x40], xmm11
000070dabbdd58c6  movq xmm11, xmm11
000070dabbdd58cb  movaps [r15+0x140], xmm11
000070dabbdd58d3  lea rax, [r12+0x10]
000070dabbdd58d8  mov r11, [r13+rax*1]
000070dabbdd58dd  lea rax, [r12+0x18]
000070dabbdd58e2  mov r10, [r13+rax*1]
000070dabbdd58e7  movq xmm12, r11
000070dabbdd58ec  movq xmm11, r10
000070dabbdd58f1  movq xmm12, xmm12
000070dabbdd58f6  vmovaps [rsp+0x50], xmm12
000070dabbdd58fc  movq xmm12, xmm12
000070dabbdd5901  movaps [r15+0x170], xmm12
000070dabbdd5909  movq xmm11, xmm11
000070dabbdd590e  vmovaps [rsp+0x60], xmm11
000070dabbdd5914  movq xmm11, xmm11
000070dabbdd5919  movaps [r15+0x160], xmm11
000070dabbdd5921  mov rax, [r13+r12*1]
000070dabbdd5926  vmovq xmm12, rax
000070dabbdd592b  vpbroadcastq xmm12, xmm12
000070dabbdd5930  lea rax, [r12+0x08]
000070dabbdd5935  mov r12, [r13+rax*1]
000070dabbdd593a  movq xmm11, r12
000070dabbdd593f  movaps [r15+0x230], xmm11
000070dabbdd5947  mov rax, [r15+0xF8]
000070dabbdd594e  lea r12, [rax+0x50]
000070dabbdd5952  movups xmm11, [r13+r12*1]
000070dabbdd5958  lea r12, [rax+0x60]
000070dabbdd595c  movups xmm10, [r13+r12*1]
000070dabbdd5962  lea r12, [rax+0x30]
000070dabbdd5966  movups xmm9, [r13+r12*1]
000070dabbdd596c  mov r12, [r15+0x50]
000070dabbdd5970  lea r11, [r12+r14*1]
000070dabbdd5974  mov [r15+0x60], r11
000070dabbdd5978  lea r12, [r14+0x40]
000070dabbdd597c  mov [r15+0x58], r12
000070dabbdd5980  movaps xmm8, xmm12
000070dabbdd5984  mulpd xmm8, xmm15
000070dabbdd5989  vcmppd xmm7, xmm8, xmm8, 0x03
000070dabbdd598f  ptest xmm7, xmm7
000070dabbdd5994  jnz 0x000070DABBDD67B7
000070dabbdd599a  movq xmm15, qword ptr [r15+0x230]
000070dabbdd59a3  vmovaps [rsp+0x70], xmm15
000070dabbdd59a9  vpermilpd xmm15, xmm15, 0x00
000070dabbdd59af  movaps xmm7, xmm9
000070dabbdd59b3  mulpd xmm7, xmm15
000070dabbdd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000070dabbdd59bd  ptest xmm6, xmm6
000070dabbdd59c2  jnz 0x000070DABBDD68FB
000070dabbdd59c8  vxorps xmm15, xmm15, xmm15
000070dabbdd59cd  vpbroadcastq xmm15, xmm15
000070dabbdd59d2  movaps xmm9, xmm12
000070dabbdd59d6  mulpd xmm9, xmm10
000070dabbdd59db  vcmppd xmm6, xmm9, xmm9, 0x03
000070dabbdd59e1  ptest xmm6, xmm6
000070dabbdd59e6  jnz 0x000070DABBDD6A3D
000070dabbdd59ec  movaps xmm10, xmm12
000070dabbdd59f0  mulpd xmm10, xmm11
000070dabbdd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000070dabbdd59fb  ptest xmm6, xmm6
000070dabbdd5a00  jnz 0x000070DABBDD6B81
000070dabbdd5a06  movaps xmm11, [r15+0x1F0]
000070dabbdd5a0e  movaps xmm6, xmm12
000070dabbdd5a12  mulpd xmm6, xmm11
000070dabbdd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000070dabbdd5a1c  ptest xmm5, xmm5
000070dabbdd5a21  jnz 0x000070DABBDD6CC5
000070dabbdd5a27  movaps xmm12, [r15+0x2A0]
000070dabbdd5a2f  vmovaps [rsp+0x80], xmm12
000070dabbdd5a38  vmovaps xmm11, [rsp+0x80]
000070dabbdd5a41  por xmm12, xmm11
000070dabbdd5a46  movaps xmm11, [r15+0x250]
000070dabbdd5a4e  vmovaps [rsp+0x80], xmm11
000070dabbdd5a57  vmovaps xmm5, [rsp+0x80]
000070dabbdd5a60  por xmm11, xmm5
000070dabbdd5a65  vmovaps xmm4, [rsp+0x70]
000070dabbdd5a6b  vpermilpd xmm4, xmm4, 0x00
000070dabbdd5a71  movaps xmm3, xmm5
000070dabbdd5a74  mulpd xmm3, xmm4
000070dabbdd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000070dabbdd5a7d  ptest xmm2, xmm2
000070dabbdd5a82  jnz 0x000070DABBDD6E07
000070dabbdd5a88  mov [rsp+0x80], rax
000070dabbdd5a90  xor eax, eax
000070dabbdd5a92  mov r14d, 0x200
000070dabbdd5a98  cmp r12, r14
000070dabbdd5a9b  cmc
000070dabbdd5a9c  lahf
000070dabbdd5a9d  seto al
000070dabbdd5aa0  mov [r15+0x108], eax
000070dabbdd5aa7  movaps xmm5, xmm8
000070dabbdd5aab  addpd xmm5, xmm15
000070dabbdd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000070dabbdd5ab5  ptest xmm4, xmm4
000070dabbdd5aba  jnz 0x000070DABBDD6F47
000070dabbdd5ac0  movaps xmm8, [r15+0x1B0]
000070dabbdd5ac8  movaps xmm4, xmm9
000070dabbdd5acc  addpd xmm4, xmm8
000070dabbdd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000070dabbdd5ad6  ptest xmm2, xmm2
000070dabbdd5adb  jnz 0x000070DABBDD7089
000070dabbdd5ae1  movaps xmm9, xmm10
000070dabbdd5ae5  addpd xmm9, xmm8
000070dabbdd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000070dabbdd5af0  ptest xmm2, xmm2
000070dabbdd5af5  jnz 0x000070DABBDD71CB
000070dabbdd5afb  movaps xmm10, [r15+0x2F0]
000070dabbdd5b03  vmovaps [rsp+0x90], xmm10
000070dabbdd5b0c  vmovaps xmm8, [rsp+0x90]
000070dabbdd5b15  por xmm10, xmm8
000070dabbdd5b1a  movaps xmm8, [r15+0x2E0]
000070dabbdd5b22  vmovaps [rsp+0x90], xmm8
000070dabbdd5b2b  vmovaps xmm2, [rsp+0x90]
000070dabbdd5b34  por xmm8, xmm2
000070dabbdd5b39  movaps xmm2, [r15+0x2D0]
000070dabbdd5b41  vmovaps [rsp+0x90], xmm2
000070dabbdd5b4a  vmovaps [rsp+0xA0], xmm1
000070dabbdd5b53  vmovaps xmm1, [rsp+0x90]
000070dabbdd5b5c  por xmm2, xmm1
000070dabbdd5b60  movaps xmm1, [r15+0x200]
000070dabbdd5b68  vmovaps [rsp+0x90], xmm1
000070dabbdd5b71  vmovaps [rsp+0xB0], xmm15
000070dabbdd5b7a  vmovaps xmm15, [rsp+0x90]
000070dabbdd5b83  por xmm1, xmm15
000070dabbdd5b88  movaps xmm15, [r15+0x1C0]
000070dabbdd5b90  vmovaps [rsp+0x90], xmm15
000070dabbdd5b99  vmovaps [rsp+0xC0], xmm1
000070dabbdd5ba2  vmovaps xmm1, [rsp+0x90]
000070dabbdd5bab  por xmm15, xmm1
000070dabbdd5bb0  movaps xmm1, [r15+0x190]
000070dabbdd5bb8  vmovaps [rsp+0x90], xmm1
000070dabbdd5bc1  vmovaps [rsp+0xD0], xmm15
000070dabbdd5bca  vmovaps xmm15, [rsp+0x90]
000070dabbdd5bd3  por xmm1, xmm15
000070dabbdd5bd8  movaps xmm15, [r15+0x300]
000070dabbdd5be0  vmovaps [rsp+0x90], xmm15
000070dabbdd5be9  vmovaps [rsp+0xE0], xmm1
000070dabbdd5bf2  vmovaps xmm1, [rsp+0x90]
000070dabbdd5bfb  por xmm15, xmm1
000070dabbdd5c00  mov rax, [rsp+0x80]
000070dabbdd5c08  lea r14, [rax+0xA0]
000070dabbdd5c0f  movups xmm1, [r13+r14*1]
000070dabbdd5c15  lea r14, [rax+0xB0]
000070dabbdd5c1c  vmovaps [rsp+0x80], xmm1
000070dabbdd5c25  movups xmm1, [r13+r14*1]
000070dabbdd5c2b  vmovaps [rsp+0x90], xmm1
000070dabbdd5c34  vmovaps [rsp+0xF0], xmm15
000070dabbdd5c3d  vmovaps xmm15, [rsp+0xB0]
000070dabbdd5c46  vmovaps [rsp+0xB0], xmm14
000070dabbdd5c4f  movaps xmm1, xmm6
000070dabbdd5c52  addpd xmm1, xmm15
000070dabbdd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000070dabbdd5c5c  ptest xmm14, xmm14
000070dabbdd5c62  jnz 0x000070DABBDD7323
000070dabbdd5c68  lea r14, [rax+0xF0]
000070dabbdd5c6f  movups xmm15, [r13+r14*1]
000070dabbdd5c75  movaps xmm14, xmm4
000070dabbdd5c79  addpd xmm14, xmm3
000070dabbdd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000070dabbdd5c84  ptest xmm6, xmm6
000070dabbdd5c89  jnz 0x000070DABBDD746E
000070dabbdd5c8f  movaps xmm6, xmm9
000070dabbdd5c93  addpd xmm6, xmm7
000070dabbdd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000070dabbdd5c9c  ptest xmm4, xmm4
000070dabbdd5ca1  jnz 0x000070DABBDD75B0
000070dabbdd5ca7  vmovaps xmm9, [rsp+0x70]
000070dabbdd5cad  vpermilpd xmm9, xmm9, 0x00
000070dabbdd5cb3  vmovaps xmm4, [rsp+0x90]
000070dabbdd5cbc  movaps xmm7, xmm4
000070dabbdd5cbf  mulpd xmm7, xmm9
000070dabbdd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000070dabbdd5cc9  ptest xmm3, xmm3
000070dabbdd5cce  jnz 0x000070DABBDD76F1
000070dabbdd5cd4  vmovaps xmm9, [rsp+0x50]
000070dabbdd5cda  vpermilpd xmm9, xmm9, 0x00
000070dabbdd5ce0  movaps xmm4, xmm15
000070dabbdd5ce4  mulpd xmm4, xmm9
000070dabbdd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000070dabbdd5cee  ptest xmm3, xmm3
000070dabbdd5cf3  jnz 0x000070DABBDD7832
000070dabbdd5cf9  lea r14, [rax+0xE0]
000070dabbdd5d00  movups xmm15, [r13+r14*1]
000070dabbdd5d06  vmovaps xmm9, [rsp+0x70]
000070dabbdd5d0c  vpermilpd xmm9, xmm9, 0x00
000070dabbdd5d12  vmovaps [rsp+0x70], xmm1
000070dabbdd5d18  vmovaps xmm1, [rsp+0x80]
000070dabbdd5d21  vmovaps [rsp+0x80], xmm15
000070dabbdd5d2a  movaps xmm3, xmm1
000070dabbdd5d2d  mulpd xmm3, xmm9
000070dabbdd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000070dabbdd5d37  ptest xmm15, xmm15
000070dabbdd5d3d  jnz 0x000070DABBDD797E
000070dabbdd5d43  vmovaps xmm1, [rsp+0xF0]
000070dabbdd5d4c  vmovaps xmm15, [rsp+0xF0]
000070dabbdd5d55  por xmm1, xmm15
000070dabbdd5d5a  movaps [r15+0x300], xmm1
000070dabbdd5d62  vmovaps xmm15, [rsp+0xE0]
000070dabbdd5d6b  vmovaps xmm9, [rsp+0xE0]
000070dabbdd5d74  por xmm15, xmm9
000070dabbdd5d79  movaps [r15+0x190], xmm15
000070dabbdd5d81  vmovaps xmm9, [rsp+0x50]
000070dabbdd5d87  vpermilpd xmm9, xmm9, 0x00
000070dabbdd5d8d  vmovaps [rsp+0x90], xmm1
000070dabbdd5d96  vmovaps [rsp+0xE0], xmm15
000070dabbdd5d9f  vmovaps xmm15, [rsp+0x80]
000070dabbdd5da8  vmovaps [rsp+0x80], xmm14
000070dabbdd5db1  movaps xmm1, xmm15
000070dabbdd5db5  mulpd xmm1, xmm9
000070dabbdd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000070dabbdd5dbf  ptest xmm14, xmm14
000070dabbdd5dc5  jnz 0x000070DABBDD7ABF
000070dabbdd5dcb  lea r14, [rax+0x90]
000070dabbdd5dd2  movups xmm15, [r13+r14*1]
000070dabbdd5dd8  vmovaps xmm14, [rsp+0xD0]
000070dabbdd5de1  vmovaps xmm9, [rsp+0xD0]
000070dabbdd5dea  por xmm14, xmm9
000070dabbdd5def  movaps [r15+0x1C0], xmm14
000070dabbdd5df7  vmovaps xmm9, [rsp+0xC0]
000070dabbdd5e00  vmovaps [rsp+0xD0], xmm1
000070dabbdd5e09  vmovaps xmm1, [rsp+0xC0]
000070dabbdd5e12  por xmm9, xmm1
000070dabbdd5e17  movaps [r15+0x200], xmm9
000070dabbdd5e1f  vmovaps [rsp+0xC0], xmm2
000070dabbdd5e28  vmovaps xmm1, [rsp+0xC0]
000070dabbdd5e31  por xmm2, xmm1
000070dabbdd5e35  movaps [r15+0x2D0], xmm2
000070dabbdd5e3d  vmovaps [rsp+0xC0], xmm8
000070dabbdd5e46  vmovaps xmm1, [rsp+0xC0]
000070dabbdd5e4f  por xmm8, xmm1
000070dabbdd5e54  movaps [r15+0x2E0], xmm8
000070dabbdd5e5c  vmovaps [rsp+0xC0], xmm15
000070dabbdd5e65  movaps xmm1, xmm5
000070dabbdd5e68  addpd xmm1, xmm7
000070dabbdd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000070dabbdd5e71  ptest xmm15, xmm15
000070dabbdd5e77  jnz 0x000070DABBDD7C0B
000070dabbdd5e7d  vmovaps xmm15, [rsp+0x50]
000070dabbdd5e83  vpermilpd xmm15, xmm15, 0x00
000070dabbdd5e89  vmovaps xmm5, [rsp+0xC0]
000070dabbdd5e92  vmovaps [rsp+0xC0], xmm1
000070dabbdd5e9b  movaps xmm7, xmm5
000070dabbdd5e9e  mulpd xmm7, xmm15
000070dabbdd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000070dabbdd5ea8  ptest xmm1, xmm1
000070dabbdd5ead  jnz 0x000070DABBDD7D4B
000070dabbdd5eb3  lea r14, [rax+0x80]
000070dabbdd5eba  movups xmm1, [r13+r14*1]
000070dabbdd5ec0  vmovaps xmm5, [rsp+0x70]
000070dabbdd5ec6  vmovaps [rsp+0x70], xmm1
000070dabbdd5ecc  movaps xmm15, xmm5
000070dabbdd5ed0  addpd xmm15, xmm3
000070dabbdd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000070dabbdd5edb  ptest xmm1, xmm1
000070dabbdd5ee0  jnz 0x000070DABBDD7E96
000070dabbdd5ee6  vmovaps xmm5, [rsp+0x80]
000070dabbdd5eef  movaps xmm1, xmm5
000070dabbdd5ef2  addpd xmm1, xmm4
000070dabbdd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000070dabbdd5efb  ptest xmm3, xmm3
000070dabbdd5f00  jnz 0x000070DABBDD7FD8
000070dabbdd5f06  vmovaps [rsp+0x80], xmm10
000070dabbdd5f0f  vmovaps xmm5, [rsp+0x80]
000070dabbdd5f18  por xmm10, xmm5
000070dabbdd5f1d  movaps [r15+0x2F0], xmm10
000070dabbdd5f25  vmovaps xmm5, [rsp+0x50]
000070dabbdd5f2b  vpermilpd xmm5, xmm5, 0x00
000070dabbdd5f31  vmovaps xmm3, [rsp+0x70]
000070dabbdd5f37  vmovaps [rsp+0x50], xmm1
000070dabbdd5f3d  movaps xmm4, xmm3
000070dabbdd5f40  mulpd xmm4, xmm5
000070dabbdd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000070dabbdd5f49  ptest xmm1, xmm1
000070dabbdd5f4e  jnz 0x000070DABBDD8118
000070dabbdd5f54  lea r14, [rax+0xD0]
000070dabbdd5f5b  movups xmm1, [r13+r14*1]
000070dabbdd5f61  vmovaps xmm3, [rsp+0xD0]
000070dabbdd5f6a  vmovaps [rsp+0x70], xmm1
000070dabbdd5f70  movaps xmm5, xmm6
000070dabbdd5f73  addpd xmm5, xmm3
000070dabbdd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000070dabbdd5f7c  ptest xmm1, xmm1
000070dabbdd5f81  jnz 0x000070DABBDD8262
000070dabbdd5f87  vmovaps xmm1, [rsp+0x60]
000070dabbdd5f8d  vpermilpd xmm1, xmm1, 0x00
000070dabbdd5f93  movaps xmm6, xmm9
000070dabbdd5f97  mulpd xmm6, xmm1
000070dabbdd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000070dabbdd5fa0  ptest xmm3, xmm3
000070dabbdd5fa5  jnz 0x000070DABBDD83A2
000070dabbdd5fab  movaps [r15+0x260], xmm6
000070dabbdd5fb3  vxorps xmm1, xmm1, xmm1
000070dabbdd5fb7  vpbroadcastq xmm1, xmm1
000070dabbdd5fbc  movaps [r15+0x1B0], xmm1
000070dabbdd5fc4  vmovaps xmm1, [rsp+0x60]
000070dabbdd5fca  vpermilpd xmm1, xmm1, 0x00
000070dabbdd5fd0  vmovaps xmm3, [rsp+0x70]
000070dabbdd5fd6  vmovaps [rsp+0x70], xmm15
000070dabbdd5fdc  movaps xmm9, xmm3
000070dabbdd5fe0  mulpd xmm9, xmm1
000070dabbdd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000070dabbdd5feb  ptest xmm15, xmm15
000070dabbdd5ff1  jnz 0x000070DABBDD84E3
000070dabbdd5ff7  lea r14, [rax+0xC0]
000070dabbdd5ffe  movups xmm1, [r13+r14*1]
000070dabbdd6004  vmovaps xmm3, [rsp+0xC0]
000070dabbdd600d  vmovaps [rsp+0x80], xmm1
000070dabbdd6016  movaps xmm15, xmm3
000070dabbdd601a  addpd xmm15, xmm7
000070dabbdd601f  vcmppd xmm1, xmm15, xmm15, 0x03
000070dabbdd6025  ptest xmm1, xmm1
000070dabbdd602a  jnz 0x000070DABBDD862F
000070dabbdd6030  vmovaps [rsp+0xC0], xmm13
000070dabbdd6039  vmovaps xmm1, [rsp+0xC0]
000070dabbdd6042  por xmm13, xmm1
000070dabbdd6047  movaps [r15+0x270], xmm13
000070dabbdd604f  vmovaps xmm1, [rsp+0xB0]
000070dabbdd6058  vmovaps xmm7, [rsp+0xB0]
000070dabbdd6061  por xmm1, xmm7
000070dabbdd6065  movaps [r15+0x1A0], xmm1
000070dabbdd606d  vmovaps xmm1, [rsp+0x60]
000070dabbdd6073  vpermilpd xmm1, xmm1, 0x00
000070dabbdd6079  vmovaps [rsp+0xB0], xmm1
000070dabbdd6082  vmovaps xmm1, [rsp+0x80]
000070dabbdd608b  vmovaps [rsp+0x80], xmm15
000070dabbdd6094  vmovaps xmm15, [rsp+0xB0]
000070dabbdd609d  vmovaps [rsp+0xB0], xmm14
000070dabbdd60a6  movaps xmm3, xmm1
000070dabbdd60a9  mulpd xmm3, xmm15
000070dabbdd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000070dabbdd60b3  ptest xmm14, xmm14
000070dabbdd60b9  jnz 0x000070DABBDD8771
000070dabbdd60bf  lea r14, [rax+0x20]
000070dabbdd60c3  movups xmm1, [r13+r14*1]
000070dabbdd60c9  movaps [r15+0x110], xmm1
000070dabbdd60d1  vmovaps xmm14, [rsp+0x70]
000070dabbdd60d7  vmovaps [rsp+0x70], xmm1
000070dabbdd60dd  movaps xmm15, xmm14
000070dabbdd60e1  addpd xmm15, xmm4
000070dabbdd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000070dabbdd60ec  ptest xmm1, xmm1
000070dabbdd60f1  jnz 0x000070DABBDD88BC
000070dabbdd60f7  vmovaps xmm1, [rsp+0x60]
000070dabbdd60fd  vpermilpd xmm1, xmm1, 0x00
000070dabbdd6103  movaps xmm14, xmm2
000070dabbdd6107  mulpd xmm14, xmm1
000070dabbdd610c  vcmppd xmm4, xmm14, xmm14, 0x03
000070dabbdd6112  ptest xmm4, xmm4
000070dabbdd6117  jnz 0x000070DABBDD89FF
000070dabbdd611d  vmovaps xmm4, [rsp+0x50]
000070dabbdd6123  movaps xmm1, xmm4
000070dabbdd6126  addpd xmm1, xmm9
000070dabbdd612b  vcmppd xmm2, xmm1, xmm1, 0x03
000070dabbdd6130  ptest xmm2, xmm2
000070dabbdd6135  jnz 0x000070DABBDD8B41
000070dabbdd613b  vmovaps xmm9, [rsp+0x30]
000070dabbdd6141  vpermilpd xmm9, xmm9, 0x00
000070dabbdd6147  vmovaps xmm2, [rsp+0x70]
000070dabbdd614d  vmovaps [rsp+0x50], xmm1
000070dabbdd6153  movaps xmm4, xmm2
000070dabbdd6156  mulpd xmm4, xmm9
000070dabbdd615b  vcmppd xmm1, xmm4, xmm4, 0x03
000070dabbdd6160  ptest xmm1, xmm1
000070dabbdd6165  jnz 0x000070DABBDD8C82
000070dabbdd616b  vmovaps xmm1, [rsp+0x30]
000070dabbdd6171  vpermilpd xmm1, xmm1, 0x00
000070dabbdd6177  vmovaps xmm2, [rsp+0x90]
000070dabbdd6180  vmovaps [rsp+0x60], xmm15
000070dabbdd6186  movaps xmm9, xmm2
000070dabbdd618a  mulpd xmm9, xmm1
000070dabbdd618f  vcmppd xmm15, xmm9, xmm9, 0x03
000070dabbdd6195  ptest xmm15, xmm15
000070dabbdd619b  jnz 0x000070DABBDD8DC3
000070dabbdd61a1  vmovaps xmm15, [rsp+0x80]
000070dabbdd61aa  movaps xmm1, xmm15
000070dabbdd61ae  addpd xmm1, xmm6
000070dabbdd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000070dabbdd61b7  ptest xmm2, xmm2
000070dabbdd61bc  jnz 0x000070DABBDD8F05
000070dabbdd61c2  movaps xmm15, xmm5
000070dabbdd61c6  addpd xmm15, xmm3
000070dabbdd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000070dabbdd61d1  ptest xmm6, xmm6
000070dabbdd61d6  jnz 0x000070DABBDD9046
000070dabbdd61dc  vmovaps xmm6, [rsp+0x30]
000070dabbdd61e2  vpermilpd xmm6, xmm6, 0x00
000070dabbdd61e8  movaps xmm5, xmm8
000070dabbdd61ec  mulpd xmm5, xmm6
000070dabbdd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000070dabbdd61f5  ptest xmm3, xmm3
000070dabbdd61fa  jnz 0x000070DABBDD9188
000070dabbdd6200  vmovaps xmm8, [rsp+0x30]
000070dabbdd6206  vpermilpd xmm8, xmm8, 0x00
000070dabbdd620c  movaps xmm6, xmm10
000070dabbdd6210  mulpd xmm6, xmm8
000070dabbdd6215  vcmppd xmm3, xmm6, xmm6, 0x03
000070dabbdd621a  ptest xmm3, xmm3
000070dabbdd621f  jnz 0x000070DABBDD92C9
000070dabbdd6225  vmovaps xmm8, [rsp+0x60]
000070dabbdd622b  movaps xmm10, xmm8
000070dabbdd622f  addpd xmm10, xmm14
000070dabbdd6234  vcmppd xmm3, xmm10, xmm10, 0x03
000070dabbdd623a  ptest xmm3, xmm3
000070dabbdd623f  jnz 0x000070DABBDD940B
000070dabbdd6245  vmovaps xmm8, [rsp+0x50]
000070dabbdd624b  movaps xmm14, xmm8
000070dabbdd624f  addpd xmm14, xmm4
000070dabbdd6254  vcmppd xmm3, xmm14, xmm14, 0x03
000070dabbdd625a  ptest xmm3, xmm3
000070dabbdd625f  jnz 0x000070DABBDD954F
000070dabbdd6265  vmovaps xmm8, [rsp+0x40]
000070dabbdd626b  vpermilpd xmm8, xmm8, 0x00
000070dabbdd6271  movaps xmm4, xmm13
000070dabbdd6275  mulpd xmm4, xmm8
000070dabbdd627a  vcmppd xmm3, xmm4, xmm4, 0x03
000070dabbdd627f  ptest xmm3, xmm3
000070dabbdd6284  jnz 0x000070DABBDD9692
000070dabbdd628a  movaps xmm13, xmm15
000070dabbdd628e  addpd xmm13, xmm9
000070dabbdd6293  vcmppd xmm8, xmm13, xmm13, 0x03
000070dabbdd6299  ptest xmm8, xmm8
000070dabbdd629f  jnz 0x000070DABBDD97D4
000070dabbdd62a5  movaps xmm15, xmm1
000070dabbdd62a9  addpd xmm15, xmm5
000070dabbdd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000070dabbdd62b4  ptest xmm9, xmm9
000070dabbdd62ba  jnz 0x000070DABBDD9918
000070dabbdd62c0  vmovaps [rsp+0x30], xmm11
000070dabbdd62c6  vmovaps xmm1, [rsp+0x30]
000070dabbdd62cc  por xmm11, xmm1
000070dabbdd62d1  movaps [r15+0x250], xmm11
000070dabbdd62d9  vmovaps [rsp+0x30], xmm12
000070dabbdd62df  vmovaps xmm1, [rsp+0x30]
000070dabbdd62e5  por xmm12, xmm1
000070dabbdd62ea  movaps [r15+0x2A0], xmm12
000070dabbdd62f2  vmovaps xmm1, [rsp+0xA0]
000070dabbdd62fb  vmovaps xmm11, [rsp+0xA0]
000070dabbdd6304  por xmm1, xmm11
000070dabbdd6309  movaps [r15+0x1D0], xmm1
000070dabbdd6311  lea r14, [rax+0x40]
000070dabbdd6315  movups xmm1, [r13+r14*1]
000070dabbdd631b  movaps [r15+0x2C0], xmm1
000070dabbdd6323  vmovaps xmm11, [rsp+0x40]
000070dabbdd6329  vpermilpd xmm11, xmm11, 0x00
000070dabbdd632f  vmovaps xmm8, [rsp+0xE0]
000070dabbdd6338  movaps xmm9, xmm8
000070dabbdd633c  mulpd xmm9, xmm11
000070dabbdd6341  vcmppd xmm5, xmm9, xmm9, 0x03
000070dabbdd6347  ptest xmm5, xmm5
000070dabbdd634c  jnz 0x000070DABBDD9A64
000070dabbdd6352  movaps xmm11, xmm10
000070dabbdd6356  addpd xmm11, xmm6
000070dabbdd635b  vcmppd xmm8, xmm11, xmm11, 0x03
000070dabbdd6361  ptest xmm8, xmm8
000070dabbdd6367  jnz 0x000070DABBDD9BA8
000070dabbdd636d  movaps xmm10, xmm14
000070dabbdd6371  addpd xmm10, xmm4
000070dabbdd6376  vcmppd xmm8, xmm10, xmm10, 0x03
000070dabbdd637c  ptest xmm8, xmm8
000070dabbdd6382  jnz 0x000070DABBDD9CEB
000070dabbdd6388  vmovaps xmm14, [rsp+0x40]
000070dabbdd638e  vpermilpd xmm14, xmm14, 0x00
000070dabbdd6394  movaps xmm8, xmm1
000070dabbdd6398  mulpd xmm8, xmm14
000070dabbdd639d  vcmppd xmm6, xmm8, xmm8, 0x03
000070dabbdd63a3  ptest xmm6, xmm6
000070dabbdd63a8  jnz 0x000070DABBDD9E2E
000070dabbdd63ae  movaps xmm1, [r15+0x2B0]
000070dabbdd63b6  vmovaps xmm14, [rsp+0x40]
000070dabbdd63bc  vpermilpd xmm14, xmm14, 0x00
000070dabbdd63c2  movaps xmm6, xmm1
000070dabbdd63c5  mulpd xmm6, xmm14
000070dabbdd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000070dabbdd63cf  ptest xmm5, xmm5
000070dabbdd63d4  jnz 0x000070DABBDD9F71
000070dabbdd63da  vmovaps xmm1, [rsp+0x10]
000070dabbdd63e0  vpermilpd xmm1, xmm1, 0x00
000070dabbdd63e6  movaps xmm14, xmm12
000070dabbdd63ea  mulpd xmm14, xmm1
000070dabbdd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000070dabbdd63f5  ptest xmm5, xmm5
000070dabbdd63fa  jnz 0x000070DABBDDA0B2
000070dabbdd6400  movaps xmm1, xmm13
000070dabbdd6404  addpd xmm1, xmm9
000070dabbdd6409  vcmppd xmm12, xmm1, xmm1, 0x03
000070dabbdd640e  ptest xmm12, xmm12
000070dabbdd6414  jnz 0x000070DABBDDA1F5
000070dabbdd641a  vmovaps xmm13, [rsp+0x10]
000070dabbdd6420  vpermilpd xmm13, xmm13, 0x00
000070dabbdd6426  movaps xmm12, xmm7
000070dabbdd642a  mulpd xmm12, xmm13
000070dabbdd642f  vcmppd xmm9, xmm12, xmm12, 0x03
000070dabbdd6435  ptest xmm9, xmm9
000070dabbdd643b  jnz 0x000070DABBDDA337
000070dabbdd6441  movaps xmm13, xmm15
000070dabbdd6445  addpd xmm13, xmm8
000070dabbdd644a  vcmppd xmm9, xmm13, xmm13, 0x03
000070dabbdd6450  ptest xmm9, xmm9
000070dabbdd6456  jnz 0x000070DABBDDA47A
000070dabbdd645c  movaps xmm15, [r15+0x290]
000070dabbdd6464  vmovaps xmm9, [rsp+0x10]
000070dabbdd646a  vpermilpd xmm9, xmm9, 0x00
000070dabbdd6470  movaps xmm8, xmm15
000070dabbdd6474  mulpd xmm8, xmm9
000070dabbdd6479  vcmppd xmm7, xmm8, xmm8, 0x03
000070dabbdd647f  ptest xmm7, xmm7
000070dabbdd6484  jnz 0x000070DABBDDA5BE
000070dabbdd648a  movaps xmm15, xmm11
000070dabbdd648e  addpd xmm15, xmm6
000070dabbdd6493  vcmppd xmm9, xmm15, xmm15, 0x03
000070dabbdd6499  ptest xmm9, xmm9
000070dabbdd649f  jnz 0x000070DABBDDA702
000070dabbdd64a5  movaps xmm11, [r15+0x1E0]
000070dabbdd64ad  vmovaps xmm9, [rsp+0x10]
000070dabbdd64b3  vpermilpd xmm9, xmm9, 0x00
000070dabbdd64b9  movaps xmm7, xmm11
000070dabbdd64bd  mulpd xmm7, xmm9
000070dabbdd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000070dabbdd64c7  ptest xmm6, xmm6
000070dabbdd64cc  jnz 0x000070DABBDDA845
000070dabbdd64d2  movaps xmm11, xmm10
000070dabbdd64d6  addpd xmm11, xmm14
000070dabbdd64db  vcmppd xmm9, xmm11, xmm11, 0x03
000070dabbdd64e1  ptest xmm9, xmm9
000070dabbdd64e7  jnz 0x000070DABBDDA987
000070dabbdd64ed  lea r14, [rax+0x70]
000070dabbdd64f1  movups xmm14, [r13+r14*1]
000070dabbdd64f7  movaps [r15+0x240], xmm14
000070dabbdd64ff  movaps xmm10, xmm1
000070dabbdd6503  addpd xmm10, xmm12
000070dabbdd6508  vcmppd xmm9, xmm10, xmm10, 0x03
000070dabbdd650e  ptest xmm9, xmm9
000070dabbdd6514  jnz 0x000070DABBDDAAD5
000070dabbdd651a  movaps [r15+0x170], xmm10
000070dabbdd6522  vmovaps xmm1, [rsp+0x20]
000070dabbdd6528  vpermilpd xmm1, xmm1, 0x00
000070dabbdd652e  movaps xmm12, xmm14
000070dabbdd6532  mulpd xmm12, xmm1
000070dabbdd6537  vcmppd xmm9, xmm12, xmm12, 0x03
000070dabbdd653d  ptest xmm9, xmm9
000070dabbdd6543  jnz 0x000070DABBDDAC18
000070dabbdd6549  vmovaps xmm1, [rsp+0x20]
000070dabbdd654f  vpermilpd xmm1, xmm1, 0x00
000070dabbdd6555  vmovaps xmm9, [rsp+0xB0]
000070dabbdd655e  movaps xmm14, xmm9
000070dabbdd6562  mulpd xmm14, xmm1
000070dabbdd6567  vcmppd xmm6, xmm14, xmm14, 0x03
000070dabbdd656d  ptest xmm6, xmm6
000070dabbdd6572  jnz 0x000070DABBDDAD5B
000070dabbdd6578  movaps [r15+0x180], xmm14
000070dabbdd6580  movaps xmm1, xmm13
000070dabbdd6584  addpd xmm1, xmm8
000070dabbdd6589  vcmppd xmm9, xmm1, xmm1, 0x03
000070dabbdd658e  ptest xmm9, xmm9
000070dabbdd6594  jnz 0x000070DABBDDAE9E
000070dabbdd659a  movaps [r15+0x210], xmm1
000070dabbdd65a2  movups xmm13, [r13+rax*1]
000070dabbdd65a8  lea r14, [rax+0x10]
000070dabbdd65ac  movups xmm9, [r13+r14*1]
000070dabbdd65b2  movaps [r15+0x230], xmm9
000070dabbdd65ba  movaps xmm8, xmm15
000070dabbdd65be  addpd xmm8, xmm7
000070dabbdd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000070dabbdd65c9  ptest xmm6, xmm6
000070dabbdd65ce  jnz 0x000070DABBDDAFF4
000070dabbdd65d4  movaps [r15+0x130], xmm8
000070dabbdd65dc  vmovaps xmm15, [rsp+0x20]
000070dabbdd65e2  vpermilpd xmm15, xmm15, 0x00
000070dabbdd65e8  movaps xmm7, xmm9
000070dabbdd65ec  mulpd xmm7, xmm15
000070dabbdd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000070dabbdd65f6  ptest xmm6, xmm6
000070dabbdd65fb  jnz 0x000070DABBDDB137
000070dabbdd6601  movaps [r15+0x220], xmm7
000070dabbdd6609  vmovaps xmm15, [rsp+0x20]
000070dabbdd660f  vpermilpd xmm15, xmm15, 0x00
000070dabbdd6615  movaps xmm9, xmm13
000070dabbdd6619  mulpd xmm9, xmm15
000070dabbdd661e  vcmppd xmm6, xmm9, xmm9, 0x03
000070dabbdd6624  ptest xmm6, xmm6
000070dabbdd6629  jnz 0x000070DABBDDB279
000070dabbdd662f  movaps xmm15, xmm11
000070dabbdd6633  addpd xmm15, xmm12
000070dabbdd6638  vcmppd xmm13, xmm15, xmm15, 0x03
000070dabbdd663e  ptest xmm13, xmm13
000070dabbdd6644  jnz 0x000070DABBDDB3BD
000070dabbdd664a  movaps [r15+0x140], xmm15
000070dabbdd6652  movaps xmm13, xmm10
000070dabbdd6656  addpd xmm13, xmm14
000070dabbdd665b  vcmppd xmm12, xmm13, xmm13, 0x03
000070dabbdd6661  ptest xmm12, xmm12
000070dabbdd6667  jnz 0x000070DABBDDB501
000070dabbdd666d  movaps [r15+0x150], xmm13
000070dabbdd6675  movaps xmm14, xmm1
000070dabbdd6679  addpd xmm14, xmm7
000070dabbdd667e  vcmppd xmm12, xmm14, xmm14, 0x03
000070dabbdd6684  ptest xmm12, xmm12
000070dabbdd668a  jnz 0x000070DABBDDB645
000070dabbdd6690  movaps [r15+0x160], xmm14
000070dabbdd6698  movaps xmm1, xmm8
000070dabbdd669c  addpd xmm1, xmm9
000070dabbdd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000070dabbdd66a6  ptest xmm12, xmm12
000070dabbdd66ac  jnz 0x000070DABBDDB787
000070dabbdd66b2  movaps [r15+0x120], xmm1
000070dabbdd66ba  movups [r13+r11*1], xmm15
000070dabbdd66c0  lea rax, [r11+0x10]
000070dabbdd66c4  movups [r13+rax*1], xmm13
000070dabbdd66ca  lea rax, [r11+0x20]
000070dabbdd66ce  movups [r13+rax*1], xmm14
000070dabbdd66d4  lea rax, [r11+0x30]
000070dabbdd66d8  movups [r13+rax*1], xmm1
000070dabbdd66de  mov eax, [r15+0x108]
000070dabbdd66e5  sahf
000070dabbdd66e6  jnz 0x000070DABBDD6718
000070dabbdd66e8  cmp dword ptr [r15+0x318], 0x00
000070dabbdd66f0  jz 0x000070DABBDDB900
000070dabbdd66f6  nop [rax+rax*1], ax
000070dabbdd66ff  nop [rax+rax*1], eax
000070dabbdd6707  mov eax, 0x410444
000070dabbdd670c  mov [r15+0x100], rax
000070dabbdd6713  jmp 0x000070DABBBFE110
000070dabbdd6718  cmp dword ptr [r15+0x318], 0x00
000070dabbdd6720  jz 0x000070DABBDD57E0
000070dabbdd6726  nop [rax+rax*1], ax
000070dabbdd672f  nop [rax+rax*1], eax
000070dabbdd6737  mov eax, 0x410278
000070dabbdd673c  mov [r15+0x100], rax
000070dabbdd6743  jmp 0x000070DABBBFE110
000070dabbdd6748  int3
000070dabbdd6749  call 0x000070DABBC0A4B0
000070dabbdd674e  jmp 0x000070DABBDD5828
000070dabbdd6753  call 0x000070DABBC09240
000070dabbdd6758  jmp 0x000070DABBDD5832
000070dabbdd675d  call 0x000070DABBC0A4B0
000070dabbdd6762  jmp 0x000070DABBDD588F
000070dabbdd6767  call 0x000070DABBC09240
000070dabbdd676c  jmp 0x000070DABBDD5899
000070dabbdd6771  call 0x000070DABBC0A4B0
000070dabbdd6776  jmp 0x000070DABBDD58DD
000070dabbdd677b  call 0x000070DABBC09240
000070dabbdd6780  jmp 0x000070DABBDD58E7
000070dabbdd6785  call 0x000070DABBCB47C0
000070dabbdd678a  jmp 0x000070DABBDD5926
000070dabbdd678f  call 0x000070DABBC0B720
000070dabbdd6794  jmp 0x000070DABBDD593A
000070dabbdd6799  call 0x000070DABBCBFC30
000070dabbdd679e  jmp 0x000070DABBDD5958
000070dabbdd67a3  call 0x000070DABBCBE9C0
000070dabbdd67a8  jmp 0x000070DABBDD5962
000070dabbdd67ad  call 0x000070DABBCBD750
000070dabbdd67b2  jmp 0x000070DABBDD596C
000070dabbdd67b7  sub rsp, 0x08
000070dabbdd67bb  push rax
000070dabbdd67bc  push rcx
000070dabbdd67bd  push rdx
000070dabbdd67be  push rdi
000070dabbdd67bf  push rsi
000070dabbdd67c0  push r8
000070dabbdd67c2  push r9
000070dabbdd67c4  push r10
000070dabbdd67c6  push r11
000070dabbdd67c8  sub rsp, 0xF0
000070dabbdd67cf  vmovaps [rsp], xmm0
000070dabbdd67d4  vmovaps [rsp+0x10], xmm1
000070dabbdd67da  vmovaps [rsp+0x20], xmm2
000070dabbdd67e0  vmovaps [rsp+0x30], xmm3
000070dabbdd67e6  vmovaps [rsp+0x40], xmm4
000070dabbdd67ec  vmovaps [rsp+0x50], xmm5
000070dabbdd67f2  vmovaps [rsp+0x60], xmm6
000070dabbdd67f8  vmovaps [rsp+0x70], xmm7
000070dabbdd67fe  vmovaps [rsp+0x80], xmm9
000070dabbdd6807  vmovaps [rsp+0x90], xmm10
000070dabbdd6810  vmovaps [rsp+0xA0], xmm11
000070dabbdd6819  vmovaps [rsp+0xB0], xmm12
000070dabbdd6822  vmovaps [rsp+0xC0], xmm13
000070dabbdd682b  vmovaps [rsp+0xD0], xmm14
000070dabbdd6834  vmovaps [rsp+0xE0], xmm15
000070dabbdd683d  sub rsp, 0x30
000070dabbdd6841  movaps [rsp], xmm8
000070dabbdd6846  movaps [rsp+0x10], xmm12
000070dabbdd684c  movaps [rsp+0x20], xmm15
000070dabbdd6852  lea rdi, [rsp]
000070dabbdd6856  mov esi, 0x00
000070dabbdd685b  mov rax, 0x5C2CF7B6F530
000070dabbdd6865  call rax
000070dabbdd6867  movaps xmm8, [rsp]
000070dabbdd686c  add rsp, 0x30
000070dabbdd6870  vmovaps xmm0, [rsp]
000070dabbdd6875  vmovaps xmm1, [rsp+0x10]
000070dabbdd687b  vmovaps xmm2, [rsp+0x20]
000070dabbdd6881  vmovaps xmm3, [rsp+0x30]
000070dabbdd6887  vmovaps xmm4, [rsp+0x40]
000070dabbdd688d  vmovaps xmm5, [rsp+0x50]
000070dabbdd6893  vmovaps xmm6, [rsp+0x60]
000070dabbdd6899  vmovaps xmm7, [rsp+0x70]
000070dabbdd689f  vmovaps xmm9, [rsp+0x80]
000070dabbdd68a8  vmovaps xmm10, [rsp+0x90]
000070dabbdd68b1  vmovaps xmm11, [rsp+0xA0]
000070dabbdd68ba  vmovaps xmm12, [rsp+0xB0]
000070dabbdd68c3  vmovaps xmm13, [rsp+0xC0]
000070dabbdd68cc  vmovaps xmm14, [rsp+0xD0]
000070dabbdd68d5  vmovaps xmm15, [rsp+0xE0]
000070dabbdd68de  add rsp, 0xF0
000070dabbdd68e5  pop r11
000070dabbdd68e7  pop r10
000070dabbdd68e9  pop r9
000070dabbdd68eb  pop r8
000070dabbdd68ed  pop rsi
000070dabbdd68ee  pop rdi
000070dabbdd68ef  pop rdx
000070dabbdd68f0  pop rcx
000070dabbdd68f1  pop rax
000070dabbdd68f2  add rsp, 0x08
000070dabbdd68f6  jmp 0x000070DABBDD599A
000070dabbdd68fb  sub rsp, 0x08
000070dabbdd68ff  push rax
000070dabbdd6900  push rcx
000070dabbdd6901  push rdx
000070dabbdd6902  push rdi
000070dabbdd6903  push rsi
000070dabbdd6904  push r8
000070dabbdd6906  push r9
000070dabbdd6908  push r10
000070dabbdd690a  push r11
000070dabbdd690c  sub rsp, 0xF0
000070dabbdd6913  vmovaps [rsp], xmm0
000070dabbdd6918  vmovaps [rsp+0x10], xmm1
000070dabbdd691e  vmovaps [rsp+0x20], xmm2
000070dabbdd6924  vmovaps [rsp+0x30], xmm3
000070dabbdd692a  vmovaps [rsp+0x40], xmm4
000070dabbdd6930  vmovaps [rsp+0x50], xmm5
000070dabbdd6936  vmovaps [rsp+0x60], xmm6
000070dabbdd693c  vmovaps [rsp+0x70], xmm8
000070dabbdd6942  vmovaps [rsp+0x80], xmm9
000070dabbdd694b  vmovaps [rsp+0x90], xmm10
000070dabbdd6954  vmovaps [rsp+0xA0], xmm11
000070dabbdd695d  vmovaps [rsp+0xB0], xmm12
000070dabbdd6966  vmovaps [rsp+0xC0], xmm13
000070dabbdd696f  vmovaps [rsp+0xD0], xmm14
000070dabbdd6978  vmovaps [rsp+0xE0], xmm15
000070dabbdd6981  sub rsp, 0x30
000070dabbdd6985  movaps [rsp], xmm7
000070dabbdd6989  movaps [rsp+0x10], xmm9
000070dabbdd698f  movaps [rsp+0x20], xmm15
000070dabbdd6995  lea rdi, [rsp]
000070dabbdd6999  mov esi, 0x00
000070dabbdd699e  mov rax, 0x5C2CF7B6F530
000070dabbdd69a8  call rax
000070dabbdd69aa  movaps xmm7, [rsp]
000070dabbdd69ae  add rsp, 0x30
000070dabbdd69b2  vmovaps xmm0, [rsp]
000070dabbdd69b7  vmovaps xmm1, [rsp+0x10]
000070dabbdd69bd  vmovaps xmm2, [rsp+0x20]
000070dabbdd69c3  vmovaps xmm3, [rsp+0x30]
000070dabbdd69c9  vmovaps xmm4, [rsp+0x40]
000070dabbdd69cf  vmovaps xmm5, [rsp+0x50]
000070dabbdd69d5  vmovaps xmm6, [rsp+0x60]
000070dabbdd69db  vmovaps xmm8, [rsp+0x70]
000070dabbdd69e1  vmovaps xmm9, [rsp+0x80]
000070dabbdd69ea  vmovaps xmm10, [rsp+0x90]
000070dabbdd69f3  vmovaps xmm11, [rsp+0xA0]
000070dabbdd69fc  vmovaps xmm12, [rsp+0xB0]
000070dabbdd6a05  vmovaps xmm13, [rsp+0xC0]
000070dabbdd6a0e  vmovaps xmm14, [rsp+0xD0]
000070dabbdd6a17  vmovaps xmm15, [rsp+0xE0]
000070dabbdd6a20  add rsp, 0xF0
000070dabbdd6a27  pop r11
000070dabbdd6a29  pop r10
000070dabbdd6a2b  pop r9
000070dabbdd6a2d  pop r8
000070dabbdd6a2f  pop rsi
000070dabbdd6a30  pop rdi
000070dabbdd6a31  pop rdx
000070dabbdd6a32  pop rcx
000070dabbdd6a33  pop rax
000070dabbdd6a34  add rsp, 0x08
000070dabbdd6a38  jmp 0x000070DABBDD59C8
000070dabbdd6a3d  sub rsp, 0x08
000070dabbdd6a41  push rax
000070dabbdd6a42  push rcx
000070dabbdd6a43  push rdx
000070dabbdd6a44  push rdi
000070dabbdd6a45  push rsi
000070dabbdd6a46  push r8
000070dabbdd6a48  push r9
000070dabbdd6a4a  push r10
000070dabbdd6a4c  push r11
000070dabbdd6a4e  sub rsp, 0xF0
000070dabbdd6a55  vmovaps [rsp], xmm0
000070dabbdd6a5a  vmovaps [rsp+0x10], xmm1
000070dabbdd6a60  vmovaps [rsp+0x20], xmm2
000070dabbdd6a66  vmovaps [rsp+0x30], xmm3
000070dabbdd6a6c  vmovaps [rsp+0x40], xmm4
000070dabbdd6a72  vmovaps [rsp+0x50], xmm5
000070dabbdd6a78  vmovaps [rsp+0x60], xmm6
000070dabbdd6a7e  vmovaps [rsp+0x70], xmm7
000070dabbdd6a84  vmovaps [rsp+0x80], xmm8
000070dabbdd6a8d  vmovaps [rsp+0x90], xmm10
000070dabbdd6a96  vmovaps [rsp+0xA0], xmm11
000070dabbdd6a9f  vmovaps [rsp+0xB0], xmm12
000070dabbdd6aa8  vmovaps [rsp+0xC0], xmm13
000070dabbdd6ab1  vmovaps [rsp+0xD0], xmm14
000070dabbdd6aba  vmovaps [rsp+0xE0], xmm15
000070dabbdd6ac3  sub rsp, 0x30
000070dabbdd6ac7  movaps [rsp], xmm9
000070dabbdd6acc  movaps [rsp+0x10], xmm12
000070dabbdd6ad2  movaps [rsp+0x20], xmm10
000070dabbdd6ad8  lea rdi, [rsp]
000070dabbdd6adc  mov esi, 0x00
000070dabbdd6ae1  mov rax, 0x5C2CF7B6F530
000070dabbdd6aeb  call rax
000070dabbdd6aed  movaps xmm9, [rsp]
000070dabbdd6af2  add rsp, 0x30
000070dabbdd6af6  vmovaps xmm0, [rsp]
000070dabbdd6afb  vmovaps xmm1, [rsp+0x10]
000070dabbdd6b01  vmovaps xmm2, [rsp+0x20]
000070dabbdd6b07  vmovaps xmm3, [rsp+0x30]
000070dabbdd6b0d  vmovaps xmm4, [rsp+0x40]
000070dabbdd6b13  vmovaps xmm5, [rsp+0x50]
000070dabbdd6b19  vmovaps xmm6, [rsp+0x60]
000070dabbdd6b1f  vmovaps xmm7, [rsp+0x70]
000070dabbdd6b25  vmovaps xmm8, [rsp+0x80]
000070dabbdd6b2e  vmovaps xmm10, [rsp+0x90]
000070dabbdd6b37  vmovaps xmm11, [rsp+0xA0]
000070dabbdd6b40  vmovaps xmm12, [rsp+0xB0]
000070dabbdd6b49  vmovaps xmm13, [rsp+0xC0]
000070dabbdd6b52  vmovaps xmm14, [rsp+0xD0]
000070dabbdd6b5b  vmovaps xmm15, [rsp+0xE0]
000070dabbdd6b64  add rsp, 0xF0
000070dabbdd6b6b  pop r11
000070dabbdd6b6d  pop r10
000070dabbdd6b6f  pop r9
000070dabbdd6b71  pop r8
000070dabbdd6b73  pop rsi
000070dabbdd6b74  pop rdi
000070dabbdd6b75  pop rdx
000070dabbdd6b76  pop rcx
000070dabbdd6b77  pop rax
000070dabbdd6b78  add rsp, 0x08
000070dabbdd6b7c  jmp 0x000070DABBDD59EC
000070dabbdd6b81  sub rsp, 0x08
000070dabbdd6b85  push rax
000070dabbdd6b86  push rcx
000070dabbdd6b87  push rdx
000070dabbdd6b88  push rdi
000070dabbdd6b89  push rsi
000070dabbdd6b8a  push r8
000070dabbdd6b8c  push r9
000070dabbdd6b8e  push r10
000070dabbdd6b90  push r11
000070dabbdd6b92  sub rsp, 0xF0
000070dabbdd6b99  vmovaps [rsp], xmm0
000070dabbdd6b9e  vmovaps [rsp+0x10], xmm1
000070dabbdd6ba4  vmovaps [rsp+0x20], xmm2
000070dabbdd6baa  vmovaps [rsp+0x30], xmm3
000070dabbdd6bb0  vmovaps [rsp+0x40], xmm4
000070dabbdd6bb6  vmovaps [rsp+0x50], xmm5
000070dabbdd6bbc  vmovaps [rsp+0x60], xmm6
000070dabbdd6bc2  vmovaps [rsp+0x70], xmm7
000070dabbdd6bc8  vmovaps [rsp+0x80], xmm8
000070dabbdd6bd1  vmovaps [rsp+0x90], xmm9
000070dabbdd6bda  vmovaps [rsp+0xA0], xmm11
000070dabbdd6be3  vmovaps [rsp+0xB0], xmm12
000070dabbdd6bec  vmovaps [rsp+0xC0], xmm13
000070dabbdd6bf5  vmovaps [rsp+0xD0], xmm14
000070dabbdd6bfe  vmovaps [rsp+0xE0], xmm15
000070dabbdd6c07  sub rsp, 0x30
000070dabbdd6c0b  movaps [rsp], xmm10
000070dabbdd6c10  movaps [rsp+0x10], xmm12
000070dabbdd6c16  movaps [rsp+0x20], xmm11
000070dabbdd6c1c  lea rdi, [rsp]
000070dabbdd6c20  mov esi, 0x00
000070dabbdd6c25  mov rax, 0x5C2CF7B6F530
000070dabbdd6c2f  call rax
000070dabbdd6c31  movaps xmm10, [rsp]
000070dabbdd6c36  add rsp, 0x30
000070dabbdd6c3a  vmovaps xmm0, [rsp]
000070dabbdd6c3f  vmovaps xmm1, [rsp+0x10]
000070dabbdd6c45  vmovaps xmm2, [rsp+0x20]
000070dabbdd6c4b  vmovaps xmm3, [rsp+0x30]
000070dabbdd6c51  vmovaps xmm4, [rsp+0x40]
000070dabbdd6c57  vmovaps xmm5, [rsp+0x50]
000070dabbdd6c5d  vmovaps xmm6, [rsp+0x60]
000070dabbdd6c63  vmovaps xmm7, [rsp+0x70]
000070dabbdd6c69  vmovaps xmm8, [rsp+0x80]
000070dabbdd6c72  vmovaps xmm9, [rsp+0x90]
000070dabbdd6c7b  vmovaps xmm11, [rsp+0xA0]
000070dabbdd6c84  vmovaps xmm12, [rsp+0xB0]
000070dabbdd6c8d  vmovaps xmm13, [rsp+0xC0]
000070dabbdd6c96  vmovaps xmm14, [rsp+0xD0]
000070dabbdd6c9f  vmovaps xmm15, [rsp+0xE0]
000070dabbdd6ca8  add rsp, 0xF0
000070dabbdd6caf  pop r11
000070dabbdd6cb1  pop r10
000070dabbdd6cb3  pop r9
000070dabbdd6cb5  pop r8
000070dabbdd6cb7  pop rsi
000070dabbdd6cb8  pop rdi
000070dabbdd6cb9  pop rdx
000070dabbdd6cba  pop rcx
000070dabbdd6cbb  pop rax
000070dabbdd6cbc  add rsp, 0x08
000070dabbdd6cc0  jmp 0x000070DABBDD5A06
000070dabbdd6cc5  sub rsp, 0x08
000070dabbdd6cc9  push rax
000070dabbdd6cca  push rcx
000070dabbdd6ccb  push rdx
000070dabbdd6ccc  push rdi
000070dabbdd6ccd  push rsi
000070dabbdd6cce  push r8
000070dabbdd6cd0  push r9
000070dabbdd6cd2  push r10
000070dabbdd6cd4  push r11
000070dabbdd6cd6  sub rsp, 0xF0
000070dabbdd6cdd  vmovaps [rsp], xmm0
000070dabbdd6ce2  vmovaps [rsp+0x10], xmm1
000070dabbdd6ce8  vmovaps [rsp+0x20], xmm2
000070dabbdd6cee  vmovaps [rsp+0x30], xmm3
000070dabbdd6cf4  vmovaps [rsp+0x40], xmm4
000070dabbdd6cfa  vmovaps [rsp+0x50], xmm5
000070dabbdd6d00  vmovaps [rsp+0x60], xmm7
000070dabbdd6d06  vmovaps [rsp+0x70], xmm8
000070dabbdd6d0c  vmovaps [rsp+0x80], xmm9
000070dabbdd6d15  vmovaps [rsp+0x90], xmm10
000070dabbdd6d1e  vmovaps [rsp+0xA0], xmm11
000070dabbdd6d27  vmovaps [rsp+0xB0], xmm12
000070dabbdd6d30  vmovaps [rsp+0xC0], xmm13
000070dabbdd6d39  vmovaps [rsp+0xD0], xmm14
000070dabbdd6d42  vmovaps [rsp+0xE0], xmm15
000070dabbdd6d4b  sub rsp, 0x30
000070dabbdd6d4f  movaps [rsp], xmm6
000070dabbdd6d53  movaps [rsp+0x10], xmm12
000070dabbdd6d59  movaps [rsp+0x20], xmm11
000070dabbdd6d5f  lea rdi, [rsp]
000070dabbdd6d63  mov esi, 0x00
000070dabbdd6d68  mov rax, 0x5C2CF7B6F530
000070dabbdd6d72  call rax
000070dabbdd6d74  movaps xmm6, [rsp]
000070dabbdd6d78  add rsp, 0x30
000070dabbdd6d7c  vmovaps xmm0, [rsp]
000070dabbdd6d81  vmovaps xmm1, [rsp+0x10]
000070dabbdd6d87  vmovaps xmm2, [rsp+0x20]
000070dabbdd6d8d  vmovaps xmm3, [rsp+0x30]
000070dabbdd6d93  vmovaps xmm4, [rsp+0x40]
000070dabbdd6d99  vmovaps xmm5, [rsp+0x50]
000070dabbdd6d9f  vmovaps xmm7, [rsp+0x60]
000070dabbdd6da5  vmovaps xmm8, [rsp+0x70]
000070dabbdd6dab  vmovaps xmm9, [rsp+0x80]
000070dabbdd6db4  vmovaps xmm10, [rsp+0x90]
000070dabbdd6dbd  vmovaps xmm11, [rsp+0xA0]
000070dabbdd6dc6  vmovaps xmm12, [rsp+0xB0]
000070dabbdd6dcf  vmovaps xmm13, [rsp+0xC0]
000070dabbdd6dd8  vmovaps xmm14, [rsp+0xD0]
000070dabbdd6de1  vmovaps xmm15, [rsp+0xE0]
000070dabbdd6dea  add rsp, 0xF0
000070dabbdd6df1  pop r11
000070dabbdd6df3  pop r10
000070dabbdd6df5  pop r9
000070dabbdd6df7  pop r8
000070dabbdd6df9  pop rsi
000070dabbdd6dfa  pop rdi
000070dabbdd6dfb  pop rdx
000070dabbdd6dfc  pop rcx
000070dabbdd6dfd  pop rax
000070dabbdd6dfe  add rsp, 0x08
000070dabbdd6e02  jmp 0x000070DABBDD5A27
000070dabbdd6e07  sub rsp, 0x08
000070dabbdd6e0b  push rax
000070dabbdd6e0c  push rcx
000070dabbdd6e0d  push rdx
000070dabbdd6e0e  push rdi
000070dabbdd6e0f  push rsi
000070dabbdd6e10  push r8
000070dabbdd6e12  push r9
000070dabbdd6e14  push r10
000070dabbdd6e16  push r11
000070dabbdd6e18  sub rsp, 0xF0
000070dabbdd6e1f  vmovaps [rsp], xmm0
000070dabbdd6e24  vmovaps [rsp+0x10], xmm1
000070dabbdd6e2a  vmovaps [rsp+0x20], xmm2
000070dabbdd6e30  vmovaps [rsp+0x30], xmm4
000070dabbdd6e36  vmovaps [rsp+0x40], xmm5
000070dabbdd6e3c  vmovaps [rsp+0x50], xmm6
000070dabbdd6e42  vmovaps [rsp+0x60], xmm7
000070dabbdd6e48  vmovaps [rsp+0x70], xmm8
000070dabbdd6e4e  vmovaps [rsp+0x80], xmm9
000070dabbdd6e57  vmovaps [rsp+0x90], xmm10
000070dabbdd6e60  vmovaps [rsp+0xA0], xmm11
000070dabbdd6e69  vmovaps [rsp+0xB0], xmm12
000070dabbdd6e72  vmovaps [rsp+0xC0], xmm13
000070dabbdd6e7b  vmovaps [rsp+0xD0], xmm14
000070dabbdd6e84  vmovaps [rsp+0xE0], xmm15
000070dabbdd6e8d  sub rsp, 0x30
000070dabbdd6e91  movaps [rsp], xmm3
000070dabbdd6e95  movaps [rsp+0x10], xmm5
000070dabbdd6e9a  movaps [rsp+0x20], xmm4
000070dabbdd6e9f  lea rdi, [rsp]
000070dabbdd6ea3  mov esi, 0x00
000070dabbdd6ea8  mov rax, 0x5C2CF7B6F530
000070dabbdd6eb2  call rax
000070dabbdd6eb4  movaps xmm3, [rsp]
000070dabbdd6eb8  add rsp, 0x30
000070dabbdd6ebc  vmovaps xmm0, [rsp]
000070dabbdd6ec1  vmovaps xmm1, [rsp+0x10]
000070dabbdd6ec7  vmovaps xmm2, [rsp+0x20]
000070dabbdd6ecd  vmovaps xmm4, [rsp+0x30]
000070dabbdd6ed3  vmovaps xmm5, [rsp+0x40]
000070dabbdd6ed9  vmovaps xmm6, [rsp+0x50]
000070dabbdd6edf  vmovaps xmm7, [rsp+0x60]
000070dabbdd6ee5  vmovaps xmm8, [rsp+0x70]
000070dabbdd6eeb  vmovaps xmm9, [rsp+0x80]
000070dabbdd6ef4  vmovaps xmm10, [rsp+0x90]
000070dabbdd6efd  vmovaps xmm11, [rsp+0xA0]
000070dabbdd6f06  vmovaps xmm12, [rsp+0xB0]
000070dabbdd6f0f  vmovaps xmm13, [rsp+0xC0]
000070dabbdd6f18  vmovaps xmm14, [rsp+0xD0]
000070dabbdd6f21  vmovaps xmm15, [rsp+0xE0]
000070dabbdd6f2a  add rsp, 0xF0
000070dabbdd6f31  pop r11
000070dabbdd6f33  pop r10
000070dabbdd6f35  pop r9
000070dabbdd6f37  pop r8
000070dabbdd6f39  pop rsi
000070dabbdd6f3a  pop rdi
000070dabbdd6f3b  pop rdx
000070dabbdd6f3c  pop rcx
000070dabbdd6f3d  pop rax
000070dabbdd6f3e  add rsp, 0x08
000070dabbdd6f42  jmp 0x000070DABBDD5A88
000070dabbdd6f47  sub rsp, 0x08
000070dabbdd6f4b  push rax
000070dabbdd6f4c  push rcx
000070dabbdd6f4d  push rdx
000070dabbdd6f4e  push rdi
000070dabbdd6f4f  push rsi
000070dabbdd6f50  push r8
000070dabbdd6f52  push r9
000070dabbdd6f54  push r10
000070dabbdd6f56  push r11
000070dabbdd6f58  sub rsp, 0xF0
000070dabbdd6f5f  vmovaps [rsp], xmm0
000070dabbdd6f64  vmovaps [rsp+0x10], xmm1
000070dabbdd6f6a  vmovaps [rsp+0x20], xmm2
000070dabbdd6f70  vmovaps [rsp+0x30], xmm3
000070dabbdd6f76  vmovaps [rsp+0x40], xmm4
000070dabbdd6f7c  vmovaps [rsp+0x50], xmm6
000070dabbdd6f82  vmovaps [rsp+0x60], xmm7
000070dabbdd6f88  vmovaps [rsp+0x70], xmm8
000070dabbdd6f8e  vmovaps [rsp+0x80], xmm9
000070dabbdd6f97  vmovaps [rsp+0x90], xmm10
000070dabbdd6fa0  vmovaps [rsp+0xA0], xmm11
000070dabbdd6fa9  vmovaps [rsp+0xB0], xmm12
000070dabbdd6fb2  vmovaps [rsp+0xC0], xmm13
000070dabbdd6fbb  vmovaps [rsp+0xD0], xmm14
000070dabbdd6fc4  vmovaps [rsp+0xE0], xmm15
000070dabbdd6fcd  sub rsp, 0x30
000070dabbdd6fd1  movaps [rsp], xmm5
000070dabbdd6fd5  movaps [rsp+0x10], xmm8
000070dabbdd6fdb  movaps [rsp+0x20], xmm15
000070dabbdd6fe1  lea rdi, [rsp]
000070dabbdd6fe5  mov esi, 0x00
000070dabbdd6fea  mov rax, 0x5C2CF7B6F530
000070dabbdd6ff4  call rax
000070dabbdd6ff6  movaps xmm5, [rsp]
000070dabbdd6ffa  add rsp, 0x30
000070dabbdd6ffe  vmovaps xmm0, [rsp]
000070dabbdd7003  vmovaps xmm1, [rsp+0x10]
000070dabbdd7009  vmovaps xmm2, [rsp+0x20]
000070dabbdd700f  vmovaps xmm3, [rsp+0x30]
000070dabbdd7015  vmovaps xmm4, [rsp+0x40]
000070dabbdd701b  vmovaps xmm6, [rsp+0x50]
000070dabbdd7021  vmovaps xmm7, [rsp+0x60]
000070dabbdd7027  vmovaps xmm8, [rsp+0x70]
000070dabbdd702d  vmovaps xmm9, [rsp+0x80]
000070dabbdd7036  vmovaps xmm10, [rsp+0x90]
000070dabbdd703f  vmovaps xmm11, [rsp+0xA0]
000070dabbdd7048  vmovaps xmm12, [rsp+0xB0]
000070dabbdd7051  vmovaps xmm13, [rsp+0xC0]
000070dabbdd705a  vmovaps xmm14, [rsp+0xD0]
000070dabbdd7063  vmovaps xmm15, [rsp+0xE0]
000070dabbdd706c  add rsp, 0xF0
000070dabbdd7073  pop r11
000070dabbdd7075  pop r10
000070dabbdd7077  pop r9
000070dabbdd7079  pop r8
000070dabbdd707b  pop rsi
000070dabbdd707c  pop rdi
000070dabbdd707d  pop rdx
000070dabbdd707e  pop rcx
000070dabbdd707f  pop rax
000070dabbdd7080  add rsp, 0x08
000070dabbdd7084  jmp 0x000070DABBDD5AC0
000070dabbdd7089  sub rsp, 0x08
000070dabbdd708d  push rax
000070dabbdd708e  push rcx
000070dabbdd708f  push rdx
000070dabbdd7090  push rdi
000070dabbdd7091  push rsi
000070dabbdd7092  push r8
000070dabbdd7094  push r9
000070dabbdd7096  push r10
000070dabbdd7098  push r11
000070dabbdd709a  sub rsp, 0xF0
000070dabbdd70a1  vmovaps [rsp], xmm0
000070dabbdd70a6  vmovaps [rsp+0x10], xmm1
000070dabbdd70ac  vmovaps [rsp+0x20], xmm2
000070dabbdd70b2  vmovaps [rsp+0x30], xmm3
000070dabbdd70b8  vmovaps [rsp+0x40], xmm5
000070dabbdd70be  vmovaps [rsp+0x50], xmm6
000070dabbdd70c4  vmovaps [rsp+0x60], xmm7
000070dabbdd70ca  vmovaps [rsp+0x70], xmm8
000070dabbdd70d0  vmovaps [rsp+0x80], xmm9
000070dabbdd70d9  vmovaps [rsp+0x90], xmm10
000070dabbdd70e2  vmovaps [rsp+0xA0], xmm11
000070dabbdd70eb  vmovaps [rsp+0xB0], xmm12
000070dabbdd70f4  vmovaps [rsp+0xC0], xmm13
000070dabbdd70fd  vmovaps [rsp+0xD0], xmm14
000070dabbdd7106  vmovaps [rsp+0xE0], xmm15
000070dabbdd710f  sub rsp, 0x30
000070dabbdd7113  movaps [rsp], xmm4
000070dabbdd7117  movaps [rsp+0x10], xmm9
000070dabbdd711d  movaps [rsp+0x20], xmm8
000070dabbdd7123  lea rdi, [rsp]
000070dabbdd7127  mov esi, 0x00
000070dabbdd712c  mov rax, 0x5C2CF7B6F530
000070dabbdd7136  call rax
000070dabbdd7138  movaps xmm4, [rsp]
000070dabbdd713c  add rsp, 0x30
000070dabbdd7140  vmovaps xmm0, [rsp]
000070dabbdd7145  vmovaps xmm1, [rsp+0x10]
000070dabbdd714b  vmovaps xmm2, [rsp+0x20]
000070dabbdd7151  vmovaps xmm3, [rsp+0x30]
000070dabbdd7157  vmovaps xmm5, [rsp+0x40]
000070dabbdd715d  vmovaps xmm6, [rsp+0x50]
000070dabbdd7163  vmovaps xmm7, [rsp+0x60]
000070dabbdd7169  vmovaps xmm8, [rsp+0x70]
000070dabbdd716f  vmovaps xmm9, [rsp+0x80]
000070dabbdd7178  vmovaps xmm10, [rsp+0x90]
000070dabbdd7181  vmovaps xmm11, [rsp+0xA0]
000070dabbdd718a  vmovaps xmm12, [rsp+0xB0]
000070dabbdd7193  vmovaps xmm13, [rsp+0xC0]
000070dabbdd719c  vmovaps xmm14, [rsp+0xD0]
000070dabbdd71a5  vmovaps xmm15, [rsp+0xE0]
000070dabbdd71ae  add rsp, 0xF0
000070dabbdd71b5  pop r11
000070dabbdd71b7  pop r10
000070dabbdd71b9  pop r9
000070dabbdd71bb  pop r8
000070dabbdd71bd  pop rsi
000070dabbdd71be  pop rdi
000070dabbdd71bf  pop rdx
000070dabbdd71c0  pop rcx
000070dabbdd71c1  pop rax
000070dabbdd71c2  add rsp, 0x08
000070dabbdd71c6  jmp 0x000070DABBDD5AE1
000070dabbdd71cb  sub rsp, 0x08
000070dabbdd71cf  push rax
000070dabbdd71d0  push rcx
000070dabbdd71d1  push rdx
000070dabbdd71d2  push rdi
000070dabbdd71d3  push rsi
000070dabbdd71d4  push r8
000070dabbdd71d6  push r9
000070dabbdd71d8  push r10
000070dabbdd71da  push r11
000070dabbdd71dc  sub rsp, 0xF0
000070dabbdd71e3  vmovaps [rsp], xmm0
000070dabbdd71e8  vmovaps [rsp+0x10], xmm1
000070dabbdd71ee  vmovaps [rsp+0x20], xmm2
000070dabbdd71f4  vmovaps [rsp+0x30], xmm3
000070dabbdd71fa  vmovaps [rsp+0x40], xmm4
000070dabbdd7200  vmovaps [rsp+0x50], xmm5
000070dabbdd7206  vmovaps [rsp+0x60], xmm6
000070dabbdd720c  vmovaps [rsp+0x70], xmm7
000070dabbdd7212  vmovaps [rsp+0x80], xmm8
000070dabbdd721b  vmovaps [rsp+0x90], xmm10
000070dabbdd7224  vmovaps [rsp+0xA0], xmm11
000070dabbdd722d  vmovaps [rsp+0xB0], xmm12
000070dabbdd7236  vmovaps [rsp+0xC0], xmm13
000070dabbdd723f  vmovaps [rsp+0xD0], xmm14
000070dabbdd7248  vmovaps [rsp+0xE0], xmm15
000070dabbdd7251  sub rsp, 0x30
000070dabbdd7255  movaps [rsp], xmm9
000070dabbdd725a  movaps [rsp+0x10], xmm10
000070dabbdd7260  movaps [rsp+0x20], xmm8
000070dabbdd7266  lea rdi, [rsp]
000070dabbdd726a  mov esi, 0x00
000070dabbdd726f  mov rax, 0x5C2CF7B6F530
000070dabbdd7279  call rax
000070dabbdd727b  movaps xmm9, [rsp]
000070dabbdd7280  add rsp, 0x30
000070dabbdd7284  vmovaps xmm0, [rsp]
000070dabbdd7289  vmovaps xmm1, [rsp+0x10]
000070dabbdd728f  vmovaps xmm2, [rsp+0x20]
000070dabbdd7295  vmovaps xmm3, [rsp+0x30]
000070dabbdd729b  vmovaps xmm4, [rsp+0x40]
000070dabbdd72a1  vmovaps xmm5, [rsp+0x50]
000070dabbdd72a7  vmovaps xmm6, [rsp+0x60]
000070dabbdd72ad  vmovaps xmm7, [rsp+0x70]
000070dabbdd72b3  vmovaps xmm8, [rsp+0x80]
000070dabbdd72bc  vmovaps xmm10, [rsp+0x90]
000070dabbdd72c5  vmovaps xmm11, [rsp+0xA0]
000070dabbdd72ce  vmovaps xmm12, [rsp+0xB0]
000070dabbdd72d7  vmovaps xmm13, [rsp+0xC0]
000070dabbdd72e0  vmovaps xmm14, [rsp+0xD0]
000070dabbdd72e9  vmovaps xmm15, [rsp+0xE0]
000070dabbdd72f2  add rsp, 0xF0
000070dabbdd72f9  pop r11
000070dabbdd72fb  pop r10
000070dabbdd72fd  pop r9
000070dabbdd72ff  pop r8
000070dabbdd7301  pop rsi
000070dabbdd7302  pop rdi
000070dabbdd7303  pop rdx
000070dabbdd7304  pop rcx
000070dabbdd7305  pop rax
000070dabbdd7306  add rsp, 0x08
000070dabbdd730a  jmp 0x000070DABBDD5AFB
000070dabbdd730f  call 0x000070DABBCD64F0
000070dabbdd7314  jmp 0x000070DABBDD5C15
000070dabbdd7319  call 0x000070DABBCD64F0
000070dabbdd731e  jmp 0x000070DABBDD5C2B
000070dabbdd7323  sub rsp, 0x08
000070dabbdd7327  push rax
000070dabbdd7328  push rcx
000070dabbdd7329  push rdx
000070dabbdd732a  push rdi
000070dabbdd732b  push rsi
000070dabbdd732c  push r8
000070dabbdd732e  push r9
000070dabbdd7330  push r10
000070dabbdd7332  push r11
000070dabbdd7334  sub rsp, 0xF0
000070dabbdd733b  vmovaps [rsp], xmm0
000070dabbdd7340  vmovaps [rsp+0x10], xmm2
000070dabbdd7346  vmovaps [rsp+0x20], xmm3
000070dabbdd734c  vmovaps [rsp+0x30], xmm4
000070dabbdd7352  vmovaps [rsp+0x40], xmm5
000070dabbdd7358  vmovaps [rsp+0x50], xmm6
000070dabbdd735e  vmovaps [rsp+0x60], xmm7
000070dabbdd7364  vmovaps [rsp+0x70], xmm8
000070dabbdd736a  vmovaps [rsp+0x80], xmm9
000070dabbdd7373  vmovaps [rsp+0x90], xmm10
000070dabbdd737c  vmovaps [rsp+0xA0], xmm11
000070dabbdd7385  vmovaps [rsp+0xB0], xmm12
000070dabbdd738e  vmovaps [rsp+0xC0], xmm13
000070dabbdd7397  vmovaps [rsp+0xD0], xmm14
000070dabbdd73a0  vmovaps [rsp+0xE0], xmm15
000070dabbdd73a9  sub rsp, 0x30
000070dabbdd73ad  movaps [rsp], xmm1
000070dabbdd73b1  movaps [rsp+0x10], xmm6
000070dabbdd73b6  movaps [rsp+0x20], xmm15
000070dabbdd73bc  lea rdi, [rsp]
000070dabbdd73c0  mov esi, 0x00
000070dabbdd73c5  mov rax, 0x5C2CF7B6F530
000070dabbdd73cf  call rax
000070dabbdd73d1  movaps xmm1, [rsp]
000070dabbdd73d5  add rsp, 0x30
000070dabbdd73d9  vmovaps xmm0, [rsp]
000070dabbdd73de  vmovaps xmm2, [rsp+0x10]
000070dabbdd73e4  vmovaps xmm3, [rsp+0x20]
000070dabbdd73ea  vmovaps xmm4, [rsp+0x30]
000070dabbdd73f0  vmovaps xmm5, [rsp+0x40]
000070dabbdd73f6  vmovaps xmm6, [rsp+0x50]
000070dabbdd73fc  vmovaps xmm7, [rsp+0x60]
000070dabbdd7402  vmovaps xmm8, [rsp+0x70]
000070dabbdd7408  vmovaps xmm9, [rsp+0x80]
000070dabbdd7411  vmovaps xmm10, [rsp+0x90]
000070dabbdd741a  vmovaps xmm11, [rsp+0xA0]
000070dabbdd7423  vmovaps xmm12, [rsp+0xB0]
000070dabbdd742c  vmovaps xmm13, [rsp+0xC0]
000070dabbdd7435  vmovaps xmm14, [rsp+0xD0]
000070dabbdd743e  vmovaps xmm15, [rsp+0xE0]
000070dabbdd7447  add rsp, 0xF0
000070dabbdd744e  pop r11
000070dabbdd7450  pop r10
000070dabbdd7452  pop r9
000070dabbdd7454  pop r8
000070dabbdd7456  pop rsi
000070dabbdd7457  pop rdi
000070dabbdd7458  pop rdx
000070dabbdd7459  pop rcx
000070dabbdd745a  pop rax
000070dabbdd745b  add rsp, 0x08
000070dabbdd745f  jmp 0x000070DABBDD5C68
000070dabbdd7464  call 0x000070DABBCE5820
000070dabbdd7469  jmp 0x000070DABBDD5C75
000070dabbdd746e  sub rsp, 0x08
000070dabbdd7472  push rax
000070dabbdd7473  push rcx
000070dabbdd7474  push rdx
000070dabbdd7475  push rdi
000070dabbdd7476  push rsi
000070dabbdd7477  push r8
000070dabbdd7479  push r9
000070dabbdd747b  push r10
000070dabbdd747d  push r11
000070dabbdd747f  sub rsp, 0xF0
000070dabbdd7486  vmovaps [rsp], xmm0
000070dabbdd748b  vmovaps [rsp+0x10], xmm1
000070dabbdd7491  vmovaps [rsp+0x20], xmm2
000070dabbdd7497  vmovaps [rsp+0x30], xmm3
000070dabbdd749d  vmovaps [rsp+0x40], xmm4
000070dabbdd74a3  vmovaps [rsp+0x50], xmm5
000070dabbdd74a9  vmovaps [rsp+0x60], xmm6
000070dabbdd74af  vmovaps [rsp+0x70], xmm7
000070dabbdd74b5  vmovaps [rsp+0x80], xmm8
000070dabbdd74be  vmovaps [rsp+0x90], xmm9
000070dabbdd74c7  vmovaps [rsp+0xA0], xmm10
000070dabbdd74d0  vmovaps [rsp+0xB0], xmm11
000070dabbdd74d9  vmovaps [rsp+0xC0], xmm12
000070dabbdd74e2  vmovaps [rsp+0xD0], xmm13
000070dabbdd74eb  vmovaps [rsp+0xE0], xmm15
000070dabbdd74f4  sub rsp, 0x30
000070dabbdd74f8  movaps [rsp], xmm14
000070dabbdd74fd  movaps [rsp+0x10], xmm4
000070dabbdd7502  movaps [rsp+0x20], xmm3
000070dabbdd7507  lea rdi, [rsp]
000070dabbdd750b  mov esi, 0x00
000070dabbdd7510  mov rax, 0x5C2CF7B6F530
000070dabbdd751a  call rax
000070dabbdd751c  movaps xmm14, [rsp]
000070dabbdd7521  add rsp, 0x30
000070dabbdd7525  vmovaps xmm0, [rsp]
000070dabbdd752a  vmovaps xmm1, [rsp+0x10]
000070dabbdd7530  vmovaps xmm2, [rsp+0x20]
000070dabbdd7536  vmovaps xmm3, [rsp+0x30]
000070dabbdd753c  vmovaps xmm4, [rsp+0x40]
000070dabbdd7542  vmovaps xmm5, [rsp+0x50]
000070dabbdd7548  vmovaps xmm6, [rsp+0x60]
000070dabbdd754e  vmovaps xmm7, [rsp+0x70]
000070dabbdd7554  vmovaps xmm8, [rsp+0x80]
000070dabbdd755d  vmovaps xmm9, [rsp+0x90]
000070dabbdd7566  vmovaps xmm10, [rsp+0xA0]
000070dabbdd756f  vmovaps xmm11, [rsp+0xB0]
000070dabbdd7578  vmovaps xmm12, [rsp+0xC0]
000070dabbdd7581  vmovaps xmm13, [rsp+0xD0]
000070dabbdd758a  vmovaps xmm15, [rsp+0xE0]
000070dabbdd7593  add rsp, 0xF0
000070dabbdd759a  pop r11
000070dabbdd759c  pop r10
000070dabbdd759e  pop r9
000070dabbdd75a0  pop r8
000070dabbdd75a2  pop rsi
000070dabbdd75a3  pop rdi
000070dabbdd75a4  pop rdx
000070dabbdd75a5  pop rcx
000070dabbdd75a6  pop rax
000070dabbdd75a7  add rsp, 0x08
000070dabbdd75ab  jmp 0x000070DABBDD5C8F
000070dabbdd75b0  sub rsp, 0x08
000070dabbdd75b4  push rax
000070dabbdd75b5  push rcx
000070dabbdd75b6  push rdx
000070dabbdd75b7  push rdi
000070dabbdd75b8  push rsi
000070dabbdd75b9  push r8
000070dabbdd75bb  push r9
000070dabbdd75bd  push r10
000070dabbdd75bf  push r11
000070dabbdd75c1  sub rsp, 0xF0
000070dabbdd75c8  vmovaps [rsp], xmm0
000070dabbdd75cd  vmovaps [rsp+0x10], xmm1
000070dabbdd75d3  vmovaps [rsp+0x20], xmm2
000070dabbdd75d9  vmovaps [rsp+0x30], xmm3
000070dabbdd75df  vmovaps [rsp+0x40], xmm4
000070dabbdd75e5  vmovaps [rsp+0x50], xmm5
000070dabbdd75eb  vmovaps [rsp+0x60], xmm7
000070dabbdd75f1  vmovaps [rsp+0x70], xmm8
000070dabbdd75f7  vmovaps [rsp+0x80], xmm9
000070dabbdd7600  vmovaps [rsp+0x90], xmm10
000070dabbdd7609  vmovaps [rsp+0xA0], xmm11
000070dabbdd7612  vmovaps [rsp+0xB0], xmm12
000070dabbdd761b  vmovaps [rsp+0xC0], xmm13
000070dabbdd7624  vmovaps [rsp+0xD0], xmm14
000070dabbdd762d  vmovaps [rsp+0xE0], xmm15
000070dabbdd7636  sub rsp, 0x30
000070dabbdd763a  movaps [rsp], xmm6
000070dabbdd763e  movaps [rsp+0x10], xmm9
000070dabbdd7644  movaps [rsp+0x20], xmm7
000070dabbdd7649  lea rdi, [rsp]
000070dabbdd764d  mov esi, 0x00
000070dabbdd7652  mov rax, 0x5C2CF7B6F530
000070dabbdd765c  call rax
000070dabbdd765e  movaps xmm6, [rsp]
000070dabbdd7662  add rsp, 0x30
000070dabbdd7666  vmovaps xmm0, [rsp]
000070dabbdd766b  vmovaps xmm1, [rsp+0x10]
000070dabbdd7671  vmovaps xmm2, [rsp+0x20]
000070dabbdd7677  vmovaps xmm3, [rsp+0x30]
000070dabbdd767d  vmovaps xmm4, [rsp+0x40]
000070dabbdd7683  vmovaps xmm5, [rsp+0x50]
000070dabbdd7689  vmovaps xmm7, [rsp+0x60]
000070dabbdd768f  vmovaps xmm8, [rsp+0x70]
000070dabbdd7695  vmovaps xmm9, [rsp+0x80]
000070dabbdd769e  vmovaps xmm10, [rsp+0x90]
000070dabbdd76a7  vmovaps xmm11, [rsp+0xA0]
000070dabbdd76b0  vmovaps xmm12, [rsp+0xB0]
000070dabbdd76b9  vmovaps xmm13, [rsp+0xC0]
000070dabbdd76c2  vmovaps xmm14, [rsp+0xD0]
000070dabbdd76cb  vmovaps xmm15, [rsp+0xE0]
000070dabbdd76d4  add rsp, 0xF0
000070dabbdd76db  pop r11
000070dabbdd76dd  pop r10
000070dabbdd76df  pop r9
000070dabbdd76e1  pop r8
000070dabbdd76e3  pop rsi
000070dabbdd76e4  pop rdi
000070dabbdd76e5  pop rdx
000070dabbdd76e6  pop rcx
000070dabbdd76e7  pop rax
000070dabbdd76e8  add rsp, 0x08
000070dabbdd76ec  jmp 0x000070DABBDD5CA7
000070dabbdd76f1  sub rsp, 0x08
000070dabbdd76f5  push rax
000070dabbdd76f6  push rcx
000070dabbdd76f7  push rdx
000070dabbdd76f8  push rdi
000070dabbdd76f9  push rsi
000070dabbdd76fa  push r8
000070dabbdd76fc  push r9
000070dabbdd76fe  push r10
000070dabbdd7700  push r11
000070dabbdd7702  sub rsp, 0xF0
000070dabbdd7709  vmovaps [rsp], xmm0
000070dabbdd770e  vmovaps [rsp+0x10], xmm1
000070dabbdd7714  vmovaps [rsp+0x20], xmm2
000070dabbdd771a  vmovaps [rsp+0x30], xmm3
000070dabbdd7720  vmovaps [rsp+0x40], xmm4
000070dabbdd7726  vmovaps [rsp+0x50], xmm5
000070dabbdd772c  vmovaps [rsp+0x60], xmm6
000070dabbdd7732  vmovaps [rsp+0x70], xmm8
000070dabbdd7738  vmovaps [rsp+0x80], xmm9
000070dabbdd7741  vmovaps [rsp+0x90], xmm10
000070dabbdd774a  vmovaps [rsp+0xA0], xmm11
000070dabbdd7753  vmovaps [rsp+0xB0], xmm12
000070dabbdd775c  vmovaps [rsp+0xC0], xmm13
000070dabbdd7765  vmovaps [rsp+0xD0], xmm14
000070dabbdd776e  vmovaps [rsp+0xE0], xmm15
000070dabbdd7777  sub rsp, 0x30
000070dabbdd777b  movaps [rsp], xmm7
000070dabbdd777f  movaps [rsp+0x10], xmm4
000070dabbdd7784  movaps [rsp+0x20], xmm9
000070dabbdd778a  lea rdi, [rsp]
000070dabbdd778e  mov esi, 0x00
000070dabbdd7793  mov rax, 0x5C2CF7B6F530
000070dabbdd779d  call rax
000070dabbdd779f  movaps xmm7, [rsp]
000070dabbdd77a3  add rsp, 0x30
000070dabbdd77a7  vmovaps xmm0, [rsp]
000070dabbdd77ac  vmovaps xmm1, [rsp+0x10]
000070dabbdd77b2  vmovaps xmm2, [rsp+0x20]
000070dabbdd77b8  vmovaps xmm3, [rsp+0x30]
000070dabbdd77be  vmovaps xmm4, [rsp+0x40]
000070dabbdd77c4  vmovaps xmm5, [rsp+0x50]
000070dabbdd77ca  vmovaps xmm6, [rsp+0x60]
000070dabbdd77d0  vmovaps xmm8, [rsp+0x70]
000070dabbdd77d6  vmovaps xmm9, [rsp+0x80]
000070dabbdd77df  vmovaps xmm10, [rsp+0x90]
000070dabbdd77e8  vmovaps xmm11, [rsp+0xA0]
000070dabbdd77f1  vmovaps xmm12, [rsp+0xB0]
000070dabbdd77fa  vmovaps xmm13, [rsp+0xC0]
000070dabbdd7803  vmovaps xmm14, [rsp+0xD0]
000070dabbdd780c  vmovaps xmm15, [rsp+0xE0]
000070dabbdd7815  add rsp, 0xF0
000070dabbdd781c  pop r11
000070dabbdd781e  pop r10
000070dabbdd7820  pop r9
000070dabbdd7822  pop r8
000070dabbdd7824  pop rsi
000070dabbdd7825  pop rdi
000070dabbdd7826  pop rdx
000070dabbdd7827  pop rcx
000070dabbdd7828  pop rax
000070dabbdd7829  add rsp, 0x08
000070dabbdd782d  jmp 0x000070DABBDD5CD4
000070dabbdd7832  sub rsp, 0x08
000070dabbdd7836  push rax
000070dabbdd7837  push rcx
000070dabbdd7838  push rdx
000070dabbdd7839  push rdi
000070dabbdd783a  push rsi
000070dabbdd783b  push r8
000070dabbdd783d  push r9
000070dabbdd783f  push r10
000070dabbdd7841  push r11
000070dabbdd7843  sub rsp, 0xF0
000070dabbdd784a  vmovaps [rsp], xmm0
000070dabbdd784f  vmovaps [rsp+0x10], xmm1
000070dabbdd7855  vmovaps [rsp+0x20], xmm2
000070dabbdd785b  vmovaps [rsp+0x30], xmm3
000070dabbdd7861  vmovaps [rsp+0x40], xmm5
000070dabbdd7867  vmovaps [rsp+0x50], xmm6
000070dabbdd786d  vmovaps [rsp+0x60], xmm7
000070dabbdd7873  vmovaps [rsp+0x70], xmm8
000070dabbdd7879  vmovaps [rsp+0x80], xmm9
000070dabbdd7882  vmovaps [rsp+0x90], xmm10
000070dabbdd788b  vmovaps [rsp+0xA0], xmm11
000070dabbdd7894  vmovaps [rsp+0xB0], xmm12
000070dabbdd789d  vmovaps [rsp+0xC0], xmm13
000070dabbdd78a6  vmovaps [rsp+0xD0], xmm14
000070dabbdd78af  vmovaps [rsp+0xE0], xmm15
000070dabbdd78b8  sub rsp, 0x30
000070dabbdd78bc  movaps [rsp], xmm4
000070dabbdd78c0  movaps [rsp+0x10], xmm15
000070dabbdd78c6  movaps [rsp+0x20], xmm9
000070dabbdd78cc  lea rdi, [rsp]
000070dabbdd78d0  mov esi, 0x00
000070dabbdd78d5  mov rax, 0x5C2CF7B6F530
000070dabbdd78df  call rax
000070dabbdd78e1  movaps xmm4, [rsp]
000070dabbdd78e5  add rsp, 0x30
000070dabbdd78e9  vmovaps xmm0, [rsp]
000070dabbdd78ee  vmovaps xmm1, [rsp+0x10]
000070dabbdd78f4  vmovaps xmm2, [rsp+0x20]
000070dabbdd78fa  vmovaps xmm3, [rsp+0x30]
000070dabbdd7900  vmovaps xmm5, [rsp+0x40]
000070dabbdd7906  vmovaps xmm6, [rsp+0x50]
000070dabbdd790c  vmovaps xmm7, [rsp+0x60]
000070dabbdd7912  vmovaps xmm8, [rsp+0x70]
000070dabbdd7918  vmovaps xmm9, [rsp+0x80]
000070dabbdd7921  vmovaps xmm10, [rsp+0x90]
000070dabbdd792a  vmovaps xmm11, [rsp+0xA0]
000070dabbdd7933  vmovaps xmm12, [rsp+0xB0]
000070dabbdd793c  vmovaps xmm13, [rsp+0xC0]
000070dabbdd7945  vmovaps xmm14, [rsp+0xD0]
000070dabbdd794e  vmovaps xmm15, [rsp+0xE0]
000070dabbdd7957  add rsp, 0xF0
000070dabbdd795e  pop r11
000070dabbdd7960  pop r10
000070dabbdd7962  pop r9
000070dabbdd7964  pop r8
000070dabbdd7966  pop rsi
000070dabbdd7967  pop rdi
000070dabbdd7968  pop rdx
000070dabbdd7969  pop rcx
000070dabbdd796a  pop rax
000070dabbdd796b  add rsp, 0x08
000070dabbdd796f  jmp 0x000070DABBDD5CF9
000070dabbdd7974  call 0x000070DABBCE5820
000070dabbdd7979  jmp 0x000070DABBDD5D06
000070dabbdd797e  sub rsp, 0x08
000070dabbdd7982  push rax
000070dabbdd7983  push rcx
000070dabbdd7984  push rdx
000070dabbdd7985  push rdi
000070dabbdd7986  push rsi
000070dabbdd7987  push r8
000070dabbdd7989  push r9
000070dabbdd798b  push r10
000070dabbdd798d  push r11
000070dabbdd798f  sub rsp, 0xF0
000070dabbdd7996  vmovaps [rsp], xmm0
000070dabbdd799b  vmovaps [rsp+0x10], xmm1
000070dabbdd79a1  vmovaps [rsp+0x20], xmm2
000070dabbdd79a7  vmovaps [rsp+0x30], xmm4
000070dabbdd79ad  vmovaps [rsp+0x40], xmm5
000070dabbdd79b3  vmovaps [rsp+0x50], xmm6
000070dabbdd79b9  vmovaps [rsp+0x60], xmm7
000070dabbdd79bf  vmovaps [rsp+0x70], xmm8
000070dabbdd79c5  vmovaps [rsp+0x80], xmm9
000070dabbdd79ce  vmovaps [rsp+0x90], xmm10
000070dabbdd79d7  vmovaps [rsp+0xA0], xmm11
000070dabbdd79e0  vmovaps [rsp+0xB0], xmm12
000070dabbdd79e9  vmovaps [rsp+0xC0], xmm13
000070dabbdd79f2  vmovaps [rsp+0xD0], xmm14
000070dabbdd79fb  vmovaps [rsp+0xE0], xmm15
000070dabbdd7a04  sub rsp, 0x30
000070dabbdd7a08  movaps [rsp], xmm3
000070dabbdd7a0c  movaps [rsp+0x10], xmm1
000070dabbdd7a11  movaps [rsp+0x20], xmm9
000070dabbdd7a17  lea rdi, [rsp]
000070dabbdd7a1b  mov esi, 0x00
000070dabbdd7a20  mov rax, 0x5C2CF7B6F530
000070dabbdd7a2a  call rax
000070dabbdd7a2c  movaps xmm3, [rsp]
000070dabbdd7a30  add rsp, 0x30
000070dabbdd7a34  vmovaps xmm0, [rsp]
000070dabbdd7a39  vmovaps xmm1, [rsp+0x10]
000070dabbdd7a3f  vmovaps xmm2, [rsp+0x20]
000070dabbdd7a45  vmovaps xmm4, [rsp+0x30]
000070dabbdd7a4b  vmovaps xmm5, [rsp+0x40]
000070dabbdd7a51  vmovaps xmm6, [rsp+0x50]
000070dabbdd7a57  vmovaps xmm7, [rsp+0x60]
000070dabbdd7a5d  vmovaps xmm8, [rsp+0x70]
000070dabbdd7a63  vmovaps xmm9, [rsp+0x80]
000070dabbdd7a6c  vmovaps xmm10, [rsp+0x90]
000070dabbdd7a75  vmovaps xmm11, [rsp+0xA0]
000070dabbdd7a7e  vmovaps xmm12, [rsp+0xB0]
000070dabbdd7a87  vmovaps xmm13, [rsp+0xC0]
000070dabbdd7a90  vmovaps xmm14, [rsp+0xD0]
000070dabbdd7a99  vmovaps xmm15, [rsp+0xE0]
000070dabbdd7aa2  add rsp, 0xF0
000070dabbdd7aa9  pop r11
000070dabbdd7aab  pop r10
000070dabbdd7aad  pop r9
000070dabbdd7aaf  pop r8
000070dabbdd7ab1  pop rsi
000070dabbdd7ab2  pop rdi
000070dabbdd7ab3  pop rdx
000070dabbdd7ab4  pop rcx
000070dabbdd7ab5  pop rax
000070dabbdd7ab6  add rsp, 0x08
000070dabbdd7aba  jmp 0x000070DABBDD5D43
000070dabbdd7abf  sub rsp, 0x08
000070dabbdd7ac3  push rax
000070dabbdd7ac4  push rcx
000070dabbdd7ac5  push rdx
000070dabbdd7ac6  push rdi
000070dabbdd7ac7  push rsi
000070dabbdd7ac8  push r8
000070dabbdd7aca  push r9
000070dabbdd7acc  push r10
000070dabbdd7ace  push r11
000070dabbdd7ad0  sub rsp, 0xF0
000070dabbdd7ad7  vmovaps [rsp], xmm0
000070dabbdd7adc  vmovaps [rsp+0x10], xmm2
000070dabbdd7ae2  vmovaps [rsp+0x20], xmm3
000070dabbdd7ae8  vmovaps [rsp+0x30], xmm4
000070dabbdd7aee  vmovaps [rsp+0x40], xmm5
000070dabbdd7af4  vmovaps [rsp+0x50], xmm6
000070dabbdd7afa  vmovaps [rsp+0x60], xmm7
000070dabbdd7b00  vmovaps [rsp+0x70], xmm8
000070dabbdd7b06  vmovaps [rsp+0x80], xmm9
000070dabbdd7b0f  vmovaps [rsp+0x90], xmm10
000070dabbdd7b18  vmovaps [rsp+0xA0], xmm11
000070dabbdd7b21  vmovaps [rsp+0xB0], xmm12
000070dabbdd7b2a  vmovaps [rsp+0xC0], xmm13
000070dabbdd7b33  vmovaps [rsp+0xD0], xmm14
000070dabbdd7b3c  vmovaps [rsp+0xE0], xmm15
000070dabbdd7b45  sub rsp, 0x30
000070dabbdd7b49  movaps [rsp], xmm1
000070dabbdd7b4d  movaps [rsp+0x10], xmm15
000070dabbdd7b53  movaps [rsp+0x20], xmm9
000070dabbdd7b59  lea rdi, [rsp]
000070dabbdd7b5d  mov esi, 0x00
000070dabbdd7b62  mov rax, 0x5C2CF7B6F530
000070dabbdd7b6c  call rax
000070dabbdd7b6e  movaps xmm1, [rsp]
000070dabbdd7b72  add rsp, 0x30
000070dabbdd7b76  vmovaps xmm0, [rsp]
000070dabbdd7b7b  vmovaps xmm2, [rsp+0x10]
000070dabbdd7b81  vmovaps xmm3, [rsp+0x20]
000070dabbdd7b87  vmovaps xmm4, [rsp+0x30]
000070dabbdd7b8d  vmovaps xmm5, [rsp+0x40]
000070dabbdd7b93  vmovaps xmm6, [rsp+0x50]
000070dabbdd7b99  vmovaps xmm7, [rsp+0x60]
000070dabbdd7b9f  vmovaps xmm8, [rsp+0x70]
000070dabbdd7ba5  vmovaps xmm9, [rsp+0x80]
000070dabbdd7bae  vmovaps xmm10, [rsp+0x90]
000070dabbdd7bb7  vmovaps xmm11, [rsp+0xA0]
000070dabbdd7bc0  vmovaps xmm12, [rsp+0xB0]
000070dabbdd7bc9  vmovaps xmm13, [rsp+0xC0]
000070dabbdd7bd2  vmovaps xmm14, [rsp+0xD0]
000070dabbdd7bdb  vmovaps xmm15, [rsp+0xE0]
000070dabbdd7be4  add rsp, 0xF0
000070dabbdd7beb  pop r11
000070dabbdd7bed  pop r10
000070dabbdd7bef  pop r9
000070dabbdd7bf1  pop r8
000070dabbdd7bf3  pop rsi
000070dabbdd7bf4  pop rdi
000070dabbdd7bf5  pop rdx
000070dabbdd7bf6  pop rcx
000070dabbdd7bf7  pop rax
000070dabbdd7bf8  add rsp, 0x08
000070dabbdd7bfc  jmp 0x000070DABBDD5DCB
000070dabbdd7c01  call 0x000070DABBCE5820
000070dabbdd7c06  jmp 0x000070DABBDD5DD8
000070dabbdd7c0b  sub rsp, 0x08
000070dabbdd7c0f  push rax
000070dabbdd7c10  push rcx
000070dabbdd7c11  push rdx
000070dabbdd7c12  push rdi
000070dabbdd7c13  push rsi
000070dabbdd7c14  push r8
000070dabbdd7c16  push r9
000070dabbdd7c18  push r10
000070dabbdd7c1a  push r11
000070dabbdd7c1c  sub rsp, 0xF0
000070dabbdd7c23  vmovaps [rsp], xmm0
000070dabbdd7c28  vmovaps [rsp+0x10], xmm2
000070dabbdd7c2e  vmovaps [rsp+0x20], xmm3
000070dabbdd7c34  vmovaps [rsp+0x30], xmm4
000070dabbdd7c3a  vmovaps [rsp+0x40], xmm5
000070dabbdd7c40  vmovaps [rsp+0x50], xmm6
000070dabbdd7c46  vmovaps [rsp+0x60], xmm7
000070dabbdd7c4c  vmovaps [rsp+0x70], xmm8
000070dabbdd7c52  vmovaps [rsp+0x80], xmm9
000070dabbdd7c5b  vmovaps [rsp+0x90], xmm10
000070dabbdd7c64  vmovaps [rsp+0xA0], xmm11
000070dabbdd7c6d  vmovaps [rsp+0xB0], xmm12
000070dabbdd7c76  vmovaps [rsp+0xC0], xmm13
000070dabbdd7c7f  vmovaps [rsp+0xD0], xmm14
000070dabbdd7c88  vmovaps [rsp+0xE0], xmm15
000070dabbdd7c91  sub rsp, 0x30
000070dabbdd7c95  movaps [rsp], xmm1
000070dabbdd7c99  movaps [rsp+0x10], xmm5
000070dabbdd7c9e  movaps [rsp+0x20], xmm7
000070dabbdd7ca3  lea rdi, [rsp]
000070dabbdd7ca7  mov esi, 0x00
000070dabbdd7cac  mov rax, 0x5C2CF7B6F530
000070dabbdd7cb6  call rax
000070dabbdd7cb8  movaps xmm1, [rsp]
000070dabbdd7cbc  add rsp, 0x30
000070dabbdd7cc0  vmovaps xmm0, [rsp]
000070dabbdd7cc5  vmovaps xmm2, [rsp+0x10]
000070dabbdd7ccb  vmovaps xmm3, [rsp+0x20]
000070dabbdd7cd1  vmovaps xmm4, [rsp+0x30]
000070dabbdd7cd7  vmovaps xmm5, [rsp+0x40]
000070dabbdd7cdd  vmovaps xmm6, [rsp+0x50]
000070dabbdd7ce3  vmovaps xmm7, [rsp+0x60]
000070dabbdd7ce9  vmovaps xmm8, [rsp+0x70]
000070dabbdd7cef  vmovaps xmm9, [rsp+0x80]
000070dabbdd7cf8  vmovaps xmm10, [rsp+0x90]
000070dabbdd7d01  vmovaps xmm11, [rsp+0xA0]
000070dabbdd7d0a  vmovaps xmm12, [rsp+0xB0]
000070dabbdd7d13  vmovaps xmm13, [rsp+0xC0]
000070dabbdd7d1c  vmovaps xmm14, [rsp+0xD0]
000070dabbdd7d25  vmovaps xmm15, [rsp+0xE0]
000070dabbdd7d2e  add rsp, 0xF0
000070dabbdd7d35  pop r11
000070dabbdd7d37  pop r10
000070dabbdd7d39  pop r9
000070dabbdd7d3b  pop r8
000070dabbdd7d3d  pop rsi
000070dabbdd7d3e  pop rdi
000070dabbdd7d3f  pop rdx
000070dabbdd7d40  pop rcx
000070dabbdd7d41  pop rax
000070dabbdd7d42  add rsp, 0x08
000070dabbdd7d46  jmp 0x000070DABBDD5E7D
000070dabbdd7d4b  sub rsp, 0x08
000070dabbdd7d4f  push rax
000070dabbdd7d50  push rcx
000070dabbdd7d51  push rdx
000070dabbdd7d52  push rdi
000070dabbdd7d53  push rsi
000070dabbdd7d54  push r8
000070dabbdd7d56  push r9
000070dabbdd7d58  push r10
000070dabbdd7d5a  push r11
000070dabbdd7d5c  sub rsp, 0xF0
000070dabbdd7d63  vmovaps [rsp], xmm0
000070dabbdd7d68  vmovaps [rsp+0x10], xmm1
000070dabbdd7d6e  vmovaps [rsp+0x20], xmm2
000070dabbdd7d74  vmovaps [rsp+0x30], xmm3
000070dabbdd7d7a  vmovaps [rsp+0x40], xmm4
000070dabbdd7d80  vmovaps [rsp+0x50], xmm5
000070dabbdd7d86  vmovaps [rsp+0x60], xmm6
000070dabbdd7d8c  vmovaps [rsp+0x70], xmm8
000070dabbdd7d92  vmovaps [rsp+0x80], xmm9
000070dabbdd7d9b  vmovaps [rsp+0x90], xmm10
000070dabbdd7da4  vmovaps [rsp+0xA0], xmm11
000070dabbdd7dad  vmovaps [rsp+0xB0], xmm12
000070dabbdd7db6  vmovaps [rsp+0xC0], xmm13
000070dabbdd7dbf  vmovaps [rsp+0xD0], xmm14
000070dabbdd7dc8  vmovaps [rsp+0xE0], xmm15
000070dabbdd7dd1  sub rsp, 0x30
000070dabbdd7dd5  movaps [rsp], xmm7
000070dabbdd7dd9  movaps [rsp+0x10], xmm5
000070dabbdd7dde  movaps [rsp+0x20], xmm15
000070dabbdd7de4  lea rdi, [rsp]
000070dabbdd7de8  mov esi, 0x00
000070dabbdd7ded  mov rax, 0x5C2CF7B6F530
000070dabbdd7df7  call rax
000070dabbdd7df9  movaps xmm7, [rsp]
000070dabbdd7dfd  add rsp, 0x30
000070dabbdd7e01  vmovaps xmm0, [rsp]
000070dabbdd7e06  vmovaps xmm1, [rsp+0x10]
000070dabbdd7e0c  vmovaps xmm2, [rsp+0x20]
000070dabbdd7e12  vmovaps xmm3, [rsp+0x30]
000070dabbdd7e18  vmovaps xmm4, [rsp+0x40]
000070dabbdd7e1e  vmovaps xmm5, [rsp+0x50]
000070dabbdd7e24  vmovaps xmm6, [rsp+0x60]
000070dabbdd7e2a  vmovaps xmm8, [rsp+0x70]
000070dabbdd7e30  vmovaps xmm9, [rsp+0x80]
000070dabbdd7e39  vmovaps xmm10, [rsp+0x90]
000070dabbdd7e42  vmovaps xmm11, [rsp+0xA0]
000070dabbdd7e4b  vmovaps xmm12, [rsp+0xB0]
000070dabbdd7e54  vmovaps xmm13, [rsp+0xC0]
000070dabbdd7e5d  vmovaps xmm14, [rsp+0xD0]
000070dabbdd7e66  vmovaps xmm15, [rsp+0xE0]
000070dabbdd7e6f  add rsp, 0xF0
000070dabbdd7e76  pop r11
000070dabbdd7e78  pop r10
000070dabbdd7e7a  pop r9
000070dabbdd7e7c  pop r8
000070dabbdd7e7e  pop rsi
000070dabbdd7e7f  pop rdi
000070dabbdd7e80  pop rdx
000070dabbdd7e81  pop rcx
000070dabbdd7e82  pop rax
000070dabbdd7e83  add rsp, 0x08
000070dabbdd7e87  jmp 0x000070DABBDD5EB3
000070dabbdd7e8c  call 0x000070DABBCD64F0
000070dabbdd7e91  jmp 0x000070DABBDD5EC0
000070dabbdd7e96  sub rsp, 0x08
000070dabbdd7e9a  push rax
000070dabbdd7e9b  push rcx
000070dabbdd7e9c  push rdx
000070dabbdd7e9d  push rdi
000070dabbdd7e9e  push rsi
000070dabbdd7e9f  push r8
000070dabbdd7ea1  push r9
000070dabbdd7ea3  push r10
000070dabbdd7ea5  push r11
000070dabbdd7ea7  sub rsp, 0xF0
000070dabbdd7eae  vmovaps [rsp], xmm0
000070dabbdd7eb3  vmovaps [rsp+0x10], xmm1
000070dabbdd7eb9  vmovaps [rsp+0x20], xmm2
000070dabbdd7ebf  vmovaps [rsp+0x30], xmm3
000070dabbdd7ec5  vmovaps [rsp+0x40], xmm4
000070dabbdd7ecb  vmovaps [rsp+0x50], xmm5
000070dabbdd7ed1  vmovaps [rsp+0x60], xmm6
000070dabbdd7ed7  vmovaps [rsp+0x70], xmm7
000070dabbdd7edd  vmovaps [rsp+0x80], xmm8
000070dabbdd7ee6  vmovaps [rsp+0x90], xmm9
000070dabbdd7eef  vmovaps [rsp+0xA0], xmm10
000070dabbdd7ef8  vmovaps [rsp+0xB0], xmm11
000070dabbdd7f01  vmovaps [rsp+0xC0], xmm12
000070dabbdd7f0a  vmovaps [rsp+0xD0], xmm13
000070dabbdd7f13  vmovaps [rsp+0xE0], xmm14
000070dabbdd7f1c  sub rsp, 0x30
000070dabbdd7f20  movaps [rsp], xmm15
000070dabbdd7f25  movaps [rsp+0x10], xmm5
000070dabbdd7f2a  movaps [rsp+0x20], xmm3
000070dabbdd7f2f  lea rdi, [rsp]
000070dabbdd7f33  mov esi, 0x00
000070dabbdd7f38  mov rax, 0x5C2CF7B6F530
000070dabbdd7f42  call rax
000070dabbdd7f44  movaps xmm15, [rsp]
000070dabbdd7f49  add rsp, 0x30
000070dabbdd7f4d  vmovaps xmm0, [rsp]
000070dabbdd7f52  vmovaps xmm1, [rsp+0x10]
000070dabbdd7f58  vmovaps xmm2, [rsp+0x20]
000070dabbdd7f5e  vmovaps xmm3, [rsp+0x30]
000070dabbdd7f64  vmovaps xmm4, [rsp+0x40]
000070dabbdd7f6a  vmovaps xmm5, [rsp+0x50]
000070dabbdd7f70  vmovaps xmm6, [rsp+0x60]
000070dabbdd7f76  vmovaps xmm7, [rsp+0x70]
000070dabbdd7f7c  vmovaps xmm8, [rsp+0x80]
000070dabbdd7f85  vmovaps xmm9, [rsp+0x90]
000070dabbdd7f8e  vmovaps xmm10, [rsp+0xA0]
000070dabbdd7f97  vmovaps xmm11, [rsp+0xB0]
000070dabbdd7fa0  vmovaps xmm12, [rsp+0xC0]
000070dabbdd7fa9  vmovaps xmm13, [rsp+0xD0]
000070dabbdd7fb2  vmovaps xmm14, [rsp+0xE0]
000070dabbdd7fbb  add rsp, 0xF0
000070dabbdd7fc2  pop r11
000070dabbdd7fc4  pop r10
000070dabbdd7fc6  pop r9
000070dabbdd7fc8  pop r8
000070dabbdd7fca  pop rsi
000070dabbdd7fcb  pop rdi
000070dabbdd7fcc  pop rdx
000070dabbdd7fcd  pop rcx
000070dabbdd7fce  pop rax
000070dabbdd7fcf  add rsp, 0x08
000070dabbdd7fd3  jmp 0x000070DABBDD5EE6
000070dabbdd7fd8  sub rsp, 0x08
000070dabbdd7fdc  push rax
000070dabbdd7fdd  push rcx
000070dabbdd7fde  push rdx
000070dabbdd7fdf  push rdi
000070dabbdd7fe0  push rsi
000070dabbdd7fe1  push r8
000070dabbdd7fe3  push r9
000070dabbdd7fe5  push r10
000070dabbdd7fe7  push r11
000070dabbdd7fe9  sub rsp, 0xF0
000070dabbdd7ff0  vmovaps [rsp], xmm0
000070dabbdd7ff5  vmovaps [rsp+0x10], xmm2
000070dabbdd7ffb  vmovaps [rsp+0x20], xmm3
000070dabbdd8001  vmovaps [rsp+0x30], xmm4
000070dabbdd8007  vmovaps [rsp+0x40], xmm5
000070dabbdd800d  vmovaps [rsp+0x50], xmm6
000070dabbdd8013  vmovaps [rsp+0x60], xmm7
000070dabbdd8019  vmovaps [rsp+0x70], xmm8
000070dabbdd801f  vmovaps [rsp+0x80], xmm9
000070dabbdd8028  vmovaps [rsp+0x90], xmm10
000070dabbdd8031  vmovaps [rsp+0xA0], xmm11
000070dabbdd803a  vmovaps [rsp+0xB0], xmm12
000070dabbdd8043  vmovaps [rsp+0xC0], xmm13
000070dabbdd804c  vmovaps [rsp+0xD0], xmm14
000070dabbdd8055  vmovaps [rsp+0xE0], xmm15
000070dabbdd805e  sub rsp, 0x30
000070dabbdd8062  movaps [rsp], xmm1
000070dabbdd8066  movaps [rsp+0x10], xmm5
000070dabbdd806b  movaps [rsp+0x20], xmm4
000070dabbdd8070  lea rdi, [rsp]
000070dabbdd8074  mov esi, 0x00
000070dabbdd8079  mov rax, 0x5C2CF7B6F530
000070dabbdd8083  call rax
000070dabbdd8085  movaps xmm1, [rsp]
000070dabbdd8089  add rsp, 0x30
000070dabbdd808d  vmovaps xmm0, [rsp]
000070dabbdd8092  vmovaps xmm2, [rsp+0x10]
000070dabbdd8098  vmovaps xmm3, [rsp+0x20]
000070dabbdd809e  vmovaps xmm4, [rsp+0x30]
000070dabbdd80a4  vmovaps xmm5, [rsp+0x40]
000070dabbdd80aa  vmovaps xmm6, [rsp+0x50]
000070dabbdd80b0  vmovaps xmm7, [rsp+0x60]
000070dabbdd80b6  vmovaps xmm8, [rsp+0x70]
000070dabbdd80bc  vmovaps xmm9, [rsp+0x80]
000070dabbdd80c5  vmovaps xmm10, [rsp+0x90]
000070dabbdd80ce  vmovaps xmm11, [rsp+0xA0]
000070dabbdd80d7  vmovaps xmm12, [rsp+0xB0]
000070dabbdd80e0  vmovaps xmm13, [rsp+0xC0]
000070dabbdd80e9  vmovaps xmm14, [rsp+0xD0]
000070dabbdd80f2  vmovaps xmm15, [rsp+0xE0]
000070dabbdd80fb  add rsp, 0xF0
000070dabbdd8102  pop r11
000070dabbdd8104  pop r10
000070dabbdd8106  pop r9
000070dabbdd8108  pop r8
000070dabbdd810a  pop rsi
000070dabbdd810b  pop rdi
000070dabbdd810c  pop rdx
000070dabbdd810d  pop rcx
000070dabbdd810e  pop rax
000070dabbdd810f  add rsp, 0x08
000070dabbdd8113  jmp 0x000070DABBDD5F06
000070dabbdd8118  sub rsp, 0x08
000070dabbdd811c  push rax
000070dabbdd811d  push rcx
000070dabbdd811e  push rdx
000070dabbdd811f  push rdi
000070dabbdd8120  push rsi
000070dabbdd8121  push r8
000070dabbdd8123  push r9
000070dabbdd8125  push r10
000070dabbdd8127  push r11
000070dabbdd8129  sub rsp, 0xF0
000070dabbdd8130  vmovaps [rsp], xmm0
000070dabbdd8135  vmovaps [rsp+0x10], xmm1
000070dabbdd813b  vmovaps [rsp+0x20], xmm2
000070dabbdd8141  vmovaps [rsp+0x30], xmm3
000070dabbdd8147  vmovaps [rsp+0x40], xmm5
000070dabbdd814d  vmovaps [rsp+0x50], xmm6
000070dabbdd8153  vmovaps [rsp+0x60], xmm7
000070dabbdd8159  vmovaps [rsp+0x70], xmm8
000070dabbdd815f  vmovaps [rsp+0x80], xmm9
000070dabbdd8168  vmovaps [rsp+0x90], xmm10
000070dabbdd8171  vmovaps [rsp+0xA0], xmm11
000070dabbdd817a  vmovaps [rsp+0xB0], xmm12
000070dabbdd8183  vmovaps [rsp+0xC0], xmm13
000070dabbdd818c  vmovaps [rsp+0xD0], xmm14
000070dabbdd8195  vmovaps [rsp+0xE0], xmm15
000070dabbdd819e  sub rsp, 0x30
000070dabbdd81a2  movaps [rsp], xmm4
000070dabbdd81a6  movaps [rsp+0x10], xmm3
000070dabbdd81ab  movaps [rsp+0x20], xmm5
000070dabbdd81b0  lea rdi, [rsp]
000070dabbdd81b4  mov esi, 0x00
000070dabbdd81b9  mov rax, 0x5C2CF7B6F530
000070dabbdd81c3  call rax
000070dabbdd81c5  movaps xmm4, [rsp]
000070dabbdd81c9  add rsp, 0x30
000070dabbdd81cd  vmovaps xmm0, [rsp]
000070dabbdd81d2  vmovaps xmm1, [rsp+0x10]
000070dabbdd81d8  vmovaps xmm2, [rsp+0x20]
000070dabbdd81de  vmovaps xmm3, [rsp+0x30]
000070dabbdd81e4  vmovaps xmm5, [rsp+0x40]
000070dabbdd81ea  vmovaps xmm6, [rsp+0x50]
000070dabbdd81f0  vmovaps xmm7, [rsp+0x60]
000070dabbdd81f6  vmovaps xmm8, [rsp+0x70]
000070dabbdd81fc  vmovaps xmm9, [rsp+0x80]
000070dabbdd8205  vmovaps xmm10, [rsp+0x90]
000070dabbdd820e  vmovaps xmm11, [rsp+0xA0]
000070dabbdd8217  vmovaps xmm12, [rsp+0xB0]
000070dabbdd8220  vmovaps xmm13, [rsp+0xC0]
000070dabbdd8229  vmovaps xmm14, [rsp+0xD0]
000070dabbdd8232  vmovaps xmm15, [rsp+0xE0]
000070dabbdd823b  add rsp, 0xF0
000070dabbdd8242  pop r11
000070dabbdd8244  pop r10
000070dabbdd8246  pop r9
000070dabbdd8248  pop r8
000070dabbdd824a  pop rsi
000070dabbdd824b  pop rdi
000070dabbdd824c  pop rdx
000070dabbdd824d  pop rcx
000070dabbdd824e  pop rax
000070dabbdd824f  add rsp, 0x08
000070dabbdd8253  jmp 0x000070DABBDD5F54
000070dabbdd8258  call 0x000070DABBCD64F0
000070dabbdd825d  jmp 0x000070DABBDD5F61
000070dabbdd8262  sub rsp, 0x08
000070dabbdd8266  push rax
000070dabbdd8267  push rcx
000070dabbdd8268  push rdx
000070dabbdd8269  push rdi
000070dabbdd826a  push rsi
000070dabbdd826b  push r8
000070dabbdd826d  push r9
000070dabbdd826f  push r10
000070dabbdd8271  push r11
000070dabbdd8273  sub rsp, 0xF0
000070dabbdd827a  vmovaps [rsp], xmm0
000070dabbdd827f  vmovaps [rsp+0x10], xmm1
000070dabbdd8285  vmovaps [rsp+0x20], xmm2
000070dabbdd828b  vmovaps [rsp+0x30], xmm3
000070dabbdd8291  vmovaps [rsp+0x40], xmm4
000070dabbdd8297  vmovaps [rsp+0x50], xmm6
000070dabbdd829d  vmovaps [rsp+0x60], xmm7
000070dabbdd82a3  vmovaps [rsp+0x70], xmm8
000070dabbdd82a9  vmovaps [rsp+0x80], xmm9
000070dabbdd82b2  vmovaps [rsp+0x90], xmm10
000070dabbdd82bb  vmovaps [rsp+0xA0], xmm11
000070dabbdd82c4  vmovaps [rsp+0xB0], xmm12
000070dabbdd82cd  vmovaps [rsp+0xC0], xmm13
000070dabbdd82d6  vmovaps [rsp+0xD0], xmm14
000070dabbdd82df  vmovaps [rsp+0xE0], xmm15
000070dabbdd82e8  sub rsp, 0x30
000070dabbdd82ec  movaps [rsp], xmm5
000070dabbdd82f0  movaps [rsp+0x10], xmm6
000070dabbdd82f5  movaps [rsp+0x20], xmm3
000070dabbdd82fa  lea rdi, [rsp]
000070dabbdd82fe  mov esi, 0x00
000070dabbdd8303  mov rax, 0x5C2CF7B6F530
000070dabbdd830d  call rax
000070dabbdd830f  movaps xmm5, [rsp]
000070dabbdd8313  add rsp, 0x30
000070dabbdd8317  vmovaps xmm0, [rsp]
000070dabbdd831c  vmovaps xmm1, [rsp+0x10]
000070dabbdd8322  vmovaps xmm2, [rsp+0x20]
000070dabbdd8328  vmovaps xmm3, [rsp+0x30]
000070dabbdd832e  vmovaps xmm4, [rsp+0x40]
000070dabbdd8334  vmovaps xmm6, [rsp+0x50]
000070dabbdd833a  vmovaps xmm7, [rsp+0x60]
000070dabbdd8340  vmovaps xmm8, [rsp+0x70]
000070dabbdd8346  vmovaps xmm9, [rsp+0x80]
000070dabbdd834f  vmovaps xmm10, [rsp+0x90]
000070dabbdd8358  vmovaps xmm11, [rsp+0xA0]
000070dabbdd8361  vmovaps xmm12, [rsp+0xB0]
000070dabbdd836a  vmovaps xmm13, [rsp+0xC0]
000070dabbdd8373  vmovaps xmm14, [rsp+0xD0]
000070dabbdd837c  vmovaps xmm15, [rsp+0xE0]
000070dabbdd8385  add rsp, 0xF0
000070dabbdd838c  pop r11
000070dabbdd838e  pop r10
000070dabbdd8390  pop r9
000070dabbdd8392  pop r8
000070dabbdd8394  pop rsi
000070dabbdd8395  pop rdi
000070dabbdd8396  pop rdx
000070dabbdd8397  pop rcx
000070dabbdd8398  pop rax
000070dabbdd8399  add rsp, 0x08
000070dabbdd839d  jmp 0x000070DABBDD5F87
000070dabbdd83a2  sub rsp, 0x08
000070dabbdd83a6  push rax
000070dabbdd83a7  push rcx
000070dabbdd83a8  push rdx
000070dabbdd83a9  push rdi
000070dabbdd83aa  push rsi
000070dabbdd83ab  push r8
000070dabbdd83ad  push r9
000070dabbdd83af  push r10
000070dabbdd83b1  push r11
000070dabbdd83b3  sub rsp, 0xF0
000070dabbdd83ba  vmovaps [rsp], xmm0
000070dabbdd83bf  vmovaps [rsp+0x10], xmm1
000070dabbdd83c5  vmovaps [rsp+0x20], xmm2
000070dabbdd83cb  vmovaps [rsp+0x30], xmm3
000070dabbdd83d1  vmovaps [rsp+0x40], xmm4
000070dabbdd83d7  vmovaps [rsp+0x50], xmm5
000070dabbdd83dd  vmovaps [rsp+0x60], xmm7
000070dabbdd83e3  vmovaps [rsp+0x70], xmm8
000070dabbdd83e9  vmovaps [rsp+0x80], xmm9
000070dabbdd83f2  vmovaps [rsp+0x90], xmm10
000070dabbdd83fb  vmovaps [rsp+0xA0], xmm11
000070dabbdd8404  vmovaps [rsp+0xB0], xmm12
000070dabbdd840d  vmovaps [rsp+0xC0], xmm13
000070dabbdd8416  vmovaps [rsp+0xD0], xmm14
000070dabbdd841f  vmovaps [rsp+0xE0], xmm15
000070dabbdd8428  sub rsp, 0x30
000070dabbdd842c  movaps [rsp], xmm6
000070dabbdd8430  movaps [rsp+0x10], xmm9
000070dabbdd8436  movaps [rsp+0x20], xmm1
000070dabbdd843b  lea rdi, [rsp]
000070dabbdd843f  mov esi, 0x00
000070dabbdd8444  mov rax, 0x5C2CF7B6F530
000070dabbdd844e  call rax
000070dabbdd8450  movaps xmm6, [rsp]
000070dabbdd8454  add rsp, 0x30
000070dabbdd8458  vmovaps xmm0, [rsp]
000070dabbdd845d  vmovaps xmm1, [rsp+0x10]
000070dabbdd8463  vmovaps xmm2, [rsp+0x20]
000070dabbdd8469  vmovaps xmm3, [rsp+0x30]
000070dabbdd846f  vmovaps xmm4, [rsp+0x40]
000070dabbdd8475  vmovaps xmm5, [rsp+0x50]
000070dabbdd847b  vmovaps xmm7, [rsp+0x60]
000070dabbdd8481  vmovaps xmm8, [rsp+0x70]
000070dabbdd8487  vmovaps xmm9, [rsp+0x80]
000070dabbdd8490  vmovaps xmm10, [rsp+0x90]
000070dabbdd8499  vmovaps xmm11, [rsp+0xA0]
000070dabbdd84a2  vmovaps xmm12, [rsp+0xB0]
000070dabbdd84ab  vmovaps xmm13, [rsp+0xC0]
000070dabbdd84b4  vmovaps xmm14, [rsp+0xD0]
000070dabbdd84bd  vmovaps xmm15, [rsp+0xE0]
000070dabbdd84c6  add rsp, 0xF0
000070dabbdd84cd  pop r11
000070dabbdd84cf  pop r10
000070dabbdd84d1  pop r9
000070dabbdd84d3  pop r8
000070dabbdd84d5  pop rsi
000070dabbdd84d6  pop rdi
000070dabbdd84d7  pop rdx
000070dabbdd84d8  pop rcx
000070dabbdd84d9  pop rax
000070dabbdd84da  add rsp, 0x08
000070dabbdd84de  jmp 0x000070DABBDD5FAB
000070dabbdd84e3  sub rsp, 0x08
000070dabbdd84e7  push rax
000070dabbdd84e8  push rcx
000070dabbdd84e9  push rdx
000070dabbdd84ea  push rdi
000070dabbdd84eb  push rsi
000070dabbdd84ec  push r8
000070dabbdd84ee  push r9
000070dabbdd84f0  push r10
000070dabbdd84f2  push r11
000070dabbdd84f4  sub rsp, 0xF0
000070dabbdd84fb  vmovaps [rsp], xmm0
000070dabbdd8500  vmovaps [rsp+0x10], xmm1
000070dabbdd8506  vmovaps [rsp+0x20], xmm2
000070dabbdd850c  vmovaps [rsp+0x30], xmm3
000070dabbdd8512  vmovaps [rsp+0x40], xmm4
000070dabbdd8518  vmovaps [rsp+0x50], xmm5
000070dabbdd851e  vmovaps [rsp+0x60], xmm6
000070dabbdd8524  vmovaps [rsp+0x70], xmm7
000070dabbdd852a  vmovaps [rsp+0x80], xmm8
000070dabbdd8533  vmovaps [rsp+0x90], xmm10
000070dabbdd853c  vmovaps [rsp+0xA0], xmm11
000070dabbdd8545  vmovaps [rsp+0xB0], xmm12
000070dabbdd854e  vmovaps [rsp+0xC0], xmm13
000070dabbdd8557  vmovaps [rsp+0xD0], xmm14
000070dabbdd8560  vmovaps [rsp+0xE0], xmm15
000070dabbdd8569  sub rsp, 0x30
000070dabbdd856d  movaps [rsp], xmm9
000070dabbdd8572  movaps [rsp+0x10], xmm3
000070dabbdd8577  movaps [rsp+0x20], xmm1
000070dabbdd857c  lea rdi, [rsp]
000070dabbdd8580  mov esi, 0x00
000070dabbdd8585  mov rax, 0x5C2CF7B6F530
000070dabbdd858f  call rax
000070dabbdd8591  movaps xmm9, [rsp]
000070dabbdd8596  add rsp, 0x30
000070dabbdd859a  vmovaps xmm0, [rsp]
000070dabbdd859f  vmovaps xmm1, [rsp+0x10]
000070dabbdd85a5  vmovaps xmm2, [rsp+0x20]
000070dabbdd85ab  vmovaps xmm3, [rsp+0x30]
000070dabbdd85b1  vmovaps xmm4, [rsp+0x40]
000070dabbdd85b7  vmovaps xmm5, [rsp+0x50]
000070dabbdd85bd  vmovaps xmm6, [rsp+0x60]
000070dabbdd85c3  vmovaps xmm7, [rsp+0x70]
000070dabbdd85c9  vmovaps xmm8, [rsp+0x80]
000070dabbdd85d2  vmovaps xmm10, [rsp+0x90]
000070dabbdd85db  vmovaps xmm11, [rsp+0xA0]
000070dabbdd85e4  vmovaps xmm12, [rsp+0xB0]
000070dabbdd85ed  vmovaps xmm13, [rsp+0xC0]
000070dabbdd85f6  vmovaps xmm14, [rsp+0xD0]
000070dabbdd85ff  vmovaps xmm15, [rsp+0xE0]
000070dabbdd8608  add rsp, 0xF0
000070dabbdd860f  pop r11
000070dabbdd8611  pop r10
000070dabbdd8613  pop r9
000070dabbdd8615  pop r8
000070dabbdd8617  pop rsi
000070dabbdd8618  pop rdi
000070dabbdd8619  pop rdx
000070dabbdd861a  pop rcx
000070dabbdd861b  pop rax
000070dabbdd861c  add rsp, 0x08
000070dabbdd8620  jmp 0x000070DABBDD5FF7
000070dabbdd8625  call 0x000070DABBCD64F0
000070dabbdd862a  jmp 0x000070DABBDD6004
000070dabbdd862f  sub rsp, 0x08
000070dabbdd8633  push rax
000070dabbdd8634  push rcx
000070dabbdd8635  push rdx
000070dabbdd8636  push rdi
000070dabbdd8637  push rsi
000070dabbdd8638  push r8
000070dabbdd863a  push r9
000070dabbdd863c  push r10
000070dabbdd863e  push r11
000070dabbdd8640  sub rsp, 0xF0
000070dabbdd8647  vmovaps [rsp], xmm0
000070dabbdd864c  vmovaps [rsp+0x10], xmm1
000070dabbdd8652  vmovaps [rsp+0x20], xmm2
000070dabbdd8658  vmovaps [rsp+0x30], xmm3
000070dabbdd865e  vmovaps [rsp+0x40], xmm4
000070dabbdd8664  vmovaps [rsp+0x50], xmm5
000070dabbdd866a  vmovaps [rsp+0x60], xmm6
000070dabbdd8670  vmovaps [rsp+0x70], xmm7
000070dabbdd8676  vmovaps [rsp+0x80], xmm8
000070dabbdd867f  vmovaps [rsp+0x90], xmm9
000070dabbdd8688  vmovaps [rsp+0xA0], xmm10
000070dabbdd8691  vmovaps [rsp+0xB0], xmm11
000070dabbdd869a  vmovaps [rsp+0xC0], xmm12
000070dabbdd86a3  vmovaps [rsp+0xD0], xmm13
000070dabbdd86ac  vmovaps [rsp+0xE0], xmm14
000070dabbdd86b5  sub rsp, 0x30
000070dabbdd86b9  movaps [rsp], xmm15
000070dabbdd86be  movaps [rsp+0x10], xmm3
000070dabbdd86c3  movaps [rsp+0x20], xmm7
000070dabbdd86c8  lea rdi, [rsp]
000070dabbdd86cc  mov esi, 0x00
000070dabbdd86d1  mov rax, 0x5C2CF7B6F530
000070dabbdd86db  call rax
000070dabbdd86dd  movaps xmm15, [rsp]
000070dabbdd86e2  add rsp, 0x30
000070dabbdd86e6  vmovaps xmm0, [rsp]
000070dabbdd86eb  vmovaps xmm1, [rsp+0x10]
000070dabbdd86f1  vmovaps xmm2, [rsp+0x20]
000070dabbdd86f7  vmovaps xmm3, [rsp+0x30]
000070dabbdd86fd  vmovaps xmm4, [rsp+0x40]
000070dabbdd8703  vmovaps xmm5, [rsp+0x50]
000070dabbdd8709  vmovaps xmm6, [rsp+0x60]
000070dabbdd870f  vmovaps xmm7, [rsp+0x70]
000070dabbdd8715  vmovaps xmm8, [rsp+0x80]
000070dabbdd871e  vmovaps xmm9, [rsp+0x90]
000070dabbdd8727  vmovaps xmm10, [rsp+0xA0]
000070dabbdd8730  vmovaps xmm11, [rsp+0xB0]
000070dabbdd8739  vmovaps xmm12, [rsp+0xC0]
000070dabbdd8742  vmovaps xmm13, [rsp+0xD0]
000070dabbdd874b  vmovaps xmm14, [rsp+0xE0]
000070dabbdd8754  add rsp, 0xF0
000070dabbdd875b  pop r11
000070dabbdd875d  pop r10
000070dabbdd875f  pop r9
000070dabbdd8761  pop r8
000070dabbdd8763  pop rsi
000070dabbdd8764  pop rdi
000070dabbdd8765  pop rdx
000070dabbdd8766  pop rcx
000070dabbdd8767  pop rax
000070dabbdd8768  add rsp, 0x08
000070dabbdd876c  jmp 0x000070DABBDD6030
000070dabbdd8771  sub rsp, 0x08
000070dabbdd8775  push rax
000070dabbdd8776  push rcx
000070dabbdd8777  push rdx
000070dabbdd8778  push rdi
000070dabbdd8779  push rsi
000070dabbdd877a  push r8
000070dabbdd877c  push r9
000070dabbdd877e  push r10
000070dabbdd8780  push r11
000070dabbdd8782  sub rsp, 0xF0
000070dabbdd8789  vmovaps [rsp], xmm0
000070dabbdd878e  vmovaps [rsp+0x10], xmm1
000070dabbdd8794  vmovaps [rsp+0x20], xmm2
000070dabbdd879a  vmovaps [rsp+0x30], xmm4
000070dabbdd87a0  vmovaps [rsp+0x40], xmm5
000070dabbdd87a6  vmovaps [rsp+0x50], xmm6
000070dabbdd87ac  vmovaps [rsp+0x60], xmm7
000070dabbdd87b2  vmovaps [rsp+0x70], xmm8
000070dabbdd87b8  vmovaps [rsp+0x80], xmm9
000070dabbdd87c1  vmovaps [rsp+0x90], xmm10
000070dabbdd87ca  vmovaps [rsp+0xA0], xmm11
000070dabbdd87d3  vmovaps [rsp+0xB0], xmm12
000070dabbdd87dc  vmovaps [rsp+0xC0], xmm13
000070dabbdd87e5  vmovaps [rsp+0xD0], xmm14
000070dabbdd87ee  vmovaps [rsp+0xE0], xmm15
000070dabbdd87f7  sub rsp, 0x30
000070dabbdd87fb  movaps [rsp], xmm3
000070dabbdd87ff  movaps [rsp+0x10], xmm1
000070dabbdd8804  movaps [rsp+0x20], xmm15
000070dabbdd880a  lea rdi, [rsp]
000070dabbdd880e  mov esi, 0x00
000070dabbdd8813  mov rax, 0x5C2CF7B6F530
000070dabbdd881d  call rax
000070dabbdd881f  movaps xmm3, [rsp]
000070dabbdd8823  add rsp, 0x30
000070dabbdd8827  vmovaps xmm0, [rsp]
000070dabbdd882c  vmovaps xmm1, [rsp+0x10]
000070dabbdd8832  vmovaps xmm2, [rsp+0x20]
000070dabbdd8838  vmovaps xmm4, [rsp+0x30]
000070dabbdd883e  vmovaps xmm5, [rsp+0x40]
000070dabbdd8844  vmovaps xmm6, [rsp+0x50]
000070dabbdd884a  vmovaps xmm7, [rsp+0x60]
000070dabbdd8850  vmovaps xmm8, [rsp+0x70]
000070dabbdd8856  vmovaps xmm9, [rsp+0x80]
000070dabbdd885f  vmovaps xmm10, [rsp+0x90]
000070dabbdd8868  vmovaps xmm11, [rsp+0xA0]
000070dabbdd8871  vmovaps xmm12, [rsp+0xB0]
000070dabbdd887a  vmovaps xmm13, [rsp+0xC0]
000070dabbdd8883  vmovaps xmm14, [rsp+0xD0]
000070dabbdd888c  vmovaps xmm15, [rsp+0xE0]
000070dabbdd8895  add rsp, 0xF0
000070dabbdd889c  pop r11
000070dabbdd889e  pop r10
000070dabbdd88a0  pop r9
000070dabbdd88a2  pop r8
000070dabbdd88a4  pop rsi
000070dabbdd88a5  pop rdi
000070dabbdd88a6  pop rdx
000070dabbdd88a7  pop rcx
000070dabbdd88a8  pop rax
000070dabbdd88a9  add rsp, 0x08
000070dabbdd88ad  jmp 0x000070DABBDD60BF
000070dabbdd88b2  call 0x000070DABBCD64F0
000070dabbdd88b7  jmp 0x000070DABBDD60C9
000070dabbdd88bc  sub rsp, 0x08
000070dabbdd88c0  push rax
000070dabbdd88c1  push rcx
000070dabbdd88c2  push rdx
000070dabbdd88c3  push rdi
000070dabbdd88c4  push rsi
000070dabbdd88c5  push r8
000070dabbdd88c7  push r9
000070dabbdd88c9  push r10
000070dabbdd88cb  push r11
000070dabbdd88cd  sub rsp, 0xF0
000070dabbdd88d4  vmovaps [rsp], xmm0
000070dabbdd88d9  vmovaps [rsp+0x10], xmm1
000070dabbdd88df  vmovaps [rsp+0x20], xmm2
000070dabbdd88e5  vmovaps [rsp+0x30], xmm3
000070dabbdd88eb  vmovaps [rsp+0x40], xmm4
000070dabbdd88f1  vmovaps [rsp+0x50], xmm5
000070dabbdd88f7  vmovaps [rsp+0x60], xmm6
000070dabbdd88fd  vmovaps [rsp+0x70], xmm7
000070dabbdd8903  vmovaps [rsp+0x80], xmm8
000070dabbdd890c  vmovaps [rsp+0x90], xmm9
000070dabbdd8915  vmovaps [rsp+0xA0], xmm10
000070dabbdd891e  vmovaps [rsp+0xB0], xmm11
000070dabbdd8927  vmovaps [rsp+0xC0], xmm12
000070dabbdd8930  vmovaps [rsp+0xD0], xmm13
000070dabbdd8939  vmovaps [rsp+0xE0], xmm14
000070dabbdd8942  sub rsp, 0x30
000070dabbdd8946  movaps [rsp], xmm15
000070dabbdd894b  movaps [rsp+0x10], xmm14
000070dabbdd8951  movaps [rsp+0x20], xmm4
000070dabbdd8956  lea rdi, [rsp]
000070dabbdd895a  mov esi, 0x00
000070dabbdd895f  mov rax, 0x5C2CF7B6F530
000070dabbdd8969  call rax
000070dabbdd896b  movaps xmm15, [rsp]
000070dabbdd8970  add rsp, 0x30
000070dabbdd8974  vmovaps xmm0, [rsp]
000070dabbdd8979  vmovaps xmm1, [rsp+0x10]
000070dabbdd897f  vmovaps xmm2, [rsp+0x20]
000070dabbdd8985  vmovaps xmm3, [rsp+0x30]
000070dabbdd898b  vmovaps xmm4, [rsp+0x40]
000070dabbdd8991  vmovaps xmm5, [rsp+0x50]
000070dabbdd8997  vmovaps xmm6, [rsp+0x60]
000070dabbdd899d  vmovaps xmm7, [rsp+0x70]
000070dabbdd89a3  vmovaps xmm8, [rsp+0x80]
000070dabbdd89ac  vmovaps xmm9, [rsp+0x90]
000070dabbdd89b5  vmovaps xmm10, [rsp+0xA0]
000070dabbdd89be  vmovaps xmm11, [rsp+0xB0]
000070dabbdd89c7  vmovaps xmm12, [rsp+0xC0]
000070dabbdd89d0  vmovaps xmm13, [rsp+0xD0]
000070dabbdd89d9  vmovaps xmm14, [rsp+0xE0]
000070dabbdd89e2  add rsp, 0xF0
000070dabbdd89e9  pop r11
000070dabbdd89eb  pop r10
000070dabbdd89ed  pop r9
000070dabbdd89ef  pop r8
000070dabbdd89f1  pop rsi
000070dabbdd89f2  pop rdi
000070dabbdd89f3  pop rdx
000070dabbdd89f4  pop rcx
000070dabbdd89f5  pop rax
000070dabbdd89f6  add rsp, 0x08
000070dabbdd89fa  jmp 0x000070DABBDD60F7
000070dabbdd89ff  sub rsp, 0x08
000070dabbdd8a03  push rax
000070dabbdd8a04  push rcx
000070dabbdd8a05  push rdx
000070dabbdd8a06  push rdi
000070dabbdd8a07  push rsi
000070dabbdd8a08  push r8
000070dabbdd8a0a  push r9
000070dabbdd8a0c  push r10
000070dabbdd8a0e  push r11
000070dabbdd8a10  sub rsp, 0xF0
000070dabbdd8a17  vmovaps [rsp], xmm0
000070dabbdd8a1c  vmovaps [rsp+0x10], xmm1
000070dabbdd8a22  vmovaps [rsp+0x20], xmm2
000070dabbdd8a28  vmovaps [rsp+0x30], xmm3
000070dabbdd8a2e  vmovaps [rsp+0x40], xmm4
000070dabbdd8a34  vmovaps [rsp+0x50], xmm5
000070dabbdd8a3a  vmovaps [rsp+0x60], xmm6
000070dabbdd8a40  vmovaps [rsp+0x70], xmm7
000070dabbdd8a46  vmovaps [rsp+0x80], xmm8
000070dabbdd8a4f  vmovaps [rsp+0x90], xmm9
000070dabbdd8a58  vmovaps [rsp+0xA0], xmm10
000070dabbdd8a61  vmovaps [rsp+0xB0], xmm11
000070dabbdd8a6a  vmovaps [rsp+0xC0], xmm12
000070dabbdd8a73  vmovaps [rsp+0xD0], xmm13
000070dabbdd8a7c  vmovaps [rsp+0xE0], xmm15
000070dabbdd8a85  sub rsp, 0x30
000070dabbdd8a89  movaps [rsp], xmm14
000070dabbdd8a8e  movaps [rsp+0x10], xmm2
000070dabbdd8a93  movaps [rsp+0x20], xmm1
000070dabbdd8a98  lea rdi, [rsp]
000070dabbdd8a9c  mov esi, 0x00
000070dabbdd8aa1  mov rax, 0x5C2CF7B6F530
000070dabbdd8aab  call rax
000070dabbdd8aad  movaps xmm14, [rsp]
000070dabbdd8ab2  add rsp, 0x30
000070dabbdd8ab6  vmovaps xmm0, [rsp]
000070dabbdd8abb  vmovaps xmm1, [rsp+0x10]
000070dabbdd8ac1  vmovaps xmm2, [rsp+0x20]
000070dabbdd8ac7  vmovaps xmm3, [rsp+0x30]
000070dabbdd8acd  vmovaps xmm4, [rsp+0x40]
000070dabbdd8ad3  vmovaps xmm5, [rsp+0x50]
000070dabbdd8ad9  vmovaps xmm6, [rsp+0x60]
000070dabbdd8adf  vmovaps xmm7, [rsp+0x70]
000070dabbdd8ae5  vmovaps xmm8, [rsp+0x80]
000070dabbdd8aee  vmovaps xmm9, [rsp+0x90]
000070dabbdd8af7  vmovaps xmm10, [rsp+0xA0]
000070dabbdd8b00  vmovaps xmm11, [rsp+0xB0]
000070dabbdd8b09  vmovaps xmm12, [rsp+0xC0]
000070dabbdd8b12  vmovaps xmm13, [rsp+0xD0]
000070dabbdd8b1b  vmovaps xmm15, [rsp+0xE0]
000070dabbdd8b24  add rsp, 0xF0
000070dabbdd8b2b  pop r11
000070dabbdd8b2d  pop r10
000070dabbdd8b2f  pop r9
000070dabbdd8b31  pop r8
000070dabbdd8b33  pop rsi
000070dabbdd8b34  pop rdi
000070dabbdd8b35  pop rdx
000070dabbdd8b36  pop rcx
000070dabbdd8b37  pop rax
000070dabbdd8b38  add rsp, 0x08
000070dabbdd8b3c  jmp 0x000070DABBDD611D
000070dabbdd8b41  sub rsp, 0x08
000070dabbdd8b45  push rax
000070dabbdd8b46  push rcx
000070dabbdd8b47  push rdx
000070dabbdd8b48  push rdi
000070dabbdd8b49  push rsi
000070dabbdd8b4a  push r8
000070dabbdd8b4c  push r9
000070dabbdd8b4e  push r10
000070dabbdd8b50  push r11
000070dabbdd8b52  sub rsp, 0xF0
000070dabbdd8b59  vmovaps [rsp], xmm0
000070dabbdd8b5e  vmovaps [rsp+0x10], xmm2
000070dabbdd8b64  vmovaps [rsp+0x20], xmm3
000070dabbdd8b6a  vmovaps [rsp+0x30], xmm4
000070dabbdd8b70  vmovaps [rsp+0x40], xmm5
000070dabbdd8b76  vmovaps [rsp+0x50], xmm6
000070dabbdd8b7c  vmovaps [rsp+0x60], xmm7
000070dabbdd8b82  vmovaps [rsp+0x70], xmm8
000070dabbdd8b88  vmovaps [rsp+0x80], xmm9
000070dabbdd8b91  vmovaps [rsp+0x90], xmm10
000070dabbdd8b9a  vmovaps [rsp+0xA0], xmm11
000070dabbdd8ba3  vmovaps [rsp+0xB0], xmm12
000070dabbdd8bac  vmovaps [rsp+0xC0], xmm13
000070dabbdd8bb5  vmovaps [rsp+0xD0], xmm14
000070dabbdd8bbe  vmovaps [rsp+0xE0], xmm15
000070dabbdd8bc7  sub rsp, 0x30
000070dabbdd8bcb  movaps [rsp], xmm1
000070dabbdd8bcf  movaps [rsp+0x10], xmm4
000070dabbdd8bd4  movaps [rsp+0x20], xmm9
000070dabbdd8bda  lea rdi, [rsp]
000070dabbdd8bde  mov esi, 0x00
000070dabbdd8be3  mov rax, 0x5C2CF7B6F530
000070dabbdd8bed  call rax
000070dabbdd8bef  movaps xmm1, [rsp]
000070dabbdd8bf3  add rsp, 0x30
000070dabbdd8bf7  vmovaps xmm0, [rsp]
000070dabbdd8bfc  vmovaps xmm2, [rsp+0x10]
000070dabbdd8c02  vmovaps xmm3, [rsp+0x20]
000070dabbdd8c08  vmovaps xmm4, [rsp+0x30]
000070dabbdd8c0e  vmovaps xmm5, [rsp+0x40]
000070dabbdd8c14  vmovaps xmm6, [rsp+0x50]
000070dabbdd8c1a  vmovaps xmm7, [rsp+0x60]
000070dabbdd8c20  vmovaps xmm8, [rsp+0x70]
000070dabbdd8c26  vmovaps xmm9, [rsp+0x80]
000070dabbdd8c2f  vmovaps xmm10, [rsp+0x90]
000070dabbdd8c38  vmovaps xmm11, [rsp+0xA0]
000070dabbdd8c41  vmovaps xmm12, [rsp+0xB0]
000070dabbdd8c4a  vmovaps xmm13, [rsp+0xC0]
000070dabbdd8c53  vmovaps xmm14, [rsp+0xD0]
000070dabbdd8c5c  vmovaps xmm15, [rsp+0xE0]
000070dabbdd8c65  add rsp, 0xF0
000070dabbdd8c6c  pop r11
000070dabbdd8c6e  pop r10
000070dabbdd8c70  pop r9
000070dabbdd8c72  pop r8
000070dabbdd8c74  pop rsi
000070dabbdd8c75  pop rdi
000070dabbdd8c76  pop rdx
000070dabbdd8c77  pop rcx
000070dabbdd8c78  pop rax
000070dabbdd8c79  add rsp, 0x08
000070dabbdd8c7d  jmp 0x000070DABBDD613B
000070dabbdd8c82  sub rsp, 0x08
000070dabbdd8c86  push rax
000070dabbdd8c87  push rcx
000070dabbdd8c88  push rdx
000070dabbdd8c89  push rdi
000070dabbdd8c8a  push rsi
000070dabbdd8c8b  push r8
000070dabbdd8c8d  push r9
000070dabbdd8c8f  push r10
000070dabbdd8c91  push r11
000070dabbdd8c93  sub rsp, 0xF0
000070dabbdd8c9a  vmovaps [rsp], xmm0
000070dabbdd8c9f  vmovaps [rsp+0x10], xmm1
000070dabbdd8ca5  vmovaps [rsp+0x20], xmm2
000070dabbdd8cab  vmovaps [rsp+0x30], xmm3
000070dabbdd8cb1  vmovaps [rsp+0x40], xmm5
000070dabbdd8cb7  vmovaps [rsp+0x50], xmm6
000070dabbdd8cbd  vmovaps [rsp+0x60], xmm7
000070dabbdd8cc3  vmovaps [rsp+0x70], xmm8
000070dabbdd8cc9  vmovaps [rsp+0x80], xmm9
000070dabbdd8cd2  vmovaps [rsp+0x90], xmm10
000070dabbdd8cdb  vmovaps [rsp+0xA0], xmm11
000070dabbdd8ce4  vmovaps [rsp+0xB0], xmm12
000070dabbdd8ced  vmovaps [rsp+0xC0], xmm13
000070dabbdd8cf6  vmovaps [rsp+0xD0], xmm14
000070dabbdd8cff  vmovaps [rsp+0xE0], xmm15
000070dabbdd8d08  sub rsp, 0x30
000070dabbdd8d0c  movaps [rsp], xmm4
000070dabbdd8d10  movaps [rsp+0x10], xmm2
000070dabbdd8d15  movaps [rsp+0x20], xmm9
000070dabbdd8d1b  lea rdi, [rsp]
000070dabbdd8d1f  mov esi, 0x00
000070dabbdd8d24  mov rax, 0x5C2CF7B6F530
000070dabbdd8d2e  call rax
000070dabbdd8d30  movaps xmm4, [rsp]
000070dabbdd8d34  add rsp, 0x30
000070dabbdd8d38  vmovaps xmm0, [rsp]
000070dabbdd8d3d  vmovaps xmm1, [rsp+0x10]
000070dabbdd8d43  vmovaps xmm2, [rsp+0x20]
000070dabbdd8d49  vmovaps xmm3, [rsp+0x30]
000070dabbdd8d4f  vmovaps xmm5, [rsp+0x40]
000070dabbdd8d55  vmovaps xmm6, [rsp+0x50]
000070dabbdd8d5b  vmovaps xmm7, [rsp+0x60]
000070dabbdd8d61  vmovaps xmm8, [rsp+0x70]
000070dabbdd8d67  vmovaps xmm9, [rsp+0x80]
000070dabbdd8d70  vmovaps xmm10, [rsp+0x90]
000070dabbdd8d79  vmovaps xmm11, [rsp+0xA0]
000070dabbdd8d82  vmovaps xmm12, [rsp+0xB0]
000070dabbdd8d8b  vmovaps xmm13, [rsp+0xC0]
000070dabbdd8d94  vmovaps xmm14, [rsp+0xD0]
000070dabbdd8d9d  vmovaps xmm15, [rsp+0xE0]
000070dabbdd8da6  add rsp, 0xF0
000070dabbdd8dad  pop r11
000070dabbdd8daf  pop r10
000070dabbdd8db1  pop r9
000070dabbdd8db3  pop r8
000070dabbdd8db5  pop rsi
000070dabbdd8db6  pop rdi
000070dabbdd8db7  pop rdx
000070dabbdd8db8  pop rcx
000070dabbdd8db9  pop rax
000070dabbdd8dba  add rsp, 0x08
000070dabbdd8dbe  jmp 0x000070DABBDD616B
000070dabbdd8dc3  sub rsp, 0x08
000070dabbdd8dc7  push rax
000070dabbdd8dc8  push rcx
000070dabbdd8dc9  push rdx
000070dabbdd8dca  push rdi
000070dabbdd8dcb  push rsi
000070dabbdd8dcc  push r8
000070dabbdd8dce  push r9
000070dabbdd8dd0  push r10
000070dabbdd8dd2  push r11
000070dabbdd8dd4  sub rsp, 0xF0
000070dabbdd8ddb  vmovaps [rsp], xmm0
000070dabbdd8de0  vmovaps [rsp+0x10], xmm1
000070dabbdd8de6  vmovaps [rsp+0x20], xmm2
000070dabbdd8dec  vmovaps [rsp+0x30], xmm3
000070dabbdd8df2  vmovaps [rsp+0x40], xmm4
000070dabbdd8df8  vmovaps [rsp+0x50], xmm5
000070dabbdd8dfe  vmovaps [rsp+0x60], xmm6
000070dabbdd8e04  vmovaps [rsp+0x70], xmm7
000070dabbdd8e0a  vmovaps [rsp+0x80], xmm8
000070dabbdd8e13  vmovaps [rsp+0x90], xmm10
000070dabbdd8e1c  vmovaps [rsp+0xA0], xmm11
000070dabbdd8e25  vmovaps [rsp+0xB0], xmm12
000070dabbdd8e2e  vmovaps [rsp+0xC0], xmm13
000070dabbdd8e37  vmovaps [rsp+0xD0], xmm14
000070dabbdd8e40  vmovaps [rsp+0xE0], xmm15
000070dabbdd8e49  sub rsp, 0x30
000070dabbdd8e4d  movaps [rsp], xmm9
000070dabbdd8e52  movaps [rsp+0x10], xmm2
000070dabbdd8e57  movaps [rsp+0x20], xmm1
000070dabbdd8e5c  lea rdi, [rsp]
000070dabbdd8e60  mov esi, 0x00
000070dabbdd8e65  mov rax, 0x5C2CF7B6F530
000070dabbdd8e6f  call rax
000070dabbdd8e71  movaps xmm9, [rsp]
000070dabbdd8e76  add rsp, 0x30
000070dabbdd8e7a  vmovaps xmm0, [rsp]
000070dabbdd8e7f  vmovaps xmm1, [rsp+0x10]
000070dabbdd8e85  vmovaps xmm2, [rsp+0x20]
000070dabbdd8e8b  vmovaps xmm3, [rsp+0x30]
000070dabbdd8e91  vmovaps xmm4, [rsp+0x40]
000070dabbdd8e97  vmovaps xmm5, [rsp+0x50]
000070dabbdd8e9d  vmovaps xmm6, [rsp+0x60]
000070dabbdd8ea3  vmovaps xmm7, [rsp+0x70]
000070dabbdd8ea9  vmovaps xmm8, [rsp+0x80]
000070dabbdd8eb2  vmovaps xmm10, [rsp+0x90]
000070dabbdd8ebb  vmovaps xmm11, [rsp+0xA0]
000070dabbdd8ec4  vmovaps xmm12, [rsp+0xB0]
000070dabbdd8ecd  vmovaps xmm13, [rsp+0xC0]
000070dabbdd8ed6  vmovaps xmm14, [rsp+0xD0]
000070dabbdd8edf  vmovaps xmm15, [rsp+0xE0]
000070dabbdd8ee8  add rsp, 0xF0
000070dabbdd8eef  pop r11
000070dabbdd8ef1  pop r10
000070dabbdd8ef3  pop r9
000070dabbdd8ef5  pop r8
000070dabbdd8ef7  pop rsi
000070dabbdd8ef8  pop rdi
000070dabbdd8ef9  pop rdx
000070dabbdd8efa  pop rcx
000070dabbdd8efb  pop rax
000070dabbdd8efc  add rsp, 0x08
000070dabbdd8f00  jmp 0x000070DABBDD61A1
000070dabbdd8f05  sub rsp, 0x08
000070dabbdd8f09  push rax
000070dabbdd8f0a  push rcx
000070dabbdd8f0b  push rdx
000070dabbdd8f0c  push rdi
000070dabbdd8f0d  push rsi
000070dabbdd8f0e  push r8
000070dabbdd8f10  push r9
000070dabbdd8f12  push r10
000070dabbdd8f14  push r11
000070dabbdd8f16  sub rsp, 0xF0
000070dabbdd8f1d  vmovaps [rsp], xmm0
000070dabbdd8f22  vmovaps [rsp+0x10], xmm2
000070dabbdd8f28  vmovaps [rsp+0x20], xmm3
000070dabbdd8f2e  vmovaps [rsp+0x30], xmm4
000070dabbdd8f34  vmovaps [rsp+0x40], xmm5
000070dabbdd8f3a  vmovaps [rsp+0x50], xmm6
000070dabbdd8f40  vmovaps [rsp+0x60], xmm7
000070dabbdd8f46  vmovaps [rsp+0x70], xmm8
000070dabbdd8f4c  vmovaps [rsp+0x80], xmm9
000070dabbdd8f55  vmovaps [rsp+0x90], xmm10
000070dabbdd8f5e  vmovaps [rsp+0xA0], xmm11
000070dabbdd8f67  vmovaps [rsp+0xB0], xmm12
000070dabbdd8f70  vmovaps [rsp+0xC0], xmm13
000070dabbdd8f79  vmovaps [rsp+0xD0], xmm14
000070dabbdd8f82  vmovaps [rsp+0xE0], xmm15
000070dabbdd8f8b  sub rsp, 0x30
000070dabbdd8f8f  movaps [rsp], xmm1
000070dabbdd8f93  movaps [rsp+0x10], xmm15
000070dabbdd8f99  movaps [rsp+0x20], xmm6
000070dabbdd8f9e  lea rdi, [rsp]
000070dabbdd8fa2  mov esi, 0x00
000070dabbdd8fa7  mov rax, 0x5C2CF7B6F530
000070dabbdd8fb1  call rax
000070dabbdd8fb3  movaps xmm1, [rsp]
000070dabbdd8fb7  add rsp, 0x30
000070dabbdd8fbb  vmovaps xmm0, [rsp]
000070dabbdd8fc0  vmovaps xmm2, [rsp+0x10]
000070dabbdd8fc6  vmovaps xmm3, [rsp+0x20]
000070dabbdd8fcc  vmovaps xmm4, [rsp+0x30]
000070dabbdd8fd2  vmovaps xmm5, [rsp+0x40]
000070dabbdd8fd8  vmovaps xmm6, [rsp+0x50]
000070dabbdd8fde  vmovaps xmm7, [rsp+0x60]
000070dabbdd8fe4  vmovaps xmm8, [rsp+0x70]
000070dabbdd8fea  vmovaps xmm9, [rsp+0x80]
000070dabbdd8ff3  vmovaps xmm10, [rsp+0x90]
000070dabbdd8ffc  vmovaps xmm11, [rsp+0xA0]
000070dabbdd9005  vmovaps xmm12, [rsp+0xB0]
000070dabbdd900e  vmovaps xmm13, [rsp+0xC0]
000070dabbdd9017  vmovaps xmm14, [rsp+0xD0]
000070dabbdd9020  vmovaps xmm15, [rsp+0xE0]
000070dabbdd9029  add rsp, 0xF0
000070dabbdd9030  pop r11
000070dabbdd9032  pop r10
000070dabbdd9034  pop r9
000070dabbdd9036  pop r8
000070dabbdd9038  pop rsi
000070dabbdd9039  pop rdi
000070dabbdd903a  pop rdx
000070dabbdd903b  pop rcx
000070dabbdd903c  pop rax
000070dabbdd903d  add rsp, 0x08
000070dabbdd9041  jmp 0x000070DABBDD61C2
000070dabbdd9046  sub rsp, 0x08
000070dabbdd904a  push rax
000070dabbdd904b  push rcx
000070dabbdd904c  push rdx
000070dabbdd904d  push rdi
000070dabbdd904e  push rsi
000070dabbdd904f  push r8
000070dabbdd9051  push r9
000070dabbdd9053  push r10
000070dabbdd9055  push r11
000070dabbdd9057  sub rsp, 0xF0
000070dabbdd905e  vmovaps [rsp], xmm0
000070dabbdd9063  vmovaps [rsp+0x10], xmm1
000070dabbdd9069  vmovaps [rsp+0x20], xmm2
000070dabbdd906f  vmovaps [rsp+0x30], xmm3
000070dabbdd9075  vmovaps [rsp+0x40], xmm4
000070dabbdd907b  vmovaps [rsp+0x50], xmm5
000070dabbdd9081  vmovaps [rsp+0x60], xmm6
000070dabbdd9087  vmovaps [rsp+0x70], xmm7
000070dabbdd908d  vmovaps [rsp+0x80], xmm8
000070dabbdd9096  vmovaps [rsp+0x90], xmm9
000070dabbdd909f  vmovaps [rsp+0xA0], xmm10
000070dabbdd90a8  vmovaps [rsp+0xB0], xmm11
000070dabbdd90b1  vmovaps [rsp+0xC0], xmm12
000070dabbdd90ba  vmovaps [rsp+0xD0], xmm13
000070dabbdd90c3  vmovaps [rsp+0xE0], xmm14
000070dabbdd90cc  sub rsp, 0x30
000070dabbdd90d0  movaps [rsp], xmm15
000070dabbdd90d5  movaps [rsp+0x10], xmm5
000070dabbdd90da  movaps [rsp+0x20], xmm3
000070dabbdd90df  lea rdi, [rsp]
000070dabbdd90e3  mov esi, 0x00
000070dabbdd90e8  mov rax, 0x5C2CF7B6F530
000070dabbdd90f2  call rax
000070dabbdd90f4  movaps xmm15, [rsp]
000070dabbdd90f9  add rsp, 0x30
000070dabbdd90fd  vmovaps xmm0, [rsp]
000070dabbdd9102  vmovaps xmm1, [rsp+0x10]
000070dabbdd9108  vmovaps xmm2, [rsp+0x20]
000070dabbdd910e  vmovaps xmm3, [rsp+0x30]
000070dabbdd9114  vmovaps xmm4, [rsp+0x40]
000070dabbdd911a  vmovaps xmm5, [rsp+0x50]
000070dabbdd9120  vmovaps xmm6, [rsp+0x60]
000070dabbdd9126  vmovaps xmm7, [rsp+0x70]
000070dabbdd912c  vmovaps xmm8, [rsp+0x80]
000070dabbdd9135  vmovaps xmm9, [rsp+0x90]
000070dabbdd913e  vmovaps xmm10, [rsp+0xA0]
000070dabbdd9147  vmovaps xmm11, [rsp+0xB0]
000070dabbdd9150  vmovaps xmm12, [rsp+0xC0]
000070dabbdd9159  vmovaps xmm13, [rsp+0xD0]
000070dabbdd9162  vmovaps xmm14, [rsp+0xE0]
000070dabbdd916b  add rsp, 0xF0
000070dabbdd9172  pop r11
000070dabbdd9174  pop r10
000070dabbdd9176  pop r9
000070dabbdd9178  pop r8
000070dabbdd917a  pop rsi
000070dabbdd917b  pop rdi
000070dabbdd917c  pop rdx
000070dabbdd917d  pop rcx
000070dabbdd917e  pop rax
000070dabbdd917f  add rsp, 0x08
000070dabbdd9183  jmp 0x000070DABBDD61DC
000070dabbdd9188  sub rsp, 0x08
000070dabbdd918c  push rax
000070dabbdd918d  push rcx
000070dabbdd918e  push rdx
000070dabbdd918f  push rdi
000070dabbdd9190  push rsi
000070dabbdd9191  push r8
000070dabbdd9193  push r9
000070dabbdd9195  push r10
000070dabbdd9197  push r11
000070dabbdd9199  sub rsp, 0xF0
000070dabbdd91a0  vmovaps [rsp], xmm0
000070dabbdd91a5  vmovaps [rsp+0x10], xmm1
000070dabbdd91ab  vmovaps [rsp+0x20], xmm2
000070dabbdd91b1  vmovaps [rsp+0x30], xmm3
000070dabbdd91b7  vmovaps [rsp+0x40], xmm4
000070dabbdd91bd  vmovaps [rsp+0x50], xmm6
000070dabbdd91c3  vmovaps [rsp+0x60], xmm7
000070dabbdd91c9  vmovaps [rsp+0x70], xmm8
000070dabbdd91cf  vmovaps [rsp+0x80], xmm9
000070dabbdd91d8  vmovaps [rsp+0x90], xmm10
000070dabbdd91e1  vmovaps [rsp+0xA0], xmm11
000070dabbdd91ea  vmovaps [rsp+0xB0], xmm12
000070dabbdd91f3  vmovaps [rsp+0xC0], xmm13
000070dabbdd91fc  vmovaps [rsp+0xD0], xmm14
000070dabbdd9205  vmovaps [rsp+0xE0], xmm15
000070dabbdd920e  sub rsp, 0x30
000070dabbdd9212  movaps [rsp], xmm5
000070dabbdd9216  movaps [rsp+0x10], xmm8
000070dabbdd921c  movaps [rsp+0x20], xmm6
000070dabbdd9221  lea rdi, [rsp]
000070dabbdd9225  mov esi, 0x00
000070dabbdd922a  mov rax, 0x5C2CF7B6F530
000070dabbdd9234  call rax
000070dabbdd9236  movaps xmm5, [rsp]
000070dabbdd923a  add rsp, 0x30
000070dabbdd923e  vmovaps xmm0, [rsp]
000070dabbdd9243  vmovaps xmm1, [rsp+0x10]
000070dabbdd9249  vmovaps xmm2, [rsp+0x20]
000070dabbdd924f  vmovaps xmm3, [rsp+0x30]
000070dabbdd9255  vmovaps xmm4, [rsp+0x40]
000070dabbdd925b  vmovaps xmm6, [rsp+0x50]
000070dabbdd9261  vmovaps xmm7, [rsp+0x60]
000070dabbdd9267  vmovaps xmm8, [rsp+0x70]
000070dabbdd926d  vmovaps xmm9, [rsp+0x80]
000070dabbdd9276  vmovaps xmm10, [rsp+0x90]
000070dabbdd927f  vmovaps xmm11, [rsp+0xA0]
000070dabbdd9288  vmovaps xmm12, [rsp+0xB0]
000070dabbdd9291  vmovaps xmm13, [rsp+0xC0]
000070dabbdd929a  vmovaps xmm14, [rsp+0xD0]
000070dabbdd92a3  vmovaps xmm15, [rsp+0xE0]
000070dabbdd92ac  add rsp, 0xF0
000070dabbdd92b3  pop r11
000070dabbdd92b5  pop r10
000070dabbdd92b7  pop r9
000070dabbdd92b9  pop r8
000070dabbdd92bb  pop rsi
000070dabbdd92bc  pop rdi
000070dabbdd92bd  pop rdx
000070dabbdd92be  pop rcx
000070dabbdd92bf  pop rax
000070dabbdd92c0  add rsp, 0x08
000070dabbdd92c4  jmp 0x000070DABBDD6200
000070dabbdd92c9  sub rsp, 0x08
000070dabbdd92cd  push rax
000070dabbdd92ce  push rcx
000070dabbdd92cf  push rdx
000070dabbdd92d0  push rdi
000070dabbdd92d1  push rsi
000070dabbdd92d2  push r8
000070dabbdd92d4  push r9
000070dabbdd92d6  push r10
000070dabbdd92d8  push r11
000070dabbdd92da  sub rsp, 0xF0
000070dabbdd92e1  vmovaps [rsp], xmm0
000070dabbdd92e6  vmovaps [rsp+0x10], xmm1
000070dabbdd92ec  vmovaps [rsp+0x20], xmm2
000070dabbdd92f2  vmovaps [rsp+0x30], xmm3
000070dabbdd92f8  vmovaps [rsp+0x40], xmm4
000070dabbdd92fe  vmovaps [rsp+0x50], xmm5
000070dabbdd9304  vmovaps [rsp+0x60], xmm7
000070dabbdd930a  vmovaps [rsp+0x70], xmm8
000070dabbdd9310  vmovaps [rsp+0x80], xmm9
000070dabbdd9319  vmovaps [rsp+0x90], xmm10
000070dabbdd9322  vmovaps [rsp+0xA0], xmm11
000070dabbdd932b  vmovaps [rsp+0xB0], xmm12
000070dabbdd9334  vmovaps [rsp+0xC0], xmm13
000070dabbdd933d  vmovaps [rsp+0xD0], xmm14
000070dabbdd9346  vmovaps [rsp+0xE0], xmm15
000070dabbdd934f  sub rsp, 0x30
000070dabbdd9353  movaps [rsp], xmm6
000070dabbdd9357  movaps [rsp+0x10], xmm10
000070dabbdd935d  movaps [rsp+0x20], xmm8
000070dabbdd9363  lea rdi, [rsp]
000070dabbdd9367  mov esi, 0x00
000070dabbdd936c  mov rax, 0x5C2CF7B6F530
000070dabbdd9376  call rax
000070dabbdd9378  movaps xmm6, [rsp]
000070dabbdd937c  add rsp, 0x30
000070dabbdd9380  vmovaps xmm0, [rsp]
000070dabbdd9385  vmovaps xmm1, [rsp+0x10]
000070dabbdd938b  vmovaps xmm2, [rsp+0x20]
000070dabbdd9391  vmovaps xmm3, [rsp+0x30]
000070dabbdd9397  vmovaps xmm4, [rsp+0x40]
000070dabbdd939d  vmovaps xmm5, [rsp+0x50]
000070dabbdd93a3  vmovaps xmm7, [rsp+0x60]
000070dabbdd93a9  vmovaps xmm8, [rsp+0x70]
000070dabbdd93af  vmovaps xmm9, [rsp+0x80]
000070dabbdd93b8  vmovaps xmm10, [rsp+0x90]
000070dabbdd93c1  vmovaps xmm11, [rsp+0xA0]
000070dabbdd93ca  vmovaps xmm12, [rsp+0xB0]
000070dabbdd93d3  vmovaps xmm13, [rsp+0xC0]
000070dabbdd93dc  vmovaps xmm14, [rsp+0xD0]
000070dabbdd93e5  vmovaps xmm15, [rsp+0xE0]
000070dabbdd93ee  add rsp, 0xF0
000070dabbdd93f5  pop r11
000070dabbdd93f7  pop r10
000070dabbdd93f9  pop r9
000070dabbdd93fb  pop r8
000070dabbdd93fd  pop rsi
000070dabbdd93fe  pop rdi
000070dabbdd93ff  pop rdx
000070dabbdd9400  pop rcx
000070dabbdd9401  pop rax
000070dabbdd9402  add rsp, 0x08
000070dabbdd9406  jmp 0x000070DABBDD6225
000070dabbdd940b  sub rsp, 0x08
000070dabbdd940f  push rax
000070dabbdd9410  push rcx
000070dabbdd9411  push rdx
000070dabbdd9412  push rdi
000070dabbdd9413  push rsi
000070dabbdd9414  push r8
000070dabbdd9416  push r9
000070dabbdd9418  push r10
000070dabbdd941a  push r11
000070dabbdd941c  sub rsp, 0xF0
000070dabbdd9423  vmovaps [rsp], xmm0
000070dabbdd9428  vmovaps [rsp+0x10], xmm1
000070dabbdd942e  vmovaps [rsp+0x20], xmm2
000070dabbdd9434  vmovaps [rsp+0x30], xmm3
000070dabbdd943a  vmovaps [rsp+0x40], xmm4
000070dabbdd9440  vmovaps [rsp+0x50], xmm5
000070dabbdd9446  vmovaps [rsp+0x60], xmm6
000070dabbdd944c  vmovaps [rsp+0x70], xmm7
000070dabbdd9452  vmovaps [rsp+0x80], xmm8
000070dabbdd945b  vmovaps [rsp+0x90], xmm9
000070dabbdd9464  vmovaps [rsp+0xA0], xmm11
000070dabbdd946d  vmovaps [rsp+0xB0], xmm12
000070dabbdd9476  vmovaps [rsp+0xC0], xmm13
000070dabbdd947f  vmovaps [rsp+0xD0], xmm14
000070dabbdd9488  vmovaps [rsp+0xE0], xmm15
000070dabbdd9491  sub rsp, 0x30
000070dabbdd9495  movaps [rsp], xmm10
000070dabbdd949a  movaps [rsp+0x10], xmm8
000070dabbdd94a0  movaps [rsp+0x20], xmm14
000070dabbdd94a6  lea rdi, [rsp]
000070dabbdd94aa  mov esi, 0x00
000070dabbdd94af  mov rax, 0x5C2CF7B6F530
000070dabbdd94b9  call rax
000070dabbdd94bb  movaps xmm10, [rsp]
000070dabbdd94c0  add rsp, 0x30
000070dabbdd94c4  vmovaps xmm0, [rsp]
000070dabbdd94c9  vmovaps xmm1, [rsp+0x10]
000070dabbdd94cf  vmovaps xmm2, [rsp+0x20]
000070dabbdd94d5  vmovaps xmm3, [rsp+0x30]
000070dabbdd94db  vmovaps xmm4, [rsp+0x40]
000070dabbdd94e1  vmovaps xmm5, [rsp+0x50]
000070dabbdd94e7  vmovaps xmm6, [rsp+0x60]
000070dabbdd94ed  vmovaps xmm7, [rsp+0x70]
000070dabbdd94f3  vmovaps xmm8, [rsp+0x80]
000070dabbdd94fc  vmovaps xmm9, [rsp+0x90]
000070dabbdd9505  vmovaps xmm11, [rsp+0xA0]
000070dabbdd950e  vmovaps xmm12, [rsp+0xB0]
000070dabbdd9517  vmovaps xmm13, [rsp+0xC0]
000070dabbdd9520  vmovaps xmm14, [rsp+0xD0]
000070dabbdd9529  vmovaps xmm15, [rsp+0xE0]
000070dabbdd9532  add rsp, 0xF0
000070dabbdd9539  pop r11
000070dabbdd953b  pop r10
000070dabbdd953d  pop r9
000070dabbdd953f  pop r8
000070dabbdd9541  pop rsi
000070dabbdd9542  pop rdi
000070dabbdd9543  pop rdx
000070dabbdd9544  pop rcx
000070dabbdd9545  pop rax
000070dabbdd9546  add rsp, 0x08
000070dabbdd954a  jmp 0x000070DABBDD6245
000070dabbdd954f  sub rsp, 0x08
000070dabbdd9553  push rax
000070dabbdd9554  push rcx
000070dabbdd9555  push rdx
000070dabbdd9556  push rdi
000070dabbdd9557  push rsi
000070dabbdd9558  push r8
000070dabbdd955a  push r9
000070dabbdd955c  push r10
000070dabbdd955e  push r11
000070dabbdd9560  sub rsp, 0xF0
000070dabbdd9567  vmovaps [rsp], xmm0
000070dabbdd956c  vmovaps [rsp+0x10], xmm1
000070dabbdd9572  vmovaps [rsp+0x20], xmm2
000070dabbdd9578  vmovaps [rsp+0x30], xmm3
000070dabbdd957e  vmovaps [rsp+0x40], xmm4
000070dabbdd9584  vmovaps [rsp+0x50], xmm5
000070dabbdd958a  vmovaps [rsp+0x60], xmm6
000070dabbdd9590  vmovaps [rsp+0x70], xmm7
000070dabbdd9596  vmovaps [rsp+0x80], xmm8
000070dabbdd959f  vmovaps [rsp+0x90], xmm9
000070dabbdd95a8  vmovaps [rsp+0xA0], xmm10
000070dabbdd95b1  vmovaps [rsp+0xB0], xmm11
000070dabbdd95ba  vmovaps [rsp+0xC0], xmm12
000070dabbdd95c3  vmovaps [rsp+0xD0], xmm13
000070dabbdd95cc  vmovaps [rsp+0xE0], xmm15
000070dabbdd95d5  sub rsp, 0x30
000070dabbdd95d9  movaps [rsp], xmm14
000070dabbdd95de  movaps [rsp+0x10], xmm8
000070dabbdd95e4  movaps [rsp+0x20], xmm4
000070dabbdd95e9  lea rdi, [rsp]
000070dabbdd95ed  mov esi, 0x00
000070dabbdd95f2  mov rax, 0x5C2CF7B6F530
000070dabbdd95fc  call rax
000070dabbdd95fe  movaps xmm14, [rsp]
000070dabbdd9603  add rsp, 0x30
000070dabbdd9607  vmovaps xmm0, [rsp]
000070dabbdd960c  vmovaps xmm1, [rsp+0x10]
000070dabbdd9612  vmovaps xmm2, [rsp+0x20]
000070dabbdd9618  vmovaps xmm3, [rsp+0x30]
000070dabbdd961e  vmovaps xmm4, [rsp+0x40]
000070dabbdd9624  vmovaps xmm5, [rsp+0x50]
000070dabbdd962a  vmovaps xmm6, [rsp+0x60]
000070dabbdd9630  vmovaps xmm7, [rsp+0x70]
000070dabbdd9636  vmovaps xmm8, [rsp+0x80]
000070dabbdd963f  vmovaps xmm9, [rsp+0x90]
000070dabbdd9648  vmovaps xmm10, [rsp+0xA0]
000070dabbdd9651  vmovaps xmm11, [rsp+0xB0]
000070dabbdd965a  vmovaps xmm12, [rsp+0xC0]
000070dabbdd9663  vmovaps xmm13, [rsp+0xD0]
000070dabbdd966c  vmovaps xmm15, [rsp+0xE0]
000070dabbdd9675  add rsp, 0xF0
000070dabbdd967c  pop r11
000070dabbdd967e  pop r10
000070dabbdd9680  pop r9
000070dabbdd9682  pop r8
000070dabbdd9684  pop rsi
000070dabbdd9685  pop rdi
000070dabbdd9686  pop rdx
000070dabbdd9687  pop rcx
000070dabbdd9688  pop rax
000070dabbdd9689  add rsp, 0x08
000070dabbdd968d  jmp 0x000070DABBDD6265
000070dabbdd9692  sub rsp, 0x08
000070dabbdd9696  push rax
000070dabbdd9697  push rcx
000070dabbdd9698  push rdx
000070dabbdd9699  push rdi
000070dabbdd969a  push rsi
000070dabbdd969b  push r8
000070dabbdd969d  push r9
000070dabbdd969f  push r10
000070dabbdd96a1  push r11
000070dabbdd96a3  sub rsp, 0xF0
000070dabbdd96aa  vmovaps [rsp], xmm0
000070dabbdd96af  vmovaps [rsp+0x10], xmm1
000070dabbdd96b5  vmovaps [rsp+0x20], xmm2
000070dabbdd96bb  vmovaps [rsp+0x30], xmm3
000070dabbdd96c1  vmovaps [rsp+0x40], xmm5
000070dabbdd96c7  vmovaps [rsp+0x50], xmm6
000070dabbdd96cd  vmovaps [rsp+0x60], xmm7
000070dabbdd96d3  vmovaps [rsp+0x70], xmm8
000070dabbdd96d9  vmovaps [rsp+0x80], xmm9
000070dabbdd96e2  vmovaps [rsp+0x90], xmm10
000070dabbdd96eb  vmovaps [rsp+0xA0], xmm11
000070dabbdd96f4  vmovaps [rsp+0xB0], xmm12
000070dabbdd96fd  vmovaps [rsp+0xC0], xmm13
000070dabbdd9706  vmovaps [rsp+0xD0], xmm14
000070dabbdd970f  vmovaps [rsp+0xE0], xmm15
000070dabbdd9718  sub rsp, 0x30
000070dabbdd971c  movaps [rsp], xmm4
000070dabbdd9720  movaps [rsp+0x10], xmm13
000070dabbdd9726  movaps [rsp+0x20], xmm8
000070dabbdd972c  lea rdi, [rsp]
000070dabbdd9730  mov esi, 0x00
000070dabbdd9735  mov rax, 0x5C2CF7B6F530
000070dabbdd973f  call rax
000070dabbdd9741  movaps xmm4, [rsp]
000070dabbdd9745  add rsp, 0x30
000070dabbdd9749  vmovaps xmm0, [rsp]
000070dabbdd974e  vmovaps xmm1, [rsp+0x10]
000070dabbdd9754  vmovaps xmm2, [rsp+0x20]
000070dabbdd975a  vmovaps xmm3, [rsp+0x30]
000070dabbdd9760  vmovaps xmm5, [rsp+0x40]
000070dabbdd9766  vmovaps xmm6, [rsp+0x50]
000070dabbdd976c  vmovaps xmm7, [rsp+0x60]
000070dabbdd9772  vmovaps xmm8, [rsp+0x70]
000070dabbdd9778  vmovaps xmm9, [rsp+0x80]
000070dabbdd9781  vmovaps xmm10, [rsp+0x90]
000070dabbdd978a  vmovaps xmm11, [rsp+0xA0]
000070dabbdd9793  vmovaps xmm12, [rsp+0xB0]
000070dabbdd979c  vmovaps xmm13, [rsp+0xC0]
000070dabbdd97a5  vmovaps xmm14, [rsp+0xD0]
000070dabbdd97ae  vmovaps xmm15, [rsp+0xE0]
000070dabbdd97b7  add rsp, 0xF0
000070dabbdd97be  pop r11
000070dabbdd97c0  pop r10
000070dabbdd97c2  pop r9
000070dabbdd97c4  pop r8
000070dabbdd97c6  pop rsi
000070dabbdd97c7  pop rdi
000070dabbdd97c8  pop rdx
000070dabbdd97c9  pop rcx
000070dabbdd97ca  pop rax
000070dabbdd97cb  add rsp, 0x08
000070dabbdd97cf  jmp 0x000070DABBDD628A
000070dabbdd97d4  sub rsp, 0x08
000070dabbdd97d8  push rax
000070dabbdd97d9  push rcx
000070dabbdd97da  push rdx
000070dabbdd97db  push rdi
000070dabbdd97dc  push rsi
000070dabbdd97dd  push r8
000070dabbdd97df  push r9
000070dabbdd97e1  push r10
000070dabbdd97e3  push r11
000070dabbdd97e5  sub rsp, 0xF0
000070dabbdd97ec  vmovaps [rsp], xmm0
000070dabbdd97f1  vmovaps [rsp+0x10], xmm1
000070dabbdd97f7  vmovaps [rsp+0x20], xmm2
000070dabbdd97fd  vmovaps [rsp+0x30], xmm3
000070dabbdd9803  vmovaps [rsp+0x40], xmm4
000070dabbdd9809  vmovaps [rsp+0x50], xmm5
000070dabbdd980f  vmovaps [rsp+0x60], xmm6
000070dabbdd9815  vmovaps [rsp+0x70], xmm7
000070dabbdd981b  vmovaps [rsp+0x80], xmm8
000070dabbdd9824  vmovaps [rsp+0x90], xmm9
000070dabbdd982d  vmovaps [rsp+0xA0], xmm10
000070dabbdd9836  vmovaps [rsp+0xB0], xmm11
000070dabbdd983f  vmovaps [rsp+0xC0], xmm12
000070dabbdd9848  vmovaps [rsp+0xD0], xmm14
000070dabbdd9851  vmovaps [rsp+0xE0], xmm15
000070dabbdd985a  sub rsp, 0x30
000070dabbdd985e  movaps [rsp], xmm13
000070dabbdd9863  movaps [rsp+0x10], xmm15
000070dabbdd9869  movaps [rsp+0x20], xmm9
000070dabbdd986f  lea rdi, [rsp]
000070dabbdd9873  mov esi, 0x00
000070dabbdd9878  mov rax, 0x5C2CF7B6F530
000070dabbdd9882  call rax
000070dabbdd9884  movaps xmm13, [rsp]
000070dabbdd9889  add rsp, 0x30
000070dabbdd988d  vmovaps xmm0, [rsp]
000070dabbdd9892  vmovaps xmm1, [rsp+0x10]
000070dabbdd9898  vmovaps xmm2, [rsp+0x20]
000070dabbdd989e  vmovaps xmm3, [rsp+0x30]
000070dabbdd98a4  vmovaps xmm4, [rsp+0x40]
000070dabbdd98aa  vmovaps xmm5, [rsp+0x50]
000070dabbdd98b0  vmovaps xmm6, [rsp+0x60]
000070dabbdd98b6  vmovaps xmm7, [rsp+0x70]
000070dabbdd98bc  vmovaps xmm8, [rsp+0x80]
000070dabbdd98c5  vmovaps xmm9, [rsp+0x90]
000070dabbdd98ce  vmovaps xmm10, [rsp+0xA0]
000070dabbdd98d7  vmovaps xmm11, [rsp+0xB0]
000070dabbdd98e0  vmovaps xmm12, [rsp+0xC0]
000070dabbdd98e9  vmovaps xmm14, [rsp+0xD0]
000070dabbdd98f2  vmovaps xmm15, [rsp+0xE0]
000070dabbdd98fb  add rsp, 0xF0
000070dabbdd9902  pop r11
000070dabbdd9904  pop r10
000070dabbdd9906  pop r9
000070dabbdd9908  pop r8
000070dabbdd990a  pop rsi
000070dabbdd990b  pop rdi
000070dabbdd990c  pop rdx
000070dabbdd990d  pop rcx
000070dabbdd990e  pop rax
000070dabbdd990f  add rsp, 0x08
000070dabbdd9913  jmp 0x000070DABBDD62A5
000070dabbdd9918  sub rsp, 0x08
000070dabbdd991c  push rax
000070dabbdd991d  push rcx
000070dabbdd991e  push rdx
000070dabbdd991f  push rdi
000070dabbdd9920  push rsi
000070dabbdd9921  push r8
000070dabbdd9923  push r9
000070dabbdd9925  push r10
000070dabbdd9927  push r11
000070dabbdd9929  sub rsp, 0xF0
000070dabbdd9930  vmovaps [rsp], xmm0
000070dabbdd9935  vmovaps [rsp+0x10], xmm1
000070dabbdd993b  vmovaps [rsp+0x20], xmm2
000070dabbdd9941  vmovaps [rsp+0x30], xmm3
000070dabbdd9947  vmovaps [rsp+0x40], xmm4
000070dabbdd994d  vmovaps [rsp+0x50], xmm5
000070dabbdd9953  vmovaps [rsp+0x60], xmm6
000070dabbdd9959  vmovaps [rsp+0x70], xmm7
000070dabbdd995f  vmovaps [rsp+0x80], xmm8
000070dabbdd9968  vmovaps [rsp+0x90], xmm9
000070dabbdd9971  vmovaps [rsp+0xA0], xmm10
000070dabbdd997a  vmovaps [rsp+0xB0], xmm11
000070dabbdd9983  vmovaps [rsp+0xC0], xmm12
000070dabbdd998c  vmovaps [rsp+0xD0], xmm13
000070dabbdd9995  vmovaps [rsp+0xE0], xmm14
000070dabbdd999e  sub rsp, 0x30
000070dabbdd99a2  movaps [rsp], xmm15
000070dabbdd99a7  movaps [rsp+0x10], xmm1
000070dabbdd99ac  movaps [rsp+0x20], xmm5
000070dabbdd99b1  lea rdi, [rsp]
000070dabbdd99b5  mov esi, 0x00
000070dabbdd99ba  mov rax, 0x5C2CF7B6F530
000070dabbdd99c4  call rax
000070dabbdd99c6  movaps xmm15, [rsp]
000070dabbdd99cb  add rsp, 0x30
000070dabbdd99cf  vmovaps xmm0, [rsp]
000070dabbdd99d4  vmovaps xmm1, [rsp+0x10]
000070dabbdd99da  vmovaps xmm2, [rsp+0x20]
000070dabbdd99e0  vmovaps xmm3, [rsp+0x30]
000070dabbdd99e6  vmovaps xmm4, [rsp+0x40]
000070dabbdd99ec  vmovaps xmm5, [rsp+0x50]
000070dabbdd99f2  vmovaps xmm6, [rsp+0x60]
000070dabbdd99f8  vmovaps xmm7, [rsp+0x70]
000070dabbdd99fe  vmovaps xmm8, [rsp+0x80]
000070dabbdd9a07  vmovaps xmm9, [rsp+0x90]
000070dabbdd9a10  vmovaps xmm10, [rsp+0xA0]
000070dabbdd9a19  vmovaps xmm11, [rsp+0xB0]
000070dabbdd9a22  vmovaps xmm12, [rsp+0xC0]
000070dabbdd9a2b  vmovaps xmm13, [rsp+0xD0]
000070dabbdd9a34  vmovaps xmm14, [rsp+0xE0]
000070dabbdd9a3d  add rsp, 0xF0
000070dabbdd9a44  pop r11
000070dabbdd9a46  pop r10
000070dabbdd9a48  pop r9
000070dabbdd9a4a  pop r8
000070dabbdd9a4c  pop rsi
000070dabbdd9a4d  pop rdi
000070dabbdd9a4e  pop rdx
000070dabbdd9a4f  pop rcx
000070dabbdd9a50  pop rax
000070dabbdd9a51  add rsp, 0x08
000070dabbdd9a55  jmp 0x000070DABBDD62C0
000070dabbdd9a5a  call 0x000070DABBCD64F0
000070dabbdd9a5f  jmp 0x000070DABBDD631B
000070dabbdd9a64  sub rsp, 0x08
000070dabbdd9a68  push rax
000070dabbdd9a69  push rcx
000070dabbdd9a6a  push rdx
000070dabbdd9a6b  push rdi
000070dabbdd9a6c  push rsi
000070dabbdd9a6d  push r8
000070dabbdd9a6f  push r9
000070dabbdd9a71  push r10
000070dabbdd9a73  push r11
000070dabbdd9a75  sub rsp, 0xF0
000070dabbdd9a7c  vmovaps [rsp], xmm0
000070dabbdd9a81  vmovaps [rsp+0x10], xmm1
000070dabbdd9a87  vmovaps [rsp+0x20], xmm2
000070dabbdd9a8d  vmovaps [rsp+0x30], xmm3
000070dabbdd9a93  vmovaps [rsp+0x40], xmm4
000070dabbdd9a99  vmovaps [rsp+0x50], xmm5
000070dabbdd9a9f  vmovaps [rsp+0x60], xmm6
000070dabbdd9aa5  vmovaps [rsp+0x70], xmm7
000070dabbdd9aab  vmovaps [rsp+0x80], xmm8
000070dabbdd9ab4  vmovaps [rsp+0x90], xmm10
000070dabbdd9abd  vmovaps [rsp+0xA0], xmm11
000070dabbdd9ac6  vmovaps [rsp+0xB0], xmm12
000070dabbdd9acf  vmovaps [rsp+0xC0], xmm13
000070dabbdd9ad8  vmovaps [rsp+0xD0], xmm14
000070dabbdd9ae1  vmovaps [rsp+0xE0], xmm15
000070dabbdd9aea  sub rsp, 0x30
000070dabbdd9aee  movaps [rsp], xmm9
000070dabbdd9af3  movaps [rsp+0x10], xmm8
000070dabbdd9af9  movaps [rsp+0x20], xmm11
000070dabbdd9aff  lea rdi, [rsp]
000070dabbdd9b03  mov esi, 0x00
000070dabbdd9b08  mov rax, 0x5C2CF7B6F530
000070dabbdd9b12  call rax
000070dabbdd9b14  movaps xmm9, [rsp]
000070dabbdd9b19  add rsp, 0x30
000070dabbdd9b1d  vmovaps xmm0, [rsp]
000070dabbdd9b22  vmovaps xmm1, [rsp+0x10]
000070dabbdd9b28  vmovaps xmm2, [rsp+0x20]
000070dabbdd9b2e  vmovaps xmm3, [rsp+0x30]
000070dabbdd9b34  vmovaps xmm4, [rsp+0x40]
000070dabbdd9b3a  vmovaps xmm5, [rsp+0x50]
000070dabbdd9b40  vmovaps xmm6, [rsp+0x60]
000070dabbdd9b46  vmovaps xmm7, [rsp+0x70]
000070dabbdd9b4c  vmovaps xmm8, [rsp+0x80]
000070dabbdd9b55  vmovaps xmm10, [rsp+0x90]
000070dabbdd9b5e  vmovaps xmm11, [rsp+0xA0]
000070dabbdd9b67  vmovaps xmm12, [rsp+0xB0]
000070dabbdd9b70  vmovaps xmm13, [rsp+0xC0]
000070dabbdd9b79  vmovaps xmm14, [rsp+0xD0]
000070dabbdd9b82  vmovaps xmm15, [rsp+0xE0]
000070dabbdd9b8b  add rsp, 0xF0
000070dabbdd9b92  pop r11
000070dabbdd9b94  pop r10
000070dabbdd9b96  pop r9
000070dabbdd9b98  pop r8
000070dabbdd9b9a  pop rsi
000070dabbdd9b9b  pop rdi
000070dabbdd9b9c  pop rdx
000070dabbdd9b9d  pop rcx
000070dabbdd9b9e  pop rax
000070dabbdd9b9f  add rsp, 0x08
000070dabbdd9ba3  jmp 0x000070DABBDD6352
000070dabbdd9ba8  sub rsp, 0x08
000070dabbdd9bac  push rax
000070dabbdd9bad  push rcx
000070dabbdd9bae  push rdx
000070dabbdd9baf  push rdi
000070dabbdd9bb0  push rsi
000070dabbdd9bb1  push r8
000070dabbdd9bb3  push r9
000070dabbdd9bb5  push r10
000070dabbdd9bb7  push r11
000070dabbdd9bb9  sub rsp, 0xF0
000070dabbdd9bc0  vmovaps [rsp], xmm0
000070dabbdd9bc5  vmovaps [rsp+0x10], xmm1
000070dabbdd9bcb  vmovaps [rsp+0x20], xmm2
000070dabbdd9bd1  vmovaps [rsp+0x30], xmm3
000070dabbdd9bd7  vmovaps [rsp+0x40], xmm4
000070dabbdd9bdd  vmovaps [rsp+0x50], xmm5
000070dabbdd9be3  vmovaps [rsp+0x60], xmm6
000070dabbdd9be9  vmovaps [rsp+0x70], xmm7
000070dabbdd9bef  vmovaps [rsp+0x80], xmm8
000070dabbdd9bf8  vmovaps [rsp+0x90], xmm9
000070dabbdd9c01  vmovaps [rsp+0xA0], xmm10
000070dabbdd9c0a  vmovaps [rsp+0xB0], xmm12
000070dabbdd9c13  vmovaps [rsp+0xC0], xmm13
000070dabbdd9c1c  vmovaps [rsp+0xD0], xmm14
000070dabbdd9c25  vmovaps [rsp+0xE0], xmm15
000070dabbdd9c2e  sub rsp, 0x30
000070dabbdd9c32  movaps [rsp], xmm11
000070dabbdd9c37  movaps [rsp+0x10], xmm10
000070dabbdd9c3d  movaps [rsp+0x20], xmm6
000070dabbdd9c42  lea rdi, [rsp]
000070dabbdd9c46  mov esi, 0x00
000070dabbdd9c4b  mov rax, 0x5C2CF7B6F530
000070dabbdd9c55  call rax
000070dabbdd9c57  movaps xmm11, [rsp]
000070dabbdd9c5c  add rsp, 0x30
000070dabbdd9c60  vmovaps xmm0, [rsp]
000070dabbdd9c65  vmovaps xmm1, [rsp+0x10]
000070dabbdd9c6b  vmovaps xmm2, [rsp+0x20]
000070dabbdd9c71  vmovaps xmm3, [rsp+0x30]
000070dabbdd9c77  vmovaps xmm4, [rsp+0x40]
000070dabbdd9c7d  vmovaps xmm5, [rsp+0x50]
000070dabbdd9c83  vmovaps xmm6, [rsp+0x60]
000070dabbdd9c89  vmovaps xmm7, [rsp+0x70]
000070dabbdd9c8f  vmovaps xmm8, [rsp+0x80]
000070dabbdd9c98  vmovaps xmm9, [rsp+0x90]
000070dabbdd9ca1  vmovaps xmm10, [rsp+0xA0]
000070dabbdd9caa  vmovaps xmm12, [rsp+0xB0]
000070dabbdd9cb3  vmovaps xmm13, [rsp+0xC0]
000070dabbdd9cbc  vmovaps xmm14, [rsp+0xD0]
000070dabbdd9cc5  vmovaps xmm15, [rsp+0xE0]
000070dabbdd9cce  add rsp, 0xF0
000070dabbdd9cd5  pop r11
000070dabbdd9cd7  pop r10
000070dabbdd9cd9  pop r9
000070dabbdd9cdb  pop r8
000070dabbdd9cdd  pop rsi
000070dabbdd9cde  pop rdi
000070dabbdd9cdf  pop rdx
000070dabbdd9ce0  pop rcx
000070dabbdd9ce1  pop rax
000070dabbdd9ce2  add rsp, 0x08
000070dabbdd9ce6  jmp 0x000070DABBDD636D
000070dabbdd9ceb  sub rsp, 0x08
000070dabbdd9cef  push rax
000070dabbdd9cf0  push rcx
000070dabbdd9cf1  push rdx
000070dabbdd9cf2  push rdi
000070dabbdd9cf3  push rsi
000070dabbdd9cf4  push r8
000070dabbdd9cf6  push r9
000070dabbdd9cf8  push r10
000070dabbdd9cfa  push r11
000070dabbdd9cfc  sub rsp, 0xF0
000070dabbdd9d03  vmovaps [rsp], xmm0
000070dabbdd9d08  vmovaps [rsp+0x10], xmm1
000070dabbdd9d0e  vmovaps [rsp+0x20], xmm2
000070dabbdd9d14  vmovaps [rsp+0x30], xmm3
000070dabbdd9d1a  vmovaps [rsp+0x40], xmm4
000070dabbdd9d20  vmovaps [rsp+0x50], xmm5
000070dabbdd9d26  vmovaps [rsp+0x60], xmm6
000070dabbdd9d2c  vmovaps [rsp+0x70], xmm7
000070dabbdd9d32  vmovaps [rsp+0x80], xmm8
000070dabbdd9d3b  vmovaps [rsp+0x90], xmm9
000070dabbdd9d44  vmovaps [rsp+0xA0], xmm11
000070dabbdd9d4d  vmovaps [rsp+0xB0], xmm12
000070dabbdd9d56  vmovaps [rsp+0xC0], xmm13
000070dabbdd9d5f  vmovaps [rsp+0xD0], xmm14
000070dabbdd9d68  vmovaps [rsp+0xE0], xmm15
000070dabbdd9d71  sub rsp, 0x30
000070dabbdd9d75  movaps [rsp], xmm10
000070dabbdd9d7a  movaps [rsp+0x10], xmm14
000070dabbdd9d80  movaps [rsp+0x20], xmm4
000070dabbdd9d85  lea rdi, [rsp]
000070dabbdd9d89  mov esi, 0x00
000070dabbdd9d8e  mov rax, 0x5C2CF7B6F530
000070dabbdd9d98  call rax
000070dabbdd9d9a  movaps xmm10, [rsp]
000070dabbdd9d9f  add rsp, 0x30
000070dabbdd9da3  vmovaps xmm0, [rsp]
000070dabbdd9da8  vmovaps xmm1, [rsp+0x10]
000070dabbdd9dae  vmovaps xmm2, [rsp+0x20]
000070dabbdd9db4  vmovaps xmm3, [rsp+0x30]
000070dabbdd9dba  vmovaps xmm4, [rsp+0x40]
000070dabbdd9dc0  vmovaps xmm5, [rsp+0x50]
000070dabbdd9dc6  vmovaps xmm6, [rsp+0x60]
000070dabbdd9dcc  vmovaps xmm7, [rsp+0x70]
000070dabbdd9dd2  vmovaps xmm8, [rsp+0x80]
000070dabbdd9ddb  vmovaps xmm9, [rsp+0x90]
000070dabbdd9de4  vmovaps xmm11, [rsp+0xA0]
000070dabbdd9ded  vmovaps xmm12, [rsp+0xB0]
000070dabbdd9df6  vmovaps xmm13, [rsp+0xC0]
000070dabbdd9dff  vmovaps xmm14, [rsp+0xD0]
000070dabbdd9e08  vmovaps xmm15, [rsp+0xE0]
000070dabbdd9e11  add rsp, 0xF0
000070dabbdd9e18  pop r11
000070dabbdd9e1a  pop r10
000070dabbdd9e1c  pop r9
000070dabbdd9e1e  pop r8
000070dabbdd9e20  pop rsi
000070dabbdd9e21  pop rdi
000070dabbdd9e22  pop rdx
000070dabbdd9e23  pop rcx
000070dabbdd9e24  pop rax
000070dabbdd9e25  add rsp, 0x08
000070dabbdd9e29  jmp 0x000070DABBDD6388
000070dabbdd9e2e  sub rsp, 0x08
000070dabbdd9e32  push rax
000070dabbdd9e33  push rcx
000070dabbdd9e34  push rdx
000070dabbdd9e35  push rdi
000070dabbdd9e36  push rsi
000070dabbdd9e37  push r8
000070dabbdd9e39  push r9
000070dabbdd9e3b  push r10
000070dabbdd9e3d  push r11
000070dabbdd9e3f  sub rsp, 0xF0
000070dabbdd9e46  vmovaps [rsp], xmm0
000070dabbdd9e4b  vmovaps [rsp+0x10], xmm1
000070dabbdd9e51  vmovaps [rsp+0x20], xmm2
000070dabbdd9e57  vmovaps [rsp+0x30], xmm3
000070dabbdd9e5d  vmovaps [rsp+0x40], xmm4
000070dabbdd9e63  vmovaps [rsp+0x50], xmm5
000070dabbdd9e69  vmovaps [rsp+0x60], xmm6
000070dabbdd9e6f  vmovaps [rsp+0x70], xmm7
000070dabbdd9e75  vmovaps [rsp+0x80], xmm9
000070dabbdd9e7e  vmovaps [rsp+0x90], xmm10
000070dabbdd9e87  vmovaps [rsp+0xA0], xmm11
000070dabbdd9e90  vmovaps [rsp+0xB0], xmm12
000070dabbdd9e99  vmovaps [rsp+0xC0], xmm13
000070dabbdd9ea2  vmovaps [rsp+0xD0], xmm14
000070dabbdd9eab  vmovaps [rsp+0xE0], xmm15
000070dabbdd9eb4  sub rsp, 0x30
000070dabbdd9eb8  movaps [rsp], xmm8
000070dabbdd9ebd  movaps [rsp+0x10], xmm1
000070dabbdd9ec2  movaps [rsp+0x20], xmm14
000070dabbdd9ec8  lea rdi, [rsp]
000070dabbdd9ecc  mov esi, 0x00
000070dabbdd9ed1  mov rax, 0x5C2CF7B6F530
000070dabbdd9edb  call rax
000070dabbdd9edd  movaps xmm8, [rsp]
000070dabbdd9ee2  add rsp, 0x30
000070dabbdd9ee6  vmovaps xmm0, [rsp]
000070dabbdd9eeb  vmovaps xmm1, [rsp+0x10]
000070dabbdd9ef1  vmovaps xmm2, [rsp+0x20]
000070dabbdd9ef7  vmovaps xmm3, [rsp+0x30]
000070dabbdd9efd  vmovaps xmm4, [rsp+0x40]
000070dabbdd9f03  vmovaps xmm5, [rsp+0x50]
000070dabbdd9f09  vmovaps xmm6, [rsp+0x60]
000070dabbdd9f0f  vmovaps xmm7, [rsp+0x70]
000070dabbdd9f15  vmovaps xmm9, [rsp+0x80]
000070dabbdd9f1e  vmovaps xmm10, [rsp+0x90]
000070dabbdd9f27  vmovaps xmm11, [rsp+0xA0]
000070dabbdd9f30  vmovaps xmm12, [rsp+0xB0]
000070dabbdd9f39  vmovaps xmm13, [rsp+0xC0]
000070dabbdd9f42  vmovaps xmm14, [rsp+0xD0]
000070dabbdd9f4b  vmovaps xmm15, [rsp+0xE0]
000070dabbdd9f54  add rsp, 0xF0
000070dabbdd9f5b  pop r11
000070dabbdd9f5d  pop r10
000070dabbdd9f5f  pop r9
000070dabbdd9f61  pop r8
000070dabbdd9f63  pop rsi
000070dabbdd9f64  pop rdi
000070dabbdd9f65  pop rdx
000070dabbdd9f66  pop rcx
000070dabbdd9f67  pop rax
000070dabbdd9f68  add rsp, 0x08
000070dabbdd9f6c  jmp 0x000070DABBDD63AE
000070dabbdd9f71  sub rsp, 0x08
000070dabbdd9f75  push rax
000070dabbdd9f76  push rcx
000070dabbdd9f77  push rdx
000070dabbdd9f78  push rdi
000070dabbdd9f79  push rsi
000070dabbdd9f7a  push r8
000070dabbdd9f7c  push r9
000070dabbdd9f7e  push r10
000070dabbdd9f80  push r11
000070dabbdd9f82  sub rsp, 0xF0
000070dabbdd9f89  vmovaps [rsp], xmm0
000070dabbdd9f8e  vmovaps [rsp+0x10], xmm1
000070dabbdd9f94  vmovaps [rsp+0x20], xmm2
000070dabbdd9f9a  vmovaps [rsp+0x30], xmm3
000070dabbdd9fa0  vmovaps [rsp+0x40], xmm4
000070dabbdd9fa6  vmovaps [rsp+0x50], xmm5
000070dabbdd9fac  vmovaps [rsp+0x60], xmm7
000070dabbdd9fb2  vmovaps [rsp+0x70], xmm8
000070dabbdd9fb8  vmovaps [rsp+0x80], xmm9
000070dabbdd9fc1  vmovaps [rsp+0x90], xmm10
000070dabbdd9fca  vmovaps [rsp+0xA0], xmm11
000070dabbdd9fd3  vmovaps [rsp+0xB0], xmm12
000070dabbdd9fdc  vmovaps [rsp+0xC0], xmm13
000070dabbdd9fe5  vmovaps [rsp+0xD0], xmm14
000070dabbdd9fee  vmovaps [rsp+0xE0], xmm15
000070dabbdd9ff7  sub rsp, 0x30
000070dabbdd9ffb  movaps [rsp], xmm6
000070dabbdd9fff  movaps [rsp+0x10], xmm1
000070dabbdda004  movaps [rsp+0x20], xmm14
000070dabbdda00a  lea rdi, [rsp]
000070dabbdda00e  mov esi, 0x00
000070dabbdda013  mov rax, 0x5C2CF7B6F530
000070dabbdda01d  call rax
000070dabbdda01f  movaps xmm6, [rsp]
000070dabbdda023  add rsp, 0x30
000070dabbdda027  vmovaps xmm0, [rsp]
000070dabbdda02c  vmovaps xmm1, [rsp+0x10]
000070dabbdda032  vmovaps xmm2, [rsp+0x20]
000070dabbdda038  vmovaps xmm3, [rsp+0x30]
000070dabbdda03e  vmovaps xmm4, [rsp+0x40]
000070dabbdda044  vmovaps xmm5, [rsp+0x50]
000070dabbdda04a  vmovaps xmm7, [rsp+0x60]
000070dabbdda050  vmovaps xmm8, [rsp+0x70]
000070dabbdda056  vmovaps xmm9, [rsp+0x80]
000070dabbdda05f  vmovaps xmm10, [rsp+0x90]
000070dabbdda068  vmovaps xmm11, [rsp+0xA0]
000070dabbdda071  vmovaps xmm12, [rsp+0xB0]
000070dabbdda07a  vmovaps xmm13, [rsp+0xC0]
000070dabbdda083  vmovaps xmm14, [rsp+0xD0]
000070dabbdda08c  vmovaps xmm15, [rsp+0xE0]
000070dabbdda095  add rsp, 0xF0
000070dabbdda09c  pop r11
000070dabbdda09e  pop r10
000070dabbdda0a0  pop r9
000070dabbdda0a2  pop r8
000070dabbdda0a4  pop rsi
000070dabbdda0a5  pop rdi
000070dabbdda0a6  pop rdx
000070dabbdda0a7  pop rcx
000070dabbdda0a8  pop rax
000070dabbdda0a9  add rsp, 0x08
000070dabbdda0ad  jmp 0x000070DABBDD63DA
000070dabbdda0b2  sub rsp, 0x08
000070dabbdda0b6  push rax
000070dabbdda0b7  push rcx
000070dabbdda0b8  push rdx
000070dabbdda0b9  push rdi
000070dabbdda0ba  push rsi
000070dabbdda0bb  push r8
000070dabbdda0bd  push r9
000070dabbdda0bf  push r10
000070dabbdda0c1  push r11
000070dabbdda0c3  sub rsp, 0xF0
000070dabbdda0ca  vmovaps [rsp], xmm0
000070dabbdda0cf  vmovaps [rsp+0x10], xmm1
000070dabbdda0d5  vmovaps [rsp+0x20], xmm2
000070dabbdda0db  vmovaps [rsp+0x30], xmm3
000070dabbdda0e1  vmovaps [rsp+0x40], xmm4
000070dabbdda0e7  vmovaps [rsp+0x50], xmm5
000070dabbdda0ed  vmovaps [rsp+0x60], xmm6
000070dabbdda0f3  vmovaps [rsp+0x70], xmm7
000070dabbdda0f9  vmovaps [rsp+0x80], xmm8
000070dabbdda102  vmovaps [rsp+0x90], xmm9
000070dabbdda10b  vmovaps [rsp+0xA0], xmm10
000070dabbdda114  vmovaps [rsp+0xB0], xmm11
000070dabbdda11d  vmovaps [rsp+0xC0], xmm12
000070dabbdda126  vmovaps [rsp+0xD0], xmm13
000070dabbdda12f  vmovaps [rsp+0xE0], xmm15
000070dabbdda138  sub rsp, 0x30
000070dabbdda13c  movaps [rsp], xmm14
000070dabbdda141  movaps [rsp+0x10], xmm12
000070dabbdda147  movaps [rsp+0x20], xmm1
000070dabbdda14c  lea rdi, [rsp]
000070dabbdda150  mov esi, 0x00
000070dabbdda155  mov rax, 0x5C2CF7B6F530
000070dabbdda15f  call rax
000070dabbdda161  movaps xmm14, [rsp]
000070dabbdda166  add rsp, 0x30
000070dabbdda16a  vmovaps xmm0, [rsp]
000070dabbdda16f  vmovaps xmm1, [rsp+0x10]
000070dabbdda175  vmovaps xmm2, [rsp+0x20]
000070dabbdda17b  vmovaps xmm3, [rsp+0x30]
000070dabbdda181  vmovaps xmm4, [rsp+0x40]
000070dabbdda187  vmovaps xmm5, [rsp+0x50]
000070dabbdda18d  vmovaps xmm6, [rsp+0x60]
000070dabbdda193  vmovaps xmm7, [rsp+0x70]
000070dabbdda199  vmovaps xmm8, [rsp+0x80]
000070dabbdda1a2  vmovaps xmm9, [rsp+0x90]
000070dabbdda1ab  vmovaps xmm10, [rsp+0xA0]
000070dabbdda1b4  vmovaps xmm11, [rsp+0xB0]
000070dabbdda1bd  vmovaps xmm12, [rsp+0xC0]
000070dabbdda1c6  vmovaps xmm13, [rsp+0xD0]
000070dabbdda1cf  vmovaps xmm15, [rsp+0xE0]
000070dabbdda1d8  add rsp, 0xF0
000070dabbdda1df  pop r11
000070dabbdda1e1  pop r10
000070dabbdda1e3  pop r9
000070dabbdda1e5  pop r8
000070dabbdda1e7  pop rsi
000070dabbdda1e8  pop rdi
000070dabbdda1e9  pop rdx
000070dabbdda1ea  pop rcx
000070dabbdda1eb  pop rax
000070dabbdda1ec  add rsp, 0x08
000070dabbdda1f0  jmp 0x000070DABBDD6400
000070dabbdda1f5  sub rsp, 0x08
000070dabbdda1f9  push rax
000070dabbdda1fa  push rcx
000070dabbdda1fb  push rdx
000070dabbdda1fc  push rdi
000070dabbdda1fd  push rsi
000070dabbdda1fe  push r8
000070dabbdda200  push r9
000070dabbdda202  push r10
000070dabbdda204  push r11
000070dabbdda206  sub rsp, 0xF0
000070dabbdda20d  vmovaps [rsp], xmm0
000070dabbdda212  vmovaps [rsp+0x10], xmm2
000070dabbdda218  vmovaps [rsp+0x20], xmm3
000070dabbdda21e  vmovaps [rsp+0x30], xmm4
000070dabbdda224  vmovaps [rsp+0x40], xmm5
000070dabbdda22a  vmovaps [rsp+0x50], xmm6
000070dabbdda230  vmovaps [rsp+0x60], xmm7
000070dabbdda236  vmovaps [rsp+0x70], xmm8
000070dabbdda23c  vmovaps [rsp+0x80], xmm9
000070dabbdda245  vmovaps [rsp+0x90], xmm10
000070dabbdda24e  vmovaps [rsp+0xA0], xmm11
000070dabbdda257  vmovaps [rsp+0xB0], xmm12
000070dabbdda260  vmovaps [rsp+0xC0], xmm13
000070dabbdda269  vmovaps [rsp+0xD0], xmm14
000070dabbdda272  vmovaps [rsp+0xE0], xmm15
000070dabbdda27b  sub rsp, 0x30
000070dabbdda27f  movaps [rsp], xmm1
000070dabbdda283  movaps [rsp+0x10], xmm13
000070dabbdda289  movaps [rsp+0x20], xmm9
000070dabbdda28f  lea rdi, [rsp]
000070dabbdda293  mov esi, 0x00
000070dabbdda298  mov rax, 0x5C2CF7B6F530
000070dabbdda2a2  call rax
000070dabbdda2a4  movaps xmm1, [rsp]
000070dabbdda2a8  add rsp, 0x30
000070dabbdda2ac  vmovaps xmm0, [rsp]
000070dabbdda2b1  vmovaps xmm2, [rsp+0x10]
000070dabbdda2b7  vmovaps xmm3, [rsp+0x20]
000070dabbdda2bd  vmovaps xmm4, [rsp+0x30]
000070dabbdda2c3  vmovaps xmm5, [rsp+0x40]
000070dabbdda2c9  vmovaps xmm6, [rsp+0x50]
000070dabbdda2cf  vmovaps xmm7, [rsp+0x60]
000070dabbdda2d5  vmovaps xmm8, [rsp+0x70]
000070dabbdda2db  vmovaps xmm9, [rsp+0x80]
000070dabbdda2e4  vmovaps xmm10, [rsp+0x90]
000070dabbdda2ed  vmovaps xmm11, [rsp+0xA0]
000070dabbdda2f6  vmovaps xmm12, [rsp+0xB0]
000070dabbdda2ff  vmovaps xmm13, [rsp+0xC0]
000070dabbdda308  vmovaps xmm14, [rsp+0xD0]
000070dabbdda311  vmovaps xmm15, [rsp+0xE0]
000070dabbdda31a  add rsp, 0xF0
000070dabbdda321  pop r11
000070dabbdda323  pop r10
000070dabbdda325  pop r9
000070dabbdda327  pop r8
000070dabbdda329  pop rsi
000070dabbdda32a  pop rdi
000070dabbdda32b  pop rdx
000070dabbdda32c  pop rcx
000070dabbdda32d  pop rax
000070dabbdda32e  add rsp, 0x08
000070dabbdda332  jmp 0x000070DABBDD641A
000070dabbdda337  sub rsp, 0x08
000070dabbdda33b  push rax
000070dabbdda33c  push rcx
000070dabbdda33d  push rdx
000070dabbdda33e  push rdi
000070dabbdda33f  push rsi
000070dabbdda340  push r8
000070dabbdda342  push r9
000070dabbdda344  push r10
000070dabbdda346  push r11
000070dabbdda348  sub rsp, 0xF0
000070dabbdda34f  vmovaps [rsp], xmm0
000070dabbdda354  vmovaps [rsp+0x10], xmm1
000070dabbdda35a  vmovaps [rsp+0x20], xmm2
000070dabbdda360  vmovaps [rsp+0x30], xmm3
000070dabbdda366  vmovaps [rsp+0x40], xmm4
000070dabbdda36c  vmovaps [rsp+0x50], xmm5
000070dabbdda372  vmovaps [rsp+0x60], xmm6
000070dabbdda378  vmovaps [rsp+0x70], xmm7
000070dabbdda37e  vmovaps [rsp+0x80], xmm8
000070dabbdda387  vmovaps [rsp+0x90], xmm9
000070dabbdda390  vmovaps [rsp+0xA0], xmm10
000070dabbdda399  vmovaps [rsp+0xB0], xmm11
000070dabbdda3a2  vmovaps [rsp+0xC0], xmm13
000070dabbdda3ab  vmovaps [rsp+0xD0], xmm14
000070dabbdda3b4  vmovaps [rsp+0xE0], xmm15
000070dabbdda3bd  sub rsp, 0x30
000070dabbdda3c1  movaps [rsp], xmm12
000070dabbdda3c6  movaps [rsp+0x10], xmm7
000070dabbdda3cb  movaps [rsp+0x20], xmm13
000070dabbdda3d1  lea rdi, [rsp]
000070dabbdda3d5  mov esi, 0x00
000070dabbdda3da  mov rax, 0x5C2CF7B6F530
000070dabbdda3e4  call rax
000070dabbdda3e6  movaps xmm12, [rsp]
000070dabbdda3eb  add rsp, 0x30
000070dabbdda3ef  vmovaps xmm0, [rsp]
000070dabbdda3f4  vmovaps xmm1, [rsp+0x10]
000070dabbdda3fa  vmovaps xmm2, [rsp+0x20]
000070dabbdda400  vmovaps xmm3, [rsp+0x30]
000070dabbdda406  vmovaps xmm4, [rsp+0x40]
000070dabbdda40c  vmovaps xmm5, [rsp+0x50]
000070dabbdda412  vmovaps xmm6, [rsp+0x60]
000070dabbdda418  vmovaps xmm7, [rsp+0x70]
000070dabbdda41e  vmovaps xmm8, [rsp+0x80]
000070dabbdda427  vmovaps xmm9, [rsp+0x90]
000070dabbdda430  vmovaps xmm10, [rsp+0xA0]
000070dabbdda439  vmovaps xmm11, [rsp+0xB0]
000070dabbdda442  vmovaps xmm13, [rsp+0xC0]
000070dabbdda44b  vmovaps xmm14, [rsp+0xD0]
000070dabbdda454  vmovaps xmm15, [rsp+0xE0]
000070dabbdda45d  add rsp, 0xF0
000070dabbdda464  pop r11
000070dabbdda466  pop r10
000070dabbdda468  pop r9
000070dabbdda46a  pop r8
000070dabbdda46c  pop rsi
000070dabbdda46d  pop rdi
000070dabbdda46e  pop rdx
000070dabbdda46f  pop rcx
000070dabbdda470  pop rax
000070dabbdda471  add rsp, 0x08
000070dabbdda475  jmp 0x000070DABBDD6441
000070dabbdda47a  sub rsp, 0x08
000070dabbdda47e  push rax
000070dabbdda47f  push rcx
000070dabbdda480  push rdx
000070dabbdda481  push rdi
000070dabbdda482  push rsi
000070dabbdda483  push r8
000070dabbdda485  push r9
000070dabbdda487  push r10
000070dabbdda489  push r11
000070dabbdda48b  sub rsp, 0xF0
000070dabbdda492  vmovaps [rsp], xmm0
000070dabbdda497  vmovaps [rsp+0x10], xmm1
000070dabbdda49d  vmovaps [rsp+0x20], xmm2
000070dabbdda4a3  vmovaps [rsp+0x30], xmm3
000070dabbdda4a9  vmovaps [rsp+0x40], xmm4
000070dabbdda4af  vmovaps [rsp+0x50], xmm5
000070dabbdda4b5  vmovaps [rsp+0x60], xmm6
000070dabbdda4bb  vmovaps [rsp+0x70], xmm7
000070dabbdda4c1  vmovaps [rsp+0x80], xmm8
000070dabbdda4ca  vmovaps [rsp+0x90], xmm9
000070dabbdda4d3  vmovaps [rsp+0xA0], xmm10
000070dabbdda4dc  vmovaps [rsp+0xB0], xmm11
000070dabbdda4e5  vmovaps [rsp+0xC0], xmm12
000070dabbdda4ee  vmovaps [rsp+0xD0], xmm14
000070dabbdda4f7  vmovaps [rsp+0xE0], xmm15
000070dabbdda500  sub rsp, 0x30
000070dabbdda504  movaps [rsp], xmm13
000070dabbdda509  movaps [rsp+0x10], xmm15
000070dabbdda50f  movaps [rsp+0x20], xmm8
000070dabbdda515  lea rdi, [rsp]
000070dabbdda519  mov esi, 0x00
000070dabbdda51e  mov rax, 0x5C2CF7B6F530
000070dabbdda528  call rax
000070dabbdda52a  movaps xmm13, [rsp]
000070dabbdda52f  add rsp, 0x30
000070dabbdda533  vmovaps xmm0, [rsp]
000070dabbdda538  vmovaps xmm1, [rsp+0x10]
000070dabbdda53e  vmovaps xmm2, [rsp+0x20]
000070dabbdda544  vmovaps xmm3, [rsp+0x30]
000070dabbdda54a  vmovaps xmm4, [rsp+0x40]
000070dabbdda550  vmovaps xmm5, [rsp+0x50]
000070dabbdda556  vmovaps xmm6, [rsp+0x60]
000070dabbdda55c  vmovaps xmm7, [rsp+0x70]
000070dabbdda562  vmovaps xmm8, [rsp+0x80]
000070dabbdda56b  vmovaps xmm9, [rsp+0x90]
000070dabbdda574  vmovaps xmm10, [rsp+0xA0]
000070dabbdda57d  vmovaps xmm11, [rsp+0xB0]
000070dabbdda586  vmovaps xmm12, [rsp+0xC0]
000070dabbdda58f  vmovaps xmm14, [rsp+0xD0]
000070dabbdda598  vmovaps xmm15, [rsp+0xE0]
000070dabbdda5a1  add rsp, 0xF0
000070dabbdda5a8  pop r11
000070dabbdda5aa  pop r10
000070dabbdda5ac  pop r9
000070dabbdda5ae  pop r8
000070dabbdda5b0  pop rsi
000070dabbdda5b1  pop rdi
000070dabbdda5b2  pop rdx
000070dabbdda5b3  pop rcx
000070dabbdda5b4  pop rax
000070dabbdda5b5  add rsp, 0x08
000070dabbdda5b9  jmp 0x000070DABBDD645C
000070dabbdda5be  sub rsp, 0x08
000070dabbdda5c2  push rax
000070dabbdda5c3  push rcx
000070dabbdda5c4  push rdx
000070dabbdda5c5  push rdi
000070dabbdda5c6  push rsi
000070dabbdda5c7  push r8
000070dabbdda5c9  push r9
000070dabbdda5cb  push r10
000070dabbdda5cd  push r11
000070dabbdda5cf  sub rsp, 0xF0
000070dabbdda5d6  vmovaps [rsp], xmm0
000070dabbdda5db  vmovaps [rsp+0x10], xmm1
000070dabbdda5e1  vmovaps [rsp+0x20], xmm2
000070dabbdda5e7  vmovaps [rsp+0x30], xmm3
000070dabbdda5ed  vmovaps [rsp+0x40], xmm4
000070dabbdda5f3  vmovaps [rsp+0x50], xmm5
000070dabbdda5f9  vmovaps [rsp+0x60], xmm6
000070dabbdda5ff  vmovaps [rsp+0x70], xmm7
000070dabbdda605  vmovaps [rsp+0x80], xmm9
000070dabbdda60e  vmovaps [rsp+0x90], xmm10
000070dabbdda617  vmovaps [rsp+0xA0], xmm11
000070dabbdda620  vmovaps [rsp+0xB0], xmm12
000070dabbdda629  vmovaps [rsp+0xC0], xmm13
000070dabbdda632  vmovaps [rsp+0xD0], xmm14
000070dabbdda63b  vmovaps [rsp+0xE0], xmm15
000070dabbdda644  sub rsp, 0x30
000070dabbdda648  movaps [rsp], xmm8
000070dabbdda64d  movaps [rsp+0x10], xmm15
000070dabbdda653  movaps [rsp+0x20], xmm9
000070dabbdda659  lea rdi, [rsp]
000070dabbdda65d  mov esi, 0x00
000070dabbdda662  mov rax, 0x5C2CF7B6F530
000070dabbdda66c  call rax
000070dabbdda66e  movaps xmm8, [rsp]
000070dabbdda673  add rsp, 0x30
000070dabbdda677  vmovaps xmm0, [rsp]
000070dabbdda67c  vmovaps xmm1, [rsp+0x10]
000070dabbdda682  vmovaps xmm2, [rsp+0x20]
000070dabbdda688  vmovaps xmm3, [rsp+0x30]
000070dabbdda68e  vmovaps xmm4, [rsp+0x40]
000070dabbdda694  vmovaps xmm5, [rsp+0x50]
000070dabbdda69a  vmovaps xmm6, [rsp+0x60]
000070dabbdda6a0  vmovaps xmm7, [rsp+0x70]
000070dabbdda6a6  vmovaps xmm9, [rsp+0x80]
000070dabbdda6af  vmovaps xmm10, [rsp+0x90]
000070dabbdda6b8  vmovaps xmm11, [rsp+0xA0]
000070dabbdda6c1  vmovaps xmm12, [rsp+0xB0]
000070dabbdda6ca  vmovaps xmm13, [rsp+0xC0]
000070dabbdda6d3  vmovaps xmm14, [rsp+0xD0]
000070dabbdda6dc  vmovaps xmm15, [rsp+0xE0]
000070dabbdda6e5  add rsp, 0xF0
000070dabbdda6ec  pop r11
000070dabbdda6ee  pop r10
000070dabbdda6f0  pop r9
000070dabbdda6f2  pop r8
000070dabbdda6f4  pop rsi
000070dabbdda6f5  pop rdi
000070dabbdda6f6  pop rdx
000070dabbdda6f7  pop rcx
000070dabbdda6f8  pop rax
000070dabbdda6f9  add rsp, 0x08
000070dabbdda6fd  jmp 0x000070DABBDD648A
000070dabbdda702  sub rsp, 0x08
000070dabbdda706  push rax
000070dabbdda707  push rcx
000070dabbdda708  push rdx
000070dabbdda709  push rdi
000070dabbdda70a  push rsi
000070dabbdda70b  push r8
000070dabbdda70d  push r9
000070dabbdda70f  push r10
000070dabbdda711  push r11
000070dabbdda713  sub rsp, 0xF0
000070dabbdda71a  vmovaps [rsp], xmm0
000070dabbdda71f  vmovaps [rsp+0x10], xmm1
000070dabbdda725  vmovaps [rsp+0x20], xmm2
000070dabbdda72b  vmovaps [rsp+0x30], xmm3
000070dabbdda731  vmovaps [rsp+0x40], xmm4
000070dabbdda737  vmovaps [rsp+0x50], xmm5
000070dabbdda73d  vmovaps [rsp+0x60], xmm6
000070dabbdda743  vmovaps [rsp+0x70], xmm7
000070dabbdda749  vmovaps [rsp+0x80], xmm8
000070dabbdda752  vmovaps [rsp+0x90], xmm9
000070dabbdda75b  vmovaps [rsp+0xA0], xmm10
000070dabbdda764  vmovaps [rsp+0xB0], xmm11
000070dabbdda76d  vmovaps [rsp+0xC0], xmm12
000070dabbdda776  vmovaps [rsp+0xD0], xmm13
000070dabbdda77f  vmovaps [rsp+0xE0], xmm14
000070dabbdda788  sub rsp, 0x30
000070dabbdda78c  movaps [rsp], xmm15
000070dabbdda791  movaps [rsp+0x10], xmm11
000070dabbdda797  movaps [rsp+0x20], xmm6
000070dabbdda79c  lea rdi, [rsp]
000070dabbdda7a0  mov esi, 0x00
000070dabbdda7a5  mov rax, 0x5C2CF7B6F530
000070dabbdda7af  call rax
000070dabbdda7b1  movaps xmm15, [rsp]
000070dabbdda7b6  add rsp, 0x30
000070dabbdda7ba  vmovaps xmm0, [rsp]
000070dabbdda7bf  vmovaps xmm1, [rsp+0x10]
000070dabbdda7c5  vmovaps xmm2, [rsp+0x20]
000070dabbdda7cb  vmovaps xmm3, [rsp+0x30]
000070dabbdda7d1  vmovaps xmm4, [rsp+0x40]
000070dabbdda7d7  vmovaps xmm5, [rsp+0x50]
000070dabbdda7dd  vmovaps xmm6, [rsp+0x60]
000070dabbdda7e3  vmovaps xmm7, [rsp+0x70]
000070dabbdda7e9  vmovaps xmm8, [rsp+0x80]
000070dabbdda7f2  vmovaps xmm9, [rsp+0x90]
000070dabbdda7fb  vmovaps xmm10, [rsp+0xA0]
000070dabbdda804  vmovaps xmm11, [rsp+0xB0]
000070dabbdda80d  vmovaps xmm12, [rsp+0xC0]
000070dabbdda816  vmovaps xmm13, [rsp+0xD0]
000070dabbdda81f  vmovaps xmm14, [rsp+0xE0]
000070dabbdda828  add rsp, 0xF0
000070dabbdda82f  pop r11
000070dabbdda831  pop r10
000070dabbdda833  pop r9
000070dabbdda835  pop r8
000070dabbdda837  pop rsi
000070dabbdda838  pop rdi
000070dabbdda839  pop rdx
000070dabbdda83a  pop rcx
000070dabbdda83b  pop rax
000070dabbdda83c  add rsp, 0x08
000070dabbdda840  jmp 0x000070DABBDD64A5
000070dabbdda845  sub rsp, 0x08
000070dabbdda849  push rax
000070dabbdda84a  push rcx
000070dabbdda84b  push rdx
000070dabbdda84c  push rdi
000070dabbdda84d  push rsi
000070dabbdda84e  push r8
000070dabbdda850  push r9
000070dabbdda852  push r10
000070dabbdda854  push r11
000070dabbdda856  sub rsp, 0xF0
000070dabbdda85d  vmovaps [rsp], xmm0
000070dabbdda862  vmovaps [rsp+0x10], xmm1
000070dabbdda868  vmovaps [rsp+0x20], xmm2
000070dabbdda86e  vmovaps [rsp+0x30], xmm3
000070dabbdda874  vmovaps [rsp+0x40], xmm4
000070dabbdda87a  vmovaps [rsp+0x50], xmm5
000070dabbdda880  vmovaps [rsp+0x60], xmm6
000070dabbdda886  vmovaps [rsp+0x70], xmm8
000070dabbdda88c  vmovaps [rsp+0x80], xmm9
000070dabbdda895  vmovaps [rsp+0x90], xmm10
000070dabbdda89e  vmovaps [rsp+0xA0], xmm11
000070dabbdda8a7  vmovaps [rsp+0xB0], xmm12
000070dabbdda8b0  vmovaps [rsp+0xC0], xmm13
000070dabbdda8b9  vmovaps [rsp+0xD0], xmm14
000070dabbdda8c2  vmovaps [rsp+0xE0], xmm15
000070dabbdda8cb  sub rsp, 0x30
000070dabbdda8cf  movaps [rsp], xmm7
000070dabbdda8d3  movaps [rsp+0x10], xmm11
000070dabbdda8d9  movaps [rsp+0x20], xmm9
000070dabbdda8df  lea rdi, [rsp]
000070dabbdda8e3  mov esi, 0x00
000070dabbdda8e8  mov rax, 0x5C2CF7B6F530
000070dabbdda8f2  call rax
000070dabbdda8f4  movaps xmm7, [rsp]
000070dabbdda8f8  add rsp, 0x30
000070dabbdda8fc  vmovaps xmm0, [rsp]
000070dabbdda901  vmovaps xmm1, [rsp+0x10]
000070dabbdda907  vmovaps xmm2, [rsp+0x20]
000070dabbdda90d  vmovaps xmm3, [rsp+0x30]
000070dabbdda913  vmovaps xmm4, [rsp+0x40]
000070dabbdda919  vmovaps xmm5, [rsp+0x50]
000070dabbdda91f  vmovaps xmm6, [rsp+0x60]
000070dabbdda925  vmovaps xmm8, [rsp+0x70]
000070dabbdda92b  vmovaps xmm9, [rsp+0x80]
000070dabbdda934  vmovaps xmm10, [rsp+0x90]
000070dabbdda93d  vmovaps xmm11, [rsp+0xA0]
000070dabbdda946  vmovaps xmm12, [rsp+0xB0]
000070dabbdda94f  vmovaps xmm13, [rsp+0xC0]
000070dabbdda958  vmovaps xmm14, [rsp+0xD0]
000070dabbdda961  vmovaps xmm15, [rsp+0xE0]
000070dabbdda96a  add rsp, 0xF0
000070dabbdda971  pop r11
000070dabbdda973  pop r10
000070dabbdda975  pop r9
000070dabbdda977  pop r8
000070dabbdda979  pop rsi
000070dabbdda97a  pop rdi
000070dabbdda97b  pop rdx
000070dabbdda97c  pop rcx
000070dabbdda97d  pop rax
000070dabbdda97e  add rsp, 0x08
000070dabbdda982  jmp 0x000070DABBDD64D2
000070dabbdda987  sub rsp, 0x08
000070dabbdda98b  push rax
000070dabbdda98c  push rcx
000070dabbdda98d  push rdx
000070dabbdda98e  push rdi
000070dabbdda98f  push rsi
000070dabbdda990  push r8
000070dabbdda992  push r9
000070dabbdda994  push r10
000070dabbdda996  push r11
000070dabbdda998  sub rsp, 0xF0
000070dabbdda99f  vmovaps [rsp], xmm0
000070dabbdda9a4  vmovaps [rsp+0x10], xmm1
000070dabbdda9aa  vmovaps [rsp+0x20], xmm2
000070dabbdda9b0  vmovaps [rsp+0x30], xmm3
000070dabbdda9b6  vmovaps [rsp+0x40], xmm4
000070dabbdda9bc  vmovaps [rsp+0x50], xmm5
000070dabbdda9c2  vmovaps [rsp+0x60], xmm6
000070dabbdda9c8  vmovaps [rsp+0x70], xmm7
000070dabbdda9ce  vmovaps [rsp+0x80], xmm8
000070dabbdda9d7  vmovaps [rsp+0x90], xmm9
000070dabbdda9e0  vmovaps [rsp+0xA0], xmm10
000070dabbdda9e9  vmovaps [rsp+0xB0], xmm12
000070dabbdda9f2  vmovaps [rsp+0xC0], xmm13
000070dabbdda9fb  vmovaps [rsp+0xD0], xmm14
000070dabbddaa04  vmovaps [rsp+0xE0], xmm15
000070dabbddaa0d  sub rsp, 0x30
000070dabbddaa11  movaps [rsp], xmm11
000070dabbddaa16  movaps [rsp+0x10], xmm10
000070dabbddaa1c  movaps [rsp+0x20], xmm14
000070dabbddaa22  lea rdi, [rsp]
000070dabbddaa26  mov esi, 0x00
000070dabbddaa2b  mov rax, 0x5C2CF7B6F530
000070dabbddaa35  call rax
000070dabbddaa37  movaps xmm11, [rsp]
000070dabbddaa3c  add rsp, 0x30
000070dabbddaa40  vmovaps xmm0, [rsp]
000070dabbddaa45  vmovaps xmm1, [rsp+0x10]
000070dabbddaa4b  vmovaps xmm2, [rsp+0x20]
000070dabbddaa51  vmovaps xmm3, [rsp+0x30]
000070dabbddaa57  vmovaps xmm4, [rsp+0x40]
000070dabbddaa5d  vmovaps xmm5, [rsp+0x50]
000070dabbddaa63  vmovaps xmm6, [rsp+0x60]
000070dabbddaa69  vmovaps xmm7, [rsp+0x70]
000070dabbddaa6f  vmovaps xmm8, [rsp+0x80]
000070dabbddaa78  vmovaps xmm9, [rsp+0x90]
000070dabbddaa81  vmovaps xmm10, [rsp+0xA0]
000070dabbddaa8a  vmovaps xmm12, [rsp+0xB0]
000070dabbddaa93  vmovaps xmm13, [rsp+0xC0]
000070dabbddaa9c  vmovaps xmm14, [rsp+0xD0]
000070dabbddaaa5  vmovaps xmm15, [rsp+0xE0]
000070dabbddaaae  add rsp, 0xF0
000070dabbddaab5  pop r11
000070dabbddaab7  pop r10
000070dabbddaab9  pop r9
000070dabbddaabb  pop r8
000070dabbddaabd  pop rsi
000070dabbddaabe  pop rdi
000070dabbddaabf  pop rdx
000070dabbddaac0  pop rcx
000070dabbddaac1  pop rax
000070dabbddaac2  add rsp, 0x08
000070dabbddaac6  jmp 0x000070DABBDD64ED
000070dabbddaacb  call 0x000070DABBCE45A0
000070dabbddaad0  jmp 0x000070DABBDD64F7
000070dabbddaad5  sub rsp, 0x08
000070dabbddaad9  push rax
000070dabbddaada  push rcx
000070dabbddaadb  push rdx
000070dabbddaadc  push rdi
000070dabbddaadd  push rsi
000070dabbddaade  push r8
000070dabbddaae0  push r9
000070dabbddaae2  push r10
000070dabbddaae4  push r11
000070dabbddaae6  sub rsp, 0xF0
000070dabbddaaed  vmovaps [rsp], xmm0
000070dabbddaaf2  vmovaps [rsp+0x10], xmm1
000070dabbddaaf8  vmovaps [rsp+0x20], xmm2
000070dabbddaafe  vmovaps [rsp+0x30], xmm3
000070dabbddab04  vmovaps [rsp+0x40], xmm4
000070dabbddab0a  vmovaps [rsp+0x50], xmm5
000070dabbddab10  vmovaps [rsp+0x60], xmm6
000070dabbddab16  vmovaps [rsp+0x70], xmm7
000070dabbddab1c  vmovaps [rsp+0x80], xmm8
000070dabbddab25  vmovaps [rsp+0x90], xmm9
000070dabbddab2e  vmovaps [rsp+0xA0], xmm11
000070dabbddab37  vmovaps [rsp+0xB0], xmm12
000070dabbddab40  vmovaps [rsp+0xC0], xmm13
000070dabbddab49  vmovaps [rsp+0xD0], xmm14
000070dabbddab52  vmovaps [rsp+0xE0], xmm15
000070dabbddab5b  sub rsp, 0x30
000070dabbddab5f  movaps [rsp], xmm10
000070dabbddab64  movaps [rsp+0x10], xmm1
000070dabbddab69  movaps [rsp+0x20], xmm12
000070dabbddab6f  lea rdi, [rsp]
000070dabbddab73  mov esi, 0x00
000070dabbddab78  mov rax, 0x5C2CF7B6F530
000070dabbddab82  call rax
000070dabbddab84  movaps xmm10, [rsp]
000070dabbddab89  add rsp, 0x30
000070dabbddab8d  vmovaps xmm0, [rsp]
000070dabbddab92  vmovaps xmm1, [rsp+0x10]
000070dabbddab98  vmovaps xmm2, [rsp+0x20]
000070dabbddab9e  vmovaps xmm3, [rsp+0x30]
000070dabbddaba4  vmovaps xmm4, [rsp+0x40]
000070dabbddabaa  vmovaps xmm5, [rsp+0x50]
000070dabbddabb0  vmovaps xmm6, [rsp+0x60]
000070dabbddabb6  vmovaps xmm7, [rsp+0x70]
000070dabbddabbc  vmovaps xmm8, [rsp+0x80]
000070dabbddabc5  vmovaps xmm9, [rsp+0x90]
000070dabbddabce  vmovaps xmm11, [rsp+0xA0]
000070dabbddabd7  vmovaps xmm12, [rsp+0xB0]
000070dabbddabe0  vmovaps xmm13, [rsp+0xC0]
000070dabbddabe9  vmovaps xmm14, [rsp+0xD0]
000070dabbddabf2  vmovaps xmm15, [rsp+0xE0]
000070dabbddabfb  add rsp, 0xF0
000070dabbddac02  pop r11
000070dabbddac04  pop r10
000070dabbddac06  pop r9
000070dabbddac08  pop r8
000070dabbddac0a  pop rsi
000070dabbddac0b  pop rdi
000070dabbddac0c  pop rdx
000070dabbddac0d  pop rcx
000070dabbddac0e  pop rax
000070dabbddac0f  add rsp, 0x08
000070dabbddac13  jmp 0x000070DABBDD651A
000070dabbddac18  sub rsp, 0x08
000070dabbddac1c  push rax
000070dabbddac1d  push rcx
000070dabbddac1e  push rdx
000070dabbddac1f  push rdi
000070dabbddac20  push rsi
000070dabbddac21  push r8
000070dabbddac23  push r9
000070dabbddac25  push r10
000070dabbddac27  push r11
000070dabbddac29  sub rsp, 0xF0
000070dabbddac30  vmovaps [rsp], xmm0
000070dabbddac35  vmovaps [rsp+0x10], xmm1
000070dabbddac3b  vmovaps [rsp+0x20], xmm2
000070dabbddac41  vmovaps [rsp+0x30], xmm3
000070dabbddac47  vmovaps [rsp+0x40], xmm4
000070dabbddac4d  vmovaps [rsp+0x50], xmm5
000070dabbddac53  vmovaps [rsp+0x60], xmm6
000070dabbddac59  vmovaps [rsp+0x70], xmm7
000070dabbddac5f  vmovaps [rsp+0x80], xmm8
000070dabbddac68  vmovaps [rsp+0x90], xmm9
000070dabbddac71  vmovaps [rsp+0xA0], xmm10
000070dabbddac7a  vmovaps [rsp+0xB0], xmm11
000070dabbddac83  vmovaps [rsp+0xC0], xmm13
000070dabbddac8c  vmovaps [rsp+0xD0], xmm14
000070dabbddac95  vmovaps [rsp+0xE0], xmm15
000070dabbddac9e  sub rsp, 0x30
000070dabbddaca2  movaps [rsp], xmm12
000070dabbddaca7  movaps [rsp+0x10], xmm14
000070dabbddacad  movaps [rsp+0x20], xmm1
000070dabbddacb2  lea rdi, [rsp]
000070dabbddacb6  mov esi, 0x00
000070dabbddacbb  mov rax, 0x5C2CF7B6F530
000070dabbddacc5  call rax
000070dabbddacc7  movaps xmm12, [rsp]
000070dabbddaccc  add rsp, 0x30
000070dabbddacd0  vmovaps xmm0, [rsp]
000070dabbddacd5  vmovaps xmm1, [rsp+0x10]
000070dabbddacdb  vmovaps xmm2, [rsp+0x20]
000070dabbddace1  vmovaps xmm3, [rsp+0x30]
000070dabbddace7  vmovaps xmm4, [rsp+0x40]
000070dabbddaced  vmovaps xmm5, [rsp+0x50]
000070dabbddacf3  vmovaps xmm6, [rsp+0x60]
000070dabbddacf9  vmovaps xmm7, [rsp+0x70]
000070dabbddacff  vmovaps xmm8, [rsp+0x80]
000070dabbddad08  vmovaps xmm9, [rsp+0x90]
000070dabbddad11  vmovaps xmm10, [rsp+0xA0]
000070dabbddad1a  vmovaps xmm11, [rsp+0xB0]
000070dabbddad23  vmovaps xmm13, [rsp+0xC0]
000070dabbddad2c  vmovaps xmm14, [rsp+0xD0]
000070dabbddad35  vmovaps xmm15, [rsp+0xE0]
000070dabbddad3e  add rsp, 0xF0
000070dabbddad45  pop r11
000070dabbddad47  pop r10
000070dabbddad49  pop r9
000070dabbddad4b  pop r8
000070dabbddad4d  pop rsi
000070dabbddad4e  pop rdi
000070dabbddad4f  pop rdx
000070dabbddad50  pop rcx
000070dabbddad51  pop rax
000070dabbddad52  add rsp, 0x08
000070dabbddad56  jmp 0x000070DABBDD6549
000070dabbddad5b  sub rsp, 0x08
000070dabbddad5f  push rax
000070dabbddad60  push rcx
000070dabbddad61  push rdx
000070dabbddad62  push rdi
000070dabbddad63  push rsi
000070dabbddad64  push r8
000070dabbddad66  push r9
000070dabbddad68  push r10
000070dabbddad6a  push r11
000070dabbddad6c  sub rsp, 0xF0
000070dabbddad73  vmovaps [rsp], xmm0
000070dabbddad78  vmovaps [rsp+0x10], xmm1
000070dabbddad7e  vmovaps [rsp+0x20], xmm2
000070dabbddad84  vmovaps [rsp+0x30], xmm3
000070dabbddad8a  vmovaps [rsp+0x40], xmm4
000070dabbddad90  vmovaps [rsp+0x50], xmm5
000070dabbddad96  vmovaps [rsp+0x60], xmm6
000070dabbddad9c  vmovaps [rsp+0x70], xmm7
000070dabbddada2  vmovaps [rsp+0x80], xmm8
000070dabbddadab  vmovaps [rsp+0x90], xmm9
000070dabbddadb4  vmovaps [rsp+0xA0], xmm10
000070dabbddadbd  vmovaps [rsp+0xB0], xmm11
000070dabbddadc6  vmovaps [rsp+0xC0], xmm12
000070dabbddadcf  vmovaps [rsp+0xD0], xmm13
000070dabbddadd8  vmovaps [rsp+0xE0], xmm15
000070dabbddade1  sub rsp, 0x30
000070dabbddade5  movaps [rsp], xmm14
000070dabbddadea  movaps [rsp+0x10], xmm9
000070dabbddadf0  movaps [rsp+0x20], xmm1
000070dabbddadf5  lea rdi, [rsp]
000070dabbddadf9  mov esi, 0x00
000070dabbddadfe  mov rax, 0x5C2CF7B6F530
000070dabbddae08  call rax
000070dabbddae0a  movaps xmm14, [rsp]
000070dabbddae0f  add rsp, 0x30
000070dabbddae13  vmovaps xmm0, [rsp]
000070dabbddae18  vmovaps xmm1, [rsp+0x10]
000070dabbddae1e  vmovaps xmm2, [rsp+0x20]
000070dabbddae24  vmovaps xmm3, [rsp+0x30]
000070dabbddae2a  vmovaps xmm4, [rsp+0x40]
000070dabbddae30  vmovaps xmm5, [rsp+0x50]
000070dabbddae36  vmovaps xmm6, [rsp+0x60]
000070dabbddae3c  vmovaps xmm7, [rsp+0x70]
000070dabbddae42  vmovaps xmm8, [rsp+0x80]
000070dabbddae4b  vmovaps xmm9, [rsp+0x90]
000070dabbddae54  vmovaps xmm10, [rsp+0xA0]
000070dabbddae5d  vmovaps xmm11, [rsp+0xB0]
000070dabbddae66  vmovaps xmm12, [rsp+0xC0]
000070dabbddae6f  vmovaps xmm13, [rsp+0xD0]
000070dabbddae78  vmovaps xmm15, [rsp+0xE0]
000070dabbddae81  add rsp, 0xF0
000070dabbddae88  pop r11
000070dabbddae8a  pop r10
000070dabbddae8c  pop r9
000070dabbddae8e  pop r8
000070dabbddae90  pop rsi
000070dabbddae91  pop rdi
000070dabbddae92  pop rdx
000070dabbddae93  pop rcx
000070dabbddae94  pop rax
000070dabbddae95  add rsp, 0x08
000070dabbddae99  jmp 0x000070DABBDD6578
000070dabbddae9e  sub rsp, 0x08
000070dabbddaea2  push rax
000070dabbddaea3  push rcx
000070dabbddaea4  push rdx
000070dabbddaea5  push rdi
000070dabbddaea6  push rsi
000070dabbddaea7  push r8
000070dabbddaea9  push r9
000070dabbddaeab  push r10
000070dabbddaead  push r11
000070dabbddaeaf  sub rsp, 0xF0
000070dabbddaeb6  vmovaps [rsp], xmm0
000070dabbddaebb  vmovaps [rsp+0x10], xmm2
000070dabbddaec1  vmovaps [rsp+0x20], xmm3
000070dabbddaec7  vmovaps [rsp+0x30], xmm4
000070dabbddaecd  vmovaps [rsp+0x40], xmm5
000070dabbddaed3  vmovaps [rsp+0x50], xmm6
000070dabbddaed9  vmovaps [rsp+0x60], xmm7
000070dabbddaedf  vmovaps [rsp+0x70], xmm8
000070dabbddaee5  vmovaps [rsp+0x80], xmm9
000070dabbddaeee  vmovaps [rsp+0x90], xmm10
000070dabbddaef7  vmovaps [rsp+0xA0], xmm11
000070dabbddaf00  vmovaps [rsp+0xB0], xmm12
000070dabbddaf09  vmovaps [rsp+0xC0], xmm13
000070dabbddaf12  vmovaps [rsp+0xD0], xmm14
000070dabbddaf1b  vmovaps [rsp+0xE0], xmm15
000070dabbddaf24  sub rsp, 0x30
000070dabbddaf28  movaps [rsp], xmm1
000070dabbddaf2c  movaps [rsp+0x10], xmm13
000070dabbddaf32  movaps [rsp+0x20], xmm8
000070dabbddaf38  lea rdi, [rsp]
000070dabbddaf3c  mov esi, 0x00
000070dabbddaf41  mov rax, 0x5C2CF7B6F530
000070dabbddaf4b  call rax
000070dabbddaf4d  movaps xmm1, [rsp]
000070dabbddaf51  add rsp, 0x30
000070dabbddaf55  vmovaps xmm0, [rsp]
000070dabbddaf5a  vmovaps xmm2, [rsp+0x10]
000070dabbddaf60  vmovaps xmm3, [rsp+0x20]
000070dabbddaf66  vmovaps xmm4, [rsp+0x30]
000070dabbddaf6c  vmovaps xmm5, [rsp+0x40]
000070dabbddaf72  vmovaps xmm6, [rsp+0x50]
000070dabbddaf78  vmovaps xmm7, [rsp+0x60]
000070dabbddaf7e  vmovaps xmm8, [rsp+0x70]
000070dabbddaf84  vmovaps xmm9, [rsp+0x80]
000070dabbddaf8d  vmovaps xmm10, [rsp+0x90]
000070dabbddaf96  vmovaps xmm11, [rsp+0xA0]
000070dabbddaf9f  vmovaps xmm12, [rsp+0xB0]
000070dabbddafa8  vmovaps xmm13, [rsp+0xC0]
000070dabbddafb1  vmovaps xmm14, [rsp+0xD0]
000070dabbddafba  vmovaps xmm15, [rsp+0xE0]
000070dabbddafc3  add rsp, 0xF0
000070dabbddafca  pop r11
000070dabbddafcc  pop r10
000070dabbddafce  pop r9
000070dabbddafd0  pop r8
000070dabbddafd2  pop rsi
000070dabbddafd3  pop rdi
000070dabbddafd4  pop rdx
000070dabbddafd5  pop rcx
000070dabbddafd6  pop rax
000070dabbddafd7  add rsp, 0x08
000070dabbddafdb  jmp 0x000070DABBDD659A
000070dabbddafe0  call 0x000070DABBC0C260
000070dabbddafe5  jmp 0x000070DABBDD65A8
000070dabbddafea  call 0x000070DABBCDE950
000070dabbddafef  jmp 0x000070DABBDD65B2
000070dabbddaff4  sub rsp, 0x08
000070dabbddaff8  push rax
000070dabbddaff9  push rcx
000070dabbddaffa  push rdx
000070dabbddaffb  push rdi
000070dabbddaffc  push rsi
000070dabbddaffd  push r8
000070dabbddafff  push r9
000070dabbddb001  push r10
000070dabbddb003  push r11
000070dabbddb005  sub rsp, 0xF0
000070dabbddb00c  vmovaps [rsp], xmm0
000070dabbddb011  vmovaps [rsp+0x10], xmm1
000070dabbddb017  vmovaps [rsp+0x20], xmm2
000070dabbddb01d  vmovaps [rsp+0x30], xmm3
000070dabbddb023  vmovaps [rsp+0x40], xmm4
000070dabbddb029  vmovaps [rsp+0x50], xmm5
000070dabbddb02f  vmovaps [rsp+0x60], xmm6
000070dabbddb035  vmovaps [rsp+0x70], xmm7
000070dabbddb03b  vmovaps [rsp+0x80], xmm9
000070dabbddb044  vmovaps [rsp+0x90], xmm10
000070dabbddb04d  vmovaps [rsp+0xA0], xmm11
000070dabbddb056  vmovaps [rsp+0xB0], xmm12
000070dabbddb05f  vmovaps [rsp+0xC0], xmm13
000070dabbddb068  vmovaps [rsp+0xD0], xmm14
000070dabbddb071  vmovaps [rsp+0xE0], xmm15
000070dabbddb07a  sub rsp, 0x30
000070dabbddb07e  movaps [rsp], xmm8
000070dabbddb083  movaps [rsp+0x10], xmm15
000070dabbddb089  movaps [rsp+0x20], xmm7
000070dabbddb08e  lea rdi, [rsp]
000070dabbddb092  mov esi, 0x00
000070dabbddb097  mov rax, 0x5C2CF7B6F530
000070dabbddb0a1  call rax
000070dabbddb0a3  movaps xmm8, [rsp]
000070dabbddb0a8  add rsp, 0x30
000070dabbddb0ac  vmovaps xmm0, [rsp]
000070dabbddb0b1  vmovaps xmm1, [rsp+0x10]
000070dabbddb0b7  vmovaps xmm2, [rsp+0x20]
000070dabbddb0bd  vmovaps xmm3, [rsp+0x30]
000070dabbddb0c3  vmovaps xmm4, [rsp+0x40]
000070dabbddb0c9  vmovaps xmm5, [rsp+0x50]
000070dabbddb0cf  vmovaps xmm6, [rsp+0x60]
000070dabbddb0d5  vmovaps xmm7, [rsp+0x70]
000070dabbddb0db  vmovaps xmm9, [rsp+0x80]
000070dabbddb0e4  vmovaps xmm10, [rsp+0x90]
000070dabbddb0ed  vmovaps xmm11, [rsp+0xA0]
000070dabbddb0f6  vmovaps xmm12, [rsp+0xB0]
000070dabbddb0ff  vmovaps xmm13, [rsp+0xC0]
000070dabbddb108  vmovaps xmm14, [rsp+0xD0]
000070dabbddb111  vmovaps xmm15, [rsp+0xE0]
000070dabbddb11a  add rsp, 0xF0
000070dabbddb121  pop r11
000070dabbddb123  pop r10
000070dabbddb125  pop r9
000070dabbddb127  pop r8
000070dabbddb129  pop rsi
000070dabbddb12a  pop rdi
000070dabbddb12b  pop rdx
000070dabbddb12c  pop rcx
000070dabbddb12d  pop rax
000070dabbddb12e  add rsp, 0x08
000070dabbddb132  jmp 0x000070DABBDD65D4
000070dabbddb137  sub rsp, 0x08
000070dabbddb13b  push rax
000070dabbddb13c  push rcx
000070dabbddb13d  push rdx
000070dabbddb13e  push rdi
000070dabbddb13f  push rsi
000070dabbddb140  push r8
000070dabbddb142  push r9
000070dabbddb144  push r10
000070dabbddb146  push r11
000070dabbddb148  sub rsp, 0xF0
000070dabbddb14f  vmovaps [rsp], xmm0
000070dabbddb154  vmovaps [rsp+0x10], xmm1
000070dabbddb15a  vmovaps [rsp+0x20], xmm2
000070dabbddb160  vmovaps [rsp+0x30], xmm3
000070dabbddb166  vmovaps [rsp+0x40], xmm4
000070dabbddb16c  vmovaps [rsp+0x50], xmm5
000070dabbddb172  vmovaps [rsp+0x60], xmm6
000070dabbddb178  vmovaps [rsp+0x70], xmm8
000070dabbddb17e  vmovaps [rsp+0x80], xmm9
000070dabbddb187  vmovaps [rsp+0x90], xmm10
000070dabbddb190  vmovaps [rsp+0xA0], xmm11
000070dabbddb199  vmovaps [rsp+0xB0], xmm12
000070dabbddb1a2  vmovaps [rsp+0xC0], xmm13
000070dabbddb1ab  vmovaps [rsp+0xD0], xmm14
000070dabbddb1b4  vmovaps [rsp+0xE0], xmm15
000070dabbddb1bd  sub rsp, 0x30
000070dabbddb1c1  movaps [rsp], xmm7
000070dabbddb1c5  movaps [rsp+0x10], xmm9
000070dabbddb1cb  movaps [rsp+0x20], xmm15
000070dabbddb1d1  lea rdi, [rsp]
000070dabbddb1d5  mov esi, 0x00
000070dabbddb1da  mov rax, 0x5C2CF7B6F530
000070dabbddb1e4  call rax
000070dabbddb1e6  movaps xmm7, [rsp]
000070dabbddb1ea  add rsp, 0x30
000070dabbddb1ee  vmovaps xmm0, [rsp]
000070dabbddb1f3  vmovaps xmm1, [rsp+0x10]
000070dabbddb1f9  vmovaps xmm2, [rsp+0x20]
000070dabbddb1ff  vmovaps xmm3, [rsp+0x30]
000070dabbddb205  vmovaps xmm4, [rsp+0x40]
000070dabbddb20b  vmovaps xmm5, [rsp+0x50]
000070dabbddb211  vmovaps xmm6, [rsp+0x60]
000070dabbddb217  vmovaps xmm8, [rsp+0x70]
000070dabbddb21d  vmovaps xmm9, [rsp+0x80]
000070dabbddb226  vmovaps xmm10, [rsp+0x90]
000070dabbddb22f  vmovaps xmm11, [rsp+0xA0]
000070dabbddb238  vmovaps xmm12, [rsp+0xB0]
000070dabbddb241  vmovaps xmm13, [rsp+0xC0]
000070dabbddb24a  vmovaps xmm14, [rsp+0xD0]
000070dabbddb253  vmovaps xmm15, [rsp+0xE0]
000070dabbddb25c  add rsp, 0xF0
000070dabbddb263  pop r11
000070dabbddb265  pop r10
000070dabbddb267  pop r9
000070dabbddb269  pop r8
000070dabbddb26b  pop rsi
000070dabbddb26c  pop rdi
000070dabbddb26d  pop rdx
000070dabbddb26e  pop rcx
000070dabbddb26f  pop rax
000070dabbddb270  add rsp, 0x08
000070dabbddb274  jmp 0x000070DABBDD6601
000070dabbddb279  sub rsp, 0x08
000070dabbddb27d  push rax
000070dabbddb27e  push rcx
000070dabbddb27f  push rdx
000070dabbddb280  push rdi
000070dabbddb281  push rsi
000070dabbddb282  push r8
000070dabbddb284  push r9
000070dabbddb286  push r10
000070dabbddb288  push r11
000070dabbddb28a  sub rsp, 0xF0
000070dabbddb291  vmovaps [rsp], xmm0
000070dabbddb296  vmovaps [rsp+0x10], xmm1
000070dabbddb29c  vmovaps [rsp+0x20], xmm2
000070dabbddb2a2  vmovaps [rsp+0x30], xmm3
000070dabbddb2a8  vmovaps [rsp+0x40], xmm4
000070dabbddb2ae  vmovaps [rsp+0x50], xmm5
000070dabbddb2b4  vmovaps [rsp+0x60], xmm6
000070dabbddb2ba  vmovaps [rsp+0x70], xmm7
000070dabbddb2c0  vmovaps [rsp+0x80], xmm8
000070dabbddb2c9  vmovaps [rsp+0x90], xmm10
000070dabbddb2d2  vmovaps [rsp+0xA0], xmm11
000070dabbddb2db  vmovaps [rsp+0xB0], xmm12
000070dabbddb2e4  vmovaps [rsp+0xC0], xmm13
000070dabbddb2ed  vmovaps [rsp+0xD0], xmm14
000070dabbddb2f6  vmovaps [rsp+0xE0], xmm15
000070dabbddb2ff  sub rsp, 0x30
000070dabbddb303  movaps [rsp], xmm9
000070dabbddb308  movaps [rsp+0x10], xmm13
000070dabbddb30e  movaps [rsp+0x20], xmm15
000070dabbddb314  lea rdi, [rsp]
000070dabbddb318  mov esi, 0x00
000070dabbddb31d  mov rax, 0x5C2CF7B6F530
000070dabbddb327  call rax
000070dabbddb329  movaps xmm9, [rsp]
000070dabbddb32e  add rsp, 0x30
000070dabbddb332  vmovaps xmm0, [rsp]
000070dabbddb337  vmovaps xmm1, [rsp+0x10]
000070dabbddb33d  vmovaps xmm2, [rsp+0x20]
000070dabbddb343  vmovaps xmm3, [rsp+0x30]
000070dabbddb349  vmovaps xmm4, [rsp+0x40]
000070dabbddb34f  vmovaps xmm5, [rsp+0x50]
000070dabbddb355  vmovaps xmm6, [rsp+0x60]
000070dabbddb35b  vmovaps xmm7, [rsp+0x70]
000070dabbddb361  vmovaps xmm8, [rsp+0x80]
000070dabbddb36a  vmovaps xmm10, [rsp+0x90]
000070dabbddb373  vmovaps xmm11, [rsp+0xA0]
000070dabbddb37c  vmovaps xmm12, [rsp+0xB0]
000070dabbddb385  vmovaps xmm13, [rsp+0xC0]
000070dabbddb38e  vmovaps xmm14, [rsp+0xD0]
000070dabbddb397  vmovaps xmm15, [rsp+0xE0]
000070dabbddb3a0  add rsp, 0xF0
000070dabbddb3a7  pop r11
000070dabbddb3a9  pop r10
000070dabbddb3ab  pop r9
000070dabbddb3ad  pop r8
000070dabbddb3af  pop rsi
000070dabbddb3b0  pop rdi
000070dabbddb3b1  pop rdx
000070dabbddb3b2  pop rcx
000070dabbddb3b3  pop rax
000070dabbddb3b4  add rsp, 0x08
000070dabbddb3b8  jmp 0x000070DABBDD662F
000070dabbddb3bd  sub rsp, 0x08
000070dabbddb3c1  push rax
000070dabbddb3c2  push rcx
000070dabbddb3c3  push rdx
000070dabbddb3c4  push rdi
000070dabbddb3c5  push rsi
000070dabbddb3c6  push r8
000070dabbddb3c8  push r9
000070dabbddb3ca  push r10
000070dabbddb3cc  push r11
000070dabbddb3ce  sub rsp, 0xF0
000070dabbddb3d5  vmovaps [rsp], xmm0
000070dabbddb3da  vmovaps [rsp+0x10], xmm1
000070dabbddb3e0  vmovaps [rsp+0x20], xmm2
000070dabbddb3e6  vmovaps [rsp+0x30], xmm3
000070dabbddb3ec  vmovaps [rsp+0x40], xmm4
000070dabbddb3f2  vmovaps [rsp+0x50], xmm5
000070dabbddb3f8  vmovaps [rsp+0x60], xmm6
000070dabbddb3fe  vmovaps [rsp+0x70], xmm7
000070dabbddb404  vmovaps [rsp+0x80], xmm8
000070dabbddb40d  vmovaps [rsp+0x90], xmm9
000070dabbddb416  vmovaps [rsp+0xA0], xmm10
000070dabbddb41f  vmovaps [rsp+0xB0], xmm11
000070dabbddb428  vmovaps [rsp+0xC0], xmm12
000070dabbddb431  vmovaps [rsp+0xD0], xmm13
000070dabbddb43a  vmovaps [rsp+0xE0], xmm14
000070dabbddb443  sub rsp, 0x30
000070dabbddb447  movaps [rsp], xmm15
000070dabbddb44c  movaps [rsp+0x10], xmm11
000070dabbddb452  movaps [rsp+0x20], xmm12
000070dabbddb458  lea rdi, [rsp]
000070dabbddb45c  mov esi, 0x00
000070dabbddb461  mov rax, 0x5C2CF7B6F530
000070dabbddb46b  call rax
000070dabbddb46d  movaps xmm15, [rsp]
000070dabbddb472  add rsp, 0x30
000070dabbddb476  vmovaps xmm0, [rsp]
000070dabbddb47b  vmovaps xmm1, [rsp+0x10]
000070dabbddb481  vmovaps xmm2, [rsp+0x20]
000070dabbddb487  vmovaps xmm3, [rsp+0x30]
000070dabbddb48d  vmovaps xmm4, [rsp+0x40]
000070dabbddb493  vmovaps xmm5, [rsp+0x50]
000070dabbddb499  vmovaps xmm6, [rsp+0x60]
000070dabbddb49f  vmovaps xmm7, [rsp+0x70]
000070dabbddb4a5  vmovaps xmm8, [rsp+0x80]
000070dabbddb4ae  vmovaps xmm9, [rsp+0x90]
000070dabbddb4b7  vmovaps xmm10, [rsp+0xA0]
000070dabbddb4c0  vmovaps xmm11, [rsp+0xB0]
000070dabbddb4c9  vmovaps xmm12, [rsp+0xC0]
000070dabbddb4d2  vmovaps xmm13, [rsp+0xD0]
000070dabbddb4db  vmovaps xmm14, [rsp+0xE0]
000070dabbddb4e4  add rsp, 0xF0
000070dabbddb4eb  pop r11
000070dabbddb4ed  pop r10
000070dabbddb4ef  pop r9
000070dabbddb4f1  pop r8
000070dabbddb4f3  pop rsi
000070dabbddb4f4  pop rdi
000070dabbddb4f5  pop rdx
000070dabbddb4f6  pop rcx
000070dabbddb4f7  pop rax
000070dabbddb4f8  add rsp, 0x08
000070dabbddb4fc  jmp 0x000070DABBDD664A
000070dabbddb501  sub rsp, 0x08
000070dabbddb505  push rax
000070dabbddb506  push rcx
000070dabbddb507  push rdx
000070dabbddb508  push rdi
000070dabbddb509  push rsi
000070dabbddb50a  push r8
000070dabbddb50c  push r9
000070dabbddb50e  push r10
000070dabbddb510  push r11
000070dabbddb512  sub rsp, 0xF0
000070dabbddb519  vmovaps [rsp], xmm0
000070dabbddb51e  vmovaps [rsp+0x10], xmm1
000070dabbddb524  vmovaps [rsp+0x20], xmm2
000070dabbddb52a  vmovaps [rsp+0x30], xmm3
000070dabbddb530  vmovaps [rsp+0x40], xmm4
000070dabbddb536  vmovaps [rsp+0x50], xmm5
000070dabbddb53c  vmovaps [rsp+0x60], xmm6
000070dabbddb542  vmovaps [rsp+0x70], xmm7
000070dabbddb548  vmovaps [rsp+0x80], xmm8
000070dabbddb551  vmovaps [rsp+0x90], xmm9
000070dabbddb55a  vmovaps [rsp+0xA0], xmm10
000070dabbddb563  vmovaps [rsp+0xB0], xmm11
000070dabbddb56c  vmovaps [rsp+0xC0], xmm12
000070dabbddb575  vmovaps [rsp+0xD0], xmm14
000070dabbddb57e  vmovaps [rsp+0xE0], xmm15
000070dabbddb587  sub rsp, 0x30
000070dabbddb58b  movaps [rsp], xmm13
000070dabbddb590  movaps [rsp+0x10], xmm10
000070dabbddb596  movaps [rsp+0x20], xmm14
000070dabbddb59c  lea rdi, [rsp]
000070dabbddb5a0  mov esi, 0x00
000070dabbddb5a5  mov rax, 0x5C2CF7B6F530
000070dabbddb5af  call rax
000070dabbddb5b1  movaps xmm13, [rsp]
000070dabbddb5b6  add rsp, 0x30
000070dabbddb5ba  vmovaps xmm0, [rsp]
000070dabbddb5bf  vmovaps xmm1, [rsp+0x10]
000070dabbddb5c5  vmovaps xmm2, [rsp+0x20]
000070dabbddb5cb  vmovaps xmm3, [rsp+0x30]
000070dabbddb5d1  vmovaps xmm4, [rsp+0x40]
000070dabbddb5d7  vmovaps xmm5, [rsp+0x50]
000070dabbddb5dd  vmovaps xmm6, [rsp+0x60]
000070dabbddb5e3  vmovaps xmm7, [rsp+0x70]
000070dabbddb5e9  vmovaps xmm8, [rsp+0x80]
000070dabbddb5f2  vmovaps xmm9, [rsp+0x90]
000070dabbddb5fb  vmovaps xmm10, [rsp+0xA0]
000070dabbddb604  vmovaps xmm11, [rsp+0xB0]
000070dabbddb60d  vmovaps xmm12, [rsp+0xC0]
000070dabbddb616  vmovaps xmm14, [rsp+0xD0]
000070dabbddb61f  vmovaps xmm15, [rsp+0xE0]
000070dabbddb628  add rsp, 0xF0
000070dabbddb62f  pop r11
000070dabbddb631  pop r10
000070dabbddb633  pop r9
000070dabbddb635  pop r8
000070dabbddb637  pop rsi
000070dabbddb638  pop rdi
000070dabbddb639  pop rdx
000070dabbddb63a  pop rcx
000070dabbddb63b  pop rax
000070dabbddb63c  add rsp, 0x08
000070dabbddb640  jmp 0x000070DABBDD666D
000070dabbddb645  sub rsp, 0x08
000070dabbddb649  push rax
000070dabbddb64a  push rcx
000070dabbddb64b  push rdx
000070dabbddb64c  push rdi
000070dabbddb64d  push rsi
000070dabbddb64e  push r8
000070dabbddb650  push r9
000070dabbddb652  push r10
000070dabbddb654  push r11
000070dabbddb656  sub rsp, 0xF0
000070dabbddb65d  vmovaps [rsp], xmm0
000070dabbddb662  vmovaps [rsp+0x10], xmm1
000070dabbddb668  vmovaps [rsp+0x20], xmm2
000070dabbddb66e  vmovaps [rsp+0x30], xmm3
000070dabbddb674  vmovaps [rsp+0x40], xmm4
000070dabbddb67a  vmovaps [rsp+0x50], xmm5
000070dabbddb680  vmovaps [rsp+0x60], xmm6
000070dabbddb686  vmovaps [rsp+0x70], xmm7
000070dabbddb68c  vmovaps [rsp+0x80], xmm8
000070dabbddb695  vmovaps [rsp+0x90], xmm9
000070dabbddb69e  vmovaps [rsp+0xA0], xmm10
000070dabbddb6a7  vmovaps [rsp+0xB0], xmm11
000070dabbddb6b0  vmovaps [rsp+0xC0], xmm12
000070dabbddb6b9  vmovaps [rsp+0xD0], xmm13
000070dabbddb6c2  vmovaps [rsp+0xE0], xmm15
000070dabbddb6cb  sub rsp, 0x30
000070dabbddb6cf  movaps [rsp], xmm14
000070dabbddb6d4  movaps [rsp+0x10], xmm1
000070dabbddb6d9  movaps [rsp+0x20], xmm7
000070dabbddb6de  lea rdi, [rsp]
000070dabbddb6e2  mov esi, 0x00
000070dabbddb6e7  mov rax, 0x5C2CF7B6F530
000070dabbddb6f1  call rax
000070dabbddb6f3  movaps xmm14, [rsp]
000070dabbddb6f8  add rsp, 0x30
000070dabbddb6fc  vmovaps xmm0, [rsp]
000070dabbddb701  vmovaps xmm1, [rsp+0x10]
000070dabbddb707  vmovaps xmm2, [rsp+0x20]
000070dabbddb70d  vmovaps xmm3, [rsp+0x30]
000070dabbddb713  vmovaps xmm4, [rsp+0x40]
000070dabbddb719  vmovaps xmm5, [rsp+0x50]
000070dabbddb71f  vmovaps xmm6, [rsp+0x60]
000070dabbddb725  vmovaps xmm7, [rsp+0x70]
000070dabbddb72b  vmovaps xmm8, [rsp+0x80]
000070dabbddb734  vmovaps xmm9, [rsp+0x90]
000070dabbddb73d  vmovaps xmm10, [rsp+0xA0]
000070dabbddb746  vmovaps xmm11, [rsp+0xB0]
000070dabbddb74f  vmovaps xmm12, [rsp+0xC0]
000070dabbddb758  vmovaps xmm13, [rsp+0xD0]
000070dabbddb761  vmovaps xmm15, [rsp+0xE0]
000070dabbddb76a  add rsp, 0xF0
000070dabbddb771  pop r11
000070dabbddb773  pop r10
000070dabbddb775  pop r9
000070dabbddb777  pop r8
000070dabbddb779  pop rsi
000070dabbddb77a  pop rdi
000070dabbddb77b  pop rdx
000070dabbddb77c  pop rcx
000070dabbddb77d  pop rax
000070dabbddb77e  add rsp, 0x08
000070dabbddb782  jmp 0x000070DABBDD6690
000070dabbddb787  sub rsp, 0x08
000070dabbddb78b  push rax
000070dabbddb78c  push rcx
000070dabbddb78d  push rdx
000070dabbddb78e  push rdi
000070dabbddb78f  push rsi
000070dabbddb790  push r8
000070dabbddb792  push r9
000070dabbddb794  push r10
000070dabbddb796  push r11
000070dabbddb798  sub rsp, 0xF0
000070dabbddb79f  vmovaps [rsp], xmm0
000070dabbddb7a4  vmovaps [rsp+0x10], xmm2
000070dabbddb7aa  vmovaps [rsp+0x20], xmm3
000070dabbddb7b0  vmovaps [rsp+0x30], xmm4
000070dabbddb7b6  vmovaps [rsp+0x40], xmm5
000070dabbddb7bc  vmovaps [rsp+0x50], xmm6
000070dabbddb7c2  vmovaps [rsp+0x60], xmm7
000070dabbddb7c8  vmovaps [rsp+0x70], xmm8
000070dabbddb7ce  vmovaps [rsp+0x80], xmm9
000070dabbddb7d7  vmovaps [rsp+0x90], xmm10
000070dabbddb7e0  vmovaps [rsp+0xA0], xmm11
000070dabbddb7e9  vmovaps [rsp+0xB0], xmm12
000070dabbddb7f2  vmovaps [rsp+0xC0], xmm13
000070dabbddb7fb  vmovaps [rsp+0xD0], xmm14
000070dabbddb804  vmovaps [rsp+0xE0], xmm15
000070dabbddb80d  sub rsp, 0x30
000070dabbddb811  movaps [rsp], xmm1
000070dabbddb815  movaps [rsp+0x10], xmm8
000070dabbddb81b  movaps [rsp+0x20], xmm9
000070dabbddb821  lea rdi, [rsp]
000070dabbddb825  mov esi, 0x00
000070dabbddb82a  mov rax, 0x5C2CF7B6F530
000070dabbddb834  call rax
000070dabbddb836  movaps xmm1, [rsp]
000070dabbddb83a  add rsp, 0x30
000070dabbddb83e  vmovaps xmm0, [rsp]
000070dabbddb843  vmovaps xmm2, [rsp+0x10]
000070dabbddb849  vmovaps xmm3, [rsp+0x20]
000070dabbddb84f  vmovaps xmm4, [rsp+0x30]
000070dabbddb855  vmovaps xmm5, [rsp+0x40]
000070dabbddb85b  vmovaps xmm6, [rsp+0x50]
000070dabbddb861  vmovaps xmm7, [rsp+0x60]
000070dabbddb867  vmovaps xmm8, [rsp+0x70]
000070dabbddb86d  vmovaps xmm9, [rsp+0x80]
000070dabbddb876  vmovaps xmm10, [rsp+0x90]
000070dabbddb87f  vmovaps xmm11, [rsp+0xA0]
000070dabbddb888  vmovaps xmm12, [rsp+0xB0]
000070dabbddb891  vmovaps xmm13, [rsp+0xC0]
000070dabbddb89a  vmovaps xmm14, [rsp+0xD0]
000070dabbddb8a3  vmovaps xmm15, [rsp+0xE0]
000070dabbddb8ac  add rsp, 0xF0
000070dabbddb8b3  pop r11
000070dabbddb8b5  pop r10
000070dabbddb8b7  pop r9
000070dabbddb8b9  pop r8
000070dabbddb8bb  pop rsi
000070dabbddb8bc  pop rdi
000070dabbddb8bd  pop rdx
000070dabbddb8be  pop rcx
000070dabbddb8bf  pop rax
000070dabbddb8c0  add rsp, 0x08
000070dabbddb8c4  jmp 0x000070DABBDD66B2
000070dabbddb8c9  call 0x000070DABBCB3E40
000070dabbddb8ce  jmp 0x000070DABBDD66C0
000070dabbddb8d3  call 0x000070DABBC0C380
000070dabbddb8d8  jmp 0x000070DABBDD66CA
000070dabbddb8dd  call 0x000070DABBC0D600
000070dabbddb8e2  jmp 0x000070DABBDD66D4
000070dabbddb8e7  call 0x000070DABBBFF540
000070dabbddb8ec  jmp 0x000070DABBDD66DE
000070dabbddb8f1  int3
000070dabbddb8f2  nop [rax+rax*1], ax
000070dabbddb8fb  nop [rax+rax*1], eax
000070dabbddb900  mov eax, [r15+0x48]
000070dabbddb904  lea r14d, [eax+0x01]
000070dabbddb909  mov [rsp+0x10], r14d
000070dabbddb90e  mov r14d, r14d
000070dabbddb911  mov [r15+0x48], r14
000070dabbddb915  xor eax, eax
000070dabbddb917  mov r14d, [rsp+0x10]
000070dabbddb91c  cmp r14d, 0x1F4
000070dabbddb923  cmc
000070dabbddb924  lahf
000070dabbddb925  seto al
000070dabbddb928  mov [r15+0x108], eax
000070dabbddb92f  mov eax, [r15+0x108]
000070dabbddb936  sahf
000070dabbddb937  jnz 0x000070DABBDDB969
000070dabbddb939  cmp dword ptr [r15+0x318], 0x00
000070dabbddb941  jz 0x000070DABBDE1AB0
000070dabbddb947  nop [rax+rax*1], ax
000070dabbddb950  nop [rax+rax*1], eax
000070dabbddb958  mov eax, 0x410450
000070dabbddb95d  mov [r15+0x100], rax
000070dabbddb964  jmp 0x000070DABBBFE110
000070dabbddb969  cmp dword ptr [r15+0x318], 0x00
000070dabbddb971  jz 0x000070DABBDDB9A0
000070dabbddb977  nop [rax+rax*1], ax
000070dabbddb980  nop [rax+rax*1], eax
000070dabbddb988  mov eax, 0x410274
000070dabbddb98d  mov [r15+0x100], rax
000070dabbddb994  jmp 0x000070DABBBFE110
000070dabbddb999  int3
000070dabbddb99a  int3
000070dabbddb99b  nop [rax+rax*1], eax
000070dabbddb9a0  mov rax, [r15+0x40]
000070dabbddb9a4  movaps xmm1, [r15+0x1D0]
000070dabbddb9ac  vmovaps [rsp+0x10], xmm1
000070dabbddb9b2  vmovaps xmm15, [rsp+0x10]
000070dabbddb9b8  por xmm1, xmm15
000070dabbddb9bd  movaps xmm14, [r15+0x1A0]
000070dabbddb9c5  vmovaps [rsp+0x10], xmm14
000070dabbddb9cb  vmovaps xmm13, [rsp+0x10]
000070dabbddb9d1  por xmm14, xmm13
000070dabbddb9d6  lea r14, [rax+0x30]
000070dabbddb9da  mov r12, [r13+r14*1]
000070dabbddb9df  lea r14, [rax+0x38]
000070dabbddb9e3  mov r11, [r13+r14*1]
000070dabbddb9e8  movq xmm13, r12
000070dabbddb9ed  movq xmm12, r11
000070dabbddb9f2  movq xmm13, xmm13
000070dabbddb9f7  vmovaps [rsp+0x10], xmm13
000070dabbddb9fd  movq xmm13, xmm13
000070dabbddba02  movaps [r15+0x130], xmm13
000070dabbddba0a  movq xmm12, xmm12
000070dabbddba0f  vmovaps [rsp+0x20], xmm12
000070dabbddba15  movq xmm12, xmm12
000070dabbddba1a  movaps [r15+0x280], xmm12
000070dabbddba22  movaps xmm13, [r15+0x270]
000070dabbddba2a  vmovaps [rsp+0x30], xmm13
000070dabbddba30  vmovaps xmm12, [rsp+0x30]
000070dabbddba36  por xmm13, xmm12
000070dabbddba3b  lea r14, [rax+0x20]
000070dabbddba3f  mov r12, [r13+r14*1]
000070dabbddba44  lea r14, [rax+0x28]
000070dabbddba48  mov r11, [r13+r14*1]
000070dabbddba4d  movq xmm12, r12
000070dabbddba52  movq xmm11, r11
000070dabbddba57  movq xmm12, xmm12
000070dabbddba5c  vmovaps [rsp+0x30], xmm12
000070dabbddba62  movq xmm12, xmm12
000070dabbddba67  movaps [r15+0x150], xmm12
000070dabbddba6f  movq xmm11, xmm11
000070dabbddba74  vmovaps [rsp+0x40], xmm11
000070dabbddba7a  movq xmm11, xmm11
000070dabbddba7f  movaps [r15+0x140], xmm11
000070dabbddba87  lea r14, [rax+0x10]
000070dabbddba8b  mov r12, [r13+r14*1]
000070dabbddba90  lea r14, [rax+0x18]
000070dabbddba94  mov r11, [r13+r14*1]
000070dabbddba99  movq xmm12, r12
000070dabbddba9e  movq xmm11, r11
000070dabbddbaa3  movq xmm12, xmm12
000070dabbddbaa8  vmovaps [rsp+0x50], xmm12
000070dabbddbaae  movq xmm12, xmm12
000070dabbddbab3  movaps [r15+0x170], xmm12
000070dabbddbabb  movq xmm11, xmm11
000070dabbddbac0  vmovaps [rsp+0x60], xmm11
000070dabbddbac6  movq xmm11, xmm11
000070dabbddbacb  movaps [r15+0x160], xmm11
000070dabbddbad3  mov r14, [r13+rax*1]
000070dabbddbad8  vmovq xmm12, r14
000070dabbddbadd  vpbroadcastq xmm12, xmm12
000070dabbddbae2  lea r14, [rax+0x08]
000070dabbddbae6  mov rax, [r13+r14*1]
000070dabbddbaeb  movq xmm11, rax
000070dabbddbaf0  movaps [r15+0x230], xmm11
000070dabbddbaf8  mov rax, [r15+0xF8]
000070dabbddbaff  lea r14, [rax+0x50]
000070dabbddbb03  movups xmm11, [r13+r14*1]
000070dabbddbb09  lea r14, [rax+0x60]
000070dabbddbb0d  movups xmm10, [r13+r14*1]
000070dabbddbb13  lea r14, [rax+0x30]
000070dabbddbb17  movups xmm9, [r13+r14*1]
000070dabbddbb1d  mov r14, [r15+0x50]
000070dabbddbb21  mov [r15+0x60], r14
000070dabbddbb25  mov qword ptr [r15+0x58], 0x40
000070dabbddbb2d  movaps xmm8, xmm12
000070dabbddbb31  mulpd xmm8, xmm15
000070dabbddbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000070dabbddbb3c  ptest xmm7, xmm7
000070dabbddbb41  jnz 0x000070DABBDDC96A
000070dabbddbb47  movq xmm15, qword ptr [r15+0x230]
000070dabbddbb50  vmovaps [rsp+0x70], xmm15
000070dabbddbb56  vpermilpd xmm15, xmm15, 0x00
000070dabbddbb5c  movaps xmm7, xmm9
000070dabbddbb60  mulpd xmm7, xmm15
000070dabbddbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000070dabbddbb6a  ptest xmm6, xmm6
000070dabbddbb6f  jnz 0x000070DABBDDCAAE
000070dabbddbb75  vxorps xmm15, xmm15, xmm15
000070dabbddbb7a  vpbroadcastq xmm15, xmm15
000070dabbddbb7f  movaps xmm9, xmm12
000070dabbddbb83  mulpd xmm9, xmm10
000070dabbddbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000070dabbddbb8e  ptest xmm6, xmm6
000070dabbddbb93  jnz 0x000070DABBDDCBF0
000070dabbddbb99  movaps xmm10, xmm12
000070dabbddbb9d  mulpd xmm10, xmm11
000070dabbddbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000070dabbddbba8  ptest xmm6, xmm6
000070dabbddbbad  jnz 0x000070DABBDDCD34
000070dabbddbbb3  movaps xmm11, [r15+0x1F0]
000070dabbddbbbb  movaps xmm6, xmm12
000070dabbddbbbf  mulpd xmm6, xmm11
000070dabbddbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000070dabbddbbc9  ptest xmm5, xmm5
000070dabbddbbce  jnz 0x000070DABBDDCE78
000070dabbddbbd4  movaps xmm12, [r15+0x2A0]
000070dabbddbbdc  vmovaps [rsp+0x80], xmm12
000070dabbddbbe5  vmovaps xmm11, [rsp+0x80]
000070dabbddbbee  por xmm12, xmm11
000070dabbddbbf3  movaps xmm11, [r15+0x250]
000070dabbddbbfb  vmovaps [rsp+0x80], xmm11
000070dabbddbc04  vmovaps xmm5, [rsp+0x80]
000070dabbddbc0d  por xmm11, xmm5
000070dabbddbc12  vmovaps xmm4, [rsp+0x70]
000070dabbddbc18  vpermilpd xmm4, xmm4, 0x00
000070dabbddbc1e  movaps xmm3, xmm5
000070dabbddbc21  mulpd xmm3, xmm4
000070dabbddbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000070dabbddbc2a  ptest xmm2, xmm2
000070dabbddbc2f  jnz 0x000070DABBDDCFBA
000070dabbddbc35  mov [rsp+0x80], rax
000070dabbddbc3d  xor eax, eax
000070dabbddbc3f  mov r12d, 0x40
000070dabbddbc45  mov r11d, 0x200
000070dabbddbc4b  cmp r12, r11
000070dabbddbc4e  cmc
000070dabbddbc4f  lahf
000070dabbddbc50  seto al
000070dabbddbc53  mov [r15+0x108], eax
000070dabbddbc5a  movaps xmm5, xmm8
000070dabbddbc5e  addpd xmm5, xmm15
000070dabbddbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000070dabbddbc68  ptest xmm4, xmm4
000070dabbddbc6d  jnz 0x000070DABBDDD0FA
000070dabbddbc73  movaps xmm8, [r15+0x1B0]
000070dabbddbc7b  movaps xmm4, xmm9
000070dabbddbc7f  addpd xmm4, xmm8
000070dabbddbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000070dabbddbc89  ptest xmm2, xmm2
000070dabbddbc8e  jnz 0x000070DABBDDD23C
000070dabbddbc94  movaps xmm9, xmm10
000070dabbddbc98  addpd xmm9, xmm8
000070dabbddbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000070dabbddbca3  ptest xmm2, xmm2
000070dabbddbca8  jnz 0x000070DABBDDD37E
000070dabbddbcae  movaps xmm10, [r15+0x2F0]
000070dabbddbcb6  vmovaps [rsp+0x90], xmm10
000070dabbddbcbf  vmovaps xmm8, [rsp+0x90]
000070dabbddbcc8  por xmm10, xmm8
000070dabbddbccd  movaps xmm8, [r15+0x2E0]
000070dabbddbcd5  vmovaps [rsp+0x90], xmm8
000070dabbddbcde  vmovaps xmm2, [rsp+0x90]
000070dabbddbce7  por xmm8, xmm2
000070dabbddbcec  movaps xmm2, [r15+0x2D0]
000070dabbddbcf4  vmovaps [rsp+0x90], xmm2
000070dabbddbcfd  vmovaps [rsp+0xA0], xmm1
000070dabbddbd06  vmovaps xmm1, [rsp+0x90]
000070dabbddbd0f  por xmm2, xmm1
000070dabbddbd13  movaps xmm1, [r15+0x200]
000070dabbddbd1b  vmovaps [rsp+0x90], xmm1
000070dabbddbd24  vmovaps [rsp+0xB0], xmm15
000070dabbddbd2d  vmovaps xmm15, [rsp+0x90]
000070dabbddbd36  por xmm1, xmm15
000070dabbddbd3b  movaps xmm15, [r15+0x1C0]
000070dabbddbd43  vmovaps [rsp+0x90], xmm15
000070dabbddbd4c  vmovaps [rsp+0xC0], xmm1
000070dabbddbd55  vmovaps xmm1, [rsp+0x90]
000070dabbddbd5e  por xmm15, xmm1
000070dabbddbd63  movaps xmm1, [r15+0x190]
000070dabbddbd6b  vmovaps [rsp+0x90], xmm1
000070dabbddbd74  vmovaps [rsp+0xD0], xmm15
000070dabbddbd7d  vmovaps xmm15, [rsp+0x90]
000070dabbddbd86  por xmm1, xmm15
000070dabbddbd8b  movaps xmm15, [r15+0x300]
000070dabbddbd93  vmovaps [rsp+0x90], xmm15
000070dabbddbd9c  vmovaps [rsp+0xE0], xmm1
000070dabbddbda5  vmovaps xmm1, [rsp+0x90]
000070dabbddbdae  por xmm15, xmm1
000070dabbddbdb3  mov rax, [rsp+0x80]
000070dabbddbdbb  lea r12, [rax+0xA0]
000070dabbddbdc2  movups xmm1, [r13+r12*1]
000070dabbddbdc8  lea r12, [rax+0xB0]
000070dabbddbdcf  vmovaps [rsp+0x80], xmm1
000070dabbddbdd8  movups xmm1, [r13+r12*1]
000070dabbddbdde  vmovaps [rsp+0x90], xmm1
000070dabbddbde7  vmovaps [rsp+0xF0], xmm15
000070dabbddbdf0  vmovaps xmm15, [rsp+0xB0]
000070dabbddbdf9  vmovaps [rsp+0xB0], xmm14
000070dabbddbe02  movaps xmm1, xmm6
000070dabbddbe05  addpd xmm1, xmm15
000070dabbddbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000070dabbddbe0f  ptest xmm14, xmm14
000070dabbddbe15  jnz 0x000070DABBDDD4D6
000070dabbddbe1b  lea r12, [rax+0xF0]
000070dabbddbe22  movups xmm15, [r13+r12*1]
000070dabbddbe28  movaps xmm14, xmm4
000070dabbddbe2c  addpd xmm14, xmm3
000070dabbddbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000070dabbddbe37  ptest xmm6, xmm6
000070dabbddbe3c  jnz 0x000070DABBDDD621
000070dabbddbe42  movaps xmm6, xmm9
000070dabbddbe46  addpd xmm6, xmm7
000070dabbddbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000070dabbddbe4f  ptest xmm4, xmm4
000070dabbddbe54  jnz 0x000070DABBDDD763
000070dabbddbe5a  vmovaps xmm9, [rsp+0x70]
000070dabbddbe60  vpermilpd xmm9, xmm9, 0x00
000070dabbddbe66  vmovaps xmm4, [rsp+0x90]
000070dabbddbe6f  movaps xmm7, xmm4
000070dabbddbe72  mulpd xmm7, xmm9
000070dabbddbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000070dabbddbe7c  ptest xmm3, xmm3
000070dabbddbe81  jnz 0x000070DABBDDD8A4
000070dabbddbe87  vmovaps xmm9, [rsp+0x50]
000070dabbddbe8d  vpermilpd xmm9, xmm9, 0x00
000070dabbddbe93  movaps xmm4, xmm15
000070dabbddbe97  mulpd xmm4, xmm9
000070dabbddbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000070dabbddbea1  ptest xmm3, xmm3
000070dabbddbea6  jnz 0x000070DABBDDD9E5
000070dabbddbeac  lea r12, [rax+0xE0]
000070dabbddbeb3  movups xmm15, [r13+r12*1]
000070dabbddbeb9  vmovaps xmm9, [rsp+0x70]
000070dabbddbebf  vpermilpd xmm9, xmm9, 0x00
000070dabbddbec5  vmovaps [rsp+0x70], xmm1
000070dabbddbecb  vmovaps xmm1, [rsp+0x80]
000070dabbddbed4  vmovaps [rsp+0x80], xmm15
000070dabbddbedd  movaps xmm3, xmm1
000070dabbddbee0  mulpd xmm3, xmm9
000070dabbddbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000070dabbddbeea  ptest xmm15, xmm15
000070dabbddbef0  jnz 0x000070DABBDDDB31
000070dabbddbef6  vmovaps xmm1, [rsp+0xF0]
000070dabbddbeff  vmovaps xmm15, [rsp+0xF0]
000070dabbddbf08  por xmm1, xmm15
000070dabbddbf0d  movaps [r15+0x300], xmm1
000070dabbddbf15  vmovaps xmm15, [rsp+0xE0]
000070dabbddbf1e  vmovaps xmm9, [rsp+0xE0]
000070dabbddbf27  por xmm15, xmm9
000070dabbddbf2c  movaps [r15+0x190], xmm15
000070dabbddbf34  vmovaps xmm9, [rsp+0x50]
000070dabbddbf3a  vpermilpd xmm9, xmm9, 0x00
000070dabbddbf40  vmovaps [rsp+0x90], xmm1
000070dabbddbf49  vmovaps [rsp+0xE0], xmm15
000070dabbddbf52  vmovaps xmm15, [rsp+0x80]
000070dabbddbf5b  vmovaps [rsp+0x80], xmm14
000070dabbddbf64  movaps xmm1, xmm15
000070dabbddbf68  mulpd xmm1, xmm9
000070dabbddbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000070dabbddbf72  ptest xmm14, xmm14
000070dabbddbf78  jnz 0x000070DABBDDDC72
000070dabbddbf7e  lea r12, [rax+0x90]
000070dabbddbf85  movups xmm15, [r13+r12*1]
000070dabbddbf8b  vmovaps xmm14, [rsp+0xD0]
000070dabbddbf94  vmovaps xmm9, [rsp+0xD0]
000070dabbddbf9d  por xmm14, xmm9
000070dabbddbfa2  movaps [r15+0x1C0], xmm14
000070dabbddbfaa  vmovaps xmm9, [rsp+0xC0]
000070dabbddbfb3  vmovaps [rsp+0xD0], xmm1
000070dabbddbfbc  vmovaps xmm1, [rsp+0xC0]
000070dabbddbfc5  por xmm9, xmm1
000070dabbddbfca  movaps [r15+0x200], xmm9
000070dabbddbfd2  vmovaps [rsp+0xC0], xmm2
000070dabbddbfdb  vmovaps xmm1, [rsp+0xC0]
000070dabbddbfe4  por xmm2, xmm1
000070dabbddbfe8  movaps [r15+0x2D0], xmm2
000070dabbddbff0  vmovaps [rsp+0xC0], xmm8
000070dabbddbff9  vmovaps xmm1, [rsp+0xC0]
000070dabbddc002  por xmm8, xmm1
000070dabbddc007  movaps [r15+0x2E0], xmm8
000070dabbddc00f  vmovaps [rsp+0xC0], xmm15
000070dabbddc018  movaps xmm1, xmm5
000070dabbddc01b  addpd xmm1, xmm7
000070dabbddc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000070dabbddc024  ptest xmm15, xmm15
000070dabbddc02a  jnz 0x000070DABBDDDDBE
000070dabbddc030  vmovaps xmm15, [rsp+0x50]
000070dabbddc036  vpermilpd xmm15, xmm15, 0x00
000070dabbddc03c  vmovaps xmm5, [rsp+0xC0]
000070dabbddc045  vmovaps [rsp+0xC0], xmm1
000070dabbddc04e  movaps xmm7, xmm5
000070dabbddc051  mulpd xmm7, xmm15
000070dabbddc056  vcmppd xmm1, xmm7, xmm7, 0x03
000070dabbddc05b  ptest xmm1, xmm1
000070dabbddc060  jnz 0x000070DABBDDDEFE
000070dabbddc066  lea r12, [rax+0x80]
000070dabbddc06d  movups xmm1, [r13+r12*1]
000070dabbddc073  vmovaps xmm5, [rsp+0x70]
000070dabbddc079  vmovaps [rsp+0x70], xmm1
000070dabbddc07f  movaps xmm15, xmm5
000070dabbddc083  addpd xmm15, xmm3
000070dabbddc088  vcmppd xmm1, xmm15, xmm15, 0x03
000070dabbddc08e  ptest xmm1, xmm1
000070dabbddc093  jnz 0x000070DABBDDE049
000070dabbddc099  vmovaps xmm5, [rsp+0x80]
000070dabbddc0a2  movaps xmm1, xmm5
000070dabbddc0a5  addpd xmm1, xmm4
000070dabbddc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000070dabbddc0ae  ptest xmm3, xmm3
000070dabbddc0b3  jnz 0x000070DABBDDE18B
000070dabbddc0b9  vmovaps [rsp+0x80], xmm10
000070dabbddc0c2  vmovaps xmm5, [rsp+0x80]
000070dabbddc0cb  por xmm10, xmm5
000070dabbddc0d0  movaps [r15+0x2F0], xmm10
000070dabbddc0d8  vmovaps xmm5, [rsp+0x50]
000070dabbddc0de  vpermilpd xmm5, xmm5, 0x00
000070dabbddc0e4  vmovaps xmm3, [rsp+0x70]
000070dabbddc0ea  vmovaps [rsp+0x50], xmm1
000070dabbddc0f0  movaps xmm4, xmm3
000070dabbddc0f3  mulpd xmm4, xmm5
000070dabbddc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000070dabbddc0fc  ptest xmm1, xmm1
000070dabbddc101  jnz 0x000070DABBDDE2CB
000070dabbddc107  lea r12, [rax+0xD0]
000070dabbddc10e  movups xmm1, [r13+r12*1]
000070dabbddc114  vmovaps xmm3, [rsp+0xD0]
000070dabbddc11d  vmovaps [rsp+0x70], xmm1
000070dabbddc123  movaps xmm5, xmm6
000070dabbddc126  addpd xmm5, xmm3
000070dabbddc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000070dabbddc12f  ptest xmm1, xmm1
000070dabbddc134  jnz 0x000070DABBDDE415
000070dabbddc13a  vmovaps xmm1, [rsp+0x60]
000070dabbddc140  vpermilpd xmm1, xmm1, 0x00
000070dabbddc146  movaps xmm6, xmm9
000070dabbddc14a  mulpd xmm6, xmm1
000070dabbddc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000070dabbddc153  ptest xmm3, xmm3
000070dabbddc158  jnz 0x000070DABBDDE555
000070dabbddc15e  movaps [r15+0x260], xmm6
000070dabbddc166  vxorps xmm1, xmm1, xmm1
000070dabbddc16a  vpbroadcastq xmm1, xmm1
000070dabbddc16f  movaps [r15+0x1B0], xmm1
000070dabbddc177  vmovaps xmm1, [rsp+0x60]
000070dabbddc17d  vpermilpd xmm1, xmm1, 0x00
000070dabbddc183  vmovaps xmm3, [rsp+0x70]
000070dabbddc189  vmovaps [rsp+0x70], xmm15
000070dabbddc18f  movaps xmm9, xmm3
000070dabbddc193  mulpd xmm9, xmm1
000070dabbddc198  vcmppd xmm15, xmm9, xmm9, 0x03
000070dabbddc19e  ptest xmm15, xmm15
000070dabbddc1a4  jnz 0x000070DABBDDE696
000070dabbddc1aa  lea r12, [rax+0xC0]
000070dabbddc1b1  movups xmm1, [r13+r12*1]
000070dabbddc1b7  vmovaps xmm3, [rsp+0xC0]
000070dabbddc1c0  vmovaps [rsp+0x80], xmm1
000070dabbddc1c9  movaps xmm15, xmm3
000070dabbddc1cd  addpd xmm15, xmm7
000070dabbddc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000070dabbddc1d8  ptest xmm1, xmm1
000070dabbddc1dd  jnz 0x000070DABBDDE7E2
000070dabbddc1e3  vmovaps [rsp+0xC0], xmm13
000070dabbddc1ec  vmovaps xmm1, [rsp+0xC0]
000070dabbddc1f5  por xmm13, xmm1
000070dabbddc1fa  movaps [r15+0x270], xmm13
000070dabbddc202  vmovaps xmm1, [rsp+0xB0]
000070dabbddc20b  vmovaps xmm7, [rsp+0xB0]
000070dabbddc214  por xmm1, xmm7
000070dabbddc218  movaps [r15+0x1A0], xmm1
000070dabbddc220  vmovaps xmm1, [rsp+0x60]
000070dabbddc226  vpermilpd xmm1, xmm1, 0x00
000070dabbddc22c  vmovaps [rsp+0xB0], xmm1
000070dabbddc235  vmovaps xmm1, [rsp+0x80]
000070dabbddc23e  vmovaps [rsp+0x80], xmm15
000070dabbddc247  vmovaps xmm15, [rsp+0xB0]
000070dabbddc250  vmovaps [rsp+0xB0], xmm14
000070dabbddc259  movaps xmm3, xmm1
000070dabbddc25c  mulpd xmm3, xmm15
000070dabbddc261  vcmppd xmm14, xmm3, xmm3, 0x03
000070dabbddc266  ptest xmm14, xmm14
000070dabbddc26c  jnz 0x000070DABBDDE924
000070dabbddc272  lea r12, [rax+0x20]
000070dabbddc276  movups xmm1, [r13+r12*1]
000070dabbddc27c  movaps [r15+0x110], xmm1
000070dabbddc284  vmovaps xmm14, [rsp+0x70]
000070dabbddc28a  vmovaps [rsp+0x70], xmm1
000070dabbddc290  movaps xmm15, xmm14
000070dabbddc294  addpd xmm15, xmm4
000070dabbddc299  vcmppd xmm1, xmm15, xmm15, 0x03
000070dabbddc29f  ptest xmm1, xmm1
000070dabbddc2a4  jnz 0x000070DABBDDEA6F
000070dabbddc2aa  vmovaps xmm1, [rsp+0x60]
000070dabbddc2b0  vpermilpd xmm1, xmm1, 0x00
000070dabbddc2b6  movaps xmm14, xmm2
000070dabbddc2ba  mulpd xmm14, xmm1
000070dabbddc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000070dabbddc2c5  ptest xmm4, xmm4
000070dabbddc2ca  jnz 0x000070DABBDDEBB2
000070dabbddc2d0  vmovaps xmm4, [rsp+0x50]
000070dabbddc2d6  movaps xmm1, xmm4
000070dabbddc2d9  addpd xmm1, xmm9
000070dabbddc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000070dabbddc2e3  ptest xmm2, xmm2
000070dabbddc2e8  jnz 0x000070DABBDDECF4
000070dabbddc2ee  vmovaps xmm9, [rsp+0x30]
000070dabbddc2f4  vpermilpd xmm9, xmm9, 0x00
000070dabbddc2fa  vmovaps xmm2, [rsp+0x70]
000070dabbddc300  vmovaps [rsp+0x50], xmm1
000070dabbddc306  movaps xmm4, xmm2
000070dabbddc309  mulpd xmm4, xmm9
000070dabbddc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000070dabbddc313  ptest xmm1, xmm1
000070dabbddc318  jnz 0x000070DABBDDEE35
000070dabbddc31e  vmovaps xmm1, [rsp+0x30]
000070dabbddc324  vpermilpd xmm1, xmm1, 0x00
000070dabbddc32a  vmovaps xmm2, [rsp+0x90]
000070dabbddc333  vmovaps [rsp+0x60], xmm15
000070dabbddc339  movaps xmm9, xmm2
000070dabbddc33d  mulpd xmm9, xmm1
000070dabbddc342  vcmppd xmm15, xmm9, xmm9, 0x03
000070dabbddc348  ptest xmm15, xmm15
000070dabbddc34e  jnz 0x000070DABBDDEF76
000070dabbddc354  vmovaps xmm15, [rsp+0x80]
000070dabbddc35d  movaps xmm1, xmm15
000070dabbddc361  addpd xmm1, xmm6
000070dabbddc365  vcmppd xmm2, xmm1, xmm1, 0x03
000070dabbddc36a  ptest xmm2, xmm2
000070dabbddc36f  jnz 0x000070DABBDDF0B8
000070dabbddc375  movaps xmm15, xmm5
000070dabbddc379  addpd xmm15, xmm3
000070dabbddc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000070dabbddc384  ptest xmm6, xmm6
000070dabbddc389  jnz 0x000070DABBDDF1F9
000070dabbddc38f  vmovaps xmm6, [rsp+0x30]
000070dabbddc395  vpermilpd xmm6, xmm6, 0x00
000070dabbddc39b  movaps xmm5, xmm8
000070dabbddc39f  mulpd xmm5, xmm6
000070dabbddc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000070dabbddc3a8  ptest xmm3, xmm3
000070dabbddc3ad  jnz 0x000070DABBDDF33B
000070dabbddc3b3  vmovaps xmm8, [rsp+0x30]
000070dabbddc3b9  vpermilpd xmm8, xmm8, 0x00
000070dabbddc3bf  movaps xmm6, xmm10
000070dabbddc3c3  mulpd xmm6, xmm8
000070dabbddc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000070dabbddc3cd  ptest xmm3, xmm3
000070dabbddc3d2  jnz 0x000070DABBDDF47C
000070dabbddc3d8  vmovaps xmm8, [rsp+0x60]
000070dabbddc3de  movaps xmm10, xmm8
000070dabbddc3e2  addpd xmm10, xmm14
000070dabbddc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000070dabbddc3ed  ptest xmm3, xmm3
000070dabbddc3f2  jnz 0x000070DABBDDF5BE
000070dabbddc3f8  vmovaps xmm8, [rsp+0x50]
000070dabbddc3fe  movaps xmm14, xmm8
000070dabbddc402  addpd xmm14, xmm4
000070dabbddc407  vcmppd xmm3, xmm14, xmm14, 0x03
000070dabbddc40d  ptest xmm3, xmm3
000070dabbddc412  jnz 0x000070DABBDDF702
000070dabbddc418  vmovaps xmm8, [rsp+0x40]
000070dabbddc41e  vpermilpd xmm8, xmm8, 0x00
000070dabbddc424  movaps xmm4, xmm13
000070dabbddc428  mulpd xmm4, xmm8
000070dabbddc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000070dabbddc432  ptest xmm3, xmm3
000070dabbddc437  jnz 0x000070DABBDDF845
000070dabbddc43d  movaps xmm13, xmm15
000070dabbddc441  addpd xmm13, xmm9
000070dabbddc446  vcmppd xmm8, xmm13, xmm13, 0x03
000070dabbddc44c  ptest xmm8, xmm8
000070dabbddc452  jnz 0x000070DABBDDF987
000070dabbddc458  movaps xmm15, xmm1
000070dabbddc45c  addpd xmm15, xmm5
000070dabbddc461  vcmppd xmm9, xmm15, xmm15, 0x03
000070dabbddc467  ptest xmm9, xmm9
000070dabbddc46d  jnz 0x000070DABBDDFACB
000070dabbddc473  vmovaps [rsp+0x30], xmm11
000070dabbddc479  vmovaps xmm1, [rsp+0x30]
000070dabbddc47f  por xmm11, xmm1
000070dabbddc484  movaps [r15+0x250], xmm11
000070dabbddc48c  vmovaps [rsp+0x30], xmm12
000070dabbddc492  vmovaps xmm1, [rsp+0x30]
000070dabbddc498  por xmm12, xmm1
000070dabbddc49d  movaps [r15+0x2A0], xmm12
000070dabbddc4a5  vmovaps xmm1, [rsp+0xA0]
000070dabbddc4ae  vmovaps xmm11, [rsp+0xA0]
000070dabbddc4b7  por xmm1, xmm11
000070dabbddc4bc  movaps [r15+0x1D0], xmm1
000070dabbddc4c4  lea r12, [rax+0x40]
000070dabbddc4c8  movups xmm1, [r13+r12*1]
000070dabbddc4ce  movaps [r15+0x2C0], xmm1
000070dabbddc4d6  vmovaps xmm11, [rsp+0x40]
000070dabbddc4dc  vpermilpd xmm11, xmm11, 0x00
000070dabbddc4e2  vmovaps xmm8, [rsp+0xE0]
000070dabbddc4eb  movaps xmm9, xmm8
000070dabbddc4ef  mulpd xmm9, xmm11
000070dabbddc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000070dabbddc4fa  ptest xmm5, xmm5
000070dabbddc4ff  jnz 0x000070DABBDDFC17
000070dabbddc505  movaps xmm11, xmm10
000070dabbddc509  addpd xmm11, xmm6
000070dabbddc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000070dabbddc514  ptest xmm8, xmm8
000070dabbddc51a  jnz 0x000070DABBDDFD5B
000070dabbddc520  movaps xmm10, xmm14
000070dabbddc524  addpd xmm10, xmm4
000070dabbddc529  vcmppd xmm8, xmm10, xmm10, 0x03
000070dabbddc52f  ptest xmm8, xmm8
000070dabbddc535  jnz 0x000070DABBDDFE9E
000070dabbddc53b  vmovaps xmm14, [rsp+0x40]
000070dabbddc541  vpermilpd xmm14, xmm14, 0x00
000070dabbddc547  movaps xmm8, xmm1
000070dabbddc54b  mulpd xmm8, xmm14
000070dabbddc550  vcmppd xmm6, xmm8, xmm8, 0x03
000070dabbddc556  ptest xmm6, xmm6
000070dabbddc55b  jnz 0x000070DABBDDFFE1
000070dabbddc561  movaps xmm1, [r15+0x2B0]
000070dabbddc569  vmovaps xmm14, [rsp+0x40]
000070dabbddc56f  vpermilpd xmm14, xmm14, 0x00
000070dabbddc575  movaps xmm6, xmm1
000070dabbddc578  mulpd xmm6, xmm14
000070dabbddc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000070dabbddc582  ptest xmm5, xmm5
000070dabbddc587  jnz 0x000070DABBDE0124
000070dabbddc58d  vmovaps xmm1, [rsp+0x10]
000070dabbddc593  vpermilpd xmm1, xmm1, 0x00
000070dabbddc599  movaps xmm14, xmm12
000070dabbddc59d  mulpd xmm14, xmm1
000070dabbddc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000070dabbddc5a8  ptest xmm5, xmm5
000070dabbddc5ad  jnz 0x000070DABBDE0265
000070dabbddc5b3  movaps xmm1, xmm13
000070dabbddc5b7  addpd xmm1, xmm9
000070dabbddc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000070dabbddc5c1  ptest xmm12, xmm12
000070dabbddc5c7  jnz 0x000070DABBDE03A8
000070dabbddc5cd  vmovaps xmm13, [rsp+0x10]
000070dabbddc5d3  vpermilpd xmm13, xmm13, 0x00
000070dabbddc5d9  movaps xmm12, xmm7
000070dabbddc5dd  mulpd xmm12, xmm13
000070dabbddc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000070dabbddc5e8  ptest xmm9, xmm9
000070dabbddc5ee  jnz 0x000070DABBDE04EA
000070dabbddc5f4  movaps xmm13, xmm15
000070dabbddc5f8  addpd xmm13, xmm8
000070dabbddc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000070dabbddc603  ptest xmm9, xmm9
000070dabbddc609  jnz 0x000070DABBDE062D
000070dabbddc60f  movaps xmm15, [r15+0x290]
000070dabbddc617  vmovaps xmm9, [rsp+0x10]
000070dabbddc61d  vpermilpd xmm9, xmm9, 0x00
000070dabbddc623  movaps xmm8, xmm15
000070dabbddc627  mulpd xmm8, xmm9
000070dabbddc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000070dabbddc632  ptest xmm7, xmm7
000070dabbddc637  jnz 0x000070DABBDE0771
000070dabbddc63d  movaps xmm15, xmm11
000070dabbddc641  addpd xmm15, xmm6
000070dabbddc646  vcmppd xmm9, xmm15, xmm15, 0x03
000070dabbddc64c  ptest xmm9, xmm9
000070dabbddc652  jnz 0x000070DABBDE08B5
000070dabbddc658  movaps xmm11, [r15+0x1E0]
000070dabbddc660  vmovaps xmm9, [rsp+0x10]
000070dabbddc666  vpermilpd xmm9, xmm9, 0x00
000070dabbddc66c  movaps xmm7, xmm11
000070dabbddc670  mulpd xmm7, xmm9
000070dabbddc675  vcmppd xmm6, xmm7, xmm7, 0x03
000070dabbddc67a  ptest xmm6, xmm6
000070dabbddc67f  jnz 0x000070DABBDE09F8
000070dabbddc685  movaps xmm11, xmm10
000070dabbddc689  addpd xmm11, xmm14
000070dabbddc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000070dabbddc694  ptest xmm9, xmm9
000070dabbddc69a  jnz 0x000070DABBDE0B3A
000070dabbddc6a0  lea r12, [rax+0x70]
000070dabbddc6a4  movups xmm14, [r13+r12*1]
000070dabbddc6aa  movaps [r15+0x240], xmm14
000070dabbddc6b2  movaps xmm10, xmm1
000070dabbddc6b6  addpd xmm10, xmm12
000070dabbddc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000070dabbddc6c1  ptest xmm9, xmm9
000070dabbddc6c7  jnz 0x000070DABBDE0C88
000070dabbddc6cd  movaps [r15+0x170], xmm10
000070dabbddc6d5  vmovaps xmm1, [rsp+0x20]
000070dabbddc6db  vpermilpd xmm1, xmm1, 0x00
000070dabbddc6e1  movaps xmm12, xmm14
000070dabbddc6e5  mulpd xmm12, xmm1
000070dabbddc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000070dabbddc6f0  ptest xmm9, xmm9
000070dabbddc6f6  jnz 0x000070DABBDE0DCB
000070dabbddc6fc  vmovaps xmm1, [rsp+0x20]
000070dabbddc702  vpermilpd xmm1, xmm1, 0x00
000070dabbddc708  vmovaps xmm9, [rsp+0xB0]
000070dabbddc711  movaps xmm14, xmm9
000070dabbddc715  mulpd xmm14, xmm1
000070dabbddc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000070dabbddc720  ptest xmm6, xmm6
000070dabbddc725  jnz 0x000070DABBDE0F0E
000070dabbddc72b  movaps [r15+0x180], xmm14
000070dabbddc733  movaps xmm1, xmm13
000070dabbddc737  addpd xmm1, xmm8
000070dabbddc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000070dabbddc741  ptest xmm9, xmm9
000070dabbddc747  jnz 0x000070DABBDE1051
000070dabbddc74d  movaps [r15+0x210], xmm1
000070dabbddc755  movups xmm13, [r13+rax*1]
000070dabbddc75b  lea r12, [rax+0x10]
000070dabbddc75f  movups xmm9, [r13+r12*1]
000070dabbddc765  movaps [r15+0x230], xmm9
000070dabbddc76d  movaps xmm8, xmm15
000070dabbddc771  addpd xmm8, xmm7
000070dabbddc776  vcmppd xmm6, xmm8, xmm8, 0x03
000070dabbddc77c  ptest xmm6, xmm6
000070dabbddc781  jnz 0x000070DABBDE11A7
000070dabbddc787  movaps [r15+0x130], xmm8
000070dabbddc78f  vmovaps xmm15, [rsp+0x20]
000070dabbddc795  vpermilpd xmm15, xmm15, 0x00
000070dabbddc79b  movaps xmm7, xmm9
000070dabbddc79f  mulpd xmm7, xmm15
000070dabbddc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000070dabbddc7a9  ptest xmm6, xmm6
000070dabbddc7ae  jnz 0x000070DABBDE12EA
000070dabbddc7b4  movaps [r15+0x220], xmm7
000070dabbddc7bc  vmovaps xmm15, [rsp+0x20]
000070dabbddc7c2  vpermilpd xmm15, xmm15, 0x00
000070dabbddc7c8  movaps xmm9, xmm13
000070dabbddc7cc  mulpd xmm9, xmm15
000070dabbddc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000070dabbddc7d7  ptest xmm6, xmm6
000070dabbddc7dc  jnz 0x000070DABBDE142C
000070dabbddc7e2  movaps xmm15, xmm11
000070dabbddc7e6  addpd xmm15, xmm12
000070dabbddc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000070dabbddc7f1  ptest xmm13, xmm13
000070dabbddc7f7  jnz 0x000070DABBDE1570
000070dabbddc7fd  movaps [r15+0x140], xmm15
000070dabbddc805  movaps xmm13, xmm10
000070dabbddc809  addpd xmm13, xmm14
000070dabbddc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000070dabbddc814  ptest xmm12, xmm12
000070dabbddc81a  jnz 0x000070DABBDE16B4
000070dabbddc820  movaps [r15+0x150], xmm13
000070dabbddc828  movaps xmm14, xmm1
000070dabbddc82c  addpd xmm14, xmm7
000070dabbddc831  vcmppd xmm12, xmm14, xmm14, 0x03
000070dabbddc837  ptest xmm12, xmm12
000070dabbddc83d  jnz 0x000070DABBDE17F8
000070dabbddc843  movaps [r15+0x160], xmm14
000070dabbddc84b  movaps xmm1, xmm8
000070dabbddc84f  addpd xmm1, xmm9
000070dabbddc854  vcmppd xmm12, xmm1, xmm1, 0x03
000070dabbddc859  ptest xmm12, xmm12
000070dabbddc85f  jnz 0x000070DABBDE193A
000070dabbddc865  movaps [r15+0x120], xmm1
000070dabbddc86d  movups [r13+r14*1], xmm15
000070dabbddc873  lea rax, [r14+0x10]
000070dabbddc877  movups [r13+rax*1], xmm13
000070dabbddc87d  lea rax, [r14+0x20]
000070dabbddc881  movups [r13+rax*1], xmm14
000070dabbddc887  lea rax, [r14+0x30]
000070dabbddc88b  movups [r13+rax*1], xmm1
000070dabbddc891  mov eax, [r15+0x108]
000070dabbddc898  sahf
000070dabbddc899  jnz 0x000070DABBDDC8CB
000070dabbddc89b  cmp dword ptr [r15+0x318], 0x00
000070dabbddc8a3  jz 0x000070DABBDDB900
000070dabbddc8a9  nop [rax+rax*1], ax
000070dabbddc8b2  nop [rax+rax*1], eax
000070dabbddc8ba  mov eax, 0x410444
000070dabbddc8bf  mov [r15+0x100], rax
000070dabbddc8c6  jmp 0x000070DABBBFE110
000070dabbddc8cb  cmp dword ptr [r15+0x318], 0x00
000070dabbddc8d3  jz 0x000070DABBDD57E0
000070dabbddc8d9  nop [rax+rax*1], ax
000070dabbddc8e2  nop [rax+rax*1], eax
000070dabbddc8ea  mov eax, 0x410278
000070dabbddc8ef  mov [r15+0x100], rax
000070dabbddc8f6  jmp 0x000070DABBBFE110
000070dabbddc8fb  int3
000070dabbddc8fc  call 0x000070DABBCE27E0
000070dabbddc901  jmp 0x000070DABBDDB9DF
000070dabbddc906  call 0x000070DABBCE1570
000070dabbddc90b  jmp 0x000070DABBDDB9E8
000070dabbddc910  call 0x000070DABBCE27E0
000070dabbddc915  jmp 0x000070DABBDDBA44
000070dabbddc91a  call 0x000070DABBCE1570
000070dabbddc91f  jmp 0x000070DABBDDBA4D
000070dabbddc924  call 0x000070DABBCE27E0
000070dabbddc929  jmp 0x000070DABBDDBA90
000070dabbddc92e  call 0x000070DABBCE1570
000070dabbddc933  jmp 0x000070DABBDDBA99
000070dabbddc938  call 0x000070DABBC0DC20
000070dabbddc93d  jmp 0x000070DABBDDBAD8
000070dabbddc942  call 0x000070DABBCD59C0
000070dabbddc947  jmp 0x000070DABBDDBAEB
000070dabbddc94c  call 0x000070DABBCE0E30
000070dabbddc951  jmp 0x000070DABBDDBB09
000070dabbddc956  call 0x000070DABBCDFBC0
000070dabbddc95b  jmp 0x000070DABBDDBB13
000070dabbddc960  call 0x000070DABBCDE950
000070dabbddc965  jmp 0x000070DABBDDBB1D
000070dabbddc96a  sub rsp, 0x08
000070dabbddc96e  push rax
000070dabbddc96f  push rcx
000070dabbddc970  push rdx
000070dabbddc971  push rdi
000070dabbddc972  push rsi
000070dabbddc973  push r8
000070dabbddc975  push r9
000070dabbddc977  push r10
000070dabbddc979  push r11
000070dabbddc97b  sub rsp, 0xF0
000070dabbddc982  vmovaps [rsp], xmm0
000070dabbddc987  vmovaps [rsp+0x10], xmm1
000070dabbddc98d  vmovaps [rsp+0x20], xmm2
000070dabbddc993  vmovaps [rsp+0x30], xmm3
000070dabbddc999  vmovaps [rsp+0x40], xmm4
000070dabbddc99f  vmovaps [rsp+0x50], xmm5
000070dabbddc9a5  vmovaps [rsp+0x60], xmm6
000070dabbddc9ab  vmovaps [rsp+0x70], xmm7
000070dabbddc9b1  vmovaps [rsp+0x80], xmm9
000070dabbddc9ba  vmovaps [rsp+0x90], xmm10
000070dabbddc9c3  vmovaps [rsp+0xA0], xmm11
000070dabbddc9cc  vmovaps [rsp+0xB0], xmm12
000070dabbddc9d5  vmovaps [rsp+0xC0], xmm13
000070dabbddc9de  vmovaps [rsp+0xD0], xmm14
000070dabbddc9e7  vmovaps [rsp+0xE0], xmm15
000070dabbddc9f0  sub rsp, 0x30
000070dabbddc9f4  movaps [rsp], xmm8
000070dabbddc9f9  movaps [rsp+0x10], xmm12
000070dabbddc9ff  movaps [rsp+0x20], xmm15
000070dabbddca05  lea rdi, [rsp]
000070dabbddca09  mov esi, 0x00
000070dabbddca0e  mov rax, 0x5C2CF7B6F530
000070dabbddca18  call rax
000070dabbddca1a  movaps xmm8, [rsp]
000070dabbddca1f  add rsp, 0x30
000070dabbddca23  vmovaps xmm0, [rsp]
000070dabbddca28  vmovaps xmm1, [rsp+0x10]
000070dabbddca2e  vmovaps xmm2, [rsp+0x20]
000070dabbddca34  vmovaps xmm3, [rsp+0x30]
000070dabbddca3a  vmovaps xmm4, [rsp+0x40]
000070dabbddca40  vmovaps xmm5, [rsp+0x50]
000070dabbddca46  vmovaps xmm6, [rsp+0x60]
000070dabbddca4c  vmovaps xmm7, [rsp+0x70]
000070dabbddca52  vmovaps xmm9, [rsp+0x80]
000070dabbddca5b  vmovaps xmm10, [rsp+0x90]
000070dabbddca64  vmovaps xmm11, [rsp+0xA0]
000070dabbddca6d  vmovaps xmm12, [rsp+0xB0]
000070dabbddca76  vmovaps xmm13, [rsp+0xC0]
000070dabbddca7f  vmovaps xmm14, [rsp+0xD0]
000070dabbddca88  vmovaps xmm15, [rsp+0xE0]
000070dabbddca91  add rsp, 0xF0
000070dabbddca98  pop r11
000070dabbddca9a  pop r10
000070dabbddca9c  pop r9
000070dabbddca9e  pop r8
000070dabbddcaa0  pop rsi
000070dabbddcaa1  pop rdi
000070dabbddcaa2  pop rdx
000070dabbddcaa3  pop rcx
000070dabbddcaa4  pop rax
000070dabbddcaa5  add rsp, 0x08
000070dabbddcaa9  jmp 0x000070DABBDDBB47
000070dabbddcaae  sub rsp, 0x08
000070dabbddcab2  push rax
000070dabbddcab3  push rcx
000070dabbddcab4  push rdx
000070dabbddcab5  push rdi
000070dabbddcab6  push rsi
000070dabbddcab7  push r8
000070dabbddcab9  push r9
000070dabbddcabb  push r10
000070dabbddcabd  push r11
000070dabbddcabf  sub rsp, 0xF0
000070dabbddcac6  vmovaps [rsp], xmm0
000070dabbddcacb  vmovaps [rsp+0x10], xmm1
000070dabbddcad1  vmovaps [rsp+0x20], xmm2
000070dabbddcad7  vmovaps [rsp+0x30], xmm3
000070dabbddcadd  vmovaps [rsp+0x40], xmm4
000070dabbddcae3  vmovaps [rsp+0x50], xmm5
000070dabbddcae9  vmovaps [rsp+0x60], xmm6
000070dabbddcaef  vmovaps [rsp+0x70], xmm8
000070dabbddcaf5  vmovaps [rsp+0x80], xmm9
000070dabbddcafe  vmovaps [rsp+0x90], xmm10
000070dabbddcb07  vmovaps [rsp+0xA0], xmm11
000070dabbddcb10  vmovaps [rsp+0xB0], xmm12
000070dabbddcb19  vmovaps [rsp+0xC0], xmm13
000070dabbddcb22  vmovaps [rsp+0xD0], xmm14
000070dabbddcb2b  vmovaps [rsp+0xE0], xmm15
000070dabbddcb34  sub rsp, 0x30
000070dabbddcb38  movaps [rsp], xmm7
000070dabbddcb3c  movaps [rsp+0x10], xmm9
000070dabbddcb42  movaps [rsp+0x20], xmm15
000070dabbddcb48  lea rdi, [rsp]
000070dabbddcb4c  mov esi, 0x00
000070dabbddcb51  mov rax, 0x5C2CF7B6F530
000070dabbddcb5b  call rax
000070dabbddcb5d  movaps xmm7, [rsp]
000070dabbddcb61  add rsp, 0x30
000070dabbddcb65  vmovaps xmm0, [rsp]
000070dabbddcb6a  vmovaps xmm1, [rsp+0x10]
000070dabbddcb70  vmovaps xmm2, [rsp+0x20]
000070dabbddcb76  vmovaps xmm3, [rsp+0x30]
000070dabbddcb7c  vmovaps xmm4, [rsp+0x40]
000070dabbddcb82  vmovaps xmm5, [rsp+0x50]
000070dabbddcb88  vmovaps xmm6, [rsp+0x60]
000070dabbddcb8e  vmovaps xmm8, [rsp+0x70]
000070dabbddcb94  vmovaps xmm9, [rsp+0x80]
000070dabbddcb9d  vmovaps xmm10, [rsp+0x90]
000070dabbddcba6  vmovaps xmm11, [rsp+0xA0]
000070dabbddcbaf  vmovaps xmm12, [rsp+0xB0]
000070dabbddcbb8  vmovaps xmm13, [rsp+0xC0]
000070dabbddcbc1  vmovaps xmm14, [rsp+0xD0]
000070dabbddcbca  vmovaps xmm15, [rsp+0xE0]
000070dabbddcbd3  add rsp, 0xF0
000070dabbddcbda  pop r11
000070dabbddcbdc  pop r10
000070dabbddcbde  pop r9
000070dabbddcbe0  pop r8
000070dabbddcbe2  pop rsi
000070dabbddcbe3  pop rdi
000070dabbddcbe4  pop rdx
000070dabbddcbe5  pop rcx
000070dabbddcbe6  pop rax
000070dabbddcbe7  add rsp, 0x08
000070dabbddcbeb  jmp 0x000070DABBDDBB75
000070dabbddcbf0  sub rsp, 0x08
000070dabbddcbf4  push rax
000070dabbddcbf5  push rcx
000070dabbddcbf6  push rdx
000070dabbddcbf7  push rdi
000070dabbddcbf8  push rsi
000070dabbddcbf9  push r8
000070dabbddcbfb  push r9
000070dabbddcbfd  push r10
000070dabbddcbff  push r11
000070dabbddcc01  sub rsp, 0xF0
000070dabbddcc08  vmovaps [rsp], xmm0
000070dabbddcc0d  vmovaps [rsp+0x10], xmm1
000070dabbddcc13  vmovaps [rsp+0x20], xmm2
000070dabbddcc19  vmovaps [rsp+0x30], xmm3
000070dabbddcc1f  vmovaps [rsp+0x40], xmm4
000070dabbddcc25  vmovaps [rsp+0x50], xmm5
000070dabbddcc2b  vmovaps [rsp+0x60], xmm6
000070dabbddcc31  vmovaps [rsp+0x70], xmm7
000070dabbddcc37  vmovaps [rsp+0x80], xmm8
000070dabbddcc40  vmovaps [rsp+0x90], xmm10
000070dabbddcc49  vmovaps [rsp+0xA0], xmm11
000070dabbddcc52  vmovaps [rsp+0xB0], xmm12
000070dabbddcc5b  vmovaps [rsp+0xC0], xmm13
000070dabbddcc64  vmovaps [rsp+0xD0], xmm14
000070dabbddcc6d  vmovaps [rsp+0xE0], xmm15
000070dabbddcc76  sub rsp, 0x30
000070dabbddcc7a  movaps [rsp], xmm9
000070dabbddcc7f  movaps [rsp+0x10], xmm12
000070dabbddcc85  movaps [rsp+0x20], xmm10
000070dabbddcc8b  lea rdi, [rsp]
000070dabbddcc8f  mov esi, 0x00
000070dabbddcc94  mov rax, 0x5C2CF7B6F530
000070dabbddcc9e  call rax
000070dabbddcca0  movaps xmm9, [rsp]
000070dabbddcca5  add rsp, 0x30
000070dabbddcca9  vmovaps xmm0, [rsp]
000070dabbddccae  vmovaps xmm1, [rsp+0x10]
000070dabbddccb4  vmovaps xmm2, [rsp+0x20]
000070dabbddccba  vmovaps xmm3, [rsp+0x30]
000070dabbddccc0  vmovaps xmm4, [rsp+0x40]
000070dabbddccc6  vmovaps xmm5, [rsp+0x50]
000070dabbddcccc  vmovaps xmm6, [rsp+0x60]
000070dabbddccd2  vmovaps xmm7, [rsp+0x70]
000070dabbddccd8  vmovaps xmm8, [rsp+0x80]
000070dabbddcce1  vmovaps xmm10, [rsp+0x90]
000070dabbddccea  vmovaps xmm11, [rsp+0xA0]
000070dabbddccf3  vmovaps xmm12, [rsp+0xB0]
000070dabbddccfc  vmovaps xmm13, [rsp+0xC0]
000070dabbddcd05  vmovaps xmm14, [rsp+0xD0]
000070dabbddcd0e  vmovaps xmm15, [rsp+0xE0]
000070dabbddcd17  add rsp, 0xF0
000070dabbddcd1e  pop r11
000070dabbddcd20  pop r10
000070dabbddcd22  pop r9
000070dabbddcd24  pop r8
000070dabbddcd26  pop rsi
000070dabbddcd27  pop rdi
000070dabbddcd28  pop rdx
000070dabbddcd29  pop rcx
000070dabbddcd2a  pop rax
000070dabbddcd2b  add rsp, 0x08
000070dabbddcd2f  jmp 0x000070DABBDDBB99
000070dabbddcd34  sub rsp, 0x08
000070dabbddcd38  push rax
000070dabbddcd39  push rcx
000070dabbddcd3a  push rdx
000070dabbddcd3b  push rdi
000070dabbddcd3c  push rsi
000070dabbddcd3d  push r8
000070dabbddcd3f  push r9
000070dabbddcd41  push r10
000070dabbddcd43  push r11
000070dabbddcd45  sub rsp, 0xF0
000070dabbddcd4c  vmovaps [rsp], xmm0
000070dabbddcd51  vmovaps [rsp+0x10], xmm1
000070dabbddcd57  vmovaps [rsp+0x20], xmm2
000070dabbddcd5d  vmovaps [rsp+0x30], xmm3
000070dabbddcd63  vmovaps [rsp+0x40], xmm4
000070dabbddcd69  vmovaps [rsp+0x50], xmm5
000070dabbddcd6f  vmovaps [rsp+0x60], xmm6
000070dabbddcd75  vmovaps [rsp+0x70], xmm7
000070dabbddcd7b  vmovaps [rsp+0x80], xmm8
000070dabbddcd84  vmovaps [rsp+0x90], xmm9
000070dabbddcd8d  vmovaps [rsp+0xA0], xmm11
000070dabbddcd96  vmovaps [rsp+0xB0], xmm12
000070dabbddcd9f  vmovaps [rsp+0xC0], xmm13
000070dabbddcda8  vmovaps [rsp+0xD0], xmm14
000070dabbddcdb1  vmovaps [rsp+0xE0], xmm15
000070dabbddcdba  sub rsp, 0x30
000070dabbddcdbe  movaps [rsp], xmm10
000070dabbddcdc3  movaps [rsp+0x10], xmm12
000070dabbddcdc9  movaps [rsp+0x20], xmm11
000070dabbddcdcf  lea rdi, [rsp]
000070dabbddcdd3  mov esi, 0x00
000070dabbddcdd8  mov rax, 0x5C2CF7B6F530
000070dabbddcde2  call rax
000070dabbddcde4  movaps xmm10, [rsp]
000070dabbddcde9  add rsp, 0x30
000070dabbddcded  vmovaps xmm0, [rsp]
000070dabbddcdf2  vmovaps xmm1, [rsp+0x10]
000070dabbddcdf8  vmovaps xmm2, [rsp+0x20]
000070dabbddcdfe  vmovaps xmm3, [rsp+0x30]
000070dabbddce04  vmovaps xmm4, [rsp+0x40]
000070dabbddce0a  vmovaps xmm5, [rsp+0x50]
000070dabbddce10  vmovaps xmm6, [rsp+0x60]
000070dabbddce16  vmovaps xmm7, [rsp+0x70]
000070dabbddce1c  vmovaps xmm8, [rsp+0x80]
000070dabbddce25  vmovaps xmm9, [rsp+0x90]
000070dabbddce2e  vmovaps xmm11, [rsp+0xA0]
000070dabbddce37  vmovaps xmm12, [rsp+0xB0]
000070dabbddce40  vmovaps xmm13, [rsp+0xC0]
000070dabbddce49  vmovaps xmm14, [rsp+0xD0]
000070dabbddce52  vmovaps xmm15, [rsp+0xE0]
000070dabbddce5b  add rsp, 0xF0
000070dabbddce62  pop r11
000070dabbddce64  pop r10
000070dabbddce66  pop r9
000070dabbddce68  pop r8
000070dabbddce6a  pop rsi
000070dabbddce6b  pop rdi
000070dabbddce6c  pop rdx
000070dabbddce6d  pop rcx
000070dabbddce6e  pop rax
000070dabbddce6f  add rsp, 0x08
000070dabbddce73  jmp 0x000070DABBDDBBB3
000070dabbddce78  sub rsp, 0x08
000070dabbddce7c  push rax
000070dabbddce7d  push rcx
000070dabbddce7e  push rdx
000070dabbddce7f  push rdi
000070dabbddce80  push rsi
000070dabbddce81  push r8
000070dabbddce83  push r9
000070dabbddce85  push r10
000070dabbddce87  push r11
000070dabbddce89  sub rsp, 0xF0
000070dabbddce90  vmovaps [rsp], xmm0
000070dabbddce95  vmovaps [rsp+0x10], xmm1
000070dabbddce9b  vmovaps [rsp+0x20], xmm2
000070dabbddcea1  vmovaps [rsp+0x30], xmm3
000070dabbddcea7  vmovaps [rsp+0x40], xmm4
000070dabbddcead  vmovaps [rsp+0x50], xmm5
000070dabbddceb3  vmovaps [rsp+0x60], xmm7
000070dabbddceb9  vmovaps [rsp+0x70], xmm8
000070dabbddcebf  vmovaps [rsp+0x80], xmm9
000070dabbddcec8  vmovaps [rsp+0x90], xmm10
000070dabbddced1  vmovaps [rsp+0xA0], xmm11
000070dabbddceda  vmovaps [rsp+0xB0], xmm12
000070dabbddcee3  vmovaps [rsp+0xC0], xmm13
000070dabbddceec  vmovaps [rsp+0xD0], xmm14
000070dabbddcef5  vmovaps [rsp+0xE0], xmm15
000070dabbddcefe  sub rsp, 0x30
000070dabbddcf02  movaps [rsp], xmm6
000070dabbddcf06  movaps [rsp+0x10], xmm12
000070dabbddcf0c  movaps [rsp+0x20], xmm11
000070dabbddcf12  lea rdi, [rsp]
000070dabbddcf16  mov esi, 0x00
000070dabbddcf1b  mov rax, 0x5C2CF7B6F530
000070dabbddcf25  call rax
000070dabbddcf27  movaps xmm6, [rsp]
000070dabbddcf2b  add rsp, 0x30
000070dabbddcf2f  vmovaps xmm0, [rsp]
000070dabbddcf34  vmovaps xmm1, [rsp+0x10]
000070dabbddcf3a  vmovaps xmm2, [rsp+0x20]
000070dabbddcf40  vmovaps xmm3, [rsp+0x30]
000070dabbddcf46  vmovaps xmm4, [rsp+0x40]
000070dabbddcf4c  vmovaps xmm5, [rsp+0x50]
000070dabbddcf52  vmovaps xmm7, [rsp+0x60]
000070dabbddcf58  vmovaps xmm8, [rsp+0x70]
000070dabbddcf5e  vmovaps xmm9, [rsp+0x80]
000070dabbddcf67  vmovaps xmm10, [rsp+0x90]
000070dabbddcf70  vmovaps xmm11, [rsp+0xA0]
000070dabbddcf79  vmovaps xmm12, [rsp+0xB0]
000070dabbddcf82  vmovaps xmm13, [rsp+0xC0]
000070dabbddcf8b  vmovaps xmm14, [rsp+0xD0]
000070dabbddcf94  vmovaps xmm15, [rsp+0xE0]
000070dabbddcf9d  add rsp, 0xF0
000070dabbddcfa4  pop r11
000070dabbddcfa6  pop r10
000070dabbddcfa8  pop r9
000070dabbddcfaa  pop r8
000070dabbddcfac  pop rsi
000070dabbddcfad  pop rdi
000070dabbddcfae  pop rdx
000070dabbddcfaf  pop rcx
000070dabbddcfb0  pop rax
000070dabbddcfb1  add rsp, 0x08
000070dabbddcfb5  jmp 0x000070DABBDDBBD4
000070dabbddcfba  sub rsp, 0x08
000070dabbddcfbe  push rax
000070dabbddcfbf  push rcx
000070dabbddcfc0  push rdx
000070dabbddcfc1  push rdi
000070dabbddcfc2  push rsi
000070dabbddcfc3  push r8
000070dabbddcfc5  push r9
000070dabbddcfc7  push r10
000070dabbddcfc9  push r11
000070dabbddcfcb  sub rsp, 0xF0
000070dabbddcfd2  vmovaps [rsp], xmm0
000070dabbddcfd7  vmovaps [rsp+0x10], xmm1
000070dabbddcfdd  vmovaps [rsp+0x20], xmm2
000070dabbddcfe3  vmovaps [rsp+0x30], xmm4
000070dabbddcfe9  vmovaps [rsp+0x40], xmm5
000070dabbddcfef  vmovaps [rsp+0x50], xmm6
000070dabbddcff5  vmovaps [rsp+0x60], xmm7
000070dabbddcffb  vmovaps [rsp+0x70], xmm8
000070dabbddd001  vmovaps [rsp+0x80], xmm9
000070dabbddd00a  vmovaps [rsp+0x90], xmm10
000070dabbddd013  vmovaps [rsp+0xA0], xmm11
000070dabbddd01c  vmovaps [rsp+0xB0], xmm12
000070dabbddd025  vmovaps [rsp+0xC0], xmm13
000070dabbddd02e  vmovaps [rsp+0xD0], xmm14
000070dabbddd037  vmovaps [rsp+0xE0], xmm15
000070dabbddd040  sub rsp, 0x30
000070dabbddd044  movaps [rsp], xmm3
000070dabbddd048  movaps [rsp+0x10], xmm5
000070dabbddd04d  movaps [rsp+0x20], xmm4
000070dabbddd052  lea rdi, [rsp]
000070dabbddd056  mov esi, 0x00
000070dabbddd05b  mov rax, 0x5C2CF7B6F530
000070dabbddd065  call rax
000070dabbddd067  movaps xmm3, [rsp]
000070dabbddd06b  add rsp, 0x30
000070dabbddd06f  vmovaps xmm0, [rsp]
000070dabbddd074  vmovaps xmm1, [rsp+0x10]
000070dabbddd07a  vmovaps xmm2, [rsp+0x20]
000070dabbddd080  vmovaps xmm4, [rsp+0x30]
000070dabbddd086  vmovaps xmm5, [rsp+0x40]
000070dabbddd08c  vmovaps xmm6, [rsp+0x50]
000070dabbddd092  vmovaps xmm7, [rsp+0x60]
000070dabbddd098  vmovaps xmm8, [rsp+0x70]
000070dabbddd09e  vmovaps xmm9, [rsp+0x80]
000070dabbddd0a7  vmovaps xmm10, [rsp+0x90]
000070dabbddd0b0  vmovaps xmm11, [rsp+0xA0]
000070dabbddd0b9  vmovaps xmm12, [rsp+0xB0]
000070dabbddd0c2  vmovaps xmm13, [rsp+0xC0]
000070dabbddd0cb  vmovaps xmm14, [rsp+0xD0]
000070dabbddd0d4  vmovaps xmm15, [rsp+0xE0]
000070dabbddd0dd  add rsp, 0xF0
000070dabbddd0e4  pop r11
000070dabbddd0e6  pop r10
000070dabbddd0e8  pop r9
000070dabbddd0ea  pop r8
000070dabbddd0ec  pop rsi
000070dabbddd0ed  pop rdi
000070dabbddd0ee  pop rdx
000070dabbddd0ef  pop rcx
000070dabbddd0f0  pop rax
000070dabbddd0f1  add rsp, 0x08
000070dabbddd0f5  jmp 0x000070DABBDDBC35
000070dabbddd0fa  sub rsp, 0x08
000070dabbddd0fe  push rax
000070dabbddd0ff  push rcx
000070dabbddd100  push rdx
000070dabbddd101  push rdi
000070dabbddd102  push rsi
000070dabbddd103  push r8
000070dabbddd105  push r9
000070dabbddd107  push r10
000070dabbddd109  push r11
000070dabbddd10b  sub rsp, 0xF0
000070dabbddd112  vmovaps [rsp], xmm0
000070dabbddd117  vmovaps [rsp+0x10], xmm1
000070dabbddd11d  vmovaps [rsp+0x20], xmm2
000070dabbddd123  vmovaps [rsp+0x30], xmm3
000070dabbddd129  vmovaps [rsp+0x40], xmm4
000070dabbddd12f  vmovaps [rsp+0x50], xmm6
000070dabbddd135  vmovaps [rsp+0x60], xmm7
000070dabbddd13b  vmovaps [rsp+0x70], xmm8
000070dabbddd141  vmovaps [rsp+0x80], xmm9
000070dabbddd14a  vmovaps [rsp+0x90], xmm10
000070dabbddd153  vmovaps [rsp+0xA0], xmm11
000070dabbddd15c  vmovaps [rsp+0xB0], xmm12
000070dabbddd165  vmovaps [rsp+0xC0], xmm13
000070dabbddd16e  vmovaps [rsp+0xD0], xmm14
000070dabbddd177  vmovaps [rsp+0xE0], xmm15
000070dabbddd180  sub rsp, 0x30
000070dabbddd184  movaps [rsp], xmm5
000070dabbddd188  movaps [rsp+0x10], xmm8
000070dabbddd18e  movaps [rsp+0x20], xmm15
000070dabbddd194  lea rdi, [rsp]
000070dabbddd198  mov esi, 0x00
000070dabbddd19d  mov rax, 0x5C2CF7B6F530
000070dabbddd1a7  call rax
000070dabbddd1a9  movaps xmm5, [rsp]
000070dabbddd1ad  add rsp, 0x30
000070dabbddd1b1  vmovaps xmm0, [rsp]
000070dabbddd1b6  vmovaps xmm1, [rsp+0x10]
000070dabbddd1bc  vmovaps xmm2, [rsp+0x20]
000070dabbddd1c2  vmovaps xmm3, [rsp+0x30]
000070dabbddd1c8  vmovaps xmm4, [rsp+0x40]
000070dabbddd1ce  vmovaps xmm6, [rsp+0x50]
000070dabbddd1d4  vmovaps xmm7, [rsp+0x60]
000070dabbddd1da  vmovaps xmm8, [rsp+0x70]
000070dabbddd1e0  vmovaps xmm9, [rsp+0x80]
000070dabbddd1e9  vmovaps xmm10, [rsp+0x90]
000070dabbddd1f2  vmovaps xmm11, [rsp+0xA0]
000070dabbddd1fb  vmovaps xmm12, [rsp+0xB0]
000070dabbddd204  vmovaps xmm13, [rsp+0xC0]
000070dabbddd20d  vmovaps xmm14, [rsp+0xD0]
000070dabbddd216  vmovaps xmm15, [rsp+0xE0]
000070dabbddd21f  add rsp, 0xF0
000070dabbddd226  pop r11
000070dabbddd228  pop r10
000070dabbddd22a  pop r9
000070dabbddd22c  pop r8
000070dabbddd22e  pop rsi
000070dabbddd22f  pop rdi
000070dabbddd230  pop rdx
000070dabbddd231  pop rcx
000070dabbddd232  pop rax
000070dabbddd233  add rsp, 0x08
000070dabbddd237  jmp 0x000070DABBDDBC73
000070dabbddd23c  sub rsp, 0x08
000070dabbddd240  push rax
000070dabbddd241  push rcx
000070dabbddd242  push rdx
000070dabbddd243  push rdi
000070dabbddd244  push rsi
000070dabbddd245  push r8
000070dabbddd247  push r9
000070dabbddd249  push r10
000070dabbddd24b  push r11
000070dabbddd24d  sub rsp, 0xF0
000070dabbddd254  vmovaps [rsp], xmm0
000070dabbddd259  vmovaps [rsp+0x10], xmm1
000070dabbddd25f  vmovaps [rsp+0x20], xmm2
000070dabbddd265  vmovaps [rsp+0x30], xmm3
000070dabbddd26b  vmovaps [rsp+0x40], xmm5
000070dabbddd271  vmovaps [rsp+0x50], xmm6
000070dabbddd277  vmovaps [rsp+0x60], xmm7
000070dabbddd27d  vmovaps [rsp+0x70], xmm8
000070dabbddd283  vmovaps [rsp+0x80], xmm9
000070dabbddd28c  vmovaps [rsp+0x90], xmm10
000070dabbddd295  vmovaps [rsp+0xA0], xmm11
000070dabbddd29e  vmovaps [rsp+0xB0], xmm12
000070dabbddd2a7  vmovaps [rsp+0xC0], xmm13
000070dabbddd2b0  vmovaps [rsp+0xD0], xmm14
000070dabbddd2b9  vmovaps [rsp+0xE0], xmm15
000070dabbddd2c2  sub rsp, 0x30
000070dabbddd2c6  movaps [rsp], xmm4
000070dabbddd2ca  movaps [rsp+0x10], xmm9
000070dabbddd2d0  movaps [rsp+0x20], xmm8
000070dabbddd2d6  lea rdi, [rsp]
000070dabbddd2da  mov esi, 0x00
000070dabbddd2df  mov rax, 0x5C2CF7B6F530
000070dabbddd2e9  call rax
000070dabbddd2eb  movaps xmm4, [rsp]
000070dabbddd2ef  add rsp, 0x30
000070dabbddd2f3  vmovaps xmm0, [rsp]
000070dabbddd2f8  vmovaps xmm1, [rsp+0x10]
000070dabbddd2fe  vmovaps xmm2, [rsp+0x20]
000070dabbddd304  vmovaps xmm3, [rsp+0x30]
000070dabbddd30a  vmovaps xmm5, [rsp+0x40]
000070dabbddd310  vmovaps xmm6, [rsp+0x50]
000070dabbddd316  vmovaps xmm7, [rsp+0x60]
000070dabbddd31c  vmovaps xmm8, [rsp+0x70]
000070dabbddd322  vmovaps xmm9, [rsp+0x80]
000070dabbddd32b  vmovaps xmm10, [rsp+0x90]
000070dabbddd334  vmovaps xmm11, [rsp+0xA0]
000070dabbddd33d  vmovaps xmm12, [rsp+0xB0]
000070dabbddd346  vmovaps xmm13, [rsp+0xC0]
000070dabbddd34f  vmovaps xmm14, [rsp+0xD0]
000070dabbddd358  vmovaps xmm15, [rsp+0xE0]
000070dabbddd361  add rsp, 0xF0
000070dabbddd368  pop r11
000070dabbddd36a  pop r10
000070dabbddd36c  pop r9
000070dabbddd36e  pop r8
000070dabbddd370  pop rsi
000070dabbddd371  pop rdi
000070dabbddd372  pop rdx
000070dabbddd373  pop rcx
000070dabbddd374  pop rax
000070dabbddd375  add rsp, 0x08
000070dabbddd379  jmp 0x000070DABBDDBC94
000070dabbddd37e  sub rsp, 0x08
000070dabbddd382  push rax
000070dabbddd383  push rcx
000070dabbddd384  push rdx
000070dabbddd385  push rdi
000070dabbddd386  push rsi
000070dabbddd387  push r8
000070dabbddd389  push r9
000070dabbddd38b  push r10
000070dabbddd38d  push r11
000070dabbddd38f  sub rsp, 0xF0
000070dabbddd396  vmovaps [rsp], xmm0
000070dabbddd39b  vmovaps [rsp+0x10], xmm1
000070dabbddd3a1  vmovaps [rsp+0x20], xmm2
000070dabbddd3a7  vmovaps [rsp+0x30], xmm3
000070dabbddd3ad  vmovaps [rsp+0x40], xmm4
000070dabbddd3b3  vmovaps [rsp+0x50], xmm5
000070dabbddd3b9  vmovaps [rsp+0x60], xmm6
000070dabbddd3bf  vmovaps [rsp+0x70], xmm7
000070dabbddd3c5  vmovaps [rsp+0x80], xmm8
000070dabbddd3ce  vmovaps [rsp+0x90], xmm10
000070dabbddd3d7  vmovaps [rsp+0xA0], xmm11
000070dabbddd3e0  vmovaps [rsp+0xB0], xmm12
000070dabbddd3e9  vmovaps [rsp+0xC0], xmm13
000070dabbddd3f2  vmovaps [rsp+0xD0], xmm14
000070dabbddd3fb  vmovaps [rsp+0xE0], xmm15
000070dabbddd404  sub rsp, 0x30
000070dabbddd408  movaps [rsp], xmm9
000070dabbddd40d  movaps [rsp+0x10], xmm10
000070dabbddd413  movaps [rsp+0x20], xmm8
000070dabbddd419  lea rdi, [rsp]
000070dabbddd41d  mov esi, 0x00
000070dabbddd422  mov rax, 0x5C2CF7B6F530
000070dabbddd42c  call rax
000070dabbddd42e  movaps xmm9, [rsp]
000070dabbddd433  add rsp, 0x30
000070dabbddd437  vmovaps xmm0, [rsp]
000070dabbddd43c  vmovaps xmm1, [rsp+0x10]
000070dabbddd442  vmovaps xmm2, [rsp+0x20]
000070dabbddd448  vmovaps xmm3, [rsp+0x30]
000070dabbddd44e  vmovaps xmm4, [rsp+0x40]
000070dabbddd454  vmovaps xmm5, [rsp+0x50]
000070dabbddd45a  vmovaps xmm6, [rsp+0x60]
000070dabbddd460  vmovaps xmm7, [rsp+0x70]
000070dabbddd466  vmovaps xmm8, [rsp+0x80]
000070dabbddd46f  vmovaps xmm10, [rsp+0x90]
000070dabbddd478  vmovaps xmm11, [rsp+0xA0]
000070dabbddd481  vmovaps xmm12, [rsp+0xB0]
000070dabbddd48a  vmovaps xmm13, [rsp+0xC0]
000070dabbddd493  vmovaps xmm14, [rsp+0xD0]
000070dabbddd49c  vmovaps xmm15, [rsp+0xE0]
000070dabbddd4a5  add rsp, 0xF0
000070dabbddd4ac  pop r11
000070dabbddd4ae  pop r10
000070dabbddd4b0  pop r9
000070dabbddd4b2  pop r8
000070dabbddd4b4  pop rsi
000070dabbddd4b5  pop rdi
000070dabbddd4b6  pop rdx
000070dabbddd4b7  pop rcx
000070dabbddd4b8  pop rax
000070dabbddd4b9  add rsp, 0x08
000070dabbddd4bd  jmp 0x000070DABBDDBCAE
000070dabbddd4c2  call 0x000070DABBCB52F0
000070dabbddd4c7  jmp 0x000070DABBDDBDC8
000070dabbddd4cc  call 0x000070DABBCB52F0
000070dabbddd4d1  jmp 0x000070DABBDDBDDE
000070dabbddd4d6  sub rsp, 0x08
000070dabbddd4da  push rax
000070dabbddd4db  push rcx
000070dabbddd4dc  push rdx
000070dabbddd4dd  push rdi
000070dabbddd4de  push rsi
000070dabbddd4df  push r8
000070dabbddd4e1  push r9
000070dabbddd4e3  push r10
000070dabbddd4e5  push r11
000070dabbddd4e7  sub rsp, 0xF0
000070dabbddd4ee  vmovaps [rsp], xmm0
000070dabbddd4f3  vmovaps [rsp+0x10], xmm2
000070dabbddd4f9  vmovaps [rsp+0x20], xmm3
000070dabbddd4ff  vmovaps [rsp+0x30], xmm4
000070dabbddd505  vmovaps [rsp+0x40], xmm5
000070dabbddd50b  vmovaps [rsp+0x50], xmm6
000070dabbddd511  vmovaps [rsp+0x60], xmm7
000070dabbddd517  vmovaps [rsp+0x70], xmm8
000070dabbddd51d  vmovaps [rsp+0x80], xmm9
000070dabbddd526  vmovaps [rsp+0x90], xmm10
000070dabbddd52f  vmovaps [rsp+0xA0], xmm11
000070dabbddd538  vmovaps [rsp+0xB0], xmm12
000070dabbddd541  vmovaps [rsp+0xC0], xmm13
000070dabbddd54a  vmovaps [rsp+0xD0], xmm14
000070dabbddd553  vmovaps [rsp+0xE0], xmm15
000070dabbddd55c  sub rsp, 0x30
000070dabbddd560  movaps [rsp], xmm1
000070dabbddd564  movaps [rsp+0x10], xmm6
000070dabbddd569  movaps [rsp+0x20], xmm15
000070dabbddd56f  lea rdi, [rsp]
000070dabbddd573  mov esi, 0x00
000070dabbddd578  mov rax, 0x5C2CF7B6F530
000070dabbddd582  call rax
000070dabbddd584  movaps xmm1, [rsp]
000070dabbddd588  add rsp, 0x30
000070dabbddd58c  vmovaps xmm0, [rsp]
000070dabbddd591  vmovaps xmm2, [rsp+0x10]
000070dabbddd597  vmovaps xmm3, [rsp+0x20]
000070dabbddd59d  vmovaps xmm4, [rsp+0x30]
000070dabbddd5a3  vmovaps xmm5, [rsp+0x40]
000070dabbddd5a9  vmovaps xmm6, [rsp+0x50]
000070dabbddd5af  vmovaps xmm7, [rsp+0x60]
000070dabbddd5b5  vmovaps xmm8, [rsp+0x70]
000070dabbddd5bb  vmovaps xmm9, [rsp+0x80]
000070dabbddd5c4  vmovaps xmm10, [rsp+0x90]
000070dabbddd5cd  vmovaps xmm11, [rsp+0xA0]
000070dabbddd5d6  vmovaps xmm12, [rsp+0xB0]
000070dabbddd5df  vmovaps xmm13, [rsp+0xC0]
000070dabbddd5e8  vmovaps xmm14, [rsp+0xD0]
000070dabbddd5f1  vmovaps xmm15, [rsp+0xE0]
000070dabbddd5fa  add rsp, 0xF0
000070dabbddd601  pop r11
000070dabbddd603  pop r10
000070dabbddd605  pop r9
000070dabbddd607  pop r8
000070dabbddd609  pop rsi
000070dabbddd60a  pop rdi
000070dabbddd60b  pop rdx
000070dabbddd60c  pop rcx
000070dabbddd60d  pop rax
000070dabbddd60e  add rsp, 0x08
000070dabbddd612  jmp 0x000070DABBDDBE1B
000070dabbddd617  call 0x000070DABBCC4620
000070dabbddd61c  jmp 0x000070DABBDDBE28
000070dabbddd621  sub rsp, 0x08
000070dabbddd625  push rax
000070dabbddd626  push rcx
000070dabbddd627  push rdx
000070dabbddd628  push rdi
000070dabbddd629  push rsi
000070dabbddd62a  push r8
000070dabbddd62c  push r9
000070dabbddd62e  push r10
000070dabbddd630  push r11
000070dabbddd632  sub rsp, 0xF0
000070dabbddd639  vmovaps [rsp], xmm0
000070dabbddd63e  vmovaps [rsp+0x10], xmm1
000070dabbddd644  vmovaps [rsp+0x20], xmm2
000070dabbddd64a  vmovaps [rsp+0x30], xmm3
000070dabbddd650  vmovaps [rsp+0x40], xmm4
000070dabbddd656  vmovaps [rsp+0x50], xmm5
000070dabbddd65c  vmovaps [rsp+0x60], xmm6
000070dabbddd662  vmovaps [rsp+0x70], xmm7
000070dabbddd668  vmovaps [rsp+0x80], xmm8
000070dabbddd671  vmovaps [rsp+0x90], xmm9
000070dabbddd67a  vmovaps [rsp+0xA0], xmm10
000070dabbddd683  vmovaps [rsp+0xB0], xmm11
000070dabbddd68c  vmovaps [rsp+0xC0], xmm12
000070dabbddd695  vmovaps [rsp+0xD0], xmm13
000070dabbddd69e  vmovaps [rsp+0xE0], xmm15
000070dabbddd6a7  sub rsp, 0x30
000070dabbddd6ab  movaps [rsp], xmm14
000070dabbddd6b0  movaps [rsp+0x10], xmm4
000070dabbddd6b5  movaps [rsp+0x20], xmm3
000070dabbddd6ba  lea rdi, [rsp]
000070dabbddd6be  mov esi, 0x00
000070dabbddd6c3  mov rax, 0x5C2CF7B6F530
000070dabbddd6cd  call rax
000070dabbddd6cf  movaps xmm14, [rsp]
000070dabbddd6d4  add rsp, 0x30
000070dabbddd6d8  vmovaps xmm0, [rsp]
000070dabbddd6dd  vmovaps xmm1, [rsp+0x10]
000070dabbddd6e3  vmovaps xmm2, [rsp+0x20]
000070dabbddd6e9  vmovaps xmm3, [rsp+0x30]
000070dabbddd6ef  vmovaps xmm4, [rsp+0x40]
000070dabbddd6f5  vmovaps xmm5, [rsp+0x50]
000070dabbddd6fb  vmovaps xmm6, [rsp+0x60]
000070dabbddd701  vmovaps xmm7, [rsp+0x70]
000070dabbddd707  vmovaps xmm8, [rsp+0x80]
000070dabbddd710  vmovaps xmm9, [rsp+0x90]
000070dabbddd719  vmovaps xmm10, [rsp+0xA0]
000070dabbddd722  vmovaps xmm11, [rsp+0xB0]
000070dabbddd72b  vmovaps xmm12, [rsp+0xC0]
000070dabbddd734  vmovaps xmm13, [rsp+0xD0]
000070dabbddd73d  vmovaps xmm15, [rsp+0xE0]
000070dabbddd746  add rsp, 0xF0
000070dabbddd74d  pop r11
000070dabbddd74f  pop r10
000070dabbddd751  pop r9
000070dabbddd753  pop r8
000070dabbddd755  pop rsi
000070dabbddd756  pop rdi
000070dabbddd757  pop rdx
000070dabbddd758  pop rcx
000070dabbddd759  pop rax
000070dabbddd75a  add rsp, 0x08
000070dabbddd75e  jmp 0x000070DABBDDBE42
000070dabbddd763  sub rsp, 0x08
000070dabbddd767  push rax
000070dabbddd768  push rcx
000070dabbddd769  push rdx
000070dabbddd76a  push rdi
000070dabbddd76b  push rsi
000070dabbddd76c  push r8
000070dabbddd76e  push r9
000070dabbddd770  push r10
000070dabbddd772  push r11
000070dabbddd774  sub rsp, 0xF0
000070dabbddd77b  vmovaps [rsp], xmm0
000070dabbddd780  vmovaps [rsp+0x10], xmm1
000070dabbddd786  vmovaps [rsp+0x20], xmm2
000070dabbddd78c  vmovaps [rsp+0x30], xmm3
000070dabbddd792  vmovaps [rsp+0x40], xmm4
000070dabbddd798  vmovaps [rsp+0x50], xmm5
000070dabbddd79e  vmovaps [rsp+0x60], xmm7
000070dabbddd7a4  vmovaps [rsp+0x70], xmm8
000070dabbddd7aa  vmovaps [rsp+0x80], xmm9
000070dabbddd7b3  vmovaps [rsp+0x90], xmm10
000070dabbddd7bc  vmovaps [rsp+0xA0], xmm11
000070dabbddd7c5  vmovaps [rsp+0xB0], xmm12
000070dabbddd7ce  vmovaps [rsp+0xC0], xmm13
000070dabbddd7d7  vmovaps [rsp+0xD0], xmm14
000070dabbddd7e0  vmovaps [rsp+0xE0], xmm15
000070dabbddd7e9  sub rsp, 0x30
000070dabbddd7ed  movaps [rsp], xmm6
000070dabbddd7f1  movaps [rsp+0x10], xmm9
000070dabbddd7f7  movaps [rsp+0x20], xmm7
000070dabbddd7fc  lea rdi, [rsp]
000070dabbddd800  mov esi, 0x00
000070dabbddd805  mov rax, 0x5C2CF7B6F530
000070dabbddd80f  call rax
000070dabbddd811  movaps xmm6, [rsp]
000070dabbddd815  add rsp, 0x30
000070dabbddd819  vmovaps xmm0, [rsp]
000070dabbddd81e  vmovaps xmm1, [rsp+0x10]
000070dabbddd824  vmovaps xmm2, [rsp+0x20]
000070dabbddd82a  vmovaps xmm3, [rsp+0x30]
000070dabbddd830  vmovaps xmm4, [rsp+0x40]
000070dabbddd836  vmovaps xmm5, [rsp+0x50]
000070dabbddd83c  vmovaps xmm7, [rsp+0x60]
000070dabbddd842  vmovaps xmm8, [rsp+0x70]
000070dabbddd848  vmovaps xmm9, [rsp+0x80]
000070dabbddd851  vmovaps xmm10, [rsp+0x90]
000070dabbddd85a  vmovaps xmm11, [rsp+0xA0]
000070dabbddd863  vmovaps xmm12, [rsp+0xB0]
000070dabbddd86c  vmovaps xmm13, [rsp+0xC0]
000070dabbddd875  vmovaps xmm14, [rsp+0xD0]
000070dabbddd87e  vmovaps xmm15, [rsp+0xE0]
000070dabbddd887  add rsp, 0xF0
000070dabbddd88e  pop r11
000070dabbddd890  pop r10
000070dabbddd892  pop r9
000070dabbddd894  pop r8
000070dabbddd896  pop rsi
000070dabbddd897  pop rdi
000070dabbddd898  pop rdx
000070dabbddd899  pop rcx
000070dabbddd89a  pop rax
000070dabbddd89b  add rsp, 0x08
000070dabbddd89f  jmp 0x000070DABBDDBE5A
000070dabbddd8a4  sub rsp, 0x08
000070dabbddd8a8  push rax
000070dabbddd8a9  push rcx
000070dabbddd8aa  push rdx
000070dabbddd8ab  push rdi
000070dabbddd8ac  push rsi
000070dabbddd8ad  push r8
000070dabbddd8af  push r9
000070dabbddd8b1  push r10
000070dabbddd8b3  push r11
000070dabbddd8b5  sub rsp, 0xF0
000070dabbddd8bc  vmovaps [rsp], xmm0
000070dabbddd8c1  vmovaps [rsp+0x10], xmm1
000070dabbddd8c7  vmovaps [rsp+0x20], xmm2
000070dabbddd8cd  vmovaps [rsp+0x30], xmm3
000070dabbddd8d3  vmovaps [rsp+0x40], xmm4
000070dabbddd8d9  vmovaps [rsp+0x50], xmm5
000070dabbddd8df  vmovaps [rsp+0x60], xmm6
000070dabbddd8e5  vmovaps [rsp+0x70], xmm8
000070dabbddd8eb  vmovaps [rsp+0x80], xmm9
000070dabbddd8f4  vmovaps [rsp+0x90], xmm10
000070dabbddd8fd  vmovaps [rsp+0xA0], xmm11
000070dabbddd906  vmovaps [rsp+0xB0], xmm12
000070dabbddd90f  vmovaps [rsp+0xC0], xmm13
000070dabbddd918  vmovaps [rsp+0xD0], xmm14
000070dabbddd921  vmovaps [rsp+0xE0], xmm15
000070dabbddd92a  sub rsp, 0x30
000070dabbddd92e  movaps [rsp], xmm7
000070dabbddd932  movaps [rsp+0x10], xmm4
000070dabbddd937  movaps [rsp+0x20], xmm9
000070dabbddd93d  lea rdi, [rsp]
000070dabbddd941  mov esi, 0x00
000070dabbddd946  mov rax, 0x5C2CF7B6F530
000070dabbddd950  call rax
000070dabbddd952  movaps xmm7, [rsp]
000070dabbddd956  add rsp, 0x30
000070dabbddd95a  vmovaps xmm0, [rsp]
000070dabbddd95f  vmovaps xmm1, [rsp+0x10]
000070dabbddd965  vmovaps xmm2, [rsp+0x20]
000070dabbddd96b  vmovaps xmm3, [rsp+0x30]
000070dabbddd971  vmovaps xmm4, [rsp+0x40]
000070dabbddd977  vmovaps xmm5, [rsp+0x50]
000070dabbddd97d  vmovaps xmm6, [rsp+0x60]
000070dabbddd983  vmovaps xmm8, [rsp+0x70]
000070dabbddd989  vmovaps xmm9, [rsp+0x80]
000070dabbddd992  vmovaps xmm10, [rsp+0x90]
000070dabbddd99b  vmovaps xmm11, [rsp+0xA0]
000070dabbddd9a4  vmovaps xmm12, [rsp+0xB0]
000070dabbddd9ad  vmovaps xmm13, [rsp+0xC0]
000070dabbddd9b6  vmovaps xmm14, [rsp+0xD0]
000070dabbddd9bf  vmovaps xmm15, [rsp+0xE0]
000070dabbddd9c8  add rsp, 0xF0
000070dabbddd9cf  pop r11
000070dabbddd9d1  pop r10
000070dabbddd9d3  pop r9
000070dabbddd9d5  pop r8
000070dabbddd9d7  pop rsi
000070dabbddd9d8  pop rdi
000070dabbddd9d9  pop rdx
000070dabbddd9da  pop rcx
000070dabbddd9db  pop rax
000070dabbddd9dc  add rsp, 0x08
000070dabbddd9e0  jmp 0x000070DABBDDBE87
000070dabbddd9e5  sub rsp, 0x08
000070dabbddd9e9  push rax
000070dabbddd9ea  push rcx
000070dabbddd9eb  push rdx
000070dabbddd9ec  push rdi
000070dabbddd9ed  push rsi
000070dabbddd9ee  push r8
000070dabbddd9f0  push r9
000070dabbddd9f2  push r10
000070dabbddd9f4  push r11
000070dabbddd9f6  sub rsp, 0xF0
000070dabbddd9fd  vmovaps [rsp], xmm0
000070dabbddda02  vmovaps [rsp+0x10], xmm1
000070dabbddda08  vmovaps [rsp+0x20], xmm2
000070dabbddda0e  vmovaps [rsp+0x30], xmm3
000070dabbddda14  vmovaps [rsp+0x40], xmm5
000070dabbddda1a  vmovaps [rsp+0x50], xmm6
000070dabbddda20  vmovaps [rsp+0x60], xmm7
000070dabbddda26  vmovaps [rsp+0x70], xmm8
000070dabbddda2c  vmovaps [rsp+0x80], xmm9
000070dabbddda35  vmovaps [rsp+0x90], xmm10
000070dabbddda3e  vmovaps [rsp+0xA0], xmm11
000070dabbddda47  vmovaps [rsp+0xB0], xmm12
000070dabbddda50  vmovaps [rsp+0xC0], xmm13
000070dabbddda59  vmovaps [rsp+0xD0], xmm14
000070dabbddda62  vmovaps [rsp+0xE0], xmm15
000070dabbddda6b  sub rsp, 0x30
000070dabbddda6f  movaps [rsp], xmm4
000070dabbddda73  movaps [rsp+0x10], xmm15
000070dabbddda79  movaps [rsp+0x20], xmm9
000070dabbddda7f  lea rdi, [rsp]
000070dabbddda83  mov esi, 0x00
000070dabbddda88  mov rax, 0x5C2CF7B6F530
000070dabbddda92  call rax
000070dabbddda94  movaps xmm4, [rsp]
000070dabbddda98  add rsp, 0x30
000070dabbddda9c  vmovaps xmm0, [rsp]
000070dabbdddaa1  vmovaps xmm1, [rsp+0x10]
000070dabbdddaa7  vmovaps xmm2, [rsp+0x20]
000070dabbdddaad  vmovaps xmm3, [rsp+0x30]
000070dabbdddab3  vmovaps xmm5, [rsp+0x40]
000070dabbdddab9  vmovaps xmm6, [rsp+0x50]
000070dabbdddabf  vmovaps xmm7, [rsp+0x60]
000070dabbdddac5  vmovaps xmm8, [rsp+0x70]
000070dabbdddacb  vmovaps xmm9, [rsp+0x80]
000070dabbdddad4  vmovaps xmm10, [rsp+0x90]
000070dabbdddadd  vmovaps xmm11, [rsp+0xA0]
000070dabbdddae6  vmovaps xmm12, [rsp+0xB0]
000070dabbdddaef  vmovaps xmm13, [rsp+0xC0]
000070dabbdddaf8  vmovaps xmm14, [rsp+0xD0]
000070dabbdddb01  vmovaps xmm15, [rsp+0xE0]
000070dabbdddb0a  add rsp, 0xF0
000070dabbdddb11  pop r11
000070dabbdddb13  pop r10
000070dabbdddb15  pop r9
000070dabbdddb17  pop r8
000070dabbdddb19  pop rsi
000070dabbdddb1a  pop rdi
000070dabbdddb1b  pop rdx
000070dabbdddb1c  pop rcx
000070dabbdddb1d  pop rax
000070dabbdddb1e  add rsp, 0x08
000070dabbdddb22  jmp 0x000070DABBDDBEAC
000070dabbdddb27  call 0x000070DABBCC4620
000070dabbdddb2c  jmp 0x000070DABBDDBEB9
000070dabbdddb31  sub rsp, 0x08
000070dabbdddb35  push rax
000070dabbdddb36  push rcx
000070dabbdddb37  push rdx
000070dabbdddb38  push rdi
000070dabbdddb39  push rsi
000070dabbdddb3a  push r8
000070dabbdddb3c  push r9
000070dabbdddb3e  push r10
000070dabbdddb40  push r11
000070dabbdddb42  sub rsp, 0xF0
000070dabbdddb49  vmovaps [rsp], xmm0
000070dabbdddb4e  vmovaps [rsp+0x10], xmm1
000070dabbdddb54  vmovaps [rsp+0x20], xmm2
000070dabbdddb5a  vmovaps [rsp+0x30], xmm4
000070dabbdddb60  vmovaps [rsp+0x40], xmm5
000070dabbdddb66  vmovaps [rsp+0x50], xmm6
000070dabbdddb6c  vmovaps [rsp+0x60], xmm7
000070dabbdddb72  vmovaps [rsp+0x70], xmm8
000070dabbdddb78  vmovaps [rsp+0x80], xmm9
000070dabbdddb81  vmovaps [rsp+0x90], xmm10
000070dabbdddb8a  vmovaps [rsp+0xA0], xmm11
000070dabbdddb93  vmovaps [rsp+0xB0], xmm12
000070dabbdddb9c  vmovaps [rsp+0xC0], xmm13
000070dabbdddba5  vmovaps [rsp+0xD0], xmm14
000070dabbdddbae  vmovaps [rsp+0xE0], xmm15
000070dabbdddbb7  sub rsp, 0x30
000070dabbdddbbb  movaps [rsp], xmm3
000070dabbdddbbf  movaps [rsp+0x10], xmm1
000070dabbdddbc4  movaps [rsp+0x20], xmm9
000070dabbdddbca  lea rdi, [rsp]
000070dabbdddbce  mov esi, 0x00
000070dabbdddbd3  mov rax, 0x5C2CF7B6F530
000070dabbdddbdd  call rax
000070dabbdddbdf  movaps xmm3, [rsp]
000070dabbdddbe3  add rsp, 0x30
000070dabbdddbe7  vmovaps xmm0, [rsp]
000070dabbdddbec  vmovaps xmm1, [rsp+0x10]
000070dabbdddbf2  vmovaps xmm2, [rsp+0x20]
000070dabbdddbf8  vmovaps xmm4, [rsp+0x30]
000070dabbdddbfe  vmovaps xmm5, [rsp+0x40]
000070dabbdddc04  vmovaps xmm6, [rsp+0x50]
000070dabbdddc0a  vmovaps xmm7, [rsp+0x60]
000070dabbdddc10  vmovaps xmm8, [rsp+0x70]
000070dabbdddc16  vmovaps xmm9, [rsp+0x80]
000070dabbdddc1f  vmovaps xmm10, [rsp+0x90]
000070dabbdddc28  vmovaps xmm11, [rsp+0xA0]
000070dabbdddc31  vmovaps xmm12, [rsp+0xB0]
000070dabbdddc3a  vmovaps xmm13, [rsp+0xC0]
000070dabbdddc43  vmovaps xmm14, [rsp+0xD0]
000070dabbdddc4c  vmovaps xmm15, [rsp+0xE0]
000070dabbdddc55  add rsp, 0xF0
000070dabbdddc5c  pop r11
000070dabbdddc5e  pop r10
000070dabbdddc60  pop r9
000070dabbdddc62  pop r8
000070dabbdddc64  pop rsi
000070dabbdddc65  pop rdi
000070dabbdddc66  pop rdx
000070dabbdddc67  pop rcx
000070dabbdddc68  pop rax
000070dabbdddc69  add rsp, 0x08
000070dabbdddc6d  jmp 0x000070DABBDDBEF6
000070dabbdddc72  sub rsp, 0x08
000070dabbdddc76  push rax
000070dabbdddc77  push rcx
000070dabbdddc78  push rdx
000070dabbdddc79  push rdi
000070dabbdddc7a  push rsi
000070dabbdddc7b  push r8
000070dabbdddc7d  push r9
000070dabbdddc7f  push r10
000070dabbdddc81  push r11
000070dabbdddc83  sub rsp, 0xF0
000070dabbdddc8a  vmovaps [rsp], xmm0
000070dabbdddc8f  vmovaps [rsp+0x10], xmm2
000070dabbdddc95  vmovaps [rsp+0x20], xmm3
000070dabbdddc9b  vmovaps [rsp+0x30], xmm4
000070dabbdddca1  vmovaps [rsp+0x40], xmm5
000070dabbdddca7  vmovaps [rsp+0x50], xmm6
000070dabbdddcad  vmovaps [rsp+0x60], xmm7
000070dabbdddcb3  vmovaps [rsp+0x70], xmm8
000070dabbdddcb9  vmovaps [rsp+0x80], xmm9
000070dabbdddcc2  vmovaps [rsp+0x90], xmm10
000070dabbdddccb  vmovaps [rsp+0xA0], xmm11
000070dabbdddcd4  vmovaps [rsp+0xB0], xmm12
000070dabbdddcdd  vmovaps [rsp+0xC0], xmm13
000070dabbdddce6  vmovaps [rsp+0xD0], xmm14
000070dabbdddcef  vmovaps [rsp+0xE0], xmm15
000070dabbdddcf8  sub rsp, 0x30
000070dabbdddcfc  movaps [rsp], xmm1
000070dabbdddd00  movaps [rsp+0x10], xmm15
000070dabbdddd06  movaps [rsp+0x20], xmm9
000070dabbdddd0c  lea rdi, [rsp]
000070dabbdddd10  mov esi, 0x00
000070dabbdddd15  mov rax, 0x5C2CF7B6F530
000070dabbdddd1f  call rax
000070dabbdddd21  movaps xmm1, [rsp]
000070dabbdddd25  add rsp, 0x30
000070dabbdddd29  vmovaps xmm0, [rsp]
000070dabbdddd2e  vmovaps xmm2, [rsp+0x10]
000070dabbdddd34  vmovaps xmm3, [rsp+0x20]
000070dabbdddd3a  vmovaps xmm4, [rsp+0x30]
000070dabbdddd40  vmovaps xmm5, [rsp+0x40]
000070dabbdddd46  vmovaps xmm6, [rsp+0x50]
000070dabbdddd4c  vmovaps xmm7, [rsp+0x60]
000070dabbdddd52  vmovaps xmm8, [rsp+0x70]
000070dabbdddd58  vmovaps xmm9, [rsp+0x80]
000070dabbdddd61  vmovaps xmm10, [rsp+0x90]
000070dabbdddd6a  vmovaps xmm11, [rsp+0xA0]
000070dabbdddd73  vmovaps xmm12, [rsp+0xB0]
000070dabbdddd7c  vmovaps xmm13, [rsp+0xC0]
000070dabbdddd85  vmovaps xmm14, [rsp+0xD0]
000070dabbdddd8e  vmovaps xmm15, [rsp+0xE0]
000070dabbdddd97  add rsp, 0xF0
000070dabbdddd9e  pop r11
000070dabbdddda0  pop r10
000070dabbdddda2  pop r9
000070dabbdddda4  pop r8
000070dabbdddda6  pop rsi
000070dabbdddda7  pop rdi
000070dabbdddda8  pop rdx
000070dabbdddda9  pop rcx
000070dabbddddaa  pop rax
000070dabbddddab  add rsp, 0x08
000070dabbddddaf  jmp 0x000070DABBDDBF7E
000070dabbddddb4  call 0x000070DABBCC4620
000070dabbddddb9  jmp 0x000070DABBDDBF8B
000070dabbddddbe  sub rsp, 0x08
000070dabbddddc2  push rax
000070dabbddddc3  push rcx
000070dabbddddc4  push rdx
000070dabbddddc5  push rdi
000070dabbddddc6  push rsi
000070dabbddddc7  push r8
000070dabbddddc9  push r9
000070dabbddddcb  push r10
000070dabbddddcd  push r11
000070dabbddddcf  sub rsp, 0xF0
000070dabbddddd6  vmovaps [rsp], xmm0
000070dabbdddddb  vmovaps [rsp+0x10], xmm2
000070dabbdddde1  vmovaps [rsp+0x20], xmm3
000070dabbdddde7  vmovaps [rsp+0x30], xmm4
000070dabbdddded  vmovaps [rsp+0x40], xmm5
000070dabbddddf3  vmovaps [rsp+0x50], xmm6
000070dabbddddf9  vmovaps [rsp+0x60], xmm7
000070dabbddddff  vmovaps [rsp+0x70], xmm8
000070dabbddde05  vmovaps [rsp+0x80], xmm9
000070dabbddde0e  vmovaps [rsp+0x90], xmm10
000070dabbddde17  vmovaps [rsp+0xA0], xmm11
000070dabbddde20  vmovaps [rsp+0xB0], xmm12
000070dabbddde29  vmovaps [rsp+0xC0], xmm13
000070dabbddde32  vmovaps [rsp+0xD0], xmm14
000070dabbddde3b  vmovaps [rsp+0xE0], xmm15
000070dabbddde44  sub rsp, 0x30
000070dabbddde48  movaps [rsp], xmm1
000070dabbddde4c  movaps [rsp+0x10], xmm5
000070dabbddde51  movaps [rsp+0x20], xmm7
000070dabbddde56  lea rdi, [rsp]
000070dabbddde5a  mov esi, 0x00
000070dabbddde5f  mov rax, 0x5C2CF7B6F530
000070dabbddde69  call rax
000070dabbddde6b  movaps xmm1, [rsp]
000070dabbddde6f  add rsp, 0x30
000070dabbddde73  vmovaps xmm0, [rsp]
000070dabbddde78  vmovaps xmm2, [rsp+0x10]
000070dabbddde7e  vmovaps xmm3, [rsp+0x20]
000070dabbddde84  vmovaps xmm4, [rsp+0x30]
000070dabbddde8a  vmovaps xmm5, [rsp+0x40]
000070dabbddde90  vmovaps xmm6, [rsp+0x50]
000070dabbddde96  vmovaps xmm7, [rsp+0x60]
000070dabbddde9c  vmovaps xmm8, [rsp+0x70]
000070dabbdddea2  vmovaps xmm9, [rsp+0x80]
000070dabbdddeab  vmovaps xmm10, [rsp+0x90]
000070dabbdddeb4  vmovaps xmm11, [rsp+0xA0]
000070dabbdddebd  vmovaps xmm12, [rsp+0xB0]
000070dabbdddec6  vmovaps xmm13, [rsp+0xC0]
000070dabbdddecf  vmovaps xmm14, [rsp+0xD0]
000070dabbddded8  vmovaps xmm15, [rsp+0xE0]
000070dabbdddee1  add rsp, 0xF0
000070dabbdddee8  pop r11
000070dabbdddeea  pop r10
000070dabbdddeec  pop r9
000070dabbdddeee  pop r8
000070dabbdddef0  pop rsi
000070dabbdddef1  pop rdi
000070dabbdddef2  pop rdx
000070dabbdddef3  pop rcx
000070dabbdddef4  pop rax
000070dabbdddef5  add rsp, 0x08
000070dabbdddef9  jmp 0x000070DABBDDC030
000070dabbdddefe  sub rsp, 0x08
000070dabbdddf02  push rax
000070dabbdddf03  push rcx
000070dabbdddf04  push rdx
000070dabbdddf05  push rdi
000070dabbdddf06  push rsi
000070dabbdddf07  push r8
000070dabbdddf09  push r9
000070dabbdddf0b  push r10
000070dabbdddf0d  push r11
000070dabbdddf0f  sub rsp, 0xF0
000070dabbdddf16  vmovaps [rsp], xmm0
000070dabbdddf1b  vmovaps [rsp+0x10], xmm1
000070dabbdddf21  vmovaps [rsp+0x20], xmm2
000070dabbdddf27  vmovaps [rsp+0x30], xmm3
000070dabbdddf2d  vmovaps [rsp+0x40], xmm4
000070dabbdddf33  vmovaps [rsp+0x50], xmm5
000070dabbdddf39  vmovaps [rsp+0x60], xmm6
000070dabbdddf3f  vmovaps [rsp+0x70], xmm8
000070dabbdddf45  vmovaps [rsp+0x80], xmm9
000070dabbdddf4e  vmovaps [rsp+0x90], xmm10
000070dabbdddf57  vmovaps [rsp+0xA0], xmm11
000070dabbdddf60  vmovaps [rsp+0xB0], xmm12
000070dabbdddf69  vmovaps [rsp+0xC0], xmm13
000070dabbdddf72  vmovaps [rsp+0xD0], xmm14
000070dabbdddf7b  vmovaps [rsp+0xE0], xmm15
000070dabbdddf84  sub rsp, 0x30
000070dabbdddf88  movaps [rsp], xmm7
000070dabbdddf8c  movaps [rsp+0x10], xmm5
000070dabbdddf91  movaps [rsp+0x20], xmm15
000070dabbdddf97  lea rdi, [rsp]
000070dabbdddf9b  mov esi, 0x00
000070dabbdddfa0  mov rax, 0x5C2CF7B6F530
000070dabbdddfaa  call rax
000070dabbdddfac  movaps xmm7, [rsp]
000070dabbdddfb0  add rsp, 0x30
000070dabbdddfb4  vmovaps xmm0, [rsp]
000070dabbdddfb9  vmovaps xmm1, [rsp+0x10]
000070dabbdddfbf  vmovaps xmm2, [rsp+0x20]
000070dabbdddfc5  vmovaps xmm3, [rsp+0x30]
000070dabbdddfcb  vmovaps xmm4, [rsp+0x40]
000070dabbdddfd1  vmovaps xmm5, [rsp+0x50]
000070dabbdddfd7  vmovaps xmm6, [rsp+0x60]
000070dabbdddfdd  vmovaps xmm8, [rsp+0x70]
000070dabbdddfe3  vmovaps xmm9, [rsp+0x80]
000070dabbdddfec  vmovaps xmm10, [rsp+0x90]
000070dabbdddff5  vmovaps xmm11, [rsp+0xA0]
000070dabbdddffe  vmovaps xmm12, [rsp+0xB0]
000070dabbdde007  vmovaps xmm13, [rsp+0xC0]
000070dabbdde010  vmovaps xmm14, [rsp+0xD0]
000070dabbdde019  vmovaps xmm15, [rsp+0xE0]
000070dabbdde022  add rsp, 0xF0
000070dabbdde029  pop r11
000070dabbdde02b  pop r10
000070dabbdde02d  pop r9
000070dabbdde02f  pop r8
000070dabbdde031  pop rsi
000070dabbdde032  pop rdi
000070dabbdde033  pop rdx
000070dabbdde034  pop rcx
000070dabbdde035  pop rax
000070dabbdde036  add rsp, 0x08
000070dabbdde03a  jmp 0x000070DABBDDC066
000070dabbdde03f  call 0x000070DABBCB52F0
000070dabbdde044  jmp 0x000070DABBDDC073
000070dabbdde049  sub rsp, 0x08
000070dabbdde04d  push rax
000070dabbdde04e  push rcx
000070dabbdde04f  push rdx
000070dabbdde050  push rdi
000070dabbdde051  push rsi
000070dabbdde052  push r8
000070dabbdde054  push r9
000070dabbdde056  push r10
000070dabbdde058  push r11
000070dabbdde05a  sub rsp, 0xF0
000070dabbdde061  vmovaps [rsp], xmm0
000070dabbdde066  vmovaps [rsp+0x10], xmm1
000070dabbdde06c  vmovaps [rsp+0x20], xmm2
000070dabbdde072  vmovaps [rsp+0x30], xmm3
000070dabbdde078  vmovaps [rsp+0x40], xmm4
000070dabbdde07e  vmovaps [rsp+0x50], xmm5
000070dabbdde084  vmovaps [rsp+0x60], xmm6
000070dabbdde08a  vmovaps [rsp+0x70], xmm7
000070dabbdde090  vmovaps [rsp+0x80], xmm8
000070dabbdde099  vmovaps [rsp+0x90], xmm9
000070dabbdde0a2  vmovaps [rsp+0xA0], xmm10
000070dabbdde0ab  vmovaps [rsp+0xB0], xmm11
000070dabbdde0b4  vmovaps [rsp+0xC0], xmm12
000070dabbdde0bd  vmovaps [rsp+0xD0], xmm13
000070dabbdde0c6  vmovaps [rsp+0xE0], xmm14
000070dabbdde0cf  sub rsp, 0x30
000070dabbdde0d3  movaps [rsp], xmm15
000070dabbdde0d8  movaps [rsp+0x10], xmm5
000070dabbdde0dd  movaps [rsp+0x20], xmm3
000070dabbdde0e2  lea rdi, [rsp]
000070dabbdde0e6  mov esi, 0x00
000070dabbdde0eb  mov rax, 0x5C2CF7B6F530
000070dabbdde0f5  call rax
000070dabbdde0f7  movaps xmm15, [rsp]
000070dabbdde0fc  add rsp, 0x30
000070dabbdde100  vmovaps xmm0, [rsp]
000070dabbdde105  vmovaps xmm1, [rsp+0x10]
000070dabbdde10b  vmovaps xmm2, [rsp+0x20]
000070dabbdde111  vmovaps xmm3, [rsp+0x30]
000070dabbdde117  vmovaps xmm4, [rsp+0x40]
000070dabbdde11d  vmovaps xmm5, [rsp+0x50]
000070dabbdde123  vmovaps xmm6, [rsp+0x60]
000070dabbdde129  vmovaps xmm7, [rsp+0x70]
000070dabbdde12f  vmovaps xmm8, [rsp+0x80]
000070dabbdde138  vmovaps xmm9, [rsp+0x90]
000070dabbdde141  vmovaps xmm10, [rsp+0xA0]
000070dabbdde14a  vmovaps xmm11, [rsp+0xB0]
000070dabbdde153  vmovaps xmm12, [rsp+0xC0]
000070dabbdde15c  vmovaps xmm13, [rsp+0xD0]
000070dabbdde165  vmovaps xmm14, [rsp+0xE0]
000070dabbdde16e  add rsp, 0xF0
000070dabbdde175  pop r11
000070dabbdde177  pop r10
000070dabbdde179  pop r9
000070dabbdde17b  pop r8
000070dabbdde17d  pop rsi
000070dabbdde17e  pop rdi
000070dabbdde17f  pop rdx
000070dabbdde180  pop rcx
000070dabbdde181  pop rax
000070dabbdde182  add rsp, 0x08
000070dabbdde186  jmp 0x000070DABBDDC099
000070dabbdde18b  sub rsp, 0x08
000070dabbdde18f  push rax
000070dabbdde190  push rcx
000070dabbdde191  push rdx
000070dabbdde192  push rdi
000070dabbdde193  push rsi
000070dabbdde194  push r8
000070dabbdde196  push r9
000070dabbdde198  push r10
000070dabbdde19a  push r11
000070dabbdde19c  sub rsp, 0xF0
000070dabbdde1a3  vmovaps [rsp], xmm0
000070dabbdde1a8  vmovaps [rsp+0x10], xmm2
000070dabbdde1ae  vmovaps [rsp+0x20], xmm3
000070dabbdde1b4  vmovaps [rsp+0x30], xmm4
000070dabbdde1ba  vmovaps [rsp+0x40], xmm5
000070dabbdde1c0  vmovaps [rsp+0x50], xmm6
000070dabbdde1c6  vmovaps [rsp+0x60], xmm7
000070dabbdde1cc  vmovaps [rsp+0x70], xmm8
000070dabbdde1d2  vmovaps [rsp+0x80], xmm9
000070dabbdde1db  vmovaps [rsp+0x90], xmm10
000070dabbdde1e4  vmovaps [rsp+0xA0], xmm11
000070dabbdde1ed  vmovaps [rsp+0xB0], xmm12
000070dabbdde1f6  vmovaps [rsp+0xC0], xmm13
000070dabbdde1ff  vmovaps [rsp+0xD0], xmm14
000070dabbdde208  vmovaps [rsp+0xE0], xmm15
000070dabbdde211  sub rsp, 0x30
000070dabbdde215  movaps [rsp], xmm1
000070dabbdde219  movaps [rsp+0x10], xmm5
000070dabbdde21e  movaps [rsp+0x20], xmm4
000070dabbdde223  lea rdi, [rsp]
000070dabbdde227  mov esi, 0x00
000070dabbdde22c  mov rax, 0x5C2CF7B6F530
000070dabbdde236  call rax
000070dabbdde238  movaps xmm1, [rsp]
000070dabbdde23c  add rsp, 0x30
000070dabbdde240  vmovaps xmm0, [rsp]
000070dabbdde245  vmovaps xmm2, [rsp+0x10]
000070dabbdde24b  vmovaps xmm3, [rsp+0x20]
000070dabbdde251  vmovaps xmm4, [rsp+0x30]
000070dabbdde257  vmovaps xmm5, [rsp+0x40]
000070dabbdde25d  vmovaps xmm6, [rsp+0x50]
000070dabbdde263  vmovaps xmm7, [rsp+0x60]
000070dabbdde269  vmovaps xmm8, [rsp+0x70]
000070dabbdde26f  vmovaps xmm9, [rsp+0x80]
000070dabbdde278  vmovaps xmm10, [rsp+0x90]
000070dabbdde281  vmovaps xmm11, [rsp+0xA0]
000070dabbdde28a  vmovaps xmm12, [rsp+0xB0]
000070dabbdde293  vmovaps xmm13, [rsp+0xC0]
000070dabbdde29c  vmovaps xmm14, [rsp+0xD0]
000070dabbdde2a5  vmovaps xmm15, [rsp+0xE0]
000070dabbdde2ae  add rsp, 0xF0
000070dabbdde2b5  pop r11
000070dabbdde2b7  pop r10
000070dabbdde2b9  pop r9
000070dabbdde2bb  pop r8
000070dabbdde2bd  pop rsi
000070dabbdde2be  pop rdi
000070dabbdde2bf  pop rdx
000070dabbdde2c0  pop rcx
000070dabbdde2c1  pop rax
000070dabbdde2c2  add rsp, 0x08
000070dabbdde2c6  jmp 0x000070DABBDDC0B9
000070dabbdde2cb  sub rsp, 0x08
000070dabbdde2cf  push rax
000070dabbdde2d0  push rcx
000070dabbdde2d1  push rdx
000070dabbdde2d2  push rdi
000070dabbdde2d3  push rsi
000070dabbdde2d4  push r8
000070dabbdde2d6  push r9
000070dabbdde2d8  push r10
000070dabbdde2da  push r11
000070dabbdde2dc  sub rsp, 0xF0
000070dabbdde2e3  vmovaps [rsp], xmm0
000070dabbdde2e8  vmovaps [rsp+0x10], xmm1
000070dabbdde2ee  vmovaps [rsp+0x20], xmm2
000070dabbdde2f4  vmovaps [rsp+0x30], xmm3
000070dabbdde2fa  vmovaps [rsp+0x40], xmm5
000070dabbdde300  vmovaps [rsp+0x50], xmm6
000070dabbdde306  vmovaps [rsp+0x60], xmm7
000070dabbdde30c  vmovaps [rsp+0x70], xmm8
000070dabbdde312  vmovaps [rsp+0x80], xmm9
000070dabbdde31b  vmovaps [rsp+0x90], xmm10
000070dabbdde324  vmovaps [rsp+0xA0], xmm11
000070dabbdde32d  vmovaps [rsp+0xB0], xmm12
000070dabbdde336  vmovaps [rsp+0xC0], xmm13
000070dabbdde33f  vmovaps [rsp+0xD0], xmm14
000070dabbdde348  vmovaps [rsp+0xE0], xmm15
000070dabbdde351  sub rsp, 0x30
000070dabbdde355  movaps [rsp], xmm4
000070dabbdde359  movaps [rsp+0x10], xmm3
000070dabbdde35e  movaps [rsp+0x20], xmm5
000070dabbdde363  lea rdi, [rsp]
000070dabbdde367  mov esi, 0x00
000070dabbdde36c  mov rax, 0x5C2CF7B6F530
000070dabbdde376  call rax
000070dabbdde378  movaps xmm4, [rsp]
000070dabbdde37c  add rsp, 0x30
000070dabbdde380  vmovaps xmm0, [rsp]
000070dabbdde385  vmovaps xmm1, [rsp+0x10]
000070dabbdde38b  vmovaps xmm2, [rsp+0x20]
000070dabbdde391  vmovaps xmm3, [rsp+0x30]
000070dabbdde397  vmovaps xmm5, [rsp+0x40]
000070dabbdde39d  vmovaps xmm6, [rsp+0x50]
000070dabbdde3a3  vmovaps xmm7, [rsp+0x60]
000070dabbdde3a9  vmovaps xmm8, [rsp+0x70]
000070dabbdde3af  vmovaps xmm9, [rsp+0x80]
000070dabbdde3b8  vmovaps xmm10, [rsp+0x90]
000070dabbdde3c1  vmovaps xmm11, [rsp+0xA0]
000070dabbdde3ca  vmovaps xmm12, [rsp+0xB0]
000070dabbdde3d3  vmovaps xmm13, [rsp+0xC0]
000070dabbdde3dc  vmovaps xmm14, [rsp+0xD0]
000070dabbdde3e5  vmovaps xmm15, [rsp+0xE0]
000070dabbdde3ee  add rsp, 0xF0
000070dabbdde3f5  pop r11
000070dabbdde3f7  pop r10
000070dabbdde3f9  pop r9
000070dabbdde3fb  pop r8
000070dabbdde3fd  pop rsi
000070dabbdde3fe  pop rdi
000070dabbdde3ff  pop rdx
000070dabbdde400  pop rcx
000070dabbdde401  pop rax
000070dabbdde402  add rsp, 0x08
000070dabbdde406  jmp 0x000070DABBDDC107
000070dabbdde40b  call 0x000070DABBCB52F0
000070dabbdde410  jmp 0x000070DABBDDC114
000070dabbdde415  sub rsp, 0x08
000070dabbdde419  push rax
000070dabbdde41a  push rcx
000070dabbdde41b  push rdx
000070dabbdde41c  push rdi
000070dabbdde41d  push rsi
000070dabbdde41e  push r8
000070dabbdde420  push r9
000070dabbdde422  push r10
000070dabbdde424  push r11
000070dabbdde426  sub rsp, 0xF0
000070dabbdde42d  vmovaps [rsp], xmm0
000070dabbdde432  vmovaps [rsp+0x10], xmm1
000070dabbdde438  vmovaps [rsp+0x20], xmm2
000070dabbdde43e  vmovaps [rsp+0x30], xmm3
000070dabbdde444  vmovaps [rsp+0x40], xmm4
000070dabbdde44a  vmovaps [rsp+0x50], xmm6
000070dabbdde450  vmovaps [rsp+0x60], xmm7
000070dabbdde456  vmovaps [rsp+0x70], xmm8
000070dabbdde45c  vmovaps [rsp+0x80], xmm9
000070dabbdde465  vmovaps [rsp+0x90], xmm10
000070dabbdde46e  vmovaps [rsp+0xA0], xmm11
000070dabbdde477  vmovaps [rsp+0xB0], xmm12
000070dabbdde480  vmovaps [rsp+0xC0], xmm13
000070dabbdde489  vmovaps [rsp+0xD0], xmm14
000070dabbdde492  vmovaps [rsp+0xE0], xmm15
000070dabbdde49b  sub rsp, 0x30
000070dabbdde49f  movaps [rsp], xmm5
000070dabbdde4a3  movaps [rsp+0x10], xmm6
000070dabbdde4a8  movaps [rsp+0x20], xmm3
000070dabbdde4ad  lea rdi, [rsp]
000070dabbdde4b1  mov esi, 0x00
000070dabbdde4b6  mov rax, 0x5C2CF7B6F530
000070dabbdde4c0  call rax
000070dabbdde4c2  movaps xmm5, [rsp]
000070dabbdde4c6  add rsp, 0x30
000070dabbdde4ca  vmovaps xmm0, [rsp]
000070dabbdde4cf  vmovaps xmm1, [rsp+0x10]
000070dabbdde4d5  vmovaps xmm2, [rsp+0x20]
000070dabbdde4db  vmovaps xmm3, [rsp+0x30]
000070dabbdde4e1  vmovaps xmm4, [rsp+0x40]
000070dabbdde4e7  vmovaps xmm6, [rsp+0x50]
000070dabbdde4ed  vmovaps xmm7, [rsp+0x60]
000070dabbdde4f3  vmovaps xmm8, [rsp+0x70]
000070dabbdde4f9  vmovaps xmm9, [rsp+0x80]
000070dabbdde502  vmovaps xmm10, [rsp+0x90]
000070dabbdde50b  vmovaps xmm11, [rsp+0xA0]
000070dabbdde514  vmovaps xmm12, [rsp+0xB0]
000070dabbdde51d  vmovaps xmm13, [rsp+0xC0]
000070dabbdde526  vmovaps xmm14, [rsp+0xD0]
000070dabbdde52f  vmovaps xmm15, [rsp+0xE0]
000070dabbdde538  add rsp, 0xF0
000070dabbdde53f  pop r11
000070dabbdde541  pop r10
000070dabbdde543  pop r9
000070dabbdde545  pop r8
000070dabbdde547  pop rsi
000070dabbdde548  pop rdi
000070dabbdde549  pop rdx
000070dabbdde54a  pop rcx
000070dabbdde54b  pop rax
000070dabbdde54c  add rsp, 0x08
000070dabbdde550  jmp 0x000070DABBDDC13A
000070dabbdde555  sub rsp, 0x08
000070dabbdde559  push rax
000070dabbdde55a  push rcx
000070dabbdde55b  push rdx
000070dabbdde55c  push rdi
000070dabbdde55d  push rsi
000070dabbdde55e  push r8
000070dabbdde560  push r9
000070dabbdde562  push r10
000070dabbdde564  push r11
000070dabbdde566  sub rsp, 0xF0
000070dabbdde56d  vmovaps [rsp], xmm0
000070dabbdde572  vmovaps [rsp+0x10], xmm1
000070dabbdde578  vmovaps [rsp+0x20], xmm2
000070dabbdde57e  vmovaps [rsp+0x30], xmm3
000070dabbdde584  vmovaps [rsp+0x40], xmm4
000070dabbdde58a  vmovaps [rsp+0x50], xmm5
000070dabbdde590  vmovaps [rsp+0x60], xmm7
000070dabbdde596  vmovaps [rsp+0x70], xmm8
000070dabbdde59c  vmovaps [rsp+0x80], xmm9
000070dabbdde5a5  vmovaps [rsp+0x90], xmm10
000070dabbdde5ae  vmovaps [rsp+0xA0], xmm11
000070dabbdde5b7  vmovaps [rsp+0xB0], xmm12
000070dabbdde5c0  vmovaps [rsp+0xC0], xmm13
000070dabbdde5c9  vmovaps [rsp+0xD0], xmm14
000070dabbdde5d2  vmovaps [rsp+0xE0], xmm15
000070dabbdde5db  sub rsp, 0x30
000070dabbdde5df  movaps [rsp], xmm6
000070dabbdde5e3  movaps [rsp+0x10], xmm9
000070dabbdde5e9  movaps [rsp+0x20], xmm1
000070dabbdde5ee  lea rdi, [rsp]
000070dabbdde5f2  mov esi, 0x00
000070dabbdde5f7  mov rax, 0x5C2CF7B6F530
000070dabbdde601  call rax
000070dabbdde603  movaps xmm6, [rsp]
000070dabbdde607  add rsp, 0x30
000070dabbdde60b  vmovaps xmm0, [rsp]
000070dabbdde610  vmovaps xmm1, [rsp+0x10]
000070dabbdde616  vmovaps xmm2, [rsp+0x20]
000070dabbdde61c  vmovaps xmm3, [rsp+0x30]
000070dabbdde622  vmovaps xmm4, [rsp+0x40]
000070dabbdde628  vmovaps xmm5, [rsp+0x50]
000070dabbdde62e  vmovaps xmm7, [rsp+0x60]
000070dabbdde634  vmovaps xmm8, [rsp+0x70]
000070dabbdde63a  vmovaps xmm9, [rsp+0x80]
000070dabbdde643  vmovaps xmm10, [rsp+0x90]
000070dabbdde64c  vmovaps xmm11, [rsp+0xA0]
000070dabbdde655  vmovaps xmm12, [rsp+0xB0]
000070dabbdde65e  vmovaps xmm13, [rsp+0xC0]
000070dabbdde667  vmovaps xmm14, [rsp+0xD0]
000070dabbdde670  vmovaps xmm15, [rsp+0xE0]
000070dabbdde679  add rsp, 0xF0
000070dabbdde680  pop r11
000070dabbdde682  pop r10
000070dabbdde684  pop r9
000070dabbdde686  pop r8
000070dabbdde688  pop rsi
000070dabbdde689  pop rdi
000070dabbdde68a  pop rdx
000070dabbdde68b  pop rcx
000070dabbdde68c  pop rax
000070dabbdde68d  add rsp, 0x08
000070dabbdde691  jmp 0x000070DABBDDC15E
000070dabbdde696  sub rsp, 0x08
000070dabbdde69a  push rax
000070dabbdde69b  push rcx
000070dabbdde69c  push rdx
000070dabbdde69d  push rdi
000070dabbdde69e  push rsi
000070dabbdde69f  push r8
000070dabbdde6a1  push r9
000070dabbdde6a3  push r10
000070dabbdde6a5  push r11
000070dabbdde6a7  sub rsp, 0xF0
000070dabbdde6ae  vmovaps [rsp], xmm0
000070dabbdde6b3  vmovaps [rsp+0x10], xmm1
000070dabbdde6b9  vmovaps [rsp+0x20], xmm2
000070dabbdde6bf  vmovaps [rsp+0x30], xmm3
000070dabbdde6c5  vmovaps [rsp+0x40], xmm4
000070dabbdde6cb  vmovaps [rsp+0x50], xmm5
000070dabbdde6d1  vmovaps [rsp+0x60], xmm6
000070dabbdde6d7  vmovaps [rsp+0x70], xmm7
000070dabbdde6dd  vmovaps [rsp+0x80], xmm8
000070dabbdde6e6  vmovaps [rsp+0x90], xmm10
000070dabbdde6ef  vmovaps [rsp+0xA0], xmm11
000070dabbdde6f8  vmovaps [rsp+0xB0], xmm12
000070dabbdde701  vmovaps [rsp+0xC0], xmm13
000070dabbdde70a  vmovaps [rsp+0xD0], xmm14
000070dabbdde713  vmovaps [rsp+0xE0], xmm15
000070dabbdde71c  sub rsp, 0x30
000070dabbdde720  movaps [rsp], xmm9
000070dabbdde725  movaps [rsp+0x10], xmm3
000070dabbdde72a  movaps [rsp+0x20], xmm1
000070dabbdde72f  lea rdi, [rsp]
000070dabbdde733  mov esi, 0x00
000070dabbdde738  mov rax, 0x5C2CF7B6F530
000070dabbdde742  call rax
000070dabbdde744  movaps xmm9, [rsp]
000070dabbdde749  add rsp, 0x30
000070dabbdde74d  vmovaps xmm0, [rsp]
000070dabbdde752  vmovaps xmm1, [rsp+0x10]
000070dabbdde758  vmovaps xmm2, [rsp+0x20]
000070dabbdde75e  vmovaps xmm3, [rsp+0x30]
000070dabbdde764  vmovaps xmm4, [rsp+0x40]
000070dabbdde76a  vmovaps xmm5, [rsp+0x50]
000070dabbdde770  vmovaps xmm6, [rsp+0x60]
000070dabbdde776  vmovaps xmm7, [rsp+0x70]
000070dabbdde77c  vmovaps xmm8, [rsp+0x80]
000070dabbdde785  vmovaps xmm10, [rsp+0x90]
000070dabbdde78e  vmovaps xmm11, [rsp+0xA0]
000070dabbdde797  vmovaps xmm12, [rsp+0xB0]
000070dabbdde7a0  vmovaps xmm13, [rsp+0xC0]
000070dabbdde7a9  vmovaps xmm14, [rsp+0xD0]
000070dabbdde7b2  vmovaps xmm15, [rsp+0xE0]
000070dabbdde7bb  add rsp, 0xF0
000070dabbdde7c2  pop r11
000070dabbdde7c4  pop r10
000070dabbdde7c6  pop r9
000070dabbdde7c8  pop r8
000070dabbdde7ca  pop rsi
000070dabbdde7cb  pop rdi
000070dabbdde7cc  pop rdx
000070dabbdde7cd  pop rcx
000070dabbdde7ce  pop rax
000070dabbdde7cf  add rsp, 0x08
000070dabbdde7d3  jmp 0x000070DABBDDC1AA
000070dabbdde7d8  call 0x000070DABBCB52F0
000070dabbdde7dd  jmp 0x000070DABBDDC1B7
000070dabbdde7e2  sub rsp, 0x08
000070dabbdde7e6  push rax
000070dabbdde7e7  push rcx
000070dabbdde7e8  push rdx
000070dabbdde7e9  push rdi
000070dabbdde7ea  push rsi
000070dabbdde7eb  push r8
000070dabbdde7ed  push r9
000070dabbdde7ef  push r10
000070dabbdde7f1  push r11
000070dabbdde7f3  sub rsp, 0xF0
000070dabbdde7fa  vmovaps [rsp], xmm0
000070dabbdde7ff  vmovaps [rsp+0x10], xmm1
000070dabbdde805  vmovaps [rsp+0x20], xmm2
000070dabbdde80b  vmovaps [rsp+0x30], xmm3
000070dabbdde811  vmovaps [rsp+0x40], xmm4
000070dabbdde817  vmovaps [rsp+0x50], xmm5
000070dabbdde81d  vmovaps [rsp+0x60], xmm6
000070dabbdde823  vmovaps [rsp+0x70], xmm7
000070dabbdde829  vmovaps [rsp+0x80], xmm8
000070dabbdde832  vmovaps [rsp+0x90], xmm9
000070dabbdde83b  vmovaps [rsp+0xA0], xmm10
000070dabbdde844  vmovaps [rsp+0xB0], xmm11
000070dabbdde84d  vmovaps [rsp+0xC0], xmm12
000070dabbdde856  vmovaps [rsp+0xD0], xmm13
000070dabbdde85f  vmovaps [rsp+0xE0], xmm14
000070dabbdde868  sub rsp, 0x30
000070dabbdde86c  movaps [rsp], xmm15
000070dabbdde871  movaps [rsp+0x10], xmm3
000070dabbdde876  movaps [rsp+0x20], xmm7
000070dabbdde87b  lea rdi, [rsp]
000070dabbdde87f  mov esi, 0x00
000070dabbdde884  mov rax, 0x5C2CF7B6F530
000070dabbdde88e  call rax
000070dabbdde890  movaps xmm15, [rsp]
000070dabbdde895  add rsp, 0x30
000070dabbdde899  vmovaps xmm0, [rsp]
000070dabbdde89e  vmovaps xmm1, [rsp+0x10]
000070dabbdde8a4  vmovaps xmm2, [rsp+0x20]
000070dabbdde8aa  vmovaps xmm3, [rsp+0x30]
000070dabbdde8b0  vmovaps xmm4, [rsp+0x40]
000070dabbdde8b6  vmovaps xmm5, [rsp+0x50]
000070dabbdde8bc  vmovaps xmm6, [rsp+0x60]
000070dabbdde8c2  vmovaps xmm7, [rsp+0x70]
000070dabbdde8c8  vmovaps xmm8, [rsp+0x80]
000070dabbdde8d1  vmovaps xmm9, [rsp+0x90]
000070dabbdde8da  vmovaps xmm10, [rsp+0xA0]
000070dabbdde8e3  vmovaps xmm11, [rsp+0xB0]
000070dabbdde8ec  vmovaps xmm12, [rsp+0xC0]
000070dabbdde8f5  vmovaps xmm13, [rsp+0xD0]
000070dabbdde8fe  vmovaps xmm14, [rsp+0xE0]
000070dabbdde907  add rsp, 0xF0
000070dabbdde90e  pop r11
000070dabbdde910  pop r10
000070dabbdde912  pop r9
000070dabbdde914  pop r8
000070dabbdde916  pop rsi
000070dabbdde917  pop rdi
000070dabbdde918  pop rdx
000070dabbdde919  pop rcx
000070dabbdde91a  pop rax
000070dabbdde91b  add rsp, 0x08
000070dabbdde91f  jmp 0x000070DABBDDC1E3
000070dabbdde924  sub rsp, 0x08
000070dabbdde928  push rax
000070dabbdde929  push rcx
000070dabbdde92a  push rdx
000070dabbdde92b  push rdi
000070dabbdde92c  push rsi
000070dabbdde92d  push r8
000070dabbdde92f  push r9
000070dabbdde931  push r10
000070dabbdde933  push r11
000070dabbdde935  sub rsp, 0xF0
000070dabbdde93c  vmovaps [rsp], xmm0
000070dabbdde941  vmovaps [rsp+0x10], xmm1
000070dabbdde947  vmovaps [rsp+0x20], xmm2
000070dabbdde94d  vmovaps [rsp+0x30], xmm4
000070dabbdde953  vmovaps [rsp+0x40], xmm5
000070dabbdde959  vmovaps [rsp+0x50], xmm6
000070dabbdde95f  vmovaps [rsp+0x60], xmm7
000070dabbdde965  vmovaps [rsp+0x70], xmm8
000070dabbdde96b  vmovaps [rsp+0x80], xmm9
000070dabbdde974  vmovaps [rsp+0x90], xmm10
000070dabbdde97d  vmovaps [rsp+0xA0], xmm11
000070dabbdde986  vmovaps [rsp+0xB0], xmm12
000070dabbdde98f  vmovaps [rsp+0xC0], xmm13
000070dabbdde998  vmovaps [rsp+0xD0], xmm14
000070dabbdde9a1  vmovaps [rsp+0xE0], xmm15
000070dabbdde9aa  sub rsp, 0x30
000070dabbdde9ae  movaps [rsp], xmm3
000070dabbdde9b2  movaps [rsp+0x10], xmm1
000070dabbdde9b7  movaps [rsp+0x20], xmm15
000070dabbdde9bd  lea rdi, [rsp]
000070dabbdde9c1  mov esi, 0x00
000070dabbdde9c6  mov rax, 0x5C2CF7B6F530
000070dabbdde9d0  call rax
000070dabbdde9d2  movaps xmm3, [rsp]
000070dabbdde9d6  add rsp, 0x30
000070dabbdde9da  vmovaps xmm0, [rsp]
000070dabbdde9df  vmovaps xmm1, [rsp+0x10]
000070dabbdde9e5  vmovaps xmm2, [rsp+0x20]
000070dabbdde9eb  vmovaps xmm4, [rsp+0x30]
000070dabbdde9f1  vmovaps xmm5, [rsp+0x40]
000070dabbdde9f7  vmovaps xmm6, [rsp+0x50]
000070dabbdde9fd  vmovaps xmm7, [rsp+0x60]
000070dabbddea03  vmovaps xmm8, [rsp+0x70]
000070dabbddea09  vmovaps xmm9, [rsp+0x80]
000070dabbddea12  vmovaps xmm10, [rsp+0x90]
000070dabbddea1b  vmovaps xmm11, [rsp+0xA0]
000070dabbddea24  vmovaps xmm12, [rsp+0xB0]
000070dabbddea2d  vmovaps xmm13, [rsp+0xC0]
000070dabbddea36  vmovaps xmm14, [rsp+0xD0]
000070dabbddea3f  vmovaps xmm15, [rsp+0xE0]
000070dabbddea48  add rsp, 0xF0
000070dabbddea4f  pop r11
000070dabbddea51  pop r10
000070dabbddea53  pop r9
000070dabbddea55  pop r8
000070dabbddea57  pop rsi
000070dabbddea58  pop rdi
000070dabbddea59  pop rdx
000070dabbddea5a  pop rcx
000070dabbddea5b  pop rax
000070dabbddea5c  add rsp, 0x08
000070dabbddea60  jmp 0x000070DABBDDC272
000070dabbddea65  call 0x000070DABBCB52F0
000070dabbddea6a  jmp 0x000070DABBDDC27C
000070dabbddea6f  sub rsp, 0x08
000070dabbddea73  push rax
000070dabbddea74  push rcx
000070dabbddea75  push rdx
000070dabbddea76  push rdi
000070dabbddea77  push rsi
000070dabbddea78  push r8
000070dabbddea7a  push r9
000070dabbddea7c  push r10
000070dabbddea7e  push r11
000070dabbddea80  sub rsp, 0xF0
000070dabbddea87  vmovaps [rsp], xmm0
000070dabbddea8c  vmovaps [rsp+0x10], xmm1
000070dabbddea92  vmovaps [rsp+0x20], xmm2
000070dabbddea98  vmovaps [rsp+0x30], xmm3
000070dabbddea9e  vmovaps [rsp+0x40], xmm4
000070dabbddeaa4  vmovaps [rsp+0x50], xmm5
000070dabbddeaaa  vmovaps [rsp+0x60], xmm6
000070dabbddeab0  vmovaps [rsp+0x70], xmm7
000070dabbddeab6  vmovaps [rsp+0x80], xmm8
000070dabbddeabf  vmovaps [rsp+0x90], xmm9
000070dabbddeac8  vmovaps [rsp+0xA0], xmm10
000070dabbddead1  vmovaps [rsp+0xB0], xmm11
000070dabbddeada  vmovaps [rsp+0xC0], xmm12
000070dabbddeae3  vmovaps [rsp+0xD0], xmm13
000070dabbddeaec  vmovaps [rsp+0xE0], xmm14
000070dabbddeaf5  sub rsp, 0x30
000070dabbddeaf9  movaps [rsp], xmm15
000070dabbddeafe  movaps [rsp+0x10], xmm14
000070dabbddeb04  movaps [rsp+0x20], xmm4
000070dabbddeb09  lea rdi, [rsp]
000070dabbddeb0d  mov esi, 0x00
000070dabbddeb12  mov rax, 0x5C2CF7B6F530
000070dabbddeb1c  call rax
000070dabbddeb1e  movaps xmm15, [rsp]
000070dabbddeb23  add rsp, 0x30
000070dabbddeb27  vmovaps xmm0, [rsp]
000070dabbddeb2c  vmovaps xmm1, [rsp+0x10]
000070dabbddeb32  vmovaps xmm2, [rsp+0x20]
000070dabbddeb38  vmovaps xmm3, [rsp+0x30]
000070dabbddeb3e  vmovaps xmm4, [rsp+0x40]
000070dabbddeb44  vmovaps xmm5, [rsp+0x50]
000070dabbddeb4a  vmovaps xmm6, [rsp+0x60]
000070dabbddeb50  vmovaps xmm7, [rsp+0x70]
000070dabbddeb56  vmovaps xmm8, [rsp+0x80]
000070dabbddeb5f  vmovaps xmm9, [rsp+0x90]
000070dabbddeb68  vmovaps xmm10, [rsp+0xA0]
000070dabbddeb71  vmovaps xmm11, [rsp+0xB0]
000070dabbddeb7a  vmovaps xmm12, [rsp+0xC0]
000070dabbddeb83  vmovaps xmm13, [rsp+0xD0]
000070dabbddeb8c  vmovaps xmm14, [rsp+0xE0]
000070dabbddeb95  add rsp, 0xF0
000070dabbddeb9c  pop r11
000070dabbddeb9e  pop r10
000070dabbddeba0  pop r9
000070dabbddeba2  pop r8
000070dabbddeba4  pop rsi
000070dabbddeba5  pop rdi
000070dabbddeba6  pop rdx
000070dabbddeba7  pop rcx
000070dabbddeba8  pop rax
000070dabbddeba9  add rsp, 0x08
000070dabbddebad  jmp 0x000070DABBDDC2AA
000070dabbddebb2  sub rsp, 0x08
000070dabbddebb6  push rax
000070dabbddebb7  push rcx
000070dabbddebb8  push rdx
000070dabbddebb9  push rdi
000070dabbddebba  push rsi
000070dabbddebbb  push r8
000070dabbddebbd  push r9
000070dabbddebbf  push r10
000070dabbddebc1  push r11
000070dabbddebc3  sub rsp, 0xF0
000070dabbddebca  vmovaps [rsp], xmm0
000070dabbddebcf  vmovaps [rsp+0x10], xmm1
000070dabbddebd5  vmovaps [rsp+0x20], xmm2
000070dabbddebdb  vmovaps [rsp+0x30], xmm3
000070dabbddebe1  vmovaps [rsp+0x40], xmm4
000070dabbddebe7  vmovaps [rsp+0x50], xmm5
000070dabbddebed  vmovaps [rsp+0x60], xmm6
000070dabbddebf3  vmovaps [rsp+0x70], xmm7
000070dabbddebf9  vmovaps [rsp+0x80], xmm8
000070dabbddec02  vmovaps [rsp+0x90], xmm9
000070dabbddec0b  vmovaps [rsp+0xA0], xmm10
000070dabbddec14  vmovaps [rsp+0xB0], xmm11
000070dabbddec1d  vmovaps [rsp+0xC0], xmm12
000070dabbddec26  vmovaps [rsp+0xD0], xmm13
000070dabbddec2f  vmovaps [rsp+0xE0], xmm15
000070dabbddec38  sub rsp, 0x30
000070dabbddec3c  movaps [rsp], xmm14
000070dabbddec41  movaps [rsp+0x10], xmm2
000070dabbddec46  movaps [rsp+0x20], xmm1
000070dabbddec4b  lea rdi, [rsp]
000070dabbddec4f  mov esi, 0x00
000070dabbddec54  mov rax, 0x5C2CF7B6F530
000070dabbddec5e  call rax
000070dabbddec60  movaps xmm14, [rsp]
000070dabbddec65  add rsp, 0x30
000070dabbddec69  vmovaps xmm0, [rsp]
000070dabbddec6e  vmovaps xmm1, [rsp+0x10]
000070dabbddec74  vmovaps xmm2, [rsp+0x20]
000070dabbddec7a  vmovaps xmm3, [rsp+0x30]
000070dabbddec80  vmovaps xmm4, [rsp+0x40]
000070dabbddec86  vmovaps xmm5, [rsp+0x50]
000070dabbddec8c  vmovaps xmm6, [rsp+0x60]
000070dabbddec92  vmovaps xmm7, [rsp+0x70]
000070dabbddec98  vmovaps xmm8, [rsp+0x80]
000070dabbddeca1  vmovaps xmm9, [rsp+0x90]
000070dabbddecaa  vmovaps xmm10, [rsp+0xA0]
000070dabbddecb3  vmovaps xmm11, [rsp+0xB0]
000070dabbddecbc  vmovaps xmm12, [rsp+0xC0]
000070dabbddecc5  vmovaps xmm13, [rsp+0xD0]
000070dabbddecce  vmovaps xmm15, [rsp+0xE0]
000070dabbddecd7  add rsp, 0xF0
000070dabbddecde  pop r11
000070dabbddece0  pop r10
000070dabbddece2  pop r9
000070dabbddece4  pop r8
000070dabbddece6  pop rsi
000070dabbddece7  pop rdi
000070dabbddece8  pop rdx
000070dabbddece9  pop rcx
000070dabbddecea  pop rax
000070dabbddeceb  add rsp, 0x08
000070dabbddecef  jmp 0x000070DABBDDC2D0
000070dabbddecf4  sub rsp, 0x08
000070dabbddecf8  push rax
000070dabbddecf9  push rcx
000070dabbddecfa  push rdx
000070dabbddecfb  push rdi
000070dabbddecfc  push rsi
000070dabbddecfd  push r8
000070dabbddecff  push r9
000070dabbdded01  push r10
000070dabbdded03  push r11
000070dabbdded05  sub rsp, 0xF0
000070dabbdded0c  vmovaps [rsp], xmm0
000070dabbdded11  vmovaps [rsp+0x10], xmm2
000070dabbdded17  vmovaps [rsp+0x20], xmm3
000070dabbdded1d  vmovaps [rsp+0x30], xmm4
000070dabbdded23  vmovaps [rsp+0x40], xmm5
000070dabbdded29  vmovaps [rsp+0x50], xmm6
000070dabbdded2f  vmovaps [rsp+0x60], xmm7
000070dabbdded35  vmovaps [rsp+0x70], xmm8
000070dabbdded3b  vmovaps [rsp+0x80], xmm9
000070dabbdded44  vmovaps [rsp+0x90], xmm10
000070dabbdded4d  vmovaps [rsp+0xA0], xmm11
000070dabbdded56  vmovaps [rsp+0xB0], xmm12
000070dabbdded5f  vmovaps [rsp+0xC0], xmm13
000070dabbdded68  vmovaps [rsp+0xD0], xmm14
000070dabbdded71  vmovaps [rsp+0xE0], xmm15
000070dabbdded7a  sub rsp, 0x30
000070dabbdded7e  movaps [rsp], xmm1
000070dabbdded82  movaps [rsp+0x10], xmm4
000070dabbdded87  movaps [rsp+0x20], xmm9
000070dabbdded8d  lea rdi, [rsp]
000070dabbdded91  mov esi, 0x00
000070dabbdded96  mov rax, 0x5C2CF7B6F530
000070dabbddeda0  call rax
000070dabbddeda2  movaps xmm1, [rsp]
000070dabbddeda6  add rsp, 0x30
000070dabbddedaa  vmovaps xmm0, [rsp]
000070dabbddedaf  vmovaps xmm2, [rsp+0x10]
000070dabbddedb5  vmovaps xmm3, [rsp+0x20]
000070dabbddedbb  vmovaps xmm4, [rsp+0x30]
000070dabbddedc1  vmovaps xmm5, [rsp+0x40]
000070dabbddedc7  vmovaps xmm6, [rsp+0x50]
000070dabbddedcd  vmovaps xmm7, [rsp+0x60]
000070dabbddedd3  vmovaps xmm8, [rsp+0x70]
000070dabbddedd9  vmovaps xmm9, [rsp+0x80]
000070dabbddede2  vmovaps xmm10, [rsp+0x90]
000070dabbddedeb  vmovaps xmm11, [rsp+0xA0]
000070dabbddedf4  vmovaps xmm12, [rsp+0xB0]
000070dabbddedfd  vmovaps xmm13, [rsp+0xC0]
000070dabbddee06  vmovaps xmm14, [rsp+0xD0]
000070dabbddee0f  vmovaps xmm15, [rsp+0xE0]
000070dabbddee18  add rsp, 0xF0
000070dabbddee1f  pop r11
000070dabbddee21  pop r10
000070dabbddee23  pop r9
000070dabbddee25  pop r8
000070dabbddee27  pop rsi
000070dabbddee28  pop rdi
000070dabbddee29  pop rdx
000070dabbddee2a  pop rcx
000070dabbddee2b  pop rax
000070dabbddee2c  add rsp, 0x08
000070dabbddee30  jmp 0x000070DABBDDC2EE
000070dabbddee35  sub rsp, 0x08
000070dabbddee39  push rax
000070dabbddee3a  push rcx
000070dabbddee3b  push rdx
000070dabbddee3c  push rdi
000070dabbddee3d  push rsi
000070dabbddee3e  push r8
000070dabbddee40  push r9
000070dabbddee42  push r10
000070dabbddee44  push r11
000070dabbddee46  sub rsp, 0xF0
000070dabbddee4d  vmovaps [rsp], xmm0
000070dabbddee52  vmovaps [rsp+0x10], xmm1
000070dabbddee58  vmovaps [rsp+0x20], xmm2
000070dabbddee5e  vmovaps [rsp+0x30], xmm3
000070dabbddee64  vmovaps [rsp+0x40], xmm5
000070dabbddee6a  vmovaps [rsp+0x50], xmm6
000070dabbddee70  vmovaps [rsp+0x60], xmm7
000070dabbddee76  vmovaps [rsp+0x70], xmm8
000070dabbddee7c  vmovaps [rsp+0x80], xmm9
000070dabbddee85  vmovaps [rsp+0x90], xmm10
000070dabbddee8e  vmovaps [rsp+0xA0], xmm11
000070dabbddee97  vmovaps [rsp+0xB0], xmm12
000070dabbddeea0  vmovaps [rsp+0xC0], xmm13
000070dabbddeea9  vmovaps [rsp+0xD0], xmm14
000070dabbddeeb2  vmovaps [rsp+0xE0], xmm15
000070dabbddeebb  sub rsp, 0x30
000070dabbddeebf  movaps [rsp], xmm4
000070dabbddeec3  movaps [rsp+0x10], xmm2
000070dabbddeec8  movaps [rsp+0x20], xmm9
000070dabbddeece  lea rdi, [rsp]
000070dabbddeed2  mov esi, 0x00
000070dabbddeed7  mov rax, 0x5C2CF7B6F530
000070dabbddeee1  call rax
000070dabbddeee3  movaps xmm4, [rsp]
000070dabbddeee7  add rsp, 0x30
000070dabbddeeeb  vmovaps xmm0, [rsp]
000070dabbddeef0  vmovaps xmm1, [rsp+0x10]
000070dabbddeef6  vmovaps xmm2, [rsp+0x20]
000070dabbddeefc  vmovaps xmm3, [rsp+0x30]
000070dabbddef02  vmovaps xmm5, [rsp+0x40]
000070dabbddef08  vmovaps xmm6, [rsp+0x50]
000070dabbddef0e  vmovaps xmm7, [rsp+0x60]
000070dabbddef14  vmovaps xmm8, [rsp+0x70]
000070dabbddef1a  vmovaps xmm9, [rsp+0x80]
000070dabbddef23  vmovaps xmm10, [rsp+0x90]
000070dabbddef2c  vmovaps xmm11, [rsp+0xA0]
000070dabbddef35  vmovaps xmm12, [rsp+0xB0]
000070dabbddef3e  vmovaps xmm13, [rsp+0xC0]
000070dabbddef47  vmovaps xmm14, [rsp+0xD0]
000070dabbddef50  vmovaps xmm15, [rsp+0xE0]
000070dabbddef59  add rsp, 0xF0
000070dabbddef60  pop r11
000070dabbddef62  pop r10
000070dabbddef64  pop r9
000070dabbddef66  pop r8
000070dabbddef68  pop rsi
000070dabbddef69  pop rdi
000070dabbddef6a  pop rdx
000070dabbddef6b  pop rcx
000070dabbddef6c  pop rax
000070dabbddef6d  add rsp, 0x08
000070dabbddef71  jmp 0x000070DABBDDC31E
000070dabbddef76  sub rsp, 0x08
000070dabbddef7a  push rax
000070dabbddef7b  push rcx
000070dabbddef7c  push rdx
000070dabbddef7d  push rdi
000070dabbddef7e  push rsi
000070dabbddef7f  push r8
000070dabbddef81  push r9
000070dabbddef83  push r10
000070dabbddef85  push r11
000070dabbddef87  sub rsp, 0xF0
000070dabbddef8e  vmovaps [rsp], xmm0
000070dabbddef93  vmovaps [rsp+0x10], xmm1
000070dabbddef99  vmovaps [rsp+0x20], xmm2
000070dabbddef9f  vmovaps [rsp+0x30], xmm3
000070dabbddefa5  vmovaps [rsp+0x40], xmm4
000070dabbddefab  vmovaps [rsp+0x50], xmm5
000070dabbddefb1  vmovaps [rsp+0x60], xmm6
000070dabbddefb7  vmovaps [rsp+0x70], xmm7
000070dabbddefbd  vmovaps [rsp+0x80], xmm8
000070dabbddefc6  vmovaps [rsp+0x90], xmm10
000070dabbddefcf  vmovaps [rsp+0xA0], xmm11
000070dabbddefd8  vmovaps [rsp+0xB0], xmm12
000070dabbddefe1  vmovaps [rsp+0xC0], xmm13
000070dabbddefea  vmovaps [rsp+0xD0], xmm14
000070dabbddeff3  vmovaps [rsp+0xE0], xmm15
000070dabbddeffc  sub rsp, 0x30
000070dabbddf000  movaps [rsp], xmm9
000070dabbddf005  movaps [rsp+0x10], xmm2
000070dabbddf00a  movaps [rsp+0x20], xmm1
000070dabbddf00f  lea rdi, [rsp]
000070dabbddf013  mov esi, 0x00
000070dabbddf018  mov rax, 0x5C2CF7B6F530
000070dabbddf022  call rax
000070dabbddf024  movaps xmm9, [rsp]
000070dabbddf029  add rsp, 0x30
000070dabbddf02d  vmovaps xmm0, [rsp]
000070dabbddf032  vmovaps xmm1, [rsp+0x10]
000070dabbddf038  vmovaps xmm2, [rsp+0x20]
000070dabbddf03e  vmovaps xmm3, [rsp+0x30]
000070dabbddf044  vmovaps xmm4, [rsp+0x40]
000070dabbddf04a  vmovaps xmm5, [rsp+0x50]
000070dabbddf050  vmovaps xmm6, [rsp+0x60]
000070dabbddf056  vmovaps xmm7, [rsp+0x70]
000070dabbddf05c  vmovaps xmm8, [rsp+0x80]
000070dabbddf065  vmovaps xmm10, [rsp+0x90]
000070dabbddf06e  vmovaps xmm11, [rsp+0xA0]
000070dabbddf077  vmovaps xmm12, [rsp+0xB0]
000070dabbddf080  vmovaps xmm13, [rsp+0xC0]
000070dabbddf089  vmovaps xmm14, [rsp+0xD0]
000070dabbddf092  vmovaps xmm15, [rsp+0xE0]
000070dabbddf09b  add rsp, 0xF0
000070dabbddf0a2  pop r11
000070dabbddf0a4  pop r10
000070dabbddf0a6  pop r9
000070dabbddf0a8  pop r8
000070dabbddf0aa  pop rsi
000070dabbddf0ab  pop rdi
000070dabbddf0ac  pop rdx
000070dabbddf0ad  pop rcx
000070dabbddf0ae  pop rax
000070dabbddf0af  add rsp, 0x08
000070dabbddf0b3  jmp 0x000070DABBDDC354
000070dabbddf0b8  sub rsp, 0x08
000070dabbddf0bc  push rax
000070dabbddf0bd  push rcx
000070dabbddf0be  push rdx
000070dabbddf0bf  push rdi
000070dabbddf0c0  push rsi
000070dabbddf0c1  push r8
000070dabbddf0c3  push r9
000070dabbddf0c5  push r10
000070dabbddf0c7  push r11
000070dabbddf0c9  sub rsp, 0xF0
000070dabbddf0d0  vmovaps [rsp], xmm0
000070dabbddf0d5  vmovaps [rsp+0x10], xmm2
000070dabbddf0db  vmovaps [rsp+0x20], xmm3
000070dabbddf0e1  vmovaps [rsp+0x30], xmm4
000070dabbddf0e7  vmovaps [rsp+0x40], xmm5
000070dabbddf0ed  vmovaps [rsp+0x50], xmm6
000070dabbddf0f3  vmovaps [rsp+0x60], xmm7
000070dabbddf0f9  vmovaps [rsp+0x70], xmm8
000070dabbddf0ff  vmovaps [rsp+0x80], xmm9
000070dabbddf108  vmovaps [rsp+0x90], xmm10
000070dabbddf111  vmovaps [rsp+0xA0], xmm11
000070dabbddf11a  vmovaps [rsp+0xB0], xmm12
000070dabbddf123  vmovaps [rsp+0xC0], xmm13
000070dabbddf12c  vmovaps [rsp+0xD0], xmm14
000070dabbddf135  vmovaps [rsp+0xE0], xmm15
000070dabbddf13e  sub rsp, 0x30
000070dabbddf142  movaps [rsp], xmm1
000070dabbddf146  movaps [rsp+0x10], xmm15
000070dabbddf14c  movaps [rsp+0x20], xmm6
000070dabbddf151  lea rdi, [rsp]
000070dabbddf155  mov esi, 0x00
000070dabbddf15a  mov rax, 0x5C2CF7B6F530
000070dabbddf164  call rax
000070dabbddf166  movaps xmm1, [rsp]
000070dabbddf16a  add rsp, 0x30
000070dabbddf16e  vmovaps xmm0, [rsp]
000070dabbddf173  vmovaps xmm2, [rsp+0x10]
000070dabbddf179  vmovaps xmm3, [rsp+0x20]
000070dabbddf17f  vmovaps xmm4, [rsp+0x30]
000070dabbddf185  vmovaps xmm5, [rsp+0x40]
000070dabbddf18b  vmovaps xmm6, [rsp+0x50]
000070dabbddf191  vmovaps xmm7, [rsp+0x60]
000070dabbddf197  vmovaps xmm8, [rsp+0x70]
000070dabbddf19d  vmovaps xmm9, [rsp+0x80]
000070dabbddf1a6  vmovaps xmm10, [rsp+0x90]
000070dabbddf1af  vmovaps xmm11, [rsp+0xA0]
000070dabbddf1b8  vmovaps xmm12, [rsp+0xB0]
000070dabbddf1c1  vmovaps xmm13, [rsp+0xC0]
000070dabbddf1ca  vmovaps xmm14, [rsp+0xD0]
000070dabbddf1d3  vmovaps xmm15, [rsp+0xE0]
000070dabbddf1dc  add rsp, 0xF0
000070dabbddf1e3  pop r11
000070dabbddf1e5  pop r10
000070dabbddf1e7  pop r9
000070dabbddf1e9  pop r8
000070dabbddf1eb  pop rsi
000070dabbddf1ec  pop rdi
000070dabbddf1ed  pop rdx
000070dabbddf1ee  pop rcx
000070dabbddf1ef  pop rax
000070dabbddf1f0  add rsp, 0x08
000070dabbddf1f4  jmp 0x000070DABBDDC375
000070dabbddf1f9  sub rsp, 0x08
000070dabbddf1fd  push rax
000070dabbddf1fe  push rcx
000070dabbddf1ff  push rdx
000070dabbddf200  push rdi
000070dabbddf201  push rsi
000070dabbddf202  push r8
000070dabbddf204  push r9
000070dabbddf206  push r10
000070dabbddf208  push r11
000070dabbddf20a  sub rsp, 0xF0
000070dabbddf211  vmovaps [rsp], xmm0
000070dabbddf216  vmovaps [rsp+0x10], xmm1
000070dabbddf21c  vmovaps [rsp+0x20], xmm2
000070dabbddf222  vmovaps [rsp+0x30], xmm3
000070dabbddf228  vmovaps [rsp+0x40], xmm4
000070dabbddf22e  vmovaps [rsp+0x50], xmm5
000070dabbddf234  vmovaps [rsp+0x60], xmm6
000070dabbddf23a  vmovaps [rsp+0x70], xmm7
000070dabbddf240  vmovaps [rsp+0x80], xmm8
000070dabbddf249  vmovaps [rsp+0x90], xmm9
000070dabbddf252  vmovaps [rsp+0xA0], xmm10
000070dabbddf25b  vmovaps [rsp+0xB0], xmm11
000070dabbddf264  vmovaps [rsp+0xC0], xmm12
000070dabbddf26d  vmovaps [rsp+0xD0], xmm13
000070dabbddf276  vmovaps [rsp+0xE0], xmm14
000070dabbddf27f  sub rsp, 0x30
000070dabbddf283  movaps [rsp], xmm15
000070dabbddf288  movaps [rsp+0x10], xmm5
000070dabbddf28d  movaps [rsp+0x20], xmm3
000070dabbddf292  lea rdi, [rsp]
000070dabbddf296  mov esi, 0x00
000070dabbddf29b  mov rax, 0x5C2CF7B6F530
000070dabbddf2a5  call rax
000070dabbddf2a7  movaps xmm15, [rsp]
000070dabbddf2ac  add rsp, 0x30
000070dabbddf2b0  vmovaps xmm0, [rsp]
000070dabbddf2b5  vmovaps xmm1, [rsp+0x10]
000070dabbddf2bb  vmovaps xmm2, [rsp+0x20]
000070dabbddf2c1  vmovaps xmm3, [rsp+0x30]
000070dabbddf2c7  vmovaps xmm4, [rsp+0x40]
000070dabbddf2cd  vmovaps xmm5, [rsp+0x50]
000070dabbddf2d3  vmovaps xmm6, [rsp+0x60]
000070dabbddf2d9  vmovaps xmm7, [rsp+0x70]
000070dabbddf2df  vmovaps xmm8, [rsp+0x80]
000070dabbddf2e8  vmovaps xmm9, [rsp+0x90]
000070dabbddf2f1  vmovaps xmm10, [rsp+0xA0]
000070dabbddf2fa  vmovaps xmm11, [rsp+0xB0]
000070dabbddf303  vmovaps xmm12, [rsp+0xC0]
000070dabbddf30c  vmovaps xmm13, [rsp+0xD0]
000070dabbddf315  vmovaps xmm14, [rsp+0xE0]
000070dabbddf31e  add rsp, 0xF0
000070dabbddf325  pop r11
000070dabbddf327  pop r10
000070dabbddf329  pop r9
000070dabbddf32b  pop r8
000070dabbddf32d  pop rsi
000070dabbddf32e  pop rdi
000070dabbddf32f  pop rdx
000070dabbddf330  pop rcx
000070dabbddf331  pop rax
000070dabbddf332  add rsp, 0x08
000070dabbddf336  jmp 0x000070DABBDDC38F
000070dabbddf33b  sub rsp, 0x08
000070dabbddf33f  push rax
000070dabbddf340  push rcx
000070dabbddf341  push rdx
000070dabbddf342  push rdi
000070dabbddf343  push rsi
000070dabbddf344  push r8
000070dabbddf346  push r9
000070dabbddf348  push r10
000070dabbddf34a  push r11
000070dabbddf34c  sub rsp, 0xF0
000070dabbddf353  vmovaps [rsp], xmm0
000070dabbddf358  vmovaps [rsp+0x10], xmm1
000070dabbddf35e  vmovaps [rsp+0x20], xmm2
000070dabbddf364  vmovaps [rsp+0x30], xmm3
000070dabbddf36a  vmovaps [rsp+0x40], xmm4
000070dabbddf370  vmovaps [rsp+0x50], xmm6
000070dabbddf376  vmovaps [rsp+0x60], xmm7
000070dabbddf37c  vmovaps [rsp+0x70], xmm8
000070dabbddf382  vmovaps [rsp+0x80], xmm9
000070dabbddf38b  vmovaps [rsp+0x90], xmm10
000070dabbddf394  vmovaps [rsp+0xA0], xmm11
000070dabbddf39d  vmovaps [rsp+0xB0], xmm12
000070dabbddf3a6  vmovaps [rsp+0xC0], xmm13
000070dabbddf3af  vmovaps [rsp+0xD0], xmm14
000070dabbddf3b8  vmovaps [rsp+0xE0], xmm15
000070dabbddf3c1  sub rsp, 0x30
000070dabbddf3c5  movaps [rsp], xmm5
000070dabbddf3c9  movaps [rsp+0x10], xmm8
000070dabbddf3cf  movaps [rsp+0x20], xmm6
000070dabbddf3d4  lea rdi, [rsp]
000070dabbddf3d8  mov esi, 0x00
000070dabbddf3dd  mov rax, 0x5C2CF7B6F530
000070dabbddf3e7  call rax
000070dabbddf3e9  movaps xmm5, [rsp]
000070dabbddf3ed  add rsp, 0x30
000070dabbddf3f1  vmovaps xmm0, [rsp]
000070dabbddf3f6  vmovaps xmm1, [rsp+0x10]
000070dabbddf3fc  vmovaps xmm2, [rsp+0x20]
000070dabbddf402  vmovaps xmm3, [rsp+0x30]
000070dabbddf408  vmovaps xmm4, [rsp+0x40]
000070dabbddf40e  vmovaps xmm6, [rsp+0x50]
000070dabbddf414  vmovaps xmm7, [rsp+0x60]
000070dabbddf41a  vmovaps xmm8, [rsp+0x70]
000070dabbddf420  vmovaps xmm9, [rsp+0x80]
000070dabbddf429  vmovaps xmm10, [rsp+0x90]
000070dabbddf432  vmovaps xmm11, [rsp+0xA0]
000070dabbddf43b  vmovaps xmm12, [rsp+0xB0]
000070dabbddf444  vmovaps xmm13, [rsp+0xC0]
000070dabbddf44d  vmovaps xmm14, [rsp+0xD0]
000070dabbddf456  vmovaps xmm15, [rsp+0xE0]
000070dabbddf45f  add rsp, 0xF0
000070dabbddf466  pop r11
000070dabbddf468  pop r10
000070dabbddf46a  pop r9
000070dabbddf46c  pop r8
000070dabbddf46e  pop rsi
000070dabbddf46f  pop rdi
000070dabbddf470  pop rdx
000070dabbddf471  pop rcx
000070dabbddf472  pop rax
000070dabbddf473  add rsp, 0x08
000070dabbddf477  jmp 0x000070DABBDDC3B3
000070dabbddf47c  sub rsp, 0x08
000070dabbddf480  push rax
000070dabbddf481  push rcx
000070dabbddf482  push rdx
000070dabbddf483  push rdi
000070dabbddf484  push rsi
000070dabbddf485  push r8
000070dabbddf487  push r9
000070dabbddf489  push r10
000070dabbddf48b  push r11
000070dabbddf48d  sub rsp, 0xF0
000070dabbddf494  vmovaps [rsp], xmm0
000070dabbddf499  vmovaps [rsp+0x10], xmm1
000070dabbddf49f  vmovaps [rsp+0x20], xmm2
000070dabbddf4a5  vmovaps [rsp+0x30], xmm3
000070dabbddf4ab  vmovaps [rsp+0x40], xmm4
000070dabbddf4b1  vmovaps [rsp+0x50], xmm5
000070dabbddf4b7  vmovaps [rsp+0x60], xmm7
000070dabbddf4bd  vmovaps [rsp+0x70], xmm8
000070dabbddf4c3  vmovaps [rsp+0x80], xmm9
000070dabbddf4cc  vmovaps [rsp+0x90], xmm10
000070dabbddf4d5  vmovaps [rsp+0xA0], xmm11
000070dabbddf4de  vmovaps [rsp+0xB0], xmm12
000070dabbddf4e7  vmovaps [rsp+0xC0], xmm13
000070dabbddf4f0  vmovaps [rsp+0xD0], xmm14
000070dabbddf4f9  vmovaps [rsp+0xE0], xmm15
000070dabbddf502  sub rsp, 0x30
000070dabbddf506  movaps [rsp], xmm6
000070dabbddf50a  movaps [rsp+0x10], xmm10
000070dabbddf510  movaps [rsp+0x20], xmm8
000070dabbddf516  lea rdi, [rsp]
000070dabbddf51a  mov esi, 0x00
000070dabbddf51f  mov rax, 0x5C2CF7B6F530
000070dabbddf529  call rax
000070dabbddf52b  movaps xmm6, [rsp]
000070dabbddf52f  add rsp, 0x30
000070dabbddf533  vmovaps xmm0, [rsp]
000070dabbddf538  vmovaps xmm1, [rsp+0x10]
000070dabbddf53e  vmovaps xmm2, [rsp+0x20]
000070dabbddf544  vmovaps xmm3, [rsp+0x30]
000070dabbddf54a  vmovaps xmm4, [rsp+0x40]
000070dabbddf550  vmovaps xmm5, [rsp+0x50]
000070dabbddf556  vmovaps xmm7, [rsp+0x60]
000070dabbddf55c  vmovaps xmm8, [rsp+0x70]
000070dabbddf562  vmovaps xmm9, [rsp+0x80]
000070dabbddf56b  vmovaps xmm10, [rsp+0x90]
000070dabbddf574  vmovaps xmm11, [rsp+0xA0]
000070dabbddf57d  vmovaps xmm12, [rsp+0xB0]
000070dabbddf586  vmovaps xmm13, [rsp+0xC0]
000070dabbddf58f  vmovaps xmm14, [rsp+0xD0]
000070dabbddf598  vmovaps xmm15, [rsp+0xE0]
000070dabbddf5a1  add rsp, 0xF0
000070dabbddf5a8  pop r11
000070dabbddf5aa  pop r10
000070dabbddf5ac  pop r9
000070dabbddf5ae  pop r8
000070dabbddf5b0  pop rsi
000070dabbddf5b1  pop rdi
000070dabbddf5b2  pop rdx
000070dabbddf5b3  pop rcx
000070dabbddf5b4  pop rax
000070dabbddf5b5  add rsp, 0x08
000070dabbddf5b9  jmp 0x000070DABBDDC3D8
000070dabbddf5be  sub rsp, 0x08
000070dabbddf5c2  push rax
000070dabbddf5c3  push rcx
000070dabbddf5c4  push rdx
000070dabbddf5c5  push rdi
000070dabbddf5c6  push rsi
000070dabbddf5c7  push r8
000070dabbddf5c9  push r9
000070dabbddf5cb  push r10
000070dabbddf5cd  push r11
000070dabbddf5cf  sub rsp, 0xF0
000070dabbddf5d6  vmovaps [rsp], xmm0
000070dabbddf5db  vmovaps [rsp+0x10], xmm1
000070dabbddf5e1  vmovaps [rsp+0x20], xmm2
000070dabbddf5e7  vmovaps [rsp+0x30], xmm3
000070dabbddf5ed  vmovaps [rsp+0x40], xmm4
000070dabbddf5f3  vmovaps [rsp+0x50], xmm5
000070dabbddf5f9  vmovaps [rsp+0x60], xmm6
000070dabbddf5ff  vmovaps [rsp+0x70], xmm7
000070dabbddf605  vmovaps [rsp+0x80], xmm8
000070dabbddf60e  vmovaps [rsp+0x90], xmm9
000070dabbddf617  vmovaps [rsp+0xA0], xmm11
000070dabbddf620  vmovaps [rsp+0xB0], xmm12
000070dabbddf629  vmovaps [rsp+0xC0], xmm13
000070dabbddf632  vmovaps [rsp+0xD0], xmm14
000070dabbddf63b  vmovaps [rsp+0xE0], xmm15
000070dabbddf644  sub rsp, 0x30
000070dabbddf648  movaps [rsp], xmm10
000070dabbddf64d  movaps [rsp+0x10], xmm8
000070dabbddf653  movaps [rsp+0x20], xmm14
000070dabbddf659  lea rdi, [rsp]
000070dabbddf65d  mov esi, 0x00
000070dabbddf662  mov rax, 0x5C2CF7B6F530
000070dabbddf66c  call rax
000070dabbddf66e  movaps xmm10, [rsp]
000070dabbddf673  add rsp, 0x30
000070dabbddf677  vmovaps xmm0, [rsp]
000070dabbddf67c  vmovaps xmm1, [rsp+0x10]
000070dabbddf682  vmovaps xmm2, [rsp+0x20]
000070dabbddf688  vmovaps xmm3, [rsp+0x30]
000070dabbddf68e  vmovaps xmm4, [rsp+0x40]
000070dabbddf694  vmovaps xmm5, [rsp+0x50]
000070dabbddf69a  vmovaps xmm6, [rsp+0x60]
000070dabbddf6a0  vmovaps xmm7, [rsp+0x70]
000070dabbddf6a6  vmovaps xmm8, [rsp+0x80]
000070dabbddf6af  vmovaps xmm9, [rsp+0x90]
000070dabbddf6b8  vmovaps xmm11, [rsp+0xA0]
000070dabbddf6c1  vmovaps xmm12, [rsp+0xB0]
000070dabbddf6ca  vmovaps xmm13, [rsp+0xC0]
000070dabbddf6d3  vmovaps xmm14, [rsp+0xD0]
000070dabbddf6dc  vmovaps xmm15, [rsp+0xE0]
000070dabbddf6e5  add rsp, 0xF0
000070dabbddf6ec  pop r11
000070dabbddf6ee  pop r10
000070dabbddf6f0  pop r9
000070dabbddf6f2  pop r8
000070dabbddf6f4  pop rsi
000070dabbddf6f5  pop rdi
000070dabbddf6f6  pop rdx
000070dabbddf6f7  pop rcx
000070dabbddf6f8  pop rax
000070dabbddf6f9  add rsp, 0x08
000070dabbddf6fd  jmp 0x000070DABBDDC3F8
000070dabbddf702  sub rsp, 0x08
000070dabbddf706  push rax
000070dabbddf707  push rcx
000070dabbddf708  push rdx
000070dabbddf709  push rdi
000070dabbddf70a  push rsi
000070dabbddf70b  push r8
000070dabbddf70d  push r9
000070dabbddf70f  push r10
000070dabbddf711  push r11
000070dabbddf713  sub rsp, 0xF0
000070dabbddf71a  vmovaps [rsp], xmm0
000070dabbddf71f  vmovaps [rsp+0x10], xmm1
000070dabbddf725  vmovaps [rsp+0x20], xmm2
000070dabbddf72b  vmovaps [rsp+0x30], xmm3
000070dabbddf731  vmovaps [rsp+0x40], xmm4
000070dabbddf737  vmovaps [rsp+0x50], xmm5
000070dabbddf73d  vmovaps [rsp+0x60], xmm6
000070dabbddf743  vmovaps [rsp+0x70], xmm7
000070dabbddf749  vmovaps [rsp+0x80], xmm8
000070dabbddf752  vmovaps [rsp+0x90], xmm9
000070dabbddf75b  vmovaps [rsp+0xA0], xmm10
000070dabbddf764  vmovaps [rsp+0xB0], xmm11
000070dabbddf76d  vmovaps [rsp+0xC0], xmm12
000070dabbddf776  vmovaps [rsp+0xD0], xmm13
000070dabbddf77f  vmovaps [rsp+0xE0], xmm15
000070dabbddf788  sub rsp, 0x30
000070dabbddf78c  movaps [rsp], xmm14
000070dabbddf791  movaps [rsp+0x10], xmm8
000070dabbddf797  movaps [rsp+0x20], xmm4
000070dabbddf79c  lea rdi, [rsp]
000070dabbddf7a0  mov esi, 0x00
000070dabbddf7a5  mov rax, 0x5C2CF7B6F530
000070dabbddf7af  call rax
000070dabbddf7b1  movaps xmm14, [rsp]
000070dabbddf7b6  add rsp, 0x30
000070dabbddf7ba  vmovaps xmm0, [rsp]
000070dabbddf7bf  vmovaps xmm1, [rsp+0x10]
000070dabbddf7c5  vmovaps xmm2, [rsp+0x20]
000070dabbddf7cb  vmovaps xmm3, [rsp+0x30]
000070dabbddf7d1  vmovaps xmm4, [rsp+0x40]
000070dabbddf7d7  vmovaps xmm5, [rsp+0x50]
000070dabbddf7dd  vmovaps xmm6, [rsp+0x60]
000070dabbddf7e3  vmovaps xmm7, [rsp+0x70]
000070dabbddf7e9  vmovaps xmm8, [rsp+0x80]
000070dabbddf7f2  vmovaps xmm9, [rsp+0x90]
000070dabbddf7fb  vmovaps xmm10, [rsp+0xA0]
000070dabbddf804  vmovaps xmm11, [rsp+0xB0]
000070dabbddf80d  vmovaps xmm12, [rsp+0xC0]
000070dabbddf816  vmovaps xmm13, [rsp+0xD0]
000070dabbddf81f  vmovaps xmm15, [rsp+0xE0]
000070dabbddf828  add rsp, 0xF0
000070dabbddf82f  pop r11
000070dabbddf831  pop r10
000070dabbddf833  pop r9
000070dabbddf835  pop r8
000070dabbddf837  pop rsi
000070dabbddf838  pop rdi
000070dabbddf839  pop rdx
000070dabbddf83a  pop rcx
000070dabbddf83b  pop rax
000070dabbddf83c  add rsp, 0x08
000070dabbddf840  jmp 0x000070DABBDDC418
000070dabbddf845  sub rsp, 0x08
000070dabbddf849  push rax
000070dabbddf84a  push rcx
000070dabbddf84b  push rdx
000070dabbddf84c  push rdi
000070dabbddf84d  push rsi
000070dabbddf84e  push r8
000070dabbddf850  push r9
000070dabbddf852  push r10
000070dabbddf854  push r11
000070dabbddf856  sub rsp, 0xF0
000070dabbddf85d  vmovaps [rsp], xmm0
000070dabbddf862  vmovaps [rsp+0x10], xmm1
000070dabbddf868  vmovaps [rsp+0x20], xmm2
000070dabbddf86e  vmovaps [rsp+0x30], xmm3
000070dabbddf874  vmovaps [rsp+0x40], xmm5
000070dabbddf87a  vmovaps [rsp+0x50], xmm6
000070dabbddf880  vmovaps [rsp+0x60], xmm7
000070dabbddf886  vmovaps [rsp+0x70], xmm8
000070dabbddf88c  vmovaps [rsp+0x80], xmm9
000070dabbddf895  vmovaps [rsp+0x90], xmm10
000070dabbddf89e  vmovaps [rsp+0xA0], xmm11
000070dabbddf8a7  vmovaps [rsp+0xB0], xmm12
000070dabbddf8b0  vmovaps [rsp+0xC0], xmm13
000070dabbddf8b9  vmovaps [rsp+0xD0], xmm14
000070dabbddf8c2  vmovaps [rsp+0xE0], xmm15
000070dabbddf8cb  sub rsp, 0x30
000070dabbddf8cf  movaps [rsp], xmm4
000070dabbddf8d3  movaps [rsp+0x10], xmm13
000070dabbddf8d9  movaps [rsp+0x20], xmm8
000070dabbddf8df  lea rdi, [rsp]
000070dabbddf8e3  mov esi, 0x00
000070dabbddf8e8  mov rax, 0x5C2CF7B6F530
000070dabbddf8f2  call rax
000070dabbddf8f4  movaps xmm4, [rsp]
000070dabbddf8f8  add rsp, 0x30
000070dabbddf8fc  vmovaps xmm0, [rsp]
000070dabbddf901  vmovaps xmm1, [rsp+0x10]
000070dabbddf907  vmovaps xmm2, [rsp+0x20]
000070dabbddf90d  vmovaps xmm3, [rsp+0x30]
000070dabbddf913  vmovaps xmm5, [rsp+0x40]
000070dabbddf919  vmovaps xmm6, [rsp+0x50]
000070dabbddf91f  vmovaps xmm7, [rsp+0x60]
000070dabbddf925  vmovaps xmm8, [rsp+0x70]
000070dabbddf92b  vmovaps xmm9, [rsp+0x80]
000070dabbddf934  vmovaps xmm10, [rsp+0x90]
000070dabbddf93d  vmovaps xmm11, [rsp+0xA0]
000070dabbddf946  vmovaps xmm12, [rsp+0xB0]
000070dabbddf94f  vmovaps xmm13, [rsp+0xC0]
000070dabbddf958  vmovaps xmm14, [rsp+0xD0]
000070dabbddf961  vmovaps xmm15, [rsp+0xE0]
000070dabbddf96a  add rsp, 0xF0
000070dabbddf971  pop r11
000070dabbddf973  pop r10
000070dabbddf975  pop r9
000070dabbddf977  pop r8
000070dabbddf979  pop rsi
000070dabbddf97a  pop rdi
000070dabbddf97b  pop rdx
000070dabbddf97c  pop rcx
000070dabbddf97d  pop rax
000070dabbddf97e  add rsp, 0x08
000070dabbddf982  jmp 0x000070DABBDDC43D
000070dabbddf987  sub rsp, 0x08
000070dabbddf98b  push rax
000070dabbddf98c  push rcx
000070dabbddf98d  push rdx
000070dabbddf98e  push rdi
000070dabbddf98f  push rsi
000070dabbddf990  push r8
000070dabbddf992  push r9
000070dabbddf994  push r10
000070dabbddf996  push r11
000070dabbddf998  sub rsp, 0xF0
000070dabbddf99f  vmovaps [rsp], xmm0
000070dabbddf9a4  vmovaps [rsp+0x10], xmm1
000070dabbddf9aa  vmovaps [rsp+0x20], xmm2
000070dabbddf9b0  vmovaps [rsp+0x30], xmm3
000070dabbddf9b6  vmovaps [rsp+0x40], xmm4
000070dabbddf9bc  vmovaps [rsp+0x50], xmm5
000070dabbddf9c2  vmovaps [rsp+0x60], xmm6
000070dabbddf9c8  vmovaps [rsp+0x70], xmm7
000070dabbddf9ce  vmovaps [rsp+0x80], xmm8
000070dabbddf9d7  vmovaps [rsp+0x90], xmm9
000070dabbddf9e0  vmovaps [rsp+0xA0], xmm10
000070dabbddf9e9  vmovaps [rsp+0xB0], xmm11
000070dabbddf9f2  vmovaps [rsp+0xC0], xmm12
000070dabbddf9fb  vmovaps [rsp+0xD0], xmm14
000070dabbddfa04  vmovaps [rsp+0xE0], xmm15
000070dabbddfa0d  sub rsp, 0x30
000070dabbddfa11  movaps [rsp], xmm13
000070dabbddfa16  movaps [rsp+0x10], xmm15
000070dabbddfa1c  movaps [rsp+0x20], xmm9
000070dabbddfa22  lea rdi, [rsp]
000070dabbddfa26  mov esi, 0x00
000070dabbddfa2b  mov rax, 0x5C2CF7B6F530
000070dabbddfa35  call rax
000070dabbddfa37  movaps xmm13, [rsp]
000070dabbddfa3c  add rsp, 0x30
000070dabbddfa40  vmovaps xmm0, [rsp]
000070dabbddfa45  vmovaps xmm1, [rsp+0x10]
000070dabbddfa4b  vmovaps xmm2, [rsp+0x20]
000070dabbddfa51  vmovaps xmm3, [rsp+0x30]
000070dabbddfa57  vmovaps xmm4, [rsp+0x40]
000070dabbddfa5d  vmovaps xmm5, [rsp+0x50]
000070dabbddfa63  vmovaps xmm6, [rsp+0x60]
000070dabbddfa69  vmovaps xmm7, [rsp+0x70]
000070dabbddfa6f  vmovaps xmm8, [rsp+0x80]
000070dabbddfa78  vmovaps xmm9, [rsp+0x90]
000070dabbddfa81  vmovaps xmm10, [rsp+0xA0]
000070dabbddfa8a  vmovaps xmm11, [rsp+0xB0]
000070dabbddfa93  vmovaps xmm12, [rsp+0xC0]
000070dabbddfa9c  vmovaps xmm14, [rsp+0xD0]
000070dabbddfaa5  vmovaps xmm15, [rsp+0xE0]
000070dabbddfaae  add rsp, 0xF0
000070dabbddfab5  pop r11
000070dabbddfab7  pop r10
000070dabbddfab9  pop r9
000070dabbddfabb  pop r8
000070dabbddfabd  pop rsi
000070dabbddfabe  pop rdi
000070dabbddfabf  pop rdx
000070dabbddfac0  pop rcx
000070dabbddfac1  pop rax
000070dabbddfac2  add rsp, 0x08
000070dabbddfac6  jmp 0x000070DABBDDC458
000070dabbddfacb  sub rsp, 0x08
000070dabbddfacf  push rax
000070dabbddfad0  push rcx
000070dabbddfad1  push rdx
000070dabbddfad2  push rdi
000070dabbddfad3  push rsi
000070dabbddfad4  push r8
000070dabbddfad6  push r9
000070dabbddfad8  push r10
000070dabbddfada  push r11
000070dabbddfadc  sub rsp, 0xF0
000070dabbddfae3  vmovaps [rsp], xmm0
000070dabbddfae8  vmovaps [rsp+0x10], xmm1
000070dabbddfaee  vmovaps [rsp+0x20], xmm2
000070dabbddfaf4  vmovaps [rsp+0x30], xmm3
000070dabbddfafa  vmovaps [rsp+0x40], xmm4
000070dabbddfb00  vmovaps [rsp+0x50], xmm5
000070dabbddfb06  vmovaps [rsp+0x60], xmm6
000070dabbddfb0c  vmovaps [rsp+0x70], xmm7
000070dabbddfb12  vmovaps [rsp+0x80], xmm8
000070dabbddfb1b  vmovaps [rsp+0x90], xmm9
000070dabbddfb24  vmovaps [rsp+0xA0], xmm10
000070dabbddfb2d  vmovaps [rsp+0xB0], xmm11
000070dabbddfb36  vmovaps [rsp+0xC0], xmm12
000070dabbddfb3f  vmovaps [rsp+0xD0], xmm13
000070dabbddfb48  vmovaps [rsp+0xE0], xmm14
000070dabbddfb51  sub rsp, 0x30
000070dabbddfb55  movaps [rsp], xmm15
000070dabbddfb5a  movaps [rsp+0x10], xmm1
000070dabbddfb5f  movaps [rsp+0x20], xmm5
000070dabbddfb64  lea rdi, [rsp]
000070dabbddfb68  mov esi, 0x00
000070dabbddfb6d  mov rax, 0x5C2CF7B6F530
000070dabbddfb77  call rax
000070dabbddfb79  movaps xmm15, [rsp]
000070dabbddfb7e  add rsp, 0x30
000070dabbddfb82  vmovaps xmm0, [rsp]
000070dabbddfb87  vmovaps xmm1, [rsp+0x10]
000070dabbddfb8d  vmovaps xmm2, [rsp+0x20]
000070dabbddfb93  vmovaps xmm3, [rsp+0x30]
000070dabbddfb99  vmovaps xmm4, [rsp+0x40]
000070dabbddfb9f  vmovaps xmm5, [rsp+0x50]
000070dabbddfba5  vmovaps xmm6, [rsp+0x60]
000070dabbddfbab  vmovaps xmm7, [rsp+0x70]
000070dabbddfbb1  vmovaps xmm8, [rsp+0x80]
000070dabbddfbba  vmovaps xmm9, [rsp+0x90]
000070dabbddfbc3  vmovaps xmm10, [rsp+0xA0]
000070dabbddfbcc  vmovaps xmm11, [rsp+0xB0]
000070dabbddfbd5  vmovaps xmm12, [rsp+0xC0]
000070dabbddfbde  vmovaps xmm13, [rsp+0xD0]
000070dabbddfbe7  vmovaps xmm14, [rsp+0xE0]
000070dabbddfbf0  add rsp, 0xF0
000070dabbddfbf7  pop r11
000070dabbddfbf9  pop r10
000070dabbddfbfb  pop r9
000070dabbddfbfd  pop r8
000070dabbddfbff  pop rsi
000070dabbddfc00  pop rdi
000070dabbddfc01  pop rdx
000070dabbddfc02  pop rcx
000070dabbddfc03  pop rax
000070dabbddfc04  add rsp, 0x08
000070dabbddfc08  jmp 0x000070DABBDDC473
000070dabbddfc0d  call 0x000070DABBCB52F0
000070dabbddfc12  jmp 0x000070DABBDDC4CE
000070dabbddfc17  sub rsp, 0x08
000070dabbddfc1b  push rax
000070dabbddfc1c  push rcx
000070dabbddfc1d  push rdx
000070dabbddfc1e  push rdi
000070dabbddfc1f  push rsi
000070dabbddfc20  push r8
000070dabbddfc22  push r9
000070dabbddfc24  push r10
000070dabbddfc26  push r11
000070dabbddfc28  sub rsp, 0xF0
000070dabbddfc2f  vmovaps [rsp], xmm0
000070dabbddfc34  vmovaps [rsp+0x10], xmm1
000070dabbddfc3a  vmovaps [rsp+0x20], xmm2
000070dabbddfc40  vmovaps [rsp+0x30], xmm3
000070dabbddfc46  vmovaps [rsp+0x40], xmm4
000070dabbddfc4c  vmovaps [rsp+0x50], xmm5
000070dabbddfc52  vmovaps [rsp+0x60], xmm6
000070dabbddfc58  vmovaps [rsp+0x70], xmm7
000070dabbddfc5e  vmovaps [rsp+0x80], xmm8
000070dabbddfc67  vmovaps [rsp+0x90], xmm10
000070dabbddfc70  vmovaps [rsp+0xA0], xmm11
000070dabbddfc79  vmovaps [rsp+0xB0], xmm12
000070dabbddfc82  vmovaps [rsp+0xC0], xmm13
000070dabbddfc8b  vmovaps [rsp+0xD0], xmm14
000070dabbddfc94  vmovaps [rsp+0xE0], xmm15
000070dabbddfc9d  sub rsp, 0x30
000070dabbddfca1  movaps [rsp], xmm9
000070dabbddfca6  movaps [rsp+0x10], xmm8
000070dabbddfcac  movaps [rsp+0x20], xmm11
000070dabbddfcb2  lea rdi, [rsp]
000070dabbddfcb6  mov esi, 0x00
000070dabbddfcbb  mov rax, 0x5C2CF7B6F530
000070dabbddfcc5  call rax
000070dabbddfcc7  movaps xmm9, [rsp]
000070dabbddfccc  add rsp, 0x30
000070dabbddfcd0  vmovaps xmm0, [rsp]
000070dabbddfcd5  vmovaps xmm1, [rsp+0x10]
000070dabbddfcdb  vmovaps xmm2, [rsp+0x20]
000070dabbddfce1  vmovaps xmm3, [rsp+0x30]
000070dabbddfce7  vmovaps xmm4, [rsp+0x40]
000070dabbddfced  vmovaps xmm5, [rsp+0x50]
000070dabbddfcf3  vmovaps xmm6, [rsp+0x60]
000070dabbddfcf9  vmovaps xmm7, [rsp+0x70]
000070dabbddfcff  vmovaps xmm8, [rsp+0x80]
000070dabbddfd08  vmovaps xmm10, [rsp+0x90]
000070dabbddfd11  vmovaps xmm11, [rsp+0xA0]
000070dabbddfd1a  vmovaps xmm12, [rsp+0xB0]
000070dabbddfd23  vmovaps xmm13, [rsp+0xC0]
000070dabbddfd2c  vmovaps xmm14, [rsp+0xD0]
000070dabbddfd35  vmovaps xmm15, [rsp+0xE0]
000070dabbddfd3e  add rsp, 0xF0
000070dabbddfd45  pop r11
000070dabbddfd47  pop r10
000070dabbddfd49  pop r9
000070dabbddfd4b  pop r8
000070dabbddfd4d  pop rsi
000070dabbddfd4e  pop rdi
000070dabbddfd4f  pop rdx
000070dabbddfd50  pop rcx
000070dabbddfd51  pop rax
000070dabbddfd52  add rsp, 0x08
000070dabbddfd56  jmp 0x000070DABBDDC505
000070dabbddfd5b  sub rsp, 0x08
000070dabbddfd5f  push rax
000070dabbddfd60  push rcx
000070dabbddfd61  push rdx
000070dabbddfd62  push rdi
000070dabbddfd63  push rsi
000070dabbddfd64  push r8
000070dabbddfd66  push r9
000070dabbddfd68  push r10
000070dabbddfd6a  push r11
000070dabbddfd6c  sub rsp, 0xF0
000070dabbddfd73  vmovaps [rsp], xmm0
000070dabbddfd78  vmovaps [rsp+0x10], xmm1
000070dabbddfd7e  vmovaps [rsp+0x20], xmm2
000070dabbddfd84  vmovaps [rsp+0x30], xmm3
000070dabbddfd8a  vmovaps [rsp+0x40], xmm4
000070dabbddfd90  vmovaps [rsp+0x50], xmm5
000070dabbddfd96  vmovaps [rsp+0x60], xmm6
000070dabbddfd9c  vmovaps [rsp+0x70], xmm7
000070dabbddfda2  vmovaps [rsp+0x80], xmm8
000070dabbddfdab  vmovaps [rsp+0x90], xmm9
000070dabbddfdb4  vmovaps [rsp+0xA0], xmm10
000070dabbddfdbd  vmovaps [rsp+0xB0], xmm12
000070dabbddfdc6  vmovaps [rsp+0xC0], xmm13
000070dabbddfdcf  vmovaps [rsp+0xD0], xmm14
000070dabbddfdd8  vmovaps [rsp+0xE0], xmm15
000070dabbddfde1  sub rsp, 0x30
000070dabbddfde5  movaps [rsp], xmm11
000070dabbddfdea  movaps [rsp+0x10], xmm10
000070dabbddfdf0  movaps [rsp+0x20], xmm6
000070dabbddfdf5  lea rdi, [rsp]
000070dabbddfdf9  mov esi, 0x00
000070dabbddfdfe  mov rax, 0x5C2CF7B6F530
000070dabbddfe08  call rax
000070dabbddfe0a  movaps xmm11, [rsp]
000070dabbddfe0f  add rsp, 0x30
000070dabbddfe13  vmovaps xmm0, [rsp]
000070dabbddfe18  vmovaps xmm1, [rsp+0x10]
000070dabbddfe1e  vmovaps xmm2, [rsp+0x20]
000070dabbddfe24  vmovaps xmm3, [rsp+0x30]
000070dabbddfe2a  vmovaps xmm4, [rsp+0x40]
000070dabbddfe30  vmovaps xmm5, [rsp+0x50]
000070dabbddfe36  vmovaps xmm6, [rsp+0x60]
000070dabbddfe3c  vmovaps xmm7, [rsp+0x70]
000070dabbddfe42  vmovaps xmm8, [rsp+0x80]
000070dabbddfe4b  vmovaps xmm9, [rsp+0x90]
000070dabbddfe54  vmovaps xmm10, [rsp+0xA0]
000070dabbddfe5d  vmovaps xmm12, [rsp+0xB0]
000070dabbddfe66  vmovaps xmm13, [rsp+0xC0]
000070dabbddfe6f  vmovaps xmm14, [rsp+0xD0]
000070dabbddfe78  vmovaps xmm15, [rsp+0xE0]
000070dabbddfe81  add rsp, 0xF0
000070dabbddfe88  pop r11
000070dabbddfe8a  pop r10
000070dabbddfe8c  pop r9
000070dabbddfe8e  pop r8
000070dabbddfe90  pop rsi
000070dabbddfe91  pop rdi
000070dabbddfe92  pop rdx
000070dabbddfe93  pop rcx
000070dabbddfe94  pop rax
000070dabbddfe95  add rsp, 0x08
000070dabbddfe99  jmp 0x000070DABBDDC520
000070dabbddfe9e  sub rsp, 0x08
000070dabbddfea2  push rax
000070dabbddfea3  push rcx
000070dabbddfea4  push rdx
000070dabbddfea5  push rdi
000070dabbddfea6  push rsi
000070dabbddfea7  push r8
000070dabbddfea9  push r9
000070dabbddfeab  push r10
000070dabbddfead  push r11
000070dabbddfeaf  sub rsp, 0xF0
000070dabbddfeb6  vmovaps [rsp], xmm0
000070dabbddfebb  vmovaps [rsp+0x10], xmm1
000070dabbddfec1  vmovaps [rsp+0x20], xmm2
000070dabbddfec7  vmovaps [rsp+0x30], xmm3
000070dabbddfecd  vmovaps [rsp+0x40], xmm4
000070dabbddfed3  vmovaps [rsp+0x50], xmm5
000070dabbddfed9  vmovaps [rsp+0x60], xmm6
000070dabbddfedf  vmovaps [rsp+0x70], xmm7
000070dabbddfee5  vmovaps [rsp+0x80], xmm8
000070dabbddfeee  vmovaps [rsp+0x90], xmm9
000070dabbddfef7  vmovaps [rsp+0xA0], xmm11
000070dabbddff00  vmovaps [rsp+0xB0], xmm12
000070dabbddff09  vmovaps [rsp+0xC0], xmm13
000070dabbddff12  vmovaps [rsp+0xD0], xmm14
000070dabbddff1b  vmovaps [rsp+0xE0], xmm15
000070dabbddff24  sub rsp, 0x30
000070dabbddff28  movaps [rsp], xmm10
000070dabbddff2d  movaps [rsp+0x10], xmm14
000070dabbddff33  movaps [rsp+0x20], xmm4
000070dabbddff38  lea rdi, [rsp]
000070dabbddff3c  mov esi, 0x00
000070dabbddff41  mov rax, 0x5C2CF7B6F530
000070dabbddff4b  call rax
000070dabbddff4d  movaps xmm10, [rsp]
000070dabbddff52  add rsp, 0x30
000070dabbddff56  vmovaps xmm0, [rsp]
000070dabbddff5b  vmovaps xmm1, [rsp+0x10]
000070dabbddff61  vmovaps xmm2, [rsp+0x20]
000070dabbddff67  vmovaps xmm3, [rsp+0x30]
000070dabbddff6d  vmovaps xmm4, [rsp+0x40]
000070dabbddff73  vmovaps xmm5, [rsp+0x50]
000070dabbddff79  vmovaps xmm6, [rsp+0x60]
000070dabbddff7f  vmovaps xmm7, [rsp+0x70]
000070dabbddff85  vmovaps xmm8, [rsp+0x80]
000070dabbddff8e  vmovaps xmm9, [rsp+0x90]
000070dabbddff97  vmovaps xmm11, [rsp+0xA0]
000070dabbddffa0  vmovaps xmm12, [rsp+0xB0]
000070dabbddffa9  vmovaps xmm13, [rsp+0xC0]
000070dabbddffb2  vmovaps xmm14, [rsp+0xD0]
000070dabbddffbb  vmovaps xmm15, [rsp+0xE0]
000070dabbddffc4  add rsp, 0xF0
000070dabbddffcb  pop r11
000070dabbddffcd  pop r10
000070dabbddffcf  pop r9
000070dabbddffd1  pop r8
000070dabbddffd3  pop rsi
000070dabbddffd4  pop rdi
000070dabbddffd5  pop rdx
000070dabbddffd6  pop rcx
000070dabbddffd7  pop rax
000070dabbddffd8  add rsp, 0x08
000070dabbddffdc  jmp 0x000070DABBDDC53B
000070dabbddffe1  sub rsp, 0x08
000070dabbddffe5  push rax
000070dabbddffe6  push rcx
000070dabbddffe7  push rdx
000070dabbddffe8  push rdi
000070dabbddffe9  push rsi
000070dabbddffea  push r8
000070dabbddffec  push r9
000070dabbddffee  push r10
000070dabbddfff0  push r11
000070dabbddfff2  sub rsp, 0xF0
000070dabbddfff9  vmovaps [rsp], xmm0
000070dabbddfffe  vmovaps [rsp+0x10], xmm1
000070dabbde0004  vmovaps [rsp+0x20], xmm2
000070dabbde000a  vmovaps [rsp+0x30], xmm3
000070dabbde0010  vmovaps [rsp+0x40], xmm4
000070dabbde0016  vmovaps [rsp+0x50], xmm5
000070dabbde001c  vmovaps [rsp+0x60], xmm6
000070dabbde0022  vmovaps [rsp+0x70], xmm7
000070dabbde0028  vmovaps [rsp+0x80], xmm9
000070dabbde0031  vmovaps [rsp+0x90], xmm10
000070dabbde003a  vmovaps [rsp+0xA0], xmm11
000070dabbde0043  vmovaps [rsp+0xB0], xmm12
000070dabbde004c  vmovaps [rsp+0xC0], xmm13
000070dabbde0055  vmovaps [rsp+0xD0], xmm14
000070dabbde005e  vmovaps [rsp+0xE0], xmm15
000070dabbde0067  sub rsp, 0x30
000070dabbde006b  movaps [rsp], xmm8
000070dabbde0070  movaps [rsp+0x10], xmm1
000070dabbde0075  movaps [rsp+0x20], xmm14
000070dabbde007b  lea rdi, [rsp]
000070dabbde007f  mov esi, 0x00
000070dabbde0084  mov rax, 0x5C2CF7B6F530
000070dabbde008e  call rax
000070dabbde0090  movaps xmm8, [rsp]
000070dabbde0095  add rsp, 0x30
000070dabbde0099  vmovaps xmm0, [rsp]
000070dabbde009e  vmovaps xmm1, [rsp+0x10]
000070dabbde00a4  vmovaps xmm2, [rsp+0x20]
000070dabbde00aa  vmovaps xmm3, [rsp+0x30]
000070dabbde00b0  vmovaps xmm4, [rsp+0x40]
000070dabbde00b6  vmovaps xmm5, [rsp+0x50]
000070dabbde00bc  vmovaps xmm6, [rsp+0x60]
000070dabbde00c2  vmovaps xmm7, [rsp+0x70]
000070dabbde00c8  vmovaps xmm9, [rsp+0x80]
000070dabbde00d1  vmovaps xmm10, [rsp+0x90]
000070dabbde00da  vmovaps xmm11, [rsp+0xA0]
000070dabbde00e3  vmovaps xmm12, [rsp+0xB0]
000070dabbde00ec  vmovaps xmm13, [rsp+0xC0]
000070dabbde00f5  vmovaps xmm14, [rsp+0xD0]
000070dabbde00fe  vmovaps xmm15, [rsp+0xE0]
000070dabbde0107  add rsp, 0xF0
000070dabbde010e  pop r11
000070dabbde0110  pop r10
000070dabbde0112  pop r9
000070dabbde0114  pop r8
000070dabbde0116  pop rsi
000070dabbde0117  pop rdi
000070dabbde0118  pop rdx
000070dabbde0119  pop rcx
000070dabbde011a  pop rax
000070dabbde011b  add rsp, 0x08
000070dabbde011f  jmp 0x000070DABBDDC561
000070dabbde0124  sub rsp, 0x08
000070dabbde0128  push rax
000070dabbde0129  push rcx
000070dabbde012a  push rdx
000070dabbde012b  push rdi
000070dabbde012c  push rsi
000070dabbde012d  push r8
000070dabbde012f  push r9
000070dabbde0131  push r10
000070dabbde0133  push r11
000070dabbde0135  sub rsp, 0xF0
000070dabbde013c  vmovaps [rsp], xmm0
000070dabbde0141  vmovaps [rsp+0x10], xmm1
000070dabbde0147  vmovaps [rsp+0x20], xmm2
000070dabbde014d  vmovaps [rsp+0x30], xmm3
000070dabbde0153  vmovaps [rsp+0x40], xmm4
000070dabbde0159  vmovaps [rsp+0x50], xmm5
000070dabbde015f  vmovaps [rsp+0x60], xmm7
000070dabbde0165  vmovaps [rsp+0x70], xmm8
000070dabbde016b  vmovaps [rsp+0x80], xmm9
000070dabbde0174  vmovaps [rsp+0x90], xmm10
000070dabbde017d  vmovaps [rsp+0xA0], xmm11
000070dabbde0186  vmovaps [rsp+0xB0], xmm12
000070dabbde018f  vmovaps [rsp+0xC0], xmm13
000070dabbde0198  vmovaps [rsp+0xD0], xmm14
000070dabbde01a1  vmovaps [rsp+0xE0], xmm15
000070dabbde01aa  sub rsp, 0x30
000070dabbde01ae  movaps [rsp], xmm6
000070dabbde01b2  movaps [rsp+0x10], xmm1
000070dabbde01b7  movaps [rsp+0x20], xmm14
000070dabbde01bd  lea rdi, [rsp]
000070dabbde01c1  mov esi, 0x00
000070dabbde01c6  mov rax, 0x5C2CF7B6F530
000070dabbde01d0  call rax
000070dabbde01d2  movaps xmm6, [rsp]
000070dabbde01d6  add rsp, 0x30
000070dabbde01da  vmovaps xmm0, [rsp]
000070dabbde01df  vmovaps xmm1, [rsp+0x10]
000070dabbde01e5  vmovaps xmm2, [rsp+0x20]
000070dabbde01eb  vmovaps xmm3, [rsp+0x30]
000070dabbde01f1  vmovaps xmm4, [rsp+0x40]
000070dabbde01f7  vmovaps xmm5, [rsp+0x50]
000070dabbde01fd  vmovaps xmm7, [rsp+0x60]
000070dabbde0203  vmovaps xmm8, [rsp+0x70]
000070dabbde0209  vmovaps xmm9, [rsp+0x80]
000070dabbde0212  vmovaps xmm10, [rsp+0x90]
000070dabbde021b  vmovaps xmm11, [rsp+0xA0]
000070dabbde0224  vmovaps xmm12, [rsp+0xB0]
000070dabbde022d  vmovaps xmm13, [rsp+0xC0]
000070dabbde0236  vmovaps xmm14, [rsp+0xD0]
000070dabbde023f  vmovaps xmm15, [rsp+0xE0]
000070dabbde0248  add rsp, 0xF0
000070dabbde024f  pop r11
000070dabbde0251  pop r10
000070dabbde0253  pop r9
000070dabbde0255  pop r8
000070dabbde0257  pop rsi
000070dabbde0258  pop rdi
000070dabbde0259  pop rdx
000070dabbde025a  pop rcx
000070dabbde025b  pop rax
000070dabbde025c  add rsp, 0x08
000070dabbde0260  jmp 0x000070DABBDDC58D
000070dabbde0265  sub rsp, 0x08
000070dabbde0269  push rax
000070dabbde026a  push rcx
000070dabbde026b  push rdx
000070dabbde026c  push rdi
000070dabbde026d  push rsi
000070dabbde026e  push r8
000070dabbde0270  push r9
000070dabbde0272  push r10
000070dabbde0274  push r11
000070dabbde0276  sub rsp, 0xF0
000070dabbde027d  vmovaps [rsp], xmm0
000070dabbde0282  vmovaps [rsp+0x10], xmm1
000070dabbde0288  vmovaps [rsp+0x20], xmm2
000070dabbde028e  vmovaps [rsp+0x30], xmm3
000070dabbde0294  vmovaps [rsp+0x40], xmm4
000070dabbde029a  vmovaps [rsp+0x50], xmm5
000070dabbde02a0  vmovaps [rsp+0x60], xmm6
000070dabbde02a6  vmovaps [rsp+0x70], xmm7
000070dabbde02ac  vmovaps [rsp+0x80], xmm8
000070dabbde02b5  vmovaps [rsp+0x90], xmm9
000070dabbde02be  vmovaps [rsp+0xA0], xmm10
000070dabbde02c7  vmovaps [rsp+0xB0], xmm11
000070dabbde02d0  vmovaps [rsp+0xC0], xmm12
000070dabbde02d9  vmovaps [rsp+0xD0], xmm13
000070dabbde02e2  vmovaps [rsp+0xE0], xmm15
000070dabbde02eb  sub rsp, 0x30
000070dabbde02ef  movaps [rsp], xmm14
000070dabbde02f4  movaps [rsp+0x10], xmm12
000070dabbde02fa  movaps [rsp+0x20], xmm1
000070dabbde02ff  lea rdi, [rsp]
000070dabbde0303  mov esi, 0x00
000070dabbde0308  mov rax, 0x5C2CF7B6F530
000070dabbde0312  call rax
000070dabbde0314  movaps xmm14, [rsp]
000070dabbde0319  add rsp, 0x30
000070dabbde031d  vmovaps xmm0, [rsp]
000070dabbde0322  vmovaps xmm1, [rsp+0x10]
000070dabbde0328  vmovaps xmm2, [rsp+0x20]
000070dabbde032e  vmovaps xmm3, [rsp+0x30]
000070dabbde0334  vmovaps xmm4, [rsp+0x40]
000070dabbde033a  vmovaps xmm5, [rsp+0x50]
000070dabbde0340  vmovaps xmm6, [rsp+0x60]
000070dabbde0346  vmovaps xmm7, [rsp+0x70]
000070dabbde034c  vmovaps xmm8, [rsp+0x80]
000070dabbde0355  vmovaps xmm9, [rsp+0x90]
000070dabbde035e  vmovaps xmm10, [rsp+0xA0]
000070dabbde0367  vmovaps xmm11, [rsp+0xB0]
000070dabbde0370  vmovaps xmm12, [rsp+0xC0]
000070dabbde0379  vmovaps xmm13, [rsp+0xD0]
000070dabbde0382  vmovaps xmm15, [rsp+0xE0]
000070dabbde038b  add rsp, 0xF0
000070dabbde0392  pop r11
000070dabbde0394  pop r10
000070dabbde0396  pop r9
000070dabbde0398  pop r8
000070dabbde039a  pop rsi
000070dabbde039b  pop rdi
000070dabbde039c  pop rdx
000070dabbde039d  pop rcx
000070dabbde039e  pop rax
000070dabbde039f  add rsp, 0x08
000070dabbde03a3  jmp 0x000070DABBDDC5B3
000070dabbde03a8  sub rsp, 0x08
000070dabbde03ac  push rax
000070dabbde03ad  push rcx
000070dabbde03ae  push rdx
000070dabbde03af  push rdi
000070dabbde03b0  push rsi
000070dabbde03b1  push r8
000070dabbde03b3  push r9
000070dabbde03b5  push r10
000070dabbde03b7  push r11
000070dabbde03b9  sub rsp, 0xF0
000070dabbde03c0  vmovaps [rsp], xmm0
000070dabbde03c5  vmovaps [rsp+0x10], xmm2
000070dabbde03cb  vmovaps [rsp+0x20], xmm3
000070dabbde03d1  vmovaps [rsp+0x30], xmm4
000070dabbde03d7  vmovaps [rsp+0x40], xmm5
000070dabbde03dd  vmovaps [rsp+0x50], xmm6
000070dabbde03e3  vmovaps [rsp+0x60], xmm7
000070dabbde03e9  vmovaps [rsp+0x70], xmm8
000070dabbde03ef  vmovaps [rsp+0x80], xmm9
000070dabbde03f8  vmovaps [rsp+0x90], xmm10
000070dabbde0401  vmovaps [rsp+0xA0], xmm11
000070dabbde040a  vmovaps [rsp+0xB0], xmm12
000070dabbde0413  vmovaps [rsp+0xC0], xmm13
000070dabbde041c  vmovaps [rsp+0xD0], xmm14
000070dabbde0425  vmovaps [rsp+0xE0], xmm15
000070dabbde042e  sub rsp, 0x30
000070dabbde0432  movaps [rsp], xmm1
000070dabbde0436  movaps [rsp+0x10], xmm13
000070dabbde043c  movaps [rsp+0x20], xmm9
000070dabbde0442  lea rdi, [rsp]
000070dabbde0446  mov esi, 0x00
000070dabbde044b  mov rax, 0x5C2CF7B6F530
000070dabbde0455  call rax
000070dabbde0457  movaps xmm1, [rsp]
000070dabbde045b  add rsp, 0x30
000070dabbde045f  vmovaps xmm0, [rsp]
000070dabbde0464  vmovaps xmm2, [rsp+0x10]
000070dabbde046a  vmovaps xmm3, [rsp+0x20]
000070dabbde0470  vmovaps xmm4, [rsp+0x30]
000070dabbde0476  vmovaps xmm5, [rsp+0x40]
000070dabbde047c  vmovaps xmm6, [rsp+0x50]
000070dabbde0482  vmovaps xmm7, [rsp+0x60]
000070dabbde0488  vmovaps xmm8, [rsp+0x70]
000070dabbde048e  vmovaps xmm9, [rsp+0x80]
000070dabbde0497  vmovaps xmm10, [rsp+0x90]
000070dabbde04a0  vmovaps xmm11, [rsp+0xA0]
000070dabbde04a9  vmovaps xmm12, [rsp+0xB0]
000070dabbde04b2  vmovaps xmm13, [rsp+0xC0]
000070dabbde04bb  vmovaps xmm14, [rsp+0xD0]
000070dabbde04c4  vmovaps xmm15, [rsp+0xE0]
000070dabbde04cd  add rsp, 0xF0
000070dabbde04d4  pop r11
000070dabbde04d6  pop r10
000070dabbde04d8  pop r9
000070dabbde04da  pop r8
000070dabbde04dc  pop rsi
000070dabbde04dd  pop rdi
000070dabbde04de  pop rdx
000070dabbde04df  pop rcx
000070dabbde04e0  pop rax
000070dabbde04e1  add rsp, 0x08
000070dabbde04e5  jmp 0x000070DABBDDC5CD
000070dabbde04ea  sub rsp, 0x08
000070dabbde04ee  push rax
000070dabbde04ef  push rcx
000070dabbde04f0  push rdx
000070dabbde04f1  push rdi
000070dabbde04f2  push rsi
000070dabbde04f3  push r8
000070dabbde04f5  push r9
000070dabbde04f7  push r10
000070dabbde04f9  push r11
000070dabbde04fb  sub rsp, 0xF0
000070dabbde0502  vmovaps [rsp], xmm0
000070dabbde0507  vmovaps [rsp+0x10], xmm1
000070dabbde050d  vmovaps [rsp+0x20], xmm2
000070dabbde0513  vmovaps [rsp+0x30], xmm3
000070dabbde0519  vmovaps [rsp+0x40], xmm4
000070dabbde051f  vmovaps [rsp+0x50], xmm5
000070dabbde0525  vmovaps [rsp+0x60], xmm6
000070dabbde052b  vmovaps [rsp+0x70], xmm7
000070dabbde0531  vmovaps [rsp+0x80], xmm8
000070dabbde053a  vmovaps [rsp+0x90], xmm9
000070dabbde0543  vmovaps [rsp+0xA0], xmm10
000070dabbde054c  vmovaps [rsp+0xB0], xmm11
000070dabbde0555  vmovaps [rsp+0xC0], xmm13
000070dabbde055e  vmovaps [rsp+0xD0], xmm14
000070dabbde0567  vmovaps [rsp+0xE0], xmm15
000070dabbde0570  sub rsp, 0x30
000070dabbde0574  movaps [rsp], xmm12
000070dabbde0579  movaps [rsp+0x10], xmm7
000070dabbde057e  movaps [rsp+0x20], xmm13
000070dabbde0584  lea rdi, [rsp]
000070dabbde0588  mov esi, 0x00
000070dabbde058d  mov rax, 0x5C2CF7B6F530
000070dabbde0597  call rax
000070dabbde0599  movaps xmm12, [rsp]
000070dabbde059e  add rsp, 0x30
000070dabbde05a2  vmovaps xmm0, [rsp]
000070dabbde05a7  vmovaps xmm1, [rsp+0x10]
000070dabbde05ad  vmovaps xmm2, [rsp+0x20]
000070dabbde05b3  vmovaps xmm3, [rsp+0x30]
000070dabbde05b9  vmovaps xmm4, [rsp+0x40]
000070dabbde05bf  vmovaps xmm5, [rsp+0x50]
000070dabbde05c5  vmovaps xmm6, [rsp+0x60]
000070dabbde05cb  vmovaps xmm7, [rsp+0x70]
000070dabbde05d1  vmovaps xmm8, [rsp+0x80]
000070dabbde05da  vmovaps xmm9, [rsp+0x90]
000070dabbde05e3  vmovaps xmm10, [rsp+0xA0]
000070dabbde05ec  vmovaps xmm11, [rsp+0xB0]
000070dabbde05f5  vmovaps xmm13, [rsp+0xC0]
000070dabbde05fe  vmovaps xmm14, [rsp+0xD0]
000070dabbde0607  vmovaps xmm15, [rsp+0xE0]
000070dabbde0610  add rsp, 0xF0
000070dabbde0617  pop r11
000070dabbde0619  pop r10
000070dabbde061b  pop r9
000070dabbde061d  pop r8
000070dabbde061f  pop rsi
000070dabbde0620  pop rdi
000070dabbde0621  pop rdx
000070dabbde0622  pop rcx
000070dabbde0623  pop rax
000070dabbde0624  add rsp, 0x08
000070dabbde0628  jmp 0x000070DABBDDC5F4
000070dabbde062d  sub rsp, 0x08
000070dabbde0631  push rax
000070dabbde0632  push rcx
000070dabbde0633  push rdx
000070dabbde0634  push rdi
000070dabbde0635  push rsi
000070dabbde0636  push r8
000070dabbde0638  push r9
000070dabbde063a  push r10
000070dabbde063c  push r11
000070dabbde063e  sub rsp, 0xF0
000070dabbde0645  vmovaps [rsp], xmm0
000070dabbde064a  vmovaps [rsp+0x10], xmm1
000070dabbde0650  vmovaps [rsp+0x20], xmm2
000070dabbde0656  vmovaps [rsp+0x30], xmm3
000070dabbde065c  vmovaps [rsp+0x40], xmm4
000070dabbde0662  vmovaps [rsp+0x50], xmm5
000070dabbde0668  vmovaps [rsp+0x60], xmm6
000070dabbde066e  vmovaps [rsp+0x70], xmm7
000070dabbde0674  vmovaps [rsp+0x80], xmm8
000070dabbde067d  vmovaps [rsp+0x90], xmm9
000070dabbde0686  vmovaps [rsp+0xA0], xmm10
000070dabbde068f  vmovaps [rsp+0xB0], xmm11
000070dabbde0698  vmovaps [rsp+0xC0], xmm12
000070dabbde06a1  vmovaps [rsp+0xD0], xmm14
000070dabbde06aa  vmovaps [rsp+0xE0], xmm15
000070dabbde06b3  sub rsp, 0x30
000070dabbde06b7  movaps [rsp], xmm13
000070dabbde06bc  movaps [rsp+0x10], xmm15
000070dabbde06c2  movaps [rsp+0x20], xmm8
000070dabbde06c8  lea rdi, [rsp]
000070dabbde06cc  mov esi, 0x00
000070dabbde06d1  mov rax, 0x5C2CF7B6F530
000070dabbde06db  call rax
000070dabbde06dd  movaps xmm13, [rsp]
000070dabbde06e2  add rsp, 0x30
000070dabbde06e6  vmovaps xmm0, [rsp]
000070dabbde06eb  vmovaps xmm1, [rsp+0x10]
000070dabbde06f1  vmovaps xmm2, [rsp+0x20]
000070dabbde06f7  vmovaps xmm3, [rsp+0x30]
000070dabbde06fd  vmovaps xmm4, [rsp+0x40]
000070dabbde0703  vmovaps xmm5, [rsp+0x50]
000070dabbde0709  vmovaps xmm6, [rsp+0x60]
000070dabbde070f  vmovaps xmm7, [rsp+0x70]
000070dabbde0715  vmovaps xmm8, [rsp+0x80]
000070dabbde071e  vmovaps xmm9, [rsp+0x90]
000070dabbde0727  vmovaps xmm10, [rsp+0xA0]
000070dabbde0730  vmovaps xmm11, [rsp+0xB0]
000070dabbde0739  vmovaps xmm12, [rsp+0xC0]
000070dabbde0742  vmovaps xmm14, [rsp+0xD0]
000070dabbde074b  vmovaps xmm15, [rsp+0xE0]
000070dabbde0754  add rsp, 0xF0
000070dabbde075b  pop r11
000070dabbde075d  pop r10
000070dabbde075f  pop r9
000070dabbde0761  pop r8
000070dabbde0763  pop rsi
000070dabbde0764  pop rdi
000070dabbde0765  pop rdx
000070dabbde0766  pop rcx
000070dabbde0767  pop rax
000070dabbde0768  add rsp, 0x08
000070dabbde076c  jmp 0x000070DABBDDC60F
000070dabbde0771  sub rsp, 0x08
000070dabbde0775  push rax
000070dabbde0776  push rcx
000070dabbde0777  push rdx
000070dabbde0778  push rdi
000070dabbde0779  push rsi
000070dabbde077a  push r8
000070dabbde077c  push r9
000070dabbde077e  push r10
000070dabbde0780  push r11
000070dabbde0782  sub rsp, 0xF0
000070dabbde0789  vmovaps [rsp], xmm0
000070dabbde078e  vmovaps [rsp+0x10], xmm1
000070dabbde0794  vmovaps [rsp+0x20], xmm2
000070dabbde079a  vmovaps [rsp+0x30], xmm3
000070dabbde07a0  vmovaps [rsp+0x40], xmm4
000070dabbde07a6  vmovaps [rsp+0x50], xmm5
000070dabbde07ac  vmovaps [rsp+0x60], xmm6
000070dabbde07b2  vmovaps [rsp+0x70], xmm7
000070dabbde07b8  vmovaps [rsp+0x80], xmm9
000070dabbde07c1  vmovaps [rsp+0x90], xmm10
000070dabbde07ca  vmovaps [rsp+0xA0], xmm11
000070dabbde07d3  vmovaps [rsp+0xB0], xmm12
000070dabbde07dc  vmovaps [rsp+0xC0], xmm13
000070dabbde07e5  vmovaps [rsp+0xD0], xmm14
000070dabbde07ee  vmovaps [rsp+0xE0], xmm15
000070dabbde07f7  sub rsp, 0x30
000070dabbde07fb  movaps [rsp], xmm8
000070dabbde0800  movaps [rsp+0x10], xmm15
000070dabbde0806  movaps [rsp+0x20], xmm9
000070dabbde080c  lea rdi, [rsp]
000070dabbde0810  mov esi, 0x00
000070dabbde0815  mov rax, 0x5C2CF7B6F530
000070dabbde081f  call rax
000070dabbde0821  movaps xmm8, [rsp]
000070dabbde0826  add rsp, 0x30
000070dabbde082a  vmovaps xmm0, [rsp]
000070dabbde082f  vmovaps xmm1, [rsp+0x10]
000070dabbde0835  vmovaps xmm2, [rsp+0x20]
000070dabbde083b  vmovaps xmm3, [rsp+0x30]
000070dabbde0841  vmovaps xmm4, [rsp+0x40]
000070dabbde0847  vmovaps xmm5, [rsp+0x50]
000070dabbde084d  vmovaps xmm6, [rsp+0x60]
000070dabbde0853  vmovaps xmm7, [rsp+0x70]
000070dabbde0859  vmovaps xmm9, [rsp+0x80]
000070dabbde0862  vmovaps xmm10, [rsp+0x90]
000070dabbde086b  vmovaps xmm11, [rsp+0xA0]
000070dabbde0874  vmovaps xmm12, [rsp+0xB0]
000070dabbde087d  vmovaps xmm13, [rsp+0xC0]
000070dabbde0886  vmovaps xmm14, [rsp+0xD0]
000070dabbde088f  vmovaps xmm15, [rsp+0xE0]
000070dabbde0898  add rsp, 0xF0
000070dabbde089f  pop r11
000070dabbde08a1  pop r10
000070dabbde08a3  pop r9
000070dabbde08a5  pop r8
000070dabbde08a7  pop rsi
000070dabbde08a8  pop rdi
000070dabbde08a9  pop rdx
000070dabbde08aa  pop rcx
000070dabbde08ab  pop rax
000070dabbde08ac  add rsp, 0x08
000070dabbde08b0  jmp 0x000070DABBDDC63D
000070dabbde08b5  sub rsp, 0x08
000070dabbde08b9  push rax
000070dabbde08ba  push rcx
000070dabbde08bb  push rdx
000070dabbde08bc  push rdi
000070dabbde08bd  push rsi
000070dabbde08be  push r8
000070dabbde08c0  push r9
000070dabbde08c2  push r10
000070dabbde08c4  push r11
000070dabbde08c6  sub rsp, 0xF0
000070dabbde08cd  vmovaps [rsp], xmm0
000070dabbde08d2  vmovaps [rsp+0x10], xmm1
000070dabbde08d8  vmovaps [rsp+0x20], xmm2
000070dabbde08de  vmovaps [rsp+0x30], xmm3
000070dabbde08e4  vmovaps [rsp+0x40], xmm4
000070dabbde08ea  vmovaps [rsp+0x50], xmm5
000070dabbde08f0  vmovaps [rsp+0x60], xmm6
000070dabbde08f6  vmovaps [rsp+0x70], xmm7
000070dabbde08fc  vmovaps [rsp+0x80], xmm8
000070dabbde0905  vmovaps [rsp+0x90], xmm9
000070dabbde090e  vmovaps [rsp+0xA0], xmm10
000070dabbde0917  vmovaps [rsp+0xB0], xmm11
000070dabbde0920  vmovaps [rsp+0xC0], xmm12
000070dabbde0929  vmovaps [rsp+0xD0], xmm13
000070dabbde0932  vmovaps [rsp+0xE0], xmm14
000070dabbde093b  sub rsp, 0x30
000070dabbde093f  movaps [rsp], xmm15
000070dabbde0944  movaps [rsp+0x10], xmm11
000070dabbde094a  movaps [rsp+0x20], xmm6
000070dabbde094f  lea rdi, [rsp]
000070dabbde0953  mov esi, 0x00
000070dabbde0958  mov rax, 0x5C2CF7B6F530
000070dabbde0962  call rax
000070dabbde0964  movaps xmm15, [rsp]
000070dabbde0969  add rsp, 0x30
000070dabbde096d  vmovaps xmm0, [rsp]
000070dabbde0972  vmovaps xmm1, [rsp+0x10]
000070dabbde0978  vmovaps xmm2, [rsp+0x20]
000070dabbde097e  vmovaps xmm3, [rsp+0x30]
000070dabbde0984  vmovaps xmm4, [rsp+0x40]
000070dabbde098a  vmovaps xmm5, [rsp+0x50]
000070dabbde0990  vmovaps xmm6, [rsp+0x60]
000070dabbde0996  vmovaps xmm7, [rsp+0x70]
000070dabbde099c  vmovaps xmm8, [rsp+0x80]
000070dabbde09a5  vmovaps xmm9, [rsp+0x90]
000070dabbde09ae  vmovaps xmm10, [rsp+0xA0]
000070dabbde09b7  vmovaps xmm11, [rsp+0xB0]
000070dabbde09c0  vmovaps xmm12, [rsp+0xC0]
000070dabbde09c9  vmovaps xmm13, [rsp+0xD0]
000070dabbde09d2  vmovaps xmm14, [rsp+0xE0]
000070dabbde09db  add rsp, 0xF0
000070dabbde09e2  pop r11
000070dabbde09e4  pop r10
000070dabbde09e6  pop r9
000070dabbde09e8  pop r8
000070dabbde09ea  pop rsi
000070dabbde09eb  pop rdi
000070dabbde09ec  pop rdx
000070dabbde09ed  pop rcx
000070dabbde09ee  pop rax
000070dabbde09ef  add rsp, 0x08
000070dabbde09f3  jmp 0x000070DABBDDC658
000070dabbde09f8  sub rsp, 0x08
000070dabbde09fc  push rax
000070dabbde09fd  push rcx
000070dabbde09fe  push rdx
000070dabbde09ff  push rdi
000070dabbde0a00  push rsi
000070dabbde0a01  push r8
000070dabbde0a03  push r9
000070dabbde0a05  push r10
000070dabbde0a07  push r11
000070dabbde0a09  sub rsp, 0xF0
000070dabbde0a10  vmovaps [rsp], xmm0
000070dabbde0a15  vmovaps [rsp+0x10], xmm1
000070dabbde0a1b  vmovaps [rsp+0x20], xmm2
000070dabbde0a21  vmovaps [rsp+0x30], xmm3
000070dabbde0a27  vmovaps [rsp+0x40], xmm4
000070dabbde0a2d  vmovaps [rsp+0x50], xmm5
000070dabbde0a33  vmovaps [rsp+0x60], xmm6
000070dabbde0a39  vmovaps [rsp+0x70], xmm8
000070dabbde0a3f  vmovaps [rsp+0x80], xmm9
000070dabbde0a48  vmovaps [rsp+0x90], xmm10
000070dabbde0a51  vmovaps [rsp+0xA0], xmm11
000070dabbde0a5a  vmovaps [rsp+0xB0], xmm12
000070dabbde0a63  vmovaps [rsp+0xC0], xmm13
000070dabbde0a6c  vmovaps [rsp+0xD0], xmm14
000070dabbde0a75  vmovaps [rsp+0xE0], xmm15
000070dabbde0a7e  sub rsp, 0x30
000070dabbde0a82  movaps [rsp], xmm7
000070dabbde0a86  movaps [rsp+0x10], xmm11
000070dabbde0a8c  movaps [rsp+0x20], xmm9
000070dabbde0a92  lea rdi, [rsp]
000070dabbde0a96  mov esi, 0x00
000070dabbde0a9b  mov rax, 0x5C2CF7B6F530
000070dabbde0aa5  call rax
000070dabbde0aa7  movaps xmm7, [rsp]
000070dabbde0aab  add rsp, 0x30
000070dabbde0aaf  vmovaps xmm0, [rsp]
000070dabbde0ab4  vmovaps xmm1, [rsp+0x10]
000070dabbde0aba  vmovaps xmm2, [rsp+0x20]
000070dabbde0ac0  vmovaps xmm3, [rsp+0x30]
000070dabbde0ac6  vmovaps xmm4, [rsp+0x40]
000070dabbde0acc  vmovaps xmm5, [rsp+0x50]
000070dabbde0ad2  vmovaps xmm6, [rsp+0x60]
000070dabbde0ad8  vmovaps xmm8, [rsp+0x70]
000070dabbde0ade  vmovaps xmm9, [rsp+0x80]
000070dabbde0ae7  vmovaps xmm10, [rsp+0x90]
000070dabbde0af0  vmovaps xmm11, [rsp+0xA0]
000070dabbde0af9  vmovaps xmm12, [rsp+0xB0]
000070dabbde0b02  vmovaps xmm13, [rsp+0xC0]
000070dabbde0b0b  vmovaps xmm14, [rsp+0xD0]
000070dabbde0b14  vmovaps xmm15, [rsp+0xE0]
000070dabbde0b1d  add rsp, 0xF0
000070dabbde0b24  pop r11
000070dabbde0b26  pop r10
000070dabbde0b28  pop r9
000070dabbde0b2a  pop r8
000070dabbde0b2c  pop rsi
000070dabbde0b2d  pop rdi
000070dabbde0b2e  pop rdx
000070dabbde0b2f  pop rcx
000070dabbde0b30  pop rax
000070dabbde0b31  add rsp, 0x08
000070dabbde0b35  jmp 0x000070DABBDDC685
000070dabbde0b3a  sub rsp, 0x08
000070dabbde0b3e  push rax
000070dabbde0b3f  push rcx
000070dabbde0b40  push rdx
000070dabbde0b41  push rdi
000070dabbde0b42  push rsi
000070dabbde0b43  push r8
000070dabbde0b45  push r9
000070dabbde0b47  push r10
000070dabbde0b49  push r11
000070dabbde0b4b  sub rsp, 0xF0
000070dabbde0b52  vmovaps [rsp], xmm0
000070dabbde0b57  vmovaps [rsp+0x10], xmm1
000070dabbde0b5d  vmovaps [rsp+0x20], xmm2
000070dabbde0b63  vmovaps [rsp+0x30], xmm3
000070dabbde0b69  vmovaps [rsp+0x40], xmm4
000070dabbde0b6f  vmovaps [rsp+0x50], xmm5
000070dabbde0b75  vmovaps [rsp+0x60], xmm6
000070dabbde0b7b  vmovaps [rsp+0x70], xmm7
000070dabbde0b81  vmovaps [rsp+0x80], xmm8
000070dabbde0b8a  vmovaps [rsp+0x90], xmm9
000070dabbde0b93  vmovaps [rsp+0xA0], xmm10
000070dabbde0b9c  vmovaps [rsp+0xB0], xmm12
000070dabbde0ba5  vmovaps [rsp+0xC0], xmm13
000070dabbde0bae  vmovaps [rsp+0xD0], xmm14
000070dabbde0bb7  vmovaps [rsp+0xE0], xmm15
000070dabbde0bc0  sub rsp, 0x30
000070dabbde0bc4  movaps [rsp], xmm11
000070dabbde0bc9  movaps [rsp+0x10], xmm10
000070dabbde0bcf  movaps [rsp+0x20], xmm14
000070dabbde0bd5  lea rdi, [rsp]
000070dabbde0bd9  mov esi, 0x00
000070dabbde0bde  mov rax, 0x5C2CF7B6F530
000070dabbde0be8  call rax
000070dabbde0bea  movaps xmm11, [rsp]
000070dabbde0bef  add rsp, 0x30
000070dabbde0bf3  vmovaps xmm0, [rsp]
000070dabbde0bf8  vmovaps xmm1, [rsp+0x10]
000070dabbde0bfe  vmovaps xmm2, [rsp+0x20]
000070dabbde0c04  vmovaps xmm3, [rsp+0x30]
000070dabbde0c0a  vmovaps xmm4, [rsp+0x40]
000070dabbde0c10  vmovaps xmm5, [rsp+0x50]
000070dabbde0c16  vmovaps xmm6, [rsp+0x60]
000070dabbde0c1c  vmovaps xmm7, [rsp+0x70]
000070dabbde0c22  vmovaps xmm8, [rsp+0x80]
000070dabbde0c2b  vmovaps xmm9, [rsp+0x90]
000070dabbde0c34  vmovaps xmm10, [rsp+0xA0]
000070dabbde0c3d  vmovaps xmm12, [rsp+0xB0]
000070dabbde0c46  vmovaps xmm13, [rsp+0xC0]
000070dabbde0c4f  vmovaps xmm14, [rsp+0xD0]
000070dabbde0c58  vmovaps xmm15, [rsp+0xE0]
000070dabbde0c61  add rsp, 0xF0
000070dabbde0c68  pop r11
000070dabbde0c6a  pop r10
000070dabbde0c6c  pop r9
000070dabbde0c6e  pop r8
000070dabbde0c70  pop rsi
000070dabbde0c71  pop rdi
000070dabbde0c72  pop rdx
000070dabbde0c73  pop rcx
000070dabbde0c74  pop rax
000070dabbde0c75  add rsp, 0x08
000070dabbde0c79  jmp 0x000070DABBDDC6A0
000070dabbde0c7e  call 0x000070DABBCC33A0
000070dabbde0c83  jmp 0x000070DABBDDC6AA
000070dabbde0c88  sub rsp, 0x08
000070dabbde0c8c  push rax
000070dabbde0c8d  push rcx
000070dabbde0c8e  push rdx
000070dabbde0c8f  push rdi
000070dabbde0c90  push rsi
000070dabbde0c91  push r8
000070dabbde0c93  push r9
000070dabbde0c95  push r10
000070dabbde0c97  push r11
000070dabbde0c99  sub rsp, 0xF0
000070dabbde0ca0  vmovaps [rsp], xmm0
000070dabbde0ca5  vmovaps [rsp+0x10], xmm1
000070dabbde0cab  vmovaps [rsp+0x20], xmm2
000070dabbde0cb1  vmovaps [rsp+0x30], xmm3
000070dabbde0cb7  vmovaps [rsp+0x40], xmm4
000070dabbde0cbd  vmovaps [rsp+0x50], xmm5
000070dabbde0cc3  vmovaps [rsp+0x60], xmm6
000070dabbde0cc9  vmovaps [rsp+0x70], xmm7
000070dabbde0ccf  vmovaps [rsp+0x80], xmm8
000070dabbde0cd8  vmovaps [rsp+0x90], xmm9
000070dabbde0ce1  vmovaps [rsp+0xA0], xmm11
000070dabbde0cea  vmovaps [rsp+0xB0], xmm12
000070dabbde0cf3  vmovaps [rsp+0xC0], xmm13
000070dabbde0cfc  vmovaps [rsp+0xD0], xmm14
000070dabbde0d05  vmovaps [rsp+0xE0], xmm15
000070dabbde0d0e  sub rsp, 0x30
000070dabbde0d12  movaps [rsp], xmm10
000070dabbde0d17  movaps [rsp+0x10], xmm1
000070dabbde0d1c  movaps [rsp+0x20], xmm12
000070dabbde0d22  lea rdi, [rsp]
000070dabbde0d26  mov esi, 0x00
000070dabbde0d2b  mov rax, 0x5C2CF7B6F530
000070dabbde0d35  call rax
000070dabbde0d37  movaps xmm10, [rsp]
000070dabbde0d3c  add rsp, 0x30
000070dabbde0d40  vmovaps xmm0, [rsp]
000070dabbde0d45  vmovaps xmm1, [rsp+0x10]
000070dabbde0d4b  vmovaps xmm2, [rsp+0x20]
000070dabbde0d51  vmovaps xmm3, [rsp+0x30]
000070dabbde0d57  vmovaps xmm4, [rsp+0x40]
000070dabbde0d5d  vmovaps xmm5, [rsp+0x50]
000070dabbde0d63  vmovaps xmm6, [rsp+0x60]
000070dabbde0d69  vmovaps xmm7, [rsp+0x70]
000070dabbde0d6f  vmovaps xmm8, [rsp+0x80]
000070dabbde0d78  vmovaps xmm9, [rsp+0x90]
000070dabbde0d81  vmovaps xmm11, [rsp+0xA0]
000070dabbde0d8a  vmovaps xmm12, [rsp+0xB0]
000070dabbde0d93  vmovaps xmm13, [rsp+0xC0]
000070dabbde0d9c  vmovaps xmm14, [rsp+0xD0]
000070dabbde0da5  vmovaps xmm15, [rsp+0xE0]
000070dabbde0dae  add rsp, 0xF0
000070dabbde0db5  pop r11
000070dabbde0db7  pop r10
000070dabbde0db9  pop r9
000070dabbde0dbb  pop r8
000070dabbde0dbd  pop rsi
000070dabbde0dbe  pop rdi
000070dabbde0dbf  pop rdx
000070dabbde0dc0  pop rcx
000070dabbde0dc1  pop rax
000070dabbde0dc2  add rsp, 0x08
000070dabbde0dc6  jmp 0x000070DABBDDC6CD
000070dabbde0dcb  sub rsp, 0x08
000070dabbde0dcf  push rax
000070dabbde0dd0  push rcx
000070dabbde0dd1  push rdx
000070dabbde0dd2  push rdi
000070dabbde0dd3  push rsi
000070dabbde0dd4  push r8
000070dabbde0dd6  push r9
000070dabbde0dd8  push r10
000070dabbde0dda  push r11
000070dabbde0ddc  sub rsp, 0xF0
000070dabbde0de3  vmovaps [rsp], xmm0
000070dabbde0de8  vmovaps [rsp+0x10], xmm1
000070dabbde0dee  vmovaps [rsp+0x20], xmm2
000070dabbde0df4  vmovaps [rsp+0x30], xmm3
000070dabbde0dfa  vmovaps [rsp+0x40], xmm4
000070dabbde0e00  vmovaps [rsp+0x50], xmm5
000070dabbde0e06  vmovaps [rsp+0x60], xmm6
000070dabbde0e0c  vmovaps [rsp+0x70], xmm7
000070dabbde0e12  vmovaps [rsp+0x80], xmm8
000070dabbde0e1b  vmovaps [rsp+0x90], xmm9
000070dabbde0e24  vmovaps [rsp+0xA0], xmm10
000070dabbde0e2d  vmovaps [rsp+0xB0], xmm11
000070dabbde0e36  vmovaps [rsp+0xC0], xmm13
000070dabbde0e3f  vmovaps [rsp+0xD0], xmm14
000070dabbde0e48  vmovaps [rsp+0xE0], xmm15
000070dabbde0e51  sub rsp, 0x30
000070dabbde0e55  movaps [rsp], xmm12
000070dabbde0e5a  movaps [rsp+0x10], xmm14
000070dabbde0e60  movaps [rsp+0x20], xmm1
000070dabbde0e65  lea rdi, [rsp]
000070dabbde0e69  mov esi, 0x00
000070dabbde0e6e  mov rax, 0x5C2CF7B6F530
000070dabbde0e78  call rax
000070dabbde0e7a  movaps xmm12, [rsp]
000070dabbde0e7f  add rsp, 0x30
000070dabbde0e83  vmovaps xmm0, [rsp]
000070dabbde0e88  vmovaps xmm1, [rsp+0x10]
000070dabbde0e8e  vmovaps xmm2, [rsp+0x20]
000070dabbde0e94  vmovaps xmm3, [rsp+0x30]
000070dabbde0e9a  vmovaps xmm4, [rsp+0x40]
000070dabbde0ea0  vmovaps xmm5, [rsp+0x50]
000070dabbde0ea6  vmovaps xmm6, [rsp+0x60]
000070dabbde0eac  vmovaps xmm7, [rsp+0x70]
000070dabbde0eb2  vmovaps xmm8, [rsp+0x80]
000070dabbde0ebb  vmovaps xmm9, [rsp+0x90]
000070dabbde0ec4  vmovaps xmm10, [rsp+0xA0]
000070dabbde0ecd  vmovaps xmm11, [rsp+0xB0]
000070dabbde0ed6  vmovaps xmm13, [rsp+0xC0]
000070dabbde0edf  vmovaps xmm14, [rsp+0xD0]
000070dabbde0ee8  vmovaps xmm15, [rsp+0xE0]
000070dabbde0ef1  add rsp, 0xF0
000070dabbde0ef8  pop r11
000070dabbde0efa  pop r10
000070dabbde0efc  pop r9
000070dabbde0efe  pop r8
000070dabbde0f00  pop rsi
000070dabbde0f01  pop rdi
000070dabbde0f02  pop rdx
000070dabbde0f03  pop rcx
000070dabbde0f04  pop rax
000070dabbde0f05  add rsp, 0x08
000070dabbde0f09  jmp 0x000070DABBDDC6FC
000070dabbde0f0e  sub rsp, 0x08
000070dabbde0f12  push rax
000070dabbde0f13  push rcx
000070dabbde0f14  push rdx
000070dabbde0f15  push rdi
000070dabbde0f16  push rsi
000070dabbde0f17  push r8
000070dabbde0f19  push r9
000070dabbde0f1b  push r10
000070dabbde0f1d  push r11
000070dabbde0f1f  sub rsp, 0xF0
000070dabbde0f26  vmovaps [rsp], xmm0
000070dabbde0f2b  vmovaps [rsp+0x10], xmm1
000070dabbde0f31  vmovaps [rsp+0x20], xmm2
000070dabbde0f37  vmovaps [rsp+0x30], xmm3
000070dabbde0f3d  vmovaps [rsp+0x40], xmm4
000070dabbde0f43  vmovaps [rsp+0x50], xmm5
000070dabbde0f49  vmovaps [rsp+0x60], xmm6
000070dabbde0f4f  vmovaps [rsp+0x70], xmm7
000070dabbde0f55  vmovaps [rsp+0x80], xmm8
000070dabbde0f5e  vmovaps [rsp+0x90], xmm9
000070dabbde0f67  vmovaps [rsp+0xA0], xmm10
000070dabbde0f70  vmovaps [rsp+0xB0], xmm11
000070dabbde0f79  vmovaps [rsp+0xC0], xmm12
000070dabbde0f82  vmovaps [rsp+0xD0], xmm13
000070dabbde0f8b  vmovaps [rsp+0xE0], xmm15
000070dabbde0f94  sub rsp, 0x30
000070dabbde0f98  movaps [rsp], xmm14
000070dabbde0f9d  movaps [rsp+0x10], xmm9
000070dabbde0fa3  movaps [rsp+0x20], xmm1
000070dabbde0fa8  lea rdi, [rsp]
000070dabbde0fac  mov esi, 0x00
000070dabbde0fb1  mov rax, 0x5C2CF7B6F530
000070dabbde0fbb  call rax
000070dabbde0fbd  movaps xmm14, [rsp]
000070dabbde0fc2  add rsp, 0x30
000070dabbde0fc6  vmovaps xmm0, [rsp]
000070dabbde0fcb  vmovaps xmm1, [rsp+0x10]
000070dabbde0fd1  vmovaps xmm2, [rsp+0x20]
000070dabbde0fd7  vmovaps xmm3, [rsp+0x30]
000070dabbde0fdd  vmovaps xmm4, [rsp+0x40]
000070dabbde0fe3  vmovaps xmm5, [rsp+0x50]
000070dabbde0fe9  vmovaps xmm6, [rsp+0x60]
000070dabbde0fef  vmovaps xmm7, [rsp+0x70]
000070dabbde0ff5  vmovaps xmm8, [rsp+0x80]
000070dabbde0ffe  vmovaps xmm9, [rsp+0x90]
000070dabbde1007  vmovaps xmm10, [rsp+0xA0]
000070dabbde1010  vmovaps xmm11, [rsp+0xB0]
000070dabbde1019  vmovaps xmm12, [rsp+0xC0]
000070dabbde1022  vmovaps xmm13, [rsp+0xD0]
000070dabbde102b  vmovaps xmm15, [rsp+0xE0]
000070dabbde1034  add rsp, 0xF0
000070dabbde103b  pop r11
000070dabbde103d  pop r10
000070dabbde103f  pop r9
000070dabbde1041  pop r8
000070dabbde1043  pop rsi
000070dabbde1044  pop rdi
000070dabbde1045  pop rdx
000070dabbde1046  pop rcx
000070dabbde1047  pop rax
000070dabbde1048  add rsp, 0x08
000070dabbde104c  jmp 0x000070DABBDDC72B
000070dabbde1051  sub rsp, 0x08
000070dabbde1055  push rax
000070dabbde1056  push rcx
000070dabbde1057  push rdx
000070dabbde1058  push rdi
000070dabbde1059  push rsi
000070dabbde105a  push r8
000070dabbde105c  push r9
000070dabbde105e  push r10
000070dabbde1060  push r11
000070dabbde1062  sub rsp, 0xF0
000070dabbde1069  vmovaps [rsp], xmm0
000070dabbde106e  vmovaps [rsp+0x10], xmm2
000070dabbde1074  vmovaps [rsp+0x20], xmm3
000070dabbde107a  vmovaps [rsp+0x30], xmm4
000070dabbde1080  vmovaps [rsp+0x40], xmm5
000070dabbde1086  vmovaps [rsp+0x50], xmm6
000070dabbde108c  vmovaps [rsp+0x60], xmm7
000070dabbde1092  vmovaps [rsp+0x70], xmm8
000070dabbde1098  vmovaps [rsp+0x80], xmm9
000070dabbde10a1  vmovaps [rsp+0x90], xmm10
000070dabbde10aa  vmovaps [rsp+0xA0], xmm11
000070dabbde10b3  vmovaps [rsp+0xB0], xmm12
000070dabbde10bc  vmovaps [rsp+0xC0], xmm13
000070dabbde10c5  vmovaps [rsp+0xD0], xmm14
000070dabbde10ce  vmovaps [rsp+0xE0], xmm15
000070dabbde10d7  sub rsp, 0x30
000070dabbde10db  movaps [rsp], xmm1
000070dabbde10df  movaps [rsp+0x10], xmm13
000070dabbde10e5  movaps [rsp+0x20], xmm8
000070dabbde10eb  lea rdi, [rsp]
000070dabbde10ef  mov esi, 0x00
000070dabbde10f4  mov rax, 0x5C2CF7B6F530
000070dabbde10fe  call rax
000070dabbde1100  movaps xmm1, [rsp]
000070dabbde1104  add rsp, 0x30
000070dabbde1108  vmovaps xmm0, [rsp]
000070dabbde110d  vmovaps xmm2, [rsp+0x10]
000070dabbde1113  vmovaps xmm3, [rsp+0x20]
000070dabbde1119  vmovaps xmm4, [rsp+0x30]
000070dabbde111f  vmovaps xmm5, [rsp+0x40]
000070dabbde1125  vmovaps xmm6, [rsp+0x50]
000070dabbde112b  vmovaps xmm7, [rsp+0x60]
000070dabbde1131  vmovaps xmm8, [rsp+0x70]
000070dabbde1137  vmovaps xmm9, [rsp+0x80]
000070dabbde1140  vmovaps xmm10, [rsp+0x90]
000070dabbde1149  vmovaps xmm11, [rsp+0xA0]
000070dabbde1152  vmovaps xmm12, [rsp+0xB0]
000070dabbde115b  vmovaps xmm13, [rsp+0xC0]
000070dabbde1164  vmovaps xmm14, [rsp+0xD0]
000070dabbde116d  vmovaps xmm15, [rsp+0xE0]
000070dabbde1176  add rsp, 0xF0
000070dabbde117d  pop r11
000070dabbde117f  pop r10
000070dabbde1181  pop r9
000070dabbde1183  pop r8
000070dabbde1185  pop rsi
000070dabbde1186  pop rdi
000070dabbde1187  pop rdx
000070dabbde1188  pop rcx
000070dabbde1189  pop rax
000070dabbde118a  add rsp, 0x08
000070dabbde118e  jmp 0x000070DABBDDC74D
000070dabbde1193  call 0x000070DABBC0C260
000070dabbde1198  jmp 0x000070DABBDDC75B
000070dabbde119d  call 0x000070DABBCBD750
000070dabbde11a2  jmp 0x000070DABBDDC765
000070dabbde11a7  sub rsp, 0x08
000070dabbde11ab  push rax
000070dabbde11ac  push rcx
000070dabbde11ad  push rdx
000070dabbde11ae  push rdi
000070dabbde11af  push rsi
000070dabbde11b0  push r8
000070dabbde11b2  push r9
000070dabbde11b4  push r10
000070dabbde11b6  push r11
000070dabbde11b8  sub rsp, 0xF0
000070dabbde11bf  vmovaps [rsp], xmm0
000070dabbde11c4  vmovaps [rsp+0x10], xmm1
000070dabbde11ca  vmovaps [rsp+0x20], xmm2
000070dabbde11d0  vmovaps [rsp+0x30], xmm3
000070dabbde11d6  vmovaps [rsp+0x40], xmm4
000070dabbde11dc  vmovaps [rsp+0x50], xmm5
000070dabbde11e2  vmovaps [rsp+0x60], xmm6
000070dabbde11e8  vmovaps [rsp+0x70], xmm7
000070dabbde11ee  vmovaps [rsp+0x80], xmm9
000070dabbde11f7  vmovaps [rsp+0x90], xmm10
000070dabbde1200  vmovaps [rsp+0xA0], xmm11
000070dabbde1209  vmovaps [rsp+0xB0], xmm12
000070dabbde1212  vmovaps [rsp+0xC0], xmm13
000070dabbde121b  vmovaps [rsp+0xD0], xmm14
000070dabbde1224  vmovaps [rsp+0xE0], xmm15
000070dabbde122d  sub rsp, 0x30
000070dabbde1231  movaps [rsp], xmm8
000070dabbde1236  movaps [rsp+0x10], xmm15
000070dabbde123c  movaps [rsp+0x20], xmm7
000070dabbde1241  lea rdi, [rsp]
000070dabbde1245  mov esi, 0x00
000070dabbde124a  mov rax, 0x5C2CF7B6F530
000070dabbde1254  call rax
000070dabbde1256  movaps xmm8, [rsp]
000070dabbde125b  add rsp, 0x30
000070dabbde125f  vmovaps xmm0, [rsp]
000070dabbde1264  vmovaps xmm1, [rsp+0x10]
000070dabbde126a  vmovaps xmm2, [rsp+0x20]
000070dabbde1270  vmovaps xmm3, [rsp+0x30]
000070dabbde1276  vmovaps xmm4, [rsp+0x40]
000070dabbde127c  vmovaps xmm5, [rsp+0x50]
000070dabbde1282  vmovaps xmm6, [rsp+0x60]
000070dabbde1288  vmovaps xmm7, [rsp+0x70]
000070dabbde128e  vmovaps xmm9, [rsp+0x80]
000070dabbde1297  vmovaps xmm10, [rsp+0x90]
000070dabbde12a0  vmovaps xmm11, [rsp+0xA0]
000070dabbde12a9  vmovaps xmm12, [rsp+0xB0]
000070dabbde12b2  vmovaps xmm13, [rsp+0xC0]
000070dabbde12bb  vmovaps xmm14, [rsp+0xD0]
000070dabbde12c4  vmovaps xmm15, [rsp+0xE0]
000070dabbde12cd  add rsp, 0xF0
000070dabbde12d4  pop r11
000070dabbde12d6  pop r10
000070dabbde12d8  pop r9
000070dabbde12da  pop r8
000070dabbde12dc  pop rsi
000070dabbde12dd  pop rdi
000070dabbde12de  pop rdx
000070dabbde12df  pop rcx
000070dabbde12e0  pop rax
000070dabbde12e1  add rsp, 0x08
000070dabbde12e5  jmp 0x000070DABBDDC787
000070dabbde12ea  sub rsp, 0x08
000070dabbde12ee  push rax
000070dabbde12ef  push rcx
000070dabbde12f0  push rdx
000070dabbde12f1  push rdi
000070dabbde12f2  push rsi
000070dabbde12f3  push r8
000070dabbde12f5  push r9
000070dabbde12f7  push r10
000070dabbde12f9  push r11
000070dabbde12fb  sub rsp, 0xF0
000070dabbde1302  vmovaps [rsp], xmm0
000070dabbde1307  vmovaps [rsp+0x10], xmm1
000070dabbde130d  vmovaps [rsp+0x20], xmm2
000070dabbde1313  vmovaps [rsp+0x30], xmm3
000070dabbde1319  vmovaps [rsp+0x40], xmm4
000070dabbde131f  vmovaps [rsp+0x50], xmm5
000070dabbde1325  vmovaps [rsp+0x60], xmm6
000070dabbde132b  vmovaps [rsp+0x70], xmm8
000070dabbde1331  vmovaps [rsp+0x80], xmm9
000070dabbde133a  vmovaps [rsp+0x90], xmm10
000070dabbde1343  vmovaps [rsp+0xA0], xmm11
000070dabbde134c  vmovaps [rsp+0xB0], xmm12
000070dabbde1355  vmovaps [rsp+0xC0], xmm13
000070dabbde135e  vmovaps [rsp+0xD0], xmm14
000070dabbde1367  vmovaps [rsp+0xE0], xmm15
000070dabbde1370  sub rsp, 0x30
000070dabbde1374  movaps [rsp], xmm7
000070dabbde1378  movaps [rsp+0x10], xmm9
000070dabbde137e  movaps [rsp+0x20], xmm15
000070dabbde1384  lea rdi, [rsp]
000070dabbde1388  mov esi, 0x00
000070dabbde138d  mov rax, 0x5C2CF7B6F530
000070dabbde1397  call rax
000070dabbde1399  movaps xmm7, [rsp]
000070dabbde139d  add rsp, 0x30
000070dabbde13a1  vmovaps xmm0, [rsp]
000070dabbde13a6  vmovaps xmm1, [rsp+0x10]
000070dabbde13ac  vmovaps xmm2, [rsp+0x20]
000070dabbde13b2  vmovaps xmm3, [rsp+0x30]
000070dabbde13b8  vmovaps xmm4, [rsp+0x40]
000070dabbde13be  vmovaps xmm5, [rsp+0x50]
000070dabbde13c4  vmovaps xmm6, [rsp+0x60]
000070dabbde13ca  vmovaps xmm8, [rsp+0x70]
000070dabbde13d0  vmovaps xmm9, [rsp+0x80]
000070dabbde13d9  vmovaps xmm10, [rsp+0x90]
000070dabbde13e2  vmovaps xmm11, [rsp+0xA0]
000070dabbde13eb  vmovaps xmm12, [rsp+0xB0]
000070dabbde13f4  vmovaps xmm13, [rsp+0xC0]
000070dabbde13fd  vmovaps xmm14, [rsp+0xD0]
000070dabbde1406  vmovaps xmm15, [rsp+0xE0]
000070dabbde140f  add rsp, 0xF0
000070dabbde1416  pop r11
000070dabbde1418  pop r10
000070dabbde141a  pop r9
000070dabbde141c  pop r8
000070dabbde141e  pop rsi
000070dabbde141f  pop rdi
000070dabbde1420  pop rdx
000070dabbde1421  pop rcx
000070dabbde1422  pop rax
000070dabbde1423  add rsp, 0x08
000070dabbde1427  jmp 0x000070DABBDDC7B4
000070dabbde142c  sub rsp, 0x08
000070dabbde1430  push rax
000070dabbde1431  push rcx
000070dabbde1432  push rdx
000070dabbde1433  push rdi
000070dabbde1434  push rsi
000070dabbde1435  push r8
000070dabbde1437  push r9
000070dabbde1439  push r10
000070dabbde143b  push r11
000070dabbde143d  sub rsp, 0xF0
000070dabbde1444  vmovaps [rsp], xmm0
000070dabbde1449  vmovaps [rsp+0x10], xmm1
000070dabbde144f  vmovaps [rsp+0x20], xmm2
000070dabbde1455  vmovaps [rsp+0x30], xmm3
000070dabbde145b  vmovaps [rsp+0x40], xmm4
000070dabbde1461  vmovaps [rsp+0x50], xmm5
000070dabbde1467  vmovaps [rsp+0x60], xmm6
000070dabbde146d  vmovaps [rsp+0x70], xmm7
000070dabbde1473  vmovaps [rsp+0x80], xmm8
000070dabbde147c  vmovaps [rsp+0x90], xmm10
000070dabbde1485  vmovaps [rsp+0xA0], xmm11
000070dabbde148e  vmovaps [rsp+0xB0], xmm12
000070dabbde1497  vmovaps [rsp+0xC0], xmm13
000070dabbde14a0  vmovaps [rsp+0xD0], xmm14
000070dabbde14a9  vmovaps [rsp+0xE0], xmm15
000070dabbde14b2  sub rsp, 0x30
000070dabbde14b6  movaps [rsp], xmm9
000070dabbde14bb  movaps [rsp+0x10], xmm13
000070dabbde14c1  movaps [rsp+0x20], xmm15
000070dabbde14c7  lea rdi, [rsp]
000070dabbde14cb  mov esi, 0x00
000070dabbde14d0  mov rax, 0x5C2CF7B6F530
000070dabbde14da  call rax
000070dabbde14dc  movaps xmm9, [rsp]
000070dabbde14e1  add rsp, 0x30
000070dabbde14e5  vmovaps xmm0, [rsp]
000070dabbde14ea  vmovaps xmm1, [rsp+0x10]
000070dabbde14f0  vmovaps xmm2, [rsp+0x20]
000070dabbde14f6  vmovaps xmm3, [rsp+0x30]
000070dabbde14fc  vmovaps xmm4, [rsp+0x40]
000070dabbde1502  vmovaps xmm5, [rsp+0x50]
000070dabbde1508  vmovaps xmm6, [rsp+0x60]
000070dabbde150e  vmovaps xmm7, [rsp+0x70]
000070dabbde1514  vmovaps xmm8, [rsp+0x80]
000070dabbde151d  vmovaps xmm10, [rsp+0x90]
000070dabbde1526  vmovaps xmm11, [rsp+0xA0]
000070dabbde152f  vmovaps xmm12, [rsp+0xB0]
000070dabbde1538  vmovaps xmm13, [rsp+0xC0]
000070dabbde1541  vmovaps xmm14, [rsp+0xD0]
000070dabbde154a  vmovaps xmm15, [rsp+0xE0]
000070dabbde1553  add rsp, 0xF0
000070dabbde155a  pop r11
000070dabbde155c  pop r10
000070dabbde155e  pop r9
000070dabbde1560  pop r8
000070dabbde1562  pop rsi
000070dabbde1563  pop rdi
000070dabbde1564  pop rdx
000070dabbde1565  pop rcx
000070dabbde1566  pop rax
000070dabbde1567  add rsp, 0x08
000070dabbde156b  jmp 0x000070DABBDDC7E2
000070dabbde1570  sub rsp, 0x08
000070dabbde1574  push rax
000070dabbde1575  push rcx
000070dabbde1576  push rdx
000070dabbde1577  push rdi
000070dabbde1578  push rsi
000070dabbde1579  push r8
000070dabbde157b  push r9
000070dabbde157d  push r10
000070dabbde157f  push r11
000070dabbde1581  sub rsp, 0xF0
000070dabbde1588  vmovaps [rsp], xmm0
000070dabbde158d  vmovaps [rsp+0x10], xmm1
000070dabbde1593  vmovaps [rsp+0x20], xmm2
000070dabbde1599  vmovaps [rsp+0x30], xmm3
000070dabbde159f  vmovaps [rsp+0x40], xmm4
000070dabbde15a5  vmovaps [rsp+0x50], xmm5
000070dabbde15ab  vmovaps [rsp+0x60], xmm6
000070dabbde15b1  vmovaps [rsp+0x70], xmm7
000070dabbde15b7  vmovaps [rsp+0x80], xmm8
000070dabbde15c0  vmovaps [rsp+0x90], xmm9
000070dabbde15c9  vmovaps [rsp+0xA0], xmm10
000070dabbde15d2  vmovaps [rsp+0xB0], xmm11
000070dabbde15db  vmovaps [rsp+0xC0], xmm12
000070dabbde15e4  vmovaps [rsp+0xD0], xmm13
000070dabbde15ed  vmovaps [rsp+0xE0], xmm14
000070dabbde15f6  sub rsp, 0x30
000070dabbde15fa  movaps [rsp], xmm15
000070dabbde15ff  movaps [rsp+0x10], xmm11
000070dabbde1605  movaps [rsp+0x20], xmm12
000070dabbde160b  lea rdi, [rsp]
000070dabbde160f  mov esi, 0x00
000070dabbde1614  mov rax, 0x5C2CF7B6F530
000070dabbde161e  call rax
000070dabbde1620  movaps xmm15, [rsp]
000070dabbde1625  add rsp, 0x30
000070dabbde1629  vmovaps xmm0, [rsp]
000070dabbde162e  vmovaps xmm1, [rsp+0x10]
000070dabbde1634  vmovaps xmm2, [rsp+0x20]
000070dabbde163a  vmovaps xmm3, [rsp+0x30]
000070dabbde1640  vmovaps xmm4, [rsp+0x40]
000070dabbde1646  vmovaps xmm5, [rsp+0x50]
000070dabbde164c  vmovaps xmm6, [rsp+0x60]
000070dabbde1652  vmovaps xmm7, [rsp+0x70]
000070dabbde1658  vmovaps xmm8, [rsp+0x80]
000070dabbde1661  vmovaps xmm9, [rsp+0x90]
000070dabbde166a  vmovaps xmm10, [rsp+0xA0]
000070dabbde1673  vmovaps xmm11, [rsp+0xB0]
000070dabbde167c  vmovaps xmm12, [rsp+0xC0]
000070dabbde1685  vmovaps xmm13, [rsp+0xD0]
000070dabbde168e  vmovaps xmm14, [rsp+0xE0]
000070dabbde1697  add rsp, 0xF0
000070dabbde169e  pop r11
000070dabbde16a0  pop r10
000070dabbde16a2  pop r9
000070dabbde16a4  pop r8
000070dabbde16a6  pop rsi
000070dabbde16a7  pop rdi
000070dabbde16a8  pop rdx
000070dabbde16a9  pop rcx
000070dabbde16aa  pop rax
000070dabbde16ab  add rsp, 0x08
000070dabbde16af  jmp 0x000070DABBDDC7FD
000070dabbde16b4  sub rsp, 0x08
000070dabbde16b8  push rax
000070dabbde16b9  push rcx
000070dabbde16ba  push rdx
000070dabbde16bb  push rdi
000070dabbde16bc  push rsi
000070dabbde16bd  push r8
000070dabbde16bf  push r9
000070dabbde16c1  push r10
000070dabbde16c3  push r11
000070dabbde16c5  sub rsp, 0xF0
000070dabbde16cc  vmovaps [rsp], xmm0
000070dabbde16d1  vmovaps [rsp+0x10], xmm1
000070dabbde16d7  vmovaps [rsp+0x20], xmm2
000070dabbde16dd  vmovaps [rsp+0x30], xmm3
000070dabbde16e3  vmovaps [rsp+0x40], xmm4
000070dabbde16e9  vmovaps [rsp+0x50], xmm5
000070dabbde16ef  vmovaps [rsp+0x60], xmm6
000070dabbde16f5  vmovaps [rsp+0x70], xmm7
000070dabbde16fb  vmovaps [rsp+0x80], xmm8
000070dabbde1704  vmovaps [rsp+0x90], xmm9
000070dabbde170d  vmovaps [rsp+0xA0], xmm10
000070dabbde1716  vmovaps [rsp+0xB0], xmm11
000070dabbde171f  vmovaps [rsp+0xC0], xmm12
000070dabbde1728  vmovaps [rsp+0xD0], xmm14
000070dabbde1731  vmovaps [rsp+0xE0], xmm15
000070dabbde173a  sub rsp, 0x30
000070dabbde173e  movaps [rsp], xmm13
000070dabbde1743  movaps [rsp+0x10], xmm10
000070dabbde1749  movaps [rsp+0x20], xmm14
000070dabbde174f  lea rdi, [rsp]
000070dabbde1753  mov esi, 0x00
000070dabbde1758  mov rax, 0x5C2CF7B6F530
000070dabbde1762  call rax
000070dabbde1764  movaps xmm13, [rsp]
000070dabbde1769  add rsp, 0x30
000070dabbde176d  vmovaps xmm0, [rsp]
000070dabbde1772  vmovaps xmm1, [rsp+0x10]
000070dabbde1778  vmovaps xmm2, [rsp+0x20]
000070dabbde177e  vmovaps xmm3, [rsp+0x30]
000070dabbde1784  vmovaps xmm4, [rsp+0x40]
000070dabbde178a  vmovaps xmm5, [rsp+0x50]
000070dabbde1790  vmovaps xmm6, [rsp+0x60]
000070dabbde1796  vmovaps xmm7, [rsp+0x70]
000070dabbde179c  vmovaps xmm8, [rsp+0x80]
000070dabbde17a5  vmovaps xmm9, [rsp+0x90]
000070dabbde17ae  vmovaps xmm10, [rsp+0xA0]
000070dabbde17b7  vmovaps xmm11, [rsp+0xB0]
000070dabbde17c0  vmovaps xmm12, [rsp+0xC0]
000070dabbde17c9  vmovaps xmm14, [rsp+0xD0]
000070dabbde17d2  vmovaps xmm15, [rsp+0xE0]
000070dabbde17db  add rsp, 0xF0
000070dabbde17e2  pop r11
000070dabbde17e4  pop r10
000070dabbde17e6  pop r9
000070dabbde17e8  pop r8
000070dabbde17ea  pop rsi
000070dabbde17eb  pop rdi
000070dabbde17ec  pop rdx
000070dabbde17ed  pop rcx
000070dabbde17ee  pop rax
000070dabbde17ef  add rsp, 0x08
000070dabbde17f3  jmp 0x000070DABBDDC820
000070dabbde17f8  sub rsp, 0x08
000070dabbde17fc  push rax
000070dabbde17fd  push rcx
000070dabbde17fe  push rdx
000070dabbde17ff  push rdi
000070dabbde1800  push rsi
000070dabbde1801  push r8
000070dabbde1803  push r9
000070dabbde1805  push r10
000070dabbde1807  push r11
000070dabbde1809  sub rsp, 0xF0
000070dabbde1810  vmovaps [rsp], xmm0
000070dabbde1815  vmovaps [rsp+0x10], xmm1
000070dabbde181b  vmovaps [rsp+0x20], xmm2
000070dabbde1821  vmovaps [rsp+0x30], xmm3
000070dabbde1827  vmovaps [rsp+0x40], xmm4
000070dabbde182d  vmovaps [rsp+0x50], xmm5
000070dabbde1833  vmovaps [rsp+0x60], xmm6
000070dabbde1839  vmovaps [rsp+0x70], xmm7
000070dabbde183f  vmovaps [rsp+0x80], xmm8
000070dabbde1848  vmovaps [rsp+0x90], xmm9
000070dabbde1851  vmovaps [rsp+0xA0], xmm10
000070dabbde185a  vmovaps [rsp+0xB0], xmm11
000070dabbde1863  vmovaps [rsp+0xC0], xmm12
000070dabbde186c  vmovaps [rsp+0xD0], xmm13
000070dabbde1875  vmovaps [rsp+0xE0], xmm15
000070dabbde187e  sub rsp, 0x30
000070dabbde1882  movaps [rsp], xmm14
000070dabbde1887  movaps [rsp+0x10], xmm1
000070dabbde188c  movaps [rsp+0x20], xmm7
000070dabbde1891  lea rdi, [rsp]
000070dabbde1895  mov esi, 0x00
000070dabbde189a  mov rax, 0x5C2CF7B6F530
000070dabbde18a4  call rax
000070dabbde18a6  movaps xmm14, [rsp]
000070dabbde18ab  add rsp, 0x30
000070dabbde18af  vmovaps xmm0, [rsp]
000070dabbde18b4  vmovaps xmm1, [rsp+0x10]
000070dabbde18ba  vmovaps xmm2, [rsp+0x20]
000070dabbde18c0  vmovaps xmm3, [rsp+0x30]
000070dabbde18c6  vmovaps xmm4, [rsp+0x40]
000070dabbde18cc  vmovaps xmm5, [rsp+0x50]
000070dabbde18d2  vmovaps xmm6, [rsp+0x60]
000070dabbde18d8  vmovaps xmm7, [rsp+0x70]
000070dabbde18de  vmovaps xmm8, [rsp+0x80]
000070dabbde18e7  vmovaps xmm9, [rsp+0x90]
000070dabbde18f0  vmovaps xmm10, [rsp+0xA0]
000070dabbde18f9  vmovaps xmm11, [rsp+0xB0]
000070dabbde1902  vmovaps xmm12, [rsp+0xC0]
000070dabbde190b  vmovaps xmm13, [rsp+0xD0]
000070dabbde1914  vmovaps xmm15, [rsp+0xE0]
000070dabbde191d  add rsp, 0xF0
000070dabbde1924  pop r11
000070dabbde1926  pop r10
000070dabbde1928  pop r9
000070dabbde192a  pop r8
000070dabbde192c  pop rsi
000070dabbde192d  pop rdi
000070dabbde192e  pop rdx
000070dabbde192f  pop rcx
000070dabbde1930  pop rax
000070dabbde1931  add rsp, 0x08
000070dabbde1935  jmp 0x000070DABBDDC843
000070dabbde193a  sub rsp, 0x08
000070dabbde193e  push rax
000070dabbde193f  push rcx
000070dabbde1940  push rdx
000070dabbde1941  push rdi
000070dabbde1942  push rsi
000070dabbde1943  push r8
000070dabbde1945  push r9
000070dabbde1947  push r10
000070dabbde1949  push r11
000070dabbde194b  sub rsp, 0xF0
000070dabbde1952  vmovaps [rsp], xmm0
000070dabbde1957  vmovaps [rsp+0x10], xmm2
000070dabbde195d  vmovaps [rsp+0x20], xmm3
000070dabbde1963  vmovaps [rsp+0x30], xmm4
000070dabbde1969  vmovaps [rsp+0x40], xmm5
000070dabbde196f  vmovaps [rsp+0x50], xmm6
000070dabbde1975  vmovaps [rsp+0x60], xmm7
000070dabbde197b  vmovaps [rsp+0x70], xmm8
000070dabbde1981  vmovaps [rsp+0x80], xmm9
000070dabbde198a  vmovaps [rsp+0x90], xmm10
000070dabbde1993  vmovaps [rsp+0xA0], xmm11
000070dabbde199c  vmovaps [rsp+0xB0], xmm12
000070dabbde19a5  vmovaps [rsp+0xC0], xmm13
000070dabbde19ae  vmovaps [rsp+0xD0], xmm14
000070dabbde19b7  vmovaps [rsp+0xE0], xmm15
000070dabbde19c0  sub rsp, 0x30
000070dabbde19c4  movaps [rsp], xmm1
000070dabbde19c8  movaps [rsp+0x10], xmm8
000070dabbde19ce  movaps [rsp+0x20], xmm9
000070dabbde19d4  lea rdi, [rsp]
000070dabbde19d8  mov esi, 0x00
000070dabbde19dd  mov rax, 0x5C2CF7B6F530
000070dabbde19e7  call rax
000070dabbde19e9  movaps xmm1, [rsp]
000070dabbde19ed  add rsp, 0x30
000070dabbde19f1  vmovaps xmm0, [rsp]
000070dabbde19f6  vmovaps xmm2, [rsp+0x10]
000070dabbde19fc  vmovaps xmm3, [rsp+0x20]
000070dabbde1a02  vmovaps xmm4, [rsp+0x30]
000070dabbde1a08  vmovaps xmm5, [rsp+0x40]
000070dabbde1a0e  vmovaps xmm6, [rsp+0x50]
000070dabbde1a14  vmovaps xmm7, [rsp+0x60]
000070dabbde1a1a  vmovaps xmm8, [rsp+0x70]
000070dabbde1a20  vmovaps xmm9, [rsp+0x80]
000070dabbde1a29  vmovaps xmm10, [rsp+0x90]
000070dabbde1a32  vmovaps xmm11, [rsp+0xA0]
000070dabbde1a3b  vmovaps xmm12, [rsp+0xB0]
000070dabbde1a44  vmovaps xmm13, [rsp+0xC0]
000070dabbde1a4d  vmovaps xmm14, [rsp+0xD0]
000070dabbde1a56  vmovaps xmm15, [rsp+0xE0]
000070dabbde1a5f  add rsp, 0xF0
000070dabbde1a66  pop r11
000070dabbde1a68  pop r10
000070dabbde1a6a  pop r9
000070dabbde1a6c  pop r8
000070dabbde1a6e  pop rsi
000070dabbde1a6f  pop rdi
000070dabbde1a70  pop rdx
000070dabbde1a71  pop rcx
000070dabbde1a72  pop rax
000070dabbde1a73  add rsp, 0x08
000070dabbde1a77  jmp 0x000070DABBDDC865
000070dabbde1a7c  call 0x000070DABBCE5940
000070dabbde1a81  jmp 0x000070DABBDDC873
000070dabbde1a86  call 0x000070DABBC0C380
000070dabbde1a8b  jmp 0x000070DABBDDC87D
000070dabbde1a90  call 0x000070DABBC0D600
000070dabbde1a95  jmp 0x000070DABBDDC887
000070dabbde1a9a  call 0x000070DABBBFF540
000070dabbde1a9f  jmp 0x000070DABBDDC891
000070dabbde1aa4  int3
000070dabbde1aa5  nop [rax+rax*1], ax
000070dabbde1aae  nop
000070dabbde1ab0  mov rax, [r15+0xF8]
000070dabbde1ab7  lea r14, [rax+0x140]
000070dabbde1abe  mov r12, [r13+r14*1]
000070dabbde1ac3  mov [r15+0xE8], r12
000070dabbde1aca  lea r14, [rax+0x130]
000070dabbde1ad1  mov r12, [r13+r14*1]
000070dabbde1ad6  lea r14, [rax+0x138]
000070dabbde1add  mov r11, [r13+r14*1]
000070dabbde1ae2  movq xmm1, r12
000070dabbde1ae7  movq xmm15, r11
000070dabbde1aec  movq xmm1, xmm1
000070dabbde1af0  movq xmm1, xmm1
000070dabbde1af4  movaps [r15+0x1A0], xmm1
000070dabbde1afc  movq xmm15, xmm15
000070dabbde1b01  movq xmm15, xmm15
000070dabbde1b06  movaps [r15+0x190], xmm15
000070dabbde1b0e  lea r14, [rax+0x120]
000070dabbde1b15  mov r12, [r13+r14*1]
000070dabbde1b1a  lea r14, [rax+0x128]
000070dabbde1b21  mov r11, [r13+r14*1]
000070dabbde1b26  movq xmm1, r12
000070dabbde1b2b  movq xmm15, r11
000070dabbde1b30  movq xmm1, xmm1
000070dabbde1b34  movq xmm1, xmm1
000070dabbde1b38  movaps [r15+0x1C0], xmm1
000070dabbde1b40  movq xmm15, xmm15
000070dabbde1b45  movq xmm15, xmm15
000070dabbde1b4a  movaps [r15+0x1B0], xmm15
000070dabbde1b52  lea r14, [rax+0x110]
000070dabbde1b59  mov r12, [r13+r14*1]
000070dabbde1b5e  lea r14, [rax+0x118]
000070dabbde1b65  mov r11, [r13+r14*1]
000070dabbde1b6a  movq xmm1, r12
000070dabbde1b6f  movq xmm15, r11
000070dabbde1b74  movq xmm1, xmm1
000070dabbde1b78  movq xmm1, xmm1
000070dabbde1b7c  movaps [r15+0x1E0], xmm1
000070dabbde1b84  movq xmm15, xmm15
000070dabbde1b89  movq xmm15, xmm15
000070dabbde1b8e  movaps [r15+0x1D0], xmm15
000070dabbde1b96  lea r14, [rax+0x100]
000070dabbde1b9d  mov r12, [r13+r14*1]
000070dabbde1ba2  lea r14, [rax+0x108]
000070dabbde1ba9  mov r11, [r13+r14*1]
000070dabbde1bae  movq xmm1, r12
000070dabbde1bb3  movq xmm15, r11
000070dabbde1bb8  movq xmm1, xmm1
000070dabbde1bbc  movq xmm1, xmm1
000070dabbde1bc0  movaps [r15+0x200], xmm1
000070dabbde1bc8  movq xmm15, xmm15
000070dabbde1bcd  movq xmm15, xmm15
000070dabbde1bd2  movaps [r15+0x1F0], xmm15
000070dabbde1bda  mov qword ptr [r15+0x40], 0x430000
000070dabbde1be2  mov r14d, 0x430510
000070dabbde1be8  mov r12, [r13+r14*1]
000070dabbde1bed  movq xmm1, r12
000070dabbde1bf2  lea r14, [rax+0x150]
000070dabbde1bf9  mov [r15+0xF8], r14
000070dabbde1c00  mov rax, [r15+0x50]
000070dabbde1c04  movups xmm15, [r13+rax*1]
000070dabbde1c0a  movaps [r15+0x120], xmm15
000070dabbde1c12  mov qword ptr [r15+0x48], 0x10
000070dabbde1c1a  xor eax, eax
000070dabbde1c1c  mov r14d, 0x10
000070dabbde1c22  mov r12d, 0x200
000070dabbde1c28  cmp r14, r12
000070dabbde1c2b  cmc
000070dabbde1c2c  lahf
000070dabbde1c2d  seto al
000070dabbde1c30  mov [r15+0x108], eax
000070dabbde1c37  pextrq rax, xmm15, 0x01
000070dabbde1c3e  movq xmm14, rax
000070dabbde1c43  movaps [r15+0x130], xmm14
000070dabbde1c4b  movq rax, xmm1
000070dabbde1c50  movq r14, xmm15
000070dabbde1c55  vmovq xmm1, rax
000070dabbde1c5a  vmovq xmm15, r14
000070dabbde1c5f  movaps xmm13, xmm1
000070dabbde1c63  addsd xmm13, xmm15
000070dabbde1c68  ucomisd xmm13, xmm13
000070dabbde1c6d  jp 0x000070DABBDE1D86
000070dabbde1c73  movq xmm13, xmm13
000070dabbde1c78  movq rax, xmm13
000070dabbde1c7d  movq r14, xmm14
000070dabbde1c82  vmovq xmm1, rax
000070dabbde1c87  vmovq xmm15, r14
000070dabbde1c8c  movaps xmm14, xmm1
000070dabbde1c90  addsd xmm14, xmm15
000070dabbde1c95  ucomisd xmm14, xmm14
000070dabbde1c9a  jp 0x000070DABBDE1DCE
000070dabbde1ca0  movq xmm14, xmm14
000070dabbde1ca5  movaps [r15+0x110], xmm14
000070dabbde1cad  mov eax, [r15+0x108]
000070dabbde1cb4  sahf
000070dabbde1cb5  jnz 0x000070DABBDE1CE7
000070dabbde1cb7  cmp dword ptr [r15+0x318], 0x00
000070dabbde1cbf  jz 0x000070DABBDE1FE0
000070dabbde1cc5  nop [rax+rax*1], ax
000070dabbde1cce  nop [rax+rax*1], eax
000070dabbde1cd6  mov eax, 0x410490
000070dabbde1cdb  mov [r15+0x100], rax
000070dabbde1ce2  jmp 0x000070DABBBFE110
000070dabbde1ce7  cmp dword ptr [r15+0x318], 0x00
000070dabbde1cef  jz 0x000070DABBDE1E20
000070dabbde1cf5  nop [rax+rax*1], ax
000070dabbde1cfe  nop [rax+rax*1], eax
000070dabbde1d06  mov eax, 0x410474
000070dabbde1d0b  mov [r15+0x100], rax
000070dabbde1d12  jmp 0x000070DABBBFE110
000070dabbde1d17  int3
000070dabbde1d18  call 0x000070DABBCE27E0
000070dabbde1d1d  jmp 0x000070DABBDE1AC3
000070dabbde1d22  call 0x000070DABBCE27E0
000070dabbde1d27  jmp 0x000070DABBDE1AD6
000070dabbde1d2c  call 0x000070DABBCE1570
000070dabbde1d31  jmp 0x000070DABBDE1AE2
000070dabbde1d36  call 0x000070DABBCE27E0
000070dabbde1d3b  jmp 0x000070DABBDE1B1A
000070dabbde1d40  call 0x000070DABBCE1570
000070dabbde1d45  jmp 0x000070DABBDE1B26
000070dabbde1d4a  call 0x000070DABBCE27E0
000070dabbde1d4f  jmp 0x000070DABBDE1B5E
000070dabbde1d54  call 0x000070DABBCE1570
000070dabbde1d59  jmp 0x000070DABBDE1B6A
000070dabbde1d5e  call 0x000070DABBCE27E0
000070dabbde1d63  jmp 0x000070DABBDE1BA2
000070dabbde1d68  call 0x000070DABBCE1570
000070dabbde1d6d  jmp 0x000070DABBDE1BAE
000070dabbde1d72  call 0x000070DABBCE27E0
000070dabbde1d77  jmp 0x000070DABBDE1BED
000070dabbde1d7c  call 0x000070DABBC0E760
000070dabbde1d81  jmp 0x000070DABBDE1C0A
000070dabbde1d86  ucomisd xmm1, xmm15
000070dabbde1d8b  jp 0x000070DABBDE1D9A
000070dabbde1d8d  movaps xmm13, [0x000070DABB9FE060]
000070dabbde1d95  jmp 0x000070DABBDE1C73
000070dabbde1d9a  vxorps xmm0, xmm1, xmm15
000070dabbde1d9f  pextrw eax, xmm0, 0x03
000070dabbde1da4  and eax, 0x7FF8
000070dabbde1da9  cmp eax, 0x08
000070dabbde1dac  jnz 0x000070DABBDE1C73
000070dabbde1db2  movq rax, xmm15
000070dabbde1db7  shl rax, 0x0D
000070dabbde1dbb  jbe 0x000070DABBDE1C73
000070dabbde1dc1  vorps xmm13, xmm15, [0x000070DABB9FE070]
000070dabbde1dc9  jmp 0x000070DABBDE1C73
000070dabbde1dce  ucomisd xmm1, xmm15
000070dabbde1dd3  jp 0x000070DABBDE1DE2
000070dabbde1dd5  movaps xmm14, [0x000070DABB9FE060]
000070dabbde1ddd  jmp 0x000070DABBDE1CA0
000070dabbde1de2  vxorps xmm0, xmm1, xmm15
000070dabbde1de7  pextrw eax, xmm0, 0x03
000070dabbde1dec  and eax, 0x7FF8
000070dabbde1df1  cmp eax, 0x08
000070dabbde1df4  jnz 0x000070DABBDE1CA0
000070dabbde1dfa  movq rax, xmm15
000070dabbde1dff  shl rax, 0x0D
000070dabbde1e03  jbe 0x000070DABBDE1CA0
000070dabbde1e09  vorps xmm14, xmm15, [0x000070DABB9FE070]
000070dabbde1e11  jmp 0x000070DABBDE1CA0
000070dabbde1e16  int3
000070dabbde1e17  nop [rax+rax*1], ax
000070dabbde1e20  mov rax, [r15+0x48]
000070dabbde1e24  mov r14, [r15+0x50]
000070dabbde1e28  lea r12, [r14+rax*1]
000070dabbde1e2c  movups xmm1, [r13+r12*1]
000070dabbde1e32  movaps [r15+0x120], xmm1
000070dabbde1e3a  lea r14, [rax+0x10]
000070dabbde1e3e  mov [r15+0x48], r14
000070dabbde1e42  xor eax, eax
000070dabbde1e44  mov r12d, 0x200
000070dabbde1e4a  cmp r14, r12
000070dabbde1e4d  cmc
000070dabbde1e4e  lahf
000070dabbde1e4f  seto al
000070dabbde1e52  mov [r15+0x108], eax
000070dabbde1e59  pextrq rax, xmm1, 0x01
000070dabbde1e60  movq xmm15, rax
000070dabbde1e65  movaps [r15+0x130], xmm15
000070dabbde1e6d  movaps xmm14, [r15+0x110]
000070dabbde1e75  movq rax, xmm14
000070dabbde1e7a  movq r14, xmm1
000070dabbde1e7f  vmovq xmm1, rax
000070dabbde1e84  vmovq xmm14, r14
000070dabbde1e89  movaps xmm13, xmm1
000070dabbde1e8d  addsd xmm13, xmm14
000070dabbde1e92  ucomisd xmm13, xmm13
000070dabbde1e97  jp 0x000070DABBDE1F4C
000070dabbde1e9d  movq xmm13, xmm13
000070dabbde1ea2  movq rax, xmm13
000070dabbde1ea7  movq r14, xmm15
000070dabbde1eac  vmovq xmm1, rax
000070dabbde1eb1  vmovq xmm15, r14
000070dabbde1eb6  movaps xmm14, xmm1
000070dabbde1eba  addsd xmm14, xmm15
000070dabbde1ebf  ucomisd xmm14, xmm14
000070dabbde1ec4  jp 0x000070DABBDE1F94
000070dabbde1eca  movq xmm14, xmm14
000070dabbde1ecf  movaps [r15+0x110], xmm14
000070dabbde1ed7  mov eax, [r15+0x108]
000070dabbde1ede  sahf
000070dabbde1edf  jnz 0x000070DABBDE1F11
000070dabbde1ee1  cmp dword ptr [r15+0x318], 0x00
000070dabbde1ee9  jz 0x000070DABBDE1FE0
000070dabbde1eef  nop [rax+rax*1], ax
000070dabbde1ef8  nop [rax+rax*1], eax
000070dabbde1f00  mov eax, 0x410490
000070dabbde1f05  mov [r15+0x100], rax
000070dabbde1f0c  jmp 0x000070DABBBFE110
000070dabbde1f11  cmp dword ptr [r15+0x318], 0x00
000070dabbde1f19  jz 0x000070DABBDE1E20
000070dabbde1f1f  nop [rax+rax*1], ax
000070dabbde1f28  nop [rax+rax*1], eax
000070dabbde1f30  mov eax, 0x410474
000070dabbde1f35  mov [r15+0x100], rax
000070dabbde1f3c  jmp 0x000070DABBBFE110
000070dabbde1f41  int3
000070dabbde1f42  call 0x000070DABBCB52F0
000070dabbde1f47  jmp 0x000070DABBDE1E32
000070dabbde1f4c  ucomisd xmm1, xmm14
000070dabbde1f51  jp 0x000070DABBDE1F60
000070dabbde1f53  movaps xmm13, [0x000070DABB9FE060]
000070dabbde1f5b  jmp 0x000070DABBDE1E9D
000070dabbde1f60  vxorps xmm0, xmm1, xmm14
000070dabbde1f65  pextrw eax, xmm0, 0x03
000070dabbde1f6a  and eax, 0x7FF8
000070dabbde1f6f  cmp eax, 0x08
000070dabbde1f72  jnz 0x000070DABBDE1E9D
000070dabbde1f78  movq rax, xmm14
000070dabbde1f7d  shl rax, 0x0D
000070dabbde1f81  jbe 0x000070DABBDE1E9D
000070dabbde1f87  vorps xmm13, xmm14, [0x000070DABB9FE070]
000070dabbde1f8f  jmp 0x000070DABBDE1E9D
000070dabbde1f94  ucomisd xmm1, xmm15
000070dabbde1f99  jp 0x000070DABBDE1FA8
000070dabbde1f9b  movaps xmm14, [0x000070DABB9FE060]
000070dabbde1fa3  jmp 0x000070DABBDE1ECA
000070dabbde1fa8  vxorps xmm0, xmm1, xmm15
000070dabbde1fad  pextrw eax, xmm0, 0x03
000070dabbde1fb2  and eax, 0x7FF8
000070dabbde1fb7  cmp eax, 0x08
000070dabbde1fba  jnz 0x000070DABBDE1ECA
000070dabbde1fc0  movq rax, xmm15
000070dabbde1fc5  shl rax, 0x0D
000070dabbde1fc9  jbe 0x000070DABBDE1ECA
000070dabbde1fcf  vorps xmm14, xmm15, [0x000070DABB9FE070]
000070dabbde1fd7  jmp 0x000070DABBDE1ECA
000070dabbde1fdc  int3
000070dabbde1fdd  nop [rax], eax
000070dabbde1fe0  mov rax, [r15+0x40]
000070dabbde1fe4  lea r14, [rax+0x510]
000070dabbde1feb  movaps xmm1, [r15+0x110]
000070dabbde1ff3  movq rax, xmm1
000070dabbde1ff8  mov [r13+r14*1], rax
000070dabbde1ffd  mov rax, [r15+0xF0]
000070dabbde2004  mov [r15+0x100], rax
000070dabbde200b  jmp 0x000070DABBDCE5C0
000070dabbde2010  int3
000070dabbde2011  call 0x000070DABBCD5EB0
000070dabbde2016  jmp 0x000070DABBDE1FFD
000070dabbde201b  int3
000070dabbde201c  nop [rax], eax
000070dabbde2020  mov qword ptr [r15+0x100], 0x04
000070dabbde202b  mov esi, 0x00
000070dabbde2030  mov edx, 0x09
000070dabbde2035  mov rdi, 0x7FFE3933C0D0
000070dabbde203f  mov rax, 0x5C2CF7A02970
000070dabbde2049  call rax
000070dabbde204b  cmp dword ptr [r15+0x318], 0x00
000070dabbde2053  jnz 0x000070DABBBFE110
000070dabbde2059  jmp 0x000070DABBBFE0A0
000070dabbde205e  int3
000070dabbde205f  int3
