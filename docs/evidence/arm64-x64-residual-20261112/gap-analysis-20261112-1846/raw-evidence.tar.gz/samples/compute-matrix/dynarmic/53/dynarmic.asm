0000777bb65ce69b  nop [rax+rax*1], eax
0000777bb65ce6a0  vmovaps xmm1, [0x0000777BB61FE010]
0000777bb65ce6a8  movq xmm1, xmm1
0000777bb65ce6ac  movaps [r15+0x110], xmm1
0000777bb65ce6b4  vmovaps xmm1, [0x0000777BB61FE020]
0000777bb65ce6bc  movq xmm1, xmm1
0000777bb65ce6c0  movaps [r15+0x120], xmm1
0000777bb65ce6c8  mov eax, 0x4204C0
0000777bb65ce6cd  mov r14, [r13+rax*1]
0000777bb65ce6d2  movq xmm1, r14
0000777bb65ce6d7  movaps [r15+0x130], xmm1
0000777bb65ce6df  vmovaps xmm1, [0x0000777BB61FE030]
0000777bb65ce6e7  vpbroadcastq xmm1, xmm1
0000777bb65ce6ec  movaps [r15+0x140], xmm1
0000777bb65ce6f4  mov qword ptr [r15+0x40], 0x02
0000777bb65ce6fc  vmovaps xmm15, [0x0000777BB61FE040]
0000777bb65ce704  movq xmm15, xmm15
0000777bb65ce709  movaps [r15+0x150], xmm15
0000777bb65ce711  mov qword ptr [r15+0x58], 0x420000
0000777bb65ce719  vmovaps xmm15, [0x0000777BB61FE050]
0000777bb65ce721  vpbroadcastq xmm15, xmm15
0000777bb65ce726  movaps [r15+0x160], xmm15
0000777bb65ce72e  mov rax, [r15+0x40]
0000777bb65ce732  vmovq xmm14, rax
0000777bb65ce737  vpbroadcastq xmm14, xmm14
0000777bb65ce73c  movaps [r15+0x170], xmm14
0000777bb65ce744  mov eax, 0x4204D0
0000777bb65ce749  movups xmm13, [r13+rax*1]
0000777bb65ce74f  mov qword ptr [r15+0x40], 0x430518
0000777bb65ce757  mov qword ptr [r15+0x50], 0x430720
0000777bb65ce75f  vpmovqd xmm12, xmm13
0000777bb65ce765  pxor xmm11, xmm11
0000777bb65ce76a  punpcklqdq xmm12, xmm11
0000777bb65ce76f  movaps [r15+0x210], xmm12
0000777bb65ce777  movq xmm12, qword ptr [r15+0x120]
0000777bb65ce780  movq xmm11, qword ptr [r15+0x130]
0000777bb65ce789  psubd xmm12, xmm11
0000777bb65ce78e  movq xmm12, xmm12
0000777bb65ce793  paddq xmm13, xmm14
0000777bb65ce798  movaps [r15+0x180], xmm13
0000777bb65ce7a0  movq xmm14, qword ptr [r15+0x150]
0000777bb65ce7a9  paddd xmm11, xmm14
0000777bb65ce7ae  movq xmm11, xmm11
0000777bb65ce7b3  movq xmm11, xmm11
0000777bb65ce7b8  movaps [r15+0x130], xmm11
0000777bb65ce7c0  pmovzxdq xmm12, xmm12
0000777bb65ce7c6  psllq xmm12, 0x00
0000777bb65ce7cc  movq xmm14, qword ptr [r15+0x210]
0000777bb65ce7d5  movq xmm13, qword ptr [r15+0x110]
0000777bb65ce7de  paddd xmm14, xmm13
0000777bb65ce7e3  movq xmm14, xmm14
0000777bb65ce7e8  vcvtuqq2pd xmm12, xmm12
0000777bb65ce7ee  pmovzxdq xmm14, xmm14
0000777bb65ce7f4  psllq xmm14, 0x00
0000777bb65ce7fa  vcvtuqq2pd xmm14, xmm14
0000777bb65ce800  movaps xmm13, xmm12
0000777bb65ce804  mulpd xmm13, xmm1
0000777bb65ce809  vcmppd xmm11, xmm13, xmm13, 0x03
0000777bb65ce80f  ptest xmm11, xmm11
0000777bb65ce815  jnz 0x0000777BB65CE8FF
0000777bb65ce81b  movaps [r15+0x220], xmm13
0000777bb65ce823  mov eax, 0x430720
0000777bb65ce828  movups [r13+rax*1], xmm13
0000777bb65ce82e  movaps xmm1, xmm14
0000777bb65ce832  mulpd xmm1, xmm15
0000777bb65ce837  vcmppd xmm13, xmm1, xmm1, 0x03
0000777bb65ce83c  ptest xmm13, xmm13
0000777bb65ce842  jnz 0x0000777BB65CEA4C
0000777bb65ce848  movaps [r15+0x210], xmm1
0000777bb65ce850  mov eax, 0x430518
0000777bb65ce855  movups [r13+rax*1], xmm1
0000777bb65ce85b  mov qword ptr [r15+0x48], 0x10
0000777bb65ce863  xor eax, eax
0000777bb65ce865  mov r14d, 0x10
0000777bb65ce86b  mov r12d, 0x200
0000777bb65ce871  cmp r14, r12
0000777bb65ce874  cmc
0000777bb65ce875  lahf
0000777bb65ce876  seto al
0000777bb65ce879  mov [r15+0x108], eax
0000777bb65ce880  mov eax, [r15+0x108]
0000777bb65ce887  sahf
0000777bb65ce888  jnz 0x0000777BB65CE8BA
0000777bb65ce88a  cmp dword ptr [r15+0x318], 0x00
0000777bb65ce892  jz 0x0000777BB65CEFF0
0000777bb65ce898  nop [rax+rax*1], ax
0000777bb65ce8a1  nop [rax+rax*1], eax
0000777bb65ce8a9  mov eax, 0x4101EC
0000777bb65ce8ae  mov [r15+0x100], rax
0000777bb65ce8b5  jmp 0x0000777BB63FE110
0000777bb65ce8ba  cmp dword ptr [r15+0x318], 0x00
0000777bb65ce8c2  jz 0x0000777BB65CEBA0
0000777bb65ce8c8  nop [rax+rax*1], ax
0000777bb65ce8d1  nop [rax+rax*1], eax
0000777bb65ce8d9  mov eax, 0x4101AC
0000777bb65ce8de  mov [r15+0x100], rax
0000777bb65ce8e5  jmp 0x0000777BB63FE110
0000777bb65ce8ea  int3
0000777bb65ce8eb  call 0x0000777BB640DC20
0000777bb65ce8f0  jmp 0x0000777BB65CE6D2
0000777bb65ce8f5  call 0x0000777BB640C260
0000777bb65ce8fa  jmp 0x0000777BB65CE74F
0000777bb65ce8ff  sub rsp, 0x08
0000777bb65ce903  push rax
0000777bb65ce904  push rcx
0000777bb65ce905  push rdx
0000777bb65ce906  push rdi
0000777bb65ce907  push rsi
0000777bb65ce908  push r8
0000777bb65ce90a  push r9
0000777bb65ce90c  push r10
0000777bb65ce90e  push r11
0000777bb65ce910  sub rsp, 0xF0
0000777bb65ce917  vmovaps [rsp], xmm0
0000777bb65ce91c  vmovaps [rsp+0x10], xmm1
0000777bb65ce922  vmovaps [rsp+0x20], xmm2
0000777bb65ce928  vmovaps [rsp+0x30], xmm3
0000777bb65ce92e  vmovaps [rsp+0x40], xmm4
0000777bb65ce934  vmovaps [rsp+0x50], xmm5
0000777bb65ce93a  vmovaps [rsp+0x60], xmm6
0000777bb65ce940  vmovaps [rsp+0x70], xmm7
0000777bb65ce946  vmovaps [rsp+0x80], xmm8
0000777bb65ce94f  vmovaps [rsp+0x90], xmm9
0000777bb65ce958  vmovaps [rsp+0xA0], xmm10
0000777bb65ce961  vmovaps [rsp+0xB0], xmm11
0000777bb65ce96a  vmovaps [rsp+0xC0], xmm12
0000777bb65ce973  vmovaps [rsp+0xD0], xmm14
0000777bb65ce97c  vmovaps [rsp+0xE0], xmm15
0000777bb65ce985  sub rsp, 0x30
0000777bb65ce989  movaps [rsp], xmm13
0000777bb65ce98e  movaps [rsp+0x10], xmm12
0000777bb65ce994  movaps [rsp+0x20], xmm1
0000777bb65ce999  lea rdi, [rsp]
0000777bb65ce99d  mov esi, 0x00
0000777bb65ce9a2  mov rax, 0x569DC437B530
0000777bb65ce9ac  call rax
0000777bb65ce9ae  movaps xmm13, [rsp]
0000777bb65ce9b3  add rsp, 0x30
0000777bb65ce9b7  vmovaps xmm0, [rsp]
0000777bb65ce9bc  vmovaps xmm1, [rsp+0x10]
0000777bb65ce9c2  vmovaps xmm2, [rsp+0x20]
0000777bb65ce9c8  vmovaps xmm3, [rsp+0x30]
0000777bb65ce9ce  vmovaps xmm4, [rsp+0x40]
0000777bb65ce9d4  vmovaps xmm5, [rsp+0x50]
0000777bb65ce9da  vmovaps xmm6, [rsp+0x60]
0000777bb65ce9e0  vmovaps xmm7, [rsp+0x70]
0000777bb65ce9e6  vmovaps xmm8, [rsp+0x80]
0000777bb65ce9ef  vmovaps xmm9, [rsp+0x90]
0000777bb65ce9f8  vmovaps xmm10, [rsp+0xA0]
0000777bb65cea01  vmovaps xmm11, [rsp+0xB0]
0000777bb65cea0a  vmovaps xmm12, [rsp+0xC0]
0000777bb65cea13  vmovaps xmm14, [rsp+0xD0]
0000777bb65cea1c  vmovaps xmm15, [rsp+0xE0]
0000777bb65cea25  add rsp, 0xF0
0000777bb65cea2c  pop r11
0000777bb65cea2e  pop r10
0000777bb65cea30  pop r9
0000777bb65cea32  pop r8
0000777bb65cea34  pop rsi
0000777bb65cea35  pop rdi
0000777bb65cea36  pop rdx
0000777bb65cea37  pop rcx
0000777bb65cea38  pop rax
0000777bb65cea39  add rsp, 0x08
0000777bb65cea3d  jmp 0x0000777BB65CE81B
0000777bb65cea42  call 0x0000777BB640C380
0000777bb65cea47  jmp 0x0000777BB65CE82E
0000777bb65cea4c  sub rsp, 0x08
0000777bb65cea50  push rax
0000777bb65cea51  push rcx
0000777bb65cea52  push rdx
0000777bb65cea53  push rdi
0000777bb65cea54  push rsi
0000777bb65cea55  push r8
0000777bb65cea57  push r9
0000777bb65cea59  push r10
0000777bb65cea5b  push r11
0000777bb65cea5d  sub rsp, 0xF0
0000777bb65cea64  vmovaps [rsp], xmm0
0000777bb65cea69  vmovaps [rsp+0x10], xmm2
0000777bb65cea6f  vmovaps [rsp+0x20], xmm3
0000777bb65cea75  vmovaps [rsp+0x30], xmm4
0000777bb65cea7b  vmovaps [rsp+0x40], xmm5
0000777bb65cea81  vmovaps [rsp+0x50], xmm6
0000777bb65cea87  vmovaps [rsp+0x60], xmm7
0000777bb65cea8d  vmovaps [rsp+0x70], xmm8
0000777bb65cea93  vmovaps [rsp+0x80], xmm9
0000777bb65cea9c  vmovaps [rsp+0x90], xmm10
0000777bb65ceaa5  vmovaps [rsp+0xA0], xmm11
0000777bb65ceaae  vmovaps [rsp+0xB0], xmm12
0000777bb65ceab7  vmovaps [rsp+0xC0], xmm13
0000777bb65ceac0  vmovaps [rsp+0xD0], xmm14
0000777bb65ceac9  vmovaps [rsp+0xE0], xmm15
0000777bb65cead2  sub rsp, 0x30
0000777bb65cead6  movaps [rsp], xmm1
0000777bb65ceada  movaps [rsp+0x10], xmm14
0000777bb65ceae0  movaps [rsp+0x20], xmm15
0000777bb65ceae6  lea rdi, [rsp]
0000777bb65ceaea  mov esi, 0x00
0000777bb65ceaef  mov rax, 0x569DC437B530
0000777bb65ceaf9  call rax
0000777bb65ceafb  movaps xmm1, [rsp]
0000777bb65ceaff  add rsp, 0x30
0000777bb65ceb03  vmovaps xmm0, [rsp]
0000777bb65ceb08  vmovaps xmm2, [rsp+0x10]
0000777bb65ceb0e  vmovaps xmm3, [rsp+0x20]
0000777bb65ceb14  vmovaps xmm4, [rsp+0x30]
0000777bb65ceb1a  vmovaps xmm5, [rsp+0x40]
0000777bb65ceb20  vmovaps xmm6, [rsp+0x50]
0000777bb65ceb26  vmovaps xmm7, [rsp+0x60]
0000777bb65ceb2c  vmovaps xmm8, [rsp+0x70]
0000777bb65ceb32  vmovaps xmm9, [rsp+0x80]
0000777bb65ceb3b  vmovaps xmm10, [rsp+0x90]
0000777bb65ceb44  vmovaps xmm11, [rsp+0xA0]
0000777bb65ceb4d  vmovaps xmm12, [rsp+0xB0]
0000777bb65ceb56  vmovaps xmm13, [rsp+0xC0]
0000777bb65ceb5f  vmovaps xmm14, [rsp+0xD0]
0000777bb65ceb68  vmovaps xmm15, [rsp+0xE0]
0000777bb65ceb71  add rsp, 0xF0
0000777bb65ceb78  pop r11
0000777bb65ceb7a  pop r10
0000777bb65ceb7c  pop r9
0000777bb65ceb7e  pop r8
0000777bb65ceb80  pop rsi
0000777bb65ceb81  pop rdi
0000777bb65ceb82  pop rdx
0000777bb65ceb83  pop rcx
0000777bb65ceb84  pop rax
0000777bb65ceb85  add rsp, 0x08
0000777bb65ceb89  jmp 0x0000777BB65CE848
0000777bb65ceb8e  call 0x0000777BB63FF540
0000777bb65ceb93  jmp 0x0000777BB65CE85B
0000777bb65ceb98  int3
0000777bb65ceb99  nop [rax], eax
0000777bb65ceba0  movaps xmm1, [r15+0x180]
0000777bb65ceba8  vpmovqd xmm15, xmm1
0000777bb65cebae  pxor xmm14, xmm14
0000777bb65cebb3  punpcklqdq xmm15, xmm14
0000777bb65cebb8  movaps [r15+0x210], xmm15
0000777bb65cebc0  movq xmm15, qword ptr [r15+0x120]
0000777bb65cebc9  movq xmm14, qword ptr [r15+0x130]
0000777bb65cebd2  psubd xmm15, xmm14
0000777bb65cebd7  movq xmm15, xmm15
0000777bb65cebdc  movaps xmm13, [r15+0x170]
0000777bb65cebe4  paddq xmm1, xmm13
0000777bb65cebe9  movaps [r15+0x180], xmm1
0000777bb65cebf1  movq xmm1, qword ptr [r15+0x150]
0000777bb65cebfa  paddd xmm14, xmm1
0000777bb65cebff  movq xmm14, xmm14
0000777bb65cec04  movq xmm14, xmm14
0000777bb65cec09  movaps [r15+0x130], xmm14
0000777bb65cec11  pmovzxdq xmm15, xmm15
0000777bb65cec17  psllq xmm15, 0x00
0000777bb65cec1d  movq xmm1, qword ptr [r15+0x210]
0000777bb65cec26  movq xmm14, qword ptr [r15+0x110]
0000777bb65cec2f  paddd xmm1, xmm14
0000777bb65cec34  movq xmm1, xmm1
0000777bb65cec38  vcvtuqq2pd xmm15, xmm15
0000777bb65cec3e  pmovzxdq xmm1, xmm1
0000777bb65cec43  psllq xmm1, 0x00
0000777bb65cec48  vcvtuqq2pd xmm1, xmm1
0000777bb65cec4e  movaps xmm14, [r15+0x140]
0000777bb65cec56  movaps xmm13, xmm15
0000777bb65cec5a  mulpd xmm13, xmm14
0000777bb65cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
0000777bb65cec65  ptest xmm12, xmm12
0000777bb65cec6b  jnz 0x0000777BB65CED4E
0000777bb65cec71  movaps [r15+0x220], xmm13
0000777bb65cec79  mov rax, [r15+0x48]
0000777bb65cec7d  mov r14, [r15+0x50]
0000777bb65cec81  lea r12, [r14+rax*1]
0000777bb65cec85  movups [r13+r12*1], xmm13
0000777bb65cec8b  movaps xmm15, [r15+0x160]
0000777bb65cec93  movaps xmm14, xmm1
0000777bb65cec97  mulpd xmm14, xmm15
0000777bb65cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
0000777bb65ceca2  ptest xmm13, xmm13
0000777bb65ceca8  jnz 0x0000777BB65CEE9C
0000777bb65cecae  movaps [r15+0x210], xmm14
0000777bb65cecb6  mov r14, [r15+0x40]
0000777bb65cecba  lea r12, [r14+rax*1]
0000777bb65cecbe  movups [r13+r12*1], xmm14
0000777bb65cecc4  lea r14, [rax+0x10]
0000777bb65cecc8  mov [r15+0x48], r14
0000777bb65ceccc  xor eax, eax
0000777bb65cecce  mov r12d, 0x200
0000777bb65cecd4  cmp r14, r12
0000777bb65cecd7  cmc
0000777bb65cecd8  lahf
0000777bb65cecd9  seto al
0000777bb65cecdc  mov [r15+0x108], eax
0000777bb65cece3  mov eax, [r15+0x108]
0000777bb65cecea  sahf
0000777bb65ceceb  jnz 0x0000777BB65CED1D
0000777bb65ceced  cmp dword ptr [r15+0x318], 0x00
0000777bb65cecf5  jz 0x0000777BB65CEFF0
0000777bb65cecfb  nop [rax+rax*1], ax
0000777bb65ced04  nop [rax+rax*1], eax
0000777bb65ced0c  mov eax, 0x4101EC
0000777bb65ced11  mov [r15+0x100], rax
0000777bb65ced18  jmp 0x0000777BB63FE110
0000777bb65ced1d  cmp dword ptr [r15+0x318], 0x00
0000777bb65ced25  jz 0x0000777BB65CEBA0
0000777bb65ced2b  nop [rax+rax*1], ax
0000777bb65ced34  nop [rax+rax*1], eax
0000777bb65ced3c  mov eax, 0x4101AC
0000777bb65ced41  mov [r15+0x100], rax
0000777bb65ced48  jmp 0x0000777BB63FE110
0000777bb65ced4d  int3
0000777bb65ced4e  sub rsp, 0x08
0000777bb65ced52  push rax
0000777bb65ced53  push rcx
0000777bb65ced54  push rdx
0000777bb65ced55  push rdi
0000777bb65ced56  push rsi
0000777bb65ced57  push r8
0000777bb65ced59  push r9
0000777bb65ced5b  push r10
0000777bb65ced5d  push r11
0000777bb65ced5f  sub rsp, 0xF0
0000777bb65ced66  vmovaps [rsp], xmm0
0000777bb65ced6b  vmovaps [rsp+0x10], xmm1
0000777bb65ced71  vmovaps [rsp+0x20], xmm2
0000777bb65ced77  vmovaps [rsp+0x30], xmm3
0000777bb65ced7d  vmovaps [rsp+0x40], xmm4
0000777bb65ced83  vmovaps [rsp+0x50], xmm5
0000777bb65ced89  vmovaps [rsp+0x60], xmm6
0000777bb65ced8f  vmovaps [rsp+0x70], xmm7
0000777bb65ced95  vmovaps [rsp+0x80], xmm8
0000777bb65ced9e  vmovaps [rsp+0x90], xmm9
0000777bb65ceda7  vmovaps [rsp+0xA0], xmm10
0000777bb65cedb0  vmovaps [rsp+0xB0], xmm11
0000777bb65cedb9  vmovaps [rsp+0xC0], xmm12
0000777bb65cedc2  vmovaps [rsp+0xD0], xmm14
0000777bb65cedcb  vmovaps [rsp+0xE0], xmm15
0000777bb65cedd4  sub rsp, 0x30
0000777bb65cedd8  movaps [rsp], xmm13
0000777bb65ceddd  movaps [rsp+0x10], xmm15
0000777bb65cede3  movaps [rsp+0x20], xmm14
0000777bb65cede9  lea rdi, [rsp]
0000777bb65ceded  mov esi, 0x00
0000777bb65cedf2  mov rax, 0x569DC437B530
0000777bb65cedfc  call rax
0000777bb65cedfe  movaps xmm13, [rsp]
0000777bb65cee03  add rsp, 0x30
0000777bb65cee07  vmovaps xmm0, [rsp]
0000777bb65cee0c  vmovaps xmm1, [rsp+0x10]
0000777bb65cee12  vmovaps xmm2, [rsp+0x20]
0000777bb65cee18  vmovaps xmm3, [rsp+0x30]
0000777bb65cee1e  vmovaps xmm4, [rsp+0x40]
0000777bb65cee24  vmovaps xmm5, [rsp+0x50]
0000777bb65cee2a  vmovaps xmm6, [rsp+0x60]
0000777bb65cee30  vmovaps xmm7, [rsp+0x70]
0000777bb65cee36  vmovaps xmm8, [rsp+0x80]
0000777bb65cee3f  vmovaps xmm9, [rsp+0x90]
0000777bb65cee48  vmovaps xmm10, [rsp+0xA0]
0000777bb65cee51  vmovaps xmm11, [rsp+0xB0]
0000777bb65cee5a  vmovaps xmm12, [rsp+0xC0]
0000777bb65cee63  vmovaps xmm14, [rsp+0xD0]
0000777bb65cee6c  vmovaps xmm15, [rsp+0xE0]
0000777bb65cee75  add rsp, 0xF0
0000777bb65cee7c  pop r11
0000777bb65cee7e  pop r10
0000777bb65cee80  pop r9
0000777bb65cee82  pop r8
0000777bb65cee84  pop rsi
0000777bb65cee85  pop rdi
0000777bb65cee86  pop rdx
0000777bb65cee87  pop rcx
0000777bb65cee88  pop rax
0000777bb65cee89  add rsp, 0x08
0000777bb65cee8d  jmp 0x0000777BB65CEC71
0000777bb65cee92  call 0x0000777BB64C2240
0000777bb65cee97  jmp 0x0000777BB65CEC8B
0000777bb65cee9c  sub rsp, 0x08
0000777bb65ceea0  push rax
0000777bb65ceea1  push rcx
0000777bb65ceea2  push rdx
0000777bb65ceea3  push rdi
0000777bb65ceea4  push rsi
0000777bb65ceea5  push r8
0000777bb65ceea7  push r9
0000777bb65ceea9  push r10
0000777bb65ceeab  push r11
0000777bb65ceead  sub rsp, 0xF0
0000777bb65ceeb4  vmovaps [rsp], xmm0
0000777bb65ceeb9  vmovaps [rsp+0x10], xmm1
0000777bb65ceebf  vmovaps [rsp+0x20], xmm2
0000777bb65ceec5  vmovaps [rsp+0x30], xmm3
0000777bb65ceecb  vmovaps [rsp+0x40], xmm4
0000777bb65ceed1  vmovaps [rsp+0x50], xmm5
0000777bb65ceed7  vmovaps [rsp+0x60], xmm6
0000777bb65ceedd  vmovaps [rsp+0x70], xmm7
0000777bb65ceee3  vmovaps [rsp+0x80], xmm8
0000777bb65ceeec  vmovaps [rsp+0x90], xmm9
0000777bb65ceef5  vmovaps [rsp+0xA0], xmm10
0000777bb65ceefe  vmovaps [rsp+0xB0], xmm11
0000777bb65cef07  vmovaps [rsp+0xC0], xmm12
0000777bb65cef10  vmovaps [rsp+0xD0], xmm13
0000777bb65cef19  vmovaps [rsp+0xE0], xmm15
0000777bb65cef22  sub rsp, 0x30
0000777bb65cef26  movaps [rsp], xmm14
0000777bb65cef2b  movaps [rsp+0x10], xmm1
0000777bb65cef30  movaps [rsp+0x20], xmm15
0000777bb65cef36  lea rdi, [rsp]
0000777bb65cef3a  mov esi, 0x00
0000777bb65cef3f  mov rax, 0x569DC437B530
0000777bb65cef49  call rax
0000777bb65cef4b  movaps xmm14, [rsp]
0000777bb65cef50  add rsp, 0x30
0000777bb65cef54  vmovaps xmm0, [rsp]
0000777bb65cef59  vmovaps xmm1, [rsp+0x10]
0000777bb65cef5f  vmovaps xmm2, [rsp+0x20]
0000777bb65cef65  vmovaps xmm3, [rsp+0x30]
0000777bb65cef6b  vmovaps xmm4, [rsp+0x40]
0000777bb65cef71  vmovaps xmm5, [rsp+0x50]
0000777bb65cef77  vmovaps xmm6, [rsp+0x60]
0000777bb65cef7d  vmovaps xmm7, [rsp+0x70]
0000777bb65cef83  vmovaps xmm8, [rsp+0x80]
0000777bb65cef8c  vmovaps xmm9, [rsp+0x90]
0000777bb65cef95  vmovaps xmm10, [rsp+0xA0]
0000777bb65cef9e  vmovaps xmm11, [rsp+0xB0]
0000777bb65cefa7  vmovaps xmm12, [rsp+0xC0]
0000777bb65cefb0  vmovaps xmm13, [rsp+0xD0]
0000777bb65cefb9  vmovaps xmm15, [rsp+0xE0]
0000777bb65cefc2  add rsp, 0xF0
0000777bb65cefc9  pop r11
0000777bb65cefcb  pop r10
0000777bb65cefcd  pop r9
0000777bb65cefcf  pop r8
0000777bb65cefd1  pop rsi
0000777bb65cefd2  pop rdi
0000777bb65cefd3  pop rdx
0000777bb65cefd4  pop rcx
0000777bb65cefd5  pop rax
0000777bb65cefd6  add rsp, 0x08
0000777bb65cefda  jmp 0x0000777BB65CECAE
0000777bb65cefdf  call 0x0000777BB64C34C0
0000777bb65cefe4  jmp 0x0000777BB65CECC4
0000777bb65cefe9  int3
0000777bb65cefea  nop [rax+rax*1], ax
0000777bb65ceff0  mov rax, [r15+0xF8]
0000777bb65ceff7  lea r14, [rax-0x150]
0000777bb65ceffe  mov [r15+0xF8], r14
0000777bb65cf005  mov rax, [r15+0x50]
0000777bb65cf009  lea r12, [rax+0x80]
0000777bb65cf010  movups xmm1, [r13+r12*1]
0000777bb65cf016  lea r12, [rax+0x90]
0000777bb65cf01d  movups xmm15, [r13+r12*1]
0000777bb65cf023  mov qword ptr [r15+0x48], 0x00
0000777bb65cf02b  lea r12, [rax+0x40]
0000777bb65cf02f  movups xmm14, [r13+r12*1]
0000777bb65cf035  lea r12, [rax+0x50]
0000777bb65cf039  movups xmm13, [r13+r12*1]
0000777bb65cf03f  lea r12, [r14+0x120]
0000777bb65cf046  movq xmm12, qword ptr [r15+0x1C0]
0000777bb65cf04f  movq xmm11, qword ptr [r15+0x1B0]
0000777bb65cf058  movq r11, xmm12
0000777bb65cf05d  movq r10, xmm11
0000777bb65cf062  mov [r13+r12*1], r11
0000777bb65cf067  lea r12, [r14+0x128]
0000777bb65cf06e  mov [r13+r12*1], r10
0000777bb65cf073  vxorps xmm12, xmm12, xmm12
0000777bb65cf078  vpbroadcastq xmm12, xmm12
0000777bb65cf07d  lea r12, [r14+0x100]
0000777bb65cf084  movq xmm11, qword ptr [r15+0x200]
0000777bb65cf08d  movq xmm10, qword ptr [r15+0x1F0]
0000777bb65cf096  movq r11, xmm11
0000777bb65cf09b  movq r10, xmm10
0000777bb65cf0a0  mov [r13+r12*1], r11
0000777bb65cf0a5  lea r12, [r14+0x108]
0000777bb65cf0ac  mov [r13+r12*1], r10
0000777bb65cf0b1  lea r12, [r14+0xE0]
0000777bb65cf0b8  movups [r13+r12*1], xmm15
0000777bb65cf0be  lea r12, [r14+0xF0]
0000777bb65cf0c5  movups [r13+r12*1], xmm1
0000777bb65cf0cb  lea r12, [rax+0xC0]
0000777bb65cf0d2  movups xmm1, [r13+r12*1]
0000777bb65cf0d8  lea r12, [rax+0xD0]
0000777bb65cf0df  movups xmm15, [r13+r12*1]
0000777bb65cf0e5  lea r12, [r14+0x110]
0000777bb65cf0ec  movq xmm11, qword ptr [r15+0x1E0]
0000777bb65cf0f5  movq xmm10, qword ptr [r15+0x1D0]
0000777bb65cf0fe  movq r11, xmm11
0000777bb65cf103  movq r10, xmm10
0000777bb65cf108  mov [r13+r12*1], r11
0000777bb65cf10d  lea r12, [r14+0x118]
0000777bb65cf114  mov [r13+r12*1], r10
0000777bb65cf119  movups xmm11, [r13+rax*1]
0000777bb65cf11f  lea r12, [rax+0x10]
0000777bb65cf123  movups xmm10, [r13+r12*1]
0000777bb65cf129  lea r12, [r14+0x130]
0000777bb65cf130  movq xmm9, qword ptr [r15+0x1A0]
0000777bb65cf139  movq xmm8, qword ptr [r15+0x190]
0000777bb65cf142  movq r11, xmm9
0000777bb65cf147  movq r10, xmm8
0000777bb65cf14c  mov [r13+r12*1], r11
0000777bb65cf151  lea r12, [r14+0x138]
0000777bb65cf158  mov [r13+r12*1], r10
0000777bb65cf15d  lea r12, [rax+0x140]
0000777bb65cf164  movups xmm9, [r13+r12*1]
0000777bb65cf16a  lea r12, [rax+0x150]
0000777bb65cf171  movups xmm8, [r13+r12*1]
0000777bb65cf177  lea r12, [r14+0xC0]
0000777bb65cf17e  movups [r13+r12*1], xmm15
0000777bb65cf184  lea r12, [r14+0xD0]
0000777bb65cf18b  movups [r13+r12*1], xmm1
0000777bb65cf191  lea r12, [rax+0x100]
0000777bb65cf198  movups xmm1, [r13+r12*1]
0000777bb65cf19e  lea r12, [rax+0x110]
0000777bb65cf1a5  movups xmm15, [r13+r12*1]
0000777bb65cf1ab  lea r12, [r14+0x140]
0000777bb65cf1b2  mov r11, [r15+0xE8]
0000777bb65cf1b9  mov [r13+r12*1], r11
0000777bb65cf1be  lea r12, [rax+0x180]
0000777bb65cf1c5  movups xmm7, [r13+r12*1]
0000777bb65cf1cb  lea r12, [rax+0x190]
0000777bb65cf1d2  movups xmm6, [r13+r12*1]
0000777bb65cf1d8  lea r12, [rax+0x1C0]
0000777bb65cf1df  movups xmm5, [r13+r12*1]
0000777bb65cf1e5  lea r12, [rax+0x1D0]
0000777bb65cf1ec  movups xmm4, [r13+r12*1]
0000777bb65cf1f2  lea r12, [r14+0x20]
0000777bb65cf1f6  movups [r13+r12*1], xmm1
0000777bb65cf1fc  lea r12, [r14+0x30]
0000777bb65cf200  movups [r13+r12*1], xmm13
0000777bb65cf206  lea r12, [rax+0x60]
0000777bb65cf20a  movups xmm1, [r13+r12*1]
0000777bb65cf210  lea r12, [rax+0x70]
0000777bb65cf214  movups xmm13, [r13+r12*1]
0000777bb65cf21a  lea r12, [rax+0x20]
0000777bb65cf21e  movups xmm3, [r13+r12*1]
0000777bb65cf224  lea r12, [rax+0x30]
0000777bb65cf228  movups xmm2, [r13+r12*1]
0000777bb65cf22e  movaps [r15+0x1F0], xmm2
0000777bb65cf236  lea r12, [r14+0x60]
0000777bb65cf23a  movups [r13+r12*1], xmm11
0000777bb65cf240  lea r12, [r14+0x70]
0000777bb65cf244  movups [r13+r12*1], xmm5
0000777bb65cf24a  lea r12, [rax+0xE0]
0000777bb65cf251  movups xmm11, [r13+r12*1]
0000777bb65cf257  lea r12, [rax+0xF0]
0000777bb65cf25e  movups xmm5, [r13+r12*1]
0000777bb65cf264  lea r12, [r14+0xA0]
0000777bb65cf26b  movups [r13+r12*1], xmm13
0000777bb65cf271  lea r12, [r14+0xB0]
0000777bb65cf278  movups [r13+r12*1], xmm1
0000777bb65cf27e  lea r12, [rax+0xA0]
0000777bb65cf285  movups xmm1, [r13+r12*1]
0000777bb65cf28b  lea r12, [rax+0xB0]
0000777bb65cf292  movups xmm13, [r13+r12*1]
0000777bb65cf298  lea r12, [rax+0x120]
0000777bb65cf29f  vmovaps [rsp+0x10], xmm1
0000777bb65cf2a5  movups xmm1, [r13+r12*1]
0000777bb65cf2ab  lea r12, [rax+0x130]
0000777bb65cf2b2  vmovaps [rsp+0x20], xmm1
0000777bb65cf2b8  movups xmm1, [r13+r12*1]
0000777bb65cf2be  lea r12, [rax+0x160]
0000777bb65cf2c5  vmovaps [rsp+0x30], xmm1
0000777bb65cf2cb  movups xmm1, [r13+r12*1]
0000777bb65cf2d1  lea r12, [rax+0x170]
0000777bb65cf2d8  vmovaps [rsp+0x40], xmm1
0000777bb65cf2de  movups xmm1, [r13+r12*1]
0000777bb65cf2e4  movaps [r15+0x2B0], xmm1
0000777bb65cf2ec  lea r12, [r14+0x80]
0000777bb65cf2f3  movups [r13+r12*1], xmm13
0000777bb65cf2f9  lea r12, [r14+0x90]
0000777bb65cf300  vmovaps xmm13, [rsp+0x10]
0000777bb65cf306  movups [r13+r12*1], xmm13
0000777bb65cf30c  lea r12, [rax+0x1A0]
0000777bb65cf313  movups xmm13, [r13+r12*1]
0000777bb65cf319  lea r12, [rax+0x1B0]
0000777bb65cf320  vmovaps [rsp+0x10], xmm1
0000777bb65cf326  movups xmm1, [r13+r12*1]
0000777bb65cf32c  movaps [r15+0x290], xmm13
0000777bb65cf334  movaps [r15+0x1E0], xmm1
0000777bb65cf33c  lea r12, [rax+0x1E0]
0000777bb65cf343  vmovaps [rsp+0x50], xmm1
0000777bb65cf349  movups xmm1, [r13+r12*1]
0000777bb65cf34f  lea r12, [rax+0x1F0]
0000777bb65cf356  vmovaps [rsp+0x60], xmm1
0000777bb65cf35c  movups xmm1, [r13+r12*1]
0000777bb65cf362  mov qword ptr [r15+0x50], 0x430920
0000777bb65cf36a  lea rax, [r14+0x40]
0000777bb65cf36e  vmovaps [rsp+0x70], xmm1
0000777bb65cf374  vmovaps xmm1, [rsp+0x40]
0000777bb65cf37a  movups [r13+rax*1], xmm1
0000777bb65cf380  lea rax, [r14+0x50]
0000777bb65cf384  movups [r13+rax*1], xmm10
0000777bb65cf38a  vmovaps xmm1, [rsp+0x70]
0000777bb65cf390  movups [r13+r14*1], xmm1
0000777bb65cf396  lea rax, [r14+0x10]
0000777bb65cf39a  vmovaps xmm1, [rsp+0x60]
0000777bb65cf3a0  movups [r13+rax*1], xmm1
0000777bb65cf3a6  mov rax, [r15+0x40]
0000777bb65cf3aa  vmovaps [rsp+0x40], xmm3
0000777bb65cf3b0  vmovaps xmm1, [rsp+0x40]
0000777bb65cf3b6  por xmm3, xmm1
0000777bb65cf3ba  vmovaps [rsp+0x40], xmm6
0000777bb65cf3c0  vmovaps xmm10, [rsp+0x40]
0000777bb65cf3c6  por xmm6, xmm10
0000777bb65cf3cb  lea r12, [rax+0x30]
0000777bb65cf3cf  mov r11, [r13+r12*1]
0000777bb65cf3d4  lea r12, [rax+0x38]
0000777bb65cf3d8  mov r10, [r13+r12*1]
0000777bb65cf3dd  movq xmm10, r11
0000777bb65cf3e2  vmovaps [rsp+0x40], xmm1
0000777bb65cf3e8  movq xmm1, r10
0000777bb65cf3ed  movq xmm10, xmm10
0000777bb65cf3f2  vmovaps [rsp+0x60], xmm10
0000777bb65cf3f8  movq xmm10, xmm10
0000777bb65cf3fd  movaps [r15+0x130], xmm10
0000777bb65cf405  movq xmm1, xmm1
0000777bb65cf409  vmovaps [rsp+0x70], xmm1
0000777bb65cf40f  movq xmm1, xmm1
0000777bb65cf413  movaps [r15+0x280], xmm1
0000777bb65cf41b  vmovaps [rsp+0x80], xmm9
0000777bb65cf424  vmovaps xmm1, [rsp+0x80]
0000777bb65cf42d  por xmm9, xmm1
0000777bb65cf432  lea r12, [rax+0x20]
0000777bb65cf436  mov r11, [r13+r12*1]
0000777bb65cf43b  lea r12, [rax+0x28]
0000777bb65cf43f  mov r10, [r13+r12*1]
0000777bb65cf444  movq xmm1, r11
0000777bb65cf449  movq xmm10, r10
0000777bb65cf44e  movq xmm1, xmm1
0000777bb65cf452  vmovaps [rsp+0x80], xmm1
0000777bb65cf45b  movq xmm1, xmm1
0000777bb65cf45f  movaps [r15+0x150], xmm1
0000777bb65cf467  movq xmm10, xmm10
0000777bb65cf46c  vmovaps [rsp+0x90], xmm10
0000777bb65cf475  movq xmm10, xmm10
0000777bb65cf47a  movaps [r15+0x140], xmm10
0000777bb65cf482  lea r12, [rax+0x10]
0000777bb65cf486  mov r11, [r13+r12*1]
0000777bb65cf48b  lea r12, [rax+0x18]
0000777bb65cf48f  mov r10, [r13+r12*1]
0000777bb65cf494  movq xmm1, r11
0000777bb65cf499  movq xmm10, r10
0000777bb65cf49e  movq xmm1, xmm1
0000777bb65cf4a2  vmovaps [rsp+0xA0], xmm1
0000777bb65cf4ab  movq xmm1, xmm1
0000777bb65cf4af  movaps [r15+0x170], xmm1
0000777bb65cf4b7  movq xmm10, xmm10
0000777bb65cf4bc  vmovaps [rsp+0xB0], xmm10
0000777bb65cf4c5  movq xmm10, xmm10
0000777bb65cf4ca  movaps [r15+0x160], xmm10
0000777bb65cf4d2  mov r12, [r13+rax*1]
0000777bb65cf4d7  vmovq xmm1, r12
0000777bb65cf4dc  vpbroadcastq xmm1, xmm1
0000777bb65cf4e1  lea r12, [rax+0x08]
0000777bb65cf4e5  mov rax, [r13+r12*1]
0000777bb65cf4ea  movq xmm10, rax
0000777bb65cf4ef  movaps [r15+0x230], xmm10
0000777bb65cf4f7  lea rax, [r14+0x50]
0000777bb65cf4fb  movups xmm10, [r13+rax*1]
0000777bb65cf501  lea rax, [r14+0x60]
0000777bb65cf505  vmovaps [rsp+0xC0], xmm1
0000777bb65cf50e  movups xmm1, [r13+rax*1]
0000777bb65cf514  lea rax, [r14+0x30]
0000777bb65cf518  vmovaps [rsp+0xD0], xmm1
0000777bb65cf521  movups xmm1, [r13+rax*1]
0000777bb65cf527  mov qword ptr [r15+0x60], 0x430920
0000777bb65cf52f  mov qword ptr [r15+0x58], 0x40
0000777bb65cf537  vmovaps [rsp+0xE0], xmm1
0000777bb65cf540  vmovaps [rsp+0xF0], xmm15
0000777bb65cf549  vmovaps xmm15, [rsp+0xC0]
0000777bb65cf552  vmovaps [rsp+0xC0], xmm14
0000777bb65cf55b  vmovaps xmm14, [rsp+0x40]
0000777bb65cf561  vmovaps [rsp+0x40], xmm13
0000777bb65cf567  movaps xmm1, xmm15
0000777bb65cf56b  mulpd xmm1, xmm14
0000777bb65cf570  vcmppd xmm13, xmm1, xmm1, 0x03
0000777bb65cf575  ptest xmm13, xmm13
0000777bb65cf57b  jnz 0x0000777BB65D0682
0000777bb65cf581  movq xmm14, qword ptr [r15+0x230]
0000777bb65cf58a  vmovaps [rsp+0x100], xmm14
0000777bb65cf593  vpermilpd xmm14, xmm14, 0x00
0000777bb65cf599  vmovaps [rsp+0x110], xmm1
0000777bb65cf5a2  vmovaps xmm1, [rsp+0xE0]
0000777bb65cf5ab  vmovaps [rsp+0xE0], xmm15
0000777bb65cf5b4  movaps xmm13, xmm1
0000777bb65cf5b8  mulpd xmm13, xmm14
0000777bb65cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
0000777bb65cf5c3  ptest xmm15, xmm15
0000777bb65cf5c9  jnz 0x0000777BB65D07C4
0000777bb65cf5cf  vxorps xmm1, xmm1, xmm1
0000777bb65cf5d3  vpbroadcastq xmm1, xmm1
0000777bb65cf5d8  vmovaps xmm14, [rsp+0xE0]
0000777bb65cf5e1  vmovaps [rsp+0xE0], xmm1
0000777bb65cf5ea  vmovaps xmm1, [rsp+0xD0]
0000777bb65cf5f3  vmovaps [rsp+0xD0], xmm13
0000777bb65cf5fc  movaps xmm15, xmm14
0000777bb65cf600  mulpd xmm15, xmm1
0000777bb65cf605  vcmppd xmm13, xmm15, xmm15, 0x03
0000777bb65cf60b  ptest xmm13, xmm13
0000777bb65cf611  jnz 0x0000777BB65D0907
0000777bb65cf617  movaps xmm1, xmm14
0000777bb65cf61b  mulpd xmm1, xmm10
0000777bb65cf620  vcmppd xmm13, xmm1, xmm1, 0x03
0000777bb65cf625  ptest xmm13, xmm13
0000777bb65cf62b  jnz 0x0000777BB65D0A4A
0000777bb65cf631  movaps xmm13, xmm14
0000777bb65cf635  mulpd xmm13, xmm2
0000777bb65cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
0000777bb65cf640  ptest xmm10, xmm10
0000777bb65cf646  jnz 0x0000777BB65D0B8C
0000777bb65cf64c  vmovaps [rsp+0x120], xmm7
0000777bb65cf655  vmovaps xmm14, [rsp+0x120]
0000777bb65cf65e  por xmm7, xmm14
0000777bb65cf663  vmovaps xmm14, [rsp+0xC0]
0000777bb65cf66c  vmovaps xmm10, [rsp+0xC0]
0000777bb65cf675  por xmm14, xmm10
0000777bb65cf67a  vmovaps xmm2, [rsp+0x100]
0000777bb65cf683  vpermilpd xmm2, xmm2, 0x00
0000777bb65cf689  vmovaps [rsp+0xC0], xmm1
0000777bb65cf692  vmovaps [rsp+0x120], xmm15
0000777bb65cf69b  movaps xmm1, xmm10
0000777bb65cf69f  mulpd xmm1, xmm2
0000777bb65cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
0000777bb65cf6a8  ptest xmm15, xmm15
0000777bb65cf6ae  jnz 0x0000777BB65D0CCF
0000777bb65cf6b4  xor eax, eax
0000777bb65cf6b6  mov r12d, 0x40
0000777bb65cf6bc  mov r11d, 0x200
0000777bb65cf6c2  cmp r12, r11
0000777bb65cf6c5  cmc
0000777bb65cf6c6  lahf
0000777bb65cf6c7  seto al
0000777bb65cf6ca  mov [r15+0x108], eax
0000777bb65cf6d1  vmovaps xmm10, [rsp+0x110]
0000777bb65cf6da  vmovaps xmm2, [rsp+0xE0]
0000777bb65cf6e3  vmovaps [rsp+0xE0], xmm1
0000777bb65cf6ec  movaps xmm15, xmm10
0000777bb65cf6f0  addpd xmm15, xmm2
0000777bb65cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
0000777bb65cf6fb  ptest xmm1, xmm1
0000777bb65cf700  jnz 0x0000777BB65D0E10
0000777bb65cf706  vmovaps xmm10, [rsp+0x120]
0000777bb65cf70f  vmovaps [rsp+0x110], xmm15
0000777bb65cf718  movaps xmm1, xmm10
0000777bb65cf71c  addpd xmm1, xmm12
0000777bb65cf721  vcmppd xmm15, xmm1, xmm1, 0x03
0000777bb65cf726  ptest xmm15, xmm15
0000777bb65cf72c  jnz 0x0000777BB65D0F53
0000777bb65cf732  vmovaps xmm10, [rsp+0xC0]
0000777bb65cf73b  vmovaps [rsp+0xC0], xmm1
0000777bb65cf744  movaps xmm15, xmm10
0000777bb65cf748  addpd xmm15, xmm12
0000777bb65cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
0000777bb65cf753  ptest xmm1, xmm1
0000777bb65cf758  jnz 0x0000777BB65D1095
0000777bb65cf75e  vmovaps xmm1, [rsp+0x30]
0000777bb65cf764  vmovaps xmm12, [rsp+0x30]
0000777bb65cf76a  por xmm1, xmm12
0000777bb65cf76f  vmovaps xmm12, [rsp+0x20]
0000777bb65cf775  vmovaps xmm10, [rsp+0x20]
0000777bb65cf77b  por xmm12, xmm10
0000777bb65cf780  vmovaps [rsp+0x20], xmm5
0000777bb65cf786  vmovaps xmm10, [rsp+0x20]
0000777bb65cf78c  por xmm5, xmm10
0000777bb65cf791  vmovaps [rsp+0x20], xmm11
0000777bb65cf797  vmovaps xmm10, [rsp+0x20]
0000777bb65cf79d  por xmm11, xmm10
0000777bb65cf7a2  vmovaps [rsp+0x20], xmm4
0000777bb65cf7a8  vmovaps xmm10, [rsp+0x20]
0000777bb65cf7ae  por xmm4, xmm10
0000777bb65cf7b3  vmovaps [rsp+0x20], xmm8
0000777bb65cf7b9  vmovaps xmm10, [rsp+0x20]
0000777bb65cf7bf  por xmm8, xmm10
0000777bb65cf7c4  vmovaps xmm10, [rsp+0xF0]
0000777bb65cf7cd  vmovaps [rsp+0x20], xmm1
0000777bb65cf7d3  vmovaps xmm1, [rsp+0xF0]
0000777bb65cf7dc  por xmm10, xmm1
0000777bb65cf7e1  lea rax, [r14+0xA0]
0000777bb65cf7e8  movups xmm1, [r13+rax*1]
0000777bb65cf7ee  lea rax, [r14+0xB0]
0000777bb65cf7f5  vmovaps [rsp+0x30], xmm1
0000777bb65cf7fb  movups xmm1, [r13+rax*1]
0000777bb65cf801  vmovaps [rsp+0xF0], xmm1
0000777bb65cf80a  vmovaps [rsp+0x120], xmm15
0000777bb65cf813  movaps xmm1, xmm13
0000777bb65cf817  addpd xmm1, xmm2
0000777bb65cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
0000777bb65cf820  ptest xmm15, xmm15
0000777bb65cf826  jnz 0x0000777BB65D11ED
0000777bb65cf82c  lea rax, [r14+0xF0]
0000777bb65cf833  movups xmm15, [r13+rax*1]
0000777bb65cf839  vmovaps xmm2, [rsp+0xC0]
0000777bb65cf842  vmovaps [rsp+0xC0], xmm1
0000777bb65cf84b  vmovaps xmm1, [rsp+0xE0]
0000777bb65cf854  vmovaps [rsp+0xE0], xmm15
0000777bb65cf85d  movaps xmm13, xmm2
0000777bb65cf861  addpd xmm13, xmm1
0000777bb65cf866  vcmppd xmm15, xmm13, xmm13, 0x03
0000777bb65cf86c  ptest xmm15, xmm15
0000777bb65cf872  jnz 0x0000777BB65D1338
0000777bb65cf878  vmovaps xmm15, [rsp+0x120]
0000777bb65cf881  vmovaps xmm2, [rsp+0xD0]
0000777bb65cf88a  vmovaps [rsp+0xD0], xmm14
0000777bb65cf893  movaps xmm1, xmm15
0000777bb65cf897  addpd xmm1, xmm2
0000777bb65cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
0000777bb65cf8a0  ptest xmm14, xmm14
0000777bb65cf8a6  jnz 0x0000777BB65D147A
0000777bb65cf8ac  vmovaps xmm15, [rsp+0x100]
0000777bb65cf8b5  vpermilpd xmm15, xmm15, 0x00
0000777bb65cf8bb  vmovaps xmm2, [rsp+0xF0]
0000777bb65cf8c4  vmovaps [rsp+0xF0], xmm1
0000777bb65cf8cd  movaps xmm14, xmm2
0000777bb65cf8d1  mulpd xmm14, xmm15
0000777bb65cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
0000777bb65cf8dc  ptest xmm1, xmm1
0000777bb65cf8e1  jnz 0x0000777BB65D15BB
0000777bb65cf8e7  vmovaps xmm1, [rsp+0xA0]
0000777bb65cf8f0  vpermilpd xmm1, xmm1, 0x00
0000777bb65cf8f6  vmovaps xmm2, [rsp+0xE0]
0000777bb65cf8ff  vmovaps [rsp+0xE0], xmm14
0000777bb65cf908  movaps xmm15, xmm2
0000777bb65cf90c  mulpd xmm15, xmm1
0000777bb65cf911  vcmppd xmm14, xmm15, xmm15, 0x03
0000777bb65cf917  ptest xmm14, xmm14
0000777bb65cf91d  jnz 0x0000777BB65D16FE
0000777bb65cf923  lea rax, [r14+0xE0]
0000777bb65cf92a  movups xmm1, [r13+rax*1]
0000777bb65cf930  vmovaps xmm14, [rsp+0x100]
0000777bb65cf939  vpermilpd xmm14, xmm14, 0x00
0000777bb65cf93f  vmovaps [rsp+0x100], xmm1
0000777bb65cf948  vmovaps xmm1, [rsp+0x30]
0000777bb65cf94e  vmovaps [rsp+0x30], xmm15
0000777bb65cf954  movaps xmm2, xmm1
0000777bb65cf957  mulpd xmm2, xmm14
0000777bb65cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
0000777bb65cf961  ptest xmm15, xmm15
0000777bb65cf967  jnz 0x0000777BB65D184A
0000777bb65cf96d  vmovaps [rsp+0x120], xmm10
0000777bb65cf976  vmovaps xmm1, [rsp+0x120]
0000777bb65cf97f  por xmm10, xmm1
0000777bb65cf984  movaps [r15+0x300], xmm10
0000777bb65cf98c  vmovaps [rsp+0x120], xmm8
0000777bb65cf995  vmovaps xmm1, [rsp+0x120]
0000777bb65cf99e  por xmm8, xmm1
0000777bb65cf9a3  movaps [r15+0x190], xmm8
0000777bb65cf9ab  vmovaps xmm1, [rsp+0xA0]
0000777bb65cf9b4  vpermilpd xmm1, xmm1, 0x00
0000777bb65cf9ba  vmovaps xmm14, [rsp+0x100]
0000777bb65cf9c3  vmovaps [rsp+0x100], xmm13
0000777bb65cf9cc  movaps xmm15, xmm14
0000777bb65cf9d0  mulpd xmm15, xmm1
0000777bb65cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
0000777bb65cf9db  ptest xmm13, xmm13
0000777bb65cf9e1  jnz 0x0000777BB65D198B
0000777bb65cf9e7  lea rax, [r14+0x90]
0000777bb65cf9ee  movups xmm1, [r13+rax*1]
0000777bb65cf9f4  vmovaps [rsp+0x120], xmm4
0000777bb65cf9fd  vmovaps xmm14, [rsp+0x120]
0000777bb65cfa06  por xmm4, xmm14
0000777bb65cfa0b  movaps [r15+0x1C0], xmm4
0000777bb65cfa13  vmovaps [rsp+0x120], xmm11
0000777bb65cfa1c  vmovaps xmm14, [rsp+0x120]
0000777bb65cfa25  por xmm11, xmm14
0000777bb65cfa2a  movaps [r15+0x200], xmm11
0000777bb65cfa32  vmovaps [rsp+0x120], xmm5
0000777bb65cfa3b  vmovaps xmm14, [rsp+0x120]
0000777bb65cfa44  por xmm5, xmm14
0000777bb65cfa49  movaps [r15+0x2D0], xmm5
0000777bb65cfa51  vmovaps [rsp+0x120], xmm12
0000777bb65cfa5a  vmovaps xmm14, [rsp+0x120]
0000777bb65cfa63  por xmm12, xmm14
0000777bb65cfa68  movaps [r15+0x2E0], xmm12
0000777bb65cfa70  vmovaps xmm13, [rsp+0x110]
0000777bb65cfa79  vmovaps [rsp+0x110], xmm1
0000777bb65cfa82  vmovaps xmm1, [rsp+0xE0]
0000777bb65cfa8b  vmovaps [rsp+0xE0], xmm15
0000777bb65cfa94  movaps xmm14, xmm13
0000777bb65cfa98  addpd xmm14, xmm1
0000777bb65cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
0000777bb65cfaa3  ptest xmm15, xmm15
0000777bb65cfaa9  jnz 0x0000777BB65D1AD8
0000777bb65cfaaf  vmovaps xmm1, [rsp+0xA0]
0000777bb65cfab8  vpermilpd xmm1, xmm1, 0x00
0000777bb65cfabe  vmovaps xmm13, [rsp+0x110]
0000777bb65cfac7  vmovaps [rsp+0x110], xmm14
0000777bb65cfad0  movaps xmm15, xmm13
0000777bb65cfad4  mulpd xmm15, xmm1
0000777bb65cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
0000777bb65cfadf  ptest xmm14, xmm14
0000777bb65cfae5  jnz 0x0000777BB65D1C1B
0000777bb65cfaeb  lea rax, [r14+0x80]
0000777bb65cfaf2  movups xmm1, [r13+rax*1]
0000777bb65cfaf8  vmovaps xmm13, [rsp+0xC0]
0000777bb65cfb01  vmovaps [rsp+0xC0], xmm1
0000777bb65cfb0a  movaps xmm14, xmm13
0000777bb65cfb0e  addpd xmm14, xmm2
0000777bb65cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
0000777bb65cfb19  ptest xmm1, xmm1
0000777bb65cfb1e  jnz 0x0000777BB65D1D68
0000777bb65cfb24  vmovaps xmm13, [rsp+0x100]
0000777bb65cfb2d  vmovaps xmm2, [rsp+0x30]
0000777bb65cfb33  vmovaps [rsp+0x30], xmm15
0000777bb65cfb39  movaps xmm1, xmm13
0000777bb65cfb3d  addpd xmm1, xmm2
0000777bb65cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
0000777bb65cfb46  ptest xmm15, xmm15
0000777bb65cfb4c  jnz 0x0000777BB65D1EAB
0000777bb65cfb52  vmovaps xmm15, [rsp+0x20]
0000777bb65cfb58  vmovaps xmm13, [rsp+0x20]
0000777bb65cfb5e  por xmm15, xmm13
0000777bb65cfb63  movaps [r15+0x2F0], xmm15
0000777bb65cfb6b  vmovaps xmm13, [rsp+0xA0]
0000777bb65cfb74  vpermilpd xmm13, xmm13, 0x00
0000777bb65cfb7a  vmovaps [rsp+0x20], xmm1
0000777bb65cfb80  vmovaps xmm1, [rsp+0xC0]
0000777bb65cfb89  vmovaps [rsp+0xA0], xmm15
0000777bb65cfb92  movaps xmm2, xmm1
0000777bb65cfb95  mulpd xmm2, xmm13
0000777bb65cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
0000777bb65cfb9f  ptest xmm15, xmm15
0000777bb65cfba5  jnz 0x0000777BB65D1FEC
0000777bb65cfbab  lea rax, [r14+0xD0]
0000777bb65cfbb2  movups xmm1, [r13+rax*1]
0000777bb65cfbb8  vmovaps xmm13, [rsp+0xF0]
0000777bb65cfbc1  vmovaps [rsp+0xC0], xmm1
0000777bb65cfbca  vmovaps xmm1, [rsp+0xE0]
0000777bb65cfbd3  vmovaps [rsp+0xE0], xmm14
0000777bb65cfbdc  movaps xmm15, xmm13
0000777bb65cfbe0  addpd xmm15, xmm1
0000777bb65cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
0000777bb65cfbeb  ptest xmm14, xmm14
0000777bb65cfbf1  jnz 0x0000777BB65D2137
0000777bb65cfbf7  vmovaps xmm1, [rsp+0xB0]
0000777bb65cfc00  vpermilpd xmm1, xmm1, 0x00
0000777bb65cfc06  movaps xmm14, xmm11
0000777bb65cfc0a  mulpd xmm14, xmm1
0000777bb65cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
0000777bb65cfc15  ptest xmm13, xmm13
0000777bb65cfc1b  jnz 0x0000777BB65D227A
0000777bb65cfc21  movaps [r15+0x260], xmm14
0000777bb65cfc29  vxorps xmm1, xmm1, xmm1
0000777bb65cfc2d  vpbroadcastq xmm1, xmm1
0000777bb65cfc32  movaps [r15+0x1B0], xmm1
0000777bb65cfc3a  vmovaps xmm1, [rsp+0xB0]
0000777bb65cfc43  vpermilpd xmm1, xmm1, 0x00
0000777bb65cfc49  vmovaps xmm11, [rsp+0xC0]
0000777bb65cfc52  vmovaps [rsp+0xC0], xmm15
0000777bb65cfc5b  movaps xmm13, xmm11
0000777bb65cfc5f  mulpd xmm13, xmm1
0000777bb65cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
0000777bb65cfc6a  ptest xmm15, xmm15
0000777bb65cfc70  jnz 0x0000777BB65D23BD
0000777bb65cfc76  lea rax, [r14+0xC0]
0000777bb65cfc7d  movups xmm1, [r13+rax*1]
0000777bb65cfc83  vmovaps xmm11, [rsp+0x110]
0000777bb65cfc8c  vmovaps [rsp+0xF0], xmm1
0000777bb65cfc95  vmovaps xmm1, [rsp+0x30]
0000777bb65cfc9b  vmovaps [rsp+0x30], xmm14
0000777bb65cfca1  movaps xmm15, xmm11
0000777bb65cfca5  addpd xmm15, xmm1
0000777bb65cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
0000777bb65cfcb0  ptest xmm14, xmm14
0000777bb65cfcb6  jnz 0x0000777BB65D250A
0000777bb65cfcbc  vmovaps [rsp+0x100], xmm9
0000777bb65cfcc5  vmovaps xmm1, [rsp+0x100]
0000777bb65cfcce  por xmm9, xmm1
0000777bb65cfcd3  movaps [r15+0x270], xmm9
0000777bb65cfcdb  vmovaps [rsp+0x100], xmm6
0000777bb65cfce4  vmovaps xmm1, [rsp+0x100]
0000777bb65cfced  por xmm6, xmm1
0000777bb65cfcf1  movaps [r15+0x1A0], xmm6
0000777bb65cfcf9  vmovaps xmm14, [rsp+0xB0]
0000777bb65cfd02  vpermilpd xmm14, xmm14, 0x00
0000777bb65cfd08  vmovaps xmm6, [rsp+0xF0]
0000777bb65cfd11  vmovaps [rsp+0xF0], xmm1
0000777bb65cfd1a  movaps xmm11, xmm6
0000777bb65cfd1e  mulpd xmm11, xmm14
0000777bb65cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
0000777bb65cfd29  ptest xmm1, xmm1
0000777bb65cfd2e  jnz 0x0000777BB65D264D
0000777bb65cfd34  lea rax, [r14+0x20]
0000777bb65cfd38  movups xmm1, [r13+rax*1]
0000777bb65cfd3e  movaps [r15+0x110], xmm1
0000777bb65cfd46  vmovaps xmm6, [rsp+0xE0]
0000777bb65cfd4f  vmovaps [rsp+0xE0], xmm1
0000777bb65cfd58  movaps xmm14, xmm6
0000777bb65cfd5c  addpd xmm14, xmm2
0000777bb65cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
0000777bb65cfd67  ptest xmm1, xmm1
0000777bb65cfd6c  jnz 0x0000777BB65D279A
0000777bb65cfd72  vmovaps xmm1, [rsp+0xB0]
0000777bb65cfd7b  vpermilpd xmm1, xmm1, 0x00
0000777bb65cfd81  movaps xmm6, xmm5
0000777bb65cfd84  mulpd xmm6, xmm1
0000777bb65cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
0000777bb65cfd8d  ptest xmm2, xmm2
0000777bb65cfd92  jnz 0x0000777BB65D28DC
0000777bb65cfd98  vmovaps xmm5, [rsp+0x20]
0000777bb65cfd9e  movaps xmm1, xmm5
0000777bb65cfda1  addpd xmm1, xmm13
0000777bb65cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
0000777bb65cfdab  ptest xmm2, xmm2
0000777bb65cfdb0  jnz 0x0000777BB65D2A1C
0000777bb65cfdb6  vmovaps xmm13, [rsp+0x80]
0000777bb65cfdbf  vpermilpd xmm13, xmm13, 0x00
0000777bb65cfdc5  vmovaps xmm2, [rsp+0xE0]
0000777bb65cfdce  vmovaps [rsp+0x20], xmm1
0000777bb65cfdd4  movaps xmm5, xmm2
0000777bb65cfdd7  mulpd xmm5, xmm13
0000777bb65cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
0000777bb65cfde1  ptest xmm1, xmm1
0000777bb65cfde6  jnz 0x0000777BB65D2B5D
0000777bb65cfdec  vmovaps xmm1, [rsp+0x80]
0000777bb65cfdf5  vpermilpd xmm1, xmm1, 0x00
0000777bb65cfdfb  movaps xmm13, xmm10
0000777bb65cfdff  mulpd xmm13, xmm1
0000777bb65cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
0000777bb65cfe0a  ptest xmm2, xmm2
0000777bb65cfe0f  jnz 0x0000777BB65D2C9E
0000777bb65cfe15  vmovaps xmm10, [rsp+0x30]
0000777bb65cfe1b  movaps xmm1, xmm15
0000777bb65cfe1f  addpd xmm1, xmm10
0000777bb65cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
0000777bb65cfe29  ptest xmm2, xmm2
0000777bb65cfe2e  jnz 0x0000777BB65D2DE1
0000777bb65cfe34  vmovaps xmm10, [rsp+0xC0]
0000777bb65cfe3d  movaps xmm15, xmm10
0000777bb65cfe41  addpd xmm15, xmm11
0000777bb65cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
0000777bb65cfe4c  ptest xmm2, xmm2
0000777bb65cfe51  jnz 0x0000777BB65D2F23
0000777bb65cfe57  vmovaps xmm11, [rsp+0x80]
0000777bb65cfe60  vpermilpd xmm11, xmm11, 0x00
0000777bb65cfe66  movaps xmm10, xmm12
0000777bb65cfe6a  mulpd xmm10, xmm11
0000777bb65cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
0000777bb65cfe75  ptest xmm2, xmm2
0000777bb65cfe7a  jnz 0x0000777BB65D3067
0000777bb65cfe80  vmovaps xmm12, [rsp+0x80]
0000777bb65cfe89  vpermilpd xmm12, xmm12, 0x00
0000777bb65cfe8f  vmovaps xmm2, [rsp+0xA0]
0000777bb65cfe98  vmovaps [rsp+0x30], xmm1
0000777bb65cfe9e  movaps xmm11, xmm2
0000777bb65cfea2  mulpd xmm11, xmm12
0000777bb65cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
0000777bb65cfead  ptest xmm1, xmm1
0000777bb65cfeb2  jnz 0x0000777BB65D31AB
0000777bb65cfeb8  movaps xmm1, xmm14
0000777bb65cfebc  addpd xmm1, xmm6
0000777bb65cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
0000777bb65cfec5  ptest xmm12, xmm12
0000777bb65cfecb  jnz 0x0000777BB65D32EE
0000777bb65cfed1  vmovaps xmm12, [rsp+0x20]
0000777bb65cfed7  movaps xmm14, xmm12
0000777bb65cfedb  addpd xmm14, xmm5
0000777bb65cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
0000777bb65cfee6  ptest xmm6, xmm6
0000777bb65cfeeb  jnz 0x0000777BB65D342F
0000777bb65cfef1  vmovaps xmm12, [rsp+0x90]
0000777bb65cfefa  vpermilpd xmm12, xmm12, 0x00
0000777bb65cff00  movaps xmm6, xmm9
0000777bb65cff04  mulpd xmm6, xmm12
0000777bb65cff09  vcmppd xmm5, xmm6, xmm6, 0x03
0000777bb65cff0e  ptest xmm5, xmm5
0000777bb65cff13  jnz 0x0000777BB65D3572
0000777bb65cff19  movaps xmm12, xmm15
0000777bb65cff1d  addpd xmm12, xmm13
0000777bb65cff22  vcmppd xmm9, xmm12, xmm12, 0x03
0000777bb65cff28  ptest xmm9, xmm9
0000777bb65cff2e  jnz 0x0000777BB65D36B4
0000777bb65cff34  vmovaps xmm13, [rsp+0x30]
0000777bb65cff3a  movaps xmm15, xmm13
0000777bb65cff3e  addpd xmm15, xmm10
0000777bb65cff43  vcmppd xmm9, xmm15, xmm15, 0x03
0000777bb65cff49  ptest xmm9, xmm9
0000777bb65cff4f  jnz 0x0000777BB65D37F8
0000777bb65cff55  vmovaps xmm13, [rsp+0xD0]
0000777bb65cff5e  vmovaps xmm10, [rsp+0xD0]
0000777bb65cff67  por xmm13, xmm10
0000777bb65cff6c  movaps [r15+0x250], xmm13
0000777bb65cff74  vmovaps [rsp+0x20], xmm7
0000777bb65cff7a  vmovaps xmm13, [rsp+0x20]
0000777bb65cff80  por xmm7, xmm13
0000777bb65cff85  movaps [r15+0x2A0], xmm7
0000777bb65cff8d  vmovaps [rsp+0x20], xmm3
0000777bb65cff93  vmovaps xmm13, [rsp+0x20]
0000777bb65cff99  por xmm3, xmm13
0000777bb65cff9e  movaps [r15+0x1D0], xmm3
0000777bb65cffa6  lea rax, [r14+0x40]
0000777bb65cffaa  movups xmm13, [r13+rax*1]
0000777bb65cffb0  movaps [r15+0x2C0], xmm13
0000777bb65cffb8  vmovaps xmm10, [rsp+0x90]
0000777bb65cffc1  vpermilpd xmm10, xmm10, 0x00
0000777bb65cffc7  movaps xmm9, xmm8
0000777bb65cffcb  mulpd xmm9, xmm10
0000777bb65cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
0000777bb65cffd6  ptest xmm5, xmm5
0000777bb65cffdb  jnz 0x0000777BB65D3946
0000777bb65cffe1  movaps xmm10, xmm1
0000777bb65cffe5  addpd xmm10, xmm11
0000777bb65cffea  vcmppd xmm8, xmm10, xmm10, 0x03
0000777bb65cfff0  ptest xmm8, xmm8
0000777bb65cfff6  jnz 0x0000777BB65D3A8A
0000777bb65cfffc  movaps xmm1, xmm14
0000777bb65d0000  addpd xmm1, xmm6
0000777bb65d0004  vcmppd xmm11, xmm1, xmm1, 0x03
0000777bb65d0009  ptest xmm11, xmm11
0000777bb65d000f  jnz 0x0000777BB65D3BCD
0000777bb65d0015  vmovaps xmm14, [rsp+0x90]
0000777bb65d001e  vpermilpd xmm14, xmm14, 0x00
0000777bb65d0024  movaps xmm11, xmm13
0000777bb65d0028  mulpd xmm11, xmm14
0000777bb65d002d  vcmppd xmm8, xmm11, xmm11, 0x03
0000777bb65d0033  ptest xmm8, xmm8
0000777bb65d0039  jnz 0x0000777BB65D3D0E
0000777bb65d003f  vmovaps xmm14, [rsp+0x90]
0000777bb65d0048  vpermilpd xmm14, xmm14, 0x00
0000777bb65d004e  vmovaps xmm8, [rsp+0x10]
0000777bb65d0054  movaps xmm13, xmm8
0000777bb65d0058  mulpd xmm13, xmm14
0000777bb65d005d  vcmppd xmm6, xmm13, xmm13, 0x03
0000777bb65d0063  ptest xmm6, xmm6
0000777bb65d0068  jnz 0x0000777BB65D3E52
0000777bb65d006e  vmovaps xmm14, [rsp+0x60]
0000777bb65d0074  vpermilpd xmm14, xmm14, 0x00
0000777bb65d007a  movaps xmm8, xmm7
0000777bb65d007e  mulpd xmm8, xmm14
0000777bb65d0083  vcmppd xmm6, xmm8, xmm8, 0x03
0000777bb65d0089  ptest xmm6, xmm6
0000777bb65d008e  jnz 0x0000777BB65D3F96
0000777bb65d0094  movaps xmm14, xmm12
0000777bb65d0098  addpd xmm14, xmm9
0000777bb65d009d  vcmppd xmm7, xmm14, xmm14, 0x03
0000777bb65d00a3  ptest xmm7, xmm7
0000777bb65d00a8  jnz 0x0000777BB65D40D9
0000777bb65d00ae  vmovaps xmm12, [rsp+0x60]
0000777bb65d00b4  vpermilpd xmm12, xmm12, 0x00
0000777bb65d00ba  vmovaps xmm7, [rsp+0xF0]
0000777bb65d00c3  movaps xmm9, xmm7
0000777bb65d00c7  mulpd xmm9, xmm12
0000777bb65d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
0000777bb65d00d2  ptest xmm6, xmm6
0000777bb65d00d7  jnz 0x0000777BB65D421D
0000777bb65d00dd  movaps xmm12, xmm15
0000777bb65d00e1  addpd xmm12, xmm11
0000777bb65d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
0000777bb65d00ec  ptest xmm7, xmm7
0000777bb65d00f1  jnz 0x0000777BB65D4360
0000777bb65d00f7  vmovaps xmm15, [rsp+0x60]
0000777bb65d00fd  vpermilpd xmm15, xmm15, 0x00
0000777bb65d0103  vmovaps xmm7, [rsp+0x40]
0000777bb65d0109  movaps xmm11, xmm7
0000777bb65d010d  mulpd xmm11, xmm15
0000777bb65d0112  vcmppd xmm6, xmm11, xmm11, 0x03
0000777bb65d0118  ptest xmm6, xmm6
0000777bb65d011d  jnz 0x0000777BB65D44A4
0000777bb65d0123  movaps xmm15, xmm10
0000777bb65d0127  addpd xmm15, xmm13
0000777bb65d012c  vcmppd xmm7, xmm15, xmm15, 0x03
0000777bb65d0132  ptest xmm7, xmm7
0000777bb65d0137  jnz 0x0000777BB65D45E7
0000777bb65d013d  vmovaps xmm13, [rsp+0x60]
0000777bb65d0143  vpermilpd xmm13, xmm13, 0x00
0000777bb65d0149  vmovaps xmm7, [rsp+0x50]
0000777bb65d014f  movaps xmm10, xmm7
0000777bb65d0153  mulpd xmm10, xmm13
0000777bb65d0158  vcmppd xmm6, xmm10, xmm10, 0x03
0000777bb65d015e  ptest xmm6, xmm6
0000777bb65d0163  jnz 0x0000777BB65D472B
0000777bb65d0169  movaps xmm13, xmm1
0000777bb65d016d  addpd xmm13, xmm8
0000777bb65d0172  vcmppd xmm7, xmm13, xmm13, 0x03
0000777bb65d0178  ptest xmm7, xmm7
0000777bb65d017d  jnz 0x0000777BB65D486E
0000777bb65d0183  lea rax, [r14+0x70]
0000777bb65d0187  movups xmm1, [r13+rax*1]
0000777bb65d018d  movaps [r15+0x240], xmm1
0000777bb65d0195  movaps xmm8, xmm14
0000777bb65d0199  addpd xmm8, xmm9
0000777bb65d019e  vcmppd xmm7, xmm8, xmm8, 0x03
0000777bb65d01a4  ptest xmm7, xmm7
0000777bb65d01a9  jnz 0x0000777BB65D49BB
0000777bb65d01af  movaps [r15+0x170], xmm8
0000777bb65d01b7  vmovaps xmm14, [rsp+0x70]
0000777bb65d01bd  vpermilpd xmm14, xmm14, 0x00
0000777bb65d01c3  movaps xmm9, xmm1
0000777bb65d01c7  mulpd xmm9, xmm14
0000777bb65d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
0000777bb65d01d2  ptest xmm7, xmm7
0000777bb65d01d7  jnz 0x0000777BB65D4AFF
0000777bb65d01dd  vmovaps xmm1, [rsp+0x70]
0000777bb65d01e3  vpermilpd xmm1, xmm1, 0x00
0000777bb65d01e9  movaps xmm14, xmm4
0000777bb65d01ed  mulpd xmm14, xmm1
0000777bb65d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
0000777bb65d01f8  ptest xmm7, xmm7
0000777bb65d01fd  jnz 0x0000777BB65D4C42
0000777bb65d0203  movaps [r15+0x180], xmm14
0000777bb65d020b  movaps xmm1, xmm12
0000777bb65d020f  addpd xmm1, xmm11
0000777bb65d0214  vcmppd xmm7, xmm1, xmm1, 0x03
0000777bb65d0219  ptest xmm7, xmm7
0000777bb65d021e  jnz 0x0000777BB65D4D84
0000777bb65d0224  movaps [r15+0x210], xmm1
0000777bb65d022c  movups xmm12, [r13+r14*1]
0000777bb65d0232  lea rax, [r14+0x10]
0000777bb65d0236  movups xmm11, [r13+rax*1]
0000777bb65d023c  movaps [r15+0x230], xmm11
0000777bb65d0244  movaps xmm7, xmm15
0000777bb65d0248  addpd xmm7, xmm10
0000777bb65d024d  vcmppd xmm6, xmm7, xmm7, 0x03
0000777bb65d0252  ptest xmm6, xmm6
0000777bb65d0257  jnz 0x0000777BB65D4EDA
0000777bb65d025d  movaps [r15+0x130], xmm7
0000777bb65d0265  vmovaps xmm15, [rsp+0x70]
0000777bb65d026b  vpermilpd xmm15, xmm15, 0x00
0000777bb65d0271  movaps xmm10, xmm11
0000777bb65d0275  mulpd xmm10, xmm15
0000777bb65d027a  vcmppd xmm6, xmm10, xmm10, 0x03
0000777bb65d0280  ptest xmm6, xmm6
0000777bb65d0285  jnz 0x0000777BB65D501C
0000777bb65d028b  movaps [r15+0x220], xmm10
0000777bb65d0293  vmovaps xmm15, [rsp+0x70]
0000777bb65d0299  vpermilpd xmm15, xmm15, 0x00
0000777bb65d029f  movaps xmm11, xmm12
0000777bb65d02a3  mulpd xmm11, xmm15
0000777bb65d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
0000777bb65d02ae  ptest xmm6, xmm6
0000777bb65d02b3  jnz 0x0000777BB65D5160
0000777bb65d02b9  movaps xmm15, xmm13
0000777bb65d02bd  addpd xmm15, xmm9
0000777bb65d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
0000777bb65d02c8  ptest xmm12, xmm12
0000777bb65d02ce  jnz 0x0000777BB65D52A4
0000777bb65d02d4  movaps [r15+0x140], xmm15
0000777bb65d02dc  movaps xmm13, xmm8
0000777bb65d02e0  addpd xmm13, xmm14
0000777bb65d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
0000777bb65d02eb  ptest xmm12, xmm12
0000777bb65d02f1  jnz 0x0000777BB65D53E8
0000777bb65d02f7  movaps [r15+0x150], xmm13
0000777bb65d02ff  movaps xmm14, xmm1
0000777bb65d0303  addpd xmm14, xmm10
0000777bb65d0308  vcmppd xmm12, xmm14, xmm14, 0x03
0000777bb65d030e  ptest xmm12, xmm12
0000777bb65d0314  jnz 0x0000777BB65D552C
0000777bb65d031a  movaps [r15+0x160], xmm14
0000777bb65d0322  movaps xmm1, xmm7
0000777bb65d0325  addpd xmm1, xmm11
0000777bb65d032a  vcmppd xmm12, xmm1, xmm1, 0x03
0000777bb65d032f  ptest xmm12, xmm12
0000777bb65d0335  jnz 0x0000777BB65D566F
0000777bb65d033b  movaps [r15+0x120], xmm1
0000777bb65d0343  mov eax, 0x430920
0000777bb65d0348  movups [r13+rax*1], xmm15
0000777bb65d034e  mov eax, 0x430930
0000777bb65d0353  movups [r13+rax*1], xmm13
0000777bb65d0359  mov eax, 0x430940
0000777bb65d035e  movups [r13+rax*1], xmm14
0000777bb65d0364  mov eax, 0x430950
0000777bb65d0369  movups [r13+rax*1], xmm1
0000777bb65d036f  mov eax, [r15+0x108]
0000777bb65d0376  sahf
0000777bb65d0377  jnz 0x0000777BB65D03A9
0000777bb65d0379  cmp dword ptr [r15+0x318], 0x00
0000777bb65d0381  jz 0x0000777BB65DB900
0000777bb65d0387  nop [rax+rax*1], ax
0000777bb65d0390  nop [rax+rax*1], eax
0000777bb65d0398  mov eax, 0x410444
0000777bb65d039d  mov [r15+0x100], rax
0000777bb65d03a4  jmp 0x0000777BB63FE110
0000777bb65d03a9  cmp dword ptr [r15+0x318], 0x00
0000777bb65d03b1  jz 0x0000777BB65D57E0
0000777bb65d03b7  nop [rax+rax*1], ax
0000777bb65d03c0  nop [rax+rax*1], eax
0000777bb65d03c8  mov eax, 0x410278
0000777bb65d03cd  mov [r15+0x100], rax
0000777bb65d03d4  jmp 0x0000777BB63FE110
0000777bb65d03d9  int3
0000777bb65d03da  call 0x0000777BB64B52F0
0000777bb65d03df  jmp 0x0000777BB65CF016
0000777bb65d03e4  call 0x0000777BB64C4620
0000777bb65d03e9  jmp 0x0000777BB65CF023
0000777bb65d03ee  call 0x0000777BB64C33A0
0000777bb65d03f3  jmp 0x0000777BB65CF035
0000777bb65d03f8  call 0x0000777BB64C2120
0000777bb65d03fd  jmp 0x0000777BB65CF03F
0000777bb65d0402  call 0x0000777BB64C0860
0000777bb65d0407  jmp 0x0000777BB65CF067
0000777bb65d040c  call 0x0000777BB64BF5F0
0000777bb65d0411  jmp 0x0000777BB65CF073
0000777bb65d0416  call 0x0000777BB64C0860
0000777bb65d041b  jmp 0x0000777BB65CF0A5
0000777bb65d0420  call 0x0000777BB64BF5F0
0000777bb65d0425  jmp 0x0000777BB65CF0B1
0000777bb65d042a  call 0x0000777BB64C4740
0000777bb65d042f  jmp 0x0000777BB65CF0BE
0000777bb65d0434  call 0x0000777BB64B5400
0000777bb65d0439  jmp 0x0000777BB65CF0CB
0000777bb65d043e  call 0x0000777BB64B52F0
0000777bb65d0443  jmp 0x0000777BB65CF0D8
0000777bb65d0448  call 0x0000777BB64C4620
0000777bb65d044d  jmp 0x0000777BB65CF0E5
0000777bb65d0452  call 0x0000777BB64C0860
0000777bb65d0457  jmp 0x0000777BB65CF10D
0000777bb65d045c  call 0x0000777BB64BF5F0
0000777bb65d0461  jmp 0x0000777BB65CF119
0000777bb65d0466  call 0x0000777BB6409D70
0000777bb65d046b  jmp 0x0000777BB65CF11F
0000777bb65d0470  call 0x0000777BB64BE9C0
0000777bb65d0475  jmp 0x0000777BB65CF129
0000777bb65d047a  call 0x0000777BB64C0860
0000777bb65d047f  jmp 0x0000777BB65CF151
0000777bb65d0484  call 0x0000777BB64BF5F0
0000777bb65d0489  jmp 0x0000777BB65CF15D
0000777bb65d048e  call 0x0000777BB64BD750
0000777bb65d0493  jmp 0x0000777BB65CF16A
0000777bb65d0498  call 0x0000777BB64BC4E0
0000777bb65d049d  jmp 0x0000777BB65CF177
0000777bb65d04a2  call 0x0000777BB64C4740
0000777bb65d04a7  jmp 0x0000777BB65CF184
0000777bb65d04ac  call 0x0000777BB64B5400
0000777bb65d04b1  jmp 0x0000777BB65CF191
0000777bb65d04b6  call 0x0000777BB64B52F0
0000777bb65d04bb  jmp 0x0000777BB65CF19E
0000777bb65d04c0  call 0x0000777BB64C4620
0000777bb65d04c5  jmp 0x0000777BB65CF1AB
0000777bb65d04ca  call 0x0000777BB64C0860
0000777bb65d04cf  jmp 0x0000777BB65CF1BE
0000777bb65d04d4  call 0x0000777BB64BB270
0000777bb65d04d9  jmp 0x0000777BB65CF1CB
0000777bb65d04de  call 0x0000777BB64BA000
0000777bb65d04e3  jmp 0x0000777BB65CF1D8
0000777bb65d04e8  call 0x0000777BB64B8D90
0000777bb65d04ed  jmp 0x0000777BB65CF1E5
0000777bb65d04f2  call 0x0000777BB64B8A20
0000777bb65d04f7  jmp 0x0000777BB65CF1F2
0000777bb65d04fc  call 0x0000777BB64B5400
0000777bb65d0501  jmp 0x0000777BB65CF1FC
0000777bb65d0506  call 0x0000777BB64C2240
0000777bb65d050b  jmp 0x0000777BB65CF206
0000777bb65d0510  call 0x0000777BB64B52F0
0000777bb65d0515  jmp 0x0000777BB65CF210
0000777bb65d051a  call 0x0000777BB64C2120
0000777bb65d051f  jmp 0x0000777BB65CF21A
0000777bb65d0524  call 0x0000777BB64B77B0
0000777bb65d0529  jmp 0x0000777BB65CF224
0000777bb65d052e  call 0x0000777BB64B6550
0000777bb65d0533  jmp 0x0000777BB65CF22E
0000777bb65d0538  call 0x0000777BB64BFD50
0000777bb65d053d  jmp 0x0000777BB65CF240
0000777bb65d0542  call 0x0000777BB64B8EA0
0000777bb65d0547  jmp 0x0000777BB65CF24A
0000777bb65d054c  call 0x0000777BB64BFC30
0000777bb65d0551  jmp 0x0000777BB65CF257
0000777bb65d0556  call 0x0000777BB64B8D90
0000777bb65d055b  jmp 0x0000777BB65CF264
0000777bb65d0560  call 0x0000777BB64C2240
0000777bb65d0565  jmp 0x0000777BB65CF271
0000777bb65d056a  call 0x0000777BB64B5400
0000777bb65d056f  jmp 0x0000777BB65CF27E
0000777bb65d0574  call 0x0000777BB64B52F0
0000777bb65d0579  jmp 0x0000777BB65CF28B
0000777bb65d057e  call 0x0000777BB64C2120
0000777bb65d0583  jmp 0x0000777BB65CF298
0000777bb65d0588  call 0x0000777BB64B52F0
0000777bb65d058d  jmp 0x0000777BB65CF2AB
0000777bb65d0592  call 0x0000777BB64B52F0
0000777bb65d0597  jmp 0x0000777BB65CF2BE
0000777bb65d059c  call 0x0000777BB64B52F0
0000777bb65d05a1  jmp 0x0000777BB65CF2D1
0000777bb65d05a6  call 0x0000777BB64B52F0
0000777bb65d05ab  jmp 0x0000777BB65CF2E4
0000777bb65d05b0  call 0x0000777BB64C2240
0000777bb65d05b5  jmp 0x0000777BB65CF2F9
0000777bb65d05ba  call 0x0000777BB64C2240
0000777bb65d05bf  jmp 0x0000777BB65CF30C
0000777bb65d05c4  call 0x0000777BB64C2120
0000777bb65d05c9  jmp 0x0000777BB65CF319
0000777bb65d05ce  call 0x0000777BB64B52F0
0000777bb65d05d3  jmp 0x0000777BB65CF32C
0000777bb65d05d8  call 0x0000777BB64B52F0
0000777bb65d05dd  jmp 0x0000777BB65CF34F
0000777bb65d05e2  call 0x0000777BB64B52F0
0000777bb65d05e7  jmp 0x0000777BB65CF362
0000777bb65d05ec  call 0x0000777BB63FF540
0000777bb65d05f1  jmp 0x0000777BB65CF380
0000777bb65d05f6  call 0x0000777BB6408C20
0000777bb65d05fb  jmp 0x0000777BB65CF38A
0000777bb65d0600  call 0x0000777BB64D6600
0000777bb65d0605  jmp 0x0000777BB65CF396
0000777bb65d060a  call 0x0000777BB63FF540
0000777bb65d060f  jmp 0x0000777BB65CF3A6
0000777bb65d0614  call 0x0000777BB64C0370
0000777bb65d0619  jmp 0x0000777BB65CF3D4
0000777bb65d061e  call 0x0000777BB64BF100
0000777bb65d0623  jmp 0x0000777BB65CF3DD
0000777bb65d0628  call 0x0000777BB64C0370
0000777bb65d062d  jmp 0x0000777BB65CF43B
0000777bb65d0632  call 0x0000777BB64BF100
0000777bb65d0637  jmp 0x0000777BB65CF444
0000777bb65d063c  call 0x0000777BB64C0370
0000777bb65d0641  jmp 0x0000777BB65CF48B
0000777bb65d0646  call 0x0000777BB64BF100
0000777bb65d064b  jmp 0x0000777BB65CF494
0000777bb65d0650  call 0x0000777BB640B720
0000777bb65d0655  jmp 0x0000777BB65CF4D7
0000777bb65d065a  call 0x0000777BB64B47C0
0000777bb65d065f  jmp 0x0000777BB65CF4EA
0000777bb65d0664  call 0x0000777BB6408B00
0000777bb65d0669  jmp 0x0000777BB65CF501
0000777bb65d066e  call 0x0000777BB63FF430
0000777bb65d0673  jmp 0x0000777BB65CF514
0000777bb65d0678  call 0x0000777BB63FF430
0000777bb65d067d  jmp 0x0000777BB65CF527
0000777bb65d0682  sub rsp, 0x08
0000777bb65d0686  push rax
0000777bb65d0687  push rcx
0000777bb65d0688  push rdx
0000777bb65d0689  push rdi
0000777bb65d068a  push rsi
0000777bb65d068b  push r8
0000777bb65d068d  push r9
0000777bb65d068f  push r10
0000777bb65d0691  push r11
0000777bb65d0693  sub rsp, 0xF0
0000777bb65d069a  vmovaps [rsp], xmm0
0000777bb65d069f  vmovaps [rsp+0x10], xmm2
0000777bb65d06a5  vmovaps [rsp+0x20], xmm3
0000777bb65d06ab  vmovaps [rsp+0x30], xmm4
0000777bb65d06b1  vmovaps [rsp+0x40], xmm5
0000777bb65d06b7  vmovaps [rsp+0x50], xmm6
0000777bb65d06bd  vmovaps [rsp+0x60], xmm7
0000777bb65d06c3  vmovaps [rsp+0x70], xmm8
0000777bb65d06c9  vmovaps [rsp+0x80], xmm9
0000777bb65d06d2  vmovaps [rsp+0x90], xmm10
0000777bb65d06db  vmovaps [rsp+0xA0], xmm11
0000777bb65d06e4  vmovaps [rsp+0xB0], xmm12
0000777bb65d06ed  vmovaps [rsp+0xC0], xmm13
0000777bb65d06f6  vmovaps [rsp+0xD0], xmm14
0000777bb65d06ff  vmovaps [rsp+0xE0], xmm15
0000777bb65d0708  sub rsp, 0x30
0000777bb65d070c  movaps [rsp], xmm1
0000777bb65d0710  movaps [rsp+0x10], xmm15
0000777bb65d0716  movaps [rsp+0x20], xmm14
0000777bb65d071c  lea rdi, [rsp]
0000777bb65d0720  mov esi, 0x00
0000777bb65d0725  mov rax, 0x569DC437B530
0000777bb65d072f  call rax
0000777bb65d0731  movaps xmm1, [rsp]
0000777bb65d0735  add rsp, 0x30
0000777bb65d0739  vmovaps xmm0, [rsp]
0000777bb65d073e  vmovaps xmm2, [rsp+0x10]
0000777bb65d0744  vmovaps xmm3, [rsp+0x20]
0000777bb65d074a  vmovaps xmm4, [rsp+0x30]
0000777bb65d0750  vmovaps xmm5, [rsp+0x40]
0000777bb65d0756  vmovaps xmm6, [rsp+0x50]
0000777bb65d075c  vmovaps xmm7, [rsp+0x60]
0000777bb65d0762  vmovaps xmm8, [rsp+0x70]
0000777bb65d0768  vmovaps xmm9, [rsp+0x80]
0000777bb65d0771  vmovaps xmm10, [rsp+0x90]
0000777bb65d077a  vmovaps xmm11, [rsp+0xA0]
0000777bb65d0783  vmovaps xmm12, [rsp+0xB0]
0000777bb65d078c  vmovaps xmm13, [rsp+0xC0]
0000777bb65d0795  vmovaps xmm14, [rsp+0xD0]
0000777bb65d079e  vmovaps xmm15, [rsp+0xE0]
0000777bb65d07a7  add rsp, 0xF0
0000777bb65d07ae  pop r11
0000777bb65d07b0  pop r10
0000777bb65d07b2  pop r9
0000777bb65d07b4  pop r8
0000777bb65d07b6  pop rsi
0000777bb65d07b7  pop rdi
0000777bb65d07b8  pop rdx
0000777bb65d07b9  pop rcx
0000777bb65d07ba  pop rax
0000777bb65d07bb  add rsp, 0x08
0000777bb65d07bf  jmp 0x0000777BB65CF581
0000777bb65d07c4  sub rsp, 0x08
0000777bb65d07c8  push rax
0000777bb65d07c9  push rcx
0000777bb65d07ca  push rdx
0000777bb65d07cb  push rdi
0000777bb65d07cc  push rsi
0000777bb65d07cd  push r8
0000777bb65d07cf  push r9
0000777bb65d07d1  push r10
0000777bb65d07d3  push r11
0000777bb65d07d5  sub rsp, 0xF0
0000777bb65d07dc  vmovaps [rsp], xmm0
0000777bb65d07e1  vmovaps [rsp+0x10], xmm1
0000777bb65d07e7  vmovaps [rsp+0x20], xmm2
0000777bb65d07ed  vmovaps [rsp+0x30], xmm3
0000777bb65d07f3  vmovaps [rsp+0x40], xmm4
0000777bb65d07f9  vmovaps [rsp+0x50], xmm5
0000777bb65d07ff  vmovaps [rsp+0x60], xmm6
0000777bb65d0805  vmovaps [rsp+0x70], xmm7
0000777bb65d080b  vmovaps [rsp+0x80], xmm8
0000777bb65d0814  vmovaps [rsp+0x90], xmm9
0000777bb65d081d  vmovaps [rsp+0xA0], xmm10
0000777bb65d0826  vmovaps [rsp+0xB0], xmm11
0000777bb65d082f  vmovaps [rsp+0xC0], xmm12
0000777bb65d0838  vmovaps [rsp+0xD0], xmm14
0000777bb65d0841  vmovaps [rsp+0xE0], xmm15
0000777bb65d084a  sub rsp, 0x30
0000777bb65d084e  movaps [rsp], xmm13
0000777bb65d0853  movaps [rsp+0x10], xmm1
0000777bb65d0858  movaps [rsp+0x20], xmm14
0000777bb65d085e  lea rdi, [rsp]
0000777bb65d0862  mov esi, 0x00
0000777bb65d0867  mov rax, 0x569DC437B530
0000777bb65d0871  call rax
0000777bb65d0873  movaps xmm13, [rsp]
0000777bb65d0878  add rsp, 0x30
0000777bb65d087c  vmovaps xmm0, [rsp]
0000777bb65d0881  vmovaps xmm1, [rsp+0x10]
0000777bb65d0887  vmovaps xmm2, [rsp+0x20]
0000777bb65d088d  vmovaps xmm3, [rsp+0x30]
0000777bb65d0893  vmovaps xmm4, [rsp+0x40]
0000777bb65d0899  vmovaps xmm5, [rsp+0x50]
0000777bb65d089f  vmovaps xmm6, [rsp+0x60]
0000777bb65d08a5  vmovaps xmm7, [rsp+0x70]
0000777bb65d08ab  vmovaps xmm8, [rsp+0x80]
0000777bb65d08b4  vmovaps xmm9, [rsp+0x90]
0000777bb65d08bd  vmovaps xmm10, [rsp+0xA0]
0000777bb65d08c6  vmovaps xmm11, [rsp+0xB0]
0000777bb65d08cf  vmovaps xmm12, [rsp+0xC0]
0000777bb65d08d8  vmovaps xmm14, [rsp+0xD0]
0000777bb65d08e1  vmovaps xmm15, [rsp+0xE0]
0000777bb65d08ea  add rsp, 0xF0
0000777bb65d08f1  pop r11
0000777bb65d08f3  pop r10
0000777bb65d08f5  pop r9
0000777bb65d08f7  pop r8
0000777bb65d08f9  pop rsi
0000777bb65d08fa  pop rdi
0000777bb65d08fb  pop rdx
0000777bb65d08fc  pop rcx
0000777bb65d08fd  pop rax
0000777bb65d08fe  add rsp, 0x08
0000777bb65d0902  jmp 0x0000777BB65CF5CF
0000777bb65d0907  sub rsp, 0x08
0000777bb65d090b  push rax
0000777bb65d090c  push rcx
0000777bb65d090d  push rdx
0000777bb65d090e  push rdi
0000777bb65d090f  push rsi
0000777bb65d0910  push r8
0000777bb65d0912  push r9
0000777bb65d0914  push r10
0000777bb65d0916  push r11
0000777bb65d0918  sub rsp, 0xF0
0000777bb65d091f  vmovaps [rsp], xmm0
0000777bb65d0924  vmovaps [rsp+0x10], xmm1
0000777bb65d092a  vmovaps [rsp+0x20], xmm2
0000777bb65d0930  vmovaps [rsp+0x30], xmm3
0000777bb65d0936  vmovaps [rsp+0x40], xmm4
0000777bb65d093c  vmovaps [rsp+0x50], xmm5
0000777bb65d0942  vmovaps [rsp+0x60], xmm6
0000777bb65d0948  vmovaps [rsp+0x70], xmm7
0000777bb65d094e  vmovaps [rsp+0x80], xmm8
0000777bb65d0957  vmovaps [rsp+0x90], xmm9
0000777bb65d0960  vmovaps [rsp+0xA0], xmm10
0000777bb65d0969  vmovaps [rsp+0xB0], xmm11
0000777bb65d0972  vmovaps [rsp+0xC0], xmm12
0000777bb65d097b  vmovaps [rsp+0xD0], xmm13
0000777bb65d0984  vmovaps [rsp+0xE0], xmm14
0000777bb65d098d  sub rsp, 0x30
0000777bb65d0991  movaps [rsp], xmm15
0000777bb65d0996  movaps [rsp+0x10], xmm14
0000777bb65d099c  movaps [rsp+0x20], xmm1
0000777bb65d09a1  lea rdi, [rsp]
0000777bb65d09a5  mov esi, 0x00
0000777bb65d09aa  mov rax, 0x569DC437B530
0000777bb65d09b4  call rax
0000777bb65d09b6  movaps xmm15, [rsp]
0000777bb65d09bb  add rsp, 0x30
0000777bb65d09bf  vmovaps xmm0, [rsp]
0000777bb65d09c4  vmovaps xmm1, [rsp+0x10]
0000777bb65d09ca  vmovaps xmm2, [rsp+0x20]
0000777bb65d09d0  vmovaps xmm3, [rsp+0x30]
0000777bb65d09d6  vmovaps xmm4, [rsp+0x40]
0000777bb65d09dc  vmovaps xmm5, [rsp+0x50]
0000777bb65d09e2  vmovaps xmm6, [rsp+0x60]
0000777bb65d09e8  vmovaps xmm7, [rsp+0x70]
0000777bb65d09ee  vmovaps xmm8, [rsp+0x80]
0000777bb65d09f7  vmovaps xmm9, [rsp+0x90]
0000777bb65d0a00  vmovaps xmm10, [rsp+0xA0]
0000777bb65d0a09  vmovaps xmm11, [rsp+0xB0]
0000777bb65d0a12  vmovaps xmm12, [rsp+0xC0]
0000777bb65d0a1b  vmovaps xmm13, [rsp+0xD0]
0000777bb65d0a24  vmovaps xmm14, [rsp+0xE0]
0000777bb65d0a2d  add rsp, 0xF0
0000777bb65d0a34  pop r11
0000777bb65d0a36  pop r10
0000777bb65d0a38  pop r9
0000777bb65d0a3a  pop r8
0000777bb65d0a3c  pop rsi
0000777bb65d0a3d  pop rdi
0000777bb65d0a3e  pop rdx
0000777bb65d0a3f  pop rcx
0000777bb65d0a40  pop rax
0000777bb65d0a41  add rsp, 0x08
0000777bb65d0a45  jmp 0x0000777BB65CF617
0000777bb65d0a4a  sub rsp, 0x08
0000777bb65d0a4e  push rax
0000777bb65d0a4f  push rcx
0000777bb65d0a50  push rdx
0000777bb65d0a51  push rdi
0000777bb65d0a52  push rsi
0000777bb65d0a53  push r8
0000777bb65d0a55  push r9
0000777bb65d0a57  push r10
0000777bb65d0a59  push r11
0000777bb65d0a5b  sub rsp, 0xF0
0000777bb65d0a62  vmovaps [rsp], xmm0
0000777bb65d0a67  vmovaps [rsp+0x10], xmm2
0000777bb65d0a6d  vmovaps [rsp+0x20], xmm3
0000777bb65d0a73  vmovaps [rsp+0x30], xmm4
0000777bb65d0a79  vmovaps [rsp+0x40], xmm5
0000777bb65d0a7f  vmovaps [rsp+0x50], xmm6
0000777bb65d0a85  vmovaps [rsp+0x60], xmm7
0000777bb65d0a8b  vmovaps [rsp+0x70], xmm8
0000777bb65d0a91  vmovaps [rsp+0x80], xmm9
0000777bb65d0a9a  vmovaps [rsp+0x90], xmm10
0000777bb65d0aa3  vmovaps [rsp+0xA0], xmm11
0000777bb65d0aac  vmovaps [rsp+0xB0], xmm12
0000777bb65d0ab5  vmovaps [rsp+0xC0], xmm13
0000777bb65d0abe  vmovaps [rsp+0xD0], xmm14
0000777bb65d0ac7  vmovaps [rsp+0xE0], xmm15
0000777bb65d0ad0  sub rsp, 0x30
0000777bb65d0ad4  movaps [rsp], xmm1
0000777bb65d0ad8  movaps [rsp+0x10], xmm14
0000777bb65d0ade  movaps [rsp+0x20], xmm10
0000777bb65d0ae4  lea rdi, [rsp]
0000777bb65d0ae8  mov esi, 0x00
0000777bb65d0aed  mov rax, 0x569DC437B530
0000777bb65d0af7  call rax
0000777bb65d0af9  movaps xmm1, [rsp]
0000777bb65d0afd  add rsp, 0x30
0000777bb65d0b01  vmovaps xmm0, [rsp]
0000777bb65d0b06  vmovaps xmm2, [rsp+0x10]
0000777bb65d0b0c  vmovaps xmm3, [rsp+0x20]
0000777bb65d0b12  vmovaps xmm4, [rsp+0x30]
0000777bb65d0b18  vmovaps xmm5, [rsp+0x40]
0000777bb65d0b1e  vmovaps xmm6, [rsp+0x50]
0000777bb65d0b24  vmovaps xmm7, [rsp+0x60]
0000777bb65d0b2a  vmovaps xmm8, [rsp+0x70]
0000777bb65d0b30  vmovaps xmm9, [rsp+0x80]
0000777bb65d0b39  vmovaps xmm10, [rsp+0x90]
0000777bb65d0b42  vmovaps xmm11, [rsp+0xA0]
0000777bb65d0b4b  vmovaps xmm12, [rsp+0xB0]
0000777bb65d0b54  vmovaps xmm13, [rsp+0xC0]
0000777bb65d0b5d  vmovaps xmm14, [rsp+0xD0]
0000777bb65d0b66  vmovaps xmm15, [rsp+0xE0]
0000777bb65d0b6f  add rsp, 0xF0
0000777bb65d0b76  pop r11
0000777bb65d0b78  pop r10
0000777bb65d0b7a  pop r9
0000777bb65d0b7c  pop r8
0000777bb65d0b7e  pop rsi
0000777bb65d0b7f  pop rdi
0000777bb65d0b80  pop rdx
0000777bb65d0b81  pop rcx
0000777bb65d0b82  pop rax
0000777bb65d0b83  add rsp, 0x08
0000777bb65d0b87  jmp 0x0000777BB65CF631
0000777bb65d0b8c  sub rsp, 0x08
0000777bb65d0b90  push rax
0000777bb65d0b91  push rcx
0000777bb65d0b92  push rdx
0000777bb65d0b93  push rdi
0000777bb65d0b94  push rsi
0000777bb65d0b95  push r8
0000777bb65d0b97  push r9
0000777bb65d0b99  push r10
0000777bb65d0b9b  push r11
0000777bb65d0b9d  sub rsp, 0xF0
0000777bb65d0ba4  vmovaps [rsp], xmm0
0000777bb65d0ba9  vmovaps [rsp+0x10], xmm1
0000777bb65d0baf  vmovaps [rsp+0x20], xmm2
0000777bb65d0bb5  vmovaps [rsp+0x30], xmm3
0000777bb65d0bbb  vmovaps [rsp+0x40], xmm4
0000777bb65d0bc1  vmovaps [rsp+0x50], xmm5
0000777bb65d0bc7  vmovaps [rsp+0x60], xmm6
0000777bb65d0bcd  vmovaps [rsp+0x70], xmm7
0000777bb65d0bd3  vmovaps [rsp+0x80], xmm8
0000777bb65d0bdc  vmovaps [rsp+0x90], xmm9
0000777bb65d0be5  vmovaps [rsp+0xA0], xmm10
0000777bb65d0bee  vmovaps [rsp+0xB0], xmm11
0000777bb65d0bf7  vmovaps [rsp+0xC0], xmm12
0000777bb65d0c00  vmovaps [rsp+0xD0], xmm14
0000777bb65d0c09  vmovaps [rsp+0xE0], xmm15
0000777bb65d0c12  sub rsp, 0x30
0000777bb65d0c16  movaps [rsp], xmm13
0000777bb65d0c1b  movaps [rsp+0x10], xmm14
0000777bb65d0c21  movaps [rsp+0x20], xmm2
0000777bb65d0c26  lea rdi, [rsp]
0000777bb65d0c2a  mov esi, 0x00
0000777bb65d0c2f  mov rax, 0x569DC437B530
0000777bb65d0c39  call rax
0000777bb65d0c3b  movaps xmm13, [rsp]
0000777bb65d0c40  add rsp, 0x30
0000777bb65d0c44  vmovaps xmm0, [rsp]
0000777bb65d0c49  vmovaps xmm1, [rsp+0x10]
0000777bb65d0c4f  vmovaps xmm2, [rsp+0x20]
0000777bb65d0c55  vmovaps xmm3, [rsp+0x30]
0000777bb65d0c5b  vmovaps xmm4, [rsp+0x40]
0000777bb65d0c61  vmovaps xmm5, [rsp+0x50]
0000777bb65d0c67  vmovaps xmm6, [rsp+0x60]
0000777bb65d0c6d  vmovaps xmm7, [rsp+0x70]
0000777bb65d0c73  vmovaps xmm8, [rsp+0x80]
0000777bb65d0c7c  vmovaps xmm9, [rsp+0x90]
0000777bb65d0c85  vmovaps xmm10, [rsp+0xA0]
0000777bb65d0c8e  vmovaps xmm11, [rsp+0xB0]
0000777bb65d0c97  vmovaps xmm12, [rsp+0xC0]
0000777bb65d0ca0  vmovaps xmm14, [rsp+0xD0]
0000777bb65d0ca9  vmovaps xmm15, [rsp+0xE0]
0000777bb65d0cb2  add rsp, 0xF0
0000777bb65d0cb9  pop r11
0000777bb65d0cbb  pop r10
0000777bb65d0cbd  pop r9
0000777bb65d0cbf  pop r8
0000777bb65d0cc1  pop rsi
0000777bb65d0cc2  pop rdi
0000777bb65d0cc3  pop rdx
0000777bb65d0cc4  pop rcx
0000777bb65d0cc5  pop rax
0000777bb65d0cc6  add rsp, 0x08
0000777bb65d0cca  jmp 0x0000777BB65CF64C
0000777bb65d0ccf  sub rsp, 0x08
0000777bb65d0cd3  push rax
0000777bb65d0cd4  push rcx
0000777bb65d0cd5  push rdx
0000777bb65d0cd6  push rdi
0000777bb65d0cd7  push rsi
0000777bb65d0cd8  push r8
0000777bb65d0cda  push r9
0000777bb65d0cdc  push r10
0000777bb65d0cde  push r11
0000777bb65d0ce0  sub rsp, 0xF0
0000777bb65d0ce7  vmovaps [rsp], xmm0
0000777bb65d0cec  vmovaps [rsp+0x10], xmm2
0000777bb65d0cf2  vmovaps [rsp+0x20], xmm3
0000777bb65d0cf8  vmovaps [rsp+0x30], xmm4
0000777bb65d0cfe  vmovaps [rsp+0x40], xmm5
0000777bb65d0d04  vmovaps [rsp+0x50], xmm6
0000777bb65d0d0a  vmovaps [rsp+0x60], xmm7
0000777bb65d0d10  vmovaps [rsp+0x70], xmm8
0000777bb65d0d16  vmovaps [rsp+0x80], xmm9
0000777bb65d0d1f  vmovaps [rsp+0x90], xmm10
0000777bb65d0d28  vmovaps [rsp+0xA0], xmm11
0000777bb65d0d31  vmovaps [rsp+0xB0], xmm12
0000777bb65d0d3a  vmovaps [rsp+0xC0], xmm13
0000777bb65d0d43  vmovaps [rsp+0xD0], xmm14
0000777bb65d0d4c  vmovaps [rsp+0xE0], xmm15
0000777bb65d0d55  sub rsp, 0x30
0000777bb65d0d59  movaps [rsp], xmm1
0000777bb65d0d5d  movaps [rsp+0x10], xmm10
0000777bb65d0d63  movaps [rsp+0x20], xmm2
0000777bb65d0d68  lea rdi, [rsp]
0000777bb65d0d6c  mov esi, 0x00
0000777bb65d0d71  mov rax, 0x569DC437B530
0000777bb65d0d7b  call rax
0000777bb65d0d7d  movaps xmm1, [rsp]
0000777bb65d0d81  add rsp, 0x30
0000777bb65d0d85  vmovaps xmm0, [rsp]
0000777bb65d0d8a  vmovaps xmm2, [rsp+0x10]
0000777bb65d0d90  vmovaps xmm3, [rsp+0x20]
0000777bb65d0d96  vmovaps xmm4, [rsp+0x30]
0000777bb65d0d9c  vmovaps xmm5, [rsp+0x40]
0000777bb65d0da2  vmovaps xmm6, [rsp+0x50]
0000777bb65d0da8  vmovaps xmm7, [rsp+0x60]
0000777bb65d0dae  vmovaps xmm8, [rsp+0x70]
0000777bb65d0db4  vmovaps xmm9, [rsp+0x80]
0000777bb65d0dbd  vmovaps xmm10, [rsp+0x90]
0000777bb65d0dc6  vmovaps xmm11, [rsp+0xA0]
0000777bb65d0dcf  vmovaps xmm12, [rsp+0xB0]
0000777bb65d0dd8  vmovaps xmm13, [rsp+0xC0]
0000777bb65d0de1  vmovaps xmm14, [rsp+0xD0]
0000777bb65d0dea  vmovaps xmm15, [rsp+0xE0]
0000777bb65d0df3  add rsp, 0xF0
0000777bb65d0dfa  pop r11
0000777bb65d0dfc  pop r10
0000777bb65d0dfe  pop r9
0000777bb65d0e00  pop r8
0000777bb65d0e02  pop rsi
0000777bb65d0e03  pop rdi
0000777bb65d0e04  pop rdx
0000777bb65d0e05  pop rcx
0000777bb65d0e06  pop rax
0000777bb65d0e07  add rsp, 0x08
0000777bb65d0e0b  jmp 0x0000777BB65CF6B4
0000777bb65d0e10  sub rsp, 0x08
0000777bb65d0e14  push rax
0000777bb65d0e15  push rcx
0000777bb65d0e16  push rdx
0000777bb65d0e17  push rdi
0000777bb65d0e18  push rsi
0000777bb65d0e19  push r8
0000777bb65d0e1b  push r9
0000777bb65d0e1d  push r10
0000777bb65d0e1f  push r11
0000777bb65d0e21  sub rsp, 0xF0
0000777bb65d0e28  vmovaps [rsp], xmm0
0000777bb65d0e2d  vmovaps [rsp+0x10], xmm1
0000777bb65d0e33  vmovaps [rsp+0x20], xmm2
0000777bb65d0e39  vmovaps [rsp+0x30], xmm3
0000777bb65d0e3f  vmovaps [rsp+0x40], xmm4
0000777bb65d0e45  vmovaps [rsp+0x50], xmm5
0000777bb65d0e4b  vmovaps [rsp+0x60], xmm6
0000777bb65d0e51  vmovaps [rsp+0x70], xmm7
0000777bb65d0e57  vmovaps [rsp+0x80], xmm8
0000777bb65d0e60  vmovaps [rsp+0x90], xmm9
0000777bb65d0e69  vmovaps [rsp+0xA0], xmm10
0000777bb65d0e72  vmovaps [rsp+0xB0], xmm11
0000777bb65d0e7b  vmovaps [rsp+0xC0], xmm12
0000777bb65d0e84  vmovaps [rsp+0xD0], xmm13
0000777bb65d0e8d  vmovaps [rsp+0xE0], xmm14
0000777bb65d0e96  sub rsp, 0x30
0000777bb65d0e9a  movaps [rsp], xmm15
0000777bb65d0e9f  movaps [rsp+0x10], xmm10
0000777bb65d0ea5  movaps [rsp+0x20], xmm2
0000777bb65d0eaa  lea rdi, [rsp]
0000777bb65d0eae  mov esi, 0x00
0000777bb65d0eb3  mov rax, 0x569DC437B530
0000777bb65d0ebd  call rax
0000777bb65d0ebf  movaps xmm15, [rsp]
0000777bb65d0ec4  add rsp, 0x30
0000777bb65d0ec8  vmovaps xmm0, [rsp]
0000777bb65d0ecd  vmovaps xmm1, [rsp+0x10]
0000777bb65d0ed3  vmovaps xmm2, [rsp+0x20]
0000777bb65d0ed9  vmovaps xmm3, [rsp+0x30]
0000777bb65d0edf  vmovaps xmm4, [rsp+0x40]
0000777bb65d0ee5  vmovaps xmm5, [rsp+0x50]
0000777bb65d0eeb  vmovaps xmm6, [rsp+0x60]
0000777bb65d0ef1  vmovaps xmm7, [rsp+0x70]
0000777bb65d0ef7  vmovaps xmm8, [rsp+0x80]
0000777bb65d0f00  vmovaps xmm9, [rsp+0x90]
0000777bb65d0f09  vmovaps xmm10, [rsp+0xA0]
0000777bb65d0f12  vmovaps xmm11, [rsp+0xB0]
0000777bb65d0f1b  vmovaps xmm12, [rsp+0xC0]
0000777bb65d0f24  vmovaps xmm13, [rsp+0xD0]
0000777bb65d0f2d  vmovaps xmm14, [rsp+0xE0]
0000777bb65d0f36  add rsp, 0xF0
0000777bb65d0f3d  pop r11
0000777bb65d0f3f  pop r10
0000777bb65d0f41  pop r9
0000777bb65d0f43  pop r8
0000777bb65d0f45  pop rsi
0000777bb65d0f46  pop rdi
0000777bb65d0f47  pop rdx
0000777bb65d0f48  pop rcx
0000777bb65d0f49  pop rax
0000777bb65d0f4a  add rsp, 0x08
0000777bb65d0f4e  jmp 0x0000777BB65CF706
0000777bb65d0f53  sub rsp, 0x08
0000777bb65d0f57  push rax
0000777bb65d0f58  push rcx
0000777bb65d0f59  push rdx
0000777bb65d0f5a  push rdi
0000777bb65d0f5b  push rsi
0000777bb65d0f5c  push r8
0000777bb65d0f5e  push r9
0000777bb65d0f60  push r10
0000777bb65d0f62  push r11
0000777bb65d0f64  sub rsp, 0xF0
0000777bb65d0f6b  vmovaps [rsp], xmm0
0000777bb65d0f70  vmovaps [rsp+0x10], xmm2
0000777bb65d0f76  vmovaps [rsp+0x20], xmm3
0000777bb65d0f7c  vmovaps [rsp+0x30], xmm4
0000777bb65d0f82  vmovaps [rsp+0x40], xmm5
0000777bb65d0f88  vmovaps [rsp+0x50], xmm6
0000777bb65d0f8e  vmovaps [rsp+0x60], xmm7
0000777bb65d0f94  vmovaps [rsp+0x70], xmm8
0000777bb65d0f9a  vmovaps [rsp+0x80], xmm9
0000777bb65d0fa3  vmovaps [rsp+0x90], xmm10
0000777bb65d0fac  vmovaps [rsp+0xA0], xmm11
0000777bb65d0fb5  vmovaps [rsp+0xB0], xmm12
0000777bb65d0fbe  vmovaps [rsp+0xC0], xmm13
0000777bb65d0fc7  vmovaps [rsp+0xD0], xmm14
0000777bb65d0fd0  vmovaps [rsp+0xE0], xmm15
0000777bb65d0fd9  sub rsp, 0x30
0000777bb65d0fdd  movaps [rsp], xmm1
0000777bb65d0fe1  movaps [rsp+0x10], xmm10
0000777bb65d0fe7  movaps [rsp+0x20], xmm12
0000777bb65d0fed  lea rdi, [rsp]
0000777bb65d0ff1  mov esi, 0x00
0000777bb65d0ff6  mov rax, 0x569DC437B530
0000777bb65d1000  call rax
0000777bb65d1002  movaps xmm1, [rsp]
0000777bb65d1006  add rsp, 0x30
0000777bb65d100a  vmovaps xmm0, [rsp]
0000777bb65d100f  vmovaps xmm2, [rsp+0x10]
0000777bb65d1015  vmovaps xmm3, [rsp+0x20]
0000777bb65d101b  vmovaps xmm4, [rsp+0x30]
0000777bb65d1021  vmovaps xmm5, [rsp+0x40]
0000777bb65d1027  vmovaps xmm6, [rsp+0x50]
0000777bb65d102d  vmovaps xmm7, [rsp+0x60]
0000777bb65d1033  vmovaps xmm8, [rsp+0x70]
0000777bb65d1039  vmovaps xmm9, [rsp+0x80]
0000777bb65d1042  vmovaps xmm10, [rsp+0x90]
0000777bb65d104b  vmovaps xmm11, [rsp+0xA0]
0000777bb65d1054  vmovaps xmm12, [rsp+0xB0]
0000777bb65d105d  vmovaps xmm13, [rsp+0xC0]
0000777bb65d1066  vmovaps xmm14, [rsp+0xD0]
0000777bb65d106f  vmovaps xmm15, [rsp+0xE0]
0000777bb65d1078  add rsp, 0xF0
0000777bb65d107f  pop r11
0000777bb65d1081  pop r10
0000777bb65d1083  pop r9
0000777bb65d1085  pop r8
0000777bb65d1087  pop rsi
0000777bb65d1088  pop rdi
0000777bb65d1089  pop rdx
0000777bb65d108a  pop rcx
0000777bb65d108b  pop rax
0000777bb65d108c  add rsp, 0x08
0000777bb65d1090  jmp 0x0000777BB65CF732
0000777bb65d1095  sub rsp, 0x08
0000777bb65d1099  push rax
0000777bb65d109a  push rcx
0000777bb65d109b  push rdx
0000777bb65d109c  push rdi
0000777bb65d109d  push rsi
0000777bb65d109e  push r8
0000777bb65d10a0  push r9
0000777bb65d10a2  push r10
0000777bb65d10a4  push r11
0000777bb65d10a6  sub rsp, 0xF0
0000777bb65d10ad  vmovaps [rsp], xmm0
0000777bb65d10b2  vmovaps [rsp+0x10], xmm1
0000777bb65d10b8  vmovaps [rsp+0x20], xmm2
0000777bb65d10be  vmovaps [rsp+0x30], xmm3
0000777bb65d10c4  vmovaps [rsp+0x40], xmm4
0000777bb65d10ca  vmovaps [rsp+0x50], xmm5
0000777bb65d10d0  vmovaps [rsp+0x60], xmm6
0000777bb65d10d6  vmovaps [rsp+0x70], xmm7
0000777bb65d10dc  vmovaps [rsp+0x80], xmm8
0000777bb65d10e5  vmovaps [rsp+0x90], xmm9
0000777bb65d10ee  vmovaps [rsp+0xA0], xmm10
0000777bb65d10f7  vmovaps [rsp+0xB0], xmm11
0000777bb65d1100  vmovaps [rsp+0xC0], xmm12
0000777bb65d1109  vmovaps [rsp+0xD0], xmm13
0000777bb65d1112  vmovaps [rsp+0xE0], xmm14
0000777bb65d111b  sub rsp, 0x30
0000777bb65d111f  movaps [rsp], xmm15
0000777bb65d1124  movaps [rsp+0x10], xmm10
0000777bb65d112a  movaps [rsp+0x20], xmm12
0000777bb65d1130  lea rdi, [rsp]
0000777bb65d1134  mov esi, 0x00
0000777bb65d1139  mov rax, 0x569DC437B530
0000777bb65d1143  call rax
0000777bb65d1145  movaps xmm15, [rsp]
0000777bb65d114a  add rsp, 0x30
0000777bb65d114e  vmovaps xmm0, [rsp]
0000777bb65d1153  vmovaps xmm1, [rsp+0x10]
0000777bb65d1159  vmovaps xmm2, [rsp+0x20]
0000777bb65d115f  vmovaps xmm3, [rsp+0x30]
0000777bb65d1165  vmovaps xmm4, [rsp+0x40]
0000777bb65d116b  vmovaps xmm5, [rsp+0x50]
0000777bb65d1171  vmovaps xmm6, [rsp+0x60]
0000777bb65d1177  vmovaps xmm7, [rsp+0x70]
0000777bb65d117d  vmovaps xmm8, [rsp+0x80]
0000777bb65d1186  vmovaps xmm9, [rsp+0x90]
0000777bb65d118f  vmovaps xmm10, [rsp+0xA0]
0000777bb65d1198  vmovaps xmm11, [rsp+0xB0]
0000777bb65d11a1  vmovaps xmm12, [rsp+0xC0]
0000777bb65d11aa  vmovaps xmm13, [rsp+0xD0]
0000777bb65d11b3  vmovaps xmm14, [rsp+0xE0]
0000777bb65d11bc  add rsp, 0xF0
0000777bb65d11c3  pop r11
0000777bb65d11c5  pop r10
0000777bb65d11c7  pop r9
0000777bb65d11c9  pop r8
0000777bb65d11cb  pop rsi
0000777bb65d11cc  pop rdi
0000777bb65d11cd  pop rdx
0000777bb65d11ce  pop rcx
0000777bb65d11cf  pop rax
0000777bb65d11d0  add rsp, 0x08
0000777bb65d11d4  jmp 0x0000777BB65CF75E
0000777bb65d11d9  call 0x0000777BB63FF430
0000777bb65d11de  jmp 0x0000777BB65CF7EE
0000777bb65d11e3  call 0x0000777BB63FF430
0000777bb65d11e8  jmp 0x0000777BB65CF801
0000777bb65d11ed  sub rsp, 0x08
0000777bb65d11f1  push rax
0000777bb65d11f2  push rcx
0000777bb65d11f3  push rdx
0000777bb65d11f4  push rdi
0000777bb65d11f5  push rsi
0000777bb65d11f6  push r8
0000777bb65d11f8  push r9
0000777bb65d11fa  push r10
0000777bb65d11fc  push r11
0000777bb65d11fe  sub rsp, 0xF0
0000777bb65d1205  vmovaps [rsp], xmm0
0000777bb65d120a  vmovaps [rsp+0x10], xmm2
0000777bb65d1210  vmovaps [rsp+0x20], xmm3
0000777bb65d1216  vmovaps [rsp+0x30], xmm4
0000777bb65d121c  vmovaps [rsp+0x40], xmm5
0000777bb65d1222  vmovaps [rsp+0x50], xmm6
0000777bb65d1228  vmovaps [rsp+0x60], xmm7
0000777bb65d122e  vmovaps [rsp+0x70], xmm8
0000777bb65d1234  vmovaps [rsp+0x80], xmm9
0000777bb65d123d  vmovaps [rsp+0x90], xmm10
0000777bb65d1246  vmovaps [rsp+0xA0], xmm11
0000777bb65d124f  vmovaps [rsp+0xB0], xmm12
0000777bb65d1258  vmovaps [rsp+0xC0], xmm13
0000777bb65d1261  vmovaps [rsp+0xD0], xmm14
0000777bb65d126a  vmovaps [rsp+0xE0], xmm15
0000777bb65d1273  sub rsp, 0x30
0000777bb65d1277  movaps [rsp], xmm1
0000777bb65d127b  movaps [rsp+0x10], xmm13
0000777bb65d1281  movaps [rsp+0x20], xmm2
0000777bb65d1286  lea rdi, [rsp]
0000777bb65d128a  mov esi, 0x00
0000777bb65d128f  mov rax, 0x569DC437B530
0000777bb65d1299  call rax
0000777bb65d129b  movaps xmm1, [rsp]
0000777bb65d129f  add rsp, 0x30
0000777bb65d12a3  vmovaps xmm0, [rsp]
0000777bb65d12a8  vmovaps xmm2, [rsp+0x10]
0000777bb65d12ae  vmovaps xmm3, [rsp+0x20]
0000777bb65d12b4  vmovaps xmm4, [rsp+0x30]
0000777bb65d12ba  vmovaps xmm5, [rsp+0x40]
0000777bb65d12c0  vmovaps xmm6, [rsp+0x50]
0000777bb65d12c6  vmovaps xmm7, [rsp+0x60]
0000777bb65d12cc  vmovaps xmm8, [rsp+0x70]
0000777bb65d12d2  vmovaps xmm9, [rsp+0x80]
0000777bb65d12db  vmovaps xmm10, [rsp+0x90]
0000777bb65d12e4  vmovaps xmm11, [rsp+0xA0]
0000777bb65d12ed  vmovaps xmm12, [rsp+0xB0]
0000777bb65d12f6  vmovaps xmm13, [rsp+0xC0]
0000777bb65d12ff  vmovaps xmm14, [rsp+0xD0]
0000777bb65d1308  vmovaps xmm15, [rsp+0xE0]
0000777bb65d1311  add rsp, 0xF0
0000777bb65d1318  pop r11
0000777bb65d131a  pop r10
0000777bb65d131c  pop r9
0000777bb65d131e  pop r8
0000777bb65d1320  pop rsi
0000777bb65d1321  pop rdi
0000777bb65d1322  pop rdx
0000777bb65d1323  pop rcx
0000777bb65d1324  pop rax
0000777bb65d1325  add rsp, 0x08
0000777bb65d1329  jmp 0x0000777BB65CF82C
0000777bb65d132e  call 0x0000777BB640E760
0000777bb65d1333  jmp 0x0000777BB65CF839
0000777bb65d1338  sub rsp, 0x08
0000777bb65d133c  push rax
0000777bb65d133d  push rcx
0000777bb65d133e  push rdx
0000777bb65d133f  push rdi
0000777bb65d1340  push rsi
0000777bb65d1341  push r8
0000777bb65d1343  push r9
0000777bb65d1345  push r10
0000777bb65d1347  push r11
0000777bb65d1349  sub rsp, 0xF0
0000777bb65d1350  vmovaps [rsp], xmm0
0000777bb65d1355  vmovaps [rsp+0x10], xmm1
0000777bb65d135b  vmovaps [rsp+0x20], xmm2
0000777bb65d1361  vmovaps [rsp+0x30], xmm3
0000777bb65d1367  vmovaps [rsp+0x40], xmm4
0000777bb65d136d  vmovaps [rsp+0x50], xmm5
0000777bb65d1373  vmovaps [rsp+0x60], xmm6
0000777bb65d1379  vmovaps [rsp+0x70], xmm7
0000777bb65d137f  vmovaps [rsp+0x80], xmm8
0000777bb65d1388  vmovaps [rsp+0x90], xmm9
0000777bb65d1391  vmovaps [rsp+0xA0], xmm10
0000777bb65d139a  vmovaps [rsp+0xB0], xmm11
0000777bb65d13a3  vmovaps [rsp+0xC0], xmm12
0000777bb65d13ac  vmovaps [rsp+0xD0], xmm14
0000777bb65d13b5  vmovaps [rsp+0xE0], xmm15
0000777bb65d13be  sub rsp, 0x30
0000777bb65d13c2  movaps [rsp], xmm13
0000777bb65d13c7  movaps [rsp+0x10], xmm2
0000777bb65d13cc  movaps [rsp+0x20], xmm1
0000777bb65d13d1  lea rdi, [rsp]
0000777bb65d13d5  mov esi, 0x00
0000777bb65d13da  mov rax, 0x569DC437B530
0000777bb65d13e4  call rax
0000777bb65d13e6  movaps xmm13, [rsp]
0000777bb65d13eb  add rsp, 0x30
0000777bb65d13ef  vmovaps xmm0, [rsp]
0000777bb65d13f4  vmovaps xmm1, [rsp+0x10]
0000777bb65d13fa  vmovaps xmm2, [rsp+0x20]
0000777bb65d1400  vmovaps xmm3, [rsp+0x30]
0000777bb65d1406  vmovaps xmm4, [rsp+0x40]
0000777bb65d140c  vmovaps xmm5, [rsp+0x50]
0000777bb65d1412  vmovaps xmm6, [rsp+0x60]
0000777bb65d1418  vmovaps xmm7, [rsp+0x70]
0000777bb65d141e  vmovaps xmm8, [rsp+0x80]
0000777bb65d1427  vmovaps xmm9, [rsp+0x90]
0000777bb65d1430  vmovaps xmm10, [rsp+0xA0]
0000777bb65d1439  vmovaps xmm11, [rsp+0xB0]
0000777bb65d1442  vmovaps xmm12, [rsp+0xC0]
0000777bb65d144b  vmovaps xmm14, [rsp+0xD0]
0000777bb65d1454  vmovaps xmm15, [rsp+0xE0]
0000777bb65d145d  add rsp, 0xF0
0000777bb65d1464  pop r11
0000777bb65d1466  pop r10
0000777bb65d1468  pop r9
0000777bb65d146a  pop r8
0000777bb65d146c  pop rsi
0000777bb65d146d  pop rdi
0000777bb65d146e  pop rdx
0000777bb65d146f  pop rcx
0000777bb65d1470  pop rax
0000777bb65d1471  add rsp, 0x08
0000777bb65d1475  jmp 0x0000777BB65CF878
0000777bb65d147a  sub rsp, 0x08
0000777bb65d147e  push rax
0000777bb65d147f  push rcx
0000777bb65d1480  push rdx
0000777bb65d1481  push rdi
0000777bb65d1482  push rsi
0000777bb65d1483  push r8
0000777bb65d1485  push r9
0000777bb65d1487  push r10
0000777bb65d1489  push r11
0000777bb65d148b  sub rsp, 0xF0
0000777bb65d1492  vmovaps [rsp], xmm0
0000777bb65d1497  vmovaps [rsp+0x10], xmm2
0000777bb65d149d  vmovaps [rsp+0x20], xmm3
0000777bb65d14a3  vmovaps [rsp+0x30], xmm4
0000777bb65d14a9  vmovaps [rsp+0x40], xmm5
0000777bb65d14af  vmovaps [rsp+0x50], xmm6
0000777bb65d14b5  vmovaps [rsp+0x60], xmm7
0000777bb65d14bb  vmovaps [rsp+0x70], xmm8
0000777bb65d14c1  vmovaps [rsp+0x80], xmm9
0000777bb65d14ca  vmovaps [rsp+0x90], xmm10
0000777bb65d14d3  vmovaps [rsp+0xA0], xmm11
0000777bb65d14dc  vmovaps [rsp+0xB0], xmm12
0000777bb65d14e5  vmovaps [rsp+0xC0], xmm13
0000777bb65d14ee  vmovaps [rsp+0xD0], xmm14
0000777bb65d14f7  vmovaps [rsp+0xE0], xmm15
0000777bb65d1500  sub rsp, 0x30
0000777bb65d1504  movaps [rsp], xmm1
0000777bb65d1508  movaps [rsp+0x10], xmm15
0000777bb65d150e  movaps [rsp+0x20], xmm2
0000777bb65d1513  lea rdi, [rsp]
0000777bb65d1517  mov esi, 0x00
0000777bb65d151c  mov rax, 0x569DC437B530
0000777bb65d1526  call rax
0000777bb65d1528  movaps xmm1, [rsp]
0000777bb65d152c  add rsp, 0x30
0000777bb65d1530  vmovaps xmm0, [rsp]
0000777bb65d1535  vmovaps xmm2, [rsp+0x10]
0000777bb65d153b  vmovaps xmm3, [rsp+0x20]
0000777bb65d1541  vmovaps xmm4, [rsp+0x30]
0000777bb65d1547  vmovaps xmm5, [rsp+0x40]
0000777bb65d154d  vmovaps xmm6, [rsp+0x50]
0000777bb65d1553  vmovaps xmm7, [rsp+0x60]
0000777bb65d1559  vmovaps xmm8, [rsp+0x70]
0000777bb65d155f  vmovaps xmm9, [rsp+0x80]
0000777bb65d1568  vmovaps xmm10, [rsp+0x90]
0000777bb65d1571  vmovaps xmm11, [rsp+0xA0]
0000777bb65d157a  vmovaps xmm12, [rsp+0xB0]
0000777bb65d1583  vmovaps xmm13, [rsp+0xC0]
0000777bb65d158c  vmovaps xmm14, [rsp+0xD0]
0000777bb65d1595  vmovaps xmm15, [rsp+0xE0]
0000777bb65d159e  add rsp, 0xF0
0000777bb65d15a5  pop r11
0000777bb65d15a7  pop r10
0000777bb65d15a9  pop r9
0000777bb65d15ab  pop r8
0000777bb65d15ad  pop rsi
0000777bb65d15ae  pop rdi
0000777bb65d15af  pop rdx
0000777bb65d15b0  pop rcx
0000777bb65d15b1  pop rax
0000777bb65d15b2  add rsp, 0x08
0000777bb65d15b6  jmp 0x0000777BB65CF8AC
0000777bb65d15bb  sub rsp, 0x08
0000777bb65d15bf  push rax
0000777bb65d15c0  push rcx
0000777bb65d15c1  push rdx
0000777bb65d15c2  push rdi
0000777bb65d15c3  push rsi
0000777bb65d15c4  push r8
0000777bb65d15c6  push r9
0000777bb65d15c8  push r10
0000777bb65d15ca  push r11
0000777bb65d15cc  sub rsp, 0xF0
0000777bb65d15d3  vmovaps [rsp], xmm0
0000777bb65d15d8  vmovaps [rsp+0x10], xmm1
0000777bb65d15de  vmovaps [rsp+0x20], xmm2
0000777bb65d15e4  vmovaps [rsp+0x30], xmm3
0000777bb65d15ea  vmovaps [rsp+0x40], xmm4
0000777bb65d15f0  vmovaps [rsp+0x50], xmm5
0000777bb65d15f6  vmovaps [rsp+0x60], xmm6
0000777bb65d15fc  vmovaps [rsp+0x70], xmm7
0000777bb65d1602  vmovaps [rsp+0x80], xmm8
0000777bb65d160b  vmovaps [rsp+0x90], xmm9
0000777bb65d1614  vmovaps [rsp+0xA0], xmm10
0000777bb65d161d  vmovaps [rsp+0xB0], xmm11
0000777bb65d1626  vmovaps [rsp+0xC0], xmm12
0000777bb65d162f  vmovaps [rsp+0xD0], xmm13
0000777bb65d1638  vmovaps [rsp+0xE0], xmm15
0000777bb65d1641  sub rsp, 0x30
0000777bb65d1645  movaps [rsp], xmm14
0000777bb65d164a  movaps [rsp+0x10], xmm2
0000777bb65d164f  movaps [rsp+0x20], xmm15
0000777bb65d1655  lea rdi, [rsp]
0000777bb65d1659  mov esi, 0x00
0000777bb65d165e  mov rax, 0x569DC437B530
0000777bb65d1668  call rax
0000777bb65d166a  movaps xmm14, [rsp]
0000777bb65d166f  add rsp, 0x30
0000777bb65d1673  vmovaps xmm0, [rsp]
0000777bb65d1678  vmovaps xmm1, [rsp+0x10]
0000777bb65d167e  vmovaps xmm2, [rsp+0x20]
0000777bb65d1684  vmovaps xmm3, [rsp+0x30]
0000777bb65d168a  vmovaps xmm4, [rsp+0x40]
0000777bb65d1690  vmovaps xmm5, [rsp+0x50]
0000777bb65d1696  vmovaps xmm6, [rsp+0x60]
0000777bb65d169c  vmovaps xmm7, [rsp+0x70]
0000777bb65d16a2  vmovaps xmm8, [rsp+0x80]
0000777bb65d16ab  vmovaps xmm9, [rsp+0x90]
0000777bb65d16b4  vmovaps xmm10, [rsp+0xA0]
0000777bb65d16bd  vmovaps xmm11, [rsp+0xB0]
0000777bb65d16c6  vmovaps xmm12, [rsp+0xC0]
0000777bb65d16cf  vmovaps xmm13, [rsp+0xD0]
0000777bb65d16d8  vmovaps xmm15, [rsp+0xE0]
0000777bb65d16e1  add rsp, 0xF0
0000777bb65d16e8  pop r11
0000777bb65d16ea  pop r10
0000777bb65d16ec  pop r9
0000777bb65d16ee  pop r8
0000777bb65d16f0  pop rsi
0000777bb65d16f1  pop rdi
0000777bb65d16f2  pop rdx
0000777bb65d16f3  pop rcx
0000777bb65d16f4  pop rax
0000777bb65d16f5  add rsp, 0x08
0000777bb65d16f9  jmp 0x0000777BB65CF8E7
0000777bb65d16fe  sub rsp, 0x08
0000777bb65d1702  push rax
0000777bb65d1703  push rcx
0000777bb65d1704  push rdx
0000777bb65d1705  push rdi
0000777bb65d1706  push rsi
0000777bb65d1707  push r8
0000777bb65d1709  push r9
0000777bb65d170b  push r10
0000777bb65d170d  push r11
0000777bb65d170f  sub rsp, 0xF0
0000777bb65d1716  vmovaps [rsp], xmm0
0000777bb65d171b  vmovaps [rsp+0x10], xmm1
0000777bb65d1721  vmovaps [rsp+0x20], xmm2
0000777bb65d1727  vmovaps [rsp+0x30], xmm3
0000777bb65d172d  vmovaps [rsp+0x40], xmm4
0000777bb65d1733  vmovaps [rsp+0x50], xmm5
0000777bb65d1739  vmovaps [rsp+0x60], xmm6
0000777bb65d173f  vmovaps [rsp+0x70], xmm7
0000777bb65d1745  vmovaps [rsp+0x80], xmm8
0000777bb65d174e  vmovaps [rsp+0x90], xmm9
0000777bb65d1757  vmovaps [rsp+0xA0], xmm10
0000777bb65d1760  vmovaps [rsp+0xB0], xmm11
0000777bb65d1769  vmovaps [rsp+0xC0], xmm12
0000777bb65d1772  vmovaps [rsp+0xD0], xmm13
0000777bb65d177b  vmovaps [rsp+0xE0], xmm14
0000777bb65d1784  sub rsp, 0x30
0000777bb65d1788  movaps [rsp], xmm15
0000777bb65d178d  movaps [rsp+0x10], xmm2
0000777bb65d1792  movaps [rsp+0x20], xmm1
0000777bb65d1797  lea rdi, [rsp]
0000777bb65d179b  mov esi, 0x00
0000777bb65d17a0  mov rax, 0x569DC437B530
0000777bb65d17aa  call rax
0000777bb65d17ac  movaps xmm15, [rsp]
0000777bb65d17b1  add rsp, 0x30
0000777bb65d17b5  vmovaps xmm0, [rsp]
0000777bb65d17ba  vmovaps xmm1, [rsp+0x10]
0000777bb65d17c0  vmovaps xmm2, [rsp+0x20]
0000777bb65d17c6  vmovaps xmm3, [rsp+0x30]
0000777bb65d17cc  vmovaps xmm4, [rsp+0x40]
0000777bb65d17d2  vmovaps xmm5, [rsp+0x50]
0000777bb65d17d8  vmovaps xmm6, [rsp+0x60]
0000777bb65d17de  vmovaps xmm7, [rsp+0x70]
0000777bb65d17e4  vmovaps xmm8, [rsp+0x80]
0000777bb65d17ed  vmovaps xmm9, [rsp+0x90]
0000777bb65d17f6  vmovaps xmm10, [rsp+0xA0]
0000777bb65d17ff  vmovaps xmm11, [rsp+0xB0]
0000777bb65d1808  vmovaps xmm12, [rsp+0xC0]
0000777bb65d1811  vmovaps xmm13, [rsp+0xD0]
0000777bb65d181a  vmovaps xmm14, [rsp+0xE0]
0000777bb65d1823  add rsp, 0xF0
0000777bb65d182a  pop r11
0000777bb65d182c  pop r10
0000777bb65d182e  pop r9
0000777bb65d1830  pop r8
0000777bb65d1832  pop rsi
0000777bb65d1833  pop rdi
0000777bb65d1834  pop rdx
0000777bb65d1835  pop rcx
0000777bb65d1836  pop rax
0000777bb65d1837  add rsp, 0x08
0000777bb65d183b  jmp 0x0000777BB65CF923
0000777bb65d1840  call 0x0000777BB63FF430
0000777bb65d1845  jmp 0x0000777BB65CF930
0000777bb65d184a  sub rsp, 0x08
0000777bb65d184e  push rax
0000777bb65d184f  push rcx
0000777bb65d1850  push rdx
0000777bb65d1851  push rdi
0000777bb65d1852  push rsi
0000777bb65d1853  push r8
0000777bb65d1855  push r9
0000777bb65d1857  push r10
0000777bb65d1859  push r11
0000777bb65d185b  sub rsp, 0xF0
0000777bb65d1862  vmovaps [rsp], xmm0
0000777bb65d1867  vmovaps [rsp+0x10], xmm1
0000777bb65d186d  vmovaps [rsp+0x20], xmm3
0000777bb65d1873  vmovaps [rsp+0x30], xmm4
0000777bb65d1879  vmovaps [rsp+0x40], xmm5
0000777bb65d187f  vmovaps [rsp+0x50], xmm6
0000777bb65d1885  vmovaps [rsp+0x60], xmm7
0000777bb65d188b  vmovaps [rsp+0x70], xmm8
0000777bb65d1891  vmovaps [rsp+0x80], xmm9
0000777bb65d189a  vmovaps [rsp+0x90], xmm10
0000777bb65d18a3  vmovaps [rsp+0xA0], xmm11
0000777bb65d18ac  vmovaps [rsp+0xB0], xmm12
0000777bb65d18b5  vmovaps [rsp+0xC0], xmm13
0000777bb65d18be  vmovaps [rsp+0xD0], xmm14
0000777bb65d18c7  vmovaps [rsp+0xE0], xmm15
0000777bb65d18d0  sub rsp, 0x30
0000777bb65d18d4  movaps [rsp], xmm2
0000777bb65d18d8  movaps [rsp+0x10], xmm1
0000777bb65d18dd  movaps [rsp+0x20], xmm14
0000777bb65d18e3  lea rdi, [rsp]
0000777bb65d18e7  mov esi, 0x00
0000777bb65d18ec  mov rax, 0x569DC437B530
0000777bb65d18f6  call rax
0000777bb65d18f8  movaps xmm2, [rsp]
0000777bb65d18fc  add rsp, 0x30
0000777bb65d1900  vmovaps xmm0, [rsp]
0000777bb65d1905  vmovaps xmm1, [rsp+0x10]
0000777bb65d190b  vmovaps xmm3, [rsp+0x20]
0000777bb65d1911  vmovaps xmm4, [rsp+0x30]
0000777bb65d1917  vmovaps xmm5, [rsp+0x40]
0000777bb65d191d  vmovaps xmm6, [rsp+0x50]
0000777bb65d1923  vmovaps xmm7, [rsp+0x60]
0000777bb65d1929  vmovaps xmm8, [rsp+0x70]
0000777bb65d192f  vmovaps xmm9, [rsp+0x80]
0000777bb65d1938  vmovaps xmm10, [rsp+0x90]
0000777bb65d1941  vmovaps xmm11, [rsp+0xA0]
0000777bb65d194a  vmovaps xmm12, [rsp+0xB0]
0000777bb65d1953  vmovaps xmm13, [rsp+0xC0]
0000777bb65d195c  vmovaps xmm14, [rsp+0xD0]
0000777bb65d1965  vmovaps xmm15, [rsp+0xE0]
0000777bb65d196e  add rsp, 0xF0
0000777bb65d1975  pop r11
0000777bb65d1977  pop r10
0000777bb65d1979  pop r9
0000777bb65d197b  pop r8
0000777bb65d197d  pop rsi
0000777bb65d197e  pop rdi
0000777bb65d197f  pop rdx
0000777bb65d1980  pop rcx
0000777bb65d1981  pop rax
0000777bb65d1982  add rsp, 0x08
0000777bb65d1986  jmp 0x0000777BB65CF96D
0000777bb65d198b  sub rsp, 0x08
0000777bb65d198f  push rax
0000777bb65d1990  push rcx
0000777bb65d1991  push rdx
0000777bb65d1992  push rdi
0000777bb65d1993  push rsi
0000777bb65d1994  push r8
0000777bb65d1996  push r9
0000777bb65d1998  push r10
0000777bb65d199a  push r11
0000777bb65d199c  sub rsp, 0xF0
0000777bb65d19a3  vmovaps [rsp], xmm0
0000777bb65d19a8  vmovaps [rsp+0x10], xmm1
0000777bb65d19ae  vmovaps [rsp+0x20], xmm2
0000777bb65d19b4  vmovaps [rsp+0x30], xmm3
0000777bb65d19ba  vmovaps [rsp+0x40], xmm4
0000777bb65d19c0  vmovaps [rsp+0x50], xmm5
0000777bb65d19c6  vmovaps [rsp+0x60], xmm6
0000777bb65d19cc  vmovaps [rsp+0x70], xmm7
0000777bb65d19d2  vmovaps [rsp+0x80], xmm8
0000777bb65d19db  vmovaps [rsp+0x90], xmm9
0000777bb65d19e4  vmovaps [rsp+0xA0], xmm10
0000777bb65d19ed  vmovaps [rsp+0xB0], xmm11
0000777bb65d19f6  vmovaps [rsp+0xC0], xmm12
0000777bb65d19ff  vmovaps [rsp+0xD0], xmm13
0000777bb65d1a08  vmovaps [rsp+0xE0], xmm14
0000777bb65d1a11  sub rsp, 0x30
0000777bb65d1a15  movaps [rsp], xmm15
0000777bb65d1a1a  movaps [rsp+0x10], xmm14
0000777bb65d1a20  movaps [rsp+0x20], xmm1
0000777bb65d1a25  lea rdi, [rsp]
0000777bb65d1a29  mov esi, 0x00
0000777bb65d1a2e  mov rax, 0x569DC437B530
0000777bb65d1a38  call rax
0000777bb65d1a3a  movaps xmm15, [rsp]
0000777bb65d1a3f  add rsp, 0x30
0000777bb65d1a43  vmovaps xmm0, [rsp]
0000777bb65d1a48  vmovaps xmm1, [rsp+0x10]
0000777bb65d1a4e  vmovaps xmm2, [rsp+0x20]
0000777bb65d1a54  vmovaps xmm3, [rsp+0x30]
0000777bb65d1a5a  vmovaps xmm4, [rsp+0x40]
0000777bb65d1a60  vmovaps xmm5, [rsp+0x50]
0000777bb65d1a66  vmovaps xmm6, [rsp+0x60]
0000777bb65d1a6c  vmovaps xmm7, [rsp+0x70]
0000777bb65d1a72  vmovaps xmm8, [rsp+0x80]
0000777bb65d1a7b  vmovaps xmm9, [rsp+0x90]
0000777bb65d1a84  vmovaps xmm10, [rsp+0xA0]
0000777bb65d1a8d  vmovaps xmm11, [rsp+0xB0]
0000777bb65d1a96  vmovaps xmm12, [rsp+0xC0]
0000777bb65d1a9f  vmovaps xmm13, [rsp+0xD0]
0000777bb65d1aa8  vmovaps xmm14, [rsp+0xE0]
0000777bb65d1ab1  add rsp, 0xF0
0000777bb65d1ab8  pop r11
0000777bb65d1aba  pop r10
0000777bb65d1abc  pop r9
0000777bb65d1abe  pop r8
0000777bb65d1ac0  pop rsi
0000777bb65d1ac1  pop rdi
0000777bb65d1ac2  pop rdx
0000777bb65d1ac3  pop rcx
0000777bb65d1ac4  pop rax
0000777bb65d1ac5  add rsp, 0x08
0000777bb65d1ac9  jmp 0x0000777BB65CF9E7
0000777bb65d1ace  call 0x0000777BB63FF430
0000777bb65d1ad3  jmp 0x0000777BB65CF9F4
0000777bb65d1ad8  sub rsp, 0x08
0000777bb65d1adc  push rax
0000777bb65d1add  push rcx
0000777bb65d1ade  push rdx
0000777bb65d1adf  push rdi
0000777bb65d1ae0  push rsi
0000777bb65d1ae1  push r8
0000777bb65d1ae3  push r9
0000777bb65d1ae5  push r10
0000777bb65d1ae7  push r11
0000777bb65d1ae9  sub rsp, 0xF0
0000777bb65d1af0  vmovaps [rsp], xmm0
0000777bb65d1af5  vmovaps [rsp+0x10], xmm1
0000777bb65d1afb  vmovaps [rsp+0x20], xmm2
0000777bb65d1b01  vmovaps [rsp+0x30], xmm3
0000777bb65d1b07  vmovaps [rsp+0x40], xmm4
0000777bb65d1b0d  vmovaps [rsp+0x50], xmm5
0000777bb65d1b13  vmovaps [rsp+0x60], xmm6
0000777bb65d1b19  vmovaps [rsp+0x70], xmm7
0000777bb65d1b1f  vmovaps [rsp+0x80], xmm8
0000777bb65d1b28  vmovaps [rsp+0x90], xmm9
0000777bb65d1b31  vmovaps [rsp+0xA0], xmm10
0000777bb65d1b3a  vmovaps [rsp+0xB0], xmm11
0000777bb65d1b43  vmovaps [rsp+0xC0], xmm12
0000777bb65d1b4c  vmovaps [rsp+0xD0], xmm13
0000777bb65d1b55  vmovaps [rsp+0xE0], xmm15
0000777bb65d1b5e  sub rsp, 0x30
0000777bb65d1b62  movaps [rsp], xmm14
0000777bb65d1b67  movaps [rsp+0x10], xmm13
0000777bb65d1b6d  movaps [rsp+0x20], xmm1
0000777bb65d1b72  lea rdi, [rsp]
0000777bb65d1b76  mov esi, 0x00
0000777bb65d1b7b  mov rax, 0x569DC437B530
0000777bb65d1b85  call rax
0000777bb65d1b87  movaps xmm14, [rsp]
0000777bb65d1b8c  add rsp, 0x30
0000777bb65d1b90  vmovaps xmm0, [rsp]
0000777bb65d1b95  vmovaps xmm1, [rsp+0x10]
0000777bb65d1b9b  vmovaps xmm2, [rsp+0x20]
0000777bb65d1ba1  vmovaps xmm3, [rsp+0x30]
0000777bb65d1ba7  vmovaps xmm4, [rsp+0x40]
0000777bb65d1bad  vmovaps xmm5, [rsp+0x50]
0000777bb65d1bb3  vmovaps xmm6, [rsp+0x60]
0000777bb65d1bb9  vmovaps xmm7, [rsp+0x70]
0000777bb65d1bbf  vmovaps xmm8, [rsp+0x80]
0000777bb65d1bc8  vmovaps xmm9, [rsp+0x90]
0000777bb65d1bd1  vmovaps xmm10, [rsp+0xA0]
0000777bb65d1bda  vmovaps xmm11, [rsp+0xB0]
0000777bb65d1be3  vmovaps xmm12, [rsp+0xC0]
0000777bb65d1bec  vmovaps xmm13, [rsp+0xD0]
0000777bb65d1bf5  vmovaps xmm15, [rsp+0xE0]
0000777bb65d1bfe  add rsp, 0xF0
0000777bb65d1c05  pop r11
0000777bb65d1c07  pop r10
0000777bb65d1c09  pop r9
0000777bb65d1c0b  pop r8
0000777bb65d1c0d  pop rsi
0000777bb65d1c0e  pop rdi
0000777bb65d1c0f  pop rdx
0000777bb65d1c10  pop rcx
0000777bb65d1c11  pop rax
0000777bb65d1c12  add rsp, 0x08
0000777bb65d1c16  jmp 0x0000777BB65CFAAF
0000777bb65d1c1b  sub rsp, 0x08
0000777bb65d1c1f  push rax
0000777bb65d1c20  push rcx
0000777bb65d1c21  push rdx
0000777bb65d1c22  push rdi
0000777bb65d1c23  push rsi
0000777bb65d1c24  push r8
0000777bb65d1c26  push r9
0000777bb65d1c28  push r10
0000777bb65d1c2a  push r11
0000777bb65d1c2c  sub rsp, 0xF0
0000777bb65d1c33  vmovaps [rsp], xmm0
0000777bb65d1c38  vmovaps [rsp+0x10], xmm1
0000777bb65d1c3e  vmovaps [rsp+0x20], xmm2
0000777bb65d1c44  vmovaps [rsp+0x30], xmm3
0000777bb65d1c4a  vmovaps [rsp+0x40], xmm4
0000777bb65d1c50  vmovaps [rsp+0x50], xmm5
0000777bb65d1c56  vmovaps [rsp+0x60], xmm6
0000777bb65d1c5c  vmovaps [rsp+0x70], xmm7
0000777bb65d1c62  vmovaps [rsp+0x80], xmm8
0000777bb65d1c6b  vmovaps [rsp+0x90], xmm9
0000777bb65d1c74  vmovaps [rsp+0xA0], xmm10
0000777bb65d1c7d  vmovaps [rsp+0xB0], xmm11
0000777bb65d1c86  vmovaps [rsp+0xC0], xmm12
0000777bb65d1c8f  vmovaps [rsp+0xD0], xmm13
0000777bb65d1c98  vmovaps [rsp+0xE0], xmm14
0000777bb65d1ca1  sub rsp, 0x30
0000777bb65d1ca5  movaps [rsp], xmm15
0000777bb65d1caa  movaps [rsp+0x10], xmm13
0000777bb65d1cb0  movaps [rsp+0x20], xmm1
0000777bb65d1cb5  lea rdi, [rsp]
0000777bb65d1cb9  mov esi, 0x00
0000777bb65d1cbe  mov rax, 0x569DC437B530
0000777bb65d1cc8  call rax
0000777bb65d1cca  movaps xmm15, [rsp]
0000777bb65d1ccf  add rsp, 0x30
0000777bb65d1cd3  vmovaps xmm0, [rsp]
0000777bb65d1cd8  vmovaps xmm1, [rsp+0x10]
0000777bb65d1cde  vmovaps xmm2, [rsp+0x20]
0000777bb65d1ce4  vmovaps xmm3, [rsp+0x30]
0000777bb65d1cea  vmovaps xmm4, [rsp+0x40]
0000777bb65d1cf0  vmovaps xmm5, [rsp+0x50]
0000777bb65d1cf6  vmovaps xmm6, [rsp+0x60]
0000777bb65d1cfc  vmovaps xmm7, [rsp+0x70]
0000777bb65d1d02  vmovaps xmm8, [rsp+0x80]
0000777bb65d1d0b  vmovaps xmm9, [rsp+0x90]
0000777bb65d1d14  vmovaps xmm10, [rsp+0xA0]
0000777bb65d1d1d  vmovaps xmm11, [rsp+0xB0]
0000777bb65d1d26  vmovaps xmm12, [rsp+0xC0]
0000777bb65d1d2f  vmovaps xmm13, [rsp+0xD0]
0000777bb65d1d38  vmovaps xmm14, [rsp+0xE0]
0000777bb65d1d41  add rsp, 0xF0
0000777bb65d1d48  pop r11
0000777bb65d1d4a  pop r10
0000777bb65d1d4c  pop r9
0000777bb65d1d4e  pop r8
0000777bb65d1d50  pop rsi
0000777bb65d1d51  pop rdi
0000777bb65d1d52  pop rdx
0000777bb65d1d53  pop rcx
0000777bb65d1d54  pop rax
0000777bb65d1d55  add rsp, 0x08
0000777bb65d1d59  jmp 0x0000777BB65CFAEB
0000777bb65d1d5e  call 0x0000777BB63FF430
0000777bb65d1d63  jmp 0x0000777BB65CFAF8
0000777bb65d1d68  sub rsp, 0x08
0000777bb65d1d6c  push rax
0000777bb65d1d6d  push rcx
0000777bb65d1d6e  push rdx
0000777bb65d1d6f  push rdi
0000777bb65d1d70  push rsi
0000777bb65d1d71  push r8
0000777bb65d1d73  push r9
0000777bb65d1d75  push r10
0000777bb65d1d77  push r11
0000777bb65d1d79  sub rsp, 0xF0
0000777bb65d1d80  vmovaps [rsp], xmm0
0000777bb65d1d85  vmovaps [rsp+0x10], xmm1
0000777bb65d1d8b  vmovaps [rsp+0x20], xmm2
0000777bb65d1d91  vmovaps [rsp+0x30], xmm3
0000777bb65d1d97  vmovaps [rsp+0x40], xmm4
0000777bb65d1d9d  vmovaps [rsp+0x50], xmm5
0000777bb65d1da3  vmovaps [rsp+0x60], xmm6
0000777bb65d1da9  vmovaps [rsp+0x70], xmm7
0000777bb65d1daf  vmovaps [rsp+0x80], xmm8
0000777bb65d1db8  vmovaps [rsp+0x90], xmm9
0000777bb65d1dc1  vmovaps [rsp+0xA0], xmm10
0000777bb65d1dca  vmovaps [rsp+0xB0], xmm11
0000777bb65d1dd3  vmovaps [rsp+0xC0], xmm12
0000777bb65d1ddc  vmovaps [rsp+0xD0], xmm13
0000777bb65d1de5  vmovaps [rsp+0xE0], xmm15
0000777bb65d1dee  sub rsp, 0x30
0000777bb65d1df2  movaps [rsp], xmm14
0000777bb65d1df7  movaps [rsp+0x10], xmm13
0000777bb65d1dfd  movaps [rsp+0x20], xmm2
0000777bb65d1e02  lea rdi, [rsp]
0000777bb65d1e06  mov esi, 0x00
0000777bb65d1e0b  mov rax, 0x569DC437B530
0000777bb65d1e15  call rax
0000777bb65d1e17  movaps xmm14, [rsp]
0000777bb65d1e1c  add rsp, 0x30
0000777bb65d1e20  vmovaps xmm0, [rsp]
0000777bb65d1e25  vmovaps xmm1, [rsp+0x10]
0000777bb65d1e2b  vmovaps xmm2, [rsp+0x20]
0000777bb65d1e31  vmovaps xmm3, [rsp+0x30]
0000777bb65d1e37  vmovaps xmm4, [rsp+0x40]
0000777bb65d1e3d  vmovaps xmm5, [rsp+0x50]
0000777bb65d1e43  vmovaps xmm6, [rsp+0x60]
0000777bb65d1e49  vmovaps xmm7, [rsp+0x70]
0000777bb65d1e4f  vmovaps xmm8, [rsp+0x80]
0000777bb65d1e58  vmovaps xmm9, [rsp+0x90]
0000777bb65d1e61  vmovaps xmm10, [rsp+0xA0]
0000777bb65d1e6a  vmovaps xmm11, [rsp+0xB0]
0000777bb65d1e73  vmovaps xmm12, [rsp+0xC0]
0000777bb65d1e7c  vmovaps xmm13, [rsp+0xD0]
0000777bb65d1e85  vmovaps xmm15, [rsp+0xE0]
0000777bb65d1e8e  add rsp, 0xF0
0000777bb65d1e95  pop r11
0000777bb65d1e97  pop r10
0000777bb65d1e99  pop r9
0000777bb65d1e9b  pop r8
0000777bb65d1e9d  pop rsi
0000777bb65d1e9e  pop rdi
0000777bb65d1e9f  pop rdx
0000777bb65d1ea0  pop rcx
0000777bb65d1ea1  pop rax
0000777bb65d1ea2  add rsp, 0x08
0000777bb65d1ea6  jmp 0x0000777BB65CFB24
0000777bb65d1eab  sub rsp, 0x08
0000777bb65d1eaf  push rax
0000777bb65d1eb0  push rcx
0000777bb65d1eb1  push rdx
0000777bb65d1eb2  push rdi
0000777bb65d1eb3  push rsi
0000777bb65d1eb4  push r8
0000777bb65d1eb6  push r9
0000777bb65d1eb8  push r10
0000777bb65d1eba  push r11
0000777bb65d1ebc  sub rsp, 0xF0
0000777bb65d1ec3  vmovaps [rsp], xmm0
0000777bb65d1ec8  vmovaps [rsp+0x10], xmm2
0000777bb65d1ece  vmovaps [rsp+0x20], xmm3
0000777bb65d1ed4  vmovaps [rsp+0x30], xmm4
0000777bb65d1eda  vmovaps [rsp+0x40], xmm5
0000777bb65d1ee0  vmovaps [rsp+0x50], xmm6
0000777bb65d1ee6  vmovaps [rsp+0x60], xmm7
0000777bb65d1eec  vmovaps [rsp+0x70], xmm8
0000777bb65d1ef2  vmovaps [rsp+0x80], xmm9
0000777bb65d1efb  vmovaps [rsp+0x90], xmm10
0000777bb65d1f04  vmovaps [rsp+0xA0], xmm11
0000777bb65d1f0d  vmovaps [rsp+0xB0], xmm12
0000777bb65d1f16  vmovaps [rsp+0xC0], xmm13
0000777bb65d1f1f  vmovaps [rsp+0xD0], xmm14
0000777bb65d1f28  vmovaps [rsp+0xE0], xmm15
0000777bb65d1f31  sub rsp, 0x30
0000777bb65d1f35  movaps [rsp], xmm1
0000777bb65d1f39  movaps [rsp+0x10], xmm13
0000777bb65d1f3f  movaps [rsp+0x20], xmm2
0000777bb65d1f44  lea rdi, [rsp]
0000777bb65d1f48  mov esi, 0x00
0000777bb65d1f4d  mov rax, 0x569DC437B530
0000777bb65d1f57  call rax
0000777bb65d1f59  movaps xmm1, [rsp]
0000777bb65d1f5d  add rsp, 0x30
0000777bb65d1f61  vmovaps xmm0, [rsp]
0000777bb65d1f66  vmovaps xmm2, [rsp+0x10]
0000777bb65d1f6c  vmovaps xmm3, [rsp+0x20]
0000777bb65d1f72  vmovaps xmm4, [rsp+0x30]
0000777bb65d1f78  vmovaps xmm5, [rsp+0x40]
0000777bb65d1f7e  vmovaps xmm6, [rsp+0x50]
0000777bb65d1f84  vmovaps xmm7, [rsp+0x60]
0000777bb65d1f8a  vmovaps xmm8, [rsp+0x70]
0000777bb65d1f90  vmovaps xmm9, [rsp+0x80]
0000777bb65d1f99  vmovaps xmm10, [rsp+0x90]
0000777bb65d1fa2  vmovaps xmm11, [rsp+0xA0]
0000777bb65d1fab  vmovaps xmm12, [rsp+0xB0]
0000777bb65d1fb4  vmovaps xmm13, [rsp+0xC0]
0000777bb65d1fbd  vmovaps xmm14, [rsp+0xD0]
0000777bb65d1fc6  vmovaps xmm15, [rsp+0xE0]
0000777bb65d1fcf  add rsp, 0xF0
0000777bb65d1fd6  pop r11
0000777bb65d1fd8  pop r10
0000777bb65d1fda  pop r9
0000777bb65d1fdc  pop r8
0000777bb65d1fde  pop rsi
0000777bb65d1fdf  pop rdi
0000777bb65d1fe0  pop rdx
0000777bb65d1fe1  pop rcx
0000777bb65d1fe2  pop rax
0000777bb65d1fe3  add rsp, 0x08
0000777bb65d1fe7  jmp 0x0000777BB65CFB52
0000777bb65d1fec  sub rsp, 0x08
0000777bb65d1ff0  push rax
0000777bb65d1ff1  push rcx
0000777bb65d1ff2  push rdx
0000777bb65d1ff3  push rdi
0000777bb65d1ff4  push rsi
0000777bb65d1ff5  push r8
0000777bb65d1ff7  push r9
0000777bb65d1ff9  push r10
0000777bb65d1ffb  push r11
0000777bb65d1ffd  sub rsp, 0xF0
0000777bb65d2004  vmovaps [rsp], xmm0
0000777bb65d2009  vmovaps [rsp+0x10], xmm1
0000777bb65d200f  vmovaps [rsp+0x20], xmm3
0000777bb65d2015  vmovaps [rsp+0x30], xmm4
0000777bb65d201b  vmovaps [rsp+0x40], xmm5
0000777bb65d2021  vmovaps [rsp+0x50], xmm6
0000777bb65d2027  vmovaps [rsp+0x60], xmm7
0000777bb65d202d  vmovaps [rsp+0x70], xmm8
0000777bb65d2033  vmovaps [rsp+0x80], xmm9
0000777bb65d203c  vmovaps [rsp+0x90], xmm10
0000777bb65d2045  vmovaps [rsp+0xA0], xmm11
0000777bb65d204e  vmovaps [rsp+0xB0], xmm12
0000777bb65d2057  vmovaps [rsp+0xC0], xmm13
0000777bb65d2060  vmovaps [rsp+0xD0], xmm14
0000777bb65d2069  vmovaps [rsp+0xE0], xmm15
0000777bb65d2072  sub rsp, 0x30
0000777bb65d2076  movaps [rsp], xmm2
0000777bb65d207a  movaps [rsp+0x10], xmm1
0000777bb65d207f  movaps [rsp+0x20], xmm13
0000777bb65d2085  lea rdi, [rsp]
0000777bb65d2089  mov esi, 0x00
0000777bb65d208e  mov rax, 0x569DC437B530
0000777bb65d2098  call rax
0000777bb65d209a  movaps xmm2, [rsp]
0000777bb65d209e  add rsp, 0x30
0000777bb65d20a2  vmovaps xmm0, [rsp]
0000777bb65d20a7  vmovaps xmm1, [rsp+0x10]
0000777bb65d20ad  vmovaps xmm3, [rsp+0x20]
0000777bb65d20b3  vmovaps xmm4, [rsp+0x30]
0000777bb65d20b9  vmovaps xmm5, [rsp+0x40]
0000777bb65d20bf  vmovaps xmm6, [rsp+0x50]
0000777bb65d20c5  vmovaps xmm7, [rsp+0x60]
0000777bb65d20cb  vmovaps xmm8, [rsp+0x70]
0000777bb65d20d1  vmovaps xmm9, [rsp+0x80]
0000777bb65d20da  vmovaps xmm10, [rsp+0x90]
0000777bb65d20e3  vmovaps xmm11, [rsp+0xA0]
0000777bb65d20ec  vmovaps xmm12, [rsp+0xB0]
0000777bb65d20f5  vmovaps xmm13, [rsp+0xC0]
0000777bb65d20fe  vmovaps xmm14, [rsp+0xD0]
0000777bb65d2107  vmovaps xmm15, [rsp+0xE0]
0000777bb65d2110  add rsp, 0xF0
0000777bb65d2117  pop r11
0000777bb65d2119  pop r10
0000777bb65d211b  pop r9
0000777bb65d211d  pop r8
0000777bb65d211f  pop rsi
0000777bb65d2120  pop rdi
0000777bb65d2121  pop rdx
0000777bb65d2122  pop rcx
0000777bb65d2123  pop rax
0000777bb65d2124  add rsp, 0x08
0000777bb65d2128  jmp 0x0000777BB65CFBAB
0000777bb65d212d  call 0x0000777BB63FF430
0000777bb65d2132  jmp 0x0000777BB65CFBB8
0000777bb65d2137  sub rsp, 0x08
0000777bb65d213b  push rax
0000777bb65d213c  push rcx
0000777bb65d213d  push rdx
0000777bb65d213e  push rdi
0000777bb65d213f  push rsi
0000777bb65d2140  push r8
0000777bb65d2142  push r9
0000777bb65d2144  push r10
0000777bb65d2146  push r11
0000777bb65d2148  sub rsp, 0xF0
0000777bb65d214f  vmovaps [rsp], xmm0
0000777bb65d2154  vmovaps [rsp+0x10], xmm1
0000777bb65d215a  vmovaps [rsp+0x20], xmm2
0000777bb65d2160  vmovaps [rsp+0x30], xmm3
0000777bb65d2166  vmovaps [rsp+0x40], xmm4
0000777bb65d216c  vmovaps [rsp+0x50], xmm5
0000777bb65d2172  vmovaps [rsp+0x60], xmm6
0000777bb65d2178  vmovaps [rsp+0x70], xmm7
0000777bb65d217e  vmovaps [rsp+0x80], xmm8
0000777bb65d2187  vmovaps [rsp+0x90], xmm9
0000777bb65d2190  vmovaps [rsp+0xA0], xmm10
0000777bb65d2199  vmovaps [rsp+0xB0], xmm11
0000777bb65d21a2  vmovaps [rsp+0xC0], xmm12
0000777bb65d21ab  vmovaps [rsp+0xD0], xmm13
0000777bb65d21b4  vmovaps [rsp+0xE0], xmm14
0000777bb65d21bd  sub rsp, 0x30
0000777bb65d21c1  movaps [rsp], xmm15
0000777bb65d21c6  movaps [rsp+0x10], xmm13
0000777bb65d21cc  movaps [rsp+0x20], xmm1
0000777bb65d21d1  lea rdi, [rsp]
0000777bb65d21d5  mov esi, 0x00
0000777bb65d21da  mov rax, 0x569DC437B530
0000777bb65d21e4  call rax
0000777bb65d21e6  movaps xmm15, [rsp]
0000777bb65d21eb  add rsp, 0x30
0000777bb65d21ef  vmovaps xmm0, [rsp]
0000777bb65d21f4  vmovaps xmm1, [rsp+0x10]
0000777bb65d21fa  vmovaps xmm2, [rsp+0x20]
0000777bb65d2200  vmovaps xmm3, [rsp+0x30]
0000777bb65d2206  vmovaps xmm4, [rsp+0x40]
0000777bb65d220c  vmovaps xmm5, [rsp+0x50]
0000777bb65d2212  vmovaps xmm6, [rsp+0x60]
0000777bb65d2218  vmovaps xmm7, [rsp+0x70]
0000777bb65d221e  vmovaps xmm8, [rsp+0x80]
0000777bb65d2227  vmovaps xmm9, [rsp+0x90]
0000777bb65d2230  vmovaps xmm10, [rsp+0xA0]
0000777bb65d2239  vmovaps xmm11, [rsp+0xB0]
0000777bb65d2242  vmovaps xmm12, [rsp+0xC0]
0000777bb65d224b  vmovaps xmm13, [rsp+0xD0]
0000777bb65d2254  vmovaps xmm14, [rsp+0xE0]
0000777bb65d225d  add rsp, 0xF0
0000777bb65d2264  pop r11
0000777bb65d2266  pop r10
0000777bb65d2268  pop r9
0000777bb65d226a  pop r8
0000777bb65d226c  pop rsi
0000777bb65d226d  pop rdi
0000777bb65d226e  pop rdx
0000777bb65d226f  pop rcx
0000777bb65d2270  pop rax
0000777bb65d2271  add rsp, 0x08
0000777bb65d2275  jmp 0x0000777BB65CFBF7
0000777bb65d227a  sub rsp, 0x08
0000777bb65d227e  push rax
0000777bb65d227f  push rcx
0000777bb65d2280  push rdx
0000777bb65d2281  push rdi
0000777bb65d2282  push rsi
0000777bb65d2283  push r8
0000777bb65d2285  push r9
0000777bb65d2287  push r10
0000777bb65d2289  push r11
0000777bb65d228b  sub rsp, 0xF0
0000777bb65d2292  vmovaps [rsp], xmm0
0000777bb65d2297  vmovaps [rsp+0x10], xmm1
0000777bb65d229d  vmovaps [rsp+0x20], xmm2
0000777bb65d22a3  vmovaps [rsp+0x30], xmm3
0000777bb65d22a9  vmovaps [rsp+0x40], xmm4
0000777bb65d22af  vmovaps [rsp+0x50], xmm5
0000777bb65d22b5  vmovaps [rsp+0x60], xmm6
0000777bb65d22bb  vmovaps [rsp+0x70], xmm7
0000777bb65d22c1  vmovaps [rsp+0x80], xmm8
0000777bb65d22ca  vmovaps [rsp+0x90], xmm9
0000777bb65d22d3  vmovaps [rsp+0xA0], xmm10
0000777bb65d22dc  vmovaps [rsp+0xB0], xmm11
0000777bb65d22e5  vmovaps [rsp+0xC0], xmm12
0000777bb65d22ee  vmovaps [rsp+0xD0], xmm13
0000777bb65d22f7  vmovaps [rsp+0xE0], xmm15
0000777bb65d2300  sub rsp, 0x30
0000777bb65d2304  movaps [rsp], xmm14
0000777bb65d2309  movaps [rsp+0x10], xmm11
0000777bb65d230f  movaps [rsp+0x20], xmm1
0000777bb65d2314  lea rdi, [rsp]
0000777bb65d2318  mov esi, 0x00
0000777bb65d231d  mov rax, 0x569DC437B530
0000777bb65d2327  call rax
0000777bb65d2329  movaps xmm14, [rsp]
0000777bb65d232e  add rsp, 0x30
0000777bb65d2332  vmovaps xmm0, [rsp]
0000777bb65d2337  vmovaps xmm1, [rsp+0x10]
0000777bb65d233d  vmovaps xmm2, [rsp+0x20]
0000777bb65d2343  vmovaps xmm3, [rsp+0x30]
0000777bb65d2349  vmovaps xmm4, [rsp+0x40]
0000777bb65d234f  vmovaps xmm5, [rsp+0x50]
0000777bb65d2355  vmovaps xmm6, [rsp+0x60]
0000777bb65d235b  vmovaps xmm7, [rsp+0x70]
0000777bb65d2361  vmovaps xmm8, [rsp+0x80]
0000777bb65d236a  vmovaps xmm9, [rsp+0x90]
0000777bb65d2373  vmovaps xmm10, [rsp+0xA0]
0000777bb65d237c  vmovaps xmm11, [rsp+0xB0]
0000777bb65d2385  vmovaps xmm12, [rsp+0xC0]
0000777bb65d238e  vmovaps xmm13, [rsp+0xD0]
0000777bb65d2397  vmovaps xmm15, [rsp+0xE0]
0000777bb65d23a0  add rsp, 0xF0
0000777bb65d23a7  pop r11
0000777bb65d23a9  pop r10
0000777bb65d23ab  pop r9
0000777bb65d23ad  pop r8
0000777bb65d23af  pop rsi
0000777bb65d23b0  pop rdi
0000777bb65d23b1  pop rdx
0000777bb65d23b2  pop rcx
0000777bb65d23b3  pop rax
0000777bb65d23b4  add rsp, 0x08
0000777bb65d23b8  jmp 0x0000777BB65CFC21
0000777bb65d23bd  sub rsp, 0x08
0000777bb65d23c1  push rax
0000777bb65d23c2  push rcx
0000777bb65d23c3  push rdx
0000777bb65d23c4  push rdi
0000777bb65d23c5  push rsi
0000777bb65d23c6  push r8
0000777bb65d23c8  push r9
0000777bb65d23ca  push r10
0000777bb65d23cc  push r11
0000777bb65d23ce  sub rsp, 0xF0
0000777bb65d23d5  vmovaps [rsp], xmm0
0000777bb65d23da  vmovaps [rsp+0x10], xmm1
0000777bb65d23e0  vmovaps [rsp+0x20], xmm2
0000777bb65d23e6  vmovaps [rsp+0x30], xmm3
0000777bb65d23ec  vmovaps [rsp+0x40], xmm4
0000777bb65d23f2  vmovaps [rsp+0x50], xmm5
0000777bb65d23f8  vmovaps [rsp+0x60], xmm6
0000777bb65d23fe  vmovaps [rsp+0x70], xmm7
0000777bb65d2404  vmovaps [rsp+0x80], xmm8
0000777bb65d240d  vmovaps [rsp+0x90], xmm9
0000777bb65d2416  vmovaps [rsp+0xA0], xmm10
0000777bb65d241f  vmovaps [rsp+0xB0], xmm11
0000777bb65d2428  vmovaps [rsp+0xC0], xmm12
0000777bb65d2431  vmovaps [rsp+0xD0], xmm14
0000777bb65d243a  vmovaps [rsp+0xE0], xmm15
0000777bb65d2443  sub rsp, 0x30
0000777bb65d2447  movaps [rsp], xmm13
0000777bb65d244c  movaps [rsp+0x10], xmm11
0000777bb65d2452  movaps [rsp+0x20], xmm1
0000777bb65d2457  lea rdi, [rsp]
0000777bb65d245b  mov esi, 0x00
0000777bb65d2460  mov rax, 0x569DC437B530
0000777bb65d246a  call rax
0000777bb65d246c  movaps xmm13, [rsp]
0000777bb65d2471  add rsp, 0x30
0000777bb65d2475  vmovaps xmm0, [rsp]
0000777bb65d247a  vmovaps xmm1, [rsp+0x10]
0000777bb65d2480  vmovaps xmm2, [rsp+0x20]
0000777bb65d2486  vmovaps xmm3, [rsp+0x30]
0000777bb65d248c  vmovaps xmm4, [rsp+0x40]
0000777bb65d2492  vmovaps xmm5, [rsp+0x50]
0000777bb65d2498  vmovaps xmm6, [rsp+0x60]
0000777bb65d249e  vmovaps xmm7, [rsp+0x70]
0000777bb65d24a4  vmovaps xmm8, [rsp+0x80]
0000777bb65d24ad  vmovaps xmm9, [rsp+0x90]
0000777bb65d24b6  vmovaps xmm10, [rsp+0xA0]
0000777bb65d24bf  vmovaps xmm11, [rsp+0xB0]
0000777bb65d24c8  vmovaps xmm12, [rsp+0xC0]
0000777bb65d24d1  vmovaps xmm14, [rsp+0xD0]
0000777bb65d24da  vmovaps xmm15, [rsp+0xE0]
0000777bb65d24e3  add rsp, 0xF0
0000777bb65d24ea  pop r11
0000777bb65d24ec  pop r10
0000777bb65d24ee  pop r9
0000777bb65d24f0  pop r8
0000777bb65d24f2  pop rsi
0000777bb65d24f3  pop rdi
0000777bb65d24f4  pop rdx
0000777bb65d24f5  pop rcx
0000777bb65d24f6  pop rax
0000777bb65d24f7  add rsp, 0x08
0000777bb65d24fb  jmp 0x0000777BB65CFC76
0000777bb65d2500  call 0x0000777BB63FF430
0000777bb65d2505  jmp 0x0000777BB65CFC83
0000777bb65d250a  sub rsp, 0x08
0000777bb65d250e  push rax
0000777bb65d250f  push rcx
0000777bb65d2510  push rdx
0000777bb65d2511  push rdi
0000777bb65d2512  push rsi
0000777bb65d2513  push r8
0000777bb65d2515  push r9
0000777bb65d2517  push r10
0000777bb65d2519  push r11
0000777bb65d251b  sub rsp, 0xF0
0000777bb65d2522  vmovaps [rsp], xmm0
0000777bb65d2527  vmovaps [rsp+0x10], xmm1
0000777bb65d252d  vmovaps [rsp+0x20], xmm2
0000777bb65d2533  vmovaps [rsp+0x30], xmm3
0000777bb65d2539  vmovaps [rsp+0x40], xmm4
0000777bb65d253f  vmovaps [rsp+0x50], xmm5
0000777bb65d2545  vmovaps [rsp+0x60], xmm6
0000777bb65d254b  vmovaps [rsp+0x70], xmm7
0000777bb65d2551  vmovaps [rsp+0x80], xmm8
0000777bb65d255a  vmovaps [rsp+0x90], xmm9
0000777bb65d2563  vmovaps [rsp+0xA0], xmm10
0000777bb65d256c  vmovaps [rsp+0xB0], xmm11
0000777bb65d2575  vmovaps [rsp+0xC0], xmm12
0000777bb65d257e  vmovaps [rsp+0xD0], xmm13
0000777bb65d2587  vmovaps [rsp+0xE0], xmm14
0000777bb65d2590  sub rsp, 0x30
0000777bb65d2594  movaps [rsp], xmm15
0000777bb65d2599  movaps [rsp+0x10], xmm11
0000777bb65d259f  movaps [rsp+0x20], xmm1
0000777bb65d25a4  lea rdi, [rsp]
0000777bb65d25a8  mov esi, 0x00
0000777bb65d25ad  mov rax, 0x569DC437B530
0000777bb65d25b7  call rax
0000777bb65d25b9  movaps xmm15, [rsp]
0000777bb65d25be  add rsp, 0x30
0000777bb65d25c2  vmovaps xmm0, [rsp]
0000777bb65d25c7  vmovaps xmm1, [rsp+0x10]
0000777bb65d25cd  vmovaps xmm2, [rsp+0x20]
0000777bb65d25d3  vmovaps xmm3, [rsp+0x30]
0000777bb65d25d9  vmovaps xmm4, [rsp+0x40]
0000777bb65d25df  vmovaps xmm5, [rsp+0x50]
0000777bb65d25e5  vmovaps xmm6, [rsp+0x60]
0000777bb65d25eb  vmovaps xmm7, [rsp+0x70]
0000777bb65d25f1  vmovaps xmm8, [rsp+0x80]
0000777bb65d25fa  vmovaps xmm9, [rsp+0x90]
0000777bb65d2603  vmovaps xmm10, [rsp+0xA0]
0000777bb65d260c  vmovaps xmm11, [rsp+0xB0]
0000777bb65d2615  vmovaps xmm12, [rsp+0xC0]
0000777bb65d261e  vmovaps xmm13, [rsp+0xD0]
0000777bb65d2627  vmovaps xmm14, [rsp+0xE0]
0000777bb65d2630  add rsp, 0xF0
0000777bb65d2637  pop r11
0000777bb65d2639  pop r10
0000777bb65d263b  pop r9
0000777bb65d263d  pop r8
0000777bb65d263f  pop rsi
0000777bb65d2640  pop rdi
0000777bb65d2641  pop rdx
0000777bb65d2642  pop rcx
0000777bb65d2643  pop rax
0000777bb65d2644  add rsp, 0x08
0000777bb65d2648  jmp 0x0000777BB65CFCBC
0000777bb65d264d  sub rsp, 0x08
0000777bb65d2651  push rax
0000777bb65d2652  push rcx
0000777bb65d2653  push rdx
0000777bb65d2654  push rdi
0000777bb65d2655  push rsi
0000777bb65d2656  push r8
0000777bb65d2658  push r9
0000777bb65d265a  push r10
0000777bb65d265c  push r11
0000777bb65d265e  sub rsp, 0xF0
0000777bb65d2665  vmovaps [rsp], xmm0
0000777bb65d266a  vmovaps [rsp+0x10], xmm1
0000777bb65d2670  vmovaps [rsp+0x20], xmm2
0000777bb65d2676  vmovaps [rsp+0x30], xmm3
0000777bb65d267c  vmovaps [rsp+0x40], xmm4
0000777bb65d2682  vmovaps [rsp+0x50], xmm5
0000777bb65d2688  vmovaps [rsp+0x60], xmm6
0000777bb65d268e  vmovaps [rsp+0x70], xmm7
0000777bb65d2694  vmovaps [rsp+0x80], xmm8
0000777bb65d269d  vmovaps [rsp+0x90], xmm9
0000777bb65d26a6  vmovaps [rsp+0xA0], xmm10
0000777bb65d26af  vmovaps [rsp+0xB0], xmm12
0000777bb65d26b8  vmovaps [rsp+0xC0], xmm13
0000777bb65d26c1  vmovaps [rsp+0xD0], xmm14
0000777bb65d26ca  vmovaps [rsp+0xE0], xmm15
0000777bb65d26d3  sub rsp, 0x30
0000777bb65d26d7  movaps [rsp], xmm11
0000777bb65d26dc  movaps [rsp+0x10], xmm6
0000777bb65d26e1  movaps [rsp+0x20], xmm14
0000777bb65d26e7  lea rdi, [rsp]
0000777bb65d26eb  mov esi, 0x00
0000777bb65d26f0  mov rax, 0x569DC437B530
0000777bb65d26fa  call rax
0000777bb65d26fc  movaps xmm11, [rsp]
0000777bb65d2701  add rsp, 0x30
0000777bb65d2705  vmovaps xmm0, [rsp]
0000777bb65d270a  vmovaps xmm1, [rsp+0x10]
0000777bb65d2710  vmovaps xmm2, [rsp+0x20]
0000777bb65d2716  vmovaps xmm3, [rsp+0x30]
0000777bb65d271c  vmovaps xmm4, [rsp+0x40]
0000777bb65d2722  vmovaps xmm5, [rsp+0x50]
0000777bb65d2728  vmovaps xmm6, [rsp+0x60]
0000777bb65d272e  vmovaps xmm7, [rsp+0x70]
0000777bb65d2734  vmovaps xmm8, [rsp+0x80]
0000777bb65d273d  vmovaps xmm9, [rsp+0x90]
0000777bb65d2746  vmovaps xmm10, [rsp+0xA0]
0000777bb65d274f  vmovaps xmm12, [rsp+0xB0]
0000777bb65d2758  vmovaps xmm13, [rsp+0xC0]
0000777bb65d2761  vmovaps xmm14, [rsp+0xD0]
0000777bb65d276a  vmovaps xmm15, [rsp+0xE0]
0000777bb65d2773  add rsp, 0xF0
0000777bb65d277a  pop r11
0000777bb65d277c  pop r10
0000777bb65d277e  pop r9
0000777bb65d2780  pop r8
0000777bb65d2782  pop rsi
0000777bb65d2783  pop rdi
0000777bb65d2784  pop rdx
0000777bb65d2785  pop rcx
0000777bb65d2786  pop rax
0000777bb65d2787  add rsp, 0x08
0000777bb65d278b  jmp 0x0000777BB65CFD34
0000777bb65d2790  call 0x0000777BB63FF430
0000777bb65d2795  jmp 0x0000777BB65CFD3E
0000777bb65d279a  sub rsp, 0x08
0000777bb65d279e  push rax
0000777bb65d279f  push rcx
0000777bb65d27a0  push rdx
0000777bb65d27a1  push rdi
0000777bb65d27a2  push rsi
0000777bb65d27a3  push r8
0000777bb65d27a5  push r9
0000777bb65d27a7  push r10
0000777bb65d27a9  push r11
0000777bb65d27ab  sub rsp, 0xF0
0000777bb65d27b2  vmovaps [rsp], xmm0
0000777bb65d27b7  vmovaps [rsp+0x10], xmm1
0000777bb65d27bd  vmovaps [rsp+0x20], xmm2
0000777bb65d27c3  vmovaps [rsp+0x30], xmm3
0000777bb65d27c9  vmovaps [rsp+0x40], xmm4
0000777bb65d27cf  vmovaps [rsp+0x50], xmm5
0000777bb65d27d5  vmovaps [rsp+0x60], xmm6
0000777bb65d27db  vmovaps [rsp+0x70], xmm7
0000777bb65d27e1  vmovaps [rsp+0x80], xmm8
0000777bb65d27ea  vmovaps [rsp+0x90], xmm9
0000777bb65d27f3  vmovaps [rsp+0xA0], xmm10
0000777bb65d27fc  vmovaps [rsp+0xB0], xmm11
0000777bb65d2805  vmovaps [rsp+0xC0], xmm12
0000777bb65d280e  vmovaps [rsp+0xD0], xmm13
0000777bb65d2817  vmovaps [rsp+0xE0], xmm15
0000777bb65d2820  sub rsp, 0x30
0000777bb65d2824  movaps [rsp], xmm14
0000777bb65d2829  movaps [rsp+0x10], xmm6
0000777bb65d282e  movaps [rsp+0x20], xmm2
0000777bb65d2833  lea rdi, [rsp]
0000777bb65d2837  mov esi, 0x00
0000777bb65d283c  mov rax, 0x569DC437B530
0000777bb65d2846  call rax
0000777bb65d2848  movaps xmm14, [rsp]
0000777bb65d284d  add rsp, 0x30
0000777bb65d2851  vmovaps xmm0, [rsp]
0000777bb65d2856  vmovaps xmm1, [rsp+0x10]
0000777bb65d285c  vmovaps xmm2, [rsp+0x20]
0000777bb65d2862  vmovaps xmm3, [rsp+0x30]
0000777bb65d2868  vmovaps xmm4, [rsp+0x40]
0000777bb65d286e  vmovaps xmm5, [rsp+0x50]
0000777bb65d2874  vmovaps xmm6, [rsp+0x60]
0000777bb65d287a  vmovaps xmm7, [rsp+0x70]
0000777bb65d2880  vmovaps xmm8, [rsp+0x80]
0000777bb65d2889  vmovaps xmm9, [rsp+0x90]
0000777bb65d2892  vmovaps xmm10, [rsp+0xA0]
0000777bb65d289b  vmovaps xmm11, [rsp+0xB0]
0000777bb65d28a4  vmovaps xmm12, [rsp+0xC0]
0000777bb65d28ad  vmovaps xmm13, [rsp+0xD0]
0000777bb65d28b6  vmovaps xmm15, [rsp+0xE0]
0000777bb65d28bf  add rsp, 0xF0
0000777bb65d28c6  pop r11
0000777bb65d28c8  pop r10
0000777bb65d28ca  pop r9
0000777bb65d28cc  pop r8
0000777bb65d28ce  pop rsi
0000777bb65d28cf  pop rdi
0000777bb65d28d0  pop rdx
0000777bb65d28d1  pop rcx
0000777bb65d28d2  pop rax
0000777bb65d28d3  add rsp, 0x08
0000777bb65d28d7  jmp 0x0000777BB65CFD72
0000777bb65d28dc  sub rsp, 0x08
0000777bb65d28e0  push rax
0000777bb65d28e1  push rcx
0000777bb65d28e2  push rdx
0000777bb65d28e3  push rdi
0000777bb65d28e4  push rsi
0000777bb65d28e5  push r8
0000777bb65d28e7  push r9
0000777bb65d28e9  push r10
0000777bb65d28eb  push r11
0000777bb65d28ed  sub rsp, 0xF0
0000777bb65d28f4  vmovaps [rsp], xmm0
0000777bb65d28f9  vmovaps [rsp+0x10], xmm1
0000777bb65d28ff  vmovaps [rsp+0x20], xmm2
0000777bb65d2905  vmovaps [rsp+0x30], xmm3
0000777bb65d290b  vmovaps [rsp+0x40], xmm4
0000777bb65d2911  vmovaps [rsp+0x50], xmm5
0000777bb65d2917  vmovaps [rsp+0x60], xmm7
0000777bb65d291d  vmovaps [rsp+0x70], xmm8
0000777bb65d2923  vmovaps [rsp+0x80], xmm9
0000777bb65d292c  vmovaps [rsp+0x90], xmm10
0000777bb65d2935  vmovaps [rsp+0xA0], xmm11
0000777bb65d293e  vmovaps [rsp+0xB0], xmm12
0000777bb65d2947  vmovaps [rsp+0xC0], xmm13
0000777bb65d2950  vmovaps [rsp+0xD0], xmm14
0000777bb65d2959  vmovaps [rsp+0xE0], xmm15
0000777bb65d2962  sub rsp, 0x30
0000777bb65d2966  movaps [rsp], xmm6
0000777bb65d296a  movaps [rsp+0x10], xmm5
0000777bb65d296f  movaps [rsp+0x20], xmm1
0000777bb65d2974  lea rdi, [rsp]
0000777bb65d2978  mov esi, 0x00
0000777bb65d297d  mov rax, 0x569DC437B530
0000777bb65d2987  call rax
0000777bb65d2989  movaps xmm6, [rsp]
0000777bb65d298d  add rsp, 0x30
0000777bb65d2991  vmovaps xmm0, [rsp]
0000777bb65d2996  vmovaps xmm1, [rsp+0x10]
0000777bb65d299c  vmovaps xmm2, [rsp+0x20]
0000777bb65d29a2  vmovaps xmm3, [rsp+0x30]
0000777bb65d29a8  vmovaps xmm4, [rsp+0x40]
0000777bb65d29ae  vmovaps xmm5, [rsp+0x50]
0000777bb65d29b4  vmovaps xmm7, [rsp+0x60]
0000777bb65d29ba  vmovaps xmm8, [rsp+0x70]
0000777bb65d29c0  vmovaps xmm9, [rsp+0x80]
0000777bb65d29c9  vmovaps xmm10, [rsp+0x90]
0000777bb65d29d2  vmovaps xmm11, [rsp+0xA0]
0000777bb65d29db  vmovaps xmm12, [rsp+0xB0]
0000777bb65d29e4  vmovaps xmm13, [rsp+0xC0]
0000777bb65d29ed  vmovaps xmm14, [rsp+0xD0]
0000777bb65d29f6  vmovaps xmm15, [rsp+0xE0]
0000777bb65d29ff  add rsp, 0xF0
0000777bb65d2a06  pop r11
0000777bb65d2a08  pop r10
0000777bb65d2a0a  pop r9
0000777bb65d2a0c  pop r8
0000777bb65d2a0e  pop rsi
0000777bb65d2a0f  pop rdi
0000777bb65d2a10  pop rdx
0000777bb65d2a11  pop rcx
0000777bb65d2a12  pop rax
0000777bb65d2a13  add rsp, 0x08
0000777bb65d2a17  jmp 0x0000777BB65CFD98
0000777bb65d2a1c  sub rsp, 0x08
0000777bb65d2a20  push rax
0000777bb65d2a21  push rcx
0000777bb65d2a22  push rdx
0000777bb65d2a23  push rdi
0000777bb65d2a24  push rsi
0000777bb65d2a25  push r8
0000777bb65d2a27  push r9
0000777bb65d2a29  push r10
0000777bb65d2a2b  push r11
0000777bb65d2a2d  sub rsp, 0xF0
0000777bb65d2a34  vmovaps [rsp], xmm0
0000777bb65d2a39  vmovaps [rsp+0x10], xmm2
0000777bb65d2a3f  vmovaps [rsp+0x20], xmm3
0000777bb65d2a45  vmovaps [rsp+0x30], xmm4
0000777bb65d2a4b  vmovaps [rsp+0x40], xmm5
0000777bb65d2a51  vmovaps [rsp+0x50], xmm6
0000777bb65d2a57  vmovaps [rsp+0x60], xmm7
0000777bb65d2a5d  vmovaps [rsp+0x70], xmm8
0000777bb65d2a63  vmovaps [rsp+0x80], xmm9
0000777bb65d2a6c  vmovaps [rsp+0x90], xmm10
0000777bb65d2a75  vmovaps [rsp+0xA0], xmm11
0000777bb65d2a7e  vmovaps [rsp+0xB0], xmm12
0000777bb65d2a87  vmovaps [rsp+0xC0], xmm13
0000777bb65d2a90  vmovaps [rsp+0xD0], xmm14
0000777bb65d2a99  vmovaps [rsp+0xE0], xmm15
0000777bb65d2aa2  sub rsp, 0x30
0000777bb65d2aa6  movaps [rsp], xmm1
0000777bb65d2aaa  movaps [rsp+0x10], xmm5
0000777bb65d2aaf  movaps [rsp+0x20], xmm13
0000777bb65d2ab5  lea rdi, [rsp]
0000777bb65d2ab9  mov esi, 0x00
0000777bb65d2abe  mov rax, 0x569DC437B530
0000777bb65d2ac8  call rax
0000777bb65d2aca  movaps xmm1, [rsp]
0000777bb65d2ace  add rsp, 0x30
0000777bb65d2ad2  vmovaps xmm0, [rsp]
0000777bb65d2ad7  vmovaps xmm2, [rsp+0x10]
0000777bb65d2add  vmovaps xmm3, [rsp+0x20]
0000777bb65d2ae3  vmovaps xmm4, [rsp+0x30]
0000777bb65d2ae9  vmovaps xmm5, [rsp+0x40]
0000777bb65d2aef  vmovaps xmm6, [rsp+0x50]
0000777bb65d2af5  vmovaps xmm7, [rsp+0x60]
0000777bb65d2afb  vmovaps xmm8, [rsp+0x70]
0000777bb65d2b01  vmovaps xmm9, [rsp+0x80]
0000777bb65d2b0a  vmovaps xmm10, [rsp+0x90]
0000777bb65d2b13  vmovaps xmm11, [rsp+0xA0]
0000777bb65d2b1c  vmovaps xmm12, [rsp+0xB0]
0000777bb65d2b25  vmovaps xmm13, [rsp+0xC0]
0000777bb65d2b2e  vmovaps xmm14, [rsp+0xD0]
0000777bb65d2b37  vmovaps xmm15, [rsp+0xE0]
0000777bb65d2b40  add rsp, 0xF0
0000777bb65d2b47  pop r11
0000777bb65d2b49  pop r10
0000777bb65d2b4b  pop r9
0000777bb65d2b4d  pop r8
0000777bb65d2b4f  pop rsi
0000777bb65d2b50  pop rdi
0000777bb65d2b51  pop rdx
0000777bb65d2b52  pop rcx
0000777bb65d2b53  pop rax
0000777bb65d2b54  add rsp, 0x08
0000777bb65d2b58  jmp 0x0000777BB65CFDB6
0000777bb65d2b5d  sub rsp, 0x08
0000777bb65d2b61  push rax
0000777bb65d2b62  push rcx
0000777bb65d2b63  push rdx
0000777bb65d2b64  push rdi
0000777bb65d2b65  push rsi
0000777bb65d2b66  push r8
0000777bb65d2b68  push r9
0000777bb65d2b6a  push r10
0000777bb65d2b6c  push r11
0000777bb65d2b6e  sub rsp, 0xF0
0000777bb65d2b75  vmovaps [rsp], xmm0
0000777bb65d2b7a  vmovaps [rsp+0x10], xmm1
0000777bb65d2b80  vmovaps [rsp+0x20], xmm2
0000777bb65d2b86  vmovaps [rsp+0x30], xmm3
0000777bb65d2b8c  vmovaps [rsp+0x40], xmm4
0000777bb65d2b92  vmovaps [rsp+0x50], xmm6
0000777bb65d2b98  vmovaps [rsp+0x60], xmm7
0000777bb65d2b9e  vmovaps [rsp+0x70], xmm8
0000777bb65d2ba4  vmovaps [rsp+0x80], xmm9
0000777bb65d2bad  vmovaps [rsp+0x90], xmm10
0000777bb65d2bb6  vmovaps [rsp+0xA0], xmm11
0000777bb65d2bbf  vmovaps [rsp+0xB0], xmm12
0000777bb65d2bc8  vmovaps [rsp+0xC0], xmm13
0000777bb65d2bd1  vmovaps [rsp+0xD0], xmm14
0000777bb65d2bda  vmovaps [rsp+0xE0], xmm15
0000777bb65d2be3  sub rsp, 0x30
0000777bb65d2be7  movaps [rsp], xmm5
0000777bb65d2beb  movaps [rsp+0x10], xmm2
0000777bb65d2bf0  movaps [rsp+0x20], xmm13
0000777bb65d2bf6  lea rdi, [rsp]
0000777bb65d2bfa  mov esi, 0x00
0000777bb65d2bff  mov rax, 0x569DC437B530
0000777bb65d2c09  call rax
0000777bb65d2c0b  movaps xmm5, [rsp]
0000777bb65d2c0f  add rsp, 0x30
0000777bb65d2c13  vmovaps xmm0, [rsp]
0000777bb65d2c18  vmovaps xmm1, [rsp+0x10]
0000777bb65d2c1e  vmovaps xmm2, [rsp+0x20]
0000777bb65d2c24  vmovaps xmm3, [rsp+0x30]
0000777bb65d2c2a  vmovaps xmm4, [rsp+0x40]
0000777bb65d2c30  vmovaps xmm6, [rsp+0x50]
0000777bb65d2c36  vmovaps xmm7, [rsp+0x60]
0000777bb65d2c3c  vmovaps xmm8, [rsp+0x70]
0000777bb65d2c42  vmovaps xmm9, [rsp+0x80]
0000777bb65d2c4b  vmovaps xmm10, [rsp+0x90]
0000777bb65d2c54  vmovaps xmm11, [rsp+0xA0]
0000777bb65d2c5d  vmovaps xmm12, [rsp+0xB0]
0000777bb65d2c66  vmovaps xmm13, [rsp+0xC0]
0000777bb65d2c6f  vmovaps xmm14, [rsp+0xD0]
0000777bb65d2c78  vmovaps xmm15, [rsp+0xE0]
0000777bb65d2c81  add rsp, 0xF0
0000777bb65d2c88  pop r11
0000777bb65d2c8a  pop r10
0000777bb65d2c8c  pop r9
0000777bb65d2c8e  pop r8
0000777bb65d2c90  pop rsi
0000777bb65d2c91  pop rdi
0000777bb65d2c92  pop rdx
0000777bb65d2c93  pop rcx
0000777bb65d2c94  pop rax
0000777bb65d2c95  add rsp, 0x08
0000777bb65d2c99  jmp 0x0000777BB65CFDEC
0000777bb65d2c9e  sub rsp, 0x08
0000777bb65d2ca2  push rax
0000777bb65d2ca3  push rcx
0000777bb65d2ca4  push rdx
0000777bb65d2ca5  push rdi
0000777bb65d2ca6  push rsi
0000777bb65d2ca7  push r8
0000777bb65d2ca9  push r9
0000777bb65d2cab  push r10
0000777bb65d2cad  push r11
0000777bb65d2caf  sub rsp, 0xF0
0000777bb65d2cb6  vmovaps [rsp], xmm0
0000777bb65d2cbb  vmovaps [rsp+0x10], xmm1
0000777bb65d2cc1  vmovaps [rsp+0x20], xmm2
0000777bb65d2cc7  vmovaps [rsp+0x30], xmm3
0000777bb65d2ccd  vmovaps [rsp+0x40], xmm4
0000777bb65d2cd3  vmovaps [rsp+0x50], xmm5
0000777bb65d2cd9  vmovaps [rsp+0x60], xmm6
0000777bb65d2cdf  vmovaps [rsp+0x70], xmm7
0000777bb65d2ce5  vmovaps [rsp+0x80], xmm8
0000777bb65d2cee  vmovaps [rsp+0x90], xmm9
0000777bb65d2cf7  vmovaps [rsp+0xA0], xmm10
0000777bb65d2d00  vmovaps [rsp+0xB0], xmm11
0000777bb65d2d09  vmovaps [rsp+0xC0], xmm12
0000777bb65d2d12  vmovaps [rsp+0xD0], xmm14
0000777bb65d2d1b  vmovaps [rsp+0xE0], xmm15
0000777bb65d2d24  sub rsp, 0x30
0000777bb65d2d28  movaps [rsp], xmm13
0000777bb65d2d2d  movaps [rsp+0x10], xmm10
0000777bb65d2d33  movaps [rsp+0x20], xmm1
0000777bb65d2d38  lea rdi, [rsp]
0000777bb65d2d3c  mov esi, 0x00
0000777bb65d2d41  mov rax, 0x569DC437B530
0000777bb65d2d4b  call rax
0000777bb65d2d4d  movaps xmm13, [rsp]
0000777bb65d2d52  add rsp, 0x30
0000777bb65d2d56  vmovaps xmm0, [rsp]
0000777bb65d2d5b  vmovaps xmm1, [rsp+0x10]
0000777bb65d2d61  vmovaps xmm2, [rsp+0x20]
0000777bb65d2d67  vmovaps xmm3, [rsp+0x30]
0000777bb65d2d6d  vmovaps xmm4, [rsp+0x40]
0000777bb65d2d73  vmovaps xmm5, [rsp+0x50]
0000777bb65d2d79  vmovaps xmm6, [rsp+0x60]
0000777bb65d2d7f  vmovaps xmm7, [rsp+0x70]
0000777bb65d2d85  vmovaps xmm8, [rsp+0x80]
0000777bb65d2d8e  vmovaps xmm9, [rsp+0x90]
0000777bb65d2d97  vmovaps xmm10, [rsp+0xA0]
0000777bb65d2da0  vmovaps xmm11, [rsp+0xB0]
0000777bb65d2da9  vmovaps xmm12, [rsp+0xC0]
0000777bb65d2db2  vmovaps xmm14, [rsp+0xD0]
0000777bb65d2dbb  vmovaps xmm15, [rsp+0xE0]
0000777bb65d2dc4  add rsp, 0xF0
0000777bb65d2dcb  pop r11
0000777bb65d2dcd  pop r10
0000777bb65d2dcf  pop r9
0000777bb65d2dd1  pop r8
0000777bb65d2dd3  pop rsi
0000777bb65d2dd4  pop rdi
0000777bb65d2dd5  pop rdx
0000777bb65d2dd6  pop rcx
0000777bb65d2dd7  pop rax
0000777bb65d2dd8  add rsp, 0x08
0000777bb65d2ddc  jmp 0x0000777BB65CFE15
0000777bb65d2de1  sub rsp, 0x08
0000777bb65d2de5  push rax
0000777bb65d2de6  push rcx
0000777bb65d2de7  push rdx
0000777bb65d2de8  push rdi
0000777bb65d2de9  push rsi
0000777bb65d2dea  push r8
0000777bb65d2dec  push r9
0000777bb65d2dee  push r10
0000777bb65d2df0  push r11
0000777bb65d2df2  sub rsp, 0xF0
0000777bb65d2df9  vmovaps [rsp], xmm0
0000777bb65d2dfe  vmovaps [rsp+0x10], xmm2
0000777bb65d2e04  vmovaps [rsp+0x20], xmm3
0000777bb65d2e0a  vmovaps [rsp+0x30], xmm4
0000777bb65d2e10  vmovaps [rsp+0x40], xmm5
0000777bb65d2e16  vmovaps [rsp+0x50], xmm6
0000777bb65d2e1c  vmovaps [rsp+0x60], xmm7
0000777bb65d2e22  vmovaps [rsp+0x70], xmm8
0000777bb65d2e28  vmovaps [rsp+0x80], xmm9
0000777bb65d2e31  vmovaps [rsp+0x90], xmm10
0000777bb65d2e3a  vmovaps [rsp+0xA0], xmm11
0000777bb65d2e43  vmovaps [rsp+0xB0], xmm12
0000777bb65d2e4c  vmovaps [rsp+0xC0], xmm13
0000777bb65d2e55  vmovaps [rsp+0xD0], xmm14
0000777bb65d2e5e  vmovaps [rsp+0xE0], xmm15
0000777bb65d2e67  sub rsp, 0x30
0000777bb65d2e6b  movaps [rsp], xmm1
0000777bb65d2e6f  movaps [rsp+0x10], xmm15
0000777bb65d2e75  movaps [rsp+0x20], xmm10
0000777bb65d2e7b  lea rdi, [rsp]
0000777bb65d2e7f  mov esi, 0x00
0000777bb65d2e84  mov rax, 0x569DC437B530
0000777bb65d2e8e  call rax
0000777bb65d2e90  movaps xmm1, [rsp]
0000777bb65d2e94  add rsp, 0x30
0000777bb65d2e98  vmovaps xmm0, [rsp]
0000777bb65d2e9d  vmovaps xmm2, [rsp+0x10]
0000777bb65d2ea3  vmovaps xmm3, [rsp+0x20]
0000777bb65d2ea9  vmovaps xmm4, [rsp+0x30]
0000777bb65d2eaf  vmovaps xmm5, [rsp+0x40]
0000777bb65d2eb5  vmovaps xmm6, [rsp+0x50]
0000777bb65d2ebb  vmovaps xmm7, [rsp+0x60]
0000777bb65d2ec1  vmovaps xmm8, [rsp+0x70]
0000777bb65d2ec7  vmovaps xmm9, [rsp+0x80]
0000777bb65d2ed0  vmovaps xmm10, [rsp+0x90]
0000777bb65d2ed9  vmovaps xmm11, [rsp+0xA0]
0000777bb65d2ee2  vmovaps xmm12, [rsp+0xB0]
0000777bb65d2eeb  vmovaps xmm13, [rsp+0xC0]
0000777bb65d2ef4  vmovaps xmm14, [rsp+0xD0]
0000777bb65d2efd  vmovaps xmm15, [rsp+0xE0]
0000777bb65d2f06  add rsp, 0xF0
0000777bb65d2f0d  pop r11
0000777bb65d2f0f  pop r10
0000777bb65d2f11  pop r9
0000777bb65d2f13  pop r8
0000777bb65d2f15  pop rsi
0000777bb65d2f16  pop rdi
0000777bb65d2f17  pop rdx
0000777bb65d2f18  pop rcx
0000777bb65d2f19  pop rax
0000777bb65d2f1a  add rsp, 0x08
0000777bb65d2f1e  jmp 0x0000777BB65CFE34
0000777bb65d2f23  sub rsp, 0x08
0000777bb65d2f27  push rax
0000777bb65d2f28  push rcx
0000777bb65d2f29  push rdx
0000777bb65d2f2a  push rdi
0000777bb65d2f2b  push rsi
0000777bb65d2f2c  push r8
0000777bb65d2f2e  push r9
0000777bb65d2f30  push r10
0000777bb65d2f32  push r11
0000777bb65d2f34  sub rsp, 0xF0
0000777bb65d2f3b  vmovaps [rsp], xmm0
0000777bb65d2f40  vmovaps [rsp+0x10], xmm1
0000777bb65d2f46  vmovaps [rsp+0x20], xmm2
0000777bb65d2f4c  vmovaps [rsp+0x30], xmm3
0000777bb65d2f52  vmovaps [rsp+0x40], xmm4
0000777bb65d2f58  vmovaps [rsp+0x50], xmm5
0000777bb65d2f5e  vmovaps [rsp+0x60], xmm6
0000777bb65d2f64  vmovaps [rsp+0x70], xmm7
0000777bb65d2f6a  vmovaps [rsp+0x80], xmm8
0000777bb65d2f73  vmovaps [rsp+0x90], xmm9
0000777bb65d2f7c  vmovaps [rsp+0xA0], xmm10
0000777bb65d2f85  vmovaps [rsp+0xB0], xmm11
0000777bb65d2f8e  vmovaps [rsp+0xC0], xmm12
0000777bb65d2f97  vmovaps [rsp+0xD0], xmm13
0000777bb65d2fa0  vmovaps [rsp+0xE0], xmm14
0000777bb65d2fa9  sub rsp, 0x30
0000777bb65d2fad  movaps [rsp], xmm15
0000777bb65d2fb2  movaps [rsp+0x10], xmm10
0000777bb65d2fb8  movaps [rsp+0x20], xmm11
0000777bb65d2fbe  lea rdi, [rsp]
0000777bb65d2fc2  mov esi, 0x00
0000777bb65d2fc7  mov rax, 0x569DC437B530
0000777bb65d2fd1  call rax
0000777bb65d2fd3  movaps xmm15, [rsp]
0000777bb65d2fd8  add rsp, 0x30
0000777bb65d2fdc  vmovaps xmm0, [rsp]
0000777bb65d2fe1  vmovaps xmm1, [rsp+0x10]
0000777bb65d2fe7  vmovaps xmm2, [rsp+0x20]
0000777bb65d2fed  vmovaps xmm3, [rsp+0x30]
0000777bb65d2ff3  vmovaps xmm4, [rsp+0x40]
0000777bb65d2ff9  vmovaps xmm5, [rsp+0x50]
0000777bb65d2fff  vmovaps xmm6, [rsp+0x60]
0000777bb65d3005  vmovaps xmm7, [rsp+0x70]
0000777bb65d300b  vmovaps xmm8, [rsp+0x80]
0000777bb65d3014  vmovaps xmm9, [rsp+0x90]
0000777bb65d301d  vmovaps xmm10, [rsp+0xA0]
0000777bb65d3026  vmovaps xmm11, [rsp+0xB0]
0000777bb65d302f  vmovaps xmm12, [rsp+0xC0]
0000777bb65d3038  vmovaps xmm13, [rsp+0xD0]
0000777bb65d3041  vmovaps xmm14, [rsp+0xE0]
0000777bb65d304a  add rsp, 0xF0
0000777bb65d3051  pop r11
0000777bb65d3053  pop r10
0000777bb65d3055  pop r9
0000777bb65d3057  pop r8
0000777bb65d3059  pop rsi
0000777bb65d305a  pop rdi
0000777bb65d305b  pop rdx
0000777bb65d305c  pop rcx
0000777bb65d305d  pop rax
0000777bb65d305e  add rsp, 0x08
0000777bb65d3062  jmp 0x0000777BB65CFE57
0000777bb65d3067  sub rsp, 0x08
0000777bb65d306b  push rax
0000777bb65d306c  push rcx
0000777bb65d306d  push rdx
0000777bb65d306e  push rdi
0000777bb65d306f  push rsi
0000777bb65d3070  push r8
0000777bb65d3072  push r9
0000777bb65d3074  push r10
0000777bb65d3076  push r11
0000777bb65d3078  sub rsp, 0xF0
0000777bb65d307f  vmovaps [rsp], xmm0
0000777bb65d3084  vmovaps [rsp+0x10], xmm1
0000777bb65d308a  vmovaps [rsp+0x20], xmm2
0000777bb65d3090  vmovaps [rsp+0x30], xmm3
0000777bb65d3096  vmovaps [rsp+0x40], xmm4
0000777bb65d309c  vmovaps [rsp+0x50], xmm5
0000777bb65d30a2  vmovaps [rsp+0x60], xmm6
0000777bb65d30a8  vmovaps [rsp+0x70], xmm7
0000777bb65d30ae  vmovaps [rsp+0x80], xmm8
0000777bb65d30b7  vmovaps [rsp+0x90], xmm9
0000777bb65d30c0  vmovaps [rsp+0xA0], xmm11
0000777bb65d30c9  vmovaps [rsp+0xB0], xmm12
0000777bb65d30d2  vmovaps [rsp+0xC0], xmm13
0000777bb65d30db  vmovaps [rsp+0xD0], xmm14
0000777bb65d30e4  vmovaps [rsp+0xE0], xmm15
0000777bb65d30ed  sub rsp, 0x30
0000777bb65d30f1  movaps [rsp], xmm10
0000777bb65d30f6  movaps [rsp+0x10], xmm12
0000777bb65d30fc  movaps [rsp+0x20], xmm11
0000777bb65d3102  lea rdi, [rsp]
0000777bb65d3106  mov esi, 0x00
0000777bb65d310b  mov rax, 0x569DC437B530
0000777bb65d3115  call rax
0000777bb65d3117  movaps xmm10, [rsp]
0000777bb65d311c  add rsp, 0x30
0000777bb65d3120  vmovaps xmm0, [rsp]
0000777bb65d3125  vmovaps xmm1, [rsp+0x10]
0000777bb65d312b  vmovaps xmm2, [rsp+0x20]
0000777bb65d3131  vmovaps xmm3, [rsp+0x30]
0000777bb65d3137  vmovaps xmm4, [rsp+0x40]
0000777bb65d313d  vmovaps xmm5, [rsp+0x50]
0000777bb65d3143  vmovaps xmm6, [rsp+0x60]
0000777bb65d3149  vmovaps xmm7, [rsp+0x70]
0000777bb65d314f  vmovaps xmm8, [rsp+0x80]
0000777bb65d3158  vmovaps xmm9, [rsp+0x90]
0000777bb65d3161  vmovaps xmm11, [rsp+0xA0]
0000777bb65d316a  vmovaps xmm12, [rsp+0xB0]
0000777bb65d3173  vmovaps xmm13, [rsp+0xC0]
0000777bb65d317c  vmovaps xmm14, [rsp+0xD0]
0000777bb65d3185  vmovaps xmm15, [rsp+0xE0]
0000777bb65d318e  add rsp, 0xF0
0000777bb65d3195  pop r11
0000777bb65d3197  pop r10
0000777bb65d3199  pop r9
0000777bb65d319b  pop r8
0000777bb65d319d  pop rsi
0000777bb65d319e  pop rdi
0000777bb65d319f  pop rdx
0000777bb65d31a0  pop rcx
0000777bb65d31a1  pop rax
0000777bb65d31a2  add rsp, 0x08
0000777bb65d31a6  jmp 0x0000777BB65CFE80
0000777bb65d31ab  sub rsp, 0x08
0000777bb65d31af  push rax
0000777bb65d31b0  push rcx
0000777bb65d31b1  push rdx
0000777bb65d31b2  push rdi
0000777bb65d31b3  push rsi
0000777bb65d31b4  push r8
0000777bb65d31b6  push r9
0000777bb65d31b8  push r10
0000777bb65d31ba  push r11
0000777bb65d31bc  sub rsp, 0xF0
0000777bb65d31c3  vmovaps [rsp], xmm0
0000777bb65d31c8  vmovaps [rsp+0x10], xmm1
0000777bb65d31ce  vmovaps [rsp+0x20], xmm2
0000777bb65d31d4  vmovaps [rsp+0x30], xmm3
0000777bb65d31da  vmovaps [rsp+0x40], xmm4
0000777bb65d31e0  vmovaps [rsp+0x50], xmm5
0000777bb65d31e6  vmovaps [rsp+0x60], xmm6
0000777bb65d31ec  vmovaps [rsp+0x70], xmm7
0000777bb65d31f2  vmovaps [rsp+0x80], xmm8
0000777bb65d31fb  vmovaps [rsp+0x90], xmm9
0000777bb65d3204  vmovaps [rsp+0xA0], xmm10
0000777bb65d320d  vmovaps [rsp+0xB0], xmm12
0000777bb65d3216  vmovaps [rsp+0xC0], xmm13
0000777bb65d321f  vmovaps [rsp+0xD0], xmm14
0000777bb65d3228  vmovaps [rsp+0xE0], xmm15
0000777bb65d3231  sub rsp, 0x30
0000777bb65d3235  movaps [rsp], xmm11
0000777bb65d323a  movaps [rsp+0x10], xmm2
0000777bb65d323f  movaps [rsp+0x20], xmm12
0000777bb65d3245  lea rdi, [rsp]
0000777bb65d3249  mov esi, 0x00
0000777bb65d324e  mov rax, 0x569DC437B530
0000777bb65d3258  call rax
0000777bb65d325a  movaps xmm11, [rsp]
0000777bb65d325f  add rsp, 0x30
0000777bb65d3263  vmovaps xmm0, [rsp]
0000777bb65d3268  vmovaps xmm1, [rsp+0x10]
0000777bb65d326e  vmovaps xmm2, [rsp+0x20]
0000777bb65d3274  vmovaps xmm3, [rsp+0x30]
0000777bb65d327a  vmovaps xmm4, [rsp+0x40]
0000777bb65d3280  vmovaps xmm5, [rsp+0x50]
0000777bb65d3286  vmovaps xmm6, [rsp+0x60]
0000777bb65d328c  vmovaps xmm7, [rsp+0x70]
0000777bb65d3292  vmovaps xmm8, [rsp+0x80]
0000777bb65d329b  vmovaps xmm9, [rsp+0x90]
0000777bb65d32a4  vmovaps xmm10, [rsp+0xA0]
0000777bb65d32ad  vmovaps xmm12, [rsp+0xB0]
0000777bb65d32b6  vmovaps xmm13, [rsp+0xC0]
0000777bb65d32bf  vmovaps xmm14, [rsp+0xD0]
0000777bb65d32c8  vmovaps xmm15, [rsp+0xE0]
0000777bb65d32d1  add rsp, 0xF0
0000777bb65d32d8  pop r11
0000777bb65d32da  pop r10
0000777bb65d32dc  pop r9
0000777bb65d32de  pop r8
0000777bb65d32e0  pop rsi
0000777bb65d32e1  pop rdi
0000777bb65d32e2  pop rdx
0000777bb65d32e3  pop rcx
0000777bb65d32e4  pop rax
0000777bb65d32e5  add rsp, 0x08
0000777bb65d32e9  jmp 0x0000777BB65CFEB8
0000777bb65d32ee  sub rsp, 0x08
0000777bb65d32f2  push rax
0000777bb65d32f3  push rcx
0000777bb65d32f4  push rdx
0000777bb65d32f5  push rdi
0000777bb65d32f6  push rsi
0000777bb65d32f7  push r8
0000777bb65d32f9  push r9
0000777bb65d32fb  push r10
0000777bb65d32fd  push r11
0000777bb65d32ff  sub rsp, 0xF0
0000777bb65d3306  vmovaps [rsp], xmm0
0000777bb65d330b  vmovaps [rsp+0x10], xmm2
0000777bb65d3311  vmovaps [rsp+0x20], xmm3
0000777bb65d3317  vmovaps [rsp+0x30], xmm4
0000777bb65d331d  vmovaps [rsp+0x40], xmm5
0000777bb65d3323  vmovaps [rsp+0x50], xmm6
0000777bb65d3329  vmovaps [rsp+0x60], xmm7
0000777bb65d332f  vmovaps [rsp+0x70], xmm8
0000777bb65d3335  vmovaps [rsp+0x80], xmm9
0000777bb65d333e  vmovaps [rsp+0x90], xmm10
0000777bb65d3347  vmovaps [rsp+0xA0], xmm11
0000777bb65d3350  vmovaps [rsp+0xB0], xmm12
0000777bb65d3359  vmovaps [rsp+0xC0], xmm13
0000777bb65d3362  vmovaps [rsp+0xD0], xmm14
0000777bb65d336b  vmovaps [rsp+0xE0], xmm15
0000777bb65d3374  sub rsp, 0x30
0000777bb65d3378  movaps [rsp], xmm1
0000777bb65d337c  movaps [rsp+0x10], xmm14
0000777bb65d3382  movaps [rsp+0x20], xmm6
0000777bb65d3387  lea rdi, [rsp]
0000777bb65d338b  mov esi, 0x00
0000777bb65d3390  mov rax, 0x569DC437B530
0000777bb65d339a  call rax
0000777bb65d339c  movaps xmm1, [rsp]
0000777bb65d33a0  add rsp, 0x30
0000777bb65d33a4  vmovaps xmm0, [rsp]
0000777bb65d33a9  vmovaps xmm2, [rsp+0x10]
0000777bb65d33af  vmovaps xmm3, [rsp+0x20]
0000777bb65d33b5  vmovaps xmm4, [rsp+0x30]
0000777bb65d33bb  vmovaps xmm5, [rsp+0x40]
0000777bb65d33c1  vmovaps xmm6, [rsp+0x50]
0000777bb65d33c7  vmovaps xmm7, [rsp+0x60]
0000777bb65d33cd  vmovaps xmm8, [rsp+0x70]
0000777bb65d33d3  vmovaps xmm9, [rsp+0x80]
0000777bb65d33dc  vmovaps xmm10, [rsp+0x90]
0000777bb65d33e5  vmovaps xmm11, [rsp+0xA0]
0000777bb65d33ee  vmovaps xmm12, [rsp+0xB0]
0000777bb65d33f7  vmovaps xmm13, [rsp+0xC0]
0000777bb65d3400  vmovaps xmm14, [rsp+0xD0]
0000777bb65d3409  vmovaps xmm15, [rsp+0xE0]
0000777bb65d3412  add rsp, 0xF0
0000777bb65d3419  pop r11
0000777bb65d341b  pop r10
0000777bb65d341d  pop r9
0000777bb65d341f  pop r8
0000777bb65d3421  pop rsi
0000777bb65d3422  pop rdi
0000777bb65d3423  pop rdx
0000777bb65d3424  pop rcx
0000777bb65d3425  pop rax
0000777bb65d3426  add rsp, 0x08
0000777bb65d342a  jmp 0x0000777BB65CFED1
0000777bb65d342f  sub rsp, 0x08
0000777bb65d3433  push rax
0000777bb65d3434  push rcx
0000777bb65d3435  push rdx
0000777bb65d3436  push rdi
0000777bb65d3437  push rsi
0000777bb65d3438  push r8
0000777bb65d343a  push r9
0000777bb65d343c  push r10
0000777bb65d343e  push r11
0000777bb65d3440  sub rsp, 0xF0
0000777bb65d3447  vmovaps [rsp], xmm0
0000777bb65d344c  vmovaps [rsp+0x10], xmm1
0000777bb65d3452  vmovaps [rsp+0x20], xmm2
0000777bb65d3458  vmovaps [rsp+0x30], xmm3
0000777bb65d345e  vmovaps [rsp+0x40], xmm4
0000777bb65d3464  vmovaps [rsp+0x50], xmm5
0000777bb65d346a  vmovaps [rsp+0x60], xmm6
0000777bb65d3470  vmovaps [rsp+0x70], xmm7
0000777bb65d3476  vmovaps [rsp+0x80], xmm8
0000777bb65d347f  vmovaps [rsp+0x90], xmm9
0000777bb65d3488  vmovaps [rsp+0xA0], xmm10
0000777bb65d3491  vmovaps [rsp+0xB0], xmm11
0000777bb65d349a  vmovaps [rsp+0xC0], xmm12
0000777bb65d34a3  vmovaps [rsp+0xD0], xmm13
0000777bb65d34ac  vmovaps [rsp+0xE0], xmm15
0000777bb65d34b5  sub rsp, 0x30
0000777bb65d34b9  movaps [rsp], xmm14
0000777bb65d34be  movaps [rsp+0x10], xmm12
0000777bb65d34c4  movaps [rsp+0x20], xmm5
0000777bb65d34c9  lea rdi, [rsp]
0000777bb65d34cd  mov esi, 0x00
0000777bb65d34d2  mov rax, 0x569DC437B530
0000777bb65d34dc  call rax
0000777bb65d34de  movaps xmm14, [rsp]
0000777bb65d34e3  add rsp, 0x30
0000777bb65d34e7  vmovaps xmm0, [rsp]
0000777bb65d34ec  vmovaps xmm1, [rsp+0x10]
0000777bb65d34f2  vmovaps xmm2, [rsp+0x20]
0000777bb65d34f8  vmovaps xmm3, [rsp+0x30]
0000777bb65d34fe  vmovaps xmm4, [rsp+0x40]
0000777bb65d3504  vmovaps xmm5, [rsp+0x50]
0000777bb65d350a  vmovaps xmm6, [rsp+0x60]
0000777bb65d3510  vmovaps xmm7, [rsp+0x70]
0000777bb65d3516  vmovaps xmm8, [rsp+0x80]
0000777bb65d351f  vmovaps xmm9, [rsp+0x90]
0000777bb65d3528  vmovaps xmm10, [rsp+0xA0]
0000777bb65d3531  vmovaps xmm11, [rsp+0xB0]
0000777bb65d353a  vmovaps xmm12, [rsp+0xC0]
0000777bb65d3543  vmovaps xmm13, [rsp+0xD0]
0000777bb65d354c  vmovaps xmm15, [rsp+0xE0]
0000777bb65d3555  add rsp, 0xF0
0000777bb65d355c  pop r11
0000777bb65d355e  pop r10
0000777bb65d3560  pop r9
0000777bb65d3562  pop r8
0000777bb65d3564  pop rsi
0000777bb65d3565  pop rdi
0000777bb65d3566  pop rdx
0000777bb65d3567  pop rcx
0000777bb65d3568  pop rax
0000777bb65d3569  add rsp, 0x08
0000777bb65d356d  jmp 0x0000777BB65CFEF1
0000777bb65d3572  sub rsp, 0x08
0000777bb65d3576  push rax
0000777bb65d3577  push rcx
0000777bb65d3578  push rdx
0000777bb65d3579  push rdi
0000777bb65d357a  push rsi
0000777bb65d357b  push r8
0000777bb65d357d  push r9
0000777bb65d357f  push r10
0000777bb65d3581  push r11
0000777bb65d3583  sub rsp, 0xF0
0000777bb65d358a  vmovaps [rsp], xmm0
0000777bb65d358f  vmovaps [rsp+0x10], xmm1
0000777bb65d3595  vmovaps [rsp+0x20], xmm2
0000777bb65d359b  vmovaps [rsp+0x30], xmm3
0000777bb65d35a1  vmovaps [rsp+0x40], xmm4
0000777bb65d35a7  vmovaps [rsp+0x50], xmm5
0000777bb65d35ad  vmovaps [rsp+0x60], xmm7
0000777bb65d35b3  vmovaps [rsp+0x70], xmm8
0000777bb65d35b9  vmovaps [rsp+0x80], xmm9
0000777bb65d35c2  vmovaps [rsp+0x90], xmm10
0000777bb65d35cb  vmovaps [rsp+0xA0], xmm11
0000777bb65d35d4  vmovaps [rsp+0xB0], xmm12
0000777bb65d35dd  vmovaps [rsp+0xC0], xmm13
0000777bb65d35e6  vmovaps [rsp+0xD0], xmm14
0000777bb65d35ef  vmovaps [rsp+0xE0], xmm15
0000777bb65d35f8  sub rsp, 0x30
0000777bb65d35fc  movaps [rsp], xmm6
0000777bb65d3600  movaps [rsp+0x10], xmm9
0000777bb65d3606  movaps [rsp+0x20], xmm12
0000777bb65d360c  lea rdi, [rsp]
0000777bb65d3610  mov esi, 0x00
0000777bb65d3615  mov rax, 0x569DC437B530
0000777bb65d361f  call rax
0000777bb65d3621  movaps xmm6, [rsp]
0000777bb65d3625  add rsp, 0x30
0000777bb65d3629  vmovaps xmm0, [rsp]
0000777bb65d362e  vmovaps xmm1, [rsp+0x10]
0000777bb65d3634  vmovaps xmm2, [rsp+0x20]
0000777bb65d363a  vmovaps xmm3, [rsp+0x30]
0000777bb65d3640  vmovaps xmm4, [rsp+0x40]
0000777bb65d3646  vmovaps xmm5, [rsp+0x50]
0000777bb65d364c  vmovaps xmm7, [rsp+0x60]
0000777bb65d3652  vmovaps xmm8, [rsp+0x70]
0000777bb65d3658  vmovaps xmm9, [rsp+0x80]
0000777bb65d3661  vmovaps xmm10, [rsp+0x90]
0000777bb65d366a  vmovaps xmm11, [rsp+0xA0]
0000777bb65d3673  vmovaps xmm12, [rsp+0xB0]
0000777bb65d367c  vmovaps xmm13, [rsp+0xC0]
0000777bb65d3685  vmovaps xmm14, [rsp+0xD0]
0000777bb65d368e  vmovaps xmm15, [rsp+0xE0]
0000777bb65d3697  add rsp, 0xF0
0000777bb65d369e  pop r11
0000777bb65d36a0  pop r10
0000777bb65d36a2  pop r9
0000777bb65d36a4  pop r8
0000777bb65d36a6  pop rsi
0000777bb65d36a7  pop rdi
0000777bb65d36a8  pop rdx
0000777bb65d36a9  pop rcx
0000777bb65d36aa  pop rax
0000777bb65d36ab  add rsp, 0x08
0000777bb65d36af  jmp 0x0000777BB65CFF19
0000777bb65d36b4  sub rsp, 0x08
0000777bb65d36b8  push rax
0000777bb65d36b9  push rcx
0000777bb65d36ba  push rdx
0000777bb65d36bb  push rdi
0000777bb65d36bc  push rsi
0000777bb65d36bd  push r8
0000777bb65d36bf  push r9
0000777bb65d36c1  push r10
0000777bb65d36c3  push r11
0000777bb65d36c5  sub rsp, 0xF0
0000777bb65d36cc  vmovaps [rsp], xmm0
0000777bb65d36d1  vmovaps [rsp+0x10], xmm1
0000777bb65d36d7  vmovaps [rsp+0x20], xmm2
0000777bb65d36dd  vmovaps [rsp+0x30], xmm3
0000777bb65d36e3  vmovaps [rsp+0x40], xmm4
0000777bb65d36e9  vmovaps [rsp+0x50], xmm5
0000777bb65d36ef  vmovaps [rsp+0x60], xmm6
0000777bb65d36f5  vmovaps [rsp+0x70], xmm7
0000777bb65d36fb  vmovaps [rsp+0x80], xmm8
0000777bb65d3704  vmovaps [rsp+0x90], xmm9
0000777bb65d370d  vmovaps [rsp+0xA0], xmm10
0000777bb65d3716  vmovaps [rsp+0xB0], xmm11
0000777bb65d371f  vmovaps [rsp+0xC0], xmm13
0000777bb65d3728  vmovaps [rsp+0xD0], xmm14
0000777bb65d3731  vmovaps [rsp+0xE0], xmm15
0000777bb65d373a  sub rsp, 0x30
0000777bb65d373e  movaps [rsp], xmm12
0000777bb65d3743  movaps [rsp+0x10], xmm15
0000777bb65d3749  movaps [rsp+0x20], xmm13
0000777bb65d374f  lea rdi, [rsp]
0000777bb65d3753  mov esi, 0x00
0000777bb65d3758  mov rax, 0x569DC437B530
0000777bb65d3762  call rax
0000777bb65d3764  movaps xmm12, [rsp]
0000777bb65d3769  add rsp, 0x30
0000777bb65d376d  vmovaps xmm0, [rsp]
0000777bb65d3772  vmovaps xmm1, [rsp+0x10]
0000777bb65d3778  vmovaps xmm2, [rsp+0x20]
0000777bb65d377e  vmovaps xmm3, [rsp+0x30]
0000777bb65d3784  vmovaps xmm4, [rsp+0x40]
0000777bb65d378a  vmovaps xmm5, [rsp+0x50]
0000777bb65d3790  vmovaps xmm6, [rsp+0x60]
0000777bb65d3796  vmovaps xmm7, [rsp+0x70]
0000777bb65d379c  vmovaps xmm8, [rsp+0x80]
0000777bb65d37a5  vmovaps xmm9, [rsp+0x90]
0000777bb65d37ae  vmovaps xmm10, [rsp+0xA0]
0000777bb65d37b7  vmovaps xmm11, [rsp+0xB0]
0000777bb65d37c0  vmovaps xmm13, [rsp+0xC0]
0000777bb65d37c9  vmovaps xmm14, [rsp+0xD0]
0000777bb65d37d2  vmovaps xmm15, [rsp+0xE0]
0000777bb65d37db  add rsp, 0xF0
0000777bb65d37e2  pop r11
0000777bb65d37e4  pop r10
0000777bb65d37e6  pop r9
0000777bb65d37e8  pop r8
0000777bb65d37ea  pop rsi
0000777bb65d37eb  pop rdi
0000777bb65d37ec  pop rdx
0000777bb65d37ed  pop rcx
0000777bb65d37ee  pop rax
0000777bb65d37ef  add rsp, 0x08
0000777bb65d37f3  jmp 0x0000777BB65CFF34
0000777bb65d37f8  sub rsp, 0x08
0000777bb65d37fc  push rax
0000777bb65d37fd  push rcx
0000777bb65d37fe  push rdx
0000777bb65d37ff  push rdi
0000777bb65d3800  push rsi
0000777bb65d3801  push r8
0000777bb65d3803  push r9
0000777bb65d3805  push r10
0000777bb65d3807  push r11
0000777bb65d3809  sub rsp, 0xF0
0000777bb65d3810  vmovaps [rsp], xmm0
0000777bb65d3815  vmovaps [rsp+0x10], xmm1
0000777bb65d381b  vmovaps [rsp+0x20], xmm2
0000777bb65d3821  vmovaps [rsp+0x30], xmm3
0000777bb65d3827  vmovaps [rsp+0x40], xmm4
0000777bb65d382d  vmovaps [rsp+0x50], xmm5
0000777bb65d3833  vmovaps [rsp+0x60], xmm6
0000777bb65d3839  vmovaps [rsp+0x70], xmm7
0000777bb65d383f  vmovaps [rsp+0x80], xmm8
0000777bb65d3848  vmovaps [rsp+0x90], xmm9
0000777bb65d3851  vmovaps [rsp+0xA0], xmm10
0000777bb65d385a  vmovaps [rsp+0xB0], xmm11
0000777bb65d3863  vmovaps [rsp+0xC0], xmm12
0000777bb65d386c  vmovaps [rsp+0xD0], xmm13
0000777bb65d3875  vmovaps [rsp+0xE0], xmm14
0000777bb65d387e  sub rsp, 0x30
0000777bb65d3882  movaps [rsp], xmm15
0000777bb65d3887  movaps [rsp+0x10], xmm13
0000777bb65d388d  movaps [rsp+0x20], xmm10
0000777bb65d3893  lea rdi, [rsp]
0000777bb65d3897  mov esi, 0x00
0000777bb65d389c  mov rax, 0x569DC437B530
0000777bb65d38a6  call rax
0000777bb65d38a8  movaps xmm15, [rsp]
0000777bb65d38ad  add rsp, 0x30
0000777bb65d38b1  vmovaps xmm0, [rsp]
0000777bb65d38b6  vmovaps xmm1, [rsp+0x10]
0000777bb65d38bc  vmovaps xmm2, [rsp+0x20]
0000777bb65d38c2  vmovaps xmm3, [rsp+0x30]
0000777bb65d38c8  vmovaps xmm4, [rsp+0x40]
0000777bb65d38ce  vmovaps xmm5, [rsp+0x50]
0000777bb65d38d4  vmovaps xmm6, [rsp+0x60]
0000777bb65d38da  vmovaps xmm7, [rsp+0x70]
0000777bb65d38e0  vmovaps xmm8, [rsp+0x80]
0000777bb65d38e9  vmovaps xmm9, [rsp+0x90]
0000777bb65d38f2  vmovaps xmm10, [rsp+0xA0]
0000777bb65d38fb  vmovaps xmm11, [rsp+0xB0]
0000777bb65d3904  vmovaps xmm12, [rsp+0xC0]
0000777bb65d390d  vmovaps xmm13, [rsp+0xD0]
0000777bb65d3916  vmovaps xmm14, [rsp+0xE0]
0000777bb65d391f  add rsp, 0xF0
0000777bb65d3926  pop r11
0000777bb65d3928  pop r10
0000777bb65d392a  pop r9
0000777bb65d392c  pop r8
0000777bb65d392e  pop rsi
0000777bb65d392f  pop rdi
0000777bb65d3930  pop rdx
0000777bb65d3931  pop rcx
0000777bb65d3932  pop rax
0000777bb65d3933  add rsp, 0x08
0000777bb65d3937  jmp 0x0000777BB65CFF55
0000777bb65d393c  call 0x0000777BB640C260
0000777bb65d3941  jmp 0x0000777BB65CFFB0
0000777bb65d3946  sub rsp, 0x08
0000777bb65d394a  push rax
0000777bb65d394b  push rcx
0000777bb65d394c  push rdx
0000777bb65d394d  push rdi
0000777bb65d394e  push rsi
0000777bb65d394f  push r8
0000777bb65d3951  push r9
0000777bb65d3953  push r10
0000777bb65d3955  push r11
0000777bb65d3957  sub rsp, 0xF0
0000777bb65d395e  vmovaps [rsp], xmm0
0000777bb65d3963  vmovaps [rsp+0x10], xmm1
0000777bb65d3969  vmovaps [rsp+0x20], xmm2
0000777bb65d396f  vmovaps [rsp+0x30], xmm3
0000777bb65d3975  vmovaps [rsp+0x40], xmm4
0000777bb65d397b  vmovaps [rsp+0x50], xmm5
0000777bb65d3981  vmovaps [rsp+0x60], xmm6
0000777bb65d3987  vmovaps [rsp+0x70], xmm7
0000777bb65d398d  vmovaps [rsp+0x80], xmm8
0000777bb65d3996  vmovaps [rsp+0x90], xmm10
0000777bb65d399f  vmovaps [rsp+0xA0], xmm11
0000777bb65d39a8  vmovaps [rsp+0xB0], xmm12
0000777bb65d39b1  vmovaps [rsp+0xC0], xmm13
0000777bb65d39ba  vmovaps [rsp+0xD0], xmm14
0000777bb65d39c3  vmovaps [rsp+0xE0], xmm15
0000777bb65d39cc  sub rsp, 0x30
0000777bb65d39d0  movaps [rsp], xmm9
0000777bb65d39d5  movaps [rsp+0x10], xmm8
0000777bb65d39db  movaps [rsp+0x20], xmm10
0000777bb65d39e1  lea rdi, [rsp]
0000777bb65d39e5  mov esi, 0x00
0000777bb65d39ea  mov rax, 0x569DC437B530
0000777bb65d39f4  call rax
0000777bb65d39f6  movaps xmm9, [rsp]
0000777bb65d39fb  add rsp, 0x30
0000777bb65d39ff  vmovaps xmm0, [rsp]
0000777bb65d3a04  vmovaps xmm1, [rsp+0x10]
0000777bb65d3a0a  vmovaps xmm2, [rsp+0x20]
0000777bb65d3a10  vmovaps xmm3, [rsp+0x30]
0000777bb65d3a16  vmovaps xmm4, [rsp+0x40]
0000777bb65d3a1c  vmovaps xmm5, [rsp+0x50]
0000777bb65d3a22  vmovaps xmm6, [rsp+0x60]
0000777bb65d3a28  vmovaps xmm7, [rsp+0x70]
0000777bb65d3a2e  vmovaps xmm8, [rsp+0x80]
0000777bb65d3a37  vmovaps xmm10, [rsp+0x90]
0000777bb65d3a40  vmovaps xmm11, [rsp+0xA0]
0000777bb65d3a49  vmovaps xmm12, [rsp+0xB0]
0000777bb65d3a52  vmovaps xmm13, [rsp+0xC0]
0000777bb65d3a5b  vmovaps xmm14, [rsp+0xD0]
0000777bb65d3a64  vmovaps xmm15, [rsp+0xE0]
0000777bb65d3a6d  add rsp, 0xF0
0000777bb65d3a74  pop r11
0000777bb65d3a76  pop r10
0000777bb65d3a78  pop r9
0000777bb65d3a7a  pop r8
0000777bb65d3a7c  pop rsi
0000777bb65d3a7d  pop rdi
0000777bb65d3a7e  pop rdx
0000777bb65d3a7f  pop rcx
0000777bb65d3a80  pop rax
0000777bb65d3a81  add rsp, 0x08
0000777bb65d3a85  jmp 0x0000777BB65CFFE1
0000777bb65d3a8a  sub rsp, 0x08
0000777bb65d3a8e  push rax
0000777bb65d3a8f  push rcx
0000777bb65d3a90  push rdx
0000777bb65d3a91  push rdi
0000777bb65d3a92  push rsi
0000777bb65d3a93  push r8
0000777bb65d3a95  push r9
0000777bb65d3a97  push r10
0000777bb65d3a99  push r11
0000777bb65d3a9b  sub rsp, 0xF0
0000777bb65d3aa2  vmovaps [rsp], xmm0
0000777bb65d3aa7  vmovaps [rsp+0x10], xmm1
0000777bb65d3aad  vmovaps [rsp+0x20], xmm2
0000777bb65d3ab3  vmovaps [rsp+0x30], xmm3
0000777bb65d3ab9  vmovaps [rsp+0x40], xmm4
0000777bb65d3abf  vmovaps [rsp+0x50], xmm5
0000777bb65d3ac5  vmovaps [rsp+0x60], xmm6
0000777bb65d3acb  vmovaps [rsp+0x70], xmm7
0000777bb65d3ad1  vmovaps [rsp+0x80], xmm8
0000777bb65d3ada  vmovaps [rsp+0x90], xmm9
0000777bb65d3ae3  vmovaps [rsp+0xA0], xmm11
0000777bb65d3aec  vmovaps [rsp+0xB0], xmm12
0000777bb65d3af5  vmovaps [rsp+0xC0], xmm13
0000777bb65d3afe  vmovaps [rsp+0xD0], xmm14
0000777bb65d3b07  vmovaps [rsp+0xE0], xmm15
0000777bb65d3b10  sub rsp, 0x30
0000777bb65d3b14  movaps [rsp], xmm10
0000777bb65d3b19  movaps [rsp+0x10], xmm1
0000777bb65d3b1e  movaps [rsp+0x20], xmm11
0000777bb65d3b24  lea rdi, [rsp]
0000777bb65d3b28  mov esi, 0x00
0000777bb65d3b2d  mov rax, 0x569DC437B530
0000777bb65d3b37  call rax
0000777bb65d3b39  movaps xmm10, [rsp]
0000777bb65d3b3e  add rsp, 0x30
0000777bb65d3b42  vmovaps xmm0, [rsp]
0000777bb65d3b47  vmovaps xmm1, [rsp+0x10]
0000777bb65d3b4d  vmovaps xmm2, [rsp+0x20]
0000777bb65d3b53  vmovaps xmm3, [rsp+0x30]
0000777bb65d3b59  vmovaps xmm4, [rsp+0x40]
0000777bb65d3b5f  vmovaps xmm5, [rsp+0x50]
0000777bb65d3b65  vmovaps xmm6, [rsp+0x60]
0000777bb65d3b6b  vmovaps xmm7, [rsp+0x70]
0000777bb65d3b71  vmovaps xmm8, [rsp+0x80]
0000777bb65d3b7a  vmovaps xmm9, [rsp+0x90]
0000777bb65d3b83  vmovaps xmm11, [rsp+0xA0]
0000777bb65d3b8c  vmovaps xmm12, [rsp+0xB0]
0000777bb65d3b95  vmovaps xmm13, [rsp+0xC0]
0000777bb65d3b9e  vmovaps xmm14, [rsp+0xD0]
0000777bb65d3ba7  vmovaps xmm15, [rsp+0xE0]
0000777bb65d3bb0  add rsp, 0xF0
0000777bb65d3bb7  pop r11
0000777bb65d3bb9  pop r10
0000777bb65d3bbb  pop r9
0000777bb65d3bbd  pop r8
0000777bb65d3bbf  pop rsi
0000777bb65d3bc0  pop rdi
0000777bb65d3bc1  pop rdx
0000777bb65d3bc2  pop rcx
0000777bb65d3bc3  pop rax
0000777bb65d3bc4  add rsp, 0x08
0000777bb65d3bc8  jmp 0x0000777BB65CFFFC
0000777bb65d3bcd  sub rsp, 0x08
0000777bb65d3bd1  push rax
0000777bb65d3bd2  push rcx
0000777bb65d3bd3  push rdx
0000777bb65d3bd4  push rdi
0000777bb65d3bd5  push rsi
0000777bb65d3bd6  push r8
0000777bb65d3bd8  push r9
0000777bb65d3bda  push r10
0000777bb65d3bdc  push r11
0000777bb65d3bde  sub rsp, 0xF0
0000777bb65d3be5  vmovaps [rsp], xmm0
0000777bb65d3bea  vmovaps [rsp+0x10], xmm2
0000777bb65d3bf0  vmovaps [rsp+0x20], xmm3
0000777bb65d3bf6  vmovaps [rsp+0x30], xmm4
0000777bb65d3bfc  vmovaps [rsp+0x40], xmm5
0000777bb65d3c02  vmovaps [rsp+0x50], xmm6
0000777bb65d3c08  vmovaps [rsp+0x60], xmm7
0000777bb65d3c0e  vmovaps [rsp+0x70], xmm8
0000777bb65d3c14  vmovaps [rsp+0x80], xmm9
0000777bb65d3c1d  vmovaps [rsp+0x90], xmm10
0000777bb65d3c26  vmovaps [rsp+0xA0], xmm11
0000777bb65d3c2f  vmovaps [rsp+0xB0], xmm12
0000777bb65d3c38  vmovaps [rsp+0xC0], xmm13
0000777bb65d3c41  vmovaps [rsp+0xD0], xmm14
0000777bb65d3c4a  vmovaps [rsp+0xE0], xmm15
0000777bb65d3c53  sub rsp, 0x30
0000777bb65d3c57  movaps [rsp], xmm1
0000777bb65d3c5b  movaps [rsp+0x10], xmm14
0000777bb65d3c61  movaps [rsp+0x20], xmm6
0000777bb65d3c66  lea rdi, [rsp]
0000777bb65d3c6a  mov esi, 0x00
0000777bb65d3c6f  mov rax, 0x569DC437B530
0000777bb65d3c79  call rax
0000777bb65d3c7b  movaps xmm1, [rsp]
0000777bb65d3c7f  add rsp, 0x30
0000777bb65d3c83  vmovaps xmm0, [rsp]
0000777bb65d3c88  vmovaps xmm2, [rsp+0x10]
0000777bb65d3c8e  vmovaps xmm3, [rsp+0x20]
0000777bb65d3c94  vmovaps xmm4, [rsp+0x30]
0000777bb65d3c9a  vmovaps xmm5, [rsp+0x40]
0000777bb65d3ca0  vmovaps xmm6, [rsp+0x50]
0000777bb65d3ca6  vmovaps xmm7, [rsp+0x60]
0000777bb65d3cac  vmovaps xmm8, [rsp+0x70]
0000777bb65d3cb2  vmovaps xmm9, [rsp+0x80]
0000777bb65d3cbb  vmovaps xmm10, [rsp+0x90]
0000777bb65d3cc4  vmovaps xmm11, [rsp+0xA0]
0000777bb65d3ccd  vmovaps xmm12, [rsp+0xB0]
0000777bb65d3cd6  vmovaps xmm13, [rsp+0xC0]
0000777bb65d3cdf  vmovaps xmm14, [rsp+0xD0]
0000777bb65d3ce8  vmovaps xmm15, [rsp+0xE0]
0000777bb65d3cf1  add rsp, 0xF0
0000777bb65d3cf8  pop r11
0000777bb65d3cfa  pop r10
0000777bb65d3cfc  pop r9
0000777bb65d3cfe  pop r8
0000777bb65d3d00  pop rsi
0000777bb65d3d01  pop rdi
0000777bb65d3d02  pop rdx
0000777bb65d3d03  pop rcx
0000777bb65d3d04  pop rax
0000777bb65d3d05  add rsp, 0x08
0000777bb65d3d09  jmp 0x0000777BB65D0015
0000777bb65d3d0e  sub rsp, 0x08
0000777bb65d3d12  push rax
0000777bb65d3d13  push rcx
0000777bb65d3d14  push rdx
0000777bb65d3d15  push rdi
0000777bb65d3d16  push rsi
0000777bb65d3d17  push r8
0000777bb65d3d19  push r9
0000777bb65d3d1b  push r10
0000777bb65d3d1d  push r11
0000777bb65d3d1f  sub rsp, 0xF0
0000777bb65d3d26  vmovaps [rsp], xmm0
0000777bb65d3d2b  vmovaps [rsp+0x10], xmm1
0000777bb65d3d31  vmovaps [rsp+0x20], xmm2
0000777bb65d3d37  vmovaps [rsp+0x30], xmm3
0000777bb65d3d3d  vmovaps [rsp+0x40], xmm4
0000777bb65d3d43  vmovaps [rsp+0x50], xmm5
0000777bb65d3d49  vmovaps [rsp+0x60], xmm6
0000777bb65d3d4f  vmovaps [rsp+0x70], xmm7
0000777bb65d3d55  vmovaps [rsp+0x80], xmm8
0000777bb65d3d5e  vmovaps [rsp+0x90], xmm9
0000777bb65d3d67  vmovaps [rsp+0xA0], xmm10
0000777bb65d3d70  vmovaps [rsp+0xB0], xmm12
0000777bb65d3d79  vmovaps [rsp+0xC0], xmm13
0000777bb65d3d82  vmovaps [rsp+0xD0], xmm14
0000777bb65d3d8b  vmovaps [rsp+0xE0], xmm15
0000777bb65d3d94  sub rsp, 0x30
0000777bb65d3d98  movaps [rsp], xmm11
0000777bb65d3d9d  movaps [rsp+0x10], xmm13
0000777bb65d3da3  movaps [rsp+0x20], xmm14
0000777bb65d3da9  lea rdi, [rsp]
0000777bb65d3dad  mov esi, 0x00
0000777bb65d3db2  mov rax, 0x569DC437B530
0000777bb65d3dbc  call rax
0000777bb65d3dbe  movaps xmm11, [rsp]
0000777bb65d3dc3  add rsp, 0x30
0000777bb65d3dc7  vmovaps xmm0, [rsp]
0000777bb65d3dcc  vmovaps xmm1, [rsp+0x10]
0000777bb65d3dd2  vmovaps xmm2, [rsp+0x20]
0000777bb65d3dd8  vmovaps xmm3, [rsp+0x30]
0000777bb65d3dde  vmovaps xmm4, [rsp+0x40]
0000777bb65d3de4  vmovaps xmm5, [rsp+0x50]
0000777bb65d3dea  vmovaps xmm6, [rsp+0x60]
0000777bb65d3df0  vmovaps xmm7, [rsp+0x70]
0000777bb65d3df6  vmovaps xmm8, [rsp+0x80]
0000777bb65d3dff  vmovaps xmm9, [rsp+0x90]
0000777bb65d3e08  vmovaps xmm10, [rsp+0xA0]
0000777bb65d3e11  vmovaps xmm12, [rsp+0xB0]
0000777bb65d3e1a  vmovaps xmm13, [rsp+0xC0]
0000777bb65d3e23  vmovaps xmm14, [rsp+0xD0]
0000777bb65d3e2c  vmovaps xmm15, [rsp+0xE0]
0000777bb65d3e35  add rsp, 0xF0
0000777bb65d3e3c  pop r11
0000777bb65d3e3e  pop r10
0000777bb65d3e40  pop r9
0000777bb65d3e42  pop r8
0000777bb65d3e44  pop rsi
0000777bb65d3e45  pop rdi
0000777bb65d3e46  pop rdx
0000777bb65d3e47  pop rcx
0000777bb65d3e48  pop rax
0000777bb65d3e49  add rsp, 0x08
0000777bb65d3e4d  jmp 0x0000777BB65D003F
0000777bb65d3e52  sub rsp, 0x08
0000777bb65d3e56  push rax
0000777bb65d3e57  push rcx
0000777bb65d3e58  push rdx
0000777bb65d3e59  push rdi
0000777bb65d3e5a  push rsi
0000777bb65d3e5b  push r8
0000777bb65d3e5d  push r9
0000777bb65d3e5f  push r10
0000777bb65d3e61  push r11
0000777bb65d3e63  sub rsp, 0xF0
0000777bb65d3e6a  vmovaps [rsp], xmm0
0000777bb65d3e6f  vmovaps [rsp+0x10], xmm1
0000777bb65d3e75  vmovaps [rsp+0x20], xmm2
0000777bb65d3e7b  vmovaps [rsp+0x30], xmm3
0000777bb65d3e81  vmovaps [rsp+0x40], xmm4
0000777bb65d3e87  vmovaps [rsp+0x50], xmm5
0000777bb65d3e8d  vmovaps [rsp+0x60], xmm6
0000777bb65d3e93  vmovaps [rsp+0x70], xmm7
0000777bb65d3e99  vmovaps [rsp+0x80], xmm8
0000777bb65d3ea2  vmovaps [rsp+0x90], xmm9
0000777bb65d3eab  vmovaps [rsp+0xA0], xmm10
0000777bb65d3eb4  vmovaps [rsp+0xB0], xmm11
0000777bb65d3ebd  vmovaps [rsp+0xC0], xmm12
0000777bb65d3ec6  vmovaps [rsp+0xD0], xmm14
0000777bb65d3ecf  vmovaps [rsp+0xE0], xmm15
0000777bb65d3ed8  sub rsp, 0x30
0000777bb65d3edc  movaps [rsp], xmm13
0000777bb65d3ee1  movaps [rsp+0x10], xmm8
0000777bb65d3ee7  movaps [rsp+0x20], xmm14
0000777bb65d3eed  lea rdi, [rsp]
0000777bb65d3ef1  mov esi, 0x00
0000777bb65d3ef6  mov rax, 0x569DC437B530
0000777bb65d3f00  call rax
0000777bb65d3f02  movaps xmm13, [rsp]
0000777bb65d3f07  add rsp, 0x30
0000777bb65d3f0b  vmovaps xmm0, [rsp]
0000777bb65d3f10  vmovaps xmm1, [rsp+0x10]
0000777bb65d3f16  vmovaps xmm2, [rsp+0x20]
0000777bb65d3f1c  vmovaps xmm3, [rsp+0x30]
0000777bb65d3f22  vmovaps xmm4, [rsp+0x40]
0000777bb65d3f28  vmovaps xmm5, [rsp+0x50]
0000777bb65d3f2e  vmovaps xmm6, [rsp+0x60]
0000777bb65d3f34  vmovaps xmm7, [rsp+0x70]
0000777bb65d3f3a  vmovaps xmm8, [rsp+0x80]
0000777bb65d3f43  vmovaps xmm9, [rsp+0x90]
0000777bb65d3f4c  vmovaps xmm10, [rsp+0xA0]
0000777bb65d3f55  vmovaps xmm11, [rsp+0xB0]
0000777bb65d3f5e  vmovaps xmm12, [rsp+0xC0]
0000777bb65d3f67  vmovaps xmm14, [rsp+0xD0]
0000777bb65d3f70  vmovaps xmm15, [rsp+0xE0]
0000777bb65d3f79  add rsp, 0xF0
0000777bb65d3f80  pop r11
0000777bb65d3f82  pop r10
0000777bb65d3f84  pop r9
0000777bb65d3f86  pop r8
0000777bb65d3f88  pop rsi
0000777bb65d3f89  pop rdi
0000777bb65d3f8a  pop rdx
0000777bb65d3f8b  pop rcx
0000777bb65d3f8c  pop rax
0000777bb65d3f8d  add rsp, 0x08
0000777bb65d3f91  jmp 0x0000777BB65D006E
0000777bb65d3f96  sub rsp, 0x08
0000777bb65d3f9a  push rax
0000777bb65d3f9b  push rcx
0000777bb65d3f9c  push rdx
0000777bb65d3f9d  push rdi
0000777bb65d3f9e  push rsi
0000777bb65d3f9f  push r8
0000777bb65d3fa1  push r9
0000777bb65d3fa3  push r10
0000777bb65d3fa5  push r11
0000777bb65d3fa7  sub rsp, 0xF0
0000777bb65d3fae  vmovaps [rsp], xmm0
0000777bb65d3fb3  vmovaps [rsp+0x10], xmm1
0000777bb65d3fb9  vmovaps [rsp+0x20], xmm2
0000777bb65d3fbf  vmovaps [rsp+0x30], xmm3
0000777bb65d3fc5  vmovaps [rsp+0x40], xmm4
0000777bb65d3fcb  vmovaps [rsp+0x50], xmm5
0000777bb65d3fd1  vmovaps [rsp+0x60], xmm6
0000777bb65d3fd7  vmovaps [rsp+0x70], xmm7
0000777bb65d3fdd  vmovaps [rsp+0x80], xmm9
0000777bb65d3fe6  vmovaps [rsp+0x90], xmm10
0000777bb65d3fef  vmovaps [rsp+0xA0], xmm11
0000777bb65d3ff8  vmovaps [rsp+0xB0], xmm12
0000777bb65d4001  vmovaps [rsp+0xC0], xmm13
0000777bb65d400a  vmovaps [rsp+0xD0], xmm14
0000777bb65d4013  vmovaps [rsp+0xE0], xmm15
0000777bb65d401c  sub rsp, 0x30
0000777bb65d4020  movaps [rsp], xmm8
0000777bb65d4025  movaps [rsp+0x10], xmm7
0000777bb65d402a  movaps [rsp+0x20], xmm14
0000777bb65d4030  lea rdi, [rsp]
0000777bb65d4034  mov esi, 0x00
0000777bb65d4039  mov rax, 0x569DC437B530
0000777bb65d4043  call rax
0000777bb65d4045  movaps xmm8, [rsp]
0000777bb65d404a  add rsp, 0x30
0000777bb65d404e  vmovaps xmm0, [rsp]
0000777bb65d4053  vmovaps xmm1, [rsp+0x10]
0000777bb65d4059  vmovaps xmm2, [rsp+0x20]
0000777bb65d405f  vmovaps xmm3, [rsp+0x30]
0000777bb65d4065  vmovaps xmm4, [rsp+0x40]
0000777bb65d406b  vmovaps xmm5, [rsp+0x50]
0000777bb65d4071  vmovaps xmm6, [rsp+0x60]
0000777bb65d4077  vmovaps xmm7, [rsp+0x70]
0000777bb65d407d  vmovaps xmm9, [rsp+0x80]
0000777bb65d4086  vmovaps xmm10, [rsp+0x90]
0000777bb65d408f  vmovaps xmm11, [rsp+0xA0]
0000777bb65d4098  vmovaps xmm12, [rsp+0xB0]
0000777bb65d40a1  vmovaps xmm13, [rsp+0xC0]
0000777bb65d40aa  vmovaps xmm14, [rsp+0xD0]
0000777bb65d40b3  vmovaps xmm15, [rsp+0xE0]
0000777bb65d40bc  add rsp, 0xF0
0000777bb65d40c3  pop r11
0000777bb65d40c5  pop r10
0000777bb65d40c7  pop r9
0000777bb65d40c9  pop r8
0000777bb65d40cb  pop rsi
0000777bb65d40cc  pop rdi
0000777bb65d40cd  pop rdx
0000777bb65d40ce  pop rcx
0000777bb65d40cf  pop rax
0000777bb65d40d0  add rsp, 0x08
0000777bb65d40d4  jmp 0x0000777BB65D0094
0000777bb65d40d9  sub rsp, 0x08
0000777bb65d40dd  push rax
0000777bb65d40de  push rcx
0000777bb65d40df  push rdx
0000777bb65d40e0  push rdi
0000777bb65d40e1  push rsi
0000777bb65d40e2  push r8
0000777bb65d40e4  push r9
0000777bb65d40e6  push r10
0000777bb65d40e8  push r11
0000777bb65d40ea  sub rsp, 0xF0
0000777bb65d40f1  vmovaps [rsp], xmm0
0000777bb65d40f6  vmovaps [rsp+0x10], xmm1
0000777bb65d40fc  vmovaps [rsp+0x20], xmm2
0000777bb65d4102  vmovaps [rsp+0x30], xmm3
0000777bb65d4108  vmovaps [rsp+0x40], xmm4
0000777bb65d410e  vmovaps [rsp+0x50], xmm5
0000777bb65d4114  vmovaps [rsp+0x60], xmm6
0000777bb65d411a  vmovaps [rsp+0x70], xmm7
0000777bb65d4120  vmovaps [rsp+0x80], xmm8
0000777bb65d4129  vmovaps [rsp+0x90], xmm9
0000777bb65d4132  vmovaps [rsp+0xA0], xmm10
0000777bb65d413b  vmovaps [rsp+0xB0], xmm11
0000777bb65d4144  vmovaps [rsp+0xC0], xmm12
0000777bb65d414d  vmovaps [rsp+0xD0], xmm13
0000777bb65d4156  vmovaps [rsp+0xE0], xmm15
0000777bb65d415f  sub rsp, 0x30
0000777bb65d4163  movaps [rsp], xmm14
0000777bb65d4168  movaps [rsp+0x10], xmm12
0000777bb65d416e  movaps [rsp+0x20], xmm9
0000777bb65d4174  lea rdi, [rsp]
0000777bb65d4178  mov esi, 0x00
0000777bb65d417d  mov rax, 0x569DC437B530
0000777bb65d4187  call rax
0000777bb65d4189  movaps xmm14, [rsp]
0000777bb65d418e  add rsp, 0x30
0000777bb65d4192  vmovaps xmm0, [rsp]
0000777bb65d4197  vmovaps xmm1, [rsp+0x10]
0000777bb65d419d  vmovaps xmm2, [rsp+0x20]
0000777bb65d41a3  vmovaps xmm3, [rsp+0x30]
0000777bb65d41a9  vmovaps xmm4, [rsp+0x40]
0000777bb65d41af  vmovaps xmm5, [rsp+0x50]
0000777bb65d41b5  vmovaps xmm6, [rsp+0x60]
0000777bb65d41bb  vmovaps xmm7, [rsp+0x70]
0000777bb65d41c1  vmovaps xmm8, [rsp+0x80]
0000777bb65d41ca  vmovaps xmm9, [rsp+0x90]
0000777bb65d41d3  vmovaps xmm10, [rsp+0xA0]
0000777bb65d41dc  vmovaps xmm11, [rsp+0xB0]
0000777bb65d41e5  vmovaps xmm12, [rsp+0xC0]
0000777bb65d41ee  vmovaps xmm13, [rsp+0xD0]
0000777bb65d41f7  vmovaps xmm15, [rsp+0xE0]
0000777bb65d4200  add rsp, 0xF0
0000777bb65d4207  pop r11
0000777bb65d4209  pop r10
0000777bb65d420b  pop r9
0000777bb65d420d  pop r8
0000777bb65d420f  pop rsi
0000777bb65d4210  pop rdi
0000777bb65d4211  pop rdx
0000777bb65d4212  pop rcx
0000777bb65d4213  pop rax
0000777bb65d4214  add rsp, 0x08
0000777bb65d4218  jmp 0x0000777BB65D00AE
0000777bb65d421d  sub rsp, 0x08
0000777bb65d4221  push rax
0000777bb65d4222  push rcx
0000777bb65d4223  push rdx
0000777bb65d4224  push rdi
0000777bb65d4225  push rsi
0000777bb65d4226  push r8
0000777bb65d4228  push r9
0000777bb65d422a  push r10
0000777bb65d422c  push r11
0000777bb65d422e  sub rsp, 0xF0
0000777bb65d4235  vmovaps [rsp], xmm0
0000777bb65d423a  vmovaps [rsp+0x10], xmm1
0000777bb65d4240  vmovaps [rsp+0x20], xmm2
0000777bb65d4246  vmovaps [rsp+0x30], xmm3
0000777bb65d424c  vmovaps [rsp+0x40], xmm4
0000777bb65d4252  vmovaps [rsp+0x50], xmm5
0000777bb65d4258  vmovaps [rsp+0x60], xmm6
0000777bb65d425e  vmovaps [rsp+0x70], xmm7
0000777bb65d4264  vmovaps [rsp+0x80], xmm8
0000777bb65d426d  vmovaps [rsp+0x90], xmm10
0000777bb65d4276  vmovaps [rsp+0xA0], xmm11
0000777bb65d427f  vmovaps [rsp+0xB0], xmm12
0000777bb65d4288  vmovaps [rsp+0xC0], xmm13
0000777bb65d4291  vmovaps [rsp+0xD0], xmm14
0000777bb65d429a  vmovaps [rsp+0xE0], xmm15
0000777bb65d42a3  sub rsp, 0x30
0000777bb65d42a7  movaps [rsp], xmm9
0000777bb65d42ac  movaps [rsp+0x10], xmm7
0000777bb65d42b1  movaps [rsp+0x20], xmm12
0000777bb65d42b7  lea rdi, [rsp]
0000777bb65d42bb  mov esi, 0x00
0000777bb65d42c0  mov rax, 0x569DC437B530
0000777bb65d42ca  call rax
0000777bb65d42cc  movaps xmm9, [rsp]
0000777bb65d42d1  add rsp, 0x30
0000777bb65d42d5  vmovaps xmm0, [rsp]
0000777bb65d42da  vmovaps xmm1, [rsp+0x10]
0000777bb65d42e0  vmovaps xmm2, [rsp+0x20]
0000777bb65d42e6  vmovaps xmm3, [rsp+0x30]
0000777bb65d42ec  vmovaps xmm4, [rsp+0x40]
0000777bb65d42f2  vmovaps xmm5, [rsp+0x50]
0000777bb65d42f8  vmovaps xmm6, [rsp+0x60]
0000777bb65d42fe  vmovaps xmm7, [rsp+0x70]
0000777bb65d4304  vmovaps xmm8, [rsp+0x80]
0000777bb65d430d  vmovaps xmm10, [rsp+0x90]
0000777bb65d4316  vmovaps xmm11, [rsp+0xA0]
0000777bb65d431f  vmovaps xmm12, [rsp+0xB0]
0000777bb65d4328  vmovaps xmm13, [rsp+0xC0]
0000777bb65d4331  vmovaps xmm14, [rsp+0xD0]
0000777bb65d433a  vmovaps xmm15, [rsp+0xE0]
0000777bb65d4343  add rsp, 0xF0
0000777bb65d434a  pop r11
0000777bb65d434c  pop r10
0000777bb65d434e  pop r9
0000777bb65d4350  pop r8
0000777bb65d4352  pop rsi
0000777bb65d4353  pop rdi
0000777bb65d4354  pop rdx
0000777bb65d4355  pop rcx
0000777bb65d4356  pop rax
0000777bb65d4357  add rsp, 0x08
0000777bb65d435b  jmp 0x0000777BB65D00DD
0000777bb65d4360  sub rsp, 0x08
0000777bb65d4364  push rax
0000777bb65d4365  push rcx
0000777bb65d4366  push rdx
0000777bb65d4367  push rdi
0000777bb65d4368  push rsi
0000777bb65d4369  push r8
0000777bb65d436b  push r9
0000777bb65d436d  push r10
0000777bb65d436f  push r11
0000777bb65d4371  sub rsp, 0xF0
0000777bb65d4378  vmovaps [rsp], xmm0
0000777bb65d437d  vmovaps [rsp+0x10], xmm1
0000777bb65d4383  vmovaps [rsp+0x20], xmm2
0000777bb65d4389  vmovaps [rsp+0x30], xmm3
0000777bb65d438f  vmovaps [rsp+0x40], xmm4
0000777bb65d4395  vmovaps [rsp+0x50], xmm5
0000777bb65d439b  vmovaps [rsp+0x60], xmm6
0000777bb65d43a1  vmovaps [rsp+0x70], xmm7
0000777bb65d43a7  vmovaps [rsp+0x80], xmm8
0000777bb65d43b0  vmovaps [rsp+0x90], xmm9
0000777bb65d43b9  vmovaps [rsp+0xA0], xmm10
0000777bb65d43c2  vmovaps [rsp+0xB0], xmm11
0000777bb65d43cb  vmovaps [rsp+0xC0], xmm13
0000777bb65d43d4  vmovaps [rsp+0xD0], xmm14
0000777bb65d43dd  vmovaps [rsp+0xE0], xmm15
0000777bb65d43e6  sub rsp, 0x30
0000777bb65d43ea  movaps [rsp], xmm12
0000777bb65d43ef  movaps [rsp+0x10], xmm15
0000777bb65d43f5  movaps [rsp+0x20], xmm11
0000777bb65d43fb  lea rdi, [rsp]
0000777bb65d43ff  mov esi, 0x00
0000777bb65d4404  mov rax, 0x569DC437B530
0000777bb65d440e  call rax
0000777bb65d4410  movaps xmm12, [rsp]
0000777bb65d4415  add rsp, 0x30
0000777bb65d4419  vmovaps xmm0, [rsp]
0000777bb65d441e  vmovaps xmm1, [rsp+0x10]
0000777bb65d4424  vmovaps xmm2, [rsp+0x20]
0000777bb65d442a  vmovaps xmm3, [rsp+0x30]
0000777bb65d4430  vmovaps xmm4, [rsp+0x40]
0000777bb65d4436  vmovaps xmm5, [rsp+0x50]
0000777bb65d443c  vmovaps xmm6, [rsp+0x60]
0000777bb65d4442  vmovaps xmm7, [rsp+0x70]
0000777bb65d4448  vmovaps xmm8, [rsp+0x80]
0000777bb65d4451  vmovaps xmm9, [rsp+0x90]
0000777bb65d445a  vmovaps xmm10, [rsp+0xA0]
0000777bb65d4463  vmovaps xmm11, [rsp+0xB0]
0000777bb65d446c  vmovaps xmm13, [rsp+0xC0]
0000777bb65d4475  vmovaps xmm14, [rsp+0xD0]
0000777bb65d447e  vmovaps xmm15, [rsp+0xE0]
0000777bb65d4487  add rsp, 0xF0
0000777bb65d448e  pop r11
0000777bb65d4490  pop r10
0000777bb65d4492  pop r9
0000777bb65d4494  pop r8
0000777bb65d4496  pop rsi
0000777bb65d4497  pop rdi
0000777bb65d4498  pop rdx
0000777bb65d4499  pop rcx
0000777bb65d449a  pop rax
0000777bb65d449b  add rsp, 0x08
0000777bb65d449f  jmp 0x0000777BB65D00F7
0000777bb65d44a4  sub rsp, 0x08
0000777bb65d44a8  push rax
0000777bb65d44a9  push rcx
0000777bb65d44aa  push rdx
0000777bb65d44ab  push rdi
0000777bb65d44ac  push rsi
0000777bb65d44ad  push r8
0000777bb65d44af  push r9
0000777bb65d44b1  push r10
0000777bb65d44b3  push r11
0000777bb65d44b5  sub rsp, 0xF0
0000777bb65d44bc  vmovaps [rsp], xmm0
0000777bb65d44c1  vmovaps [rsp+0x10], xmm1
0000777bb65d44c7  vmovaps [rsp+0x20], xmm2
0000777bb65d44cd  vmovaps [rsp+0x30], xmm3
0000777bb65d44d3  vmovaps [rsp+0x40], xmm4
0000777bb65d44d9  vmovaps [rsp+0x50], xmm5
0000777bb65d44df  vmovaps [rsp+0x60], xmm6
0000777bb65d44e5  vmovaps [rsp+0x70], xmm7
0000777bb65d44eb  vmovaps [rsp+0x80], xmm8
0000777bb65d44f4  vmovaps [rsp+0x90], xmm9
0000777bb65d44fd  vmovaps [rsp+0xA0], xmm10
0000777bb65d4506  vmovaps [rsp+0xB0], xmm12
0000777bb65d450f  vmovaps [rsp+0xC0], xmm13
0000777bb65d4518  vmovaps [rsp+0xD0], xmm14
0000777bb65d4521  vmovaps [rsp+0xE0], xmm15
0000777bb65d452a  sub rsp, 0x30
0000777bb65d452e  movaps [rsp], xmm11
0000777bb65d4533  movaps [rsp+0x10], xmm7
0000777bb65d4538  movaps [rsp+0x20], xmm15
0000777bb65d453e  lea rdi, [rsp]
0000777bb65d4542  mov esi, 0x00
0000777bb65d4547  mov rax, 0x569DC437B530
0000777bb65d4551  call rax
0000777bb65d4553  movaps xmm11, [rsp]
0000777bb65d4558  add rsp, 0x30
0000777bb65d455c  vmovaps xmm0, [rsp]
0000777bb65d4561  vmovaps xmm1, [rsp+0x10]
0000777bb65d4567  vmovaps xmm2, [rsp+0x20]
0000777bb65d456d  vmovaps xmm3, [rsp+0x30]
0000777bb65d4573  vmovaps xmm4, [rsp+0x40]
0000777bb65d4579  vmovaps xmm5, [rsp+0x50]
0000777bb65d457f  vmovaps xmm6, [rsp+0x60]
0000777bb65d4585  vmovaps xmm7, [rsp+0x70]
0000777bb65d458b  vmovaps xmm8, [rsp+0x80]
0000777bb65d4594  vmovaps xmm9, [rsp+0x90]
0000777bb65d459d  vmovaps xmm10, [rsp+0xA0]
0000777bb65d45a6  vmovaps xmm12, [rsp+0xB0]
0000777bb65d45af  vmovaps xmm13, [rsp+0xC0]
0000777bb65d45b8  vmovaps xmm14, [rsp+0xD0]
0000777bb65d45c1  vmovaps xmm15, [rsp+0xE0]
0000777bb65d45ca  add rsp, 0xF0
0000777bb65d45d1  pop r11
0000777bb65d45d3  pop r10
0000777bb65d45d5  pop r9
0000777bb65d45d7  pop r8
0000777bb65d45d9  pop rsi
0000777bb65d45da  pop rdi
0000777bb65d45db  pop rdx
0000777bb65d45dc  pop rcx
0000777bb65d45dd  pop rax
0000777bb65d45de  add rsp, 0x08
0000777bb65d45e2  jmp 0x0000777BB65D0123
0000777bb65d45e7  sub rsp, 0x08
0000777bb65d45eb  push rax
0000777bb65d45ec  push rcx
0000777bb65d45ed  push rdx
0000777bb65d45ee  push rdi
0000777bb65d45ef  push rsi
0000777bb65d45f0  push r8
0000777bb65d45f2  push r9
0000777bb65d45f4  push r10
0000777bb65d45f6  push r11
0000777bb65d45f8  sub rsp, 0xF0
0000777bb65d45ff  vmovaps [rsp], xmm0
0000777bb65d4604  vmovaps [rsp+0x10], xmm1
0000777bb65d460a  vmovaps [rsp+0x20], xmm2
0000777bb65d4610  vmovaps [rsp+0x30], xmm3
0000777bb65d4616  vmovaps [rsp+0x40], xmm4
0000777bb65d461c  vmovaps [rsp+0x50], xmm5
0000777bb65d4622  vmovaps [rsp+0x60], xmm6
0000777bb65d4628  vmovaps [rsp+0x70], xmm7
0000777bb65d462e  vmovaps [rsp+0x80], xmm8
0000777bb65d4637  vmovaps [rsp+0x90], xmm9
0000777bb65d4640  vmovaps [rsp+0xA0], xmm10
0000777bb65d4649  vmovaps [rsp+0xB0], xmm11
0000777bb65d4652  vmovaps [rsp+0xC0], xmm12
0000777bb65d465b  vmovaps [rsp+0xD0], xmm13
0000777bb65d4664  vmovaps [rsp+0xE0], xmm14
0000777bb65d466d  sub rsp, 0x30
0000777bb65d4671  movaps [rsp], xmm15
0000777bb65d4676  movaps [rsp+0x10], xmm10
0000777bb65d467c  movaps [rsp+0x20], xmm13
0000777bb65d4682  lea rdi, [rsp]
0000777bb65d4686  mov esi, 0x00
0000777bb65d468b  mov rax, 0x569DC437B530
0000777bb65d4695  call rax
0000777bb65d4697  movaps xmm15, [rsp]
0000777bb65d469c  add rsp, 0x30
0000777bb65d46a0  vmovaps xmm0, [rsp]
0000777bb65d46a5  vmovaps xmm1, [rsp+0x10]
0000777bb65d46ab  vmovaps xmm2, [rsp+0x20]
0000777bb65d46b1  vmovaps xmm3, [rsp+0x30]
0000777bb65d46b7  vmovaps xmm4, [rsp+0x40]
0000777bb65d46bd  vmovaps xmm5, [rsp+0x50]
0000777bb65d46c3  vmovaps xmm6, [rsp+0x60]
0000777bb65d46c9  vmovaps xmm7, [rsp+0x70]
0000777bb65d46cf  vmovaps xmm8, [rsp+0x80]
0000777bb65d46d8  vmovaps xmm9, [rsp+0x90]
0000777bb65d46e1  vmovaps xmm10, [rsp+0xA0]
0000777bb65d46ea  vmovaps xmm11, [rsp+0xB0]
0000777bb65d46f3  vmovaps xmm12, [rsp+0xC0]
0000777bb65d46fc  vmovaps xmm13, [rsp+0xD0]
0000777bb65d4705  vmovaps xmm14, [rsp+0xE0]
0000777bb65d470e  add rsp, 0xF0
0000777bb65d4715  pop r11
0000777bb65d4717  pop r10
0000777bb65d4719  pop r9
0000777bb65d471b  pop r8
0000777bb65d471d  pop rsi
0000777bb65d471e  pop rdi
0000777bb65d471f  pop rdx
0000777bb65d4720  pop rcx
0000777bb65d4721  pop rax
0000777bb65d4722  add rsp, 0x08
0000777bb65d4726  jmp 0x0000777BB65D013D
0000777bb65d472b  sub rsp, 0x08
0000777bb65d472f  push rax
0000777bb65d4730  push rcx
0000777bb65d4731  push rdx
0000777bb65d4732  push rdi
0000777bb65d4733  push rsi
0000777bb65d4734  push r8
0000777bb65d4736  push r9
0000777bb65d4738  push r10
0000777bb65d473a  push r11
0000777bb65d473c  sub rsp, 0xF0
0000777bb65d4743  vmovaps [rsp], xmm0
0000777bb65d4748  vmovaps [rsp+0x10], xmm1
0000777bb65d474e  vmovaps [rsp+0x20], xmm2
0000777bb65d4754  vmovaps [rsp+0x30], xmm3
0000777bb65d475a  vmovaps [rsp+0x40], xmm4
0000777bb65d4760  vmovaps [rsp+0x50], xmm5
0000777bb65d4766  vmovaps [rsp+0x60], xmm6
0000777bb65d476c  vmovaps [rsp+0x70], xmm7
0000777bb65d4772  vmovaps [rsp+0x80], xmm8
0000777bb65d477b  vmovaps [rsp+0x90], xmm9
0000777bb65d4784  vmovaps [rsp+0xA0], xmm11
0000777bb65d478d  vmovaps [rsp+0xB0], xmm12
0000777bb65d4796  vmovaps [rsp+0xC0], xmm13
0000777bb65d479f  vmovaps [rsp+0xD0], xmm14
0000777bb65d47a8  vmovaps [rsp+0xE0], xmm15
0000777bb65d47b1  sub rsp, 0x30
0000777bb65d47b5  movaps [rsp], xmm10
0000777bb65d47ba  movaps [rsp+0x10], xmm7
0000777bb65d47bf  movaps [rsp+0x20], xmm13
0000777bb65d47c5  lea rdi, [rsp]
0000777bb65d47c9  mov esi, 0x00
0000777bb65d47ce  mov rax, 0x569DC437B530
0000777bb65d47d8  call rax
0000777bb65d47da  movaps xmm10, [rsp]
0000777bb65d47df  add rsp, 0x30
0000777bb65d47e3  vmovaps xmm0, [rsp]
0000777bb65d47e8  vmovaps xmm1, [rsp+0x10]
0000777bb65d47ee  vmovaps xmm2, [rsp+0x20]
0000777bb65d47f4  vmovaps xmm3, [rsp+0x30]
0000777bb65d47fa  vmovaps xmm4, [rsp+0x40]
0000777bb65d4800  vmovaps xmm5, [rsp+0x50]
0000777bb65d4806  vmovaps xmm6, [rsp+0x60]
0000777bb65d480c  vmovaps xmm7, [rsp+0x70]
0000777bb65d4812  vmovaps xmm8, [rsp+0x80]
0000777bb65d481b  vmovaps xmm9, [rsp+0x90]
0000777bb65d4824  vmovaps xmm11, [rsp+0xA0]
0000777bb65d482d  vmovaps xmm12, [rsp+0xB0]
0000777bb65d4836  vmovaps xmm13, [rsp+0xC0]
0000777bb65d483f  vmovaps xmm14, [rsp+0xD0]
0000777bb65d4848  vmovaps xmm15, [rsp+0xE0]
0000777bb65d4851  add rsp, 0xF0
0000777bb65d4858  pop r11
0000777bb65d485a  pop r10
0000777bb65d485c  pop r9
0000777bb65d485e  pop r8
0000777bb65d4860  pop rsi
0000777bb65d4861  pop rdi
0000777bb65d4862  pop rdx
0000777bb65d4863  pop rcx
0000777bb65d4864  pop rax
0000777bb65d4865  add rsp, 0x08
0000777bb65d4869  jmp 0x0000777BB65D0169
0000777bb65d486e  sub rsp, 0x08
0000777bb65d4872  push rax
0000777bb65d4873  push rcx
0000777bb65d4874  push rdx
0000777bb65d4875  push rdi
0000777bb65d4876  push rsi
0000777bb65d4877  push r8
0000777bb65d4879  push r9
0000777bb65d487b  push r10
0000777bb65d487d  push r11
0000777bb65d487f  sub rsp, 0xF0
0000777bb65d4886  vmovaps [rsp], xmm0
0000777bb65d488b  vmovaps [rsp+0x10], xmm1
0000777bb65d4891  vmovaps [rsp+0x20], xmm2
0000777bb65d4897  vmovaps [rsp+0x30], xmm3
0000777bb65d489d  vmovaps [rsp+0x40], xmm4
0000777bb65d48a3  vmovaps [rsp+0x50], xmm5
0000777bb65d48a9  vmovaps [rsp+0x60], xmm6
0000777bb65d48af  vmovaps [rsp+0x70], xmm7
0000777bb65d48b5  vmovaps [rsp+0x80], xmm8
0000777bb65d48be  vmovaps [rsp+0x90], xmm9
0000777bb65d48c7  vmovaps [rsp+0xA0], xmm10
0000777bb65d48d0  vmovaps [rsp+0xB0], xmm11
0000777bb65d48d9  vmovaps [rsp+0xC0], xmm12
0000777bb65d48e2  vmovaps [rsp+0xD0], xmm14
0000777bb65d48eb  vmovaps [rsp+0xE0], xmm15
0000777bb65d48f4  sub rsp, 0x30
0000777bb65d48f8  movaps [rsp], xmm13
0000777bb65d48fd  movaps [rsp+0x10], xmm1
0000777bb65d4902  movaps [rsp+0x20], xmm8
0000777bb65d4908  lea rdi, [rsp]
0000777bb65d490c  mov esi, 0x00
0000777bb65d4911  mov rax, 0x569DC437B530
0000777bb65d491b  call rax
0000777bb65d491d  movaps xmm13, [rsp]
0000777bb65d4922  add rsp, 0x30
0000777bb65d4926  vmovaps xmm0, [rsp]
0000777bb65d492b  vmovaps xmm1, [rsp+0x10]
0000777bb65d4931  vmovaps xmm2, [rsp+0x20]
0000777bb65d4937  vmovaps xmm3, [rsp+0x30]
0000777bb65d493d  vmovaps xmm4, [rsp+0x40]
0000777bb65d4943  vmovaps xmm5, [rsp+0x50]
0000777bb65d4949  vmovaps xmm6, [rsp+0x60]
0000777bb65d494f  vmovaps xmm7, [rsp+0x70]
0000777bb65d4955  vmovaps xmm8, [rsp+0x80]
0000777bb65d495e  vmovaps xmm9, [rsp+0x90]
0000777bb65d4967  vmovaps xmm10, [rsp+0xA0]
0000777bb65d4970  vmovaps xmm11, [rsp+0xB0]
0000777bb65d4979  vmovaps xmm12, [rsp+0xC0]
0000777bb65d4982  vmovaps xmm14, [rsp+0xD0]
0000777bb65d498b  vmovaps xmm15, [rsp+0xE0]
0000777bb65d4994  add rsp, 0xF0
0000777bb65d499b  pop r11
0000777bb65d499d  pop r10
0000777bb65d499f  pop r9
0000777bb65d49a1  pop r8
0000777bb65d49a3  pop rsi
0000777bb65d49a4  pop rdi
0000777bb65d49a5  pop rdx
0000777bb65d49a6  pop rcx
0000777bb65d49a7  pop rax
0000777bb65d49a8  add rsp, 0x08
0000777bb65d49ac  jmp 0x0000777BB65D0183
0000777bb65d49b1  call 0x0000777BB63FF430
0000777bb65d49b6  jmp 0x0000777BB65D018D
0000777bb65d49bb  sub rsp, 0x08
0000777bb65d49bf  push rax
0000777bb65d49c0  push rcx
0000777bb65d49c1  push rdx
0000777bb65d49c2  push rdi
0000777bb65d49c3  push rsi
0000777bb65d49c4  push r8
0000777bb65d49c6  push r9
0000777bb65d49c8  push r10
0000777bb65d49ca  push r11
0000777bb65d49cc  sub rsp, 0xF0
0000777bb65d49d3  vmovaps [rsp], xmm0
0000777bb65d49d8  vmovaps [rsp+0x10], xmm1
0000777bb65d49de  vmovaps [rsp+0x20], xmm2
0000777bb65d49e4  vmovaps [rsp+0x30], xmm3
0000777bb65d49ea  vmovaps [rsp+0x40], xmm4
0000777bb65d49f0  vmovaps [rsp+0x50], xmm5
0000777bb65d49f6  vmovaps [rsp+0x60], xmm6
0000777bb65d49fc  vmovaps [rsp+0x70], xmm7
0000777bb65d4a02  vmovaps [rsp+0x80], xmm9
0000777bb65d4a0b  vmovaps [rsp+0x90], xmm10
0000777bb65d4a14  vmovaps [rsp+0xA0], xmm11
0000777bb65d4a1d  vmovaps [rsp+0xB0], xmm12
0000777bb65d4a26  vmovaps [rsp+0xC0], xmm13
0000777bb65d4a2f  vmovaps [rsp+0xD0], xmm14
0000777bb65d4a38  vmovaps [rsp+0xE0], xmm15
0000777bb65d4a41  sub rsp, 0x30
0000777bb65d4a45  movaps [rsp], xmm8
0000777bb65d4a4a  movaps [rsp+0x10], xmm14
0000777bb65d4a50  movaps [rsp+0x20], xmm9
0000777bb65d4a56  lea rdi, [rsp]
0000777bb65d4a5a  mov esi, 0x00
0000777bb65d4a5f  mov rax, 0x569DC437B530
0000777bb65d4a69  call rax
0000777bb65d4a6b  movaps xmm8, [rsp]
0000777bb65d4a70  add rsp, 0x30
0000777bb65d4a74  vmovaps xmm0, [rsp]
0000777bb65d4a79  vmovaps xmm1, [rsp+0x10]
0000777bb65d4a7f  vmovaps xmm2, [rsp+0x20]
0000777bb65d4a85  vmovaps xmm3, [rsp+0x30]
0000777bb65d4a8b  vmovaps xmm4, [rsp+0x40]
0000777bb65d4a91  vmovaps xmm5, [rsp+0x50]
0000777bb65d4a97  vmovaps xmm6, [rsp+0x60]
0000777bb65d4a9d  vmovaps xmm7, [rsp+0x70]
0000777bb65d4aa3  vmovaps xmm9, [rsp+0x80]
0000777bb65d4aac  vmovaps xmm10, [rsp+0x90]
0000777bb65d4ab5  vmovaps xmm11, [rsp+0xA0]
0000777bb65d4abe  vmovaps xmm12, [rsp+0xB0]
0000777bb65d4ac7  vmovaps xmm13, [rsp+0xC0]
0000777bb65d4ad0  vmovaps xmm14, [rsp+0xD0]
0000777bb65d4ad9  vmovaps xmm15, [rsp+0xE0]
0000777bb65d4ae2  add rsp, 0xF0
0000777bb65d4ae9  pop r11
0000777bb65d4aeb  pop r10
0000777bb65d4aed  pop r9
0000777bb65d4aef  pop r8
0000777bb65d4af1  pop rsi
0000777bb65d4af2  pop rdi
0000777bb65d4af3  pop rdx
0000777bb65d4af4  pop rcx
0000777bb65d4af5  pop rax
0000777bb65d4af6  add rsp, 0x08
0000777bb65d4afa  jmp 0x0000777BB65D01AF
0000777bb65d4aff  sub rsp, 0x08
0000777bb65d4b03  push rax
0000777bb65d4b04  push rcx
0000777bb65d4b05  push rdx
0000777bb65d4b06  push rdi
0000777bb65d4b07  push rsi
0000777bb65d4b08  push r8
0000777bb65d4b0a  push r9
0000777bb65d4b0c  push r10
0000777bb65d4b0e  push r11
0000777bb65d4b10  sub rsp, 0xF0
0000777bb65d4b17  vmovaps [rsp], xmm0
0000777bb65d4b1c  vmovaps [rsp+0x10], xmm1
0000777bb65d4b22  vmovaps [rsp+0x20], xmm2
0000777bb65d4b28  vmovaps [rsp+0x30], xmm3
0000777bb65d4b2e  vmovaps [rsp+0x40], xmm4
0000777bb65d4b34  vmovaps [rsp+0x50], xmm5
0000777bb65d4b3a  vmovaps [rsp+0x60], xmm6
0000777bb65d4b40  vmovaps [rsp+0x70], xmm7
0000777bb65d4b46  vmovaps [rsp+0x80], xmm8
0000777bb65d4b4f  vmovaps [rsp+0x90], xmm10
0000777bb65d4b58  vmovaps [rsp+0xA0], xmm11
0000777bb65d4b61  vmovaps [rsp+0xB0], xmm12
0000777bb65d4b6a  vmovaps [rsp+0xC0], xmm13
0000777bb65d4b73  vmovaps [rsp+0xD0], xmm14
0000777bb65d4b7c  vmovaps [rsp+0xE0], xmm15
0000777bb65d4b85  sub rsp, 0x30
0000777bb65d4b89  movaps [rsp], xmm9
0000777bb65d4b8e  movaps [rsp+0x10], xmm1
0000777bb65d4b93  movaps [rsp+0x20], xmm14
0000777bb65d4b99  lea rdi, [rsp]
0000777bb65d4b9d  mov esi, 0x00
0000777bb65d4ba2  mov rax, 0x569DC437B530
0000777bb65d4bac  call rax
0000777bb65d4bae  movaps xmm9, [rsp]
0000777bb65d4bb3  add rsp, 0x30
0000777bb65d4bb7  vmovaps xmm0, [rsp]
0000777bb65d4bbc  vmovaps xmm1, [rsp+0x10]
0000777bb65d4bc2  vmovaps xmm2, [rsp+0x20]
0000777bb65d4bc8  vmovaps xmm3, [rsp+0x30]
0000777bb65d4bce  vmovaps xmm4, [rsp+0x40]
0000777bb65d4bd4  vmovaps xmm5, [rsp+0x50]
0000777bb65d4bda  vmovaps xmm6, [rsp+0x60]
0000777bb65d4be0  vmovaps xmm7, [rsp+0x70]
0000777bb65d4be6  vmovaps xmm8, [rsp+0x80]
0000777bb65d4bef  vmovaps xmm10, [rsp+0x90]
0000777bb65d4bf8  vmovaps xmm11, [rsp+0xA0]
0000777bb65d4c01  vmovaps xmm12, [rsp+0xB0]
0000777bb65d4c0a  vmovaps xmm13, [rsp+0xC0]
0000777bb65d4c13  vmovaps xmm14, [rsp+0xD0]
0000777bb65d4c1c  vmovaps xmm15, [rsp+0xE0]
0000777bb65d4c25  add rsp, 0xF0
0000777bb65d4c2c  pop r11
0000777bb65d4c2e  pop r10
0000777bb65d4c30  pop r9
0000777bb65d4c32  pop r8
0000777bb65d4c34  pop rsi
0000777bb65d4c35  pop rdi
0000777bb65d4c36  pop rdx
0000777bb65d4c37  pop rcx
0000777bb65d4c38  pop rax
0000777bb65d4c39  add rsp, 0x08
0000777bb65d4c3d  jmp 0x0000777BB65D01DD
0000777bb65d4c42  sub rsp, 0x08
0000777bb65d4c46  push rax
0000777bb65d4c47  push rcx
0000777bb65d4c48  push rdx
0000777bb65d4c49  push rdi
0000777bb65d4c4a  push rsi
0000777bb65d4c4b  push r8
0000777bb65d4c4d  push r9
0000777bb65d4c4f  push r10
0000777bb65d4c51  push r11
0000777bb65d4c53  sub rsp, 0xF0
0000777bb65d4c5a  vmovaps [rsp], xmm0
0000777bb65d4c5f  vmovaps [rsp+0x10], xmm1
0000777bb65d4c65  vmovaps [rsp+0x20], xmm2
0000777bb65d4c6b  vmovaps [rsp+0x30], xmm3
0000777bb65d4c71  vmovaps [rsp+0x40], xmm4
0000777bb65d4c77  vmovaps [rsp+0x50], xmm5
0000777bb65d4c7d  vmovaps [rsp+0x60], xmm6
0000777bb65d4c83  vmovaps [rsp+0x70], xmm7
0000777bb65d4c89  vmovaps [rsp+0x80], xmm8
0000777bb65d4c92  vmovaps [rsp+0x90], xmm9
0000777bb65d4c9b  vmovaps [rsp+0xA0], xmm10
0000777bb65d4ca4  vmovaps [rsp+0xB0], xmm11
0000777bb65d4cad  vmovaps [rsp+0xC0], xmm12
0000777bb65d4cb6  vmovaps [rsp+0xD0], xmm13
0000777bb65d4cbf  vmovaps [rsp+0xE0], xmm15
0000777bb65d4cc8  sub rsp, 0x30
0000777bb65d4ccc  movaps [rsp], xmm14
0000777bb65d4cd1  movaps [rsp+0x10], xmm4
0000777bb65d4cd6  movaps [rsp+0x20], xmm1
0000777bb65d4cdb  lea rdi, [rsp]
0000777bb65d4cdf  mov esi, 0x00
0000777bb65d4ce4  mov rax, 0x569DC437B530
0000777bb65d4cee  call rax
0000777bb65d4cf0  movaps xmm14, [rsp]
0000777bb65d4cf5  add rsp, 0x30
0000777bb65d4cf9  vmovaps xmm0, [rsp]
0000777bb65d4cfe  vmovaps xmm1, [rsp+0x10]
0000777bb65d4d04  vmovaps xmm2, [rsp+0x20]
0000777bb65d4d0a  vmovaps xmm3, [rsp+0x30]
0000777bb65d4d10  vmovaps xmm4, [rsp+0x40]
0000777bb65d4d16  vmovaps xmm5, [rsp+0x50]
0000777bb65d4d1c  vmovaps xmm6, [rsp+0x60]
0000777bb65d4d22  vmovaps xmm7, [rsp+0x70]
0000777bb65d4d28  vmovaps xmm8, [rsp+0x80]
0000777bb65d4d31  vmovaps xmm9, [rsp+0x90]
0000777bb65d4d3a  vmovaps xmm10, [rsp+0xA0]
0000777bb65d4d43  vmovaps xmm11, [rsp+0xB0]
0000777bb65d4d4c  vmovaps xmm12, [rsp+0xC0]
0000777bb65d4d55  vmovaps xmm13, [rsp+0xD0]
0000777bb65d4d5e  vmovaps xmm15, [rsp+0xE0]
0000777bb65d4d67  add rsp, 0xF0
0000777bb65d4d6e  pop r11
0000777bb65d4d70  pop r10
0000777bb65d4d72  pop r9
0000777bb65d4d74  pop r8
0000777bb65d4d76  pop rsi
0000777bb65d4d77  pop rdi
0000777bb65d4d78  pop rdx
0000777bb65d4d79  pop rcx
0000777bb65d4d7a  pop rax
0000777bb65d4d7b  add rsp, 0x08
0000777bb65d4d7f  jmp 0x0000777BB65D0203
0000777bb65d4d84  sub rsp, 0x08
0000777bb65d4d88  push rax
0000777bb65d4d89  push rcx
0000777bb65d4d8a  push rdx
0000777bb65d4d8b  push rdi
0000777bb65d4d8c  push rsi
0000777bb65d4d8d  push r8
0000777bb65d4d8f  push r9
0000777bb65d4d91  push r10
0000777bb65d4d93  push r11
0000777bb65d4d95  sub rsp, 0xF0
0000777bb65d4d9c  vmovaps [rsp], xmm0
0000777bb65d4da1  vmovaps [rsp+0x10], xmm2
0000777bb65d4da7  vmovaps [rsp+0x20], xmm3
0000777bb65d4dad  vmovaps [rsp+0x30], xmm4
0000777bb65d4db3  vmovaps [rsp+0x40], xmm5
0000777bb65d4db9  vmovaps [rsp+0x50], xmm6
0000777bb65d4dbf  vmovaps [rsp+0x60], xmm7
0000777bb65d4dc5  vmovaps [rsp+0x70], xmm8
0000777bb65d4dcb  vmovaps [rsp+0x80], xmm9
0000777bb65d4dd4  vmovaps [rsp+0x90], xmm10
0000777bb65d4ddd  vmovaps [rsp+0xA0], xmm11
0000777bb65d4de6  vmovaps [rsp+0xB0], xmm12
0000777bb65d4def  vmovaps [rsp+0xC0], xmm13
0000777bb65d4df8  vmovaps [rsp+0xD0], xmm14
0000777bb65d4e01  vmovaps [rsp+0xE0], xmm15
0000777bb65d4e0a  sub rsp, 0x30
0000777bb65d4e0e  movaps [rsp], xmm1
0000777bb65d4e12  movaps [rsp+0x10], xmm12
0000777bb65d4e18  movaps [rsp+0x20], xmm11
0000777bb65d4e1e  lea rdi, [rsp]
0000777bb65d4e22  mov esi, 0x00
0000777bb65d4e27  mov rax, 0x569DC437B530
0000777bb65d4e31  call rax
0000777bb65d4e33  movaps xmm1, [rsp]
0000777bb65d4e37  add rsp, 0x30
0000777bb65d4e3b  vmovaps xmm0, [rsp]
0000777bb65d4e40  vmovaps xmm2, [rsp+0x10]
0000777bb65d4e46  vmovaps xmm3, [rsp+0x20]
0000777bb65d4e4c  vmovaps xmm4, [rsp+0x30]
0000777bb65d4e52  vmovaps xmm5, [rsp+0x40]
0000777bb65d4e58  vmovaps xmm6, [rsp+0x50]
0000777bb65d4e5e  vmovaps xmm7, [rsp+0x60]
0000777bb65d4e64  vmovaps xmm8, [rsp+0x70]
0000777bb65d4e6a  vmovaps xmm9, [rsp+0x80]
0000777bb65d4e73  vmovaps xmm10, [rsp+0x90]
0000777bb65d4e7c  vmovaps xmm11, [rsp+0xA0]
0000777bb65d4e85  vmovaps xmm12, [rsp+0xB0]
0000777bb65d4e8e  vmovaps xmm13, [rsp+0xC0]
0000777bb65d4e97  vmovaps xmm14, [rsp+0xD0]
0000777bb65d4ea0  vmovaps xmm15, [rsp+0xE0]
0000777bb65d4ea9  add rsp, 0xF0
0000777bb65d4eb0  pop r11
0000777bb65d4eb2  pop r10
0000777bb65d4eb4  pop r9
0000777bb65d4eb6  pop r8
0000777bb65d4eb8  pop rsi
0000777bb65d4eb9  pop rdi
0000777bb65d4eba  pop rdx
0000777bb65d4ebb  pop rcx
0000777bb65d4ebc  pop rax
0000777bb65d4ebd  add rsp, 0x08
0000777bb65d4ec1  jmp 0x0000777BB65D0224
0000777bb65d4ec6  call 0x0000777BB64E20A0
0000777bb65d4ecb  jmp 0x0000777BB65D0232
0000777bb65d4ed0  call 0x0000777BB6409D70
0000777bb65d4ed5  jmp 0x0000777BB65D023C
0000777bb65d4eda  sub rsp, 0x08
0000777bb65d4ede  push rax
0000777bb65d4edf  push rcx
0000777bb65d4ee0  push rdx
0000777bb65d4ee1  push rdi
0000777bb65d4ee2  push rsi
0000777bb65d4ee3  push r8
0000777bb65d4ee5  push r9
0000777bb65d4ee7  push r10
0000777bb65d4ee9  push r11
0000777bb65d4eeb  sub rsp, 0xF0
0000777bb65d4ef2  vmovaps [rsp], xmm0
0000777bb65d4ef7  vmovaps [rsp+0x10], xmm1
0000777bb65d4efd  vmovaps [rsp+0x20], xmm2
0000777bb65d4f03  vmovaps [rsp+0x30], xmm3
0000777bb65d4f09  vmovaps [rsp+0x40], xmm4
0000777bb65d4f0f  vmovaps [rsp+0x50], xmm5
0000777bb65d4f15  vmovaps [rsp+0x60], xmm6
0000777bb65d4f1b  vmovaps [rsp+0x70], xmm8
0000777bb65d4f21  vmovaps [rsp+0x80], xmm9
0000777bb65d4f2a  vmovaps [rsp+0x90], xmm10
0000777bb65d4f33  vmovaps [rsp+0xA0], xmm11
0000777bb65d4f3c  vmovaps [rsp+0xB0], xmm12
0000777bb65d4f45  vmovaps [rsp+0xC0], xmm13
0000777bb65d4f4e  vmovaps [rsp+0xD0], xmm14
0000777bb65d4f57  vmovaps [rsp+0xE0], xmm15
0000777bb65d4f60  sub rsp, 0x30
0000777bb65d4f64  movaps [rsp], xmm7
0000777bb65d4f68  movaps [rsp+0x10], xmm15
0000777bb65d4f6e  movaps [rsp+0x20], xmm10
0000777bb65d4f74  lea rdi, [rsp]
0000777bb65d4f78  mov esi, 0x00
0000777bb65d4f7d  mov rax, 0x569DC437B530
0000777bb65d4f87  call rax
0000777bb65d4f89  movaps xmm7, [rsp]
0000777bb65d4f8d  add rsp, 0x30
0000777bb65d4f91  vmovaps xmm0, [rsp]
0000777bb65d4f96  vmovaps xmm1, [rsp+0x10]
0000777bb65d4f9c  vmovaps xmm2, [rsp+0x20]
0000777bb65d4fa2  vmovaps xmm3, [rsp+0x30]
0000777bb65d4fa8  vmovaps xmm4, [rsp+0x40]
0000777bb65d4fae  vmovaps xmm5, [rsp+0x50]
0000777bb65d4fb4  vmovaps xmm6, [rsp+0x60]
0000777bb65d4fba  vmovaps xmm8, [rsp+0x70]
0000777bb65d4fc0  vmovaps xmm9, [rsp+0x80]
0000777bb65d4fc9  vmovaps xmm10, [rsp+0x90]
0000777bb65d4fd2  vmovaps xmm11, [rsp+0xA0]
0000777bb65d4fdb  vmovaps xmm12, [rsp+0xB0]
0000777bb65d4fe4  vmovaps xmm13, [rsp+0xC0]
0000777bb65d4fed  vmovaps xmm14, [rsp+0xD0]
0000777bb65d4ff6  vmovaps xmm15, [rsp+0xE0]
0000777bb65d4fff  add rsp, 0xF0
0000777bb65d5006  pop r11
0000777bb65d5008  pop r10
0000777bb65d500a  pop r9
0000777bb65d500c  pop r8
0000777bb65d500e  pop rsi
0000777bb65d500f  pop rdi
0000777bb65d5010  pop rdx
0000777bb65d5011  pop rcx
0000777bb65d5012  pop rax
0000777bb65d5013  add rsp, 0x08
0000777bb65d5017  jmp 0x0000777BB65D025D
0000777bb65d501c  sub rsp, 0x08
0000777bb65d5020  push rax
0000777bb65d5021  push rcx
0000777bb65d5022  push rdx
0000777bb65d5023  push rdi
0000777bb65d5024  push rsi
0000777bb65d5025  push r8
0000777bb65d5027  push r9
0000777bb65d5029  push r10
0000777bb65d502b  push r11
0000777bb65d502d  sub rsp, 0xF0
0000777bb65d5034  vmovaps [rsp], xmm0
0000777bb65d5039  vmovaps [rsp+0x10], xmm1
0000777bb65d503f  vmovaps [rsp+0x20], xmm2
0000777bb65d5045  vmovaps [rsp+0x30], xmm3
0000777bb65d504b  vmovaps [rsp+0x40], xmm4
0000777bb65d5051  vmovaps [rsp+0x50], xmm5
0000777bb65d5057  vmovaps [rsp+0x60], xmm6
0000777bb65d505d  vmovaps [rsp+0x70], xmm7
0000777bb65d5063  vmovaps [rsp+0x80], xmm8
0000777bb65d506c  vmovaps [rsp+0x90], xmm9
0000777bb65d5075  vmovaps [rsp+0xA0], xmm11
0000777bb65d507e  vmovaps [rsp+0xB0], xmm12
0000777bb65d5087  vmovaps [rsp+0xC0], xmm13
0000777bb65d5090  vmovaps [rsp+0xD0], xmm14
0000777bb65d5099  vmovaps [rsp+0xE0], xmm15
0000777bb65d50a2  sub rsp, 0x30
0000777bb65d50a6  movaps [rsp], xmm10
0000777bb65d50ab  movaps [rsp+0x10], xmm11
0000777bb65d50b1  movaps [rsp+0x20], xmm15
0000777bb65d50b7  lea rdi, [rsp]
0000777bb65d50bb  mov esi, 0x00
0000777bb65d50c0  mov rax, 0x569DC437B530
0000777bb65d50ca  call rax
0000777bb65d50cc  movaps xmm10, [rsp]
0000777bb65d50d1  add rsp, 0x30
0000777bb65d50d5  vmovaps xmm0, [rsp]
0000777bb65d50da  vmovaps xmm1, [rsp+0x10]
0000777bb65d50e0  vmovaps xmm2, [rsp+0x20]
0000777bb65d50e6  vmovaps xmm3, [rsp+0x30]
0000777bb65d50ec  vmovaps xmm4, [rsp+0x40]
0000777bb65d50f2  vmovaps xmm5, [rsp+0x50]
0000777bb65d50f8  vmovaps xmm6, [rsp+0x60]
0000777bb65d50fe  vmovaps xmm7, [rsp+0x70]
0000777bb65d5104  vmovaps xmm8, [rsp+0x80]
0000777bb65d510d  vmovaps xmm9, [rsp+0x90]
0000777bb65d5116  vmovaps xmm11, [rsp+0xA0]
0000777bb65d511f  vmovaps xmm12, [rsp+0xB0]
0000777bb65d5128  vmovaps xmm13, [rsp+0xC0]
0000777bb65d5131  vmovaps xmm14, [rsp+0xD0]
0000777bb65d513a  vmovaps xmm15, [rsp+0xE0]
0000777bb65d5143  add rsp, 0xF0
0000777bb65d514a  pop r11
0000777bb65d514c  pop r10
0000777bb65d514e  pop r9
0000777bb65d5150  pop r8
0000777bb65d5152  pop rsi
0000777bb65d5153  pop rdi
0000777bb65d5154  pop rdx
0000777bb65d5155  pop rcx
0000777bb65d5156  pop rax
0000777bb65d5157  add rsp, 0x08
0000777bb65d515b  jmp 0x0000777BB65D028B
0000777bb65d5160  sub rsp, 0x08
0000777bb65d5164  push rax
0000777bb65d5165  push rcx
0000777bb65d5166  push rdx
0000777bb65d5167  push rdi
0000777bb65d5168  push rsi
0000777bb65d5169  push r8
0000777bb65d516b  push r9
0000777bb65d516d  push r10
0000777bb65d516f  push r11
0000777bb65d5171  sub rsp, 0xF0
0000777bb65d5178  vmovaps [rsp], xmm0
0000777bb65d517d  vmovaps [rsp+0x10], xmm1
0000777bb65d5183  vmovaps [rsp+0x20], xmm2
0000777bb65d5189  vmovaps [rsp+0x30], xmm3
0000777bb65d518f  vmovaps [rsp+0x40], xmm4
0000777bb65d5195  vmovaps [rsp+0x50], xmm5
0000777bb65d519b  vmovaps [rsp+0x60], xmm6
0000777bb65d51a1  vmovaps [rsp+0x70], xmm7
0000777bb65d51a7  vmovaps [rsp+0x80], xmm8
0000777bb65d51b0  vmovaps [rsp+0x90], xmm9
0000777bb65d51b9  vmovaps [rsp+0xA0], xmm10
0000777bb65d51c2  vmovaps [rsp+0xB0], xmm12
0000777bb65d51cb  vmovaps [rsp+0xC0], xmm13
0000777bb65d51d4  vmovaps [rsp+0xD0], xmm14
0000777bb65d51dd  vmovaps [rsp+0xE0], xmm15
0000777bb65d51e6  sub rsp, 0x30
0000777bb65d51ea  movaps [rsp], xmm11
0000777bb65d51ef  movaps [rsp+0x10], xmm12
0000777bb65d51f5  movaps [rsp+0x20], xmm15
0000777bb65d51fb  lea rdi, [rsp]
0000777bb65d51ff  mov esi, 0x00
0000777bb65d5204  mov rax, 0x569DC437B530
0000777bb65d520e  call rax
0000777bb65d5210  movaps xmm11, [rsp]
0000777bb65d5215  add rsp, 0x30
0000777bb65d5219  vmovaps xmm0, [rsp]
0000777bb65d521e  vmovaps xmm1, [rsp+0x10]
0000777bb65d5224  vmovaps xmm2, [rsp+0x20]
0000777bb65d522a  vmovaps xmm3, [rsp+0x30]
0000777bb65d5230  vmovaps xmm4, [rsp+0x40]
0000777bb65d5236  vmovaps xmm5, [rsp+0x50]
0000777bb65d523c  vmovaps xmm6, [rsp+0x60]
0000777bb65d5242  vmovaps xmm7, [rsp+0x70]
0000777bb65d5248  vmovaps xmm8, [rsp+0x80]
0000777bb65d5251  vmovaps xmm9, [rsp+0x90]
0000777bb65d525a  vmovaps xmm10, [rsp+0xA0]
0000777bb65d5263  vmovaps xmm12, [rsp+0xB0]
0000777bb65d526c  vmovaps xmm13, [rsp+0xC0]
0000777bb65d5275  vmovaps xmm14, [rsp+0xD0]
0000777bb65d527e  vmovaps xmm15, [rsp+0xE0]
0000777bb65d5287  add rsp, 0xF0
0000777bb65d528e  pop r11
0000777bb65d5290  pop r10
0000777bb65d5292  pop r9
0000777bb65d5294  pop r8
0000777bb65d5296  pop rsi
0000777bb65d5297  pop rdi
0000777bb65d5298  pop rdx
0000777bb65d5299  pop rcx
0000777bb65d529a  pop rax
0000777bb65d529b  add rsp, 0x08
0000777bb65d529f  jmp 0x0000777BB65D02B9
0000777bb65d52a4  sub rsp, 0x08
0000777bb65d52a8  push rax
0000777bb65d52a9  push rcx
0000777bb65d52aa  push rdx
0000777bb65d52ab  push rdi
0000777bb65d52ac  push rsi
0000777bb65d52ad  push r8
0000777bb65d52af  push r9
0000777bb65d52b1  push r10
0000777bb65d52b3  push r11
0000777bb65d52b5  sub rsp, 0xF0
0000777bb65d52bc  vmovaps [rsp], xmm0
0000777bb65d52c1  vmovaps [rsp+0x10], xmm1
0000777bb65d52c7  vmovaps [rsp+0x20], xmm2
0000777bb65d52cd  vmovaps [rsp+0x30], xmm3
0000777bb65d52d3  vmovaps [rsp+0x40], xmm4
0000777bb65d52d9  vmovaps [rsp+0x50], xmm5
0000777bb65d52df  vmovaps [rsp+0x60], xmm6
0000777bb65d52e5  vmovaps [rsp+0x70], xmm7
0000777bb65d52eb  vmovaps [rsp+0x80], xmm8
0000777bb65d52f4  vmovaps [rsp+0x90], xmm9
0000777bb65d52fd  vmovaps [rsp+0xA0], xmm10
0000777bb65d5306  vmovaps [rsp+0xB0], xmm11
0000777bb65d530f  vmovaps [rsp+0xC0], xmm12
0000777bb65d5318  vmovaps [rsp+0xD0], xmm13
0000777bb65d5321  vmovaps [rsp+0xE0], xmm14
0000777bb65d532a  sub rsp, 0x30
0000777bb65d532e  movaps [rsp], xmm15
0000777bb65d5333  movaps [rsp+0x10], xmm13
0000777bb65d5339  movaps [rsp+0x20], xmm9
0000777bb65d533f  lea rdi, [rsp]
0000777bb65d5343  mov esi, 0x00
0000777bb65d5348  mov rax, 0x569DC437B530
0000777bb65d5352  call rax
0000777bb65d5354  movaps xmm15, [rsp]
0000777bb65d5359  add rsp, 0x30
0000777bb65d535d  vmovaps xmm0, [rsp]
0000777bb65d5362  vmovaps xmm1, [rsp+0x10]
0000777bb65d5368  vmovaps xmm2, [rsp+0x20]
0000777bb65d536e  vmovaps xmm3, [rsp+0x30]
0000777bb65d5374  vmovaps xmm4, [rsp+0x40]
0000777bb65d537a  vmovaps xmm5, [rsp+0x50]
0000777bb65d5380  vmovaps xmm6, [rsp+0x60]
0000777bb65d5386  vmovaps xmm7, [rsp+0x70]
0000777bb65d538c  vmovaps xmm8, [rsp+0x80]
0000777bb65d5395  vmovaps xmm9, [rsp+0x90]
0000777bb65d539e  vmovaps xmm10, [rsp+0xA0]
0000777bb65d53a7  vmovaps xmm11, [rsp+0xB0]
0000777bb65d53b0  vmovaps xmm12, [rsp+0xC0]
0000777bb65d53b9  vmovaps xmm13, [rsp+0xD0]
0000777bb65d53c2  vmovaps xmm14, [rsp+0xE0]
0000777bb65d53cb  add rsp, 0xF0
0000777bb65d53d2  pop r11
0000777bb65d53d4  pop r10
0000777bb65d53d6  pop r9
0000777bb65d53d8  pop r8
0000777bb65d53da  pop rsi
0000777bb65d53db  pop rdi
0000777bb65d53dc  pop rdx
0000777bb65d53dd  pop rcx
0000777bb65d53de  pop rax
0000777bb65d53df  add rsp, 0x08
0000777bb65d53e3  jmp 0x0000777BB65D02D4
0000777bb65d53e8  sub rsp, 0x08
0000777bb65d53ec  push rax
0000777bb65d53ed  push rcx
0000777bb65d53ee  push rdx
0000777bb65d53ef  push rdi
0000777bb65d53f0  push rsi
0000777bb65d53f1  push r8
0000777bb65d53f3  push r9
0000777bb65d53f5  push r10
0000777bb65d53f7  push r11
0000777bb65d53f9  sub rsp, 0xF0
0000777bb65d5400  vmovaps [rsp], xmm0
0000777bb65d5405  vmovaps [rsp+0x10], xmm1
0000777bb65d540b  vmovaps [rsp+0x20], xmm2
0000777bb65d5411  vmovaps [rsp+0x30], xmm3
0000777bb65d5417  vmovaps [rsp+0x40], xmm4
0000777bb65d541d  vmovaps [rsp+0x50], xmm5
0000777bb65d5423  vmovaps [rsp+0x60], xmm6
0000777bb65d5429  vmovaps [rsp+0x70], xmm7
0000777bb65d542f  vmovaps [rsp+0x80], xmm8
0000777bb65d5438  vmovaps [rsp+0x90], xmm9
0000777bb65d5441  vmovaps [rsp+0xA0], xmm10
0000777bb65d544a  vmovaps [rsp+0xB0], xmm11
0000777bb65d5453  vmovaps [rsp+0xC0], xmm12
0000777bb65d545c  vmovaps [rsp+0xD0], xmm14
0000777bb65d5465  vmovaps [rsp+0xE0], xmm15
0000777bb65d546e  sub rsp, 0x30
0000777bb65d5472  movaps [rsp], xmm13
0000777bb65d5477  movaps [rsp+0x10], xmm8
0000777bb65d547d  movaps [rsp+0x20], xmm14
0000777bb65d5483  lea rdi, [rsp]
0000777bb65d5487  mov esi, 0x00
0000777bb65d548c  mov rax, 0x569DC437B530
0000777bb65d5496  call rax
0000777bb65d5498  movaps xmm13, [rsp]
0000777bb65d549d  add rsp, 0x30
0000777bb65d54a1  vmovaps xmm0, [rsp]
0000777bb65d54a6  vmovaps xmm1, [rsp+0x10]
0000777bb65d54ac  vmovaps xmm2, [rsp+0x20]
0000777bb65d54b2  vmovaps xmm3, [rsp+0x30]
0000777bb65d54b8  vmovaps xmm4, [rsp+0x40]
0000777bb65d54be  vmovaps xmm5, [rsp+0x50]
0000777bb65d54c4  vmovaps xmm6, [rsp+0x60]
0000777bb65d54ca  vmovaps xmm7, [rsp+0x70]
0000777bb65d54d0  vmovaps xmm8, [rsp+0x80]
0000777bb65d54d9  vmovaps xmm9, [rsp+0x90]
0000777bb65d54e2  vmovaps xmm10, [rsp+0xA0]
0000777bb65d54eb  vmovaps xmm11, [rsp+0xB0]
0000777bb65d54f4  vmovaps xmm12, [rsp+0xC0]
0000777bb65d54fd  vmovaps xmm14, [rsp+0xD0]
0000777bb65d5506  vmovaps xmm15, [rsp+0xE0]
0000777bb65d550f  add rsp, 0xF0
0000777bb65d5516  pop r11
0000777bb65d5518  pop r10
0000777bb65d551a  pop r9
0000777bb65d551c  pop r8
0000777bb65d551e  pop rsi
0000777bb65d551f  pop rdi
0000777bb65d5520  pop rdx
0000777bb65d5521  pop rcx
0000777bb65d5522  pop rax
0000777bb65d5523  add rsp, 0x08
0000777bb65d5527  jmp 0x0000777BB65D02F7
0000777bb65d552c  sub rsp, 0x08
0000777bb65d5530  push rax
0000777bb65d5531  push rcx
0000777bb65d5532  push rdx
0000777bb65d5533  push rdi
0000777bb65d5534  push rsi
0000777bb65d5535  push r8
0000777bb65d5537  push r9
0000777bb65d5539  push r10
0000777bb65d553b  push r11
0000777bb65d553d  sub rsp, 0xF0
0000777bb65d5544  vmovaps [rsp], xmm0
0000777bb65d5549  vmovaps [rsp+0x10], xmm1
0000777bb65d554f  vmovaps [rsp+0x20], xmm2
0000777bb65d5555  vmovaps [rsp+0x30], xmm3
0000777bb65d555b  vmovaps [rsp+0x40], xmm4
0000777bb65d5561  vmovaps [rsp+0x50], xmm5
0000777bb65d5567  vmovaps [rsp+0x60], xmm6
0000777bb65d556d  vmovaps [rsp+0x70], xmm7
0000777bb65d5573  vmovaps [rsp+0x80], xmm8
0000777bb65d557c  vmovaps [rsp+0x90], xmm9
0000777bb65d5585  vmovaps [rsp+0xA0], xmm10
0000777bb65d558e  vmovaps [rsp+0xB0], xmm11
0000777bb65d5597  vmovaps [rsp+0xC0], xmm12
0000777bb65d55a0  vmovaps [rsp+0xD0], xmm13
0000777bb65d55a9  vmovaps [rsp+0xE0], xmm15
0000777bb65d55b2  sub rsp, 0x30
0000777bb65d55b6  movaps [rsp], xmm14
0000777bb65d55bb  movaps [rsp+0x10], xmm1
0000777bb65d55c0  movaps [rsp+0x20], xmm10
0000777bb65d55c6  lea rdi, [rsp]
0000777bb65d55ca  mov esi, 0x00
0000777bb65d55cf  mov rax, 0x569DC437B530
0000777bb65d55d9  call rax
0000777bb65d55db  movaps xmm14, [rsp]
0000777bb65d55e0  add rsp, 0x30
0000777bb65d55e4  vmovaps xmm0, [rsp]
0000777bb65d55e9  vmovaps xmm1, [rsp+0x10]
0000777bb65d55ef  vmovaps xmm2, [rsp+0x20]
0000777bb65d55f5  vmovaps xmm3, [rsp+0x30]
0000777bb65d55fb  vmovaps xmm4, [rsp+0x40]
0000777bb65d5601  vmovaps xmm5, [rsp+0x50]
0000777bb65d5607  vmovaps xmm6, [rsp+0x60]
0000777bb65d560d  vmovaps xmm7, [rsp+0x70]
0000777bb65d5613  vmovaps xmm8, [rsp+0x80]
0000777bb65d561c  vmovaps xmm9, [rsp+0x90]
0000777bb65d5625  vmovaps xmm10, [rsp+0xA0]
0000777bb65d562e  vmovaps xmm11, [rsp+0xB0]
0000777bb65d5637  vmovaps xmm12, [rsp+0xC0]
0000777bb65d5640  vmovaps xmm13, [rsp+0xD0]
0000777bb65d5649  vmovaps xmm15, [rsp+0xE0]
0000777bb65d5652  add rsp, 0xF0
0000777bb65d5659  pop r11
0000777bb65d565b  pop r10
0000777bb65d565d  pop r9
0000777bb65d565f  pop r8
0000777bb65d5661  pop rsi
0000777bb65d5662  pop rdi
0000777bb65d5663  pop rdx
0000777bb65d5664  pop rcx
0000777bb65d5665  pop rax
0000777bb65d5666  add rsp, 0x08
0000777bb65d566a  jmp 0x0000777BB65D031A
0000777bb65d566f  sub rsp, 0x08
0000777bb65d5673  push rax
0000777bb65d5674  push rcx
0000777bb65d5675  push rdx
0000777bb65d5676  push rdi
0000777bb65d5677  push rsi
0000777bb65d5678  push r8
0000777bb65d567a  push r9
0000777bb65d567c  push r10
0000777bb65d567e  push r11
0000777bb65d5680  sub rsp, 0xF0
0000777bb65d5687  vmovaps [rsp], xmm0
0000777bb65d568c  vmovaps [rsp+0x10], xmm2
0000777bb65d5692  vmovaps [rsp+0x20], xmm3
0000777bb65d5698  vmovaps [rsp+0x30], xmm4
0000777bb65d569e  vmovaps [rsp+0x40], xmm5
0000777bb65d56a4  vmovaps [rsp+0x50], xmm6
0000777bb65d56aa  vmovaps [rsp+0x60], xmm7
0000777bb65d56b0  vmovaps [rsp+0x70], xmm8
0000777bb65d56b6  vmovaps [rsp+0x80], xmm9
0000777bb65d56bf  vmovaps [rsp+0x90], xmm10
0000777bb65d56c8  vmovaps [rsp+0xA0], xmm11
0000777bb65d56d1  vmovaps [rsp+0xB0], xmm12
0000777bb65d56da  vmovaps [rsp+0xC0], xmm13
0000777bb65d56e3  vmovaps [rsp+0xD0], xmm14
0000777bb65d56ec  vmovaps [rsp+0xE0], xmm15
0000777bb65d56f5  sub rsp, 0x30
0000777bb65d56f9  movaps [rsp], xmm1
0000777bb65d56fd  movaps [rsp+0x10], xmm7
0000777bb65d5702  movaps [rsp+0x20], xmm11
0000777bb65d5708  lea rdi, [rsp]
0000777bb65d570c  mov esi, 0x00
0000777bb65d5711  mov rax, 0x569DC437B530
0000777bb65d571b  call rax
0000777bb65d571d  movaps xmm1, [rsp]
0000777bb65d5721  add rsp, 0x30
0000777bb65d5725  vmovaps xmm0, [rsp]
0000777bb65d572a  vmovaps xmm2, [rsp+0x10]
0000777bb65d5730  vmovaps xmm3, [rsp+0x20]
0000777bb65d5736  vmovaps xmm4, [rsp+0x30]
0000777bb65d573c  vmovaps xmm5, [rsp+0x40]
0000777bb65d5742  vmovaps xmm6, [rsp+0x50]
0000777bb65d5748  vmovaps xmm7, [rsp+0x60]
0000777bb65d574e  vmovaps xmm8, [rsp+0x70]
0000777bb65d5754  vmovaps xmm9, [rsp+0x80]
0000777bb65d575d  vmovaps xmm10, [rsp+0x90]
0000777bb65d5766  vmovaps xmm11, [rsp+0xA0]
0000777bb65d576f  vmovaps xmm12, [rsp+0xB0]
0000777bb65d5778  vmovaps xmm13, [rsp+0xC0]
0000777bb65d5781  vmovaps xmm14, [rsp+0xD0]
0000777bb65d578a  vmovaps xmm15, [rsp+0xE0]
0000777bb65d5793  add rsp, 0xF0
0000777bb65d579a  pop r11
0000777bb65d579c  pop r10
0000777bb65d579e  pop r9
0000777bb65d57a0  pop r8
0000777bb65d57a2  pop rsi
0000777bb65d57a3  pop rdi
0000777bb65d57a4  pop rdx
0000777bb65d57a5  pop rcx
0000777bb65d57a6  pop rax
0000777bb65d57a7  add rsp, 0x08
0000777bb65d57ab  jmp 0x0000777BB65D033B
0000777bb65d57b0  call 0x0000777BB640E880
0000777bb65d57b5  jmp 0x0000777BB65D034E
0000777bb65d57ba  call 0x0000777BB640C380
0000777bb65d57bf  jmp 0x0000777BB65D0359
0000777bb65d57c4  call 0x0000777BB640D600
0000777bb65d57c9  jmp 0x0000777BB65D0364
0000777bb65d57ce  call 0x0000777BB63FF540
0000777bb65d57d3  jmp 0x0000777BB65D036F
0000777bb65d57d8  int3
0000777bb65d57d9  nop [rax], eax
0000777bb65d57e0  mov rax, [r15+0x40]
0000777bb65d57e4  mov r14, [r15+0x58]
0000777bb65d57e8  lea r12, [rax+r14*1]
0000777bb65d57ec  movaps xmm1, [r15+0x1D0]
0000777bb65d57f4  vmovaps [rsp+0x10], xmm1
0000777bb65d57fa  vmovaps xmm15, [rsp+0x10]
0000777bb65d5800  por xmm1, xmm15
0000777bb65d5805  movaps xmm14, [r15+0x1A0]
0000777bb65d580d  vmovaps [rsp+0x10], xmm14
0000777bb65d5813  vmovaps xmm13, [rsp+0x10]
0000777bb65d5819  por xmm14, xmm13
0000777bb65d581e  lea rax, [r12+0x30]
0000777bb65d5823  mov r11, [r13+rax*1]
0000777bb65d5828  lea rax, [r12+0x38]
0000777bb65d582d  mov r10, [r13+rax*1]
0000777bb65d5832  movq xmm13, r11
0000777bb65d5837  movq xmm12, r10
0000777bb65d583c  movq xmm13, xmm13
0000777bb65d5841  vmovaps [rsp+0x10], xmm13
0000777bb65d5847  movq xmm13, xmm13
0000777bb65d584c  movaps [r15+0x130], xmm13
0000777bb65d5854  movq xmm12, xmm12
0000777bb65d5859  vmovaps [rsp+0x20], xmm12
0000777bb65d585f  movq xmm12, xmm12
0000777bb65d5864  movaps [r15+0x280], xmm12
0000777bb65d586c  movaps xmm13, [r15+0x270]
0000777bb65d5874  vmovaps [rsp+0x30], xmm13
0000777bb65d587a  vmovaps xmm12, [rsp+0x30]
0000777bb65d5880  por xmm13, xmm12
0000777bb65d5885  lea rax, [r12+0x20]
0000777bb65d588a  mov r11, [r13+rax*1]
0000777bb65d588f  lea rax, [r12+0x28]
0000777bb65d5894  mov r10, [r13+rax*1]
0000777bb65d5899  movq xmm12, r11
0000777bb65d589e  movq xmm11, r10
0000777bb65d58a3  movq xmm12, xmm12
0000777bb65d58a8  vmovaps [rsp+0x30], xmm12
0000777bb65d58ae  movq xmm12, xmm12
0000777bb65d58b3  movaps [r15+0x150], xmm12
0000777bb65d58bb  movq xmm11, xmm11
0000777bb65d58c0  vmovaps [rsp+0x40], xmm11
0000777bb65d58c6  movq xmm11, xmm11
0000777bb65d58cb  movaps [r15+0x140], xmm11
0000777bb65d58d3  lea rax, [r12+0x10]
0000777bb65d58d8  mov r11, [r13+rax*1]
0000777bb65d58dd  lea rax, [r12+0x18]
0000777bb65d58e2  mov r10, [r13+rax*1]
0000777bb65d58e7  movq xmm12, r11
0000777bb65d58ec  movq xmm11, r10
0000777bb65d58f1  movq xmm12, xmm12
0000777bb65d58f6  vmovaps [rsp+0x50], xmm12
0000777bb65d58fc  movq xmm12, xmm12
0000777bb65d5901  movaps [r15+0x170], xmm12
0000777bb65d5909  movq xmm11, xmm11
0000777bb65d590e  vmovaps [rsp+0x60], xmm11
0000777bb65d5914  movq xmm11, xmm11
0000777bb65d5919  movaps [r15+0x160], xmm11
0000777bb65d5921  mov rax, [r13+r12*1]
0000777bb65d5926  vmovq xmm12, rax
0000777bb65d592b  vpbroadcastq xmm12, xmm12
0000777bb65d5930  lea rax, [r12+0x08]
0000777bb65d5935  mov r12, [r13+rax*1]
0000777bb65d593a  movq xmm11, r12
0000777bb65d593f  movaps [r15+0x230], xmm11
0000777bb65d5947  mov rax, [r15+0xF8]
0000777bb65d594e  lea r12, [rax+0x50]
0000777bb65d5952  movups xmm11, [r13+r12*1]
0000777bb65d5958  lea r12, [rax+0x60]
0000777bb65d595c  movups xmm10, [r13+r12*1]
0000777bb65d5962  lea r12, [rax+0x30]
0000777bb65d5966  movups xmm9, [r13+r12*1]
0000777bb65d596c  mov r12, [r15+0x50]
0000777bb65d5970  lea r11, [r12+r14*1]
0000777bb65d5974  mov [r15+0x60], r11
0000777bb65d5978  lea r12, [r14+0x40]
0000777bb65d597c  mov [r15+0x58], r12
0000777bb65d5980  movaps xmm8, xmm12
0000777bb65d5984  mulpd xmm8, xmm15
0000777bb65d5989  vcmppd xmm7, xmm8, xmm8, 0x03
0000777bb65d598f  ptest xmm7, xmm7
0000777bb65d5994  jnz 0x0000777BB65D67B7
0000777bb65d599a  movq xmm15, qword ptr [r15+0x230]
0000777bb65d59a3  vmovaps [rsp+0x70], xmm15
0000777bb65d59a9  vpermilpd xmm15, xmm15, 0x00
0000777bb65d59af  movaps xmm7, xmm9
0000777bb65d59b3  mulpd xmm7, xmm15
0000777bb65d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
0000777bb65d59bd  ptest xmm6, xmm6
0000777bb65d59c2  jnz 0x0000777BB65D68FB
0000777bb65d59c8  vxorps xmm15, xmm15, xmm15
0000777bb65d59cd  vpbroadcastq xmm15, xmm15
0000777bb65d59d2  movaps xmm9, xmm12
0000777bb65d59d6  mulpd xmm9, xmm10
0000777bb65d59db  vcmppd xmm6, xmm9, xmm9, 0x03
0000777bb65d59e1  ptest xmm6, xmm6
0000777bb65d59e6  jnz 0x0000777BB65D6A3D
0000777bb65d59ec  movaps xmm10, xmm12
0000777bb65d59f0  mulpd xmm10, xmm11
0000777bb65d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
0000777bb65d59fb  ptest xmm6, xmm6
0000777bb65d5a00  jnz 0x0000777BB65D6B81
0000777bb65d5a06  movaps xmm11, [r15+0x1F0]
0000777bb65d5a0e  movaps xmm6, xmm12
0000777bb65d5a12  mulpd xmm6, xmm11
0000777bb65d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
0000777bb65d5a1c  ptest xmm5, xmm5
0000777bb65d5a21  jnz 0x0000777BB65D6CC5
0000777bb65d5a27  movaps xmm12, [r15+0x2A0]
0000777bb65d5a2f  vmovaps [rsp+0x80], xmm12
0000777bb65d5a38  vmovaps xmm11, [rsp+0x80]
0000777bb65d5a41  por xmm12, xmm11
0000777bb65d5a46  movaps xmm11, [r15+0x250]
0000777bb65d5a4e  vmovaps [rsp+0x80], xmm11
0000777bb65d5a57  vmovaps xmm5, [rsp+0x80]
0000777bb65d5a60  por xmm11, xmm5
0000777bb65d5a65  vmovaps xmm4, [rsp+0x70]
0000777bb65d5a6b  vpermilpd xmm4, xmm4, 0x00
0000777bb65d5a71  movaps xmm3, xmm5
0000777bb65d5a74  mulpd xmm3, xmm4
0000777bb65d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
0000777bb65d5a7d  ptest xmm2, xmm2
0000777bb65d5a82  jnz 0x0000777BB65D6E07
0000777bb65d5a88  mov [rsp+0x80], rax
0000777bb65d5a90  xor eax, eax
0000777bb65d5a92  mov r14d, 0x200
0000777bb65d5a98  cmp r12, r14
0000777bb65d5a9b  cmc
0000777bb65d5a9c  lahf
0000777bb65d5a9d  seto al
0000777bb65d5aa0  mov [r15+0x108], eax
0000777bb65d5aa7  movaps xmm5, xmm8
0000777bb65d5aab  addpd xmm5, xmm15
0000777bb65d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
0000777bb65d5ab5  ptest xmm4, xmm4
0000777bb65d5aba  jnz 0x0000777BB65D6F47
0000777bb65d5ac0  movaps xmm8, [r15+0x1B0]
0000777bb65d5ac8  movaps xmm4, xmm9
0000777bb65d5acc  addpd xmm4, xmm8
0000777bb65d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
0000777bb65d5ad6  ptest xmm2, xmm2
0000777bb65d5adb  jnz 0x0000777BB65D7089
0000777bb65d5ae1  movaps xmm9, xmm10
0000777bb65d5ae5  addpd xmm9, xmm8
0000777bb65d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
0000777bb65d5af0  ptest xmm2, xmm2
0000777bb65d5af5  jnz 0x0000777BB65D71CB
0000777bb65d5afb  movaps xmm10, [r15+0x2F0]
0000777bb65d5b03  vmovaps [rsp+0x90], xmm10
0000777bb65d5b0c  vmovaps xmm8, [rsp+0x90]
0000777bb65d5b15  por xmm10, xmm8
0000777bb65d5b1a  movaps xmm8, [r15+0x2E0]
0000777bb65d5b22  vmovaps [rsp+0x90], xmm8
0000777bb65d5b2b  vmovaps xmm2, [rsp+0x90]
0000777bb65d5b34  por xmm8, xmm2
0000777bb65d5b39  movaps xmm2, [r15+0x2D0]
0000777bb65d5b41  vmovaps [rsp+0x90], xmm2
0000777bb65d5b4a  vmovaps [rsp+0xA0], xmm1
0000777bb65d5b53  vmovaps xmm1, [rsp+0x90]
0000777bb65d5b5c  por xmm2, xmm1
0000777bb65d5b60  movaps xmm1, [r15+0x200]
0000777bb65d5b68  vmovaps [rsp+0x90], xmm1
0000777bb65d5b71  vmovaps [rsp+0xB0], xmm15
0000777bb65d5b7a  vmovaps xmm15, [rsp+0x90]
0000777bb65d5b83  por xmm1, xmm15
0000777bb65d5b88  movaps xmm15, [r15+0x1C0]
0000777bb65d5b90  vmovaps [rsp+0x90], xmm15
0000777bb65d5b99  vmovaps [rsp+0xC0], xmm1
0000777bb65d5ba2  vmovaps xmm1, [rsp+0x90]
0000777bb65d5bab  por xmm15, xmm1
0000777bb65d5bb0  movaps xmm1, [r15+0x190]
0000777bb65d5bb8  vmovaps [rsp+0x90], xmm1
0000777bb65d5bc1  vmovaps [rsp+0xD0], xmm15
0000777bb65d5bca  vmovaps xmm15, [rsp+0x90]
0000777bb65d5bd3  por xmm1, xmm15
0000777bb65d5bd8  movaps xmm15, [r15+0x300]
0000777bb65d5be0  vmovaps [rsp+0x90], xmm15
0000777bb65d5be9  vmovaps [rsp+0xE0], xmm1
0000777bb65d5bf2  vmovaps xmm1, [rsp+0x90]
0000777bb65d5bfb  por xmm15, xmm1
0000777bb65d5c00  mov rax, [rsp+0x80]
0000777bb65d5c08  lea r14, [rax+0xA0]
0000777bb65d5c0f  movups xmm1, [r13+r14*1]
0000777bb65d5c15  lea r14, [rax+0xB0]
0000777bb65d5c1c  vmovaps [rsp+0x80], xmm1
0000777bb65d5c25  movups xmm1, [r13+r14*1]
0000777bb65d5c2b  vmovaps [rsp+0x90], xmm1
0000777bb65d5c34  vmovaps [rsp+0xF0], xmm15
0000777bb65d5c3d  vmovaps xmm15, [rsp+0xB0]
0000777bb65d5c46  vmovaps [rsp+0xB0], xmm14
0000777bb65d5c4f  movaps xmm1, xmm6
0000777bb65d5c52  addpd xmm1, xmm15
0000777bb65d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
0000777bb65d5c5c  ptest xmm14, xmm14
0000777bb65d5c62  jnz 0x0000777BB65D7323
0000777bb65d5c68  lea r14, [rax+0xF0]
0000777bb65d5c6f  movups xmm15, [r13+r14*1]
0000777bb65d5c75  movaps xmm14, xmm4
0000777bb65d5c79  addpd xmm14, xmm3
0000777bb65d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
0000777bb65d5c84  ptest xmm6, xmm6
0000777bb65d5c89  jnz 0x0000777BB65D746E
0000777bb65d5c8f  movaps xmm6, xmm9
0000777bb65d5c93  addpd xmm6, xmm7
0000777bb65d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
0000777bb65d5c9c  ptest xmm4, xmm4
0000777bb65d5ca1  jnz 0x0000777BB65D75B0
0000777bb65d5ca7  vmovaps xmm9, [rsp+0x70]
0000777bb65d5cad  vpermilpd xmm9, xmm9, 0x00
0000777bb65d5cb3  vmovaps xmm4, [rsp+0x90]
0000777bb65d5cbc  movaps xmm7, xmm4
0000777bb65d5cbf  mulpd xmm7, xmm9
0000777bb65d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
0000777bb65d5cc9  ptest xmm3, xmm3
0000777bb65d5cce  jnz 0x0000777BB65D76F1
0000777bb65d5cd4  vmovaps xmm9, [rsp+0x50]
0000777bb65d5cda  vpermilpd xmm9, xmm9, 0x00
0000777bb65d5ce0  movaps xmm4, xmm15
0000777bb65d5ce4  mulpd xmm4, xmm9
0000777bb65d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
0000777bb65d5cee  ptest xmm3, xmm3
0000777bb65d5cf3  jnz 0x0000777BB65D7832
0000777bb65d5cf9  lea r14, [rax+0xE0]
0000777bb65d5d00  movups xmm15, [r13+r14*1]
0000777bb65d5d06  vmovaps xmm9, [rsp+0x70]
0000777bb65d5d0c  vpermilpd xmm9, xmm9, 0x00
0000777bb65d5d12  vmovaps [rsp+0x70], xmm1
0000777bb65d5d18  vmovaps xmm1, [rsp+0x80]
0000777bb65d5d21  vmovaps [rsp+0x80], xmm15
0000777bb65d5d2a  movaps xmm3, xmm1
0000777bb65d5d2d  mulpd xmm3, xmm9
0000777bb65d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
0000777bb65d5d37  ptest xmm15, xmm15
0000777bb65d5d3d  jnz 0x0000777BB65D797E
0000777bb65d5d43  vmovaps xmm1, [rsp+0xF0]
0000777bb65d5d4c  vmovaps xmm15, [rsp+0xF0]
0000777bb65d5d55  por xmm1, xmm15
0000777bb65d5d5a  movaps [r15+0x300], xmm1
0000777bb65d5d62  vmovaps xmm15, [rsp+0xE0]
0000777bb65d5d6b  vmovaps xmm9, [rsp+0xE0]
0000777bb65d5d74  por xmm15, xmm9
0000777bb65d5d79  movaps [r15+0x190], xmm15
0000777bb65d5d81  vmovaps xmm9, [rsp+0x50]
0000777bb65d5d87  vpermilpd xmm9, xmm9, 0x00
0000777bb65d5d8d  vmovaps [rsp+0x90], xmm1
0000777bb65d5d96  vmovaps [rsp+0xE0], xmm15
0000777bb65d5d9f  vmovaps xmm15, [rsp+0x80]
0000777bb65d5da8  vmovaps [rsp+0x80], xmm14
0000777bb65d5db1  movaps xmm1, xmm15
0000777bb65d5db5  mulpd xmm1, xmm9
0000777bb65d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
0000777bb65d5dbf  ptest xmm14, xmm14
0000777bb65d5dc5  jnz 0x0000777BB65D7ABF
0000777bb65d5dcb  lea r14, [rax+0x90]
0000777bb65d5dd2  movups xmm15, [r13+r14*1]
0000777bb65d5dd8  vmovaps xmm14, [rsp+0xD0]
0000777bb65d5de1  vmovaps xmm9, [rsp+0xD0]
0000777bb65d5dea  por xmm14, xmm9
0000777bb65d5def  movaps [r15+0x1C0], xmm14
0000777bb65d5df7  vmovaps xmm9, [rsp+0xC0]
0000777bb65d5e00  vmovaps [rsp+0xD0], xmm1
0000777bb65d5e09  vmovaps xmm1, [rsp+0xC0]
0000777bb65d5e12  por xmm9, xmm1
0000777bb65d5e17  movaps [r15+0x200], xmm9
0000777bb65d5e1f  vmovaps [rsp+0xC0], xmm2
0000777bb65d5e28  vmovaps xmm1, [rsp+0xC0]
0000777bb65d5e31  por xmm2, xmm1
0000777bb65d5e35  movaps [r15+0x2D0], xmm2
0000777bb65d5e3d  vmovaps [rsp+0xC0], xmm8
0000777bb65d5e46  vmovaps xmm1, [rsp+0xC0]
0000777bb65d5e4f  por xmm8, xmm1
0000777bb65d5e54  movaps [r15+0x2E0], xmm8
0000777bb65d5e5c  vmovaps [rsp+0xC0], xmm15
0000777bb65d5e65  movaps xmm1, xmm5
0000777bb65d5e68  addpd xmm1, xmm7
0000777bb65d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
0000777bb65d5e71  ptest xmm15, xmm15
0000777bb65d5e77  jnz 0x0000777BB65D7C0B
0000777bb65d5e7d  vmovaps xmm15, [rsp+0x50]
0000777bb65d5e83  vpermilpd xmm15, xmm15, 0x00
0000777bb65d5e89  vmovaps xmm5, [rsp+0xC0]
0000777bb65d5e92  vmovaps [rsp+0xC0], xmm1
0000777bb65d5e9b  movaps xmm7, xmm5
0000777bb65d5e9e  mulpd xmm7, xmm15
0000777bb65d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
0000777bb65d5ea8  ptest xmm1, xmm1
0000777bb65d5ead  jnz 0x0000777BB65D7D4B
0000777bb65d5eb3  lea r14, [rax+0x80]
0000777bb65d5eba  movups xmm1, [r13+r14*1]
0000777bb65d5ec0  vmovaps xmm5, [rsp+0x70]
0000777bb65d5ec6  vmovaps [rsp+0x70], xmm1
0000777bb65d5ecc  movaps xmm15, xmm5
0000777bb65d5ed0  addpd xmm15, xmm3
0000777bb65d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
0000777bb65d5edb  ptest xmm1, xmm1
0000777bb65d5ee0  jnz 0x0000777BB65D7E96
0000777bb65d5ee6  vmovaps xmm5, [rsp+0x80]
0000777bb65d5eef  movaps xmm1, xmm5
0000777bb65d5ef2  addpd xmm1, xmm4
0000777bb65d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
0000777bb65d5efb  ptest xmm3, xmm3
0000777bb65d5f00  jnz 0x0000777BB65D7FD8
0000777bb65d5f06  vmovaps [rsp+0x80], xmm10
0000777bb65d5f0f  vmovaps xmm5, [rsp+0x80]
0000777bb65d5f18  por xmm10, xmm5
0000777bb65d5f1d  movaps [r15+0x2F0], xmm10
0000777bb65d5f25  vmovaps xmm5, [rsp+0x50]
0000777bb65d5f2b  vpermilpd xmm5, xmm5, 0x00
0000777bb65d5f31  vmovaps xmm3, [rsp+0x70]
0000777bb65d5f37  vmovaps [rsp+0x50], xmm1
0000777bb65d5f3d  movaps xmm4, xmm3
0000777bb65d5f40  mulpd xmm4, xmm5
0000777bb65d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
0000777bb65d5f49  ptest xmm1, xmm1
0000777bb65d5f4e  jnz 0x0000777BB65D8118
0000777bb65d5f54  lea r14, [rax+0xD0]
0000777bb65d5f5b  movups xmm1, [r13+r14*1]
0000777bb65d5f61  vmovaps xmm3, [rsp+0xD0]
0000777bb65d5f6a  vmovaps [rsp+0x70], xmm1
0000777bb65d5f70  movaps xmm5, xmm6
0000777bb65d5f73  addpd xmm5, xmm3
0000777bb65d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
0000777bb65d5f7c  ptest xmm1, xmm1
0000777bb65d5f81  jnz 0x0000777BB65D8262
0000777bb65d5f87  vmovaps xmm1, [rsp+0x60]
0000777bb65d5f8d  vpermilpd xmm1, xmm1, 0x00
0000777bb65d5f93  movaps xmm6, xmm9
0000777bb65d5f97  mulpd xmm6, xmm1
0000777bb65d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
0000777bb65d5fa0  ptest xmm3, xmm3
0000777bb65d5fa5  jnz 0x0000777BB65D83A2
0000777bb65d5fab  movaps [r15+0x260], xmm6
0000777bb65d5fb3  vxorps xmm1, xmm1, xmm1
0000777bb65d5fb7  vpbroadcastq xmm1, xmm1
0000777bb65d5fbc  movaps [r15+0x1B0], xmm1
0000777bb65d5fc4  vmovaps xmm1, [rsp+0x60]
0000777bb65d5fca  vpermilpd xmm1, xmm1, 0x00
0000777bb65d5fd0  vmovaps xmm3, [rsp+0x70]
0000777bb65d5fd6  vmovaps [rsp+0x70], xmm15
0000777bb65d5fdc  movaps xmm9, xmm3
0000777bb65d5fe0  mulpd xmm9, xmm1
0000777bb65d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
0000777bb65d5feb  ptest xmm15, xmm15
0000777bb65d5ff1  jnz 0x0000777BB65D84E3
0000777bb65d5ff7  lea r14, [rax+0xC0]
0000777bb65d5ffe  movups xmm1, [r13+r14*1]
0000777bb65d6004  vmovaps xmm3, [rsp+0xC0]
0000777bb65d600d  vmovaps [rsp+0x80], xmm1
0000777bb65d6016  movaps xmm15, xmm3
0000777bb65d601a  addpd xmm15, xmm7
0000777bb65d601f  vcmppd xmm1, xmm15, xmm15, 0x03
0000777bb65d6025  ptest xmm1, xmm1
0000777bb65d602a  jnz 0x0000777BB65D862F
0000777bb65d6030  vmovaps [rsp+0xC0], xmm13
0000777bb65d6039  vmovaps xmm1, [rsp+0xC0]
0000777bb65d6042  por xmm13, xmm1
0000777bb65d6047  movaps [r15+0x270], xmm13
0000777bb65d604f  vmovaps xmm1, [rsp+0xB0]
0000777bb65d6058  vmovaps xmm7, [rsp+0xB0]
0000777bb65d6061  por xmm1, xmm7
0000777bb65d6065  movaps [r15+0x1A0], xmm1
0000777bb65d606d  vmovaps xmm1, [rsp+0x60]
0000777bb65d6073  vpermilpd xmm1, xmm1, 0x00
0000777bb65d6079  vmovaps [rsp+0xB0], xmm1
0000777bb65d6082  vmovaps xmm1, [rsp+0x80]
0000777bb65d608b  vmovaps [rsp+0x80], xmm15
0000777bb65d6094  vmovaps xmm15, [rsp+0xB0]
0000777bb65d609d  vmovaps [rsp+0xB0], xmm14
0000777bb65d60a6  movaps xmm3, xmm1
0000777bb65d60a9  mulpd xmm3, xmm15
0000777bb65d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
0000777bb65d60b3  ptest xmm14, xmm14
0000777bb65d60b9  jnz 0x0000777BB65D8771
0000777bb65d60bf  lea r14, [rax+0x20]
0000777bb65d60c3  movups xmm1, [r13+r14*1]
0000777bb65d60c9  movaps [r15+0x110], xmm1
0000777bb65d60d1  vmovaps xmm14, [rsp+0x70]
0000777bb65d60d7  vmovaps [rsp+0x70], xmm1
0000777bb65d60dd  movaps xmm15, xmm14
0000777bb65d60e1  addpd xmm15, xmm4
0000777bb65d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
0000777bb65d60ec  ptest xmm1, xmm1
0000777bb65d60f1  jnz 0x0000777BB65D88BC
0000777bb65d60f7  vmovaps xmm1, [rsp+0x60]
0000777bb65d60fd  vpermilpd xmm1, xmm1, 0x00
0000777bb65d6103  movaps xmm14, xmm2
0000777bb65d6107  mulpd xmm14, xmm1
0000777bb65d610c  vcmppd xmm4, xmm14, xmm14, 0x03
0000777bb65d6112  ptest xmm4, xmm4
0000777bb65d6117  jnz 0x0000777BB65D89FF
0000777bb65d611d  vmovaps xmm4, [rsp+0x50]
0000777bb65d6123  movaps xmm1, xmm4
0000777bb65d6126  addpd xmm1, xmm9
0000777bb65d612b  vcmppd xmm2, xmm1, xmm1, 0x03
0000777bb65d6130  ptest xmm2, xmm2
0000777bb65d6135  jnz 0x0000777BB65D8B41
0000777bb65d613b  vmovaps xmm9, [rsp+0x30]
0000777bb65d6141  vpermilpd xmm9, xmm9, 0x00
0000777bb65d6147  vmovaps xmm2, [rsp+0x70]
0000777bb65d614d  vmovaps [rsp+0x50], xmm1
0000777bb65d6153  movaps xmm4, xmm2
0000777bb65d6156  mulpd xmm4, xmm9
0000777bb65d615b  vcmppd xmm1, xmm4, xmm4, 0x03
0000777bb65d6160  ptest xmm1, xmm1
0000777bb65d6165  jnz 0x0000777BB65D8C82
0000777bb65d616b  vmovaps xmm1, [rsp+0x30]
0000777bb65d6171  vpermilpd xmm1, xmm1, 0x00
0000777bb65d6177  vmovaps xmm2, [rsp+0x90]
0000777bb65d6180  vmovaps [rsp+0x60], xmm15
0000777bb65d6186  movaps xmm9, xmm2
0000777bb65d618a  mulpd xmm9, xmm1
0000777bb65d618f  vcmppd xmm15, xmm9, xmm9, 0x03
0000777bb65d6195  ptest xmm15, xmm15
0000777bb65d619b  jnz 0x0000777BB65D8DC3
0000777bb65d61a1  vmovaps xmm15, [rsp+0x80]
0000777bb65d61aa  movaps xmm1, xmm15
0000777bb65d61ae  addpd xmm1, xmm6
0000777bb65d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
0000777bb65d61b7  ptest xmm2, xmm2
0000777bb65d61bc  jnz 0x0000777BB65D8F05
0000777bb65d61c2  movaps xmm15, xmm5
0000777bb65d61c6  addpd xmm15, xmm3
0000777bb65d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
0000777bb65d61d1  ptest xmm6, xmm6
0000777bb65d61d6  jnz 0x0000777BB65D9046
0000777bb65d61dc  vmovaps xmm6, [rsp+0x30]
0000777bb65d61e2  vpermilpd xmm6, xmm6, 0x00
0000777bb65d61e8  movaps xmm5, xmm8
0000777bb65d61ec  mulpd xmm5, xmm6
0000777bb65d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
0000777bb65d61f5  ptest xmm3, xmm3
0000777bb65d61fa  jnz 0x0000777BB65D9188
0000777bb65d6200  vmovaps xmm8, [rsp+0x30]
0000777bb65d6206  vpermilpd xmm8, xmm8, 0x00
0000777bb65d620c  movaps xmm6, xmm10
0000777bb65d6210  mulpd xmm6, xmm8
0000777bb65d6215  vcmppd xmm3, xmm6, xmm6, 0x03
0000777bb65d621a  ptest xmm3, xmm3
0000777bb65d621f  jnz 0x0000777BB65D92C9
0000777bb65d6225  vmovaps xmm8, [rsp+0x60]
0000777bb65d622b  movaps xmm10, xmm8
0000777bb65d622f  addpd xmm10, xmm14
0000777bb65d6234  vcmppd xmm3, xmm10, xmm10, 0x03
0000777bb65d623a  ptest xmm3, xmm3
0000777bb65d623f  jnz 0x0000777BB65D940B
0000777bb65d6245  vmovaps xmm8, [rsp+0x50]
0000777bb65d624b  movaps xmm14, xmm8
0000777bb65d624f  addpd xmm14, xmm4
0000777bb65d6254  vcmppd xmm3, xmm14, xmm14, 0x03
0000777bb65d625a  ptest xmm3, xmm3
0000777bb65d625f  jnz 0x0000777BB65D954F
0000777bb65d6265  vmovaps xmm8, [rsp+0x40]
0000777bb65d626b  vpermilpd xmm8, xmm8, 0x00
0000777bb65d6271  movaps xmm4, xmm13
0000777bb65d6275  mulpd xmm4, xmm8
0000777bb65d627a  vcmppd xmm3, xmm4, xmm4, 0x03
0000777bb65d627f  ptest xmm3, xmm3
0000777bb65d6284  jnz 0x0000777BB65D9692
0000777bb65d628a  movaps xmm13, xmm15
0000777bb65d628e  addpd xmm13, xmm9
0000777bb65d6293  vcmppd xmm8, xmm13, xmm13, 0x03
0000777bb65d6299  ptest xmm8, xmm8
0000777bb65d629f  jnz 0x0000777BB65D97D4
0000777bb65d62a5  movaps xmm15, xmm1
0000777bb65d62a9  addpd xmm15, xmm5
0000777bb65d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
0000777bb65d62b4  ptest xmm9, xmm9
0000777bb65d62ba  jnz 0x0000777BB65D9918
0000777bb65d62c0  vmovaps [rsp+0x30], xmm11
0000777bb65d62c6  vmovaps xmm1, [rsp+0x30]
0000777bb65d62cc  por xmm11, xmm1
0000777bb65d62d1  movaps [r15+0x250], xmm11
0000777bb65d62d9  vmovaps [rsp+0x30], xmm12
0000777bb65d62df  vmovaps xmm1, [rsp+0x30]
0000777bb65d62e5  por xmm12, xmm1
0000777bb65d62ea  movaps [r15+0x2A0], xmm12
0000777bb65d62f2  vmovaps xmm1, [rsp+0xA0]
0000777bb65d62fb  vmovaps xmm11, [rsp+0xA0]
0000777bb65d6304  por xmm1, xmm11
0000777bb65d6309  movaps [r15+0x1D0], xmm1
0000777bb65d6311  lea r14, [rax+0x40]
0000777bb65d6315  movups xmm1, [r13+r14*1]
0000777bb65d631b  movaps [r15+0x2C0], xmm1
0000777bb65d6323  vmovaps xmm11, [rsp+0x40]
0000777bb65d6329  vpermilpd xmm11, xmm11, 0x00
0000777bb65d632f  vmovaps xmm8, [rsp+0xE0]
0000777bb65d6338  movaps xmm9, xmm8
0000777bb65d633c  mulpd xmm9, xmm11
0000777bb65d6341  vcmppd xmm5, xmm9, xmm9, 0x03
0000777bb65d6347  ptest xmm5, xmm5
0000777bb65d634c  jnz 0x0000777BB65D9A64
0000777bb65d6352  movaps xmm11, xmm10
0000777bb65d6356  addpd xmm11, xmm6
0000777bb65d635b  vcmppd xmm8, xmm11, xmm11, 0x03
0000777bb65d6361  ptest xmm8, xmm8
0000777bb65d6367  jnz 0x0000777BB65D9BA8
0000777bb65d636d  movaps xmm10, xmm14
0000777bb65d6371  addpd xmm10, xmm4
0000777bb65d6376  vcmppd xmm8, xmm10, xmm10, 0x03
0000777bb65d637c  ptest xmm8, xmm8
0000777bb65d6382  jnz 0x0000777BB65D9CEB
0000777bb65d6388  vmovaps xmm14, [rsp+0x40]
0000777bb65d638e  vpermilpd xmm14, xmm14, 0x00
0000777bb65d6394  movaps xmm8, xmm1
0000777bb65d6398  mulpd xmm8, xmm14
0000777bb65d639d  vcmppd xmm6, xmm8, xmm8, 0x03
0000777bb65d63a3  ptest xmm6, xmm6
0000777bb65d63a8  jnz 0x0000777BB65D9E2E
0000777bb65d63ae  movaps xmm1, [r15+0x2B0]
0000777bb65d63b6  vmovaps xmm14, [rsp+0x40]
0000777bb65d63bc  vpermilpd xmm14, xmm14, 0x00
0000777bb65d63c2  movaps xmm6, xmm1
0000777bb65d63c5  mulpd xmm6, xmm14
0000777bb65d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
0000777bb65d63cf  ptest xmm5, xmm5
0000777bb65d63d4  jnz 0x0000777BB65D9F71
0000777bb65d63da  vmovaps xmm1, [rsp+0x10]
0000777bb65d63e0  vpermilpd xmm1, xmm1, 0x00
0000777bb65d63e6  movaps xmm14, xmm12
0000777bb65d63ea  mulpd xmm14, xmm1
0000777bb65d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
0000777bb65d63f5  ptest xmm5, xmm5
0000777bb65d63fa  jnz 0x0000777BB65DA0B2
0000777bb65d6400  movaps xmm1, xmm13
0000777bb65d6404  addpd xmm1, xmm9
0000777bb65d6409  vcmppd xmm12, xmm1, xmm1, 0x03
0000777bb65d640e  ptest xmm12, xmm12
0000777bb65d6414  jnz 0x0000777BB65DA1F5
0000777bb65d641a  vmovaps xmm13, [rsp+0x10]
0000777bb65d6420  vpermilpd xmm13, xmm13, 0x00
0000777bb65d6426  movaps xmm12, xmm7
0000777bb65d642a  mulpd xmm12, xmm13
0000777bb65d642f  vcmppd xmm9, xmm12, xmm12, 0x03
0000777bb65d6435  ptest xmm9, xmm9
0000777bb65d643b  jnz 0x0000777BB65DA337
0000777bb65d6441  movaps xmm13, xmm15
0000777bb65d6445  addpd xmm13, xmm8
0000777bb65d644a  vcmppd xmm9, xmm13, xmm13, 0x03
0000777bb65d6450  ptest xmm9, xmm9
0000777bb65d6456  jnz 0x0000777BB65DA47A
0000777bb65d645c  movaps xmm15, [r15+0x290]
0000777bb65d6464  vmovaps xmm9, [rsp+0x10]
0000777bb65d646a  vpermilpd xmm9, xmm9, 0x00
0000777bb65d6470  movaps xmm8, xmm15
0000777bb65d6474  mulpd xmm8, xmm9
0000777bb65d6479  vcmppd xmm7, xmm8, xmm8, 0x03
0000777bb65d647f  ptest xmm7, xmm7
0000777bb65d6484  jnz 0x0000777BB65DA5BE
0000777bb65d648a  movaps xmm15, xmm11
0000777bb65d648e  addpd xmm15, xmm6
0000777bb65d6493  vcmppd xmm9, xmm15, xmm15, 0x03
0000777bb65d6499  ptest xmm9, xmm9
0000777bb65d649f  jnz 0x0000777BB65DA702
0000777bb65d64a5  movaps xmm11, [r15+0x1E0]
0000777bb65d64ad  vmovaps xmm9, [rsp+0x10]
0000777bb65d64b3  vpermilpd xmm9, xmm9, 0x00
0000777bb65d64b9  movaps xmm7, xmm11
0000777bb65d64bd  mulpd xmm7, xmm9
0000777bb65d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
0000777bb65d64c7  ptest xmm6, xmm6
0000777bb65d64cc  jnz 0x0000777BB65DA845
0000777bb65d64d2  movaps xmm11, xmm10
0000777bb65d64d6  addpd xmm11, xmm14
0000777bb65d64db  vcmppd xmm9, xmm11, xmm11, 0x03
0000777bb65d64e1  ptest xmm9, xmm9
0000777bb65d64e7  jnz 0x0000777BB65DA987
0000777bb65d64ed  lea r14, [rax+0x70]
0000777bb65d64f1  movups xmm14, [r13+r14*1]
0000777bb65d64f7  movaps [r15+0x240], xmm14
0000777bb65d64ff  movaps xmm10, xmm1
0000777bb65d6503  addpd xmm10, xmm12
0000777bb65d6508  vcmppd xmm9, xmm10, xmm10, 0x03
0000777bb65d650e  ptest xmm9, xmm9
0000777bb65d6514  jnz 0x0000777BB65DAAD5
0000777bb65d651a  movaps [r15+0x170], xmm10
0000777bb65d6522  vmovaps xmm1, [rsp+0x20]
0000777bb65d6528  vpermilpd xmm1, xmm1, 0x00
0000777bb65d652e  movaps xmm12, xmm14
0000777bb65d6532  mulpd xmm12, xmm1
0000777bb65d6537  vcmppd xmm9, xmm12, xmm12, 0x03
0000777bb65d653d  ptest xmm9, xmm9
0000777bb65d6543  jnz 0x0000777BB65DAC18
0000777bb65d6549  vmovaps xmm1, [rsp+0x20]
0000777bb65d654f  vpermilpd xmm1, xmm1, 0x00
0000777bb65d6555  vmovaps xmm9, [rsp+0xB0]
0000777bb65d655e  movaps xmm14, xmm9
0000777bb65d6562  mulpd xmm14, xmm1
0000777bb65d6567  vcmppd xmm6, xmm14, xmm14, 0x03
0000777bb65d656d  ptest xmm6, xmm6
0000777bb65d6572  jnz 0x0000777BB65DAD5B
0000777bb65d6578  movaps [r15+0x180], xmm14
0000777bb65d6580  movaps xmm1, xmm13
0000777bb65d6584  addpd xmm1, xmm8
0000777bb65d6589  vcmppd xmm9, xmm1, xmm1, 0x03
0000777bb65d658e  ptest xmm9, xmm9
0000777bb65d6594  jnz 0x0000777BB65DAE9E
0000777bb65d659a  movaps [r15+0x210], xmm1
0000777bb65d65a2  movups xmm13, [r13+rax*1]
0000777bb65d65a8  lea r14, [rax+0x10]
0000777bb65d65ac  movups xmm9, [r13+r14*1]
0000777bb65d65b2  movaps [r15+0x230], xmm9
0000777bb65d65ba  movaps xmm8, xmm15
0000777bb65d65be  addpd xmm8, xmm7
0000777bb65d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
0000777bb65d65c9  ptest xmm6, xmm6
0000777bb65d65ce  jnz 0x0000777BB65DAFF4
0000777bb65d65d4  movaps [r15+0x130], xmm8
0000777bb65d65dc  vmovaps xmm15, [rsp+0x20]
0000777bb65d65e2  vpermilpd xmm15, xmm15, 0x00
0000777bb65d65e8  movaps xmm7, xmm9
0000777bb65d65ec  mulpd xmm7, xmm15
0000777bb65d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
0000777bb65d65f6  ptest xmm6, xmm6
0000777bb65d65fb  jnz 0x0000777BB65DB137
0000777bb65d6601  movaps [r15+0x220], xmm7
0000777bb65d6609  vmovaps xmm15, [rsp+0x20]
0000777bb65d660f  vpermilpd xmm15, xmm15, 0x00
0000777bb65d6615  movaps xmm9, xmm13
0000777bb65d6619  mulpd xmm9, xmm15
0000777bb65d661e  vcmppd xmm6, xmm9, xmm9, 0x03
0000777bb65d6624  ptest xmm6, xmm6
0000777bb65d6629  jnz 0x0000777BB65DB279
0000777bb65d662f  movaps xmm15, xmm11
0000777bb65d6633  addpd xmm15, xmm12
0000777bb65d6638  vcmppd xmm13, xmm15, xmm15, 0x03
0000777bb65d663e  ptest xmm13, xmm13
0000777bb65d6644  jnz 0x0000777BB65DB3BD
0000777bb65d664a  movaps [r15+0x140], xmm15
0000777bb65d6652  movaps xmm13, xmm10
0000777bb65d6656  addpd xmm13, xmm14
0000777bb65d665b  vcmppd xmm12, xmm13, xmm13, 0x03
0000777bb65d6661  ptest xmm12, xmm12
0000777bb65d6667  jnz 0x0000777BB65DB501
0000777bb65d666d  movaps [r15+0x150], xmm13
0000777bb65d6675  movaps xmm14, xmm1
0000777bb65d6679  addpd xmm14, xmm7
0000777bb65d667e  vcmppd xmm12, xmm14, xmm14, 0x03
0000777bb65d6684  ptest xmm12, xmm12
0000777bb65d668a  jnz 0x0000777BB65DB645
0000777bb65d6690  movaps [r15+0x160], xmm14
0000777bb65d6698  movaps xmm1, xmm8
0000777bb65d669c  addpd xmm1, xmm9
0000777bb65d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
0000777bb65d66a6  ptest xmm12, xmm12
0000777bb65d66ac  jnz 0x0000777BB65DB787
0000777bb65d66b2  movaps [r15+0x120], xmm1
0000777bb65d66ba  movups [r13+r11*1], xmm15
0000777bb65d66c0  lea rax, [r11+0x10]
0000777bb65d66c4  movups [r13+rax*1], xmm13
0000777bb65d66ca  lea rax, [r11+0x20]
0000777bb65d66ce  movups [r13+rax*1], xmm14
0000777bb65d66d4  lea rax, [r11+0x30]
0000777bb65d66d8  movups [r13+rax*1], xmm1
0000777bb65d66de  mov eax, [r15+0x108]
0000777bb65d66e5  sahf
0000777bb65d66e6  jnz 0x0000777BB65D6718
0000777bb65d66e8  cmp dword ptr [r15+0x318], 0x00
0000777bb65d66f0  jz 0x0000777BB65DB900
0000777bb65d66f6  nop [rax+rax*1], ax
0000777bb65d66ff  nop [rax+rax*1], eax
0000777bb65d6707  mov eax, 0x410444
0000777bb65d670c  mov [r15+0x100], rax
0000777bb65d6713  jmp 0x0000777BB63FE110
0000777bb65d6718  cmp dword ptr [r15+0x318], 0x00
0000777bb65d6720  jz 0x0000777BB65D57E0
0000777bb65d6726  nop [rax+rax*1], ax
0000777bb65d672f  nop [rax+rax*1], eax
0000777bb65d6737  mov eax, 0x410278
0000777bb65d673c  mov [r15+0x100], rax
0000777bb65d6743  jmp 0x0000777BB63FE110
0000777bb65d6748  int3
0000777bb65d6749  call 0x0000777BB640A4B0
0000777bb65d674e  jmp 0x0000777BB65D5828
0000777bb65d6753  call 0x0000777BB6409240
0000777bb65d6758  jmp 0x0000777BB65D5832
0000777bb65d675d  call 0x0000777BB640A4B0
0000777bb65d6762  jmp 0x0000777BB65D588F
0000777bb65d6767  call 0x0000777BB6409240
0000777bb65d676c  jmp 0x0000777BB65D5899
0000777bb65d6771  call 0x0000777BB640A4B0
0000777bb65d6776  jmp 0x0000777BB65D58DD
0000777bb65d677b  call 0x0000777BB6409240
0000777bb65d6780  jmp 0x0000777BB65D58E7
0000777bb65d6785  call 0x0000777BB64B47C0
0000777bb65d678a  jmp 0x0000777BB65D5926
0000777bb65d678f  call 0x0000777BB640B720
0000777bb65d6794  jmp 0x0000777BB65D593A
0000777bb65d6799  call 0x0000777BB64BFC30
0000777bb65d679e  jmp 0x0000777BB65D5958
0000777bb65d67a3  call 0x0000777BB64BE9C0
0000777bb65d67a8  jmp 0x0000777BB65D5962
0000777bb65d67ad  call 0x0000777BB64BD750
0000777bb65d67b2  jmp 0x0000777BB65D596C
0000777bb65d67b7  sub rsp, 0x08
0000777bb65d67bb  push rax
0000777bb65d67bc  push rcx
0000777bb65d67bd  push rdx
0000777bb65d67be  push rdi
0000777bb65d67bf  push rsi
0000777bb65d67c0  push r8
0000777bb65d67c2  push r9
0000777bb65d67c4  push r10
0000777bb65d67c6  push r11
0000777bb65d67c8  sub rsp, 0xF0
0000777bb65d67cf  vmovaps [rsp], xmm0
0000777bb65d67d4  vmovaps [rsp+0x10], xmm1
0000777bb65d67da  vmovaps [rsp+0x20], xmm2
0000777bb65d67e0  vmovaps [rsp+0x30], xmm3
0000777bb65d67e6  vmovaps [rsp+0x40], xmm4
0000777bb65d67ec  vmovaps [rsp+0x50], xmm5
0000777bb65d67f2  vmovaps [rsp+0x60], xmm6
0000777bb65d67f8  vmovaps [rsp+0x70], xmm7
0000777bb65d67fe  vmovaps [rsp+0x80], xmm9
0000777bb65d6807  vmovaps [rsp+0x90], xmm10
0000777bb65d6810  vmovaps [rsp+0xA0], xmm11
0000777bb65d6819  vmovaps [rsp+0xB0], xmm12
0000777bb65d6822  vmovaps [rsp+0xC0], xmm13
0000777bb65d682b  vmovaps [rsp+0xD0], xmm14
0000777bb65d6834  vmovaps [rsp+0xE0], xmm15
0000777bb65d683d  sub rsp, 0x30
0000777bb65d6841  movaps [rsp], xmm8
0000777bb65d6846  movaps [rsp+0x10], xmm12
0000777bb65d684c  movaps [rsp+0x20], xmm15
0000777bb65d6852  lea rdi, [rsp]
0000777bb65d6856  mov esi, 0x00
0000777bb65d685b  mov rax, 0x569DC437B530
0000777bb65d6865  call rax
0000777bb65d6867  movaps xmm8, [rsp]
0000777bb65d686c  add rsp, 0x30
0000777bb65d6870  vmovaps xmm0, [rsp]
0000777bb65d6875  vmovaps xmm1, [rsp+0x10]
0000777bb65d687b  vmovaps xmm2, [rsp+0x20]
0000777bb65d6881  vmovaps xmm3, [rsp+0x30]
0000777bb65d6887  vmovaps xmm4, [rsp+0x40]
0000777bb65d688d  vmovaps xmm5, [rsp+0x50]
0000777bb65d6893  vmovaps xmm6, [rsp+0x60]
0000777bb65d6899  vmovaps xmm7, [rsp+0x70]
0000777bb65d689f  vmovaps xmm9, [rsp+0x80]
0000777bb65d68a8  vmovaps xmm10, [rsp+0x90]
0000777bb65d68b1  vmovaps xmm11, [rsp+0xA0]
0000777bb65d68ba  vmovaps xmm12, [rsp+0xB0]
0000777bb65d68c3  vmovaps xmm13, [rsp+0xC0]
0000777bb65d68cc  vmovaps xmm14, [rsp+0xD0]
0000777bb65d68d5  vmovaps xmm15, [rsp+0xE0]
0000777bb65d68de  add rsp, 0xF0
0000777bb65d68e5  pop r11
0000777bb65d68e7  pop r10
0000777bb65d68e9  pop r9
0000777bb65d68eb  pop r8
0000777bb65d68ed  pop rsi
0000777bb65d68ee  pop rdi
0000777bb65d68ef  pop rdx
0000777bb65d68f0  pop rcx
0000777bb65d68f1  pop rax
0000777bb65d68f2  add rsp, 0x08
0000777bb65d68f6  jmp 0x0000777BB65D599A
0000777bb65d68fb  sub rsp, 0x08
0000777bb65d68ff  push rax
0000777bb65d6900  push rcx
0000777bb65d6901  push rdx
0000777bb65d6902  push rdi
0000777bb65d6903  push rsi
0000777bb65d6904  push r8
0000777bb65d6906  push r9
0000777bb65d6908  push r10
0000777bb65d690a  push r11
0000777bb65d690c  sub rsp, 0xF0
0000777bb65d6913  vmovaps [rsp], xmm0
0000777bb65d6918  vmovaps [rsp+0x10], xmm1
0000777bb65d691e  vmovaps [rsp+0x20], xmm2
0000777bb65d6924  vmovaps [rsp+0x30], xmm3
0000777bb65d692a  vmovaps [rsp+0x40], xmm4
0000777bb65d6930  vmovaps [rsp+0x50], xmm5
0000777bb65d6936  vmovaps [rsp+0x60], xmm6
0000777bb65d693c  vmovaps [rsp+0x70], xmm8
0000777bb65d6942  vmovaps [rsp+0x80], xmm9
0000777bb65d694b  vmovaps [rsp+0x90], xmm10
0000777bb65d6954  vmovaps [rsp+0xA0], xmm11
0000777bb65d695d  vmovaps [rsp+0xB0], xmm12
0000777bb65d6966  vmovaps [rsp+0xC0], xmm13
0000777bb65d696f  vmovaps [rsp+0xD0], xmm14
0000777bb65d6978  vmovaps [rsp+0xE0], xmm15
0000777bb65d6981  sub rsp, 0x30
0000777bb65d6985  movaps [rsp], xmm7
0000777bb65d6989  movaps [rsp+0x10], xmm9
0000777bb65d698f  movaps [rsp+0x20], xmm15
0000777bb65d6995  lea rdi, [rsp]
0000777bb65d6999  mov esi, 0x00
0000777bb65d699e  mov rax, 0x569DC437B530
0000777bb65d69a8  call rax
0000777bb65d69aa  movaps xmm7, [rsp]
0000777bb65d69ae  add rsp, 0x30
0000777bb65d69b2  vmovaps xmm0, [rsp]
0000777bb65d69b7  vmovaps xmm1, [rsp+0x10]
0000777bb65d69bd  vmovaps xmm2, [rsp+0x20]
0000777bb65d69c3  vmovaps xmm3, [rsp+0x30]
0000777bb65d69c9  vmovaps xmm4, [rsp+0x40]
0000777bb65d69cf  vmovaps xmm5, [rsp+0x50]
0000777bb65d69d5  vmovaps xmm6, [rsp+0x60]
0000777bb65d69db  vmovaps xmm8, [rsp+0x70]
0000777bb65d69e1  vmovaps xmm9, [rsp+0x80]
0000777bb65d69ea  vmovaps xmm10, [rsp+0x90]
0000777bb65d69f3  vmovaps xmm11, [rsp+0xA0]
0000777bb65d69fc  vmovaps xmm12, [rsp+0xB0]
0000777bb65d6a05  vmovaps xmm13, [rsp+0xC0]
0000777bb65d6a0e  vmovaps xmm14, [rsp+0xD0]
0000777bb65d6a17  vmovaps xmm15, [rsp+0xE0]
0000777bb65d6a20  add rsp, 0xF0
0000777bb65d6a27  pop r11
0000777bb65d6a29  pop r10
0000777bb65d6a2b  pop r9
0000777bb65d6a2d  pop r8
0000777bb65d6a2f  pop rsi
0000777bb65d6a30  pop rdi
0000777bb65d6a31  pop rdx
0000777bb65d6a32  pop rcx
0000777bb65d6a33  pop rax
0000777bb65d6a34  add rsp, 0x08
0000777bb65d6a38  jmp 0x0000777BB65D59C8
0000777bb65d6a3d  sub rsp, 0x08
0000777bb65d6a41  push rax
0000777bb65d6a42  push rcx
0000777bb65d6a43  push rdx
0000777bb65d6a44  push rdi
0000777bb65d6a45  push rsi
0000777bb65d6a46  push r8
0000777bb65d6a48  push r9
0000777bb65d6a4a  push r10
0000777bb65d6a4c  push r11
0000777bb65d6a4e  sub rsp, 0xF0
0000777bb65d6a55  vmovaps [rsp], xmm0
0000777bb65d6a5a  vmovaps [rsp+0x10], xmm1
0000777bb65d6a60  vmovaps [rsp+0x20], xmm2
0000777bb65d6a66  vmovaps [rsp+0x30], xmm3
0000777bb65d6a6c  vmovaps [rsp+0x40], xmm4
0000777bb65d6a72  vmovaps [rsp+0x50], xmm5
0000777bb65d6a78  vmovaps [rsp+0x60], xmm6
0000777bb65d6a7e  vmovaps [rsp+0x70], xmm7
0000777bb65d6a84  vmovaps [rsp+0x80], xmm8
0000777bb65d6a8d  vmovaps [rsp+0x90], xmm10
0000777bb65d6a96  vmovaps [rsp+0xA0], xmm11
0000777bb65d6a9f  vmovaps [rsp+0xB0], xmm12
0000777bb65d6aa8  vmovaps [rsp+0xC0], xmm13
0000777bb65d6ab1  vmovaps [rsp+0xD0], xmm14
0000777bb65d6aba  vmovaps [rsp+0xE0], xmm15
0000777bb65d6ac3  sub rsp, 0x30
0000777bb65d6ac7  movaps [rsp], xmm9
0000777bb65d6acc  movaps [rsp+0x10], xmm12
0000777bb65d6ad2  movaps [rsp+0x20], xmm10
0000777bb65d6ad8  lea rdi, [rsp]
0000777bb65d6adc  mov esi, 0x00
0000777bb65d6ae1  mov rax, 0x569DC437B530
0000777bb65d6aeb  call rax
0000777bb65d6aed  movaps xmm9, [rsp]
0000777bb65d6af2  add rsp, 0x30
0000777bb65d6af6  vmovaps xmm0, [rsp]
0000777bb65d6afb  vmovaps xmm1, [rsp+0x10]
0000777bb65d6b01  vmovaps xmm2, [rsp+0x20]
0000777bb65d6b07  vmovaps xmm3, [rsp+0x30]
0000777bb65d6b0d  vmovaps xmm4, [rsp+0x40]
0000777bb65d6b13  vmovaps xmm5, [rsp+0x50]
0000777bb65d6b19  vmovaps xmm6, [rsp+0x60]
0000777bb65d6b1f  vmovaps xmm7, [rsp+0x70]
0000777bb65d6b25  vmovaps xmm8, [rsp+0x80]
0000777bb65d6b2e  vmovaps xmm10, [rsp+0x90]
0000777bb65d6b37  vmovaps xmm11, [rsp+0xA0]
0000777bb65d6b40  vmovaps xmm12, [rsp+0xB0]
0000777bb65d6b49  vmovaps xmm13, [rsp+0xC0]
0000777bb65d6b52  vmovaps xmm14, [rsp+0xD0]
0000777bb65d6b5b  vmovaps xmm15, [rsp+0xE0]
0000777bb65d6b64  add rsp, 0xF0
0000777bb65d6b6b  pop r11
0000777bb65d6b6d  pop r10
0000777bb65d6b6f  pop r9
0000777bb65d6b71  pop r8
0000777bb65d6b73  pop rsi
0000777bb65d6b74  pop rdi
0000777bb65d6b75  pop rdx
0000777bb65d6b76  pop rcx
0000777bb65d6b77  pop rax
0000777bb65d6b78  add rsp, 0x08
0000777bb65d6b7c  jmp 0x0000777BB65D59EC
0000777bb65d6b81  sub rsp, 0x08
0000777bb65d6b85  push rax
0000777bb65d6b86  push rcx
0000777bb65d6b87  push rdx
0000777bb65d6b88  push rdi
0000777bb65d6b89  push rsi
0000777bb65d6b8a  push r8
0000777bb65d6b8c  push r9
0000777bb65d6b8e  push r10
0000777bb65d6b90  push r11
0000777bb65d6b92  sub rsp, 0xF0
0000777bb65d6b99  vmovaps [rsp], xmm0
0000777bb65d6b9e  vmovaps [rsp+0x10], xmm1
0000777bb65d6ba4  vmovaps [rsp+0x20], xmm2
0000777bb65d6baa  vmovaps [rsp+0x30], xmm3
0000777bb65d6bb0  vmovaps [rsp+0x40], xmm4
0000777bb65d6bb6  vmovaps [rsp+0x50], xmm5
0000777bb65d6bbc  vmovaps [rsp+0x60], xmm6
0000777bb65d6bc2  vmovaps [rsp+0x70], xmm7
0000777bb65d6bc8  vmovaps [rsp+0x80], xmm8
0000777bb65d6bd1  vmovaps [rsp+0x90], xmm9
0000777bb65d6bda  vmovaps [rsp+0xA0], xmm11
0000777bb65d6be3  vmovaps [rsp+0xB0], xmm12
0000777bb65d6bec  vmovaps [rsp+0xC0], xmm13
0000777bb65d6bf5  vmovaps [rsp+0xD0], xmm14
0000777bb65d6bfe  vmovaps [rsp+0xE0], xmm15
0000777bb65d6c07  sub rsp, 0x30
0000777bb65d6c0b  movaps [rsp], xmm10
0000777bb65d6c10  movaps [rsp+0x10], xmm12
0000777bb65d6c16  movaps [rsp+0x20], xmm11
0000777bb65d6c1c  lea rdi, [rsp]
0000777bb65d6c20  mov esi, 0x00
0000777bb65d6c25  mov rax, 0x569DC437B530
0000777bb65d6c2f  call rax
0000777bb65d6c31  movaps xmm10, [rsp]
0000777bb65d6c36  add rsp, 0x30
0000777bb65d6c3a  vmovaps xmm0, [rsp]
0000777bb65d6c3f  vmovaps xmm1, [rsp+0x10]
0000777bb65d6c45  vmovaps xmm2, [rsp+0x20]
0000777bb65d6c4b  vmovaps xmm3, [rsp+0x30]
0000777bb65d6c51  vmovaps xmm4, [rsp+0x40]
0000777bb65d6c57  vmovaps xmm5, [rsp+0x50]
0000777bb65d6c5d  vmovaps xmm6, [rsp+0x60]
0000777bb65d6c63  vmovaps xmm7, [rsp+0x70]
0000777bb65d6c69  vmovaps xmm8, [rsp+0x80]
0000777bb65d6c72  vmovaps xmm9, [rsp+0x90]
0000777bb65d6c7b  vmovaps xmm11, [rsp+0xA0]
0000777bb65d6c84  vmovaps xmm12, [rsp+0xB0]
0000777bb65d6c8d  vmovaps xmm13, [rsp+0xC0]
0000777bb65d6c96  vmovaps xmm14, [rsp+0xD0]
0000777bb65d6c9f  vmovaps xmm15, [rsp+0xE0]
0000777bb65d6ca8  add rsp, 0xF0
0000777bb65d6caf  pop r11
0000777bb65d6cb1  pop r10
0000777bb65d6cb3  pop r9
0000777bb65d6cb5  pop r8
0000777bb65d6cb7  pop rsi
0000777bb65d6cb8  pop rdi
0000777bb65d6cb9  pop rdx
0000777bb65d6cba  pop rcx
0000777bb65d6cbb  pop rax
0000777bb65d6cbc  add rsp, 0x08
0000777bb65d6cc0  jmp 0x0000777BB65D5A06
0000777bb65d6cc5  sub rsp, 0x08
0000777bb65d6cc9  push rax
0000777bb65d6cca  push rcx
0000777bb65d6ccb  push rdx
0000777bb65d6ccc  push rdi
0000777bb65d6ccd  push rsi
0000777bb65d6cce  push r8
0000777bb65d6cd0  push r9
0000777bb65d6cd2  push r10
0000777bb65d6cd4  push r11
0000777bb65d6cd6  sub rsp, 0xF0
0000777bb65d6cdd  vmovaps [rsp], xmm0
0000777bb65d6ce2  vmovaps [rsp+0x10], xmm1
0000777bb65d6ce8  vmovaps [rsp+0x20], xmm2
0000777bb65d6cee  vmovaps [rsp+0x30], xmm3
0000777bb65d6cf4  vmovaps [rsp+0x40], xmm4
0000777bb65d6cfa  vmovaps [rsp+0x50], xmm5
0000777bb65d6d00  vmovaps [rsp+0x60], xmm7
0000777bb65d6d06  vmovaps [rsp+0x70], xmm8
0000777bb65d6d0c  vmovaps [rsp+0x80], xmm9
0000777bb65d6d15  vmovaps [rsp+0x90], xmm10
0000777bb65d6d1e  vmovaps [rsp+0xA0], xmm11
0000777bb65d6d27  vmovaps [rsp+0xB0], xmm12
0000777bb65d6d30  vmovaps [rsp+0xC0], xmm13
0000777bb65d6d39  vmovaps [rsp+0xD0], xmm14
0000777bb65d6d42  vmovaps [rsp+0xE0], xmm15
0000777bb65d6d4b  sub rsp, 0x30
0000777bb65d6d4f  movaps [rsp], xmm6
0000777bb65d6d53  movaps [rsp+0x10], xmm12
0000777bb65d6d59  movaps [rsp+0x20], xmm11
0000777bb65d6d5f  lea rdi, [rsp]
0000777bb65d6d63  mov esi, 0x00
0000777bb65d6d68  mov rax, 0x569DC437B530
0000777bb65d6d72  call rax
0000777bb65d6d74  movaps xmm6, [rsp]
0000777bb65d6d78  add rsp, 0x30
0000777bb65d6d7c  vmovaps xmm0, [rsp]
0000777bb65d6d81  vmovaps xmm1, [rsp+0x10]
0000777bb65d6d87  vmovaps xmm2, [rsp+0x20]
0000777bb65d6d8d  vmovaps xmm3, [rsp+0x30]
0000777bb65d6d93  vmovaps xmm4, [rsp+0x40]
0000777bb65d6d99  vmovaps xmm5, [rsp+0x50]
0000777bb65d6d9f  vmovaps xmm7, [rsp+0x60]
0000777bb65d6da5  vmovaps xmm8, [rsp+0x70]
0000777bb65d6dab  vmovaps xmm9, [rsp+0x80]
0000777bb65d6db4  vmovaps xmm10, [rsp+0x90]
0000777bb65d6dbd  vmovaps xmm11, [rsp+0xA0]
0000777bb65d6dc6  vmovaps xmm12, [rsp+0xB0]
0000777bb65d6dcf  vmovaps xmm13, [rsp+0xC0]
0000777bb65d6dd8  vmovaps xmm14, [rsp+0xD0]
0000777bb65d6de1  vmovaps xmm15, [rsp+0xE0]
0000777bb65d6dea  add rsp, 0xF0
0000777bb65d6df1  pop r11
0000777bb65d6df3  pop r10
0000777bb65d6df5  pop r9
0000777bb65d6df7  pop r8
0000777bb65d6df9  pop rsi
0000777bb65d6dfa  pop rdi
0000777bb65d6dfb  pop rdx
0000777bb65d6dfc  pop rcx
0000777bb65d6dfd  pop rax
0000777bb65d6dfe  add rsp, 0x08
0000777bb65d6e02  jmp 0x0000777BB65D5A27
0000777bb65d6e07  sub rsp, 0x08
0000777bb65d6e0b  push rax
0000777bb65d6e0c  push rcx
0000777bb65d6e0d  push rdx
0000777bb65d6e0e  push rdi
0000777bb65d6e0f  push rsi
0000777bb65d6e10  push r8
0000777bb65d6e12  push r9
0000777bb65d6e14  push r10
0000777bb65d6e16  push r11
0000777bb65d6e18  sub rsp, 0xF0
0000777bb65d6e1f  vmovaps [rsp], xmm0
0000777bb65d6e24  vmovaps [rsp+0x10], xmm1
0000777bb65d6e2a  vmovaps [rsp+0x20], xmm2
0000777bb65d6e30  vmovaps [rsp+0x30], xmm4
0000777bb65d6e36  vmovaps [rsp+0x40], xmm5
0000777bb65d6e3c  vmovaps [rsp+0x50], xmm6
0000777bb65d6e42  vmovaps [rsp+0x60], xmm7
0000777bb65d6e48  vmovaps [rsp+0x70], xmm8
0000777bb65d6e4e  vmovaps [rsp+0x80], xmm9
0000777bb65d6e57  vmovaps [rsp+0x90], xmm10
0000777bb65d6e60  vmovaps [rsp+0xA0], xmm11
0000777bb65d6e69  vmovaps [rsp+0xB0], xmm12
0000777bb65d6e72  vmovaps [rsp+0xC0], xmm13
0000777bb65d6e7b  vmovaps [rsp+0xD0], xmm14
0000777bb65d6e84  vmovaps [rsp+0xE0], xmm15
0000777bb65d6e8d  sub rsp, 0x30
0000777bb65d6e91  movaps [rsp], xmm3
0000777bb65d6e95  movaps [rsp+0x10], xmm5
0000777bb65d6e9a  movaps [rsp+0x20], xmm4
0000777bb65d6e9f  lea rdi, [rsp]
0000777bb65d6ea3  mov esi, 0x00
0000777bb65d6ea8  mov rax, 0x569DC437B530
0000777bb65d6eb2  call rax
0000777bb65d6eb4  movaps xmm3, [rsp]
0000777bb65d6eb8  add rsp, 0x30
0000777bb65d6ebc  vmovaps xmm0, [rsp]
0000777bb65d6ec1  vmovaps xmm1, [rsp+0x10]
0000777bb65d6ec7  vmovaps xmm2, [rsp+0x20]
0000777bb65d6ecd  vmovaps xmm4, [rsp+0x30]
0000777bb65d6ed3  vmovaps xmm5, [rsp+0x40]
0000777bb65d6ed9  vmovaps xmm6, [rsp+0x50]
0000777bb65d6edf  vmovaps xmm7, [rsp+0x60]
0000777bb65d6ee5  vmovaps xmm8, [rsp+0x70]
0000777bb65d6eeb  vmovaps xmm9, [rsp+0x80]
0000777bb65d6ef4  vmovaps xmm10, [rsp+0x90]
0000777bb65d6efd  vmovaps xmm11, [rsp+0xA0]
0000777bb65d6f06  vmovaps xmm12, [rsp+0xB0]
0000777bb65d6f0f  vmovaps xmm13, [rsp+0xC0]
0000777bb65d6f18  vmovaps xmm14, [rsp+0xD0]
0000777bb65d6f21  vmovaps xmm15, [rsp+0xE0]
0000777bb65d6f2a  add rsp, 0xF0
0000777bb65d6f31  pop r11
0000777bb65d6f33  pop r10
0000777bb65d6f35  pop r9
0000777bb65d6f37  pop r8
0000777bb65d6f39  pop rsi
0000777bb65d6f3a  pop rdi
0000777bb65d6f3b  pop rdx
0000777bb65d6f3c  pop rcx
0000777bb65d6f3d  pop rax
0000777bb65d6f3e  add rsp, 0x08
0000777bb65d6f42  jmp 0x0000777BB65D5A88
0000777bb65d6f47  sub rsp, 0x08
0000777bb65d6f4b  push rax
0000777bb65d6f4c  push rcx
0000777bb65d6f4d  push rdx
0000777bb65d6f4e  push rdi
0000777bb65d6f4f  push rsi
0000777bb65d6f50  push r8
0000777bb65d6f52  push r9
0000777bb65d6f54  push r10
0000777bb65d6f56  push r11
0000777bb65d6f58  sub rsp, 0xF0
0000777bb65d6f5f  vmovaps [rsp], xmm0
0000777bb65d6f64  vmovaps [rsp+0x10], xmm1
0000777bb65d6f6a  vmovaps [rsp+0x20], xmm2
0000777bb65d6f70  vmovaps [rsp+0x30], xmm3
0000777bb65d6f76  vmovaps [rsp+0x40], xmm4
0000777bb65d6f7c  vmovaps [rsp+0x50], xmm6
0000777bb65d6f82  vmovaps [rsp+0x60], xmm7
0000777bb65d6f88  vmovaps [rsp+0x70], xmm8
0000777bb65d6f8e  vmovaps [rsp+0x80], xmm9
0000777bb65d6f97  vmovaps [rsp+0x90], xmm10
0000777bb65d6fa0  vmovaps [rsp+0xA0], xmm11
0000777bb65d6fa9  vmovaps [rsp+0xB0], xmm12
0000777bb65d6fb2  vmovaps [rsp+0xC0], xmm13
0000777bb65d6fbb  vmovaps [rsp+0xD0], xmm14
0000777bb65d6fc4  vmovaps [rsp+0xE0], xmm15
0000777bb65d6fcd  sub rsp, 0x30
0000777bb65d6fd1  movaps [rsp], xmm5
0000777bb65d6fd5  movaps [rsp+0x10], xmm8
0000777bb65d6fdb  movaps [rsp+0x20], xmm15
0000777bb65d6fe1  lea rdi, [rsp]
0000777bb65d6fe5  mov esi, 0x00
0000777bb65d6fea  mov rax, 0x569DC437B530
0000777bb65d6ff4  call rax
0000777bb65d6ff6  movaps xmm5, [rsp]
0000777bb65d6ffa  add rsp, 0x30
0000777bb65d6ffe  vmovaps xmm0, [rsp]
0000777bb65d7003  vmovaps xmm1, [rsp+0x10]
0000777bb65d7009  vmovaps xmm2, [rsp+0x20]
0000777bb65d700f  vmovaps xmm3, [rsp+0x30]
0000777bb65d7015  vmovaps xmm4, [rsp+0x40]
0000777bb65d701b  vmovaps xmm6, [rsp+0x50]
0000777bb65d7021  vmovaps xmm7, [rsp+0x60]
0000777bb65d7027  vmovaps xmm8, [rsp+0x70]
0000777bb65d702d  vmovaps xmm9, [rsp+0x80]
0000777bb65d7036  vmovaps xmm10, [rsp+0x90]
0000777bb65d703f  vmovaps xmm11, [rsp+0xA0]
0000777bb65d7048  vmovaps xmm12, [rsp+0xB0]
0000777bb65d7051  vmovaps xmm13, [rsp+0xC0]
0000777bb65d705a  vmovaps xmm14, [rsp+0xD0]
0000777bb65d7063  vmovaps xmm15, [rsp+0xE0]
0000777bb65d706c  add rsp, 0xF0
0000777bb65d7073  pop r11
0000777bb65d7075  pop r10
0000777bb65d7077  pop r9
0000777bb65d7079  pop r8
0000777bb65d707b  pop rsi
0000777bb65d707c  pop rdi
0000777bb65d707d  pop rdx
0000777bb65d707e  pop rcx
0000777bb65d707f  pop rax
0000777bb65d7080  add rsp, 0x08
0000777bb65d7084  jmp 0x0000777BB65D5AC0
0000777bb65d7089  sub rsp, 0x08
0000777bb65d708d  push rax
0000777bb65d708e  push rcx
0000777bb65d708f  push rdx
0000777bb65d7090  push rdi
0000777bb65d7091  push rsi
0000777bb65d7092  push r8
0000777bb65d7094  push r9
0000777bb65d7096  push r10
0000777bb65d7098  push r11
0000777bb65d709a  sub rsp, 0xF0
0000777bb65d70a1  vmovaps [rsp], xmm0
0000777bb65d70a6  vmovaps [rsp+0x10], xmm1
0000777bb65d70ac  vmovaps [rsp+0x20], xmm2
0000777bb65d70b2  vmovaps [rsp+0x30], xmm3
0000777bb65d70b8  vmovaps [rsp+0x40], xmm5
0000777bb65d70be  vmovaps [rsp+0x50], xmm6
0000777bb65d70c4  vmovaps [rsp+0x60], xmm7
0000777bb65d70ca  vmovaps [rsp+0x70], xmm8
0000777bb65d70d0  vmovaps [rsp+0x80], xmm9
0000777bb65d70d9  vmovaps [rsp+0x90], xmm10
0000777bb65d70e2  vmovaps [rsp+0xA0], xmm11
0000777bb65d70eb  vmovaps [rsp+0xB0], xmm12
0000777bb65d70f4  vmovaps [rsp+0xC0], xmm13
0000777bb65d70fd  vmovaps [rsp+0xD0], xmm14
0000777bb65d7106  vmovaps [rsp+0xE0], xmm15
0000777bb65d710f  sub rsp, 0x30
0000777bb65d7113  movaps [rsp], xmm4
0000777bb65d7117  movaps [rsp+0x10], xmm9
0000777bb65d711d  movaps [rsp+0x20], xmm8
0000777bb65d7123  lea rdi, [rsp]
0000777bb65d7127  mov esi, 0x00
0000777bb65d712c  mov rax, 0x569DC437B530
0000777bb65d7136  call rax
0000777bb65d7138  movaps xmm4, [rsp]
0000777bb65d713c  add rsp, 0x30
0000777bb65d7140  vmovaps xmm0, [rsp]
0000777bb65d7145  vmovaps xmm1, [rsp+0x10]
0000777bb65d714b  vmovaps xmm2, [rsp+0x20]
0000777bb65d7151  vmovaps xmm3, [rsp+0x30]
0000777bb65d7157  vmovaps xmm5, [rsp+0x40]
0000777bb65d715d  vmovaps xmm6, [rsp+0x50]
0000777bb65d7163  vmovaps xmm7, [rsp+0x60]
0000777bb65d7169  vmovaps xmm8, [rsp+0x70]
0000777bb65d716f  vmovaps xmm9, [rsp+0x80]
0000777bb65d7178  vmovaps xmm10, [rsp+0x90]
0000777bb65d7181  vmovaps xmm11, [rsp+0xA0]
0000777bb65d718a  vmovaps xmm12, [rsp+0xB0]
0000777bb65d7193  vmovaps xmm13, [rsp+0xC0]
0000777bb65d719c  vmovaps xmm14, [rsp+0xD0]
0000777bb65d71a5  vmovaps xmm15, [rsp+0xE0]
0000777bb65d71ae  add rsp, 0xF0
0000777bb65d71b5  pop r11
0000777bb65d71b7  pop r10
0000777bb65d71b9  pop r9
0000777bb65d71bb  pop r8
0000777bb65d71bd  pop rsi
0000777bb65d71be  pop rdi
0000777bb65d71bf  pop rdx
0000777bb65d71c0  pop rcx
0000777bb65d71c1  pop rax
0000777bb65d71c2  add rsp, 0x08
0000777bb65d71c6  jmp 0x0000777BB65D5AE1
0000777bb65d71cb  sub rsp, 0x08
0000777bb65d71cf  push rax
0000777bb65d71d0  push rcx
0000777bb65d71d1  push rdx
0000777bb65d71d2  push rdi
0000777bb65d71d3  push rsi
0000777bb65d71d4  push r8
0000777bb65d71d6  push r9
0000777bb65d71d8  push r10
0000777bb65d71da  push r11
0000777bb65d71dc  sub rsp, 0xF0
0000777bb65d71e3  vmovaps [rsp], xmm0
0000777bb65d71e8  vmovaps [rsp+0x10], xmm1
0000777bb65d71ee  vmovaps [rsp+0x20], xmm2
0000777bb65d71f4  vmovaps [rsp+0x30], xmm3
0000777bb65d71fa  vmovaps [rsp+0x40], xmm4
0000777bb65d7200  vmovaps [rsp+0x50], xmm5
0000777bb65d7206  vmovaps [rsp+0x60], xmm6
0000777bb65d720c  vmovaps [rsp+0x70], xmm7
0000777bb65d7212  vmovaps [rsp+0x80], xmm8
0000777bb65d721b  vmovaps [rsp+0x90], xmm10
0000777bb65d7224  vmovaps [rsp+0xA0], xmm11
0000777bb65d722d  vmovaps [rsp+0xB0], xmm12
0000777bb65d7236  vmovaps [rsp+0xC0], xmm13
0000777bb65d723f  vmovaps [rsp+0xD0], xmm14
0000777bb65d7248  vmovaps [rsp+0xE0], xmm15
0000777bb65d7251  sub rsp, 0x30
0000777bb65d7255  movaps [rsp], xmm9
0000777bb65d725a  movaps [rsp+0x10], xmm10
0000777bb65d7260  movaps [rsp+0x20], xmm8
0000777bb65d7266  lea rdi, [rsp]
0000777bb65d726a  mov esi, 0x00
0000777bb65d726f  mov rax, 0x569DC437B530
0000777bb65d7279  call rax
0000777bb65d727b  movaps xmm9, [rsp]
0000777bb65d7280  add rsp, 0x30
0000777bb65d7284  vmovaps xmm0, [rsp]
0000777bb65d7289  vmovaps xmm1, [rsp+0x10]
0000777bb65d728f  vmovaps xmm2, [rsp+0x20]
0000777bb65d7295  vmovaps xmm3, [rsp+0x30]
0000777bb65d729b  vmovaps xmm4, [rsp+0x40]
0000777bb65d72a1  vmovaps xmm5, [rsp+0x50]
0000777bb65d72a7  vmovaps xmm6, [rsp+0x60]
0000777bb65d72ad  vmovaps xmm7, [rsp+0x70]
0000777bb65d72b3  vmovaps xmm8, [rsp+0x80]
0000777bb65d72bc  vmovaps xmm10, [rsp+0x90]
0000777bb65d72c5  vmovaps xmm11, [rsp+0xA0]
0000777bb65d72ce  vmovaps xmm12, [rsp+0xB0]
0000777bb65d72d7  vmovaps xmm13, [rsp+0xC0]
0000777bb65d72e0  vmovaps xmm14, [rsp+0xD0]
0000777bb65d72e9  vmovaps xmm15, [rsp+0xE0]
0000777bb65d72f2  add rsp, 0xF0
0000777bb65d72f9  pop r11
0000777bb65d72fb  pop r10
0000777bb65d72fd  pop r9
0000777bb65d72ff  pop r8
0000777bb65d7301  pop rsi
0000777bb65d7302  pop rdi
0000777bb65d7303  pop rdx
0000777bb65d7304  pop rcx
0000777bb65d7305  pop rax
0000777bb65d7306  add rsp, 0x08
0000777bb65d730a  jmp 0x0000777BB65D5AFB
0000777bb65d730f  call 0x0000777BB64D64F0
0000777bb65d7314  jmp 0x0000777BB65D5C15
0000777bb65d7319  call 0x0000777BB64D64F0
0000777bb65d731e  jmp 0x0000777BB65D5C2B
0000777bb65d7323  sub rsp, 0x08
0000777bb65d7327  push rax
0000777bb65d7328  push rcx
0000777bb65d7329  push rdx
0000777bb65d732a  push rdi
0000777bb65d732b  push rsi
0000777bb65d732c  push r8
0000777bb65d732e  push r9
0000777bb65d7330  push r10
0000777bb65d7332  push r11
0000777bb65d7334  sub rsp, 0xF0
0000777bb65d733b  vmovaps [rsp], xmm0
0000777bb65d7340  vmovaps [rsp+0x10], xmm2
0000777bb65d7346  vmovaps [rsp+0x20], xmm3
0000777bb65d734c  vmovaps [rsp+0x30], xmm4
0000777bb65d7352  vmovaps [rsp+0x40], xmm5
0000777bb65d7358  vmovaps [rsp+0x50], xmm6
0000777bb65d735e  vmovaps [rsp+0x60], xmm7
0000777bb65d7364  vmovaps [rsp+0x70], xmm8
0000777bb65d736a  vmovaps [rsp+0x80], xmm9
0000777bb65d7373  vmovaps [rsp+0x90], xmm10
0000777bb65d737c  vmovaps [rsp+0xA0], xmm11
0000777bb65d7385  vmovaps [rsp+0xB0], xmm12
0000777bb65d738e  vmovaps [rsp+0xC0], xmm13
0000777bb65d7397  vmovaps [rsp+0xD0], xmm14
0000777bb65d73a0  vmovaps [rsp+0xE0], xmm15
0000777bb65d73a9  sub rsp, 0x30
0000777bb65d73ad  movaps [rsp], xmm1
0000777bb65d73b1  movaps [rsp+0x10], xmm6
0000777bb65d73b6  movaps [rsp+0x20], xmm15
0000777bb65d73bc  lea rdi, [rsp]
0000777bb65d73c0  mov esi, 0x00
0000777bb65d73c5  mov rax, 0x569DC437B530
0000777bb65d73cf  call rax
0000777bb65d73d1  movaps xmm1, [rsp]
0000777bb65d73d5  add rsp, 0x30
0000777bb65d73d9  vmovaps xmm0, [rsp]
0000777bb65d73de  vmovaps xmm2, [rsp+0x10]
0000777bb65d73e4  vmovaps xmm3, [rsp+0x20]
0000777bb65d73ea  vmovaps xmm4, [rsp+0x30]
0000777bb65d73f0  vmovaps xmm5, [rsp+0x40]
0000777bb65d73f6  vmovaps xmm6, [rsp+0x50]
0000777bb65d73fc  vmovaps xmm7, [rsp+0x60]
0000777bb65d7402  vmovaps xmm8, [rsp+0x70]
0000777bb65d7408  vmovaps xmm9, [rsp+0x80]
0000777bb65d7411  vmovaps xmm10, [rsp+0x90]
0000777bb65d741a  vmovaps xmm11, [rsp+0xA0]
0000777bb65d7423  vmovaps xmm12, [rsp+0xB0]
0000777bb65d742c  vmovaps xmm13, [rsp+0xC0]
0000777bb65d7435  vmovaps xmm14, [rsp+0xD0]
0000777bb65d743e  vmovaps xmm15, [rsp+0xE0]
0000777bb65d7447  add rsp, 0xF0
0000777bb65d744e  pop r11
0000777bb65d7450  pop r10
0000777bb65d7452  pop r9
0000777bb65d7454  pop r8
0000777bb65d7456  pop rsi
0000777bb65d7457  pop rdi
0000777bb65d7458  pop rdx
0000777bb65d7459  pop rcx
0000777bb65d745a  pop rax
0000777bb65d745b  add rsp, 0x08
0000777bb65d745f  jmp 0x0000777BB65D5C68
0000777bb65d7464  call 0x0000777BB64E5820
0000777bb65d7469  jmp 0x0000777BB65D5C75
0000777bb65d746e  sub rsp, 0x08
0000777bb65d7472  push rax
0000777bb65d7473  push rcx
0000777bb65d7474  push rdx
0000777bb65d7475  push rdi
0000777bb65d7476  push rsi
0000777bb65d7477  push r8
0000777bb65d7479  push r9
0000777bb65d747b  push r10
0000777bb65d747d  push r11
0000777bb65d747f  sub rsp, 0xF0
0000777bb65d7486  vmovaps [rsp], xmm0
0000777bb65d748b  vmovaps [rsp+0x10], xmm1
0000777bb65d7491  vmovaps [rsp+0x20], xmm2
0000777bb65d7497  vmovaps [rsp+0x30], xmm3
0000777bb65d749d  vmovaps [rsp+0x40], xmm4
0000777bb65d74a3  vmovaps [rsp+0x50], xmm5
0000777bb65d74a9  vmovaps [rsp+0x60], xmm6
0000777bb65d74af  vmovaps [rsp+0x70], xmm7
0000777bb65d74b5  vmovaps [rsp+0x80], xmm8
0000777bb65d74be  vmovaps [rsp+0x90], xmm9
0000777bb65d74c7  vmovaps [rsp+0xA0], xmm10
0000777bb65d74d0  vmovaps [rsp+0xB0], xmm11
0000777bb65d74d9  vmovaps [rsp+0xC0], xmm12
0000777bb65d74e2  vmovaps [rsp+0xD0], xmm13
0000777bb65d74eb  vmovaps [rsp+0xE0], xmm15
0000777bb65d74f4  sub rsp, 0x30
0000777bb65d74f8  movaps [rsp], xmm14
0000777bb65d74fd  movaps [rsp+0x10], xmm4
0000777bb65d7502  movaps [rsp+0x20], xmm3
0000777bb65d7507  lea rdi, [rsp]
0000777bb65d750b  mov esi, 0x00
0000777bb65d7510  mov rax, 0x569DC437B530
0000777bb65d751a  call rax
0000777bb65d751c  movaps xmm14, [rsp]
0000777bb65d7521  add rsp, 0x30
0000777bb65d7525  vmovaps xmm0, [rsp]
0000777bb65d752a  vmovaps xmm1, [rsp+0x10]
0000777bb65d7530  vmovaps xmm2, [rsp+0x20]
0000777bb65d7536  vmovaps xmm3, [rsp+0x30]
0000777bb65d753c  vmovaps xmm4, [rsp+0x40]
0000777bb65d7542  vmovaps xmm5, [rsp+0x50]
0000777bb65d7548  vmovaps xmm6, [rsp+0x60]
0000777bb65d754e  vmovaps xmm7, [rsp+0x70]
0000777bb65d7554  vmovaps xmm8, [rsp+0x80]
0000777bb65d755d  vmovaps xmm9, [rsp+0x90]
0000777bb65d7566  vmovaps xmm10, [rsp+0xA0]
0000777bb65d756f  vmovaps xmm11, [rsp+0xB0]
0000777bb65d7578  vmovaps xmm12, [rsp+0xC0]
0000777bb65d7581  vmovaps xmm13, [rsp+0xD0]
0000777bb65d758a  vmovaps xmm15, [rsp+0xE0]
0000777bb65d7593  add rsp, 0xF0
0000777bb65d759a  pop r11
0000777bb65d759c  pop r10
0000777bb65d759e  pop r9
0000777bb65d75a0  pop r8
0000777bb65d75a2  pop rsi
0000777bb65d75a3  pop rdi
0000777bb65d75a4  pop rdx
0000777bb65d75a5  pop rcx
0000777bb65d75a6  pop rax
0000777bb65d75a7  add rsp, 0x08
0000777bb65d75ab  jmp 0x0000777BB65D5C8F
0000777bb65d75b0  sub rsp, 0x08
0000777bb65d75b4  push rax
0000777bb65d75b5  push rcx
0000777bb65d75b6  push rdx
0000777bb65d75b7  push rdi
0000777bb65d75b8  push rsi
0000777bb65d75b9  push r8
0000777bb65d75bb  push r9
0000777bb65d75bd  push r10
0000777bb65d75bf  push r11
0000777bb65d75c1  sub rsp, 0xF0
0000777bb65d75c8  vmovaps [rsp], xmm0
0000777bb65d75cd  vmovaps [rsp+0x10], xmm1
0000777bb65d75d3  vmovaps [rsp+0x20], xmm2
0000777bb65d75d9  vmovaps [rsp+0x30], xmm3
0000777bb65d75df  vmovaps [rsp+0x40], xmm4
0000777bb65d75e5  vmovaps [rsp+0x50], xmm5
0000777bb65d75eb  vmovaps [rsp+0x60], xmm7
0000777bb65d75f1  vmovaps [rsp+0x70], xmm8
0000777bb65d75f7  vmovaps [rsp+0x80], xmm9
0000777bb65d7600  vmovaps [rsp+0x90], xmm10
0000777bb65d7609  vmovaps [rsp+0xA0], xmm11
0000777bb65d7612  vmovaps [rsp+0xB0], xmm12
0000777bb65d761b  vmovaps [rsp+0xC0], xmm13
0000777bb65d7624  vmovaps [rsp+0xD0], xmm14
0000777bb65d762d  vmovaps [rsp+0xE0], xmm15
0000777bb65d7636  sub rsp, 0x30
0000777bb65d763a  movaps [rsp], xmm6
0000777bb65d763e  movaps [rsp+0x10], xmm9
0000777bb65d7644  movaps [rsp+0x20], xmm7
0000777bb65d7649  lea rdi, [rsp]
0000777bb65d764d  mov esi, 0x00
0000777bb65d7652  mov rax, 0x569DC437B530
0000777bb65d765c  call rax
0000777bb65d765e  movaps xmm6, [rsp]
0000777bb65d7662  add rsp, 0x30
0000777bb65d7666  vmovaps xmm0, [rsp]
0000777bb65d766b  vmovaps xmm1, [rsp+0x10]
0000777bb65d7671  vmovaps xmm2, [rsp+0x20]
0000777bb65d7677  vmovaps xmm3, [rsp+0x30]
0000777bb65d767d  vmovaps xmm4, [rsp+0x40]
0000777bb65d7683  vmovaps xmm5, [rsp+0x50]
0000777bb65d7689  vmovaps xmm7, [rsp+0x60]
0000777bb65d768f  vmovaps xmm8, [rsp+0x70]
0000777bb65d7695  vmovaps xmm9, [rsp+0x80]
0000777bb65d769e  vmovaps xmm10, [rsp+0x90]
0000777bb65d76a7  vmovaps xmm11, [rsp+0xA0]
0000777bb65d76b0  vmovaps xmm12, [rsp+0xB0]
0000777bb65d76b9  vmovaps xmm13, [rsp+0xC0]
0000777bb65d76c2  vmovaps xmm14, [rsp+0xD0]
0000777bb65d76cb  vmovaps xmm15, [rsp+0xE0]
0000777bb65d76d4  add rsp, 0xF0
0000777bb65d76db  pop r11
0000777bb65d76dd  pop r10
0000777bb65d76df  pop r9
0000777bb65d76e1  pop r8
0000777bb65d76e3  pop rsi
0000777bb65d76e4  pop rdi
0000777bb65d76e5  pop rdx
0000777bb65d76e6  pop rcx
0000777bb65d76e7  pop rax
0000777bb65d76e8  add rsp, 0x08
0000777bb65d76ec  jmp 0x0000777BB65D5CA7
0000777bb65d76f1  sub rsp, 0x08
0000777bb65d76f5  push rax
0000777bb65d76f6  push rcx
0000777bb65d76f7  push rdx
0000777bb65d76f8  push rdi
0000777bb65d76f9  push rsi
0000777bb65d76fa  push r8
0000777bb65d76fc  push r9
0000777bb65d76fe  push r10
0000777bb65d7700  push r11
0000777bb65d7702  sub rsp, 0xF0
0000777bb65d7709  vmovaps [rsp], xmm0
0000777bb65d770e  vmovaps [rsp+0x10], xmm1
0000777bb65d7714  vmovaps [rsp+0x20], xmm2
0000777bb65d771a  vmovaps [rsp+0x30], xmm3
0000777bb65d7720  vmovaps [rsp+0x40], xmm4
0000777bb65d7726  vmovaps [rsp+0x50], xmm5
0000777bb65d772c  vmovaps [rsp+0x60], xmm6
0000777bb65d7732  vmovaps [rsp+0x70], xmm8
0000777bb65d7738  vmovaps [rsp+0x80], xmm9
0000777bb65d7741  vmovaps [rsp+0x90], xmm10
0000777bb65d774a  vmovaps [rsp+0xA0], xmm11
0000777bb65d7753  vmovaps [rsp+0xB0], xmm12
0000777bb65d775c  vmovaps [rsp+0xC0], xmm13
0000777bb65d7765  vmovaps [rsp+0xD0], xmm14
0000777bb65d776e  vmovaps [rsp+0xE0], xmm15
0000777bb65d7777  sub rsp, 0x30
0000777bb65d777b  movaps [rsp], xmm7
0000777bb65d777f  movaps [rsp+0x10], xmm4
0000777bb65d7784  movaps [rsp+0x20], xmm9
0000777bb65d778a  lea rdi, [rsp]
0000777bb65d778e  mov esi, 0x00
0000777bb65d7793  mov rax, 0x569DC437B530
0000777bb65d779d  call rax
0000777bb65d779f  movaps xmm7, [rsp]
0000777bb65d77a3  add rsp, 0x30
0000777bb65d77a7  vmovaps xmm0, [rsp]
0000777bb65d77ac  vmovaps xmm1, [rsp+0x10]
0000777bb65d77b2  vmovaps xmm2, [rsp+0x20]
0000777bb65d77b8  vmovaps xmm3, [rsp+0x30]
0000777bb65d77be  vmovaps xmm4, [rsp+0x40]
0000777bb65d77c4  vmovaps xmm5, [rsp+0x50]
0000777bb65d77ca  vmovaps xmm6, [rsp+0x60]
0000777bb65d77d0  vmovaps xmm8, [rsp+0x70]
0000777bb65d77d6  vmovaps xmm9, [rsp+0x80]
0000777bb65d77df  vmovaps xmm10, [rsp+0x90]
0000777bb65d77e8  vmovaps xmm11, [rsp+0xA0]
0000777bb65d77f1  vmovaps xmm12, [rsp+0xB0]
0000777bb65d77fa  vmovaps xmm13, [rsp+0xC0]
0000777bb65d7803  vmovaps xmm14, [rsp+0xD0]
0000777bb65d780c  vmovaps xmm15, [rsp+0xE0]
0000777bb65d7815  add rsp, 0xF0
0000777bb65d781c  pop r11
0000777bb65d781e  pop r10
0000777bb65d7820  pop r9
0000777bb65d7822  pop r8
0000777bb65d7824  pop rsi
0000777bb65d7825  pop rdi
0000777bb65d7826  pop rdx
0000777bb65d7827  pop rcx
0000777bb65d7828  pop rax
0000777bb65d7829  add rsp, 0x08
0000777bb65d782d  jmp 0x0000777BB65D5CD4
0000777bb65d7832  sub rsp, 0x08
0000777bb65d7836  push rax
0000777bb65d7837  push rcx
0000777bb65d7838  push rdx
0000777bb65d7839  push rdi
0000777bb65d783a  push rsi
0000777bb65d783b  push r8
0000777bb65d783d  push r9
0000777bb65d783f  push r10
0000777bb65d7841  push r11
0000777bb65d7843  sub rsp, 0xF0
0000777bb65d784a  vmovaps [rsp], xmm0
0000777bb65d784f  vmovaps [rsp+0x10], xmm1
0000777bb65d7855  vmovaps [rsp+0x20], xmm2
0000777bb65d785b  vmovaps [rsp+0x30], xmm3
0000777bb65d7861  vmovaps [rsp+0x40], xmm5
0000777bb65d7867  vmovaps [rsp+0x50], xmm6
0000777bb65d786d  vmovaps [rsp+0x60], xmm7
0000777bb65d7873  vmovaps [rsp+0x70], xmm8
0000777bb65d7879  vmovaps [rsp+0x80], xmm9
0000777bb65d7882  vmovaps [rsp+0x90], xmm10
0000777bb65d788b  vmovaps [rsp+0xA0], xmm11
0000777bb65d7894  vmovaps [rsp+0xB0], xmm12
0000777bb65d789d  vmovaps [rsp+0xC0], xmm13
0000777bb65d78a6  vmovaps [rsp+0xD0], xmm14
0000777bb65d78af  vmovaps [rsp+0xE0], xmm15
0000777bb65d78b8  sub rsp, 0x30
0000777bb65d78bc  movaps [rsp], xmm4
0000777bb65d78c0  movaps [rsp+0x10], xmm15
0000777bb65d78c6  movaps [rsp+0x20], xmm9
0000777bb65d78cc  lea rdi, [rsp]
0000777bb65d78d0  mov esi, 0x00
0000777bb65d78d5  mov rax, 0x569DC437B530
0000777bb65d78df  call rax
0000777bb65d78e1  movaps xmm4, [rsp]
0000777bb65d78e5  add rsp, 0x30
0000777bb65d78e9  vmovaps xmm0, [rsp]
0000777bb65d78ee  vmovaps xmm1, [rsp+0x10]
0000777bb65d78f4  vmovaps xmm2, [rsp+0x20]
0000777bb65d78fa  vmovaps xmm3, [rsp+0x30]
0000777bb65d7900  vmovaps xmm5, [rsp+0x40]
0000777bb65d7906  vmovaps xmm6, [rsp+0x50]
0000777bb65d790c  vmovaps xmm7, [rsp+0x60]
0000777bb65d7912  vmovaps xmm8, [rsp+0x70]
0000777bb65d7918  vmovaps xmm9, [rsp+0x80]
0000777bb65d7921  vmovaps xmm10, [rsp+0x90]
0000777bb65d792a  vmovaps xmm11, [rsp+0xA0]
0000777bb65d7933  vmovaps xmm12, [rsp+0xB0]
0000777bb65d793c  vmovaps xmm13, [rsp+0xC0]
0000777bb65d7945  vmovaps xmm14, [rsp+0xD0]
0000777bb65d794e  vmovaps xmm15, [rsp+0xE0]
0000777bb65d7957  add rsp, 0xF0
0000777bb65d795e  pop r11
0000777bb65d7960  pop r10
0000777bb65d7962  pop r9
0000777bb65d7964  pop r8
0000777bb65d7966  pop rsi
0000777bb65d7967  pop rdi
0000777bb65d7968  pop rdx
0000777bb65d7969  pop rcx
0000777bb65d796a  pop rax
0000777bb65d796b  add rsp, 0x08
0000777bb65d796f  jmp 0x0000777BB65D5CF9
0000777bb65d7974  call 0x0000777BB64E5820
0000777bb65d7979  jmp 0x0000777BB65D5D06
0000777bb65d797e  sub rsp, 0x08
0000777bb65d7982  push rax
0000777bb65d7983  push rcx
0000777bb65d7984  push rdx
0000777bb65d7985  push rdi
0000777bb65d7986  push rsi
0000777bb65d7987  push r8
0000777bb65d7989  push r9
0000777bb65d798b  push r10
0000777bb65d798d  push r11
0000777bb65d798f  sub rsp, 0xF0
0000777bb65d7996  vmovaps [rsp], xmm0
0000777bb65d799b  vmovaps [rsp+0x10], xmm1
0000777bb65d79a1  vmovaps [rsp+0x20], xmm2
0000777bb65d79a7  vmovaps [rsp+0x30], xmm4
0000777bb65d79ad  vmovaps [rsp+0x40], xmm5
0000777bb65d79b3  vmovaps [rsp+0x50], xmm6
0000777bb65d79b9  vmovaps [rsp+0x60], xmm7
0000777bb65d79bf  vmovaps [rsp+0x70], xmm8
0000777bb65d79c5  vmovaps [rsp+0x80], xmm9
0000777bb65d79ce  vmovaps [rsp+0x90], xmm10
0000777bb65d79d7  vmovaps [rsp+0xA0], xmm11
0000777bb65d79e0  vmovaps [rsp+0xB0], xmm12
0000777bb65d79e9  vmovaps [rsp+0xC0], xmm13
0000777bb65d79f2  vmovaps [rsp+0xD0], xmm14
0000777bb65d79fb  vmovaps [rsp+0xE0], xmm15
0000777bb65d7a04  sub rsp, 0x30
0000777bb65d7a08  movaps [rsp], xmm3
0000777bb65d7a0c  movaps [rsp+0x10], xmm1
0000777bb65d7a11  movaps [rsp+0x20], xmm9
0000777bb65d7a17  lea rdi, [rsp]
0000777bb65d7a1b  mov esi, 0x00
0000777bb65d7a20  mov rax, 0x569DC437B530
0000777bb65d7a2a  call rax
0000777bb65d7a2c  movaps xmm3, [rsp]
0000777bb65d7a30  add rsp, 0x30
0000777bb65d7a34  vmovaps xmm0, [rsp]
0000777bb65d7a39  vmovaps xmm1, [rsp+0x10]
0000777bb65d7a3f  vmovaps xmm2, [rsp+0x20]
0000777bb65d7a45  vmovaps xmm4, [rsp+0x30]
0000777bb65d7a4b  vmovaps xmm5, [rsp+0x40]
0000777bb65d7a51  vmovaps xmm6, [rsp+0x50]
0000777bb65d7a57  vmovaps xmm7, [rsp+0x60]
0000777bb65d7a5d  vmovaps xmm8, [rsp+0x70]
0000777bb65d7a63  vmovaps xmm9, [rsp+0x80]
0000777bb65d7a6c  vmovaps xmm10, [rsp+0x90]
0000777bb65d7a75  vmovaps xmm11, [rsp+0xA0]
0000777bb65d7a7e  vmovaps xmm12, [rsp+0xB0]
0000777bb65d7a87  vmovaps xmm13, [rsp+0xC0]
0000777bb65d7a90  vmovaps xmm14, [rsp+0xD0]
0000777bb65d7a99  vmovaps xmm15, [rsp+0xE0]
0000777bb65d7aa2  add rsp, 0xF0
0000777bb65d7aa9  pop r11
0000777bb65d7aab  pop r10
0000777bb65d7aad  pop r9
0000777bb65d7aaf  pop r8
0000777bb65d7ab1  pop rsi
0000777bb65d7ab2  pop rdi
0000777bb65d7ab3  pop rdx
0000777bb65d7ab4  pop rcx
0000777bb65d7ab5  pop rax
0000777bb65d7ab6  add rsp, 0x08
0000777bb65d7aba  jmp 0x0000777BB65D5D43
0000777bb65d7abf  sub rsp, 0x08
0000777bb65d7ac3  push rax
0000777bb65d7ac4  push rcx
0000777bb65d7ac5  push rdx
0000777bb65d7ac6  push rdi
0000777bb65d7ac7  push rsi
0000777bb65d7ac8  push r8
0000777bb65d7aca  push r9
0000777bb65d7acc  push r10
0000777bb65d7ace  push r11
0000777bb65d7ad0  sub rsp, 0xF0
0000777bb65d7ad7  vmovaps [rsp], xmm0
0000777bb65d7adc  vmovaps [rsp+0x10], xmm2
0000777bb65d7ae2  vmovaps [rsp+0x20], xmm3
0000777bb65d7ae8  vmovaps [rsp+0x30], xmm4
0000777bb65d7aee  vmovaps [rsp+0x40], xmm5
0000777bb65d7af4  vmovaps [rsp+0x50], xmm6
0000777bb65d7afa  vmovaps [rsp+0x60], xmm7
0000777bb65d7b00  vmovaps [rsp+0x70], xmm8
0000777bb65d7b06  vmovaps [rsp+0x80], xmm9
0000777bb65d7b0f  vmovaps [rsp+0x90], xmm10
0000777bb65d7b18  vmovaps [rsp+0xA0], xmm11
0000777bb65d7b21  vmovaps [rsp+0xB0], xmm12
0000777bb65d7b2a  vmovaps [rsp+0xC0], xmm13
0000777bb65d7b33  vmovaps [rsp+0xD0], xmm14
0000777bb65d7b3c  vmovaps [rsp+0xE0], xmm15
0000777bb65d7b45  sub rsp, 0x30
0000777bb65d7b49  movaps [rsp], xmm1
0000777bb65d7b4d  movaps [rsp+0x10], xmm15
0000777bb65d7b53  movaps [rsp+0x20], xmm9
0000777bb65d7b59  lea rdi, [rsp]
0000777bb65d7b5d  mov esi, 0x00
0000777bb65d7b62  mov rax, 0x569DC437B530
0000777bb65d7b6c  call rax
0000777bb65d7b6e  movaps xmm1, [rsp]
0000777bb65d7b72  add rsp, 0x30
0000777bb65d7b76  vmovaps xmm0, [rsp]
0000777bb65d7b7b  vmovaps xmm2, [rsp+0x10]
0000777bb65d7b81  vmovaps xmm3, [rsp+0x20]
0000777bb65d7b87  vmovaps xmm4, [rsp+0x30]
0000777bb65d7b8d  vmovaps xmm5, [rsp+0x40]
0000777bb65d7b93  vmovaps xmm6, [rsp+0x50]
0000777bb65d7b99  vmovaps xmm7, [rsp+0x60]
0000777bb65d7b9f  vmovaps xmm8, [rsp+0x70]
0000777bb65d7ba5  vmovaps xmm9, [rsp+0x80]
0000777bb65d7bae  vmovaps xmm10, [rsp+0x90]
0000777bb65d7bb7  vmovaps xmm11, [rsp+0xA0]
0000777bb65d7bc0  vmovaps xmm12, [rsp+0xB0]
0000777bb65d7bc9  vmovaps xmm13, [rsp+0xC0]
0000777bb65d7bd2  vmovaps xmm14, [rsp+0xD0]
0000777bb65d7bdb  vmovaps xmm15, [rsp+0xE0]
0000777bb65d7be4  add rsp, 0xF0
0000777bb65d7beb  pop r11
0000777bb65d7bed  pop r10
0000777bb65d7bef  pop r9
0000777bb65d7bf1  pop r8
0000777bb65d7bf3  pop rsi
0000777bb65d7bf4  pop rdi
0000777bb65d7bf5  pop rdx
0000777bb65d7bf6  pop rcx
0000777bb65d7bf7  pop rax
0000777bb65d7bf8  add rsp, 0x08
0000777bb65d7bfc  jmp 0x0000777BB65D5DCB
0000777bb65d7c01  call 0x0000777BB64E5820
0000777bb65d7c06  jmp 0x0000777BB65D5DD8
0000777bb65d7c0b  sub rsp, 0x08
0000777bb65d7c0f  push rax
0000777bb65d7c10  push rcx
0000777bb65d7c11  push rdx
0000777bb65d7c12  push rdi
0000777bb65d7c13  push rsi
0000777bb65d7c14  push r8
0000777bb65d7c16  push r9
0000777bb65d7c18  push r10
0000777bb65d7c1a  push r11
0000777bb65d7c1c  sub rsp, 0xF0
0000777bb65d7c23  vmovaps [rsp], xmm0
0000777bb65d7c28  vmovaps [rsp+0x10], xmm2
0000777bb65d7c2e  vmovaps [rsp+0x20], xmm3
0000777bb65d7c34  vmovaps [rsp+0x30], xmm4
0000777bb65d7c3a  vmovaps [rsp+0x40], xmm5
0000777bb65d7c40  vmovaps [rsp+0x50], xmm6
0000777bb65d7c46  vmovaps [rsp+0x60], xmm7
0000777bb65d7c4c  vmovaps [rsp+0x70], xmm8
0000777bb65d7c52  vmovaps [rsp+0x80], xmm9
0000777bb65d7c5b  vmovaps [rsp+0x90], xmm10
0000777bb65d7c64  vmovaps [rsp+0xA0], xmm11
0000777bb65d7c6d  vmovaps [rsp+0xB0], xmm12
0000777bb65d7c76  vmovaps [rsp+0xC0], xmm13
0000777bb65d7c7f  vmovaps [rsp+0xD0], xmm14
0000777bb65d7c88  vmovaps [rsp+0xE0], xmm15
0000777bb65d7c91  sub rsp, 0x30
0000777bb65d7c95  movaps [rsp], xmm1
0000777bb65d7c99  movaps [rsp+0x10], xmm5
0000777bb65d7c9e  movaps [rsp+0x20], xmm7
0000777bb65d7ca3  lea rdi, [rsp]
0000777bb65d7ca7  mov esi, 0x00
0000777bb65d7cac  mov rax, 0x569DC437B530
0000777bb65d7cb6  call rax
0000777bb65d7cb8  movaps xmm1, [rsp]
0000777bb65d7cbc  add rsp, 0x30
0000777bb65d7cc0  vmovaps xmm0, [rsp]
0000777bb65d7cc5  vmovaps xmm2, [rsp+0x10]
0000777bb65d7ccb  vmovaps xmm3, [rsp+0x20]
0000777bb65d7cd1  vmovaps xmm4, [rsp+0x30]
0000777bb65d7cd7  vmovaps xmm5, [rsp+0x40]
0000777bb65d7cdd  vmovaps xmm6, [rsp+0x50]
0000777bb65d7ce3  vmovaps xmm7, [rsp+0x60]
0000777bb65d7ce9  vmovaps xmm8, [rsp+0x70]
0000777bb65d7cef  vmovaps xmm9, [rsp+0x80]
0000777bb65d7cf8  vmovaps xmm10, [rsp+0x90]
0000777bb65d7d01  vmovaps xmm11, [rsp+0xA0]
0000777bb65d7d0a  vmovaps xmm12, [rsp+0xB0]
0000777bb65d7d13  vmovaps xmm13, [rsp+0xC0]
0000777bb65d7d1c  vmovaps xmm14, [rsp+0xD0]
0000777bb65d7d25  vmovaps xmm15, [rsp+0xE0]
0000777bb65d7d2e  add rsp, 0xF0
0000777bb65d7d35  pop r11
0000777bb65d7d37  pop r10
0000777bb65d7d39  pop r9
0000777bb65d7d3b  pop r8
0000777bb65d7d3d  pop rsi
0000777bb65d7d3e  pop rdi
0000777bb65d7d3f  pop rdx
0000777bb65d7d40  pop rcx
0000777bb65d7d41  pop rax
0000777bb65d7d42  add rsp, 0x08
0000777bb65d7d46  jmp 0x0000777BB65D5E7D
0000777bb65d7d4b  sub rsp, 0x08
0000777bb65d7d4f  push rax
0000777bb65d7d50  push rcx
0000777bb65d7d51  push rdx
0000777bb65d7d52  push rdi
0000777bb65d7d53  push rsi
0000777bb65d7d54  push r8
0000777bb65d7d56  push r9
0000777bb65d7d58  push r10
0000777bb65d7d5a  push r11
0000777bb65d7d5c  sub rsp, 0xF0
0000777bb65d7d63  vmovaps [rsp], xmm0
0000777bb65d7d68  vmovaps [rsp+0x10], xmm1
0000777bb65d7d6e  vmovaps [rsp+0x20], xmm2
0000777bb65d7d74  vmovaps [rsp+0x30], xmm3
0000777bb65d7d7a  vmovaps [rsp+0x40], xmm4
0000777bb65d7d80  vmovaps [rsp+0x50], xmm5
0000777bb65d7d86  vmovaps [rsp+0x60], xmm6
0000777bb65d7d8c  vmovaps [rsp+0x70], xmm8
0000777bb65d7d92  vmovaps [rsp+0x80], xmm9
0000777bb65d7d9b  vmovaps [rsp+0x90], xmm10
0000777bb65d7da4  vmovaps [rsp+0xA0], xmm11
0000777bb65d7dad  vmovaps [rsp+0xB0], xmm12
0000777bb65d7db6  vmovaps [rsp+0xC0], xmm13
0000777bb65d7dbf  vmovaps [rsp+0xD0], xmm14
0000777bb65d7dc8  vmovaps [rsp+0xE0], xmm15
0000777bb65d7dd1  sub rsp, 0x30
0000777bb65d7dd5  movaps [rsp], xmm7
0000777bb65d7dd9  movaps [rsp+0x10], xmm5
0000777bb65d7dde  movaps [rsp+0x20], xmm15
0000777bb65d7de4  lea rdi, [rsp]
0000777bb65d7de8  mov esi, 0x00
0000777bb65d7ded  mov rax, 0x569DC437B530
0000777bb65d7df7  call rax
0000777bb65d7df9  movaps xmm7, [rsp]
0000777bb65d7dfd  add rsp, 0x30
0000777bb65d7e01  vmovaps xmm0, [rsp]
0000777bb65d7e06  vmovaps xmm1, [rsp+0x10]
0000777bb65d7e0c  vmovaps xmm2, [rsp+0x20]
0000777bb65d7e12  vmovaps xmm3, [rsp+0x30]
0000777bb65d7e18  vmovaps xmm4, [rsp+0x40]
0000777bb65d7e1e  vmovaps xmm5, [rsp+0x50]
0000777bb65d7e24  vmovaps xmm6, [rsp+0x60]
0000777bb65d7e2a  vmovaps xmm8, [rsp+0x70]
0000777bb65d7e30  vmovaps xmm9, [rsp+0x80]
0000777bb65d7e39  vmovaps xmm10, [rsp+0x90]
0000777bb65d7e42  vmovaps xmm11, [rsp+0xA0]
0000777bb65d7e4b  vmovaps xmm12, [rsp+0xB0]
0000777bb65d7e54  vmovaps xmm13, [rsp+0xC0]
0000777bb65d7e5d  vmovaps xmm14, [rsp+0xD0]
0000777bb65d7e66  vmovaps xmm15, [rsp+0xE0]
0000777bb65d7e6f  add rsp, 0xF0
0000777bb65d7e76  pop r11
0000777bb65d7e78  pop r10
0000777bb65d7e7a  pop r9
0000777bb65d7e7c  pop r8
0000777bb65d7e7e  pop rsi
0000777bb65d7e7f  pop rdi
0000777bb65d7e80  pop rdx
0000777bb65d7e81  pop rcx
0000777bb65d7e82  pop rax
0000777bb65d7e83  add rsp, 0x08
0000777bb65d7e87  jmp 0x0000777BB65D5EB3
0000777bb65d7e8c  call 0x0000777BB64D64F0
0000777bb65d7e91  jmp 0x0000777BB65D5EC0
0000777bb65d7e96  sub rsp, 0x08
0000777bb65d7e9a  push rax
0000777bb65d7e9b  push rcx
0000777bb65d7e9c  push rdx
0000777bb65d7e9d  push rdi
0000777bb65d7e9e  push rsi
0000777bb65d7e9f  push r8
0000777bb65d7ea1  push r9
0000777bb65d7ea3  push r10
0000777bb65d7ea5  push r11
0000777bb65d7ea7  sub rsp, 0xF0
0000777bb65d7eae  vmovaps [rsp], xmm0
0000777bb65d7eb3  vmovaps [rsp+0x10], xmm1
0000777bb65d7eb9  vmovaps [rsp+0x20], xmm2
0000777bb65d7ebf  vmovaps [rsp+0x30], xmm3
0000777bb65d7ec5  vmovaps [rsp+0x40], xmm4
0000777bb65d7ecb  vmovaps [rsp+0x50], xmm5
0000777bb65d7ed1  vmovaps [rsp+0x60], xmm6
0000777bb65d7ed7  vmovaps [rsp+0x70], xmm7
0000777bb65d7edd  vmovaps [rsp+0x80], xmm8
0000777bb65d7ee6  vmovaps [rsp+0x90], xmm9
0000777bb65d7eef  vmovaps [rsp+0xA0], xmm10
0000777bb65d7ef8  vmovaps [rsp+0xB0], xmm11
0000777bb65d7f01  vmovaps [rsp+0xC0], xmm12
0000777bb65d7f0a  vmovaps [rsp+0xD0], xmm13
0000777bb65d7f13  vmovaps [rsp+0xE0], xmm14
0000777bb65d7f1c  sub rsp, 0x30
0000777bb65d7f20  movaps [rsp], xmm15
0000777bb65d7f25  movaps [rsp+0x10], xmm5
0000777bb65d7f2a  movaps [rsp+0x20], xmm3
0000777bb65d7f2f  lea rdi, [rsp]
0000777bb65d7f33  mov esi, 0x00
0000777bb65d7f38  mov rax, 0x569DC437B530
0000777bb65d7f42  call rax
0000777bb65d7f44  movaps xmm15, [rsp]
0000777bb65d7f49  add rsp, 0x30
0000777bb65d7f4d  vmovaps xmm0, [rsp]
0000777bb65d7f52  vmovaps xmm1, [rsp+0x10]
0000777bb65d7f58  vmovaps xmm2, [rsp+0x20]
0000777bb65d7f5e  vmovaps xmm3, [rsp+0x30]
0000777bb65d7f64  vmovaps xmm4, [rsp+0x40]
0000777bb65d7f6a  vmovaps xmm5, [rsp+0x50]
0000777bb65d7f70  vmovaps xmm6, [rsp+0x60]
0000777bb65d7f76  vmovaps xmm7, [rsp+0x70]
0000777bb65d7f7c  vmovaps xmm8, [rsp+0x80]
0000777bb65d7f85  vmovaps xmm9, [rsp+0x90]
0000777bb65d7f8e  vmovaps xmm10, [rsp+0xA0]
0000777bb65d7f97  vmovaps xmm11, [rsp+0xB0]
0000777bb65d7fa0  vmovaps xmm12, [rsp+0xC0]
0000777bb65d7fa9  vmovaps xmm13, [rsp+0xD0]
0000777bb65d7fb2  vmovaps xmm14, [rsp+0xE0]
0000777bb65d7fbb  add rsp, 0xF0
0000777bb65d7fc2  pop r11
0000777bb65d7fc4  pop r10
0000777bb65d7fc6  pop r9
0000777bb65d7fc8  pop r8
0000777bb65d7fca  pop rsi
0000777bb65d7fcb  pop rdi
0000777bb65d7fcc  pop rdx
0000777bb65d7fcd  pop rcx
0000777bb65d7fce  pop rax
0000777bb65d7fcf  add rsp, 0x08
0000777bb65d7fd3  jmp 0x0000777BB65D5EE6
0000777bb65d7fd8  sub rsp, 0x08
0000777bb65d7fdc  push rax
0000777bb65d7fdd  push rcx
0000777bb65d7fde  push rdx
0000777bb65d7fdf  push rdi
0000777bb65d7fe0  push rsi
0000777bb65d7fe1  push r8
0000777bb65d7fe3  push r9
0000777bb65d7fe5  push r10
0000777bb65d7fe7  push r11
0000777bb65d7fe9  sub rsp, 0xF0
0000777bb65d7ff0  vmovaps [rsp], xmm0
0000777bb65d7ff5  vmovaps [rsp+0x10], xmm2
0000777bb65d7ffb  vmovaps [rsp+0x20], xmm3
0000777bb65d8001  vmovaps [rsp+0x30], xmm4
0000777bb65d8007  vmovaps [rsp+0x40], xmm5
0000777bb65d800d  vmovaps [rsp+0x50], xmm6
0000777bb65d8013  vmovaps [rsp+0x60], xmm7
0000777bb65d8019  vmovaps [rsp+0x70], xmm8
0000777bb65d801f  vmovaps [rsp+0x80], xmm9
0000777bb65d8028  vmovaps [rsp+0x90], xmm10
0000777bb65d8031  vmovaps [rsp+0xA0], xmm11
0000777bb65d803a  vmovaps [rsp+0xB0], xmm12
0000777bb65d8043  vmovaps [rsp+0xC0], xmm13
0000777bb65d804c  vmovaps [rsp+0xD0], xmm14
0000777bb65d8055  vmovaps [rsp+0xE0], xmm15
0000777bb65d805e  sub rsp, 0x30
0000777bb65d8062  movaps [rsp], xmm1
0000777bb65d8066  movaps [rsp+0x10], xmm5
0000777bb65d806b  movaps [rsp+0x20], xmm4
0000777bb65d8070  lea rdi, [rsp]
0000777bb65d8074  mov esi, 0x00
0000777bb65d8079  mov rax, 0x569DC437B530
0000777bb65d8083  call rax
0000777bb65d8085  movaps xmm1, [rsp]
0000777bb65d8089  add rsp, 0x30
0000777bb65d808d  vmovaps xmm0, [rsp]
0000777bb65d8092  vmovaps xmm2, [rsp+0x10]
0000777bb65d8098  vmovaps xmm3, [rsp+0x20]
0000777bb65d809e  vmovaps xmm4, [rsp+0x30]
0000777bb65d80a4  vmovaps xmm5, [rsp+0x40]
0000777bb65d80aa  vmovaps xmm6, [rsp+0x50]
0000777bb65d80b0  vmovaps xmm7, [rsp+0x60]
0000777bb65d80b6  vmovaps xmm8, [rsp+0x70]
0000777bb65d80bc  vmovaps xmm9, [rsp+0x80]
0000777bb65d80c5  vmovaps xmm10, [rsp+0x90]
0000777bb65d80ce  vmovaps xmm11, [rsp+0xA0]
0000777bb65d80d7  vmovaps xmm12, [rsp+0xB0]
0000777bb65d80e0  vmovaps xmm13, [rsp+0xC0]
0000777bb65d80e9  vmovaps xmm14, [rsp+0xD0]
0000777bb65d80f2  vmovaps xmm15, [rsp+0xE0]
0000777bb65d80fb  add rsp, 0xF0
0000777bb65d8102  pop r11
0000777bb65d8104  pop r10
0000777bb65d8106  pop r9
0000777bb65d8108  pop r8
0000777bb65d810a  pop rsi
0000777bb65d810b  pop rdi
0000777bb65d810c  pop rdx
0000777bb65d810d  pop rcx
0000777bb65d810e  pop rax
0000777bb65d810f  add rsp, 0x08
0000777bb65d8113  jmp 0x0000777BB65D5F06
0000777bb65d8118  sub rsp, 0x08
0000777bb65d811c  push rax
0000777bb65d811d  push rcx
0000777bb65d811e  push rdx
0000777bb65d811f  push rdi
0000777bb65d8120  push rsi
0000777bb65d8121  push r8
0000777bb65d8123  push r9
0000777bb65d8125  push r10
0000777bb65d8127  push r11
0000777bb65d8129  sub rsp, 0xF0
0000777bb65d8130  vmovaps [rsp], xmm0
0000777bb65d8135  vmovaps [rsp+0x10], xmm1
0000777bb65d813b  vmovaps [rsp+0x20], xmm2
0000777bb65d8141  vmovaps [rsp+0x30], xmm3
0000777bb65d8147  vmovaps [rsp+0x40], xmm5
0000777bb65d814d  vmovaps [rsp+0x50], xmm6
0000777bb65d8153  vmovaps [rsp+0x60], xmm7
0000777bb65d8159  vmovaps [rsp+0x70], xmm8
0000777bb65d815f  vmovaps [rsp+0x80], xmm9
0000777bb65d8168  vmovaps [rsp+0x90], xmm10
0000777bb65d8171  vmovaps [rsp+0xA0], xmm11
0000777bb65d817a  vmovaps [rsp+0xB0], xmm12
0000777bb65d8183  vmovaps [rsp+0xC0], xmm13
0000777bb65d818c  vmovaps [rsp+0xD0], xmm14
0000777bb65d8195  vmovaps [rsp+0xE0], xmm15
0000777bb65d819e  sub rsp, 0x30
0000777bb65d81a2  movaps [rsp], xmm4
0000777bb65d81a6  movaps [rsp+0x10], xmm3
0000777bb65d81ab  movaps [rsp+0x20], xmm5
0000777bb65d81b0  lea rdi, [rsp]
0000777bb65d81b4  mov esi, 0x00
0000777bb65d81b9  mov rax, 0x569DC437B530
0000777bb65d81c3  call rax
0000777bb65d81c5  movaps xmm4, [rsp]
0000777bb65d81c9  add rsp, 0x30
0000777bb65d81cd  vmovaps xmm0, [rsp]
0000777bb65d81d2  vmovaps xmm1, [rsp+0x10]
0000777bb65d81d8  vmovaps xmm2, [rsp+0x20]
0000777bb65d81de  vmovaps xmm3, [rsp+0x30]
0000777bb65d81e4  vmovaps xmm5, [rsp+0x40]
0000777bb65d81ea  vmovaps xmm6, [rsp+0x50]
0000777bb65d81f0  vmovaps xmm7, [rsp+0x60]
0000777bb65d81f6  vmovaps xmm8, [rsp+0x70]
0000777bb65d81fc  vmovaps xmm9, [rsp+0x80]
0000777bb65d8205  vmovaps xmm10, [rsp+0x90]
0000777bb65d820e  vmovaps xmm11, [rsp+0xA0]
0000777bb65d8217  vmovaps xmm12, [rsp+0xB0]
0000777bb65d8220  vmovaps xmm13, [rsp+0xC0]
0000777bb65d8229  vmovaps xmm14, [rsp+0xD0]
0000777bb65d8232  vmovaps xmm15, [rsp+0xE0]
0000777bb65d823b  add rsp, 0xF0
0000777bb65d8242  pop r11
0000777bb65d8244  pop r10
0000777bb65d8246  pop r9
0000777bb65d8248  pop r8
0000777bb65d824a  pop rsi
0000777bb65d824b  pop rdi
0000777bb65d824c  pop rdx
0000777bb65d824d  pop rcx
0000777bb65d824e  pop rax
0000777bb65d824f  add rsp, 0x08
0000777bb65d8253  jmp 0x0000777BB65D5F54
0000777bb65d8258  call 0x0000777BB64D64F0
0000777bb65d825d  jmp 0x0000777BB65D5F61
0000777bb65d8262  sub rsp, 0x08
0000777bb65d8266  push rax
0000777bb65d8267  push rcx
0000777bb65d8268  push rdx
0000777bb65d8269  push rdi
0000777bb65d826a  push rsi
0000777bb65d826b  push r8
0000777bb65d826d  push r9
0000777bb65d826f  push r10
0000777bb65d8271  push r11
0000777bb65d8273  sub rsp, 0xF0
0000777bb65d827a  vmovaps [rsp], xmm0
0000777bb65d827f  vmovaps [rsp+0x10], xmm1
0000777bb65d8285  vmovaps [rsp+0x20], xmm2
0000777bb65d828b  vmovaps [rsp+0x30], xmm3
0000777bb65d8291  vmovaps [rsp+0x40], xmm4
0000777bb65d8297  vmovaps [rsp+0x50], xmm6
0000777bb65d829d  vmovaps [rsp+0x60], xmm7
0000777bb65d82a3  vmovaps [rsp+0x70], xmm8
0000777bb65d82a9  vmovaps [rsp+0x80], xmm9
0000777bb65d82b2  vmovaps [rsp+0x90], xmm10
0000777bb65d82bb  vmovaps [rsp+0xA0], xmm11
0000777bb65d82c4  vmovaps [rsp+0xB0], xmm12
0000777bb65d82cd  vmovaps [rsp+0xC0], xmm13
0000777bb65d82d6  vmovaps [rsp+0xD0], xmm14
0000777bb65d82df  vmovaps [rsp+0xE0], xmm15
0000777bb65d82e8  sub rsp, 0x30
0000777bb65d82ec  movaps [rsp], xmm5
0000777bb65d82f0  movaps [rsp+0x10], xmm6
0000777bb65d82f5  movaps [rsp+0x20], xmm3
0000777bb65d82fa  lea rdi, [rsp]
0000777bb65d82fe  mov esi, 0x00
0000777bb65d8303  mov rax, 0x569DC437B530
0000777bb65d830d  call rax
0000777bb65d830f  movaps xmm5, [rsp]
0000777bb65d8313  add rsp, 0x30
0000777bb65d8317  vmovaps xmm0, [rsp]
0000777bb65d831c  vmovaps xmm1, [rsp+0x10]
0000777bb65d8322  vmovaps xmm2, [rsp+0x20]
0000777bb65d8328  vmovaps xmm3, [rsp+0x30]
0000777bb65d832e  vmovaps xmm4, [rsp+0x40]
0000777bb65d8334  vmovaps xmm6, [rsp+0x50]
0000777bb65d833a  vmovaps xmm7, [rsp+0x60]
0000777bb65d8340  vmovaps xmm8, [rsp+0x70]
0000777bb65d8346  vmovaps xmm9, [rsp+0x80]
0000777bb65d834f  vmovaps xmm10, [rsp+0x90]
0000777bb65d8358  vmovaps xmm11, [rsp+0xA0]
0000777bb65d8361  vmovaps xmm12, [rsp+0xB0]
0000777bb65d836a  vmovaps xmm13, [rsp+0xC0]
0000777bb65d8373  vmovaps xmm14, [rsp+0xD0]
0000777bb65d837c  vmovaps xmm15, [rsp+0xE0]
0000777bb65d8385  add rsp, 0xF0
0000777bb65d838c  pop r11
0000777bb65d838e  pop r10
0000777bb65d8390  pop r9
0000777bb65d8392  pop r8
0000777bb65d8394  pop rsi
0000777bb65d8395  pop rdi
0000777bb65d8396  pop rdx
0000777bb65d8397  pop rcx
0000777bb65d8398  pop rax
0000777bb65d8399  add rsp, 0x08
0000777bb65d839d  jmp 0x0000777BB65D5F87
0000777bb65d83a2  sub rsp, 0x08
0000777bb65d83a6  push rax
0000777bb65d83a7  push rcx
0000777bb65d83a8  push rdx
0000777bb65d83a9  push rdi
0000777bb65d83aa  push rsi
0000777bb65d83ab  push r8
0000777bb65d83ad  push r9
0000777bb65d83af  push r10
0000777bb65d83b1  push r11
0000777bb65d83b3  sub rsp, 0xF0
0000777bb65d83ba  vmovaps [rsp], xmm0
0000777bb65d83bf  vmovaps [rsp+0x10], xmm1
0000777bb65d83c5  vmovaps [rsp+0x20], xmm2
0000777bb65d83cb  vmovaps [rsp+0x30], xmm3
0000777bb65d83d1  vmovaps [rsp+0x40], xmm4
0000777bb65d83d7  vmovaps [rsp+0x50], xmm5
0000777bb65d83dd  vmovaps [rsp+0x60], xmm7
0000777bb65d83e3  vmovaps [rsp+0x70], xmm8
0000777bb65d83e9  vmovaps [rsp+0x80], xmm9
0000777bb65d83f2  vmovaps [rsp+0x90], xmm10
0000777bb65d83fb  vmovaps [rsp+0xA0], xmm11
0000777bb65d8404  vmovaps [rsp+0xB0], xmm12
0000777bb65d840d  vmovaps [rsp+0xC0], xmm13
0000777bb65d8416  vmovaps [rsp+0xD0], xmm14
0000777bb65d841f  vmovaps [rsp+0xE0], xmm15
0000777bb65d8428  sub rsp, 0x30
0000777bb65d842c  movaps [rsp], xmm6
0000777bb65d8430  movaps [rsp+0x10], xmm9
0000777bb65d8436  movaps [rsp+0x20], xmm1
0000777bb65d843b  lea rdi, [rsp]
0000777bb65d843f  mov esi, 0x00
0000777bb65d8444  mov rax, 0x569DC437B530
0000777bb65d844e  call rax
0000777bb65d8450  movaps xmm6, [rsp]
0000777bb65d8454  add rsp, 0x30
0000777bb65d8458  vmovaps xmm0, [rsp]
0000777bb65d845d  vmovaps xmm1, [rsp+0x10]
0000777bb65d8463  vmovaps xmm2, [rsp+0x20]
0000777bb65d8469  vmovaps xmm3, [rsp+0x30]
0000777bb65d846f  vmovaps xmm4, [rsp+0x40]
0000777bb65d8475  vmovaps xmm5, [rsp+0x50]
0000777bb65d847b  vmovaps xmm7, [rsp+0x60]
0000777bb65d8481  vmovaps xmm8, [rsp+0x70]
0000777bb65d8487  vmovaps xmm9, [rsp+0x80]
0000777bb65d8490  vmovaps xmm10, [rsp+0x90]
0000777bb65d8499  vmovaps xmm11, [rsp+0xA0]
0000777bb65d84a2  vmovaps xmm12, [rsp+0xB0]
0000777bb65d84ab  vmovaps xmm13, [rsp+0xC0]
0000777bb65d84b4  vmovaps xmm14, [rsp+0xD0]
0000777bb65d84bd  vmovaps xmm15, [rsp+0xE0]
0000777bb65d84c6  add rsp, 0xF0
0000777bb65d84cd  pop r11
0000777bb65d84cf  pop r10
0000777bb65d84d1  pop r9
0000777bb65d84d3  pop r8
0000777bb65d84d5  pop rsi
0000777bb65d84d6  pop rdi
0000777bb65d84d7  pop rdx
0000777bb65d84d8  pop rcx
0000777bb65d84d9  pop rax
0000777bb65d84da  add rsp, 0x08
0000777bb65d84de  jmp 0x0000777BB65D5FAB
0000777bb65d84e3  sub rsp, 0x08
0000777bb65d84e7  push rax
0000777bb65d84e8  push rcx
0000777bb65d84e9  push rdx
0000777bb65d84ea  push rdi
0000777bb65d84eb  push rsi
0000777bb65d84ec  push r8
0000777bb65d84ee  push r9
0000777bb65d84f0  push r10
0000777bb65d84f2  push r11
0000777bb65d84f4  sub rsp, 0xF0
0000777bb65d84fb  vmovaps [rsp], xmm0
0000777bb65d8500  vmovaps [rsp+0x10], xmm1
0000777bb65d8506  vmovaps [rsp+0x20], xmm2
0000777bb65d850c  vmovaps [rsp+0x30], xmm3
0000777bb65d8512  vmovaps [rsp+0x40], xmm4
0000777bb65d8518  vmovaps [rsp+0x50], xmm5
0000777bb65d851e  vmovaps [rsp+0x60], xmm6
0000777bb65d8524  vmovaps [rsp+0x70], xmm7
0000777bb65d852a  vmovaps [rsp+0x80], xmm8
0000777bb65d8533  vmovaps [rsp+0x90], xmm10
0000777bb65d853c  vmovaps [rsp+0xA0], xmm11
0000777bb65d8545  vmovaps [rsp+0xB0], xmm12
0000777bb65d854e  vmovaps [rsp+0xC0], xmm13
0000777bb65d8557  vmovaps [rsp+0xD0], xmm14
0000777bb65d8560  vmovaps [rsp+0xE0], xmm15
0000777bb65d8569  sub rsp, 0x30
0000777bb65d856d  movaps [rsp], xmm9
0000777bb65d8572  movaps [rsp+0x10], xmm3
0000777bb65d8577  movaps [rsp+0x20], xmm1
0000777bb65d857c  lea rdi, [rsp]
0000777bb65d8580  mov esi, 0x00
0000777bb65d8585  mov rax, 0x569DC437B530
0000777bb65d858f  call rax
0000777bb65d8591  movaps xmm9, [rsp]
0000777bb65d8596  add rsp, 0x30
0000777bb65d859a  vmovaps xmm0, [rsp]
0000777bb65d859f  vmovaps xmm1, [rsp+0x10]
0000777bb65d85a5  vmovaps xmm2, [rsp+0x20]
0000777bb65d85ab  vmovaps xmm3, [rsp+0x30]
0000777bb65d85b1  vmovaps xmm4, [rsp+0x40]
0000777bb65d85b7  vmovaps xmm5, [rsp+0x50]
0000777bb65d85bd  vmovaps xmm6, [rsp+0x60]
0000777bb65d85c3  vmovaps xmm7, [rsp+0x70]
0000777bb65d85c9  vmovaps xmm8, [rsp+0x80]
0000777bb65d85d2  vmovaps xmm10, [rsp+0x90]
0000777bb65d85db  vmovaps xmm11, [rsp+0xA0]
0000777bb65d85e4  vmovaps xmm12, [rsp+0xB0]
0000777bb65d85ed  vmovaps xmm13, [rsp+0xC0]
0000777bb65d85f6  vmovaps xmm14, [rsp+0xD0]
0000777bb65d85ff  vmovaps xmm15, [rsp+0xE0]
0000777bb65d8608  add rsp, 0xF0
0000777bb65d860f  pop r11
0000777bb65d8611  pop r10
0000777bb65d8613  pop r9
0000777bb65d8615  pop r8
0000777bb65d8617  pop rsi
0000777bb65d8618  pop rdi
0000777bb65d8619  pop rdx
0000777bb65d861a  pop rcx
0000777bb65d861b  pop rax
0000777bb65d861c  add rsp, 0x08
0000777bb65d8620  jmp 0x0000777BB65D5FF7
0000777bb65d8625  call 0x0000777BB64D64F0
0000777bb65d862a  jmp 0x0000777BB65D6004
0000777bb65d862f  sub rsp, 0x08
0000777bb65d8633  push rax
0000777bb65d8634  push rcx
0000777bb65d8635  push rdx
0000777bb65d8636  push rdi
0000777bb65d8637  push rsi
0000777bb65d8638  push r8
0000777bb65d863a  push r9
0000777bb65d863c  push r10
0000777bb65d863e  push r11
0000777bb65d8640  sub rsp, 0xF0
0000777bb65d8647  vmovaps [rsp], xmm0
0000777bb65d864c  vmovaps [rsp+0x10], xmm1
0000777bb65d8652  vmovaps [rsp+0x20], xmm2
0000777bb65d8658  vmovaps [rsp+0x30], xmm3
0000777bb65d865e  vmovaps [rsp+0x40], xmm4
0000777bb65d8664  vmovaps [rsp+0x50], xmm5
0000777bb65d866a  vmovaps [rsp+0x60], xmm6
0000777bb65d8670  vmovaps [rsp+0x70], xmm7
0000777bb65d8676  vmovaps [rsp+0x80], xmm8
0000777bb65d867f  vmovaps [rsp+0x90], xmm9
0000777bb65d8688  vmovaps [rsp+0xA0], xmm10
0000777bb65d8691  vmovaps [rsp+0xB0], xmm11
0000777bb65d869a  vmovaps [rsp+0xC0], xmm12
0000777bb65d86a3  vmovaps [rsp+0xD0], xmm13
0000777bb65d86ac  vmovaps [rsp+0xE0], xmm14
0000777bb65d86b5  sub rsp, 0x30
0000777bb65d86b9  movaps [rsp], xmm15
0000777bb65d86be  movaps [rsp+0x10], xmm3
0000777bb65d86c3  movaps [rsp+0x20], xmm7
0000777bb65d86c8  lea rdi, [rsp]
0000777bb65d86cc  mov esi, 0x00
0000777bb65d86d1  mov rax, 0x569DC437B530
0000777bb65d86db  call rax
0000777bb65d86dd  movaps xmm15, [rsp]
0000777bb65d86e2  add rsp, 0x30
0000777bb65d86e6  vmovaps xmm0, [rsp]
0000777bb65d86eb  vmovaps xmm1, [rsp+0x10]
0000777bb65d86f1  vmovaps xmm2, [rsp+0x20]
0000777bb65d86f7  vmovaps xmm3, [rsp+0x30]
0000777bb65d86fd  vmovaps xmm4, [rsp+0x40]
0000777bb65d8703  vmovaps xmm5, [rsp+0x50]
0000777bb65d8709  vmovaps xmm6, [rsp+0x60]
0000777bb65d870f  vmovaps xmm7, [rsp+0x70]
0000777bb65d8715  vmovaps xmm8, [rsp+0x80]
0000777bb65d871e  vmovaps xmm9, [rsp+0x90]
0000777bb65d8727  vmovaps xmm10, [rsp+0xA0]
0000777bb65d8730  vmovaps xmm11, [rsp+0xB0]
0000777bb65d8739  vmovaps xmm12, [rsp+0xC0]
0000777bb65d8742  vmovaps xmm13, [rsp+0xD0]
0000777bb65d874b  vmovaps xmm14, [rsp+0xE0]
0000777bb65d8754  add rsp, 0xF0
0000777bb65d875b  pop r11
0000777bb65d875d  pop r10
0000777bb65d875f  pop r9
0000777bb65d8761  pop r8
0000777bb65d8763  pop rsi
0000777bb65d8764  pop rdi
0000777bb65d8765  pop rdx
0000777bb65d8766  pop rcx
0000777bb65d8767  pop rax
0000777bb65d8768  add rsp, 0x08
0000777bb65d876c  jmp 0x0000777BB65D6030
0000777bb65d8771  sub rsp, 0x08
0000777bb65d8775  push rax
0000777bb65d8776  push rcx
0000777bb65d8777  push rdx
0000777bb65d8778  push rdi
0000777bb65d8779  push rsi
0000777bb65d877a  push r8
0000777bb65d877c  push r9
0000777bb65d877e  push r10
0000777bb65d8780  push r11
0000777bb65d8782  sub rsp, 0xF0
0000777bb65d8789  vmovaps [rsp], xmm0
0000777bb65d878e  vmovaps [rsp+0x10], xmm1
0000777bb65d8794  vmovaps [rsp+0x20], xmm2
0000777bb65d879a  vmovaps [rsp+0x30], xmm4
0000777bb65d87a0  vmovaps [rsp+0x40], xmm5
0000777bb65d87a6  vmovaps [rsp+0x50], xmm6
0000777bb65d87ac  vmovaps [rsp+0x60], xmm7
0000777bb65d87b2  vmovaps [rsp+0x70], xmm8
0000777bb65d87b8  vmovaps [rsp+0x80], xmm9
0000777bb65d87c1  vmovaps [rsp+0x90], xmm10
0000777bb65d87ca  vmovaps [rsp+0xA0], xmm11
0000777bb65d87d3  vmovaps [rsp+0xB0], xmm12
0000777bb65d87dc  vmovaps [rsp+0xC0], xmm13
0000777bb65d87e5  vmovaps [rsp+0xD0], xmm14
0000777bb65d87ee  vmovaps [rsp+0xE0], xmm15
0000777bb65d87f7  sub rsp, 0x30
0000777bb65d87fb  movaps [rsp], xmm3
0000777bb65d87ff  movaps [rsp+0x10], xmm1
0000777bb65d8804  movaps [rsp+0x20], xmm15
0000777bb65d880a  lea rdi, [rsp]
0000777bb65d880e  mov esi, 0x00
0000777bb65d8813  mov rax, 0x569DC437B530
0000777bb65d881d  call rax
0000777bb65d881f  movaps xmm3, [rsp]
0000777bb65d8823  add rsp, 0x30
0000777bb65d8827  vmovaps xmm0, [rsp]
0000777bb65d882c  vmovaps xmm1, [rsp+0x10]
0000777bb65d8832  vmovaps xmm2, [rsp+0x20]
0000777bb65d8838  vmovaps xmm4, [rsp+0x30]
0000777bb65d883e  vmovaps xmm5, [rsp+0x40]
0000777bb65d8844  vmovaps xmm6, [rsp+0x50]
0000777bb65d884a  vmovaps xmm7, [rsp+0x60]
0000777bb65d8850  vmovaps xmm8, [rsp+0x70]
0000777bb65d8856  vmovaps xmm9, [rsp+0x80]
0000777bb65d885f  vmovaps xmm10, [rsp+0x90]
0000777bb65d8868  vmovaps xmm11, [rsp+0xA0]
0000777bb65d8871  vmovaps xmm12, [rsp+0xB0]
0000777bb65d887a  vmovaps xmm13, [rsp+0xC0]
0000777bb65d8883  vmovaps xmm14, [rsp+0xD0]
0000777bb65d888c  vmovaps xmm15, [rsp+0xE0]
0000777bb65d8895  add rsp, 0xF0
0000777bb65d889c  pop r11
0000777bb65d889e  pop r10
0000777bb65d88a0  pop r9
0000777bb65d88a2  pop r8
0000777bb65d88a4  pop rsi
0000777bb65d88a5  pop rdi
0000777bb65d88a6  pop rdx
0000777bb65d88a7  pop rcx
0000777bb65d88a8  pop rax
0000777bb65d88a9  add rsp, 0x08
0000777bb65d88ad  jmp 0x0000777BB65D60BF
0000777bb65d88b2  call 0x0000777BB64D64F0
0000777bb65d88b7  jmp 0x0000777BB65D60C9
0000777bb65d88bc  sub rsp, 0x08
0000777bb65d88c0  push rax
0000777bb65d88c1  push rcx
0000777bb65d88c2  push rdx
0000777bb65d88c3  push rdi
0000777bb65d88c4  push rsi
0000777bb65d88c5  push r8
0000777bb65d88c7  push r9
0000777bb65d88c9  push r10
0000777bb65d88cb  push r11
0000777bb65d88cd  sub rsp, 0xF0
0000777bb65d88d4  vmovaps [rsp], xmm0
0000777bb65d88d9  vmovaps [rsp+0x10], xmm1
0000777bb65d88df  vmovaps [rsp+0x20], xmm2
0000777bb65d88e5  vmovaps [rsp+0x30], xmm3
0000777bb65d88eb  vmovaps [rsp+0x40], xmm4
0000777bb65d88f1  vmovaps [rsp+0x50], xmm5
0000777bb65d88f7  vmovaps [rsp+0x60], xmm6
0000777bb65d88fd  vmovaps [rsp+0x70], xmm7
0000777bb65d8903  vmovaps [rsp+0x80], xmm8
0000777bb65d890c  vmovaps [rsp+0x90], xmm9
0000777bb65d8915  vmovaps [rsp+0xA0], xmm10
0000777bb65d891e  vmovaps [rsp+0xB0], xmm11
0000777bb65d8927  vmovaps [rsp+0xC0], xmm12
0000777bb65d8930  vmovaps [rsp+0xD0], xmm13
0000777bb65d8939  vmovaps [rsp+0xE0], xmm14
0000777bb65d8942  sub rsp, 0x30
0000777bb65d8946  movaps [rsp], xmm15
0000777bb65d894b  movaps [rsp+0x10], xmm14
0000777bb65d8951  movaps [rsp+0x20], xmm4
0000777bb65d8956  lea rdi, [rsp]
0000777bb65d895a  mov esi, 0x00
0000777bb65d895f  mov rax, 0x569DC437B530
0000777bb65d8969  call rax
0000777bb65d896b  movaps xmm15, [rsp]
0000777bb65d8970  add rsp, 0x30
0000777bb65d8974  vmovaps xmm0, [rsp]
0000777bb65d8979  vmovaps xmm1, [rsp+0x10]
0000777bb65d897f  vmovaps xmm2, [rsp+0x20]
0000777bb65d8985  vmovaps xmm3, [rsp+0x30]
0000777bb65d898b  vmovaps xmm4, [rsp+0x40]
0000777bb65d8991  vmovaps xmm5, [rsp+0x50]
0000777bb65d8997  vmovaps xmm6, [rsp+0x60]
0000777bb65d899d  vmovaps xmm7, [rsp+0x70]
0000777bb65d89a3  vmovaps xmm8, [rsp+0x80]
0000777bb65d89ac  vmovaps xmm9, [rsp+0x90]
0000777bb65d89b5  vmovaps xmm10, [rsp+0xA0]
0000777bb65d89be  vmovaps xmm11, [rsp+0xB0]
0000777bb65d89c7  vmovaps xmm12, [rsp+0xC0]
0000777bb65d89d0  vmovaps xmm13, [rsp+0xD0]
0000777bb65d89d9  vmovaps xmm14, [rsp+0xE0]
0000777bb65d89e2  add rsp, 0xF0
0000777bb65d89e9  pop r11
0000777bb65d89eb  pop r10
0000777bb65d89ed  pop r9
0000777bb65d89ef  pop r8
0000777bb65d89f1  pop rsi
0000777bb65d89f2  pop rdi
0000777bb65d89f3  pop rdx
0000777bb65d89f4  pop rcx
0000777bb65d89f5  pop rax
0000777bb65d89f6  add rsp, 0x08
0000777bb65d89fa  jmp 0x0000777BB65D60F7
0000777bb65d89ff  sub rsp, 0x08
0000777bb65d8a03  push rax
0000777bb65d8a04  push rcx
0000777bb65d8a05  push rdx
0000777bb65d8a06  push rdi
0000777bb65d8a07  push rsi
0000777bb65d8a08  push r8
0000777bb65d8a0a  push r9
0000777bb65d8a0c  push r10
0000777bb65d8a0e  push r11
0000777bb65d8a10  sub rsp, 0xF0
0000777bb65d8a17  vmovaps [rsp], xmm0
0000777bb65d8a1c  vmovaps [rsp+0x10], xmm1
0000777bb65d8a22  vmovaps [rsp+0x20], xmm2
0000777bb65d8a28  vmovaps [rsp+0x30], xmm3
0000777bb65d8a2e  vmovaps [rsp+0x40], xmm4
0000777bb65d8a34  vmovaps [rsp+0x50], xmm5
0000777bb65d8a3a  vmovaps [rsp+0x60], xmm6
0000777bb65d8a40  vmovaps [rsp+0x70], xmm7
0000777bb65d8a46  vmovaps [rsp+0x80], xmm8
0000777bb65d8a4f  vmovaps [rsp+0x90], xmm9
0000777bb65d8a58  vmovaps [rsp+0xA0], xmm10
0000777bb65d8a61  vmovaps [rsp+0xB0], xmm11
0000777bb65d8a6a  vmovaps [rsp+0xC0], xmm12
0000777bb65d8a73  vmovaps [rsp+0xD0], xmm13
0000777bb65d8a7c  vmovaps [rsp+0xE0], xmm15
0000777bb65d8a85  sub rsp, 0x30
0000777bb65d8a89  movaps [rsp], xmm14
0000777bb65d8a8e  movaps [rsp+0x10], xmm2
0000777bb65d8a93  movaps [rsp+0x20], xmm1
0000777bb65d8a98  lea rdi, [rsp]
0000777bb65d8a9c  mov esi, 0x00
0000777bb65d8aa1  mov rax, 0x569DC437B530
0000777bb65d8aab  call rax
0000777bb65d8aad  movaps xmm14, [rsp]
0000777bb65d8ab2  add rsp, 0x30
0000777bb65d8ab6  vmovaps xmm0, [rsp]
0000777bb65d8abb  vmovaps xmm1, [rsp+0x10]
0000777bb65d8ac1  vmovaps xmm2, [rsp+0x20]
0000777bb65d8ac7  vmovaps xmm3, [rsp+0x30]
0000777bb65d8acd  vmovaps xmm4, [rsp+0x40]
0000777bb65d8ad3  vmovaps xmm5, [rsp+0x50]
0000777bb65d8ad9  vmovaps xmm6, [rsp+0x60]
0000777bb65d8adf  vmovaps xmm7, [rsp+0x70]
0000777bb65d8ae5  vmovaps xmm8, [rsp+0x80]
0000777bb65d8aee  vmovaps xmm9, [rsp+0x90]
0000777bb65d8af7  vmovaps xmm10, [rsp+0xA0]
0000777bb65d8b00  vmovaps xmm11, [rsp+0xB0]
0000777bb65d8b09  vmovaps xmm12, [rsp+0xC0]
0000777bb65d8b12  vmovaps xmm13, [rsp+0xD0]
0000777bb65d8b1b  vmovaps xmm15, [rsp+0xE0]
0000777bb65d8b24  add rsp, 0xF0
0000777bb65d8b2b  pop r11
0000777bb65d8b2d  pop r10
0000777bb65d8b2f  pop r9
0000777bb65d8b31  pop r8
0000777bb65d8b33  pop rsi
0000777bb65d8b34  pop rdi
0000777bb65d8b35  pop rdx
0000777bb65d8b36  pop rcx
0000777bb65d8b37  pop rax
0000777bb65d8b38  add rsp, 0x08
0000777bb65d8b3c  jmp 0x0000777BB65D611D
0000777bb65d8b41  sub rsp, 0x08
0000777bb65d8b45  push rax
0000777bb65d8b46  push rcx
0000777bb65d8b47  push rdx
0000777bb65d8b48  push rdi
0000777bb65d8b49  push rsi
0000777bb65d8b4a  push r8
0000777bb65d8b4c  push r9
0000777bb65d8b4e  push r10
0000777bb65d8b50  push r11
0000777bb65d8b52  sub rsp, 0xF0
0000777bb65d8b59  vmovaps [rsp], xmm0
0000777bb65d8b5e  vmovaps [rsp+0x10], xmm2
0000777bb65d8b64  vmovaps [rsp+0x20], xmm3
0000777bb65d8b6a  vmovaps [rsp+0x30], xmm4
0000777bb65d8b70  vmovaps [rsp+0x40], xmm5
0000777bb65d8b76  vmovaps [rsp+0x50], xmm6
0000777bb65d8b7c  vmovaps [rsp+0x60], xmm7
0000777bb65d8b82  vmovaps [rsp+0x70], xmm8
0000777bb65d8b88  vmovaps [rsp+0x80], xmm9
0000777bb65d8b91  vmovaps [rsp+0x90], xmm10
0000777bb65d8b9a  vmovaps [rsp+0xA0], xmm11
0000777bb65d8ba3  vmovaps [rsp+0xB0], xmm12
0000777bb65d8bac  vmovaps [rsp+0xC0], xmm13
0000777bb65d8bb5  vmovaps [rsp+0xD0], xmm14
0000777bb65d8bbe  vmovaps [rsp+0xE0], xmm15
0000777bb65d8bc7  sub rsp, 0x30
0000777bb65d8bcb  movaps [rsp], xmm1
0000777bb65d8bcf  movaps [rsp+0x10], xmm4
0000777bb65d8bd4  movaps [rsp+0x20], xmm9
0000777bb65d8bda  lea rdi, [rsp]
0000777bb65d8bde  mov esi, 0x00
0000777bb65d8be3  mov rax, 0x569DC437B530
0000777bb65d8bed  call rax
0000777bb65d8bef  movaps xmm1, [rsp]
0000777bb65d8bf3  add rsp, 0x30
0000777bb65d8bf7  vmovaps xmm0, [rsp]
0000777bb65d8bfc  vmovaps xmm2, [rsp+0x10]
0000777bb65d8c02  vmovaps xmm3, [rsp+0x20]
0000777bb65d8c08  vmovaps xmm4, [rsp+0x30]
0000777bb65d8c0e  vmovaps xmm5, [rsp+0x40]
0000777bb65d8c14  vmovaps xmm6, [rsp+0x50]
0000777bb65d8c1a  vmovaps xmm7, [rsp+0x60]
0000777bb65d8c20  vmovaps xmm8, [rsp+0x70]
0000777bb65d8c26  vmovaps xmm9, [rsp+0x80]
0000777bb65d8c2f  vmovaps xmm10, [rsp+0x90]
0000777bb65d8c38  vmovaps xmm11, [rsp+0xA0]
0000777bb65d8c41  vmovaps xmm12, [rsp+0xB0]
0000777bb65d8c4a  vmovaps xmm13, [rsp+0xC0]
0000777bb65d8c53  vmovaps xmm14, [rsp+0xD0]
0000777bb65d8c5c  vmovaps xmm15, [rsp+0xE0]
0000777bb65d8c65  add rsp, 0xF0
0000777bb65d8c6c  pop r11
0000777bb65d8c6e  pop r10
0000777bb65d8c70  pop r9
0000777bb65d8c72  pop r8
0000777bb65d8c74  pop rsi
0000777bb65d8c75  pop rdi
0000777bb65d8c76  pop rdx
0000777bb65d8c77  pop rcx
0000777bb65d8c78  pop rax
0000777bb65d8c79  add rsp, 0x08
0000777bb65d8c7d  jmp 0x0000777BB65D613B
0000777bb65d8c82  sub rsp, 0x08
0000777bb65d8c86  push rax
0000777bb65d8c87  push rcx
0000777bb65d8c88  push rdx
0000777bb65d8c89  push rdi
0000777bb65d8c8a  push rsi
0000777bb65d8c8b  push r8
0000777bb65d8c8d  push r9
0000777bb65d8c8f  push r10
0000777bb65d8c91  push r11
0000777bb65d8c93  sub rsp, 0xF0
0000777bb65d8c9a  vmovaps [rsp], xmm0
0000777bb65d8c9f  vmovaps [rsp+0x10], xmm1
0000777bb65d8ca5  vmovaps [rsp+0x20], xmm2
0000777bb65d8cab  vmovaps [rsp+0x30], xmm3
0000777bb65d8cb1  vmovaps [rsp+0x40], xmm5
0000777bb65d8cb7  vmovaps [rsp+0x50], xmm6
0000777bb65d8cbd  vmovaps [rsp+0x60], xmm7
0000777bb65d8cc3  vmovaps [rsp+0x70], xmm8
0000777bb65d8cc9  vmovaps [rsp+0x80], xmm9
0000777bb65d8cd2  vmovaps [rsp+0x90], xmm10
0000777bb65d8cdb  vmovaps [rsp+0xA0], xmm11
0000777bb65d8ce4  vmovaps [rsp+0xB0], xmm12
0000777bb65d8ced  vmovaps [rsp+0xC0], xmm13
0000777bb65d8cf6  vmovaps [rsp+0xD0], xmm14
0000777bb65d8cff  vmovaps [rsp+0xE0], xmm15
0000777bb65d8d08  sub rsp, 0x30
0000777bb65d8d0c  movaps [rsp], xmm4
0000777bb65d8d10  movaps [rsp+0x10], xmm2
0000777bb65d8d15  movaps [rsp+0x20], xmm9
0000777bb65d8d1b  lea rdi, [rsp]
0000777bb65d8d1f  mov esi, 0x00
0000777bb65d8d24  mov rax, 0x569DC437B530
0000777bb65d8d2e  call rax
0000777bb65d8d30  movaps xmm4, [rsp]
0000777bb65d8d34  add rsp, 0x30
0000777bb65d8d38  vmovaps xmm0, [rsp]
0000777bb65d8d3d  vmovaps xmm1, [rsp+0x10]
0000777bb65d8d43  vmovaps xmm2, [rsp+0x20]
0000777bb65d8d49  vmovaps xmm3, [rsp+0x30]
0000777bb65d8d4f  vmovaps xmm5, [rsp+0x40]
0000777bb65d8d55  vmovaps xmm6, [rsp+0x50]
0000777bb65d8d5b  vmovaps xmm7, [rsp+0x60]
0000777bb65d8d61  vmovaps xmm8, [rsp+0x70]
0000777bb65d8d67  vmovaps xmm9, [rsp+0x80]
0000777bb65d8d70  vmovaps xmm10, [rsp+0x90]
0000777bb65d8d79  vmovaps xmm11, [rsp+0xA0]
0000777bb65d8d82  vmovaps xmm12, [rsp+0xB0]
0000777bb65d8d8b  vmovaps xmm13, [rsp+0xC0]
0000777bb65d8d94  vmovaps xmm14, [rsp+0xD0]
0000777bb65d8d9d  vmovaps xmm15, [rsp+0xE0]
0000777bb65d8da6  add rsp, 0xF0
0000777bb65d8dad  pop r11
0000777bb65d8daf  pop r10
0000777bb65d8db1  pop r9
0000777bb65d8db3  pop r8
0000777bb65d8db5  pop rsi
0000777bb65d8db6  pop rdi
0000777bb65d8db7  pop rdx
0000777bb65d8db8  pop rcx
0000777bb65d8db9  pop rax
0000777bb65d8dba  add rsp, 0x08
0000777bb65d8dbe  jmp 0x0000777BB65D616B
0000777bb65d8dc3  sub rsp, 0x08
0000777bb65d8dc7  push rax
0000777bb65d8dc8  push rcx
0000777bb65d8dc9  push rdx
0000777bb65d8dca  push rdi
0000777bb65d8dcb  push rsi
0000777bb65d8dcc  push r8
0000777bb65d8dce  push r9
0000777bb65d8dd0  push r10
0000777bb65d8dd2  push r11
0000777bb65d8dd4  sub rsp, 0xF0
0000777bb65d8ddb  vmovaps [rsp], xmm0
0000777bb65d8de0  vmovaps [rsp+0x10], xmm1
0000777bb65d8de6  vmovaps [rsp+0x20], xmm2
0000777bb65d8dec  vmovaps [rsp+0x30], xmm3
0000777bb65d8df2  vmovaps [rsp+0x40], xmm4
0000777bb65d8df8  vmovaps [rsp+0x50], xmm5
0000777bb65d8dfe  vmovaps [rsp+0x60], xmm6
0000777bb65d8e04  vmovaps [rsp+0x70], xmm7
0000777bb65d8e0a  vmovaps [rsp+0x80], xmm8
0000777bb65d8e13  vmovaps [rsp+0x90], xmm10
0000777bb65d8e1c  vmovaps [rsp+0xA0], xmm11
0000777bb65d8e25  vmovaps [rsp+0xB0], xmm12
0000777bb65d8e2e  vmovaps [rsp+0xC0], xmm13
0000777bb65d8e37  vmovaps [rsp+0xD0], xmm14
0000777bb65d8e40  vmovaps [rsp+0xE0], xmm15
0000777bb65d8e49  sub rsp, 0x30
0000777bb65d8e4d  movaps [rsp], xmm9
0000777bb65d8e52  movaps [rsp+0x10], xmm2
0000777bb65d8e57  movaps [rsp+0x20], xmm1
0000777bb65d8e5c  lea rdi, [rsp]
0000777bb65d8e60  mov esi, 0x00
0000777bb65d8e65  mov rax, 0x569DC437B530
0000777bb65d8e6f  call rax
0000777bb65d8e71  movaps xmm9, [rsp]
0000777bb65d8e76  add rsp, 0x30
0000777bb65d8e7a  vmovaps xmm0, [rsp]
0000777bb65d8e7f  vmovaps xmm1, [rsp+0x10]
0000777bb65d8e85  vmovaps xmm2, [rsp+0x20]
0000777bb65d8e8b  vmovaps xmm3, [rsp+0x30]
0000777bb65d8e91  vmovaps xmm4, [rsp+0x40]
0000777bb65d8e97  vmovaps xmm5, [rsp+0x50]
0000777bb65d8e9d  vmovaps xmm6, [rsp+0x60]
0000777bb65d8ea3  vmovaps xmm7, [rsp+0x70]
0000777bb65d8ea9  vmovaps xmm8, [rsp+0x80]
0000777bb65d8eb2  vmovaps xmm10, [rsp+0x90]
0000777bb65d8ebb  vmovaps xmm11, [rsp+0xA0]
0000777bb65d8ec4  vmovaps xmm12, [rsp+0xB0]
0000777bb65d8ecd  vmovaps xmm13, [rsp+0xC0]
0000777bb65d8ed6  vmovaps xmm14, [rsp+0xD0]
0000777bb65d8edf  vmovaps xmm15, [rsp+0xE0]
0000777bb65d8ee8  add rsp, 0xF0
0000777bb65d8eef  pop r11
0000777bb65d8ef1  pop r10
0000777bb65d8ef3  pop r9
0000777bb65d8ef5  pop r8
0000777bb65d8ef7  pop rsi
0000777bb65d8ef8  pop rdi
0000777bb65d8ef9  pop rdx
0000777bb65d8efa  pop rcx
0000777bb65d8efb  pop rax
0000777bb65d8efc  add rsp, 0x08
0000777bb65d8f00  jmp 0x0000777BB65D61A1
0000777bb65d8f05  sub rsp, 0x08
0000777bb65d8f09  push rax
0000777bb65d8f0a  push rcx
0000777bb65d8f0b  push rdx
0000777bb65d8f0c  push rdi
0000777bb65d8f0d  push rsi
0000777bb65d8f0e  push r8
0000777bb65d8f10  push r9
0000777bb65d8f12  push r10
0000777bb65d8f14  push r11
0000777bb65d8f16  sub rsp, 0xF0
0000777bb65d8f1d  vmovaps [rsp], xmm0
0000777bb65d8f22  vmovaps [rsp+0x10], xmm2
0000777bb65d8f28  vmovaps [rsp+0x20], xmm3
0000777bb65d8f2e  vmovaps [rsp+0x30], xmm4
0000777bb65d8f34  vmovaps [rsp+0x40], xmm5
0000777bb65d8f3a  vmovaps [rsp+0x50], xmm6
0000777bb65d8f40  vmovaps [rsp+0x60], xmm7
0000777bb65d8f46  vmovaps [rsp+0x70], xmm8
0000777bb65d8f4c  vmovaps [rsp+0x80], xmm9
0000777bb65d8f55  vmovaps [rsp+0x90], xmm10
0000777bb65d8f5e  vmovaps [rsp+0xA0], xmm11
0000777bb65d8f67  vmovaps [rsp+0xB0], xmm12
0000777bb65d8f70  vmovaps [rsp+0xC0], xmm13
0000777bb65d8f79  vmovaps [rsp+0xD0], xmm14
0000777bb65d8f82  vmovaps [rsp+0xE0], xmm15
0000777bb65d8f8b  sub rsp, 0x30
0000777bb65d8f8f  movaps [rsp], xmm1
0000777bb65d8f93  movaps [rsp+0x10], xmm15
0000777bb65d8f99  movaps [rsp+0x20], xmm6
0000777bb65d8f9e  lea rdi, [rsp]
0000777bb65d8fa2  mov esi, 0x00
0000777bb65d8fa7  mov rax, 0x569DC437B530
0000777bb65d8fb1  call rax
0000777bb65d8fb3  movaps xmm1, [rsp]
0000777bb65d8fb7  add rsp, 0x30
0000777bb65d8fbb  vmovaps xmm0, [rsp]
0000777bb65d8fc0  vmovaps xmm2, [rsp+0x10]
0000777bb65d8fc6  vmovaps xmm3, [rsp+0x20]
0000777bb65d8fcc  vmovaps xmm4, [rsp+0x30]
0000777bb65d8fd2  vmovaps xmm5, [rsp+0x40]
0000777bb65d8fd8  vmovaps xmm6, [rsp+0x50]
0000777bb65d8fde  vmovaps xmm7, [rsp+0x60]
0000777bb65d8fe4  vmovaps xmm8, [rsp+0x70]
0000777bb65d8fea  vmovaps xmm9, [rsp+0x80]
0000777bb65d8ff3  vmovaps xmm10, [rsp+0x90]
0000777bb65d8ffc  vmovaps xmm11, [rsp+0xA0]
0000777bb65d9005  vmovaps xmm12, [rsp+0xB0]
0000777bb65d900e  vmovaps xmm13, [rsp+0xC0]
0000777bb65d9017  vmovaps xmm14, [rsp+0xD0]
0000777bb65d9020  vmovaps xmm15, [rsp+0xE0]
0000777bb65d9029  add rsp, 0xF0
0000777bb65d9030  pop r11
0000777bb65d9032  pop r10
0000777bb65d9034  pop r9
0000777bb65d9036  pop r8
0000777bb65d9038  pop rsi
0000777bb65d9039  pop rdi
0000777bb65d903a  pop rdx
0000777bb65d903b  pop rcx
0000777bb65d903c  pop rax
0000777bb65d903d  add rsp, 0x08
0000777bb65d9041  jmp 0x0000777BB65D61C2
0000777bb65d9046  sub rsp, 0x08
0000777bb65d904a  push rax
0000777bb65d904b  push rcx
0000777bb65d904c  push rdx
0000777bb65d904d  push rdi
0000777bb65d904e  push rsi
0000777bb65d904f  push r8
0000777bb65d9051  push r9
0000777bb65d9053  push r10
0000777bb65d9055  push r11
0000777bb65d9057  sub rsp, 0xF0
0000777bb65d905e  vmovaps [rsp], xmm0
0000777bb65d9063  vmovaps [rsp+0x10], xmm1
0000777bb65d9069  vmovaps [rsp+0x20], xmm2
0000777bb65d906f  vmovaps [rsp+0x30], xmm3
0000777bb65d9075  vmovaps [rsp+0x40], xmm4
0000777bb65d907b  vmovaps [rsp+0x50], xmm5
0000777bb65d9081  vmovaps [rsp+0x60], xmm6
0000777bb65d9087  vmovaps [rsp+0x70], xmm7
0000777bb65d908d  vmovaps [rsp+0x80], xmm8
0000777bb65d9096  vmovaps [rsp+0x90], xmm9
0000777bb65d909f  vmovaps [rsp+0xA0], xmm10
0000777bb65d90a8  vmovaps [rsp+0xB0], xmm11
0000777bb65d90b1  vmovaps [rsp+0xC0], xmm12
0000777bb65d90ba  vmovaps [rsp+0xD0], xmm13
0000777bb65d90c3  vmovaps [rsp+0xE0], xmm14
0000777bb65d90cc  sub rsp, 0x30
0000777bb65d90d0  movaps [rsp], xmm15
0000777bb65d90d5  movaps [rsp+0x10], xmm5
0000777bb65d90da  movaps [rsp+0x20], xmm3
0000777bb65d90df  lea rdi, [rsp]
0000777bb65d90e3  mov esi, 0x00
0000777bb65d90e8  mov rax, 0x569DC437B530
0000777bb65d90f2  call rax
0000777bb65d90f4  movaps xmm15, [rsp]
0000777bb65d90f9  add rsp, 0x30
0000777bb65d90fd  vmovaps xmm0, [rsp]
0000777bb65d9102  vmovaps xmm1, [rsp+0x10]
0000777bb65d9108  vmovaps xmm2, [rsp+0x20]
0000777bb65d910e  vmovaps xmm3, [rsp+0x30]
0000777bb65d9114  vmovaps xmm4, [rsp+0x40]
0000777bb65d911a  vmovaps xmm5, [rsp+0x50]
0000777bb65d9120  vmovaps xmm6, [rsp+0x60]
0000777bb65d9126  vmovaps xmm7, [rsp+0x70]
0000777bb65d912c  vmovaps xmm8, [rsp+0x80]
0000777bb65d9135  vmovaps xmm9, [rsp+0x90]
0000777bb65d913e  vmovaps xmm10, [rsp+0xA0]
0000777bb65d9147  vmovaps xmm11, [rsp+0xB0]
0000777bb65d9150  vmovaps xmm12, [rsp+0xC0]
0000777bb65d9159  vmovaps xmm13, [rsp+0xD0]
0000777bb65d9162  vmovaps xmm14, [rsp+0xE0]
0000777bb65d916b  add rsp, 0xF0
0000777bb65d9172  pop r11
0000777bb65d9174  pop r10
0000777bb65d9176  pop r9
0000777bb65d9178  pop r8
0000777bb65d917a  pop rsi
0000777bb65d917b  pop rdi
0000777bb65d917c  pop rdx
0000777bb65d917d  pop rcx
0000777bb65d917e  pop rax
0000777bb65d917f  add rsp, 0x08
0000777bb65d9183  jmp 0x0000777BB65D61DC
0000777bb65d9188  sub rsp, 0x08
0000777bb65d918c  push rax
0000777bb65d918d  push rcx
0000777bb65d918e  push rdx
0000777bb65d918f  push rdi
0000777bb65d9190  push rsi
0000777bb65d9191  push r8
0000777bb65d9193  push r9
0000777bb65d9195  push r10
0000777bb65d9197  push r11
0000777bb65d9199  sub rsp, 0xF0
0000777bb65d91a0  vmovaps [rsp], xmm0
0000777bb65d91a5  vmovaps [rsp+0x10], xmm1
0000777bb65d91ab  vmovaps [rsp+0x20], xmm2
0000777bb65d91b1  vmovaps [rsp+0x30], xmm3
0000777bb65d91b7  vmovaps [rsp+0x40], xmm4
0000777bb65d91bd  vmovaps [rsp+0x50], xmm6
0000777bb65d91c3  vmovaps [rsp+0x60], xmm7
0000777bb65d91c9  vmovaps [rsp+0x70], xmm8
0000777bb65d91cf  vmovaps [rsp+0x80], xmm9
0000777bb65d91d8  vmovaps [rsp+0x90], xmm10
0000777bb65d91e1  vmovaps [rsp+0xA0], xmm11
0000777bb65d91ea  vmovaps [rsp+0xB0], xmm12
0000777bb65d91f3  vmovaps [rsp+0xC0], xmm13
0000777bb65d91fc  vmovaps [rsp+0xD0], xmm14
0000777bb65d9205  vmovaps [rsp+0xE0], xmm15
0000777bb65d920e  sub rsp, 0x30
0000777bb65d9212  movaps [rsp], xmm5
0000777bb65d9216  movaps [rsp+0x10], xmm8
0000777bb65d921c  movaps [rsp+0x20], xmm6
0000777bb65d9221  lea rdi, [rsp]
0000777bb65d9225  mov esi, 0x00
0000777bb65d922a  mov rax, 0x569DC437B530
0000777bb65d9234  call rax
0000777bb65d9236  movaps xmm5, [rsp]
0000777bb65d923a  add rsp, 0x30
0000777bb65d923e  vmovaps xmm0, [rsp]
0000777bb65d9243  vmovaps xmm1, [rsp+0x10]
0000777bb65d9249  vmovaps xmm2, [rsp+0x20]
0000777bb65d924f  vmovaps xmm3, [rsp+0x30]
0000777bb65d9255  vmovaps xmm4, [rsp+0x40]
0000777bb65d925b  vmovaps xmm6, [rsp+0x50]
0000777bb65d9261  vmovaps xmm7, [rsp+0x60]
0000777bb65d9267  vmovaps xmm8, [rsp+0x70]
0000777bb65d926d  vmovaps xmm9, [rsp+0x80]
0000777bb65d9276  vmovaps xmm10, [rsp+0x90]
0000777bb65d927f  vmovaps xmm11, [rsp+0xA0]
0000777bb65d9288  vmovaps xmm12, [rsp+0xB0]
0000777bb65d9291  vmovaps xmm13, [rsp+0xC0]
0000777bb65d929a  vmovaps xmm14, [rsp+0xD0]
0000777bb65d92a3  vmovaps xmm15, [rsp+0xE0]
0000777bb65d92ac  add rsp, 0xF0
0000777bb65d92b3  pop r11
0000777bb65d92b5  pop r10
0000777bb65d92b7  pop r9
0000777bb65d92b9  pop r8
0000777bb65d92bb  pop rsi
0000777bb65d92bc  pop rdi
0000777bb65d92bd  pop rdx
0000777bb65d92be  pop rcx
0000777bb65d92bf  pop rax
0000777bb65d92c0  add rsp, 0x08
0000777bb65d92c4  jmp 0x0000777BB65D6200
0000777bb65d92c9  sub rsp, 0x08
0000777bb65d92cd  push rax
0000777bb65d92ce  push rcx
0000777bb65d92cf  push rdx
0000777bb65d92d0  push rdi
0000777bb65d92d1  push rsi
0000777bb65d92d2  push r8
0000777bb65d92d4  push r9
0000777bb65d92d6  push r10
0000777bb65d92d8  push r11
0000777bb65d92da  sub rsp, 0xF0
0000777bb65d92e1  vmovaps [rsp], xmm0
0000777bb65d92e6  vmovaps [rsp+0x10], xmm1
0000777bb65d92ec  vmovaps [rsp+0x20], xmm2
0000777bb65d92f2  vmovaps [rsp+0x30], xmm3
0000777bb65d92f8  vmovaps [rsp+0x40], xmm4
0000777bb65d92fe  vmovaps [rsp+0x50], xmm5
0000777bb65d9304  vmovaps [rsp+0x60], xmm7
0000777bb65d930a  vmovaps [rsp+0x70], xmm8
0000777bb65d9310  vmovaps [rsp+0x80], xmm9
0000777bb65d9319  vmovaps [rsp+0x90], xmm10
0000777bb65d9322  vmovaps [rsp+0xA0], xmm11
0000777bb65d932b  vmovaps [rsp+0xB0], xmm12
0000777bb65d9334  vmovaps [rsp+0xC0], xmm13
0000777bb65d933d  vmovaps [rsp+0xD0], xmm14
0000777bb65d9346  vmovaps [rsp+0xE0], xmm15
0000777bb65d934f  sub rsp, 0x30
0000777bb65d9353  movaps [rsp], xmm6
0000777bb65d9357  movaps [rsp+0x10], xmm10
0000777bb65d935d  movaps [rsp+0x20], xmm8
0000777bb65d9363  lea rdi, [rsp]
0000777bb65d9367  mov esi, 0x00
0000777bb65d936c  mov rax, 0x569DC437B530
0000777bb65d9376  call rax
0000777bb65d9378  movaps xmm6, [rsp]
0000777bb65d937c  add rsp, 0x30
0000777bb65d9380  vmovaps xmm0, [rsp]
0000777bb65d9385  vmovaps xmm1, [rsp+0x10]
0000777bb65d938b  vmovaps xmm2, [rsp+0x20]
0000777bb65d9391  vmovaps xmm3, [rsp+0x30]
0000777bb65d9397  vmovaps xmm4, [rsp+0x40]
0000777bb65d939d  vmovaps xmm5, [rsp+0x50]
0000777bb65d93a3  vmovaps xmm7, [rsp+0x60]
0000777bb65d93a9  vmovaps xmm8, [rsp+0x70]
0000777bb65d93af  vmovaps xmm9, [rsp+0x80]
0000777bb65d93b8  vmovaps xmm10, [rsp+0x90]
0000777bb65d93c1  vmovaps xmm11, [rsp+0xA0]
0000777bb65d93ca  vmovaps xmm12, [rsp+0xB0]
0000777bb65d93d3  vmovaps xmm13, [rsp+0xC0]
0000777bb65d93dc  vmovaps xmm14, [rsp+0xD0]
0000777bb65d93e5  vmovaps xmm15, [rsp+0xE0]
0000777bb65d93ee  add rsp, 0xF0
0000777bb65d93f5  pop r11
0000777bb65d93f7  pop r10
0000777bb65d93f9  pop r9
0000777bb65d93fb  pop r8
0000777bb65d93fd  pop rsi
0000777bb65d93fe  pop rdi
0000777bb65d93ff  pop rdx
0000777bb65d9400  pop rcx
0000777bb65d9401  pop rax
0000777bb65d9402  add rsp, 0x08
0000777bb65d9406  jmp 0x0000777BB65D6225
0000777bb65d940b  sub rsp, 0x08
0000777bb65d940f  push rax
0000777bb65d9410  push rcx
0000777bb65d9411  push rdx
0000777bb65d9412  push rdi
0000777bb65d9413  push rsi
0000777bb65d9414  push r8
0000777bb65d9416  push r9
0000777bb65d9418  push r10
0000777bb65d941a  push r11
0000777bb65d941c  sub rsp, 0xF0
0000777bb65d9423  vmovaps [rsp], xmm0
0000777bb65d9428  vmovaps [rsp+0x10], xmm1
0000777bb65d942e  vmovaps [rsp+0x20], xmm2
0000777bb65d9434  vmovaps [rsp+0x30], xmm3
0000777bb65d943a  vmovaps [rsp+0x40], xmm4
0000777bb65d9440  vmovaps [rsp+0x50], xmm5
0000777bb65d9446  vmovaps [rsp+0x60], xmm6
0000777bb65d944c  vmovaps [rsp+0x70], xmm7
0000777bb65d9452  vmovaps [rsp+0x80], xmm8
0000777bb65d945b  vmovaps [rsp+0x90], xmm9
0000777bb65d9464  vmovaps [rsp+0xA0], xmm11
0000777bb65d946d  vmovaps [rsp+0xB0], xmm12
0000777bb65d9476  vmovaps [rsp+0xC0], xmm13
0000777bb65d947f  vmovaps [rsp+0xD0], xmm14
0000777bb65d9488  vmovaps [rsp+0xE0], xmm15
0000777bb65d9491  sub rsp, 0x30
0000777bb65d9495  movaps [rsp], xmm10
0000777bb65d949a  movaps [rsp+0x10], xmm8
0000777bb65d94a0  movaps [rsp+0x20], xmm14
0000777bb65d94a6  lea rdi, [rsp]
0000777bb65d94aa  mov esi, 0x00
0000777bb65d94af  mov rax, 0x569DC437B530
0000777bb65d94b9  call rax
0000777bb65d94bb  movaps xmm10, [rsp]
0000777bb65d94c0  add rsp, 0x30
0000777bb65d94c4  vmovaps xmm0, [rsp]
0000777bb65d94c9  vmovaps xmm1, [rsp+0x10]
0000777bb65d94cf  vmovaps xmm2, [rsp+0x20]
0000777bb65d94d5  vmovaps xmm3, [rsp+0x30]
0000777bb65d94db  vmovaps xmm4, [rsp+0x40]
0000777bb65d94e1  vmovaps xmm5, [rsp+0x50]
0000777bb65d94e7  vmovaps xmm6, [rsp+0x60]
0000777bb65d94ed  vmovaps xmm7, [rsp+0x70]
0000777bb65d94f3  vmovaps xmm8, [rsp+0x80]
0000777bb65d94fc  vmovaps xmm9, [rsp+0x90]
0000777bb65d9505  vmovaps xmm11, [rsp+0xA0]
0000777bb65d950e  vmovaps xmm12, [rsp+0xB0]
0000777bb65d9517  vmovaps xmm13, [rsp+0xC0]
0000777bb65d9520  vmovaps xmm14, [rsp+0xD0]
0000777bb65d9529  vmovaps xmm15, [rsp+0xE0]
0000777bb65d9532  add rsp, 0xF0
0000777bb65d9539  pop r11
0000777bb65d953b  pop r10
0000777bb65d953d  pop r9
0000777bb65d953f  pop r8
0000777bb65d9541  pop rsi
0000777bb65d9542  pop rdi
0000777bb65d9543  pop rdx
0000777bb65d9544  pop rcx
0000777bb65d9545  pop rax
0000777bb65d9546  add rsp, 0x08
0000777bb65d954a  jmp 0x0000777BB65D6245
0000777bb65d954f  sub rsp, 0x08
0000777bb65d9553  push rax
0000777bb65d9554  push rcx
0000777bb65d9555  push rdx
0000777bb65d9556  push rdi
0000777bb65d9557  push rsi
0000777bb65d9558  push r8
0000777bb65d955a  push r9
0000777bb65d955c  push r10
0000777bb65d955e  push r11
0000777bb65d9560  sub rsp, 0xF0
0000777bb65d9567  vmovaps [rsp], xmm0
0000777bb65d956c  vmovaps [rsp+0x10], xmm1
0000777bb65d9572  vmovaps [rsp+0x20], xmm2
0000777bb65d9578  vmovaps [rsp+0x30], xmm3
0000777bb65d957e  vmovaps [rsp+0x40], xmm4
0000777bb65d9584  vmovaps [rsp+0x50], xmm5
0000777bb65d958a  vmovaps [rsp+0x60], xmm6
0000777bb65d9590  vmovaps [rsp+0x70], xmm7
0000777bb65d9596  vmovaps [rsp+0x80], xmm8
0000777bb65d959f  vmovaps [rsp+0x90], xmm9
0000777bb65d95a8  vmovaps [rsp+0xA0], xmm10
0000777bb65d95b1  vmovaps [rsp+0xB0], xmm11
0000777bb65d95ba  vmovaps [rsp+0xC0], xmm12
0000777bb65d95c3  vmovaps [rsp+0xD0], xmm13
0000777bb65d95cc  vmovaps [rsp+0xE0], xmm15
0000777bb65d95d5  sub rsp, 0x30
0000777bb65d95d9  movaps [rsp], xmm14
0000777bb65d95de  movaps [rsp+0x10], xmm8
0000777bb65d95e4  movaps [rsp+0x20], xmm4
0000777bb65d95e9  lea rdi, [rsp]
0000777bb65d95ed  mov esi, 0x00
0000777bb65d95f2  mov rax, 0x569DC437B530
0000777bb65d95fc  call rax
0000777bb65d95fe  movaps xmm14, [rsp]
0000777bb65d9603  add rsp, 0x30
0000777bb65d9607  vmovaps xmm0, [rsp]
0000777bb65d960c  vmovaps xmm1, [rsp+0x10]
0000777bb65d9612  vmovaps xmm2, [rsp+0x20]
0000777bb65d9618  vmovaps xmm3, [rsp+0x30]
0000777bb65d961e  vmovaps xmm4, [rsp+0x40]
0000777bb65d9624  vmovaps xmm5, [rsp+0x50]
0000777bb65d962a  vmovaps xmm6, [rsp+0x60]
0000777bb65d9630  vmovaps xmm7, [rsp+0x70]
0000777bb65d9636  vmovaps xmm8, [rsp+0x80]
0000777bb65d963f  vmovaps xmm9, [rsp+0x90]
0000777bb65d9648  vmovaps xmm10, [rsp+0xA0]
0000777bb65d9651  vmovaps xmm11, [rsp+0xB0]
0000777bb65d965a  vmovaps xmm12, [rsp+0xC0]
0000777bb65d9663  vmovaps xmm13, [rsp+0xD0]
0000777bb65d966c  vmovaps xmm15, [rsp+0xE0]
0000777bb65d9675  add rsp, 0xF0
0000777bb65d967c  pop r11
0000777bb65d967e  pop r10
0000777bb65d9680  pop r9
0000777bb65d9682  pop r8
0000777bb65d9684  pop rsi
0000777bb65d9685  pop rdi
0000777bb65d9686  pop rdx
0000777bb65d9687  pop rcx
0000777bb65d9688  pop rax
0000777bb65d9689  add rsp, 0x08
0000777bb65d968d  jmp 0x0000777BB65D6265
0000777bb65d9692  sub rsp, 0x08
0000777bb65d9696  push rax
0000777bb65d9697  push rcx
0000777bb65d9698  push rdx
0000777bb65d9699  push rdi
0000777bb65d969a  push rsi
0000777bb65d969b  push r8
0000777bb65d969d  push r9
0000777bb65d969f  push r10
0000777bb65d96a1  push r11
0000777bb65d96a3  sub rsp, 0xF0
0000777bb65d96aa  vmovaps [rsp], xmm0
0000777bb65d96af  vmovaps [rsp+0x10], xmm1
0000777bb65d96b5  vmovaps [rsp+0x20], xmm2
0000777bb65d96bb  vmovaps [rsp+0x30], xmm3
0000777bb65d96c1  vmovaps [rsp+0x40], xmm5
0000777bb65d96c7  vmovaps [rsp+0x50], xmm6
0000777bb65d96cd  vmovaps [rsp+0x60], xmm7
0000777bb65d96d3  vmovaps [rsp+0x70], xmm8
0000777bb65d96d9  vmovaps [rsp+0x80], xmm9
0000777bb65d96e2  vmovaps [rsp+0x90], xmm10
0000777bb65d96eb  vmovaps [rsp+0xA0], xmm11
0000777bb65d96f4  vmovaps [rsp+0xB0], xmm12
0000777bb65d96fd  vmovaps [rsp+0xC0], xmm13
0000777bb65d9706  vmovaps [rsp+0xD0], xmm14
0000777bb65d970f  vmovaps [rsp+0xE0], xmm15
0000777bb65d9718  sub rsp, 0x30
0000777bb65d971c  movaps [rsp], xmm4
0000777bb65d9720  movaps [rsp+0x10], xmm13
0000777bb65d9726  movaps [rsp+0x20], xmm8
0000777bb65d972c  lea rdi, [rsp]
0000777bb65d9730  mov esi, 0x00
0000777bb65d9735  mov rax, 0x569DC437B530
0000777bb65d973f  call rax
0000777bb65d9741  movaps xmm4, [rsp]
0000777bb65d9745  add rsp, 0x30
0000777bb65d9749  vmovaps xmm0, [rsp]
0000777bb65d974e  vmovaps xmm1, [rsp+0x10]
0000777bb65d9754  vmovaps xmm2, [rsp+0x20]
0000777bb65d975a  vmovaps xmm3, [rsp+0x30]
0000777bb65d9760  vmovaps xmm5, [rsp+0x40]
0000777bb65d9766  vmovaps xmm6, [rsp+0x50]
0000777bb65d976c  vmovaps xmm7, [rsp+0x60]
0000777bb65d9772  vmovaps xmm8, [rsp+0x70]
0000777bb65d9778  vmovaps xmm9, [rsp+0x80]
0000777bb65d9781  vmovaps xmm10, [rsp+0x90]
0000777bb65d978a  vmovaps xmm11, [rsp+0xA0]
0000777bb65d9793  vmovaps xmm12, [rsp+0xB0]
0000777bb65d979c  vmovaps xmm13, [rsp+0xC0]
0000777bb65d97a5  vmovaps xmm14, [rsp+0xD0]
0000777bb65d97ae  vmovaps xmm15, [rsp+0xE0]
0000777bb65d97b7  add rsp, 0xF0
0000777bb65d97be  pop r11
0000777bb65d97c0  pop r10
0000777bb65d97c2  pop r9
0000777bb65d97c4  pop r8
0000777bb65d97c6  pop rsi
0000777bb65d97c7  pop rdi
0000777bb65d97c8  pop rdx
0000777bb65d97c9  pop rcx
0000777bb65d97ca  pop rax
0000777bb65d97cb  add rsp, 0x08
0000777bb65d97cf  jmp 0x0000777BB65D628A
0000777bb65d97d4  sub rsp, 0x08
0000777bb65d97d8  push rax
0000777bb65d97d9  push rcx
0000777bb65d97da  push rdx
0000777bb65d97db  push rdi
0000777bb65d97dc  push rsi
0000777bb65d97dd  push r8
0000777bb65d97df  push r9
0000777bb65d97e1  push r10
0000777bb65d97e3  push r11
0000777bb65d97e5  sub rsp, 0xF0
0000777bb65d97ec  vmovaps [rsp], xmm0
0000777bb65d97f1  vmovaps [rsp+0x10], xmm1
0000777bb65d97f7  vmovaps [rsp+0x20], xmm2
0000777bb65d97fd  vmovaps [rsp+0x30], xmm3
0000777bb65d9803  vmovaps [rsp+0x40], xmm4
0000777bb65d9809  vmovaps [rsp+0x50], xmm5
0000777bb65d980f  vmovaps [rsp+0x60], xmm6
0000777bb65d9815  vmovaps [rsp+0x70], xmm7
0000777bb65d981b  vmovaps [rsp+0x80], xmm8
0000777bb65d9824  vmovaps [rsp+0x90], xmm9
0000777bb65d982d  vmovaps [rsp+0xA0], xmm10
0000777bb65d9836  vmovaps [rsp+0xB0], xmm11
0000777bb65d983f  vmovaps [rsp+0xC0], xmm12
0000777bb65d9848  vmovaps [rsp+0xD0], xmm14
0000777bb65d9851  vmovaps [rsp+0xE0], xmm15
0000777bb65d985a  sub rsp, 0x30
0000777bb65d985e  movaps [rsp], xmm13
0000777bb65d9863  movaps [rsp+0x10], xmm15
0000777bb65d9869  movaps [rsp+0x20], xmm9
0000777bb65d986f  lea rdi, [rsp]
0000777bb65d9873  mov esi, 0x00
0000777bb65d9878  mov rax, 0x569DC437B530
0000777bb65d9882  call rax
0000777bb65d9884  movaps xmm13, [rsp]
0000777bb65d9889  add rsp, 0x30
0000777bb65d988d  vmovaps xmm0, [rsp]
0000777bb65d9892  vmovaps xmm1, [rsp+0x10]
0000777bb65d9898  vmovaps xmm2, [rsp+0x20]
0000777bb65d989e  vmovaps xmm3, [rsp+0x30]
0000777bb65d98a4  vmovaps xmm4, [rsp+0x40]
0000777bb65d98aa  vmovaps xmm5, [rsp+0x50]
0000777bb65d98b0  vmovaps xmm6, [rsp+0x60]
0000777bb65d98b6  vmovaps xmm7, [rsp+0x70]
0000777bb65d98bc  vmovaps xmm8, [rsp+0x80]
0000777bb65d98c5  vmovaps xmm9, [rsp+0x90]
0000777bb65d98ce  vmovaps xmm10, [rsp+0xA0]
0000777bb65d98d7  vmovaps xmm11, [rsp+0xB0]
0000777bb65d98e0  vmovaps xmm12, [rsp+0xC0]
0000777bb65d98e9  vmovaps xmm14, [rsp+0xD0]
0000777bb65d98f2  vmovaps xmm15, [rsp+0xE0]
0000777bb65d98fb  add rsp, 0xF0
0000777bb65d9902  pop r11
0000777bb65d9904  pop r10
0000777bb65d9906  pop r9
0000777bb65d9908  pop r8
0000777bb65d990a  pop rsi
0000777bb65d990b  pop rdi
0000777bb65d990c  pop rdx
0000777bb65d990d  pop rcx
0000777bb65d990e  pop rax
0000777bb65d990f  add rsp, 0x08
0000777bb65d9913  jmp 0x0000777BB65D62A5
0000777bb65d9918  sub rsp, 0x08
0000777bb65d991c  push rax
0000777bb65d991d  push rcx
0000777bb65d991e  push rdx
0000777bb65d991f  push rdi
0000777bb65d9920  push rsi
0000777bb65d9921  push r8
0000777bb65d9923  push r9
0000777bb65d9925  push r10
0000777bb65d9927  push r11
0000777bb65d9929  sub rsp, 0xF0
0000777bb65d9930  vmovaps [rsp], xmm0
0000777bb65d9935  vmovaps [rsp+0x10], xmm1
0000777bb65d993b  vmovaps [rsp+0x20], xmm2
0000777bb65d9941  vmovaps [rsp+0x30], xmm3
0000777bb65d9947  vmovaps [rsp+0x40], xmm4
0000777bb65d994d  vmovaps [rsp+0x50], xmm5
0000777bb65d9953  vmovaps [rsp+0x60], xmm6
0000777bb65d9959  vmovaps [rsp+0x70], xmm7
0000777bb65d995f  vmovaps [rsp+0x80], xmm8
0000777bb65d9968  vmovaps [rsp+0x90], xmm9
0000777bb65d9971  vmovaps [rsp+0xA0], xmm10
0000777bb65d997a  vmovaps [rsp+0xB0], xmm11
0000777bb65d9983  vmovaps [rsp+0xC0], xmm12
0000777bb65d998c  vmovaps [rsp+0xD0], xmm13
0000777bb65d9995  vmovaps [rsp+0xE0], xmm14
0000777bb65d999e  sub rsp, 0x30
0000777bb65d99a2  movaps [rsp], xmm15
0000777bb65d99a7  movaps [rsp+0x10], xmm1
0000777bb65d99ac  movaps [rsp+0x20], xmm5
0000777bb65d99b1  lea rdi, [rsp]
0000777bb65d99b5  mov esi, 0x00
0000777bb65d99ba  mov rax, 0x569DC437B530
0000777bb65d99c4  call rax
0000777bb65d99c6  movaps xmm15, [rsp]
0000777bb65d99cb  add rsp, 0x30
0000777bb65d99cf  vmovaps xmm0, [rsp]
0000777bb65d99d4  vmovaps xmm1, [rsp+0x10]
0000777bb65d99da  vmovaps xmm2, [rsp+0x20]
0000777bb65d99e0  vmovaps xmm3, [rsp+0x30]
0000777bb65d99e6  vmovaps xmm4, [rsp+0x40]
0000777bb65d99ec  vmovaps xmm5, [rsp+0x50]
0000777bb65d99f2  vmovaps xmm6, [rsp+0x60]
0000777bb65d99f8  vmovaps xmm7, [rsp+0x70]
0000777bb65d99fe  vmovaps xmm8, [rsp+0x80]
0000777bb65d9a07  vmovaps xmm9, [rsp+0x90]
0000777bb65d9a10  vmovaps xmm10, [rsp+0xA0]
0000777bb65d9a19  vmovaps xmm11, [rsp+0xB0]
0000777bb65d9a22  vmovaps xmm12, [rsp+0xC0]
0000777bb65d9a2b  vmovaps xmm13, [rsp+0xD0]
0000777bb65d9a34  vmovaps xmm14, [rsp+0xE0]
0000777bb65d9a3d  add rsp, 0xF0
0000777bb65d9a44  pop r11
0000777bb65d9a46  pop r10
0000777bb65d9a48  pop r9
0000777bb65d9a4a  pop r8
0000777bb65d9a4c  pop rsi
0000777bb65d9a4d  pop rdi
0000777bb65d9a4e  pop rdx
0000777bb65d9a4f  pop rcx
0000777bb65d9a50  pop rax
0000777bb65d9a51  add rsp, 0x08
0000777bb65d9a55  jmp 0x0000777BB65D62C0
0000777bb65d9a5a  call 0x0000777BB64D64F0
0000777bb65d9a5f  jmp 0x0000777BB65D631B
0000777bb65d9a64  sub rsp, 0x08
0000777bb65d9a68  push rax
0000777bb65d9a69  push rcx
0000777bb65d9a6a  push rdx
0000777bb65d9a6b  push rdi
0000777bb65d9a6c  push rsi
0000777bb65d9a6d  push r8
0000777bb65d9a6f  push r9
0000777bb65d9a71  push r10
0000777bb65d9a73  push r11
0000777bb65d9a75  sub rsp, 0xF0
0000777bb65d9a7c  vmovaps [rsp], xmm0
0000777bb65d9a81  vmovaps [rsp+0x10], xmm1
0000777bb65d9a87  vmovaps [rsp+0x20], xmm2
0000777bb65d9a8d  vmovaps [rsp+0x30], xmm3
0000777bb65d9a93  vmovaps [rsp+0x40], xmm4
0000777bb65d9a99  vmovaps [rsp+0x50], xmm5
0000777bb65d9a9f  vmovaps [rsp+0x60], xmm6
0000777bb65d9aa5  vmovaps [rsp+0x70], xmm7
0000777bb65d9aab  vmovaps [rsp+0x80], xmm8
0000777bb65d9ab4  vmovaps [rsp+0x90], xmm10
0000777bb65d9abd  vmovaps [rsp+0xA0], xmm11
0000777bb65d9ac6  vmovaps [rsp+0xB0], xmm12
0000777bb65d9acf  vmovaps [rsp+0xC0], xmm13
0000777bb65d9ad8  vmovaps [rsp+0xD0], xmm14
0000777bb65d9ae1  vmovaps [rsp+0xE0], xmm15
0000777bb65d9aea  sub rsp, 0x30
0000777bb65d9aee  movaps [rsp], xmm9
0000777bb65d9af3  movaps [rsp+0x10], xmm8
0000777bb65d9af9  movaps [rsp+0x20], xmm11
0000777bb65d9aff  lea rdi, [rsp]
0000777bb65d9b03  mov esi, 0x00
0000777bb65d9b08  mov rax, 0x569DC437B530
0000777bb65d9b12  call rax
0000777bb65d9b14  movaps xmm9, [rsp]
0000777bb65d9b19  add rsp, 0x30
0000777bb65d9b1d  vmovaps xmm0, [rsp]
0000777bb65d9b22  vmovaps xmm1, [rsp+0x10]
0000777bb65d9b28  vmovaps xmm2, [rsp+0x20]
0000777bb65d9b2e  vmovaps xmm3, [rsp+0x30]
0000777bb65d9b34  vmovaps xmm4, [rsp+0x40]
0000777bb65d9b3a  vmovaps xmm5, [rsp+0x50]
0000777bb65d9b40  vmovaps xmm6, [rsp+0x60]
0000777bb65d9b46  vmovaps xmm7, [rsp+0x70]
0000777bb65d9b4c  vmovaps xmm8, [rsp+0x80]
0000777bb65d9b55  vmovaps xmm10, [rsp+0x90]
0000777bb65d9b5e  vmovaps xmm11, [rsp+0xA0]
0000777bb65d9b67  vmovaps xmm12, [rsp+0xB0]
0000777bb65d9b70  vmovaps xmm13, [rsp+0xC0]
0000777bb65d9b79  vmovaps xmm14, [rsp+0xD0]
0000777bb65d9b82  vmovaps xmm15, [rsp+0xE0]
0000777bb65d9b8b  add rsp, 0xF0
0000777bb65d9b92  pop r11
0000777bb65d9b94  pop r10
0000777bb65d9b96  pop r9
0000777bb65d9b98  pop r8
0000777bb65d9b9a  pop rsi
0000777bb65d9b9b  pop rdi
0000777bb65d9b9c  pop rdx
0000777bb65d9b9d  pop rcx
0000777bb65d9b9e  pop rax
0000777bb65d9b9f  add rsp, 0x08
0000777bb65d9ba3  jmp 0x0000777BB65D6352
0000777bb65d9ba8  sub rsp, 0x08
0000777bb65d9bac  push rax
0000777bb65d9bad  push rcx
0000777bb65d9bae  push rdx
0000777bb65d9baf  push rdi
0000777bb65d9bb0  push rsi
0000777bb65d9bb1  push r8
0000777bb65d9bb3  push r9
0000777bb65d9bb5  push r10
0000777bb65d9bb7  push r11
0000777bb65d9bb9  sub rsp, 0xF0
0000777bb65d9bc0  vmovaps [rsp], xmm0
0000777bb65d9bc5  vmovaps [rsp+0x10], xmm1
0000777bb65d9bcb  vmovaps [rsp+0x20], xmm2
0000777bb65d9bd1  vmovaps [rsp+0x30], xmm3
0000777bb65d9bd7  vmovaps [rsp+0x40], xmm4
0000777bb65d9bdd  vmovaps [rsp+0x50], xmm5
0000777bb65d9be3  vmovaps [rsp+0x60], xmm6
0000777bb65d9be9  vmovaps [rsp+0x70], xmm7
0000777bb65d9bef  vmovaps [rsp+0x80], xmm8
0000777bb65d9bf8  vmovaps [rsp+0x90], xmm9
0000777bb65d9c01  vmovaps [rsp+0xA0], xmm10
0000777bb65d9c0a  vmovaps [rsp+0xB0], xmm12
0000777bb65d9c13  vmovaps [rsp+0xC0], xmm13
0000777bb65d9c1c  vmovaps [rsp+0xD0], xmm14
0000777bb65d9c25  vmovaps [rsp+0xE0], xmm15
0000777bb65d9c2e  sub rsp, 0x30
0000777bb65d9c32  movaps [rsp], xmm11
0000777bb65d9c37  movaps [rsp+0x10], xmm10
0000777bb65d9c3d  movaps [rsp+0x20], xmm6
0000777bb65d9c42  lea rdi, [rsp]
0000777bb65d9c46  mov esi, 0x00
0000777bb65d9c4b  mov rax, 0x569DC437B530
0000777bb65d9c55  call rax
0000777bb65d9c57  movaps xmm11, [rsp]
0000777bb65d9c5c  add rsp, 0x30
0000777bb65d9c60  vmovaps xmm0, [rsp]
0000777bb65d9c65  vmovaps xmm1, [rsp+0x10]
0000777bb65d9c6b  vmovaps xmm2, [rsp+0x20]
0000777bb65d9c71  vmovaps xmm3, [rsp+0x30]
0000777bb65d9c77  vmovaps xmm4, [rsp+0x40]
0000777bb65d9c7d  vmovaps xmm5, [rsp+0x50]
0000777bb65d9c83  vmovaps xmm6, [rsp+0x60]
0000777bb65d9c89  vmovaps xmm7, [rsp+0x70]
0000777bb65d9c8f  vmovaps xmm8, [rsp+0x80]
0000777bb65d9c98  vmovaps xmm9, [rsp+0x90]
0000777bb65d9ca1  vmovaps xmm10, [rsp+0xA0]
0000777bb65d9caa  vmovaps xmm12, [rsp+0xB0]
0000777bb65d9cb3  vmovaps xmm13, [rsp+0xC0]
0000777bb65d9cbc  vmovaps xmm14, [rsp+0xD0]
0000777bb65d9cc5  vmovaps xmm15, [rsp+0xE0]
0000777bb65d9cce  add rsp, 0xF0
0000777bb65d9cd5  pop r11
0000777bb65d9cd7  pop r10
0000777bb65d9cd9  pop r9
0000777bb65d9cdb  pop r8
0000777bb65d9cdd  pop rsi
0000777bb65d9cde  pop rdi
0000777bb65d9cdf  pop rdx
0000777bb65d9ce0  pop rcx
0000777bb65d9ce1  pop rax
0000777bb65d9ce2  add rsp, 0x08
0000777bb65d9ce6  jmp 0x0000777BB65D636D
0000777bb65d9ceb  sub rsp, 0x08
0000777bb65d9cef  push rax
0000777bb65d9cf0  push rcx
0000777bb65d9cf1  push rdx
0000777bb65d9cf2  push rdi
0000777bb65d9cf3  push rsi
0000777bb65d9cf4  push r8
0000777bb65d9cf6  push r9
0000777bb65d9cf8  push r10
0000777bb65d9cfa  push r11
0000777bb65d9cfc  sub rsp, 0xF0
0000777bb65d9d03  vmovaps [rsp], xmm0
0000777bb65d9d08  vmovaps [rsp+0x10], xmm1
0000777bb65d9d0e  vmovaps [rsp+0x20], xmm2
0000777bb65d9d14  vmovaps [rsp+0x30], xmm3
0000777bb65d9d1a  vmovaps [rsp+0x40], xmm4
0000777bb65d9d20  vmovaps [rsp+0x50], xmm5
0000777bb65d9d26  vmovaps [rsp+0x60], xmm6
0000777bb65d9d2c  vmovaps [rsp+0x70], xmm7
0000777bb65d9d32  vmovaps [rsp+0x80], xmm8
0000777bb65d9d3b  vmovaps [rsp+0x90], xmm9
0000777bb65d9d44  vmovaps [rsp+0xA0], xmm11
0000777bb65d9d4d  vmovaps [rsp+0xB0], xmm12
0000777bb65d9d56  vmovaps [rsp+0xC0], xmm13
0000777bb65d9d5f  vmovaps [rsp+0xD0], xmm14
0000777bb65d9d68  vmovaps [rsp+0xE0], xmm15
0000777bb65d9d71  sub rsp, 0x30
0000777bb65d9d75  movaps [rsp], xmm10
0000777bb65d9d7a  movaps [rsp+0x10], xmm14
0000777bb65d9d80  movaps [rsp+0x20], xmm4
0000777bb65d9d85  lea rdi, [rsp]
0000777bb65d9d89  mov esi, 0x00
0000777bb65d9d8e  mov rax, 0x569DC437B530
0000777bb65d9d98  call rax
0000777bb65d9d9a  movaps xmm10, [rsp]
0000777bb65d9d9f  add rsp, 0x30
0000777bb65d9da3  vmovaps xmm0, [rsp]
0000777bb65d9da8  vmovaps xmm1, [rsp+0x10]
0000777bb65d9dae  vmovaps xmm2, [rsp+0x20]
0000777bb65d9db4  vmovaps xmm3, [rsp+0x30]
0000777bb65d9dba  vmovaps xmm4, [rsp+0x40]
0000777bb65d9dc0  vmovaps xmm5, [rsp+0x50]
0000777bb65d9dc6  vmovaps xmm6, [rsp+0x60]
0000777bb65d9dcc  vmovaps xmm7, [rsp+0x70]
0000777bb65d9dd2  vmovaps xmm8, [rsp+0x80]
0000777bb65d9ddb  vmovaps xmm9, [rsp+0x90]
0000777bb65d9de4  vmovaps xmm11, [rsp+0xA0]
0000777bb65d9ded  vmovaps xmm12, [rsp+0xB0]
0000777bb65d9df6  vmovaps xmm13, [rsp+0xC0]
0000777bb65d9dff  vmovaps xmm14, [rsp+0xD0]
0000777bb65d9e08  vmovaps xmm15, [rsp+0xE0]
0000777bb65d9e11  add rsp, 0xF0
0000777bb65d9e18  pop r11
0000777bb65d9e1a  pop r10
0000777bb65d9e1c  pop r9
0000777bb65d9e1e  pop r8
0000777bb65d9e20  pop rsi
0000777bb65d9e21  pop rdi
0000777bb65d9e22  pop rdx
0000777bb65d9e23  pop rcx
0000777bb65d9e24  pop rax
0000777bb65d9e25  add rsp, 0x08
0000777bb65d9e29  jmp 0x0000777BB65D6388
0000777bb65d9e2e  sub rsp, 0x08
0000777bb65d9e32  push rax
0000777bb65d9e33  push rcx
0000777bb65d9e34  push rdx
0000777bb65d9e35  push rdi
0000777bb65d9e36  push rsi
0000777bb65d9e37  push r8
0000777bb65d9e39  push r9
0000777bb65d9e3b  push r10
0000777bb65d9e3d  push r11
0000777bb65d9e3f  sub rsp, 0xF0
0000777bb65d9e46  vmovaps [rsp], xmm0
0000777bb65d9e4b  vmovaps [rsp+0x10], xmm1
0000777bb65d9e51  vmovaps [rsp+0x20], xmm2
0000777bb65d9e57  vmovaps [rsp+0x30], xmm3
0000777bb65d9e5d  vmovaps [rsp+0x40], xmm4
0000777bb65d9e63  vmovaps [rsp+0x50], xmm5
0000777bb65d9e69  vmovaps [rsp+0x60], xmm6
0000777bb65d9e6f  vmovaps [rsp+0x70], xmm7
0000777bb65d9e75  vmovaps [rsp+0x80], xmm9
0000777bb65d9e7e  vmovaps [rsp+0x90], xmm10
0000777bb65d9e87  vmovaps [rsp+0xA0], xmm11
0000777bb65d9e90  vmovaps [rsp+0xB0], xmm12
0000777bb65d9e99  vmovaps [rsp+0xC0], xmm13
0000777bb65d9ea2  vmovaps [rsp+0xD0], xmm14
0000777bb65d9eab  vmovaps [rsp+0xE0], xmm15
0000777bb65d9eb4  sub rsp, 0x30
0000777bb65d9eb8  movaps [rsp], xmm8
0000777bb65d9ebd  movaps [rsp+0x10], xmm1
0000777bb65d9ec2  movaps [rsp+0x20], xmm14
0000777bb65d9ec8  lea rdi, [rsp]
0000777bb65d9ecc  mov esi, 0x00
0000777bb65d9ed1  mov rax, 0x569DC437B530
0000777bb65d9edb  call rax
0000777bb65d9edd  movaps xmm8, [rsp]
0000777bb65d9ee2  add rsp, 0x30
0000777bb65d9ee6  vmovaps xmm0, [rsp]
0000777bb65d9eeb  vmovaps xmm1, [rsp+0x10]
0000777bb65d9ef1  vmovaps xmm2, [rsp+0x20]
0000777bb65d9ef7  vmovaps xmm3, [rsp+0x30]
0000777bb65d9efd  vmovaps xmm4, [rsp+0x40]
0000777bb65d9f03  vmovaps xmm5, [rsp+0x50]
0000777bb65d9f09  vmovaps xmm6, [rsp+0x60]
0000777bb65d9f0f  vmovaps xmm7, [rsp+0x70]
0000777bb65d9f15  vmovaps xmm9, [rsp+0x80]
0000777bb65d9f1e  vmovaps xmm10, [rsp+0x90]
0000777bb65d9f27  vmovaps xmm11, [rsp+0xA0]
0000777bb65d9f30  vmovaps xmm12, [rsp+0xB0]
0000777bb65d9f39  vmovaps xmm13, [rsp+0xC0]
0000777bb65d9f42  vmovaps xmm14, [rsp+0xD0]
0000777bb65d9f4b  vmovaps xmm15, [rsp+0xE0]
0000777bb65d9f54  add rsp, 0xF0
0000777bb65d9f5b  pop r11
0000777bb65d9f5d  pop r10
0000777bb65d9f5f  pop r9
0000777bb65d9f61  pop r8
0000777bb65d9f63  pop rsi
0000777bb65d9f64  pop rdi
0000777bb65d9f65  pop rdx
0000777bb65d9f66  pop rcx
0000777bb65d9f67  pop rax
0000777bb65d9f68  add rsp, 0x08
0000777bb65d9f6c  jmp 0x0000777BB65D63AE
0000777bb65d9f71  sub rsp, 0x08
0000777bb65d9f75  push rax
0000777bb65d9f76  push rcx
0000777bb65d9f77  push rdx
0000777bb65d9f78  push rdi
0000777bb65d9f79  push rsi
0000777bb65d9f7a  push r8
0000777bb65d9f7c  push r9
0000777bb65d9f7e  push r10
0000777bb65d9f80  push r11
0000777bb65d9f82  sub rsp, 0xF0
0000777bb65d9f89  vmovaps [rsp], xmm0
0000777bb65d9f8e  vmovaps [rsp+0x10], xmm1
0000777bb65d9f94  vmovaps [rsp+0x20], xmm2
0000777bb65d9f9a  vmovaps [rsp+0x30], xmm3
0000777bb65d9fa0  vmovaps [rsp+0x40], xmm4
0000777bb65d9fa6  vmovaps [rsp+0x50], xmm5
0000777bb65d9fac  vmovaps [rsp+0x60], xmm7
0000777bb65d9fb2  vmovaps [rsp+0x70], xmm8
0000777bb65d9fb8  vmovaps [rsp+0x80], xmm9
0000777bb65d9fc1  vmovaps [rsp+0x90], xmm10
0000777bb65d9fca  vmovaps [rsp+0xA0], xmm11
0000777bb65d9fd3  vmovaps [rsp+0xB0], xmm12
0000777bb65d9fdc  vmovaps [rsp+0xC0], xmm13
0000777bb65d9fe5  vmovaps [rsp+0xD0], xmm14
0000777bb65d9fee  vmovaps [rsp+0xE0], xmm15
0000777bb65d9ff7  sub rsp, 0x30
0000777bb65d9ffb  movaps [rsp], xmm6
0000777bb65d9fff  movaps [rsp+0x10], xmm1
0000777bb65da004  movaps [rsp+0x20], xmm14
0000777bb65da00a  lea rdi, [rsp]
0000777bb65da00e  mov esi, 0x00
0000777bb65da013  mov rax, 0x569DC437B530
0000777bb65da01d  call rax
0000777bb65da01f  movaps xmm6, [rsp]
0000777bb65da023  add rsp, 0x30
0000777bb65da027  vmovaps xmm0, [rsp]
0000777bb65da02c  vmovaps xmm1, [rsp+0x10]
0000777bb65da032  vmovaps xmm2, [rsp+0x20]
0000777bb65da038  vmovaps xmm3, [rsp+0x30]
0000777bb65da03e  vmovaps xmm4, [rsp+0x40]
0000777bb65da044  vmovaps xmm5, [rsp+0x50]
0000777bb65da04a  vmovaps xmm7, [rsp+0x60]
0000777bb65da050  vmovaps xmm8, [rsp+0x70]
0000777bb65da056  vmovaps xmm9, [rsp+0x80]
0000777bb65da05f  vmovaps xmm10, [rsp+0x90]
0000777bb65da068  vmovaps xmm11, [rsp+0xA0]
0000777bb65da071  vmovaps xmm12, [rsp+0xB0]
0000777bb65da07a  vmovaps xmm13, [rsp+0xC0]
0000777bb65da083  vmovaps xmm14, [rsp+0xD0]
0000777bb65da08c  vmovaps xmm15, [rsp+0xE0]
0000777bb65da095  add rsp, 0xF0
0000777bb65da09c  pop r11
0000777bb65da09e  pop r10
0000777bb65da0a0  pop r9
0000777bb65da0a2  pop r8
0000777bb65da0a4  pop rsi
0000777bb65da0a5  pop rdi
0000777bb65da0a6  pop rdx
0000777bb65da0a7  pop rcx
0000777bb65da0a8  pop rax
0000777bb65da0a9  add rsp, 0x08
0000777bb65da0ad  jmp 0x0000777BB65D63DA
0000777bb65da0b2  sub rsp, 0x08
0000777bb65da0b6  push rax
0000777bb65da0b7  push rcx
0000777bb65da0b8  push rdx
0000777bb65da0b9  push rdi
0000777bb65da0ba  push rsi
0000777bb65da0bb  push r8
0000777bb65da0bd  push r9
0000777bb65da0bf  push r10
0000777bb65da0c1  push r11
0000777bb65da0c3  sub rsp, 0xF0
0000777bb65da0ca  vmovaps [rsp], xmm0
0000777bb65da0cf  vmovaps [rsp+0x10], xmm1
0000777bb65da0d5  vmovaps [rsp+0x20], xmm2
0000777bb65da0db  vmovaps [rsp+0x30], xmm3
0000777bb65da0e1  vmovaps [rsp+0x40], xmm4
0000777bb65da0e7  vmovaps [rsp+0x50], xmm5
0000777bb65da0ed  vmovaps [rsp+0x60], xmm6
0000777bb65da0f3  vmovaps [rsp+0x70], xmm7
0000777bb65da0f9  vmovaps [rsp+0x80], xmm8
0000777bb65da102  vmovaps [rsp+0x90], xmm9
0000777bb65da10b  vmovaps [rsp+0xA0], xmm10
0000777bb65da114  vmovaps [rsp+0xB0], xmm11
0000777bb65da11d  vmovaps [rsp+0xC0], xmm12
0000777bb65da126  vmovaps [rsp+0xD0], xmm13
0000777bb65da12f  vmovaps [rsp+0xE0], xmm15
0000777bb65da138  sub rsp, 0x30
0000777bb65da13c  movaps [rsp], xmm14
0000777bb65da141  movaps [rsp+0x10], xmm12
0000777bb65da147  movaps [rsp+0x20], xmm1
0000777bb65da14c  lea rdi, [rsp]
0000777bb65da150  mov esi, 0x00
0000777bb65da155  mov rax, 0x569DC437B530
0000777bb65da15f  call rax
0000777bb65da161  movaps xmm14, [rsp]
0000777bb65da166  add rsp, 0x30
0000777bb65da16a  vmovaps xmm0, [rsp]
0000777bb65da16f  vmovaps xmm1, [rsp+0x10]
0000777bb65da175  vmovaps xmm2, [rsp+0x20]
0000777bb65da17b  vmovaps xmm3, [rsp+0x30]
0000777bb65da181  vmovaps xmm4, [rsp+0x40]
0000777bb65da187  vmovaps xmm5, [rsp+0x50]
0000777bb65da18d  vmovaps xmm6, [rsp+0x60]
0000777bb65da193  vmovaps xmm7, [rsp+0x70]
0000777bb65da199  vmovaps xmm8, [rsp+0x80]
0000777bb65da1a2  vmovaps xmm9, [rsp+0x90]
0000777bb65da1ab  vmovaps xmm10, [rsp+0xA0]
0000777bb65da1b4  vmovaps xmm11, [rsp+0xB0]
0000777bb65da1bd  vmovaps xmm12, [rsp+0xC0]
0000777bb65da1c6  vmovaps xmm13, [rsp+0xD0]
0000777bb65da1cf  vmovaps xmm15, [rsp+0xE0]
0000777bb65da1d8  add rsp, 0xF0
0000777bb65da1df  pop r11
0000777bb65da1e1  pop r10
0000777bb65da1e3  pop r9
0000777bb65da1e5  pop r8
0000777bb65da1e7  pop rsi
0000777bb65da1e8  pop rdi
0000777bb65da1e9  pop rdx
0000777bb65da1ea  pop rcx
0000777bb65da1eb  pop rax
0000777bb65da1ec  add rsp, 0x08
0000777bb65da1f0  jmp 0x0000777BB65D6400
0000777bb65da1f5  sub rsp, 0x08
0000777bb65da1f9  push rax
0000777bb65da1fa  push rcx
0000777bb65da1fb  push rdx
0000777bb65da1fc  push rdi
0000777bb65da1fd  push rsi
0000777bb65da1fe  push r8
0000777bb65da200  push r9
0000777bb65da202  push r10
0000777bb65da204  push r11
0000777bb65da206  sub rsp, 0xF0
0000777bb65da20d  vmovaps [rsp], xmm0
0000777bb65da212  vmovaps [rsp+0x10], xmm2
0000777bb65da218  vmovaps [rsp+0x20], xmm3
0000777bb65da21e  vmovaps [rsp+0x30], xmm4
0000777bb65da224  vmovaps [rsp+0x40], xmm5
0000777bb65da22a  vmovaps [rsp+0x50], xmm6
0000777bb65da230  vmovaps [rsp+0x60], xmm7
0000777bb65da236  vmovaps [rsp+0x70], xmm8
0000777bb65da23c  vmovaps [rsp+0x80], xmm9
0000777bb65da245  vmovaps [rsp+0x90], xmm10
0000777bb65da24e  vmovaps [rsp+0xA0], xmm11
0000777bb65da257  vmovaps [rsp+0xB0], xmm12
0000777bb65da260  vmovaps [rsp+0xC0], xmm13
0000777bb65da269  vmovaps [rsp+0xD0], xmm14
0000777bb65da272  vmovaps [rsp+0xE0], xmm15
0000777bb65da27b  sub rsp, 0x30
0000777bb65da27f  movaps [rsp], xmm1
0000777bb65da283  movaps [rsp+0x10], xmm13
0000777bb65da289  movaps [rsp+0x20], xmm9
0000777bb65da28f  lea rdi, [rsp]
0000777bb65da293  mov esi, 0x00
0000777bb65da298  mov rax, 0x569DC437B530
0000777bb65da2a2  call rax
0000777bb65da2a4  movaps xmm1, [rsp]
0000777bb65da2a8  add rsp, 0x30
0000777bb65da2ac  vmovaps xmm0, [rsp]
0000777bb65da2b1  vmovaps xmm2, [rsp+0x10]
0000777bb65da2b7  vmovaps xmm3, [rsp+0x20]
0000777bb65da2bd  vmovaps xmm4, [rsp+0x30]
0000777bb65da2c3  vmovaps xmm5, [rsp+0x40]
0000777bb65da2c9  vmovaps xmm6, [rsp+0x50]
0000777bb65da2cf  vmovaps xmm7, [rsp+0x60]
0000777bb65da2d5  vmovaps xmm8, [rsp+0x70]
0000777bb65da2db  vmovaps xmm9, [rsp+0x80]
0000777bb65da2e4  vmovaps xmm10, [rsp+0x90]
0000777bb65da2ed  vmovaps xmm11, [rsp+0xA0]
0000777bb65da2f6  vmovaps xmm12, [rsp+0xB0]
0000777bb65da2ff  vmovaps xmm13, [rsp+0xC0]
0000777bb65da308  vmovaps xmm14, [rsp+0xD0]
0000777bb65da311  vmovaps xmm15, [rsp+0xE0]
0000777bb65da31a  add rsp, 0xF0
0000777bb65da321  pop r11
0000777bb65da323  pop r10
0000777bb65da325  pop r9
0000777bb65da327  pop r8
0000777bb65da329  pop rsi
0000777bb65da32a  pop rdi
0000777bb65da32b  pop rdx
0000777bb65da32c  pop rcx
0000777bb65da32d  pop rax
0000777bb65da32e  add rsp, 0x08
0000777bb65da332  jmp 0x0000777BB65D641A
0000777bb65da337  sub rsp, 0x08
0000777bb65da33b  push rax
0000777bb65da33c  push rcx
0000777bb65da33d  push rdx
0000777bb65da33e  push rdi
0000777bb65da33f  push rsi
0000777bb65da340  push r8
0000777bb65da342  push r9
0000777bb65da344  push r10
0000777bb65da346  push r11
0000777bb65da348  sub rsp, 0xF0
0000777bb65da34f  vmovaps [rsp], xmm0
0000777bb65da354  vmovaps [rsp+0x10], xmm1
0000777bb65da35a  vmovaps [rsp+0x20], xmm2
0000777bb65da360  vmovaps [rsp+0x30], xmm3
0000777bb65da366  vmovaps [rsp+0x40], xmm4
0000777bb65da36c  vmovaps [rsp+0x50], xmm5
0000777bb65da372  vmovaps [rsp+0x60], xmm6
0000777bb65da378  vmovaps [rsp+0x70], xmm7
0000777bb65da37e  vmovaps [rsp+0x80], xmm8
0000777bb65da387  vmovaps [rsp+0x90], xmm9
0000777bb65da390  vmovaps [rsp+0xA0], xmm10
0000777bb65da399  vmovaps [rsp+0xB0], xmm11
0000777bb65da3a2  vmovaps [rsp+0xC0], xmm13
0000777bb65da3ab  vmovaps [rsp+0xD0], xmm14
0000777bb65da3b4  vmovaps [rsp+0xE0], xmm15
0000777bb65da3bd  sub rsp, 0x30
0000777bb65da3c1  movaps [rsp], xmm12
0000777bb65da3c6  movaps [rsp+0x10], xmm7
0000777bb65da3cb  movaps [rsp+0x20], xmm13
0000777bb65da3d1  lea rdi, [rsp]
0000777bb65da3d5  mov esi, 0x00
0000777bb65da3da  mov rax, 0x569DC437B530
0000777bb65da3e4  call rax
0000777bb65da3e6  movaps xmm12, [rsp]
0000777bb65da3eb  add rsp, 0x30
0000777bb65da3ef  vmovaps xmm0, [rsp]
0000777bb65da3f4  vmovaps xmm1, [rsp+0x10]
0000777bb65da3fa  vmovaps xmm2, [rsp+0x20]
0000777bb65da400  vmovaps xmm3, [rsp+0x30]
0000777bb65da406  vmovaps xmm4, [rsp+0x40]
0000777bb65da40c  vmovaps xmm5, [rsp+0x50]
0000777bb65da412  vmovaps xmm6, [rsp+0x60]
0000777bb65da418  vmovaps xmm7, [rsp+0x70]
0000777bb65da41e  vmovaps xmm8, [rsp+0x80]
0000777bb65da427  vmovaps xmm9, [rsp+0x90]
0000777bb65da430  vmovaps xmm10, [rsp+0xA0]
0000777bb65da439  vmovaps xmm11, [rsp+0xB0]
0000777bb65da442  vmovaps xmm13, [rsp+0xC0]
0000777bb65da44b  vmovaps xmm14, [rsp+0xD0]
0000777bb65da454  vmovaps xmm15, [rsp+0xE0]
0000777bb65da45d  add rsp, 0xF0
0000777bb65da464  pop r11
0000777bb65da466  pop r10
0000777bb65da468  pop r9
0000777bb65da46a  pop r8
0000777bb65da46c  pop rsi
0000777bb65da46d  pop rdi
0000777bb65da46e  pop rdx
0000777bb65da46f  pop rcx
0000777bb65da470  pop rax
0000777bb65da471  add rsp, 0x08
0000777bb65da475  jmp 0x0000777BB65D6441
0000777bb65da47a  sub rsp, 0x08
0000777bb65da47e  push rax
0000777bb65da47f  push rcx
0000777bb65da480  push rdx
0000777bb65da481  push rdi
0000777bb65da482  push rsi
0000777bb65da483  push r8
0000777bb65da485  push r9
0000777bb65da487  push r10
0000777bb65da489  push r11
0000777bb65da48b  sub rsp, 0xF0
0000777bb65da492  vmovaps [rsp], xmm0
0000777bb65da497  vmovaps [rsp+0x10], xmm1
0000777bb65da49d  vmovaps [rsp+0x20], xmm2
0000777bb65da4a3  vmovaps [rsp+0x30], xmm3
0000777bb65da4a9  vmovaps [rsp+0x40], xmm4
0000777bb65da4af  vmovaps [rsp+0x50], xmm5
0000777bb65da4b5  vmovaps [rsp+0x60], xmm6
0000777bb65da4bb  vmovaps [rsp+0x70], xmm7
0000777bb65da4c1  vmovaps [rsp+0x80], xmm8
0000777bb65da4ca  vmovaps [rsp+0x90], xmm9
0000777bb65da4d3  vmovaps [rsp+0xA0], xmm10
0000777bb65da4dc  vmovaps [rsp+0xB0], xmm11
0000777bb65da4e5  vmovaps [rsp+0xC0], xmm12
0000777bb65da4ee  vmovaps [rsp+0xD0], xmm14
0000777bb65da4f7  vmovaps [rsp+0xE0], xmm15
0000777bb65da500  sub rsp, 0x30
0000777bb65da504  movaps [rsp], xmm13
0000777bb65da509  movaps [rsp+0x10], xmm15
0000777bb65da50f  movaps [rsp+0x20], xmm8
0000777bb65da515  lea rdi, [rsp]
0000777bb65da519  mov esi, 0x00
0000777bb65da51e  mov rax, 0x569DC437B530
0000777bb65da528  call rax
0000777bb65da52a  movaps xmm13, [rsp]
0000777bb65da52f  add rsp, 0x30
0000777bb65da533  vmovaps xmm0, [rsp]
0000777bb65da538  vmovaps xmm1, [rsp+0x10]
0000777bb65da53e  vmovaps xmm2, [rsp+0x20]
0000777bb65da544  vmovaps xmm3, [rsp+0x30]
0000777bb65da54a  vmovaps xmm4, [rsp+0x40]
0000777bb65da550  vmovaps xmm5, [rsp+0x50]
0000777bb65da556  vmovaps xmm6, [rsp+0x60]
0000777bb65da55c  vmovaps xmm7, [rsp+0x70]
0000777bb65da562  vmovaps xmm8, [rsp+0x80]
0000777bb65da56b  vmovaps xmm9, [rsp+0x90]
0000777bb65da574  vmovaps xmm10, [rsp+0xA0]
0000777bb65da57d  vmovaps xmm11, [rsp+0xB0]
0000777bb65da586  vmovaps xmm12, [rsp+0xC0]
0000777bb65da58f  vmovaps xmm14, [rsp+0xD0]
0000777bb65da598  vmovaps xmm15, [rsp+0xE0]
0000777bb65da5a1  add rsp, 0xF0
0000777bb65da5a8  pop r11
0000777bb65da5aa  pop r10
0000777bb65da5ac  pop r9
0000777bb65da5ae  pop r8
0000777bb65da5b0  pop rsi
0000777bb65da5b1  pop rdi
0000777bb65da5b2  pop rdx
0000777bb65da5b3  pop rcx
0000777bb65da5b4  pop rax
0000777bb65da5b5  add rsp, 0x08
0000777bb65da5b9  jmp 0x0000777BB65D645C
0000777bb65da5be  sub rsp, 0x08
0000777bb65da5c2  push rax
0000777bb65da5c3  push rcx
0000777bb65da5c4  push rdx
0000777bb65da5c5  push rdi
0000777bb65da5c6  push rsi
0000777bb65da5c7  push r8
0000777bb65da5c9  push r9
0000777bb65da5cb  push r10
0000777bb65da5cd  push r11
0000777bb65da5cf  sub rsp, 0xF0
0000777bb65da5d6  vmovaps [rsp], xmm0
0000777bb65da5db  vmovaps [rsp+0x10], xmm1
0000777bb65da5e1  vmovaps [rsp+0x20], xmm2
0000777bb65da5e7  vmovaps [rsp+0x30], xmm3
0000777bb65da5ed  vmovaps [rsp+0x40], xmm4
0000777bb65da5f3  vmovaps [rsp+0x50], xmm5
0000777bb65da5f9  vmovaps [rsp+0x60], xmm6
0000777bb65da5ff  vmovaps [rsp+0x70], xmm7
0000777bb65da605  vmovaps [rsp+0x80], xmm9
0000777bb65da60e  vmovaps [rsp+0x90], xmm10
0000777bb65da617  vmovaps [rsp+0xA0], xmm11
0000777bb65da620  vmovaps [rsp+0xB0], xmm12
0000777bb65da629  vmovaps [rsp+0xC0], xmm13
0000777bb65da632  vmovaps [rsp+0xD0], xmm14
0000777bb65da63b  vmovaps [rsp+0xE0], xmm15
0000777bb65da644  sub rsp, 0x30
0000777bb65da648  movaps [rsp], xmm8
0000777bb65da64d  movaps [rsp+0x10], xmm15
0000777bb65da653  movaps [rsp+0x20], xmm9
0000777bb65da659  lea rdi, [rsp]
0000777bb65da65d  mov esi, 0x00
0000777bb65da662  mov rax, 0x569DC437B530
0000777bb65da66c  call rax
0000777bb65da66e  movaps xmm8, [rsp]
0000777bb65da673  add rsp, 0x30
0000777bb65da677  vmovaps xmm0, [rsp]
0000777bb65da67c  vmovaps xmm1, [rsp+0x10]
0000777bb65da682  vmovaps xmm2, [rsp+0x20]
0000777bb65da688  vmovaps xmm3, [rsp+0x30]
0000777bb65da68e  vmovaps xmm4, [rsp+0x40]
0000777bb65da694  vmovaps xmm5, [rsp+0x50]
0000777bb65da69a  vmovaps xmm6, [rsp+0x60]
0000777bb65da6a0  vmovaps xmm7, [rsp+0x70]
0000777bb65da6a6  vmovaps xmm9, [rsp+0x80]
0000777bb65da6af  vmovaps xmm10, [rsp+0x90]
0000777bb65da6b8  vmovaps xmm11, [rsp+0xA0]
0000777bb65da6c1  vmovaps xmm12, [rsp+0xB0]
0000777bb65da6ca  vmovaps xmm13, [rsp+0xC0]
0000777bb65da6d3  vmovaps xmm14, [rsp+0xD0]
0000777bb65da6dc  vmovaps xmm15, [rsp+0xE0]
0000777bb65da6e5  add rsp, 0xF0
0000777bb65da6ec  pop r11
0000777bb65da6ee  pop r10
0000777bb65da6f0  pop r9
0000777bb65da6f2  pop r8
0000777bb65da6f4  pop rsi
0000777bb65da6f5  pop rdi
0000777bb65da6f6  pop rdx
0000777bb65da6f7  pop rcx
0000777bb65da6f8  pop rax
0000777bb65da6f9  add rsp, 0x08
0000777bb65da6fd  jmp 0x0000777BB65D648A
0000777bb65da702  sub rsp, 0x08
0000777bb65da706  push rax
0000777bb65da707  push rcx
0000777bb65da708  push rdx
0000777bb65da709  push rdi
0000777bb65da70a  push rsi
0000777bb65da70b  push r8
0000777bb65da70d  push r9
0000777bb65da70f  push r10
0000777bb65da711  push r11
0000777bb65da713  sub rsp, 0xF0
0000777bb65da71a  vmovaps [rsp], xmm0
0000777bb65da71f  vmovaps [rsp+0x10], xmm1
0000777bb65da725  vmovaps [rsp+0x20], xmm2
0000777bb65da72b  vmovaps [rsp+0x30], xmm3
0000777bb65da731  vmovaps [rsp+0x40], xmm4
0000777bb65da737  vmovaps [rsp+0x50], xmm5
0000777bb65da73d  vmovaps [rsp+0x60], xmm6
0000777bb65da743  vmovaps [rsp+0x70], xmm7
0000777bb65da749  vmovaps [rsp+0x80], xmm8
0000777bb65da752  vmovaps [rsp+0x90], xmm9
0000777bb65da75b  vmovaps [rsp+0xA0], xmm10
0000777bb65da764  vmovaps [rsp+0xB0], xmm11
0000777bb65da76d  vmovaps [rsp+0xC0], xmm12
0000777bb65da776  vmovaps [rsp+0xD0], xmm13
0000777bb65da77f  vmovaps [rsp+0xE0], xmm14
0000777bb65da788  sub rsp, 0x30
0000777bb65da78c  movaps [rsp], xmm15
0000777bb65da791  movaps [rsp+0x10], xmm11
0000777bb65da797  movaps [rsp+0x20], xmm6
0000777bb65da79c  lea rdi, [rsp]
0000777bb65da7a0  mov esi, 0x00
0000777bb65da7a5  mov rax, 0x569DC437B530
0000777bb65da7af  call rax
0000777bb65da7b1  movaps xmm15, [rsp]
0000777bb65da7b6  add rsp, 0x30
0000777bb65da7ba  vmovaps xmm0, [rsp]
0000777bb65da7bf  vmovaps xmm1, [rsp+0x10]
0000777bb65da7c5  vmovaps xmm2, [rsp+0x20]
0000777bb65da7cb  vmovaps xmm3, [rsp+0x30]
0000777bb65da7d1  vmovaps xmm4, [rsp+0x40]
0000777bb65da7d7  vmovaps xmm5, [rsp+0x50]
0000777bb65da7dd  vmovaps xmm6, [rsp+0x60]
0000777bb65da7e3  vmovaps xmm7, [rsp+0x70]
0000777bb65da7e9  vmovaps xmm8, [rsp+0x80]
0000777bb65da7f2  vmovaps xmm9, [rsp+0x90]
0000777bb65da7fb  vmovaps xmm10, [rsp+0xA0]
0000777bb65da804  vmovaps xmm11, [rsp+0xB0]
0000777bb65da80d  vmovaps xmm12, [rsp+0xC0]
0000777bb65da816  vmovaps xmm13, [rsp+0xD0]
0000777bb65da81f  vmovaps xmm14, [rsp+0xE0]
0000777bb65da828  add rsp, 0xF0
0000777bb65da82f  pop r11
0000777bb65da831  pop r10
0000777bb65da833  pop r9
0000777bb65da835  pop r8
0000777bb65da837  pop rsi
0000777bb65da838  pop rdi
0000777bb65da839  pop rdx
0000777bb65da83a  pop rcx
0000777bb65da83b  pop rax
0000777bb65da83c  add rsp, 0x08
0000777bb65da840  jmp 0x0000777BB65D64A5
0000777bb65da845  sub rsp, 0x08
0000777bb65da849  push rax
0000777bb65da84a  push rcx
0000777bb65da84b  push rdx
0000777bb65da84c  push rdi
0000777bb65da84d  push rsi
0000777bb65da84e  push r8
0000777bb65da850  push r9
0000777bb65da852  push r10
0000777bb65da854  push r11
0000777bb65da856  sub rsp, 0xF0
0000777bb65da85d  vmovaps [rsp], xmm0
0000777bb65da862  vmovaps [rsp+0x10], xmm1
0000777bb65da868  vmovaps [rsp+0x20], xmm2
0000777bb65da86e  vmovaps [rsp+0x30], xmm3
0000777bb65da874  vmovaps [rsp+0x40], xmm4
0000777bb65da87a  vmovaps [rsp+0x50], xmm5
0000777bb65da880  vmovaps [rsp+0x60], xmm6
0000777bb65da886  vmovaps [rsp+0x70], xmm8
0000777bb65da88c  vmovaps [rsp+0x80], xmm9
0000777bb65da895  vmovaps [rsp+0x90], xmm10
0000777bb65da89e  vmovaps [rsp+0xA0], xmm11
0000777bb65da8a7  vmovaps [rsp+0xB0], xmm12
0000777bb65da8b0  vmovaps [rsp+0xC0], xmm13
0000777bb65da8b9  vmovaps [rsp+0xD0], xmm14
0000777bb65da8c2  vmovaps [rsp+0xE0], xmm15
0000777bb65da8cb  sub rsp, 0x30
0000777bb65da8cf  movaps [rsp], xmm7
0000777bb65da8d3  movaps [rsp+0x10], xmm11
0000777bb65da8d9  movaps [rsp+0x20], xmm9
0000777bb65da8df  lea rdi, [rsp]
0000777bb65da8e3  mov esi, 0x00
0000777bb65da8e8  mov rax, 0x569DC437B530
0000777bb65da8f2  call rax
0000777bb65da8f4  movaps xmm7, [rsp]
0000777bb65da8f8  add rsp, 0x30
0000777bb65da8fc  vmovaps xmm0, [rsp]
0000777bb65da901  vmovaps xmm1, [rsp+0x10]
0000777bb65da907  vmovaps xmm2, [rsp+0x20]
0000777bb65da90d  vmovaps xmm3, [rsp+0x30]
0000777bb65da913  vmovaps xmm4, [rsp+0x40]
0000777bb65da919  vmovaps xmm5, [rsp+0x50]
0000777bb65da91f  vmovaps xmm6, [rsp+0x60]
0000777bb65da925  vmovaps xmm8, [rsp+0x70]
0000777bb65da92b  vmovaps xmm9, [rsp+0x80]
0000777bb65da934  vmovaps xmm10, [rsp+0x90]
0000777bb65da93d  vmovaps xmm11, [rsp+0xA0]
0000777bb65da946  vmovaps xmm12, [rsp+0xB0]
0000777bb65da94f  vmovaps xmm13, [rsp+0xC0]
0000777bb65da958  vmovaps xmm14, [rsp+0xD0]
0000777bb65da961  vmovaps xmm15, [rsp+0xE0]
0000777bb65da96a  add rsp, 0xF0
0000777bb65da971  pop r11
0000777bb65da973  pop r10
0000777bb65da975  pop r9
0000777bb65da977  pop r8
0000777bb65da979  pop rsi
0000777bb65da97a  pop rdi
0000777bb65da97b  pop rdx
0000777bb65da97c  pop rcx
0000777bb65da97d  pop rax
0000777bb65da97e  add rsp, 0x08
0000777bb65da982  jmp 0x0000777BB65D64D2
0000777bb65da987  sub rsp, 0x08
0000777bb65da98b  push rax
0000777bb65da98c  push rcx
0000777bb65da98d  push rdx
0000777bb65da98e  push rdi
0000777bb65da98f  push rsi
0000777bb65da990  push r8
0000777bb65da992  push r9
0000777bb65da994  push r10
0000777bb65da996  push r11
0000777bb65da998  sub rsp, 0xF0
0000777bb65da99f  vmovaps [rsp], xmm0
0000777bb65da9a4  vmovaps [rsp+0x10], xmm1
0000777bb65da9aa  vmovaps [rsp+0x20], xmm2
0000777bb65da9b0  vmovaps [rsp+0x30], xmm3
0000777bb65da9b6  vmovaps [rsp+0x40], xmm4
0000777bb65da9bc  vmovaps [rsp+0x50], xmm5
0000777bb65da9c2  vmovaps [rsp+0x60], xmm6
0000777bb65da9c8  vmovaps [rsp+0x70], xmm7
0000777bb65da9ce  vmovaps [rsp+0x80], xmm8
0000777bb65da9d7  vmovaps [rsp+0x90], xmm9
0000777bb65da9e0  vmovaps [rsp+0xA0], xmm10
0000777bb65da9e9  vmovaps [rsp+0xB0], xmm12
0000777bb65da9f2  vmovaps [rsp+0xC0], xmm13
0000777bb65da9fb  vmovaps [rsp+0xD0], xmm14
0000777bb65daa04  vmovaps [rsp+0xE0], xmm15
0000777bb65daa0d  sub rsp, 0x30
0000777bb65daa11  movaps [rsp], xmm11
0000777bb65daa16  movaps [rsp+0x10], xmm10
0000777bb65daa1c  movaps [rsp+0x20], xmm14
0000777bb65daa22  lea rdi, [rsp]
0000777bb65daa26  mov esi, 0x00
0000777bb65daa2b  mov rax, 0x569DC437B530
0000777bb65daa35  call rax
0000777bb65daa37  movaps xmm11, [rsp]
0000777bb65daa3c  add rsp, 0x30
0000777bb65daa40  vmovaps xmm0, [rsp]
0000777bb65daa45  vmovaps xmm1, [rsp+0x10]
0000777bb65daa4b  vmovaps xmm2, [rsp+0x20]
0000777bb65daa51  vmovaps xmm3, [rsp+0x30]
0000777bb65daa57  vmovaps xmm4, [rsp+0x40]
0000777bb65daa5d  vmovaps xmm5, [rsp+0x50]
0000777bb65daa63  vmovaps xmm6, [rsp+0x60]
0000777bb65daa69  vmovaps xmm7, [rsp+0x70]
0000777bb65daa6f  vmovaps xmm8, [rsp+0x80]
0000777bb65daa78  vmovaps xmm9, [rsp+0x90]
0000777bb65daa81  vmovaps xmm10, [rsp+0xA0]
0000777bb65daa8a  vmovaps xmm12, [rsp+0xB0]
0000777bb65daa93  vmovaps xmm13, [rsp+0xC0]
0000777bb65daa9c  vmovaps xmm14, [rsp+0xD0]
0000777bb65daaa5  vmovaps xmm15, [rsp+0xE0]
0000777bb65daaae  add rsp, 0xF0
0000777bb65daab5  pop r11
0000777bb65daab7  pop r10
0000777bb65daab9  pop r9
0000777bb65daabb  pop r8
0000777bb65daabd  pop rsi
0000777bb65daabe  pop rdi
0000777bb65daabf  pop rdx
0000777bb65daac0  pop rcx
0000777bb65daac1  pop rax
0000777bb65daac2  add rsp, 0x08
0000777bb65daac6  jmp 0x0000777BB65D64ED
0000777bb65daacb  call 0x0000777BB64E45A0
0000777bb65daad0  jmp 0x0000777BB65D64F7
0000777bb65daad5  sub rsp, 0x08
0000777bb65daad9  push rax
0000777bb65daada  push rcx
0000777bb65daadb  push rdx
0000777bb65daadc  push rdi
0000777bb65daadd  push rsi
0000777bb65daade  push r8
0000777bb65daae0  push r9
0000777bb65daae2  push r10
0000777bb65daae4  push r11
0000777bb65daae6  sub rsp, 0xF0
0000777bb65daaed  vmovaps [rsp], xmm0
0000777bb65daaf2  vmovaps [rsp+0x10], xmm1
0000777bb65daaf8  vmovaps [rsp+0x20], xmm2
0000777bb65daafe  vmovaps [rsp+0x30], xmm3
0000777bb65dab04  vmovaps [rsp+0x40], xmm4
0000777bb65dab0a  vmovaps [rsp+0x50], xmm5
0000777bb65dab10  vmovaps [rsp+0x60], xmm6
0000777bb65dab16  vmovaps [rsp+0x70], xmm7
0000777bb65dab1c  vmovaps [rsp+0x80], xmm8
0000777bb65dab25  vmovaps [rsp+0x90], xmm9
0000777bb65dab2e  vmovaps [rsp+0xA0], xmm11
0000777bb65dab37  vmovaps [rsp+0xB0], xmm12
0000777bb65dab40  vmovaps [rsp+0xC0], xmm13
0000777bb65dab49  vmovaps [rsp+0xD0], xmm14
0000777bb65dab52  vmovaps [rsp+0xE0], xmm15
0000777bb65dab5b  sub rsp, 0x30
0000777bb65dab5f  movaps [rsp], xmm10
0000777bb65dab64  movaps [rsp+0x10], xmm1
0000777bb65dab69  movaps [rsp+0x20], xmm12
0000777bb65dab6f  lea rdi, [rsp]
0000777bb65dab73  mov esi, 0x00
0000777bb65dab78  mov rax, 0x569DC437B530
0000777bb65dab82  call rax
0000777bb65dab84  movaps xmm10, [rsp]
0000777bb65dab89  add rsp, 0x30
0000777bb65dab8d  vmovaps xmm0, [rsp]
0000777bb65dab92  vmovaps xmm1, [rsp+0x10]
0000777bb65dab98  vmovaps xmm2, [rsp+0x20]
0000777bb65dab9e  vmovaps xmm3, [rsp+0x30]
0000777bb65daba4  vmovaps xmm4, [rsp+0x40]
0000777bb65dabaa  vmovaps xmm5, [rsp+0x50]
0000777bb65dabb0  vmovaps xmm6, [rsp+0x60]
0000777bb65dabb6  vmovaps xmm7, [rsp+0x70]
0000777bb65dabbc  vmovaps xmm8, [rsp+0x80]
0000777bb65dabc5  vmovaps xmm9, [rsp+0x90]
0000777bb65dabce  vmovaps xmm11, [rsp+0xA0]
0000777bb65dabd7  vmovaps xmm12, [rsp+0xB0]
0000777bb65dabe0  vmovaps xmm13, [rsp+0xC0]
0000777bb65dabe9  vmovaps xmm14, [rsp+0xD0]
0000777bb65dabf2  vmovaps xmm15, [rsp+0xE0]
0000777bb65dabfb  add rsp, 0xF0
0000777bb65dac02  pop r11
0000777bb65dac04  pop r10
0000777bb65dac06  pop r9
0000777bb65dac08  pop r8
0000777bb65dac0a  pop rsi
0000777bb65dac0b  pop rdi
0000777bb65dac0c  pop rdx
0000777bb65dac0d  pop rcx
0000777bb65dac0e  pop rax
0000777bb65dac0f  add rsp, 0x08
0000777bb65dac13  jmp 0x0000777BB65D651A
0000777bb65dac18  sub rsp, 0x08
0000777bb65dac1c  push rax
0000777bb65dac1d  push rcx
0000777bb65dac1e  push rdx
0000777bb65dac1f  push rdi
0000777bb65dac20  push rsi
0000777bb65dac21  push r8
0000777bb65dac23  push r9
0000777bb65dac25  push r10
0000777bb65dac27  push r11
0000777bb65dac29  sub rsp, 0xF0
0000777bb65dac30  vmovaps [rsp], xmm0
0000777bb65dac35  vmovaps [rsp+0x10], xmm1
0000777bb65dac3b  vmovaps [rsp+0x20], xmm2
0000777bb65dac41  vmovaps [rsp+0x30], xmm3
0000777bb65dac47  vmovaps [rsp+0x40], xmm4
0000777bb65dac4d  vmovaps [rsp+0x50], xmm5
0000777bb65dac53  vmovaps [rsp+0x60], xmm6
0000777bb65dac59  vmovaps [rsp+0x70], xmm7
0000777bb65dac5f  vmovaps [rsp+0x80], xmm8
0000777bb65dac68  vmovaps [rsp+0x90], xmm9
0000777bb65dac71  vmovaps [rsp+0xA0], xmm10
0000777bb65dac7a  vmovaps [rsp+0xB0], xmm11
0000777bb65dac83  vmovaps [rsp+0xC0], xmm13
0000777bb65dac8c  vmovaps [rsp+0xD0], xmm14
0000777bb65dac95  vmovaps [rsp+0xE0], xmm15
0000777bb65dac9e  sub rsp, 0x30
0000777bb65daca2  movaps [rsp], xmm12
0000777bb65daca7  movaps [rsp+0x10], xmm14
0000777bb65dacad  movaps [rsp+0x20], xmm1
0000777bb65dacb2  lea rdi, [rsp]
0000777bb65dacb6  mov esi, 0x00
0000777bb65dacbb  mov rax, 0x569DC437B530
0000777bb65dacc5  call rax
0000777bb65dacc7  movaps xmm12, [rsp]
0000777bb65daccc  add rsp, 0x30
0000777bb65dacd0  vmovaps xmm0, [rsp]
0000777bb65dacd5  vmovaps xmm1, [rsp+0x10]
0000777bb65dacdb  vmovaps xmm2, [rsp+0x20]
0000777bb65dace1  vmovaps xmm3, [rsp+0x30]
0000777bb65dace7  vmovaps xmm4, [rsp+0x40]
0000777bb65daced  vmovaps xmm5, [rsp+0x50]
0000777bb65dacf3  vmovaps xmm6, [rsp+0x60]
0000777bb65dacf9  vmovaps xmm7, [rsp+0x70]
0000777bb65dacff  vmovaps xmm8, [rsp+0x80]
0000777bb65dad08  vmovaps xmm9, [rsp+0x90]
0000777bb65dad11  vmovaps xmm10, [rsp+0xA0]
0000777bb65dad1a  vmovaps xmm11, [rsp+0xB0]
0000777bb65dad23  vmovaps xmm13, [rsp+0xC0]
0000777bb65dad2c  vmovaps xmm14, [rsp+0xD0]
0000777bb65dad35  vmovaps xmm15, [rsp+0xE0]
0000777bb65dad3e  add rsp, 0xF0
0000777bb65dad45  pop r11
0000777bb65dad47  pop r10
0000777bb65dad49  pop r9
0000777bb65dad4b  pop r8
0000777bb65dad4d  pop rsi
0000777bb65dad4e  pop rdi
0000777bb65dad4f  pop rdx
0000777bb65dad50  pop rcx
0000777bb65dad51  pop rax
0000777bb65dad52  add rsp, 0x08
0000777bb65dad56  jmp 0x0000777BB65D6549
0000777bb65dad5b  sub rsp, 0x08
0000777bb65dad5f  push rax
0000777bb65dad60  push rcx
0000777bb65dad61  push rdx
0000777bb65dad62  push rdi
0000777bb65dad63  push rsi
0000777bb65dad64  push r8
0000777bb65dad66  push r9
0000777bb65dad68  push r10
0000777bb65dad6a  push r11
0000777bb65dad6c  sub rsp, 0xF0
0000777bb65dad73  vmovaps [rsp], xmm0
0000777bb65dad78  vmovaps [rsp+0x10], xmm1
0000777bb65dad7e  vmovaps [rsp+0x20], xmm2
0000777bb65dad84  vmovaps [rsp+0x30], xmm3
0000777bb65dad8a  vmovaps [rsp+0x40], xmm4
0000777bb65dad90  vmovaps [rsp+0x50], xmm5
0000777bb65dad96  vmovaps [rsp+0x60], xmm6
0000777bb65dad9c  vmovaps [rsp+0x70], xmm7
0000777bb65dada2  vmovaps [rsp+0x80], xmm8
0000777bb65dadab  vmovaps [rsp+0x90], xmm9
0000777bb65dadb4  vmovaps [rsp+0xA0], xmm10
0000777bb65dadbd  vmovaps [rsp+0xB0], xmm11
0000777bb65dadc6  vmovaps [rsp+0xC0], xmm12
0000777bb65dadcf  vmovaps [rsp+0xD0], xmm13
0000777bb65dadd8  vmovaps [rsp+0xE0], xmm15
0000777bb65dade1  sub rsp, 0x30
0000777bb65dade5  movaps [rsp], xmm14
0000777bb65dadea  movaps [rsp+0x10], xmm9
0000777bb65dadf0  movaps [rsp+0x20], xmm1
0000777bb65dadf5  lea rdi, [rsp]
0000777bb65dadf9  mov esi, 0x00
0000777bb65dadfe  mov rax, 0x569DC437B530
0000777bb65dae08  call rax
0000777bb65dae0a  movaps xmm14, [rsp]
0000777bb65dae0f  add rsp, 0x30
0000777bb65dae13  vmovaps xmm0, [rsp]
0000777bb65dae18  vmovaps xmm1, [rsp+0x10]
0000777bb65dae1e  vmovaps xmm2, [rsp+0x20]
0000777bb65dae24  vmovaps xmm3, [rsp+0x30]
0000777bb65dae2a  vmovaps xmm4, [rsp+0x40]
0000777bb65dae30  vmovaps xmm5, [rsp+0x50]
0000777bb65dae36  vmovaps xmm6, [rsp+0x60]
0000777bb65dae3c  vmovaps xmm7, [rsp+0x70]
0000777bb65dae42  vmovaps xmm8, [rsp+0x80]
0000777bb65dae4b  vmovaps xmm9, [rsp+0x90]
0000777bb65dae54  vmovaps xmm10, [rsp+0xA0]
0000777bb65dae5d  vmovaps xmm11, [rsp+0xB0]
0000777bb65dae66  vmovaps xmm12, [rsp+0xC0]
0000777bb65dae6f  vmovaps xmm13, [rsp+0xD0]
0000777bb65dae78  vmovaps xmm15, [rsp+0xE0]
0000777bb65dae81  add rsp, 0xF0
0000777bb65dae88  pop r11
0000777bb65dae8a  pop r10
0000777bb65dae8c  pop r9
0000777bb65dae8e  pop r8
0000777bb65dae90  pop rsi
0000777bb65dae91  pop rdi
0000777bb65dae92  pop rdx
0000777bb65dae93  pop rcx
0000777bb65dae94  pop rax
0000777bb65dae95  add rsp, 0x08
0000777bb65dae99  jmp 0x0000777BB65D6578
0000777bb65dae9e  sub rsp, 0x08
0000777bb65daea2  push rax
0000777bb65daea3  push rcx
0000777bb65daea4  push rdx
0000777bb65daea5  push rdi
0000777bb65daea6  push rsi
0000777bb65daea7  push r8
0000777bb65daea9  push r9
0000777bb65daeab  push r10
0000777bb65daead  push r11
0000777bb65daeaf  sub rsp, 0xF0
0000777bb65daeb6  vmovaps [rsp], xmm0
0000777bb65daebb  vmovaps [rsp+0x10], xmm2
0000777bb65daec1  vmovaps [rsp+0x20], xmm3
0000777bb65daec7  vmovaps [rsp+0x30], xmm4
0000777bb65daecd  vmovaps [rsp+0x40], xmm5
0000777bb65daed3  vmovaps [rsp+0x50], xmm6
0000777bb65daed9  vmovaps [rsp+0x60], xmm7
0000777bb65daedf  vmovaps [rsp+0x70], xmm8
0000777bb65daee5  vmovaps [rsp+0x80], xmm9
0000777bb65daeee  vmovaps [rsp+0x90], xmm10
0000777bb65daef7  vmovaps [rsp+0xA0], xmm11
0000777bb65daf00  vmovaps [rsp+0xB0], xmm12
0000777bb65daf09  vmovaps [rsp+0xC0], xmm13
0000777bb65daf12  vmovaps [rsp+0xD0], xmm14
0000777bb65daf1b  vmovaps [rsp+0xE0], xmm15
0000777bb65daf24  sub rsp, 0x30
0000777bb65daf28  movaps [rsp], xmm1
0000777bb65daf2c  movaps [rsp+0x10], xmm13
0000777bb65daf32  movaps [rsp+0x20], xmm8
0000777bb65daf38  lea rdi, [rsp]
0000777bb65daf3c  mov esi, 0x00
0000777bb65daf41  mov rax, 0x569DC437B530
0000777bb65daf4b  call rax
0000777bb65daf4d  movaps xmm1, [rsp]
0000777bb65daf51  add rsp, 0x30
0000777bb65daf55  vmovaps xmm0, [rsp]
0000777bb65daf5a  vmovaps xmm2, [rsp+0x10]
0000777bb65daf60  vmovaps xmm3, [rsp+0x20]
0000777bb65daf66  vmovaps xmm4, [rsp+0x30]
0000777bb65daf6c  vmovaps xmm5, [rsp+0x40]
0000777bb65daf72  vmovaps xmm6, [rsp+0x50]
0000777bb65daf78  vmovaps xmm7, [rsp+0x60]
0000777bb65daf7e  vmovaps xmm8, [rsp+0x70]
0000777bb65daf84  vmovaps xmm9, [rsp+0x80]
0000777bb65daf8d  vmovaps xmm10, [rsp+0x90]
0000777bb65daf96  vmovaps xmm11, [rsp+0xA0]
0000777bb65daf9f  vmovaps xmm12, [rsp+0xB0]
0000777bb65dafa8  vmovaps xmm13, [rsp+0xC0]
0000777bb65dafb1  vmovaps xmm14, [rsp+0xD0]
0000777bb65dafba  vmovaps xmm15, [rsp+0xE0]
0000777bb65dafc3  add rsp, 0xF0
0000777bb65dafca  pop r11
0000777bb65dafcc  pop r10
0000777bb65dafce  pop r9
0000777bb65dafd0  pop r8
0000777bb65dafd2  pop rsi
0000777bb65dafd3  pop rdi
0000777bb65dafd4  pop rdx
0000777bb65dafd5  pop rcx
0000777bb65dafd6  pop rax
0000777bb65dafd7  add rsp, 0x08
0000777bb65dafdb  jmp 0x0000777BB65D659A
0000777bb65dafe0  call 0x0000777BB640C260
0000777bb65dafe5  jmp 0x0000777BB65D65A8
0000777bb65dafea  call 0x0000777BB64DE950
0000777bb65dafef  jmp 0x0000777BB65D65B2
0000777bb65daff4  sub rsp, 0x08
0000777bb65daff8  push rax
0000777bb65daff9  push rcx
0000777bb65daffa  push rdx
0000777bb65daffb  push rdi
0000777bb65daffc  push rsi
0000777bb65daffd  push r8
0000777bb65dafff  push r9
0000777bb65db001  push r10
0000777bb65db003  push r11
0000777bb65db005  sub rsp, 0xF0
0000777bb65db00c  vmovaps [rsp], xmm0
0000777bb65db011  vmovaps [rsp+0x10], xmm1
0000777bb65db017  vmovaps [rsp+0x20], xmm2
0000777bb65db01d  vmovaps [rsp+0x30], xmm3
0000777bb65db023  vmovaps [rsp+0x40], xmm4
0000777bb65db029  vmovaps [rsp+0x50], xmm5
0000777bb65db02f  vmovaps [rsp+0x60], xmm6
0000777bb65db035  vmovaps [rsp+0x70], xmm7
0000777bb65db03b  vmovaps [rsp+0x80], xmm9
0000777bb65db044  vmovaps [rsp+0x90], xmm10
0000777bb65db04d  vmovaps [rsp+0xA0], xmm11
0000777bb65db056  vmovaps [rsp+0xB0], xmm12
0000777bb65db05f  vmovaps [rsp+0xC0], xmm13
0000777bb65db068  vmovaps [rsp+0xD0], xmm14
0000777bb65db071  vmovaps [rsp+0xE0], xmm15
0000777bb65db07a  sub rsp, 0x30
0000777bb65db07e  movaps [rsp], xmm8
0000777bb65db083  movaps [rsp+0x10], xmm15
0000777bb65db089  movaps [rsp+0x20], xmm7
0000777bb65db08e  lea rdi, [rsp]
0000777bb65db092  mov esi, 0x00
0000777bb65db097  mov rax, 0x569DC437B530
0000777bb65db0a1  call rax
0000777bb65db0a3  movaps xmm8, [rsp]
0000777bb65db0a8  add rsp, 0x30
0000777bb65db0ac  vmovaps xmm0, [rsp]
0000777bb65db0b1  vmovaps xmm1, [rsp+0x10]
0000777bb65db0b7  vmovaps xmm2, [rsp+0x20]
0000777bb65db0bd  vmovaps xmm3, [rsp+0x30]
0000777bb65db0c3  vmovaps xmm4, [rsp+0x40]
0000777bb65db0c9  vmovaps xmm5, [rsp+0x50]
0000777bb65db0cf  vmovaps xmm6, [rsp+0x60]
0000777bb65db0d5  vmovaps xmm7, [rsp+0x70]
0000777bb65db0db  vmovaps xmm9, [rsp+0x80]
0000777bb65db0e4  vmovaps xmm10, [rsp+0x90]
0000777bb65db0ed  vmovaps xmm11, [rsp+0xA0]
0000777bb65db0f6  vmovaps xmm12, [rsp+0xB0]
0000777bb65db0ff  vmovaps xmm13, [rsp+0xC0]
0000777bb65db108  vmovaps xmm14, [rsp+0xD0]
0000777bb65db111  vmovaps xmm15, [rsp+0xE0]
0000777bb65db11a  add rsp, 0xF0
0000777bb65db121  pop r11
0000777bb65db123  pop r10
0000777bb65db125  pop r9
0000777bb65db127  pop r8
0000777bb65db129  pop rsi
0000777bb65db12a  pop rdi
0000777bb65db12b  pop rdx
0000777bb65db12c  pop rcx
0000777bb65db12d  pop rax
0000777bb65db12e  add rsp, 0x08
0000777bb65db132  jmp 0x0000777BB65D65D4
0000777bb65db137  sub rsp, 0x08
0000777bb65db13b  push rax
0000777bb65db13c  push rcx
0000777bb65db13d  push rdx
0000777bb65db13e  push rdi
0000777bb65db13f  push rsi
0000777bb65db140  push r8
0000777bb65db142  push r9
0000777bb65db144  push r10
0000777bb65db146  push r11
0000777bb65db148  sub rsp, 0xF0
0000777bb65db14f  vmovaps [rsp], xmm0
0000777bb65db154  vmovaps [rsp+0x10], xmm1
0000777bb65db15a  vmovaps [rsp+0x20], xmm2
0000777bb65db160  vmovaps [rsp+0x30], xmm3
0000777bb65db166  vmovaps [rsp+0x40], xmm4
0000777bb65db16c  vmovaps [rsp+0x50], xmm5
0000777bb65db172  vmovaps [rsp+0x60], xmm6
0000777bb65db178  vmovaps [rsp+0x70], xmm8
0000777bb65db17e  vmovaps [rsp+0x80], xmm9
0000777bb65db187  vmovaps [rsp+0x90], xmm10
0000777bb65db190  vmovaps [rsp+0xA0], xmm11
0000777bb65db199  vmovaps [rsp+0xB0], xmm12
0000777bb65db1a2  vmovaps [rsp+0xC0], xmm13
0000777bb65db1ab  vmovaps [rsp+0xD0], xmm14
0000777bb65db1b4  vmovaps [rsp+0xE0], xmm15
0000777bb65db1bd  sub rsp, 0x30
0000777bb65db1c1  movaps [rsp], xmm7
0000777bb65db1c5  movaps [rsp+0x10], xmm9
0000777bb65db1cb  movaps [rsp+0x20], xmm15
0000777bb65db1d1  lea rdi, [rsp]
0000777bb65db1d5  mov esi, 0x00
0000777bb65db1da  mov rax, 0x569DC437B530
0000777bb65db1e4  call rax
0000777bb65db1e6  movaps xmm7, [rsp]
0000777bb65db1ea  add rsp, 0x30
0000777bb65db1ee  vmovaps xmm0, [rsp]
0000777bb65db1f3  vmovaps xmm1, [rsp+0x10]
0000777bb65db1f9  vmovaps xmm2, [rsp+0x20]
0000777bb65db1ff  vmovaps xmm3, [rsp+0x30]
0000777bb65db205  vmovaps xmm4, [rsp+0x40]
0000777bb65db20b  vmovaps xmm5, [rsp+0x50]
0000777bb65db211  vmovaps xmm6, [rsp+0x60]
0000777bb65db217  vmovaps xmm8, [rsp+0x70]
0000777bb65db21d  vmovaps xmm9, [rsp+0x80]
0000777bb65db226  vmovaps xmm10, [rsp+0x90]
0000777bb65db22f  vmovaps xmm11, [rsp+0xA0]
0000777bb65db238  vmovaps xmm12, [rsp+0xB0]
0000777bb65db241  vmovaps xmm13, [rsp+0xC0]
0000777bb65db24a  vmovaps xmm14, [rsp+0xD0]
0000777bb65db253  vmovaps xmm15, [rsp+0xE0]
0000777bb65db25c  add rsp, 0xF0
0000777bb65db263  pop r11
0000777bb65db265  pop r10
0000777bb65db267  pop r9
0000777bb65db269  pop r8
0000777bb65db26b  pop rsi
0000777bb65db26c  pop rdi
0000777bb65db26d  pop rdx
0000777bb65db26e  pop rcx
0000777bb65db26f  pop rax
0000777bb65db270  add rsp, 0x08
0000777bb65db274  jmp 0x0000777BB65D6601
0000777bb65db279  sub rsp, 0x08
0000777bb65db27d  push rax
0000777bb65db27e  push rcx
0000777bb65db27f  push rdx
0000777bb65db280  push rdi
0000777bb65db281  push rsi
0000777bb65db282  push r8
0000777bb65db284  push r9
0000777bb65db286  push r10
0000777bb65db288  push r11
0000777bb65db28a  sub rsp, 0xF0
0000777bb65db291  vmovaps [rsp], xmm0
0000777bb65db296  vmovaps [rsp+0x10], xmm1
0000777bb65db29c  vmovaps [rsp+0x20], xmm2
0000777bb65db2a2  vmovaps [rsp+0x30], xmm3
0000777bb65db2a8  vmovaps [rsp+0x40], xmm4
0000777bb65db2ae  vmovaps [rsp+0x50], xmm5
0000777bb65db2b4  vmovaps [rsp+0x60], xmm6
0000777bb65db2ba  vmovaps [rsp+0x70], xmm7
0000777bb65db2c0  vmovaps [rsp+0x80], xmm8
0000777bb65db2c9  vmovaps [rsp+0x90], xmm10
0000777bb65db2d2  vmovaps [rsp+0xA0], xmm11
0000777bb65db2db  vmovaps [rsp+0xB0], xmm12
0000777bb65db2e4  vmovaps [rsp+0xC0], xmm13
0000777bb65db2ed  vmovaps [rsp+0xD0], xmm14
0000777bb65db2f6  vmovaps [rsp+0xE0], xmm15
0000777bb65db2ff  sub rsp, 0x30
0000777bb65db303  movaps [rsp], xmm9
0000777bb65db308  movaps [rsp+0x10], xmm13
0000777bb65db30e  movaps [rsp+0x20], xmm15
0000777bb65db314  lea rdi, [rsp]
0000777bb65db318  mov esi, 0x00
0000777bb65db31d  mov rax, 0x569DC437B530
0000777bb65db327  call rax
0000777bb65db329  movaps xmm9, [rsp]
0000777bb65db32e  add rsp, 0x30
0000777bb65db332  vmovaps xmm0, [rsp]
0000777bb65db337  vmovaps xmm1, [rsp+0x10]
0000777bb65db33d  vmovaps xmm2, [rsp+0x20]
0000777bb65db343  vmovaps xmm3, [rsp+0x30]
0000777bb65db349  vmovaps xmm4, [rsp+0x40]
0000777bb65db34f  vmovaps xmm5, [rsp+0x50]
0000777bb65db355  vmovaps xmm6, [rsp+0x60]
0000777bb65db35b  vmovaps xmm7, [rsp+0x70]
0000777bb65db361  vmovaps xmm8, [rsp+0x80]
0000777bb65db36a  vmovaps xmm10, [rsp+0x90]
0000777bb65db373  vmovaps xmm11, [rsp+0xA0]
0000777bb65db37c  vmovaps xmm12, [rsp+0xB0]
0000777bb65db385  vmovaps xmm13, [rsp+0xC0]
0000777bb65db38e  vmovaps xmm14, [rsp+0xD0]
0000777bb65db397  vmovaps xmm15, [rsp+0xE0]
0000777bb65db3a0  add rsp, 0xF0
0000777bb65db3a7  pop r11
0000777bb65db3a9  pop r10
0000777bb65db3ab  pop r9
0000777bb65db3ad  pop r8
0000777bb65db3af  pop rsi
0000777bb65db3b0  pop rdi
0000777bb65db3b1  pop rdx
0000777bb65db3b2  pop rcx
0000777bb65db3b3  pop rax
0000777bb65db3b4  add rsp, 0x08
0000777bb65db3b8  jmp 0x0000777BB65D662F
0000777bb65db3bd  sub rsp, 0x08
0000777bb65db3c1  push rax
0000777bb65db3c2  push rcx
0000777bb65db3c3  push rdx
0000777bb65db3c4  push rdi
0000777bb65db3c5  push rsi
0000777bb65db3c6  push r8
0000777bb65db3c8  push r9
0000777bb65db3ca  push r10
0000777bb65db3cc  push r11
0000777bb65db3ce  sub rsp, 0xF0
0000777bb65db3d5  vmovaps [rsp], xmm0
0000777bb65db3da  vmovaps [rsp+0x10], xmm1
0000777bb65db3e0  vmovaps [rsp+0x20], xmm2
0000777bb65db3e6  vmovaps [rsp+0x30], xmm3
0000777bb65db3ec  vmovaps [rsp+0x40], xmm4
0000777bb65db3f2  vmovaps [rsp+0x50], xmm5
0000777bb65db3f8  vmovaps [rsp+0x60], xmm6
0000777bb65db3fe  vmovaps [rsp+0x70], xmm7
0000777bb65db404  vmovaps [rsp+0x80], xmm8
0000777bb65db40d  vmovaps [rsp+0x90], xmm9
0000777bb65db416  vmovaps [rsp+0xA0], xmm10
0000777bb65db41f  vmovaps [rsp+0xB0], xmm11
0000777bb65db428  vmovaps [rsp+0xC0], xmm12
0000777bb65db431  vmovaps [rsp+0xD0], xmm13
0000777bb65db43a  vmovaps [rsp+0xE0], xmm14
0000777bb65db443  sub rsp, 0x30
0000777bb65db447  movaps [rsp], xmm15
0000777bb65db44c  movaps [rsp+0x10], xmm11
0000777bb65db452  movaps [rsp+0x20], xmm12
0000777bb65db458  lea rdi, [rsp]
0000777bb65db45c  mov esi, 0x00
0000777bb65db461  mov rax, 0x569DC437B530
0000777bb65db46b  call rax
0000777bb65db46d  movaps xmm15, [rsp]
0000777bb65db472  add rsp, 0x30
0000777bb65db476  vmovaps xmm0, [rsp]
0000777bb65db47b  vmovaps xmm1, [rsp+0x10]
0000777bb65db481  vmovaps xmm2, [rsp+0x20]
0000777bb65db487  vmovaps xmm3, [rsp+0x30]
0000777bb65db48d  vmovaps xmm4, [rsp+0x40]
0000777bb65db493  vmovaps xmm5, [rsp+0x50]
0000777bb65db499  vmovaps xmm6, [rsp+0x60]
0000777bb65db49f  vmovaps xmm7, [rsp+0x70]
0000777bb65db4a5  vmovaps xmm8, [rsp+0x80]
0000777bb65db4ae  vmovaps xmm9, [rsp+0x90]
0000777bb65db4b7  vmovaps xmm10, [rsp+0xA0]
0000777bb65db4c0  vmovaps xmm11, [rsp+0xB0]
0000777bb65db4c9  vmovaps xmm12, [rsp+0xC0]
0000777bb65db4d2  vmovaps xmm13, [rsp+0xD0]
0000777bb65db4db  vmovaps xmm14, [rsp+0xE0]
0000777bb65db4e4  add rsp, 0xF0
0000777bb65db4eb  pop r11
0000777bb65db4ed  pop r10
0000777bb65db4ef  pop r9
0000777bb65db4f1  pop r8
0000777bb65db4f3  pop rsi
0000777bb65db4f4  pop rdi
0000777bb65db4f5  pop rdx
0000777bb65db4f6  pop rcx
0000777bb65db4f7  pop rax
0000777bb65db4f8  add rsp, 0x08
0000777bb65db4fc  jmp 0x0000777BB65D664A
0000777bb65db501  sub rsp, 0x08
0000777bb65db505  push rax
0000777bb65db506  push rcx
0000777bb65db507  push rdx
0000777bb65db508  push rdi
0000777bb65db509  push rsi
0000777bb65db50a  push r8
0000777bb65db50c  push r9
0000777bb65db50e  push r10
0000777bb65db510  push r11
0000777bb65db512  sub rsp, 0xF0
0000777bb65db519  vmovaps [rsp], xmm0
0000777bb65db51e  vmovaps [rsp+0x10], xmm1
0000777bb65db524  vmovaps [rsp+0x20], xmm2
0000777bb65db52a  vmovaps [rsp+0x30], xmm3
0000777bb65db530  vmovaps [rsp+0x40], xmm4
0000777bb65db536  vmovaps [rsp+0x50], xmm5
0000777bb65db53c  vmovaps [rsp+0x60], xmm6
0000777bb65db542  vmovaps [rsp+0x70], xmm7
0000777bb65db548  vmovaps [rsp+0x80], xmm8
0000777bb65db551  vmovaps [rsp+0x90], xmm9
0000777bb65db55a  vmovaps [rsp+0xA0], xmm10
0000777bb65db563  vmovaps [rsp+0xB0], xmm11
0000777bb65db56c  vmovaps [rsp+0xC0], xmm12
0000777bb65db575  vmovaps [rsp+0xD0], xmm14
0000777bb65db57e  vmovaps [rsp+0xE0], xmm15
0000777bb65db587  sub rsp, 0x30
0000777bb65db58b  movaps [rsp], xmm13
0000777bb65db590  movaps [rsp+0x10], xmm10
0000777bb65db596  movaps [rsp+0x20], xmm14
0000777bb65db59c  lea rdi, [rsp]
0000777bb65db5a0  mov esi, 0x00
0000777bb65db5a5  mov rax, 0x569DC437B530
0000777bb65db5af  call rax
0000777bb65db5b1  movaps xmm13, [rsp]
0000777bb65db5b6  add rsp, 0x30
0000777bb65db5ba  vmovaps xmm0, [rsp]
0000777bb65db5bf  vmovaps xmm1, [rsp+0x10]
0000777bb65db5c5  vmovaps xmm2, [rsp+0x20]
0000777bb65db5cb  vmovaps xmm3, [rsp+0x30]
0000777bb65db5d1  vmovaps xmm4, [rsp+0x40]
0000777bb65db5d7  vmovaps xmm5, [rsp+0x50]
0000777bb65db5dd  vmovaps xmm6, [rsp+0x60]
0000777bb65db5e3  vmovaps xmm7, [rsp+0x70]
0000777bb65db5e9  vmovaps xmm8, [rsp+0x80]
0000777bb65db5f2  vmovaps xmm9, [rsp+0x90]
0000777bb65db5fb  vmovaps xmm10, [rsp+0xA0]
0000777bb65db604  vmovaps xmm11, [rsp+0xB0]
0000777bb65db60d  vmovaps xmm12, [rsp+0xC0]
0000777bb65db616  vmovaps xmm14, [rsp+0xD0]
0000777bb65db61f  vmovaps xmm15, [rsp+0xE0]
0000777bb65db628  add rsp, 0xF0
0000777bb65db62f  pop r11
0000777bb65db631  pop r10
0000777bb65db633  pop r9
0000777bb65db635  pop r8
0000777bb65db637  pop rsi
0000777bb65db638  pop rdi
0000777bb65db639  pop rdx
0000777bb65db63a  pop rcx
0000777bb65db63b  pop rax
0000777bb65db63c  add rsp, 0x08
0000777bb65db640  jmp 0x0000777BB65D666D
0000777bb65db645  sub rsp, 0x08
0000777bb65db649  push rax
0000777bb65db64a  push rcx
0000777bb65db64b  push rdx
0000777bb65db64c  push rdi
0000777bb65db64d  push rsi
0000777bb65db64e  push r8
0000777bb65db650  push r9
0000777bb65db652  push r10
0000777bb65db654  push r11
0000777bb65db656  sub rsp, 0xF0
0000777bb65db65d  vmovaps [rsp], xmm0
0000777bb65db662  vmovaps [rsp+0x10], xmm1
0000777bb65db668  vmovaps [rsp+0x20], xmm2
0000777bb65db66e  vmovaps [rsp+0x30], xmm3
0000777bb65db674  vmovaps [rsp+0x40], xmm4
0000777bb65db67a  vmovaps [rsp+0x50], xmm5
0000777bb65db680  vmovaps [rsp+0x60], xmm6
0000777bb65db686  vmovaps [rsp+0x70], xmm7
0000777bb65db68c  vmovaps [rsp+0x80], xmm8
0000777bb65db695  vmovaps [rsp+0x90], xmm9
0000777bb65db69e  vmovaps [rsp+0xA0], xmm10
0000777bb65db6a7  vmovaps [rsp+0xB0], xmm11
0000777bb65db6b0  vmovaps [rsp+0xC0], xmm12
0000777bb65db6b9  vmovaps [rsp+0xD0], xmm13
0000777bb65db6c2  vmovaps [rsp+0xE0], xmm15
0000777bb65db6cb  sub rsp, 0x30
0000777bb65db6cf  movaps [rsp], xmm14
0000777bb65db6d4  movaps [rsp+0x10], xmm1
0000777bb65db6d9  movaps [rsp+0x20], xmm7
0000777bb65db6de  lea rdi, [rsp]
0000777bb65db6e2  mov esi, 0x00
0000777bb65db6e7  mov rax, 0x569DC437B530
0000777bb65db6f1  call rax
0000777bb65db6f3  movaps xmm14, [rsp]
0000777bb65db6f8  add rsp, 0x30
0000777bb65db6fc  vmovaps xmm0, [rsp]
0000777bb65db701  vmovaps xmm1, [rsp+0x10]
0000777bb65db707  vmovaps xmm2, [rsp+0x20]
0000777bb65db70d  vmovaps xmm3, [rsp+0x30]
0000777bb65db713  vmovaps xmm4, [rsp+0x40]
0000777bb65db719  vmovaps xmm5, [rsp+0x50]
0000777bb65db71f  vmovaps xmm6, [rsp+0x60]
0000777bb65db725  vmovaps xmm7, [rsp+0x70]
0000777bb65db72b  vmovaps xmm8, [rsp+0x80]
0000777bb65db734  vmovaps xmm9, [rsp+0x90]
0000777bb65db73d  vmovaps xmm10, [rsp+0xA0]
0000777bb65db746  vmovaps xmm11, [rsp+0xB0]
0000777bb65db74f  vmovaps xmm12, [rsp+0xC0]
0000777bb65db758  vmovaps xmm13, [rsp+0xD0]
0000777bb65db761  vmovaps xmm15, [rsp+0xE0]
0000777bb65db76a  add rsp, 0xF0
0000777bb65db771  pop r11
0000777bb65db773  pop r10
0000777bb65db775  pop r9
0000777bb65db777  pop r8
0000777bb65db779  pop rsi
0000777bb65db77a  pop rdi
0000777bb65db77b  pop rdx
0000777bb65db77c  pop rcx
0000777bb65db77d  pop rax
0000777bb65db77e  add rsp, 0x08
0000777bb65db782  jmp 0x0000777BB65D6690
0000777bb65db787  sub rsp, 0x08
0000777bb65db78b  push rax
0000777bb65db78c  push rcx
0000777bb65db78d  push rdx
0000777bb65db78e  push rdi
0000777bb65db78f  push rsi
0000777bb65db790  push r8
0000777bb65db792  push r9
0000777bb65db794  push r10
0000777bb65db796  push r11
0000777bb65db798  sub rsp, 0xF0
0000777bb65db79f  vmovaps [rsp], xmm0
0000777bb65db7a4  vmovaps [rsp+0x10], xmm2
0000777bb65db7aa  vmovaps [rsp+0x20], xmm3
0000777bb65db7b0  vmovaps [rsp+0x30], xmm4
0000777bb65db7b6  vmovaps [rsp+0x40], xmm5
0000777bb65db7bc  vmovaps [rsp+0x50], xmm6
0000777bb65db7c2  vmovaps [rsp+0x60], xmm7
0000777bb65db7c8  vmovaps [rsp+0x70], xmm8
0000777bb65db7ce  vmovaps [rsp+0x80], xmm9
0000777bb65db7d7  vmovaps [rsp+0x90], xmm10
0000777bb65db7e0  vmovaps [rsp+0xA0], xmm11
0000777bb65db7e9  vmovaps [rsp+0xB0], xmm12
0000777bb65db7f2  vmovaps [rsp+0xC0], xmm13
0000777bb65db7fb  vmovaps [rsp+0xD0], xmm14
0000777bb65db804  vmovaps [rsp+0xE0], xmm15
0000777bb65db80d  sub rsp, 0x30
0000777bb65db811  movaps [rsp], xmm1
0000777bb65db815  movaps [rsp+0x10], xmm8
0000777bb65db81b  movaps [rsp+0x20], xmm9
0000777bb65db821  lea rdi, [rsp]
0000777bb65db825  mov esi, 0x00
0000777bb65db82a  mov rax, 0x569DC437B530
0000777bb65db834  call rax
0000777bb65db836  movaps xmm1, [rsp]
0000777bb65db83a  add rsp, 0x30
0000777bb65db83e  vmovaps xmm0, [rsp]
0000777bb65db843  vmovaps xmm2, [rsp+0x10]
0000777bb65db849  vmovaps xmm3, [rsp+0x20]
0000777bb65db84f  vmovaps xmm4, [rsp+0x30]
0000777bb65db855  vmovaps xmm5, [rsp+0x40]
0000777bb65db85b  vmovaps xmm6, [rsp+0x50]
0000777bb65db861  vmovaps xmm7, [rsp+0x60]
0000777bb65db867  vmovaps xmm8, [rsp+0x70]
0000777bb65db86d  vmovaps xmm9, [rsp+0x80]
0000777bb65db876  vmovaps xmm10, [rsp+0x90]
0000777bb65db87f  vmovaps xmm11, [rsp+0xA0]
0000777bb65db888  vmovaps xmm12, [rsp+0xB0]
0000777bb65db891  vmovaps xmm13, [rsp+0xC0]
0000777bb65db89a  vmovaps xmm14, [rsp+0xD0]
0000777bb65db8a3  vmovaps xmm15, [rsp+0xE0]
0000777bb65db8ac  add rsp, 0xF0
0000777bb65db8b3  pop r11
0000777bb65db8b5  pop r10
0000777bb65db8b7  pop r9
0000777bb65db8b9  pop r8
0000777bb65db8bb  pop rsi
0000777bb65db8bc  pop rdi
0000777bb65db8bd  pop rdx
0000777bb65db8be  pop rcx
0000777bb65db8bf  pop rax
0000777bb65db8c0  add rsp, 0x08
0000777bb65db8c4  jmp 0x0000777BB65D66B2
0000777bb65db8c9  call 0x0000777BB64B3E40
0000777bb65db8ce  jmp 0x0000777BB65D66C0
0000777bb65db8d3  call 0x0000777BB640C380
0000777bb65db8d8  jmp 0x0000777BB65D66CA
0000777bb65db8dd  call 0x0000777BB640D600
0000777bb65db8e2  jmp 0x0000777BB65D66D4
0000777bb65db8e7  call 0x0000777BB63FF540
0000777bb65db8ec  jmp 0x0000777BB65D66DE
0000777bb65db8f1  int3
0000777bb65db8f2  nop [rax+rax*1], ax
0000777bb65db8fb  nop [rax+rax*1], eax
0000777bb65db900  mov eax, [r15+0x48]
0000777bb65db904  lea r14d, [eax+0x01]
0000777bb65db909  mov [rsp+0x10], r14d
0000777bb65db90e  mov r14d, r14d
0000777bb65db911  mov [r15+0x48], r14
0000777bb65db915  xor eax, eax
0000777bb65db917  mov r14d, [rsp+0x10]
0000777bb65db91c  cmp r14d, 0x1F4
0000777bb65db923  cmc
0000777bb65db924  lahf
0000777bb65db925  seto al
0000777bb65db928  mov [r15+0x108], eax
0000777bb65db92f  mov eax, [r15+0x108]
0000777bb65db936  sahf
0000777bb65db937  jnz 0x0000777BB65DB969
0000777bb65db939  cmp dword ptr [r15+0x318], 0x00
0000777bb65db941  jz 0x0000777BB65E1AB0
0000777bb65db947  nop [rax+rax*1], ax
0000777bb65db950  nop [rax+rax*1], eax
0000777bb65db958  mov eax, 0x410450
0000777bb65db95d  mov [r15+0x100], rax
0000777bb65db964  jmp 0x0000777BB63FE110
0000777bb65db969  cmp dword ptr [r15+0x318], 0x00
0000777bb65db971  jz 0x0000777BB65DB9A0
0000777bb65db977  nop [rax+rax*1], ax
0000777bb65db980  nop [rax+rax*1], eax
0000777bb65db988  mov eax, 0x410274
0000777bb65db98d  mov [r15+0x100], rax
0000777bb65db994  jmp 0x0000777BB63FE110
0000777bb65db999  int3
0000777bb65db99a  int3
0000777bb65db99b  nop [rax+rax*1], eax
0000777bb65db9a0  mov rax, [r15+0x40]
0000777bb65db9a4  movaps xmm1, [r15+0x1D0]
0000777bb65db9ac  vmovaps [rsp+0x10], xmm1
0000777bb65db9b2  vmovaps xmm15, [rsp+0x10]
0000777bb65db9b8  por xmm1, xmm15
0000777bb65db9bd  movaps xmm14, [r15+0x1A0]
0000777bb65db9c5  vmovaps [rsp+0x10], xmm14
0000777bb65db9cb  vmovaps xmm13, [rsp+0x10]
0000777bb65db9d1  por xmm14, xmm13
0000777bb65db9d6  lea r14, [rax+0x30]
0000777bb65db9da  mov r12, [r13+r14*1]
0000777bb65db9df  lea r14, [rax+0x38]
0000777bb65db9e3  mov r11, [r13+r14*1]
0000777bb65db9e8  movq xmm13, r12
0000777bb65db9ed  movq xmm12, r11
0000777bb65db9f2  movq xmm13, xmm13
0000777bb65db9f7  vmovaps [rsp+0x10], xmm13
0000777bb65db9fd  movq xmm13, xmm13
0000777bb65dba02  movaps [r15+0x130], xmm13
0000777bb65dba0a  movq xmm12, xmm12
0000777bb65dba0f  vmovaps [rsp+0x20], xmm12
0000777bb65dba15  movq xmm12, xmm12
0000777bb65dba1a  movaps [r15+0x280], xmm12
0000777bb65dba22  movaps xmm13, [r15+0x270]
0000777bb65dba2a  vmovaps [rsp+0x30], xmm13
0000777bb65dba30  vmovaps xmm12, [rsp+0x30]
0000777bb65dba36  por xmm13, xmm12
0000777bb65dba3b  lea r14, [rax+0x20]
0000777bb65dba3f  mov r12, [r13+r14*1]
0000777bb65dba44  lea r14, [rax+0x28]
0000777bb65dba48  mov r11, [r13+r14*1]
0000777bb65dba4d  movq xmm12, r12
0000777bb65dba52  movq xmm11, r11
0000777bb65dba57  movq xmm12, xmm12
0000777bb65dba5c  vmovaps [rsp+0x30], xmm12
0000777bb65dba62  movq xmm12, xmm12
0000777bb65dba67  movaps [r15+0x150], xmm12
0000777bb65dba6f  movq xmm11, xmm11
0000777bb65dba74  vmovaps [rsp+0x40], xmm11
0000777bb65dba7a  movq xmm11, xmm11
0000777bb65dba7f  movaps [r15+0x140], xmm11
0000777bb65dba87  lea r14, [rax+0x10]
0000777bb65dba8b  mov r12, [r13+r14*1]
0000777bb65dba90  lea r14, [rax+0x18]
0000777bb65dba94  mov r11, [r13+r14*1]
0000777bb65dba99  movq xmm12, r12
0000777bb65dba9e  movq xmm11, r11
0000777bb65dbaa3  movq xmm12, xmm12
0000777bb65dbaa8  vmovaps [rsp+0x50], xmm12
0000777bb65dbaae  movq xmm12, xmm12
0000777bb65dbab3  movaps [r15+0x170], xmm12
0000777bb65dbabb  movq xmm11, xmm11
0000777bb65dbac0  vmovaps [rsp+0x60], xmm11
0000777bb65dbac6  movq xmm11, xmm11
0000777bb65dbacb  movaps [r15+0x160], xmm11
0000777bb65dbad3  mov r14, [r13+rax*1]
0000777bb65dbad8  vmovq xmm12, r14
0000777bb65dbadd  vpbroadcastq xmm12, xmm12
0000777bb65dbae2  lea r14, [rax+0x08]
0000777bb65dbae6  mov rax, [r13+r14*1]
0000777bb65dbaeb  movq xmm11, rax
0000777bb65dbaf0  movaps [r15+0x230], xmm11
0000777bb65dbaf8  mov rax, [r15+0xF8]
0000777bb65dbaff  lea r14, [rax+0x50]
0000777bb65dbb03  movups xmm11, [r13+r14*1]
0000777bb65dbb09  lea r14, [rax+0x60]
0000777bb65dbb0d  movups xmm10, [r13+r14*1]
0000777bb65dbb13  lea r14, [rax+0x30]
0000777bb65dbb17  movups xmm9, [r13+r14*1]
0000777bb65dbb1d  mov r14, [r15+0x50]
0000777bb65dbb21  mov [r15+0x60], r14
0000777bb65dbb25  mov qword ptr [r15+0x58], 0x40
0000777bb65dbb2d  movaps xmm8, xmm12
0000777bb65dbb31  mulpd xmm8, xmm15
0000777bb65dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
0000777bb65dbb3c  ptest xmm7, xmm7
0000777bb65dbb41  jnz 0x0000777BB65DC96A
0000777bb65dbb47  movq xmm15, qword ptr [r15+0x230]
0000777bb65dbb50  vmovaps [rsp+0x70], xmm15
0000777bb65dbb56  vpermilpd xmm15, xmm15, 0x00
0000777bb65dbb5c  movaps xmm7, xmm9
0000777bb65dbb60  mulpd xmm7, xmm15
0000777bb65dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
0000777bb65dbb6a  ptest xmm6, xmm6
0000777bb65dbb6f  jnz 0x0000777BB65DCAAE
0000777bb65dbb75  vxorps xmm15, xmm15, xmm15
0000777bb65dbb7a  vpbroadcastq xmm15, xmm15
0000777bb65dbb7f  movaps xmm9, xmm12
0000777bb65dbb83  mulpd xmm9, xmm10
0000777bb65dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
0000777bb65dbb8e  ptest xmm6, xmm6
0000777bb65dbb93  jnz 0x0000777BB65DCBF0
0000777bb65dbb99  movaps xmm10, xmm12
0000777bb65dbb9d  mulpd xmm10, xmm11
0000777bb65dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
0000777bb65dbba8  ptest xmm6, xmm6
0000777bb65dbbad  jnz 0x0000777BB65DCD34
0000777bb65dbbb3  movaps xmm11, [r15+0x1F0]
0000777bb65dbbbb  movaps xmm6, xmm12
0000777bb65dbbbf  mulpd xmm6, xmm11
0000777bb65dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
0000777bb65dbbc9  ptest xmm5, xmm5
0000777bb65dbbce  jnz 0x0000777BB65DCE78
0000777bb65dbbd4  movaps xmm12, [r15+0x2A0]
0000777bb65dbbdc  vmovaps [rsp+0x80], xmm12
0000777bb65dbbe5  vmovaps xmm11, [rsp+0x80]
0000777bb65dbbee  por xmm12, xmm11
0000777bb65dbbf3  movaps xmm11, [r15+0x250]
0000777bb65dbbfb  vmovaps [rsp+0x80], xmm11
0000777bb65dbc04  vmovaps xmm5, [rsp+0x80]
0000777bb65dbc0d  por xmm11, xmm5
0000777bb65dbc12  vmovaps xmm4, [rsp+0x70]
0000777bb65dbc18  vpermilpd xmm4, xmm4, 0x00
0000777bb65dbc1e  movaps xmm3, xmm5
0000777bb65dbc21  mulpd xmm3, xmm4
0000777bb65dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
0000777bb65dbc2a  ptest xmm2, xmm2
0000777bb65dbc2f  jnz 0x0000777BB65DCFBA
0000777bb65dbc35  mov [rsp+0x80], rax
0000777bb65dbc3d  xor eax, eax
0000777bb65dbc3f  mov r12d, 0x40
0000777bb65dbc45  mov r11d, 0x200
0000777bb65dbc4b  cmp r12, r11
0000777bb65dbc4e  cmc
0000777bb65dbc4f  lahf
0000777bb65dbc50  seto al
0000777bb65dbc53  mov [r15+0x108], eax
0000777bb65dbc5a  movaps xmm5, xmm8
0000777bb65dbc5e  addpd xmm5, xmm15
0000777bb65dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
0000777bb65dbc68  ptest xmm4, xmm4
0000777bb65dbc6d  jnz 0x0000777BB65DD0FA
0000777bb65dbc73  movaps xmm8, [r15+0x1B0]
0000777bb65dbc7b  movaps xmm4, xmm9
0000777bb65dbc7f  addpd xmm4, xmm8
0000777bb65dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
0000777bb65dbc89  ptest xmm2, xmm2
0000777bb65dbc8e  jnz 0x0000777BB65DD23C
0000777bb65dbc94  movaps xmm9, xmm10
0000777bb65dbc98  addpd xmm9, xmm8
0000777bb65dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
0000777bb65dbca3  ptest xmm2, xmm2
0000777bb65dbca8  jnz 0x0000777BB65DD37E
0000777bb65dbcae  movaps xmm10, [r15+0x2F0]
0000777bb65dbcb6  vmovaps [rsp+0x90], xmm10
0000777bb65dbcbf  vmovaps xmm8, [rsp+0x90]
0000777bb65dbcc8  por xmm10, xmm8
0000777bb65dbccd  movaps xmm8, [r15+0x2E0]
0000777bb65dbcd5  vmovaps [rsp+0x90], xmm8
0000777bb65dbcde  vmovaps xmm2, [rsp+0x90]
0000777bb65dbce7  por xmm8, xmm2
0000777bb65dbcec  movaps xmm2, [r15+0x2D0]
0000777bb65dbcf4  vmovaps [rsp+0x90], xmm2
0000777bb65dbcfd  vmovaps [rsp+0xA0], xmm1
0000777bb65dbd06  vmovaps xmm1, [rsp+0x90]
0000777bb65dbd0f  por xmm2, xmm1
0000777bb65dbd13  movaps xmm1, [r15+0x200]
0000777bb65dbd1b  vmovaps [rsp+0x90], xmm1
0000777bb65dbd24  vmovaps [rsp+0xB0], xmm15
0000777bb65dbd2d  vmovaps xmm15, [rsp+0x90]
0000777bb65dbd36  por xmm1, xmm15
0000777bb65dbd3b  movaps xmm15, [r15+0x1C0]
0000777bb65dbd43  vmovaps [rsp+0x90], xmm15
0000777bb65dbd4c  vmovaps [rsp+0xC0], xmm1
0000777bb65dbd55  vmovaps xmm1, [rsp+0x90]
0000777bb65dbd5e  por xmm15, xmm1
0000777bb65dbd63  movaps xmm1, [r15+0x190]
0000777bb65dbd6b  vmovaps [rsp+0x90], xmm1
0000777bb65dbd74  vmovaps [rsp+0xD0], xmm15
0000777bb65dbd7d  vmovaps xmm15, [rsp+0x90]
0000777bb65dbd86  por xmm1, xmm15
0000777bb65dbd8b  movaps xmm15, [r15+0x300]
0000777bb65dbd93  vmovaps [rsp+0x90], xmm15
0000777bb65dbd9c  vmovaps [rsp+0xE0], xmm1
0000777bb65dbda5  vmovaps xmm1, [rsp+0x90]
0000777bb65dbdae  por xmm15, xmm1
0000777bb65dbdb3  mov rax, [rsp+0x80]
0000777bb65dbdbb  lea r12, [rax+0xA0]
0000777bb65dbdc2  movups xmm1, [r13+r12*1]
0000777bb65dbdc8  lea r12, [rax+0xB0]
0000777bb65dbdcf  vmovaps [rsp+0x80], xmm1
0000777bb65dbdd8  movups xmm1, [r13+r12*1]
0000777bb65dbdde  vmovaps [rsp+0x90], xmm1
0000777bb65dbde7  vmovaps [rsp+0xF0], xmm15
0000777bb65dbdf0  vmovaps xmm15, [rsp+0xB0]
0000777bb65dbdf9  vmovaps [rsp+0xB0], xmm14
0000777bb65dbe02  movaps xmm1, xmm6
0000777bb65dbe05  addpd xmm1, xmm15
0000777bb65dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
0000777bb65dbe0f  ptest xmm14, xmm14
0000777bb65dbe15  jnz 0x0000777BB65DD4D6
0000777bb65dbe1b  lea r12, [rax+0xF0]
0000777bb65dbe22  movups xmm15, [r13+r12*1]
0000777bb65dbe28  movaps xmm14, xmm4
0000777bb65dbe2c  addpd xmm14, xmm3
0000777bb65dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
0000777bb65dbe37  ptest xmm6, xmm6
0000777bb65dbe3c  jnz 0x0000777BB65DD621
0000777bb65dbe42  movaps xmm6, xmm9
0000777bb65dbe46  addpd xmm6, xmm7
0000777bb65dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
0000777bb65dbe4f  ptest xmm4, xmm4
0000777bb65dbe54  jnz 0x0000777BB65DD763
0000777bb65dbe5a  vmovaps xmm9, [rsp+0x70]
0000777bb65dbe60  vpermilpd xmm9, xmm9, 0x00
0000777bb65dbe66  vmovaps xmm4, [rsp+0x90]
0000777bb65dbe6f  movaps xmm7, xmm4
0000777bb65dbe72  mulpd xmm7, xmm9
0000777bb65dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
0000777bb65dbe7c  ptest xmm3, xmm3
0000777bb65dbe81  jnz 0x0000777BB65DD8A4
0000777bb65dbe87  vmovaps xmm9, [rsp+0x50]
0000777bb65dbe8d  vpermilpd xmm9, xmm9, 0x00
0000777bb65dbe93  movaps xmm4, xmm15
0000777bb65dbe97  mulpd xmm4, xmm9
0000777bb65dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
0000777bb65dbea1  ptest xmm3, xmm3
0000777bb65dbea6  jnz 0x0000777BB65DD9E5
0000777bb65dbeac  lea r12, [rax+0xE0]
0000777bb65dbeb3  movups xmm15, [r13+r12*1]
0000777bb65dbeb9  vmovaps xmm9, [rsp+0x70]
0000777bb65dbebf  vpermilpd xmm9, xmm9, 0x00
0000777bb65dbec5  vmovaps [rsp+0x70], xmm1
0000777bb65dbecb  vmovaps xmm1, [rsp+0x80]
0000777bb65dbed4  vmovaps [rsp+0x80], xmm15
0000777bb65dbedd  movaps xmm3, xmm1
0000777bb65dbee0  mulpd xmm3, xmm9
0000777bb65dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
0000777bb65dbeea  ptest xmm15, xmm15
0000777bb65dbef0  jnz 0x0000777BB65DDB31
0000777bb65dbef6  vmovaps xmm1, [rsp+0xF0]
0000777bb65dbeff  vmovaps xmm15, [rsp+0xF0]
0000777bb65dbf08  por xmm1, xmm15
0000777bb65dbf0d  movaps [r15+0x300], xmm1
0000777bb65dbf15  vmovaps xmm15, [rsp+0xE0]
0000777bb65dbf1e  vmovaps xmm9, [rsp+0xE0]
0000777bb65dbf27  por xmm15, xmm9
0000777bb65dbf2c  movaps [r15+0x190], xmm15
0000777bb65dbf34  vmovaps xmm9, [rsp+0x50]
0000777bb65dbf3a  vpermilpd xmm9, xmm9, 0x00
0000777bb65dbf40  vmovaps [rsp+0x90], xmm1
0000777bb65dbf49  vmovaps [rsp+0xE0], xmm15
0000777bb65dbf52  vmovaps xmm15, [rsp+0x80]
0000777bb65dbf5b  vmovaps [rsp+0x80], xmm14
0000777bb65dbf64  movaps xmm1, xmm15
0000777bb65dbf68  mulpd xmm1, xmm9
0000777bb65dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
0000777bb65dbf72  ptest xmm14, xmm14
0000777bb65dbf78  jnz 0x0000777BB65DDC72
0000777bb65dbf7e  lea r12, [rax+0x90]
0000777bb65dbf85  movups xmm15, [r13+r12*1]
0000777bb65dbf8b  vmovaps xmm14, [rsp+0xD0]
0000777bb65dbf94  vmovaps xmm9, [rsp+0xD0]
0000777bb65dbf9d  por xmm14, xmm9
0000777bb65dbfa2  movaps [r15+0x1C0], xmm14
0000777bb65dbfaa  vmovaps xmm9, [rsp+0xC0]
0000777bb65dbfb3  vmovaps [rsp+0xD0], xmm1
0000777bb65dbfbc  vmovaps xmm1, [rsp+0xC0]
0000777bb65dbfc5  por xmm9, xmm1
0000777bb65dbfca  movaps [r15+0x200], xmm9
0000777bb65dbfd2  vmovaps [rsp+0xC0], xmm2
0000777bb65dbfdb  vmovaps xmm1, [rsp+0xC0]
0000777bb65dbfe4  por xmm2, xmm1
0000777bb65dbfe8  movaps [r15+0x2D0], xmm2
0000777bb65dbff0  vmovaps [rsp+0xC0], xmm8
0000777bb65dbff9  vmovaps xmm1, [rsp+0xC0]
0000777bb65dc002  por xmm8, xmm1
0000777bb65dc007  movaps [r15+0x2E0], xmm8
0000777bb65dc00f  vmovaps [rsp+0xC0], xmm15
0000777bb65dc018  movaps xmm1, xmm5
0000777bb65dc01b  addpd xmm1, xmm7
0000777bb65dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
0000777bb65dc024  ptest xmm15, xmm15
0000777bb65dc02a  jnz 0x0000777BB65DDDBE
0000777bb65dc030  vmovaps xmm15, [rsp+0x50]
0000777bb65dc036  vpermilpd xmm15, xmm15, 0x00
0000777bb65dc03c  vmovaps xmm5, [rsp+0xC0]
0000777bb65dc045  vmovaps [rsp+0xC0], xmm1
0000777bb65dc04e  movaps xmm7, xmm5
0000777bb65dc051  mulpd xmm7, xmm15
0000777bb65dc056  vcmppd xmm1, xmm7, xmm7, 0x03
0000777bb65dc05b  ptest xmm1, xmm1
0000777bb65dc060  jnz 0x0000777BB65DDEFE
0000777bb65dc066  lea r12, [rax+0x80]
0000777bb65dc06d  movups xmm1, [r13+r12*1]
0000777bb65dc073  vmovaps xmm5, [rsp+0x70]
0000777bb65dc079  vmovaps [rsp+0x70], xmm1
0000777bb65dc07f  movaps xmm15, xmm5
0000777bb65dc083  addpd xmm15, xmm3
0000777bb65dc088  vcmppd xmm1, xmm15, xmm15, 0x03
0000777bb65dc08e  ptest xmm1, xmm1
0000777bb65dc093  jnz 0x0000777BB65DE049
0000777bb65dc099  vmovaps xmm5, [rsp+0x80]
0000777bb65dc0a2  movaps xmm1, xmm5
0000777bb65dc0a5  addpd xmm1, xmm4
0000777bb65dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
0000777bb65dc0ae  ptest xmm3, xmm3
0000777bb65dc0b3  jnz 0x0000777BB65DE18B
0000777bb65dc0b9  vmovaps [rsp+0x80], xmm10
0000777bb65dc0c2  vmovaps xmm5, [rsp+0x80]
0000777bb65dc0cb  por xmm10, xmm5
0000777bb65dc0d0  movaps [r15+0x2F0], xmm10
0000777bb65dc0d8  vmovaps xmm5, [rsp+0x50]
0000777bb65dc0de  vpermilpd xmm5, xmm5, 0x00
0000777bb65dc0e4  vmovaps xmm3, [rsp+0x70]
0000777bb65dc0ea  vmovaps [rsp+0x50], xmm1
0000777bb65dc0f0  movaps xmm4, xmm3
0000777bb65dc0f3  mulpd xmm4, xmm5
0000777bb65dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
0000777bb65dc0fc  ptest xmm1, xmm1
0000777bb65dc101  jnz 0x0000777BB65DE2CB
0000777bb65dc107  lea r12, [rax+0xD0]
0000777bb65dc10e  movups xmm1, [r13+r12*1]
0000777bb65dc114  vmovaps xmm3, [rsp+0xD0]
0000777bb65dc11d  vmovaps [rsp+0x70], xmm1
0000777bb65dc123  movaps xmm5, xmm6
0000777bb65dc126  addpd xmm5, xmm3
0000777bb65dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
0000777bb65dc12f  ptest xmm1, xmm1
0000777bb65dc134  jnz 0x0000777BB65DE415
0000777bb65dc13a  vmovaps xmm1, [rsp+0x60]
0000777bb65dc140  vpermilpd xmm1, xmm1, 0x00
0000777bb65dc146  movaps xmm6, xmm9
0000777bb65dc14a  mulpd xmm6, xmm1
0000777bb65dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
0000777bb65dc153  ptest xmm3, xmm3
0000777bb65dc158  jnz 0x0000777BB65DE555
0000777bb65dc15e  movaps [r15+0x260], xmm6
0000777bb65dc166  vxorps xmm1, xmm1, xmm1
0000777bb65dc16a  vpbroadcastq xmm1, xmm1
0000777bb65dc16f  movaps [r15+0x1B0], xmm1
0000777bb65dc177  vmovaps xmm1, [rsp+0x60]
0000777bb65dc17d  vpermilpd xmm1, xmm1, 0x00
0000777bb65dc183  vmovaps xmm3, [rsp+0x70]
0000777bb65dc189  vmovaps [rsp+0x70], xmm15
0000777bb65dc18f  movaps xmm9, xmm3
0000777bb65dc193  mulpd xmm9, xmm1
0000777bb65dc198  vcmppd xmm15, xmm9, xmm9, 0x03
0000777bb65dc19e  ptest xmm15, xmm15
0000777bb65dc1a4  jnz 0x0000777BB65DE696
0000777bb65dc1aa  lea r12, [rax+0xC0]
0000777bb65dc1b1  movups xmm1, [r13+r12*1]
0000777bb65dc1b7  vmovaps xmm3, [rsp+0xC0]
0000777bb65dc1c0  vmovaps [rsp+0x80], xmm1
0000777bb65dc1c9  movaps xmm15, xmm3
0000777bb65dc1cd  addpd xmm15, xmm7
0000777bb65dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
0000777bb65dc1d8  ptest xmm1, xmm1
0000777bb65dc1dd  jnz 0x0000777BB65DE7E2
0000777bb65dc1e3  vmovaps [rsp+0xC0], xmm13
0000777bb65dc1ec  vmovaps xmm1, [rsp+0xC0]
0000777bb65dc1f5  por xmm13, xmm1
0000777bb65dc1fa  movaps [r15+0x270], xmm13
0000777bb65dc202  vmovaps xmm1, [rsp+0xB0]
0000777bb65dc20b  vmovaps xmm7, [rsp+0xB0]
0000777bb65dc214  por xmm1, xmm7
0000777bb65dc218  movaps [r15+0x1A0], xmm1
0000777bb65dc220  vmovaps xmm1, [rsp+0x60]
0000777bb65dc226  vpermilpd xmm1, xmm1, 0x00
0000777bb65dc22c  vmovaps [rsp+0xB0], xmm1
0000777bb65dc235  vmovaps xmm1, [rsp+0x80]
0000777bb65dc23e  vmovaps [rsp+0x80], xmm15
0000777bb65dc247  vmovaps xmm15, [rsp+0xB0]
0000777bb65dc250  vmovaps [rsp+0xB0], xmm14
0000777bb65dc259  movaps xmm3, xmm1
0000777bb65dc25c  mulpd xmm3, xmm15
0000777bb65dc261  vcmppd xmm14, xmm3, xmm3, 0x03
0000777bb65dc266  ptest xmm14, xmm14
0000777bb65dc26c  jnz 0x0000777BB65DE924
0000777bb65dc272  lea r12, [rax+0x20]
0000777bb65dc276  movups xmm1, [r13+r12*1]
0000777bb65dc27c  movaps [r15+0x110], xmm1
0000777bb65dc284  vmovaps xmm14, [rsp+0x70]
0000777bb65dc28a  vmovaps [rsp+0x70], xmm1
0000777bb65dc290  movaps xmm15, xmm14
0000777bb65dc294  addpd xmm15, xmm4
0000777bb65dc299  vcmppd xmm1, xmm15, xmm15, 0x03
0000777bb65dc29f  ptest xmm1, xmm1
0000777bb65dc2a4  jnz 0x0000777BB65DEA6F
0000777bb65dc2aa  vmovaps xmm1, [rsp+0x60]
0000777bb65dc2b0  vpermilpd xmm1, xmm1, 0x00
0000777bb65dc2b6  movaps xmm14, xmm2
0000777bb65dc2ba  mulpd xmm14, xmm1
0000777bb65dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
0000777bb65dc2c5  ptest xmm4, xmm4
0000777bb65dc2ca  jnz 0x0000777BB65DEBB2
0000777bb65dc2d0  vmovaps xmm4, [rsp+0x50]
0000777bb65dc2d6  movaps xmm1, xmm4
0000777bb65dc2d9  addpd xmm1, xmm9
0000777bb65dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
0000777bb65dc2e3  ptest xmm2, xmm2
0000777bb65dc2e8  jnz 0x0000777BB65DECF4
0000777bb65dc2ee  vmovaps xmm9, [rsp+0x30]
0000777bb65dc2f4  vpermilpd xmm9, xmm9, 0x00
0000777bb65dc2fa  vmovaps xmm2, [rsp+0x70]
0000777bb65dc300  vmovaps [rsp+0x50], xmm1
0000777bb65dc306  movaps xmm4, xmm2
0000777bb65dc309  mulpd xmm4, xmm9
0000777bb65dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
0000777bb65dc313  ptest xmm1, xmm1
0000777bb65dc318  jnz 0x0000777BB65DEE35
0000777bb65dc31e  vmovaps xmm1, [rsp+0x30]
0000777bb65dc324  vpermilpd xmm1, xmm1, 0x00
0000777bb65dc32a  vmovaps xmm2, [rsp+0x90]
0000777bb65dc333  vmovaps [rsp+0x60], xmm15
0000777bb65dc339  movaps xmm9, xmm2
0000777bb65dc33d  mulpd xmm9, xmm1
0000777bb65dc342  vcmppd xmm15, xmm9, xmm9, 0x03
0000777bb65dc348  ptest xmm15, xmm15
0000777bb65dc34e  jnz 0x0000777BB65DEF76
0000777bb65dc354  vmovaps xmm15, [rsp+0x80]
0000777bb65dc35d  movaps xmm1, xmm15
0000777bb65dc361  addpd xmm1, xmm6
0000777bb65dc365  vcmppd xmm2, xmm1, xmm1, 0x03
0000777bb65dc36a  ptest xmm2, xmm2
0000777bb65dc36f  jnz 0x0000777BB65DF0B8
0000777bb65dc375  movaps xmm15, xmm5
0000777bb65dc379  addpd xmm15, xmm3
0000777bb65dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
0000777bb65dc384  ptest xmm6, xmm6
0000777bb65dc389  jnz 0x0000777BB65DF1F9
0000777bb65dc38f  vmovaps xmm6, [rsp+0x30]
0000777bb65dc395  vpermilpd xmm6, xmm6, 0x00
0000777bb65dc39b  movaps xmm5, xmm8
0000777bb65dc39f  mulpd xmm5, xmm6
0000777bb65dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
0000777bb65dc3a8  ptest xmm3, xmm3
0000777bb65dc3ad  jnz 0x0000777BB65DF33B
0000777bb65dc3b3  vmovaps xmm8, [rsp+0x30]
0000777bb65dc3b9  vpermilpd xmm8, xmm8, 0x00
0000777bb65dc3bf  movaps xmm6, xmm10
0000777bb65dc3c3  mulpd xmm6, xmm8
0000777bb65dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
0000777bb65dc3cd  ptest xmm3, xmm3
0000777bb65dc3d2  jnz 0x0000777BB65DF47C
0000777bb65dc3d8  vmovaps xmm8, [rsp+0x60]
0000777bb65dc3de  movaps xmm10, xmm8
0000777bb65dc3e2  addpd xmm10, xmm14
0000777bb65dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
0000777bb65dc3ed  ptest xmm3, xmm3
0000777bb65dc3f2  jnz 0x0000777BB65DF5BE
0000777bb65dc3f8  vmovaps xmm8, [rsp+0x50]
0000777bb65dc3fe  movaps xmm14, xmm8
0000777bb65dc402  addpd xmm14, xmm4
0000777bb65dc407  vcmppd xmm3, xmm14, xmm14, 0x03
0000777bb65dc40d  ptest xmm3, xmm3
0000777bb65dc412  jnz 0x0000777BB65DF702
0000777bb65dc418  vmovaps xmm8, [rsp+0x40]
0000777bb65dc41e  vpermilpd xmm8, xmm8, 0x00
0000777bb65dc424  movaps xmm4, xmm13
0000777bb65dc428  mulpd xmm4, xmm8
0000777bb65dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
0000777bb65dc432  ptest xmm3, xmm3
0000777bb65dc437  jnz 0x0000777BB65DF845
0000777bb65dc43d  movaps xmm13, xmm15
0000777bb65dc441  addpd xmm13, xmm9
0000777bb65dc446  vcmppd xmm8, xmm13, xmm13, 0x03
0000777bb65dc44c  ptest xmm8, xmm8
0000777bb65dc452  jnz 0x0000777BB65DF987
0000777bb65dc458  movaps xmm15, xmm1
0000777bb65dc45c  addpd xmm15, xmm5
0000777bb65dc461  vcmppd xmm9, xmm15, xmm15, 0x03
0000777bb65dc467  ptest xmm9, xmm9
0000777bb65dc46d  jnz 0x0000777BB65DFACB
0000777bb65dc473  vmovaps [rsp+0x30], xmm11
0000777bb65dc479  vmovaps xmm1, [rsp+0x30]
0000777bb65dc47f  por xmm11, xmm1
0000777bb65dc484  movaps [r15+0x250], xmm11
0000777bb65dc48c  vmovaps [rsp+0x30], xmm12
0000777bb65dc492  vmovaps xmm1, [rsp+0x30]
0000777bb65dc498  por xmm12, xmm1
0000777bb65dc49d  movaps [r15+0x2A0], xmm12
0000777bb65dc4a5  vmovaps xmm1, [rsp+0xA0]
0000777bb65dc4ae  vmovaps xmm11, [rsp+0xA0]
0000777bb65dc4b7  por xmm1, xmm11
0000777bb65dc4bc  movaps [r15+0x1D0], xmm1
0000777bb65dc4c4  lea r12, [rax+0x40]
0000777bb65dc4c8  movups xmm1, [r13+r12*1]
0000777bb65dc4ce  movaps [r15+0x2C0], xmm1
0000777bb65dc4d6  vmovaps xmm11, [rsp+0x40]
0000777bb65dc4dc  vpermilpd xmm11, xmm11, 0x00
0000777bb65dc4e2  vmovaps xmm8, [rsp+0xE0]
0000777bb65dc4eb  movaps xmm9, xmm8
0000777bb65dc4ef  mulpd xmm9, xmm11
0000777bb65dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
0000777bb65dc4fa  ptest xmm5, xmm5
0000777bb65dc4ff  jnz 0x0000777BB65DFC17
0000777bb65dc505  movaps xmm11, xmm10
0000777bb65dc509  addpd xmm11, xmm6
0000777bb65dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
0000777bb65dc514  ptest xmm8, xmm8
0000777bb65dc51a  jnz 0x0000777BB65DFD5B
0000777bb65dc520  movaps xmm10, xmm14
0000777bb65dc524  addpd xmm10, xmm4
0000777bb65dc529  vcmppd xmm8, xmm10, xmm10, 0x03
0000777bb65dc52f  ptest xmm8, xmm8
0000777bb65dc535  jnz 0x0000777BB65DFE9E
0000777bb65dc53b  vmovaps xmm14, [rsp+0x40]
0000777bb65dc541  vpermilpd xmm14, xmm14, 0x00
0000777bb65dc547  movaps xmm8, xmm1
0000777bb65dc54b  mulpd xmm8, xmm14
0000777bb65dc550  vcmppd xmm6, xmm8, xmm8, 0x03
0000777bb65dc556  ptest xmm6, xmm6
0000777bb65dc55b  jnz 0x0000777BB65DFFE1
0000777bb65dc561  movaps xmm1, [r15+0x2B0]
0000777bb65dc569  vmovaps xmm14, [rsp+0x40]
0000777bb65dc56f  vpermilpd xmm14, xmm14, 0x00
0000777bb65dc575  movaps xmm6, xmm1
0000777bb65dc578  mulpd xmm6, xmm14
0000777bb65dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
0000777bb65dc582  ptest xmm5, xmm5
0000777bb65dc587  jnz 0x0000777BB65E0124
0000777bb65dc58d  vmovaps xmm1, [rsp+0x10]
0000777bb65dc593  vpermilpd xmm1, xmm1, 0x00
0000777bb65dc599  movaps xmm14, xmm12
0000777bb65dc59d  mulpd xmm14, xmm1
0000777bb65dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
0000777bb65dc5a8  ptest xmm5, xmm5
0000777bb65dc5ad  jnz 0x0000777BB65E0265
0000777bb65dc5b3  movaps xmm1, xmm13
0000777bb65dc5b7  addpd xmm1, xmm9
0000777bb65dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
0000777bb65dc5c1  ptest xmm12, xmm12
0000777bb65dc5c7  jnz 0x0000777BB65E03A8
0000777bb65dc5cd  vmovaps xmm13, [rsp+0x10]
0000777bb65dc5d3  vpermilpd xmm13, xmm13, 0x00
0000777bb65dc5d9  movaps xmm12, xmm7
0000777bb65dc5dd  mulpd xmm12, xmm13
0000777bb65dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
0000777bb65dc5e8  ptest xmm9, xmm9
0000777bb65dc5ee  jnz 0x0000777BB65E04EA
0000777bb65dc5f4  movaps xmm13, xmm15
0000777bb65dc5f8  addpd xmm13, xmm8
0000777bb65dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
0000777bb65dc603  ptest xmm9, xmm9
0000777bb65dc609  jnz 0x0000777BB65E062D
0000777bb65dc60f  movaps xmm15, [r15+0x290]
0000777bb65dc617  vmovaps xmm9, [rsp+0x10]
0000777bb65dc61d  vpermilpd xmm9, xmm9, 0x00
0000777bb65dc623  movaps xmm8, xmm15
0000777bb65dc627  mulpd xmm8, xmm9
0000777bb65dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
0000777bb65dc632  ptest xmm7, xmm7
0000777bb65dc637  jnz 0x0000777BB65E0771
0000777bb65dc63d  movaps xmm15, xmm11
0000777bb65dc641  addpd xmm15, xmm6
0000777bb65dc646  vcmppd xmm9, xmm15, xmm15, 0x03
0000777bb65dc64c  ptest xmm9, xmm9
0000777bb65dc652  jnz 0x0000777BB65E08B5
0000777bb65dc658  movaps xmm11, [r15+0x1E0]
0000777bb65dc660  vmovaps xmm9, [rsp+0x10]
0000777bb65dc666  vpermilpd xmm9, xmm9, 0x00
0000777bb65dc66c  movaps xmm7, xmm11
0000777bb65dc670  mulpd xmm7, xmm9
0000777bb65dc675  vcmppd xmm6, xmm7, xmm7, 0x03
0000777bb65dc67a  ptest xmm6, xmm6
0000777bb65dc67f  jnz 0x0000777BB65E09F8
0000777bb65dc685  movaps xmm11, xmm10
0000777bb65dc689  addpd xmm11, xmm14
0000777bb65dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
0000777bb65dc694  ptest xmm9, xmm9
0000777bb65dc69a  jnz 0x0000777BB65E0B3A
0000777bb65dc6a0  lea r12, [rax+0x70]
0000777bb65dc6a4  movups xmm14, [r13+r12*1]
0000777bb65dc6aa  movaps [r15+0x240], xmm14
0000777bb65dc6b2  movaps xmm10, xmm1
0000777bb65dc6b6  addpd xmm10, xmm12
0000777bb65dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
0000777bb65dc6c1  ptest xmm9, xmm9
0000777bb65dc6c7  jnz 0x0000777BB65E0C88
0000777bb65dc6cd  movaps [r15+0x170], xmm10
0000777bb65dc6d5  vmovaps xmm1, [rsp+0x20]
0000777bb65dc6db  vpermilpd xmm1, xmm1, 0x00
0000777bb65dc6e1  movaps xmm12, xmm14
0000777bb65dc6e5  mulpd xmm12, xmm1
0000777bb65dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
0000777bb65dc6f0  ptest xmm9, xmm9
0000777bb65dc6f6  jnz 0x0000777BB65E0DCB
0000777bb65dc6fc  vmovaps xmm1, [rsp+0x20]
0000777bb65dc702  vpermilpd xmm1, xmm1, 0x00
0000777bb65dc708  vmovaps xmm9, [rsp+0xB0]
0000777bb65dc711  movaps xmm14, xmm9
0000777bb65dc715  mulpd xmm14, xmm1
0000777bb65dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
0000777bb65dc720  ptest xmm6, xmm6
0000777bb65dc725  jnz 0x0000777BB65E0F0E
0000777bb65dc72b  movaps [r15+0x180], xmm14
0000777bb65dc733  movaps xmm1, xmm13
0000777bb65dc737  addpd xmm1, xmm8
0000777bb65dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
0000777bb65dc741  ptest xmm9, xmm9
0000777bb65dc747  jnz 0x0000777BB65E1051
0000777bb65dc74d  movaps [r15+0x210], xmm1
0000777bb65dc755  movups xmm13, [r13+rax*1]
0000777bb65dc75b  lea r12, [rax+0x10]
0000777bb65dc75f  movups xmm9, [r13+r12*1]
0000777bb65dc765  movaps [r15+0x230], xmm9
0000777bb65dc76d  movaps xmm8, xmm15
0000777bb65dc771  addpd xmm8, xmm7
0000777bb65dc776  vcmppd xmm6, xmm8, xmm8, 0x03
0000777bb65dc77c  ptest xmm6, xmm6
0000777bb65dc781  jnz 0x0000777BB65E11A7
0000777bb65dc787  movaps [r15+0x130], xmm8
0000777bb65dc78f  vmovaps xmm15, [rsp+0x20]
0000777bb65dc795  vpermilpd xmm15, xmm15, 0x00
0000777bb65dc79b  movaps xmm7, xmm9
0000777bb65dc79f  mulpd xmm7, xmm15
0000777bb65dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
0000777bb65dc7a9  ptest xmm6, xmm6
0000777bb65dc7ae  jnz 0x0000777BB65E12EA
0000777bb65dc7b4  movaps [r15+0x220], xmm7
0000777bb65dc7bc  vmovaps xmm15, [rsp+0x20]
0000777bb65dc7c2  vpermilpd xmm15, xmm15, 0x00
0000777bb65dc7c8  movaps xmm9, xmm13
0000777bb65dc7cc  mulpd xmm9, xmm15
0000777bb65dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
0000777bb65dc7d7  ptest xmm6, xmm6
0000777bb65dc7dc  jnz 0x0000777BB65E142C
0000777bb65dc7e2  movaps xmm15, xmm11
0000777bb65dc7e6  addpd xmm15, xmm12
0000777bb65dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
0000777bb65dc7f1  ptest xmm13, xmm13
0000777bb65dc7f7  jnz 0x0000777BB65E1570
0000777bb65dc7fd  movaps [r15+0x140], xmm15
0000777bb65dc805  movaps xmm13, xmm10
0000777bb65dc809  addpd xmm13, xmm14
0000777bb65dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
0000777bb65dc814  ptest xmm12, xmm12
0000777bb65dc81a  jnz 0x0000777BB65E16B4
0000777bb65dc820  movaps [r15+0x150], xmm13
0000777bb65dc828  movaps xmm14, xmm1
0000777bb65dc82c  addpd xmm14, xmm7
0000777bb65dc831  vcmppd xmm12, xmm14, xmm14, 0x03
0000777bb65dc837  ptest xmm12, xmm12
0000777bb65dc83d  jnz 0x0000777BB65E17F8
0000777bb65dc843  movaps [r15+0x160], xmm14
0000777bb65dc84b  movaps xmm1, xmm8
0000777bb65dc84f  addpd xmm1, xmm9
0000777bb65dc854  vcmppd xmm12, xmm1, xmm1, 0x03
0000777bb65dc859  ptest xmm12, xmm12
0000777bb65dc85f  jnz 0x0000777BB65E193A
0000777bb65dc865  movaps [r15+0x120], xmm1
0000777bb65dc86d  movups [r13+r14*1], xmm15
0000777bb65dc873  lea rax, [r14+0x10]
0000777bb65dc877  movups [r13+rax*1], xmm13
0000777bb65dc87d  lea rax, [r14+0x20]
0000777bb65dc881  movups [r13+rax*1], xmm14
0000777bb65dc887  lea rax, [r14+0x30]
0000777bb65dc88b  movups [r13+rax*1], xmm1
0000777bb65dc891  mov eax, [r15+0x108]
0000777bb65dc898  sahf
0000777bb65dc899  jnz 0x0000777BB65DC8CB
0000777bb65dc89b  cmp dword ptr [r15+0x318], 0x00
0000777bb65dc8a3  jz 0x0000777BB65DB900
0000777bb65dc8a9  nop [rax+rax*1], ax
0000777bb65dc8b2  nop [rax+rax*1], eax
0000777bb65dc8ba  mov eax, 0x410444
0000777bb65dc8bf  mov [r15+0x100], rax
0000777bb65dc8c6  jmp 0x0000777BB63FE110
0000777bb65dc8cb  cmp dword ptr [r15+0x318], 0x00
0000777bb65dc8d3  jz 0x0000777BB65D57E0
0000777bb65dc8d9  nop [rax+rax*1], ax
0000777bb65dc8e2  nop [rax+rax*1], eax
0000777bb65dc8ea  mov eax, 0x410278
0000777bb65dc8ef  mov [r15+0x100], rax
0000777bb65dc8f6  jmp 0x0000777BB63FE110
0000777bb65dc8fb  int3
0000777bb65dc8fc  call 0x0000777BB64E27E0
0000777bb65dc901  jmp 0x0000777BB65DB9DF
0000777bb65dc906  call 0x0000777BB64E1570
0000777bb65dc90b  jmp 0x0000777BB65DB9E8
0000777bb65dc910  call 0x0000777BB64E27E0
0000777bb65dc915  jmp 0x0000777BB65DBA44
0000777bb65dc91a  call 0x0000777BB64E1570
0000777bb65dc91f  jmp 0x0000777BB65DBA4D
0000777bb65dc924  call 0x0000777BB64E27E0
0000777bb65dc929  jmp 0x0000777BB65DBA90
0000777bb65dc92e  call 0x0000777BB64E1570
0000777bb65dc933  jmp 0x0000777BB65DBA99
0000777bb65dc938  call 0x0000777BB640DC20
0000777bb65dc93d  jmp 0x0000777BB65DBAD8
0000777bb65dc942  call 0x0000777BB64D59C0
0000777bb65dc947  jmp 0x0000777BB65DBAEB
0000777bb65dc94c  call 0x0000777BB64E0E30
0000777bb65dc951  jmp 0x0000777BB65DBB09
0000777bb65dc956  call 0x0000777BB64DFBC0
0000777bb65dc95b  jmp 0x0000777BB65DBB13
0000777bb65dc960  call 0x0000777BB64DE950
0000777bb65dc965  jmp 0x0000777BB65DBB1D
0000777bb65dc96a  sub rsp, 0x08
0000777bb65dc96e  push rax
0000777bb65dc96f  push rcx
0000777bb65dc970  push rdx
0000777bb65dc971  push rdi
0000777bb65dc972  push rsi
0000777bb65dc973  push r8
0000777bb65dc975  push r9
0000777bb65dc977  push r10
0000777bb65dc979  push r11
0000777bb65dc97b  sub rsp, 0xF0
0000777bb65dc982  vmovaps [rsp], xmm0
0000777bb65dc987  vmovaps [rsp+0x10], xmm1
0000777bb65dc98d  vmovaps [rsp+0x20], xmm2
0000777bb65dc993  vmovaps [rsp+0x30], xmm3
0000777bb65dc999  vmovaps [rsp+0x40], xmm4
0000777bb65dc99f  vmovaps [rsp+0x50], xmm5
0000777bb65dc9a5  vmovaps [rsp+0x60], xmm6
0000777bb65dc9ab  vmovaps [rsp+0x70], xmm7
0000777bb65dc9b1  vmovaps [rsp+0x80], xmm9
0000777bb65dc9ba  vmovaps [rsp+0x90], xmm10
0000777bb65dc9c3  vmovaps [rsp+0xA0], xmm11
0000777bb65dc9cc  vmovaps [rsp+0xB0], xmm12
0000777bb65dc9d5  vmovaps [rsp+0xC0], xmm13
0000777bb65dc9de  vmovaps [rsp+0xD0], xmm14
0000777bb65dc9e7  vmovaps [rsp+0xE0], xmm15
0000777bb65dc9f0  sub rsp, 0x30
0000777bb65dc9f4  movaps [rsp], xmm8
0000777bb65dc9f9  movaps [rsp+0x10], xmm12
0000777bb65dc9ff  movaps [rsp+0x20], xmm15
0000777bb65dca05  lea rdi, [rsp]
0000777bb65dca09  mov esi, 0x00
0000777bb65dca0e  mov rax, 0x569DC437B530
0000777bb65dca18  call rax
0000777bb65dca1a  movaps xmm8, [rsp]
0000777bb65dca1f  add rsp, 0x30
0000777bb65dca23  vmovaps xmm0, [rsp]
0000777bb65dca28  vmovaps xmm1, [rsp+0x10]
0000777bb65dca2e  vmovaps xmm2, [rsp+0x20]
0000777bb65dca34  vmovaps xmm3, [rsp+0x30]
0000777bb65dca3a  vmovaps xmm4, [rsp+0x40]
0000777bb65dca40  vmovaps xmm5, [rsp+0x50]
0000777bb65dca46  vmovaps xmm6, [rsp+0x60]
0000777bb65dca4c  vmovaps xmm7, [rsp+0x70]
0000777bb65dca52  vmovaps xmm9, [rsp+0x80]
0000777bb65dca5b  vmovaps xmm10, [rsp+0x90]
0000777bb65dca64  vmovaps xmm11, [rsp+0xA0]
0000777bb65dca6d  vmovaps xmm12, [rsp+0xB0]
0000777bb65dca76  vmovaps xmm13, [rsp+0xC0]
0000777bb65dca7f  vmovaps xmm14, [rsp+0xD0]
0000777bb65dca88  vmovaps xmm15, [rsp+0xE0]
0000777bb65dca91  add rsp, 0xF0
0000777bb65dca98  pop r11
0000777bb65dca9a  pop r10
0000777bb65dca9c  pop r9
0000777bb65dca9e  pop r8
0000777bb65dcaa0  pop rsi
0000777bb65dcaa1  pop rdi
0000777bb65dcaa2  pop rdx
0000777bb65dcaa3  pop rcx
0000777bb65dcaa4  pop rax
0000777bb65dcaa5  add rsp, 0x08
0000777bb65dcaa9  jmp 0x0000777BB65DBB47
0000777bb65dcaae  sub rsp, 0x08
0000777bb65dcab2  push rax
0000777bb65dcab3  push rcx
0000777bb65dcab4  push rdx
0000777bb65dcab5  push rdi
0000777bb65dcab6  push rsi
0000777bb65dcab7  push r8
0000777bb65dcab9  push r9
0000777bb65dcabb  push r10
0000777bb65dcabd  push r11
0000777bb65dcabf  sub rsp, 0xF0
0000777bb65dcac6  vmovaps [rsp], xmm0
0000777bb65dcacb  vmovaps [rsp+0x10], xmm1
0000777bb65dcad1  vmovaps [rsp+0x20], xmm2
0000777bb65dcad7  vmovaps [rsp+0x30], xmm3
0000777bb65dcadd  vmovaps [rsp+0x40], xmm4
0000777bb65dcae3  vmovaps [rsp+0x50], xmm5
0000777bb65dcae9  vmovaps [rsp+0x60], xmm6
0000777bb65dcaef  vmovaps [rsp+0x70], xmm8
0000777bb65dcaf5  vmovaps [rsp+0x80], xmm9
0000777bb65dcafe  vmovaps [rsp+0x90], xmm10
0000777bb65dcb07  vmovaps [rsp+0xA0], xmm11
0000777bb65dcb10  vmovaps [rsp+0xB0], xmm12
0000777bb65dcb19  vmovaps [rsp+0xC0], xmm13
0000777bb65dcb22  vmovaps [rsp+0xD0], xmm14
0000777bb65dcb2b  vmovaps [rsp+0xE0], xmm15
0000777bb65dcb34  sub rsp, 0x30
0000777bb65dcb38  movaps [rsp], xmm7
0000777bb65dcb3c  movaps [rsp+0x10], xmm9
0000777bb65dcb42  movaps [rsp+0x20], xmm15
0000777bb65dcb48  lea rdi, [rsp]
0000777bb65dcb4c  mov esi, 0x00
0000777bb65dcb51  mov rax, 0x569DC437B530
0000777bb65dcb5b  call rax
0000777bb65dcb5d  movaps xmm7, [rsp]
0000777bb65dcb61  add rsp, 0x30
0000777bb65dcb65  vmovaps xmm0, [rsp]
0000777bb65dcb6a  vmovaps xmm1, [rsp+0x10]
0000777bb65dcb70  vmovaps xmm2, [rsp+0x20]
0000777bb65dcb76  vmovaps xmm3, [rsp+0x30]
0000777bb65dcb7c  vmovaps xmm4, [rsp+0x40]
0000777bb65dcb82  vmovaps xmm5, [rsp+0x50]
0000777bb65dcb88  vmovaps xmm6, [rsp+0x60]
0000777bb65dcb8e  vmovaps xmm8, [rsp+0x70]
0000777bb65dcb94  vmovaps xmm9, [rsp+0x80]
0000777bb65dcb9d  vmovaps xmm10, [rsp+0x90]
0000777bb65dcba6  vmovaps xmm11, [rsp+0xA0]
0000777bb65dcbaf  vmovaps xmm12, [rsp+0xB0]
0000777bb65dcbb8  vmovaps xmm13, [rsp+0xC0]
0000777bb65dcbc1  vmovaps xmm14, [rsp+0xD0]
0000777bb65dcbca  vmovaps xmm15, [rsp+0xE0]
0000777bb65dcbd3  add rsp, 0xF0
0000777bb65dcbda  pop r11
0000777bb65dcbdc  pop r10
0000777bb65dcbde  pop r9
0000777bb65dcbe0  pop r8
0000777bb65dcbe2  pop rsi
0000777bb65dcbe3  pop rdi
0000777bb65dcbe4  pop rdx
0000777bb65dcbe5  pop rcx
0000777bb65dcbe6  pop rax
0000777bb65dcbe7  add rsp, 0x08
0000777bb65dcbeb  jmp 0x0000777BB65DBB75
0000777bb65dcbf0  sub rsp, 0x08
0000777bb65dcbf4  push rax
0000777bb65dcbf5  push rcx
0000777bb65dcbf6  push rdx
0000777bb65dcbf7  push rdi
0000777bb65dcbf8  push rsi
0000777bb65dcbf9  push r8
0000777bb65dcbfb  push r9
0000777bb65dcbfd  push r10
0000777bb65dcbff  push r11
0000777bb65dcc01  sub rsp, 0xF0
0000777bb65dcc08  vmovaps [rsp], xmm0
0000777bb65dcc0d  vmovaps [rsp+0x10], xmm1
0000777bb65dcc13  vmovaps [rsp+0x20], xmm2
0000777bb65dcc19  vmovaps [rsp+0x30], xmm3
0000777bb65dcc1f  vmovaps [rsp+0x40], xmm4
0000777bb65dcc25  vmovaps [rsp+0x50], xmm5
0000777bb65dcc2b  vmovaps [rsp+0x60], xmm6
0000777bb65dcc31  vmovaps [rsp+0x70], xmm7
0000777bb65dcc37  vmovaps [rsp+0x80], xmm8
0000777bb65dcc40  vmovaps [rsp+0x90], xmm10
0000777bb65dcc49  vmovaps [rsp+0xA0], xmm11
0000777bb65dcc52  vmovaps [rsp+0xB0], xmm12
0000777bb65dcc5b  vmovaps [rsp+0xC0], xmm13
0000777bb65dcc64  vmovaps [rsp+0xD0], xmm14
0000777bb65dcc6d  vmovaps [rsp+0xE0], xmm15
0000777bb65dcc76  sub rsp, 0x30
0000777bb65dcc7a  movaps [rsp], xmm9
0000777bb65dcc7f  movaps [rsp+0x10], xmm12
0000777bb65dcc85  movaps [rsp+0x20], xmm10
0000777bb65dcc8b  lea rdi, [rsp]
0000777bb65dcc8f  mov esi, 0x00
0000777bb65dcc94  mov rax, 0x569DC437B530
0000777bb65dcc9e  call rax
0000777bb65dcca0  movaps xmm9, [rsp]
0000777bb65dcca5  add rsp, 0x30
0000777bb65dcca9  vmovaps xmm0, [rsp]
0000777bb65dccae  vmovaps xmm1, [rsp+0x10]
0000777bb65dccb4  vmovaps xmm2, [rsp+0x20]
0000777bb65dccba  vmovaps xmm3, [rsp+0x30]
0000777bb65dccc0  vmovaps xmm4, [rsp+0x40]
0000777bb65dccc6  vmovaps xmm5, [rsp+0x50]
0000777bb65dcccc  vmovaps xmm6, [rsp+0x60]
0000777bb65dccd2  vmovaps xmm7, [rsp+0x70]
0000777bb65dccd8  vmovaps xmm8, [rsp+0x80]
0000777bb65dcce1  vmovaps xmm10, [rsp+0x90]
0000777bb65dccea  vmovaps xmm11, [rsp+0xA0]
0000777bb65dccf3  vmovaps xmm12, [rsp+0xB0]
0000777bb65dccfc  vmovaps xmm13, [rsp+0xC0]
0000777bb65dcd05  vmovaps xmm14, [rsp+0xD0]
0000777bb65dcd0e  vmovaps xmm15, [rsp+0xE0]
0000777bb65dcd17  add rsp, 0xF0
0000777bb65dcd1e  pop r11
0000777bb65dcd20  pop r10
0000777bb65dcd22  pop r9
0000777bb65dcd24  pop r8
0000777bb65dcd26  pop rsi
0000777bb65dcd27  pop rdi
0000777bb65dcd28  pop rdx
0000777bb65dcd29  pop rcx
0000777bb65dcd2a  pop rax
0000777bb65dcd2b  add rsp, 0x08
0000777bb65dcd2f  jmp 0x0000777BB65DBB99
0000777bb65dcd34  sub rsp, 0x08
0000777bb65dcd38  push rax
0000777bb65dcd39  push rcx
0000777bb65dcd3a  push rdx
0000777bb65dcd3b  push rdi
0000777bb65dcd3c  push rsi
0000777bb65dcd3d  push r8
0000777bb65dcd3f  push r9
0000777bb65dcd41  push r10
0000777bb65dcd43  push r11
0000777bb65dcd45  sub rsp, 0xF0
0000777bb65dcd4c  vmovaps [rsp], xmm0
0000777bb65dcd51  vmovaps [rsp+0x10], xmm1
0000777bb65dcd57  vmovaps [rsp+0x20], xmm2
0000777bb65dcd5d  vmovaps [rsp+0x30], xmm3
0000777bb65dcd63  vmovaps [rsp+0x40], xmm4
0000777bb65dcd69  vmovaps [rsp+0x50], xmm5
0000777bb65dcd6f  vmovaps [rsp+0x60], xmm6
0000777bb65dcd75  vmovaps [rsp+0x70], xmm7
0000777bb65dcd7b  vmovaps [rsp+0x80], xmm8
0000777bb65dcd84  vmovaps [rsp+0x90], xmm9
0000777bb65dcd8d  vmovaps [rsp+0xA0], xmm11
0000777bb65dcd96  vmovaps [rsp+0xB0], xmm12
0000777bb65dcd9f  vmovaps [rsp+0xC0], xmm13
0000777bb65dcda8  vmovaps [rsp+0xD0], xmm14
0000777bb65dcdb1  vmovaps [rsp+0xE0], xmm15
0000777bb65dcdba  sub rsp, 0x30
0000777bb65dcdbe  movaps [rsp], xmm10
0000777bb65dcdc3  movaps [rsp+0x10], xmm12
0000777bb65dcdc9  movaps [rsp+0x20], xmm11
0000777bb65dcdcf  lea rdi, [rsp]
0000777bb65dcdd3  mov esi, 0x00
0000777bb65dcdd8  mov rax, 0x569DC437B530
0000777bb65dcde2  call rax
0000777bb65dcde4  movaps xmm10, [rsp]
0000777bb65dcde9  add rsp, 0x30
0000777bb65dcded  vmovaps xmm0, [rsp]
0000777bb65dcdf2  vmovaps xmm1, [rsp+0x10]
0000777bb65dcdf8  vmovaps xmm2, [rsp+0x20]
0000777bb65dcdfe  vmovaps xmm3, [rsp+0x30]
0000777bb65dce04  vmovaps xmm4, [rsp+0x40]
0000777bb65dce0a  vmovaps xmm5, [rsp+0x50]
0000777bb65dce10  vmovaps xmm6, [rsp+0x60]
0000777bb65dce16  vmovaps xmm7, [rsp+0x70]
0000777bb65dce1c  vmovaps xmm8, [rsp+0x80]
0000777bb65dce25  vmovaps xmm9, [rsp+0x90]
0000777bb65dce2e  vmovaps xmm11, [rsp+0xA0]
0000777bb65dce37  vmovaps xmm12, [rsp+0xB0]
0000777bb65dce40  vmovaps xmm13, [rsp+0xC0]
0000777bb65dce49  vmovaps xmm14, [rsp+0xD0]
0000777bb65dce52  vmovaps xmm15, [rsp+0xE0]
0000777bb65dce5b  add rsp, 0xF0
0000777bb65dce62  pop r11
0000777bb65dce64  pop r10
0000777bb65dce66  pop r9
0000777bb65dce68  pop r8
0000777bb65dce6a  pop rsi
0000777bb65dce6b  pop rdi
0000777bb65dce6c  pop rdx
0000777bb65dce6d  pop rcx
0000777bb65dce6e  pop rax
0000777bb65dce6f  add rsp, 0x08
0000777bb65dce73  jmp 0x0000777BB65DBBB3
0000777bb65dce78  sub rsp, 0x08
0000777bb65dce7c  push rax
0000777bb65dce7d  push rcx
0000777bb65dce7e  push rdx
0000777bb65dce7f  push rdi
0000777bb65dce80  push rsi
0000777bb65dce81  push r8
0000777bb65dce83  push r9
0000777bb65dce85  push r10
0000777bb65dce87  push r11
0000777bb65dce89  sub rsp, 0xF0
0000777bb65dce90  vmovaps [rsp], xmm0
0000777bb65dce95  vmovaps [rsp+0x10], xmm1
0000777bb65dce9b  vmovaps [rsp+0x20], xmm2
0000777bb65dcea1  vmovaps [rsp+0x30], xmm3
0000777bb65dcea7  vmovaps [rsp+0x40], xmm4
0000777bb65dcead  vmovaps [rsp+0x50], xmm5
0000777bb65dceb3  vmovaps [rsp+0x60], xmm7
0000777bb65dceb9  vmovaps [rsp+0x70], xmm8
0000777bb65dcebf  vmovaps [rsp+0x80], xmm9
0000777bb65dcec8  vmovaps [rsp+0x90], xmm10
0000777bb65dced1  vmovaps [rsp+0xA0], xmm11
0000777bb65dceda  vmovaps [rsp+0xB0], xmm12
0000777bb65dcee3  vmovaps [rsp+0xC0], xmm13
0000777bb65dceec  vmovaps [rsp+0xD0], xmm14
0000777bb65dcef5  vmovaps [rsp+0xE0], xmm15
0000777bb65dcefe  sub rsp, 0x30
0000777bb65dcf02  movaps [rsp], xmm6
0000777bb65dcf06  movaps [rsp+0x10], xmm12
0000777bb65dcf0c  movaps [rsp+0x20], xmm11
0000777bb65dcf12  lea rdi, [rsp]
0000777bb65dcf16  mov esi, 0x00
0000777bb65dcf1b  mov rax, 0x569DC437B530
0000777bb65dcf25  call rax
0000777bb65dcf27  movaps xmm6, [rsp]
0000777bb65dcf2b  add rsp, 0x30
0000777bb65dcf2f  vmovaps xmm0, [rsp]
0000777bb65dcf34  vmovaps xmm1, [rsp+0x10]
0000777bb65dcf3a  vmovaps xmm2, [rsp+0x20]
0000777bb65dcf40  vmovaps xmm3, [rsp+0x30]
0000777bb65dcf46  vmovaps xmm4, [rsp+0x40]
0000777bb65dcf4c  vmovaps xmm5, [rsp+0x50]
0000777bb65dcf52  vmovaps xmm7, [rsp+0x60]
0000777bb65dcf58  vmovaps xmm8, [rsp+0x70]
0000777bb65dcf5e  vmovaps xmm9, [rsp+0x80]
0000777bb65dcf67  vmovaps xmm10, [rsp+0x90]
0000777bb65dcf70  vmovaps xmm11, [rsp+0xA0]
0000777bb65dcf79  vmovaps xmm12, [rsp+0xB0]
0000777bb65dcf82  vmovaps xmm13, [rsp+0xC0]
0000777bb65dcf8b  vmovaps xmm14, [rsp+0xD0]
0000777bb65dcf94  vmovaps xmm15, [rsp+0xE0]
0000777bb65dcf9d  add rsp, 0xF0
0000777bb65dcfa4  pop r11
0000777bb65dcfa6  pop r10
0000777bb65dcfa8  pop r9
0000777bb65dcfaa  pop r8
0000777bb65dcfac  pop rsi
0000777bb65dcfad  pop rdi
0000777bb65dcfae  pop rdx
0000777bb65dcfaf  pop rcx
0000777bb65dcfb0  pop rax
0000777bb65dcfb1  add rsp, 0x08
0000777bb65dcfb5  jmp 0x0000777BB65DBBD4
0000777bb65dcfba  sub rsp, 0x08
0000777bb65dcfbe  push rax
0000777bb65dcfbf  push rcx
0000777bb65dcfc0  push rdx
0000777bb65dcfc1  push rdi
0000777bb65dcfc2  push rsi
0000777bb65dcfc3  push r8
0000777bb65dcfc5  push r9
0000777bb65dcfc7  push r10
0000777bb65dcfc9  push r11
0000777bb65dcfcb  sub rsp, 0xF0
0000777bb65dcfd2  vmovaps [rsp], xmm0
0000777bb65dcfd7  vmovaps [rsp+0x10], xmm1
0000777bb65dcfdd  vmovaps [rsp+0x20], xmm2
0000777bb65dcfe3  vmovaps [rsp+0x30], xmm4
0000777bb65dcfe9  vmovaps [rsp+0x40], xmm5
0000777bb65dcfef  vmovaps [rsp+0x50], xmm6
0000777bb65dcff5  vmovaps [rsp+0x60], xmm7
0000777bb65dcffb  vmovaps [rsp+0x70], xmm8
0000777bb65dd001  vmovaps [rsp+0x80], xmm9
0000777bb65dd00a  vmovaps [rsp+0x90], xmm10
0000777bb65dd013  vmovaps [rsp+0xA0], xmm11
0000777bb65dd01c  vmovaps [rsp+0xB0], xmm12
0000777bb65dd025  vmovaps [rsp+0xC0], xmm13
0000777bb65dd02e  vmovaps [rsp+0xD0], xmm14
0000777bb65dd037  vmovaps [rsp+0xE0], xmm15
0000777bb65dd040  sub rsp, 0x30
0000777bb65dd044  movaps [rsp], xmm3
0000777bb65dd048  movaps [rsp+0x10], xmm5
0000777bb65dd04d  movaps [rsp+0x20], xmm4
0000777bb65dd052  lea rdi, [rsp]
0000777bb65dd056  mov esi, 0x00
0000777bb65dd05b  mov rax, 0x569DC437B530
0000777bb65dd065  call rax
0000777bb65dd067  movaps xmm3, [rsp]
0000777bb65dd06b  add rsp, 0x30
0000777bb65dd06f  vmovaps xmm0, [rsp]
0000777bb65dd074  vmovaps xmm1, [rsp+0x10]
0000777bb65dd07a  vmovaps xmm2, [rsp+0x20]
0000777bb65dd080  vmovaps xmm4, [rsp+0x30]
0000777bb65dd086  vmovaps xmm5, [rsp+0x40]
0000777bb65dd08c  vmovaps xmm6, [rsp+0x50]
0000777bb65dd092  vmovaps xmm7, [rsp+0x60]
0000777bb65dd098  vmovaps xmm8, [rsp+0x70]
0000777bb65dd09e  vmovaps xmm9, [rsp+0x80]
0000777bb65dd0a7  vmovaps xmm10, [rsp+0x90]
0000777bb65dd0b0  vmovaps xmm11, [rsp+0xA0]
0000777bb65dd0b9  vmovaps xmm12, [rsp+0xB0]
0000777bb65dd0c2  vmovaps xmm13, [rsp+0xC0]
0000777bb65dd0cb  vmovaps xmm14, [rsp+0xD0]
0000777bb65dd0d4  vmovaps xmm15, [rsp+0xE0]
0000777bb65dd0dd  add rsp, 0xF0
0000777bb65dd0e4  pop r11
0000777bb65dd0e6  pop r10
0000777bb65dd0e8  pop r9
0000777bb65dd0ea  pop r8
0000777bb65dd0ec  pop rsi
0000777bb65dd0ed  pop rdi
0000777bb65dd0ee  pop rdx
0000777bb65dd0ef  pop rcx
0000777bb65dd0f0  pop rax
0000777bb65dd0f1  add rsp, 0x08
0000777bb65dd0f5  jmp 0x0000777BB65DBC35
0000777bb65dd0fa  sub rsp, 0x08
0000777bb65dd0fe  push rax
0000777bb65dd0ff  push rcx
0000777bb65dd100  push rdx
0000777bb65dd101  push rdi
0000777bb65dd102  push rsi
0000777bb65dd103  push r8
0000777bb65dd105  push r9
0000777bb65dd107  push r10
0000777bb65dd109  push r11
0000777bb65dd10b  sub rsp, 0xF0
0000777bb65dd112  vmovaps [rsp], xmm0
0000777bb65dd117  vmovaps [rsp+0x10], xmm1
0000777bb65dd11d  vmovaps [rsp+0x20], xmm2
0000777bb65dd123  vmovaps [rsp+0x30], xmm3
0000777bb65dd129  vmovaps [rsp+0x40], xmm4
0000777bb65dd12f  vmovaps [rsp+0x50], xmm6
0000777bb65dd135  vmovaps [rsp+0x60], xmm7
0000777bb65dd13b  vmovaps [rsp+0x70], xmm8
0000777bb65dd141  vmovaps [rsp+0x80], xmm9
0000777bb65dd14a  vmovaps [rsp+0x90], xmm10
0000777bb65dd153  vmovaps [rsp+0xA0], xmm11
0000777bb65dd15c  vmovaps [rsp+0xB0], xmm12
0000777bb65dd165  vmovaps [rsp+0xC0], xmm13
0000777bb65dd16e  vmovaps [rsp+0xD0], xmm14
0000777bb65dd177  vmovaps [rsp+0xE0], xmm15
0000777bb65dd180  sub rsp, 0x30
0000777bb65dd184  movaps [rsp], xmm5
0000777bb65dd188  movaps [rsp+0x10], xmm8
0000777bb65dd18e  movaps [rsp+0x20], xmm15
0000777bb65dd194  lea rdi, [rsp]
0000777bb65dd198  mov esi, 0x00
0000777bb65dd19d  mov rax, 0x569DC437B530
0000777bb65dd1a7  call rax
0000777bb65dd1a9  movaps xmm5, [rsp]
0000777bb65dd1ad  add rsp, 0x30
0000777bb65dd1b1  vmovaps xmm0, [rsp]
0000777bb65dd1b6  vmovaps xmm1, [rsp+0x10]
0000777bb65dd1bc  vmovaps xmm2, [rsp+0x20]
0000777bb65dd1c2  vmovaps xmm3, [rsp+0x30]
0000777bb65dd1c8  vmovaps xmm4, [rsp+0x40]
0000777bb65dd1ce  vmovaps xmm6, [rsp+0x50]
0000777bb65dd1d4  vmovaps xmm7, [rsp+0x60]
0000777bb65dd1da  vmovaps xmm8, [rsp+0x70]
0000777bb65dd1e0  vmovaps xmm9, [rsp+0x80]
0000777bb65dd1e9  vmovaps xmm10, [rsp+0x90]
0000777bb65dd1f2  vmovaps xmm11, [rsp+0xA0]
0000777bb65dd1fb  vmovaps xmm12, [rsp+0xB0]
0000777bb65dd204  vmovaps xmm13, [rsp+0xC0]
0000777bb65dd20d  vmovaps xmm14, [rsp+0xD0]
0000777bb65dd216  vmovaps xmm15, [rsp+0xE0]
0000777bb65dd21f  add rsp, 0xF0
0000777bb65dd226  pop r11
0000777bb65dd228  pop r10
0000777bb65dd22a  pop r9
0000777bb65dd22c  pop r8
0000777bb65dd22e  pop rsi
0000777bb65dd22f  pop rdi
0000777bb65dd230  pop rdx
0000777bb65dd231  pop rcx
0000777bb65dd232  pop rax
0000777bb65dd233  add rsp, 0x08
0000777bb65dd237  jmp 0x0000777BB65DBC73
0000777bb65dd23c  sub rsp, 0x08
0000777bb65dd240  push rax
0000777bb65dd241  push rcx
0000777bb65dd242  push rdx
0000777bb65dd243  push rdi
0000777bb65dd244  push rsi
0000777bb65dd245  push r8
0000777bb65dd247  push r9
0000777bb65dd249  push r10
0000777bb65dd24b  push r11
0000777bb65dd24d  sub rsp, 0xF0
0000777bb65dd254  vmovaps [rsp], xmm0
0000777bb65dd259  vmovaps [rsp+0x10], xmm1
0000777bb65dd25f  vmovaps [rsp+0x20], xmm2
0000777bb65dd265  vmovaps [rsp+0x30], xmm3
0000777bb65dd26b  vmovaps [rsp+0x40], xmm5
0000777bb65dd271  vmovaps [rsp+0x50], xmm6
0000777bb65dd277  vmovaps [rsp+0x60], xmm7
0000777bb65dd27d  vmovaps [rsp+0x70], xmm8
0000777bb65dd283  vmovaps [rsp+0x80], xmm9
0000777bb65dd28c  vmovaps [rsp+0x90], xmm10
0000777bb65dd295  vmovaps [rsp+0xA0], xmm11
0000777bb65dd29e  vmovaps [rsp+0xB0], xmm12
0000777bb65dd2a7  vmovaps [rsp+0xC0], xmm13
0000777bb65dd2b0  vmovaps [rsp+0xD0], xmm14
0000777bb65dd2b9  vmovaps [rsp+0xE0], xmm15
0000777bb65dd2c2  sub rsp, 0x30
0000777bb65dd2c6  movaps [rsp], xmm4
0000777bb65dd2ca  movaps [rsp+0x10], xmm9
0000777bb65dd2d0  movaps [rsp+0x20], xmm8
0000777bb65dd2d6  lea rdi, [rsp]
0000777bb65dd2da  mov esi, 0x00
0000777bb65dd2df  mov rax, 0x569DC437B530
0000777bb65dd2e9  call rax
0000777bb65dd2eb  movaps xmm4, [rsp]
0000777bb65dd2ef  add rsp, 0x30
0000777bb65dd2f3  vmovaps xmm0, [rsp]
0000777bb65dd2f8  vmovaps xmm1, [rsp+0x10]
0000777bb65dd2fe  vmovaps xmm2, [rsp+0x20]
0000777bb65dd304  vmovaps xmm3, [rsp+0x30]
0000777bb65dd30a  vmovaps xmm5, [rsp+0x40]
0000777bb65dd310  vmovaps xmm6, [rsp+0x50]
0000777bb65dd316  vmovaps xmm7, [rsp+0x60]
0000777bb65dd31c  vmovaps xmm8, [rsp+0x70]
0000777bb65dd322  vmovaps xmm9, [rsp+0x80]
0000777bb65dd32b  vmovaps xmm10, [rsp+0x90]
0000777bb65dd334  vmovaps xmm11, [rsp+0xA0]
0000777bb65dd33d  vmovaps xmm12, [rsp+0xB0]
0000777bb65dd346  vmovaps xmm13, [rsp+0xC0]
0000777bb65dd34f  vmovaps xmm14, [rsp+0xD0]
0000777bb65dd358  vmovaps xmm15, [rsp+0xE0]
0000777bb65dd361  add rsp, 0xF0
0000777bb65dd368  pop r11
0000777bb65dd36a  pop r10
0000777bb65dd36c  pop r9
0000777bb65dd36e  pop r8
0000777bb65dd370  pop rsi
0000777bb65dd371  pop rdi
0000777bb65dd372  pop rdx
0000777bb65dd373  pop rcx
0000777bb65dd374  pop rax
0000777bb65dd375  add rsp, 0x08
0000777bb65dd379  jmp 0x0000777BB65DBC94
0000777bb65dd37e  sub rsp, 0x08
0000777bb65dd382  push rax
0000777bb65dd383  push rcx
0000777bb65dd384  push rdx
0000777bb65dd385  push rdi
0000777bb65dd386  push rsi
0000777bb65dd387  push r8
0000777bb65dd389  push r9
0000777bb65dd38b  push r10
0000777bb65dd38d  push r11
0000777bb65dd38f  sub rsp, 0xF0
0000777bb65dd396  vmovaps [rsp], xmm0
0000777bb65dd39b  vmovaps [rsp+0x10], xmm1
0000777bb65dd3a1  vmovaps [rsp+0x20], xmm2
0000777bb65dd3a7  vmovaps [rsp+0x30], xmm3
0000777bb65dd3ad  vmovaps [rsp+0x40], xmm4
0000777bb65dd3b3  vmovaps [rsp+0x50], xmm5
0000777bb65dd3b9  vmovaps [rsp+0x60], xmm6
0000777bb65dd3bf  vmovaps [rsp+0x70], xmm7
0000777bb65dd3c5  vmovaps [rsp+0x80], xmm8
0000777bb65dd3ce  vmovaps [rsp+0x90], xmm10
0000777bb65dd3d7  vmovaps [rsp+0xA0], xmm11
0000777bb65dd3e0  vmovaps [rsp+0xB0], xmm12
0000777bb65dd3e9  vmovaps [rsp+0xC0], xmm13
0000777bb65dd3f2  vmovaps [rsp+0xD0], xmm14
0000777bb65dd3fb  vmovaps [rsp+0xE0], xmm15
0000777bb65dd404  sub rsp, 0x30
0000777bb65dd408  movaps [rsp], xmm9
0000777bb65dd40d  movaps [rsp+0x10], xmm10
0000777bb65dd413  movaps [rsp+0x20], xmm8
0000777bb65dd419  lea rdi, [rsp]
0000777bb65dd41d  mov esi, 0x00
0000777bb65dd422  mov rax, 0x569DC437B530
0000777bb65dd42c  call rax
0000777bb65dd42e  movaps xmm9, [rsp]
0000777bb65dd433  add rsp, 0x30
0000777bb65dd437  vmovaps xmm0, [rsp]
0000777bb65dd43c  vmovaps xmm1, [rsp+0x10]
0000777bb65dd442  vmovaps xmm2, [rsp+0x20]
0000777bb65dd448  vmovaps xmm3, [rsp+0x30]
0000777bb65dd44e  vmovaps xmm4, [rsp+0x40]
0000777bb65dd454  vmovaps xmm5, [rsp+0x50]
0000777bb65dd45a  vmovaps xmm6, [rsp+0x60]
0000777bb65dd460  vmovaps xmm7, [rsp+0x70]
0000777bb65dd466  vmovaps xmm8, [rsp+0x80]
0000777bb65dd46f  vmovaps xmm10, [rsp+0x90]
0000777bb65dd478  vmovaps xmm11, [rsp+0xA0]
0000777bb65dd481  vmovaps xmm12, [rsp+0xB0]
0000777bb65dd48a  vmovaps xmm13, [rsp+0xC0]
0000777bb65dd493  vmovaps xmm14, [rsp+0xD0]
0000777bb65dd49c  vmovaps xmm15, [rsp+0xE0]
0000777bb65dd4a5  add rsp, 0xF0
0000777bb65dd4ac  pop r11
0000777bb65dd4ae  pop r10
0000777bb65dd4b0  pop r9
0000777bb65dd4b2  pop r8
0000777bb65dd4b4  pop rsi
0000777bb65dd4b5  pop rdi
0000777bb65dd4b6  pop rdx
0000777bb65dd4b7  pop rcx
0000777bb65dd4b8  pop rax
0000777bb65dd4b9  add rsp, 0x08
0000777bb65dd4bd  jmp 0x0000777BB65DBCAE
0000777bb65dd4c2  call 0x0000777BB64B52F0
0000777bb65dd4c7  jmp 0x0000777BB65DBDC8
0000777bb65dd4cc  call 0x0000777BB64B52F0
0000777bb65dd4d1  jmp 0x0000777BB65DBDDE
0000777bb65dd4d6  sub rsp, 0x08
0000777bb65dd4da  push rax
0000777bb65dd4db  push rcx
0000777bb65dd4dc  push rdx
0000777bb65dd4dd  push rdi
0000777bb65dd4de  push rsi
0000777bb65dd4df  push r8
0000777bb65dd4e1  push r9
0000777bb65dd4e3  push r10
0000777bb65dd4e5  push r11
0000777bb65dd4e7  sub rsp, 0xF0
0000777bb65dd4ee  vmovaps [rsp], xmm0
0000777bb65dd4f3  vmovaps [rsp+0x10], xmm2
0000777bb65dd4f9  vmovaps [rsp+0x20], xmm3
0000777bb65dd4ff  vmovaps [rsp+0x30], xmm4
0000777bb65dd505  vmovaps [rsp+0x40], xmm5
0000777bb65dd50b  vmovaps [rsp+0x50], xmm6
0000777bb65dd511  vmovaps [rsp+0x60], xmm7
0000777bb65dd517  vmovaps [rsp+0x70], xmm8
0000777bb65dd51d  vmovaps [rsp+0x80], xmm9
0000777bb65dd526  vmovaps [rsp+0x90], xmm10
0000777bb65dd52f  vmovaps [rsp+0xA0], xmm11
0000777bb65dd538  vmovaps [rsp+0xB0], xmm12
0000777bb65dd541  vmovaps [rsp+0xC0], xmm13
0000777bb65dd54a  vmovaps [rsp+0xD0], xmm14
0000777bb65dd553  vmovaps [rsp+0xE0], xmm15
0000777bb65dd55c  sub rsp, 0x30
0000777bb65dd560  movaps [rsp], xmm1
0000777bb65dd564  movaps [rsp+0x10], xmm6
0000777bb65dd569  movaps [rsp+0x20], xmm15
0000777bb65dd56f  lea rdi, [rsp]
0000777bb65dd573  mov esi, 0x00
0000777bb65dd578  mov rax, 0x569DC437B530
0000777bb65dd582  call rax
0000777bb65dd584  movaps xmm1, [rsp]
0000777bb65dd588  add rsp, 0x30
0000777bb65dd58c  vmovaps xmm0, [rsp]
0000777bb65dd591  vmovaps xmm2, [rsp+0x10]
0000777bb65dd597  vmovaps xmm3, [rsp+0x20]
0000777bb65dd59d  vmovaps xmm4, [rsp+0x30]
0000777bb65dd5a3  vmovaps xmm5, [rsp+0x40]
0000777bb65dd5a9  vmovaps xmm6, [rsp+0x50]
0000777bb65dd5af  vmovaps xmm7, [rsp+0x60]
0000777bb65dd5b5  vmovaps xmm8, [rsp+0x70]
0000777bb65dd5bb  vmovaps xmm9, [rsp+0x80]
0000777bb65dd5c4  vmovaps xmm10, [rsp+0x90]
0000777bb65dd5cd  vmovaps xmm11, [rsp+0xA0]
0000777bb65dd5d6  vmovaps xmm12, [rsp+0xB0]
0000777bb65dd5df  vmovaps xmm13, [rsp+0xC0]
0000777bb65dd5e8  vmovaps xmm14, [rsp+0xD0]
0000777bb65dd5f1  vmovaps xmm15, [rsp+0xE0]
0000777bb65dd5fa  add rsp, 0xF0
0000777bb65dd601  pop r11
0000777bb65dd603  pop r10
0000777bb65dd605  pop r9
0000777bb65dd607  pop r8
0000777bb65dd609  pop rsi
0000777bb65dd60a  pop rdi
0000777bb65dd60b  pop rdx
0000777bb65dd60c  pop rcx
0000777bb65dd60d  pop rax
0000777bb65dd60e  add rsp, 0x08
0000777bb65dd612  jmp 0x0000777BB65DBE1B
0000777bb65dd617  call 0x0000777BB64C4620
0000777bb65dd61c  jmp 0x0000777BB65DBE28
0000777bb65dd621  sub rsp, 0x08
0000777bb65dd625  push rax
0000777bb65dd626  push rcx
0000777bb65dd627  push rdx
0000777bb65dd628  push rdi
0000777bb65dd629  push rsi
0000777bb65dd62a  push r8
0000777bb65dd62c  push r9
0000777bb65dd62e  push r10
0000777bb65dd630  push r11
0000777bb65dd632  sub rsp, 0xF0
0000777bb65dd639  vmovaps [rsp], xmm0
0000777bb65dd63e  vmovaps [rsp+0x10], xmm1
0000777bb65dd644  vmovaps [rsp+0x20], xmm2
0000777bb65dd64a  vmovaps [rsp+0x30], xmm3
0000777bb65dd650  vmovaps [rsp+0x40], xmm4
0000777bb65dd656  vmovaps [rsp+0x50], xmm5
0000777bb65dd65c  vmovaps [rsp+0x60], xmm6
0000777bb65dd662  vmovaps [rsp+0x70], xmm7
0000777bb65dd668  vmovaps [rsp+0x80], xmm8
0000777bb65dd671  vmovaps [rsp+0x90], xmm9
0000777bb65dd67a  vmovaps [rsp+0xA0], xmm10
0000777bb65dd683  vmovaps [rsp+0xB0], xmm11
0000777bb65dd68c  vmovaps [rsp+0xC0], xmm12
0000777bb65dd695  vmovaps [rsp+0xD0], xmm13
0000777bb65dd69e  vmovaps [rsp+0xE0], xmm15
0000777bb65dd6a7  sub rsp, 0x30
0000777bb65dd6ab  movaps [rsp], xmm14
0000777bb65dd6b0  movaps [rsp+0x10], xmm4
0000777bb65dd6b5  movaps [rsp+0x20], xmm3
0000777bb65dd6ba  lea rdi, [rsp]
0000777bb65dd6be  mov esi, 0x00
0000777bb65dd6c3  mov rax, 0x569DC437B530
0000777bb65dd6cd  call rax
0000777bb65dd6cf  movaps xmm14, [rsp]
0000777bb65dd6d4  add rsp, 0x30
0000777bb65dd6d8  vmovaps xmm0, [rsp]
0000777bb65dd6dd  vmovaps xmm1, [rsp+0x10]
0000777bb65dd6e3  vmovaps xmm2, [rsp+0x20]
0000777bb65dd6e9  vmovaps xmm3, [rsp+0x30]
0000777bb65dd6ef  vmovaps xmm4, [rsp+0x40]
0000777bb65dd6f5  vmovaps xmm5, [rsp+0x50]
0000777bb65dd6fb  vmovaps xmm6, [rsp+0x60]
0000777bb65dd701  vmovaps xmm7, [rsp+0x70]
0000777bb65dd707  vmovaps xmm8, [rsp+0x80]
0000777bb65dd710  vmovaps xmm9, [rsp+0x90]
0000777bb65dd719  vmovaps xmm10, [rsp+0xA0]
0000777bb65dd722  vmovaps xmm11, [rsp+0xB0]
0000777bb65dd72b  vmovaps xmm12, [rsp+0xC0]
0000777bb65dd734  vmovaps xmm13, [rsp+0xD0]
0000777bb65dd73d  vmovaps xmm15, [rsp+0xE0]
0000777bb65dd746  add rsp, 0xF0
0000777bb65dd74d  pop r11
0000777bb65dd74f  pop r10
0000777bb65dd751  pop r9
0000777bb65dd753  pop r8
0000777bb65dd755  pop rsi
0000777bb65dd756  pop rdi
0000777bb65dd757  pop rdx
0000777bb65dd758  pop rcx
0000777bb65dd759  pop rax
0000777bb65dd75a  add rsp, 0x08
0000777bb65dd75e  jmp 0x0000777BB65DBE42
0000777bb65dd763  sub rsp, 0x08
0000777bb65dd767  push rax
0000777bb65dd768  push rcx
0000777bb65dd769  push rdx
0000777bb65dd76a  push rdi
0000777bb65dd76b  push rsi
0000777bb65dd76c  push r8
0000777bb65dd76e  push r9
0000777bb65dd770  push r10
0000777bb65dd772  push r11
0000777bb65dd774  sub rsp, 0xF0
0000777bb65dd77b  vmovaps [rsp], xmm0
0000777bb65dd780  vmovaps [rsp+0x10], xmm1
0000777bb65dd786  vmovaps [rsp+0x20], xmm2
0000777bb65dd78c  vmovaps [rsp+0x30], xmm3
0000777bb65dd792  vmovaps [rsp+0x40], xmm4
0000777bb65dd798  vmovaps [rsp+0x50], xmm5
0000777bb65dd79e  vmovaps [rsp+0x60], xmm7
0000777bb65dd7a4  vmovaps [rsp+0x70], xmm8
0000777bb65dd7aa  vmovaps [rsp+0x80], xmm9
0000777bb65dd7b3  vmovaps [rsp+0x90], xmm10
0000777bb65dd7bc  vmovaps [rsp+0xA0], xmm11
0000777bb65dd7c5  vmovaps [rsp+0xB0], xmm12
0000777bb65dd7ce  vmovaps [rsp+0xC0], xmm13
0000777bb65dd7d7  vmovaps [rsp+0xD0], xmm14
0000777bb65dd7e0  vmovaps [rsp+0xE0], xmm15
0000777bb65dd7e9  sub rsp, 0x30
0000777bb65dd7ed  movaps [rsp], xmm6
0000777bb65dd7f1  movaps [rsp+0x10], xmm9
0000777bb65dd7f7  movaps [rsp+0x20], xmm7
0000777bb65dd7fc  lea rdi, [rsp]
0000777bb65dd800  mov esi, 0x00
0000777bb65dd805  mov rax, 0x569DC437B530
0000777bb65dd80f  call rax
0000777bb65dd811  movaps xmm6, [rsp]
0000777bb65dd815  add rsp, 0x30
0000777bb65dd819  vmovaps xmm0, [rsp]
0000777bb65dd81e  vmovaps xmm1, [rsp+0x10]
0000777bb65dd824  vmovaps xmm2, [rsp+0x20]
0000777bb65dd82a  vmovaps xmm3, [rsp+0x30]
0000777bb65dd830  vmovaps xmm4, [rsp+0x40]
0000777bb65dd836  vmovaps xmm5, [rsp+0x50]
0000777bb65dd83c  vmovaps xmm7, [rsp+0x60]
0000777bb65dd842  vmovaps xmm8, [rsp+0x70]
0000777bb65dd848  vmovaps xmm9, [rsp+0x80]
0000777bb65dd851  vmovaps xmm10, [rsp+0x90]
0000777bb65dd85a  vmovaps xmm11, [rsp+0xA0]
0000777bb65dd863  vmovaps xmm12, [rsp+0xB0]
0000777bb65dd86c  vmovaps xmm13, [rsp+0xC0]
0000777bb65dd875  vmovaps xmm14, [rsp+0xD0]
0000777bb65dd87e  vmovaps xmm15, [rsp+0xE0]
0000777bb65dd887  add rsp, 0xF0
0000777bb65dd88e  pop r11
0000777bb65dd890  pop r10
0000777bb65dd892  pop r9
0000777bb65dd894  pop r8
0000777bb65dd896  pop rsi
0000777bb65dd897  pop rdi
0000777bb65dd898  pop rdx
0000777bb65dd899  pop rcx
0000777bb65dd89a  pop rax
0000777bb65dd89b  add rsp, 0x08
0000777bb65dd89f  jmp 0x0000777BB65DBE5A
0000777bb65dd8a4  sub rsp, 0x08
0000777bb65dd8a8  push rax
0000777bb65dd8a9  push rcx
0000777bb65dd8aa  push rdx
0000777bb65dd8ab  push rdi
0000777bb65dd8ac  push rsi
0000777bb65dd8ad  push r8
0000777bb65dd8af  push r9
0000777bb65dd8b1  push r10
0000777bb65dd8b3  push r11
0000777bb65dd8b5  sub rsp, 0xF0
0000777bb65dd8bc  vmovaps [rsp], xmm0
0000777bb65dd8c1  vmovaps [rsp+0x10], xmm1
0000777bb65dd8c7  vmovaps [rsp+0x20], xmm2
0000777bb65dd8cd  vmovaps [rsp+0x30], xmm3
0000777bb65dd8d3  vmovaps [rsp+0x40], xmm4
0000777bb65dd8d9  vmovaps [rsp+0x50], xmm5
0000777bb65dd8df  vmovaps [rsp+0x60], xmm6
0000777bb65dd8e5  vmovaps [rsp+0x70], xmm8
0000777bb65dd8eb  vmovaps [rsp+0x80], xmm9
0000777bb65dd8f4  vmovaps [rsp+0x90], xmm10
0000777bb65dd8fd  vmovaps [rsp+0xA0], xmm11
0000777bb65dd906  vmovaps [rsp+0xB0], xmm12
0000777bb65dd90f  vmovaps [rsp+0xC0], xmm13
0000777bb65dd918  vmovaps [rsp+0xD0], xmm14
0000777bb65dd921  vmovaps [rsp+0xE0], xmm15
0000777bb65dd92a  sub rsp, 0x30
0000777bb65dd92e  movaps [rsp], xmm7
0000777bb65dd932  movaps [rsp+0x10], xmm4
0000777bb65dd937  movaps [rsp+0x20], xmm9
0000777bb65dd93d  lea rdi, [rsp]
0000777bb65dd941  mov esi, 0x00
0000777bb65dd946  mov rax, 0x569DC437B530
0000777bb65dd950  call rax
0000777bb65dd952  movaps xmm7, [rsp]
0000777bb65dd956  add rsp, 0x30
0000777bb65dd95a  vmovaps xmm0, [rsp]
0000777bb65dd95f  vmovaps xmm1, [rsp+0x10]
0000777bb65dd965  vmovaps xmm2, [rsp+0x20]
0000777bb65dd96b  vmovaps xmm3, [rsp+0x30]
0000777bb65dd971  vmovaps xmm4, [rsp+0x40]
0000777bb65dd977  vmovaps xmm5, [rsp+0x50]
0000777bb65dd97d  vmovaps xmm6, [rsp+0x60]
0000777bb65dd983  vmovaps xmm8, [rsp+0x70]
0000777bb65dd989  vmovaps xmm9, [rsp+0x80]
0000777bb65dd992  vmovaps xmm10, [rsp+0x90]
0000777bb65dd99b  vmovaps xmm11, [rsp+0xA0]
0000777bb65dd9a4  vmovaps xmm12, [rsp+0xB0]
0000777bb65dd9ad  vmovaps xmm13, [rsp+0xC0]
0000777bb65dd9b6  vmovaps xmm14, [rsp+0xD0]
0000777bb65dd9bf  vmovaps xmm15, [rsp+0xE0]
0000777bb65dd9c8  add rsp, 0xF0
0000777bb65dd9cf  pop r11
0000777bb65dd9d1  pop r10
0000777bb65dd9d3  pop r9
0000777bb65dd9d5  pop r8
0000777bb65dd9d7  pop rsi
0000777bb65dd9d8  pop rdi
0000777bb65dd9d9  pop rdx
0000777bb65dd9da  pop rcx
0000777bb65dd9db  pop rax
0000777bb65dd9dc  add rsp, 0x08
0000777bb65dd9e0  jmp 0x0000777BB65DBE87
0000777bb65dd9e5  sub rsp, 0x08
0000777bb65dd9e9  push rax
0000777bb65dd9ea  push rcx
0000777bb65dd9eb  push rdx
0000777bb65dd9ec  push rdi
0000777bb65dd9ed  push rsi
0000777bb65dd9ee  push r8
0000777bb65dd9f0  push r9
0000777bb65dd9f2  push r10
0000777bb65dd9f4  push r11
0000777bb65dd9f6  sub rsp, 0xF0
0000777bb65dd9fd  vmovaps [rsp], xmm0
0000777bb65dda02  vmovaps [rsp+0x10], xmm1
0000777bb65dda08  vmovaps [rsp+0x20], xmm2
0000777bb65dda0e  vmovaps [rsp+0x30], xmm3
0000777bb65dda14  vmovaps [rsp+0x40], xmm5
0000777bb65dda1a  vmovaps [rsp+0x50], xmm6
0000777bb65dda20  vmovaps [rsp+0x60], xmm7
0000777bb65dda26  vmovaps [rsp+0x70], xmm8
0000777bb65dda2c  vmovaps [rsp+0x80], xmm9
0000777bb65dda35  vmovaps [rsp+0x90], xmm10
0000777bb65dda3e  vmovaps [rsp+0xA0], xmm11
0000777bb65dda47  vmovaps [rsp+0xB0], xmm12
0000777bb65dda50  vmovaps [rsp+0xC0], xmm13
0000777bb65dda59  vmovaps [rsp+0xD0], xmm14
0000777bb65dda62  vmovaps [rsp+0xE0], xmm15
0000777bb65dda6b  sub rsp, 0x30
0000777bb65dda6f  movaps [rsp], xmm4
0000777bb65dda73  movaps [rsp+0x10], xmm15
0000777bb65dda79  movaps [rsp+0x20], xmm9
0000777bb65dda7f  lea rdi, [rsp]
0000777bb65dda83  mov esi, 0x00
0000777bb65dda88  mov rax, 0x569DC437B530
0000777bb65dda92  call rax
0000777bb65dda94  movaps xmm4, [rsp]
0000777bb65dda98  add rsp, 0x30
0000777bb65dda9c  vmovaps xmm0, [rsp]
0000777bb65ddaa1  vmovaps xmm1, [rsp+0x10]
0000777bb65ddaa7  vmovaps xmm2, [rsp+0x20]
0000777bb65ddaad  vmovaps xmm3, [rsp+0x30]
0000777bb65ddab3  vmovaps xmm5, [rsp+0x40]
0000777bb65ddab9  vmovaps xmm6, [rsp+0x50]
0000777bb65ddabf  vmovaps xmm7, [rsp+0x60]
0000777bb65ddac5  vmovaps xmm8, [rsp+0x70]
0000777bb65ddacb  vmovaps xmm9, [rsp+0x80]
0000777bb65ddad4  vmovaps xmm10, [rsp+0x90]
0000777bb65ddadd  vmovaps xmm11, [rsp+0xA0]
0000777bb65ddae6  vmovaps xmm12, [rsp+0xB0]
0000777bb65ddaef  vmovaps xmm13, [rsp+0xC0]
0000777bb65ddaf8  vmovaps xmm14, [rsp+0xD0]
0000777bb65ddb01  vmovaps xmm15, [rsp+0xE0]
0000777bb65ddb0a  add rsp, 0xF0
0000777bb65ddb11  pop r11
0000777bb65ddb13  pop r10
0000777bb65ddb15  pop r9
0000777bb65ddb17  pop r8
0000777bb65ddb19  pop rsi
0000777bb65ddb1a  pop rdi
0000777bb65ddb1b  pop rdx
0000777bb65ddb1c  pop rcx
0000777bb65ddb1d  pop rax
0000777bb65ddb1e  add rsp, 0x08
0000777bb65ddb22  jmp 0x0000777BB65DBEAC
0000777bb65ddb27  call 0x0000777BB64C4620
0000777bb65ddb2c  jmp 0x0000777BB65DBEB9
0000777bb65ddb31  sub rsp, 0x08
0000777bb65ddb35  push rax
0000777bb65ddb36  push rcx
0000777bb65ddb37  push rdx
0000777bb65ddb38  push rdi
0000777bb65ddb39  push rsi
0000777bb65ddb3a  push r8
0000777bb65ddb3c  push r9
0000777bb65ddb3e  push r10
0000777bb65ddb40  push r11
0000777bb65ddb42  sub rsp, 0xF0
0000777bb65ddb49  vmovaps [rsp], xmm0
0000777bb65ddb4e  vmovaps [rsp+0x10], xmm1
0000777bb65ddb54  vmovaps [rsp+0x20], xmm2
0000777bb65ddb5a  vmovaps [rsp+0x30], xmm4
0000777bb65ddb60  vmovaps [rsp+0x40], xmm5
0000777bb65ddb66  vmovaps [rsp+0x50], xmm6
0000777bb65ddb6c  vmovaps [rsp+0x60], xmm7
0000777bb65ddb72  vmovaps [rsp+0x70], xmm8
0000777bb65ddb78  vmovaps [rsp+0x80], xmm9
0000777bb65ddb81  vmovaps [rsp+0x90], xmm10
0000777bb65ddb8a  vmovaps [rsp+0xA0], xmm11
0000777bb65ddb93  vmovaps [rsp+0xB0], xmm12
0000777bb65ddb9c  vmovaps [rsp+0xC0], xmm13
0000777bb65ddba5  vmovaps [rsp+0xD0], xmm14
0000777bb65ddbae  vmovaps [rsp+0xE0], xmm15
0000777bb65ddbb7  sub rsp, 0x30
0000777bb65ddbbb  movaps [rsp], xmm3
0000777bb65ddbbf  movaps [rsp+0x10], xmm1
0000777bb65ddbc4  movaps [rsp+0x20], xmm9
0000777bb65ddbca  lea rdi, [rsp]
0000777bb65ddbce  mov esi, 0x00
0000777bb65ddbd3  mov rax, 0x569DC437B530
0000777bb65ddbdd  call rax
0000777bb65ddbdf  movaps xmm3, [rsp]
0000777bb65ddbe3  add rsp, 0x30
0000777bb65ddbe7  vmovaps xmm0, [rsp]
0000777bb65ddbec  vmovaps xmm1, [rsp+0x10]
0000777bb65ddbf2  vmovaps xmm2, [rsp+0x20]
0000777bb65ddbf8  vmovaps xmm4, [rsp+0x30]
0000777bb65ddbfe  vmovaps xmm5, [rsp+0x40]
0000777bb65ddc04  vmovaps xmm6, [rsp+0x50]
0000777bb65ddc0a  vmovaps xmm7, [rsp+0x60]
0000777bb65ddc10  vmovaps xmm8, [rsp+0x70]
0000777bb65ddc16  vmovaps xmm9, [rsp+0x80]
0000777bb65ddc1f  vmovaps xmm10, [rsp+0x90]
0000777bb65ddc28  vmovaps xmm11, [rsp+0xA0]
0000777bb65ddc31  vmovaps xmm12, [rsp+0xB0]
0000777bb65ddc3a  vmovaps xmm13, [rsp+0xC0]
0000777bb65ddc43  vmovaps xmm14, [rsp+0xD0]
0000777bb65ddc4c  vmovaps xmm15, [rsp+0xE0]
0000777bb65ddc55  add rsp, 0xF0
0000777bb65ddc5c  pop r11
0000777bb65ddc5e  pop r10
0000777bb65ddc60  pop r9
0000777bb65ddc62  pop r8
0000777bb65ddc64  pop rsi
0000777bb65ddc65  pop rdi
0000777bb65ddc66  pop rdx
0000777bb65ddc67  pop rcx
0000777bb65ddc68  pop rax
0000777bb65ddc69  add rsp, 0x08
0000777bb65ddc6d  jmp 0x0000777BB65DBEF6
0000777bb65ddc72  sub rsp, 0x08
0000777bb65ddc76  push rax
0000777bb65ddc77  push rcx
0000777bb65ddc78  push rdx
0000777bb65ddc79  push rdi
0000777bb65ddc7a  push rsi
0000777bb65ddc7b  push r8
0000777bb65ddc7d  push r9
0000777bb65ddc7f  push r10
0000777bb65ddc81  push r11
0000777bb65ddc83  sub rsp, 0xF0
0000777bb65ddc8a  vmovaps [rsp], xmm0
0000777bb65ddc8f  vmovaps [rsp+0x10], xmm2
0000777bb65ddc95  vmovaps [rsp+0x20], xmm3
0000777bb65ddc9b  vmovaps [rsp+0x30], xmm4
0000777bb65ddca1  vmovaps [rsp+0x40], xmm5
0000777bb65ddca7  vmovaps [rsp+0x50], xmm6
0000777bb65ddcad  vmovaps [rsp+0x60], xmm7
0000777bb65ddcb3  vmovaps [rsp+0x70], xmm8
0000777bb65ddcb9  vmovaps [rsp+0x80], xmm9
0000777bb65ddcc2  vmovaps [rsp+0x90], xmm10
0000777bb65ddccb  vmovaps [rsp+0xA0], xmm11
0000777bb65ddcd4  vmovaps [rsp+0xB0], xmm12
0000777bb65ddcdd  vmovaps [rsp+0xC0], xmm13
0000777bb65ddce6  vmovaps [rsp+0xD0], xmm14
0000777bb65ddcef  vmovaps [rsp+0xE0], xmm15
0000777bb65ddcf8  sub rsp, 0x30
0000777bb65ddcfc  movaps [rsp], xmm1
0000777bb65ddd00  movaps [rsp+0x10], xmm15
0000777bb65ddd06  movaps [rsp+0x20], xmm9
0000777bb65ddd0c  lea rdi, [rsp]
0000777bb65ddd10  mov esi, 0x00
0000777bb65ddd15  mov rax, 0x569DC437B530
0000777bb65ddd1f  call rax
0000777bb65ddd21  movaps xmm1, [rsp]
0000777bb65ddd25  add rsp, 0x30
0000777bb65ddd29  vmovaps xmm0, [rsp]
0000777bb65ddd2e  vmovaps xmm2, [rsp+0x10]
0000777bb65ddd34  vmovaps xmm3, [rsp+0x20]
0000777bb65ddd3a  vmovaps xmm4, [rsp+0x30]
0000777bb65ddd40  vmovaps xmm5, [rsp+0x40]
0000777bb65ddd46  vmovaps xmm6, [rsp+0x50]
0000777bb65ddd4c  vmovaps xmm7, [rsp+0x60]
0000777bb65ddd52  vmovaps xmm8, [rsp+0x70]
0000777bb65ddd58  vmovaps xmm9, [rsp+0x80]
0000777bb65ddd61  vmovaps xmm10, [rsp+0x90]
0000777bb65ddd6a  vmovaps xmm11, [rsp+0xA0]
0000777bb65ddd73  vmovaps xmm12, [rsp+0xB0]
0000777bb65ddd7c  vmovaps xmm13, [rsp+0xC0]
0000777bb65ddd85  vmovaps xmm14, [rsp+0xD0]
0000777bb65ddd8e  vmovaps xmm15, [rsp+0xE0]
0000777bb65ddd97  add rsp, 0xF0
0000777bb65ddd9e  pop r11
0000777bb65ddda0  pop r10
0000777bb65ddda2  pop r9
0000777bb65ddda4  pop r8
0000777bb65ddda6  pop rsi
0000777bb65ddda7  pop rdi
0000777bb65ddda8  pop rdx
0000777bb65ddda9  pop rcx
0000777bb65dddaa  pop rax
0000777bb65dddab  add rsp, 0x08
0000777bb65dddaf  jmp 0x0000777BB65DBF7E
0000777bb65dddb4  call 0x0000777BB64C4620
0000777bb65dddb9  jmp 0x0000777BB65DBF8B
0000777bb65dddbe  sub rsp, 0x08
0000777bb65dddc2  push rax
0000777bb65dddc3  push rcx
0000777bb65dddc4  push rdx
0000777bb65dddc5  push rdi
0000777bb65dddc6  push rsi
0000777bb65dddc7  push r8
0000777bb65dddc9  push r9
0000777bb65dddcb  push r10
0000777bb65dddcd  push r11
0000777bb65dddcf  sub rsp, 0xF0
0000777bb65dddd6  vmovaps [rsp], xmm0
0000777bb65ddddb  vmovaps [rsp+0x10], xmm2
0000777bb65ddde1  vmovaps [rsp+0x20], xmm3
0000777bb65ddde7  vmovaps [rsp+0x30], xmm4
0000777bb65ddded  vmovaps [rsp+0x40], xmm5
0000777bb65dddf3  vmovaps [rsp+0x50], xmm6
0000777bb65dddf9  vmovaps [rsp+0x60], xmm7
0000777bb65dddff  vmovaps [rsp+0x70], xmm8
0000777bb65dde05  vmovaps [rsp+0x80], xmm9
0000777bb65dde0e  vmovaps [rsp+0x90], xmm10
0000777bb65dde17  vmovaps [rsp+0xA0], xmm11
0000777bb65dde20  vmovaps [rsp+0xB0], xmm12
0000777bb65dde29  vmovaps [rsp+0xC0], xmm13
0000777bb65dde32  vmovaps [rsp+0xD0], xmm14
0000777bb65dde3b  vmovaps [rsp+0xE0], xmm15
0000777bb65dde44  sub rsp, 0x30
0000777bb65dde48  movaps [rsp], xmm1
0000777bb65dde4c  movaps [rsp+0x10], xmm5
0000777bb65dde51  movaps [rsp+0x20], xmm7
0000777bb65dde56  lea rdi, [rsp]
0000777bb65dde5a  mov esi, 0x00
0000777bb65dde5f  mov rax, 0x569DC437B530
0000777bb65dde69  call rax
0000777bb65dde6b  movaps xmm1, [rsp]
0000777bb65dde6f  add rsp, 0x30
0000777bb65dde73  vmovaps xmm0, [rsp]
0000777bb65dde78  vmovaps xmm2, [rsp+0x10]
0000777bb65dde7e  vmovaps xmm3, [rsp+0x20]
0000777bb65dde84  vmovaps xmm4, [rsp+0x30]
0000777bb65dde8a  vmovaps xmm5, [rsp+0x40]
0000777bb65dde90  vmovaps xmm6, [rsp+0x50]
0000777bb65dde96  vmovaps xmm7, [rsp+0x60]
0000777bb65dde9c  vmovaps xmm8, [rsp+0x70]
0000777bb65ddea2  vmovaps xmm9, [rsp+0x80]
0000777bb65ddeab  vmovaps xmm10, [rsp+0x90]
0000777bb65ddeb4  vmovaps xmm11, [rsp+0xA0]
0000777bb65ddebd  vmovaps xmm12, [rsp+0xB0]
0000777bb65ddec6  vmovaps xmm13, [rsp+0xC0]
0000777bb65ddecf  vmovaps xmm14, [rsp+0xD0]
0000777bb65dded8  vmovaps xmm15, [rsp+0xE0]
0000777bb65ddee1  add rsp, 0xF0
0000777bb65ddee8  pop r11
0000777bb65ddeea  pop r10
0000777bb65ddeec  pop r9
0000777bb65ddeee  pop r8
0000777bb65ddef0  pop rsi
0000777bb65ddef1  pop rdi
0000777bb65ddef2  pop rdx
0000777bb65ddef3  pop rcx
0000777bb65ddef4  pop rax
0000777bb65ddef5  add rsp, 0x08
0000777bb65ddef9  jmp 0x0000777BB65DC030
0000777bb65ddefe  sub rsp, 0x08
0000777bb65ddf02  push rax
0000777bb65ddf03  push rcx
0000777bb65ddf04  push rdx
0000777bb65ddf05  push rdi
0000777bb65ddf06  push rsi
0000777bb65ddf07  push r8
0000777bb65ddf09  push r9
0000777bb65ddf0b  push r10
0000777bb65ddf0d  push r11
0000777bb65ddf0f  sub rsp, 0xF0
0000777bb65ddf16  vmovaps [rsp], xmm0
0000777bb65ddf1b  vmovaps [rsp+0x10], xmm1
0000777bb65ddf21  vmovaps [rsp+0x20], xmm2
0000777bb65ddf27  vmovaps [rsp+0x30], xmm3
0000777bb65ddf2d  vmovaps [rsp+0x40], xmm4
0000777bb65ddf33  vmovaps [rsp+0x50], xmm5
0000777bb65ddf39  vmovaps [rsp+0x60], xmm6
0000777bb65ddf3f  vmovaps [rsp+0x70], xmm8
0000777bb65ddf45  vmovaps [rsp+0x80], xmm9
0000777bb65ddf4e  vmovaps [rsp+0x90], xmm10
0000777bb65ddf57  vmovaps [rsp+0xA0], xmm11
0000777bb65ddf60  vmovaps [rsp+0xB0], xmm12
0000777bb65ddf69  vmovaps [rsp+0xC0], xmm13
0000777bb65ddf72  vmovaps [rsp+0xD0], xmm14
0000777bb65ddf7b  vmovaps [rsp+0xE0], xmm15
0000777bb65ddf84  sub rsp, 0x30
0000777bb65ddf88  movaps [rsp], xmm7
0000777bb65ddf8c  movaps [rsp+0x10], xmm5
0000777bb65ddf91  movaps [rsp+0x20], xmm15
0000777bb65ddf97  lea rdi, [rsp]
0000777bb65ddf9b  mov esi, 0x00
0000777bb65ddfa0  mov rax, 0x569DC437B530
0000777bb65ddfaa  call rax
0000777bb65ddfac  movaps xmm7, [rsp]
0000777bb65ddfb0  add rsp, 0x30
0000777bb65ddfb4  vmovaps xmm0, [rsp]
0000777bb65ddfb9  vmovaps xmm1, [rsp+0x10]
0000777bb65ddfbf  vmovaps xmm2, [rsp+0x20]
0000777bb65ddfc5  vmovaps xmm3, [rsp+0x30]
0000777bb65ddfcb  vmovaps xmm4, [rsp+0x40]
0000777bb65ddfd1  vmovaps xmm5, [rsp+0x50]
0000777bb65ddfd7  vmovaps xmm6, [rsp+0x60]
0000777bb65ddfdd  vmovaps xmm8, [rsp+0x70]
0000777bb65ddfe3  vmovaps xmm9, [rsp+0x80]
0000777bb65ddfec  vmovaps xmm10, [rsp+0x90]
0000777bb65ddff5  vmovaps xmm11, [rsp+0xA0]
0000777bb65ddffe  vmovaps xmm12, [rsp+0xB0]
0000777bb65de007  vmovaps xmm13, [rsp+0xC0]
0000777bb65de010  vmovaps xmm14, [rsp+0xD0]
0000777bb65de019  vmovaps xmm15, [rsp+0xE0]
0000777bb65de022  add rsp, 0xF0
0000777bb65de029  pop r11
0000777bb65de02b  pop r10
0000777bb65de02d  pop r9
0000777bb65de02f  pop r8
0000777bb65de031  pop rsi
0000777bb65de032  pop rdi
0000777bb65de033  pop rdx
0000777bb65de034  pop rcx
0000777bb65de035  pop rax
0000777bb65de036  add rsp, 0x08
0000777bb65de03a  jmp 0x0000777BB65DC066
0000777bb65de03f  call 0x0000777BB64B52F0
0000777bb65de044  jmp 0x0000777BB65DC073
0000777bb65de049  sub rsp, 0x08
0000777bb65de04d  push rax
0000777bb65de04e  push rcx
0000777bb65de04f  push rdx
0000777bb65de050  push rdi
0000777bb65de051  push rsi
0000777bb65de052  push r8
0000777bb65de054  push r9
0000777bb65de056  push r10
0000777bb65de058  push r11
0000777bb65de05a  sub rsp, 0xF0
0000777bb65de061  vmovaps [rsp], xmm0
0000777bb65de066  vmovaps [rsp+0x10], xmm1
0000777bb65de06c  vmovaps [rsp+0x20], xmm2
0000777bb65de072  vmovaps [rsp+0x30], xmm3
0000777bb65de078  vmovaps [rsp+0x40], xmm4
0000777bb65de07e  vmovaps [rsp+0x50], xmm5
0000777bb65de084  vmovaps [rsp+0x60], xmm6
0000777bb65de08a  vmovaps [rsp+0x70], xmm7
0000777bb65de090  vmovaps [rsp+0x80], xmm8
0000777bb65de099  vmovaps [rsp+0x90], xmm9
0000777bb65de0a2  vmovaps [rsp+0xA0], xmm10
0000777bb65de0ab  vmovaps [rsp+0xB0], xmm11
0000777bb65de0b4  vmovaps [rsp+0xC0], xmm12
0000777bb65de0bd  vmovaps [rsp+0xD0], xmm13
0000777bb65de0c6  vmovaps [rsp+0xE0], xmm14
0000777bb65de0cf  sub rsp, 0x30
0000777bb65de0d3  movaps [rsp], xmm15
0000777bb65de0d8  movaps [rsp+0x10], xmm5
0000777bb65de0dd  movaps [rsp+0x20], xmm3
0000777bb65de0e2  lea rdi, [rsp]
0000777bb65de0e6  mov esi, 0x00
0000777bb65de0eb  mov rax, 0x569DC437B530
0000777bb65de0f5  call rax
0000777bb65de0f7  movaps xmm15, [rsp]
0000777bb65de0fc  add rsp, 0x30
0000777bb65de100  vmovaps xmm0, [rsp]
0000777bb65de105  vmovaps xmm1, [rsp+0x10]
0000777bb65de10b  vmovaps xmm2, [rsp+0x20]
0000777bb65de111  vmovaps xmm3, [rsp+0x30]
0000777bb65de117  vmovaps xmm4, [rsp+0x40]
0000777bb65de11d  vmovaps xmm5, [rsp+0x50]
0000777bb65de123  vmovaps xmm6, [rsp+0x60]
0000777bb65de129  vmovaps xmm7, [rsp+0x70]
0000777bb65de12f  vmovaps xmm8, [rsp+0x80]
0000777bb65de138  vmovaps xmm9, [rsp+0x90]
0000777bb65de141  vmovaps xmm10, [rsp+0xA0]
0000777bb65de14a  vmovaps xmm11, [rsp+0xB0]
0000777bb65de153  vmovaps xmm12, [rsp+0xC0]
0000777bb65de15c  vmovaps xmm13, [rsp+0xD0]
0000777bb65de165  vmovaps xmm14, [rsp+0xE0]
0000777bb65de16e  add rsp, 0xF0
0000777bb65de175  pop r11
0000777bb65de177  pop r10
0000777bb65de179  pop r9
0000777bb65de17b  pop r8
0000777bb65de17d  pop rsi
0000777bb65de17e  pop rdi
0000777bb65de17f  pop rdx
0000777bb65de180  pop rcx
0000777bb65de181  pop rax
0000777bb65de182  add rsp, 0x08
0000777bb65de186  jmp 0x0000777BB65DC099
0000777bb65de18b  sub rsp, 0x08
0000777bb65de18f  push rax
0000777bb65de190  push rcx
0000777bb65de191  push rdx
0000777bb65de192  push rdi
0000777bb65de193  push rsi
0000777bb65de194  push r8
0000777bb65de196  push r9
0000777bb65de198  push r10
0000777bb65de19a  push r11
0000777bb65de19c  sub rsp, 0xF0
0000777bb65de1a3  vmovaps [rsp], xmm0
0000777bb65de1a8  vmovaps [rsp+0x10], xmm2
0000777bb65de1ae  vmovaps [rsp+0x20], xmm3
0000777bb65de1b4  vmovaps [rsp+0x30], xmm4
0000777bb65de1ba  vmovaps [rsp+0x40], xmm5
0000777bb65de1c0  vmovaps [rsp+0x50], xmm6
0000777bb65de1c6  vmovaps [rsp+0x60], xmm7
0000777bb65de1cc  vmovaps [rsp+0x70], xmm8
0000777bb65de1d2  vmovaps [rsp+0x80], xmm9
0000777bb65de1db  vmovaps [rsp+0x90], xmm10
0000777bb65de1e4  vmovaps [rsp+0xA0], xmm11
0000777bb65de1ed  vmovaps [rsp+0xB0], xmm12
0000777bb65de1f6  vmovaps [rsp+0xC0], xmm13
0000777bb65de1ff  vmovaps [rsp+0xD0], xmm14
0000777bb65de208  vmovaps [rsp+0xE0], xmm15
0000777bb65de211  sub rsp, 0x30
0000777bb65de215  movaps [rsp], xmm1
0000777bb65de219  movaps [rsp+0x10], xmm5
0000777bb65de21e  movaps [rsp+0x20], xmm4
0000777bb65de223  lea rdi, [rsp]
0000777bb65de227  mov esi, 0x00
0000777bb65de22c  mov rax, 0x569DC437B530
0000777bb65de236  call rax
0000777bb65de238  movaps xmm1, [rsp]
0000777bb65de23c  add rsp, 0x30
0000777bb65de240  vmovaps xmm0, [rsp]
0000777bb65de245  vmovaps xmm2, [rsp+0x10]
0000777bb65de24b  vmovaps xmm3, [rsp+0x20]
0000777bb65de251  vmovaps xmm4, [rsp+0x30]
0000777bb65de257  vmovaps xmm5, [rsp+0x40]
0000777bb65de25d  vmovaps xmm6, [rsp+0x50]
0000777bb65de263  vmovaps xmm7, [rsp+0x60]
0000777bb65de269  vmovaps xmm8, [rsp+0x70]
0000777bb65de26f  vmovaps xmm9, [rsp+0x80]
0000777bb65de278  vmovaps xmm10, [rsp+0x90]
0000777bb65de281  vmovaps xmm11, [rsp+0xA0]
0000777bb65de28a  vmovaps xmm12, [rsp+0xB0]
0000777bb65de293  vmovaps xmm13, [rsp+0xC0]
0000777bb65de29c  vmovaps xmm14, [rsp+0xD0]
0000777bb65de2a5  vmovaps xmm15, [rsp+0xE0]
0000777bb65de2ae  add rsp, 0xF0
0000777bb65de2b5  pop r11
0000777bb65de2b7  pop r10
0000777bb65de2b9  pop r9
0000777bb65de2bb  pop r8
0000777bb65de2bd  pop rsi
0000777bb65de2be  pop rdi
0000777bb65de2bf  pop rdx
0000777bb65de2c0  pop rcx
0000777bb65de2c1  pop rax
0000777bb65de2c2  add rsp, 0x08
0000777bb65de2c6  jmp 0x0000777BB65DC0B9
0000777bb65de2cb  sub rsp, 0x08
0000777bb65de2cf  push rax
0000777bb65de2d0  push rcx
0000777bb65de2d1  push rdx
0000777bb65de2d2  push rdi
0000777bb65de2d3  push rsi
0000777bb65de2d4  push r8
0000777bb65de2d6  push r9
0000777bb65de2d8  push r10
0000777bb65de2da  push r11
0000777bb65de2dc  sub rsp, 0xF0
0000777bb65de2e3  vmovaps [rsp], xmm0
0000777bb65de2e8  vmovaps [rsp+0x10], xmm1
0000777bb65de2ee  vmovaps [rsp+0x20], xmm2
0000777bb65de2f4  vmovaps [rsp+0x30], xmm3
0000777bb65de2fa  vmovaps [rsp+0x40], xmm5
0000777bb65de300  vmovaps [rsp+0x50], xmm6
0000777bb65de306  vmovaps [rsp+0x60], xmm7
0000777bb65de30c  vmovaps [rsp+0x70], xmm8
0000777bb65de312  vmovaps [rsp+0x80], xmm9
0000777bb65de31b  vmovaps [rsp+0x90], xmm10
0000777bb65de324  vmovaps [rsp+0xA0], xmm11
0000777bb65de32d  vmovaps [rsp+0xB0], xmm12
0000777bb65de336  vmovaps [rsp+0xC0], xmm13
0000777bb65de33f  vmovaps [rsp+0xD0], xmm14
0000777bb65de348  vmovaps [rsp+0xE0], xmm15
0000777bb65de351  sub rsp, 0x30
0000777bb65de355  movaps [rsp], xmm4
0000777bb65de359  movaps [rsp+0x10], xmm3
0000777bb65de35e  movaps [rsp+0x20], xmm5
0000777bb65de363  lea rdi, [rsp]
0000777bb65de367  mov esi, 0x00
0000777bb65de36c  mov rax, 0x569DC437B530
0000777bb65de376  call rax
0000777bb65de378  movaps xmm4, [rsp]
0000777bb65de37c  add rsp, 0x30
0000777bb65de380  vmovaps xmm0, [rsp]
0000777bb65de385  vmovaps xmm1, [rsp+0x10]
0000777bb65de38b  vmovaps xmm2, [rsp+0x20]
0000777bb65de391  vmovaps xmm3, [rsp+0x30]
0000777bb65de397  vmovaps xmm5, [rsp+0x40]
0000777bb65de39d  vmovaps xmm6, [rsp+0x50]
0000777bb65de3a3  vmovaps xmm7, [rsp+0x60]
0000777bb65de3a9  vmovaps xmm8, [rsp+0x70]
0000777bb65de3af  vmovaps xmm9, [rsp+0x80]
0000777bb65de3b8  vmovaps xmm10, [rsp+0x90]
0000777bb65de3c1  vmovaps xmm11, [rsp+0xA0]
0000777bb65de3ca  vmovaps xmm12, [rsp+0xB0]
0000777bb65de3d3  vmovaps xmm13, [rsp+0xC0]
0000777bb65de3dc  vmovaps xmm14, [rsp+0xD0]
0000777bb65de3e5  vmovaps xmm15, [rsp+0xE0]
0000777bb65de3ee  add rsp, 0xF0
0000777bb65de3f5  pop r11
0000777bb65de3f7  pop r10
0000777bb65de3f9  pop r9
0000777bb65de3fb  pop r8
0000777bb65de3fd  pop rsi
0000777bb65de3fe  pop rdi
0000777bb65de3ff  pop rdx
0000777bb65de400  pop rcx
0000777bb65de401  pop rax
0000777bb65de402  add rsp, 0x08
0000777bb65de406  jmp 0x0000777BB65DC107
0000777bb65de40b  call 0x0000777BB64B52F0
0000777bb65de410  jmp 0x0000777BB65DC114
0000777bb65de415  sub rsp, 0x08
0000777bb65de419  push rax
0000777bb65de41a  push rcx
0000777bb65de41b  push rdx
0000777bb65de41c  push rdi
0000777bb65de41d  push rsi
0000777bb65de41e  push r8
0000777bb65de420  push r9
0000777bb65de422  push r10
0000777bb65de424  push r11
0000777bb65de426  sub rsp, 0xF0
0000777bb65de42d  vmovaps [rsp], xmm0
0000777bb65de432  vmovaps [rsp+0x10], xmm1
0000777bb65de438  vmovaps [rsp+0x20], xmm2
0000777bb65de43e  vmovaps [rsp+0x30], xmm3
0000777bb65de444  vmovaps [rsp+0x40], xmm4
0000777bb65de44a  vmovaps [rsp+0x50], xmm6
0000777bb65de450  vmovaps [rsp+0x60], xmm7
0000777bb65de456  vmovaps [rsp+0x70], xmm8
0000777bb65de45c  vmovaps [rsp+0x80], xmm9
0000777bb65de465  vmovaps [rsp+0x90], xmm10
0000777bb65de46e  vmovaps [rsp+0xA0], xmm11
0000777bb65de477  vmovaps [rsp+0xB0], xmm12
0000777bb65de480  vmovaps [rsp+0xC0], xmm13
0000777bb65de489  vmovaps [rsp+0xD0], xmm14
0000777bb65de492  vmovaps [rsp+0xE0], xmm15
0000777bb65de49b  sub rsp, 0x30
0000777bb65de49f  movaps [rsp], xmm5
0000777bb65de4a3  movaps [rsp+0x10], xmm6
0000777bb65de4a8  movaps [rsp+0x20], xmm3
0000777bb65de4ad  lea rdi, [rsp]
0000777bb65de4b1  mov esi, 0x00
0000777bb65de4b6  mov rax, 0x569DC437B530
0000777bb65de4c0  call rax
0000777bb65de4c2  movaps xmm5, [rsp]
0000777bb65de4c6  add rsp, 0x30
0000777bb65de4ca  vmovaps xmm0, [rsp]
0000777bb65de4cf  vmovaps xmm1, [rsp+0x10]
0000777bb65de4d5  vmovaps xmm2, [rsp+0x20]
0000777bb65de4db  vmovaps xmm3, [rsp+0x30]
0000777bb65de4e1  vmovaps xmm4, [rsp+0x40]
0000777bb65de4e7  vmovaps xmm6, [rsp+0x50]
0000777bb65de4ed  vmovaps xmm7, [rsp+0x60]
0000777bb65de4f3  vmovaps xmm8, [rsp+0x70]
0000777bb65de4f9  vmovaps xmm9, [rsp+0x80]
0000777bb65de502  vmovaps xmm10, [rsp+0x90]
0000777bb65de50b  vmovaps xmm11, [rsp+0xA0]
0000777bb65de514  vmovaps xmm12, [rsp+0xB0]
0000777bb65de51d  vmovaps xmm13, [rsp+0xC0]
0000777bb65de526  vmovaps xmm14, [rsp+0xD0]
0000777bb65de52f  vmovaps xmm15, [rsp+0xE0]
0000777bb65de538  add rsp, 0xF0
0000777bb65de53f  pop r11
0000777bb65de541  pop r10
0000777bb65de543  pop r9
0000777bb65de545  pop r8
0000777bb65de547  pop rsi
0000777bb65de548  pop rdi
0000777bb65de549  pop rdx
0000777bb65de54a  pop rcx
0000777bb65de54b  pop rax
0000777bb65de54c  add rsp, 0x08
0000777bb65de550  jmp 0x0000777BB65DC13A
0000777bb65de555  sub rsp, 0x08
0000777bb65de559  push rax
0000777bb65de55a  push rcx
0000777bb65de55b  push rdx
0000777bb65de55c  push rdi
0000777bb65de55d  push rsi
0000777bb65de55e  push r8
0000777bb65de560  push r9
0000777bb65de562  push r10
0000777bb65de564  push r11
0000777bb65de566  sub rsp, 0xF0
0000777bb65de56d  vmovaps [rsp], xmm0
0000777bb65de572  vmovaps [rsp+0x10], xmm1
0000777bb65de578  vmovaps [rsp+0x20], xmm2
0000777bb65de57e  vmovaps [rsp+0x30], xmm3
0000777bb65de584  vmovaps [rsp+0x40], xmm4
0000777bb65de58a  vmovaps [rsp+0x50], xmm5
0000777bb65de590  vmovaps [rsp+0x60], xmm7
0000777bb65de596  vmovaps [rsp+0x70], xmm8
0000777bb65de59c  vmovaps [rsp+0x80], xmm9
0000777bb65de5a5  vmovaps [rsp+0x90], xmm10
0000777bb65de5ae  vmovaps [rsp+0xA0], xmm11
0000777bb65de5b7  vmovaps [rsp+0xB0], xmm12
0000777bb65de5c0  vmovaps [rsp+0xC0], xmm13
0000777bb65de5c9  vmovaps [rsp+0xD0], xmm14
0000777bb65de5d2  vmovaps [rsp+0xE0], xmm15
0000777bb65de5db  sub rsp, 0x30
0000777bb65de5df  movaps [rsp], xmm6
0000777bb65de5e3  movaps [rsp+0x10], xmm9
0000777bb65de5e9  movaps [rsp+0x20], xmm1
0000777bb65de5ee  lea rdi, [rsp]
0000777bb65de5f2  mov esi, 0x00
0000777bb65de5f7  mov rax, 0x569DC437B530
0000777bb65de601  call rax
0000777bb65de603  movaps xmm6, [rsp]
0000777bb65de607  add rsp, 0x30
0000777bb65de60b  vmovaps xmm0, [rsp]
0000777bb65de610  vmovaps xmm1, [rsp+0x10]
0000777bb65de616  vmovaps xmm2, [rsp+0x20]
0000777bb65de61c  vmovaps xmm3, [rsp+0x30]
0000777bb65de622  vmovaps xmm4, [rsp+0x40]
0000777bb65de628  vmovaps xmm5, [rsp+0x50]
0000777bb65de62e  vmovaps xmm7, [rsp+0x60]
0000777bb65de634  vmovaps xmm8, [rsp+0x70]
0000777bb65de63a  vmovaps xmm9, [rsp+0x80]
0000777bb65de643  vmovaps xmm10, [rsp+0x90]
0000777bb65de64c  vmovaps xmm11, [rsp+0xA0]
0000777bb65de655  vmovaps xmm12, [rsp+0xB0]
0000777bb65de65e  vmovaps xmm13, [rsp+0xC0]
0000777bb65de667  vmovaps xmm14, [rsp+0xD0]
0000777bb65de670  vmovaps xmm15, [rsp+0xE0]
0000777bb65de679  add rsp, 0xF0
0000777bb65de680  pop r11
0000777bb65de682  pop r10
0000777bb65de684  pop r9
0000777bb65de686  pop r8
0000777bb65de688  pop rsi
0000777bb65de689  pop rdi
0000777bb65de68a  pop rdx
0000777bb65de68b  pop rcx
0000777bb65de68c  pop rax
0000777bb65de68d  add rsp, 0x08
0000777bb65de691  jmp 0x0000777BB65DC15E
0000777bb65de696  sub rsp, 0x08
0000777bb65de69a  push rax
0000777bb65de69b  push rcx
0000777bb65de69c  push rdx
0000777bb65de69d  push rdi
0000777bb65de69e  push rsi
0000777bb65de69f  push r8
0000777bb65de6a1  push r9
0000777bb65de6a3  push r10
0000777bb65de6a5  push r11
0000777bb65de6a7  sub rsp, 0xF0
0000777bb65de6ae  vmovaps [rsp], xmm0
0000777bb65de6b3  vmovaps [rsp+0x10], xmm1
0000777bb65de6b9  vmovaps [rsp+0x20], xmm2
0000777bb65de6bf  vmovaps [rsp+0x30], xmm3
0000777bb65de6c5  vmovaps [rsp+0x40], xmm4
0000777bb65de6cb  vmovaps [rsp+0x50], xmm5
0000777bb65de6d1  vmovaps [rsp+0x60], xmm6
0000777bb65de6d7  vmovaps [rsp+0x70], xmm7
0000777bb65de6dd  vmovaps [rsp+0x80], xmm8
0000777bb65de6e6  vmovaps [rsp+0x90], xmm10
0000777bb65de6ef  vmovaps [rsp+0xA0], xmm11
0000777bb65de6f8  vmovaps [rsp+0xB0], xmm12
0000777bb65de701  vmovaps [rsp+0xC0], xmm13
0000777bb65de70a  vmovaps [rsp+0xD0], xmm14
0000777bb65de713  vmovaps [rsp+0xE0], xmm15
0000777bb65de71c  sub rsp, 0x30
0000777bb65de720  movaps [rsp], xmm9
0000777bb65de725  movaps [rsp+0x10], xmm3
0000777bb65de72a  movaps [rsp+0x20], xmm1
0000777bb65de72f  lea rdi, [rsp]
0000777bb65de733  mov esi, 0x00
0000777bb65de738  mov rax, 0x569DC437B530
0000777bb65de742  call rax
0000777bb65de744  movaps xmm9, [rsp]
0000777bb65de749  add rsp, 0x30
0000777bb65de74d  vmovaps xmm0, [rsp]
0000777bb65de752  vmovaps xmm1, [rsp+0x10]
0000777bb65de758  vmovaps xmm2, [rsp+0x20]
0000777bb65de75e  vmovaps xmm3, [rsp+0x30]
0000777bb65de764  vmovaps xmm4, [rsp+0x40]
0000777bb65de76a  vmovaps xmm5, [rsp+0x50]
0000777bb65de770  vmovaps xmm6, [rsp+0x60]
0000777bb65de776  vmovaps xmm7, [rsp+0x70]
0000777bb65de77c  vmovaps xmm8, [rsp+0x80]
0000777bb65de785  vmovaps xmm10, [rsp+0x90]
0000777bb65de78e  vmovaps xmm11, [rsp+0xA0]
0000777bb65de797  vmovaps xmm12, [rsp+0xB0]
0000777bb65de7a0  vmovaps xmm13, [rsp+0xC0]
0000777bb65de7a9  vmovaps xmm14, [rsp+0xD0]
0000777bb65de7b2  vmovaps xmm15, [rsp+0xE0]
0000777bb65de7bb  add rsp, 0xF0
0000777bb65de7c2  pop r11
0000777bb65de7c4  pop r10
0000777bb65de7c6  pop r9
0000777bb65de7c8  pop r8
0000777bb65de7ca  pop rsi
0000777bb65de7cb  pop rdi
0000777bb65de7cc  pop rdx
0000777bb65de7cd  pop rcx
0000777bb65de7ce  pop rax
0000777bb65de7cf  add rsp, 0x08
0000777bb65de7d3  jmp 0x0000777BB65DC1AA
0000777bb65de7d8  call 0x0000777BB64B52F0
0000777bb65de7dd  jmp 0x0000777BB65DC1B7
0000777bb65de7e2  sub rsp, 0x08
0000777bb65de7e6  push rax
0000777bb65de7e7  push rcx
0000777bb65de7e8  push rdx
0000777bb65de7e9  push rdi
0000777bb65de7ea  push rsi
0000777bb65de7eb  push r8
0000777bb65de7ed  push r9
0000777bb65de7ef  push r10
0000777bb65de7f1  push r11
0000777bb65de7f3  sub rsp, 0xF0
0000777bb65de7fa  vmovaps [rsp], xmm0
0000777bb65de7ff  vmovaps [rsp+0x10], xmm1
0000777bb65de805  vmovaps [rsp+0x20], xmm2
0000777bb65de80b  vmovaps [rsp+0x30], xmm3
0000777bb65de811  vmovaps [rsp+0x40], xmm4
0000777bb65de817  vmovaps [rsp+0x50], xmm5
0000777bb65de81d  vmovaps [rsp+0x60], xmm6
0000777bb65de823  vmovaps [rsp+0x70], xmm7
0000777bb65de829  vmovaps [rsp+0x80], xmm8
0000777bb65de832  vmovaps [rsp+0x90], xmm9
0000777bb65de83b  vmovaps [rsp+0xA0], xmm10
0000777bb65de844  vmovaps [rsp+0xB0], xmm11
0000777bb65de84d  vmovaps [rsp+0xC0], xmm12
0000777bb65de856  vmovaps [rsp+0xD0], xmm13
0000777bb65de85f  vmovaps [rsp+0xE0], xmm14
0000777bb65de868  sub rsp, 0x30
0000777bb65de86c  movaps [rsp], xmm15
0000777bb65de871  movaps [rsp+0x10], xmm3
0000777bb65de876  movaps [rsp+0x20], xmm7
0000777bb65de87b  lea rdi, [rsp]
0000777bb65de87f  mov esi, 0x00
0000777bb65de884  mov rax, 0x569DC437B530
0000777bb65de88e  call rax
0000777bb65de890  movaps xmm15, [rsp]
0000777bb65de895  add rsp, 0x30
0000777bb65de899  vmovaps xmm0, [rsp]
0000777bb65de89e  vmovaps xmm1, [rsp+0x10]
0000777bb65de8a4  vmovaps xmm2, [rsp+0x20]
0000777bb65de8aa  vmovaps xmm3, [rsp+0x30]
0000777bb65de8b0  vmovaps xmm4, [rsp+0x40]
0000777bb65de8b6  vmovaps xmm5, [rsp+0x50]
0000777bb65de8bc  vmovaps xmm6, [rsp+0x60]
0000777bb65de8c2  vmovaps xmm7, [rsp+0x70]
0000777bb65de8c8  vmovaps xmm8, [rsp+0x80]
0000777bb65de8d1  vmovaps xmm9, [rsp+0x90]
0000777bb65de8da  vmovaps xmm10, [rsp+0xA0]
0000777bb65de8e3  vmovaps xmm11, [rsp+0xB0]
0000777bb65de8ec  vmovaps xmm12, [rsp+0xC0]
0000777bb65de8f5  vmovaps xmm13, [rsp+0xD0]
0000777bb65de8fe  vmovaps xmm14, [rsp+0xE0]
0000777bb65de907  add rsp, 0xF0
0000777bb65de90e  pop r11
0000777bb65de910  pop r10
0000777bb65de912  pop r9
0000777bb65de914  pop r8
0000777bb65de916  pop rsi
0000777bb65de917  pop rdi
0000777bb65de918  pop rdx
0000777bb65de919  pop rcx
0000777bb65de91a  pop rax
0000777bb65de91b  add rsp, 0x08
0000777bb65de91f  jmp 0x0000777BB65DC1E3
0000777bb65de924  sub rsp, 0x08
0000777bb65de928  push rax
0000777bb65de929  push rcx
0000777bb65de92a  push rdx
0000777bb65de92b  push rdi
0000777bb65de92c  push rsi
0000777bb65de92d  push r8
0000777bb65de92f  push r9
0000777bb65de931  push r10
0000777bb65de933  push r11
0000777bb65de935  sub rsp, 0xF0
0000777bb65de93c  vmovaps [rsp], xmm0
0000777bb65de941  vmovaps [rsp+0x10], xmm1
0000777bb65de947  vmovaps [rsp+0x20], xmm2
0000777bb65de94d  vmovaps [rsp+0x30], xmm4
0000777bb65de953  vmovaps [rsp+0x40], xmm5
0000777bb65de959  vmovaps [rsp+0x50], xmm6
0000777bb65de95f  vmovaps [rsp+0x60], xmm7
0000777bb65de965  vmovaps [rsp+0x70], xmm8
0000777bb65de96b  vmovaps [rsp+0x80], xmm9
0000777bb65de974  vmovaps [rsp+0x90], xmm10
0000777bb65de97d  vmovaps [rsp+0xA0], xmm11
0000777bb65de986  vmovaps [rsp+0xB0], xmm12
0000777bb65de98f  vmovaps [rsp+0xC0], xmm13
0000777bb65de998  vmovaps [rsp+0xD0], xmm14
0000777bb65de9a1  vmovaps [rsp+0xE0], xmm15
0000777bb65de9aa  sub rsp, 0x30
0000777bb65de9ae  movaps [rsp], xmm3
0000777bb65de9b2  movaps [rsp+0x10], xmm1
0000777bb65de9b7  movaps [rsp+0x20], xmm15
0000777bb65de9bd  lea rdi, [rsp]
0000777bb65de9c1  mov esi, 0x00
0000777bb65de9c6  mov rax, 0x569DC437B530
0000777bb65de9d0  call rax
0000777bb65de9d2  movaps xmm3, [rsp]
0000777bb65de9d6  add rsp, 0x30
0000777bb65de9da  vmovaps xmm0, [rsp]
0000777bb65de9df  vmovaps xmm1, [rsp+0x10]
0000777bb65de9e5  vmovaps xmm2, [rsp+0x20]
0000777bb65de9eb  vmovaps xmm4, [rsp+0x30]
0000777bb65de9f1  vmovaps xmm5, [rsp+0x40]
0000777bb65de9f7  vmovaps xmm6, [rsp+0x50]
0000777bb65de9fd  vmovaps xmm7, [rsp+0x60]
0000777bb65dea03  vmovaps xmm8, [rsp+0x70]
0000777bb65dea09  vmovaps xmm9, [rsp+0x80]
0000777bb65dea12  vmovaps xmm10, [rsp+0x90]
0000777bb65dea1b  vmovaps xmm11, [rsp+0xA0]
0000777bb65dea24  vmovaps xmm12, [rsp+0xB0]
0000777bb65dea2d  vmovaps xmm13, [rsp+0xC0]
0000777bb65dea36  vmovaps xmm14, [rsp+0xD0]
0000777bb65dea3f  vmovaps xmm15, [rsp+0xE0]
0000777bb65dea48  add rsp, 0xF0
0000777bb65dea4f  pop r11
0000777bb65dea51  pop r10
0000777bb65dea53  pop r9
0000777bb65dea55  pop r8
0000777bb65dea57  pop rsi
0000777bb65dea58  pop rdi
0000777bb65dea59  pop rdx
0000777bb65dea5a  pop rcx
0000777bb65dea5b  pop rax
0000777bb65dea5c  add rsp, 0x08
0000777bb65dea60  jmp 0x0000777BB65DC272
0000777bb65dea65  call 0x0000777BB64B52F0
0000777bb65dea6a  jmp 0x0000777BB65DC27C
0000777bb65dea6f  sub rsp, 0x08
0000777bb65dea73  push rax
0000777bb65dea74  push rcx
0000777bb65dea75  push rdx
0000777bb65dea76  push rdi
0000777bb65dea77  push rsi
0000777bb65dea78  push r8
0000777bb65dea7a  push r9
0000777bb65dea7c  push r10
0000777bb65dea7e  push r11
0000777bb65dea80  sub rsp, 0xF0
0000777bb65dea87  vmovaps [rsp], xmm0
0000777bb65dea8c  vmovaps [rsp+0x10], xmm1
0000777bb65dea92  vmovaps [rsp+0x20], xmm2
0000777bb65dea98  vmovaps [rsp+0x30], xmm3
0000777bb65dea9e  vmovaps [rsp+0x40], xmm4
0000777bb65deaa4  vmovaps [rsp+0x50], xmm5
0000777bb65deaaa  vmovaps [rsp+0x60], xmm6
0000777bb65deab0  vmovaps [rsp+0x70], xmm7
0000777bb65deab6  vmovaps [rsp+0x80], xmm8
0000777bb65deabf  vmovaps [rsp+0x90], xmm9
0000777bb65deac8  vmovaps [rsp+0xA0], xmm10
0000777bb65dead1  vmovaps [rsp+0xB0], xmm11
0000777bb65deada  vmovaps [rsp+0xC0], xmm12
0000777bb65deae3  vmovaps [rsp+0xD0], xmm13
0000777bb65deaec  vmovaps [rsp+0xE0], xmm14
0000777bb65deaf5  sub rsp, 0x30
0000777bb65deaf9  movaps [rsp], xmm15
0000777bb65deafe  movaps [rsp+0x10], xmm14
0000777bb65deb04  movaps [rsp+0x20], xmm4
0000777bb65deb09  lea rdi, [rsp]
0000777bb65deb0d  mov esi, 0x00
0000777bb65deb12  mov rax, 0x569DC437B530
0000777bb65deb1c  call rax
0000777bb65deb1e  movaps xmm15, [rsp]
0000777bb65deb23  add rsp, 0x30
0000777bb65deb27  vmovaps xmm0, [rsp]
0000777bb65deb2c  vmovaps xmm1, [rsp+0x10]
0000777bb65deb32  vmovaps xmm2, [rsp+0x20]
0000777bb65deb38  vmovaps xmm3, [rsp+0x30]
0000777bb65deb3e  vmovaps xmm4, [rsp+0x40]
0000777bb65deb44  vmovaps xmm5, [rsp+0x50]
0000777bb65deb4a  vmovaps xmm6, [rsp+0x60]
0000777bb65deb50  vmovaps xmm7, [rsp+0x70]
0000777bb65deb56  vmovaps xmm8, [rsp+0x80]
0000777bb65deb5f  vmovaps xmm9, [rsp+0x90]
0000777bb65deb68  vmovaps xmm10, [rsp+0xA0]
0000777bb65deb71  vmovaps xmm11, [rsp+0xB0]
0000777bb65deb7a  vmovaps xmm12, [rsp+0xC0]
0000777bb65deb83  vmovaps xmm13, [rsp+0xD0]
0000777bb65deb8c  vmovaps xmm14, [rsp+0xE0]
0000777bb65deb95  add rsp, 0xF0
0000777bb65deb9c  pop r11
0000777bb65deb9e  pop r10
0000777bb65deba0  pop r9
0000777bb65deba2  pop r8
0000777bb65deba4  pop rsi
0000777bb65deba5  pop rdi
0000777bb65deba6  pop rdx
0000777bb65deba7  pop rcx
0000777bb65deba8  pop rax
0000777bb65deba9  add rsp, 0x08
0000777bb65debad  jmp 0x0000777BB65DC2AA
0000777bb65debb2  sub rsp, 0x08
0000777bb65debb6  push rax
0000777bb65debb7  push rcx
0000777bb65debb8  push rdx
0000777bb65debb9  push rdi
0000777bb65debba  push rsi
0000777bb65debbb  push r8
0000777bb65debbd  push r9
0000777bb65debbf  push r10
0000777bb65debc1  push r11
0000777bb65debc3  sub rsp, 0xF0
0000777bb65debca  vmovaps [rsp], xmm0
0000777bb65debcf  vmovaps [rsp+0x10], xmm1
0000777bb65debd5  vmovaps [rsp+0x20], xmm2
0000777bb65debdb  vmovaps [rsp+0x30], xmm3
0000777bb65debe1  vmovaps [rsp+0x40], xmm4
0000777bb65debe7  vmovaps [rsp+0x50], xmm5
0000777bb65debed  vmovaps [rsp+0x60], xmm6
0000777bb65debf3  vmovaps [rsp+0x70], xmm7
0000777bb65debf9  vmovaps [rsp+0x80], xmm8
0000777bb65dec02  vmovaps [rsp+0x90], xmm9
0000777bb65dec0b  vmovaps [rsp+0xA0], xmm10
0000777bb65dec14  vmovaps [rsp+0xB0], xmm11
0000777bb65dec1d  vmovaps [rsp+0xC0], xmm12
0000777bb65dec26  vmovaps [rsp+0xD0], xmm13
0000777bb65dec2f  vmovaps [rsp+0xE0], xmm15
0000777bb65dec38  sub rsp, 0x30
0000777bb65dec3c  movaps [rsp], xmm14
0000777bb65dec41  movaps [rsp+0x10], xmm2
0000777bb65dec46  movaps [rsp+0x20], xmm1
0000777bb65dec4b  lea rdi, [rsp]
0000777bb65dec4f  mov esi, 0x00
0000777bb65dec54  mov rax, 0x569DC437B530
0000777bb65dec5e  call rax
0000777bb65dec60  movaps xmm14, [rsp]
0000777bb65dec65  add rsp, 0x30
0000777bb65dec69  vmovaps xmm0, [rsp]
0000777bb65dec6e  vmovaps xmm1, [rsp+0x10]
0000777bb65dec74  vmovaps xmm2, [rsp+0x20]
0000777bb65dec7a  vmovaps xmm3, [rsp+0x30]
0000777bb65dec80  vmovaps xmm4, [rsp+0x40]
0000777bb65dec86  vmovaps xmm5, [rsp+0x50]
0000777bb65dec8c  vmovaps xmm6, [rsp+0x60]
0000777bb65dec92  vmovaps xmm7, [rsp+0x70]
0000777bb65dec98  vmovaps xmm8, [rsp+0x80]
0000777bb65deca1  vmovaps xmm9, [rsp+0x90]
0000777bb65decaa  vmovaps xmm10, [rsp+0xA0]
0000777bb65decb3  vmovaps xmm11, [rsp+0xB0]
0000777bb65decbc  vmovaps xmm12, [rsp+0xC0]
0000777bb65decc5  vmovaps xmm13, [rsp+0xD0]
0000777bb65decce  vmovaps xmm15, [rsp+0xE0]
0000777bb65decd7  add rsp, 0xF0
0000777bb65decde  pop r11
0000777bb65dece0  pop r10
0000777bb65dece2  pop r9
0000777bb65dece4  pop r8
0000777bb65dece6  pop rsi
0000777bb65dece7  pop rdi
0000777bb65dece8  pop rdx
0000777bb65dece9  pop rcx
0000777bb65decea  pop rax
0000777bb65deceb  add rsp, 0x08
0000777bb65decef  jmp 0x0000777BB65DC2D0
0000777bb65decf4  sub rsp, 0x08
0000777bb65decf8  push rax
0000777bb65decf9  push rcx
0000777bb65decfa  push rdx
0000777bb65decfb  push rdi
0000777bb65decfc  push rsi
0000777bb65decfd  push r8
0000777bb65decff  push r9
0000777bb65ded01  push r10
0000777bb65ded03  push r11
0000777bb65ded05  sub rsp, 0xF0
0000777bb65ded0c  vmovaps [rsp], xmm0
0000777bb65ded11  vmovaps [rsp+0x10], xmm2
0000777bb65ded17  vmovaps [rsp+0x20], xmm3
0000777bb65ded1d  vmovaps [rsp+0x30], xmm4
0000777bb65ded23  vmovaps [rsp+0x40], xmm5
0000777bb65ded29  vmovaps [rsp+0x50], xmm6
0000777bb65ded2f  vmovaps [rsp+0x60], xmm7
0000777bb65ded35  vmovaps [rsp+0x70], xmm8
0000777bb65ded3b  vmovaps [rsp+0x80], xmm9
0000777bb65ded44  vmovaps [rsp+0x90], xmm10
0000777bb65ded4d  vmovaps [rsp+0xA0], xmm11
0000777bb65ded56  vmovaps [rsp+0xB0], xmm12
0000777bb65ded5f  vmovaps [rsp+0xC0], xmm13
0000777bb65ded68  vmovaps [rsp+0xD0], xmm14
0000777bb65ded71  vmovaps [rsp+0xE0], xmm15
0000777bb65ded7a  sub rsp, 0x30
0000777bb65ded7e  movaps [rsp], xmm1
0000777bb65ded82  movaps [rsp+0x10], xmm4
0000777bb65ded87  movaps [rsp+0x20], xmm9
0000777bb65ded8d  lea rdi, [rsp]
0000777bb65ded91  mov esi, 0x00
0000777bb65ded96  mov rax, 0x569DC437B530
0000777bb65deda0  call rax
0000777bb65deda2  movaps xmm1, [rsp]
0000777bb65deda6  add rsp, 0x30
0000777bb65dedaa  vmovaps xmm0, [rsp]
0000777bb65dedaf  vmovaps xmm2, [rsp+0x10]
0000777bb65dedb5  vmovaps xmm3, [rsp+0x20]
0000777bb65dedbb  vmovaps xmm4, [rsp+0x30]
0000777bb65dedc1  vmovaps xmm5, [rsp+0x40]
0000777bb65dedc7  vmovaps xmm6, [rsp+0x50]
0000777bb65dedcd  vmovaps xmm7, [rsp+0x60]
0000777bb65dedd3  vmovaps xmm8, [rsp+0x70]
0000777bb65dedd9  vmovaps xmm9, [rsp+0x80]
0000777bb65dede2  vmovaps xmm10, [rsp+0x90]
0000777bb65dedeb  vmovaps xmm11, [rsp+0xA0]
0000777bb65dedf4  vmovaps xmm12, [rsp+0xB0]
0000777bb65dedfd  vmovaps xmm13, [rsp+0xC0]
0000777bb65dee06  vmovaps xmm14, [rsp+0xD0]
0000777bb65dee0f  vmovaps xmm15, [rsp+0xE0]
0000777bb65dee18  add rsp, 0xF0
0000777bb65dee1f  pop r11
0000777bb65dee21  pop r10
0000777bb65dee23  pop r9
0000777bb65dee25  pop r8
0000777bb65dee27  pop rsi
0000777bb65dee28  pop rdi
0000777bb65dee29  pop rdx
0000777bb65dee2a  pop rcx
0000777bb65dee2b  pop rax
0000777bb65dee2c  add rsp, 0x08
0000777bb65dee30  jmp 0x0000777BB65DC2EE
0000777bb65dee35  sub rsp, 0x08
0000777bb65dee39  push rax
0000777bb65dee3a  push rcx
0000777bb65dee3b  push rdx
0000777bb65dee3c  push rdi
0000777bb65dee3d  push rsi
0000777bb65dee3e  push r8
0000777bb65dee40  push r9
0000777bb65dee42  push r10
0000777bb65dee44  push r11
0000777bb65dee46  sub rsp, 0xF0
0000777bb65dee4d  vmovaps [rsp], xmm0
0000777bb65dee52  vmovaps [rsp+0x10], xmm1
0000777bb65dee58  vmovaps [rsp+0x20], xmm2
0000777bb65dee5e  vmovaps [rsp+0x30], xmm3
0000777bb65dee64  vmovaps [rsp+0x40], xmm5
0000777bb65dee6a  vmovaps [rsp+0x50], xmm6
0000777bb65dee70  vmovaps [rsp+0x60], xmm7
0000777bb65dee76  vmovaps [rsp+0x70], xmm8
0000777bb65dee7c  vmovaps [rsp+0x80], xmm9
0000777bb65dee85  vmovaps [rsp+0x90], xmm10
0000777bb65dee8e  vmovaps [rsp+0xA0], xmm11
0000777bb65dee97  vmovaps [rsp+0xB0], xmm12
0000777bb65deea0  vmovaps [rsp+0xC0], xmm13
0000777bb65deea9  vmovaps [rsp+0xD0], xmm14
0000777bb65deeb2  vmovaps [rsp+0xE0], xmm15
0000777bb65deebb  sub rsp, 0x30
0000777bb65deebf  movaps [rsp], xmm4
0000777bb65deec3  movaps [rsp+0x10], xmm2
0000777bb65deec8  movaps [rsp+0x20], xmm9
0000777bb65deece  lea rdi, [rsp]
0000777bb65deed2  mov esi, 0x00
0000777bb65deed7  mov rax, 0x569DC437B530
0000777bb65deee1  call rax
0000777bb65deee3  movaps xmm4, [rsp]
0000777bb65deee7  add rsp, 0x30
0000777bb65deeeb  vmovaps xmm0, [rsp]
0000777bb65deef0  vmovaps xmm1, [rsp+0x10]
0000777bb65deef6  vmovaps xmm2, [rsp+0x20]
0000777bb65deefc  vmovaps xmm3, [rsp+0x30]
0000777bb65def02  vmovaps xmm5, [rsp+0x40]
0000777bb65def08  vmovaps xmm6, [rsp+0x50]
0000777bb65def0e  vmovaps xmm7, [rsp+0x60]
0000777bb65def14  vmovaps xmm8, [rsp+0x70]
0000777bb65def1a  vmovaps xmm9, [rsp+0x80]
0000777bb65def23  vmovaps xmm10, [rsp+0x90]
0000777bb65def2c  vmovaps xmm11, [rsp+0xA0]
0000777bb65def35  vmovaps xmm12, [rsp+0xB0]
0000777bb65def3e  vmovaps xmm13, [rsp+0xC0]
0000777bb65def47  vmovaps xmm14, [rsp+0xD0]
0000777bb65def50  vmovaps xmm15, [rsp+0xE0]
0000777bb65def59  add rsp, 0xF0
0000777bb65def60  pop r11
0000777bb65def62  pop r10
0000777bb65def64  pop r9
0000777bb65def66  pop r8
0000777bb65def68  pop rsi
0000777bb65def69  pop rdi
0000777bb65def6a  pop rdx
0000777bb65def6b  pop rcx
0000777bb65def6c  pop rax
0000777bb65def6d  add rsp, 0x08
0000777bb65def71  jmp 0x0000777BB65DC31E
0000777bb65def76  sub rsp, 0x08
0000777bb65def7a  push rax
0000777bb65def7b  push rcx
0000777bb65def7c  push rdx
0000777bb65def7d  push rdi
0000777bb65def7e  push rsi
0000777bb65def7f  push r8
0000777bb65def81  push r9
0000777bb65def83  push r10
0000777bb65def85  push r11
0000777bb65def87  sub rsp, 0xF0
0000777bb65def8e  vmovaps [rsp], xmm0
0000777bb65def93  vmovaps [rsp+0x10], xmm1
0000777bb65def99  vmovaps [rsp+0x20], xmm2
0000777bb65def9f  vmovaps [rsp+0x30], xmm3
0000777bb65defa5  vmovaps [rsp+0x40], xmm4
0000777bb65defab  vmovaps [rsp+0x50], xmm5
0000777bb65defb1  vmovaps [rsp+0x60], xmm6
0000777bb65defb7  vmovaps [rsp+0x70], xmm7
0000777bb65defbd  vmovaps [rsp+0x80], xmm8
0000777bb65defc6  vmovaps [rsp+0x90], xmm10
0000777bb65defcf  vmovaps [rsp+0xA0], xmm11
0000777bb65defd8  vmovaps [rsp+0xB0], xmm12
0000777bb65defe1  vmovaps [rsp+0xC0], xmm13
0000777bb65defea  vmovaps [rsp+0xD0], xmm14
0000777bb65deff3  vmovaps [rsp+0xE0], xmm15
0000777bb65deffc  sub rsp, 0x30
0000777bb65df000  movaps [rsp], xmm9
0000777bb65df005  movaps [rsp+0x10], xmm2
0000777bb65df00a  movaps [rsp+0x20], xmm1
0000777bb65df00f  lea rdi, [rsp]
0000777bb65df013  mov esi, 0x00
0000777bb65df018  mov rax, 0x569DC437B530
0000777bb65df022  call rax
0000777bb65df024  movaps xmm9, [rsp]
0000777bb65df029  add rsp, 0x30
0000777bb65df02d  vmovaps xmm0, [rsp]
0000777bb65df032  vmovaps xmm1, [rsp+0x10]
0000777bb65df038  vmovaps xmm2, [rsp+0x20]
0000777bb65df03e  vmovaps xmm3, [rsp+0x30]
0000777bb65df044  vmovaps xmm4, [rsp+0x40]
0000777bb65df04a  vmovaps xmm5, [rsp+0x50]
0000777bb65df050  vmovaps xmm6, [rsp+0x60]
0000777bb65df056  vmovaps xmm7, [rsp+0x70]
0000777bb65df05c  vmovaps xmm8, [rsp+0x80]
0000777bb65df065  vmovaps xmm10, [rsp+0x90]
0000777bb65df06e  vmovaps xmm11, [rsp+0xA0]
0000777bb65df077  vmovaps xmm12, [rsp+0xB0]
0000777bb65df080  vmovaps xmm13, [rsp+0xC0]
0000777bb65df089  vmovaps xmm14, [rsp+0xD0]
0000777bb65df092  vmovaps xmm15, [rsp+0xE0]
0000777bb65df09b  add rsp, 0xF0
0000777bb65df0a2  pop r11
0000777bb65df0a4  pop r10
0000777bb65df0a6  pop r9
0000777bb65df0a8  pop r8
0000777bb65df0aa  pop rsi
0000777bb65df0ab  pop rdi
0000777bb65df0ac  pop rdx
0000777bb65df0ad  pop rcx
0000777bb65df0ae  pop rax
0000777bb65df0af  add rsp, 0x08
0000777bb65df0b3  jmp 0x0000777BB65DC354
0000777bb65df0b8  sub rsp, 0x08
0000777bb65df0bc  push rax
0000777bb65df0bd  push rcx
0000777bb65df0be  push rdx
0000777bb65df0bf  push rdi
0000777bb65df0c0  push rsi
0000777bb65df0c1  push r8
0000777bb65df0c3  push r9
0000777bb65df0c5  push r10
0000777bb65df0c7  push r11
0000777bb65df0c9  sub rsp, 0xF0
0000777bb65df0d0  vmovaps [rsp], xmm0
0000777bb65df0d5  vmovaps [rsp+0x10], xmm2
0000777bb65df0db  vmovaps [rsp+0x20], xmm3
0000777bb65df0e1  vmovaps [rsp+0x30], xmm4
0000777bb65df0e7  vmovaps [rsp+0x40], xmm5
0000777bb65df0ed  vmovaps [rsp+0x50], xmm6
0000777bb65df0f3  vmovaps [rsp+0x60], xmm7
0000777bb65df0f9  vmovaps [rsp+0x70], xmm8
0000777bb65df0ff  vmovaps [rsp+0x80], xmm9
0000777bb65df108  vmovaps [rsp+0x90], xmm10
0000777bb65df111  vmovaps [rsp+0xA0], xmm11
0000777bb65df11a  vmovaps [rsp+0xB0], xmm12
0000777bb65df123  vmovaps [rsp+0xC0], xmm13
0000777bb65df12c  vmovaps [rsp+0xD0], xmm14
0000777bb65df135  vmovaps [rsp+0xE0], xmm15
0000777bb65df13e  sub rsp, 0x30
0000777bb65df142  movaps [rsp], xmm1
0000777bb65df146  movaps [rsp+0x10], xmm15
0000777bb65df14c  movaps [rsp+0x20], xmm6
0000777bb65df151  lea rdi, [rsp]
0000777bb65df155  mov esi, 0x00
0000777bb65df15a  mov rax, 0x569DC437B530
0000777bb65df164  call rax
0000777bb65df166  movaps xmm1, [rsp]
0000777bb65df16a  add rsp, 0x30
0000777bb65df16e  vmovaps xmm0, [rsp]
0000777bb65df173  vmovaps xmm2, [rsp+0x10]
0000777bb65df179  vmovaps xmm3, [rsp+0x20]
0000777bb65df17f  vmovaps xmm4, [rsp+0x30]
0000777bb65df185  vmovaps xmm5, [rsp+0x40]
0000777bb65df18b  vmovaps xmm6, [rsp+0x50]
0000777bb65df191  vmovaps xmm7, [rsp+0x60]
0000777bb65df197  vmovaps xmm8, [rsp+0x70]
0000777bb65df19d  vmovaps xmm9, [rsp+0x80]
0000777bb65df1a6  vmovaps xmm10, [rsp+0x90]
0000777bb65df1af  vmovaps xmm11, [rsp+0xA0]
0000777bb65df1b8  vmovaps xmm12, [rsp+0xB0]
0000777bb65df1c1  vmovaps xmm13, [rsp+0xC0]
0000777bb65df1ca  vmovaps xmm14, [rsp+0xD0]
0000777bb65df1d3  vmovaps xmm15, [rsp+0xE0]
0000777bb65df1dc  add rsp, 0xF0
0000777bb65df1e3  pop r11
0000777bb65df1e5  pop r10
0000777bb65df1e7  pop r9
0000777bb65df1e9  pop r8
0000777bb65df1eb  pop rsi
0000777bb65df1ec  pop rdi
0000777bb65df1ed  pop rdx
0000777bb65df1ee  pop rcx
0000777bb65df1ef  pop rax
0000777bb65df1f0  add rsp, 0x08
0000777bb65df1f4  jmp 0x0000777BB65DC375
0000777bb65df1f9  sub rsp, 0x08
0000777bb65df1fd  push rax
0000777bb65df1fe  push rcx
0000777bb65df1ff  push rdx
0000777bb65df200  push rdi
0000777bb65df201  push rsi
0000777bb65df202  push r8
0000777bb65df204  push r9
0000777bb65df206  push r10
0000777bb65df208  push r11
0000777bb65df20a  sub rsp, 0xF0
0000777bb65df211  vmovaps [rsp], xmm0
0000777bb65df216  vmovaps [rsp+0x10], xmm1
0000777bb65df21c  vmovaps [rsp+0x20], xmm2
0000777bb65df222  vmovaps [rsp+0x30], xmm3
0000777bb65df228  vmovaps [rsp+0x40], xmm4
0000777bb65df22e  vmovaps [rsp+0x50], xmm5
0000777bb65df234  vmovaps [rsp+0x60], xmm6
0000777bb65df23a  vmovaps [rsp+0x70], xmm7
0000777bb65df240  vmovaps [rsp+0x80], xmm8
0000777bb65df249  vmovaps [rsp+0x90], xmm9
0000777bb65df252  vmovaps [rsp+0xA0], xmm10
0000777bb65df25b  vmovaps [rsp+0xB0], xmm11
0000777bb65df264  vmovaps [rsp+0xC0], xmm12
0000777bb65df26d  vmovaps [rsp+0xD0], xmm13
0000777bb65df276  vmovaps [rsp+0xE0], xmm14
0000777bb65df27f  sub rsp, 0x30
0000777bb65df283  movaps [rsp], xmm15
0000777bb65df288  movaps [rsp+0x10], xmm5
0000777bb65df28d  movaps [rsp+0x20], xmm3
0000777bb65df292  lea rdi, [rsp]
0000777bb65df296  mov esi, 0x00
0000777bb65df29b  mov rax, 0x569DC437B530
0000777bb65df2a5  call rax
0000777bb65df2a7  movaps xmm15, [rsp]
0000777bb65df2ac  add rsp, 0x30
0000777bb65df2b0  vmovaps xmm0, [rsp]
0000777bb65df2b5  vmovaps xmm1, [rsp+0x10]
0000777bb65df2bb  vmovaps xmm2, [rsp+0x20]
0000777bb65df2c1  vmovaps xmm3, [rsp+0x30]
0000777bb65df2c7  vmovaps xmm4, [rsp+0x40]
0000777bb65df2cd  vmovaps xmm5, [rsp+0x50]
0000777bb65df2d3  vmovaps xmm6, [rsp+0x60]
0000777bb65df2d9  vmovaps xmm7, [rsp+0x70]
0000777bb65df2df  vmovaps xmm8, [rsp+0x80]
0000777bb65df2e8  vmovaps xmm9, [rsp+0x90]
0000777bb65df2f1  vmovaps xmm10, [rsp+0xA0]
0000777bb65df2fa  vmovaps xmm11, [rsp+0xB0]
0000777bb65df303  vmovaps xmm12, [rsp+0xC0]
0000777bb65df30c  vmovaps xmm13, [rsp+0xD0]
0000777bb65df315  vmovaps xmm14, [rsp+0xE0]
0000777bb65df31e  add rsp, 0xF0
0000777bb65df325  pop r11
0000777bb65df327  pop r10
0000777bb65df329  pop r9
0000777bb65df32b  pop r8
0000777bb65df32d  pop rsi
0000777bb65df32e  pop rdi
0000777bb65df32f  pop rdx
0000777bb65df330  pop rcx
0000777bb65df331  pop rax
0000777bb65df332  add rsp, 0x08
0000777bb65df336  jmp 0x0000777BB65DC38F
0000777bb65df33b  sub rsp, 0x08
0000777bb65df33f  push rax
0000777bb65df340  push rcx
0000777bb65df341  push rdx
0000777bb65df342  push rdi
0000777bb65df343  push rsi
0000777bb65df344  push r8
0000777bb65df346  push r9
0000777bb65df348  push r10
0000777bb65df34a  push r11
0000777bb65df34c  sub rsp, 0xF0
0000777bb65df353  vmovaps [rsp], xmm0
0000777bb65df358  vmovaps [rsp+0x10], xmm1
0000777bb65df35e  vmovaps [rsp+0x20], xmm2
0000777bb65df364  vmovaps [rsp+0x30], xmm3
0000777bb65df36a  vmovaps [rsp+0x40], xmm4
0000777bb65df370  vmovaps [rsp+0x50], xmm6
0000777bb65df376  vmovaps [rsp+0x60], xmm7
0000777bb65df37c  vmovaps [rsp+0x70], xmm8
0000777bb65df382  vmovaps [rsp+0x80], xmm9
0000777bb65df38b  vmovaps [rsp+0x90], xmm10
0000777bb65df394  vmovaps [rsp+0xA0], xmm11
0000777bb65df39d  vmovaps [rsp+0xB0], xmm12
0000777bb65df3a6  vmovaps [rsp+0xC0], xmm13
0000777bb65df3af  vmovaps [rsp+0xD0], xmm14
0000777bb65df3b8  vmovaps [rsp+0xE0], xmm15
0000777bb65df3c1  sub rsp, 0x30
0000777bb65df3c5  movaps [rsp], xmm5
0000777bb65df3c9  movaps [rsp+0x10], xmm8
0000777bb65df3cf  movaps [rsp+0x20], xmm6
0000777bb65df3d4  lea rdi, [rsp]
0000777bb65df3d8  mov esi, 0x00
0000777bb65df3dd  mov rax, 0x569DC437B530
0000777bb65df3e7  call rax
0000777bb65df3e9  movaps xmm5, [rsp]
0000777bb65df3ed  add rsp, 0x30
0000777bb65df3f1  vmovaps xmm0, [rsp]
0000777bb65df3f6  vmovaps xmm1, [rsp+0x10]
0000777bb65df3fc  vmovaps xmm2, [rsp+0x20]
0000777bb65df402  vmovaps xmm3, [rsp+0x30]
0000777bb65df408  vmovaps xmm4, [rsp+0x40]
0000777bb65df40e  vmovaps xmm6, [rsp+0x50]
0000777bb65df414  vmovaps xmm7, [rsp+0x60]
0000777bb65df41a  vmovaps xmm8, [rsp+0x70]
0000777bb65df420  vmovaps xmm9, [rsp+0x80]
0000777bb65df429  vmovaps xmm10, [rsp+0x90]
0000777bb65df432  vmovaps xmm11, [rsp+0xA0]
0000777bb65df43b  vmovaps xmm12, [rsp+0xB0]
0000777bb65df444  vmovaps xmm13, [rsp+0xC0]
0000777bb65df44d  vmovaps xmm14, [rsp+0xD0]
0000777bb65df456  vmovaps xmm15, [rsp+0xE0]
0000777bb65df45f  add rsp, 0xF0
0000777bb65df466  pop r11
0000777bb65df468  pop r10
0000777bb65df46a  pop r9
0000777bb65df46c  pop r8
0000777bb65df46e  pop rsi
0000777bb65df46f  pop rdi
0000777bb65df470  pop rdx
0000777bb65df471  pop rcx
0000777bb65df472  pop rax
0000777bb65df473  add rsp, 0x08
0000777bb65df477  jmp 0x0000777BB65DC3B3
0000777bb65df47c  sub rsp, 0x08
0000777bb65df480  push rax
0000777bb65df481  push rcx
0000777bb65df482  push rdx
0000777bb65df483  push rdi
0000777bb65df484  push rsi
0000777bb65df485  push r8
0000777bb65df487  push r9
0000777bb65df489  push r10
0000777bb65df48b  push r11
0000777bb65df48d  sub rsp, 0xF0
0000777bb65df494  vmovaps [rsp], xmm0
0000777bb65df499  vmovaps [rsp+0x10], xmm1
0000777bb65df49f  vmovaps [rsp+0x20], xmm2
0000777bb65df4a5  vmovaps [rsp+0x30], xmm3
0000777bb65df4ab  vmovaps [rsp+0x40], xmm4
0000777bb65df4b1  vmovaps [rsp+0x50], xmm5
0000777bb65df4b7  vmovaps [rsp+0x60], xmm7
0000777bb65df4bd  vmovaps [rsp+0x70], xmm8
0000777bb65df4c3  vmovaps [rsp+0x80], xmm9
0000777bb65df4cc  vmovaps [rsp+0x90], xmm10
0000777bb65df4d5  vmovaps [rsp+0xA0], xmm11
0000777bb65df4de  vmovaps [rsp+0xB0], xmm12
0000777bb65df4e7  vmovaps [rsp+0xC0], xmm13
0000777bb65df4f0  vmovaps [rsp+0xD0], xmm14
0000777bb65df4f9  vmovaps [rsp+0xE0], xmm15
0000777bb65df502  sub rsp, 0x30
0000777bb65df506  movaps [rsp], xmm6
0000777bb65df50a  movaps [rsp+0x10], xmm10
0000777bb65df510  movaps [rsp+0x20], xmm8
0000777bb65df516  lea rdi, [rsp]
0000777bb65df51a  mov esi, 0x00
0000777bb65df51f  mov rax, 0x569DC437B530
0000777bb65df529  call rax
0000777bb65df52b  movaps xmm6, [rsp]
0000777bb65df52f  add rsp, 0x30
0000777bb65df533  vmovaps xmm0, [rsp]
0000777bb65df538  vmovaps xmm1, [rsp+0x10]
0000777bb65df53e  vmovaps xmm2, [rsp+0x20]
0000777bb65df544  vmovaps xmm3, [rsp+0x30]
0000777bb65df54a  vmovaps xmm4, [rsp+0x40]
0000777bb65df550  vmovaps xmm5, [rsp+0x50]
0000777bb65df556  vmovaps xmm7, [rsp+0x60]
0000777bb65df55c  vmovaps xmm8, [rsp+0x70]
0000777bb65df562  vmovaps xmm9, [rsp+0x80]
0000777bb65df56b  vmovaps xmm10, [rsp+0x90]
0000777bb65df574  vmovaps xmm11, [rsp+0xA0]
0000777bb65df57d  vmovaps xmm12, [rsp+0xB0]
0000777bb65df586  vmovaps xmm13, [rsp+0xC0]
0000777bb65df58f  vmovaps xmm14, [rsp+0xD0]
0000777bb65df598  vmovaps xmm15, [rsp+0xE0]
0000777bb65df5a1  add rsp, 0xF0
0000777bb65df5a8  pop r11
0000777bb65df5aa  pop r10
0000777bb65df5ac  pop r9
0000777bb65df5ae  pop r8
0000777bb65df5b0  pop rsi
0000777bb65df5b1  pop rdi
0000777bb65df5b2  pop rdx
0000777bb65df5b3  pop rcx
0000777bb65df5b4  pop rax
0000777bb65df5b5  add rsp, 0x08
0000777bb65df5b9  jmp 0x0000777BB65DC3D8
0000777bb65df5be  sub rsp, 0x08
0000777bb65df5c2  push rax
0000777bb65df5c3  push rcx
0000777bb65df5c4  push rdx
0000777bb65df5c5  push rdi
0000777bb65df5c6  push rsi
0000777bb65df5c7  push r8
0000777bb65df5c9  push r9
0000777bb65df5cb  push r10
0000777bb65df5cd  push r11
0000777bb65df5cf  sub rsp, 0xF0
0000777bb65df5d6  vmovaps [rsp], xmm0
0000777bb65df5db  vmovaps [rsp+0x10], xmm1
0000777bb65df5e1  vmovaps [rsp+0x20], xmm2
0000777bb65df5e7  vmovaps [rsp+0x30], xmm3
0000777bb65df5ed  vmovaps [rsp+0x40], xmm4
0000777bb65df5f3  vmovaps [rsp+0x50], xmm5
0000777bb65df5f9  vmovaps [rsp+0x60], xmm6
0000777bb65df5ff  vmovaps [rsp+0x70], xmm7
0000777bb65df605  vmovaps [rsp+0x80], xmm8
0000777bb65df60e  vmovaps [rsp+0x90], xmm9
0000777bb65df617  vmovaps [rsp+0xA0], xmm11
0000777bb65df620  vmovaps [rsp+0xB0], xmm12
0000777bb65df629  vmovaps [rsp+0xC0], xmm13
0000777bb65df632  vmovaps [rsp+0xD0], xmm14
0000777bb65df63b  vmovaps [rsp+0xE0], xmm15
0000777bb65df644  sub rsp, 0x30
0000777bb65df648  movaps [rsp], xmm10
0000777bb65df64d  movaps [rsp+0x10], xmm8
0000777bb65df653  movaps [rsp+0x20], xmm14
0000777bb65df659  lea rdi, [rsp]
0000777bb65df65d  mov esi, 0x00
0000777bb65df662  mov rax, 0x569DC437B530
0000777bb65df66c  call rax
0000777bb65df66e  movaps xmm10, [rsp]
0000777bb65df673  add rsp, 0x30
0000777bb65df677  vmovaps xmm0, [rsp]
0000777bb65df67c  vmovaps xmm1, [rsp+0x10]
0000777bb65df682  vmovaps xmm2, [rsp+0x20]
0000777bb65df688  vmovaps xmm3, [rsp+0x30]
0000777bb65df68e  vmovaps xmm4, [rsp+0x40]
0000777bb65df694  vmovaps xmm5, [rsp+0x50]
0000777bb65df69a  vmovaps xmm6, [rsp+0x60]
0000777bb65df6a0  vmovaps xmm7, [rsp+0x70]
0000777bb65df6a6  vmovaps xmm8, [rsp+0x80]
0000777bb65df6af  vmovaps xmm9, [rsp+0x90]
0000777bb65df6b8  vmovaps xmm11, [rsp+0xA0]
0000777bb65df6c1  vmovaps xmm12, [rsp+0xB0]
0000777bb65df6ca  vmovaps xmm13, [rsp+0xC0]
0000777bb65df6d3  vmovaps xmm14, [rsp+0xD0]
0000777bb65df6dc  vmovaps xmm15, [rsp+0xE0]
0000777bb65df6e5  add rsp, 0xF0
0000777bb65df6ec  pop r11
0000777bb65df6ee  pop r10
0000777bb65df6f0  pop r9
0000777bb65df6f2  pop r8
0000777bb65df6f4  pop rsi
0000777bb65df6f5  pop rdi
0000777bb65df6f6  pop rdx
0000777bb65df6f7  pop rcx
0000777bb65df6f8  pop rax
0000777bb65df6f9  add rsp, 0x08
0000777bb65df6fd  jmp 0x0000777BB65DC3F8
0000777bb65df702  sub rsp, 0x08
0000777bb65df706  push rax
0000777bb65df707  push rcx
0000777bb65df708  push rdx
0000777bb65df709  push rdi
0000777bb65df70a  push rsi
0000777bb65df70b  push r8
0000777bb65df70d  push r9
0000777bb65df70f  push r10
0000777bb65df711  push r11
0000777bb65df713  sub rsp, 0xF0
0000777bb65df71a  vmovaps [rsp], xmm0
0000777bb65df71f  vmovaps [rsp+0x10], xmm1
0000777bb65df725  vmovaps [rsp+0x20], xmm2
0000777bb65df72b  vmovaps [rsp+0x30], xmm3
0000777bb65df731  vmovaps [rsp+0x40], xmm4
0000777bb65df737  vmovaps [rsp+0x50], xmm5
0000777bb65df73d  vmovaps [rsp+0x60], xmm6
0000777bb65df743  vmovaps [rsp+0x70], xmm7
0000777bb65df749  vmovaps [rsp+0x80], xmm8
0000777bb65df752  vmovaps [rsp+0x90], xmm9
0000777bb65df75b  vmovaps [rsp+0xA0], xmm10
0000777bb65df764  vmovaps [rsp+0xB0], xmm11
0000777bb65df76d  vmovaps [rsp+0xC0], xmm12
0000777bb65df776  vmovaps [rsp+0xD0], xmm13
0000777bb65df77f  vmovaps [rsp+0xE0], xmm15
0000777bb65df788  sub rsp, 0x30
0000777bb65df78c  movaps [rsp], xmm14
0000777bb65df791  movaps [rsp+0x10], xmm8
0000777bb65df797  movaps [rsp+0x20], xmm4
0000777bb65df79c  lea rdi, [rsp]
0000777bb65df7a0  mov esi, 0x00
0000777bb65df7a5  mov rax, 0x569DC437B530
0000777bb65df7af  call rax
0000777bb65df7b1  movaps xmm14, [rsp]
0000777bb65df7b6  add rsp, 0x30
0000777bb65df7ba  vmovaps xmm0, [rsp]
0000777bb65df7bf  vmovaps xmm1, [rsp+0x10]
0000777bb65df7c5  vmovaps xmm2, [rsp+0x20]
0000777bb65df7cb  vmovaps xmm3, [rsp+0x30]
0000777bb65df7d1  vmovaps xmm4, [rsp+0x40]
0000777bb65df7d7  vmovaps xmm5, [rsp+0x50]
0000777bb65df7dd  vmovaps xmm6, [rsp+0x60]
0000777bb65df7e3  vmovaps xmm7, [rsp+0x70]
0000777bb65df7e9  vmovaps xmm8, [rsp+0x80]
0000777bb65df7f2  vmovaps xmm9, [rsp+0x90]
0000777bb65df7fb  vmovaps xmm10, [rsp+0xA0]
0000777bb65df804  vmovaps xmm11, [rsp+0xB0]
0000777bb65df80d  vmovaps xmm12, [rsp+0xC0]
0000777bb65df816  vmovaps xmm13, [rsp+0xD0]
0000777bb65df81f  vmovaps xmm15, [rsp+0xE0]
0000777bb65df828  add rsp, 0xF0
0000777bb65df82f  pop r11
0000777bb65df831  pop r10
0000777bb65df833  pop r9
0000777bb65df835  pop r8
0000777bb65df837  pop rsi
0000777bb65df838  pop rdi
0000777bb65df839  pop rdx
0000777bb65df83a  pop rcx
0000777bb65df83b  pop rax
0000777bb65df83c  add rsp, 0x08
0000777bb65df840  jmp 0x0000777BB65DC418
0000777bb65df845  sub rsp, 0x08
0000777bb65df849  push rax
0000777bb65df84a  push rcx
0000777bb65df84b  push rdx
0000777bb65df84c  push rdi
0000777bb65df84d  push rsi
0000777bb65df84e  push r8
0000777bb65df850  push r9
0000777bb65df852  push r10
0000777bb65df854  push r11
0000777bb65df856  sub rsp, 0xF0
0000777bb65df85d  vmovaps [rsp], xmm0
0000777bb65df862  vmovaps [rsp+0x10], xmm1
0000777bb65df868  vmovaps [rsp+0x20], xmm2
0000777bb65df86e  vmovaps [rsp+0x30], xmm3
0000777bb65df874  vmovaps [rsp+0x40], xmm5
0000777bb65df87a  vmovaps [rsp+0x50], xmm6
0000777bb65df880  vmovaps [rsp+0x60], xmm7
0000777bb65df886  vmovaps [rsp+0x70], xmm8
0000777bb65df88c  vmovaps [rsp+0x80], xmm9
0000777bb65df895  vmovaps [rsp+0x90], xmm10
0000777bb65df89e  vmovaps [rsp+0xA0], xmm11
0000777bb65df8a7  vmovaps [rsp+0xB0], xmm12
0000777bb65df8b0  vmovaps [rsp+0xC0], xmm13
0000777bb65df8b9  vmovaps [rsp+0xD0], xmm14
0000777bb65df8c2  vmovaps [rsp+0xE0], xmm15
0000777bb65df8cb  sub rsp, 0x30
0000777bb65df8cf  movaps [rsp], xmm4
0000777bb65df8d3  movaps [rsp+0x10], xmm13
0000777bb65df8d9  movaps [rsp+0x20], xmm8
0000777bb65df8df  lea rdi, [rsp]
0000777bb65df8e3  mov esi, 0x00
0000777bb65df8e8  mov rax, 0x569DC437B530
0000777bb65df8f2  call rax
0000777bb65df8f4  movaps xmm4, [rsp]
0000777bb65df8f8  add rsp, 0x30
0000777bb65df8fc  vmovaps xmm0, [rsp]
0000777bb65df901  vmovaps xmm1, [rsp+0x10]
0000777bb65df907  vmovaps xmm2, [rsp+0x20]
0000777bb65df90d  vmovaps xmm3, [rsp+0x30]
0000777bb65df913  vmovaps xmm5, [rsp+0x40]
0000777bb65df919  vmovaps xmm6, [rsp+0x50]
0000777bb65df91f  vmovaps xmm7, [rsp+0x60]
0000777bb65df925  vmovaps xmm8, [rsp+0x70]
0000777bb65df92b  vmovaps xmm9, [rsp+0x80]
0000777bb65df934  vmovaps xmm10, [rsp+0x90]
0000777bb65df93d  vmovaps xmm11, [rsp+0xA0]
0000777bb65df946  vmovaps xmm12, [rsp+0xB0]
0000777bb65df94f  vmovaps xmm13, [rsp+0xC0]
0000777bb65df958  vmovaps xmm14, [rsp+0xD0]
0000777bb65df961  vmovaps xmm15, [rsp+0xE0]
0000777bb65df96a  add rsp, 0xF0
0000777bb65df971  pop r11
0000777bb65df973  pop r10
0000777bb65df975  pop r9
0000777bb65df977  pop r8
0000777bb65df979  pop rsi
0000777bb65df97a  pop rdi
0000777bb65df97b  pop rdx
0000777bb65df97c  pop rcx
0000777bb65df97d  pop rax
0000777bb65df97e  add rsp, 0x08
0000777bb65df982  jmp 0x0000777BB65DC43D
0000777bb65df987  sub rsp, 0x08
0000777bb65df98b  push rax
0000777bb65df98c  push rcx
0000777bb65df98d  push rdx
0000777bb65df98e  push rdi
0000777bb65df98f  push rsi
0000777bb65df990  push r8
0000777bb65df992  push r9
0000777bb65df994  push r10
0000777bb65df996  push r11
0000777bb65df998  sub rsp, 0xF0
0000777bb65df99f  vmovaps [rsp], xmm0
0000777bb65df9a4  vmovaps [rsp+0x10], xmm1
0000777bb65df9aa  vmovaps [rsp+0x20], xmm2
0000777bb65df9b0  vmovaps [rsp+0x30], xmm3
0000777bb65df9b6  vmovaps [rsp+0x40], xmm4
0000777bb65df9bc  vmovaps [rsp+0x50], xmm5
0000777bb65df9c2  vmovaps [rsp+0x60], xmm6
0000777bb65df9c8  vmovaps [rsp+0x70], xmm7
0000777bb65df9ce  vmovaps [rsp+0x80], xmm8
0000777bb65df9d7  vmovaps [rsp+0x90], xmm9
0000777bb65df9e0  vmovaps [rsp+0xA0], xmm10
0000777bb65df9e9  vmovaps [rsp+0xB0], xmm11
0000777bb65df9f2  vmovaps [rsp+0xC0], xmm12
0000777bb65df9fb  vmovaps [rsp+0xD0], xmm14
0000777bb65dfa04  vmovaps [rsp+0xE0], xmm15
0000777bb65dfa0d  sub rsp, 0x30
0000777bb65dfa11  movaps [rsp], xmm13
0000777bb65dfa16  movaps [rsp+0x10], xmm15
0000777bb65dfa1c  movaps [rsp+0x20], xmm9
0000777bb65dfa22  lea rdi, [rsp]
0000777bb65dfa26  mov esi, 0x00
0000777bb65dfa2b  mov rax, 0x569DC437B530
0000777bb65dfa35  call rax
0000777bb65dfa37  movaps xmm13, [rsp]
0000777bb65dfa3c  add rsp, 0x30
0000777bb65dfa40  vmovaps xmm0, [rsp]
0000777bb65dfa45  vmovaps xmm1, [rsp+0x10]
0000777bb65dfa4b  vmovaps xmm2, [rsp+0x20]
0000777bb65dfa51  vmovaps xmm3, [rsp+0x30]
0000777bb65dfa57  vmovaps xmm4, [rsp+0x40]
0000777bb65dfa5d  vmovaps xmm5, [rsp+0x50]
0000777bb65dfa63  vmovaps xmm6, [rsp+0x60]
0000777bb65dfa69  vmovaps xmm7, [rsp+0x70]
0000777bb65dfa6f  vmovaps xmm8, [rsp+0x80]
0000777bb65dfa78  vmovaps xmm9, [rsp+0x90]
0000777bb65dfa81  vmovaps xmm10, [rsp+0xA0]
0000777bb65dfa8a  vmovaps xmm11, [rsp+0xB0]
0000777bb65dfa93  vmovaps xmm12, [rsp+0xC0]
0000777bb65dfa9c  vmovaps xmm14, [rsp+0xD0]
0000777bb65dfaa5  vmovaps xmm15, [rsp+0xE0]
0000777bb65dfaae  add rsp, 0xF0
0000777bb65dfab5  pop r11
0000777bb65dfab7  pop r10
0000777bb65dfab9  pop r9
0000777bb65dfabb  pop r8
0000777bb65dfabd  pop rsi
0000777bb65dfabe  pop rdi
0000777bb65dfabf  pop rdx
0000777bb65dfac0  pop rcx
0000777bb65dfac1  pop rax
0000777bb65dfac2  add rsp, 0x08
0000777bb65dfac6  jmp 0x0000777BB65DC458
0000777bb65dfacb  sub rsp, 0x08
0000777bb65dfacf  push rax
0000777bb65dfad0  push rcx
0000777bb65dfad1  push rdx
0000777bb65dfad2  push rdi
0000777bb65dfad3  push rsi
0000777bb65dfad4  push r8
0000777bb65dfad6  push r9
0000777bb65dfad8  push r10
0000777bb65dfada  push r11
0000777bb65dfadc  sub rsp, 0xF0
0000777bb65dfae3  vmovaps [rsp], xmm0
0000777bb65dfae8  vmovaps [rsp+0x10], xmm1
0000777bb65dfaee  vmovaps [rsp+0x20], xmm2
0000777bb65dfaf4  vmovaps [rsp+0x30], xmm3
0000777bb65dfafa  vmovaps [rsp+0x40], xmm4
0000777bb65dfb00  vmovaps [rsp+0x50], xmm5
0000777bb65dfb06  vmovaps [rsp+0x60], xmm6
0000777bb65dfb0c  vmovaps [rsp+0x70], xmm7
0000777bb65dfb12  vmovaps [rsp+0x80], xmm8
0000777bb65dfb1b  vmovaps [rsp+0x90], xmm9
0000777bb65dfb24  vmovaps [rsp+0xA0], xmm10
0000777bb65dfb2d  vmovaps [rsp+0xB0], xmm11
0000777bb65dfb36  vmovaps [rsp+0xC0], xmm12
0000777bb65dfb3f  vmovaps [rsp+0xD0], xmm13
0000777bb65dfb48  vmovaps [rsp+0xE0], xmm14
0000777bb65dfb51  sub rsp, 0x30
0000777bb65dfb55  movaps [rsp], xmm15
0000777bb65dfb5a  movaps [rsp+0x10], xmm1
0000777bb65dfb5f  movaps [rsp+0x20], xmm5
0000777bb65dfb64  lea rdi, [rsp]
0000777bb65dfb68  mov esi, 0x00
0000777bb65dfb6d  mov rax, 0x569DC437B530
0000777bb65dfb77  call rax
0000777bb65dfb79  movaps xmm15, [rsp]
0000777bb65dfb7e  add rsp, 0x30
0000777bb65dfb82  vmovaps xmm0, [rsp]
0000777bb65dfb87  vmovaps xmm1, [rsp+0x10]
0000777bb65dfb8d  vmovaps xmm2, [rsp+0x20]
0000777bb65dfb93  vmovaps xmm3, [rsp+0x30]
0000777bb65dfb99  vmovaps xmm4, [rsp+0x40]
0000777bb65dfb9f  vmovaps xmm5, [rsp+0x50]
0000777bb65dfba5  vmovaps xmm6, [rsp+0x60]
0000777bb65dfbab  vmovaps xmm7, [rsp+0x70]
0000777bb65dfbb1  vmovaps xmm8, [rsp+0x80]
0000777bb65dfbba  vmovaps xmm9, [rsp+0x90]
0000777bb65dfbc3  vmovaps xmm10, [rsp+0xA0]
0000777bb65dfbcc  vmovaps xmm11, [rsp+0xB0]
0000777bb65dfbd5  vmovaps xmm12, [rsp+0xC0]
0000777bb65dfbde  vmovaps xmm13, [rsp+0xD0]
0000777bb65dfbe7  vmovaps xmm14, [rsp+0xE0]
0000777bb65dfbf0  add rsp, 0xF0
0000777bb65dfbf7  pop r11
0000777bb65dfbf9  pop r10
0000777bb65dfbfb  pop r9
0000777bb65dfbfd  pop r8
0000777bb65dfbff  pop rsi
0000777bb65dfc00  pop rdi
0000777bb65dfc01  pop rdx
0000777bb65dfc02  pop rcx
0000777bb65dfc03  pop rax
0000777bb65dfc04  add rsp, 0x08
0000777bb65dfc08  jmp 0x0000777BB65DC473
0000777bb65dfc0d  call 0x0000777BB64B52F0
0000777bb65dfc12  jmp 0x0000777BB65DC4CE
0000777bb65dfc17  sub rsp, 0x08
0000777bb65dfc1b  push rax
0000777bb65dfc1c  push rcx
0000777bb65dfc1d  push rdx
0000777bb65dfc1e  push rdi
0000777bb65dfc1f  push rsi
0000777bb65dfc20  push r8
0000777bb65dfc22  push r9
0000777bb65dfc24  push r10
0000777bb65dfc26  push r11
0000777bb65dfc28  sub rsp, 0xF0
0000777bb65dfc2f  vmovaps [rsp], xmm0
0000777bb65dfc34  vmovaps [rsp+0x10], xmm1
0000777bb65dfc3a  vmovaps [rsp+0x20], xmm2
0000777bb65dfc40  vmovaps [rsp+0x30], xmm3
0000777bb65dfc46  vmovaps [rsp+0x40], xmm4
0000777bb65dfc4c  vmovaps [rsp+0x50], xmm5
0000777bb65dfc52  vmovaps [rsp+0x60], xmm6
0000777bb65dfc58  vmovaps [rsp+0x70], xmm7
0000777bb65dfc5e  vmovaps [rsp+0x80], xmm8
0000777bb65dfc67  vmovaps [rsp+0x90], xmm10
0000777bb65dfc70  vmovaps [rsp+0xA0], xmm11
0000777bb65dfc79  vmovaps [rsp+0xB0], xmm12
0000777bb65dfc82  vmovaps [rsp+0xC0], xmm13
0000777bb65dfc8b  vmovaps [rsp+0xD0], xmm14
0000777bb65dfc94  vmovaps [rsp+0xE0], xmm15
0000777bb65dfc9d  sub rsp, 0x30
0000777bb65dfca1  movaps [rsp], xmm9
0000777bb65dfca6  movaps [rsp+0x10], xmm8
0000777bb65dfcac  movaps [rsp+0x20], xmm11
0000777bb65dfcb2  lea rdi, [rsp]
0000777bb65dfcb6  mov esi, 0x00
0000777bb65dfcbb  mov rax, 0x569DC437B530
0000777bb65dfcc5  call rax
0000777bb65dfcc7  movaps xmm9, [rsp]
0000777bb65dfccc  add rsp, 0x30
0000777bb65dfcd0  vmovaps xmm0, [rsp]
0000777bb65dfcd5  vmovaps xmm1, [rsp+0x10]
0000777bb65dfcdb  vmovaps xmm2, [rsp+0x20]
0000777bb65dfce1  vmovaps xmm3, [rsp+0x30]
0000777bb65dfce7  vmovaps xmm4, [rsp+0x40]
0000777bb65dfced  vmovaps xmm5, [rsp+0x50]
0000777bb65dfcf3  vmovaps xmm6, [rsp+0x60]
0000777bb65dfcf9  vmovaps xmm7, [rsp+0x70]
0000777bb65dfcff  vmovaps xmm8, [rsp+0x80]
0000777bb65dfd08  vmovaps xmm10, [rsp+0x90]
0000777bb65dfd11  vmovaps xmm11, [rsp+0xA0]
0000777bb65dfd1a  vmovaps xmm12, [rsp+0xB0]
0000777bb65dfd23  vmovaps xmm13, [rsp+0xC0]
0000777bb65dfd2c  vmovaps xmm14, [rsp+0xD0]
0000777bb65dfd35  vmovaps xmm15, [rsp+0xE0]
0000777bb65dfd3e  add rsp, 0xF0
0000777bb65dfd45  pop r11
0000777bb65dfd47  pop r10
0000777bb65dfd49  pop r9
0000777bb65dfd4b  pop r8
0000777bb65dfd4d  pop rsi
0000777bb65dfd4e  pop rdi
0000777bb65dfd4f  pop rdx
0000777bb65dfd50  pop rcx
0000777bb65dfd51  pop rax
0000777bb65dfd52  add rsp, 0x08
0000777bb65dfd56  jmp 0x0000777BB65DC505
0000777bb65dfd5b  sub rsp, 0x08
0000777bb65dfd5f  push rax
0000777bb65dfd60  push rcx
0000777bb65dfd61  push rdx
0000777bb65dfd62  push rdi
0000777bb65dfd63  push rsi
0000777bb65dfd64  push r8
0000777bb65dfd66  push r9
0000777bb65dfd68  push r10
0000777bb65dfd6a  push r11
0000777bb65dfd6c  sub rsp, 0xF0
0000777bb65dfd73  vmovaps [rsp], xmm0
0000777bb65dfd78  vmovaps [rsp+0x10], xmm1
0000777bb65dfd7e  vmovaps [rsp+0x20], xmm2
0000777bb65dfd84  vmovaps [rsp+0x30], xmm3
0000777bb65dfd8a  vmovaps [rsp+0x40], xmm4
0000777bb65dfd90  vmovaps [rsp+0x50], xmm5
0000777bb65dfd96  vmovaps [rsp+0x60], xmm6
0000777bb65dfd9c  vmovaps [rsp+0x70], xmm7
0000777bb65dfda2  vmovaps [rsp+0x80], xmm8
0000777bb65dfdab  vmovaps [rsp+0x90], xmm9
0000777bb65dfdb4  vmovaps [rsp+0xA0], xmm10
0000777bb65dfdbd  vmovaps [rsp+0xB0], xmm12
0000777bb65dfdc6  vmovaps [rsp+0xC0], xmm13
0000777bb65dfdcf  vmovaps [rsp+0xD0], xmm14
0000777bb65dfdd8  vmovaps [rsp+0xE0], xmm15
0000777bb65dfde1  sub rsp, 0x30
0000777bb65dfde5  movaps [rsp], xmm11
0000777bb65dfdea  movaps [rsp+0x10], xmm10
0000777bb65dfdf0  movaps [rsp+0x20], xmm6
0000777bb65dfdf5  lea rdi, [rsp]
0000777bb65dfdf9  mov esi, 0x00
0000777bb65dfdfe  mov rax, 0x569DC437B530
0000777bb65dfe08  call rax
0000777bb65dfe0a  movaps xmm11, [rsp]
0000777bb65dfe0f  add rsp, 0x30
0000777bb65dfe13  vmovaps xmm0, [rsp]
0000777bb65dfe18  vmovaps xmm1, [rsp+0x10]
0000777bb65dfe1e  vmovaps xmm2, [rsp+0x20]
0000777bb65dfe24  vmovaps xmm3, [rsp+0x30]
0000777bb65dfe2a  vmovaps xmm4, [rsp+0x40]
0000777bb65dfe30  vmovaps xmm5, [rsp+0x50]
0000777bb65dfe36  vmovaps xmm6, [rsp+0x60]
0000777bb65dfe3c  vmovaps xmm7, [rsp+0x70]
0000777bb65dfe42  vmovaps xmm8, [rsp+0x80]
0000777bb65dfe4b  vmovaps xmm9, [rsp+0x90]
0000777bb65dfe54  vmovaps xmm10, [rsp+0xA0]
0000777bb65dfe5d  vmovaps xmm12, [rsp+0xB0]
0000777bb65dfe66  vmovaps xmm13, [rsp+0xC0]
0000777bb65dfe6f  vmovaps xmm14, [rsp+0xD0]
0000777bb65dfe78  vmovaps xmm15, [rsp+0xE0]
0000777bb65dfe81  add rsp, 0xF0
0000777bb65dfe88  pop r11
0000777bb65dfe8a  pop r10
0000777bb65dfe8c  pop r9
0000777bb65dfe8e  pop r8
0000777bb65dfe90  pop rsi
0000777bb65dfe91  pop rdi
0000777bb65dfe92  pop rdx
0000777bb65dfe93  pop rcx
0000777bb65dfe94  pop rax
0000777bb65dfe95  add rsp, 0x08
0000777bb65dfe99  jmp 0x0000777BB65DC520
0000777bb65dfe9e  sub rsp, 0x08
0000777bb65dfea2  push rax
0000777bb65dfea3  push rcx
0000777bb65dfea4  push rdx
0000777bb65dfea5  push rdi
0000777bb65dfea6  push rsi
0000777bb65dfea7  push r8
0000777bb65dfea9  push r9
0000777bb65dfeab  push r10
0000777bb65dfead  push r11
0000777bb65dfeaf  sub rsp, 0xF0
0000777bb65dfeb6  vmovaps [rsp], xmm0
0000777bb65dfebb  vmovaps [rsp+0x10], xmm1
0000777bb65dfec1  vmovaps [rsp+0x20], xmm2
0000777bb65dfec7  vmovaps [rsp+0x30], xmm3
0000777bb65dfecd  vmovaps [rsp+0x40], xmm4
0000777bb65dfed3  vmovaps [rsp+0x50], xmm5
0000777bb65dfed9  vmovaps [rsp+0x60], xmm6
0000777bb65dfedf  vmovaps [rsp+0x70], xmm7
0000777bb65dfee5  vmovaps [rsp+0x80], xmm8
0000777bb65dfeee  vmovaps [rsp+0x90], xmm9
0000777bb65dfef7  vmovaps [rsp+0xA0], xmm11
0000777bb65dff00  vmovaps [rsp+0xB0], xmm12
0000777bb65dff09  vmovaps [rsp+0xC0], xmm13
0000777bb65dff12  vmovaps [rsp+0xD0], xmm14
0000777bb65dff1b  vmovaps [rsp+0xE0], xmm15
0000777bb65dff24  sub rsp, 0x30
0000777bb65dff28  movaps [rsp], xmm10
0000777bb65dff2d  movaps [rsp+0x10], xmm14
0000777bb65dff33  movaps [rsp+0x20], xmm4
0000777bb65dff38  lea rdi, [rsp]
0000777bb65dff3c  mov esi, 0x00
0000777bb65dff41  mov rax, 0x569DC437B530
0000777bb65dff4b  call rax
0000777bb65dff4d  movaps xmm10, [rsp]
0000777bb65dff52  add rsp, 0x30
0000777bb65dff56  vmovaps xmm0, [rsp]
0000777bb65dff5b  vmovaps xmm1, [rsp+0x10]
0000777bb65dff61  vmovaps xmm2, [rsp+0x20]
0000777bb65dff67  vmovaps xmm3, [rsp+0x30]
0000777bb65dff6d  vmovaps xmm4, [rsp+0x40]
0000777bb65dff73  vmovaps xmm5, [rsp+0x50]
0000777bb65dff79  vmovaps xmm6, [rsp+0x60]
0000777bb65dff7f  vmovaps xmm7, [rsp+0x70]
0000777bb65dff85  vmovaps xmm8, [rsp+0x80]
0000777bb65dff8e  vmovaps xmm9, [rsp+0x90]
0000777bb65dff97  vmovaps xmm11, [rsp+0xA0]
0000777bb65dffa0  vmovaps xmm12, [rsp+0xB0]
0000777bb65dffa9  vmovaps xmm13, [rsp+0xC0]
0000777bb65dffb2  vmovaps xmm14, [rsp+0xD0]
0000777bb65dffbb  vmovaps xmm15, [rsp+0xE0]
0000777bb65dffc4  add rsp, 0xF0
0000777bb65dffcb  pop r11
0000777bb65dffcd  pop r10
0000777bb65dffcf  pop r9
0000777bb65dffd1  pop r8
0000777bb65dffd3  pop rsi
0000777bb65dffd4  pop rdi
0000777bb65dffd5  pop rdx
0000777bb65dffd6  pop rcx
0000777bb65dffd7  pop rax
0000777bb65dffd8  add rsp, 0x08
0000777bb65dffdc  jmp 0x0000777BB65DC53B
0000777bb65dffe1  sub rsp, 0x08
0000777bb65dffe5  push rax
0000777bb65dffe6  push rcx
0000777bb65dffe7  push rdx
0000777bb65dffe8  push rdi
0000777bb65dffe9  push rsi
0000777bb65dffea  push r8
0000777bb65dffec  push r9
0000777bb65dffee  push r10
0000777bb65dfff0  push r11
0000777bb65dfff2  sub rsp, 0xF0
0000777bb65dfff9  vmovaps [rsp], xmm0
0000777bb65dfffe  vmovaps [rsp+0x10], xmm1
0000777bb65e0004  vmovaps [rsp+0x20], xmm2
0000777bb65e000a  vmovaps [rsp+0x30], xmm3
0000777bb65e0010  vmovaps [rsp+0x40], xmm4
0000777bb65e0016  vmovaps [rsp+0x50], xmm5
0000777bb65e001c  vmovaps [rsp+0x60], xmm6
0000777bb65e0022  vmovaps [rsp+0x70], xmm7
0000777bb65e0028  vmovaps [rsp+0x80], xmm9
0000777bb65e0031  vmovaps [rsp+0x90], xmm10
0000777bb65e003a  vmovaps [rsp+0xA0], xmm11
0000777bb65e0043  vmovaps [rsp+0xB0], xmm12
0000777bb65e004c  vmovaps [rsp+0xC0], xmm13
0000777bb65e0055  vmovaps [rsp+0xD0], xmm14
0000777bb65e005e  vmovaps [rsp+0xE0], xmm15
0000777bb65e0067  sub rsp, 0x30
0000777bb65e006b  movaps [rsp], xmm8
0000777bb65e0070  movaps [rsp+0x10], xmm1
0000777bb65e0075  movaps [rsp+0x20], xmm14
0000777bb65e007b  lea rdi, [rsp]
0000777bb65e007f  mov esi, 0x00
0000777bb65e0084  mov rax, 0x569DC437B530
0000777bb65e008e  call rax
0000777bb65e0090  movaps xmm8, [rsp]
0000777bb65e0095  add rsp, 0x30
0000777bb65e0099  vmovaps xmm0, [rsp]
0000777bb65e009e  vmovaps xmm1, [rsp+0x10]
0000777bb65e00a4  vmovaps xmm2, [rsp+0x20]
0000777bb65e00aa  vmovaps xmm3, [rsp+0x30]
0000777bb65e00b0  vmovaps xmm4, [rsp+0x40]
0000777bb65e00b6  vmovaps xmm5, [rsp+0x50]
0000777bb65e00bc  vmovaps xmm6, [rsp+0x60]
0000777bb65e00c2  vmovaps xmm7, [rsp+0x70]
0000777bb65e00c8  vmovaps xmm9, [rsp+0x80]
0000777bb65e00d1  vmovaps xmm10, [rsp+0x90]
0000777bb65e00da  vmovaps xmm11, [rsp+0xA0]
0000777bb65e00e3  vmovaps xmm12, [rsp+0xB0]
0000777bb65e00ec  vmovaps xmm13, [rsp+0xC0]
0000777bb65e00f5  vmovaps xmm14, [rsp+0xD0]
0000777bb65e00fe  vmovaps xmm15, [rsp+0xE0]
0000777bb65e0107  add rsp, 0xF0
0000777bb65e010e  pop r11
0000777bb65e0110  pop r10
0000777bb65e0112  pop r9
0000777bb65e0114  pop r8
0000777bb65e0116  pop rsi
0000777bb65e0117  pop rdi
0000777bb65e0118  pop rdx
0000777bb65e0119  pop rcx
0000777bb65e011a  pop rax
0000777bb65e011b  add rsp, 0x08
0000777bb65e011f  jmp 0x0000777BB65DC561
0000777bb65e0124  sub rsp, 0x08
0000777bb65e0128  push rax
0000777bb65e0129  push rcx
0000777bb65e012a  push rdx
0000777bb65e012b  push rdi
0000777bb65e012c  push rsi
0000777bb65e012d  push r8
0000777bb65e012f  push r9
0000777bb65e0131  push r10
0000777bb65e0133  push r11
0000777bb65e0135  sub rsp, 0xF0
0000777bb65e013c  vmovaps [rsp], xmm0
0000777bb65e0141  vmovaps [rsp+0x10], xmm1
0000777bb65e0147  vmovaps [rsp+0x20], xmm2
0000777bb65e014d  vmovaps [rsp+0x30], xmm3
0000777bb65e0153  vmovaps [rsp+0x40], xmm4
0000777bb65e0159  vmovaps [rsp+0x50], xmm5
0000777bb65e015f  vmovaps [rsp+0x60], xmm7
0000777bb65e0165  vmovaps [rsp+0x70], xmm8
0000777bb65e016b  vmovaps [rsp+0x80], xmm9
0000777bb65e0174  vmovaps [rsp+0x90], xmm10
0000777bb65e017d  vmovaps [rsp+0xA0], xmm11
0000777bb65e0186  vmovaps [rsp+0xB0], xmm12
0000777bb65e018f  vmovaps [rsp+0xC0], xmm13
0000777bb65e0198  vmovaps [rsp+0xD0], xmm14
0000777bb65e01a1  vmovaps [rsp+0xE0], xmm15
0000777bb65e01aa  sub rsp, 0x30
0000777bb65e01ae  movaps [rsp], xmm6
0000777bb65e01b2  movaps [rsp+0x10], xmm1
0000777bb65e01b7  movaps [rsp+0x20], xmm14
0000777bb65e01bd  lea rdi, [rsp]
0000777bb65e01c1  mov esi, 0x00
0000777bb65e01c6  mov rax, 0x569DC437B530
0000777bb65e01d0  call rax
0000777bb65e01d2  movaps xmm6, [rsp]
0000777bb65e01d6  add rsp, 0x30
0000777bb65e01da  vmovaps xmm0, [rsp]
0000777bb65e01df  vmovaps xmm1, [rsp+0x10]
0000777bb65e01e5  vmovaps xmm2, [rsp+0x20]
0000777bb65e01eb  vmovaps xmm3, [rsp+0x30]
0000777bb65e01f1  vmovaps xmm4, [rsp+0x40]
0000777bb65e01f7  vmovaps xmm5, [rsp+0x50]
0000777bb65e01fd  vmovaps xmm7, [rsp+0x60]
0000777bb65e0203  vmovaps xmm8, [rsp+0x70]
0000777bb65e0209  vmovaps xmm9, [rsp+0x80]
0000777bb65e0212  vmovaps xmm10, [rsp+0x90]
0000777bb65e021b  vmovaps xmm11, [rsp+0xA0]
0000777bb65e0224  vmovaps xmm12, [rsp+0xB0]
0000777bb65e022d  vmovaps xmm13, [rsp+0xC0]
0000777bb65e0236  vmovaps xmm14, [rsp+0xD0]
0000777bb65e023f  vmovaps xmm15, [rsp+0xE0]
0000777bb65e0248  add rsp, 0xF0
0000777bb65e024f  pop r11
0000777bb65e0251  pop r10
0000777bb65e0253  pop r9
0000777bb65e0255  pop r8
0000777bb65e0257  pop rsi
0000777bb65e0258  pop rdi
0000777bb65e0259  pop rdx
0000777bb65e025a  pop rcx
0000777bb65e025b  pop rax
0000777bb65e025c  add rsp, 0x08
0000777bb65e0260  jmp 0x0000777BB65DC58D
0000777bb65e0265  sub rsp, 0x08
0000777bb65e0269  push rax
0000777bb65e026a  push rcx
0000777bb65e026b  push rdx
0000777bb65e026c  push rdi
0000777bb65e026d  push rsi
0000777bb65e026e  push r8
0000777bb65e0270  push r9
0000777bb65e0272  push r10
0000777bb65e0274  push r11
0000777bb65e0276  sub rsp, 0xF0
0000777bb65e027d  vmovaps [rsp], xmm0
0000777bb65e0282  vmovaps [rsp+0x10], xmm1
0000777bb65e0288  vmovaps [rsp+0x20], xmm2
0000777bb65e028e  vmovaps [rsp+0x30], xmm3
0000777bb65e0294  vmovaps [rsp+0x40], xmm4
0000777bb65e029a  vmovaps [rsp+0x50], xmm5
0000777bb65e02a0  vmovaps [rsp+0x60], xmm6
0000777bb65e02a6  vmovaps [rsp+0x70], xmm7
0000777bb65e02ac  vmovaps [rsp+0x80], xmm8
0000777bb65e02b5  vmovaps [rsp+0x90], xmm9
0000777bb65e02be  vmovaps [rsp+0xA0], xmm10
0000777bb65e02c7  vmovaps [rsp+0xB0], xmm11
0000777bb65e02d0  vmovaps [rsp+0xC0], xmm12
0000777bb65e02d9  vmovaps [rsp+0xD0], xmm13
0000777bb65e02e2  vmovaps [rsp+0xE0], xmm15
0000777bb65e02eb  sub rsp, 0x30
0000777bb65e02ef  movaps [rsp], xmm14
0000777bb65e02f4  movaps [rsp+0x10], xmm12
0000777bb65e02fa  movaps [rsp+0x20], xmm1
0000777bb65e02ff  lea rdi, [rsp]
0000777bb65e0303  mov esi, 0x00
0000777bb65e0308  mov rax, 0x569DC437B530
0000777bb65e0312  call rax
0000777bb65e0314  movaps xmm14, [rsp]
0000777bb65e0319  add rsp, 0x30
0000777bb65e031d  vmovaps xmm0, [rsp]
0000777bb65e0322  vmovaps xmm1, [rsp+0x10]
0000777bb65e0328  vmovaps xmm2, [rsp+0x20]
0000777bb65e032e  vmovaps xmm3, [rsp+0x30]
0000777bb65e0334  vmovaps xmm4, [rsp+0x40]
0000777bb65e033a  vmovaps xmm5, [rsp+0x50]
0000777bb65e0340  vmovaps xmm6, [rsp+0x60]
0000777bb65e0346  vmovaps xmm7, [rsp+0x70]
0000777bb65e034c  vmovaps xmm8, [rsp+0x80]
0000777bb65e0355  vmovaps xmm9, [rsp+0x90]
0000777bb65e035e  vmovaps xmm10, [rsp+0xA0]
0000777bb65e0367  vmovaps xmm11, [rsp+0xB0]
0000777bb65e0370  vmovaps xmm12, [rsp+0xC0]
0000777bb65e0379  vmovaps xmm13, [rsp+0xD0]
0000777bb65e0382  vmovaps xmm15, [rsp+0xE0]
0000777bb65e038b  add rsp, 0xF0
0000777bb65e0392  pop r11
0000777bb65e0394  pop r10
0000777bb65e0396  pop r9
0000777bb65e0398  pop r8
0000777bb65e039a  pop rsi
0000777bb65e039b  pop rdi
0000777bb65e039c  pop rdx
0000777bb65e039d  pop rcx
0000777bb65e039e  pop rax
0000777bb65e039f  add rsp, 0x08
0000777bb65e03a3  jmp 0x0000777BB65DC5B3
0000777bb65e03a8  sub rsp, 0x08
0000777bb65e03ac  push rax
0000777bb65e03ad  push rcx
0000777bb65e03ae  push rdx
0000777bb65e03af  push rdi
0000777bb65e03b0  push rsi
0000777bb65e03b1  push r8
0000777bb65e03b3  push r9
0000777bb65e03b5  push r10
0000777bb65e03b7  push r11
0000777bb65e03b9  sub rsp, 0xF0
0000777bb65e03c0  vmovaps [rsp], xmm0
0000777bb65e03c5  vmovaps [rsp+0x10], xmm2
0000777bb65e03cb  vmovaps [rsp+0x20], xmm3
0000777bb65e03d1  vmovaps [rsp+0x30], xmm4
0000777bb65e03d7  vmovaps [rsp+0x40], xmm5
0000777bb65e03dd  vmovaps [rsp+0x50], xmm6
0000777bb65e03e3  vmovaps [rsp+0x60], xmm7
0000777bb65e03e9  vmovaps [rsp+0x70], xmm8
0000777bb65e03ef  vmovaps [rsp+0x80], xmm9
0000777bb65e03f8  vmovaps [rsp+0x90], xmm10
0000777bb65e0401  vmovaps [rsp+0xA0], xmm11
0000777bb65e040a  vmovaps [rsp+0xB0], xmm12
0000777bb65e0413  vmovaps [rsp+0xC0], xmm13
0000777bb65e041c  vmovaps [rsp+0xD0], xmm14
0000777bb65e0425  vmovaps [rsp+0xE0], xmm15
0000777bb65e042e  sub rsp, 0x30
0000777bb65e0432  movaps [rsp], xmm1
0000777bb65e0436  movaps [rsp+0x10], xmm13
0000777bb65e043c  movaps [rsp+0x20], xmm9
0000777bb65e0442  lea rdi, [rsp]
0000777bb65e0446  mov esi, 0x00
0000777bb65e044b  mov rax, 0x569DC437B530
0000777bb65e0455  call rax
0000777bb65e0457  movaps xmm1, [rsp]
0000777bb65e045b  add rsp, 0x30
0000777bb65e045f  vmovaps xmm0, [rsp]
0000777bb65e0464  vmovaps xmm2, [rsp+0x10]
0000777bb65e046a  vmovaps xmm3, [rsp+0x20]
0000777bb65e0470  vmovaps xmm4, [rsp+0x30]
0000777bb65e0476  vmovaps xmm5, [rsp+0x40]
0000777bb65e047c  vmovaps xmm6, [rsp+0x50]
0000777bb65e0482  vmovaps xmm7, [rsp+0x60]
0000777bb65e0488  vmovaps xmm8, [rsp+0x70]
0000777bb65e048e  vmovaps xmm9, [rsp+0x80]
0000777bb65e0497  vmovaps xmm10, [rsp+0x90]
0000777bb65e04a0  vmovaps xmm11, [rsp+0xA0]
0000777bb65e04a9  vmovaps xmm12, [rsp+0xB0]
0000777bb65e04b2  vmovaps xmm13, [rsp+0xC0]
0000777bb65e04bb  vmovaps xmm14, [rsp+0xD0]
0000777bb65e04c4  vmovaps xmm15, [rsp+0xE0]
0000777bb65e04cd  add rsp, 0xF0
0000777bb65e04d4  pop r11
0000777bb65e04d6  pop r10
0000777bb65e04d8  pop r9
0000777bb65e04da  pop r8
0000777bb65e04dc  pop rsi
0000777bb65e04dd  pop rdi
0000777bb65e04de  pop rdx
0000777bb65e04df  pop rcx
0000777bb65e04e0  pop rax
0000777bb65e04e1  add rsp, 0x08
0000777bb65e04e5  jmp 0x0000777BB65DC5CD
0000777bb65e04ea  sub rsp, 0x08
0000777bb65e04ee  push rax
0000777bb65e04ef  push rcx
0000777bb65e04f0  push rdx
0000777bb65e04f1  push rdi
0000777bb65e04f2  push rsi
0000777bb65e04f3  push r8
0000777bb65e04f5  push r9
0000777bb65e04f7  push r10
0000777bb65e04f9  push r11
0000777bb65e04fb  sub rsp, 0xF0
0000777bb65e0502  vmovaps [rsp], xmm0
0000777bb65e0507  vmovaps [rsp+0x10], xmm1
0000777bb65e050d  vmovaps [rsp+0x20], xmm2
0000777bb65e0513  vmovaps [rsp+0x30], xmm3
0000777bb65e0519  vmovaps [rsp+0x40], xmm4
0000777bb65e051f  vmovaps [rsp+0x50], xmm5
0000777bb65e0525  vmovaps [rsp+0x60], xmm6
0000777bb65e052b  vmovaps [rsp+0x70], xmm7
0000777bb65e0531  vmovaps [rsp+0x80], xmm8
0000777bb65e053a  vmovaps [rsp+0x90], xmm9
0000777bb65e0543  vmovaps [rsp+0xA0], xmm10
0000777bb65e054c  vmovaps [rsp+0xB0], xmm11
0000777bb65e0555  vmovaps [rsp+0xC0], xmm13
0000777bb65e055e  vmovaps [rsp+0xD0], xmm14
0000777bb65e0567  vmovaps [rsp+0xE0], xmm15
0000777bb65e0570  sub rsp, 0x30
0000777bb65e0574  movaps [rsp], xmm12
0000777bb65e0579  movaps [rsp+0x10], xmm7
0000777bb65e057e  movaps [rsp+0x20], xmm13
0000777bb65e0584  lea rdi, [rsp]
0000777bb65e0588  mov esi, 0x00
0000777bb65e058d  mov rax, 0x569DC437B530
0000777bb65e0597  call rax
0000777bb65e0599  movaps xmm12, [rsp]
0000777bb65e059e  add rsp, 0x30
0000777bb65e05a2  vmovaps xmm0, [rsp]
0000777bb65e05a7  vmovaps xmm1, [rsp+0x10]
0000777bb65e05ad  vmovaps xmm2, [rsp+0x20]
0000777bb65e05b3  vmovaps xmm3, [rsp+0x30]
0000777bb65e05b9  vmovaps xmm4, [rsp+0x40]
0000777bb65e05bf  vmovaps xmm5, [rsp+0x50]
0000777bb65e05c5  vmovaps xmm6, [rsp+0x60]
0000777bb65e05cb  vmovaps xmm7, [rsp+0x70]
0000777bb65e05d1  vmovaps xmm8, [rsp+0x80]
0000777bb65e05da  vmovaps xmm9, [rsp+0x90]
0000777bb65e05e3  vmovaps xmm10, [rsp+0xA0]
0000777bb65e05ec  vmovaps xmm11, [rsp+0xB0]
0000777bb65e05f5  vmovaps xmm13, [rsp+0xC0]
0000777bb65e05fe  vmovaps xmm14, [rsp+0xD0]
0000777bb65e0607  vmovaps xmm15, [rsp+0xE0]
0000777bb65e0610  add rsp, 0xF0
0000777bb65e0617  pop r11
0000777bb65e0619  pop r10
0000777bb65e061b  pop r9
0000777bb65e061d  pop r8
0000777bb65e061f  pop rsi
0000777bb65e0620  pop rdi
0000777bb65e0621  pop rdx
0000777bb65e0622  pop rcx
0000777bb65e0623  pop rax
0000777bb65e0624  add rsp, 0x08
0000777bb65e0628  jmp 0x0000777BB65DC5F4
0000777bb65e062d  sub rsp, 0x08
0000777bb65e0631  push rax
0000777bb65e0632  push rcx
0000777bb65e0633  push rdx
0000777bb65e0634  push rdi
0000777bb65e0635  push rsi
0000777bb65e0636  push r8
0000777bb65e0638  push r9
0000777bb65e063a  push r10
0000777bb65e063c  push r11
0000777bb65e063e  sub rsp, 0xF0
0000777bb65e0645  vmovaps [rsp], xmm0
0000777bb65e064a  vmovaps [rsp+0x10], xmm1
0000777bb65e0650  vmovaps [rsp+0x20], xmm2
0000777bb65e0656  vmovaps [rsp+0x30], xmm3
0000777bb65e065c  vmovaps [rsp+0x40], xmm4
0000777bb65e0662  vmovaps [rsp+0x50], xmm5
0000777bb65e0668  vmovaps [rsp+0x60], xmm6
0000777bb65e066e  vmovaps [rsp+0x70], xmm7
0000777bb65e0674  vmovaps [rsp+0x80], xmm8
0000777bb65e067d  vmovaps [rsp+0x90], xmm9
0000777bb65e0686  vmovaps [rsp+0xA0], xmm10
0000777bb65e068f  vmovaps [rsp+0xB0], xmm11
0000777bb65e0698  vmovaps [rsp+0xC0], xmm12
0000777bb65e06a1  vmovaps [rsp+0xD0], xmm14
0000777bb65e06aa  vmovaps [rsp+0xE0], xmm15
0000777bb65e06b3  sub rsp, 0x30
0000777bb65e06b7  movaps [rsp], xmm13
0000777bb65e06bc  movaps [rsp+0x10], xmm15
0000777bb65e06c2  movaps [rsp+0x20], xmm8
0000777bb65e06c8  lea rdi, [rsp]
0000777bb65e06cc  mov esi, 0x00
0000777bb65e06d1  mov rax, 0x569DC437B530
0000777bb65e06db  call rax
0000777bb65e06dd  movaps xmm13, [rsp]
0000777bb65e06e2  add rsp, 0x30
0000777bb65e06e6  vmovaps xmm0, [rsp]
0000777bb65e06eb  vmovaps xmm1, [rsp+0x10]
0000777bb65e06f1  vmovaps xmm2, [rsp+0x20]
0000777bb65e06f7  vmovaps xmm3, [rsp+0x30]
0000777bb65e06fd  vmovaps xmm4, [rsp+0x40]
0000777bb65e0703  vmovaps xmm5, [rsp+0x50]
0000777bb65e0709  vmovaps xmm6, [rsp+0x60]
0000777bb65e070f  vmovaps xmm7, [rsp+0x70]
0000777bb65e0715  vmovaps xmm8, [rsp+0x80]
0000777bb65e071e  vmovaps xmm9, [rsp+0x90]
0000777bb65e0727  vmovaps xmm10, [rsp+0xA0]
0000777bb65e0730  vmovaps xmm11, [rsp+0xB0]
0000777bb65e0739  vmovaps xmm12, [rsp+0xC0]
0000777bb65e0742  vmovaps xmm14, [rsp+0xD0]
0000777bb65e074b  vmovaps xmm15, [rsp+0xE0]
0000777bb65e0754  add rsp, 0xF0
0000777bb65e075b  pop r11
0000777bb65e075d  pop r10
0000777bb65e075f  pop r9
0000777bb65e0761  pop r8
0000777bb65e0763  pop rsi
0000777bb65e0764  pop rdi
0000777bb65e0765  pop rdx
0000777bb65e0766  pop rcx
0000777bb65e0767  pop rax
0000777bb65e0768  add rsp, 0x08
0000777bb65e076c  jmp 0x0000777BB65DC60F
0000777bb65e0771  sub rsp, 0x08
0000777bb65e0775  push rax
0000777bb65e0776  push rcx
0000777bb65e0777  push rdx
0000777bb65e0778  push rdi
0000777bb65e0779  push rsi
0000777bb65e077a  push r8
0000777bb65e077c  push r9
0000777bb65e077e  push r10
0000777bb65e0780  push r11
0000777bb65e0782  sub rsp, 0xF0
0000777bb65e0789  vmovaps [rsp], xmm0
0000777bb65e078e  vmovaps [rsp+0x10], xmm1
0000777bb65e0794  vmovaps [rsp+0x20], xmm2
0000777bb65e079a  vmovaps [rsp+0x30], xmm3
0000777bb65e07a0  vmovaps [rsp+0x40], xmm4
0000777bb65e07a6  vmovaps [rsp+0x50], xmm5
0000777bb65e07ac  vmovaps [rsp+0x60], xmm6
0000777bb65e07b2  vmovaps [rsp+0x70], xmm7
0000777bb65e07b8  vmovaps [rsp+0x80], xmm9
0000777bb65e07c1  vmovaps [rsp+0x90], xmm10
0000777bb65e07ca  vmovaps [rsp+0xA0], xmm11
0000777bb65e07d3  vmovaps [rsp+0xB0], xmm12
0000777bb65e07dc  vmovaps [rsp+0xC0], xmm13
0000777bb65e07e5  vmovaps [rsp+0xD0], xmm14
0000777bb65e07ee  vmovaps [rsp+0xE0], xmm15
0000777bb65e07f7  sub rsp, 0x30
0000777bb65e07fb  movaps [rsp], xmm8
0000777bb65e0800  movaps [rsp+0x10], xmm15
0000777bb65e0806  movaps [rsp+0x20], xmm9
0000777bb65e080c  lea rdi, [rsp]
0000777bb65e0810  mov esi, 0x00
0000777bb65e0815  mov rax, 0x569DC437B530
0000777bb65e081f  call rax
0000777bb65e0821  movaps xmm8, [rsp]
0000777bb65e0826  add rsp, 0x30
0000777bb65e082a  vmovaps xmm0, [rsp]
0000777bb65e082f  vmovaps xmm1, [rsp+0x10]
0000777bb65e0835  vmovaps xmm2, [rsp+0x20]
0000777bb65e083b  vmovaps xmm3, [rsp+0x30]
0000777bb65e0841  vmovaps xmm4, [rsp+0x40]
0000777bb65e0847  vmovaps xmm5, [rsp+0x50]
0000777bb65e084d  vmovaps xmm6, [rsp+0x60]
0000777bb65e0853  vmovaps xmm7, [rsp+0x70]
0000777bb65e0859  vmovaps xmm9, [rsp+0x80]
0000777bb65e0862  vmovaps xmm10, [rsp+0x90]
0000777bb65e086b  vmovaps xmm11, [rsp+0xA0]
0000777bb65e0874  vmovaps xmm12, [rsp+0xB0]
0000777bb65e087d  vmovaps xmm13, [rsp+0xC0]
0000777bb65e0886  vmovaps xmm14, [rsp+0xD0]
0000777bb65e088f  vmovaps xmm15, [rsp+0xE0]
0000777bb65e0898  add rsp, 0xF0
0000777bb65e089f  pop r11
0000777bb65e08a1  pop r10
0000777bb65e08a3  pop r9
0000777bb65e08a5  pop r8
0000777bb65e08a7  pop rsi
0000777bb65e08a8  pop rdi
0000777bb65e08a9  pop rdx
0000777bb65e08aa  pop rcx
0000777bb65e08ab  pop rax
0000777bb65e08ac  add rsp, 0x08
0000777bb65e08b0  jmp 0x0000777BB65DC63D
0000777bb65e08b5  sub rsp, 0x08
0000777bb65e08b9  push rax
0000777bb65e08ba  push rcx
0000777bb65e08bb  push rdx
0000777bb65e08bc  push rdi
0000777bb65e08bd  push rsi
0000777bb65e08be  push r8
0000777bb65e08c0  push r9
0000777bb65e08c2  push r10
0000777bb65e08c4  push r11
0000777bb65e08c6  sub rsp, 0xF0
0000777bb65e08cd  vmovaps [rsp], xmm0
0000777bb65e08d2  vmovaps [rsp+0x10], xmm1
0000777bb65e08d8  vmovaps [rsp+0x20], xmm2
0000777bb65e08de  vmovaps [rsp+0x30], xmm3
0000777bb65e08e4  vmovaps [rsp+0x40], xmm4
0000777bb65e08ea  vmovaps [rsp+0x50], xmm5
0000777bb65e08f0  vmovaps [rsp+0x60], xmm6
0000777bb65e08f6  vmovaps [rsp+0x70], xmm7
0000777bb65e08fc  vmovaps [rsp+0x80], xmm8
0000777bb65e0905  vmovaps [rsp+0x90], xmm9
0000777bb65e090e  vmovaps [rsp+0xA0], xmm10
0000777bb65e0917  vmovaps [rsp+0xB0], xmm11
0000777bb65e0920  vmovaps [rsp+0xC0], xmm12
0000777bb65e0929  vmovaps [rsp+0xD0], xmm13
0000777bb65e0932  vmovaps [rsp+0xE0], xmm14
0000777bb65e093b  sub rsp, 0x30
0000777bb65e093f  movaps [rsp], xmm15
0000777bb65e0944  movaps [rsp+0x10], xmm11
0000777bb65e094a  movaps [rsp+0x20], xmm6
0000777bb65e094f  lea rdi, [rsp]
0000777bb65e0953  mov esi, 0x00
0000777bb65e0958  mov rax, 0x569DC437B530
0000777bb65e0962  call rax
0000777bb65e0964  movaps xmm15, [rsp]
0000777bb65e0969  add rsp, 0x30
0000777bb65e096d  vmovaps xmm0, [rsp]
0000777bb65e0972  vmovaps xmm1, [rsp+0x10]
0000777bb65e0978  vmovaps xmm2, [rsp+0x20]
0000777bb65e097e  vmovaps xmm3, [rsp+0x30]
0000777bb65e0984  vmovaps xmm4, [rsp+0x40]
0000777bb65e098a  vmovaps xmm5, [rsp+0x50]
0000777bb65e0990  vmovaps xmm6, [rsp+0x60]
0000777bb65e0996  vmovaps xmm7, [rsp+0x70]
0000777bb65e099c  vmovaps xmm8, [rsp+0x80]
0000777bb65e09a5  vmovaps xmm9, [rsp+0x90]
0000777bb65e09ae  vmovaps xmm10, [rsp+0xA0]
0000777bb65e09b7  vmovaps xmm11, [rsp+0xB0]
0000777bb65e09c0  vmovaps xmm12, [rsp+0xC0]
0000777bb65e09c9  vmovaps xmm13, [rsp+0xD0]
0000777bb65e09d2  vmovaps xmm14, [rsp+0xE0]
0000777bb65e09db  add rsp, 0xF0
0000777bb65e09e2  pop r11
0000777bb65e09e4  pop r10
0000777bb65e09e6  pop r9
0000777bb65e09e8  pop r8
0000777bb65e09ea  pop rsi
0000777bb65e09eb  pop rdi
0000777bb65e09ec  pop rdx
0000777bb65e09ed  pop rcx
0000777bb65e09ee  pop rax
0000777bb65e09ef  add rsp, 0x08
0000777bb65e09f3  jmp 0x0000777BB65DC658
0000777bb65e09f8  sub rsp, 0x08
0000777bb65e09fc  push rax
0000777bb65e09fd  push rcx
0000777bb65e09fe  push rdx
0000777bb65e09ff  push rdi
0000777bb65e0a00  push rsi
0000777bb65e0a01  push r8
0000777bb65e0a03  push r9
0000777bb65e0a05  push r10
0000777bb65e0a07  push r11
0000777bb65e0a09  sub rsp, 0xF0
0000777bb65e0a10  vmovaps [rsp], xmm0
0000777bb65e0a15  vmovaps [rsp+0x10], xmm1
0000777bb65e0a1b  vmovaps [rsp+0x20], xmm2
0000777bb65e0a21  vmovaps [rsp+0x30], xmm3
0000777bb65e0a27  vmovaps [rsp+0x40], xmm4
0000777bb65e0a2d  vmovaps [rsp+0x50], xmm5
0000777bb65e0a33  vmovaps [rsp+0x60], xmm6
0000777bb65e0a39  vmovaps [rsp+0x70], xmm8
0000777bb65e0a3f  vmovaps [rsp+0x80], xmm9
0000777bb65e0a48  vmovaps [rsp+0x90], xmm10
0000777bb65e0a51  vmovaps [rsp+0xA0], xmm11
0000777bb65e0a5a  vmovaps [rsp+0xB0], xmm12
0000777bb65e0a63  vmovaps [rsp+0xC0], xmm13
0000777bb65e0a6c  vmovaps [rsp+0xD0], xmm14
0000777bb65e0a75  vmovaps [rsp+0xE0], xmm15
0000777bb65e0a7e  sub rsp, 0x30
0000777bb65e0a82  movaps [rsp], xmm7
0000777bb65e0a86  movaps [rsp+0x10], xmm11
0000777bb65e0a8c  movaps [rsp+0x20], xmm9
0000777bb65e0a92  lea rdi, [rsp]
0000777bb65e0a96  mov esi, 0x00
0000777bb65e0a9b  mov rax, 0x569DC437B530
0000777bb65e0aa5  call rax
0000777bb65e0aa7  movaps xmm7, [rsp]
0000777bb65e0aab  add rsp, 0x30
0000777bb65e0aaf  vmovaps xmm0, [rsp]
0000777bb65e0ab4  vmovaps xmm1, [rsp+0x10]
0000777bb65e0aba  vmovaps xmm2, [rsp+0x20]
0000777bb65e0ac0  vmovaps xmm3, [rsp+0x30]
0000777bb65e0ac6  vmovaps xmm4, [rsp+0x40]
0000777bb65e0acc  vmovaps xmm5, [rsp+0x50]
0000777bb65e0ad2  vmovaps xmm6, [rsp+0x60]
0000777bb65e0ad8  vmovaps xmm8, [rsp+0x70]
0000777bb65e0ade  vmovaps xmm9, [rsp+0x80]
0000777bb65e0ae7  vmovaps xmm10, [rsp+0x90]
0000777bb65e0af0  vmovaps xmm11, [rsp+0xA0]
0000777bb65e0af9  vmovaps xmm12, [rsp+0xB0]
0000777bb65e0b02  vmovaps xmm13, [rsp+0xC0]
0000777bb65e0b0b  vmovaps xmm14, [rsp+0xD0]
0000777bb65e0b14  vmovaps xmm15, [rsp+0xE0]
0000777bb65e0b1d  add rsp, 0xF0
0000777bb65e0b24  pop r11
0000777bb65e0b26  pop r10
0000777bb65e0b28  pop r9
0000777bb65e0b2a  pop r8
0000777bb65e0b2c  pop rsi
0000777bb65e0b2d  pop rdi
0000777bb65e0b2e  pop rdx
0000777bb65e0b2f  pop rcx
0000777bb65e0b30  pop rax
0000777bb65e0b31  add rsp, 0x08
0000777bb65e0b35  jmp 0x0000777BB65DC685
0000777bb65e0b3a  sub rsp, 0x08
0000777bb65e0b3e  push rax
0000777bb65e0b3f  push rcx
0000777bb65e0b40  push rdx
0000777bb65e0b41  push rdi
0000777bb65e0b42  push rsi
0000777bb65e0b43  push r8
0000777bb65e0b45  push r9
0000777bb65e0b47  push r10
0000777bb65e0b49  push r11
0000777bb65e0b4b  sub rsp, 0xF0
0000777bb65e0b52  vmovaps [rsp], xmm0
0000777bb65e0b57  vmovaps [rsp+0x10], xmm1
0000777bb65e0b5d  vmovaps [rsp+0x20], xmm2
0000777bb65e0b63  vmovaps [rsp+0x30], xmm3
0000777bb65e0b69  vmovaps [rsp+0x40], xmm4
0000777bb65e0b6f  vmovaps [rsp+0x50], xmm5
0000777bb65e0b75  vmovaps [rsp+0x60], xmm6
0000777bb65e0b7b  vmovaps [rsp+0x70], xmm7
0000777bb65e0b81  vmovaps [rsp+0x80], xmm8
0000777bb65e0b8a  vmovaps [rsp+0x90], xmm9
0000777bb65e0b93  vmovaps [rsp+0xA0], xmm10
0000777bb65e0b9c  vmovaps [rsp+0xB0], xmm12
0000777bb65e0ba5  vmovaps [rsp+0xC0], xmm13
0000777bb65e0bae  vmovaps [rsp+0xD0], xmm14
0000777bb65e0bb7  vmovaps [rsp+0xE0], xmm15
0000777bb65e0bc0  sub rsp, 0x30
0000777bb65e0bc4  movaps [rsp], xmm11
0000777bb65e0bc9  movaps [rsp+0x10], xmm10
0000777bb65e0bcf  movaps [rsp+0x20], xmm14
0000777bb65e0bd5  lea rdi, [rsp]
0000777bb65e0bd9  mov esi, 0x00
0000777bb65e0bde  mov rax, 0x569DC437B530
0000777bb65e0be8  call rax
0000777bb65e0bea  movaps xmm11, [rsp]
0000777bb65e0bef  add rsp, 0x30
0000777bb65e0bf3  vmovaps xmm0, [rsp]
0000777bb65e0bf8  vmovaps xmm1, [rsp+0x10]
0000777bb65e0bfe  vmovaps xmm2, [rsp+0x20]
0000777bb65e0c04  vmovaps xmm3, [rsp+0x30]
0000777bb65e0c0a  vmovaps xmm4, [rsp+0x40]
0000777bb65e0c10  vmovaps xmm5, [rsp+0x50]
0000777bb65e0c16  vmovaps xmm6, [rsp+0x60]
0000777bb65e0c1c  vmovaps xmm7, [rsp+0x70]
0000777bb65e0c22  vmovaps xmm8, [rsp+0x80]
0000777bb65e0c2b  vmovaps xmm9, [rsp+0x90]
0000777bb65e0c34  vmovaps xmm10, [rsp+0xA0]
0000777bb65e0c3d  vmovaps xmm12, [rsp+0xB0]
0000777bb65e0c46  vmovaps xmm13, [rsp+0xC0]
0000777bb65e0c4f  vmovaps xmm14, [rsp+0xD0]
0000777bb65e0c58  vmovaps xmm15, [rsp+0xE0]
0000777bb65e0c61  add rsp, 0xF0
0000777bb65e0c68  pop r11
0000777bb65e0c6a  pop r10
0000777bb65e0c6c  pop r9
0000777bb65e0c6e  pop r8
0000777bb65e0c70  pop rsi
0000777bb65e0c71  pop rdi
0000777bb65e0c72  pop rdx
0000777bb65e0c73  pop rcx
0000777bb65e0c74  pop rax
0000777bb65e0c75  add rsp, 0x08
0000777bb65e0c79  jmp 0x0000777BB65DC6A0
0000777bb65e0c7e  call 0x0000777BB64C33A0
0000777bb65e0c83  jmp 0x0000777BB65DC6AA
0000777bb65e0c88  sub rsp, 0x08
0000777bb65e0c8c  push rax
0000777bb65e0c8d  push rcx
0000777bb65e0c8e  push rdx
0000777bb65e0c8f  push rdi
0000777bb65e0c90  push rsi
0000777bb65e0c91  push r8
0000777bb65e0c93  push r9
0000777bb65e0c95  push r10
0000777bb65e0c97  push r11
0000777bb65e0c99  sub rsp, 0xF0
0000777bb65e0ca0  vmovaps [rsp], xmm0
0000777bb65e0ca5  vmovaps [rsp+0x10], xmm1
0000777bb65e0cab  vmovaps [rsp+0x20], xmm2
0000777bb65e0cb1  vmovaps [rsp+0x30], xmm3
0000777bb65e0cb7  vmovaps [rsp+0x40], xmm4
0000777bb65e0cbd  vmovaps [rsp+0x50], xmm5
0000777bb65e0cc3  vmovaps [rsp+0x60], xmm6
0000777bb65e0cc9  vmovaps [rsp+0x70], xmm7
0000777bb65e0ccf  vmovaps [rsp+0x80], xmm8
0000777bb65e0cd8  vmovaps [rsp+0x90], xmm9
0000777bb65e0ce1  vmovaps [rsp+0xA0], xmm11
0000777bb65e0cea  vmovaps [rsp+0xB0], xmm12
0000777bb65e0cf3  vmovaps [rsp+0xC0], xmm13
0000777bb65e0cfc  vmovaps [rsp+0xD0], xmm14
0000777bb65e0d05  vmovaps [rsp+0xE0], xmm15
0000777bb65e0d0e  sub rsp, 0x30
0000777bb65e0d12  movaps [rsp], xmm10
0000777bb65e0d17  movaps [rsp+0x10], xmm1
0000777bb65e0d1c  movaps [rsp+0x20], xmm12
0000777bb65e0d22  lea rdi, [rsp]
0000777bb65e0d26  mov esi, 0x00
0000777bb65e0d2b  mov rax, 0x569DC437B530
0000777bb65e0d35  call rax
0000777bb65e0d37  movaps xmm10, [rsp]
0000777bb65e0d3c  add rsp, 0x30
0000777bb65e0d40  vmovaps xmm0, [rsp]
0000777bb65e0d45  vmovaps xmm1, [rsp+0x10]
0000777bb65e0d4b  vmovaps xmm2, [rsp+0x20]
0000777bb65e0d51  vmovaps xmm3, [rsp+0x30]
0000777bb65e0d57  vmovaps xmm4, [rsp+0x40]
0000777bb65e0d5d  vmovaps xmm5, [rsp+0x50]
0000777bb65e0d63  vmovaps xmm6, [rsp+0x60]
0000777bb65e0d69  vmovaps xmm7, [rsp+0x70]
0000777bb65e0d6f  vmovaps xmm8, [rsp+0x80]
0000777bb65e0d78  vmovaps xmm9, [rsp+0x90]
0000777bb65e0d81  vmovaps xmm11, [rsp+0xA0]
0000777bb65e0d8a  vmovaps xmm12, [rsp+0xB0]
0000777bb65e0d93  vmovaps xmm13, [rsp+0xC0]
0000777bb65e0d9c  vmovaps xmm14, [rsp+0xD0]
0000777bb65e0da5  vmovaps xmm15, [rsp+0xE0]
0000777bb65e0dae  add rsp, 0xF0
0000777bb65e0db5  pop r11
0000777bb65e0db7  pop r10
0000777bb65e0db9  pop r9
0000777bb65e0dbb  pop r8
0000777bb65e0dbd  pop rsi
0000777bb65e0dbe  pop rdi
0000777bb65e0dbf  pop rdx
0000777bb65e0dc0  pop rcx
0000777bb65e0dc1  pop rax
0000777bb65e0dc2  add rsp, 0x08
0000777bb65e0dc6  jmp 0x0000777BB65DC6CD
0000777bb65e0dcb  sub rsp, 0x08
0000777bb65e0dcf  push rax
0000777bb65e0dd0  push rcx
0000777bb65e0dd1  push rdx
0000777bb65e0dd2  push rdi
0000777bb65e0dd3  push rsi
0000777bb65e0dd4  push r8
0000777bb65e0dd6  push r9
0000777bb65e0dd8  push r10
0000777bb65e0dda  push r11
0000777bb65e0ddc  sub rsp, 0xF0
0000777bb65e0de3  vmovaps [rsp], xmm0
0000777bb65e0de8  vmovaps [rsp+0x10], xmm1
0000777bb65e0dee  vmovaps [rsp+0x20], xmm2
0000777bb65e0df4  vmovaps [rsp+0x30], xmm3
0000777bb65e0dfa  vmovaps [rsp+0x40], xmm4
0000777bb65e0e00  vmovaps [rsp+0x50], xmm5
0000777bb65e0e06  vmovaps [rsp+0x60], xmm6
0000777bb65e0e0c  vmovaps [rsp+0x70], xmm7
0000777bb65e0e12  vmovaps [rsp+0x80], xmm8
0000777bb65e0e1b  vmovaps [rsp+0x90], xmm9
0000777bb65e0e24  vmovaps [rsp+0xA0], xmm10
0000777bb65e0e2d  vmovaps [rsp+0xB0], xmm11
0000777bb65e0e36  vmovaps [rsp+0xC0], xmm13
0000777bb65e0e3f  vmovaps [rsp+0xD0], xmm14
0000777bb65e0e48  vmovaps [rsp+0xE0], xmm15
0000777bb65e0e51  sub rsp, 0x30
0000777bb65e0e55  movaps [rsp], xmm12
0000777bb65e0e5a  movaps [rsp+0x10], xmm14
0000777bb65e0e60  movaps [rsp+0x20], xmm1
0000777bb65e0e65  lea rdi, [rsp]
0000777bb65e0e69  mov esi, 0x00
0000777bb65e0e6e  mov rax, 0x569DC437B530
0000777bb65e0e78  call rax
0000777bb65e0e7a  movaps xmm12, [rsp]
0000777bb65e0e7f  add rsp, 0x30
0000777bb65e0e83  vmovaps xmm0, [rsp]
0000777bb65e0e88  vmovaps xmm1, [rsp+0x10]
0000777bb65e0e8e  vmovaps xmm2, [rsp+0x20]
0000777bb65e0e94  vmovaps xmm3, [rsp+0x30]
0000777bb65e0e9a  vmovaps xmm4, [rsp+0x40]
0000777bb65e0ea0  vmovaps xmm5, [rsp+0x50]
0000777bb65e0ea6  vmovaps xmm6, [rsp+0x60]
0000777bb65e0eac  vmovaps xmm7, [rsp+0x70]
0000777bb65e0eb2  vmovaps xmm8, [rsp+0x80]
0000777bb65e0ebb  vmovaps xmm9, [rsp+0x90]
0000777bb65e0ec4  vmovaps xmm10, [rsp+0xA0]
0000777bb65e0ecd  vmovaps xmm11, [rsp+0xB0]
0000777bb65e0ed6  vmovaps xmm13, [rsp+0xC0]
0000777bb65e0edf  vmovaps xmm14, [rsp+0xD0]
0000777bb65e0ee8  vmovaps xmm15, [rsp+0xE0]
0000777bb65e0ef1  add rsp, 0xF0
0000777bb65e0ef8  pop r11
0000777bb65e0efa  pop r10
0000777bb65e0efc  pop r9
0000777bb65e0efe  pop r8
0000777bb65e0f00  pop rsi
0000777bb65e0f01  pop rdi
0000777bb65e0f02  pop rdx
0000777bb65e0f03  pop rcx
0000777bb65e0f04  pop rax
0000777bb65e0f05  add rsp, 0x08
0000777bb65e0f09  jmp 0x0000777BB65DC6FC
0000777bb65e0f0e  sub rsp, 0x08
0000777bb65e0f12  push rax
0000777bb65e0f13  push rcx
0000777bb65e0f14  push rdx
0000777bb65e0f15  push rdi
0000777bb65e0f16  push rsi
0000777bb65e0f17  push r8
0000777bb65e0f19  push r9
0000777bb65e0f1b  push r10
0000777bb65e0f1d  push r11
0000777bb65e0f1f  sub rsp, 0xF0
0000777bb65e0f26  vmovaps [rsp], xmm0
0000777bb65e0f2b  vmovaps [rsp+0x10], xmm1
0000777bb65e0f31  vmovaps [rsp+0x20], xmm2
0000777bb65e0f37  vmovaps [rsp+0x30], xmm3
0000777bb65e0f3d  vmovaps [rsp+0x40], xmm4
0000777bb65e0f43  vmovaps [rsp+0x50], xmm5
0000777bb65e0f49  vmovaps [rsp+0x60], xmm6
0000777bb65e0f4f  vmovaps [rsp+0x70], xmm7
0000777bb65e0f55  vmovaps [rsp+0x80], xmm8
0000777bb65e0f5e  vmovaps [rsp+0x90], xmm9
0000777bb65e0f67  vmovaps [rsp+0xA0], xmm10
0000777bb65e0f70  vmovaps [rsp+0xB0], xmm11
0000777bb65e0f79  vmovaps [rsp+0xC0], xmm12
0000777bb65e0f82  vmovaps [rsp+0xD0], xmm13
0000777bb65e0f8b  vmovaps [rsp+0xE0], xmm15
0000777bb65e0f94  sub rsp, 0x30
0000777bb65e0f98  movaps [rsp], xmm14
0000777bb65e0f9d  movaps [rsp+0x10], xmm9
0000777bb65e0fa3  movaps [rsp+0x20], xmm1
0000777bb65e0fa8  lea rdi, [rsp]
0000777bb65e0fac  mov esi, 0x00
0000777bb65e0fb1  mov rax, 0x569DC437B530
0000777bb65e0fbb  call rax
0000777bb65e0fbd  movaps xmm14, [rsp]
0000777bb65e0fc2  add rsp, 0x30
0000777bb65e0fc6  vmovaps xmm0, [rsp]
0000777bb65e0fcb  vmovaps xmm1, [rsp+0x10]
0000777bb65e0fd1  vmovaps xmm2, [rsp+0x20]
0000777bb65e0fd7  vmovaps xmm3, [rsp+0x30]
0000777bb65e0fdd  vmovaps xmm4, [rsp+0x40]
0000777bb65e0fe3  vmovaps xmm5, [rsp+0x50]
0000777bb65e0fe9  vmovaps xmm6, [rsp+0x60]
0000777bb65e0fef  vmovaps xmm7, [rsp+0x70]
0000777bb65e0ff5  vmovaps xmm8, [rsp+0x80]
0000777bb65e0ffe  vmovaps xmm9, [rsp+0x90]
0000777bb65e1007  vmovaps xmm10, [rsp+0xA0]
0000777bb65e1010  vmovaps xmm11, [rsp+0xB0]
0000777bb65e1019  vmovaps xmm12, [rsp+0xC0]
0000777bb65e1022  vmovaps xmm13, [rsp+0xD0]
0000777bb65e102b  vmovaps xmm15, [rsp+0xE0]
0000777bb65e1034  add rsp, 0xF0
0000777bb65e103b  pop r11
0000777bb65e103d  pop r10
0000777bb65e103f  pop r9
0000777bb65e1041  pop r8
0000777bb65e1043  pop rsi
0000777bb65e1044  pop rdi
0000777bb65e1045  pop rdx
0000777bb65e1046  pop rcx
0000777bb65e1047  pop rax
0000777bb65e1048  add rsp, 0x08
0000777bb65e104c  jmp 0x0000777BB65DC72B
0000777bb65e1051  sub rsp, 0x08
0000777bb65e1055  push rax
0000777bb65e1056  push rcx
0000777bb65e1057  push rdx
0000777bb65e1058  push rdi
0000777bb65e1059  push rsi
0000777bb65e105a  push r8
0000777bb65e105c  push r9
0000777bb65e105e  push r10
0000777bb65e1060  push r11
0000777bb65e1062  sub rsp, 0xF0
0000777bb65e1069  vmovaps [rsp], xmm0
0000777bb65e106e  vmovaps [rsp+0x10], xmm2
0000777bb65e1074  vmovaps [rsp+0x20], xmm3
0000777bb65e107a  vmovaps [rsp+0x30], xmm4
0000777bb65e1080  vmovaps [rsp+0x40], xmm5
0000777bb65e1086  vmovaps [rsp+0x50], xmm6
0000777bb65e108c  vmovaps [rsp+0x60], xmm7
0000777bb65e1092  vmovaps [rsp+0x70], xmm8
0000777bb65e1098  vmovaps [rsp+0x80], xmm9
0000777bb65e10a1  vmovaps [rsp+0x90], xmm10
0000777bb65e10aa  vmovaps [rsp+0xA0], xmm11
0000777bb65e10b3  vmovaps [rsp+0xB0], xmm12
0000777bb65e10bc  vmovaps [rsp+0xC0], xmm13
0000777bb65e10c5  vmovaps [rsp+0xD0], xmm14
0000777bb65e10ce  vmovaps [rsp+0xE0], xmm15
0000777bb65e10d7  sub rsp, 0x30
0000777bb65e10db  movaps [rsp], xmm1
0000777bb65e10df  movaps [rsp+0x10], xmm13
0000777bb65e10e5  movaps [rsp+0x20], xmm8
0000777bb65e10eb  lea rdi, [rsp]
0000777bb65e10ef  mov esi, 0x00
0000777bb65e10f4  mov rax, 0x569DC437B530
0000777bb65e10fe  call rax
0000777bb65e1100  movaps xmm1, [rsp]
0000777bb65e1104  add rsp, 0x30
0000777bb65e1108  vmovaps xmm0, [rsp]
0000777bb65e110d  vmovaps xmm2, [rsp+0x10]
0000777bb65e1113  vmovaps xmm3, [rsp+0x20]
0000777bb65e1119  vmovaps xmm4, [rsp+0x30]
0000777bb65e111f  vmovaps xmm5, [rsp+0x40]
0000777bb65e1125  vmovaps xmm6, [rsp+0x50]
0000777bb65e112b  vmovaps xmm7, [rsp+0x60]
0000777bb65e1131  vmovaps xmm8, [rsp+0x70]
0000777bb65e1137  vmovaps xmm9, [rsp+0x80]
0000777bb65e1140  vmovaps xmm10, [rsp+0x90]
0000777bb65e1149  vmovaps xmm11, [rsp+0xA0]
0000777bb65e1152  vmovaps xmm12, [rsp+0xB0]
0000777bb65e115b  vmovaps xmm13, [rsp+0xC0]
0000777bb65e1164  vmovaps xmm14, [rsp+0xD0]
0000777bb65e116d  vmovaps xmm15, [rsp+0xE0]
0000777bb65e1176  add rsp, 0xF0
0000777bb65e117d  pop r11
0000777bb65e117f  pop r10
0000777bb65e1181  pop r9
0000777bb65e1183  pop r8
0000777bb65e1185  pop rsi
0000777bb65e1186  pop rdi
0000777bb65e1187  pop rdx
0000777bb65e1188  pop rcx
0000777bb65e1189  pop rax
0000777bb65e118a  add rsp, 0x08
0000777bb65e118e  jmp 0x0000777BB65DC74D
0000777bb65e1193  call 0x0000777BB640C260
0000777bb65e1198  jmp 0x0000777BB65DC75B
0000777bb65e119d  call 0x0000777BB64BD750
0000777bb65e11a2  jmp 0x0000777BB65DC765
0000777bb65e11a7  sub rsp, 0x08
0000777bb65e11ab  push rax
0000777bb65e11ac  push rcx
0000777bb65e11ad  push rdx
0000777bb65e11ae  push rdi
0000777bb65e11af  push rsi
0000777bb65e11b0  push r8
0000777bb65e11b2  push r9
0000777bb65e11b4  push r10
0000777bb65e11b6  push r11
0000777bb65e11b8  sub rsp, 0xF0
0000777bb65e11bf  vmovaps [rsp], xmm0
0000777bb65e11c4  vmovaps [rsp+0x10], xmm1
0000777bb65e11ca  vmovaps [rsp+0x20], xmm2
0000777bb65e11d0  vmovaps [rsp+0x30], xmm3
0000777bb65e11d6  vmovaps [rsp+0x40], xmm4
0000777bb65e11dc  vmovaps [rsp+0x50], xmm5
0000777bb65e11e2  vmovaps [rsp+0x60], xmm6
0000777bb65e11e8  vmovaps [rsp+0x70], xmm7
0000777bb65e11ee  vmovaps [rsp+0x80], xmm9
0000777bb65e11f7  vmovaps [rsp+0x90], xmm10
0000777bb65e1200  vmovaps [rsp+0xA0], xmm11
0000777bb65e1209  vmovaps [rsp+0xB0], xmm12
0000777bb65e1212  vmovaps [rsp+0xC0], xmm13
0000777bb65e121b  vmovaps [rsp+0xD0], xmm14
0000777bb65e1224  vmovaps [rsp+0xE0], xmm15
0000777bb65e122d  sub rsp, 0x30
0000777bb65e1231  movaps [rsp], xmm8
0000777bb65e1236  movaps [rsp+0x10], xmm15
0000777bb65e123c  movaps [rsp+0x20], xmm7
0000777bb65e1241  lea rdi, [rsp]
0000777bb65e1245  mov esi, 0x00
0000777bb65e124a  mov rax, 0x569DC437B530
0000777bb65e1254  call rax
0000777bb65e1256  movaps xmm8, [rsp]
0000777bb65e125b  add rsp, 0x30
0000777bb65e125f  vmovaps xmm0, [rsp]
0000777bb65e1264  vmovaps xmm1, [rsp+0x10]
0000777bb65e126a  vmovaps xmm2, [rsp+0x20]
0000777bb65e1270  vmovaps xmm3, [rsp+0x30]
0000777bb65e1276  vmovaps xmm4, [rsp+0x40]
0000777bb65e127c  vmovaps xmm5, [rsp+0x50]
0000777bb65e1282  vmovaps xmm6, [rsp+0x60]
0000777bb65e1288  vmovaps xmm7, [rsp+0x70]
0000777bb65e128e  vmovaps xmm9, [rsp+0x80]
0000777bb65e1297  vmovaps xmm10, [rsp+0x90]
0000777bb65e12a0  vmovaps xmm11, [rsp+0xA0]
0000777bb65e12a9  vmovaps xmm12, [rsp+0xB0]
0000777bb65e12b2  vmovaps xmm13, [rsp+0xC0]
0000777bb65e12bb  vmovaps xmm14, [rsp+0xD0]
0000777bb65e12c4  vmovaps xmm15, [rsp+0xE0]
0000777bb65e12cd  add rsp, 0xF0
0000777bb65e12d4  pop r11
0000777bb65e12d6  pop r10
0000777bb65e12d8  pop r9
0000777bb65e12da  pop r8
0000777bb65e12dc  pop rsi
0000777bb65e12dd  pop rdi
0000777bb65e12de  pop rdx
0000777bb65e12df  pop rcx
0000777bb65e12e0  pop rax
0000777bb65e12e1  add rsp, 0x08
0000777bb65e12e5  jmp 0x0000777BB65DC787
0000777bb65e12ea  sub rsp, 0x08
0000777bb65e12ee  push rax
0000777bb65e12ef  push rcx
0000777bb65e12f0  push rdx
0000777bb65e12f1  push rdi
0000777bb65e12f2  push rsi
0000777bb65e12f3  push r8
0000777bb65e12f5  push r9
0000777bb65e12f7  push r10
0000777bb65e12f9  push r11
0000777bb65e12fb  sub rsp, 0xF0
0000777bb65e1302  vmovaps [rsp], xmm0
0000777bb65e1307  vmovaps [rsp+0x10], xmm1
0000777bb65e130d  vmovaps [rsp+0x20], xmm2
0000777bb65e1313  vmovaps [rsp+0x30], xmm3
0000777bb65e1319  vmovaps [rsp+0x40], xmm4
0000777bb65e131f  vmovaps [rsp+0x50], xmm5
0000777bb65e1325  vmovaps [rsp+0x60], xmm6
0000777bb65e132b  vmovaps [rsp+0x70], xmm8
0000777bb65e1331  vmovaps [rsp+0x80], xmm9
0000777bb65e133a  vmovaps [rsp+0x90], xmm10
0000777bb65e1343  vmovaps [rsp+0xA0], xmm11
0000777bb65e134c  vmovaps [rsp+0xB0], xmm12
0000777bb65e1355  vmovaps [rsp+0xC0], xmm13
0000777bb65e135e  vmovaps [rsp+0xD0], xmm14
0000777bb65e1367  vmovaps [rsp+0xE0], xmm15
0000777bb65e1370  sub rsp, 0x30
0000777bb65e1374  movaps [rsp], xmm7
0000777bb65e1378  movaps [rsp+0x10], xmm9
0000777bb65e137e  movaps [rsp+0x20], xmm15
0000777bb65e1384  lea rdi, [rsp]
0000777bb65e1388  mov esi, 0x00
0000777bb65e138d  mov rax, 0x569DC437B530
0000777bb65e1397  call rax
0000777bb65e1399  movaps xmm7, [rsp]
0000777bb65e139d  add rsp, 0x30
0000777bb65e13a1  vmovaps xmm0, [rsp]
0000777bb65e13a6  vmovaps xmm1, [rsp+0x10]
0000777bb65e13ac  vmovaps xmm2, [rsp+0x20]
0000777bb65e13b2  vmovaps xmm3, [rsp+0x30]
0000777bb65e13b8  vmovaps xmm4, [rsp+0x40]
0000777bb65e13be  vmovaps xmm5, [rsp+0x50]
0000777bb65e13c4  vmovaps xmm6, [rsp+0x60]
0000777bb65e13ca  vmovaps xmm8, [rsp+0x70]
0000777bb65e13d0  vmovaps xmm9, [rsp+0x80]
0000777bb65e13d9  vmovaps xmm10, [rsp+0x90]
0000777bb65e13e2  vmovaps xmm11, [rsp+0xA0]
0000777bb65e13eb  vmovaps xmm12, [rsp+0xB0]
0000777bb65e13f4  vmovaps xmm13, [rsp+0xC0]
0000777bb65e13fd  vmovaps xmm14, [rsp+0xD0]
0000777bb65e1406  vmovaps xmm15, [rsp+0xE0]
0000777bb65e140f  add rsp, 0xF0
0000777bb65e1416  pop r11
0000777bb65e1418  pop r10
0000777bb65e141a  pop r9
0000777bb65e141c  pop r8
0000777bb65e141e  pop rsi
0000777bb65e141f  pop rdi
0000777bb65e1420  pop rdx
0000777bb65e1421  pop rcx
0000777bb65e1422  pop rax
0000777bb65e1423  add rsp, 0x08
0000777bb65e1427  jmp 0x0000777BB65DC7B4
0000777bb65e142c  sub rsp, 0x08
0000777bb65e1430  push rax
0000777bb65e1431  push rcx
0000777bb65e1432  push rdx
0000777bb65e1433  push rdi
0000777bb65e1434  push rsi
0000777bb65e1435  push r8
0000777bb65e1437  push r9
0000777bb65e1439  push r10
0000777bb65e143b  push r11
0000777bb65e143d  sub rsp, 0xF0
0000777bb65e1444  vmovaps [rsp], xmm0
0000777bb65e1449  vmovaps [rsp+0x10], xmm1
0000777bb65e144f  vmovaps [rsp+0x20], xmm2
0000777bb65e1455  vmovaps [rsp+0x30], xmm3
0000777bb65e145b  vmovaps [rsp+0x40], xmm4
0000777bb65e1461  vmovaps [rsp+0x50], xmm5
0000777bb65e1467  vmovaps [rsp+0x60], xmm6
0000777bb65e146d  vmovaps [rsp+0x70], xmm7
0000777bb65e1473  vmovaps [rsp+0x80], xmm8
0000777bb65e147c  vmovaps [rsp+0x90], xmm10
0000777bb65e1485  vmovaps [rsp+0xA0], xmm11
0000777bb65e148e  vmovaps [rsp+0xB0], xmm12
0000777bb65e1497  vmovaps [rsp+0xC0], xmm13
0000777bb65e14a0  vmovaps [rsp+0xD0], xmm14
0000777bb65e14a9  vmovaps [rsp+0xE0], xmm15
0000777bb65e14b2  sub rsp, 0x30
0000777bb65e14b6  movaps [rsp], xmm9
0000777bb65e14bb  movaps [rsp+0x10], xmm13
0000777bb65e14c1  movaps [rsp+0x20], xmm15
0000777bb65e14c7  lea rdi, [rsp]
0000777bb65e14cb  mov esi, 0x00
0000777bb65e14d0  mov rax, 0x569DC437B530
0000777bb65e14da  call rax
0000777bb65e14dc  movaps xmm9, [rsp]
0000777bb65e14e1  add rsp, 0x30
0000777bb65e14e5  vmovaps xmm0, [rsp]
0000777bb65e14ea  vmovaps xmm1, [rsp+0x10]
0000777bb65e14f0  vmovaps xmm2, [rsp+0x20]
0000777bb65e14f6  vmovaps xmm3, [rsp+0x30]
0000777bb65e14fc  vmovaps xmm4, [rsp+0x40]
0000777bb65e1502  vmovaps xmm5, [rsp+0x50]
0000777bb65e1508  vmovaps xmm6, [rsp+0x60]
0000777bb65e150e  vmovaps xmm7, [rsp+0x70]
0000777bb65e1514  vmovaps xmm8, [rsp+0x80]
0000777bb65e151d  vmovaps xmm10, [rsp+0x90]
0000777bb65e1526  vmovaps xmm11, [rsp+0xA0]
0000777bb65e152f  vmovaps xmm12, [rsp+0xB0]
0000777bb65e1538  vmovaps xmm13, [rsp+0xC0]
0000777bb65e1541  vmovaps xmm14, [rsp+0xD0]
0000777bb65e154a  vmovaps xmm15, [rsp+0xE0]
0000777bb65e1553  add rsp, 0xF0
0000777bb65e155a  pop r11
0000777bb65e155c  pop r10
0000777bb65e155e  pop r9
0000777bb65e1560  pop r8
0000777bb65e1562  pop rsi
0000777bb65e1563  pop rdi
0000777bb65e1564  pop rdx
0000777bb65e1565  pop rcx
0000777bb65e1566  pop rax
0000777bb65e1567  add rsp, 0x08
0000777bb65e156b  jmp 0x0000777BB65DC7E2
0000777bb65e1570  sub rsp, 0x08
0000777bb65e1574  push rax
0000777bb65e1575  push rcx
0000777bb65e1576  push rdx
0000777bb65e1577  push rdi
0000777bb65e1578  push rsi
0000777bb65e1579  push r8
0000777bb65e157b  push r9
0000777bb65e157d  push r10
0000777bb65e157f  push r11
0000777bb65e1581  sub rsp, 0xF0
0000777bb65e1588  vmovaps [rsp], xmm0
0000777bb65e158d  vmovaps [rsp+0x10], xmm1
0000777bb65e1593  vmovaps [rsp+0x20], xmm2
0000777bb65e1599  vmovaps [rsp+0x30], xmm3
0000777bb65e159f  vmovaps [rsp+0x40], xmm4
0000777bb65e15a5  vmovaps [rsp+0x50], xmm5
0000777bb65e15ab  vmovaps [rsp+0x60], xmm6
0000777bb65e15b1  vmovaps [rsp+0x70], xmm7
0000777bb65e15b7  vmovaps [rsp+0x80], xmm8
0000777bb65e15c0  vmovaps [rsp+0x90], xmm9
0000777bb65e15c9  vmovaps [rsp+0xA0], xmm10
0000777bb65e15d2  vmovaps [rsp+0xB0], xmm11
0000777bb65e15db  vmovaps [rsp+0xC0], xmm12
0000777bb65e15e4  vmovaps [rsp+0xD0], xmm13
0000777bb65e15ed  vmovaps [rsp+0xE0], xmm14
0000777bb65e15f6  sub rsp, 0x30
0000777bb65e15fa  movaps [rsp], xmm15
0000777bb65e15ff  movaps [rsp+0x10], xmm11
0000777bb65e1605  movaps [rsp+0x20], xmm12
0000777bb65e160b  lea rdi, [rsp]
0000777bb65e160f  mov esi, 0x00
0000777bb65e1614  mov rax, 0x569DC437B530
0000777bb65e161e  call rax
0000777bb65e1620  movaps xmm15, [rsp]
0000777bb65e1625  add rsp, 0x30
0000777bb65e1629  vmovaps xmm0, [rsp]
0000777bb65e162e  vmovaps xmm1, [rsp+0x10]
0000777bb65e1634  vmovaps xmm2, [rsp+0x20]
0000777bb65e163a  vmovaps xmm3, [rsp+0x30]
0000777bb65e1640  vmovaps xmm4, [rsp+0x40]
0000777bb65e1646  vmovaps xmm5, [rsp+0x50]
0000777bb65e164c  vmovaps xmm6, [rsp+0x60]
0000777bb65e1652  vmovaps xmm7, [rsp+0x70]
0000777bb65e1658  vmovaps xmm8, [rsp+0x80]
0000777bb65e1661  vmovaps xmm9, [rsp+0x90]
0000777bb65e166a  vmovaps xmm10, [rsp+0xA0]
0000777bb65e1673  vmovaps xmm11, [rsp+0xB0]
0000777bb65e167c  vmovaps xmm12, [rsp+0xC0]
0000777bb65e1685  vmovaps xmm13, [rsp+0xD0]
0000777bb65e168e  vmovaps xmm14, [rsp+0xE0]
0000777bb65e1697  add rsp, 0xF0
0000777bb65e169e  pop r11
0000777bb65e16a0  pop r10
0000777bb65e16a2  pop r9
0000777bb65e16a4  pop r8
0000777bb65e16a6  pop rsi
0000777bb65e16a7  pop rdi
0000777bb65e16a8  pop rdx
0000777bb65e16a9  pop rcx
0000777bb65e16aa  pop rax
0000777bb65e16ab  add rsp, 0x08
0000777bb65e16af  jmp 0x0000777BB65DC7FD
0000777bb65e16b4  sub rsp, 0x08
0000777bb65e16b8  push rax
0000777bb65e16b9  push rcx
0000777bb65e16ba  push rdx
0000777bb65e16bb  push rdi
0000777bb65e16bc  push rsi
0000777bb65e16bd  push r8
0000777bb65e16bf  push r9
0000777bb65e16c1  push r10
0000777bb65e16c3  push r11
0000777bb65e16c5  sub rsp, 0xF0
0000777bb65e16cc  vmovaps [rsp], xmm0
0000777bb65e16d1  vmovaps [rsp+0x10], xmm1
0000777bb65e16d7  vmovaps [rsp+0x20], xmm2
0000777bb65e16dd  vmovaps [rsp+0x30], xmm3
0000777bb65e16e3  vmovaps [rsp+0x40], xmm4
0000777bb65e16e9  vmovaps [rsp+0x50], xmm5
0000777bb65e16ef  vmovaps [rsp+0x60], xmm6
0000777bb65e16f5  vmovaps [rsp+0x70], xmm7
0000777bb65e16fb  vmovaps [rsp+0x80], xmm8
0000777bb65e1704  vmovaps [rsp+0x90], xmm9
0000777bb65e170d  vmovaps [rsp+0xA0], xmm10
0000777bb65e1716  vmovaps [rsp+0xB0], xmm11
0000777bb65e171f  vmovaps [rsp+0xC0], xmm12
0000777bb65e1728  vmovaps [rsp+0xD0], xmm14
0000777bb65e1731  vmovaps [rsp+0xE0], xmm15
0000777bb65e173a  sub rsp, 0x30
0000777bb65e173e  movaps [rsp], xmm13
0000777bb65e1743  movaps [rsp+0x10], xmm10
0000777bb65e1749  movaps [rsp+0x20], xmm14
0000777bb65e174f  lea rdi, [rsp]
0000777bb65e1753  mov esi, 0x00
0000777bb65e1758  mov rax, 0x569DC437B530
0000777bb65e1762  call rax
0000777bb65e1764  movaps xmm13, [rsp]
0000777bb65e1769  add rsp, 0x30
0000777bb65e176d  vmovaps xmm0, [rsp]
0000777bb65e1772  vmovaps xmm1, [rsp+0x10]
0000777bb65e1778  vmovaps xmm2, [rsp+0x20]
0000777bb65e177e  vmovaps xmm3, [rsp+0x30]
0000777bb65e1784  vmovaps xmm4, [rsp+0x40]
0000777bb65e178a  vmovaps xmm5, [rsp+0x50]
0000777bb65e1790  vmovaps xmm6, [rsp+0x60]
0000777bb65e1796  vmovaps xmm7, [rsp+0x70]
0000777bb65e179c  vmovaps xmm8, [rsp+0x80]
0000777bb65e17a5  vmovaps xmm9, [rsp+0x90]
0000777bb65e17ae  vmovaps xmm10, [rsp+0xA0]
0000777bb65e17b7  vmovaps xmm11, [rsp+0xB0]
0000777bb65e17c0  vmovaps xmm12, [rsp+0xC0]
0000777bb65e17c9  vmovaps xmm14, [rsp+0xD0]
0000777bb65e17d2  vmovaps xmm15, [rsp+0xE0]
0000777bb65e17db  add rsp, 0xF0
0000777bb65e17e2  pop r11
0000777bb65e17e4  pop r10
0000777bb65e17e6  pop r9
0000777bb65e17e8  pop r8
0000777bb65e17ea  pop rsi
0000777bb65e17eb  pop rdi
0000777bb65e17ec  pop rdx
0000777bb65e17ed  pop rcx
0000777bb65e17ee  pop rax
0000777bb65e17ef  add rsp, 0x08
0000777bb65e17f3  jmp 0x0000777BB65DC820
0000777bb65e17f8  sub rsp, 0x08
0000777bb65e17fc  push rax
0000777bb65e17fd  push rcx
0000777bb65e17fe  push rdx
0000777bb65e17ff  push rdi
0000777bb65e1800  push rsi
0000777bb65e1801  push r8
0000777bb65e1803  push r9
0000777bb65e1805  push r10
0000777bb65e1807  push r11
0000777bb65e1809  sub rsp, 0xF0
0000777bb65e1810  vmovaps [rsp], xmm0
0000777bb65e1815  vmovaps [rsp+0x10], xmm1
0000777bb65e181b  vmovaps [rsp+0x20], xmm2
0000777bb65e1821  vmovaps [rsp+0x30], xmm3
0000777bb65e1827  vmovaps [rsp+0x40], xmm4
0000777bb65e182d  vmovaps [rsp+0x50], xmm5
0000777bb65e1833  vmovaps [rsp+0x60], xmm6
0000777bb65e1839  vmovaps [rsp+0x70], xmm7
0000777bb65e183f  vmovaps [rsp+0x80], xmm8
0000777bb65e1848  vmovaps [rsp+0x90], xmm9
0000777bb65e1851  vmovaps [rsp+0xA0], xmm10
0000777bb65e185a  vmovaps [rsp+0xB0], xmm11
0000777bb65e1863  vmovaps [rsp+0xC0], xmm12
0000777bb65e186c  vmovaps [rsp+0xD0], xmm13
0000777bb65e1875  vmovaps [rsp+0xE0], xmm15
0000777bb65e187e  sub rsp, 0x30
0000777bb65e1882  movaps [rsp], xmm14
0000777bb65e1887  movaps [rsp+0x10], xmm1
0000777bb65e188c  movaps [rsp+0x20], xmm7
0000777bb65e1891  lea rdi, [rsp]
0000777bb65e1895  mov esi, 0x00
0000777bb65e189a  mov rax, 0x569DC437B530
0000777bb65e18a4  call rax
0000777bb65e18a6  movaps xmm14, [rsp]
0000777bb65e18ab  add rsp, 0x30
0000777bb65e18af  vmovaps xmm0, [rsp]
0000777bb65e18b4  vmovaps xmm1, [rsp+0x10]
0000777bb65e18ba  vmovaps xmm2, [rsp+0x20]
0000777bb65e18c0  vmovaps xmm3, [rsp+0x30]
0000777bb65e18c6  vmovaps xmm4, [rsp+0x40]
0000777bb65e18cc  vmovaps xmm5, [rsp+0x50]
0000777bb65e18d2  vmovaps xmm6, [rsp+0x60]
0000777bb65e18d8  vmovaps xmm7, [rsp+0x70]
0000777bb65e18de  vmovaps xmm8, [rsp+0x80]
0000777bb65e18e7  vmovaps xmm9, [rsp+0x90]
0000777bb65e18f0  vmovaps xmm10, [rsp+0xA0]
0000777bb65e18f9  vmovaps xmm11, [rsp+0xB0]
0000777bb65e1902  vmovaps xmm12, [rsp+0xC0]
0000777bb65e190b  vmovaps xmm13, [rsp+0xD0]
0000777bb65e1914  vmovaps xmm15, [rsp+0xE0]
0000777bb65e191d  add rsp, 0xF0
0000777bb65e1924  pop r11
0000777bb65e1926  pop r10
0000777bb65e1928  pop r9
0000777bb65e192a  pop r8
0000777bb65e192c  pop rsi
0000777bb65e192d  pop rdi
0000777bb65e192e  pop rdx
0000777bb65e192f  pop rcx
0000777bb65e1930  pop rax
0000777bb65e1931  add rsp, 0x08
0000777bb65e1935  jmp 0x0000777BB65DC843
0000777bb65e193a  sub rsp, 0x08
0000777bb65e193e  push rax
0000777bb65e193f  push rcx
0000777bb65e1940  push rdx
0000777bb65e1941  push rdi
0000777bb65e1942  push rsi
0000777bb65e1943  push r8
0000777bb65e1945  push r9
0000777bb65e1947  push r10
0000777bb65e1949  push r11
0000777bb65e194b  sub rsp, 0xF0
0000777bb65e1952  vmovaps [rsp], xmm0
0000777bb65e1957  vmovaps [rsp+0x10], xmm2
0000777bb65e195d  vmovaps [rsp+0x20], xmm3
0000777bb65e1963  vmovaps [rsp+0x30], xmm4
0000777bb65e1969  vmovaps [rsp+0x40], xmm5
0000777bb65e196f  vmovaps [rsp+0x50], xmm6
0000777bb65e1975  vmovaps [rsp+0x60], xmm7
0000777bb65e197b  vmovaps [rsp+0x70], xmm8
0000777bb65e1981  vmovaps [rsp+0x80], xmm9
0000777bb65e198a  vmovaps [rsp+0x90], xmm10
0000777bb65e1993  vmovaps [rsp+0xA0], xmm11
0000777bb65e199c  vmovaps [rsp+0xB0], xmm12
0000777bb65e19a5  vmovaps [rsp+0xC0], xmm13
0000777bb65e19ae  vmovaps [rsp+0xD0], xmm14
0000777bb65e19b7  vmovaps [rsp+0xE0], xmm15
0000777bb65e19c0  sub rsp, 0x30
0000777bb65e19c4  movaps [rsp], xmm1
0000777bb65e19c8  movaps [rsp+0x10], xmm8
0000777bb65e19ce  movaps [rsp+0x20], xmm9
0000777bb65e19d4  lea rdi, [rsp]
0000777bb65e19d8  mov esi, 0x00
0000777bb65e19dd  mov rax, 0x569DC437B530
0000777bb65e19e7  call rax
0000777bb65e19e9  movaps xmm1, [rsp]
0000777bb65e19ed  add rsp, 0x30
0000777bb65e19f1  vmovaps xmm0, [rsp]
0000777bb65e19f6  vmovaps xmm2, [rsp+0x10]
0000777bb65e19fc  vmovaps xmm3, [rsp+0x20]
0000777bb65e1a02  vmovaps xmm4, [rsp+0x30]
0000777bb65e1a08  vmovaps xmm5, [rsp+0x40]
0000777bb65e1a0e  vmovaps xmm6, [rsp+0x50]
0000777bb65e1a14  vmovaps xmm7, [rsp+0x60]
0000777bb65e1a1a  vmovaps xmm8, [rsp+0x70]
0000777bb65e1a20  vmovaps xmm9, [rsp+0x80]
0000777bb65e1a29  vmovaps xmm10, [rsp+0x90]
0000777bb65e1a32  vmovaps xmm11, [rsp+0xA0]
0000777bb65e1a3b  vmovaps xmm12, [rsp+0xB0]
0000777bb65e1a44  vmovaps xmm13, [rsp+0xC0]
0000777bb65e1a4d  vmovaps xmm14, [rsp+0xD0]
0000777bb65e1a56  vmovaps xmm15, [rsp+0xE0]
0000777bb65e1a5f  add rsp, 0xF0
0000777bb65e1a66  pop r11
0000777bb65e1a68  pop r10
0000777bb65e1a6a  pop r9
0000777bb65e1a6c  pop r8
0000777bb65e1a6e  pop rsi
0000777bb65e1a6f  pop rdi
0000777bb65e1a70  pop rdx
0000777bb65e1a71  pop rcx
0000777bb65e1a72  pop rax
0000777bb65e1a73  add rsp, 0x08
0000777bb65e1a77  jmp 0x0000777BB65DC865
0000777bb65e1a7c  call 0x0000777BB64E5940
0000777bb65e1a81  jmp 0x0000777BB65DC873
0000777bb65e1a86  call 0x0000777BB640C380
0000777bb65e1a8b  jmp 0x0000777BB65DC87D
0000777bb65e1a90  call 0x0000777BB640D600
0000777bb65e1a95  jmp 0x0000777BB65DC887
0000777bb65e1a9a  call 0x0000777BB63FF540
0000777bb65e1a9f  jmp 0x0000777BB65DC891
0000777bb65e1aa4  int3
0000777bb65e1aa5  nop [rax+rax*1], ax
0000777bb65e1aae  nop
0000777bb65e1ab0  mov rax, [r15+0xF8]
0000777bb65e1ab7  lea r14, [rax+0x140]
0000777bb65e1abe  mov r12, [r13+r14*1]
0000777bb65e1ac3  mov [r15+0xE8], r12
0000777bb65e1aca  lea r14, [rax+0x130]
0000777bb65e1ad1  mov r12, [r13+r14*1]
0000777bb65e1ad6  lea r14, [rax+0x138]
0000777bb65e1add  mov r11, [r13+r14*1]
0000777bb65e1ae2  movq xmm1, r12
0000777bb65e1ae7  movq xmm15, r11
0000777bb65e1aec  movq xmm1, xmm1
0000777bb65e1af0  movq xmm1, xmm1
0000777bb65e1af4  movaps [r15+0x1A0], xmm1
0000777bb65e1afc  movq xmm15, xmm15
0000777bb65e1b01  movq xmm15, xmm15
0000777bb65e1b06  movaps [r15+0x190], xmm15
0000777bb65e1b0e  lea r14, [rax+0x120]
0000777bb65e1b15  mov r12, [r13+r14*1]
0000777bb65e1b1a  lea r14, [rax+0x128]
0000777bb65e1b21  mov r11, [r13+r14*1]
0000777bb65e1b26  movq xmm1, r12
0000777bb65e1b2b  movq xmm15, r11
0000777bb65e1b30  movq xmm1, xmm1
0000777bb65e1b34  movq xmm1, xmm1
0000777bb65e1b38  movaps [r15+0x1C0], xmm1
0000777bb65e1b40  movq xmm15, xmm15
0000777bb65e1b45  movq xmm15, xmm15
0000777bb65e1b4a  movaps [r15+0x1B0], xmm15
0000777bb65e1b52  lea r14, [rax+0x110]
0000777bb65e1b59  mov r12, [r13+r14*1]
0000777bb65e1b5e  lea r14, [rax+0x118]
0000777bb65e1b65  mov r11, [r13+r14*1]
0000777bb65e1b6a  movq xmm1, r12
0000777bb65e1b6f  movq xmm15, r11
0000777bb65e1b74  movq xmm1, xmm1
0000777bb65e1b78  movq xmm1, xmm1
0000777bb65e1b7c  movaps [r15+0x1E0], xmm1
0000777bb65e1b84  movq xmm15, xmm15
0000777bb65e1b89  movq xmm15, xmm15
0000777bb65e1b8e  movaps [r15+0x1D0], xmm15
0000777bb65e1b96  lea r14, [rax+0x100]
0000777bb65e1b9d  mov r12, [r13+r14*1]
0000777bb65e1ba2  lea r14, [rax+0x108]
0000777bb65e1ba9  mov r11, [r13+r14*1]
0000777bb65e1bae  movq xmm1, r12
0000777bb65e1bb3  movq xmm15, r11
0000777bb65e1bb8  movq xmm1, xmm1
0000777bb65e1bbc  movq xmm1, xmm1
0000777bb65e1bc0  movaps [r15+0x200], xmm1
0000777bb65e1bc8  movq xmm15, xmm15
0000777bb65e1bcd  movq xmm15, xmm15
0000777bb65e1bd2  movaps [r15+0x1F0], xmm15
0000777bb65e1bda  mov qword ptr [r15+0x40], 0x430000
0000777bb65e1be2  mov r14d, 0x430510
0000777bb65e1be8  mov r12, [r13+r14*1]
0000777bb65e1bed  movq xmm1, r12
0000777bb65e1bf2  lea r14, [rax+0x150]
0000777bb65e1bf9  mov [r15+0xF8], r14
0000777bb65e1c00  mov rax, [r15+0x50]
0000777bb65e1c04  movups xmm15, [r13+rax*1]
0000777bb65e1c0a  movaps [r15+0x120], xmm15
0000777bb65e1c12  mov qword ptr [r15+0x48], 0x10
0000777bb65e1c1a  xor eax, eax
0000777bb65e1c1c  mov r14d, 0x10
0000777bb65e1c22  mov r12d, 0x200
0000777bb65e1c28  cmp r14, r12
0000777bb65e1c2b  cmc
0000777bb65e1c2c  lahf
0000777bb65e1c2d  seto al
0000777bb65e1c30  mov [r15+0x108], eax
0000777bb65e1c37  pextrq rax, xmm15, 0x01
0000777bb65e1c3e  movq xmm14, rax
0000777bb65e1c43  movaps [r15+0x130], xmm14
0000777bb65e1c4b  movq rax, xmm1
0000777bb65e1c50  movq r14, xmm15
0000777bb65e1c55  vmovq xmm1, rax
0000777bb65e1c5a  vmovq xmm15, r14
0000777bb65e1c5f  movaps xmm13, xmm1
0000777bb65e1c63  addsd xmm13, xmm15
0000777bb65e1c68  ucomisd xmm13, xmm13
0000777bb65e1c6d  jp 0x0000777BB65E1D86
0000777bb65e1c73  movq xmm13, xmm13
0000777bb65e1c78  movq rax, xmm13
0000777bb65e1c7d  movq r14, xmm14
0000777bb65e1c82  vmovq xmm1, rax
0000777bb65e1c87  vmovq xmm15, r14
0000777bb65e1c8c  movaps xmm14, xmm1
0000777bb65e1c90  addsd xmm14, xmm15
0000777bb65e1c95  ucomisd xmm14, xmm14
0000777bb65e1c9a  jp 0x0000777BB65E1DCE
0000777bb65e1ca0  movq xmm14, xmm14
0000777bb65e1ca5  movaps [r15+0x110], xmm14
0000777bb65e1cad  mov eax, [r15+0x108]
0000777bb65e1cb4  sahf
0000777bb65e1cb5  jnz 0x0000777BB65E1CE7
0000777bb65e1cb7  cmp dword ptr [r15+0x318], 0x00
0000777bb65e1cbf  jz 0x0000777BB65E1FE0
0000777bb65e1cc5  nop [rax+rax*1], ax
0000777bb65e1cce  nop [rax+rax*1], eax
0000777bb65e1cd6  mov eax, 0x410490
0000777bb65e1cdb  mov [r15+0x100], rax
0000777bb65e1ce2  jmp 0x0000777BB63FE110
0000777bb65e1ce7  cmp dword ptr [r15+0x318], 0x00
0000777bb65e1cef  jz 0x0000777BB65E1E20
0000777bb65e1cf5  nop [rax+rax*1], ax
0000777bb65e1cfe  nop [rax+rax*1], eax
0000777bb65e1d06  mov eax, 0x410474
0000777bb65e1d0b  mov [r15+0x100], rax
0000777bb65e1d12  jmp 0x0000777BB63FE110
0000777bb65e1d17  int3
0000777bb65e1d18  call 0x0000777BB64E27E0
0000777bb65e1d1d  jmp 0x0000777BB65E1AC3
0000777bb65e1d22  call 0x0000777BB64E27E0
0000777bb65e1d27  jmp 0x0000777BB65E1AD6
0000777bb65e1d2c  call 0x0000777BB64E1570
0000777bb65e1d31  jmp 0x0000777BB65E1AE2
0000777bb65e1d36  call 0x0000777BB64E27E0
0000777bb65e1d3b  jmp 0x0000777BB65E1B1A
0000777bb65e1d40  call 0x0000777BB64E1570
0000777bb65e1d45  jmp 0x0000777BB65E1B26
0000777bb65e1d4a  call 0x0000777BB64E27E0
0000777bb65e1d4f  jmp 0x0000777BB65E1B5E
0000777bb65e1d54  call 0x0000777BB64E1570
0000777bb65e1d59  jmp 0x0000777BB65E1B6A
0000777bb65e1d5e  call 0x0000777BB64E27E0
0000777bb65e1d63  jmp 0x0000777BB65E1BA2
0000777bb65e1d68  call 0x0000777BB64E1570
0000777bb65e1d6d  jmp 0x0000777BB65E1BAE
0000777bb65e1d72  call 0x0000777BB64E27E0
0000777bb65e1d77  jmp 0x0000777BB65E1BED
0000777bb65e1d7c  call 0x0000777BB640E760
0000777bb65e1d81  jmp 0x0000777BB65E1C0A
0000777bb65e1d86  ucomisd xmm1, xmm15
0000777bb65e1d8b  jp 0x0000777BB65E1D9A
0000777bb65e1d8d  movaps xmm13, [0x0000777BB61FE060]
0000777bb65e1d95  jmp 0x0000777BB65E1C73
0000777bb65e1d9a  vxorps xmm0, xmm1, xmm15
0000777bb65e1d9f  pextrw eax, xmm0, 0x03
0000777bb65e1da4  and eax, 0x7FF8
0000777bb65e1da9  cmp eax, 0x08
0000777bb65e1dac  jnz 0x0000777BB65E1C73
0000777bb65e1db2  movq rax, xmm15
0000777bb65e1db7  shl rax, 0x0D
0000777bb65e1dbb  jbe 0x0000777BB65E1C73
0000777bb65e1dc1  vorps xmm13, xmm15, [0x0000777BB61FE070]
0000777bb65e1dc9  jmp 0x0000777BB65E1C73
0000777bb65e1dce  ucomisd xmm1, xmm15
0000777bb65e1dd3  jp 0x0000777BB65E1DE2
0000777bb65e1dd5  movaps xmm14, [0x0000777BB61FE060]
0000777bb65e1ddd  jmp 0x0000777BB65E1CA0
0000777bb65e1de2  vxorps xmm0, xmm1, xmm15
0000777bb65e1de7  pextrw eax, xmm0, 0x03
0000777bb65e1dec  and eax, 0x7FF8
0000777bb65e1df1  cmp eax, 0x08
0000777bb65e1df4  jnz 0x0000777BB65E1CA0
0000777bb65e1dfa  movq rax, xmm15
0000777bb65e1dff  shl rax, 0x0D
0000777bb65e1e03  jbe 0x0000777BB65E1CA0
0000777bb65e1e09  vorps xmm14, xmm15, [0x0000777BB61FE070]
0000777bb65e1e11  jmp 0x0000777BB65E1CA0
0000777bb65e1e16  int3
0000777bb65e1e17  nop [rax+rax*1], ax
0000777bb65e1e20  mov rax, [r15+0x48]
0000777bb65e1e24  mov r14, [r15+0x50]
0000777bb65e1e28  lea r12, [r14+rax*1]
0000777bb65e1e2c  movups xmm1, [r13+r12*1]
0000777bb65e1e32  movaps [r15+0x120], xmm1
0000777bb65e1e3a  lea r14, [rax+0x10]
0000777bb65e1e3e  mov [r15+0x48], r14
0000777bb65e1e42  xor eax, eax
0000777bb65e1e44  mov r12d, 0x200
0000777bb65e1e4a  cmp r14, r12
0000777bb65e1e4d  cmc
0000777bb65e1e4e  lahf
0000777bb65e1e4f  seto al
0000777bb65e1e52  mov [r15+0x108], eax
0000777bb65e1e59  pextrq rax, xmm1, 0x01
0000777bb65e1e60  movq xmm15, rax
0000777bb65e1e65  movaps [r15+0x130], xmm15
0000777bb65e1e6d  movaps xmm14, [r15+0x110]
0000777bb65e1e75  movq rax, xmm14
0000777bb65e1e7a  movq r14, xmm1
0000777bb65e1e7f  vmovq xmm1, rax
0000777bb65e1e84  vmovq xmm14, r14
0000777bb65e1e89  movaps xmm13, xmm1
0000777bb65e1e8d  addsd xmm13, xmm14
0000777bb65e1e92  ucomisd xmm13, xmm13
0000777bb65e1e97  jp 0x0000777BB65E1F4C
0000777bb65e1e9d  movq xmm13, xmm13
0000777bb65e1ea2  movq rax, xmm13
0000777bb65e1ea7  movq r14, xmm15
0000777bb65e1eac  vmovq xmm1, rax
0000777bb65e1eb1  vmovq xmm15, r14
0000777bb65e1eb6  movaps xmm14, xmm1
0000777bb65e1eba  addsd xmm14, xmm15
0000777bb65e1ebf  ucomisd xmm14, xmm14
0000777bb65e1ec4  jp 0x0000777BB65E1F94
0000777bb65e1eca  movq xmm14, xmm14
0000777bb65e1ecf  movaps [r15+0x110], xmm14
0000777bb65e1ed7  mov eax, [r15+0x108]
0000777bb65e1ede  sahf
0000777bb65e1edf  jnz 0x0000777BB65E1F11
0000777bb65e1ee1  cmp dword ptr [r15+0x318], 0x00
0000777bb65e1ee9  jz 0x0000777BB65E1FE0
0000777bb65e1eef  nop [rax+rax*1], ax
0000777bb65e1ef8  nop [rax+rax*1], eax
0000777bb65e1f00  mov eax, 0x410490
0000777bb65e1f05  mov [r15+0x100], rax
0000777bb65e1f0c  jmp 0x0000777BB63FE110
0000777bb65e1f11  cmp dword ptr [r15+0x318], 0x00
0000777bb65e1f19  jz 0x0000777BB65E1E20
0000777bb65e1f1f  nop [rax+rax*1], ax
0000777bb65e1f28  nop [rax+rax*1], eax
0000777bb65e1f30  mov eax, 0x410474
0000777bb65e1f35  mov [r15+0x100], rax
0000777bb65e1f3c  jmp 0x0000777BB63FE110
0000777bb65e1f41  int3
0000777bb65e1f42  call 0x0000777BB64B52F0
0000777bb65e1f47  jmp 0x0000777BB65E1E32
0000777bb65e1f4c  ucomisd xmm1, xmm14
0000777bb65e1f51  jp 0x0000777BB65E1F60
0000777bb65e1f53  movaps xmm13, [0x0000777BB61FE060]
0000777bb65e1f5b  jmp 0x0000777BB65E1E9D
0000777bb65e1f60  vxorps xmm0, xmm1, xmm14
0000777bb65e1f65  pextrw eax, xmm0, 0x03
0000777bb65e1f6a  and eax, 0x7FF8
0000777bb65e1f6f  cmp eax, 0x08
0000777bb65e1f72  jnz 0x0000777BB65E1E9D
0000777bb65e1f78  movq rax, xmm14
0000777bb65e1f7d  shl rax, 0x0D
0000777bb65e1f81  jbe 0x0000777BB65E1E9D
0000777bb65e1f87  vorps xmm13, xmm14, [0x0000777BB61FE070]
0000777bb65e1f8f  jmp 0x0000777BB65E1E9D
0000777bb65e1f94  ucomisd xmm1, xmm15
0000777bb65e1f99  jp 0x0000777BB65E1FA8
0000777bb65e1f9b  movaps xmm14, [0x0000777BB61FE060]
0000777bb65e1fa3  jmp 0x0000777BB65E1ECA
0000777bb65e1fa8  vxorps xmm0, xmm1, xmm15
0000777bb65e1fad  pextrw eax, xmm0, 0x03
0000777bb65e1fb2  and eax, 0x7FF8
0000777bb65e1fb7  cmp eax, 0x08
0000777bb65e1fba  jnz 0x0000777BB65E1ECA
0000777bb65e1fc0  movq rax, xmm15
0000777bb65e1fc5  shl rax, 0x0D
0000777bb65e1fc9  jbe 0x0000777BB65E1ECA
0000777bb65e1fcf  vorps xmm14, xmm15, [0x0000777BB61FE070]
0000777bb65e1fd7  jmp 0x0000777BB65E1ECA
0000777bb65e1fdc  int3
0000777bb65e1fdd  nop [rax], eax
0000777bb65e1fe0  mov rax, [r15+0x40]
0000777bb65e1fe4  lea r14, [rax+0x510]
0000777bb65e1feb  movaps xmm1, [r15+0x110]
0000777bb65e1ff3  movq rax, xmm1
0000777bb65e1ff8  mov [r13+r14*1], rax
0000777bb65e1ffd  mov rax, [r15+0xF0]
0000777bb65e2004  mov [r15+0x100], rax
0000777bb65e200b  jmp 0x0000777BB65CE5C0
0000777bb65e2010  int3
0000777bb65e2011  call 0x0000777BB64D5EB0
0000777bb65e2016  jmp 0x0000777BB65E1FFD
0000777bb65e201b  int3
0000777bb65e201c  nop [rax], eax
0000777bb65e2020  mov qword ptr [r15+0x100], 0x04
0000777bb65e202b  mov esi, 0x00
0000777bb65e2030  mov edx, 0x09
0000777bb65e2035  mov rdi, 0x7FFF48330580
0000777bb65e203f  mov rax, 0x569DC420E970
0000777bb65e2049  call rax
0000777bb65e204b  cmp dword ptr [r15+0x318], 0x00
0000777bb65e2053  jnz 0x0000777BB63FE110
0000777bb65e2059  jmp 0x0000777BB63FE0A0
0000777bb65e205e  int3
0000777bb65e205f  int3
