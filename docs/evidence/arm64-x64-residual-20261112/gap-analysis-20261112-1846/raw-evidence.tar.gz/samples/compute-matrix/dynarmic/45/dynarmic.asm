00007b78f51ce69b  nop [rax+rax*1], eax
00007b78f51ce6a0  vmovaps xmm1, [0x00007B78F4DFE010]
00007b78f51ce6a8  movq xmm1, xmm1
00007b78f51ce6ac  movaps [r15+0x110], xmm1
00007b78f51ce6b4  vmovaps xmm1, [0x00007B78F4DFE020]
00007b78f51ce6bc  movq xmm1, xmm1
00007b78f51ce6c0  movaps [r15+0x120], xmm1
00007b78f51ce6c8  mov eax, 0x4204C0
00007b78f51ce6cd  mov r14, [r13+rax*1]
00007b78f51ce6d2  movq xmm1, r14
00007b78f51ce6d7  movaps [r15+0x130], xmm1
00007b78f51ce6df  vmovaps xmm1, [0x00007B78F4DFE030]
00007b78f51ce6e7  vpbroadcastq xmm1, xmm1
00007b78f51ce6ec  movaps [r15+0x140], xmm1
00007b78f51ce6f4  mov qword ptr [r15+0x40], 0x02
00007b78f51ce6fc  vmovaps xmm15, [0x00007B78F4DFE040]
00007b78f51ce704  movq xmm15, xmm15
00007b78f51ce709  movaps [r15+0x150], xmm15
00007b78f51ce711  mov qword ptr [r15+0x58], 0x420000
00007b78f51ce719  vmovaps xmm15, [0x00007B78F4DFE050]
00007b78f51ce721  vpbroadcastq xmm15, xmm15
00007b78f51ce726  movaps [r15+0x160], xmm15
00007b78f51ce72e  mov rax, [r15+0x40]
00007b78f51ce732  vmovq xmm14, rax
00007b78f51ce737  vpbroadcastq xmm14, xmm14
00007b78f51ce73c  movaps [r15+0x170], xmm14
00007b78f51ce744  mov eax, 0x4204D0
00007b78f51ce749  movups xmm13, [r13+rax*1]
00007b78f51ce74f  mov qword ptr [r15+0x40], 0x430518
00007b78f51ce757  mov qword ptr [r15+0x50], 0x430720
00007b78f51ce75f  vpmovqd xmm12, xmm13
00007b78f51ce765  pxor xmm11, xmm11
00007b78f51ce76a  punpcklqdq xmm12, xmm11
00007b78f51ce76f  movaps [r15+0x210], xmm12
00007b78f51ce777  movq xmm12, qword ptr [r15+0x120]
00007b78f51ce780  movq xmm11, qword ptr [r15+0x130]
00007b78f51ce789  psubd xmm12, xmm11
00007b78f51ce78e  movq xmm12, xmm12
00007b78f51ce793  paddq xmm13, xmm14
00007b78f51ce798  movaps [r15+0x180], xmm13
00007b78f51ce7a0  movq xmm14, qword ptr [r15+0x150]
00007b78f51ce7a9  paddd xmm11, xmm14
00007b78f51ce7ae  movq xmm11, xmm11
00007b78f51ce7b3  movq xmm11, xmm11
00007b78f51ce7b8  movaps [r15+0x130], xmm11
00007b78f51ce7c0  pmovzxdq xmm12, xmm12
00007b78f51ce7c6  psllq xmm12, 0x00
00007b78f51ce7cc  movq xmm14, qword ptr [r15+0x210]
00007b78f51ce7d5  movq xmm13, qword ptr [r15+0x110]
00007b78f51ce7de  paddd xmm14, xmm13
00007b78f51ce7e3  movq xmm14, xmm14
00007b78f51ce7e8  vcvtuqq2pd xmm12, xmm12
00007b78f51ce7ee  pmovzxdq xmm14, xmm14
00007b78f51ce7f4  psllq xmm14, 0x00
00007b78f51ce7fa  vcvtuqq2pd xmm14, xmm14
00007b78f51ce800  movaps xmm13, xmm12
00007b78f51ce804  mulpd xmm13, xmm1
00007b78f51ce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007b78f51ce80f  ptest xmm11, xmm11
00007b78f51ce815  jnz 0x00007B78F51CE8FF
00007b78f51ce81b  movaps [r15+0x220], xmm13
00007b78f51ce823  mov eax, 0x430720
00007b78f51ce828  movups [r13+rax*1], xmm13
00007b78f51ce82e  movaps xmm1, xmm14
00007b78f51ce832  mulpd xmm1, xmm15
00007b78f51ce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007b78f51ce83c  ptest xmm13, xmm13
00007b78f51ce842  jnz 0x00007B78F51CEA4C
00007b78f51ce848  movaps [r15+0x210], xmm1
00007b78f51ce850  mov eax, 0x430518
00007b78f51ce855  movups [r13+rax*1], xmm1
00007b78f51ce85b  mov qword ptr [r15+0x48], 0x10
00007b78f51ce863  xor eax, eax
00007b78f51ce865  mov r14d, 0x10
00007b78f51ce86b  mov r12d, 0x200
00007b78f51ce871  cmp r14, r12
00007b78f51ce874  cmc
00007b78f51ce875  lahf
00007b78f51ce876  seto al
00007b78f51ce879  mov [r15+0x108], eax
00007b78f51ce880  mov eax, [r15+0x108]
00007b78f51ce887  sahf
00007b78f51ce888  jnz 0x00007B78F51CE8BA
00007b78f51ce88a  cmp dword ptr [r15+0x318], 0x00
00007b78f51ce892  jz 0x00007B78F51CEFF0
00007b78f51ce898  nop [rax+rax*1], ax
00007b78f51ce8a1  nop [rax+rax*1], eax
00007b78f51ce8a9  mov eax, 0x4101EC
00007b78f51ce8ae  mov [r15+0x100], rax
00007b78f51ce8b5  jmp 0x00007B78F4FFE110
00007b78f51ce8ba  cmp dword ptr [r15+0x318], 0x00
00007b78f51ce8c2  jz 0x00007B78F51CEBA0
00007b78f51ce8c8  nop [rax+rax*1], ax
00007b78f51ce8d1  nop [rax+rax*1], eax
00007b78f51ce8d9  mov eax, 0x4101AC
00007b78f51ce8de  mov [r15+0x100], rax
00007b78f51ce8e5  jmp 0x00007B78F4FFE110
00007b78f51ce8ea  int3
00007b78f51ce8eb  call 0x00007B78F500DC20
00007b78f51ce8f0  jmp 0x00007B78F51CE6D2
00007b78f51ce8f5  call 0x00007B78F500C260
00007b78f51ce8fa  jmp 0x00007B78F51CE74F
00007b78f51ce8ff  sub rsp, 0x08
00007b78f51ce903  push rax
00007b78f51ce904  push rcx
00007b78f51ce905  push rdx
00007b78f51ce906  push rdi
00007b78f51ce907  push rsi
00007b78f51ce908  push r8
00007b78f51ce90a  push r9
00007b78f51ce90c  push r10
00007b78f51ce90e  push r11
00007b78f51ce910  sub rsp, 0xF0
00007b78f51ce917  vmovaps [rsp], xmm0
00007b78f51ce91c  vmovaps [rsp+0x10], xmm1
00007b78f51ce922  vmovaps [rsp+0x20], xmm2
00007b78f51ce928  vmovaps [rsp+0x30], xmm3
00007b78f51ce92e  vmovaps [rsp+0x40], xmm4
00007b78f51ce934  vmovaps [rsp+0x50], xmm5
00007b78f51ce93a  vmovaps [rsp+0x60], xmm6
00007b78f51ce940  vmovaps [rsp+0x70], xmm7
00007b78f51ce946  vmovaps [rsp+0x80], xmm8
00007b78f51ce94f  vmovaps [rsp+0x90], xmm9
00007b78f51ce958  vmovaps [rsp+0xA0], xmm10
00007b78f51ce961  vmovaps [rsp+0xB0], xmm11
00007b78f51ce96a  vmovaps [rsp+0xC0], xmm12
00007b78f51ce973  vmovaps [rsp+0xD0], xmm14
00007b78f51ce97c  vmovaps [rsp+0xE0], xmm15
00007b78f51ce985  sub rsp, 0x30
00007b78f51ce989  movaps [rsp], xmm13
00007b78f51ce98e  movaps [rsp+0x10], xmm12
00007b78f51ce994  movaps [rsp+0x20], xmm1
00007b78f51ce999  lea rdi, [rsp]
00007b78f51ce99d  mov esi, 0x00
00007b78f51ce9a2  mov rax, 0x597478C09530
00007b78f51ce9ac  call rax
00007b78f51ce9ae  movaps xmm13, [rsp]
00007b78f51ce9b3  add rsp, 0x30
00007b78f51ce9b7  vmovaps xmm0, [rsp]
00007b78f51ce9bc  vmovaps xmm1, [rsp+0x10]
00007b78f51ce9c2  vmovaps xmm2, [rsp+0x20]
00007b78f51ce9c8  vmovaps xmm3, [rsp+0x30]
00007b78f51ce9ce  vmovaps xmm4, [rsp+0x40]
00007b78f51ce9d4  vmovaps xmm5, [rsp+0x50]
00007b78f51ce9da  vmovaps xmm6, [rsp+0x60]
00007b78f51ce9e0  vmovaps xmm7, [rsp+0x70]
00007b78f51ce9e6  vmovaps xmm8, [rsp+0x80]
00007b78f51ce9ef  vmovaps xmm9, [rsp+0x90]
00007b78f51ce9f8  vmovaps xmm10, [rsp+0xA0]
00007b78f51cea01  vmovaps xmm11, [rsp+0xB0]
00007b78f51cea0a  vmovaps xmm12, [rsp+0xC0]
00007b78f51cea13  vmovaps xmm14, [rsp+0xD0]
00007b78f51cea1c  vmovaps xmm15, [rsp+0xE0]
00007b78f51cea25  add rsp, 0xF0
00007b78f51cea2c  pop r11
00007b78f51cea2e  pop r10
00007b78f51cea30  pop r9
00007b78f51cea32  pop r8
00007b78f51cea34  pop rsi
00007b78f51cea35  pop rdi
00007b78f51cea36  pop rdx
00007b78f51cea37  pop rcx
00007b78f51cea38  pop rax
00007b78f51cea39  add rsp, 0x08
00007b78f51cea3d  jmp 0x00007B78F51CE81B
00007b78f51cea42  call 0x00007B78F500C380
00007b78f51cea47  jmp 0x00007B78F51CE82E
00007b78f51cea4c  sub rsp, 0x08
00007b78f51cea50  push rax
00007b78f51cea51  push rcx
00007b78f51cea52  push rdx
00007b78f51cea53  push rdi
00007b78f51cea54  push rsi
00007b78f51cea55  push r8
00007b78f51cea57  push r9
00007b78f51cea59  push r10
00007b78f51cea5b  push r11
00007b78f51cea5d  sub rsp, 0xF0
00007b78f51cea64  vmovaps [rsp], xmm0
00007b78f51cea69  vmovaps [rsp+0x10], xmm2
00007b78f51cea6f  vmovaps [rsp+0x20], xmm3
00007b78f51cea75  vmovaps [rsp+0x30], xmm4
00007b78f51cea7b  vmovaps [rsp+0x40], xmm5
00007b78f51cea81  vmovaps [rsp+0x50], xmm6
00007b78f51cea87  vmovaps [rsp+0x60], xmm7
00007b78f51cea8d  vmovaps [rsp+0x70], xmm8
00007b78f51cea93  vmovaps [rsp+0x80], xmm9
00007b78f51cea9c  vmovaps [rsp+0x90], xmm10
00007b78f51ceaa5  vmovaps [rsp+0xA0], xmm11
00007b78f51ceaae  vmovaps [rsp+0xB0], xmm12
00007b78f51ceab7  vmovaps [rsp+0xC0], xmm13
00007b78f51ceac0  vmovaps [rsp+0xD0], xmm14
00007b78f51ceac9  vmovaps [rsp+0xE0], xmm15
00007b78f51cead2  sub rsp, 0x30
00007b78f51cead6  movaps [rsp], xmm1
00007b78f51ceada  movaps [rsp+0x10], xmm14
00007b78f51ceae0  movaps [rsp+0x20], xmm15
00007b78f51ceae6  lea rdi, [rsp]
00007b78f51ceaea  mov esi, 0x00
00007b78f51ceaef  mov rax, 0x597478C09530
00007b78f51ceaf9  call rax
00007b78f51ceafb  movaps xmm1, [rsp]
00007b78f51ceaff  add rsp, 0x30
00007b78f51ceb03  vmovaps xmm0, [rsp]
00007b78f51ceb08  vmovaps xmm2, [rsp+0x10]
00007b78f51ceb0e  vmovaps xmm3, [rsp+0x20]
00007b78f51ceb14  vmovaps xmm4, [rsp+0x30]
00007b78f51ceb1a  vmovaps xmm5, [rsp+0x40]
00007b78f51ceb20  vmovaps xmm6, [rsp+0x50]
00007b78f51ceb26  vmovaps xmm7, [rsp+0x60]
00007b78f51ceb2c  vmovaps xmm8, [rsp+0x70]
00007b78f51ceb32  vmovaps xmm9, [rsp+0x80]
00007b78f51ceb3b  vmovaps xmm10, [rsp+0x90]
00007b78f51ceb44  vmovaps xmm11, [rsp+0xA0]
00007b78f51ceb4d  vmovaps xmm12, [rsp+0xB0]
00007b78f51ceb56  vmovaps xmm13, [rsp+0xC0]
00007b78f51ceb5f  vmovaps xmm14, [rsp+0xD0]
00007b78f51ceb68  vmovaps xmm15, [rsp+0xE0]
00007b78f51ceb71  add rsp, 0xF0
00007b78f51ceb78  pop r11
00007b78f51ceb7a  pop r10
00007b78f51ceb7c  pop r9
00007b78f51ceb7e  pop r8
00007b78f51ceb80  pop rsi
00007b78f51ceb81  pop rdi
00007b78f51ceb82  pop rdx
00007b78f51ceb83  pop rcx
00007b78f51ceb84  pop rax
00007b78f51ceb85  add rsp, 0x08
00007b78f51ceb89  jmp 0x00007B78F51CE848
00007b78f51ceb8e  call 0x00007B78F4FFF540
00007b78f51ceb93  jmp 0x00007B78F51CE85B
00007b78f51ceb98  int3
00007b78f51ceb99  nop [rax], eax
00007b78f51ceba0  movaps xmm1, [r15+0x180]
00007b78f51ceba8  vpmovqd xmm15, xmm1
00007b78f51cebae  pxor xmm14, xmm14
00007b78f51cebb3  punpcklqdq xmm15, xmm14
00007b78f51cebb8  movaps [r15+0x210], xmm15
00007b78f51cebc0  movq xmm15, qword ptr [r15+0x120]
00007b78f51cebc9  movq xmm14, qword ptr [r15+0x130]
00007b78f51cebd2  psubd xmm15, xmm14
00007b78f51cebd7  movq xmm15, xmm15
00007b78f51cebdc  movaps xmm13, [r15+0x170]
00007b78f51cebe4  paddq xmm1, xmm13
00007b78f51cebe9  movaps [r15+0x180], xmm1
00007b78f51cebf1  movq xmm1, qword ptr [r15+0x150]
00007b78f51cebfa  paddd xmm14, xmm1
00007b78f51cebff  movq xmm14, xmm14
00007b78f51cec04  movq xmm14, xmm14
00007b78f51cec09  movaps [r15+0x130], xmm14
00007b78f51cec11  pmovzxdq xmm15, xmm15
00007b78f51cec17  psllq xmm15, 0x00
00007b78f51cec1d  movq xmm1, qword ptr [r15+0x210]
00007b78f51cec26  movq xmm14, qword ptr [r15+0x110]
00007b78f51cec2f  paddd xmm1, xmm14
00007b78f51cec34  movq xmm1, xmm1
00007b78f51cec38  vcvtuqq2pd xmm15, xmm15
00007b78f51cec3e  pmovzxdq xmm1, xmm1
00007b78f51cec43  psllq xmm1, 0x00
00007b78f51cec48  vcvtuqq2pd xmm1, xmm1
00007b78f51cec4e  movaps xmm14, [r15+0x140]
00007b78f51cec56  movaps xmm13, xmm15
00007b78f51cec5a  mulpd xmm13, xmm14
00007b78f51cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007b78f51cec65  ptest xmm12, xmm12
00007b78f51cec6b  jnz 0x00007B78F51CED4E
00007b78f51cec71  movaps [r15+0x220], xmm13
00007b78f51cec79  mov rax, [r15+0x48]
00007b78f51cec7d  mov r14, [r15+0x50]
00007b78f51cec81  lea r12, [r14+rax*1]
00007b78f51cec85  movups [r13+r12*1], xmm13
00007b78f51cec8b  movaps xmm15, [r15+0x160]
00007b78f51cec93  movaps xmm14, xmm1
00007b78f51cec97  mulpd xmm14, xmm15
00007b78f51cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007b78f51ceca2  ptest xmm13, xmm13
00007b78f51ceca8  jnz 0x00007B78F51CEE9C
00007b78f51cecae  movaps [r15+0x210], xmm14
00007b78f51cecb6  mov r14, [r15+0x40]
00007b78f51cecba  lea r12, [r14+rax*1]
00007b78f51cecbe  movups [r13+r12*1], xmm14
00007b78f51cecc4  lea r14, [rax+0x10]
00007b78f51cecc8  mov [r15+0x48], r14
00007b78f51ceccc  xor eax, eax
00007b78f51cecce  mov r12d, 0x200
00007b78f51cecd4  cmp r14, r12
00007b78f51cecd7  cmc
00007b78f51cecd8  lahf
00007b78f51cecd9  seto al
00007b78f51cecdc  mov [r15+0x108], eax
00007b78f51cece3  mov eax, [r15+0x108]
00007b78f51cecea  sahf
00007b78f51ceceb  jnz 0x00007B78F51CED1D
00007b78f51ceced  cmp dword ptr [r15+0x318], 0x00
00007b78f51cecf5  jz 0x00007B78F51CEFF0
00007b78f51cecfb  nop [rax+rax*1], ax
00007b78f51ced04  nop [rax+rax*1], eax
00007b78f51ced0c  mov eax, 0x4101EC
00007b78f51ced11  mov [r15+0x100], rax
00007b78f51ced18  jmp 0x00007B78F4FFE110
00007b78f51ced1d  cmp dword ptr [r15+0x318], 0x00
00007b78f51ced25  jz 0x00007B78F51CEBA0
00007b78f51ced2b  nop [rax+rax*1], ax
00007b78f51ced34  nop [rax+rax*1], eax
00007b78f51ced3c  mov eax, 0x4101AC
00007b78f51ced41  mov [r15+0x100], rax
00007b78f51ced48  jmp 0x00007B78F4FFE110
00007b78f51ced4d  int3
00007b78f51ced4e  sub rsp, 0x08
00007b78f51ced52  push rax
00007b78f51ced53  push rcx
00007b78f51ced54  push rdx
00007b78f51ced55  push rdi
00007b78f51ced56  push rsi
00007b78f51ced57  push r8
00007b78f51ced59  push r9
00007b78f51ced5b  push r10
00007b78f51ced5d  push r11
00007b78f51ced5f  sub rsp, 0xF0
00007b78f51ced66  vmovaps [rsp], xmm0
00007b78f51ced6b  vmovaps [rsp+0x10], xmm1
00007b78f51ced71  vmovaps [rsp+0x20], xmm2
00007b78f51ced77  vmovaps [rsp+0x30], xmm3
00007b78f51ced7d  vmovaps [rsp+0x40], xmm4
00007b78f51ced83  vmovaps [rsp+0x50], xmm5
00007b78f51ced89  vmovaps [rsp+0x60], xmm6
00007b78f51ced8f  vmovaps [rsp+0x70], xmm7
00007b78f51ced95  vmovaps [rsp+0x80], xmm8
00007b78f51ced9e  vmovaps [rsp+0x90], xmm9
00007b78f51ceda7  vmovaps [rsp+0xA0], xmm10
00007b78f51cedb0  vmovaps [rsp+0xB0], xmm11
00007b78f51cedb9  vmovaps [rsp+0xC0], xmm12
00007b78f51cedc2  vmovaps [rsp+0xD0], xmm14
00007b78f51cedcb  vmovaps [rsp+0xE0], xmm15
00007b78f51cedd4  sub rsp, 0x30
00007b78f51cedd8  movaps [rsp], xmm13
00007b78f51ceddd  movaps [rsp+0x10], xmm15
00007b78f51cede3  movaps [rsp+0x20], xmm14
00007b78f51cede9  lea rdi, [rsp]
00007b78f51ceded  mov esi, 0x00
00007b78f51cedf2  mov rax, 0x597478C09530
00007b78f51cedfc  call rax
00007b78f51cedfe  movaps xmm13, [rsp]
00007b78f51cee03  add rsp, 0x30
00007b78f51cee07  vmovaps xmm0, [rsp]
00007b78f51cee0c  vmovaps xmm1, [rsp+0x10]
00007b78f51cee12  vmovaps xmm2, [rsp+0x20]
00007b78f51cee18  vmovaps xmm3, [rsp+0x30]
00007b78f51cee1e  vmovaps xmm4, [rsp+0x40]
00007b78f51cee24  vmovaps xmm5, [rsp+0x50]
00007b78f51cee2a  vmovaps xmm6, [rsp+0x60]
00007b78f51cee30  vmovaps xmm7, [rsp+0x70]
00007b78f51cee36  vmovaps xmm8, [rsp+0x80]
00007b78f51cee3f  vmovaps xmm9, [rsp+0x90]
00007b78f51cee48  vmovaps xmm10, [rsp+0xA0]
00007b78f51cee51  vmovaps xmm11, [rsp+0xB0]
00007b78f51cee5a  vmovaps xmm12, [rsp+0xC0]
00007b78f51cee63  vmovaps xmm14, [rsp+0xD0]
00007b78f51cee6c  vmovaps xmm15, [rsp+0xE0]
00007b78f51cee75  add rsp, 0xF0
00007b78f51cee7c  pop r11
00007b78f51cee7e  pop r10
00007b78f51cee80  pop r9
00007b78f51cee82  pop r8
00007b78f51cee84  pop rsi
00007b78f51cee85  pop rdi
00007b78f51cee86  pop rdx
00007b78f51cee87  pop rcx
00007b78f51cee88  pop rax
00007b78f51cee89  add rsp, 0x08
00007b78f51cee8d  jmp 0x00007B78F51CEC71
00007b78f51cee92  call 0x00007B78F50C2240
00007b78f51cee97  jmp 0x00007B78F51CEC8B
00007b78f51cee9c  sub rsp, 0x08
00007b78f51ceea0  push rax
00007b78f51ceea1  push rcx
00007b78f51ceea2  push rdx
00007b78f51ceea3  push rdi
00007b78f51ceea4  push rsi
00007b78f51ceea5  push r8
00007b78f51ceea7  push r9
00007b78f51ceea9  push r10
00007b78f51ceeab  push r11
00007b78f51ceead  sub rsp, 0xF0
00007b78f51ceeb4  vmovaps [rsp], xmm0
00007b78f51ceeb9  vmovaps [rsp+0x10], xmm1
00007b78f51ceebf  vmovaps [rsp+0x20], xmm2
00007b78f51ceec5  vmovaps [rsp+0x30], xmm3
00007b78f51ceecb  vmovaps [rsp+0x40], xmm4
00007b78f51ceed1  vmovaps [rsp+0x50], xmm5
00007b78f51ceed7  vmovaps [rsp+0x60], xmm6
00007b78f51ceedd  vmovaps [rsp+0x70], xmm7
00007b78f51ceee3  vmovaps [rsp+0x80], xmm8
00007b78f51ceeec  vmovaps [rsp+0x90], xmm9
00007b78f51ceef5  vmovaps [rsp+0xA0], xmm10
00007b78f51ceefe  vmovaps [rsp+0xB0], xmm11
00007b78f51cef07  vmovaps [rsp+0xC0], xmm12
00007b78f51cef10  vmovaps [rsp+0xD0], xmm13
00007b78f51cef19  vmovaps [rsp+0xE0], xmm15
00007b78f51cef22  sub rsp, 0x30
00007b78f51cef26  movaps [rsp], xmm14
00007b78f51cef2b  movaps [rsp+0x10], xmm1
00007b78f51cef30  movaps [rsp+0x20], xmm15
00007b78f51cef36  lea rdi, [rsp]
00007b78f51cef3a  mov esi, 0x00
00007b78f51cef3f  mov rax, 0x597478C09530
00007b78f51cef49  call rax
00007b78f51cef4b  movaps xmm14, [rsp]
00007b78f51cef50  add rsp, 0x30
00007b78f51cef54  vmovaps xmm0, [rsp]
00007b78f51cef59  vmovaps xmm1, [rsp+0x10]
00007b78f51cef5f  vmovaps xmm2, [rsp+0x20]
00007b78f51cef65  vmovaps xmm3, [rsp+0x30]
00007b78f51cef6b  vmovaps xmm4, [rsp+0x40]
00007b78f51cef71  vmovaps xmm5, [rsp+0x50]
00007b78f51cef77  vmovaps xmm6, [rsp+0x60]
00007b78f51cef7d  vmovaps xmm7, [rsp+0x70]
00007b78f51cef83  vmovaps xmm8, [rsp+0x80]
00007b78f51cef8c  vmovaps xmm9, [rsp+0x90]
00007b78f51cef95  vmovaps xmm10, [rsp+0xA0]
00007b78f51cef9e  vmovaps xmm11, [rsp+0xB0]
00007b78f51cefa7  vmovaps xmm12, [rsp+0xC0]
00007b78f51cefb0  vmovaps xmm13, [rsp+0xD0]
00007b78f51cefb9  vmovaps xmm15, [rsp+0xE0]
00007b78f51cefc2  add rsp, 0xF0
00007b78f51cefc9  pop r11
00007b78f51cefcb  pop r10
00007b78f51cefcd  pop r9
00007b78f51cefcf  pop r8
00007b78f51cefd1  pop rsi
00007b78f51cefd2  pop rdi
00007b78f51cefd3  pop rdx
00007b78f51cefd4  pop rcx
00007b78f51cefd5  pop rax
00007b78f51cefd6  add rsp, 0x08
00007b78f51cefda  jmp 0x00007B78F51CECAE
00007b78f51cefdf  call 0x00007B78F50C34C0
00007b78f51cefe4  jmp 0x00007B78F51CECC4
00007b78f51cefe9  int3
00007b78f51cefea  nop [rax+rax*1], ax
00007b78f51ceff0  mov rax, [r15+0xF8]
00007b78f51ceff7  lea r14, [rax-0x150]
00007b78f51ceffe  mov [r15+0xF8], r14
00007b78f51cf005  mov rax, [r15+0x50]
00007b78f51cf009  lea r12, [rax+0x80]
00007b78f51cf010  movups xmm1, [r13+r12*1]
00007b78f51cf016  lea r12, [rax+0x90]
00007b78f51cf01d  movups xmm15, [r13+r12*1]
00007b78f51cf023  mov qword ptr [r15+0x48], 0x00
00007b78f51cf02b  lea r12, [rax+0x40]
00007b78f51cf02f  movups xmm14, [r13+r12*1]
00007b78f51cf035  lea r12, [rax+0x50]
00007b78f51cf039  movups xmm13, [r13+r12*1]
00007b78f51cf03f  lea r12, [r14+0x120]
00007b78f51cf046  movq xmm12, qword ptr [r15+0x1C0]
00007b78f51cf04f  movq xmm11, qword ptr [r15+0x1B0]
00007b78f51cf058  movq r11, xmm12
00007b78f51cf05d  movq r10, xmm11
00007b78f51cf062  mov [r13+r12*1], r11
00007b78f51cf067  lea r12, [r14+0x128]
00007b78f51cf06e  mov [r13+r12*1], r10
00007b78f51cf073  vxorps xmm12, xmm12, xmm12
00007b78f51cf078  vpbroadcastq xmm12, xmm12
00007b78f51cf07d  lea r12, [r14+0x100]
00007b78f51cf084  movq xmm11, qword ptr [r15+0x200]
00007b78f51cf08d  movq xmm10, qword ptr [r15+0x1F0]
00007b78f51cf096  movq r11, xmm11
00007b78f51cf09b  movq r10, xmm10
00007b78f51cf0a0  mov [r13+r12*1], r11
00007b78f51cf0a5  lea r12, [r14+0x108]
00007b78f51cf0ac  mov [r13+r12*1], r10
00007b78f51cf0b1  lea r12, [r14+0xE0]
00007b78f51cf0b8  movups [r13+r12*1], xmm15
00007b78f51cf0be  lea r12, [r14+0xF0]
00007b78f51cf0c5  movups [r13+r12*1], xmm1
00007b78f51cf0cb  lea r12, [rax+0xC0]
00007b78f51cf0d2  movups xmm1, [r13+r12*1]
00007b78f51cf0d8  lea r12, [rax+0xD0]
00007b78f51cf0df  movups xmm15, [r13+r12*1]
00007b78f51cf0e5  lea r12, [r14+0x110]
00007b78f51cf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007b78f51cf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007b78f51cf0fe  movq r11, xmm11
00007b78f51cf103  movq r10, xmm10
00007b78f51cf108  mov [r13+r12*1], r11
00007b78f51cf10d  lea r12, [r14+0x118]
00007b78f51cf114  mov [r13+r12*1], r10
00007b78f51cf119  movups xmm11, [r13+rax*1]
00007b78f51cf11f  lea r12, [rax+0x10]
00007b78f51cf123  movups xmm10, [r13+r12*1]
00007b78f51cf129  lea r12, [r14+0x130]
00007b78f51cf130  movq xmm9, qword ptr [r15+0x1A0]
00007b78f51cf139  movq xmm8, qword ptr [r15+0x190]
00007b78f51cf142  movq r11, xmm9
00007b78f51cf147  movq r10, xmm8
00007b78f51cf14c  mov [r13+r12*1], r11
00007b78f51cf151  lea r12, [r14+0x138]
00007b78f51cf158  mov [r13+r12*1], r10
00007b78f51cf15d  lea r12, [rax+0x140]
00007b78f51cf164  movups xmm9, [r13+r12*1]
00007b78f51cf16a  lea r12, [rax+0x150]
00007b78f51cf171  movups xmm8, [r13+r12*1]
00007b78f51cf177  lea r12, [r14+0xC0]
00007b78f51cf17e  movups [r13+r12*1], xmm15
00007b78f51cf184  lea r12, [r14+0xD0]
00007b78f51cf18b  movups [r13+r12*1], xmm1
00007b78f51cf191  lea r12, [rax+0x100]
00007b78f51cf198  movups xmm1, [r13+r12*1]
00007b78f51cf19e  lea r12, [rax+0x110]
00007b78f51cf1a5  movups xmm15, [r13+r12*1]
00007b78f51cf1ab  lea r12, [r14+0x140]
00007b78f51cf1b2  mov r11, [r15+0xE8]
00007b78f51cf1b9  mov [r13+r12*1], r11
00007b78f51cf1be  lea r12, [rax+0x180]
00007b78f51cf1c5  movups xmm7, [r13+r12*1]
00007b78f51cf1cb  lea r12, [rax+0x190]
00007b78f51cf1d2  movups xmm6, [r13+r12*1]
00007b78f51cf1d8  lea r12, [rax+0x1C0]
00007b78f51cf1df  movups xmm5, [r13+r12*1]
00007b78f51cf1e5  lea r12, [rax+0x1D0]
00007b78f51cf1ec  movups xmm4, [r13+r12*1]
00007b78f51cf1f2  lea r12, [r14+0x20]
00007b78f51cf1f6  movups [r13+r12*1], xmm1
00007b78f51cf1fc  lea r12, [r14+0x30]
00007b78f51cf200  movups [r13+r12*1], xmm13
00007b78f51cf206  lea r12, [rax+0x60]
00007b78f51cf20a  movups xmm1, [r13+r12*1]
00007b78f51cf210  lea r12, [rax+0x70]
00007b78f51cf214  movups xmm13, [r13+r12*1]
00007b78f51cf21a  lea r12, [rax+0x20]
00007b78f51cf21e  movups xmm3, [r13+r12*1]
00007b78f51cf224  lea r12, [rax+0x30]
00007b78f51cf228  movups xmm2, [r13+r12*1]
00007b78f51cf22e  movaps [r15+0x1F0], xmm2
00007b78f51cf236  lea r12, [r14+0x60]
00007b78f51cf23a  movups [r13+r12*1], xmm11
00007b78f51cf240  lea r12, [r14+0x70]
00007b78f51cf244  movups [r13+r12*1], xmm5
00007b78f51cf24a  lea r12, [rax+0xE0]
00007b78f51cf251  movups xmm11, [r13+r12*1]
00007b78f51cf257  lea r12, [rax+0xF0]
00007b78f51cf25e  movups xmm5, [r13+r12*1]
00007b78f51cf264  lea r12, [r14+0xA0]
00007b78f51cf26b  movups [r13+r12*1], xmm13
00007b78f51cf271  lea r12, [r14+0xB0]
00007b78f51cf278  movups [r13+r12*1], xmm1
00007b78f51cf27e  lea r12, [rax+0xA0]
00007b78f51cf285  movups xmm1, [r13+r12*1]
00007b78f51cf28b  lea r12, [rax+0xB0]
00007b78f51cf292  movups xmm13, [r13+r12*1]
00007b78f51cf298  lea r12, [rax+0x120]
00007b78f51cf29f  vmovaps [rsp+0x10], xmm1
00007b78f51cf2a5  movups xmm1, [r13+r12*1]
00007b78f51cf2ab  lea r12, [rax+0x130]
00007b78f51cf2b2  vmovaps [rsp+0x20], xmm1
00007b78f51cf2b8  movups xmm1, [r13+r12*1]
00007b78f51cf2be  lea r12, [rax+0x160]
00007b78f51cf2c5  vmovaps [rsp+0x30], xmm1
00007b78f51cf2cb  movups xmm1, [r13+r12*1]
00007b78f51cf2d1  lea r12, [rax+0x170]
00007b78f51cf2d8  vmovaps [rsp+0x40], xmm1
00007b78f51cf2de  movups xmm1, [r13+r12*1]
00007b78f51cf2e4  movaps [r15+0x2B0], xmm1
00007b78f51cf2ec  lea r12, [r14+0x80]
00007b78f51cf2f3  movups [r13+r12*1], xmm13
00007b78f51cf2f9  lea r12, [r14+0x90]
00007b78f51cf300  vmovaps xmm13, [rsp+0x10]
00007b78f51cf306  movups [r13+r12*1], xmm13
00007b78f51cf30c  lea r12, [rax+0x1A0]
00007b78f51cf313  movups xmm13, [r13+r12*1]
00007b78f51cf319  lea r12, [rax+0x1B0]
00007b78f51cf320  vmovaps [rsp+0x10], xmm1
00007b78f51cf326  movups xmm1, [r13+r12*1]
00007b78f51cf32c  movaps [r15+0x290], xmm13
00007b78f51cf334  movaps [r15+0x1E0], xmm1
00007b78f51cf33c  lea r12, [rax+0x1E0]
00007b78f51cf343  vmovaps [rsp+0x50], xmm1
00007b78f51cf349  movups xmm1, [r13+r12*1]
00007b78f51cf34f  lea r12, [rax+0x1F0]
00007b78f51cf356  vmovaps [rsp+0x60], xmm1
00007b78f51cf35c  movups xmm1, [r13+r12*1]
00007b78f51cf362  mov qword ptr [r15+0x50], 0x430920
00007b78f51cf36a  lea rax, [r14+0x40]
00007b78f51cf36e  vmovaps [rsp+0x70], xmm1
00007b78f51cf374  vmovaps xmm1, [rsp+0x40]
00007b78f51cf37a  movups [r13+rax*1], xmm1
00007b78f51cf380  lea rax, [r14+0x50]
00007b78f51cf384  movups [r13+rax*1], xmm10
00007b78f51cf38a  vmovaps xmm1, [rsp+0x70]
00007b78f51cf390  movups [r13+r14*1], xmm1
00007b78f51cf396  lea rax, [r14+0x10]
00007b78f51cf39a  vmovaps xmm1, [rsp+0x60]
00007b78f51cf3a0  movups [r13+rax*1], xmm1
00007b78f51cf3a6  mov rax, [r15+0x40]
00007b78f51cf3aa  vmovaps [rsp+0x40], xmm3
00007b78f51cf3b0  vmovaps xmm1, [rsp+0x40]
00007b78f51cf3b6  por xmm3, xmm1
00007b78f51cf3ba  vmovaps [rsp+0x40], xmm6
00007b78f51cf3c0  vmovaps xmm10, [rsp+0x40]
00007b78f51cf3c6  por xmm6, xmm10
00007b78f51cf3cb  lea r12, [rax+0x30]
00007b78f51cf3cf  mov r11, [r13+r12*1]
00007b78f51cf3d4  lea r12, [rax+0x38]
00007b78f51cf3d8  mov r10, [r13+r12*1]
00007b78f51cf3dd  movq xmm10, r11
00007b78f51cf3e2  vmovaps [rsp+0x40], xmm1
00007b78f51cf3e8  movq xmm1, r10
00007b78f51cf3ed  movq xmm10, xmm10
00007b78f51cf3f2  vmovaps [rsp+0x60], xmm10
00007b78f51cf3f8  movq xmm10, xmm10
00007b78f51cf3fd  movaps [r15+0x130], xmm10
00007b78f51cf405  movq xmm1, xmm1
00007b78f51cf409  vmovaps [rsp+0x70], xmm1
00007b78f51cf40f  movq xmm1, xmm1
00007b78f51cf413  movaps [r15+0x280], xmm1
00007b78f51cf41b  vmovaps [rsp+0x80], xmm9
00007b78f51cf424  vmovaps xmm1, [rsp+0x80]
00007b78f51cf42d  por xmm9, xmm1
00007b78f51cf432  lea r12, [rax+0x20]
00007b78f51cf436  mov r11, [r13+r12*1]
00007b78f51cf43b  lea r12, [rax+0x28]
00007b78f51cf43f  mov r10, [r13+r12*1]
00007b78f51cf444  movq xmm1, r11
00007b78f51cf449  movq xmm10, r10
00007b78f51cf44e  movq xmm1, xmm1
00007b78f51cf452  vmovaps [rsp+0x80], xmm1
00007b78f51cf45b  movq xmm1, xmm1
00007b78f51cf45f  movaps [r15+0x150], xmm1
00007b78f51cf467  movq xmm10, xmm10
00007b78f51cf46c  vmovaps [rsp+0x90], xmm10
00007b78f51cf475  movq xmm10, xmm10
00007b78f51cf47a  movaps [r15+0x140], xmm10
00007b78f51cf482  lea r12, [rax+0x10]
00007b78f51cf486  mov r11, [r13+r12*1]
00007b78f51cf48b  lea r12, [rax+0x18]
00007b78f51cf48f  mov r10, [r13+r12*1]
00007b78f51cf494  movq xmm1, r11
00007b78f51cf499  movq xmm10, r10
00007b78f51cf49e  movq xmm1, xmm1
00007b78f51cf4a2  vmovaps [rsp+0xA0], xmm1
00007b78f51cf4ab  movq xmm1, xmm1
00007b78f51cf4af  movaps [r15+0x170], xmm1
00007b78f51cf4b7  movq xmm10, xmm10
00007b78f51cf4bc  vmovaps [rsp+0xB0], xmm10
00007b78f51cf4c5  movq xmm10, xmm10
00007b78f51cf4ca  movaps [r15+0x160], xmm10
00007b78f51cf4d2  mov r12, [r13+rax*1]
00007b78f51cf4d7  vmovq xmm1, r12
00007b78f51cf4dc  vpbroadcastq xmm1, xmm1
00007b78f51cf4e1  lea r12, [rax+0x08]
00007b78f51cf4e5  mov rax, [r13+r12*1]
00007b78f51cf4ea  movq xmm10, rax
00007b78f51cf4ef  movaps [r15+0x230], xmm10
00007b78f51cf4f7  lea rax, [r14+0x50]
00007b78f51cf4fb  movups xmm10, [r13+rax*1]
00007b78f51cf501  lea rax, [r14+0x60]
00007b78f51cf505  vmovaps [rsp+0xC0], xmm1
00007b78f51cf50e  movups xmm1, [r13+rax*1]
00007b78f51cf514  lea rax, [r14+0x30]
00007b78f51cf518  vmovaps [rsp+0xD0], xmm1
00007b78f51cf521  movups xmm1, [r13+rax*1]
00007b78f51cf527  mov qword ptr [r15+0x60], 0x430920
00007b78f51cf52f  mov qword ptr [r15+0x58], 0x40
00007b78f51cf537  vmovaps [rsp+0xE0], xmm1
00007b78f51cf540  vmovaps [rsp+0xF0], xmm15
00007b78f51cf549  vmovaps xmm15, [rsp+0xC0]
00007b78f51cf552  vmovaps [rsp+0xC0], xmm14
00007b78f51cf55b  vmovaps xmm14, [rsp+0x40]
00007b78f51cf561  vmovaps [rsp+0x40], xmm13
00007b78f51cf567  movaps xmm1, xmm15
00007b78f51cf56b  mulpd xmm1, xmm14
00007b78f51cf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007b78f51cf575  ptest xmm13, xmm13
00007b78f51cf57b  jnz 0x00007B78F51D0682
00007b78f51cf581  movq xmm14, qword ptr [r15+0x230]
00007b78f51cf58a  vmovaps [rsp+0x100], xmm14
00007b78f51cf593  vpermilpd xmm14, xmm14, 0x00
00007b78f51cf599  vmovaps [rsp+0x110], xmm1
00007b78f51cf5a2  vmovaps xmm1, [rsp+0xE0]
00007b78f51cf5ab  vmovaps [rsp+0xE0], xmm15
00007b78f51cf5b4  movaps xmm13, xmm1
00007b78f51cf5b8  mulpd xmm13, xmm14
00007b78f51cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007b78f51cf5c3  ptest xmm15, xmm15
00007b78f51cf5c9  jnz 0x00007B78F51D07C4
00007b78f51cf5cf  vxorps xmm1, xmm1, xmm1
00007b78f51cf5d3  vpbroadcastq xmm1, xmm1
00007b78f51cf5d8  vmovaps xmm14, [rsp+0xE0]
00007b78f51cf5e1  vmovaps [rsp+0xE0], xmm1
00007b78f51cf5ea  vmovaps xmm1, [rsp+0xD0]
00007b78f51cf5f3  vmovaps [rsp+0xD0], xmm13
00007b78f51cf5fc  movaps xmm15, xmm14
00007b78f51cf600  mulpd xmm15, xmm1
00007b78f51cf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007b78f51cf60b  ptest xmm13, xmm13
00007b78f51cf611  jnz 0x00007B78F51D0907
00007b78f51cf617  movaps xmm1, xmm14
00007b78f51cf61b  mulpd xmm1, xmm10
00007b78f51cf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007b78f51cf625  ptest xmm13, xmm13
00007b78f51cf62b  jnz 0x00007B78F51D0A4A
00007b78f51cf631  movaps xmm13, xmm14
00007b78f51cf635  mulpd xmm13, xmm2
00007b78f51cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007b78f51cf640  ptest xmm10, xmm10
00007b78f51cf646  jnz 0x00007B78F51D0B8C
00007b78f51cf64c  vmovaps [rsp+0x120], xmm7
00007b78f51cf655  vmovaps xmm14, [rsp+0x120]
00007b78f51cf65e  por xmm7, xmm14
00007b78f51cf663  vmovaps xmm14, [rsp+0xC0]
00007b78f51cf66c  vmovaps xmm10, [rsp+0xC0]
00007b78f51cf675  por xmm14, xmm10
00007b78f51cf67a  vmovaps xmm2, [rsp+0x100]
00007b78f51cf683  vpermilpd xmm2, xmm2, 0x00
00007b78f51cf689  vmovaps [rsp+0xC0], xmm1
00007b78f51cf692  vmovaps [rsp+0x120], xmm15
00007b78f51cf69b  movaps xmm1, xmm10
00007b78f51cf69f  mulpd xmm1, xmm2
00007b78f51cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007b78f51cf6a8  ptest xmm15, xmm15
00007b78f51cf6ae  jnz 0x00007B78F51D0CCF
00007b78f51cf6b4  xor eax, eax
00007b78f51cf6b6  mov r12d, 0x40
00007b78f51cf6bc  mov r11d, 0x200
00007b78f51cf6c2  cmp r12, r11
00007b78f51cf6c5  cmc
00007b78f51cf6c6  lahf
00007b78f51cf6c7  seto al
00007b78f51cf6ca  mov [r15+0x108], eax
00007b78f51cf6d1  vmovaps xmm10, [rsp+0x110]
00007b78f51cf6da  vmovaps xmm2, [rsp+0xE0]
00007b78f51cf6e3  vmovaps [rsp+0xE0], xmm1
00007b78f51cf6ec  movaps xmm15, xmm10
00007b78f51cf6f0  addpd xmm15, xmm2
00007b78f51cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007b78f51cf6fb  ptest xmm1, xmm1
00007b78f51cf700  jnz 0x00007B78F51D0E10
00007b78f51cf706  vmovaps xmm10, [rsp+0x120]
00007b78f51cf70f  vmovaps [rsp+0x110], xmm15
00007b78f51cf718  movaps xmm1, xmm10
00007b78f51cf71c  addpd xmm1, xmm12
00007b78f51cf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007b78f51cf726  ptest xmm15, xmm15
00007b78f51cf72c  jnz 0x00007B78F51D0F53
00007b78f51cf732  vmovaps xmm10, [rsp+0xC0]
00007b78f51cf73b  vmovaps [rsp+0xC0], xmm1
00007b78f51cf744  movaps xmm15, xmm10
00007b78f51cf748  addpd xmm15, xmm12
00007b78f51cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007b78f51cf753  ptest xmm1, xmm1
00007b78f51cf758  jnz 0x00007B78F51D1095
00007b78f51cf75e  vmovaps xmm1, [rsp+0x30]
00007b78f51cf764  vmovaps xmm12, [rsp+0x30]
00007b78f51cf76a  por xmm1, xmm12
00007b78f51cf76f  vmovaps xmm12, [rsp+0x20]
00007b78f51cf775  vmovaps xmm10, [rsp+0x20]
00007b78f51cf77b  por xmm12, xmm10
00007b78f51cf780  vmovaps [rsp+0x20], xmm5
00007b78f51cf786  vmovaps xmm10, [rsp+0x20]
00007b78f51cf78c  por xmm5, xmm10
00007b78f51cf791  vmovaps [rsp+0x20], xmm11
00007b78f51cf797  vmovaps xmm10, [rsp+0x20]
00007b78f51cf79d  por xmm11, xmm10
00007b78f51cf7a2  vmovaps [rsp+0x20], xmm4
00007b78f51cf7a8  vmovaps xmm10, [rsp+0x20]
00007b78f51cf7ae  por xmm4, xmm10
00007b78f51cf7b3  vmovaps [rsp+0x20], xmm8
00007b78f51cf7b9  vmovaps xmm10, [rsp+0x20]
00007b78f51cf7bf  por xmm8, xmm10
00007b78f51cf7c4  vmovaps xmm10, [rsp+0xF0]
00007b78f51cf7cd  vmovaps [rsp+0x20], xmm1
00007b78f51cf7d3  vmovaps xmm1, [rsp+0xF0]
00007b78f51cf7dc  por xmm10, xmm1
00007b78f51cf7e1  lea rax, [r14+0xA0]
00007b78f51cf7e8  movups xmm1, [r13+rax*1]
00007b78f51cf7ee  lea rax, [r14+0xB0]
00007b78f51cf7f5  vmovaps [rsp+0x30], xmm1
00007b78f51cf7fb  movups xmm1, [r13+rax*1]
00007b78f51cf801  vmovaps [rsp+0xF0], xmm1
00007b78f51cf80a  vmovaps [rsp+0x120], xmm15
00007b78f51cf813  movaps xmm1, xmm13
00007b78f51cf817  addpd xmm1, xmm2
00007b78f51cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007b78f51cf820  ptest xmm15, xmm15
00007b78f51cf826  jnz 0x00007B78F51D11ED
00007b78f51cf82c  lea rax, [r14+0xF0]
00007b78f51cf833  movups xmm15, [r13+rax*1]
00007b78f51cf839  vmovaps xmm2, [rsp+0xC0]
00007b78f51cf842  vmovaps [rsp+0xC0], xmm1
00007b78f51cf84b  vmovaps xmm1, [rsp+0xE0]
00007b78f51cf854  vmovaps [rsp+0xE0], xmm15
00007b78f51cf85d  movaps xmm13, xmm2
00007b78f51cf861  addpd xmm13, xmm1
00007b78f51cf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007b78f51cf86c  ptest xmm15, xmm15
00007b78f51cf872  jnz 0x00007B78F51D1338
00007b78f51cf878  vmovaps xmm15, [rsp+0x120]
00007b78f51cf881  vmovaps xmm2, [rsp+0xD0]
00007b78f51cf88a  vmovaps [rsp+0xD0], xmm14
00007b78f51cf893  movaps xmm1, xmm15
00007b78f51cf897  addpd xmm1, xmm2
00007b78f51cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007b78f51cf8a0  ptest xmm14, xmm14
00007b78f51cf8a6  jnz 0x00007B78F51D147A
00007b78f51cf8ac  vmovaps xmm15, [rsp+0x100]
00007b78f51cf8b5  vpermilpd xmm15, xmm15, 0x00
00007b78f51cf8bb  vmovaps xmm2, [rsp+0xF0]
00007b78f51cf8c4  vmovaps [rsp+0xF0], xmm1
00007b78f51cf8cd  movaps xmm14, xmm2
00007b78f51cf8d1  mulpd xmm14, xmm15
00007b78f51cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007b78f51cf8dc  ptest xmm1, xmm1
00007b78f51cf8e1  jnz 0x00007B78F51D15BB
00007b78f51cf8e7  vmovaps xmm1, [rsp+0xA0]
00007b78f51cf8f0  vpermilpd xmm1, xmm1, 0x00
00007b78f51cf8f6  vmovaps xmm2, [rsp+0xE0]
00007b78f51cf8ff  vmovaps [rsp+0xE0], xmm14
00007b78f51cf908  movaps xmm15, xmm2
00007b78f51cf90c  mulpd xmm15, xmm1
00007b78f51cf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007b78f51cf917  ptest xmm14, xmm14
00007b78f51cf91d  jnz 0x00007B78F51D16FE
00007b78f51cf923  lea rax, [r14+0xE0]
00007b78f51cf92a  movups xmm1, [r13+rax*1]
00007b78f51cf930  vmovaps xmm14, [rsp+0x100]
00007b78f51cf939  vpermilpd xmm14, xmm14, 0x00
00007b78f51cf93f  vmovaps [rsp+0x100], xmm1
00007b78f51cf948  vmovaps xmm1, [rsp+0x30]
00007b78f51cf94e  vmovaps [rsp+0x30], xmm15
00007b78f51cf954  movaps xmm2, xmm1
00007b78f51cf957  mulpd xmm2, xmm14
00007b78f51cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007b78f51cf961  ptest xmm15, xmm15
00007b78f51cf967  jnz 0x00007B78F51D184A
00007b78f51cf96d  vmovaps [rsp+0x120], xmm10
00007b78f51cf976  vmovaps xmm1, [rsp+0x120]
00007b78f51cf97f  por xmm10, xmm1
00007b78f51cf984  movaps [r15+0x300], xmm10
00007b78f51cf98c  vmovaps [rsp+0x120], xmm8
00007b78f51cf995  vmovaps xmm1, [rsp+0x120]
00007b78f51cf99e  por xmm8, xmm1
00007b78f51cf9a3  movaps [r15+0x190], xmm8
00007b78f51cf9ab  vmovaps xmm1, [rsp+0xA0]
00007b78f51cf9b4  vpermilpd xmm1, xmm1, 0x00
00007b78f51cf9ba  vmovaps xmm14, [rsp+0x100]
00007b78f51cf9c3  vmovaps [rsp+0x100], xmm13
00007b78f51cf9cc  movaps xmm15, xmm14
00007b78f51cf9d0  mulpd xmm15, xmm1
00007b78f51cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007b78f51cf9db  ptest xmm13, xmm13
00007b78f51cf9e1  jnz 0x00007B78F51D198B
00007b78f51cf9e7  lea rax, [r14+0x90]
00007b78f51cf9ee  movups xmm1, [r13+rax*1]
00007b78f51cf9f4  vmovaps [rsp+0x120], xmm4
00007b78f51cf9fd  vmovaps xmm14, [rsp+0x120]
00007b78f51cfa06  por xmm4, xmm14
00007b78f51cfa0b  movaps [r15+0x1C0], xmm4
00007b78f51cfa13  vmovaps [rsp+0x120], xmm11
00007b78f51cfa1c  vmovaps xmm14, [rsp+0x120]
00007b78f51cfa25  por xmm11, xmm14
00007b78f51cfa2a  movaps [r15+0x200], xmm11
00007b78f51cfa32  vmovaps [rsp+0x120], xmm5
00007b78f51cfa3b  vmovaps xmm14, [rsp+0x120]
00007b78f51cfa44  por xmm5, xmm14
00007b78f51cfa49  movaps [r15+0x2D0], xmm5
00007b78f51cfa51  vmovaps [rsp+0x120], xmm12
00007b78f51cfa5a  vmovaps xmm14, [rsp+0x120]
00007b78f51cfa63  por xmm12, xmm14
00007b78f51cfa68  movaps [r15+0x2E0], xmm12
00007b78f51cfa70  vmovaps xmm13, [rsp+0x110]
00007b78f51cfa79  vmovaps [rsp+0x110], xmm1
00007b78f51cfa82  vmovaps xmm1, [rsp+0xE0]
00007b78f51cfa8b  vmovaps [rsp+0xE0], xmm15
00007b78f51cfa94  movaps xmm14, xmm13
00007b78f51cfa98  addpd xmm14, xmm1
00007b78f51cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007b78f51cfaa3  ptest xmm15, xmm15
00007b78f51cfaa9  jnz 0x00007B78F51D1AD8
00007b78f51cfaaf  vmovaps xmm1, [rsp+0xA0]
00007b78f51cfab8  vpermilpd xmm1, xmm1, 0x00
00007b78f51cfabe  vmovaps xmm13, [rsp+0x110]
00007b78f51cfac7  vmovaps [rsp+0x110], xmm14
00007b78f51cfad0  movaps xmm15, xmm13
00007b78f51cfad4  mulpd xmm15, xmm1
00007b78f51cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007b78f51cfadf  ptest xmm14, xmm14
00007b78f51cfae5  jnz 0x00007B78F51D1C1B
00007b78f51cfaeb  lea rax, [r14+0x80]
00007b78f51cfaf2  movups xmm1, [r13+rax*1]
00007b78f51cfaf8  vmovaps xmm13, [rsp+0xC0]
00007b78f51cfb01  vmovaps [rsp+0xC0], xmm1
00007b78f51cfb0a  movaps xmm14, xmm13
00007b78f51cfb0e  addpd xmm14, xmm2
00007b78f51cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007b78f51cfb19  ptest xmm1, xmm1
00007b78f51cfb1e  jnz 0x00007B78F51D1D68
00007b78f51cfb24  vmovaps xmm13, [rsp+0x100]
00007b78f51cfb2d  vmovaps xmm2, [rsp+0x30]
00007b78f51cfb33  vmovaps [rsp+0x30], xmm15
00007b78f51cfb39  movaps xmm1, xmm13
00007b78f51cfb3d  addpd xmm1, xmm2
00007b78f51cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007b78f51cfb46  ptest xmm15, xmm15
00007b78f51cfb4c  jnz 0x00007B78F51D1EAB
00007b78f51cfb52  vmovaps xmm15, [rsp+0x20]
00007b78f51cfb58  vmovaps xmm13, [rsp+0x20]
00007b78f51cfb5e  por xmm15, xmm13
00007b78f51cfb63  movaps [r15+0x2F0], xmm15
00007b78f51cfb6b  vmovaps xmm13, [rsp+0xA0]
00007b78f51cfb74  vpermilpd xmm13, xmm13, 0x00
00007b78f51cfb7a  vmovaps [rsp+0x20], xmm1
00007b78f51cfb80  vmovaps xmm1, [rsp+0xC0]
00007b78f51cfb89  vmovaps [rsp+0xA0], xmm15
00007b78f51cfb92  movaps xmm2, xmm1
00007b78f51cfb95  mulpd xmm2, xmm13
00007b78f51cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007b78f51cfb9f  ptest xmm15, xmm15
00007b78f51cfba5  jnz 0x00007B78F51D1FEC
00007b78f51cfbab  lea rax, [r14+0xD0]
00007b78f51cfbb2  movups xmm1, [r13+rax*1]
00007b78f51cfbb8  vmovaps xmm13, [rsp+0xF0]
00007b78f51cfbc1  vmovaps [rsp+0xC0], xmm1
00007b78f51cfbca  vmovaps xmm1, [rsp+0xE0]
00007b78f51cfbd3  vmovaps [rsp+0xE0], xmm14
00007b78f51cfbdc  movaps xmm15, xmm13
00007b78f51cfbe0  addpd xmm15, xmm1
00007b78f51cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007b78f51cfbeb  ptest xmm14, xmm14
00007b78f51cfbf1  jnz 0x00007B78F51D2137
00007b78f51cfbf7  vmovaps xmm1, [rsp+0xB0]
00007b78f51cfc00  vpermilpd xmm1, xmm1, 0x00
00007b78f51cfc06  movaps xmm14, xmm11
00007b78f51cfc0a  mulpd xmm14, xmm1
00007b78f51cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007b78f51cfc15  ptest xmm13, xmm13
00007b78f51cfc1b  jnz 0x00007B78F51D227A
00007b78f51cfc21  movaps [r15+0x260], xmm14
00007b78f51cfc29  vxorps xmm1, xmm1, xmm1
00007b78f51cfc2d  vpbroadcastq xmm1, xmm1
00007b78f51cfc32  movaps [r15+0x1B0], xmm1
00007b78f51cfc3a  vmovaps xmm1, [rsp+0xB0]
00007b78f51cfc43  vpermilpd xmm1, xmm1, 0x00
00007b78f51cfc49  vmovaps xmm11, [rsp+0xC0]
00007b78f51cfc52  vmovaps [rsp+0xC0], xmm15
00007b78f51cfc5b  movaps xmm13, xmm11
00007b78f51cfc5f  mulpd xmm13, xmm1
00007b78f51cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007b78f51cfc6a  ptest xmm15, xmm15
00007b78f51cfc70  jnz 0x00007B78F51D23BD
00007b78f51cfc76  lea rax, [r14+0xC0]
00007b78f51cfc7d  movups xmm1, [r13+rax*1]
00007b78f51cfc83  vmovaps xmm11, [rsp+0x110]
00007b78f51cfc8c  vmovaps [rsp+0xF0], xmm1
00007b78f51cfc95  vmovaps xmm1, [rsp+0x30]
00007b78f51cfc9b  vmovaps [rsp+0x30], xmm14
00007b78f51cfca1  movaps xmm15, xmm11
00007b78f51cfca5  addpd xmm15, xmm1
00007b78f51cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007b78f51cfcb0  ptest xmm14, xmm14
00007b78f51cfcb6  jnz 0x00007B78F51D250A
00007b78f51cfcbc  vmovaps [rsp+0x100], xmm9
00007b78f51cfcc5  vmovaps xmm1, [rsp+0x100]
00007b78f51cfcce  por xmm9, xmm1
00007b78f51cfcd3  movaps [r15+0x270], xmm9
00007b78f51cfcdb  vmovaps [rsp+0x100], xmm6
00007b78f51cfce4  vmovaps xmm1, [rsp+0x100]
00007b78f51cfced  por xmm6, xmm1
00007b78f51cfcf1  movaps [r15+0x1A0], xmm6
00007b78f51cfcf9  vmovaps xmm14, [rsp+0xB0]
00007b78f51cfd02  vpermilpd xmm14, xmm14, 0x00
00007b78f51cfd08  vmovaps xmm6, [rsp+0xF0]
00007b78f51cfd11  vmovaps [rsp+0xF0], xmm1
00007b78f51cfd1a  movaps xmm11, xmm6
00007b78f51cfd1e  mulpd xmm11, xmm14
00007b78f51cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007b78f51cfd29  ptest xmm1, xmm1
00007b78f51cfd2e  jnz 0x00007B78F51D264D
00007b78f51cfd34  lea rax, [r14+0x20]
00007b78f51cfd38  movups xmm1, [r13+rax*1]
00007b78f51cfd3e  movaps [r15+0x110], xmm1
00007b78f51cfd46  vmovaps xmm6, [rsp+0xE0]
00007b78f51cfd4f  vmovaps [rsp+0xE0], xmm1
00007b78f51cfd58  movaps xmm14, xmm6
00007b78f51cfd5c  addpd xmm14, xmm2
00007b78f51cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007b78f51cfd67  ptest xmm1, xmm1
00007b78f51cfd6c  jnz 0x00007B78F51D279A
00007b78f51cfd72  vmovaps xmm1, [rsp+0xB0]
00007b78f51cfd7b  vpermilpd xmm1, xmm1, 0x00
00007b78f51cfd81  movaps xmm6, xmm5
00007b78f51cfd84  mulpd xmm6, xmm1
00007b78f51cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007b78f51cfd8d  ptest xmm2, xmm2
00007b78f51cfd92  jnz 0x00007B78F51D28DC
00007b78f51cfd98  vmovaps xmm5, [rsp+0x20]
00007b78f51cfd9e  movaps xmm1, xmm5
00007b78f51cfda1  addpd xmm1, xmm13
00007b78f51cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007b78f51cfdab  ptest xmm2, xmm2
00007b78f51cfdb0  jnz 0x00007B78F51D2A1C
00007b78f51cfdb6  vmovaps xmm13, [rsp+0x80]
00007b78f51cfdbf  vpermilpd xmm13, xmm13, 0x00
00007b78f51cfdc5  vmovaps xmm2, [rsp+0xE0]
00007b78f51cfdce  vmovaps [rsp+0x20], xmm1
00007b78f51cfdd4  movaps xmm5, xmm2
00007b78f51cfdd7  mulpd xmm5, xmm13
00007b78f51cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007b78f51cfde1  ptest xmm1, xmm1
00007b78f51cfde6  jnz 0x00007B78F51D2B5D
00007b78f51cfdec  vmovaps xmm1, [rsp+0x80]
00007b78f51cfdf5  vpermilpd xmm1, xmm1, 0x00
00007b78f51cfdfb  movaps xmm13, xmm10
00007b78f51cfdff  mulpd xmm13, xmm1
00007b78f51cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007b78f51cfe0a  ptest xmm2, xmm2
00007b78f51cfe0f  jnz 0x00007B78F51D2C9E
00007b78f51cfe15  vmovaps xmm10, [rsp+0x30]
00007b78f51cfe1b  movaps xmm1, xmm15
00007b78f51cfe1f  addpd xmm1, xmm10
00007b78f51cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007b78f51cfe29  ptest xmm2, xmm2
00007b78f51cfe2e  jnz 0x00007B78F51D2DE1
00007b78f51cfe34  vmovaps xmm10, [rsp+0xC0]
00007b78f51cfe3d  movaps xmm15, xmm10
00007b78f51cfe41  addpd xmm15, xmm11
00007b78f51cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007b78f51cfe4c  ptest xmm2, xmm2
00007b78f51cfe51  jnz 0x00007B78F51D2F23
00007b78f51cfe57  vmovaps xmm11, [rsp+0x80]
00007b78f51cfe60  vpermilpd xmm11, xmm11, 0x00
00007b78f51cfe66  movaps xmm10, xmm12
00007b78f51cfe6a  mulpd xmm10, xmm11
00007b78f51cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007b78f51cfe75  ptest xmm2, xmm2
00007b78f51cfe7a  jnz 0x00007B78F51D3067
00007b78f51cfe80  vmovaps xmm12, [rsp+0x80]
00007b78f51cfe89  vpermilpd xmm12, xmm12, 0x00
00007b78f51cfe8f  vmovaps xmm2, [rsp+0xA0]
00007b78f51cfe98  vmovaps [rsp+0x30], xmm1
00007b78f51cfe9e  movaps xmm11, xmm2
00007b78f51cfea2  mulpd xmm11, xmm12
00007b78f51cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007b78f51cfead  ptest xmm1, xmm1
00007b78f51cfeb2  jnz 0x00007B78F51D31AB
00007b78f51cfeb8  movaps xmm1, xmm14
00007b78f51cfebc  addpd xmm1, xmm6
00007b78f51cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007b78f51cfec5  ptest xmm12, xmm12
00007b78f51cfecb  jnz 0x00007B78F51D32EE
00007b78f51cfed1  vmovaps xmm12, [rsp+0x20]
00007b78f51cfed7  movaps xmm14, xmm12
00007b78f51cfedb  addpd xmm14, xmm5
00007b78f51cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007b78f51cfee6  ptest xmm6, xmm6
00007b78f51cfeeb  jnz 0x00007B78F51D342F
00007b78f51cfef1  vmovaps xmm12, [rsp+0x90]
00007b78f51cfefa  vpermilpd xmm12, xmm12, 0x00
00007b78f51cff00  movaps xmm6, xmm9
00007b78f51cff04  mulpd xmm6, xmm12
00007b78f51cff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007b78f51cff0e  ptest xmm5, xmm5
00007b78f51cff13  jnz 0x00007B78F51D3572
00007b78f51cff19  movaps xmm12, xmm15
00007b78f51cff1d  addpd xmm12, xmm13
00007b78f51cff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007b78f51cff28  ptest xmm9, xmm9
00007b78f51cff2e  jnz 0x00007B78F51D36B4
00007b78f51cff34  vmovaps xmm13, [rsp+0x30]
00007b78f51cff3a  movaps xmm15, xmm13
00007b78f51cff3e  addpd xmm15, xmm10
00007b78f51cff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007b78f51cff49  ptest xmm9, xmm9
00007b78f51cff4f  jnz 0x00007B78F51D37F8
00007b78f51cff55  vmovaps xmm13, [rsp+0xD0]
00007b78f51cff5e  vmovaps xmm10, [rsp+0xD0]
00007b78f51cff67  por xmm13, xmm10
00007b78f51cff6c  movaps [r15+0x250], xmm13
00007b78f51cff74  vmovaps [rsp+0x20], xmm7
00007b78f51cff7a  vmovaps xmm13, [rsp+0x20]
00007b78f51cff80  por xmm7, xmm13
00007b78f51cff85  movaps [r15+0x2A0], xmm7
00007b78f51cff8d  vmovaps [rsp+0x20], xmm3
00007b78f51cff93  vmovaps xmm13, [rsp+0x20]
00007b78f51cff99  por xmm3, xmm13
00007b78f51cff9e  movaps [r15+0x1D0], xmm3
00007b78f51cffa6  lea rax, [r14+0x40]
00007b78f51cffaa  movups xmm13, [r13+rax*1]
00007b78f51cffb0  movaps [r15+0x2C0], xmm13
00007b78f51cffb8  vmovaps xmm10, [rsp+0x90]
00007b78f51cffc1  vpermilpd xmm10, xmm10, 0x00
00007b78f51cffc7  movaps xmm9, xmm8
00007b78f51cffcb  mulpd xmm9, xmm10
00007b78f51cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007b78f51cffd6  ptest xmm5, xmm5
00007b78f51cffdb  jnz 0x00007B78F51D3946
00007b78f51cffe1  movaps xmm10, xmm1
00007b78f51cffe5  addpd xmm10, xmm11
00007b78f51cffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007b78f51cfff0  ptest xmm8, xmm8
00007b78f51cfff6  jnz 0x00007B78F51D3A8A
00007b78f51cfffc  movaps xmm1, xmm14
00007b78f51d0000  addpd xmm1, xmm6
00007b78f51d0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007b78f51d0009  ptest xmm11, xmm11
00007b78f51d000f  jnz 0x00007B78F51D3BCD
00007b78f51d0015  vmovaps xmm14, [rsp+0x90]
00007b78f51d001e  vpermilpd xmm14, xmm14, 0x00
00007b78f51d0024  movaps xmm11, xmm13
00007b78f51d0028  mulpd xmm11, xmm14
00007b78f51d002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007b78f51d0033  ptest xmm8, xmm8
00007b78f51d0039  jnz 0x00007B78F51D3D0E
00007b78f51d003f  vmovaps xmm14, [rsp+0x90]
00007b78f51d0048  vpermilpd xmm14, xmm14, 0x00
00007b78f51d004e  vmovaps xmm8, [rsp+0x10]
00007b78f51d0054  movaps xmm13, xmm8
00007b78f51d0058  mulpd xmm13, xmm14
00007b78f51d005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007b78f51d0063  ptest xmm6, xmm6
00007b78f51d0068  jnz 0x00007B78F51D3E52
00007b78f51d006e  vmovaps xmm14, [rsp+0x60]
00007b78f51d0074  vpermilpd xmm14, xmm14, 0x00
00007b78f51d007a  movaps xmm8, xmm7
00007b78f51d007e  mulpd xmm8, xmm14
00007b78f51d0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007b78f51d0089  ptest xmm6, xmm6
00007b78f51d008e  jnz 0x00007B78F51D3F96
00007b78f51d0094  movaps xmm14, xmm12
00007b78f51d0098  addpd xmm14, xmm9
00007b78f51d009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007b78f51d00a3  ptest xmm7, xmm7
00007b78f51d00a8  jnz 0x00007B78F51D40D9
00007b78f51d00ae  vmovaps xmm12, [rsp+0x60]
00007b78f51d00b4  vpermilpd xmm12, xmm12, 0x00
00007b78f51d00ba  vmovaps xmm7, [rsp+0xF0]
00007b78f51d00c3  movaps xmm9, xmm7
00007b78f51d00c7  mulpd xmm9, xmm12
00007b78f51d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007b78f51d00d2  ptest xmm6, xmm6
00007b78f51d00d7  jnz 0x00007B78F51D421D
00007b78f51d00dd  movaps xmm12, xmm15
00007b78f51d00e1  addpd xmm12, xmm11
00007b78f51d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007b78f51d00ec  ptest xmm7, xmm7
00007b78f51d00f1  jnz 0x00007B78F51D4360
00007b78f51d00f7  vmovaps xmm15, [rsp+0x60]
00007b78f51d00fd  vpermilpd xmm15, xmm15, 0x00
00007b78f51d0103  vmovaps xmm7, [rsp+0x40]
00007b78f51d0109  movaps xmm11, xmm7
00007b78f51d010d  mulpd xmm11, xmm15
00007b78f51d0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007b78f51d0118  ptest xmm6, xmm6
00007b78f51d011d  jnz 0x00007B78F51D44A4
00007b78f51d0123  movaps xmm15, xmm10
00007b78f51d0127  addpd xmm15, xmm13
00007b78f51d012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007b78f51d0132  ptest xmm7, xmm7
00007b78f51d0137  jnz 0x00007B78F51D45E7
00007b78f51d013d  vmovaps xmm13, [rsp+0x60]
00007b78f51d0143  vpermilpd xmm13, xmm13, 0x00
00007b78f51d0149  vmovaps xmm7, [rsp+0x50]
00007b78f51d014f  movaps xmm10, xmm7
00007b78f51d0153  mulpd xmm10, xmm13
00007b78f51d0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007b78f51d015e  ptest xmm6, xmm6
00007b78f51d0163  jnz 0x00007B78F51D472B
00007b78f51d0169  movaps xmm13, xmm1
00007b78f51d016d  addpd xmm13, xmm8
00007b78f51d0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007b78f51d0178  ptest xmm7, xmm7
00007b78f51d017d  jnz 0x00007B78F51D486E
00007b78f51d0183  lea rax, [r14+0x70]
00007b78f51d0187  movups xmm1, [r13+rax*1]
00007b78f51d018d  movaps [r15+0x240], xmm1
00007b78f51d0195  movaps xmm8, xmm14
00007b78f51d0199  addpd xmm8, xmm9
00007b78f51d019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007b78f51d01a4  ptest xmm7, xmm7
00007b78f51d01a9  jnz 0x00007B78F51D49BB
00007b78f51d01af  movaps [r15+0x170], xmm8
00007b78f51d01b7  vmovaps xmm14, [rsp+0x70]
00007b78f51d01bd  vpermilpd xmm14, xmm14, 0x00
00007b78f51d01c3  movaps xmm9, xmm1
00007b78f51d01c7  mulpd xmm9, xmm14
00007b78f51d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007b78f51d01d2  ptest xmm7, xmm7
00007b78f51d01d7  jnz 0x00007B78F51D4AFF
00007b78f51d01dd  vmovaps xmm1, [rsp+0x70]
00007b78f51d01e3  vpermilpd xmm1, xmm1, 0x00
00007b78f51d01e9  movaps xmm14, xmm4
00007b78f51d01ed  mulpd xmm14, xmm1
00007b78f51d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007b78f51d01f8  ptest xmm7, xmm7
00007b78f51d01fd  jnz 0x00007B78F51D4C42
00007b78f51d0203  movaps [r15+0x180], xmm14
00007b78f51d020b  movaps xmm1, xmm12
00007b78f51d020f  addpd xmm1, xmm11
00007b78f51d0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007b78f51d0219  ptest xmm7, xmm7
00007b78f51d021e  jnz 0x00007B78F51D4D84
00007b78f51d0224  movaps [r15+0x210], xmm1
00007b78f51d022c  movups xmm12, [r13+r14*1]
00007b78f51d0232  lea rax, [r14+0x10]
00007b78f51d0236  movups xmm11, [r13+rax*1]
00007b78f51d023c  movaps [r15+0x230], xmm11
00007b78f51d0244  movaps xmm7, xmm15
00007b78f51d0248  addpd xmm7, xmm10
00007b78f51d024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007b78f51d0252  ptest xmm6, xmm6
00007b78f51d0257  jnz 0x00007B78F51D4EDA
00007b78f51d025d  movaps [r15+0x130], xmm7
00007b78f51d0265  vmovaps xmm15, [rsp+0x70]
00007b78f51d026b  vpermilpd xmm15, xmm15, 0x00
00007b78f51d0271  movaps xmm10, xmm11
00007b78f51d0275  mulpd xmm10, xmm15
00007b78f51d027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007b78f51d0280  ptest xmm6, xmm6
00007b78f51d0285  jnz 0x00007B78F51D501C
00007b78f51d028b  movaps [r15+0x220], xmm10
00007b78f51d0293  vmovaps xmm15, [rsp+0x70]
00007b78f51d0299  vpermilpd xmm15, xmm15, 0x00
00007b78f51d029f  movaps xmm11, xmm12
00007b78f51d02a3  mulpd xmm11, xmm15
00007b78f51d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007b78f51d02ae  ptest xmm6, xmm6
00007b78f51d02b3  jnz 0x00007B78F51D5160
00007b78f51d02b9  movaps xmm15, xmm13
00007b78f51d02bd  addpd xmm15, xmm9
00007b78f51d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007b78f51d02c8  ptest xmm12, xmm12
00007b78f51d02ce  jnz 0x00007B78F51D52A4
00007b78f51d02d4  movaps [r15+0x140], xmm15
00007b78f51d02dc  movaps xmm13, xmm8
00007b78f51d02e0  addpd xmm13, xmm14
00007b78f51d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007b78f51d02eb  ptest xmm12, xmm12
00007b78f51d02f1  jnz 0x00007B78F51D53E8
00007b78f51d02f7  movaps [r15+0x150], xmm13
00007b78f51d02ff  movaps xmm14, xmm1
00007b78f51d0303  addpd xmm14, xmm10
00007b78f51d0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007b78f51d030e  ptest xmm12, xmm12
00007b78f51d0314  jnz 0x00007B78F51D552C
00007b78f51d031a  movaps [r15+0x160], xmm14
00007b78f51d0322  movaps xmm1, xmm7
00007b78f51d0325  addpd xmm1, xmm11
00007b78f51d032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007b78f51d032f  ptest xmm12, xmm12
00007b78f51d0335  jnz 0x00007B78F51D566F
00007b78f51d033b  movaps [r15+0x120], xmm1
00007b78f51d0343  mov eax, 0x430920
00007b78f51d0348  movups [r13+rax*1], xmm15
00007b78f51d034e  mov eax, 0x430930
00007b78f51d0353  movups [r13+rax*1], xmm13
00007b78f51d0359  mov eax, 0x430940
00007b78f51d035e  movups [r13+rax*1], xmm14
00007b78f51d0364  mov eax, 0x430950
00007b78f51d0369  movups [r13+rax*1], xmm1
00007b78f51d036f  mov eax, [r15+0x108]
00007b78f51d0376  sahf
00007b78f51d0377  jnz 0x00007B78F51D03A9
00007b78f51d0379  cmp dword ptr [r15+0x318], 0x00
00007b78f51d0381  jz 0x00007B78F51DB900
00007b78f51d0387  nop [rax+rax*1], ax
00007b78f51d0390  nop [rax+rax*1], eax
00007b78f51d0398  mov eax, 0x410444
00007b78f51d039d  mov [r15+0x100], rax
00007b78f51d03a4  jmp 0x00007B78F4FFE110
00007b78f51d03a9  cmp dword ptr [r15+0x318], 0x00
00007b78f51d03b1  jz 0x00007B78F51D57E0
00007b78f51d03b7  nop [rax+rax*1], ax
00007b78f51d03c0  nop [rax+rax*1], eax
00007b78f51d03c8  mov eax, 0x410278
00007b78f51d03cd  mov [r15+0x100], rax
00007b78f51d03d4  jmp 0x00007B78F4FFE110
00007b78f51d03d9  int3
00007b78f51d03da  call 0x00007B78F50B52F0
00007b78f51d03df  jmp 0x00007B78F51CF016
00007b78f51d03e4  call 0x00007B78F50C4620
00007b78f51d03e9  jmp 0x00007B78F51CF023
00007b78f51d03ee  call 0x00007B78F50C33A0
00007b78f51d03f3  jmp 0x00007B78F51CF035
00007b78f51d03f8  call 0x00007B78F50C2120
00007b78f51d03fd  jmp 0x00007B78F51CF03F
00007b78f51d0402  call 0x00007B78F50C0860
00007b78f51d0407  jmp 0x00007B78F51CF067
00007b78f51d040c  call 0x00007B78F50BF5F0
00007b78f51d0411  jmp 0x00007B78F51CF073
00007b78f51d0416  call 0x00007B78F50C0860
00007b78f51d041b  jmp 0x00007B78F51CF0A5
00007b78f51d0420  call 0x00007B78F50BF5F0
00007b78f51d0425  jmp 0x00007B78F51CF0B1
00007b78f51d042a  call 0x00007B78F50C4740
00007b78f51d042f  jmp 0x00007B78F51CF0BE
00007b78f51d0434  call 0x00007B78F50B5400
00007b78f51d0439  jmp 0x00007B78F51CF0CB
00007b78f51d043e  call 0x00007B78F50B52F0
00007b78f51d0443  jmp 0x00007B78F51CF0D8
00007b78f51d0448  call 0x00007B78F50C4620
00007b78f51d044d  jmp 0x00007B78F51CF0E5
00007b78f51d0452  call 0x00007B78F50C0860
00007b78f51d0457  jmp 0x00007B78F51CF10D
00007b78f51d045c  call 0x00007B78F50BF5F0
00007b78f51d0461  jmp 0x00007B78F51CF119
00007b78f51d0466  call 0x00007B78F5009D70
00007b78f51d046b  jmp 0x00007B78F51CF11F
00007b78f51d0470  call 0x00007B78F50BE9C0
00007b78f51d0475  jmp 0x00007B78F51CF129
00007b78f51d047a  call 0x00007B78F50C0860
00007b78f51d047f  jmp 0x00007B78F51CF151
00007b78f51d0484  call 0x00007B78F50BF5F0
00007b78f51d0489  jmp 0x00007B78F51CF15D
00007b78f51d048e  call 0x00007B78F50BD750
00007b78f51d0493  jmp 0x00007B78F51CF16A
00007b78f51d0498  call 0x00007B78F50BC4E0
00007b78f51d049d  jmp 0x00007B78F51CF177
00007b78f51d04a2  call 0x00007B78F50C4740
00007b78f51d04a7  jmp 0x00007B78F51CF184
00007b78f51d04ac  call 0x00007B78F50B5400
00007b78f51d04b1  jmp 0x00007B78F51CF191
00007b78f51d04b6  call 0x00007B78F50B52F0
00007b78f51d04bb  jmp 0x00007B78F51CF19E
00007b78f51d04c0  call 0x00007B78F50C4620
00007b78f51d04c5  jmp 0x00007B78F51CF1AB
00007b78f51d04ca  call 0x00007B78F50C0860
00007b78f51d04cf  jmp 0x00007B78F51CF1BE
00007b78f51d04d4  call 0x00007B78F50BB270
00007b78f51d04d9  jmp 0x00007B78F51CF1CB
00007b78f51d04de  call 0x00007B78F50BA000
00007b78f51d04e3  jmp 0x00007B78F51CF1D8
00007b78f51d04e8  call 0x00007B78F50B8D90
00007b78f51d04ed  jmp 0x00007B78F51CF1E5
00007b78f51d04f2  call 0x00007B78F50B8A20
00007b78f51d04f7  jmp 0x00007B78F51CF1F2
00007b78f51d04fc  call 0x00007B78F50B5400
00007b78f51d0501  jmp 0x00007B78F51CF1FC
00007b78f51d0506  call 0x00007B78F50C2240
00007b78f51d050b  jmp 0x00007B78F51CF206
00007b78f51d0510  call 0x00007B78F50B52F0
00007b78f51d0515  jmp 0x00007B78F51CF210
00007b78f51d051a  call 0x00007B78F50C2120
00007b78f51d051f  jmp 0x00007B78F51CF21A
00007b78f51d0524  call 0x00007B78F50B77B0
00007b78f51d0529  jmp 0x00007B78F51CF224
00007b78f51d052e  call 0x00007B78F50B6550
00007b78f51d0533  jmp 0x00007B78F51CF22E
00007b78f51d0538  call 0x00007B78F50BFD50
00007b78f51d053d  jmp 0x00007B78F51CF240
00007b78f51d0542  call 0x00007B78F50B8EA0
00007b78f51d0547  jmp 0x00007B78F51CF24A
00007b78f51d054c  call 0x00007B78F50BFC30
00007b78f51d0551  jmp 0x00007B78F51CF257
00007b78f51d0556  call 0x00007B78F50B8D90
00007b78f51d055b  jmp 0x00007B78F51CF264
00007b78f51d0560  call 0x00007B78F50C2240
00007b78f51d0565  jmp 0x00007B78F51CF271
00007b78f51d056a  call 0x00007B78F50B5400
00007b78f51d056f  jmp 0x00007B78F51CF27E
00007b78f51d0574  call 0x00007B78F50B52F0
00007b78f51d0579  jmp 0x00007B78F51CF28B
00007b78f51d057e  call 0x00007B78F50C2120
00007b78f51d0583  jmp 0x00007B78F51CF298
00007b78f51d0588  call 0x00007B78F50B52F0
00007b78f51d058d  jmp 0x00007B78F51CF2AB
00007b78f51d0592  call 0x00007B78F50B52F0
00007b78f51d0597  jmp 0x00007B78F51CF2BE
00007b78f51d059c  call 0x00007B78F50B52F0
00007b78f51d05a1  jmp 0x00007B78F51CF2D1
00007b78f51d05a6  call 0x00007B78F50B52F0
00007b78f51d05ab  jmp 0x00007B78F51CF2E4
00007b78f51d05b0  call 0x00007B78F50C2240
00007b78f51d05b5  jmp 0x00007B78F51CF2F9
00007b78f51d05ba  call 0x00007B78F50C2240
00007b78f51d05bf  jmp 0x00007B78F51CF30C
00007b78f51d05c4  call 0x00007B78F50C2120
00007b78f51d05c9  jmp 0x00007B78F51CF319
00007b78f51d05ce  call 0x00007B78F50B52F0
00007b78f51d05d3  jmp 0x00007B78F51CF32C
00007b78f51d05d8  call 0x00007B78F50B52F0
00007b78f51d05dd  jmp 0x00007B78F51CF34F
00007b78f51d05e2  call 0x00007B78F50B52F0
00007b78f51d05e7  jmp 0x00007B78F51CF362
00007b78f51d05ec  call 0x00007B78F4FFF540
00007b78f51d05f1  jmp 0x00007B78F51CF380
00007b78f51d05f6  call 0x00007B78F5008C20
00007b78f51d05fb  jmp 0x00007B78F51CF38A
00007b78f51d0600  call 0x00007B78F50D6600
00007b78f51d0605  jmp 0x00007B78F51CF396
00007b78f51d060a  call 0x00007B78F4FFF540
00007b78f51d060f  jmp 0x00007B78F51CF3A6
00007b78f51d0614  call 0x00007B78F50C0370
00007b78f51d0619  jmp 0x00007B78F51CF3D4
00007b78f51d061e  call 0x00007B78F50BF100
00007b78f51d0623  jmp 0x00007B78F51CF3DD
00007b78f51d0628  call 0x00007B78F50C0370
00007b78f51d062d  jmp 0x00007B78F51CF43B
00007b78f51d0632  call 0x00007B78F50BF100
00007b78f51d0637  jmp 0x00007B78F51CF444
00007b78f51d063c  call 0x00007B78F50C0370
00007b78f51d0641  jmp 0x00007B78F51CF48B
00007b78f51d0646  call 0x00007B78F50BF100
00007b78f51d064b  jmp 0x00007B78F51CF494
00007b78f51d0650  call 0x00007B78F500B720
00007b78f51d0655  jmp 0x00007B78F51CF4D7
00007b78f51d065a  call 0x00007B78F50B47C0
00007b78f51d065f  jmp 0x00007B78F51CF4EA
00007b78f51d0664  call 0x00007B78F5008B00
00007b78f51d0669  jmp 0x00007B78F51CF501
00007b78f51d066e  call 0x00007B78F4FFF430
00007b78f51d0673  jmp 0x00007B78F51CF514
00007b78f51d0678  call 0x00007B78F4FFF430
00007b78f51d067d  jmp 0x00007B78F51CF527
00007b78f51d0682  sub rsp, 0x08
00007b78f51d0686  push rax
00007b78f51d0687  push rcx
00007b78f51d0688  push rdx
00007b78f51d0689  push rdi
00007b78f51d068a  push rsi
00007b78f51d068b  push r8
00007b78f51d068d  push r9
00007b78f51d068f  push r10
00007b78f51d0691  push r11
00007b78f51d0693  sub rsp, 0xF0
00007b78f51d069a  vmovaps [rsp], xmm0
00007b78f51d069f  vmovaps [rsp+0x10], xmm2
00007b78f51d06a5  vmovaps [rsp+0x20], xmm3
00007b78f51d06ab  vmovaps [rsp+0x30], xmm4
00007b78f51d06b1  vmovaps [rsp+0x40], xmm5
00007b78f51d06b7  vmovaps [rsp+0x50], xmm6
00007b78f51d06bd  vmovaps [rsp+0x60], xmm7
00007b78f51d06c3  vmovaps [rsp+0x70], xmm8
00007b78f51d06c9  vmovaps [rsp+0x80], xmm9
00007b78f51d06d2  vmovaps [rsp+0x90], xmm10
00007b78f51d06db  vmovaps [rsp+0xA0], xmm11
00007b78f51d06e4  vmovaps [rsp+0xB0], xmm12
00007b78f51d06ed  vmovaps [rsp+0xC0], xmm13
00007b78f51d06f6  vmovaps [rsp+0xD0], xmm14
00007b78f51d06ff  vmovaps [rsp+0xE0], xmm15
00007b78f51d0708  sub rsp, 0x30
00007b78f51d070c  movaps [rsp], xmm1
00007b78f51d0710  movaps [rsp+0x10], xmm15
00007b78f51d0716  movaps [rsp+0x20], xmm14
00007b78f51d071c  lea rdi, [rsp]
00007b78f51d0720  mov esi, 0x00
00007b78f51d0725  mov rax, 0x597478C09530
00007b78f51d072f  call rax
00007b78f51d0731  movaps xmm1, [rsp]
00007b78f51d0735  add rsp, 0x30
00007b78f51d0739  vmovaps xmm0, [rsp]
00007b78f51d073e  vmovaps xmm2, [rsp+0x10]
00007b78f51d0744  vmovaps xmm3, [rsp+0x20]
00007b78f51d074a  vmovaps xmm4, [rsp+0x30]
00007b78f51d0750  vmovaps xmm5, [rsp+0x40]
00007b78f51d0756  vmovaps xmm6, [rsp+0x50]
00007b78f51d075c  vmovaps xmm7, [rsp+0x60]
00007b78f51d0762  vmovaps xmm8, [rsp+0x70]
00007b78f51d0768  vmovaps xmm9, [rsp+0x80]
00007b78f51d0771  vmovaps xmm10, [rsp+0x90]
00007b78f51d077a  vmovaps xmm11, [rsp+0xA0]
00007b78f51d0783  vmovaps xmm12, [rsp+0xB0]
00007b78f51d078c  vmovaps xmm13, [rsp+0xC0]
00007b78f51d0795  vmovaps xmm14, [rsp+0xD0]
00007b78f51d079e  vmovaps xmm15, [rsp+0xE0]
00007b78f51d07a7  add rsp, 0xF0
00007b78f51d07ae  pop r11
00007b78f51d07b0  pop r10
00007b78f51d07b2  pop r9
00007b78f51d07b4  pop r8
00007b78f51d07b6  pop rsi
00007b78f51d07b7  pop rdi
00007b78f51d07b8  pop rdx
00007b78f51d07b9  pop rcx
00007b78f51d07ba  pop rax
00007b78f51d07bb  add rsp, 0x08
00007b78f51d07bf  jmp 0x00007B78F51CF581
00007b78f51d07c4  sub rsp, 0x08
00007b78f51d07c8  push rax
00007b78f51d07c9  push rcx
00007b78f51d07ca  push rdx
00007b78f51d07cb  push rdi
00007b78f51d07cc  push rsi
00007b78f51d07cd  push r8
00007b78f51d07cf  push r9
00007b78f51d07d1  push r10
00007b78f51d07d3  push r11
00007b78f51d07d5  sub rsp, 0xF0
00007b78f51d07dc  vmovaps [rsp], xmm0
00007b78f51d07e1  vmovaps [rsp+0x10], xmm1
00007b78f51d07e7  vmovaps [rsp+0x20], xmm2
00007b78f51d07ed  vmovaps [rsp+0x30], xmm3
00007b78f51d07f3  vmovaps [rsp+0x40], xmm4
00007b78f51d07f9  vmovaps [rsp+0x50], xmm5
00007b78f51d07ff  vmovaps [rsp+0x60], xmm6
00007b78f51d0805  vmovaps [rsp+0x70], xmm7
00007b78f51d080b  vmovaps [rsp+0x80], xmm8
00007b78f51d0814  vmovaps [rsp+0x90], xmm9
00007b78f51d081d  vmovaps [rsp+0xA0], xmm10
00007b78f51d0826  vmovaps [rsp+0xB0], xmm11
00007b78f51d082f  vmovaps [rsp+0xC0], xmm12
00007b78f51d0838  vmovaps [rsp+0xD0], xmm14
00007b78f51d0841  vmovaps [rsp+0xE0], xmm15
00007b78f51d084a  sub rsp, 0x30
00007b78f51d084e  movaps [rsp], xmm13
00007b78f51d0853  movaps [rsp+0x10], xmm1
00007b78f51d0858  movaps [rsp+0x20], xmm14
00007b78f51d085e  lea rdi, [rsp]
00007b78f51d0862  mov esi, 0x00
00007b78f51d0867  mov rax, 0x597478C09530
00007b78f51d0871  call rax
00007b78f51d0873  movaps xmm13, [rsp]
00007b78f51d0878  add rsp, 0x30
00007b78f51d087c  vmovaps xmm0, [rsp]
00007b78f51d0881  vmovaps xmm1, [rsp+0x10]
00007b78f51d0887  vmovaps xmm2, [rsp+0x20]
00007b78f51d088d  vmovaps xmm3, [rsp+0x30]
00007b78f51d0893  vmovaps xmm4, [rsp+0x40]
00007b78f51d0899  vmovaps xmm5, [rsp+0x50]
00007b78f51d089f  vmovaps xmm6, [rsp+0x60]
00007b78f51d08a5  vmovaps xmm7, [rsp+0x70]
00007b78f51d08ab  vmovaps xmm8, [rsp+0x80]
00007b78f51d08b4  vmovaps xmm9, [rsp+0x90]
00007b78f51d08bd  vmovaps xmm10, [rsp+0xA0]
00007b78f51d08c6  vmovaps xmm11, [rsp+0xB0]
00007b78f51d08cf  vmovaps xmm12, [rsp+0xC0]
00007b78f51d08d8  vmovaps xmm14, [rsp+0xD0]
00007b78f51d08e1  vmovaps xmm15, [rsp+0xE0]
00007b78f51d08ea  add rsp, 0xF0
00007b78f51d08f1  pop r11
00007b78f51d08f3  pop r10
00007b78f51d08f5  pop r9
00007b78f51d08f7  pop r8
00007b78f51d08f9  pop rsi
00007b78f51d08fa  pop rdi
00007b78f51d08fb  pop rdx
00007b78f51d08fc  pop rcx
00007b78f51d08fd  pop rax
00007b78f51d08fe  add rsp, 0x08
00007b78f51d0902  jmp 0x00007B78F51CF5CF
00007b78f51d0907  sub rsp, 0x08
00007b78f51d090b  push rax
00007b78f51d090c  push rcx
00007b78f51d090d  push rdx
00007b78f51d090e  push rdi
00007b78f51d090f  push rsi
00007b78f51d0910  push r8
00007b78f51d0912  push r9
00007b78f51d0914  push r10
00007b78f51d0916  push r11
00007b78f51d0918  sub rsp, 0xF0
00007b78f51d091f  vmovaps [rsp], xmm0
00007b78f51d0924  vmovaps [rsp+0x10], xmm1
00007b78f51d092a  vmovaps [rsp+0x20], xmm2
00007b78f51d0930  vmovaps [rsp+0x30], xmm3
00007b78f51d0936  vmovaps [rsp+0x40], xmm4
00007b78f51d093c  vmovaps [rsp+0x50], xmm5
00007b78f51d0942  vmovaps [rsp+0x60], xmm6
00007b78f51d0948  vmovaps [rsp+0x70], xmm7
00007b78f51d094e  vmovaps [rsp+0x80], xmm8
00007b78f51d0957  vmovaps [rsp+0x90], xmm9
00007b78f51d0960  vmovaps [rsp+0xA0], xmm10
00007b78f51d0969  vmovaps [rsp+0xB0], xmm11
00007b78f51d0972  vmovaps [rsp+0xC0], xmm12
00007b78f51d097b  vmovaps [rsp+0xD0], xmm13
00007b78f51d0984  vmovaps [rsp+0xE0], xmm14
00007b78f51d098d  sub rsp, 0x30
00007b78f51d0991  movaps [rsp], xmm15
00007b78f51d0996  movaps [rsp+0x10], xmm14
00007b78f51d099c  movaps [rsp+0x20], xmm1
00007b78f51d09a1  lea rdi, [rsp]
00007b78f51d09a5  mov esi, 0x00
00007b78f51d09aa  mov rax, 0x597478C09530
00007b78f51d09b4  call rax
00007b78f51d09b6  movaps xmm15, [rsp]
00007b78f51d09bb  add rsp, 0x30
00007b78f51d09bf  vmovaps xmm0, [rsp]
00007b78f51d09c4  vmovaps xmm1, [rsp+0x10]
00007b78f51d09ca  vmovaps xmm2, [rsp+0x20]
00007b78f51d09d0  vmovaps xmm3, [rsp+0x30]
00007b78f51d09d6  vmovaps xmm4, [rsp+0x40]
00007b78f51d09dc  vmovaps xmm5, [rsp+0x50]
00007b78f51d09e2  vmovaps xmm6, [rsp+0x60]
00007b78f51d09e8  vmovaps xmm7, [rsp+0x70]
00007b78f51d09ee  vmovaps xmm8, [rsp+0x80]
00007b78f51d09f7  vmovaps xmm9, [rsp+0x90]
00007b78f51d0a00  vmovaps xmm10, [rsp+0xA0]
00007b78f51d0a09  vmovaps xmm11, [rsp+0xB0]
00007b78f51d0a12  vmovaps xmm12, [rsp+0xC0]
00007b78f51d0a1b  vmovaps xmm13, [rsp+0xD0]
00007b78f51d0a24  vmovaps xmm14, [rsp+0xE0]
00007b78f51d0a2d  add rsp, 0xF0
00007b78f51d0a34  pop r11
00007b78f51d0a36  pop r10
00007b78f51d0a38  pop r9
00007b78f51d0a3a  pop r8
00007b78f51d0a3c  pop rsi
00007b78f51d0a3d  pop rdi
00007b78f51d0a3e  pop rdx
00007b78f51d0a3f  pop rcx
00007b78f51d0a40  pop rax
00007b78f51d0a41  add rsp, 0x08
00007b78f51d0a45  jmp 0x00007B78F51CF617
00007b78f51d0a4a  sub rsp, 0x08
00007b78f51d0a4e  push rax
00007b78f51d0a4f  push rcx
00007b78f51d0a50  push rdx
00007b78f51d0a51  push rdi
00007b78f51d0a52  push rsi
00007b78f51d0a53  push r8
00007b78f51d0a55  push r9
00007b78f51d0a57  push r10
00007b78f51d0a59  push r11
00007b78f51d0a5b  sub rsp, 0xF0
00007b78f51d0a62  vmovaps [rsp], xmm0
00007b78f51d0a67  vmovaps [rsp+0x10], xmm2
00007b78f51d0a6d  vmovaps [rsp+0x20], xmm3
00007b78f51d0a73  vmovaps [rsp+0x30], xmm4
00007b78f51d0a79  vmovaps [rsp+0x40], xmm5
00007b78f51d0a7f  vmovaps [rsp+0x50], xmm6
00007b78f51d0a85  vmovaps [rsp+0x60], xmm7
00007b78f51d0a8b  vmovaps [rsp+0x70], xmm8
00007b78f51d0a91  vmovaps [rsp+0x80], xmm9
00007b78f51d0a9a  vmovaps [rsp+0x90], xmm10
00007b78f51d0aa3  vmovaps [rsp+0xA0], xmm11
00007b78f51d0aac  vmovaps [rsp+0xB0], xmm12
00007b78f51d0ab5  vmovaps [rsp+0xC0], xmm13
00007b78f51d0abe  vmovaps [rsp+0xD0], xmm14
00007b78f51d0ac7  vmovaps [rsp+0xE0], xmm15
00007b78f51d0ad0  sub rsp, 0x30
00007b78f51d0ad4  movaps [rsp], xmm1
00007b78f51d0ad8  movaps [rsp+0x10], xmm14
00007b78f51d0ade  movaps [rsp+0x20], xmm10
00007b78f51d0ae4  lea rdi, [rsp]
00007b78f51d0ae8  mov esi, 0x00
00007b78f51d0aed  mov rax, 0x597478C09530
00007b78f51d0af7  call rax
00007b78f51d0af9  movaps xmm1, [rsp]
00007b78f51d0afd  add rsp, 0x30
00007b78f51d0b01  vmovaps xmm0, [rsp]
00007b78f51d0b06  vmovaps xmm2, [rsp+0x10]
00007b78f51d0b0c  vmovaps xmm3, [rsp+0x20]
00007b78f51d0b12  vmovaps xmm4, [rsp+0x30]
00007b78f51d0b18  vmovaps xmm5, [rsp+0x40]
00007b78f51d0b1e  vmovaps xmm6, [rsp+0x50]
00007b78f51d0b24  vmovaps xmm7, [rsp+0x60]
00007b78f51d0b2a  vmovaps xmm8, [rsp+0x70]
00007b78f51d0b30  vmovaps xmm9, [rsp+0x80]
00007b78f51d0b39  vmovaps xmm10, [rsp+0x90]
00007b78f51d0b42  vmovaps xmm11, [rsp+0xA0]
00007b78f51d0b4b  vmovaps xmm12, [rsp+0xB0]
00007b78f51d0b54  vmovaps xmm13, [rsp+0xC0]
00007b78f51d0b5d  vmovaps xmm14, [rsp+0xD0]
00007b78f51d0b66  vmovaps xmm15, [rsp+0xE0]
00007b78f51d0b6f  add rsp, 0xF0
00007b78f51d0b76  pop r11
00007b78f51d0b78  pop r10
00007b78f51d0b7a  pop r9
00007b78f51d0b7c  pop r8
00007b78f51d0b7e  pop rsi
00007b78f51d0b7f  pop rdi
00007b78f51d0b80  pop rdx
00007b78f51d0b81  pop rcx
00007b78f51d0b82  pop rax
00007b78f51d0b83  add rsp, 0x08
00007b78f51d0b87  jmp 0x00007B78F51CF631
00007b78f51d0b8c  sub rsp, 0x08
00007b78f51d0b90  push rax
00007b78f51d0b91  push rcx
00007b78f51d0b92  push rdx
00007b78f51d0b93  push rdi
00007b78f51d0b94  push rsi
00007b78f51d0b95  push r8
00007b78f51d0b97  push r9
00007b78f51d0b99  push r10
00007b78f51d0b9b  push r11
00007b78f51d0b9d  sub rsp, 0xF0
00007b78f51d0ba4  vmovaps [rsp], xmm0
00007b78f51d0ba9  vmovaps [rsp+0x10], xmm1
00007b78f51d0baf  vmovaps [rsp+0x20], xmm2
00007b78f51d0bb5  vmovaps [rsp+0x30], xmm3
00007b78f51d0bbb  vmovaps [rsp+0x40], xmm4
00007b78f51d0bc1  vmovaps [rsp+0x50], xmm5
00007b78f51d0bc7  vmovaps [rsp+0x60], xmm6
00007b78f51d0bcd  vmovaps [rsp+0x70], xmm7
00007b78f51d0bd3  vmovaps [rsp+0x80], xmm8
00007b78f51d0bdc  vmovaps [rsp+0x90], xmm9
00007b78f51d0be5  vmovaps [rsp+0xA0], xmm10
00007b78f51d0bee  vmovaps [rsp+0xB0], xmm11
00007b78f51d0bf7  vmovaps [rsp+0xC0], xmm12
00007b78f51d0c00  vmovaps [rsp+0xD0], xmm14
00007b78f51d0c09  vmovaps [rsp+0xE0], xmm15
00007b78f51d0c12  sub rsp, 0x30
00007b78f51d0c16  movaps [rsp], xmm13
00007b78f51d0c1b  movaps [rsp+0x10], xmm14
00007b78f51d0c21  movaps [rsp+0x20], xmm2
00007b78f51d0c26  lea rdi, [rsp]
00007b78f51d0c2a  mov esi, 0x00
00007b78f51d0c2f  mov rax, 0x597478C09530
00007b78f51d0c39  call rax
00007b78f51d0c3b  movaps xmm13, [rsp]
00007b78f51d0c40  add rsp, 0x30
00007b78f51d0c44  vmovaps xmm0, [rsp]
00007b78f51d0c49  vmovaps xmm1, [rsp+0x10]
00007b78f51d0c4f  vmovaps xmm2, [rsp+0x20]
00007b78f51d0c55  vmovaps xmm3, [rsp+0x30]
00007b78f51d0c5b  vmovaps xmm4, [rsp+0x40]
00007b78f51d0c61  vmovaps xmm5, [rsp+0x50]
00007b78f51d0c67  vmovaps xmm6, [rsp+0x60]
00007b78f51d0c6d  vmovaps xmm7, [rsp+0x70]
00007b78f51d0c73  vmovaps xmm8, [rsp+0x80]
00007b78f51d0c7c  vmovaps xmm9, [rsp+0x90]
00007b78f51d0c85  vmovaps xmm10, [rsp+0xA0]
00007b78f51d0c8e  vmovaps xmm11, [rsp+0xB0]
00007b78f51d0c97  vmovaps xmm12, [rsp+0xC0]
00007b78f51d0ca0  vmovaps xmm14, [rsp+0xD0]
00007b78f51d0ca9  vmovaps xmm15, [rsp+0xE0]
00007b78f51d0cb2  add rsp, 0xF0
00007b78f51d0cb9  pop r11
00007b78f51d0cbb  pop r10
00007b78f51d0cbd  pop r9
00007b78f51d0cbf  pop r8
00007b78f51d0cc1  pop rsi
00007b78f51d0cc2  pop rdi
00007b78f51d0cc3  pop rdx
00007b78f51d0cc4  pop rcx
00007b78f51d0cc5  pop rax
00007b78f51d0cc6  add rsp, 0x08
00007b78f51d0cca  jmp 0x00007B78F51CF64C
00007b78f51d0ccf  sub rsp, 0x08
00007b78f51d0cd3  push rax
00007b78f51d0cd4  push rcx
00007b78f51d0cd5  push rdx
00007b78f51d0cd6  push rdi
00007b78f51d0cd7  push rsi
00007b78f51d0cd8  push r8
00007b78f51d0cda  push r9
00007b78f51d0cdc  push r10
00007b78f51d0cde  push r11
00007b78f51d0ce0  sub rsp, 0xF0
00007b78f51d0ce7  vmovaps [rsp], xmm0
00007b78f51d0cec  vmovaps [rsp+0x10], xmm2
00007b78f51d0cf2  vmovaps [rsp+0x20], xmm3
00007b78f51d0cf8  vmovaps [rsp+0x30], xmm4
00007b78f51d0cfe  vmovaps [rsp+0x40], xmm5
00007b78f51d0d04  vmovaps [rsp+0x50], xmm6
00007b78f51d0d0a  vmovaps [rsp+0x60], xmm7
00007b78f51d0d10  vmovaps [rsp+0x70], xmm8
00007b78f51d0d16  vmovaps [rsp+0x80], xmm9
00007b78f51d0d1f  vmovaps [rsp+0x90], xmm10
00007b78f51d0d28  vmovaps [rsp+0xA0], xmm11
00007b78f51d0d31  vmovaps [rsp+0xB0], xmm12
00007b78f51d0d3a  vmovaps [rsp+0xC0], xmm13
00007b78f51d0d43  vmovaps [rsp+0xD0], xmm14
00007b78f51d0d4c  vmovaps [rsp+0xE0], xmm15
00007b78f51d0d55  sub rsp, 0x30
00007b78f51d0d59  movaps [rsp], xmm1
00007b78f51d0d5d  movaps [rsp+0x10], xmm10
00007b78f51d0d63  movaps [rsp+0x20], xmm2
00007b78f51d0d68  lea rdi, [rsp]
00007b78f51d0d6c  mov esi, 0x00
00007b78f51d0d71  mov rax, 0x597478C09530
00007b78f51d0d7b  call rax
00007b78f51d0d7d  movaps xmm1, [rsp]
00007b78f51d0d81  add rsp, 0x30
00007b78f51d0d85  vmovaps xmm0, [rsp]
00007b78f51d0d8a  vmovaps xmm2, [rsp+0x10]
00007b78f51d0d90  vmovaps xmm3, [rsp+0x20]
00007b78f51d0d96  vmovaps xmm4, [rsp+0x30]
00007b78f51d0d9c  vmovaps xmm5, [rsp+0x40]
00007b78f51d0da2  vmovaps xmm6, [rsp+0x50]
00007b78f51d0da8  vmovaps xmm7, [rsp+0x60]
00007b78f51d0dae  vmovaps xmm8, [rsp+0x70]
00007b78f51d0db4  vmovaps xmm9, [rsp+0x80]
00007b78f51d0dbd  vmovaps xmm10, [rsp+0x90]
00007b78f51d0dc6  vmovaps xmm11, [rsp+0xA0]
00007b78f51d0dcf  vmovaps xmm12, [rsp+0xB0]
00007b78f51d0dd8  vmovaps xmm13, [rsp+0xC0]
00007b78f51d0de1  vmovaps xmm14, [rsp+0xD0]
00007b78f51d0dea  vmovaps xmm15, [rsp+0xE0]
00007b78f51d0df3  add rsp, 0xF0
00007b78f51d0dfa  pop r11
00007b78f51d0dfc  pop r10
00007b78f51d0dfe  pop r9
00007b78f51d0e00  pop r8
00007b78f51d0e02  pop rsi
00007b78f51d0e03  pop rdi
00007b78f51d0e04  pop rdx
00007b78f51d0e05  pop rcx
00007b78f51d0e06  pop rax
00007b78f51d0e07  add rsp, 0x08
00007b78f51d0e0b  jmp 0x00007B78F51CF6B4
00007b78f51d0e10  sub rsp, 0x08
00007b78f51d0e14  push rax
00007b78f51d0e15  push rcx
00007b78f51d0e16  push rdx
00007b78f51d0e17  push rdi
00007b78f51d0e18  push rsi
00007b78f51d0e19  push r8
00007b78f51d0e1b  push r9
00007b78f51d0e1d  push r10
00007b78f51d0e1f  push r11
00007b78f51d0e21  sub rsp, 0xF0
00007b78f51d0e28  vmovaps [rsp], xmm0
00007b78f51d0e2d  vmovaps [rsp+0x10], xmm1
00007b78f51d0e33  vmovaps [rsp+0x20], xmm2
00007b78f51d0e39  vmovaps [rsp+0x30], xmm3
00007b78f51d0e3f  vmovaps [rsp+0x40], xmm4
00007b78f51d0e45  vmovaps [rsp+0x50], xmm5
00007b78f51d0e4b  vmovaps [rsp+0x60], xmm6
00007b78f51d0e51  vmovaps [rsp+0x70], xmm7
00007b78f51d0e57  vmovaps [rsp+0x80], xmm8
00007b78f51d0e60  vmovaps [rsp+0x90], xmm9
00007b78f51d0e69  vmovaps [rsp+0xA0], xmm10
00007b78f51d0e72  vmovaps [rsp+0xB0], xmm11
00007b78f51d0e7b  vmovaps [rsp+0xC0], xmm12
00007b78f51d0e84  vmovaps [rsp+0xD0], xmm13
00007b78f51d0e8d  vmovaps [rsp+0xE0], xmm14
00007b78f51d0e96  sub rsp, 0x30
00007b78f51d0e9a  movaps [rsp], xmm15
00007b78f51d0e9f  movaps [rsp+0x10], xmm10
00007b78f51d0ea5  movaps [rsp+0x20], xmm2
00007b78f51d0eaa  lea rdi, [rsp]
00007b78f51d0eae  mov esi, 0x00
00007b78f51d0eb3  mov rax, 0x597478C09530
00007b78f51d0ebd  call rax
00007b78f51d0ebf  movaps xmm15, [rsp]
00007b78f51d0ec4  add rsp, 0x30
00007b78f51d0ec8  vmovaps xmm0, [rsp]
00007b78f51d0ecd  vmovaps xmm1, [rsp+0x10]
00007b78f51d0ed3  vmovaps xmm2, [rsp+0x20]
00007b78f51d0ed9  vmovaps xmm3, [rsp+0x30]
00007b78f51d0edf  vmovaps xmm4, [rsp+0x40]
00007b78f51d0ee5  vmovaps xmm5, [rsp+0x50]
00007b78f51d0eeb  vmovaps xmm6, [rsp+0x60]
00007b78f51d0ef1  vmovaps xmm7, [rsp+0x70]
00007b78f51d0ef7  vmovaps xmm8, [rsp+0x80]
00007b78f51d0f00  vmovaps xmm9, [rsp+0x90]
00007b78f51d0f09  vmovaps xmm10, [rsp+0xA0]
00007b78f51d0f12  vmovaps xmm11, [rsp+0xB0]
00007b78f51d0f1b  vmovaps xmm12, [rsp+0xC0]
00007b78f51d0f24  vmovaps xmm13, [rsp+0xD0]
00007b78f51d0f2d  vmovaps xmm14, [rsp+0xE0]
00007b78f51d0f36  add rsp, 0xF0
00007b78f51d0f3d  pop r11
00007b78f51d0f3f  pop r10
00007b78f51d0f41  pop r9
00007b78f51d0f43  pop r8
00007b78f51d0f45  pop rsi
00007b78f51d0f46  pop rdi
00007b78f51d0f47  pop rdx
00007b78f51d0f48  pop rcx
00007b78f51d0f49  pop rax
00007b78f51d0f4a  add rsp, 0x08
00007b78f51d0f4e  jmp 0x00007B78F51CF706
00007b78f51d0f53  sub rsp, 0x08
00007b78f51d0f57  push rax
00007b78f51d0f58  push rcx
00007b78f51d0f59  push rdx
00007b78f51d0f5a  push rdi
00007b78f51d0f5b  push rsi
00007b78f51d0f5c  push r8
00007b78f51d0f5e  push r9
00007b78f51d0f60  push r10
00007b78f51d0f62  push r11
00007b78f51d0f64  sub rsp, 0xF0
00007b78f51d0f6b  vmovaps [rsp], xmm0
00007b78f51d0f70  vmovaps [rsp+0x10], xmm2
00007b78f51d0f76  vmovaps [rsp+0x20], xmm3
00007b78f51d0f7c  vmovaps [rsp+0x30], xmm4
00007b78f51d0f82  vmovaps [rsp+0x40], xmm5
00007b78f51d0f88  vmovaps [rsp+0x50], xmm6
00007b78f51d0f8e  vmovaps [rsp+0x60], xmm7
00007b78f51d0f94  vmovaps [rsp+0x70], xmm8
00007b78f51d0f9a  vmovaps [rsp+0x80], xmm9
00007b78f51d0fa3  vmovaps [rsp+0x90], xmm10
00007b78f51d0fac  vmovaps [rsp+0xA0], xmm11
00007b78f51d0fb5  vmovaps [rsp+0xB0], xmm12
00007b78f51d0fbe  vmovaps [rsp+0xC0], xmm13
00007b78f51d0fc7  vmovaps [rsp+0xD0], xmm14
00007b78f51d0fd0  vmovaps [rsp+0xE0], xmm15
00007b78f51d0fd9  sub rsp, 0x30
00007b78f51d0fdd  movaps [rsp], xmm1
00007b78f51d0fe1  movaps [rsp+0x10], xmm10
00007b78f51d0fe7  movaps [rsp+0x20], xmm12
00007b78f51d0fed  lea rdi, [rsp]
00007b78f51d0ff1  mov esi, 0x00
00007b78f51d0ff6  mov rax, 0x597478C09530
00007b78f51d1000  call rax
00007b78f51d1002  movaps xmm1, [rsp]
00007b78f51d1006  add rsp, 0x30
00007b78f51d100a  vmovaps xmm0, [rsp]
00007b78f51d100f  vmovaps xmm2, [rsp+0x10]
00007b78f51d1015  vmovaps xmm3, [rsp+0x20]
00007b78f51d101b  vmovaps xmm4, [rsp+0x30]
00007b78f51d1021  vmovaps xmm5, [rsp+0x40]
00007b78f51d1027  vmovaps xmm6, [rsp+0x50]
00007b78f51d102d  vmovaps xmm7, [rsp+0x60]
00007b78f51d1033  vmovaps xmm8, [rsp+0x70]
00007b78f51d1039  vmovaps xmm9, [rsp+0x80]
00007b78f51d1042  vmovaps xmm10, [rsp+0x90]
00007b78f51d104b  vmovaps xmm11, [rsp+0xA0]
00007b78f51d1054  vmovaps xmm12, [rsp+0xB0]
00007b78f51d105d  vmovaps xmm13, [rsp+0xC0]
00007b78f51d1066  vmovaps xmm14, [rsp+0xD0]
00007b78f51d106f  vmovaps xmm15, [rsp+0xE0]
00007b78f51d1078  add rsp, 0xF0
00007b78f51d107f  pop r11
00007b78f51d1081  pop r10
00007b78f51d1083  pop r9
00007b78f51d1085  pop r8
00007b78f51d1087  pop rsi
00007b78f51d1088  pop rdi
00007b78f51d1089  pop rdx
00007b78f51d108a  pop rcx
00007b78f51d108b  pop rax
00007b78f51d108c  add rsp, 0x08
00007b78f51d1090  jmp 0x00007B78F51CF732
00007b78f51d1095  sub rsp, 0x08
00007b78f51d1099  push rax
00007b78f51d109a  push rcx
00007b78f51d109b  push rdx
00007b78f51d109c  push rdi
00007b78f51d109d  push rsi
00007b78f51d109e  push r8
00007b78f51d10a0  push r9
00007b78f51d10a2  push r10
00007b78f51d10a4  push r11
00007b78f51d10a6  sub rsp, 0xF0
00007b78f51d10ad  vmovaps [rsp], xmm0
00007b78f51d10b2  vmovaps [rsp+0x10], xmm1
00007b78f51d10b8  vmovaps [rsp+0x20], xmm2
00007b78f51d10be  vmovaps [rsp+0x30], xmm3
00007b78f51d10c4  vmovaps [rsp+0x40], xmm4
00007b78f51d10ca  vmovaps [rsp+0x50], xmm5
00007b78f51d10d0  vmovaps [rsp+0x60], xmm6
00007b78f51d10d6  vmovaps [rsp+0x70], xmm7
00007b78f51d10dc  vmovaps [rsp+0x80], xmm8
00007b78f51d10e5  vmovaps [rsp+0x90], xmm9
00007b78f51d10ee  vmovaps [rsp+0xA0], xmm10
00007b78f51d10f7  vmovaps [rsp+0xB0], xmm11
00007b78f51d1100  vmovaps [rsp+0xC0], xmm12
00007b78f51d1109  vmovaps [rsp+0xD0], xmm13
00007b78f51d1112  vmovaps [rsp+0xE0], xmm14
00007b78f51d111b  sub rsp, 0x30
00007b78f51d111f  movaps [rsp], xmm15
00007b78f51d1124  movaps [rsp+0x10], xmm10
00007b78f51d112a  movaps [rsp+0x20], xmm12
00007b78f51d1130  lea rdi, [rsp]
00007b78f51d1134  mov esi, 0x00
00007b78f51d1139  mov rax, 0x597478C09530
00007b78f51d1143  call rax
00007b78f51d1145  movaps xmm15, [rsp]
00007b78f51d114a  add rsp, 0x30
00007b78f51d114e  vmovaps xmm0, [rsp]
00007b78f51d1153  vmovaps xmm1, [rsp+0x10]
00007b78f51d1159  vmovaps xmm2, [rsp+0x20]
00007b78f51d115f  vmovaps xmm3, [rsp+0x30]
00007b78f51d1165  vmovaps xmm4, [rsp+0x40]
00007b78f51d116b  vmovaps xmm5, [rsp+0x50]
00007b78f51d1171  vmovaps xmm6, [rsp+0x60]
00007b78f51d1177  vmovaps xmm7, [rsp+0x70]
00007b78f51d117d  vmovaps xmm8, [rsp+0x80]
00007b78f51d1186  vmovaps xmm9, [rsp+0x90]
00007b78f51d118f  vmovaps xmm10, [rsp+0xA0]
00007b78f51d1198  vmovaps xmm11, [rsp+0xB0]
00007b78f51d11a1  vmovaps xmm12, [rsp+0xC0]
00007b78f51d11aa  vmovaps xmm13, [rsp+0xD0]
00007b78f51d11b3  vmovaps xmm14, [rsp+0xE0]
00007b78f51d11bc  add rsp, 0xF0
00007b78f51d11c3  pop r11
00007b78f51d11c5  pop r10
00007b78f51d11c7  pop r9
00007b78f51d11c9  pop r8
00007b78f51d11cb  pop rsi
00007b78f51d11cc  pop rdi
00007b78f51d11cd  pop rdx
00007b78f51d11ce  pop rcx
00007b78f51d11cf  pop rax
00007b78f51d11d0  add rsp, 0x08
00007b78f51d11d4  jmp 0x00007B78F51CF75E
00007b78f51d11d9  call 0x00007B78F4FFF430
00007b78f51d11de  jmp 0x00007B78F51CF7EE
00007b78f51d11e3  call 0x00007B78F4FFF430
00007b78f51d11e8  jmp 0x00007B78F51CF801
00007b78f51d11ed  sub rsp, 0x08
00007b78f51d11f1  push rax
00007b78f51d11f2  push rcx
00007b78f51d11f3  push rdx
00007b78f51d11f4  push rdi
00007b78f51d11f5  push rsi
00007b78f51d11f6  push r8
00007b78f51d11f8  push r9
00007b78f51d11fa  push r10
00007b78f51d11fc  push r11
00007b78f51d11fe  sub rsp, 0xF0
00007b78f51d1205  vmovaps [rsp], xmm0
00007b78f51d120a  vmovaps [rsp+0x10], xmm2
00007b78f51d1210  vmovaps [rsp+0x20], xmm3
00007b78f51d1216  vmovaps [rsp+0x30], xmm4
00007b78f51d121c  vmovaps [rsp+0x40], xmm5
00007b78f51d1222  vmovaps [rsp+0x50], xmm6
00007b78f51d1228  vmovaps [rsp+0x60], xmm7
00007b78f51d122e  vmovaps [rsp+0x70], xmm8
00007b78f51d1234  vmovaps [rsp+0x80], xmm9
00007b78f51d123d  vmovaps [rsp+0x90], xmm10
00007b78f51d1246  vmovaps [rsp+0xA0], xmm11
00007b78f51d124f  vmovaps [rsp+0xB0], xmm12
00007b78f51d1258  vmovaps [rsp+0xC0], xmm13
00007b78f51d1261  vmovaps [rsp+0xD0], xmm14
00007b78f51d126a  vmovaps [rsp+0xE0], xmm15
00007b78f51d1273  sub rsp, 0x30
00007b78f51d1277  movaps [rsp], xmm1
00007b78f51d127b  movaps [rsp+0x10], xmm13
00007b78f51d1281  movaps [rsp+0x20], xmm2
00007b78f51d1286  lea rdi, [rsp]
00007b78f51d128a  mov esi, 0x00
00007b78f51d128f  mov rax, 0x597478C09530
00007b78f51d1299  call rax
00007b78f51d129b  movaps xmm1, [rsp]
00007b78f51d129f  add rsp, 0x30
00007b78f51d12a3  vmovaps xmm0, [rsp]
00007b78f51d12a8  vmovaps xmm2, [rsp+0x10]
00007b78f51d12ae  vmovaps xmm3, [rsp+0x20]
00007b78f51d12b4  vmovaps xmm4, [rsp+0x30]
00007b78f51d12ba  vmovaps xmm5, [rsp+0x40]
00007b78f51d12c0  vmovaps xmm6, [rsp+0x50]
00007b78f51d12c6  vmovaps xmm7, [rsp+0x60]
00007b78f51d12cc  vmovaps xmm8, [rsp+0x70]
00007b78f51d12d2  vmovaps xmm9, [rsp+0x80]
00007b78f51d12db  vmovaps xmm10, [rsp+0x90]
00007b78f51d12e4  vmovaps xmm11, [rsp+0xA0]
00007b78f51d12ed  vmovaps xmm12, [rsp+0xB0]
00007b78f51d12f6  vmovaps xmm13, [rsp+0xC0]
00007b78f51d12ff  vmovaps xmm14, [rsp+0xD0]
00007b78f51d1308  vmovaps xmm15, [rsp+0xE0]
00007b78f51d1311  add rsp, 0xF0
00007b78f51d1318  pop r11
00007b78f51d131a  pop r10
00007b78f51d131c  pop r9
00007b78f51d131e  pop r8
00007b78f51d1320  pop rsi
00007b78f51d1321  pop rdi
00007b78f51d1322  pop rdx
00007b78f51d1323  pop rcx
00007b78f51d1324  pop rax
00007b78f51d1325  add rsp, 0x08
00007b78f51d1329  jmp 0x00007B78F51CF82C
00007b78f51d132e  call 0x00007B78F500E760
00007b78f51d1333  jmp 0x00007B78F51CF839
00007b78f51d1338  sub rsp, 0x08
00007b78f51d133c  push rax
00007b78f51d133d  push rcx
00007b78f51d133e  push rdx
00007b78f51d133f  push rdi
00007b78f51d1340  push rsi
00007b78f51d1341  push r8
00007b78f51d1343  push r9
00007b78f51d1345  push r10
00007b78f51d1347  push r11
00007b78f51d1349  sub rsp, 0xF0
00007b78f51d1350  vmovaps [rsp], xmm0
00007b78f51d1355  vmovaps [rsp+0x10], xmm1
00007b78f51d135b  vmovaps [rsp+0x20], xmm2
00007b78f51d1361  vmovaps [rsp+0x30], xmm3
00007b78f51d1367  vmovaps [rsp+0x40], xmm4
00007b78f51d136d  vmovaps [rsp+0x50], xmm5
00007b78f51d1373  vmovaps [rsp+0x60], xmm6
00007b78f51d1379  vmovaps [rsp+0x70], xmm7
00007b78f51d137f  vmovaps [rsp+0x80], xmm8
00007b78f51d1388  vmovaps [rsp+0x90], xmm9
00007b78f51d1391  vmovaps [rsp+0xA0], xmm10
00007b78f51d139a  vmovaps [rsp+0xB0], xmm11
00007b78f51d13a3  vmovaps [rsp+0xC0], xmm12
00007b78f51d13ac  vmovaps [rsp+0xD0], xmm14
00007b78f51d13b5  vmovaps [rsp+0xE0], xmm15
00007b78f51d13be  sub rsp, 0x30
00007b78f51d13c2  movaps [rsp], xmm13
00007b78f51d13c7  movaps [rsp+0x10], xmm2
00007b78f51d13cc  movaps [rsp+0x20], xmm1
00007b78f51d13d1  lea rdi, [rsp]
00007b78f51d13d5  mov esi, 0x00
00007b78f51d13da  mov rax, 0x597478C09530
00007b78f51d13e4  call rax
00007b78f51d13e6  movaps xmm13, [rsp]
00007b78f51d13eb  add rsp, 0x30
00007b78f51d13ef  vmovaps xmm0, [rsp]
00007b78f51d13f4  vmovaps xmm1, [rsp+0x10]
00007b78f51d13fa  vmovaps xmm2, [rsp+0x20]
00007b78f51d1400  vmovaps xmm3, [rsp+0x30]
00007b78f51d1406  vmovaps xmm4, [rsp+0x40]
00007b78f51d140c  vmovaps xmm5, [rsp+0x50]
00007b78f51d1412  vmovaps xmm6, [rsp+0x60]
00007b78f51d1418  vmovaps xmm7, [rsp+0x70]
00007b78f51d141e  vmovaps xmm8, [rsp+0x80]
00007b78f51d1427  vmovaps xmm9, [rsp+0x90]
00007b78f51d1430  vmovaps xmm10, [rsp+0xA0]
00007b78f51d1439  vmovaps xmm11, [rsp+0xB0]
00007b78f51d1442  vmovaps xmm12, [rsp+0xC0]
00007b78f51d144b  vmovaps xmm14, [rsp+0xD0]
00007b78f51d1454  vmovaps xmm15, [rsp+0xE0]
00007b78f51d145d  add rsp, 0xF0
00007b78f51d1464  pop r11
00007b78f51d1466  pop r10
00007b78f51d1468  pop r9
00007b78f51d146a  pop r8
00007b78f51d146c  pop rsi
00007b78f51d146d  pop rdi
00007b78f51d146e  pop rdx
00007b78f51d146f  pop rcx
00007b78f51d1470  pop rax
00007b78f51d1471  add rsp, 0x08
00007b78f51d1475  jmp 0x00007B78F51CF878
00007b78f51d147a  sub rsp, 0x08
00007b78f51d147e  push rax
00007b78f51d147f  push rcx
00007b78f51d1480  push rdx
00007b78f51d1481  push rdi
00007b78f51d1482  push rsi
00007b78f51d1483  push r8
00007b78f51d1485  push r9
00007b78f51d1487  push r10
00007b78f51d1489  push r11
00007b78f51d148b  sub rsp, 0xF0
00007b78f51d1492  vmovaps [rsp], xmm0
00007b78f51d1497  vmovaps [rsp+0x10], xmm2
00007b78f51d149d  vmovaps [rsp+0x20], xmm3
00007b78f51d14a3  vmovaps [rsp+0x30], xmm4
00007b78f51d14a9  vmovaps [rsp+0x40], xmm5
00007b78f51d14af  vmovaps [rsp+0x50], xmm6
00007b78f51d14b5  vmovaps [rsp+0x60], xmm7
00007b78f51d14bb  vmovaps [rsp+0x70], xmm8
00007b78f51d14c1  vmovaps [rsp+0x80], xmm9
00007b78f51d14ca  vmovaps [rsp+0x90], xmm10
00007b78f51d14d3  vmovaps [rsp+0xA0], xmm11
00007b78f51d14dc  vmovaps [rsp+0xB0], xmm12
00007b78f51d14e5  vmovaps [rsp+0xC0], xmm13
00007b78f51d14ee  vmovaps [rsp+0xD0], xmm14
00007b78f51d14f7  vmovaps [rsp+0xE0], xmm15
00007b78f51d1500  sub rsp, 0x30
00007b78f51d1504  movaps [rsp], xmm1
00007b78f51d1508  movaps [rsp+0x10], xmm15
00007b78f51d150e  movaps [rsp+0x20], xmm2
00007b78f51d1513  lea rdi, [rsp]
00007b78f51d1517  mov esi, 0x00
00007b78f51d151c  mov rax, 0x597478C09530
00007b78f51d1526  call rax
00007b78f51d1528  movaps xmm1, [rsp]
00007b78f51d152c  add rsp, 0x30
00007b78f51d1530  vmovaps xmm0, [rsp]
00007b78f51d1535  vmovaps xmm2, [rsp+0x10]
00007b78f51d153b  vmovaps xmm3, [rsp+0x20]
00007b78f51d1541  vmovaps xmm4, [rsp+0x30]
00007b78f51d1547  vmovaps xmm5, [rsp+0x40]
00007b78f51d154d  vmovaps xmm6, [rsp+0x50]
00007b78f51d1553  vmovaps xmm7, [rsp+0x60]
00007b78f51d1559  vmovaps xmm8, [rsp+0x70]
00007b78f51d155f  vmovaps xmm9, [rsp+0x80]
00007b78f51d1568  vmovaps xmm10, [rsp+0x90]
00007b78f51d1571  vmovaps xmm11, [rsp+0xA0]
00007b78f51d157a  vmovaps xmm12, [rsp+0xB0]
00007b78f51d1583  vmovaps xmm13, [rsp+0xC0]
00007b78f51d158c  vmovaps xmm14, [rsp+0xD0]
00007b78f51d1595  vmovaps xmm15, [rsp+0xE0]
00007b78f51d159e  add rsp, 0xF0
00007b78f51d15a5  pop r11
00007b78f51d15a7  pop r10
00007b78f51d15a9  pop r9
00007b78f51d15ab  pop r8
00007b78f51d15ad  pop rsi
00007b78f51d15ae  pop rdi
00007b78f51d15af  pop rdx
00007b78f51d15b0  pop rcx
00007b78f51d15b1  pop rax
00007b78f51d15b2  add rsp, 0x08
00007b78f51d15b6  jmp 0x00007B78F51CF8AC
00007b78f51d15bb  sub rsp, 0x08
00007b78f51d15bf  push rax
00007b78f51d15c0  push rcx
00007b78f51d15c1  push rdx
00007b78f51d15c2  push rdi
00007b78f51d15c3  push rsi
00007b78f51d15c4  push r8
00007b78f51d15c6  push r9
00007b78f51d15c8  push r10
00007b78f51d15ca  push r11
00007b78f51d15cc  sub rsp, 0xF0
00007b78f51d15d3  vmovaps [rsp], xmm0
00007b78f51d15d8  vmovaps [rsp+0x10], xmm1
00007b78f51d15de  vmovaps [rsp+0x20], xmm2
00007b78f51d15e4  vmovaps [rsp+0x30], xmm3
00007b78f51d15ea  vmovaps [rsp+0x40], xmm4
00007b78f51d15f0  vmovaps [rsp+0x50], xmm5
00007b78f51d15f6  vmovaps [rsp+0x60], xmm6
00007b78f51d15fc  vmovaps [rsp+0x70], xmm7
00007b78f51d1602  vmovaps [rsp+0x80], xmm8
00007b78f51d160b  vmovaps [rsp+0x90], xmm9
00007b78f51d1614  vmovaps [rsp+0xA0], xmm10
00007b78f51d161d  vmovaps [rsp+0xB0], xmm11
00007b78f51d1626  vmovaps [rsp+0xC0], xmm12
00007b78f51d162f  vmovaps [rsp+0xD0], xmm13
00007b78f51d1638  vmovaps [rsp+0xE0], xmm15
00007b78f51d1641  sub rsp, 0x30
00007b78f51d1645  movaps [rsp], xmm14
00007b78f51d164a  movaps [rsp+0x10], xmm2
00007b78f51d164f  movaps [rsp+0x20], xmm15
00007b78f51d1655  lea rdi, [rsp]
00007b78f51d1659  mov esi, 0x00
00007b78f51d165e  mov rax, 0x597478C09530
00007b78f51d1668  call rax
00007b78f51d166a  movaps xmm14, [rsp]
00007b78f51d166f  add rsp, 0x30
00007b78f51d1673  vmovaps xmm0, [rsp]
00007b78f51d1678  vmovaps xmm1, [rsp+0x10]
00007b78f51d167e  vmovaps xmm2, [rsp+0x20]
00007b78f51d1684  vmovaps xmm3, [rsp+0x30]
00007b78f51d168a  vmovaps xmm4, [rsp+0x40]
00007b78f51d1690  vmovaps xmm5, [rsp+0x50]
00007b78f51d1696  vmovaps xmm6, [rsp+0x60]
00007b78f51d169c  vmovaps xmm7, [rsp+0x70]
00007b78f51d16a2  vmovaps xmm8, [rsp+0x80]
00007b78f51d16ab  vmovaps xmm9, [rsp+0x90]
00007b78f51d16b4  vmovaps xmm10, [rsp+0xA0]
00007b78f51d16bd  vmovaps xmm11, [rsp+0xB0]
00007b78f51d16c6  vmovaps xmm12, [rsp+0xC0]
00007b78f51d16cf  vmovaps xmm13, [rsp+0xD0]
00007b78f51d16d8  vmovaps xmm15, [rsp+0xE0]
00007b78f51d16e1  add rsp, 0xF0
00007b78f51d16e8  pop r11
00007b78f51d16ea  pop r10
00007b78f51d16ec  pop r9
00007b78f51d16ee  pop r8
00007b78f51d16f0  pop rsi
00007b78f51d16f1  pop rdi
00007b78f51d16f2  pop rdx
00007b78f51d16f3  pop rcx
00007b78f51d16f4  pop rax
00007b78f51d16f5  add rsp, 0x08
00007b78f51d16f9  jmp 0x00007B78F51CF8E7
00007b78f51d16fe  sub rsp, 0x08
00007b78f51d1702  push rax
00007b78f51d1703  push rcx
00007b78f51d1704  push rdx
00007b78f51d1705  push rdi
00007b78f51d1706  push rsi
00007b78f51d1707  push r8
00007b78f51d1709  push r9
00007b78f51d170b  push r10
00007b78f51d170d  push r11
00007b78f51d170f  sub rsp, 0xF0
00007b78f51d1716  vmovaps [rsp], xmm0
00007b78f51d171b  vmovaps [rsp+0x10], xmm1
00007b78f51d1721  vmovaps [rsp+0x20], xmm2
00007b78f51d1727  vmovaps [rsp+0x30], xmm3
00007b78f51d172d  vmovaps [rsp+0x40], xmm4
00007b78f51d1733  vmovaps [rsp+0x50], xmm5
00007b78f51d1739  vmovaps [rsp+0x60], xmm6
00007b78f51d173f  vmovaps [rsp+0x70], xmm7
00007b78f51d1745  vmovaps [rsp+0x80], xmm8
00007b78f51d174e  vmovaps [rsp+0x90], xmm9
00007b78f51d1757  vmovaps [rsp+0xA0], xmm10
00007b78f51d1760  vmovaps [rsp+0xB0], xmm11
00007b78f51d1769  vmovaps [rsp+0xC0], xmm12
00007b78f51d1772  vmovaps [rsp+0xD0], xmm13
00007b78f51d177b  vmovaps [rsp+0xE0], xmm14
00007b78f51d1784  sub rsp, 0x30
00007b78f51d1788  movaps [rsp], xmm15
00007b78f51d178d  movaps [rsp+0x10], xmm2
00007b78f51d1792  movaps [rsp+0x20], xmm1
00007b78f51d1797  lea rdi, [rsp]
00007b78f51d179b  mov esi, 0x00
00007b78f51d17a0  mov rax, 0x597478C09530
00007b78f51d17aa  call rax
00007b78f51d17ac  movaps xmm15, [rsp]
00007b78f51d17b1  add rsp, 0x30
00007b78f51d17b5  vmovaps xmm0, [rsp]
00007b78f51d17ba  vmovaps xmm1, [rsp+0x10]
00007b78f51d17c0  vmovaps xmm2, [rsp+0x20]
00007b78f51d17c6  vmovaps xmm3, [rsp+0x30]
00007b78f51d17cc  vmovaps xmm4, [rsp+0x40]
00007b78f51d17d2  vmovaps xmm5, [rsp+0x50]
00007b78f51d17d8  vmovaps xmm6, [rsp+0x60]
00007b78f51d17de  vmovaps xmm7, [rsp+0x70]
00007b78f51d17e4  vmovaps xmm8, [rsp+0x80]
00007b78f51d17ed  vmovaps xmm9, [rsp+0x90]
00007b78f51d17f6  vmovaps xmm10, [rsp+0xA0]
00007b78f51d17ff  vmovaps xmm11, [rsp+0xB0]
00007b78f51d1808  vmovaps xmm12, [rsp+0xC0]
00007b78f51d1811  vmovaps xmm13, [rsp+0xD0]
00007b78f51d181a  vmovaps xmm14, [rsp+0xE0]
00007b78f51d1823  add rsp, 0xF0
00007b78f51d182a  pop r11
00007b78f51d182c  pop r10
00007b78f51d182e  pop r9
00007b78f51d1830  pop r8
00007b78f51d1832  pop rsi
00007b78f51d1833  pop rdi
00007b78f51d1834  pop rdx
00007b78f51d1835  pop rcx
00007b78f51d1836  pop rax
00007b78f51d1837  add rsp, 0x08
00007b78f51d183b  jmp 0x00007B78F51CF923
00007b78f51d1840  call 0x00007B78F4FFF430
00007b78f51d1845  jmp 0x00007B78F51CF930
00007b78f51d184a  sub rsp, 0x08
00007b78f51d184e  push rax
00007b78f51d184f  push rcx
00007b78f51d1850  push rdx
00007b78f51d1851  push rdi
00007b78f51d1852  push rsi
00007b78f51d1853  push r8
00007b78f51d1855  push r9
00007b78f51d1857  push r10
00007b78f51d1859  push r11
00007b78f51d185b  sub rsp, 0xF0
00007b78f51d1862  vmovaps [rsp], xmm0
00007b78f51d1867  vmovaps [rsp+0x10], xmm1
00007b78f51d186d  vmovaps [rsp+0x20], xmm3
00007b78f51d1873  vmovaps [rsp+0x30], xmm4
00007b78f51d1879  vmovaps [rsp+0x40], xmm5
00007b78f51d187f  vmovaps [rsp+0x50], xmm6
00007b78f51d1885  vmovaps [rsp+0x60], xmm7
00007b78f51d188b  vmovaps [rsp+0x70], xmm8
00007b78f51d1891  vmovaps [rsp+0x80], xmm9
00007b78f51d189a  vmovaps [rsp+0x90], xmm10
00007b78f51d18a3  vmovaps [rsp+0xA0], xmm11
00007b78f51d18ac  vmovaps [rsp+0xB0], xmm12
00007b78f51d18b5  vmovaps [rsp+0xC0], xmm13
00007b78f51d18be  vmovaps [rsp+0xD0], xmm14
00007b78f51d18c7  vmovaps [rsp+0xE0], xmm15
00007b78f51d18d0  sub rsp, 0x30
00007b78f51d18d4  movaps [rsp], xmm2
00007b78f51d18d8  movaps [rsp+0x10], xmm1
00007b78f51d18dd  movaps [rsp+0x20], xmm14
00007b78f51d18e3  lea rdi, [rsp]
00007b78f51d18e7  mov esi, 0x00
00007b78f51d18ec  mov rax, 0x597478C09530
00007b78f51d18f6  call rax
00007b78f51d18f8  movaps xmm2, [rsp]
00007b78f51d18fc  add rsp, 0x30
00007b78f51d1900  vmovaps xmm0, [rsp]
00007b78f51d1905  vmovaps xmm1, [rsp+0x10]
00007b78f51d190b  vmovaps xmm3, [rsp+0x20]
00007b78f51d1911  vmovaps xmm4, [rsp+0x30]
00007b78f51d1917  vmovaps xmm5, [rsp+0x40]
00007b78f51d191d  vmovaps xmm6, [rsp+0x50]
00007b78f51d1923  vmovaps xmm7, [rsp+0x60]
00007b78f51d1929  vmovaps xmm8, [rsp+0x70]
00007b78f51d192f  vmovaps xmm9, [rsp+0x80]
00007b78f51d1938  vmovaps xmm10, [rsp+0x90]
00007b78f51d1941  vmovaps xmm11, [rsp+0xA0]
00007b78f51d194a  vmovaps xmm12, [rsp+0xB0]
00007b78f51d1953  vmovaps xmm13, [rsp+0xC0]
00007b78f51d195c  vmovaps xmm14, [rsp+0xD0]
00007b78f51d1965  vmovaps xmm15, [rsp+0xE0]
00007b78f51d196e  add rsp, 0xF0
00007b78f51d1975  pop r11
00007b78f51d1977  pop r10
00007b78f51d1979  pop r9
00007b78f51d197b  pop r8
00007b78f51d197d  pop rsi
00007b78f51d197e  pop rdi
00007b78f51d197f  pop rdx
00007b78f51d1980  pop rcx
00007b78f51d1981  pop rax
00007b78f51d1982  add rsp, 0x08
00007b78f51d1986  jmp 0x00007B78F51CF96D
00007b78f51d198b  sub rsp, 0x08
00007b78f51d198f  push rax
00007b78f51d1990  push rcx
00007b78f51d1991  push rdx
00007b78f51d1992  push rdi
00007b78f51d1993  push rsi
00007b78f51d1994  push r8
00007b78f51d1996  push r9
00007b78f51d1998  push r10
00007b78f51d199a  push r11
00007b78f51d199c  sub rsp, 0xF0
00007b78f51d19a3  vmovaps [rsp], xmm0
00007b78f51d19a8  vmovaps [rsp+0x10], xmm1
00007b78f51d19ae  vmovaps [rsp+0x20], xmm2
00007b78f51d19b4  vmovaps [rsp+0x30], xmm3
00007b78f51d19ba  vmovaps [rsp+0x40], xmm4
00007b78f51d19c0  vmovaps [rsp+0x50], xmm5
00007b78f51d19c6  vmovaps [rsp+0x60], xmm6
00007b78f51d19cc  vmovaps [rsp+0x70], xmm7
00007b78f51d19d2  vmovaps [rsp+0x80], xmm8
00007b78f51d19db  vmovaps [rsp+0x90], xmm9
00007b78f51d19e4  vmovaps [rsp+0xA0], xmm10
00007b78f51d19ed  vmovaps [rsp+0xB0], xmm11
00007b78f51d19f6  vmovaps [rsp+0xC0], xmm12
00007b78f51d19ff  vmovaps [rsp+0xD0], xmm13
00007b78f51d1a08  vmovaps [rsp+0xE0], xmm14
00007b78f51d1a11  sub rsp, 0x30
00007b78f51d1a15  movaps [rsp], xmm15
00007b78f51d1a1a  movaps [rsp+0x10], xmm14
00007b78f51d1a20  movaps [rsp+0x20], xmm1
00007b78f51d1a25  lea rdi, [rsp]
00007b78f51d1a29  mov esi, 0x00
00007b78f51d1a2e  mov rax, 0x597478C09530
00007b78f51d1a38  call rax
00007b78f51d1a3a  movaps xmm15, [rsp]
00007b78f51d1a3f  add rsp, 0x30
00007b78f51d1a43  vmovaps xmm0, [rsp]
00007b78f51d1a48  vmovaps xmm1, [rsp+0x10]
00007b78f51d1a4e  vmovaps xmm2, [rsp+0x20]
00007b78f51d1a54  vmovaps xmm3, [rsp+0x30]
00007b78f51d1a5a  vmovaps xmm4, [rsp+0x40]
00007b78f51d1a60  vmovaps xmm5, [rsp+0x50]
00007b78f51d1a66  vmovaps xmm6, [rsp+0x60]
00007b78f51d1a6c  vmovaps xmm7, [rsp+0x70]
00007b78f51d1a72  vmovaps xmm8, [rsp+0x80]
00007b78f51d1a7b  vmovaps xmm9, [rsp+0x90]
00007b78f51d1a84  vmovaps xmm10, [rsp+0xA0]
00007b78f51d1a8d  vmovaps xmm11, [rsp+0xB0]
00007b78f51d1a96  vmovaps xmm12, [rsp+0xC0]
00007b78f51d1a9f  vmovaps xmm13, [rsp+0xD0]
00007b78f51d1aa8  vmovaps xmm14, [rsp+0xE0]
00007b78f51d1ab1  add rsp, 0xF0
00007b78f51d1ab8  pop r11
00007b78f51d1aba  pop r10
00007b78f51d1abc  pop r9
00007b78f51d1abe  pop r8
00007b78f51d1ac0  pop rsi
00007b78f51d1ac1  pop rdi
00007b78f51d1ac2  pop rdx
00007b78f51d1ac3  pop rcx
00007b78f51d1ac4  pop rax
00007b78f51d1ac5  add rsp, 0x08
00007b78f51d1ac9  jmp 0x00007B78F51CF9E7
00007b78f51d1ace  call 0x00007B78F4FFF430
00007b78f51d1ad3  jmp 0x00007B78F51CF9F4
00007b78f51d1ad8  sub rsp, 0x08
00007b78f51d1adc  push rax
00007b78f51d1add  push rcx
00007b78f51d1ade  push rdx
00007b78f51d1adf  push rdi
00007b78f51d1ae0  push rsi
00007b78f51d1ae1  push r8
00007b78f51d1ae3  push r9
00007b78f51d1ae5  push r10
00007b78f51d1ae7  push r11
00007b78f51d1ae9  sub rsp, 0xF0
00007b78f51d1af0  vmovaps [rsp], xmm0
00007b78f51d1af5  vmovaps [rsp+0x10], xmm1
00007b78f51d1afb  vmovaps [rsp+0x20], xmm2
00007b78f51d1b01  vmovaps [rsp+0x30], xmm3
00007b78f51d1b07  vmovaps [rsp+0x40], xmm4
00007b78f51d1b0d  vmovaps [rsp+0x50], xmm5
00007b78f51d1b13  vmovaps [rsp+0x60], xmm6
00007b78f51d1b19  vmovaps [rsp+0x70], xmm7
00007b78f51d1b1f  vmovaps [rsp+0x80], xmm8
00007b78f51d1b28  vmovaps [rsp+0x90], xmm9
00007b78f51d1b31  vmovaps [rsp+0xA0], xmm10
00007b78f51d1b3a  vmovaps [rsp+0xB0], xmm11
00007b78f51d1b43  vmovaps [rsp+0xC0], xmm12
00007b78f51d1b4c  vmovaps [rsp+0xD0], xmm13
00007b78f51d1b55  vmovaps [rsp+0xE0], xmm15
00007b78f51d1b5e  sub rsp, 0x30
00007b78f51d1b62  movaps [rsp], xmm14
00007b78f51d1b67  movaps [rsp+0x10], xmm13
00007b78f51d1b6d  movaps [rsp+0x20], xmm1
00007b78f51d1b72  lea rdi, [rsp]
00007b78f51d1b76  mov esi, 0x00
00007b78f51d1b7b  mov rax, 0x597478C09530
00007b78f51d1b85  call rax
00007b78f51d1b87  movaps xmm14, [rsp]
00007b78f51d1b8c  add rsp, 0x30
00007b78f51d1b90  vmovaps xmm0, [rsp]
00007b78f51d1b95  vmovaps xmm1, [rsp+0x10]
00007b78f51d1b9b  vmovaps xmm2, [rsp+0x20]
00007b78f51d1ba1  vmovaps xmm3, [rsp+0x30]
00007b78f51d1ba7  vmovaps xmm4, [rsp+0x40]
00007b78f51d1bad  vmovaps xmm5, [rsp+0x50]
00007b78f51d1bb3  vmovaps xmm6, [rsp+0x60]
00007b78f51d1bb9  vmovaps xmm7, [rsp+0x70]
00007b78f51d1bbf  vmovaps xmm8, [rsp+0x80]
00007b78f51d1bc8  vmovaps xmm9, [rsp+0x90]
00007b78f51d1bd1  vmovaps xmm10, [rsp+0xA0]
00007b78f51d1bda  vmovaps xmm11, [rsp+0xB0]
00007b78f51d1be3  vmovaps xmm12, [rsp+0xC0]
00007b78f51d1bec  vmovaps xmm13, [rsp+0xD0]
00007b78f51d1bf5  vmovaps xmm15, [rsp+0xE0]
00007b78f51d1bfe  add rsp, 0xF0
00007b78f51d1c05  pop r11
00007b78f51d1c07  pop r10
00007b78f51d1c09  pop r9
00007b78f51d1c0b  pop r8
00007b78f51d1c0d  pop rsi
00007b78f51d1c0e  pop rdi
00007b78f51d1c0f  pop rdx
00007b78f51d1c10  pop rcx
00007b78f51d1c11  pop rax
00007b78f51d1c12  add rsp, 0x08
00007b78f51d1c16  jmp 0x00007B78F51CFAAF
00007b78f51d1c1b  sub rsp, 0x08
00007b78f51d1c1f  push rax
00007b78f51d1c20  push rcx
00007b78f51d1c21  push rdx
00007b78f51d1c22  push rdi
00007b78f51d1c23  push rsi
00007b78f51d1c24  push r8
00007b78f51d1c26  push r9
00007b78f51d1c28  push r10
00007b78f51d1c2a  push r11
00007b78f51d1c2c  sub rsp, 0xF0
00007b78f51d1c33  vmovaps [rsp], xmm0
00007b78f51d1c38  vmovaps [rsp+0x10], xmm1
00007b78f51d1c3e  vmovaps [rsp+0x20], xmm2
00007b78f51d1c44  vmovaps [rsp+0x30], xmm3
00007b78f51d1c4a  vmovaps [rsp+0x40], xmm4
00007b78f51d1c50  vmovaps [rsp+0x50], xmm5
00007b78f51d1c56  vmovaps [rsp+0x60], xmm6
00007b78f51d1c5c  vmovaps [rsp+0x70], xmm7
00007b78f51d1c62  vmovaps [rsp+0x80], xmm8
00007b78f51d1c6b  vmovaps [rsp+0x90], xmm9
00007b78f51d1c74  vmovaps [rsp+0xA0], xmm10
00007b78f51d1c7d  vmovaps [rsp+0xB0], xmm11
00007b78f51d1c86  vmovaps [rsp+0xC0], xmm12
00007b78f51d1c8f  vmovaps [rsp+0xD0], xmm13
00007b78f51d1c98  vmovaps [rsp+0xE0], xmm14
00007b78f51d1ca1  sub rsp, 0x30
00007b78f51d1ca5  movaps [rsp], xmm15
00007b78f51d1caa  movaps [rsp+0x10], xmm13
00007b78f51d1cb0  movaps [rsp+0x20], xmm1
00007b78f51d1cb5  lea rdi, [rsp]
00007b78f51d1cb9  mov esi, 0x00
00007b78f51d1cbe  mov rax, 0x597478C09530
00007b78f51d1cc8  call rax
00007b78f51d1cca  movaps xmm15, [rsp]
00007b78f51d1ccf  add rsp, 0x30
00007b78f51d1cd3  vmovaps xmm0, [rsp]
00007b78f51d1cd8  vmovaps xmm1, [rsp+0x10]
00007b78f51d1cde  vmovaps xmm2, [rsp+0x20]
00007b78f51d1ce4  vmovaps xmm3, [rsp+0x30]
00007b78f51d1cea  vmovaps xmm4, [rsp+0x40]
00007b78f51d1cf0  vmovaps xmm5, [rsp+0x50]
00007b78f51d1cf6  vmovaps xmm6, [rsp+0x60]
00007b78f51d1cfc  vmovaps xmm7, [rsp+0x70]
00007b78f51d1d02  vmovaps xmm8, [rsp+0x80]
00007b78f51d1d0b  vmovaps xmm9, [rsp+0x90]
00007b78f51d1d14  vmovaps xmm10, [rsp+0xA0]
00007b78f51d1d1d  vmovaps xmm11, [rsp+0xB0]
00007b78f51d1d26  vmovaps xmm12, [rsp+0xC0]
00007b78f51d1d2f  vmovaps xmm13, [rsp+0xD0]
00007b78f51d1d38  vmovaps xmm14, [rsp+0xE0]
00007b78f51d1d41  add rsp, 0xF0
00007b78f51d1d48  pop r11
00007b78f51d1d4a  pop r10
00007b78f51d1d4c  pop r9
00007b78f51d1d4e  pop r8
00007b78f51d1d50  pop rsi
00007b78f51d1d51  pop rdi
00007b78f51d1d52  pop rdx
00007b78f51d1d53  pop rcx
00007b78f51d1d54  pop rax
00007b78f51d1d55  add rsp, 0x08
00007b78f51d1d59  jmp 0x00007B78F51CFAEB
00007b78f51d1d5e  call 0x00007B78F4FFF430
00007b78f51d1d63  jmp 0x00007B78F51CFAF8
00007b78f51d1d68  sub rsp, 0x08
00007b78f51d1d6c  push rax
00007b78f51d1d6d  push rcx
00007b78f51d1d6e  push rdx
00007b78f51d1d6f  push rdi
00007b78f51d1d70  push rsi
00007b78f51d1d71  push r8
00007b78f51d1d73  push r9
00007b78f51d1d75  push r10
00007b78f51d1d77  push r11
00007b78f51d1d79  sub rsp, 0xF0
00007b78f51d1d80  vmovaps [rsp], xmm0
00007b78f51d1d85  vmovaps [rsp+0x10], xmm1
00007b78f51d1d8b  vmovaps [rsp+0x20], xmm2
00007b78f51d1d91  vmovaps [rsp+0x30], xmm3
00007b78f51d1d97  vmovaps [rsp+0x40], xmm4
00007b78f51d1d9d  vmovaps [rsp+0x50], xmm5
00007b78f51d1da3  vmovaps [rsp+0x60], xmm6
00007b78f51d1da9  vmovaps [rsp+0x70], xmm7
00007b78f51d1daf  vmovaps [rsp+0x80], xmm8
00007b78f51d1db8  vmovaps [rsp+0x90], xmm9
00007b78f51d1dc1  vmovaps [rsp+0xA0], xmm10
00007b78f51d1dca  vmovaps [rsp+0xB0], xmm11
00007b78f51d1dd3  vmovaps [rsp+0xC0], xmm12
00007b78f51d1ddc  vmovaps [rsp+0xD0], xmm13
00007b78f51d1de5  vmovaps [rsp+0xE0], xmm15
00007b78f51d1dee  sub rsp, 0x30
00007b78f51d1df2  movaps [rsp], xmm14
00007b78f51d1df7  movaps [rsp+0x10], xmm13
00007b78f51d1dfd  movaps [rsp+0x20], xmm2
00007b78f51d1e02  lea rdi, [rsp]
00007b78f51d1e06  mov esi, 0x00
00007b78f51d1e0b  mov rax, 0x597478C09530
00007b78f51d1e15  call rax
00007b78f51d1e17  movaps xmm14, [rsp]
00007b78f51d1e1c  add rsp, 0x30
00007b78f51d1e20  vmovaps xmm0, [rsp]
00007b78f51d1e25  vmovaps xmm1, [rsp+0x10]
00007b78f51d1e2b  vmovaps xmm2, [rsp+0x20]
00007b78f51d1e31  vmovaps xmm3, [rsp+0x30]
00007b78f51d1e37  vmovaps xmm4, [rsp+0x40]
00007b78f51d1e3d  vmovaps xmm5, [rsp+0x50]
00007b78f51d1e43  vmovaps xmm6, [rsp+0x60]
00007b78f51d1e49  vmovaps xmm7, [rsp+0x70]
00007b78f51d1e4f  vmovaps xmm8, [rsp+0x80]
00007b78f51d1e58  vmovaps xmm9, [rsp+0x90]
00007b78f51d1e61  vmovaps xmm10, [rsp+0xA0]
00007b78f51d1e6a  vmovaps xmm11, [rsp+0xB0]
00007b78f51d1e73  vmovaps xmm12, [rsp+0xC0]
00007b78f51d1e7c  vmovaps xmm13, [rsp+0xD0]
00007b78f51d1e85  vmovaps xmm15, [rsp+0xE0]
00007b78f51d1e8e  add rsp, 0xF0
00007b78f51d1e95  pop r11
00007b78f51d1e97  pop r10
00007b78f51d1e99  pop r9
00007b78f51d1e9b  pop r8
00007b78f51d1e9d  pop rsi
00007b78f51d1e9e  pop rdi
00007b78f51d1e9f  pop rdx
00007b78f51d1ea0  pop rcx
00007b78f51d1ea1  pop rax
00007b78f51d1ea2  add rsp, 0x08
00007b78f51d1ea6  jmp 0x00007B78F51CFB24
00007b78f51d1eab  sub rsp, 0x08
00007b78f51d1eaf  push rax
00007b78f51d1eb0  push rcx
00007b78f51d1eb1  push rdx
00007b78f51d1eb2  push rdi
00007b78f51d1eb3  push rsi
00007b78f51d1eb4  push r8
00007b78f51d1eb6  push r9
00007b78f51d1eb8  push r10
00007b78f51d1eba  push r11
00007b78f51d1ebc  sub rsp, 0xF0
00007b78f51d1ec3  vmovaps [rsp], xmm0
00007b78f51d1ec8  vmovaps [rsp+0x10], xmm2
00007b78f51d1ece  vmovaps [rsp+0x20], xmm3
00007b78f51d1ed4  vmovaps [rsp+0x30], xmm4
00007b78f51d1eda  vmovaps [rsp+0x40], xmm5
00007b78f51d1ee0  vmovaps [rsp+0x50], xmm6
00007b78f51d1ee6  vmovaps [rsp+0x60], xmm7
00007b78f51d1eec  vmovaps [rsp+0x70], xmm8
00007b78f51d1ef2  vmovaps [rsp+0x80], xmm9
00007b78f51d1efb  vmovaps [rsp+0x90], xmm10
00007b78f51d1f04  vmovaps [rsp+0xA0], xmm11
00007b78f51d1f0d  vmovaps [rsp+0xB0], xmm12
00007b78f51d1f16  vmovaps [rsp+0xC0], xmm13
00007b78f51d1f1f  vmovaps [rsp+0xD0], xmm14
00007b78f51d1f28  vmovaps [rsp+0xE0], xmm15
00007b78f51d1f31  sub rsp, 0x30
00007b78f51d1f35  movaps [rsp], xmm1
00007b78f51d1f39  movaps [rsp+0x10], xmm13
00007b78f51d1f3f  movaps [rsp+0x20], xmm2
00007b78f51d1f44  lea rdi, [rsp]
00007b78f51d1f48  mov esi, 0x00
00007b78f51d1f4d  mov rax, 0x597478C09530
00007b78f51d1f57  call rax
00007b78f51d1f59  movaps xmm1, [rsp]
00007b78f51d1f5d  add rsp, 0x30
00007b78f51d1f61  vmovaps xmm0, [rsp]
00007b78f51d1f66  vmovaps xmm2, [rsp+0x10]
00007b78f51d1f6c  vmovaps xmm3, [rsp+0x20]
00007b78f51d1f72  vmovaps xmm4, [rsp+0x30]
00007b78f51d1f78  vmovaps xmm5, [rsp+0x40]
00007b78f51d1f7e  vmovaps xmm6, [rsp+0x50]
00007b78f51d1f84  vmovaps xmm7, [rsp+0x60]
00007b78f51d1f8a  vmovaps xmm8, [rsp+0x70]
00007b78f51d1f90  vmovaps xmm9, [rsp+0x80]
00007b78f51d1f99  vmovaps xmm10, [rsp+0x90]
00007b78f51d1fa2  vmovaps xmm11, [rsp+0xA0]
00007b78f51d1fab  vmovaps xmm12, [rsp+0xB0]
00007b78f51d1fb4  vmovaps xmm13, [rsp+0xC0]
00007b78f51d1fbd  vmovaps xmm14, [rsp+0xD0]
00007b78f51d1fc6  vmovaps xmm15, [rsp+0xE0]
00007b78f51d1fcf  add rsp, 0xF0
00007b78f51d1fd6  pop r11
00007b78f51d1fd8  pop r10
00007b78f51d1fda  pop r9
00007b78f51d1fdc  pop r8
00007b78f51d1fde  pop rsi
00007b78f51d1fdf  pop rdi
00007b78f51d1fe0  pop rdx
00007b78f51d1fe1  pop rcx
00007b78f51d1fe2  pop rax
00007b78f51d1fe3  add rsp, 0x08
00007b78f51d1fe7  jmp 0x00007B78F51CFB52
00007b78f51d1fec  sub rsp, 0x08
00007b78f51d1ff0  push rax
00007b78f51d1ff1  push rcx
00007b78f51d1ff2  push rdx
00007b78f51d1ff3  push rdi
00007b78f51d1ff4  push rsi
00007b78f51d1ff5  push r8
00007b78f51d1ff7  push r9
00007b78f51d1ff9  push r10
00007b78f51d1ffb  push r11
00007b78f51d1ffd  sub rsp, 0xF0
00007b78f51d2004  vmovaps [rsp], xmm0
00007b78f51d2009  vmovaps [rsp+0x10], xmm1
00007b78f51d200f  vmovaps [rsp+0x20], xmm3
00007b78f51d2015  vmovaps [rsp+0x30], xmm4
00007b78f51d201b  vmovaps [rsp+0x40], xmm5
00007b78f51d2021  vmovaps [rsp+0x50], xmm6
00007b78f51d2027  vmovaps [rsp+0x60], xmm7
00007b78f51d202d  vmovaps [rsp+0x70], xmm8
00007b78f51d2033  vmovaps [rsp+0x80], xmm9
00007b78f51d203c  vmovaps [rsp+0x90], xmm10
00007b78f51d2045  vmovaps [rsp+0xA0], xmm11
00007b78f51d204e  vmovaps [rsp+0xB0], xmm12
00007b78f51d2057  vmovaps [rsp+0xC0], xmm13
00007b78f51d2060  vmovaps [rsp+0xD0], xmm14
00007b78f51d2069  vmovaps [rsp+0xE0], xmm15
00007b78f51d2072  sub rsp, 0x30
00007b78f51d2076  movaps [rsp], xmm2
00007b78f51d207a  movaps [rsp+0x10], xmm1
00007b78f51d207f  movaps [rsp+0x20], xmm13
00007b78f51d2085  lea rdi, [rsp]
00007b78f51d2089  mov esi, 0x00
00007b78f51d208e  mov rax, 0x597478C09530
00007b78f51d2098  call rax
00007b78f51d209a  movaps xmm2, [rsp]
00007b78f51d209e  add rsp, 0x30
00007b78f51d20a2  vmovaps xmm0, [rsp]
00007b78f51d20a7  vmovaps xmm1, [rsp+0x10]
00007b78f51d20ad  vmovaps xmm3, [rsp+0x20]
00007b78f51d20b3  vmovaps xmm4, [rsp+0x30]
00007b78f51d20b9  vmovaps xmm5, [rsp+0x40]
00007b78f51d20bf  vmovaps xmm6, [rsp+0x50]
00007b78f51d20c5  vmovaps xmm7, [rsp+0x60]
00007b78f51d20cb  vmovaps xmm8, [rsp+0x70]
00007b78f51d20d1  vmovaps xmm9, [rsp+0x80]
00007b78f51d20da  vmovaps xmm10, [rsp+0x90]
00007b78f51d20e3  vmovaps xmm11, [rsp+0xA0]
00007b78f51d20ec  vmovaps xmm12, [rsp+0xB0]
00007b78f51d20f5  vmovaps xmm13, [rsp+0xC0]
00007b78f51d20fe  vmovaps xmm14, [rsp+0xD0]
00007b78f51d2107  vmovaps xmm15, [rsp+0xE0]
00007b78f51d2110  add rsp, 0xF0
00007b78f51d2117  pop r11
00007b78f51d2119  pop r10
00007b78f51d211b  pop r9
00007b78f51d211d  pop r8
00007b78f51d211f  pop rsi
00007b78f51d2120  pop rdi
00007b78f51d2121  pop rdx
00007b78f51d2122  pop rcx
00007b78f51d2123  pop rax
00007b78f51d2124  add rsp, 0x08
00007b78f51d2128  jmp 0x00007B78F51CFBAB
00007b78f51d212d  call 0x00007B78F4FFF430
00007b78f51d2132  jmp 0x00007B78F51CFBB8
00007b78f51d2137  sub rsp, 0x08
00007b78f51d213b  push rax
00007b78f51d213c  push rcx
00007b78f51d213d  push rdx
00007b78f51d213e  push rdi
00007b78f51d213f  push rsi
00007b78f51d2140  push r8
00007b78f51d2142  push r9
00007b78f51d2144  push r10
00007b78f51d2146  push r11
00007b78f51d2148  sub rsp, 0xF0
00007b78f51d214f  vmovaps [rsp], xmm0
00007b78f51d2154  vmovaps [rsp+0x10], xmm1
00007b78f51d215a  vmovaps [rsp+0x20], xmm2
00007b78f51d2160  vmovaps [rsp+0x30], xmm3
00007b78f51d2166  vmovaps [rsp+0x40], xmm4
00007b78f51d216c  vmovaps [rsp+0x50], xmm5
00007b78f51d2172  vmovaps [rsp+0x60], xmm6
00007b78f51d2178  vmovaps [rsp+0x70], xmm7
00007b78f51d217e  vmovaps [rsp+0x80], xmm8
00007b78f51d2187  vmovaps [rsp+0x90], xmm9
00007b78f51d2190  vmovaps [rsp+0xA0], xmm10
00007b78f51d2199  vmovaps [rsp+0xB0], xmm11
00007b78f51d21a2  vmovaps [rsp+0xC0], xmm12
00007b78f51d21ab  vmovaps [rsp+0xD0], xmm13
00007b78f51d21b4  vmovaps [rsp+0xE0], xmm14
00007b78f51d21bd  sub rsp, 0x30
00007b78f51d21c1  movaps [rsp], xmm15
00007b78f51d21c6  movaps [rsp+0x10], xmm13
00007b78f51d21cc  movaps [rsp+0x20], xmm1
00007b78f51d21d1  lea rdi, [rsp]
00007b78f51d21d5  mov esi, 0x00
00007b78f51d21da  mov rax, 0x597478C09530
00007b78f51d21e4  call rax
00007b78f51d21e6  movaps xmm15, [rsp]
00007b78f51d21eb  add rsp, 0x30
00007b78f51d21ef  vmovaps xmm0, [rsp]
00007b78f51d21f4  vmovaps xmm1, [rsp+0x10]
00007b78f51d21fa  vmovaps xmm2, [rsp+0x20]
00007b78f51d2200  vmovaps xmm3, [rsp+0x30]
00007b78f51d2206  vmovaps xmm4, [rsp+0x40]
00007b78f51d220c  vmovaps xmm5, [rsp+0x50]
00007b78f51d2212  vmovaps xmm6, [rsp+0x60]
00007b78f51d2218  vmovaps xmm7, [rsp+0x70]
00007b78f51d221e  vmovaps xmm8, [rsp+0x80]
00007b78f51d2227  vmovaps xmm9, [rsp+0x90]
00007b78f51d2230  vmovaps xmm10, [rsp+0xA0]
00007b78f51d2239  vmovaps xmm11, [rsp+0xB0]
00007b78f51d2242  vmovaps xmm12, [rsp+0xC0]
00007b78f51d224b  vmovaps xmm13, [rsp+0xD0]
00007b78f51d2254  vmovaps xmm14, [rsp+0xE0]
00007b78f51d225d  add rsp, 0xF0
00007b78f51d2264  pop r11
00007b78f51d2266  pop r10
00007b78f51d2268  pop r9
00007b78f51d226a  pop r8
00007b78f51d226c  pop rsi
00007b78f51d226d  pop rdi
00007b78f51d226e  pop rdx
00007b78f51d226f  pop rcx
00007b78f51d2270  pop rax
00007b78f51d2271  add rsp, 0x08
00007b78f51d2275  jmp 0x00007B78F51CFBF7
00007b78f51d227a  sub rsp, 0x08
00007b78f51d227e  push rax
00007b78f51d227f  push rcx
00007b78f51d2280  push rdx
00007b78f51d2281  push rdi
00007b78f51d2282  push rsi
00007b78f51d2283  push r8
00007b78f51d2285  push r9
00007b78f51d2287  push r10
00007b78f51d2289  push r11
00007b78f51d228b  sub rsp, 0xF0
00007b78f51d2292  vmovaps [rsp], xmm0
00007b78f51d2297  vmovaps [rsp+0x10], xmm1
00007b78f51d229d  vmovaps [rsp+0x20], xmm2
00007b78f51d22a3  vmovaps [rsp+0x30], xmm3
00007b78f51d22a9  vmovaps [rsp+0x40], xmm4
00007b78f51d22af  vmovaps [rsp+0x50], xmm5
00007b78f51d22b5  vmovaps [rsp+0x60], xmm6
00007b78f51d22bb  vmovaps [rsp+0x70], xmm7
00007b78f51d22c1  vmovaps [rsp+0x80], xmm8
00007b78f51d22ca  vmovaps [rsp+0x90], xmm9
00007b78f51d22d3  vmovaps [rsp+0xA0], xmm10
00007b78f51d22dc  vmovaps [rsp+0xB0], xmm11
00007b78f51d22e5  vmovaps [rsp+0xC0], xmm12
00007b78f51d22ee  vmovaps [rsp+0xD0], xmm13
00007b78f51d22f7  vmovaps [rsp+0xE0], xmm15
00007b78f51d2300  sub rsp, 0x30
00007b78f51d2304  movaps [rsp], xmm14
00007b78f51d2309  movaps [rsp+0x10], xmm11
00007b78f51d230f  movaps [rsp+0x20], xmm1
00007b78f51d2314  lea rdi, [rsp]
00007b78f51d2318  mov esi, 0x00
00007b78f51d231d  mov rax, 0x597478C09530
00007b78f51d2327  call rax
00007b78f51d2329  movaps xmm14, [rsp]
00007b78f51d232e  add rsp, 0x30
00007b78f51d2332  vmovaps xmm0, [rsp]
00007b78f51d2337  vmovaps xmm1, [rsp+0x10]
00007b78f51d233d  vmovaps xmm2, [rsp+0x20]
00007b78f51d2343  vmovaps xmm3, [rsp+0x30]
00007b78f51d2349  vmovaps xmm4, [rsp+0x40]
00007b78f51d234f  vmovaps xmm5, [rsp+0x50]
00007b78f51d2355  vmovaps xmm6, [rsp+0x60]
00007b78f51d235b  vmovaps xmm7, [rsp+0x70]
00007b78f51d2361  vmovaps xmm8, [rsp+0x80]
00007b78f51d236a  vmovaps xmm9, [rsp+0x90]
00007b78f51d2373  vmovaps xmm10, [rsp+0xA0]
00007b78f51d237c  vmovaps xmm11, [rsp+0xB0]
00007b78f51d2385  vmovaps xmm12, [rsp+0xC0]
00007b78f51d238e  vmovaps xmm13, [rsp+0xD0]
00007b78f51d2397  vmovaps xmm15, [rsp+0xE0]
00007b78f51d23a0  add rsp, 0xF0
00007b78f51d23a7  pop r11
00007b78f51d23a9  pop r10
00007b78f51d23ab  pop r9
00007b78f51d23ad  pop r8
00007b78f51d23af  pop rsi
00007b78f51d23b0  pop rdi
00007b78f51d23b1  pop rdx
00007b78f51d23b2  pop rcx
00007b78f51d23b3  pop rax
00007b78f51d23b4  add rsp, 0x08
00007b78f51d23b8  jmp 0x00007B78F51CFC21
00007b78f51d23bd  sub rsp, 0x08
00007b78f51d23c1  push rax
00007b78f51d23c2  push rcx
00007b78f51d23c3  push rdx
00007b78f51d23c4  push rdi
00007b78f51d23c5  push rsi
00007b78f51d23c6  push r8
00007b78f51d23c8  push r9
00007b78f51d23ca  push r10
00007b78f51d23cc  push r11
00007b78f51d23ce  sub rsp, 0xF0
00007b78f51d23d5  vmovaps [rsp], xmm0
00007b78f51d23da  vmovaps [rsp+0x10], xmm1
00007b78f51d23e0  vmovaps [rsp+0x20], xmm2
00007b78f51d23e6  vmovaps [rsp+0x30], xmm3
00007b78f51d23ec  vmovaps [rsp+0x40], xmm4
00007b78f51d23f2  vmovaps [rsp+0x50], xmm5
00007b78f51d23f8  vmovaps [rsp+0x60], xmm6
00007b78f51d23fe  vmovaps [rsp+0x70], xmm7
00007b78f51d2404  vmovaps [rsp+0x80], xmm8
00007b78f51d240d  vmovaps [rsp+0x90], xmm9
00007b78f51d2416  vmovaps [rsp+0xA0], xmm10
00007b78f51d241f  vmovaps [rsp+0xB0], xmm11
00007b78f51d2428  vmovaps [rsp+0xC0], xmm12
00007b78f51d2431  vmovaps [rsp+0xD0], xmm14
00007b78f51d243a  vmovaps [rsp+0xE0], xmm15
00007b78f51d2443  sub rsp, 0x30
00007b78f51d2447  movaps [rsp], xmm13
00007b78f51d244c  movaps [rsp+0x10], xmm11
00007b78f51d2452  movaps [rsp+0x20], xmm1
00007b78f51d2457  lea rdi, [rsp]
00007b78f51d245b  mov esi, 0x00
00007b78f51d2460  mov rax, 0x597478C09530
00007b78f51d246a  call rax
00007b78f51d246c  movaps xmm13, [rsp]
00007b78f51d2471  add rsp, 0x30
00007b78f51d2475  vmovaps xmm0, [rsp]
00007b78f51d247a  vmovaps xmm1, [rsp+0x10]
00007b78f51d2480  vmovaps xmm2, [rsp+0x20]
00007b78f51d2486  vmovaps xmm3, [rsp+0x30]
00007b78f51d248c  vmovaps xmm4, [rsp+0x40]
00007b78f51d2492  vmovaps xmm5, [rsp+0x50]
00007b78f51d2498  vmovaps xmm6, [rsp+0x60]
00007b78f51d249e  vmovaps xmm7, [rsp+0x70]
00007b78f51d24a4  vmovaps xmm8, [rsp+0x80]
00007b78f51d24ad  vmovaps xmm9, [rsp+0x90]
00007b78f51d24b6  vmovaps xmm10, [rsp+0xA0]
00007b78f51d24bf  vmovaps xmm11, [rsp+0xB0]
00007b78f51d24c8  vmovaps xmm12, [rsp+0xC0]
00007b78f51d24d1  vmovaps xmm14, [rsp+0xD0]
00007b78f51d24da  vmovaps xmm15, [rsp+0xE0]
00007b78f51d24e3  add rsp, 0xF0
00007b78f51d24ea  pop r11
00007b78f51d24ec  pop r10
00007b78f51d24ee  pop r9
00007b78f51d24f0  pop r8
00007b78f51d24f2  pop rsi
00007b78f51d24f3  pop rdi
00007b78f51d24f4  pop rdx
00007b78f51d24f5  pop rcx
00007b78f51d24f6  pop rax
00007b78f51d24f7  add rsp, 0x08
00007b78f51d24fb  jmp 0x00007B78F51CFC76
00007b78f51d2500  call 0x00007B78F4FFF430
00007b78f51d2505  jmp 0x00007B78F51CFC83
00007b78f51d250a  sub rsp, 0x08
00007b78f51d250e  push rax
00007b78f51d250f  push rcx
00007b78f51d2510  push rdx
00007b78f51d2511  push rdi
00007b78f51d2512  push rsi
00007b78f51d2513  push r8
00007b78f51d2515  push r9
00007b78f51d2517  push r10
00007b78f51d2519  push r11
00007b78f51d251b  sub rsp, 0xF0
00007b78f51d2522  vmovaps [rsp], xmm0
00007b78f51d2527  vmovaps [rsp+0x10], xmm1
00007b78f51d252d  vmovaps [rsp+0x20], xmm2
00007b78f51d2533  vmovaps [rsp+0x30], xmm3
00007b78f51d2539  vmovaps [rsp+0x40], xmm4
00007b78f51d253f  vmovaps [rsp+0x50], xmm5
00007b78f51d2545  vmovaps [rsp+0x60], xmm6
00007b78f51d254b  vmovaps [rsp+0x70], xmm7
00007b78f51d2551  vmovaps [rsp+0x80], xmm8
00007b78f51d255a  vmovaps [rsp+0x90], xmm9
00007b78f51d2563  vmovaps [rsp+0xA0], xmm10
00007b78f51d256c  vmovaps [rsp+0xB0], xmm11
00007b78f51d2575  vmovaps [rsp+0xC0], xmm12
00007b78f51d257e  vmovaps [rsp+0xD0], xmm13
00007b78f51d2587  vmovaps [rsp+0xE0], xmm14
00007b78f51d2590  sub rsp, 0x30
00007b78f51d2594  movaps [rsp], xmm15
00007b78f51d2599  movaps [rsp+0x10], xmm11
00007b78f51d259f  movaps [rsp+0x20], xmm1
00007b78f51d25a4  lea rdi, [rsp]
00007b78f51d25a8  mov esi, 0x00
00007b78f51d25ad  mov rax, 0x597478C09530
00007b78f51d25b7  call rax
00007b78f51d25b9  movaps xmm15, [rsp]
00007b78f51d25be  add rsp, 0x30
00007b78f51d25c2  vmovaps xmm0, [rsp]
00007b78f51d25c7  vmovaps xmm1, [rsp+0x10]
00007b78f51d25cd  vmovaps xmm2, [rsp+0x20]
00007b78f51d25d3  vmovaps xmm3, [rsp+0x30]
00007b78f51d25d9  vmovaps xmm4, [rsp+0x40]
00007b78f51d25df  vmovaps xmm5, [rsp+0x50]
00007b78f51d25e5  vmovaps xmm6, [rsp+0x60]
00007b78f51d25eb  vmovaps xmm7, [rsp+0x70]
00007b78f51d25f1  vmovaps xmm8, [rsp+0x80]
00007b78f51d25fa  vmovaps xmm9, [rsp+0x90]
00007b78f51d2603  vmovaps xmm10, [rsp+0xA0]
00007b78f51d260c  vmovaps xmm11, [rsp+0xB0]
00007b78f51d2615  vmovaps xmm12, [rsp+0xC0]
00007b78f51d261e  vmovaps xmm13, [rsp+0xD0]
00007b78f51d2627  vmovaps xmm14, [rsp+0xE0]
00007b78f51d2630  add rsp, 0xF0
00007b78f51d2637  pop r11
00007b78f51d2639  pop r10
00007b78f51d263b  pop r9
00007b78f51d263d  pop r8
00007b78f51d263f  pop rsi
00007b78f51d2640  pop rdi
00007b78f51d2641  pop rdx
00007b78f51d2642  pop rcx
00007b78f51d2643  pop rax
00007b78f51d2644  add rsp, 0x08
00007b78f51d2648  jmp 0x00007B78F51CFCBC
00007b78f51d264d  sub rsp, 0x08
00007b78f51d2651  push rax
00007b78f51d2652  push rcx
00007b78f51d2653  push rdx
00007b78f51d2654  push rdi
00007b78f51d2655  push rsi
00007b78f51d2656  push r8
00007b78f51d2658  push r9
00007b78f51d265a  push r10
00007b78f51d265c  push r11
00007b78f51d265e  sub rsp, 0xF0
00007b78f51d2665  vmovaps [rsp], xmm0
00007b78f51d266a  vmovaps [rsp+0x10], xmm1
00007b78f51d2670  vmovaps [rsp+0x20], xmm2
00007b78f51d2676  vmovaps [rsp+0x30], xmm3
00007b78f51d267c  vmovaps [rsp+0x40], xmm4
00007b78f51d2682  vmovaps [rsp+0x50], xmm5
00007b78f51d2688  vmovaps [rsp+0x60], xmm6
00007b78f51d268e  vmovaps [rsp+0x70], xmm7
00007b78f51d2694  vmovaps [rsp+0x80], xmm8
00007b78f51d269d  vmovaps [rsp+0x90], xmm9
00007b78f51d26a6  vmovaps [rsp+0xA0], xmm10
00007b78f51d26af  vmovaps [rsp+0xB0], xmm12
00007b78f51d26b8  vmovaps [rsp+0xC0], xmm13
00007b78f51d26c1  vmovaps [rsp+0xD0], xmm14
00007b78f51d26ca  vmovaps [rsp+0xE0], xmm15
00007b78f51d26d3  sub rsp, 0x30
00007b78f51d26d7  movaps [rsp], xmm11
00007b78f51d26dc  movaps [rsp+0x10], xmm6
00007b78f51d26e1  movaps [rsp+0x20], xmm14
00007b78f51d26e7  lea rdi, [rsp]
00007b78f51d26eb  mov esi, 0x00
00007b78f51d26f0  mov rax, 0x597478C09530
00007b78f51d26fa  call rax
00007b78f51d26fc  movaps xmm11, [rsp]
00007b78f51d2701  add rsp, 0x30
00007b78f51d2705  vmovaps xmm0, [rsp]
00007b78f51d270a  vmovaps xmm1, [rsp+0x10]
00007b78f51d2710  vmovaps xmm2, [rsp+0x20]
00007b78f51d2716  vmovaps xmm3, [rsp+0x30]
00007b78f51d271c  vmovaps xmm4, [rsp+0x40]
00007b78f51d2722  vmovaps xmm5, [rsp+0x50]
00007b78f51d2728  vmovaps xmm6, [rsp+0x60]
00007b78f51d272e  vmovaps xmm7, [rsp+0x70]
00007b78f51d2734  vmovaps xmm8, [rsp+0x80]
00007b78f51d273d  vmovaps xmm9, [rsp+0x90]
00007b78f51d2746  vmovaps xmm10, [rsp+0xA0]
00007b78f51d274f  vmovaps xmm12, [rsp+0xB0]
00007b78f51d2758  vmovaps xmm13, [rsp+0xC0]
00007b78f51d2761  vmovaps xmm14, [rsp+0xD0]
00007b78f51d276a  vmovaps xmm15, [rsp+0xE0]
00007b78f51d2773  add rsp, 0xF0
00007b78f51d277a  pop r11
00007b78f51d277c  pop r10
00007b78f51d277e  pop r9
00007b78f51d2780  pop r8
00007b78f51d2782  pop rsi
00007b78f51d2783  pop rdi
00007b78f51d2784  pop rdx
00007b78f51d2785  pop rcx
00007b78f51d2786  pop rax
00007b78f51d2787  add rsp, 0x08
00007b78f51d278b  jmp 0x00007B78F51CFD34
00007b78f51d2790  call 0x00007B78F4FFF430
00007b78f51d2795  jmp 0x00007B78F51CFD3E
00007b78f51d279a  sub rsp, 0x08
00007b78f51d279e  push rax
00007b78f51d279f  push rcx
00007b78f51d27a0  push rdx
00007b78f51d27a1  push rdi
00007b78f51d27a2  push rsi
00007b78f51d27a3  push r8
00007b78f51d27a5  push r9
00007b78f51d27a7  push r10
00007b78f51d27a9  push r11
00007b78f51d27ab  sub rsp, 0xF0
00007b78f51d27b2  vmovaps [rsp], xmm0
00007b78f51d27b7  vmovaps [rsp+0x10], xmm1
00007b78f51d27bd  vmovaps [rsp+0x20], xmm2
00007b78f51d27c3  vmovaps [rsp+0x30], xmm3
00007b78f51d27c9  vmovaps [rsp+0x40], xmm4
00007b78f51d27cf  vmovaps [rsp+0x50], xmm5
00007b78f51d27d5  vmovaps [rsp+0x60], xmm6
00007b78f51d27db  vmovaps [rsp+0x70], xmm7
00007b78f51d27e1  vmovaps [rsp+0x80], xmm8
00007b78f51d27ea  vmovaps [rsp+0x90], xmm9
00007b78f51d27f3  vmovaps [rsp+0xA0], xmm10
00007b78f51d27fc  vmovaps [rsp+0xB0], xmm11
00007b78f51d2805  vmovaps [rsp+0xC0], xmm12
00007b78f51d280e  vmovaps [rsp+0xD0], xmm13
00007b78f51d2817  vmovaps [rsp+0xE0], xmm15
00007b78f51d2820  sub rsp, 0x30
00007b78f51d2824  movaps [rsp], xmm14
00007b78f51d2829  movaps [rsp+0x10], xmm6
00007b78f51d282e  movaps [rsp+0x20], xmm2
00007b78f51d2833  lea rdi, [rsp]
00007b78f51d2837  mov esi, 0x00
00007b78f51d283c  mov rax, 0x597478C09530
00007b78f51d2846  call rax
00007b78f51d2848  movaps xmm14, [rsp]
00007b78f51d284d  add rsp, 0x30
00007b78f51d2851  vmovaps xmm0, [rsp]
00007b78f51d2856  vmovaps xmm1, [rsp+0x10]
00007b78f51d285c  vmovaps xmm2, [rsp+0x20]
00007b78f51d2862  vmovaps xmm3, [rsp+0x30]
00007b78f51d2868  vmovaps xmm4, [rsp+0x40]
00007b78f51d286e  vmovaps xmm5, [rsp+0x50]
00007b78f51d2874  vmovaps xmm6, [rsp+0x60]
00007b78f51d287a  vmovaps xmm7, [rsp+0x70]
00007b78f51d2880  vmovaps xmm8, [rsp+0x80]
00007b78f51d2889  vmovaps xmm9, [rsp+0x90]
00007b78f51d2892  vmovaps xmm10, [rsp+0xA0]
00007b78f51d289b  vmovaps xmm11, [rsp+0xB0]
00007b78f51d28a4  vmovaps xmm12, [rsp+0xC0]
00007b78f51d28ad  vmovaps xmm13, [rsp+0xD0]
00007b78f51d28b6  vmovaps xmm15, [rsp+0xE0]
00007b78f51d28bf  add rsp, 0xF0
00007b78f51d28c6  pop r11
00007b78f51d28c8  pop r10
00007b78f51d28ca  pop r9
00007b78f51d28cc  pop r8
00007b78f51d28ce  pop rsi
00007b78f51d28cf  pop rdi
00007b78f51d28d0  pop rdx
00007b78f51d28d1  pop rcx
00007b78f51d28d2  pop rax
00007b78f51d28d3  add rsp, 0x08
00007b78f51d28d7  jmp 0x00007B78F51CFD72
00007b78f51d28dc  sub rsp, 0x08
00007b78f51d28e0  push rax
00007b78f51d28e1  push rcx
00007b78f51d28e2  push rdx
00007b78f51d28e3  push rdi
00007b78f51d28e4  push rsi
00007b78f51d28e5  push r8
00007b78f51d28e7  push r9
00007b78f51d28e9  push r10
00007b78f51d28eb  push r11
00007b78f51d28ed  sub rsp, 0xF0
00007b78f51d28f4  vmovaps [rsp], xmm0
00007b78f51d28f9  vmovaps [rsp+0x10], xmm1
00007b78f51d28ff  vmovaps [rsp+0x20], xmm2
00007b78f51d2905  vmovaps [rsp+0x30], xmm3
00007b78f51d290b  vmovaps [rsp+0x40], xmm4
00007b78f51d2911  vmovaps [rsp+0x50], xmm5
00007b78f51d2917  vmovaps [rsp+0x60], xmm7
00007b78f51d291d  vmovaps [rsp+0x70], xmm8
00007b78f51d2923  vmovaps [rsp+0x80], xmm9
00007b78f51d292c  vmovaps [rsp+0x90], xmm10
00007b78f51d2935  vmovaps [rsp+0xA0], xmm11
00007b78f51d293e  vmovaps [rsp+0xB0], xmm12
00007b78f51d2947  vmovaps [rsp+0xC0], xmm13
00007b78f51d2950  vmovaps [rsp+0xD0], xmm14
00007b78f51d2959  vmovaps [rsp+0xE0], xmm15
00007b78f51d2962  sub rsp, 0x30
00007b78f51d2966  movaps [rsp], xmm6
00007b78f51d296a  movaps [rsp+0x10], xmm5
00007b78f51d296f  movaps [rsp+0x20], xmm1
00007b78f51d2974  lea rdi, [rsp]
00007b78f51d2978  mov esi, 0x00
00007b78f51d297d  mov rax, 0x597478C09530
00007b78f51d2987  call rax
00007b78f51d2989  movaps xmm6, [rsp]
00007b78f51d298d  add rsp, 0x30
00007b78f51d2991  vmovaps xmm0, [rsp]
00007b78f51d2996  vmovaps xmm1, [rsp+0x10]
00007b78f51d299c  vmovaps xmm2, [rsp+0x20]
00007b78f51d29a2  vmovaps xmm3, [rsp+0x30]
00007b78f51d29a8  vmovaps xmm4, [rsp+0x40]
00007b78f51d29ae  vmovaps xmm5, [rsp+0x50]
00007b78f51d29b4  vmovaps xmm7, [rsp+0x60]
00007b78f51d29ba  vmovaps xmm8, [rsp+0x70]
00007b78f51d29c0  vmovaps xmm9, [rsp+0x80]
00007b78f51d29c9  vmovaps xmm10, [rsp+0x90]
00007b78f51d29d2  vmovaps xmm11, [rsp+0xA0]
00007b78f51d29db  vmovaps xmm12, [rsp+0xB0]
00007b78f51d29e4  vmovaps xmm13, [rsp+0xC0]
00007b78f51d29ed  vmovaps xmm14, [rsp+0xD0]
00007b78f51d29f6  vmovaps xmm15, [rsp+0xE0]
00007b78f51d29ff  add rsp, 0xF0
00007b78f51d2a06  pop r11
00007b78f51d2a08  pop r10
00007b78f51d2a0a  pop r9
00007b78f51d2a0c  pop r8
00007b78f51d2a0e  pop rsi
00007b78f51d2a0f  pop rdi
00007b78f51d2a10  pop rdx
00007b78f51d2a11  pop rcx
00007b78f51d2a12  pop rax
00007b78f51d2a13  add rsp, 0x08
00007b78f51d2a17  jmp 0x00007B78F51CFD98
00007b78f51d2a1c  sub rsp, 0x08
00007b78f51d2a20  push rax
00007b78f51d2a21  push rcx
00007b78f51d2a22  push rdx
00007b78f51d2a23  push rdi
00007b78f51d2a24  push rsi
00007b78f51d2a25  push r8
00007b78f51d2a27  push r9
00007b78f51d2a29  push r10
00007b78f51d2a2b  push r11
00007b78f51d2a2d  sub rsp, 0xF0
00007b78f51d2a34  vmovaps [rsp], xmm0
00007b78f51d2a39  vmovaps [rsp+0x10], xmm2
00007b78f51d2a3f  vmovaps [rsp+0x20], xmm3
00007b78f51d2a45  vmovaps [rsp+0x30], xmm4
00007b78f51d2a4b  vmovaps [rsp+0x40], xmm5
00007b78f51d2a51  vmovaps [rsp+0x50], xmm6
00007b78f51d2a57  vmovaps [rsp+0x60], xmm7
00007b78f51d2a5d  vmovaps [rsp+0x70], xmm8
00007b78f51d2a63  vmovaps [rsp+0x80], xmm9
00007b78f51d2a6c  vmovaps [rsp+0x90], xmm10
00007b78f51d2a75  vmovaps [rsp+0xA0], xmm11
00007b78f51d2a7e  vmovaps [rsp+0xB0], xmm12
00007b78f51d2a87  vmovaps [rsp+0xC0], xmm13
00007b78f51d2a90  vmovaps [rsp+0xD0], xmm14
00007b78f51d2a99  vmovaps [rsp+0xE0], xmm15
00007b78f51d2aa2  sub rsp, 0x30
00007b78f51d2aa6  movaps [rsp], xmm1
00007b78f51d2aaa  movaps [rsp+0x10], xmm5
00007b78f51d2aaf  movaps [rsp+0x20], xmm13
00007b78f51d2ab5  lea rdi, [rsp]
00007b78f51d2ab9  mov esi, 0x00
00007b78f51d2abe  mov rax, 0x597478C09530
00007b78f51d2ac8  call rax
00007b78f51d2aca  movaps xmm1, [rsp]
00007b78f51d2ace  add rsp, 0x30
00007b78f51d2ad2  vmovaps xmm0, [rsp]
00007b78f51d2ad7  vmovaps xmm2, [rsp+0x10]
00007b78f51d2add  vmovaps xmm3, [rsp+0x20]
00007b78f51d2ae3  vmovaps xmm4, [rsp+0x30]
00007b78f51d2ae9  vmovaps xmm5, [rsp+0x40]
00007b78f51d2aef  vmovaps xmm6, [rsp+0x50]
00007b78f51d2af5  vmovaps xmm7, [rsp+0x60]
00007b78f51d2afb  vmovaps xmm8, [rsp+0x70]
00007b78f51d2b01  vmovaps xmm9, [rsp+0x80]
00007b78f51d2b0a  vmovaps xmm10, [rsp+0x90]
00007b78f51d2b13  vmovaps xmm11, [rsp+0xA0]
00007b78f51d2b1c  vmovaps xmm12, [rsp+0xB0]
00007b78f51d2b25  vmovaps xmm13, [rsp+0xC0]
00007b78f51d2b2e  vmovaps xmm14, [rsp+0xD0]
00007b78f51d2b37  vmovaps xmm15, [rsp+0xE0]
00007b78f51d2b40  add rsp, 0xF0
00007b78f51d2b47  pop r11
00007b78f51d2b49  pop r10
00007b78f51d2b4b  pop r9
00007b78f51d2b4d  pop r8
00007b78f51d2b4f  pop rsi
00007b78f51d2b50  pop rdi
00007b78f51d2b51  pop rdx
00007b78f51d2b52  pop rcx
00007b78f51d2b53  pop rax
00007b78f51d2b54  add rsp, 0x08
00007b78f51d2b58  jmp 0x00007B78F51CFDB6
00007b78f51d2b5d  sub rsp, 0x08
00007b78f51d2b61  push rax
00007b78f51d2b62  push rcx
00007b78f51d2b63  push rdx
00007b78f51d2b64  push rdi
00007b78f51d2b65  push rsi
00007b78f51d2b66  push r8
00007b78f51d2b68  push r9
00007b78f51d2b6a  push r10
00007b78f51d2b6c  push r11
00007b78f51d2b6e  sub rsp, 0xF0
00007b78f51d2b75  vmovaps [rsp], xmm0
00007b78f51d2b7a  vmovaps [rsp+0x10], xmm1
00007b78f51d2b80  vmovaps [rsp+0x20], xmm2
00007b78f51d2b86  vmovaps [rsp+0x30], xmm3
00007b78f51d2b8c  vmovaps [rsp+0x40], xmm4
00007b78f51d2b92  vmovaps [rsp+0x50], xmm6
00007b78f51d2b98  vmovaps [rsp+0x60], xmm7
00007b78f51d2b9e  vmovaps [rsp+0x70], xmm8
00007b78f51d2ba4  vmovaps [rsp+0x80], xmm9
00007b78f51d2bad  vmovaps [rsp+0x90], xmm10
00007b78f51d2bb6  vmovaps [rsp+0xA0], xmm11
00007b78f51d2bbf  vmovaps [rsp+0xB0], xmm12
00007b78f51d2bc8  vmovaps [rsp+0xC0], xmm13
00007b78f51d2bd1  vmovaps [rsp+0xD0], xmm14
00007b78f51d2bda  vmovaps [rsp+0xE0], xmm15
00007b78f51d2be3  sub rsp, 0x30
00007b78f51d2be7  movaps [rsp], xmm5
00007b78f51d2beb  movaps [rsp+0x10], xmm2
00007b78f51d2bf0  movaps [rsp+0x20], xmm13
00007b78f51d2bf6  lea rdi, [rsp]
00007b78f51d2bfa  mov esi, 0x00
00007b78f51d2bff  mov rax, 0x597478C09530
00007b78f51d2c09  call rax
00007b78f51d2c0b  movaps xmm5, [rsp]
00007b78f51d2c0f  add rsp, 0x30
00007b78f51d2c13  vmovaps xmm0, [rsp]
00007b78f51d2c18  vmovaps xmm1, [rsp+0x10]
00007b78f51d2c1e  vmovaps xmm2, [rsp+0x20]
00007b78f51d2c24  vmovaps xmm3, [rsp+0x30]
00007b78f51d2c2a  vmovaps xmm4, [rsp+0x40]
00007b78f51d2c30  vmovaps xmm6, [rsp+0x50]
00007b78f51d2c36  vmovaps xmm7, [rsp+0x60]
00007b78f51d2c3c  vmovaps xmm8, [rsp+0x70]
00007b78f51d2c42  vmovaps xmm9, [rsp+0x80]
00007b78f51d2c4b  vmovaps xmm10, [rsp+0x90]
00007b78f51d2c54  vmovaps xmm11, [rsp+0xA0]
00007b78f51d2c5d  vmovaps xmm12, [rsp+0xB0]
00007b78f51d2c66  vmovaps xmm13, [rsp+0xC0]
00007b78f51d2c6f  vmovaps xmm14, [rsp+0xD0]
00007b78f51d2c78  vmovaps xmm15, [rsp+0xE0]
00007b78f51d2c81  add rsp, 0xF0
00007b78f51d2c88  pop r11
00007b78f51d2c8a  pop r10
00007b78f51d2c8c  pop r9
00007b78f51d2c8e  pop r8
00007b78f51d2c90  pop rsi
00007b78f51d2c91  pop rdi
00007b78f51d2c92  pop rdx
00007b78f51d2c93  pop rcx
00007b78f51d2c94  pop rax
00007b78f51d2c95  add rsp, 0x08
00007b78f51d2c99  jmp 0x00007B78F51CFDEC
00007b78f51d2c9e  sub rsp, 0x08
00007b78f51d2ca2  push rax
00007b78f51d2ca3  push rcx
00007b78f51d2ca4  push rdx
00007b78f51d2ca5  push rdi
00007b78f51d2ca6  push rsi
00007b78f51d2ca7  push r8
00007b78f51d2ca9  push r9
00007b78f51d2cab  push r10
00007b78f51d2cad  push r11
00007b78f51d2caf  sub rsp, 0xF0
00007b78f51d2cb6  vmovaps [rsp], xmm0
00007b78f51d2cbb  vmovaps [rsp+0x10], xmm1
00007b78f51d2cc1  vmovaps [rsp+0x20], xmm2
00007b78f51d2cc7  vmovaps [rsp+0x30], xmm3
00007b78f51d2ccd  vmovaps [rsp+0x40], xmm4
00007b78f51d2cd3  vmovaps [rsp+0x50], xmm5
00007b78f51d2cd9  vmovaps [rsp+0x60], xmm6
00007b78f51d2cdf  vmovaps [rsp+0x70], xmm7
00007b78f51d2ce5  vmovaps [rsp+0x80], xmm8
00007b78f51d2cee  vmovaps [rsp+0x90], xmm9
00007b78f51d2cf7  vmovaps [rsp+0xA0], xmm10
00007b78f51d2d00  vmovaps [rsp+0xB0], xmm11
00007b78f51d2d09  vmovaps [rsp+0xC0], xmm12
00007b78f51d2d12  vmovaps [rsp+0xD0], xmm14
00007b78f51d2d1b  vmovaps [rsp+0xE0], xmm15
00007b78f51d2d24  sub rsp, 0x30
00007b78f51d2d28  movaps [rsp], xmm13
00007b78f51d2d2d  movaps [rsp+0x10], xmm10
00007b78f51d2d33  movaps [rsp+0x20], xmm1
00007b78f51d2d38  lea rdi, [rsp]
00007b78f51d2d3c  mov esi, 0x00
00007b78f51d2d41  mov rax, 0x597478C09530
00007b78f51d2d4b  call rax
00007b78f51d2d4d  movaps xmm13, [rsp]
00007b78f51d2d52  add rsp, 0x30
00007b78f51d2d56  vmovaps xmm0, [rsp]
00007b78f51d2d5b  vmovaps xmm1, [rsp+0x10]
00007b78f51d2d61  vmovaps xmm2, [rsp+0x20]
00007b78f51d2d67  vmovaps xmm3, [rsp+0x30]
00007b78f51d2d6d  vmovaps xmm4, [rsp+0x40]
00007b78f51d2d73  vmovaps xmm5, [rsp+0x50]
00007b78f51d2d79  vmovaps xmm6, [rsp+0x60]
00007b78f51d2d7f  vmovaps xmm7, [rsp+0x70]
00007b78f51d2d85  vmovaps xmm8, [rsp+0x80]
00007b78f51d2d8e  vmovaps xmm9, [rsp+0x90]
00007b78f51d2d97  vmovaps xmm10, [rsp+0xA0]
00007b78f51d2da0  vmovaps xmm11, [rsp+0xB0]
00007b78f51d2da9  vmovaps xmm12, [rsp+0xC0]
00007b78f51d2db2  vmovaps xmm14, [rsp+0xD0]
00007b78f51d2dbb  vmovaps xmm15, [rsp+0xE0]
00007b78f51d2dc4  add rsp, 0xF0
00007b78f51d2dcb  pop r11
00007b78f51d2dcd  pop r10
00007b78f51d2dcf  pop r9
00007b78f51d2dd1  pop r8
00007b78f51d2dd3  pop rsi
00007b78f51d2dd4  pop rdi
00007b78f51d2dd5  pop rdx
00007b78f51d2dd6  pop rcx
00007b78f51d2dd7  pop rax
00007b78f51d2dd8  add rsp, 0x08
00007b78f51d2ddc  jmp 0x00007B78F51CFE15
00007b78f51d2de1  sub rsp, 0x08
00007b78f51d2de5  push rax
00007b78f51d2de6  push rcx
00007b78f51d2de7  push rdx
00007b78f51d2de8  push rdi
00007b78f51d2de9  push rsi
00007b78f51d2dea  push r8
00007b78f51d2dec  push r9
00007b78f51d2dee  push r10
00007b78f51d2df0  push r11
00007b78f51d2df2  sub rsp, 0xF0
00007b78f51d2df9  vmovaps [rsp], xmm0
00007b78f51d2dfe  vmovaps [rsp+0x10], xmm2
00007b78f51d2e04  vmovaps [rsp+0x20], xmm3
00007b78f51d2e0a  vmovaps [rsp+0x30], xmm4
00007b78f51d2e10  vmovaps [rsp+0x40], xmm5
00007b78f51d2e16  vmovaps [rsp+0x50], xmm6
00007b78f51d2e1c  vmovaps [rsp+0x60], xmm7
00007b78f51d2e22  vmovaps [rsp+0x70], xmm8
00007b78f51d2e28  vmovaps [rsp+0x80], xmm9
00007b78f51d2e31  vmovaps [rsp+0x90], xmm10
00007b78f51d2e3a  vmovaps [rsp+0xA0], xmm11
00007b78f51d2e43  vmovaps [rsp+0xB0], xmm12
00007b78f51d2e4c  vmovaps [rsp+0xC0], xmm13
00007b78f51d2e55  vmovaps [rsp+0xD0], xmm14
00007b78f51d2e5e  vmovaps [rsp+0xE0], xmm15
00007b78f51d2e67  sub rsp, 0x30
00007b78f51d2e6b  movaps [rsp], xmm1
00007b78f51d2e6f  movaps [rsp+0x10], xmm15
00007b78f51d2e75  movaps [rsp+0x20], xmm10
00007b78f51d2e7b  lea rdi, [rsp]
00007b78f51d2e7f  mov esi, 0x00
00007b78f51d2e84  mov rax, 0x597478C09530
00007b78f51d2e8e  call rax
00007b78f51d2e90  movaps xmm1, [rsp]
00007b78f51d2e94  add rsp, 0x30
00007b78f51d2e98  vmovaps xmm0, [rsp]
00007b78f51d2e9d  vmovaps xmm2, [rsp+0x10]
00007b78f51d2ea3  vmovaps xmm3, [rsp+0x20]
00007b78f51d2ea9  vmovaps xmm4, [rsp+0x30]
00007b78f51d2eaf  vmovaps xmm5, [rsp+0x40]
00007b78f51d2eb5  vmovaps xmm6, [rsp+0x50]
00007b78f51d2ebb  vmovaps xmm7, [rsp+0x60]
00007b78f51d2ec1  vmovaps xmm8, [rsp+0x70]
00007b78f51d2ec7  vmovaps xmm9, [rsp+0x80]
00007b78f51d2ed0  vmovaps xmm10, [rsp+0x90]
00007b78f51d2ed9  vmovaps xmm11, [rsp+0xA0]
00007b78f51d2ee2  vmovaps xmm12, [rsp+0xB0]
00007b78f51d2eeb  vmovaps xmm13, [rsp+0xC0]
00007b78f51d2ef4  vmovaps xmm14, [rsp+0xD0]
00007b78f51d2efd  vmovaps xmm15, [rsp+0xE0]
00007b78f51d2f06  add rsp, 0xF0
00007b78f51d2f0d  pop r11
00007b78f51d2f0f  pop r10
00007b78f51d2f11  pop r9
00007b78f51d2f13  pop r8
00007b78f51d2f15  pop rsi
00007b78f51d2f16  pop rdi
00007b78f51d2f17  pop rdx
00007b78f51d2f18  pop rcx
00007b78f51d2f19  pop rax
00007b78f51d2f1a  add rsp, 0x08
00007b78f51d2f1e  jmp 0x00007B78F51CFE34
00007b78f51d2f23  sub rsp, 0x08
00007b78f51d2f27  push rax
00007b78f51d2f28  push rcx
00007b78f51d2f29  push rdx
00007b78f51d2f2a  push rdi
00007b78f51d2f2b  push rsi
00007b78f51d2f2c  push r8
00007b78f51d2f2e  push r9
00007b78f51d2f30  push r10
00007b78f51d2f32  push r11
00007b78f51d2f34  sub rsp, 0xF0
00007b78f51d2f3b  vmovaps [rsp], xmm0
00007b78f51d2f40  vmovaps [rsp+0x10], xmm1
00007b78f51d2f46  vmovaps [rsp+0x20], xmm2
00007b78f51d2f4c  vmovaps [rsp+0x30], xmm3
00007b78f51d2f52  vmovaps [rsp+0x40], xmm4
00007b78f51d2f58  vmovaps [rsp+0x50], xmm5
00007b78f51d2f5e  vmovaps [rsp+0x60], xmm6
00007b78f51d2f64  vmovaps [rsp+0x70], xmm7
00007b78f51d2f6a  vmovaps [rsp+0x80], xmm8
00007b78f51d2f73  vmovaps [rsp+0x90], xmm9
00007b78f51d2f7c  vmovaps [rsp+0xA0], xmm10
00007b78f51d2f85  vmovaps [rsp+0xB0], xmm11
00007b78f51d2f8e  vmovaps [rsp+0xC0], xmm12
00007b78f51d2f97  vmovaps [rsp+0xD0], xmm13
00007b78f51d2fa0  vmovaps [rsp+0xE0], xmm14
00007b78f51d2fa9  sub rsp, 0x30
00007b78f51d2fad  movaps [rsp], xmm15
00007b78f51d2fb2  movaps [rsp+0x10], xmm10
00007b78f51d2fb8  movaps [rsp+0x20], xmm11
00007b78f51d2fbe  lea rdi, [rsp]
00007b78f51d2fc2  mov esi, 0x00
00007b78f51d2fc7  mov rax, 0x597478C09530
00007b78f51d2fd1  call rax
00007b78f51d2fd3  movaps xmm15, [rsp]
00007b78f51d2fd8  add rsp, 0x30
00007b78f51d2fdc  vmovaps xmm0, [rsp]
00007b78f51d2fe1  vmovaps xmm1, [rsp+0x10]
00007b78f51d2fe7  vmovaps xmm2, [rsp+0x20]
00007b78f51d2fed  vmovaps xmm3, [rsp+0x30]
00007b78f51d2ff3  vmovaps xmm4, [rsp+0x40]
00007b78f51d2ff9  vmovaps xmm5, [rsp+0x50]
00007b78f51d2fff  vmovaps xmm6, [rsp+0x60]
00007b78f51d3005  vmovaps xmm7, [rsp+0x70]
00007b78f51d300b  vmovaps xmm8, [rsp+0x80]
00007b78f51d3014  vmovaps xmm9, [rsp+0x90]
00007b78f51d301d  vmovaps xmm10, [rsp+0xA0]
00007b78f51d3026  vmovaps xmm11, [rsp+0xB0]
00007b78f51d302f  vmovaps xmm12, [rsp+0xC0]
00007b78f51d3038  vmovaps xmm13, [rsp+0xD0]
00007b78f51d3041  vmovaps xmm14, [rsp+0xE0]
00007b78f51d304a  add rsp, 0xF0
00007b78f51d3051  pop r11
00007b78f51d3053  pop r10
00007b78f51d3055  pop r9
00007b78f51d3057  pop r8
00007b78f51d3059  pop rsi
00007b78f51d305a  pop rdi
00007b78f51d305b  pop rdx
00007b78f51d305c  pop rcx
00007b78f51d305d  pop rax
00007b78f51d305e  add rsp, 0x08
00007b78f51d3062  jmp 0x00007B78F51CFE57
00007b78f51d3067  sub rsp, 0x08
00007b78f51d306b  push rax
00007b78f51d306c  push rcx
00007b78f51d306d  push rdx
00007b78f51d306e  push rdi
00007b78f51d306f  push rsi
00007b78f51d3070  push r8
00007b78f51d3072  push r9
00007b78f51d3074  push r10
00007b78f51d3076  push r11
00007b78f51d3078  sub rsp, 0xF0
00007b78f51d307f  vmovaps [rsp], xmm0
00007b78f51d3084  vmovaps [rsp+0x10], xmm1
00007b78f51d308a  vmovaps [rsp+0x20], xmm2
00007b78f51d3090  vmovaps [rsp+0x30], xmm3
00007b78f51d3096  vmovaps [rsp+0x40], xmm4
00007b78f51d309c  vmovaps [rsp+0x50], xmm5
00007b78f51d30a2  vmovaps [rsp+0x60], xmm6
00007b78f51d30a8  vmovaps [rsp+0x70], xmm7
00007b78f51d30ae  vmovaps [rsp+0x80], xmm8
00007b78f51d30b7  vmovaps [rsp+0x90], xmm9
00007b78f51d30c0  vmovaps [rsp+0xA0], xmm11
00007b78f51d30c9  vmovaps [rsp+0xB0], xmm12
00007b78f51d30d2  vmovaps [rsp+0xC0], xmm13
00007b78f51d30db  vmovaps [rsp+0xD0], xmm14
00007b78f51d30e4  vmovaps [rsp+0xE0], xmm15
00007b78f51d30ed  sub rsp, 0x30
00007b78f51d30f1  movaps [rsp], xmm10
00007b78f51d30f6  movaps [rsp+0x10], xmm12
00007b78f51d30fc  movaps [rsp+0x20], xmm11
00007b78f51d3102  lea rdi, [rsp]
00007b78f51d3106  mov esi, 0x00
00007b78f51d310b  mov rax, 0x597478C09530
00007b78f51d3115  call rax
00007b78f51d3117  movaps xmm10, [rsp]
00007b78f51d311c  add rsp, 0x30
00007b78f51d3120  vmovaps xmm0, [rsp]
00007b78f51d3125  vmovaps xmm1, [rsp+0x10]
00007b78f51d312b  vmovaps xmm2, [rsp+0x20]
00007b78f51d3131  vmovaps xmm3, [rsp+0x30]
00007b78f51d3137  vmovaps xmm4, [rsp+0x40]
00007b78f51d313d  vmovaps xmm5, [rsp+0x50]
00007b78f51d3143  vmovaps xmm6, [rsp+0x60]
00007b78f51d3149  vmovaps xmm7, [rsp+0x70]
00007b78f51d314f  vmovaps xmm8, [rsp+0x80]
00007b78f51d3158  vmovaps xmm9, [rsp+0x90]
00007b78f51d3161  vmovaps xmm11, [rsp+0xA0]
00007b78f51d316a  vmovaps xmm12, [rsp+0xB0]
00007b78f51d3173  vmovaps xmm13, [rsp+0xC0]
00007b78f51d317c  vmovaps xmm14, [rsp+0xD0]
00007b78f51d3185  vmovaps xmm15, [rsp+0xE0]
00007b78f51d318e  add rsp, 0xF0
00007b78f51d3195  pop r11
00007b78f51d3197  pop r10
00007b78f51d3199  pop r9
00007b78f51d319b  pop r8
00007b78f51d319d  pop rsi
00007b78f51d319e  pop rdi
00007b78f51d319f  pop rdx
00007b78f51d31a0  pop rcx
00007b78f51d31a1  pop rax
00007b78f51d31a2  add rsp, 0x08
00007b78f51d31a6  jmp 0x00007B78F51CFE80
00007b78f51d31ab  sub rsp, 0x08
00007b78f51d31af  push rax
00007b78f51d31b0  push rcx
00007b78f51d31b1  push rdx
00007b78f51d31b2  push rdi
00007b78f51d31b3  push rsi
00007b78f51d31b4  push r8
00007b78f51d31b6  push r9
00007b78f51d31b8  push r10
00007b78f51d31ba  push r11
00007b78f51d31bc  sub rsp, 0xF0
00007b78f51d31c3  vmovaps [rsp], xmm0
00007b78f51d31c8  vmovaps [rsp+0x10], xmm1
00007b78f51d31ce  vmovaps [rsp+0x20], xmm2
00007b78f51d31d4  vmovaps [rsp+0x30], xmm3
00007b78f51d31da  vmovaps [rsp+0x40], xmm4
00007b78f51d31e0  vmovaps [rsp+0x50], xmm5
00007b78f51d31e6  vmovaps [rsp+0x60], xmm6
00007b78f51d31ec  vmovaps [rsp+0x70], xmm7
00007b78f51d31f2  vmovaps [rsp+0x80], xmm8
00007b78f51d31fb  vmovaps [rsp+0x90], xmm9
00007b78f51d3204  vmovaps [rsp+0xA0], xmm10
00007b78f51d320d  vmovaps [rsp+0xB0], xmm12
00007b78f51d3216  vmovaps [rsp+0xC0], xmm13
00007b78f51d321f  vmovaps [rsp+0xD0], xmm14
00007b78f51d3228  vmovaps [rsp+0xE0], xmm15
00007b78f51d3231  sub rsp, 0x30
00007b78f51d3235  movaps [rsp], xmm11
00007b78f51d323a  movaps [rsp+0x10], xmm2
00007b78f51d323f  movaps [rsp+0x20], xmm12
00007b78f51d3245  lea rdi, [rsp]
00007b78f51d3249  mov esi, 0x00
00007b78f51d324e  mov rax, 0x597478C09530
00007b78f51d3258  call rax
00007b78f51d325a  movaps xmm11, [rsp]
00007b78f51d325f  add rsp, 0x30
00007b78f51d3263  vmovaps xmm0, [rsp]
00007b78f51d3268  vmovaps xmm1, [rsp+0x10]
00007b78f51d326e  vmovaps xmm2, [rsp+0x20]
00007b78f51d3274  vmovaps xmm3, [rsp+0x30]
00007b78f51d327a  vmovaps xmm4, [rsp+0x40]
00007b78f51d3280  vmovaps xmm5, [rsp+0x50]
00007b78f51d3286  vmovaps xmm6, [rsp+0x60]
00007b78f51d328c  vmovaps xmm7, [rsp+0x70]
00007b78f51d3292  vmovaps xmm8, [rsp+0x80]
00007b78f51d329b  vmovaps xmm9, [rsp+0x90]
00007b78f51d32a4  vmovaps xmm10, [rsp+0xA0]
00007b78f51d32ad  vmovaps xmm12, [rsp+0xB0]
00007b78f51d32b6  vmovaps xmm13, [rsp+0xC0]
00007b78f51d32bf  vmovaps xmm14, [rsp+0xD0]
00007b78f51d32c8  vmovaps xmm15, [rsp+0xE0]
00007b78f51d32d1  add rsp, 0xF0
00007b78f51d32d8  pop r11
00007b78f51d32da  pop r10
00007b78f51d32dc  pop r9
00007b78f51d32de  pop r8
00007b78f51d32e0  pop rsi
00007b78f51d32e1  pop rdi
00007b78f51d32e2  pop rdx
00007b78f51d32e3  pop rcx
00007b78f51d32e4  pop rax
00007b78f51d32e5  add rsp, 0x08
00007b78f51d32e9  jmp 0x00007B78F51CFEB8
00007b78f51d32ee  sub rsp, 0x08
00007b78f51d32f2  push rax
00007b78f51d32f3  push rcx
00007b78f51d32f4  push rdx
00007b78f51d32f5  push rdi
00007b78f51d32f6  push rsi
00007b78f51d32f7  push r8
00007b78f51d32f9  push r9
00007b78f51d32fb  push r10
00007b78f51d32fd  push r11
00007b78f51d32ff  sub rsp, 0xF0
00007b78f51d3306  vmovaps [rsp], xmm0
00007b78f51d330b  vmovaps [rsp+0x10], xmm2
00007b78f51d3311  vmovaps [rsp+0x20], xmm3
00007b78f51d3317  vmovaps [rsp+0x30], xmm4
00007b78f51d331d  vmovaps [rsp+0x40], xmm5
00007b78f51d3323  vmovaps [rsp+0x50], xmm6
00007b78f51d3329  vmovaps [rsp+0x60], xmm7
00007b78f51d332f  vmovaps [rsp+0x70], xmm8
00007b78f51d3335  vmovaps [rsp+0x80], xmm9
00007b78f51d333e  vmovaps [rsp+0x90], xmm10
00007b78f51d3347  vmovaps [rsp+0xA0], xmm11
00007b78f51d3350  vmovaps [rsp+0xB0], xmm12
00007b78f51d3359  vmovaps [rsp+0xC0], xmm13
00007b78f51d3362  vmovaps [rsp+0xD0], xmm14
00007b78f51d336b  vmovaps [rsp+0xE0], xmm15
00007b78f51d3374  sub rsp, 0x30
00007b78f51d3378  movaps [rsp], xmm1
00007b78f51d337c  movaps [rsp+0x10], xmm14
00007b78f51d3382  movaps [rsp+0x20], xmm6
00007b78f51d3387  lea rdi, [rsp]
00007b78f51d338b  mov esi, 0x00
00007b78f51d3390  mov rax, 0x597478C09530
00007b78f51d339a  call rax
00007b78f51d339c  movaps xmm1, [rsp]
00007b78f51d33a0  add rsp, 0x30
00007b78f51d33a4  vmovaps xmm0, [rsp]
00007b78f51d33a9  vmovaps xmm2, [rsp+0x10]
00007b78f51d33af  vmovaps xmm3, [rsp+0x20]
00007b78f51d33b5  vmovaps xmm4, [rsp+0x30]
00007b78f51d33bb  vmovaps xmm5, [rsp+0x40]
00007b78f51d33c1  vmovaps xmm6, [rsp+0x50]
00007b78f51d33c7  vmovaps xmm7, [rsp+0x60]
00007b78f51d33cd  vmovaps xmm8, [rsp+0x70]
00007b78f51d33d3  vmovaps xmm9, [rsp+0x80]
00007b78f51d33dc  vmovaps xmm10, [rsp+0x90]
00007b78f51d33e5  vmovaps xmm11, [rsp+0xA0]
00007b78f51d33ee  vmovaps xmm12, [rsp+0xB0]
00007b78f51d33f7  vmovaps xmm13, [rsp+0xC0]
00007b78f51d3400  vmovaps xmm14, [rsp+0xD0]
00007b78f51d3409  vmovaps xmm15, [rsp+0xE0]
00007b78f51d3412  add rsp, 0xF0
00007b78f51d3419  pop r11
00007b78f51d341b  pop r10
00007b78f51d341d  pop r9
00007b78f51d341f  pop r8
00007b78f51d3421  pop rsi
00007b78f51d3422  pop rdi
00007b78f51d3423  pop rdx
00007b78f51d3424  pop rcx
00007b78f51d3425  pop rax
00007b78f51d3426  add rsp, 0x08
00007b78f51d342a  jmp 0x00007B78F51CFED1
00007b78f51d342f  sub rsp, 0x08
00007b78f51d3433  push rax
00007b78f51d3434  push rcx
00007b78f51d3435  push rdx
00007b78f51d3436  push rdi
00007b78f51d3437  push rsi
00007b78f51d3438  push r8
00007b78f51d343a  push r9
00007b78f51d343c  push r10
00007b78f51d343e  push r11
00007b78f51d3440  sub rsp, 0xF0
00007b78f51d3447  vmovaps [rsp], xmm0
00007b78f51d344c  vmovaps [rsp+0x10], xmm1
00007b78f51d3452  vmovaps [rsp+0x20], xmm2
00007b78f51d3458  vmovaps [rsp+0x30], xmm3
00007b78f51d345e  vmovaps [rsp+0x40], xmm4
00007b78f51d3464  vmovaps [rsp+0x50], xmm5
00007b78f51d346a  vmovaps [rsp+0x60], xmm6
00007b78f51d3470  vmovaps [rsp+0x70], xmm7
00007b78f51d3476  vmovaps [rsp+0x80], xmm8
00007b78f51d347f  vmovaps [rsp+0x90], xmm9
00007b78f51d3488  vmovaps [rsp+0xA0], xmm10
00007b78f51d3491  vmovaps [rsp+0xB0], xmm11
00007b78f51d349a  vmovaps [rsp+0xC0], xmm12
00007b78f51d34a3  vmovaps [rsp+0xD0], xmm13
00007b78f51d34ac  vmovaps [rsp+0xE0], xmm15
00007b78f51d34b5  sub rsp, 0x30
00007b78f51d34b9  movaps [rsp], xmm14
00007b78f51d34be  movaps [rsp+0x10], xmm12
00007b78f51d34c4  movaps [rsp+0x20], xmm5
00007b78f51d34c9  lea rdi, [rsp]
00007b78f51d34cd  mov esi, 0x00
00007b78f51d34d2  mov rax, 0x597478C09530
00007b78f51d34dc  call rax
00007b78f51d34de  movaps xmm14, [rsp]
00007b78f51d34e3  add rsp, 0x30
00007b78f51d34e7  vmovaps xmm0, [rsp]
00007b78f51d34ec  vmovaps xmm1, [rsp+0x10]
00007b78f51d34f2  vmovaps xmm2, [rsp+0x20]
00007b78f51d34f8  vmovaps xmm3, [rsp+0x30]
00007b78f51d34fe  vmovaps xmm4, [rsp+0x40]
00007b78f51d3504  vmovaps xmm5, [rsp+0x50]
00007b78f51d350a  vmovaps xmm6, [rsp+0x60]
00007b78f51d3510  vmovaps xmm7, [rsp+0x70]
00007b78f51d3516  vmovaps xmm8, [rsp+0x80]
00007b78f51d351f  vmovaps xmm9, [rsp+0x90]
00007b78f51d3528  vmovaps xmm10, [rsp+0xA0]
00007b78f51d3531  vmovaps xmm11, [rsp+0xB0]
00007b78f51d353a  vmovaps xmm12, [rsp+0xC0]
00007b78f51d3543  vmovaps xmm13, [rsp+0xD0]
00007b78f51d354c  vmovaps xmm15, [rsp+0xE0]
00007b78f51d3555  add rsp, 0xF0
00007b78f51d355c  pop r11
00007b78f51d355e  pop r10
00007b78f51d3560  pop r9
00007b78f51d3562  pop r8
00007b78f51d3564  pop rsi
00007b78f51d3565  pop rdi
00007b78f51d3566  pop rdx
00007b78f51d3567  pop rcx
00007b78f51d3568  pop rax
00007b78f51d3569  add rsp, 0x08
00007b78f51d356d  jmp 0x00007B78F51CFEF1
00007b78f51d3572  sub rsp, 0x08
00007b78f51d3576  push rax
00007b78f51d3577  push rcx
00007b78f51d3578  push rdx
00007b78f51d3579  push rdi
00007b78f51d357a  push rsi
00007b78f51d357b  push r8
00007b78f51d357d  push r9
00007b78f51d357f  push r10
00007b78f51d3581  push r11
00007b78f51d3583  sub rsp, 0xF0
00007b78f51d358a  vmovaps [rsp], xmm0
00007b78f51d358f  vmovaps [rsp+0x10], xmm1
00007b78f51d3595  vmovaps [rsp+0x20], xmm2
00007b78f51d359b  vmovaps [rsp+0x30], xmm3
00007b78f51d35a1  vmovaps [rsp+0x40], xmm4
00007b78f51d35a7  vmovaps [rsp+0x50], xmm5
00007b78f51d35ad  vmovaps [rsp+0x60], xmm7
00007b78f51d35b3  vmovaps [rsp+0x70], xmm8
00007b78f51d35b9  vmovaps [rsp+0x80], xmm9
00007b78f51d35c2  vmovaps [rsp+0x90], xmm10
00007b78f51d35cb  vmovaps [rsp+0xA0], xmm11
00007b78f51d35d4  vmovaps [rsp+0xB0], xmm12
00007b78f51d35dd  vmovaps [rsp+0xC0], xmm13
00007b78f51d35e6  vmovaps [rsp+0xD0], xmm14
00007b78f51d35ef  vmovaps [rsp+0xE0], xmm15
00007b78f51d35f8  sub rsp, 0x30
00007b78f51d35fc  movaps [rsp], xmm6
00007b78f51d3600  movaps [rsp+0x10], xmm9
00007b78f51d3606  movaps [rsp+0x20], xmm12
00007b78f51d360c  lea rdi, [rsp]
00007b78f51d3610  mov esi, 0x00
00007b78f51d3615  mov rax, 0x597478C09530
00007b78f51d361f  call rax
00007b78f51d3621  movaps xmm6, [rsp]
00007b78f51d3625  add rsp, 0x30
00007b78f51d3629  vmovaps xmm0, [rsp]
00007b78f51d362e  vmovaps xmm1, [rsp+0x10]
00007b78f51d3634  vmovaps xmm2, [rsp+0x20]
00007b78f51d363a  vmovaps xmm3, [rsp+0x30]
00007b78f51d3640  vmovaps xmm4, [rsp+0x40]
00007b78f51d3646  vmovaps xmm5, [rsp+0x50]
00007b78f51d364c  vmovaps xmm7, [rsp+0x60]
00007b78f51d3652  vmovaps xmm8, [rsp+0x70]
00007b78f51d3658  vmovaps xmm9, [rsp+0x80]
00007b78f51d3661  vmovaps xmm10, [rsp+0x90]
00007b78f51d366a  vmovaps xmm11, [rsp+0xA0]
00007b78f51d3673  vmovaps xmm12, [rsp+0xB0]
00007b78f51d367c  vmovaps xmm13, [rsp+0xC0]
00007b78f51d3685  vmovaps xmm14, [rsp+0xD0]
00007b78f51d368e  vmovaps xmm15, [rsp+0xE0]
00007b78f51d3697  add rsp, 0xF0
00007b78f51d369e  pop r11
00007b78f51d36a0  pop r10
00007b78f51d36a2  pop r9
00007b78f51d36a4  pop r8
00007b78f51d36a6  pop rsi
00007b78f51d36a7  pop rdi
00007b78f51d36a8  pop rdx
00007b78f51d36a9  pop rcx
00007b78f51d36aa  pop rax
00007b78f51d36ab  add rsp, 0x08
00007b78f51d36af  jmp 0x00007B78F51CFF19
00007b78f51d36b4  sub rsp, 0x08
00007b78f51d36b8  push rax
00007b78f51d36b9  push rcx
00007b78f51d36ba  push rdx
00007b78f51d36bb  push rdi
00007b78f51d36bc  push rsi
00007b78f51d36bd  push r8
00007b78f51d36bf  push r9
00007b78f51d36c1  push r10
00007b78f51d36c3  push r11
00007b78f51d36c5  sub rsp, 0xF0
00007b78f51d36cc  vmovaps [rsp], xmm0
00007b78f51d36d1  vmovaps [rsp+0x10], xmm1
00007b78f51d36d7  vmovaps [rsp+0x20], xmm2
00007b78f51d36dd  vmovaps [rsp+0x30], xmm3
00007b78f51d36e3  vmovaps [rsp+0x40], xmm4
00007b78f51d36e9  vmovaps [rsp+0x50], xmm5
00007b78f51d36ef  vmovaps [rsp+0x60], xmm6
00007b78f51d36f5  vmovaps [rsp+0x70], xmm7
00007b78f51d36fb  vmovaps [rsp+0x80], xmm8
00007b78f51d3704  vmovaps [rsp+0x90], xmm9
00007b78f51d370d  vmovaps [rsp+0xA0], xmm10
00007b78f51d3716  vmovaps [rsp+0xB0], xmm11
00007b78f51d371f  vmovaps [rsp+0xC0], xmm13
00007b78f51d3728  vmovaps [rsp+0xD0], xmm14
00007b78f51d3731  vmovaps [rsp+0xE0], xmm15
00007b78f51d373a  sub rsp, 0x30
00007b78f51d373e  movaps [rsp], xmm12
00007b78f51d3743  movaps [rsp+0x10], xmm15
00007b78f51d3749  movaps [rsp+0x20], xmm13
00007b78f51d374f  lea rdi, [rsp]
00007b78f51d3753  mov esi, 0x00
00007b78f51d3758  mov rax, 0x597478C09530
00007b78f51d3762  call rax
00007b78f51d3764  movaps xmm12, [rsp]
00007b78f51d3769  add rsp, 0x30
00007b78f51d376d  vmovaps xmm0, [rsp]
00007b78f51d3772  vmovaps xmm1, [rsp+0x10]
00007b78f51d3778  vmovaps xmm2, [rsp+0x20]
00007b78f51d377e  vmovaps xmm3, [rsp+0x30]
00007b78f51d3784  vmovaps xmm4, [rsp+0x40]
00007b78f51d378a  vmovaps xmm5, [rsp+0x50]
00007b78f51d3790  vmovaps xmm6, [rsp+0x60]
00007b78f51d3796  vmovaps xmm7, [rsp+0x70]
00007b78f51d379c  vmovaps xmm8, [rsp+0x80]
00007b78f51d37a5  vmovaps xmm9, [rsp+0x90]
00007b78f51d37ae  vmovaps xmm10, [rsp+0xA0]
00007b78f51d37b7  vmovaps xmm11, [rsp+0xB0]
00007b78f51d37c0  vmovaps xmm13, [rsp+0xC0]
00007b78f51d37c9  vmovaps xmm14, [rsp+0xD0]
00007b78f51d37d2  vmovaps xmm15, [rsp+0xE0]
00007b78f51d37db  add rsp, 0xF0
00007b78f51d37e2  pop r11
00007b78f51d37e4  pop r10
00007b78f51d37e6  pop r9
00007b78f51d37e8  pop r8
00007b78f51d37ea  pop rsi
00007b78f51d37eb  pop rdi
00007b78f51d37ec  pop rdx
00007b78f51d37ed  pop rcx
00007b78f51d37ee  pop rax
00007b78f51d37ef  add rsp, 0x08
00007b78f51d37f3  jmp 0x00007B78F51CFF34
00007b78f51d37f8  sub rsp, 0x08
00007b78f51d37fc  push rax
00007b78f51d37fd  push rcx
00007b78f51d37fe  push rdx
00007b78f51d37ff  push rdi
00007b78f51d3800  push rsi
00007b78f51d3801  push r8
00007b78f51d3803  push r9
00007b78f51d3805  push r10
00007b78f51d3807  push r11
00007b78f51d3809  sub rsp, 0xF0
00007b78f51d3810  vmovaps [rsp], xmm0
00007b78f51d3815  vmovaps [rsp+0x10], xmm1
00007b78f51d381b  vmovaps [rsp+0x20], xmm2
00007b78f51d3821  vmovaps [rsp+0x30], xmm3
00007b78f51d3827  vmovaps [rsp+0x40], xmm4
00007b78f51d382d  vmovaps [rsp+0x50], xmm5
00007b78f51d3833  vmovaps [rsp+0x60], xmm6
00007b78f51d3839  vmovaps [rsp+0x70], xmm7
00007b78f51d383f  vmovaps [rsp+0x80], xmm8
00007b78f51d3848  vmovaps [rsp+0x90], xmm9
00007b78f51d3851  vmovaps [rsp+0xA0], xmm10
00007b78f51d385a  vmovaps [rsp+0xB0], xmm11
00007b78f51d3863  vmovaps [rsp+0xC0], xmm12
00007b78f51d386c  vmovaps [rsp+0xD0], xmm13
00007b78f51d3875  vmovaps [rsp+0xE0], xmm14
00007b78f51d387e  sub rsp, 0x30
00007b78f51d3882  movaps [rsp], xmm15
00007b78f51d3887  movaps [rsp+0x10], xmm13
00007b78f51d388d  movaps [rsp+0x20], xmm10
00007b78f51d3893  lea rdi, [rsp]
00007b78f51d3897  mov esi, 0x00
00007b78f51d389c  mov rax, 0x597478C09530
00007b78f51d38a6  call rax
00007b78f51d38a8  movaps xmm15, [rsp]
00007b78f51d38ad  add rsp, 0x30
00007b78f51d38b1  vmovaps xmm0, [rsp]
00007b78f51d38b6  vmovaps xmm1, [rsp+0x10]
00007b78f51d38bc  vmovaps xmm2, [rsp+0x20]
00007b78f51d38c2  vmovaps xmm3, [rsp+0x30]
00007b78f51d38c8  vmovaps xmm4, [rsp+0x40]
00007b78f51d38ce  vmovaps xmm5, [rsp+0x50]
00007b78f51d38d4  vmovaps xmm6, [rsp+0x60]
00007b78f51d38da  vmovaps xmm7, [rsp+0x70]
00007b78f51d38e0  vmovaps xmm8, [rsp+0x80]
00007b78f51d38e9  vmovaps xmm9, [rsp+0x90]
00007b78f51d38f2  vmovaps xmm10, [rsp+0xA0]
00007b78f51d38fb  vmovaps xmm11, [rsp+0xB0]
00007b78f51d3904  vmovaps xmm12, [rsp+0xC0]
00007b78f51d390d  vmovaps xmm13, [rsp+0xD0]
00007b78f51d3916  vmovaps xmm14, [rsp+0xE0]
00007b78f51d391f  add rsp, 0xF0
00007b78f51d3926  pop r11
00007b78f51d3928  pop r10
00007b78f51d392a  pop r9
00007b78f51d392c  pop r8
00007b78f51d392e  pop rsi
00007b78f51d392f  pop rdi
00007b78f51d3930  pop rdx
00007b78f51d3931  pop rcx
00007b78f51d3932  pop rax
00007b78f51d3933  add rsp, 0x08
00007b78f51d3937  jmp 0x00007B78F51CFF55
00007b78f51d393c  call 0x00007B78F500C260
00007b78f51d3941  jmp 0x00007B78F51CFFB0
00007b78f51d3946  sub rsp, 0x08
00007b78f51d394a  push rax
00007b78f51d394b  push rcx
00007b78f51d394c  push rdx
00007b78f51d394d  push rdi
00007b78f51d394e  push rsi
00007b78f51d394f  push r8
00007b78f51d3951  push r9
00007b78f51d3953  push r10
00007b78f51d3955  push r11
00007b78f51d3957  sub rsp, 0xF0
00007b78f51d395e  vmovaps [rsp], xmm0
00007b78f51d3963  vmovaps [rsp+0x10], xmm1
00007b78f51d3969  vmovaps [rsp+0x20], xmm2
00007b78f51d396f  vmovaps [rsp+0x30], xmm3
00007b78f51d3975  vmovaps [rsp+0x40], xmm4
00007b78f51d397b  vmovaps [rsp+0x50], xmm5
00007b78f51d3981  vmovaps [rsp+0x60], xmm6
00007b78f51d3987  vmovaps [rsp+0x70], xmm7
00007b78f51d398d  vmovaps [rsp+0x80], xmm8
00007b78f51d3996  vmovaps [rsp+0x90], xmm10
00007b78f51d399f  vmovaps [rsp+0xA0], xmm11
00007b78f51d39a8  vmovaps [rsp+0xB0], xmm12
00007b78f51d39b1  vmovaps [rsp+0xC0], xmm13
00007b78f51d39ba  vmovaps [rsp+0xD0], xmm14
00007b78f51d39c3  vmovaps [rsp+0xE0], xmm15
00007b78f51d39cc  sub rsp, 0x30
00007b78f51d39d0  movaps [rsp], xmm9
00007b78f51d39d5  movaps [rsp+0x10], xmm8
00007b78f51d39db  movaps [rsp+0x20], xmm10
00007b78f51d39e1  lea rdi, [rsp]
00007b78f51d39e5  mov esi, 0x00
00007b78f51d39ea  mov rax, 0x597478C09530
00007b78f51d39f4  call rax
00007b78f51d39f6  movaps xmm9, [rsp]
00007b78f51d39fb  add rsp, 0x30
00007b78f51d39ff  vmovaps xmm0, [rsp]
00007b78f51d3a04  vmovaps xmm1, [rsp+0x10]
00007b78f51d3a0a  vmovaps xmm2, [rsp+0x20]
00007b78f51d3a10  vmovaps xmm3, [rsp+0x30]
00007b78f51d3a16  vmovaps xmm4, [rsp+0x40]
00007b78f51d3a1c  vmovaps xmm5, [rsp+0x50]
00007b78f51d3a22  vmovaps xmm6, [rsp+0x60]
00007b78f51d3a28  vmovaps xmm7, [rsp+0x70]
00007b78f51d3a2e  vmovaps xmm8, [rsp+0x80]
00007b78f51d3a37  vmovaps xmm10, [rsp+0x90]
00007b78f51d3a40  vmovaps xmm11, [rsp+0xA0]
00007b78f51d3a49  vmovaps xmm12, [rsp+0xB0]
00007b78f51d3a52  vmovaps xmm13, [rsp+0xC0]
00007b78f51d3a5b  vmovaps xmm14, [rsp+0xD0]
00007b78f51d3a64  vmovaps xmm15, [rsp+0xE0]
00007b78f51d3a6d  add rsp, 0xF0
00007b78f51d3a74  pop r11
00007b78f51d3a76  pop r10
00007b78f51d3a78  pop r9
00007b78f51d3a7a  pop r8
00007b78f51d3a7c  pop rsi
00007b78f51d3a7d  pop rdi
00007b78f51d3a7e  pop rdx
00007b78f51d3a7f  pop rcx
00007b78f51d3a80  pop rax
00007b78f51d3a81  add rsp, 0x08
00007b78f51d3a85  jmp 0x00007B78F51CFFE1
00007b78f51d3a8a  sub rsp, 0x08
00007b78f51d3a8e  push rax
00007b78f51d3a8f  push rcx
00007b78f51d3a90  push rdx
00007b78f51d3a91  push rdi
00007b78f51d3a92  push rsi
00007b78f51d3a93  push r8
00007b78f51d3a95  push r9
00007b78f51d3a97  push r10
00007b78f51d3a99  push r11
00007b78f51d3a9b  sub rsp, 0xF0
00007b78f51d3aa2  vmovaps [rsp], xmm0
00007b78f51d3aa7  vmovaps [rsp+0x10], xmm1
00007b78f51d3aad  vmovaps [rsp+0x20], xmm2
00007b78f51d3ab3  vmovaps [rsp+0x30], xmm3
00007b78f51d3ab9  vmovaps [rsp+0x40], xmm4
00007b78f51d3abf  vmovaps [rsp+0x50], xmm5
00007b78f51d3ac5  vmovaps [rsp+0x60], xmm6
00007b78f51d3acb  vmovaps [rsp+0x70], xmm7
00007b78f51d3ad1  vmovaps [rsp+0x80], xmm8
00007b78f51d3ada  vmovaps [rsp+0x90], xmm9
00007b78f51d3ae3  vmovaps [rsp+0xA0], xmm11
00007b78f51d3aec  vmovaps [rsp+0xB0], xmm12
00007b78f51d3af5  vmovaps [rsp+0xC0], xmm13
00007b78f51d3afe  vmovaps [rsp+0xD0], xmm14
00007b78f51d3b07  vmovaps [rsp+0xE0], xmm15
00007b78f51d3b10  sub rsp, 0x30
00007b78f51d3b14  movaps [rsp], xmm10
00007b78f51d3b19  movaps [rsp+0x10], xmm1
00007b78f51d3b1e  movaps [rsp+0x20], xmm11
00007b78f51d3b24  lea rdi, [rsp]
00007b78f51d3b28  mov esi, 0x00
00007b78f51d3b2d  mov rax, 0x597478C09530
00007b78f51d3b37  call rax
00007b78f51d3b39  movaps xmm10, [rsp]
00007b78f51d3b3e  add rsp, 0x30
00007b78f51d3b42  vmovaps xmm0, [rsp]
00007b78f51d3b47  vmovaps xmm1, [rsp+0x10]
00007b78f51d3b4d  vmovaps xmm2, [rsp+0x20]
00007b78f51d3b53  vmovaps xmm3, [rsp+0x30]
00007b78f51d3b59  vmovaps xmm4, [rsp+0x40]
00007b78f51d3b5f  vmovaps xmm5, [rsp+0x50]
00007b78f51d3b65  vmovaps xmm6, [rsp+0x60]
00007b78f51d3b6b  vmovaps xmm7, [rsp+0x70]
00007b78f51d3b71  vmovaps xmm8, [rsp+0x80]
00007b78f51d3b7a  vmovaps xmm9, [rsp+0x90]
00007b78f51d3b83  vmovaps xmm11, [rsp+0xA0]
00007b78f51d3b8c  vmovaps xmm12, [rsp+0xB0]
00007b78f51d3b95  vmovaps xmm13, [rsp+0xC0]
00007b78f51d3b9e  vmovaps xmm14, [rsp+0xD0]
00007b78f51d3ba7  vmovaps xmm15, [rsp+0xE0]
00007b78f51d3bb0  add rsp, 0xF0
00007b78f51d3bb7  pop r11
00007b78f51d3bb9  pop r10
00007b78f51d3bbb  pop r9
00007b78f51d3bbd  pop r8
00007b78f51d3bbf  pop rsi
00007b78f51d3bc0  pop rdi
00007b78f51d3bc1  pop rdx
00007b78f51d3bc2  pop rcx
00007b78f51d3bc3  pop rax
00007b78f51d3bc4  add rsp, 0x08
00007b78f51d3bc8  jmp 0x00007B78F51CFFFC
00007b78f51d3bcd  sub rsp, 0x08
00007b78f51d3bd1  push rax
00007b78f51d3bd2  push rcx
00007b78f51d3bd3  push rdx
00007b78f51d3bd4  push rdi
00007b78f51d3bd5  push rsi
00007b78f51d3bd6  push r8
00007b78f51d3bd8  push r9
00007b78f51d3bda  push r10
00007b78f51d3bdc  push r11
00007b78f51d3bde  sub rsp, 0xF0
00007b78f51d3be5  vmovaps [rsp], xmm0
00007b78f51d3bea  vmovaps [rsp+0x10], xmm2
00007b78f51d3bf0  vmovaps [rsp+0x20], xmm3
00007b78f51d3bf6  vmovaps [rsp+0x30], xmm4
00007b78f51d3bfc  vmovaps [rsp+0x40], xmm5
00007b78f51d3c02  vmovaps [rsp+0x50], xmm6
00007b78f51d3c08  vmovaps [rsp+0x60], xmm7
00007b78f51d3c0e  vmovaps [rsp+0x70], xmm8
00007b78f51d3c14  vmovaps [rsp+0x80], xmm9
00007b78f51d3c1d  vmovaps [rsp+0x90], xmm10
00007b78f51d3c26  vmovaps [rsp+0xA0], xmm11
00007b78f51d3c2f  vmovaps [rsp+0xB0], xmm12
00007b78f51d3c38  vmovaps [rsp+0xC0], xmm13
00007b78f51d3c41  vmovaps [rsp+0xD0], xmm14
00007b78f51d3c4a  vmovaps [rsp+0xE0], xmm15
00007b78f51d3c53  sub rsp, 0x30
00007b78f51d3c57  movaps [rsp], xmm1
00007b78f51d3c5b  movaps [rsp+0x10], xmm14
00007b78f51d3c61  movaps [rsp+0x20], xmm6
00007b78f51d3c66  lea rdi, [rsp]
00007b78f51d3c6a  mov esi, 0x00
00007b78f51d3c6f  mov rax, 0x597478C09530
00007b78f51d3c79  call rax
00007b78f51d3c7b  movaps xmm1, [rsp]
00007b78f51d3c7f  add rsp, 0x30
00007b78f51d3c83  vmovaps xmm0, [rsp]
00007b78f51d3c88  vmovaps xmm2, [rsp+0x10]
00007b78f51d3c8e  vmovaps xmm3, [rsp+0x20]
00007b78f51d3c94  vmovaps xmm4, [rsp+0x30]
00007b78f51d3c9a  vmovaps xmm5, [rsp+0x40]
00007b78f51d3ca0  vmovaps xmm6, [rsp+0x50]
00007b78f51d3ca6  vmovaps xmm7, [rsp+0x60]
00007b78f51d3cac  vmovaps xmm8, [rsp+0x70]
00007b78f51d3cb2  vmovaps xmm9, [rsp+0x80]
00007b78f51d3cbb  vmovaps xmm10, [rsp+0x90]
00007b78f51d3cc4  vmovaps xmm11, [rsp+0xA0]
00007b78f51d3ccd  vmovaps xmm12, [rsp+0xB0]
00007b78f51d3cd6  vmovaps xmm13, [rsp+0xC0]
00007b78f51d3cdf  vmovaps xmm14, [rsp+0xD0]
00007b78f51d3ce8  vmovaps xmm15, [rsp+0xE0]
00007b78f51d3cf1  add rsp, 0xF0
00007b78f51d3cf8  pop r11
00007b78f51d3cfa  pop r10
00007b78f51d3cfc  pop r9
00007b78f51d3cfe  pop r8
00007b78f51d3d00  pop rsi
00007b78f51d3d01  pop rdi
00007b78f51d3d02  pop rdx
00007b78f51d3d03  pop rcx
00007b78f51d3d04  pop rax
00007b78f51d3d05  add rsp, 0x08
00007b78f51d3d09  jmp 0x00007B78F51D0015
00007b78f51d3d0e  sub rsp, 0x08
00007b78f51d3d12  push rax
00007b78f51d3d13  push rcx
00007b78f51d3d14  push rdx
00007b78f51d3d15  push rdi
00007b78f51d3d16  push rsi
00007b78f51d3d17  push r8
00007b78f51d3d19  push r9
00007b78f51d3d1b  push r10
00007b78f51d3d1d  push r11
00007b78f51d3d1f  sub rsp, 0xF0
00007b78f51d3d26  vmovaps [rsp], xmm0
00007b78f51d3d2b  vmovaps [rsp+0x10], xmm1
00007b78f51d3d31  vmovaps [rsp+0x20], xmm2
00007b78f51d3d37  vmovaps [rsp+0x30], xmm3
00007b78f51d3d3d  vmovaps [rsp+0x40], xmm4
00007b78f51d3d43  vmovaps [rsp+0x50], xmm5
00007b78f51d3d49  vmovaps [rsp+0x60], xmm6
00007b78f51d3d4f  vmovaps [rsp+0x70], xmm7
00007b78f51d3d55  vmovaps [rsp+0x80], xmm8
00007b78f51d3d5e  vmovaps [rsp+0x90], xmm9
00007b78f51d3d67  vmovaps [rsp+0xA0], xmm10
00007b78f51d3d70  vmovaps [rsp+0xB0], xmm12
00007b78f51d3d79  vmovaps [rsp+0xC0], xmm13
00007b78f51d3d82  vmovaps [rsp+0xD0], xmm14
00007b78f51d3d8b  vmovaps [rsp+0xE0], xmm15
00007b78f51d3d94  sub rsp, 0x30
00007b78f51d3d98  movaps [rsp], xmm11
00007b78f51d3d9d  movaps [rsp+0x10], xmm13
00007b78f51d3da3  movaps [rsp+0x20], xmm14
00007b78f51d3da9  lea rdi, [rsp]
00007b78f51d3dad  mov esi, 0x00
00007b78f51d3db2  mov rax, 0x597478C09530
00007b78f51d3dbc  call rax
00007b78f51d3dbe  movaps xmm11, [rsp]
00007b78f51d3dc3  add rsp, 0x30
00007b78f51d3dc7  vmovaps xmm0, [rsp]
00007b78f51d3dcc  vmovaps xmm1, [rsp+0x10]
00007b78f51d3dd2  vmovaps xmm2, [rsp+0x20]
00007b78f51d3dd8  vmovaps xmm3, [rsp+0x30]
00007b78f51d3dde  vmovaps xmm4, [rsp+0x40]
00007b78f51d3de4  vmovaps xmm5, [rsp+0x50]
00007b78f51d3dea  vmovaps xmm6, [rsp+0x60]
00007b78f51d3df0  vmovaps xmm7, [rsp+0x70]
00007b78f51d3df6  vmovaps xmm8, [rsp+0x80]
00007b78f51d3dff  vmovaps xmm9, [rsp+0x90]
00007b78f51d3e08  vmovaps xmm10, [rsp+0xA0]
00007b78f51d3e11  vmovaps xmm12, [rsp+0xB0]
00007b78f51d3e1a  vmovaps xmm13, [rsp+0xC0]
00007b78f51d3e23  vmovaps xmm14, [rsp+0xD0]
00007b78f51d3e2c  vmovaps xmm15, [rsp+0xE0]
00007b78f51d3e35  add rsp, 0xF0
00007b78f51d3e3c  pop r11
00007b78f51d3e3e  pop r10
00007b78f51d3e40  pop r9
00007b78f51d3e42  pop r8
00007b78f51d3e44  pop rsi
00007b78f51d3e45  pop rdi
00007b78f51d3e46  pop rdx
00007b78f51d3e47  pop rcx
00007b78f51d3e48  pop rax
00007b78f51d3e49  add rsp, 0x08
00007b78f51d3e4d  jmp 0x00007B78F51D003F
00007b78f51d3e52  sub rsp, 0x08
00007b78f51d3e56  push rax
00007b78f51d3e57  push rcx
00007b78f51d3e58  push rdx
00007b78f51d3e59  push rdi
00007b78f51d3e5a  push rsi
00007b78f51d3e5b  push r8
00007b78f51d3e5d  push r9
00007b78f51d3e5f  push r10
00007b78f51d3e61  push r11
00007b78f51d3e63  sub rsp, 0xF0
00007b78f51d3e6a  vmovaps [rsp], xmm0
00007b78f51d3e6f  vmovaps [rsp+0x10], xmm1
00007b78f51d3e75  vmovaps [rsp+0x20], xmm2
00007b78f51d3e7b  vmovaps [rsp+0x30], xmm3
00007b78f51d3e81  vmovaps [rsp+0x40], xmm4
00007b78f51d3e87  vmovaps [rsp+0x50], xmm5
00007b78f51d3e8d  vmovaps [rsp+0x60], xmm6
00007b78f51d3e93  vmovaps [rsp+0x70], xmm7
00007b78f51d3e99  vmovaps [rsp+0x80], xmm8
00007b78f51d3ea2  vmovaps [rsp+0x90], xmm9
00007b78f51d3eab  vmovaps [rsp+0xA0], xmm10
00007b78f51d3eb4  vmovaps [rsp+0xB0], xmm11
00007b78f51d3ebd  vmovaps [rsp+0xC0], xmm12
00007b78f51d3ec6  vmovaps [rsp+0xD0], xmm14
00007b78f51d3ecf  vmovaps [rsp+0xE0], xmm15
00007b78f51d3ed8  sub rsp, 0x30
00007b78f51d3edc  movaps [rsp], xmm13
00007b78f51d3ee1  movaps [rsp+0x10], xmm8
00007b78f51d3ee7  movaps [rsp+0x20], xmm14
00007b78f51d3eed  lea rdi, [rsp]
00007b78f51d3ef1  mov esi, 0x00
00007b78f51d3ef6  mov rax, 0x597478C09530
00007b78f51d3f00  call rax
00007b78f51d3f02  movaps xmm13, [rsp]
00007b78f51d3f07  add rsp, 0x30
00007b78f51d3f0b  vmovaps xmm0, [rsp]
00007b78f51d3f10  vmovaps xmm1, [rsp+0x10]
00007b78f51d3f16  vmovaps xmm2, [rsp+0x20]
00007b78f51d3f1c  vmovaps xmm3, [rsp+0x30]
00007b78f51d3f22  vmovaps xmm4, [rsp+0x40]
00007b78f51d3f28  vmovaps xmm5, [rsp+0x50]
00007b78f51d3f2e  vmovaps xmm6, [rsp+0x60]
00007b78f51d3f34  vmovaps xmm7, [rsp+0x70]
00007b78f51d3f3a  vmovaps xmm8, [rsp+0x80]
00007b78f51d3f43  vmovaps xmm9, [rsp+0x90]
00007b78f51d3f4c  vmovaps xmm10, [rsp+0xA0]
00007b78f51d3f55  vmovaps xmm11, [rsp+0xB0]
00007b78f51d3f5e  vmovaps xmm12, [rsp+0xC0]
00007b78f51d3f67  vmovaps xmm14, [rsp+0xD0]
00007b78f51d3f70  vmovaps xmm15, [rsp+0xE0]
00007b78f51d3f79  add rsp, 0xF0
00007b78f51d3f80  pop r11
00007b78f51d3f82  pop r10
00007b78f51d3f84  pop r9
00007b78f51d3f86  pop r8
00007b78f51d3f88  pop rsi
00007b78f51d3f89  pop rdi
00007b78f51d3f8a  pop rdx
00007b78f51d3f8b  pop rcx
00007b78f51d3f8c  pop rax
00007b78f51d3f8d  add rsp, 0x08
00007b78f51d3f91  jmp 0x00007B78F51D006E
00007b78f51d3f96  sub rsp, 0x08
00007b78f51d3f9a  push rax
00007b78f51d3f9b  push rcx
00007b78f51d3f9c  push rdx
00007b78f51d3f9d  push rdi
00007b78f51d3f9e  push rsi
00007b78f51d3f9f  push r8
00007b78f51d3fa1  push r9
00007b78f51d3fa3  push r10
00007b78f51d3fa5  push r11
00007b78f51d3fa7  sub rsp, 0xF0
00007b78f51d3fae  vmovaps [rsp], xmm0
00007b78f51d3fb3  vmovaps [rsp+0x10], xmm1
00007b78f51d3fb9  vmovaps [rsp+0x20], xmm2
00007b78f51d3fbf  vmovaps [rsp+0x30], xmm3
00007b78f51d3fc5  vmovaps [rsp+0x40], xmm4
00007b78f51d3fcb  vmovaps [rsp+0x50], xmm5
00007b78f51d3fd1  vmovaps [rsp+0x60], xmm6
00007b78f51d3fd7  vmovaps [rsp+0x70], xmm7
00007b78f51d3fdd  vmovaps [rsp+0x80], xmm9
00007b78f51d3fe6  vmovaps [rsp+0x90], xmm10
00007b78f51d3fef  vmovaps [rsp+0xA0], xmm11
00007b78f51d3ff8  vmovaps [rsp+0xB0], xmm12
00007b78f51d4001  vmovaps [rsp+0xC0], xmm13
00007b78f51d400a  vmovaps [rsp+0xD0], xmm14
00007b78f51d4013  vmovaps [rsp+0xE0], xmm15
00007b78f51d401c  sub rsp, 0x30
00007b78f51d4020  movaps [rsp], xmm8
00007b78f51d4025  movaps [rsp+0x10], xmm7
00007b78f51d402a  movaps [rsp+0x20], xmm14
00007b78f51d4030  lea rdi, [rsp]
00007b78f51d4034  mov esi, 0x00
00007b78f51d4039  mov rax, 0x597478C09530
00007b78f51d4043  call rax
00007b78f51d4045  movaps xmm8, [rsp]
00007b78f51d404a  add rsp, 0x30
00007b78f51d404e  vmovaps xmm0, [rsp]
00007b78f51d4053  vmovaps xmm1, [rsp+0x10]
00007b78f51d4059  vmovaps xmm2, [rsp+0x20]
00007b78f51d405f  vmovaps xmm3, [rsp+0x30]
00007b78f51d4065  vmovaps xmm4, [rsp+0x40]
00007b78f51d406b  vmovaps xmm5, [rsp+0x50]
00007b78f51d4071  vmovaps xmm6, [rsp+0x60]
00007b78f51d4077  vmovaps xmm7, [rsp+0x70]
00007b78f51d407d  vmovaps xmm9, [rsp+0x80]
00007b78f51d4086  vmovaps xmm10, [rsp+0x90]
00007b78f51d408f  vmovaps xmm11, [rsp+0xA0]
00007b78f51d4098  vmovaps xmm12, [rsp+0xB0]
00007b78f51d40a1  vmovaps xmm13, [rsp+0xC0]
00007b78f51d40aa  vmovaps xmm14, [rsp+0xD0]
00007b78f51d40b3  vmovaps xmm15, [rsp+0xE0]
00007b78f51d40bc  add rsp, 0xF0
00007b78f51d40c3  pop r11
00007b78f51d40c5  pop r10
00007b78f51d40c7  pop r9
00007b78f51d40c9  pop r8
00007b78f51d40cb  pop rsi
00007b78f51d40cc  pop rdi
00007b78f51d40cd  pop rdx
00007b78f51d40ce  pop rcx
00007b78f51d40cf  pop rax
00007b78f51d40d0  add rsp, 0x08
00007b78f51d40d4  jmp 0x00007B78F51D0094
00007b78f51d40d9  sub rsp, 0x08
00007b78f51d40dd  push rax
00007b78f51d40de  push rcx
00007b78f51d40df  push rdx
00007b78f51d40e0  push rdi
00007b78f51d40e1  push rsi
00007b78f51d40e2  push r8
00007b78f51d40e4  push r9
00007b78f51d40e6  push r10
00007b78f51d40e8  push r11
00007b78f51d40ea  sub rsp, 0xF0
00007b78f51d40f1  vmovaps [rsp], xmm0
00007b78f51d40f6  vmovaps [rsp+0x10], xmm1
00007b78f51d40fc  vmovaps [rsp+0x20], xmm2
00007b78f51d4102  vmovaps [rsp+0x30], xmm3
00007b78f51d4108  vmovaps [rsp+0x40], xmm4
00007b78f51d410e  vmovaps [rsp+0x50], xmm5
00007b78f51d4114  vmovaps [rsp+0x60], xmm6
00007b78f51d411a  vmovaps [rsp+0x70], xmm7
00007b78f51d4120  vmovaps [rsp+0x80], xmm8
00007b78f51d4129  vmovaps [rsp+0x90], xmm9
00007b78f51d4132  vmovaps [rsp+0xA0], xmm10
00007b78f51d413b  vmovaps [rsp+0xB0], xmm11
00007b78f51d4144  vmovaps [rsp+0xC0], xmm12
00007b78f51d414d  vmovaps [rsp+0xD0], xmm13
00007b78f51d4156  vmovaps [rsp+0xE0], xmm15
00007b78f51d415f  sub rsp, 0x30
00007b78f51d4163  movaps [rsp], xmm14
00007b78f51d4168  movaps [rsp+0x10], xmm12
00007b78f51d416e  movaps [rsp+0x20], xmm9
00007b78f51d4174  lea rdi, [rsp]
00007b78f51d4178  mov esi, 0x00
00007b78f51d417d  mov rax, 0x597478C09530
00007b78f51d4187  call rax
00007b78f51d4189  movaps xmm14, [rsp]
00007b78f51d418e  add rsp, 0x30
00007b78f51d4192  vmovaps xmm0, [rsp]
00007b78f51d4197  vmovaps xmm1, [rsp+0x10]
00007b78f51d419d  vmovaps xmm2, [rsp+0x20]
00007b78f51d41a3  vmovaps xmm3, [rsp+0x30]
00007b78f51d41a9  vmovaps xmm4, [rsp+0x40]
00007b78f51d41af  vmovaps xmm5, [rsp+0x50]
00007b78f51d41b5  vmovaps xmm6, [rsp+0x60]
00007b78f51d41bb  vmovaps xmm7, [rsp+0x70]
00007b78f51d41c1  vmovaps xmm8, [rsp+0x80]
00007b78f51d41ca  vmovaps xmm9, [rsp+0x90]
00007b78f51d41d3  vmovaps xmm10, [rsp+0xA0]
00007b78f51d41dc  vmovaps xmm11, [rsp+0xB0]
00007b78f51d41e5  vmovaps xmm12, [rsp+0xC0]
00007b78f51d41ee  vmovaps xmm13, [rsp+0xD0]
00007b78f51d41f7  vmovaps xmm15, [rsp+0xE0]
00007b78f51d4200  add rsp, 0xF0
00007b78f51d4207  pop r11
00007b78f51d4209  pop r10
00007b78f51d420b  pop r9
00007b78f51d420d  pop r8
00007b78f51d420f  pop rsi
00007b78f51d4210  pop rdi
00007b78f51d4211  pop rdx
00007b78f51d4212  pop rcx
00007b78f51d4213  pop rax
00007b78f51d4214  add rsp, 0x08
00007b78f51d4218  jmp 0x00007B78F51D00AE
00007b78f51d421d  sub rsp, 0x08
00007b78f51d4221  push rax
00007b78f51d4222  push rcx
00007b78f51d4223  push rdx
00007b78f51d4224  push rdi
00007b78f51d4225  push rsi
00007b78f51d4226  push r8
00007b78f51d4228  push r9
00007b78f51d422a  push r10
00007b78f51d422c  push r11
00007b78f51d422e  sub rsp, 0xF0
00007b78f51d4235  vmovaps [rsp], xmm0
00007b78f51d423a  vmovaps [rsp+0x10], xmm1
00007b78f51d4240  vmovaps [rsp+0x20], xmm2
00007b78f51d4246  vmovaps [rsp+0x30], xmm3
00007b78f51d424c  vmovaps [rsp+0x40], xmm4
00007b78f51d4252  vmovaps [rsp+0x50], xmm5
00007b78f51d4258  vmovaps [rsp+0x60], xmm6
00007b78f51d425e  vmovaps [rsp+0x70], xmm7
00007b78f51d4264  vmovaps [rsp+0x80], xmm8
00007b78f51d426d  vmovaps [rsp+0x90], xmm10
00007b78f51d4276  vmovaps [rsp+0xA0], xmm11
00007b78f51d427f  vmovaps [rsp+0xB0], xmm12
00007b78f51d4288  vmovaps [rsp+0xC0], xmm13
00007b78f51d4291  vmovaps [rsp+0xD0], xmm14
00007b78f51d429a  vmovaps [rsp+0xE0], xmm15
00007b78f51d42a3  sub rsp, 0x30
00007b78f51d42a7  movaps [rsp], xmm9
00007b78f51d42ac  movaps [rsp+0x10], xmm7
00007b78f51d42b1  movaps [rsp+0x20], xmm12
00007b78f51d42b7  lea rdi, [rsp]
00007b78f51d42bb  mov esi, 0x00
00007b78f51d42c0  mov rax, 0x597478C09530
00007b78f51d42ca  call rax
00007b78f51d42cc  movaps xmm9, [rsp]
00007b78f51d42d1  add rsp, 0x30
00007b78f51d42d5  vmovaps xmm0, [rsp]
00007b78f51d42da  vmovaps xmm1, [rsp+0x10]
00007b78f51d42e0  vmovaps xmm2, [rsp+0x20]
00007b78f51d42e6  vmovaps xmm3, [rsp+0x30]
00007b78f51d42ec  vmovaps xmm4, [rsp+0x40]
00007b78f51d42f2  vmovaps xmm5, [rsp+0x50]
00007b78f51d42f8  vmovaps xmm6, [rsp+0x60]
00007b78f51d42fe  vmovaps xmm7, [rsp+0x70]
00007b78f51d4304  vmovaps xmm8, [rsp+0x80]
00007b78f51d430d  vmovaps xmm10, [rsp+0x90]
00007b78f51d4316  vmovaps xmm11, [rsp+0xA0]
00007b78f51d431f  vmovaps xmm12, [rsp+0xB0]
00007b78f51d4328  vmovaps xmm13, [rsp+0xC0]
00007b78f51d4331  vmovaps xmm14, [rsp+0xD0]
00007b78f51d433a  vmovaps xmm15, [rsp+0xE0]
00007b78f51d4343  add rsp, 0xF0
00007b78f51d434a  pop r11
00007b78f51d434c  pop r10
00007b78f51d434e  pop r9
00007b78f51d4350  pop r8
00007b78f51d4352  pop rsi
00007b78f51d4353  pop rdi
00007b78f51d4354  pop rdx
00007b78f51d4355  pop rcx
00007b78f51d4356  pop rax
00007b78f51d4357  add rsp, 0x08
00007b78f51d435b  jmp 0x00007B78F51D00DD
00007b78f51d4360  sub rsp, 0x08
00007b78f51d4364  push rax
00007b78f51d4365  push rcx
00007b78f51d4366  push rdx
00007b78f51d4367  push rdi
00007b78f51d4368  push rsi
00007b78f51d4369  push r8
00007b78f51d436b  push r9
00007b78f51d436d  push r10
00007b78f51d436f  push r11
00007b78f51d4371  sub rsp, 0xF0
00007b78f51d4378  vmovaps [rsp], xmm0
00007b78f51d437d  vmovaps [rsp+0x10], xmm1
00007b78f51d4383  vmovaps [rsp+0x20], xmm2
00007b78f51d4389  vmovaps [rsp+0x30], xmm3
00007b78f51d438f  vmovaps [rsp+0x40], xmm4
00007b78f51d4395  vmovaps [rsp+0x50], xmm5
00007b78f51d439b  vmovaps [rsp+0x60], xmm6
00007b78f51d43a1  vmovaps [rsp+0x70], xmm7
00007b78f51d43a7  vmovaps [rsp+0x80], xmm8
00007b78f51d43b0  vmovaps [rsp+0x90], xmm9
00007b78f51d43b9  vmovaps [rsp+0xA0], xmm10
00007b78f51d43c2  vmovaps [rsp+0xB0], xmm11
00007b78f51d43cb  vmovaps [rsp+0xC0], xmm13
00007b78f51d43d4  vmovaps [rsp+0xD0], xmm14
00007b78f51d43dd  vmovaps [rsp+0xE0], xmm15
00007b78f51d43e6  sub rsp, 0x30
00007b78f51d43ea  movaps [rsp], xmm12
00007b78f51d43ef  movaps [rsp+0x10], xmm15
00007b78f51d43f5  movaps [rsp+0x20], xmm11
00007b78f51d43fb  lea rdi, [rsp]
00007b78f51d43ff  mov esi, 0x00
00007b78f51d4404  mov rax, 0x597478C09530
00007b78f51d440e  call rax
00007b78f51d4410  movaps xmm12, [rsp]
00007b78f51d4415  add rsp, 0x30
00007b78f51d4419  vmovaps xmm0, [rsp]
00007b78f51d441e  vmovaps xmm1, [rsp+0x10]
00007b78f51d4424  vmovaps xmm2, [rsp+0x20]
00007b78f51d442a  vmovaps xmm3, [rsp+0x30]
00007b78f51d4430  vmovaps xmm4, [rsp+0x40]
00007b78f51d4436  vmovaps xmm5, [rsp+0x50]
00007b78f51d443c  vmovaps xmm6, [rsp+0x60]
00007b78f51d4442  vmovaps xmm7, [rsp+0x70]
00007b78f51d4448  vmovaps xmm8, [rsp+0x80]
00007b78f51d4451  vmovaps xmm9, [rsp+0x90]
00007b78f51d445a  vmovaps xmm10, [rsp+0xA0]
00007b78f51d4463  vmovaps xmm11, [rsp+0xB0]
00007b78f51d446c  vmovaps xmm13, [rsp+0xC0]
00007b78f51d4475  vmovaps xmm14, [rsp+0xD0]
00007b78f51d447e  vmovaps xmm15, [rsp+0xE0]
00007b78f51d4487  add rsp, 0xF0
00007b78f51d448e  pop r11
00007b78f51d4490  pop r10
00007b78f51d4492  pop r9
00007b78f51d4494  pop r8
00007b78f51d4496  pop rsi
00007b78f51d4497  pop rdi
00007b78f51d4498  pop rdx
00007b78f51d4499  pop rcx
00007b78f51d449a  pop rax
00007b78f51d449b  add rsp, 0x08
00007b78f51d449f  jmp 0x00007B78F51D00F7
00007b78f51d44a4  sub rsp, 0x08
00007b78f51d44a8  push rax
00007b78f51d44a9  push rcx
00007b78f51d44aa  push rdx
00007b78f51d44ab  push rdi
00007b78f51d44ac  push rsi
00007b78f51d44ad  push r8
00007b78f51d44af  push r9
00007b78f51d44b1  push r10
00007b78f51d44b3  push r11
00007b78f51d44b5  sub rsp, 0xF0
00007b78f51d44bc  vmovaps [rsp], xmm0
00007b78f51d44c1  vmovaps [rsp+0x10], xmm1
00007b78f51d44c7  vmovaps [rsp+0x20], xmm2
00007b78f51d44cd  vmovaps [rsp+0x30], xmm3
00007b78f51d44d3  vmovaps [rsp+0x40], xmm4
00007b78f51d44d9  vmovaps [rsp+0x50], xmm5
00007b78f51d44df  vmovaps [rsp+0x60], xmm6
00007b78f51d44e5  vmovaps [rsp+0x70], xmm7
00007b78f51d44eb  vmovaps [rsp+0x80], xmm8
00007b78f51d44f4  vmovaps [rsp+0x90], xmm9
00007b78f51d44fd  vmovaps [rsp+0xA0], xmm10
00007b78f51d4506  vmovaps [rsp+0xB0], xmm12
00007b78f51d450f  vmovaps [rsp+0xC0], xmm13
00007b78f51d4518  vmovaps [rsp+0xD0], xmm14
00007b78f51d4521  vmovaps [rsp+0xE0], xmm15
00007b78f51d452a  sub rsp, 0x30
00007b78f51d452e  movaps [rsp], xmm11
00007b78f51d4533  movaps [rsp+0x10], xmm7
00007b78f51d4538  movaps [rsp+0x20], xmm15
00007b78f51d453e  lea rdi, [rsp]
00007b78f51d4542  mov esi, 0x00
00007b78f51d4547  mov rax, 0x597478C09530
00007b78f51d4551  call rax
00007b78f51d4553  movaps xmm11, [rsp]
00007b78f51d4558  add rsp, 0x30
00007b78f51d455c  vmovaps xmm0, [rsp]
00007b78f51d4561  vmovaps xmm1, [rsp+0x10]
00007b78f51d4567  vmovaps xmm2, [rsp+0x20]
00007b78f51d456d  vmovaps xmm3, [rsp+0x30]
00007b78f51d4573  vmovaps xmm4, [rsp+0x40]
00007b78f51d4579  vmovaps xmm5, [rsp+0x50]
00007b78f51d457f  vmovaps xmm6, [rsp+0x60]
00007b78f51d4585  vmovaps xmm7, [rsp+0x70]
00007b78f51d458b  vmovaps xmm8, [rsp+0x80]
00007b78f51d4594  vmovaps xmm9, [rsp+0x90]
00007b78f51d459d  vmovaps xmm10, [rsp+0xA0]
00007b78f51d45a6  vmovaps xmm12, [rsp+0xB0]
00007b78f51d45af  vmovaps xmm13, [rsp+0xC0]
00007b78f51d45b8  vmovaps xmm14, [rsp+0xD0]
00007b78f51d45c1  vmovaps xmm15, [rsp+0xE0]
00007b78f51d45ca  add rsp, 0xF0
00007b78f51d45d1  pop r11
00007b78f51d45d3  pop r10
00007b78f51d45d5  pop r9
00007b78f51d45d7  pop r8
00007b78f51d45d9  pop rsi
00007b78f51d45da  pop rdi
00007b78f51d45db  pop rdx
00007b78f51d45dc  pop rcx
00007b78f51d45dd  pop rax
00007b78f51d45de  add rsp, 0x08
00007b78f51d45e2  jmp 0x00007B78F51D0123
00007b78f51d45e7  sub rsp, 0x08
00007b78f51d45eb  push rax
00007b78f51d45ec  push rcx
00007b78f51d45ed  push rdx
00007b78f51d45ee  push rdi
00007b78f51d45ef  push rsi
00007b78f51d45f0  push r8
00007b78f51d45f2  push r9
00007b78f51d45f4  push r10
00007b78f51d45f6  push r11
00007b78f51d45f8  sub rsp, 0xF0
00007b78f51d45ff  vmovaps [rsp], xmm0
00007b78f51d4604  vmovaps [rsp+0x10], xmm1
00007b78f51d460a  vmovaps [rsp+0x20], xmm2
00007b78f51d4610  vmovaps [rsp+0x30], xmm3
00007b78f51d4616  vmovaps [rsp+0x40], xmm4
00007b78f51d461c  vmovaps [rsp+0x50], xmm5
00007b78f51d4622  vmovaps [rsp+0x60], xmm6
00007b78f51d4628  vmovaps [rsp+0x70], xmm7
00007b78f51d462e  vmovaps [rsp+0x80], xmm8
00007b78f51d4637  vmovaps [rsp+0x90], xmm9
00007b78f51d4640  vmovaps [rsp+0xA0], xmm10
00007b78f51d4649  vmovaps [rsp+0xB0], xmm11
00007b78f51d4652  vmovaps [rsp+0xC0], xmm12
00007b78f51d465b  vmovaps [rsp+0xD0], xmm13
00007b78f51d4664  vmovaps [rsp+0xE0], xmm14
00007b78f51d466d  sub rsp, 0x30
00007b78f51d4671  movaps [rsp], xmm15
00007b78f51d4676  movaps [rsp+0x10], xmm10
00007b78f51d467c  movaps [rsp+0x20], xmm13
00007b78f51d4682  lea rdi, [rsp]
00007b78f51d4686  mov esi, 0x00
00007b78f51d468b  mov rax, 0x597478C09530
00007b78f51d4695  call rax
00007b78f51d4697  movaps xmm15, [rsp]
00007b78f51d469c  add rsp, 0x30
00007b78f51d46a0  vmovaps xmm0, [rsp]
00007b78f51d46a5  vmovaps xmm1, [rsp+0x10]
00007b78f51d46ab  vmovaps xmm2, [rsp+0x20]
00007b78f51d46b1  vmovaps xmm3, [rsp+0x30]
00007b78f51d46b7  vmovaps xmm4, [rsp+0x40]
00007b78f51d46bd  vmovaps xmm5, [rsp+0x50]
00007b78f51d46c3  vmovaps xmm6, [rsp+0x60]
00007b78f51d46c9  vmovaps xmm7, [rsp+0x70]
00007b78f51d46cf  vmovaps xmm8, [rsp+0x80]
00007b78f51d46d8  vmovaps xmm9, [rsp+0x90]
00007b78f51d46e1  vmovaps xmm10, [rsp+0xA0]
00007b78f51d46ea  vmovaps xmm11, [rsp+0xB0]
00007b78f51d46f3  vmovaps xmm12, [rsp+0xC0]
00007b78f51d46fc  vmovaps xmm13, [rsp+0xD0]
00007b78f51d4705  vmovaps xmm14, [rsp+0xE0]
00007b78f51d470e  add rsp, 0xF0
00007b78f51d4715  pop r11
00007b78f51d4717  pop r10
00007b78f51d4719  pop r9
00007b78f51d471b  pop r8
00007b78f51d471d  pop rsi
00007b78f51d471e  pop rdi
00007b78f51d471f  pop rdx
00007b78f51d4720  pop rcx
00007b78f51d4721  pop rax
00007b78f51d4722  add rsp, 0x08
00007b78f51d4726  jmp 0x00007B78F51D013D
00007b78f51d472b  sub rsp, 0x08
00007b78f51d472f  push rax
00007b78f51d4730  push rcx
00007b78f51d4731  push rdx
00007b78f51d4732  push rdi
00007b78f51d4733  push rsi
00007b78f51d4734  push r8
00007b78f51d4736  push r9
00007b78f51d4738  push r10
00007b78f51d473a  push r11
00007b78f51d473c  sub rsp, 0xF0
00007b78f51d4743  vmovaps [rsp], xmm0
00007b78f51d4748  vmovaps [rsp+0x10], xmm1
00007b78f51d474e  vmovaps [rsp+0x20], xmm2
00007b78f51d4754  vmovaps [rsp+0x30], xmm3
00007b78f51d475a  vmovaps [rsp+0x40], xmm4
00007b78f51d4760  vmovaps [rsp+0x50], xmm5
00007b78f51d4766  vmovaps [rsp+0x60], xmm6
00007b78f51d476c  vmovaps [rsp+0x70], xmm7
00007b78f51d4772  vmovaps [rsp+0x80], xmm8
00007b78f51d477b  vmovaps [rsp+0x90], xmm9
00007b78f51d4784  vmovaps [rsp+0xA0], xmm11
00007b78f51d478d  vmovaps [rsp+0xB0], xmm12
00007b78f51d4796  vmovaps [rsp+0xC0], xmm13
00007b78f51d479f  vmovaps [rsp+0xD0], xmm14
00007b78f51d47a8  vmovaps [rsp+0xE0], xmm15
00007b78f51d47b1  sub rsp, 0x30
00007b78f51d47b5  movaps [rsp], xmm10
00007b78f51d47ba  movaps [rsp+0x10], xmm7
00007b78f51d47bf  movaps [rsp+0x20], xmm13
00007b78f51d47c5  lea rdi, [rsp]
00007b78f51d47c9  mov esi, 0x00
00007b78f51d47ce  mov rax, 0x597478C09530
00007b78f51d47d8  call rax
00007b78f51d47da  movaps xmm10, [rsp]
00007b78f51d47df  add rsp, 0x30
00007b78f51d47e3  vmovaps xmm0, [rsp]
00007b78f51d47e8  vmovaps xmm1, [rsp+0x10]
00007b78f51d47ee  vmovaps xmm2, [rsp+0x20]
00007b78f51d47f4  vmovaps xmm3, [rsp+0x30]
00007b78f51d47fa  vmovaps xmm4, [rsp+0x40]
00007b78f51d4800  vmovaps xmm5, [rsp+0x50]
00007b78f51d4806  vmovaps xmm6, [rsp+0x60]
00007b78f51d480c  vmovaps xmm7, [rsp+0x70]
00007b78f51d4812  vmovaps xmm8, [rsp+0x80]
00007b78f51d481b  vmovaps xmm9, [rsp+0x90]
00007b78f51d4824  vmovaps xmm11, [rsp+0xA0]
00007b78f51d482d  vmovaps xmm12, [rsp+0xB0]
00007b78f51d4836  vmovaps xmm13, [rsp+0xC0]
00007b78f51d483f  vmovaps xmm14, [rsp+0xD0]
00007b78f51d4848  vmovaps xmm15, [rsp+0xE0]
00007b78f51d4851  add rsp, 0xF0
00007b78f51d4858  pop r11
00007b78f51d485a  pop r10
00007b78f51d485c  pop r9
00007b78f51d485e  pop r8
00007b78f51d4860  pop rsi
00007b78f51d4861  pop rdi
00007b78f51d4862  pop rdx
00007b78f51d4863  pop rcx
00007b78f51d4864  pop rax
00007b78f51d4865  add rsp, 0x08
00007b78f51d4869  jmp 0x00007B78F51D0169
00007b78f51d486e  sub rsp, 0x08
00007b78f51d4872  push rax
00007b78f51d4873  push rcx
00007b78f51d4874  push rdx
00007b78f51d4875  push rdi
00007b78f51d4876  push rsi
00007b78f51d4877  push r8
00007b78f51d4879  push r9
00007b78f51d487b  push r10
00007b78f51d487d  push r11
00007b78f51d487f  sub rsp, 0xF0
00007b78f51d4886  vmovaps [rsp], xmm0
00007b78f51d488b  vmovaps [rsp+0x10], xmm1
00007b78f51d4891  vmovaps [rsp+0x20], xmm2
00007b78f51d4897  vmovaps [rsp+0x30], xmm3
00007b78f51d489d  vmovaps [rsp+0x40], xmm4
00007b78f51d48a3  vmovaps [rsp+0x50], xmm5
00007b78f51d48a9  vmovaps [rsp+0x60], xmm6
00007b78f51d48af  vmovaps [rsp+0x70], xmm7
00007b78f51d48b5  vmovaps [rsp+0x80], xmm8
00007b78f51d48be  vmovaps [rsp+0x90], xmm9
00007b78f51d48c7  vmovaps [rsp+0xA0], xmm10
00007b78f51d48d0  vmovaps [rsp+0xB0], xmm11
00007b78f51d48d9  vmovaps [rsp+0xC0], xmm12
00007b78f51d48e2  vmovaps [rsp+0xD0], xmm14
00007b78f51d48eb  vmovaps [rsp+0xE0], xmm15
00007b78f51d48f4  sub rsp, 0x30
00007b78f51d48f8  movaps [rsp], xmm13
00007b78f51d48fd  movaps [rsp+0x10], xmm1
00007b78f51d4902  movaps [rsp+0x20], xmm8
00007b78f51d4908  lea rdi, [rsp]
00007b78f51d490c  mov esi, 0x00
00007b78f51d4911  mov rax, 0x597478C09530
00007b78f51d491b  call rax
00007b78f51d491d  movaps xmm13, [rsp]
00007b78f51d4922  add rsp, 0x30
00007b78f51d4926  vmovaps xmm0, [rsp]
00007b78f51d492b  vmovaps xmm1, [rsp+0x10]
00007b78f51d4931  vmovaps xmm2, [rsp+0x20]
00007b78f51d4937  vmovaps xmm3, [rsp+0x30]
00007b78f51d493d  vmovaps xmm4, [rsp+0x40]
00007b78f51d4943  vmovaps xmm5, [rsp+0x50]
00007b78f51d4949  vmovaps xmm6, [rsp+0x60]
00007b78f51d494f  vmovaps xmm7, [rsp+0x70]
00007b78f51d4955  vmovaps xmm8, [rsp+0x80]
00007b78f51d495e  vmovaps xmm9, [rsp+0x90]
00007b78f51d4967  vmovaps xmm10, [rsp+0xA0]
00007b78f51d4970  vmovaps xmm11, [rsp+0xB0]
00007b78f51d4979  vmovaps xmm12, [rsp+0xC0]
00007b78f51d4982  vmovaps xmm14, [rsp+0xD0]
00007b78f51d498b  vmovaps xmm15, [rsp+0xE0]
00007b78f51d4994  add rsp, 0xF0
00007b78f51d499b  pop r11
00007b78f51d499d  pop r10
00007b78f51d499f  pop r9
00007b78f51d49a1  pop r8
00007b78f51d49a3  pop rsi
00007b78f51d49a4  pop rdi
00007b78f51d49a5  pop rdx
00007b78f51d49a6  pop rcx
00007b78f51d49a7  pop rax
00007b78f51d49a8  add rsp, 0x08
00007b78f51d49ac  jmp 0x00007B78F51D0183
00007b78f51d49b1  call 0x00007B78F4FFF430
00007b78f51d49b6  jmp 0x00007B78F51D018D
00007b78f51d49bb  sub rsp, 0x08
00007b78f51d49bf  push rax
00007b78f51d49c0  push rcx
00007b78f51d49c1  push rdx
00007b78f51d49c2  push rdi
00007b78f51d49c3  push rsi
00007b78f51d49c4  push r8
00007b78f51d49c6  push r9
00007b78f51d49c8  push r10
00007b78f51d49ca  push r11
00007b78f51d49cc  sub rsp, 0xF0
00007b78f51d49d3  vmovaps [rsp], xmm0
00007b78f51d49d8  vmovaps [rsp+0x10], xmm1
00007b78f51d49de  vmovaps [rsp+0x20], xmm2
00007b78f51d49e4  vmovaps [rsp+0x30], xmm3
00007b78f51d49ea  vmovaps [rsp+0x40], xmm4
00007b78f51d49f0  vmovaps [rsp+0x50], xmm5
00007b78f51d49f6  vmovaps [rsp+0x60], xmm6
00007b78f51d49fc  vmovaps [rsp+0x70], xmm7
00007b78f51d4a02  vmovaps [rsp+0x80], xmm9
00007b78f51d4a0b  vmovaps [rsp+0x90], xmm10
00007b78f51d4a14  vmovaps [rsp+0xA0], xmm11
00007b78f51d4a1d  vmovaps [rsp+0xB0], xmm12
00007b78f51d4a26  vmovaps [rsp+0xC0], xmm13
00007b78f51d4a2f  vmovaps [rsp+0xD0], xmm14
00007b78f51d4a38  vmovaps [rsp+0xE0], xmm15
00007b78f51d4a41  sub rsp, 0x30
00007b78f51d4a45  movaps [rsp], xmm8
00007b78f51d4a4a  movaps [rsp+0x10], xmm14
00007b78f51d4a50  movaps [rsp+0x20], xmm9
00007b78f51d4a56  lea rdi, [rsp]
00007b78f51d4a5a  mov esi, 0x00
00007b78f51d4a5f  mov rax, 0x597478C09530
00007b78f51d4a69  call rax
00007b78f51d4a6b  movaps xmm8, [rsp]
00007b78f51d4a70  add rsp, 0x30
00007b78f51d4a74  vmovaps xmm0, [rsp]
00007b78f51d4a79  vmovaps xmm1, [rsp+0x10]
00007b78f51d4a7f  vmovaps xmm2, [rsp+0x20]
00007b78f51d4a85  vmovaps xmm3, [rsp+0x30]
00007b78f51d4a8b  vmovaps xmm4, [rsp+0x40]
00007b78f51d4a91  vmovaps xmm5, [rsp+0x50]
00007b78f51d4a97  vmovaps xmm6, [rsp+0x60]
00007b78f51d4a9d  vmovaps xmm7, [rsp+0x70]
00007b78f51d4aa3  vmovaps xmm9, [rsp+0x80]
00007b78f51d4aac  vmovaps xmm10, [rsp+0x90]
00007b78f51d4ab5  vmovaps xmm11, [rsp+0xA0]
00007b78f51d4abe  vmovaps xmm12, [rsp+0xB0]
00007b78f51d4ac7  vmovaps xmm13, [rsp+0xC0]
00007b78f51d4ad0  vmovaps xmm14, [rsp+0xD0]
00007b78f51d4ad9  vmovaps xmm15, [rsp+0xE0]
00007b78f51d4ae2  add rsp, 0xF0
00007b78f51d4ae9  pop r11
00007b78f51d4aeb  pop r10
00007b78f51d4aed  pop r9
00007b78f51d4aef  pop r8
00007b78f51d4af1  pop rsi
00007b78f51d4af2  pop rdi
00007b78f51d4af3  pop rdx
00007b78f51d4af4  pop rcx
00007b78f51d4af5  pop rax
00007b78f51d4af6  add rsp, 0x08
00007b78f51d4afa  jmp 0x00007B78F51D01AF
00007b78f51d4aff  sub rsp, 0x08
00007b78f51d4b03  push rax
00007b78f51d4b04  push rcx
00007b78f51d4b05  push rdx
00007b78f51d4b06  push rdi
00007b78f51d4b07  push rsi
00007b78f51d4b08  push r8
00007b78f51d4b0a  push r9
00007b78f51d4b0c  push r10
00007b78f51d4b0e  push r11
00007b78f51d4b10  sub rsp, 0xF0
00007b78f51d4b17  vmovaps [rsp], xmm0
00007b78f51d4b1c  vmovaps [rsp+0x10], xmm1
00007b78f51d4b22  vmovaps [rsp+0x20], xmm2
00007b78f51d4b28  vmovaps [rsp+0x30], xmm3
00007b78f51d4b2e  vmovaps [rsp+0x40], xmm4
00007b78f51d4b34  vmovaps [rsp+0x50], xmm5
00007b78f51d4b3a  vmovaps [rsp+0x60], xmm6
00007b78f51d4b40  vmovaps [rsp+0x70], xmm7
00007b78f51d4b46  vmovaps [rsp+0x80], xmm8
00007b78f51d4b4f  vmovaps [rsp+0x90], xmm10
00007b78f51d4b58  vmovaps [rsp+0xA0], xmm11
00007b78f51d4b61  vmovaps [rsp+0xB0], xmm12
00007b78f51d4b6a  vmovaps [rsp+0xC0], xmm13
00007b78f51d4b73  vmovaps [rsp+0xD0], xmm14
00007b78f51d4b7c  vmovaps [rsp+0xE0], xmm15
00007b78f51d4b85  sub rsp, 0x30
00007b78f51d4b89  movaps [rsp], xmm9
00007b78f51d4b8e  movaps [rsp+0x10], xmm1
00007b78f51d4b93  movaps [rsp+0x20], xmm14
00007b78f51d4b99  lea rdi, [rsp]
00007b78f51d4b9d  mov esi, 0x00
00007b78f51d4ba2  mov rax, 0x597478C09530
00007b78f51d4bac  call rax
00007b78f51d4bae  movaps xmm9, [rsp]
00007b78f51d4bb3  add rsp, 0x30
00007b78f51d4bb7  vmovaps xmm0, [rsp]
00007b78f51d4bbc  vmovaps xmm1, [rsp+0x10]
00007b78f51d4bc2  vmovaps xmm2, [rsp+0x20]
00007b78f51d4bc8  vmovaps xmm3, [rsp+0x30]
00007b78f51d4bce  vmovaps xmm4, [rsp+0x40]
00007b78f51d4bd4  vmovaps xmm5, [rsp+0x50]
00007b78f51d4bda  vmovaps xmm6, [rsp+0x60]
00007b78f51d4be0  vmovaps xmm7, [rsp+0x70]
00007b78f51d4be6  vmovaps xmm8, [rsp+0x80]
00007b78f51d4bef  vmovaps xmm10, [rsp+0x90]
00007b78f51d4bf8  vmovaps xmm11, [rsp+0xA0]
00007b78f51d4c01  vmovaps xmm12, [rsp+0xB0]
00007b78f51d4c0a  vmovaps xmm13, [rsp+0xC0]
00007b78f51d4c13  vmovaps xmm14, [rsp+0xD0]
00007b78f51d4c1c  vmovaps xmm15, [rsp+0xE0]
00007b78f51d4c25  add rsp, 0xF0
00007b78f51d4c2c  pop r11
00007b78f51d4c2e  pop r10
00007b78f51d4c30  pop r9
00007b78f51d4c32  pop r8
00007b78f51d4c34  pop rsi
00007b78f51d4c35  pop rdi
00007b78f51d4c36  pop rdx
00007b78f51d4c37  pop rcx
00007b78f51d4c38  pop rax
00007b78f51d4c39  add rsp, 0x08
00007b78f51d4c3d  jmp 0x00007B78F51D01DD
00007b78f51d4c42  sub rsp, 0x08
00007b78f51d4c46  push rax
00007b78f51d4c47  push rcx
00007b78f51d4c48  push rdx
00007b78f51d4c49  push rdi
00007b78f51d4c4a  push rsi
00007b78f51d4c4b  push r8
00007b78f51d4c4d  push r9
00007b78f51d4c4f  push r10
00007b78f51d4c51  push r11
00007b78f51d4c53  sub rsp, 0xF0
00007b78f51d4c5a  vmovaps [rsp], xmm0
00007b78f51d4c5f  vmovaps [rsp+0x10], xmm1
00007b78f51d4c65  vmovaps [rsp+0x20], xmm2
00007b78f51d4c6b  vmovaps [rsp+0x30], xmm3
00007b78f51d4c71  vmovaps [rsp+0x40], xmm4
00007b78f51d4c77  vmovaps [rsp+0x50], xmm5
00007b78f51d4c7d  vmovaps [rsp+0x60], xmm6
00007b78f51d4c83  vmovaps [rsp+0x70], xmm7
00007b78f51d4c89  vmovaps [rsp+0x80], xmm8
00007b78f51d4c92  vmovaps [rsp+0x90], xmm9
00007b78f51d4c9b  vmovaps [rsp+0xA0], xmm10
00007b78f51d4ca4  vmovaps [rsp+0xB0], xmm11
00007b78f51d4cad  vmovaps [rsp+0xC0], xmm12
00007b78f51d4cb6  vmovaps [rsp+0xD0], xmm13
00007b78f51d4cbf  vmovaps [rsp+0xE0], xmm15
00007b78f51d4cc8  sub rsp, 0x30
00007b78f51d4ccc  movaps [rsp], xmm14
00007b78f51d4cd1  movaps [rsp+0x10], xmm4
00007b78f51d4cd6  movaps [rsp+0x20], xmm1
00007b78f51d4cdb  lea rdi, [rsp]
00007b78f51d4cdf  mov esi, 0x00
00007b78f51d4ce4  mov rax, 0x597478C09530
00007b78f51d4cee  call rax
00007b78f51d4cf0  movaps xmm14, [rsp]
00007b78f51d4cf5  add rsp, 0x30
00007b78f51d4cf9  vmovaps xmm0, [rsp]
00007b78f51d4cfe  vmovaps xmm1, [rsp+0x10]
00007b78f51d4d04  vmovaps xmm2, [rsp+0x20]
00007b78f51d4d0a  vmovaps xmm3, [rsp+0x30]
00007b78f51d4d10  vmovaps xmm4, [rsp+0x40]
00007b78f51d4d16  vmovaps xmm5, [rsp+0x50]
00007b78f51d4d1c  vmovaps xmm6, [rsp+0x60]
00007b78f51d4d22  vmovaps xmm7, [rsp+0x70]
00007b78f51d4d28  vmovaps xmm8, [rsp+0x80]
00007b78f51d4d31  vmovaps xmm9, [rsp+0x90]
00007b78f51d4d3a  vmovaps xmm10, [rsp+0xA0]
00007b78f51d4d43  vmovaps xmm11, [rsp+0xB0]
00007b78f51d4d4c  vmovaps xmm12, [rsp+0xC0]
00007b78f51d4d55  vmovaps xmm13, [rsp+0xD0]
00007b78f51d4d5e  vmovaps xmm15, [rsp+0xE0]
00007b78f51d4d67  add rsp, 0xF0
00007b78f51d4d6e  pop r11
00007b78f51d4d70  pop r10
00007b78f51d4d72  pop r9
00007b78f51d4d74  pop r8
00007b78f51d4d76  pop rsi
00007b78f51d4d77  pop rdi
00007b78f51d4d78  pop rdx
00007b78f51d4d79  pop rcx
00007b78f51d4d7a  pop rax
00007b78f51d4d7b  add rsp, 0x08
00007b78f51d4d7f  jmp 0x00007B78F51D0203
00007b78f51d4d84  sub rsp, 0x08
00007b78f51d4d88  push rax
00007b78f51d4d89  push rcx
00007b78f51d4d8a  push rdx
00007b78f51d4d8b  push rdi
00007b78f51d4d8c  push rsi
00007b78f51d4d8d  push r8
00007b78f51d4d8f  push r9
00007b78f51d4d91  push r10
00007b78f51d4d93  push r11
00007b78f51d4d95  sub rsp, 0xF0
00007b78f51d4d9c  vmovaps [rsp], xmm0
00007b78f51d4da1  vmovaps [rsp+0x10], xmm2
00007b78f51d4da7  vmovaps [rsp+0x20], xmm3
00007b78f51d4dad  vmovaps [rsp+0x30], xmm4
00007b78f51d4db3  vmovaps [rsp+0x40], xmm5
00007b78f51d4db9  vmovaps [rsp+0x50], xmm6
00007b78f51d4dbf  vmovaps [rsp+0x60], xmm7
00007b78f51d4dc5  vmovaps [rsp+0x70], xmm8
00007b78f51d4dcb  vmovaps [rsp+0x80], xmm9
00007b78f51d4dd4  vmovaps [rsp+0x90], xmm10
00007b78f51d4ddd  vmovaps [rsp+0xA0], xmm11
00007b78f51d4de6  vmovaps [rsp+0xB0], xmm12
00007b78f51d4def  vmovaps [rsp+0xC0], xmm13
00007b78f51d4df8  vmovaps [rsp+0xD0], xmm14
00007b78f51d4e01  vmovaps [rsp+0xE0], xmm15
00007b78f51d4e0a  sub rsp, 0x30
00007b78f51d4e0e  movaps [rsp], xmm1
00007b78f51d4e12  movaps [rsp+0x10], xmm12
00007b78f51d4e18  movaps [rsp+0x20], xmm11
00007b78f51d4e1e  lea rdi, [rsp]
00007b78f51d4e22  mov esi, 0x00
00007b78f51d4e27  mov rax, 0x597478C09530
00007b78f51d4e31  call rax
00007b78f51d4e33  movaps xmm1, [rsp]
00007b78f51d4e37  add rsp, 0x30
00007b78f51d4e3b  vmovaps xmm0, [rsp]
00007b78f51d4e40  vmovaps xmm2, [rsp+0x10]
00007b78f51d4e46  vmovaps xmm3, [rsp+0x20]
00007b78f51d4e4c  vmovaps xmm4, [rsp+0x30]
00007b78f51d4e52  vmovaps xmm5, [rsp+0x40]
00007b78f51d4e58  vmovaps xmm6, [rsp+0x50]
00007b78f51d4e5e  vmovaps xmm7, [rsp+0x60]
00007b78f51d4e64  vmovaps xmm8, [rsp+0x70]
00007b78f51d4e6a  vmovaps xmm9, [rsp+0x80]
00007b78f51d4e73  vmovaps xmm10, [rsp+0x90]
00007b78f51d4e7c  vmovaps xmm11, [rsp+0xA0]
00007b78f51d4e85  vmovaps xmm12, [rsp+0xB0]
00007b78f51d4e8e  vmovaps xmm13, [rsp+0xC0]
00007b78f51d4e97  vmovaps xmm14, [rsp+0xD0]
00007b78f51d4ea0  vmovaps xmm15, [rsp+0xE0]
00007b78f51d4ea9  add rsp, 0xF0
00007b78f51d4eb0  pop r11
00007b78f51d4eb2  pop r10
00007b78f51d4eb4  pop r9
00007b78f51d4eb6  pop r8
00007b78f51d4eb8  pop rsi
00007b78f51d4eb9  pop rdi
00007b78f51d4eba  pop rdx
00007b78f51d4ebb  pop rcx
00007b78f51d4ebc  pop rax
00007b78f51d4ebd  add rsp, 0x08
00007b78f51d4ec1  jmp 0x00007B78F51D0224
00007b78f51d4ec6  call 0x00007B78F50E20A0
00007b78f51d4ecb  jmp 0x00007B78F51D0232
00007b78f51d4ed0  call 0x00007B78F5009D70
00007b78f51d4ed5  jmp 0x00007B78F51D023C
00007b78f51d4eda  sub rsp, 0x08
00007b78f51d4ede  push rax
00007b78f51d4edf  push rcx
00007b78f51d4ee0  push rdx
00007b78f51d4ee1  push rdi
00007b78f51d4ee2  push rsi
00007b78f51d4ee3  push r8
00007b78f51d4ee5  push r9
00007b78f51d4ee7  push r10
00007b78f51d4ee9  push r11
00007b78f51d4eeb  sub rsp, 0xF0
00007b78f51d4ef2  vmovaps [rsp], xmm0
00007b78f51d4ef7  vmovaps [rsp+0x10], xmm1
00007b78f51d4efd  vmovaps [rsp+0x20], xmm2
00007b78f51d4f03  vmovaps [rsp+0x30], xmm3
00007b78f51d4f09  vmovaps [rsp+0x40], xmm4
00007b78f51d4f0f  vmovaps [rsp+0x50], xmm5
00007b78f51d4f15  vmovaps [rsp+0x60], xmm6
00007b78f51d4f1b  vmovaps [rsp+0x70], xmm8
00007b78f51d4f21  vmovaps [rsp+0x80], xmm9
00007b78f51d4f2a  vmovaps [rsp+0x90], xmm10
00007b78f51d4f33  vmovaps [rsp+0xA0], xmm11
00007b78f51d4f3c  vmovaps [rsp+0xB0], xmm12
00007b78f51d4f45  vmovaps [rsp+0xC0], xmm13
00007b78f51d4f4e  vmovaps [rsp+0xD0], xmm14
00007b78f51d4f57  vmovaps [rsp+0xE0], xmm15
00007b78f51d4f60  sub rsp, 0x30
00007b78f51d4f64  movaps [rsp], xmm7
00007b78f51d4f68  movaps [rsp+0x10], xmm15
00007b78f51d4f6e  movaps [rsp+0x20], xmm10
00007b78f51d4f74  lea rdi, [rsp]
00007b78f51d4f78  mov esi, 0x00
00007b78f51d4f7d  mov rax, 0x597478C09530
00007b78f51d4f87  call rax
00007b78f51d4f89  movaps xmm7, [rsp]
00007b78f51d4f8d  add rsp, 0x30
00007b78f51d4f91  vmovaps xmm0, [rsp]
00007b78f51d4f96  vmovaps xmm1, [rsp+0x10]
00007b78f51d4f9c  vmovaps xmm2, [rsp+0x20]
00007b78f51d4fa2  vmovaps xmm3, [rsp+0x30]
00007b78f51d4fa8  vmovaps xmm4, [rsp+0x40]
00007b78f51d4fae  vmovaps xmm5, [rsp+0x50]
00007b78f51d4fb4  vmovaps xmm6, [rsp+0x60]
00007b78f51d4fba  vmovaps xmm8, [rsp+0x70]
00007b78f51d4fc0  vmovaps xmm9, [rsp+0x80]
00007b78f51d4fc9  vmovaps xmm10, [rsp+0x90]
00007b78f51d4fd2  vmovaps xmm11, [rsp+0xA0]
00007b78f51d4fdb  vmovaps xmm12, [rsp+0xB0]
00007b78f51d4fe4  vmovaps xmm13, [rsp+0xC0]
00007b78f51d4fed  vmovaps xmm14, [rsp+0xD0]
00007b78f51d4ff6  vmovaps xmm15, [rsp+0xE0]
00007b78f51d4fff  add rsp, 0xF0
00007b78f51d5006  pop r11
00007b78f51d5008  pop r10
00007b78f51d500a  pop r9
00007b78f51d500c  pop r8
00007b78f51d500e  pop rsi
00007b78f51d500f  pop rdi
00007b78f51d5010  pop rdx
00007b78f51d5011  pop rcx
00007b78f51d5012  pop rax
00007b78f51d5013  add rsp, 0x08
00007b78f51d5017  jmp 0x00007B78F51D025D
00007b78f51d501c  sub rsp, 0x08
00007b78f51d5020  push rax
00007b78f51d5021  push rcx
00007b78f51d5022  push rdx
00007b78f51d5023  push rdi
00007b78f51d5024  push rsi
00007b78f51d5025  push r8
00007b78f51d5027  push r9
00007b78f51d5029  push r10
00007b78f51d502b  push r11
00007b78f51d502d  sub rsp, 0xF0
00007b78f51d5034  vmovaps [rsp], xmm0
00007b78f51d5039  vmovaps [rsp+0x10], xmm1
00007b78f51d503f  vmovaps [rsp+0x20], xmm2
00007b78f51d5045  vmovaps [rsp+0x30], xmm3
00007b78f51d504b  vmovaps [rsp+0x40], xmm4
00007b78f51d5051  vmovaps [rsp+0x50], xmm5
00007b78f51d5057  vmovaps [rsp+0x60], xmm6
00007b78f51d505d  vmovaps [rsp+0x70], xmm7
00007b78f51d5063  vmovaps [rsp+0x80], xmm8
00007b78f51d506c  vmovaps [rsp+0x90], xmm9
00007b78f51d5075  vmovaps [rsp+0xA0], xmm11
00007b78f51d507e  vmovaps [rsp+0xB0], xmm12
00007b78f51d5087  vmovaps [rsp+0xC0], xmm13
00007b78f51d5090  vmovaps [rsp+0xD0], xmm14
00007b78f51d5099  vmovaps [rsp+0xE0], xmm15
00007b78f51d50a2  sub rsp, 0x30
00007b78f51d50a6  movaps [rsp], xmm10
00007b78f51d50ab  movaps [rsp+0x10], xmm11
00007b78f51d50b1  movaps [rsp+0x20], xmm15
00007b78f51d50b7  lea rdi, [rsp]
00007b78f51d50bb  mov esi, 0x00
00007b78f51d50c0  mov rax, 0x597478C09530
00007b78f51d50ca  call rax
00007b78f51d50cc  movaps xmm10, [rsp]
00007b78f51d50d1  add rsp, 0x30
00007b78f51d50d5  vmovaps xmm0, [rsp]
00007b78f51d50da  vmovaps xmm1, [rsp+0x10]
00007b78f51d50e0  vmovaps xmm2, [rsp+0x20]
00007b78f51d50e6  vmovaps xmm3, [rsp+0x30]
00007b78f51d50ec  vmovaps xmm4, [rsp+0x40]
00007b78f51d50f2  vmovaps xmm5, [rsp+0x50]
00007b78f51d50f8  vmovaps xmm6, [rsp+0x60]
00007b78f51d50fe  vmovaps xmm7, [rsp+0x70]
00007b78f51d5104  vmovaps xmm8, [rsp+0x80]
00007b78f51d510d  vmovaps xmm9, [rsp+0x90]
00007b78f51d5116  vmovaps xmm11, [rsp+0xA0]
00007b78f51d511f  vmovaps xmm12, [rsp+0xB0]
00007b78f51d5128  vmovaps xmm13, [rsp+0xC0]
00007b78f51d5131  vmovaps xmm14, [rsp+0xD0]
00007b78f51d513a  vmovaps xmm15, [rsp+0xE0]
00007b78f51d5143  add rsp, 0xF0
00007b78f51d514a  pop r11
00007b78f51d514c  pop r10
00007b78f51d514e  pop r9
00007b78f51d5150  pop r8
00007b78f51d5152  pop rsi
00007b78f51d5153  pop rdi
00007b78f51d5154  pop rdx
00007b78f51d5155  pop rcx
00007b78f51d5156  pop rax
00007b78f51d5157  add rsp, 0x08
00007b78f51d515b  jmp 0x00007B78F51D028B
00007b78f51d5160  sub rsp, 0x08
00007b78f51d5164  push rax
00007b78f51d5165  push rcx
00007b78f51d5166  push rdx
00007b78f51d5167  push rdi
00007b78f51d5168  push rsi
00007b78f51d5169  push r8
00007b78f51d516b  push r9
00007b78f51d516d  push r10
00007b78f51d516f  push r11
00007b78f51d5171  sub rsp, 0xF0
00007b78f51d5178  vmovaps [rsp], xmm0
00007b78f51d517d  vmovaps [rsp+0x10], xmm1
00007b78f51d5183  vmovaps [rsp+0x20], xmm2
00007b78f51d5189  vmovaps [rsp+0x30], xmm3
00007b78f51d518f  vmovaps [rsp+0x40], xmm4
00007b78f51d5195  vmovaps [rsp+0x50], xmm5
00007b78f51d519b  vmovaps [rsp+0x60], xmm6
00007b78f51d51a1  vmovaps [rsp+0x70], xmm7
00007b78f51d51a7  vmovaps [rsp+0x80], xmm8
00007b78f51d51b0  vmovaps [rsp+0x90], xmm9
00007b78f51d51b9  vmovaps [rsp+0xA0], xmm10
00007b78f51d51c2  vmovaps [rsp+0xB0], xmm12
00007b78f51d51cb  vmovaps [rsp+0xC0], xmm13
00007b78f51d51d4  vmovaps [rsp+0xD0], xmm14
00007b78f51d51dd  vmovaps [rsp+0xE0], xmm15
00007b78f51d51e6  sub rsp, 0x30
00007b78f51d51ea  movaps [rsp], xmm11
00007b78f51d51ef  movaps [rsp+0x10], xmm12
00007b78f51d51f5  movaps [rsp+0x20], xmm15
00007b78f51d51fb  lea rdi, [rsp]
00007b78f51d51ff  mov esi, 0x00
00007b78f51d5204  mov rax, 0x597478C09530
00007b78f51d520e  call rax
00007b78f51d5210  movaps xmm11, [rsp]
00007b78f51d5215  add rsp, 0x30
00007b78f51d5219  vmovaps xmm0, [rsp]
00007b78f51d521e  vmovaps xmm1, [rsp+0x10]
00007b78f51d5224  vmovaps xmm2, [rsp+0x20]
00007b78f51d522a  vmovaps xmm3, [rsp+0x30]
00007b78f51d5230  vmovaps xmm4, [rsp+0x40]
00007b78f51d5236  vmovaps xmm5, [rsp+0x50]
00007b78f51d523c  vmovaps xmm6, [rsp+0x60]
00007b78f51d5242  vmovaps xmm7, [rsp+0x70]
00007b78f51d5248  vmovaps xmm8, [rsp+0x80]
00007b78f51d5251  vmovaps xmm9, [rsp+0x90]
00007b78f51d525a  vmovaps xmm10, [rsp+0xA0]
00007b78f51d5263  vmovaps xmm12, [rsp+0xB0]
00007b78f51d526c  vmovaps xmm13, [rsp+0xC0]
00007b78f51d5275  vmovaps xmm14, [rsp+0xD0]
00007b78f51d527e  vmovaps xmm15, [rsp+0xE0]
00007b78f51d5287  add rsp, 0xF0
00007b78f51d528e  pop r11
00007b78f51d5290  pop r10
00007b78f51d5292  pop r9
00007b78f51d5294  pop r8
00007b78f51d5296  pop rsi
00007b78f51d5297  pop rdi
00007b78f51d5298  pop rdx
00007b78f51d5299  pop rcx
00007b78f51d529a  pop rax
00007b78f51d529b  add rsp, 0x08
00007b78f51d529f  jmp 0x00007B78F51D02B9
00007b78f51d52a4  sub rsp, 0x08
00007b78f51d52a8  push rax
00007b78f51d52a9  push rcx
00007b78f51d52aa  push rdx
00007b78f51d52ab  push rdi
00007b78f51d52ac  push rsi
00007b78f51d52ad  push r8
00007b78f51d52af  push r9
00007b78f51d52b1  push r10
00007b78f51d52b3  push r11
00007b78f51d52b5  sub rsp, 0xF0
00007b78f51d52bc  vmovaps [rsp], xmm0
00007b78f51d52c1  vmovaps [rsp+0x10], xmm1
00007b78f51d52c7  vmovaps [rsp+0x20], xmm2
00007b78f51d52cd  vmovaps [rsp+0x30], xmm3
00007b78f51d52d3  vmovaps [rsp+0x40], xmm4
00007b78f51d52d9  vmovaps [rsp+0x50], xmm5
00007b78f51d52df  vmovaps [rsp+0x60], xmm6
00007b78f51d52e5  vmovaps [rsp+0x70], xmm7
00007b78f51d52eb  vmovaps [rsp+0x80], xmm8
00007b78f51d52f4  vmovaps [rsp+0x90], xmm9
00007b78f51d52fd  vmovaps [rsp+0xA0], xmm10
00007b78f51d5306  vmovaps [rsp+0xB0], xmm11
00007b78f51d530f  vmovaps [rsp+0xC0], xmm12
00007b78f51d5318  vmovaps [rsp+0xD0], xmm13
00007b78f51d5321  vmovaps [rsp+0xE0], xmm14
00007b78f51d532a  sub rsp, 0x30
00007b78f51d532e  movaps [rsp], xmm15
00007b78f51d5333  movaps [rsp+0x10], xmm13
00007b78f51d5339  movaps [rsp+0x20], xmm9
00007b78f51d533f  lea rdi, [rsp]
00007b78f51d5343  mov esi, 0x00
00007b78f51d5348  mov rax, 0x597478C09530
00007b78f51d5352  call rax
00007b78f51d5354  movaps xmm15, [rsp]
00007b78f51d5359  add rsp, 0x30
00007b78f51d535d  vmovaps xmm0, [rsp]
00007b78f51d5362  vmovaps xmm1, [rsp+0x10]
00007b78f51d5368  vmovaps xmm2, [rsp+0x20]
00007b78f51d536e  vmovaps xmm3, [rsp+0x30]
00007b78f51d5374  vmovaps xmm4, [rsp+0x40]
00007b78f51d537a  vmovaps xmm5, [rsp+0x50]
00007b78f51d5380  vmovaps xmm6, [rsp+0x60]
00007b78f51d5386  vmovaps xmm7, [rsp+0x70]
00007b78f51d538c  vmovaps xmm8, [rsp+0x80]
00007b78f51d5395  vmovaps xmm9, [rsp+0x90]
00007b78f51d539e  vmovaps xmm10, [rsp+0xA0]
00007b78f51d53a7  vmovaps xmm11, [rsp+0xB0]
00007b78f51d53b0  vmovaps xmm12, [rsp+0xC0]
00007b78f51d53b9  vmovaps xmm13, [rsp+0xD0]
00007b78f51d53c2  vmovaps xmm14, [rsp+0xE0]
00007b78f51d53cb  add rsp, 0xF0
00007b78f51d53d2  pop r11
00007b78f51d53d4  pop r10
00007b78f51d53d6  pop r9
00007b78f51d53d8  pop r8
00007b78f51d53da  pop rsi
00007b78f51d53db  pop rdi
00007b78f51d53dc  pop rdx
00007b78f51d53dd  pop rcx
00007b78f51d53de  pop rax
00007b78f51d53df  add rsp, 0x08
00007b78f51d53e3  jmp 0x00007B78F51D02D4
00007b78f51d53e8  sub rsp, 0x08
00007b78f51d53ec  push rax
00007b78f51d53ed  push rcx
00007b78f51d53ee  push rdx
00007b78f51d53ef  push rdi
00007b78f51d53f0  push rsi
00007b78f51d53f1  push r8
00007b78f51d53f3  push r9
00007b78f51d53f5  push r10
00007b78f51d53f7  push r11
00007b78f51d53f9  sub rsp, 0xF0
00007b78f51d5400  vmovaps [rsp], xmm0
00007b78f51d5405  vmovaps [rsp+0x10], xmm1
00007b78f51d540b  vmovaps [rsp+0x20], xmm2
00007b78f51d5411  vmovaps [rsp+0x30], xmm3
00007b78f51d5417  vmovaps [rsp+0x40], xmm4
00007b78f51d541d  vmovaps [rsp+0x50], xmm5
00007b78f51d5423  vmovaps [rsp+0x60], xmm6
00007b78f51d5429  vmovaps [rsp+0x70], xmm7
00007b78f51d542f  vmovaps [rsp+0x80], xmm8
00007b78f51d5438  vmovaps [rsp+0x90], xmm9
00007b78f51d5441  vmovaps [rsp+0xA0], xmm10
00007b78f51d544a  vmovaps [rsp+0xB0], xmm11
00007b78f51d5453  vmovaps [rsp+0xC0], xmm12
00007b78f51d545c  vmovaps [rsp+0xD0], xmm14
00007b78f51d5465  vmovaps [rsp+0xE0], xmm15
00007b78f51d546e  sub rsp, 0x30
00007b78f51d5472  movaps [rsp], xmm13
00007b78f51d5477  movaps [rsp+0x10], xmm8
00007b78f51d547d  movaps [rsp+0x20], xmm14
00007b78f51d5483  lea rdi, [rsp]
00007b78f51d5487  mov esi, 0x00
00007b78f51d548c  mov rax, 0x597478C09530
00007b78f51d5496  call rax
00007b78f51d5498  movaps xmm13, [rsp]
00007b78f51d549d  add rsp, 0x30
00007b78f51d54a1  vmovaps xmm0, [rsp]
00007b78f51d54a6  vmovaps xmm1, [rsp+0x10]
00007b78f51d54ac  vmovaps xmm2, [rsp+0x20]
00007b78f51d54b2  vmovaps xmm3, [rsp+0x30]
00007b78f51d54b8  vmovaps xmm4, [rsp+0x40]
00007b78f51d54be  vmovaps xmm5, [rsp+0x50]
00007b78f51d54c4  vmovaps xmm6, [rsp+0x60]
00007b78f51d54ca  vmovaps xmm7, [rsp+0x70]
00007b78f51d54d0  vmovaps xmm8, [rsp+0x80]
00007b78f51d54d9  vmovaps xmm9, [rsp+0x90]
00007b78f51d54e2  vmovaps xmm10, [rsp+0xA0]
00007b78f51d54eb  vmovaps xmm11, [rsp+0xB0]
00007b78f51d54f4  vmovaps xmm12, [rsp+0xC0]
00007b78f51d54fd  vmovaps xmm14, [rsp+0xD0]
00007b78f51d5506  vmovaps xmm15, [rsp+0xE0]
00007b78f51d550f  add rsp, 0xF0
00007b78f51d5516  pop r11
00007b78f51d5518  pop r10
00007b78f51d551a  pop r9
00007b78f51d551c  pop r8
00007b78f51d551e  pop rsi
00007b78f51d551f  pop rdi
00007b78f51d5520  pop rdx
00007b78f51d5521  pop rcx
00007b78f51d5522  pop rax
00007b78f51d5523  add rsp, 0x08
00007b78f51d5527  jmp 0x00007B78F51D02F7
00007b78f51d552c  sub rsp, 0x08
00007b78f51d5530  push rax
00007b78f51d5531  push rcx
00007b78f51d5532  push rdx
00007b78f51d5533  push rdi
00007b78f51d5534  push rsi
00007b78f51d5535  push r8
00007b78f51d5537  push r9
00007b78f51d5539  push r10
00007b78f51d553b  push r11
00007b78f51d553d  sub rsp, 0xF0
00007b78f51d5544  vmovaps [rsp], xmm0
00007b78f51d5549  vmovaps [rsp+0x10], xmm1
00007b78f51d554f  vmovaps [rsp+0x20], xmm2
00007b78f51d5555  vmovaps [rsp+0x30], xmm3
00007b78f51d555b  vmovaps [rsp+0x40], xmm4
00007b78f51d5561  vmovaps [rsp+0x50], xmm5
00007b78f51d5567  vmovaps [rsp+0x60], xmm6
00007b78f51d556d  vmovaps [rsp+0x70], xmm7
00007b78f51d5573  vmovaps [rsp+0x80], xmm8
00007b78f51d557c  vmovaps [rsp+0x90], xmm9
00007b78f51d5585  vmovaps [rsp+0xA0], xmm10
00007b78f51d558e  vmovaps [rsp+0xB0], xmm11
00007b78f51d5597  vmovaps [rsp+0xC0], xmm12
00007b78f51d55a0  vmovaps [rsp+0xD0], xmm13
00007b78f51d55a9  vmovaps [rsp+0xE0], xmm15
00007b78f51d55b2  sub rsp, 0x30
00007b78f51d55b6  movaps [rsp], xmm14
00007b78f51d55bb  movaps [rsp+0x10], xmm1
00007b78f51d55c0  movaps [rsp+0x20], xmm10
00007b78f51d55c6  lea rdi, [rsp]
00007b78f51d55ca  mov esi, 0x00
00007b78f51d55cf  mov rax, 0x597478C09530
00007b78f51d55d9  call rax
00007b78f51d55db  movaps xmm14, [rsp]
00007b78f51d55e0  add rsp, 0x30
00007b78f51d55e4  vmovaps xmm0, [rsp]
00007b78f51d55e9  vmovaps xmm1, [rsp+0x10]
00007b78f51d55ef  vmovaps xmm2, [rsp+0x20]
00007b78f51d55f5  vmovaps xmm3, [rsp+0x30]
00007b78f51d55fb  vmovaps xmm4, [rsp+0x40]
00007b78f51d5601  vmovaps xmm5, [rsp+0x50]
00007b78f51d5607  vmovaps xmm6, [rsp+0x60]
00007b78f51d560d  vmovaps xmm7, [rsp+0x70]
00007b78f51d5613  vmovaps xmm8, [rsp+0x80]
00007b78f51d561c  vmovaps xmm9, [rsp+0x90]
00007b78f51d5625  vmovaps xmm10, [rsp+0xA0]
00007b78f51d562e  vmovaps xmm11, [rsp+0xB0]
00007b78f51d5637  vmovaps xmm12, [rsp+0xC0]
00007b78f51d5640  vmovaps xmm13, [rsp+0xD0]
00007b78f51d5649  vmovaps xmm15, [rsp+0xE0]
00007b78f51d5652  add rsp, 0xF0
00007b78f51d5659  pop r11
00007b78f51d565b  pop r10
00007b78f51d565d  pop r9
00007b78f51d565f  pop r8
00007b78f51d5661  pop rsi
00007b78f51d5662  pop rdi
00007b78f51d5663  pop rdx
00007b78f51d5664  pop rcx
00007b78f51d5665  pop rax
00007b78f51d5666  add rsp, 0x08
00007b78f51d566a  jmp 0x00007B78F51D031A
00007b78f51d566f  sub rsp, 0x08
00007b78f51d5673  push rax
00007b78f51d5674  push rcx
00007b78f51d5675  push rdx
00007b78f51d5676  push rdi
00007b78f51d5677  push rsi
00007b78f51d5678  push r8
00007b78f51d567a  push r9
00007b78f51d567c  push r10
00007b78f51d567e  push r11
00007b78f51d5680  sub rsp, 0xF0
00007b78f51d5687  vmovaps [rsp], xmm0
00007b78f51d568c  vmovaps [rsp+0x10], xmm2
00007b78f51d5692  vmovaps [rsp+0x20], xmm3
00007b78f51d5698  vmovaps [rsp+0x30], xmm4
00007b78f51d569e  vmovaps [rsp+0x40], xmm5
00007b78f51d56a4  vmovaps [rsp+0x50], xmm6
00007b78f51d56aa  vmovaps [rsp+0x60], xmm7
00007b78f51d56b0  vmovaps [rsp+0x70], xmm8
00007b78f51d56b6  vmovaps [rsp+0x80], xmm9
00007b78f51d56bf  vmovaps [rsp+0x90], xmm10
00007b78f51d56c8  vmovaps [rsp+0xA0], xmm11
00007b78f51d56d1  vmovaps [rsp+0xB0], xmm12
00007b78f51d56da  vmovaps [rsp+0xC0], xmm13
00007b78f51d56e3  vmovaps [rsp+0xD0], xmm14
00007b78f51d56ec  vmovaps [rsp+0xE0], xmm15
00007b78f51d56f5  sub rsp, 0x30
00007b78f51d56f9  movaps [rsp], xmm1
00007b78f51d56fd  movaps [rsp+0x10], xmm7
00007b78f51d5702  movaps [rsp+0x20], xmm11
00007b78f51d5708  lea rdi, [rsp]
00007b78f51d570c  mov esi, 0x00
00007b78f51d5711  mov rax, 0x597478C09530
00007b78f51d571b  call rax
00007b78f51d571d  movaps xmm1, [rsp]
00007b78f51d5721  add rsp, 0x30
00007b78f51d5725  vmovaps xmm0, [rsp]
00007b78f51d572a  vmovaps xmm2, [rsp+0x10]
00007b78f51d5730  vmovaps xmm3, [rsp+0x20]
00007b78f51d5736  vmovaps xmm4, [rsp+0x30]
00007b78f51d573c  vmovaps xmm5, [rsp+0x40]
00007b78f51d5742  vmovaps xmm6, [rsp+0x50]
00007b78f51d5748  vmovaps xmm7, [rsp+0x60]
00007b78f51d574e  vmovaps xmm8, [rsp+0x70]
00007b78f51d5754  vmovaps xmm9, [rsp+0x80]
00007b78f51d575d  vmovaps xmm10, [rsp+0x90]
00007b78f51d5766  vmovaps xmm11, [rsp+0xA0]
00007b78f51d576f  vmovaps xmm12, [rsp+0xB0]
00007b78f51d5778  vmovaps xmm13, [rsp+0xC0]
00007b78f51d5781  vmovaps xmm14, [rsp+0xD0]
00007b78f51d578a  vmovaps xmm15, [rsp+0xE0]
00007b78f51d5793  add rsp, 0xF0
00007b78f51d579a  pop r11
00007b78f51d579c  pop r10
00007b78f51d579e  pop r9
00007b78f51d57a0  pop r8
00007b78f51d57a2  pop rsi
00007b78f51d57a3  pop rdi
00007b78f51d57a4  pop rdx
00007b78f51d57a5  pop rcx
00007b78f51d57a6  pop rax
00007b78f51d57a7  add rsp, 0x08
00007b78f51d57ab  jmp 0x00007B78F51D033B
00007b78f51d57b0  call 0x00007B78F500E880
00007b78f51d57b5  jmp 0x00007B78F51D034E
00007b78f51d57ba  call 0x00007B78F500C380
00007b78f51d57bf  jmp 0x00007B78F51D0359
00007b78f51d57c4  call 0x00007B78F500D600
00007b78f51d57c9  jmp 0x00007B78F51D0364
00007b78f51d57ce  call 0x00007B78F4FFF540
00007b78f51d57d3  jmp 0x00007B78F51D036F
00007b78f51d57d8  int3
00007b78f51d57d9  nop [rax], eax
00007b78f51d57e0  mov rax, [r15+0x40]
00007b78f51d57e4  mov r14, [r15+0x58]
00007b78f51d57e8  lea r12, [rax+r14*1]
00007b78f51d57ec  movaps xmm1, [r15+0x1D0]
00007b78f51d57f4  vmovaps [rsp+0x10], xmm1
00007b78f51d57fa  vmovaps xmm15, [rsp+0x10]
00007b78f51d5800  por xmm1, xmm15
00007b78f51d5805  movaps xmm14, [r15+0x1A0]
00007b78f51d580d  vmovaps [rsp+0x10], xmm14
00007b78f51d5813  vmovaps xmm13, [rsp+0x10]
00007b78f51d5819  por xmm14, xmm13
00007b78f51d581e  lea rax, [r12+0x30]
00007b78f51d5823  mov r11, [r13+rax*1]
00007b78f51d5828  lea rax, [r12+0x38]
00007b78f51d582d  mov r10, [r13+rax*1]
00007b78f51d5832  movq xmm13, r11
00007b78f51d5837  movq xmm12, r10
00007b78f51d583c  movq xmm13, xmm13
00007b78f51d5841  vmovaps [rsp+0x10], xmm13
00007b78f51d5847  movq xmm13, xmm13
00007b78f51d584c  movaps [r15+0x130], xmm13
00007b78f51d5854  movq xmm12, xmm12
00007b78f51d5859  vmovaps [rsp+0x20], xmm12
00007b78f51d585f  movq xmm12, xmm12
00007b78f51d5864  movaps [r15+0x280], xmm12
00007b78f51d586c  movaps xmm13, [r15+0x270]
00007b78f51d5874  vmovaps [rsp+0x30], xmm13
00007b78f51d587a  vmovaps xmm12, [rsp+0x30]
00007b78f51d5880  por xmm13, xmm12
00007b78f51d5885  lea rax, [r12+0x20]
00007b78f51d588a  mov r11, [r13+rax*1]
00007b78f51d588f  lea rax, [r12+0x28]
00007b78f51d5894  mov r10, [r13+rax*1]
00007b78f51d5899  movq xmm12, r11
00007b78f51d589e  movq xmm11, r10
00007b78f51d58a3  movq xmm12, xmm12
00007b78f51d58a8  vmovaps [rsp+0x30], xmm12
00007b78f51d58ae  movq xmm12, xmm12
00007b78f51d58b3  movaps [r15+0x150], xmm12
00007b78f51d58bb  movq xmm11, xmm11
00007b78f51d58c0  vmovaps [rsp+0x40], xmm11
00007b78f51d58c6  movq xmm11, xmm11
00007b78f51d58cb  movaps [r15+0x140], xmm11
00007b78f51d58d3  lea rax, [r12+0x10]
00007b78f51d58d8  mov r11, [r13+rax*1]
00007b78f51d58dd  lea rax, [r12+0x18]
00007b78f51d58e2  mov r10, [r13+rax*1]
00007b78f51d58e7  movq xmm12, r11
00007b78f51d58ec  movq xmm11, r10
00007b78f51d58f1  movq xmm12, xmm12
00007b78f51d58f6  vmovaps [rsp+0x50], xmm12
00007b78f51d58fc  movq xmm12, xmm12
00007b78f51d5901  movaps [r15+0x170], xmm12
00007b78f51d5909  movq xmm11, xmm11
00007b78f51d590e  vmovaps [rsp+0x60], xmm11
00007b78f51d5914  movq xmm11, xmm11
00007b78f51d5919  movaps [r15+0x160], xmm11
00007b78f51d5921  mov rax, [r13+r12*1]
00007b78f51d5926  vmovq xmm12, rax
00007b78f51d592b  vpbroadcastq xmm12, xmm12
00007b78f51d5930  lea rax, [r12+0x08]
00007b78f51d5935  mov r12, [r13+rax*1]
00007b78f51d593a  movq xmm11, r12
00007b78f51d593f  movaps [r15+0x230], xmm11
00007b78f51d5947  mov rax, [r15+0xF8]
00007b78f51d594e  lea r12, [rax+0x50]
00007b78f51d5952  movups xmm11, [r13+r12*1]
00007b78f51d5958  lea r12, [rax+0x60]
00007b78f51d595c  movups xmm10, [r13+r12*1]
00007b78f51d5962  lea r12, [rax+0x30]
00007b78f51d5966  movups xmm9, [r13+r12*1]
00007b78f51d596c  mov r12, [r15+0x50]
00007b78f51d5970  lea r11, [r12+r14*1]
00007b78f51d5974  mov [r15+0x60], r11
00007b78f51d5978  lea r12, [r14+0x40]
00007b78f51d597c  mov [r15+0x58], r12
00007b78f51d5980  movaps xmm8, xmm12
00007b78f51d5984  mulpd xmm8, xmm15
00007b78f51d5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007b78f51d598f  ptest xmm7, xmm7
00007b78f51d5994  jnz 0x00007B78F51D67B7
00007b78f51d599a  movq xmm15, qword ptr [r15+0x230]
00007b78f51d59a3  vmovaps [rsp+0x70], xmm15
00007b78f51d59a9  vpermilpd xmm15, xmm15, 0x00
00007b78f51d59af  movaps xmm7, xmm9
00007b78f51d59b3  mulpd xmm7, xmm15
00007b78f51d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007b78f51d59bd  ptest xmm6, xmm6
00007b78f51d59c2  jnz 0x00007B78F51D68FB
00007b78f51d59c8  vxorps xmm15, xmm15, xmm15
00007b78f51d59cd  vpbroadcastq xmm15, xmm15
00007b78f51d59d2  movaps xmm9, xmm12
00007b78f51d59d6  mulpd xmm9, xmm10
00007b78f51d59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007b78f51d59e1  ptest xmm6, xmm6
00007b78f51d59e6  jnz 0x00007B78F51D6A3D
00007b78f51d59ec  movaps xmm10, xmm12
00007b78f51d59f0  mulpd xmm10, xmm11
00007b78f51d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007b78f51d59fb  ptest xmm6, xmm6
00007b78f51d5a00  jnz 0x00007B78F51D6B81
00007b78f51d5a06  movaps xmm11, [r15+0x1F0]
00007b78f51d5a0e  movaps xmm6, xmm12
00007b78f51d5a12  mulpd xmm6, xmm11
00007b78f51d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007b78f51d5a1c  ptest xmm5, xmm5
00007b78f51d5a21  jnz 0x00007B78F51D6CC5
00007b78f51d5a27  movaps xmm12, [r15+0x2A0]
00007b78f51d5a2f  vmovaps [rsp+0x80], xmm12
00007b78f51d5a38  vmovaps xmm11, [rsp+0x80]
00007b78f51d5a41  por xmm12, xmm11
00007b78f51d5a46  movaps xmm11, [r15+0x250]
00007b78f51d5a4e  vmovaps [rsp+0x80], xmm11
00007b78f51d5a57  vmovaps xmm5, [rsp+0x80]
00007b78f51d5a60  por xmm11, xmm5
00007b78f51d5a65  vmovaps xmm4, [rsp+0x70]
00007b78f51d5a6b  vpermilpd xmm4, xmm4, 0x00
00007b78f51d5a71  movaps xmm3, xmm5
00007b78f51d5a74  mulpd xmm3, xmm4
00007b78f51d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007b78f51d5a7d  ptest xmm2, xmm2
00007b78f51d5a82  jnz 0x00007B78F51D6E07
00007b78f51d5a88  mov [rsp+0x80], rax
00007b78f51d5a90  xor eax, eax
00007b78f51d5a92  mov r14d, 0x200
00007b78f51d5a98  cmp r12, r14
00007b78f51d5a9b  cmc
00007b78f51d5a9c  lahf
00007b78f51d5a9d  seto al
00007b78f51d5aa0  mov [r15+0x108], eax
00007b78f51d5aa7  movaps xmm5, xmm8
00007b78f51d5aab  addpd xmm5, xmm15
00007b78f51d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007b78f51d5ab5  ptest xmm4, xmm4
00007b78f51d5aba  jnz 0x00007B78F51D6F47
00007b78f51d5ac0  movaps xmm8, [r15+0x1B0]
00007b78f51d5ac8  movaps xmm4, xmm9
00007b78f51d5acc  addpd xmm4, xmm8
00007b78f51d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007b78f51d5ad6  ptest xmm2, xmm2
00007b78f51d5adb  jnz 0x00007B78F51D7089
00007b78f51d5ae1  movaps xmm9, xmm10
00007b78f51d5ae5  addpd xmm9, xmm8
00007b78f51d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007b78f51d5af0  ptest xmm2, xmm2
00007b78f51d5af5  jnz 0x00007B78F51D71CB
00007b78f51d5afb  movaps xmm10, [r15+0x2F0]
00007b78f51d5b03  vmovaps [rsp+0x90], xmm10
00007b78f51d5b0c  vmovaps xmm8, [rsp+0x90]
00007b78f51d5b15  por xmm10, xmm8
00007b78f51d5b1a  movaps xmm8, [r15+0x2E0]
00007b78f51d5b22  vmovaps [rsp+0x90], xmm8
00007b78f51d5b2b  vmovaps xmm2, [rsp+0x90]
00007b78f51d5b34  por xmm8, xmm2
00007b78f51d5b39  movaps xmm2, [r15+0x2D0]
00007b78f51d5b41  vmovaps [rsp+0x90], xmm2
00007b78f51d5b4a  vmovaps [rsp+0xA0], xmm1
00007b78f51d5b53  vmovaps xmm1, [rsp+0x90]
00007b78f51d5b5c  por xmm2, xmm1
00007b78f51d5b60  movaps xmm1, [r15+0x200]
00007b78f51d5b68  vmovaps [rsp+0x90], xmm1
00007b78f51d5b71  vmovaps [rsp+0xB0], xmm15
00007b78f51d5b7a  vmovaps xmm15, [rsp+0x90]
00007b78f51d5b83  por xmm1, xmm15
00007b78f51d5b88  movaps xmm15, [r15+0x1C0]
00007b78f51d5b90  vmovaps [rsp+0x90], xmm15
00007b78f51d5b99  vmovaps [rsp+0xC0], xmm1
00007b78f51d5ba2  vmovaps xmm1, [rsp+0x90]
00007b78f51d5bab  por xmm15, xmm1
00007b78f51d5bb0  movaps xmm1, [r15+0x190]
00007b78f51d5bb8  vmovaps [rsp+0x90], xmm1
00007b78f51d5bc1  vmovaps [rsp+0xD0], xmm15
00007b78f51d5bca  vmovaps xmm15, [rsp+0x90]
00007b78f51d5bd3  por xmm1, xmm15
00007b78f51d5bd8  movaps xmm15, [r15+0x300]
00007b78f51d5be0  vmovaps [rsp+0x90], xmm15
00007b78f51d5be9  vmovaps [rsp+0xE0], xmm1
00007b78f51d5bf2  vmovaps xmm1, [rsp+0x90]
00007b78f51d5bfb  por xmm15, xmm1
00007b78f51d5c00  mov rax, [rsp+0x80]
00007b78f51d5c08  lea r14, [rax+0xA0]
00007b78f51d5c0f  movups xmm1, [r13+r14*1]
00007b78f51d5c15  lea r14, [rax+0xB0]
00007b78f51d5c1c  vmovaps [rsp+0x80], xmm1
00007b78f51d5c25  movups xmm1, [r13+r14*1]
00007b78f51d5c2b  vmovaps [rsp+0x90], xmm1
00007b78f51d5c34  vmovaps [rsp+0xF0], xmm15
00007b78f51d5c3d  vmovaps xmm15, [rsp+0xB0]
00007b78f51d5c46  vmovaps [rsp+0xB0], xmm14
00007b78f51d5c4f  movaps xmm1, xmm6
00007b78f51d5c52  addpd xmm1, xmm15
00007b78f51d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007b78f51d5c5c  ptest xmm14, xmm14
00007b78f51d5c62  jnz 0x00007B78F51D7323
00007b78f51d5c68  lea r14, [rax+0xF0]
00007b78f51d5c6f  movups xmm15, [r13+r14*1]
00007b78f51d5c75  movaps xmm14, xmm4
00007b78f51d5c79  addpd xmm14, xmm3
00007b78f51d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007b78f51d5c84  ptest xmm6, xmm6
00007b78f51d5c89  jnz 0x00007B78F51D746E
00007b78f51d5c8f  movaps xmm6, xmm9
00007b78f51d5c93  addpd xmm6, xmm7
00007b78f51d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007b78f51d5c9c  ptest xmm4, xmm4
00007b78f51d5ca1  jnz 0x00007B78F51D75B0
00007b78f51d5ca7  vmovaps xmm9, [rsp+0x70]
00007b78f51d5cad  vpermilpd xmm9, xmm9, 0x00
00007b78f51d5cb3  vmovaps xmm4, [rsp+0x90]
00007b78f51d5cbc  movaps xmm7, xmm4
00007b78f51d5cbf  mulpd xmm7, xmm9
00007b78f51d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007b78f51d5cc9  ptest xmm3, xmm3
00007b78f51d5cce  jnz 0x00007B78F51D76F1
00007b78f51d5cd4  vmovaps xmm9, [rsp+0x50]
00007b78f51d5cda  vpermilpd xmm9, xmm9, 0x00
00007b78f51d5ce0  movaps xmm4, xmm15
00007b78f51d5ce4  mulpd xmm4, xmm9
00007b78f51d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007b78f51d5cee  ptest xmm3, xmm3
00007b78f51d5cf3  jnz 0x00007B78F51D7832
00007b78f51d5cf9  lea r14, [rax+0xE0]
00007b78f51d5d00  movups xmm15, [r13+r14*1]
00007b78f51d5d06  vmovaps xmm9, [rsp+0x70]
00007b78f51d5d0c  vpermilpd xmm9, xmm9, 0x00
00007b78f51d5d12  vmovaps [rsp+0x70], xmm1
00007b78f51d5d18  vmovaps xmm1, [rsp+0x80]
00007b78f51d5d21  vmovaps [rsp+0x80], xmm15
00007b78f51d5d2a  movaps xmm3, xmm1
00007b78f51d5d2d  mulpd xmm3, xmm9
00007b78f51d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007b78f51d5d37  ptest xmm15, xmm15
00007b78f51d5d3d  jnz 0x00007B78F51D797E
00007b78f51d5d43  vmovaps xmm1, [rsp+0xF0]
00007b78f51d5d4c  vmovaps xmm15, [rsp+0xF0]
00007b78f51d5d55  por xmm1, xmm15
00007b78f51d5d5a  movaps [r15+0x300], xmm1
00007b78f51d5d62  vmovaps xmm15, [rsp+0xE0]
00007b78f51d5d6b  vmovaps xmm9, [rsp+0xE0]
00007b78f51d5d74  por xmm15, xmm9
00007b78f51d5d79  movaps [r15+0x190], xmm15
00007b78f51d5d81  vmovaps xmm9, [rsp+0x50]
00007b78f51d5d87  vpermilpd xmm9, xmm9, 0x00
00007b78f51d5d8d  vmovaps [rsp+0x90], xmm1
00007b78f51d5d96  vmovaps [rsp+0xE0], xmm15
00007b78f51d5d9f  vmovaps xmm15, [rsp+0x80]
00007b78f51d5da8  vmovaps [rsp+0x80], xmm14
00007b78f51d5db1  movaps xmm1, xmm15
00007b78f51d5db5  mulpd xmm1, xmm9
00007b78f51d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007b78f51d5dbf  ptest xmm14, xmm14
00007b78f51d5dc5  jnz 0x00007B78F51D7ABF
00007b78f51d5dcb  lea r14, [rax+0x90]
00007b78f51d5dd2  movups xmm15, [r13+r14*1]
00007b78f51d5dd8  vmovaps xmm14, [rsp+0xD0]
00007b78f51d5de1  vmovaps xmm9, [rsp+0xD0]
00007b78f51d5dea  por xmm14, xmm9
00007b78f51d5def  movaps [r15+0x1C0], xmm14
00007b78f51d5df7  vmovaps xmm9, [rsp+0xC0]
00007b78f51d5e00  vmovaps [rsp+0xD0], xmm1
00007b78f51d5e09  vmovaps xmm1, [rsp+0xC0]
00007b78f51d5e12  por xmm9, xmm1
00007b78f51d5e17  movaps [r15+0x200], xmm9
00007b78f51d5e1f  vmovaps [rsp+0xC0], xmm2
00007b78f51d5e28  vmovaps xmm1, [rsp+0xC0]
00007b78f51d5e31  por xmm2, xmm1
00007b78f51d5e35  movaps [r15+0x2D0], xmm2
00007b78f51d5e3d  vmovaps [rsp+0xC0], xmm8
00007b78f51d5e46  vmovaps xmm1, [rsp+0xC0]
00007b78f51d5e4f  por xmm8, xmm1
00007b78f51d5e54  movaps [r15+0x2E0], xmm8
00007b78f51d5e5c  vmovaps [rsp+0xC0], xmm15
00007b78f51d5e65  movaps xmm1, xmm5
00007b78f51d5e68  addpd xmm1, xmm7
00007b78f51d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007b78f51d5e71  ptest xmm15, xmm15
00007b78f51d5e77  jnz 0x00007B78F51D7C0B
00007b78f51d5e7d  vmovaps xmm15, [rsp+0x50]
00007b78f51d5e83  vpermilpd xmm15, xmm15, 0x00
00007b78f51d5e89  vmovaps xmm5, [rsp+0xC0]
00007b78f51d5e92  vmovaps [rsp+0xC0], xmm1
00007b78f51d5e9b  movaps xmm7, xmm5
00007b78f51d5e9e  mulpd xmm7, xmm15
00007b78f51d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007b78f51d5ea8  ptest xmm1, xmm1
00007b78f51d5ead  jnz 0x00007B78F51D7D4B
00007b78f51d5eb3  lea r14, [rax+0x80]
00007b78f51d5eba  movups xmm1, [r13+r14*1]
00007b78f51d5ec0  vmovaps xmm5, [rsp+0x70]
00007b78f51d5ec6  vmovaps [rsp+0x70], xmm1
00007b78f51d5ecc  movaps xmm15, xmm5
00007b78f51d5ed0  addpd xmm15, xmm3
00007b78f51d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007b78f51d5edb  ptest xmm1, xmm1
00007b78f51d5ee0  jnz 0x00007B78F51D7E96
00007b78f51d5ee6  vmovaps xmm5, [rsp+0x80]
00007b78f51d5eef  movaps xmm1, xmm5
00007b78f51d5ef2  addpd xmm1, xmm4
00007b78f51d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007b78f51d5efb  ptest xmm3, xmm3
00007b78f51d5f00  jnz 0x00007B78F51D7FD8
00007b78f51d5f06  vmovaps [rsp+0x80], xmm10
00007b78f51d5f0f  vmovaps xmm5, [rsp+0x80]
00007b78f51d5f18  por xmm10, xmm5
00007b78f51d5f1d  movaps [r15+0x2F0], xmm10
00007b78f51d5f25  vmovaps xmm5, [rsp+0x50]
00007b78f51d5f2b  vpermilpd xmm5, xmm5, 0x00
00007b78f51d5f31  vmovaps xmm3, [rsp+0x70]
00007b78f51d5f37  vmovaps [rsp+0x50], xmm1
00007b78f51d5f3d  movaps xmm4, xmm3
00007b78f51d5f40  mulpd xmm4, xmm5
00007b78f51d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007b78f51d5f49  ptest xmm1, xmm1
00007b78f51d5f4e  jnz 0x00007B78F51D8118
00007b78f51d5f54  lea r14, [rax+0xD0]
00007b78f51d5f5b  movups xmm1, [r13+r14*1]
00007b78f51d5f61  vmovaps xmm3, [rsp+0xD0]
00007b78f51d5f6a  vmovaps [rsp+0x70], xmm1
00007b78f51d5f70  movaps xmm5, xmm6
00007b78f51d5f73  addpd xmm5, xmm3
00007b78f51d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007b78f51d5f7c  ptest xmm1, xmm1
00007b78f51d5f81  jnz 0x00007B78F51D8262
00007b78f51d5f87  vmovaps xmm1, [rsp+0x60]
00007b78f51d5f8d  vpermilpd xmm1, xmm1, 0x00
00007b78f51d5f93  movaps xmm6, xmm9
00007b78f51d5f97  mulpd xmm6, xmm1
00007b78f51d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007b78f51d5fa0  ptest xmm3, xmm3
00007b78f51d5fa5  jnz 0x00007B78F51D83A2
00007b78f51d5fab  movaps [r15+0x260], xmm6
00007b78f51d5fb3  vxorps xmm1, xmm1, xmm1
00007b78f51d5fb7  vpbroadcastq xmm1, xmm1
00007b78f51d5fbc  movaps [r15+0x1B0], xmm1
00007b78f51d5fc4  vmovaps xmm1, [rsp+0x60]
00007b78f51d5fca  vpermilpd xmm1, xmm1, 0x00
00007b78f51d5fd0  vmovaps xmm3, [rsp+0x70]
00007b78f51d5fd6  vmovaps [rsp+0x70], xmm15
00007b78f51d5fdc  movaps xmm9, xmm3
00007b78f51d5fe0  mulpd xmm9, xmm1
00007b78f51d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007b78f51d5feb  ptest xmm15, xmm15
00007b78f51d5ff1  jnz 0x00007B78F51D84E3
00007b78f51d5ff7  lea r14, [rax+0xC0]
00007b78f51d5ffe  movups xmm1, [r13+r14*1]
00007b78f51d6004  vmovaps xmm3, [rsp+0xC0]
00007b78f51d600d  vmovaps [rsp+0x80], xmm1
00007b78f51d6016  movaps xmm15, xmm3
00007b78f51d601a  addpd xmm15, xmm7
00007b78f51d601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007b78f51d6025  ptest xmm1, xmm1
00007b78f51d602a  jnz 0x00007B78F51D862F
00007b78f51d6030  vmovaps [rsp+0xC0], xmm13
00007b78f51d6039  vmovaps xmm1, [rsp+0xC0]
00007b78f51d6042  por xmm13, xmm1
00007b78f51d6047  movaps [r15+0x270], xmm13
00007b78f51d604f  vmovaps xmm1, [rsp+0xB0]
00007b78f51d6058  vmovaps xmm7, [rsp+0xB0]
00007b78f51d6061  por xmm1, xmm7
00007b78f51d6065  movaps [r15+0x1A0], xmm1
00007b78f51d606d  vmovaps xmm1, [rsp+0x60]
00007b78f51d6073  vpermilpd xmm1, xmm1, 0x00
00007b78f51d6079  vmovaps [rsp+0xB0], xmm1
00007b78f51d6082  vmovaps xmm1, [rsp+0x80]
00007b78f51d608b  vmovaps [rsp+0x80], xmm15
00007b78f51d6094  vmovaps xmm15, [rsp+0xB0]
00007b78f51d609d  vmovaps [rsp+0xB0], xmm14
00007b78f51d60a6  movaps xmm3, xmm1
00007b78f51d60a9  mulpd xmm3, xmm15
00007b78f51d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007b78f51d60b3  ptest xmm14, xmm14
00007b78f51d60b9  jnz 0x00007B78F51D8771
00007b78f51d60bf  lea r14, [rax+0x20]
00007b78f51d60c3  movups xmm1, [r13+r14*1]
00007b78f51d60c9  movaps [r15+0x110], xmm1
00007b78f51d60d1  vmovaps xmm14, [rsp+0x70]
00007b78f51d60d7  vmovaps [rsp+0x70], xmm1
00007b78f51d60dd  movaps xmm15, xmm14
00007b78f51d60e1  addpd xmm15, xmm4
00007b78f51d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007b78f51d60ec  ptest xmm1, xmm1
00007b78f51d60f1  jnz 0x00007B78F51D88BC
00007b78f51d60f7  vmovaps xmm1, [rsp+0x60]
00007b78f51d60fd  vpermilpd xmm1, xmm1, 0x00
00007b78f51d6103  movaps xmm14, xmm2
00007b78f51d6107  mulpd xmm14, xmm1
00007b78f51d610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007b78f51d6112  ptest xmm4, xmm4
00007b78f51d6117  jnz 0x00007B78F51D89FF
00007b78f51d611d  vmovaps xmm4, [rsp+0x50]
00007b78f51d6123  movaps xmm1, xmm4
00007b78f51d6126  addpd xmm1, xmm9
00007b78f51d612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007b78f51d6130  ptest xmm2, xmm2
00007b78f51d6135  jnz 0x00007B78F51D8B41
00007b78f51d613b  vmovaps xmm9, [rsp+0x30]
00007b78f51d6141  vpermilpd xmm9, xmm9, 0x00
00007b78f51d6147  vmovaps xmm2, [rsp+0x70]
00007b78f51d614d  vmovaps [rsp+0x50], xmm1
00007b78f51d6153  movaps xmm4, xmm2
00007b78f51d6156  mulpd xmm4, xmm9
00007b78f51d615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007b78f51d6160  ptest xmm1, xmm1
00007b78f51d6165  jnz 0x00007B78F51D8C82
00007b78f51d616b  vmovaps xmm1, [rsp+0x30]
00007b78f51d6171  vpermilpd xmm1, xmm1, 0x00
00007b78f51d6177  vmovaps xmm2, [rsp+0x90]
00007b78f51d6180  vmovaps [rsp+0x60], xmm15
00007b78f51d6186  movaps xmm9, xmm2
00007b78f51d618a  mulpd xmm9, xmm1
00007b78f51d618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007b78f51d6195  ptest xmm15, xmm15
00007b78f51d619b  jnz 0x00007B78F51D8DC3
00007b78f51d61a1  vmovaps xmm15, [rsp+0x80]
00007b78f51d61aa  movaps xmm1, xmm15
00007b78f51d61ae  addpd xmm1, xmm6
00007b78f51d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007b78f51d61b7  ptest xmm2, xmm2
00007b78f51d61bc  jnz 0x00007B78F51D8F05
00007b78f51d61c2  movaps xmm15, xmm5
00007b78f51d61c6  addpd xmm15, xmm3
00007b78f51d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007b78f51d61d1  ptest xmm6, xmm6
00007b78f51d61d6  jnz 0x00007B78F51D9046
00007b78f51d61dc  vmovaps xmm6, [rsp+0x30]
00007b78f51d61e2  vpermilpd xmm6, xmm6, 0x00
00007b78f51d61e8  movaps xmm5, xmm8
00007b78f51d61ec  mulpd xmm5, xmm6
00007b78f51d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007b78f51d61f5  ptest xmm3, xmm3
00007b78f51d61fa  jnz 0x00007B78F51D9188
00007b78f51d6200  vmovaps xmm8, [rsp+0x30]
00007b78f51d6206  vpermilpd xmm8, xmm8, 0x00
00007b78f51d620c  movaps xmm6, xmm10
00007b78f51d6210  mulpd xmm6, xmm8
00007b78f51d6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007b78f51d621a  ptest xmm3, xmm3
00007b78f51d621f  jnz 0x00007B78F51D92C9
00007b78f51d6225  vmovaps xmm8, [rsp+0x60]
00007b78f51d622b  movaps xmm10, xmm8
00007b78f51d622f  addpd xmm10, xmm14
00007b78f51d6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007b78f51d623a  ptest xmm3, xmm3
00007b78f51d623f  jnz 0x00007B78F51D940B
00007b78f51d6245  vmovaps xmm8, [rsp+0x50]
00007b78f51d624b  movaps xmm14, xmm8
00007b78f51d624f  addpd xmm14, xmm4
00007b78f51d6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007b78f51d625a  ptest xmm3, xmm3
00007b78f51d625f  jnz 0x00007B78F51D954F
00007b78f51d6265  vmovaps xmm8, [rsp+0x40]
00007b78f51d626b  vpermilpd xmm8, xmm8, 0x00
00007b78f51d6271  movaps xmm4, xmm13
00007b78f51d6275  mulpd xmm4, xmm8
00007b78f51d627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007b78f51d627f  ptest xmm3, xmm3
00007b78f51d6284  jnz 0x00007B78F51D9692
00007b78f51d628a  movaps xmm13, xmm15
00007b78f51d628e  addpd xmm13, xmm9
00007b78f51d6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007b78f51d6299  ptest xmm8, xmm8
00007b78f51d629f  jnz 0x00007B78F51D97D4
00007b78f51d62a5  movaps xmm15, xmm1
00007b78f51d62a9  addpd xmm15, xmm5
00007b78f51d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007b78f51d62b4  ptest xmm9, xmm9
00007b78f51d62ba  jnz 0x00007B78F51D9918
00007b78f51d62c0  vmovaps [rsp+0x30], xmm11
00007b78f51d62c6  vmovaps xmm1, [rsp+0x30]
00007b78f51d62cc  por xmm11, xmm1
00007b78f51d62d1  movaps [r15+0x250], xmm11
00007b78f51d62d9  vmovaps [rsp+0x30], xmm12
00007b78f51d62df  vmovaps xmm1, [rsp+0x30]
00007b78f51d62e5  por xmm12, xmm1
00007b78f51d62ea  movaps [r15+0x2A0], xmm12
00007b78f51d62f2  vmovaps xmm1, [rsp+0xA0]
00007b78f51d62fb  vmovaps xmm11, [rsp+0xA0]
00007b78f51d6304  por xmm1, xmm11
00007b78f51d6309  movaps [r15+0x1D0], xmm1
00007b78f51d6311  lea r14, [rax+0x40]
00007b78f51d6315  movups xmm1, [r13+r14*1]
00007b78f51d631b  movaps [r15+0x2C0], xmm1
00007b78f51d6323  vmovaps xmm11, [rsp+0x40]
00007b78f51d6329  vpermilpd xmm11, xmm11, 0x00
00007b78f51d632f  vmovaps xmm8, [rsp+0xE0]
00007b78f51d6338  movaps xmm9, xmm8
00007b78f51d633c  mulpd xmm9, xmm11
00007b78f51d6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007b78f51d6347  ptest xmm5, xmm5
00007b78f51d634c  jnz 0x00007B78F51D9A64
00007b78f51d6352  movaps xmm11, xmm10
00007b78f51d6356  addpd xmm11, xmm6
00007b78f51d635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007b78f51d6361  ptest xmm8, xmm8
00007b78f51d6367  jnz 0x00007B78F51D9BA8
00007b78f51d636d  movaps xmm10, xmm14
00007b78f51d6371  addpd xmm10, xmm4
00007b78f51d6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007b78f51d637c  ptest xmm8, xmm8
00007b78f51d6382  jnz 0x00007B78F51D9CEB
00007b78f51d6388  vmovaps xmm14, [rsp+0x40]
00007b78f51d638e  vpermilpd xmm14, xmm14, 0x00
00007b78f51d6394  movaps xmm8, xmm1
00007b78f51d6398  mulpd xmm8, xmm14
00007b78f51d639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007b78f51d63a3  ptest xmm6, xmm6
00007b78f51d63a8  jnz 0x00007B78F51D9E2E
00007b78f51d63ae  movaps xmm1, [r15+0x2B0]
00007b78f51d63b6  vmovaps xmm14, [rsp+0x40]
00007b78f51d63bc  vpermilpd xmm14, xmm14, 0x00
00007b78f51d63c2  movaps xmm6, xmm1
00007b78f51d63c5  mulpd xmm6, xmm14
00007b78f51d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007b78f51d63cf  ptest xmm5, xmm5
00007b78f51d63d4  jnz 0x00007B78F51D9F71
00007b78f51d63da  vmovaps xmm1, [rsp+0x10]
00007b78f51d63e0  vpermilpd xmm1, xmm1, 0x00
00007b78f51d63e6  movaps xmm14, xmm12
00007b78f51d63ea  mulpd xmm14, xmm1
00007b78f51d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007b78f51d63f5  ptest xmm5, xmm5
00007b78f51d63fa  jnz 0x00007B78F51DA0B2
00007b78f51d6400  movaps xmm1, xmm13
00007b78f51d6404  addpd xmm1, xmm9
00007b78f51d6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007b78f51d640e  ptest xmm12, xmm12
00007b78f51d6414  jnz 0x00007B78F51DA1F5
00007b78f51d641a  vmovaps xmm13, [rsp+0x10]
00007b78f51d6420  vpermilpd xmm13, xmm13, 0x00
00007b78f51d6426  movaps xmm12, xmm7
00007b78f51d642a  mulpd xmm12, xmm13
00007b78f51d642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007b78f51d6435  ptest xmm9, xmm9
00007b78f51d643b  jnz 0x00007B78F51DA337
00007b78f51d6441  movaps xmm13, xmm15
00007b78f51d6445  addpd xmm13, xmm8
00007b78f51d644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007b78f51d6450  ptest xmm9, xmm9
00007b78f51d6456  jnz 0x00007B78F51DA47A
00007b78f51d645c  movaps xmm15, [r15+0x290]
00007b78f51d6464  vmovaps xmm9, [rsp+0x10]
00007b78f51d646a  vpermilpd xmm9, xmm9, 0x00
00007b78f51d6470  movaps xmm8, xmm15
00007b78f51d6474  mulpd xmm8, xmm9
00007b78f51d6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007b78f51d647f  ptest xmm7, xmm7
00007b78f51d6484  jnz 0x00007B78F51DA5BE
00007b78f51d648a  movaps xmm15, xmm11
00007b78f51d648e  addpd xmm15, xmm6
00007b78f51d6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007b78f51d6499  ptest xmm9, xmm9
00007b78f51d649f  jnz 0x00007B78F51DA702
00007b78f51d64a5  movaps xmm11, [r15+0x1E0]
00007b78f51d64ad  vmovaps xmm9, [rsp+0x10]
00007b78f51d64b3  vpermilpd xmm9, xmm9, 0x00
00007b78f51d64b9  movaps xmm7, xmm11
00007b78f51d64bd  mulpd xmm7, xmm9
00007b78f51d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007b78f51d64c7  ptest xmm6, xmm6
00007b78f51d64cc  jnz 0x00007B78F51DA845
00007b78f51d64d2  movaps xmm11, xmm10
00007b78f51d64d6  addpd xmm11, xmm14
00007b78f51d64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007b78f51d64e1  ptest xmm9, xmm9
00007b78f51d64e7  jnz 0x00007B78F51DA987
00007b78f51d64ed  lea r14, [rax+0x70]
00007b78f51d64f1  movups xmm14, [r13+r14*1]
00007b78f51d64f7  movaps [r15+0x240], xmm14
00007b78f51d64ff  movaps xmm10, xmm1
00007b78f51d6503  addpd xmm10, xmm12
00007b78f51d6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007b78f51d650e  ptest xmm9, xmm9
00007b78f51d6514  jnz 0x00007B78F51DAAD5
00007b78f51d651a  movaps [r15+0x170], xmm10
00007b78f51d6522  vmovaps xmm1, [rsp+0x20]
00007b78f51d6528  vpermilpd xmm1, xmm1, 0x00
00007b78f51d652e  movaps xmm12, xmm14
00007b78f51d6532  mulpd xmm12, xmm1
00007b78f51d6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007b78f51d653d  ptest xmm9, xmm9
00007b78f51d6543  jnz 0x00007B78F51DAC18
00007b78f51d6549  vmovaps xmm1, [rsp+0x20]
00007b78f51d654f  vpermilpd xmm1, xmm1, 0x00
00007b78f51d6555  vmovaps xmm9, [rsp+0xB0]
00007b78f51d655e  movaps xmm14, xmm9
00007b78f51d6562  mulpd xmm14, xmm1
00007b78f51d6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007b78f51d656d  ptest xmm6, xmm6
00007b78f51d6572  jnz 0x00007B78F51DAD5B
00007b78f51d6578  movaps [r15+0x180], xmm14
00007b78f51d6580  movaps xmm1, xmm13
00007b78f51d6584  addpd xmm1, xmm8
00007b78f51d6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007b78f51d658e  ptest xmm9, xmm9
00007b78f51d6594  jnz 0x00007B78F51DAE9E
00007b78f51d659a  movaps [r15+0x210], xmm1
00007b78f51d65a2  movups xmm13, [r13+rax*1]
00007b78f51d65a8  lea r14, [rax+0x10]
00007b78f51d65ac  movups xmm9, [r13+r14*1]
00007b78f51d65b2  movaps [r15+0x230], xmm9
00007b78f51d65ba  movaps xmm8, xmm15
00007b78f51d65be  addpd xmm8, xmm7
00007b78f51d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007b78f51d65c9  ptest xmm6, xmm6
00007b78f51d65ce  jnz 0x00007B78F51DAFF4
00007b78f51d65d4  movaps [r15+0x130], xmm8
00007b78f51d65dc  vmovaps xmm15, [rsp+0x20]
00007b78f51d65e2  vpermilpd xmm15, xmm15, 0x00
00007b78f51d65e8  movaps xmm7, xmm9
00007b78f51d65ec  mulpd xmm7, xmm15
00007b78f51d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007b78f51d65f6  ptest xmm6, xmm6
00007b78f51d65fb  jnz 0x00007B78F51DB137
00007b78f51d6601  movaps [r15+0x220], xmm7
00007b78f51d6609  vmovaps xmm15, [rsp+0x20]
00007b78f51d660f  vpermilpd xmm15, xmm15, 0x00
00007b78f51d6615  movaps xmm9, xmm13
00007b78f51d6619  mulpd xmm9, xmm15
00007b78f51d661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007b78f51d6624  ptest xmm6, xmm6
00007b78f51d6629  jnz 0x00007B78F51DB279
00007b78f51d662f  movaps xmm15, xmm11
00007b78f51d6633  addpd xmm15, xmm12
00007b78f51d6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007b78f51d663e  ptest xmm13, xmm13
00007b78f51d6644  jnz 0x00007B78F51DB3BD
00007b78f51d664a  movaps [r15+0x140], xmm15
00007b78f51d6652  movaps xmm13, xmm10
00007b78f51d6656  addpd xmm13, xmm14
00007b78f51d665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007b78f51d6661  ptest xmm12, xmm12
00007b78f51d6667  jnz 0x00007B78F51DB501
00007b78f51d666d  movaps [r15+0x150], xmm13
00007b78f51d6675  movaps xmm14, xmm1
00007b78f51d6679  addpd xmm14, xmm7
00007b78f51d667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007b78f51d6684  ptest xmm12, xmm12
00007b78f51d668a  jnz 0x00007B78F51DB645
00007b78f51d6690  movaps [r15+0x160], xmm14
00007b78f51d6698  movaps xmm1, xmm8
00007b78f51d669c  addpd xmm1, xmm9
00007b78f51d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007b78f51d66a6  ptest xmm12, xmm12
00007b78f51d66ac  jnz 0x00007B78F51DB787
00007b78f51d66b2  movaps [r15+0x120], xmm1
00007b78f51d66ba  movups [r13+r11*1], xmm15
00007b78f51d66c0  lea rax, [r11+0x10]
00007b78f51d66c4  movups [r13+rax*1], xmm13
00007b78f51d66ca  lea rax, [r11+0x20]
00007b78f51d66ce  movups [r13+rax*1], xmm14
00007b78f51d66d4  lea rax, [r11+0x30]
00007b78f51d66d8  movups [r13+rax*1], xmm1
00007b78f51d66de  mov eax, [r15+0x108]
00007b78f51d66e5  sahf
00007b78f51d66e6  jnz 0x00007B78F51D6718
00007b78f51d66e8  cmp dword ptr [r15+0x318], 0x00
00007b78f51d66f0  jz 0x00007B78F51DB900
00007b78f51d66f6  nop [rax+rax*1], ax
00007b78f51d66ff  nop [rax+rax*1], eax
00007b78f51d6707  mov eax, 0x410444
00007b78f51d670c  mov [r15+0x100], rax
00007b78f51d6713  jmp 0x00007B78F4FFE110
00007b78f51d6718  cmp dword ptr [r15+0x318], 0x00
00007b78f51d6720  jz 0x00007B78F51D57E0
00007b78f51d6726  nop [rax+rax*1], ax
00007b78f51d672f  nop [rax+rax*1], eax
00007b78f51d6737  mov eax, 0x410278
00007b78f51d673c  mov [r15+0x100], rax
00007b78f51d6743  jmp 0x00007B78F4FFE110
00007b78f51d6748  int3
00007b78f51d6749  call 0x00007B78F500A4B0
00007b78f51d674e  jmp 0x00007B78F51D5828
00007b78f51d6753  call 0x00007B78F5009240
00007b78f51d6758  jmp 0x00007B78F51D5832
00007b78f51d675d  call 0x00007B78F500A4B0
00007b78f51d6762  jmp 0x00007B78F51D588F
00007b78f51d6767  call 0x00007B78F5009240
00007b78f51d676c  jmp 0x00007B78F51D5899
00007b78f51d6771  call 0x00007B78F500A4B0
00007b78f51d6776  jmp 0x00007B78F51D58DD
00007b78f51d677b  call 0x00007B78F5009240
00007b78f51d6780  jmp 0x00007B78F51D58E7
00007b78f51d6785  call 0x00007B78F50B47C0
00007b78f51d678a  jmp 0x00007B78F51D5926
00007b78f51d678f  call 0x00007B78F500B720
00007b78f51d6794  jmp 0x00007B78F51D593A
00007b78f51d6799  call 0x00007B78F50BFC30
00007b78f51d679e  jmp 0x00007B78F51D5958
00007b78f51d67a3  call 0x00007B78F50BE9C0
00007b78f51d67a8  jmp 0x00007B78F51D5962
00007b78f51d67ad  call 0x00007B78F50BD750
00007b78f51d67b2  jmp 0x00007B78F51D596C
00007b78f51d67b7  sub rsp, 0x08
00007b78f51d67bb  push rax
00007b78f51d67bc  push rcx
00007b78f51d67bd  push rdx
00007b78f51d67be  push rdi
00007b78f51d67bf  push rsi
00007b78f51d67c0  push r8
00007b78f51d67c2  push r9
00007b78f51d67c4  push r10
00007b78f51d67c6  push r11
00007b78f51d67c8  sub rsp, 0xF0
00007b78f51d67cf  vmovaps [rsp], xmm0
00007b78f51d67d4  vmovaps [rsp+0x10], xmm1
00007b78f51d67da  vmovaps [rsp+0x20], xmm2
00007b78f51d67e0  vmovaps [rsp+0x30], xmm3
00007b78f51d67e6  vmovaps [rsp+0x40], xmm4
00007b78f51d67ec  vmovaps [rsp+0x50], xmm5
00007b78f51d67f2  vmovaps [rsp+0x60], xmm6
00007b78f51d67f8  vmovaps [rsp+0x70], xmm7
00007b78f51d67fe  vmovaps [rsp+0x80], xmm9
00007b78f51d6807  vmovaps [rsp+0x90], xmm10
00007b78f51d6810  vmovaps [rsp+0xA0], xmm11
00007b78f51d6819  vmovaps [rsp+0xB0], xmm12
00007b78f51d6822  vmovaps [rsp+0xC0], xmm13
00007b78f51d682b  vmovaps [rsp+0xD0], xmm14
00007b78f51d6834  vmovaps [rsp+0xE0], xmm15
00007b78f51d683d  sub rsp, 0x30
00007b78f51d6841  movaps [rsp], xmm8
00007b78f51d6846  movaps [rsp+0x10], xmm12
00007b78f51d684c  movaps [rsp+0x20], xmm15
00007b78f51d6852  lea rdi, [rsp]
00007b78f51d6856  mov esi, 0x00
00007b78f51d685b  mov rax, 0x597478C09530
00007b78f51d6865  call rax
00007b78f51d6867  movaps xmm8, [rsp]
00007b78f51d686c  add rsp, 0x30
00007b78f51d6870  vmovaps xmm0, [rsp]
00007b78f51d6875  vmovaps xmm1, [rsp+0x10]
00007b78f51d687b  vmovaps xmm2, [rsp+0x20]
00007b78f51d6881  vmovaps xmm3, [rsp+0x30]
00007b78f51d6887  vmovaps xmm4, [rsp+0x40]
00007b78f51d688d  vmovaps xmm5, [rsp+0x50]
00007b78f51d6893  vmovaps xmm6, [rsp+0x60]
00007b78f51d6899  vmovaps xmm7, [rsp+0x70]
00007b78f51d689f  vmovaps xmm9, [rsp+0x80]
00007b78f51d68a8  vmovaps xmm10, [rsp+0x90]
00007b78f51d68b1  vmovaps xmm11, [rsp+0xA0]
00007b78f51d68ba  vmovaps xmm12, [rsp+0xB0]
00007b78f51d68c3  vmovaps xmm13, [rsp+0xC0]
00007b78f51d68cc  vmovaps xmm14, [rsp+0xD0]
00007b78f51d68d5  vmovaps xmm15, [rsp+0xE0]
00007b78f51d68de  add rsp, 0xF0
00007b78f51d68e5  pop r11
00007b78f51d68e7  pop r10
00007b78f51d68e9  pop r9
00007b78f51d68eb  pop r8
00007b78f51d68ed  pop rsi
00007b78f51d68ee  pop rdi
00007b78f51d68ef  pop rdx
00007b78f51d68f0  pop rcx
00007b78f51d68f1  pop rax
00007b78f51d68f2  add rsp, 0x08
00007b78f51d68f6  jmp 0x00007B78F51D599A
00007b78f51d68fb  sub rsp, 0x08
00007b78f51d68ff  push rax
00007b78f51d6900  push rcx
00007b78f51d6901  push rdx
00007b78f51d6902  push rdi
00007b78f51d6903  push rsi
00007b78f51d6904  push r8
00007b78f51d6906  push r9
00007b78f51d6908  push r10
00007b78f51d690a  push r11
00007b78f51d690c  sub rsp, 0xF0
00007b78f51d6913  vmovaps [rsp], xmm0
00007b78f51d6918  vmovaps [rsp+0x10], xmm1
00007b78f51d691e  vmovaps [rsp+0x20], xmm2
00007b78f51d6924  vmovaps [rsp+0x30], xmm3
00007b78f51d692a  vmovaps [rsp+0x40], xmm4
00007b78f51d6930  vmovaps [rsp+0x50], xmm5
00007b78f51d6936  vmovaps [rsp+0x60], xmm6
00007b78f51d693c  vmovaps [rsp+0x70], xmm8
00007b78f51d6942  vmovaps [rsp+0x80], xmm9
00007b78f51d694b  vmovaps [rsp+0x90], xmm10
00007b78f51d6954  vmovaps [rsp+0xA0], xmm11
00007b78f51d695d  vmovaps [rsp+0xB0], xmm12
00007b78f51d6966  vmovaps [rsp+0xC0], xmm13
00007b78f51d696f  vmovaps [rsp+0xD0], xmm14
00007b78f51d6978  vmovaps [rsp+0xE0], xmm15
00007b78f51d6981  sub rsp, 0x30
00007b78f51d6985  movaps [rsp], xmm7
00007b78f51d6989  movaps [rsp+0x10], xmm9
00007b78f51d698f  movaps [rsp+0x20], xmm15
00007b78f51d6995  lea rdi, [rsp]
00007b78f51d6999  mov esi, 0x00
00007b78f51d699e  mov rax, 0x597478C09530
00007b78f51d69a8  call rax
00007b78f51d69aa  movaps xmm7, [rsp]
00007b78f51d69ae  add rsp, 0x30
00007b78f51d69b2  vmovaps xmm0, [rsp]
00007b78f51d69b7  vmovaps xmm1, [rsp+0x10]
00007b78f51d69bd  vmovaps xmm2, [rsp+0x20]
00007b78f51d69c3  vmovaps xmm3, [rsp+0x30]
00007b78f51d69c9  vmovaps xmm4, [rsp+0x40]
00007b78f51d69cf  vmovaps xmm5, [rsp+0x50]
00007b78f51d69d5  vmovaps xmm6, [rsp+0x60]
00007b78f51d69db  vmovaps xmm8, [rsp+0x70]
00007b78f51d69e1  vmovaps xmm9, [rsp+0x80]
00007b78f51d69ea  vmovaps xmm10, [rsp+0x90]
00007b78f51d69f3  vmovaps xmm11, [rsp+0xA0]
00007b78f51d69fc  vmovaps xmm12, [rsp+0xB0]
00007b78f51d6a05  vmovaps xmm13, [rsp+0xC0]
00007b78f51d6a0e  vmovaps xmm14, [rsp+0xD0]
00007b78f51d6a17  vmovaps xmm15, [rsp+0xE0]
00007b78f51d6a20  add rsp, 0xF0
00007b78f51d6a27  pop r11
00007b78f51d6a29  pop r10
00007b78f51d6a2b  pop r9
00007b78f51d6a2d  pop r8
00007b78f51d6a2f  pop rsi
00007b78f51d6a30  pop rdi
00007b78f51d6a31  pop rdx
00007b78f51d6a32  pop rcx
00007b78f51d6a33  pop rax
00007b78f51d6a34  add rsp, 0x08
00007b78f51d6a38  jmp 0x00007B78F51D59C8
00007b78f51d6a3d  sub rsp, 0x08
00007b78f51d6a41  push rax
00007b78f51d6a42  push rcx
00007b78f51d6a43  push rdx
00007b78f51d6a44  push rdi
00007b78f51d6a45  push rsi
00007b78f51d6a46  push r8
00007b78f51d6a48  push r9
00007b78f51d6a4a  push r10
00007b78f51d6a4c  push r11
00007b78f51d6a4e  sub rsp, 0xF0
00007b78f51d6a55  vmovaps [rsp], xmm0
00007b78f51d6a5a  vmovaps [rsp+0x10], xmm1
00007b78f51d6a60  vmovaps [rsp+0x20], xmm2
00007b78f51d6a66  vmovaps [rsp+0x30], xmm3
00007b78f51d6a6c  vmovaps [rsp+0x40], xmm4
00007b78f51d6a72  vmovaps [rsp+0x50], xmm5
00007b78f51d6a78  vmovaps [rsp+0x60], xmm6
00007b78f51d6a7e  vmovaps [rsp+0x70], xmm7
00007b78f51d6a84  vmovaps [rsp+0x80], xmm8
00007b78f51d6a8d  vmovaps [rsp+0x90], xmm10
00007b78f51d6a96  vmovaps [rsp+0xA0], xmm11
00007b78f51d6a9f  vmovaps [rsp+0xB0], xmm12
00007b78f51d6aa8  vmovaps [rsp+0xC0], xmm13
00007b78f51d6ab1  vmovaps [rsp+0xD0], xmm14
00007b78f51d6aba  vmovaps [rsp+0xE0], xmm15
00007b78f51d6ac3  sub rsp, 0x30
00007b78f51d6ac7  movaps [rsp], xmm9
00007b78f51d6acc  movaps [rsp+0x10], xmm12
00007b78f51d6ad2  movaps [rsp+0x20], xmm10
00007b78f51d6ad8  lea rdi, [rsp]
00007b78f51d6adc  mov esi, 0x00
00007b78f51d6ae1  mov rax, 0x597478C09530
00007b78f51d6aeb  call rax
00007b78f51d6aed  movaps xmm9, [rsp]
00007b78f51d6af2  add rsp, 0x30
00007b78f51d6af6  vmovaps xmm0, [rsp]
00007b78f51d6afb  vmovaps xmm1, [rsp+0x10]
00007b78f51d6b01  vmovaps xmm2, [rsp+0x20]
00007b78f51d6b07  vmovaps xmm3, [rsp+0x30]
00007b78f51d6b0d  vmovaps xmm4, [rsp+0x40]
00007b78f51d6b13  vmovaps xmm5, [rsp+0x50]
00007b78f51d6b19  vmovaps xmm6, [rsp+0x60]
00007b78f51d6b1f  vmovaps xmm7, [rsp+0x70]
00007b78f51d6b25  vmovaps xmm8, [rsp+0x80]
00007b78f51d6b2e  vmovaps xmm10, [rsp+0x90]
00007b78f51d6b37  vmovaps xmm11, [rsp+0xA0]
00007b78f51d6b40  vmovaps xmm12, [rsp+0xB0]
00007b78f51d6b49  vmovaps xmm13, [rsp+0xC0]
00007b78f51d6b52  vmovaps xmm14, [rsp+0xD0]
00007b78f51d6b5b  vmovaps xmm15, [rsp+0xE0]
00007b78f51d6b64  add rsp, 0xF0
00007b78f51d6b6b  pop r11
00007b78f51d6b6d  pop r10
00007b78f51d6b6f  pop r9
00007b78f51d6b71  pop r8
00007b78f51d6b73  pop rsi
00007b78f51d6b74  pop rdi
00007b78f51d6b75  pop rdx
00007b78f51d6b76  pop rcx
00007b78f51d6b77  pop rax
00007b78f51d6b78  add rsp, 0x08
00007b78f51d6b7c  jmp 0x00007B78F51D59EC
00007b78f51d6b81  sub rsp, 0x08
00007b78f51d6b85  push rax
00007b78f51d6b86  push rcx
00007b78f51d6b87  push rdx
00007b78f51d6b88  push rdi
00007b78f51d6b89  push rsi
00007b78f51d6b8a  push r8
00007b78f51d6b8c  push r9
00007b78f51d6b8e  push r10
00007b78f51d6b90  push r11
00007b78f51d6b92  sub rsp, 0xF0
00007b78f51d6b99  vmovaps [rsp], xmm0
00007b78f51d6b9e  vmovaps [rsp+0x10], xmm1
00007b78f51d6ba4  vmovaps [rsp+0x20], xmm2
00007b78f51d6baa  vmovaps [rsp+0x30], xmm3
00007b78f51d6bb0  vmovaps [rsp+0x40], xmm4
00007b78f51d6bb6  vmovaps [rsp+0x50], xmm5
00007b78f51d6bbc  vmovaps [rsp+0x60], xmm6
00007b78f51d6bc2  vmovaps [rsp+0x70], xmm7
00007b78f51d6bc8  vmovaps [rsp+0x80], xmm8
00007b78f51d6bd1  vmovaps [rsp+0x90], xmm9
00007b78f51d6bda  vmovaps [rsp+0xA0], xmm11
00007b78f51d6be3  vmovaps [rsp+0xB0], xmm12
00007b78f51d6bec  vmovaps [rsp+0xC0], xmm13
00007b78f51d6bf5  vmovaps [rsp+0xD0], xmm14
00007b78f51d6bfe  vmovaps [rsp+0xE0], xmm15
00007b78f51d6c07  sub rsp, 0x30
00007b78f51d6c0b  movaps [rsp], xmm10
00007b78f51d6c10  movaps [rsp+0x10], xmm12
00007b78f51d6c16  movaps [rsp+0x20], xmm11
00007b78f51d6c1c  lea rdi, [rsp]
00007b78f51d6c20  mov esi, 0x00
00007b78f51d6c25  mov rax, 0x597478C09530
00007b78f51d6c2f  call rax
00007b78f51d6c31  movaps xmm10, [rsp]
00007b78f51d6c36  add rsp, 0x30
00007b78f51d6c3a  vmovaps xmm0, [rsp]
00007b78f51d6c3f  vmovaps xmm1, [rsp+0x10]
00007b78f51d6c45  vmovaps xmm2, [rsp+0x20]
00007b78f51d6c4b  vmovaps xmm3, [rsp+0x30]
00007b78f51d6c51  vmovaps xmm4, [rsp+0x40]
00007b78f51d6c57  vmovaps xmm5, [rsp+0x50]
00007b78f51d6c5d  vmovaps xmm6, [rsp+0x60]
00007b78f51d6c63  vmovaps xmm7, [rsp+0x70]
00007b78f51d6c69  vmovaps xmm8, [rsp+0x80]
00007b78f51d6c72  vmovaps xmm9, [rsp+0x90]
00007b78f51d6c7b  vmovaps xmm11, [rsp+0xA0]
00007b78f51d6c84  vmovaps xmm12, [rsp+0xB0]
00007b78f51d6c8d  vmovaps xmm13, [rsp+0xC0]
00007b78f51d6c96  vmovaps xmm14, [rsp+0xD0]
00007b78f51d6c9f  vmovaps xmm15, [rsp+0xE0]
00007b78f51d6ca8  add rsp, 0xF0
00007b78f51d6caf  pop r11
00007b78f51d6cb1  pop r10
00007b78f51d6cb3  pop r9
00007b78f51d6cb5  pop r8
00007b78f51d6cb7  pop rsi
00007b78f51d6cb8  pop rdi
00007b78f51d6cb9  pop rdx
00007b78f51d6cba  pop rcx
00007b78f51d6cbb  pop rax
00007b78f51d6cbc  add rsp, 0x08
00007b78f51d6cc0  jmp 0x00007B78F51D5A06
00007b78f51d6cc5  sub rsp, 0x08
00007b78f51d6cc9  push rax
00007b78f51d6cca  push rcx
00007b78f51d6ccb  push rdx
00007b78f51d6ccc  push rdi
00007b78f51d6ccd  push rsi
00007b78f51d6cce  push r8
00007b78f51d6cd0  push r9
00007b78f51d6cd2  push r10
00007b78f51d6cd4  push r11
00007b78f51d6cd6  sub rsp, 0xF0
00007b78f51d6cdd  vmovaps [rsp], xmm0
00007b78f51d6ce2  vmovaps [rsp+0x10], xmm1
00007b78f51d6ce8  vmovaps [rsp+0x20], xmm2
00007b78f51d6cee  vmovaps [rsp+0x30], xmm3
00007b78f51d6cf4  vmovaps [rsp+0x40], xmm4
00007b78f51d6cfa  vmovaps [rsp+0x50], xmm5
00007b78f51d6d00  vmovaps [rsp+0x60], xmm7
00007b78f51d6d06  vmovaps [rsp+0x70], xmm8
00007b78f51d6d0c  vmovaps [rsp+0x80], xmm9
00007b78f51d6d15  vmovaps [rsp+0x90], xmm10
00007b78f51d6d1e  vmovaps [rsp+0xA0], xmm11
00007b78f51d6d27  vmovaps [rsp+0xB0], xmm12
00007b78f51d6d30  vmovaps [rsp+0xC0], xmm13
00007b78f51d6d39  vmovaps [rsp+0xD0], xmm14
00007b78f51d6d42  vmovaps [rsp+0xE0], xmm15
00007b78f51d6d4b  sub rsp, 0x30
00007b78f51d6d4f  movaps [rsp], xmm6
00007b78f51d6d53  movaps [rsp+0x10], xmm12
00007b78f51d6d59  movaps [rsp+0x20], xmm11
00007b78f51d6d5f  lea rdi, [rsp]
00007b78f51d6d63  mov esi, 0x00
00007b78f51d6d68  mov rax, 0x597478C09530
00007b78f51d6d72  call rax
00007b78f51d6d74  movaps xmm6, [rsp]
00007b78f51d6d78  add rsp, 0x30
00007b78f51d6d7c  vmovaps xmm0, [rsp]
00007b78f51d6d81  vmovaps xmm1, [rsp+0x10]
00007b78f51d6d87  vmovaps xmm2, [rsp+0x20]
00007b78f51d6d8d  vmovaps xmm3, [rsp+0x30]
00007b78f51d6d93  vmovaps xmm4, [rsp+0x40]
00007b78f51d6d99  vmovaps xmm5, [rsp+0x50]
00007b78f51d6d9f  vmovaps xmm7, [rsp+0x60]
00007b78f51d6da5  vmovaps xmm8, [rsp+0x70]
00007b78f51d6dab  vmovaps xmm9, [rsp+0x80]
00007b78f51d6db4  vmovaps xmm10, [rsp+0x90]
00007b78f51d6dbd  vmovaps xmm11, [rsp+0xA0]
00007b78f51d6dc6  vmovaps xmm12, [rsp+0xB0]
00007b78f51d6dcf  vmovaps xmm13, [rsp+0xC0]
00007b78f51d6dd8  vmovaps xmm14, [rsp+0xD0]
00007b78f51d6de1  vmovaps xmm15, [rsp+0xE0]
00007b78f51d6dea  add rsp, 0xF0
00007b78f51d6df1  pop r11
00007b78f51d6df3  pop r10
00007b78f51d6df5  pop r9
00007b78f51d6df7  pop r8
00007b78f51d6df9  pop rsi
00007b78f51d6dfa  pop rdi
00007b78f51d6dfb  pop rdx
00007b78f51d6dfc  pop rcx
00007b78f51d6dfd  pop rax
00007b78f51d6dfe  add rsp, 0x08
00007b78f51d6e02  jmp 0x00007B78F51D5A27
00007b78f51d6e07  sub rsp, 0x08
00007b78f51d6e0b  push rax
00007b78f51d6e0c  push rcx
00007b78f51d6e0d  push rdx
00007b78f51d6e0e  push rdi
00007b78f51d6e0f  push rsi
00007b78f51d6e10  push r8
00007b78f51d6e12  push r9
00007b78f51d6e14  push r10
00007b78f51d6e16  push r11
00007b78f51d6e18  sub rsp, 0xF0
00007b78f51d6e1f  vmovaps [rsp], xmm0
00007b78f51d6e24  vmovaps [rsp+0x10], xmm1
00007b78f51d6e2a  vmovaps [rsp+0x20], xmm2
00007b78f51d6e30  vmovaps [rsp+0x30], xmm4
00007b78f51d6e36  vmovaps [rsp+0x40], xmm5
00007b78f51d6e3c  vmovaps [rsp+0x50], xmm6
00007b78f51d6e42  vmovaps [rsp+0x60], xmm7
00007b78f51d6e48  vmovaps [rsp+0x70], xmm8
00007b78f51d6e4e  vmovaps [rsp+0x80], xmm9
00007b78f51d6e57  vmovaps [rsp+0x90], xmm10
00007b78f51d6e60  vmovaps [rsp+0xA0], xmm11
00007b78f51d6e69  vmovaps [rsp+0xB0], xmm12
00007b78f51d6e72  vmovaps [rsp+0xC0], xmm13
00007b78f51d6e7b  vmovaps [rsp+0xD0], xmm14
00007b78f51d6e84  vmovaps [rsp+0xE0], xmm15
00007b78f51d6e8d  sub rsp, 0x30
00007b78f51d6e91  movaps [rsp], xmm3
00007b78f51d6e95  movaps [rsp+0x10], xmm5
00007b78f51d6e9a  movaps [rsp+0x20], xmm4
00007b78f51d6e9f  lea rdi, [rsp]
00007b78f51d6ea3  mov esi, 0x00
00007b78f51d6ea8  mov rax, 0x597478C09530
00007b78f51d6eb2  call rax
00007b78f51d6eb4  movaps xmm3, [rsp]
00007b78f51d6eb8  add rsp, 0x30
00007b78f51d6ebc  vmovaps xmm0, [rsp]
00007b78f51d6ec1  vmovaps xmm1, [rsp+0x10]
00007b78f51d6ec7  vmovaps xmm2, [rsp+0x20]
00007b78f51d6ecd  vmovaps xmm4, [rsp+0x30]
00007b78f51d6ed3  vmovaps xmm5, [rsp+0x40]
00007b78f51d6ed9  vmovaps xmm6, [rsp+0x50]
00007b78f51d6edf  vmovaps xmm7, [rsp+0x60]
00007b78f51d6ee5  vmovaps xmm8, [rsp+0x70]
00007b78f51d6eeb  vmovaps xmm9, [rsp+0x80]
00007b78f51d6ef4  vmovaps xmm10, [rsp+0x90]
00007b78f51d6efd  vmovaps xmm11, [rsp+0xA0]
00007b78f51d6f06  vmovaps xmm12, [rsp+0xB0]
00007b78f51d6f0f  vmovaps xmm13, [rsp+0xC0]
00007b78f51d6f18  vmovaps xmm14, [rsp+0xD0]
00007b78f51d6f21  vmovaps xmm15, [rsp+0xE0]
00007b78f51d6f2a  add rsp, 0xF0
00007b78f51d6f31  pop r11
00007b78f51d6f33  pop r10
00007b78f51d6f35  pop r9
00007b78f51d6f37  pop r8
00007b78f51d6f39  pop rsi
00007b78f51d6f3a  pop rdi
00007b78f51d6f3b  pop rdx
00007b78f51d6f3c  pop rcx
00007b78f51d6f3d  pop rax
00007b78f51d6f3e  add rsp, 0x08
00007b78f51d6f42  jmp 0x00007B78F51D5A88
00007b78f51d6f47  sub rsp, 0x08
00007b78f51d6f4b  push rax
00007b78f51d6f4c  push rcx
00007b78f51d6f4d  push rdx
00007b78f51d6f4e  push rdi
00007b78f51d6f4f  push rsi
00007b78f51d6f50  push r8
00007b78f51d6f52  push r9
00007b78f51d6f54  push r10
00007b78f51d6f56  push r11
00007b78f51d6f58  sub rsp, 0xF0
00007b78f51d6f5f  vmovaps [rsp], xmm0
00007b78f51d6f64  vmovaps [rsp+0x10], xmm1
00007b78f51d6f6a  vmovaps [rsp+0x20], xmm2
00007b78f51d6f70  vmovaps [rsp+0x30], xmm3
00007b78f51d6f76  vmovaps [rsp+0x40], xmm4
00007b78f51d6f7c  vmovaps [rsp+0x50], xmm6
00007b78f51d6f82  vmovaps [rsp+0x60], xmm7
00007b78f51d6f88  vmovaps [rsp+0x70], xmm8
00007b78f51d6f8e  vmovaps [rsp+0x80], xmm9
00007b78f51d6f97  vmovaps [rsp+0x90], xmm10
00007b78f51d6fa0  vmovaps [rsp+0xA0], xmm11
00007b78f51d6fa9  vmovaps [rsp+0xB0], xmm12
00007b78f51d6fb2  vmovaps [rsp+0xC0], xmm13
00007b78f51d6fbb  vmovaps [rsp+0xD0], xmm14
00007b78f51d6fc4  vmovaps [rsp+0xE0], xmm15
00007b78f51d6fcd  sub rsp, 0x30
00007b78f51d6fd1  movaps [rsp], xmm5
00007b78f51d6fd5  movaps [rsp+0x10], xmm8
00007b78f51d6fdb  movaps [rsp+0x20], xmm15
00007b78f51d6fe1  lea rdi, [rsp]
00007b78f51d6fe5  mov esi, 0x00
00007b78f51d6fea  mov rax, 0x597478C09530
00007b78f51d6ff4  call rax
00007b78f51d6ff6  movaps xmm5, [rsp]
00007b78f51d6ffa  add rsp, 0x30
00007b78f51d6ffe  vmovaps xmm0, [rsp]
00007b78f51d7003  vmovaps xmm1, [rsp+0x10]
00007b78f51d7009  vmovaps xmm2, [rsp+0x20]
00007b78f51d700f  vmovaps xmm3, [rsp+0x30]
00007b78f51d7015  vmovaps xmm4, [rsp+0x40]
00007b78f51d701b  vmovaps xmm6, [rsp+0x50]
00007b78f51d7021  vmovaps xmm7, [rsp+0x60]
00007b78f51d7027  vmovaps xmm8, [rsp+0x70]
00007b78f51d702d  vmovaps xmm9, [rsp+0x80]
00007b78f51d7036  vmovaps xmm10, [rsp+0x90]
00007b78f51d703f  vmovaps xmm11, [rsp+0xA0]
00007b78f51d7048  vmovaps xmm12, [rsp+0xB0]
00007b78f51d7051  vmovaps xmm13, [rsp+0xC0]
00007b78f51d705a  vmovaps xmm14, [rsp+0xD0]
00007b78f51d7063  vmovaps xmm15, [rsp+0xE0]
00007b78f51d706c  add rsp, 0xF0
00007b78f51d7073  pop r11
00007b78f51d7075  pop r10
00007b78f51d7077  pop r9
00007b78f51d7079  pop r8
00007b78f51d707b  pop rsi
00007b78f51d707c  pop rdi
00007b78f51d707d  pop rdx
00007b78f51d707e  pop rcx
00007b78f51d707f  pop rax
00007b78f51d7080  add rsp, 0x08
00007b78f51d7084  jmp 0x00007B78F51D5AC0
00007b78f51d7089  sub rsp, 0x08
00007b78f51d708d  push rax
00007b78f51d708e  push rcx
00007b78f51d708f  push rdx
00007b78f51d7090  push rdi
00007b78f51d7091  push rsi
00007b78f51d7092  push r8
00007b78f51d7094  push r9
00007b78f51d7096  push r10
00007b78f51d7098  push r11
00007b78f51d709a  sub rsp, 0xF0
00007b78f51d70a1  vmovaps [rsp], xmm0
00007b78f51d70a6  vmovaps [rsp+0x10], xmm1
00007b78f51d70ac  vmovaps [rsp+0x20], xmm2
00007b78f51d70b2  vmovaps [rsp+0x30], xmm3
00007b78f51d70b8  vmovaps [rsp+0x40], xmm5
00007b78f51d70be  vmovaps [rsp+0x50], xmm6
00007b78f51d70c4  vmovaps [rsp+0x60], xmm7
00007b78f51d70ca  vmovaps [rsp+0x70], xmm8
00007b78f51d70d0  vmovaps [rsp+0x80], xmm9
00007b78f51d70d9  vmovaps [rsp+0x90], xmm10
00007b78f51d70e2  vmovaps [rsp+0xA0], xmm11
00007b78f51d70eb  vmovaps [rsp+0xB0], xmm12
00007b78f51d70f4  vmovaps [rsp+0xC0], xmm13
00007b78f51d70fd  vmovaps [rsp+0xD0], xmm14
00007b78f51d7106  vmovaps [rsp+0xE0], xmm15
00007b78f51d710f  sub rsp, 0x30
00007b78f51d7113  movaps [rsp], xmm4
00007b78f51d7117  movaps [rsp+0x10], xmm9
00007b78f51d711d  movaps [rsp+0x20], xmm8
00007b78f51d7123  lea rdi, [rsp]
00007b78f51d7127  mov esi, 0x00
00007b78f51d712c  mov rax, 0x597478C09530
00007b78f51d7136  call rax
00007b78f51d7138  movaps xmm4, [rsp]
00007b78f51d713c  add rsp, 0x30
00007b78f51d7140  vmovaps xmm0, [rsp]
00007b78f51d7145  vmovaps xmm1, [rsp+0x10]
00007b78f51d714b  vmovaps xmm2, [rsp+0x20]
00007b78f51d7151  vmovaps xmm3, [rsp+0x30]
00007b78f51d7157  vmovaps xmm5, [rsp+0x40]
00007b78f51d715d  vmovaps xmm6, [rsp+0x50]
00007b78f51d7163  vmovaps xmm7, [rsp+0x60]
00007b78f51d7169  vmovaps xmm8, [rsp+0x70]
00007b78f51d716f  vmovaps xmm9, [rsp+0x80]
00007b78f51d7178  vmovaps xmm10, [rsp+0x90]
00007b78f51d7181  vmovaps xmm11, [rsp+0xA0]
00007b78f51d718a  vmovaps xmm12, [rsp+0xB0]
00007b78f51d7193  vmovaps xmm13, [rsp+0xC0]
00007b78f51d719c  vmovaps xmm14, [rsp+0xD0]
00007b78f51d71a5  vmovaps xmm15, [rsp+0xE0]
00007b78f51d71ae  add rsp, 0xF0
00007b78f51d71b5  pop r11
00007b78f51d71b7  pop r10
00007b78f51d71b9  pop r9
00007b78f51d71bb  pop r8
00007b78f51d71bd  pop rsi
00007b78f51d71be  pop rdi
00007b78f51d71bf  pop rdx
00007b78f51d71c0  pop rcx
00007b78f51d71c1  pop rax
00007b78f51d71c2  add rsp, 0x08
00007b78f51d71c6  jmp 0x00007B78F51D5AE1
00007b78f51d71cb  sub rsp, 0x08
00007b78f51d71cf  push rax
00007b78f51d71d0  push rcx
00007b78f51d71d1  push rdx
00007b78f51d71d2  push rdi
00007b78f51d71d3  push rsi
00007b78f51d71d4  push r8
00007b78f51d71d6  push r9
00007b78f51d71d8  push r10
00007b78f51d71da  push r11
00007b78f51d71dc  sub rsp, 0xF0
00007b78f51d71e3  vmovaps [rsp], xmm0
00007b78f51d71e8  vmovaps [rsp+0x10], xmm1
00007b78f51d71ee  vmovaps [rsp+0x20], xmm2
00007b78f51d71f4  vmovaps [rsp+0x30], xmm3
00007b78f51d71fa  vmovaps [rsp+0x40], xmm4
00007b78f51d7200  vmovaps [rsp+0x50], xmm5
00007b78f51d7206  vmovaps [rsp+0x60], xmm6
00007b78f51d720c  vmovaps [rsp+0x70], xmm7
00007b78f51d7212  vmovaps [rsp+0x80], xmm8
00007b78f51d721b  vmovaps [rsp+0x90], xmm10
00007b78f51d7224  vmovaps [rsp+0xA0], xmm11
00007b78f51d722d  vmovaps [rsp+0xB0], xmm12
00007b78f51d7236  vmovaps [rsp+0xC0], xmm13
00007b78f51d723f  vmovaps [rsp+0xD0], xmm14
00007b78f51d7248  vmovaps [rsp+0xE0], xmm15
00007b78f51d7251  sub rsp, 0x30
00007b78f51d7255  movaps [rsp], xmm9
00007b78f51d725a  movaps [rsp+0x10], xmm10
00007b78f51d7260  movaps [rsp+0x20], xmm8
00007b78f51d7266  lea rdi, [rsp]
00007b78f51d726a  mov esi, 0x00
00007b78f51d726f  mov rax, 0x597478C09530
00007b78f51d7279  call rax
00007b78f51d727b  movaps xmm9, [rsp]
00007b78f51d7280  add rsp, 0x30
00007b78f51d7284  vmovaps xmm0, [rsp]
00007b78f51d7289  vmovaps xmm1, [rsp+0x10]
00007b78f51d728f  vmovaps xmm2, [rsp+0x20]
00007b78f51d7295  vmovaps xmm3, [rsp+0x30]
00007b78f51d729b  vmovaps xmm4, [rsp+0x40]
00007b78f51d72a1  vmovaps xmm5, [rsp+0x50]
00007b78f51d72a7  vmovaps xmm6, [rsp+0x60]
00007b78f51d72ad  vmovaps xmm7, [rsp+0x70]
00007b78f51d72b3  vmovaps xmm8, [rsp+0x80]
00007b78f51d72bc  vmovaps xmm10, [rsp+0x90]
00007b78f51d72c5  vmovaps xmm11, [rsp+0xA0]
00007b78f51d72ce  vmovaps xmm12, [rsp+0xB0]
00007b78f51d72d7  vmovaps xmm13, [rsp+0xC0]
00007b78f51d72e0  vmovaps xmm14, [rsp+0xD0]
00007b78f51d72e9  vmovaps xmm15, [rsp+0xE0]
00007b78f51d72f2  add rsp, 0xF0
00007b78f51d72f9  pop r11
00007b78f51d72fb  pop r10
00007b78f51d72fd  pop r9
00007b78f51d72ff  pop r8
00007b78f51d7301  pop rsi
00007b78f51d7302  pop rdi
00007b78f51d7303  pop rdx
00007b78f51d7304  pop rcx
00007b78f51d7305  pop rax
00007b78f51d7306  add rsp, 0x08
00007b78f51d730a  jmp 0x00007B78F51D5AFB
00007b78f51d730f  call 0x00007B78F50D64F0
00007b78f51d7314  jmp 0x00007B78F51D5C15
00007b78f51d7319  call 0x00007B78F50D64F0
00007b78f51d731e  jmp 0x00007B78F51D5C2B
00007b78f51d7323  sub rsp, 0x08
00007b78f51d7327  push rax
00007b78f51d7328  push rcx
00007b78f51d7329  push rdx
00007b78f51d732a  push rdi
00007b78f51d732b  push rsi
00007b78f51d732c  push r8
00007b78f51d732e  push r9
00007b78f51d7330  push r10
00007b78f51d7332  push r11
00007b78f51d7334  sub rsp, 0xF0
00007b78f51d733b  vmovaps [rsp], xmm0
00007b78f51d7340  vmovaps [rsp+0x10], xmm2
00007b78f51d7346  vmovaps [rsp+0x20], xmm3
00007b78f51d734c  vmovaps [rsp+0x30], xmm4
00007b78f51d7352  vmovaps [rsp+0x40], xmm5
00007b78f51d7358  vmovaps [rsp+0x50], xmm6
00007b78f51d735e  vmovaps [rsp+0x60], xmm7
00007b78f51d7364  vmovaps [rsp+0x70], xmm8
00007b78f51d736a  vmovaps [rsp+0x80], xmm9
00007b78f51d7373  vmovaps [rsp+0x90], xmm10
00007b78f51d737c  vmovaps [rsp+0xA0], xmm11
00007b78f51d7385  vmovaps [rsp+0xB0], xmm12
00007b78f51d738e  vmovaps [rsp+0xC0], xmm13
00007b78f51d7397  vmovaps [rsp+0xD0], xmm14
00007b78f51d73a0  vmovaps [rsp+0xE0], xmm15
00007b78f51d73a9  sub rsp, 0x30
00007b78f51d73ad  movaps [rsp], xmm1
00007b78f51d73b1  movaps [rsp+0x10], xmm6
00007b78f51d73b6  movaps [rsp+0x20], xmm15
00007b78f51d73bc  lea rdi, [rsp]
00007b78f51d73c0  mov esi, 0x00
00007b78f51d73c5  mov rax, 0x597478C09530
00007b78f51d73cf  call rax
00007b78f51d73d1  movaps xmm1, [rsp]
00007b78f51d73d5  add rsp, 0x30
00007b78f51d73d9  vmovaps xmm0, [rsp]
00007b78f51d73de  vmovaps xmm2, [rsp+0x10]
00007b78f51d73e4  vmovaps xmm3, [rsp+0x20]
00007b78f51d73ea  vmovaps xmm4, [rsp+0x30]
00007b78f51d73f0  vmovaps xmm5, [rsp+0x40]
00007b78f51d73f6  vmovaps xmm6, [rsp+0x50]
00007b78f51d73fc  vmovaps xmm7, [rsp+0x60]
00007b78f51d7402  vmovaps xmm8, [rsp+0x70]
00007b78f51d7408  vmovaps xmm9, [rsp+0x80]
00007b78f51d7411  vmovaps xmm10, [rsp+0x90]
00007b78f51d741a  vmovaps xmm11, [rsp+0xA0]
00007b78f51d7423  vmovaps xmm12, [rsp+0xB0]
00007b78f51d742c  vmovaps xmm13, [rsp+0xC0]
00007b78f51d7435  vmovaps xmm14, [rsp+0xD0]
00007b78f51d743e  vmovaps xmm15, [rsp+0xE0]
00007b78f51d7447  add rsp, 0xF0
00007b78f51d744e  pop r11
00007b78f51d7450  pop r10
00007b78f51d7452  pop r9
00007b78f51d7454  pop r8
00007b78f51d7456  pop rsi
00007b78f51d7457  pop rdi
00007b78f51d7458  pop rdx
00007b78f51d7459  pop rcx
00007b78f51d745a  pop rax
00007b78f51d745b  add rsp, 0x08
00007b78f51d745f  jmp 0x00007B78F51D5C68
00007b78f51d7464  call 0x00007B78F50E5820
00007b78f51d7469  jmp 0x00007B78F51D5C75
00007b78f51d746e  sub rsp, 0x08
00007b78f51d7472  push rax
00007b78f51d7473  push rcx
00007b78f51d7474  push rdx
00007b78f51d7475  push rdi
00007b78f51d7476  push rsi
00007b78f51d7477  push r8
00007b78f51d7479  push r9
00007b78f51d747b  push r10
00007b78f51d747d  push r11
00007b78f51d747f  sub rsp, 0xF0
00007b78f51d7486  vmovaps [rsp], xmm0
00007b78f51d748b  vmovaps [rsp+0x10], xmm1
00007b78f51d7491  vmovaps [rsp+0x20], xmm2
00007b78f51d7497  vmovaps [rsp+0x30], xmm3
00007b78f51d749d  vmovaps [rsp+0x40], xmm4
00007b78f51d74a3  vmovaps [rsp+0x50], xmm5
00007b78f51d74a9  vmovaps [rsp+0x60], xmm6
00007b78f51d74af  vmovaps [rsp+0x70], xmm7
00007b78f51d74b5  vmovaps [rsp+0x80], xmm8
00007b78f51d74be  vmovaps [rsp+0x90], xmm9
00007b78f51d74c7  vmovaps [rsp+0xA0], xmm10
00007b78f51d74d0  vmovaps [rsp+0xB0], xmm11
00007b78f51d74d9  vmovaps [rsp+0xC0], xmm12
00007b78f51d74e2  vmovaps [rsp+0xD0], xmm13
00007b78f51d74eb  vmovaps [rsp+0xE0], xmm15
00007b78f51d74f4  sub rsp, 0x30
00007b78f51d74f8  movaps [rsp], xmm14
00007b78f51d74fd  movaps [rsp+0x10], xmm4
00007b78f51d7502  movaps [rsp+0x20], xmm3
00007b78f51d7507  lea rdi, [rsp]
00007b78f51d750b  mov esi, 0x00
00007b78f51d7510  mov rax, 0x597478C09530
00007b78f51d751a  call rax
00007b78f51d751c  movaps xmm14, [rsp]
00007b78f51d7521  add rsp, 0x30
00007b78f51d7525  vmovaps xmm0, [rsp]
00007b78f51d752a  vmovaps xmm1, [rsp+0x10]
00007b78f51d7530  vmovaps xmm2, [rsp+0x20]
00007b78f51d7536  vmovaps xmm3, [rsp+0x30]
00007b78f51d753c  vmovaps xmm4, [rsp+0x40]
00007b78f51d7542  vmovaps xmm5, [rsp+0x50]
00007b78f51d7548  vmovaps xmm6, [rsp+0x60]
00007b78f51d754e  vmovaps xmm7, [rsp+0x70]
00007b78f51d7554  vmovaps xmm8, [rsp+0x80]
00007b78f51d755d  vmovaps xmm9, [rsp+0x90]
00007b78f51d7566  vmovaps xmm10, [rsp+0xA0]
00007b78f51d756f  vmovaps xmm11, [rsp+0xB0]
00007b78f51d7578  vmovaps xmm12, [rsp+0xC0]
00007b78f51d7581  vmovaps xmm13, [rsp+0xD0]
00007b78f51d758a  vmovaps xmm15, [rsp+0xE0]
00007b78f51d7593  add rsp, 0xF0
00007b78f51d759a  pop r11
00007b78f51d759c  pop r10
00007b78f51d759e  pop r9
00007b78f51d75a0  pop r8
00007b78f51d75a2  pop rsi
00007b78f51d75a3  pop rdi
00007b78f51d75a4  pop rdx
00007b78f51d75a5  pop rcx
00007b78f51d75a6  pop rax
00007b78f51d75a7  add rsp, 0x08
00007b78f51d75ab  jmp 0x00007B78F51D5C8F
00007b78f51d75b0  sub rsp, 0x08
00007b78f51d75b4  push rax
00007b78f51d75b5  push rcx
00007b78f51d75b6  push rdx
00007b78f51d75b7  push rdi
00007b78f51d75b8  push rsi
00007b78f51d75b9  push r8
00007b78f51d75bb  push r9
00007b78f51d75bd  push r10
00007b78f51d75bf  push r11
00007b78f51d75c1  sub rsp, 0xF0
00007b78f51d75c8  vmovaps [rsp], xmm0
00007b78f51d75cd  vmovaps [rsp+0x10], xmm1
00007b78f51d75d3  vmovaps [rsp+0x20], xmm2
00007b78f51d75d9  vmovaps [rsp+0x30], xmm3
00007b78f51d75df  vmovaps [rsp+0x40], xmm4
00007b78f51d75e5  vmovaps [rsp+0x50], xmm5
00007b78f51d75eb  vmovaps [rsp+0x60], xmm7
00007b78f51d75f1  vmovaps [rsp+0x70], xmm8
00007b78f51d75f7  vmovaps [rsp+0x80], xmm9
00007b78f51d7600  vmovaps [rsp+0x90], xmm10
00007b78f51d7609  vmovaps [rsp+0xA0], xmm11
00007b78f51d7612  vmovaps [rsp+0xB0], xmm12
00007b78f51d761b  vmovaps [rsp+0xC0], xmm13
00007b78f51d7624  vmovaps [rsp+0xD0], xmm14
00007b78f51d762d  vmovaps [rsp+0xE0], xmm15
00007b78f51d7636  sub rsp, 0x30
00007b78f51d763a  movaps [rsp], xmm6
00007b78f51d763e  movaps [rsp+0x10], xmm9
00007b78f51d7644  movaps [rsp+0x20], xmm7
00007b78f51d7649  lea rdi, [rsp]
00007b78f51d764d  mov esi, 0x00
00007b78f51d7652  mov rax, 0x597478C09530
00007b78f51d765c  call rax
00007b78f51d765e  movaps xmm6, [rsp]
00007b78f51d7662  add rsp, 0x30
00007b78f51d7666  vmovaps xmm0, [rsp]
00007b78f51d766b  vmovaps xmm1, [rsp+0x10]
00007b78f51d7671  vmovaps xmm2, [rsp+0x20]
00007b78f51d7677  vmovaps xmm3, [rsp+0x30]
00007b78f51d767d  vmovaps xmm4, [rsp+0x40]
00007b78f51d7683  vmovaps xmm5, [rsp+0x50]
00007b78f51d7689  vmovaps xmm7, [rsp+0x60]
00007b78f51d768f  vmovaps xmm8, [rsp+0x70]
00007b78f51d7695  vmovaps xmm9, [rsp+0x80]
00007b78f51d769e  vmovaps xmm10, [rsp+0x90]
00007b78f51d76a7  vmovaps xmm11, [rsp+0xA0]
00007b78f51d76b0  vmovaps xmm12, [rsp+0xB0]
00007b78f51d76b9  vmovaps xmm13, [rsp+0xC0]
00007b78f51d76c2  vmovaps xmm14, [rsp+0xD0]
00007b78f51d76cb  vmovaps xmm15, [rsp+0xE0]
00007b78f51d76d4  add rsp, 0xF0
00007b78f51d76db  pop r11
00007b78f51d76dd  pop r10
00007b78f51d76df  pop r9
00007b78f51d76e1  pop r8
00007b78f51d76e3  pop rsi
00007b78f51d76e4  pop rdi
00007b78f51d76e5  pop rdx
00007b78f51d76e6  pop rcx
00007b78f51d76e7  pop rax
00007b78f51d76e8  add rsp, 0x08
00007b78f51d76ec  jmp 0x00007B78F51D5CA7
00007b78f51d76f1  sub rsp, 0x08
00007b78f51d76f5  push rax
00007b78f51d76f6  push rcx
00007b78f51d76f7  push rdx
00007b78f51d76f8  push rdi
00007b78f51d76f9  push rsi
00007b78f51d76fa  push r8
00007b78f51d76fc  push r9
00007b78f51d76fe  push r10
00007b78f51d7700  push r11
00007b78f51d7702  sub rsp, 0xF0
00007b78f51d7709  vmovaps [rsp], xmm0
00007b78f51d770e  vmovaps [rsp+0x10], xmm1
00007b78f51d7714  vmovaps [rsp+0x20], xmm2
00007b78f51d771a  vmovaps [rsp+0x30], xmm3
00007b78f51d7720  vmovaps [rsp+0x40], xmm4
00007b78f51d7726  vmovaps [rsp+0x50], xmm5
00007b78f51d772c  vmovaps [rsp+0x60], xmm6
00007b78f51d7732  vmovaps [rsp+0x70], xmm8
00007b78f51d7738  vmovaps [rsp+0x80], xmm9
00007b78f51d7741  vmovaps [rsp+0x90], xmm10
00007b78f51d774a  vmovaps [rsp+0xA0], xmm11
00007b78f51d7753  vmovaps [rsp+0xB0], xmm12
00007b78f51d775c  vmovaps [rsp+0xC0], xmm13
00007b78f51d7765  vmovaps [rsp+0xD0], xmm14
00007b78f51d776e  vmovaps [rsp+0xE0], xmm15
00007b78f51d7777  sub rsp, 0x30
00007b78f51d777b  movaps [rsp], xmm7
00007b78f51d777f  movaps [rsp+0x10], xmm4
00007b78f51d7784  movaps [rsp+0x20], xmm9
00007b78f51d778a  lea rdi, [rsp]
00007b78f51d778e  mov esi, 0x00
00007b78f51d7793  mov rax, 0x597478C09530
00007b78f51d779d  call rax
00007b78f51d779f  movaps xmm7, [rsp]
00007b78f51d77a3  add rsp, 0x30
00007b78f51d77a7  vmovaps xmm0, [rsp]
00007b78f51d77ac  vmovaps xmm1, [rsp+0x10]
00007b78f51d77b2  vmovaps xmm2, [rsp+0x20]
00007b78f51d77b8  vmovaps xmm3, [rsp+0x30]
00007b78f51d77be  vmovaps xmm4, [rsp+0x40]
00007b78f51d77c4  vmovaps xmm5, [rsp+0x50]
00007b78f51d77ca  vmovaps xmm6, [rsp+0x60]
00007b78f51d77d0  vmovaps xmm8, [rsp+0x70]
00007b78f51d77d6  vmovaps xmm9, [rsp+0x80]
00007b78f51d77df  vmovaps xmm10, [rsp+0x90]
00007b78f51d77e8  vmovaps xmm11, [rsp+0xA0]
00007b78f51d77f1  vmovaps xmm12, [rsp+0xB0]
00007b78f51d77fa  vmovaps xmm13, [rsp+0xC0]
00007b78f51d7803  vmovaps xmm14, [rsp+0xD0]
00007b78f51d780c  vmovaps xmm15, [rsp+0xE0]
00007b78f51d7815  add rsp, 0xF0
00007b78f51d781c  pop r11
00007b78f51d781e  pop r10
00007b78f51d7820  pop r9
00007b78f51d7822  pop r8
00007b78f51d7824  pop rsi
00007b78f51d7825  pop rdi
00007b78f51d7826  pop rdx
00007b78f51d7827  pop rcx
00007b78f51d7828  pop rax
00007b78f51d7829  add rsp, 0x08
00007b78f51d782d  jmp 0x00007B78F51D5CD4
00007b78f51d7832  sub rsp, 0x08
00007b78f51d7836  push rax
00007b78f51d7837  push rcx
00007b78f51d7838  push rdx
00007b78f51d7839  push rdi
00007b78f51d783a  push rsi
00007b78f51d783b  push r8
00007b78f51d783d  push r9
00007b78f51d783f  push r10
00007b78f51d7841  push r11
00007b78f51d7843  sub rsp, 0xF0
00007b78f51d784a  vmovaps [rsp], xmm0
00007b78f51d784f  vmovaps [rsp+0x10], xmm1
00007b78f51d7855  vmovaps [rsp+0x20], xmm2
00007b78f51d785b  vmovaps [rsp+0x30], xmm3
00007b78f51d7861  vmovaps [rsp+0x40], xmm5
00007b78f51d7867  vmovaps [rsp+0x50], xmm6
00007b78f51d786d  vmovaps [rsp+0x60], xmm7
00007b78f51d7873  vmovaps [rsp+0x70], xmm8
00007b78f51d7879  vmovaps [rsp+0x80], xmm9
00007b78f51d7882  vmovaps [rsp+0x90], xmm10
00007b78f51d788b  vmovaps [rsp+0xA0], xmm11
00007b78f51d7894  vmovaps [rsp+0xB0], xmm12
00007b78f51d789d  vmovaps [rsp+0xC0], xmm13
00007b78f51d78a6  vmovaps [rsp+0xD0], xmm14
00007b78f51d78af  vmovaps [rsp+0xE0], xmm15
00007b78f51d78b8  sub rsp, 0x30
00007b78f51d78bc  movaps [rsp], xmm4
00007b78f51d78c0  movaps [rsp+0x10], xmm15
00007b78f51d78c6  movaps [rsp+0x20], xmm9
00007b78f51d78cc  lea rdi, [rsp]
00007b78f51d78d0  mov esi, 0x00
00007b78f51d78d5  mov rax, 0x597478C09530
00007b78f51d78df  call rax
00007b78f51d78e1  movaps xmm4, [rsp]
00007b78f51d78e5  add rsp, 0x30
00007b78f51d78e9  vmovaps xmm0, [rsp]
00007b78f51d78ee  vmovaps xmm1, [rsp+0x10]
00007b78f51d78f4  vmovaps xmm2, [rsp+0x20]
00007b78f51d78fa  vmovaps xmm3, [rsp+0x30]
00007b78f51d7900  vmovaps xmm5, [rsp+0x40]
00007b78f51d7906  vmovaps xmm6, [rsp+0x50]
00007b78f51d790c  vmovaps xmm7, [rsp+0x60]
00007b78f51d7912  vmovaps xmm8, [rsp+0x70]
00007b78f51d7918  vmovaps xmm9, [rsp+0x80]
00007b78f51d7921  vmovaps xmm10, [rsp+0x90]
00007b78f51d792a  vmovaps xmm11, [rsp+0xA0]
00007b78f51d7933  vmovaps xmm12, [rsp+0xB0]
00007b78f51d793c  vmovaps xmm13, [rsp+0xC0]
00007b78f51d7945  vmovaps xmm14, [rsp+0xD0]
00007b78f51d794e  vmovaps xmm15, [rsp+0xE0]
00007b78f51d7957  add rsp, 0xF0
00007b78f51d795e  pop r11
00007b78f51d7960  pop r10
00007b78f51d7962  pop r9
00007b78f51d7964  pop r8
00007b78f51d7966  pop rsi
00007b78f51d7967  pop rdi
00007b78f51d7968  pop rdx
00007b78f51d7969  pop rcx
00007b78f51d796a  pop rax
00007b78f51d796b  add rsp, 0x08
00007b78f51d796f  jmp 0x00007B78F51D5CF9
00007b78f51d7974  call 0x00007B78F50E5820
00007b78f51d7979  jmp 0x00007B78F51D5D06
00007b78f51d797e  sub rsp, 0x08
00007b78f51d7982  push rax
00007b78f51d7983  push rcx
00007b78f51d7984  push rdx
00007b78f51d7985  push rdi
00007b78f51d7986  push rsi
00007b78f51d7987  push r8
00007b78f51d7989  push r9
00007b78f51d798b  push r10
00007b78f51d798d  push r11
00007b78f51d798f  sub rsp, 0xF0
00007b78f51d7996  vmovaps [rsp], xmm0
00007b78f51d799b  vmovaps [rsp+0x10], xmm1
00007b78f51d79a1  vmovaps [rsp+0x20], xmm2
00007b78f51d79a7  vmovaps [rsp+0x30], xmm4
00007b78f51d79ad  vmovaps [rsp+0x40], xmm5
00007b78f51d79b3  vmovaps [rsp+0x50], xmm6
00007b78f51d79b9  vmovaps [rsp+0x60], xmm7
00007b78f51d79bf  vmovaps [rsp+0x70], xmm8
00007b78f51d79c5  vmovaps [rsp+0x80], xmm9
00007b78f51d79ce  vmovaps [rsp+0x90], xmm10
00007b78f51d79d7  vmovaps [rsp+0xA0], xmm11
00007b78f51d79e0  vmovaps [rsp+0xB0], xmm12
00007b78f51d79e9  vmovaps [rsp+0xC0], xmm13
00007b78f51d79f2  vmovaps [rsp+0xD0], xmm14
00007b78f51d79fb  vmovaps [rsp+0xE0], xmm15
00007b78f51d7a04  sub rsp, 0x30
00007b78f51d7a08  movaps [rsp], xmm3
00007b78f51d7a0c  movaps [rsp+0x10], xmm1
00007b78f51d7a11  movaps [rsp+0x20], xmm9
00007b78f51d7a17  lea rdi, [rsp]
00007b78f51d7a1b  mov esi, 0x00
00007b78f51d7a20  mov rax, 0x597478C09530
00007b78f51d7a2a  call rax
00007b78f51d7a2c  movaps xmm3, [rsp]
00007b78f51d7a30  add rsp, 0x30
00007b78f51d7a34  vmovaps xmm0, [rsp]
00007b78f51d7a39  vmovaps xmm1, [rsp+0x10]
00007b78f51d7a3f  vmovaps xmm2, [rsp+0x20]
00007b78f51d7a45  vmovaps xmm4, [rsp+0x30]
00007b78f51d7a4b  vmovaps xmm5, [rsp+0x40]
00007b78f51d7a51  vmovaps xmm6, [rsp+0x50]
00007b78f51d7a57  vmovaps xmm7, [rsp+0x60]
00007b78f51d7a5d  vmovaps xmm8, [rsp+0x70]
00007b78f51d7a63  vmovaps xmm9, [rsp+0x80]
00007b78f51d7a6c  vmovaps xmm10, [rsp+0x90]
00007b78f51d7a75  vmovaps xmm11, [rsp+0xA0]
00007b78f51d7a7e  vmovaps xmm12, [rsp+0xB0]
00007b78f51d7a87  vmovaps xmm13, [rsp+0xC0]
00007b78f51d7a90  vmovaps xmm14, [rsp+0xD0]
00007b78f51d7a99  vmovaps xmm15, [rsp+0xE0]
00007b78f51d7aa2  add rsp, 0xF0
00007b78f51d7aa9  pop r11
00007b78f51d7aab  pop r10
00007b78f51d7aad  pop r9
00007b78f51d7aaf  pop r8
00007b78f51d7ab1  pop rsi
00007b78f51d7ab2  pop rdi
00007b78f51d7ab3  pop rdx
00007b78f51d7ab4  pop rcx
00007b78f51d7ab5  pop rax
00007b78f51d7ab6  add rsp, 0x08
00007b78f51d7aba  jmp 0x00007B78F51D5D43
00007b78f51d7abf  sub rsp, 0x08
00007b78f51d7ac3  push rax
00007b78f51d7ac4  push rcx
00007b78f51d7ac5  push rdx
00007b78f51d7ac6  push rdi
00007b78f51d7ac7  push rsi
00007b78f51d7ac8  push r8
00007b78f51d7aca  push r9
00007b78f51d7acc  push r10
00007b78f51d7ace  push r11
00007b78f51d7ad0  sub rsp, 0xF0
00007b78f51d7ad7  vmovaps [rsp], xmm0
00007b78f51d7adc  vmovaps [rsp+0x10], xmm2
00007b78f51d7ae2  vmovaps [rsp+0x20], xmm3
00007b78f51d7ae8  vmovaps [rsp+0x30], xmm4
00007b78f51d7aee  vmovaps [rsp+0x40], xmm5
00007b78f51d7af4  vmovaps [rsp+0x50], xmm6
00007b78f51d7afa  vmovaps [rsp+0x60], xmm7
00007b78f51d7b00  vmovaps [rsp+0x70], xmm8
00007b78f51d7b06  vmovaps [rsp+0x80], xmm9
00007b78f51d7b0f  vmovaps [rsp+0x90], xmm10
00007b78f51d7b18  vmovaps [rsp+0xA0], xmm11
00007b78f51d7b21  vmovaps [rsp+0xB0], xmm12
00007b78f51d7b2a  vmovaps [rsp+0xC0], xmm13
00007b78f51d7b33  vmovaps [rsp+0xD0], xmm14
00007b78f51d7b3c  vmovaps [rsp+0xE0], xmm15
00007b78f51d7b45  sub rsp, 0x30
00007b78f51d7b49  movaps [rsp], xmm1
00007b78f51d7b4d  movaps [rsp+0x10], xmm15
00007b78f51d7b53  movaps [rsp+0x20], xmm9
00007b78f51d7b59  lea rdi, [rsp]
00007b78f51d7b5d  mov esi, 0x00
00007b78f51d7b62  mov rax, 0x597478C09530
00007b78f51d7b6c  call rax
00007b78f51d7b6e  movaps xmm1, [rsp]
00007b78f51d7b72  add rsp, 0x30
00007b78f51d7b76  vmovaps xmm0, [rsp]
00007b78f51d7b7b  vmovaps xmm2, [rsp+0x10]
00007b78f51d7b81  vmovaps xmm3, [rsp+0x20]
00007b78f51d7b87  vmovaps xmm4, [rsp+0x30]
00007b78f51d7b8d  vmovaps xmm5, [rsp+0x40]
00007b78f51d7b93  vmovaps xmm6, [rsp+0x50]
00007b78f51d7b99  vmovaps xmm7, [rsp+0x60]
00007b78f51d7b9f  vmovaps xmm8, [rsp+0x70]
00007b78f51d7ba5  vmovaps xmm9, [rsp+0x80]
00007b78f51d7bae  vmovaps xmm10, [rsp+0x90]
00007b78f51d7bb7  vmovaps xmm11, [rsp+0xA0]
00007b78f51d7bc0  vmovaps xmm12, [rsp+0xB0]
00007b78f51d7bc9  vmovaps xmm13, [rsp+0xC0]
00007b78f51d7bd2  vmovaps xmm14, [rsp+0xD0]
00007b78f51d7bdb  vmovaps xmm15, [rsp+0xE0]
00007b78f51d7be4  add rsp, 0xF0
00007b78f51d7beb  pop r11
00007b78f51d7bed  pop r10
00007b78f51d7bef  pop r9
00007b78f51d7bf1  pop r8
00007b78f51d7bf3  pop rsi
00007b78f51d7bf4  pop rdi
00007b78f51d7bf5  pop rdx
00007b78f51d7bf6  pop rcx
00007b78f51d7bf7  pop rax
00007b78f51d7bf8  add rsp, 0x08
00007b78f51d7bfc  jmp 0x00007B78F51D5DCB
00007b78f51d7c01  call 0x00007B78F50E5820
00007b78f51d7c06  jmp 0x00007B78F51D5DD8
00007b78f51d7c0b  sub rsp, 0x08
00007b78f51d7c0f  push rax
00007b78f51d7c10  push rcx
00007b78f51d7c11  push rdx
00007b78f51d7c12  push rdi
00007b78f51d7c13  push rsi
00007b78f51d7c14  push r8
00007b78f51d7c16  push r9
00007b78f51d7c18  push r10
00007b78f51d7c1a  push r11
00007b78f51d7c1c  sub rsp, 0xF0
00007b78f51d7c23  vmovaps [rsp], xmm0
00007b78f51d7c28  vmovaps [rsp+0x10], xmm2
00007b78f51d7c2e  vmovaps [rsp+0x20], xmm3
00007b78f51d7c34  vmovaps [rsp+0x30], xmm4
00007b78f51d7c3a  vmovaps [rsp+0x40], xmm5
00007b78f51d7c40  vmovaps [rsp+0x50], xmm6
00007b78f51d7c46  vmovaps [rsp+0x60], xmm7
00007b78f51d7c4c  vmovaps [rsp+0x70], xmm8
00007b78f51d7c52  vmovaps [rsp+0x80], xmm9
00007b78f51d7c5b  vmovaps [rsp+0x90], xmm10
00007b78f51d7c64  vmovaps [rsp+0xA0], xmm11
00007b78f51d7c6d  vmovaps [rsp+0xB0], xmm12
00007b78f51d7c76  vmovaps [rsp+0xC0], xmm13
00007b78f51d7c7f  vmovaps [rsp+0xD0], xmm14
00007b78f51d7c88  vmovaps [rsp+0xE0], xmm15
00007b78f51d7c91  sub rsp, 0x30
00007b78f51d7c95  movaps [rsp], xmm1
00007b78f51d7c99  movaps [rsp+0x10], xmm5
00007b78f51d7c9e  movaps [rsp+0x20], xmm7
00007b78f51d7ca3  lea rdi, [rsp]
00007b78f51d7ca7  mov esi, 0x00
00007b78f51d7cac  mov rax, 0x597478C09530
00007b78f51d7cb6  call rax
00007b78f51d7cb8  movaps xmm1, [rsp]
00007b78f51d7cbc  add rsp, 0x30
00007b78f51d7cc0  vmovaps xmm0, [rsp]
00007b78f51d7cc5  vmovaps xmm2, [rsp+0x10]
00007b78f51d7ccb  vmovaps xmm3, [rsp+0x20]
00007b78f51d7cd1  vmovaps xmm4, [rsp+0x30]
00007b78f51d7cd7  vmovaps xmm5, [rsp+0x40]
00007b78f51d7cdd  vmovaps xmm6, [rsp+0x50]
00007b78f51d7ce3  vmovaps xmm7, [rsp+0x60]
00007b78f51d7ce9  vmovaps xmm8, [rsp+0x70]
00007b78f51d7cef  vmovaps xmm9, [rsp+0x80]
00007b78f51d7cf8  vmovaps xmm10, [rsp+0x90]
00007b78f51d7d01  vmovaps xmm11, [rsp+0xA0]
00007b78f51d7d0a  vmovaps xmm12, [rsp+0xB0]
00007b78f51d7d13  vmovaps xmm13, [rsp+0xC0]
00007b78f51d7d1c  vmovaps xmm14, [rsp+0xD0]
00007b78f51d7d25  vmovaps xmm15, [rsp+0xE0]
00007b78f51d7d2e  add rsp, 0xF0
00007b78f51d7d35  pop r11
00007b78f51d7d37  pop r10
00007b78f51d7d39  pop r9
00007b78f51d7d3b  pop r8
00007b78f51d7d3d  pop rsi
00007b78f51d7d3e  pop rdi
00007b78f51d7d3f  pop rdx
00007b78f51d7d40  pop rcx
00007b78f51d7d41  pop rax
00007b78f51d7d42  add rsp, 0x08
00007b78f51d7d46  jmp 0x00007B78F51D5E7D
00007b78f51d7d4b  sub rsp, 0x08
00007b78f51d7d4f  push rax
00007b78f51d7d50  push rcx
00007b78f51d7d51  push rdx
00007b78f51d7d52  push rdi
00007b78f51d7d53  push rsi
00007b78f51d7d54  push r8
00007b78f51d7d56  push r9
00007b78f51d7d58  push r10
00007b78f51d7d5a  push r11
00007b78f51d7d5c  sub rsp, 0xF0
00007b78f51d7d63  vmovaps [rsp], xmm0
00007b78f51d7d68  vmovaps [rsp+0x10], xmm1
00007b78f51d7d6e  vmovaps [rsp+0x20], xmm2
00007b78f51d7d74  vmovaps [rsp+0x30], xmm3
00007b78f51d7d7a  vmovaps [rsp+0x40], xmm4
00007b78f51d7d80  vmovaps [rsp+0x50], xmm5
00007b78f51d7d86  vmovaps [rsp+0x60], xmm6
00007b78f51d7d8c  vmovaps [rsp+0x70], xmm8
00007b78f51d7d92  vmovaps [rsp+0x80], xmm9
00007b78f51d7d9b  vmovaps [rsp+0x90], xmm10
00007b78f51d7da4  vmovaps [rsp+0xA0], xmm11
00007b78f51d7dad  vmovaps [rsp+0xB0], xmm12
00007b78f51d7db6  vmovaps [rsp+0xC0], xmm13
00007b78f51d7dbf  vmovaps [rsp+0xD0], xmm14
00007b78f51d7dc8  vmovaps [rsp+0xE0], xmm15
00007b78f51d7dd1  sub rsp, 0x30
00007b78f51d7dd5  movaps [rsp], xmm7
00007b78f51d7dd9  movaps [rsp+0x10], xmm5
00007b78f51d7dde  movaps [rsp+0x20], xmm15
00007b78f51d7de4  lea rdi, [rsp]
00007b78f51d7de8  mov esi, 0x00
00007b78f51d7ded  mov rax, 0x597478C09530
00007b78f51d7df7  call rax
00007b78f51d7df9  movaps xmm7, [rsp]
00007b78f51d7dfd  add rsp, 0x30
00007b78f51d7e01  vmovaps xmm0, [rsp]
00007b78f51d7e06  vmovaps xmm1, [rsp+0x10]
00007b78f51d7e0c  vmovaps xmm2, [rsp+0x20]
00007b78f51d7e12  vmovaps xmm3, [rsp+0x30]
00007b78f51d7e18  vmovaps xmm4, [rsp+0x40]
00007b78f51d7e1e  vmovaps xmm5, [rsp+0x50]
00007b78f51d7e24  vmovaps xmm6, [rsp+0x60]
00007b78f51d7e2a  vmovaps xmm8, [rsp+0x70]
00007b78f51d7e30  vmovaps xmm9, [rsp+0x80]
00007b78f51d7e39  vmovaps xmm10, [rsp+0x90]
00007b78f51d7e42  vmovaps xmm11, [rsp+0xA0]
00007b78f51d7e4b  vmovaps xmm12, [rsp+0xB0]
00007b78f51d7e54  vmovaps xmm13, [rsp+0xC0]
00007b78f51d7e5d  vmovaps xmm14, [rsp+0xD0]
00007b78f51d7e66  vmovaps xmm15, [rsp+0xE0]
00007b78f51d7e6f  add rsp, 0xF0
00007b78f51d7e76  pop r11
00007b78f51d7e78  pop r10
00007b78f51d7e7a  pop r9
00007b78f51d7e7c  pop r8
00007b78f51d7e7e  pop rsi
00007b78f51d7e7f  pop rdi
00007b78f51d7e80  pop rdx
00007b78f51d7e81  pop rcx
00007b78f51d7e82  pop rax
00007b78f51d7e83  add rsp, 0x08
00007b78f51d7e87  jmp 0x00007B78F51D5EB3
00007b78f51d7e8c  call 0x00007B78F50D64F0
00007b78f51d7e91  jmp 0x00007B78F51D5EC0
00007b78f51d7e96  sub rsp, 0x08
00007b78f51d7e9a  push rax
00007b78f51d7e9b  push rcx
00007b78f51d7e9c  push rdx
00007b78f51d7e9d  push rdi
00007b78f51d7e9e  push rsi
00007b78f51d7e9f  push r8
00007b78f51d7ea1  push r9
00007b78f51d7ea3  push r10
00007b78f51d7ea5  push r11
00007b78f51d7ea7  sub rsp, 0xF0
00007b78f51d7eae  vmovaps [rsp], xmm0
00007b78f51d7eb3  vmovaps [rsp+0x10], xmm1
00007b78f51d7eb9  vmovaps [rsp+0x20], xmm2
00007b78f51d7ebf  vmovaps [rsp+0x30], xmm3
00007b78f51d7ec5  vmovaps [rsp+0x40], xmm4
00007b78f51d7ecb  vmovaps [rsp+0x50], xmm5
00007b78f51d7ed1  vmovaps [rsp+0x60], xmm6
00007b78f51d7ed7  vmovaps [rsp+0x70], xmm7
00007b78f51d7edd  vmovaps [rsp+0x80], xmm8
00007b78f51d7ee6  vmovaps [rsp+0x90], xmm9
00007b78f51d7eef  vmovaps [rsp+0xA0], xmm10
00007b78f51d7ef8  vmovaps [rsp+0xB0], xmm11
00007b78f51d7f01  vmovaps [rsp+0xC0], xmm12
00007b78f51d7f0a  vmovaps [rsp+0xD0], xmm13
00007b78f51d7f13  vmovaps [rsp+0xE0], xmm14
00007b78f51d7f1c  sub rsp, 0x30
00007b78f51d7f20  movaps [rsp], xmm15
00007b78f51d7f25  movaps [rsp+0x10], xmm5
00007b78f51d7f2a  movaps [rsp+0x20], xmm3
00007b78f51d7f2f  lea rdi, [rsp]
00007b78f51d7f33  mov esi, 0x00
00007b78f51d7f38  mov rax, 0x597478C09530
00007b78f51d7f42  call rax
00007b78f51d7f44  movaps xmm15, [rsp]
00007b78f51d7f49  add rsp, 0x30
00007b78f51d7f4d  vmovaps xmm0, [rsp]
00007b78f51d7f52  vmovaps xmm1, [rsp+0x10]
00007b78f51d7f58  vmovaps xmm2, [rsp+0x20]
00007b78f51d7f5e  vmovaps xmm3, [rsp+0x30]
00007b78f51d7f64  vmovaps xmm4, [rsp+0x40]
00007b78f51d7f6a  vmovaps xmm5, [rsp+0x50]
00007b78f51d7f70  vmovaps xmm6, [rsp+0x60]
00007b78f51d7f76  vmovaps xmm7, [rsp+0x70]
00007b78f51d7f7c  vmovaps xmm8, [rsp+0x80]
00007b78f51d7f85  vmovaps xmm9, [rsp+0x90]
00007b78f51d7f8e  vmovaps xmm10, [rsp+0xA0]
00007b78f51d7f97  vmovaps xmm11, [rsp+0xB0]
00007b78f51d7fa0  vmovaps xmm12, [rsp+0xC0]
00007b78f51d7fa9  vmovaps xmm13, [rsp+0xD0]
00007b78f51d7fb2  vmovaps xmm14, [rsp+0xE0]
00007b78f51d7fbb  add rsp, 0xF0
00007b78f51d7fc2  pop r11
00007b78f51d7fc4  pop r10
00007b78f51d7fc6  pop r9
00007b78f51d7fc8  pop r8
00007b78f51d7fca  pop rsi
00007b78f51d7fcb  pop rdi
00007b78f51d7fcc  pop rdx
00007b78f51d7fcd  pop rcx
00007b78f51d7fce  pop rax
00007b78f51d7fcf  add rsp, 0x08
00007b78f51d7fd3  jmp 0x00007B78F51D5EE6
00007b78f51d7fd8  sub rsp, 0x08
00007b78f51d7fdc  push rax
00007b78f51d7fdd  push rcx
00007b78f51d7fde  push rdx
00007b78f51d7fdf  push rdi
00007b78f51d7fe0  push rsi
00007b78f51d7fe1  push r8
00007b78f51d7fe3  push r9
00007b78f51d7fe5  push r10
00007b78f51d7fe7  push r11
00007b78f51d7fe9  sub rsp, 0xF0
00007b78f51d7ff0  vmovaps [rsp], xmm0
00007b78f51d7ff5  vmovaps [rsp+0x10], xmm2
00007b78f51d7ffb  vmovaps [rsp+0x20], xmm3
00007b78f51d8001  vmovaps [rsp+0x30], xmm4
00007b78f51d8007  vmovaps [rsp+0x40], xmm5
00007b78f51d800d  vmovaps [rsp+0x50], xmm6
00007b78f51d8013  vmovaps [rsp+0x60], xmm7
00007b78f51d8019  vmovaps [rsp+0x70], xmm8
00007b78f51d801f  vmovaps [rsp+0x80], xmm9
00007b78f51d8028  vmovaps [rsp+0x90], xmm10
00007b78f51d8031  vmovaps [rsp+0xA0], xmm11
00007b78f51d803a  vmovaps [rsp+0xB0], xmm12
00007b78f51d8043  vmovaps [rsp+0xC0], xmm13
00007b78f51d804c  vmovaps [rsp+0xD0], xmm14
00007b78f51d8055  vmovaps [rsp+0xE0], xmm15
00007b78f51d805e  sub rsp, 0x30
00007b78f51d8062  movaps [rsp], xmm1
00007b78f51d8066  movaps [rsp+0x10], xmm5
00007b78f51d806b  movaps [rsp+0x20], xmm4
00007b78f51d8070  lea rdi, [rsp]
00007b78f51d8074  mov esi, 0x00
00007b78f51d8079  mov rax, 0x597478C09530
00007b78f51d8083  call rax
00007b78f51d8085  movaps xmm1, [rsp]
00007b78f51d8089  add rsp, 0x30
00007b78f51d808d  vmovaps xmm0, [rsp]
00007b78f51d8092  vmovaps xmm2, [rsp+0x10]
00007b78f51d8098  vmovaps xmm3, [rsp+0x20]
00007b78f51d809e  vmovaps xmm4, [rsp+0x30]
00007b78f51d80a4  vmovaps xmm5, [rsp+0x40]
00007b78f51d80aa  vmovaps xmm6, [rsp+0x50]
00007b78f51d80b0  vmovaps xmm7, [rsp+0x60]
00007b78f51d80b6  vmovaps xmm8, [rsp+0x70]
00007b78f51d80bc  vmovaps xmm9, [rsp+0x80]
00007b78f51d80c5  vmovaps xmm10, [rsp+0x90]
00007b78f51d80ce  vmovaps xmm11, [rsp+0xA0]
00007b78f51d80d7  vmovaps xmm12, [rsp+0xB0]
00007b78f51d80e0  vmovaps xmm13, [rsp+0xC0]
00007b78f51d80e9  vmovaps xmm14, [rsp+0xD0]
00007b78f51d80f2  vmovaps xmm15, [rsp+0xE0]
00007b78f51d80fb  add rsp, 0xF0
00007b78f51d8102  pop r11
00007b78f51d8104  pop r10
00007b78f51d8106  pop r9
00007b78f51d8108  pop r8
00007b78f51d810a  pop rsi
00007b78f51d810b  pop rdi
00007b78f51d810c  pop rdx
00007b78f51d810d  pop rcx
00007b78f51d810e  pop rax
00007b78f51d810f  add rsp, 0x08
00007b78f51d8113  jmp 0x00007B78F51D5F06
00007b78f51d8118  sub rsp, 0x08
00007b78f51d811c  push rax
00007b78f51d811d  push rcx
00007b78f51d811e  push rdx
00007b78f51d811f  push rdi
00007b78f51d8120  push rsi
00007b78f51d8121  push r8
00007b78f51d8123  push r9
00007b78f51d8125  push r10
00007b78f51d8127  push r11
00007b78f51d8129  sub rsp, 0xF0
00007b78f51d8130  vmovaps [rsp], xmm0
00007b78f51d8135  vmovaps [rsp+0x10], xmm1
00007b78f51d813b  vmovaps [rsp+0x20], xmm2
00007b78f51d8141  vmovaps [rsp+0x30], xmm3
00007b78f51d8147  vmovaps [rsp+0x40], xmm5
00007b78f51d814d  vmovaps [rsp+0x50], xmm6
00007b78f51d8153  vmovaps [rsp+0x60], xmm7
00007b78f51d8159  vmovaps [rsp+0x70], xmm8
00007b78f51d815f  vmovaps [rsp+0x80], xmm9
00007b78f51d8168  vmovaps [rsp+0x90], xmm10
00007b78f51d8171  vmovaps [rsp+0xA0], xmm11
00007b78f51d817a  vmovaps [rsp+0xB0], xmm12
00007b78f51d8183  vmovaps [rsp+0xC0], xmm13
00007b78f51d818c  vmovaps [rsp+0xD0], xmm14
00007b78f51d8195  vmovaps [rsp+0xE0], xmm15
00007b78f51d819e  sub rsp, 0x30
00007b78f51d81a2  movaps [rsp], xmm4
00007b78f51d81a6  movaps [rsp+0x10], xmm3
00007b78f51d81ab  movaps [rsp+0x20], xmm5
00007b78f51d81b0  lea rdi, [rsp]
00007b78f51d81b4  mov esi, 0x00
00007b78f51d81b9  mov rax, 0x597478C09530
00007b78f51d81c3  call rax
00007b78f51d81c5  movaps xmm4, [rsp]
00007b78f51d81c9  add rsp, 0x30
00007b78f51d81cd  vmovaps xmm0, [rsp]
00007b78f51d81d2  vmovaps xmm1, [rsp+0x10]
00007b78f51d81d8  vmovaps xmm2, [rsp+0x20]
00007b78f51d81de  vmovaps xmm3, [rsp+0x30]
00007b78f51d81e4  vmovaps xmm5, [rsp+0x40]
00007b78f51d81ea  vmovaps xmm6, [rsp+0x50]
00007b78f51d81f0  vmovaps xmm7, [rsp+0x60]
00007b78f51d81f6  vmovaps xmm8, [rsp+0x70]
00007b78f51d81fc  vmovaps xmm9, [rsp+0x80]
00007b78f51d8205  vmovaps xmm10, [rsp+0x90]
00007b78f51d820e  vmovaps xmm11, [rsp+0xA0]
00007b78f51d8217  vmovaps xmm12, [rsp+0xB0]
00007b78f51d8220  vmovaps xmm13, [rsp+0xC0]
00007b78f51d8229  vmovaps xmm14, [rsp+0xD0]
00007b78f51d8232  vmovaps xmm15, [rsp+0xE0]
00007b78f51d823b  add rsp, 0xF0
00007b78f51d8242  pop r11
00007b78f51d8244  pop r10
00007b78f51d8246  pop r9
00007b78f51d8248  pop r8
00007b78f51d824a  pop rsi
00007b78f51d824b  pop rdi
00007b78f51d824c  pop rdx
00007b78f51d824d  pop rcx
00007b78f51d824e  pop rax
00007b78f51d824f  add rsp, 0x08
00007b78f51d8253  jmp 0x00007B78F51D5F54
00007b78f51d8258  call 0x00007B78F50D64F0
00007b78f51d825d  jmp 0x00007B78F51D5F61
00007b78f51d8262  sub rsp, 0x08
00007b78f51d8266  push rax
00007b78f51d8267  push rcx
00007b78f51d8268  push rdx
00007b78f51d8269  push rdi
00007b78f51d826a  push rsi
00007b78f51d826b  push r8
00007b78f51d826d  push r9
00007b78f51d826f  push r10
00007b78f51d8271  push r11
00007b78f51d8273  sub rsp, 0xF0
00007b78f51d827a  vmovaps [rsp], xmm0
00007b78f51d827f  vmovaps [rsp+0x10], xmm1
00007b78f51d8285  vmovaps [rsp+0x20], xmm2
00007b78f51d828b  vmovaps [rsp+0x30], xmm3
00007b78f51d8291  vmovaps [rsp+0x40], xmm4
00007b78f51d8297  vmovaps [rsp+0x50], xmm6
00007b78f51d829d  vmovaps [rsp+0x60], xmm7
00007b78f51d82a3  vmovaps [rsp+0x70], xmm8
00007b78f51d82a9  vmovaps [rsp+0x80], xmm9
00007b78f51d82b2  vmovaps [rsp+0x90], xmm10
00007b78f51d82bb  vmovaps [rsp+0xA0], xmm11
00007b78f51d82c4  vmovaps [rsp+0xB0], xmm12
00007b78f51d82cd  vmovaps [rsp+0xC0], xmm13
00007b78f51d82d6  vmovaps [rsp+0xD0], xmm14
00007b78f51d82df  vmovaps [rsp+0xE0], xmm15
00007b78f51d82e8  sub rsp, 0x30
00007b78f51d82ec  movaps [rsp], xmm5
00007b78f51d82f0  movaps [rsp+0x10], xmm6
00007b78f51d82f5  movaps [rsp+0x20], xmm3
00007b78f51d82fa  lea rdi, [rsp]
00007b78f51d82fe  mov esi, 0x00
00007b78f51d8303  mov rax, 0x597478C09530
00007b78f51d830d  call rax
00007b78f51d830f  movaps xmm5, [rsp]
00007b78f51d8313  add rsp, 0x30
00007b78f51d8317  vmovaps xmm0, [rsp]
00007b78f51d831c  vmovaps xmm1, [rsp+0x10]
00007b78f51d8322  vmovaps xmm2, [rsp+0x20]
00007b78f51d8328  vmovaps xmm3, [rsp+0x30]
00007b78f51d832e  vmovaps xmm4, [rsp+0x40]
00007b78f51d8334  vmovaps xmm6, [rsp+0x50]
00007b78f51d833a  vmovaps xmm7, [rsp+0x60]
00007b78f51d8340  vmovaps xmm8, [rsp+0x70]
00007b78f51d8346  vmovaps xmm9, [rsp+0x80]
00007b78f51d834f  vmovaps xmm10, [rsp+0x90]
00007b78f51d8358  vmovaps xmm11, [rsp+0xA0]
00007b78f51d8361  vmovaps xmm12, [rsp+0xB0]
00007b78f51d836a  vmovaps xmm13, [rsp+0xC0]
00007b78f51d8373  vmovaps xmm14, [rsp+0xD0]
00007b78f51d837c  vmovaps xmm15, [rsp+0xE0]
00007b78f51d8385  add rsp, 0xF0
00007b78f51d838c  pop r11
00007b78f51d838e  pop r10
00007b78f51d8390  pop r9
00007b78f51d8392  pop r8
00007b78f51d8394  pop rsi
00007b78f51d8395  pop rdi
00007b78f51d8396  pop rdx
00007b78f51d8397  pop rcx
00007b78f51d8398  pop rax
00007b78f51d8399  add rsp, 0x08
00007b78f51d839d  jmp 0x00007B78F51D5F87
00007b78f51d83a2  sub rsp, 0x08
00007b78f51d83a6  push rax
00007b78f51d83a7  push rcx
00007b78f51d83a8  push rdx
00007b78f51d83a9  push rdi
00007b78f51d83aa  push rsi
00007b78f51d83ab  push r8
00007b78f51d83ad  push r9
00007b78f51d83af  push r10
00007b78f51d83b1  push r11
00007b78f51d83b3  sub rsp, 0xF0
00007b78f51d83ba  vmovaps [rsp], xmm0
00007b78f51d83bf  vmovaps [rsp+0x10], xmm1
00007b78f51d83c5  vmovaps [rsp+0x20], xmm2
00007b78f51d83cb  vmovaps [rsp+0x30], xmm3
00007b78f51d83d1  vmovaps [rsp+0x40], xmm4
00007b78f51d83d7  vmovaps [rsp+0x50], xmm5
00007b78f51d83dd  vmovaps [rsp+0x60], xmm7
00007b78f51d83e3  vmovaps [rsp+0x70], xmm8
00007b78f51d83e9  vmovaps [rsp+0x80], xmm9
00007b78f51d83f2  vmovaps [rsp+0x90], xmm10
00007b78f51d83fb  vmovaps [rsp+0xA0], xmm11
00007b78f51d8404  vmovaps [rsp+0xB0], xmm12
00007b78f51d840d  vmovaps [rsp+0xC0], xmm13
00007b78f51d8416  vmovaps [rsp+0xD0], xmm14
00007b78f51d841f  vmovaps [rsp+0xE0], xmm15
00007b78f51d8428  sub rsp, 0x30
00007b78f51d842c  movaps [rsp], xmm6
00007b78f51d8430  movaps [rsp+0x10], xmm9
00007b78f51d8436  movaps [rsp+0x20], xmm1
00007b78f51d843b  lea rdi, [rsp]
00007b78f51d843f  mov esi, 0x00
00007b78f51d8444  mov rax, 0x597478C09530
00007b78f51d844e  call rax
00007b78f51d8450  movaps xmm6, [rsp]
00007b78f51d8454  add rsp, 0x30
00007b78f51d8458  vmovaps xmm0, [rsp]
00007b78f51d845d  vmovaps xmm1, [rsp+0x10]
00007b78f51d8463  vmovaps xmm2, [rsp+0x20]
00007b78f51d8469  vmovaps xmm3, [rsp+0x30]
00007b78f51d846f  vmovaps xmm4, [rsp+0x40]
00007b78f51d8475  vmovaps xmm5, [rsp+0x50]
00007b78f51d847b  vmovaps xmm7, [rsp+0x60]
00007b78f51d8481  vmovaps xmm8, [rsp+0x70]
00007b78f51d8487  vmovaps xmm9, [rsp+0x80]
00007b78f51d8490  vmovaps xmm10, [rsp+0x90]
00007b78f51d8499  vmovaps xmm11, [rsp+0xA0]
00007b78f51d84a2  vmovaps xmm12, [rsp+0xB0]
00007b78f51d84ab  vmovaps xmm13, [rsp+0xC0]
00007b78f51d84b4  vmovaps xmm14, [rsp+0xD0]
00007b78f51d84bd  vmovaps xmm15, [rsp+0xE0]
00007b78f51d84c6  add rsp, 0xF0
00007b78f51d84cd  pop r11
00007b78f51d84cf  pop r10
00007b78f51d84d1  pop r9
00007b78f51d84d3  pop r8
00007b78f51d84d5  pop rsi
00007b78f51d84d6  pop rdi
00007b78f51d84d7  pop rdx
00007b78f51d84d8  pop rcx
00007b78f51d84d9  pop rax
00007b78f51d84da  add rsp, 0x08
00007b78f51d84de  jmp 0x00007B78F51D5FAB
00007b78f51d84e3  sub rsp, 0x08
00007b78f51d84e7  push rax
00007b78f51d84e8  push rcx
00007b78f51d84e9  push rdx
00007b78f51d84ea  push rdi
00007b78f51d84eb  push rsi
00007b78f51d84ec  push r8
00007b78f51d84ee  push r9
00007b78f51d84f0  push r10
00007b78f51d84f2  push r11
00007b78f51d84f4  sub rsp, 0xF0
00007b78f51d84fb  vmovaps [rsp], xmm0
00007b78f51d8500  vmovaps [rsp+0x10], xmm1
00007b78f51d8506  vmovaps [rsp+0x20], xmm2
00007b78f51d850c  vmovaps [rsp+0x30], xmm3
00007b78f51d8512  vmovaps [rsp+0x40], xmm4
00007b78f51d8518  vmovaps [rsp+0x50], xmm5
00007b78f51d851e  vmovaps [rsp+0x60], xmm6
00007b78f51d8524  vmovaps [rsp+0x70], xmm7
00007b78f51d852a  vmovaps [rsp+0x80], xmm8
00007b78f51d8533  vmovaps [rsp+0x90], xmm10
00007b78f51d853c  vmovaps [rsp+0xA0], xmm11
00007b78f51d8545  vmovaps [rsp+0xB0], xmm12
00007b78f51d854e  vmovaps [rsp+0xC0], xmm13
00007b78f51d8557  vmovaps [rsp+0xD0], xmm14
00007b78f51d8560  vmovaps [rsp+0xE0], xmm15
00007b78f51d8569  sub rsp, 0x30
00007b78f51d856d  movaps [rsp], xmm9
00007b78f51d8572  movaps [rsp+0x10], xmm3
00007b78f51d8577  movaps [rsp+0x20], xmm1
00007b78f51d857c  lea rdi, [rsp]
00007b78f51d8580  mov esi, 0x00
00007b78f51d8585  mov rax, 0x597478C09530
00007b78f51d858f  call rax
00007b78f51d8591  movaps xmm9, [rsp]
00007b78f51d8596  add rsp, 0x30
00007b78f51d859a  vmovaps xmm0, [rsp]
00007b78f51d859f  vmovaps xmm1, [rsp+0x10]
00007b78f51d85a5  vmovaps xmm2, [rsp+0x20]
00007b78f51d85ab  vmovaps xmm3, [rsp+0x30]
00007b78f51d85b1  vmovaps xmm4, [rsp+0x40]
00007b78f51d85b7  vmovaps xmm5, [rsp+0x50]
00007b78f51d85bd  vmovaps xmm6, [rsp+0x60]
00007b78f51d85c3  vmovaps xmm7, [rsp+0x70]
00007b78f51d85c9  vmovaps xmm8, [rsp+0x80]
00007b78f51d85d2  vmovaps xmm10, [rsp+0x90]
00007b78f51d85db  vmovaps xmm11, [rsp+0xA0]
00007b78f51d85e4  vmovaps xmm12, [rsp+0xB0]
00007b78f51d85ed  vmovaps xmm13, [rsp+0xC0]
00007b78f51d85f6  vmovaps xmm14, [rsp+0xD0]
00007b78f51d85ff  vmovaps xmm15, [rsp+0xE0]
00007b78f51d8608  add rsp, 0xF0
00007b78f51d860f  pop r11
00007b78f51d8611  pop r10
00007b78f51d8613  pop r9
00007b78f51d8615  pop r8
00007b78f51d8617  pop rsi
00007b78f51d8618  pop rdi
00007b78f51d8619  pop rdx
00007b78f51d861a  pop rcx
00007b78f51d861b  pop rax
00007b78f51d861c  add rsp, 0x08
00007b78f51d8620  jmp 0x00007B78F51D5FF7
00007b78f51d8625  call 0x00007B78F50D64F0
00007b78f51d862a  jmp 0x00007B78F51D6004
00007b78f51d862f  sub rsp, 0x08
00007b78f51d8633  push rax
00007b78f51d8634  push rcx
00007b78f51d8635  push rdx
00007b78f51d8636  push rdi
00007b78f51d8637  push rsi
00007b78f51d8638  push r8
00007b78f51d863a  push r9
00007b78f51d863c  push r10
00007b78f51d863e  push r11
00007b78f51d8640  sub rsp, 0xF0
00007b78f51d8647  vmovaps [rsp], xmm0
00007b78f51d864c  vmovaps [rsp+0x10], xmm1
00007b78f51d8652  vmovaps [rsp+0x20], xmm2
00007b78f51d8658  vmovaps [rsp+0x30], xmm3
00007b78f51d865e  vmovaps [rsp+0x40], xmm4
00007b78f51d8664  vmovaps [rsp+0x50], xmm5
00007b78f51d866a  vmovaps [rsp+0x60], xmm6
00007b78f51d8670  vmovaps [rsp+0x70], xmm7
00007b78f51d8676  vmovaps [rsp+0x80], xmm8
00007b78f51d867f  vmovaps [rsp+0x90], xmm9
00007b78f51d8688  vmovaps [rsp+0xA0], xmm10
00007b78f51d8691  vmovaps [rsp+0xB0], xmm11
00007b78f51d869a  vmovaps [rsp+0xC0], xmm12
00007b78f51d86a3  vmovaps [rsp+0xD0], xmm13
00007b78f51d86ac  vmovaps [rsp+0xE0], xmm14
00007b78f51d86b5  sub rsp, 0x30
00007b78f51d86b9  movaps [rsp], xmm15
00007b78f51d86be  movaps [rsp+0x10], xmm3
00007b78f51d86c3  movaps [rsp+0x20], xmm7
00007b78f51d86c8  lea rdi, [rsp]
00007b78f51d86cc  mov esi, 0x00
00007b78f51d86d1  mov rax, 0x597478C09530
00007b78f51d86db  call rax
00007b78f51d86dd  movaps xmm15, [rsp]
00007b78f51d86e2  add rsp, 0x30
00007b78f51d86e6  vmovaps xmm0, [rsp]
00007b78f51d86eb  vmovaps xmm1, [rsp+0x10]
00007b78f51d86f1  vmovaps xmm2, [rsp+0x20]
00007b78f51d86f7  vmovaps xmm3, [rsp+0x30]
00007b78f51d86fd  vmovaps xmm4, [rsp+0x40]
00007b78f51d8703  vmovaps xmm5, [rsp+0x50]
00007b78f51d8709  vmovaps xmm6, [rsp+0x60]
00007b78f51d870f  vmovaps xmm7, [rsp+0x70]
00007b78f51d8715  vmovaps xmm8, [rsp+0x80]
00007b78f51d871e  vmovaps xmm9, [rsp+0x90]
00007b78f51d8727  vmovaps xmm10, [rsp+0xA0]
00007b78f51d8730  vmovaps xmm11, [rsp+0xB0]
00007b78f51d8739  vmovaps xmm12, [rsp+0xC0]
00007b78f51d8742  vmovaps xmm13, [rsp+0xD0]
00007b78f51d874b  vmovaps xmm14, [rsp+0xE0]
00007b78f51d8754  add rsp, 0xF0
00007b78f51d875b  pop r11
00007b78f51d875d  pop r10
00007b78f51d875f  pop r9
00007b78f51d8761  pop r8
00007b78f51d8763  pop rsi
00007b78f51d8764  pop rdi
00007b78f51d8765  pop rdx
00007b78f51d8766  pop rcx
00007b78f51d8767  pop rax
00007b78f51d8768  add rsp, 0x08
00007b78f51d876c  jmp 0x00007B78F51D6030
00007b78f51d8771  sub rsp, 0x08
00007b78f51d8775  push rax
00007b78f51d8776  push rcx
00007b78f51d8777  push rdx
00007b78f51d8778  push rdi
00007b78f51d8779  push rsi
00007b78f51d877a  push r8
00007b78f51d877c  push r9
00007b78f51d877e  push r10
00007b78f51d8780  push r11
00007b78f51d8782  sub rsp, 0xF0
00007b78f51d8789  vmovaps [rsp], xmm0
00007b78f51d878e  vmovaps [rsp+0x10], xmm1
00007b78f51d8794  vmovaps [rsp+0x20], xmm2
00007b78f51d879a  vmovaps [rsp+0x30], xmm4
00007b78f51d87a0  vmovaps [rsp+0x40], xmm5
00007b78f51d87a6  vmovaps [rsp+0x50], xmm6
00007b78f51d87ac  vmovaps [rsp+0x60], xmm7
00007b78f51d87b2  vmovaps [rsp+0x70], xmm8
00007b78f51d87b8  vmovaps [rsp+0x80], xmm9
00007b78f51d87c1  vmovaps [rsp+0x90], xmm10
00007b78f51d87ca  vmovaps [rsp+0xA0], xmm11
00007b78f51d87d3  vmovaps [rsp+0xB0], xmm12
00007b78f51d87dc  vmovaps [rsp+0xC0], xmm13
00007b78f51d87e5  vmovaps [rsp+0xD0], xmm14
00007b78f51d87ee  vmovaps [rsp+0xE0], xmm15
00007b78f51d87f7  sub rsp, 0x30
00007b78f51d87fb  movaps [rsp], xmm3
00007b78f51d87ff  movaps [rsp+0x10], xmm1
00007b78f51d8804  movaps [rsp+0x20], xmm15
00007b78f51d880a  lea rdi, [rsp]
00007b78f51d880e  mov esi, 0x00
00007b78f51d8813  mov rax, 0x597478C09530
00007b78f51d881d  call rax
00007b78f51d881f  movaps xmm3, [rsp]
00007b78f51d8823  add rsp, 0x30
00007b78f51d8827  vmovaps xmm0, [rsp]
00007b78f51d882c  vmovaps xmm1, [rsp+0x10]
00007b78f51d8832  vmovaps xmm2, [rsp+0x20]
00007b78f51d8838  vmovaps xmm4, [rsp+0x30]
00007b78f51d883e  vmovaps xmm5, [rsp+0x40]
00007b78f51d8844  vmovaps xmm6, [rsp+0x50]
00007b78f51d884a  vmovaps xmm7, [rsp+0x60]
00007b78f51d8850  vmovaps xmm8, [rsp+0x70]
00007b78f51d8856  vmovaps xmm9, [rsp+0x80]
00007b78f51d885f  vmovaps xmm10, [rsp+0x90]
00007b78f51d8868  vmovaps xmm11, [rsp+0xA0]
00007b78f51d8871  vmovaps xmm12, [rsp+0xB0]
00007b78f51d887a  vmovaps xmm13, [rsp+0xC0]
00007b78f51d8883  vmovaps xmm14, [rsp+0xD0]
00007b78f51d888c  vmovaps xmm15, [rsp+0xE0]
00007b78f51d8895  add rsp, 0xF0
00007b78f51d889c  pop r11
00007b78f51d889e  pop r10
00007b78f51d88a0  pop r9
00007b78f51d88a2  pop r8
00007b78f51d88a4  pop rsi
00007b78f51d88a5  pop rdi
00007b78f51d88a6  pop rdx
00007b78f51d88a7  pop rcx
00007b78f51d88a8  pop rax
00007b78f51d88a9  add rsp, 0x08
00007b78f51d88ad  jmp 0x00007B78F51D60BF
00007b78f51d88b2  call 0x00007B78F50D64F0
00007b78f51d88b7  jmp 0x00007B78F51D60C9
00007b78f51d88bc  sub rsp, 0x08
00007b78f51d88c0  push rax
00007b78f51d88c1  push rcx
00007b78f51d88c2  push rdx
00007b78f51d88c3  push rdi
00007b78f51d88c4  push rsi
00007b78f51d88c5  push r8
00007b78f51d88c7  push r9
00007b78f51d88c9  push r10
00007b78f51d88cb  push r11
00007b78f51d88cd  sub rsp, 0xF0
00007b78f51d88d4  vmovaps [rsp], xmm0
00007b78f51d88d9  vmovaps [rsp+0x10], xmm1
00007b78f51d88df  vmovaps [rsp+0x20], xmm2
00007b78f51d88e5  vmovaps [rsp+0x30], xmm3
00007b78f51d88eb  vmovaps [rsp+0x40], xmm4
00007b78f51d88f1  vmovaps [rsp+0x50], xmm5
00007b78f51d88f7  vmovaps [rsp+0x60], xmm6
00007b78f51d88fd  vmovaps [rsp+0x70], xmm7
00007b78f51d8903  vmovaps [rsp+0x80], xmm8
00007b78f51d890c  vmovaps [rsp+0x90], xmm9
00007b78f51d8915  vmovaps [rsp+0xA0], xmm10
00007b78f51d891e  vmovaps [rsp+0xB0], xmm11
00007b78f51d8927  vmovaps [rsp+0xC0], xmm12
00007b78f51d8930  vmovaps [rsp+0xD0], xmm13
00007b78f51d8939  vmovaps [rsp+0xE0], xmm14
00007b78f51d8942  sub rsp, 0x30
00007b78f51d8946  movaps [rsp], xmm15
00007b78f51d894b  movaps [rsp+0x10], xmm14
00007b78f51d8951  movaps [rsp+0x20], xmm4
00007b78f51d8956  lea rdi, [rsp]
00007b78f51d895a  mov esi, 0x00
00007b78f51d895f  mov rax, 0x597478C09530
00007b78f51d8969  call rax
00007b78f51d896b  movaps xmm15, [rsp]
00007b78f51d8970  add rsp, 0x30
00007b78f51d8974  vmovaps xmm0, [rsp]
00007b78f51d8979  vmovaps xmm1, [rsp+0x10]
00007b78f51d897f  vmovaps xmm2, [rsp+0x20]
00007b78f51d8985  vmovaps xmm3, [rsp+0x30]
00007b78f51d898b  vmovaps xmm4, [rsp+0x40]
00007b78f51d8991  vmovaps xmm5, [rsp+0x50]
00007b78f51d8997  vmovaps xmm6, [rsp+0x60]
00007b78f51d899d  vmovaps xmm7, [rsp+0x70]
00007b78f51d89a3  vmovaps xmm8, [rsp+0x80]
00007b78f51d89ac  vmovaps xmm9, [rsp+0x90]
00007b78f51d89b5  vmovaps xmm10, [rsp+0xA0]
00007b78f51d89be  vmovaps xmm11, [rsp+0xB0]
00007b78f51d89c7  vmovaps xmm12, [rsp+0xC0]
00007b78f51d89d0  vmovaps xmm13, [rsp+0xD0]
00007b78f51d89d9  vmovaps xmm14, [rsp+0xE0]
00007b78f51d89e2  add rsp, 0xF0
00007b78f51d89e9  pop r11
00007b78f51d89eb  pop r10
00007b78f51d89ed  pop r9
00007b78f51d89ef  pop r8
00007b78f51d89f1  pop rsi
00007b78f51d89f2  pop rdi
00007b78f51d89f3  pop rdx
00007b78f51d89f4  pop rcx
00007b78f51d89f5  pop rax
00007b78f51d89f6  add rsp, 0x08
00007b78f51d89fa  jmp 0x00007B78F51D60F7
00007b78f51d89ff  sub rsp, 0x08
00007b78f51d8a03  push rax
00007b78f51d8a04  push rcx
00007b78f51d8a05  push rdx
00007b78f51d8a06  push rdi
00007b78f51d8a07  push rsi
00007b78f51d8a08  push r8
00007b78f51d8a0a  push r9
00007b78f51d8a0c  push r10
00007b78f51d8a0e  push r11
00007b78f51d8a10  sub rsp, 0xF0
00007b78f51d8a17  vmovaps [rsp], xmm0
00007b78f51d8a1c  vmovaps [rsp+0x10], xmm1
00007b78f51d8a22  vmovaps [rsp+0x20], xmm2
00007b78f51d8a28  vmovaps [rsp+0x30], xmm3
00007b78f51d8a2e  vmovaps [rsp+0x40], xmm4
00007b78f51d8a34  vmovaps [rsp+0x50], xmm5
00007b78f51d8a3a  vmovaps [rsp+0x60], xmm6
00007b78f51d8a40  vmovaps [rsp+0x70], xmm7
00007b78f51d8a46  vmovaps [rsp+0x80], xmm8
00007b78f51d8a4f  vmovaps [rsp+0x90], xmm9
00007b78f51d8a58  vmovaps [rsp+0xA0], xmm10
00007b78f51d8a61  vmovaps [rsp+0xB0], xmm11
00007b78f51d8a6a  vmovaps [rsp+0xC0], xmm12
00007b78f51d8a73  vmovaps [rsp+0xD0], xmm13
00007b78f51d8a7c  vmovaps [rsp+0xE0], xmm15
00007b78f51d8a85  sub rsp, 0x30
00007b78f51d8a89  movaps [rsp], xmm14
00007b78f51d8a8e  movaps [rsp+0x10], xmm2
00007b78f51d8a93  movaps [rsp+0x20], xmm1
00007b78f51d8a98  lea rdi, [rsp]
00007b78f51d8a9c  mov esi, 0x00
00007b78f51d8aa1  mov rax, 0x597478C09530
00007b78f51d8aab  call rax
00007b78f51d8aad  movaps xmm14, [rsp]
00007b78f51d8ab2  add rsp, 0x30
00007b78f51d8ab6  vmovaps xmm0, [rsp]
00007b78f51d8abb  vmovaps xmm1, [rsp+0x10]
00007b78f51d8ac1  vmovaps xmm2, [rsp+0x20]
00007b78f51d8ac7  vmovaps xmm3, [rsp+0x30]
00007b78f51d8acd  vmovaps xmm4, [rsp+0x40]
00007b78f51d8ad3  vmovaps xmm5, [rsp+0x50]
00007b78f51d8ad9  vmovaps xmm6, [rsp+0x60]
00007b78f51d8adf  vmovaps xmm7, [rsp+0x70]
00007b78f51d8ae5  vmovaps xmm8, [rsp+0x80]
00007b78f51d8aee  vmovaps xmm9, [rsp+0x90]
00007b78f51d8af7  vmovaps xmm10, [rsp+0xA0]
00007b78f51d8b00  vmovaps xmm11, [rsp+0xB0]
00007b78f51d8b09  vmovaps xmm12, [rsp+0xC0]
00007b78f51d8b12  vmovaps xmm13, [rsp+0xD0]
00007b78f51d8b1b  vmovaps xmm15, [rsp+0xE0]
00007b78f51d8b24  add rsp, 0xF0
00007b78f51d8b2b  pop r11
00007b78f51d8b2d  pop r10
00007b78f51d8b2f  pop r9
00007b78f51d8b31  pop r8
00007b78f51d8b33  pop rsi
00007b78f51d8b34  pop rdi
00007b78f51d8b35  pop rdx
00007b78f51d8b36  pop rcx
00007b78f51d8b37  pop rax
00007b78f51d8b38  add rsp, 0x08
00007b78f51d8b3c  jmp 0x00007B78F51D611D
00007b78f51d8b41  sub rsp, 0x08
00007b78f51d8b45  push rax
00007b78f51d8b46  push rcx
00007b78f51d8b47  push rdx
00007b78f51d8b48  push rdi
00007b78f51d8b49  push rsi
00007b78f51d8b4a  push r8
00007b78f51d8b4c  push r9
00007b78f51d8b4e  push r10
00007b78f51d8b50  push r11
00007b78f51d8b52  sub rsp, 0xF0
00007b78f51d8b59  vmovaps [rsp], xmm0
00007b78f51d8b5e  vmovaps [rsp+0x10], xmm2
00007b78f51d8b64  vmovaps [rsp+0x20], xmm3
00007b78f51d8b6a  vmovaps [rsp+0x30], xmm4
00007b78f51d8b70  vmovaps [rsp+0x40], xmm5
00007b78f51d8b76  vmovaps [rsp+0x50], xmm6
00007b78f51d8b7c  vmovaps [rsp+0x60], xmm7
00007b78f51d8b82  vmovaps [rsp+0x70], xmm8
00007b78f51d8b88  vmovaps [rsp+0x80], xmm9
00007b78f51d8b91  vmovaps [rsp+0x90], xmm10
00007b78f51d8b9a  vmovaps [rsp+0xA0], xmm11
00007b78f51d8ba3  vmovaps [rsp+0xB0], xmm12
00007b78f51d8bac  vmovaps [rsp+0xC0], xmm13
00007b78f51d8bb5  vmovaps [rsp+0xD0], xmm14
00007b78f51d8bbe  vmovaps [rsp+0xE0], xmm15
00007b78f51d8bc7  sub rsp, 0x30
00007b78f51d8bcb  movaps [rsp], xmm1
00007b78f51d8bcf  movaps [rsp+0x10], xmm4
00007b78f51d8bd4  movaps [rsp+0x20], xmm9
00007b78f51d8bda  lea rdi, [rsp]
00007b78f51d8bde  mov esi, 0x00
00007b78f51d8be3  mov rax, 0x597478C09530
00007b78f51d8bed  call rax
00007b78f51d8bef  movaps xmm1, [rsp]
00007b78f51d8bf3  add rsp, 0x30
00007b78f51d8bf7  vmovaps xmm0, [rsp]
00007b78f51d8bfc  vmovaps xmm2, [rsp+0x10]
00007b78f51d8c02  vmovaps xmm3, [rsp+0x20]
00007b78f51d8c08  vmovaps xmm4, [rsp+0x30]
00007b78f51d8c0e  vmovaps xmm5, [rsp+0x40]
00007b78f51d8c14  vmovaps xmm6, [rsp+0x50]
00007b78f51d8c1a  vmovaps xmm7, [rsp+0x60]
00007b78f51d8c20  vmovaps xmm8, [rsp+0x70]
00007b78f51d8c26  vmovaps xmm9, [rsp+0x80]
00007b78f51d8c2f  vmovaps xmm10, [rsp+0x90]
00007b78f51d8c38  vmovaps xmm11, [rsp+0xA0]
00007b78f51d8c41  vmovaps xmm12, [rsp+0xB0]
00007b78f51d8c4a  vmovaps xmm13, [rsp+0xC0]
00007b78f51d8c53  vmovaps xmm14, [rsp+0xD0]
00007b78f51d8c5c  vmovaps xmm15, [rsp+0xE0]
00007b78f51d8c65  add rsp, 0xF0
00007b78f51d8c6c  pop r11
00007b78f51d8c6e  pop r10
00007b78f51d8c70  pop r9
00007b78f51d8c72  pop r8
00007b78f51d8c74  pop rsi
00007b78f51d8c75  pop rdi
00007b78f51d8c76  pop rdx
00007b78f51d8c77  pop rcx
00007b78f51d8c78  pop rax
00007b78f51d8c79  add rsp, 0x08
00007b78f51d8c7d  jmp 0x00007B78F51D613B
00007b78f51d8c82  sub rsp, 0x08
00007b78f51d8c86  push rax
00007b78f51d8c87  push rcx
00007b78f51d8c88  push rdx
00007b78f51d8c89  push rdi
00007b78f51d8c8a  push rsi
00007b78f51d8c8b  push r8
00007b78f51d8c8d  push r9
00007b78f51d8c8f  push r10
00007b78f51d8c91  push r11
00007b78f51d8c93  sub rsp, 0xF0
00007b78f51d8c9a  vmovaps [rsp], xmm0
00007b78f51d8c9f  vmovaps [rsp+0x10], xmm1
00007b78f51d8ca5  vmovaps [rsp+0x20], xmm2
00007b78f51d8cab  vmovaps [rsp+0x30], xmm3
00007b78f51d8cb1  vmovaps [rsp+0x40], xmm5
00007b78f51d8cb7  vmovaps [rsp+0x50], xmm6
00007b78f51d8cbd  vmovaps [rsp+0x60], xmm7
00007b78f51d8cc3  vmovaps [rsp+0x70], xmm8
00007b78f51d8cc9  vmovaps [rsp+0x80], xmm9
00007b78f51d8cd2  vmovaps [rsp+0x90], xmm10
00007b78f51d8cdb  vmovaps [rsp+0xA0], xmm11
00007b78f51d8ce4  vmovaps [rsp+0xB0], xmm12
00007b78f51d8ced  vmovaps [rsp+0xC0], xmm13
00007b78f51d8cf6  vmovaps [rsp+0xD0], xmm14
00007b78f51d8cff  vmovaps [rsp+0xE0], xmm15
00007b78f51d8d08  sub rsp, 0x30
00007b78f51d8d0c  movaps [rsp], xmm4
00007b78f51d8d10  movaps [rsp+0x10], xmm2
00007b78f51d8d15  movaps [rsp+0x20], xmm9
00007b78f51d8d1b  lea rdi, [rsp]
00007b78f51d8d1f  mov esi, 0x00
00007b78f51d8d24  mov rax, 0x597478C09530
00007b78f51d8d2e  call rax
00007b78f51d8d30  movaps xmm4, [rsp]
00007b78f51d8d34  add rsp, 0x30
00007b78f51d8d38  vmovaps xmm0, [rsp]
00007b78f51d8d3d  vmovaps xmm1, [rsp+0x10]
00007b78f51d8d43  vmovaps xmm2, [rsp+0x20]
00007b78f51d8d49  vmovaps xmm3, [rsp+0x30]
00007b78f51d8d4f  vmovaps xmm5, [rsp+0x40]
00007b78f51d8d55  vmovaps xmm6, [rsp+0x50]
00007b78f51d8d5b  vmovaps xmm7, [rsp+0x60]
00007b78f51d8d61  vmovaps xmm8, [rsp+0x70]
00007b78f51d8d67  vmovaps xmm9, [rsp+0x80]
00007b78f51d8d70  vmovaps xmm10, [rsp+0x90]
00007b78f51d8d79  vmovaps xmm11, [rsp+0xA0]
00007b78f51d8d82  vmovaps xmm12, [rsp+0xB0]
00007b78f51d8d8b  vmovaps xmm13, [rsp+0xC0]
00007b78f51d8d94  vmovaps xmm14, [rsp+0xD0]
00007b78f51d8d9d  vmovaps xmm15, [rsp+0xE0]
00007b78f51d8da6  add rsp, 0xF0
00007b78f51d8dad  pop r11
00007b78f51d8daf  pop r10
00007b78f51d8db1  pop r9
00007b78f51d8db3  pop r8
00007b78f51d8db5  pop rsi
00007b78f51d8db6  pop rdi
00007b78f51d8db7  pop rdx
00007b78f51d8db8  pop rcx
00007b78f51d8db9  pop rax
00007b78f51d8dba  add rsp, 0x08
00007b78f51d8dbe  jmp 0x00007B78F51D616B
00007b78f51d8dc3  sub rsp, 0x08
00007b78f51d8dc7  push rax
00007b78f51d8dc8  push rcx
00007b78f51d8dc9  push rdx
00007b78f51d8dca  push rdi
00007b78f51d8dcb  push rsi
00007b78f51d8dcc  push r8
00007b78f51d8dce  push r9
00007b78f51d8dd0  push r10
00007b78f51d8dd2  push r11
00007b78f51d8dd4  sub rsp, 0xF0
00007b78f51d8ddb  vmovaps [rsp], xmm0
00007b78f51d8de0  vmovaps [rsp+0x10], xmm1
00007b78f51d8de6  vmovaps [rsp+0x20], xmm2
00007b78f51d8dec  vmovaps [rsp+0x30], xmm3
00007b78f51d8df2  vmovaps [rsp+0x40], xmm4
00007b78f51d8df8  vmovaps [rsp+0x50], xmm5
00007b78f51d8dfe  vmovaps [rsp+0x60], xmm6
00007b78f51d8e04  vmovaps [rsp+0x70], xmm7
00007b78f51d8e0a  vmovaps [rsp+0x80], xmm8
00007b78f51d8e13  vmovaps [rsp+0x90], xmm10
00007b78f51d8e1c  vmovaps [rsp+0xA0], xmm11
00007b78f51d8e25  vmovaps [rsp+0xB0], xmm12
00007b78f51d8e2e  vmovaps [rsp+0xC0], xmm13
00007b78f51d8e37  vmovaps [rsp+0xD0], xmm14
00007b78f51d8e40  vmovaps [rsp+0xE0], xmm15
00007b78f51d8e49  sub rsp, 0x30
00007b78f51d8e4d  movaps [rsp], xmm9
00007b78f51d8e52  movaps [rsp+0x10], xmm2
00007b78f51d8e57  movaps [rsp+0x20], xmm1
00007b78f51d8e5c  lea rdi, [rsp]
00007b78f51d8e60  mov esi, 0x00
00007b78f51d8e65  mov rax, 0x597478C09530
00007b78f51d8e6f  call rax
00007b78f51d8e71  movaps xmm9, [rsp]
00007b78f51d8e76  add rsp, 0x30
00007b78f51d8e7a  vmovaps xmm0, [rsp]
00007b78f51d8e7f  vmovaps xmm1, [rsp+0x10]
00007b78f51d8e85  vmovaps xmm2, [rsp+0x20]
00007b78f51d8e8b  vmovaps xmm3, [rsp+0x30]
00007b78f51d8e91  vmovaps xmm4, [rsp+0x40]
00007b78f51d8e97  vmovaps xmm5, [rsp+0x50]
00007b78f51d8e9d  vmovaps xmm6, [rsp+0x60]
00007b78f51d8ea3  vmovaps xmm7, [rsp+0x70]
00007b78f51d8ea9  vmovaps xmm8, [rsp+0x80]
00007b78f51d8eb2  vmovaps xmm10, [rsp+0x90]
00007b78f51d8ebb  vmovaps xmm11, [rsp+0xA0]
00007b78f51d8ec4  vmovaps xmm12, [rsp+0xB0]
00007b78f51d8ecd  vmovaps xmm13, [rsp+0xC0]
00007b78f51d8ed6  vmovaps xmm14, [rsp+0xD0]
00007b78f51d8edf  vmovaps xmm15, [rsp+0xE0]
00007b78f51d8ee8  add rsp, 0xF0
00007b78f51d8eef  pop r11
00007b78f51d8ef1  pop r10
00007b78f51d8ef3  pop r9
00007b78f51d8ef5  pop r8
00007b78f51d8ef7  pop rsi
00007b78f51d8ef8  pop rdi
00007b78f51d8ef9  pop rdx
00007b78f51d8efa  pop rcx
00007b78f51d8efb  pop rax
00007b78f51d8efc  add rsp, 0x08
00007b78f51d8f00  jmp 0x00007B78F51D61A1
00007b78f51d8f05  sub rsp, 0x08
00007b78f51d8f09  push rax
00007b78f51d8f0a  push rcx
00007b78f51d8f0b  push rdx
00007b78f51d8f0c  push rdi
00007b78f51d8f0d  push rsi
00007b78f51d8f0e  push r8
00007b78f51d8f10  push r9
00007b78f51d8f12  push r10
00007b78f51d8f14  push r11
00007b78f51d8f16  sub rsp, 0xF0
00007b78f51d8f1d  vmovaps [rsp], xmm0
00007b78f51d8f22  vmovaps [rsp+0x10], xmm2
00007b78f51d8f28  vmovaps [rsp+0x20], xmm3
00007b78f51d8f2e  vmovaps [rsp+0x30], xmm4
00007b78f51d8f34  vmovaps [rsp+0x40], xmm5
00007b78f51d8f3a  vmovaps [rsp+0x50], xmm6
00007b78f51d8f40  vmovaps [rsp+0x60], xmm7
00007b78f51d8f46  vmovaps [rsp+0x70], xmm8
00007b78f51d8f4c  vmovaps [rsp+0x80], xmm9
00007b78f51d8f55  vmovaps [rsp+0x90], xmm10
00007b78f51d8f5e  vmovaps [rsp+0xA0], xmm11
00007b78f51d8f67  vmovaps [rsp+0xB0], xmm12
00007b78f51d8f70  vmovaps [rsp+0xC0], xmm13
00007b78f51d8f79  vmovaps [rsp+0xD0], xmm14
00007b78f51d8f82  vmovaps [rsp+0xE0], xmm15
00007b78f51d8f8b  sub rsp, 0x30
00007b78f51d8f8f  movaps [rsp], xmm1
00007b78f51d8f93  movaps [rsp+0x10], xmm15
00007b78f51d8f99  movaps [rsp+0x20], xmm6
00007b78f51d8f9e  lea rdi, [rsp]
00007b78f51d8fa2  mov esi, 0x00
00007b78f51d8fa7  mov rax, 0x597478C09530
00007b78f51d8fb1  call rax
00007b78f51d8fb3  movaps xmm1, [rsp]
00007b78f51d8fb7  add rsp, 0x30
00007b78f51d8fbb  vmovaps xmm0, [rsp]
00007b78f51d8fc0  vmovaps xmm2, [rsp+0x10]
00007b78f51d8fc6  vmovaps xmm3, [rsp+0x20]
00007b78f51d8fcc  vmovaps xmm4, [rsp+0x30]
00007b78f51d8fd2  vmovaps xmm5, [rsp+0x40]
00007b78f51d8fd8  vmovaps xmm6, [rsp+0x50]
00007b78f51d8fde  vmovaps xmm7, [rsp+0x60]
00007b78f51d8fe4  vmovaps xmm8, [rsp+0x70]
00007b78f51d8fea  vmovaps xmm9, [rsp+0x80]
00007b78f51d8ff3  vmovaps xmm10, [rsp+0x90]
00007b78f51d8ffc  vmovaps xmm11, [rsp+0xA0]
00007b78f51d9005  vmovaps xmm12, [rsp+0xB0]
00007b78f51d900e  vmovaps xmm13, [rsp+0xC0]
00007b78f51d9017  vmovaps xmm14, [rsp+0xD0]
00007b78f51d9020  vmovaps xmm15, [rsp+0xE0]
00007b78f51d9029  add rsp, 0xF0
00007b78f51d9030  pop r11
00007b78f51d9032  pop r10
00007b78f51d9034  pop r9
00007b78f51d9036  pop r8
00007b78f51d9038  pop rsi
00007b78f51d9039  pop rdi
00007b78f51d903a  pop rdx
00007b78f51d903b  pop rcx
00007b78f51d903c  pop rax
00007b78f51d903d  add rsp, 0x08
00007b78f51d9041  jmp 0x00007B78F51D61C2
00007b78f51d9046  sub rsp, 0x08
00007b78f51d904a  push rax
00007b78f51d904b  push rcx
00007b78f51d904c  push rdx
00007b78f51d904d  push rdi
00007b78f51d904e  push rsi
00007b78f51d904f  push r8
00007b78f51d9051  push r9
00007b78f51d9053  push r10
00007b78f51d9055  push r11
00007b78f51d9057  sub rsp, 0xF0
00007b78f51d905e  vmovaps [rsp], xmm0
00007b78f51d9063  vmovaps [rsp+0x10], xmm1
00007b78f51d9069  vmovaps [rsp+0x20], xmm2
00007b78f51d906f  vmovaps [rsp+0x30], xmm3
00007b78f51d9075  vmovaps [rsp+0x40], xmm4
00007b78f51d907b  vmovaps [rsp+0x50], xmm5
00007b78f51d9081  vmovaps [rsp+0x60], xmm6
00007b78f51d9087  vmovaps [rsp+0x70], xmm7
00007b78f51d908d  vmovaps [rsp+0x80], xmm8
00007b78f51d9096  vmovaps [rsp+0x90], xmm9
00007b78f51d909f  vmovaps [rsp+0xA0], xmm10
00007b78f51d90a8  vmovaps [rsp+0xB0], xmm11
00007b78f51d90b1  vmovaps [rsp+0xC0], xmm12
00007b78f51d90ba  vmovaps [rsp+0xD0], xmm13
00007b78f51d90c3  vmovaps [rsp+0xE0], xmm14
00007b78f51d90cc  sub rsp, 0x30
00007b78f51d90d0  movaps [rsp], xmm15
00007b78f51d90d5  movaps [rsp+0x10], xmm5
00007b78f51d90da  movaps [rsp+0x20], xmm3
00007b78f51d90df  lea rdi, [rsp]
00007b78f51d90e3  mov esi, 0x00
00007b78f51d90e8  mov rax, 0x597478C09530
00007b78f51d90f2  call rax
00007b78f51d90f4  movaps xmm15, [rsp]
00007b78f51d90f9  add rsp, 0x30
00007b78f51d90fd  vmovaps xmm0, [rsp]
00007b78f51d9102  vmovaps xmm1, [rsp+0x10]
00007b78f51d9108  vmovaps xmm2, [rsp+0x20]
00007b78f51d910e  vmovaps xmm3, [rsp+0x30]
00007b78f51d9114  vmovaps xmm4, [rsp+0x40]
00007b78f51d911a  vmovaps xmm5, [rsp+0x50]
00007b78f51d9120  vmovaps xmm6, [rsp+0x60]
00007b78f51d9126  vmovaps xmm7, [rsp+0x70]
00007b78f51d912c  vmovaps xmm8, [rsp+0x80]
00007b78f51d9135  vmovaps xmm9, [rsp+0x90]
00007b78f51d913e  vmovaps xmm10, [rsp+0xA0]
00007b78f51d9147  vmovaps xmm11, [rsp+0xB0]
00007b78f51d9150  vmovaps xmm12, [rsp+0xC0]
00007b78f51d9159  vmovaps xmm13, [rsp+0xD0]
00007b78f51d9162  vmovaps xmm14, [rsp+0xE0]
00007b78f51d916b  add rsp, 0xF0
00007b78f51d9172  pop r11
00007b78f51d9174  pop r10
00007b78f51d9176  pop r9
00007b78f51d9178  pop r8
00007b78f51d917a  pop rsi
00007b78f51d917b  pop rdi
00007b78f51d917c  pop rdx
00007b78f51d917d  pop rcx
00007b78f51d917e  pop rax
00007b78f51d917f  add rsp, 0x08
00007b78f51d9183  jmp 0x00007B78F51D61DC
00007b78f51d9188  sub rsp, 0x08
00007b78f51d918c  push rax
00007b78f51d918d  push rcx
00007b78f51d918e  push rdx
00007b78f51d918f  push rdi
00007b78f51d9190  push rsi
00007b78f51d9191  push r8
00007b78f51d9193  push r9
00007b78f51d9195  push r10
00007b78f51d9197  push r11
00007b78f51d9199  sub rsp, 0xF0
00007b78f51d91a0  vmovaps [rsp], xmm0
00007b78f51d91a5  vmovaps [rsp+0x10], xmm1
00007b78f51d91ab  vmovaps [rsp+0x20], xmm2
00007b78f51d91b1  vmovaps [rsp+0x30], xmm3
00007b78f51d91b7  vmovaps [rsp+0x40], xmm4
00007b78f51d91bd  vmovaps [rsp+0x50], xmm6
00007b78f51d91c3  vmovaps [rsp+0x60], xmm7
00007b78f51d91c9  vmovaps [rsp+0x70], xmm8
00007b78f51d91cf  vmovaps [rsp+0x80], xmm9
00007b78f51d91d8  vmovaps [rsp+0x90], xmm10
00007b78f51d91e1  vmovaps [rsp+0xA0], xmm11
00007b78f51d91ea  vmovaps [rsp+0xB0], xmm12
00007b78f51d91f3  vmovaps [rsp+0xC0], xmm13
00007b78f51d91fc  vmovaps [rsp+0xD0], xmm14
00007b78f51d9205  vmovaps [rsp+0xE0], xmm15
00007b78f51d920e  sub rsp, 0x30
00007b78f51d9212  movaps [rsp], xmm5
00007b78f51d9216  movaps [rsp+0x10], xmm8
00007b78f51d921c  movaps [rsp+0x20], xmm6
00007b78f51d9221  lea rdi, [rsp]
00007b78f51d9225  mov esi, 0x00
00007b78f51d922a  mov rax, 0x597478C09530
00007b78f51d9234  call rax
00007b78f51d9236  movaps xmm5, [rsp]
00007b78f51d923a  add rsp, 0x30
00007b78f51d923e  vmovaps xmm0, [rsp]
00007b78f51d9243  vmovaps xmm1, [rsp+0x10]
00007b78f51d9249  vmovaps xmm2, [rsp+0x20]
00007b78f51d924f  vmovaps xmm3, [rsp+0x30]
00007b78f51d9255  vmovaps xmm4, [rsp+0x40]
00007b78f51d925b  vmovaps xmm6, [rsp+0x50]
00007b78f51d9261  vmovaps xmm7, [rsp+0x60]
00007b78f51d9267  vmovaps xmm8, [rsp+0x70]
00007b78f51d926d  vmovaps xmm9, [rsp+0x80]
00007b78f51d9276  vmovaps xmm10, [rsp+0x90]
00007b78f51d927f  vmovaps xmm11, [rsp+0xA0]
00007b78f51d9288  vmovaps xmm12, [rsp+0xB0]
00007b78f51d9291  vmovaps xmm13, [rsp+0xC0]
00007b78f51d929a  vmovaps xmm14, [rsp+0xD0]
00007b78f51d92a3  vmovaps xmm15, [rsp+0xE0]
00007b78f51d92ac  add rsp, 0xF0
00007b78f51d92b3  pop r11
00007b78f51d92b5  pop r10
00007b78f51d92b7  pop r9
00007b78f51d92b9  pop r8
00007b78f51d92bb  pop rsi
00007b78f51d92bc  pop rdi
00007b78f51d92bd  pop rdx
00007b78f51d92be  pop rcx
00007b78f51d92bf  pop rax
00007b78f51d92c0  add rsp, 0x08
00007b78f51d92c4  jmp 0x00007B78F51D6200
00007b78f51d92c9  sub rsp, 0x08
00007b78f51d92cd  push rax
00007b78f51d92ce  push rcx
00007b78f51d92cf  push rdx
00007b78f51d92d0  push rdi
00007b78f51d92d1  push rsi
00007b78f51d92d2  push r8
00007b78f51d92d4  push r9
00007b78f51d92d6  push r10
00007b78f51d92d8  push r11
00007b78f51d92da  sub rsp, 0xF0
00007b78f51d92e1  vmovaps [rsp], xmm0
00007b78f51d92e6  vmovaps [rsp+0x10], xmm1
00007b78f51d92ec  vmovaps [rsp+0x20], xmm2
00007b78f51d92f2  vmovaps [rsp+0x30], xmm3
00007b78f51d92f8  vmovaps [rsp+0x40], xmm4
00007b78f51d92fe  vmovaps [rsp+0x50], xmm5
00007b78f51d9304  vmovaps [rsp+0x60], xmm7
00007b78f51d930a  vmovaps [rsp+0x70], xmm8
00007b78f51d9310  vmovaps [rsp+0x80], xmm9
00007b78f51d9319  vmovaps [rsp+0x90], xmm10
00007b78f51d9322  vmovaps [rsp+0xA0], xmm11
00007b78f51d932b  vmovaps [rsp+0xB0], xmm12
00007b78f51d9334  vmovaps [rsp+0xC0], xmm13
00007b78f51d933d  vmovaps [rsp+0xD0], xmm14
00007b78f51d9346  vmovaps [rsp+0xE0], xmm15
00007b78f51d934f  sub rsp, 0x30
00007b78f51d9353  movaps [rsp], xmm6
00007b78f51d9357  movaps [rsp+0x10], xmm10
00007b78f51d935d  movaps [rsp+0x20], xmm8
00007b78f51d9363  lea rdi, [rsp]
00007b78f51d9367  mov esi, 0x00
00007b78f51d936c  mov rax, 0x597478C09530
00007b78f51d9376  call rax
00007b78f51d9378  movaps xmm6, [rsp]
00007b78f51d937c  add rsp, 0x30
00007b78f51d9380  vmovaps xmm0, [rsp]
00007b78f51d9385  vmovaps xmm1, [rsp+0x10]
00007b78f51d938b  vmovaps xmm2, [rsp+0x20]
00007b78f51d9391  vmovaps xmm3, [rsp+0x30]
00007b78f51d9397  vmovaps xmm4, [rsp+0x40]
00007b78f51d939d  vmovaps xmm5, [rsp+0x50]
00007b78f51d93a3  vmovaps xmm7, [rsp+0x60]
00007b78f51d93a9  vmovaps xmm8, [rsp+0x70]
00007b78f51d93af  vmovaps xmm9, [rsp+0x80]
00007b78f51d93b8  vmovaps xmm10, [rsp+0x90]
00007b78f51d93c1  vmovaps xmm11, [rsp+0xA0]
00007b78f51d93ca  vmovaps xmm12, [rsp+0xB0]
00007b78f51d93d3  vmovaps xmm13, [rsp+0xC0]
00007b78f51d93dc  vmovaps xmm14, [rsp+0xD0]
00007b78f51d93e5  vmovaps xmm15, [rsp+0xE0]
00007b78f51d93ee  add rsp, 0xF0
00007b78f51d93f5  pop r11
00007b78f51d93f7  pop r10
00007b78f51d93f9  pop r9
00007b78f51d93fb  pop r8
00007b78f51d93fd  pop rsi
00007b78f51d93fe  pop rdi
00007b78f51d93ff  pop rdx
00007b78f51d9400  pop rcx
00007b78f51d9401  pop rax
00007b78f51d9402  add rsp, 0x08
00007b78f51d9406  jmp 0x00007B78F51D6225
00007b78f51d940b  sub rsp, 0x08
00007b78f51d940f  push rax
00007b78f51d9410  push rcx
00007b78f51d9411  push rdx
00007b78f51d9412  push rdi
00007b78f51d9413  push rsi
00007b78f51d9414  push r8
00007b78f51d9416  push r9
00007b78f51d9418  push r10
00007b78f51d941a  push r11
00007b78f51d941c  sub rsp, 0xF0
00007b78f51d9423  vmovaps [rsp], xmm0
00007b78f51d9428  vmovaps [rsp+0x10], xmm1
00007b78f51d942e  vmovaps [rsp+0x20], xmm2
00007b78f51d9434  vmovaps [rsp+0x30], xmm3
00007b78f51d943a  vmovaps [rsp+0x40], xmm4
00007b78f51d9440  vmovaps [rsp+0x50], xmm5
00007b78f51d9446  vmovaps [rsp+0x60], xmm6
00007b78f51d944c  vmovaps [rsp+0x70], xmm7
00007b78f51d9452  vmovaps [rsp+0x80], xmm8
00007b78f51d945b  vmovaps [rsp+0x90], xmm9
00007b78f51d9464  vmovaps [rsp+0xA0], xmm11
00007b78f51d946d  vmovaps [rsp+0xB0], xmm12
00007b78f51d9476  vmovaps [rsp+0xC0], xmm13
00007b78f51d947f  vmovaps [rsp+0xD0], xmm14
00007b78f51d9488  vmovaps [rsp+0xE0], xmm15
00007b78f51d9491  sub rsp, 0x30
00007b78f51d9495  movaps [rsp], xmm10
00007b78f51d949a  movaps [rsp+0x10], xmm8
00007b78f51d94a0  movaps [rsp+0x20], xmm14
00007b78f51d94a6  lea rdi, [rsp]
00007b78f51d94aa  mov esi, 0x00
00007b78f51d94af  mov rax, 0x597478C09530
00007b78f51d94b9  call rax
00007b78f51d94bb  movaps xmm10, [rsp]
00007b78f51d94c0  add rsp, 0x30
00007b78f51d94c4  vmovaps xmm0, [rsp]
00007b78f51d94c9  vmovaps xmm1, [rsp+0x10]
00007b78f51d94cf  vmovaps xmm2, [rsp+0x20]
00007b78f51d94d5  vmovaps xmm3, [rsp+0x30]
00007b78f51d94db  vmovaps xmm4, [rsp+0x40]
00007b78f51d94e1  vmovaps xmm5, [rsp+0x50]
00007b78f51d94e7  vmovaps xmm6, [rsp+0x60]
00007b78f51d94ed  vmovaps xmm7, [rsp+0x70]
00007b78f51d94f3  vmovaps xmm8, [rsp+0x80]
00007b78f51d94fc  vmovaps xmm9, [rsp+0x90]
00007b78f51d9505  vmovaps xmm11, [rsp+0xA0]
00007b78f51d950e  vmovaps xmm12, [rsp+0xB0]
00007b78f51d9517  vmovaps xmm13, [rsp+0xC0]
00007b78f51d9520  vmovaps xmm14, [rsp+0xD0]
00007b78f51d9529  vmovaps xmm15, [rsp+0xE0]
00007b78f51d9532  add rsp, 0xF0
00007b78f51d9539  pop r11
00007b78f51d953b  pop r10
00007b78f51d953d  pop r9
00007b78f51d953f  pop r8
00007b78f51d9541  pop rsi
00007b78f51d9542  pop rdi
00007b78f51d9543  pop rdx
00007b78f51d9544  pop rcx
00007b78f51d9545  pop rax
00007b78f51d9546  add rsp, 0x08
00007b78f51d954a  jmp 0x00007B78F51D6245
00007b78f51d954f  sub rsp, 0x08
00007b78f51d9553  push rax
00007b78f51d9554  push rcx
00007b78f51d9555  push rdx
00007b78f51d9556  push rdi
00007b78f51d9557  push rsi
00007b78f51d9558  push r8
00007b78f51d955a  push r9
00007b78f51d955c  push r10
00007b78f51d955e  push r11
00007b78f51d9560  sub rsp, 0xF0
00007b78f51d9567  vmovaps [rsp], xmm0
00007b78f51d956c  vmovaps [rsp+0x10], xmm1
00007b78f51d9572  vmovaps [rsp+0x20], xmm2
00007b78f51d9578  vmovaps [rsp+0x30], xmm3
00007b78f51d957e  vmovaps [rsp+0x40], xmm4
00007b78f51d9584  vmovaps [rsp+0x50], xmm5
00007b78f51d958a  vmovaps [rsp+0x60], xmm6
00007b78f51d9590  vmovaps [rsp+0x70], xmm7
00007b78f51d9596  vmovaps [rsp+0x80], xmm8
00007b78f51d959f  vmovaps [rsp+0x90], xmm9
00007b78f51d95a8  vmovaps [rsp+0xA0], xmm10
00007b78f51d95b1  vmovaps [rsp+0xB0], xmm11
00007b78f51d95ba  vmovaps [rsp+0xC0], xmm12
00007b78f51d95c3  vmovaps [rsp+0xD0], xmm13
00007b78f51d95cc  vmovaps [rsp+0xE0], xmm15
00007b78f51d95d5  sub rsp, 0x30
00007b78f51d95d9  movaps [rsp], xmm14
00007b78f51d95de  movaps [rsp+0x10], xmm8
00007b78f51d95e4  movaps [rsp+0x20], xmm4
00007b78f51d95e9  lea rdi, [rsp]
00007b78f51d95ed  mov esi, 0x00
00007b78f51d95f2  mov rax, 0x597478C09530
00007b78f51d95fc  call rax
00007b78f51d95fe  movaps xmm14, [rsp]
00007b78f51d9603  add rsp, 0x30
00007b78f51d9607  vmovaps xmm0, [rsp]
00007b78f51d960c  vmovaps xmm1, [rsp+0x10]
00007b78f51d9612  vmovaps xmm2, [rsp+0x20]
00007b78f51d9618  vmovaps xmm3, [rsp+0x30]
00007b78f51d961e  vmovaps xmm4, [rsp+0x40]
00007b78f51d9624  vmovaps xmm5, [rsp+0x50]
00007b78f51d962a  vmovaps xmm6, [rsp+0x60]
00007b78f51d9630  vmovaps xmm7, [rsp+0x70]
00007b78f51d9636  vmovaps xmm8, [rsp+0x80]
00007b78f51d963f  vmovaps xmm9, [rsp+0x90]
00007b78f51d9648  vmovaps xmm10, [rsp+0xA0]
00007b78f51d9651  vmovaps xmm11, [rsp+0xB0]
00007b78f51d965a  vmovaps xmm12, [rsp+0xC0]
00007b78f51d9663  vmovaps xmm13, [rsp+0xD0]
00007b78f51d966c  vmovaps xmm15, [rsp+0xE0]
00007b78f51d9675  add rsp, 0xF0
00007b78f51d967c  pop r11
00007b78f51d967e  pop r10
00007b78f51d9680  pop r9
00007b78f51d9682  pop r8
00007b78f51d9684  pop rsi
00007b78f51d9685  pop rdi
00007b78f51d9686  pop rdx
00007b78f51d9687  pop rcx
00007b78f51d9688  pop rax
00007b78f51d9689  add rsp, 0x08
00007b78f51d968d  jmp 0x00007B78F51D6265
00007b78f51d9692  sub rsp, 0x08
00007b78f51d9696  push rax
00007b78f51d9697  push rcx
00007b78f51d9698  push rdx
00007b78f51d9699  push rdi
00007b78f51d969a  push rsi
00007b78f51d969b  push r8
00007b78f51d969d  push r9
00007b78f51d969f  push r10
00007b78f51d96a1  push r11
00007b78f51d96a3  sub rsp, 0xF0
00007b78f51d96aa  vmovaps [rsp], xmm0
00007b78f51d96af  vmovaps [rsp+0x10], xmm1
00007b78f51d96b5  vmovaps [rsp+0x20], xmm2
00007b78f51d96bb  vmovaps [rsp+0x30], xmm3
00007b78f51d96c1  vmovaps [rsp+0x40], xmm5
00007b78f51d96c7  vmovaps [rsp+0x50], xmm6
00007b78f51d96cd  vmovaps [rsp+0x60], xmm7
00007b78f51d96d3  vmovaps [rsp+0x70], xmm8
00007b78f51d96d9  vmovaps [rsp+0x80], xmm9
00007b78f51d96e2  vmovaps [rsp+0x90], xmm10
00007b78f51d96eb  vmovaps [rsp+0xA0], xmm11
00007b78f51d96f4  vmovaps [rsp+0xB0], xmm12
00007b78f51d96fd  vmovaps [rsp+0xC0], xmm13
00007b78f51d9706  vmovaps [rsp+0xD0], xmm14
00007b78f51d970f  vmovaps [rsp+0xE0], xmm15
00007b78f51d9718  sub rsp, 0x30
00007b78f51d971c  movaps [rsp], xmm4
00007b78f51d9720  movaps [rsp+0x10], xmm13
00007b78f51d9726  movaps [rsp+0x20], xmm8
00007b78f51d972c  lea rdi, [rsp]
00007b78f51d9730  mov esi, 0x00
00007b78f51d9735  mov rax, 0x597478C09530
00007b78f51d973f  call rax
00007b78f51d9741  movaps xmm4, [rsp]
00007b78f51d9745  add rsp, 0x30
00007b78f51d9749  vmovaps xmm0, [rsp]
00007b78f51d974e  vmovaps xmm1, [rsp+0x10]
00007b78f51d9754  vmovaps xmm2, [rsp+0x20]
00007b78f51d975a  vmovaps xmm3, [rsp+0x30]
00007b78f51d9760  vmovaps xmm5, [rsp+0x40]
00007b78f51d9766  vmovaps xmm6, [rsp+0x50]
00007b78f51d976c  vmovaps xmm7, [rsp+0x60]
00007b78f51d9772  vmovaps xmm8, [rsp+0x70]
00007b78f51d9778  vmovaps xmm9, [rsp+0x80]
00007b78f51d9781  vmovaps xmm10, [rsp+0x90]
00007b78f51d978a  vmovaps xmm11, [rsp+0xA0]
00007b78f51d9793  vmovaps xmm12, [rsp+0xB0]
00007b78f51d979c  vmovaps xmm13, [rsp+0xC0]
00007b78f51d97a5  vmovaps xmm14, [rsp+0xD0]
00007b78f51d97ae  vmovaps xmm15, [rsp+0xE0]
00007b78f51d97b7  add rsp, 0xF0
00007b78f51d97be  pop r11
00007b78f51d97c0  pop r10
00007b78f51d97c2  pop r9
00007b78f51d97c4  pop r8
00007b78f51d97c6  pop rsi
00007b78f51d97c7  pop rdi
00007b78f51d97c8  pop rdx
00007b78f51d97c9  pop rcx
00007b78f51d97ca  pop rax
00007b78f51d97cb  add rsp, 0x08
00007b78f51d97cf  jmp 0x00007B78F51D628A
00007b78f51d97d4  sub rsp, 0x08
00007b78f51d97d8  push rax
00007b78f51d97d9  push rcx
00007b78f51d97da  push rdx
00007b78f51d97db  push rdi
00007b78f51d97dc  push rsi
00007b78f51d97dd  push r8
00007b78f51d97df  push r9
00007b78f51d97e1  push r10
00007b78f51d97e3  push r11
00007b78f51d97e5  sub rsp, 0xF0
00007b78f51d97ec  vmovaps [rsp], xmm0
00007b78f51d97f1  vmovaps [rsp+0x10], xmm1
00007b78f51d97f7  vmovaps [rsp+0x20], xmm2
00007b78f51d97fd  vmovaps [rsp+0x30], xmm3
00007b78f51d9803  vmovaps [rsp+0x40], xmm4
00007b78f51d9809  vmovaps [rsp+0x50], xmm5
00007b78f51d980f  vmovaps [rsp+0x60], xmm6
00007b78f51d9815  vmovaps [rsp+0x70], xmm7
00007b78f51d981b  vmovaps [rsp+0x80], xmm8
00007b78f51d9824  vmovaps [rsp+0x90], xmm9
00007b78f51d982d  vmovaps [rsp+0xA0], xmm10
00007b78f51d9836  vmovaps [rsp+0xB0], xmm11
00007b78f51d983f  vmovaps [rsp+0xC0], xmm12
00007b78f51d9848  vmovaps [rsp+0xD0], xmm14
00007b78f51d9851  vmovaps [rsp+0xE0], xmm15
00007b78f51d985a  sub rsp, 0x30
00007b78f51d985e  movaps [rsp], xmm13
00007b78f51d9863  movaps [rsp+0x10], xmm15
00007b78f51d9869  movaps [rsp+0x20], xmm9
00007b78f51d986f  lea rdi, [rsp]
00007b78f51d9873  mov esi, 0x00
00007b78f51d9878  mov rax, 0x597478C09530
00007b78f51d9882  call rax
00007b78f51d9884  movaps xmm13, [rsp]
00007b78f51d9889  add rsp, 0x30
00007b78f51d988d  vmovaps xmm0, [rsp]
00007b78f51d9892  vmovaps xmm1, [rsp+0x10]
00007b78f51d9898  vmovaps xmm2, [rsp+0x20]
00007b78f51d989e  vmovaps xmm3, [rsp+0x30]
00007b78f51d98a4  vmovaps xmm4, [rsp+0x40]
00007b78f51d98aa  vmovaps xmm5, [rsp+0x50]
00007b78f51d98b0  vmovaps xmm6, [rsp+0x60]
00007b78f51d98b6  vmovaps xmm7, [rsp+0x70]
00007b78f51d98bc  vmovaps xmm8, [rsp+0x80]
00007b78f51d98c5  vmovaps xmm9, [rsp+0x90]
00007b78f51d98ce  vmovaps xmm10, [rsp+0xA0]
00007b78f51d98d7  vmovaps xmm11, [rsp+0xB0]
00007b78f51d98e0  vmovaps xmm12, [rsp+0xC0]
00007b78f51d98e9  vmovaps xmm14, [rsp+0xD0]
00007b78f51d98f2  vmovaps xmm15, [rsp+0xE0]
00007b78f51d98fb  add rsp, 0xF0
00007b78f51d9902  pop r11
00007b78f51d9904  pop r10
00007b78f51d9906  pop r9
00007b78f51d9908  pop r8
00007b78f51d990a  pop rsi
00007b78f51d990b  pop rdi
00007b78f51d990c  pop rdx
00007b78f51d990d  pop rcx
00007b78f51d990e  pop rax
00007b78f51d990f  add rsp, 0x08
00007b78f51d9913  jmp 0x00007B78F51D62A5
00007b78f51d9918  sub rsp, 0x08
00007b78f51d991c  push rax
00007b78f51d991d  push rcx
00007b78f51d991e  push rdx
00007b78f51d991f  push rdi
00007b78f51d9920  push rsi
00007b78f51d9921  push r8
00007b78f51d9923  push r9
00007b78f51d9925  push r10
00007b78f51d9927  push r11
00007b78f51d9929  sub rsp, 0xF0
00007b78f51d9930  vmovaps [rsp], xmm0
00007b78f51d9935  vmovaps [rsp+0x10], xmm1
00007b78f51d993b  vmovaps [rsp+0x20], xmm2
00007b78f51d9941  vmovaps [rsp+0x30], xmm3
00007b78f51d9947  vmovaps [rsp+0x40], xmm4
00007b78f51d994d  vmovaps [rsp+0x50], xmm5
00007b78f51d9953  vmovaps [rsp+0x60], xmm6
00007b78f51d9959  vmovaps [rsp+0x70], xmm7
00007b78f51d995f  vmovaps [rsp+0x80], xmm8
00007b78f51d9968  vmovaps [rsp+0x90], xmm9
00007b78f51d9971  vmovaps [rsp+0xA0], xmm10
00007b78f51d997a  vmovaps [rsp+0xB0], xmm11
00007b78f51d9983  vmovaps [rsp+0xC0], xmm12
00007b78f51d998c  vmovaps [rsp+0xD0], xmm13
00007b78f51d9995  vmovaps [rsp+0xE0], xmm14
00007b78f51d999e  sub rsp, 0x30
00007b78f51d99a2  movaps [rsp], xmm15
00007b78f51d99a7  movaps [rsp+0x10], xmm1
00007b78f51d99ac  movaps [rsp+0x20], xmm5
00007b78f51d99b1  lea rdi, [rsp]
00007b78f51d99b5  mov esi, 0x00
00007b78f51d99ba  mov rax, 0x597478C09530
00007b78f51d99c4  call rax
00007b78f51d99c6  movaps xmm15, [rsp]
00007b78f51d99cb  add rsp, 0x30
00007b78f51d99cf  vmovaps xmm0, [rsp]
00007b78f51d99d4  vmovaps xmm1, [rsp+0x10]
00007b78f51d99da  vmovaps xmm2, [rsp+0x20]
00007b78f51d99e0  vmovaps xmm3, [rsp+0x30]
00007b78f51d99e6  vmovaps xmm4, [rsp+0x40]
00007b78f51d99ec  vmovaps xmm5, [rsp+0x50]
00007b78f51d99f2  vmovaps xmm6, [rsp+0x60]
00007b78f51d99f8  vmovaps xmm7, [rsp+0x70]
00007b78f51d99fe  vmovaps xmm8, [rsp+0x80]
00007b78f51d9a07  vmovaps xmm9, [rsp+0x90]
00007b78f51d9a10  vmovaps xmm10, [rsp+0xA0]
00007b78f51d9a19  vmovaps xmm11, [rsp+0xB0]
00007b78f51d9a22  vmovaps xmm12, [rsp+0xC0]
00007b78f51d9a2b  vmovaps xmm13, [rsp+0xD0]
00007b78f51d9a34  vmovaps xmm14, [rsp+0xE0]
00007b78f51d9a3d  add rsp, 0xF0
00007b78f51d9a44  pop r11
00007b78f51d9a46  pop r10
00007b78f51d9a48  pop r9
00007b78f51d9a4a  pop r8
00007b78f51d9a4c  pop rsi
00007b78f51d9a4d  pop rdi
00007b78f51d9a4e  pop rdx
00007b78f51d9a4f  pop rcx
00007b78f51d9a50  pop rax
00007b78f51d9a51  add rsp, 0x08
00007b78f51d9a55  jmp 0x00007B78F51D62C0
00007b78f51d9a5a  call 0x00007B78F50D64F0
00007b78f51d9a5f  jmp 0x00007B78F51D631B
00007b78f51d9a64  sub rsp, 0x08
00007b78f51d9a68  push rax
00007b78f51d9a69  push rcx
00007b78f51d9a6a  push rdx
00007b78f51d9a6b  push rdi
00007b78f51d9a6c  push rsi
00007b78f51d9a6d  push r8
00007b78f51d9a6f  push r9
00007b78f51d9a71  push r10
00007b78f51d9a73  push r11
00007b78f51d9a75  sub rsp, 0xF0
00007b78f51d9a7c  vmovaps [rsp], xmm0
00007b78f51d9a81  vmovaps [rsp+0x10], xmm1
00007b78f51d9a87  vmovaps [rsp+0x20], xmm2
00007b78f51d9a8d  vmovaps [rsp+0x30], xmm3
00007b78f51d9a93  vmovaps [rsp+0x40], xmm4
00007b78f51d9a99  vmovaps [rsp+0x50], xmm5
00007b78f51d9a9f  vmovaps [rsp+0x60], xmm6
00007b78f51d9aa5  vmovaps [rsp+0x70], xmm7
00007b78f51d9aab  vmovaps [rsp+0x80], xmm8
00007b78f51d9ab4  vmovaps [rsp+0x90], xmm10
00007b78f51d9abd  vmovaps [rsp+0xA0], xmm11
00007b78f51d9ac6  vmovaps [rsp+0xB0], xmm12
00007b78f51d9acf  vmovaps [rsp+0xC0], xmm13
00007b78f51d9ad8  vmovaps [rsp+0xD0], xmm14
00007b78f51d9ae1  vmovaps [rsp+0xE0], xmm15
00007b78f51d9aea  sub rsp, 0x30
00007b78f51d9aee  movaps [rsp], xmm9
00007b78f51d9af3  movaps [rsp+0x10], xmm8
00007b78f51d9af9  movaps [rsp+0x20], xmm11
00007b78f51d9aff  lea rdi, [rsp]
00007b78f51d9b03  mov esi, 0x00
00007b78f51d9b08  mov rax, 0x597478C09530
00007b78f51d9b12  call rax
00007b78f51d9b14  movaps xmm9, [rsp]
00007b78f51d9b19  add rsp, 0x30
00007b78f51d9b1d  vmovaps xmm0, [rsp]
00007b78f51d9b22  vmovaps xmm1, [rsp+0x10]
00007b78f51d9b28  vmovaps xmm2, [rsp+0x20]
00007b78f51d9b2e  vmovaps xmm3, [rsp+0x30]
00007b78f51d9b34  vmovaps xmm4, [rsp+0x40]
00007b78f51d9b3a  vmovaps xmm5, [rsp+0x50]
00007b78f51d9b40  vmovaps xmm6, [rsp+0x60]
00007b78f51d9b46  vmovaps xmm7, [rsp+0x70]
00007b78f51d9b4c  vmovaps xmm8, [rsp+0x80]
00007b78f51d9b55  vmovaps xmm10, [rsp+0x90]
00007b78f51d9b5e  vmovaps xmm11, [rsp+0xA0]
00007b78f51d9b67  vmovaps xmm12, [rsp+0xB0]
00007b78f51d9b70  vmovaps xmm13, [rsp+0xC0]
00007b78f51d9b79  vmovaps xmm14, [rsp+0xD0]
00007b78f51d9b82  vmovaps xmm15, [rsp+0xE0]
00007b78f51d9b8b  add rsp, 0xF0
00007b78f51d9b92  pop r11
00007b78f51d9b94  pop r10
00007b78f51d9b96  pop r9
00007b78f51d9b98  pop r8
00007b78f51d9b9a  pop rsi
00007b78f51d9b9b  pop rdi
00007b78f51d9b9c  pop rdx
00007b78f51d9b9d  pop rcx
00007b78f51d9b9e  pop rax
00007b78f51d9b9f  add rsp, 0x08
00007b78f51d9ba3  jmp 0x00007B78F51D6352
00007b78f51d9ba8  sub rsp, 0x08
00007b78f51d9bac  push rax
00007b78f51d9bad  push rcx
00007b78f51d9bae  push rdx
00007b78f51d9baf  push rdi
00007b78f51d9bb0  push rsi
00007b78f51d9bb1  push r8
00007b78f51d9bb3  push r9
00007b78f51d9bb5  push r10
00007b78f51d9bb7  push r11
00007b78f51d9bb9  sub rsp, 0xF0
00007b78f51d9bc0  vmovaps [rsp], xmm0
00007b78f51d9bc5  vmovaps [rsp+0x10], xmm1
00007b78f51d9bcb  vmovaps [rsp+0x20], xmm2
00007b78f51d9bd1  vmovaps [rsp+0x30], xmm3
00007b78f51d9bd7  vmovaps [rsp+0x40], xmm4
00007b78f51d9bdd  vmovaps [rsp+0x50], xmm5
00007b78f51d9be3  vmovaps [rsp+0x60], xmm6
00007b78f51d9be9  vmovaps [rsp+0x70], xmm7
00007b78f51d9bef  vmovaps [rsp+0x80], xmm8
00007b78f51d9bf8  vmovaps [rsp+0x90], xmm9
00007b78f51d9c01  vmovaps [rsp+0xA0], xmm10
00007b78f51d9c0a  vmovaps [rsp+0xB0], xmm12
00007b78f51d9c13  vmovaps [rsp+0xC0], xmm13
00007b78f51d9c1c  vmovaps [rsp+0xD0], xmm14
00007b78f51d9c25  vmovaps [rsp+0xE0], xmm15
00007b78f51d9c2e  sub rsp, 0x30
00007b78f51d9c32  movaps [rsp], xmm11
00007b78f51d9c37  movaps [rsp+0x10], xmm10
00007b78f51d9c3d  movaps [rsp+0x20], xmm6
00007b78f51d9c42  lea rdi, [rsp]
00007b78f51d9c46  mov esi, 0x00
00007b78f51d9c4b  mov rax, 0x597478C09530
00007b78f51d9c55  call rax
00007b78f51d9c57  movaps xmm11, [rsp]
00007b78f51d9c5c  add rsp, 0x30
00007b78f51d9c60  vmovaps xmm0, [rsp]
00007b78f51d9c65  vmovaps xmm1, [rsp+0x10]
00007b78f51d9c6b  vmovaps xmm2, [rsp+0x20]
00007b78f51d9c71  vmovaps xmm3, [rsp+0x30]
00007b78f51d9c77  vmovaps xmm4, [rsp+0x40]
00007b78f51d9c7d  vmovaps xmm5, [rsp+0x50]
00007b78f51d9c83  vmovaps xmm6, [rsp+0x60]
00007b78f51d9c89  vmovaps xmm7, [rsp+0x70]
00007b78f51d9c8f  vmovaps xmm8, [rsp+0x80]
00007b78f51d9c98  vmovaps xmm9, [rsp+0x90]
00007b78f51d9ca1  vmovaps xmm10, [rsp+0xA0]
00007b78f51d9caa  vmovaps xmm12, [rsp+0xB0]
00007b78f51d9cb3  vmovaps xmm13, [rsp+0xC0]
00007b78f51d9cbc  vmovaps xmm14, [rsp+0xD0]
00007b78f51d9cc5  vmovaps xmm15, [rsp+0xE0]
00007b78f51d9cce  add rsp, 0xF0
00007b78f51d9cd5  pop r11
00007b78f51d9cd7  pop r10
00007b78f51d9cd9  pop r9
00007b78f51d9cdb  pop r8
00007b78f51d9cdd  pop rsi
00007b78f51d9cde  pop rdi
00007b78f51d9cdf  pop rdx
00007b78f51d9ce0  pop rcx
00007b78f51d9ce1  pop rax
00007b78f51d9ce2  add rsp, 0x08
00007b78f51d9ce6  jmp 0x00007B78F51D636D
00007b78f51d9ceb  sub rsp, 0x08
00007b78f51d9cef  push rax
00007b78f51d9cf0  push rcx
00007b78f51d9cf1  push rdx
00007b78f51d9cf2  push rdi
00007b78f51d9cf3  push rsi
00007b78f51d9cf4  push r8
00007b78f51d9cf6  push r9
00007b78f51d9cf8  push r10
00007b78f51d9cfa  push r11
00007b78f51d9cfc  sub rsp, 0xF0
00007b78f51d9d03  vmovaps [rsp], xmm0
00007b78f51d9d08  vmovaps [rsp+0x10], xmm1
00007b78f51d9d0e  vmovaps [rsp+0x20], xmm2
00007b78f51d9d14  vmovaps [rsp+0x30], xmm3
00007b78f51d9d1a  vmovaps [rsp+0x40], xmm4
00007b78f51d9d20  vmovaps [rsp+0x50], xmm5
00007b78f51d9d26  vmovaps [rsp+0x60], xmm6
00007b78f51d9d2c  vmovaps [rsp+0x70], xmm7
00007b78f51d9d32  vmovaps [rsp+0x80], xmm8
00007b78f51d9d3b  vmovaps [rsp+0x90], xmm9
00007b78f51d9d44  vmovaps [rsp+0xA0], xmm11
00007b78f51d9d4d  vmovaps [rsp+0xB0], xmm12
00007b78f51d9d56  vmovaps [rsp+0xC0], xmm13
00007b78f51d9d5f  vmovaps [rsp+0xD0], xmm14
00007b78f51d9d68  vmovaps [rsp+0xE0], xmm15
00007b78f51d9d71  sub rsp, 0x30
00007b78f51d9d75  movaps [rsp], xmm10
00007b78f51d9d7a  movaps [rsp+0x10], xmm14
00007b78f51d9d80  movaps [rsp+0x20], xmm4
00007b78f51d9d85  lea rdi, [rsp]
00007b78f51d9d89  mov esi, 0x00
00007b78f51d9d8e  mov rax, 0x597478C09530
00007b78f51d9d98  call rax
00007b78f51d9d9a  movaps xmm10, [rsp]
00007b78f51d9d9f  add rsp, 0x30
00007b78f51d9da3  vmovaps xmm0, [rsp]
00007b78f51d9da8  vmovaps xmm1, [rsp+0x10]
00007b78f51d9dae  vmovaps xmm2, [rsp+0x20]
00007b78f51d9db4  vmovaps xmm3, [rsp+0x30]
00007b78f51d9dba  vmovaps xmm4, [rsp+0x40]
00007b78f51d9dc0  vmovaps xmm5, [rsp+0x50]
00007b78f51d9dc6  vmovaps xmm6, [rsp+0x60]
00007b78f51d9dcc  vmovaps xmm7, [rsp+0x70]
00007b78f51d9dd2  vmovaps xmm8, [rsp+0x80]
00007b78f51d9ddb  vmovaps xmm9, [rsp+0x90]
00007b78f51d9de4  vmovaps xmm11, [rsp+0xA0]
00007b78f51d9ded  vmovaps xmm12, [rsp+0xB0]
00007b78f51d9df6  vmovaps xmm13, [rsp+0xC0]
00007b78f51d9dff  vmovaps xmm14, [rsp+0xD0]
00007b78f51d9e08  vmovaps xmm15, [rsp+0xE0]
00007b78f51d9e11  add rsp, 0xF0
00007b78f51d9e18  pop r11
00007b78f51d9e1a  pop r10
00007b78f51d9e1c  pop r9
00007b78f51d9e1e  pop r8
00007b78f51d9e20  pop rsi
00007b78f51d9e21  pop rdi
00007b78f51d9e22  pop rdx
00007b78f51d9e23  pop rcx
00007b78f51d9e24  pop rax
00007b78f51d9e25  add rsp, 0x08
00007b78f51d9e29  jmp 0x00007B78F51D6388
00007b78f51d9e2e  sub rsp, 0x08
00007b78f51d9e32  push rax
00007b78f51d9e33  push rcx
00007b78f51d9e34  push rdx
00007b78f51d9e35  push rdi
00007b78f51d9e36  push rsi
00007b78f51d9e37  push r8
00007b78f51d9e39  push r9
00007b78f51d9e3b  push r10
00007b78f51d9e3d  push r11
00007b78f51d9e3f  sub rsp, 0xF0
00007b78f51d9e46  vmovaps [rsp], xmm0
00007b78f51d9e4b  vmovaps [rsp+0x10], xmm1
00007b78f51d9e51  vmovaps [rsp+0x20], xmm2
00007b78f51d9e57  vmovaps [rsp+0x30], xmm3
00007b78f51d9e5d  vmovaps [rsp+0x40], xmm4
00007b78f51d9e63  vmovaps [rsp+0x50], xmm5
00007b78f51d9e69  vmovaps [rsp+0x60], xmm6
00007b78f51d9e6f  vmovaps [rsp+0x70], xmm7
00007b78f51d9e75  vmovaps [rsp+0x80], xmm9
00007b78f51d9e7e  vmovaps [rsp+0x90], xmm10
00007b78f51d9e87  vmovaps [rsp+0xA0], xmm11
00007b78f51d9e90  vmovaps [rsp+0xB0], xmm12
00007b78f51d9e99  vmovaps [rsp+0xC0], xmm13
00007b78f51d9ea2  vmovaps [rsp+0xD0], xmm14
00007b78f51d9eab  vmovaps [rsp+0xE0], xmm15
00007b78f51d9eb4  sub rsp, 0x30
00007b78f51d9eb8  movaps [rsp], xmm8
00007b78f51d9ebd  movaps [rsp+0x10], xmm1
00007b78f51d9ec2  movaps [rsp+0x20], xmm14
00007b78f51d9ec8  lea rdi, [rsp]
00007b78f51d9ecc  mov esi, 0x00
00007b78f51d9ed1  mov rax, 0x597478C09530
00007b78f51d9edb  call rax
00007b78f51d9edd  movaps xmm8, [rsp]
00007b78f51d9ee2  add rsp, 0x30
00007b78f51d9ee6  vmovaps xmm0, [rsp]
00007b78f51d9eeb  vmovaps xmm1, [rsp+0x10]
00007b78f51d9ef1  vmovaps xmm2, [rsp+0x20]
00007b78f51d9ef7  vmovaps xmm3, [rsp+0x30]
00007b78f51d9efd  vmovaps xmm4, [rsp+0x40]
00007b78f51d9f03  vmovaps xmm5, [rsp+0x50]
00007b78f51d9f09  vmovaps xmm6, [rsp+0x60]
00007b78f51d9f0f  vmovaps xmm7, [rsp+0x70]
00007b78f51d9f15  vmovaps xmm9, [rsp+0x80]
00007b78f51d9f1e  vmovaps xmm10, [rsp+0x90]
00007b78f51d9f27  vmovaps xmm11, [rsp+0xA0]
00007b78f51d9f30  vmovaps xmm12, [rsp+0xB0]
00007b78f51d9f39  vmovaps xmm13, [rsp+0xC0]
00007b78f51d9f42  vmovaps xmm14, [rsp+0xD0]
00007b78f51d9f4b  vmovaps xmm15, [rsp+0xE0]
00007b78f51d9f54  add rsp, 0xF0
00007b78f51d9f5b  pop r11
00007b78f51d9f5d  pop r10
00007b78f51d9f5f  pop r9
00007b78f51d9f61  pop r8
00007b78f51d9f63  pop rsi
00007b78f51d9f64  pop rdi
00007b78f51d9f65  pop rdx
00007b78f51d9f66  pop rcx
00007b78f51d9f67  pop rax
00007b78f51d9f68  add rsp, 0x08
00007b78f51d9f6c  jmp 0x00007B78F51D63AE
00007b78f51d9f71  sub rsp, 0x08
00007b78f51d9f75  push rax
00007b78f51d9f76  push rcx
00007b78f51d9f77  push rdx
00007b78f51d9f78  push rdi
00007b78f51d9f79  push rsi
00007b78f51d9f7a  push r8
00007b78f51d9f7c  push r9
00007b78f51d9f7e  push r10
00007b78f51d9f80  push r11
00007b78f51d9f82  sub rsp, 0xF0
00007b78f51d9f89  vmovaps [rsp], xmm0
00007b78f51d9f8e  vmovaps [rsp+0x10], xmm1
00007b78f51d9f94  vmovaps [rsp+0x20], xmm2
00007b78f51d9f9a  vmovaps [rsp+0x30], xmm3
00007b78f51d9fa0  vmovaps [rsp+0x40], xmm4
00007b78f51d9fa6  vmovaps [rsp+0x50], xmm5
00007b78f51d9fac  vmovaps [rsp+0x60], xmm7
00007b78f51d9fb2  vmovaps [rsp+0x70], xmm8
00007b78f51d9fb8  vmovaps [rsp+0x80], xmm9
00007b78f51d9fc1  vmovaps [rsp+0x90], xmm10
00007b78f51d9fca  vmovaps [rsp+0xA0], xmm11
00007b78f51d9fd3  vmovaps [rsp+0xB0], xmm12
00007b78f51d9fdc  vmovaps [rsp+0xC0], xmm13
00007b78f51d9fe5  vmovaps [rsp+0xD0], xmm14
00007b78f51d9fee  vmovaps [rsp+0xE0], xmm15
00007b78f51d9ff7  sub rsp, 0x30
00007b78f51d9ffb  movaps [rsp], xmm6
00007b78f51d9fff  movaps [rsp+0x10], xmm1
00007b78f51da004  movaps [rsp+0x20], xmm14
00007b78f51da00a  lea rdi, [rsp]
00007b78f51da00e  mov esi, 0x00
00007b78f51da013  mov rax, 0x597478C09530
00007b78f51da01d  call rax
00007b78f51da01f  movaps xmm6, [rsp]
00007b78f51da023  add rsp, 0x30
00007b78f51da027  vmovaps xmm0, [rsp]
00007b78f51da02c  vmovaps xmm1, [rsp+0x10]
00007b78f51da032  vmovaps xmm2, [rsp+0x20]
00007b78f51da038  vmovaps xmm3, [rsp+0x30]
00007b78f51da03e  vmovaps xmm4, [rsp+0x40]
00007b78f51da044  vmovaps xmm5, [rsp+0x50]
00007b78f51da04a  vmovaps xmm7, [rsp+0x60]
00007b78f51da050  vmovaps xmm8, [rsp+0x70]
00007b78f51da056  vmovaps xmm9, [rsp+0x80]
00007b78f51da05f  vmovaps xmm10, [rsp+0x90]
00007b78f51da068  vmovaps xmm11, [rsp+0xA0]
00007b78f51da071  vmovaps xmm12, [rsp+0xB0]
00007b78f51da07a  vmovaps xmm13, [rsp+0xC0]
00007b78f51da083  vmovaps xmm14, [rsp+0xD0]
00007b78f51da08c  vmovaps xmm15, [rsp+0xE0]
00007b78f51da095  add rsp, 0xF0
00007b78f51da09c  pop r11
00007b78f51da09e  pop r10
00007b78f51da0a0  pop r9
00007b78f51da0a2  pop r8
00007b78f51da0a4  pop rsi
00007b78f51da0a5  pop rdi
00007b78f51da0a6  pop rdx
00007b78f51da0a7  pop rcx
00007b78f51da0a8  pop rax
00007b78f51da0a9  add rsp, 0x08
00007b78f51da0ad  jmp 0x00007B78F51D63DA
00007b78f51da0b2  sub rsp, 0x08
00007b78f51da0b6  push rax
00007b78f51da0b7  push rcx
00007b78f51da0b8  push rdx
00007b78f51da0b9  push rdi
00007b78f51da0ba  push rsi
00007b78f51da0bb  push r8
00007b78f51da0bd  push r9
00007b78f51da0bf  push r10
00007b78f51da0c1  push r11
00007b78f51da0c3  sub rsp, 0xF0
00007b78f51da0ca  vmovaps [rsp], xmm0
00007b78f51da0cf  vmovaps [rsp+0x10], xmm1
00007b78f51da0d5  vmovaps [rsp+0x20], xmm2
00007b78f51da0db  vmovaps [rsp+0x30], xmm3
00007b78f51da0e1  vmovaps [rsp+0x40], xmm4
00007b78f51da0e7  vmovaps [rsp+0x50], xmm5
00007b78f51da0ed  vmovaps [rsp+0x60], xmm6
00007b78f51da0f3  vmovaps [rsp+0x70], xmm7
00007b78f51da0f9  vmovaps [rsp+0x80], xmm8
00007b78f51da102  vmovaps [rsp+0x90], xmm9
00007b78f51da10b  vmovaps [rsp+0xA0], xmm10
00007b78f51da114  vmovaps [rsp+0xB0], xmm11
00007b78f51da11d  vmovaps [rsp+0xC0], xmm12
00007b78f51da126  vmovaps [rsp+0xD0], xmm13
00007b78f51da12f  vmovaps [rsp+0xE0], xmm15
00007b78f51da138  sub rsp, 0x30
00007b78f51da13c  movaps [rsp], xmm14
00007b78f51da141  movaps [rsp+0x10], xmm12
00007b78f51da147  movaps [rsp+0x20], xmm1
00007b78f51da14c  lea rdi, [rsp]
00007b78f51da150  mov esi, 0x00
00007b78f51da155  mov rax, 0x597478C09530
00007b78f51da15f  call rax
00007b78f51da161  movaps xmm14, [rsp]
00007b78f51da166  add rsp, 0x30
00007b78f51da16a  vmovaps xmm0, [rsp]
00007b78f51da16f  vmovaps xmm1, [rsp+0x10]
00007b78f51da175  vmovaps xmm2, [rsp+0x20]
00007b78f51da17b  vmovaps xmm3, [rsp+0x30]
00007b78f51da181  vmovaps xmm4, [rsp+0x40]
00007b78f51da187  vmovaps xmm5, [rsp+0x50]
00007b78f51da18d  vmovaps xmm6, [rsp+0x60]
00007b78f51da193  vmovaps xmm7, [rsp+0x70]
00007b78f51da199  vmovaps xmm8, [rsp+0x80]
00007b78f51da1a2  vmovaps xmm9, [rsp+0x90]
00007b78f51da1ab  vmovaps xmm10, [rsp+0xA0]
00007b78f51da1b4  vmovaps xmm11, [rsp+0xB0]
00007b78f51da1bd  vmovaps xmm12, [rsp+0xC0]
00007b78f51da1c6  vmovaps xmm13, [rsp+0xD0]
00007b78f51da1cf  vmovaps xmm15, [rsp+0xE0]
00007b78f51da1d8  add rsp, 0xF0
00007b78f51da1df  pop r11
00007b78f51da1e1  pop r10
00007b78f51da1e3  pop r9
00007b78f51da1e5  pop r8
00007b78f51da1e7  pop rsi
00007b78f51da1e8  pop rdi
00007b78f51da1e9  pop rdx
00007b78f51da1ea  pop rcx
00007b78f51da1eb  pop rax
00007b78f51da1ec  add rsp, 0x08
00007b78f51da1f0  jmp 0x00007B78F51D6400
00007b78f51da1f5  sub rsp, 0x08
00007b78f51da1f9  push rax
00007b78f51da1fa  push rcx
00007b78f51da1fb  push rdx
00007b78f51da1fc  push rdi
00007b78f51da1fd  push rsi
00007b78f51da1fe  push r8
00007b78f51da200  push r9
00007b78f51da202  push r10
00007b78f51da204  push r11
00007b78f51da206  sub rsp, 0xF0
00007b78f51da20d  vmovaps [rsp], xmm0
00007b78f51da212  vmovaps [rsp+0x10], xmm2
00007b78f51da218  vmovaps [rsp+0x20], xmm3
00007b78f51da21e  vmovaps [rsp+0x30], xmm4
00007b78f51da224  vmovaps [rsp+0x40], xmm5
00007b78f51da22a  vmovaps [rsp+0x50], xmm6
00007b78f51da230  vmovaps [rsp+0x60], xmm7
00007b78f51da236  vmovaps [rsp+0x70], xmm8
00007b78f51da23c  vmovaps [rsp+0x80], xmm9
00007b78f51da245  vmovaps [rsp+0x90], xmm10
00007b78f51da24e  vmovaps [rsp+0xA0], xmm11
00007b78f51da257  vmovaps [rsp+0xB0], xmm12
00007b78f51da260  vmovaps [rsp+0xC0], xmm13
00007b78f51da269  vmovaps [rsp+0xD0], xmm14
00007b78f51da272  vmovaps [rsp+0xE0], xmm15
00007b78f51da27b  sub rsp, 0x30
00007b78f51da27f  movaps [rsp], xmm1
00007b78f51da283  movaps [rsp+0x10], xmm13
00007b78f51da289  movaps [rsp+0x20], xmm9
00007b78f51da28f  lea rdi, [rsp]
00007b78f51da293  mov esi, 0x00
00007b78f51da298  mov rax, 0x597478C09530
00007b78f51da2a2  call rax
00007b78f51da2a4  movaps xmm1, [rsp]
00007b78f51da2a8  add rsp, 0x30
00007b78f51da2ac  vmovaps xmm0, [rsp]
00007b78f51da2b1  vmovaps xmm2, [rsp+0x10]
00007b78f51da2b7  vmovaps xmm3, [rsp+0x20]
00007b78f51da2bd  vmovaps xmm4, [rsp+0x30]
00007b78f51da2c3  vmovaps xmm5, [rsp+0x40]
00007b78f51da2c9  vmovaps xmm6, [rsp+0x50]
00007b78f51da2cf  vmovaps xmm7, [rsp+0x60]
00007b78f51da2d5  vmovaps xmm8, [rsp+0x70]
00007b78f51da2db  vmovaps xmm9, [rsp+0x80]
00007b78f51da2e4  vmovaps xmm10, [rsp+0x90]
00007b78f51da2ed  vmovaps xmm11, [rsp+0xA0]
00007b78f51da2f6  vmovaps xmm12, [rsp+0xB0]
00007b78f51da2ff  vmovaps xmm13, [rsp+0xC0]
00007b78f51da308  vmovaps xmm14, [rsp+0xD0]
00007b78f51da311  vmovaps xmm15, [rsp+0xE0]
00007b78f51da31a  add rsp, 0xF0
00007b78f51da321  pop r11
00007b78f51da323  pop r10
00007b78f51da325  pop r9
00007b78f51da327  pop r8
00007b78f51da329  pop rsi
00007b78f51da32a  pop rdi
00007b78f51da32b  pop rdx
00007b78f51da32c  pop rcx
00007b78f51da32d  pop rax
00007b78f51da32e  add rsp, 0x08
00007b78f51da332  jmp 0x00007B78F51D641A
00007b78f51da337  sub rsp, 0x08
00007b78f51da33b  push rax
00007b78f51da33c  push rcx
00007b78f51da33d  push rdx
00007b78f51da33e  push rdi
00007b78f51da33f  push rsi
00007b78f51da340  push r8
00007b78f51da342  push r9
00007b78f51da344  push r10
00007b78f51da346  push r11
00007b78f51da348  sub rsp, 0xF0
00007b78f51da34f  vmovaps [rsp], xmm0
00007b78f51da354  vmovaps [rsp+0x10], xmm1
00007b78f51da35a  vmovaps [rsp+0x20], xmm2
00007b78f51da360  vmovaps [rsp+0x30], xmm3
00007b78f51da366  vmovaps [rsp+0x40], xmm4
00007b78f51da36c  vmovaps [rsp+0x50], xmm5
00007b78f51da372  vmovaps [rsp+0x60], xmm6
00007b78f51da378  vmovaps [rsp+0x70], xmm7
00007b78f51da37e  vmovaps [rsp+0x80], xmm8
00007b78f51da387  vmovaps [rsp+0x90], xmm9
00007b78f51da390  vmovaps [rsp+0xA0], xmm10
00007b78f51da399  vmovaps [rsp+0xB0], xmm11
00007b78f51da3a2  vmovaps [rsp+0xC0], xmm13
00007b78f51da3ab  vmovaps [rsp+0xD0], xmm14
00007b78f51da3b4  vmovaps [rsp+0xE0], xmm15
00007b78f51da3bd  sub rsp, 0x30
00007b78f51da3c1  movaps [rsp], xmm12
00007b78f51da3c6  movaps [rsp+0x10], xmm7
00007b78f51da3cb  movaps [rsp+0x20], xmm13
00007b78f51da3d1  lea rdi, [rsp]
00007b78f51da3d5  mov esi, 0x00
00007b78f51da3da  mov rax, 0x597478C09530
00007b78f51da3e4  call rax
00007b78f51da3e6  movaps xmm12, [rsp]
00007b78f51da3eb  add rsp, 0x30
00007b78f51da3ef  vmovaps xmm0, [rsp]
00007b78f51da3f4  vmovaps xmm1, [rsp+0x10]
00007b78f51da3fa  vmovaps xmm2, [rsp+0x20]
00007b78f51da400  vmovaps xmm3, [rsp+0x30]
00007b78f51da406  vmovaps xmm4, [rsp+0x40]
00007b78f51da40c  vmovaps xmm5, [rsp+0x50]
00007b78f51da412  vmovaps xmm6, [rsp+0x60]
00007b78f51da418  vmovaps xmm7, [rsp+0x70]
00007b78f51da41e  vmovaps xmm8, [rsp+0x80]
00007b78f51da427  vmovaps xmm9, [rsp+0x90]
00007b78f51da430  vmovaps xmm10, [rsp+0xA0]
00007b78f51da439  vmovaps xmm11, [rsp+0xB0]
00007b78f51da442  vmovaps xmm13, [rsp+0xC0]
00007b78f51da44b  vmovaps xmm14, [rsp+0xD0]
00007b78f51da454  vmovaps xmm15, [rsp+0xE0]
00007b78f51da45d  add rsp, 0xF0
00007b78f51da464  pop r11
00007b78f51da466  pop r10
00007b78f51da468  pop r9
00007b78f51da46a  pop r8
00007b78f51da46c  pop rsi
00007b78f51da46d  pop rdi
00007b78f51da46e  pop rdx
00007b78f51da46f  pop rcx
00007b78f51da470  pop rax
00007b78f51da471  add rsp, 0x08
00007b78f51da475  jmp 0x00007B78F51D6441
00007b78f51da47a  sub rsp, 0x08
00007b78f51da47e  push rax
00007b78f51da47f  push rcx
00007b78f51da480  push rdx
00007b78f51da481  push rdi
00007b78f51da482  push rsi
00007b78f51da483  push r8
00007b78f51da485  push r9
00007b78f51da487  push r10
00007b78f51da489  push r11
00007b78f51da48b  sub rsp, 0xF0
00007b78f51da492  vmovaps [rsp], xmm0
00007b78f51da497  vmovaps [rsp+0x10], xmm1
00007b78f51da49d  vmovaps [rsp+0x20], xmm2
00007b78f51da4a3  vmovaps [rsp+0x30], xmm3
00007b78f51da4a9  vmovaps [rsp+0x40], xmm4
00007b78f51da4af  vmovaps [rsp+0x50], xmm5
00007b78f51da4b5  vmovaps [rsp+0x60], xmm6
00007b78f51da4bb  vmovaps [rsp+0x70], xmm7
00007b78f51da4c1  vmovaps [rsp+0x80], xmm8
00007b78f51da4ca  vmovaps [rsp+0x90], xmm9
00007b78f51da4d3  vmovaps [rsp+0xA0], xmm10
00007b78f51da4dc  vmovaps [rsp+0xB0], xmm11
00007b78f51da4e5  vmovaps [rsp+0xC0], xmm12
00007b78f51da4ee  vmovaps [rsp+0xD0], xmm14
00007b78f51da4f7  vmovaps [rsp+0xE0], xmm15
00007b78f51da500  sub rsp, 0x30
00007b78f51da504  movaps [rsp], xmm13
00007b78f51da509  movaps [rsp+0x10], xmm15
00007b78f51da50f  movaps [rsp+0x20], xmm8
00007b78f51da515  lea rdi, [rsp]
00007b78f51da519  mov esi, 0x00
00007b78f51da51e  mov rax, 0x597478C09530
00007b78f51da528  call rax
00007b78f51da52a  movaps xmm13, [rsp]
00007b78f51da52f  add rsp, 0x30
00007b78f51da533  vmovaps xmm0, [rsp]
00007b78f51da538  vmovaps xmm1, [rsp+0x10]
00007b78f51da53e  vmovaps xmm2, [rsp+0x20]
00007b78f51da544  vmovaps xmm3, [rsp+0x30]
00007b78f51da54a  vmovaps xmm4, [rsp+0x40]
00007b78f51da550  vmovaps xmm5, [rsp+0x50]
00007b78f51da556  vmovaps xmm6, [rsp+0x60]
00007b78f51da55c  vmovaps xmm7, [rsp+0x70]
00007b78f51da562  vmovaps xmm8, [rsp+0x80]
00007b78f51da56b  vmovaps xmm9, [rsp+0x90]
00007b78f51da574  vmovaps xmm10, [rsp+0xA0]
00007b78f51da57d  vmovaps xmm11, [rsp+0xB0]
00007b78f51da586  vmovaps xmm12, [rsp+0xC0]
00007b78f51da58f  vmovaps xmm14, [rsp+0xD0]
00007b78f51da598  vmovaps xmm15, [rsp+0xE0]
00007b78f51da5a1  add rsp, 0xF0
00007b78f51da5a8  pop r11
00007b78f51da5aa  pop r10
00007b78f51da5ac  pop r9
00007b78f51da5ae  pop r8
00007b78f51da5b0  pop rsi
00007b78f51da5b1  pop rdi
00007b78f51da5b2  pop rdx
00007b78f51da5b3  pop rcx
00007b78f51da5b4  pop rax
00007b78f51da5b5  add rsp, 0x08
00007b78f51da5b9  jmp 0x00007B78F51D645C
00007b78f51da5be  sub rsp, 0x08
00007b78f51da5c2  push rax
00007b78f51da5c3  push rcx
00007b78f51da5c4  push rdx
00007b78f51da5c5  push rdi
00007b78f51da5c6  push rsi
00007b78f51da5c7  push r8
00007b78f51da5c9  push r9
00007b78f51da5cb  push r10
00007b78f51da5cd  push r11
00007b78f51da5cf  sub rsp, 0xF0
00007b78f51da5d6  vmovaps [rsp], xmm0
00007b78f51da5db  vmovaps [rsp+0x10], xmm1
00007b78f51da5e1  vmovaps [rsp+0x20], xmm2
00007b78f51da5e7  vmovaps [rsp+0x30], xmm3
00007b78f51da5ed  vmovaps [rsp+0x40], xmm4
00007b78f51da5f3  vmovaps [rsp+0x50], xmm5
00007b78f51da5f9  vmovaps [rsp+0x60], xmm6
00007b78f51da5ff  vmovaps [rsp+0x70], xmm7
00007b78f51da605  vmovaps [rsp+0x80], xmm9
00007b78f51da60e  vmovaps [rsp+0x90], xmm10
00007b78f51da617  vmovaps [rsp+0xA0], xmm11
00007b78f51da620  vmovaps [rsp+0xB0], xmm12
00007b78f51da629  vmovaps [rsp+0xC0], xmm13
00007b78f51da632  vmovaps [rsp+0xD0], xmm14
00007b78f51da63b  vmovaps [rsp+0xE0], xmm15
00007b78f51da644  sub rsp, 0x30
00007b78f51da648  movaps [rsp], xmm8
00007b78f51da64d  movaps [rsp+0x10], xmm15
00007b78f51da653  movaps [rsp+0x20], xmm9
00007b78f51da659  lea rdi, [rsp]
00007b78f51da65d  mov esi, 0x00
00007b78f51da662  mov rax, 0x597478C09530
00007b78f51da66c  call rax
00007b78f51da66e  movaps xmm8, [rsp]
00007b78f51da673  add rsp, 0x30
00007b78f51da677  vmovaps xmm0, [rsp]
00007b78f51da67c  vmovaps xmm1, [rsp+0x10]
00007b78f51da682  vmovaps xmm2, [rsp+0x20]
00007b78f51da688  vmovaps xmm3, [rsp+0x30]
00007b78f51da68e  vmovaps xmm4, [rsp+0x40]
00007b78f51da694  vmovaps xmm5, [rsp+0x50]
00007b78f51da69a  vmovaps xmm6, [rsp+0x60]
00007b78f51da6a0  vmovaps xmm7, [rsp+0x70]
00007b78f51da6a6  vmovaps xmm9, [rsp+0x80]
00007b78f51da6af  vmovaps xmm10, [rsp+0x90]
00007b78f51da6b8  vmovaps xmm11, [rsp+0xA0]
00007b78f51da6c1  vmovaps xmm12, [rsp+0xB0]
00007b78f51da6ca  vmovaps xmm13, [rsp+0xC0]
00007b78f51da6d3  vmovaps xmm14, [rsp+0xD0]
00007b78f51da6dc  vmovaps xmm15, [rsp+0xE0]
00007b78f51da6e5  add rsp, 0xF0
00007b78f51da6ec  pop r11
00007b78f51da6ee  pop r10
00007b78f51da6f0  pop r9
00007b78f51da6f2  pop r8
00007b78f51da6f4  pop rsi
00007b78f51da6f5  pop rdi
00007b78f51da6f6  pop rdx
00007b78f51da6f7  pop rcx
00007b78f51da6f8  pop rax
00007b78f51da6f9  add rsp, 0x08
00007b78f51da6fd  jmp 0x00007B78F51D648A
00007b78f51da702  sub rsp, 0x08
00007b78f51da706  push rax
00007b78f51da707  push rcx
00007b78f51da708  push rdx
00007b78f51da709  push rdi
00007b78f51da70a  push rsi
00007b78f51da70b  push r8
00007b78f51da70d  push r9
00007b78f51da70f  push r10
00007b78f51da711  push r11
00007b78f51da713  sub rsp, 0xF0
00007b78f51da71a  vmovaps [rsp], xmm0
00007b78f51da71f  vmovaps [rsp+0x10], xmm1
00007b78f51da725  vmovaps [rsp+0x20], xmm2
00007b78f51da72b  vmovaps [rsp+0x30], xmm3
00007b78f51da731  vmovaps [rsp+0x40], xmm4
00007b78f51da737  vmovaps [rsp+0x50], xmm5
00007b78f51da73d  vmovaps [rsp+0x60], xmm6
00007b78f51da743  vmovaps [rsp+0x70], xmm7
00007b78f51da749  vmovaps [rsp+0x80], xmm8
00007b78f51da752  vmovaps [rsp+0x90], xmm9
00007b78f51da75b  vmovaps [rsp+0xA0], xmm10
00007b78f51da764  vmovaps [rsp+0xB0], xmm11
00007b78f51da76d  vmovaps [rsp+0xC0], xmm12
00007b78f51da776  vmovaps [rsp+0xD0], xmm13
00007b78f51da77f  vmovaps [rsp+0xE0], xmm14
00007b78f51da788  sub rsp, 0x30
00007b78f51da78c  movaps [rsp], xmm15
00007b78f51da791  movaps [rsp+0x10], xmm11
00007b78f51da797  movaps [rsp+0x20], xmm6
00007b78f51da79c  lea rdi, [rsp]
00007b78f51da7a0  mov esi, 0x00
00007b78f51da7a5  mov rax, 0x597478C09530
00007b78f51da7af  call rax
00007b78f51da7b1  movaps xmm15, [rsp]
00007b78f51da7b6  add rsp, 0x30
00007b78f51da7ba  vmovaps xmm0, [rsp]
00007b78f51da7bf  vmovaps xmm1, [rsp+0x10]
00007b78f51da7c5  vmovaps xmm2, [rsp+0x20]
00007b78f51da7cb  vmovaps xmm3, [rsp+0x30]
00007b78f51da7d1  vmovaps xmm4, [rsp+0x40]
00007b78f51da7d7  vmovaps xmm5, [rsp+0x50]
00007b78f51da7dd  vmovaps xmm6, [rsp+0x60]
00007b78f51da7e3  vmovaps xmm7, [rsp+0x70]
00007b78f51da7e9  vmovaps xmm8, [rsp+0x80]
00007b78f51da7f2  vmovaps xmm9, [rsp+0x90]
00007b78f51da7fb  vmovaps xmm10, [rsp+0xA0]
00007b78f51da804  vmovaps xmm11, [rsp+0xB0]
00007b78f51da80d  vmovaps xmm12, [rsp+0xC0]
00007b78f51da816  vmovaps xmm13, [rsp+0xD0]
00007b78f51da81f  vmovaps xmm14, [rsp+0xE0]
00007b78f51da828  add rsp, 0xF0
00007b78f51da82f  pop r11
00007b78f51da831  pop r10
00007b78f51da833  pop r9
00007b78f51da835  pop r8
00007b78f51da837  pop rsi
00007b78f51da838  pop rdi
00007b78f51da839  pop rdx
00007b78f51da83a  pop rcx
00007b78f51da83b  pop rax
00007b78f51da83c  add rsp, 0x08
00007b78f51da840  jmp 0x00007B78F51D64A5
00007b78f51da845  sub rsp, 0x08
00007b78f51da849  push rax
00007b78f51da84a  push rcx
00007b78f51da84b  push rdx
00007b78f51da84c  push rdi
00007b78f51da84d  push rsi
00007b78f51da84e  push r8
00007b78f51da850  push r9
00007b78f51da852  push r10
00007b78f51da854  push r11
00007b78f51da856  sub rsp, 0xF0
00007b78f51da85d  vmovaps [rsp], xmm0
00007b78f51da862  vmovaps [rsp+0x10], xmm1
00007b78f51da868  vmovaps [rsp+0x20], xmm2
00007b78f51da86e  vmovaps [rsp+0x30], xmm3
00007b78f51da874  vmovaps [rsp+0x40], xmm4
00007b78f51da87a  vmovaps [rsp+0x50], xmm5
00007b78f51da880  vmovaps [rsp+0x60], xmm6
00007b78f51da886  vmovaps [rsp+0x70], xmm8
00007b78f51da88c  vmovaps [rsp+0x80], xmm9
00007b78f51da895  vmovaps [rsp+0x90], xmm10
00007b78f51da89e  vmovaps [rsp+0xA0], xmm11
00007b78f51da8a7  vmovaps [rsp+0xB0], xmm12
00007b78f51da8b0  vmovaps [rsp+0xC0], xmm13
00007b78f51da8b9  vmovaps [rsp+0xD0], xmm14
00007b78f51da8c2  vmovaps [rsp+0xE0], xmm15
00007b78f51da8cb  sub rsp, 0x30
00007b78f51da8cf  movaps [rsp], xmm7
00007b78f51da8d3  movaps [rsp+0x10], xmm11
00007b78f51da8d9  movaps [rsp+0x20], xmm9
00007b78f51da8df  lea rdi, [rsp]
00007b78f51da8e3  mov esi, 0x00
00007b78f51da8e8  mov rax, 0x597478C09530
00007b78f51da8f2  call rax
00007b78f51da8f4  movaps xmm7, [rsp]
00007b78f51da8f8  add rsp, 0x30
00007b78f51da8fc  vmovaps xmm0, [rsp]
00007b78f51da901  vmovaps xmm1, [rsp+0x10]
00007b78f51da907  vmovaps xmm2, [rsp+0x20]
00007b78f51da90d  vmovaps xmm3, [rsp+0x30]
00007b78f51da913  vmovaps xmm4, [rsp+0x40]
00007b78f51da919  vmovaps xmm5, [rsp+0x50]
00007b78f51da91f  vmovaps xmm6, [rsp+0x60]
00007b78f51da925  vmovaps xmm8, [rsp+0x70]
00007b78f51da92b  vmovaps xmm9, [rsp+0x80]
00007b78f51da934  vmovaps xmm10, [rsp+0x90]
00007b78f51da93d  vmovaps xmm11, [rsp+0xA0]
00007b78f51da946  vmovaps xmm12, [rsp+0xB0]
00007b78f51da94f  vmovaps xmm13, [rsp+0xC0]
00007b78f51da958  vmovaps xmm14, [rsp+0xD0]
00007b78f51da961  vmovaps xmm15, [rsp+0xE0]
00007b78f51da96a  add rsp, 0xF0
00007b78f51da971  pop r11
00007b78f51da973  pop r10
00007b78f51da975  pop r9
00007b78f51da977  pop r8
00007b78f51da979  pop rsi
00007b78f51da97a  pop rdi
00007b78f51da97b  pop rdx
00007b78f51da97c  pop rcx
00007b78f51da97d  pop rax
00007b78f51da97e  add rsp, 0x08
00007b78f51da982  jmp 0x00007B78F51D64D2
00007b78f51da987  sub rsp, 0x08
00007b78f51da98b  push rax
00007b78f51da98c  push rcx
00007b78f51da98d  push rdx
00007b78f51da98e  push rdi
00007b78f51da98f  push rsi
00007b78f51da990  push r8
00007b78f51da992  push r9
00007b78f51da994  push r10
00007b78f51da996  push r11
00007b78f51da998  sub rsp, 0xF0
00007b78f51da99f  vmovaps [rsp], xmm0
00007b78f51da9a4  vmovaps [rsp+0x10], xmm1
00007b78f51da9aa  vmovaps [rsp+0x20], xmm2
00007b78f51da9b0  vmovaps [rsp+0x30], xmm3
00007b78f51da9b6  vmovaps [rsp+0x40], xmm4
00007b78f51da9bc  vmovaps [rsp+0x50], xmm5
00007b78f51da9c2  vmovaps [rsp+0x60], xmm6
00007b78f51da9c8  vmovaps [rsp+0x70], xmm7
00007b78f51da9ce  vmovaps [rsp+0x80], xmm8
00007b78f51da9d7  vmovaps [rsp+0x90], xmm9
00007b78f51da9e0  vmovaps [rsp+0xA0], xmm10
00007b78f51da9e9  vmovaps [rsp+0xB0], xmm12
00007b78f51da9f2  vmovaps [rsp+0xC0], xmm13
00007b78f51da9fb  vmovaps [rsp+0xD0], xmm14
00007b78f51daa04  vmovaps [rsp+0xE0], xmm15
00007b78f51daa0d  sub rsp, 0x30
00007b78f51daa11  movaps [rsp], xmm11
00007b78f51daa16  movaps [rsp+0x10], xmm10
00007b78f51daa1c  movaps [rsp+0x20], xmm14
00007b78f51daa22  lea rdi, [rsp]
00007b78f51daa26  mov esi, 0x00
00007b78f51daa2b  mov rax, 0x597478C09530
00007b78f51daa35  call rax
00007b78f51daa37  movaps xmm11, [rsp]
00007b78f51daa3c  add rsp, 0x30
00007b78f51daa40  vmovaps xmm0, [rsp]
00007b78f51daa45  vmovaps xmm1, [rsp+0x10]
00007b78f51daa4b  vmovaps xmm2, [rsp+0x20]
00007b78f51daa51  vmovaps xmm3, [rsp+0x30]
00007b78f51daa57  vmovaps xmm4, [rsp+0x40]
00007b78f51daa5d  vmovaps xmm5, [rsp+0x50]
00007b78f51daa63  vmovaps xmm6, [rsp+0x60]
00007b78f51daa69  vmovaps xmm7, [rsp+0x70]
00007b78f51daa6f  vmovaps xmm8, [rsp+0x80]
00007b78f51daa78  vmovaps xmm9, [rsp+0x90]
00007b78f51daa81  vmovaps xmm10, [rsp+0xA0]
00007b78f51daa8a  vmovaps xmm12, [rsp+0xB0]
00007b78f51daa93  vmovaps xmm13, [rsp+0xC0]
00007b78f51daa9c  vmovaps xmm14, [rsp+0xD0]
00007b78f51daaa5  vmovaps xmm15, [rsp+0xE0]
00007b78f51daaae  add rsp, 0xF0
00007b78f51daab5  pop r11
00007b78f51daab7  pop r10
00007b78f51daab9  pop r9
00007b78f51daabb  pop r8
00007b78f51daabd  pop rsi
00007b78f51daabe  pop rdi
00007b78f51daabf  pop rdx
00007b78f51daac0  pop rcx
00007b78f51daac1  pop rax
00007b78f51daac2  add rsp, 0x08
00007b78f51daac6  jmp 0x00007B78F51D64ED
00007b78f51daacb  call 0x00007B78F50E45A0
00007b78f51daad0  jmp 0x00007B78F51D64F7
00007b78f51daad5  sub rsp, 0x08
00007b78f51daad9  push rax
00007b78f51daada  push rcx
00007b78f51daadb  push rdx
00007b78f51daadc  push rdi
00007b78f51daadd  push rsi
00007b78f51daade  push r8
00007b78f51daae0  push r9
00007b78f51daae2  push r10
00007b78f51daae4  push r11
00007b78f51daae6  sub rsp, 0xF0
00007b78f51daaed  vmovaps [rsp], xmm0
00007b78f51daaf2  vmovaps [rsp+0x10], xmm1
00007b78f51daaf8  vmovaps [rsp+0x20], xmm2
00007b78f51daafe  vmovaps [rsp+0x30], xmm3
00007b78f51dab04  vmovaps [rsp+0x40], xmm4
00007b78f51dab0a  vmovaps [rsp+0x50], xmm5
00007b78f51dab10  vmovaps [rsp+0x60], xmm6
00007b78f51dab16  vmovaps [rsp+0x70], xmm7
00007b78f51dab1c  vmovaps [rsp+0x80], xmm8
00007b78f51dab25  vmovaps [rsp+0x90], xmm9
00007b78f51dab2e  vmovaps [rsp+0xA0], xmm11
00007b78f51dab37  vmovaps [rsp+0xB0], xmm12
00007b78f51dab40  vmovaps [rsp+0xC0], xmm13
00007b78f51dab49  vmovaps [rsp+0xD0], xmm14
00007b78f51dab52  vmovaps [rsp+0xE0], xmm15
00007b78f51dab5b  sub rsp, 0x30
00007b78f51dab5f  movaps [rsp], xmm10
00007b78f51dab64  movaps [rsp+0x10], xmm1
00007b78f51dab69  movaps [rsp+0x20], xmm12
00007b78f51dab6f  lea rdi, [rsp]
00007b78f51dab73  mov esi, 0x00
00007b78f51dab78  mov rax, 0x597478C09530
00007b78f51dab82  call rax
00007b78f51dab84  movaps xmm10, [rsp]
00007b78f51dab89  add rsp, 0x30
00007b78f51dab8d  vmovaps xmm0, [rsp]
00007b78f51dab92  vmovaps xmm1, [rsp+0x10]
00007b78f51dab98  vmovaps xmm2, [rsp+0x20]
00007b78f51dab9e  vmovaps xmm3, [rsp+0x30]
00007b78f51daba4  vmovaps xmm4, [rsp+0x40]
00007b78f51dabaa  vmovaps xmm5, [rsp+0x50]
00007b78f51dabb0  vmovaps xmm6, [rsp+0x60]
00007b78f51dabb6  vmovaps xmm7, [rsp+0x70]
00007b78f51dabbc  vmovaps xmm8, [rsp+0x80]
00007b78f51dabc5  vmovaps xmm9, [rsp+0x90]
00007b78f51dabce  vmovaps xmm11, [rsp+0xA0]
00007b78f51dabd7  vmovaps xmm12, [rsp+0xB0]
00007b78f51dabe0  vmovaps xmm13, [rsp+0xC0]
00007b78f51dabe9  vmovaps xmm14, [rsp+0xD0]
00007b78f51dabf2  vmovaps xmm15, [rsp+0xE0]
00007b78f51dabfb  add rsp, 0xF0
00007b78f51dac02  pop r11
00007b78f51dac04  pop r10
00007b78f51dac06  pop r9
00007b78f51dac08  pop r8
00007b78f51dac0a  pop rsi
00007b78f51dac0b  pop rdi
00007b78f51dac0c  pop rdx
00007b78f51dac0d  pop rcx
00007b78f51dac0e  pop rax
00007b78f51dac0f  add rsp, 0x08
00007b78f51dac13  jmp 0x00007B78F51D651A
00007b78f51dac18  sub rsp, 0x08
00007b78f51dac1c  push rax
00007b78f51dac1d  push rcx
00007b78f51dac1e  push rdx
00007b78f51dac1f  push rdi
00007b78f51dac20  push rsi
00007b78f51dac21  push r8
00007b78f51dac23  push r9
00007b78f51dac25  push r10
00007b78f51dac27  push r11
00007b78f51dac29  sub rsp, 0xF0
00007b78f51dac30  vmovaps [rsp], xmm0
00007b78f51dac35  vmovaps [rsp+0x10], xmm1
00007b78f51dac3b  vmovaps [rsp+0x20], xmm2
00007b78f51dac41  vmovaps [rsp+0x30], xmm3
00007b78f51dac47  vmovaps [rsp+0x40], xmm4
00007b78f51dac4d  vmovaps [rsp+0x50], xmm5
00007b78f51dac53  vmovaps [rsp+0x60], xmm6
00007b78f51dac59  vmovaps [rsp+0x70], xmm7
00007b78f51dac5f  vmovaps [rsp+0x80], xmm8
00007b78f51dac68  vmovaps [rsp+0x90], xmm9
00007b78f51dac71  vmovaps [rsp+0xA0], xmm10
00007b78f51dac7a  vmovaps [rsp+0xB0], xmm11
00007b78f51dac83  vmovaps [rsp+0xC0], xmm13
00007b78f51dac8c  vmovaps [rsp+0xD0], xmm14
00007b78f51dac95  vmovaps [rsp+0xE0], xmm15
00007b78f51dac9e  sub rsp, 0x30
00007b78f51daca2  movaps [rsp], xmm12
00007b78f51daca7  movaps [rsp+0x10], xmm14
00007b78f51dacad  movaps [rsp+0x20], xmm1
00007b78f51dacb2  lea rdi, [rsp]
00007b78f51dacb6  mov esi, 0x00
00007b78f51dacbb  mov rax, 0x597478C09530
00007b78f51dacc5  call rax
00007b78f51dacc7  movaps xmm12, [rsp]
00007b78f51daccc  add rsp, 0x30
00007b78f51dacd0  vmovaps xmm0, [rsp]
00007b78f51dacd5  vmovaps xmm1, [rsp+0x10]
00007b78f51dacdb  vmovaps xmm2, [rsp+0x20]
00007b78f51dace1  vmovaps xmm3, [rsp+0x30]
00007b78f51dace7  vmovaps xmm4, [rsp+0x40]
00007b78f51daced  vmovaps xmm5, [rsp+0x50]
00007b78f51dacf3  vmovaps xmm6, [rsp+0x60]
00007b78f51dacf9  vmovaps xmm7, [rsp+0x70]
00007b78f51dacff  vmovaps xmm8, [rsp+0x80]
00007b78f51dad08  vmovaps xmm9, [rsp+0x90]
00007b78f51dad11  vmovaps xmm10, [rsp+0xA0]
00007b78f51dad1a  vmovaps xmm11, [rsp+0xB0]
00007b78f51dad23  vmovaps xmm13, [rsp+0xC0]
00007b78f51dad2c  vmovaps xmm14, [rsp+0xD0]
00007b78f51dad35  vmovaps xmm15, [rsp+0xE0]
00007b78f51dad3e  add rsp, 0xF0
00007b78f51dad45  pop r11
00007b78f51dad47  pop r10
00007b78f51dad49  pop r9
00007b78f51dad4b  pop r8
00007b78f51dad4d  pop rsi
00007b78f51dad4e  pop rdi
00007b78f51dad4f  pop rdx
00007b78f51dad50  pop rcx
00007b78f51dad51  pop rax
00007b78f51dad52  add rsp, 0x08
00007b78f51dad56  jmp 0x00007B78F51D6549
00007b78f51dad5b  sub rsp, 0x08
00007b78f51dad5f  push rax
00007b78f51dad60  push rcx
00007b78f51dad61  push rdx
00007b78f51dad62  push rdi
00007b78f51dad63  push rsi
00007b78f51dad64  push r8
00007b78f51dad66  push r9
00007b78f51dad68  push r10
00007b78f51dad6a  push r11
00007b78f51dad6c  sub rsp, 0xF0
00007b78f51dad73  vmovaps [rsp], xmm0
00007b78f51dad78  vmovaps [rsp+0x10], xmm1
00007b78f51dad7e  vmovaps [rsp+0x20], xmm2
00007b78f51dad84  vmovaps [rsp+0x30], xmm3
00007b78f51dad8a  vmovaps [rsp+0x40], xmm4
00007b78f51dad90  vmovaps [rsp+0x50], xmm5
00007b78f51dad96  vmovaps [rsp+0x60], xmm6
00007b78f51dad9c  vmovaps [rsp+0x70], xmm7
00007b78f51dada2  vmovaps [rsp+0x80], xmm8
00007b78f51dadab  vmovaps [rsp+0x90], xmm9
00007b78f51dadb4  vmovaps [rsp+0xA0], xmm10
00007b78f51dadbd  vmovaps [rsp+0xB0], xmm11
00007b78f51dadc6  vmovaps [rsp+0xC0], xmm12
00007b78f51dadcf  vmovaps [rsp+0xD0], xmm13
00007b78f51dadd8  vmovaps [rsp+0xE0], xmm15
00007b78f51dade1  sub rsp, 0x30
00007b78f51dade5  movaps [rsp], xmm14
00007b78f51dadea  movaps [rsp+0x10], xmm9
00007b78f51dadf0  movaps [rsp+0x20], xmm1
00007b78f51dadf5  lea rdi, [rsp]
00007b78f51dadf9  mov esi, 0x00
00007b78f51dadfe  mov rax, 0x597478C09530
00007b78f51dae08  call rax
00007b78f51dae0a  movaps xmm14, [rsp]
00007b78f51dae0f  add rsp, 0x30
00007b78f51dae13  vmovaps xmm0, [rsp]
00007b78f51dae18  vmovaps xmm1, [rsp+0x10]
00007b78f51dae1e  vmovaps xmm2, [rsp+0x20]
00007b78f51dae24  vmovaps xmm3, [rsp+0x30]
00007b78f51dae2a  vmovaps xmm4, [rsp+0x40]
00007b78f51dae30  vmovaps xmm5, [rsp+0x50]
00007b78f51dae36  vmovaps xmm6, [rsp+0x60]
00007b78f51dae3c  vmovaps xmm7, [rsp+0x70]
00007b78f51dae42  vmovaps xmm8, [rsp+0x80]
00007b78f51dae4b  vmovaps xmm9, [rsp+0x90]
00007b78f51dae54  vmovaps xmm10, [rsp+0xA0]
00007b78f51dae5d  vmovaps xmm11, [rsp+0xB0]
00007b78f51dae66  vmovaps xmm12, [rsp+0xC0]
00007b78f51dae6f  vmovaps xmm13, [rsp+0xD0]
00007b78f51dae78  vmovaps xmm15, [rsp+0xE0]
00007b78f51dae81  add rsp, 0xF0
00007b78f51dae88  pop r11
00007b78f51dae8a  pop r10
00007b78f51dae8c  pop r9
00007b78f51dae8e  pop r8
00007b78f51dae90  pop rsi
00007b78f51dae91  pop rdi
00007b78f51dae92  pop rdx
00007b78f51dae93  pop rcx
00007b78f51dae94  pop rax
00007b78f51dae95  add rsp, 0x08
00007b78f51dae99  jmp 0x00007B78F51D6578
00007b78f51dae9e  sub rsp, 0x08
00007b78f51daea2  push rax
00007b78f51daea3  push rcx
00007b78f51daea4  push rdx
00007b78f51daea5  push rdi
00007b78f51daea6  push rsi
00007b78f51daea7  push r8
00007b78f51daea9  push r9
00007b78f51daeab  push r10
00007b78f51daead  push r11
00007b78f51daeaf  sub rsp, 0xF0
00007b78f51daeb6  vmovaps [rsp], xmm0
00007b78f51daebb  vmovaps [rsp+0x10], xmm2
00007b78f51daec1  vmovaps [rsp+0x20], xmm3
00007b78f51daec7  vmovaps [rsp+0x30], xmm4
00007b78f51daecd  vmovaps [rsp+0x40], xmm5
00007b78f51daed3  vmovaps [rsp+0x50], xmm6
00007b78f51daed9  vmovaps [rsp+0x60], xmm7
00007b78f51daedf  vmovaps [rsp+0x70], xmm8
00007b78f51daee5  vmovaps [rsp+0x80], xmm9
00007b78f51daeee  vmovaps [rsp+0x90], xmm10
00007b78f51daef7  vmovaps [rsp+0xA0], xmm11
00007b78f51daf00  vmovaps [rsp+0xB0], xmm12
00007b78f51daf09  vmovaps [rsp+0xC0], xmm13
00007b78f51daf12  vmovaps [rsp+0xD0], xmm14
00007b78f51daf1b  vmovaps [rsp+0xE0], xmm15
00007b78f51daf24  sub rsp, 0x30
00007b78f51daf28  movaps [rsp], xmm1
00007b78f51daf2c  movaps [rsp+0x10], xmm13
00007b78f51daf32  movaps [rsp+0x20], xmm8
00007b78f51daf38  lea rdi, [rsp]
00007b78f51daf3c  mov esi, 0x00
00007b78f51daf41  mov rax, 0x597478C09530
00007b78f51daf4b  call rax
00007b78f51daf4d  movaps xmm1, [rsp]
00007b78f51daf51  add rsp, 0x30
00007b78f51daf55  vmovaps xmm0, [rsp]
00007b78f51daf5a  vmovaps xmm2, [rsp+0x10]
00007b78f51daf60  vmovaps xmm3, [rsp+0x20]
00007b78f51daf66  vmovaps xmm4, [rsp+0x30]
00007b78f51daf6c  vmovaps xmm5, [rsp+0x40]
00007b78f51daf72  vmovaps xmm6, [rsp+0x50]
00007b78f51daf78  vmovaps xmm7, [rsp+0x60]
00007b78f51daf7e  vmovaps xmm8, [rsp+0x70]
00007b78f51daf84  vmovaps xmm9, [rsp+0x80]
00007b78f51daf8d  vmovaps xmm10, [rsp+0x90]
00007b78f51daf96  vmovaps xmm11, [rsp+0xA0]
00007b78f51daf9f  vmovaps xmm12, [rsp+0xB0]
00007b78f51dafa8  vmovaps xmm13, [rsp+0xC0]
00007b78f51dafb1  vmovaps xmm14, [rsp+0xD0]
00007b78f51dafba  vmovaps xmm15, [rsp+0xE0]
00007b78f51dafc3  add rsp, 0xF0
00007b78f51dafca  pop r11
00007b78f51dafcc  pop r10
00007b78f51dafce  pop r9
00007b78f51dafd0  pop r8
00007b78f51dafd2  pop rsi
00007b78f51dafd3  pop rdi
00007b78f51dafd4  pop rdx
00007b78f51dafd5  pop rcx
00007b78f51dafd6  pop rax
00007b78f51dafd7  add rsp, 0x08
00007b78f51dafdb  jmp 0x00007B78F51D659A
00007b78f51dafe0  call 0x00007B78F500C260
00007b78f51dafe5  jmp 0x00007B78F51D65A8
00007b78f51dafea  call 0x00007B78F50DE950
00007b78f51dafef  jmp 0x00007B78F51D65B2
00007b78f51daff4  sub rsp, 0x08
00007b78f51daff8  push rax
00007b78f51daff9  push rcx
00007b78f51daffa  push rdx
00007b78f51daffb  push rdi
00007b78f51daffc  push rsi
00007b78f51daffd  push r8
00007b78f51dafff  push r9
00007b78f51db001  push r10
00007b78f51db003  push r11
00007b78f51db005  sub rsp, 0xF0
00007b78f51db00c  vmovaps [rsp], xmm0
00007b78f51db011  vmovaps [rsp+0x10], xmm1
00007b78f51db017  vmovaps [rsp+0x20], xmm2
00007b78f51db01d  vmovaps [rsp+0x30], xmm3
00007b78f51db023  vmovaps [rsp+0x40], xmm4
00007b78f51db029  vmovaps [rsp+0x50], xmm5
00007b78f51db02f  vmovaps [rsp+0x60], xmm6
00007b78f51db035  vmovaps [rsp+0x70], xmm7
00007b78f51db03b  vmovaps [rsp+0x80], xmm9
00007b78f51db044  vmovaps [rsp+0x90], xmm10
00007b78f51db04d  vmovaps [rsp+0xA0], xmm11
00007b78f51db056  vmovaps [rsp+0xB0], xmm12
00007b78f51db05f  vmovaps [rsp+0xC0], xmm13
00007b78f51db068  vmovaps [rsp+0xD0], xmm14
00007b78f51db071  vmovaps [rsp+0xE0], xmm15
00007b78f51db07a  sub rsp, 0x30
00007b78f51db07e  movaps [rsp], xmm8
00007b78f51db083  movaps [rsp+0x10], xmm15
00007b78f51db089  movaps [rsp+0x20], xmm7
00007b78f51db08e  lea rdi, [rsp]
00007b78f51db092  mov esi, 0x00
00007b78f51db097  mov rax, 0x597478C09530
00007b78f51db0a1  call rax
00007b78f51db0a3  movaps xmm8, [rsp]
00007b78f51db0a8  add rsp, 0x30
00007b78f51db0ac  vmovaps xmm0, [rsp]
00007b78f51db0b1  vmovaps xmm1, [rsp+0x10]
00007b78f51db0b7  vmovaps xmm2, [rsp+0x20]
00007b78f51db0bd  vmovaps xmm3, [rsp+0x30]
00007b78f51db0c3  vmovaps xmm4, [rsp+0x40]
00007b78f51db0c9  vmovaps xmm5, [rsp+0x50]
00007b78f51db0cf  vmovaps xmm6, [rsp+0x60]
00007b78f51db0d5  vmovaps xmm7, [rsp+0x70]
00007b78f51db0db  vmovaps xmm9, [rsp+0x80]
00007b78f51db0e4  vmovaps xmm10, [rsp+0x90]
00007b78f51db0ed  vmovaps xmm11, [rsp+0xA0]
00007b78f51db0f6  vmovaps xmm12, [rsp+0xB0]
00007b78f51db0ff  vmovaps xmm13, [rsp+0xC0]
00007b78f51db108  vmovaps xmm14, [rsp+0xD0]
00007b78f51db111  vmovaps xmm15, [rsp+0xE0]
00007b78f51db11a  add rsp, 0xF0
00007b78f51db121  pop r11
00007b78f51db123  pop r10
00007b78f51db125  pop r9
00007b78f51db127  pop r8
00007b78f51db129  pop rsi
00007b78f51db12a  pop rdi
00007b78f51db12b  pop rdx
00007b78f51db12c  pop rcx
00007b78f51db12d  pop rax
00007b78f51db12e  add rsp, 0x08
00007b78f51db132  jmp 0x00007B78F51D65D4
00007b78f51db137  sub rsp, 0x08
00007b78f51db13b  push rax
00007b78f51db13c  push rcx
00007b78f51db13d  push rdx
00007b78f51db13e  push rdi
00007b78f51db13f  push rsi
00007b78f51db140  push r8
00007b78f51db142  push r9
00007b78f51db144  push r10
00007b78f51db146  push r11
00007b78f51db148  sub rsp, 0xF0
00007b78f51db14f  vmovaps [rsp], xmm0
00007b78f51db154  vmovaps [rsp+0x10], xmm1
00007b78f51db15a  vmovaps [rsp+0x20], xmm2
00007b78f51db160  vmovaps [rsp+0x30], xmm3
00007b78f51db166  vmovaps [rsp+0x40], xmm4
00007b78f51db16c  vmovaps [rsp+0x50], xmm5
00007b78f51db172  vmovaps [rsp+0x60], xmm6
00007b78f51db178  vmovaps [rsp+0x70], xmm8
00007b78f51db17e  vmovaps [rsp+0x80], xmm9
00007b78f51db187  vmovaps [rsp+0x90], xmm10
00007b78f51db190  vmovaps [rsp+0xA0], xmm11
00007b78f51db199  vmovaps [rsp+0xB0], xmm12
00007b78f51db1a2  vmovaps [rsp+0xC0], xmm13
00007b78f51db1ab  vmovaps [rsp+0xD0], xmm14
00007b78f51db1b4  vmovaps [rsp+0xE0], xmm15
00007b78f51db1bd  sub rsp, 0x30
00007b78f51db1c1  movaps [rsp], xmm7
00007b78f51db1c5  movaps [rsp+0x10], xmm9
00007b78f51db1cb  movaps [rsp+0x20], xmm15
00007b78f51db1d1  lea rdi, [rsp]
00007b78f51db1d5  mov esi, 0x00
00007b78f51db1da  mov rax, 0x597478C09530
00007b78f51db1e4  call rax
00007b78f51db1e6  movaps xmm7, [rsp]
00007b78f51db1ea  add rsp, 0x30
00007b78f51db1ee  vmovaps xmm0, [rsp]
00007b78f51db1f3  vmovaps xmm1, [rsp+0x10]
00007b78f51db1f9  vmovaps xmm2, [rsp+0x20]
00007b78f51db1ff  vmovaps xmm3, [rsp+0x30]
00007b78f51db205  vmovaps xmm4, [rsp+0x40]
00007b78f51db20b  vmovaps xmm5, [rsp+0x50]
00007b78f51db211  vmovaps xmm6, [rsp+0x60]
00007b78f51db217  vmovaps xmm8, [rsp+0x70]
00007b78f51db21d  vmovaps xmm9, [rsp+0x80]
00007b78f51db226  vmovaps xmm10, [rsp+0x90]
00007b78f51db22f  vmovaps xmm11, [rsp+0xA0]
00007b78f51db238  vmovaps xmm12, [rsp+0xB0]
00007b78f51db241  vmovaps xmm13, [rsp+0xC0]
00007b78f51db24a  vmovaps xmm14, [rsp+0xD0]
00007b78f51db253  vmovaps xmm15, [rsp+0xE0]
00007b78f51db25c  add rsp, 0xF0
00007b78f51db263  pop r11
00007b78f51db265  pop r10
00007b78f51db267  pop r9
00007b78f51db269  pop r8
00007b78f51db26b  pop rsi
00007b78f51db26c  pop rdi
00007b78f51db26d  pop rdx
00007b78f51db26e  pop rcx
00007b78f51db26f  pop rax
00007b78f51db270  add rsp, 0x08
00007b78f51db274  jmp 0x00007B78F51D6601
00007b78f51db279  sub rsp, 0x08
00007b78f51db27d  push rax
00007b78f51db27e  push rcx
00007b78f51db27f  push rdx
00007b78f51db280  push rdi
00007b78f51db281  push rsi
00007b78f51db282  push r8
00007b78f51db284  push r9
00007b78f51db286  push r10
00007b78f51db288  push r11
00007b78f51db28a  sub rsp, 0xF0
00007b78f51db291  vmovaps [rsp], xmm0
00007b78f51db296  vmovaps [rsp+0x10], xmm1
00007b78f51db29c  vmovaps [rsp+0x20], xmm2
00007b78f51db2a2  vmovaps [rsp+0x30], xmm3
00007b78f51db2a8  vmovaps [rsp+0x40], xmm4
00007b78f51db2ae  vmovaps [rsp+0x50], xmm5
00007b78f51db2b4  vmovaps [rsp+0x60], xmm6
00007b78f51db2ba  vmovaps [rsp+0x70], xmm7
00007b78f51db2c0  vmovaps [rsp+0x80], xmm8
00007b78f51db2c9  vmovaps [rsp+0x90], xmm10
00007b78f51db2d2  vmovaps [rsp+0xA0], xmm11
00007b78f51db2db  vmovaps [rsp+0xB0], xmm12
00007b78f51db2e4  vmovaps [rsp+0xC0], xmm13
00007b78f51db2ed  vmovaps [rsp+0xD0], xmm14
00007b78f51db2f6  vmovaps [rsp+0xE0], xmm15
00007b78f51db2ff  sub rsp, 0x30
00007b78f51db303  movaps [rsp], xmm9
00007b78f51db308  movaps [rsp+0x10], xmm13
00007b78f51db30e  movaps [rsp+0x20], xmm15
00007b78f51db314  lea rdi, [rsp]
00007b78f51db318  mov esi, 0x00
00007b78f51db31d  mov rax, 0x597478C09530
00007b78f51db327  call rax
00007b78f51db329  movaps xmm9, [rsp]
00007b78f51db32e  add rsp, 0x30
00007b78f51db332  vmovaps xmm0, [rsp]
00007b78f51db337  vmovaps xmm1, [rsp+0x10]
00007b78f51db33d  vmovaps xmm2, [rsp+0x20]
00007b78f51db343  vmovaps xmm3, [rsp+0x30]
00007b78f51db349  vmovaps xmm4, [rsp+0x40]
00007b78f51db34f  vmovaps xmm5, [rsp+0x50]
00007b78f51db355  vmovaps xmm6, [rsp+0x60]
00007b78f51db35b  vmovaps xmm7, [rsp+0x70]
00007b78f51db361  vmovaps xmm8, [rsp+0x80]
00007b78f51db36a  vmovaps xmm10, [rsp+0x90]
00007b78f51db373  vmovaps xmm11, [rsp+0xA0]
00007b78f51db37c  vmovaps xmm12, [rsp+0xB0]
00007b78f51db385  vmovaps xmm13, [rsp+0xC0]
00007b78f51db38e  vmovaps xmm14, [rsp+0xD0]
00007b78f51db397  vmovaps xmm15, [rsp+0xE0]
00007b78f51db3a0  add rsp, 0xF0
00007b78f51db3a7  pop r11
00007b78f51db3a9  pop r10
00007b78f51db3ab  pop r9
00007b78f51db3ad  pop r8
00007b78f51db3af  pop rsi
00007b78f51db3b0  pop rdi
00007b78f51db3b1  pop rdx
00007b78f51db3b2  pop rcx
00007b78f51db3b3  pop rax
00007b78f51db3b4  add rsp, 0x08
00007b78f51db3b8  jmp 0x00007B78F51D662F
00007b78f51db3bd  sub rsp, 0x08
00007b78f51db3c1  push rax
00007b78f51db3c2  push rcx
00007b78f51db3c3  push rdx
00007b78f51db3c4  push rdi
00007b78f51db3c5  push rsi
00007b78f51db3c6  push r8
00007b78f51db3c8  push r9
00007b78f51db3ca  push r10
00007b78f51db3cc  push r11
00007b78f51db3ce  sub rsp, 0xF0
00007b78f51db3d5  vmovaps [rsp], xmm0
00007b78f51db3da  vmovaps [rsp+0x10], xmm1
00007b78f51db3e0  vmovaps [rsp+0x20], xmm2
00007b78f51db3e6  vmovaps [rsp+0x30], xmm3
00007b78f51db3ec  vmovaps [rsp+0x40], xmm4
00007b78f51db3f2  vmovaps [rsp+0x50], xmm5
00007b78f51db3f8  vmovaps [rsp+0x60], xmm6
00007b78f51db3fe  vmovaps [rsp+0x70], xmm7
00007b78f51db404  vmovaps [rsp+0x80], xmm8
00007b78f51db40d  vmovaps [rsp+0x90], xmm9
00007b78f51db416  vmovaps [rsp+0xA0], xmm10
00007b78f51db41f  vmovaps [rsp+0xB0], xmm11
00007b78f51db428  vmovaps [rsp+0xC0], xmm12
00007b78f51db431  vmovaps [rsp+0xD0], xmm13
00007b78f51db43a  vmovaps [rsp+0xE0], xmm14
00007b78f51db443  sub rsp, 0x30
00007b78f51db447  movaps [rsp], xmm15
00007b78f51db44c  movaps [rsp+0x10], xmm11
00007b78f51db452  movaps [rsp+0x20], xmm12
00007b78f51db458  lea rdi, [rsp]
00007b78f51db45c  mov esi, 0x00
00007b78f51db461  mov rax, 0x597478C09530
00007b78f51db46b  call rax
00007b78f51db46d  movaps xmm15, [rsp]
00007b78f51db472  add rsp, 0x30
00007b78f51db476  vmovaps xmm0, [rsp]
00007b78f51db47b  vmovaps xmm1, [rsp+0x10]
00007b78f51db481  vmovaps xmm2, [rsp+0x20]
00007b78f51db487  vmovaps xmm3, [rsp+0x30]
00007b78f51db48d  vmovaps xmm4, [rsp+0x40]
00007b78f51db493  vmovaps xmm5, [rsp+0x50]
00007b78f51db499  vmovaps xmm6, [rsp+0x60]
00007b78f51db49f  vmovaps xmm7, [rsp+0x70]
00007b78f51db4a5  vmovaps xmm8, [rsp+0x80]
00007b78f51db4ae  vmovaps xmm9, [rsp+0x90]
00007b78f51db4b7  vmovaps xmm10, [rsp+0xA0]
00007b78f51db4c0  vmovaps xmm11, [rsp+0xB0]
00007b78f51db4c9  vmovaps xmm12, [rsp+0xC0]
00007b78f51db4d2  vmovaps xmm13, [rsp+0xD0]
00007b78f51db4db  vmovaps xmm14, [rsp+0xE0]
00007b78f51db4e4  add rsp, 0xF0
00007b78f51db4eb  pop r11
00007b78f51db4ed  pop r10
00007b78f51db4ef  pop r9
00007b78f51db4f1  pop r8
00007b78f51db4f3  pop rsi
00007b78f51db4f4  pop rdi
00007b78f51db4f5  pop rdx
00007b78f51db4f6  pop rcx
00007b78f51db4f7  pop rax
00007b78f51db4f8  add rsp, 0x08
00007b78f51db4fc  jmp 0x00007B78F51D664A
00007b78f51db501  sub rsp, 0x08
00007b78f51db505  push rax
00007b78f51db506  push rcx
00007b78f51db507  push rdx
00007b78f51db508  push rdi
00007b78f51db509  push rsi
00007b78f51db50a  push r8
00007b78f51db50c  push r9
00007b78f51db50e  push r10
00007b78f51db510  push r11
00007b78f51db512  sub rsp, 0xF0
00007b78f51db519  vmovaps [rsp], xmm0
00007b78f51db51e  vmovaps [rsp+0x10], xmm1
00007b78f51db524  vmovaps [rsp+0x20], xmm2
00007b78f51db52a  vmovaps [rsp+0x30], xmm3
00007b78f51db530  vmovaps [rsp+0x40], xmm4
00007b78f51db536  vmovaps [rsp+0x50], xmm5
00007b78f51db53c  vmovaps [rsp+0x60], xmm6
00007b78f51db542  vmovaps [rsp+0x70], xmm7
00007b78f51db548  vmovaps [rsp+0x80], xmm8
00007b78f51db551  vmovaps [rsp+0x90], xmm9
00007b78f51db55a  vmovaps [rsp+0xA0], xmm10
00007b78f51db563  vmovaps [rsp+0xB0], xmm11
00007b78f51db56c  vmovaps [rsp+0xC0], xmm12
00007b78f51db575  vmovaps [rsp+0xD0], xmm14
00007b78f51db57e  vmovaps [rsp+0xE0], xmm15
00007b78f51db587  sub rsp, 0x30
00007b78f51db58b  movaps [rsp], xmm13
00007b78f51db590  movaps [rsp+0x10], xmm10
00007b78f51db596  movaps [rsp+0x20], xmm14
00007b78f51db59c  lea rdi, [rsp]
00007b78f51db5a0  mov esi, 0x00
00007b78f51db5a5  mov rax, 0x597478C09530
00007b78f51db5af  call rax
00007b78f51db5b1  movaps xmm13, [rsp]
00007b78f51db5b6  add rsp, 0x30
00007b78f51db5ba  vmovaps xmm0, [rsp]
00007b78f51db5bf  vmovaps xmm1, [rsp+0x10]
00007b78f51db5c5  vmovaps xmm2, [rsp+0x20]
00007b78f51db5cb  vmovaps xmm3, [rsp+0x30]
00007b78f51db5d1  vmovaps xmm4, [rsp+0x40]
00007b78f51db5d7  vmovaps xmm5, [rsp+0x50]
00007b78f51db5dd  vmovaps xmm6, [rsp+0x60]
00007b78f51db5e3  vmovaps xmm7, [rsp+0x70]
00007b78f51db5e9  vmovaps xmm8, [rsp+0x80]
00007b78f51db5f2  vmovaps xmm9, [rsp+0x90]
00007b78f51db5fb  vmovaps xmm10, [rsp+0xA0]
00007b78f51db604  vmovaps xmm11, [rsp+0xB0]
00007b78f51db60d  vmovaps xmm12, [rsp+0xC0]
00007b78f51db616  vmovaps xmm14, [rsp+0xD0]
00007b78f51db61f  vmovaps xmm15, [rsp+0xE0]
00007b78f51db628  add rsp, 0xF0
00007b78f51db62f  pop r11
00007b78f51db631  pop r10
00007b78f51db633  pop r9
00007b78f51db635  pop r8
00007b78f51db637  pop rsi
00007b78f51db638  pop rdi
00007b78f51db639  pop rdx
00007b78f51db63a  pop rcx
00007b78f51db63b  pop rax
00007b78f51db63c  add rsp, 0x08
00007b78f51db640  jmp 0x00007B78F51D666D
00007b78f51db645  sub rsp, 0x08
00007b78f51db649  push rax
00007b78f51db64a  push rcx
00007b78f51db64b  push rdx
00007b78f51db64c  push rdi
00007b78f51db64d  push rsi
00007b78f51db64e  push r8
00007b78f51db650  push r9
00007b78f51db652  push r10
00007b78f51db654  push r11
00007b78f51db656  sub rsp, 0xF0
00007b78f51db65d  vmovaps [rsp], xmm0
00007b78f51db662  vmovaps [rsp+0x10], xmm1
00007b78f51db668  vmovaps [rsp+0x20], xmm2
00007b78f51db66e  vmovaps [rsp+0x30], xmm3
00007b78f51db674  vmovaps [rsp+0x40], xmm4
00007b78f51db67a  vmovaps [rsp+0x50], xmm5
00007b78f51db680  vmovaps [rsp+0x60], xmm6
00007b78f51db686  vmovaps [rsp+0x70], xmm7
00007b78f51db68c  vmovaps [rsp+0x80], xmm8
00007b78f51db695  vmovaps [rsp+0x90], xmm9
00007b78f51db69e  vmovaps [rsp+0xA0], xmm10
00007b78f51db6a7  vmovaps [rsp+0xB0], xmm11
00007b78f51db6b0  vmovaps [rsp+0xC0], xmm12
00007b78f51db6b9  vmovaps [rsp+0xD0], xmm13
00007b78f51db6c2  vmovaps [rsp+0xE0], xmm15
00007b78f51db6cb  sub rsp, 0x30
00007b78f51db6cf  movaps [rsp], xmm14
00007b78f51db6d4  movaps [rsp+0x10], xmm1
00007b78f51db6d9  movaps [rsp+0x20], xmm7
00007b78f51db6de  lea rdi, [rsp]
00007b78f51db6e2  mov esi, 0x00
00007b78f51db6e7  mov rax, 0x597478C09530
00007b78f51db6f1  call rax
00007b78f51db6f3  movaps xmm14, [rsp]
00007b78f51db6f8  add rsp, 0x30
00007b78f51db6fc  vmovaps xmm0, [rsp]
00007b78f51db701  vmovaps xmm1, [rsp+0x10]
00007b78f51db707  vmovaps xmm2, [rsp+0x20]
00007b78f51db70d  vmovaps xmm3, [rsp+0x30]
00007b78f51db713  vmovaps xmm4, [rsp+0x40]
00007b78f51db719  vmovaps xmm5, [rsp+0x50]
00007b78f51db71f  vmovaps xmm6, [rsp+0x60]
00007b78f51db725  vmovaps xmm7, [rsp+0x70]
00007b78f51db72b  vmovaps xmm8, [rsp+0x80]
00007b78f51db734  vmovaps xmm9, [rsp+0x90]
00007b78f51db73d  vmovaps xmm10, [rsp+0xA0]
00007b78f51db746  vmovaps xmm11, [rsp+0xB0]
00007b78f51db74f  vmovaps xmm12, [rsp+0xC0]
00007b78f51db758  vmovaps xmm13, [rsp+0xD0]
00007b78f51db761  vmovaps xmm15, [rsp+0xE0]
00007b78f51db76a  add rsp, 0xF0
00007b78f51db771  pop r11
00007b78f51db773  pop r10
00007b78f51db775  pop r9
00007b78f51db777  pop r8
00007b78f51db779  pop rsi
00007b78f51db77a  pop rdi
00007b78f51db77b  pop rdx
00007b78f51db77c  pop rcx
00007b78f51db77d  pop rax
00007b78f51db77e  add rsp, 0x08
00007b78f51db782  jmp 0x00007B78F51D6690
00007b78f51db787  sub rsp, 0x08
00007b78f51db78b  push rax
00007b78f51db78c  push rcx
00007b78f51db78d  push rdx
00007b78f51db78e  push rdi
00007b78f51db78f  push rsi
00007b78f51db790  push r8
00007b78f51db792  push r9
00007b78f51db794  push r10
00007b78f51db796  push r11
00007b78f51db798  sub rsp, 0xF0
00007b78f51db79f  vmovaps [rsp], xmm0
00007b78f51db7a4  vmovaps [rsp+0x10], xmm2
00007b78f51db7aa  vmovaps [rsp+0x20], xmm3
00007b78f51db7b0  vmovaps [rsp+0x30], xmm4
00007b78f51db7b6  vmovaps [rsp+0x40], xmm5
00007b78f51db7bc  vmovaps [rsp+0x50], xmm6
00007b78f51db7c2  vmovaps [rsp+0x60], xmm7
00007b78f51db7c8  vmovaps [rsp+0x70], xmm8
00007b78f51db7ce  vmovaps [rsp+0x80], xmm9
00007b78f51db7d7  vmovaps [rsp+0x90], xmm10
00007b78f51db7e0  vmovaps [rsp+0xA0], xmm11
00007b78f51db7e9  vmovaps [rsp+0xB0], xmm12
00007b78f51db7f2  vmovaps [rsp+0xC0], xmm13
00007b78f51db7fb  vmovaps [rsp+0xD0], xmm14
00007b78f51db804  vmovaps [rsp+0xE0], xmm15
00007b78f51db80d  sub rsp, 0x30
00007b78f51db811  movaps [rsp], xmm1
00007b78f51db815  movaps [rsp+0x10], xmm8
00007b78f51db81b  movaps [rsp+0x20], xmm9
00007b78f51db821  lea rdi, [rsp]
00007b78f51db825  mov esi, 0x00
00007b78f51db82a  mov rax, 0x597478C09530
00007b78f51db834  call rax
00007b78f51db836  movaps xmm1, [rsp]
00007b78f51db83a  add rsp, 0x30
00007b78f51db83e  vmovaps xmm0, [rsp]
00007b78f51db843  vmovaps xmm2, [rsp+0x10]
00007b78f51db849  vmovaps xmm3, [rsp+0x20]
00007b78f51db84f  vmovaps xmm4, [rsp+0x30]
00007b78f51db855  vmovaps xmm5, [rsp+0x40]
00007b78f51db85b  vmovaps xmm6, [rsp+0x50]
00007b78f51db861  vmovaps xmm7, [rsp+0x60]
00007b78f51db867  vmovaps xmm8, [rsp+0x70]
00007b78f51db86d  vmovaps xmm9, [rsp+0x80]
00007b78f51db876  vmovaps xmm10, [rsp+0x90]
00007b78f51db87f  vmovaps xmm11, [rsp+0xA0]
00007b78f51db888  vmovaps xmm12, [rsp+0xB0]
00007b78f51db891  vmovaps xmm13, [rsp+0xC0]
00007b78f51db89a  vmovaps xmm14, [rsp+0xD0]
00007b78f51db8a3  vmovaps xmm15, [rsp+0xE0]
00007b78f51db8ac  add rsp, 0xF0
00007b78f51db8b3  pop r11
00007b78f51db8b5  pop r10
00007b78f51db8b7  pop r9
00007b78f51db8b9  pop r8
00007b78f51db8bb  pop rsi
00007b78f51db8bc  pop rdi
00007b78f51db8bd  pop rdx
00007b78f51db8be  pop rcx
00007b78f51db8bf  pop rax
00007b78f51db8c0  add rsp, 0x08
00007b78f51db8c4  jmp 0x00007B78F51D66B2
00007b78f51db8c9  call 0x00007B78F50B3E40
00007b78f51db8ce  jmp 0x00007B78F51D66C0
00007b78f51db8d3  call 0x00007B78F500C380
00007b78f51db8d8  jmp 0x00007B78F51D66CA
00007b78f51db8dd  call 0x00007B78F500D600
00007b78f51db8e2  jmp 0x00007B78F51D66D4
00007b78f51db8e7  call 0x00007B78F4FFF540
00007b78f51db8ec  jmp 0x00007B78F51D66DE
00007b78f51db8f1  int3
00007b78f51db8f2  nop [rax+rax*1], ax
00007b78f51db8fb  nop [rax+rax*1], eax
00007b78f51db900  mov eax, [r15+0x48]
00007b78f51db904  lea r14d, [eax+0x01]
00007b78f51db909  mov [rsp+0x10], r14d
00007b78f51db90e  mov r14d, r14d
00007b78f51db911  mov [r15+0x48], r14
00007b78f51db915  xor eax, eax
00007b78f51db917  mov r14d, [rsp+0x10]
00007b78f51db91c  cmp r14d, 0x1F4
00007b78f51db923  cmc
00007b78f51db924  lahf
00007b78f51db925  seto al
00007b78f51db928  mov [r15+0x108], eax
00007b78f51db92f  mov eax, [r15+0x108]
00007b78f51db936  sahf
00007b78f51db937  jnz 0x00007B78F51DB969
00007b78f51db939  cmp dword ptr [r15+0x318], 0x00
00007b78f51db941  jz 0x00007B78F51E1AB0
00007b78f51db947  nop [rax+rax*1], ax
00007b78f51db950  nop [rax+rax*1], eax
00007b78f51db958  mov eax, 0x410450
00007b78f51db95d  mov [r15+0x100], rax
00007b78f51db964  jmp 0x00007B78F4FFE110
00007b78f51db969  cmp dword ptr [r15+0x318], 0x00
00007b78f51db971  jz 0x00007B78F51DB9A0
00007b78f51db977  nop [rax+rax*1], ax
00007b78f51db980  nop [rax+rax*1], eax
00007b78f51db988  mov eax, 0x410274
00007b78f51db98d  mov [r15+0x100], rax
00007b78f51db994  jmp 0x00007B78F4FFE110
00007b78f51db999  int3
00007b78f51db99a  int3
00007b78f51db99b  nop [rax+rax*1], eax
00007b78f51db9a0  mov rax, [r15+0x40]
00007b78f51db9a4  movaps xmm1, [r15+0x1D0]
00007b78f51db9ac  vmovaps [rsp+0x10], xmm1
00007b78f51db9b2  vmovaps xmm15, [rsp+0x10]
00007b78f51db9b8  por xmm1, xmm15
00007b78f51db9bd  movaps xmm14, [r15+0x1A0]
00007b78f51db9c5  vmovaps [rsp+0x10], xmm14
00007b78f51db9cb  vmovaps xmm13, [rsp+0x10]
00007b78f51db9d1  por xmm14, xmm13
00007b78f51db9d6  lea r14, [rax+0x30]
00007b78f51db9da  mov r12, [r13+r14*1]
00007b78f51db9df  lea r14, [rax+0x38]
00007b78f51db9e3  mov r11, [r13+r14*1]
00007b78f51db9e8  movq xmm13, r12
00007b78f51db9ed  movq xmm12, r11
00007b78f51db9f2  movq xmm13, xmm13
00007b78f51db9f7  vmovaps [rsp+0x10], xmm13
00007b78f51db9fd  movq xmm13, xmm13
00007b78f51dba02  movaps [r15+0x130], xmm13
00007b78f51dba0a  movq xmm12, xmm12
00007b78f51dba0f  vmovaps [rsp+0x20], xmm12
00007b78f51dba15  movq xmm12, xmm12
00007b78f51dba1a  movaps [r15+0x280], xmm12
00007b78f51dba22  movaps xmm13, [r15+0x270]
00007b78f51dba2a  vmovaps [rsp+0x30], xmm13
00007b78f51dba30  vmovaps xmm12, [rsp+0x30]
00007b78f51dba36  por xmm13, xmm12
00007b78f51dba3b  lea r14, [rax+0x20]
00007b78f51dba3f  mov r12, [r13+r14*1]
00007b78f51dba44  lea r14, [rax+0x28]
00007b78f51dba48  mov r11, [r13+r14*1]
00007b78f51dba4d  movq xmm12, r12
00007b78f51dba52  movq xmm11, r11
00007b78f51dba57  movq xmm12, xmm12
00007b78f51dba5c  vmovaps [rsp+0x30], xmm12
00007b78f51dba62  movq xmm12, xmm12
00007b78f51dba67  movaps [r15+0x150], xmm12
00007b78f51dba6f  movq xmm11, xmm11
00007b78f51dba74  vmovaps [rsp+0x40], xmm11
00007b78f51dba7a  movq xmm11, xmm11
00007b78f51dba7f  movaps [r15+0x140], xmm11
00007b78f51dba87  lea r14, [rax+0x10]
00007b78f51dba8b  mov r12, [r13+r14*1]
00007b78f51dba90  lea r14, [rax+0x18]
00007b78f51dba94  mov r11, [r13+r14*1]
00007b78f51dba99  movq xmm12, r12
00007b78f51dba9e  movq xmm11, r11
00007b78f51dbaa3  movq xmm12, xmm12
00007b78f51dbaa8  vmovaps [rsp+0x50], xmm12
00007b78f51dbaae  movq xmm12, xmm12
00007b78f51dbab3  movaps [r15+0x170], xmm12
00007b78f51dbabb  movq xmm11, xmm11
00007b78f51dbac0  vmovaps [rsp+0x60], xmm11
00007b78f51dbac6  movq xmm11, xmm11
00007b78f51dbacb  movaps [r15+0x160], xmm11
00007b78f51dbad3  mov r14, [r13+rax*1]
00007b78f51dbad8  vmovq xmm12, r14
00007b78f51dbadd  vpbroadcastq xmm12, xmm12
00007b78f51dbae2  lea r14, [rax+0x08]
00007b78f51dbae6  mov rax, [r13+r14*1]
00007b78f51dbaeb  movq xmm11, rax
00007b78f51dbaf0  movaps [r15+0x230], xmm11
00007b78f51dbaf8  mov rax, [r15+0xF8]
00007b78f51dbaff  lea r14, [rax+0x50]
00007b78f51dbb03  movups xmm11, [r13+r14*1]
00007b78f51dbb09  lea r14, [rax+0x60]
00007b78f51dbb0d  movups xmm10, [r13+r14*1]
00007b78f51dbb13  lea r14, [rax+0x30]
00007b78f51dbb17  movups xmm9, [r13+r14*1]
00007b78f51dbb1d  mov r14, [r15+0x50]
00007b78f51dbb21  mov [r15+0x60], r14
00007b78f51dbb25  mov qword ptr [r15+0x58], 0x40
00007b78f51dbb2d  movaps xmm8, xmm12
00007b78f51dbb31  mulpd xmm8, xmm15
00007b78f51dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007b78f51dbb3c  ptest xmm7, xmm7
00007b78f51dbb41  jnz 0x00007B78F51DC96A
00007b78f51dbb47  movq xmm15, qword ptr [r15+0x230]
00007b78f51dbb50  vmovaps [rsp+0x70], xmm15
00007b78f51dbb56  vpermilpd xmm15, xmm15, 0x00
00007b78f51dbb5c  movaps xmm7, xmm9
00007b78f51dbb60  mulpd xmm7, xmm15
00007b78f51dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007b78f51dbb6a  ptest xmm6, xmm6
00007b78f51dbb6f  jnz 0x00007B78F51DCAAE
00007b78f51dbb75  vxorps xmm15, xmm15, xmm15
00007b78f51dbb7a  vpbroadcastq xmm15, xmm15
00007b78f51dbb7f  movaps xmm9, xmm12
00007b78f51dbb83  mulpd xmm9, xmm10
00007b78f51dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007b78f51dbb8e  ptest xmm6, xmm6
00007b78f51dbb93  jnz 0x00007B78F51DCBF0
00007b78f51dbb99  movaps xmm10, xmm12
00007b78f51dbb9d  mulpd xmm10, xmm11
00007b78f51dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007b78f51dbba8  ptest xmm6, xmm6
00007b78f51dbbad  jnz 0x00007B78F51DCD34
00007b78f51dbbb3  movaps xmm11, [r15+0x1F0]
00007b78f51dbbbb  movaps xmm6, xmm12
00007b78f51dbbbf  mulpd xmm6, xmm11
00007b78f51dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007b78f51dbbc9  ptest xmm5, xmm5
00007b78f51dbbce  jnz 0x00007B78F51DCE78
00007b78f51dbbd4  movaps xmm12, [r15+0x2A0]
00007b78f51dbbdc  vmovaps [rsp+0x80], xmm12
00007b78f51dbbe5  vmovaps xmm11, [rsp+0x80]
00007b78f51dbbee  por xmm12, xmm11
00007b78f51dbbf3  movaps xmm11, [r15+0x250]
00007b78f51dbbfb  vmovaps [rsp+0x80], xmm11
00007b78f51dbc04  vmovaps xmm5, [rsp+0x80]
00007b78f51dbc0d  por xmm11, xmm5
00007b78f51dbc12  vmovaps xmm4, [rsp+0x70]
00007b78f51dbc18  vpermilpd xmm4, xmm4, 0x00
00007b78f51dbc1e  movaps xmm3, xmm5
00007b78f51dbc21  mulpd xmm3, xmm4
00007b78f51dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007b78f51dbc2a  ptest xmm2, xmm2
00007b78f51dbc2f  jnz 0x00007B78F51DCFBA
00007b78f51dbc35  mov [rsp+0x80], rax
00007b78f51dbc3d  xor eax, eax
00007b78f51dbc3f  mov r12d, 0x40
00007b78f51dbc45  mov r11d, 0x200
00007b78f51dbc4b  cmp r12, r11
00007b78f51dbc4e  cmc
00007b78f51dbc4f  lahf
00007b78f51dbc50  seto al
00007b78f51dbc53  mov [r15+0x108], eax
00007b78f51dbc5a  movaps xmm5, xmm8
00007b78f51dbc5e  addpd xmm5, xmm15
00007b78f51dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007b78f51dbc68  ptest xmm4, xmm4
00007b78f51dbc6d  jnz 0x00007B78F51DD0FA
00007b78f51dbc73  movaps xmm8, [r15+0x1B0]
00007b78f51dbc7b  movaps xmm4, xmm9
00007b78f51dbc7f  addpd xmm4, xmm8
00007b78f51dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007b78f51dbc89  ptest xmm2, xmm2
00007b78f51dbc8e  jnz 0x00007B78F51DD23C
00007b78f51dbc94  movaps xmm9, xmm10
00007b78f51dbc98  addpd xmm9, xmm8
00007b78f51dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007b78f51dbca3  ptest xmm2, xmm2
00007b78f51dbca8  jnz 0x00007B78F51DD37E
00007b78f51dbcae  movaps xmm10, [r15+0x2F0]
00007b78f51dbcb6  vmovaps [rsp+0x90], xmm10
00007b78f51dbcbf  vmovaps xmm8, [rsp+0x90]
00007b78f51dbcc8  por xmm10, xmm8
00007b78f51dbccd  movaps xmm8, [r15+0x2E0]
00007b78f51dbcd5  vmovaps [rsp+0x90], xmm8
00007b78f51dbcde  vmovaps xmm2, [rsp+0x90]
00007b78f51dbce7  por xmm8, xmm2
00007b78f51dbcec  movaps xmm2, [r15+0x2D0]
00007b78f51dbcf4  vmovaps [rsp+0x90], xmm2
00007b78f51dbcfd  vmovaps [rsp+0xA0], xmm1
00007b78f51dbd06  vmovaps xmm1, [rsp+0x90]
00007b78f51dbd0f  por xmm2, xmm1
00007b78f51dbd13  movaps xmm1, [r15+0x200]
00007b78f51dbd1b  vmovaps [rsp+0x90], xmm1
00007b78f51dbd24  vmovaps [rsp+0xB0], xmm15
00007b78f51dbd2d  vmovaps xmm15, [rsp+0x90]
00007b78f51dbd36  por xmm1, xmm15
00007b78f51dbd3b  movaps xmm15, [r15+0x1C0]
00007b78f51dbd43  vmovaps [rsp+0x90], xmm15
00007b78f51dbd4c  vmovaps [rsp+0xC0], xmm1
00007b78f51dbd55  vmovaps xmm1, [rsp+0x90]
00007b78f51dbd5e  por xmm15, xmm1
00007b78f51dbd63  movaps xmm1, [r15+0x190]
00007b78f51dbd6b  vmovaps [rsp+0x90], xmm1
00007b78f51dbd74  vmovaps [rsp+0xD0], xmm15
00007b78f51dbd7d  vmovaps xmm15, [rsp+0x90]
00007b78f51dbd86  por xmm1, xmm15
00007b78f51dbd8b  movaps xmm15, [r15+0x300]
00007b78f51dbd93  vmovaps [rsp+0x90], xmm15
00007b78f51dbd9c  vmovaps [rsp+0xE0], xmm1
00007b78f51dbda5  vmovaps xmm1, [rsp+0x90]
00007b78f51dbdae  por xmm15, xmm1
00007b78f51dbdb3  mov rax, [rsp+0x80]
00007b78f51dbdbb  lea r12, [rax+0xA0]
00007b78f51dbdc2  movups xmm1, [r13+r12*1]
00007b78f51dbdc8  lea r12, [rax+0xB0]
00007b78f51dbdcf  vmovaps [rsp+0x80], xmm1
00007b78f51dbdd8  movups xmm1, [r13+r12*1]
00007b78f51dbdde  vmovaps [rsp+0x90], xmm1
00007b78f51dbde7  vmovaps [rsp+0xF0], xmm15
00007b78f51dbdf0  vmovaps xmm15, [rsp+0xB0]
00007b78f51dbdf9  vmovaps [rsp+0xB0], xmm14
00007b78f51dbe02  movaps xmm1, xmm6
00007b78f51dbe05  addpd xmm1, xmm15
00007b78f51dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007b78f51dbe0f  ptest xmm14, xmm14
00007b78f51dbe15  jnz 0x00007B78F51DD4D6
00007b78f51dbe1b  lea r12, [rax+0xF0]
00007b78f51dbe22  movups xmm15, [r13+r12*1]
00007b78f51dbe28  movaps xmm14, xmm4
00007b78f51dbe2c  addpd xmm14, xmm3
00007b78f51dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007b78f51dbe37  ptest xmm6, xmm6
00007b78f51dbe3c  jnz 0x00007B78F51DD621
00007b78f51dbe42  movaps xmm6, xmm9
00007b78f51dbe46  addpd xmm6, xmm7
00007b78f51dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007b78f51dbe4f  ptest xmm4, xmm4
00007b78f51dbe54  jnz 0x00007B78F51DD763
00007b78f51dbe5a  vmovaps xmm9, [rsp+0x70]
00007b78f51dbe60  vpermilpd xmm9, xmm9, 0x00
00007b78f51dbe66  vmovaps xmm4, [rsp+0x90]
00007b78f51dbe6f  movaps xmm7, xmm4
00007b78f51dbe72  mulpd xmm7, xmm9
00007b78f51dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007b78f51dbe7c  ptest xmm3, xmm3
00007b78f51dbe81  jnz 0x00007B78F51DD8A4
00007b78f51dbe87  vmovaps xmm9, [rsp+0x50]
00007b78f51dbe8d  vpermilpd xmm9, xmm9, 0x00
00007b78f51dbe93  movaps xmm4, xmm15
00007b78f51dbe97  mulpd xmm4, xmm9
00007b78f51dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007b78f51dbea1  ptest xmm3, xmm3
00007b78f51dbea6  jnz 0x00007B78F51DD9E5
00007b78f51dbeac  lea r12, [rax+0xE0]
00007b78f51dbeb3  movups xmm15, [r13+r12*1]
00007b78f51dbeb9  vmovaps xmm9, [rsp+0x70]
00007b78f51dbebf  vpermilpd xmm9, xmm9, 0x00
00007b78f51dbec5  vmovaps [rsp+0x70], xmm1
00007b78f51dbecb  vmovaps xmm1, [rsp+0x80]
00007b78f51dbed4  vmovaps [rsp+0x80], xmm15
00007b78f51dbedd  movaps xmm3, xmm1
00007b78f51dbee0  mulpd xmm3, xmm9
00007b78f51dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007b78f51dbeea  ptest xmm15, xmm15
00007b78f51dbef0  jnz 0x00007B78F51DDB31
00007b78f51dbef6  vmovaps xmm1, [rsp+0xF0]
00007b78f51dbeff  vmovaps xmm15, [rsp+0xF0]
00007b78f51dbf08  por xmm1, xmm15
00007b78f51dbf0d  movaps [r15+0x300], xmm1
00007b78f51dbf15  vmovaps xmm15, [rsp+0xE0]
00007b78f51dbf1e  vmovaps xmm9, [rsp+0xE0]
00007b78f51dbf27  por xmm15, xmm9
00007b78f51dbf2c  movaps [r15+0x190], xmm15
00007b78f51dbf34  vmovaps xmm9, [rsp+0x50]
00007b78f51dbf3a  vpermilpd xmm9, xmm9, 0x00
00007b78f51dbf40  vmovaps [rsp+0x90], xmm1
00007b78f51dbf49  vmovaps [rsp+0xE0], xmm15
00007b78f51dbf52  vmovaps xmm15, [rsp+0x80]
00007b78f51dbf5b  vmovaps [rsp+0x80], xmm14
00007b78f51dbf64  movaps xmm1, xmm15
00007b78f51dbf68  mulpd xmm1, xmm9
00007b78f51dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007b78f51dbf72  ptest xmm14, xmm14
00007b78f51dbf78  jnz 0x00007B78F51DDC72
00007b78f51dbf7e  lea r12, [rax+0x90]
00007b78f51dbf85  movups xmm15, [r13+r12*1]
00007b78f51dbf8b  vmovaps xmm14, [rsp+0xD0]
00007b78f51dbf94  vmovaps xmm9, [rsp+0xD0]
00007b78f51dbf9d  por xmm14, xmm9
00007b78f51dbfa2  movaps [r15+0x1C0], xmm14
00007b78f51dbfaa  vmovaps xmm9, [rsp+0xC0]
00007b78f51dbfb3  vmovaps [rsp+0xD0], xmm1
00007b78f51dbfbc  vmovaps xmm1, [rsp+0xC0]
00007b78f51dbfc5  por xmm9, xmm1
00007b78f51dbfca  movaps [r15+0x200], xmm9
00007b78f51dbfd2  vmovaps [rsp+0xC0], xmm2
00007b78f51dbfdb  vmovaps xmm1, [rsp+0xC0]
00007b78f51dbfe4  por xmm2, xmm1
00007b78f51dbfe8  movaps [r15+0x2D0], xmm2
00007b78f51dbff0  vmovaps [rsp+0xC0], xmm8
00007b78f51dbff9  vmovaps xmm1, [rsp+0xC0]
00007b78f51dc002  por xmm8, xmm1
00007b78f51dc007  movaps [r15+0x2E0], xmm8
00007b78f51dc00f  vmovaps [rsp+0xC0], xmm15
00007b78f51dc018  movaps xmm1, xmm5
00007b78f51dc01b  addpd xmm1, xmm7
00007b78f51dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007b78f51dc024  ptest xmm15, xmm15
00007b78f51dc02a  jnz 0x00007B78F51DDDBE
00007b78f51dc030  vmovaps xmm15, [rsp+0x50]
00007b78f51dc036  vpermilpd xmm15, xmm15, 0x00
00007b78f51dc03c  vmovaps xmm5, [rsp+0xC0]
00007b78f51dc045  vmovaps [rsp+0xC0], xmm1
00007b78f51dc04e  movaps xmm7, xmm5
00007b78f51dc051  mulpd xmm7, xmm15
00007b78f51dc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007b78f51dc05b  ptest xmm1, xmm1
00007b78f51dc060  jnz 0x00007B78F51DDEFE
00007b78f51dc066  lea r12, [rax+0x80]
00007b78f51dc06d  movups xmm1, [r13+r12*1]
00007b78f51dc073  vmovaps xmm5, [rsp+0x70]
00007b78f51dc079  vmovaps [rsp+0x70], xmm1
00007b78f51dc07f  movaps xmm15, xmm5
00007b78f51dc083  addpd xmm15, xmm3
00007b78f51dc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007b78f51dc08e  ptest xmm1, xmm1
00007b78f51dc093  jnz 0x00007B78F51DE049
00007b78f51dc099  vmovaps xmm5, [rsp+0x80]
00007b78f51dc0a2  movaps xmm1, xmm5
00007b78f51dc0a5  addpd xmm1, xmm4
00007b78f51dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007b78f51dc0ae  ptest xmm3, xmm3
00007b78f51dc0b3  jnz 0x00007B78F51DE18B
00007b78f51dc0b9  vmovaps [rsp+0x80], xmm10
00007b78f51dc0c2  vmovaps xmm5, [rsp+0x80]
00007b78f51dc0cb  por xmm10, xmm5
00007b78f51dc0d0  movaps [r15+0x2F0], xmm10
00007b78f51dc0d8  vmovaps xmm5, [rsp+0x50]
00007b78f51dc0de  vpermilpd xmm5, xmm5, 0x00
00007b78f51dc0e4  vmovaps xmm3, [rsp+0x70]
00007b78f51dc0ea  vmovaps [rsp+0x50], xmm1
00007b78f51dc0f0  movaps xmm4, xmm3
00007b78f51dc0f3  mulpd xmm4, xmm5
00007b78f51dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007b78f51dc0fc  ptest xmm1, xmm1
00007b78f51dc101  jnz 0x00007B78F51DE2CB
00007b78f51dc107  lea r12, [rax+0xD0]
00007b78f51dc10e  movups xmm1, [r13+r12*1]
00007b78f51dc114  vmovaps xmm3, [rsp+0xD0]
00007b78f51dc11d  vmovaps [rsp+0x70], xmm1
00007b78f51dc123  movaps xmm5, xmm6
00007b78f51dc126  addpd xmm5, xmm3
00007b78f51dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007b78f51dc12f  ptest xmm1, xmm1
00007b78f51dc134  jnz 0x00007B78F51DE415
00007b78f51dc13a  vmovaps xmm1, [rsp+0x60]
00007b78f51dc140  vpermilpd xmm1, xmm1, 0x00
00007b78f51dc146  movaps xmm6, xmm9
00007b78f51dc14a  mulpd xmm6, xmm1
00007b78f51dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007b78f51dc153  ptest xmm3, xmm3
00007b78f51dc158  jnz 0x00007B78F51DE555
00007b78f51dc15e  movaps [r15+0x260], xmm6
00007b78f51dc166  vxorps xmm1, xmm1, xmm1
00007b78f51dc16a  vpbroadcastq xmm1, xmm1
00007b78f51dc16f  movaps [r15+0x1B0], xmm1
00007b78f51dc177  vmovaps xmm1, [rsp+0x60]
00007b78f51dc17d  vpermilpd xmm1, xmm1, 0x00
00007b78f51dc183  vmovaps xmm3, [rsp+0x70]
00007b78f51dc189  vmovaps [rsp+0x70], xmm15
00007b78f51dc18f  movaps xmm9, xmm3
00007b78f51dc193  mulpd xmm9, xmm1
00007b78f51dc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007b78f51dc19e  ptest xmm15, xmm15
00007b78f51dc1a4  jnz 0x00007B78F51DE696
00007b78f51dc1aa  lea r12, [rax+0xC0]
00007b78f51dc1b1  movups xmm1, [r13+r12*1]
00007b78f51dc1b7  vmovaps xmm3, [rsp+0xC0]
00007b78f51dc1c0  vmovaps [rsp+0x80], xmm1
00007b78f51dc1c9  movaps xmm15, xmm3
00007b78f51dc1cd  addpd xmm15, xmm7
00007b78f51dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007b78f51dc1d8  ptest xmm1, xmm1
00007b78f51dc1dd  jnz 0x00007B78F51DE7E2
00007b78f51dc1e3  vmovaps [rsp+0xC0], xmm13
00007b78f51dc1ec  vmovaps xmm1, [rsp+0xC0]
00007b78f51dc1f5  por xmm13, xmm1
00007b78f51dc1fa  movaps [r15+0x270], xmm13
00007b78f51dc202  vmovaps xmm1, [rsp+0xB0]
00007b78f51dc20b  vmovaps xmm7, [rsp+0xB0]
00007b78f51dc214  por xmm1, xmm7
00007b78f51dc218  movaps [r15+0x1A0], xmm1
00007b78f51dc220  vmovaps xmm1, [rsp+0x60]
00007b78f51dc226  vpermilpd xmm1, xmm1, 0x00
00007b78f51dc22c  vmovaps [rsp+0xB0], xmm1
00007b78f51dc235  vmovaps xmm1, [rsp+0x80]
00007b78f51dc23e  vmovaps [rsp+0x80], xmm15
00007b78f51dc247  vmovaps xmm15, [rsp+0xB0]
00007b78f51dc250  vmovaps [rsp+0xB0], xmm14
00007b78f51dc259  movaps xmm3, xmm1
00007b78f51dc25c  mulpd xmm3, xmm15
00007b78f51dc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007b78f51dc266  ptest xmm14, xmm14
00007b78f51dc26c  jnz 0x00007B78F51DE924
00007b78f51dc272  lea r12, [rax+0x20]
00007b78f51dc276  movups xmm1, [r13+r12*1]
00007b78f51dc27c  movaps [r15+0x110], xmm1
00007b78f51dc284  vmovaps xmm14, [rsp+0x70]
00007b78f51dc28a  vmovaps [rsp+0x70], xmm1
00007b78f51dc290  movaps xmm15, xmm14
00007b78f51dc294  addpd xmm15, xmm4
00007b78f51dc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007b78f51dc29f  ptest xmm1, xmm1
00007b78f51dc2a4  jnz 0x00007B78F51DEA6F
00007b78f51dc2aa  vmovaps xmm1, [rsp+0x60]
00007b78f51dc2b0  vpermilpd xmm1, xmm1, 0x00
00007b78f51dc2b6  movaps xmm14, xmm2
00007b78f51dc2ba  mulpd xmm14, xmm1
00007b78f51dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007b78f51dc2c5  ptest xmm4, xmm4
00007b78f51dc2ca  jnz 0x00007B78F51DEBB2
00007b78f51dc2d0  vmovaps xmm4, [rsp+0x50]
00007b78f51dc2d6  movaps xmm1, xmm4
00007b78f51dc2d9  addpd xmm1, xmm9
00007b78f51dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007b78f51dc2e3  ptest xmm2, xmm2
00007b78f51dc2e8  jnz 0x00007B78F51DECF4
00007b78f51dc2ee  vmovaps xmm9, [rsp+0x30]
00007b78f51dc2f4  vpermilpd xmm9, xmm9, 0x00
00007b78f51dc2fa  vmovaps xmm2, [rsp+0x70]
00007b78f51dc300  vmovaps [rsp+0x50], xmm1
00007b78f51dc306  movaps xmm4, xmm2
00007b78f51dc309  mulpd xmm4, xmm9
00007b78f51dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007b78f51dc313  ptest xmm1, xmm1
00007b78f51dc318  jnz 0x00007B78F51DEE35
00007b78f51dc31e  vmovaps xmm1, [rsp+0x30]
00007b78f51dc324  vpermilpd xmm1, xmm1, 0x00
00007b78f51dc32a  vmovaps xmm2, [rsp+0x90]
00007b78f51dc333  vmovaps [rsp+0x60], xmm15
00007b78f51dc339  movaps xmm9, xmm2
00007b78f51dc33d  mulpd xmm9, xmm1
00007b78f51dc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007b78f51dc348  ptest xmm15, xmm15
00007b78f51dc34e  jnz 0x00007B78F51DEF76
00007b78f51dc354  vmovaps xmm15, [rsp+0x80]
00007b78f51dc35d  movaps xmm1, xmm15
00007b78f51dc361  addpd xmm1, xmm6
00007b78f51dc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007b78f51dc36a  ptest xmm2, xmm2
00007b78f51dc36f  jnz 0x00007B78F51DF0B8
00007b78f51dc375  movaps xmm15, xmm5
00007b78f51dc379  addpd xmm15, xmm3
00007b78f51dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007b78f51dc384  ptest xmm6, xmm6
00007b78f51dc389  jnz 0x00007B78F51DF1F9
00007b78f51dc38f  vmovaps xmm6, [rsp+0x30]
00007b78f51dc395  vpermilpd xmm6, xmm6, 0x00
00007b78f51dc39b  movaps xmm5, xmm8
00007b78f51dc39f  mulpd xmm5, xmm6
00007b78f51dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007b78f51dc3a8  ptest xmm3, xmm3
00007b78f51dc3ad  jnz 0x00007B78F51DF33B
00007b78f51dc3b3  vmovaps xmm8, [rsp+0x30]
00007b78f51dc3b9  vpermilpd xmm8, xmm8, 0x00
00007b78f51dc3bf  movaps xmm6, xmm10
00007b78f51dc3c3  mulpd xmm6, xmm8
00007b78f51dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007b78f51dc3cd  ptest xmm3, xmm3
00007b78f51dc3d2  jnz 0x00007B78F51DF47C
00007b78f51dc3d8  vmovaps xmm8, [rsp+0x60]
00007b78f51dc3de  movaps xmm10, xmm8
00007b78f51dc3e2  addpd xmm10, xmm14
00007b78f51dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007b78f51dc3ed  ptest xmm3, xmm3
00007b78f51dc3f2  jnz 0x00007B78F51DF5BE
00007b78f51dc3f8  vmovaps xmm8, [rsp+0x50]
00007b78f51dc3fe  movaps xmm14, xmm8
00007b78f51dc402  addpd xmm14, xmm4
00007b78f51dc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007b78f51dc40d  ptest xmm3, xmm3
00007b78f51dc412  jnz 0x00007B78F51DF702
00007b78f51dc418  vmovaps xmm8, [rsp+0x40]
00007b78f51dc41e  vpermilpd xmm8, xmm8, 0x00
00007b78f51dc424  movaps xmm4, xmm13
00007b78f51dc428  mulpd xmm4, xmm8
00007b78f51dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007b78f51dc432  ptest xmm3, xmm3
00007b78f51dc437  jnz 0x00007B78F51DF845
00007b78f51dc43d  movaps xmm13, xmm15
00007b78f51dc441  addpd xmm13, xmm9
00007b78f51dc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007b78f51dc44c  ptest xmm8, xmm8
00007b78f51dc452  jnz 0x00007B78F51DF987
00007b78f51dc458  movaps xmm15, xmm1
00007b78f51dc45c  addpd xmm15, xmm5
00007b78f51dc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007b78f51dc467  ptest xmm9, xmm9
00007b78f51dc46d  jnz 0x00007B78F51DFACB
00007b78f51dc473  vmovaps [rsp+0x30], xmm11
00007b78f51dc479  vmovaps xmm1, [rsp+0x30]
00007b78f51dc47f  por xmm11, xmm1
00007b78f51dc484  movaps [r15+0x250], xmm11
00007b78f51dc48c  vmovaps [rsp+0x30], xmm12
00007b78f51dc492  vmovaps xmm1, [rsp+0x30]
00007b78f51dc498  por xmm12, xmm1
00007b78f51dc49d  movaps [r15+0x2A0], xmm12
00007b78f51dc4a5  vmovaps xmm1, [rsp+0xA0]
00007b78f51dc4ae  vmovaps xmm11, [rsp+0xA0]
00007b78f51dc4b7  por xmm1, xmm11
00007b78f51dc4bc  movaps [r15+0x1D0], xmm1
00007b78f51dc4c4  lea r12, [rax+0x40]
00007b78f51dc4c8  movups xmm1, [r13+r12*1]
00007b78f51dc4ce  movaps [r15+0x2C0], xmm1
00007b78f51dc4d6  vmovaps xmm11, [rsp+0x40]
00007b78f51dc4dc  vpermilpd xmm11, xmm11, 0x00
00007b78f51dc4e2  vmovaps xmm8, [rsp+0xE0]
00007b78f51dc4eb  movaps xmm9, xmm8
00007b78f51dc4ef  mulpd xmm9, xmm11
00007b78f51dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007b78f51dc4fa  ptest xmm5, xmm5
00007b78f51dc4ff  jnz 0x00007B78F51DFC17
00007b78f51dc505  movaps xmm11, xmm10
00007b78f51dc509  addpd xmm11, xmm6
00007b78f51dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007b78f51dc514  ptest xmm8, xmm8
00007b78f51dc51a  jnz 0x00007B78F51DFD5B
00007b78f51dc520  movaps xmm10, xmm14
00007b78f51dc524  addpd xmm10, xmm4
00007b78f51dc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007b78f51dc52f  ptest xmm8, xmm8
00007b78f51dc535  jnz 0x00007B78F51DFE9E
00007b78f51dc53b  vmovaps xmm14, [rsp+0x40]
00007b78f51dc541  vpermilpd xmm14, xmm14, 0x00
00007b78f51dc547  movaps xmm8, xmm1
00007b78f51dc54b  mulpd xmm8, xmm14
00007b78f51dc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007b78f51dc556  ptest xmm6, xmm6
00007b78f51dc55b  jnz 0x00007B78F51DFFE1
00007b78f51dc561  movaps xmm1, [r15+0x2B0]
00007b78f51dc569  vmovaps xmm14, [rsp+0x40]
00007b78f51dc56f  vpermilpd xmm14, xmm14, 0x00
00007b78f51dc575  movaps xmm6, xmm1
00007b78f51dc578  mulpd xmm6, xmm14
00007b78f51dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007b78f51dc582  ptest xmm5, xmm5
00007b78f51dc587  jnz 0x00007B78F51E0124
00007b78f51dc58d  vmovaps xmm1, [rsp+0x10]
00007b78f51dc593  vpermilpd xmm1, xmm1, 0x00
00007b78f51dc599  movaps xmm14, xmm12
00007b78f51dc59d  mulpd xmm14, xmm1
00007b78f51dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007b78f51dc5a8  ptest xmm5, xmm5
00007b78f51dc5ad  jnz 0x00007B78F51E0265
00007b78f51dc5b3  movaps xmm1, xmm13
00007b78f51dc5b7  addpd xmm1, xmm9
00007b78f51dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007b78f51dc5c1  ptest xmm12, xmm12
00007b78f51dc5c7  jnz 0x00007B78F51E03A8
00007b78f51dc5cd  vmovaps xmm13, [rsp+0x10]
00007b78f51dc5d3  vpermilpd xmm13, xmm13, 0x00
00007b78f51dc5d9  movaps xmm12, xmm7
00007b78f51dc5dd  mulpd xmm12, xmm13
00007b78f51dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007b78f51dc5e8  ptest xmm9, xmm9
00007b78f51dc5ee  jnz 0x00007B78F51E04EA
00007b78f51dc5f4  movaps xmm13, xmm15
00007b78f51dc5f8  addpd xmm13, xmm8
00007b78f51dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007b78f51dc603  ptest xmm9, xmm9
00007b78f51dc609  jnz 0x00007B78F51E062D
00007b78f51dc60f  movaps xmm15, [r15+0x290]
00007b78f51dc617  vmovaps xmm9, [rsp+0x10]
00007b78f51dc61d  vpermilpd xmm9, xmm9, 0x00
00007b78f51dc623  movaps xmm8, xmm15
00007b78f51dc627  mulpd xmm8, xmm9
00007b78f51dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007b78f51dc632  ptest xmm7, xmm7
00007b78f51dc637  jnz 0x00007B78F51E0771
00007b78f51dc63d  movaps xmm15, xmm11
00007b78f51dc641  addpd xmm15, xmm6
00007b78f51dc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007b78f51dc64c  ptest xmm9, xmm9
00007b78f51dc652  jnz 0x00007B78F51E08B5
00007b78f51dc658  movaps xmm11, [r15+0x1E0]
00007b78f51dc660  vmovaps xmm9, [rsp+0x10]
00007b78f51dc666  vpermilpd xmm9, xmm9, 0x00
00007b78f51dc66c  movaps xmm7, xmm11
00007b78f51dc670  mulpd xmm7, xmm9
00007b78f51dc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007b78f51dc67a  ptest xmm6, xmm6
00007b78f51dc67f  jnz 0x00007B78F51E09F8
00007b78f51dc685  movaps xmm11, xmm10
00007b78f51dc689  addpd xmm11, xmm14
00007b78f51dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007b78f51dc694  ptest xmm9, xmm9
00007b78f51dc69a  jnz 0x00007B78F51E0B3A
00007b78f51dc6a0  lea r12, [rax+0x70]
00007b78f51dc6a4  movups xmm14, [r13+r12*1]
00007b78f51dc6aa  movaps [r15+0x240], xmm14
00007b78f51dc6b2  movaps xmm10, xmm1
00007b78f51dc6b6  addpd xmm10, xmm12
00007b78f51dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007b78f51dc6c1  ptest xmm9, xmm9
00007b78f51dc6c7  jnz 0x00007B78F51E0C88
00007b78f51dc6cd  movaps [r15+0x170], xmm10
00007b78f51dc6d5  vmovaps xmm1, [rsp+0x20]
00007b78f51dc6db  vpermilpd xmm1, xmm1, 0x00
00007b78f51dc6e1  movaps xmm12, xmm14
00007b78f51dc6e5  mulpd xmm12, xmm1
00007b78f51dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007b78f51dc6f0  ptest xmm9, xmm9
00007b78f51dc6f6  jnz 0x00007B78F51E0DCB
00007b78f51dc6fc  vmovaps xmm1, [rsp+0x20]
00007b78f51dc702  vpermilpd xmm1, xmm1, 0x00
00007b78f51dc708  vmovaps xmm9, [rsp+0xB0]
00007b78f51dc711  movaps xmm14, xmm9
00007b78f51dc715  mulpd xmm14, xmm1
00007b78f51dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007b78f51dc720  ptest xmm6, xmm6
00007b78f51dc725  jnz 0x00007B78F51E0F0E
00007b78f51dc72b  movaps [r15+0x180], xmm14
00007b78f51dc733  movaps xmm1, xmm13
00007b78f51dc737  addpd xmm1, xmm8
00007b78f51dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007b78f51dc741  ptest xmm9, xmm9
00007b78f51dc747  jnz 0x00007B78F51E1051
00007b78f51dc74d  movaps [r15+0x210], xmm1
00007b78f51dc755  movups xmm13, [r13+rax*1]
00007b78f51dc75b  lea r12, [rax+0x10]
00007b78f51dc75f  movups xmm9, [r13+r12*1]
00007b78f51dc765  movaps [r15+0x230], xmm9
00007b78f51dc76d  movaps xmm8, xmm15
00007b78f51dc771  addpd xmm8, xmm7
00007b78f51dc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007b78f51dc77c  ptest xmm6, xmm6
00007b78f51dc781  jnz 0x00007B78F51E11A7
00007b78f51dc787  movaps [r15+0x130], xmm8
00007b78f51dc78f  vmovaps xmm15, [rsp+0x20]
00007b78f51dc795  vpermilpd xmm15, xmm15, 0x00
00007b78f51dc79b  movaps xmm7, xmm9
00007b78f51dc79f  mulpd xmm7, xmm15
00007b78f51dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007b78f51dc7a9  ptest xmm6, xmm6
00007b78f51dc7ae  jnz 0x00007B78F51E12EA
00007b78f51dc7b4  movaps [r15+0x220], xmm7
00007b78f51dc7bc  vmovaps xmm15, [rsp+0x20]
00007b78f51dc7c2  vpermilpd xmm15, xmm15, 0x00
00007b78f51dc7c8  movaps xmm9, xmm13
00007b78f51dc7cc  mulpd xmm9, xmm15
00007b78f51dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007b78f51dc7d7  ptest xmm6, xmm6
00007b78f51dc7dc  jnz 0x00007B78F51E142C
00007b78f51dc7e2  movaps xmm15, xmm11
00007b78f51dc7e6  addpd xmm15, xmm12
00007b78f51dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007b78f51dc7f1  ptest xmm13, xmm13
00007b78f51dc7f7  jnz 0x00007B78F51E1570
00007b78f51dc7fd  movaps [r15+0x140], xmm15
00007b78f51dc805  movaps xmm13, xmm10
00007b78f51dc809  addpd xmm13, xmm14
00007b78f51dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007b78f51dc814  ptest xmm12, xmm12
00007b78f51dc81a  jnz 0x00007B78F51E16B4
00007b78f51dc820  movaps [r15+0x150], xmm13
00007b78f51dc828  movaps xmm14, xmm1
00007b78f51dc82c  addpd xmm14, xmm7
00007b78f51dc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007b78f51dc837  ptest xmm12, xmm12
00007b78f51dc83d  jnz 0x00007B78F51E17F8
00007b78f51dc843  movaps [r15+0x160], xmm14
00007b78f51dc84b  movaps xmm1, xmm8
00007b78f51dc84f  addpd xmm1, xmm9
00007b78f51dc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007b78f51dc859  ptest xmm12, xmm12
00007b78f51dc85f  jnz 0x00007B78F51E193A
00007b78f51dc865  movaps [r15+0x120], xmm1
00007b78f51dc86d  movups [r13+r14*1], xmm15
00007b78f51dc873  lea rax, [r14+0x10]
00007b78f51dc877  movups [r13+rax*1], xmm13
00007b78f51dc87d  lea rax, [r14+0x20]
00007b78f51dc881  movups [r13+rax*1], xmm14
00007b78f51dc887  lea rax, [r14+0x30]
00007b78f51dc88b  movups [r13+rax*1], xmm1
00007b78f51dc891  mov eax, [r15+0x108]
00007b78f51dc898  sahf
00007b78f51dc899  jnz 0x00007B78F51DC8CB
00007b78f51dc89b  cmp dword ptr [r15+0x318], 0x00
00007b78f51dc8a3  jz 0x00007B78F51DB900
00007b78f51dc8a9  nop [rax+rax*1], ax
00007b78f51dc8b2  nop [rax+rax*1], eax
00007b78f51dc8ba  mov eax, 0x410444
00007b78f51dc8bf  mov [r15+0x100], rax
00007b78f51dc8c6  jmp 0x00007B78F4FFE110
00007b78f51dc8cb  cmp dword ptr [r15+0x318], 0x00
00007b78f51dc8d3  jz 0x00007B78F51D57E0
00007b78f51dc8d9  nop [rax+rax*1], ax
00007b78f51dc8e2  nop [rax+rax*1], eax
00007b78f51dc8ea  mov eax, 0x410278
00007b78f51dc8ef  mov [r15+0x100], rax
00007b78f51dc8f6  jmp 0x00007B78F4FFE110
00007b78f51dc8fb  int3
00007b78f51dc8fc  call 0x00007B78F50E27E0
00007b78f51dc901  jmp 0x00007B78F51DB9DF
00007b78f51dc906  call 0x00007B78F50E1570
00007b78f51dc90b  jmp 0x00007B78F51DB9E8
00007b78f51dc910  call 0x00007B78F50E27E0
00007b78f51dc915  jmp 0x00007B78F51DBA44
00007b78f51dc91a  call 0x00007B78F50E1570
00007b78f51dc91f  jmp 0x00007B78F51DBA4D
00007b78f51dc924  call 0x00007B78F50E27E0
00007b78f51dc929  jmp 0x00007B78F51DBA90
00007b78f51dc92e  call 0x00007B78F50E1570
00007b78f51dc933  jmp 0x00007B78F51DBA99
00007b78f51dc938  call 0x00007B78F500DC20
00007b78f51dc93d  jmp 0x00007B78F51DBAD8
00007b78f51dc942  call 0x00007B78F50D59C0
00007b78f51dc947  jmp 0x00007B78F51DBAEB
00007b78f51dc94c  call 0x00007B78F50E0E30
00007b78f51dc951  jmp 0x00007B78F51DBB09
00007b78f51dc956  call 0x00007B78F50DFBC0
00007b78f51dc95b  jmp 0x00007B78F51DBB13
00007b78f51dc960  call 0x00007B78F50DE950
00007b78f51dc965  jmp 0x00007B78F51DBB1D
00007b78f51dc96a  sub rsp, 0x08
00007b78f51dc96e  push rax
00007b78f51dc96f  push rcx
00007b78f51dc970  push rdx
00007b78f51dc971  push rdi
00007b78f51dc972  push rsi
00007b78f51dc973  push r8
00007b78f51dc975  push r9
00007b78f51dc977  push r10
00007b78f51dc979  push r11
00007b78f51dc97b  sub rsp, 0xF0
00007b78f51dc982  vmovaps [rsp], xmm0
00007b78f51dc987  vmovaps [rsp+0x10], xmm1
00007b78f51dc98d  vmovaps [rsp+0x20], xmm2
00007b78f51dc993  vmovaps [rsp+0x30], xmm3
00007b78f51dc999  vmovaps [rsp+0x40], xmm4
00007b78f51dc99f  vmovaps [rsp+0x50], xmm5
00007b78f51dc9a5  vmovaps [rsp+0x60], xmm6
00007b78f51dc9ab  vmovaps [rsp+0x70], xmm7
00007b78f51dc9b1  vmovaps [rsp+0x80], xmm9
00007b78f51dc9ba  vmovaps [rsp+0x90], xmm10
00007b78f51dc9c3  vmovaps [rsp+0xA0], xmm11
00007b78f51dc9cc  vmovaps [rsp+0xB0], xmm12
00007b78f51dc9d5  vmovaps [rsp+0xC0], xmm13
00007b78f51dc9de  vmovaps [rsp+0xD0], xmm14
00007b78f51dc9e7  vmovaps [rsp+0xE0], xmm15
00007b78f51dc9f0  sub rsp, 0x30
00007b78f51dc9f4  movaps [rsp], xmm8
00007b78f51dc9f9  movaps [rsp+0x10], xmm12
00007b78f51dc9ff  movaps [rsp+0x20], xmm15
00007b78f51dca05  lea rdi, [rsp]
00007b78f51dca09  mov esi, 0x00
00007b78f51dca0e  mov rax, 0x597478C09530
00007b78f51dca18  call rax
00007b78f51dca1a  movaps xmm8, [rsp]
00007b78f51dca1f  add rsp, 0x30
00007b78f51dca23  vmovaps xmm0, [rsp]
00007b78f51dca28  vmovaps xmm1, [rsp+0x10]
00007b78f51dca2e  vmovaps xmm2, [rsp+0x20]
00007b78f51dca34  vmovaps xmm3, [rsp+0x30]
00007b78f51dca3a  vmovaps xmm4, [rsp+0x40]
00007b78f51dca40  vmovaps xmm5, [rsp+0x50]
00007b78f51dca46  vmovaps xmm6, [rsp+0x60]
00007b78f51dca4c  vmovaps xmm7, [rsp+0x70]
00007b78f51dca52  vmovaps xmm9, [rsp+0x80]
00007b78f51dca5b  vmovaps xmm10, [rsp+0x90]
00007b78f51dca64  vmovaps xmm11, [rsp+0xA0]
00007b78f51dca6d  vmovaps xmm12, [rsp+0xB0]
00007b78f51dca76  vmovaps xmm13, [rsp+0xC0]
00007b78f51dca7f  vmovaps xmm14, [rsp+0xD0]
00007b78f51dca88  vmovaps xmm15, [rsp+0xE0]
00007b78f51dca91  add rsp, 0xF0
00007b78f51dca98  pop r11
00007b78f51dca9a  pop r10
00007b78f51dca9c  pop r9
00007b78f51dca9e  pop r8
00007b78f51dcaa0  pop rsi
00007b78f51dcaa1  pop rdi
00007b78f51dcaa2  pop rdx
00007b78f51dcaa3  pop rcx
00007b78f51dcaa4  pop rax
00007b78f51dcaa5  add rsp, 0x08
00007b78f51dcaa9  jmp 0x00007B78F51DBB47
00007b78f51dcaae  sub rsp, 0x08
00007b78f51dcab2  push rax
00007b78f51dcab3  push rcx
00007b78f51dcab4  push rdx
00007b78f51dcab5  push rdi
00007b78f51dcab6  push rsi
00007b78f51dcab7  push r8
00007b78f51dcab9  push r9
00007b78f51dcabb  push r10
00007b78f51dcabd  push r11
00007b78f51dcabf  sub rsp, 0xF0
00007b78f51dcac6  vmovaps [rsp], xmm0
00007b78f51dcacb  vmovaps [rsp+0x10], xmm1
00007b78f51dcad1  vmovaps [rsp+0x20], xmm2
00007b78f51dcad7  vmovaps [rsp+0x30], xmm3
00007b78f51dcadd  vmovaps [rsp+0x40], xmm4
00007b78f51dcae3  vmovaps [rsp+0x50], xmm5
00007b78f51dcae9  vmovaps [rsp+0x60], xmm6
00007b78f51dcaef  vmovaps [rsp+0x70], xmm8
00007b78f51dcaf5  vmovaps [rsp+0x80], xmm9
00007b78f51dcafe  vmovaps [rsp+0x90], xmm10
00007b78f51dcb07  vmovaps [rsp+0xA0], xmm11
00007b78f51dcb10  vmovaps [rsp+0xB0], xmm12
00007b78f51dcb19  vmovaps [rsp+0xC0], xmm13
00007b78f51dcb22  vmovaps [rsp+0xD0], xmm14
00007b78f51dcb2b  vmovaps [rsp+0xE0], xmm15
00007b78f51dcb34  sub rsp, 0x30
00007b78f51dcb38  movaps [rsp], xmm7
00007b78f51dcb3c  movaps [rsp+0x10], xmm9
00007b78f51dcb42  movaps [rsp+0x20], xmm15
00007b78f51dcb48  lea rdi, [rsp]
00007b78f51dcb4c  mov esi, 0x00
00007b78f51dcb51  mov rax, 0x597478C09530
00007b78f51dcb5b  call rax
00007b78f51dcb5d  movaps xmm7, [rsp]
00007b78f51dcb61  add rsp, 0x30
00007b78f51dcb65  vmovaps xmm0, [rsp]
00007b78f51dcb6a  vmovaps xmm1, [rsp+0x10]
00007b78f51dcb70  vmovaps xmm2, [rsp+0x20]
00007b78f51dcb76  vmovaps xmm3, [rsp+0x30]
00007b78f51dcb7c  vmovaps xmm4, [rsp+0x40]
00007b78f51dcb82  vmovaps xmm5, [rsp+0x50]
00007b78f51dcb88  vmovaps xmm6, [rsp+0x60]
00007b78f51dcb8e  vmovaps xmm8, [rsp+0x70]
00007b78f51dcb94  vmovaps xmm9, [rsp+0x80]
00007b78f51dcb9d  vmovaps xmm10, [rsp+0x90]
00007b78f51dcba6  vmovaps xmm11, [rsp+0xA0]
00007b78f51dcbaf  vmovaps xmm12, [rsp+0xB0]
00007b78f51dcbb8  vmovaps xmm13, [rsp+0xC0]
00007b78f51dcbc1  vmovaps xmm14, [rsp+0xD0]
00007b78f51dcbca  vmovaps xmm15, [rsp+0xE0]
00007b78f51dcbd3  add rsp, 0xF0
00007b78f51dcbda  pop r11
00007b78f51dcbdc  pop r10
00007b78f51dcbde  pop r9
00007b78f51dcbe0  pop r8
00007b78f51dcbe2  pop rsi
00007b78f51dcbe3  pop rdi
00007b78f51dcbe4  pop rdx
00007b78f51dcbe5  pop rcx
00007b78f51dcbe6  pop rax
00007b78f51dcbe7  add rsp, 0x08
00007b78f51dcbeb  jmp 0x00007B78F51DBB75
00007b78f51dcbf0  sub rsp, 0x08
00007b78f51dcbf4  push rax
00007b78f51dcbf5  push rcx
00007b78f51dcbf6  push rdx
00007b78f51dcbf7  push rdi
00007b78f51dcbf8  push rsi
00007b78f51dcbf9  push r8
00007b78f51dcbfb  push r9
00007b78f51dcbfd  push r10
00007b78f51dcbff  push r11
00007b78f51dcc01  sub rsp, 0xF0
00007b78f51dcc08  vmovaps [rsp], xmm0
00007b78f51dcc0d  vmovaps [rsp+0x10], xmm1
00007b78f51dcc13  vmovaps [rsp+0x20], xmm2
00007b78f51dcc19  vmovaps [rsp+0x30], xmm3
00007b78f51dcc1f  vmovaps [rsp+0x40], xmm4
00007b78f51dcc25  vmovaps [rsp+0x50], xmm5
00007b78f51dcc2b  vmovaps [rsp+0x60], xmm6
00007b78f51dcc31  vmovaps [rsp+0x70], xmm7
00007b78f51dcc37  vmovaps [rsp+0x80], xmm8
00007b78f51dcc40  vmovaps [rsp+0x90], xmm10
00007b78f51dcc49  vmovaps [rsp+0xA0], xmm11
00007b78f51dcc52  vmovaps [rsp+0xB0], xmm12
00007b78f51dcc5b  vmovaps [rsp+0xC0], xmm13
00007b78f51dcc64  vmovaps [rsp+0xD0], xmm14
00007b78f51dcc6d  vmovaps [rsp+0xE0], xmm15
00007b78f51dcc76  sub rsp, 0x30
00007b78f51dcc7a  movaps [rsp], xmm9
00007b78f51dcc7f  movaps [rsp+0x10], xmm12
00007b78f51dcc85  movaps [rsp+0x20], xmm10
00007b78f51dcc8b  lea rdi, [rsp]
00007b78f51dcc8f  mov esi, 0x00
00007b78f51dcc94  mov rax, 0x597478C09530
00007b78f51dcc9e  call rax
00007b78f51dcca0  movaps xmm9, [rsp]
00007b78f51dcca5  add rsp, 0x30
00007b78f51dcca9  vmovaps xmm0, [rsp]
00007b78f51dccae  vmovaps xmm1, [rsp+0x10]
00007b78f51dccb4  vmovaps xmm2, [rsp+0x20]
00007b78f51dccba  vmovaps xmm3, [rsp+0x30]
00007b78f51dccc0  vmovaps xmm4, [rsp+0x40]
00007b78f51dccc6  vmovaps xmm5, [rsp+0x50]
00007b78f51dcccc  vmovaps xmm6, [rsp+0x60]
00007b78f51dccd2  vmovaps xmm7, [rsp+0x70]
00007b78f51dccd8  vmovaps xmm8, [rsp+0x80]
00007b78f51dcce1  vmovaps xmm10, [rsp+0x90]
00007b78f51dccea  vmovaps xmm11, [rsp+0xA0]
00007b78f51dccf3  vmovaps xmm12, [rsp+0xB0]
00007b78f51dccfc  vmovaps xmm13, [rsp+0xC0]
00007b78f51dcd05  vmovaps xmm14, [rsp+0xD0]
00007b78f51dcd0e  vmovaps xmm15, [rsp+0xE0]
00007b78f51dcd17  add rsp, 0xF0
00007b78f51dcd1e  pop r11
00007b78f51dcd20  pop r10
00007b78f51dcd22  pop r9
00007b78f51dcd24  pop r8
00007b78f51dcd26  pop rsi
00007b78f51dcd27  pop rdi
00007b78f51dcd28  pop rdx
00007b78f51dcd29  pop rcx
00007b78f51dcd2a  pop rax
00007b78f51dcd2b  add rsp, 0x08
00007b78f51dcd2f  jmp 0x00007B78F51DBB99
00007b78f51dcd34  sub rsp, 0x08
00007b78f51dcd38  push rax
00007b78f51dcd39  push rcx
00007b78f51dcd3a  push rdx
00007b78f51dcd3b  push rdi
00007b78f51dcd3c  push rsi
00007b78f51dcd3d  push r8
00007b78f51dcd3f  push r9
00007b78f51dcd41  push r10
00007b78f51dcd43  push r11
00007b78f51dcd45  sub rsp, 0xF0
00007b78f51dcd4c  vmovaps [rsp], xmm0
00007b78f51dcd51  vmovaps [rsp+0x10], xmm1
00007b78f51dcd57  vmovaps [rsp+0x20], xmm2
00007b78f51dcd5d  vmovaps [rsp+0x30], xmm3
00007b78f51dcd63  vmovaps [rsp+0x40], xmm4
00007b78f51dcd69  vmovaps [rsp+0x50], xmm5
00007b78f51dcd6f  vmovaps [rsp+0x60], xmm6
00007b78f51dcd75  vmovaps [rsp+0x70], xmm7
00007b78f51dcd7b  vmovaps [rsp+0x80], xmm8
00007b78f51dcd84  vmovaps [rsp+0x90], xmm9
00007b78f51dcd8d  vmovaps [rsp+0xA0], xmm11
00007b78f51dcd96  vmovaps [rsp+0xB0], xmm12
00007b78f51dcd9f  vmovaps [rsp+0xC0], xmm13
00007b78f51dcda8  vmovaps [rsp+0xD0], xmm14
00007b78f51dcdb1  vmovaps [rsp+0xE0], xmm15
00007b78f51dcdba  sub rsp, 0x30
00007b78f51dcdbe  movaps [rsp], xmm10
00007b78f51dcdc3  movaps [rsp+0x10], xmm12
00007b78f51dcdc9  movaps [rsp+0x20], xmm11
00007b78f51dcdcf  lea rdi, [rsp]
00007b78f51dcdd3  mov esi, 0x00
00007b78f51dcdd8  mov rax, 0x597478C09530
00007b78f51dcde2  call rax
00007b78f51dcde4  movaps xmm10, [rsp]
00007b78f51dcde9  add rsp, 0x30
00007b78f51dcded  vmovaps xmm0, [rsp]
00007b78f51dcdf2  vmovaps xmm1, [rsp+0x10]
00007b78f51dcdf8  vmovaps xmm2, [rsp+0x20]
00007b78f51dcdfe  vmovaps xmm3, [rsp+0x30]
00007b78f51dce04  vmovaps xmm4, [rsp+0x40]
00007b78f51dce0a  vmovaps xmm5, [rsp+0x50]
00007b78f51dce10  vmovaps xmm6, [rsp+0x60]
00007b78f51dce16  vmovaps xmm7, [rsp+0x70]
00007b78f51dce1c  vmovaps xmm8, [rsp+0x80]
00007b78f51dce25  vmovaps xmm9, [rsp+0x90]
00007b78f51dce2e  vmovaps xmm11, [rsp+0xA0]
00007b78f51dce37  vmovaps xmm12, [rsp+0xB0]
00007b78f51dce40  vmovaps xmm13, [rsp+0xC0]
00007b78f51dce49  vmovaps xmm14, [rsp+0xD0]
00007b78f51dce52  vmovaps xmm15, [rsp+0xE0]
00007b78f51dce5b  add rsp, 0xF0
00007b78f51dce62  pop r11
00007b78f51dce64  pop r10
00007b78f51dce66  pop r9
00007b78f51dce68  pop r8
00007b78f51dce6a  pop rsi
00007b78f51dce6b  pop rdi
00007b78f51dce6c  pop rdx
00007b78f51dce6d  pop rcx
00007b78f51dce6e  pop rax
00007b78f51dce6f  add rsp, 0x08
00007b78f51dce73  jmp 0x00007B78F51DBBB3
00007b78f51dce78  sub rsp, 0x08
00007b78f51dce7c  push rax
00007b78f51dce7d  push rcx
00007b78f51dce7e  push rdx
00007b78f51dce7f  push rdi
00007b78f51dce80  push rsi
00007b78f51dce81  push r8
00007b78f51dce83  push r9
00007b78f51dce85  push r10
00007b78f51dce87  push r11
00007b78f51dce89  sub rsp, 0xF0
00007b78f51dce90  vmovaps [rsp], xmm0
00007b78f51dce95  vmovaps [rsp+0x10], xmm1
00007b78f51dce9b  vmovaps [rsp+0x20], xmm2
00007b78f51dcea1  vmovaps [rsp+0x30], xmm3
00007b78f51dcea7  vmovaps [rsp+0x40], xmm4
00007b78f51dcead  vmovaps [rsp+0x50], xmm5
00007b78f51dceb3  vmovaps [rsp+0x60], xmm7
00007b78f51dceb9  vmovaps [rsp+0x70], xmm8
00007b78f51dcebf  vmovaps [rsp+0x80], xmm9
00007b78f51dcec8  vmovaps [rsp+0x90], xmm10
00007b78f51dced1  vmovaps [rsp+0xA0], xmm11
00007b78f51dceda  vmovaps [rsp+0xB0], xmm12
00007b78f51dcee3  vmovaps [rsp+0xC0], xmm13
00007b78f51dceec  vmovaps [rsp+0xD0], xmm14
00007b78f51dcef5  vmovaps [rsp+0xE0], xmm15
00007b78f51dcefe  sub rsp, 0x30
00007b78f51dcf02  movaps [rsp], xmm6
00007b78f51dcf06  movaps [rsp+0x10], xmm12
00007b78f51dcf0c  movaps [rsp+0x20], xmm11
00007b78f51dcf12  lea rdi, [rsp]
00007b78f51dcf16  mov esi, 0x00
00007b78f51dcf1b  mov rax, 0x597478C09530
00007b78f51dcf25  call rax
00007b78f51dcf27  movaps xmm6, [rsp]
00007b78f51dcf2b  add rsp, 0x30
00007b78f51dcf2f  vmovaps xmm0, [rsp]
00007b78f51dcf34  vmovaps xmm1, [rsp+0x10]
00007b78f51dcf3a  vmovaps xmm2, [rsp+0x20]
00007b78f51dcf40  vmovaps xmm3, [rsp+0x30]
00007b78f51dcf46  vmovaps xmm4, [rsp+0x40]
00007b78f51dcf4c  vmovaps xmm5, [rsp+0x50]
00007b78f51dcf52  vmovaps xmm7, [rsp+0x60]
00007b78f51dcf58  vmovaps xmm8, [rsp+0x70]
00007b78f51dcf5e  vmovaps xmm9, [rsp+0x80]
00007b78f51dcf67  vmovaps xmm10, [rsp+0x90]
00007b78f51dcf70  vmovaps xmm11, [rsp+0xA0]
00007b78f51dcf79  vmovaps xmm12, [rsp+0xB0]
00007b78f51dcf82  vmovaps xmm13, [rsp+0xC0]
00007b78f51dcf8b  vmovaps xmm14, [rsp+0xD0]
00007b78f51dcf94  vmovaps xmm15, [rsp+0xE0]
00007b78f51dcf9d  add rsp, 0xF0
00007b78f51dcfa4  pop r11
00007b78f51dcfa6  pop r10
00007b78f51dcfa8  pop r9
00007b78f51dcfaa  pop r8
00007b78f51dcfac  pop rsi
00007b78f51dcfad  pop rdi
00007b78f51dcfae  pop rdx
00007b78f51dcfaf  pop rcx
00007b78f51dcfb0  pop rax
00007b78f51dcfb1  add rsp, 0x08
00007b78f51dcfb5  jmp 0x00007B78F51DBBD4
00007b78f51dcfba  sub rsp, 0x08
00007b78f51dcfbe  push rax
00007b78f51dcfbf  push rcx
00007b78f51dcfc0  push rdx
00007b78f51dcfc1  push rdi
00007b78f51dcfc2  push rsi
00007b78f51dcfc3  push r8
00007b78f51dcfc5  push r9
00007b78f51dcfc7  push r10
00007b78f51dcfc9  push r11
00007b78f51dcfcb  sub rsp, 0xF0
00007b78f51dcfd2  vmovaps [rsp], xmm0
00007b78f51dcfd7  vmovaps [rsp+0x10], xmm1
00007b78f51dcfdd  vmovaps [rsp+0x20], xmm2
00007b78f51dcfe3  vmovaps [rsp+0x30], xmm4
00007b78f51dcfe9  vmovaps [rsp+0x40], xmm5
00007b78f51dcfef  vmovaps [rsp+0x50], xmm6
00007b78f51dcff5  vmovaps [rsp+0x60], xmm7
00007b78f51dcffb  vmovaps [rsp+0x70], xmm8
00007b78f51dd001  vmovaps [rsp+0x80], xmm9
00007b78f51dd00a  vmovaps [rsp+0x90], xmm10
00007b78f51dd013  vmovaps [rsp+0xA0], xmm11
00007b78f51dd01c  vmovaps [rsp+0xB0], xmm12
00007b78f51dd025  vmovaps [rsp+0xC0], xmm13
00007b78f51dd02e  vmovaps [rsp+0xD0], xmm14
00007b78f51dd037  vmovaps [rsp+0xE0], xmm15
00007b78f51dd040  sub rsp, 0x30
00007b78f51dd044  movaps [rsp], xmm3
00007b78f51dd048  movaps [rsp+0x10], xmm5
00007b78f51dd04d  movaps [rsp+0x20], xmm4
00007b78f51dd052  lea rdi, [rsp]
00007b78f51dd056  mov esi, 0x00
00007b78f51dd05b  mov rax, 0x597478C09530
00007b78f51dd065  call rax
00007b78f51dd067  movaps xmm3, [rsp]
00007b78f51dd06b  add rsp, 0x30
00007b78f51dd06f  vmovaps xmm0, [rsp]
00007b78f51dd074  vmovaps xmm1, [rsp+0x10]
00007b78f51dd07a  vmovaps xmm2, [rsp+0x20]
00007b78f51dd080  vmovaps xmm4, [rsp+0x30]
00007b78f51dd086  vmovaps xmm5, [rsp+0x40]
00007b78f51dd08c  vmovaps xmm6, [rsp+0x50]
00007b78f51dd092  vmovaps xmm7, [rsp+0x60]
00007b78f51dd098  vmovaps xmm8, [rsp+0x70]
00007b78f51dd09e  vmovaps xmm9, [rsp+0x80]
00007b78f51dd0a7  vmovaps xmm10, [rsp+0x90]
00007b78f51dd0b0  vmovaps xmm11, [rsp+0xA0]
00007b78f51dd0b9  vmovaps xmm12, [rsp+0xB0]
00007b78f51dd0c2  vmovaps xmm13, [rsp+0xC0]
00007b78f51dd0cb  vmovaps xmm14, [rsp+0xD0]
00007b78f51dd0d4  vmovaps xmm15, [rsp+0xE0]
00007b78f51dd0dd  add rsp, 0xF0
00007b78f51dd0e4  pop r11
00007b78f51dd0e6  pop r10
00007b78f51dd0e8  pop r9
00007b78f51dd0ea  pop r8
00007b78f51dd0ec  pop rsi
00007b78f51dd0ed  pop rdi
00007b78f51dd0ee  pop rdx
00007b78f51dd0ef  pop rcx
00007b78f51dd0f0  pop rax
00007b78f51dd0f1  add rsp, 0x08
00007b78f51dd0f5  jmp 0x00007B78F51DBC35
00007b78f51dd0fa  sub rsp, 0x08
00007b78f51dd0fe  push rax
00007b78f51dd0ff  push rcx
00007b78f51dd100  push rdx
00007b78f51dd101  push rdi
00007b78f51dd102  push rsi
00007b78f51dd103  push r8
00007b78f51dd105  push r9
00007b78f51dd107  push r10
00007b78f51dd109  push r11
00007b78f51dd10b  sub rsp, 0xF0
00007b78f51dd112  vmovaps [rsp], xmm0
00007b78f51dd117  vmovaps [rsp+0x10], xmm1
00007b78f51dd11d  vmovaps [rsp+0x20], xmm2
00007b78f51dd123  vmovaps [rsp+0x30], xmm3
00007b78f51dd129  vmovaps [rsp+0x40], xmm4
00007b78f51dd12f  vmovaps [rsp+0x50], xmm6
00007b78f51dd135  vmovaps [rsp+0x60], xmm7
00007b78f51dd13b  vmovaps [rsp+0x70], xmm8
00007b78f51dd141  vmovaps [rsp+0x80], xmm9
00007b78f51dd14a  vmovaps [rsp+0x90], xmm10
00007b78f51dd153  vmovaps [rsp+0xA0], xmm11
00007b78f51dd15c  vmovaps [rsp+0xB0], xmm12
00007b78f51dd165  vmovaps [rsp+0xC0], xmm13
00007b78f51dd16e  vmovaps [rsp+0xD0], xmm14
00007b78f51dd177  vmovaps [rsp+0xE0], xmm15
00007b78f51dd180  sub rsp, 0x30
00007b78f51dd184  movaps [rsp], xmm5
00007b78f51dd188  movaps [rsp+0x10], xmm8
00007b78f51dd18e  movaps [rsp+0x20], xmm15
00007b78f51dd194  lea rdi, [rsp]
00007b78f51dd198  mov esi, 0x00
00007b78f51dd19d  mov rax, 0x597478C09530
00007b78f51dd1a7  call rax
00007b78f51dd1a9  movaps xmm5, [rsp]
00007b78f51dd1ad  add rsp, 0x30
00007b78f51dd1b1  vmovaps xmm0, [rsp]
00007b78f51dd1b6  vmovaps xmm1, [rsp+0x10]
00007b78f51dd1bc  vmovaps xmm2, [rsp+0x20]
00007b78f51dd1c2  vmovaps xmm3, [rsp+0x30]
00007b78f51dd1c8  vmovaps xmm4, [rsp+0x40]
00007b78f51dd1ce  vmovaps xmm6, [rsp+0x50]
00007b78f51dd1d4  vmovaps xmm7, [rsp+0x60]
00007b78f51dd1da  vmovaps xmm8, [rsp+0x70]
00007b78f51dd1e0  vmovaps xmm9, [rsp+0x80]
00007b78f51dd1e9  vmovaps xmm10, [rsp+0x90]
00007b78f51dd1f2  vmovaps xmm11, [rsp+0xA0]
00007b78f51dd1fb  vmovaps xmm12, [rsp+0xB0]
00007b78f51dd204  vmovaps xmm13, [rsp+0xC0]
00007b78f51dd20d  vmovaps xmm14, [rsp+0xD0]
00007b78f51dd216  vmovaps xmm15, [rsp+0xE0]
00007b78f51dd21f  add rsp, 0xF0
00007b78f51dd226  pop r11
00007b78f51dd228  pop r10
00007b78f51dd22a  pop r9
00007b78f51dd22c  pop r8
00007b78f51dd22e  pop rsi
00007b78f51dd22f  pop rdi
00007b78f51dd230  pop rdx
00007b78f51dd231  pop rcx
00007b78f51dd232  pop rax
00007b78f51dd233  add rsp, 0x08
00007b78f51dd237  jmp 0x00007B78F51DBC73
00007b78f51dd23c  sub rsp, 0x08
00007b78f51dd240  push rax
00007b78f51dd241  push rcx
00007b78f51dd242  push rdx
00007b78f51dd243  push rdi
00007b78f51dd244  push rsi
00007b78f51dd245  push r8
00007b78f51dd247  push r9
00007b78f51dd249  push r10
00007b78f51dd24b  push r11
00007b78f51dd24d  sub rsp, 0xF0
00007b78f51dd254  vmovaps [rsp], xmm0
00007b78f51dd259  vmovaps [rsp+0x10], xmm1
00007b78f51dd25f  vmovaps [rsp+0x20], xmm2
00007b78f51dd265  vmovaps [rsp+0x30], xmm3
00007b78f51dd26b  vmovaps [rsp+0x40], xmm5
00007b78f51dd271  vmovaps [rsp+0x50], xmm6
00007b78f51dd277  vmovaps [rsp+0x60], xmm7
00007b78f51dd27d  vmovaps [rsp+0x70], xmm8
00007b78f51dd283  vmovaps [rsp+0x80], xmm9
00007b78f51dd28c  vmovaps [rsp+0x90], xmm10
00007b78f51dd295  vmovaps [rsp+0xA0], xmm11
00007b78f51dd29e  vmovaps [rsp+0xB0], xmm12
00007b78f51dd2a7  vmovaps [rsp+0xC0], xmm13
00007b78f51dd2b0  vmovaps [rsp+0xD0], xmm14
00007b78f51dd2b9  vmovaps [rsp+0xE0], xmm15
00007b78f51dd2c2  sub rsp, 0x30
00007b78f51dd2c6  movaps [rsp], xmm4
00007b78f51dd2ca  movaps [rsp+0x10], xmm9
00007b78f51dd2d0  movaps [rsp+0x20], xmm8
00007b78f51dd2d6  lea rdi, [rsp]
00007b78f51dd2da  mov esi, 0x00
00007b78f51dd2df  mov rax, 0x597478C09530
00007b78f51dd2e9  call rax
00007b78f51dd2eb  movaps xmm4, [rsp]
00007b78f51dd2ef  add rsp, 0x30
00007b78f51dd2f3  vmovaps xmm0, [rsp]
00007b78f51dd2f8  vmovaps xmm1, [rsp+0x10]
00007b78f51dd2fe  vmovaps xmm2, [rsp+0x20]
00007b78f51dd304  vmovaps xmm3, [rsp+0x30]
00007b78f51dd30a  vmovaps xmm5, [rsp+0x40]
00007b78f51dd310  vmovaps xmm6, [rsp+0x50]
00007b78f51dd316  vmovaps xmm7, [rsp+0x60]
00007b78f51dd31c  vmovaps xmm8, [rsp+0x70]
00007b78f51dd322  vmovaps xmm9, [rsp+0x80]
00007b78f51dd32b  vmovaps xmm10, [rsp+0x90]
00007b78f51dd334  vmovaps xmm11, [rsp+0xA0]
00007b78f51dd33d  vmovaps xmm12, [rsp+0xB0]
00007b78f51dd346  vmovaps xmm13, [rsp+0xC0]
00007b78f51dd34f  vmovaps xmm14, [rsp+0xD0]
00007b78f51dd358  vmovaps xmm15, [rsp+0xE0]
00007b78f51dd361  add rsp, 0xF0
00007b78f51dd368  pop r11
00007b78f51dd36a  pop r10
00007b78f51dd36c  pop r9
00007b78f51dd36e  pop r8
00007b78f51dd370  pop rsi
00007b78f51dd371  pop rdi
00007b78f51dd372  pop rdx
00007b78f51dd373  pop rcx
00007b78f51dd374  pop rax
00007b78f51dd375  add rsp, 0x08
00007b78f51dd379  jmp 0x00007B78F51DBC94
00007b78f51dd37e  sub rsp, 0x08
00007b78f51dd382  push rax
00007b78f51dd383  push rcx
00007b78f51dd384  push rdx
00007b78f51dd385  push rdi
00007b78f51dd386  push rsi
00007b78f51dd387  push r8
00007b78f51dd389  push r9
00007b78f51dd38b  push r10
00007b78f51dd38d  push r11
00007b78f51dd38f  sub rsp, 0xF0
00007b78f51dd396  vmovaps [rsp], xmm0
00007b78f51dd39b  vmovaps [rsp+0x10], xmm1
00007b78f51dd3a1  vmovaps [rsp+0x20], xmm2
00007b78f51dd3a7  vmovaps [rsp+0x30], xmm3
00007b78f51dd3ad  vmovaps [rsp+0x40], xmm4
00007b78f51dd3b3  vmovaps [rsp+0x50], xmm5
00007b78f51dd3b9  vmovaps [rsp+0x60], xmm6
00007b78f51dd3bf  vmovaps [rsp+0x70], xmm7
00007b78f51dd3c5  vmovaps [rsp+0x80], xmm8
00007b78f51dd3ce  vmovaps [rsp+0x90], xmm10
00007b78f51dd3d7  vmovaps [rsp+0xA0], xmm11
00007b78f51dd3e0  vmovaps [rsp+0xB0], xmm12
00007b78f51dd3e9  vmovaps [rsp+0xC0], xmm13
00007b78f51dd3f2  vmovaps [rsp+0xD0], xmm14
00007b78f51dd3fb  vmovaps [rsp+0xE0], xmm15
00007b78f51dd404  sub rsp, 0x30
00007b78f51dd408  movaps [rsp], xmm9
00007b78f51dd40d  movaps [rsp+0x10], xmm10
00007b78f51dd413  movaps [rsp+0x20], xmm8
00007b78f51dd419  lea rdi, [rsp]
00007b78f51dd41d  mov esi, 0x00
00007b78f51dd422  mov rax, 0x597478C09530
00007b78f51dd42c  call rax
00007b78f51dd42e  movaps xmm9, [rsp]
00007b78f51dd433  add rsp, 0x30
00007b78f51dd437  vmovaps xmm0, [rsp]
00007b78f51dd43c  vmovaps xmm1, [rsp+0x10]
00007b78f51dd442  vmovaps xmm2, [rsp+0x20]
00007b78f51dd448  vmovaps xmm3, [rsp+0x30]
00007b78f51dd44e  vmovaps xmm4, [rsp+0x40]
00007b78f51dd454  vmovaps xmm5, [rsp+0x50]
00007b78f51dd45a  vmovaps xmm6, [rsp+0x60]
00007b78f51dd460  vmovaps xmm7, [rsp+0x70]
00007b78f51dd466  vmovaps xmm8, [rsp+0x80]
00007b78f51dd46f  vmovaps xmm10, [rsp+0x90]
00007b78f51dd478  vmovaps xmm11, [rsp+0xA0]
00007b78f51dd481  vmovaps xmm12, [rsp+0xB0]
00007b78f51dd48a  vmovaps xmm13, [rsp+0xC0]
00007b78f51dd493  vmovaps xmm14, [rsp+0xD0]
00007b78f51dd49c  vmovaps xmm15, [rsp+0xE0]
00007b78f51dd4a5  add rsp, 0xF0
00007b78f51dd4ac  pop r11
00007b78f51dd4ae  pop r10
00007b78f51dd4b0  pop r9
00007b78f51dd4b2  pop r8
00007b78f51dd4b4  pop rsi
00007b78f51dd4b5  pop rdi
00007b78f51dd4b6  pop rdx
00007b78f51dd4b7  pop rcx
00007b78f51dd4b8  pop rax
00007b78f51dd4b9  add rsp, 0x08
00007b78f51dd4bd  jmp 0x00007B78F51DBCAE
00007b78f51dd4c2  call 0x00007B78F50B52F0
00007b78f51dd4c7  jmp 0x00007B78F51DBDC8
00007b78f51dd4cc  call 0x00007B78F50B52F0
00007b78f51dd4d1  jmp 0x00007B78F51DBDDE
00007b78f51dd4d6  sub rsp, 0x08
00007b78f51dd4da  push rax
00007b78f51dd4db  push rcx
00007b78f51dd4dc  push rdx
00007b78f51dd4dd  push rdi
00007b78f51dd4de  push rsi
00007b78f51dd4df  push r8
00007b78f51dd4e1  push r9
00007b78f51dd4e3  push r10
00007b78f51dd4e5  push r11
00007b78f51dd4e7  sub rsp, 0xF0
00007b78f51dd4ee  vmovaps [rsp], xmm0
00007b78f51dd4f3  vmovaps [rsp+0x10], xmm2
00007b78f51dd4f9  vmovaps [rsp+0x20], xmm3
00007b78f51dd4ff  vmovaps [rsp+0x30], xmm4
00007b78f51dd505  vmovaps [rsp+0x40], xmm5
00007b78f51dd50b  vmovaps [rsp+0x50], xmm6
00007b78f51dd511  vmovaps [rsp+0x60], xmm7
00007b78f51dd517  vmovaps [rsp+0x70], xmm8
00007b78f51dd51d  vmovaps [rsp+0x80], xmm9
00007b78f51dd526  vmovaps [rsp+0x90], xmm10
00007b78f51dd52f  vmovaps [rsp+0xA0], xmm11
00007b78f51dd538  vmovaps [rsp+0xB0], xmm12
00007b78f51dd541  vmovaps [rsp+0xC0], xmm13
00007b78f51dd54a  vmovaps [rsp+0xD0], xmm14
00007b78f51dd553  vmovaps [rsp+0xE0], xmm15
00007b78f51dd55c  sub rsp, 0x30
00007b78f51dd560  movaps [rsp], xmm1
00007b78f51dd564  movaps [rsp+0x10], xmm6
00007b78f51dd569  movaps [rsp+0x20], xmm15
00007b78f51dd56f  lea rdi, [rsp]
00007b78f51dd573  mov esi, 0x00
00007b78f51dd578  mov rax, 0x597478C09530
00007b78f51dd582  call rax
00007b78f51dd584  movaps xmm1, [rsp]
00007b78f51dd588  add rsp, 0x30
00007b78f51dd58c  vmovaps xmm0, [rsp]
00007b78f51dd591  vmovaps xmm2, [rsp+0x10]
00007b78f51dd597  vmovaps xmm3, [rsp+0x20]
00007b78f51dd59d  vmovaps xmm4, [rsp+0x30]
00007b78f51dd5a3  vmovaps xmm5, [rsp+0x40]
00007b78f51dd5a9  vmovaps xmm6, [rsp+0x50]
00007b78f51dd5af  vmovaps xmm7, [rsp+0x60]
00007b78f51dd5b5  vmovaps xmm8, [rsp+0x70]
00007b78f51dd5bb  vmovaps xmm9, [rsp+0x80]
00007b78f51dd5c4  vmovaps xmm10, [rsp+0x90]
00007b78f51dd5cd  vmovaps xmm11, [rsp+0xA0]
00007b78f51dd5d6  vmovaps xmm12, [rsp+0xB0]
00007b78f51dd5df  vmovaps xmm13, [rsp+0xC0]
00007b78f51dd5e8  vmovaps xmm14, [rsp+0xD0]
00007b78f51dd5f1  vmovaps xmm15, [rsp+0xE0]
00007b78f51dd5fa  add rsp, 0xF0
00007b78f51dd601  pop r11
00007b78f51dd603  pop r10
00007b78f51dd605  pop r9
00007b78f51dd607  pop r8
00007b78f51dd609  pop rsi
00007b78f51dd60a  pop rdi
00007b78f51dd60b  pop rdx
00007b78f51dd60c  pop rcx
00007b78f51dd60d  pop rax
00007b78f51dd60e  add rsp, 0x08
00007b78f51dd612  jmp 0x00007B78F51DBE1B
00007b78f51dd617  call 0x00007B78F50C4620
00007b78f51dd61c  jmp 0x00007B78F51DBE28
00007b78f51dd621  sub rsp, 0x08
00007b78f51dd625  push rax
00007b78f51dd626  push rcx
00007b78f51dd627  push rdx
00007b78f51dd628  push rdi
00007b78f51dd629  push rsi
00007b78f51dd62a  push r8
00007b78f51dd62c  push r9
00007b78f51dd62e  push r10
00007b78f51dd630  push r11
00007b78f51dd632  sub rsp, 0xF0
00007b78f51dd639  vmovaps [rsp], xmm0
00007b78f51dd63e  vmovaps [rsp+0x10], xmm1
00007b78f51dd644  vmovaps [rsp+0x20], xmm2
00007b78f51dd64a  vmovaps [rsp+0x30], xmm3
00007b78f51dd650  vmovaps [rsp+0x40], xmm4
00007b78f51dd656  vmovaps [rsp+0x50], xmm5
00007b78f51dd65c  vmovaps [rsp+0x60], xmm6
00007b78f51dd662  vmovaps [rsp+0x70], xmm7
00007b78f51dd668  vmovaps [rsp+0x80], xmm8
00007b78f51dd671  vmovaps [rsp+0x90], xmm9
00007b78f51dd67a  vmovaps [rsp+0xA0], xmm10
00007b78f51dd683  vmovaps [rsp+0xB0], xmm11
00007b78f51dd68c  vmovaps [rsp+0xC0], xmm12
00007b78f51dd695  vmovaps [rsp+0xD0], xmm13
00007b78f51dd69e  vmovaps [rsp+0xE0], xmm15
00007b78f51dd6a7  sub rsp, 0x30
00007b78f51dd6ab  movaps [rsp], xmm14
00007b78f51dd6b0  movaps [rsp+0x10], xmm4
00007b78f51dd6b5  movaps [rsp+0x20], xmm3
00007b78f51dd6ba  lea rdi, [rsp]
00007b78f51dd6be  mov esi, 0x00
00007b78f51dd6c3  mov rax, 0x597478C09530
00007b78f51dd6cd  call rax
00007b78f51dd6cf  movaps xmm14, [rsp]
00007b78f51dd6d4  add rsp, 0x30
00007b78f51dd6d8  vmovaps xmm0, [rsp]
00007b78f51dd6dd  vmovaps xmm1, [rsp+0x10]
00007b78f51dd6e3  vmovaps xmm2, [rsp+0x20]
00007b78f51dd6e9  vmovaps xmm3, [rsp+0x30]
00007b78f51dd6ef  vmovaps xmm4, [rsp+0x40]
00007b78f51dd6f5  vmovaps xmm5, [rsp+0x50]
00007b78f51dd6fb  vmovaps xmm6, [rsp+0x60]
00007b78f51dd701  vmovaps xmm7, [rsp+0x70]
00007b78f51dd707  vmovaps xmm8, [rsp+0x80]
00007b78f51dd710  vmovaps xmm9, [rsp+0x90]
00007b78f51dd719  vmovaps xmm10, [rsp+0xA0]
00007b78f51dd722  vmovaps xmm11, [rsp+0xB0]
00007b78f51dd72b  vmovaps xmm12, [rsp+0xC0]
00007b78f51dd734  vmovaps xmm13, [rsp+0xD0]
00007b78f51dd73d  vmovaps xmm15, [rsp+0xE0]
00007b78f51dd746  add rsp, 0xF0
00007b78f51dd74d  pop r11
00007b78f51dd74f  pop r10
00007b78f51dd751  pop r9
00007b78f51dd753  pop r8
00007b78f51dd755  pop rsi
00007b78f51dd756  pop rdi
00007b78f51dd757  pop rdx
00007b78f51dd758  pop rcx
00007b78f51dd759  pop rax
00007b78f51dd75a  add rsp, 0x08
00007b78f51dd75e  jmp 0x00007B78F51DBE42
00007b78f51dd763  sub rsp, 0x08
00007b78f51dd767  push rax
00007b78f51dd768  push rcx
00007b78f51dd769  push rdx
00007b78f51dd76a  push rdi
00007b78f51dd76b  push rsi
00007b78f51dd76c  push r8
00007b78f51dd76e  push r9
00007b78f51dd770  push r10
00007b78f51dd772  push r11
00007b78f51dd774  sub rsp, 0xF0
00007b78f51dd77b  vmovaps [rsp], xmm0
00007b78f51dd780  vmovaps [rsp+0x10], xmm1
00007b78f51dd786  vmovaps [rsp+0x20], xmm2
00007b78f51dd78c  vmovaps [rsp+0x30], xmm3
00007b78f51dd792  vmovaps [rsp+0x40], xmm4
00007b78f51dd798  vmovaps [rsp+0x50], xmm5
00007b78f51dd79e  vmovaps [rsp+0x60], xmm7
00007b78f51dd7a4  vmovaps [rsp+0x70], xmm8
00007b78f51dd7aa  vmovaps [rsp+0x80], xmm9
00007b78f51dd7b3  vmovaps [rsp+0x90], xmm10
00007b78f51dd7bc  vmovaps [rsp+0xA0], xmm11
00007b78f51dd7c5  vmovaps [rsp+0xB0], xmm12
00007b78f51dd7ce  vmovaps [rsp+0xC0], xmm13
00007b78f51dd7d7  vmovaps [rsp+0xD0], xmm14
00007b78f51dd7e0  vmovaps [rsp+0xE0], xmm15
00007b78f51dd7e9  sub rsp, 0x30
00007b78f51dd7ed  movaps [rsp], xmm6
00007b78f51dd7f1  movaps [rsp+0x10], xmm9
00007b78f51dd7f7  movaps [rsp+0x20], xmm7
00007b78f51dd7fc  lea rdi, [rsp]
00007b78f51dd800  mov esi, 0x00
00007b78f51dd805  mov rax, 0x597478C09530
00007b78f51dd80f  call rax
00007b78f51dd811  movaps xmm6, [rsp]
00007b78f51dd815  add rsp, 0x30
00007b78f51dd819  vmovaps xmm0, [rsp]
00007b78f51dd81e  vmovaps xmm1, [rsp+0x10]
00007b78f51dd824  vmovaps xmm2, [rsp+0x20]
00007b78f51dd82a  vmovaps xmm3, [rsp+0x30]
00007b78f51dd830  vmovaps xmm4, [rsp+0x40]
00007b78f51dd836  vmovaps xmm5, [rsp+0x50]
00007b78f51dd83c  vmovaps xmm7, [rsp+0x60]
00007b78f51dd842  vmovaps xmm8, [rsp+0x70]
00007b78f51dd848  vmovaps xmm9, [rsp+0x80]
00007b78f51dd851  vmovaps xmm10, [rsp+0x90]
00007b78f51dd85a  vmovaps xmm11, [rsp+0xA0]
00007b78f51dd863  vmovaps xmm12, [rsp+0xB0]
00007b78f51dd86c  vmovaps xmm13, [rsp+0xC0]
00007b78f51dd875  vmovaps xmm14, [rsp+0xD0]
00007b78f51dd87e  vmovaps xmm15, [rsp+0xE0]
00007b78f51dd887  add rsp, 0xF0
00007b78f51dd88e  pop r11
00007b78f51dd890  pop r10
00007b78f51dd892  pop r9
00007b78f51dd894  pop r8
00007b78f51dd896  pop rsi
00007b78f51dd897  pop rdi
00007b78f51dd898  pop rdx
00007b78f51dd899  pop rcx
00007b78f51dd89a  pop rax
00007b78f51dd89b  add rsp, 0x08
00007b78f51dd89f  jmp 0x00007B78F51DBE5A
00007b78f51dd8a4  sub rsp, 0x08
00007b78f51dd8a8  push rax
00007b78f51dd8a9  push rcx
00007b78f51dd8aa  push rdx
00007b78f51dd8ab  push rdi
00007b78f51dd8ac  push rsi
00007b78f51dd8ad  push r8
00007b78f51dd8af  push r9
00007b78f51dd8b1  push r10
00007b78f51dd8b3  push r11
00007b78f51dd8b5  sub rsp, 0xF0
00007b78f51dd8bc  vmovaps [rsp], xmm0
00007b78f51dd8c1  vmovaps [rsp+0x10], xmm1
00007b78f51dd8c7  vmovaps [rsp+0x20], xmm2
00007b78f51dd8cd  vmovaps [rsp+0x30], xmm3
00007b78f51dd8d3  vmovaps [rsp+0x40], xmm4
00007b78f51dd8d9  vmovaps [rsp+0x50], xmm5
00007b78f51dd8df  vmovaps [rsp+0x60], xmm6
00007b78f51dd8e5  vmovaps [rsp+0x70], xmm8
00007b78f51dd8eb  vmovaps [rsp+0x80], xmm9
00007b78f51dd8f4  vmovaps [rsp+0x90], xmm10
00007b78f51dd8fd  vmovaps [rsp+0xA0], xmm11
00007b78f51dd906  vmovaps [rsp+0xB0], xmm12
00007b78f51dd90f  vmovaps [rsp+0xC0], xmm13
00007b78f51dd918  vmovaps [rsp+0xD0], xmm14
00007b78f51dd921  vmovaps [rsp+0xE0], xmm15
00007b78f51dd92a  sub rsp, 0x30
00007b78f51dd92e  movaps [rsp], xmm7
00007b78f51dd932  movaps [rsp+0x10], xmm4
00007b78f51dd937  movaps [rsp+0x20], xmm9
00007b78f51dd93d  lea rdi, [rsp]
00007b78f51dd941  mov esi, 0x00
00007b78f51dd946  mov rax, 0x597478C09530
00007b78f51dd950  call rax
00007b78f51dd952  movaps xmm7, [rsp]
00007b78f51dd956  add rsp, 0x30
00007b78f51dd95a  vmovaps xmm0, [rsp]
00007b78f51dd95f  vmovaps xmm1, [rsp+0x10]
00007b78f51dd965  vmovaps xmm2, [rsp+0x20]
00007b78f51dd96b  vmovaps xmm3, [rsp+0x30]
00007b78f51dd971  vmovaps xmm4, [rsp+0x40]
00007b78f51dd977  vmovaps xmm5, [rsp+0x50]
00007b78f51dd97d  vmovaps xmm6, [rsp+0x60]
00007b78f51dd983  vmovaps xmm8, [rsp+0x70]
00007b78f51dd989  vmovaps xmm9, [rsp+0x80]
00007b78f51dd992  vmovaps xmm10, [rsp+0x90]
00007b78f51dd99b  vmovaps xmm11, [rsp+0xA0]
00007b78f51dd9a4  vmovaps xmm12, [rsp+0xB0]
00007b78f51dd9ad  vmovaps xmm13, [rsp+0xC0]
00007b78f51dd9b6  vmovaps xmm14, [rsp+0xD0]
00007b78f51dd9bf  vmovaps xmm15, [rsp+0xE0]
00007b78f51dd9c8  add rsp, 0xF0
00007b78f51dd9cf  pop r11
00007b78f51dd9d1  pop r10
00007b78f51dd9d3  pop r9
00007b78f51dd9d5  pop r8
00007b78f51dd9d7  pop rsi
00007b78f51dd9d8  pop rdi
00007b78f51dd9d9  pop rdx
00007b78f51dd9da  pop rcx
00007b78f51dd9db  pop rax
00007b78f51dd9dc  add rsp, 0x08
00007b78f51dd9e0  jmp 0x00007B78F51DBE87
00007b78f51dd9e5  sub rsp, 0x08
00007b78f51dd9e9  push rax
00007b78f51dd9ea  push rcx
00007b78f51dd9eb  push rdx
00007b78f51dd9ec  push rdi
00007b78f51dd9ed  push rsi
00007b78f51dd9ee  push r8
00007b78f51dd9f0  push r9
00007b78f51dd9f2  push r10
00007b78f51dd9f4  push r11
00007b78f51dd9f6  sub rsp, 0xF0
00007b78f51dd9fd  vmovaps [rsp], xmm0
00007b78f51dda02  vmovaps [rsp+0x10], xmm1
00007b78f51dda08  vmovaps [rsp+0x20], xmm2
00007b78f51dda0e  vmovaps [rsp+0x30], xmm3
00007b78f51dda14  vmovaps [rsp+0x40], xmm5
00007b78f51dda1a  vmovaps [rsp+0x50], xmm6
00007b78f51dda20  vmovaps [rsp+0x60], xmm7
00007b78f51dda26  vmovaps [rsp+0x70], xmm8
00007b78f51dda2c  vmovaps [rsp+0x80], xmm9
00007b78f51dda35  vmovaps [rsp+0x90], xmm10
00007b78f51dda3e  vmovaps [rsp+0xA0], xmm11
00007b78f51dda47  vmovaps [rsp+0xB0], xmm12
00007b78f51dda50  vmovaps [rsp+0xC0], xmm13
00007b78f51dda59  vmovaps [rsp+0xD0], xmm14
00007b78f51dda62  vmovaps [rsp+0xE0], xmm15
00007b78f51dda6b  sub rsp, 0x30
00007b78f51dda6f  movaps [rsp], xmm4
00007b78f51dda73  movaps [rsp+0x10], xmm15
00007b78f51dda79  movaps [rsp+0x20], xmm9
00007b78f51dda7f  lea rdi, [rsp]
00007b78f51dda83  mov esi, 0x00
00007b78f51dda88  mov rax, 0x597478C09530
00007b78f51dda92  call rax
00007b78f51dda94  movaps xmm4, [rsp]
00007b78f51dda98  add rsp, 0x30
00007b78f51dda9c  vmovaps xmm0, [rsp]
00007b78f51ddaa1  vmovaps xmm1, [rsp+0x10]
00007b78f51ddaa7  vmovaps xmm2, [rsp+0x20]
00007b78f51ddaad  vmovaps xmm3, [rsp+0x30]
00007b78f51ddab3  vmovaps xmm5, [rsp+0x40]
00007b78f51ddab9  vmovaps xmm6, [rsp+0x50]
00007b78f51ddabf  vmovaps xmm7, [rsp+0x60]
00007b78f51ddac5  vmovaps xmm8, [rsp+0x70]
00007b78f51ddacb  vmovaps xmm9, [rsp+0x80]
00007b78f51ddad4  vmovaps xmm10, [rsp+0x90]
00007b78f51ddadd  vmovaps xmm11, [rsp+0xA0]
00007b78f51ddae6  vmovaps xmm12, [rsp+0xB0]
00007b78f51ddaef  vmovaps xmm13, [rsp+0xC0]
00007b78f51ddaf8  vmovaps xmm14, [rsp+0xD0]
00007b78f51ddb01  vmovaps xmm15, [rsp+0xE0]
00007b78f51ddb0a  add rsp, 0xF0
00007b78f51ddb11  pop r11
00007b78f51ddb13  pop r10
00007b78f51ddb15  pop r9
00007b78f51ddb17  pop r8
00007b78f51ddb19  pop rsi
00007b78f51ddb1a  pop rdi
00007b78f51ddb1b  pop rdx
00007b78f51ddb1c  pop rcx
00007b78f51ddb1d  pop rax
00007b78f51ddb1e  add rsp, 0x08
00007b78f51ddb22  jmp 0x00007B78F51DBEAC
00007b78f51ddb27  call 0x00007B78F50C4620
00007b78f51ddb2c  jmp 0x00007B78F51DBEB9
00007b78f51ddb31  sub rsp, 0x08
00007b78f51ddb35  push rax
00007b78f51ddb36  push rcx
00007b78f51ddb37  push rdx
00007b78f51ddb38  push rdi
00007b78f51ddb39  push rsi
00007b78f51ddb3a  push r8
00007b78f51ddb3c  push r9
00007b78f51ddb3e  push r10
00007b78f51ddb40  push r11
00007b78f51ddb42  sub rsp, 0xF0
00007b78f51ddb49  vmovaps [rsp], xmm0
00007b78f51ddb4e  vmovaps [rsp+0x10], xmm1
00007b78f51ddb54  vmovaps [rsp+0x20], xmm2
00007b78f51ddb5a  vmovaps [rsp+0x30], xmm4
00007b78f51ddb60  vmovaps [rsp+0x40], xmm5
00007b78f51ddb66  vmovaps [rsp+0x50], xmm6
00007b78f51ddb6c  vmovaps [rsp+0x60], xmm7
00007b78f51ddb72  vmovaps [rsp+0x70], xmm8
00007b78f51ddb78  vmovaps [rsp+0x80], xmm9
00007b78f51ddb81  vmovaps [rsp+0x90], xmm10
00007b78f51ddb8a  vmovaps [rsp+0xA0], xmm11
00007b78f51ddb93  vmovaps [rsp+0xB0], xmm12
00007b78f51ddb9c  vmovaps [rsp+0xC0], xmm13
00007b78f51ddba5  vmovaps [rsp+0xD0], xmm14
00007b78f51ddbae  vmovaps [rsp+0xE0], xmm15
00007b78f51ddbb7  sub rsp, 0x30
00007b78f51ddbbb  movaps [rsp], xmm3
00007b78f51ddbbf  movaps [rsp+0x10], xmm1
00007b78f51ddbc4  movaps [rsp+0x20], xmm9
00007b78f51ddbca  lea rdi, [rsp]
00007b78f51ddbce  mov esi, 0x00
00007b78f51ddbd3  mov rax, 0x597478C09530
00007b78f51ddbdd  call rax
00007b78f51ddbdf  movaps xmm3, [rsp]
00007b78f51ddbe3  add rsp, 0x30
00007b78f51ddbe7  vmovaps xmm0, [rsp]
00007b78f51ddbec  vmovaps xmm1, [rsp+0x10]
00007b78f51ddbf2  vmovaps xmm2, [rsp+0x20]
00007b78f51ddbf8  vmovaps xmm4, [rsp+0x30]
00007b78f51ddbfe  vmovaps xmm5, [rsp+0x40]
00007b78f51ddc04  vmovaps xmm6, [rsp+0x50]
00007b78f51ddc0a  vmovaps xmm7, [rsp+0x60]
00007b78f51ddc10  vmovaps xmm8, [rsp+0x70]
00007b78f51ddc16  vmovaps xmm9, [rsp+0x80]
00007b78f51ddc1f  vmovaps xmm10, [rsp+0x90]
00007b78f51ddc28  vmovaps xmm11, [rsp+0xA0]
00007b78f51ddc31  vmovaps xmm12, [rsp+0xB0]
00007b78f51ddc3a  vmovaps xmm13, [rsp+0xC0]
00007b78f51ddc43  vmovaps xmm14, [rsp+0xD0]
00007b78f51ddc4c  vmovaps xmm15, [rsp+0xE0]
00007b78f51ddc55  add rsp, 0xF0
00007b78f51ddc5c  pop r11
00007b78f51ddc5e  pop r10
00007b78f51ddc60  pop r9
00007b78f51ddc62  pop r8
00007b78f51ddc64  pop rsi
00007b78f51ddc65  pop rdi
00007b78f51ddc66  pop rdx
00007b78f51ddc67  pop rcx
00007b78f51ddc68  pop rax
00007b78f51ddc69  add rsp, 0x08
00007b78f51ddc6d  jmp 0x00007B78F51DBEF6
00007b78f51ddc72  sub rsp, 0x08
00007b78f51ddc76  push rax
00007b78f51ddc77  push rcx
00007b78f51ddc78  push rdx
00007b78f51ddc79  push rdi
00007b78f51ddc7a  push rsi
00007b78f51ddc7b  push r8
00007b78f51ddc7d  push r9
00007b78f51ddc7f  push r10
00007b78f51ddc81  push r11
00007b78f51ddc83  sub rsp, 0xF0
00007b78f51ddc8a  vmovaps [rsp], xmm0
00007b78f51ddc8f  vmovaps [rsp+0x10], xmm2
00007b78f51ddc95  vmovaps [rsp+0x20], xmm3
00007b78f51ddc9b  vmovaps [rsp+0x30], xmm4
00007b78f51ddca1  vmovaps [rsp+0x40], xmm5
00007b78f51ddca7  vmovaps [rsp+0x50], xmm6
00007b78f51ddcad  vmovaps [rsp+0x60], xmm7
00007b78f51ddcb3  vmovaps [rsp+0x70], xmm8
00007b78f51ddcb9  vmovaps [rsp+0x80], xmm9
00007b78f51ddcc2  vmovaps [rsp+0x90], xmm10
00007b78f51ddccb  vmovaps [rsp+0xA0], xmm11
00007b78f51ddcd4  vmovaps [rsp+0xB0], xmm12
00007b78f51ddcdd  vmovaps [rsp+0xC0], xmm13
00007b78f51ddce6  vmovaps [rsp+0xD0], xmm14
00007b78f51ddcef  vmovaps [rsp+0xE0], xmm15
00007b78f51ddcf8  sub rsp, 0x30
00007b78f51ddcfc  movaps [rsp], xmm1
00007b78f51ddd00  movaps [rsp+0x10], xmm15
00007b78f51ddd06  movaps [rsp+0x20], xmm9
00007b78f51ddd0c  lea rdi, [rsp]
00007b78f51ddd10  mov esi, 0x00
00007b78f51ddd15  mov rax, 0x597478C09530
00007b78f51ddd1f  call rax
00007b78f51ddd21  movaps xmm1, [rsp]
00007b78f51ddd25  add rsp, 0x30
00007b78f51ddd29  vmovaps xmm0, [rsp]
00007b78f51ddd2e  vmovaps xmm2, [rsp+0x10]
00007b78f51ddd34  vmovaps xmm3, [rsp+0x20]
00007b78f51ddd3a  vmovaps xmm4, [rsp+0x30]
00007b78f51ddd40  vmovaps xmm5, [rsp+0x40]
00007b78f51ddd46  vmovaps xmm6, [rsp+0x50]
00007b78f51ddd4c  vmovaps xmm7, [rsp+0x60]
00007b78f51ddd52  vmovaps xmm8, [rsp+0x70]
00007b78f51ddd58  vmovaps xmm9, [rsp+0x80]
00007b78f51ddd61  vmovaps xmm10, [rsp+0x90]
00007b78f51ddd6a  vmovaps xmm11, [rsp+0xA0]
00007b78f51ddd73  vmovaps xmm12, [rsp+0xB0]
00007b78f51ddd7c  vmovaps xmm13, [rsp+0xC0]
00007b78f51ddd85  vmovaps xmm14, [rsp+0xD0]
00007b78f51ddd8e  vmovaps xmm15, [rsp+0xE0]
00007b78f51ddd97  add rsp, 0xF0
00007b78f51ddd9e  pop r11
00007b78f51ddda0  pop r10
00007b78f51ddda2  pop r9
00007b78f51ddda4  pop r8
00007b78f51ddda6  pop rsi
00007b78f51ddda7  pop rdi
00007b78f51ddda8  pop rdx
00007b78f51ddda9  pop rcx
00007b78f51dddaa  pop rax
00007b78f51dddab  add rsp, 0x08
00007b78f51dddaf  jmp 0x00007B78F51DBF7E
00007b78f51dddb4  call 0x00007B78F50C4620
00007b78f51dddb9  jmp 0x00007B78F51DBF8B
00007b78f51dddbe  sub rsp, 0x08
00007b78f51dddc2  push rax
00007b78f51dddc3  push rcx
00007b78f51dddc4  push rdx
00007b78f51dddc5  push rdi
00007b78f51dddc6  push rsi
00007b78f51dddc7  push r8
00007b78f51dddc9  push r9
00007b78f51dddcb  push r10
00007b78f51dddcd  push r11
00007b78f51dddcf  sub rsp, 0xF0
00007b78f51dddd6  vmovaps [rsp], xmm0
00007b78f51ddddb  vmovaps [rsp+0x10], xmm2
00007b78f51ddde1  vmovaps [rsp+0x20], xmm3
00007b78f51ddde7  vmovaps [rsp+0x30], xmm4
00007b78f51ddded  vmovaps [rsp+0x40], xmm5
00007b78f51dddf3  vmovaps [rsp+0x50], xmm6
00007b78f51dddf9  vmovaps [rsp+0x60], xmm7
00007b78f51dddff  vmovaps [rsp+0x70], xmm8
00007b78f51dde05  vmovaps [rsp+0x80], xmm9
00007b78f51dde0e  vmovaps [rsp+0x90], xmm10
00007b78f51dde17  vmovaps [rsp+0xA0], xmm11
00007b78f51dde20  vmovaps [rsp+0xB0], xmm12
00007b78f51dde29  vmovaps [rsp+0xC0], xmm13
00007b78f51dde32  vmovaps [rsp+0xD0], xmm14
00007b78f51dde3b  vmovaps [rsp+0xE0], xmm15
00007b78f51dde44  sub rsp, 0x30
00007b78f51dde48  movaps [rsp], xmm1
00007b78f51dde4c  movaps [rsp+0x10], xmm5
00007b78f51dde51  movaps [rsp+0x20], xmm7
00007b78f51dde56  lea rdi, [rsp]
00007b78f51dde5a  mov esi, 0x00
00007b78f51dde5f  mov rax, 0x597478C09530
00007b78f51dde69  call rax
00007b78f51dde6b  movaps xmm1, [rsp]
00007b78f51dde6f  add rsp, 0x30
00007b78f51dde73  vmovaps xmm0, [rsp]
00007b78f51dde78  vmovaps xmm2, [rsp+0x10]
00007b78f51dde7e  vmovaps xmm3, [rsp+0x20]
00007b78f51dde84  vmovaps xmm4, [rsp+0x30]
00007b78f51dde8a  vmovaps xmm5, [rsp+0x40]
00007b78f51dde90  vmovaps xmm6, [rsp+0x50]
00007b78f51dde96  vmovaps xmm7, [rsp+0x60]
00007b78f51dde9c  vmovaps xmm8, [rsp+0x70]
00007b78f51ddea2  vmovaps xmm9, [rsp+0x80]
00007b78f51ddeab  vmovaps xmm10, [rsp+0x90]
00007b78f51ddeb4  vmovaps xmm11, [rsp+0xA0]
00007b78f51ddebd  vmovaps xmm12, [rsp+0xB0]
00007b78f51ddec6  vmovaps xmm13, [rsp+0xC0]
00007b78f51ddecf  vmovaps xmm14, [rsp+0xD0]
00007b78f51dded8  vmovaps xmm15, [rsp+0xE0]
00007b78f51ddee1  add rsp, 0xF0
00007b78f51ddee8  pop r11
00007b78f51ddeea  pop r10
00007b78f51ddeec  pop r9
00007b78f51ddeee  pop r8
00007b78f51ddef0  pop rsi
00007b78f51ddef1  pop rdi
00007b78f51ddef2  pop rdx
00007b78f51ddef3  pop rcx
00007b78f51ddef4  pop rax
00007b78f51ddef5  add rsp, 0x08
00007b78f51ddef9  jmp 0x00007B78F51DC030
00007b78f51ddefe  sub rsp, 0x08
00007b78f51ddf02  push rax
00007b78f51ddf03  push rcx
00007b78f51ddf04  push rdx
00007b78f51ddf05  push rdi
00007b78f51ddf06  push rsi
00007b78f51ddf07  push r8
00007b78f51ddf09  push r9
00007b78f51ddf0b  push r10
00007b78f51ddf0d  push r11
00007b78f51ddf0f  sub rsp, 0xF0
00007b78f51ddf16  vmovaps [rsp], xmm0
00007b78f51ddf1b  vmovaps [rsp+0x10], xmm1
00007b78f51ddf21  vmovaps [rsp+0x20], xmm2
00007b78f51ddf27  vmovaps [rsp+0x30], xmm3
00007b78f51ddf2d  vmovaps [rsp+0x40], xmm4
00007b78f51ddf33  vmovaps [rsp+0x50], xmm5
00007b78f51ddf39  vmovaps [rsp+0x60], xmm6
00007b78f51ddf3f  vmovaps [rsp+0x70], xmm8
00007b78f51ddf45  vmovaps [rsp+0x80], xmm9
00007b78f51ddf4e  vmovaps [rsp+0x90], xmm10
00007b78f51ddf57  vmovaps [rsp+0xA0], xmm11
00007b78f51ddf60  vmovaps [rsp+0xB0], xmm12
00007b78f51ddf69  vmovaps [rsp+0xC0], xmm13
00007b78f51ddf72  vmovaps [rsp+0xD0], xmm14
00007b78f51ddf7b  vmovaps [rsp+0xE0], xmm15
00007b78f51ddf84  sub rsp, 0x30
00007b78f51ddf88  movaps [rsp], xmm7
00007b78f51ddf8c  movaps [rsp+0x10], xmm5
00007b78f51ddf91  movaps [rsp+0x20], xmm15
00007b78f51ddf97  lea rdi, [rsp]
00007b78f51ddf9b  mov esi, 0x00
00007b78f51ddfa0  mov rax, 0x597478C09530
00007b78f51ddfaa  call rax
00007b78f51ddfac  movaps xmm7, [rsp]
00007b78f51ddfb0  add rsp, 0x30
00007b78f51ddfb4  vmovaps xmm0, [rsp]
00007b78f51ddfb9  vmovaps xmm1, [rsp+0x10]
00007b78f51ddfbf  vmovaps xmm2, [rsp+0x20]
00007b78f51ddfc5  vmovaps xmm3, [rsp+0x30]
00007b78f51ddfcb  vmovaps xmm4, [rsp+0x40]
00007b78f51ddfd1  vmovaps xmm5, [rsp+0x50]
00007b78f51ddfd7  vmovaps xmm6, [rsp+0x60]
00007b78f51ddfdd  vmovaps xmm8, [rsp+0x70]
00007b78f51ddfe3  vmovaps xmm9, [rsp+0x80]
00007b78f51ddfec  vmovaps xmm10, [rsp+0x90]
00007b78f51ddff5  vmovaps xmm11, [rsp+0xA0]
00007b78f51ddffe  vmovaps xmm12, [rsp+0xB0]
00007b78f51de007  vmovaps xmm13, [rsp+0xC0]
00007b78f51de010  vmovaps xmm14, [rsp+0xD0]
00007b78f51de019  vmovaps xmm15, [rsp+0xE0]
00007b78f51de022  add rsp, 0xF0
00007b78f51de029  pop r11
00007b78f51de02b  pop r10
00007b78f51de02d  pop r9
00007b78f51de02f  pop r8
00007b78f51de031  pop rsi
00007b78f51de032  pop rdi
00007b78f51de033  pop rdx
00007b78f51de034  pop rcx
00007b78f51de035  pop rax
00007b78f51de036  add rsp, 0x08
00007b78f51de03a  jmp 0x00007B78F51DC066
00007b78f51de03f  call 0x00007B78F50B52F0
00007b78f51de044  jmp 0x00007B78F51DC073
00007b78f51de049  sub rsp, 0x08
00007b78f51de04d  push rax
00007b78f51de04e  push rcx
00007b78f51de04f  push rdx
00007b78f51de050  push rdi
00007b78f51de051  push rsi
00007b78f51de052  push r8
00007b78f51de054  push r9
00007b78f51de056  push r10
00007b78f51de058  push r11
00007b78f51de05a  sub rsp, 0xF0
00007b78f51de061  vmovaps [rsp], xmm0
00007b78f51de066  vmovaps [rsp+0x10], xmm1
00007b78f51de06c  vmovaps [rsp+0x20], xmm2
00007b78f51de072  vmovaps [rsp+0x30], xmm3
00007b78f51de078  vmovaps [rsp+0x40], xmm4
00007b78f51de07e  vmovaps [rsp+0x50], xmm5
00007b78f51de084  vmovaps [rsp+0x60], xmm6
00007b78f51de08a  vmovaps [rsp+0x70], xmm7
00007b78f51de090  vmovaps [rsp+0x80], xmm8
00007b78f51de099  vmovaps [rsp+0x90], xmm9
00007b78f51de0a2  vmovaps [rsp+0xA0], xmm10
00007b78f51de0ab  vmovaps [rsp+0xB0], xmm11
00007b78f51de0b4  vmovaps [rsp+0xC0], xmm12
00007b78f51de0bd  vmovaps [rsp+0xD0], xmm13
00007b78f51de0c6  vmovaps [rsp+0xE0], xmm14
00007b78f51de0cf  sub rsp, 0x30
00007b78f51de0d3  movaps [rsp], xmm15
00007b78f51de0d8  movaps [rsp+0x10], xmm5
00007b78f51de0dd  movaps [rsp+0x20], xmm3
00007b78f51de0e2  lea rdi, [rsp]
00007b78f51de0e6  mov esi, 0x00
00007b78f51de0eb  mov rax, 0x597478C09530
00007b78f51de0f5  call rax
00007b78f51de0f7  movaps xmm15, [rsp]
00007b78f51de0fc  add rsp, 0x30
00007b78f51de100  vmovaps xmm0, [rsp]
00007b78f51de105  vmovaps xmm1, [rsp+0x10]
00007b78f51de10b  vmovaps xmm2, [rsp+0x20]
00007b78f51de111  vmovaps xmm3, [rsp+0x30]
00007b78f51de117  vmovaps xmm4, [rsp+0x40]
00007b78f51de11d  vmovaps xmm5, [rsp+0x50]
00007b78f51de123  vmovaps xmm6, [rsp+0x60]
00007b78f51de129  vmovaps xmm7, [rsp+0x70]
00007b78f51de12f  vmovaps xmm8, [rsp+0x80]
00007b78f51de138  vmovaps xmm9, [rsp+0x90]
00007b78f51de141  vmovaps xmm10, [rsp+0xA0]
00007b78f51de14a  vmovaps xmm11, [rsp+0xB0]
00007b78f51de153  vmovaps xmm12, [rsp+0xC0]
00007b78f51de15c  vmovaps xmm13, [rsp+0xD0]
00007b78f51de165  vmovaps xmm14, [rsp+0xE0]
00007b78f51de16e  add rsp, 0xF0
00007b78f51de175  pop r11
00007b78f51de177  pop r10
00007b78f51de179  pop r9
00007b78f51de17b  pop r8
00007b78f51de17d  pop rsi
00007b78f51de17e  pop rdi
00007b78f51de17f  pop rdx
00007b78f51de180  pop rcx
00007b78f51de181  pop rax
00007b78f51de182  add rsp, 0x08
00007b78f51de186  jmp 0x00007B78F51DC099
00007b78f51de18b  sub rsp, 0x08
00007b78f51de18f  push rax
00007b78f51de190  push rcx
00007b78f51de191  push rdx
00007b78f51de192  push rdi
00007b78f51de193  push rsi
00007b78f51de194  push r8
00007b78f51de196  push r9
00007b78f51de198  push r10
00007b78f51de19a  push r11
00007b78f51de19c  sub rsp, 0xF0
00007b78f51de1a3  vmovaps [rsp], xmm0
00007b78f51de1a8  vmovaps [rsp+0x10], xmm2
00007b78f51de1ae  vmovaps [rsp+0x20], xmm3
00007b78f51de1b4  vmovaps [rsp+0x30], xmm4
00007b78f51de1ba  vmovaps [rsp+0x40], xmm5
00007b78f51de1c0  vmovaps [rsp+0x50], xmm6
00007b78f51de1c6  vmovaps [rsp+0x60], xmm7
00007b78f51de1cc  vmovaps [rsp+0x70], xmm8
00007b78f51de1d2  vmovaps [rsp+0x80], xmm9
00007b78f51de1db  vmovaps [rsp+0x90], xmm10
00007b78f51de1e4  vmovaps [rsp+0xA0], xmm11
00007b78f51de1ed  vmovaps [rsp+0xB0], xmm12
00007b78f51de1f6  vmovaps [rsp+0xC0], xmm13
00007b78f51de1ff  vmovaps [rsp+0xD0], xmm14
00007b78f51de208  vmovaps [rsp+0xE0], xmm15
00007b78f51de211  sub rsp, 0x30
00007b78f51de215  movaps [rsp], xmm1
00007b78f51de219  movaps [rsp+0x10], xmm5
00007b78f51de21e  movaps [rsp+0x20], xmm4
00007b78f51de223  lea rdi, [rsp]
00007b78f51de227  mov esi, 0x00
00007b78f51de22c  mov rax, 0x597478C09530
00007b78f51de236  call rax
00007b78f51de238  movaps xmm1, [rsp]
00007b78f51de23c  add rsp, 0x30
00007b78f51de240  vmovaps xmm0, [rsp]
00007b78f51de245  vmovaps xmm2, [rsp+0x10]
00007b78f51de24b  vmovaps xmm3, [rsp+0x20]
00007b78f51de251  vmovaps xmm4, [rsp+0x30]
00007b78f51de257  vmovaps xmm5, [rsp+0x40]
00007b78f51de25d  vmovaps xmm6, [rsp+0x50]
00007b78f51de263  vmovaps xmm7, [rsp+0x60]
00007b78f51de269  vmovaps xmm8, [rsp+0x70]
00007b78f51de26f  vmovaps xmm9, [rsp+0x80]
00007b78f51de278  vmovaps xmm10, [rsp+0x90]
00007b78f51de281  vmovaps xmm11, [rsp+0xA0]
00007b78f51de28a  vmovaps xmm12, [rsp+0xB0]
00007b78f51de293  vmovaps xmm13, [rsp+0xC0]
00007b78f51de29c  vmovaps xmm14, [rsp+0xD0]
00007b78f51de2a5  vmovaps xmm15, [rsp+0xE0]
00007b78f51de2ae  add rsp, 0xF0
00007b78f51de2b5  pop r11
00007b78f51de2b7  pop r10
00007b78f51de2b9  pop r9
00007b78f51de2bb  pop r8
00007b78f51de2bd  pop rsi
00007b78f51de2be  pop rdi
00007b78f51de2bf  pop rdx
00007b78f51de2c0  pop rcx
00007b78f51de2c1  pop rax
00007b78f51de2c2  add rsp, 0x08
00007b78f51de2c6  jmp 0x00007B78F51DC0B9
00007b78f51de2cb  sub rsp, 0x08
00007b78f51de2cf  push rax
00007b78f51de2d0  push rcx
00007b78f51de2d1  push rdx
00007b78f51de2d2  push rdi
00007b78f51de2d3  push rsi
00007b78f51de2d4  push r8
00007b78f51de2d6  push r9
00007b78f51de2d8  push r10
00007b78f51de2da  push r11
00007b78f51de2dc  sub rsp, 0xF0
00007b78f51de2e3  vmovaps [rsp], xmm0
00007b78f51de2e8  vmovaps [rsp+0x10], xmm1
00007b78f51de2ee  vmovaps [rsp+0x20], xmm2
00007b78f51de2f4  vmovaps [rsp+0x30], xmm3
00007b78f51de2fa  vmovaps [rsp+0x40], xmm5
00007b78f51de300  vmovaps [rsp+0x50], xmm6
00007b78f51de306  vmovaps [rsp+0x60], xmm7
00007b78f51de30c  vmovaps [rsp+0x70], xmm8
00007b78f51de312  vmovaps [rsp+0x80], xmm9
00007b78f51de31b  vmovaps [rsp+0x90], xmm10
00007b78f51de324  vmovaps [rsp+0xA0], xmm11
00007b78f51de32d  vmovaps [rsp+0xB0], xmm12
00007b78f51de336  vmovaps [rsp+0xC0], xmm13
00007b78f51de33f  vmovaps [rsp+0xD0], xmm14
00007b78f51de348  vmovaps [rsp+0xE0], xmm15
00007b78f51de351  sub rsp, 0x30
00007b78f51de355  movaps [rsp], xmm4
00007b78f51de359  movaps [rsp+0x10], xmm3
00007b78f51de35e  movaps [rsp+0x20], xmm5
00007b78f51de363  lea rdi, [rsp]
00007b78f51de367  mov esi, 0x00
00007b78f51de36c  mov rax, 0x597478C09530
00007b78f51de376  call rax
00007b78f51de378  movaps xmm4, [rsp]
00007b78f51de37c  add rsp, 0x30
00007b78f51de380  vmovaps xmm0, [rsp]
00007b78f51de385  vmovaps xmm1, [rsp+0x10]
00007b78f51de38b  vmovaps xmm2, [rsp+0x20]
00007b78f51de391  vmovaps xmm3, [rsp+0x30]
00007b78f51de397  vmovaps xmm5, [rsp+0x40]
00007b78f51de39d  vmovaps xmm6, [rsp+0x50]
00007b78f51de3a3  vmovaps xmm7, [rsp+0x60]
00007b78f51de3a9  vmovaps xmm8, [rsp+0x70]
00007b78f51de3af  vmovaps xmm9, [rsp+0x80]
00007b78f51de3b8  vmovaps xmm10, [rsp+0x90]
00007b78f51de3c1  vmovaps xmm11, [rsp+0xA0]
00007b78f51de3ca  vmovaps xmm12, [rsp+0xB0]
00007b78f51de3d3  vmovaps xmm13, [rsp+0xC0]
00007b78f51de3dc  vmovaps xmm14, [rsp+0xD0]
00007b78f51de3e5  vmovaps xmm15, [rsp+0xE0]
00007b78f51de3ee  add rsp, 0xF0
00007b78f51de3f5  pop r11
00007b78f51de3f7  pop r10
00007b78f51de3f9  pop r9
00007b78f51de3fb  pop r8
00007b78f51de3fd  pop rsi
00007b78f51de3fe  pop rdi
00007b78f51de3ff  pop rdx
00007b78f51de400  pop rcx
00007b78f51de401  pop rax
00007b78f51de402  add rsp, 0x08
00007b78f51de406  jmp 0x00007B78F51DC107
00007b78f51de40b  call 0x00007B78F50B52F0
00007b78f51de410  jmp 0x00007B78F51DC114
00007b78f51de415  sub rsp, 0x08
00007b78f51de419  push rax
00007b78f51de41a  push rcx
00007b78f51de41b  push rdx
00007b78f51de41c  push rdi
00007b78f51de41d  push rsi
00007b78f51de41e  push r8
00007b78f51de420  push r9
00007b78f51de422  push r10
00007b78f51de424  push r11
00007b78f51de426  sub rsp, 0xF0
00007b78f51de42d  vmovaps [rsp], xmm0
00007b78f51de432  vmovaps [rsp+0x10], xmm1
00007b78f51de438  vmovaps [rsp+0x20], xmm2
00007b78f51de43e  vmovaps [rsp+0x30], xmm3
00007b78f51de444  vmovaps [rsp+0x40], xmm4
00007b78f51de44a  vmovaps [rsp+0x50], xmm6
00007b78f51de450  vmovaps [rsp+0x60], xmm7
00007b78f51de456  vmovaps [rsp+0x70], xmm8
00007b78f51de45c  vmovaps [rsp+0x80], xmm9
00007b78f51de465  vmovaps [rsp+0x90], xmm10
00007b78f51de46e  vmovaps [rsp+0xA0], xmm11
00007b78f51de477  vmovaps [rsp+0xB0], xmm12
00007b78f51de480  vmovaps [rsp+0xC0], xmm13
00007b78f51de489  vmovaps [rsp+0xD0], xmm14
00007b78f51de492  vmovaps [rsp+0xE0], xmm15
00007b78f51de49b  sub rsp, 0x30
00007b78f51de49f  movaps [rsp], xmm5
00007b78f51de4a3  movaps [rsp+0x10], xmm6
00007b78f51de4a8  movaps [rsp+0x20], xmm3
00007b78f51de4ad  lea rdi, [rsp]
00007b78f51de4b1  mov esi, 0x00
00007b78f51de4b6  mov rax, 0x597478C09530
00007b78f51de4c0  call rax
00007b78f51de4c2  movaps xmm5, [rsp]
00007b78f51de4c6  add rsp, 0x30
00007b78f51de4ca  vmovaps xmm0, [rsp]
00007b78f51de4cf  vmovaps xmm1, [rsp+0x10]
00007b78f51de4d5  vmovaps xmm2, [rsp+0x20]
00007b78f51de4db  vmovaps xmm3, [rsp+0x30]
00007b78f51de4e1  vmovaps xmm4, [rsp+0x40]
00007b78f51de4e7  vmovaps xmm6, [rsp+0x50]
00007b78f51de4ed  vmovaps xmm7, [rsp+0x60]
00007b78f51de4f3  vmovaps xmm8, [rsp+0x70]
00007b78f51de4f9  vmovaps xmm9, [rsp+0x80]
00007b78f51de502  vmovaps xmm10, [rsp+0x90]
00007b78f51de50b  vmovaps xmm11, [rsp+0xA0]
00007b78f51de514  vmovaps xmm12, [rsp+0xB0]
00007b78f51de51d  vmovaps xmm13, [rsp+0xC0]
00007b78f51de526  vmovaps xmm14, [rsp+0xD0]
00007b78f51de52f  vmovaps xmm15, [rsp+0xE0]
00007b78f51de538  add rsp, 0xF0
00007b78f51de53f  pop r11
00007b78f51de541  pop r10
00007b78f51de543  pop r9
00007b78f51de545  pop r8
00007b78f51de547  pop rsi
00007b78f51de548  pop rdi
00007b78f51de549  pop rdx
00007b78f51de54a  pop rcx
00007b78f51de54b  pop rax
00007b78f51de54c  add rsp, 0x08
00007b78f51de550  jmp 0x00007B78F51DC13A
00007b78f51de555  sub rsp, 0x08
00007b78f51de559  push rax
00007b78f51de55a  push rcx
00007b78f51de55b  push rdx
00007b78f51de55c  push rdi
00007b78f51de55d  push rsi
00007b78f51de55e  push r8
00007b78f51de560  push r9
00007b78f51de562  push r10
00007b78f51de564  push r11
00007b78f51de566  sub rsp, 0xF0
00007b78f51de56d  vmovaps [rsp], xmm0
00007b78f51de572  vmovaps [rsp+0x10], xmm1
00007b78f51de578  vmovaps [rsp+0x20], xmm2
00007b78f51de57e  vmovaps [rsp+0x30], xmm3
00007b78f51de584  vmovaps [rsp+0x40], xmm4
00007b78f51de58a  vmovaps [rsp+0x50], xmm5
00007b78f51de590  vmovaps [rsp+0x60], xmm7
00007b78f51de596  vmovaps [rsp+0x70], xmm8
00007b78f51de59c  vmovaps [rsp+0x80], xmm9
00007b78f51de5a5  vmovaps [rsp+0x90], xmm10
00007b78f51de5ae  vmovaps [rsp+0xA0], xmm11
00007b78f51de5b7  vmovaps [rsp+0xB0], xmm12
00007b78f51de5c0  vmovaps [rsp+0xC0], xmm13
00007b78f51de5c9  vmovaps [rsp+0xD0], xmm14
00007b78f51de5d2  vmovaps [rsp+0xE0], xmm15
00007b78f51de5db  sub rsp, 0x30
00007b78f51de5df  movaps [rsp], xmm6
00007b78f51de5e3  movaps [rsp+0x10], xmm9
00007b78f51de5e9  movaps [rsp+0x20], xmm1
00007b78f51de5ee  lea rdi, [rsp]
00007b78f51de5f2  mov esi, 0x00
00007b78f51de5f7  mov rax, 0x597478C09530
00007b78f51de601  call rax
00007b78f51de603  movaps xmm6, [rsp]
00007b78f51de607  add rsp, 0x30
00007b78f51de60b  vmovaps xmm0, [rsp]
00007b78f51de610  vmovaps xmm1, [rsp+0x10]
00007b78f51de616  vmovaps xmm2, [rsp+0x20]
00007b78f51de61c  vmovaps xmm3, [rsp+0x30]
00007b78f51de622  vmovaps xmm4, [rsp+0x40]
00007b78f51de628  vmovaps xmm5, [rsp+0x50]
00007b78f51de62e  vmovaps xmm7, [rsp+0x60]
00007b78f51de634  vmovaps xmm8, [rsp+0x70]
00007b78f51de63a  vmovaps xmm9, [rsp+0x80]
00007b78f51de643  vmovaps xmm10, [rsp+0x90]
00007b78f51de64c  vmovaps xmm11, [rsp+0xA0]
00007b78f51de655  vmovaps xmm12, [rsp+0xB0]
00007b78f51de65e  vmovaps xmm13, [rsp+0xC0]
00007b78f51de667  vmovaps xmm14, [rsp+0xD0]
00007b78f51de670  vmovaps xmm15, [rsp+0xE0]
00007b78f51de679  add rsp, 0xF0
00007b78f51de680  pop r11
00007b78f51de682  pop r10
00007b78f51de684  pop r9
00007b78f51de686  pop r8
00007b78f51de688  pop rsi
00007b78f51de689  pop rdi
00007b78f51de68a  pop rdx
00007b78f51de68b  pop rcx
00007b78f51de68c  pop rax
00007b78f51de68d  add rsp, 0x08
00007b78f51de691  jmp 0x00007B78F51DC15E
00007b78f51de696  sub rsp, 0x08
00007b78f51de69a  push rax
00007b78f51de69b  push rcx
00007b78f51de69c  push rdx
00007b78f51de69d  push rdi
00007b78f51de69e  push rsi
00007b78f51de69f  push r8
00007b78f51de6a1  push r9
00007b78f51de6a3  push r10
00007b78f51de6a5  push r11
00007b78f51de6a7  sub rsp, 0xF0
00007b78f51de6ae  vmovaps [rsp], xmm0
00007b78f51de6b3  vmovaps [rsp+0x10], xmm1
00007b78f51de6b9  vmovaps [rsp+0x20], xmm2
00007b78f51de6bf  vmovaps [rsp+0x30], xmm3
00007b78f51de6c5  vmovaps [rsp+0x40], xmm4
00007b78f51de6cb  vmovaps [rsp+0x50], xmm5
00007b78f51de6d1  vmovaps [rsp+0x60], xmm6
00007b78f51de6d7  vmovaps [rsp+0x70], xmm7
00007b78f51de6dd  vmovaps [rsp+0x80], xmm8
00007b78f51de6e6  vmovaps [rsp+0x90], xmm10
00007b78f51de6ef  vmovaps [rsp+0xA0], xmm11
00007b78f51de6f8  vmovaps [rsp+0xB0], xmm12
00007b78f51de701  vmovaps [rsp+0xC0], xmm13
00007b78f51de70a  vmovaps [rsp+0xD0], xmm14
00007b78f51de713  vmovaps [rsp+0xE0], xmm15
00007b78f51de71c  sub rsp, 0x30
00007b78f51de720  movaps [rsp], xmm9
00007b78f51de725  movaps [rsp+0x10], xmm3
00007b78f51de72a  movaps [rsp+0x20], xmm1
00007b78f51de72f  lea rdi, [rsp]
00007b78f51de733  mov esi, 0x00
00007b78f51de738  mov rax, 0x597478C09530
00007b78f51de742  call rax
00007b78f51de744  movaps xmm9, [rsp]
00007b78f51de749  add rsp, 0x30
00007b78f51de74d  vmovaps xmm0, [rsp]
00007b78f51de752  vmovaps xmm1, [rsp+0x10]
00007b78f51de758  vmovaps xmm2, [rsp+0x20]
00007b78f51de75e  vmovaps xmm3, [rsp+0x30]
00007b78f51de764  vmovaps xmm4, [rsp+0x40]
00007b78f51de76a  vmovaps xmm5, [rsp+0x50]
00007b78f51de770  vmovaps xmm6, [rsp+0x60]
00007b78f51de776  vmovaps xmm7, [rsp+0x70]
00007b78f51de77c  vmovaps xmm8, [rsp+0x80]
00007b78f51de785  vmovaps xmm10, [rsp+0x90]
00007b78f51de78e  vmovaps xmm11, [rsp+0xA0]
00007b78f51de797  vmovaps xmm12, [rsp+0xB0]
00007b78f51de7a0  vmovaps xmm13, [rsp+0xC0]
00007b78f51de7a9  vmovaps xmm14, [rsp+0xD0]
00007b78f51de7b2  vmovaps xmm15, [rsp+0xE0]
00007b78f51de7bb  add rsp, 0xF0
00007b78f51de7c2  pop r11
00007b78f51de7c4  pop r10
00007b78f51de7c6  pop r9
00007b78f51de7c8  pop r8
00007b78f51de7ca  pop rsi
00007b78f51de7cb  pop rdi
00007b78f51de7cc  pop rdx
00007b78f51de7cd  pop rcx
00007b78f51de7ce  pop rax
00007b78f51de7cf  add rsp, 0x08
00007b78f51de7d3  jmp 0x00007B78F51DC1AA
00007b78f51de7d8  call 0x00007B78F50B52F0
00007b78f51de7dd  jmp 0x00007B78F51DC1B7
00007b78f51de7e2  sub rsp, 0x08
00007b78f51de7e6  push rax
00007b78f51de7e7  push rcx
00007b78f51de7e8  push rdx
00007b78f51de7e9  push rdi
00007b78f51de7ea  push rsi
00007b78f51de7eb  push r8
00007b78f51de7ed  push r9
00007b78f51de7ef  push r10
00007b78f51de7f1  push r11
00007b78f51de7f3  sub rsp, 0xF0
00007b78f51de7fa  vmovaps [rsp], xmm0
00007b78f51de7ff  vmovaps [rsp+0x10], xmm1
00007b78f51de805  vmovaps [rsp+0x20], xmm2
00007b78f51de80b  vmovaps [rsp+0x30], xmm3
00007b78f51de811  vmovaps [rsp+0x40], xmm4
00007b78f51de817  vmovaps [rsp+0x50], xmm5
00007b78f51de81d  vmovaps [rsp+0x60], xmm6
00007b78f51de823  vmovaps [rsp+0x70], xmm7
00007b78f51de829  vmovaps [rsp+0x80], xmm8
00007b78f51de832  vmovaps [rsp+0x90], xmm9
00007b78f51de83b  vmovaps [rsp+0xA0], xmm10
00007b78f51de844  vmovaps [rsp+0xB0], xmm11
00007b78f51de84d  vmovaps [rsp+0xC0], xmm12
00007b78f51de856  vmovaps [rsp+0xD0], xmm13
00007b78f51de85f  vmovaps [rsp+0xE0], xmm14
00007b78f51de868  sub rsp, 0x30
00007b78f51de86c  movaps [rsp], xmm15
00007b78f51de871  movaps [rsp+0x10], xmm3
00007b78f51de876  movaps [rsp+0x20], xmm7
00007b78f51de87b  lea rdi, [rsp]
00007b78f51de87f  mov esi, 0x00
00007b78f51de884  mov rax, 0x597478C09530
00007b78f51de88e  call rax
00007b78f51de890  movaps xmm15, [rsp]
00007b78f51de895  add rsp, 0x30
00007b78f51de899  vmovaps xmm0, [rsp]
00007b78f51de89e  vmovaps xmm1, [rsp+0x10]
00007b78f51de8a4  vmovaps xmm2, [rsp+0x20]
00007b78f51de8aa  vmovaps xmm3, [rsp+0x30]
00007b78f51de8b0  vmovaps xmm4, [rsp+0x40]
00007b78f51de8b6  vmovaps xmm5, [rsp+0x50]
00007b78f51de8bc  vmovaps xmm6, [rsp+0x60]
00007b78f51de8c2  vmovaps xmm7, [rsp+0x70]
00007b78f51de8c8  vmovaps xmm8, [rsp+0x80]
00007b78f51de8d1  vmovaps xmm9, [rsp+0x90]
00007b78f51de8da  vmovaps xmm10, [rsp+0xA0]
00007b78f51de8e3  vmovaps xmm11, [rsp+0xB0]
00007b78f51de8ec  vmovaps xmm12, [rsp+0xC0]
00007b78f51de8f5  vmovaps xmm13, [rsp+0xD0]
00007b78f51de8fe  vmovaps xmm14, [rsp+0xE0]
00007b78f51de907  add rsp, 0xF0
00007b78f51de90e  pop r11
00007b78f51de910  pop r10
00007b78f51de912  pop r9
00007b78f51de914  pop r8
00007b78f51de916  pop rsi
00007b78f51de917  pop rdi
00007b78f51de918  pop rdx
00007b78f51de919  pop rcx
00007b78f51de91a  pop rax
00007b78f51de91b  add rsp, 0x08
00007b78f51de91f  jmp 0x00007B78F51DC1E3
00007b78f51de924  sub rsp, 0x08
00007b78f51de928  push rax
00007b78f51de929  push rcx
00007b78f51de92a  push rdx
00007b78f51de92b  push rdi
00007b78f51de92c  push rsi
00007b78f51de92d  push r8
00007b78f51de92f  push r9
00007b78f51de931  push r10
00007b78f51de933  push r11
00007b78f51de935  sub rsp, 0xF0
00007b78f51de93c  vmovaps [rsp], xmm0
00007b78f51de941  vmovaps [rsp+0x10], xmm1
00007b78f51de947  vmovaps [rsp+0x20], xmm2
00007b78f51de94d  vmovaps [rsp+0x30], xmm4
00007b78f51de953  vmovaps [rsp+0x40], xmm5
00007b78f51de959  vmovaps [rsp+0x50], xmm6
00007b78f51de95f  vmovaps [rsp+0x60], xmm7
00007b78f51de965  vmovaps [rsp+0x70], xmm8
00007b78f51de96b  vmovaps [rsp+0x80], xmm9
00007b78f51de974  vmovaps [rsp+0x90], xmm10
00007b78f51de97d  vmovaps [rsp+0xA0], xmm11
00007b78f51de986  vmovaps [rsp+0xB0], xmm12
00007b78f51de98f  vmovaps [rsp+0xC0], xmm13
00007b78f51de998  vmovaps [rsp+0xD0], xmm14
00007b78f51de9a1  vmovaps [rsp+0xE0], xmm15
00007b78f51de9aa  sub rsp, 0x30
00007b78f51de9ae  movaps [rsp], xmm3
00007b78f51de9b2  movaps [rsp+0x10], xmm1
00007b78f51de9b7  movaps [rsp+0x20], xmm15
00007b78f51de9bd  lea rdi, [rsp]
00007b78f51de9c1  mov esi, 0x00
00007b78f51de9c6  mov rax, 0x597478C09530
00007b78f51de9d0  call rax
00007b78f51de9d2  movaps xmm3, [rsp]
00007b78f51de9d6  add rsp, 0x30
00007b78f51de9da  vmovaps xmm0, [rsp]
00007b78f51de9df  vmovaps xmm1, [rsp+0x10]
00007b78f51de9e5  vmovaps xmm2, [rsp+0x20]
00007b78f51de9eb  vmovaps xmm4, [rsp+0x30]
00007b78f51de9f1  vmovaps xmm5, [rsp+0x40]
00007b78f51de9f7  vmovaps xmm6, [rsp+0x50]
00007b78f51de9fd  vmovaps xmm7, [rsp+0x60]
00007b78f51dea03  vmovaps xmm8, [rsp+0x70]
00007b78f51dea09  vmovaps xmm9, [rsp+0x80]
00007b78f51dea12  vmovaps xmm10, [rsp+0x90]
00007b78f51dea1b  vmovaps xmm11, [rsp+0xA0]
00007b78f51dea24  vmovaps xmm12, [rsp+0xB0]
00007b78f51dea2d  vmovaps xmm13, [rsp+0xC0]
00007b78f51dea36  vmovaps xmm14, [rsp+0xD0]
00007b78f51dea3f  vmovaps xmm15, [rsp+0xE0]
00007b78f51dea48  add rsp, 0xF0
00007b78f51dea4f  pop r11
00007b78f51dea51  pop r10
00007b78f51dea53  pop r9
00007b78f51dea55  pop r8
00007b78f51dea57  pop rsi
00007b78f51dea58  pop rdi
00007b78f51dea59  pop rdx
00007b78f51dea5a  pop rcx
00007b78f51dea5b  pop rax
00007b78f51dea5c  add rsp, 0x08
00007b78f51dea60  jmp 0x00007B78F51DC272
00007b78f51dea65  call 0x00007B78F50B52F0
00007b78f51dea6a  jmp 0x00007B78F51DC27C
00007b78f51dea6f  sub rsp, 0x08
00007b78f51dea73  push rax
00007b78f51dea74  push rcx
00007b78f51dea75  push rdx
00007b78f51dea76  push rdi
00007b78f51dea77  push rsi
00007b78f51dea78  push r8
00007b78f51dea7a  push r9
00007b78f51dea7c  push r10
00007b78f51dea7e  push r11
00007b78f51dea80  sub rsp, 0xF0
00007b78f51dea87  vmovaps [rsp], xmm0
00007b78f51dea8c  vmovaps [rsp+0x10], xmm1
00007b78f51dea92  vmovaps [rsp+0x20], xmm2
00007b78f51dea98  vmovaps [rsp+0x30], xmm3
00007b78f51dea9e  vmovaps [rsp+0x40], xmm4
00007b78f51deaa4  vmovaps [rsp+0x50], xmm5
00007b78f51deaaa  vmovaps [rsp+0x60], xmm6
00007b78f51deab0  vmovaps [rsp+0x70], xmm7
00007b78f51deab6  vmovaps [rsp+0x80], xmm8
00007b78f51deabf  vmovaps [rsp+0x90], xmm9
00007b78f51deac8  vmovaps [rsp+0xA0], xmm10
00007b78f51dead1  vmovaps [rsp+0xB0], xmm11
00007b78f51deada  vmovaps [rsp+0xC0], xmm12
00007b78f51deae3  vmovaps [rsp+0xD0], xmm13
00007b78f51deaec  vmovaps [rsp+0xE0], xmm14
00007b78f51deaf5  sub rsp, 0x30
00007b78f51deaf9  movaps [rsp], xmm15
00007b78f51deafe  movaps [rsp+0x10], xmm14
00007b78f51deb04  movaps [rsp+0x20], xmm4
00007b78f51deb09  lea rdi, [rsp]
00007b78f51deb0d  mov esi, 0x00
00007b78f51deb12  mov rax, 0x597478C09530
00007b78f51deb1c  call rax
00007b78f51deb1e  movaps xmm15, [rsp]
00007b78f51deb23  add rsp, 0x30
00007b78f51deb27  vmovaps xmm0, [rsp]
00007b78f51deb2c  vmovaps xmm1, [rsp+0x10]
00007b78f51deb32  vmovaps xmm2, [rsp+0x20]
00007b78f51deb38  vmovaps xmm3, [rsp+0x30]
00007b78f51deb3e  vmovaps xmm4, [rsp+0x40]
00007b78f51deb44  vmovaps xmm5, [rsp+0x50]
00007b78f51deb4a  vmovaps xmm6, [rsp+0x60]
00007b78f51deb50  vmovaps xmm7, [rsp+0x70]
00007b78f51deb56  vmovaps xmm8, [rsp+0x80]
00007b78f51deb5f  vmovaps xmm9, [rsp+0x90]
00007b78f51deb68  vmovaps xmm10, [rsp+0xA0]
00007b78f51deb71  vmovaps xmm11, [rsp+0xB0]
00007b78f51deb7a  vmovaps xmm12, [rsp+0xC0]
00007b78f51deb83  vmovaps xmm13, [rsp+0xD0]
00007b78f51deb8c  vmovaps xmm14, [rsp+0xE0]
00007b78f51deb95  add rsp, 0xF0
00007b78f51deb9c  pop r11
00007b78f51deb9e  pop r10
00007b78f51deba0  pop r9
00007b78f51deba2  pop r8
00007b78f51deba4  pop rsi
00007b78f51deba5  pop rdi
00007b78f51deba6  pop rdx
00007b78f51deba7  pop rcx
00007b78f51deba8  pop rax
00007b78f51deba9  add rsp, 0x08
00007b78f51debad  jmp 0x00007B78F51DC2AA
00007b78f51debb2  sub rsp, 0x08
00007b78f51debb6  push rax
00007b78f51debb7  push rcx
00007b78f51debb8  push rdx
00007b78f51debb9  push rdi
00007b78f51debba  push rsi
00007b78f51debbb  push r8
00007b78f51debbd  push r9
00007b78f51debbf  push r10
00007b78f51debc1  push r11
00007b78f51debc3  sub rsp, 0xF0
00007b78f51debca  vmovaps [rsp], xmm0
00007b78f51debcf  vmovaps [rsp+0x10], xmm1
00007b78f51debd5  vmovaps [rsp+0x20], xmm2
00007b78f51debdb  vmovaps [rsp+0x30], xmm3
00007b78f51debe1  vmovaps [rsp+0x40], xmm4
00007b78f51debe7  vmovaps [rsp+0x50], xmm5
00007b78f51debed  vmovaps [rsp+0x60], xmm6
00007b78f51debf3  vmovaps [rsp+0x70], xmm7
00007b78f51debf9  vmovaps [rsp+0x80], xmm8
00007b78f51dec02  vmovaps [rsp+0x90], xmm9
00007b78f51dec0b  vmovaps [rsp+0xA0], xmm10
00007b78f51dec14  vmovaps [rsp+0xB0], xmm11
00007b78f51dec1d  vmovaps [rsp+0xC0], xmm12
00007b78f51dec26  vmovaps [rsp+0xD0], xmm13
00007b78f51dec2f  vmovaps [rsp+0xE0], xmm15
00007b78f51dec38  sub rsp, 0x30
00007b78f51dec3c  movaps [rsp], xmm14
00007b78f51dec41  movaps [rsp+0x10], xmm2
00007b78f51dec46  movaps [rsp+0x20], xmm1
00007b78f51dec4b  lea rdi, [rsp]
00007b78f51dec4f  mov esi, 0x00
00007b78f51dec54  mov rax, 0x597478C09530
00007b78f51dec5e  call rax
00007b78f51dec60  movaps xmm14, [rsp]
00007b78f51dec65  add rsp, 0x30
00007b78f51dec69  vmovaps xmm0, [rsp]
00007b78f51dec6e  vmovaps xmm1, [rsp+0x10]
00007b78f51dec74  vmovaps xmm2, [rsp+0x20]
00007b78f51dec7a  vmovaps xmm3, [rsp+0x30]
00007b78f51dec80  vmovaps xmm4, [rsp+0x40]
00007b78f51dec86  vmovaps xmm5, [rsp+0x50]
00007b78f51dec8c  vmovaps xmm6, [rsp+0x60]
00007b78f51dec92  vmovaps xmm7, [rsp+0x70]
00007b78f51dec98  vmovaps xmm8, [rsp+0x80]
00007b78f51deca1  vmovaps xmm9, [rsp+0x90]
00007b78f51decaa  vmovaps xmm10, [rsp+0xA0]
00007b78f51decb3  vmovaps xmm11, [rsp+0xB0]
00007b78f51decbc  vmovaps xmm12, [rsp+0xC0]
00007b78f51decc5  vmovaps xmm13, [rsp+0xD0]
00007b78f51decce  vmovaps xmm15, [rsp+0xE0]
00007b78f51decd7  add rsp, 0xF0
00007b78f51decde  pop r11
00007b78f51dece0  pop r10
00007b78f51dece2  pop r9
00007b78f51dece4  pop r8
00007b78f51dece6  pop rsi
00007b78f51dece7  pop rdi
00007b78f51dece8  pop rdx
00007b78f51dece9  pop rcx
00007b78f51decea  pop rax
00007b78f51deceb  add rsp, 0x08
00007b78f51decef  jmp 0x00007B78F51DC2D0
00007b78f51decf4  sub rsp, 0x08
00007b78f51decf8  push rax
00007b78f51decf9  push rcx
00007b78f51decfa  push rdx
00007b78f51decfb  push rdi
00007b78f51decfc  push rsi
00007b78f51decfd  push r8
00007b78f51decff  push r9
00007b78f51ded01  push r10
00007b78f51ded03  push r11
00007b78f51ded05  sub rsp, 0xF0
00007b78f51ded0c  vmovaps [rsp], xmm0
00007b78f51ded11  vmovaps [rsp+0x10], xmm2
00007b78f51ded17  vmovaps [rsp+0x20], xmm3
00007b78f51ded1d  vmovaps [rsp+0x30], xmm4
00007b78f51ded23  vmovaps [rsp+0x40], xmm5
00007b78f51ded29  vmovaps [rsp+0x50], xmm6
00007b78f51ded2f  vmovaps [rsp+0x60], xmm7
00007b78f51ded35  vmovaps [rsp+0x70], xmm8
00007b78f51ded3b  vmovaps [rsp+0x80], xmm9
00007b78f51ded44  vmovaps [rsp+0x90], xmm10
00007b78f51ded4d  vmovaps [rsp+0xA0], xmm11
00007b78f51ded56  vmovaps [rsp+0xB0], xmm12
00007b78f51ded5f  vmovaps [rsp+0xC0], xmm13
00007b78f51ded68  vmovaps [rsp+0xD0], xmm14
00007b78f51ded71  vmovaps [rsp+0xE0], xmm15
00007b78f51ded7a  sub rsp, 0x30
00007b78f51ded7e  movaps [rsp], xmm1
00007b78f51ded82  movaps [rsp+0x10], xmm4
00007b78f51ded87  movaps [rsp+0x20], xmm9
00007b78f51ded8d  lea rdi, [rsp]
00007b78f51ded91  mov esi, 0x00
00007b78f51ded96  mov rax, 0x597478C09530
00007b78f51deda0  call rax
00007b78f51deda2  movaps xmm1, [rsp]
00007b78f51deda6  add rsp, 0x30
00007b78f51dedaa  vmovaps xmm0, [rsp]
00007b78f51dedaf  vmovaps xmm2, [rsp+0x10]
00007b78f51dedb5  vmovaps xmm3, [rsp+0x20]
00007b78f51dedbb  vmovaps xmm4, [rsp+0x30]
00007b78f51dedc1  vmovaps xmm5, [rsp+0x40]
00007b78f51dedc7  vmovaps xmm6, [rsp+0x50]
00007b78f51dedcd  vmovaps xmm7, [rsp+0x60]
00007b78f51dedd3  vmovaps xmm8, [rsp+0x70]
00007b78f51dedd9  vmovaps xmm9, [rsp+0x80]
00007b78f51dede2  vmovaps xmm10, [rsp+0x90]
00007b78f51dedeb  vmovaps xmm11, [rsp+0xA0]
00007b78f51dedf4  vmovaps xmm12, [rsp+0xB0]
00007b78f51dedfd  vmovaps xmm13, [rsp+0xC0]
00007b78f51dee06  vmovaps xmm14, [rsp+0xD0]
00007b78f51dee0f  vmovaps xmm15, [rsp+0xE0]
00007b78f51dee18  add rsp, 0xF0
00007b78f51dee1f  pop r11
00007b78f51dee21  pop r10
00007b78f51dee23  pop r9
00007b78f51dee25  pop r8
00007b78f51dee27  pop rsi
00007b78f51dee28  pop rdi
00007b78f51dee29  pop rdx
00007b78f51dee2a  pop rcx
00007b78f51dee2b  pop rax
00007b78f51dee2c  add rsp, 0x08
00007b78f51dee30  jmp 0x00007B78F51DC2EE
00007b78f51dee35  sub rsp, 0x08
00007b78f51dee39  push rax
00007b78f51dee3a  push rcx
00007b78f51dee3b  push rdx
00007b78f51dee3c  push rdi
00007b78f51dee3d  push rsi
00007b78f51dee3e  push r8
00007b78f51dee40  push r9
00007b78f51dee42  push r10
00007b78f51dee44  push r11
00007b78f51dee46  sub rsp, 0xF0
00007b78f51dee4d  vmovaps [rsp], xmm0
00007b78f51dee52  vmovaps [rsp+0x10], xmm1
00007b78f51dee58  vmovaps [rsp+0x20], xmm2
00007b78f51dee5e  vmovaps [rsp+0x30], xmm3
00007b78f51dee64  vmovaps [rsp+0x40], xmm5
00007b78f51dee6a  vmovaps [rsp+0x50], xmm6
00007b78f51dee70  vmovaps [rsp+0x60], xmm7
00007b78f51dee76  vmovaps [rsp+0x70], xmm8
00007b78f51dee7c  vmovaps [rsp+0x80], xmm9
00007b78f51dee85  vmovaps [rsp+0x90], xmm10
00007b78f51dee8e  vmovaps [rsp+0xA0], xmm11
00007b78f51dee97  vmovaps [rsp+0xB0], xmm12
00007b78f51deea0  vmovaps [rsp+0xC0], xmm13
00007b78f51deea9  vmovaps [rsp+0xD0], xmm14
00007b78f51deeb2  vmovaps [rsp+0xE0], xmm15
00007b78f51deebb  sub rsp, 0x30
00007b78f51deebf  movaps [rsp], xmm4
00007b78f51deec3  movaps [rsp+0x10], xmm2
00007b78f51deec8  movaps [rsp+0x20], xmm9
00007b78f51deece  lea rdi, [rsp]
00007b78f51deed2  mov esi, 0x00
00007b78f51deed7  mov rax, 0x597478C09530
00007b78f51deee1  call rax
00007b78f51deee3  movaps xmm4, [rsp]
00007b78f51deee7  add rsp, 0x30
00007b78f51deeeb  vmovaps xmm0, [rsp]
00007b78f51deef0  vmovaps xmm1, [rsp+0x10]
00007b78f51deef6  vmovaps xmm2, [rsp+0x20]
00007b78f51deefc  vmovaps xmm3, [rsp+0x30]
00007b78f51def02  vmovaps xmm5, [rsp+0x40]
00007b78f51def08  vmovaps xmm6, [rsp+0x50]
00007b78f51def0e  vmovaps xmm7, [rsp+0x60]
00007b78f51def14  vmovaps xmm8, [rsp+0x70]
00007b78f51def1a  vmovaps xmm9, [rsp+0x80]
00007b78f51def23  vmovaps xmm10, [rsp+0x90]
00007b78f51def2c  vmovaps xmm11, [rsp+0xA0]
00007b78f51def35  vmovaps xmm12, [rsp+0xB0]
00007b78f51def3e  vmovaps xmm13, [rsp+0xC0]
00007b78f51def47  vmovaps xmm14, [rsp+0xD0]
00007b78f51def50  vmovaps xmm15, [rsp+0xE0]
00007b78f51def59  add rsp, 0xF0
00007b78f51def60  pop r11
00007b78f51def62  pop r10
00007b78f51def64  pop r9
00007b78f51def66  pop r8
00007b78f51def68  pop rsi
00007b78f51def69  pop rdi
00007b78f51def6a  pop rdx
00007b78f51def6b  pop rcx
00007b78f51def6c  pop rax
00007b78f51def6d  add rsp, 0x08
00007b78f51def71  jmp 0x00007B78F51DC31E
00007b78f51def76  sub rsp, 0x08
00007b78f51def7a  push rax
00007b78f51def7b  push rcx
00007b78f51def7c  push rdx
00007b78f51def7d  push rdi
00007b78f51def7e  push rsi
00007b78f51def7f  push r8
00007b78f51def81  push r9
00007b78f51def83  push r10
00007b78f51def85  push r11
00007b78f51def87  sub rsp, 0xF0
00007b78f51def8e  vmovaps [rsp], xmm0
00007b78f51def93  vmovaps [rsp+0x10], xmm1
00007b78f51def99  vmovaps [rsp+0x20], xmm2
00007b78f51def9f  vmovaps [rsp+0x30], xmm3
00007b78f51defa5  vmovaps [rsp+0x40], xmm4
00007b78f51defab  vmovaps [rsp+0x50], xmm5
00007b78f51defb1  vmovaps [rsp+0x60], xmm6
00007b78f51defb7  vmovaps [rsp+0x70], xmm7
00007b78f51defbd  vmovaps [rsp+0x80], xmm8
00007b78f51defc6  vmovaps [rsp+0x90], xmm10
00007b78f51defcf  vmovaps [rsp+0xA0], xmm11
00007b78f51defd8  vmovaps [rsp+0xB0], xmm12
00007b78f51defe1  vmovaps [rsp+0xC0], xmm13
00007b78f51defea  vmovaps [rsp+0xD0], xmm14
00007b78f51deff3  vmovaps [rsp+0xE0], xmm15
00007b78f51deffc  sub rsp, 0x30
00007b78f51df000  movaps [rsp], xmm9
00007b78f51df005  movaps [rsp+0x10], xmm2
00007b78f51df00a  movaps [rsp+0x20], xmm1
00007b78f51df00f  lea rdi, [rsp]
00007b78f51df013  mov esi, 0x00
00007b78f51df018  mov rax, 0x597478C09530
00007b78f51df022  call rax
00007b78f51df024  movaps xmm9, [rsp]
00007b78f51df029  add rsp, 0x30
00007b78f51df02d  vmovaps xmm0, [rsp]
00007b78f51df032  vmovaps xmm1, [rsp+0x10]
00007b78f51df038  vmovaps xmm2, [rsp+0x20]
00007b78f51df03e  vmovaps xmm3, [rsp+0x30]
00007b78f51df044  vmovaps xmm4, [rsp+0x40]
00007b78f51df04a  vmovaps xmm5, [rsp+0x50]
00007b78f51df050  vmovaps xmm6, [rsp+0x60]
00007b78f51df056  vmovaps xmm7, [rsp+0x70]
00007b78f51df05c  vmovaps xmm8, [rsp+0x80]
00007b78f51df065  vmovaps xmm10, [rsp+0x90]
00007b78f51df06e  vmovaps xmm11, [rsp+0xA0]
00007b78f51df077  vmovaps xmm12, [rsp+0xB0]
00007b78f51df080  vmovaps xmm13, [rsp+0xC0]
00007b78f51df089  vmovaps xmm14, [rsp+0xD0]
00007b78f51df092  vmovaps xmm15, [rsp+0xE0]
00007b78f51df09b  add rsp, 0xF0
00007b78f51df0a2  pop r11
00007b78f51df0a4  pop r10
00007b78f51df0a6  pop r9
00007b78f51df0a8  pop r8
00007b78f51df0aa  pop rsi
00007b78f51df0ab  pop rdi
00007b78f51df0ac  pop rdx
00007b78f51df0ad  pop rcx
00007b78f51df0ae  pop rax
00007b78f51df0af  add rsp, 0x08
00007b78f51df0b3  jmp 0x00007B78F51DC354
00007b78f51df0b8  sub rsp, 0x08
00007b78f51df0bc  push rax
00007b78f51df0bd  push rcx
00007b78f51df0be  push rdx
00007b78f51df0bf  push rdi
00007b78f51df0c0  push rsi
00007b78f51df0c1  push r8
00007b78f51df0c3  push r9
00007b78f51df0c5  push r10
00007b78f51df0c7  push r11
00007b78f51df0c9  sub rsp, 0xF0
00007b78f51df0d0  vmovaps [rsp], xmm0
00007b78f51df0d5  vmovaps [rsp+0x10], xmm2
00007b78f51df0db  vmovaps [rsp+0x20], xmm3
00007b78f51df0e1  vmovaps [rsp+0x30], xmm4
00007b78f51df0e7  vmovaps [rsp+0x40], xmm5
00007b78f51df0ed  vmovaps [rsp+0x50], xmm6
00007b78f51df0f3  vmovaps [rsp+0x60], xmm7
00007b78f51df0f9  vmovaps [rsp+0x70], xmm8
00007b78f51df0ff  vmovaps [rsp+0x80], xmm9
00007b78f51df108  vmovaps [rsp+0x90], xmm10
00007b78f51df111  vmovaps [rsp+0xA0], xmm11
00007b78f51df11a  vmovaps [rsp+0xB0], xmm12
00007b78f51df123  vmovaps [rsp+0xC0], xmm13
00007b78f51df12c  vmovaps [rsp+0xD0], xmm14
00007b78f51df135  vmovaps [rsp+0xE0], xmm15
00007b78f51df13e  sub rsp, 0x30
00007b78f51df142  movaps [rsp], xmm1
00007b78f51df146  movaps [rsp+0x10], xmm15
00007b78f51df14c  movaps [rsp+0x20], xmm6
00007b78f51df151  lea rdi, [rsp]
00007b78f51df155  mov esi, 0x00
00007b78f51df15a  mov rax, 0x597478C09530
00007b78f51df164  call rax
00007b78f51df166  movaps xmm1, [rsp]
00007b78f51df16a  add rsp, 0x30
00007b78f51df16e  vmovaps xmm0, [rsp]
00007b78f51df173  vmovaps xmm2, [rsp+0x10]
00007b78f51df179  vmovaps xmm3, [rsp+0x20]
00007b78f51df17f  vmovaps xmm4, [rsp+0x30]
00007b78f51df185  vmovaps xmm5, [rsp+0x40]
00007b78f51df18b  vmovaps xmm6, [rsp+0x50]
00007b78f51df191  vmovaps xmm7, [rsp+0x60]
00007b78f51df197  vmovaps xmm8, [rsp+0x70]
00007b78f51df19d  vmovaps xmm9, [rsp+0x80]
00007b78f51df1a6  vmovaps xmm10, [rsp+0x90]
00007b78f51df1af  vmovaps xmm11, [rsp+0xA0]
00007b78f51df1b8  vmovaps xmm12, [rsp+0xB0]
00007b78f51df1c1  vmovaps xmm13, [rsp+0xC0]
00007b78f51df1ca  vmovaps xmm14, [rsp+0xD0]
00007b78f51df1d3  vmovaps xmm15, [rsp+0xE0]
00007b78f51df1dc  add rsp, 0xF0
00007b78f51df1e3  pop r11
00007b78f51df1e5  pop r10
00007b78f51df1e7  pop r9
00007b78f51df1e9  pop r8
00007b78f51df1eb  pop rsi
00007b78f51df1ec  pop rdi
00007b78f51df1ed  pop rdx
00007b78f51df1ee  pop rcx
00007b78f51df1ef  pop rax
00007b78f51df1f0  add rsp, 0x08
00007b78f51df1f4  jmp 0x00007B78F51DC375
00007b78f51df1f9  sub rsp, 0x08
00007b78f51df1fd  push rax
00007b78f51df1fe  push rcx
00007b78f51df1ff  push rdx
00007b78f51df200  push rdi
00007b78f51df201  push rsi
00007b78f51df202  push r8
00007b78f51df204  push r9
00007b78f51df206  push r10
00007b78f51df208  push r11
00007b78f51df20a  sub rsp, 0xF0
00007b78f51df211  vmovaps [rsp], xmm0
00007b78f51df216  vmovaps [rsp+0x10], xmm1
00007b78f51df21c  vmovaps [rsp+0x20], xmm2
00007b78f51df222  vmovaps [rsp+0x30], xmm3
00007b78f51df228  vmovaps [rsp+0x40], xmm4
00007b78f51df22e  vmovaps [rsp+0x50], xmm5
00007b78f51df234  vmovaps [rsp+0x60], xmm6
00007b78f51df23a  vmovaps [rsp+0x70], xmm7
00007b78f51df240  vmovaps [rsp+0x80], xmm8
00007b78f51df249  vmovaps [rsp+0x90], xmm9
00007b78f51df252  vmovaps [rsp+0xA0], xmm10
00007b78f51df25b  vmovaps [rsp+0xB0], xmm11
00007b78f51df264  vmovaps [rsp+0xC0], xmm12
00007b78f51df26d  vmovaps [rsp+0xD0], xmm13
00007b78f51df276  vmovaps [rsp+0xE0], xmm14
00007b78f51df27f  sub rsp, 0x30
00007b78f51df283  movaps [rsp], xmm15
00007b78f51df288  movaps [rsp+0x10], xmm5
00007b78f51df28d  movaps [rsp+0x20], xmm3
00007b78f51df292  lea rdi, [rsp]
00007b78f51df296  mov esi, 0x00
00007b78f51df29b  mov rax, 0x597478C09530
00007b78f51df2a5  call rax
00007b78f51df2a7  movaps xmm15, [rsp]
00007b78f51df2ac  add rsp, 0x30
00007b78f51df2b0  vmovaps xmm0, [rsp]
00007b78f51df2b5  vmovaps xmm1, [rsp+0x10]
00007b78f51df2bb  vmovaps xmm2, [rsp+0x20]
00007b78f51df2c1  vmovaps xmm3, [rsp+0x30]
00007b78f51df2c7  vmovaps xmm4, [rsp+0x40]
00007b78f51df2cd  vmovaps xmm5, [rsp+0x50]
00007b78f51df2d3  vmovaps xmm6, [rsp+0x60]
00007b78f51df2d9  vmovaps xmm7, [rsp+0x70]
00007b78f51df2df  vmovaps xmm8, [rsp+0x80]
00007b78f51df2e8  vmovaps xmm9, [rsp+0x90]
00007b78f51df2f1  vmovaps xmm10, [rsp+0xA0]
00007b78f51df2fa  vmovaps xmm11, [rsp+0xB0]
00007b78f51df303  vmovaps xmm12, [rsp+0xC0]
00007b78f51df30c  vmovaps xmm13, [rsp+0xD0]
00007b78f51df315  vmovaps xmm14, [rsp+0xE0]
00007b78f51df31e  add rsp, 0xF0
00007b78f51df325  pop r11
00007b78f51df327  pop r10
00007b78f51df329  pop r9
00007b78f51df32b  pop r8
00007b78f51df32d  pop rsi
00007b78f51df32e  pop rdi
00007b78f51df32f  pop rdx
00007b78f51df330  pop rcx
00007b78f51df331  pop rax
00007b78f51df332  add rsp, 0x08
00007b78f51df336  jmp 0x00007B78F51DC38F
00007b78f51df33b  sub rsp, 0x08
00007b78f51df33f  push rax
00007b78f51df340  push rcx
00007b78f51df341  push rdx
00007b78f51df342  push rdi
00007b78f51df343  push rsi
00007b78f51df344  push r8
00007b78f51df346  push r9
00007b78f51df348  push r10
00007b78f51df34a  push r11
00007b78f51df34c  sub rsp, 0xF0
00007b78f51df353  vmovaps [rsp], xmm0
00007b78f51df358  vmovaps [rsp+0x10], xmm1
00007b78f51df35e  vmovaps [rsp+0x20], xmm2
00007b78f51df364  vmovaps [rsp+0x30], xmm3
00007b78f51df36a  vmovaps [rsp+0x40], xmm4
00007b78f51df370  vmovaps [rsp+0x50], xmm6
00007b78f51df376  vmovaps [rsp+0x60], xmm7
00007b78f51df37c  vmovaps [rsp+0x70], xmm8
00007b78f51df382  vmovaps [rsp+0x80], xmm9
00007b78f51df38b  vmovaps [rsp+0x90], xmm10
00007b78f51df394  vmovaps [rsp+0xA0], xmm11
00007b78f51df39d  vmovaps [rsp+0xB0], xmm12
00007b78f51df3a6  vmovaps [rsp+0xC0], xmm13
00007b78f51df3af  vmovaps [rsp+0xD0], xmm14
00007b78f51df3b8  vmovaps [rsp+0xE0], xmm15
00007b78f51df3c1  sub rsp, 0x30
00007b78f51df3c5  movaps [rsp], xmm5
00007b78f51df3c9  movaps [rsp+0x10], xmm8
00007b78f51df3cf  movaps [rsp+0x20], xmm6
00007b78f51df3d4  lea rdi, [rsp]
00007b78f51df3d8  mov esi, 0x00
00007b78f51df3dd  mov rax, 0x597478C09530
00007b78f51df3e7  call rax
00007b78f51df3e9  movaps xmm5, [rsp]
00007b78f51df3ed  add rsp, 0x30
00007b78f51df3f1  vmovaps xmm0, [rsp]
00007b78f51df3f6  vmovaps xmm1, [rsp+0x10]
00007b78f51df3fc  vmovaps xmm2, [rsp+0x20]
00007b78f51df402  vmovaps xmm3, [rsp+0x30]
00007b78f51df408  vmovaps xmm4, [rsp+0x40]
00007b78f51df40e  vmovaps xmm6, [rsp+0x50]
00007b78f51df414  vmovaps xmm7, [rsp+0x60]
00007b78f51df41a  vmovaps xmm8, [rsp+0x70]
00007b78f51df420  vmovaps xmm9, [rsp+0x80]
00007b78f51df429  vmovaps xmm10, [rsp+0x90]
00007b78f51df432  vmovaps xmm11, [rsp+0xA0]
00007b78f51df43b  vmovaps xmm12, [rsp+0xB0]
00007b78f51df444  vmovaps xmm13, [rsp+0xC0]
00007b78f51df44d  vmovaps xmm14, [rsp+0xD0]
00007b78f51df456  vmovaps xmm15, [rsp+0xE0]
00007b78f51df45f  add rsp, 0xF0
00007b78f51df466  pop r11
00007b78f51df468  pop r10
00007b78f51df46a  pop r9
00007b78f51df46c  pop r8
00007b78f51df46e  pop rsi
00007b78f51df46f  pop rdi
00007b78f51df470  pop rdx
00007b78f51df471  pop rcx
00007b78f51df472  pop rax
00007b78f51df473  add rsp, 0x08
00007b78f51df477  jmp 0x00007B78F51DC3B3
00007b78f51df47c  sub rsp, 0x08
00007b78f51df480  push rax
00007b78f51df481  push rcx
00007b78f51df482  push rdx
00007b78f51df483  push rdi
00007b78f51df484  push rsi
00007b78f51df485  push r8
00007b78f51df487  push r9
00007b78f51df489  push r10
00007b78f51df48b  push r11
00007b78f51df48d  sub rsp, 0xF0
00007b78f51df494  vmovaps [rsp], xmm0
00007b78f51df499  vmovaps [rsp+0x10], xmm1
00007b78f51df49f  vmovaps [rsp+0x20], xmm2
00007b78f51df4a5  vmovaps [rsp+0x30], xmm3
00007b78f51df4ab  vmovaps [rsp+0x40], xmm4
00007b78f51df4b1  vmovaps [rsp+0x50], xmm5
00007b78f51df4b7  vmovaps [rsp+0x60], xmm7
00007b78f51df4bd  vmovaps [rsp+0x70], xmm8
00007b78f51df4c3  vmovaps [rsp+0x80], xmm9
00007b78f51df4cc  vmovaps [rsp+0x90], xmm10
00007b78f51df4d5  vmovaps [rsp+0xA0], xmm11
00007b78f51df4de  vmovaps [rsp+0xB0], xmm12
00007b78f51df4e7  vmovaps [rsp+0xC0], xmm13
00007b78f51df4f0  vmovaps [rsp+0xD0], xmm14
00007b78f51df4f9  vmovaps [rsp+0xE0], xmm15
00007b78f51df502  sub rsp, 0x30
00007b78f51df506  movaps [rsp], xmm6
00007b78f51df50a  movaps [rsp+0x10], xmm10
00007b78f51df510  movaps [rsp+0x20], xmm8
00007b78f51df516  lea rdi, [rsp]
00007b78f51df51a  mov esi, 0x00
00007b78f51df51f  mov rax, 0x597478C09530
00007b78f51df529  call rax
00007b78f51df52b  movaps xmm6, [rsp]
00007b78f51df52f  add rsp, 0x30
00007b78f51df533  vmovaps xmm0, [rsp]
00007b78f51df538  vmovaps xmm1, [rsp+0x10]
00007b78f51df53e  vmovaps xmm2, [rsp+0x20]
00007b78f51df544  vmovaps xmm3, [rsp+0x30]
00007b78f51df54a  vmovaps xmm4, [rsp+0x40]
00007b78f51df550  vmovaps xmm5, [rsp+0x50]
00007b78f51df556  vmovaps xmm7, [rsp+0x60]
00007b78f51df55c  vmovaps xmm8, [rsp+0x70]
00007b78f51df562  vmovaps xmm9, [rsp+0x80]
00007b78f51df56b  vmovaps xmm10, [rsp+0x90]
00007b78f51df574  vmovaps xmm11, [rsp+0xA0]
00007b78f51df57d  vmovaps xmm12, [rsp+0xB0]
00007b78f51df586  vmovaps xmm13, [rsp+0xC0]
00007b78f51df58f  vmovaps xmm14, [rsp+0xD0]
00007b78f51df598  vmovaps xmm15, [rsp+0xE0]
00007b78f51df5a1  add rsp, 0xF0
00007b78f51df5a8  pop r11
00007b78f51df5aa  pop r10
00007b78f51df5ac  pop r9
00007b78f51df5ae  pop r8
00007b78f51df5b0  pop rsi
00007b78f51df5b1  pop rdi
00007b78f51df5b2  pop rdx
00007b78f51df5b3  pop rcx
00007b78f51df5b4  pop rax
00007b78f51df5b5  add rsp, 0x08
00007b78f51df5b9  jmp 0x00007B78F51DC3D8
00007b78f51df5be  sub rsp, 0x08
00007b78f51df5c2  push rax
00007b78f51df5c3  push rcx
00007b78f51df5c4  push rdx
00007b78f51df5c5  push rdi
00007b78f51df5c6  push rsi
00007b78f51df5c7  push r8
00007b78f51df5c9  push r9
00007b78f51df5cb  push r10
00007b78f51df5cd  push r11
00007b78f51df5cf  sub rsp, 0xF0
00007b78f51df5d6  vmovaps [rsp], xmm0
00007b78f51df5db  vmovaps [rsp+0x10], xmm1
00007b78f51df5e1  vmovaps [rsp+0x20], xmm2
00007b78f51df5e7  vmovaps [rsp+0x30], xmm3
00007b78f51df5ed  vmovaps [rsp+0x40], xmm4
00007b78f51df5f3  vmovaps [rsp+0x50], xmm5
00007b78f51df5f9  vmovaps [rsp+0x60], xmm6
00007b78f51df5ff  vmovaps [rsp+0x70], xmm7
00007b78f51df605  vmovaps [rsp+0x80], xmm8
00007b78f51df60e  vmovaps [rsp+0x90], xmm9
00007b78f51df617  vmovaps [rsp+0xA0], xmm11
00007b78f51df620  vmovaps [rsp+0xB0], xmm12
00007b78f51df629  vmovaps [rsp+0xC0], xmm13
00007b78f51df632  vmovaps [rsp+0xD0], xmm14
00007b78f51df63b  vmovaps [rsp+0xE0], xmm15
00007b78f51df644  sub rsp, 0x30
00007b78f51df648  movaps [rsp], xmm10
00007b78f51df64d  movaps [rsp+0x10], xmm8
00007b78f51df653  movaps [rsp+0x20], xmm14
00007b78f51df659  lea rdi, [rsp]
00007b78f51df65d  mov esi, 0x00
00007b78f51df662  mov rax, 0x597478C09530
00007b78f51df66c  call rax
00007b78f51df66e  movaps xmm10, [rsp]
00007b78f51df673  add rsp, 0x30
00007b78f51df677  vmovaps xmm0, [rsp]
00007b78f51df67c  vmovaps xmm1, [rsp+0x10]
00007b78f51df682  vmovaps xmm2, [rsp+0x20]
00007b78f51df688  vmovaps xmm3, [rsp+0x30]
00007b78f51df68e  vmovaps xmm4, [rsp+0x40]
00007b78f51df694  vmovaps xmm5, [rsp+0x50]
00007b78f51df69a  vmovaps xmm6, [rsp+0x60]
00007b78f51df6a0  vmovaps xmm7, [rsp+0x70]
00007b78f51df6a6  vmovaps xmm8, [rsp+0x80]
00007b78f51df6af  vmovaps xmm9, [rsp+0x90]
00007b78f51df6b8  vmovaps xmm11, [rsp+0xA0]
00007b78f51df6c1  vmovaps xmm12, [rsp+0xB0]
00007b78f51df6ca  vmovaps xmm13, [rsp+0xC0]
00007b78f51df6d3  vmovaps xmm14, [rsp+0xD0]
00007b78f51df6dc  vmovaps xmm15, [rsp+0xE0]
00007b78f51df6e5  add rsp, 0xF0
00007b78f51df6ec  pop r11
00007b78f51df6ee  pop r10
00007b78f51df6f0  pop r9
00007b78f51df6f2  pop r8
00007b78f51df6f4  pop rsi
00007b78f51df6f5  pop rdi
00007b78f51df6f6  pop rdx
00007b78f51df6f7  pop rcx
00007b78f51df6f8  pop rax
00007b78f51df6f9  add rsp, 0x08
00007b78f51df6fd  jmp 0x00007B78F51DC3F8
00007b78f51df702  sub rsp, 0x08
00007b78f51df706  push rax
00007b78f51df707  push rcx
00007b78f51df708  push rdx
00007b78f51df709  push rdi
00007b78f51df70a  push rsi
00007b78f51df70b  push r8
00007b78f51df70d  push r9
00007b78f51df70f  push r10
00007b78f51df711  push r11
00007b78f51df713  sub rsp, 0xF0
00007b78f51df71a  vmovaps [rsp], xmm0
00007b78f51df71f  vmovaps [rsp+0x10], xmm1
00007b78f51df725  vmovaps [rsp+0x20], xmm2
00007b78f51df72b  vmovaps [rsp+0x30], xmm3
00007b78f51df731  vmovaps [rsp+0x40], xmm4
00007b78f51df737  vmovaps [rsp+0x50], xmm5
00007b78f51df73d  vmovaps [rsp+0x60], xmm6
00007b78f51df743  vmovaps [rsp+0x70], xmm7
00007b78f51df749  vmovaps [rsp+0x80], xmm8
00007b78f51df752  vmovaps [rsp+0x90], xmm9
00007b78f51df75b  vmovaps [rsp+0xA0], xmm10
00007b78f51df764  vmovaps [rsp+0xB0], xmm11
00007b78f51df76d  vmovaps [rsp+0xC0], xmm12
00007b78f51df776  vmovaps [rsp+0xD0], xmm13
00007b78f51df77f  vmovaps [rsp+0xE0], xmm15
00007b78f51df788  sub rsp, 0x30
00007b78f51df78c  movaps [rsp], xmm14
00007b78f51df791  movaps [rsp+0x10], xmm8
00007b78f51df797  movaps [rsp+0x20], xmm4
00007b78f51df79c  lea rdi, [rsp]
00007b78f51df7a0  mov esi, 0x00
00007b78f51df7a5  mov rax, 0x597478C09530
00007b78f51df7af  call rax
00007b78f51df7b1  movaps xmm14, [rsp]
00007b78f51df7b6  add rsp, 0x30
00007b78f51df7ba  vmovaps xmm0, [rsp]
00007b78f51df7bf  vmovaps xmm1, [rsp+0x10]
00007b78f51df7c5  vmovaps xmm2, [rsp+0x20]
00007b78f51df7cb  vmovaps xmm3, [rsp+0x30]
00007b78f51df7d1  vmovaps xmm4, [rsp+0x40]
00007b78f51df7d7  vmovaps xmm5, [rsp+0x50]
00007b78f51df7dd  vmovaps xmm6, [rsp+0x60]
00007b78f51df7e3  vmovaps xmm7, [rsp+0x70]
00007b78f51df7e9  vmovaps xmm8, [rsp+0x80]
00007b78f51df7f2  vmovaps xmm9, [rsp+0x90]
00007b78f51df7fb  vmovaps xmm10, [rsp+0xA0]
00007b78f51df804  vmovaps xmm11, [rsp+0xB0]
00007b78f51df80d  vmovaps xmm12, [rsp+0xC0]
00007b78f51df816  vmovaps xmm13, [rsp+0xD0]
00007b78f51df81f  vmovaps xmm15, [rsp+0xE0]
00007b78f51df828  add rsp, 0xF0
00007b78f51df82f  pop r11
00007b78f51df831  pop r10
00007b78f51df833  pop r9
00007b78f51df835  pop r8
00007b78f51df837  pop rsi
00007b78f51df838  pop rdi
00007b78f51df839  pop rdx
00007b78f51df83a  pop rcx
00007b78f51df83b  pop rax
00007b78f51df83c  add rsp, 0x08
00007b78f51df840  jmp 0x00007B78F51DC418
00007b78f51df845  sub rsp, 0x08
00007b78f51df849  push rax
00007b78f51df84a  push rcx
00007b78f51df84b  push rdx
00007b78f51df84c  push rdi
00007b78f51df84d  push rsi
00007b78f51df84e  push r8
00007b78f51df850  push r9
00007b78f51df852  push r10
00007b78f51df854  push r11
00007b78f51df856  sub rsp, 0xF0
00007b78f51df85d  vmovaps [rsp], xmm0
00007b78f51df862  vmovaps [rsp+0x10], xmm1
00007b78f51df868  vmovaps [rsp+0x20], xmm2
00007b78f51df86e  vmovaps [rsp+0x30], xmm3
00007b78f51df874  vmovaps [rsp+0x40], xmm5
00007b78f51df87a  vmovaps [rsp+0x50], xmm6
00007b78f51df880  vmovaps [rsp+0x60], xmm7
00007b78f51df886  vmovaps [rsp+0x70], xmm8
00007b78f51df88c  vmovaps [rsp+0x80], xmm9
00007b78f51df895  vmovaps [rsp+0x90], xmm10
00007b78f51df89e  vmovaps [rsp+0xA0], xmm11
00007b78f51df8a7  vmovaps [rsp+0xB0], xmm12
00007b78f51df8b0  vmovaps [rsp+0xC0], xmm13
00007b78f51df8b9  vmovaps [rsp+0xD0], xmm14
00007b78f51df8c2  vmovaps [rsp+0xE0], xmm15
00007b78f51df8cb  sub rsp, 0x30
00007b78f51df8cf  movaps [rsp], xmm4
00007b78f51df8d3  movaps [rsp+0x10], xmm13
00007b78f51df8d9  movaps [rsp+0x20], xmm8
00007b78f51df8df  lea rdi, [rsp]
00007b78f51df8e3  mov esi, 0x00
00007b78f51df8e8  mov rax, 0x597478C09530
00007b78f51df8f2  call rax
00007b78f51df8f4  movaps xmm4, [rsp]
00007b78f51df8f8  add rsp, 0x30
00007b78f51df8fc  vmovaps xmm0, [rsp]
00007b78f51df901  vmovaps xmm1, [rsp+0x10]
00007b78f51df907  vmovaps xmm2, [rsp+0x20]
00007b78f51df90d  vmovaps xmm3, [rsp+0x30]
00007b78f51df913  vmovaps xmm5, [rsp+0x40]
00007b78f51df919  vmovaps xmm6, [rsp+0x50]
00007b78f51df91f  vmovaps xmm7, [rsp+0x60]
00007b78f51df925  vmovaps xmm8, [rsp+0x70]
00007b78f51df92b  vmovaps xmm9, [rsp+0x80]
00007b78f51df934  vmovaps xmm10, [rsp+0x90]
00007b78f51df93d  vmovaps xmm11, [rsp+0xA0]
00007b78f51df946  vmovaps xmm12, [rsp+0xB0]
00007b78f51df94f  vmovaps xmm13, [rsp+0xC0]
00007b78f51df958  vmovaps xmm14, [rsp+0xD0]
00007b78f51df961  vmovaps xmm15, [rsp+0xE0]
00007b78f51df96a  add rsp, 0xF0
00007b78f51df971  pop r11
00007b78f51df973  pop r10
00007b78f51df975  pop r9
00007b78f51df977  pop r8
00007b78f51df979  pop rsi
00007b78f51df97a  pop rdi
00007b78f51df97b  pop rdx
00007b78f51df97c  pop rcx
00007b78f51df97d  pop rax
00007b78f51df97e  add rsp, 0x08
00007b78f51df982  jmp 0x00007B78F51DC43D
00007b78f51df987  sub rsp, 0x08
00007b78f51df98b  push rax
00007b78f51df98c  push rcx
00007b78f51df98d  push rdx
00007b78f51df98e  push rdi
00007b78f51df98f  push rsi
00007b78f51df990  push r8
00007b78f51df992  push r9
00007b78f51df994  push r10
00007b78f51df996  push r11
00007b78f51df998  sub rsp, 0xF0
00007b78f51df99f  vmovaps [rsp], xmm0
00007b78f51df9a4  vmovaps [rsp+0x10], xmm1
00007b78f51df9aa  vmovaps [rsp+0x20], xmm2
00007b78f51df9b0  vmovaps [rsp+0x30], xmm3
00007b78f51df9b6  vmovaps [rsp+0x40], xmm4
00007b78f51df9bc  vmovaps [rsp+0x50], xmm5
00007b78f51df9c2  vmovaps [rsp+0x60], xmm6
00007b78f51df9c8  vmovaps [rsp+0x70], xmm7
00007b78f51df9ce  vmovaps [rsp+0x80], xmm8
00007b78f51df9d7  vmovaps [rsp+0x90], xmm9
00007b78f51df9e0  vmovaps [rsp+0xA0], xmm10
00007b78f51df9e9  vmovaps [rsp+0xB0], xmm11
00007b78f51df9f2  vmovaps [rsp+0xC0], xmm12
00007b78f51df9fb  vmovaps [rsp+0xD0], xmm14
00007b78f51dfa04  vmovaps [rsp+0xE0], xmm15
00007b78f51dfa0d  sub rsp, 0x30
00007b78f51dfa11  movaps [rsp], xmm13
00007b78f51dfa16  movaps [rsp+0x10], xmm15
00007b78f51dfa1c  movaps [rsp+0x20], xmm9
00007b78f51dfa22  lea rdi, [rsp]
00007b78f51dfa26  mov esi, 0x00
00007b78f51dfa2b  mov rax, 0x597478C09530
00007b78f51dfa35  call rax
00007b78f51dfa37  movaps xmm13, [rsp]
00007b78f51dfa3c  add rsp, 0x30
00007b78f51dfa40  vmovaps xmm0, [rsp]
00007b78f51dfa45  vmovaps xmm1, [rsp+0x10]
00007b78f51dfa4b  vmovaps xmm2, [rsp+0x20]
00007b78f51dfa51  vmovaps xmm3, [rsp+0x30]
00007b78f51dfa57  vmovaps xmm4, [rsp+0x40]
00007b78f51dfa5d  vmovaps xmm5, [rsp+0x50]
00007b78f51dfa63  vmovaps xmm6, [rsp+0x60]
00007b78f51dfa69  vmovaps xmm7, [rsp+0x70]
00007b78f51dfa6f  vmovaps xmm8, [rsp+0x80]
00007b78f51dfa78  vmovaps xmm9, [rsp+0x90]
00007b78f51dfa81  vmovaps xmm10, [rsp+0xA0]
00007b78f51dfa8a  vmovaps xmm11, [rsp+0xB0]
00007b78f51dfa93  vmovaps xmm12, [rsp+0xC0]
00007b78f51dfa9c  vmovaps xmm14, [rsp+0xD0]
00007b78f51dfaa5  vmovaps xmm15, [rsp+0xE0]
00007b78f51dfaae  add rsp, 0xF0
00007b78f51dfab5  pop r11
00007b78f51dfab7  pop r10
00007b78f51dfab9  pop r9
00007b78f51dfabb  pop r8
00007b78f51dfabd  pop rsi
00007b78f51dfabe  pop rdi
00007b78f51dfabf  pop rdx
00007b78f51dfac0  pop rcx
00007b78f51dfac1  pop rax
00007b78f51dfac2  add rsp, 0x08
00007b78f51dfac6  jmp 0x00007B78F51DC458
00007b78f51dfacb  sub rsp, 0x08
00007b78f51dfacf  push rax
00007b78f51dfad0  push rcx
00007b78f51dfad1  push rdx
00007b78f51dfad2  push rdi
00007b78f51dfad3  push rsi
00007b78f51dfad4  push r8
00007b78f51dfad6  push r9
00007b78f51dfad8  push r10
00007b78f51dfada  push r11
00007b78f51dfadc  sub rsp, 0xF0
00007b78f51dfae3  vmovaps [rsp], xmm0
00007b78f51dfae8  vmovaps [rsp+0x10], xmm1
00007b78f51dfaee  vmovaps [rsp+0x20], xmm2
00007b78f51dfaf4  vmovaps [rsp+0x30], xmm3
00007b78f51dfafa  vmovaps [rsp+0x40], xmm4
00007b78f51dfb00  vmovaps [rsp+0x50], xmm5
00007b78f51dfb06  vmovaps [rsp+0x60], xmm6
00007b78f51dfb0c  vmovaps [rsp+0x70], xmm7
00007b78f51dfb12  vmovaps [rsp+0x80], xmm8
00007b78f51dfb1b  vmovaps [rsp+0x90], xmm9
00007b78f51dfb24  vmovaps [rsp+0xA0], xmm10
00007b78f51dfb2d  vmovaps [rsp+0xB0], xmm11
00007b78f51dfb36  vmovaps [rsp+0xC0], xmm12
00007b78f51dfb3f  vmovaps [rsp+0xD0], xmm13
00007b78f51dfb48  vmovaps [rsp+0xE0], xmm14
00007b78f51dfb51  sub rsp, 0x30
00007b78f51dfb55  movaps [rsp], xmm15
00007b78f51dfb5a  movaps [rsp+0x10], xmm1
00007b78f51dfb5f  movaps [rsp+0x20], xmm5
00007b78f51dfb64  lea rdi, [rsp]
00007b78f51dfb68  mov esi, 0x00
00007b78f51dfb6d  mov rax, 0x597478C09530
00007b78f51dfb77  call rax
00007b78f51dfb79  movaps xmm15, [rsp]
00007b78f51dfb7e  add rsp, 0x30
00007b78f51dfb82  vmovaps xmm0, [rsp]
00007b78f51dfb87  vmovaps xmm1, [rsp+0x10]
00007b78f51dfb8d  vmovaps xmm2, [rsp+0x20]
00007b78f51dfb93  vmovaps xmm3, [rsp+0x30]
00007b78f51dfb99  vmovaps xmm4, [rsp+0x40]
00007b78f51dfb9f  vmovaps xmm5, [rsp+0x50]
00007b78f51dfba5  vmovaps xmm6, [rsp+0x60]
00007b78f51dfbab  vmovaps xmm7, [rsp+0x70]
00007b78f51dfbb1  vmovaps xmm8, [rsp+0x80]
00007b78f51dfbba  vmovaps xmm9, [rsp+0x90]
00007b78f51dfbc3  vmovaps xmm10, [rsp+0xA0]
00007b78f51dfbcc  vmovaps xmm11, [rsp+0xB0]
00007b78f51dfbd5  vmovaps xmm12, [rsp+0xC0]
00007b78f51dfbde  vmovaps xmm13, [rsp+0xD0]
00007b78f51dfbe7  vmovaps xmm14, [rsp+0xE0]
00007b78f51dfbf0  add rsp, 0xF0
00007b78f51dfbf7  pop r11
00007b78f51dfbf9  pop r10
00007b78f51dfbfb  pop r9
00007b78f51dfbfd  pop r8
00007b78f51dfbff  pop rsi
00007b78f51dfc00  pop rdi
00007b78f51dfc01  pop rdx
00007b78f51dfc02  pop rcx
00007b78f51dfc03  pop rax
00007b78f51dfc04  add rsp, 0x08
00007b78f51dfc08  jmp 0x00007B78F51DC473
00007b78f51dfc0d  call 0x00007B78F50B52F0
00007b78f51dfc12  jmp 0x00007B78F51DC4CE
00007b78f51dfc17  sub rsp, 0x08
00007b78f51dfc1b  push rax
00007b78f51dfc1c  push rcx
00007b78f51dfc1d  push rdx
00007b78f51dfc1e  push rdi
00007b78f51dfc1f  push rsi
00007b78f51dfc20  push r8
00007b78f51dfc22  push r9
00007b78f51dfc24  push r10
00007b78f51dfc26  push r11
00007b78f51dfc28  sub rsp, 0xF0
00007b78f51dfc2f  vmovaps [rsp], xmm0
00007b78f51dfc34  vmovaps [rsp+0x10], xmm1
00007b78f51dfc3a  vmovaps [rsp+0x20], xmm2
00007b78f51dfc40  vmovaps [rsp+0x30], xmm3
00007b78f51dfc46  vmovaps [rsp+0x40], xmm4
00007b78f51dfc4c  vmovaps [rsp+0x50], xmm5
00007b78f51dfc52  vmovaps [rsp+0x60], xmm6
00007b78f51dfc58  vmovaps [rsp+0x70], xmm7
00007b78f51dfc5e  vmovaps [rsp+0x80], xmm8
00007b78f51dfc67  vmovaps [rsp+0x90], xmm10
00007b78f51dfc70  vmovaps [rsp+0xA0], xmm11
00007b78f51dfc79  vmovaps [rsp+0xB0], xmm12
00007b78f51dfc82  vmovaps [rsp+0xC0], xmm13
00007b78f51dfc8b  vmovaps [rsp+0xD0], xmm14
00007b78f51dfc94  vmovaps [rsp+0xE0], xmm15
00007b78f51dfc9d  sub rsp, 0x30
00007b78f51dfca1  movaps [rsp], xmm9
00007b78f51dfca6  movaps [rsp+0x10], xmm8
00007b78f51dfcac  movaps [rsp+0x20], xmm11
00007b78f51dfcb2  lea rdi, [rsp]
00007b78f51dfcb6  mov esi, 0x00
00007b78f51dfcbb  mov rax, 0x597478C09530
00007b78f51dfcc5  call rax
00007b78f51dfcc7  movaps xmm9, [rsp]
00007b78f51dfccc  add rsp, 0x30
00007b78f51dfcd0  vmovaps xmm0, [rsp]
00007b78f51dfcd5  vmovaps xmm1, [rsp+0x10]
00007b78f51dfcdb  vmovaps xmm2, [rsp+0x20]
00007b78f51dfce1  vmovaps xmm3, [rsp+0x30]
00007b78f51dfce7  vmovaps xmm4, [rsp+0x40]
00007b78f51dfced  vmovaps xmm5, [rsp+0x50]
00007b78f51dfcf3  vmovaps xmm6, [rsp+0x60]
00007b78f51dfcf9  vmovaps xmm7, [rsp+0x70]
00007b78f51dfcff  vmovaps xmm8, [rsp+0x80]
00007b78f51dfd08  vmovaps xmm10, [rsp+0x90]
00007b78f51dfd11  vmovaps xmm11, [rsp+0xA0]
00007b78f51dfd1a  vmovaps xmm12, [rsp+0xB0]
00007b78f51dfd23  vmovaps xmm13, [rsp+0xC0]
00007b78f51dfd2c  vmovaps xmm14, [rsp+0xD0]
00007b78f51dfd35  vmovaps xmm15, [rsp+0xE0]
00007b78f51dfd3e  add rsp, 0xF0
00007b78f51dfd45  pop r11
00007b78f51dfd47  pop r10
00007b78f51dfd49  pop r9
00007b78f51dfd4b  pop r8
00007b78f51dfd4d  pop rsi
00007b78f51dfd4e  pop rdi
00007b78f51dfd4f  pop rdx
00007b78f51dfd50  pop rcx
00007b78f51dfd51  pop rax
00007b78f51dfd52  add rsp, 0x08
00007b78f51dfd56  jmp 0x00007B78F51DC505
00007b78f51dfd5b  sub rsp, 0x08
00007b78f51dfd5f  push rax
00007b78f51dfd60  push rcx
00007b78f51dfd61  push rdx
00007b78f51dfd62  push rdi
00007b78f51dfd63  push rsi
00007b78f51dfd64  push r8
00007b78f51dfd66  push r9
00007b78f51dfd68  push r10
00007b78f51dfd6a  push r11
00007b78f51dfd6c  sub rsp, 0xF0
00007b78f51dfd73  vmovaps [rsp], xmm0
00007b78f51dfd78  vmovaps [rsp+0x10], xmm1
00007b78f51dfd7e  vmovaps [rsp+0x20], xmm2
00007b78f51dfd84  vmovaps [rsp+0x30], xmm3
00007b78f51dfd8a  vmovaps [rsp+0x40], xmm4
00007b78f51dfd90  vmovaps [rsp+0x50], xmm5
00007b78f51dfd96  vmovaps [rsp+0x60], xmm6
00007b78f51dfd9c  vmovaps [rsp+0x70], xmm7
00007b78f51dfda2  vmovaps [rsp+0x80], xmm8
00007b78f51dfdab  vmovaps [rsp+0x90], xmm9
00007b78f51dfdb4  vmovaps [rsp+0xA0], xmm10
00007b78f51dfdbd  vmovaps [rsp+0xB0], xmm12
00007b78f51dfdc6  vmovaps [rsp+0xC0], xmm13
00007b78f51dfdcf  vmovaps [rsp+0xD0], xmm14
00007b78f51dfdd8  vmovaps [rsp+0xE0], xmm15
00007b78f51dfde1  sub rsp, 0x30
00007b78f51dfde5  movaps [rsp], xmm11
00007b78f51dfdea  movaps [rsp+0x10], xmm10
00007b78f51dfdf0  movaps [rsp+0x20], xmm6
00007b78f51dfdf5  lea rdi, [rsp]
00007b78f51dfdf9  mov esi, 0x00
00007b78f51dfdfe  mov rax, 0x597478C09530
00007b78f51dfe08  call rax
00007b78f51dfe0a  movaps xmm11, [rsp]
00007b78f51dfe0f  add rsp, 0x30
00007b78f51dfe13  vmovaps xmm0, [rsp]
00007b78f51dfe18  vmovaps xmm1, [rsp+0x10]
00007b78f51dfe1e  vmovaps xmm2, [rsp+0x20]
00007b78f51dfe24  vmovaps xmm3, [rsp+0x30]
00007b78f51dfe2a  vmovaps xmm4, [rsp+0x40]
00007b78f51dfe30  vmovaps xmm5, [rsp+0x50]
00007b78f51dfe36  vmovaps xmm6, [rsp+0x60]
00007b78f51dfe3c  vmovaps xmm7, [rsp+0x70]
00007b78f51dfe42  vmovaps xmm8, [rsp+0x80]
00007b78f51dfe4b  vmovaps xmm9, [rsp+0x90]
00007b78f51dfe54  vmovaps xmm10, [rsp+0xA0]
00007b78f51dfe5d  vmovaps xmm12, [rsp+0xB0]
00007b78f51dfe66  vmovaps xmm13, [rsp+0xC0]
00007b78f51dfe6f  vmovaps xmm14, [rsp+0xD0]
00007b78f51dfe78  vmovaps xmm15, [rsp+0xE0]
00007b78f51dfe81  add rsp, 0xF0
00007b78f51dfe88  pop r11
00007b78f51dfe8a  pop r10
00007b78f51dfe8c  pop r9
00007b78f51dfe8e  pop r8
00007b78f51dfe90  pop rsi
00007b78f51dfe91  pop rdi
00007b78f51dfe92  pop rdx
00007b78f51dfe93  pop rcx
00007b78f51dfe94  pop rax
00007b78f51dfe95  add rsp, 0x08
00007b78f51dfe99  jmp 0x00007B78F51DC520
00007b78f51dfe9e  sub rsp, 0x08
00007b78f51dfea2  push rax
00007b78f51dfea3  push rcx
00007b78f51dfea4  push rdx
00007b78f51dfea5  push rdi
00007b78f51dfea6  push rsi
00007b78f51dfea7  push r8
00007b78f51dfea9  push r9
00007b78f51dfeab  push r10
00007b78f51dfead  push r11
00007b78f51dfeaf  sub rsp, 0xF0
00007b78f51dfeb6  vmovaps [rsp], xmm0
00007b78f51dfebb  vmovaps [rsp+0x10], xmm1
00007b78f51dfec1  vmovaps [rsp+0x20], xmm2
00007b78f51dfec7  vmovaps [rsp+0x30], xmm3
00007b78f51dfecd  vmovaps [rsp+0x40], xmm4
00007b78f51dfed3  vmovaps [rsp+0x50], xmm5
00007b78f51dfed9  vmovaps [rsp+0x60], xmm6
00007b78f51dfedf  vmovaps [rsp+0x70], xmm7
00007b78f51dfee5  vmovaps [rsp+0x80], xmm8
00007b78f51dfeee  vmovaps [rsp+0x90], xmm9
00007b78f51dfef7  vmovaps [rsp+0xA0], xmm11
00007b78f51dff00  vmovaps [rsp+0xB0], xmm12
00007b78f51dff09  vmovaps [rsp+0xC0], xmm13
00007b78f51dff12  vmovaps [rsp+0xD0], xmm14
00007b78f51dff1b  vmovaps [rsp+0xE0], xmm15
00007b78f51dff24  sub rsp, 0x30
00007b78f51dff28  movaps [rsp], xmm10
00007b78f51dff2d  movaps [rsp+0x10], xmm14
00007b78f51dff33  movaps [rsp+0x20], xmm4
00007b78f51dff38  lea rdi, [rsp]
00007b78f51dff3c  mov esi, 0x00
00007b78f51dff41  mov rax, 0x597478C09530
00007b78f51dff4b  call rax
00007b78f51dff4d  movaps xmm10, [rsp]
00007b78f51dff52  add rsp, 0x30
00007b78f51dff56  vmovaps xmm0, [rsp]
00007b78f51dff5b  vmovaps xmm1, [rsp+0x10]
00007b78f51dff61  vmovaps xmm2, [rsp+0x20]
00007b78f51dff67  vmovaps xmm3, [rsp+0x30]
00007b78f51dff6d  vmovaps xmm4, [rsp+0x40]
00007b78f51dff73  vmovaps xmm5, [rsp+0x50]
00007b78f51dff79  vmovaps xmm6, [rsp+0x60]
00007b78f51dff7f  vmovaps xmm7, [rsp+0x70]
00007b78f51dff85  vmovaps xmm8, [rsp+0x80]
00007b78f51dff8e  vmovaps xmm9, [rsp+0x90]
00007b78f51dff97  vmovaps xmm11, [rsp+0xA0]
00007b78f51dffa0  vmovaps xmm12, [rsp+0xB0]
00007b78f51dffa9  vmovaps xmm13, [rsp+0xC0]
00007b78f51dffb2  vmovaps xmm14, [rsp+0xD0]
00007b78f51dffbb  vmovaps xmm15, [rsp+0xE0]
00007b78f51dffc4  add rsp, 0xF0
00007b78f51dffcb  pop r11
00007b78f51dffcd  pop r10
00007b78f51dffcf  pop r9
00007b78f51dffd1  pop r8
00007b78f51dffd3  pop rsi
00007b78f51dffd4  pop rdi
00007b78f51dffd5  pop rdx
00007b78f51dffd6  pop rcx
00007b78f51dffd7  pop rax
00007b78f51dffd8  add rsp, 0x08
00007b78f51dffdc  jmp 0x00007B78F51DC53B
00007b78f51dffe1  sub rsp, 0x08
00007b78f51dffe5  push rax
00007b78f51dffe6  push rcx
00007b78f51dffe7  push rdx
00007b78f51dffe8  push rdi
00007b78f51dffe9  push rsi
00007b78f51dffea  push r8
00007b78f51dffec  push r9
00007b78f51dffee  push r10
00007b78f51dfff0  push r11
00007b78f51dfff2  sub rsp, 0xF0
00007b78f51dfff9  vmovaps [rsp], xmm0
00007b78f51dfffe  vmovaps [rsp+0x10], xmm1
00007b78f51e0004  vmovaps [rsp+0x20], xmm2
00007b78f51e000a  vmovaps [rsp+0x30], xmm3
00007b78f51e0010  vmovaps [rsp+0x40], xmm4
00007b78f51e0016  vmovaps [rsp+0x50], xmm5
00007b78f51e001c  vmovaps [rsp+0x60], xmm6
00007b78f51e0022  vmovaps [rsp+0x70], xmm7
00007b78f51e0028  vmovaps [rsp+0x80], xmm9
00007b78f51e0031  vmovaps [rsp+0x90], xmm10
00007b78f51e003a  vmovaps [rsp+0xA0], xmm11
00007b78f51e0043  vmovaps [rsp+0xB0], xmm12
00007b78f51e004c  vmovaps [rsp+0xC0], xmm13
00007b78f51e0055  vmovaps [rsp+0xD0], xmm14
00007b78f51e005e  vmovaps [rsp+0xE0], xmm15
00007b78f51e0067  sub rsp, 0x30
00007b78f51e006b  movaps [rsp], xmm8
00007b78f51e0070  movaps [rsp+0x10], xmm1
00007b78f51e0075  movaps [rsp+0x20], xmm14
00007b78f51e007b  lea rdi, [rsp]
00007b78f51e007f  mov esi, 0x00
00007b78f51e0084  mov rax, 0x597478C09530
00007b78f51e008e  call rax
00007b78f51e0090  movaps xmm8, [rsp]
00007b78f51e0095  add rsp, 0x30
00007b78f51e0099  vmovaps xmm0, [rsp]
00007b78f51e009e  vmovaps xmm1, [rsp+0x10]
00007b78f51e00a4  vmovaps xmm2, [rsp+0x20]
00007b78f51e00aa  vmovaps xmm3, [rsp+0x30]
00007b78f51e00b0  vmovaps xmm4, [rsp+0x40]
00007b78f51e00b6  vmovaps xmm5, [rsp+0x50]
00007b78f51e00bc  vmovaps xmm6, [rsp+0x60]
00007b78f51e00c2  vmovaps xmm7, [rsp+0x70]
00007b78f51e00c8  vmovaps xmm9, [rsp+0x80]
00007b78f51e00d1  vmovaps xmm10, [rsp+0x90]
00007b78f51e00da  vmovaps xmm11, [rsp+0xA0]
00007b78f51e00e3  vmovaps xmm12, [rsp+0xB0]
00007b78f51e00ec  vmovaps xmm13, [rsp+0xC0]
00007b78f51e00f5  vmovaps xmm14, [rsp+0xD0]
00007b78f51e00fe  vmovaps xmm15, [rsp+0xE0]
00007b78f51e0107  add rsp, 0xF0
00007b78f51e010e  pop r11
00007b78f51e0110  pop r10
00007b78f51e0112  pop r9
00007b78f51e0114  pop r8
00007b78f51e0116  pop rsi
00007b78f51e0117  pop rdi
00007b78f51e0118  pop rdx
00007b78f51e0119  pop rcx
00007b78f51e011a  pop rax
00007b78f51e011b  add rsp, 0x08
00007b78f51e011f  jmp 0x00007B78F51DC561
00007b78f51e0124  sub rsp, 0x08
00007b78f51e0128  push rax
00007b78f51e0129  push rcx
00007b78f51e012a  push rdx
00007b78f51e012b  push rdi
00007b78f51e012c  push rsi
00007b78f51e012d  push r8
00007b78f51e012f  push r9
00007b78f51e0131  push r10
00007b78f51e0133  push r11
00007b78f51e0135  sub rsp, 0xF0
00007b78f51e013c  vmovaps [rsp], xmm0
00007b78f51e0141  vmovaps [rsp+0x10], xmm1
00007b78f51e0147  vmovaps [rsp+0x20], xmm2
00007b78f51e014d  vmovaps [rsp+0x30], xmm3
00007b78f51e0153  vmovaps [rsp+0x40], xmm4
00007b78f51e0159  vmovaps [rsp+0x50], xmm5
00007b78f51e015f  vmovaps [rsp+0x60], xmm7
00007b78f51e0165  vmovaps [rsp+0x70], xmm8
00007b78f51e016b  vmovaps [rsp+0x80], xmm9
00007b78f51e0174  vmovaps [rsp+0x90], xmm10
00007b78f51e017d  vmovaps [rsp+0xA0], xmm11
00007b78f51e0186  vmovaps [rsp+0xB0], xmm12
00007b78f51e018f  vmovaps [rsp+0xC0], xmm13
00007b78f51e0198  vmovaps [rsp+0xD0], xmm14
00007b78f51e01a1  vmovaps [rsp+0xE0], xmm15
00007b78f51e01aa  sub rsp, 0x30
00007b78f51e01ae  movaps [rsp], xmm6
00007b78f51e01b2  movaps [rsp+0x10], xmm1
00007b78f51e01b7  movaps [rsp+0x20], xmm14
00007b78f51e01bd  lea rdi, [rsp]
00007b78f51e01c1  mov esi, 0x00
00007b78f51e01c6  mov rax, 0x597478C09530
00007b78f51e01d0  call rax
00007b78f51e01d2  movaps xmm6, [rsp]
00007b78f51e01d6  add rsp, 0x30
00007b78f51e01da  vmovaps xmm0, [rsp]
00007b78f51e01df  vmovaps xmm1, [rsp+0x10]
00007b78f51e01e5  vmovaps xmm2, [rsp+0x20]
00007b78f51e01eb  vmovaps xmm3, [rsp+0x30]
00007b78f51e01f1  vmovaps xmm4, [rsp+0x40]
00007b78f51e01f7  vmovaps xmm5, [rsp+0x50]
00007b78f51e01fd  vmovaps xmm7, [rsp+0x60]
00007b78f51e0203  vmovaps xmm8, [rsp+0x70]
00007b78f51e0209  vmovaps xmm9, [rsp+0x80]
00007b78f51e0212  vmovaps xmm10, [rsp+0x90]
00007b78f51e021b  vmovaps xmm11, [rsp+0xA0]
00007b78f51e0224  vmovaps xmm12, [rsp+0xB0]
00007b78f51e022d  vmovaps xmm13, [rsp+0xC0]
00007b78f51e0236  vmovaps xmm14, [rsp+0xD0]
00007b78f51e023f  vmovaps xmm15, [rsp+0xE0]
00007b78f51e0248  add rsp, 0xF0
00007b78f51e024f  pop r11
00007b78f51e0251  pop r10
00007b78f51e0253  pop r9
00007b78f51e0255  pop r8
00007b78f51e0257  pop rsi
00007b78f51e0258  pop rdi
00007b78f51e0259  pop rdx
00007b78f51e025a  pop rcx
00007b78f51e025b  pop rax
00007b78f51e025c  add rsp, 0x08
00007b78f51e0260  jmp 0x00007B78F51DC58D
00007b78f51e0265  sub rsp, 0x08
00007b78f51e0269  push rax
00007b78f51e026a  push rcx
00007b78f51e026b  push rdx
00007b78f51e026c  push rdi
00007b78f51e026d  push rsi
00007b78f51e026e  push r8
00007b78f51e0270  push r9
00007b78f51e0272  push r10
00007b78f51e0274  push r11
00007b78f51e0276  sub rsp, 0xF0
00007b78f51e027d  vmovaps [rsp], xmm0
00007b78f51e0282  vmovaps [rsp+0x10], xmm1
00007b78f51e0288  vmovaps [rsp+0x20], xmm2
00007b78f51e028e  vmovaps [rsp+0x30], xmm3
00007b78f51e0294  vmovaps [rsp+0x40], xmm4
00007b78f51e029a  vmovaps [rsp+0x50], xmm5
00007b78f51e02a0  vmovaps [rsp+0x60], xmm6
00007b78f51e02a6  vmovaps [rsp+0x70], xmm7
00007b78f51e02ac  vmovaps [rsp+0x80], xmm8
00007b78f51e02b5  vmovaps [rsp+0x90], xmm9
00007b78f51e02be  vmovaps [rsp+0xA0], xmm10
00007b78f51e02c7  vmovaps [rsp+0xB0], xmm11
00007b78f51e02d0  vmovaps [rsp+0xC0], xmm12
00007b78f51e02d9  vmovaps [rsp+0xD0], xmm13
00007b78f51e02e2  vmovaps [rsp+0xE0], xmm15
00007b78f51e02eb  sub rsp, 0x30
00007b78f51e02ef  movaps [rsp], xmm14
00007b78f51e02f4  movaps [rsp+0x10], xmm12
00007b78f51e02fa  movaps [rsp+0x20], xmm1
00007b78f51e02ff  lea rdi, [rsp]
00007b78f51e0303  mov esi, 0x00
00007b78f51e0308  mov rax, 0x597478C09530
00007b78f51e0312  call rax
00007b78f51e0314  movaps xmm14, [rsp]
00007b78f51e0319  add rsp, 0x30
00007b78f51e031d  vmovaps xmm0, [rsp]
00007b78f51e0322  vmovaps xmm1, [rsp+0x10]
00007b78f51e0328  vmovaps xmm2, [rsp+0x20]
00007b78f51e032e  vmovaps xmm3, [rsp+0x30]
00007b78f51e0334  vmovaps xmm4, [rsp+0x40]
00007b78f51e033a  vmovaps xmm5, [rsp+0x50]
00007b78f51e0340  vmovaps xmm6, [rsp+0x60]
00007b78f51e0346  vmovaps xmm7, [rsp+0x70]
00007b78f51e034c  vmovaps xmm8, [rsp+0x80]
00007b78f51e0355  vmovaps xmm9, [rsp+0x90]
00007b78f51e035e  vmovaps xmm10, [rsp+0xA0]
00007b78f51e0367  vmovaps xmm11, [rsp+0xB0]
00007b78f51e0370  vmovaps xmm12, [rsp+0xC0]
00007b78f51e0379  vmovaps xmm13, [rsp+0xD0]
00007b78f51e0382  vmovaps xmm15, [rsp+0xE0]
00007b78f51e038b  add rsp, 0xF0
00007b78f51e0392  pop r11
00007b78f51e0394  pop r10
00007b78f51e0396  pop r9
00007b78f51e0398  pop r8
00007b78f51e039a  pop rsi
00007b78f51e039b  pop rdi
00007b78f51e039c  pop rdx
00007b78f51e039d  pop rcx
00007b78f51e039e  pop rax
00007b78f51e039f  add rsp, 0x08
00007b78f51e03a3  jmp 0x00007B78F51DC5B3
00007b78f51e03a8  sub rsp, 0x08
00007b78f51e03ac  push rax
00007b78f51e03ad  push rcx
00007b78f51e03ae  push rdx
00007b78f51e03af  push rdi
00007b78f51e03b0  push rsi
00007b78f51e03b1  push r8
00007b78f51e03b3  push r9
00007b78f51e03b5  push r10
00007b78f51e03b7  push r11
00007b78f51e03b9  sub rsp, 0xF0
00007b78f51e03c0  vmovaps [rsp], xmm0
00007b78f51e03c5  vmovaps [rsp+0x10], xmm2
00007b78f51e03cb  vmovaps [rsp+0x20], xmm3
00007b78f51e03d1  vmovaps [rsp+0x30], xmm4
00007b78f51e03d7  vmovaps [rsp+0x40], xmm5
00007b78f51e03dd  vmovaps [rsp+0x50], xmm6
00007b78f51e03e3  vmovaps [rsp+0x60], xmm7
00007b78f51e03e9  vmovaps [rsp+0x70], xmm8
00007b78f51e03ef  vmovaps [rsp+0x80], xmm9
00007b78f51e03f8  vmovaps [rsp+0x90], xmm10
00007b78f51e0401  vmovaps [rsp+0xA0], xmm11
00007b78f51e040a  vmovaps [rsp+0xB0], xmm12
00007b78f51e0413  vmovaps [rsp+0xC0], xmm13
00007b78f51e041c  vmovaps [rsp+0xD0], xmm14
00007b78f51e0425  vmovaps [rsp+0xE0], xmm15
00007b78f51e042e  sub rsp, 0x30
00007b78f51e0432  movaps [rsp], xmm1
00007b78f51e0436  movaps [rsp+0x10], xmm13
00007b78f51e043c  movaps [rsp+0x20], xmm9
00007b78f51e0442  lea rdi, [rsp]
00007b78f51e0446  mov esi, 0x00
00007b78f51e044b  mov rax, 0x597478C09530
00007b78f51e0455  call rax
00007b78f51e0457  movaps xmm1, [rsp]
00007b78f51e045b  add rsp, 0x30
00007b78f51e045f  vmovaps xmm0, [rsp]
00007b78f51e0464  vmovaps xmm2, [rsp+0x10]
00007b78f51e046a  vmovaps xmm3, [rsp+0x20]
00007b78f51e0470  vmovaps xmm4, [rsp+0x30]
00007b78f51e0476  vmovaps xmm5, [rsp+0x40]
00007b78f51e047c  vmovaps xmm6, [rsp+0x50]
00007b78f51e0482  vmovaps xmm7, [rsp+0x60]
00007b78f51e0488  vmovaps xmm8, [rsp+0x70]
00007b78f51e048e  vmovaps xmm9, [rsp+0x80]
00007b78f51e0497  vmovaps xmm10, [rsp+0x90]
00007b78f51e04a0  vmovaps xmm11, [rsp+0xA0]
00007b78f51e04a9  vmovaps xmm12, [rsp+0xB0]
00007b78f51e04b2  vmovaps xmm13, [rsp+0xC0]
00007b78f51e04bb  vmovaps xmm14, [rsp+0xD0]
00007b78f51e04c4  vmovaps xmm15, [rsp+0xE0]
00007b78f51e04cd  add rsp, 0xF0
00007b78f51e04d4  pop r11
00007b78f51e04d6  pop r10
00007b78f51e04d8  pop r9
00007b78f51e04da  pop r8
00007b78f51e04dc  pop rsi
00007b78f51e04dd  pop rdi
00007b78f51e04de  pop rdx
00007b78f51e04df  pop rcx
00007b78f51e04e0  pop rax
00007b78f51e04e1  add rsp, 0x08
00007b78f51e04e5  jmp 0x00007B78F51DC5CD
00007b78f51e04ea  sub rsp, 0x08
00007b78f51e04ee  push rax
00007b78f51e04ef  push rcx
00007b78f51e04f0  push rdx
00007b78f51e04f1  push rdi
00007b78f51e04f2  push rsi
00007b78f51e04f3  push r8
00007b78f51e04f5  push r9
00007b78f51e04f7  push r10
00007b78f51e04f9  push r11
00007b78f51e04fb  sub rsp, 0xF0
00007b78f51e0502  vmovaps [rsp], xmm0
00007b78f51e0507  vmovaps [rsp+0x10], xmm1
00007b78f51e050d  vmovaps [rsp+0x20], xmm2
00007b78f51e0513  vmovaps [rsp+0x30], xmm3
00007b78f51e0519  vmovaps [rsp+0x40], xmm4
00007b78f51e051f  vmovaps [rsp+0x50], xmm5
00007b78f51e0525  vmovaps [rsp+0x60], xmm6
00007b78f51e052b  vmovaps [rsp+0x70], xmm7
00007b78f51e0531  vmovaps [rsp+0x80], xmm8
00007b78f51e053a  vmovaps [rsp+0x90], xmm9
00007b78f51e0543  vmovaps [rsp+0xA0], xmm10
00007b78f51e054c  vmovaps [rsp+0xB0], xmm11
00007b78f51e0555  vmovaps [rsp+0xC0], xmm13
00007b78f51e055e  vmovaps [rsp+0xD0], xmm14
00007b78f51e0567  vmovaps [rsp+0xE0], xmm15
00007b78f51e0570  sub rsp, 0x30
00007b78f51e0574  movaps [rsp], xmm12
00007b78f51e0579  movaps [rsp+0x10], xmm7
00007b78f51e057e  movaps [rsp+0x20], xmm13
00007b78f51e0584  lea rdi, [rsp]
00007b78f51e0588  mov esi, 0x00
00007b78f51e058d  mov rax, 0x597478C09530
00007b78f51e0597  call rax
00007b78f51e0599  movaps xmm12, [rsp]
00007b78f51e059e  add rsp, 0x30
00007b78f51e05a2  vmovaps xmm0, [rsp]
00007b78f51e05a7  vmovaps xmm1, [rsp+0x10]
00007b78f51e05ad  vmovaps xmm2, [rsp+0x20]
00007b78f51e05b3  vmovaps xmm3, [rsp+0x30]
00007b78f51e05b9  vmovaps xmm4, [rsp+0x40]
00007b78f51e05bf  vmovaps xmm5, [rsp+0x50]
00007b78f51e05c5  vmovaps xmm6, [rsp+0x60]
00007b78f51e05cb  vmovaps xmm7, [rsp+0x70]
00007b78f51e05d1  vmovaps xmm8, [rsp+0x80]
00007b78f51e05da  vmovaps xmm9, [rsp+0x90]
00007b78f51e05e3  vmovaps xmm10, [rsp+0xA0]
00007b78f51e05ec  vmovaps xmm11, [rsp+0xB0]
00007b78f51e05f5  vmovaps xmm13, [rsp+0xC0]
00007b78f51e05fe  vmovaps xmm14, [rsp+0xD0]
00007b78f51e0607  vmovaps xmm15, [rsp+0xE0]
00007b78f51e0610  add rsp, 0xF0
00007b78f51e0617  pop r11
00007b78f51e0619  pop r10
00007b78f51e061b  pop r9
00007b78f51e061d  pop r8
00007b78f51e061f  pop rsi
00007b78f51e0620  pop rdi
00007b78f51e0621  pop rdx
00007b78f51e0622  pop rcx
00007b78f51e0623  pop rax
00007b78f51e0624  add rsp, 0x08
00007b78f51e0628  jmp 0x00007B78F51DC5F4
00007b78f51e062d  sub rsp, 0x08
00007b78f51e0631  push rax
00007b78f51e0632  push rcx
00007b78f51e0633  push rdx
00007b78f51e0634  push rdi
00007b78f51e0635  push rsi
00007b78f51e0636  push r8
00007b78f51e0638  push r9
00007b78f51e063a  push r10
00007b78f51e063c  push r11
00007b78f51e063e  sub rsp, 0xF0
00007b78f51e0645  vmovaps [rsp], xmm0
00007b78f51e064a  vmovaps [rsp+0x10], xmm1
00007b78f51e0650  vmovaps [rsp+0x20], xmm2
00007b78f51e0656  vmovaps [rsp+0x30], xmm3
00007b78f51e065c  vmovaps [rsp+0x40], xmm4
00007b78f51e0662  vmovaps [rsp+0x50], xmm5
00007b78f51e0668  vmovaps [rsp+0x60], xmm6
00007b78f51e066e  vmovaps [rsp+0x70], xmm7
00007b78f51e0674  vmovaps [rsp+0x80], xmm8
00007b78f51e067d  vmovaps [rsp+0x90], xmm9
00007b78f51e0686  vmovaps [rsp+0xA0], xmm10
00007b78f51e068f  vmovaps [rsp+0xB0], xmm11
00007b78f51e0698  vmovaps [rsp+0xC0], xmm12
00007b78f51e06a1  vmovaps [rsp+0xD0], xmm14
00007b78f51e06aa  vmovaps [rsp+0xE0], xmm15
00007b78f51e06b3  sub rsp, 0x30
00007b78f51e06b7  movaps [rsp], xmm13
00007b78f51e06bc  movaps [rsp+0x10], xmm15
00007b78f51e06c2  movaps [rsp+0x20], xmm8
00007b78f51e06c8  lea rdi, [rsp]
00007b78f51e06cc  mov esi, 0x00
00007b78f51e06d1  mov rax, 0x597478C09530
00007b78f51e06db  call rax
00007b78f51e06dd  movaps xmm13, [rsp]
00007b78f51e06e2  add rsp, 0x30
00007b78f51e06e6  vmovaps xmm0, [rsp]
00007b78f51e06eb  vmovaps xmm1, [rsp+0x10]
00007b78f51e06f1  vmovaps xmm2, [rsp+0x20]
00007b78f51e06f7  vmovaps xmm3, [rsp+0x30]
00007b78f51e06fd  vmovaps xmm4, [rsp+0x40]
00007b78f51e0703  vmovaps xmm5, [rsp+0x50]
00007b78f51e0709  vmovaps xmm6, [rsp+0x60]
00007b78f51e070f  vmovaps xmm7, [rsp+0x70]
00007b78f51e0715  vmovaps xmm8, [rsp+0x80]
00007b78f51e071e  vmovaps xmm9, [rsp+0x90]
00007b78f51e0727  vmovaps xmm10, [rsp+0xA0]
00007b78f51e0730  vmovaps xmm11, [rsp+0xB0]
00007b78f51e0739  vmovaps xmm12, [rsp+0xC0]
00007b78f51e0742  vmovaps xmm14, [rsp+0xD0]
00007b78f51e074b  vmovaps xmm15, [rsp+0xE0]
00007b78f51e0754  add rsp, 0xF0
00007b78f51e075b  pop r11
00007b78f51e075d  pop r10
00007b78f51e075f  pop r9
00007b78f51e0761  pop r8
00007b78f51e0763  pop rsi
00007b78f51e0764  pop rdi
00007b78f51e0765  pop rdx
00007b78f51e0766  pop rcx
00007b78f51e0767  pop rax
00007b78f51e0768  add rsp, 0x08
00007b78f51e076c  jmp 0x00007B78F51DC60F
00007b78f51e0771  sub rsp, 0x08
00007b78f51e0775  push rax
00007b78f51e0776  push rcx
00007b78f51e0777  push rdx
00007b78f51e0778  push rdi
00007b78f51e0779  push rsi
00007b78f51e077a  push r8
00007b78f51e077c  push r9
00007b78f51e077e  push r10
00007b78f51e0780  push r11
00007b78f51e0782  sub rsp, 0xF0
00007b78f51e0789  vmovaps [rsp], xmm0
00007b78f51e078e  vmovaps [rsp+0x10], xmm1
00007b78f51e0794  vmovaps [rsp+0x20], xmm2
00007b78f51e079a  vmovaps [rsp+0x30], xmm3
00007b78f51e07a0  vmovaps [rsp+0x40], xmm4
00007b78f51e07a6  vmovaps [rsp+0x50], xmm5
00007b78f51e07ac  vmovaps [rsp+0x60], xmm6
00007b78f51e07b2  vmovaps [rsp+0x70], xmm7
00007b78f51e07b8  vmovaps [rsp+0x80], xmm9
00007b78f51e07c1  vmovaps [rsp+0x90], xmm10
00007b78f51e07ca  vmovaps [rsp+0xA0], xmm11
00007b78f51e07d3  vmovaps [rsp+0xB0], xmm12
00007b78f51e07dc  vmovaps [rsp+0xC0], xmm13
00007b78f51e07e5  vmovaps [rsp+0xD0], xmm14
00007b78f51e07ee  vmovaps [rsp+0xE0], xmm15
00007b78f51e07f7  sub rsp, 0x30
00007b78f51e07fb  movaps [rsp], xmm8
00007b78f51e0800  movaps [rsp+0x10], xmm15
00007b78f51e0806  movaps [rsp+0x20], xmm9
00007b78f51e080c  lea rdi, [rsp]
00007b78f51e0810  mov esi, 0x00
00007b78f51e0815  mov rax, 0x597478C09530
00007b78f51e081f  call rax
00007b78f51e0821  movaps xmm8, [rsp]
00007b78f51e0826  add rsp, 0x30
00007b78f51e082a  vmovaps xmm0, [rsp]
00007b78f51e082f  vmovaps xmm1, [rsp+0x10]
00007b78f51e0835  vmovaps xmm2, [rsp+0x20]
00007b78f51e083b  vmovaps xmm3, [rsp+0x30]
00007b78f51e0841  vmovaps xmm4, [rsp+0x40]
00007b78f51e0847  vmovaps xmm5, [rsp+0x50]
00007b78f51e084d  vmovaps xmm6, [rsp+0x60]
00007b78f51e0853  vmovaps xmm7, [rsp+0x70]
00007b78f51e0859  vmovaps xmm9, [rsp+0x80]
00007b78f51e0862  vmovaps xmm10, [rsp+0x90]
00007b78f51e086b  vmovaps xmm11, [rsp+0xA0]
00007b78f51e0874  vmovaps xmm12, [rsp+0xB0]
00007b78f51e087d  vmovaps xmm13, [rsp+0xC0]
00007b78f51e0886  vmovaps xmm14, [rsp+0xD0]
00007b78f51e088f  vmovaps xmm15, [rsp+0xE0]
00007b78f51e0898  add rsp, 0xF0
00007b78f51e089f  pop r11
00007b78f51e08a1  pop r10
00007b78f51e08a3  pop r9
00007b78f51e08a5  pop r8
00007b78f51e08a7  pop rsi
00007b78f51e08a8  pop rdi
00007b78f51e08a9  pop rdx
00007b78f51e08aa  pop rcx
00007b78f51e08ab  pop rax
00007b78f51e08ac  add rsp, 0x08
00007b78f51e08b0  jmp 0x00007B78F51DC63D
00007b78f51e08b5  sub rsp, 0x08
00007b78f51e08b9  push rax
00007b78f51e08ba  push rcx
00007b78f51e08bb  push rdx
00007b78f51e08bc  push rdi
00007b78f51e08bd  push rsi
00007b78f51e08be  push r8
00007b78f51e08c0  push r9
00007b78f51e08c2  push r10
00007b78f51e08c4  push r11
00007b78f51e08c6  sub rsp, 0xF0
00007b78f51e08cd  vmovaps [rsp], xmm0
00007b78f51e08d2  vmovaps [rsp+0x10], xmm1
00007b78f51e08d8  vmovaps [rsp+0x20], xmm2
00007b78f51e08de  vmovaps [rsp+0x30], xmm3
00007b78f51e08e4  vmovaps [rsp+0x40], xmm4
00007b78f51e08ea  vmovaps [rsp+0x50], xmm5
00007b78f51e08f0  vmovaps [rsp+0x60], xmm6
00007b78f51e08f6  vmovaps [rsp+0x70], xmm7
00007b78f51e08fc  vmovaps [rsp+0x80], xmm8
00007b78f51e0905  vmovaps [rsp+0x90], xmm9
00007b78f51e090e  vmovaps [rsp+0xA0], xmm10
00007b78f51e0917  vmovaps [rsp+0xB0], xmm11
00007b78f51e0920  vmovaps [rsp+0xC0], xmm12
00007b78f51e0929  vmovaps [rsp+0xD0], xmm13
00007b78f51e0932  vmovaps [rsp+0xE0], xmm14
00007b78f51e093b  sub rsp, 0x30
00007b78f51e093f  movaps [rsp], xmm15
00007b78f51e0944  movaps [rsp+0x10], xmm11
00007b78f51e094a  movaps [rsp+0x20], xmm6
00007b78f51e094f  lea rdi, [rsp]
00007b78f51e0953  mov esi, 0x00
00007b78f51e0958  mov rax, 0x597478C09530
00007b78f51e0962  call rax
00007b78f51e0964  movaps xmm15, [rsp]
00007b78f51e0969  add rsp, 0x30
00007b78f51e096d  vmovaps xmm0, [rsp]
00007b78f51e0972  vmovaps xmm1, [rsp+0x10]
00007b78f51e0978  vmovaps xmm2, [rsp+0x20]
00007b78f51e097e  vmovaps xmm3, [rsp+0x30]
00007b78f51e0984  vmovaps xmm4, [rsp+0x40]
00007b78f51e098a  vmovaps xmm5, [rsp+0x50]
00007b78f51e0990  vmovaps xmm6, [rsp+0x60]
00007b78f51e0996  vmovaps xmm7, [rsp+0x70]
00007b78f51e099c  vmovaps xmm8, [rsp+0x80]
00007b78f51e09a5  vmovaps xmm9, [rsp+0x90]
00007b78f51e09ae  vmovaps xmm10, [rsp+0xA0]
00007b78f51e09b7  vmovaps xmm11, [rsp+0xB0]
00007b78f51e09c0  vmovaps xmm12, [rsp+0xC0]
00007b78f51e09c9  vmovaps xmm13, [rsp+0xD0]
00007b78f51e09d2  vmovaps xmm14, [rsp+0xE0]
00007b78f51e09db  add rsp, 0xF0
00007b78f51e09e2  pop r11
00007b78f51e09e4  pop r10
00007b78f51e09e6  pop r9
00007b78f51e09e8  pop r8
00007b78f51e09ea  pop rsi
00007b78f51e09eb  pop rdi
00007b78f51e09ec  pop rdx
00007b78f51e09ed  pop rcx
00007b78f51e09ee  pop rax
00007b78f51e09ef  add rsp, 0x08
00007b78f51e09f3  jmp 0x00007B78F51DC658
00007b78f51e09f8  sub rsp, 0x08
00007b78f51e09fc  push rax
00007b78f51e09fd  push rcx
00007b78f51e09fe  push rdx
00007b78f51e09ff  push rdi
00007b78f51e0a00  push rsi
00007b78f51e0a01  push r8
00007b78f51e0a03  push r9
00007b78f51e0a05  push r10
00007b78f51e0a07  push r11
00007b78f51e0a09  sub rsp, 0xF0
00007b78f51e0a10  vmovaps [rsp], xmm0
00007b78f51e0a15  vmovaps [rsp+0x10], xmm1
00007b78f51e0a1b  vmovaps [rsp+0x20], xmm2
00007b78f51e0a21  vmovaps [rsp+0x30], xmm3
00007b78f51e0a27  vmovaps [rsp+0x40], xmm4
00007b78f51e0a2d  vmovaps [rsp+0x50], xmm5
00007b78f51e0a33  vmovaps [rsp+0x60], xmm6
00007b78f51e0a39  vmovaps [rsp+0x70], xmm8
00007b78f51e0a3f  vmovaps [rsp+0x80], xmm9
00007b78f51e0a48  vmovaps [rsp+0x90], xmm10
00007b78f51e0a51  vmovaps [rsp+0xA0], xmm11
00007b78f51e0a5a  vmovaps [rsp+0xB0], xmm12
00007b78f51e0a63  vmovaps [rsp+0xC0], xmm13
00007b78f51e0a6c  vmovaps [rsp+0xD0], xmm14
00007b78f51e0a75  vmovaps [rsp+0xE0], xmm15
00007b78f51e0a7e  sub rsp, 0x30
00007b78f51e0a82  movaps [rsp], xmm7
00007b78f51e0a86  movaps [rsp+0x10], xmm11
00007b78f51e0a8c  movaps [rsp+0x20], xmm9
00007b78f51e0a92  lea rdi, [rsp]
00007b78f51e0a96  mov esi, 0x00
00007b78f51e0a9b  mov rax, 0x597478C09530
00007b78f51e0aa5  call rax
00007b78f51e0aa7  movaps xmm7, [rsp]
00007b78f51e0aab  add rsp, 0x30
00007b78f51e0aaf  vmovaps xmm0, [rsp]
00007b78f51e0ab4  vmovaps xmm1, [rsp+0x10]
00007b78f51e0aba  vmovaps xmm2, [rsp+0x20]
00007b78f51e0ac0  vmovaps xmm3, [rsp+0x30]
00007b78f51e0ac6  vmovaps xmm4, [rsp+0x40]
00007b78f51e0acc  vmovaps xmm5, [rsp+0x50]
00007b78f51e0ad2  vmovaps xmm6, [rsp+0x60]
00007b78f51e0ad8  vmovaps xmm8, [rsp+0x70]
00007b78f51e0ade  vmovaps xmm9, [rsp+0x80]
00007b78f51e0ae7  vmovaps xmm10, [rsp+0x90]
00007b78f51e0af0  vmovaps xmm11, [rsp+0xA0]
00007b78f51e0af9  vmovaps xmm12, [rsp+0xB0]
00007b78f51e0b02  vmovaps xmm13, [rsp+0xC0]
00007b78f51e0b0b  vmovaps xmm14, [rsp+0xD0]
00007b78f51e0b14  vmovaps xmm15, [rsp+0xE0]
00007b78f51e0b1d  add rsp, 0xF0
00007b78f51e0b24  pop r11
00007b78f51e0b26  pop r10
00007b78f51e0b28  pop r9
00007b78f51e0b2a  pop r8
00007b78f51e0b2c  pop rsi
00007b78f51e0b2d  pop rdi
00007b78f51e0b2e  pop rdx
00007b78f51e0b2f  pop rcx
00007b78f51e0b30  pop rax
00007b78f51e0b31  add rsp, 0x08
00007b78f51e0b35  jmp 0x00007B78F51DC685
00007b78f51e0b3a  sub rsp, 0x08
00007b78f51e0b3e  push rax
00007b78f51e0b3f  push rcx
00007b78f51e0b40  push rdx
00007b78f51e0b41  push rdi
00007b78f51e0b42  push rsi
00007b78f51e0b43  push r8
00007b78f51e0b45  push r9
00007b78f51e0b47  push r10
00007b78f51e0b49  push r11
00007b78f51e0b4b  sub rsp, 0xF0
00007b78f51e0b52  vmovaps [rsp], xmm0
00007b78f51e0b57  vmovaps [rsp+0x10], xmm1
00007b78f51e0b5d  vmovaps [rsp+0x20], xmm2
00007b78f51e0b63  vmovaps [rsp+0x30], xmm3
00007b78f51e0b69  vmovaps [rsp+0x40], xmm4
00007b78f51e0b6f  vmovaps [rsp+0x50], xmm5
00007b78f51e0b75  vmovaps [rsp+0x60], xmm6
00007b78f51e0b7b  vmovaps [rsp+0x70], xmm7
00007b78f51e0b81  vmovaps [rsp+0x80], xmm8
00007b78f51e0b8a  vmovaps [rsp+0x90], xmm9
00007b78f51e0b93  vmovaps [rsp+0xA0], xmm10
00007b78f51e0b9c  vmovaps [rsp+0xB0], xmm12
00007b78f51e0ba5  vmovaps [rsp+0xC0], xmm13
00007b78f51e0bae  vmovaps [rsp+0xD0], xmm14
00007b78f51e0bb7  vmovaps [rsp+0xE0], xmm15
00007b78f51e0bc0  sub rsp, 0x30
00007b78f51e0bc4  movaps [rsp], xmm11
00007b78f51e0bc9  movaps [rsp+0x10], xmm10
00007b78f51e0bcf  movaps [rsp+0x20], xmm14
00007b78f51e0bd5  lea rdi, [rsp]
00007b78f51e0bd9  mov esi, 0x00
00007b78f51e0bde  mov rax, 0x597478C09530
00007b78f51e0be8  call rax
00007b78f51e0bea  movaps xmm11, [rsp]
00007b78f51e0bef  add rsp, 0x30
00007b78f51e0bf3  vmovaps xmm0, [rsp]
00007b78f51e0bf8  vmovaps xmm1, [rsp+0x10]
00007b78f51e0bfe  vmovaps xmm2, [rsp+0x20]
00007b78f51e0c04  vmovaps xmm3, [rsp+0x30]
00007b78f51e0c0a  vmovaps xmm4, [rsp+0x40]
00007b78f51e0c10  vmovaps xmm5, [rsp+0x50]
00007b78f51e0c16  vmovaps xmm6, [rsp+0x60]
00007b78f51e0c1c  vmovaps xmm7, [rsp+0x70]
00007b78f51e0c22  vmovaps xmm8, [rsp+0x80]
00007b78f51e0c2b  vmovaps xmm9, [rsp+0x90]
00007b78f51e0c34  vmovaps xmm10, [rsp+0xA0]
00007b78f51e0c3d  vmovaps xmm12, [rsp+0xB0]
00007b78f51e0c46  vmovaps xmm13, [rsp+0xC0]
00007b78f51e0c4f  vmovaps xmm14, [rsp+0xD0]
00007b78f51e0c58  vmovaps xmm15, [rsp+0xE0]
00007b78f51e0c61  add rsp, 0xF0
00007b78f51e0c68  pop r11
00007b78f51e0c6a  pop r10
00007b78f51e0c6c  pop r9
00007b78f51e0c6e  pop r8
00007b78f51e0c70  pop rsi
00007b78f51e0c71  pop rdi
00007b78f51e0c72  pop rdx
00007b78f51e0c73  pop rcx
00007b78f51e0c74  pop rax
00007b78f51e0c75  add rsp, 0x08
00007b78f51e0c79  jmp 0x00007B78F51DC6A0
00007b78f51e0c7e  call 0x00007B78F50C33A0
00007b78f51e0c83  jmp 0x00007B78F51DC6AA
00007b78f51e0c88  sub rsp, 0x08
00007b78f51e0c8c  push rax
00007b78f51e0c8d  push rcx
00007b78f51e0c8e  push rdx
00007b78f51e0c8f  push rdi
00007b78f51e0c90  push rsi
00007b78f51e0c91  push r8
00007b78f51e0c93  push r9
00007b78f51e0c95  push r10
00007b78f51e0c97  push r11
00007b78f51e0c99  sub rsp, 0xF0
00007b78f51e0ca0  vmovaps [rsp], xmm0
00007b78f51e0ca5  vmovaps [rsp+0x10], xmm1
00007b78f51e0cab  vmovaps [rsp+0x20], xmm2
00007b78f51e0cb1  vmovaps [rsp+0x30], xmm3
00007b78f51e0cb7  vmovaps [rsp+0x40], xmm4
00007b78f51e0cbd  vmovaps [rsp+0x50], xmm5
00007b78f51e0cc3  vmovaps [rsp+0x60], xmm6
00007b78f51e0cc9  vmovaps [rsp+0x70], xmm7
00007b78f51e0ccf  vmovaps [rsp+0x80], xmm8
00007b78f51e0cd8  vmovaps [rsp+0x90], xmm9
00007b78f51e0ce1  vmovaps [rsp+0xA0], xmm11
00007b78f51e0cea  vmovaps [rsp+0xB0], xmm12
00007b78f51e0cf3  vmovaps [rsp+0xC0], xmm13
00007b78f51e0cfc  vmovaps [rsp+0xD0], xmm14
00007b78f51e0d05  vmovaps [rsp+0xE0], xmm15
00007b78f51e0d0e  sub rsp, 0x30
00007b78f51e0d12  movaps [rsp], xmm10
00007b78f51e0d17  movaps [rsp+0x10], xmm1
00007b78f51e0d1c  movaps [rsp+0x20], xmm12
00007b78f51e0d22  lea rdi, [rsp]
00007b78f51e0d26  mov esi, 0x00
00007b78f51e0d2b  mov rax, 0x597478C09530
00007b78f51e0d35  call rax
00007b78f51e0d37  movaps xmm10, [rsp]
00007b78f51e0d3c  add rsp, 0x30
00007b78f51e0d40  vmovaps xmm0, [rsp]
00007b78f51e0d45  vmovaps xmm1, [rsp+0x10]
00007b78f51e0d4b  vmovaps xmm2, [rsp+0x20]
00007b78f51e0d51  vmovaps xmm3, [rsp+0x30]
00007b78f51e0d57  vmovaps xmm4, [rsp+0x40]
00007b78f51e0d5d  vmovaps xmm5, [rsp+0x50]
00007b78f51e0d63  vmovaps xmm6, [rsp+0x60]
00007b78f51e0d69  vmovaps xmm7, [rsp+0x70]
00007b78f51e0d6f  vmovaps xmm8, [rsp+0x80]
00007b78f51e0d78  vmovaps xmm9, [rsp+0x90]
00007b78f51e0d81  vmovaps xmm11, [rsp+0xA0]
00007b78f51e0d8a  vmovaps xmm12, [rsp+0xB0]
00007b78f51e0d93  vmovaps xmm13, [rsp+0xC0]
00007b78f51e0d9c  vmovaps xmm14, [rsp+0xD0]
00007b78f51e0da5  vmovaps xmm15, [rsp+0xE0]
00007b78f51e0dae  add rsp, 0xF0
00007b78f51e0db5  pop r11
00007b78f51e0db7  pop r10
00007b78f51e0db9  pop r9
00007b78f51e0dbb  pop r8
00007b78f51e0dbd  pop rsi
00007b78f51e0dbe  pop rdi
00007b78f51e0dbf  pop rdx
00007b78f51e0dc0  pop rcx
00007b78f51e0dc1  pop rax
00007b78f51e0dc2  add rsp, 0x08
00007b78f51e0dc6  jmp 0x00007B78F51DC6CD
00007b78f51e0dcb  sub rsp, 0x08
00007b78f51e0dcf  push rax
00007b78f51e0dd0  push rcx
00007b78f51e0dd1  push rdx
00007b78f51e0dd2  push rdi
00007b78f51e0dd3  push rsi
00007b78f51e0dd4  push r8
00007b78f51e0dd6  push r9
00007b78f51e0dd8  push r10
00007b78f51e0dda  push r11
00007b78f51e0ddc  sub rsp, 0xF0
00007b78f51e0de3  vmovaps [rsp], xmm0
00007b78f51e0de8  vmovaps [rsp+0x10], xmm1
00007b78f51e0dee  vmovaps [rsp+0x20], xmm2
00007b78f51e0df4  vmovaps [rsp+0x30], xmm3
00007b78f51e0dfa  vmovaps [rsp+0x40], xmm4
00007b78f51e0e00  vmovaps [rsp+0x50], xmm5
00007b78f51e0e06  vmovaps [rsp+0x60], xmm6
00007b78f51e0e0c  vmovaps [rsp+0x70], xmm7
00007b78f51e0e12  vmovaps [rsp+0x80], xmm8
00007b78f51e0e1b  vmovaps [rsp+0x90], xmm9
00007b78f51e0e24  vmovaps [rsp+0xA0], xmm10
00007b78f51e0e2d  vmovaps [rsp+0xB0], xmm11
00007b78f51e0e36  vmovaps [rsp+0xC0], xmm13
00007b78f51e0e3f  vmovaps [rsp+0xD0], xmm14
00007b78f51e0e48  vmovaps [rsp+0xE0], xmm15
00007b78f51e0e51  sub rsp, 0x30
00007b78f51e0e55  movaps [rsp], xmm12
00007b78f51e0e5a  movaps [rsp+0x10], xmm14
00007b78f51e0e60  movaps [rsp+0x20], xmm1
00007b78f51e0e65  lea rdi, [rsp]
00007b78f51e0e69  mov esi, 0x00
00007b78f51e0e6e  mov rax, 0x597478C09530
00007b78f51e0e78  call rax
00007b78f51e0e7a  movaps xmm12, [rsp]
00007b78f51e0e7f  add rsp, 0x30
00007b78f51e0e83  vmovaps xmm0, [rsp]
00007b78f51e0e88  vmovaps xmm1, [rsp+0x10]
00007b78f51e0e8e  vmovaps xmm2, [rsp+0x20]
00007b78f51e0e94  vmovaps xmm3, [rsp+0x30]
00007b78f51e0e9a  vmovaps xmm4, [rsp+0x40]
00007b78f51e0ea0  vmovaps xmm5, [rsp+0x50]
00007b78f51e0ea6  vmovaps xmm6, [rsp+0x60]
00007b78f51e0eac  vmovaps xmm7, [rsp+0x70]
00007b78f51e0eb2  vmovaps xmm8, [rsp+0x80]
00007b78f51e0ebb  vmovaps xmm9, [rsp+0x90]
00007b78f51e0ec4  vmovaps xmm10, [rsp+0xA0]
00007b78f51e0ecd  vmovaps xmm11, [rsp+0xB0]
00007b78f51e0ed6  vmovaps xmm13, [rsp+0xC0]
00007b78f51e0edf  vmovaps xmm14, [rsp+0xD0]
00007b78f51e0ee8  vmovaps xmm15, [rsp+0xE0]
00007b78f51e0ef1  add rsp, 0xF0
00007b78f51e0ef8  pop r11
00007b78f51e0efa  pop r10
00007b78f51e0efc  pop r9
00007b78f51e0efe  pop r8
00007b78f51e0f00  pop rsi
00007b78f51e0f01  pop rdi
00007b78f51e0f02  pop rdx
00007b78f51e0f03  pop rcx
00007b78f51e0f04  pop rax
00007b78f51e0f05  add rsp, 0x08
00007b78f51e0f09  jmp 0x00007B78F51DC6FC
00007b78f51e0f0e  sub rsp, 0x08
00007b78f51e0f12  push rax
00007b78f51e0f13  push rcx
00007b78f51e0f14  push rdx
00007b78f51e0f15  push rdi
00007b78f51e0f16  push rsi
00007b78f51e0f17  push r8
00007b78f51e0f19  push r9
00007b78f51e0f1b  push r10
00007b78f51e0f1d  push r11
00007b78f51e0f1f  sub rsp, 0xF0
00007b78f51e0f26  vmovaps [rsp], xmm0
00007b78f51e0f2b  vmovaps [rsp+0x10], xmm1
00007b78f51e0f31  vmovaps [rsp+0x20], xmm2
00007b78f51e0f37  vmovaps [rsp+0x30], xmm3
00007b78f51e0f3d  vmovaps [rsp+0x40], xmm4
00007b78f51e0f43  vmovaps [rsp+0x50], xmm5
00007b78f51e0f49  vmovaps [rsp+0x60], xmm6
00007b78f51e0f4f  vmovaps [rsp+0x70], xmm7
00007b78f51e0f55  vmovaps [rsp+0x80], xmm8
00007b78f51e0f5e  vmovaps [rsp+0x90], xmm9
00007b78f51e0f67  vmovaps [rsp+0xA0], xmm10
00007b78f51e0f70  vmovaps [rsp+0xB0], xmm11
00007b78f51e0f79  vmovaps [rsp+0xC0], xmm12
00007b78f51e0f82  vmovaps [rsp+0xD0], xmm13
00007b78f51e0f8b  vmovaps [rsp+0xE0], xmm15
00007b78f51e0f94  sub rsp, 0x30
00007b78f51e0f98  movaps [rsp], xmm14
00007b78f51e0f9d  movaps [rsp+0x10], xmm9
00007b78f51e0fa3  movaps [rsp+0x20], xmm1
00007b78f51e0fa8  lea rdi, [rsp]
00007b78f51e0fac  mov esi, 0x00
00007b78f51e0fb1  mov rax, 0x597478C09530
00007b78f51e0fbb  call rax
00007b78f51e0fbd  movaps xmm14, [rsp]
00007b78f51e0fc2  add rsp, 0x30
00007b78f51e0fc6  vmovaps xmm0, [rsp]
00007b78f51e0fcb  vmovaps xmm1, [rsp+0x10]
00007b78f51e0fd1  vmovaps xmm2, [rsp+0x20]
00007b78f51e0fd7  vmovaps xmm3, [rsp+0x30]
00007b78f51e0fdd  vmovaps xmm4, [rsp+0x40]
00007b78f51e0fe3  vmovaps xmm5, [rsp+0x50]
00007b78f51e0fe9  vmovaps xmm6, [rsp+0x60]
00007b78f51e0fef  vmovaps xmm7, [rsp+0x70]
00007b78f51e0ff5  vmovaps xmm8, [rsp+0x80]
00007b78f51e0ffe  vmovaps xmm9, [rsp+0x90]
00007b78f51e1007  vmovaps xmm10, [rsp+0xA0]
00007b78f51e1010  vmovaps xmm11, [rsp+0xB0]
00007b78f51e1019  vmovaps xmm12, [rsp+0xC0]
00007b78f51e1022  vmovaps xmm13, [rsp+0xD0]
00007b78f51e102b  vmovaps xmm15, [rsp+0xE0]
00007b78f51e1034  add rsp, 0xF0
00007b78f51e103b  pop r11
00007b78f51e103d  pop r10
00007b78f51e103f  pop r9
00007b78f51e1041  pop r8
00007b78f51e1043  pop rsi
00007b78f51e1044  pop rdi
00007b78f51e1045  pop rdx
00007b78f51e1046  pop rcx
00007b78f51e1047  pop rax
00007b78f51e1048  add rsp, 0x08
00007b78f51e104c  jmp 0x00007B78F51DC72B
00007b78f51e1051  sub rsp, 0x08
00007b78f51e1055  push rax
00007b78f51e1056  push rcx
00007b78f51e1057  push rdx
00007b78f51e1058  push rdi
00007b78f51e1059  push rsi
00007b78f51e105a  push r8
00007b78f51e105c  push r9
00007b78f51e105e  push r10
00007b78f51e1060  push r11
00007b78f51e1062  sub rsp, 0xF0
00007b78f51e1069  vmovaps [rsp], xmm0
00007b78f51e106e  vmovaps [rsp+0x10], xmm2
00007b78f51e1074  vmovaps [rsp+0x20], xmm3
00007b78f51e107a  vmovaps [rsp+0x30], xmm4
00007b78f51e1080  vmovaps [rsp+0x40], xmm5
00007b78f51e1086  vmovaps [rsp+0x50], xmm6
00007b78f51e108c  vmovaps [rsp+0x60], xmm7
00007b78f51e1092  vmovaps [rsp+0x70], xmm8
00007b78f51e1098  vmovaps [rsp+0x80], xmm9
00007b78f51e10a1  vmovaps [rsp+0x90], xmm10
00007b78f51e10aa  vmovaps [rsp+0xA0], xmm11
00007b78f51e10b3  vmovaps [rsp+0xB0], xmm12
00007b78f51e10bc  vmovaps [rsp+0xC0], xmm13
00007b78f51e10c5  vmovaps [rsp+0xD0], xmm14
00007b78f51e10ce  vmovaps [rsp+0xE0], xmm15
00007b78f51e10d7  sub rsp, 0x30
00007b78f51e10db  movaps [rsp], xmm1
00007b78f51e10df  movaps [rsp+0x10], xmm13
00007b78f51e10e5  movaps [rsp+0x20], xmm8
00007b78f51e10eb  lea rdi, [rsp]
00007b78f51e10ef  mov esi, 0x00
00007b78f51e10f4  mov rax, 0x597478C09530
00007b78f51e10fe  call rax
00007b78f51e1100  movaps xmm1, [rsp]
00007b78f51e1104  add rsp, 0x30
00007b78f51e1108  vmovaps xmm0, [rsp]
00007b78f51e110d  vmovaps xmm2, [rsp+0x10]
00007b78f51e1113  vmovaps xmm3, [rsp+0x20]
00007b78f51e1119  vmovaps xmm4, [rsp+0x30]
00007b78f51e111f  vmovaps xmm5, [rsp+0x40]
00007b78f51e1125  vmovaps xmm6, [rsp+0x50]
00007b78f51e112b  vmovaps xmm7, [rsp+0x60]
00007b78f51e1131  vmovaps xmm8, [rsp+0x70]
00007b78f51e1137  vmovaps xmm9, [rsp+0x80]
00007b78f51e1140  vmovaps xmm10, [rsp+0x90]
00007b78f51e1149  vmovaps xmm11, [rsp+0xA0]
00007b78f51e1152  vmovaps xmm12, [rsp+0xB0]
00007b78f51e115b  vmovaps xmm13, [rsp+0xC0]
00007b78f51e1164  vmovaps xmm14, [rsp+0xD0]
00007b78f51e116d  vmovaps xmm15, [rsp+0xE0]
00007b78f51e1176  add rsp, 0xF0
00007b78f51e117d  pop r11
00007b78f51e117f  pop r10
00007b78f51e1181  pop r9
00007b78f51e1183  pop r8
00007b78f51e1185  pop rsi
00007b78f51e1186  pop rdi
00007b78f51e1187  pop rdx
00007b78f51e1188  pop rcx
00007b78f51e1189  pop rax
00007b78f51e118a  add rsp, 0x08
00007b78f51e118e  jmp 0x00007B78F51DC74D
00007b78f51e1193  call 0x00007B78F500C260
00007b78f51e1198  jmp 0x00007B78F51DC75B
00007b78f51e119d  call 0x00007B78F50BD750
00007b78f51e11a2  jmp 0x00007B78F51DC765
00007b78f51e11a7  sub rsp, 0x08
00007b78f51e11ab  push rax
00007b78f51e11ac  push rcx
00007b78f51e11ad  push rdx
00007b78f51e11ae  push rdi
00007b78f51e11af  push rsi
00007b78f51e11b0  push r8
00007b78f51e11b2  push r9
00007b78f51e11b4  push r10
00007b78f51e11b6  push r11
00007b78f51e11b8  sub rsp, 0xF0
00007b78f51e11bf  vmovaps [rsp], xmm0
00007b78f51e11c4  vmovaps [rsp+0x10], xmm1
00007b78f51e11ca  vmovaps [rsp+0x20], xmm2
00007b78f51e11d0  vmovaps [rsp+0x30], xmm3
00007b78f51e11d6  vmovaps [rsp+0x40], xmm4
00007b78f51e11dc  vmovaps [rsp+0x50], xmm5
00007b78f51e11e2  vmovaps [rsp+0x60], xmm6
00007b78f51e11e8  vmovaps [rsp+0x70], xmm7
00007b78f51e11ee  vmovaps [rsp+0x80], xmm9
00007b78f51e11f7  vmovaps [rsp+0x90], xmm10
00007b78f51e1200  vmovaps [rsp+0xA0], xmm11
00007b78f51e1209  vmovaps [rsp+0xB0], xmm12
00007b78f51e1212  vmovaps [rsp+0xC0], xmm13
00007b78f51e121b  vmovaps [rsp+0xD0], xmm14
00007b78f51e1224  vmovaps [rsp+0xE0], xmm15
00007b78f51e122d  sub rsp, 0x30
00007b78f51e1231  movaps [rsp], xmm8
00007b78f51e1236  movaps [rsp+0x10], xmm15
00007b78f51e123c  movaps [rsp+0x20], xmm7
00007b78f51e1241  lea rdi, [rsp]
00007b78f51e1245  mov esi, 0x00
00007b78f51e124a  mov rax, 0x597478C09530
00007b78f51e1254  call rax
00007b78f51e1256  movaps xmm8, [rsp]
00007b78f51e125b  add rsp, 0x30
00007b78f51e125f  vmovaps xmm0, [rsp]
00007b78f51e1264  vmovaps xmm1, [rsp+0x10]
00007b78f51e126a  vmovaps xmm2, [rsp+0x20]
00007b78f51e1270  vmovaps xmm3, [rsp+0x30]
00007b78f51e1276  vmovaps xmm4, [rsp+0x40]
00007b78f51e127c  vmovaps xmm5, [rsp+0x50]
00007b78f51e1282  vmovaps xmm6, [rsp+0x60]
00007b78f51e1288  vmovaps xmm7, [rsp+0x70]
00007b78f51e128e  vmovaps xmm9, [rsp+0x80]
00007b78f51e1297  vmovaps xmm10, [rsp+0x90]
00007b78f51e12a0  vmovaps xmm11, [rsp+0xA0]
00007b78f51e12a9  vmovaps xmm12, [rsp+0xB0]
00007b78f51e12b2  vmovaps xmm13, [rsp+0xC0]
00007b78f51e12bb  vmovaps xmm14, [rsp+0xD0]
00007b78f51e12c4  vmovaps xmm15, [rsp+0xE0]
00007b78f51e12cd  add rsp, 0xF0
00007b78f51e12d4  pop r11
00007b78f51e12d6  pop r10
00007b78f51e12d8  pop r9
00007b78f51e12da  pop r8
00007b78f51e12dc  pop rsi
00007b78f51e12dd  pop rdi
00007b78f51e12de  pop rdx
00007b78f51e12df  pop rcx
00007b78f51e12e0  pop rax
00007b78f51e12e1  add rsp, 0x08
00007b78f51e12e5  jmp 0x00007B78F51DC787
00007b78f51e12ea  sub rsp, 0x08
00007b78f51e12ee  push rax
00007b78f51e12ef  push rcx
00007b78f51e12f0  push rdx
00007b78f51e12f1  push rdi
00007b78f51e12f2  push rsi
00007b78f51e12f3  push r8
00007b78f51e12f5  push r9
00007b78f51e12f7  push r10
00007b78f51e12f9  push r11
00007b78f51e12fb  sub rsp, 0xF0
00007b78f51e1302  vmovaps [rsp], xmm0
00007b78f51e1307  vmovaps [rsp+0x10], xmm1
00007b78f51e130d  vmovaps [rsp+0x20], xmm2
00007b78f51e1313  vmovaps [rsp+0x30], xmm3
00007b78f51e1319  vmovaps [rsp+0x40], xmm4
00007b78f51e131f  vmovaps [rsp+0x50], xmm5
00007b78f51e1325  vmovaps [rsp+0x60], xmm6
00007b78f51e132b  vmovaps [rsp+0x70], xmm8
00007b78f51e1331  vmovaps [rsp+0x80], xmm9
00007b78f51e133a  vmovaps [rsp+0x90], xmm10
00007b78f51e1343  vmovaps [rsp+0xA0], xmm11
00007b78f51e134c  vmovaps [rsp+0xB0], xmm12
00007b78f51e1355  vmovaps [rsp+0xC0], xmm13
00007b78f51e135e  vmovaps [rsp+0xD0], xmm14
00007b78f51e1367  vmovaps [rsp+0xE0], xmm15
00007b78f51e1370  sub rsp, 0x30
00007b78f51e1374  movaps [rsp], xmm7
00007b78f51e1378  movaps [rsp+0x10], xmm9
00007b78f51e137e  movaps [rsp+0x20], xmm15
00007b78f51e1384  lea rdi, [rsp]
00007b78f51e1388  mov esi, 0x00
00007b78f51e138d  mov rax, 0x597478C09530
00007b78f51e1397  call rax
00007b78f51e1399  movaps xmm7, [rsp]
00007b78f51e139d  add rsp, 0x30
00007b78f51e13a1  vmovaps xmm0, [rsp]
00007b78f51e13a6  vmovaps xmm1, [rsp+0x10]
00007b78f51e13ac  vmovaps xmm2, [rsp+0x20]
00007b78f51e13b2  vmovaps xmm3, [rsp+0x30]
00007b78f51e13b8  vmovaps xmm4, [rsp+0x40]
00007b78f51e13be  vmovaps xmm5, [rsp+0x50]
00007b78f51e13c4  vmovaps xmm6, [rsp+0x60]
00007b78f51e13ca  vmovaps xmm8, [rsp+0x70]
00007b78f51e13d0  vmovaps xmm9, [rsp+0x80]
00007b78f51e13d9  vmovaps xmm10, [rsp+0x90]
00007b78f51e13e2  vmovaps xmm11, [rsp+0xA0]
00007b78f51e13eb  vmovaps xmm12, [rsp+0xB0]
00007b78f51e13f4  vmovaps xmm13, [rsp+0xC0]
00007b78f51e13fd  vmovaps xmm14, [rsp+0xD0]
00007b78f51e1406  vmovaps xmm15, [rsp+0xE0]
00007b78f51e140f  add rsp, 0xF0
00007b78f51e1416  pop r11
00007b78f51e1418  pop r10
00007b78f51e141a  pop r9
00007b78f51e141c  pop r8
00007b78f51e141e  pop rsi
00007b78f51e141f  pop rdi
00007b78f51e1420  pop rdx
00007b78f51e1421  pop rcx
00007b78f51e1422  pop rax
00007b78f51e1423  add rsp, 0x08
00007b78f51e1427  jmp 0x00007B78F51DC7B4
00007b78f51e142c  sub rsp, 0x08
00007b78f51e1430  push rax
00007b78f51e1431  push rcx
00007b78f51e1432  push rdx
00007b78f51e1433  push rdi
00007b78f51e1434  push rsi
00007b78f51e1435  push r8
00007b78f51e1437  push r9
00007b78f51e1439  push r10
00007b78f51e143b  push r11
00007b78f51e143d  sub rsp, 0xF0
00007b78f51e1444  vmovaps [rsp], xmm0
00007b78f51e1449  vmovaps [rsp+0x10], xmm1
00007b78f51e144f  vmovaps [rsp+0x20], xmm2
00007b78f51e1455  vmovaps [rsp+0x30], xmm3
00007b78f51e145b  vmovaps [rsp+0x40], xmm4
00007b78f51e1461  vmovaps [rsp+0x50], xmm5
00007b78f51e1467  vmovaps [rsp+0x60], xmm6
00007b78f51e146d  vmovaps [rsp+0x70], xmm7
00007b78f51e1473  vmovaps [rsp+0x80], xmm8
00007b78f51e147c  vmovaps [rsp+0x90], xmm10
00007b78f51e1485  vmovaps [rsp+0xA0], xmm11
00007b78f51e148e  vmovaps [rsp+0xB0], xmm12
00007b78f51e1497  vmovaps [rsp+0xC0], xmm13
00007b78f51e14a0  vmovaps [rsp+0xD0], xmm14
00007b78f51e14a9  vmovaps [rsp+0xE0], xmm15
00007b78f51e14b2  sub rsp, 0x30
00007b78f51e14b6  movaps [rsp], xmm9
00007b78f51e14bb  movaps [rsp+0x10], xmm13
00007b78f51e14c1  movaps [rsp+0x20], xmm15
00007b78f51e14c7  lea rdi, [rsp]
00007b78f51e14cb  mov esi, 0x00
00007b78f51e14d0  mov rax, 0x597478C09530
00007b78f51e14da  call rax
00007b78f51e14dc  movaps xmm9, [rsp]
00007b78f51e14e1  add rsp, 0x30
00007b78f51e14e5  vmovaps xmm0, [rsp]
00007b78f51e14ea  vmovaps xmm1, [rsp+0x10]
00007b78f51e14f0  vmovaps xmm2, [rsp+0x20]
00007b78f51e14f6  vmovaps xmm3, [rsp+0x30]
00007b78f51e14fc  vmovaps xmm4, [rsp+0x40]
00007b78f51e1502  vmovaps xmm5, [rsp+0x50]
00007b78f51e1508  vmovaps xmm6, [rsp+0x60]
00007b78f51e150e  vmovaps xmm7, [rsp+0x70]
00007b78f51e1514  vmovaps xmm8, [rsp+0x80]
00007b78f51e151d  vmovaps xmm10, [rsp+0x90]
00007b78f51e1526  vmovaps xmm11, [rsp+0xA0]
00007b78f51e152f  vmovaps xmm12, [rsp+0xB0]
00007b78f51e1538  vmovaps xmm13, [rsp+0xC0]
00007b78f51e1541  vmovaps xmm14, [rsp+0xD0]
00007b78f51e154a  vmovaps xmm15, [rsp+0xE0]
00007b78f51e1553  add rsp, 0xF0
00007b78f51e155a  pop r11
00007b78f51e155c  pop r10
00007b78f51e155e  pop r9
00007b78f51e1560  pop r8
00007b78f51e1562  pop rsi
00007b78f51e1563  pop rdi
00007b78f51e1564  pop rdx
00007b78f51e1565  pop rcx
00007b78f51e1566  pop rax
00007b78f51e1567  add rsp, 0x08
00007b78f51e156b  jmp 0x00007B78F51DC7E2
00007b78f51e1570  sub rsp, 0x08
00007b78f51e1574  push rax
00007b78f51e1575  push rcx
00007b78f51e1576  push rdx
00007b78f51e1577  push rdi
00007b78f51e1578  push rsi
00007b78f51e1579  push r8
00007b78f51e157b  push r9
00007b78f51e157d  push r10
00007b78f51e157f  push r11
00007b78f51e1581  sub rsp, 0xF0
00007b78f51e1588  vmovaps [rsp], xmm0
00007b78f51e158d  vmovaps [rsp+0x10], xmm1
00007b78f51e1593  vmovaps [rsp+0x20], xmm2
00007b78f51e1599  vmovaps [rsp+0x30], xmm3
00007b78f51e159f  vmovaps [rsp+0x40], xmm4
00007b78f51e15a5  vmovaps [rsp+0x50], xmm5
00007b78f51e15ab  vmovaps [rsp+0x60], xmm6
00007b78f51e15b1  vmovaps [rsp+0x70], xmm7
00007b78f51e15b7  vmovaps [rsp+0x80], xmm8
00007b78f51e15c0  vmovaps [rsp+0x90], xmm9
00007b78f51e15c9  vmovaps [rsp+0xA0], xmm10
00007b78f51e15d2  vmovaps [rsp+0xB0], xmm11
00007b78f51e15db  vmovaps [rsp+0xC0], xmm12
00007b78f51e15e4  vmovaps [rsp+0xD0], xmm13
00007b78f51e15ed  vmovaps [rsp+0xE0], xmm14
00007b78f51e15f6  sub rsp, 0x30
00007b78f51e15fa  movaps [rsp], xmm15
00007b78f51e15ff  movaps [rsp+0x10], xmm11
00007b78f51e1605  movaps [rsp+0x20], xmm12
00007b78f51e160b  lea rdi, [rsp]
00007b78f51e160f  mov esi, 0x00
00007b78f51e1614  mov rax, 0x597478C09530
00007b78f51e161e  call rax
00007b78f51e1620  movaps xmm15, [rsp]
00007b78f51e1625  add rsp, 0x30
00007b78f51e1629  vmovaps xmm0, [rsp]
00007b78f51e162e  vmovaps xmm1, [rsp+0x10]
00007b78f51e1634  vmovaps xmm2, [rsp+0x20]
00007b78f51e163a  vmovaps xmm3, [rsp+0x30]
00007b78f51e1640  vmovaps xmm4, [rsp+0x40]
00007b78f51e1646  vmovaps xmm5, [rsp+0x50]
00007b78f51e164c  vmovaps xmm6, [rsp+0x60]
00007b78f51e1652  vmovaps xmm7, [rsp+0x70]
00007b78f51e1658  vmovaps xmm8, [rsp+0x80]
00007b78f51e1661  vmovaps xmm9, [rsp+0x90]
00007b78f51e166a  vmovaps xmm10, [rsp+0xA0]
00007b78f51e1673  vmovaps xmm11, [rsp+0xB0]
00007b78f51e167c  vmovaps xmm12, [rsp+0xC0]
00007b78f51e1685  vmovaps xmm13, [rsp+0xD0]
00007b78f51e168e  vmovaps xmm14, [rsp+0xE0]
00007b78f51e1697  add rsp, 0xF0
00007b78f51e169e  pop r11
00007b78f51e16a0  pop r10
00007b78f51e16a2  pop r9
00007b78f51e16a4  pop r8
00007b78f51e16a6  pop rsi
00007b78f51e16a7  pop rdi
00007b78f51e16a8  pop rdx
00007b78f51e16a9  pop rcx
00007b78f51e16aa  pop rax
00007b78f51e16ab  add rsp, 0x08
00007b78f51e16af  jmp 0x00007B78F51DC7FD
00007b78f51e16b4  sub rsp, 0x08
00007b78f51e16b8  push rax
00007b78f51e16b9  push rcx
00007b78f51e16ba  push rdx
00007b78f51e16bb  push rdi
00007b78f51e16bc  push rsi
00007b78f51e16bd  push r8
00007b78f51e16bf  push r9
00007b78f51e16c1  push r10
00007b78f51e16c3  push r11
00007b78f51e16c5  sub rsp, 0xF0
00007b78f51e16cc  vmovaps [rsp], xmm0
00007b78f51e16d1  vmovaps [rsp+0x10], xmm1
00007b78f51e16d7  vmovaps [rsp+0x20], xmm2
00007b78f51e16dd  vmovaps [rsp+0x30], xmm3
00007b78f51e16e3  vmovaps [rsp+0x40], xmm4
00007b78f51e16e9  vmovaps [rsp+0x50], xmm5
00007b78f51e16ef  vmovaps [rsp+0x60], xmm6
00007b78f51e16f5  vmovaps [rsp+0x70], xmm7
00007b78f51e16fb  vmovaps [rsp+0x80], xmm8
00007b78f51e1704  vmovaps [rsp+0x90], xmm9
00007b78f51e170d  vmovaps [rsp+0xA0], xmm10
00007b78f51e1716  vmovaps [rsp+0xB0], xmm11
00007b78f51e171f  vmovaps [rsp+0xC0], xmm12
00007b78f51e1728  vmovaps [rsp+0xD0], xmm14
00007b78f51e1731  vmovaps [rsp+0xE0], xmm15
00007b78f51e173a  sub rsp, 0x30
00007b78f51e173e  movaps [rsp], xmm13
00007b78f51e1743  movaps [rsp+0x10], xmm10
00007b78f51e1749  movaps [rsp+0x20], xmm14
00007b78f51e174f  lea rdi, [rsp]
00007b78f51e1753  mov esi, 0x00
00007b78f51e1758  mov rax, 0x597478C09530
00007b78f51e1762  call rax
00007b78f51e1764  movaps xmm13, [rsp]
00007b78f51e1769  add rsp, 0x30
00007b78f51e176d  vmovaps xmm0, [rsp]
00007b78f51e1772  vmovaps xmm1, [rsp+0x10]
00007b78f51e1778  vmovaps xmm2, [rsp+0x20]
00007b78f51e177e  vmovaps xmm3, [rsp+0x30]
00007b78f51e1784  vmovaps xmm4, [rsp+0x40]
00007b78f51e178a  vmovaps xmm5, [rsp+0x50]
00007b78f51e1790  vmovaps xmm6, [rsp+0x60]
00007b78f51e1796  vmovaps xmm7, [rsp+0x70]
00007b78f51e179c  vmovaps xmm8, [rsp+0x80]
00007b78f51e17a5  vmovaps xmm9, [rsp+0x90]
00007b78f51e17ae  vmovaps xmm10, [rsp+0xA0]
00007b78f51e17b7  vmovaps xmm11, [rsp+0xB0]
00007b78f51e17c0  vmovaps xmm12, [rsp+0xC0]
00007b78f51e17c9  vmovaps xmm14, [rsp+0xD0]
00007b78f51e17d2  vmovaps xmm15, [rsp+0xE0]
00007b78f51e17db  add rsp, 0xF0
00007b78f51e17e2  pop r11
00007b78f51e17e4  pop r10
00007b78f51e17e6  pop r9
00007b78f51e17e8  pop r8
00007b78f51e17ea  pop rsi
00007b78f51e17eb  pop rdi
00007b78f51e17ec  pop rdx
00007b78f51e17ed  pop rcx
00007b78f51e17ee  pop rax
00007b78f51e17ef  add rsp, 0x08
00007b78f51e17f3  jmp 0x00007B78F51DC820
00007b78f51e17f8  sub rsp, 0x08
00007b78f51e17fc  push rax
00007b78f51e17fd  push rcx
00007b78f51e17fe  push rdx
00007b78f51e17ff  push rdi
00007b78f51e1800  push rsi
00007b78f51e1801  push r8
00007b78f51e1803  push r9
00007b78f51e1805  push r10
00007b78f51e1807  push r11
00007b78f51e1809  sub rsp, 0xF0
00007b78f51e1810  vmovaps [rsp], xmm0
00007b78f51e1815  vmovaps [rsp+0x10], xmm1
00007b78f51e181b  vmovaps [rsp+0x20], xmm2
00007b78f51e1821  vmovaps [rsp+0x30], xmm3
00007b78f51e1827  vmovaps [rsp+0x40], xmm4
00007b78f51e182d  vmovaps [rsp+0x50], xmm5
00007b78f51e1833  vmovaps [rsp+0x60], xmm6
00007b78f51e1839  vmovaps [rsp+0x70], xmm7
00007b78f51e183f  vmovaps [rsp+0x80], xmm8
00007b78f51e1848  vmovaps [rsp+0x90], xmm9
00007b78f51e1851  vmovaps [rsp+0xA0], xmm10
00007b78f51e185a  vmovaps [rsp+0xB0], xmm11
00007b78f51e1863  vmovaps [rsp+0xC0], xmm12
00007b78f51e186c  vmovaps [rsp+0xD0], xmm13
00007b78f51e1875  vmovaps [rsp+0xE0], xmm15
00007b78f51e187e  sub rsp, 0x30
00007b78f51e1882  movaps [rsp], xmm14
00007b78f51e1887  movaps [rsp+0x10], xmm1
00007b78f51e188c  movaps [rsp+0x20], xmm7
00007b78f51e1891  lea rdi, [rsp]
00007b78f51e1895  mov esi, 0x00
00007b78f51e189a  mov rax, 0x597478C09530
00007b78f51e18a4  call rax
00007b78f51e18a6  movaps xmm14, [rsp]
00007b78f51e18ab  add rsp, 0x30
00007b78f51e18af  vmovaps xmm0, [rsp]
00007b78f51e18b4  vmovaps xmm1, [rsp+0x10]
00007b78f51e18ba  vmovaps xmm2, [rsp+0x20]
00007b78f51e18c0  vmovaps xmm3, [rsp+0x30]
00007b78f51e18c6  vmovaps xmm4, [rsp+0x40]
00007b78f51e18cc  vmovaps xmm5, [rsp+0x50]
00007b78f51e18d2  vmovaps xmm6, [rsp+0x60]
00007b78f51e18d8  vmovaps xmm7, [rsp+0x70]
00007b78f51e18de  vmovaps xmm8, [rsp+0x80]
00007b78f51e18e7  vmovaps xmm9, [rsp+0x90]
00007b78f51e18f0  vmovaps xmm10, [rsp+0xA0]
00007b78f51e18f9  vmovaps xmm11, [rsp+0xB0]
00007b78f51e1902  vmovaps xmm12, [rsp+0xC0]
00007b78f51e190b  vmovaps xmm13, [rsp+0xD0]
00007b78f51e1914  vmovaps xmm15, [rsp+0xE0]
00007b78f51e191d  add rsp, 0xF0
00007b78f51e1924  pop r11
00007b78f51e1926  pop r10
00007b78f51e1928  pop r9
00007b78f51e192a  pop r8
00007b78f51e192c  pop rsi
00007b78f51e192d  pop rdi
00007b78f51e192e  pop rdx
00007b78f51e192f  pop rcx
00007b78f51e1930  pop rax
00007b78f51e1931  add rsp, 0x08
00007b78f51e1935  jmp 0x00007B78F51DC843
00007b78f51e193a  sub rsp, 0x08
00007b78f51e193e  push rax
00007b78f51e193f  push rcx
00007b78f51e1940  push rdx
00007b78f51e1941  push rdi
00007b78f51e1942  push rsi
00007b78f51e1943  push r8
00007b78f51e1945  push r9
00007b78f51e1947  push r10
00007b78f51e1949  push r11
00007b78f51e194b  sub rsp, 0xF0
00007b78f51e1952  vmovaps [rsp], xmm0
00007b78f51e1957  vmovaps [rsp+0x10], xmm2
00007b78f51e195d  vmovaps [rsp+0x20], xmm3
00007b78f51e1963  vmovaps [rsp+0x30], xmm4
00007b78f51e1969  vmovaps [rsp+0x40], xmm5
00007b78f51e196f  vmovaps [rsp+0x50], xmm6
00007b78f51e1975  vmovaps [rsp+0x60], xmm7
00007b78f51e197b  vmovaps [rsp+0x70], xmm8
00007b78f51e1981  vmovaps [rsp+0x80], xmm9
00007b78f51e198a  vmovaps [rsp+0x90], xmm10
00007b78f51e1993  vmovaps [rsp+0xA0], xmm11
00007b78f51e199c  vmovaps [rsp+0xB0], xmm12
00007b78f51e19a5  vmovaps [rsp+0xC0], xmm13
00007b78f51e19ae  vmovaps [rsp+0xD0], xmm14
00007b78f51e19b7  vmovaps [rsp+0xE0], xmm15
00007b78f51e19c0  sub rsp, 0x30
00007b78f51e19c4  movaps [rsp], xmm1
00007b78f51e19c8  movaps [rsp+0x10], xmm8
00007b78f51e19ce  movaps [rsp+0x20], xmm9
00007b78f51e19d4  lea rdi, [rsp]
00007b78f51e19d8  mov esi, 0x00
00007b78f51e19dd  mov rax, 0x597478C09530
00007b78f51e19e7  call rax
00007b78f51e19e9  movaps xmm1, [rsp]
00007b78f51e19ed  add rsp, 0x30
00007b78f51e19f1  vmovaps xmm0, [rsp]
00007b78f51e19f6  vmovaps xmm2, [rsp+0x10]
00007b78f51e19fc  vmovaps xmm3, [rsp+0x20]
00007b78f51e1a02  vmovaps xmm4, [rsp+0x30]
00007b78f51e1a08  vmovaps xmm5, [rsp+0x40]
00007b78f51e1a0e  vmovaps xmm6, [rsp+0x50]
00007b78f51e1a14  vmovaps xmm7, [rsp+0x60]
00007b78f51e1a1a  vmovaps xmm8, [rsp+0x70]
00007b78f51e1a20  vmovaps xmm9, [rsp+0x80]
00007b78f51e1a29  vmovaps xmm10, [rsp+0x90]
00007b78f51e1a32  vmovaps xmm11, [rsp+0xA0]
00007b78f51e1a3b  vmovaps xmm12, [rsp+0xB0]
00007b78f51e1a44  vmovaps xmm13, [rsp+0xC0]
00007b78f51e1a4d  vmovaps xmm14, [rsp+0xD0]
00007b78f51e1a56  vmovaps xmm15, [rsp+0xE0]
00007b78f51e1a5f  add rsp, 0xF0
00007b78f51e1a66  pop r11
00007b78f51e1a68  pop r10
00007b78f51e1a6a  pop r9
00007b78f51e1a6c  pop r8
00007b78f51e1a6e  pop rsi
00007b78f51e1a6f  pop rdi
00007b78f51e1a70  pop rdx
00007b78f51e1a71  pop rcx
00007b78f51e1a72  pop rax
00007b78f51e1a73  add rsp, 0x08
00007b78f51e1a77  jmp 0x00007B78F51DC865
00007b78f51e1a7c  call 0x00007B78F50E5940
00007b78f51e1a81  jmp 0x00007B78F51DC873
00007b78f51e1a86  call 0x00007B78F500C380
00007b78f51e1a8b  jmp 0x00007B78F51DC87D
00007b78f51e1a90  call 0x00007B78F500D600
00007b78f51e1a95  jmp 0x00007B78F51DC887
00007b78f51e1a9a  call 0x00007B78F4FFF540
00007b78f51e1a9f  jmp 0x00007B78F51DC891
00007b78f51e1aa4  int3
00007b78f51e1aa5  nop [rax+rax*1], ax
00007b78f51e1aae  nop
00007b78f51e1ab0  mov rax, [r15+0xF8]
00007b78f51e1ab7  lea r14, [rax+0x140]
00007b78f51e1abe  mov r12, [r13+r14*1]
00007b78f51e1ac3  mov [r15+0xE8], r12
00007b78f51e1aca  lea r14, [rax+0x130]
00007b78f51e1ad1  mov r12, [r13+r14*1]
00007b78f51e1ad6  lea r14, [rax+0x138]
00007b78f51e1add  mov r11, [r13+r14*1]
00007b78f51e1ae2  movq xmm1, r12
00007b78f51e1ae7  movq xmm15, r11
00007b78f51e1aec  movq xmm1, xmm1
00007b78f51e1af0  movq xmm1, xmm1
00007b78f51e1af4  movaps [r15+0x1A0], xmm1
00007b78f51e1afc  movq xmm15, xmm15
00007b78f51e1b01  movq xmm15, xmm15
00007b78f51e1b06  movaps [r15+0x190], xmm15
00007b78f51e1b0e  lea r14, [rax+0x120]
00007b78f51e1b15  mov r12, [r13+r14*1]
00007b78f51e1b1a  lea r14, [rax+0x128]
00007b78f51e1b21  mov r11, [r13+r14*1]
00007b78f51e1b26  movq xmm1, r12
00007b78f51e1b2b  movq xmm15, r11
00007b78f51e1b30  movq xmm1, xmm1
00007b78f51e1b34  movq xmm1, xmm1
00007b78f51e1b38  movaps [r15+0x1C0], xmm1
00007b78f51e1b40  movq xmm15, xmm15
00007b78f51e1b45  movq xmm15, xmm15
00007b78f51e1b4a  movaps [r15+0x1B0], xmm15
00007b78f51e1b52  lea r14, [rax+0x110]
00007b78f51e1b59  mov r12, [r13+r14*1]
00007b78f51e1b5e  lea r14, [rax+0x118]
00007b78f51e1b65  mov r11, [r13+r14*1]
00007b78f51e1b6a  movq xmm1, r12
00007b78f51e1b6f  movq xmm15, r11
00007b78f51e1b74  movq xmm1, xmm1
00007b78f51e1b78  movq xmm1, xmm1
00007b78f51e1b7c  movaps [r15+0x1E0], xmm1
00007b78f51e1b84  movq xmm15, xmm15
00007b78f51e1b89  movq xmm15, xmm15
00007b78f51e1b8e  movaps [r15+0x1D0], xmm15
00007b78f51e1b96  lea r14, [rax+0x100]
00007b78f51e1b9d  mov r12, [r13+r14*1]
00007b78f51e1ba2  lea r14, [rax+0x108]
00007b78f51e1ba9  mov r11, [r13+r14*1]
00007b78f51e1bae  movq xmm1, r12
00007b78f51e1bb3  movq xmm15, r11
00007b78f51e1bb8  movq xmm1, xmm1
00007b78f51e1bbc  movq xmm1, xmm1
00007b78f51e1bc0  movaps [r15+0x200], xmm1
00007b78f51e1bc8  movq xmm15, xmm15
00007b78f51e1bcd  movq xmm15, xmm15
00007b78f51e1bd2  movaps [r15+0x1F0], xmm15
00007b78f51e1bda  mov qword ptr [r15+0x40], 0x430000
00007b78f51e1be2  mov r14d, 0x430510
00007b78f51e1be8  mov r12, [r13+r14*1]
00007b78f51e1bed  movq xmm1, r12
00007b78f51e1bf2  lea r14, [rax+0x150]
00007b78f51e1bf9  mov [r15+0xF8], r14
00007b78f51e1c00  mov rax, [r15+0x50]
00007b78f51e1c04  movups xmm15, [r13+rax*1]
00007b78f51e1c0a  movaps [r15+0x120], xmm15
00007b78f51e1c12  mov qword ptr [r15+0x48], 0x10
00007b78f51e1c1a  xor eax, eax
00007b78f51e1c1c  mov r14d, 0x10
00007b78f51e1c22  mov r12d, 0x200
00007b78f51e1c28  cmp r14, r12
00007b78f51e1c2b  cmc
00007b78f51e1c2c  lahf
00007b78f51e1c2d  seto al
00007b78f51e1c30  mov [r15+0x108], eax
00007b78f51e1c37  pextrq rax, xmm15, 0x01
00007b78f51e1c3e  movq xmm14, rax
00007b78f51e1c43  movaps [r15+0x130], xmm14
00007b78f51e1c4b  movq rax, xmm1
00007b78f51e1c50  movq r14, xmm15
00007b78f51e1c55  vmovq xmm1, rax
00007b78f51e1c5a  vmovq xmm15, r14
00007b78f51e1c5f  movaps xmm13, xmm1
00007b78f51e1c63  addsd xmm13, xmm15
00007b78f51e1c68  ucomisd xmm13, xmm13
00007b78f51e1c6d  jp 0x00007B78F51E1D86
00007b78f51e1c73  movq xmm13, xmm13
00007b78f51e1c78  movq rax, xmm13
00007b78f51e1c7d  movq r14, xmm14
00007b78f51e1c82  vmovq xmm1, rax
00007b78f51e1c87  vmovq xmm15, r14
00007b78f51e1c8c  movaps xmm14, xmm1
00007b78f51e1c90  addsd xmm14, xmm15
00007b78f51e1c95  ucomisd xmm14, xmm14
00007b78f51e1c9a  jp 0x00007B78F51E1DCE
00007b78f51e1ca0  movq xmm14, xmm14
00007b78f51e1ca5  movaps [r15+0x110], xmm14
00007b78f51e1cad  mov eax, [r15+0x108]
00007b78f51e1cb4  sahf
00007b78f51e1cb5  jnz 0x00007B78F51E1CE7
00007b78f51e1cb7  cmp dword ptr [r15+0x318], 0x00
00007b78f51e1cbf  jz 0x00007B78F51E1FE0
00007b78f51e1cc5  nop [rax+rax*1], ax
00007b78f51e1cce  nop [rax+rax*1], eax
00007b78f51e1cd6  mov eax, 0x410490
00007b78f51e1cdb  mov [r15+0x100], rax
00007b78f51e1ce2  jmp 0x00007B78F4FFE110
00007b78f51e1ce7  cmp dword ptr [r15+0x318], 0x00
00007b78f51e1cef  jz 0x00007B78F51E1E20
00007b78f51e1cf5  nop [rax+rax*1], ax
00007b78f51e1cfe  nop [rax+rax*1], eax
00007b78f51e1d06  mov eax, 0x410474
00007b78f51e1d0b  mov [r15+0x100], rax
00007b78f51e1d12  jmp 0x00007B78F4FFE110
00007b78f51e1d17  int3
00007b78f51e1d18  call 0x00007B78F50E27E0
00007b78f51e1d1d  jmp 0x00007B78F51E1AC3
00007b78f51e1d22  call 0x00007B78F50E27E0
00007b78f51e1d27  jmp 0x00007B78F51E1AD6
00007b78f51e1d2c  call 0x00007B78F50E1570
00007b78f51e1d31  jmp 0x00007B78F51E1AE2
00007b78f51e1d36  call 0x00007B78F50E27E0
00007b78f51e1d3b  jmp 0x00007B78F51E1B1A
00007b78f51e1d40  call 0x00007B78F50E1570
00007b78f51e1d45  jmp 0x00007B78F51E1B26
00007b78f51e1d4a  call 0x00007B78F50E27E0
00007b78f51e1d4f  jmp 0x00007B78F51E1B5E
00007b78f51e1d54  call 0x00007B78F50E1570
00007b78f51e1d59  jmp 0x00007B78F51E1B6A
00007b78f51e1d5e  call 0x00007B78F50E27E0
00007b78f51e1d63  jmp 0x00007B78F51E1BA2
00007b78f51e1d68  call 0x00007B78F50E1570
00007b78f51e1d6d  jmp 0x00007B78F51E1BAE
00007b78f51e1d72  call 0x00007B78F50E27E0
00007b78f51e1d77  jmp 0x00007B78F51E1BED
00007b78f51e1d7c  call 0x00007B78F500E760
00007b78f51e1d81  jmp 0x00007B78F51E1C0A
00007b78f51e1d86  ucomisd xmm1, xmm15
00007b78f51e1d8b  jp 0x00007B78F51E1D9A
00007b78f51e1d8d  movaps xmm13, [0x00007B78F4DFE060]
00007b78f51e1d95  jmp 0x00007B78F51E1C73
00007b78f51e1d9a  vxorps xmm0, xmm1, xmm15
00007b78f51e1d9f  pextrw eax, xmm0, 0x03
00007b78f51e1da4  and eax, 0x7FF8
00007b78f51e1da9  cmp eax, 0x08
00007b78f51e1dac  jnz 0x00007B78F51E1C73
00007b78f51e1db2  movq rax, xmm15
00007b78f51e1db7  shl rax, 0x0D
00007b78f51e1dbb  jbe 0x00007B78F51E1C73
00007b78f51e1dc1  vorps xmm13, xmm15, [0x00007B78F4DFE070]
00007b78f51e1dc9  jmp 0x00007B78F51E1C73
00007b78f51e1dce  ucomisd xmm1, xmm15
00007b78f51e1dd3  jp 0x00007B78F51E1DE2
00007b78f51e1dd5  movaps xmm14, [0x00007B78F4DFE060]
00007b78f51e1ddd  jmp 0x00007B78F51E1CA0
00007b78f51e1de2  vxorps xmm0, xmm1, xmm15
00007b78f51e1de7  pextrw eax, xmm0, 0x03
00007b78f51e1dec  and eax, 0x7FF8
00007b78f51e1df1  cmp eax, 0x08
00007b78f51e1df4  jnz 0x00007B78F51E1CA0
00007b78f51e1dfa  movq rax, xmm15
00007b78f51e1dff  shl rax, 0x0D
00007b78f51e1e03  jbe 0x00007B78F51E1CA0
00007b78f51e1e09  vorps xmm14, xmm15, [0x00007B78F4DFE070]
00007b78f51e1e11  jmp 0x00007B78F51E1CA0
00007b78f51e1e16  int3
00007b78f51e1e17  nop [rax+rax*1], ax
00007b78f51e1e20  mov rax, [r15+0x48]
00007b78f51e1e24  mov r14, [r15+0x50]
00007b78f51e1e28  lea r12, [r14+rax*1]
00007b78f51e1e2c  movups xmm1, [r13+r12*1]
00007b78f51e1e32  movaps [r15+0x120], xmm1
00007b78f51e1e3a  lea r14, [rax+0x10]
00007b78f51e1e3e  mov [r15+0x48], r14
00007b78f51e1e42  xor eax, eax
00007b78f51e1e44  mov r12d, 0x200
00007b78f51e1e4a  cmp r14, r12
00007b78f51e1e4d  cmc
00007b78f51e1e4e  lahf
00007b78f51e1e4f  seto al
00007b78f51e1e52  mov [r15+0x108], eax
00007b78f51e1e59  pextrq rax, xmm1, 0x01
00007b78f51e1e60  movq xmm15, rax
00007b78f51e1e65  movaps [r15+0x130], xmm15
00007b78f51e1e6d  movaps xmm14, [r15+0x110]
00007b78f51e1e75  movq rax, xmm14
00007b78f51e1e7a  movq r14, xmm1
00007b78f51e1e7f  vmovq xmm1, rax
00007b78f51e1e84  vmovq xmm14, r14
00007b78f51e1e89  movaps xmm13, xmm1
00007b78f51e1e8d  addsd xmm13, xmm14
00007b78f51e1e92  ucomisd xmm13, xmm13
00007b78f51e1e97  jp 0x00007B78F51E1F4C
00007b78f51e1e9d  movq xmm13, xmm13
00007b78f51e1ea2  movq rax, xmm13
00007b78f51e1ea7  movq r14, xmm15
00007b78f51e1eac  vmovq xmm1, rax
00007b78f51e1eb1  vmovq xmm15, r14
00007b78f51e1eb6  movaps xmm14, xmm1
00007b78f51e1eba  addsd xmm14, xmm15
00007b78f51e1ebf  ucomisd xmm14, xmm14
00007b78f51e1ec4  jp 0x00007B78F51E1F94
00007b78f51e1eca  movq xmm14, xmm14
00007b78f51e1ecf  movaps [r15+0x110], xmm14
00007b78f51e1ed7  mov eax, [r15+0x108]
00007b78f51e1ede  sahf
00007b78f51e1edf  jnz 0x00007B78F51E1F11
00007b78f51e1ee1  cmp dword ptr [r15+0x318], 0x00
00007b78f51e1ee9  jz 0x00007B78F51E1FE0
00007b78f51e1eef  nop [rax+rax*1], ax
00007b78f51e1ef8  nop [rax+rax*1], eax
00007b78f51e1f00  mov eax, 0x410490
00007b78f51e1f05  mov [r15+0x100], rax
00007b78f51e1f0c  jmp 0x00007B78F4FFE110
00007b78f51e1f11  cmp dword ptr [r15+0x318], 0x00
00007b78f51e1f19  jz 0x00007B78F51E1E20
00007b78f51e1f1f  nop [rax+rax*1], ax
00007b78f51e1f28  nop [rax+rax*1], eax
00007b78f51e1f30  mov eax, 0x410474
00007b78f51e1f35  mov [r15+0x100], rax
00007b78f51e1f3c  jmp 0x00007B78F4FFE110
00007b78f51e1f41  int3
00007b78f51e1f42  call 0x00007B78F50B52F0
00007b78f51e1f47  jmp 0x00007B78F51E1E32
00007b78f51e1f4c  ucomisd xmm1, xmm14
00007b78f51e1f51  jp 0x00007B78F51E1F60
00007b78f51e1f53  movaps xmm13, [0x00007B78F4DFE060]
00007b78f51e1f5b  jmp 0x00007B78F51E1E9D
00007b78f51e1f60  vxorps xmm0, xmm1, xmm14
00007b78f51e1f65  pextrw eax, xmm0, 0x03
00007b78f51e1f6a  and eax, 0x7FF8
00007b78f51e1f6f  cmp eax, 0x08
00007b78f51e1f72  jnz 0x00007B78F51E1E9D
00007b78f51e1f78  movq rax, xmm14
00007b78f51e1f7d  shl rax, 0x0D
00007b78f51e1f81  jbe 0x00007B78F51E1E9D
00007b78f51e1f87  vorps xmm13, xmm14, [0x00007B78F4DFE070]
00007b78f51e1f8f  jmp 0x00007B78F51E1E9D
00007b78f51e1f94  ucomisd xmm1, xmm15
00007b78f51e1f99  jp 0x00007B78F51E1FA8
00007b78f51e1f9b  movaps xmm14, [0x00007B78F4DFE060]
00007b78f51e1fa3  jmp 0x00007B78F51E1ECA
00007b78f51e1fa8  vxorps xmm0, xmm1, xmm15
00007b78f51e1fad  pextrw eax, xmm0, 0x03
00007b78f51e1fb2  and eax, 0x7FF8
00007b78f51e1fb7  cmp eax, 0x08
00007b78f51e1fba  jnz 0x00007B78F51E1ECA
00007b78f51e1fc0  movq rax, xmm15
00007b78f51e1fc5  shl rax, 0x0D
00007b78f51e1fc9  jbe 0x00007B78F51E1ECA
00007b78f51e1fcf  vorps xmm14, xmm15, [0x00007B78F4DFE070]
00007b78f51e1fd7  jmp 0x00007B78F51E1ECA
00007b78f51e1fdc  int3
00007b78f51e1fdd  nop [rax], eax
00007b78f51e1fe0  mov rax, [r15+0x40]
00007b78f51e1fe4  lea r14, [rax+0x510]
00007b78f51e1feb  movaps xmm1, [r15+0x110]
00007b78f51e1ff3  movq rax, xmm1
00007b78f51e1ff8  mov [r13+r14*1], rax
00007b78f51e1ffd  mov rax, [r15+0xF0]
00007b78f51e2004  mov [r15+0x100], rax
00007b78f51e200b  jmp 0x00007B78F51CE5C0
00007b78f51e2010  int3
00007b78f51e2011  call 0x00007B78F50D5EB0
00007b78f51e2016  jmp 0x00007B78F51E1FFD
00007b78f51e201b  int3
00007b78f51e201c  nop [rax], eax
00007b78f51e2020  mov qword ptr [r15+0x100], 0x04
00007b78f51e202b  mov esi, 0x00
00007b78f51e2030  mov edx, 0x09
00007b78f51e2035  mov rdi, 0x7FFC3E5BB170
00007b78f51e203f  mov rax, 0x597478A9C970
00007b78f51e2049  call rax
00007b78f51e204b  cmp dword ptr [r15+0x318], 0x00
00007b78f51e2053  jnz 0x00007B78F4FFE110
00007b78f51e2059  jmp 0x00007B78F4FFE0A0
00007b78f51e205e  int3
00007b78f51e205f  int3
