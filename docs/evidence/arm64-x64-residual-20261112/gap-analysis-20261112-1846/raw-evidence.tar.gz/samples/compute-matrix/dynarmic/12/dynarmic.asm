00007a66921ce69b  nop [rax+rax*1], eax
00007a66921ce6a0  vmovaps xmm1, [0x00007A6691DFE010]
00007a66921ce6a8  movq xmm1, xmm1
00007a66921ce6ac  movaps [r15+0x110], xmm1
00007a66921ce6b4  vmovaps xmm1, [0x00007A6691DFE020]
00007a66921ce6bc  movq xmm1, xmm1
00007a66921ce6c0  movaps [r15+0x120], xmm1
00007a66921ce6c8  mov eax, 0x4204C0
00007a66921ce6cd  mov r14, [r13+rax*1]
00007a66921ce6d2  movq xmm1, r14
00007a66921ce6d7  movaps [r15+0x130], xmm1
00007a66921ce6df  vmovaps xmm1, [0x00007A6691DFE030]
00007a66921ce6e7  vpbroadcastq xmm1, xmm1
00007a66921ce6ec  movaps [r15+0x140], xmm1
00007a66921ce6f4  mov qword ptr [r15+0x40], 0x02
00007a66921ce6fc  vmovaps xmm15, [0x00007A6691DFE040]
00007a66921ce704  movq xmm15, xmm15
00007a66921ce709  movaps [r15+0x150], xmm15
00007a66921ce711  mov qword ptr [r15+0x58], 0x420000
00007a66921ce719  vmovaps xmm15, [0x00007A6691DFE050]
00007a66921ce721  vpbroadcastq xmm15, xmm15
00007a66921ce726  movaps [r15+0x160], xmm15
00007a66921ce72e  mov rax, [r15+0x40]
00007a66921ce732  vmovq xmm14, rax
00007a66921ce737  vpbroadcastq xmm14, xmm14
00007a66921ce73c  movaps [r15+0x170], xmm14
00007a66921ce744  mov eax, 0x4204D0
00007a66921ce749  movups xmm13, [r13+rax*1]
00007a66921ce74f  mov qword ptr [r15+0x40], 0x430518
00007a66921ce757  mov qword ptr [r15+0x50], 0x430720
00007a66921ce75f  vpmovqd xmm12, xmm13
00007a66921ce765  pxor xmm11, xmm11
00007a66921ce76a  punpcklqdq xmm12, xmm11
00007a66921ce76f  movaps [r15+0x210], xmm12
00007a66921ce777  movq xmm12, qword ptr [r15+0x120]
00007a66921ce780  movq xmm11, qword ptr [r15+0x130]
00007a66921ce789  psubd xmm12, xmm11
00007a66921ce78e  movq xmm12, xmm12
00007a66921ce793  paddq xmm13, xmm14
00007a66921ce798  movaps [r15+0x180], xmm13
00007a66921ce7a0  movq xmm14, qword ptr [r15+0x150]
00007a66921ce7a9  paddd xmm11, xmm14
00007a66921ce7ae  movq xmm11, xmm11
00007a66921ce7b3  movq xmm11, xmm11
00007a66921ce7b8  movaps [r15+0x130], xmm11
00007a66921ce7c0  pmovzxdq xmm12, xmm12
00007a66921ce7c6  psllq xmm12, 0x00
00007a66921ce7cc  movq xmm14, qword ptr [r15+0x210]
00007a66921ce7d5  movq xmm13, qword ptr [r15+0x110]
00007a66921ce7de  paddd xmm14, xmm13
00007a66921ce7e3  movq xmm14, xmm14
00007a66921ce7e8  vcvtuqq2pd xmm12, xmm12
00007a66921ce7ee  pmovzxdq xmm14, xmm14
00007a66921ce7f4  psllq xmm14, 0x00
00007a66921ce7fa  vcvtuqq2pd xmm14, xmm14
00007a66921ce800  movaps xmm13, xmm12
00007a66921ce804  mulpd xmm13, xmm1
00007a66921ce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007a66921ce80f  ptest xmm11, xmm11
00007a66921ce815  jnz 0x00007A66921CE8FF
00007a66921ce81b  movaps [r15+0x220], xmm13
00007a66921ce823  mov eax, 0x430720
00007a66921ce828  movups [r13+rax*1], xmm13
00007a66921ce82e  movaps xmm1, xmm14
00007a66921ce832  mulpd xmm1, xmm15
00007a66921ce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007a66921ce83c  ptest xmm13, xmm13
00007a66921ce842  jnz 0x00007A66921CEA4C
00007a66921ce848  movaps [r15+0x210], xmm1
00007a66921ce850  mov eax, 0x430518
00007a66921ce855  movups [r13+rax*1], xmm1
00007a66921ce85b  mov qword ptr [r15+0x48], 0x10
00007a66921ce863  xor eax, eax
00007a66921ce865  mov r14d, 0x10
00007a66921ce86b  mov r12d, 0x200
00007a66921ce871  cmp r14, r12
00007a66921ce874  cmc
00007a66921ce875  lahf
00007a66921ce876  seto al
00007a66921ce879  mov [r15+0x108], eax
00007a66921ce880  mov eax, [r15+0x108]
00007a66921ce887  sahf
00007a66921ce888  jnz 0x00007A66921CE8BA
00007a66921ce88a  cmp dword ptr [r15+0x318], 0x00
00007a66921ce892  jz 0x00007A66921CEFF0
00007a66921ce898  nop [rax+rax*1], ax
00007a66921ce8a1  nop [rax+rax*1], eax
00007a66921ce8a9  mov eax, 0x4101EC
00007a66921ce8ae  mov [r15+0x100], rax
00007a66921ce8b5  jmp 0x00007A6691FFE110
00007a66921ce8ba  cmp dword ptr [r15+0x318], 0x00
00007a66921ce8c2  jz 0x00007A66921CEBA0
00007a66921ce8c8  nop [rax+rax*1], ax
00007a66921ce8d1  nop [rax+rax*1], eax
00007a66921ce8d9  mov eax, 0x4101AC
00007a66921ce8de  mov [r15+0x100], rax
00007a66921ce8e5  jmp 0x00007A6691FFE110
00007a66921ce8ea  int3
00007a66921ce8eb  call 0x00007A669200DC20
00007a66921ce8f0  jmp 0x00007A66921CE6D2
00007a66921ce8f5  call 0x00007A669200C260
00007a66921ce8fa  jmp 0x00007A66921CE74F
00007a66921ce8ff  sub rsp, 0x08
00007a66921ce903  push rax
00007a66921ce904  push rcx
00007a66921ce905  push rdx
00007a66921ce906  push rdi
00007a66921ce907  push rsi
00007a66921ce908  push r8
00007a66921ce90a  push r9
00007a66921ce90c  push r10
00007a66921ce90e  push r11
00007a66921ce910  sub rsp, 0xF0
00007a66921ce917  vmovaps [rsp], xmm0
00007a66921ce91c  vmovaps [rsp+0x10], xmm1
00007a66921ce922  vmovaps [rsp+0x20], xmm2
00007a66921ce928  vmovaps [rsp+0x30], xmm3
00007a66921ce92e  vmovaps [rsp+0x40], xmm4
00007a66921ce934  vmovaps [rsp+0x50], xmm5
00007a66921ce93a  vmovaps [rsp+0x60], xmm6
00007a66921ce940  vmovaps [rsp+0x70], xmm7
00007a66921ce946  vmovaps [rsp+0x80], xmm8
00007a66921ce94f  vmovaps [rsp+0x90], xmm9
00007a66921ce958  vmovaps [rsp+0xA0], xmm10
00007a66921ce961  vmovaps [rsp+0xB0], xmm11
00007a66921ce96a  vmovaps [rsp+0xC0], xmm12
00007a66921ce973  vmovaps [rsp+0xD0], xmm14
00007a66921ce97c  vmovaps [rsp+0xE0], xmm15
00007a66921ce985  sub rsp, 0x30
00007a66921ce989  movaps [rsp], xmm13
00007a66921ce98e  movaps [rsp+0x10], xmm12
00007a66921ce994  movaps [rsp+0x20], xmm1
00007a66921ce999  lea rdi, [rsp]
00007a66921ce99d  mov esi, 0x00
00007a66921ce9a2  mov rax, 0x635346DC7530
00007a66921ce9ac  call rax
00007a66921ce9ae  movaps xmm13, [rsp]
00007a66921ce9b3  add rsp, 0x30
00007a66921ce9b7  vmovaps xmm0, [rsp]
00007a66921ce9bc  vmovaps xmm1, [rsp+0x10]
00007a66921ce9c2  vmovaps xmm2, [rsp+0x20]
00007a66921ce9c8  vmovaps xmm3, [rsp+0x30]
00007a66921ce9ce  vmovaps xmm4, [rsp+0x40]
00007a66921ce9d4  vmovaps xmm5, [rsp+0x50]
00007a66921ce9da  vmovaps xmm6, [rsp+0x60]
00007a66921ce9e0  vmovaps xmm7, [rsp+0x70]
00007a66921ce9e6  vmovaps xmm8, [rsp+0x80]
00007a66921ce9ef  vmovaps xmm9, [rsp+0x90]
00007a66921ce9f8  vmovaps xmm10, [rsp+0xA0]
00007a66921cea01  vmovaps xmm11, [rsp+0xB0]
00007a66921cea0a  vmovaps xmm12, [rsp+0xC0]
00007a66921cea13  vmovaps xmm14, [rsp+0xD0]
00007a66921cea1c  vmovaps xmm15, [rsp+0xE0]
00007a66921cea25  add rsp, 0xF0
00007a66921cea2c  pop r11
00007a66921cea2e  pop r10
00007a66921cea30  pop r9
00007a66921cea32  pop r8
00007a66921cea34  pop rsi
00007a66921cea35  pop rdi
00007a66921cea36  pop rdx
00007a66921cea37  pop rcx
00007a66921cea38  pop rax
00007a66921cea39  add rsp, 0x08
00007a66921cea3d  jmp 0x00007A66921CE81B
00007a66921cea42  call 0x00007A669200C380
00007a66921cea47  jmp 0x00007A66921CE82E
00007a66921cea4c  sub rsp, 0x08
00007a66921cea50  push rax
00007a66921cea51  push rcx
00007a66921cea52  push rdx
00007a66921cea53  push rdi
00007a66921cea54  push rsi
00007a66921cea55  push r8
00007a66921cea57  push r9
00007a66921cea59  push r10
00007a66921cea5b  push r11
00007a66921cea5d  sub rsp, 0xF0
00007a66921cea64  vmovaps [rsp], xmm0
00007a66921cea69  vmovaps [rsp+0x10], xmm2
00007a66921cea6f  vmovaps [rsp+0x20], xmm3
00007a66921cea75  vmovaps [rsp+0x30], xmm4
00007a66921cea7b  vmovaps [rsp+0x40], xmm5
00007a66921cea81  vmovaps [rsp+0x50], xmm6
00007a66921cea87  vmovaps [rsp+0x60], xmm7
00007a66921cea8d  vmovaps [rsp+0x70], xmm8
00007a66921cea93  vmovaps [rsp+0x80], xmm9
00007a66921cea9c  vmovaps [rsp+0x90], xmm10
00007a66921ceaa5  vmovaps [rsp+0xA0], xmm11
00007a66921ceaae  vmovaps [rsp+0xB0], xmm12
00007a66921ceab7  vmovaps [rsp+0xC0], xmm13
00007a66921ceac0  vmovaps [rsp+0xD0], xmm14
00007a66921ceac9  vmovaps [rsp+0xE0], xmm15
00007a66921cead2  sub rsp, 0x30
00007a66921cead6  movaps [rsp], xmm1
00007a66921ceada  movaps [rsp+0x10], xmm14
00007a66921ceae0  movaps [rsp+0x20], xmm15
00007a66921ceae6  lea rdi, [rsp]
00007a66921ceaea  mov esi, 0x00
00007a66921ceaef  mov rax, 0x635346DC7530
00007a66921ceaf9  call rax
00007a66921ceafb  movaps xmm1, [rsp]
00007a66921ceaff  add rsp, 0x30
00007a66921ceb03  vmovaps xmm0, [rsp]
00007a66921ceb08  vmovaps xmm2, [rsp+0x10]
00007a66921ceb0e  vmovaps xmm3, [rsp+0x20]
00007a66921ceb14  vmovaps xmm4, [rsp+0x30]
00007a66921ceb1a  vmovaps xmm5, [rsp+0x40]
00007a66921ceb20  vmovaps xmm6, [rsp+0x50]
00007a66921ceb26  vmovaps xmm7, [rsp+0x60]
00007a66921ceb2c  vmovaps xmm8, [rsp+0x70]
00007a66921ceb32  vmovaps xmm9, [rsp+0x80]
00007a66921ceb3b  vmovaps xmm10, [rsp+0x90]
00007a66921ceb44  vmovaps xmm11, [rsp+0xA0]
00007a66921ceb4d  vmovaps xmm12, [rsp+0xB0]
00007a66921ceb56  vmovaps xmm13, [rsp+0xC0]
00007a66921ceb5f  vmovaps xmm14, [rsp+0xD0]
00007a66921ceb68  vmovaps xmm15, [rsp+0xE0]
00007a66921ceb71  add rsp, 0xF0
00007a66921ceb78  pop r11
00007a66921ceb7a  pop r10
00007a66921ceb7c  pop r9
00007a66921ceb7e  pop r8
00007a66921ceb80  pop rsi
00007a66921ceb81  pop rdi
00007a66921ceb82  pop rdx
00007a66921ceb83  pop rcx
00007a66921ceb84  pop rax
00007a66921ceb85  add rsp, 0x08
00007a66921ceb89  jmp 0x00007A66921CE848
00007a66921ceb8e  call 0x00007A6691FFF540
00007a66921ceb93  jmp 0x00007A66921CE85B
00007a66921ceb98  int3
00007a66921ceb99  nop [rax], eax
00007a66921ceba0  movaps xmm1, [r15+0x180]
00007a66921ceba8  vpmovqd xmm15, xmm1
00007a66921cebae  pxor xmm14, xmm14
00007a66921cebb3  punpcklqdq xmm15, xmm14
00007a66921cebb8  movaps [r15+0x210], xmm15
00007a66921cebc0  movq xmm15, qword ptr [r15+0x120]
00007a66921cebc9  movq xmm14, qword ptr [r15+0x130]
00007a66921cebd2  psubd xmm15, xmm14
00007a66921cebd7  movq xmm15, xmm15
00007a66921cebdc  movaps xmm13, [r15+0x170]
00007a66921cebe4  paddq xmm1, xmm13
00007a66921cebe9  movaps [r15+0x180], xmm1
00007a66921cebf1  movq xmm1, qword ptr [r15+0x150]
00007a66921cebfa  paddd xmm14, xmm1
00007a66921cebff  movq xmm14, xmm14
00007a66921cec04  movq xmm14, xmm14
00007a66921cec09  movaps [r15+0x130], xmm14
00007a66921cec11  pmovzxdq xmm15, xmm15
00007a66921cec17  psllq xmm15, 0x00
00007a66921cec1d  movq xmm1, qword ptr [r15+0x210]
00007a66921cec26  movq xmm14, qword ptr [r15+0x110]
00007a66921cec2f  paddd xmm1, xmm14
00007a66921cec34  movq xmm1, xmm1
00007a66921cec38  vcvtuqq2pd xmm15, xmm15
00007a66921cec3e  pmovzxdq xmm1, xmm1
00007a66921cec43  psllq xmm1, 0x00
00007a66921cec48  vcvtuqq2pd xmm1, xmm1
00007a66921cec4e  movaps xmm14, [r15+0x140]
00007a66921cec56  movaps xmm13, xmm15
00007a66921cec5a  mulpd xmm13, xmm14
00007a66921cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007a66921cec65  ptest xmm12, xmm12
00007a66921cec6b  jnz 0x00007A66921CED4E
00007a66921cec71  movaps [r15+0x220], xmm13
00007a66921cec79  mov rax, [r15+0x48]
00007a66921cec7d  mov r14, [r15+0x50]
00007a66921cec81  lea r12, [r14+rax*1]
00007a66921cec85  movups [r13+r12*1], xmm13
00007a66921cec8b  movaps xmm15, [r15+0x160]
00007a66921cec93  movaps xmm14, xmm1
00007a66921cec97  mulpd xmm14, xmm15
00007a66921cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007a66921ceca2  ptest xmm13, xmm13
00007a66921ceca8  jnz 0x00007A66921CEE9C
00007a66921cecae  movaps [r15+0x210], xmm14
00007a66921cecb6  mov r14, [r15+0x40]
00007a66921cecba  lea r12, [r14+rax*1]
00007a66921cecbe  movups [r13+r12*1], xmm14
00007a66921cecc4  lea r14, [rax+0x10]
00007a66921cecc8  mov [r15+0x48], r14
00007a66921ceccc  xor eax, eax
00007a66921cecce  mov r12d, 0x200
00007a66921cecd4  cmp r14, r12
00007a66921cecd7  cmc
00007a66921cecd8  lahf
00007a66921cecd9  seto al
00007a66921cecdc  mov [r15+0x108], eax
00007a66921cece3  mov eax, [r15+0x108]
00007a66921cecea  sahf
00007a66921ceceb  jnz 0x00007A66921CED1D
00007a66921ceced  cmp dword ptr [r15+0x318], 0x00
00007a66921cecf5  jz 0x00007A66921CEFF0
00007a66921cecfb  nop [rax+rax*1], ax
00007a66921ced04  nop [rax+rax*1], eax
00007a66921ced0c  mov eax, 0x4101EC
00007a66921ced11  mov [r15+0x100], rax
00007a66921ced18  jmp 0x00007A6691FFE110
00007a66921ced1d  cmp dword ptr [r15+0x318], 0x00
00007a66921ced25  jz 0x00007A66921CEBA0
00007a66921ced2b  nop [rax+rax*1], ax
00007a66921ced34  nop [rax+rax*1], eax
00007a66921ced3c  mov eax, 0x4101AC
00007a66921ced41  mov [r15+0x100], rax
00007a66921ced48  jmp 0x00007A6691FFE110
00007a66921ced4d  int3
00007a66921ced4e  sub rsp, 0x08
00007a66921ced52  push rax
00007a66921ced53  push rcx
00007a66921ced54  push rdx
00007a66921ced55  push rdi
00007a66921ced56  push rsi
00007a66921ced57  push r8
00007a66921ced59  push r9
00007a66921ced5b  push r10
00007a66921ced5d  push r11
00007a66921ced5f  sub rsp, 0xF0
00007a66921ced66  vmovaps [rsp], xmm0
00007a66921ced6b  vmovaps [rsp+0x10], xmm1
00007a66921ced71  vmovaps [rsp+0x20], xmm2
00007a66921ced77  vmovaps [rsp+0x30], xmm3
00007a66921ced7d  vmovaps [rsp+0x40], xmm4
00007a66921ced83  vmovaps [rsp+0x50], xmm5
00007a66921ced89  vmovaps [rsp+0x60], xmm6
00007a66921ced8f  vmovaps [rsp+0x70], xmm7
00007a66921ced95  vmovaps [rsp+0x80], xmm8
00007a66921ced9e  vmovaps [rsp+0x90], xmm9
00007a66921ceda7  vmovaps [rsp+0xA0], xmm10
00007a66921cedb0  vmovaps [rsp+0xB0], xmm11
00007a66921cedb9  vmovaps [rsp+0xC0], xmm12
00007a66921cedc2  vmovaps [rsp+0xD0], xmm14
00007a66921cedcb  vmovaps [rsp+0xE0], xmm15
00007a66921cedd4  sub rsp, 0x30
00007a66921cedd8  movaps [rsp], xmm13
00007a66921ceddd  movaps [rsp+0x10], xmm15
00007a66921cede3  movaps [rsp+0x20], xmm14
00007a66921cede9  lea rdi, [rsp]
00007a66921ceded  mov esi, 0x00
00007a66921cedf2  mov rax, 0x635346DC7530
00007a66921cedfc  call rax
00007a66921cedfe  movaps xmm13, [rsp]
00007a66921cee03  add rsp, 0x30
00007a66921cee07  vmovaps xmm0, [rsp]
00007a66921cee0c  vmovaps xmm1, [rsp+0x10]
00007a66921cee12  vmovaps xmm2, [rsp+0x20]
00007a66921cee18  vmovaps xmm3, [rsp+0x30]
00007a66921cee1e  vmovaps xmm4, [rsp+0x40]
00007a66921cee24  vmovaps xmm5, [rsp+0x50]
00007a66921cee2a  vmovaps xmm6, [rsp+0x60]
00007a66921cee30  vmovaps xmm7, [rsp+0x70]
00007a66921cee36  vmovaps xmm8, [rsp+0x80]
00007a66921cee3f  vmovaps xmm9, [rsp+0x90]
00007a66921cee48  vmovaps xmm10, [rsp+0xA0]
00007a66921cee51  vmovaps xmm11, [rsp+0xB0]
00007a66921cee5a  vmovaps xmm12, [rsp+0xC0]
00007a66921cee63  vmovaps xmm14, [rsp+0xD0]
00007a66921cee6c  vmovaps xmm15, [rsp+0xE0]
00007a66921cee75  add rsp, 0xF0
00007a66921cee7c  pop r11
00007a66921cee7e  pop r10
00007a66921cee80  pop r9
00007a66921cee82  pop r8
00007a66921cee84  pop rsi
00007a66921cee85  pop rdi
00007a66921cee86  pop rdx
00007a66921cee87  pop rcx
00007a66921cee88  pop rax
00007a66921cee89  add rsp, 0x08
00007a66921cee8d  jmp 0x00007A66921CEC71
00007a66921cee92  call 0x00007A66920C2240
00007a66921cee97  jmp 0x00007A66921CEC8B
00007a66921cee9c  sub rsp, 0x08
00007a66921ceea0  push rax
00007a66921ceea1  push rcx
00007a66921ceea2  push rdx
00007a66921ceea3  push rdi
00007a66921ceea4  push rsi
00007a66921ceea5  push r8
00007a66921ceea7  push r9
00007a66921ceea9  push r10
00007a66921ceeab  push r11
00007a66921ceead  sub rsp, 0xF0
00007a66921ceeb4  vmovaps [rsp], xmm0
00007a66921ceeb9  vmovaps [rsp+0x10], xmm1
00007a66921ceebf  vmovaps [rsp+0x20], xmm2
00007a66921ceec5  vmovaps [rsp+0x30], xmm3
00007a66921ceecb  vmovaps [rsp+0x40], xmm4
00007a66921ceed1  vmovaps [rsp+0x50], xmm5
00007a66921ceed7  vmovaps [rsp+0x60], xmm6
00007a66921ceedd  vmovaps [rsp+0x70], xmm7
00007a66921ceee3  vmovaps [rsp+0x80], xmm8
00007a66921ceeec  vmovaps [rsp+0x90], xmm9
00007a66921ceef5  vmovaps [rsp+0xA0], xmm10
00007a66921ceefe  vmovaps [rsp+0xB0], xmm11
00007a66921cef07  vmovaps [rsp+0xC0], xmm12
00007a66921cef10  vmovaps [rsp+0xD0], xmm13
00007a66921cef19  vmovaps [rsp+0xE0], xmm15
00007a66921cef22  sub rsp, 0x30
00007a66921cef26  movaps [rsp], xmm14
00007a66921cef2b  movaps [rsp+0x10], xmm1
00007a66921cef30  movaps [rsp+0x20], xmm15
00007a66921cef36  lea rdi, [rsp]
00007a66921cef3a  mov esi, 0x00
00007a66921cef3f  mov rax, 0x635346DC7530
00007a66921cef49  call rax
00007a66921cef4b  movaps xmm14, [rsp]
00007a66921cef50  add rsp, 0x30
00007a66921cef54  vmovaps xmm0, [rsp]
00007a66921cef59  vmovaps xmm1, [rsp+0x10]
00007a66921cef5f  vmovaps xmm2, [rsp+0x20]
00007a66921cef65  vmovaps xmm3, [rsp+0x30]
00007a66921cef6b  vmovaps xmm4, [rsp+0x40]
00007a66921cef71  vmovaps xmm5, [rsp+0x50]
00007a66921cef77  vmovaps xmm6, [rsp+0x60]
00007a66921cef7d  vmovaps xmm7, [rsp+0x70]
00007a66921cef83  vmovaps xmm8, [rsp+0x80]
00007a66921cef8c  vmovaps xmm9, [rsp+0x90]
00007a66921cef95  vmovaps xmm10, [rsp+0xA0]
00007a66921cef9e  vmovaps xmm11, [rsp+0xB0]
00007a66921cefa7  vmovaps xmm12, [rsp+0xC0]
00007a66921cefb0  vmovaps xmm13, [rsp+0xD0]
00007a66921cefb9  vmovaps xmm15, [rsp+0xE0]
00007a66921cefc2  add rsp, 0xF0
00007a66921cefc9  pop r11
00007a66921cefcb  pop r10
00007a66921cefcd  pop r9
00007a66921cefcf  pop r8
00007a66921cefd1  pop rsi
00007a66921cefd2  pop rdi
00007a66921cefd3  pop rdx
00007a66921cefd4  pop rcx
00007a66921cefd5  pop rax
00007a66921cefd6  add rsp, 0x08
00007a66921cefda  jmp 0x00007A66921CECAE
00007a66921cefdf  call 0x00007A66920C34C0
00007a66921cefe4  jmp 0x00007A66921CECC4
00007a66921cefe9  int3
00007a66921cefea  nop [rax+rax*1], ax
00007a66921ceff0  mov rax, [r15+0xF8]
00007a66921ceff7  lea r14, [rax-0x150]
00007a66921ceffe  mov [r15+0xF8], r14
00007a66921cf005  mov rax, [r15+0x50]
00007a66921cf009  lea r12, [rax+0x80]
00007a66921cf010  movups xmm1, [r13+r12*1]
00007a66921cf016  lea r12, [rax+0x90]
00007a66921cf01d  movups xmm15, [r13+r12*1]
00007a66921cf023  mov qword ptr [r15+0x48], 0x00
00007a66921cf02b  lea r12, [rax+0x40]
00007a66921cf02f  movups xmm14, [r13+r12*1]
00007a66921cf035  lea r12, [rax+0x50]
00007a66921cf039  movups xmm13, [r13+r12*1]
00007a66921cf03f  lea r12, [r14+0x120]
00007a66921cf046  movq xmm12, qword ptr [r15+0x1C0]
00007a66921cf04f  movq xmm11, qword ptr [r15+0x1B0]
00007a66921cf058  movq r11, xmm12
00007a66921cf05d  movq r10, xmm11
00007a66921cf062  mov [r13+r12*1], r11
00007a66921cf067  lea r12, [r14+0x128]
00007a66921cf06e  mov [r13+r12*1], r10
00007a66921cf073  vxorps xmm12, xmm12, xmm12
00007a66921cf078  vpbroadcastq xmm12, xmm12
00007a66921cf07d  lea r12, [r14+0x100]
00007a66921cf084  movq xmm11, qword ptr [r15+0x200]
00007a66921cf08d  movq xmm10, qword ptr [r15+0x1F0]
00007a66921cf096  movq r11, xmm11
00007a66921cf09b  movq r10, xmm10
00007a66921cf0a0  mov [r13+r12*1], r11
00007a66921cf0a5  lea r12, [r14+0x108]
00007a66921cf0ac  mov [r13+r12*1], r10
00007a66921cf0b1  lea r12, [r14+0xE0]
00007a66921cf0b8  movups [r13+r12*1], xmm15
00007a66921cf0be  lea r12, [r14+0xF0]
00007a66921cf0c5  movups [r13+r12*1], xmm1
00007a66921cf0cb  lea r12, [rax+0xC0]
00007a66921cf0d2  movups xmm1, [r13+r12*1]
00007a66921cf0d8  lea r12, [rax+0xD0]
00007a66921cf0df  movups xmm15, [r13+r12*1]
00007a66921cf0e5  lea r12, [r14+0x110]
00007a66921cf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007a66921cf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007a66921cf0fe  movq r11, xmm11
00007a66921cf103  movq r10, xmm10
00007a66921cf108  mov [r13+r12*1], r11
00007a66921cf10d  lea r12, [r14+0x118]
00007a66921cf114  mov [r13+r12*1], r10
00007a66921cf119  movups xmm11, [r13+rax*1]
00007a66921cf11f  lea r12, [rax+0x10]
00007a66921cf123  movups xmm10, [r13+r12*1]
00007a66921cf129  lea r12, [r14+0x130]
00007a66921cf130  movq xmm9, qword ptr [r15+0x1A0]
00007a66921cf139  movq xmm8, qword ptr [r15+0x190]
00007a66921cf142  movq r11, xmm9
00007a66921cf147  movq r10, xmm8
00007a66921cf14c  mov [r13+r12*1], r11
00007a66921cf151  lea r12, [r14+0x138]
00007a66921cf158  mov [r13+r12*1], r10
00007a66921cf15d  lea r12, [rax+0x140]
00007a66921cf164  movups xmm9, [r13+r12*1]
00007a66921cf16a  lea r12, [rax+0x150]
00007a66921cf171  movups xmm8, [r13+r12*1]
00007a66921cf177  lea r12, [r14+0xC0]
00007a66921cf17e  movups [r13+r12*1], xmm15
00007a66921cf184  lea r12, [r14+0xD0]
00007a66921cf18b  movups [r13+r12*1], xmm1
00007a66921cf191  lea r12, [rax+0x100]
00007a66921cf198  movups xmm1, [r13+r12*1]
00007a66921cf19e  lea r12, [rax+0x110]
00007a66921cf1a5  movups xmm15, [r13+r12*1]
00007a66921cf1ab  lea r12, [r14+0x140]
00007a66921cf1b2  mov r11, [r15+0xE8]
00007a66921cf1b9  mov [r13+r12*1], r11
00007a66921cf1be  lea r12, [rax+0x180]
00007a66921cf1c5  movups xmm7, [r13+r12*1]
00007a66921cf1cb  lea r12, [rax+0x190]
00007a66921cf1d2  movups xmm6, [r13+r12*1]
00007a66921cf1d8  lea r12, [rax+0x1C0]
00007a66921cf1df  movups xmm5, [r13+r12*1]
00007a66921cf1e5  lea r12, [rax+0x1D0]
00007a66921cf1ec  movups xmm4, [r13+r12*1]
00007a66921cf1f2  lea r12, [r14+0x20]
00007a66921cf1f6  movups [r13+r12*1], xmm1
00007a66921cf1fc  lea r12, [r14+0x30]
00007a66921cf200  movups [r13+r12*1], xmm13
00007a66921cf206  lea r12, [rax+0x60]
00007a66921cf20a  movups xmm1, [r13+r12*1]
00007a66921cf210  lea r12, [rax+0x70]
00007a66921cf214  movups xmm13, [r13+r12*1]
00007a66921cf21a  lea r12, [rax+0x20]
00007a66921cf21e  movups xmm3, [r13+r12*1]
00007a66921cf224  lea r12, [rax+0x30]
00007a66921cf228  movups xmm2, [r13+r12*1]
00007a66921cf22e  movaps [r15+0x1F0], xmm2
00007a66921cf236  lea r12, [r14+0x60]
00007a66921cf23a  movups [r13+r12*1], xmm11
00007a66921cf240  lea r12, [r14+0x70]
00007a66921cf244  movups [r13+r12*1], xmm5
00007a66921cf24a  lea r12, [rax+0xE0]
00007a66921cf251  movups xmm11, [r13+r12*1]
00007a66921cf257  lea r12, [rax+0xF0]
00007a66921cf25e  movups xmm5, [r13+r12*1]
00007a66921cf264  lea r12, [r14+0xA0]
00007a66921cf26b  movups [r13+r12*1], xmm13
00007a66921cf271  lea r12, [r14+0xB0]
00007a66921cf278  movups [r13+r12*1], xmm1
00007a66921cf27e  lea r12, [rax+0xA0]
00007a66921cf285  movups xmm1, [r13+r12*1]
00007a66921cf28b  lea r12, [rax+0xB0]
00007a66921cf292  movups xmm13, [r13+r12*1]
00007a66921cf298  lea r12, [rax+0x120]
00007a66921cf29f  vmovaps [rsp+0x10], xmm1
00007a66921cf2a5  movups xmm1, [r13+r12*1]
00007a66921cf2ab  lea r12, [rax+0x130]
00007a66921cf2b2  vmovaps [rsp+0x20], xmm1
00007a66921cf2b8  movups xmm1, [r13+r12*1]
00007a66921cf2be  lea r12, [rax+0x160]
00007a66921cf2c5  vmovaps [rsp+0x30], xmm1
00007a66921cf2cb  movups xmm1, [r13+r12*1]
00007a66921cf2d1  lea r12, [rax+0x170]
00007a66921cf2d8  vmovaps [rsp+0x40], xmm1
00007a66921cf2de  movups xmm1, [r13+r12*1]
00007a66921cf2e4  movaps [r15+0x2B0], xmm1
00007a66921cf2ec  lea r12, [r14+0x80]
00007a66921cf2f3  movups [r13+r12*1], xmm13
00007a66921cf2f9  lea r12, [r14+0x90]
00007a66921cf300  vmovaps xmm13, [rsp+0x10]
00007a66921cf306  movups [r13+r12*1], xmm13
00007a66921cf30c  lea r12, [rax+0x1A0]
00007a66921cf313  movups xmm13, [r13+r12*1]
00007a66921cf319  lea r12, [rax+0x1B0]
00007a66921cf320  vmovaps [rsp+0x10], xmm1
00007a66921cf326  movups xmm1, [r13+r12*1]
00007a66921cf32c  movaps [r15+0x290], xmm13
00007a66921cf334  movaps [r15+0x1E0], xmm1
00007a66921cf33c  lea r12, [rax+0x1E0]
00007a66921cf343  vmovaps [rsp+0x50], xmm1
00007a66921cf349  movups xmm1, [r13+r12*1]
00007a66921cf34f  lea r12, [rax+0x1F0]
00007a66921cf356  vmovaps [rsp+0x60], xmm1
00007a66921cf35c  movups xmm1, [r13+r12*1]
00007a66921cf362  mov qword ptr [r15+0x50], 0x430920
00007a66921cf36a  lea rax, [r14+0x40]
00007a66921cf36e  vmovaps [rsp+0x70], xmm1
00007a66921cf374  vmovaps xmm1, [rsp+0x40]
00007a66921cf37a  movups [r13+rax*1], xmm1
00007a66921cf380  lea rax, [r14+0x50]
00007a66921cf384  movups [r13+rax*1], xmm10
00007a66921cf38a  vmovaps xmm1, [rsp+0x70]
00007a66921cf390  movups [r13+r14*1], xmm1
00007a66921cf396  lea rax, [r14+0x10]
00007a66921cf39a  vmovaps xmm1, [rsp+0x60]
00007a66921cf3a0  movups [r13+rax*1], xmm1
00007a66921cf3a6  mov rax, [r15+0x40]
00007a66921cf3aa  vmovaps [rsp+0x40], xmm3
00007a66921cf3b0  vmovaps xmm1, [rsp+0x40]
00007a66921cf3b6  por xmm3, xmm1
00007a66921cf3ba  vmovaps [rsp+0x40], xmm6
00007a66921cf3c0  vmovaps xmm10, [rsp+0x40]
00007a66921cf3c6  por xmm6, xmm10
00007a66921cf3cb  lea r12, [rax+0x30]
00007a66921cf3cf  mov r11, [r13+r12*1]
00007a66921cf3d4  lea r12, [rax+0x38]
00007a66921cf3d8  mov r10, [r13+r12*1]
00007a66921cf3dd  movq xmm10, r11
00007a66921cf3e2  vmovaps [rsp+0x40], xmm1
00007a66921cf3e8  movq xmm1, r10
00007a66921cf3ed  movq xmm10, xmm10
00007a66921cf3f2  vmovaps [rsp+0x60], xmm10
00007a66921cf3f8  movq xmm10, xmm10
00007a66921cf3fd  movaps [r15+0x130], xmm10
00007a66921cf405  movq xmm1, xmm1
00007a66921cf409  vmovaps [rsp+0x70], xmm1
00007a66921cf40f  movq xmm1, xmm1
00007a66921cf413  movaps [r15+0x280], xmm1
00007a66921cf41b  vmovaps [rsp+0x80], xmm9
00007a66921cf424  vmovaps xmm1, [rsp+0x80]
00007a66921cf42d  por xmm9, xmm1
00007a66921cf432  lea r12, [rax+0x20]
00007a66921cf436  mov r11, [r13+r12*1]
00007a66921cf43b  lea r12, [rax+0x28]
00007a66921cf43f  mov r10, [r13+r12*1]
00007a66921cf444  movq xmm1, r11
00007a66921cf449  movq xmm10, r10
00007a66921cf44e  movq xmm1, xmm1
00007a66921cf452  vmovaps [rsp+0x80], xmm1
00007a66921cf45b  movq xmm1, xmm1
00007a66921cf45f  movaps [r15+0x150], xmm1
00007a66921cf467  movq xmm10, xmm10
00007a66921cf46c  vmovaps [rsp+0x90], xmm10
00007a66921cf475  movq xmm10, xmm10
00007a66921cf47a  movaps [r15+0x140], xmm10
00007a66921cf482  lea r12, [rax+0x10]
00007a66921cf486  mov r11, [r13+r12*1]
00007a66921cf48b  lea r12, [rax+0x18]
00007a66921cf48f  mov r10, [r13+r12*1]
00007a66921cf494  movq xmm1, r11
00007a66921cf499  movq xmm10, r10
00007a66921cf49e  movq xmm1, xmm1
00007a66921cf4a2  vmovaps [rsp+0xA0], xmm1
00007a66921cf4ab  movq xmm1, xmm1
00007a66921cf4af  movaps [r15+0x170], xmm1
00007a66921cf4b7  movq xmm10, xmm10
00007a66921cf4bc  vmovaps [rsp+0xB0], xmm10
00007a66921cf4c5  movq xmm10, xmm10
00007a66921cf4ca  movaps [r15+0x160], xmm10
00007a66921cf4d2  mov r12, [r13+rax*1]
00007a66921cf4d7  vmovq xmm1, r12
00007a66921cf4dc  vpbroadcastq xmm1, xmm1
00007a66921cf4e1  lea r12, [rax+0x08]
00007a66921cf4e5  mov rax, [r13+r12*1]
00007a66921cf4ea  movq xmm10, rax
00007a66921cf4ef  movaps [r15+0x230], xmm10
00007a66921cf4f7  lea rax, [r14+0x50]
00007a66921cf4fb  movups xmm10, [r13+rax*1]
00007a66921cf501  lea rax, [r14+0x60]
00007a66921cf505  vmovaps [rsp+0xC0], xmm1
00007a66921cf50e  movups xmm1, [r13+rax*1]
00007a66921cf514  lea rax, [r14+0x30]
00007a66921cf518  vmovaps [rsp+0xD0], xmm1
00007a66921cf521  movups xmm1, [r13+rax*1]
00007a66921cf527  mov qword ptr [r15+0x60], 0x430920
00007a66921cf52f  mov qword ptr [r15+0x58], 0x40
00007a66921cf537  vmovaps [rsp+0xE0], xmm1
00007a66921cf540  vmovaps [rsp+0xF0], xmm15
00007a66921cf549  vmovaps xmm15, [rsp+0xC0]
00007a66921cf552  vmovaps [rsp+0xC0], xmm14
00007a66921cf55b  vmovaps xmm14, [rsp+0x40]
00007a66921cf561  vmovaps [rsp+0x40], xmm13
00007a66921cf567  movaps xmm1, xmm15
00007a66921cf56b  mulpd xmm1, xmm14
00007a66921cf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007a66921cf575  ptest xmm13, xmm13
00007a66921cf57b  jnz 0x00007A66921D0682
00007a66921cf581  movq xmm14, qword ptr [r15+0x230]
00007a66921cf58a  vmovaps [rsp+0x100], xmm14
00007a66921cf593  vpermilpd xmm14, xmm14, 0x00
00007a66921cf599  vmovaps [rsp+0x110], xmm1
00007a66921cf5a2  vmovaps xmm1, [rsp+0xE0]
00007a66921cf5ab  vmovaps [rsp+0xE0], xmm15
00007a66921cf5b4  movaps xmm13, xmm1
00007a66921cf5b8  mulpd xmm13, xmm14
00007a66921cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007a66921cf5c3  ptest xmm15, xmm15
00007a66921cf5c9  jnz 0x00007A66921D07C4
00007a66921cf5cf  vxorps xmm1, xmm1, xmm1
00007a66921cf5d3  vpbroadcastq xmm1, xmm1
00007a66921cf5d8  vmovaps xmm14, [rsp+0xE0]
00007a66921cf5e1  vmovaps [rsp+0xE0], xmm1
00007a66921cf5ea  vmovaps xmm1, [rsp+0xD0]
00007a66921cf5f3  vmovaps [rsp+0xD0], xmm13
00007a66921cf5fc  movaps xmm15, xmm14
00007a66921cf600  mulpd xmm15, xmm1
00007a66921cf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007a66921cf60b  ptest xmm13, xmm13
00007a66921cf611  jnz 0x00007A66921D0907
00007a66921cf617  movaps xmm1, xmm14
00007a66921cf61b  mulpd xmm1, xmm10
00007a66921cf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007a66921cf625  ptest xmm13, xmm13
00007a66921cf62b  jnz 0x00007A66921D0A4A
00007a66921cf631  movaps xmm13, xmm14
00007a66921cf635  mulpd xmm13, xmm2
00007a66921cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007a66921cf640  ptest xmm10, xmm10
00007a66921cf646  jnz 0x00007A66921D0B8C
00007a66921cf64c  vmovaps [rsp+0x120], xmm7
00007a66921cf655  vmovaps xmm14, [rsp+0x120]
00007a66921cf65e  por xmm7, xmm14
00007a66921cf663  vmovaps xmm14, [rsp+0xC0]
00007a66921cf66c  vmovaps xmm10, [rsp+0xC0]
00007a66921cf675  por xmm14, xmm10
00007a66921cf67a  vmovaps xmm2, [rsp+0x100]
00007a66921cf683  vpermilpd xmm2, xmm2, 0x00
00007a66921cf689  vmovaps [rsp+0xC0], xmm1
00007a66921cf692  vmovaps [rsp+0x120], xmm15
00007a66921cf69b  movaps xmm1, xmm10
00007a66921cf69f  mulpd xmm1, xmm2
00007a66921cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007a66921cf6a8  ptest xmm15, xmm15
00007a66921cf6ae  jnz 0x00007A66921D0CCF
00007a66921cf6b4  xor eax, eax
00007a66921cf6b6  mov r12d, 0x40
00007a66921cf6bc  mov r11d, 0x200
00007a66921cf6c2  cmp r12, r11
00007a66921cf6c5  cmc
00007a66921cf6c6  lahf
00007a66921cf6c7  seto al
00007a66921cf6ca  mov [r15+0x108], eax
00007a66921cf6d1  vmovaps xmm10, [rsp+0x110]
00007a66921cf6da  vmovaps xmm2, [rsp+0xE0]
00007a66921cf6e3  vmovaps [rsp+0xE0], xmm1
00007a66921cf6ec  movaps xmm15, xmm10
00007a66921cf6f0  addpd xmm15, xmm2
00007a66921cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007a66921cf6fb  ptest xmm1, xmm1
00007a66921cf700  jnz 0x00007A66921D0E10
00007a66921cf706  vmovaps xmm10, [rsp+0x120]
00007a66921cf70f  vmovaps [rsp+0x110], xmm15
00007a66921cf718  movaps xmm1, xmm10
00007a66921cf71c  addpd xmm1, xmm12
00007a66921cf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007a66921cf726  ptest xmm15, xmm15
00007a66921cf72c  jnz 0x00007A66921D0F53
00007a66921cf732  vmovaps xmm10, [rsp+0xC0]
00007a66921cf73b  vmovaps [rsp+0xC0], xmm1
00007a66921cf744  movaps xmm15, xmm10
00007a66921cf748  addpd xmm15, xmm12
00007a66921cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007a66921cf753  ptest xmm1, xmm1
00007a66921cf758  jnz 0x00007A66921D1095
00007a66921cf75e  vmovaps xmm1, [rsp+0x30]
00007a66921cf764  vmovaps xmm12, [rsp+0x30]
00007a66921cf76a  por xmm1, xmm12
00007a66921cf76f  vmovaps xmm12, [rsp+0x20]
00007a66921cf775  vmovaps xmm10, [rsp+0x20]
00007a66921cf77b  por xmm12, xmm10
00007a66921cf780  vmovaps [rsp+0x20], xmm5
00007a66921cf786  vmovaps xmm10, [rsp+0x20]
00007a66921cf78c  por xmm5, xmm10
00007a66921cf791  vmovaps [rsp+0x20], xmm11
00007a66921cf797  vmovaps xmm10, [rsp+0x20]
00007a66921cf79d  por xmm11, xmm10
00007a66921cf7a2  vmovaps [rsp+0x20], xmm4
00007a66921cf7a8  vmovaps xmm10, [rsp+0x20]
00007a66921cf7ae  por xmm4, xmm10
00007a66921cf7b3  vmovaps [rsp+0x20], xmm8
00007a66921cf7b9  vmovaps xmm10, [rsp+0x20]
00007a66921cf7bf  por xmm8, xmm10
00007a66921cf7c4  vmovaps xmm10, [rsp+0xF0]
00007a66921cf7cd  vmovaps [rsp+0x20], xmm1
00007a66921cf7d3  vmovaps xmm1, [rsp+0xF0]
00007a66921cf7dc  por xmm10, xmm1
00007a66921cf7e1  lea rax, [r14+0xA0]
00007a66921cf7e8  movups xmm1, [r13+rax*1]
00007a66921cf7ee  lea rax, [r14+0xB0]
00007a66921cf7f5  vmovaps [rsp+0x30], xmm1
00007a66921cf7fb  movups xmm1, [r13+rax*1]
00007a66921cf801  vmovaps [rsp+0xF0], xmm1
00007a66921cf80a  vmovaps [rsp+0x120], xmm15
00007a66921cf813  movaps xmm1, xmm13
00007a66921cf817  addpd xmm1, xmm2
00007a66921cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007a66921cf820  ptest xmm15, xmm15
00007a66921cf826  jnz 0x00007A66921D11ED
00007a66921cf82c  lea rax, [r14+0xF0]
00007a66921cf833  movups xmm15, [r13+rax*1]
00007a66921cf839  vmovaps xmm2, [rsp+0xC0]
00007a66921cf842  vmovaps [rsp+0xC0], xmm1
00007a66921cf84b  vmovaps xmm1, [rsp+0xE0]
00007a66921cf854  vmovaps [rsp+0xE0], xmm15
00007a66921cf85d  movaps xmm13, xmm2
00007a66921cf861  addpd xmm13, xmm1
00007a66921cf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007a66921cf86c  ptest xmm15, xmm15
00007a66921cf872  jnz 0x00007A66921D1338
00007a66921cf878  vmovaps xmm15, [rsp+0x120]
00007a66921cf881  vmovaps xmm2, [rsp+0xD0]
00007a66921cf88a  vmovaps [rsp+0xD0], xmm14
00007a66921cf893  movaps xmm1, xmm15
00007a66921cf897  addpd xmm1, xmm2
00007a66921cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007a66921cf8a0  ptest xmm14, xmm14
00007a66921cf8a6  jnz 0x00007A66921D147A
00007a66921cf8ac  vmovaps xmm15, [rsp+0x100]
00007a66921cf8b5  vpermilpd xmm15, xmm15, 0x00
00007a66921cf8bb  vmovaps xmm2, [rsp+0xF0]
00007a66921cf8c4  vmovaps [rsp+0xF0], xmm1
00007a66921cf8cd  movaps xmm14, xmm2
00007a66921cf8d1  mulpd xmm14, xmm15
00007a66921cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007a66921cf8dc  ptest xmm1, xmm1
00007a66921cf8e1  jnz 0x00007A66921D15BB
00007a66921cf8e7  vmovaps xmm1, [rsp+0xA0]
00007a66921cf8f0  vpermilpd xmm1, xmm1, 0x00
00007a66921cf8f6  vmovaps xmm2, [rsp+0xE0]
00007a66921cf8ff  vmovaps [rsp+0xE0], xmm14
00007a66921cf908  movaps xmm15, xmm2
00007a66921cf90c  mulpd xmm15, xmm1
00007a66921cf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007a66921cf917  ptest xmm14, xmm14
00007a66921cf91d  jnz 0x00007A66921D16FE
00007a66921cf923  lea rax, [r14+0xE0]
00007a66921cf92a  movups xmm1, [r13+rax*1]
00007a66921cf930  vmovaps xmm14, [rsp+0x100]
00007a66921cf939  vpermilpd xmm14, xmm14, 0x00
00007a66921cf93f  vmovaps [rsp+0x100], xmm1
00007a66921cf948  vmovaps xmm1, [rsp+0x30]
00007a66921cf94e  vmovaps [rsp+0x30], xmm15
00007a66921cf954  movaps xmm2, xmm1
00007a66921cf957  mulpd xmm2, xmm14
00007a66921cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007a66921cf961  ptest xmm15, xmm15
00007a66921cf967  jnz 0x00007A66921D184A
00007a66921cf96d  vmovaps [rsp+0x120], xmm10
00007a66921cf976  vmovaps xmm1, [rsp+0x120]
00007a66921cf97f  por xmm10, xmm1
00007a66921cf984  movaps [r15+0x300], xmm10
00007a66921cf98c  vmovaps [rsp+0x120], xmm8
00007a66921cf995  vmovaps xmm1, [rsp+0x120]
00007a66921cf99e  por xmm8, xmm1
00007a66921cf9a3  movaps [r15+0x190], xmm8
00007a66921cf9ab  vmovaps xmm1, [rsp+0xA0]
00007a66921cf9b4  vpermilpd xmm1, xmm1, 0x00
00007a66921cf9ba  vmovaps xmm14, [rsp+0x100]
00007a66921cf9c3  vmovaps [rsp+0x100], xmm13
00007a66921cf9cc  movaps xmm15, xmm14
00007a66921cf9d0  mulpd xmm15, xmm1
00007a66921cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007a66921cf9db  ptest xmm13, xmm13
00007a66921cf9e1  jnz 0x00007A66921D198B
00007a66921cf9e7  lea rax, [r14+0x90]
00007a66921cf9ee  movups xmm1, [r13+rax*1]
00007a66921cf9f4  vmovaps [rsp+0x120], xmm4
00007a66921cf9fd  vmovaps xmm14, [rsp+0x120]
00007a66921cfa06  por xmm4, xmm14
00007a66921cfa0b  movaps [r15+0x1C0], xmm4
00007a66921cfa13  vmovaps [rsp+0x120], xmm11
00007a66921cfa1c  vmovaps xmm14, [rsp+0x120]
00007a66921cfa25  por xmm11, xmm14
00007a66921cfa2a  movaps [r15+0x200], xmm11
00007a66921cfa32  vmovaps [rsp+0x120], xmm5
00007a66921cfa3b  vmovaps xmm14, [rsp+0x120]
00007a66921cfa44  por xmm5, xmm14
00007a66921cfa49  movaps [r15+0x2D0], xmm5
00007a66921cfa51  vmovaps [rsp+0x120], xmm12
00007a66921cfa5a  vmovaps xmm14, [rsp+0x120]
00007a66921cfa63  por xmm12, xmm14
00007a66921cfa68  movaps [r15+0x2E0], xmm12
00007a66921cfa70  vmovaps xmm13, [rsp+0x110]
00007a66921cfa79  vmovaps [rsp+0x110], xmm1
00007a66921cfa82  vmovaps xmm1, [rsp+0xE0]
00007a66921cfa8b  vmovaps [rsp+0xE0], xmm15
00007a66921cfa94  movaps xmm14, xmm13
00007a66921cfa98  addpd xmm14, xmm1
00007a66921cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007a66921cfaa3  ptest xmm15, xmm15
00007a66921cfaa9  jnz 0x00007A66921D1AD8
00007a66921cfaaf  vmovaps xmm1, [rsp+0xA0]
00007a66921cfab8  vpermilpd xmm1, xmm1, 0x00
00007a66921cfabe  vmovaps xmm13, [rsp+0x110]
00007a66921cfac7  vmovaps [rsp+0x110], xmm14
00007a66921cfad0  movaps xmm15, xmm13
00007a66921cfad4  mulpd xmm15, xmm1
00007a66921cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007a66921cfadf  ptest xmm14, xmm14
00007a66921cfae5  jnz 0x00007A66921D1C1B
00007a66921cfaeb  lea rax, [r14+0x80]
00007a66921cfaf2  movups xmm1, [r13+rax*1]
00007a66921cfaf8  vmovaps xmm13, [rsp+0xC0]
00007a66921cfb01  vmovaps [rsp+0xC0], xmm1
00007a66921cfb0a  movaps xmm14, xmm13
00007a66921cfb0e  addpd xmm14, xmm2
00007a66921cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007a66921cfb19  ptest xmm1, xmm1
00007a66921cfb1e  jnz 0x00007A66921D1D68
00007a66921cfb24  vmovaps xmm13, [rsp+0x100]
00007a66921cfb2d  vmovaps xmm2, [rsp+0x30]
00007a66921cfb33  vmovaps [rsp+0x30], xmm15
00007a66921cfb39  movaps xmm1, xmm13
00007a66921cfb3d  addpd xmm1, xmm2
00007a66921cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007a66921cfb46  ptest xmm15, xmm15
00007a66921cfb4c  jnz 0x00007A66921D1EAB
00007a66921cfb52  vmovaps xmm15, [rsp+0x20]
00007a66921cfb58  vmovaps xmm13, [rsp+0x20]
00007a66921cfb5e  por xmm15, xmm13
00007a66921cfb63  movaps [r15+0x2F0], xmm15
00007a66921cfb6b  vmovaps xmm13, [rsp+0xA0]
00007a66921cfb74  vpermilpd xmm13, xmm13, 0x00
00007a66921cfb7a  vmovaps [rsp+0x20], xmm1
00007a66921cfb80  vmovaps xmm1, [rsp+0xC0]
00007a66921cfb89  vmovaps [rsp+0xA0], xmm15
00007a66921cfb92  movaps xmm2, xmm1
00007a66921cfb95  mulpd xmm2, xmm13
00007a66921cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007a66921cfb9f  ptest xmm15, xmm15
00007a66921cfba5  jnz 0x00007A66921D1FEC
00007a66921cfbab  lea rax, [r14+0xD0]
00007a66921cfbb2  movups xmm1, [r13+rax*1]
00007a66921cfbb8  vmovaps xmm13, [rsp+0xF0]
00007a66921cfbc1  vmovaps [rsp+0xC0], xmm1
00007a66921cfbca  vmovaps xmm1, [rsp+0xE0]
00007a66921cfbd3  vmovaps [rsp+0xE0], xmm14
00007a66921cfbdc  movaps xmm15, xmm13
00007a66921cfbe0  addpd xmm15, xmm1
00007a66921cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007a66921cfbeb  ptest xmm14, xmm14
00007a66921cfbf1  jnz 0x00007A66921D2137
00007a66921cfbf7  vmovaps xmm1, [rsp+0xB0]
00007a66921cfc00  vpermilpd xmm1, xmm1, 0x00
00007a66921cfc06  movaps xmm14, xmm11
00007a66921cfc0a  mulpd xmm14, xmm1
00007a66921cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007a66921cfc15  ptest xmm13, xmm13
00007a66921cfc1b  jnz 0x00007A66921D227A
00007a66921cfc21  movaps [r15+0x260], xmm14
00007a66921cfc29  vxorps xmm1, xmm1, xmm1
00007a66921cfc2d  vpbroadcastq xmm1, xmm1
00007a66921cfc32  movaps [r15+0x1B0], xmm1
00007a66921cfc3a  vmovaps xmm1, [rsp+0xB0]
00007a66921cfc43  vpermilpd xmm1, xmm1, 0x00
00007a66921cfc49  vmovaps xmm11, [rsp+0xC0]
00007a66921cfc52  vmovaps [rsp+0xC0], xmm15
00007a66921cfc5b  movaps xmm13, xmm11
00007a66921cfc5f  mulpd xmm13, xmm1
00007a66921cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007a66921cfc6a  ptest xmm15, xmm15
00007a66921cfc70  jnz 0x00007A66921D23BD
00007a66921cfc76  lea rax, [r14+0xC0]
00007a66921cfc7d  movups xmm1, [r13+rax*1]
00007a66921cfc83  vmovaps xmm11, [rsp+0x110]
00007a66921cfc8c  vmovaps [rsp+0xF0], xmm1
00007a66921cfc95  vmovaps xmm1, [rsp+0x30]
00007a66921cfc9b  vmovaps [rsp+0x30], xmm14
00007a66921cfca1  movaps xmm15, xmm11
00007a66921cfca5  addpd xmm15, xmm1
00007a66921cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007a66921cfcb0  ptest xmm14, xmm14
00007a66921cfcb6  jnz 0x00007A66921D250A
00007a66921cfcbc  vmovaps [rsp+0x100], xmm9
00007a66921cfcc5  vmovaps xmm1, [rsp+0x100]
00007a66921cfcce  por xmm9, xmm1
00007a66921cfcd3  movaps [r15+0x270], xmm9
00007a66921cfcdb  vmovaps [rsp+0x100], xmm6
00007a66921cfce4  vmovaps xmm1, [rsp+0x100]
00007a66921cfced  por xmm6, xmm1
00007a66921cfcf1  movaps [r15+0x1A0], xmm6
00007a66921cfcf9  vmovaps xmm14, [rsp+0xB0]
00007a66921cfd02  vpermilpd xmm14, xmm14, 0x00
00007a66921cfd08  vmovaps xmm6, [rsp+0xF0]
00007a66921cfd11  vmovaps [rsp+0xF0], xmm1
00007a66921cfd1a  movaps xmm11, xmm6
00007a66921cfd1e  mulpd xmm11, xmm14
00007a66921cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007a66921cfd29  ptest xmm1, xmm1
00007a66921cfd2e  jnz 0x00007A66921D264D
00007a66921cfd34  lea rax, [r14+0x20]
00007a66921cfd38  movups xmm1, [r13+rax*1]
00007a66921cfd3e  movaps [r15+0x110], xmm1
00007a66921cfd46  vmovaps xmm6, [rsp+0xE0]
00007a66921cfd4f  vmovaps [rsp+0xE0], xmm1
00007a66921cfd58  movaps xmm14, xmm6
00007a66921cfd5c  addpd xmm14, xmm2
00007a66921cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007a66921cfd67  ptest xmm1, xmm1
00007a66921cfd6c  jnz 0x00007A66921D279A
00007a66921cfd72  vmovaps xmm1, [rsp+0xB0]
00007a66921cfd7b  vpermilpd xmm1, xmm1, 0x00
00007a66921cfd81  movaps xmm6, xmm5
00007a66921cfd84  mulpd xmm6, xmm1
00007a66921cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007a66921cfd8d  ptest xmm2, xmm2
00007a66921cfd92  jnz 0x00007A66921D28DC
00007a66921cfd98  vmovaps xmm5, [rsp+0x20]
00007a66921cfd9e  movaps xmm1, xmm5
00007a66921cfda1  addpd xmm1, xmm13
00007a66921cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007a66921cfdab  ptest xmm2, xmm2
00007a66921cfdb0  jnz 0x00007A66921D2A1C
00007a66921cfdb6  vmovaps xmm13, [rsp+0x80]
00007a66921cfdbf  vpermilpd xmm13, xmm13, 0x00
00007a66921cfdc5  vmovaps xmm2, [rsp+0xE0]
00007a66921cfdce  vmovaps [rsp+0x20], xmm1
00007a66921cfdd4  movaps xmm5, xmm2
00007a66921cfdd7  mulpd xmm5, xmm13
00007a66921cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007a66921cfde1  ptest xmm1, xmm1
00007a66921cfde6  jnz 0x00007A66921D2B5D
00007a66921cfdec  vmovaps xmm1, [rsp+0x80]
00007a66921cfdf5  vpermilpd xmm1, xmm1, 0x00
00007a66921cfdfb  movaps xmm13, xmm10
00007a66921cfdff  mulpd xmm13, xmm1
00007a66921cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007a66921cfe0a  ptest xmm2, xmm2
00007a66921cfe0f  jnz 0x00007A66921D2C9E
00007a66921cfe15  vmovaps xmm10, [rsp+0x30]
00007a66921cfe1b  movaps xmm1, xmm15
00007a66921cfe1f  addpd xmm1, xmm10
00007a66921cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007a66921cfe29  ptest xmm2, xmm2
00007a66921cfe2e  jnz 0x00007A66921D2DE1
00007a66921cfe34  vmovaps xmm10, [rsp+0xC0]
00007a66921cfe3d  movaps xmm15, xmm10
00007a66921cfe41  addpd xmm15, xmm11
00007a66921cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007a66921cfe4c  ptest xmm2, xmm2
00007a66921cfe51  jnz 0x00007A66921D2F23
00007a66921cfe57  vmovaps xmm11, [rsp+0x80]
00007a66921cfe60  vpermilpd xmm11, xmm11, 0x00
00007a66921cfe66  movaps xmm10, xmm12
00007a66921cfe6a  mulpd xmm10, xmm11
00007a66921cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007a66921cfe75  ptest xmm2, xmm2
00007a66921cfe7a  jnz 0x00007A66921D3067
00007a66921cfe80  vmovaps xmm12, [rsp+0x80]
00007a66921cfe89  vpermilpd xmm12, xmm12, 0x00
00007a66921cfe8f  vmovaps xmm2, [rsp+0xA0]
00007a66921cfe98  vmovaps [rsp+0x30], xmm1
00007a66921cfe9e  movaps xmm11, xmm2
00007a66921cfea2  mulpd xmm11, xmm12
00007a66921cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007a66921cfead  ptest xmm1, xmm1
00007a66921cfeb2  jnz 0x00007A66921D31AB
00007a66921cfeb8  movaps xmm1, xmm14
00007a66921cfebc  addpd xmm1, xmm6
00007a66921cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007a66921cfec5  ptest xmm12, xmm12
00007a66921cfecb  jnz 0x00007A66921D32EE
00007a66921cfed1  vmovaps xmm12, [rsp+0x20]
00007a66921cfed7  movaps xmm14, xmm12
00007a66921cfedb  addpd xmm14, xmm5
00007a66921cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007a66921cfee6  ptest xmm6, xmm6
00007a66921cfeeb  jnz 0x00007A66921D342F
00007a66921cfef1  vmovaps xmm12, [rsp+0x90]
00007a66921cfefa  vpermilpd xmm12, xmm12, 0x00
00007a66921cff00  movaps xmm6, xmm9
00007a66921cff04  mulpd xmm6, xmm12
00007a66921cff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007a66921cff0e  ptest xmm5, xmm5
00007a66921cff13  jnz 0x00007A66921D3572
00007a66921cff19  movaps xmm12, xmm15
00007a66921cff1d  addpd xmm12, xmm13
00007a66921cff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007a66921cff28  ptest xmm9, xmm9
00007a66921cff2e  jnz 0x00007A66921D36B4
00007a66921cff34  vmovaps xmm13, [rsp+0x30]
00007a66921cff3a  movaps xmm15, xmm13
00007a66921cff3e  addpd xmm15, xmm10
00007a66921cff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007a66921cff49  ptest xmm9, xmm9
00007a66921cff4f  jnz 0x00007A66921D37F8
00007a66921cff55  vmovaps xmm13, [rsp+0xD0]
00007a66921cff5e  vmovaps xmm10, [rsp+0xD0]
00007a66921cff67  por xmm13, xmm10
00007a66921cff6c  movaps [r15+0x250], xmm13
00007a66921cff74  vmovaps [rsp+0x20], xmm7
00007a66921cff7a  vmovaps xmm13, [rsp+0x20]
00007a66921cff80  por xmm7, xmm13
00007a66921cff85  movaps [r15+0x2A0], xmm7
00007a66921cff8d  vmovaps [rsp+0x20], xmm3
00007a66921cff93  vmovaps xmm13, [rsp+0x20]
00007a66921cff99  por xmm3, xmm13
00007a66921cff9e  movaps [r15+0x1D0], xmm3
00007a66921cffa6  lea rax, [r14+0x40]
00007a66921cffaa  movups xmm13, [r13+rax*1]
00007a66921cffb0  movaps [r15+0x2C0], xmm13
00007a66921cffb8  vmovaps xmm10, [rsp+0x90]
00007a66921cffc1  vpermilpd xmm10, xmm10, 0x00
00007a66921cffc7  movaps xmm9, xmm8
00007a66921cffcb  mulpd xmm9, xmm10
00007a66921cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007a66921cffd6  ptest xmm5, xmm5
00007a66921cffdb  jnz 0x00007A66921D3946
00007a66921cffe1  movaps xmm10, xmm1
00007a66921cffe5  addpd xmm10, xmm11
00007a66921cffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007a66921cfff0  ptest xmm8, xmm8
00007a66921cfff6  jnz 0x00007A66921D3A8A
00007a66921cfffc  movaps xmm1, xmm14
00007a66921d0000  addpd xmm1, xmm6
00007a66921d0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007a66921d0009  ptest xmm11, xmm11
00007a66921d000f  jnz 0x00007A66921D3BCD
00007a66921d0015  vmovaps xmm14, [rsp+0x90]
00007a66921d001e  vpermilpd xmm14, xmm14, 0x00
00007a66921d0024  movaps xmm11, xmm13
00007a66921d0028  mulpd xmm11, xmm14
00007a66921d002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007a66921d0033  ptest xmm8, xmm8
00007a66921d0039  jnz 0x00007A66921D3D0E
00007a66921d003f  vmovaps xmm14, [rsp+0x90]
00007a66921d0048  vpermilpd xmm14, xmm14, 0x00
00007a66921d004e  vmovaps xmm8, [rsp+0x10]
00007a66921d0054  movaps xmm13, xmm8
00007a66921d0058  mulpd xmm13, xmm14
00007a66921d005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007a66921d0063  ptest xmm6, xmm6
00007a66921d0068  jnz 0x00007A66921D3E52
00007a66921d006e  vmovaps xmm14, [rsp+0x60]
00007a66921d0074  vpermilpd xmm14, xmm14, 0x00
00007a66921d007a  movaps xmm8, xmm7
00007a66921d007e  mulpd xmm8, xmm14
00007a66921d0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007a66921d0089  ptest xmm6, xmm6
00007a66921d008e  jnz 0x00007A66921D3F96
00007a66921d0094  movaps xmm14, xmm12
00007a66921d0098  addpd xmm14, xmm9
00007a66921d009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007a66921d00a3  ptest xmm7, xmm7
00007a66921d00a8  jnz 0x00007A66921D40D9
00007a66921d00ae  vmovaps xmm12, [rsp+0x60]
00007a66921d00b4  vpermilpd xmm12, xmm12, 0x00
00007a66921d00ba  vmovaps xmm7, [rsp+0xF0]
00007a66921d00c3  movaps xmm9, xmm7
00007a66921d00c7  mulpd xmm9, xmm12
00007a66921d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007a66921d00d2  ptest xmm6, xmm6
00007a66921d00d7  jnz 0x00007A66921D421D
00007a66921d00dd  movaps xmm12, xmm15
00007a66921d00e1  addpd xmm12, xmm11
00007a66921d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007a66921d00ec  ptest xmm7, xmm7
00007a66921d00f1  jnz 0x00007A66921D4360
00007a66921d00f7  vmovaps xmm15, [rsp+0x60]
00007a66921d00fd  vpermilpd xmm15, xmm15, 0x00
00007a66921d0103  vmovaps xmm7, [rsp+0x40]
00007a66921d0109  movaps xmm11, xmm7
00007a66921d010d  mulpd xmm11, xmm15
00007a66921d0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007a66921d0118  ptest xmm6, xmm6
00007a66921d011d  jnz 0x00007A66921D44A4
00007a66921d0123  movaps xmm15, xmm10
00007a66921d0127  addpd xmm15, xmm13
00007a66921d012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007a66921d0132  ptest xmm7, xmm7
00007a66921d0137  jnz 0x00007A66921D45E7
00007a66921d013d  vmovaps xmm13, [rsp+0x60]
00007a66921d0143  vpermilpd xmm13, xmm13, 0x00
00007a66921d0149  vmovaps xmm7, [rsp+0x50]
00007a66921d014f  movaps xmm10, xmm7
00007a66921d0153  mulpd xmm10, xmm13
00007a66921d0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007a66921d015e  ptest xmm6, xmm6
00007a66921d0163  jnz 0x00007A66921D472B
00007a66921d0169  movaps xmm13, xmm1
00007a66921d016d  addpd xmm13, xmm8
00007a66921d0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007a66921d0178  ptest xmm7, xmm7
00007a66921d017d  jnz 0x00007A66921D486E
00007a66921d0183  lea rax, [r14+0x70]
00007a66921d0187  movups xmm1, [r13+rax*1]
00007a66921d018d  movaps [r15+0x240], xmm1
00007a66921d0195  movaps xmm8, xmm14
00007a66921d0199  addpd xmm8, xmm9
00007a66921d019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007a66921d01a4  ptest xmm7, xmm7
00007a66921d01a9  jnz 0x00007A66921D49BB
00007a66921d01af  movaps [r15+0x170], xmm8
00007a66921d01b7  vmovaps xmm14, [rsp+0x70]
00007a66921d01bd  vpermilpd xmm14, xmm14, 0x00
00007a66921d01c3  movaps xmm9, xmm1
00007a66921d01c7  mulpd xmm9, xmm14
00007a66921d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007a66921d01d2  ptest xmm7, xmm7
00007a66921d01d7  jnz 0x00007A66921D4AFF
00007a66921d01dd  vmovaps xmm1, [rsp+0x70]
00007a66921d01e3  vpermilpd xmm1, xmm1, 0x00
00007a66921d01e9  movaps xmm14, xmm4
00007a66921d01ed  mulpd xmm14, xmm1
00007a66921d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007a66921d01f8  ptest xmm7, xmm7
00007a66921d01fd  jnz 0x00007A66921D4C42
00007a66921d0203  movaps [r15+0x180], xmm14
00007a66921d020b  movaps xmm1, xmm12
00007a66921d020f  addpd xmm1, xmm11
00007a66921d0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007a66921d0219  ptest xmm7, xmm7
00007a66921d021e  jnz 0x00007A66921D4D84
00007a66921d0224  movaps [r15+0x210], xmm1
00007a66921d022c  movups xmm12, [r13+r14*1]
00007a66921d0232  lea rax, [r14+0x10]
00007a66921d0236  movups xmm11, [r13+rax*1]
00007a66921d023c  movaps [r15+0x230], xmm11
00007a66921d0244  movaps xmm7, xmm15
00007a66921d0248  addpd xmm7, xmm10
00007a66921d024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007a66921d0252  ptest xmm6, xmm6
00007a66921d0257  jnz 0x00007A66921D4EDA
00007a66921d025d  movaps [r15+0x130], xmm7
00007a66921d0265  vmovaps xmm15, [rsp+0x70]
00007a66921d026b  vpermilpd xmm15, xmm15, 0x00
00007a66921d0271  movaps xmm10, xmm11
00007a66921d0275  mulpd xmm10, xmm15
00007a66921d027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007a66921d0280  ptest xmm6, xmm6
00007a66921d0285  jnz 0x00007A66921D501C
00007a66921d028b  movaps [r15+0x220], xmm10
00007a66921d0293  vmovaps xmm15, [rsp+0x70]
00007a66921d0299  vpermilpd xmm15, xmm15, 0x00
00007a66921d029f  movaps xmm11, xmm12
00007a66921d02a3  mulpd xmm11, xmm15
00007a66921d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007a66921d02ae  ptest xmm6, xmm6
00007a66921d02b3  jnz 0x00007A66921D5160
00007a66921d02b9  movaps xmm15, xmm13
00007a66921d02bd  addpd xmm15, xmm9
00007a66921d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007a66921d02c8  ptest xmm12, xmm12
00007a66921d02ce  jnz 0x00007A66921D52A4
00007a66921d02d4  movaps [r15+0x140], xmm15
00007a66921d02dc  movaps xmm13, xmm8
00007a66921d02e0  addpd xmm13, xmm14
00007a66921d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007a66921d02eb  ptest xmm12, xmm12
00007a66921d02f1  jnz 0x00007A66921D53E8
00007a66921d02f7  movaps [r15+0x150], xmm13
00007a66921d02ff  movaps xmm14, xmm1
00007a66921d0303  addpd xmm14, xmm10
00007a66921d0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007a66921d030e  ptest xmm12, xmm12
00007a66921d0314  jnz 0x00007A66921D552C
00007a66921d031a  movaps [r15+0x160], xmm14
00007a66921d0322  movaps xmm1, xmm7
00007a66921d0325  addpd xmm1, xmm11
00007a66921d032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007a66921d032f  ptest xmm12, xmm12
00007a66921d0335  jnz 0x00007A66921D566F
00007a66921d033b  movaps [r15+0x120], xmm1
00007a66921d0343  mov eax, 0x430920
00007a66921d0348  movups [r13+rax*1], xmm15
00007a66921d034e  mov eax, 0x430930
00007a66921d0353  movups [r13+rax*1], xmm13
00007a66921d0359  mov eax, 0x430940
00007a66921d035e  movups [r13+rax*1], xmm14
00007a66921d0364  mov eax, 0x430950
00007a66921d0369  movups [r13+rax*1], xmm1
00007a66921d036f  mov eax, [r15+0x108]
00007a66921d0376  sahf
00007a66921d0377  jnz 0x00007A66921D03A9
00007a66921d0379  cmp dword ptr [r15+0x318], 0x00
00007a66921d0381  jz 0x00007A66921DB900
00007a66921d0387  nop [rax+rax*1], ax
00007a66921d0390  nop [rax+rax*1], eax
00007a66921d0398  mov eax, 0x410444
00007a66921d039d  mov [r15+0x100], rax
00007a66921d03a4  jmp 0x00007A6691FFE110
00007a66921d03a9  cmp dword ptr [r15+0x318], 0x00
00007a66921d03b1  jz 0x00007A66921D57E0
00007a66921d03b7  nop [rax+rax*1], ax
00007a66921d03c0  nop [rax+rax*1], eax
00007a66921d03c8  mov eax, 0x410278
00007a66921d03cd  mov [r15+0x100], rax
00007a66921d03d4  jmp 0x00007A6691FFE110
00007a66921d03d9  int3
00007a66921d03da  call 0x00007A66920B52F0
00007a66921d03df  jmp 0x00007A66921CF016
00007a66921d03e4  call 0x00007A66920C4620
00007a66921d03e9  jmp 0x00007A66921CF023
00007a66921d03ee  call 0x00007A66920C33A0
00007a66921d03f3  jmp 0x00007A66921CF035
00007a66921d03f8  call 0x00007A66920C2120
00007a66921d03fd  jmp 0x00007A66921CF03F
00007a66921d0402  call 0x00007A66920C0860
00007a66921d0407  jmp 0x00007A66921CF067
00007a66921d040c  call 0x00007A66920BF5F0
00007a66921d0411  jmp 0x00007A66921CF073
00007a66921d0416  call 0x00007A66920C0860
00007a66921d041b  jmp 0x00007A66921CF0A5
00007a66921d0420  call 0x00007A66920BF5F0
00007a66921d0425  jmp 0x00007A66921CF0B1
00007a66921d042a  call 0x00007A66920C4740
00007a66921d042f  jmp 0x00007A66921CF0BE
00007a66921d0434  call 0x00007A66920B5400
00007a66921d0439  jmp 0x00007A66921CF0CB
00007a66921d043e  call 0x00007A66920B52F0
00007a66921d0443  jmp 0x00007A66921CF0D8
00007a66921d0448  call 0x00007A66920C4620
00007a66921d044d  jmp 0x00007A66921CF0E5
00007a66921d0452  call 0x00007A66920C0860
00007a66921d0457  jmp 0x00007A66921CF10D
00007a66921d045c  call 0x00007A66920BF5F0
00007a66921d0461  jmp 0x00007A66921CF119
00007a66921d0466  call 0x00007A6692009D70
00007a66921d046b  jmp 0x00007A66921CF11F
00007a66921d0470  call 0x00007A66920BE9C0
00007a66921d0475  jmp 0x00007A66921CF129
00007a66921d047a  call 0x00007A66920C0860
00007a66921d047f  jmp 0x00007A66921CF151
00007a66921d0484  call 0x00007A66920BF5F0
00007a66921d0489  jmp 0x00007A66921CF15D
00007a66921d048e  call 0x00007A66920BD750
00007a66921d0493  jmp 0x00007A66921CF16A
00007a66921d0498  call 0x00007A66920BC4E0
00007a66921d049d  jmp 0x00007A66921CF177
00007a66921d04a2  call 0x00007A66920C4740
00007a66921d04a7  jmp 0x00007A66921CF184
00007a66921d04ac  call 0x00007A66920B5400
00007a66921d04b1  jmp 0x00007A66921CF191
00007a66921d04b6  call 0x00007A66920B52F0
00007a66921d04bb  jmp 0x00007A66921CF19E
00007a66921d04c0  call 0x00007A66920C4620
00007a66921d04c5  jmp 0x00007A66921CF1AB
00007a66921d04ca  call 0x00007A66920C0860
00007a66921d04cf  jmp 0x00007A66921CF1BE
00007a66921d04d4  call 0x00007A66920BB270
00007a66921d04d9  jmp 0x00007A66921CF1CB
00007a66921d04de  call 0x00007A66920BA000
00007a66921d04e3  jmp 0x00007A66921CF1D8
00007a66921d04e8  call 0x00007A66920B8D90
00007a66921d04ed  jmp 0x00007A66921CF1E5
00007a66921d04f2  call 0x00007A66920B8A20
00007a66921d04f7  jmp 0x00007A66921CF1F2
00007a66921d04fc  call 0x00007A66920B5400
00007a66921d0501  jmp 0x00007A66921CF1FC
00007a66921d0506  call 0x00007A66920C2240
00007a66921d050b  jmp 0x00007A66921CF206
00007a66921d0510  call 0x00007A66920B52F0
00007a66921d0515  jmp 0x00007A66921CF210
00007a66921d051a  call 0x00007A66920C2120
00007a66921d051f  jmp 0x00007A66921CF21A
00007a66921d0524  call 0x00007A66920B77B0
00007a66921d0529  jmp 0x00007A66921CF224
00007a66921d052e  call 0x00007A66920B6550
00007a66921d0533  jmp 0x00007A66921CF22E
00007a66921d0538  call 0x00007A66920BFD50
00007a66921d053d  jmp 0x00007A66921CF240
00007a66921d0542  call 0x00007A66920B8EA0
00007a66921d0547  jmp 0x00007A66921CF24A
00007a66921d054c  call 0x00007A66920BFC30
00007a66921d0551  jmp 0x00007A66921CF257
00007a66921d0556  call 0x00007A66920B8D90
00007a66921d055b  jmp 0x00007A66921CF264
00007a66921d0560  call 0x00007A66920C2240
00007a66921d0565  jmp 0x00007A66921CF271
00007a66921d056a  call 0x00007A66920B5400
00007a66921d056f  jmp 0x00007A66921CF27E
00007a66921d0574  call 0x00007A66920B52F0
00007a66921d0579  jmp 0x00007A66921CF28B
00007a66921d057e  call 0x00007A66920C2120
00007a66921d0583  jmp 0x00007A66921CF298
00007a66921d0588  call 0x00007A66920B52F0
00007a66921d058d  jmp 0x00007A66921CF2AB
00007a66921d0592  call 0x00007A66920B52F0
00007a66921d0597  jmp 0x00007A66921CF2BE
00007a66921d059c  call 0x00007A66920B52F0
00007a66921d05a1  jmp 0x00007A66921CF2D1
00007a66921d05a6  call 0x00007A66920B52F0
00007a66921d05ab  jmp 0x00007A66921CF2E4
00007a66921d05b0  call 0x00007A66920C2240
00007a66921d05b5  jmp 0x00007A66921CF2F9
00007a66921d05ba  call 0x00007A66920C2240
00007a66921d05bf  jmp 0x00007A66921CF30C
00007a66921d05c4  call 0x00007A66920C2120
00007a66921d05c9  jmp 0x00007A66921CF319
00007a66921d05ce  call 0x00007A66920B52F0
00007a66921d05d3  jmp 0x00007A66921CF32C
00007a66921d05d8  call 0x00007A66920B52F0
00007a66921d05dd  jmp 0x00007A66921CF34F
00007a66921d05e2  call 0x00007A66920B52F0
00007a66921d05e7  jmp 0x00007A66921CF362
00007a66921d05ec  call 0x00007A6691FFF540
00007a66921d05f1  jmp 0x00007A66921CF380
00007a66921d05f6  call 0x00007A6692008C20
00007a66921d05fb  jmp 0x00007A66921CF38A
00007a66921d0600  call 0x00007A66920D6600
00007a66921d0605  jmp 0x00007A66921CF396
00007a66921d060a  call 0x00007A6691FFF540
00007a66921d060f  jmp 0x00007A66921CF3A6
00007a66921d0614  call 0x00007A66920C0370
00007a66921d0619  jmp 0x00007A66921CF3D4
00007a66921d061e  call 0x00007A66920BF100
00007a66921d0623  jmp 0x00007A66921CF3DD
00007a66921d0628  call 0x00007A66920C0370
00007a66921d062d  jmp 0x00007A66921CF43B
00007a66921d0632  call 0x00007A66920BF100
00007a66921d0637  jmp 0x00007A66921CF444
00007a66921d063c  call 0x00007A66920C0370
00007a66921d0641  jmp 0x00007A66921CF48B
00007a66921d0646  call 0x00007A66920BF100
00007a66921d064b  jmp 0x00007A66921CF494
00007a66921d0650  call 0x00007A669200B720
00007a66921d0655  jmp 0x00007A66921CF4D7
00007a66921d065a  call 0x00007A66920B47C0
00007a66921d065f  jmp 0x00007A66921CF4EA
00007a66921d0664  call 0x00007A6692008B00
00007a66921d0669  jmp 0x00007A66921CF501
00007a66921d066e  call 0x00007A6691FFF430
00007a66921d0673  jmp 0x00007A66921CF514
00007a66921d0678  call 0x00007A6691FFF430
00007a66921d067d  jmp 0x00007A66921CF527
00007a66921d0682  sub rsp, 0x08
00007a66921d0686  push rax
00007a66921d0687  push rcx
00007a66921d0688  push rdx
00007a66921d0689  push rdi
00007a66921d068a  push rsi
00007a66921d068b  push r8
00007a66921d068d  push r9
00007a66921d068f  push r10
00007a66921d0691  push r11
00007a66921d0693  sub rsp, 0xF0
00007a66921d069a  vmovaps [rsp], xmm0
00007a66921d069f  vmovaps [rsp+0x10], xmm2
00007a66921d06a5  vmovaps [rsp+0x20], xmm3
00007a66921d06ab  vmovaps [rsp+0x30], xmm4
00007a66921d06b1  vmovaps [rsp+0x40], xmm5
00007a66921d06b7  vmovaps [rsp+0x50], xmm6
00007a66921d06bd  vmovaps [rsp+0x60], xmm7
00007a66921d06c3  vmovaps [rsp+0x70], xmm8
00007a66921d06c9  vmovaps [rsp+0x80], xmm9
00007a66921d06d2  vmovaps [rsp+0x90], xmm10
00007a66921d06db  vmovaps [rsp+0xA0], xmm11
00007a66921d06e4  vmovaps [rsp+0xB0], xmm12
00007a66921d06ed  vmovaps [rsp+0xC0], xmm13
00007a66921d06f6  vmovaps [rsp+0xD0], xmm14
00007a66921d06ff  vmovaps [rsp+0xE0], xmm15
00007a66921d0708  sub rsp, 0x30
00007a66921d070c  movaps [rsp], xmm1
00007a66921d0710  movaps [rsp+0x10], xmm15
00007a66921d0716  movaps [rsp+0x20], xmm14
00007a66921d071c  lea rdi, [rsp]
00007a66921d0720  mov esi, 0x00
00007a66921d0725  mov rax, 0x635346DC7530
00007a66921d072f  call rax
00007a66921d0731  movaps xmm1, [rsp]
00007a66921d0735  add rsp, 0x30
00007a66921d0739  vmovaps xmm0, [rsp]
00007a66921d073e  vmovaps xmm2, [rsp+0x10]
00007a66921d0744  vmovaps xmm3, [rsp+0x20]
00007a66921d074a  vmovaps xmm4, [rsp+0x30]
00007a66921d0750  vmovaps xmm5, [rsp+0x40]
00007a66921d0756  vmovaps xmm6, [rsp+0x50]
00007a66921d075c  vmovaps xmm7, [rsp+0x60]
00007a66921d0762  vmovaps xmm8, [rsp+0x70]
00007a66921d0768  vmovaps xmm9, [rsp+0x80]
00007a66921d0771  vmovaps xmm10, [rsp+0x90]
00007a66921d077a  vmovaps xmm11, [rsp+0xA0]
00007a66921d0783  vmovaps xmm12, [rsp+0xB0]
00007a66921d078c  vmovaps xmm13, [rsp+0xC0]
00007a66921d0795  vmovaps xmm14, [rsp+0xD0]
00007a66921d079e  vmovaps xmm15, [rsp+0xE0]
00007a66921d07a7  add rsp, 0xF0
00007a66921d07ae  pop r11
00007a66921d07b0  pop r10
00007a66921d07b2  pop r9
00007a66921d07b4  pop r8
00007a66921d07b6  pop rsi
00007a66921d07b7  pop rdi
00007a66921d07b8  pop rdx
00007a66921d07b9  pop rcx
00007a66921d07ba  pop rax
00007a66921d07bb  add rsp, 0x08
00007a66921d07bf  jmp 0x00007A66921CF581
00007a66921d07c4  sub rsp, 0x08
00007a66921d07c8  push rax
00007a66921d07c9  push rcx
00007a66921d07ca  push rdx
00007a66921d07cb  push rdi
00007a66921d07cc  push rsi
00007a66921d07cd  push r8
00007a66921d07cf  push r9
00007a66921d07d1  push r10
00007a66921d07d3  push r11
00007a66921d07d5  sub rsp, 0xF0
00007a66921d07dc  vmovaps [rsp], xmm0
00007a66921d07e1  vmovaps [rsp+0x10], xmm1
00007a66921d07e7  vmovaps [rsp+0x20], xmm2
00007a66921d07ed  vmovaps [rsp+0x30], xmm3
00007a66921d07f3  vmovaps [rsp+0x40], xmm4
00007a66921d07f9  vmovaps [rsp+0x50], xmm5
00007a66921d07ff  vmovaps [rsp+0x60], xmm6
00007a66921d0805  vmovaps [rsp+0x70], xmm7
00007a66921d080b  vmovaps [rsp+0x80], xmm8
00007a66921d0814  vmovaps [rsp+0x90], xmm9
00007a66921d081d  vmovaps [rsp+0xA0], xmm10
00007a66921d0826  vmovaps [rsp+0xB0], xmm11
00007a66921d082f  vmovaps [rsp+0xC0], xmm12
00007a66921d0838  vmovaps [rsp+0xD0], xmm14
00007a66921d0841  vmovaps [rsp+0xE0], xmm15
00007a66921d084a  sub rsp, 0x30
00007a66921d084e  movaps [rsp], xmm13
00007a66921d0853  movaps [rsp+0x10], xmm1
00007a66921d0858  movaps [rsp+0x20], xmm14
00007a66921d085e  lea rdi, [rsp]
00007a66921d0862  mov esi, 0x00
00007a66921d0867  mov rax, 0x635346DC7530
00007a66921d0871  call rax
00007a66921d0873  movaps xmm13, [rsp]
00007a66921d0878  add rsp, 0x30
00007a66921d087c  vmovaps xmm0, [rsp]
00007a66921d0881  vmovaps xmm1, [rsp+0x10]
00007a66921d0887  vmovaps xmm2, [rsp+0x20]
00007a66921d088d  vmovaps xmm3, [rsp+0x30]
00007a66921d0893  vmovaps xmm4, [rsp+0x40]
00007a66921d0899  vmovaps xmm5, [rsp+0x50]
00007a66921d089f  vmovaps xmm6, [rsp+0x60]
00007a66921d08a5  vmovaps xmm7, [rsp+0x70]
00007a66921d08ab  vmovaps xmm8, [rsp+0x80]
00007a66921d08b4  vmovaps xmm9, [rsp+0x90]
00007a66921d08bd  vmovaps xmm10, [rsp+0xA0]
00007a66921d08c6  vmovaps xmm11, [rsp+0xB0]
00007a66921d08cf  vmovaps xmm12, [rsp+0xC0]
00007a66921d08d8  vmovaps xmm14, [rsp+0xD0]
00007a66921d08e1  vmovaps xmm15, [rsp+0xE0]
00007a66921d08ea  add rsp, 0xF0
00007a66921d08f1  pop r11
00007a66921d08f3  pop r10
00007a66921d08f5  pop r9
00007a66921d08f7  pop r8
00007a66921d08f9  pop rsi
00007a66921d08fa  pop rdi
00007a66921d08fb  pop rdx
00007a66921d08fc  pop rcx
00007a66921d08fd  pop rax
00007a66921d08fe  add rsp, 0x08
00007a66921d0902  jmp 0x00007A66921CF5CF
00007a66921d0907  sub rsp, 0x08
00007a66921d090b  push rax
00007a66921d090c  push rcx
00007a66921d090d  push rdx
00007a66921d090e  push rdi
00007a66921d090f  push rsi
00007a66921d0910  push r8
00007a66921d0912  push r9
00007a66921d0914  push r10
00007a66921d0916  push r11
00007a66921d0918  sub rsp, 0xF0
00007a66921d091f  vmovaps [rsp], xmm0
00007a66921d0924  vmovaps [rsp+0x10], xmm1
00007a66921d092a  vmovaps [rsp+0x20], xmm2
00007a66921d0930  vmovaps [rsp+0x30], xmm3
00007a66921d0936  vmovaps [rsp+0x40], xmm4
00007a66921d093c  vmovaps [rsp+0x50], xmm5
00007a66921d0942  vmovaps [rsp+0x60], xmm6
00007a66921d0948  vmovaps [rsp+0x70], xmm7
00007a66921d094e  vmovaps [rsp+0x80], xmm8
00007a66921d0957  vmovaps [rsp+0x90], xmm9
00007a66921d0960  vmovaps [rsp+0xA0], xmm10
00007a66921d0969  vmovaps [rsp+0xB0], xmm11
00007a66921d0972  vmovaps [rsp+0xC0], xmm12
00007a66921d097b  vmovaps [rsp+0xD0], xmm13
00007a66921d0984  vmovaps [rsp+0xE0], xmm14
00007a66921d098d  sub rsp, 0x30
00007a66921d0991  movaps [rsp], xmm15
00007a66921d0996  movaps [rsp+0x10], xmm14
00007a66921d099c  movaps [rsp+0x20], xmm1
00007a66921d09a1  lea rdi, [rsp]
00007a66921d09a5  mov esi, 0x00
00007a66921d09aa  mov rax, 0x635346DC7530
00007a66921d09b4  call rax
00007a66921d09b6  movaps xmm15, [rsp]
00007a66921d09bb  add rsp, 0x30
00007a66921d09bf  vmovaps xmm0, [rsp]
00007a66921d09c4  vmovaps xmm1, [rsp+0x10]
00007a66921d09ca  vmovaps xmm2, [rsp+0x20]
00007a66921d09d0  vmovaps xmm3, [rsp+0x30]
00007a66921d09d6  vmovaps xmm4, [rsp+0x40]
00007a66921d09dc  vmovaps xmm5, [rsp+0x50]
00007a66921d09e2  vmovaps xmm6, [rsp+0x60]
00007a66921d09e8  vmovaps xmm7, [rsp+0x70]
00007a66921d09ee  vmovaps xmm8, [rsp+0x80]
00007a66921d09f7  vmovaps xmm9, [rsp+0x90]
00007a66921d0a00  vmovaps xmm10, [rsp+0xA0]
00007a66921d0a09  vmovaps xmm11, [rsp+0xB0]
00007a66921d0a12  vmovaps xmm12, [rsp+0xC0]
00007a66921d0a1b  vmovaps xmm13, [rsp+0xD0]
00007a66921d0a24  vmovaps xmm14, [rsp+0xE0]
00007a66921d0a2d  add rsp, 0xF0
00007a66921d0a34  pop r11
00007a66921d0a36  pop r10
00007a66921d0a38  pop r9
00007a66921d0a3a  pop r8
00007a66921d0a3c  pop rsi
00007a66921d0a3d  pop rdi
00007a66921d0a3e  pop rdx
00007a66921d0a3f  pop rcx
00007a66921d0a40  pop rax
00007a66921d0a41  add rsp, 0x08
00007a66921d0a45  jmp 0x00007A66921CF617
00007a66921d0a4a  sub rsp, 0x08
00007a66921d0a4e  push rax
00007a66921d0a4f  push rcx
00007a66921d0a50  push rdx
00007a66921d0a51  push rdi
00007a66921d0a52  push rsi
00007a66921d0a53  push r8
00007a66921d0a55  push r9
00007a66921d0a57  push r10
00007a66921d0a59  push r11
00007a66921d0a5b  sub rsp, 0xF0
00007a66921d0a62  vmovaps [rsp], xmm0
00007a66921d0a67  vmovaps [rsp+0x10], xmm2
00007a66921d0a6d  vmovaps [rsp+0x20], xmm3
00007a66921d0a73  vmovaps [rsp+0x30], xmm4
00007a66921d0a79  vmovaps [rsp+0x40], xmm5
00007a66921d0a7f  vmovaps [rsp+0x50], xmm6
00007a66921d0a85  vmovaps [rsp+0x60], xmm7
00007a66921d0a8b  vmovaps [rsp+0x70], xmm8
00007a66921d0a91  vmovaps [rsp+0x80], xmm9
00007a66921d0a9a  vmovaps [rsp+0x90], xmm10
00007a66921d0aa3  vmovaps [rsp+0xA0], xmm11
00007a66921d0aac  vmovaps [rsp+0xB0], xmm12
00007a66921d0ab5  vmovaps [rsp+0xC0], xmm13
00007a66921d0abe  vmovaps [rsp+0xD0], xmm14
00007a66921d0ac7  vmovaps [rsp+0xE0], xmm15
00007a66921d0ad0  sub rsp, 0x30
00007a66921d0ad4  movaps [rsp], xmm1
00007a66921d0ad8  movaps [rsp+0x10], xmm14
00007a66921d0ade  movaps [rsp+0x20], xmm10
00007a66921d0ae4  lea rdi, [rsp]
00007a66921d0ae8  mov esi, 0x00
00007a66921d0aed  mov rax, 0x635346DC7530
00007a66921d0af7  call rax
00007a66921d0af9  movaps xmm1, [rsp]
00007a66921d0afd  add rsp, 0x30
00007a66921d0b01  vmovaps xmm0, [rsp]
00007a66921d0b06  vmovaps xmm2, [rsp+0x10]
00007a66921d0b0c  vmovaps xmm3, [rsp+0x20]
00007a66921d0b12  vmovaps xmm4, [rsp+0x30]
00007a66921d0b18  vmovaps xmm5, [rsp+0x40]
00007a66921d0b1e  vmovaps xmm6, [rsp+0x50]
00007a66921d0b24  vmovaps xmm7, [rsp+0x60]
00007a66921d0b2a  vmovaps xmm8, [rsp+0x70]
00007a66921d0b30  vmovaps xmm9, [rsp+0x80]
00007a66921d0b39  vmovaps xmm10, [rsp+0x90]
00007a66921d0b42  vmovaps xmm11, [rsp+0xA0]
00007a66921d0b4b  vmovaps xmm12, [rsp+0xB0]
00007a66921d0b54  vmovaps xmm13, [rsp+0xC0]
00007a66921d0b5d  vmovaps xmm14, [rsp+0xD0]
00007a66921d0b66  vmovaps xmm15, [rsp+0xE0]
00007a66921d0b6f  add rsp, 0xF0
00007a66921d0b76  pop r11
00007a66921d0b78  pop r10
00007a66921d0b7a  pop r9
00007a66921d0b7c  pop r8
00007a66921d0b7e  pop rsi
00007a66921d0b7f  pop rdi
00007a66921d0b80  pop rdx
00007a66921d0b81  pop rcx
00007a66921d0b82  pop rax
00007a66921d0b83  add rsp, 0x08
00007a66921d0b87  jmp 0x00007A66921CF631
00007a66921d0b8c  sub rsp, 0x08
00007a66921d0b90  push rax
00007a66921d0b91  push rcx
00007a66921d0b92  push rdx
00007a66921d0b93  push rdi
00007a66921d0b94  push rsi
00007a66921d0b95  push r8
00007a66921d0b97  push r9
00007a66921d0b99  push r10
00007a66921d0b9b  push r11
00007a66921d0b9d  sub rsp, 0xF0
00007a66921d0ba4  vmovaps [rsp], xmm0
00007a66921d0ba9  vmovaps [rsp+0x10], xmm1
00007a66921d0baf  vmovaps [rsp+0x20], xmm2
00007a66921d0bb5  vmovaps [rsp+0x30], xmm3
00007a66921d0bbb  vmovaps [rsp+0x40], xmm4
00007a66921d0bc1  vmovaps [rsp+0x50], xmm5
00007a66921d0bc7  vmovaps [rsp+0x60], xmm6
00007a66921d0bcd  vmovaps [rsp+0x70], xmm7
00007a66921d0bd3  vmovaps [rsp+0x80], xmm8
00007a66921d0bdc  vmovaps [rsp+0x90], xmm9
00007a66921d0be5  vmovaps [rsp+0xA0], xmm10
00007a66921d0bee  vmovaps [rsp+0xB0], xmm11
00007a66921d0bf7  vmovaps [rsp+0xC0], xmm12
00007a66921d0c00  vmovaps [rsp+0xD0], xmm14
00007a66921d0c09  vmovaps [rsp+0xE0], xmm15
00007a66921d0c12  sub rsp, 0x30
00007a66921d0c16  movaps [rsp], xmm13
00007a66921d0c1b  movaps [rsp+0x10], xmm14
00007a66921d0c21  movaps [rsp+0x20], xmm2
00007a66921d0c26  lea rdi, [rsp]
00007a66921d0c2a  mov esi, 0x00
00007a66921d0c2f  mov rax, 0x635346DC7530
00007a66921d0c39  call rax
00007a66921d0c3b  movaps xmm13, [rsp]
00007a66921d0c40  add rsp, 0x30
00007a66921d0c44  vmovaps xmm0, [rsp]
00007a66921d0c49  vmovaps xmm1, [rsp+0x10]
00007a66921d0c4f  vmovaps xmm2, [rsp+0x20]
00007a66921d0c55  vmovaps xmm3, [rsp+0x30]
00007a66921d0c5b  vmovaps xmm4, [rsp+0x40]
00007a66921d0c61  vmovaps xmm5, [rsp+0x50]
00007a66921d0c67  vmovaps xmm6, [rsp+0x60]
00007a66921d0c6d  vmovaps xmm7, [rsp+0x70]
00007a66921d0c73  vmovaps xmm8, [rsp+0x80]
00007a66921d0c7c  vmovaps xmm9, [rsp+0x90]
00007a66921d0c85  vmovaps xmm10, [rsp+0xA0]
00007a66921d0c8e  vmovaps xmm11, [rsp+0xB0]
00007a66921d0c97  vmovaps xmm12, [rsp+0xC0]
00007a66921d0ca0  vmovaps xmm14, [rsp+0xD0]
00007a66921d0ca9  vmovaps xmm15, [rsp+0xE0]
00007a66921d0cb2  add rsp, 0xF0
00007a66921d0cb9  pop r11
00007a66921d0cbb  pop r10
00007a66921d0cbd  pop r9
00007a66921d0cbf  pop r8
00007a66921d0cc1  pop rsi
00007a66921d0cc2  pop rdi
00007a66921d0cc3  pop rdx
00007a66921d0cc4  pop rcx
00007a66921d0cc5  pop rax
00007a66921d0cc6  add rsp, 0x08
00007a66921d0cca  jmp 0x00007A66921CF64C
00007a66921d0ccf  sub rsp, 0x08
00007a66921d0cd3  push rax
00007a66921d0cd4  push rcx
00007a66921d0cd5  push rdx
00007a66921d0cd6  push rdi
00007a66921d0cd7  push rsi
00007a66921d0cd8  push r8
00007a66921d0cda  push r9
00007a66921d0cdc  push r10
00007a66921d0cde  push r11
00007a66921d0ce0  sub rsp, 0xF0
00007a66921d0ce7  vmovaps [rsp], xmm0
00007a66921d0cec  vmovaps [rsp+0x10], xmm2
00007a66921d0cf2  vmovaps [rsp+0x20], xmm3
00007a66921d0cf8  vmovaps [rsp+0x30], xmm4
00007a66921d0cfe  vmovaps [rsp+0x40], xmm5
00007a66921d0d04  vmovaps [rsp+0x50], xmm6
00007a66921d0d0a  vmovaps [rsp+0x60], xmm7
00007a66921d0d10  vmovaps [rsp+0x70], xmm8
00007a66921d0d16  vmovaps [rsp+0x80], xmm9
00007a66921d0d1f  vmovaps [rsp+0x90], xmm10
00007a66921d0d28  vmovaps [rsp+0xA0], xmm11
00007a66921d0d31  vmovaps [rsp+0xB0], xmm12
00007a66921d0d3a  vmovaps [rsp+0xC0], xmm13
00007a66921d0d43  vmovaps [rsp+0xD0], xmm14
00007a66921d0d4c  vmovaps [rsp+0xE0], xmm15
00007a66921d0d55  sub rsp, 0x30
00007a66921d0d59  movaps [rsp], xmm1
00007a66921d0d5d  movaps [rsp+0x10], xmm10
00007a66921d0d63  movaps [rsp+0x20], xmm2
00007a66921d0d68  lea rdi, [rsp]
00007a66921d0d6c  mov esi, 0x00
00007a66921d0d71  mov rax, 0x635346DC7530
00007a66921d0d7b  call rax
00007a66921d0d7d  movaps xmm1, [rsp]
00007a66921d0d81  add rsp, 0x30
00007a66921d0d85  vmovaps xmm0, [rsp]
00007a66921d0d8a  vmovaps xmm2, [rsp+0x10]
00007a66921d0d90  vmovaps xmm3, [rsp+0x20]
00007a66921d0d96  vmovaps xmm4, [rsp+0x30]
00007a66921d0d9c  vmovaps xmm5, [rsp+0x40]
00007a66921d0da2  vmovaps xmm6, [rsp+0x50]
00007a66921d0da8  vmovaps xmm7, [rsp+0x60]
00007a66921d0dae  vmovaps xmm8, [rsp+0x70]
00007a66921d0db4  vmovaps xmm9, [rsp+0x80]
00007a66921d0dbd  vmovaps xmm10, [rsp+0x90]
00007a66921d0dc6  vmovaps xmm11, [rsp+0xA0]
00007a66921d0dcf  vmovaps xmm12, [rsp+0xB0]
00007a66921d0dd8  vmovaps xmm13, [rsp+0xC0]
00007a66921d0de1  vmovaps xmm14, [rsp+0xD0]
00007a66921d0dea  vmovaps xmm15, [rsp+0xE0]
00007a66921d0df3  add rsp, 0xF0
00007a66921d0dfa  pop r11
00007a66921d0dfc  pop r10
00007a66921d0dfe  pop r9
00007a66921d0e00  pop r8
00007a66921d0e02  pop rsi
00007a66921d0e03  pop rdi
00007a66921d0e04  pop rdx
00007a66921d0e05  pop rcx
00007a66921d0e06  pop rax
00007a66921d0e07  add rsp, 0x08
00007a66921d0e0b  jmp 0x00007A66921CF6B4
00007a66921d0e10  sub rsp, 0x08
00007a66921d0e14  push rax
00007a66921d0e15  push rcx
00007a66921d0e16  push rdx
00007a66921d0e17  push rdi
00007a66921d0e18  push rsi
00007a66921d0e19  push r8
00007a66921d0e1b  push r9
00007a66921d0e1d  push r10
00007a66921d0e1f  push r11
00007a66921d0e21  sub rsp, 0xF0
00007a66921d0e28  vmovaps [rsp], xmm0
00007a66921d0e2d  vmovaps [rsp+0x10], xmm1
00007a66921d0e33  vmovaps [rsp+0x20], xmm2
00007a66921d0e39  vmovaps [rsp+0x30], xmm3
00007a66921d0e3f  vmovaps [rsp+0x40], xmm4
00007a66921d0e45  vmovaps [rsp+0x50], xmm5
00007a66921d0e4b  vmovaps [rsp+0x60], xmm6
00007a66921d0e51  vmovaps [rsp+0x70], xmm7
00007a66921d0e57  vmovaps [rsp+0x80], xmm8
00007a66921d0e60  vmovaps [rsp+0x90], xmm9
00007a66921d0e69  vmovaps [rsp+0xA0], xmm10
00007a66921d0e72  vmovaps [rsp+0xB0], xmm11
00007a66921d0e7b  vmovaps [rsp+0xC0], xmm12
00007a66921d0e84  vmovaps [rsp+0xD0], xmm13
00007a66921d0e8d  vmovaps [rsp+0xE0], xmm14
00007a66921d0e96  sub rsp, 0x30
00007a66921d0e9a  movaps [rsp], xmm15
00007a66921d0e9f  movaps [rsp+0x10], xmm10
00007a66921d0ea5  movaps [rsp+0x20], xmm2
00007a66921d0eaa  lea rdi, [rsp]
00007a66921d0eae  mov esi, 0x00
00007a66921d0eb3  mov rax, 0x635346DC7530
00007a66921d0ebd  call rax
00007a66921d0ebf  movaps xmm15, [rsp]
00007a66921d0ec4  add rsp, 0x30
00007a66921d0ec8  vmovaps xmm0, [rsp]
00007a66921d0ecd  vmovaps xmm1, [rsp+0x10]
00007a66921d0ed3  vmovaps xmm2, [rsp+0x20]
00007a66921d0ed9  vmovaps xmm3, [rsp+0x30]
00007a66921d0edf  vmovaps xmm4, [rsp+0x40]
00007a66921d0ee5  vmovaps xmm5, [rsp+0x50]
00007a66921d0eeb  vmovaps xmm6, [rsp+0x60]
00007a66921d0ef1  vmovaps xmm7, [rsp+0x70]
00007a66921d0ef7  vmovaps xmm8, [rsp+0x80]
00007a66921d0f00  vmovaps xmm9, [rsp+0x90]
00007a66921d0f09  vmovaps xmm10, [rsp+0xA0]
00007a66921d0f12  vmovaps xmm11, [rsp+0xB0]
00007a66921d0f1b  vmovaps xmm12, [rsp+0xC0]
00007a66921d0f24  vmovaps xmm13, [rsp+0xD0]
00007a66921d0f2d  vmovaps xmm14, [rsp+0xE0]
00007a66921d0f36  add rsp, 0xF0
00007a66921d0f3d  pop r11
00007a66921d0f3f  pop r10
00007a66921d0f41  pop r9
00007a66921d0f43  pop r8
00007a66921d0f45  pop rsi
00007a66921d0f46  pop rdi
00007a66921d0f47  pop rdx
00007a66921d0f48  pop rcx
00007a66921d0f49  pop rax
00007a66921d0f4a  add rsp, 0x08
00007a66921d0f4e  jmp 0x00007A66921CF706
00007a66921d0f53  sub rsp, 0x08
00007a66921d0f57  push rax
00007a66921d0f58  push rcx
00007a66921d0f59  push rdx
00007a66921d0f5a  push rdi
00007a66921d0f5b  push rsi
00007a66921d0f5c  push r8
00007a66921d0f5e  push r9
00007a66921d0f60  push r10
00007a66921d0f62  push r11
00007a66921d0f64  sub rsp, 0xF0
00007a66921d0f6b  vmovaps [rsp], xmm0
00007a66921d0f70  vmovaps [rsp+0x10], xmm2
00007a66921d0f76  vmovaps [rsp+0x20], xmm3
00007a66921d0f7c  vmovaps [rsp+0x30], xmm4
00007a66921d0f82  vmovaps [rsp+0x40], xmm5
00007a66921d0f88  vmovaps [rsp+0x50], xmm6
00007a66921d0f8e  vmovaps [rsp+0x60], xmm7
00007a66921d0f94  vmovaps [rsp+0x70], xmm8
00007a66921d0f9a  vmovaps [rsp+0x80], xmm9
00007a66921d0fa3  vmovaps [rsp+0x90], xmm10
00007a66921d0fac  vmovaps [rsp+0xA0], xmm11
00007a66921d0fb5  vmovaps [rsp+0xB0], xmm12
00007a66921d0fbe  vmovaps [rsp+0xC0], xmm13
00007a66921d0fc7  vmovaps [rsp+0xD0], xmm14
00007a66921d0fd0  vmovaps [rsp+0xE0], xmm15
00007a66921d0fd9  sub rsp, 0x30
00007a66921d0fdd  movaps [rsp], xmm1
00007a66921d0fe1  movaps [rsp+0x10], xmm10
00007a66921d0fe7  movaps [rsp+0x20], xmm12
00007a66921d0fed  lea rdi, [rsp]
00007a66921d0ff1  mov esi, 0x00
00007a66921d0ff6  mov rax, 0x635346DC7530
00007a66921d1000  call rax
00007a66921d1002  movaps xmm1, [rsp]
00007a66921d1006  add rsp, 0x30
00007a66921d100a  vmovaps xmm0, [rsp]
00007a66921d100f  vmovaps xmm2, [rsp+0x10]
00007a66921d1015  vmovaps xmm3, [rsp+0x20]
00007a66921d101b  vmovaps xmm4, [rsp+0x30]
00007a66921d1021  vmovaps xmm5, [rsp+0x40]
00007a66921d1027  vmovaps xmm6, [rsp+0x50]
00007a66921d102d  vmovaps xmm7, [rsp+0x60]
00007a66921d1033  vmovaps xmm8, [rsp+0x70]
00007a66921d1039  vmovaps xmm9, [rsp+0x80]
00007a66921d1042  vmovaps xmm10, [rsp+0x90]
00007a66921d104b  vmovaps xmm11, [rsp+0xA0]
00007a66921d1054  vmovaps xmm12, [rsp+0xB0]
00007a66921d105d  vmovaps xmm13, [rsp+0xC0]
00007a66921d1066  vmovaps xmm14, [rsp+0xD0]
00007a66921d106f  vmovaps xmm15, [rsp+0xE0]
00007a66921d1078  add rsp, 0xF0
00007a66921d107f  pop r11
00007a66921d1081  pop r10
00007a66921d1083  pop r9
00007a66921d1085  pop r8
00007a66921d1087  pop rsi
00007a66921d1088  pop rdi
00007a66921d1089  pop rdx
00007a66921d108a  pop rcx
00007a66921d108b  pop rax
00007a66921d108c  add rsp, 0x08
00007a66921d1090  jmp 0x00007A66921CF732
00007a66921d1095  sub rsp, 0x08
00007a66921d1099  push rax
00007a66921d109a  push rcx
00007a66921d109b  push rdx
00007a66921d109c  push rdi
00007a66921d109d  push rsi
00007a66921d109e  push r8
00007a66921d10a0  push r9
00007a66921d10a2  push r10
00007a66921d10a4  push r11
00007a66921d10a6  sub rsp, 0xF0
00007a66921d10ad  vmovaps [rsp], xmm0
00007a66921d10b2  vmovaps [rsp+0x10], xmm1
00007a66921d10b8  vmovaps [rsp+0x20], xmm2
00007a66921d10be  vmovaps [rsp+0x30], xmm3
00007a66921d10c4  vmovaps [rsp+0x40], xmm4
00007a66921d10ca  vmovaps [rsp+0x50], xmm5
00007a66921d10d0  vmovaps [rsp+0x60], xmm6
00007a66921d10d6  vmovaps [rsp+0x70], xmm7
00007a66921d10dc  vmovaps [rsp+0x80], xmm8
00007a66921d10e5  vmovaps [rsp+0x90], xmm9
00007a66921d10ee  vmovaps [rsp+0xA0], xmm10
00007a66921d10f7  vmovaps [rsp+0xB0], xmm11
00007a66921d1100  vmovaps [rsp+0xC0], xmm12
00007a66921d1109  vmovaps [rsp+0xD0], xmm13
00007a66921d1112  vmovaps [rsp+0xE0], xmm14
00007a66921d111b  sub rsp, 0x30
00007a66921d111f  movaps [rsp], xmm15
00007a66921d1124  movaps [rsp+0x10], xmm10
00007a66921d112a  movaps [rsp+0x20], xmm12
00007a66921d1130  lea rdi, [rsp]
00007a66921d1134  mov esi, 0x00
00007a66921d1139  mov rax, 0x635346DC7530
00007a66921d1143  call rax
00007a66921d1145  movaps xmm15, [rsp]
00007a66921d114a  add rsp, 0x30
00007a66921d114e  vmovaps xmm0, [rsp]
00007a66921d1153  vmovaps xmm1, [rsp+0x10]
00007a66921d1159  vmovaps xmm2, [rsp+0x20]
00007a66921d115f  vmovaps xmm3, [rsp+0x30]
00007a66921d1165  vmovaps xmm4, [rsp+0x40]
00007a66921d116b  vmovaps xmm5, [rsp+0x50]
00007a66921d1171  vmovaps xmm6, [rsp+0x60]
00007a66921d1177  vmovaps xmm7, [rsp+0x70]
00007a66921d117d  vmovaps xmm8, [rsp+0x80]
00007a66921d1186  vmovaps xmm9, [rsp+0x90]
00007a66921d118f  vmovaps xmm10, [rsp+0xA0]
00007a66921d1198  vmovaps xmm11, [rsp+0xB0]
00007a66921d11a1  vmovaps xmm12, [rsp+0xC0]
00007a66921d11aa  vmovaps xmm13, [rsp+0xD0]
00007a66921d11b3  vmovaps xmm14, [rsp+0xE0]
00007a66921d11bc  add rsp, 0xF0
00007a66921d11c3  pop r11
00007a66921d11c5  pop r10
00007a66921d11c7  pop r9
00007a66921d11c9  pop r8
00007a66921d11cb  pop rsi
00007a66921d11cc  pop rdi
00007a66921d11cd  pop rdx
00007a66921d11ce  pop rcx
00007a66921d11cf  pop rax
00007a66921d11d0  add rsp, 0x08
00007a66921d11d4  jmp 0x00007A66921CF75E
00007a66921d11d9  call 0x00007A6691FFF430
00007a66921d11de  jmp 0x00007A66921CF7EE
00007a66921d11e3  call 0x00007A6691FFF430
00007a66921d11e8  jmp 0x00007A66921CF801
00007a66921d11ed  sub rsp, 0x08
00007a66921d11f1  push rax
00007a66921d11f2  push rcx
00007a66921d11f3  push rdx
00007a66921d11f4  push rdi
00007a66921d11f5  push rsi
00007a66921d11f6  push r8
00007a66921d11f8  push r9
00007a66921d11fa  push r10
00007a66921d11fc  push r11
00007a66921d11fe  sub rsp, 0xF0
00007a66921d1205  vmovaps [rsp], xmm0
00007a66921d120a  vmovaps [rsp+0x10], xmm2
00007a66921d1210  vmovaps [rsp+0x20], xmm3
00007a66921d1216  vmovaps [rsp+0x30], xmm4
00007a66921d121c  vmovaps [rsp+0x40], xmm5
00007a66921d1222  vmovaps [rsp+0x50], xmm6
00007a66921d1228  vmovaps [rsp+0x60], xmm7
00007a66921d122e  vmovaps [rsp+0x70], xmm8
00007a66921d1234  vmovaps [rsp+0x80], xmm9
00007a66921d123d  vmovaps [rsp+0x90], xmm10
00007a66921d1246  vmovaps [rsp+0xA0], xmm11
00007a66921d124f  vmovaps [rsp+0xB0], xmm12
00007a66921d1258  vmovaps [rsp+0xC0], xmm13
00007a66921d1261  vmovaps [rsp+0xD0], xmm14
00007a66921d126a  vmovaps [rsp+0xE0], xmm15
00007a66921d1273  sub rsp, 0x30
00007a66921d1277  movaps [rsp], xmm1
00007a66921d127b  movaps [rsp+0x10], xmm13
00007a66921d1281  movaps [rsp+0x20], xmm2
00007a66921d1286  lea rdi, [rsp]
00007a66921d128a  mov esi, 0x00
00007a66921d128f  mov rax, 0x635346DC7530
00007a66921d1299  call rax
00007a66921d129b  movaps xmm1, [rsp]
00007a66921d129f  add rsp, 0x30
00007a66921d12a3  vmovaps xmm0, [rsp]
00007a66921d12a8  vmovaps xmm2, [rsp+0x10]
00007a66921d12ae  vmovaps xmm3, [rsp+0x20]
00007a66921d12b4  vmovaps xmm4, [rsp+0x30]
00007a66921d12ba  vmovaps xmm5, [rsp+0x40]
00007a66921d12c0  vmovaps xmm6, [rsp+0x50]
00007a66921d12c6  vmovaps xmm7, [rsp+0x60]
00007a66921d12cc  vmovaps xmm8, [rsp+0x70]
00007a66921d12d2  vmovaps xmm9, [rsp+0x80]
00007a66921d12db  vmovaps xmm10, [rsp+0x90]
00007a66921d12e4  vmovaps xmm11, [rsp+0xA0]
00007a66921d12ed  vmovaps xmm12, [rsp+0xB0]
00007a66921d12f6  vmovaps xmm13, [rsp+0xC0]
00007a66921d12ff  vmovaps xmm14, [rsp+0xD0]
00007a66921d1308  vmovaps xmm15, [rsp+0xE0]
00007a66921d1311  add rsp, 0xF0
00007a66921d1318  pop r11
00007a66921d131a  pop r10
00007a66921d131c  pop r9
00007a66921d131e  pop r8
00007a66921d1320  pop rsi
00007a66921d1321  pop rdi
00007a66921d1322  pop rdx
00007a66921d1323  pop rcx
00007a66921d1324  pop rax
00007a66921d1325  add rsp, 0x08
00007a66921d1329  jmp 0x00007A66921CF82C
00007a66921d132e  call 0x00007A669200E760
00007a66921d1333  jmp 0x00007A66921CF839
00007a66921d1338  sub rsp, 0x08
00007a66921d133c  push rax
00007a66921d133d  push rcx
00007a66921d133e  push rdx
00007a66921d133f  push rdi
00007a66921d1340  push rsi
00007a66921d1341  push r8
00007a66921d1343  push r9
00007a66921d1345  push r10
00007a66921d1347  push r11
00007a66921d1349  sub rsp, 0xF0
00007a66921d1350  vmovaps [rsp], xmm0
00007a66921d1355  vmovaps [rsp+0x10], xmm1
00007a66921d135b  vmovaps [rsp+0x20], xmm2
00007a66921d1361  vmovaps [rsp+0x30], xmm3
00007a66921d1367  vmovaps [rsp+0x40], xmm4
00007a66921d136d  vmovaps [rsp+0x50], xmm5
00007a66921d1373  vmovaps [rsp+0x60], xmm6
00007a66921d1379  vmovaps [rsp+0x70], xmm7
00007a66921d137f  vmovaps [rsp+0x80], xmm8
00007a66921d1388  vmovaps [rsp+0x90], xmm9
00007a66921d1391  vmovaps [rsp+0xA0], xmm10
00007a66921d139a  vmovaps [rsp+0xB0], xmm11
00007a66921d13a3  vmovaps [rsp+0xC0], xmm12
00007a66921d13ac  vmovaps [rsp+0xD0], xmm14
00007a66921d13b5  vmovaps [rsp+0xE0], xmm15
00007a66921d13be  sub rsp, 0x30
00007a66921d13c2  movaps [rsp], xmm13
00007a66921d13c7  movaps [rsp+0x10], xmm2
00007a66921d13cc  movaps [rsp+0x20], xmm1
00007a66921d13d1  lea rdi, [rsp]
00007a66921d13d5  mov esi, 0x00
00007a66921d13da  mov rax, 0x635346DC7530
00007a66921d13e4  call rax
00007a66921d13e6  movaps xmm13, [rsp]
00007a66921d13eb  add rsp, 0x30
00007a66921d13ef  vmovaps xmm0, [rsp]
00007a66921d13f4  vmovaps xmm1, [rsp+0x10]
00007a66921d13fa  vmovaps xmm2, [rsp+0x20]
00007a66921d1400  vmovaps xmm3, [rsp+0x30]
00007a66921d1406  vmovaps xmm4, [rsp+0x40]
00007a66921d140c  vmovaps xmm5, [rsp+0x50]
00007a66921d1412  vmovaps xmm6, [rsp+0x60]
00007a66921d1418  vmovaps xmm7, [rsp+0x70]
00007a66921d141e  vmovaps xmm8, [rsp+0x80]
00007a66921d1427  vmovaps xmm9, [rsp+0x90]
00007a66921d1430  vmovaps xmm10, [rsp+0xA0]
00007a66921d1439  vmovaps xmm11, [rsp+0xB0]
00007a66921d1442  vmovaps xmm12, [rsp+0xC0]
00007a66921d144b  vmovaps xmm14, [rsp+0xD0]
00007a66921d1454  vmovaps xmm15, [rsp+0xE0]
00007a66921d145d  add rsp, 0xF0
00007a66921d1464  pop r11
00007a66921d1466  pop r10
00007a66921d1468  pop r9
00007a66921d146a  pop r8
00007a66921d146c  pop rsi
00007a66921d146d  pop rdi
00007a66921d146e  pop rdx
00007a66921d146f  pop rcx
00007a66921d1470  pop rax
00007a66921d1471  add rsp, 0x08
00007a66921d1475  jmp 0x00007A66921CF878
00007a66921d147a  sub rsp, 0x08
00007a66921d147e  push rax
00007a66921d147f  push rcx
00007a66921d1480  push rdx
00007a66921d1481  push rdi
00007a66921d1482  push rsi
00007a66921d1483  push r8
00007a66921d1485  push r9
00007a66921d1487  push r10
00007a66921d1489  push r11
00007a66921d148b  sub rsp, 0xF0
00007a66921d1492  vmovaps [rsp], xmm0
00007a66921d1497  vmovaps [rsp+0x10], xmm2
00007a66921d149d  vmovaps [rsp+0x20], xmm3
00007a66921d14a3  vmovaps [rsp+0x30], xmm4
00007a66921d14a9  vmovaps [rsp+0x40], xmm5
00007a66921d14af  vmovaps [rsp+0x50], xmm6
00007a66921d14b5  vmovaps [rsp+0x60], xmm7
00007a66921d14bb  vmovaps [rsp+0x70], xmm8
00007a66921d14c1  vmovaps [rsp+0x80], xmm9
00007a66921d14ca  vmovaps [rsp+0x90], xmm10
00007a66921d14d3  vmovaps [rsp+0xA0], xmm11
00007a66921d14dc  vmovaps [rsp+0xB0], xmm12
00007a66921d14e5  vmovaps [rsp+0xC0], xmm13
00007a66921d14ee  vmovaps [rsp+0xD0], xmm14
00007a66921d14f7  vmovaps [rsp+0xE0], xmm15
00007a66921d1500  sub rsp, 0x30
00007a66921d1504  movaps [rsp], xmm1
00007a66921d1508  movaps [rsp+0x10], xmm15
00007a66921d150e  movaps [rsp+0x20], xmm2
00007a66921d1513  lea rdi, [rsp]
00007a66921d1517  mov esi, 0x00
00007a66921d151c  mov rax, 0x635346DC7530
00007a66921d1526  call rax
00007a66921d1528  movaps xmm1, [rsp]
00007a66921d152c  add rsp, 0x30
00007a66921d1530  vmovaps xmm0, [rsp]
00007a66921d1535  vmovaps xmm2, [rsp+0x10]
00007a66921d153b  vmovaps xmm3, [rsp+0x20]
00007a66921d1541  vmovaps xmm4, [rsp+0x30]
00007a66921d1547  vmovaps xmm5, [rsp+0x40]
00007a66921d154d  vmovaps xmm6, [rsp+0x50]
00007a66921d1553  vmovaps xmm7, [rsp+0x60]
00007a66921d1559  vmovaps xmm8, [rsp+0x70]
00007a66921d155f  vmovaps xmm9, [rsp+0x80]
00007a66921d1568  vmovaps xmm10, [rsp+0x90]
00007a66921d1571  vmovaps xmm11, [rsp+0xA0]
00007a66921d157a  vmovaps xmm12, [rsp+0xB0]
00007a66921d1583  vmovaps xmm13, [rsp+0xC0]
00007a66921d158c  vmovaps xmm14, [rsp+0xD0]
00007a66921d1595  vmovaps xmm15, [rsp+0xE0]
00007a66921d159e  add rsp, 0xF0
00007a66921d15a5  pop r11
00007a66921d15a7  pop r10
00007a66921d15a9  pop r9
00007a66921d15ab  pop r8
00007a66921d15ad  pop rsi
00007a66921d15ae  pop rdi
00007a66921d15af  pop rdx
00007a66921d15b0  pop rcx
00007a66921d15b1  pop rax
00007a66921d15b2  add rsp, 0x08
00007a66921d15b6  jmp 0x00007A66921CF8AC
00007a66921d15bb  sub rsp, 0x08
00007a66921d15bf  push rax
00007a66921d15c0  push rcx
00007a66921d15c1  push rdx
00007a66921d15c2  push rdi
00007a66921d15c3  push rsi
00007a66921d15c4  push r8
00007a66921d15c6  push r9
00007a66921d15c8  push r10
00007a66921d15ca  push r11
00007a66921d15cc  sub rsp, 0xF0
00007a66921d15d3  vmovaps [rsp], xmm0
00007a66921d15d8  vmovaps [rsp+0x10], xmm1
00007a66921d15de  vmovaps [rsp+0x20], xmm2
00007a66921d15e4  vmovaps [rsp+0x30], xmm3
00007a66921d15ea  vmovaps [rsp+0x40], xmm4
00007a66921d15f0  vmovaps [rsp+0x50], xmm5
00007a66921d15f6  vmovaps [rsp+0x60], xmm6
00007a66921d15fc  vmovaps [rsp+0x70], xmm7
00007a66921d1602  vmovaps [rsp+0x80], xmm8
00007a66921d160b  vmovaps [rsp+0x90], xmm9
00007a66921d1614  vmovaps [rsp+0xA0], xmm10
00007a66921d161d  vmovaps [rsp+0xB0], xmm11
00007a66921d1626  vmovaps [rsp+0xC0], xmm12
00007a66921d162f  vmovaps [rsp+0xD0], xmm13
00007a66921d1638  vmovaps [rsp+0xE0], xmm15
00007a66921d1641  sub rsp, 0x30
00007a66921d1645  movaps [rsp], xmm14
00007a66921d164a  movaps [rsp+0x10], xmm2
00007a66921d164f  movaps [rsp+0x20], xmm15
00007a66921d1655  lea rdi, [rsp]
00007a66921d1659  mov esi, 0x00
00007a66921d165e  mov rax, 0x635346DC7530
00007a66921d1668  call rax
00007a66921d166a  movaps xmm14, [rsp]
00007a66921d166f  add rsp, 0x30
00007a66921d1673  vmovaps xmm0, [rsp]
00007a66921d1678  vmovaps xmm1, [rsp+0x10]
00007a66921d167e  vmovaps xmm2, [rsp+0x20]
00007a66921d1684  vmovaps xmm3, [rsp+0x30]
00007a66921d168a  vmovaps xmm4, [rsp+0x40]
00007a66921d1690  vmovaps xmm5, [rsp+0x50]
00007a66921d1696  vmovaps xmm6, [rsp+0x60]
00007a66921d169c  vmovaps xmm7, [rsp+0x70]
00007a66921d16a2  vmovaps xmm8, [rsp+0x80]
00007a66921d16ab  vmovaps xmm9, [rsp+0x90]
00007a66921d16b4  vmovaps xmm10, [rsp+0xA0]
00007a66921d16bd  vmovaps xmm11, [rsp+0xB0]
00007a66921d16c6  vmovaps xmm12, [rsp+0xC0]
00007a66921d16cf  vmovaps xmm13, [rsp+0xD0]
00007a66921d16d8  vmovaps xmm15, [rsp+0xE0]
00007a66921d16e1  add rsp, 0xF0
00007a66921d16e8  pop r11
00007a66921d16ea  pop r10
00007a66921d16ec  pop r9
00007a66921d16ee  pop r8
00007a66921d16f0  pop rsi
00007a66921d16f1  pop rdi
00007a66921d16f2  pop rdx
00007a66921d16f3  pop rcx
00007a66921d16f4  pop rax
00007a66921d16f5  add rsp, 0x08
00007a66921d16f9  jmp 0x00007A66921CF8E7
00007a66921d16fe  sub rsp, 0x08
00007a66921d1702  push rax
00007a66921d1703  push rcx
00007a66921d1704  push rdx
00007a66921d1705  push rdi
00007a66921d1706  push rsi
00007a66921d1707  push r8
00007a66921d1709  push r9
00007a66921d170b  push r10
00007a66921d170d  push r11
00007a66921d170f  sub rsp, 0xF0
00007a66921d1716  vmovaps [rsp], xmm0
00007a66921d171b  vmovaps [rsp+0x10], xmm1
00007a66921d1721  vmovaps [rsp+0x20], xmm2
00007a66921d1727  vmovaps [rsp+0x30], xmm3
00007a66921d172d  vmovaps [rsp+0x40], xmm4
00007a66921d1733  vmovaps [rsp+0x50], xmm5
00007a66921d1739  vmovaps [rsp+0x60], xmm6
00007a66921d173f  vmovaps [rsp+0x70], xmm7
00007a66921d1745  vmovaps [rsp+0x80], xmm8
00007a66921d174e  vmovaps [rsp+0x90], xmm9
00007a66921d1757  vmovaps [rsp+0xA0], xmm10
00007a66921d1760  vmovaps [rsp+0xB0], xmm11
00007a66921d1769  vmovaps [rsp+0xC0], xmm12
00007a66921d1772  vmovaps [rsp+0xD0], xmm13
00007a66921d177b  vmovaps [rsp+0xE0], xmm14
00007a66921d1784  sub rsp, 0x30
00007a66921d1788  movaps [rsp], xmm15
00007a66921d178d  movaps [rsp+0x10], xmm2
00007a66921d1792  movaps [rsp+0x20], xmm1
00007a66921d1797  lea rdi, [rsp]
00007a66921d179b  mov esi, 0x00
00007a66921d17a0  mov rax, 0x635346DC7530
00007a66921d17aa  call rax
00007a66921d17ac  movaps xmm15, [rsp]
00007a66921d17b1  add rsp, 0x30
00007a66921d17b5  vmovaps xmm0, [rsp]
00007a66921d17ba  vmovaps xmm1, [rsp+0x10]
00007a66921d17c0  vmovaps xmm2, [rsp+0x20]
00007a66921d17c6  vmovaps xmm3, [rsp+0x30]
00007a66921d17cc  vmovaps xmm4, [rsp+0x40]
00007a66921d17d2  vmovaps xmm5, [rsp+0x50]
00007a66921d17d8  vmovaps xmm6, [rsp+0x60]
00007a66921d17de  vmovaps xmm7, [rsp+0x70]
00007a66921d17e4  vmovaps xmm8, [rsp+0x80]
00007a66921d17ed  vmovaps xmm9, [rsp+0x90]
00007a66921d17f6  vmovaps xmm10, [rsp+0xA0]
00007a66921d17ff  vmovaps xmm11, [rsp+0xB0]
00007a66921d1808  vmovaps xmm12, [rsp+0xC0]
00007a66921d1811  vmovaps xmm13, [rsp+0xD0]
00007a66921d181a  vmovaps xmm14, [rsp+0xE0]
00007a66921d1823  add rsp, 0xF0
00007a66921d182a  pop r11
00007a66921d182c  pop r10
00007a66921d182e  pop r9
00007a66921d1830  pop r8
00007a66921d1832  pop rsi
00007a66921d1833  pop rdi
00007a66921d1834  pop rdx
00007a66921d1835  pop rcx
00007a66921d1836  pop rax
00007a66921d1837  add rsp, 0x08
00007a66921d183b  jmp 0x00007A66921CF923
00007a66921d1840  call 0x00007A6691FFF430
00007a66921d1845  jmp 0x00007A66921CF930
00007a66921d184a  sub rsp, 0x08
00007a66921d184e  push rax
00007a66921d184f  push rcx
00007a66921d1850  push rdx
00007a66921d1851  push rdi
00007a66921d1852  push rsi
00007a66921d1853  push r8
00007a66921d1855  push r9
00007a66921d1857  push r10
00007a66921d1859  push r11
00007a66921d185b  sub rsp, 0xF0
00007a66921d1862  vmovaps [rsp], xmm0
00007a66921d1867  vmovaps [rsp+0x10], xmm1
00007a66921d186d  vmovaps [rsp+0x20], xmm3
00007a66921d1873  vmovaps [rsp+0x30], xmm4
00007a66921d1879  vmovaps [rsp+0x40], xmm5
00007a66921d187f  vmovaps [rsp+0x50], xmm6
00007a66921d1885  vmovaps [rsp+0x60], xmm7
00007a66921d188b  vmovaps [rsp+0x70], xmm8
00007a66921d1891  vmovaps [rsp+0x80], xmm9
00007a66921d189a  vmovaps [rsp+0x90], xmm10
00007a66921d18a3  vmovaps [rsp+0xA0], xmm11
00007a66921d18ac  vmovaps [rsp+0xB0], xmm12
00007a66921d18b5  vmovaps [rsp+0xC0], xmm13
00007a66921d18be  vmovaps [rsp+0xD0], xmm14
00007a66921d18c7  vmovaps [rsp+0xE0], xmm15
00007a66921d18d0  sub rsp, 0x30
00007a66921d18d4  movaps [rsp], xmm2
00007a66921d18d8  movaps [rsp+0x10], xmm1
00007a66921d18dd  movaps [rsp+0x20], xmm14
00007a66921d18e3  lea rdi, [rsp]
00007a66921d18e7  mov esi, 0x00
00007a66921d18ec  mov rax, 0x635346DC7530
00007a66921d18f6  call rax
00007a66921d18f8  movaps xmm2, [rsp]
00007a66921d18fc  add rsp, 0x30
00007a66921d1900  vmovaps xmm0, [rsp]
00007a66921d1905  vmovaps xmm1, [rsp+0x10]
00007a66921d190b  vmovaps xmm3, [rsp+0x20]
00007a66921d1911  vmovaps xmm4, [rsp+0x30]
00007a66921d1917  vmovaps xmm5, [rsp+0x40]
00007a66921d191d  vmovaps xmm6, [rsp+0x50]
00007a66921d1923  vmovaps xmm7, [rsp+0x60]
00007a66921d1929  vmovaps xmm8, [rsp+0x70]
00007a66921d192f  vmovaps xmm9, [rsp+0x80]
00007a66921d1938  vmovaps xmm10, [rsp+0x90]
00007a66921d1941  vmovaps xmm11, [rsp+0xA0]
00007a66921d194a  vmovaps xmm12, [rsp+0xB0]
00007a66921d1953  vmovaps xmm13, [rsp+0xC0]
00007a66921d195c  vmovaps xmm14, [rsp+0xD0]
00007a66921d1965  vmovaps xmm15, [rsp+0xE0]
00007a66921d196e  add rsp, 0xF0
00007a66921d1975  pop r11
00007a66921d1977  pop r10
00007a66921d1979  pop r9
00007a66921d197b  pop r8
00007a66921d197d  pop rsi
00007a66921d197e  pop rdi
00007a66921d197f  pop rdx
00007a66921d1980  pop rcx
00007a66921d1981  pop rax
00007a66921d1982  add rsp, 0x08
00007a66921d1986  jmp 0x00007A66921CF96D
00007a66921d198b  sub rsp, 0x08
00007a66921d198f  push rax
00007a66921d1990  push rcx
00007a66921d1991  push rdx
00007a66921d1992  push rdi
00007a66921d1993  push rsi
00007a66921d1994  push r8
00007a66921d1996  push r9
00007a66921d1998  push r10
00007a66921d199a  push r11
00007a66921d199c  sub rsp, 0xF0
00007a66921d19a3  vmovaps [rsp], xmm0
00007a66921d19a8  vmovaps [rsp+0x10], xmm1
00007a66921d19ae  vmovaps [rsp+0x20], xmm2
00007a66921d19b4  vmovaps [rsp+0x30], xmm3
00007a66921d19ba  vmovaps [rsp+0x40], xmm4
00007a66921d19c0  vmovaps [rsp+0x50], xmm5
00007a66921d19c6  vmovaps [rsp+0x60], xmm6
00007a66921d19cc  vmovaps [rsp+0x70], xmm7
00007a66921d19d2  vmovaps [rsp+0x80], xmm8
00007a66921d19db  vmovaps [rsp+0x90], xmm9
00007a66921d19e4  vmovaps [rsp+0xA0], xmm10
00007a66921d19ed  vmovaps [rsp+0xB0], xmm11
00007a66921d19f6  vmovaps [rsp+0xC0], xmm12
00007a66921d19ff  vmovaps [rsp+0xD0], xmm13
00007a66921d1a08  vmovaps [rsp+0xE0], xmm14
00007a66921d1a11  sub rsp, 0x30
00007a66921d1a15  movaps [rsp], xmm15
00007a66921d1a1a  movaps [rsp+0x10], xmm14
00007a66921d1a20  movaps [rsp+0x20], xmm1
00007a66921d1a25  lea rdi, [rsp]
00007a66921d1a29  mov esi, 0x00
00007a66921d1a2e  mov rax, 0x635346DC7530
00007a66921d1a38  call rax
00007a66921d1a3a  movaps xmm15, [rsp]
00007a66921d1a3f  add rsp, 0x30
00007a66921d1a43  vmovaps xmm0, [rsp]
00007a66921d1a48  vmovaps xmm1, [rsp+0x10]
00007a66921d1a4e  vmovaps xmm2, [rsp+0x20]
00007a66921d1a54  vmovaps xmm3, [rsp+0x30]
00007a66921d1a5a  vmovaps xmm4, [rsp+0x40]
00007a66921d1a60  vmovaps xmm5, [rsp+0x50]
00007a66921d1a66  vmovaps xmm6, [rsp+0x60]
00007a66921d1a6c  vmovaps xmm7, [rsp+0x70]
00007a66921d1a72  vmovaps xmm8, [rsp+0x80]
00007a66921d1a7b  vmovaps xmm9, [rsp+0x90]
00007a66921d1a84  vmovaps xmm10, [rsp+0xA0]
00007a66921d1a8d  vmovaps xmm11, [rsp+0xB0]
00007a66921d1a96  vmovaps xmm12, [rsp+0xC0]
00007a66921d1a9f  vmovaps xmm13, [rsp+0xD0]
00007a66921d1aa8  vmovaps xmm14, [rsp+0xE0]
00007a66921d1ab1  add rsp, 0xF0
00007a66921d1ab8  pop r11
00007a66921d1aba  pop r10
00007a66921d1abc  pop r9
00007a66921d1abe  pop r8
00007a66921d1ac0  pop rsi
00007a66921d1ac1  pop rdi
00007a66921d1ac2  pop rdx
00007a66921d1ac3  pop rcx
00007a66921d1ac4  pop rax
00007a66921d1ac5  add rsp, 0x08
00007a66921d1ac9  jmp 0x00007A66921CF9E7
00007a66921d1ace  call 0x00007A6691FFF430
00007a66921d1ad3  jmp 0x00007A66921CF9F4
00007a66921d1ad8  sub rsp, 0x08
00007a66921d1adc  push rax
00007a66921d1add  push rcx
00007a66921d1ade  push rdx
00007a66921d1adf  push rdi
00007a66921d1ae0  push rsi
00007a66921d1ae1  push r8
00007a66921d1ae3  push r9
00007a66921d1ae5  push r10
00007a66921d1ae7  push r11
00007a66921d1ae9  sub rsp, 0xF0
00007a66921d1af0  vmovaps [rsp], xmm0
00007a66921d1af5  vmovaps [rsp+0x10], xmm1
00007a66921d1afb  vmovaps [rsp+0x20], xmm2
00007a66921d1b01  vmovaps [rsp+0x30], xmm3
00007a66921d1b07  vmovaps [rsp+0x40], xmm4
00007a66921d1b0d  vmovaps [rsp+0x50], xmm5
00007a66921d1b13  vmovaps [rsp+0x60], xmm6
00007a66921d1b19  vmovaps [rsp+0x70], xmm7
00007a66921d1b1f  vmovaps [rsp+0x80], xmm8
00007a66921d1b28  vmovaps [rsp+0x90], xmm9
00007a66921d1b31  vmovaps [rsp+0xA0], xmm10
00007a66921d1b3a  vmovaps [rsp+0xB0], xmm11
00007a66921d1b43  vmovaps [rsp+0xC0], xmm12
00007a66921d1b4c  vmovaps [rsp+0xD0], xmm13
00007a66921d1b55  vmovaps [rsp+0xE0], xmm15
00007a66921d1b5e  sub rsp, 0x30
00007a66921d1b62  movaps [rsp], xmm14
00007a66921d1b67  movaps [rsp+0x10], xmm13
00007a66921d1b6d  movaps [rsp+0x20], xmm1
00007a66921d1b72  lea rdi, [rsp]
00007a66921d1b76  mov esi, 0x00
00007a66921d1b7b  mov rax, 0x635346DC7530
00007a66921d1b85  call rax
00007a66921d1b87  movaps xmm14, [rsp]
00007a66921d1b8c  add rsp, 0x30
00007a66921d1b90  vmovaps xmm0, [rsp]
00007a66921d1b95  vmovaps xmm1, [rsp+0x10]
00007a66921d1b9b  vmovaps xmm2, [rsp+0x20]
00007a66921d1ba1  vmovaps xmm3, [rsp+0x30]
00007a66921d1ba7  vmovaps xmm4, [rsp+0x40]
00007a66921d1bad  vmovaps xmm5, [rsp+0x50]
00007a66921d1bb3  vmovaps xmm6, [rsp+0x60]
00007a66921d1bb9  vmovaps xmm7, [rsp+0x70]
00007a66921d1bbf  vmovaps xmm8, [rsp+0x80]
00007a66921d1bc8  vmovaps xmm9, [rsp+0x90]
00007a66921d1bd1  vmovaps xmm10, [rsp+0xA0]
00007a66921d1bda  vmovaps xmm11, [rsp+0xB0]
00007a66921d1be3  vmovaps xmm12, [rsp+0xC0]
00007a66921d1bec  vmovaps xmm13, [rsp+0xD0]
00007a66921d1bf5  vmovaps xmm15, [rsp+0xE0]
00007a66921d1bfe  add rsp, 0xF0
00007a66921d1c05  pop r11
00007a66921d1c07  pop r10
00007a66921d1c09  pop r9
00007a66921d1c0b  pop r8
00007a66921d1c0d  pop rsi
00007a66921d1c0e  pop rdi
00007a66921d1c0f  pop rdx
00007a66921d1c10  pop rcx
00007a66921d1c11  pop rax
00007a66921d1c12  add rsp, 0x08
00007a66921d1c16  jmp 0x00007A66921CFAAF
00007a66921d1c1b  sub rsp, 0x08
00007a66921d1c1f  push rax
00007a66921d1c20  push rcx
00007a66921d1c21  push rdx
00007a66921d1c22  push rdi
00007a66921d1c23  push rsi
00007a66921d1c24  push r8
00007a66921d1c26  push r9
00007a66921d1c28  push r10
00007a66921d1c2a  push r11
00007a66921d1c2c  sub rsp, 0xF0
00007a66921d1c33  vmovaps [rsp], xmm0
00007a66921d1c38  vmovaps [rsp+0x10], xmm1
00007a66921d1c3e  vmovaps [rsp+0x20], xmm2
00007a66921d1c44  vmovaps [rsp+0x30], xmm3
00007a66921d1c4a  vmovaps [rsp+0x40], xmm4
00007a66921d1c50  vmovaps [rsp+0x50], xmm5
00007a66921d1c56  vmovaps [rsp+0x60], xmm6
00007a66921d1c5c  vmovaps [rsp+0x70], xmm7
00007a66921d1c62  vmovaps [rsp+0x80], xmm8
00007a66921d1c6b  vmovaps [rsp+0x90], xmm9
00007a66921d1c74  vmovaps [rsp+0xA0], xmm10
00007a66921d1c7d  vmovaps [rsp+0xB0], xmm11
00007a66921d1c86  vmovaps [rsp+0xC0], xmm12
00007a66921d1c8f  vmovaps [rsp+0xD0], xmm13
00007a66921d1c98  vmovaps [rsp+0xE0], xmm14
00007a66921d1ca1  sub rsp, 0x30
00007a66921d1ca5  movaps [rsp], xmm15
00007a66921d1caa  movaps [rsp+0x10], xmm13
00007a66921d1cb0  movaps [rsp+0x20], xmm1
00007a66921d1cb5  lea rdi, [rsp]
00007a66921d1cb9  mov esi, 0x00
00007a66921d1cbe  mov rax, 0x635346DC7530
00007a66921d1cc8  call rax
00007a66921d1cca  movaps xmm15, [rsp]
00007a66921d1ccf  add rsp, 0x30
00007a66921d1cd3  vmovaps xmm0, [rsp]
00007a66921d1cd8  vmovaps xmm1, [rsp+0x10]
00007a66921d1cde  vmovaps xmm2, [rsp+0x20]
00007a66921d1ce4  vmovaps xmm3, [rsp+0x30]
00007a66921d1cea  vmovaps xmm4, [rsp+0x40]
00007a66921d1cf0  vmovaps xmm5, [rsp+0x50]
00007a66921d1cf6  vmovaps xmm6, [rsp+0x60]
00007a66921d1cfc  vmovaps xmm7, [rsp+0x70]
00007a66921d1d02  vmovaps xmm8, [rsp+0x80]
00007a66921d1d0b  vmovaps xmm9, [rsp+0x90]
00007a66921d1d14  vmovaps xmm10, [rsp+0xA0]
00007a66921d1d1d  vmovaps xmm11, [rsp+0xB0]
00007a66921d1d26  vmovaps xmm12, [rsp+0xC0]
00007a66921d1d2f  vmovaps xmm13, [rsp+0xD0]
00007a66921d1d38  vmovaps xmm14, [rsp+0xE0]
00007a66921d1d41  add rsp, 0xF0
00007a66921d1d48  pop r11
00007a66921d1d4a  pop r10
00007a66921d1d4c  pop r9
00007a66921d1d4e  pop r8
00007a66921d1d50  pop rsi
00007a66921d1d51  pop rdi
00007a66921d1d52  pop rdx
00007a66921d1d53  pop rcx
00007a66921d1d54  pop rax
00007a66921d1d55  add rsp, 0x08
00007a66921d1d59  jmp 0x00007A66921CFAEB
00007a66921d1d5e  call 0x00007A6691FFF430
00007a66921d1d63  jmp 0x00007A66921CFAF8
00007a66921d1d68  sub rsp, 0x08
00007a66921d1d6c  push rax
00007a66921d1d6d  push rcx
00007a66921d1d6e  push rdx
00007a66921d1d6f  push rdi
00007a66921d1d70  push rsi
00007a66921d1d71  push r8
00007a66921d1d73  push r9
00007a66921d1d75  push r10
00007a66921d1d77  push r11
00007a66921d1d79  sub rsp, 0xF0
00007a66921d1d80  vmovaps [rsp], xmm0
00007a66921d1d85  vmovaps [rsp+0x10], xmm1
00007a66921d1d8b  vmovaps [rsp+0x20], xmm2
00007a66921d1d91  vmovaps [rsp+0x30], xmm3
00007a66921d1d97  vmovaps [rsp+0x40], xmm4
00007a66921d1d9d  vmovaps [rsp+0x50], xmm5
00007a66921d1da3  vmovaps [rsp+0x60], xmm6
00007a66921d1da9  vmovaps [rsp+0x70], xmm7
00007a66921d1daf  vmovaps [rsp+0x80], xmm8
00007a66921d1db8  vmovaps [rsp+0x90], xmm9
00007a66921d1dc1  vmovaps [rsp+0xA0], xmm10
00007a66921d1dca  vmovaps [rsp+0xB0], xmm11
00007a66921d1dd3  vmovaps [rsp+0xC0], xmm12
00007a66921d1ddc  vmovaps [rsp+0xD0], xmm13
00007a66921d1de5  vmovaps [rsp+0xE0], xmm15
00007a66921d1dee  sub rsp, 0x30
00007a66921d1df2  movaps [rsp], xmm14
00007a66921d1df7  movaps [rsp+0x10], xmm13
00007a66921d1dfd  movaps [rsp+0x20], xmm2
00007a66921d1e02  lea rdi, [rsp]
00007a66921d1e06  mov esi, 0x00
00007a66921d1e0b  mov rax, 0x635346DC7530
00007a66921d1e15  call rax
00007a66921d1e17  movaps xmm14, [rsp]
00007a66921d1e1c  add rsp, 0x30
00007a66921d1e20  vmovaps xmm0, [rsp]
00007a66921d1e25  vmovaps xmm1, [rsp+0x10]
00007a66921d1e2b  vmovaps xmm2, [rsp+0x20]
00007a66921d1e31  vmovaps xmm3, [rsp+0x30]
00007a66921d1e37  vmovaps xmm4, [rsp+0x40]
00007a66921d1e3d  vmovaps xmm5, [rsp+0x50]
00007a66921d1e43  vmovaps xmm6, [rsp+0x60]
00007a66921d1e49  vmovaps xmm7, [rsp+0x70]
00007a66921d1e4f  vmovaps xmm8, [rsp+0x80]
00007a66921d1e58  vmovaps xmm9, [rsp+0x90]
00007a66921d1e61  vmovaps xmm10, [rsp+0xA0]
00007a66921d1e6a  vmovaps xmm11, [rsp+0xB0]
00007a66921d1e73  vmovaps xmm12, [rsp+0xC0]
00007a66921d1e7c  vmovaps xmm13, [rsp+0xD0]
00007a66921d1e85  vmovaps xmm15, [rsp+0xE0]
00007a66921d1e8e  add rsp, 0xF0
00007a66921d1e95  pop r11
00007a66921d1e97  pop r10
00007a66921d1e99  pop r9
00007a66921d1e9b  pop r8
00007a66921d1e9d  pop rsi
00007a66921d1e9e  pop rdi
00007a66921d1e9f  pop rdx
00007a66921d1ea0  pop rcx
00007a66921d1ea1  pop rax
00007a66921d1ea2  add rsp, 0x08
00007a66921d1ea6  jmp 0x00007A66921CFB24
00007a66921d1eab  sub rsp, 0x08
00007a66921d1eaf  push rax
00007a66921d1eb0  push rcx
00007a66921d1eb1  push rdx
00007a66921d1eb2  push rdi
00007a66921d1eb3  push rsi
00007a66921d1eb4  push r8
00007a66921d1eb6  push r9
00007a66921d1eb8  push r10
00007a66921d1eba  push r11
00007a66921d1ebc  sub rsp, 0xF0
00007a66921d1ec3  vmovaps [rsp], xmm0
00007a66921d1ec8  vmovaps [rsp+0x10], xmm2
00007a66921d1ece  vmovaps [rsp+0x20], xmm3
00007a66921d1ed4  vmovaps [rsp+0x30], xmm4
00007a66921d1eda  vmovaps [rsp+0x40], xmm5
00007a66921d1ee0  vmovaps [rsp+0x50], xmm6
00007a66921d1ee6  vmovaps [rsp+0x60], xmm7
00007a66921d1eec  vmovaps [rsp+0x70], xmm8
00007a66921d1ef2  vmovaps [rsp+0x80], xmm9
00007a66921d1efb  vmovaps [rsp+0x90], xmm10
00007a66921d1f04  vmovaps [rsp+0xA0], xmm11
00007a66921d1f0d  vmovaps [rsp+0xB0], xmm12
00007a66921d1f16  vmovaps [rsp+0xC0], xmm13
00007a66921d1f1f  vmovaps [rsp+0xD0], xmm14
00007a66921d1f28  vmovaps [rsp+0xE0], xmm15
00007a66921d1f31  sub rsp, 0x30
00007a66921d1f35  movaps [rsp], xmm1
00007a66921d1f39  movaps [rsp+0x10], xmm13
00007a66921d1f3f  movaps [rsp+0x20], xmm2
00007a66921d1f44  lea rdi, [rsp]
00007a66921d1f48  mov esi, 0x00
00007a66921d1f4d  mov rax, 0x635346DC7530
00007a66921d1f57  call rax
00007a66921d1f59  movaps xmm1, [rsp]
00007a66921d1f5d  add rsp, 0x30
00007a66921d1f61  vmovaps xmm0, [rsp]
00007a66921d1f66  vmovaps xmm2, [rsp+0x10]
00007a66921d1f6c  vmovaps xmm3, [rsp+0x20]
00007a66921d1f72  vmovaps xmm4, [rsp+0x30]
00007a66921d1f78  vmovaps xmm5, [rsp+0x40]
00007a66921d1f7e  vmovaps xmm6, [rsp+0x50]
00007a66921d1f84  vmovaps xmm7, [rsp+0x60]
00007a66921d1f8a  vmovaps xmm8, [rsp+0x70]
00007a66921d1f90  vmovaps xmm9, [rsp+0x80]
00007a66921d1f99  vmovaps xmm10, [rsp+0x90]
00007a66921d1fa2  vmovaps xmm11, [rsp+0xA0]
00007a66921d1fab  vmovaps xmm12, [rsp+0xB0]
00007a66921d1fb4  vmovaps xmm13, [rsp+0xC0]
00007a66921d1fbd  vmovaps xmm14, [rsp+0xD0]
00007a66921d1fc6  vmovaps xmm15, [rsp+0xE0]
00007a66921d1fcf  add rsp, 0xF0
00007a66921d1fd6  pop r11
00007a66921d1fd8  pop r10
00007a66921d1fda  pop r9
00007a66921d1fdc  pop r8
00007a66921d1fde  pop rsi
00007a66921d1fdf  pop rdi
00007a66921d1fe0  pop rdx
00007a66921d1fe1  pop rcx
00007a66921d1fe2  pop rax
00007a66921d1fe3  add rsp, 0x08
00007a66921d1fe7  jmp 0x00007A66921CFB52
00007a66921d1fec  sub rsp, 0x08
00007a66921d1ff0  push rax
00007a66921d1ff1  push rcx
00007a66921d1ff2  push rdx
00007a66921d1ff3  push rdi
00007a66921d1ff4  push rsi
00007a66921d1ff5  push r8
00007a66921d1ff7  push r9
00007a66921d1ff9  push r10
00007a66921d1ffb  push r11
00007a66921d1ffd  sub rsp, 0xF0
00007a66921d2004  vmovaps [rsp], xmm0
00007a66921d2009  vmovaps [rsp+0x10], xmm1
00007a66921d200f  vmovaps [rsp+0x20], xmm3
00007a66921d2015  vmovaps [rsp+0x30], xmm4
00007a66921d201b  vmovaps [rsp+0x40], xmm5
00007a66921d2021  vmovaps [rsp+0x50], xmm6
00007a66921d2027  vmovaps [rsp+0x60], xmm7
00007a66921d202d  vmovaps [rsp+0x70], xmm8
00007a66921d2033  vmovaps [rsp+0x80], xmm9
00007a66921d203c  vmovaps [rsp+0x90], xmm10
00007a66921d2045  vmovaps [rsp+0xA0], xmm11
00007a66921d204e  vmovaps [rsp+0xB0], xmm12
00007a66921d2057  vmovaps [rsp+0xC0], xmm13
00007a66921d2060  vmovaps [rsp+0xD0], xmm14
00007a66921d2069  vmovaps [rsp+0xE0], xmm15
00007a66921d2072  sub rsp, 0x30
00007a66921d2076  movaps [rsp], xmm2
00007a66921d207a  movaps [rsp+0x10], xmm1
00007a66921d207f  movaps [rsp+0x20], xmm13
00007a66921d2085  lea rdi, [rsp]
00007a66921d2089  mov esi, 0x00
00007a66921d208e  mov rax, 0x635346DC7530
00007a66921d2098  call rax
00007a66921d209a  movaps xmm2, [rsp]
00007a66921d209e  add rsp, 0x30
00007a66921d20a2  vmovaps xmm0, [rsp]
00007a66921d20a7  vmovaps xmm1, [rsp+0x10]
00007a66921d20ad  vmovaps xmm3, [rsp+0x20]
00007a66921d20b3  vmovaps xmm4, [rsp+0x30]
00007a66921d20b9  vmovaps xmm5, [rsp+0x40]
00007a66921d20bf  vmovaps xmm6, [rsp+0x50]
00007a66921d20c5  vmovaps xmm7, [rsp+0x60]
00007a66921d20cb  vmovaps xmm8, [rsp+0x70]
00007a66921d20d1  vmovaps xmm9, [rsp+0x80]
00007a66921d20da  vmovaps xmm10, [rsp+0x90]
00007a66921d20e3  vmovaps xmm11, [rsp+0xA0]
00007a66921d20ec  vmovaps xmm12, [rsp+0xB0]
00007a66921d20f5  vmovaps xmm13, [rsp+0xC0]
00007a66921d20fe  vmovaps xmm14, [rsp+0xD0]
00007a66921d2107  vmovaps xmm15, [rsp+0xE0]
00007a66921d2110  add rsp, 0xF0
00007a66921d2117  pop r11
00007a66921d2119  pop r10
00007a66921d211b  pop r9
00007a66921d211d  pop r8
00007a66921d211f  pop rsi
00007a66921d2120  pop rdi
00007a66921d2121  pop rdx
00007a66921d2122  pop rcx
00007a66921d2123  pop rax
00007a66921d2124  add rsp, 0x08
00007a66921d2128  jmp 0x00007A66921CFBAB
00007a66921d212d  call 0x00007A6691FFF430
00007a66921d2132  jmp 0x00007A66921CFBB8
00007a66921d2137  sub rsp, 0x08
00007a66921d213b  push rax
00007a66921d213c  push rcx
00007a66921d213d  push rdx
00007a66921d213e  push rdi
00007a66921d213f  push rsi
00007a66921d2140  push r8
00007a66921d2142  push r9
00007a66921d2144  push r10
00007a66921d2146  push r11
00007a66921d2148  sub rsp, 0xF0
00007a66921d214f  vmovaps [rsp], xmm0
00007a66921d2154  vmovaps [rsp+0x10], xmm1
00007a66921d215a  vmovaps [rsp+0x20], xmm2
00007a66921d2160  vmovaps [rsp+0x30], xmm3
00007a66921d2166  vmovaps [rsp+0x40], xmm4
00007a66921d216c  vmovaps [rsp+0x50], xmm5
00007a66921d2172  vmovaps [rsp+0x60], xmm6
00007a66921d2178  vmovaps [rsp+0x70], xmm7
00007a66921d217e  vmovaps [rsp+0x80], xmm8
00007a66921d2187  vmovaps [rsp+0x90], xmm9
00007a66921d2190  vmovaps [rsp+0xA0], xmm10
00007a66921d2199  vmovaps [rsp+0xB0], xmm11
00007a66921d21a2  vmovaps [rsp+0xC0], xmm12
00007a66921d21ab  vmovaps [rsp+0xD0], xmm13
00007a66921d21b4  vmovaps [rsp+0xE0], xmm14
00007a66921d21bd  sub rsp, 0x30
00007a66921d21c1  movaps [rsp], xmm15
00007a66921d21c6  movaps [rsp+0x10], xmm13
00007a66921d21cc  movaps [rsp+0x20], xmm1
00007a66921d21d1  lea rdi, [rsp]
00007a66921d21d5  mov esi, 0x00
00007a66921d21da  mov rax, 0x635346DC7530
00007a66921d21e4  call rax
00007a66921d21e6  movaps xmm15, [rsp]
00007a66921d21eb  add rsp, 0x30
00007a66921d21ef  vmovaps xmm0, [rsp]
00007a66921d21f4  vmovaps xmm1, [rsp+0x10]
00007a66921d21fa  vmovaps xmm2, [rsp+0x20]
00007a66921d2200  vmovaps xmm3, [rsp+0x30]
00007a66921d2206  vmovaps xmm4, [rsp+0x40]
00007a66921d220c  vmovaps xmm5, [rsp+0x50]
00007a66921d2212  vmovaps xmm6, [rsp+0x60]
00007a66921d2218  vmovaps xmm7, [rsp+0x70]
00007a66921d221e  vmovaps xmm8, [rsp+0x80]
00007a66921d2227  vmovaps xmm9, [rsp+0x90]
00007a66921d2230  vmovaps xmm10, [rsp+0xA0]
00007a66921d2239  vmovaps xmm11, [rsp+0xB0]
00007a66921d2242  vmovaps xmm12, [rsp+0xC0]
00007a66921d224b  vmovaps xmm13, [rsp+0xD0]
00007a66921d2254  vmovaps xmm14, [rsp+0xE0]
00007a66921d225d  add rsp, 0xF0
00007a66921d2264  pop r11
00007a66921d2266  pop r10
00007a66921d2268  pop r9
00007a66921d226a  pop r8
00007a66921d226c  pop rsi
00007a66921d226d  pop rdi
00007a66921d226e  pop rdx
00007a66921d226f  pop rcx
00007a66921d2270  pop rax
00007a66921d2271  add rsp, 0x08
00007a66921d2275  jmp 0x00007A66921CFBF7
00007a66921d227a  sub rsp, 0x08
00007a66921d227e  push rax
00007a66921d227f  push rcx
00007a66921d2280  push rdx
00007a66921d2281  push rdi
00007a66921d2282  push rsi
00007a66921d2283  push r8
00007a66921d2285  push r9
00007a66921d2287  push r10
00007a66921d2289  push r11
00007a66921d228b  sub rsp, 0xF0
00007a66921d2292  vmovaps [rsp], xmm0
00007a66921d2297  vmovaps [rsp+0x10], xmm1
00007a66921d229d  vmovaps [rsp+0x20], xmm2
00007a66921d22a3  vmovaps [rsp+0x30], xmm3
00007a66921d22a9  vmovaps [rsp+0x40], xmm4
00007a66921d22af  vmovaps [rsp+0x50], xmm5
00007a66921d22b5  vmovaps [rsp+0x60], xmm6
00007a66921d22bb  vmovaps [rsp+0x70], xmm7
00007a66921d22c1  vmovaps [rsp+0x80], xmm8
00007a66921d22ca  vmovaps [rsp+0x90], xmm9
00007a66921d22d3  vmovaps [rsp+0xA0], xmm10
00007a66921d22dc  vmovaps [rsp+0xB0], xmm11
00007a66921d22e5  vmovaps [rsp+0xC0], xmm12
00007a66921d22ee  vmovaps [rsp+0xD0], xmm13
00007a66921d22f7  vmovaps [rsp+0xE0], xmm15
00007a66921d2300  sub rsp, 0x30
00007a66921d2304  movaps [rsp], xmm14
00007a66921d2309  movaps [rsp+0x10], xmm11
00007a66921d230f  movaps [rsp+0x20], xmm1
00007a66921d2314  lea rdi, [rsp]
00007a66921d2318  mov esi, 0x00
00007a66921d231d  mov rax, 0x635346DC7530
00007a66921d2327  call rax
00007a66921d2329  movaps xmm14, [rsp]
00007a66921d232e  add rsp, 0x30
00007a66921d2332  vmovaps xmm0, [rsp]
00007a66921d2337  vmovaps xmm1, [rsp+0x10]
00007a66921d233d  vmovaps xmm2, [rsp+0x20]
00007a66921d2343  vmovaps xmm3, [rsp+0x30]
00007a66921d2349  vmovaps xmm4, [rsp+0x40]
00007a66921d234f  vmovaps xmm5, [rsp+0x50]
00007a66921d2355  vmovaps xmm6, [rsp+0x60]
00007a66921d235b  vmovaps xmm7, [rsp+0x70]
00007a66921d2361  vmovaps xmm8, [rsp+0x80]
00007a66921d236a  vmovaps xmm9, [rsp+0x90]
00007a66921d2373  vmovaps xmm10, [rsp+0xA0]
00007a66921d237c  vmovaps xmm11, [rsp+0xB0]
00007a66921d2385  vmovaps xmm12, [rsp+0xC0]
00007a66921d238e  vmovaps xmm13, [rsp+0xD0]
00007a66921d2397  vmovaps xmm15, [rsp+0xE0]
00007a66921d23a0  add rsp, 0xF0
00007a66921d23a7  pop r11
00007a66921d23a9  pop r10
00007a66921d23ab  pop r9
00007a66921d23ad  pop r8
00007a66921d23af  pop rsi
00007a66921d23b0  pop rdi
00007a66921d23b1  pop rdx
00007a66921d23b2  pop rcx
00007a66921d23b3  pop rax
00007a66921d23b4  add rsp, 0x08
00007a66921d23b8  jmp 0x00007A66921CFC21
00007a66921d23bd  sub rsp, 0x08
00007a66921d23c1  push rax
00007a66921d23c2  push rcx
00007a66921d23c3  push rdx
00007a66921d23c4  push rdi
00007a66921d23c5  push rsi
00007a66921d23c6  push r8
00007a66921d23c8  push r9
00007a66921d23ca  push r10
00007a66921d23cc  push r11
00007a66921d23ce  sub rsp, 0xF0
00007a66921d23d5  vmovaps [rsp], xmm0
00007a66921d23da  vmovaps [rsp+0x10], xmm1
00007a66921d23e0  vmovaps [rsp+0x20], xmm2
00007a66921d23e6  vmovaps [rsp+0x30], xmm3
00007a66921d23ec  vmovaps [rsp+0x40], xmm4
00007a66921d23f2  vmovaps [rsp+0x50], xmm5
00007a66921d23f8  vmovaps [rsp+0x60], xmm6
00007a66921d23fe  vmovaps [rsp+0x70], xmm7
00007a66921d2404  vmovaps [rsp+0x80], xmm8
00007a66921d240d  vmovaps [rsp+0x90], xmm9
00007a66921d2416  vmovaps [rsp+0xA0], xmm10
00007a66921d241f  vmovaps [rsp+0xB0], xmm11
00007a66921d2428  vmovaps [rsp+0xC0], xmm12
00007a66921d2431  vmovaps [rsp+0xD0], xmm14
00007a66921d243a  vmovaps [rsp+0xE0], xmm15
00007a66921d2443  sub rsp, 0x30
00007a66921d2447  movaps [rsp], xmm13
00007a66921d244c  movaps [rsp+0x10], xmm11
00007a66921d2452  movaps [rsp+0x20], xmm1
00007a66921d2457  lea rdi, [rsp]
00007a66921d245b  mov esi, 0x00
00007a66921d2460  mov rax, 0x635346DC7530
00007a66921d246a  call rax
00007a66921d246c  movaps xmm13, [rsp]
00007a66921d2471  add rsp, 0x30
00007a66921d2475  vmovaps xmm0, [rsp]
00007a66921d247a  vmovaps xmm1, [rsp+0x10]
00007a66921d2480  vmovaps xmm2, [rsp+0x20]
00007a66921d2486  vmovaps xmm3, [rsp+0x30]
00007a66921d248c  vmovaps xmm4, [rsp+0x40]
00007a66921d2492  vmovaps xmm5, [rsp+0x50]
00007a66921d2498  vmovaps xmm6, [rsp+0x60]
00007a66921d249e  vmovaps xmm7, [rsp+0x70]
00007a66921d24a4  vmovaps xmm8, [rsp+0x80]
00007a66921d24ad  vmovaps xmm9, [rsp+0x90]
00007a66921d24b6  vmovaps xmm10, [rsp+0xA0]
00007a66921d24bf  vmovaps xmm11, [rsp+0xB0]
00007a66921d24c8  vmovaps xmm12, [rsp+0xC0]
00007a66921d24d1  vmovaps xmm14, [rsp+0xD0]
00007a66921d24da  vmovaps xmm15, [rsp+0xE0]
00007a66921d24e3  add rsp, 0xF0
00007a66921d24ea  pop r11
00007a66921d24ec  pop r10
00007a66921d24ee  pop r9
00007a66921d24f0  pop r8
00007a66921d24f2  pop rsi
00007a66921d24f3  pop rdi
00007a66921d24f4  pop rdx
00007a66921d24f5  pop rcx
00007a66921d24f6  pop rax
00007a66921d24f7  add rsp, 0x08
00007a66921d24fb  jmp 0x00007A66921CFC76
00007a66921d2500  call 0x00007A6691FFF430
00007a66921d2505  jmp 0x00007A66921CFC83
00007a66921d250a  sub rsp, 0x08
00007a66921d250e  push rax
00007a66921d250f  push rcx
00007a66921d2510  push rdx
00007a66921d2511  push rdi
00007a66921d2512  push rsi
00007a66921d2513  push r8
00007a66921d2515  push r9
00007a66921d2517  push r10
00007a66921d2519  push r11
00007a66921d251b  sub rsp, 0xF0
00007a66921d2522  vmovaps [rsp], xmm0
00007a66921d2527  vmovaps [rsp+0x10], xmm1
00007a66921d252d  vmovaps [rsp+0x20], xmm2
00007a66921d2533  vmovaps [rsp+0x30], xmm3
00007a66921d2539  vmovaps [rsp+0x40], xmm4
00007a66921d253f  vmovaps [rsp+0x50], xmm5
00007a66921d2545  vmovaps [rsp+0x60], xmm6
00007a66921d254b  vmovaps [rsp+0x70], xmm7
00007a66921d2551  vmovaps [rsp+0x80], xmm8
00007a66921d255a  vmovaps [rsp+0x90], xmm9
00007a66921d2563  vmovaps [rsp+0xA0], xmm10
00007a66921d256c  vmovaps [rsp+0xB0], xmm11
00007a66921d2575  vmovaps [rsp+0xC0], xmm12
00007a66921d257e  vmovaps [rsp+0xD0], xmm13
00007a66921d2587  vmovaps [rsp+0xE0], xmm14
00007a66921d2590  sub rsp, 0x30
00007a66921d2594  movaps [rsp], xmm15
00007a66921d2599  movaps [rsp+0x10], xmm11
00007a66921d259f  movaps [rsp+0x20], xmm1
00007a66921d25a4  lea rdi, [rsp]
00007a66921d25a8  mov esi, 0x00
00007a66921d25ad  mov rax, 0x635346DC7530
00007a66921d25b7  call rax
00007a66921d25b9  movaps xmm15, [rsp]
00007a66921d25be  add rsp, 0x30
00007a66921d25c2  vmovaps xmm0, [rsp]
00007a66921d25c7  vmovaps xmm1, [rsp+0x10]
00007a66921d25cd  vmovaps xmm2, [rsp+0x20]
00007a66921d25d3  vmovaps xmm3, [rsp+0x30]
00007a66921d25d9  vmovaps xmm4, [rsp+0x40]
00007a66921d25df  vmovaps xmm5, [rsp+0x50]
00007a66921d25e5  vmovaps xmm6, [rsp+0x60]
00007a66921d25eb  vmovaps xmm7, [rsp+0x70]
00007a66921d25f1  vmovaps xmm8, [rsp+0x80]
00007a66921d25fa  vmovaps xmm9, [rsp+0x90]
00007a66921d2603  vmovaps xmm10, [rsp+0xA0]
00007a66921d260c  vmovaps xmm11, [rsp+0xB0]
00007a66921d2615  vmovaps xmm12, [rsp+0xC0]
00007a66921d261e  vmovaps xmm13, [rsp+0xD0]
00007a66921d2627  vmovaps xmm14, [rsp+0xE0]
00007a66921d2630  add rsp, 0xF0
00007a66921d2637  pop r11
00007a66921d2639  pop r10
00007a66921d263b  pop r9
00007a66921d263d  pop r8
00007a66921d263f  pop rsi
00007a66921d2640  pop rdi
00007a66921d2641  pop rdx
00007a66921d2642  pop rcx
00007a66921d2643  pop rax
00007a66921d2644  add rsp, 0x08
00007a66921d2648  jmp 0x00007A66921CFCBC
00007a66921d264d  sub rsp, 0x08
00007a66921d2651  push rax
00007a66921d2652  push rcx
00007a66921d2653  push rdx
00007a66921d2654  push rdi
00007a66921d2655  push rsi
00007a66921d2656  push r8
00007a66921d2658  push r9
00007a66921d265a  push r10
00007a66921d265c  push r11
00007a66921d265e  sub rsp, 0xF0
00007a66921d2665  vmovaps [rsp], xmm0
00007a66921d266a  vmovaps [rsp+0x10], xmm1
00007a66921d2670  vmovaps [rsp+0x20], xmm2
00007a66921d2676  vmovaps [rsp+0x30], xmm3
00007a66921d267c  vmovaps [rsp+0x40], xmm4
00007a66921d2682  vmovaps [rsp+0x50], xmm5
00007a66921d2688  vmovaps [rsp+0x60], xmm6
00007a66921d268e  vmovaps [rsp+0x70], xmm7
00007a66921d2694  vmovaps [rsp+0x80], xmm8
00007a66921d269d  vmovaps [rsp+0x90], xmm9
00007a66921d26a6  vmovaps [rsp+0xA0], xmm10
00007a66921d26af  vmovaps [rsp+0xB0], xmm12
00007a66921d26b8  vmovaps [rsp+0xC0], xmm13
00007a66921d26c1  vmovaps [rsp+0xD0], xmm14
00007a66921d26ca  vmovaps [rsp+0xE0], xmm15
00007a66921d26d3  sub rsp, 0x30
00007a66921d26d7  movaps [rsp], xmm11
00007a66921d26dc  movaps [rsp+0x10], xmm6
00007a66921d26e1  movaps [rsp+0x20], xmm14
00007a66921d26e7  lea rdi, [rsp]
00007a66921d26eb  mov esi, 0x00
00007a66921d26f0  mov rax, 0x635346DC7530
00007a66921d26fa  call rax
00007a66921d26fc  movaps xmm11, [rsp]
00007a66921d2701  add rsp, 0x30
00007a66921d2705  vmovaps xmm0, [rsp]
00007a66921d270a  vmovaps xmm1, [rsp+0x10]
00007a66921d2710  vmovaps xmm2, [rsp+0x20]
00007a66921d2716  vmovaps xmm3, [rsp+0x30]
00007a66921d271c  vmovaps xmm4, [rsp+0x40]
00007a66921d2722  vmovaps xmm5, [rsp+0x50]
00007a66921d2728  vmovaps xmm6, [rsp+0x60]
00007a66921d272e  vmovaps xmm7, [rsp+0x70]
00007a66921d2734  vmovaps xmm8, [rsp+0x80]
00007a66921d273d  vmovaps xmm9, [rsp+0x90]
00007a66921d2746  vmovaps xmm10, [rsp+0xA0]
00007a66921d274f  vmovaps xmm12, [rsp+0xB0]
00007a66921d2758  vmovaps xmm13, [rsp+0xC0]
00007a66921d2761  vmovaps xmm14, [rsp+0xD0]
00007a66921d276a  vmovaps xmm15, [rsp+0xE0]
00007a66921d2773  add rsp, 0xF0
00007a66921d277a  pop r11
00007a66921d277c  pop r10
00007a66921d277e  pop r9
00007a66921d2780  pop r8
00007a66921d2782  pop rsi
00007a66921d2783  pop rdi
00007a66921d2784  pop rdx
00007a66921d2785  pop rcx
00007a66921d2786  pop rax
00007a66921d2787  add rsp, 0x08
00007a66921d278b  jmp 0x00007A66921CFD34
00007a66921d2790  call 0x00007A6691FFF430
00007a66921d2795  jmp 0x00007A66921CFD3E
00007a66921d279a  sub rsp, 0x08
00007a66921d279e  push rax
00007a66921d279f  push rcx
00007a66921d27a0  push rdx
00007a66921d27a1  push rdi
00007a66921d27a2  push rsi
00007a66921d27a3  push r8
00007a66921d27a5  push r9
00007a66921d27a7  push r10
00007a66921d27a9  push r11
00007a66921d27ab  sub rsp, 0xF0
00007a66921d27b2  vmovaps [rsp], xmm0
00007a66921d27b7  vmovaps [rsp+0x10], xmm1
00007a66921d27bd  vmovaps [rsp+0x20], xmm2
00007a66921d27c3  vmovaps [rsp+0x30], xmm3
00007a66921d27c9  vmovaps [rsp+0x40], xmm4
00007a66921d27cf  vmovaps [rsp+0x50], xmm5
00007a66921d27d5  vmovaps [rsp+0x60], xmm6
00007a66921d27db  vmovaps [rsp+0x70], xmm7
00007a66921d27e1  vmovaps [rsp+0x80], xmm8
00007a66921d27ea  vmovaps [rsp+0x90], xmm9
00007a66921d27f3  vmovaps [rsp+0xA0], xmm10
00007a66921d27fc  vmovaps [rsp+0xB0], xmm11
00007a66921d2805  vmovaps [rsp+0xC0], xmm12
00007a66921d280e  vmovaps [rsp+0xD0], xmm13
00007a66921d2817  vmovaps [rsp+0xE0], xmm15
00007a66921d2820  sub rsp, 0x30
00007a66921d2824  movaps [rsp], xmm14
00007a66921d2829  movaps [rsp+0x10], xmm6
00007a66921d282e  movaps [rsp+0x20], xmm2
00007a66921d2833  lea rdi, [rsp]
00007a66921d2837  mov esi, 0x00
00007a66921d283c  mov rax, 0x635346DC7530
00007a66921d2846  call rax
00007a66921d2848  movaps xmm14, [rsp]
00007a66921d284d  add rsp, 0x30
00007a66921d2851  vmovaps xmm0, [rsp]
00007a66921d2856  vmovaps xmm1, [rsp+0x10]
00007a66921d285c  vmovaps xmm2, [rsp+0x20]
00007a66921d2862  vmovaps xmm3, [rsp+0x30]
00007a66921d2868  vmovaps xmm4, [rsp+0x40]
00007a66921d286e  vmovaps xmm5, [rsp+0x50]
00007a66921d2874  vmovaps xmm6, [rsp+0x60]
00007a66921d287a  vmovaps xmm7, [rsp+0x70]
00007a66921d2880  vmovaps xmm8, [rsp+0x80]
00007a66921d2889  vmovaps xmm9, [rsp+0x90]
00007a66921d2892  vmovaps xmm10, [rsp+0xA0]
00007a66921d289b  vmovaps xmm11, [rsp+0xB0]
00007a66921d28a4  vmovaps xmm12, [rsp+0xC0]
00007a66921d28ad  vmovaps xmm13, [rsp+0xD0]
00007a66921d28b6  vmovaps xmm15, [rsp+0xE0]
00007a66921d28bf  add rsp, 0xF0
00007a66921d28c6  pop r11
00007a66921d28c8  pop r10
00007a66921d28ca  pop r9
00007a66921d28cc  pop r8
00007a66921d28ce  pop rsi
00007a66921d28cf  pop rdi
00007a66921d28d0  pop rdx
00007a66921d28d1  pop rcx
00007a66921d28d2  pop rax
00007a66921d28d3  add rsp, 0x08
00007a66921d28d7  jmp 0x00007A66921CFD72
00007a66921d28dc  sub rsp, 0x08
00007a66921d28e0  push rax
00007a66921d28e1  push rcx
00007a66921d28e2  push rdx
00007a66921d28e3  push rdi
00007a66921d28e4  push rsi
00007a66921d28e5  push r8
00007a66921d28e7  push r9
00007a66921d28e9  push r10
00007a66921d28eb  push r11
00007a66921d28ed  sub rsp, 0xF0
00007a66921d28f4  vmovaps [rsp], xmm0
00007a66921d28f9  vmovaps [rsp+0x10], xmm1
00007a66921d28ff  vmovaps [rsp+0x20], xmm2
00007a66921d2905  vmovaps [rsp+0x30], xmm3
00007a66921d290b  vmovaps [rsp+0x40], xmm4
00007a66921d2911  vmovaps [rsp+0x50], xmm5
00007a66921d2917  vmovaps [rsp+0x60], xmm7
00007a66921d291d  vmovaps [rsp+0x70], xmm8
00007a66921d2923  vmovaps [rsp+0x80], xmm9
00007a66921d292c  vmovaps [rsp+0x90], xmm10
00007a66921d2935  vmovaps [rsp+0xA0], xmm11
00007a66921d293e  vmovaps [rsp+0xB0], xmm12
00007a66921d2947  vmovaps [rsp+0xC0], xmm13
00007a66921d2950  vmovaps [rsp+0xD0], xmm14
00007a66921d2959  vmovaps [rsp+0xE0], xmm15
00007a66921d2962  sub rsp, 0x30
00007a66921d2966  movaps [rsp], xmm6
00007a66921d296a  movaps [rsp+0x10], xmm5
00007a66921d296f  movaps [rsp+0x20], xmm1
00007a66921d2974  lea rdi, [rsp]
00007a66921d2978  mov esi, 0x00
00007a66921d297d  mov rax, 0x635346DC7530
00007a66921d2987  call rax
00007a66921d2989  movaps xmm6, [rsp]
00007a66921d298d  add rsp, 0x30
00007a66921d2991  vmovaps xmm0, [rsp]
00007a66921d2996  vmovaps xmm1, [rsp+0x10]
00007a66921d299c  vmovaps xmm2, [rsp+0x20]
00007a66921d29a2  vmovaps xmm3, [rsp+0x30]
00007a66921d29a8  vmovaps xmm4, [rsp+0x40]
00007a66921d29ae  vmovaps xmm5, [rsp+0x50]
00007a66921d29b4  vmovaps xmm7, [rsp+0x60]
00007a66921d29ba  vmovaps xmm8, [rsp+0x70]
00007a66921d29c0  vmovaps xmm9, [rsp+0x80]
00007a66921d29c9  vmovaps xmm10, [rsp+0x90]
00007a66921d29d2  vmovaps xmm11, [rsp+0xA0]
00007a66921d29db  vmovaps xmm12, [rsp+0xB0]
00007a66921d29e4  vmovaps xmm13, [rsp+0xC0]
00007a66921d29ed  vmovaps xmm14, [rsp+0xD0]
00007a66921d29f6  vmovaps xmm15, [rsp+0xE0]
00007a66921d29ff  add rsp, 0xF0
00007a66921d2a06  pop r11
00007a66921d2a08  pop r10
00007a66921d2a0a  pop r9
00007a66921d2a0c  pop r8
00007a66921d2a0e  pop rsi
00007a66921d2a0f  pop rdi
00007a66921d2a10  pop rdx
00007a66921d2a11  pop rcx
00007a66921d2a12  pop rax
00007a66921d2a13  add rsp, 0x08
00007a66921d2a17  jmp 0x00007A66921CFD98
00007a66921d2a1c  sub rsp, 0x08
00007a66921d2a20  push rax
00007a66921d2a21  push rcx
00007a66921d2a22  push rdx
00007a66921d2a23  push rdi
00007a66921d2a24  push rsi
00007a66921d2a25  push r8
00007a66921d2a27  push r9
00007a66921d2a29  push r10
00007a66921d2a2b  push r11
00007a66921d2a2d  sub rsp, 0xF0
00007a66921d2a34  vmovaps [rsp], xmm0
00007a66921d2a39  vmovaps [rsp+0x10], xmm2
00007a66921d2a3f  vmovaps [rsp+0x20], xmm3
00007a66921d2a45  vmovaps [rsp+0x30], xmm4
00007a66921d2a4b  vmovaps [rsp+0x40], xmm5
00007a66921d2a51  vmovaps [rsp+0x50], xmm6
00007a66921d2a57  vmovaps [rsp+0x60], xmm7
00007a66921d2a5d  vmovaps [rsp+0x70], xmm8
00007a66921d2a63  vmovaps [rsp+0x80], xmm9
00007a66921d2a6c  vmovaps [rsp+0x90], xmm10
00007a66921d2a75  vmovaps [rsp+0xA0], xmm11
00007a66921d2a7e  vmovaps [rsp+0xB0], xmm12
00007a66921d2a87  vmovaps [rsp+0xC0], xmm13
00007a66921d2a90  vmovaps [rsp+0xD0], xmm14
00007a66921d2a99  vmovaps [rsp+0xE0], xmm15
00007a66921d2aa2  sub rsp, 0x30
00007a66921d2aa6  movaps [rsp], xmm1
00007a66921d2aaa  movaps [rsp+0x10], xmm5
00007a66921d2aaf  movaps [rsp+0x20], xmm13
00007a66921d2ab5  lea rdi, [rsp]
00007a66921d2ab9  mov esi, 0x00
00007a66921d2abe  mov rax, 0x635346DC7530
00007a66921d2ac8  call rax
00007a66921d2aca  movaps xmm1, [rsp]
00007a66921d2ace  add rsp, 0x30
00007a66921d2ad2  vmovaps xmm0, [rsp]
00007a66921d2ad7  vmovaps xmm2, [rsp+0x10]
00007a66921d2add  vmovaps xmm3, [rsp+0x20]
00007a66921d2ae3  vmovaps xmm4, [rsp+0x30]
00007a66921d2ae9  vmovaps xmm5, [rsp+0x40]
00007a66921d2aef  vmovaps xmm6, [rsp+0x50]
00007a66921d2af5  vmovaps xmm7, [rsp+0x60]
00007a66921d2afb  vmovaps xmm8, [rsp+0x70]
00007a66921d2b01  vmovaps xmm9, [rsp+0x80]
00007a66921d2b0a  vmovaps xmm10, [rsp+0x90]
00007a66921d2b13  vmovaps xmm11, [rsp+0xA0]
00007a66921d2b1c  vmovaps xmm12, [rsp+0xB0]
00007a66921d2b25  vmovaps xmm13, [rsp+0xC0]
00007a66921d2b2e  vmovaps xmm14, [rsp+0xD0]
00007a66921d2b37  vmovaps xmm15, [rsp+0xE0]
00007a66921d2b40  add rsp, 0xF0
00007a66921d2b47  pop r11
00007a66921d2b49  pop r10
00007a66921d2b4b  pop r9
00007a66921d2b4d  pop r8
00007a66921d2b4f  pop rsi
00007a66921d2b50  pop rdi
00007a66921d2b51  pop rdx
00007a66921d2b52  pop rcx
00007a66921d2b53  pop rax
00007a66921d2b54  add rsp, 0x08
00007a66921d2b58  jmp 0x00007A66921CFDB6
00007a66921d2b5d  sub rsp, 0x08
00007a66921d2b61  push rax
00007a66921d2b62  push rcx
00007a66921d2b63  push rdx
00007a66921d2b64  push rdi
00007a66921d2b65  push rsi
00007a66921d2b66  push r8
00007a66921d2b68  push r9
00007a66921d2b6a  push r10
00007a66921d2b6c  push r11
00007a66921d2b6e  sub rsp, 0xF0
00007a66921d2b75  vmovaps [rsp], xmm0
00007a66921d2b7a  vmovaps [rsp+0x10], xmm1
00007a66921d2b80  vmovaps [rsp+0x20], xmm2
00007a66921d2b86  vmovaps [rsp+0x30], xmm3
00007a66921d2b8c  vmovaps [rsp+0x40], xmm4
00007a66921d2b92  vmovaps [rsp+0x50], xmm6
00007a66921d2b98  vmovaps [rsp+0x60], xmm7
00007a66921d2b9e  vmovaps [rsp+0x70], xmm8
00007a66921d2ba4  vmovaps [rsp+0x80], xmm9
00007a66921d2bad  vmovaps [rsp+0x90], xmm10
00007a66921d2bb6  vmovaps [rsp+0xA0], xmm11
00007a66921d2bbf  vmovaps [rsp+0xB0], xmm12
00007a66921d2bc8  vmovaps [rsp+0xC0], xmm13
00007a66921d2bd1  vmovaps [rsp+0xD0], xmm14
00007a66921d2bda  vmovaps [rsp+0xE0], xmm15
00007a66921d2be3  sub rsp, 0x30
00007a66921d2be7  movaps [rsp], xmm5
00007a66921d2beb  movaps [rsp+0x10], xmm2
00007a66921d2bf0  movaps [rsp+0x20], xmm13
00007a66921d2bf6  lea rdi, [rsp]
00007a66921d2bfa  mov esi, 0x00
00007a66921d2bff  mov rax, 0x635346DC7530
00007a66921d2c09  call rax
00007a66921d2c0b  movaps xmm5, [rsp]
00007a66921d2c0f  add rsp, 0x30
00007a66921d2c13  vmovaps xmm0, [rsp]
00007a66921d2c18  vmovaps xmm1, [rsp+0x10]
00007a66921d2c1e  vmovaps xmm2, [rsp+0x20]
00007a66921d2c24  vmovaps xmm3, [rsp+0x30]
00007a66921d2c2a  vmovaps xmm4, [rsp+0x40]
00007a66921d2c30  vmovaps xmm6, [rsp+0x50]
00007a66921d2c36  vmovaps xmm7, [rsp+0x60]
00007a66921d2c3c  vmovaps xmm8, [rsp+0x70]
00007a66921d2c42  vmovaps xmm9, [rsp+0x80]
00007a66921d2c4b  vmovaps xmm10, [rsp+0x90]
00007a66921d2c54  vmovaps xmm11, [rsp+0xA0]
00007a66921d2c5d  vmovaps xmm12, [rsp+0xB0]
00007a66921d2c66  vmovaps xmm13, [rsp+0xC0]
00007a66921d2c6f  vmovaps xmm14, [rsp+0xD0]
00007a66921d2c78  vmovaps xmm15, [rsp+0xE0]
00007a66921d2c81  add rsp, 0xF0
00007a66921d2c88  pop r11
00007a66921d2c8a  pop r10
00007a66921d2c8c  pop r9
00007a66921d2c8e  pop r8
00007a66921d2c90  pop rsi
00007a66921d2c91  pop rdi
00007a66921d2c92  pop rdx
00007a66921d2c93  pop rcx
00007a66921d2c94  pop rax
00007a66921d2c95  add rsp, 0x08
00007a66921d2c99  jmp 0x00007A66921CFDEC
00007a66921d2c9e  sub rsp, 0x08
00007a66921d2ca2  push rax
00007a66921d2ca3  push rcx
00007a66921d2ca4  push rdx
00007a66921d2ca5  push rdi
00007a66921d2ca6  push rsi
00007a66921d2ca7  push r8
00007a66921d2ca9  push r9
00007a66921d2cab  push r10
00007a66921d2cad  push r11
00007a66921d2caf  sub rsp, 0xF0
00007a66921d2cb6  vmovaps [rsp], xmm0
00007a66921d2cbb  vmovaps [rsp+0x10], xmm1
00007a66921d2cc1  vmovaps [rsp+0x20], xmm2
00007a66921d2cc7  vmovaps [rsp+0x30], xmm3
00007a66921d2ccd  vmovaps [rsp+0x40], xmm4
00007a66921d2cd3  vmovaps [rsp+0x50], xmm5
00007a66921d2cd9  vmovaps [rsp+0x60], xmm6
00007a66921d2cdf  vmovaps [rsp+0x70], xmm7
00007a66921d2ce5  vmovaps [rsp+0x80], xmm8
00007a66921d2cee  vmovaps [rsp+0x90], xmm9
00007a66921d2cf7  vmovaps [rsp+0xA0], xmm10
00007a66921d2d00  vmovaps [rsp+0xB0], xmm11
00007a66921d2d09  vmovaps [rsp+0xC0], xmm12
00007a66921d2d12  vmovaps [rsp+0xD0], xmm14
00007a66921d2d1b  vmovaps [rsp+0xE0], xmm15
00007a66921d2d24  sub rsp, 0x30
00007a66921d2d28  movaps [rsp], xmm13
00007a66921d2d2d  movaps [rsp+0x10], xmm10
00007a66921d2d33  movaps [rsp+0x20], xmm1
00007a66921d2d38  lea rdi, [rsp]
00007a66921d2d3c  mov esi, 0x00
00007a66921d2d41  mov rax, 0x635346DC7530
00007a66921d2d4b  call rax
00007a66921d2d4d  movaps xmm13, [rsp]
00007a66921d2d52  add rsp, 0x30
00007a66921d2d56  vmovaps xmm0, [rsp]
00007a66921d2d5b  vmovaps xmm1, [rsp+0x10]
00007a66921d2d61  vmovaps xmm2, [rsp+0x20]
00007a66921d2d67  vmovaps xmm3, [rsp+0x30]
00007a66921d2d6d  vmovaps xmm4, [rsp+0x40]
00007a66921d2d73  vmovaps xmm5, [rsp+0x50]
00007a66921d2d79  vmovaps xmm6, [rsp+0x60]
00007a66921d2d7f  vmovaps xmm7, [rsp+0x70]
00007a66921d2d85  vmovaps xmm8, [rsp+0x80]
00007a66921d2d8e  vmovaps xmm9, [rsp+0x90]
00007a66921d2d97  vmovaps xmm10, [rsp+0xA0]
00007a66921d2da0  vmovaps xmm11, [rsp+0xB0]
00007a66921d2da9  vmovaps xmm12, [rsp+0xC0]
00007a66921d2db2  vmovaps xmm14, [rsp+0xD0]
00007a66921d2dbb  vmovaps xmm15, [rsp+0xE0]
00007a66921d2dc4  add rsp, 0xF0
00007a66921d2dcb  pop r11
00007a66921d2dcd  pop r10
00007a66921d2dcf  pop r9
00007a66921d2dd1  pop r8
00007a66921d2dd3  pop rsi
00007a66921d2dd4  pop rdi
00007a66921d2dd5  pop rdx
00007a66921d2dd6  pop rcx
00007a66921d2dd7  pop rax
00007a66921d2dd8  add rsp, 0x08
00007a66921d2ddc  jmp 0x00007A66921CFE15
00007a66921d2de1  sub rsp, 0x08
00007a66921d2de5  push rax
00007a66921d2de6  push rcx
00007a66921d2de7  push rdx
00007a66921d2de8  push rdi
00007a66921d2de9  push rsi
00007a66921d2dea  push r8
00007a66921d2dec  push r9
00007a66921d2dee  push r10
00007a66921d2df0  push r11
00007a66921d2df2  sub rsp, 0xF0
00007a66921d2df9  vmovaps [rsp], xmm0
00007a66921d2dfe  vmovaps [rsp+0x10], xmm2
00007a66921d2e04  vmovaps [rsp+0x20], xmm3
00007a66921d2e0a  vmovaps [rsp+0x30], xmm4
00007a66921d2e10  vmovaps [rsp+0x40], xmm5
00007a66921d2e16  vmovaps [rsp+0x50], xmm6
00007a66921d2e1c  vmovaps [rsp+0x60], xmm7
00007a66921d2e22  vmovaps [rsp+0x70], xmm8
00007a66921d2e28  vmovaps [rsp+0x80], xmm9
00007a66921d2e31  vmovaps [rsp+0x90], xmm10
00007a66921d2e3a  vmovaps [rsp+0xA0], xmm11
00007a66921d2e43  vmovaps [rsp+0xB0], xmm12
00007a66921d2e4c  vmovaps [rsp+0xC0], xmm13
00007a66921d2e55  vmovaps [rsp+0xD0], xmm14
00007a66921d2e5e  vmovaps [rsp+0xE0], xmm15
00007a66921d2e67  sub rsp, 0x30
00007a66921d2e6b  movaps [rsp], xmm1
00007a66921d2e6f  movaps [rsp+0x10], xmm15
00007a66921d2e75  movaps [rsp+0x20], xmm10
00007a66921d2e7b  lea rdi, [rsp]
00007a66921d2e7f  mov esi, 0x00
00007a66921d2e84  mov rax, 0x635346DC7530
00007a66921d2e8e  call rax
00007a66921d2e90  movaps xmm1, [rsp]
00007a66921d2e94  add rsp, 0x30
00007a66921d2e98  vmovaps xmm0, [rsp]
00007a66921d2e9d  vmovaps xmm2, [rsp+0x10]
00007a66921d2ea3  vmovaps xmm3, [rsp+0x20]
00007a66921d2ea9  vmovaps xmm4, [rsp+0x30]
00007a66921d2eaf  vmovaps xmm5, [rsp+0x40]
00007a66921d2eb5  vmovaps xmm6, [rsp+0x50]
00007a66921d2ebb  vmovaps xmm7, [rsp+0x60]
00007a66921d2ec1  vmovaps xmm8, [rsp+0x70]
00007a66921d2ec7  vmovaps xmm9, [rsp+0x80]
00007a66921d2ed0  vmovaps xmm10, [rsp+0x90]
00007a66921d2ed9  vmovaps xmm11, [rsp+0xA0]
00007a66921d2ee2  vmovaps xmm12, [rsp+0xB0]
00007a66921d2eeb  vmovaps xmm13, [rsp+0xC0]
00007a66921d2ef4  vmovaps xmm14, [rsp+0xD0]
00007a66921d2efd  vmovaps xmm15, [rsp+0xE0]
00007a66921d2f06  add rsp, 0xF0
00007a66921d2f0d  pop r11
00007a66921d2f0f  pop r10
00007a66921d2f11  pop r9
00007a66921d2f13  pop r8
00007a66921d2f15  pop rsi
00007a66921d2f16  pop rdi
00007a66921d2f17  pop rdx
00007a66921d2f18  pop rcx
00007a66921d2f19  pop rax
00007a66921d2f1a  add rsp, 0x08
00007a66921d2f1e  jmp 0x00007A66921CFE34
00007a66921d2f23  sub rsp, 0x08
00007a66921d2f27  push rax
00007a66921d2f28  push rcx
00007a66921d2f29  push rdx
00007a66921d2f2a  push rdi
00007a66921d2f2b  push rsi
00007a66921d2f2c  push r8
00007a66921d2f2e  push r9
00007a66921d2f30  push r10
00007a66921d2f32  push r11
00007a66921d2f34  sub rsp, 0xF0
00007a66921d2f3b  vmovaps [rsp], xmm0
00007a66921d2f40  vmovaps [rsp+0x10], xmm1
00007a66921d2f46  vmovaps [rsp+0x20], xmm2
00007a66921d2f4c  vmovaps [rsp+0x30], xmm3
00007a66921d2f52  vmovaps [rsp+0x40], xmm4
00007a66921d2f58  vmovaps [rsp+0x50], xmm5
00007a66921d2f5e  vmovaps [rsp+0x60], xmm6
00007a66921d2f64  vmovaps [rsp+0x70], xmm7
00007a66921d2f6a  vmovaps [rsp+0x80], xmm8
00007a66921d2f73  vmovaps [rsp+0x90], xmm9
00007a66921d2f7c  vmovaps [rsp+0xA0], xmm10
00007a66921d2f85  vmovaps [rsp+0xB0], xmm11
00007a66921d2f8e  vmovaps [rsp+0xC0], xmm12
00007a66921d2f97  vmovaps [rsp+0xD0], xmm13
00007a66921d2fa0  vmovaps [rsp+0xE0], xmm14
00007a66921d2fa9  sub rsp, 0x30
00007a66921d2fad  movaps [rsp], xmm15
00007a66921d2fb2  movaps [rsp+0x10], xmm10
00007a66921d2fb8  movaps [rsp+0x20], xmm11
00007a66921d2fbe  lea rdi, [rsp]
00007a66921d2fc2  mov esi, 0x00
00007a66921d2fc7  mov rax, 0x635346DC7530
00007a66921d2fd1  call rax
00007a66921d2fd3  movaps xmm15, [rsp]
00007a66921d2fd8  add rsp, 0x30
00007a66921d2fdc  vmovaps xmm0, [rsp]
00007a66921d2fe1  vmovaps xmm1, [rsp+0x10]
00007a66921d2fe7  vmovaps xmm2, [rsp+0x20]
00007a66921d2fed  vmovaps xmm3, [rsp+0x30]
00007a66921d2ff3  vmovaps xmm4, [rsp+0x40]
00007a66921d2ff9  vmovaps xmm5, [rsp+0x50]
00007a66921d2fff  vmovaps xmm6, [rsp+0x60]
00007a66921d3005  vmovaps xmm7, [rsp+0x70]
00007a66921d300b  vmovaps xmm8, [rsp+0x80]
00007a66921d3014  vmovaps xmm9, [rsp+0x90]
00007a66921d301d  vmovaps xmm10, [rsp+0xA0]
00007a66921d3026  vmovaps xmm11, [rsp+0xB0]
00007a66921d302f  vmovaps xmm12, [rsp+0xC0]
00007a66921d3038  vmovaps xmm13, [rsp+0xD0]
00007a66921d3041  vmovaps xmm14, [rsp+0xE0]
00007a66921d304a  add rsp, 0xF0
00007a66921d3051  pop r11
00007a66921d3053  pop r10
00007a66921d3055  pop r9
00007a66921d3057  pop r8
00007a66921d3059  pop rsi
00007a66921d305a  pop rdi
00007a66921d305b  pop rdx
00007a66921d305c  pop rcx
00007a66921d305d  pop rax
00007a66921d305e  add rsp, 0x08
00007a66921d3062  jmp 0x00007A66921CFE57
00007a66921d3067  sub rsp, 0x08
00007a66921d306b  push rax
00007a66921d306c  push rcx
00007a66921d306d  push rdx
00007a66921d306e  push rdi
00007a66921d306f  push rsi
00007a66921d3070  push r8
00007a66921d3072  push r9
00007a66921d3074  push r10
00007a66921d3076  push r11
00007a66921d3078  sub rsp, 0xF0
00007a66921d307f  vmovaps [rsp], xmm0
00007a66921d3084  vmovaps [rsp+0x10], xmm1
00007a66921d308a  vmovaps [rsp+0x20], xmm2
00007a66921d3090  vmovaps [rsp+0x30], xmm3
00007a66921d3096  vmovaps [rsp+0x40], xmm4
00007a66921d309c  vmovaps [rsp+0x50], xmm5
00007a66921d30a2  vmovaps [rsp+0x60], xmm6
00007a66921d30a8  vmovaps [rsp+0x70], xmm7
00007a66921d30ae  vmovaps [rsp+0x80], xmm8
00007a66921d30b7  vmovaps [rsp+0x90], xmm9
00007a66921d30c0  vmovaps [rsp+0xA0], xmm11
00007a66921d30c9  vmovaps [rsp+0xB0], xmm12
00007a66921d30d2  vmovaps [rsp+0xC0], xmm13
00007a66921d30db  vmovaps [rsp+0xD0], xmm14
00007a66921d30e4  vmovaps [rsp+0xE0], xmm15
00007a66921d30ed  sub rsp, 0x30
00007a66921d30f1  movaps [rsp], xmm10
00007a66921d30f6  movaps [rsp+0x10], xmm12
00007a66921d30fc  movaps [rsp+0x20], xmm11
00007a66921d3102  lea rdi, [rsp]
00007a66921d3106  mov esi, 0x00
00007a66921d310b  mov rax, 0x635346DC7530
00007a66921d3115  call rax
00007a66921d3117  movaps xmm10, [rsp]
00007a66921d311c  add rsp, 0x30
00007a66921d3120  vmovaps xmm0, [rsp]
00007a66921d3125  vmovaps xmm1, [rsp+0x10]
00007a66921d312b  vmovaps xmm2, [rsp+0x20]
00007a66921d3131  vmovaps xmm3, [rsp+0x30]
00007a66921d3137  vmovaps xmm4, [rsp+0x40]
00007a66921d313d  vmovaps xmm5, [rsp+0x50]
00007a66921d3143  vmovaps xmm6, [rsp+0x60]
00007a66921d3149  vmovaps xmm7, [rsp+0x70]
00007a66921d314f  vmovaps xmm8, [rsp+0x80]
00007a66921d3158  vmovaps xmm9, [rsp+0x90]
00007a66921d3161  vmovaps xmm11, [rsp+0xA0]
00007a66921d316a  vmovaps xmm12, [rsp+0xB0]
00007a66921d3173  vmovaps xmm13, [rsp+0xC0]
00007a66921d317c  vmovaps xmm14, [rsp+0xD0]
00007a66921d3185  vmovaps xmm15, [rsp+0xE0]
00007a66921d318e  add rsp, 0xF0
00007a66921d3195  pop r11
00007a66921d3197  pop r10
00007a66921d3199  pop r9
00007a66921d319b  pop r8
00007a66921d319d  pop rsi
00007a66921d319e  pop rdi
00007a66921d319f  pop rdx
00007a66921d31a0  pop rcx
00007a66921d31a1  pop rax
00007a66921d31a2  add rsp, 0x08
00007a66921d31a6  jmp 0x00007A66921CFE80
00007a66921d31ab  sub rsp, 0x08
00007a66921d31af  push rax
00007a66921d31b0  push rcx
00007a66921d31b1  push rdx
00007a66921d31b2  push rdi
00007a66921d31b3  push rsi
00007a66921d31b4  push r8
00007a66921d31b6  push r9
00007a66921d31b8  push r10
00007a66921d31ba  push r11
00007a66921d31bc  sub rsp, 0xF0
00007a66921d31c3  vmovaps [rsp], xmm0
00007a66921d31c8  vmovaps [rsp+0x10], xmm1
00007a66921d31ce  vmovaps [rsp+0x20], xmm2
00007a66921d31d4  vmovaps [rsp+0x30], xmm3
00007a66921d31da  vmovaps [rsp+0x40], xmm4
00007a66921d31e0  vmovaps [rsp+0x50], xmm5
00007a66921d31e6  vmovaps [rsp+0x60], xmm6
00007a66921d31ec  vmovaps [rsp+0x70], xmm7
00007a66921d31f2  vmovaps [rsp+0x80], xmm8
00007a66921d31fb  vmovaps [rsp+0x90], xmm9
00007a66921d3204  vmovaps [rsp+0xA0], xmm10
00007a66921d320d  vmovaps [rsp+0xB0], xmm12
00007a66921d3216  vmovaps [rsp+0xC0], xmm13
00007a66921d321f  vmovaps [rsp+0xD0], xmm14
00007a66921d3228  vmovaps [rsp+0xE0], xmm15
00007a66921d3231  sub rsp, 0x30
00007a66921d3235  movaps [rsp], xmm11
00007a66921d323a  movaps [rsp+0x10], xmm2
00007a66921d323f  movaps [rsp+0x20], xmm12
00007a66921d3245  lea rdi, [rsp]
00007a66921d3249  mov esi, 0x00
00007a66921d324e  mov rax, 0x635346DC7530
00007a66921d3258  call rax
00007a66921d325a  movaps xmm11, [rsp]
00007a66921d325f  add rsp, 0x30
00007a66921d3263  vmovaps xmm0, [rsp]
00007a66921d3268  vmovaps xmm1, [rsp+0x10]
00007a66921d326e  vmovaps xmm2, [rsp+0x20]
00007a66921d3274  vmovaps xmm3, [rsp+0x30]
00007a66921d327a  vmovaps xmm4, [rsp+0x40]
00007a66921d3280  vmovaps xmm5, [rsp+0x50]
00007a66921d3286  vmovaps xmm6, [rsp+0x60]
00007a66921d328c  vmovaps xmm7, [rsp+0x70]
00007a66921d3292  vmovaps xmm8, [rsp+0x80]
00007a66921d329b  vmovaps xmm9, [rsp+0x90]
00007a66921d32a4  vmovaps xmm10, [rsp+0xA0]
00007a66921d32ad  vmovaps xmm12, [rsp+0xB0]
00007a66921d32b6  vmovaps xmm13, [rsp+0xC0]
00007a66921d32bf  vmovaps xmm14, [rsp+0xD0]
00007a66921d32c8  vmovaps xmm15, [rsp+0xE0]
00007a66921d32d1  add rsp, 0xF0
00007a66921d32d8  pop r11
00007a66921d32da  pop r10
00007a66921d32dc  pop r9
00007a66921d32de  pop r8
00007a66921d32e0  pop rsi
00007a66921d32e1  pop rdi
00007a66921d32e2  pop rdx
00007a66921d32e3  pop rcx
00007a66921d32e4  pop rax
00007a66921d32e5  add rsp, 0x08
00007a66921d32e9  jmp 0x00007A66921CFEB8
00007a66921d32ee  sub rsp, 0x08
00007a66921d32f2  push rax
00007a66921d32f3  push rcx
00007a66921d32f4  push rdx
00007a66921d32f5  push rdi
00007a66921d32f6  push rsi
00007a66921d32f7  push r8
00007a66921d32f9  push r9
00007a66921d32fb  push r10
00007a66921d32fd  push r11
00007a66921d32ff  sub rsp, 0xF0
00007a66921d3306  vmovaps [rsp], xmm0
00007a66921d330b  vmovaps [rsp+0x10], xmm2
00007a66921d3311  vmovaps [rsp+0x20], xmm3
00007a66921d3317  vmovaps [rsp+0x30], xmm4
00007a66921d331d  vmovaps [rsp+0x40], xmm5
00007a66921d3323  vmovaps [rsp+0x50], xmm6
00007a66921d3329  vmovaps [rsp+0x60], xmm7
00007a66921d332f  vmovaps [rsp+0x70], xmm8
00007a66921d3335  vmovaps [rsp+0x80], xmm9
00007a66921d333e  vmovaps [rsp+0x90], xmm10
00007a66921d3347  vmovaps [rsp+0xA0], xmm11
00007a66921d3350  vmovaps [rsp+0xB0], xmm12
00007a66921d3359  vmovaps [rsp+0xC0], xmm13
00007a66921d3362  vmovaps [rsp+0xD0], xmm14
00007a66921d336b  vmovaps [rsp+0xE0], xmm15
00007a66921d3374  sub rsp, 0x30
00007a66921d3378  movaps [rsp], xmm1
00007a66921d337c  movaps [rsp+0x10], xmm14
00007a66921d3382  movaps [rsp+0x20], xmm6
00007a66921d3387  lea rdi, [rsp]
00007a66921d338b  mov esi, 0x00
00007a66921d3390  mov rax, 0x635346DC7530
00007a66921d339a  call rax
00007a66921d339c  movaps xmm1, [rsp]
00007a66921d33a0  add rsp, 0x30
00007a66921d33a4  vmovaps xmm0, [rsp]
00007a66921d33a9  vmovaps xmm2, [rsp+0x10]
00007a66921d33af  vmovaps xmm3, [rsp+0x20]
00007a66921d33b5  vmovaps xmm4, [rsp+0x30]
00007a66921d33bb  vmovaps xmm5, [rsp+0x40]
00007a66921d33c1  vmovaps xmm6, [rsp+0x50]
00007a66921d33c7  vmovaps xmm7, [rsp+0x60]
00007a66921d33cd  vmovaps xmm8, [rsp+0x70]
00007a66921d33d3  vmovaps xmm9, [rsp+0x80]
00007a66921d33dc  vmovaps xmm10, [rsp+0x90]
00007a66921d33e5  vmovaps xmm11, [rsp+0xA0]
00007a66921d33ee  vmovaps xmm12, [rsp+0xB0]
00007a66921d33f7  vmovaps xmm13, [rsp+0xC0]
00007a66921d3400  vmovaps xmm14, [rsp+0xD0]
00007a66921d3409  vmovaps xmm15, [rsp+0xE0]
00007a66921d3412  add rsp, 0xF0
00007a66921d3419  pop r11
00007a66921d341b  pop r10
00007a66921d341d  pop r9
00007a66921d341f  pop r8
00007a66921d3421  pop rsi
00007a66921d3422  pop rdi
00007a66921d3423  pop rdx
00007a66921d3424  pop rcx
00007a66921d3425  pop rax
00007a66921d3426  add rsp, 0x08
00007a66921d342a  jmp 0x00007A66921CFED1
00007a66921d342f  sub rsp, 0x08
00007a66921d3433  push rax
00007a66921d3434  push rcx
00007a66921d3435  push rdx
00007a66921d3436  push rdi
00007a66921d3437  push rsi
00007a66921d3438  push r8
00007a66921d343a  push r9
00007a66921d343c  push r10
00007a66921d343e  push r11
00007a66921d3440  sub rsp, 0xF0
00007a66921d3447  vmovaps [rsp], xmm0
00007a66921d344c  vmovaps [rsp+0x10], xmm1
00007a66921d3452  vmovaps [rsp+0x20], xmm2
00007a66921d3458  vmovaps [rsp+0x30], xmm3
00007a66921d345e  vmovaps [rsp+0x40], xmm4
00007a66921d3464  vmovaps [rsp+0x50], xmm5
00007a66921d346a  vmovaps [rsp+0x60], xmm6
00007a66921d3470  vmovaps [rsp+0x70], xmm7
00007a66921d3476  vmovaps [rsp+0x80], xmm8
00007a66921d347f  vmovaps [rsp+0x90], xmm9
00007a66921d3488  vmovaps [rsp+0xA0], xmm10
00007a66921d3491  vmovaps [rsp+0xB0], xmm11
00007a66921d349a  vmovaps [rsp+0xC0], xmm12
00007a66921d34a3  vmovaps [rsp+0xD0], xmm13
00007a66921d34ac  vmovaps [rsp+0xE0], xmm15
00007a66921d34b5  sub rsp, 0x30
00007a66921d34b9  movaps [rsp], xmm14
00007a66921d34be  movaps [rsp+0x10], xmm12
00007a66921d34c4  movaps [rsp+0x20], xmm5
00007a66921d34c9  lea rdi, [rsp]
00007a66921d34cd  mov esi, 0x00
00007a66921d34d2  mov rax, 0x635346DC7530
00007a66921d34dc  call rax
00007a66921d34de  movaps xmm14, [rsp]
00007a66921d34e3  add rsp, 0x30
00007a66921d34e7  vmovaps xmm0, [rsp]
00007a66921d34ec  vmovaps xmm1, [rsp+0x10]
00007a66921d34f2  vmovaps xmm2, [rsp+0x20]
00007a66921d34f8  vmovaps xmm3, [rsp+0x30]
00007a66921d34fe  vmovaps xmm4, [rsp+0x40]
00007a66921d3504  vmovaps xmm5, [rsp+0x50]
00007a66921d350a  vmovaps xmm6, [rsp+0x60]
00007a66921d3510  vmovaps xmm7, [rsp+0x70]
00007a66921d3516  vmovaps xmm8, [rsp+0x80]
00007a66921d351f  vmovaps xmm9, [rsp+0x90]
00007a66921d3528  vmovaps xmm10, [rsp+0xA0]
00007a66921d3531  vmovaps xmm11, [rsp+0xB0]
00007a66921d353a  vmovaps xmm12, [rsp+0xC0]
00007a66921d3543  vmovaps xmm13, [rsp+0xD0]
00007a66921d354c  vmovaps xmm15, [rsp+0xE0]
00007a66921d3555  add rsp, 0xF0
00007a66921d355c  pop r11
00007a66921d355e  pop r10
00007a66921d3560  pop r9
00007a66921d3562  pop r8
00007a66921d3564  pop rsi
00007a66921d3565  pop rdi
00007a66921d3566  pop rdx
00007a66921d3567  pop rcx
00007a66921d3568  pop rax
00007a66921d3569  add rsp, 0x08
00007a66921d356d  jmp 0x00007A66921CFEF1
00007a66921d3572  sub rsp, 0x08
00007a66921d3576  push rax
00007a66921d3577  push rcx
00007a66921d3578  push rdx
00007a66921d3579  push rdi
00007a66921d357a  push rsi
00007a66921d357b  push r8
00007a66921d357d  push r9
00007a66921d357f  push r10
00007a66921d3581  push r11
00007a66921d3583  sub rsp, 0xF0
00007a66921d358a  vmovaps [rsp], xmm0
00007a66921d358f  vmovaps [rsp+0x10], xmm1
00007a66921d3595  vmovaps [rsp+0x20], xmm2
00007a66921d359b  vmovaps [rsp+0x30], xmm3
00007a66921d35a1  vmovaps [rsp+0x40], xmm4
00007a66921d35a7  vmovaps [rsp+0x50], xmm5
00007a66921d35ad  vmovaps [rsp+0x60], xmm7
00007a66921d35b3  vmovaps [rsp+0x70], xmm8
00007a66921d35b9  vmovaps [rsp+0x80], xmm9
00007a66921d35c2  vmovaps [rsp+0x90], xmm10
00007a66921d35cb  vmovaps [rsp+0xA0], xmm11
00007a66921d35d4  vmovaps [rsp+0xB0], xmm12
00007a66921d35dd  vmovaps [rsp+0xC0], xmm13
00007a66921d35e6  vmovaps [rsp+0xD0], xmm14
00007a66921d35ef  vmovaps [rsp+0xE0], xmm15
00007a66921d35f8  sub rsp, 0x30
00007a66921d35fc  movaps [rsp], xmm6
00007a66921d3600  movaps [rsp+0x10], xmm9
00007a66921d3606  movaps [rsp+0x20], xmm12
00007a66921d360c  lea rdi, [rsp]
00007a66921d3610  mov esi, 0x00
00007a66921d3615  mov rax, 0x635346DC7530
00007a66921d361f  call rax
00007a66921d3621  movaps xmm6, [rsp]
00007a66921d3625  add rsp, 0x30
00007a66921d3629  vmovaps xmm0, [rsp]
00007a66921d362e  vmovaps xmm1, [rsp+0x10]
00007a66921d3634  vmovaps xmm2, [rsp+0x20]
00007a66921d363a  vmovaps xmm3, [rsp+0x30]
00007a66921d3640  vmovaps xmm4, [rsp+0x40]
00007a66921d3646  vmovaps xmm5, [rsp+0x50]
00007a66921d364c  vmovaps xmm7, [rsp+0x60]
00007a66921d3652  vmovaps xmm8, [rsp+0x70]
00007a66921d3658  vmovaps xmm9, [rsp+0x80]
00007a66921d3661  vmovaps xmm10, [rsp+0x90]
00007a66921d366a  vmovaps xmm11, [rsp+0xA0]
00007a66921d3673  vmovaps xmm12, [rsp+0xB0]
00007a66921d367c  vmovaps xmm13, [rsp+0xC0]
00007a66921d3685  vmovaps xmm14, [rsp+0xD0]
00007a66921d368e  vmovaps xmm15, [rsp+0xE0]
00007a66921d3697  add rsp, 0xF0
00007a66921d369e  pop r11
00007a66921d36a0  pop r10
00007a66921d36a2  pop r9
00007a66921d36a4  pop r8
00007a66921d36a6  pop rsi
00007a66921d36a7  pop rdi
00007a66921d36a8  pop rdx
00007a66921d36a9  pop rcx
00007a66921d36aa  pop rax
00007a66921d36ab  add rsp, 0x08
00007a66921d36af  jmp 0x00007A66921CFF19
00007a66921d36b4  sub rsp, 0x08
00007a66921d36b8  push rax
00007a66921d36b9  push rcx
00007a66921d36ba  push rdx
00007a66921d36bb  push rdi
00007a66921d36bc  push rsi
00007a66921d36bd  push r8
00007a66921d36bf  push r9
00007a66921d36c1  push r10
00007a66921d36c3  push r11
00007a66921d36c5  sub rsp, 0xF0
00007a66921d36cc  vmovaps [rsp], xmm0
00007a66921d36d1  vmovaps [rsp+0x10], xmm1
00007a66921d36d7  vmovaps [rsp+0x20], xmm2
00007a66921d36dd  vmovaps [rsp+0x30], xmm3
00007a66921d36e3  vmovaps [rsp+0x40], xmm4
00007a66921d36e9  vmovaps [rsp+0x50], xmm5
00007a66921d36ef  vmovaps [rsp+0x60], xmm6
00007a66921d36f5  vmovaps [rsp+0x70], xmm7
00007a66921d36fb  vmovaps [rsp+0x80], xmm8
00007a66921d3704  vmovaps [rsp+0x90], xmm9
00007a66921d370d  vmovaps [rsp+0xA0], xmm10
00007a66921d3716  vmovaps [rsp+0xB0], xmm11
00007a66921d371f  vmovaps [rsp+0xC0], xmm13
00007a66921d3728  vmovaps [rsp+0xD0], xmm14
00007a66921d3731  vmovaps [rsp+0xE0], xmm15
00007a66921d373a  sub rsp, 0x30
00007a66921d373e  movaps [rsp], xmm12
00007a66921d3743  movaps [rsp+0x10], xmm15
00007a66921d3749  movaps [rsp+0x20], xmm13
00007a66921d374f  lea rdi, [rsp]
00007a66921d3753  mov esi, 0x00
00007a66921d3758  mov rax, 0x635346DC7530
00007a66921d3762  call rax
00007a66921d3764  movaps xmm12, [rsp]
00007a66921d3769  add rsp, 0x30
00007a66921d376d  vmovaps xmm0, [rsp]
00007a66921d3772  vmovaps xmm1, [rsp+0x10]
00007a66921d3778  vmovaps xmm2, [rsp+0x20]
00007a66921d377e  vmovaps xmm3, [rsp+0x30]
00007a66921d3784  vmovaps xmm4, [rsp+0x40]
00007a66921d378a  vmovaps xmm5, [rsp+0x50]
00007a66921d3790  vmovaps xmm6, [rsp+0x60]
00007a66921d3796  vmovaps xmm7, [rsp+0x70]
00007a66921d379c  vmovaps xmm8, [rsp+0x80]
00007a66921d37a5  vmovaps xmm9, [rsp+0x90]
00007a66921d37ae  vmovaps xmm10, [rsp+0xA0]
00007a66921d37b7  vmovaps xmm11, [rsp+0xB0]
00007a66921d37c0  vmovaps xmm13, [rsp+0xC0]
00007a66921d37c9  vmovaps xmm14, [rsp+0xD0]
00007a66921d37d2  vmovaps xmm15, [rsp+0xE0]
00007a66921d37db  add rsp, 0xF0
00007a66921d37e2  pop r11
00007a66921d37e4  pop r10
00007a66921d37e6  pop r9
00007a66921d37e8  pop r8
00007a66921d37ea  pop rsi
00007a66921d37eb  pop rdi
00007a66921d37ec  pop rdx
00007a66921d37ed  pop rcx
00007a66921d37ee  pop rax
00007a66921d37ef  add rsp, 0x08
00007a66921d37f3  jmp 0x00007A66921CFF34
00007a66921d37f8  sub rsp, 0x08
00007a66921d37fc  push rax
00007a66921d37fd  push rcx
00007a66921d37fe  push rdx
00007a66921d37ff  push rdi
00007a66921d3800  push rsi
00007a66921d3801  push r8
00007a66921d3803  push r9
00007a66921d3805  push r10
00007a66921d3807  push r11
00007a66921d3809  sub rsp, 0xF0
00007a66921d3810  vmovaps [rsp], xmm0
00007a66921d3815  vmovaps [rsp+0x10], xmm1
00007a66921d381b  vmovaps [rsp+0x20], xmm2
00007a66921d3821  vmovaps [rsp+0x30], xmm3
00007a66921d3827  vmovaps [rsp+0x40], xmm4
00007a66921d382d  vmovaps [rsp+0x50], xmm5
00007a66921d3833  vmovaps [rsp+0x60], xmm6
00007a66921d3839  vmovaps [rsp+0x70], xmm7
00007a66921d383f  vmovaps [rsp+0x80], xmm8
00007a66921d3848  vmovaps [rsp+0x90], xmm9
00007a66921d3851  vmovaps [rsp+0xA0], xmm10
00007a66921d385a  vmovaps [rsp+0xB0], xmm11
00007a66921d3863  vmovaps [rsp+0xC0], xmm12
00007a66921d386c  vmovaps [rsp+0xD0], xmm13
00007a66921d3875  vmovaps [rsp+0xE0], xmm14
00007a66921d387e  sub rsp, 0x30
00007a66921d3882  movaps [rsp], xmm15
00007a66921d3887  movaps [rsp+0x10], xmm13
00007a66921d388d  movaps [rsp+0x20], xmm10
00007a66921d3893  lea rdi, [rsp]
00007a66921d3897  mov esi, 0x00
00007a66921d389c  mov rax, 0x635346DC7530
00007a66921d38a6  call rax
00007a66921d38a8  movaps xmm15, [rsp]
00007a66921d38ad  add rsp, 0x30
00007a66921d38b1  vmovaps xmm0, [rsp]
00007a66921d38b6  vmovaps xmm1, [rsp+0x10]
00007a66921d38bc  vmovaps xmm2, [rsp+0x20]
00007a66921d38c2  vmovaps xmm3, [rsp+0x30]
00007a66921d38c8  vmovaps xmm4, [rsp+0x40]
00007a66921d38ce  vmovaps xmm5, [rsp+0x50]
00007a66921d38d4  vmovaps xmm6, [rsp+0x60]
00007a66921d38da  vmovaps xmm7, [rsp+0x70]
00007a66921d38e0  vmovaps xmm8, [rsp+0x80]
00007a66921d38e9  vmovaps xmm9, [rsp+0x90]
00007a66921d38f2  vmovaps xmm10, [rsp+0xA0]
00007a66921d38fb  vmovaps xmm11, [rsp+0xB0]
00007a66921d3904  vmovaps xmm12, [rsp+0xC0]
00007a66921d390d  vmovaps xmm13, [rsp+0xD0]
00007a66921d3916  vmovaps xmm14, [rsp+0xE0]
00007a66921d391f  add rsp, 0xF0
00007a66921d3926  pop r11
00007a66921d3928  pop r10
00007a66921d392a  pop r9
00007a66921d392c  pop r8
00007a66921d392e  pop rsi
00007a66921d392f  pop rdi
00007a66921d3930  pop rdx
00007a66921d3931  pop rcx
00007a66921d3932  pop rax
00007a66921d3933  add rsp, 0x08
00007a66921d3937  jmp 0x00007A66921CFF55
00007a66921d393c  call 0x00007A669200C260
00007a66921d3941  jmp 0x00007A66921CFFB0
00007a66921d3946  sub rsp, 0x08
00007a66921d394a  push rax
00007a66921d394b  push rcx
00007a66921d394c  push rdx
00007a66921d394d  push rdi
00007a66921d394e  push rsi
00007a66921d394f  push r8
00007a66921d3951  push r9
00007a66921d3953  push r10
00007a66921d3955  push r11
00007a66921d3957  sub rsp, 0xF0
00007a66921d395e  vmovaps [rsp], xmm0
00007a66921d3963  vmovaps [rsp+0x10], xmm1
00007a66921d3969  vmovaps [rsp+0x20], xmm2
00007a66921d396f  vmovaps [rsp+0x30], xmm3
00007a66921d3975  vmovaps [rsp+0x40], xmm4
00007a66921d397b  vmovaps [rsp+0x50], xmm5
00007a66921d3981  vmovaps [rsp+0x60], xmm6
00007a66921d3987  vmovaps [rsp+0x70], xmm7
00007a66921d398d  vmovaps [rsp+0x80], xmm8
00007a66921d3996  vmovaps [rsp+0x90], xmm10
00007a66921d399f  vmovaps [rsp+0xA0], xmm11
00007a66921d39a8  vmovaps [rsp+0xB0], xmm12
00007a66921d39b1  vmovaps [rsp+0xC0], xmm13
00007a66921d39ba  vmovaps [rsp+0xD0], xmm14
00007a66921d39c3  vmovaps [rsp+0xE0], xmm15
00007a66921d39cc  sub rsp, 0x30
00007a66921d39d0  movaps [rsp], xmm9
00007a66921d39d5  movaps [rsp+0x10], xmm8
00007a66921d39db  movaps [rsp+0x20], xmm10
00007a66921d39e1  lea rdi, [rsp]
00007a66921d39e5  mov esi, 0x00
00007a66921d39ea  mov rax, 0x635346DC7530
00007a66921d39f4  call rax
00007a66921d39f6  movaps xmm9, [rsp]
00007a66921d39fb  add rsp, 0x30
00007a66921d39ff  vmovaps xmm0, [rsp]
00007a66921d3a04  vmovaps xmm1, [rsp+0x10]
00007a66921d3a0a  vmovaps xmm2, [rsp+0x20]
00007a66921d3a10  vmovaps xmm3, [rsp+0x30]
00007a66921d3a16  vmovaps xmm4, [rsp+0x40]
00007a66921d3a1c  vmovaps xmm5, [rsp+0x50]
00007a66921d3a22  vmovaps xmm6, [rsp+0x60]
00007a66921d3a28  vmovaps xmm7, [rsp+0x70]
00007a66921d3a2e  vmovaps xmm8, [rsp+0x80]
00007a66921d3a37  vmovaps xmm10, [rsp+0x90]
00007a66921d3a40  vmovaps xmm11, [rsp+0xA0]
00007a66921d3a49  vmovaps xmm12, [rsp+0xB0]
00007a66921d3a52  vmovaps xmm13, [rsp+0xC0]
00007a66921d3a5b  vmovaps xmm14, [rsp+0xD0]
00007a66921d3a64  vmovaps xmm15, [rsp+0xE0]
00007a66921d3a6d  add rsp, 0xF0
00007a66921d3a74  pop r11
00007a66921d3a76  pop r10
00007a66921d3a78  pop r9
00007a66921d3a7a  pop r8
00007a66921d3a7c  pop rsi
00007a66921d3a7d  pop rdi
00007a66921d3a7e  pop rdx
00007a66921d3a7f  pop rcx
00007a66921d3a80  pop rax
00007a66921d3a81  add rsp, 0x08
00007a66921d3a85  jmp 0x00007A66921CFFE1
00007a66921d3a8a  sub rsp, 0x08
00007a66921d3a8e  push rax
00007a66921d3a8f  push rcx
00007a66921d3a90  push rdx
00007a66921d3a91  push rdi
00007a66921d3a92  push rsi
00007a66921d3a93  push r8
00007a66921d3a95  push r9
00007a66921d3a97  push r10
00007a66921d3a99  push r11
00007a66921d3a9b  sub rsp, 0xF0
00007a66921d3aa2  vmovaps [rsp], xmm0
00007a66921d3aa7  vmovaps [rsp+0x10], xmm1
00007a66921d3aad  vmovaps [rsp+0x20], xmm2
00007a66921d3ab3  vmovaps [rsp+0x30], xmm3
00007a66921d3ab9  vmovaps [rsp+0x40], xmm4
00007a66921d3abf  vmovaps [rsp+0x50], xmm5
00007a66921d3ac5  vmovaps [rsp+0x60], xmm6
00007a66921d3acb  vmovaps [rsp+0x70], xmm7
00007a66921d3ad1  vmovaps [rsp+0x80], xmm8
00007a66921d3ada  vmovaps [rsp+0x90], xmm9
00007a66921d3ae3  vmovaps [rsp+0xA0], xmm11
00007a66921d3aec  vmovaps [rsp+0xB0], xmm12
00007a66921d3af5  vmovaps [rsp+0xC0], xmm13
00007a66921d3afe  vmovaps [rsp+0xD0], xmm14
00007a66921d3b07  vmovaps [rsp+0xE0], xmm15
00007a66921d3b10  sub rsp, 0x30
00007a66921d3b14  movaps [rsp], xmm10
00007a66921d3b19  movaps [rsp+0x10], xmm1
00007a66921d3b1e  movaps [rsp+0x20], xmm11
00007a66921d3b24  lea rdi, [rsp]
00007a66921d3b28  mov esi, 0x00
00007a66921d3b2d  mov rax, 0x635346DC7530
00007a66921d3b37  call rax
00007a66921d3b39  movaps xmm10, [rsp]
00007a66921d3b3e  add rsp, 0x30
00007a66921d3b42  vmovaps xmm0, [rsp]
00007a66921d3b47  vmovaps xmm1, [rsp+0x10]
00007a66921d3b4d  vmovaps xmm2, [rsp+0x20]
00007a66921d3b53  vmovaps xmm3, [rsp+0x30]
00007a66921d3b59  vmovaps xmm4, [rsp+0x40]
00007a66921d3b5f  vmovaps xmm5, [rsp+0x50]
00007a66921d3b65  vmovaps xmm6, [rsp+0x60]
00007a66921d3b6b  vmovaps xmm7, [rsp+0x70]
00007a66921d3b71  vmovaps xmm8, [rsp+0x80]
00007a66921d3b7a  vmovaps xmm9, [rsp+0x90]
00007a66921d3b83  vmovaps xmm11, [rsp+0xA0]
00007a66921d3b8c  vmovaps xmm12, [rsp+0xB0]
00007a66921d3b95  vmovaps xmm13, [rsp+0xC0]
00007a66921d3b9e  vmovaps xmm14, [rsp+0xD0]
00007a66921d3ba7  vmovaps xmm15, [rsp+0xE0]
00007a66921d3bb0  add rsp, 0xF0
00007a66921d3bb7  pop r11
00007a66921d3bb9  pop r10
00007a66921d3bbb  pop r9
00007a66921d3bbd  pop r8
00007a66921d3bbf  pop rsi
00007a66921d3bc0  pop rdi
00007a66921d3bc1  pop rdx
00007a66921d3bc2  pop rcx
00007a66921d3bc3  pop rax
00007a66921d3bc4  add rsp, 0x08
00007a66921d3bc8  jmp 0x00007A66921CFFFC
00007a66921d3bcd  sub rsp, 0x08
00007a66921d3bd1  push rax
00007a66921d3bd2  push rcx
00007a66921d3bd3  push rdx
00007a66921d3bd4  push rdi
00007a66921d3bd5  push rsi
00007a66921d3bd6  push r8
00007a66921d3bd8  push r9
00007a66921d3bda  push r10
00007a66921d3bdc  push r11
00007a66921d3bde  sub rsp, 0xF0
00007a66921d3be5  vmovaps [rsp], xmm0
00007a66921d3bea  vmovaps [rsp+0x10], xmm2
00007a66921d3bf0  vmovaps [rsp+0x20], xmm3
00007a66921d3bf6  vmovaps [rsp+0x30], xmm4
00007a66921d3bfc  vmovaps [rsp+0x40], xmm5
00007a66921d3c02  vmovaps [rsp+0x50], xmm6
00007a66921d3c08  vmovaps [rsp+0x60], xmm7
00007a66921d3c0e  vmovaps [rsp+0x70], xmm8
00007a66921d3c14  vmovaps [rsp+0x80], xmm9
00007a66921d3c1d  vmovaps [rsp+0x90], xmm10
00007a66921d3c26  vmovaps [rsp+0xA0], xmm11
00007a66921d3c2f  vmovaps [rsp+0xB0], xmm12
00007a66921d3c38  vmovaps [rsp+0xC0], xmm13
00007a66921d3c41  vmovaps [rsp+0xD0], xmm14
00007a66921d3c4a  vmovaps [rsp+0xE0], xmm15
00007a66921d3c53  sub rsp, 0x30
00007a66921d3c57  movaps [rsp], xmm1
00007a66921d3c5b  movaps [rsp+0x10], xmm14
00007a66921d3c61  movaps [rsp+0x20], xmm6
00007a66921d3c66  lea rdi, [rsp]
00007a66921d3c6a  mov esi, 0x00
00007a66921d3c6f  mov rax, 0x635346DC7530
00007a66921d3c79  call rax
00007a66921d3c7b  movaps xmm1, [rsp]
00007a66921d3c7f  add rsp, 0x30
00007a66921d3c83  vmovaps xmm0, [rsp]
00007a66921d3c88  vmovaps xmm2, [rsp+0x10]
00007a66921d3c8e  vmovaps xmm3, [rsp+0x20]
00007a66921d3c94  vmovaps xmm4, [rsp+0x30]
00007a66921d3c9a  vmovaps xmm5, [rsp+0x40]
00007a66921d3ca0  vmovaps xmm6, [rsp+0x50]
00007a66921d3ca6  vmovaps xmm7, [rsp+0x60]
00007a66921d3cac  vmovaps xmm8, [rsp+0x70]
00007a66921d3cb2  vmovaps xmm9, [rsp+0x80]
00007a66921d3cbb  vmovaps xmm10, [rsp+0x90]
00007a66921d3cc4  vmovaps xmm11, [rsp+0xA0]
00007a66921d3ccd  vmovaps xmm12, [rsp+0xB0]
00007a66921d3cd6  vmovaps xmm13, [rsp+0xC0]
00007a66921d3cdf  vmovaps xmm14, [rsp+0xD0]
00007a66921d3ce8  vmovaps xmm15, [rsp+0xE0]
00007a66921d3cf1  add rsp, 0xF0
00007a66921d3cf8  pop r11
00007a66921d3cfa  pop r10
00007a66921d3cfc  pop r9
00007a66921d3cfe  pop r8
00007a66921d3d00  pop rsi
00007a66921d3d01  pop rdi
00007a66921d3d02  pop rdx
00007a66921d3d03  pop rcx
00007a66921d3d04  pop rax
00007a66921d3d05  add rsp, 0x08
00007a66921d3d09  jmp 0x00007A66921D0015
00007a66921d3d0e  sub rsp, 0x08
00007a66921d3d12  push rax
00007a66921d3d13  push rcx
00007a66921d3d14  push rdx
00007a66921d3d15  push rdi
00007a66921d3d16  push rsi
00007a66921d3d17  push r8
00007a66921d3d19  push r9
00007a66921d3d1b  push r10
00007a66921d3d1d  push r11
00007a66921d3d1f  sub rsp, 0xF0
00007a66921d3d26  vmovaps [rsp], xmm0
00007a66921d3d2b  vmovaps [rsp+0x10], xmm1
00007a66921d3d31  vmovaps [rsp+0x20], xmm2
00007a66921d3d37  vmovaps [rsp+0x30], xmm3
00007a66921d3d3d  vmovaps [rsp+0x40], xmm4
00007a66921d3d43  vmovaps [rsp+0x50], xmm5
00007a66921d3d49  vmovaps [rsp+0x60], xmm6
00007a66921d3d4f  vmovaps [rsp+0x70], xmm7
00007a66921d3d55  vmovaps [rsp+0x80], xmm8
00007a66921d3d5e  vmovaps [rsp+0x90], xmm9
00007a66921d3d67  vmovaps [rsp+0xA0], xmm10
00007a66921d3d70  vmovaps [rsp+0xB0], xmm12
00007a66921d3d79  vmovaps [rsp+0xC0], xmm13
00007a66921d3d82  vmovaps [rsp+0xD0], xmm14
00007a66921d3d8b  vmovaps [rsp+0xE0], xmm15
00007a66921d3d94  sub rsp, 0x30
00007a66921d3d98  movaps [rsp], xmm11
00007a66921d3d9d  movaps [rsp+0x10], xmm13
00007a66921d3da3  movaps [rsp+0x20], xmm14
00007a66921d3da9  lea rdi, [rsp]
00007a66921d3dad  mov esi, 0x00
00007a66921d3db2  mov rax, 0x635346DC7530
00007a66921d3dbc  call rax
00007a66921d3dbe  movaps xmm11, [rsp]
00007a66921d3dc3  add rsp, 0x30
00007a66921d3dc7  vmovaps xmm0, [rsp]
00007a66921d3dcc  vmovaps xmm1, [rsp+0x10]
00007a66921d3dd2  vmovaps xmm2, [rsp+0x20]
00007a66921d3dd8  vmovaps xmm3, [rsp+0x30]
00007a66921d3dde  vmovaps xmm4, [rsp+0x40]
00007a66921d3de4  vmovaps xmm5, [rsp+0x50]
00007a66921d3dea  vmovaps xmm6, [rsp+0x60]
00007a66921d3df0  vmovaps xmm7, [rsp+0x70]
00007a66921d3df6  vmovaps xmm8, [rsp+0x80]
00007a66921d3dff  vmovaps xmm9, [rsp+0x90]
00007a66921d3e08  vmovaps xmm10, [rsp+0xA0]
00007a66921d3e11  vmovaps xmm12, [rsp+0xB0]
00007a66921d3e1a  vmovaps xmm13, [rsp+0xC0]
00007a66921d3e23  vmovaps xmm14, [rsp+0xD0]
00007a66921d3e2c  vmovaps xmm15, [rsp+0xE0]
00007a66921d3e35  add rsp, 0xF0
00007a66921d3e3c  pop r11
00007a66921d3e3e  pop r10
00007a66921d3e40  pop r9
00007a66921d3e42  pop r8
00007a66921d3e44  pop rsi
00007a66921d3e45  pop rdi
00007a66921d3e46  pop rdx
00007a66921d3e47  pop rcx
00007a66921d3e48  pop rax
00007a66921d3e49  add rsp, 0x08
00007a66921d3e4d  jmp 0x00007A66921D003F
00007a66921d3e52  sub rsp, 0x08
00007a66921d3e56  push rax
00007a66921d3e57  push rcx
00007a66921d3e58  push rdx
00007a66921d3e59  push rdi
00007a66921d3e5a  push rsi
00007a66921d3e5b  push r8
00007a66921d3e5d  push r9
00007a66921d3e5f  push r10
00007a66921d3e61  push r11
00007a66921d3e63  sub rsp, 0xF0
00007a66921d3e6a  vmovaps [rsp], xmm0
00007a66921d3e6f  vmovaps [rsp+0x10], xmm1
00007a66921d3e75  vmovaps [rsp+0x20], xmm2
00007a66921d3e7b  vmovaps [rsp+0x30], xmm3
00007a66921d3e81  vmovaps [rsp+0x40], xmm4
00007a66921d3e87  vmovaps [rsp+0x50], xmm5
00007a66921d3e8d  vmovaps [rsp+0x60], xmm6
00007a66921d3e93  vmovaps [rsp+0x70], xmm7
00007a66921d3e99  vmovaps [rsp+0x80], xmm8
00007a66921d3ea2  vmovaps [rsp+0x90], xmm9
00007a66921d3eab  vmovaps [rsp+0xA0], xmm10
00007a66921d3eb4  vmovaps [rsp+0xB0], xmm11
00007a66921d3ebd  vmovaps [rsp+0xC0], xmm12
00007a66921d3ec6  vmovaps [rsp+0xD0], xmm14
00007a66921d3ecf  vmovaps [rsp+0xE0], xmm15
00007a66921d3ed8  sub rsp, 0x30
00007a66921d3edc  movaps [rsp], xmm13
00007a66921d3ee1  movaps [rsp+0x10], xmm8
00007a66921d3ee7  movaps [rsp+0x20], xmm14
00007a66921d3eed  lea rdi, [rsp]
00007a66921d3ef1  mov esi, 0x00
00007a66921d3ef6  mov rax, 0x635346DC7530
00007a66921d3f00  call rax
00007a66921d3f02  movaps xmm13, [rsp]
00007a66921d3f07  add rsp, 0x30
00007a66921d3f0b  vmovaps xmm0, [rsp]
00007a66921d3f10  vmovaps xmm1, [rsp+0x10]
00007a66921d3f16  vmovaps xmm2, [rsp+0x20]
00007a66921d3f1c  vmovaps xmm3, [rsp+0x30]
00007a66921d3f22  vmovaps xmm4, [rsp+0x40]
00007a66921d3f28  vmovaps xmm5, [rsp+0x50]
00007a66921d3f2e  vmovaps xmm6, [rsp+0x60]
00007a66921d3f34  vmovaps xmm7, [rsp+0x70]
00007a66921d3f3a  vmovaps xmm8, [rsp+0x80]
00007a66921d3f43  vmovaps xmm9, [rsp+0x90]
00007a66921d3f4c  vmovaps xmm10, [rsp+0xA0]
00007a66921d3f55  vmovaps xmm11, [rsp+0xB0]
00007a66921d3f5e  vmovaps xmm12, [rsp+0xC0]
00007a66921d3f67  vmovaps xmm14, [rsp+0xD0]
00007a66921d3f70  vmovaps xmm15, [rsp+0xE0]
00007a66921d3f79  add rsp, 0xF0
00007a66921d3f80  pop r11
00007a66921d3f82  pop r10
00007a66921d3f84  pop r9
00007a66921d3f86  pop r8
00007a66921d3f88  pop rsi
00007a66921d3f89  pop rdi
00007a66921d3f8a  pop rdx
00007a66921d3f8b  pop rcx
00007a66921d3f8c  pop rax
00007a66921d3f8d  add rsp, 0x08
00007a66921d3f91  jmp 0x00007A66921D006E
00007a66921d3f96  sub rsp, 0x08
00007a66921d3f9a  push rax
00007a66921d3f9b  push rcx
00007a66921d3f9c  push rdx
00007a66921d3f9d  push rdi
00007a66921d3f9e  push rsi
00007a66921d3f9f  push r8
00007a66921d3fa1  push r9
00007a66921d3fa3  push r10
00007a66921d3fa5  push r11
00007a66921d3fa7  sub rsp, 0xF0
00007a66921d3fae  vmovaps [rsp], xmm0
00007a66921d3fb3  vmovaps [rsp+0x10], xmm1
00007a66921d3fb9  vmovaps [rsp+0x20], xmm2
00007a66921d3fbf  vmovaps [rsp+0x30], xmm3
00007a66921d3fc5  vmovaps [rsp+0x40], xmm4
00007a66921d3fcb  vmovaps [rsp+0x50], xmm5
00007a66921d3fd1  vmovaps [rsp+0x60], xmm6
00007a66921d3fd7  vmovaps [rsp+0x70], xmm7
00007a66921d3fdd  vmovaps [rsp+0x80], xmm9
00007a66921d3fe6  vmovaps [rsp+0x90], xmm10
00007a66921d3fef  vmovaps [rsp+0xA0], xmm11
00007a66921d3ff8  vmovaps [rsp+0xB0], xmm12
00007a66921d4001  vmovaps [rsp+0xC0], xmm13
00007a66921d400a  vmovaps [rsp+0xD0], xmm14
00007a66921d4013  vmovaps [rsp+0xE0], xmm15
00007a66921d401c  sub rsp, 0x30
00007a66921d4020  movaps [rsp], xmm8
00007a66921d4025  movaps [rsp+0x10], xmm7
00007a66921d402a  movaps [rsp+0x20], xmm14
00007a66921d4030  lea rdi, [rsp]
00007a66921d4034  mov esi, 0x00
00007a66921d4039  mov rax, 0x635346DC7530
00007a66921d4043  call rax
00007a66921d4045  movaps xmm8, [rsp]
00007a66921d404a  add rsp, 0x30
00007a66921d404e  vmovaps xmm0, [rsp]
00007a66921d4053  vmovaps xmm1, [rsp+0x10]
00007a66921d4059  vmovaps xmm2, [rsp+0x20]
00007a66921d405f  vmovaps xmm3, [rsp+0x30]
00007a66921d4065  vmovaps xmm4, [rsp+0x40]
00007a66921d406b  vmovaps xmm5, [rsp+0x50]
00007a66921d4071  vmovaps xmm6, [rsp+0x60]
00007a66921d4077  vmovaps xmm7, [rsp+0x70]
00007a66921d407d  vmovaps xmm9, [rsp+0x80]
00007a66921d4086  vmovaps xmm10, [rsp+0x90]
00007a66921d408f  vmovaps xmm11, [rsp+0xA0]
00007a66921d4098  vmovaps xmm12, [rsp+0xB0]
00007a66921d40a1  vmovaps xmm13, [rsp+0xC0]
00007a66921d40aa  vmovaps xmm14, [rsp+0xD0]
00007a66921d40b3  vmovaps xmm15, [rsp+0xE0]
00007a66921d40bc  add rsp, 0xF0
00007a66921d40c3  pop r11
00007a66921d40c5  pop r10
00007a66921d40c7  pop r9
00007a66921d40c9  pop r8
00007a66921d40cb  pop rsi
00007a66921d40cc  pop rdi
00007a66921d40cd  pop rdx
00007a66921d40ce  pop rcx
00007a66921d40cf  pop rax
00007a66921d40d0  add rsp, 0x08
00007a66921d40d4  jmp 0x00007A66921D0094
00007a66921d40d9  sub rsp, 0x08
00007a66921d40dd  push rax
00007a66921d40de  push rcx
00007a66921d40df  push rdx
00007a66921d40e0  push rdi
00007a66921d40e1  push rsi
00007a66921d40e2  push r8
00007a66921d40e4  push r9
00007a66921d40e6  push r10
00007a66921d40e8  push r11
00007a66921d40ea  sub rsp, 0xF0
00007a66921d40f1  vmovaps [rsp], xmm0
00007a66921d40f6  vmovaps [rsp+0x10], xmm1
00007a66921d40fc  vmovaps [rsp+0x20], xmm2
00007a66921d4102  vmovaps [rsp+0x30], xmm3
00007a66921d4108  vmovaps [rsp+0x40], xmm4
00007a66921d410e  vmovaps [rsp+0x50], xmm5
00007a66921d4114  vmovaps [rsp+0x60], xmm6
00007a66921d411a  vmovaps [rsp+0x70], xmm7
00007a66921d4120  vmovaps [rsp+0x80], xmm8
00007a66921d4129  vmovaps [rsp+0x90], xmm9
00007a66921d4132  vmovaps [rsp+0xA0], xmm10
00007a66921d413b  vmovaps [rsp+0xB0], xmm11
00007a66921d4144  vmovaps [rsp+0xC0], xmm12
00007a66921d414d  vmovaps [rsp+0xD0], xmm13
00007a66921d4156  vmovaps [rsp+0xE0], xmm15
00007a66921d415f  sub rsp, 0x30
00007a66921d4163  movaps [rsp], xmm14
00007a66921d4168  movaps [rsp+0x10], xmm12
00007a66921d416e  movaps [rsp+0x20], xmm9
00007a66921d4174  lea rdi, [rsp]
00007a66921d4178  mov esi, 0x00
00007a66921d417d  mov rax, 0x635346DC7530
00007a66921d4187  call rax
00007a66921d4189  movaps xmm14, [rsp]
00007a66921d418e  add rsp, 0x30
00007a66921d4192  vmovaps xmm0, [rsp]
00007a66921d4197  vmovaps xmm1, [rsp+0x10]
00007a66921d419d  vmovaps xmm2, [rsp+0x20]
00007a66921d41a3  vmovaps xmm3, [rsp+0x30]
00007a66921d41a9  vmovaps xmm4, [rsp+0x40]
00007a66921d41af  vmovaps xmm5, [rsp+0x50]
00007a66921d41b5  vmovaps xmm6, [rsp+0x60]
00007a66921d41bb  vmovaps xmm7, [rsp+0x70]
00007a66921d41c1  vmovaps xmm8, [rsp+0x80]
00007a66921d41ca  vmovaps xmm9, [rsp+0x90]
00007a66921d41d3  vmovaps xmm10, [rsp+0xA0]
00007a66921d41dc  vmovaps xmm11, [rsp+0xB0]
00007a66921d41e5  vmovaps xmm12, [rsp+0xC0]
00007a66921d41ee  vmovaps xmm13, [rsp+0xD0]
00007a66921d41f7  vmovaps xmm15, [rsp+0xE0]
00007a66921d4200  add rsp, 0xF0
00007a66921d4207  pop r11
00007a66921d4209  pop r10
00007a66921d420b  pop r9
00007a66921d420d  pop r8
00007a66921d420f  pop rsi
00007a66921d4210  pop rdi
00007a66921d4211  pop rdx
00007a66921d4212  pop rcx
00007a66921d4213  pop rax
00007a66921d4214  add rsp, 0x08
00007a66921d4218  jmp 0x00007A66921D00AE
00007a66921d421d  sub rsp, 0x08
00007a66921d4221  push rax
00007a66921d4222  push rcx
00007a66921d4223  push rdx
00007a66921d4224  push rdi
00007a66921d4225  push rsi
00007a66921d4226  push r8
00007a66921d4228  push r9
00007a66921d422a  push r10
00007a66921d422c  push r11
00007a66921d422e  sub rsp, 0xF0
00007a66921d4235  vmovaps [rsp], xmm0
00007a66921d423a  vmovaps [rsp+0x10], xmm1
00007a66921d4240  vmovaps [rsp+0x20], xmm2
00007a66921d4246  vmovaps [rsp+0x30], xmm3
00007a66921d424c  vmovaps [rsp+0x40], xmm4
00007a66921d4252  vmovaps [rsp+0x50], xmm5
00007a66921d4258  vmovaps [rsp+0x60], xmm6
00007a66921d425e  vmovaps [rsp+0x70], xmm7
00007a66921d4264  vmovaps [rsp+0x80], xmm8
00007a66921d426d  vmovaps [rsp+0x90], xmm10
00007a66921d4276  vmovaps [rsp+0xA0], xmm11
00007a66921d427f  vmovaps [rsp+0xB0], xmm12
00007a66921d4288  vmovaps [rsp+0xC0], xmm13
00007a66921d4291  vmovaps [rsp+0xD0], xmm14
00007a66921d429a  vmovaps [rsp+0xE0], xmm15
00007a66921d42a3  sub rsp, 0x30
00007a66921d42a7  movaps [rsp], xmm9
00007a66921d42ac  movaps [rsp+0x10], xmm7
00007a66921d42b1  movaps [rsp+0x20], xmm12
00007a66921d42b7  lea rdi, [rsp]
00007a66921d42bb  mov esi, 0x00
00007a66921d42c0  mov rax, 0x635346DC7530
00007a66921d42ca  call rax
00007a66921d42cc  movaps xmm9, [rsp]
00007a66921d42d1  add rsp, 0x30
00007a66921d42d5  vmovaps xmm0, [rsp]
00007a66921d42da  vmovaps xmm1, [rsp+0x10]
00007a66921d42e0  vmovaps xmm2, [rsp+0x20]
00007a66921d42e6  vmovaps xmm3, [rsp+0x30]
00007a66921d42ec  vmovaps xmm4, [rsp+0x40]
00007a66921d42f2  vmovaps xmm5, [rsp+0x50]
00007a66921d42f8  vmovaps xmm6, [rsp+0x60]
00007a66921d42fe  vmovaps xmm7, [rsp+0x70]
00007a66921d4304  vmovaps xmm8, [rsp+0x80]
00007a66921d430d  vmovaps xmm10, [rsp+0x90]
00007a66921d4316  vmovaps xmm11, [rsp+0xA0]
00007a66921d431f  vmovaps xmm12, [rsp+0xB0]
00007a66921d4328  vmovaps xmm13, [rsp+0xC0]
00007a66921d4331  vmovaps xmm14, [rsp+0xD0]
00007a66921d433a  vmovaps xmm15, [rsp+0xE0]
00007a66921d4343  add rsp, 0xF0
00007a66921d434a  pop r11
00007a66921d434c  pop r10
00007a66921d434e  pop r9
00007a66921d4350  pop r8
00007a66921d4352  pop rsi
00007a66921d4353  pop rdi
00007a66921d4354  pop rdx
00007a66921d4355  pop rcx
00007a66921d4356  pop rax
00007a66921d4357  add rsp, 0x08
00007a66921d435b  jmp 0x00007A66921D00DD
00007a66921d4360  sub rsp, 0x08
00007a66921d4364  push rax
00007a66921d4365  push rcx
00007a66921d4366  push rdx
00007a66921d4367  push rdi
00007a66921d4368  push rsi
00007a66921d4369  push r8
00007a66921d436b  push r9
00007a66921d436d  push r10
00007a66921d436f  push r11
00007a66921d4371  sub rsp, 0xF0
00007a66921d4378  vmovaps [rsp], xmm0
00007a66921d437d  vmovaps [rsp+0x10], xmm1
00007a66921d4383  vmovaps [rsp+0x20], xmm2
00007a66921d4389  vmovaps [rsp+0x30], xmm3
00007a66921d438f  vmovaps [rsp+0x40], xmm4
00007a66921d4395  vmovaps [rsp+0x50], xmm5
00007a66921d439b  vmovaps [rsp+0x60], xmm6
00007a66921d43a1  vmovaps [rsp+0x70], xmm7
00007a66921d43a7  vmovaps [rsp+0x80], xmm8
00007a66921d43b0  vmovaps [rsp+0x90], xmm9
00007a66921d43b9  vmovaps [rsp+0xA0], xmm10
00007a66921d43c2  vmovaps [rsp+0xB0], xmm11
00007a66921d43cb  vmovaps [rsp+0xC0], xmm13
00007a66921d43d4  vmovaps [rsp+0xD0], xmm14
00007a66921d43dd  vmovaps [rsp+0xE0], xmm15
00007a66921d43e6  sub rsp, 0x30
00007a66921d43ea  movaps [rsp], xmm12
00007a66921d43ef  movaps [rsp+0x10], xmm15
00007a66921d43f5  movaps [rsp+0x20], xmm11
00007a66921d43fb  lea rdi, [rsp]
00007a66921d43ff  mov esi, 0x00
00007a66921d4404  mov rax, 0x635346DC7530
00007a66921d440e  call rax
00007a66921d4410  movaps xmm12, [rsp]
00007a66921d4415  add rsp, 0x30
00007a66921d4419  vmovaps xmm0, [rsp]
00007a66921d441e  vmovaps xmm1, [rsp+0x10]
00007a66921d4424  vmovaps xmm2, [rsp+0x20]
00007a66921d442a  vmovaps xmm3, [rsp+0x30]
00007a66921d4430  vmovaps xmm4, [rsp+0x40]
00007a66921d4436  vmovaps xmm5, [rsp+0x50]
00007a66921d443c  vmovaps xmm6, [rsp+0x60]
00007a66921d4442  vmovaps xmm7, [rsp+0x70]
00007a66921d4448  vmovaps xmm8, [rsp+0x80]
00007a66921d4451  vmovaps xmm9, [rsp+0x90]
00007a66921d445a  vmovaps xmm10, [rsp+0xA0]
00007a66921d4463  vmovaps xmm11, [rsp+0xB0]
00007a66921d446c  vmovaps xmm13, [rsp+0xC0]
00007a66921d4475  vmovaps xmm14, [rsp+0xD0]
00007a66921d447e  vmovaps xmm15, [rsp+0xE0]
00007a66921d4487  add rsp, 0xF0
00007a66921d448e  pop r11
00007a66921d4490  pop r10
00007a66921d4492  pop r9
00007a66921d4494  pop r8
00007a66921d4496  pop rsi
00007a66921d4497  pop rdi
00007a66921d4498  pop rdx
00007a66921d4499  pop rcx
00007a66921d449a  pop rax
00007a66921d449b  add rsp, 0x08
00007a66921d449f  jmp 0x00007A66921D00F7
00007a66921d44a4  sub rsp, 0x08
00007a66921d44a8  push rax
00007a66921d44a9  push rcx
00007a66921d44aa  push rdx
00007a66921d44ab  push rdi
00007a66921d44ac  push rsi
00007a66921d44ad  push r8
00007a66921d44af  push r9
00007a66921d44b1  push r10
00007a66921d44b3  push r11
00007a66921d44b5  sub rsp, 0xF0
00007a66921d44bc  vmovaps [rsp], xmm0
00007a66921d44c1  vmovaps [rsp+0x10], xmm1
00007a66921d44c7  vmovaps [rsp+0x20], xmm2
00007a66921d44cd  vmovaps [rsp+0x30], xmm3
00007a66921d44d3  vmovaps [rsp+0x40], xmm4
00007a66921d44d9  vmovaps [rsp+0x50], xmm5
00007a66921d44df  vmovaps [rsp+0x60], xmm6
00007a66921d44e5  vmovaps [rsp+0x70], xmm7
00007a66921d44eb  vmovaps [rsp+0x80], xmm8
00007a66921d44f4  vmovaps [rsp+0x90], xmm9
00007a66921d44fd  vmovaps [rsp+0xA0], xmm10
00007a66921d4506  vmovaps [rsp+0xB0], xmm12
00007a66921d450f  vmovaps [rsp+0xC0], xmm13
00007a66921d4518  vmovaps [rsp+0xD0], xmm14
00007a66921d4521  vmovaps [rsp+0xE0], xmm15
00007a66921d452a  sub rsp, 0x30
00007a66921d452e  movaps [rsp], xmm11
00007a66921d4533  movaps [rsp+0x10], xmm7
00007a66921d4538  movaps [rsp+0x20], xmm15
00007a66921d453e  lea rdi, [rsp]
00007a66921d4542  mov esi, 0x00
00007a66921d4547  mov rax, 0x635346DC7530
00007a66921d4551  call rax
00007a66921d4553  movaps xmm11, [rsp]
00007a66921d4558  add rsp, 0x30
00007a66921d455c  vmovaps xmm0, [rsp]
00007a66921d4561  vmovaps xmm1, [rsp+0x10]
00007a66921d4567  vmovaps xmm2, [rsp+0x20]
00007a66921d456d  vmovaps xmm3, [rsp+0x30]
00007a66921d4573  vmovaps xmm4, [rsp+0x40]
00007a66921d4579  vmovaps xmm5, [rsp+0x50]
00007a66921d457f  vmovaps xmm6, [rsp+0x60]
00007a66921d4585  vmovaps xmm7, [rsp+0x70]
00007a66921d458b  vmovaps xmm8, [rsp+0x80]
00007a66921d4594  vmovaps xmm9, [rsp+0x90]
00007a66921d459d  vmovaps xmm10, [rsp+0xA0]
00007a66921d45a6  vmovaps xmm12, [rsp+0xB0]
00007a66921d45af  vmovaps xmm13, [rsp+0xC0]
00007a66921d45b8  vmovaps xmm14, [rsp+0xD0]
00007a66921d45c1  vmovaps xmm15, [rsp+0xE0]
00007a66921d45ca  add rsp, 0xF0
00007a66921d45d1  pop r11
00007a66921d45d3  pop r10
00007a66921d45d5  pop r9
00007a66921d45d7  pop r8
00007a66921d45d9  pop rsi
00007a66921d45da  pop rdi
00007a66921d45db  pop rdx
00007a66921d45dc  pop rcx
00007a66921d45dd  pop rax
00007a66921d45de  add rsp, 0x08
00007a66921d45e2  jmp 0x00007A66921D0123
00007a66921d45e7  sub rsp, 0x08
00007a66921d45eb  push rax
00007a66921d45ec  push rcx
00007a66921d45ed  push rdx
00007a66921d45ee  push rdi
00007a66921d45ef  push rsi
00007a66921d45f0  push r8
00007a66921d45f2  push r9
00007a66921d45f4  push r10
00007a66921d45f6  push r11
00007a66921d45f8  sub rsp, 0xF0
00007a66921d45ff  vmovaps [rsp], xmm0
00007a66921d4604  vmovaps [rsp+0x10], xmm1
00007a66921d460a  vmovaps [rsp+0x20], xmm2
00007a66921d4610  vmovaps [rsp+0x30], xmm3
00007a66921d4616  vmovaps [rsp+0x40], xmm4
00007a66921d461c  vmovaps [rsp+0x50], xmm5
00007a66921d4622  vmovaps [rsp+0x60], xmm6
00007a66921d4628  vmovaps [rsp+0x70], xmm7
00007a66921d462e  vmovaps [rsp+0x80], xmm8
00007a66921d4637  vmovaps [rsp+0x90], xmm9
00007a66921d4640  vmovaps [rsp+0xA0], xmm10
00007a66921d4649  vmovaps [rsp+0xB0], xmm11
00007a66921d4652  vmovaps [rsp+0xC0], xmm12
00007a66921d465b  vmovaps [rsp+0xD0], xmm13
00007a66921d4664  vmovaps [rsp+0xE0], xmm14
00007a66921d466d  sub rsp, 0x30
00007a66921d4671  movaps [rsp], xmm15
00007a66921d4676  movaps [rsp+0x10], xmm10
00007a66921d467c  movaps [rsp+0x20], xmm13
00007a66921d4682  lea rdi, [rsp]
00007a66921d4686  mov esi, 0x00
00007a66921d468b  mov rax, 0x635346DC7530
00007a66921d4695  call rax
00007a66921d4697  movaps xmm15, [rsp]
00007a66921d469c  add rsp, 0x30
00007a66921d46a0  vmovaps xmm0, [rsp]
00007a66921d46a5  vmovaps xmm1, [rsp+0x10]
00007a66921d46ab  vmovaps xmm2, [rsp+0x20]
00007a66921d46b1  vmovaps xmm3, [rsp+0x30]
00007a66921d46b7  vmovaps xmm4, [rsp+0x40]
00007a66921d46bd  vmovaps xmm5, [rsp+0x50]
00007a66921d46c3  vmovaps xmm6, [rsp+0x60]
00007a66921d46c9  vmovaps xmm7, [rsp+0x70]
00007a66921d46cf  vmovaps xmm8, [rsp+0x80]
00007a66921d46d8  vmovaps xmm9, [rsp+0x90]
00007a66921d46e1  vmovaps xmm10, [rsp+0xA0]
00007a66921d46ea  vmovaps xmm11, [rsp+0xB0]
00007a66921d46f3  vmovaps xmm12, [rsp+0xC0]
00007a66921d46fc  vmovaps xmm13, [rsp+0xD0]
00007a66921d4705  vmovaps xmm14, [rsp+0xE0]
00007a66921d470e  add rsp, 0xF0
00007a66921d4715  pop r11
00007a66921d4717  pop r10
00007a66921d4719  pop r9
00007a66921d471b  pop r8
00007a66921d471d  pop rsi
00007a66921d471e  pop rdi
00007a66921d471f  pop rdx
00007a66921d4720  pop rcx
00007a66921d4721  pop rax
00007a66921d4722  add rsp, 0x08
00007a66921d4726  jmp 0x00007A66921D013D
00007a66921d472b  sub rsp, 0x08
00007a66921d472f  push rax
00007a66921d4730  push rcx
00007a66921d4731  push rdx
00007a66921d4732  push rdi
00007a66921d4733  push rsi
00007a66921d4734  push r8
00007a66921d4736  push r9
00007a66921d4738  push r10
00007a66921d473a  push r11
00007a66921d473c  sub rsp, 0xF0
00007a66921d4743  vmovaps [rsp], xmm0
00007a66921d4748  vmovaps [rsp+0x10], xmm1
00007a66921d474e  vmovaps [rsp+0x20], xmm2
00007a66921d4754  vmovaps [rsp+0x30], xmm3
00007a66921d475a  vmovaps [rsp+0x40], xmm4
00007a66921d4760  vmovaps [rsp+0x50], xmm5
00007a66921d4766  vmovaps [rsp+0x60], xmm6
00007a66921d476c  vmovaps [rsp+0x70], xmm7
00007a66921d4772  vmovaps [rsp+0x80], xmm8
00007a66921d477b  vmovaps [rsp+0x90], xmm9
00007a66921d4784  vmovaps [rsp+0xA0], xmm11
00007a66921d478d  vmovaps [rsp+0xB0], xmm12
00007a66921d4796  vmovaps [rsp+0xC0], xmm13
00007a66921d479f  vmovaps [rsp+0xD0], xmm14
00007a66921d47a8  vmovaps [rsp+0xE0], xmm15
00007a66921d47b1  sub rsp, 0x30
00007a66921d47b5  movaps [rsp], xmm10
00007a66921d47ba  movaps [rsp+0x10], xmm7
00007a66921d47bf  movaps [rsp+0x20], xmm13
00007a66921d47c5  lea rdi, [rsp]
00007a66921d47c9  mov esi, 0x00
00007a66921d47ce  mov rax, 0x635346DC7530
00007a66921d47d8  call rax
00007a66921d47da  movaps xmm10, [rsp]
00007a66921d47df  add rsp, 0x30
00007a66921d47e3  vmovaps xmm0, [rsp]
00007a66921d47e8  vmovaps xmm1, [rsp+0x10]
00007a66921d47ee  vmovaps xmm2, [rsp+0x20]
00007a66921d47f4  vmovaps xmm3, [rsp+0x30]
00007a66921d47fa  vmovaps xmm4, [rsp+0x40]
00007a66921d4800  vmovaps xmm5, [rsp+0x50]
00007a66921d4806  vmovaps xmm6, [rsp+0x60]
00007a66921d480c  vmovaps xmm7, [rsp+0x70]
00007a66921d4812  vmovaps xmm8, [rsp+0x80]
00007a66921d481b  vmovaps xmm9, [rsp+0x90]
00007a66921d4824  vmovaps xmm11, [rsp+0xA0]
00007a66921d482d  vmovaps xmm12, [rsp+0xB0]
00007a66921d4836  vmovaps xmm13, [rsp+0xC0]
00007a66921d483f  vmovaps xmm14, [rsp+0xD0]
00007a66921d4848  vmovaps xmm15, [rsp+0xE0]
00007a66921d4851  add rsp, 0xF0
00007a66921d4858  pop r11
00007a66921d485a  pop r10
00007a66921d485c  pop r9
00007a66921d485e  pop r8
00007a66921d4860  pop rsi
00007a66921d4861  pop rdi
00007a66921d4862  pop rdx
00007a66921d4863  pop rcx
00007a66921d4864  pop rax
00007a66921d4865  add rsp, 0x08
00007a66921d4869  jmp 0x00007A66921D0169
00007a66921d486e  sub rsp, 0x08
00007a66921d4872  push rax
00007a66921d4873  push rcx
00007a66921d4874  push rdx
00007a66921d4875  push rdi
00007a66921d4876  push rsi
00007a66921d4877  push r8
00007a66921d4879  push r9
00007a66921d487b  push r10
00007a66921d487d  push r11
00007a66921d487f  sub rsp, 0xF0
00007a66921d4886  vmovaps [rsp], xmm0
00007a66921d488b  vmovaps [rsp+0x10], xmm1
00007a66921d4891  vmovaps [rsp+0x20], xmm2
00007a66921d4897  vmovaps [rsp+0x30], xmm3
00007a66921d489d  vmovaps [rsp+0x40], xmm4
00007a66921d48a3  vmovaps [rsp+0x50], xmm5
00007a66921d48a9  vmovaps [rsp+0x60], xmm6
00007a66921d48af  vmovaps [rsp+0x70], xmm7
00007a66921d48b5  vmovaps [rsp+0x80], xmm8
00007a66921d48be  vmovaps [rsp+0x90], xmm9
00007a66921d48c7  vmovaps [rsp+0xA0], xmm10
00007a66921d48d0  vmovaps [rsp+0xB0], xmm11
00007a66921d48d9  vmovaps [rsp+0xC0], xmm12
00007a66921d48e2  vmovaps [rsp+0xD0], xmm14
00007a66921d48eb  vmovaps [rsp+0xE0], xmm15
00007a66921d48f4  sub rsp, 0x30
00007a66921d48f8  movaps [rsp], xmm13
00007a66921d48fd  movaps [rsp+0x10], xmm1
00007a66921d4902  movaps [rsp+0x20], xmm8
00007a66921d4908  lea rdi, [rsp]
00007a66921d490c  mov esi, 0x00
00007a66921d4911  mov rax, 0x635346DC7530
00007a66921d491b  call rax
00007a66921d491d  movaps xmm13, [rsp]
00007a66921d4922  add rsp, 0x30
00007a66921d4926  vmovaps xmm0, [rsp]
00007a66921d492b  vmovaps xmm1, [rsp+0x10]
00007a66921d4931  vmovaps xmm2, [rsp+0x20]
00007a66921d4937  vmovaps xmm3, [rsp+0x30]
00007a66921d493d  vmovaps xmm4, [rsp+0x40]
00007a66921d4943  vmovaps xmm5, [rsp+0x50]
00007a66921d4949  vmovaps xmm6, [rsp+0x60]
00007a66921d494f  vmovaps xmm7, [rsp+0x70]
00007a66921d4955  vmovaps xmm8, [rsp+0x80]
00007a66921d495e  vmovaps xmm9, [rsp+0x90]
00007a66921d4967  vmovaps xmm10, [rsp+0xA0]
00007a66921d4970  vmovaps xmm11, [rsp+0xB0]
00007a66921d4979  vmovaps xmm12, [rsp+0xC0]
00007a66921d4982  vmovaps xmm14, [rsp+0xD0]
00007a66921d498b  vmovaps xmm15, [rsp+0xE0]
00007a66921d4994  add rsp, 0xF0
00007a66921d499b  pop r11
00007a66921d499d  pop r10
00007a66921d499f  pop r9
00007a66921d49a1  pop r8
00007a66921d49a3  pop rsi
00007a66921d49a4  pop rdi
00007a66921d49a5  pop rdx
00007a66921d49a6  pop rcx
00007a66921d49a7  pop rax
00007a66921d49a8  add rsp, 0x08
00007a66921d49ac  jmp 0x00007A66921D0183
00007a66921d49b1  call 0x00007A6691FFF430
00007a66921d49b6  jmp 0x00007A66921D018D
00007a66921d49bb  sub rsp, 0x08
00007a66921d49bf  push rax
00007a66921d49c0  push rcx
00007a66921d49c1  push rdx
00007a66921d49c2  push rdi
00007a66921d49c3  push rsi
00007a66921d49c4  push r8
00007a66921d49c6  push r9
00007a66921d49c8  push r10
00007a66921d49ca  push r11
00007a66921d49cc  sub rsp, 0xF0
00007a66921d49d3  vmovaps [rsp], xmm0
00007a66921d49d8  vmovaps [rsp+0x10], xmm1
00007a66921d49de  vmovaps [rsp+0x20], xmm2
00007a66921d49e4  vmovaps [rsp+0x30], xmm3
00007a66921d49ea  vmovaps [rsp+0x40], xmm4
00007a66921d49f0  vmovaps [rsp+0x50], xmm5
00007a66921d49f6  vmovaps [rsp+0x60], xmm6
00007a66921d49fc  vmovaps [rsp+0x70], xmm7
00007a66921d4a02  vmovaps [rsp+0x80], xmm9
00007a66921d4a0b  vmovaps [rsp+0x90], xmm10
00007a66921d4a14  vmovaps [rsp+0xA0], xmm11
00007a66921d4a1d  vmovaps [rsp+0xB0], xmm12
00007a66921d4a26  vmovaps [rsp+0xC0], xmm13
00007a66921d4a2f  vmovaps [rsp+0xD0], xmm14
00007a66921d4a38  vmovaps [rsp+0xE0], xmm15
00007a66921d4a41  sub rsp, 0x30
00007a66921d4a45  movaps [rsp], xmm8
00007a66921d4a4a  movaps [rsp+0x10], xmm14
00007a66921d4a50  movaps [rsp+0x20], xmm9
00007a66921d4a56  lea rdi, [rsp]
00007a66921d4a5a  mov esi, 0x00
00007a66921d4a5f  mov rax, 0x635346DC7530
00007a66921d4a69  call rax
00007a66921d4a6b  movaps xmm8, [rsp]
00007a66921d4a70  add rsp, 0x30
00007a66921d4a74  vmovaps xmm0, [rsp]
00007a66921d4a79  vmovaps xmm1, [rsp+0x10]
00007a66921d4a7f  vmovaps xmm2, [rsp+0x20]
00007a66921d4a85  vmovaps xmm3, [rsp+0x30]
00007a66921d4a8b  vmovaps xmm4, [rsp+0x40]
00007a66921d4a91  vmovaps xmm5, [rsp+0x50]
00007a66921d4a97  vmovaps xmm6, [rsp+0x60]
00007a66921d4a9d  vmovaps xmm7, [rsp+0x70]
00007a66921d4aa3  vmovaps xmm9, [rsp+0x80]
00007a66921d4aac  vmovaps xmm10, [rsp+0x90]
00007a66921d4ab5  vmovaps xmm11, [rsp+0xA0]
00007a66921d4abe  vmovaps xmm12, [rsp+0xB0]
00007a66921d4ac7  vmovaps xmm13, [rsp+0xC0]
00007a66921d4ad0  vmovaps xmm14, [rsp+0xD0]
00007a66921d4ad9  vmovaps xmm15, [rsp+0xE0]
00007a66921d4ae2  add rsp, 0xF0
00007a66921d4ae9  pop r11
00007a66921d4aeb  pop r10
00007a66921d4aed  pop r9
00007a66921d4aef  pop r8
00007a66921d4af1  pop rsi
00007a66921d4af2  pop rdi
00007a66921d4af3  pop rdx
00007a66921d4af4  pop rcx
00007a66921d4af5  pop rax
00007a66921d4af6  add rsp, 0x08
00007a66921d4afa  jmp 0x00007A66921D01AF
00007a66921d4aff  sub rsp, 0x08
00007a66921d4b03  push rax
00007a66921d4b04  push rcx
00007a66921d4b05  push rdx
00007a66921d4b06  push rdi
00007a66921d4b07  push rsi
00007a66921d4b08  push r8
00007a66921d4b0a  push r9
00007a66921d4b0c  push r10
00007a66921d4b0e  push r11
00007a66921d4b10  sub rsp, 0xF0
00007a66921d4b17  vmovaps [rsp], xmm0
00007a66921d4b1c  vmovaps [rsp+0x10], xmm1
00007a66921d4b22  vmovaps [rsp+0x20], xmm2
00007a66921d4b28  vmovaps [rsp+0x30], xmm3
00007a66921d4b2e  vmovaps [rsp+0x40], xmm4
00007a66921d4b34  vmovaps [rsp+0x50], xmm5
00007a66921d4b3a  vmovaps [rsp+0x60], xmm6
00007a66921d4b40  vmovaps [rsp+0x70], xmm7
00007a66921d4b46  vmovaps [rsp+0x80], xmm8
00007a66921d4b4f  vmovaps [rsp+0x90], xmm10
00007a66921d4b58  vmovaps [rsp+0xA0], xmm11
00007a66921d4b61  vmovaps [rsp+0xB0], xmm12
00007a66921d4b6a  vmovaps [rsp+0xC0], xmm13
00007a66921d4b73  vmovaps [rsp+0xD0], xmm14
00007a66921d4b7c  vmovaps [rsp+0xE0], xmm15
00007a66921d4b85  sub rsp, 0x30
00007a66921d4b89  movaps [rsp], xmm9
00007a66921d4b8e  movaps [rsp+0x10], xmm1
00007a66921d4b93  movaps [rsp+0x20], xmm14
00007a66921d4b99  lea rdi, [rsp]
00007a66921d4b9d  mov esi, 0x00
00007a66921d4ba2  mov rax, 0x635346DC7530
00007a66921d4bac  call rax
00007a66921d4bae  movaps xmm9, [rsp]
00007a66921d4bb3  add rsp, 0x30
00007a66921d4bb7  vmovaps xmm0, [rsp]
00007a66921d4bbc  vmovaps xmm1, [rsp+0x10]
00007a66921d4bc2  vmovaps xmm2, [rsp+0x20]
00007a66921d4bc8  vmovaps xmm3, [rsp+0x30]
00007a66921d4bce  vmovaps xmm4, [rsp+0x40]
00007a66921d4bd4  vmovaps xmm5, [rsp+0x50]
00007a66921d4bda  vmovaps xmm6, [rsp+0x60]
00007a66921d4be0  vmovaps xmm7, [rsp+0x70]
00007a66921d4be6  vmovaps xmm8, [rsp+0x80]
00007a66921d4bef  vmovaps xmm10, [rsp+0x90]
00007a66921d4bf8  vmovaps xmm11, [rsp+0xA0]
00007a66921d4c01  vmovaps xmm12, [rsp+0xB0]
00007a66921d4c0a  vmovaps xmm13, [rsp+0xC0]
00007a66921d4c13  vmovaps xmm14, [rsp+0xD0]
00007a66921d4c1c  vmovaps xmm15, [rsp+0xE0]
00007a66921d4c25  add rsp, 0xF0
00007a66921d4c2c  pop r11
00007a66921d4c2e  pop r10
00007a66921d4c30  pop r9
00007a66921d4c32  pop r8
00007a66921d4c34  pop rsi
00007a66921d4c35  pop rdi
00007a66921d4c36  pop rdx
00007a66921d4c37  pop rcx
00007a66921d4c38  pop rax
00007a66921d4c39  add rsp, 0x08
00007a66921d4c3d  jmp 0x00007A66921D01DD
00007a66921d4c42  sub rsp, 0x08
00007a66921d4c46  push rax
00007a66921d4c47  push rcx
00007a66921d4c48  push rdx
00007a66921d4c49  push rdi
00007a66921d4c4a  push rsi
00007a66921d4c4b  push r8
00007a66921d4c4d  push r9
00007a66921d4c4f  push r10
00007a66921d4c51  push r11
00007a66921d4c53  sub rsp, 0xF0
00007a66921d4c5a  vmovaps [rsp], xmm0
00007a66921d4c5f  vmovaps [rsp+0x10], xmm1
00007a66921d4c65  vmovaps [rsp+0x20], xmm2
00007a66921d4c6b  vmovaps [rsp+0x30], xmm3
00007a66921d4c71  vmovaps [rsp+0x40], xmm4
00007a66921d4c77  vmovaps [rsp+0x50], xmm5
00007a66921d4c7d  vmovaps [rsp+0x60], xmm6
00007a66921d4c83  vmovaps [rsp+0x70], xmm7
00007a66921d4c89  vmovaps [rsp+0x80], xmm8
00007a66921d4c92  vmovaps [rsp+0x90], xmm9
00007a66921d4c9b  vmovaps [rsp+0xA0], xmm10
00007a66921d4ca4  vmovaps [rsp+0xB0], xmm11
00007a66921d4cad  vmovaps [rsp+0xC0], xmm12
00007a66921d4cb6  vmovaps [rsp+0xD0], xmm13
00007a66921d4cbf  vmovaps [rsp+0xE0], xmm15
00007a66921d4cc8  sub rsp, 0x30
00007a66921d4ccc  movaps [rsp], xmm14
00007a66921d4cd1  movaps [rsp+0x10], xmm4
00007a66921d4cd6  movaps [rsp+0x20], xmm1
00007a66921d4cdb  lea rdi, [rsp]
00007a66921d4cdf  mov esi, 0x00
00007a66921d4ce4  mov rax, 0x635346DC7530
00007a66921d4cee  call rax
00007a66921d4cf0  movaps xmm14, [rsp]
00007a66921d4cf5  add rsp, 0x30
00007a66921d4cf9  vmovaps xmm0, [rsp]
00007a66921d4cfe  vmovaps xmm1, [rsp+0x10]
00007a66921d4d04  vmovaps xmm2, [rsp+0x20]
00007a66921d4d0a  vmovaps xmm3, [rsp+0x30]
00007a66921d4d10  vmovaps xmm4, [rsp+0x40]
00007a66921d4d16  vmovaps xmm5, [rsp+0x50]
00007a66921d4d1c  vmovaps xmm6, [rsp+0x60]
00007a66921d4d22  vmovaps xmm7, [rsp+0x70]
00007a66921d4d28  vmovaps xmm8, [rsp+0x80]
00007a66921d4d31  vmovaps xmm9, [rsp+0x90]
00007a66921d4d3a  vmovaps xmm10, [rsp+0xA0]
00007a66921d4d43  vmovaps xmm11, [rsp+0xB0]
00007a66921d4d4c  vmovaps xmm12, [rsp+0xC0]
00007a66921d4d55  vmovaps xmm13, [rsp+0xD0]
00007a66921d4d5e  vmovaps xmm15, [rsp+0xE0]
00007a66921d4d67  add rsp, 0xF0
00007a66921d4d6e  pop r11
00007a66921d4d70  pop r10
00007a66921d4d72  pop r9
00007a66921d4d74  pop r8
00007a66921d4d76  pop rsi
00007a66921d4d77  pop rdi
00007a66921d4d78  pop rdx
00007a66921d4d79  pop rcx
00007a66921d4d7a  pop rax
00007a66921d4d7b  add rsp, 0x08
00007a66921d4d7f  jmp 0x00007A66921D0203
00007a66921d4d84  sub rsp, 0x08
00007a66921d4d88  push rax
00007a66921d4d89  push rcx
00007a66921d4d8a  push rdx
00007a66921d4d8b  push rdi
00007a66921d4d8c  push rsi
00007a66921d4d8d  push r8
00007a66921d4d8f  push r9
00007a66921d4d91  push r10
00007a66921d4d93  push r11
00007a66921d4d95  sub rsp, 0xF0
00007a66921d4d9c  vmovaps [rsp], xmm0
00007a66921d4da1  vmovaps [rsp+0x10], xmm2
00007a66921d4da7  vmovaps [rsp+0x20], xmm3
00007a66921d4dad  vmovaps [rsp+0x30], xmm4
00007a66921d4db3  vmovaps [rsp+0x40], xmm5
00007a66921d4db9  vmovaps [rsp+0x50], xmm6
00007a66921d4dbf  vmovaps [rsp+0x60], xmm7
00007a66921d4dc5  vmovaps [rsp+0x70], xmm8
00007a66921d4dcb  vmovaps [rsp+0x80], xmm9
00007a66921d4dd4  vmovaps [rsp+0x90], xmm10
00007a66921d4ddd  vmovaps [rsp+0xA0], xmm11
00007a66921d4de6  vmovaps [rsp+0xB0], xmm12
00007a66921d4def  vmovaps [rsp+0xC0], xmm13
00007a66921d4df8  vmovaps [rsp+0xD0], xmm14
00007a66921d4e01  vmovaps [rsp+0xE0], xmm15
00007a66921d4e0a  sub rsp, 0x30
00007a66921d4e0e  movaps [rsp], xmm1
00007a66921d4e12  movaps [rsp+0x10], xmm12
00007a66921d4e18  movaps [rsp+0x20], xmm11
00007a66921d4e1e  lea rdi, [rsp]
00007a66921d4e22  mov esi, 0x00
00007a66921d4e27  mov rax, 0x635346DC7530
00007a66921d4e31  call rax
00007a66921d4e33  movaps xmm1, [rsp]
00007a66921d4e37  add rsp, 0x30
00007a66921d4e3b  vmovaps xmm0, [rsp]
00007a66921d4e40  vmovaps xmm2, [rsp+0x10]
00007a66921d4e46  vmovaps xmm3, [rsp+0x20]
00007a66921d4e4c  vmovaps xmm4, [rsp+0x30]
00007a66921d4e52  vmovaps xmm5, [rsp+0x40]
00007a66921d4e58  vmovaps xmm6, [rsp+0x50]
00007a66921d4e5e  vmovaps xmm7, [rsp+0x60]
00007a66921d4e64  vmovaps xmm8, [rsp+0x70]
00007a66921d4e6a  vmovaps xmm9, [rsp+0x80]
00007a66921d4e73  vmovaps xmm10, [rsp+0x90]
00007a66921d4e7c  vmovaps xmm11, [rsp+0xA0]
00007a66921d4e85  vmovaps xmm12, [rsp+0xB0]
00007a66921d4e8e  vmovaps xmm13, [rsp+0xC0]
00007a66921d4e97  vmovaps xmm14, [rsp+0xD0]
00007a66921d4ea0  vmovaps xmm15, [rsp+0xE0]
00007a66921d4ea9  add rsp, 0xF0
00007a66921d4eb0  pop r11
00007a66921d4eb2  pop r10
00007a66921d4eb4  pop r9
00007a66921d4eb6  pop r8
00007a66921d4eb8  pop rsi
00007a66921d4eb9  pop rdi
00007a66921d4eba  pop rdx
00007a66921d4ebb  pop rcx
00007a66921d4ebc  pop rax
00007a66921d4ebd  add rsp, 0x08
00007a66921d4ec1  jmp 0x00007A66921D0224
00007a66921d4ec6  call 0x00007A66920E20A0
00007a66921d4ecb  jmp 0x00007A66921D0232
00007a66921d4ed0  call 0x00007A6692009D70
00007a66921d4ed5  jmp 0x00007A66921D023C
00007a66921d4eda  sub rsp, 0x08
00007a66921d4ede  push rax
00007a66921d4edf  push rcx
00007a66921d4ee0  push rdx
00007a66921d4ee1  push rdi
00007a66921d4ee2  push rsi
00007a66921d4ee3  push r8
00007a66921d4ee5  push r9
00007a66921d4ee7  push r10
00007a66921d4ee9  push r11
00007a66921d4eeb  sub rsp, 0xF0
00007a66921d4ef2  vmovaps [rsp], xmm0
00007a66921d4ef7  vmovaps [rsp+0x10], xmm1
00007a66921d4efd  vmovaps [rsp+0x20], xmm2
00007a66921d4f03  vmovaps [rsp+0x30], xmm3
00007a66921d4f09  vmovaps [rsp+0x40], xmm4
00007a66921d4f0f  vmovaps [rsp+0x50], xmm5
00007a66921d4f15  vmovaps [rsp+0x60], xmm6
00007a66921d4f1b  vmovaps [rsp+0x70], xmm8
00007a66921d4f21  vmovaps [rsp+0x80], xmm9
00007a66921d4f2a  vmovaps [rsp+0x90], xmm10
00007a66921d4f33  vmovaps [rsp+0xA0], xmm11
00007a66921d4f3c  vmovaps [rsp+0xB0], xmm12
00007a66921d4f45  vmovaps [rsp+0xC0], xmm13
00007a66921d4f4e  vmovaps [rsp+0xD0], xmm14
00007a66921d4f57  vmovaps [rsp+0xE0], xmm15
00007a66921d4f60  sub rsp, 0x30
00007a66921d4f64  movaps [rsp], xmm7
00007a66921d4f68  movaps [rsp+0x10], xmm15
00007a66921d4f6e  movaps [rsp+0x20], xmm10
00007a66921d4f74  lea rdi, [rsp]
00007a66921d4f78  mov esi, 0x00
00007a66921d4f7d  mov rax, 0x635346DC7530
00007a66921d4f87  call rax
00007a66921d4f89  movaps xmm7, [rsp]
00007a66921d4f8d  add rsp, 0x30
00007a66921d4f91  vmovaps xmm0, [rsp]
00007a66921d4f96  vmovaps xmm1, [rsp+0x10]
00007a66921d4f9c  vmovaps xmm2, [rsp+0x20]
00007a66921d4fa2  vmovaps xmm3, [rsp+0x30]
00007a66921d4fa8  vmovaps xmm4, [rsp+0x40]
00007a66921d4fae  vmovaps xmm5, [rsp+0x50]
00007a66921d4fb4  vmovaps xmm6, [rsp+0x60]
00007a66921d4fba  vmovaps xmm8, [rsp+0x70]
00007a66921d4fc0  vmovaps xmm9, [rsp+0x80]
00007a66921d4fc9  vmovaps xmm10, [rsp+0x90]
00007a66921d4fd2  vmovaps xmm11, [rsp+0xA0]
00007a66921d4fdb  vmovaps xmm12, [rsp+0xB0]
00007a66921d4fe4  vmovaps xmm13, [rsp+0xC0]
00007a66921d4fed  vmovaps xmm14, [rsp+0xD0]
00007a66921d4ff6  vmovaps xmm15, [rsp+0xE0]
00007a66921d4fff  add rsp, 0xF0
00007a66921d5006  pop r11
00007a66921d5008  pop r10
00007a66921d500a  pop r9
00007a66921d500c  pop r8
00007a66921d500e  pop rsi
00007a66921d500f  pop rdi
00007a66921d5010  pop rdx
00007a66921d5011  pop rcx
00007a66921d5012  pop rax
00007a66921d5013  add rsp, 0x08
00007a66921d5017  jmp 0x00007A66921D025D
00007a66921d501c  sub rsp, 0x08
00007a66921d5020  push rax
00007a66921d5021  push rcx
00007a66921d5022  push rdx
00007a66921d5023  push rdi
00007a66921d5024  push rsi
00007a66921d5025  push r8
00007a66921d5027  push r9
00007a66921d5029  push r10
00007a66921d502b  push r11
00007a66921d502d  sub rsp, 0xF0
00007a66921d5034  vmovaps [rsp], xmm0
00007a66921d5039  vmovaps [rsp+0x10], xmm1
00007a66921d503f  vmovaps [rsp+0x20], xmm2
00007a66921d5045  vmovaps [rsp+0x30], xmm3
00007a66921d504b  vmovaps [rsp+0x40], xmm4
00007a66921d5051  vmovaps [rsp+0x50], xmm5
00007a66921d5057  vmovaps [rsp+0x60], xmm6
00007a66921d505d  vmovaps [rsp+0x70], xmm7
00007a66921d5063  vmovaps [rsp+0x80], xmm8
00007a66921d506c  vmovaps [rsp+0x90], xmm9
00007a66921d5075  vmovaps [rsp+0xA0], xmm11
00007a66921d507e  vmovaps [rsp+0xB0], xmm12
00007a66921d5087  vmovaps [rsp+0xC0], xmm13
00007a66921d5090  vmovaps [rsp+0xD0], xmm14
00007a66921d5099  vmovaps [rsp+0xE0], xmm15
00007a66921d50a2  sub rsp, 0x30
00007a66921d50a6  movaps [rsp], xmm10
00007a66921d50ab  movaps [rsp+0x10], xmm11
00007a66921d50b1  movaps [rsp+0x20], xmm15
00007a66921d50b7  lea rdi, [rsp]
00007a66921d50bb  mov esi, 0x00
00007a66921d50c0  mov rax, 0x635346DC7530
00007a66921d50ca  call rax
00007a66921d50cc  movaps xmm10, [rsp]
00007a66921d50d1  add rsp, 0x30
00007a66921d50d5  vmovaps xmm0, [rsp]
00007a66921d50da  vmovaps xmm1, [rsp+0x10]
00007a66921d50e0  vmovaps xmm2, [rsp+0x20]
00007a66921d50e6  vmovaps xmm3, [rsp+0x30]
00007a66921d50ec  vmovaps xmm4, [rsp+0x40]
00007a66921d50f2  vmovaps xmm5, [rsp+0x50]
00007a66921d50f8  vmovaps xmm6, [rsp+0x60]
00007a66921d50fe  vmovaps xmm7, [rsp+0x70]
00007a66921d5104  vmovaps xmm8, [rsp+0x80]
00007a66921d510d  vmovaps xmm9, [rsp+0x90]
00007a66921d5116  vmovaps xmm11, [rsp+0xA0]
00007a66921d511f  vmovaps xmm12, [rsp+0xB0]
00007a66921d5128  vmovaps xmm13, [rsp+0xC0]
00007a66921d5131  vmovaps xmm14, [rsp+0xD0]
00007a66921d513a  vmovaps xmm15, [rsp+0xE0]
00007a66921d5143  add rsp, 0xF0
00007a66921d514a  pop r11
00007a66921d514c  pop r10
00007a66921d514e  pop r9
00007a66921d5150  pop r8
00007a66921d5152  pop rsi
00007a66921d5153  pop rdi
00007a66921d5154  pop rdx
00007a66921d5155  pop rcx
00007a66921d5156  pop rax
00007a66921d5157  add rsp, 0x08
00007a66921d515b  jmp 0x00007A66921D028B
00007a66921d5160  sub rsp, 0x08
00007a66921d5164  push rax
00007a66921d5165  push rcx
00007a66921d5166  push rdx
00007a66921d5167  push rdi
00007a66921d5168  push rsi
00007a66921d5169  push r8
00007a66921d516b  push r9
00007a66921d516d  push r10
00007a66921d516f  push r11
00007a66921d5171  sub rsp, 0xF0
00007a66921d5178  vmovaps [rsp], xmm0
00007a66921d517d  vmovaps [rsp+0x10], xmm1
00007a66921d5183  vmovaps [rsp+0x20], xmm2
00007a66921d5189  vmovaps [rsp+0x30], xmm3
00007a66921d518f  vmovaps [rsp+0x40], xmm4
00007a66921d5195  vmovaps [rsp+0x50], xmm5
00007a66921d519b  vmovaps [rsp+0x60], xmm6
00007a66921d51a1  vmovaps [rsp+0x70], xmm7
00007a66921d51a7  vmovaps [rsp+0x80], xmm8
00007a66921d51b0  vmovaps [rsp+0x90], xmm9
00007a66921d51b9  vmovaps [rsp+0xA0], xmm10
00007a66921d51c2  vmovaps [rsp+0xB0], xmm12
00007a66921d51cb  vmovaps [rsp+0xC0], xmm13
00007a66921d51d4  vmovaps [rsp+0xD0], xmm14
00007a66921d51dd  vmovaps [rsp+0xE0], xmm15
00007a66921d51e6  sub rsp, 0x30
00007a66921d51ea  movaps [rsp], xmm11
00007a66921d51ef  movaps [rsp+0x10], xmm12
00007a66921d51f5  movaps [rsp+0x20], xmm15
00007a66921d51fb  lea rdi, [rsp]
00007a66921d51ff  mov esi, 0x00
00007a66921d5204  mov rax, 0x635346DC7530
00007a66921d520e  call rax
00007a66921d5210  movaps xmm11, [rsp]
00007a66921d5215  add rsp, 0x30
00007a66921d5219  vmovaps xmm0, [rsp]
00007a66921d521e  vmovaps xmm1, [rsp+0x10]
00007a66921d5224  vmovaps xmm2, [rsp+0x20]
00007a66921d522a  vmovaps xmm3, [rsp+0x30]
00007a66921d5230  vmovaps xmm4, [rsp+0x40]
00007a66921d5236  vmovaps xmm5, [rsp+0x50]
00007a66921d523c  vmovaps xmm6, [rsp+0x60]
00007a66921d5242  vmovaps xmm7, [rsp+0x70]
00007a66921d5248  vmovaps xmm8, [rsp+0x80]
00007a66921d5251  vmovaps xmm9, [rsp+0x90]
00007a66921d525a  vmovaps xmm10, [rsp+0xA0]
00007a66921d5263  vmovaps xmm12, [rsp+0xB0]
00007a66921d526c  vmovaps xmm13, [rsp+0xC0]
00007a66921d5275  vmovaps xmm14, [rsp+0xD0]
00007a66921d527e  vmovaps xmm15, [rsp+0xE0]
00007a66921d5287  add rsp, 0xF0
00007a66921d528e  pop r11
00007a66921d5290  pop r10
00007a66921d5292  pop r9
00007a66921d5294  pop r8
00007a66921d5296  pop rsi
00007a66921d5297  pop rdi
00007a66921d5298  pop rdx
00007a66921d5299  pop rcx
00007a66921d529a  pop rax
00007a66921d529b  add rsp, 0x08
00007a66921d529f  jmp 0x00007A66921D02B9
00007a66921d52a4  sub rsp, 0x08
00007a66921d52a8  push rax
00007a66921d52a9  push rcx
00007a66921d52aa  push rdx
00007a66921d52ab  push rdi
00007a66921d52ac  push rsi
00007a66921d52ad  push r8
00007a66921d52af  push r9
00007a66921d52b1  push r10
00007a66921d52b3  push r11
00007a66921d52b5  sub rsp, 0xF0
00007a66921d52bc  vmovaps [rsp], xmm0
00007a66921d52c1  vmovaps [rsp+0x10], xmm1
00007a66921d52c7  vmovaps [rsp+0x20], xmm2
00007a66921d52cd  vmovaps [rsp+0x30], xmm3
00007a66921d52d3  vmovaps [rsp+0x40], xmm4
00007a66921d52d9  vmovaps [rsp+0x50], xmm5
00007a66921d52df  vmovaps [rsp+0x60], xmm6
00007a66921d52e5  vmovaps [rsp+0x70], xmm7
00007a66921d52eb  vmovaps [rsp+0x80], xmm8
00007a66921d52f4  vmovaps [rsp+0x90], xmm9
00007a66921d52fd  vmovaps [rsp+0xA0], xmm10
00007a66921d5306  vmovaps [rsp+0xB0], xmm11
00007a66921d530f  vmovaps [rsp+0xC0], xmm12
00007a66921d5318  vmovaps [rsp+0xD0], xmm13
00007a66921d5321  vmovaps [rsp+0xE0], xmm14
00007a66921d532a  sub rsp, 0x30
00007a66921d532e  movaps [rsp], xmm15
00007a66921d5333  movaps [rsp+0x10], xmm13
00007a66921d5339  movaps [rsp+0x20], xmm9
00007a66921d533f  lea rdi, [rsp]
00007a66921d5343  mov esi, 0x00
00007a66921d5348  mov rax, 0x635346DC7530
00007a66921d5352  call rax
00007a66921d5354  movaps xmm15, [rsp]
00007a66921d5359  add rsp, 0x30
00007a66921d535d  vmovaps xmm0, [rsp]
00007a66921d5362  vmovaps xmm1, [rsp+0x10]
00007a66921d5368  vmovaps xmm2, [rsp+0x20]
00007a66921d536e  vmovaps xmm3, [rsp+0x30]
00007a66921d5374  vmovaps xmm4, [rsp+0x40]
00007a66921d537a  vmovaps xmm5, [rsp+0x50]
00007a66921d5380  vmovaps xmm6, [rsp+0x60]
00007a66921d5386  vmovaps xmm7, [rsp+0x70]
00007a66921d538c  vmovaps xmm8, [rsp+0x80]
00007a66921d5395  vmovaps xmm9, [rsp+0x90]
00007a66921d539e  vmovaps xmm10, [rsp+0xA0]
00007a66921d53a7  vmovaps xmm11, [rsp+0xB0]
00007a66921d53b0  vmovaps xmm12, [rsp+0xC0]
00007a66921d53b9  vmovaps xmm13, [rsp+0xD0]
00007a66921d53c2  vmovaps xmm14, [rsp+0xE0]
00007a66921d53cb  add rsp, 0xF0
00007a66921d53d2  pop r11
00007a66921d53d4  pop r10
00007a66921d53d6  pop r9
00007a66921d53d8  pop r8
00007a66921d53da  pop rsi
00007a66921d53db  pop rdi
00007a66921d53dc  pop rdx
00007a66921d53dd  pop rcx
00007a66921d53de  pop rax
00007a66921d53df  add rsp, 0x08
00007a66921d53e3  jmp 0x00007A66921D02D4
00007a66921d53e8  sub rsp, 0x08
00007a66921d53ec  push rax
00007a66921d53ed  push rcx
00007a66921d53ee  push rdx
00007a66921d53ef  push rdi
00007a66921d53f0  push rsi
00007a66921d53f1  push r8
00007a66921d53f3  push r9
00007a66921d53f5  push r10
00007a66921d53f7  push r11
00007a66921d53f9  sub rsp, 0xF0
00007a66921d5400  vmovaps [rsp], xmm0
00007a66921d5405  vmovaps [rsp+0x10], xmm1
00007a66921d540b  vmovaps [rsp+0x20], xmm2
00007a66921d5411  vmovaps [rsp+0x30], xmm3
00007a66921d5417  vmovaps [rsp+0x40], xmm4
00007a66921d541d  vmovaps [rsp+0x50], xmm5
00007a66921d5423  vmovaps [rsp+0x60], xmm6
00007a66921d5429  vmovaps [rsp+0x70], xmm7
00007a66921d542f  vmovaps [rsp+0x80], xmm8
00007a66921d5438  vmovaps [rsp+0x90], xmm9
00007a66921d5441  vmovaps [rsp+0xA0], xmm10
00007a66921d544a  vmovaps [rsp+0xB0], xmm11
00007a66921d5453  vmovaps [rsp+0xC0], xmm12
00007a66921d545c  vmovaps [rsp+0xD0], xmm14
00007a66921d5465  vmovaps [rsp+0xE0], xmm15
00007a66921d546e  sub rsp, 0x30
00007a66921d5472  movaps [rsp], xmm13
00007a66921d5477  movaps [rsp+0x10], xmm8
00007a66921d547d  movaps [rsp+0x20], xmm14
00007a66921d5483  lea rdi, [rsp]
00007a66921d5487  mov esi, 0x00
00007a66921d548c  mov rax, 0x635346DC7530
00007a66921d5496  call rax
00007a66921d5498  movaps xmm13, [rsp]
00007a66921d549d  add rsp, 0x30
00007a66921d54a1  vmovaps xmm0, [rsp]
00007a66921d54a6  vmovaps xmm1, [rsp+0x10]
00007a66921d54ac  vmovaps xmm2, [rsp+0x20]
00007a66921d54b2  vmovaps xmm3, [rsp+0x30]
00007a66921d54b8  vmovaps xmm4, [rsp+0x40]
00007a66921d54be  vmovaps xmm5, [rsp+0x50]
00007a66921d54c4  vmovaps xmm6, [rsp+0x60]
00007a66921d54ca  vmovaps xmm7, [rsp+0x70]
00007a66921d54d0  vmovaps xmm8, [rsp+0x80]
00007a66921d54d9  vmovaps xmm9, [rsp+0x90]
00007a66921d54e2  vmovaps xmm10, [rsp+0xA0]
00007a66921d54eb  vmovaps xmm11, [rsp+0xB0]
00007a66921d54f4  vmovaps xmm12, [rsp+0xC0]
00007a66921d54fd  vmovaps xmm14, [rsp+0xD0]
00007a66921d5506  vmovaps xmm15, [rsp+0xE0]
00007a66921d550f  add rsp, 0xF0
00007a66921d5516  pop r11
00007a66921d5518  pop r10
00007a66921d551a  pop r9
00007a66921d551c  pop r8
00007a66921d551e  pop rsi
00007a66921d551f  pop rdi
00007a66921d5520  pop rdx
00007a66921d5521  pop rcx
00007a66921d5522  pop rax
00007a66921d5523  add rsp, 0x08
00007a66921d5527  jmp 0x00007A66921D02F7
00007a66921d552c  sub rsp, 0x08
00007a66921d5530  push rax
00007a66921d5531  push rcx
00007a66921d5532  push rdx
00007a66921d5533  push rdi
00007a66921d5534  push rsi
00007a66921d5535  push r8
00007a66921d5537  push r9
00007a66921d5539  push r10
00007a66921d553b  push r11
00007a66921d553d  sub rsp, 0xF0
00007a66921d5544  vmovaps [rsp], xmm0
00007a66921d5549  vmovaps [rsp+0x10], xmm1
00007a66921d554f  vmovaps [rsp+0x20], xmm2
00007a66921d5555  vmovaps [rsp+0x30], xmm3
00007a66921d555b  vmovaps [rsp+0x40], xmm4
00007a66921d5561  vmovaps [rsp+0x50], xmm5
00007a66921d5567  vmovaps [rsp+0x60], xmm6
00007a66921d556d  vmovaps [rsp+0x70], xmm7
00007a66921d5573  vmovaps [rsp+0x80], xmm8
00007a66921d557c  vmovaps [rsp+0x90], xmm9
00007a66921d5585  vmovaps [rsp+0xA0], xmm10
00007a66921d558e  vmovaps [rsp+0xB0], xmm11
00007a66921d5597  vmovaps [rsp+0xC0], xmm12
00007a66921d55a0  vmovaps [rsp+0xD0], xmm13
00007a66921d55a9  vmovaps [rsp+0xE0], xmm15
00007a66921d55b2  sub rsp, 0x30
00007a66921d55b6  movaps [rsp], xmm14
00007a66921d55bb  movaps [rsp+0x10], xmm1
00007a66921d55c0  movaps [rsp+0x20], xmm10
00007a66921d55c6  lea rdi, [rsp]
00007a66921d55ca  mov esi, 0x00
00007a66921d55cf  mov rax, 0x635346DC7530
00007a66921d55d9  call rax
00007a66921d55db  movaps xmm14, [rsp]
00007a66921d55e0  add rsp, 0x30
00007a66921d55e4  vmovaps xmm0, [rsp]
00007a66921d55e9  vmovaps xmm1, [rsp+0x10]
00007a66921d55ef  vmovaps xmm2, [rsp+0x20]
00007a66921d55f5  vmovaps xmm3, [rsp+0x30]
00007a66921d55fb  vmovaps xmm4, [rsp+0x40]
00007a66921d5601  vmovaps xmm5, [rsp+0x50]
00007a66921d5607  vmovaps xmm6, [rsp+0x60]
00007a66921d560d  vmovaps xmm7, [rsp+0x70]
00007a66921d5613  vmovaps xmm8, [rsp+0x80]
00007a66921d561c  vmovaps xmm9, [rsp+0x90]
00007a66921d5625  vmovaps xmm10, [rsp+0xA0]
00007a66921d562e  vmovaps xmm11, [rsp+0xB0]
00007a66921d5637  vmovaps xmm12, [rsp+0xC0]
00007a66921d5640  vmovaps xmm13, [rsp+0xD0]
00007a66921d5649  vmovaps xmm15, [rsp+0xE0]
00007a66921d5652  add rsp, 0xF0
00007a66921d5659  pop r11
00007a66921d565b  pop r10
00007a66921d565d  pop r9
00007a66921d565f  pop r8
00007a66921d5661  pop rsi
00007a66921d5662  pop rdi
00007a66921d5663  pop rdx
00007a66921d5664  pop rcx
00007a66921d5665  pop rax
00007a66921d5666  add rsp, 0x08
00007a66921d566a  jmp 0x00007A66921D031A
00007a66921d566f  sub rsp, 0x08
00007a66921d5673  push rax
00007a66921d5674  push rcx
00007a66921d5675  push rdx
00007a66921d5676  push rdi
00007a66921d5677  push rsi
00007a66921d5678  push r8
00007a66921d567a  push r9
00007a66921d567c  push r10
00007a66921d567e  push r11
00007a66921d5680  sub rsp, 0xF0
00007a66921d5687  vmovaps [rsp], xmm0
00007a66921d568c  vmovaps [rsp+0x10], xmm2
00007a66921d5692  vmovaps [rsp+0x20], xmm3
00007a66921d5698  vmovaps [rsp+0x30], xmm4
00007a66921d569e  vmovaps [rsp+0x40], xmm5
00007a66921d56a4  vmovaps [rsp+0x50], xmm6
00007a66921d56aa  vmovaps [rsp+0x60], xmm7
00007a66921d56b0  vmovaps [rsp+0x70], xmm8
00007a66921d56b6  vmovaps [rsp+0x80], xmm9
00007a66921d56bf  vmovaps [rsp+0x90], xmm10
00007a66921d56c8  vmovaps [rsp+0xA0], xmm11
00007a66921d56d1  vmovaps [rsp+0xB0], xmm12
00007a66921d56da  vmovaps [rsp+0xC0], xmm13
00007a66921d56e3  vmovaps [rsp+0xD0], xmm14
00007a66921d56ec  vmovaps [rsp+0xE0], xmm15
00007a66921d56f5  sub rsp, 0x30
00007a66921d56f9  movaps [rsp], xmm1
00007a66921d56fd  movaps [rsp+0x10], xmm7
00007a66921d5702  movaps [rsp+0x20], xmm11
00007a66921d5708  lea rdi, [rsp]
00007a66921d570c  mov esi, 0x00
00007a66921d5711  mov rax, 0x635346DC7530
00007a66921d571b  call rax
00007a66921d571d  movaps xmm1, [rsp]
00007a66921d5721  add rsp, 0x30
00007a66921d5725  vmovaps xmm0, [rsp]
00007a66921d572a  vmovaps xmm2, [rsp+0x10]
00007a66921d5730  vmovaps xmm3, [rsp+0x20]
00007a66921d5736  vmovaps xmm4, [rsp+0x30]
00007a66921d573c  vmovaps xmm5, [rsp+0x40]
00007a66921d5742  vmovaps xmm6, [rsp+0x50]
00007a66921d5748  vmovaps xmm7, [rsp+0x60]
00007a66921d574e  vmovaps xmm8, [rsp+0x70]
00007a66921d5754  vmovaps xmm9, [rsp+0x80]
00007a66921d575d  vmovaps xmm10, [rsp+0x90]
00007a66921d5766  vmovaps xmm11, [rsp+0xA0]
00007a66921d576f  vmovaps xmm12, [rsp+0xB0]
00007a66921d5778  vmovaps xmm13, [rsp+0xC0]
00007a66921d5781  vmovaps xmm14, [rsp+0xD0]
00007a66921d578a  vmovaps xmm15, [rsp+0xE0]
00007a66921d5793  add rsp, 0xF0
00007a66921d579a  pop r11
00007a66921d579c  pop r10
00007a66921d579e  pop r9
00007a66921d57a0  pop r8
00007a66921d57a2  pop rsi
00007a66921d57a3  pop rdi
00007a66921d57a4  pop rdx
00007a66921d57a5  pop rcx
00007a66921d57a6  pop rax
00007a66921d57a7  add rsp, 0x08
00007a66921d57ab  jmp 0x00007A66921D033B
00007a66921d57b0  call 0x00007A669200E880
00007a66921d57b5  jmp 0x00007A66921D034E
00007a66921d57ba  call 0x00007A669200C380
00007a66921d57bf  jmp 0x00007A66921D0359
00007a66921d57c4  call 0x00007A669200D600
00007a66921d57c9  jmp 0x00007A66921D0364
00007a66921d57ce  call 0x00007A6691FFF540
00007a66921d57d3  jmp 0x00007A66921D036F
00007a66921d57d8  int3
00007a66921d57d9  nop [rax], eax
00007a66921d57e0  mov rax, [r15+0x40]
00007a66921d57e4  mov r14, [r15+0x58]
00007a66921d57e8  lea r12, [rax+r14*1]
00007a66921d57ec  movaps xmm1, [r15+0x1D0]
00007a66921d57f4  vmovaps [rsp+0x10], xmm1
00007a66921d57fa  vmovaps xmm15, [rsp+0x10]
00007a66921d5800  por xmm1, xmm15
00007a66921d5805  movaps xmm14, [r15+0x1A0]
00007a66921d580d  vmovaps [rsp+0x10], xmm14
00007a66921d5813  vmovaps xmm13, [rsp+0x10]
00007a66921d5819  por xmm14, xmm13
00007a66921d581e  lea rax, [r12+0x30]
00007a66921d5823  mov r11, [r13+rax*1]
00007a66921d5828  lea rax, [r12+0x38]
00007a66921d582d  mov r10, [r13+rax*1]
00007a66921d5832  movq xmm13, r11
00007a66921d5837  movq xmm12, r10
00007a66921d583c  movq xmm13, xmm13
00007a66921d5841  vmovaps [rsp+0x10], xmm13
00007a66921d5847  movq xmm13, xmm13
00007a66921d584c  movaps [r15+0x130], xmm13
00007a66921d5854  movq xmm12, xmm12
00007a66921d5859  vmovaps [rsp+0x20], xmm12
00007a66921d585f  movq xmm12, xmm12
00007a66921d5864  movaps [r15+0x280], xmm12
00007a66921d586c  movaps xmm13, [r15+0x270]
00007a66921d5874  vmovaps [rsp+0x30], xmm13
00007a66921d587a  vmovaps xmm12, [rsp+0x30]
00007a66921d5880  por xmm13, xmm12
00007a66921d5885  lea rax, [r12+0x20]
00007a66921d588a  mov r11, [r13+rax*1]
00007a66921d588f  lea rax, [r12+0x28]
00007a66921d5894  mov r10, [r13+rax*1]
00007a66921d5899  movq xmm12, r11
00007a66921d589e  movq xmm11, r10
00007a66921d58a3  movq xmm12, xmm12
00007a66921d58a8  vmovaps [rsp+0x30], xmm12
00007a66921d58ae  movq xmm12, xmm12
00007a66921d58b3  movaps [r15+0x150], xmm12
00007a66921d58bb  movq xmm11, xmm11
00007a66921d58c0  vmovaps [rsp+0x40], xmm11
00007a66921d58c6  movq xmm11, xmm11
00007a66921d58cb  movaps [r15+0x140], xmm11
00007a66921d58d3  lea rax, [r12+0x10]
00007a66921d58d8  mov r11, [r13+rax*1]
00007a66921d58dd  lea rax, [r12+0x18]
00007a66921d58e2  mov r10, [r13+rax*1]
00007a66921d58e7  movq xmm12, r11
00007a66921d58ec  movq xmm11, r10
00007a66921d58f1  movq xmm12, xmm12
00007a66921d58f6  vmovaps [rsp+0x50], xmm12
00007a66921d58fc  movq xmm12, xmm12
00007a66921d5901  movaps [r15+0x170], xmm12
00007a66921d5909  movq xmm11, xmm11
00007a66921d590e  vmovaps [rsp+0x60], xmm11
00007a66921d5914  movq xmm11, xmm11
00007a66921d5919  movaps [r15+0x160], xmm11
00007a66921d5921  mov rax, [r13+r12*1]
00007a66921d5926  vmovq xmm12, rax
00007a66921d592b  vpbroadcastq xmm12, xmm12
00007a66921d5930  lea rax, [r12+0x08]
00007a66921d5935  mov r12, [r13+rax*1]
00007a66921d593a  movq xmm11, r12
00007a66921d593f  movaps [r15+0x230], xmm11
00007a66921d5947  mov rax, [r15+0xF8]
00007a66921d594e  lea r12, [rax+0x50]
00007a66921d5952  movups xmm11, [r13+r12*1]
00007a66921d5958  lea r12, [rax+0x60]
00007a66921d595c  movups xmm10, [r13+r12*1]
00007a66921d5962  lea r12, [rax+0x30]
00007a66921d5966  movups xmm9, [r13+r12*1]
00007a66921d596c  mov r12, [r15+0x50]
00007a66921d5970  lea r11, [r12+r14*1]
00007a66921d5974  mov [r15+0x60], r11
00007a66921d5978  lea r12, [r14+0x40]
00007a66921d597c  mov [r15+0x58], r12
00007a66921d5980  movaps xmm8, xmm12
00007a66921d5984  mulpd xmm8, xmm15
00007a66921d5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007a66921d598f  ptest xmm7, xmm7
00007a66921d5994  jnz 0x00007A66921D67B7
00007a66921d599a  movq xmm15, qword ptr [r15+0x230]
00007a66921d59a3  vmovaps [rsp+0x70], xmm15
00007a66921d59a9  vpermilpd xmm15, xmm15, 0x00
00007a66921d59af  movaps xmm7, xmm9
00007a66921d59b3  mulpd xmm7, xmm15
00007a66921d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007a66921d59bd  ptest xmm6, xmm6
00007a66921d59c2  jnz 0x00007A66921D68FB
00007a66921d59c8  vxorps xmm15, xmm15, xmm15
00007a66921d59cd  vpbroadcastq xmm15, xmm15
00007a66921d59d2  movaps xmm9, xmm12
00007a66921d59d6  mulpd xmm9, xmm10
00007a66921d59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007a66921d59e1  ptest xmm6, xmm6
00007a66921d59e6  jnz 0x00007A66921D6A3D
00007a66921d59ec  movaps xmm10, xmm12
00007a66921d59f0  mulpd xmm10, xmm11
00007a66921d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007a66921d59fb  ptest xmm6, xmm6
00007a66921d5a00  jnz 0x00007A66921D6B81
00007a66921d5a06  movaps xmm11, [r15+0x1F0]
00007a66921d5a0e  movaps xmm6, xmm12
00007a66921d5a12  mulpd xmm6, xmm11
00007a66921d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007a66921d5a1c  ptest xmm5, xmm5
00007a66921d5a21  jnz 0x00007A66921D6CC5
00007a66921d5a27  movaps xmm12, [r15+0x2A0]
00007a66921d5a2f  vmovaps [rsp+0x80], xmm12
00007a66921d5a38  vmovaps xmm11, [rsp+0x80]
00007a66921d5a41  por xmm12, xmm11
00007a66921d5a46  movaps xmm11, [r15+0x250]
00007a66921d5a4e  vmovaps [rsp+0x80], xmm11
00007a66921d5a57  vmovaps xmm5, [rsp+0x80]
00007a66921d5a60  por xmm11, xmm5
00007a66921d5a65  vmovaps xmm4, [rsp+0x70]
00007a66921d5a6b  vpermilpd xmm4, xmm4, 0x00
00007a66921d5a71  movaps xmm3, xmm5
00007a66921d5a74  mulpd xmm3, xmm4
00007a66921d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007a66921d5a7d  ptest xmm2, xmm2
00007a66921d5a82  jnz 0x00007A66921D6E07
00007a66921d5a88  mov [rsp+0x80], rax
00007a66921d5a90  xor eax, eax
00007a66921d5a92  mov r14d, 0x200
00007a66921d5a98  cmp r12, r14
00007a66921d5a9b  cmc
00007a66921d5a9c  lahf
00007a66921d5a9d  seto al
00007a66921d5aa0  mov [r15+0x108], eax
00007a66921d5aa7  movaps xmm5, xmm8
00007a66921d5aab  addpd xmm5, xmm15
00007a66921d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007a66921d5ab5  ptest xmm4, xmm4
00007a66921d5aba  jnz 0x00007A66921D6F47
00007a66921d5ac0  movaps xmm8, [r15+0x1B0]
00007a66921d5ac8  movaps xmm4, xmm9
00007a66921d5acc  addpd xmm4, xmm8
00007a66921d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007a66921d5ad6  ptest xmm2, xmm2
00007a66921d5adb  jnz 0x00007A66921D7089
00007a66921d5ae1  movaps xmm9, xmm10
00007a66921d5ae5  addpd xmm9, xmm8
00007a66921d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007a66921d5af0  ptest xmm2, xmm2
00007a66921d5af5  jnz 0x00007A66921D71CB
00007a66921d5afb  movaps xmm10, [r15+0x2F0]
00007a66921d5b03  vmovaps [rsp+0x90], xmm10
00007a66921d5b0c  vmovaps xmm8, [rsp+0x90]
00007a66921d5b15  por xmm10, xmm8
00007a66921d5b1a  movaps xmm8, [r15+0x2E0]
00007a66921d5b22  vmovaps [rsp+0x90], xmm8
00007a66921d5b2b  vmovaps xmm2, [rsp+0x90]
00007a66921d5b34  por xmm8, xmm2
00007a66921d5b39  movaps xmm2, [r15+0x2D0]
00007a66921d5b41  vmovaps [rsp+0x90], xmm2
00007a66921d5b4a  vmovaps [rsp+0xA0], xmm1
00007a66921d5b53  vmovaps xmm1, [rsp+0x90]
00007a66921d5b5c  por xmm2, xmm1
00007a66921d5b60  movaps xmm1, [r15+0x200]
00007a66921d5b68  vmovaps [rsp+0x90], xmm1
00007a66921d5b71  vmovaps [rsp+0xB0], xmm15
00007a66921d5b7a  vmovaps xmm15, [rsp+0x90]
00007a66921d5b83  por xmm1, xmm15
00007a66921d5b88  movaps xmm15, [r15+0x1C0]
00007a66921d5b90  vmovaps [rsp+0x90], xmm15
00007a66921d5b99  vmovaps [rsp+0xC0], xmm1
00007a66921d5ba2  vmovaps xmm1, [rsp+0x90]
00007a66921d5bab  por xmm15, xmm1
00007a66921d5bb0  movaps xmm1, [r15+0x190]
00007a66921d5bb8  vmovaps [rsp+0x90], xmm1
00007a66921d5bc1  vmovaps [rsp+0xD0], xmm15
00007a66921d5bca  vmovaps xmm15, [rsp+0x90]
00007a66921d5bd3  por xmm1, xmm15
00007a66921d5bd8  movaps xmm15, [r15+0x300]
00007a66921d5be0  vmovaps [rsp+0x90], xmm15
00007a66921d5be9  vmovaps [rsp+0xE0], xmm1
00007a66921d5bf2  vmovaps xmm1, [rsp+0x90]
00007a66921d5bfb  por xmm15, xmm1
00007a66921d5c00  mov rax, [rsp+0x80]
00007a66921d5c08  lea r14, [rax+0xA0]
00007a66921d5c0f  movups xmm1, [r13+r14*1]
00007a66921d5c15  lea r14, [rax+0xB0]
00007a66921d5c1c  vmovaps [rsp+0x80], xmm1
00007a66921d5c25  movups xmm1, [r13+r14*1]
00007a66921d5c2b  vmovaps [rsp+0x90], xmm1
00007a66921d5c34  vmovaps [rsp+0xF0], xmm15
00007a66921d5c3d  vmovaps xmm15, [rsp+0xB0]
00007a66921d5c46  vmovaps [rsp+0xB0], xmm14
00007a66921d5c4f  movaps xmm1, xmm6
00007a66921d5c52  addpd xmm1, xmm15
00007a66921d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007a66921d5c5c  ptest xmm14, xmm14
00007a66921d5c62  jnz 0x00007A66921D7323
00007a66921d5c68  lea r14, [rax+0xF0]
00007a66921d5c6f  movups xmm15, [r13+r14*1]
00007a66921d5c75  movaps xmm14, xmm4
00007a66921d5c79  addpd xmm14, xmm3
00007a66921d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007a66921d5c84  ptest xmm6, xmm6
00007a66921d5c89  jnz 0x00007A66921D746E
00007a66921d5c8f  movaps xmm6, xmm9
00007a66921d5c93  addpd xmm6, xmm7
00007a66921d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007a66921d5c9c  ptest xmm4, xmm4
00007a66921d5ca1  jnz 0x00007A66921D75B0
00007a66921d5ca7  vmovaps xmm9, [rsp+0x70]
00007a66921d5cad  vpermilpd xmm9, xmm9, 0x00
00007a66921d5cb3  vmovaps xmm4, [rsp+0x90]
00007a66921d5cbc  movaps xmm7, xmm4
00007a66921d5cbf  mulpd xmm7, xmm9
00007a66921d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007a66921d5cc9  ptest xmm3, xmm3
00007a66921d5cce  jnz 0x00007A66921D76F1
00007a66921d5cd4  vmovaps xmm9, [rsp+0x50]
00007a66921d5cda  vpermilpd xmm9, xmm9, 0x00
00007a66921d5ce0  movaps xmm4, xmm15
00007a66921d5ce4  mulpd xmm4, xmm9
00007a66921d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007a66921d5cee  ptest xmm3, xmm3
00007a66921d5cf3  jnz 0x00007A66921D7832
00007a66921d5cf9  lea r14, [rax+0xE0]
00007a66921d5d00  movups xmm15, [r13+r14*1]
00007a66921d5d06  vmovaps xmm9, [rsp+0x70]
00007a66921d5d0c  vpermilpd xmm9, xmm9, 0x00
00007a66921d5d12  vmovaps [rsp+0x70], xmm1
00007a66921d5d18  vmovaps xmm1, [rsp+0x80]
00007a66921d5d21  vmovaps [rsp+0x80], xmm15
00007a66921d5d2a  movaps xmm3, xmm1
00007a66921d5d2d  mulpd xmm3, xmm9
00007a66921d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007a66921d5d37  ptest xmm15, xmm15
00007a66921d5d3d  jnz 0x00007A66921D797E
00007a66921d5d43  vmovaps xmm1, [rsp+0xF0]
00007a66921d5d4c  vmovaps xmm15, [rsp+0xF0]
00007a66921d5d55  por xmm1, xmm15
00007a66921d5d5a  movaps [r15+0x300], xmm1
00007a66921d5d62  vmovaps xmm15, [rsp+0xE0]
00007a66921d5d6b  vmovaps xmm9, [rsp+0xE0]
00007a66921d5d74  por xmm15, xmm9
00007a66921d5d79  movaps [r15+0x190], xmm15
00007a66921d5d81  vmovaps xmm9, [rsp+0x50]
00007a66921d5d87  vpermilpd xmm9, xmm9, 0x00
00007a66921d5d8d  vmovaps [rsp+0x90], xmm1
00007a66921d5d96  vmovaps [rsp+0xE0], xmm15
00007a66921d5d9f  vmovaps xmm15, [rsp+0x80]
00007a66921d5da8  vmovaps [rsp+0x80], xmm14
00007a66921d5db1  movaps xmm1, xmm15
00007a66921d5db5  mulpd xmm1, xmm9
00007a66921d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007a66921d5dbf  ptest xmm14, xmm14
00007a66921d5dc5  jnz 0x00007A66921D7ABF
00007a66921d5dcb  lea r14, [rax+0x90]
00007a66921d5dd2  movups xmm15, [r13+r14*1]
00007a66921d5dd8  vmovaps xmm14, [rsp+0xD0]
00007a66921d5de1  vmovaps xmm9, [rsp+0xD0]
00007a66921d5dea  por xmm14, xmm9
00007a66921d5def  movaps [r15+0x1C0], xmm14
00007a66921d5df7  vmovaps xmm9, [rsp+0xC0]
00007a66921d5e00  vmovaps [rsp+0xD0], xmm1
00007a66921d5e09  vmovaps xmm1, [rsp+0xC0]
00007a66921d5e12  por xmm9, xmm1
00007a66921d5e17  movaps [r15+0x200], xmm9
00007a66921d5e1f  vmovaps [rsp+0xC0], xmm2
00007a66921d5e28  vmovaps xmm1, [rsp+0xC0]
00007a66921d5e31  por xmm2, xmm1
00007a66921d5e35  movaps [r15+0x2D0], xmm2
00007a66921d5e3d  vmovaps [rsp+0xC0], xmm8
00007a66921d5e46  vmovaps xmm1, [rsp+0xC0]
00007a66921d5e4f  por xmm8, xmm1
00007a66921d5e54  movaps [r15+0x2E0], xmm8
00007a66921d5e5c  vmovaps [rsp+0xC0], xmm15
00007a66921d5e65  movaps xmm1, xmm5
00007a66921d5e68  addpd xmm1, xmm7
00007a66921d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007a66921d5e71  ptest xmm15, xmm15
00007a66921d5e77  jnz 0x00007A66921D7C0B
00007a66921d5e7d  vmovaps xmm15, [rsp+0x50]
00007a66921d5e83  vpermilpd xmm15, xmm15, 0x00
00007a66921d5e89  vmovaps xmm5, [rsp+0xC0]
00007a66921d5e92  vmovaps [rsp+0xC0], xmm1
00007a66921d5e9b  movaps xmm7, xmm5
00007a66921d5e9e  mulpd xmm7, xmm15
00007a66921d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007a66921d5ea8  ptest xmm1, xmm1
00007a66921d5ead  jnz 0x00007A66921D7D4B
00007a66921d5eb3  lea r14, [rax+0x80]
00007a66921d5eba  movups xmm1, [r13+r14*1]
00007a66921d5ec0  vmovaps xmm5, [rsp+0x70]
00007a66921d5ec6  vmovaps [rsp+0x70], xmm1
00007a66921d5ecc  movaps xmm15, xmm5
00007a66921d5ed0  addpd xmm15, xmm3
00007a66921d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007a66921d5edb  ptest xmm1, xmm1
00007a66921d5ee0  jnz 0x00007A66921D7E96
00007a66921d5ee6  vmovaps xmm5, [rsp+0x80]
00007a66921d5eef  movaps xmm1, xmm5
00007a66921d5ef2  addpd xmm1, xmm4
00007a66921d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007a66921d5efb  ptest xmm3, xmm3
00007a66921d5f00  jnz 0x00007A66921D7FD8
00007a66921d5f06  vmovaps [rsp+0x80], xmm10
00007a66921d5f0f  vmovaps xmm5, [rsp+0x80]
00007a66921d5f18  por xmm10, xmm5
00007a66921d5f1d  movaps [r15+0x2F0], xmm10
00007a66921d5f25  vmovaps xmm5, [rsp+0x50]
00007a66921d5f2b  vpermilpd xmm5, xmm5, 0x00
00007a66921d5f31  vmovaps xmm3, [rsp+0x70]
00007a66921d5f37  vmovaps [rsp+0x50], xmm1
00007a66921d5f3d  movaps xmm4, xmm3
00007a66921d5f40  mulpd xmm4, xmm5
00007a66921d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007a66921d5f49  ptest xmm1, xmm1
00007a66921d5f4e  jnz 0x00007A66921D8118
00007a66921d5f54  lea r14, [rax+0xD0]
00007a66921d5f5b  movups xmm1, [r13+r14*1]
00007a66921d5f61  vmovaps xmm3, [rsp+0xD0]
00007a66921d5f6a  vmovaps [rsp+0x70], xmm1
00007a66921d5f70  movaps xmm5, xmm6
00007a66921d5f73  addpd xmm5, xmm3
00007a66921d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007a66921d5f7c  ptest xmm1, xmm1
00007a66921d5f81  jnz 0x00007A66921D8262
00007a66921d5f87  vmovaps xmm1, [rsp+0x60]
00007a66921d5f8d  vpermilpd xmm1, xmm1, 0x00
00007a66921d5f93  movaps xmm6, xmm9
00007a66921d5f97  mulpd xmm6, xmm1
00007a66921d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007a66921d5fa0  ptest xmm3, xmm3
00007a66921d5fa5  jnz 0x00007A66921D83A2
00007a66921d5fab  movaps [r15+0x260], xmm6
00007a66921d5fb3  vxorps xmm1, xmm1, xmm1
00007a66921d5fb7  vpbroadcastq xmm1, xmm1
00007a66921d5fbc  movaps [r15+0x1B0], xmm1
00007a66921d5fc4  vmovaps xmm1, [rsp+0x60]
00007a66921d5fca  vpermilpd xmm1, xmm1, 0x00
00007a66921d5fd0  vmovaps xmm3, [rsp+0x70]
00007a66921d5fd6  vmovaps [rsp+0x70], xmm15
00007a66921d5fdc  movaps xmm9, xmm3
00007a66921d5fe0  mulpd xmm9, xmm1
00007a66921d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007a66921d5feb  ptest xmm15, xmm15
00007a66921d5ff1  jnz 0x00007A66921D84E3
00007a66921d5ff7  lea r14, [rax+0xC0]
00007a66921d5ffe  movups xmm1, [r13+r14*1]
00007a66921d6004  vmovaps xmm3, [rsp+0xC0]
00007a66921d600d  vmovaps [rsp+0x80], xmm1
00007a66921d6016  movaps xmm15, xmm3
00007a66921d601a  addpd xmm15, xmm7
00007a66921d601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007a66921d6025  ptest xmm1, xmm1
00007a66921d602a  jnz 0x00007A66921D862F
00007a66921d6030  vmovaps [rsp+0xC0], xmm13
00007a66921d6039  vmovaps xmm1, [rsp+0xC0]
00007a66921d6042  por xmm13, xmm1
00007a66921d6047  movaps [r15+0x270], xmm13
00007a66921d604f  vmovaps xmm1, [rsp+0xB0]
00007a66921d6058  vmovaps xmm7, [rsp+0xB0]
00007a66921d6061  por xmm1, xmm7
00007a66921d6065  movaps [r15+0x1A0], xmm1
00007a66921d606d  vmovaps xmm1, [rsp+0x60]
00007a66921d6073  vpermilpd xmm1, xmm1, 0x00
00007a66921d6079  vmovaps [rsp+0xB0], xmm1
00007a66921d6082  vmovaps xmm1, [rsp+0x80]
00007a66921d608b  vmovaps [rsp+0x80], xmm15
00007a66921d6094  vmovaps xmm15, [rsp+0xB0]
00007a66921d609d  vmovaps [rsp+0xB0], xmm14
00007a66921d60a6  movaps xmm3, xmm1
00007a66921d60a9  mulpd xmm3, xmm15
00007a66921d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007a66921d60b3  ptest xmm14, xmm14
00007a66921d60b9  jnz 0x00007A66921D8771
00007a66921d60bf  lea r14, [rax+0x20]
00007a66921d60c3  movups xmm1, [r13+r14*1]
00007a66921d60c9  movaps [r15+0x110], xmm1
00007a66921d60d1  vmovaps xmm14, [rsp+0x70]
00007a66921d60d7  vmovaps [rsp+0x70], xmm1
00007a66921d60dd  movaps xmm15, xmm14
00007a66921d60e1  addpd xmm15, xmm4
00007a66921d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007a66921d60ec  ptest xmm1, xmm1
00007a66921d60f1  jnz 0x00007A66921D88BC
00007a66921d60f7  vmovaps xmm1, [rsp+0x60]
00007a66921d60fd  vpermilpd xmm1, xmm1, 0x00
00007a66921d6103  movaps xmm14, xmm2
00007a66921d6107  mulpd xmm14, xmm1
00007a66921d610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007a66921d6112  ptest xmm4, xmm4
00007a66921d6117  jnz 0x00007A66921D89FF
00007a66921d611d  vmovaps xmm4, [rsp+0x50]
00007a66921d6123  movaps xmm1, xmm4
00007a66921d6126  addpd xmm1, xmm9
00007a66921d612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007a66921d6130  ptest xmm2, xmm2
00007a66921d6135  jnz 0x00007A66921D8B41
00007a66921d613b  vmovaps xmm9, [rsp+0x30]
00007a66921d6141  vpermilpd xmm9, xmm9, 0x00
00007a66921d6147  vmovaps xmm2, [rsp+0x70]
00007a66921d614d  vmovaps [rsp+0x50], xmm1
00007a66921d6153  movaps xmm4, xmm2
00007a66921d6156  mulpd xmm4, xmm9
00007a66921d615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007a66921d6160  ptest xmm1, xmm1
00007a66921d6165  jnz 0x00007A66921D8C82
00007a66921d616b  vmovaps xmm1, [rsp+0x30]
00007a66921d6171  vpermilpd xmm1, xmm1, 0x00
00007a66921d6177  vmovaps xmm2, [rsp+0x90]
00007a66921d6180  vmovaps [rsp+0x60], xmm15
00007a66921d6186  movaps xmm9, xmm2
00007a66921d618a  mulpd xmm9, xmm1
00007a66921d618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007a66921d6195  ptest xmm15, xmm15
00007a66921d619b  jnz 0x00007A66921D8DC3
00007a66921d61a1  vmovaps xmm15, [rsp+0x80]
00007a66921d61aa  movaps xmm1, xmm15
00007a66921d61ae  addpd xmm1, xmm6
00007a66921d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007a66921d61b7  ptest xmm2, xmm2
00007a66921d61bc  jnz 0x00007A66921D8F05
00007a66921d61c2  movaps xmm15, xmm5
00007a66921d61c6  addpd xmm15, xmm3
00007a66921d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007a66921d61d1  ptest xmm6, xmm6
00007a66921d61d6  jnz 0x00007A66921D9046
00007a66921d61dc  vmovaps xmm6, [rsp+0x30]
00007a66921d61e2  vpermilpd xmm6, xmm6, 0x00
00007a66921d61e8  movaps xmm5, xmm8
00007a66921d61ec  mulpd xmm5, xmm6
00007a66921d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007a66921d61f5  ptest xmm3, xmm3
00007a66921d61fa  jnz 0x00007A66921D9188
00007a66921d6200  vmovaps xmm8, [rsp+0x30]
00007a66921d6206  vpermilpd xmm8, xmm8, 0x00
00007a66921d620c  movaps xmm6, xmm10
00007a66921d6210  mulpd xmm6, xmm8
00007a66921d6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007a66921d621a  ptest xmm3, xmm3
00007a66921d621f  jnz 0x00007A66921D92C9
00007a66921d6225  vmovaps xmm8, [rsp+0x60]
00007a66921d622b  movaps xmm10, xmm8
00007a66921d622f  addpd xmm10, xmm14
00007a66921d6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007a66921d623a  ptest xmm3, xmm3
00007a66921d623f  jnz 0x00007A66921D940B
00007a66921d6245  vmovaps xmm8, [rsp+0x50]
00007a66921d624b  movaps xmm14, xmm8
00007a66921d624f  addpd xmm14, xmm4
00007a66921d6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007a66921d625a  ptest xmm3, xmm3
00007a66921d625f  jnz 0x00007A66921D954F
00007a66921d6265  vmovaps xmm8, [rsp+0x40]
00007a66921d626b  vpermilpd xmm8, xmm8, 0x00
00007a66921d6271  movaps xmm4, xmm13
00007a66921d6275  mulpd xmm4, xmm8
00007a66921d627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007a66921d627f  ptest xmm3, xmm3
00007a66921d6284  jnz 0x00007A66921D9692
00007a66921d628a  movaps xmm13, xmm15
00007a66921d628e  addpd xmm13, xmm9
00007a66921d6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007a66921d6299  ptest xmm8, xmm8
00007a66921d629f  jnz 0x00007A66921D97D4
00007a66921d62a5  movaps xmm15, xmm1
00007a66921d62a9  addpd xmm15, xmm5
00007a66921d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007a66921d62b4  ptest xmm9, xmm9
00007a66921d62ba  jnz 0x00007A66921D9918
00007a66921d62c0  vmovaps [rsp+0x30], xmm11
00007a66921d62c6  vmovaps xmm1, [rsp+0x30]
00007a66921d62cc  por xmm11, xmm1
00007a66921d62d1  movaps [r15+0x250], xmm11
00007a66921d62d9  vmovaps [rsp+0x30], xmm12
00007a66921d62df  vmovaps xmm1, [rsp+0x30]
00007a66921d62e5  por xmm12, xmm1
00007a66921d62ea  movaps [r15+0x2A0], xmm12
00007a66921d62f2  vmovaps xmm1, [rsp+0xA0]
00007a66921d62fb  vmovaps xmm11, [rsp+0xA0]
00007a66921d6304  por xmm1, xmm11
00007a66921d6309  movaps [r15+0x1D0], xmm1
00007a66921d6311  lea r14, [rax+0x40]
00007a66921d6315  movups xmm1, [r13+r14*1]
00007a66921d631b  movaps [r15+0x2C0], xmm1
00007a66921d6323  vmovaps xmm11, [rsp+0x40]
00007a66921d6329  vpermilpd xmm11, xmm11, 0x00
00007a66921d632f  vmovaps xmm8, [rsp+0xE0]
00007a66921d6338  movaps xmm9, xmm8
00007a66921d633c  mulpd xmm9, xmm11
00007a66921d6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007a66921d6347  ptest xmm5, xmm5
00007a66921d634c  jnz 0x00007A66921D9A64
00007a66921d6352  movaps xmm11, xmm10
00007a66921d6356  addpd xmm11, xmm6
00007a66921d635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007a66921d6361  ptest xmm8, xmm8
00007a66921d6367  jnz 0x00007A66921D9BA8
00007a66921d636d  movaps xmm10, xmm14
00007a66921d6371  addpd xmm10, xmm4
00007a66921d6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007a66921d637c  ptest xmm8, xmm8
00007a66921d6382  jnz 0x00007A66921D9CEB
00007a66921d6388  vmovaps xmm14, [rsp+0x40]
00007a66921d638e  vpermilpd xmm14, xmm14, 0x00
00007a66921d6394  movaps xmm8, xmm1
00007a66921d6398  mulpd xmm8, xmm14
00007a66921d639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007a66921d63a3  ptest xmm6, xmm6
00007a66921d63a8  jnz 0x00007A66921D9E2E
00007a66921d63ae  movaps xmm1, [r15+0x2B0]
00007a66921d63b6  vmovaps xmm14, [rsp+0x40]
00007a66921d63bc  vpermilpd xmm14, xmm14, 0x00
00007a66921d63c2  movaps xmm6, xmm1
00007a66921d63c5  mulpd xmm6, xmm14
00007a66921d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007a66921d63cf  ptest xmm5, xmm5
00007a66921d63d4  jnz 0x00007A66921D9F71
00007a66921d63da  vmovaps xmm1, [rsp+0x10]
00007a66921d63e0  vpermilpd xmm1, xmm1, 0x00
00007a66921d63e6  movaps xmm14, xmm12
00007a66921d63ea  mulpd xmm14, xmm1
00007a66921d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007a66921d63f5  ptest xmm5, xmm5
00007a66921d63fa  jnz 0x00007A66921DA0B2
00007a66921d6400  movaps xmm1, xmm13
00007a66921d6404  addpd xmm1, xmm9
00007a66921d6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007a66921d640e  ptest xmm12, xmm12
00007a66921d6414  jnz 0x00007A66921DA1F5
00007a66921d641a  vmovaps xmm13, [rsp+0x10]
00007a66921d6420  vpermilpd xmm13, xmm13, 0x00
00007a66921d6426  movaps xmm12, xmm7
00007a66921d642a  mulpd xmm12, xmm13
00007a66921d642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007a66921d6435  ptest xmm9, xmm9
00007a66921d643b  jnz 0x00007A66921DA337
00007a66921d6441  movaps xmm13, xmm15
00007a66921d6445  addpd xmm13, xmm8
00007a66921d644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007a66921d6450  ptest xmm9, xmm9
00007a66921d6456  jnz 0x00007A66921DA47A
00007a66921d645c  movaps xmm15, [r15+0x290]
00007a66921d6464  vmovaps xmm9, [rsp+0x10]
00007a66921d646a  vpermilpd xmm9, xmm9, 0x00
00007a66921d6470  movaps xmm8, xmm15
00007a66921d6474  mulpd xmm8, xmm9
00007a66921d6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007a66921d647f  ptest xmm7, xmm7
00007a66921d6484  jnz 0x00007A66921DA5BE
00007a66921d648a  movaps xmm15, xmm11
00007a66921d648e  addpd xmm15, xmm6
00007a66921d6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007a66921d6499  ptest xmm9, xmm9
00007a66921d649f  jnz 0x00007A66921DA702
00007a66921d64a5  movaps xmm11, [r15+0x1E0]
00007a66921d64ad  vmovaps xmm9, [rsp+0x10]
00007a66921d64b3  vpermilpd xmm9, xmm9, 0x00
00007a66921d64b9  movaps xmm7, xmm11
00007a66921d64bd  mulpd xmm7, xmm9
00007a66921d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007a66921d64c7  ptest xmm6, xmm6
00007a66921d64cc  jnz 0x00007A66921DA845
00007a66921d64d2  movaps xmm11, xmm10
00007a66921d64d6  addpd xmm11, xmm14
00007a66921d64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007a66921d64e1  ptest xmm9, xmm9
00007a66921d64e7  jnz 0x00007A66921DA987
00007a66921d64ed  lea r14, [rax+0x70]
00007a66921d64f1  movups xmm14, [r13+r14*1]
00007a66921d64f7  movaps [r15+0x240], xmm14
00007a66921d64ff  movaps xmm10, xmm1
00007a66921d6503  addpd xmm10, xmm12
00007a66921d6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007a66921d650e  ptest xmm9, xmm9
00007a66921d6514  jnz 0x00007A66921DAAD5
00007a66921d651a  movaps [r15+0x170], xmm10
00007a66921d6522  vmovaps xmm1, [rsp+0x20]
00007a66921d6528  vpermilpd xmm1, xmm1, 0x00
00007a66921d652e  movaps xmm12, xmm14
00007a66921d6532  mulpd xmm12, xmm1
00007a66921d6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007a66921d653d  ptest xmm9, xmm9
00007a66921d6543  jnz 0x00007A66921DAC18
00007a66921d6549  vmovaps xmm1, [rsp+0x20]
00007a66921d654f  vpermilpd xmm1, xmm1, 0x00
00007a66921d6555  vmovaps xmm9, [rsp+0xB0]
00007a66921d655e  movaps xmm14, xmm9
00007a66921d6562  mulpd xmm14, xmm1
00007a66921d6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007a66921d656d  ptest xmm6, xmm6
00007a66921d6572  jnz 0x00007A66921DAD5B
00007a66921d6578  movaps [r15+0x180], xmm14
00007a66921d6580  movaps xmm1, xmm13
00007a66921d6584  addpd xmm1, xmm8
00007a66921d6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007a66921d658e  ptest xmm9, xmm9
00007a66921d6594  jnz 0x00007A66921DAE9E
00007a66921d659a  movaps [r15+0x210], xmm1
00007a66921d65a2  movups xmm13, [r13+rax*1]
00007a66921d65a8  lea r14, [rax+0x10]
00007a66921d65ac  movups xmm9, [r13+r14*1]
00007a66921d65b2  movaps [r15+0x230], xmm9
00007a66921d65ba  movaps xmm8, xmm15
00007a66921d65be  addpd xmm8, xmm7
00007a66921d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007a66921d65c9  ptest xmm6, xmm6
00007a66921d65ce  jnz 0x00007A66921DAFF4
00007a66921d65d4  movaps [r15+0x130], xmm8
00007a66921d65dc  vmovaps xmm15, [rsp+0x20]
00007a66921d65e2  vpermilpd xmm15, xmm15, 0x00
00007a66921d65e8  movaps xmm7, xmm9
00007a66921d65ec  mulpd xmm7, xmm15
00007a66921d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007a66921d65f6  ptest xmm6, xmm6
00007a66921d65fb  jnz 0x00007A66921DB137
00007a66921d6601  movaps [r15+0x220], xmm7
00007a66921d6609  vmovaps xmm15, [rsp+0x20]
00007a66921d660f  vpermilpd xmm15, xmm15, 0x00
00007a66921d6615  movaps xmm9, xmm13
00007a66921d6619  mulpd xmm9, xmm15
00007a66921d661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007a66921d6624  ptest xmm6, xmm6
00007a66921d6629  jnz 0x00007A66921DB279
00007a66921d662f  movaps xmm15, xmm11
00007a66921d6633  addpd xmm15, xmm12
00007a66921d6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007a66921d663e  ptest xmm13, xmm13
00007a66921d6644  jnz 0x00007A66921DB3BD
00007a66921d664a  movaps [r15+0x140], xmm15
00007a66921d6652  movaps xmm13, xmm10
00007a66921d6656  addpd xmm13, xmm14
00007a66921d665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007a66921d6661  ptest xmm12, xmm12
00007a66921d6667  jnz 0x00007A66921DB501
00007a66921d666d  movaps [r15+0x150], xmm13
00007a66921d6675  movaps xmm14, xmm1
00007a66921d6679  addpd xmm14, xmm7
00007a66921d667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007a66921d6684  ptest xmm12, xmm12
00007a66921d668a  jnz 0x00007A66921DB645
00007a66921d6690  movaps [r15+0x160], xmm14
00007a66921d6698  movaps xmm1, xmm8
00007a66921d669c  addpd xmm1, xmm9
00007a66921d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007a66921d66a6  ptest xmm12, xmm12
00007a66921d66ac  jnz 0x00007A66921DB787
00007a66921d66b2  movaps [r15+0x120], xmm1
00007a66921d66ba  movups [r13+r11*1], xmm15
00007a66921d66c0  lea rax, [r11+0x10]
00007a66921d66c4  movups [r13+rax*1], xmm13
00007a66921d66ca  lea rax, [r11+0x20]
00007a66921d66ce  movups [r13+rax*1], xmm14
00007a66921d66d4  lea rax, [r11+0x30]
00007a66921d66d8  movups [r13+rax*1], xmm1
00007a66921d66de  mov eax, [r15+0x108]
00007a66921d66e5  sahf
00007a66921d66e6  jnz 0x00007A66921D6718
00007a66921d66e8  cmp dword ptr [r15+0x318], 0x00
00007a66921d66f0  jz 0x00007A66921DB900
00007a66921d66f6  nop [rax+rax*1], ax
00007a66921d66ff  nop [rax+rax*1], eax
00007a66921d6707  mov eax, 0x410444
00007a66921d670c  mov [r15+0x100], rax
00007a66921d6713  jmp 0x00007A6691FFE110
00007a66921d6718  cmp dword ptr [r15+0x318], 0x00
00007a66921d6720  jz 0x00007A66921D57E0
00007a66921d6726  nop [rax+rax*1], ax
00007a66921d672f  nop [rax+rax*1], eax
00007a66921d6737  mov eax, 0x410278
00007a66921d673c  mov [r15+0x100], rax
00007a66921d6743  jmp 0x00007A6691FFE110
00007a66921d6748  int3
00007a66921d6749  call 0x00007A669200A4B0
00007a66921d674e  jmp 0x00007A66921D5828
00007a66921d6753  call 0x00007A6692009240
00007a66921d6758  jmp 0x00007A66921D5832
00007a66921d675d  call 0x00007A669200A4B0
00007a66921d6762  jmp 0x00007A66921D588F
00007a66921d6767  call 0x00007A6692009240
00007a66921d676c  jmp 0x00007A66921D5899
00007a66921d6771  call 0x00007A669200A4B0
00007a66921d6776  jmp 0x00007A66921D58DD
00007a66921d677b  call 0x00007A6692009240
00007a66921d6780  jmp 0x00007A66921D58E7
00007a66921d6785  call 0x00007A66920B47C0
00007a66921d678a  jmp 0x00007A66921D5926
00007a66921d678f  call 0x00007A669200B720
00007a66921d6794  jmp 0x00007A66921D593A
00007a66921d6799  call 0x00007A66920BFC30
00007a66921d679e  jmp 0x00007A66921D5958
00007a66921d67a3  call 0x00007A66920BE9C0
00007a66921d67a8  jmp 0x00007A66921D5962
00007a66921d67ad  call 0x00007A66920BD750
00007a66921d67b2  jmp 0x00007A66921D596C
00007a66921d67b7  sub rsp, 0x08
00007a66921d67bb  push rax
00007a66921d67bc  push rcx
00007a66921d67bd  push rdx
00007a66921d67be  push rdi
00007a66921d67bf  push rsi
00007a66921d67c0  push r8
00007a66921d67c2  push r9
00007a66921d67c4  push r10
00007a66921d67c6  push r11
00007a66921d67c8  sub rsp, 0xF0
00007a66921d67cf  vmovaps [rsp], xmm0
00007a66921d67d4  vmovaps [rsp+0x10], xmm1
00007a66921d67da  vmovaps [rsp+0x20], xmm2
00007a66921d67e0  vmovaps [rsp+0x30], xmm3
00007a66921d67e6  vmovaps [rsp+0x40], xmm4
00007a66921d67ec  vmovaps [rsp+0x50], xmm5
00007a66921d67f2  vmovaps [rsp+0x60], xmm6
00007a66921d67f8  vmovaps [rsp+0x70], xmm7
00007a66921d67fe  vmovaps [rsp+0x80], xmm9
00007a66921d6807  vmovaps [rsp+0x90], xmm10
00007a66921d6810  vmovaps [rsp+0xA0], xmm11
00007a66921d6819  vmovaps [rsp+0xB0], xmm12
00007a66921d6822  vmovaps [rsp+0xC0], xmm13
00007a66921d682b  vmovaps [rsp+0xD0], xmm14
00007a66921d6834  vmovaps [rsp+0xE0], xmm15
00007a66921d683d  sub rsp, 0x30
00007a66921d6841  movaps [rsp], xmm8
00007a66921d6846  movaps [rsp+0x10], xmm12
00007a66921d684c  movaps [rsp+0x20], xmm15
00007a66921d6852  lea rdi, [rsp]
00007a66921d6856  mov esi, 0x00
00007a66921d685b  mov rax, 0x635346DC7530
00007a66921d6865  call rax
00007a66921d6867  movaps xmm8, [rsp]
00007a66921d686c  add rsp, 0x30
00007a66921d6870  vmovaps xmm0, [rsp]
00007a66921d6875  vmovaps xmm1, [rsp+0x10]
00007a66921d687b  vmovaps xmm2, [rsp+0x20]
00007a66921d6881  vmovaps xmm3, [rsp+0x30]
00007a66921d6887  vmovaps xmm4, [rsp+0x40]
00007a66921d688d  vmovaps xmm5, [rsp+0x50]
00007a66921d6893  vmovaps xmm6, [rsp+0x60]
00007a66921d6899  vmovaps xmm7, [rsp+0x70]
00007a66921d689f  vmovaps xmm9, [rsp+0x80]
00007a66921d68a8  vmovaps xmm10, [rsp+0x90]
00007a66921d68b1  vmovaps xmm11, [rsp+0xA0]
00007a66921d68ba  vmovaps xmm12, [rsp+0xB0]
00007a66921d68c3  vmovaps xmm13, [rsp+0xC0]
00007a66921d68cc  vmovaps xmm14, [rsp+0xD0]
00007a66921d68d5  vmovaps xmm15, [rsp+0xE0]
00007a66921d68de  add rsp, 0xF0
00007a66921d68e5  pop r11
00007a66921d68e7  pop r10
00007a66921d68e9  pop r9
00007a66921d68eb  pop r8
00007a66921d68ed  pop rsi
00007a66921d68ee  pop rdi
00007a66921d68ef  pop rdx
00007a66921d68f0  pop rcx
00007a66921d68f1  pop rax
00007a66921d68f2  add rsp, 0x08
00007a66921d68f6  jmp 0x00007A66921D599A
00007a66921d68fb  sub rsp, 0x08
00007a66921d68ff  push rax
00007a66921d6900  push rcx
00007a66921d6901  push rdx
00007a66921d6902  push rdi
00007a66921d6903  push rsi
00007a66921d6904  push r8
00007a66921d6906  push r9
00007a66921d6908  push r10
00007a66921d690a  push r11
00007a66921d690c  sub rsp, 0xF0
00007a66921d6913  vmovaps [rsp], xmm0
00007a66921d6918  vmovaps [rsp+0x10], xmm1
00007a66921d691e  vmovaps [rsp+0x20], xmm2
00007a66921d6924  vmovaps [rsp+0x30], xmm3
00007a66921d692a  vmovaps [rsp+0x40], xmm4
00007a66921d6930  vmovaps [rsp+0x50], xmm5
00007a66921d6936  vmovaps [rsp+0x60], xmm6
00007a66921d693c  vmovaps [rsp+0x70], xmm8
00007a66921d6942  vmovaps [rsp+0x80], xmm9
00007a66921d694b  vmovaps [rsp+0x90], xmm10
00007a66921d6954  vmovaps [rsp+0xA0], xmm11
00007a66921d695d  vmovaps [rsp+0xB0], xmm12
00007a66921d6966  vmovaps [rsp+0xC0], xmm13
00007a66921d696f  vmovaps [rsp+0xD0], xmm14
00007a66921d6978  vmovaps [rsp+0xE0], xmm15
00007a66921d6981  sub rsp, 0x30
00007a66921d6985  movaps [rsp], xmm7
00007a66921d6989  movaps [rsp+0x10], xmm9
00007a66921d698f  movaps [rsp+0x20], xmm15
00007a66921d6995  lea rdi, [rsp]
00007a66921d6999  mov esi, 0x00
00007a66921d699e  mov rax, 0x635346DC7530
00007a66921d69a8  call rax
00007a66921d69aa  movaps xmm7, [rsp]
00007a66921d69ae  add rsp, 0x30
00007a66921d69b2  vmovaps xmm0, [rsp]
00007a66921d69b7  vmovaps xmm1, [rsp+0x10]
00007a66921d69bd  vmovaps xmm2, [rsp+0x20]
00007a66921d69c3  vmovaps xmm3, [rsp+0x30]
00007a66921d69c9  vmovaps xmm4, [rsp+0x40]
00007a66921d69cf  vmovaps xmm5, [rsp+0x50]
00007a66921d69d5  vmovaps xmm6, [rsp+0x60]
00007a66921d69db  vmovaps xmm8, [rsp+0x70]
00007a66921d69e1  vmovaps xmm9, [rsp+0x80]
00007a66921d69ea  vmovaps xmm10, [rsp+0x90]
00007a66921d69f3  vmovaps xmm11, [rsp+0xA0]
00007a66921d69fc  vmovaps xmm12, [rsp+0xB0]
00007a66921d6a05  vmovaps xmm13, [rsp+0xC0]
00007a66921d6a0e  vmovaps xmm14, [rsp+0xD0]
00007a66921d6a17  vmovaps xmm15, [rsp+0xE0]
00007a66921d6a20  add rsp, 0xF0
00007a66921d6a27  pop r11
00007a66921d6a29  pop r10
00007a66921d6a2b  pop r9
00007a66921d6a2d  pop r8
00007a66921d6a2f  pop rsi
00007a66921d6a30  pop rdi
00007a66921d6a31  pop rdx
00007a66921d6a32  pop rcx
00007a66921d6a33  pop rax
00007a66921d6a34  add rsp, 0x08
00007a66921d6a38  jmp 0x00007A66921D59C8
00007a66921d6a3d  sub rsp, 0x08
00007a66921d6a41  push rax
00007a66921d6a42  push rcx
00007a66921d6a43  push rdx
00007a66921d6a44  push rdi
00007a66921d6a45  push rsi
00007a66921d6a46  push r8
00007a66921d6a48  push r9
00007a66921d6a4a  push r10
00007a66921d6a4c  push r11
00007a66921d6a4e  sub rsp, 0xF0
00007a66921d6a55  vmovaps [rsp], xmm0
00007a66921d6a5a  vmovaps [rsp+0x10], xmm1
00007a66921d6a60  vmovaps [rsp+0x20], xmm2
00007a66921d6a66  vmovaps [rsp+0x30], xmm3
00007a66921d6a6c  vmovaps [rsp+0x40], xmm4
00007a66921d6a72  vmovaps [rsp+0x50], xmm5
00007a66921d6a78  vmovaps [rsp+0x60], xmm6
00007a66921d6a7e  vmovaps [rsp+0x70], xmm7
00007a66921d6a84  vmovaps [rsp+0x80], xmm8
00007a66921d6a8d  vmovaps [rsp+0x90], xmm10
00007a66921d6a96  vmovaps [rsp+0xA0], xmm11
00007a66921d6a9f  vmovaps [rsp+0xB0], xmm12
00007a66921d6aa8  vmovaps [rsp+0xC0], xmm13
00007a66921d6ab1  vmovaps [rsp+0xD0], xmm14
00007a66921d6aba  vmovaps [rsp+0xE0], xmm15
00007a66921d6ac3  sub rsp, 0x30
00007a66921d6ac7  movaps [rsp], xmm9
00007a66921d6acc  movaps [rsp+0x10], xmm12
00007a66921d6ad2  movaps [rsp+0x20], xmm10
00007a66921d6ad8  lea rdi, [rsp]
00007a66921d6adc  mov esi, 0x00
00007a66921d6ae1  mov rax, 0x635346DC7530
00007a66921d6aeb  call rax
00007a66921d6aed  movaps xmm9, [rsp]
00007a66921d6af2  add rsp, 0x30
00007a66921d6af6  vmovaps xmm0, [rsp]
00007a66921d6afb  vmovaps xmm1, [rsp+0x10]
00007a66921d6b01  vmovaps xmm2, [rsp+0x20]
00007a66921d6b07  vmovaps xmm3, [rsp+0x30]
00007a66921d6b0d  vmovaps xmm4, [rsp+0x40]
00007a66921d6b13  vmovaps xmm5, [rsp+0x50]
00007a66921d6b19  vmovaps xmm6, [rsp+0x60]
00007a66921d6b1f  vmovaps xmm7, [rsp+0x70]
00007a66921d6b25  vmovaps xmm8, [rsp+0x80]
00007a66921d6b2e  vmovaps xmm10, [rsp+0x90]
00007a66921d6b37  vmovaps xmm11, [rsp+0xA0]
00007a66921d6b40  vmovaps xmm12, [rsp+0xB0]
00007a66921d6b49  vmovaps xmm13, [rsp+0xC0]
00007a66921d6b52  vmovaps xmm14, [rsp+0xD0]
00007a66921d6b5b  vmovaps xmm15, [rsp+0xE0]
00007a66921d6b64  add rsp, 0xF0
00007a66921d6b6b  pop r11
00007a66921d6b6d  pop r10
00007a66921d6b6f  pop r9
00007a66921d6b71  pop r8
00007a66921d6b73  pop rsi
00007a66921d6b74  pop rdi
00007a66921d6b75  pop rdx
00007a66921d6b76  pop rcx
00007a66921d6b77  pop rax
00007a66921d6b78  add rsp, 0x08
00007a66921d6b7c  jmp 0x00007A66921D59EC
00007a66921d6b81  sub rsp, 0x08
00007a66921d6b85  push rax
00007a66921d6b86  push rcx
00007a66921d6b87  push rdx
00007a66921d6b88  push rdi
00007a66921d6b89  push rsi
00007a66921d6b8a  push r8
00007a66921d6b8c  push r9
00007a66921d6b8e  push r10
00007a66921d6b90  push r11
00007a66921d6b92  sub rsp, 0xF0
00007a66921d6b99  vmovaps [rsp], xmm0
00007a66921d6b9e  vmovaps [rsp+0x10], xmm1
00007a66921d6ba4  vmovaps [rsp+0x20], xmm2
00007a66921d6baa  vmovaps [rsp+0x30], xmm3
00007a66921d6bb0  vmovaps [rsp+0x40], xmm4
00007a66921d6bb6  vmovaps [rsp+0x50], xmm5
00007a66921d6bbc  vmovaps [rsp+0x60], xmm6
00007a66921d6bc2  vmovaps [rsp+0x70], xmm7
00007a66921d6bc8  vmovaps [rsp+0x80], xmm8
00007a66921d6bd1  vmovaps [rsp+0x90], xmm9
00007a66921d6bda  vmovaps [rsp+0xA0], xmm11
00007a66921d6be3  vmovaps [rsp+0xB0], xmm12
00007a66921d6bec  vmovaps [rsp+0xC0], xmm13
00007a66921d6bf5  vmovaps [rsp+0xD0], xmm14
00007a66921d6bfe  vmovaps [rsp+0xE0], xmm15
00007a66921d6c07  sub rsp, 0x30
00007a66921d6c0b  movaps [rsp], xmm10
00007a66921d6c10  movaps [rsp+0x10], xmm12
00007a66921d6c16  movaps [rsp+0x20], xmm11
00007a66921d6c1c  lea rdi, [rsp]
00007a66921d6c20  mov esi, 0x00
00007a66921d6c25  mov rax, 0x635346DC7530
00007a66921d6c2f  call rax
00007a66921d6c31  movaps xmm10, [rsp]
00007a66921d6c36  add rsp, 0x30
00007a66921d6c3a  vmovaps xmm0, [rsp]
00007a66921d6c3f  vmovaps xmm1, [rsp+0x10]
00007a66921d6c45  vmovaps xmm2, [rsp+0x20]
00007a66921d6c4b  vmovaps xmm3, [rsp+0x30]
00007a66921d6c51  vmovaps xmm4, [rsp+0x40]
00007a66921d6c57  vmovaps xmm5, [rsp+0x50]
00007a66921d6c5d  vmovaps xmm6, [rsp+0x60]
00007a66921d6c63  vmovaps xmm7, [rsp+0x70]
00007a66921d6c69  vmovaps xmm8, [rsp+0x80]
00007a66921d6c72  vmovaps xmm9, [rsp+0x90]
00007a66921d6c7b  vmovaps xmm11, [rsp+0xA0]
00007a66921d6c84  vmovaps xmm12, [rsp+0xB0]
00007a66921d6c8d  vmovaps xmm13, [rsp+0xC0]
00007a66921d6c96  vmovaps xmm14, [rsp+0xD0]
00007a66921d6c9f  vmovaps xmm15, [rsp+0xE0]
00007a66921d6ca8  add rsp, 0xF0
00007a66921d6caf  pop r11
00007a66921d6cb1  pop r10
00007a66921d6cb3  pop r9
00007a66921d6cb5  pop r8
00007a66921d6cb7  pop rsi
00007a66921d6cb8  pop rdi
00007a66921d6cb9  pop rdx
00007a66921d6cba  pop rcx
00007a66921d6cbb  pop rax
00007a66921d6cbc  add rsp, 0x08
00007a66921d6cc0  jmp 0x00007A66921D5A06
00007a66921d6cc5  sub rsp, 0x08
00007a66921d6cc9  push rax
00007a66921d6cca  push rcx
00007a66921d6ccb  push rdx
00007a66921d6ccc  push rdi
00007a66921d6ccd  push rsi
00007a66921d6cce  push r8
00007a66921d6cd0  push r9
00007a66921d6cd2  push r10
00007a66921d6cd4  push r11
00007a66921d6cd6  sub rsp, 0xF0
00007a66921d6cdd  vmovaps [rsp], xmm0
00007a66921d6ce2  vmovaps [rsp+0x10], xmm1
00007a66921d6ce8  vmovaps [rsp+0x20], xmm2
00007a66921d6cee  vmovaps [rsp+0x30], xmm3
00007a66921d6cf4  vmovaps [rsp+0x40], xmm4
00007a66921d6cfa  vmovaps [rsp+0x50], xmm5
00007a66921d6d00  vmovaps [rsp+0x60], xmm7
00007a66921d6d06  vmovaps [rsp+0x70], xmm8
00007a66921d6d0c  vmovaps [rsp+0x80], xmm9
00007a66921d6d15  vmovaps [rsp+0x90], xmm10
00007a66921d6d1e  vmovaps [rsp+0xA0], xmm11
00007a66921d6d27  vmovaps [rsp+0xB0], xmm12
00007a66921d6d30  vmovaps [rsp+0xC0], xmm13
00007a66921d6d39  vmovaps [rsp+0xD0], xmm14
00007a66921d6d42  vmovaps [rsp+0xE0], xmm15
00007a66921d6d4b  sub rsp, 0x30
00007a66921d6d4f  movaps [rsp], xmm6
00007a66921d6d53  movaps [rsp+0x10], xmm12
00007a66921d6d59  movaps [rsp+0x20], xmm11
00007a66921d6d5f  lea rdi, [rsp]
00007a66921d6d63  mov esi, 0x00
00007a66921d6d68  mov rax, 0x635346DC7530
00007a66921d6d72  call rax
00007a66921d6d74  movaps xmm6, [rsp]
00007a66921d6d78  add rsp, 0x30
00007a66921d6d7c  vmovaps xmm0, [rsp]
00007a66921d6d81  vmovaps xmm1, [rsp+0x10]
00007a66921d6d87  vmovaps xmm2, [rsp+0x20]
00007a66921d6d8d  vmovaps xmm3, [rsp+0x30]
00007a66921d6d93  vmovaps xmm4, [rsp+0x40]
00007a66921d6d99  vmovaps xmm5, [rsp+0x50]
00007a66921d6d9f  vmovaps xmm7, [rsp+0x60]
00007a66921d6da5  vmovaps xmm8, [rsp+0x70]
00007a66921d6dab  vmovaps xmm9, [rsp+0x80]
00007a66921d6db4  vmovaps xmm10, [rsp+0x90]
00007a66921d6dbd  vmovaps xmm11, [rsp+0xA0]
00007a66921d6dc6  vmovaps xmm12, [rsp+0xB0]
00007a66921d6dcf  vmovaps xmm13, [rsp+0xC0]
00007a66921d6dd8  vmovaps xmm14, [rsp+0xD0]
00007a66921d6de1  vmovaps xmm15, [rsp+0xE0]
00007a66921d6dea  add rsp, 0xF0
00007a66921d6df1  pop r11
00007a66921d6df3  pop r10
00007a66921d6df5  pop r9
00007a66921d6df7  pop r8
00007a66921d6df9  pop rsi
00007a66921d6dfa  pop rdi
00007a66921d6dfb  pop rdx
00007a66921d6dfc  pop rcx
00007a66921d6dfd  pop rax
00007a66921d6dfe  add rsp, 0x08
00007a66921d6e02  jmp 0x00007A66921D5A27
00007a66921d6e07  sub rsp, 0x08
00007a66921d6e0b  push rax
00007a66921d6e0c  push rcx
00007a66921d6e0d  push rdx
00007a66921d6e0e  push rdi
00007a66921d6e0f  push rsi
00007a66921d6e10  push r8
00007a66921d6e12  push r9
00007a66921d6e14  push r10
00007a66921d6e16  push r11
00007a66921d6e18  sub rsp, 0xF0
00007a66921d6e1f  vmovaps [rsp], xmm0
00007a66921d6e24  vmovaps [rsp+0x10], xmm1
00007a66921d6e2a  vmovaps [rsp+0x20], xmm2
00007a66921d6e30  vmovaps [rsp+0x30], xmm4
00007a66921d6e36  vmovaps [rsp+0x40], xmm5
00007a66921d6e3c  vmovaps [rsp+0x50], xmm6
00007a66921d6e42  vmovaps [rsp+0x60], xmm7
00007a66921d6e48  vmovaps [rsp+0x70], xmm8
00007a66921d6e4e  vmovaps [rsp+0x80], xmm9
00007a66921d6e57  vmovaps [rsp+0x90], xmm10
00007a66921d6e60  vmovaps [rsp+0xA0], xmm11
00007a66921d6e69  vmovaps [rsp+0xB0], xmm12
00007a66921d6e72  vmovaps [rsp+0xC0], xmm13
00007a66921d6e7b  vmovaps [rsp+0xD0], xmm14
00007a66921d6e84  vmovaps [rsp+0xE0], xmm15
00007a66921d6e8d  sub rsp, 0x30
00007a66921d6e91  movaps [rsp], xmm3
00007a66921d6e95  movaps [rsp+0x10], xmm5
00007a66921d6e9a  movaps [rsp+0x20], xmm4
00007a66921d6e9f  lea rdi, [rsp]
00007a66921d6ea3  mov esi, 0x00
00007a66921d6ea8  mov rax, 0x635346DC7530
00007a66921d6eb2  call rax
00007a66921d6eb4  movaps xmm3, [rsp]
00007a66921d6eb8  add rsp, 0x30
00007a66921d6ebc  vmovaps xmm0, [rsp]
00007a66921d6ec1  vmovaps xmm1, [rsp+0x10]
00007a66921d6ec7  vmovaps xmm2, [rsp+0x20]
00007a66921d6ecd  vmovaps xmm4, [rsp+0x30]
00007a66921d6ed3  vmovaps xmm5, [rsp+0x40]
00007a66921d6ed9  vmovaps xmm6, [rsp+0x50]
00007a66921d6edf  vmovaps xmm7, [rsp+0x60]
00007a66921d6ee5  vmovaps xmm8, [rsp+0x70]
00007a66921d6eeb  vmovaps xmm9, [rsp+0x80]
00007a66921d6ef4  vmovaps xmm10, [rsp+0x90]
00007a66921d6efd  vmovaps xmm11, [rsp+0xA0]
00007a66921d6f06  vmovaps xmm12, [rsp+0xB0]
00007a66921d6f0f  vmovaps xmm13, [rsp+0xC0]
00007a66921d6f18  vmovaps xmm14, [rsp+0xD0]
00007a66921d6f21  vmovaps xmm15, [rsp+0xE0]
00007a66921d6f2a  add rsp, 0xF0
00007a66921d6f31  pop r11
00007a66921d6f33  pop r10
00007a66921d6f35  pop r9
00007a66921d6f37  pop r8
00007a66921d6f39  pop rsi
00007a66921d6f3a  pop rdi
00007a66921d6f3b  pop rdx
00007a66921d6f3c  pop rcx
00007a66921d6f3d  pop rax
00007a66921d6f3e  add rsp, 0x08
00007a66921d6f42  jmp 0x00007A66921D5A88
00007a66921d6f47  sub rsp, 0x08
00007a66921d6f4b  push rax
00007a66921d6f4c  push rcx
00007a66921d6f4d  push rdx
00007a66921d6f4e  push rdi
00007a66921d6f4f  push rsi
00007a66921d6f50  push r8
00007a66921d6f52  push r9
00007a66921d6f54  push r10
00007a66921d6f56  push r11
00007a66921d6f58  sub rsp, 0xF0
00007a66921d6f5f  vmovaps [rsp], xmm0
00007a66921d6f64  vmovaps [rsp+0x10], xmm1
00007a66921d6f6a  vmovaps [rsp+0x20], xmm2
00007a66921d6f70  vmovaps [rsp+0x30], xmm3
00007a66921d6f76  vmovaps [rsp+0x40], xmm4
00007a66921d6f7c  vmovaps [rsp+0x50], xmm6
00007a66921d6f82  vmovaps [rsp+0x60], xmm7
00007a66921d6f88  vmovaps [rsp+0x70], xmm8
00007a66921d6f8e  vmovaps [rsp+0x80], xmm9
00007a66921d6f97  vmovaps [rsp+0x90], xmm10
00007a66921d6fa0  vmovaps [rsp+0xA0], xmm11
00007a66921d6fa9  vmovaps [rsp+0xB0], xmm12
00007a66921d6fb2  vmovaps [rsp+0xC0], xmm13
00007a66921d6fbb  vmovaps [rsp+0xD0], xmm14
00007a66921d6fc4  vmovaps [rsp+0xE0], xmm15
00007a66921d6fcd  sub rsp, 0x30
00007a66921d6fd1  movaps [rsp], xmm5
00007a66921d6fd5  movaps [rsp+0x10], xmm8
00007a66921d6fdb  movaps [rsp+0x20], xmm15
00007a66921d6fe1  lea rdi, [rsp]
00007a66921d6fe5  mov esi, 0x00
00007a66921d6fea  mov rax, 0x635346DC7530
00007a66921d6ff4  call rax
00007a66921d6ff6  movaps xmm5, [rsp]
00007a66921d6ffa  add rsp, 0x30
00007a66921d6ffe  vmovaps xmm0, [rsp]
00007a66921d7003  vmovaps xmm1, [rsp+0x10]
00007a66921d7009  vmovaps xmm2, [rsp+0x20]
00007a66921d700f  vmovaps xmm3, [rsp+0x30]
00007a66921d7015  vmovaps xmm4, [rsp+0x40]
00007a66921d701b  vmovaps xmm6, [rsp+0x50]
00007a66921d7021  vmovaps xmm7, [rsp+0x60]
00007a66921d7027  vmovaps xmm8, [rsp+0x70]
00007a66921d702d  vmovaps xmm9, [rsp+0x80]
00007a66921d7036  vmovaps xmm10, [rsp+0x90]
00007a66921d703f  vmovaps xmm11, [rsp+0xA0]
00007a66921d7048  vmovaps xmm12, [rsp+0xB0]
00007a66921d7051  vmovaps xmm13, [rsp+0xC0]
00007a66921d705a  vmovaps xmm14, [rsp+0xD0]
00007a66921d7063  vmovaps xmm15, [rsp+0xE0]
00007a66921d706c  add rsp, 0xF0
00007a66921d7073  pop r11
00007a66921d7075  pop r10
00007a66921d7077  pop r9
00007a66921d7079  pop r8
00007a66921d707b  pop rsi
00007a66921d707c  pop rdi
00007a66921d707d  pop rdx
00007a66921d707e  pop rcx
00007a66921d707f  pop rax
00007a66921d7080  add rsp, 0x08
00007a66921d7084  jmp 0x00007A66921D5AC0
00007a66921d7089  sub rsp, 0x08
00007a66921d708d  push rax
00007a66921d708e  push rcx
00007a66921d708f  push rdx
00007a66921d7090  push rdi
00007a66921d7091  push rsi
00007a66921d7092  push r8
00007a66921d7094  push r9
00007a66921d7096  push r10
00007a66921d7098  push r11
00007a66921d709a  sub rsp, 0xF0
00007a66921d70a1  vmovaps [rsp], xmm0
00007a66921d70a6  vmovaps [rsp+0x10], xmm1
00007a66921d70ac  vmovaps [rsp+0x20], xmm2
00007a66921d70b2  vmovaps [rsp+0x30], xmm3
00007a66921d70b8  vmovaps [rsp+0x40], xmm5
00007a66921d70be  vmovaps [rsp+0x50], xmm6
00007a66921d70c4  vmovaps [rsp+0x60], xmm7
00007a66921d70ca  vmovaps [rsp+0x70], xmm8
00007a66921d70d0  vmovaps [rsp+0x80], xmm9
00007a66921d70d9  vmovaps [rsp+0x90], xmm10
00007a66921d70e2  vmovaps [rsp+0xA0], xmm11
00007a66921d70eb  vmovaps [rsp+0xB0], xmm12
00007a66921d70f4  vmovaps [rsp+0xC0], xmm13
00007a66921d70fd  vmovaps [rsp+0xD0], xmm14
00007a66921d7106  vmovaps [rsp+0xE0], xmm15
00007a66921d710f  sub rsp, 0x30
00007a66921d7113  movaps [rsp], xmm4
00007a66921d7117  movaps [rsp+0x10], xmm9
00007a66921d711d  movaps [rsp+0x20], xmm8
00007a66921d7123  lea rdi, [rsp]
00007a66921d7127  mov esi, 0x00
00007a66921d712c  mov rax, 0x635346DC7530
00007a66921d7136  call rax
00007a66921d7138  movaps xmm4, [rsp]
00007a66921d713c  add rsp, 0x30
00007a66921d7140  vmovaps xmm0, [rsp]
00007a66921d7145  vmovaps xmm1, [rsp+0x10]
00007a66921d714b  vmovaps xmm2, [rsp+0x20]
00007a66921d7151  vmovaps xmm3, [rsp+0x30]
00007a66921d7157  vmovaps xmm5, [rsp+0x40]
00007a66921d715d  vmovaps xmm6, [rsp+0x50]
00007a66921d7163  vmovaps xmm7, [rsp+0x60]
00007a66921d7169  vmovaps xmm8, [rsp+0x70]
00007a66921d716f  vmovaps xmm9, [rsp+0x80]
00007a66921d7178  vmovaps xmm10, [rsp+0x90]
00007a66921d7181  vmovaps xmm11, [rsp+0xA0]
00007a66921d718a  vmovaps xmm12, [rsp+0xB0]
00007a66921d7193  vmovaps xmm13, [rsp+0xC0]
00007a66921d719c  vmovaps xmm14, [rsp+0xD0]
00007a66921d71a5  vmovaps xmm15, [rsp+0xE0]
00007a66921d71ae  add rsp, 0xF0
00007a66921d71b5  pop r11
00007a66921d71b7  pop r10
00007a66921d71b9  pop r9
00007a66921d71bb  pop r8
00007a66921d71bd  pop rsi
00007a66921d71be  pop rdi
00007a66921d71bf  pop rdx
00007a66921d71c0  pop rcx
00007a66921d71c1  pop rax
00007a66921d71c2  add rsp, 0x08
00007a66921d71c6  jmp 0x00007A66921D5AE1
00007a66921d71cb  sub rsp, 0x08
00007a66921d71cf  push rax
00007a66921d71d0  push rcx
00007a66921d71d1  push rdx
00007a66921d71d2  push rdi
00007a66921d71d3  push rsi
00007a66921d71d4  push r8
00007a66921d71d6  push r9
00007a66921d71d8  push r10
00007a66921d71da  push r11
00007a66921d71dc  sub rsp, 0xF0
00007a66921d71e3  vmovaps [rsp], xmm0
00007a66921d71e8  vmovaps [rsp+0x10], xmm1
00007a66921d71ee  vmovaps [rsp+0x20], xmm2
00007a66921d71f4  vmovaps [rsp+0x30], xmm3
00007a66921d71fa  vmovaps [rsp+0x40], xmm4
00007a66921d7200  vmovaps [rsp+0x50], xmm5
00007a66921d7206  vmovaps [rsp+0x60], xmm6
00007a66921d720c  vmovaps [rsp+0x70], xmm7
00007a66921d7212  vmovaps [rsp+0x80], xmm8
00007a66921d721b  vmovaps [rsp+0x90], xmm10
00007a66921d7224  vmovaps [rsp+0xA0], xmm11
00007a66921d722d  vmovaps [rsp+0xB0], xmm12
00007a66921d7236  vmovaps [rsp+0xC0], xmm13
00007a66921d723f  vmovaps [rsp+0xD0], xmm14
00007a66921d7248  vmovaps [rsp+0xE0], xmm15
00007a66921d7251  sub rsp, 0x30
00007a66921d7255  movaps [rsp], xmm9
00007a66921d725a  movaps [rsp+0x10], xmm10
00007a66921d7260  movaps [rsp+0x20], xmm8
00007a66921d7266  lea rdi, [rsp]
00007a66921d726a  mov esi, 0x00
00007a66921d726f  mov rax, 0x635346DC7530
00007a66921d7279  call rax
00007a66921d727b  movaps xmm9, [rsp]
00007a66921d7280  add rsp, 0x30
00007a66921d7284  vmovaps xmm0, [rsp]
00007a66921d7289  vmovaps xmm1, [rsp+0x10]
00007a66921d728f  vmovaps xmm2, [rsp+0x20]
00007a66921d7295  vmovaps xmm3, [rsp+0x30]
00007a66921d729b  vmovaps xmm4, [rsp+0x40]
00007a66921d72a1  vmovaps xmm5, [rsp+0x50]
00007a66921d72a7  vmovaps xmm6, [rsp+0x60]
00007a66921d72ad  vmovaps xmm7, [rsp+0x70]
00007a66921d72b3  vmovaps xmm8, [rsp+0x80]
00007a66921d72bc  vmovaps xmm10, [rsp+0x90]
00007a66921d72c5  vmovaps xmm11, [rsp+0xA0]
00007a66921d72ce  vmovaps xmm12, [rsp+0xB0]
00007a66921d72d7  vmovaps xmm13, [rsp+0xC0]
00007a66921d72e0  vmovaps xmm14, [rsp+0xD0]
00007a66921d72e9  vmovaps xmm15, [rsp+0xE0]
00007a66921d72f2  add rsp, 0xF0
00007a66921d72f9  pop r11
00007a66921d72fb  pop r10
00007a66921d72fd  pop r9
00007a66921d72ff  pop r8
00007a66921d7301  pop rsi
00007a66921d7302  pop rdi
00007a66921d7303  pop rdx
00007a66921d7304  pop rcx
00007a66921d7305  pop rax
00007a66921d7306  add rsp, 0x08
00007a66921d730a  jmp 0x00007A66921D5AFB
00007a66921d730f  call 0x00007A66920D64F0
00007a66921d7314  jmp 0x00007A66921D5C15
00007a66921d7319  call 0x00007A66920D64F0
00007a66921d731e  jmp 0x00007A66921D5C2B
00007a66921d7323  sub rsp, 0x08
00007a66921d7327  push rax
00007a66921d7328  push rcx
00007a66921d7329  push rdx
00007a66921d732a  push rdi
00007a66921d732b  push rsi
00007a66921d732c  push r8
00007a66921d732e  push r9
00007a66921d7330  push r10
00007a66921d7332  push r11
00007a66921d7334  sub rsp, 0xF0
00007a66921d733b  vmovaps [rsp], xmm0
00007a66921d7340  vmovaps [rsp+0x10], xmm2
00007a66921d7346  vmovaps [rsp+0x20], xmm3
00007a66921d734c  vmovaps [rsp+0x30], xmm4
00007a66921d7352  vmovaps [rsp+0x40], xmm5
00007a66921d7358  vmovaps [rsp+0x50], xmm6
00007a66921d735e  vmovaps [rsp+0x60], xmm7
00007a66921d7364  vmovaps [rsp+0x70], xmm8
00007a66921d736a  vmovaps [rsp+0x80], xmm9
00007a66921d7373  vmovaps [rsp+0x90], xmm10
00007a66921d737c  vmovaps [rsp+0xA0], xmm11
00007a66921d7385  vmovaps [rsp+0xB0], xmm12
00007a66921d738e  vmovaps [rsp+0xC0], xmm13
00007a66921d7397  vmovaps [rsp+0xD0], xmm14
00007a66921d73a0  vmovaps [rsp+0xE0], xmm15
00007a66921d73a9  sub rsp, 0x30
00007a66921d73ad  movaps [rsp], xmm1
00007a66921d73b1  movaps [rsp+0x10], xmm6
00007a66921d73b6  movaps [rsp+0x20], xmm15
00007a66921d73bc  lea rdi, [rsp]
00007a66921d73c0  mov esi, 0x00
00007a66921d73c5  mov rax, 0x635346DC7530
00007a66921d73cf  call rax
00007a66921d73d1  movaps xmm1, [rsp]
00007a66921d73d5  add rsp, 0x30
00007a66921d73d9  vmovaps xmm0, [rsp]
00007a66921d73de  vmovaps xmm2, [rsp+0x10]
00007a66921d73e4  vmovaps xmm3, [rsp+0x20]
00007a66921d73ea  vmovaps xmm4, [rsp+0x30]
00007a66921d73f0  vmovaps xmm5, [rsp+0x40]
00007a66921d73f6  vmovaps xmm6, [rsp+0x50]
00007a66921d73fc  vmovaps xmm7, [rsp+0x60]
00007a66921d7402  vmovaps xmm8, [rsp+0x70]
00007a66921d7408  vmovaps xmm9, [rsp+0x80]
00007a66921d7411  vmovaps xmm10, [rsp+0x90]
00007a66921d741a  vmovaps xmm11, [rsp+0xA0]
00007a66921d7423  vmovaps xmm12, [rsp+0xB0]
00007a66921d742c  vmovaps xmm13, [rsp+0xC0]
00007a66921d7435  vmovaps xmm14, [rsp+0xD0]
00007a66921d743e  vmovaps xmm15, [rsp+0xE0]
00007a66921d7447  add rsp, 0xF0
00007a66921d744e  pop r11
00007a66921d7450  pop r10
00007a66921d7452  pop r9
00007a66921d7454  pop r8
00007a66921d7456  pop rsi
00007a66921d7457  pop rdi
00007a66921d7458  pop rdx
00007a66921d7459  pop rcx
00007a66921d745a  pop rax
00007a66921d745b  add rsp, 0x08
00007a66921d745f  jmp 0x00007A66921D5C68
00007a66921d7464  call 0x00007A66920E5820
00007a66921d7469  jmp 0x00007A66921D5C75
00007a66921d746e  sub rsp, 0x08
00007a66921d7472  push rax
00007a66921d7473  push rcx
00007a66921d7474  push rdx
00007a66921d7475  push rdi
00007a66921d7476  push rsi
00007a66921d7477  push r8
00007a66921d7479  push r9
00007a66921d747b  push r10
00007a66921d747d  push r11
00007a66921d747f  sub rsp, 0xF0
00007a66921d7486  vmovaps [rsp], xmm0
00007a66921d748b  vmovaps [rsp+0x10], xmm1
00007a66921d7491  vmovaps [rsp+0x20], xmm2
00007a66921d7497  vmovaps [rsp+0x30], xmm3
00007a66921d749d  vmovaps [rsp+0x40], xmm4
00007a66921d74a3  vmovaps [rsp+0x50], xmm5
00007a66921d74a9  vmovaps [rsp+0x60], xmm6
00007a66921d74af  vmovaps [rsp+0x70], xmm7
00007a66921d74b5  vmovaps [rsp+0x80], xmm8
00007a66921d74be  vmovaps [rsp+0x90], xmm9
00007a66921d74c7  vmovaps [rsp+0xA0], xmm10
00007a66921d74d0  vmovaps [rsp+0xB0], xmm11
00007a66921d74d9  vmovaps [rsp+0xC0], xmm12
00007a66921d74e2  vmovaps [rsp+0xD0], xmm13
00007a66921d74eb  vmovaps [rsp+0xE0], xmm15
00007a66921d74f4  sub rsp, 0x30
00007a66921d74f8  movaps [rsp], xmm14
00007a66921d74fd  movaps [rsp+0x10], xmm4
00007a66921d7502  movaps [rsp+0x20], xmm3
00007a66921d7507  lea rdi, [rsp]
00007a66921d750b  mov esi, 0x00
00007a66921d7510  mov rax, 0x635346DC7530
00007a66921d751a  call rax
00007a66921d751c  movaps xmm14, [rsp]
00007a66921d7521  add rsp, 0x30
00007a66921d7525  vmovaps xmm0, [rsp]
00007a66921d752a  vmovaps xmm1, [rsp+0x10]
00007a66921d7530  vmovaps xmm2, [rsp+0x20]
00007a66921d7536  vmovaps xmm3, [rsp+0x30]
00007a66921d753c  vmovaps xmm4, [rsp+0x40]
00007a66921d7542  vmovaps xmm5, [rsp+0x50]
00007a66921d7548  vmovaps xmm6, [rsp+0x60]
00007a66921d754e  vmovaps xmm7, [rsp+0x70]
00007a66921d7554  vmovaps xmm8, [rsp+0x80]
00007a66921d755d  vmovaps xmm9, [rsp+0x90]
00007a66921d7566  vmovaps xmm10, [rsp+0xA0]
00007a66921d756f  vmovaps xmm11, [rsp+0xB0]
00007a66921d7578  vmovaps xmm12, [rsp+0xC0]
00007a66921d7581  vmovaps xmm13, [rsp+0xD0]
00007a66921d758a  vmovaps xmm15, [rsp+0xE0]
00007a66921d7593  add rsp, 0xF0
00007a66921d759a  pop r11
00007a66921d759c  pop r10
00007a66921d759e  pop r9
00007a66921d75a0  pop r8
00007a66921d75a2  pop rsi
00007a66921d75a3  pop rdi
00007a66921d75a4  pop rdx
00007a66921d75a5  pop rcx
00007a66921d75a6  pop rax
00007a66921d75a7  add rsp, 0x08
00007a66921d75ab  jmp 0x00007A66921D5C8F
00007a66921d75b0  sub rsp, 0x08
00007a66921d75b4  push rax
00007a66921d75b5  push rcx
00007a66921d75b6  push rdx
00007a66921d75b7  push rdi
00007a66921d75b8  push rsi
00007a66921d75b9  push r8
00007a66921d75bb  push r9
00007a66921d75bd  push r10
00007a66921d75bf  push r11
00007a66921d75c1  sub rsp, 0xF0
00007a66921d75c8  vmovaps [rsp], xmm0
00007a66921d75cd  vmovaps [rsp+0x10], xmm1
00007a66921d75d3  vmovaps [rsp+0x20], xmm2
00007a66921d75d9  vmovaps [rsp+0x30], xmm3
00007a66921d75df  vmovaps [rsp+0x40], xmm4
00007a66921d75e5  vmovaps [rsp+0x50], xmm5
00007a66921d75eb  vmovaps [rsp+0x60], xmm7
00007a66921d75f1  vmovaps [rsp+0x70], xmm8
00007a66921d75f7  vmovaps [rsp+0x80], xmm9
00007a66921d7600  vmovaps [rsp+0x90], xmm10
00007a66921d7609  vmovaps [rsp+0xA0], xmm11
00007a66921d7612  vmovaps [rsp+0xB0], xmm12
00007a66921d761b  vmovaps [rsp+0xC0], xmm13
00007a66921d7624  vmovaps [rsp+0xD0], xmm14
00007a66921d762d  vmovaps [rsp+0xE0], xmm15
00007a66921d7636  sub rsp, 0x30
00007a66921d763a  movaps [rsp], xmm6
00007a66921d763e  movaps [rsp+0x10], xmm9
00007a66921d7644  movaps [rsp+0x20], xmm7
00007a66921d7649  lea rdi, [rsp]
00007a66921d764d  mov esi, 0x00
00007a66921d7652  mov rax, 0x635346DC7530
00007a66921d765c  call rax
00007a66921d765e  movaps xmm6, [rsp]
00007a66921d7662  add rsp, 0x30
00007a66921d7666  vmovaps xmm0, [rsp]
00007a66921d766b  vmovaps xmm1, [rsp+0x10]
00007a66921d7671  vmovaps xmm2, [rsp+0x20]
00007a66921d7677  vmovaps xmm3, [rsp+0x30]
00007a66921d767d  vmovaps xmm4, [rsp+0x40]
00007a66921d7683  vmovaps xmm5, [rsp+0x50]
00007a66921d7689  vmovaps xmm7, [rsp+0x60]
00007a66921d768f  vmovaps xmm8, [rsp+0x70]
00007a66921d7695  vmovaps xmm9, [rsp+0x80]
00007a66921d769e  vmovaps xmm10, [rsp+0x90]
00007a66921d76a7  vmovaps xmm11, [rsp+0xA0]
00007a66921d76b0  vmovaps xmm12, [rsp+0xB0]
00007a66921d76b9  vmovaps xmm13, [rsp+0xC0]
00007a66921d76c2  vmovaps xmm14, [rsp+0xD0]
00007a66921d76cb  vmovaps xmm15, [rsp+0xE0]
00007a66921d76d4  add rsp, 0xF0
00007a66921d76db  pop r11
00007a66921d76dd  pop r10
00007a66921d76df  pop r9
00007a66921d76e1  pop r8
00007a66921d76e3  pop rsi
00007a66921d76e4  pop rdi
00007a66921d76e5  pop rdx
00007a66921d76e6  pop rcx
00007a66921d76e7  pop rax
00007a66921d76e8  add rsp, 0x08
00007a66921d76ec  jmp 0x00007A66921D5CA7
00007a66921d76f1  sub rsp, 0x08
00007a66921d76f5  push rax
00007a66921d76f6  push rcx
00007a66921d76f7  push rdx
00007a66921d76f8  push rdi
00007a66921d76f9  push rsi
00007a66921d76fa  push r8
00007a66921d76fc  push r9
00007a66921d76fe  push r10
00007a66921d7700  push r11
00007a66921d7702  sub rsp, 0xF0
00007a66921d7709  vmovaps [rsp], xmm0
00007a66921d770e  vmovaps [rsp+0x10], xmm1
00007a66921d7714  vmovaps [rsp+0x20], xmm2
00007a66921d771a  vmovaps [rsp+0x30], xmm3
00007a66921d7720  vmovaps [rsp+0x40], xmm4
00007a66921d7726  vmovaps [rsp+0x50], xmm5
00007a66921d772c  vmovaps [rsp+0x60], xmm6
00007a66921d7732  vmovaps [rsp+0x70], xmm8
00007a66921d7738  vmovaps [rsp+0x80], xmm9
00007a66921d7741  vmovaps [rsp+0x90], xmm10
00007a66921d774a  vmovaps [rsp+0xA0], xmm11
00007a66921d7753  vmovaps [rsp+0xB0], xmm12
00007a66921d775c  vmovaps [rsp+0xC0], xmm13
00007a66921d7765  vmovaps [rsp+0xD0], xmm14
00007a66921d776e  vmovaps [rsp+0xE0], xmm15
00007a66921d7777  sub rsp, 0x30
00007a66921d777b  movaps [rsp], xmm7
00007a66921d777f  movaps [rsp+0x10], xmm4
00007a66921d7784  movaps [rsp+0x20], xmm9
00007a66921d778a  lea rdi, [rsp]
00007a66921d778e  mov esi, 0x00
00007a66921d7793  mov rax, 0x635346DC7530
00007a66921d779d  call rax
00007a66921d779f  movaps xmm7, [rsp]
00007a66921d77a3  add rsp, 0x30
00007a66921d77a7  vmovaps xmm0, [rsp]
00007a66921d77ac  vmovaps xmm1, [rsp+0x10]
00007a66921d77b2  vmovaps xmm2, [rsp+0x20]
00007a66921d77b8  vmovaps xmm3, [rsp+0x30]
00007a66921d77be  vmovaps xmm4, [rsp+0x40]
00007a66921d77c4  vmovaps xmm5, [rsp+0x50]
00007a66921d77ca  vmovaps xmm6, [rsp+0x60]
00007a66921d77d0  vmovaps xmm8, [rsp+0x70]
00007a66921d77d6  vmovaps xmm9, [rsp+0x80]
00007a66921d77df  vmovaps xmm10, [rsp+0x90]
00007a66921d77e8  vmovaps xmm11, [rsp+0xA0]
00007a66921d77f1  vmovaps xmm12, [rsp+0xB0]
00007a66921d77fa  vmovaps xmm13, [rsp+0xC0]
00007a66921d7803  vmovaps xmm14, [rsp+0xD0]
00007a66921d780c  vmovaps xmm15, [rsp+0xE0]
00007a66921d7815  add rsp, 0xF0
00007a66921d781c  pop r11
00007a66921d781e  pop r10
00007a66921d7820  pop r9
00007a66921d7822  pop r8
00007a66921d7824  pop rsi
00007a66921d7825  pop rdi
00007a66921d7826  pop rdx
00007a66921d7827  pop rcx
00007a66921d7828  pop rax
00007a66921d7829  add rsp, 0x08
00007a66921d782d  jmp 0x00007A66921D5CD4
00007a66921d7832  sub rsp, 0x08
00007a66921d7836  push rax
00007a66921d7837  push rcx
00007a66921d7838  push rdx
00007a66921d7839  push rdi
00007a66921d783a  push rsi
00007a66921d783b  push r8
00007a66921d783d  push r9
00007a66921d783f  push r10
00007a66921d7841  push r11
00007a66921d7843  sub rsp, 0xF0
00007a66921d784a  vmovaps [rsp], xmm0
00007a66921d784f  vmovaps [rsp+0x10], xmm1
00007a66921d7855  vmovaps [rsp+0x20], xmm2
00007a66921d785b  vmovaps [rsp+0x30], xmm3
00007a66921d7861  vmovaps [rsp+0x40], xmm5
00007a66921d7867  vmovaps [rsp+0x50], xmm6
00007a66921d786d  vmovaps [rsp+0x60], xmm7
00007a66921d7873  vmovaps [rsp+0x70], xmm8
00007a66921d7879  vmovaps [rsp+0x80], xmm9
00007a66921d7882  vmovaps [rsp+0x90], xmm10
00007a66921d788b  vmovaps [rsp+0xA0], xmm11
00007a66921d7894  vmovaps [rsp+0xB0], xmm12
00007a66921d789d  vmovaps [rsp+0xC0], xmm13
00007a66921d78a6  vmovaps [rsp+0xD0], xmm14
00007a66921d78af  vmovaps [rsp+0xE0], xmm15
00007a66921d78b8  sub rsp, 0x30
00007a66921d78bc  movaps [rsp], xmm4
00007a66921d78c0  movaps [rsp+0x10], xmm15
00007a66921d78c6  movaps [rsp+0x20], xmm9
00007a66921d78cc  lea rdi, [rsp]
00007a66921d78d0  mov esi, 0x00
00007a66921d78d5  mov rax, 0x635346DC7530
00007a66921d78df  call rax
00007a66921d78e1  movaps xmm4, [rsp]
00007a66921d78e5  add rsp, 0x30
00007a66921d78e9  vmovaps xmm0, [rsp]
00007a66921d78ee  vmovaps xmm1, [rsp+0x10]
00007a66921d78f4  vmovaps xmm2, [rsp+0x20]
00007a66921d78fa  vmovaps xmm3, [rsp+0x30]
00007a66921d7900  vmovaps xmm5, [rsp+0x40]
00007a66921d7906  vmovaps xmm6, [rsp+0x50]
00007a66921d790c  vmovaps xmm7, [rsp+0x60]
00007a66921d7912  vmovaps xmm8, [rsp+0x70]
00007a66921d7918  vmovaps xmm9, [rsp+0x80]
00007a66921d7921  vmovaps xmm10, [rsp+0x90]
00007a66921d792a  vmovaps xmm11, [rsp+0xA0]
00007a66921d7933  vmovaps xmm12, [rsp+0xB0]
00007a66921d793c  vmovaps xmm13, [rsp+0xC0]
00007a66921d7945  vmovaps xmm14, [rsp+0xD0]
00007a66921d794e  vmovaps xmm15, [rsp+0xE0]
00007a66921d7957  add rsp, 0xF0
00007a66921d795e  pop r11
00007a66921d7960  pop r10
00007a66921d7962  pop r9
00007a66921d7964  pop r8
00007a66921d7966  pop rsi
00007a66921d7967  pop rdi
00007a66921d7968  pop rdx
00007a66921d7969  pop rcx
00007a66921d796a  pop rax
00007a66921d796b  add rsp, 0x08
00007a66921d796f  jmp 0x00007A66921D5CF9
00007a66921d7974  call 0x00007A66920E5820
00007a66921d7979  jmp 0x00007A66921D5D06
00007a66921d797e  sub rsp, 0x08
00007a66921d7982  push rax
00007a66921d7983  push rcx
00007a66921d7984  push rdx
00007a66921d7985  push rdi
00007a66921d7986  push rsi
00007a66921d7987  push r8
00007a66921d7989  push r9
00007a66921d798b  push r10
00007a66921d798d  push r11
00007a66921d798f  sub rsp, 0xF0
00007a66921d7996  vmovaps [rsp], xmm0
00007a66921d799b  vmovaps [rsp+0x10], xmm1
00007a66921d79a1  vmovaps [rsp+0x20], xmm2
00007a66921d79a7  vmovaps [rsp+0x30], xmm4
00007a66921d79ad  vmovaps [rsp+0x40], xmm5
00007a66921d79b3  vmovaps [rsp+0x50], xmm6
00007a66921d79b9  vmovaps [rsp+0x60], xmm7
00007a66921d79bf  vmovaps [rsp+0x70], xmm8
00007a66921d79c5  vmovaps [rsp+0x80], xmm9
00007a66921d79ce  vmovaps [rsp+0x90], xmm10
00007a66921d79d7  vmovaps [rsp+0xA0], xmm11
00007a66921d79e0  vmovaps [rsp+0xB0], xmm12
00007a66921d79e9  vmovaps [rsp+0xC0], xmm13
00007a66921d79f2  vmovaps [rsp+0xD0], xmm14
00007a66921d79fb  vmovaps [rsp+0xE0], xmm15
00007a66921d7a04  sub rsp, 0x30
00007a66921d7a08  movaps [rsp], xmm3
00007a66921d7a0c  movaps [rsp+0x10], xmm1
00007a66921d7a11  movaps [rsp+0x20], xmm9
00007a66921d7a17  lea rdi, [rsp]
00007a66921d7a1b  mov esi, 0x00
00007a66921d7a20  mov rax, 0x635346DC7530
00007a66921d7a2a  call rax
00007a66921d7a2c  movaps xmm3, [rsp]
00007a66921d7a30  add rsp, 0x30
00007a66921d7a34  vmovaps xmm0, [rsp]
00007a66921d7a39  vmovaps xmm1, [rsp+0x10]
00007a66921d7a3f  vmovaps xmm2, [rsp+0x20]
00007a66921d7a45  vmovaps xmm4, [rsp+0x30]
00007a66921d7a4b  vmovaps xmm5, [rsp+0x40]
00007a66921d7a51  vmovaps xmm6, [rsp+0x50]
00007a66921d7a57  vmovaps xmm7, [rsp+0x60]
00007a66921d7a5d  vmovaps xmm8, [rsp+0x70]
00007a66921d7a63  vmovaps xmm9, [rsp+0x80]
00007a66921d7a6c  vmovaps xmm10, [rsp+0x90]
00007a66921d7a75  vmovaps xmm11, [rsp+0xA0]
00007a66921d7a7e  vmovaps xmm12, [rsp+0xB0]
00007a66921d7a87  vmovaps xmm13, [rsp+0xC0]
00007a66921d7a90  vmovaps xmm14, [rsp+0xD0]
00007a66921d7a99  vmovaps xmm15, [rsp+0xE0]
00007a66921d7aa2  add rsp, 0xF0
00007a66921d7aa9  pop r11
00007a66921d7aab  pop r10
00007a66921d7aad  pop r9
00007a66921d7aaf  pop r8
00007a66921d7ab1  pop rsi
00007a66921d7ab2  pop rdi
00007a66921d7ab3  pop rdx
00007a66921d7ab4  pop rcx
00007a66921d7ab5  pop rax
00007a66921d7ab6  add rsp, 0x08
00007a66921d7aba  jmp 0x00007A66921D5D43
00007a66921d7abf  sub rsp, 0x08
00007a66921d7ac3  push rax
00007a66921d7ac4  push rcx
00007a66921d7ac5  push rdx
00007a66921d7ac6  push rdi
00007a66921d7ac7  push rsi
00007a66921d7ac8  push r8
00007a66921d7aca  push r9
00007a66921d7acc  push r10
00007a66921d7ace  push r11
00007a66921d7ad0  sub rsp, 0xF0
00007a66921d7ad7  vmovaps [rsp], xmm0
00007a66921d7adc  vmovaps [rsp+0x10], xmm2
00007a66921d7ae2  vmovaps [rsp+0x20], xmm3
00007a66921d7ae8  vmovaps [rsp+0x30], xmm4
00007a66921d7aee  vmovaps [rsp+0x40], xmm5
00007a66921d7af4  vmovaps [rsp+0x50], xmm6
00007a66921d7afa  vmovaps [rsp+0x60], xmm7
00007a66921d7b00  vmovaps [rsp+0x70], xmm8
00007a66921d7b06  vmovaps [rsp+0x80], xmm9
00007a66921d7b0f  vmovaps [rsp+0x90], xmm10
00007a66921d7b18  vmovaps [rsp+0xA0], xmm11
00007a66921d7b21  vmovaps [rsp+0xB0], xmm12
00007a66921d7b2a  vmovaps [rsp+0xC0], xmm13
00007a66921d7b33  vmovaps [rsp+0xD0], xmm14
00007a66921d7b3c  vmovaps [rsp+0xE0], xmm15
00007a66921d7b45  sub rsp, 0x30
00007a66921d7b49  movaps [rsp], xmm1
00007a66921d7b4d  movaps [rsp+0x10], xmm15
00007a66921d7b53  movaps [rsp+0x20], xmm9
00007a66921d7b59  lea rdi, [rsp]
00007a66921d7b5d  mov esi, 0x00
00007a66921d7b62  mov rax, 0x635346DC7530
00007a66921d7b6c  call rax
00007a66921d7b6e  movaps xmm1, [rsp]
00007a66921d7b72  add rsp, 0x30
00007a66921d7b76  vmovaps xmm0, [rsp]
00007a66921d7b7b  vmovaps xmm2, [rsp+0x10]
00007a66921d7b81  vmovaps xmm3, [rsp+0x20]
00007a66921d7b87  vmovaps xmm4, [rsp+0x30]
00007a66921d7b8d  vmovaps xmm5, [rsp+0x40]
00007a66921d7b93  vmovaps xmm6, [rsp+0x50]
00007a66921d7b99  vmovaps xmm7, [rsp+0x60]
00007a66921d7b9f  vmovaps xmm8, [rsp+0x70]
00007a66921d7ba5  vmovaps xmm9, [rsp+0x80]
00007a66921d7bae  vmovaps xmm10, [rsp+0x90]
00007a66921d7bb7  vmovaps xmm11, [rsp+0xA0]
00007a66921d7bc0  vmovaps xmm12, [rsp+0xB0]
00007a66921d7bc9  vmovaps xmm13, [rsp+0xC0]
00007a66921d7bd2  vmovaps xmm14, [rsp+0xD0]
00007a66921d7bdb  vmovaps xmm15, [rsp+0xE0]
00007a66921d7be4  add rsp, 0xF0
00007a66921d7beb  pop r11
00007a66921d7bed  pop r10
00007a66921d7bef  pop r9
00007a66921d7bf1  pop r8
00007a66921d7bf3  pop rsi
00007a66921d7bf4  pop rdi
00007a66921d7bf5  pop rdx
00007a66921d7bf6  pop rcx
00007a66921d7bf7  pop rax
00007a66921d7bf8  add rsp, 0x08
00007a66921d7bfc  jmp 0x00007A66921D5DCB
00007a66921d7c01  call 0x00007A66920E5820
00007a66921d7c06  jmp 0x00007A66921D5DD8
00007a66921d7c0b  sub rsp, 0x08
00007a66921d7c0f  push rax
00007a66921d7c10  push rcx
00007a66921d7c11  push rdx
00007a66921d7c12  push rdi
00007a66921d7c13  push rsi
00007a66921d7c14  push r8
00007a66921d7c16  push r9
00007a66921d7c18  push r10
00007a66921d7c1a  push r11
00007a66921d7c1c  sub rsp, 0xF0
00007a66921d7c23  vmovaps [rsp], xmm0
00007a66921d7c28  vmovaps [rsp+0x10], xmm2
00007a66921d7c2e  vmovaps [rsp+0x20], xmm3
00007a66921d7c34  vmovaps [rsp+0x30], xmm4
00007a66921d7c3a  vmovaps [rsp+0x40], xmm5
00007a66921d7c40  vmovaps [rsp+0x50], xmm6
00007a66921d7c46  vmovaps [rsp+0x60], xmm7
00007a66921d7c4c  vmovaps [rsp+0x70], xmm8
00007a66921d7c52  vmovaps [rsp+0x80], xmm9
00007a66921d7c5b  vmovaps [rsp+0x90], xmm10
00007a66921d7c64  vmovaps [rsp+0xA0], xmm11
00007a66921d7c6d  vmovaps [rsp+0xB0], xmm12
00007a66921d7c76  vmovaps [rsp+0xC0], xmm13
00007a66921d7c7f  vmovaps [rsp+0xD0], xmm14
00007a66921d7c88  vmovaps [rsp+0xE0], xmm15
00007a66921d7c91  sub rsp, 0x30
00007a66921d7c95  movaps [rsp], xmm1
00007a66921d7c99  movaps [rsp+0x10], xmm5
00007a66921d7c9e  movaps [rsp+0x20], xmm7
00007a66921d7ca3  lea rdi, [rsp]
00007a66921d7ca7  mov esi, 0x00
00007a66921d7cac  mov rax, 0x635346DC7530
00007a66921d7cb6  call rax
00007a66921d7cb8  movaps xmm1, [rsp]
00007a66921d7cbc  add rsp, 0x30
00007a66921d7cc0  vmovaps xmm0, [rsp]
00007a66921d7cc5  vmovaps xmm2, [rsp+0x10]
00007a66921d7ccb  vmovaps xmm3, [rsp+0x20]
00007a66921d7cd1  vmovaps xmm4, [rsp+0x30]
00007a66921d7cd7  vmovaps xmm5, [rsp+0x40]
00007a66921d7cdd  vmovaps xmm6, [rsp+0x50]
00007a66921d7ce3  vmovaps xmm7, [rsp+0x60]
00007a66921d7ce9  vmovaps xmm8, [rsp+0x70]
00007a66921d7cef  vmovaps xmm9, [rsp+0x80]
00007a66921d7cf8  vmovaps xmm10, [rsp+0x90]
00007a66921d7d01  vmovaps xmm11, [rsp+0xA0]
00007a66921d7d0a  vmovaps xmm12, [rsp+0xB0]
00007a66921d7d13  vmovaps xmm13, [rsp+0xC0]
00007a66921d7d1c  vmovaps xmm14, [rsp+0xD0]
00007a66921d7d25  vmovaps xmm15, [rsp+0xE0]
00007a66921d7d2e  add rsp, 0xF0
00007a66921d7d35  pop r11
00007a66921d7d37  pop r10
00007a66921d7d39  pop r9
00007a66921d7d3b  pop r8
00007a66921d7d3d  pop rsi
00007a66921d7d3e  pop rdi
00007a66921d7d3f  pop rdx
00007a66921d7d40  pop rcx
00007a66921d7d41  pop rax
00007a66921d7d42  add rsp, 0x08
00007a66921d7d46  jmp 0x00007A66921D5E7D
00007a66921d7d4b  sub rsp, 0x08
00007a66921d7d4f  push rax
00007a66921d7d50  push rcx
00007a66921d7d51  push rdx
00007a66921d7d52  push rdi
00007a66921d7d53  push rsi
00007a66921d7d54  push r8
00007a66921d7d56  push r9
00007a66921d7d58  push r10
00007a66921d7d5a  push r11
00007a66921d7d5c  sub rsp, 0xF0
00007a66921d7d63  vmovaps [rsp], xmm0
00007a66921d7d68  vmovaps [rsp+0x10], xmm1
00007a66921d7d6e  vmovaps [rsp+0x20], xmm2
00007a66921d7d74  vmovaps [rsp+0x30], xmm3
00007a66921d7d7a  vmovaps [rsp+0x40], xmm4
00007a66921d7d80  vmovaps [rsp+0x50], xmm5
00007a66921d7d86  vmovaps [rsp+0x60], xmm6
00007a66921d7d8c  vmovaps [rsp+0x70], xmm8
00007a66921d7d92  vmovaps [rsp+0x80], xmm9
00007a66921d7d9b  vmovaps [rsp+0x90], xmm10
00007a66921d7da4  vmovaps [rsp+0xA0], xmm11
00007a66921d7dad  vmovaps [rsp+0xB0], xmm12
00007a66921d7db6  vmovaps [rsp+0xC0], xmm13
00007a66921d7dbf  vmovaps [rsp+0xD0], xmm14
00007a66921d7dc8  vmovaps [rsp+0xE0], xmm15
00007a66921d7dd1  sub rsp, 0x30
00007a66921d7dd5  movaps [rsp], xmm7
00007a66921d7dd9  movaps [rsp+0x10], xmm5
00007a66921d7dde  movaps [rsp+0x20], xmm15
00007a66921d7de4  lea rdi, [rsp]
00007a66921d7de8  mov esi, 0x00
00007a66921d7ded  mov rax, 0x635346DC7530
00007a66921d7df7  call rax
00007a66921d7df9  movaps xmm7, [rsp]
00007a66921d7dfd  add rsp, 0x30
00007a66921d7e01  vmovaps xmm0, [rsp]
00007a66921d7e06  vmovaps xmm1, [rsp+0x10]
00007a66921d7e0c  vmovaps xmm2, [rsp+0x20]
00007a66921d7e12  vmovaps xmm3, [rsp+0x30]
00007a66921d7e18  vmovaps xmm4, [rsp+0x40]
00007a66921d7e1e  vmovaps xmm5, [rsp+0x50]
00007a66921d7e24  vmovaps xmm6, [rsp+0x60]
00007a66921d7e2a  vmovaps xmm8, [rsp+0x70]
00007a66921d7e30  vmovaps xmm9, [rsp+0x80]
00007a66921d7e39  vmovaps xmm10, [rsp+0x90]
00007a66921d7e42  vmovaps xmm11, [rsp+0xA0]
00007a66921d7e4b  vmovaps xmm12, [rsp+0xB0]
00007a66921d7e54  vmovaps xmm13, [rsp+0xC0]
00007a66921d7e5d  vmovaps xmm14, [rsp+0xD0]
00007a66921d7e66  vmovaps xmm15, [rsp+0xE0]
00007a66921d7e6f  add rsp, 0xF0
00007a66921d7e76  pop r11
00007a66921d7e78  pop r10
00007a66921d7e7a  pop r9
00007a66921d7e7c  pop r8
00007a66921d7e7e  pop rsi
00007a66921d7e7f  pop rdi
00007a66921d7e80  pop rdx
00007a66921d7e81  pop rcx
00007a66921d7e82  pop rax
00007a66921d7e83  add rsp, 0x08
00007a66921d7e87  jmp 0x00007A66921D5EB3
00007a66921d7e8c  call 0x00007A66920D64F0
00007a66921d7e91  jmp 0x00007A66921D5EC0
00007a66921d7e96  sub rsp, 0x08
00007a66921d7e9a  push rax
00007a66921d7e9b  push rcx
00007a66921d7e9c  push rdx
00007a66921d7e9d  push rdi
00007a66921d7e9e  push rsi
00007a66921d7e9f  push r8
00007a66921d7ea1  push r9
00007a66921d7ea3  push r10
00007a66921d7ea5  push r11
00007a66921d7ea7  sub rsp, 0xF0
00007a66921d7eae  vmovaps [rsp], xmm0
00007a66921d7eb3  vmovaps [rsp+0x10], xmm1
00007a66921d7eb9  vmovaps [rsp+0x20], xmm2
00007a66921d7ebf  vmovaps [rsp+0x30], xmm3
00007a66921d7ec5  vmovaps [rsp+0x40], xmm4
00007a66921d7ecb  vmovaps [rsp+0x50], xmm5
00007a66921d7ed1  vmovaps [rsp+0x60], xmm6
00007a66921d7ed7  vmovaps [rsp+0x70], xmm7
00007a66921d7edd  vmovaps [rsp+0x80], xmm8
00007a66921d7ee6  vmovaps [rsp+0x90], xmm9
00007a66921d7eef  vmovaps [rsp+0xA0], xmm10
00007a66921d7ef8  vmovaps [rsp+0xB0], xmm11
00007a66921d7f01  vmovaps [rsp+0xC0], xmm12
00007a66921d7f0a  vmovaps [rsp+0xD0], xmm13
00007a66921d7f13  vmovaps [rsp+0xE0], xmm14
00007a66921d7f1c  sub rsp, 0x30
00007a66921d7f20  movaps [rsp], xmm15
00007a66921d7f25  movaps [rsp+0x10], xmm5
00007a66921d7f2a  movaps [rsp+0x20], xmm3
00007a66921d7f2f  lea rdi, [rsp]
00007a66921d7f33  mov esi, 0x00
00007a66921d7f38  mov rax, 0x635346DC7530
00007a66921d7f42  call rax
00007a66921d7f44  movaps xmm15, [rsp]
00007a66921d7f49  add rsp, 0x30
00007a66921d7f4d  vmovaps xmm0, [rsp]
00007a66921d7f52  vmovaps xmm1, [rsp+0x10]
00007a66921d7f58  vmovaps xmm2, [rsp+0x20]
00007a66921d7f5e  vmovaps xmm3, [rsp+0x30]
00007a66921d7f64  vmovaps xmm4, [rsp+0x40]
00007a66921d7f6a  vmovaps xmm5, [rsp+0x50]
00007a66921d7f70  vmovaps xmm6, [rsp+0x60]
00007a66921d7f76  vmovaps xmm7, [rsp+0x70]
00007a66921d7f7c  vmovaps xmm8, [rsp+0x80]
00007a66921d7f85  vmovaps xmm9, [rsp+0x90]
00007a66921d7f8e  vmovaps xmm10, [rsp+0xA0]
00007a66921d7f97  vmovaps xmm11, [rsp+0xB0]
00007a66921d7fa0  vmovaps xmm12, [rsp+0xC0]
00007a66921d7fa9  vmovaps xmm13, [rsp+0xD0]
00007a66921d7fb2  vmovaps xmm14, [rsp+0xE0]
00007a66921d7fbb  add rsp, 0xF0
00007a66921d7fc2  pop r11
00007a66921d7fc4  pop r10
00007a66921d7fc6  pop r9
00007a66921d7fc8  pop r8
00007a66921d7fca  pop rsi
00007a66921d7fcb  pop rdi
00007a66921d7fcc  pop rdx
00007a66921d7fcd  pop rcx
00007a66921d7fce  pop rax
00007a66921d7fcf  add rsp, 0x08
00007a66921d7fd3  jmp 0x00007A66921D5EE6
00007a66921d7fd8  sub rsp, 0x08
00007a66921d7fdc  push rax
00007a66921d7fdd  push rcx
00007a66921d7fde  push rdx
00007a66921d7fdf  push rdi
00007a66921d7fe0  push rsi
00007a66921d7fe1  push r8
00007a66921d7fe3  push r9
00007a66921d7fe5  push r10
00007a66921d7fe7  push r11
00007a66921d7fe9  sub rsp, 0xF0
00007a66921d7ff0  vmovaps [rsp], xmm0
00007a66921d7ff5  vmovaps [rsp+0x10], xmm2
00007a66921d7ffb  vmovaps [rsp+0x20], xmm3
00007a66921d8001  vmovaps [rsp+0x30], xmm4
00007a66921d8007  vmovaps [rsp+0x40], xmm5
00007a66921d800d  vmovaps [rsp+0x50], xmm6
00007a66921d8013  vmovaps [rsp+0x60], xmm7
00007a66921d8019  vmovaps [rsp+0x70], xmm8
00007a66921d801f  vmovaps [rsp+0x80], xmm9
00007a66921d8028  vmovaps [rsp+0x90], xmm10
00007a66921d8031  vmovaps [rsp+0xA0], xmm11
00007a66921d803a  vmovaps [rsp+0xB0], xmm12
00007a66921d8043  vmovaps [rsp+0xC0], xmm13
00007a66921d804c  vmovaps [rsp+0xD0], xmm14
00007a66921d8055  vmovaps [rsp+0xE0], xmm15
00007a66921d805e  sub rsp, 0x30
00007a66921d8062  movaps [rsp], xmm1
00007a66921d8066  movaps [rsp+0x10], xmm5
00007a66921d806b  movaps [rsp+0x20], xmm4
00007a66921d8070  lea rdi, [rsp]
00007a66921d8074  mov esi, 0x00
00007a66921d8079  mov rax, 0x635346DC7530
00007a66921d8083  call rax
00007a66921d8085  movaps xmm1, [rsp]
00007a66921d8089  add rsp, 0x30
00007a66921d808d  vmovaps xmm0, [rsp]
00007a66921d8092  vmovaps xmm2, [rsp+0x10]
00007a66921d8098  vmovaps xmm3, [rsp+0x20]
00007a66921d809e  vmovaps xmm4, [rsp+0x30]
00007a66921d80a4  vmovaps xmm5, [rsp+0x40]
00007a66921d80aa  vmovaps xmm6, [rsp+0x50]
00007a66921d80b0  vmovaps xmm7, [rsp+0x60]
00007a66921d80b6  vmovaps xmm8, [rsp+0x70]
00007a66921d80bc  vmovaps xmm9, [rsp+0x80]
00007a66921d80c5  vmovaps xmm10, [rsp+0x90]
00007a66921d80ce  vmovaps xmm11, [rsp+0xA0]
00007a66921d80d7  vmovaps xmm12, [rsp+0xB0]
00007a66921d80e0  vmovaps xmm13, [rsp+0xC0]
00007a66921d80e9  vmovaps xmm14, [rsp+0xD0]
00007a66921d80f2  vmovaps xmm15, [rsp+0xE0]
00007a66921d80fb  add rsp, 0xF0
00007a66921d8102  pop r11
00007a66921d8104  pop r10
00007a66921d8106  pop r9
00007a66921d8108  pop r8
00007a66921d810a  pop rsi
00007a66921d810b  pop rdi
00007a66921d810c  pop rdx
00007a66921d810d  pop rcx
00007a66921d810e  pop rax
00007a66921d810f  add rsp, 0x08
00007a66921d8113  jmp 0x00007A66921D5F06
00007a66921d8118  sub rsp, 0x08
00007a66921d811c  push rax
00007a66921d811d  push rcx
00007a66921d811e  push rdx
00007a66921d811f  push rdi
00007a66921d8120  push rsi
00007a66921d8121  push r8
00007a66921d8123  push r9
00007a66921d8125  push r10
00007a66921d8127  push r11
00007a66921d8129  sub rsp, 0xF0
00007a66921d8130  vmovaps [rsp], xmm0
00007a66921d8135  vmovaps [rsp+0x10], xmm1
00007a66921d813b  vmovaps [rsp+0x20], xmm2
00007a66921d8141  vmovaps [rsp+0x30], xmm3
00007a66921d8147  vmovaps [rsp+0x40], xmm5
00007a66921d814d  vmovaps [rsp+0x50], xmm6
00007a66921d8153  vmovaps [rsp+0x60], xmm7
00007a66921d8159  vmovaps [rsp+0x70], xmm8
00007a66921d815f  vmovaps [rsp+0x80], xmm9
00007a66921d8168  vmovaps [rsp+0x90], xmm10
00007a66921d8171  vmovaps [rsp+0xA0], xmm11
00007a66921d817a  vmovaps [rsp+0xB0], xmm12
00007a66921d8183  vmovaps [rsp+0xC0], xmm13
00007a66921d818c  vmovaps [rsp+0xD0], xmm14
00007a66921d8195  vmovaps [rsp+0xE0], xmm15
00007a66921d819e  sub rsp, 0x30
00007a66921d81a2  movaps [rsp], xmm4
00007a66921d81a6  movaps [rsp+0x10], xmm3
00007a66921d81ab  movaps [rsp+0x20], xmm5
00007a66921d81b0  lea rdi, [rsp]
00007a66921d81b4  mov esi, 0x00
00007a66921d81b9  mov rax, 0x635346DC7530
00007a66921d81c3  call rax
00007a66921d81c5  movaps xmm4, [rsp]
00007a66921d81c9  add rsp, 0x30
00007a66921d81cd  vmovaps xmm0, [rsp]
00007a66921d81d2  vmovaps xmm1, [rsp+0x10]
00007a66921d81d8  vmovaps xmm2, [rsp+0x20]
00007a66921d81de  vmovaps xmm3, [rsp+0x30]
00007a66921d81e4  vmovaps xmm5, [rsp+0x40]
00007a66921d81ea  vmovaps xmm6, [rsp+0x50]
00007a66921d81f0  vmovaps xmm7, [rsp+0x60]
00007a66921d81f6  vmovaps xmm8, [rsp+0x70]
00007a66921d81fc  vmovaps xmm9, [rsp+0x80]
00007a66921d8205  vmovaps xmm10, [rsp+0x90]
00007a66921d820e  vmovaps xmm11, [rsp+0xA0]
00007a66921d8217  vmovaps xmm12, [rsp+0xB0]
00007a66921d8220  vmovaps xmm13, [rsp+0xC0]
00007a66921d8229  vmovaps xmm14, [rsp+0xD0]
00007a66921d8232  vmovaps xmm15, [rsp+0xE0]
00007a66921d823b  add rsp, 0xF0
00007a66921d8242  pop r11
00007a66921d8244  pop r10
00007a66921d8246  pop r9
00007a66921d8248  pop r8
00007a66921d824a  pop rsi
00007a66921d824b  pop rdi
00007a66921d824c  pop rdx
00007a66921d824d  pop rcx
00007a66921d824e  pop rax
00007a66921d824f  add rsp, 0x08
00007a66921d8253  jmp 0x00007A66921D5F54
00007a66921d8258  call 0x00007A66920D64F0
00007a66921d825d  jmp 0x00007A66921D5F61
00007a66921d8262  sub rsp, 0x08
00007a66921d8266  push rax
00007a66921d8267  push rcx
00007a66921d8268  push rdx
00007a66921d8269  push rdi
00007a66921d826a  push rsi
00007a66921d826b  push r8
00007a66921d826d  push r9
00007a66921d826f  push r10
00007a66921d8271  push r11
00007a66921d8273  sub rsp, 0xF0
00007a66921d827a  vmovaps [rsp], xmm0
00007a66921d827f  vmovaps [rsp+0x10], xmm1
00007a66921d8285  vmovaps [rsp+0x20], xmm2
00007a66921d828b  vmovaps [rsp+0x30], xmm3
00007a66921d8291  vmovaps [rsp+0x40], xmm4
00007a66921d8297  vmovaps [rsp+0x50], xmm6
00007a66921d829d  vmovaps [rsp+0x60], xmm7
00007a66921d82a3  vmovaps [rsp+0x70], xmm8
00007a66921d82a9  vmovaps [rsp+0x80], xmm9
00007a66921d82b2  vmovaps [rsp+0x90], xmm10
00007a66921d82bb  vmovaps [rsp+0xA0], xmm11
00007a66921d82c4  vmovaps [rsp+0xB0], xmm12
00007a66921d82cd  vmovaps [rsp+0xC0], xmm13
00007a66921d82d6  vmovaps [rsp+0xD0], xmm14
00007a66921d82df  vmovaps [rsp+0xE0], xmm15
00007a66921d82e8  sub rsp, 0x30
00007a66921d82ec  movaps [rsp], xmm5
00007a66921d82f0  movaps [rsp+0x10], xmm6
00007a66921d82f5  movaps [rsp+0x20], xmm3
00007a66921d82fa  lea rdi, [rsp]
00007a66921d82fe  mov esi, 0x00
00007a66921d8303  mov rax, 0x635346DC7530
00007a66921d830d  call rax
00007a66921d830f  movaps xmm5, [rsp]
00007a66921d8313  add rsp, 0x30
00007a66921d8317  vmovaps xmm0, [rsp]
00007a66921d831c  vmovaps xmm1, [rsp+0x10]
00007a66921d8322  vmovaps xmm2, [rsp+0x20]
00007a66921d8328  vmovaps xmm3, [rsp+0x30]
00007a66921d832e  vmovaps xmm4, [rsp+0x40]
00007a66921d8334  vmovaps xmm6, [rsp+0x50]
00007a66921d833a  vmovaps xmm7, [rsp+0x60]
00007a66921d8340  vmovaps xmm8, [rsp+0x70]
00007a66921d8346  vmovaps xmm9, [rsp+0x80]
00007a66921d834f  vmovaps xmm10, [rsp+0x90]
00007a66921d8358  vmovaps xmm11, [rsp+0xA0]
00007a66921d8361  vmovaps xmm12, [rsp+0xB0]
00007a66921d836a  vmovaps xmm13, [rsp+0xC0]
00007a66921d8373  vmovaps xmm14, [rsp+0xD0]
00007a66921d837c  vmovaps xmm15, [rsp+0xE0]
00007a66921d8385  add rsp, 0xF0
00007a66921d838c  pop r11
00007a66921d838e  pop r10
00007a66921d8390  pop r9
00007a66921d8392  pop r8
00007a66921d8394  pop rsi
00007a66921d8395  pop rdi
00007a66921d8396  pop rdx
00007a66921d8397  pop rcx
00007a66921d8398  pop rax
00007a66921d8399  add rsp, 0x08
00007a66921d839d  jmp 0x00007A66921D5F87
00007a66921d83a2  sub rsp, 0x08
00007a66921d83a6  push rax
00007a66921d83a7  push rcx
00007a66921d83a8  push rdx
00007a66921d83a9  push rdi
00007a66921d83aa  push rsi
00007a66921d83ab  push r8
00007a66921d83ad  push r9
00007a66921d83af  push r10
00007a66921d83b1  push r11
00007a66921d83b3  sub rsp, 0xF0
00007a66921d83ba  vmovaps [rsp], xmm0
00007a66921d83bf  vmovaps [rsp+0x10], xmm1
00007a66921d83c5  vmovaps [rsp+0x20], xmm2
00007a66921d83cb  vmovaps [rsp+0x30], xmm3
00007a66921d83d1  vmovaps [rsp+0x40], xmm4
00007a66921d83d7  vmovaps [rsp+0x50], xmm5
00007a66921d83dd  vmovaps [rsp+0x60], xmm7
00007a66921d83e3  vmovaps [rsp+0x70], xmm8
00007a66921d83e9  vmovaps [rsp+0x80], xmm9
00007a66921d83f2  vmovaps [rsp+0x90], xmm10
00007a66921d83fb  vmovaps [rsp+0xA0], xmm11
00007a66921d8404  vmovaps [rsp+0xB0], xmm12
00007a66921d840d  vmovaps [rsp+0xC0], xmm13
00007a66921d8416  vmovaps [rsp+0xD0], xmm14
00007a66921d841f  vmovaps [rsp+0xE0], xmm15
00007a66921d8428  sub rsp, 0x30
00007a66921d842c  movaps [rsp], xmm6
00007a66921d8430  movaps [rsp+0x10], xmm9
00007a66921d8436  movaps [rsp+0x20], xmm1
00007a66921d843b  lea rdi, [rsp]
00007a66921d843f  mov esi, 0x00
00007a66921d8444  mov rax, 0x635346DC7530
00007a66921d844e  call rax
00007a66921d8450  movaps xmm6, [rsp]
00007a66921d8454  add rsp, 0x30
00007a66921d8458  vmovaps xmm0, [rsp]
00007a66921d845d  vmovaps xmm1, [rsp+0x10]
00007a66921d8463  vmovaps xmm2, [rsp+0x20]
00007a66921d8469  vmovaps xmm3, [rsp+0x30]
00007a66921d846f  vmovaps xmm4, [rsp+0x40]
00007a66921d8475  vmovaps xmm5, [rsp+0x50]
00007a66921d847b  vmovaps xmm7, [rsp+0x60]
00007a66921d8481  vmovaps xmm8, [rsp+0x70]
00007a66921d8487  vmovaps xmm9, [rsp+0x80]
00007a66921d8490  vmovaps xmm10, [rsp+0x90]
00007a66921d8499  vmovaps xmm11, [rsp+0xA0]
00007a66921d84a2  vmovaps xmm12, [rsp+0xB0]
00007a66921d84ab  vmovaps xmm13, [rsp+0xC0]
00007a66921d84b4  vmovaps xmm14, [rsp+0xD0]
00007a66921d84bd  vmovaps xmm15, [rsp+0xE0]
00007a66921d84c6  add rsp, 0xF0
00007a66921d84cd  pop r11
00007a66921d84cf  pop r10
00007a66921d84d1  pop r9
00007a66921d84d3  pop r8
00007a66921d84d5  pop rsi
00007a66921d84d6  pop rdi
00007a66921d84d7  pop rdx
00007a66921d84d8  pop rcx
00007a66921d84d9  pop rax
00007a66921d84da  add rsp, 0x08
00007a66921d84de  jmp 0x00007A66921D5FAB
00007a66921d84e3  sub rsp, 0x08
00007a66921d84e7  push rax
00007a66921d84e8  push rcx
00007a66921d84e9  push rdx
00007a66921d84ea  push rdi
00007a66921d84eb  push rsi
00007a66921d84ec  push r8
00007a66921d84ee  push r9
00007a66921d84f0  push r10
00007a66921d84f2  push r11
00007a66921d84f4  sub rsp, 0xF0
00007a66921d84fb  vmovaps [rsp], xmm0
00007a66921d8500  vmovaps [rsp+0x10], xmm1
00007a66921d8506  vmovaps [rsp+0x20], xmm2
00007a66921d850c  vmovaps [rsp+0x30], xmm3
00007a66921d8512  vmovaps [rsp+0x40], xmm4
00007a66921d8518  vmovaps [rsp+0x50], xmm5
00007a66921d851e  vmovaps [rsp+0x60], xmm6
00007a66921d8524  vmovaps [rsp+0x70], xmm7
00007a66921d852a  vmovaps [rsp+0x80], xmm8
00007a66921d8533  vmovaps [rsp+0x90], xmm10
00007a66921d853c  vmovaps [rsp+0xA0], xmm11
00007a66921d8545  vmovaps [rsp+0xB0], xmm12
00007a66921d854e  vmovaps [rsp+0xC0], xmm13
00007a66921d8557  vmovaps [rsp+0xD0], xmm14
00007a66921d8560  vmovaps [rsp+0xE0], xmm15
00007a66921d8569  sub rsp, 0x30
00007a66921d856d  movaps [rsp], xmm9
00007a66921d8572  movaps [rsp+0x10], xmm3
00007a66921d8577  movaps [rsp+0x20], xmm1
00007a66921d857c  lea rdi, [rsp]
00007a66921d8580  mov esi, 0x00
00007a66921d8585  mov rax, 0x635346DC7530
00007a66921d858f  call rax
00007a66921d8591  movaps xmm9, [rsp]
00007a66921d8596  add rsp, 0x30
00007a66921d859a  vmovaps xmm0, [rsp]
00007a66921d859f  vmovaps xmm1, [rsp+0x10]
00007a66921d85a5  vmovaps xmm2, [rsp+0x20]
00007a66921d85ab  vmovaps xmm3, [rsp+0x30]
00007a66921d85b1  vmovaps xmm4, [rsp+0x40]
00007a66921d85b7  vmovaps xmm5, [rsp+0x50]
00007a66921d85bd  vmovaps xmm6, [rsp+0x60]
00007a66921d85c3  vmovaps xmm7, [rsp+0x70]
00007a66921d85c9  vmovaps xmm8, [rsp+0x80]
00007a66921d85d2  vmovaps xmm10, [rsp+0x90]
00007a66921d85db  vmovaps xmm11, [rsp+0xA0]
00007a66921d85e4  vmovaps xmm12, [rsp+0xB0]
00007a66921d85ed  vmovaps xmm13, [rsp+0xC0]
00007a66921d85f6  vmovaps xmm14, [rsp+0xD0]
00007a66921d85ff  vmovaps xmm15, [rsp+0xE0]
00007a66921d8608  add rsp, 0xF0
00007a66921d860f  pop r11
00007a66921d8611  pop r10
00007a66921d8613  pop r9
00007a66921d8615  pop r8
00007a66921d8617  pop rsi
00007a66921d8618  pop rdi
00007a66921d8619  pop rdx
00007a66921d861a  pop rcx
00007a66921d861b  pop rax
00007a66921d861c  add rsp, 0x08
00007a66921d8620  jmp 0x00007A66921D5FF7
00007a66921d8625  call 0x00007A66920D64F0
00007a66921d862a  jmp 0x00007A66921D6004
00007a66921d862f  sub rsp, 0x08
00007a66921d8633  push rax
00007a66921d8634  push rcx
00007a66921d8635  push rdx
00007a66921d8636  push rdi
00007a66921d8637  push rsi
00007a66921d8638  push r8
00007a66921d863a  push r9
00007a66921d863c  push r10
00007a66921d863e  push r11
00007a66921d8640  sub rsp, 0xF0
00007a66921d8647  vmovaps [rsp], xmm0
00007a66921d864c  vmovaps [rsp+0x10], xmm1
00007a66921d8652  vmovaps [rsp+0x20], xmm2
00007a66921d8658  vmovaps [rsp+0x30], xmm3
00007a66921d865e  vmovaps [rsp+0x40], xmm4
00007a66921d8664  vmovaps [rsp+0x50], xmm5
00007a66921d866a  vmovaps [rsp+0x60], xmm6
00007a66921d8670  vmovaps [rsp+0x70], xmm7
00007a66921d8676  vmovaps [rsp+0x80], xmm8
00007a66921d867f  vmovaps [rsp+0x90], xmm9
00007a66921d8688  vmovaps [rsp+0xA0], xmm10
00007a66921d8691  vmovaps [rsp+0xB0], xmm11
00007a66921d869a  vmovaps [rsp+0xC0], xmm12
00007a66921d86a3  vmovaps [rsp+0xD0], xmm13
00007a66921d86ac  vmovaps [rsp+0xE0], xmm14
00007a66921d86b5  sub rsp, 0x30
00007a66921d86b9  movaps [rsp], xmm15
00007a66921d86be  movaps [rsp+0x10], xmm3
00007a66921d86c3  movaps [rsp+0x20], xmm7
00007a66921d86c8  lea rdi, [rsp]
00007a66921d86cc  mov esi, 0x00
00007a66921d86d1  mov rax, 0x635346DC7530
00007a66921d86db  call rax
00007a66921d86dd  movaps xmm15, [rsp]
00007a66921d86e2  add rsp, 0x30
00007a66921d86e6  vmovaps xmm0, [rsp]
00007a66921d86eb  vmovaps xmm1, [rsp+0x10]
00007a66921d86f1  vmovaps xmm2, [rsp+0x20]
00007a66921d86f7  vmovaps xmm3, [rsp+0x30]
00007a66921d86fd  vmovaps xmm4, [rsp+0x40]
00007a66921d8703  vmovaps xmm5, [rsp+0x50]
00007a66921d8709  vmovaps xmm6, [rsp+0x60]
00007a66921d870f  vmovaps xmm7, [rsp+0x70]
00007a66921d8715  vmovaps xmm8, [rsp+0x80]
00007a66921d871e  vmovaps xmm9, [rsp+0x90]
00007a66921d8727  vmovaps xmm10, [rsp+0xA0]
00007a66921d8730  vmovaps xmm11, [rsp+0xB0]
00007a66921d8739  vmovaps xmm12, [rsp+0xC0]
00007a66921d8742  vmovaps xmm13, [rsp+0xD0]
00007a66921d874b  vmovaps xmm14, [rsp+0xE0]
00007a66921d8754  add rsp, 0xF0
00007a66921d875b  pop r11
00007a66921d875d  pop r10
00007a66921d875f  pop r9
00007a66921d8761  pop r8
00007a66921d8763  pop rsi
00007a66921d8764  pop rdi
00007a66921d8765  pop rdx
00007a66921d8766  pop rcx
00007a66921d8767  pop rax
00007a66921d8768  add rsp, 0x08
00007a66921d876c  jmp 0x00007A66921D6030
00007a66921d8771  sub rsp, 0x08
00007a66921d8775  push rax
00007a66921d8776  push rcx
00007a66921d8777  push rdx
00007a66921d8778  push rdi
00007a66921d8779  push rsi
00007a66921d877a  push r8
00007a66921d877c  push r9
00007a66921d877e  push r10
00007a66921d8780  push r11
00007a66921d8782  sub rsp, 0xF0
00007a66921d8789  vmovaps [rsp], xmm0
00007a66921d878e  vmovaps [rsp+0x10], xmm1
00007a66921d8794  vmovaps [rsp+0x20], xmm2
00007a66921d879a  vmovaps [rsp+0x30], xmm4
00007a66921d87a0  vmovaps [rsp+0x40], xmm5
00007a66921d87a6  vmovaps [rsp+0x50], xmm6
00007a66921d87ac  vmovaps [rsp+0x60], xmm7
00007a66921d87b2  vmovaps [rsp+0x70], xmm8
00007a66921d87b8  vmovaps [rsp+0x80], xmm9
00007a66921d87c1  vmovaps [rsp+0x90], xmm10
00007a66921d87ca  vmovaps [rsp+0xA0], xmm11
00007a66921d87d3  vmovaps [rsp+0xB0], xmm12
00007a66921d87dc  vmovaps [rsp+0xC0], xmm13
00007a66921d87e5  vmovaps [rsp+0xD0], xmm14
00007a66921d87ee  vmovaps [rsp+0xE0], xmm15
00007a66921d87f7  sub rsp, 0x30
00007a66921d87fb  movaps [rsp], xmm3
00007a66921d87ff  movaps [rsp+0x10], xmm1
00007a66921d8804  movaps [rsp+0x20], xmm15
00007a66921d880a  lea rdi, [rsp]
00007a66921d880e  mov esi, 0x00
00007a66921d8813  mov rax, 0x635346DC7530
00007a66921d881d  call rax
00007a66921d881f  movaps xmm3, [rsp]
00007a66921d8823  add rsp, 0x30
00007a66921d8827  vmovaps xmm0, [rsp]
00007a66921d882c  vmovaps xmm1, [rsp+0x10]
00007a66921d8832  vmovaps xmm2, [rsp+0x20]
00007a66921d8838  vmovaps xmm4, [rsp+0x30]
00007a66921d883e  vmovaps xmm5, [rsp+0x40]
00007a66921d8844  vmovaps xmm6, [rsp+0x50]
00007a66921d884a  vmovaps xmm7, [rsp+0x60]
00007a66921d8850  vmovaps xmm8, [rsp+0x70]
00007a66921d8856  vmovaps xmm9, [rsp+0x80]
00007a66921d885f  vmovaps xmm10, [rsp+0x90]
00007a66921d8868  vmovaps xmm11, [rsp+0xA0]
00007a66921d8871  vmovaps xmm12, [rsp+0xB0]
00007a66921d887a  vmovaps xmm13, [rsp+0xC0]
00007a66921d8883  vmovaps xmm14, [rsp+0xD0]
00007a66921d888c  vmovaps xmm15, [rsp+0xE0]
00007a66921d8895  add rsp, 0xF0
00007a66921d889c  pop r11
00007a66921d889e  pop r10
00007a66921d88a0  pop r9
00007a66921d88a2  pop r8
00007a66921d88a4  pop rsi
00007a66921d88a5  pop rdi
00007a66921d88a6  pop rdx
00007a66921d88a7  pop rcx
00007a66921d88a8  pop rax
00007a66921d88a9  add rsp, 0x08
00007a66921d88ad  jmp 0x00007A66921D60BF
00007a66921d88b2  call 0x00007A66920D64F0
00007a66921d88b7  jmp 0x00007A66921D60C9
00007a66921d88bc  sub rsp, 0x08
00007a66921d88c0  push rax
00007a66921d88c1  push rcx
00007a66921d88c2  push rdx
00007a66921d88c3  push rdi
00007a66921d88c4  push rsi
00007a66921d88c5  push r8
00007a66921d88c7  push r9
00007a66921d88c9  push r10
00007a66921d88cb  push r11
00007a66921d88cd  sub rsp, 0xF0
00007a66921d88d4  vmovaps [rsp], xmm0
00007a66921d88d9  vmovaps [rsp+0x10], xmm1
00007a66921d88df  vmovaps [rsp+0x20], xmm2
00007a66921d88e5  vmovaps [rsp+0x30], xmm3
00007a66921d88eb  vmovaps [rsp+0x40], xmm4
00007a66921d88f1  vmovaps [rsp+0x50], xmm5
00007a66921d88f7  vmovaps [rsp+0x60], xmm6
00007a66921d88fd  vmovaps [rsp+0x70], xmm7
00007a66921d8903  vmovaps [rsp+0x80], xmm8
00007a66921d890c  vmovaps [rsp+0x90], xmm9
00007a66921d8915  vmovaps [rsp+0xA0], xmm10
00007a66921d891e  vmovaps [rsp+0xB0], xmm11
00007a66921d8927  vmovaps [rsp+0xC0], xmm12
00007a66921d8930  vmovaps [rsp+0xD0], xmm13
00007a66921d8939  vmovaps [rsp+0xE0], xmm14
00007a66921d8942  sub rsp, 0x30
00007a66921d8946  movaps [rsp], xmm15
00007a66921d894b  movaps [rsp+0x10], xmm14
00007a66921d8951  movaps [rsp+0x20], xmm4
00007a66921d8956  lea rdi, [rsp]
00007a66921d895a  mov esi, 0x00
00007a66921d895f  mov rax, 0x635346DC7530
00007a66921d8969  call rax
00007a66921d896b  movaps xmm15, [rsp]
00007a66921d8970  add rsp, 0x30
00007a66921d8974  vmovaps xmm0, [rsp]
00007a66921d8979  vmovaps xmm1, [rsp+0x10]
00007a66921d897f  vmovaps xmm2, [rsp+0x20]
00007a66921d8985  vmovaps xmm3, [rsp+0x30]
00007a66921d898b  vmovaps xmm4, [rsp+0x40]
00007a66921d8991  vmovaps xmm5, [rsp+0x50]
00007a66921d8997  vmovaps xmm6, [rsp+0x60]
00007a66921d899d  vmovaps xmm7, [rsp+0x70]
00007a66921d89a3  vmovaps xmm8, [rsp+0x80]
00007a66921d89ac  vmovaps xmm9, [rsp+0x90]
00007a66921d89b5  vmovaps xmm10, [rsp+0xA0]
00007a66921d89be  vmovaps xmm11, [rsp+0xB0]
00007a66921d89c7  vmovaps xmm12, [rsp+0xC0]
00007a66921d89d0  vmovaps xmm13, [rsp+0xD0]
00007a66921d89d9  vmovaps xmm14, [rsp+0xE0]
00007a66921d89e2  add rsp, 0xF0
00007a66921d89e9  pop r11
00007a66921d89eb  pop r10
00007a66921d89ed  pop r9
00007a66921d89ef  pop r8
00007a66921d89f1  pop rsi
00007a66921d89f2  pop rdi
00007a66921d89f3  pop rdx
00007a66921d89f4  pop rcx
00007a66921d89f5  pop rax
00007a66921d89f6  add rsp, 0x08
00007a66921d89fa  jmp 0x00007A66921D60F7
00007a66921d89ff  sub rsp, 0x08
00007a66921d8a03  push rax
00007a66921d8a04  push rcx
00007a66921d8a05  push rdx
00007a66921d8a06  push rdi
00007a66921d8a07  push rsi
00007a66921d8a08  push r8
00007a66921d8a0a  push r9
00007a66921d8a0c  push r10
00007a66921d8a0e  push r11
00007a66921d8a10  sub rsp, 0xF0
00007a66921d8a17  vmovaps [rsp], xmm0
00007a66921d8a1c  vmovaps [rsp+0x10], xmm1
00007a66921d8a22  vmovaps [rsp+0x20], xmm2
00007a66921d8a28  vmovaps [rsp+0x30], xmm3
00007a66921d8a2e  vmovaps [rsp+0x40], xmm4
00007a66921d8a34  vmovaps [rsp+0x50], xmm5
00007a66921d8a3a  vmovaps [rsp+0x60], xmm6
00007a66921d8a40  vmovaps [rsp+0x70], xmm7
00007a66921d8a46  vmovaps [rsp+0x80], xmm8
00007a66921d8a4f  vmovaps [rsp+0x90], xmm9
00007a66921d8a58  vmovaps [rsp+0xA0], xmm10
00007a66921d8a61  vmovaps [rsp+0xB0], xmm11
00007a66921d8a6a  vmovaps [rsp+0xC0], xmm12
00007a66921d8a73  vmovaps [rsp+0xD0], xmm13
00007a66921d8a7c  vmovaps [rsp+0xE0], xmm15
00007a66921d8a85  sub rsp, 0x30
00007a66921d8a89  movaps [rsp], xmm14
00007a66921d8a8e  movaps [rsp+0x10], xmm2
00007a66921d8a93  movaps [rsp+0x20], xmm1
00007a66921d8a98  lea rdi, [rsp]
00007a66921d8a9c  mov esi, 0x00
00007a66921d8aa1  mov rax, 0x635346DC7530
00007a66921d8aab  call rax
00007a66921d8aad  movaps xmm14, [rsp]
00007a66921d8ab2  add rsp, 0x30
00007a66921d8ab6  vmovaps xmm0, [rsp]
00007a66921d8abb  vmovaps xmm1, [rsp+0x10]
00007a66921d8ac1  vmovaps xmm2, [rsp+0x20]
00007a66921d8ac7  vmovaps xmm3, [rsp+0x30]
00007a66921d8acd  vmovaps xmm4, [rsp+0x40]
00007a66921d8ad3  vmovaps xmm5, [rsp+0x50]
00007a66921d8ad9  vmovaps xmm6, [rsp+0x60]
00007a66921d8adf  vmovaps xmm7, [rsp+0x70]
00007a66921d8ae5  vmovaps xmm8, [rsp+0x80]
00007a66921d8aee  vmovaps xmm9, [rsp+0x90]
00007a66921d8af7  vmovaps xmm10, [rsp+0xA0]
00007a66921d8b00  vmovaps xmm11, [rsp+0xB0]
00007a66921d8b09  vmovaps xmm12, [rsp+0xC0]
00007a66921d8b12  vmovaps xmm13, [rsp+0xD0]
00007a66921d8b1b  vmovaps xmm15, [rsp+0xE0]
00007a66921d8b24  add rsp, 0xF0
00007a66921d8b2b  pop r11
00007a66921d8b2d  pop r10
00007a66921d8b2f  pop r9
00007a66921d8b31  pop r8
00007a66921d8b33  pop rsi
00007a66921d8b34  pop rdi
00007a66921d8b35  pop rdx
00007a66921d8b36  pop rcx
00007a66921d8b37  pop rax
00007a66921d8b38  add rsp, 0x08
00007a66921d8b3c  jmp 0x00007A66921D611D
00007a66921d8b41  sub rsp, 0x08
00007a66921d8b45  push rax
00007a66921d8b46  push rcx
00007a66921d8b47  push rdx
00007a66921d8b48  push rdi
00007a66921d8b49  push rsi
00007a66921d8b4a  push r8
00007a66921d8b4c  push r9
00007a66921d8b4e  push r10
00007a66921d8b50  push r11
00007a66921d8b52  sub rsp, 0xF0
00007a66921d8b59  vmovaps [rsp], xmm0
00007a66921d8b5e  vmovaps [rsp+0x10], xmm2
00007a66921d8b64  vmovaps [rsp+0x20], xmm3
00007a66921d8b6a  vmovaps [rsp+0x30], xmm4
00007a66921d8b70  vmovaps [rsp+0x40], xmm5
00007a66921d8b76  vmovaps [rsp+0x50], xmm6
00007a66921d8b7c  vmovaps [rsp+0x60], xmm7
00007a66921d8b82  vmovaps [rsp+0x70], xmm8
00007a66921d8b88  vmovaps [rsp+0x80], xmm9
00007a66921d8b91  vmovaps [rsp+0x90], xmm10
00007a66921d8b9a  vmovaps [rsp+0xA0], xmm11
00007a66921d8ba3  vmovaps [rsp+0xB0], xmm12
00007a66921d8bac  vmovaps [rsp+0xC0], xmm13
00007a66921d8bb5  vmovaps [rsp+0xD0], xmm14
00007a66921d8bbe  vmovaps [rsp+0xE0], xmm15
00007a66921d8bc7  sub rsp, 0x30
00007a66921d8bcb  movaps [rsp], xmm1
00007a66921d8bcf  movaps [rsp+0x10], xmm4
00007a66921d8bd4  movaps [rsp+0x20], xmm9
00007a66921d8bda  lea rdi, [rsp]
00007a66921d8bde  mov esi, 0x00
00007a66921d8be3  mov rax, 0x635346DC7530
00007a66921d8bed  call rax
00007a66921d8bef  movaps xmm1, [rsp]
00007a66921d8bf3  add rsp, 0x30
00007a66921d8bf7  vmovaps xmm0, [rsp]
00007a66921d8bfc  vmovaps xmm2, [rsp+0x10]
00007a66921d8c02  vmovaps xmm3, [rsp+0x20]
00007a66921d8c08  vmovaps xmm4, [rsp+0x30]
00007a66921d8c0e  vmovaps xmm5, [rsp+0x40]
00007a66921d8c14  vmovaps xmm6, [rsp+0x50]
00007a66921d8c1a  vmovaps xmm7, [rsp+0x60]
00007a66921d8c20  vmovaps xmm8, [rsp+0x70]
00007a66921d8c26  vmovaps xmm9, [rsp+0x80]
00007a66921d8c2f  vmovaps xmm10, [rsp+0x90]
00007a66921d8c38  vmovaps xmm11, [rsp+0xA0]
00007a66921d8c41  vmovaps xmm12, [rsp+0xB0]
00007a66921d8c4a  vmovaps xmm13, [rsp+0xC0]
00007a66921d8c53  vmovaps xmm14, [rsp+0xD0]
00007a66921d8c5c  vmovaps xmm15, [rsp+0xE0]
00007a66921d8c65  add rsp, 0xF0
00007a66921d8c6c  pop r11
00007a66921d8c6e  pop r10
00007a66921d8c70  pop r9
00007a66921d8c72  pop r8
00007a66921d8c74  pop rsi
00007a66921d8c75  pop rdi
00007a66921d8c76  pop rdx
00007a66921d8c77  pop rcx
00007a66921d8c78  pop rax
00007a66921d8c79  add rsp, 0x08
00007a66921d8c7d  jmp 0x00007A66921D613B
00007a66921d8c82  sub rsp, 0x08
00007a66921d8c86  push rax
00007a66921d8c87  push rcx
00007a66921d8c88  push rdx
00007a66921d8c89  push rdi
00007a66921d8c8a  push rsi
00007a66921d8c8b  push r8
00007a66921d8c8d  push r9
00007a66921d8c8f  push r10
00007a66921d8c91  push r11
00007a66921d8c93  sub rsp, 0xF0
00007a66921d8c9a  vmovaps [rsp], xmm0
00007a66921d8c9f  vmovaps [rsp+0x10], xmm1
00007a66921d8ca5  vmovaps [rsp+0x20], xmm2
00007a66921d8cab  vmovaps [rsp+0x30], xmm3
00007a66921d8cb1  vmovaps [rsp+0x40], xmm5
00007a66921d8cb7  vmovaps [rsp+0x50], xmm6
00007a66921d8cbd  vmovaps [rsp+0x60], xmm7
00007a66921d8cc3  vmovaps [rsp+0x70], xmm8
00007a66921d8cc9  vmovaps [rsp+0x80], xmm9
00007a66921d8cd2  vmovaps [rsp+0x90], xmm10
00007a66921d8cdb  vmovaps [rsp+0xA0], xmm11
00007a66921d8ce4  vmovaps [rsp+0xB0], xmm12
00007a66921d8ced  vmovaps [rsp+0xC0], xmm13
00007a66921d8cf6  vmovaps [rsp+0xD0], xmm14
00007a66921d8cff  vmovaps [rsp+0xE0], xmm15
00007a66921d8d08  sub rsp, 0x30
00007a66921d8d0c  movaps [rsp], xmm4
00007a66921d8d10  movaps [rsp+0x10], xmm2
00007a66921d8d15  movaps [rsp+0x20], xmm9
00007a66921d8d1b  lea rdi, [rsp]
00007a66921d8d1f  mov esi, 0x00
00007a66921d8d24  mov rax, 0x635346DC7530
00007a66921d8d2e  call rax
00007a66921d8d30  movaps xmm4, [rsp]
00007a66921d8d34  add rsp, 0x30
00007a66921d8d38  vmovaps xmm0, [rsp]
00007a66921d8d3d  vmovaps xmm1, [rsp+0x10]
00007a66921d8d43  vmovaps xmm2, [rsp+0x20]
00007a66921d8d49  vmovaps xmm3, [rsp+0x30]
00007a66921d8d4f  vmovaps xmm5, [rsp+0x40]
00007a66921d8d55  vmovaps xmm6, [rsp+0x50]
00007a66921d8d5b  vmovaps xmm7, [rsp+0x60]
00007a66921d8d61  vmovaps xmm8, [rsp+0x70]
00007a66921d8d67  vmovaps xmm9, [rsp+0x80]
00007a66921d8d70  vmovaps xmm10, [rsp+0x90]
00007a66921d8d79  vmovaps xmm11, [rsp+0xA0]
00007a66921d8d82  vmovaps xmm12, [rsp+0xB0]
00007a66921d8d8b  vmovaps xmm13, [rsp+0xC0]
00007a66921d8d94  vmovaps xmm14, [rsp+0xD0]
00007a66921d8d9d  vmovaps xmm15, [rsp+0xE0]
00007a66921d8da6  add rsp, 0xF0
00007a66921d8dad  pop r11
00007a66921d8daf  pop r10
00007a66921d8db1  pop r9
00007a66921d8db3  pop r8
00007a66921d8db5  pop rsi
00007a66921d8db6  pop rdi
00007a66921d8db7  pop rdx
00007a66921d8db8  pop rcx
00007a66921d8db9  pop rax
00007a66921d8dba  add rsp, 0x08
00007a66921d8dbe  jmp 0x00007A66921D616B
00007a66921d8dc3  sub rsp, 0x08
00007a66921d8dc7  push rax
00007a66921d8dc8  push rcx
00007a66921d8dc9  push rdx
00007a66921d8dca  push rdi
00007a66921d8dcb  push rsi
00007a66921d8dcc  push r8
00007a66921d8dce  push r9
00007a66921d8dd0  push r10
00007a66921d8dd2  push r11
00007a66921d8dd4  sub rsp, 0xF0
00007a66921d8ddb  vmovaps [rsp], xmm0
00007a66921d8de0  vmovaps [rsp+0x10], xmm1
00007a66921d8de6  vmovaps [rsp+0x20], xmm2
00007a66921d8dec  vmovaps [rsp+0x30], xmm3
00007a66921d8df2  vmovaps [rsp+0x40], xmm4
00007a66921d8df8  vmovaps [rsp+0x50], xmm5
00007a66921d8dfe  vmovaps [rsp+0x60], xmm6
00007a66921d8e04  vmovaps [rsp+0x70], xmm7
00007a66921d8e0a  vmovaps [rsp+0x80], xmm8
00007a66921d8e13  vmovaps [rsp+0x90], xmm10
00007a66921d8e1c  vmovaps [rsp+0xA0], xmm11
00007a66921d8e25  vmovaps [rsp+0xB0], xmm12
00007a66921d8e2e  vmovaps [rsp+0xC0], xmm13
00007a66921d8e37  vmovaps [rsp+0xD0], xmm14
00007a66921d8e40  vmovaps [rsp+0xE0], xmm15
00007a66921d8e49  sub rsp, 0x30
00007a66921d8e4d  movaps [rsp], xmm9
00007a66921d8e52  movaps [rsp+0x10], xmm2
00007a66921d8e57  movaps [rsp+0x20], xmm1
00007a66921d8e5c  lea rdi, [rsp]
00007a66921d8e60  mov esi, 0x00
00007a66921d8e65  mov rax, 0x635346DC7530
00007a66921d8e6f  call rax
00007a66921d8e71  movaps xmm9, [rsp]
00007a66921d8e76  add rsp, 0x30
00007a66921d8e7a  vmovaps xmm0, [rsp]
00007a66921d8e7f  vmovaps xmm1, [rsp+0x10]
00007a66921d8e85  vmovaps xmm2, [rsp+0x20]
00007a66921d8e8b  vmovaps xmm3, [rsp+0x30]
00007a66921d8e91  vmovaps xmm4, [rsp+0x40]
00007a66921d8e97  vmovaps xmm5, [rsp+0x50]
00007a66921d8e9d  vmovaps xmm6, [rsp+0x60]
00007a66921d8ea3  vmovaps xmm7, [rsp+0x70]
00007a66921d8ea9  vmovaps xmm8, [rsp+0x80]
00007a66921d8eb2  vmovaps xmm10, [rsp+0x90]
00007a66921d8ebb  vmovaps xmm11, [rsp+0xA0]
00007a66921d8ec4  vmovaps xmm12, [rsp+0xB0]
00007a66921d8ecd  vmovaps xmm13, [rsp+0xC0]
00007a66921d8ed6  vmovaps xmm14, [rsp+0xD0]
00007a66921d8edf  vmovaps xmm15, [rsp+0xE0]
00007a66921d8ee8  add rsp, 0xF0
00007a66921d8eef  pop r11
00007a66921d8ef1  pop r10
00007a66921d8ef3  pop r9
00007a66921d8ef5  pop r8
00007a66921d8ef7  pop rsi
00007a66921d8ef8  pop rdi
00007a66921d8ef9  pop rdx
00007a66921d8efa  pop rcx
00007a66921d8efb  pop rax
00007a66921d8efc  add rsp, 0x08
00007a66921d8f00  jmp 0x00007A66921D61A1
00007a66921d8f05  sub rsp, 0x08
00007a66921d8f09  push rax
00007a66921d8f0a  push rcx
00007a66921d8f0b  push rdx
00007a66921d8f0c  push rdi
00007a66921d8f0d  push rsi
00007a66921d8f0e  push r8
00007a66921d8f10  push r9
00007a66921d8f12  push r10
00007a66921d8f14  push r11
00007a66921d8f16  sub rsp, 0xF0
00007a66921d8f1d  vmovaps [rsp], xmm0
00007a66921d8f22  vmovaps [rsp+0x10], xmm2
00007a66921d8f28  vmovaps [rsp+0x20], xmm3
00007a66921d8f2e  vmovaps [rsp+0x30], xmm4
00007a66921d8f34  vmovaps [rsp+0x40], xmm5
00007a66921d8f3a  vmovaps [rsp+0x50], xmm6
00007a66921d8f40  vmovaps [rsp+0x60], xmm7
00007a66921d8f46  vmovaps [rsp+0x70], xmm8
00007a66921d8f4c  vmovaps [rsp+0x80], xmm9
00007a66921d8f55  vmovaps [rsp+0x90], xmm10
00007a66921d8f5e  vmovaps [rsp+0xA0], xmm11
00007a66921d8f67  vmovaps [rsp+0xB0], xmm12
00007a66921d8f70  vmovaps [rsp+0xC0], xmm13
00007a66921d8f79  vmovaps [rsp+0xD0], xmm14
00007a66921d8f82  vmovaps [rsp+0xE0], xmm15
00007a66921d8f8b  sub rsp, 0x30
00007a66921d8f8f  movaps [rsp], xmm1
00007a66921d8f93  movaps [rsp+0x10], xmm15
00007a66921d8f99  movaps [rsp+0x20], xmm6
00007a66921d8f9e  lea rdi, [rsp]
00007a66921d8fa2  mov esi, 0x00
00007a66921d8fa7  mov rax, 0x635346DC7530
00007a66921d8fb1  call rax
00007a66921d8fb3  movaps xmm1, [rsp]
00007a66921d8fb7  add rsp, 0x30
00007a66921d8fbb  vmovaps xmm0, [rsp]
00007a66921d8fc0  vmovaps xmm2, [rsp+0x10]
00007a66921d8fc6  vmovaps xmm3, [rsp+0x20]
00007a66921d8fcc  vmovaps xmm4, [rsp+0x30]
00007a66921d8fd2  vmovaps xmm5, [rsp+0x40]
00007a66921d8fd8  vmovaps xmm6, [rsp+0x50]
00007a66921d8fde  vmovaps xmm7, [rsp+0x60]
00007a66921d8fe4  vmovaps xmm8, [rsp+0x70]
00007a66921d8fea  vmovaps xmm9, [rsp+0x80]
00007a66921d8ff3  vmovaps xmm10, [rsp+0x90]
00007a66921d8ffc  vmovaps xmm11, [rsp+0xA0]
00007a66921d9005  vmovaps xmm12, [rsp+0xB0]
00007a66921d900e  vmovaps xmm13, [rsp+0xC0]
00007a66921d9017  vmovaps xmm14, [rsp+0xD0]
00007a66921d9020  vmovaps xmm15, [rsp+0xE0]
00007a66921d9029  add rsp, 0xF0
00007a66921d9030  pop r11
00007a66921d9032  pop r10
00007a66921d9034  pop r9
00007a66921d9036  pop r8
00007a66921d9038  pop rsi
00007a66921d9039  pop rdi
00007a66921d903a  pop rdx
00007a66921d903b  pop rcx
00007a66921d903c  pop rax
00007a66921d903d  add rsp, 0x08
00007a66921d9041  jmp 0x00007A66921D61C2
00007a66921d9046  sub rsp, 0x08
00007a66921d904a  push rax
00007a66921d904b  push rcx
00007a66921d904c  push rdx
00007a66921d904d  push rdi
00007a66921d904e  push rsi
00007a66921d904f  push r8
00007a66921d9051  push r9
00007a66921d9053  push r10
00007a66921d9055  push r11
00007a66921d9057  sub rsp, 0xF0
00007a66921d905e  vmovaps [rsp], xmm0
00007a66921d9063  vmovaps [rsp+0x10], xmm1
00007a66921d9069  vmovaps [rsp+0x20], xmm2
00007a66921d906f  vmovaps [rsp+0x30], xmm3
00007a66921d9075  vmovaps [rsp+0x40], xmm4
00007a66921d907b  vmovaps [rsp+0x50], xmm5
00007a66921d9081  vmovaps [rsp+0x60], xmm6
00007a66921d9087  vmovaps [rsp+0x70], xmm7
00007a66921d908d  vmovaps [rsp+0x80], xmm8
00007a66921d9096  vmovaps [rsp+0x90], xmm9
00007a66921d909f  vmovaps [rsp+0xA0], xmm10
00007a66921d90a8  vmovaps [rsp+0xB0], xmm11
00007a66921d90b1  vmovaps [rsp+0xC0], xmm12
00007a66921d90ba  vmovaps [rsp+0xD0], xmm13
00007a66921d90c3  vmovaps [rsp+0xE0], xmm14
00007a66921d90cc  sub rsp, 0x30
00007a66921d90d0  movaps [rsp], xmm15
00007a66921d90d5  movaps [rsp+0x10], xmm5
00007a66921d90da  movaps [rsp+0x20], xmm3
00007a66921d90df  lea rdi, [rsp]
00007a66921d90e3  mov esi, 0x00
00007a66921d90e8  mov rax, 0x635346DC7530
00007a66921d90f2  call rax
00007a66921d90f4  movaps xmm15, [rsp]
00007a66921d90f9  add rsp, 0x30
00007a66921d90fd  vmovaps xmm0, [rsp]
00007a66921d9102  vmovaps xmm1, [rsp+0x10]
00007a66921d9108  vmovaps xmm2, [rsp+0x20]
00007a66921d910e  vmovaps xmm3, [rsp+0x30]
00007a66921d9114  vmovaps xmm4, [rsp+0x40]
00007a66921d911a  vmovaps xmm5, [rsp+0x50]
00007a66921d9120  vmovaps xmm6, [rsp+0x60]
00007a66921d9126  vmovaps xmm7, [rsp+0x70]
00007a66921d912c  vmovaps xmm8, [rsp+0x80]
00007a66921d9135  vmovaps xmm9, [rsp+0x90]
00007a66921d913e  vmovaps xmm10, [rsp+0xA0]
00007a66921d9147  vmovaps xmm11, [rsp+0xB0]
00007a66921d9150  vmovaps xmm12, [rsp+0xC0]
00007a66921d9159  vmovaps xmm13, [rsp+0xD0]
00007a66921d9162  vmovaps xmm14, [rsp+0xE0]
00007a66921d916b  add rsp, 0xF0
00007a66921d9172  pop r11
00007a66921d9174  pop r10
00007a66921d9176  pop r9
00007a66921d9178  pop r8
00007a66921d917a  pop rsi
00007a66921d917b  pop rdi
00007a66921d917c  pop rdx
00007a66921d917d  pop rcx
00007a66921d917e  pop rax
00007a66921d917f  add rsp, 0x08
00007a66921d9183  jmp 0x00007A66921D61DC
00007a66921d9188  sub rsp, 0x08
00007a66921d918c  push rax
00007a66921d918d  push rcx
00007a66921d918e  push rdx
00007a66921d918f  push rdi
00007a66921d9190  push rsi
00007a66921d9191  push r8
00007a66921d9193  push r9
00007a66921d9195  push r10
00007a66921d9197  push r11
00007a66921d9199  sub rsp, 0xF0
00007a66921d91a0  vmovaps [rsp], xmm0
00007a66921d91a5  vmovaps [rsp+0x10], xmm1
00007a66921d91ab  vmovaps [rsp+0x20], xmm2
00007a66921d91b1  vmovaps [rsp+0x30], xmm3
00007a66921d91b7  vmovaps [rsp+0x40], xmm4
00007a66921d91bd  vmovaps [rsp+0x50], xmm6
00007a66921d91c3  vmovaps [rsp+0x60], xmm7
00007a66921d91c9  vmovaps [rsp+0x70], xmm8
00007a66921d91cf  vmovaps [rsp+0x80], xmm9
00007a66921d91d8  vmovaps [rsp+0x90], xmm10
00007a66921d91e1  vmovaps [rsp+0xA0], xmm11
00007a66921d91ea  vmovaps [rsp+0xB0], xmm12
00007a66921d91f3  vmovaps [rsp+0xC0], xmm13
00007a66921d91fc  vmovaps [rsp+0xD0], xmm14
00007a66921d9205  vmovaps [rsp+0xE0], xmm15
00007a66921d920e  sub rsp, 0x30
00007a66921d9212  movaps [rsp], xmm5
00007a66921d9216  movaps [rsp+0x10], xmm8
00007a66921d921c  movaps [rsp+0x20], xmm6
00007a66921d9221  lea rdi, [rsp]
00007a66921d9225  mov esi, 0x00
00007a66921d922a  mov rax, 0x635346DC7530
00007a66921d9234  call rax
00007a66921d9236  movaps xmm5, [rsp]
00007a66921d923a  add rsp, 0x30
00007a66921d923e  vmovaps xmm0, [rsp]
00007a66921d9243  vmovaps xmm1, [rsp+0x10]
00007a66921d9249  vmovaps xmm2, [rsp+0x20]
00007a66921d924f  vmovaps xmm3, [rsp+0x30]
00007a66921d9255  vmovaps xmm4, [rsp+0x40]
00007a66921d925b  vmovaps xmm6, [rsp+0x50]
00007a66921d9261  vmovaps xmm7, [rsp+0x60]
00007a66921d9267  vmovaps xmm8, [rsp+0x70]
00007a66921d926d  vmovaps xmm9, [rsp+0x80]
00007a66921d9276  vmovaps xmm10, [rsp+0x90]
00007a66921d927f  vmovaps xmm11, [rsp+0xA0]
00007a66921d9288  vmovaps xmm12, [rsp+0xB0]
00007a66921d9291  vmovaps xmm13, [rsp+0xC0]
00007a66921d929a  vmovaps xmm14, [rsp+0xD0]
00007a66921d92a3  vmovaps xmm15, [rsp+0xE0]
00007a66921d92ac  add rsp, 0xF0
00007a66921d92b3  pop r11
00007a66921d92b5  pop r10
00007a66921d92b7  pop r9
00007a66921d92b9  pop r8
00007a66921d92bb  pop rsi
00007a66921d92bc  pop rdi
00007a66921d92bd  pop rdx
00007a66921d92be  pop rcx
00007a66921d92bf  pop rax
00007a66921d92c0  add rsp, 0x08
00007a66921d92c4  jmp 0x00007A66921D6200
00007a66921d92c9  sub rsp, 0x08
00007a66921d92cd  push rax
00007a66921d92ce  push rcx
00007a66921d92cf  push rdx
00007a66921d92d0  push rdi
00007a66921d92d1  push rsi
00007a66921d92d2  push r8
00007a66921d92d4  push r9
00007a66921d92d6  push r10
00007a66921d92d8  push r11
00007a66921d92da  sub rsp, 0xF0
00007a66921d92e1  vmovaps [rsp], xmm0
00007a66921d92e6  vmovaps [rsp+0x10], xmm1
00007a66921d92ec  vmovaps [rsp+0x20], xmm2
00007a66921d92f2  vmovaps [rsp+0x30], xmm3
00007a66921d92f8  vmovaps [rsp+0x40], xmm4
00007a66921d92fe  vmovaps [rsp+0x50], xmm5
00007a66921d9304  vmovaps [rsp+0x60], xmm7
00007a66921d930a  vmovaps [rsp+0x70], xmm8
00007a66921d9310  vmovaps [rsp+0x80], xmm9
00007a66921d9319  vmovaps [rsp+0x90], xmm10
00007a66921d9322  vmovaps [rsp+0xA0], xmm11
00007a66921d932b  vmovaps [rsp+0xB0], xmm12
00007a66921d9334  vmovaps [rsp+0xC0], xmm13
00007a66921d933d  vmovaps [rsp+0xD0], xmm14
00007a66921d9346  vmovaps [rsp+0xE0], xmm15
00007a66921d934f  sub rsp, 0x30
00007a66921d9353  movaps [rsp], xmm6
00007a66921d9357  movaps [rsp+0x10], xmm10
00007a66921d935d  movaps [rsp+0x20], xmm8
00007a66921d9363  lea rdi, [rsp]
00007a66921d9367  mov esi, 0x00
00007a66921d936c  mov rax, 0x635346DC7530
00007a66921d9376  call rax
00007a66921d9378  movaps xmm6, [rsp]
00007a66921d937c  add rsp, 0x30
00007a66921d9380  vmovaps xmm0, [rsp]
00007a66921d9385  vmovaps xmm1, [rsp+0x10]
00007a66921d938b  vmovaps xmm2, [rsp+0x20]
00007a66921d9391  vmovaps xmm3, [rsp+0x30]
00007a66921d9397  vmovaps xmm4, [rsp+0x40]
00007a66921d939d  vmovaps xmm5, [rsp+0x50]
00007a66921d93a3  vmovaps xmm7, [rsp+0x60]
00007a66921d93a9  vmovaps xmm8, [rsp+0x70]
00007a66921d93af  vmovaps xmm9, [rsp+0x80]
00007a66921d93b8  vmovaps xmm10, [rsp+0x90]
00007a66921d93c1  vmovaps xmm11, [rsp+0xA0]
00007a66921d93ca  vmovaps xmm12, [rsp+0xB0]
00007a66921d93d3  vmovaps xmm13, [rsp+0xC0]
00007a66921d93dc  vmovaps xmm14, [rsp+0xD0]
00007a66921d93e5  vmovaps xmm15, [rsp+0xE0]
00007a66921d93ee  add rsp, 0xF0
00007a66921d93f5  pop r11
00007a66921d93f7  pop r10
00007a66921d93f9  pop r9
00007a66921d93fb  pop r8
00007a66921d93fd  pop rsi
00007a66921d93fe  pop rdi
00007a66921d93ff  pop rdx
00007a66921d9400  pop rcx
00007a66921d9401  pop rax
00007a66921d9402  add rsp, 0x08
00007a66921d9406  jmp 0x00007A66921D6225
00007a66921d940b  sub rsp, 0x08
00007a66921d940f  push rax
00007a66921d9410  push rcx
00007a66921d9411  push rdx
00007a66921d9412  push rdi
00007a66921d9413  push rsi
00007a66921d9414  push r8
00007a66921d9416  push r9
00007a66921d9418  push r10
00007a66921d941a  push r11
00007a66921d941c  sub rsp, 0xF0
00007a66921d9423  vmovaps [rsp], xmm0
00007a66921d9428  vmovaps [rsp+0x10], xmm1
00007a66921d942e  vmovaps [rsp+0x20], xmm2
00007a66921d9434  vmovaps [rsp+0x30], xmm3
00007a66921d943a  vmovaps [rsp+0x40], xmm4
00007a66921d9440  vmovaps [rsp+0x50], xmm5
00007a66921d9446  vmovaps [rsp+0x60], xmm6
00007a66921d944c  vmovaps [rsp+0x70], xmm7
00007a66921d9452  vmovaps [rsp+0x80], xmm8
00007a66921d945b  vmovaps [rsp+0x90], xmm9
00007a66921d9464  vmovaps [rsp+0xA0], xmm11
00007a66921d946d  vmovaps [rsp+0xB0], xmm12
00007a66921d9476  vmovaps [rsp+0xC0], xmm13
00007a66921d947f  vmovaps [rsp+0xD0], xmm14
00007a66921d9488  vmovaps [rsp+0xE0], xmm15
00007a66921d9491  sub rsp, 0x30
00007a66921d9495  movaps [rsp], xmm10
00007a66921d949a  movaps [rsp+0x10], xmm8
00007a66921d94a0  movaps [rsp+0x20], xmm14
00007a66921d94a6  lea rdi, [rsp]
00007a66921d94aa  mov esi, 0x00
00007a66921d94af  mov rax, 0x635346DC7530
00007a66921d94b9  call rax
00007a66921d94bb  movaps xmm10, [rsp]
00007a66921d94c0  add rsp, 0x30
00007a66921d94c4  vmovaps xmm0, [rsp]
00007a66921d94c9  vmovaps xmm1, [rsp+0x10]
00007a66921d94cf  vmovaps xmm2, [rsp+0x20]
00007a66921d94d5  vmovaps xmm3, [rsp+0x30]
00007a66921d94db  vmovaps xmm4, [rsp+0x40]
00007a66921d94e1  vmovaps xmm5, [rsp+0x50]
00007a66921d94e7  vmovaps xmm6, [rsp+0x60]
00007a66921d94ed  vmovaps xmm7, [rsp+0x70]
00007a66921d94f3  vmovaps xmm8, [rsp+0x80]
00007a66921d94fc  vmovaps xmm9, [rsp+0x90]
00007a66921d9505  vmovaps xmm11, [rsp+0xA0]
00007a66921d950e  vmovaps xmm12, [rsp+0xB0]
00007a66921d9517  vmovaps xmm13, [rsp+0xC0]
00007a66921d9520  vmovaps xmm14, [rsp+0xD0]
00007a66921d9529  vmovaps xmm15, [rsp+0xE0]
00007a66921d9532  add rsp, 0xF0
00007a66921d9539  pop r11
00007a66921d953b  pop r10
00007a66921d953d  pop r9
00007a66921d953f  pop r8
00007a66921d9541  pop rsi
00007a66921d9542  pop rdi
00007a66921d9543  pop rdx
00007a66921d9544  pop rcx
00007a66921d9545  pop rax
00007a66921d9546  add rsp, 0x08
00007a66921d954a  jmp 0x00007A66921D6245
00007a66921d954f  sub rsp, 0x08
00007a66921d9553  push rax
00007a66921d9554  push rcx
00007a66921d9555  push rdx
00007a66921d9556  push rdi
00007a66921d9557  push rsi
00007a66921d9558  push r8
00007a66921d955a  push r9
00007a66921d955c  push r10
00007a66921d955e  push r11
00007a66921d9560  sub rsp, 0xF0
00007a66921d9567  vmovaps [rsp], xmm0
00007a66921d956c  vmovaps [rsp+0x10], xmm1
00007a66921d9572  vmovaps [rsp+0x20], xmm2
00007a66921d9578  vmovaps [rsp+0x30], xmm3
00007a66921d957e  vmovaps [rsp+0x40], xmm4
00007a66921d9584  vmovaps [rsp+0x50], xmm5
00007a66921d958a  vmovaps [rsp+0x60], xmm6
00007a66921d9590  vmovaps [rsp+0x70], xmm7
00007a66921d9596  vmovaps [rsp+0x80], xmm8
00007a66921d959f  vmovaps [rsp+0x90], xmm9
00007a66921d95a8  vmovaps [rsp+0xA0], xmm10
00007a66921d95b1  vmovaps [rsp+0xB0], xmm11
00007a66921d95ba  vmovaps [rsp+0xC0], xmm12
00007a66921d95c3  vmovaps [rsp+0xD0], xmm13
00007a66921d95cc  vmovaps [rsp+0xE0], xmm15
00007a66921d95d5  sub rsp, 0x30
00007a66921d95d9  movaps [rsp], xmm14
00007a66921d95de  movaps [rsp+0x10], xmm8
00007a66921d95e4  movaps [rsp+0x20], xmm4
00007a66921d95e9  lea rdi, [rsp]
00007a66921d95ed  mov esi, 0x00
00007a66921d95f2  mov rax, 0x635346DC7530
00007a66921d95fc  call rax
00007a66921d95fe  movaps xmm14, [rsp]
00007a66921d9603  add rsp, 0x30
00007a66921d9607  vmovaps xmm0, [rsp]
00007a66921d960c  vmovaps xmm1, [rsp+0x10]
00007a66921d9612  vmovaps xmm2, [rsp+0x20]
00007a66921d9618  vmovaps xmm3, [rsp+0x30]
00007a66921d961e  vmovaps xmm4, [rsp+0x40]
00007a66921d9624  vmovaps xmm5, [rsp+0x50]
00007a66921d962a  vmovaps xmm6, [rsp+0x60]
00007a66921d9630  vmovaps xmm7, [rsp+0x70]
00007a66921d9636  vmovaps xmm8, [rsp+0x80]
00007a66921d963f  vmovaps xmm9, [rsp+0x90]
00007a66921d9648  vmovaps xmm10, [rsp+0xA0]
00007a66921d9651  vmovaps xmm11, [rsp+0xB0]
00007a66921d965a  vmovaps xmm12, [rsp+0xC0]
00007a66921d9663  vmovaps xmm13, [rsp+0xD0]
00007a66921d966c  vmovaps xmm15, [rsp+0xE0]
00007a66921d9675  add rsp, 0xF0
00007a66921d967c  pop r11
00007a66921d967e  pop r10
00007a66921d9680  pop r9
00007a66921d9682  pop r8
00007a66921d9684  pop rsi
00007a66921d9685  pop rdi
00007a66921d9686  pop rdx
00007a66921d9687  pop rcx
00007a66921d9688  pop rax
00007a66921d9689  add rsp, 0x08
00007a66921d968d  jmp 0x00007A66921D6265
00007a66921d9692  sub rsp, 0x08
00007a66921d9696  push rax
00007a66921d9697  push rcx
00007a66921d9698  push rdx
00007a66921d9699  push rdi
00007a66921d969a  push rsi
00007a66921d969b  push r8
00007a66921d969d  push r9
00007a66921d969f  push r10
00007a66921d96a1  push r11
00007a66921d96a3  sub rsp, 0xF0
00007a66921d96aa  vmovaps [rsp], xmm0
00007a66921d96af  vmovaps [rsp+0x10], xmm1
00007a66921d96b5  vmovaps [rsp+0x20], xmm2
00007a66921d96bb  vmovaps [rsp+0x30], xmm3
00007a66921d96c1  vmovaps [rsp+0x40], xmm5
00007a66921d96c7  vmovaps [rsp+0x50], xmm6
00007a66921d96cd  vmovaps [rsp+0x60], xmm7
00007a66921d96d3  vmovaps [rsp+0x70], xmm8
00007a66921d96d9  vmovaps [rsp+0x80], xmm9
00007a66921d96e2  vmovaps [rsp+0x90], xmm10
00007a66921d96eb  vmovaps [rsp+0xA0], xmm11
00007a66921d96f4  vmovaps [rsp+0xB0], xmm12
00007a66921d96fd  vmovaps [rsp+0xC0], xmm13
00007a66921d9706  vmovaps [rsp+0xD0], xmm14
00007a66921d970f  vmovaps [rsp+0xE0], xmm15
00007a66921d9718  sub rsp, 0x30
00007a66921d971c  movaps [rsp], xmm4
00007a66921d9720  movaps [rsp+0x10], xmm13
00007a66921d9726  movaps [rsp+0x20], xmm8
00007a66921d972c  lea rdi, [rsp]
00007a66921d9730  mov esi, 0x00
00007a66921d9735  mov rax, 0x635346DC7530
00007a66921d973f  call rax
00007a66921d9741  movaps xmm4, [rsp]
00007a66921d9745  add rsp, 0x30
00007a66921d9749  vmovaps xmm0, [rsp]
00007a66921d974e  vmovaps xmm1, [rsp+0x10]
00007a66921d9754  vmovaps xmm2, [rsp+0x20]
00007a66921d975a  vmovaps xmm3, [rsp+0x30]
00007a66921d9760  vmovaps xmm5, [rsp+0x40]
00007a66921d9766  vmovaps xmm6, [rsp+0x50]
00007a66921d976c  vmovaps xmm7, [rsp+0x60]
00007a66921d9772  vmovaps xmm8, [rsp+0x70]
00007a66921d9778  vmovaps xmm9, [rsp+0x80]
00007a66921d9781  vmovaps xmm10, [rsp+0x90]
00007a66921d978a  vmovaps xmm11, [rsp+0xA0]
00007a66921d9793  vmovaps xmm12, [rsp+0xB0]
00007a66921d979c  vmovaps xmm13, [rsp+0xC0]
00007a66921d97a5  vmovaps xmm14, [rsp+0xD0]
00007a66921d97ae  vmovaps xmm15, [rsp+0xE0]
00007a66921d97b7  add rsp, 0xF0
00007a66921d97be  pop r11
00007a66921d97c0  pop r10
00007a66921d97c2  pop r9
00007a66921d97c4  pop r8
00007a66921d97c6  pop rsi
00007a66921d97c7  pop rdi
00007a66921d97c8  pop rdx
00007a66921d97c9  pop rcx
00007a66921d97ca  pop rax
00007a66921d97cb  add rsp, 0x08
00007a66921d97cf  jmp 0x00007A66921D628A
00007a66921d97d4  sub rsp, 0x08
00007a66921d97d8  push rax
00007a66921d97d9  push rcx
00007a66921d97da  push rdx
00007a66921d97db  push rdi
00007a66921d97dc  push rsi
00007a66921d97dd  push r8
00007a66921d97df  push r9
00007a66921d97e1  push r10
00007a66921d97e3  push r11
00007a66921d97e5  sub rsp, 0xF0
00007a66921d97ec  vmovaps [rsp], xmm0
00007a66921d97f1  vmovaps [rsp+0x10], xmm1
00007a66921d97f7  vmovaps [rsp+0x20], xmm2
00007a66921d97fd  vmovaps [rsp+0x30], xmm3
00007a66921d9803  vmovaps [rsp+0x40], xmm4
00007a66921d9809  vmovaps [rsp+0x50], xmm5
00007a66921d980f  vmovaps [rsp+0x60], xmm6
00007a66921d9815  vmovaps [rsp+0x70], xmm7
00007a66921d981b  vmovaps [rsp+0x80], xmm8
00007a66921d9824  vmovaps [rsp+0x90], xmm9
00007a66921d982d  vmovaps [rsp+0xA0], xmm10
00007a66921d9836  vmovaps [rsp+0xB0], xmm11
00007a66921d983f  vmovaps [rsp+0xC0], xmm12
00007a66921d9848  vmovaps [rsp+0xD0], xmm14
00007a66921d9851  vmovaps [rsp+0xE0], xmm15
00007a66921d985a  sub rsp, 0x30
00007a66921d985e  movaps [rsp], xmm13
00007a66921d9863  movaps [rsp+0x10], xmm15
00007a66921d9869  movaps [rsp+0x20], xmm9
00007a66921d986f  lea rdi, [rsp]
00007a66921d9873  mov esi, 0x00
00007a66921d9878  mov rax, 0x635346DC7530
00007a66921d9882  call rax
00007a66921d9884  movaps xmm13, [rsp]
00007a66921d9889  add rsp, 0x30
00007a66921d988d  vmovaps xmm0, [rsp]
00007a66921d9892  vmovaps xmm1, [rsp+0x10]
00007a66921d9898  vmovaps xmm2, [rsp+0x20]
00007a66921d989e  vmovaps xmm3, [rsp+0x30]
00007a66921d98a4  vmovaps xmm4, [rsp+0x40]
00007a66921d98aa  vmovaps xmm5, [rsp+0x50]
00007a66921d98b0  vmovaps xmm6, [rsp+0x60]
00007a66921d98b6  vmovaps xmm7, [rsp+0x70]
00007a66921d98bc  vmovaps xmm8, [rsp+0x80]
00007a66921d98c5  vmovaps xmm9, [rsp+0x90]
00007a66921d98ce  vmovaps xmm10, [rsp+0xA0]
00007a66921d98d7  vmovaps xmm11, [rsp+0xB0]
00007a66921d98e0  vmovaps xmm12, [rsp+0xC0]
00007a66921d98e9  vmovaps xmm14, [rsp+0xD0]
00007a66921d98f2  vmovaps xmm15, [rsp+0xE0]
00007a66921d98fb  add rsp, 0xF0
00007a66921d9902  pop r11
00007a66921d9904  pop r10
00007a66921d9906  pop r9
00007a66921d9908  pop r8
00007a66921d990a  pop rsi
00007a66921d990b  pop rdi
00007a66921d990c  pop rdx
00007a66921d990d  pop rcx
00007a66921d990e  pop rax
00007a66921d990f  add rsp, 0x08
00007a66921d9913  jmp 0x00007A66921D62A5
00007a66921d9918  sub rsp, 0x08
00007a66921d991c  push rax
00007a66921d991d  push rcx
00007a66921d991e  push rdx
00007a66921d991f  push rdi
00007a66921d9920  push rsi
00007a66921d9921  push r8
00007a66921d9923  push r9
00007a66921d9925  push r10
00007a66921d9927  push r11
00007a66921d9929  sub rsp, 0xF0
00007a66921d9930  vmovaps [rsp], xmm0
00007a66921d9935  vmovaps [rsp+0x10], xmm1
00007a66921d993b  vmovaps [rsp+0x20], xmm2
00007a66921d9941  vmovaps [rsp+0x30], xmm3
00007a66921d9947  vmovaps [rsp+0x40], xmm4
00007a66921d994d  vmovaps [rsp+0x50], xmm5
00007a66921d9953  vmovaps [rsp+0x60], xmm6
00007a66921d9959  vmovaps [rsp+0x70], xmm7
00007a66921d995f  vmovaps [rsp+0x80], xmm8
00007a66921d9968  vmovaps [rsp+0x90], xmm9
00007a66921d9971  vmovaps [rsp+0xA0], xmm10
00007a66921d997a  vmovaps [rsp+0xB0], xmm11
00007a66921d9983  vmovaps [rsp+0xC0], xmm12
00007a66921d998c  vmovaps [rsp+0xD0], xmm13
00007a66921d9995  vmovaps [rsp+0xE0], xmm14
00007a66921d999e  sub rsp, 0x30
00007a66921d99a2  movaps [rsp], xmm15
00007a66921d99a7  movaps [rsp+0x10], xmm1
00007a66921d99ac  movaps [rsp+0x20], xmm5
00007a66921d99b1  lea rdi, [rsp]
00007a66921d99b5  mov esi, 0x00
00007a66921d99ba  mov rax, 0x635346DC7530
00007a66921d99c4  call rax
00007a66921d99c6  movaps xmm15, [rsp]
00007a66921d99cb  add rsp, 0x30
00007a66921d99cf  vmovaps xmm0, [rsp]
00007a66921d99d4  vmovaps xmm1, [rsp+0x10]
00007a66921d99da  vmovaps xmm2, [rsp+0x20]
00007a66921d99e0  vmovaps xmm3, [rsp+0x30]
00007a66921d99e6  vmovaps xmm4, [rsp+0x40]
00007a66921d99ec  vmovaps xmm5, [rsp+0x50]
00007a66921d99f2  vmovaps xmm6, [rsp+0x60]
00007a66921d99f8  vmovaps xmm7, [rsp+0x70]
00007a66921d99fe  vmovaps xmm8, [rsp+0x80]
00007a66921d9a07  vmovaps xmm9, [rsp+0x90]
00007a66921d9a10  vmovaps xmm10, [rsp+0xA0]
00007a66921d9a19  vmovaps xmm11, [rsp+0xB0]
00007a66921d9a22  vmovaps xmm12, [rsp+0xC0]
00007a66921d9a2b  vmovaps xmm13, [rsp+0xD0]
00007a66921d9a34  vmovaps xmm14, [rsp+0xE0]
00007a66921d9a3d  add rsp, 0xF0
00007a66921d9a44  pop r11
00007a66921d9a46  pop r10
00007a66921d9a48  pop r9
00007a66921d9a4a  pop r8
00007a66921d9a4c  pop rsi
00007a66921d9a4d  pop rdi
00007a66921d9a4e  pop rdx
00007a66921d9a4f  pop rcx
00007a66921d9a50  pop rax
00007a66921d9a51  add rsp, 0x08
00007a66921d9a55  jmp 0x00007A66921D62C0
00007a66921d9a5a  call 0x00007A66920D64F0
00007a66921d9a5f  jmp 0x00007A66921D631B
00007a66921d9a64  sub rsp, 0x08
00007a66921d9a68  push rax
00007a66921d9a69  push rcx
00007a66921d9a6a  push rdx
00007a66921d9a6b  push rdi
00007a66921d9a6c  push rsi
00007a66921d9a6d  push r8
00007a66921d9a6f  push r9
00007a66921d9a71  push r10
00007a66921d9a73  push r11
00007a66921d9a75  sub rsp, 0xF0
00007a66921d9a7c  vmovaps [rsp], xmm0
00007a66921d9a81  vmovaps [rsp+0x10], xmm1
00007a66921d9a87  vmovaps [rsp+0x20], xmm2
00007a66921d9a8d  vmovaps [rsp+0x30], xmm3
00007a66921d9a93  vmovaps [rsp+0x40], xmm4
00007a66921d9a99  vmovaps [rsp+0x50], xmm5
00007a66921d9a9f  vmovaps [rsp+0x60], xmm6
00007a66921d9aa5  vmovaps [rsp+0x70], xmm7
00007a66921d9aab  vmovaps [rsp+0x80], xmm8
00007a66921d9ab4  vmovaps [rsp+0x90], xmm10
00007a66921d9abd  vmovaps [rsp+0xA0], xmm11
00007a66921d9ac6  vmovaps [rsp+0xB0], xmm12
00007a66921d9acf  vmovaps [rsp+0xC0], xmm13
00007a66921d9ad8  vmovaps [rsp+0xD0], xmm14
00007a66921d9ae1  vmovaps [rsp+0xE0], xmm15
00007a66921d9aea  sub rsp, 0x30
00007a66921d9aee  movaps [rsp], xmm9
00007a66921d9af3  movaps [rsp+0x10], xmm8
00007a66921d9af9  movaps [rsp+0x20], xmm11
00007a66921d9aff  lea rdi, [rsp]
00007a66921d9b03  mov esi, 0x00
00007a66921d9b08  mov rax, 0x635346DC7530
00007a66921d9b12  call rax
00007a66921d9b14  movaps xmm9, [rsp]
00007a66921d9b19  add rsp, 0x30
00007a66921d9b1d  vmovaps xmm0, [rsp]
00007a66921d9b22  vmovaps xmm1, [rsp+0x10]
00007a66921d9b28  vmovaps xmm2, [rsp+0x20]
00007a66921d9b2e  vmovaps xmm3, [rsp+0x30]
00007a66921d9b34  vmovaps xmm4, [rsp+0x40]
00007a66921d9b3a  vmovaps xmm5, [rsp+0x50]
00007a66921d9b40  vmovaps xmm6, [rsp+0x60]
00007a66921d9b46  vmovaps xmm7, [rsp+0x70]
00007a66921d9b4c  vmovaps xmm8, [rsp+0x80]
00007a66921d9b55  vmovaps xmm10, [rsp+0x90]
00007a66921d9b5e  vmovaps xmm11, [rsp+0xA0]
00007a66921d9b67  vmovaps xmm12, [rsp+0xB0]
00007a66921d9b70  vmovaps xmm13, [rsp+0xC0]
00007a66921d9b79  vmovaps xmm14, [rsp+0xD0]
00007a66921d9b82  vmovaps xmm15, [rsp+0xE0]
00007a66921d9b8b  add rsp, 0xF0
00007a66921d9b92  pop r11
00007a66921d9b94  pop r10
00007a66921d9b96  pop r9
00007a66921d9b98  pop r8
00007a66921d9b9a  pop rsi
00007a66921d9b9b  pop rdi
00007a66921d9b9c  pop rdx
00007a66921d9b9d  pop rcx
00007a66921d9b9e  pop rax
00007a66921d9b9f  add rsp, 0x08
00007a66921d9ba3  jmp 0x00007A66921D6352
00007a66921d9ba8  sub rsp, 0x08
00007a66921d9bac  push rax
00007a66921d9bad  push rcx
00007a66921d9bae  push rdx
00007a66921d9baf  push rdi
00007a66921d9bb0  push rsi
00007a66921d9bb1  push r8
00007a66921d9bb3  push r9
00007a66921d9bb5  push r10
00007a66921d9bb7  push r11
00007a66921d9bb9  sub rsp, 0xF0
00007a66921d9bc0  vmovaps [rsp], xmm0
00007a66921d9bc5  vmovaps [rsp+0x10], xmm1
00007a66921d9bcb  vmovaps [rsp+0x20], xmm2
00007a66921d9bd1  vmovaps [rsp+0x30], xmm3
00007a66921d9bd7  vmovaps [rsp+0x40], xmm4
00007a66921d9bdd  vmovaps [rsp+0x50], xmm5
00007a66921d9be3  vmovaps [rsp+0x60], xmm6
00007a66921d9be9  vmovaps [rsp+0x70], xmm7
00007a66921d9bef  vmovaps [rsp+0x80], xmm8
00007a66921d9bf8  vmovaps [rsp+0x90], xmm9
00007a66921d9c01  vmovaps [rsp+0xA0], xmm10
00007a66921d9c0a  vmovaps [rsp+0xB0], xmm12
00007a66921d9c13  vmovaps [rsp+0xC0], xmm13
00007a66921d9c1c  vmovaps [rsp+0xD0], xmm14
00007a66921d9c25  vmovaps [rsp+0xE0], xmm15
00007a66921d9c2e  sub rsp, 0x30
00007a66921d9c32  movaps [rsp], xmm11
00007a66921d9c37  movaps [rsp+0x10], xmm10
00007a66921d9c3d  movaps [rsp+0x20], xmm6
00007a66921d9c42  lea rdi, [rsp]
00007a66921d9c46  mov esi, 0x00
00007a66921d9c4b  mov rax, 0x635346DC7530
00007a66921d9c55  call rax
00007a66921d9c57  movaps xmm11, [rsp]
00007a66921d9c5c  add rsp, 0x30
00007a66921d9c60  vmovaps xmm0, [rsp]
00007a66921d9c65  vmovaps xmm1, [rsp+0x10]
00007a66921d9c6b  vmovaps xmm2, [rsp+0x20]
00007a66921d9c71  vmovaps xmm3, [rsp+0x30]
00007a66921d9c77  vmovaps xmm4, [rsp+0x40]
00007a66921d9c7d  vmovaps xmm5, [rsp+0x50]
00007a66921d9c83  vmovaps xmm6, [rsp+0x60]
00007a66921d9c89  vmovaps xmm7, [rsp+0x70]
00007a66921d9c8f  vmovaps xmm8, [rsp+0x80]
00007a66921d9c98  vmovaps xmm9, [rsp+0x90]
00007a66921d9ca1  vmovaps xmm10, [rsp+0xA0]
00007a66921d9caa  vmovaps xmm12, [rsp+0xB0]
00007a66921d9cb3  vmovaps xmm13, [rsp+0xC0]
00007a66921d9cbc  vmovaps xmm14, [rsp+0xD0]
00007a66921d9cc5  vmovaps xmm15, [rsp+0xE0]
00007a66921d9cce  add rsp, 0xF0
00007a66921d9cd5  pop r11
00007a66921d9cd7  pop r10
00007a66921d9cd9  pop r9
00007a66921d9cdb  pop r8
00007a66921d9cdd  pop rsi
00007a66921d9cde  pop rdi
00007a66921d9cdf  pop rdx
00007a66921d9ce0  pop rcx
00007a66921d9ce1  pop rax
00007a66921d9ce2  add rsp, 0x08
00007a66921d9ce6  jmp 0x00007A66921D636D
00007a66921d9ceb  sub rsp, 0x08
00007a66921d9cef  push rax
00007a66921d9cf0  push rcx
00007a66921d9cf1  push rdx
00007a66921d9cf2  push rdi
00007a66921d9cf3  push rsi
00007a66921d9cf4  push r8
00007a66921d9cf6  push r9
00007a66921d9cf8  push r10
00007a66921d9cfa  push r11
00007a66921d9cfc  sub rsp, 0xF0
00007a66921d9d03  vmovaps [rsp], xmm0
00007a66921d9d08  vmovaps [rsp+0x10], xmm1
00007a66921d9d0e  vmovaps [rsp+0x20], xmm2
00007a66921d9d14  vmovaps [rsp+0x30], xmm3
00007a66921d9d1a  vmovaps [rsp+0x40], xmm4
00007a66921d9d20  vmovaps [rsp+0x50], xmm5
00007a66921d9d26  vmovaps [rsp+0x60], xmm6
00007a66921d9d2c  vmovaps [rsp+0x70], xmm7
00007a66921d9d32  vmovaps [rsp+0x80], xmm8
00007a66921d9d3b  vmovaps [rsp+0x90], xmm9
00007a66921d9d44  vmovaps [rsp+0xA0], xmm11
00007a66921d9d4d  vmovaps [rsp+0xB0], xmm12
00007a66921d9d56  vmovaps [rsp+0xC0], xmm13
00007a66921d9d5f  vmovaps [rsp+0xD0], xmm14
00007a66921d9d68  vmovaps [rsp+0xE0], xmm15
00007a66921d9d71  sub rsp, 0x30
00007a66921d9d75  movaps [rsp], xmm10
00007a66921d9d7a  movaps [rsp+0x10], xmm14
00007a66921d9d80  movaps [rsp+0x20], xmm4
00007a66921d9d85  lea rdi, [rsp]
00007a66921d9d89  mov esi, 0x00
00007a66921d9d8e  mov rax, 0x635346DC7530
00007a66921d9d98  call rax
00007a66921d9d9a  movaps xmm10, [rsp]
00007a66921d9d9f  add rsp, 0x30
00007a66921d9da3  vmovaps xmm0, [rsp]
00007a66921d9da8  vmovaps xmm1, [rsp+0x10]
00007a66921d9dae  vmovaps xmm2, [rsp+0x20]
00007a66921d9db4  vmovaps xmm3, [rsp+0x30]
00007a66921d9dba  vmovaps xmm4, [rsp+0x40]
00007a66921d9dc0  vmovaps xmm5, [rsp+0x50]
00007a66921d9dc6  vmovaps xmm6, [rsp+0x60]
00007a66921d9dcc  vmovaps xmm7, [rsp+0x70]
00007a66921d9dd2  vmovaps xmm8, [rsp+0x80]
00007a66921d9ddb  vmovaps xmm9, [rsp+0x90]
00007a66921d9de4  vmovaps xmm11, [rsp+0xA0]
00007a66921d9ded  vmovaps xmm12, [rsp+0xB0]
00007a66921d9df6  vmovaps xmm13, [rsp+0xC0]
00007a66921d9dff  vmovaps xmm14, [rsp+0xD0]
00007a66921d9e08  vmovaps xmm15, [rsp+0xE0]
00007a66921d9e11  add rsp, 0xF0
00007a66921d9e18  pop r11
00007a66921d9e1a  pop r10
00007a66921d9e1c  pop r9
00007a66921d9e1e  pop r8
00007a66921d9e20  pop rsi
00007a66921d9e21  pop rdi
00007a66921d9e22  pop rdx
00007a66921d9e23  pop rcx
00007a66921d9e24  pop rax
00007a66921d9e25  add rsp, 0x08
00007a66921d9e29  jmp 0x00007A66921D6388
00007a66921d9e2e  sub rsp, 0x08
00007a66921d9e32  push rax
00007a66921d9e33  push rcx
00007a66921d9e34  push rdx
00007a66921d9e35  push rdi
00007a66921d9e36  push rsi
00007a66921d9e37  push r8
00007a66921d9e39  push r9
00007a66921d9e3b  push r10
00007a66921d9e3d  push r11
00007a66921d9e3f  sub rsp, 0xF0
00007a66921d9e46  vmovaps [rsp], xmm0
00007a66921d9e4b  vmovaps [rsp+0x10], xmm1
00007a66921d9e51  vmovaps [rsp+0x20], xmm2
00007a66921d9e57  vmovaps [rsp+0x30], xmm3
00007a66921d9e5d  vmovaps [rsp+0x40], xmm4
00007a66921d9e63  vmovaps [rsp+0x50], xmm5
00007a66921d9e69  vmovaps [rsp+0x60], xmm6
00007a66921d9e6f  vmovaps [rsp+0x70], xmm7
00007a66921d9e75  vmovaps [rsp+0x80], xmm9
00007a66921d9e7e  vmovaps [rsp+0x90], xmm10
00007a66921d9e87  vmovaps [rsp+0xA0], xmm11
00007a66921d9e90  vmovaps [rsp+0xB0], xmm12
00007a66921d9e99  vmovaps [rsp+0xC0], xmm13
00007a66921d9ea2  vmovaps [rsp+0xD0], xmm14
00007a66921d9eab  vmovaps [rsp+0xE0], xmm15
00007a66921d9eb4  sub rsp, 0x30
00007a66921d9eb8  movaps [rsp], xmm8
00007a66921d9ebd  movaps [rsp+0x10], xmm1
00007a66921d9ec2  movaps [rsp+0x20], xmm14
00007a66921d9ec8  lea rdi, [rsp]
00007a66921d9ecc  mov esi, 0x00
00007a66921d9ed1  mov rax, 0x635346DC7530
00007a66921d9edb  call rax
00007a66921d9edd  movaps xmm8, [rsp]
00007a66921d9ee2  add rsp, 0x30
00007a66921d9ee6  vmovaps xmm0, [rsp]
00007a66921d9eeb  vmovaps xmm1, [rsp+0x10]
00007a66921d9ef1  vmovaps xmm2, [rsp+0x20]
00007a66921d9ef7  vmovaps xmm3, [rsp+0x30]
00007a66921d9efd  vmovaps xmm4, [rsp+0x40]
00007a66921d9f03  vmovaps xmm5, [rsp+0x50]
00007a66921d9f09  vmovaps xmm6, [rsp+0x60]
00007a66921d9f0f  vmovaps xmm7, [rsp+0x70]
00007a66921d9f15  vmovaps xmm9, [rsp+0x80]
00007a66921d9f1e  vmovaps xmm10, [rsp+0x90]
00007a66921d9f27  vmovaps xmm11, [rsp+0xA0]
00007a66921d9f30  vmovaps xmm12, [rsp+0xB0]
00007a66921d9f39  vmovaps xmm13, [rsp+0xC0]
00007a66921d9f42  vmovaps xmm14, [rsp+0xD0]
00007a66921d9f4b  vmovaps xmm15, [rsp+0xE0]
00007a66921d9f54  add rsp, 0xF0
00007a66921d9f5b  pop r11
00007a66921d9f5d  pop r10
00007a66921d9f5f  pop r9
00007a66921d9f61  pop r8
00007a66921d9f63  pop rsi
00007a66921d9f64  pop rdi
00007a66921d9f65  pop rdx
00007a66921d9f66  pop rcx
00007a66921d9f67  pop rax
00007a66921d9f68  add rsp, 0x08
00007a66921d9f6c  jmp 0x00007A66921D63AE
00007a66921d9f71  sub rsp, 0x08
00007a66921d9f75  push rax
00007a66921d9f76  push rcx
00007a66921d9f77  push rdx
00007a66921d9f78  push rdi
00007a66921d9f79  push rsi
00007a66921d9f7a  push r8
00007a66921d9f7c  push r9
00007a66921d9f7e  push r10
00007a66921d9f80  push r11
00007a66921d9f82  sub rsp, 0xF0
00007a66921d9f89  vmovaps [rsp], xmm0
00007a66921d9f8e  vmovaps [rsp+0x10], xmm1
00007a66921d9f94  vmovaps [rsp+0x20], xmm2
00007a66921d9f9a  vmovaps [rsp+0x30], xmm3
00007a66921d9fa0  vmovaps [rsp+0x40], xmm4
00007a66921d9fa6  vmovaps [rsp+0x50], xmm5
00007a66921d9fac  vmovaps [rsp+0x60], xmm7
00007a66921d9fb2  vmovaps [rsp+0x70], xmm8
00007a66921d9fb8  vmovaps [rsp+0x80], xmm9
00007a66921d9fc1  vmovaps [rsp+0x90], xmm10
00007a66921d9fca  vmovaps [rsp+0xA0], xmm11
00007a66921d9fd3  vmovaps [rsp+0xB0], xmm12
00007a66921d9fdc  vmovaps [rsp+0xC0], xmm13
00007a66921d9fe5  vmovaps [rsp+0xD0], xmm14
00007a66921d9fee  vmovaps [rsp+0xE0], xmm15
00007a66921d9ff7  sub rsp, 0x30
00007a66921d9ffb  movaps [rsp], xmm6
00007a66921d9fff  movaps [rsp+0x10], xmm1
00007a66921da004  movaps [rsp+0x20], xmm14
00007a66921da00a  lea rdi, [rsp]
00007a66921da00e  mov esi, 0x00
00007a66921da013  mov rax, 0x635346DC7530
00007a66921da01d  call rax
00007a66921da01f  movaps xmm6, [rsp]
00007a66921da023  add rsp, 0x30
00007a66921da027  vmovaps xmm0, [rsp]
00007a66921da02c  vmovaps xmm1, [rsp+0x10]
00007a66921da032  vmovaps xmm2, [rsp+0x20]
00007a66921da038  vmovaps xmm3, [rsp+0x30]
00007a66921da03e  vmovaps xmm4, [rsp+0x40]
00007a66921da044  vmovaps xmm5, [rsp+0x50]
00007a66921da04a  vmovaps xmm7, [rsp+0x60]
00007a66921da050  vmovaps xmm8, [rsp+0x70]
00007a66921da056  vmovaps xmm9, [rsp+0x80]
00007a66921da05f  vmovaps xmm10, [rsp+0x90]
00007a66921da068  vmovaps xmm11, [rsp+0xA0]
00007a66921da071  vmovaps xmm12, [rsp+0xB0]
00007a66921da07a  vmovaps xmm13, [rsp+0xC0]
00007a66921da083  vmovaps xmm14, [rsp+0xD0]
00007a66921da08c  vmovaps xmm15, [rsp+0xE0]
00007a66921da095  add rsp, 0xF0
00007a66921da09c  pop r11
00007a66921da09e  pop r10
00007a66921da0a0  pop r9
00007a66921da0a2  pop r8
00007a66921da0a4  pop rsi
00007a66921da0a5  pop rdi
00007a66921da0a6  pop rdx
00007a66921da0a7  pop rcx
00007a66921da0a8  pop rax
00007a66921da0a9  add rsp, 0x08
00007a66921da0ad  jmp 0x00007A66921D63DA
00007a66921da0b2  sub rsp, 0x08
00007a66921da0b6  push rax
00007a66921da0b7  push rcx
00007a66921da0b8  push rdx
00007a66921da0b9  push rdi
00007a66921da0ba  push rsi
00007a66921da0bb  push r8
00007a66921da0bd  push r9
00007a66921da0bf  push r10
00007a66921da0c1  push r11
00007a66921da0c3  sub rsp, 0xF0
00007a66921da0ca  vmovaps [rsp], xmm0
00007a66921da0cf  vmovaps [rsp+0x10], xmm1
00007a66921da0d5  vmovaps [rsp+0x20], xmm2
00007a66921da0db  vmovaps [rsp+0x30], xmm3
00007a66921da0e1  vmovaps [rsp+0x40], xmm4
00007a66921da0e7  vmovaps [rsp+0x50], xmm5
00007a66921da0ed  vmovaps [rsp+0x60], xmm6
00007a66921da0f3  vmovaps [rsp+0x70], xmm7
00007a66921da0f9  vmovaps [rsp+0x80], xmm8
00007a66921da102  vmovaps [rsp+0x90], xmm9
00007a66921da10b  vmovaps [rsp+0xA0], xmm10
00007a66921da114  vmovaps [rsp+0xB0], xmm11
00007a66921da11d  vmovaps [rsp+0xC0], xmm12
00007a66921da126  vmovaps [rsp+0xD0], xmm13
00007a66921da12f  vmovaps [rsp+0xE0], xmm15
00007a66921da138  sub rsp, 0x30
00007a66921da13c  movaps [rsp], xmm14
00007a66921da141  movaps [rsp+0x10], xmm12
00007a66921da147  movaps [rsp+0x20], xmm1
00007a66921da14c  lea rdi, [rsp]
00007a66921da150  mov esi, 0x00
00007a66921da155  mov rax, 0x635346DC7530
00007a66921da15f  call rax
00007a66921da161  movaps xmm14, [rsp]
00007a66921da166  add rsp, 0x30
00007a66921da16a  vmovaps xmm0, [rsp]
00007a66921da16f  vmovaps xmm1, [rsp+0x10]
00007a66921da175  vmovaps xmm2, [rsp+0x20]
00007a66921da17b  vmovaps xmm3, [rsp+0x30]
00007a66921da181  vmovaps xmm4, [rsp+0x40]
00007a66921da187  vmovaps xmm5, [rsp+0x50]
00007a66921da18d  vmovaps xmm6, [rsp+0x60]
00007a66921da193  vmovaps xmm7, [rsp+0x70]
00007a66921da199  vmovaps xmm8, [rsp+0x80]
00007a66921da1a2  vmovaps xmm9, [rsp+0x90]
00007a66921da1ab  vmovaps xmm10, [rsp+0xA0]
00007a66921da1b4  vmovaps xmm11, [rsp+0xB0]
00007a66921da1bd  vmovaps xmm12, [rsp+0xC0]
00007a66921da1c6  vmovaps xmm13, [rsp+0xD0]
00007a66921da1cf  vmovaps xmm15, [rsp+0xE0]
00007a66921da1d8  add rsp, 0xF0
00007a66921da1df  pop r11
00007a66921da1e1  pop r10
00007a66921da1e3  pop r9
00007a66921da1e5  pop r8
00007a66921da1e7  pop rsi
00007a66921da1e8  pop rdi
00007a66921da1e9  pop rdx
00007a66921da1ea  pop rcx
00007a66921da1eb  pop rax
00007a66921da1ec  add rsp, 0x08
00007a66921da1f0  jmp 0x00007A66921D6400
00007a66921da1f5  sub rsp, 0x08
00007a66921da1f9  push rax
00007a66921da1fa  push rcx
00007a66921da1fb  push rdx
00007a66921da1fc  push rdi
00007a66921da1fd  push rsi
00007a66921da1fe  push r8
00007a66921da200  push r9
00007a66921da202  push r10
00007a66921da204  push r11
00007a66921da206  sub rsp, 0xF0
00007a66921da20d  vmovaps [rsp], xmm0
00007a66921da212  vmovaps [rsp+0x10], xmm2
00007a66921da218  vmovaps [rsp+0x20], xmm3
00007a66921da21e  vmovaps [rsp+0x30], xmm4
00007a66921da224  vmovaps [rsp+0x40], xmm5
00007a66921da22a  vmovaps [rsp+0x50], xmm6
00007a66921da230  vmovaps [rsp+0x60], xmm7
00007a66921da236  vmovaps [rsp+0x70], xmm8
00007a66921da23c  vmovaps [rsp+0x80], xmm9
00007a66921da245  vmovaps [rsp+0x90], xmm10
00007a66921da24e  vmovaps [rsp+0xA0], xmm11
00007a66921da257  vmovaps [rsp+0xB0], xmm12
00007a66921da260  vmovaps [rsp+0xC0], xmm13
00007a66921da269  vmovaps [rsp+0xD0], xmm14
00007a66921da272  vmovaps [rsp+0xE0], xmm15
00007a66921da27b  sub rsp, 0x30
00007a66921da27f  movaps [rsp], xmm1
00007a66921da283  movaps [rsp+0x10], xmm13
00007a66921da289  movaps [rsp+0x20], xmm9
00007a66921da28f  lea rdi, [rsp]
00007a66921da293  mov esi, 0x00
00007a66921da298  mov rax, 0x635346DC7530
00007a66921da2a2  call rax
00007a66921da2a4  movaps xmm1, [rsp]
00007a66921da2a8  add rsp, 0x30
00007a66921da2ac  vmovaps xmm0, [rsp]
00007a66921da2b1  vmovaps xmm2, [rsp+0x10]
00007a66921da2b7  vmovaps xmm3, [rsp+0x20]
00007a66921da2bd  vmovaps xmm4, [rsp+0x30]
00007a66921da2c3  vmovaps xmm5, [rsp+0x40]
00007a66921da2c9  vmovaps xmm6, [rsp+0x50]
00007a66921da2cf  vmovaps xmm7, [rsp+0x60]
00007a66921da2d5  vmovaps xmm8, [rsp+0x70]
00007a66921da2db  vmovaps xmm9, [rsp+0x80]
00007a66921da2e4  vmovaps xmm10, [rsp+0x90]
00007a66921da2ed  vmovaps xmm11, [rsp+0xA0]
00007a66921da2f6  vmovaps xmm12, [rsp+0xB0]
00007a66921da2ff  vmovaps xmm13, [rsp+0xC0]
00007a66921da308  vmovaps xmm14, [rsp+0xD0]
00007a66921da311  vmovaps xmm15, [rsp+0xE0]
00007a66921da31a  add rsp, 0xF0
00007a66921da321  pop r11
00007a66921da323  pop r10
00007a66921da325  pop r9
00007a66921da327  pop r8
00007a66921da329  pop rsi
00007a66921da32a  pop rdi
00007a66921da32b  pop rdx
00007a66921da32c  pop rcx
00007a66921da32d  pop rax
00007a66921da32e  add rsp, 0x08
00007a66921da332  jmp 0x00007A66921D641A
00007a66921da337  sub rsp, 0x08
00007a66921da33b  push rax
00007a66921da33c  push rcx
00007a66921da33d  push rdx
00007a66921da33e  push rdi
00007a66921da33f  push rsi
00007a66921da340  push r8
00007a66921da342  push r9
00007a66921da344  push r10
00007a66921da346  push r11
00007a66921da348  sub rsp, 0xF0
00007a66921da34f  vmovaps [rsp], xmm0
00007a66921da354  vmovaps [rsp+0x10], xmm1
00007a66921da35a  vmovaps [rsp+0x20], xmm2
00007a66921da360  vmovaps [rsp+0x30], xmm3
00007a66921da366  vmovaps [rsp+0x40], xmm4
00007a66921da36c  vmovaps [rsp+0x50], xmm5
00007a66921da372  vmovaps [rsp+0x60], xmm6
00007a66921da378  vmovaps [rsp+0x70], xmm7
00007a66921da37e  vmovaps [rsp+0x80], xmm8
00007a66921da387  vmovaps [rsp+0x90], xmm9
00007a66921da390  vmovaps [rsp+0xA0], xmm10
00007a66921da399  vmovaps [rsp+0xB0], xmm11
00007a66921da3a2  vmovaps [rsp+0xC0], xmm13
00007a66921da3ab  vmovaps [rsp+0xD0], xmm14
00007a66921da3b4  vmovaps [rsp+0xE0], xmm15
00007a66921da3bd  sub rsp, 0x30
00007a66921da3c1  movaps [rsp], xmm12
00007a66921da3c6  movaps [rsp+0x10], xmm7
00007a66921da3cb  movaps [rsp+0x20], xmm13
00007a66921da3d1  lea rdi, [rsp]
00007a66921da3d5  mov esi, 0x00
00007a66921da3da  mov rax, 0x635346DC7530
00007a66921da3e4  call rax
00007a66921da3e6  movaps xmm12, [rsp]
00007a66921da3eb  add rsp, 0x30
00007a66921da3ef  vmovaps xmm0, [rsp]
00007a66921da3f4  vmovaps xmm1, [rsp+0x10]
00007a66921da3fa  vmovaps xmm2, [rsp+0x20]
00007a66921da400  vmovaps xmm3, [rsp+0x30]
00007a66921da406  vmovaps xmm4, [rsp+0x40]
00007a66921da40c  vmovaps xmm5, [rsp+0x50]
00007a66921da412  vmovaps xmm6, [rsp+0x60]
00007a66921da418  vmovaps xmm7, [rsp+0x70]
00007a66921da41e  vmovaps xmm8, [rsp+0x80]
00007a66921da427  vmovaps xmm9, [rsp+0x90]
00007a66921da430  vmovaps xmm10, [rsp+0xA0]
00007a66921da439  vmovaps xmm11, [rsp+0xB0]
00007a66921da442  vmovaps xmm13, [rsp+0xC0]
00007a66921da44b  vmovaps xmm14, [rsp+0xD0]
00007a66921da454  vmovaps xmm15, [rsp+0xE0]
00007a66921da45d  add rsp, 0xF0
00007a66921da464  pop r11
00007a66921da466  pop r10
00007a66921da468  pop r9
00007a66921da46a  pop r8
00007a66921da46c  pop rsi
00007a66921da46d  pop rdi
00007a66921da46e  pop rdx
00007a66921da46f  pop rcx
00007a66921da470  pop rax
00007a66921da471  add rsp, 0x08
00007a66921da475  jmp 0x00007A66921D6441
00007a66921da47a  sub rsp, 0x08
00007a66921da47e  push rax
00007a66921da47f  push rcx
00007a66921da480  push rdx
00007a66921da481  push rdi
00007a66921da482  push rsi
00007a66921da483  push r8
00007a66921da485  push r9
00007a66921da487  push r10
00007a66921da489  push r11
00007a66921da48b  sub rsp, 0xF0
00007a66921da492  vmovaps [rsp], xmm0
00007a66921da497  vmovaps [rsp+0x10], xmm1
00007a66921da49d  vmovaps [rsp+0x20], xmm2
00007a66921da4a3  vmovaps [rsp+0x30], xmm3
00007a66921da4a9  vmovaps [rsp+0x40], xmm4
00007a66921da4af  vmovaps [rsp+0x50], xmm5
00007a66921da4b5  vmovaps [rsp+0x60], xmm6
00007a66921da4bb  vmovaps [rsp+0x70], xmm7
00007a66921da4c1  vmovaps [rsp+0x80], xmm8
00007a66921da4ca  vmovaps [rsp+0x90], xmm9
00007a66921da4d3  vmovaps [rsp+0xA0], xmm10
00007a66921da4dc  vmovaps [rsp+0xB0], xmm11
00007a66921da4e5  vmovaps [rsp+0xC0], xmm12
00007a66921da4ee  vmovaps [rsp+0xD0], xmm14
00007a66921da4f7  vmovaps [rsp+0xE0], xmm15
00007a66921da500  sub rsp, 0x30
00007a66921da504  movaps [rsp], xmm13
00007a66921da509  movaps [rsp+0x10], xmm15
00007a66921da50f  movaps [rsp+0x20], xmm8
00007a66921da515  lea rdi, [rsp]
00007a66921da519  mov esi, 0x00
00007a66921da51e  mov rax, 0x635346DC7530
00007a66921da528  call rax
00007a66921da52a  movaps xmm13, [rsp]
00007a66921da52f  add rsp, 0x30
00007a66921da533  vmovaps xmm0, [rsp]
00007a66921da538  vmovaps xmm1, [rsp+0x10]
00007a66921da53e  vmovaps xmm2, [rsp+0x20]
00007a66921da544  vmovaps xmm3, [rsp+0x30]
00007a66921da54a  vmovaps xmm4, [rsp+0x40]
00007a66921da550  vmovaps xmm5, [rsp+0x50]
00007a66921da556  vmovaps xmm6, [rsp+0x60]
00007a66921da55c  vmovaps xmm7, [rsp+0x70]
00007a66921da562  vmovaps xmm8, [rsp+0x80]
00007a66921da56b  vmovaps xmm9, [rsp+0x90]
00007a66921da574  vmovaps xmm10, [rsp+0xA0]
00007a66921da57d  vmovaps xmm11, [rsp+0xB0]
00007a66921da586  vmovaps xmm12, [rsp+0xC0]
00007a66921da58f  vmovaps xmm14, [rsp+0xD0]
00007a66921da598  vmovaps xmm15, [rsp+0xE0]
00007a66921da5a1  add rsp, 0xF0
00007a66921da5a8  pop r11
00007a66921da5aa  pop r10
00007a66921da5ac  pop r9
00007a66921da5ae  pop r8
00007a66921da5b0  pop rsi
00007a66921da5b1  pop rdi
00007a66921da5b2  pop rdx
00007a66921da5b3  pop rcx
00007a66921da5b4  pop rax
00007a66921da5b5  add rsp, 0x08
00007a66921da5b9  jmp 0x00007A66921D645C
00007a66921da5be  sub rsp, 0x08
00007a66921da5c2  push rax
00007a66921da5c3  push rcx
00007a66921da5c4  push rdx
00007a66921da5c5  push rdi
00007a66921da5c6  push rsi
00007a66921da5c7  push r8
00007a66921da5c9  push r9
00007a66921da5cb  push r10
00007a66921da5cd  push r11
00007a66921da5cf  sub rsp, 0xF0
00007a66921da5d6  vmovaps [rsp], xmm0
00007a66921da5db  vmovaps [rsp+0x10], xmm1
00007a66921da5e1  vmovaps [rsp+0x20], xmm2
00007a66921da5e7  vmovaps [rsp+0x30], xmm3
00007a66921da5ed  vmovaps [rsp+0x40], xmm4
00007a66921da5f3  vmovaps [rsp+0x50], xmm5
00007a66921da5f9  vmovaps [rsp+0x60], xmm6
00007a66921da5ff  vmovaps [rsp+0x70], xmm7
00007a66921da605  vmovaps [rsp+0x80], xmm9
00007a66921da60e  vmovaps [rsp+0x90], xmm10
00007a66921da617  vmovaps [rsp+0xA0], xmm11
00007a66921da620  vmovaps [rsp+0xB0], xmm12
00007a66921da629  vmovaps [rsp+0xC0], xmm13
00007a66921da632  vmovaps [rsp+0xD0], xmm14
00007a66921da63b  vmovaps [rsp+0xE0], xmm15
00007a66921da644  sub rsp, 0x30
00007a66921da648  movaps [rsp], xmm8
00007a66921da64d  movaps [rsp+0x10], xmm15
00007a66921da653  movaps [rsp+0x20], xmm9
00007a66921da659  lea rdi, [rsp]
00007a66921da65d  mov esi, 0x00
00007a66921da662  mov rax, 0x635346DC7530
00007a66921da66c  call rax
00007a66921da66e  movaps xmm8, [rsp]
00007a66921da673  add rsp, 0x30
00007a66921da677  vmovaps xmm0, [rsp]
00007a66921da67c  vmovaps xmm1, [rsp+0x10]
00007a66921da682  vmovaps xmm2, [rsp+0x20]
00007a66921da688  vmovaps xmm3, [rsp+0x30]
00007a66921da68e  vmovaps xmm4, [rsp+0x40]
00007a66921da694  vmovaps xmm5, [rsp+0x50]
00007a66921da69a  vmovaps xmm6, [rsp+0x60]
00007a66921da6a0  vmovaps xmm7, [rsp+0x70]
00007a66921da6a6  vmovaps xmm9, [rsp+0x80]
00007a66921da6af  vmovaps xmm10, [rsp+0x90]
00007a66921da6b8  vmovaps xmm11, [rsp+0xA0]
00007a66921da6c1  vmovaps xmm12, [rsp+0xB0]
00007a66921da6ca  vmovaps xmm13, [rsp+0xC0]
00007a66921da6d3  vmovaps xmm14, [rsp+0xD0]
00007a66921da6dc  vmovaps xmm15, [rsp+0xE0]
00007a66921da6e5  add rsp, 0xF0
00007a66921da6ec  pop r11
00007a66921da6ee  pop r10
00007a66921da6f0  pop r9
00007a66921da6f2  pop r8
00007a66921da6f4  pop rsi
00007a66921da6f5  pop rdi
00007a66921da6f6  pop rdx
00007a66921da6f7  pop rcx
00007a66921da6f8  pop rax
00007a66921da6f9  add rsp, 0x08
00007a66921da6fd  jmp 0x00007A66921D648A
00007a66921da702  sub rsp, 0x08
00007a66921da706  push rax
00007a66921da707  push rcx
00007a66921da708  push rdx
00007a66921da709  push rdi
00007a66921da70a  push rsi
00007a66921da70b  push r8
00007a66921da70d  push r9
00007a66921da70f  push r10
00007a66921da711  push r11
00007a66921da713  sub rsp, 0xF0
00007a66921da71a  vmovaps [rsp], xmm0
00007a66921da71f  vmovaps [rsp+0x10], xmm1
00007a66921da725  vmovaps [rsp+0x20], xmm2
00007a66921da72b  vmovaps [rsp+0x30], xmm3
00007a66921da731  vmovaps [rsp+0x40], xmm4
00007a66921da737  vmovaps [rsp+0x50], xmm5
00007a66921da73d  vmovaps [rsp+0x60], xmm6
00007a66921da743  vmovaps [rsp+0x70], xmm7
00007a66921da749  vmovaps [rsp+0x80], xmm8
00007a66921da752  vmovaps [rsp+0x90], xmm9
00007a66921da75b  vmovaps [rsp+0xA0], xmm10
00007a66921da764  vmovaps [rsp+0xB0], xmm11
00007a66921da76d  vmovaps [rsp+0xC0], xmm12
00007a66921da776  vmovaps [rsp+0xD0], xmm13
00007a66921da77f  vmovaps [rsp+0xE0], xmm14
00007a66921da788  sub rsp, 0x30
00007a66921da78c  movaps [rsp], xmm15
00007a66921da791  movaps [rsp+0x10], xmm11
00007a66921da797  movaps [rsp+0x20], xmm6
00007a66921da79c  lea rdi, [rsp]
00007a66921da7a0  mov esi, 0x00
00007a66921da7a5  mov rax, 0x635346DC7530
00007a66921da7af  call rax
00007a66921da7b1  movaps xmm15, [rsp]
00007a66921da7b6  add rsp, 0x30
00007a66921da7ba  vmovaps xmm0, [rsp]
00007a66921da7bf  vmovaps xmm1, [rsp+0x10]
00007a66921da7c5  vmovaps xmm2, [rsp+0x20]
00007a66921da7cb  vmovaps xmm3, [rsp+0x30]
00007a66921da7d1  vmovaps xmm4, [rsp+0x40]
00007a66921da7d7  vmovaps xmm5, [rsp+0x50]
00007a66921da7dd  vmovaps xmm6, [rsp+0x60]
00007a66921da7e3  vmovaps xmm7, [rsp+0x70]
00007a66921da7e9  vmovaps xmm8, [rsp+0x80]
00007a66921da7f2  vmovaps xmm9, [rsp+0x90]
00007a66921da7fb  vmovaps xmm10, [rsp+0xA0]
00007a66921da804  vmovaps xmm11, [rsp+0xB0]
00007a66921da80d  vmovaps xmm12, [rsp+0xC0]
00007a66921da816  vmovaps xmm13, [rsp+0xD0]
00007a66921da81f  vmovaps xmm14, [rsp+0xE0]
00007a66921da828  add rsp, 0xF0
00007a66921da82f  pop r11
00007a66921da831  pop r10
00007a66921da833  pop r9
00007a66921da835  pop r8
00007a66921da837  pop rsi
00007a66921da838  pop rdi
00007a66921da839  pop rdx
00007a66921da83a  pop rcx
00007a66921da83b  pop rax
00007a66921da83c  add rsp, 0x08
00007a66921da840  jmp 0x00007A66921D64A5
00007a66921da845  sub rsp, 0x08
00007a66921da849  push rax
00007a66921da84a  push rcx
00007a66921da84b  push rdx
00007a66921da84c  push rdi
00007a66921da84d  push rsi
00007a66921da84e  push r8
00007a66921da850  push r9
00007a66921da852  push r10
00007a66921da854  push r11
00007a66921da856  sub rsp, 0xF0
00007a66921da85d  vmovaps [rsp], xmm0
00007a66921da862  vmovaps [rsp+0x10], xmm1
00007a66921da868  vmovaps [rsp+0x20], xmm2
00007a66921da86e  vmovaps [rsp+0x30], xmm3
00007a66921da874  vmovaps [rsp+0x40], xmm4
00007a66921da87a  vmovaps [rsp+0x50], xmm5
00007a66921da880  vmovaps [rsp+0x60], xmm6
00007a66921da886  vmovaps [rsp+0x70], xmm8
00007a66921da88c  vmovaps [rsp+0x80], xmm9
00007a66921da895  vmovaps [rsp+0x90], xmm10
00007a66921da89e  vmovaps [rsp+0xA0], xmm11
00007a66921da8a7  vmovaps [rsp+0xB0], xmm12
00007a66921da8b0  vmovaps [rsp+0xC0], xmm13
00007a66921da8b9  vmovaps [rsp+0xD0], xmm14
00007a66921da8c2  vmovaps [rsp+0xE0], xmm15
00007a66921da8cb  sub rsp, 0x30
00007a66921da8cf  movaps [rsp], xmm7
00007a66921da8d3  movaps [rsp+0x10], xmm11
00007a66921da8d9  movaps [rsp+0x20], xmm9
00007a66921da8df  lea rdi, [rsp]
00007a66921da8e3  mov esi, 0x00
00007a66921da8e8  mov rax, 0x635346DC7530
00007a66921da8f2  call rax
00007a66921da8f4  movaps xmm7, [rsp]
00007a66921da8f8  add rsp, 0x30
00007a66921da8fc  vmovaps xmm0, [rsp]
00007a66921da901  vmovaps xmm1, [rsp+0x10]
00007a66921da907  vmovaps xmm2, [rsp+0x20]
00007a66921da90d  vmovaps xmm3, [rsp+0x30]
00007a66921da913  vmovaps xmm4, [rsp+0x40]
00007a66921da919  vmovaps xmm5, [rsp+0x50]
00007a66921da91f  vmovaps xmm6, [rsp+0x60]
00007a66921da925  vmovaps xmm8, [rsp+0x70]
00007a66921da92b  vmovaps xmm9, [rsp+0x80]
00007a66921da934  vmovaps xmm10, [rsp+0x90]
00007a66921da93d  vmovaps xmm11, [rsp+0xA0]
00007a66921da946  vmovaps xmm12, [rsp+0xB0]
00007a66921da94f  vmovaps xmm13, [rsp+0xC0]
00007a66921da958  vmovaps xmm14, [rsp+0xD0]
00007a66921da961  vmovaps xmm15, [rsp+0xE0]
00007a66921da96a  add rsp, 0xF0
00007a66921da971  pop r11
00007a66921da973  pop r10
00007a66921da975  pop r9
00007a66921da977  pop r8
00007a66921da979  pop rsi
00007a66921da97a  pop rdi
00007a66921da97b  pop rdx
00007a66921da97c  pop rcx
00007a66921da97d  pop rax
00007a66921da97e  add rsp, 0x08
00007a66921da982  jmp 0x00007A66921D64D2
00007a66921da987  sub rsp, 0x08
00007a66921da98b  push rax
00007a66921da98c  push rcx
00007a66921da98d  push rdx
00007a66921da98e  push rdi
00007a66921da98f  push rsi
00007a66921da990  push r8
00007a66921da992  push r9
00007a66921da994  push r10
00007a66921da996  push r11
00007a66921da998  sub rsp, 0xF0
00007a66921da99f  vmovaps [rsp], xmm0
00007a66921da9a4  vmovaps [rsp+0x10], xmm1
00007a66921da9aa  vmovaps [rsp+0x20], xmm2
00007a66921da9b0  vmovaps [rsp+0x30], xmm3
00007a66921da9b6  vmovaps [rsp+0x40], xmm4
00007a66921da9bc  vmovaps [rsp+0x50], xmm5
00007a66921da9c2  vmovaps [rsp+0x60], xmm6
00007a66921da9c8  vmovaps [rsp+0x70], xmm7
00007a66921da9ce  vmovaps [rsp+0x80], xmm8
00007a66921da9d7  vmovaps [rsp+0x90], xmm9
00007a66921da9e0  vmovaps [rsp+0xA0], xmm10
00007a66921da9e9  vmovaps [rsp+0xB0], xmm12
00007a66921da9f2  vmovaps [rsp+0xC0], xmm13
00007a66921da9fb  vmovaps [rsp+0xD0], xmm14
00007a66921daa04  vmovaps [rsp+0xE0], xmm15
00007a66921daa0d  sub rsp, 0x30
00007a66921daa11  movaps [rsp], xmm11
00007a66921daa16  movaps [rsp+0x10], xmm10
00007a66921daa1c  movaps [rsp+0x20], xmm14
00007a66921daa22  lea rdi, [rsp]
00007a66921daa26  mov esi, 0x00
00007a66921daa2b  mov rax, 0x635346DC7530
00007a66921daa35  call rax
00007a66921daa37  movaps xmm11, [rsp]
00007a66921daa3c  add rsp, 0x30
00007a66921daa40  vmovaps xmm0, [rsp]
00007a66921daa45  vmovaps xmm1, [rsp+0x10]
00007a66921daa4b  vmovaps xmm2, [rsp+0x20]
00007a66921daa51  vmovaps xmm3, [rsp+0x30]
00007a66921daa57  vmovaps xmm4, [rsp+0x40]
00007a66921daa5d  vmovaps xmm5, [rsp+0x50]
00007a66921daa63  vmovaps xmm6, [rsp+0x60]
00007a66921daa69  vmovaps xmm7, [rsp+0x70]
00007a66921daa6f  vmovaps xmm8, [rsp+0x80]
00007a66921daa78  vmovaps xmm9, [rsp+0x90]
00007a66921daa81  vmovaps xmm10, [rsp+0xA0]
00007a66921daa8a  vmovaps xmm12, [rsp+0xB0]
00007a66921daa93  vmovaps xmm13, [rsp+0xC0]
00007a66921daa9c  vmovaps xmm14, [rsp+0xD0]
00007a66921daaa5  vmovaps xmm15, [rsp+0xE0]
00007a66921daaae  add rsp, 0xF0
00007a66921daab5  pop r11
00007a66921daab7  pop r10
00007a66921daab9  pop r9
00007a66921daabb  pop r8
00007a66921daabd  pop rsi
00007a66921daabe  pop rdi
00007a66921daabf  pop rdx
00007a66921daac0  pop rcx
00007a66921daac1  pop rax
00007a66921daac2  add rsp, 0x08
00007a66921daac6  jmp 0x00007A66921D64ED
00007a66921daacb  call 0x00007A66920E45A0
00007a66921daad0  jmp 0x00007A66921D64F7
00007a66921daad5  sub rsp, 0x08
00007a66921daad9  push rax
00007a66921daada  push rcx
00007a66921daadb  push rdx
00007a66921daadc  push rdi
00007a66921daadd  push rsi
00007a66921daade  push r8
00007a66921daae0  push r9
00007a66921daae2  push r10
00007a66921daae4  push r11
00007a66921daae6  sub rsp, 0xF0
00007a66921daaed  vmovaps [rsp], xmm0
00007a66921daaf2  vmovaps [rsp+0x10], xmm1
00007a66921daaf8  vmovaps [rsp+0x20], xmm2
00007a66921daafe  vmovaps [rsp+0x30], xmm3
00007a66921dab04  vmovaps [rsp+0x40], xmm4
00007a66921dab0a  vmovaps [rsp+0x50], xmm5
00007a66921dab10  vmovaps [rsp+0x60], xmm6
00007a66921dab16  vmovaps [rsp+0x70], xmm7
00007a66921dab1c  vmovaps [rsp+0x80], xmm8
00007a66921dab25  vmovaps [rsp+0x90], xmm9
00007a66921dab2e  vmovaps [rsp+0xA0], xmm11
00007a66921dab37  vmovaps [rsp+0xB0], xmm12
00007a66921dab40  vmovaps [rsp+0xC0], xmm13
00007a66921dab49  vmovaps [rsp+0xD0], xmm14
00007a66921dab52  vmovaps [rsp+0xE0], xmm15
00007a66921dab5b  sub rsp, 0x30
00007a66921dab5f  movaps [rsp], xmm10
00007a66921dab64  movaps [rsp+0x10], xmm1
00007a66921dab69  movaps [rsp+0x20], xmm12
00007a66921dab6f  lea rdi, [rsp]
00007a66921dab73  mov esi, 0x00
00007a66921dab78  mov rax, 0x635346DC7530
00007a66921dab82  call rax
00007a66921dab84  movaps xmm10, [rsp]
00007a66921dab89  add rsp, 0x30
00007a66921dab8d  vmovaps xmm0, [rsp]
00007a66921dab92  vmovaps xmm1, [rsp+0x10]
00007a66921dab98  vmovaps xmm2, [rsp+0x20]
00007a66921dab9e  vmovaps xmm3, [rsp+0x30]
00007a66921daba4  vmovaps xmm4, [rsp+0x40]
00007a66921dabaa  vmovaps xmm5, [rsp+0x50]
00007a66921dabb0  vmovaps xmm6, [rsp+0x60]
00007a66921dabb6  vmovaps xmm7, [rsp+0x70]
00007a66921dabbc  vmovaps xmm8, [rsp+0x80]
00007a66921dabc5  vmovaps xmm9, [rsp+0x90]
00007a66921dabce  vmovaps xmm11, [rsp+0xA0]
00007a66921dabd7  vmovaps xmm12, [rsp+0xB0]
00007a66921dabe0  vmovaps xmm13, [rsp+0xC0]
00007a66921dabe9  vmovaps xmm14, [rsp+0xD0]
00007a66921dabf2  vmovaps xmm15, [rsp+0xE0]
00007a66921dabfb  add rsp, 0xF0
00007a66921dac02  pop r11
00007a66921dac04  pop r10
00007a66921dac06  pop r9
00007a66921dac08  pop r8
00007a66921dac0a  pop rsi
00007a66921dac0b  pop rdi
00007a66921dac0c  pop rdx
00007a66921dac0d  pop rcx
00007a66921dac0e  pop rax
00007a66921dac0f  add rsp, 0x08
00007a66921dac13  jmp 0x00007A66921D651A
00007a66921dac18  sub rsp, 0x08
00007a66921dac1c  push rax
00007a66921dac1d  push rcx
00007a66921dac1e  push rdx
00007a66921dac1f  push rdi
00007a66921dac20  push rsi
00007a66921dac21  push r8
00007a66921dac23  push r9
00007a66921dac25  push r10
00007a66921dac27  push r11
00007a66921dac29  sub rsp, 0xF0
00007a66921dac30  vmovaps [rsp], xmm0
00007a66921dac35  vmovaps [rsp+0x10], xmm1
00007a66921dac3b  vmovaps [rsp+0x20], xmm2
00007a66921dac41  vmovaps [rsp+0x30], xmm3
00007a66921dac47  vmovaps [rsp+0x40], xmm4
00007a66921dac4d  vmovaps [rsp+0x50], xmm5
00007a66921dac53  vmovaps [rsp+0x60], xmm6
00007a66921dac59  vmovaps [rsp+0x70], xmm7
00007a66921dac5f  vmovaps [rsp+0x80], xmm8
00007a66921dac68  vmovaps [rsp+0x90], xmm9
00007a66921dac71  vmovaps [rsp+0xA0], xmm10
00007a66921dac7a  vmovaps [rsp+0xB0], xmm11
00007a66921dac83  vmovaps [rsp+0xC0], xmm13
00007a66921dac8c  vmovaps [rsp+0xD0], xmm14
00007a66921dac95  vmovaps [rsp+0xE0], xmm15
00007a66921dac9e  sub rsp, 0x30
00007a66921daca2  movaps [rsp], xmm12
00007a66921daca7  movaps [rsp+0x10], xmm14
00007a66921dacad  movaps [rsp+0x20], xmm1
00007a66921dacb2  lea rdi, [rsp]
00007a66921dacb6  mov esi, 0x00
00007a66921dacbb  mov rax, 0x635346DC7530
00007a66921dacc5  call rax
00007a66921dacc7  movaps xmm12, [rsp]
00007a66921daccc  add rsp, 0x30
00007a66921dacd0  vmovaps xmm0, [rsp]
00007a66921dacd5  vmovaps xmm1, [rsp+0x10]
00007a66921dacdb  vmovaps xmm2, [rsp+0x20]
00007a66921dace1  vmovaps xmm3, [rsp+0x30]
00007a66921dace7  vmovaps xmm4, [rsp+0x40]
00007a66921daced  vmovaps xmm5, [rsp+0x50]
00007a66921dacf3  vmovaps xmm6, [rsp+0x60]
00007a66921dacf9  vmovaps xmm7, [rsp+0x70]
00007a66921dacff  vmovaps xmm8, [rsp+0x80]
00007a66921dad08  vmovaps xmm9, [rsp+0x90]
00007a66921dad11  vmovaps xmm10, [rsp+0xA0]
00007a66921dad1a  vmovaps xmm11, [rsp+0xB0]
00007a66921dad23  vmovaps xmm13, [rsp+0xC0]
00007a66921dad2c  vmovaps xmm14, [rsp+0xD0]
00007a66921dad35  vmovaps xmm15, [rsp+0xE0]
00007a66921dad3e  add rsp, 0xF0
00007a66921dad45  pop r11
00007a66921dad47  pop r10
00007a66921dad49  pop r9
00007a66921dad4b  pop r8
00007a66921dad4d  pop rsi
00007a66921dad4e  pop rdi
00007a66921dad4f  pop rdx
00007a66921dad50  pop rcx
00007a66921dad51  pop rax
00007a66921dad52  add rsp, 0x08
00007a66921dad56  jmp 0x00007A66921D6549
00007a66921dad5b  sub rsp, 0x08
00007a66921dad5f  push rax
00007a66921dad60  push rcx
00007a66921dad61  push rdx
00007a66921dad62  push rdi
00007a66921dad63  push rsi
00007a66921dad64  push r8
00007a66921dad66  push r9
00007a66921dad68  push r10
00007a66921dad6a  push r11
00007a66921dad6c  sub rsp, 0xF0
00007a66921dad73  vmovaps [rsp], xmm0
00007a66921dad78  vmovaps [rsp+0x10], xmm1
00007a66921dad7e  vmovaps [rsp+0x20], xmm2
00007a66921dad84  vmovaps [rsp+0x30], xmm3
00007a66921dad8a  vmovaps [rsp+0x40], xmm4
00007a66921dad90  vmovaps [rsp+0x50], xmm5
00007a66921dad96  vmovaps [rsp+0x60], xmm6
00007a66921dad9c  vmovaps [rsp+0x70], xmm7
00007a66921dada2  vmovaps [rsp+0x80], xmm8
00007a66921dadab  vmovaps [rsp+0x90], xmm9
00007a66921dadb4  vmovaps [rsp+0xA0], xmm10
00007a66921dadbd  vmovaps [rsp+0xB0], xmm11
00007a66921dadc6  vmovaps [rsp+0xC0], xmm12
00007a66921dadcf  vmovaps [rsp+0xD0], xmm13
00007a66921dadd8  vmovaps [rsp+0xE0], xmm15
00007a66921dade1  sub rsp, 0x30
00007a66921dade5  movaps [rsp], xmm14
00007a66921dadea  movaps [rsp+0x10], xmm9
00007a66921dadf0  movaps [rsp+0x20], xmm1
00007a66921dadf5  lea rdi, [rsp]
00007a66921dadf9  mov esi, 0x00
00007a66921dadfe  mov rax, 0x635346DC7530
00007a66921dae08  call rax
00007a66921dae0a  movaps xmm14, [rsp]
00007a66921dae0f  add rsp, 0x30
00007a66921dae13  vmovaps xmm0, [rsp]
00007a66921dae18  vmovaps xmm1, [rsp+0x10]
00007a66921dae1e  vmovaps xmm2, [rsp+0x20]
00007a66921dae24  vmovaps xmm3, [rsp+0x30]
00007a66921dae2a  vmovaps xmm4, [rsp+0x40]
00007a66921dae30  vmovaps xmm5, [rsp+0x50]
00007a66921dae36  vmovaps xmm6, [rsp+0x60]
00007a66921dae3c  vmovaps xmm7, [rsp+0x70]
00007a66921dae42  vmovaps xmm8, [rsp+0x80]
00007a66921dae4b  vmovaps xmm9, [rsp+0x90]
00007a66921dae54  vmovaps xmm10, [rsp+0xA0]
00007a66921dae5d  vmovaps xmm11, [rsp+0xB0]
00007a66921dae66  vmovaps xmm12, [rsp+0xC0]
00007a66921dae6f  vmovaps xmm13, [rsp+0xD0]
00007a66921dae78  vmovaps xmm15, [rsp+0xE0]
00007a66921dae81  add rsp, 0xF0
00007a66921dae88  pop r11
00007a66921dae8a  pop r10
00007a66921dae8c  pop r9
00007a66921dae8e  pop r8
00007a66921dae90  pop rsi
00007a66921dae91  pop rdi
00007a66921dae92  pop rdx
00007a66921dae93  pop rcx
00007a66921dae94  pop rax
00007a66921dae95  add rsp, 0x08
00007a66921dae99  jmp 0x00007A66921D6578
00007a66921dae9e  sub rsp, 0x08
00007a66921daea2  push rax
00007a66921daea3  push rcx
00007a66921daea4  push rdx
00007a66921daea5  push rdi
00007a66921daea6  push rsi
00007a66921daea7  push r8
00007a66921daea9  push r9
00007a66921daeab  push r10
00007a66921daead  push r11
00007a66921daeaf  sub rsp, 0xF0
00007a66921daeb6  vmovaps [rsp], xmm0
00007a66921daebb  vmovaps [rsp+0x10], xmm2
00007a66921daec1  vmovaps [rsp+0x20], xmm3
00007a66921daec7  vmovaps [rsp+0x30], xmm4
00007a66921daecd  vmovaps [rsp+0x40], xmm5
00007a66921daed3  vmovaps [rsp+0x50], xmm6
00007a66921daed9  vmovaps [rsp+0x60], xmm7
00007a66921daedf  vmovaps [rsp+0x70], xmm8
00007a66921daee5  vmovaps [rsp+0x80], xmm9
00007a66921daeee  vmovaps [rsp+0x90], xmm10
00007a66921daef7  vmovaps [rsp+0xA0], xmm11
00007a66921daf00  vmovaps [rsp+0xB0], xmm12
00007a66921daf09  vmovaps [rsp+0xC0], xmm13
00007a66921daf12  vmovaps [rsp+0xD0], xmm14
00007a66921daf1b  vmovaps [rsp+0xE0], xmm15
00007a66921daf24  sub rsp, 0x30
00007a66921daf28  movaps [rsp], xmm1
00007a66921daf2c  movaps [rsp+0x10], xmm13
00007a66921daf32  movaps [rsp+0x20], xmm8
00007a66921daf38  lea rdi, [rsp]
00007a66921daf3c  mov esi, 0x00
00007a66921daf41  mov rax, 0x635346DC7530
00007a66921daf4b  call rax
00007a66921daf4d  movaps xmm1, [rsp]
00007a66921daf51  add rsp, 0x30
00007a66921daf55  vmovaps xmm0, [rsp]
00007a66921daf5a  vmovaps xmm2, [rsp+0x10]
00007a66921daf60  vmovaps xmm3, [rsp+0x20]
00007a66921daf66  vmovaps xmm4, [rsp+0x30]
00007a66921daf6c  vmovaps xmm5, [rsp+0x40]
00007a66921daf72  vmovaps xmm6, [rsp+0x50]
00007a66921daf78  vmovaps xmm7, [rsp+0x60]
00007a66921daf7e  vmovaps xmm8, [rsp+0x70]
00007a66921daf84  vmovaps xmm9, [rsp+0x80]
00007a66921daf8d  vmovaps xmm10, [rsp+0x90]
00007a66921daf96  vmovaps xmm11, [rsp+0xA0]
00007a66921daf9f  vmovaps xmm12, [rsp+0xB0]
00007a66921dafa8  vmovaps xmm13, [rsp+0xC0]
00007a66921dafb1  vmovaps xmm14, [rsp+0xD0]
00007a66921dafba  vmovaps xmm15, [rsp+0xE0]
00007a66921dafc3  add rsp, 0xF0
00007a66921dafca  pop r11
00007a66921dafcc  pop r10
00007a66921dafce  pop r9
00007a66921dafd0  pop r8
00007a66921dafd2  pop rsi
00007a66921dafd3  pop rdi
00007a66921dafd4  pop rdx
00007a66921dafd5  pop rcx
00007a66921dafd6  pop rax
00007a66921dafd7  add rsp, 0x08
00007a66921dafdb  jmp 0x00007A66921D659A
00007a66921dafe0  call 0x00007A669200C260
00007a66921dafe5  jmp 0x00007A66921D65A8
00007a66921dafea  call 0x00007A66920DE950
00007a66921dafef  jmp 0x00007A66921D65B2
00007a66921daff4  sub rsp, 0x08
00007a66921daff8  push rax
00007a66921daff9  push rcx
00007a66921daffa  push rdx
00007a66921daffb  push rdi
00007a66921daffc  push rsi
00007a66921daffd  push r8
00007a66921dafff  push r9
00007a66921db001  push r10
00007a66921db003  push r11
00007a66921db005  sub rsp, 0xF0
00007a66921db00c  vmovaps [rsp], xmm0
00007a66921db011  vmovaps [rsp+0x10], xmm1
00007a66921db017  vmovaps [rsp+0x20], xmm2
00007a66921db01d  vmovaps [rsp+0x30], xmm3
00007a66921db023  vmovaps [rsp+0x40], xmm4
00007a66921db029  vmovaps [rsp+0x50], xmm5
00007a66921db02f  vmovaps [rsp+0x60], xmm6
00007a66921db035  vmovaps [rsp+0x70], xmm7
00007a66921db03b  vmovaps [rsp+0x80], xmm9
00007a66921db044  vmovaps [rsp+0x90], xmm10
00007a66921db04d  vmovaps [rsp+0xA0], xmm11
00007a66921db056  vmovaps [rsp+0xB0], xmm12
00007a66921db05f  vmovaps [rsp+0xC0], xmm13
00007a66921db068  vmovaps [rsp+0xD0], xmm14
00007a66921db071  vmovaps [rsp+0xE0], xmm15
00007a66921db07a  sub rsp, 0x30
00007a66921db07e  movaps [rsp], xmm8
00007a66921db083  movaps [rsp+0x10], xmm15
00007a66921db089  movaps [rsp+0x20], xmm7
00007a66921db08e  lea rdi, [rsp]
00007a66921db092  mov esi, 0x00
00007a66921db097  mov rax, 0x635346DC7530
00007a66921db0a1  call rax
00007a66921db0a3  movaps xmm8, [rsp]
00007a66921db0a8  add rsp, 0x30
00007a66921db0ac  vmovaps xmm0, [rsp]
00007a66921db0b1  vmovaps xmm1, [rsp+0x10]
00007a66921db0b7  vmovaps xmm2, [rsp+0x20]
00007a66921db0bd  vmovaps xmm3, [rsp+0x30]
00007a66921db0c3  vmovaps xmm4, [rsp+0x40]
00007a66921db0c9  vmovaps xmm5, [rsp+0x50]
00007a66921db0cf  vmovaps xmm6, [rsp+0x60]
00007a66921db0d5  vmovaps xmm7, [rsp+0x70]
00007a66921db0db  vmovaps xmm9, [rsp+0x80]
00007a66921db0e4  vmovaps xmm10, [rsp+0x90]
00007a66921db0ed  vmovaps xmm11, [rsp+0xA0]
00007a66921db0f6  vmovaps xmm12, [rsp+0xB0]
00007a66921db0ff  vmovaps xmm13, [rsp+0xC0]
00007a66921db108  vmovaps xmm14, [rsp+0xD0]
00007a66921db111  vmovaps xmm15, [rsp+0xE0]
00007a66921db11a  add rsp, 0xF0
00007a66921db121  pop r11
00007a66921db123  pop r10
00007a66921db125  pop r9
00007a66921db127  pop r8
00007a66921db129  pop rsi
00007a66921db12a  pop rdi
00007a66921db12b  pop rdx
00007a66921db12c  pop rcx
00007a66921db12d  pop rax
00007a66921db12e  add rsp, 0x08
00007a66921db132  jmp 0x00007A66921D65D4
00007a66921db137  sub rsp, 0x08
00007a66921db13b  push rax
00007a66921db13c  push rcx
00007a66921db13d  push rdx
00007a66921db13e  push rdi
00007a66921db13f  push rsi
00007a66921db140  push r8
00007a66921db142  push r9
00007a66921db144  push r10
00007a66921db146  push r11
00007a66921db148  sub rsp, 0xF0
00007a66921db14f  vmovaps [rsp], xmm0
00007a66921db154  vmovaps [rsp+0x10], xmm1
00007a66921db15a  vmovaps [rsp+0x20], xmm2
00007a66921db160  vmovaps [rsp+0x30], xmm3
00007a66921db166  vmovaps [rsp+0x40], xmm4
00007a66921db16c  vmovaps [rsp+0x50], xmm5
00007a66921db172  vmovaps [rsp+0x60], xmm6
00007a66921db178  vmovaps [rsp+0x70], xmm8
00007a66921db17e  vmovaps [rsp+0x80], xmm9
00007a66921db187  vmovaps [rsp+0x90], xmm10
00007a66921db190  vmovaps [rsp+0xA0], xmm11
00007a66921db199  vmovaps [rsp+0xB0], xmm12
00007a66921db1a2  vmovaps [rsp+0xC0], xmm13
00007a66921db1ab  vmovaps [rsp+0xD0], xmm14
00007a66921db1b4  vmovaps [rsp+0xE0], xmm15
00007a66921db1bd  sub rsp, 0x30
00007a66921db1c1  movaps [rsp], xmm7
00007a66921db1c5  movaps [rsp+0x10], xmm9
00007a66921db1cb  movaps [rsp+0x20], xmm15
00007a66921db1d1  lea rdi, [rsp]
00007a66921db1d5  mov esi, 0x00
00007a66921db1da  mov rax, 0x635346DC7530
00007a66921db1e4  call rax
00007a66921db1e6  movaps xmm7, [rsp]
00007a66921db1ea  add rsp, 0x30
00007a66921db1ee  vmovaps xmm0, [rsp]
00007a66921db1f3  vmovaps xmm1, [rsp+0x10]
00007a66921db1f9  vmovaps xmm2, [rsp+0x20]
00007a66921db1ff  vmovaps xmm3, [rsp+0x30]
00007a66921db205  vmovaps xmm4, [rsp+0x40]
00007a66921db20b  vmovaps xmm5, [rsp+0x50]
00007a66921db211  vmovaps xmm6, [rsp+0x60]
00007a66921db217  vmovaps xmm8, [rsp+0x70]
00007a66921db21d  vmovaps xmm9, [rsp+0x80]
00007a66921db226  vmovaps xmm10, [rsp+0x90]
00007a66921db22f  vmovaps xmm11, [rsp+0xA0]
00007a66921db238  vmovaps xmm12, [rsp+0xB0]
00007a66921db241  vmovaps xmm13, [rsp+0xC0]
00007a66921db24a  vmovaps xmm14, [rsp+0xD0]
00007a66921db253  vmovaps xmm15, [rsp+0xE0]
00007a66921db25c  add rsp, 0xF0
00007a66921db263  pop r11
00007a66921db265  pop r10
00007a66921db267  pop r9
00007a66921db269  pop r8
00007a66921db26b  pop rsi
00007a66921db26c  pop rdi
00007a66921db26d  pop rdx
00007a66921db26e  pop rcx
00007a66921db26f  pop rax
00007a66921db270  add rsp, 0x08
00007a66921db274  jmp 0x00007A66921D6601
00007a66921db279  sub rsp, 0x08
00007a66921db27d  push rax
00007a66921db27e  push rcx
00007a66921db27f  push rdx
00007a66921db280  push rdi
00007a66921db281  push rsi
00007a66921db282  push r8
00007a66921db284  push r9
00007a66921db286  push r10
00007a66921db288  push r11
00007a66921db28a  sub rsp, 0xF0
00007a66921db291  vmovaps [rsp], xmm0
00007a66921db296  vmovaps [rsp+0x10], xmm1
00007a66921db29c  vmovaps [rsp+0x20], xmm2
00007a66921db2a2  vmovaps [rsp+0x30], xmm3
00007a66921db2a8  vmovaps [rsp+0x40], xmm4
00007a66921db2ae  vmovaps [rsp+0x50], xmm5
00007a66921db2b4  vmovaps [rsp+0x60], xmm6
00007a66921db2ba  vmovaps [rsp+0x70], xmm7
00007a66921db2c0  vmovaps [rsp+0x80], xmm8
00007a66921db2c9  vmovaps [rsp+0x90], xmm10
00007a66921db2d2  vmovaps [rsp+0xA0], xmm11
00007a66921db2db  vmovaps [rsp+0xB0], xmm12
00007a66921db2e4  vmovaps [rsp+0xC0], xmm13
00007a66921db2ed  vmovaps [rsp+0xD0], xmm14
00007a66921db2f6  vmovaps [rsp+0xE0], xmm15
00007a66921db2ff  sub rsp, 0x30
00007a66921db303  movaps [rsp], xmm9
00007a66921db308  movaps [rsp+0x10], xmm13
00007a66921db30e  movaps [rsp+0x20], xmm15
00007a66921db314  lea rdi, [rsp]
00007a66921db318  mov esi, 0x00
00007a66921db31d  mov rax, 0x635346DC7530
00007a66921db327  call rax
00007a66921db329  movaps xmm9, [rsp]
00007a66921db32e  add rsp, 0x30
00007a66921db332  vmovaps xmm0, [rsp]
00007a66921db337  vmovaps xmm1, [rsp+0x10]
00007a66921db33d  vmovaps xmm2, [rsp+0x20]
00007a66921db343  vmovaps xmm3, [rsp+0x30]
00007a66921db349  vmovaps xmm4, [rsp+0x40]
00007a66921db34f  vmovaps xmm5, [rsp+0x50]
00007a66921db355  vmovaps xmm6, [rsp+0x60]
00007a66921db35b  vmovaps xmm7, [rsp+0x70]
00007a66921db361  vmovaps xmm8, [rsp+0x80]
00007a66921db36a  vmovaps xmm10, [rsp+0x90]
00007a66921db373  vmovaps xmm11, [rsp+0xA0]
00007a66921db37c  vmovaps xmm12, [rsp+0xB0]
00007a66921db385  vmovaps xmm13, [rsp+0xC0]
00007a66921db38e  vmovaps xmm14, [rsp+0xD0]
00007a66921db397  vmovaps xmm15, [rsp+0xE0]
00007a66921db3a0  add rsp, 0xF0
00007a66921db3a7  pop r11
00007a66921db3a9  pop r10
00007a66921db3ab  pop r9
00007a66921db3ad  pop r8
00007a66921db3af  pop rsi
00007a66921db3b0  pop rdi
00007a66921db3b1  pop rdx
00007a66921db3b2  pop rcx
00007a66921db3b3  pop rax
00007a66921db3b4  add rsp, 0x08
00007a66921db3b8  jmp 0x00007A66921D662F
00007a66921db3bd  sub rsp, 0x08
00007a66921db3c1  push rax
00007a66921db3c2  push rcx
00007a66921db3c3  push rdx
00007a66921db3c4  push rdi
00007a66921db3c5  push rsi
00007a66921db3c6  push r8
00007a66921db3c8  push r9
00007a66921db3ca  push r10
00007a66921db3cc  push r11
00007a66921db3ce  sub rsp, 0xF0
00007a66921db3d5  vmovaps [rsp], xmm0
00007a66921db3da  vmovaps [rsp+0x10], xmm1
00007a66921db3e0  vmovaps [rsp+0x20], xmm2
00007a66921db3e6  vmovaps [rsp+0x30], xmm3
00007a66921db3ec  vmovaps [rsp+0x40], xmm4
00007a66921db3f2  vmovaps [rsp+0x50], xmm5
00007a66921db3f8  vmovaps [rsp+0x60], xmm6
00007a66921db3fe  vmovaps [rsp+0x70], xmm7
00007a66921db404  vmovaps [rsp+0x80], xmm8
00007a66921db40d  vmovaps [rsp+0x90], xmm9
00007a66921db416  vmovaps [rsp+0xA0], xmm10
00007a66921db41f  vmovaps [rsp+0xB0], xmm11
00007a66921db428  vmovaps [rsp+0xC0], xmm12
00007a66921db431  vmovaps [rsp+0xD0], xmm13
00007a66921db43a  vmovaps [rsp+0xE0], xmm14
00007a66921db443  sub rsp, 0x30
00007a66921db447  movaps [rsp], xmm15
00007a66921db44c  movaps [rsp+0x10], xmm11
00007a66921db452  movaps [rsp+0x20], xmm12
00007a66921db458  lea rdi, [rsp]
00007a66921db45c  mov esi, 0x00
00007a66921db461  mov rax, 0x635346DC7530
00007a66921db46b  call rax
00007a66921db46d  movaps xmm15, [rsp]
00007a66921db472  add rsp, 0x30
00007a66921db476  vmovaps xmm0, [rsp]
00007a66921db47b  vmovaps xmm1, [rsp+0x10]
00007a66921db481  vmovaps xmm2, [rsp+0x20]
00007a66921db487  vmovaps xmm3, [rsp+0x30]
00007a66921db48d  vmovaps xmm4, [rsp+0x40]
00007a66921db493  vmovaps xmm5, [rsp+0x50]
00007a66921db499  vmovaps xmm6, [rsp+0x60]
00007a66921db49f  vmovaps xmm7, [rsp+0x70]
00007a66921db4a5  vmovaps xmm8, [rsp+0x80]
00007a66921db4ae  vmovaps xmm9, [rsp+0x90]
00007a66921db4b7  vmovaps xmm10, [rsp+0xA0]
00007a66921db4c0  vmovaps xmm11, [rsp+0xB0]
00007a66921db4c9  vmovaps xmm12, [rsp+0xC0]
00007a66921db4d2  vmovaps xmm13, [rsp+0xD0]
00007a66921db4db  vmovaps xmm14, [rsp+0xE0]
00007a66921db4e4  add rsp, 0xF0
00007a66921db4eb  pop r11
00007a66921db4ed  pop r10
00007a66921db4ef  pop r9
00007a66921db4f1  pop r8
00007a66921db4f3  pop rsi
00007a66921db4f4  pop rdi
00007a66921db4f5  pop rdx
00007a66921db4f6  pop rcx
00007a66921db4f7  pop rax
00007a66921db4f8  add rsp, 0x08
00007a66921db4fc  jmp 0x00007A66921D664A
00007a66921db501  sub rsp, 0x08
00007a66921db505  push rax
00007a66921db506  push rcx
00007a66921db507  push rdx
00007a66921db508  push rdi
00007a66921db509  push rsi
00007a66921db50a  push r8
00007a66921db50c  push r9
00007a66921db50e  push r10
00007a66921db510  push r11
00007a66921db512  sub rsp, 0xF0
00007a66921db519  vmovaps [rsp], xmm0
00007a66921db51e  vmovaps [rsp+0x10], xmm1
00007a66921db524  vmovaps [rsp+0x20], xmm2
00007a66921db52a  vmovaps [rsp+0x30], xmm3
00007a66921db530  vmovaps [rsp+0x40], xmm4
00007a66921db536  vmovaps [rsp+0x50], xmm5
00007a66921db53c  vmovaps [rsp+0x60], xmm6
00007a66921db542  vmovaps [rsp+0x70], xmm7
00007a66921db548  vmovaps [rsp+0x80], xmm8
00007a66921db551  vmovaps [rsp+0x90], xmm9
00007a66921db55a  vmovaps [rsp+0xA0], xmm10
00007a66921db563  vmovaps [rsp+0xB0], xmm11
00007a66921db56c  vmovaps [rsp+0xC0], xmm12
00007a66921db575  vmovaps [rsp+0xD0], xmm14
00007a66921db57e  vmovaps [rsp+0xE0], xmm15
00007a66921db587  sub rsp, 0x30
00007a66921db58b  movaps [rsp], xmm13
00007a66921db590  movaps [rsp+0x10], xmm10
00007a66921db596  movaps [rsp+0x20], xmm14
00007a66921db59c  lea rdi, [rsp]
00007a66921db5a0  mov esi, 0x00
00007a66921db5a5  mov rax, 0x635346DC7530
00007a66921db5af  call rax
00007a66921db5b1  movaps xmm13, [rsp]
00007a66921db5b6  add rsp, 0x30
00007a66921db5ba  vmovaps xmm0, [rsp]
00007a66921db5bf  vmovaps xmm1, [rsp+0x10]
00007a66921db5c5  vmovaps xmm2, [rsp+0x20]
00007a66921db5cb  vmovaps xmm3, [rsp+0x30]
00007a66921db5d1  vmovaps xmm4, [rsp+0x40]
00007a66921db5d7  vmovaps xmm5, [rsp+0x50]
00007a66921db5dd  vmovaps xmm6, [rsp+0x60]
00007a66921db5e3  vmovaps xmm7, [rsp+0x70]
00007a66921db5e9  vmovaps xmm8, [rsp+0x80]
00007a66921db5f2  vmovaps xmm9, [rsp+0x90]
00007a66921db5fb  vmovaps xmm10, [rsp+0xA0]
00007a66921db604  vmovaps xmm11, [rsp+0xB0]
00007a66921db60d  vmovaps xmm12, [rsp+0xC0]
00007a66921db616  vmovaps xmm14, [rsp+0xD0]
00007a66921db61f  vmovaps xmm15, [rsp+0xE0]
00007a66921db628  add rsp, 0xF0
00007a66921db62f  pop r11
00007a66921db631  pop r10
00007a66921db633  pop r9
00007a66921db635  pop r8
00007a66921db637  pop rsi
00007a66921db638  pop rdi
00007a66921db639  pop rdx
00007a66921db63a  pop rcx
00007a66921db63b  pop rax
00007a66921db63c  add rsp, 0x08
00007a66921db640  jmp 0x00007A66921D666D
00007a66921db645  sub rsp, 0x08
00007a66921db649  push rax
00007a66921db64a  push rcx
00007a66921db64b  push rdx
00007a66921db64c  push rdi
00007a66921db64d  push rsi
00007a66921db64e  push r8
00007a66921db650  push r9
00007a66921db652  push r10
00007a66921db654  push r11
00007a66921db656  sub rsp, 0xF0
00007a66921db65d  vmovaps [rsp], xmm0
00007a66921db662  vmovaps [rsp+0x10], xmm1
00007a66921db668  vmovaps [rsp+0x20], xmm2
00007a66921db66e  vmovaps [rsp+0x30], xmm3
00007a66921db674  vmovaps [rsp+0x40], xmm4
00007a66921db67a  vmovaps [rsp+0x50], xmm5
00007a66921db680  vmovaps [rsp+0x60], xmm6
00007a66921db686  vmovaps [rsp+0x70], xmm7
00007a66921db68c  vmovaps [rsp+0x80], xmm8
00007a66921db695  vmovaps [rsp+0x90], xmm9
00007a66921db69e  vmovaps [rsp+0xA0], xmm10
00007a66921db6a7  vmovaps [rsp+0xB0], xmm11
00007a66921db6b0  vmovaps [rsp+0xC0], xmm12
00007a66921db6b9  vmovaps [rsp+0xD0], xmm13
00007a66921db6c2  vmovaps [rsp+0xE0], xmm15
00007a66921db6cb  sub rsp, 0x30
00007a66921db6cf  movaps [rsp], xmm14
00007a66921db6d4  movaps [rsp+0x10], xmm1
00007a66921db6d9  movaps [rsp+0x20], xmm7
00007a66921db6de  lea rdi, [rsp]
00007a66921db6e2  mov esi, 0x00
00007a66921db6e7  mov rax, 0x635346DC7530
00007a66921db6f1  call rax
00007a66921db6f3  movaps xmm14, [rsp]
00007a66921db6f8  add rsp, 0x30
00007a66921db6fc  vmovaps xmm0, [rsp]
00007a66921db701  vmovaps xmm1, [rsp+0x10]
00007a66921db707  vmovaps xmm2, [rsp+0x20]
00007a66921db70d  vmovaps xmm3, [rsp+0x30]
00007a66921db713  vmovaps xmm4, [rsp+0x40]
00007a66921db719  vmovaps xmm5, [rsp+0x50]
00007a66921db71f  vmovaps xmm6, [rsp+0x60]
00007a66921db725  vmovaps xmm7, [rsp+0x70]
00007a66921db72b  vmovaps xmm8, [rsp+0x80]
00007a66921db734  vmovaps xmm9, [rsp+0x90]
00007a66921db73d  vmovaps xmm10, [rsp+0xA0]
00007a66921db746  vmovaps xmm11, [rsp+0xB0]
00007a66921db74f  vmovaps xmm12, [rsp+0xC0]
00007a66921db758  vmovaps xmm13, [rsp+0xD0]
00007a66921db761  vmovaps xmm15, [rsp+0xE0]
00007a66921db76a  add rsp, 0xF0
00007a66921db771  pop r11
00007a66921db773  pop r10
00007a66921db775  pop r9
00007a66921db777  pop r8
00007a66921db779  pop rsi
00007a66921db77a  pop rdi
00007a66921db77b  pop rdx
00007a66921db77c  pop rcx
00007a66921db77d  pop rax
00007a66921db77e  add rsp, 0x08
00007a66921db782  jmp 0x00007A66921D6690
00007a66921db787  sub rsp, 0x08
00007a66921db78b  push rax
00007a66921db78c  push rcx
00007a66921db78d  push rdx
00007a66921db78e  push rdi
00007a66921db78f  push rsi
00007a66921db790  push r8
00007a66921db792  push r9
00007a66921db794  push r10
00007a66921db796  push r11
00007a66921db798  sub rsp, 0xF0
00007a66921db79f  vmovaps [rsp], xmm0
00007a66921db7a4  vmovaps [rsp+0x10], xmm2
00007a66921db7aa  vmovaps [rsp+0x20], xmm3
00007a66921db7b0  vmovaps [rsp+0x30], xmm4
00007a66921db7b6  vmovaps [rsp+0x40], xmm5
00007a66921db7bc  vmovaps [rsp+0x50], xmm6
00007a66921db7c2  vmovaps [rsp+0x60], xmm7
00007a66921db7c8  vmovaps [rsp+0x70], xmm8
00007a66921db7ce  vmovaps [rsp+0x80], xmm9
00007a66921db7d7  vmovaps [rsp+0x90], xmm10
00007a66921db7e0  vmovaps [rsp+0xA0], xmm11
00007a66921db7e9  vmovaps [rsp+0xB0], xmm12
00007a66921db7f2  vmovaps [rsp+0xC0], xmm13
00007a66921db7fb  vmovaps [rsp+0xD0], xmm14
00007a66921db804  vmovaps [rsp+0xE0], xmm15
00007a66921db80d  sub rsp, 0x30
00007a66921db811  movaps [rsp], xmm1
00007a66921db815  movaps [rsp+0x10], xmm8
00007a66921db81b  movaps [rsp+0x20], xmm9
00007a66921db821  lea rdi, [rsp]
00007a66921db825  mov esi, 0x00
00007a66921db82a  mov rax, 0x635346DC7530
00007a66921db834  call rax
00007a66921db836  movaps xmm1, [rsp]
00007a66921db83a  add rsp, 0x30
00007a66921db83e  vmovaps xmm0, [rsp]
00007a66921db843  vmovaps xmm2, [rsp+0x10]
00007a66921db849  vmovaps xmm3, [rsp+0x20]
00007a66921db84f  vmovaps xmm4, [rsp+0x30]
00007a66921db855  vmovaps xmm5, [rsp+0x40]
00007a66921db85b  vmovaps xmm6, [rsp+0x50]
00007a66921db861  vmovaps xmm7, [rsp+0x60]
00007a66921db867  vmovaps xmm8, [rsp+0x70]
00007a66921db86d  vmovaps xmm9, [rsp+0x80]
00007a66921db876  vmovaps xmm10, [rsp+0x90]
00007a66921db87f  vmovaps xmm11, [rsp+0xA0]
00007a66921db888  vmovaps xmm12, [rsp+0xB0]
00007a66921db891  vmovaps xmm13, [rsp+0xC0]
00007a66921db89a  vmovaps xmm14, [rsp+0xD0]
00007a66921db8a3  vmovaps xmm15, [rsp+0xE0]
00007a66921db8ac  add rsp, 0xF0
00007a66921db8b3  pop r11
00007a66921db8b5  pop r10
00007a66921db8b7  pop r9
00007a66921db8b9  pop r8
00007a66921db8bb  pop rsi
00007a66921db8bc  pop rdi
00007a66921db8bd  pop rdx
00007a66921db8be  pop rcx
00007a66921db8bf  pop rax
00007a66921db8c0  add rsp, 0x08
00007a66921db8c4  jmp 0x00007A66921D66B2
00007a66921db8c9  call 0x00007A66920B3E40
00007a66921db8ce  jmp 0x00007A66921D66C0
00007a66921db8d3  call 0x00007A669200C380
00007a66921db8d8  jmp 0x00007A66921D66CA
00007a66921db8dd  call 0x00007A669200D600
00007a66921db8e2  jmp 0x00007A66921D66D4
00007a66921db8e7  call 0x00007A6691FFF540
00007a66921db8ec  jmp 0x00007A66921D66DE
00007a66921db8f1  int3
00007a66921db8f2  nop [rax+rax*1], ax
00007a66921db8fb  nop [rax+rax*1], eax
00007a66921db900  mov eax, [r15+0x48]
00007a66921db904  lea r14d, [eax+0x01]
00007a66921db909  mov [rsp+0x10], r14d
00007a66921db90e  mov r14d, r14d
00007a66921db911  mov [r15+0x48], r14
00007a66921db915  xor eax, eax
00007a66921db917  mov r14d, [rsp+0x10]
00007a66921db91c  cmp r14d, 0x1F4
00007a66921db923  cmc
00007a66921db924  lahf
00007a66921db925  seto al
00007a66921db928  mov [r15+0x108], eax
00007a66921db92f  mov eax, [r15+0x108]
00007a66921db936  sahf
00007a66921db937  jnz 0x00007A66921DB969
00007a66921db939  cmp dword ptr [r15+0x318], 0x00
00007a66921db941  jz 0x00007A66921E1AB0
00007a66921db947  nop [rax+rax*1], ax
00007a66921db950  nop [rax+rax*1], eax
00007a66921db958  mov eax, 0x410450
00007a66921db95d  mov [r15+0x100], rax
00007a66921db964  jmp 0x00007A6691FFE110
00007a66921db969  cmp dword ptr [r15+0x318], 0x00
00007a66921db971  jz 0x00007A66921DB9A0
00007a66921db977  nop [rax+rax*1], ax
00007a66921db980  nop [rax+rax*1], eax
00007a66921db988  mov eax, 0x410274
00007a66921db98d  mov [r15+0x100], rax
00007a66921db994  jmp 0x00007A6691FFE110
00007a66921db999  int3
00007a66921db99a  int3
00007a66921db99b  nop [rax+rax*1], eax
00007a66921db9a0  mov rax, [r15+0x40]
00007a66921db9a4  movaps xmm1, [r15+0x1D0]
00007a66921db9ac  vmovaps [rsp+0x10], xmm1
00007a66921db9b2  vmovaps xmm15, [rsp+0x10]
00007a66921db9b8  por xmm1, xmm15
00007a66921db9bd  movaps xmm14, [r15+0x1A0]
00007a66921db9c5  vmovaps [rsp+0x10], xmm14
00007a66921db9cb  vmovaps xmm13, [rsp+0x10]
00007a66921db9d1  por xmm14, xmm13
00007a66921db9d6  lea r14, [rax+0x30]
00007a66921db9da  mov r12, [r13+r14*1]
00007a66921db9df  lea r14, [rax+0x38]
00007a66921db9e3  mov r11, [r13+r14*1]
00007a66921db9e8  movq xmm13, r12
00007a66921db9ed  movq xmm12, r11
00007a66921db9f2  movq xmm13, xmm13
00007a66921db9f7  vmovaps [rsp+0x10], xmm13
00007a66921db9fd  movq xmm13, xmm13
00007a66921dba02  movaps [r15+0x130], xmm13
00007a66921dba0a  movq xmm12, xmm12
00007a66921dba0f  vmovaps [rsp+0x20], xmm12
00007a66921dba15  movq xmm12, xmm12
00007a66921dba1a  movaps [r15+0x280], xmm12
00007a66921dba22  movaps xmm13, [r15+0x270]
00007a66921dba2a  vmovaps [rsp+0x30], xmm13
00007a66921dba30  vmovaps xmm12, [rsp+0x30]
00007a66921dba36  por xmm13, xmm12
00007a66921dba3b  lea r14, [rax+0x20]
00007a66921dba3f  mov r12, [r13+r14*1]
00007a66921dba44  lea r14, [rax+0x28]
00007a66921dba48  mov r11, [r13+r14*1]
00007a66921dba4d  movq xmm12, r12
00007a66921dba52  movq xmm11, r11
00007a66921dba57  movq xmm12, xmm12
00007a66921dba5c  vmovaps [rsp+0x30], xmm12
00007a66921dba62  movq xmm12, xmm12
00007a66921dba67  movaps [r15+0x150], xmm12
00007a66921dba6f  movq xmm11, xmm11
00007a66921dba74  vmovaps [rsp+0x40], xmm11
00007a66921dba7a  movq xmm11, xmm11
00007a66921dba7f  movaps [r15+0x140], xmm11
00007a66921dba87  lea r14, [rax+0x10]
00007a66921dba8b  mov r12, [r13+r14*1]
00007a66921dba90  lea r14, [rax+0x18]
00007a66921dba94  mov r11, [r13+r14*1]
00007a66921dba99  movq xmm12, r12
00007a66921dba9e  movq xmm11, r11
00007a66921dbaa3  movq xmm12, xmm12
00007a66921dbaa8  vmovaps [rsp+0x50], xmm12
00007a66921dbaae  movq xmm12, xmm12
00007a66921dbab3  movaps [r15+0x170], xmm12
00007a66921dbabb  movq xmm11, xmm11
00007a66921dbac0  vmovaps [rsp+0x60], xmm11
00007a66921dbac6  movq xmm11, xmm11
00007a66921dbacb  movaps [r15+0x160], xmm11
00007a66921dbad3  mov r14, [r13+rax*1]
00007a66921dbad8  vmovq xmm12, r14
00007a66921dbadd  vpbroadcastq xmm12, xmm12
00007a66921dbae2  lea r14, [rax+0x08]
00007a66921dbae6  mov rax, [r13+r14*1]
00007a66921dbaeb  movq xmm11, rax
00007a66921dbaf0  movaps [r15+0x230], xmm11
00007a66921dbaf8  mov rax, [r15+0xF8]
00007a66921dbaff  lea r14, [rax+0x50]
00007a66921dbb03  movups xmm11, [r13+r14*1]
00007a66921dbb09  lea r14, [rax+0x60]
00007a66921dbb0d  movups xmm10, [r13+r14*1]
00007a66921dbb13  lea r14, [rax+0x30]
00007a66921dbb17  movups xmm9, [r13+r14*1]
00007a66921dbb1d  mov r14, [r15+0x50]
00007a66921dbb21  mov [r15+0x60], r14
00007a66921dbb25  mov qword ptr [r15+0x58], 0x40
00007a66921dbb2d  movaps xmm8, xmm12
00007a66921dbb31  mulpd xmm8, xmm15
00007a66921dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007a66921dbb3c  ptest xmm7, xmm7
00007a66921dbb41  jnz 0x00007A66921DC96A
00007a66921dbb47  movq xmm15, qword ptr [r15+0x230]
00007a66921dbb50  vmovaps [rsp+0x70], xmm15
00007a66921dbb56  vpermilpd xmm15, xmm15, 0x00
00007a66921dbb5c  movaps xmm7, xmm9
00007a66921dbb60  mulpd xmm7, xmm15
00007a66921dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007a66921dbb6a  ptest xmm6, xmm6
00007a66921dbb6f  jnz 0x00007A66921DCAAE
00007a66921dbb75  vxorps xmm15, xmm15, xmm15
00007a66921dbb7a  vpbroadcastq xmm15, xmm15
00007a66921dbb7f  movaps xmm9, xmm12
00007a66921dbb83  mulpd xmm9, xmm10
00007a66921dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007a66921dbb8e  ptest xmm6, xmm6
00007a66921dbb93  jnz 0x00007A66921DCBF0
00007a66921dbb99  movaps xmm10, xmm12
00007a66921dbb9d  mulpd xmm10, xmm11
00007a66921dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007a66921dbba8  ptest xmm6, xmm6
00007a66921dbbad  jnz 0x00007A66921DCD34
00007a66921dbbb3  movaps xmm11, [r15+0x1F0]
00007a66921dbbbb  movaps xmm6, xmm12
00007a66921dbbbf  mulpd xmm6, xmm11
00007a66921dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007a66921dbbc9  ptest xmm5, xmm5
00007a66921dbbce  jnz 0x00007A66921DCE78
00007a66921dbbd4  movaps xmm12, [r15+0x2A0]
00007a66921dbbdc  vmovaps [rsp+0x80], xmm12
00007a66921dbbe5  vmovaps xmm11, [rsp+0x80]
00007a66921dbbee  por xmm12, xmm11
00007a66921dbbf3  movaps xmm11, [r15+0x250]
00007a66921dbbfb  vmovaps [rsp+0x80], xmm11
00007a66921dbc04  vmovaps xmm5, [rsp+0x80]
00007a66921dbc0d  por xmm11, xmm5
00007a66921dbc12  vmovaps xmm4, [rsp+0x70]
00007a66921dbc18  vpermilpd xmm4, xmm4, 0x00
00007a66921dbc1e  movaps xmm3, xmm5
00007a66921dbc21  mulpd xmm3, xmm4
00007a66921dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007a66921dbc2a  ptest xmm2, xmm2
00007a66921dbc2f  jnz 0x00007A66921DCFBA
00007a66921dbc35  mov [rsp+0x80], rax
00007a66921dbc3d  xor eax, eax
00007a66921dbc3f  mov r12d, 0x40
00007a66921dbc45  mov r11d, 0x200
00007a66921dbc4b  cmp r12, r11
00007a66921dbc4e  cmc
00007a66921dbc4f  lahf
00007a66921dbc50  seto al
00007a66921dbc53  mov [r15+0x108], eax
00007a66921dbc5a  movaps xmm5, xmm8
00007a66921dbc5e  addpd xmm5, xmm15
00007a66921dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007a66921dbc68  ptest xmm4, xmm4
00007a66921dbc6d  jnz 0x00007A66921DD0FA
00007a66921dbc73  movaps xmm8, [r15+0x1B0]
00007a66921dbc7b  movaps xmm4, xmm9
00007a66921dbc7f  addpd xmm4, xmm8
00007a66921dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007a66921dbc89  ptest xmm2, xmm2
00007a66921dbc8e  jnz 0x00007A66921DD23C
00007a66921dbc94  movaps xmm9, xmm10
00007a66921dbc98  addpd xmm9, xmm8
00007a66921dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007a66921dbca3  ptest xmm2, xmm2
00007a66921dbca8  jnz 0x00007A66921DD37E
00007a66921dbcae  movaps xmm10, [r15+0x2F0]
00007a66921dbcb6  vmovaps [rsp+0x90], xmm10
00007a66921dbcbf  vmovaps xmm8, [rsp+0x90]
00007a66921dbcc8  por xmm10, xmm8
00007a66921dbccd  movaps xmm8, [r15+0x2E0]
00007a66921dbcd5  vmovaps [rsp+0x90], xmm8
00007a66921dbcde  vmovaps xmm2, [rsp+0x90]
00007a66921dbce7  por xmm8, xmm2
00007a66921dbcec  movaps xmm2, [r15+0x2D0]
00007a66921dbcf4  vmovaps [rsp+0x90], xmm2
00007a66921dbcfd  vmovaps [rsp+0xA0], xmm1
00007a66921dbd06  vmovaps xmm1, [rsp+0x90]
00007a66921dbd0f  por xmm2, xmm1
00007a66921dbd13  movaps xmm1, [r15+0x200]
00007a66921dbd1b  vmovaps [rsp+0x90], xmm1
00007a66921dbd24  vmovaps [rsp+0xB0], xmm15
00007a66921dbd2d  vmovaps xmm15, [rsp+0x90]
00007a66921dbd36  por xmm1, xmm15
00007a66921dbd3b  movaps xmm15, [r15+0x1C0]
00007a66921dbd43  vmovaps [rsp+0x90], xmm15
00007a66921dbd4c  vmovaps [rsp+0xC0], xmm1
00007a66921dbd55  vmovaps xmm1, [rsp+0x90]
00007a66921dbd5e  por xmm15, xmm1
00007a66921dbd63  movaps xmm1, [r15+0x190]
00007a66921dbd6b  vmovaps [rsp+0x90], xmm1
00007a66921dbd74  vmovaps [rsp+0xD0], xmm15
00007a66921dbd7d  vmovaps xmm15, [rsp+0x90]
00007a66921dbd86  por xmm1, xmm15
00007a66921dbd8b  movaps xmm15, [r15+0x300]
00007a66921dbd93  vmovaps [rsp+0x90], xmm15
00007a66921dbd9c  vmovaps [rsp+0xE0], xmm1
00007a66921dbda5  vmovaps xmm1, [rsp+0x90]
00007a66921dbdae  por xmm15, xmm1
00007a66921dbdb3  mov rax, [rsp+0x80]
00007a66921dbdbb  lea r12, [rax+0xA0]
00007a66921dbdc2  movups xmm1, [r13+r12*1]
00007a66921dbdc8  lea r12, [rax+0xB0]
00007a66921dbdcf  vmovaps [rsp+0x80], xmm1
00007a66921dbdd8  movups xmm1, [r13+r12*1]
00007a66921dbdde  vmovaps [rsp+0x90], xmm1
00007a66921dbde7  vmovaps [rsp+0xF0], xmm15
00007a66921dbdf0  vmovaps xmm15, [rsp+0xB0]
00007a66921dbdf9  vmovaps [rsp+0xB0], xmm14
00007a66921dbe02  movaps xmm1, xmm6
00007a66921dbe05  addpd xmm1, xmm15
00007a66921dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007a66921dbe0f  ptest xmm14, xmm14
00007a66921dbe15  jnz 0x00007A66921DD4D6
00007a66921dbe1b  lea r12, [rax+0xF0]
00007a66921dbe22  movups xmm15, [r13+r12*1]
00007a66921dbe28  movaps xmm14, xmm4
00007a66921dbe2c  addpd xmm14, xmm3
00007a66921dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007a66921dbe37  ptest xmm6, xmm6
00007a66921dbe3c  jnz 0x00007A66921DD621
00007a66921dbe42  movaps xmm6, xmm9
00007a66921dbe46  addpd xmm6, xmm7
00007a66921dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007a66921dbe4f  ptest xmm4, xmm4
00007a66921dbe54  jnz 0x00007A66921DD763
00007a66921dbe5a  vmovaps xmm9, [rsp+0x70]
00007a66921dbe60  vpermilpd xmm9, xmm9, 0x00
00007a66921dbe66  vmovaps xmm4, [rsp+0x90]
00007a66921dbe6f  movaps xmm7, xmm4
00007a66921dbe72  mulpd xmm7, xmm9
00007a66921dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007a66921dbe7c  ptest xmm3, xmm3
00007a66921dbe81  jnz 0x00007A66921DD8A4
00007a66921dbe87  vmovaps xmm9, [rsp+0x50]
00007a66921dbe8d  vpermilpd xmm9, xmm9, 0x00
00007a66921dbe93  movaps xmm4, xmm15
00007a66921dbe97  mulpd xmm4, xmm9
00007a66921dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007a66921dbea1  ptest xmm3, xmm3
00007a66921dbea6  jnz 0x00007A66921DD9E5
00007a66921dbeac  lea r12, [rax+0xE0]
00007a66921dbeb3  movups xmm15, [r13+r12*1]
00007a66921dbeb9  vmovaps xmm9, [rsp+0x70]
00007a66921dbebf  vpermilpd xmm9, xmm9, 0x00
00007a66921dbec5  vmovaps [rsp+0x70], xmm1
00007a66921dbecb  vmovaps xmm1, [rsp+0x80]
00007a66921dbed4  vmovaps [rsp+0x80], xmm15
00007a66921dbedd  movaps xmm3, xmm1
00007a66921dbee0  mulpd xmm3, xmm9
00007a66921dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007a66921dbeea  ptest xmm15, xmm15
00007a66921dbef0  jnz 0x00007A66921DDB31
00007a66921dbef6  vmovaps xmm1, [rsp+0xF0]
00007a66921dbeff  vmovaps xmm15, [rsp+0xF0]
00007a66921dbf08  por xmm1, xmm15
00007a66921dbf0d  movaps [r15+0x300], xmm1
00007a66921dbf15  vmovaps xmm15, [rsp+0xE0]
00007a66921dbf1e  vmovaps xmm9, [rsp+0xE0]
00007a66921dbf27  por xmm15, xmm9
00007a66921dbf2c  movaps [r15+0x190], xmm15
00007a66921dbf34  vmovaps xmm9, [rsp+0x50]
00007a66921dbf3a  vpermilpd xmm9, xmm9, 0x00
00007a66921dbf40  vmovaps [rsp+0x90], xmm1
00007a66921dbf49  vmovaps [rsp+0xE0], xmm15
00007a66921dbf52  vmovaps xmm15, [rsp+0x80]
00007a66921dbf5b  vmovaps [rsp+0x80], xmm14
00007a66921dbf64  movaps xmm1, xmm15
00007a66921dbf68  mulpd xmm1, xmm9
00007a66921dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007a66921dbf72  ptest xmm14, xmm14
00007a66921dbf78  jnz 0x00007A66921DDC72
00007a66921dbf7e  lea r12, [rax+0x90]
00007a66921dbf85  movups xmm15, [r13+r12*1]
00007a66921dbf8b  vmovaps xmm14, [rsp+0xD0]
00007a66921dbf94  vmovaps xmm9, [rsp+0xD0]
00007a66921dbf9d  por xmm14, xmm9
00007a66921dbfa2  movaps [r15+0x1C0], xmm14
00007a66921dbfaa  vmovaps xmm9, [rsp+0xC0]
00007a66921dbfb3  vmovaps [rsp+0xD0], xmm1
00007a66921dbfbc  vmovaps xmm1, [rsp+0xC0]
00007a66921dbfc5  por xmm9, xmm1
00007a66921dbfca  movaps [r15+0x200], xmm9
00007a66921dbfd2  vmovaps [rsp+0xC0], xmm2
00007a66921dbfdb  vmovaps xmm1, [rsp+0xC0]
00007a66921dbfe4  por xmm2, xmm1
00007a66921dbfe8  movaps [r15+0x2D0], xmm2
00007a66921dbff0  vmovaps [rsp+0xC0], xmm8
00007a66921dbff9  vmovaps xmm1, [rsp+0xC0]
00007a66921dc002  por xmm8, xmm1
00007a66921dc007  movaps [r15+0x2E0], xmm8
00007a66921dc00f  vmovaps [rsp+0xC0], xmm15
00007a66921dc018  movaps xmm1, xmm5
00007a66921dc01b  addpd xmm1, xmm7
00007a66921dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007a66921dc024  ptest xmm15, xmm15
00007a66921dc02a  jnz 0x00007A66921DDDBE
00007a66921dc030  vmovaps xmm15, [rsp+0x50]
00007a66921dc036  vpermilpd xmm15, xmm15, 0x00
00007a66921dc03c  vmovaps xmm5, [rsp+0xC0]
00007a66921dc045  vmovaps [rsp+0xC0], xmm1
00007a66921dc04e  movaps xmm7, xmm5
00007a66921dc051  mulpd xmm7, xmm15
00007a66921dc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007a66921dc05b  ptest xmm1, xmm1
00007a66921dc060  jnz 0x00007A66921DDEFE
00007a66921dc066  lea r12, [rax+0x80]
00007a66921dc06d  movups xmm1, [r13+r12*1]
00007a66921dc073  vmovaps xmm5, [rsp+0x70]
00007a66921dc079  vmovaps [rsp+0x70], xmm1
00007a66921dc07f  movaps xmm15, xmm5
00007a66921dc083  addpd xmm15, xmm3
00007a66921dc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007a66921dc08e  ptest xmm1, xmm1
00007a66921dc093  jnz 0x00007A66921DE049
00007a66921dc099  vmovaps xmm5, [rsp+0x80]
00007a66921dc0a2  movaps xmm1, xmm5
00007a66921dc0a5  addpd xmm1, xmm4
00007a66921dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007a66921dc0ae  ptest xmm3, xmm3
00007a66921dc0b3  jnz 0x00007A66921DE18B
00007a66921dc0b9  vmovaps [rsp+0x80], xmm10
00007a66921dc0c2  vmovaps xmm5, [rsp+0x80]
00007a66921dc0cb  por xmm10, xmm5
00007a66921dc0d0  movaps [r15+0x2F0], xmm10
00007a66921dc0d8  vmovaps xmm5, [rsp+0x50]
00007a66921dc0de  vpermilpd xmm5, xmm5, 0x00
00007a66921dc0e4  vmovaps xmm3, [rsp+0x70]
00007a66921dc0ea  vmovaps [rsp+0x50], xmm1
00007a66921dc0f0  movaps xmm4, xmm3
00007a66921dc0f3  mulpd xmm4, xmm5
00007a66921dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007a66921dc0fc  ptest xmm1, xmm1
00007a66921dc101  jnz 0x00007A66921DE2CB
00007a66921dc107  lea r12, [rax+0xD0]
00007a66921dc10e  movups xmm1, [r13+r12*1]
00007a66921dc114  vmovaps xmm3, [rsp+0xD0]
00007a66921dc11d  vmovaps [rsp+0x70], xmm1
00007a66921dc123  movaps xmm5, xmm6
00007a66921dc126  addpd xmm5, xmm3
00007a66921dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007a66921dc12f  ptest xmm1, xmm1
00007a66921dc134  jnz 0x00007A66921DE415
00007a66921dc13a  vmovaps xmm1, [rsp+0x60]
00007a66921dc140  vpermilpd xmm1, xmm1, 0x00
00007a66921dc146  movaps xmm6, xmm9
00007a66921dc14a  mulpd xmm6, xmm1
00007a66921dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007a66921dc153  ptest xmm3, xmm3
00007a66921dc158  jnz 0x00007A66921DE555
00007a66921dc15e  movaps [r15+0x260], xmm6
00007a66921dc166  vxorps xmm1, xmm1, xmm1
00007a66921dc16a  vpbroadcastq xmm1, xmm1
00007a66921dc16f  movaps [r15+0x1B0], xmm1
00007a66921dc177  vmovaps xmm1, [rsp+0x60]
00007a66921dc17d  vpermilpd xmm1, xmm1, 0x00
00007a66921dc183  vmovaps xmm3, [rsp+0x70]
00007a66921dc189  vmovaps [rsp+0x70], xmm15
00007a66921dc18f  movaps xmm9, xmm3
00007a66921dc193  mulpd xmm9, xmm1
00007a66921dc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007a66921dc19e  ptest xmm15, xmm15
00007a66921dc1a4  jnz 0x00007A66921DE696
00007a66921dc1aa  lea r12, [rax+0xC0]
00007a66921dc1b1  movups xmm1, [r13+r12*1]
00007a66921dc1b7  vmovaps xmm3, [rsp+0xC0]
00007a66921dc1c0  vmovaps [rsp+0x80], xmm1
00007a66921dc1c9  movaps xmm15, xmm3
00007a66921dc1cd  addpd xmm15, xmm7
00007a66921dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007a66921dc1d8  ptest xmm1, xmm1
00007a66921dc1dd  jnz 0x00007A66921DE7E2
00007a66921dc1e3  vmovaps [rsp+0xC0], xmm13
00007a66921dc1ec  vmovaps xmm1, [rsp+0xC0]
00007a66921dc1f5  por xmm13, xmm1
00007a66921dc1fa  movaps [r15+0x270], xmm13
00007a66921dc202  vmovaps xmm1, [rsp+0xB0]
00007a66921dc20b  vmovaps xmm7, [rsp+0xB0]
00007a66921dc214  por xmm1, xmm7
00007a66921dc218  movaps [r15+0x1A0], xmm1
00007a66921dc220  vmovaps xmm1, [rsp+0x60]
00007a66921dc226  vpermilpd xmm1, xmm1, 0x00
00007a66921dc22c  vmovaps [rsp+0xB0], xmm1
00007a66921dc235  vmovaps xmm1, [rsp+0x80]
00007a66921dc23e  vmovaps [rsp+0x80], xmm15
00007a66921dc247  vmovaps xmm15, [rsp+0xB0]
00007a66921dc250  vmovaps [rsp+0xB0], xmm14
00007a66921dc259  movaps xmm3, xmm1
00007a66921dc25c  mulpd xmm3, xmm15
00007a66921dc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007a66921dc266  ptest xmm14, xmm14
00007a66921dc26c  jnz 0x00007A66921DE924
00007a66921dc272  lea r12, [rax+0x20]
00007a66921dc276  movups xmm1, [r13+r12*1]
00007a66921dc27c  movaps [r15+0x110], xmm1
00007a66921dc284  vmovaps xmm14, [rsp+0x70]
00007a66921dc28a  vmovaps [rsp+0x70], xmm1
00007a66921dc290  movaps xmm15, xmm14
00007a66921dc294  addpd xmm15, xmm4
00007a66921dc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007a66921dc29f  ptest xmm1, xmm1
00007a66921dc2a4  jnz 0x00007A66921DEA6F
00007a66921dc2aa  vmovaps xmm1, [rsp+0x60]
00007a66921dc2b0  vpermilpd xmm1, xmm1, 0x00
00007a66921dc2b6  movaps xmm14, xmm2
00007a66921dc2ba  mulpd xmm14, xmm1
00007a66921dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007a66921dc2c5  ptest xmm4, xmm4
00007a66921dc2ca  jnz 0x00007A66921DEBB2
00007a66921dc2d0  vmovaps xmm4, [rsp+0x50]
00007a66921dc2d6  movaps xmm1, xmm4
00007a66921dc2d9  addpd xmm1, xmm9
00007a66921dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007a66921dc2e3  ptest xmm2, xmm2
00007a66921dc2e8  jnz 0x00007A66921DECF4
00007a66921dc2ee  vmovaps xmm9, [rsp+0x30]
00007a66921dc2f4  vpermilpd xmm9, xmm9, 0x00
00007a66921dc2fa  vmovaps xmm2, [rsp+0x70]
00007a66921dc300  vmovaps [rsp+0x50], xmm1
00007a66921dc306  movaps xmm4, xmm2
00007a66921dc309  mulpd xmm4, xmm9
00007a66921dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007a66921dc313  ptest xmm1, xmm1
00007a66921dc318  jnz 0x00007A66921DEE35
00007a66921dc31e  vmovaps xmm1, [rsp+0x30]
00007a66921dc324  vpermilpd xmm1, xmm1, 0x00
00007a66921dc32a  vmovaps xmm2, [rsp+0x90]
00007a66921dc333  vmovaps [rsp+0x60], xmm15
00007a66921dc339  movaps xmm9, xmm2
00007a66921dc33d  mulpd xmm9, xmm1
00007a66921dc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007a66921dc348  ptest xmm15, xmm15
00007a66921dc34e  jnz 0x00007A66921DEF76
00007a66921dc354  vmovaps xmm15, [rsp+0x80]
00007a66921dc35d  movaps xmm1, xmm15
00007a66921dc361  addpd xmm1, xmm6
00007a66921dc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007a66921dc36a  ptest xmm2, xmm2
00007a66921dc36f  jnz 0x00007A66921DF0B8
00007a66921dc375  movaps xmm15, xmm5
00007a66921dc379  addpd xmm15, xmm3
00007a66921dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007a66921dc384  ptest xmm6, xmm6
00007a66921dc389  jnz 0x00007A66921DF1F9
00007a66921dc38f  vmovaps xmm6, [rsp+0x30]
00007a66921dc395  vpermilpd xmm6, xmm6, 0x00
00007a66921dc39b  movaps xmm5, xmm8
00007a66921dc39f  mulpd xmm5, xmm6
00007a66921dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007a66921dc3a8  ptest xmm3, xmm3
00007a66921dc3ad  jnz 0x00007A66921DF33B
00007a66921dc3b3  vmovaps xmm8, [rsp+0x30]
00007a66921dc3b9  vpermilpd xmm8, xmm8, 0x00
00007a66921dc3bf  movaps xmm6, xmm10
00007a66921dc3c3  mulpd xmm6, xmm8
00007a66921dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007a66921dc3cd  ptest xmm3, xmm3
00007a66921dc3d2  jnz 0x00007A66921DF47C
00007a66921dc3d8  vmovaps xmm8, [rsp+0x60]
00007a66921dc3de  movaps xmm10, xmm8
00007a66921dc3e2  addpd xmm10, xmm14
00007a66921dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007a66921dc3ed  ptest xmm3, xmm3
00007a66921dc3f2  jnz 0x00007A66921DF5BE
00007a66921dc3f8  vmovaps xmm8, [rsp+0x50]
00007a66921dc3fe  movaps xmm14, xmm8
00007a66921dc402  addpd xmm14, xmm4
00007a66921dc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007a66921dc40d  ptest xmm3, xmm3
00007a66921dc412  jnz 0x00007A66921DF702
00007a66921dc418  vmovaps xmm8, [rsp+0x40]
00007a66921dc41e  vpermilpd xmm8, xmm8, 0x00
00007a66921dc424  movaps xmm4, xmm13
00007a66921dc428  mulpd xmm4, xmm8
00007a66921dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007a66921dc432  ptest xmm3, xmm3
00007a66921dc437  jnz 0x00007A66921DF845
00007a66921dc43d  movaps xmm13, xmm15
00007a66921dc441  addpd xmm13, xmm9
00007a66921dc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007a66921dc44c  ptest xmm8, xmm8
00007a66921dc452  jnz 0x00007A66921DF987
00007a66921dc458  movaps xmm15, xmm1
00007a66921dc45c  addpd xmm15, xmm5
00007a66921dc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007a66921dc467  ptest xmm9, xmm9
00007a66921dc46d  jnz 0x00007A66921DFACB
00007a66921dc473  vmovaps [rsp+0x30], xmm11
00007a66921dc479  vmovaps xmm1, [rsp+0x30]
00007a66921dc47f  por xmm11, xmm1
00007a66921dc484  movaps [r15+0x250], xmm11
00007a66921dc48c  vmovaps [rsp+0x30], xmm12
00007a66921dc492  vmovaps xmm1, [rsp+0x30]
00007a66921dc498  por xmm12, xmm1
00007a66921dc49d  movaps [r15+0x2A0], xmm12
00007a66921dc4a5  vmovaps xmm1, [rsp+0xA0]
00007a66921dc4ae  vmovaps xmm11, [rsp+0xA0]
00007a66921dc4b7  por xmm1, xmm11
00007a66921dc4bc  movaps [r15+0x1D0], xmm1
00007a66921dc4c4  lea r12, [rax+0x40]
00007a66921dc4c8  movups xmm1, [r13+r12*1]
00007a66921dc4ce  movaps [r15+0x2C0], xmm1
00007a66921dc4d6  vmovaps xmm11, [rsp+0x40]
00007a66921dc4dc  vpermilpd xmm11, xmm11, 0x00
00007a66921dc4e2  vmovaps xmm8, [rsp+0xE0]
00007a66921dc4eb  movaps xmm9, xmm8
00007a66921dc4ef  mulpd xmm9, xmm11
00007a66921dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007a66921dc4fa  ptest xmm5, xmm5
00007a66921dc4ff  jnz 0x00007A66921DFC17
00007a66921dc505  movaps xmm11, xmm10
00007a66921dc509  addpd xmm11, xmm6
00007a66921dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007a66921dc514  ptest xmm8, xmm8
00007a66921dc51a  jnz 0x00007A66921DFD5B
00007a66921dc520  movaps xmm10, xmm14
00007a66921dc524  addpd xmm10, xmm4
00007a66921dc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007a66921dc52f  ptest xmm8, xmm8
00007a66921dc535  jnz 0x00007A66921DFE9E
00007a66921dc53b  vmovaps xmm14, [rsp+0x40]
00007a66921dc541  vpermilpd xmm14, xmm14, 0x00
00007a66921dc547  movaps xmm8, xmm1
00007a66921dc54b  mulpd xmm8, xmm14
00007a66921dc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007a66921dc556  ptest xmm6, xmm6
00007a66921dc55b  jnz 0x00007A66921DFFE1
00007a66921dc561  movaps xmm1, [r15+0x2B0]
00007a66921dc569  vmovaps xmm14, [rsp+0x40]
00007a66921dc56f  vpermilpd xmm14, xmm14, 0x00
00007a66921dc575  movaps xmm6, xmm1
00007a66921dc578  mulpd xmm6, xmm14
00007a66921dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007a66921dc582  ptest xmm5, xmm5
00007a66921dc587  jnz 0x00007A66921E0124
00007a66921dc58d  vmovaps xmm1, [rsp+0x10]
00007a66921dc593  vpermilpd xmm1, xmm1, 0x00
00007a66921dc599  movaps xmm14, xmm12
00007a66921dc59d  mulpd xmm14, xmm1
00007a66921dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007a66921dc5a8  ptest xmm5, xmm5
00007a66921dc5ad  jnz 0x00007A66921E0265
00007a66921dc5b3  movaps xmm1, xmm13
00007a66921dc5b7  addpd xmm1, xmm9
00007a66921dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007a66921dc5c1  ptest xmm12, xmm12
00007a66921dc5c7  jnz 0x00007A66921E03A8
00007a66921dc5cd  vmovaps xmm13, [rsp+0x10]
00007a66921dc5d3  vpermilpd xmm13, xmm13, 0x00
00007a66921dc5d9  movaps xmm12, xmm7
00007a66921dc5dd  mulpd xmm12, xmm13
00007a66921dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007a66921dc5e8  ptest xmm9, xmm9
00007a66921dc5ee  jnz 0x00007A66921E04EA
00007a66921dc5f4  movaps xmm13, xmm15
00007a66921dc5f8  addpd xmm13, xmm8
00007a66921dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007a66921dc603  ptest xmm9, xmm9
00007a66921dc609  jnz 0x00007A66921E062D
00007a66921dc60f  movaps xmm15, [r15+0x290]
00007a66921dc617  vmovaps xmm9, [rsp+0x10]
00007a66921dc61d  vpermilpd xmm9, xmm9, 0x00
00007a66921dc623  movaps xmm8, xmm15
00007a66921dc627  mulpd xmm8, xmm9
00007a66921dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007a66921dc632  ptest xmm7, xmm7
00007a66921dc637  jnz 0x00007A66921E0771
00007a66921dc63d  movaps xmm15, xmm11
00007a66921dc641  addpd xmm15, xmm6
00007a66921dc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007a66921dc64c  ptest xmm9, xmm9
00007a66921dc652  jnz 0x00007A66921E08B5
00007a66921dc658  movaps xmm11, [r15+0x1E0]
00007a66921dc660  vmovaps xmm9, [rsp+0x10]
00007a66921dc666  vpermilpd xmm9, xmm9, 0x00
00007a66921dc66c  movaps xmm7, xmm11
00007a66921dc670  mulpd xmm7, xmm9
00007a66921dc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007a66921dc67a  ptest xmm6, xmm6
00007a66921dc67f  jnz 0x00007A66921E09F8
00007a66921dc685  movaps xmm11, xmm10
00007a66921dc689  addpd xmm11, xmm14
00007a66921dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007a66921dc694  ptest xmm9, xmm9
00007a66921dc69a  jnz 0x00007A66921E0B3A
00007a66921dc6a0  lea r12, [rax+0x70]
00007a66921dc6a4  movups xmm14, [r13+r12*1]
00007a66921dc6aa  movaps [r15+0x240], xmm14
00007a66921dc6b2  movaps xmm10, xmm1
00007a66921dc6b6  addpd xmm10, xmm12
00007a66921dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007a66921dc6c1  ptest xmm9, xmm9
00007a66921dc6c7  jnz 0x00007A66921E0C88
00007a66921dc6cd  movaps [r15+0x170], xmm10
00007a66921dc6d5  vmovaps xmm1, [rsp+0x20]
00007a66921dc6db  vpermilpd xmm1, xmm1, 0x00
00007a66921dc6e1  movaps xmm12, xmm14
00007a66921dc6e5  mulpd xmm12, xmm1
00007a66921dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007a66921dc6f0  ptest xmm9, xmm9
00007a66921dc6f6  jnz 0x00007A66921E0DCB
00007a66921dc6fc  vmovaps xmm1, [rsp+0x20]
00007a66921dc702  vpermilpd xmm1, xmm1, 0x00
00007a66921dc708  vmovaps xmm9, [rsp+0xB0]
00007a66921dc711  movaps xmm14, xmm9
00007a66921dc715  mulpd xmm14, xmm1
00007a66921dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007a66921dc720  ptest xmm6, xmm6
00007a66921dc725  jnz 0x00007A66921E0F0E
00007a66921dc72b  movaps [r15+0x180], xmm14
00007a66921dc733  movaps xmm1, xmm13
00007a66921dc737  addpd xmm1, xmm8
00007a66921dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007a66921dc741  ptest xmm9, xmm9
00007a66921dc747  jnz 0x00007A66921E1051
00007a66921dc74d  movaps [r15+0x210], xmm1
00007a66921dc755  movups xmm13, [r13+rax*1]
00007a66921dc75b  lea r12, [rax+0x10]
00007a66921dc75f  movups xmm9, [r13+r12*1]
00007a66921dc765  movaps [r15+0x230], xmm9
00007a66921dc76d  movaps xmm8, xmm15
00007a66921dc771  addpd xmm8, xmm7
00007a66921dc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007a66921dc77c  ptest xmm6, xmm6
00007a66921dc781  jnz 0x00007A66921E11A7
00007a66921dc787  movaps [r15+0x130], xmm8
00007a66921dc78f  vmovaps xmm15, [rsp+0x20]
00007a66921dc795  vpermilpd xmm15, xmm15, 0x00
00007a66921dc79b  movaps xmm7, xmm9
00007a66921dc79f  mulpd xmm7, xmm15
00007a66921dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007a66921dc7a9  ptest xmm6, xmm6
00007a66921dc7ae  jnz 0x00007A66921E12EA
00007a66921dc7b4  movaps [r15+0x220], xmm7
00007a66921dc7bc  vmovaps xmm15, [rsp+0x20]
00007a66921dc7c2  vpermilpd xmm15, xmm15, 0x00
00007a66921dc7c8  movaps xmm9, xmm13
00007a66921dc7cc  mulpd xmm9, xmm15
00007a66921dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007a66921dc7d7  ptest xmm6, xmm6
00007a66921dc7dc  jnz 0x00007A66921E142C
00007a66921dc7e2  movaps xmm15, xmm11
00007a66921dc7e6  addpd xmm15, xmm12
00007a66921dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007a66921dc7f1  ptest xmm13, xmm13
00007a66921dc7f7  jnz 0x00007A66921E1570
00007a66921dc7fd  movaps [r15+0x140], xmm15
00007a66921dc805  movaps xmm13, xmm10
00007a66921dc809  addpd xmm13, xmm14
00007a66921dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007a66921dc814  ptest xmm12, xmm12
00007a66921dc81a  jnz 0x00007A66921E16B4
00007a66921dc820  movaps [r15+0x150], xmm13
00007a66921dc828  movaps xmm14, xmm1
00007a66921dc82c  addpd xmm14, xmm7
00007a66921dc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007a66921dc837  ptest xmm12, xmm12
00007a66921dc83d  jnz 0x00007A66921E17F8
00007a66921dc843  movaps [r15+0x160], xmm14
00007a66921dc84b  movaps xmm1, xmm8
00007a66921dc84f  addpd xmm1, xmm9
00007a66921dc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007a66921dc859  ptest xmm12, xmm12
00007a66921dc85f  jnz 0x00007A66921E193A
00007a66921dc865  movaps [r15+0x120], xmm1
00007a66921dc86d  movups [r13+r14*1], xmm15
00007a66921dc873  lea rax, [r14+0x10]
00007a66921dc877  movups [r13+rax*1], xmm13
00007a66921dc87d  lea rax, [r14+0x20]
00007a66921dc881  movups [r13+rax*1], xmm14
00007a66921dc887  lea rax, [r14+0x30]
00007a66921dc88b  movups [r13+rax*1], xmm1
00007a66921dc891  mov eax, [r15+0x108]
00007a66921dc898  sahf
00007a66921dc899  jnz 0x00007A66921DC8CB
00007a66921dc89b  cmp dword ptr [r15+0x318], 0x00
00007a66921dc8a3  jz 0x00007A66921DB900
00007a66921dc8a9  nop [rax+rax*1], ax
00007a66921dc8b2  nop [rax+rax*1], eax
00007a66921dc8ba  mov eax, 0x410444
00007a66921dc8bf  mov [r15+0x100], rax
00007a66921dc8c6  jmp 0x00007A6691FFE110
00007a66921dc8cb  cmp dword ptr [r15+0x318], 0x00
00007a66921dc8d3  jz 0x00007A66921D57E0
00007a66921dc8d9  nop [rax+rax*1], ax
00007a66921dc8e2  nop [rax+rax*1], eax
00007a66921dc8ea  mov eax, 0x410278
00007a66921dc8ef  mov [r15+0x100], rax
00007a66921dc8f6  jmp 0x00007A6691FFE110
00007a66921dc8fb  int3
00007a66921dc8fc  call 0x00007A66920E27E0
00007a66921dc901  jmp 0x00007A66921DB9DF
00007a66921dc906  call 0x00007A66920E1570
00007a66921dc90b  jmp 0x00007A66921DB9E8
00007a66921dc910  call 0x00007A66920E27E0
00007a66921dc915  jmp 0x00007A66921DBA44
00007a66921dc91a  call 0x00007A66920E1570
00007a66921dc91f  jmp 0x00007A66921DBA4D
00007a66921dc924  call 0x00007A66920E27E0
00007a66921dc929  jmp 0x00007A66921DBA90
00007a66921dc92e  call 0x00007A66920E1570
00007a66921dc933  jmp 0x00007A66921DBA99
00007a66921dc938  call 0x00007A669200DC20
00007a66921dc93d  jmp 0x00007A66921DBAD8
00007a66921dc942  call 0x00007A66920D59C0
00007a66921dc947  jmp 0x00007A66921DBAEB
00007a66921dc94c  call 0x00007A66920E0E30
00007a66921dc951  jmp 0x00007A66921DBB09
00007a66921dc956  call 0x00007A66920DFBC0
00007a66921dc95b  jmp 0x00007A66921DBB13
00007a66921dc960  call 0x00007A66920DE950
00007a66921dc965  jmp 0x00007A66921DBB1D
00007a66921dc96a  sub rsp, 0x08
00007a66921dc96e  push rax
00007a66921dc96f  push rcx
00007a66921dc970  push rdx
00007a66921dc971  push rdi
00007a66921dc972  push rsi
00007a66921dc973  push r8
00007a66921dc975  push r9
00007a66921dc977  push r10
00007a66921dc979  push r11
00007a66921dc97b  sub rsp, 0xF0
00007a66921dc982  vmovaps [rsp], xmm0
00007a66921dc987  vmovaps [rsp+0x10], xmm1
00007a66921dc98d  vmovaps [rsp+0x20], xmm2
00007a66921dc993  vmovaps [rsp+0x30], xmm3
00007a66921dc999  vmovaps [rsp+0x40], xmm4
00007a66921dc99f  vmovaps [rsp+0x50], xmm5
00007a66921dc9a5  vmovaps [rsp+0x60], xmm6
00007a66921dc9ab  vmovaps [rsp+0x70], xmm7
00007a66921dc9b1  vmovaps [rsp+0x80], xmm9
00007a66921dc9ba  vmovaps [rsp+0x90], xmm10
00007a66921dc9c3  vmovaps [rsp+0xA0], xmm11
00007a66921dc9cc  vmovaps [rsp+0xB0], xmm12
00007a66921dc9d5  vmovaps [rsp+0xC0], xmm13
00007a66921dc9de  vmovaps [rsp+0xD0], xmm14
00007a66921dc9e7  vmovaps [rsp+0xE0], xmm15
00007a66921dc9f0  sub rsp, 0x30
00007a66921dc9f4  movaps [rsp], xmm8
00007a66921dc9f9  movaps [rsp+0x10], xmm12
00007a66921dc9ff  movaps [rsp+0x20], xmm15
00007a66921dca05  lea rdi, [rsp]
00007a66921dca09  mov esi, 0x00
00007a66921dca0e  mov rax, 0x635346DC7530
00007a66921dca18  call rax
00007a66921dca1a  movaps xmm8, [rsp]
00007a66921dca1f  add rsp, 0x30
00007a66921dca23  vmovaps xmm0, [rsp]
00007a66921dca28  vmovaps xmm1, [rsp+0x10]
00007a66921dca2e  vmovaps xmm2, [rsp+0x20]
00007a66921dca34  vmovaps xmm3, [rsp+0x30]
00007a66921dca3a  vmovaps xmm4, [rsp+0x40]
00007a66921dca40  vmovaps xmm5, [rsp+0x50]
00007a66921dca46  vmovaps xmm6, [rsp+0x60]
00007a66921dca4c  vmovaps xmm7, [rsp+0x70]
00007a66921dca52  vmovaps xmm9, [rsp+0x80]
00007a66921dca5b  vmovaps xmm10, [rsp+0x90]
00007a66921dca64  vmovaps xmm11, [rsp+0xA0]
00007a66921dca6d  vmovaps xmm12, [rsp+0xB0]
00007a66921dca76  vmovaps xmm13, [rsp+0xC0]
00007a66921dca7f  vmovaps xmm14, [rsp+0xD0]
00007a66921dca88  vmovaps xmm15, [rsp+0xE0]
00007a66921dca91  add rsp, 0xF0
00007a66921dca98  pop r11
00007a66921dca9a  pop r10
00007a66921dca9c  pop r9
00007a66921dca9e  pop r8
00007a66921dcaa0  pop rsi
00007a66921dcaa1  pop rdi
00007a66921dcaa2  pop rdx
00007a66921dcaa3  pop rcx
00007a66921dcaa4  pop rax
00007a66921dcaa5  add rsp, 0x08
00007a66921dcaa9  jmp 0x00007A66921DBB47
00007a66921dcaae  sub rsp, 0x08
00007a66921dcab2  push rax
00007a66921dcab3  push rcx
00007a66921dcab4  push rdx
00007a66921dcab5  push rdi
00007a66921dcab6  push rsi
00007a66921dcab7  push r8
00007a66921dcab9  push r9
00007a66921dcabb  push r10
00007a66921dcabd  push r11
00007a66921dcabf  sub rsp, 0xF0
00007a66921dcac6  vmovaps [rsp], xmm0
00007a66921dcacb  vmovaps [rsp+0x10], xmm1
00007a66921dcad1  vmovaps [rsp+0x20], xmm2
00007a66921dcad7  vmovaps [rsp+0x30], xmm3
00007a66921dcadd  vmovaps [rsp+0x40], xmm4
00007a66921dcae3  vmovaps [rsp+0x50], xmm5
00007a66921dcae9  vmovaps [rsp+0x60], xmm6
00007a66921dcaef  vmovaps [rsp+0x70], xmm8
00007a66921dcaf5  vmovaps [rsp+0x80], xmm9
00007a66921dcafe  vmovaps [rsp+0x90], xmm10
00007a66921dcb07  vmovaps [rsp+0xA0], xmm11
00007a66921dcb10  vmovaps [rsp+0xB0], xmm12
00007a66921dcb19  vmovaps [rsp+0xC0], xmm13
00007a66921dcb22  vmovaps [rsp+0xD0], xmm14
00007a66921dcb2b  vmovaps [rsp+0xE0], xmm15
00007a66921dcb34  sub rsp, 0x30
00007a66921dcb38  movaps [rsp], xmm7
00007a66921dcb3c  movaps [rsp+0x10], xmm9
00007a66921dcb42  movaps [rsp+0x20], xmm15
00007a66921dcb48  lea rdi, [rsp]
00007a66921dcb4c  mov esi, 0x00
00007a66921dcb51  mov rax, 0x635346DC7530
00007a66921dcb5b  call rax
00007a66921dcb5d  movaps xmm7, [rsp]
00007a66921dcb61  add rsp, 0x30
00007a66921dcb65  vmovaps xmm0, [rsp]
00007a66921dcb6a  vmovaps xmm1, [rsp+0x10]
00007a66921dcb70  vmovaps xmm2, [rsp+0x20]
00007a66921dcb76  vmovaps xmm3, [rsp+0x30]
00007a66921dcb7c  vmovaps xmm4, [rsp+0x40]
00007a66921dcb82  vmovaps xmm5, [rsp+0x50]
00007a66921dcb88  vmovaps xmm6, [rsp+0x60]
00007a66921dcb8e  vmovaps xmm8, [rsp+0x70]
00007a66921dcb94  vmovaps xmm9, [rsp+0x80]
00007a66921dcb9d  vmovaps xmm10, [rsp+0x90]
00007a66921dcba6  vmovaps xmm11, [rsp+0xA0]
00007a66921dcbaf  vmovaps xmm12, [rsp+0xB0]
00007a66921dcbb8  vmovaps xmm13, [rsp+0xC0]
00007a66921dcbc1  vmovaps xmm14, [rsp+0xD0]
00007a66921dcbca  vmovaps xmm15, [rsp+0xE0]
00007a66921dcbd3  add rsp, 0xF0
00007a66921dcbda  pop r11
00007a66921dcbdc  pop r10
00007a66921dcbde  pop r9
00007a66921dcbe0  pop r8
00007a66921dcbe2  pop rsi
00007a66921dcbe3  pop rdi
00007a66921dcbe4  pop rdx
00007a66921dcbe5  pop rcx
00007a66921dcbe6  pop rax
00007a66921dcbe7  add rsp, 0x08
00007a66921dcbeb  jmp 0x00007A66921DBB75
00007a66921dcbf0  sub rsp, 0x08
00007a66921dcbf4  push rax
00007a66921dcbf5  push rcx
00007a66921dcbf6  push rdx
00007a66921dcbf7  push rdi
00007a66921dcbf8  push rsi
00007a66921dcbf9  push r8
00007a66921dcbfb  push r9
00007a66921dcbfd  push r10
00007a66921dcbff  push r11
00007a66921dcc01  sub rsp, 0xF0
00007a66921dcc08  vmovaps [rsp], xmm0
00007a66921dcc0d  vmovaps [rsp+0x10], xmm1
00007a66921dcc13  vmovaps [rsp+0x20], xmm2
00007a66921dcc19  vmovaps [rsp+0x30], xmm3
00007a66921dcc1f  vmovaps [rsp+0x40], xmm4
00007a66921dcc25  vmovaps [rsp+0x50], xmm5
00007a66921dcc2b  vmovaps [rsp+0x60], xmm6
00007a66921dcc31  vmovaps [rsp+0x70], xmm7
00007a66921dcc37  vmovaps [rsp+0x80], xmm8
00007a66921dcc40  vmovaps [rsp+0x90], xmm10
00007a66921dcc49  vmovaps [rsp+0xA0], xmm11
00007a66921dcc52  vmovaps [rsp+0xB0], xmm12
00007a66921dcc5b  vmovaps [rsp+0xC0], xmm13
00007a66921dcc64  vmovaps [rsp+0xD0], xmm14
00007a66921dcc6d  vmovaps [rsp+0xE0], xmm15
00007a66921dcc76  sub rsp, 0x30
00007a66921dcc7a  movaps [rsp], xmm9
00007a66921dcc7f  movaps [rsp+0x10], xmm12
00007a66921dcc85  movaps [rsp+0x20], xmm10
00007a66921dcc8b  lea rdi, [rsp]
00007a66921dcc8f  mov esi, 0x00
00007a66921dcc94  mov rax, 0x635346DC7530
00007a66921dcc9e  call rax
00007a66921dcca0  movaps xmm9, [rsp]
00007a66921dcca5  add rsp, 0x30
00007a66921dcca9  vmovaps xmm0, [rsp]
00007a66921dccae  vmovaps xmm1, [rsp+0x10]
00007a66921dccb4  vmovaps xmm2, [rsp+0x20]
00007a66921dccba  vmovaps xmm3, [rsp+0x30]
00007a66921dccc0  vmovaps xmm4, [rsp+0x40]
00007a66921dccc6  vmovaps xmm5, [rsp+0x50]
00007a66921dcccc  vmovaps xmm6, [rsp+0x60]
00007a66921dccd2  vmovaps xmm7, [rsp+0x70]
00007a66921dccd8  vmovaps xmm8, [rsp+0x80]
00007a66921dcce1  vmovaps xmm10, [rsp+0x90]
00007a66921dccea  vmovaps xmm11, [rsp+0xA0]
00007a66921dccf3  vmovaps xmm12, [rsp+0xB0]
00007a66921dccfc  vmovaps xmm13, [rsp+0xC0]
00007a66921dcd05  vmovaps xmm14, [rsp+0xD0]
00007a66921dcd0e  vmovaps xmm15, [rsp+0xE0]
00007a66921dcd17  add rsp, 0xF0
00007a66921dcd1e  pop r11
00007a66921dcd20  pop r10
00007a66921dcd22  pop r9
00007a66921dcd24  pop r8
00007a66921dcd26  pop rsi
00007a66921dcd27  pop rdi
00007a66921dcd28  pop rdx
00007a66921dcd29  pop rcx
00007a66921dcd2a  pop rax
00007a66921dcd2b  add rsp, 0x08
00007a66921dcd2f  jmp 0x00007A66921DBB99
00007a66921dcd34  sub rsp, 0x08
00007a66921dcd38  push rax
00007a66921dcd39  push rcx
00007a66921dcd3a  push rdx
00007a66921dcd3b  push rdi
00007a66921dcd3c  push rsi
00007a66921dcd3d  push r8
00007a66921dcd3f  push r9
00007a66921dcd41  push r10
00007a66921dcd43  push r11
00007a66921dcd45  sub rsp, 0xF0
00007a66921dcd4c  vmovaps [rsp], xmm0
00007a66921dcd51  vmovaps [rsp+0x10], xmm1
00007a66921dcd57  vmovaps [rsp+0x20], xmm2
00007a66921dcd5d  vmovaps [rsp+0x30], xmm3
00007a66921dcd63  vmovaps [rsp+0x40], xmm4
00007a66921dcd69  vmovaps [rsp+0x50], xmm5
00007a66921dcd6f  vmovaps [rsp+0x60], xmm6
00007a66921dcd75  vmovaps [rsp+0x70], xmm7
00007a66921dcd7b  vmovaps [rsp+0x80], xmm8
00007a66921dcd84  vmovaps [rsp+0x90], xmm9
00007a66921dcd8d  vmovaps [rsp+0xA0], xmm11
00007a66921dcd96  vmovaps [rsp+0xB0], xmm12
00007a66921dcd9f  vmovaps [rsp+0xC0], xmm13
00007a66921dcda8  vmovaps [rsp+0xD0], xmm14
00007a66921dcdb1  vmovaps [rsp+0xE0], xmm15
00007a66921dcdba  sub rsp, 0x30
00007a66921dcdbe  movaps [rsp], xmm10
00007a66921dcdc3  movaps [rsp+0x10], xmm12
00007a66921dcdc9  movaps [rsp+0x20], xmm11
00007a66921dcdcf  lea rdi, [rsp]
00007a66921dcdd3  mov esi, 0x00
00007a66921dcdd8  mov rax, 0x635346DC7530
00007a66921dcde2  call rax
00007a66921dcde4  movaps xmm10, [rsp]
00007a66921dcde9  add rsp, 0x30
00007a66921dcded  vmovaps xmm0, [rsp]
00007a66921dcdf2  vmovaps xmm1, [rsp+0x10]
00007a66921dcdf8  vmovaps xmm2, [rsp+0x20]
00007a66921dcdfe  vmovaps xmm3, [rsp+0x30]
00007a66921dce04  vmovaps xmm4, [rsp+0x40]
00007a66921dce0a  vmovaps xmm5, [rsp+0x50]
00007a66921dce10  vmovaps xmm6, [rsp+0x60]
00007a66921dce16  vmovaps xmm7, [rsp+0x70]
00007a66921dce1c  vmovaps xmm8, [rsp+0x80]
00007a66921dce25  vmovaps xmm9, [rsp+0x90]
00007a66921dce2e  vmovaps xmm11, [rsp+0xA0]
00007a66921dce37  vmovaps xmm12, [rsp+0xB0]
00007a66921dce40  vmovaps xmm13, [rsp+0xC0]
00007a66921dce49  vmovaps xmm14, [rsp+0xD0]
00007a66921dce52  vmovaps xmm15, [rsp+0xE0]
00007a66921dce5b  add rsp, 0xF0
00007a66921dce62  pop r11
00007a66921dce64  pop r10
00007a66921dce66  pop r9
00007a66921dce68  pop r8
00007a66921dce6a  pop rsi
00007a66921dce6b  pop rdi
00007a66921dce6c  pop rdx
00007a66921dce6d  pop rcx
00007a66921dce6e  pop rax
00007a66921dce6f  add rsp, 0x08
00007a66921dce73  jmp 0x00007A66921DBBB3
00007a66921dce78  sub rsp, 0x08
00007a66921dce7c  push rax
00007a66921dce7d  push rcx
00007a66921dce7e  push rdx
00007a66921dce7f  push rdi
00007a66921dce80  push rsi
00007a66921dce81  push r8
00007a66921dce83  push r9
00007a66921dce85  push r10
00007a66921dce87  push r11
00007a66921dce89  sub rsp, 0xF0
00007a66921dce90  vmovaps [rsp], xmm0
00007a66921dce95  vmovaps [rsp+0x10], xmm1
00007a66921dce9b  vmovaps [rsp+0x20], xmm2
00007a66921dcea1  vmovaps [rsp+0x30], xmm3
00007a66921dcea7  vmovaps [rsp+0x40], xmm4
00007a66921dcead  vmovaps [rsp+0x50], xmm5
00007a66921dceb3  vmovaps [rsp+0x60], xmm7
00007a66921dceb9  vmovaps [rsp+0x70], xmm8
00007a66921dcebf  vmovaps [rsp+0x80], xmm9
00007a66921dcec8  vmovaps [rsp+0x90], xmm10
00007a66921dced1  vmovaps [rsp+0xA0], xmm11
00007a66921dceda  vmovaps [rsp+0xB0], xmm12
00007a66921dcee3  vmovaps [rsp+0xC0], xmm13
00007a66921dceec  vmovaps [rsp+0xD0], xmm14
00007a66921dcef5  vmovaps [rsp+0xE0], xmm15
00007a66921dcefe  sub rsp, 0x30
00007a66921dcf02  movaps [rsp], xmm6
00007a66921dcf06  movaps [rsp+0x10], xmm12
00007a66921dcf0c  movaps [rsp+0x20], xmm11
00007a66921dcf12  lea rdi, [rsp]
00007a66921dcf16  mov esi, 0x00
00007a66921dcf1b  mov rax, 0x635346DC7530
00007a66921dcf25  call rax
00007a66921dcf27  movaps xmm6, [rsp]
00007a66921dcf2b  add rsp, 0x30
00007a66921dcf2f  vmovaps xmm0, [rsp]
00007a66921dcf34  vmovaps xmm1, [rsp+0x10]
00007a66921dcf3a  vmovaps xmm2, [rsp+0x20]
00007a66921dcf40  vmovaps xmm3, [rsp+0x30]
00007a66921dcf46  vmovaps xmm4, [rsp+0x40]
00007a66921dcf4c  vmovaps xmm5, [rsp+0x50]
00007a66921dcf52  vmovaps xmm7, [rsp+0x60]
00007a66921dcf58  vmovaps xmm8, [rsp+0x70]
00007a66921dcf5e  vmovaps xmm9, [rsp+0x80]
00007a66921dcf67  vmovaps xmm10, [rsp+0x90]
00007a66921dcf70  vmovaps xmm11, [rsp+0xA0]
00007a66921dcf79  vmovaps xmm12, [rsp+0xB0]
00007a66921dcf82  vmovaps xmm13, [rsp+0xC0]
00007a66921dcf8b  vmovaps xmm14, [rsp+0xD0]
00007a66921dcf94  vmovaps xmm15, [rsp+0xE0]
00007a66921dcf9d  add rsp, 0xF0
00007a66921dcfa4  pop r11
00007a66921dcfa6  pop r10
00007a66921dcfa8  pop r9
00007a66921dcfaa  pop r8
00007a66921dcfac  pop rsi
00007a66921dcfad  pop rdi
00007a66921dcfae  pop rdx
00007a66921dcfaf  pop rcx
00007a66921dcfb0  pop rax
00007a66921dcfb1  add rsp, 0x08
00007a66921dcfb5  jmp 0x00007A66921DBBD4
00007a66921dcfba  sub rsp, 0x08
00007a66921dcfbe  push rax
00007a66921dcfbf  push rcx
00007a66921dcfc0  push rdx
00007a66921dcfc1  push rdi
00007a66921dcfc2  push rsi
00007a66921dcfc3  push r8
00007a66921dcfc5  push r9
00007a66921dcfc7  push r10
00007a66921dcfc9  push r11
00007a66921dcfcb  sub rsp, 0xF0
00007a66921dcfd2  vmovaps [rsp], xmm0
00007a66921dcfd7  vmovaps [rsp+0x10], xmm1
00007a66921dcfdd  vmovaps [rsp+0x20], xmm2
00007a66921dcfe3  vmovaps [rsp+0x30], xmm4
00007a66921dcfe9  vmovaps [rsp+0x40], xmm5
00007a66921dcfef  vmovaps [rsp+0x50], xmm6
00007a66921dcff5  vmovaps [rsp+0x60], xmm7
00007a66921dcffb  vmovaps [rsp+0x70], xmm8
00007a66921dd001  vmovaps [rsp+0x80], xmm9
00007a66921dd00a  vmovaps [rsp+0x90], xmm10
00007a66921dd013  vmovaps [rsp+0xA0], xmm11
00007a66921dd01c  vmovaps [rsp+0xB0], xmm12
00007a66921dd025  vmovaps [rsp+0xC0], xmm13
00007a66921dd02e  vmovaps [rsp+0xD0], xmm14
00007a66921dd037  vmovaps [rsp+0xE0], xmm15
00007a66921dd040  sub rsp, 0x30
00007a66921dd044  movaps [rsp], xmm3
00007a66921dd048  movaps [rsp+0x10], xmm5
00007a66921dd04d  movaps [rsp+0x20], xmm4
00007a66921dd052  lea rdi, [rsp]
00007a66921dd056  mov esi, 0x00
00007a66921dd05b  mov rax, 0x635346DC7530
00007a66921dd065  call rax
00007a66921dd067  movaps xmm3, [rsp]
00007a66921dd06b  add rsp, 0x30
00007a66921dd06f  vmovaps xmm0, [rsp]
00007a66921dd074  vmovaps xmm1, [rsp+0x10]
00007a66921dd07a  vmovaps xmm2, [rsp+0x20]
00007a66921dd080  vmovaps xmm4, [rsp+0x30]
00007a66921dd086  vmovaps xmm5, [rsp+0x40]
00007a66921dd08c  vmovaps xmm6, [rsp+0x50]
00007a66921dd092  vmovaps xmm7, [rsp+0x60]
00007a66921dd098  vmovaps xmm8, [rsp+0x70]
00007a66921dd09e  vmovaps xmm9, [rsp+0x80]
00007a66921dd0a7  vmovaps xmm10, [rsp+0x90]
00007a66921dd0b0  vmovaps xmm11, [rsp+0xA0]
00007a66921dd0b9  vmovaps xmm12, [rsp+0xB0]
00007a66921dd0c2  vmovaps xmm13, [rsp+0xC0]
00007a66921dd0cb  vmovaps xmm14, [rsp+0xD0]
00007a66921dd0d4  vmovaps xmm15, [rsp+0xE0]
00007a66921dd0dd  add rsp, 0xF0
00007a66921dd0e4  pop r11
00007a66921dd0e6  pop r10
00007a66921dd0e8  pop r9
00007a66921dd0ea  pop r8
00007a66921dd0ec  pop rsi
00007a66921dd0ed  pop rdi
00007a66921dd0ee  pop rdx
00007a66921dd0ef  pop rcx
00007a66921dd0f0  pop rax
00007a66921dd0f1  add rsp, 0x08
00007a66921dd0f5  jmp 0x00007A66921DBC35
00007a66921dd0fa  sub rsp, 0x08
00007a66921dd0fe  push rax
00007a66921dd0ff  push rcx
00007a66921dd100  push rdx
00007a66921dd101  push rdi
00007a66921dd102  push rsi
00007a66921dd103  push r8
00007a66921dd105  push r9
00007a66921dd107  push r10
00007a66921dd109  push r11
00007a66921dd10b  sub rsp, 0xF0
00007a66921dd112  vmovaps [rsp], xmm0
00007a66921dd117  vmovaps [rsp+0x10], xmm1
00007a66921dd11d  vmovaps [rsp+0x20], xmm2
00007a66921dd123  vmovaps [rsp+0x30], xmm3
00007a66921dd129  vmovaps [rsp+0x40], xmm4
00007a66921dd12f  vmovaps [rsp+0x50], xmm6
00007a66921dd135  vmovaps [rsp+0x60], xmm7
00007a66921dd13b  vmovaps [rsp+0x70], xmm8
00007a66921dd141  vmovaps [rsp+0x80], xmm9
00007a66921dd14a  vmovaps [rsp+0x90], xmm10
00007a66921dd153  vmovaps [rsp+0xA0], xmm11
00007a66921dd15c  vmovaps [rsp+0xB0], xmm12
00007a66921dd165  vmovaps [rsp+0xC0], xmm13
00007a66921dd16e  vmovaps [rsp+0xD0], xmm14
00007a66921dd177  vmovaps [rsp+0xE0], xmm15
00007a66921dd180  sub rsp, 0x30
00007a66921dd184  movaps [rsp], xmm5
00007a66921dd188  movaps [rsp+0x10], xmm8
00007a66921dd18e  movaps [rsp+0x20], xmm15
00007a66921dd194  lea rdi, [rsp]
00007a66921dd198  mov esi, 0x00
00007a66921dd19d  mov rax, 0x635346DC7530
00007a66921dd1a7  call rax
00007a66921dd1a9  movaps xmm5, [rsp]
00007a66921dd1ad  add rsp, 0x30
00007a66921dd1b1  vmovaps xmm0, [rsp]
00007a66921dd1b6  vmovaps xmm1, [rsp+0x10]
00007a66921dd1bc  vmovaps xmm2, [rsp+0x20]
00007a66921dd1c2  vmovaps xmm3, [rsp+0x30]
00007a66921dd1c8  vmovaps xmm4, [rsp+0x40]
00007a66921dd1ce  vmovaps xmm6, [rsp+0x50]
00007a66921dd1d4  vmovaps xmm7, [rsp+0x60]
00007a66921dd1da  vmovaps xmm8, [rsp+0x70]
00007a66921dd1e0  vmovaps xmm9, [rsp+0x80]
00007a66921dd1e9  vmovaps xmm10, [rsp+0x90]
00007a66921dd1f2  vmovaps xmm11, [rsp+0xA0]
00007a66921dd1fb  vmovaps xmm12, [rsp+0xB0]
00007a66921dd204  vmovaps xmm13, [rsp+0xC0]
00007a66921dd20d  vmovaps xmm14, [rsp+0xD0]
00007a66921dd216  vmovaps xmm15, [rsp+0xE0]
00007a66921dd21f  add rsp, 0xF0
00007a66921dd226  pop r11
00007a66921dd228  pop r10
00007a66921dd22a  pop r9
00007a66921dd22c  pop r8
00007a66921dd22e  pop rsi
00007a66921dd22f  pop rdi
00007a66921dd230  pop rdx
00007a66921dd231  pop rcx
00007a66921dd232  pop rax
00007a66921dd233  add rsp, 0x08
00007a66921dd237  jmp 0x00007A66921DBC73
00007a66921dd23c  sub rsp, 0x08
00007a66921dd240  push rax
00007a66921dd241  push rcx
00007a66921dd242  push rdx
00007a66921dd243  push rdi
00007a66921dd244  push rsi
00007a66921dd245  push r8
00007a66921dd247  push r9
00007a66921dd249  push r10
00007a66921dd24b  push r11
00007a66921dd24d  sub rsp, 0xF0
00007a66921dd254  vmovaps [rsp], xmm0
00007a66921dd259  vmovaps [rsp+0x10], xmm1
00007a66921dd25f  vmovaps [rsp+0x20], xmm2
00007a66921dd265  vmovaps [rsp+0x30], xmm3
00007a66921dd26b  vmovaps [rsp+0x40], xmm5
00007a66921dd271  vmovaps [rsp+0x50], xmm6
00007a66921dd277  vmovaps [rsp+0x60], xmm7
00007a66921dd27d  vmovaps [rsp+0x70], xmm8
00007a66921dd283  vmovaps [rsp+0x80], xmm9
00007a66921dd28c  vmovaps [rsp+0x90], xmm10
00007a66921dd295  vmovaps [rsp+0xA0], xmm11
00007a66921dd29e  vmovaps [rsp+0xB0], xmm12
00007a66921dd2a7  vmovaps [rsp+0xC0], xmm13
00007a66921dd2b0  vmovaps [rsp+0xD0], xmm14
00007a66921dd2b9  vmovaps [rsp+0xE0], xmm15
00007a66921dd2c2  sub rsp, 0x30
00007a66921dd2c6  movaps [rsp], xmm4
00007a66921dd2ca  movaps [rsp+0x10], xmm9
00007a66921dd2d0  movaps [rsp+0x20], xmm8
00007a66921dd2d6  lea rdi, [rsp]
00007a66921dd2da  mov esi, 0x00
00007a66921dd2df  mov rax, 0x635346DC7530
00007a66921dd2e9  call rax
00007a66921dd2eb  movaps xmm4, [rsp]
00007a66921dd2ef  add rsp, 0x30
00007a66921dd2f3  vmovaps xmm0, [rsp]
00007a66921dd2f8  vmovaps xmm1, [rsp+0x10]
00007a66921dd2fe  vmovaps xmm2, [rsp+0x20]
00007a66921dd304  vmovaps xmm3, [rsp+0x30]
00007a66921dd30a  vmovaps xmm5, [rsp+0x40]
00007a66921dd310  vmovaps xmm6, [rsp+0x50]
00007a66921dd316  vmovaps xmm7, [rsp+0x60]
00007a66921dd31c  vmovaps xmm8, [rsp+0x70]
00007a66921dd322  vmovaps xmm9, [rsp+0x80]
00007a66921dd32b  vmovaps xmm10, [rsp+0x90]
00007a66921dd334  vmovaps xmm11, [rsp+0xA0]
00007a66921dd33d  vmovaps xmm12, [rsp+0xB0]
00007a66921dd346  vmovaps xmm13, [rsp+0xC0]
00007a66921dd34f  vmovaps xmm14, [rsp+0xD0]
00007a66921dd358  vmovaps xmm15, [rsp+0xE0]
00007a66921dd361  add rsp, 0xF0
00007a66921dd368  pop r11
00007a66921dd36a  pop r10
00007a66921dd36c  pop r9
00007a66921dd36e  pop r8
00007a66921dd370  pop rsi
00007a66921dd371  pop rdi
00007a66921dd372  pop rdx
00007a66921dd373  pop rcx
00007a66921dd374  pop rax
00007a66921dd375  add rsp, 0x08
00007a66921dd379  jmp 0x00007A66921DBC94
00007a66921dd37e  sub rsp, 0x08
00007a66921dd382  push rax
00007a66921dd383  push rcx
00007a66921dd384  push rdx
00007a66921dd385  push rdi
00007a66921dd386  push rsi
00007a66921dd387  push r8
00007a66921dd389  push r9
00007a66921dd38b  push r10
00007a66921dd38d  push r11
00007a66921dd38f  sub rsp, 0xF0
00007a66921dd396  vmovaps [rsp], xmm0
00007a66921dd39b  vmovaps [rsp+0x10], xmm1
00007a66921dd3a1  vmovaps [rsp+0x20], xmm2
00007a66921dd3a7  vmovaps [rsp+0x30], xmm3
00007a66921dd3ad  vmovaps [rsp+0x40], xmm4
00007a66921dd3b3  vmovaps [rsp+0x50], xmm5
00007a66921dd3b9  vmovaps [rsp+0x60], xmm6
00007a66921dd3bf  vmovaps [rsp+0x70], xmm7
00007a66921dd3c5  vmovaps [rsp+0x80], xmm8
00007a66921dd3ce  vmovaps [rsp+0x90], xmm10
00007a66921dd3d7  vmovaps [rsp+0xA0], xmm11
00007a66921dd3e0  vmovaps [rsp+0xB0], xmm12
00007a66921dd3e9  vmovaps [rsp+0xC0], xmm13
00007a66921dd3f2  vmovaps [rsp+0xD0], xmm14
00007a66921dd3fb  vmovaps [rsp+0xE0], xmm15
00007a66921dd404  sub rsp, 0x30
00007a66921dd408  movaps [rsp], xmm9
00007a66921dd40d  movaps [rsp+0x10], xmm10
00007a66921dd413  movaps [rsp+0x20], xmm8
00007a66921dd419  lea rdi, [rsp]
00007a66921dd41d  mov esi, 0x00
00007a66921dd422  mov rax, 0x635346DC7530
00007a66921dd42c  call rax
00007a66921dd42e  movaps xmm9, [rsp]
00007a66921dd433  add rsp, 0x30
00007a66921dd437  vmovaps xmm0, [rsp]
00007a66921dd43c  vmovaps xmm1, [rsp+0x10]
00007a66921dd442  vmovaps xmm2, [rsp+0x20]
00007a66921dd448  vmovaps xmm3, [rsp+0x30]
00007a66921dd44e  vmovaps xmm4, [rsp+0x40]
00007a66921dd454  vmovaps xmm5, [rsp+0x50]
00007a66921dd45a  vmovaps xmm6, [rsp+0x60]
00007a66921dd460  vmovaps xmm7, [rsp+0x70]
00007a66921dd466  vmovaps xmm8, [rsp+0x80]
00007a66921dd46f  vmovaps xmm10, [rsp+0x90]
00007a66921dd478  vmovaps xmm11, [rsp+0xA0]
00007a66921dd481  vmovaps xmm12, [rsp+0xB0]
00007a66921dd48a  vmovaps xmm13, [rsp+0xC0]
00007a66921dd493  vmovaps xmm14, [rsp+0xD0]
00007a66921dd49c  vmovaps xmm15, [rsp+0xE0]
00007a66921dd4a5  add rsp, 0xF0
00007a66921dd4ac  pop r11
00007a66921dd4ae  pop r10
00007a66921dd4b0  pop r9
00007a66921dd4b2  pop r8
00007a66921dd4b4  pop rsi
00007a66921dd4b5  pop rdi
00007a66921dd4b6  pop rdx
00007a66921dd4b7  pop rcx
00007a66921dd4b8  pop rax
00007a66921dd4b9  add rsp, 0x08
00007a66921dd4bd  jmp 0x00007A66921DBCAE
00007a66921dd4c2  call 0x00007A66920B52F0
00007a66921dd4c7  jmp 0x00007A66921DBDC8
00007a66921dd4cc  call 0x00007A66920B52F0
00007a66921dd4d1  jmp 0x00007A66921DBDDE
00007a66921dd4d6  sub rsp, 0x08
00007a66921dd4da  push rax
00007a66921dd4db  push rcx
00007a66921dd4dc  push rdx
00007a66921dd4dd  push rdi
00007a66921dd4de  push rsi
00007a66921dd4df  push r8
00007a66921dd4e1  push r9
00007a66921dd4e3  push r10
00007a66921dd4e5  push r11
00007a66921dd4e7  sub rsp, 0xF0
00007a66921dd4ee  vmovaps [rsp], xmm0
00007a66921dd4f3  vmovaps [rsp+0x10], xmm2
00007a66921dd4f9  vmovaps [rsp+0x20], xmm3
00007a66921dd4ff  vmovaps [rsp+0x30], xmm4
00007a66921dd505  vmovaps [rsp+0x40], xmm5
00007a66921dd50b  vmovaps [rsp+0x50], xmm6
00007a66921dd511  vmovaps [rsp+0x60], xmm7
00007a66921dd517  vmovaps [rsp+0x70], xmm8
00007a66921dd51d  vmovaps [rsp+0x80], xmm9
00007a66921dd526  vmovaps [rsp+0x90], xmm10
00007a66921dd52f  vmovaps [rsp+0xA0], xmm11
00007a66921dd538  vmovaps [rsp+0xB0], xmm12
00007a66921dd541  vmovaps [rsp+0xC0], xmm13
00007a66921dd54a  vmovaps [rsp+0xD0], xmm14
00007a66921dd553  vmovaps [rsp+0xE0], xmm15
00007a66921dd55c  sub rsp, 0x30
00007a66921dd560  movaps [rsp], xmm1
00007a66921dd564  movaps [rsp+0x10], xmm6
00007a66921dd569  movaps [rsp+0x20], xmm15
00007a66921dd56f  lea rdi, [rsp]
00007a66921dd573  mov esi, 0x00
00007a66921dd578  mov rax, 0x635346DC7530
00007a66921dd582  call rax
00007a66921dd584  movaps xmm1, [rsp]
00007a66921dd588  add rsp, 0x30
00007a66921dd58c  vmovaps xmm0, [rsp]
00007a66921dd591  vmovaps xmm2, [rsp+0x10]
00007a66921dd597  vmovaps xmm3, [rsp+0x20]
00007a66921dd59d  vmovaps xmm4, [rsp+0x30]
00007a66921dd5a3  vmovaps xmm5, [rsp+0x40]
00007a66921dd5a9  vmovaps xmm6, [rsp+0x50]
00007a66921dd5af  vmovaps xmm7, [rsp+0x60]
00007a66921dd5b5  vmovaps xmm8, [rsp+0x70]
00007a66921dd5bb  vmovaps xmm9, [rsp+0x80]
00007a66921dd5c4  vmovaps xmm10, [rsp+0x90]
00007a66921dd5cd  vmovaps xmm11, [rsp+0xA0]
00007a66921dd5d6  vmovaps xmm12, [rsp+0xB0]
00007a66921dd5df  vmovaps xmm13, [rsp+0xC0]
00007a66921dd5e8  vmovaps xmm14, [rsp+0xD0]
00007a66921dd5f1  vmovaps xmm15, [rsp+0xE0]
00007a66921dd5fa  add rsp, 0xF0
00007a66921dd601  pop r11
00007a66921dd603  pop r10
00007a66921dd605  pop r9
00007a66921dd607  pop r8
00007a66921dd609  pop rsi
00007a66921dd60a  pop rdi
00007a66921dd60b  pop rdx
00007a66921dd60c  pop rcx
00007a66921dd60d  pop rax
00007a66921dd60e  add rsp, 0x08
00007a66921dd612  jmp 0x00007A66921DBE1B
00007a66921dd617  call 0x00007A66920C4620
00007a66921dd61c  jmp 0x00007A66921DBE28
00007a66921dd621  sub rsp, 0x08
00007a66921dd625  push rax
00007a66921dd626  push rcx
00007a66921dd627  push rdx
00007a66921dd628  push rdi
00007a66921dd629  push rsi
00007a66921dd62a  push r8
00007a66921dd62c  push r9
00007a66921dd62e  push r10
00007a66921dd630  push r11
00007a66921dd632  sub rsp, 0xF0
00007a66921dd639  vmovaps [rsp], xmm0
00007a66921dd63e  vmovaps [rsp+0x10], xmm1
00007a66921dd644  vmovaps [rsp+0x20], xmm2
00007a66921dd64a  vmovaps [rsp+0x30], xmm3
00007a66921dd650  vmovaps [rsp+0x40], xmm4
00007a66921dd656  vmovaps [rsp+0x50], xmm5
00007a66921dd65c  vmovaps [rsp+0x60], xmm6
00007a66921dd662  vmovaps [rsp+0x70], xmm7
00007a66921dd668  vmovaps [rsp+0x80], xmm8
00007a66921dd671  vmovaps [rsp+0x90], xmm9
00007a66921dd67a  vmovaps [rsp+0xA0], xmm10
00007a66921dd683  vmovaps [rsp+0xB0], xmm11
00007a66921dd68c  vmovaps [rsp+0xC0], xmm12
00007a66921dd695  vmovaps [rsp+0xD0], xmm13
00007a66921dd69e  vmovaps [rsp+0xE0], xmm15
00007a66921dd6a7  sub rsp, 0x30
00007a66921dd6ab  movaps [rsp], xmm14
00007a66921dd6b0  movaps [rsp+0x10], xmm4
00007a66921dd6b5  movaps [rsp+0x20], xmm3
00007a66921dd6ba  lea rdi, [rsp]
00007a66921dd6be  mov esi, 0x00
00007a66921dd6c3  mov rax, 0x635346DC7530
00007a66921dd6cd  call rax
00007a66921dd6cf  movaps xmm14, [rsp]
00007a66921dd6d4  add rsp, 0x30
00007a66921dd6d8  vmovaps xmm0, [rsp]
00007a66921dd6dd  vmovaps xmm1, [rsp+0x10]
00007a66921dd6e3  vmovaps xmm2, [rsp+0x20]
00007a66921dd6e9  vmovaps xmm3, [rsp+0x30]
00007a66921dd6ef  vmovaps xmm4, [rsp+0x40]
00007a66921dd6f5  vmovaps xmm5, [rsp+0x50]
00007a66921dd6fb  vmovaps xmm6, [rsp+0x60]
00007a66921dd701  vmovaps xmm7, [rsp+0x70]
00007a66921dd707  vmovaps xmm8, [rsp+0x80]
00007a66921dd710  vmovaps xmm9, [rsp+0x90]
00007a66921dd719  vmovaps xmm10, [rsp+0xA0]
00007a66921dd722  vmovaps xmm11, [rsp+0xB0]
00007a66921dd72b  vmovaps xmm12, [rsp+0xC0]
00007a66921dd734  vmovaps xmm13, [rsp+0xD0]
00007a66921dd73d  vmovaps xmm15, [rsp+0xE0]
00007a66921dd746  add rsp, 0xF0
00007a66921dd74d  pop r11
00007a66921dd74f  pop r10
00007a66921dd751  pop r9
00007a66921dd753  pop r8
00007a66921dd755  pop rsi
00007a66921dd756  pop rdi
00007a66921dd757  pop rdx
00007a66921dd758  pop rcx
00007a66921dd759  pop rax
00007a66921dd75a  add rsp, 0x08
00007a66921dd75e  jmp 0x00007A66921DBE42
00007a66921dd763  sub rsp, 0x08
00007a66921dd767  push rax
00007a66921dd768  push rcx
00007a66921dd769  push rdx
00007a66921dd76a  push rdi
00007a66921dd76b  push rsi
00007a66921dd76c  push r8
00007a66921dd76e  push r9
00007a66921dd770  push r10
00007a66921dd772  push r11
00007a66921dd774  sub rsp, 0xF0
00007a66921dd77b  vmovaps [rsp], xmm0
00007a66921dd780  vmovaps [rsp+0x10], xmm1
00007a66921dd786  vmovaps [rsp+0x20], xmm2
00007a66921dd78c  vmovaps [rsp+0x30], xmm3
00007a66921dd792  vmovaps [rsp+0x40], xmm4
00007a66921dd798  vmovaps [rsp+0x50], xmm5
00007a66921dd79e  vmovaps [rsp+0x60], xmm7
00007a66921dd7a4  vmovaps [rsp+0x70], xmm8
00007a66921dd7aa  vmovaps [rsp+0x80], xmm9
00007a66921dd7b3  vmovaps [rsp+0x90], xmm10
00007a66921dd7bc  vmovaps [rsp+0xA0], xmm11
00007a66921dd7c5  vmovaps [rsp+0xB0], xmm12
00007a66921dd7ce  vmovaps [rsp+0xC0], xmm13
00007a66921dd7d7  vmovaps [rsp+0xD0], xmm14
00007a66921dd7e0  vmovaps [rsp+0xE0], xmm15
00007a66921dd7e9  sub rsp, 0x30
00007a66921dd7ed  movaps [rsp], xmm6
00007a66921dd7f1  movaps [rsp+0x10], xmm9
00007a66921dd7f7  movaps [rsp+0x20], xmm7
00007a66921dd7fc  lea rdi, [rsp]
00007a66921dd800  mov esi, 0x00
00007a66921dd805  mov rax, 0x635346DC7530
00007a66921dd80f  call rax
00007a66921dd811  movaps xmm6, [rsp]
00007a66921dd815  add rsp, 0x30
00007a66921dd819  vmovaps xmm0, [rsp]
00007a66921dd81e  vmovaps xmm1, [rsp+0x10]
00007a66921dd824  vmovaps xmm2, [rsp+0x20]
00007a66921dd82a  vmovaps xmm3, [rsp+0x30]
00007a66921dd830  vmovaps xmm4, [rsp+0x40]
00007a66921dd836  vmovaps xmm5, [rsp+0x50]
00007a66921dd83c  vmovaps xmm7, [rsp+0x60]
00007a66921dd842  vmovaps xmm8, [rsp+0x70]
00007a66921dd848  vmovaps xmm9, [rsp+0x80]
00007a66921dd851  vmovaps xmm10, [rsp+0x90]
00007a66921dd85a  vmovaps xmm11, [rsp+0xA0]
00007a66921dd863  vmovaps xmm12, [rsp+0xB0]
00007a66921dd86c  vmovaps xmm13, [rsp+0xC0]
00007a66921dd875  vmovaps xmm14, [rsp+0xD0]
00007a66921dd87e  vmovaps xmm15, [rsp+0xE0]
00007a66921dd887  add rsp, 0xF0
00007a66921dd88e  pop r11
00007a66921dd890  pop r10
00007a66921dd892  pop r9
00007a66921dd894  pop r8
00007a66921dd896  pop rsi
00007a66921dd897  pop rdi
00007a66921dd898  pop rdx
00007a66921dd899  pop rcx
00007a66921dd89a  pop rax
00007a66921dd89b  add rsp, 0x08
00007a66921dd89f  jmp 0x00007A66921DBE5A
00007a66921dd8a4  sub rsp, 0x08
00007a66921dd8a8  push rax
00007a66921dd8a9  push rcx
00007a66921dd8aa  push rdx
00007a66921dd8ab  push rdi
00007a66921dd8ac  push rsi
00007a66921dd8ad  push r8
00007a66921dd8af  push r9
00007a66921dd8b1  push r10
00007a66921dd8b3  push r11
00007a66921dd8b5  sub rsp, 0xF0
00007a66921dd8bc  vmovaps [rsp], xmm0
00007a66921dd8c1  vmovaps [rsp+0x10], xmm1
00007a66921dd8c7  vmovaps [rsp+0x20], xmm2
00007a66921dd8cd  vmovaps [rsp+0x30], xmm3
00007a66921dd8d3  vmovaps [rsp+0x40], xmm4
00007a66921dd8d9  vmovaps [rsp+0x50], xmm5
00007a66921dd8df  vmovaps [rsp+0x60], xmm6
00007a66921dd8e5  vmovaps [rsp+0x70], xmm8
00007a66921dd8eb  vmovaps [rsp+0x80], xmm9
00007a66921dd8f4  vmovaps [rsp+0x90], xmm10
00007a66921dd8fd  vmovaps [rsp+0xA0], xmm11
00007a66921dd906  vmovaps [rsp+0xB0], xmm12
00007a66921dd90f  vmovaps [rsp+0xC0], xmm13
00007a66921dd918  vmovaps [rsp+0xD0], xmm14
00007a66921dd921  vmovaps [rsp+0xE0], xmm15
00007a66921dd92a  sub rsp, 0x30
00007a66921dd92e  movaps [rsp], xmm7
00007a66921dd932  movaps [rsp+0x10], xmm4
00007a66921dd937  movaps [rsp+0x20], xmm9
00007a66921dd93d  lea rdi, [rsp]
00007a66921dd941  mov esi, 0x00
00007a66921dd946  mov rax, 0x635346DC7530
00007a66921dd950  call rax
00007a66921dd952  movaps xmm7, [rsp]
00007a66921dd956  add rsp, 0x30
00007a66921dd95a  vmovaps xmm0, [rsp]
00007a66921dd95f  vmovaps xmm1, [rsp+0x10]
00007a66921dd965  vmovaps xmm2, [rsp+0x20]
00007a66921dd96b  vmovaps xmm3, [rsp+0x30]
00007a66921dd971  vmovaps xmm4, [rsp+0x40]
00007a66921dd977  vmovaps xmm5, [rsp+0x50]
00007a66921dd97d  vmovaps xmm6, [rsp+0x60]
00007a66921dd983  vmovaps xmm8, [rsp+0x70]
00007a66921dd989  vmovaps xmm9, [rsp+0x80]
00007a66921dd992  vmovaps xmm10, [rsp+0x90]
00007a66921dd99b  vmovaps xmm11, [rsp+0xA0]
00007a66921dd9a4  vmovaps xmm12, [rsp+0xB0]
00007a66921dd9ad  vmovaps xmm13, [rsp+0xC0]
00007a66921dd9b6  vmovaps xmm14, [rsp+0xD0]
00007a66921dd9bf  vmovaps xmm15, [rsp+0xE0]
00007a66921dd9c8  add rsp, 0xF0
00007a66921dd9cf  pop r11
00007a66921dd9d1  pop r10
00007a66921dd9d3  pop r9
00007a66921dd9d5  pop r8
00007a66921dd9d7  pop rsi
00007a66921dd9d8  pop rdi
00007a66921dd9d9  pop rdx
00007a66921dd9da  pop rcx
00007a66921dd9db  pop rax
00007a66921dd9dc  add rsp, 0x08
00007a66921dd9e0  jmp 0x00007A66921DBE87
00007a66921dd9e5  sub rsp, 0x08
00007a66921dd9e9  push rax
00007a66921dd9ea  push rcx
00007a66921dd9eb  push rdx
00007a66921dd9ec  push rdi
00007a66921dd9ed  push rsi
00007a66921dd9ee  push r8
00007a66921dd9f0  push r9
00007a66921dd9f2  push r10
00007a66921dd9f4  push r11
00007a66921dd9f6  sub rsp, 0xF0
00007a66921dd9fd  vmovaps [rsp], xmm0
00007a66921dda02  vmovaps [rsp+0x10], xmm1
00007a66921dda08  vmovaps [rsp+0x20], xmm2
00007a66921dda0e  vmovaps [rsp+0x30], xmm3
00007a66921dda14  vmovaps [rsp+0x40], xmm5
00007a66921dda1a  vmovaps [rsp+0x50], xmm6
00007a66921dda20  vmovaps [rsp+0x60], xmm7
00007a66921dda26  vmovaps [rsp+0x70], xmm8
00007a66921dda2c  vmovaps [rsp+0x80], xmm9
00007a66921dda35  vmovaps [rsp+0x90], xmm10
00007a66921dda3e  vmovaps [rsp+0xA0], xmm11
00007a66921dda47  vmovaps [rsp+0xB0], xmm12
00007a66921dda50  vmovaps [rsp+0xC0], xmm13
00007a66921dda59  vmovaps [rsp+0xD0], xmm14
00007a66921dda62  vmovaps [rsp+0xE0], xmm15
00007a66921dda6b  sub rsp, 0x30
00007a66921dda6f  movaps [rsp], xmm4
00007a66921dda73  movaps [rsp+0x10], xmm15
00007a66921dda79  movaps [rsp+0x20], xmm9
00007a66921dda7f  lea rdi, [rsp]
00007a66921dda83  mov esi, 0x00
00007a66921dda88  mov rax, 0x635346DC7530
00007a66921dda92  call rax
00007a66921dda94  movaps xmm4, [rsp]
00007a66921dda98  add rsp, 0x30
00007a66921dda9c  vmovaps xmm0, [rsp]
00007a66921ddaa1  vmovaps xmm1, [rsp+0x10]
00007a66921ddaa7  vmovaps xmm2, [rsp+0x20]
00007a66921ddaad  vmovaps xmm3, [rsp+0x30]
00007a66921ddab3  vmovaps xmm5, [rsp+0x40]
00007a66921ddab9  vmovaps xmm6, [rsp+0x50]
00007a66921ddabf  vmovaps xmm7, [rsp+0x60]
00007a66921ddac5  vmovaps xmm8, [rsp+0x70]
00007a66921ddacb  vmovaps xmm9, [rsp+0x80]
00007a66921ddad4  vmovaps xmm10, [rsp+0x90]
00007a66921ddadd  vmovaps xmm11, [rsp+0xA0]
00007a66921ddae6  vmovaps xmm12, [rsp+0xB0]
00007a66921ddaef  vmovaps xmm13, [rsp+0xC0]
00007a66921ddaf8  vmovaps xmm14, [rsp+0xD0]
00007a66921ddb01  vmovaps xmm15, [rsp+0xE0]
00007a66921ddb0a  add rsp, 0xF0
00007a66921ddb11  pop r11
00007a66921ddb13  pop r10
00007a66921ddb15  pop r9
00007a66921ddb17  pop r8
00007a66921ddb19  pop rsi
00007a66921ddb1a  pop rdi
00007a66921ddb1b  pop rdx
00007a66921ddb1c  pop rcx
00007a66921ddb1d  pop rax
00007a66921ddb1e  add rsp, 0x08
00007a66921ddb22  jmp 0x00007A66921DBEAC
00007a66921ddb27  call 0x00007A66920C4620
00007a66921ddb2c  jmp 0x00007A66921DBEB9
00007a66921ddb31  sub rsp, 0x08
00007a66921ddb35  push rax
00007a66921ddb36  push rcx
00007a66921ddb37  push rdx
00007a66921ddb38  push rdi
00007a66921ddb39  push rsi
00007a66921ddb3a  push r8
00007a66921ddb3c  push r9
00007a66921ddb3e  push r10
00007a66921ddb40  push r11
00007a66921ddb42  sub rsp, 0xF0
00007a66921ddb49  vmovaps [rsp], xmm0
00007a66921ddb4e  vmovaps [rsp+0x10], xmm1
00007a66921ddb54  vmovaps [rsp+0x20], xmm2
00007a66921ddb5a  vmovaps [rsp+0x30], xmm4
00007a66921ddb60  vmovaps [rsp+0x40], xmm5
00007a66921ddb66  vmovaps [rsp+0x50], xmm6
00007a66921ddb6c  vmovaps [rsp+0x60], xmm7
00007a66921ddb72  vmovaps [rsp+0x70], xmm8
00007a66921ddb78  vmovaps [rsp+0x80], xmm9
00007a66921ddb81  vmovaps [rsp+0x90], xmm10
00007a66921ddb8a  vmovaps [rsp+0xA0], xmm11
00007a66921ddb93  vmovaps [rsp+0xB0], xmm12
00007a66921ddb9c  vmovaps [rsp+0xC0], xmm13
00007a66921ddba5  vmovaps [rsp+0xD0], xmm14
00007a66921ddbae  vmovaps [rsp+0xE0], xmm15
00007a66921ddbb7  sub rsp, 0x30
00007a66921ddbbb  movaps [rsp], xmm3
00007a66921ddbbf  movaps [rsp+0x10], xmm1
00007a66921ddbc4  movaps [rsp+0x20], xmm9
00007a66921ddbca  lea rdi, [rsp]
00007a66921ddbce  mov esi, 0x00
00007a66921ddbd3  mov rax, 0x635346DC7530
00007a66921ddbdd  call rax
00007a66921ddbdf  movaps xmm3, [rsp]
00007a66921ddbe3  add rsp, 0x30
00007a66921ddbe7  vmovaps xmm0, [rsp]
00007a66921ddbec  vmovaps xmm1, [rsp+0x10]
00007a66921ddbf2  vmovaps xmm2, [rsp+0x20]
00007a66921ddbf8  vmovaps xmm4, [rsp+0x30]
00007a66921ddbfe  vmovaps xmm5, [rsp+0x40]
00007a66921ddc04  vmovaps xmm6, [rsp+0x50]
00007a66921ddc0a  vmovaps xmm7, [rsp+0x60]
00007a66921ddc10  vmovaps xmm8, [rsp+0x70]
00007a66921ddc16  vmovaps xmm9, [rsp+0x80]
00007a66921ddc1f  vmovaps xmm10, [rsp+0x90]
00007a66921ddc28  vmovaps xmm11, [rsp+0xA0]
00007a66921ddc31  vmovaps xmm12, [rsp+0xB0]
00007a66921ddc3a  vmovaps xmm13, [rsp+0xC0]
00007a66921ddc43  vmovaps xmm14, [rsp+0xD0]
00007a66921ddc4c  vmovaps xmm15, [rsp+0xE0]
00007a66921ddc55  add rsp, 0xF0
00007a66921ddc5c  pop r11
00007a66921ddc5e  pop r10
00007a66921ddc60  pop r9
00007a66921ddc62  pop r8
00007a66921ddc64  pop rsi
00007a66921ddc65  pop rdi
00007a66921ddc66  pop rdx
00007a66921ddc67  pop rcx
00007a66921ddc68  pop rax
00007a66921ddc69  add rsp, 0x08
00007a66921ddc6d  jmp 0x00007A66921DBEF6
00007a66921ddc72  sub rsp, 0x08
00007a66921ddc76  push rax
00007a66921ddc77  push rcx
00007a66921ddc78  push rdx
00007a66921ddc79  push rdi
00007a66921ddc7a  push rsi
00007a66921ddc7b  push r8
00007a66921ddc7d  push r9
00007a66921ddc7f  push r10
00007a66921ddc81  push r11
00007a66921ddc83  sub rsp, 0xF0
00007a66921ddc8a  vmovaps [rsp], xmm0
00007a66921ddc8f  vmovaps [rsp+0x10], xmm2
00007a66921ddc95  vmovaps [rsp+0x20], xmm3
00007a66921ddc9b  vmovaps [rsp+0x30], xmm4
00007a66921ddca1  vmovaps [rsp+0x40], xmm5
00007a66921ddca7  vmovaps [rsp+0x50], xmm6
00007a66921ddcad  vmovaps [rsp+0x60], xmm7
00007a66921ddcb3  vmovaps [rsp+0x70], xmm8
00007a66921ddcb9  vmovaps [rsp+0x80], xmm9
00007a66921ddcc2  vmovaps [rsp+0x90], xmm10
00007a66921ddccb  vmovaps [rsp+0xA0], xmm11
00007a66921ddcd4  vmovaps [rsp+0xB0], xmm12
00007a66921ddcdd  vmovaps [rsp+0xC0], xmm13
00007a66921ddce6  vmovaps [rsp+0xD0], xmm14
00007a66921ddcef  vmovaps [rsp+0xE0], xmm15
00007a66921ddcf8  sub rsp, 0x30
00007a66921ddcfc  movaps [rsp], xmm1
00007a66921ddd00  movaps [rsp+0x10], xmm15
00007a66921ddd06  movaps [rsp+0x20], xmm9
00007a66921ddd0c  lea rdi, [rsp]
00007a66921ddd10  mov esi, 0x00
00007a66921ddd15  mov rax, 0x635346DC7530
00007a66921ddd1f  call rax
00007a66921ddd21  movaps xmm1, [rsp]
00007a66921ddd25  add rsp, 0x30
00007a66921ddd29  vmovaps xmm0, [rsp]
00007a66921ddd2e  vmovaps xmm2, [rsp+0x10]
00007a66921ddd34  vmovaps xmm3, [rsp+0x20]
00007a66921ddd3a  vmovaps xmm4, [rsp+0x30]
00007a66921ddd40  vmovaps xmm5, [rsp+0x40]
00007a66921ddd46  vmovaps xmm6, [rsp+0x50]
00007a66921ddd4c  vmovaps xmm7, [rsp+0x60]
00007a66921ddd52  vmovaps xmm8, [rsp+0x70]
00007a66921ddd58  vmovaps xmm9, [rsp+0x80]
00007a66921ddd61  vmovaps xmm10, [rsp+0x90]
00007a66921ddd6a  vmovaps xmm11, [rsp+0xA0]
00007a66921ddd73  vmovaps xmm12, [rsp+0xB0]
00007a66921ddd7c  vmovaps xmm13, [rsp+0xC0]
00007a66921ddd85  vmovaps xmm14, [rsp+0xD0]
00007a66921ddd8e  vmovaps xmm15, [rsp+0xE0]
00007a66921ddd97  add rsp, 0xF0
00007a66921ddd9e  pop r11
00007a66921ddda0  pop r10
00007a66921ddda2  pop r9
00007a66921ddda4  pop r8
00007a66921ddda6  pop rsi
00007a66921ddda7  pop rdi
00007a66921ddda8  pop rdx
00007a66921ddda9  pop rcx
00007a66921dddaa  pop rax
00007a66921dddab  add rsp, 0x08
00007a66921dddaf  jmp 0x00007A66921DBF7E
00007a66921dddb4  call 0x00007A66920C4620
00007a66921dddb9  jmp 0x00007A66921DBF8B
00007a66921dddbe  sub rsp, 0x08
00007a66921dddc2  push rax
00007a66921dddc3  push rcx
00007a66921dddc4  push rdx
00007a66921dddc5  push rdi
00007a66921dddc6  push rsi
00007a66921dddc7  push r8
00007a66921dddc9  push r9
00007a66921dddcb  push r10
00007a66921dddcd  push r11
00007a66921dddcf  sub rsp, 0xF0
00007a66921dddd6  vmovaps [rsp], xmm0
00007a66921ddddb  vmovaps [rsp+0x10], xmm2
00007a66921ddde1  vmovaps [rsp+0x20], xmm3
00007a66921ddde7  vmovaps [rsp+0x30], xmm4
00007a66921ddded  vmovaps [rsp+0x40], xmm5
00007a66921dddf3  vmovaps [rsp+0x50], xmm6
00007a66921dddf9  vmovaps [rsp+0x60], xmm7
00007a66921dddff  vmovaps [rsp+0x70], xmm8
00007a66921dde05  vmovaps [rsp+0x80], xmm9
00007a66921dde0e  vmovaps [rsp+0x90], xmm10
00007a66921dde17  vmovaps [rsp+0xA0], xmm11
00007a66921dde20  vmovaps [rsp+0xB0], xmm12
00007a66921dde29  vmovaps [rsp+0xC0], xmm13
00007a66921dde32  vmovaps [rsp+0xD0], xmm14
00007a66921dde3b  vmovaps [rsp+0xE0], xmm15
00007a66921dde44  sub rsp, 0x30
00007a66921dde48  movaps [rsp], xmm1
00007a66921dde4c  movaps [rsp+0x10], xmm5
00007a66921dde51  movaps [rsp+0x20], xmm7
00007a66921dde56  lea rdi, [rsp]
00007a66921dde5a  mov esi, 0x00
00007a66921dde5f  mov rax, 0x635346DC7530
00007a66921dde69  call rax
00007a66921dde6b  movaps xmm1, [rsp]
00007a66921dde6f  add rsp, 0x30
00007a66921dde73  vmovaps xmm0, [rsp]
00007a66921dde78  vmovaps xmm2, [rsp+0x10]
00007a66921dde7e  vmovaps xmm3, [rsp+0x20]
00007a66921dde84  vmovaps xmm4, [rsp+0x30]
00007a66921dde8a  vmovaps xmm5, [rsp+0x40]
00007a66921dde90  vmovaps xmm6, [rsp+0x50]
00007a66921dde96  vmovaps xmm7, [rsp+0x60]
00007a66921dde9c  vmovaps xmm8, [rsp+0x70]
00007a66921ddea2  vmovaps xmm9, [rsp+0x80]
00007a66921ddeab  vmovaps xmm10, [rsp+0x90]
00007a66921ddeb4  vmovaps xmm11, [rsp+0xA0]
00007a66921ddebd  vmovaps xmm12, [rsp+0xB0]
00007a66921ddec6  vmovaps xmm13, [rsp+0xC0]
00007a66921ddecf  vmovaps xmm14, [rsp+0xD0]
00007a66921dded8  vmovaps xmm15, [rsp+0xE0]
00007a66921ddee1  add rsp, 0xF0
00007a66921ddee8  pop r11
00007a66921ddeea  pop r10
00007a66921ddeec  pop r9
00007a66921ddeee  pop r8
00007a66921ddef0  pop rsi
00007a66921ddef1  pop rdi
00007a66921ddef2  pop rdx
00007a66921ddef3  pop rcx
00007a66921ddef4  pop rax
00007a66921ddef5  add rsp, 0x08
00007a66921ddef9  jmp 0x00007A66921DC030
00007a66921ddefe  sub rsp, 0x08
00007a66921ddf02  push rax
00007a66921ddf03  push rcx
00007a66921ddf04  push rdx
00007a66921ddf05  push rdi
00007a66921ddf06  push rsi
00007a66921ddf07  push r8
00007a66921ddf09  push r9
00007a66921ddf0b  push r10
00007a66921ddf0d  push r11
00007a66921ddf0f  sub rsp, 0xF0
00007a66921ddf16  vmovaps [rsp], xmm0
00007a66921ddf1b  vmovaps [rsp+0x10], xmm1
00007a66921ddf21  vmovaps [rsp+0x20], xmm2
00007a66921ddf27  vmovaps [rsp+0x30], xmm3
00007a66921ddf2d  vmovaps [rsp+0x40], xmm4
00007a66921ddf33  vmovaps [rsp+0x50], xmm5
00007a66921ddf39  vmovaps [rsp+0x60], xmm6
00007a66921ddf3f  vmovaps [rsp+0x70], xmm8
00007a66921ddf45  vmovaps [rsp+0x80], xmm9
00007a66921ddf4e  vmovaps [rsp+0x90], xmm10
00007a66921ddf57  vmovaps [rsp+0xA0], xmm11
00007a66921ddf60  vmovaps [rsp+0xB0], xmm12
00007a66921ddf69  vmovaps [rsp+0xC0], xmm13
00007a66921ddf72  vmovaps [rsp+0xD0], xmm14
00007a66921ddf7b  vmovaps [rsp+0xE0], xmm15
00007a66921ddf84  sub rsp, 0x30
00007a66921ddf88  movaps [rsp], xmm7
00007a66921ddf8c  movaps [rsp+0x10], xmm5
00007a66921ddf91  movaps [rsp+0x20], xmm15
00007a66921ddf97  lea rdi, [rsp]
00007a66921ddf9b  mov esi, 0x00
00007a66921ddfa0  mov rax, 0x635346DC7530
00007a66921ddfaa  call rax
00007a66921ddfac  movaps xmm7, [rsp]
00007a66921ddfb0  add rsp, 0x30
00007a66921ddfb4  vmovaps xmm0, [rsp]
00007a66921ddfb9  vmovaps xmm1, [rsp+0x10]
00007a66921ddfbf  vmovaps xmm2, [rsp+0x20]
00007a66921ddfc5  vmovaps xmm3, [rsp+0x30]
00007a66921ddfcb  vmovaps xmm4, [rsp+0x40]
00007a66921ddfd1  vmovaps xmm5, [rsp+0x50]
00007a66921ddfd7  vmovaps xmm6, [rsp+0x60]
00007a66921ddfdd  vmovaps xmm8, [rsp+0x70]
00007a66921ddfe3  vmovaps xmm9, [rsp+0x80]
00007a66921ddfec  vmovaps xmm10, [rsp+0x90]
00007a66921ddff5  vmovaps xmm11, [rsp+0xA0]
00007a66921ddffe  vmovaps xmm12, [rsp+0xB0]
00007a66921de007  vmovaps xmm13, [rsp+0xC0]
00007a66921de010  vmovaps xmm14, [rsp+0xD0]
00007a66921de019  vmovaps xmm15, [rsp+0xE0]
00007a66921de022  add rsp, 0xF0
00007a66921de029  pop r11
00007a66921de02b  pop r10
00007a66921de02d  pop r9
00007a66921de02f  pop r8
00007a66921de031  pop rsi
00007a66921de032  pop rdi
00007a66921de033  pop rdx
00007a66921de034  pop rcx
00007a66921de035  pop rax
00007a66921de036  add rsp, 0x08
00007a66921de03a  jmp 0x00007A66921DC066
00007a66921de03f  call 0x00007A66920B52F0
00007a66921de044  jmp 0x00007A66921DC073
00007a66921de049  sub rsp, 0x08
00007a66921de04d  push rax
00007a66921de04e  push rcx
00007a66921de04f  push rdx
00007a66921de050  push rdi
00007a66921de051  push rsi
00007a66921de052  push r8
00007a66921de054  push r9
00007a66921de056  push r10
00007a66921de058  push r11
00007a66921de05a  sub rsp, 0xF0
00007a66921de061  vmovaps [rsp], xmm0
00007a66921de066  vmovaps [rsp+0x10], xmm1
00007a66921de06c  vmovaps [rsp+0x20], xmm2
00007a66921de072  vmovaps [rsp+0x30], xmm3
00007a66921de078  vmovaps [rsp+0x40], xmm4
00007a66921de07e  vmovaps [rsp+0x50], xmm5
00007a66921de084  vmovaps [rsp+0x60], xmm6
00007a66921de08a  vmovaps [rsp+0x70], xmm7
00007a66921de090  vmovaps [rsp+0x80], xmm8
00007a66921de099  vmovaps [rsp+0x90], xmm9
00007a66921de0a2  vmovaps [rsp+0xA0], xmm10
00007a66921de0ab  vmovaps [rsp+0xB0], xmm11
00007a66921de0b4  vmovaps [rsp+0xC0], xmm12
00007a66921de0bd  vmovaps [rsp+0xD0], xmm13
00007a66921de0c6  vmovaps [rsp+0xE0], xmm14
00007a66921de0cf  sub rsp, 0x30
00007a66921de0d3  movaps [rsp], xmm15
00007a66921de0d8  movaps [rsp+0x10], xmm5
00007a66921de0dd  movaps [rsp+0x20], xmm3
00007a66921de0e2  lea rdi, [rsp]
00007a66921de0e6  mov esi, 0x00
00007a66921de0eb  mov rax, 0x635346DC7530
00007a66921de0f5  call rax
00007a66921de0f7  movaps xmm15, [rsp]
00007a66921de0fc  add rsp, 0x30
00007a66921de100  vmovaps xmm0, [rsp]
00007a66921de105  vmovaps xmm1, [rsp+0x10]
00007a66921de10b  vmovaps xmm2, [rsp+0x20]
00007a66921de111  vmovaps xmm3, [rsp+0x30]
00007a66921de117  vmovaps xmm4, [rsp+0x40]
00007a66921de11d  vmovaps xmm5, [rsp+0x50]
00007a66921de123  vmovaps xmm6, [rsp+0x60]
00007a66921de129  vmovaps xmm7, [rsp+0x70]
00007a66921de12f  vmovaps xmm8, [rsp+0x80]
00007a66921de138  vmovaps xmm9, [rsp+0x90]
00007a66921de141  vmovaps xmm10, [rsp+0xA0]
00007a66921de14a  vmovaps xmm11, [rsp+0xB0]
00007a66921de153  vmovaps xmm12, [rsp+0xC0]
00007a66921de15c  vmovaps xmm13, [rsp+0xD0]
00007a66921de165  vmovaps xmm14, [rsp+0xE0]
00007a66921de16e  add rsp, 0xF0
00007a66921de175  pop r11
00007a66921de177  pop r10
00007a66921de179  pop r9
00007a66921de17b  pop r8
00007a66921de17d  pop rsi
00007a66921de17e  pop rdi
00007a66921de17f  pop rdx
00007a66921de180  pop rcx
00007a66921de181  pop rax
00007a66921de182  add rsp, 0x08
00007a66921de186  jmp 0x00007A66921DC099
00007a66921de18b  sub rsp, 0x08
00007a66921de18f  push rax
00007a66921de190  push rcx
00007a66921de191  push rdx
00007a66921de192  push rdi
00007a66921de193  push rsi
00007a66921de194  push r8
00007a66921de196  push r9
00007a66921de198  push r10
00007a66921de19a  push r11
00007a66921de19c  sub rsp, 0xF0
00007a66921de1a3  vmovaps [rsp], xmm0
00007a66921de1a8  vmovaps [rsp+0x10], xmm2
00007a66921de1ae  vmovaps [rsp+0x20], xmm3
00007a66921de1b4  vmovaps [rsp+0x30], xmm4
00007a66921de1ba  vmovaps [rsp+0x40], xmm5
00007a66921de1c0  vmovaps [rsp+0x50], xmm6
00007a66921de1c6  vmovaps [rsp+0x60], xmm7
00007a66921de1cc  vmovaps [rsp+0x70], xmm8
00007a66921de1d2  vmovaps [rsp+0x80], xmm9
00007a66921de1db  vmovaps [rsp+0x90], xmm10
00007a66921de1e4  vmovaps [rsp+0xA0], xmm11
00007a66921de1ed  vmovaps [rsp+0xB0], xmm12
00007a66921de1f6  vmovaps [rsp+0xC0], xmm13
00007a66921de1ff  vmovaps [rsp+0xD0], xmm14
00007a66921de208  vmovaps [rsp+0xE0], xmm15
00007a66921de211  sub rsp, 0x30
00007a66921de215  movaps [rsp], xmm1
00007a66921de219  movaps [rsp+0x10], xmm5
00007a66921de21e  movaps [rsp+0x20], xmm4
00007a66921de223  lea rdi, [rsp]
00007a66921de227  mov esi, 0x00
00007a66921de22c  mov rax, 0x635346DC7530
00007a66921de236  call rax
00007a66921de238  movaps xmm1, [rsp]
00007a66921de23c  add rsp, 0x30
00007a66921de240  vmovaps xmm0, [rsp]
00007a66921de245  vmovaps xmm2, [rsp+0x10]
00007a66921de24b  vmovaps xmm3, [rsp+0x20]
00007a66921de251  vmovaps xmm4, [rsp+0x30]
00007a66921de257  vmovaps xmm5, [rsp+0x40]
00007a66921de25d  vmovaps xmm6, [rsp+0x50]
00007a66921de263  vmovaps xmm7, [rsp+0x60]
00007a66921de269  vmovaps xmm8, [rsp+0x70]
00007a66921de26f  vmovaps xmm9, [rsp+0x80]
00007a66921de278  vmovaps xmm10, [rsp+0x90]
00007a66921de281  vmovaps xmm11, [rsp+0xA0]
00007a66921de28a  vmovaps xmm12, [rsp+0xB0]
00007a66921de293  vmovaps xmm13, [rsp+0xC0]
00007a66921de29c  vmovaps xmm14, [rsp+0xD0]
00007a66921de2a5  vmovaps xmm15, [rsp+0xE0]
00007a66921de2ae  add rsp, 0xF0
00007a66921de2b5  pop r11
00007a66921de2b7  pop r10
00007a66921de2b9  pop r9
00007a66921de2bb  pop r8
00007a66921de2bd  pop rsi
00007a66921de2be  pop rdi
00007a66921de2bf  pop rdx
00007a66921de2c0  pop rcx
00007a66921de2c1  pop rax
00007a66921de2c2  add rsp, 0x08
00007a66921de2c6  jmp 0x00007A66921DC0B9
00007a66921de2cb  sub rsp, 0x08
00007a66921de2cf  push rax
00007a66921de2d0  push rcx
00007a66921de2d1  push rdx
00007a66921de2d2  push rdi
00007a66921de2d3  push rsi
00007a66921de2d4  push r8
00007a66921de2d6  push r9
00007a66921de2d8  push r10
00007a66921de2da  push r11
00007a66921de2dc  sub rsp, 0xF0
00007a66921de2e3  vmovaps [rsp], xmm0
00007a66921de2e8  vmovaps [rsp+0x10], xmm1
00007a66921de2ee  vmovaps [rsp+0x20], xmm2
00007a66921de2f4  vmovaps [rsp+0x30], xmm3
00007a66921de2fa  vmovaps [rsp+0x40], xmm5
00007a66921de300  vmovaps [rsp+0x50], xmm6
00007a66921de306  vmovaps [rsp+0x60], xmm7
00007a66921de30c  vmovaps [rsp+0x70], xmm8
00007a66921de312  vmovaps [rsp+0x80], xmm9
00007a66921de31b  vmovaps [rsp+0x90], xmm10
00007a66921de324  vmovaps [rsp+0xA0], xmm11
00007a66921de32d  vmovaps [rsp+0xB0], xmm12
00007a66921de336  vmovaps [rsp+0xC0], xmm13
00007a66921de33f  vmovaps [rsp+0xD0], xmm14
00007a66921de348  vmovaps [rsp+0xE0], xmm15
00007a66921de351  sub rsp, 0x30
00007a66921de355  movaps [rsp], xmm4
00007a66921de359  movaps [rsp+0x10], xmm3
00007a66921de35e  movaps [rsp+0x20], xmm5
00007a66921de363  lea rdi, [rsp]
00007a66921de367  mov esi, 0x00
00007a66921de36c  mov rax, 0x635346DC7530
00007a66921de376  call rax
00007a66921de378  movaps xmm4, [rsp]
00007a66921de37c  add rsp, 0x30
00007a66921de380  vmovaps xmm0, [rsp]
00007a66921de385  vmovaps xmm1, [rsp+0x10]
00007a66921de38b  vmovaps xmm2, [rsp+0x20]
00007a66921de391  vmovaps xmm3, [rsp+0x30]
00007a66921de397  vmovaps xmm5, [rsp+0x40]
00007a66921de39d  vmovaps xmm6, [rsp+0x50]
00007a66921de3a3  vmovaps xmm7, [rsp+0x60]
00007a66921de3a9  vmovaps xmm8, [rsp+0x70]
00007a66921de3af  vmovaps xmm9, [rsp+0x80]
00007a66921de3b8  vmovaps xmm10, [rsp+0x90]
00007a66921de3c1  vmovaps xmm11, [rsp+0xA0]
00007a66921de3ca  vmovaps xmm12, [rsp+0xB0]
00007a66921de3d3  vmovaps xmm13, [rsp+0xC0]
00007a66921de3dc  vmovaps xmm14, [rsp+0xD0]
00007a66921de3e5  vmovaps xmm15, [rsp+0xE0]
00007a66921de3ee  add rsp, 0xF0
00007a66921de3f5  pop r11
00007a66921de3f7  pop r10
00007a66921de3f9  pop r9
00007a66921de3fb  pop r8
00007a66921de3fd  pop rsi
00007a66921de3fe  pop rdi
00007a66921de3ff  pop rdx
00007a66921de400  pop rcx
00007a66921de401  pop rax
00007a66921de402  add rsp, 0x08
00007a66921de406  jmp 0x00007A66921DC107
00007a66921de40b  call 0x00007A66920B52F0
00007a66921de410  jmp 0x00007A66921DC114
00007a66921de415  sub rsp, 0x08
00007a66921de419  push rax
00007a66921de41a  push rcx
00007a66921de41b  push rdx
00007a66921de41c  push rdi
00007a66921de41d  push rsi
00007a66921de41e  push r8
00007a66921de420  push r9
00007a66921de422  push r10
00007a66921de424  push r11
00007a66921de426  sub rsp, 0xF0
00007a66921de42d  vmovaps [rsp], xmm0
00007a66921de432  vmovaps [rsp+0x10], xmm1
00007a66921de438  vmovaps [rsp+0x20], xmm2
00007a66921de43e  vmovaps [rsp+0x30], xmm3
00007a66921de444  vmovaps [rsp+0x40], xmm4
00007a66921de44a  vmovaps [rsp+0x50], xmm6
00007a66921de450  vmovaps [rsp+0x60], xmm7
00007a66921de456  vmovaps [rsp+0x70], xmm8
00007a66921de45c  vmovaps [rsp+0x80], xmm9
00007a66921de465  vmovaps [rsp+0x90], xmm10
00007a66921de46e  vmovaps [rsp+0xA0], xmm11
00007a66921de477  vmovaps [rsp+0xB0], xmm12
00007a66921de480  vmovaps [rsp+0xC0], xmm13
00007a66921de489  vmovaps [rsp+0xD0], xmm14
00007a66921de492  vmovaps [rsp+0xE0], xmm15
00007a66921de49b  sub rsp, 0x30
00007a66921de49f  movaps [rsp], xmm5
00007a66921de4a3  movaps [rsp+0x10], xmm6
00007a66921de4a8  movaps [rsp+0x20], xmm3
00007a66921de4ad  lea rdi, [rsp]
00007a66921de4b1  mov esi, 0x00
00007a66921de4b6  mov rax, 0x635346DC7530
00007a66921de4c0  call rax
00007a66921de4c2  movaps xmm5, [rsp]
00007a66921de4c6  add rsp, 0x30
00007a66921de4ca  vmovaps xmm0, [rsp]
00007a66921de4cf  vmovaps xmm1, [rsp+0x10]
00007a66921de4d5  vmovaps xmm2, [rsp+0x20]
00007a66921de4db  vmovaps xmm3, [rsp+0x30]
00007a66921de4e1  vmovaps xmm4, [rsp+0x40]
00007a66921de4e7  vmovaps xmm6, [rsp+0x50]
00007a66921de4ed  vmovaps xmm7, [rsp+0x60]
00007a66921de4f3  vmovaps xmm8, [rsp+0x70]
00007a66921de4f9  vmovaps xmm9, [rsp+0x80]
00007a66921de502  vmovaps xmm10, [rsp+0x90]
00007a66921de50b  vmovaps xmm11, [rsp+0xA0]
00007a66921de514  vmovaps xmm12, [rsp+0xB0]
00007a66921de51d  vmovaps xmm13, [rsp+0xC0]
00007a66921de526  vmovaps xmm14, [rsp+0xD0]
00007a66921de52f  vmovaps xmm15, [rsp+0xE0]
00007a66921de538  add rsp, 0xF0
00007a66921de53f  pop r11
00007a66921de541  pop r10
00007a66921de543  pop r9
00007a66921de545  pop r8
00007a66921de547  pop rsi
00007a66921de548  pop rdi
00007a66921de549  pop rdx
00007a66921de54a  pop rcx
00007a66921de54b  pop rax
00007a66921de54c  add rsp, 0x08
00007a66921de550  jmp 0x00007A66921DC13A
00007a66921de555  sub rsp, 0x08
00007a66921de559  push rax
00007a66921de55a  push rcx
00007a66921de55b  push rdx
00007a66921de55c  push rdi
00007a66921de55d  push rsi
00007a66921de55e  push r8
00007a66921de560  push r9
00007a66921de562  push r10
00007a66921de564  push r11
00007a66921de566  sub rsp, 0xF0
00007a66921de56d  vmovaps [rsp], xmm0
00007a66921de572  vmovaps [rsp+0x10], xmm1
00007a66921de578  vmovaps [rsp+0x20], xmm2
00007a66921de57e  vmovaps [rsp+0x30], xmm3
00007a66921de584  vmovaps [rsp+0x40], xmm4
00007a66921de58a  vmovaps [rsp+0x50], xmm5
00007a66921de590  vmovaps [rsp+0x60], xmm7
00007a66921de596  vmovaps [rsp+0x70], xmm8
00007a66921de59c  vmovaps [rsp+0x80], xmm9
00007a66921de5a5  vmovaps [rsp+0x90], xmm10
00007a66921de5ae  vmovaps [rsp+0xA0], xmm11
00007a66921de5b7  vmovaps [rsp+0xB0], xmm12
00007a66921de5c0  vmovaps [rsp+0xC0], xmm13
00007a66921de5c9  vmovaps [rsp+0xD0], xmm14
00007a66921de5d2  vmovaps [rsp+0xE0], xmm15
00007a66921de5db  sub rsp, 0x30
00007a66921de5df  movaps [rsp], xmm6
00007a66921de5e3  movaps [rsp+0x10], xmm9
00007a66921de5e9  movaps [rsp+0x20], xmm1
00007a66921de5ee  lea rdi, [rsp]
00007a66921de5f2  mov esi, 0x00
00007a66921de5f7  mov rax, 0x635346DC7530
00007a66921de601  call rax
00007a66921de603  movaps xmm6, [rsp]
00007a66921de607  add rsp, 0x30
00007a66921de60b  vmovaps xmm0, [rsp]
00007a66921de610  vmovaps xmm1, [rsp+0x10]
00007a66921de616  vmovaps xmm2, [rsp+0x20]
00007a66921de61c  vmovaps xmm3, [rsp+0x30]
00007a66921de622  vmovaps xmm4, [rsp+0x40]
00007a66921de628  vmovaps xmm5, [rsp+0x50]
00007a66921de62e  vmovaps xmm7, [rsp+0x60]
00007a66921de634  vmovaps xmm8, [rsp+0x70]
00007a66921de63a  vmovaps xmm9, [rsp+0x80]
00007a66921de643  vmovaps xmm10, [rsp+0x90]
00007a66921de64c  vmovaps xmm11, [rsp+0xA0]
00007a66921de655  vmovaps xmm12, [rsp+0xB0]
00007a66921de65e  vmovaps xmm13, [rsp+0xC0]
00007a66921de667  vmovaps xmm14, [rsp+0xD0]
00007a66921de670  vmovaps xmm15, [rsp+0xE0]
00007a66921de679  add rsp, 0xF0
00007a66921de680  pop r11
00007a66921de682  pop r10
00007a66921de684  pop r9
00007a66921de686  pop r8
00007a66921de688  pop rsi
00007a66921de689  pop rdi
00007a66921de68a  pop rdx
00007a66921de68b  pop rcx
00007a66921de68c  pop rax
00007a66921de68d  add rsp, 0x08
00007a66921de691  jmp 0x00007A66921DC15E
00007a66921de696  sub rsp, 0x08
00007a66921de69a  push rax
00007a66921de69b  push rcx
00007a66921de69c  push rdx
00007a66921de69d  push rdi
00007a66921de69e  push rsi
00007a66921de69f  push r8
00007a66921de6a1  push r9
00007a66921de6a3  push r10
00007a66921de6a5  push r11
00007a66921de6a7  sub rsp, 0xF0
00007a66921de6ae  vmovaps [rsp], xmm0
00007a66921de6b3  vmovaps [rsp+0x10], xmm1
00007a66921de6b9  vmovaps [rsp+0x20], xmm2
00007a66921de6bf  vmovaps [rsp+0x30], xmm3
00007a66921de6c5  vmovaps [rsp+0x40], xmm4
00007a66921de6cb  vmovaps [rsp+0x50], xmm5
00007a66921de6d1  vmovaps [rsp+0x60], xmm6
00007a66921de6d7  vmovaps [rsp+0x70], xmm7
00007a66921de6dd  vmovaps [rsp+0x80], xmm8
00007a66921de6e6  vmovaps [rsp+0x90], xmm10
00007a66921de6ef  vmovaps [rsp+0xA0], xmm11
00007a66921de6f8  vmovaps [rsp+0xB0], xmm12
00007a66921de701  vmovaps [rsp+0xC0], xmm13
00007a66921de70a  vmovaps [rsp+0xD0], xmm14
00007a66921de713  vmovaps [rsp+0xE0], xmm15
00007a66921de71c  sub rsp, 0x30
00007a66921de720  movaps [rsp], xmm9
00007a66921de725  movaps [rsp+0x10], xmm3
00007a66921de72a  movaps [rsp+0x20], xmm1
00007a66921de72f  lea rdi, [rsp]
00007a66921de733  mov esi, 0x00
00007a66921de738  mov rax, 0x635346DC7530
00007a66921de742  call rax
00007a66921de744  movaps xmm9, [rsp]
00007a66921de749  add rsp, 0x30
00007a66921de74d  vmovaps xmm0, [rsp]
00007a66921de752  vmovaps xmm1, [rsp+0x10]
00007a66921de758  vmovaps xmm2, [rsp+0x20]
00007a66921de75e  vmovaps xmm3, [rsp+0x30]
00007a66921de764  vmovaps xmm4, [rsp+0x40]
00007a66921de76a  vmovaps xmm5, [rsp+0x50]
00007a66921de770  vmovaps xmm6, [rsp+0x60]
00007a66921de776  vmovaps xmm7, [rsp+0x70]
00007a66921de77c  vmovaps xmm8, [rsp+0x80]
00007a66921de785  vmovaps xmm10, [rsp+0x90]
00007a66921de78e  vmovaps xmm11, [rsp+0xA0]
00007a66921de797  vmovaps xmm12, [rsp+0xB0]
00007a66921de7a0  vmovaps xmm13, [rsp+0xC0]
00007a66921de7a9  vmovaps xmm14, [rsp+0xD0]
00007a66921de7b2  vmovaps xmm15, [rsp+0xE0]
00007a66921de7bb  add rsp, 0xF0
00007a66921de7c2  pop r11
00007a66921de7c4  pop r10
00007a66921de7c6  pop r9
00007a66921de7c8  pop r8
00007a66921de7ca  pop rsi
00007a66921de7cb  pop rdi
00007a66921de7cc  pop rdx
00007a66921de7cd  pop rcx
00007a66921de7ce  pop rax
00007a66921de7cf  add rsp, 0x08
00007a66921de7d3  jmp 0x00007A66921DC1AA
00007a66921de7d8  call 0x00007A66920B52F0
00007a66921de7dd  jmp 0x00007A66921DC1B7
00007a66921de7e2  sub rsp, 0x08
00007a66921de7e6  push rax
00007a66921de7e7  push rcx
00007a66921de7e8  push rdx
00007a66921de7e9  push rdi
00007a66921de7ea  push rsi
00007a66921de7eb  push r8
00007a66921de7ed  push r9
00007a66921de7ef  push r10
00007a66921de7f1  push r11
00007a66921de7f3  sub rsp, 0xF0
00007a66921de7fa  vmovaps [rsp], xmm0
00007a66921de7ff  vmovaps [rsp+0x10], xmm1
00007a66921de805  vmovaps [rsp+0x20], xmm2
00007a66921de80b  vmovaps [rsp+0x30], xmm3
00007a66921de811  vmovaps [rsp+0x40], xmm4
00007a66921de817  vmovaps [rsp+0x50], xmm5
00007a66921de81d  vmovaps [rsp+0x60], xmm6
00007a66921de823  vmovaps [rsp+0x70], xmm7
00007a66921de829  vmovaps [rsp+0x80], xmm8
00007a66921de832  vmovaps [rsp+0x90], xmm9
00007a66921de83b  vmovaps [rsp+0xA0], xmm10
00007a66921de844  vmovaps [rsp+0xB0], xmm11
00007a66921de84d  vmovaps [rsp+0xC0], xmm12
00007a66921de856  vmovaps [rsp+0xD0], xmm13
00007a66921de85f  vmovaps [rsp+0xE0], xmm14
00007a66921de868  sub rsp, 0x30
00007a66921de86c  movaps [rsp], xmm15
00007a66921de871  movaps [rsp+0x10], xmm3
00007a66921de876  movaps [rsp+0x20], xmm7
00007a66921de87b  lea rdi, [rsp]
00007a66921de87f  mov esi, 0x00
00007a66921de884  mov rax, 0x635346DC7530
00007a66921de88e  call rax
00007a66921de890  movaps xmm15, [rsp]
00007a66921de895  add rsp, 0x30
00007a66921de899  vmovaps xmm0, [rsp]
00007a66921de89e  vmovaps xmm1, [rsp+0x10]
00007a66921de8a4  vmovaps xmm2, [rsp+0x20]
00007a66921de8aa  vmovaps xmm3, [rsp+0x30]
00007a66921de8b0  vmovaps xmm4, [rsp+0x40]
00007a66921de8b6  vmovaps xmm5, [rsp+0x50]
00007a66921de8bc  vmovaps xmm6, [rsp+0x60]
00007a66921de8c2  vmovaps xmm7, [rsp+0x70]
00007a66921de8c8  vmovaps xmm8, [rsp+0x80]
00007a66921de8d1  vmovaps xmm9, [rsp+0x90]
00007a66921de8da  vmovaps xmm10, [rsp+0xA0]
00007a66921de8e3  vmovaps xmm11, [rsp+0xB0]
00007a66921de8ec  vmovaps xmm12, [rsp+0xC0]
00007a66921de8f5  vmovaps xmm13, [rsp+0xD0]
00007a66921de8fe  vmovaps xmm14, [rsp+0xE0]
00007a66921de907  add rsp, 0xF0
00007a66921de90e  pop r11
00007a66921de910  pop r10
00007a66921de912  pop r9
00007a66921de914  pop r8
00007a66921de916  pop rsi
00007a66921de917  pop rdi
00007a66921de918  pop rdx
00007a66921de919  pop rcx
00007a66921de91a  pop rax
00007a66921de91b  add rsp, 0x08
00007a66921de91f  jmp 0x00007A66921DC1E3
00007a66921de924  sub rsp, 0x08
00007a66921de928  push rax
00007a66921de929  push rcx
00007a66921de92a  push rdx
00007a66921de92b  push rdi
00007a66921de92c  push rsi
00007a66921de92d  push r8
00007a66921de92f  push r9
00007a66921de931  push r10
00007a66921de933  push r11
00007a66921de935  sub rsp, 0xF0
00007a66921de93c  vmovaps [rsp], xmm0
00007a66921de941  vmovaps [rsp+0x10], xmm1
00007a66921de947  vmovaps [rsp+0x20], xmm2
00007a66921de94d  vmovaps [rsp+0x30], xmm4
00007a66921de953  vmovaps [rsp+0x40], xmm5
00007a66921de959  vmovaps [rsp+0x50], xmm6
00007a66921de95f  vmovaps [rsp+0x60], xmm7
00007a66921de965  vmovaps [rsp+0x70], xmm8
00007a66921de96b  vmovaps [rsp+0x80], xmm9
00007a66921de974  vmovaps [rsp+0x90], xmm10
00007a66921de97d  vmovaps [rsp+0xA0], xmm11
00007a66921de986  vmovaps [rsp+0xB0], xmm12
00007a66921de98f  vmovaps [rsp+0xC0], xmm13
00007a66921de998  vmovaps [rsp+0xD0], xmm14
00007a66921de9a1  vmovaps [rsp+0xE0], xmm15
00007a66921de9aa  sub rsp, 0x30
00007a66921de9ae  movaps [rsp], xmm3
00007a66921de9b2  movaps [rsp+0x10], xmm1
00007a66921de9b7  movaps [rsp+0x20], xmm15
00007a66921de9bd  lea rdi, [rsp]
00007a66921de9c1  mov esi, 0x00
00007a66921de9c6  mov rax, 0x635346DC7530
00007a66921de9d0  call rax
00007a66921de9d2  movaps xmm3, [rsp]
00007a66921de9d6  add rsp, 0x30
00007a66921de9da  vmovaps xmm0, [rsp]
00007a66921de9df  vmovaps xmm1, [rsp+0x10]
00007a66921de9e5  vmovaps xmm2, [rsp+0x20]
00007a66921de9eb  vmovaps xmm4, [rsp+0x30]
00007a66921de9f1  vmovaps xmm5, [rsp+0x40]
00007a66921de9f7  vmovaps xmm6, [rsp+0x50]
00007a66921de9fd  vmovaps xmm7, [rsp+0x60]
00007a66921dea03  vmovaps xmm8, [rsp+0x70]
00007a66921dea09  vmovaps xmm9, [rsp+0x80]
00007a66921dea12  vmovaps xmm10, [rsp+0x90]
00007a66921dea1b  vmovaps xmm11, [rsp+0xA0]
00007a66921dea24  vmovaps xmm12, [rsp+0xB0]
00007a66921dea2d  vmovaps xmm13, [rsp+0xC0]
00007a66921dea36  vmovaps xmm14, [rsp+0xD0]
00007a66921dea3f  vmovaps xmm15, [rsp+0xE0]
00007a66921dea48  add rsp, 0xF0
00007a66921dea4f  pop r11
00007a66921dea51  pop r10
00007a66921dea53  pop r9
00007a66921dea55  pop r8
00007a66921dea57  pop rsi
00007a66921dea58  pop rdi
00007a66921dea59  pop rdx
00007a66921dea5a  pop rcx
00007a66921dea5b  pop rax
00007a66921dea5c  add rsp, 0x08
00007a66921dea60  jmp 0x00007A66921DC272
00007a66921dea65  call 0x00007A66920B52F0
00007a66921dea6a  jmp 0x00007A66921DC27C
00007a66921dea6f  sub rsp, 0x08
00007a66921dea73  push rax
00007a66921dea74  push rcx
00007a66921dea75  push rdx
00007a66921dea76  push rdi
00007a66921dea77  push rsi
00007a66921dea78  push r8
00007a66921dea7a  push r9
00007a66921dea7c  push r10
00007a66921dea7e  push r11
00007a66921dea80  sub rsp, 0xF0
00007a66921dea87  vmovaps [rsp], xmm0
00007a66921dea8c  vmovaps [rsp+0x10], xmm1
00007a66921dea92  vmovaps [rsp+0x20], xmm2
00007a66921dea98  vmovaps [rsp+0x30], xmm3
00007a66921dea9e  vmovaps [rsp+0x40], xmm4
00007a66921deaa4  vmovaps [rsp+0x50], xmm5
00007a66921deaaa  vmovaps [rsp+0x60], xmm6
00007a66921deab0  vmovaps [rsp+0x70], xmm7
00007a66921deab6  vmovaps [rsp+0x80], xmm8
00007a66921deabf  vmovaps [rsp+0x90], xmm9
00007a66921deac8  vmovaps [rsp+0xA0], xmm10
00007a66921dead1  vmovaps [rsp+0xB0], xmm11
00007a66921deada  vmovaps [rsp+0xC0], xmm12
00007a66921deae3  vmovaps [rsp+0xD0], xmm13
00007a66921deaec  vmovaps [rsp+0xE0], xmm14
00007a66921deaf5  sub rsp, 0x30
00007a66921deaf9  movaps [rsp], xmm15
00007a66921deafe  movaps [rsp+0x10], xmm14
00007a66921deb04  movaps [rsp+0x20], xmm4
00007a66921deb09  lea rdi, [rsp]
00007a66921deb0d  mov esi, 0x00
00007a66921deb12  mov rax, 0x635346DC7530
00007a66921deb1c  call rax
00007a66921deb1e  movaps xmm15, [rsp]
00007a66921deb23  add rsp, 0x30
00007a66921deb27  vmovaps xmm0, [rsp]
00007a66921deb2c  vmovaps xmm1, [rsp+0x10]
00007a66921deb32  vmovaps xmm2, [rsp+0x20]
00007a66921deb38  vmovaps xmm3, [rsp+0x30]
00007a66921deb3e  vmovaps xmm4, [rsp+0x40]
00007a66921deb44  vmovaps xmm5, [rsp+0x50]
00007a66921deb4a  vmovaps xmm6, [rsp+0x60]
00007a66921deb50  vmovaps xmm7, [rsp+0x70]
00007a66921deb56  vmovaps xmm8, [rsp+0x80]
00007a66921deb5f  vmovaps xmm9, [rsp+0x90]
00007a66921deb68  vmovaps xmm10, [rsp+0xA0]
00007a66921deb71  vmovaps xmm11, [rsp+0xB0]
00007a66921deb7a  vmovaps xmm12, [rsp+0xC0]
00007a66921deb83  vmovaps xmm13, [rsp+0xD0]
00007a66921deb8c  vmovaps xmm14, [rsp+0xE0]
00007a66921deb95  add rsp, 0xF0
00007a66921deb9c  pop r11
00007a66921deb9e  pop r10
00007a66921deba0  pop r9
00007a66921deba2  pop r8
00007a66921deba4  pop rsi
00007a66921deba5  pop rdi
00007a66921deba6  pop rdx
00007a66921deba7  pop rcx
00007a66921deba8  pop rax
00007a66921deba9  add rsp, 0x08
00007a66921debad  jmp 0x00007A66921DC2AA
00007a66921debb2  sub rsp, 0x08
00007a66921debb6  push rax
00007a66921debb7  push rcx
00007a66921debb8  push rdx
00007a66921debb9  push rdi
00007a66921debba  push rsi
00007a66921debbb  push r8
00007a66921debbd  push r9
00007a66921debbf  push r10
00007a66921debc1  push r11
00007a66921debc3  sub rsp, 0xF0
00007a66921debca  vmovaps [rsp], xmm0
00007a66921debcf  vmovaps [rsp+0x10], xmm1
00007a66921debd5  vmovaps [rsp+0x20], xmm2
00007a66921debdb  vmovaps [rsp+0x30], xmm3
00007a66921debe1  vmovaps [rsp+0x40], xmm4
00007a66921debe7  vmovaps [rsp+0x50], xmm5
00007a66921debed  vmovaps [rsp+0x60], xmm6
00007a66921debf3  vmovaps [rsp+0x70], xmm7
00007a66921debf9  vmovaps [rsp+0x80], xmm8
00007a66921dec02  vmovaps [rsp+0x90], xmm9
00007a66921dec0b  vmovaps [rsp+0xA0], xmm10
00007a66921dec14  vmovaps [rsp+0xB0], xmm11
00007a66921dec1d  vmovaps [rsp+0xC0], xmm12
00007a66921dec26  vmovaps [rsp+0xD0], xmm13
00007a66921dec2f  vmovaps [rsp+0xE0], xmm15
00007a66921dec38  sub rsp, 0x30
00007a66921dec3c  movaps [rsp], xmm14
00007a66921dec41  movaps [rsp+0x10], xmm2
00007a66921dec46  movaps [rsp+0x20], xmm1
00007a66921dec4b  lea rdi, [rsp]
00007a66921dec4f  mov esi, 0x00
00007a66921dec54  mov rax, 0x635346DC7530
00007a66921dec5e  call rax
00007a66921dec60  movaps xmm14, [rsp]
00007a66921dec65  add rsp, 0x30
00007a66921dec69  vmovaps xmm0, [rsp]
00007a66921dec6e  vmovaps xmm1, [rsp+0x10]
00007a66921dec74  vmovaps xmm2, [rsp+0x20]
00007a66921dec7a  vmovaps xmm3, [rsp+0x30]
00007a66921dec80  vmovaps xmm4, [rsp+0x40]
00007a66921dec86  vmovaps xmm5, [rsp+0x50]
00007a66921dec8c  vmovaps xmm6, [rsp+0x60]
00007a66921dec92  vmovaps xmm7, [rsp+0x70]
00007a66921dec98  vmovaps xmm8, [rsp+0x80]
00007a66921deca1  vmovaps xmm9, [rsp+0x90]
00007a66921decaa  vmovaps xmm10, [rsp+0xA0]
00007a66921decb3  vmovaps xmm11, [rsp+0xB0]
00007a66921decbc  vmovaps xmm12, [rsp+0xC0]
00007a66921decc5  vmovaps xmm13, [rsp+0xD0]
00007a66921decce  vmovaps xmm15, [rsp+0xE0]
00007a66921decd7  add rsp, 0xF0
00007a66921decde  pop r11
00007a66921dece0  pop r10
00007a66921dece2  pop r9
00007a66921dece4  pop r8
00007a66921dece6  pop rsi
00007a66921dece7  pop rdi
00007a66921dece8  pop rdx
00007a66921dece9  pop rcx
00007a66921decea  pop rax
00007a66921deceb  add rsp, 0x08
00007a66921decef  jmp 0x00007A66921DC2D0
00007a66921decf4  sub rsp, 0x08
00007a66921decf8  push rax
00007a66921decf9  push rcx
00007a66921decfa  push rdx
00007a66921decfb  push rdi
00007a66921decfc  push rsi
00007a66921decfd  push r8
00007a66921decff  push r9
00007a66921ded01  push r10
00007a66921ded03  push r11
00007a66921ded05  sub rsp, 0xF0
00007a66921ded0c  vmovaps [rsp], xmm0
00007a66921ded11  vmovaps [rsp+0x10], xmm2
00007a66921ded17  vmovaps [rsp+0x20], xmm3
00007a66921ded1d  vmovaps [rsp+0x30], xmm4
00007a66921ded23  vmovaps [rsp+0x40], xmm5
00007a66921ded29  vmovaps [rsp+0x50], xmm6
00007a66921ded2f  vmovaps [rsp+0x60], xmm7
00007a66921ded35  vmovaps [rsp+0x70], xmm8
00007a66921ded3b  vmovaps [rsp+0x80], xmm9
00007a66921ded44  vmovaps [rsp+0x90], xmm10
00007a66921ded4d  vmovaps [rsp+0xA0], xmm11
00007a66921ded56  vmovaps [rsp+0xB0], xmm12
00007a66921ded5f  vmovaps [rsp+0xC0], xmm13
00007a66921ded68  vmovaps [rsp+0xD0], xmm14
00007a66921ded71  vmovaps [rsp+0xE0], xmm15
00007a66921ded7a  sub rsp, 0x30
00007a66921ded7e  movaps [rsp], xmm1
00007a66921ded82  movaps [rsp+0x10], xmm4
00007a66921ded87  movaps [rsp+0x20], xmm9
00007a66921ded8d  lea rdi, [rsp]
00007a66921ded91  mov esi, 0x00
00007a66921ded96  mov rax, 0x635346DC7530
00007a66921deda0  call rax
00007a66921deda2  movaps xmm1, [rsp]
00007a66921deda6  add rsp, 0x30
00007a66921dedaa  vmovaps xmm0, [rsp]
00007a66921dedaf  vmovaps xmm2, [rsp+0x10]
00007a66921dedb5  vmovaps xmm3, [rsp+0x20]
00007a66921dedbb  vmovaps xmm4, [rsp+0x30]
00007a66921dedc1  vmovaps xmm5, [rsp+0x40]
00007a66921dedc7  vmovaps xmm6, [rsp+0x50]
00007a66921dedcd  vmovaps xmm7, [rsp+0x60]
00007a66921dedd3  vmovaps xmm8, [rsp+0x70]
00007a66921dedd9  vmovaps xmm9, [rsp+0x80]
00007a66921dede2  vmovaps xmm10, [rsp+0x90]
00007a66921dedeb  vmovaps xmm11, [rsp+0xA0]
00007a66921dedf4  vmovaps xmm12, [rsp+0xB0]
00007a66921dedfd  vmovaps xmm13, [rsp+0xC0]
00007a66921dee06  vmovaps xmm14, [rsp+0xD0]
00007a66921dee0f  vmovaps xmm15, [rsp+0xE0]
00007a66921dee18  add rsp, 0xF0
00007a66921dee1f  pop r11
00007a66921dee21  pop r10
00007a66921dee23  pop r9
00007a66921dee25  pop r8
00007a66921dee27  pop rsi
00007a66921dee28  pop rdi
00007a66921dee29  pop rdx
00007a66921dee2a  pop rcx
00007a66921dee2b  pop rax
00007a66921dee2c  add rsp, 0x08
00007a66921dee30  jmp 0x00007A66921DC2EE
00007a66921dee35  sub rsp, 0x08
00007a66921dee39  push rax
00007a66921dee3a  push rcx
00007a66921dee3b  push rdx
00007a66921dee3c  push rdi
00007a66921dee3d  push rsi
00007a66921dee3e  push r8
00007a66921dee40  push r9
00007a66921dee42  push r10
00007a66921dee44  push r11
00007a66921dee46  sub rsp, 0xF0
00007a66921dee4d  vmovaps [rsp], xmm0
00007a66921dee52  vmovaps [rsp+0x10], xmm1
00007a66921dee58  vmovaps [rsp+0x20], xmm2
00007a66921dee5e  vmovaps [rsp+0x30], xmm3
00007a66921dee64  vmovaps [rsp+0x40], xmm5
00007a66921dee6a  vmovaps [rsp+0x50], xmm6
00007a66921dee70  vmovaps [rsp+0x60], xmm7
00007a66921dee76  vmovaps [rsp+0x70], xmm8
00007a66921dee7c  vmovaps [rsp+0x80], xmm9
00007a66921dee85  vmovaps [rsp+0x90], xmm10
00007a66921dee8e  vmovaps [rsp+0xA0], xmm11
00007a66921dee97  vmovaps [rsp+0xB0], xmm12
00007a66921deea0  vmovaps [rsp+0xC0], xmm13
00007a66921deea9  vmovaps [rsp+0xD0], xmm14
00007a66921deeb2  vmovaps [rsp+0xE0], xmm15
00007a66921deebb  sub rsp, 0x30
00007a66921deebf  movaps [rsp], xmm4
00007a66921deec3  movaps [rsp+0x10], xmm2
00007a66921deec8  movaps [rsp+0x20], xmm9
00007a66921deece  lea rdi, [rsp]
00007a66921deed2  mov esi, 0x00
00007a66921deed7  mov rax, 0x635346DC7530
00007a66921deee1  call rax
00007a66921deee3  movaps xmm4, [rsp]
00007a66921deee7  add rsp, 0x30
00007a66921deeeb  vmovaps xmm0, [rsp]
00007a66921deef0  vmovaps xmm1, [rsp+0x10]
00007a66921deef6  vmovaps xmm2, [rsp+0x20]
00007a66921deefc  vmovaps xmm3, [rsp+0x30]
00007a66921def02  vmovaps xmm5, [rsp+0x40]
00007a66921def08  vmovaps xmm6, [rsp+0x50]
00007a66921def0e  vmovaps xmm7, [rsp+0x60]
00007a66921def14  vmovaps xmm8, [rsp+0x70]
00007a66921def1a  vmovaps xmm9, [rsp+0x80]
00007a66921def23  vmovaps xmm10, [rsp+0x90]
00007a66921def2c  vmovaps xmm11, [rsp+0xA0]
00007a66921def35  vmovaps xmm12, [rsp+0xB0]
00007a66921def3e  vmovaps xmm13, [rsp+0xC0]
00007a66921def47  vmovaps xmm14, [rsp+0xD0]
00007a66921def50  vmovaps xmm15, [rsp+0xE0]
00007a66921def59  add rsp, 0xF0
00007a66921def60  pop r11
00007a66921def62  pop r10
00007a66921def64  pop r9
00007a66921def66  pop r8
00007a66921def68  pop rsi
00007a66921def69  pop rdi
00007a66921def6a  pop rdx
00007a66921def6b  pop rcx
00007a66921def6c  pop rax
00007a66921def6d  add rsp, 0x08
00007a66921def71  jmp 0x00007A66921DC31E
00007a66921def76  sub rsp, 0x08
00007a66921def7a  push rax
00007a66921def7b  push rcx
00007a66921def7c  push rdx
00007a66921def7d  push rdi
00007a66921def7e  push rsi
00007a66921def7f  push r8
00007a66921def81  push r9
00007a66921def83  push r10
00007a66921def85  push r11
00007a66921def87  sub rsp, 0xF0
00007a66921def8e  vmovaps [rsp], xmm0
00007a66921def93  vmovaps [rsp+0x10], xmm1
00007a66921def99  vmovaps [rsp+0x20], xmm2
00007a66921def9f  vmovaps [rsp+0x30], xmm3
00007a66921defa5  vmovaps [rsp+0x40], xmm4
00007a66921defab  vmovaps [rsp+0x50], xmm5
00007a66921defb1  vmovaps [rsp+0x60], xmm6
00007a66921defb7  vmovaps [rsp+0x70], xmm7
00007a66921defbd  vmovaps [rsp+0x80], xmm8
00007a66921defc6  vmovaps [rsp+0x90], xmm10
00007a66921defcf  vmovaps [rsp+0xA0], xmm11
00007a66921defd8  vmovaps [rsp+0xB0], xmm12
00007a66921defe1  vmovaps [rsp+0xC0], xmm13
00007a66921defea  vmovaps [rsp+0xD0], xmm14
00007a66921deff3  vmovaps [rsp+0xE0], xmm15
00007a66921deffc  sub rsp, 0x30
00007a66921df000  movaps [rsp], xmm9
00007a66921df005  movaps [rsp+0x10], xmm2
00007a66921df00a  movaps [rsp+0x20], xmm1
00007a66921df00f  lea rdi, [rsp]
00007a66921df013  mov esi, 0x00
00007a66921df018  mov rax, 0x635346DC7530
00007a66921df022  call rax
00007a66921df024  movaps xmm9, [rsp]
00007a66921df029  add rsp, 0x30
00007a66921df02d  vmovaps xmm0, [rsp]
00007a66921df032  vmovaps xmm1, [rsp+0x10]
00007a66921df038  vmovaps xmm2, [rsp+0x20]
00007a66921df03e  vmovaps xmm3, [rsp+0x30]
00007a66921df044  vmovaps xmm4, [rsp+0x40]
00007a66921df04a  vmovaps xmm5, [rsp+0x50]
00007a66921df050  vmovaps xmm6, [rsp+0x60]
00007a66921df056  vmovaps xmm7, [rsp+0x70]
00007a66921df05c  vmovaps xmm8, [rsp+0x80]
00007a66921df065  vmovaps xmm10, [rsp+0x90]
00007a66921df06e  vmovaps xmm11, [rsp+0xA0]
00007a66921df077  vmovaps xmm12, [rsp+0xB0]
00007a66921df080  vmovaps xmm13, [rsp+0xC0]
00007a66921df089  vmovaps xmm14, [rsp+0xD0]
00007a66921df092  vmovaps xmm15, [rsp+0xE0]
00007a66921df09b  add rsp, 0xF0
00007a66921df0a2  pop r11
00007a66921df0a4  pop r10
00007a66921df0a6  pop r9
00007a66921df0a8  pop r8
00007a66921df0aa  pop rsi
00007a66921df0ab  pop rdi
00007a66921df0ac  pop rdx
00007a66921df0ad  pop rcx
00007a66921df0ae  pop rax
00007a66921df0af  add rsp, 0x08
00007a66921df0b3  jmp 0x00007A66921DC354
00007a66921df0b8  sub rsp, 0x08
00007a66921df0bc  push rax
00007a66921df0bd  push rcx
00007a66921df0be  push rdx
00007a66921df0bf  push rdi
00007a66921df0c0  push rsi
00007a66921df0c1  push r8
00007a66921df0c3  push r9
00007a66921df0c5  push r10
00007a66921df0c7  push r11
00007a66921df0c9  sub rsp, 0xF0
00007a66921df0d0  vmovaps [rsp], xmm0
00007a66921df0d5  vmovaps [rsp+0x10], xmm2
00007a66921df0db  vmovaps [rsp+0x20], xmm3
00007a66921df0e1  vmovaps [rsp+0x30], xmm4
00007a66921df0e7  vmovaps [rsp+0x40], xmm5
00007a66921df0ed  vmovaps [rsp+0x50], xmm6
00007a66921df0f3  vmovaps [rsp+0x60], xmm7
00007a66921df0f9  vmovaps [rsp+0x70], xmm8
00007a66921df0ff  vmovaps [rsp+0x80], xmm9
00007a66921df108  vmovaps [rsp+0x90], xmm10
00007a66921df111  vmovaps [rsp+0xA0], xmm11
00007a66921df11a  vmovaps [rsp+0xB0], xmm12
00007a66921df123  vmovaps [rsp+0xC0], xmm13
00007a66921df12c  vmovaps [rsp+0xD0], xmm14
00007a66921df135  vmovaps [rsp+0xE0], xmm15
00007a66921df13e  sub rsp, 0x30
00007a66921df142  movaps [rsp], xmm1
00007a66921df146  movaps [rsp+0x10], xmm15
00007a66921df14c  movaps [rsp+0x20], xmm6
00007a66921df151  lea rdi, [rsp]
00007a66921df155  mov esi, 0x00
00007a66921df15a  mov rax, 0x635346DC7530
00007a66921df164  call rax
00007a66921df166  movaps xmm1, [rsp]
00007a66921df16a  add rsp, 0x30
00007a66921df16e  vmovaps xmm0, [rsp]
00007a66921df173  vmovaps xmm2, [rsp+0x10]
00007a66921df179  vmovaps xmm3, [rsp+0x20]
00007a66921df17f  vmovaps xmm4, [rsp+0x30]
00007a66921df185  vmovaps xmm5, [rsp+0x40]
00007a66921df18b  vmovaps xmm6, [rsp+0x50]
00007a66921df191  vmovaps xmm7, [rsp+0x60]
00007a66921df197  vmovaps xmm8, [rsp+0x70]
00007a66921df19d  vmovaps xmm9, [rsp+0x80]
00007a66921df1a6  vmovaps xmm10, [rsp+0x90]
00007a66921df1af  vmovaps xmm11, [rsp+0xA0]
00007a66921df1b8  vmovaps xmm12, [rsp+0xB0]
00007a66921df1c1  vmovaps xmm13, [rsp+0xC0]
00007a66921df1ca  vmovaps xmm14, [rsp+0xD0]
00007a66921df1d3  vmovaps xmm15, [rsp+0xE0]
00007a66921df1dc  add rsp, 0xF0
00007a66921df1e3  pop r11
00007a66921df1e5  pop r10
00007a66921df1e7  pop r9
00007a66921df1e9  pop r8
00007a66921df1eb  pop rsi
00007a66921df1ec  pop rdi
00007a66921df1ed  pop rdx
00007a66921df1ee  pop rcx
00007a66921df1ef  pop rax
00007a66921df1f0  add rsp, 0x08
00007a66921df1f4  jmp 0x00007A66921DC375
00007a66921df1f9  sub rsp, 0x08
00007a66921df1fd  push rax
00007a66921df1fe  push rcx
00007a66921df1ff  push rdx
00007a66921df200  push rdi
00007a66921df201  push rsi
00007a66921df202  push r8
00007a66921df204  push r9
00007a66921df206  push r10
00007a66921df208  push r11
00007a66921df20a  sub rsp, 0xF0
00007a66921df211  vmovaps [rsp], xmm0
00007a66921df216  vmovaps [rsp+0x10], xmm1
00007a66921df21c  vmovaps [rsp+0x20], xmm2
00007a66921df222  vmovaps [rsp+0x30], xmm3
00007a66921df228  vmovaps [rsp+0x40], xmm4
00007a66921df22e  vmovaps [rsp+0x50], xmm5
00007a66921df234  vmovaps [rsp+0x60], xmm6
00007a66921df23a  vmovaps [rsp+0x70], xmm7
00007a66921df240  vmovaps [rsp+0x80], xmm8
00007a66921df249  vmovaps [rsp+0x90], xmm9
00007a66921df252  vmovaps [rsp+0xA0], xmm10
00007a66921df25b  vmovaps [rsp+0xB0], xmm11
00007a66921df264  vmovaps [rsp+0xC0], xmm12
00007a66921df26d  vmovaps [rsp+0xD0], xmm13
00007a66921df276  vmovaps [rsp+0xE0], xmm14
00007a66921df27f  sub rsp, 0x30
00007a66921df283  movaps [rsp], xmm15
00007a66921df288  movaps [rsp+0x10], xmm5
00007a66921df28d  movaps [rsp+0x20], xmm3
00007a66921df292  lea rdi, [rsp]
00007a66921df296  mov esi, 0x00
00007a66921df29b  mov rax, 0x635346DC7530
00007a66921df2a5  call rax
00007a66921df2a7  movaps xmm15, [rsp]
00007a66921df2ac  add rsp, 0x30
00007a66921df2b0  vmovaps xmm0, [rsp]
00007a66921df2b5  vmovaps xmm1, [rsp+0x10]
00007a66921df2bb  vmovaps xmm2, [rsp+0x20]
00007a66921df2c1  vmovaps xmm3, [rsp+0x30]
00007a66921df2c7  vmovaps xmm4, [rsp+0x40]
00007a66921df2cd  vmovaps xmm5, [rsp+0x50]
00007a66921df2d3  vmovaps xmm6, [rsp+0x60]
00007a66921df2d9  vmovaps xmm7, [rsp+0x70]
00007a66921df2df  vmovaps xmm8, [rsp+0x80]
00007a66921df2e8  vmovaps xmm9, [rsp+0x90]
00007a66921df2f1  vmovaps xmm10, [rsp+0xA0]
00007a66921df2fa  vmovaps xmm11, [rsp+0xB0]
00007a66921df303  vmovaps xmm12, [rsp+0xC0]
00007a66921df30c  vmovaps xmm13, [rsp+0xD0]
00007a66921df315  vmovaps xmm14, [rsp+0xE0]
00007a66921df31e  add rsp, 0xF0
00007a66921df325  pop r11
00007a66921df327  pop r10
00007a66921df329  pop r9
00007a66921df32b  pop r8
00007a66921df32d  pop rsi
00007a66921df32e  pop rdi
00007a66921df32f  pop rdx
00007a66921df330  pop rcx
00007a66921df331  pop rax
00007a66921df332  add rsp, 0x08
00007a66921df336  jmp 0x00007A66921DC38F
00007a66921df33b  sub rsp, 0x08
00007a66921df33f  push rax
00007a66921df340  push rcx
00007a66921df341  push rdx
00007a66921df342  push rdi
00007a66921df343  push rsi
00007a66921df344  push r8
00007a66921df346  push r9
00007a66921df348  push r10
00007a66921df34a  push r11
00007a66921df34c  sub rsp, 0xF0
00007a66921df353  vmovaps [rsp], xmm0
00007a66921df358  vmovaps [rsp+0x10], xmm1
00007a66921df35e  vmovaps [rsp+0x20], xmm2
00007a66921df364  vmovaps [rsp+0x30], xmm3
00007a66921df36a  vmovaps [rsp+0x40], xmm4
00007a66921df370  vmovaps [rsp+0x50], xmm6
00007a66921df376  vmovaps [rsp+0x60], xmm7
00007a66921df37c  vmovaps [rsp+0x70], xmm8
00007a66921df382  vmovaps [rsp+0x80], xmm9
00007a66921df38b  vmovaps [rsp+0x90], xmm10
00007a66921df394  vmovaps [rsp+0xA0], xmm11
00007a66921df39d  vmovaps [rsp+0xB0], xmm12
00007a66921df3a6  vmovaps [rsp+0xC0], xmm13
00007a66921df3af  vmovaps [rsp+0xD0], xmm14
00007a66921df3b8  vmovaps [rsp+0xE0], xmm15
00007a66921df3c1  sub rsp, 0x30
00007a66921df3c5  movaps [rsp], xmm5
00007a66921df3c9  movaps [rsp+0x10], xmm8
00007a66921df3cf  movaps [rsp+0x20], xmm6
00007a66921df3d4  lea rdi, [rsp]
00007a66921df3d8  mov esi, 0x00
00007a66921df3dd  mov rax, 0x635346DC7530
00007a66921df3e7  call rax
00007a66921df3e9  movaps xmm5, [rsp]
00007a66921df3ed  add rsp, 0x30
00007a66921df3f1  vmovaps xmm0, [rsp]
00007a66921df3f6  vmovaps xmm1, [rsp+0x10]
00007a66921df3fc  vmovaps xmm2, [rsp+0x20]
00007a66921df402  vmovaps xmm3, [rsp+0x30]
00007a66921df408  vmovaps xmm4, [rsp+0x40]
00007a66921df40e  vmovaps xmm6, [rsp+0x50]
00007a66921df414  vmovaps xmm7, [rsp+0x60]
00007a66921df41a  vmovaps xmm8, [rsp+0x70]
00007a66921df420  vmovaps xmm9, [rsp+0x80]
00007a66921df429  vmovaps xmm10, [rsp+0x90]
00007a66921df432  vmovaps xmm11, [rsp+0xA0]
00007a66921df43b  vmovaps xmm12, [rsp+0xB0]
00007a66921df444  vmovaps xmm13, [rsp+0xC0]
00007a66921df44d  vmovaps xmm14, [rsp+0xD0]
00007a66921df456  vmovaps xmm15, [rsp+0xE0]
00007a66921df45f  add rsp, 0xF0
00007a66921df466  pop r11
00007a66921df468  pop r10
00007a66921df46a  pop r9
00007a66921df46c  pop r8
00007a66921df46e  pop rsi
00007a66921df46f  pop rdi
00007a66921df470  pop rdx
00007a66921df471  pop rcx
00007a66921df472  pop rax
00007a66921df473  add rsp, 0x08
00007a66921df477  jmp 0x00007A66921DC3B3
00007a66921df47c  sub rsp, 0x08
00007a66921df480  push rax
00007a66921df481  push rcx
00007a66921df482  push rdx
00007a66921df483  push rdi
00007a66921df484  push rsi
00007a66921df485  push r8
00007a66921df487  push r9
00007a66921df489  push r10
00007a66921df48b  push r11
00007a66921df48d  sub rsp, 0xF0
00007a66921df494  vmovaps [rsp], xmm0
00007a66921df499  vmovaps [rsp+0x10], xmm1
00007a66921df49f  vmovaps [rsp+0x20], xmm2
00007a66921df4a5  vmovaps [rsp+0x30], xmm3
00007a66921df4ab  vmovaps [rsp+0x40], xmm4
00007a66921df4b1  vmovaps [rsp+0x50], xmm5
00007a66921df4b7  vmovaps [rsp+0x60], xmm7
00007a66921df4bd  vmovaps [rsp+0x70], xmm8
00007a66921df4c3  vmovaps [rsp+0x80], xmm9
00007a66921df4cc  vmovaps [rsp+0x90], xmm10
00007a66921df4d5  vmovaps [rsp+0xA0], xmm11
00007a66921df4de  vmovaps [rsp+0xB0], xmm12
00007a66921df4e7  vmovaps [rsp+0xC0], xmm13
00007a66921df4f0  vmovaps [rsp+0xD0], xmm14
00007a66921df4f9  vmovaps [rsp+0xE0], xmm15
00007a66921df502  sub rsp, 0x30
00007a66921df506  movaps [rsp], xmm6
00007a66921df50a  movaps [rsp+0x10], xmm10
00007a66921df510  movaps [rsp+0x20], xmm8
00007a66921df516  lea rdi, [rsp]
00007a66921df51a  mov esi, 0x00
00007a66921df51f  mov rax, 0x635346DC7530
00007a66921df529  call rax
00007a66921df52b  movaps xmm6, [rsp]
00007a66921df52f  add rsp, 0x30
00007a66921df533  vmovaps xmm0, [rsp]
00007a66921df538  vmovaps xmm1, [rsp+0x10]
00007a66921df53e  vmovaps xmm2, [rsp+0x20]
00007a66921df544  vmovaps xmm3, [rsp+0x30]
00007a66921df54a  vmovaps xmm4, [rsp+0x40]
00007a66921df550  vmovaps xmm5, [rsp+0x50]
00007a66921df556  vmovaps xmm7, [rsp+0x60]
00007a66921df55c  vmovaps xmm8, [rsp+0x70]
00007a66921df562  vmovaps xmm9, [rsp+0x80]
00007a66921df56b  vmovaps xmm10, [rsp+0x90]
00007a66921df574  vmovaps xmm11, [rsp+0xA0]
00007a66921df57d  vmovaps xmm12, [rsp+0xB0]
00007a66921df586  vmovaps xmm13, [rsp+0xC0]
00007a66921df58f  vmovaps xmm14, [rsp+0xD0]
00007a66921df598  vmovaps xmm15, [rsp+0xE0]
00007a66921df5a1  add rsp, 0xF0
00007a66921df5a8  pop r11
00007a66921df5aa  pop r10
00007a66921df5ac  pop r9
00007a66921df5ae  pop r8
00007a66921df5b0  pop rsi
00007a66921df5b1  pop rdi
00007a66921df5b2  pop rdx
00007a66921df5b3  pop rcx
00007a66921df5b4  pop rax
00007a66921df5b5  add rsp, 0x08
00007a66921df5b9  jmp 0x00007A66921DC3D8
00007a66921df5be  sub rsp, 0x08
00007a66921df5c2  push rax
00007a66921df5c3  push rcx
00007a66921df5c4  push rdx
00007a66921df5c5  push rdi
00007a66921df5c6  push rsi
00007a66921df5c7  push r8
00007a66921df5c9  push r9
00007a66921df5cb  push r10
00007a66921df5cd  push r11
00007a66921df5cf  sub rsp, 0xF0
00007a66921df5d6  vmovaps [rsp], xmm0
00007a66921df5db  vmovaps [rsp+0x10], xmm1
00007a66921df5e1  vmovaps [rsp+0x20], xmm2
00007a66921df5e7  vmovaps [rsp+0x30], xmm3
00007a66921df5ed  vmovaps [rsp+0x40], xmm4
00007a66921df5f3  vmovaps [rsp+0x50], xmm5
00007a66921df5f9  vmovaps [rsp+0x60], xmm6
00007a66921df5ff  vmovaps [rsp+0x70], xmm7
00007a66921df605  vmovaps [rsp+0x80], xmm8
00007a66921df60e  vmovaps [rsp+0x90], xmm9
00007a66921df617  vmovaps [rsp+0xA0], xmm11
00007a66921df620  vmovaps [rsp+0xB0], xmm12
00007a66921df629  vmovaps [rsp+0xC0], xmm13
00007a66921df632  vmovaps [rsp+0xD0], xmm14
00007a66921df63b  vmovaps [rsp+0xE0], xmm15
00007a66921df644  sub rsp, 0x30
00007a66921df648  movaps [rsp], xmm10
00007a66921df64d  movaps [rsp+0x10], xmm8
00007a66921df653  movaps [rsp+0x20], xmm14
00007a66921df659  lea rdi, [rsp]
00007a66921df65d  mov esi, 0x00
00007a66921df662  mov rax, 0x635346DC7530
00007a66921df66c  call rax
00007a66921df66e  movaps xmm10, [rsp]
00007a66921df673  add rsp, 0x30
00007a66921df677  vmovaps xmm0, [rsp]
00007a66921df67c  vmovaps xmm1, [rsp+0x10]
00007a66921df682  vmovaps xmm2, [rsp+0x20]
00007a66921df688  vmovaps xmm3, [rsp+0x30]
00007a66921df68e  vmovaps xmm4, [rsp+0x40]
00007a66921df694  vmovaps xmm5, [rsp+0x50]
00007a66921df69a  vmovaps xmm6, [rsp+0x60]
00007a66921df6a0  vmovaps xmm7, [rsp+0x70]
00007a66921df6a6  vmovaps xmm8, [rsp+0x80]
00007a66921df6af  vmovaps xmm9, [rsp+0x90]
00007a66921df6b8  vmovaps xmm11, [rsp+0xA0]
00007a66921df6c1  vmovaps xmm12, [rsp+0xB0]
00007a66921df6ca  vmovaps xmm13, [rsp+0xC0]
00007a66921df6d3  vmovaps xmm14, [rsp+0xD0]
00007a66921df6dc  vmovaps xmm15, [rsp+0xE0]
00007a66921df6e5  add rsp, 0xF0
00007a66921df6ec  pop r11
00007a66921df6ee  pop r10
00007a66921df6f0  pop r9
00007a66921df6f2  pop r8
00007a66921df6f4  pop rsi
00007a66921df6f5  pop rdi
00007a66921df6f6  pop rdx
00007a66921df6f7  pop rcx
00007a66921df6f8  pop rax
00007a66921df6f9  add rsp, 0x08
00007a66921df6fd  jmp 0x00007A66921DC3F8
00007a66921df702  sub rsp, 0x08
00007a66921df706  push rax
00007a66921df707  push rcx
00007a66921df708  push rdx
00007a66921df709  push rdi
00007a66921df70a  push rsi
00007a66921df70b  push r8
00007a66921df70d  push r9
00007a66921df70f  push r10
00007a66921df711  push r11
00007a66921df713  sub rsp, 0xF0
00007a66921df71a  vmovaps [rsp], xmm0
00007a66921df71f  vmovaps [rsp+0x10], xmm1
00007a66921df725  vmovaps [rsp+0x20], xmm2
00007a66921df72b  vmovaps [rsp+0x30], xmm3
00007a66921df731  vmovaps [rsp+0x40], xmm4
00007a66921df737  vmovaps [rsp+0x50], xmm5
00007a66921df73d  vmovaps [rsp+0x60], xmm6
00007a66921df743  vmovaps [rsp+0x70], xmm7
00007a66921df749  vmovaps [rsp+0x80], xmm8
00007a66921df752  vmovaps [rsp+0x90], xmm9
00007a66921df75b  vmovaps [rsp+0xA0], xmm10
00007a66921df764  vmovaps [rsp+0xB0], xmm11
00007a66921df76d  vmovaps [rsp+0xC0], xmm12
00007a66921df776  vmovaps [rsp+0xD0], xmm13
00007a66921df77f  vmovaps [rsp+0xE0], xmm15
00007a66921df788  sub rsp, 0x30
00007a66921df78c  movaps [rsp], xmm14
00007a66921df791  movaps [rsp+0x10], xmm8
00007a66921df797  movaps [rsp+0x20], xmm4
00007a66921df79c  lea rdi, [rsp]
00007a66921df7a0  mov esi, 0x00
00007a66921df7a5  mov rax, 0x635346DC7530
00007a66921df7af  call rax
00007a66921df7b1  movaps xmm14, [rsp]
00007a66921df7b6  add rsp, 0x30
00007a66921df7ba  vmovaps xmm0, [rsp]
00007a66921df7bf  vmovaps xmm1, [rsp+0x10]
00007a66921df7c5  vmovaps xmm2, [rsp+0x20]
00007a66921df7cb  vmovaps xmm3, [rsp+0x30]
00007a66921df7d1  vmovaps xmm4, [rsp+0x40]
00007a66921df7d7  vmovaps xmm5, [rsp+0x50]
00007a66921df7dd  vmovaps xmm6, [rsp+0x60]
00007a66921df7e3  vmovaps xmm7, [rsp+0x70]
00007a66921df7e9  vmovaps xmm8, [rsp+0x80]
00007a66921df7f2  vmovaps xmm9, [rsp+0x90]
00007a66921df7fb  vmovaps xmm10, [rsp+0xA0]
00007a66921df804  vmovaps xmm11, [rsp+0xB0]
00007a66921df80d  vmovaps xmm12, [rsp+0xC0]
00007a66921df816  vmovaps xmm13, [rsp+0xD0]
00007a66921df81f  vmovaps xmm15, [rsp+0xE0]
00007a66921df828  add rsp, 0xF0
00007a66921df82f  pop r11
00007a66921df831  pop r10
00007a66921df833  pop r9
00007a66921df835  pop r8
00007a66921df837  pop rsi
00007a66921df838  pop rdi
00007a66921df839  pop rdx
00007a66921df83a  pop rcx
00007a66921df83b  pop rax
00007a66921df83c  add rsp, 0x08
00007a66921df840  jmp 0x00007A66921DC418
00007a66921df845  sub rsp, 0x08
00007a66921df849  push rax
00007a66921df84a  push rcx
00007a66921df84b  push rdx
00007a66921df84c  push rdi
00007a66921df84d  push rsi
00007a66921df84e  push r8
00007a66921df850  push r9
00007a66921df852  push r10
00007a66921df854  push r11
00007a66921df856  sub rsp, 0xF0
00007a66921df85d  vmovaps [rsp], xmm0
00007a66921df862  vmovaps [rsp+0x10], xmm1
00007a66921df868  vmovaps [rsp+0x20], xmm2
00007a66921df86e  vmovaps [rsp+0x30], xmm3
00007a66921df874  vmovaps [rsp+0x40], xmm5
00007a66921df87a  vmovaps [rsp+0x50], xmm6
00007a66921df880  vmovaps [rsp+0x60], xmm7
00007a66921df886  vmovaps [rsp+0x70], xmm8
00007a66921df88c  vmovaps [rsp+0x80], xmm9
00007a66921df895  vmovaps [rsp+0x90], xmm10
00007a66921df89e  vmovaps [rsp+0xA0], xmm11
00007a66921df8a7  vmovaps [rsp+0xB0], xmm12
00007a66921df8b0  vmovaps [rsp+0xC0], xmm13
00007a66921df8b9  vmovaps [rsp+0xD0], xmm14
00007a66921df8c2  vmovaps [rsp+0xE0], xmm15
00007a66921df8cb  sub rsp, 0x30
00007a66921df8cf  movaps [rsp], xmm4
00007a66921df8d3  movaps [rsp+0x10], xmm13
00007a66921df8d9  movaps [rsp+0x20], xmm8
00007a66921df8df  lea rdi, [rsp]
00007a66921df8e3  mov esi, 0x00
00007a66921df8e8  mov rax, 0x635346DC7530
00007a66921df8f2  call rax
00007a66921df8f4  movaps xmm4, [rsp]
00007a66921df8f8  add rsp, 0x30
00007a66921df8fc  vmovaps xmm0, [rsp]
00007a66921df901  vmovaps xmm1, [rsp+0x10]
00007a66921df907  vmovaps xmm2, [rsp+0x20]
00007a66921df90d  vmovaps xmm3, [rsp+0x30]
00007a66921df913  vmovaps xmm5, [rsp+0x40]
00007a66921df919  vmovaps xmm6, [rsp+0x50]
00007a66921df91f  vmovaps xmm7, [rsp+0x60]
00007a66921df925  vmovaps xmm8, [rsp+0x70]
00007a66921df92b  vmovaps xmm9, [rsp+0x80]
00007a66921df934  vmovaps xmm10, [rsp+0x90]
00007a66921df93d  vmovaps xmm11, [rsp+0xA0]
00007a66921df946  vmovaps xmm12, [rsp+0xB0]
00007a66921df94f  vmovaps xmm13, [rsp+0xC0]
00007a66921df958  vmovaps xmm14, [rsp+0xD0]
00007a66921df961  vmovaps xmm15, [rsp+0xE0]
00007a66921df96a  add rsp, 0xF0
00007a66921df971  pop r11
00007a66921df973  pop r10
00007a66921df975  pop r9
00007a66921df977  pop r8
00007a66921df979  pop rsi
00007a66921df97a  pop rdi
00007a66921df97b  pop rdx
00007a66921df97c  pop rcx
00007a66921df97d  pop rax
00007a66921df97e  add rsp, 0x08
00007a66921df982  jmp 0x00007A66921DC43D
00007a66921df987  sub rsp, 0x08
00007a66921df98b  push rax
00007a66921df98c  push rcx
00007a66921df98d  push rdx
00007a66921df98e  push rdi
00007a66921df98f  push rsi
00007a66921df990  push r8
00007a66921df992  push r9
00007a66921df994  push r10
00007a66921df996  push r11
00007a66921df998  sub rsp, 0xF0
00007a66921df99f  vmovaps [rsp], xmm0
00007a66921df9a4  vmovaps [rsp+0x10], xmm1
00007a66921df9aa  vmovaps [rsp+0x20], xmm2
00007a66921df9b0  vmovaps [rsp+0x30], xmm3
00007a66921df9b6  vmovaps [rsp+0x40], xmm4
00007a66921df9bc  vmovaps [rsp+0x50], xmm5
00007a66921df9c2  vmovaps [rsp+0x60], xmm6
00007a66921df9c8  vmovaps [rsp+0x70], xmm7
00007a66921df9ce  vmovaps [rsp+0x80], xmm8
00007a66921df9d7  vmovaps [rsp+0x90], xmm9
00007a66921df9e0  vmovaps [rsp+0xA0], xmm10
00007a66921df9e9  vmovaps [rsp+0xB0], xmm11
00007a66921df9f2  vmovaps [rsp+0xC0], xmm12
00007a66921df9fb  vmovaps [rsp+0xD0], xmm14
00007a66921dfa04  vmovaps [rsp+0xE0], xmm15
00007a66921dfa0d  sub rsp, 0x30
00007a66921dfa11  movaps [rsp], xmm13
00007a66921dfa16  movaps [rsp+0x10], xmm15
00007a66921dfa1c  movaps [rsp+0x20], xmm9
00007a66921dfa22  lea rdi, [rsp]
00007a66921dfa26  mov esi, 0x00
00007a66921dfa2b  mov rax, 0x635346DC7530
00007a66921dfa35  call rax
00007a66921dfa37  movaps xmm13, [rsp]
00007a66921dfa3c  add rsp, 0x30
00007a66921dfa40  vmovaps xmm0, [rsp]
00007a66921dfa45  vmovaps xmm1, [rsp+0x10]
00007a66921dfa4b  vmovaps xmm2, [rsp+0x20]
00007a66921dfa51  vmovaps xmm3, [rsp+0x30]
00007a66921dfa57  vmovaps xmm4, [rsp+0x40]
00007a66921dfa5d  vmovaps xmm5, [rsp+0x50]
00007a66921dfa63  vmovaps xmm6, [rsp+0x60]
00007a66921dfa69  vmovaps xmm7, [rsp+0x70]
00007a66921dfa6f  vmovaps xmm8, [rsp+0x80]
00007a66921dfa78  vmovaps xmm9, [rsp+0x90]
00007a66921dfa81  vmovaps xmm10, [rsp+0xA0]
00007a66921dfa8a  vmovaps xmm11, [rsp+0xB0]
00007a66921dfa93  vmovaps xmm12, [rsp+0xC0]
00007a66921dfa9c  vmovaps xmm14, [rsp+0xD0]
00007a66921dfaa5  vmovaps xmm15, [rsp+0xE0]
00007a66921dfaae  add rsp, 0xF0
00007a66921dfab5  pop r11
00007a66921dfab7  pop r10
00007a66921dfab9  pop r9
00007a66921dfabb  pop r8
00007a66921dfabd  pop rsi
00007a66921dfabe  pop rdi
00007a66921dfabf  pop rdx
00007a66921dfac0  pop rcx
00007a66921dfac1  pop rax
00007a66921dfac2  add rsp, 0x08
00007a66921dfac6  jmp 0x00007A66921DC458
00007a66921dfacb  sub rsp, 0x08
00007a66921dfacf  push rax
00007a66921dfad0  push rcx
00007a66921dfad1  push rdx
00007a66921dfad2  push rdi
00007a66921dfad3  push rsi
00007a66921dfad4  push r8
00007a66921dfad6  push r9
00007a66921dfad8  push r10
00007a66921dfada  push r11
00007a66921dfadc  sub rsp, 0xF0
00007a66921dfae3  vmovaps [rsp], xmm0
00007a66921dfae8  vmovaps [rsp+0x10], xmm1
00007a66921dfaee  vmovaps [rsp+0x20], xmm2
00007a66921dfaf4  vmovaps [rsp+0x30], xmm3
00007a66921dfafa  vmovaps [rsp+0x40], xmm4
00007a66921dfb00  vmovaps [rsp+0x50], xmm5
00007a66921dfb06  vmovaps [rsp+0x60], xmm6
00007a66921dfb0c  vmovaps [rsp+0x70], xmm7
00007a66921dfb12  vmovaps [rsp+0x80], xmm8
00007a66921dfb1b  vmovaps [rsp+0x90], xmm9
00007a66921dfb24  vmovaps [rsp+0xA0], xmm10
00007a66921dfb2d  vmovaps [rsp+0xB0], xmm11
00007a66921dfb36  vmovaps [rsp+0xC0], xmm12
00007a66921dfb3f  vmovaps [rsp+0xD0], xmm13
00007a66921dfb48  vmovaps [rsp+0xE0], xmm14
00007a66921dfb51  sub rsp, 0x30
00007a66921dfb55  movaps [rsp], xmm15
00007a66921dfb5a  movaps [rsp+0x10], xmm1
00007a66921dfb5f  movaps [rsp+0x20], xmm5
00007a66921dfb64  lea rdi, [rsp]
00007a66921dfb68  mov esi, 0x00
00007a66921dfb6d  mov rax, 0x635346DC7530
00007a66921dfb77  call rax
00007a66921dfb79  movaps xmm15, [rsp]
00007a66921dfb7e  add rsp, 0x30
00007a66921dfb82  vmovaps xmm0, [rsp]
00007a66921dfb87  vmovaps xmm1, [rsp+0x10]
00007a66921dfb8d  vmovaps xmm2, [rsp+0x20]
00007a66921dfb93  vmovaps xmm3, [rsp+0x30]
00007a66921dfb99  vmovaps xmm4, [rsp+0x40]
00007a66921dfb9f  vmovaps xmm5, [rsp+0x50]
00007a66921dfba5  vmovaps xmm6, [rsp+0x60]
00007a66921dfbab  vmovaps xmm7, [rsp+0x70]
00007a66921dfbb1  vmovaps xmm8, [rsp+0x80]
00007a66921dfbba  vmovaps xmm9, [rsp+0x90]
00007a66921dfbc3  vmovaps xmm10, [rsp+0xA0]
00007a66921dfbcc  vmovaps xmm11, [rsp+0xB0]
00007a66921dfbd5  vmovaps xmm12, [rsp+0xC0]
00007a66921dfbde  vmovaps xmm13, [rsp+0xD0]
00007a66921dfbe7  vmovaps xmm14, [rsp+0xE0]
00007a66921dfbf0  add rsp, 0xF0
00007a66921dfbf7  pop r11
00007a66921dfbf9  pop r10
00007a66921dfbfb  pop r9
00007a66921dfbfd  pop r8
00007a66921dfbff  pop rsi
00007a66921dfc00  pop rdi
00007a66921dfc01  pop rdx
00007a66921dfc02  pop rcx
00007a66921dfc03  pop rax
00007a66921dfc04  add rsp, 0x08
00007a66921dfc08  jmp 0x00007A66921DC473
00007a66921dfc0d  call 0x00007A66920B52F0
00007a66921dfc12  jmp 0x00007A66921DC4CE
00007a66921dfc17  sub rsp, 0x08
00007a66921dfc1b  push rax
00007a66921dfc1c  push rcx
00007a66921dfc1d  push rdx
00007a66921dfc1e  push rdi
00007a66921dfc1f  push rsi
00007a66921dfc20  push r8
00007a66921dfc22  push r9
00007a66921dfc24  push r10
00007a66921dfc26  push r11
00007a66921dfc28  sub rsp, 0xF0
00007a66921dfc2f  vmovaps [rsp], xmm0
00007a66921dfc34  vmovaps [rsp+0x10], xmm1
00007a66921dfc3a  vmovaps [rsp+0x20], xmm2
00007a66921dfc40  vmovaps [rsp+0x30], xmm3
00007a66921dfc46  vmovaps [rsp+0x40], xmm4
00007a66921dfc4c  vmovaps [rsp+0x50], xmm5
00007a66921dfc52  vmovaps [rsp+0x60], xmm6
00007a66921dfc58  vmovaps [rsp+0x70], xmm7
00007a66921dfc5e  vmovaps [rsp+0x80], xmm8
00007a66921dfc67  vmovaps [rsp+0x90], xmm10
00007a66921dfc70  vmovaps [rsp+0xA0], xmm11
00007a66921dfc79  vmovaps [rsp+0xB0], xmm12
00007a66921dfc82  vmovaps [rsp+0xC0], xmm13
00007a66921dfc8b  vmovaps [rsp+0xD0], xmm14
00007a66921dfc94  vmovaps [rsp+0xE0], xmm15
00007a66921dfc9d  sub rsp, 0x30
00007a66921dfca1  movaps [rsp], xmm9
00007a66921dfca6  movaps [rsp+0x10], xmm8
00007a66921dfcac  movaps [rsp+0x20], xmm11
00007a66921dfcb2  lea rdi, [rsp]
00007a66921dfcb6  mov esi, 0x00
00007a66921dfcbb  mov rax, 0x635346DC7530
00007a66921dfcc5  call rax
00007a66921dfcc7  movaps xmm9, [rsp]
00007a66921dfccc  add rsp, 0x30
00007a66921dfcd0  vmovaps xmm0, [rsp]
00007a66921dfcd5  vmovaps xmm1, [rsp+0x10]
00007a66921dfcdb  vmovaps xmm2, [rsp+0x20]
00007a66921dfce1  vmovaps xmm3, [rsp+0x30]
00007a66921dfce7  vmovaps xmm4, [rsp+0x40]
00007a66921dfced  vmovaps xmm5, [rsp+0x50]
00007a66921dfcf3  vmovaps xmm6, [rsp+0x60]
00007a66921dfcf9  vmovaps xmm7, [rsp+0x70]
00007a66921dfcff  vmovaps xmm8, [rsp+0x80]
00007a66921dfd08  vmovaps xmm10, [rsp+0x90]
00007a66921dfd11  vmovaps xmm11, [rsp+0xA0]
00007a66921dfd1a  vmovaps xmm12, [rsp+0xB0]
00007a66921dfd23  vmovaps xmm13, [rsp+0xC0]
00007a66921dfd2c  vmovaps xmm14, [rsp+0xD0]
00007a66921dfd35  vmovaps xmm15, [rsp+0xE0]
00007a66921dfd3e  add rsp, 0xF0
00007a66921dfd45  pop r11
00007a66921dfd47  pop r10
00007a66921dfd49  pop r9
00007a66921dfd4b  pop r8
00007a66921dfd4d  pop rsi
00007a66921dfd4e  pop rdi
00007a66921dfd4f  pop rdx
00007a66921dfd50  pop rcx
00007a66921dfd51  pop rax
00007a66921dfd52  add rsp, 0x08
00007a66921dfd56  jmp 0x00007A66921DC505
00007a66921dfd5b  sub rsp, 0x08
00007a66921dfd5f  push rax
00007a66921dfd60  push rcx
00007a66921dfd61  push rdx
00007a66921dfd62  push rdi
00007a66921dfd63  push rsi
00007a66921dfd64  push r8
00007a66921dfd66  push r9
00007a66921dfd68  push r10
00007a66921dfd6a  push r11
00007a66921dfd6c  sub rsp, 0xF0
00007a66921dfd73  vmovaps [rsp], xmm0
00007a66921dfd78  vmovaps [rsp+0x10], xmm1
00007a66921dfd7e  vmovaps [rsp+0x20], xmm2
00007a66921dfd84  vmovaps [rsp+0x30], xmm3
00007a66921dfd8a  vmovaps [rsp+0x40], xmm4
00007a66921dfd90  vmovaps [rsp+0x50], xmm5
00007a66921dfd96  vmovaps [rsp+0x60], xmm6
00007a66921dfd9c  vmovaps [rsp+0x70], xmm7
00007a66921dfda2  vmovaps [rsp+0x80], xmm8
00007a66921dfdab  vmovaps [rsp+0x90], xmm9
00007a66921dfdb4  vmovaps [rsp+0xA0], xmm10
00007a66921dfdbd  vmovaps [rsp+0xB0], xmm12
00007a66921dfdc6  vmovaps [rsp+0xC0], xmm13
00007a66921dfdcf  vmovaps [rsp+0xD0], xmm14
00007a66921dfdd8  vmovaps [rsp+0xE0], xmm15
00007a66921dfde1  sub rsp, 0x30
00007a66921dfde5  movaps [rsp], xmm11
00007a66921dfdea  movaps [rsp+0x10], xmm10
00007a66921dfdf0  movaps [rsp+0x20], xmm6
00007a66921dfdf5  lea rdi, [rsp]
00007a66921dfdf9  mov esi, 0x00
00007a66921dfdfe  mov rax, 0x635346DC7530
00007a66921dfe08  call rax
00007a66921dfe0a  movaps xmm11, [rsp]
00007a66921dfe0f  add rsp, 0x30
00007a66921dfe13  vmovaps xmm0, [rsp]
00007a66921dfe18  vmovaps xmm1, [rsp+0x10]
00007a66921dfe1e  vmovaps xmm2, [rsp+0x20]
00007a66921dfe24  vmovaps xmm3, [rsp+0x30]
00007a66921dfe2a  vmovaps xmm4, [rsp+0x40]
00007a66921dfe30  vmovaps xmm5, [rsp+0x50]
00007a66921dfe36  vmovaps xmm6, [rsp+0x60]
00007a66921dfe3c  vmovaps xmm7, [rsp+0x70]
00007a66921dfe42  vmovaps xmm8, [rsp+0x80]
00007a66921dfe4b  vmovaps xmm9, [rsp+0x90]
00007a66921dfe54  vmovaps xmm10, [rsp+0xA0]
00007a66921dfe5d  vmovaps xmm12, [rsp+0xB0]
00007a66921dfe66  vmovaps xmm13, [rsp+0xC0]
00007a66921dfe6f  vmovaps xmm14, [rsp+0xD0]
00007a66921dfe78  vmovaps xmm15, [rsp+0xE0]
00007a66921dfe81  add rsp, 0xF0
00007a66921dfe88  pop r11
00007a66921dfe8a  pop r10
00007a66921dfe8c  pop r9
00007a66921dfe8e  pop r8
00007a66921dfe90  pop rsi
00007a66921dfe91  pop rdi
00007a66921dfe92  pop rdx
00007a66921dfe93  pop rcx
00007a66921dfe94  pop rax
00007a66921dfe95  add rsp, 0x08
00007a66921dfe99  jmp 0x00007A66921DC520
00007a66921dfe9e  sub rsp, 0x08
00007a66921dfea2  push rax
00007a66921dfea3  push rcx
00007a66921dfea4  push rdx
00007a66921dfea5  push rdi
00007a66921dfea6  push rsi
00007a66921dfea7  push r8
00007a66921dfea9  push r9
00007a66921dfeab  push r10
00007a66921dfead  push r11
00007a66921dfeaf  sub rsp, 0xF0
00007a66921dfeb6  vmovaps [rsp], xmm0
00007a66921dfebb  vmovaps [rsp+0x10], xmm1
00007a66921dfec1  vmovaps [rsp+0x20], xmm2
00007a66921dfec7  vmovaps [rsp+0x30], xmm3
00007a66921dfecd  vmovaps [rsp+0x40], xmm4
00007a66921dfed3  vmovaps [rsp+0x50], xmm5
00007a66921dfed9  vmovaps [rsp+0x60], xmm6
00007a66921dfedf  vmovaps [rsp+0x70], xmm7
00007a66921dfee5  vmovaps [rsp+0x80], xmm8
00007a66921dfeee  vmovaps [rsp+0x90], xmm9
00007a66921dfef7  vmovaps [rsp+0xA0], xmm11
00007a66921dff00  vmovaps [rsp+0xB0], xmm12
00007a66921dff09  vmovaps [rsp+0xC0], xmm13
00007a66921dff12  vmovaps [rsp+0xD0], xmm14
00007a66921dff1b  vmovaps [rsp+0xE0], xmm15
00007a66921dff24  sub rsp, 0x30
00007a66921dff28  movaps [rsp], xmm10
00007a66921dff2d  movaps [rsp+0x10], xmm14
00007a66921dff33  movaps [rsp+0x20], xmm4
00007a66921dff38  lea rdi, [rsp]
00007a66921dff3c  mov esi, 0x00
00007a66921dff41  mov rax, 0x635346DC7530
00007a66921dff4b  call rax
00007a66921dff4d  movaps xmm10, [rsp]
00007a66921dff52  add rsp, 0x30
00007a66921dff56  vmovaps xmm0, [rsp]
00007a66921dff5b  vmovaps xmm1, [rsp+0x10]
00007a66921dff61  vmovaps xmm2, [rsp+0x20]
00007a66921dff67  vmovaps xmm3, [rsp+0x30]
00007a66921dff6d  vmovaps xmm4, [rsp+0x40]
00007a66921dff73  vmovaps xmm5, [rsp+0x50]
00007a66921dff79  vmovaps xmm6, [rsp+0x60]
00007a66921dff7f  vmovaps xmm7, [rsp+0x70]
00007a66921dff85  vmovaps xmm8, [rsp+0x80]
00007a66921dff8e  vmovaps xmm9, [rsp+0x90]
00007a66921dff97  vmovaps xmm11, [rsp+0xA0]
00007a66921dffa0  vmovaps xmm12, [rsp+0xB0]
00007a66921dffa9  vmovaps xmm13, [rsp+0xC0]
00007a66921dffb2  vmovaps xmm14, [rsp+0xD0]
00007a66921dffbb  vmovaps xmm15, [rsp+0xE0]
00007a66921dffc4  add rsp, 0xF0
00007a66921dffcb  pop r11
00007a66921dffcd  pop r10
00007a66921dffcf  pop r9
00007a66921dffd1  pop r8
00007a66921dffd3  pop rsi
00007a66921dffd4  pop rdi
00007a66921dffd5  pop rdx
00007a66921dffd6  pop rcx
00007a66921dffd7  pop rax
00007a66921dffd8  add rsp, 0x08
00007a66921dffdc  jmp 0x00007A66921DC53B
00007a66921dffe1  sub rsp, 0x08
00007a66921dffe5  push rax
00007a66921dffe6  push rcx
00007a66921dffe7  push rdx
00007a66921dffe8  push rdi
00007a66921dffe9  push rsi
00007a66921dffea  push r8
00007a66921dffec  push r9
00007a66921dffee  push r10
00007a66921dfff0  push r11
00007a66921dfff2  sub rsp, 0xF0
00007a66921dfff9  vmovaps [rsp], xmm0
00007a66921dfffe  vmovaps [rsp+0x10], xmm1
00007a66921e0004  vmovaps [rsp+0x20], xmm2
00007a66921e000a  vmovaps [rsp+0x30], xmm3
00007a66921e0010  vmovaps [rsp+0x40], xmm4
00007a66921e0016  vmovaps [rsp+0x50], xmm5
00007a66921e001c  vmovaps [rsp+0x60], xmm6
00007a66921e0022  vmovaps [rsp+0x70], xmm7
00007a66921e0028  vmovaps [rsp+0x80], xmm9
00007a66921e0031  vmovaps [rsp+0x90], xmm10
00007a66921e003a  vmovaps [rsp+0xA0], xmm11
00007a66921e0043  vmovaps [rsp+0xB0], xmm12
00007a66921e004c  vmovaps [rsp+0xC0], xmm13
00007a66921e0055  vmovaps [rsp+0xD0], xmm14
00007a66921e005e  vmovaps [rsp+0xE0], xmm15
00007a66921e0067  sub rsp, 0x30
00007a66921e006b  movaps [rsp], xmm8
00007a66921e0070  movaps [rsp+0x10], xmm1
00007a66921e0075  movaps [rsp+0x20], xmm14
00007a66921e007b  lea rdi, [rsp]
00007a66921e007f  mov esi, 0x00
00007a66921e0084  mov rax, 0x635346DC7530
00007a66921e008e  call rax
00007a66921e0090  movaps xmm8, [rsp]
00007a66921e0095  add rsp, 0x30
00007a66921e0099  vmovaps xmm0, [rsp]
00007a66921e009e  vmovaps xmm1, [rsp+0x10]
00007a66921e00a4  vmovaps xmm2, [rsp+0x20]
00007a66921e00aa  vmovaps xmm3, [rsp+0x30]
00007a66921e00b0  vmovaps xmm4, [rsp+0x40]
00007a66921e00b6  vmovaps xmm5, [rsp+0x50]
00007a66921e00bc  vmovaps xmm6, [rsp+0x60]
00007a66921e00c2  vmovaps xmm7, [rsp+0x70]
00007a66921e00c8  vmovaps xmm9, [rsp+0x80]
00007a66921e00d1  vmovaps xmm10, [rsp+0x90]
00007a66921e00da  vmovaps xmm11, [rsp+0xA0]
00007a66921e00e3  vmovaps xmm12, [rsp+0xB0]
00007a66921e00ec  vmovaps xmm13, [rsp+0xC0]
00007a66921e00f5  vmovaps xmm14, [rsp+0xD0]
00007a66921e00fe  vmovaps xmm15, [rsp+0xE0]
00007a66921e0107  add rsp, 0xF0
00007a66921e010e  pop r11
00007a66921e0110  pop r10
00007a66921e0112  pop r9
00007a66921e0114  pop r8
00007a66921e0116  pop rsi
00007a66921e0117  pop rdi
00007a66921e0118  pop rdx
00007a66921e0119  pop rcx
00007a66921e011a  pop rax
00007a66921e011b  add rsp, 0x08
00007a66921e011f  jmp 0x00007A66921DC561
00007a66921e0124  sub rsp, 0x08
00007a66921e0128  push rax
00007a66921e0129  push rcx
00007a66921e012a  push rdx
00007a66921e012b  push rdi
00007a66921e012c  push rsi
00007a66921e012d  push r8
00007a66921e012f  push r9
00007a66921e0131  push r10
00007a66921e0133  push r11
00007a66921e0135  sub rsp, 0xF0
00007a66921e013c  vmovaps [rsp], xmm0
00007a66921e0141  vmovaps [rsp+0x10], xmm1
00007a66921e0147  vmovaps [rsp+0x20], xmm2
00007a66921e014d  vmovaps [rsp+0x30], xmm3
00007a66921e0153  vmovaps [rsp+0x40], xmm4
00007a66921e0159  vmovaps [rsp+0x50], xmm5
00007a66921e015f  vmovaps [rsp+0x60], xmm7
00007a66921e0165  vmovaps [rsp+0x70], xmm8
00007a66921e016b  vmovaps [rsp+0x80], xmm9
00007a66921e0174  vmovaps [rsp+0x90], xmm10
00007a66921e017d  vmovaps [rsp+0xA0], xmm11
00007a66921e0186  vmovaps [rsp+0xB0], xmm12
00007a66921e018f  vmovaps [rsp+0xC0], xmm13
00007a66921e0198  vmovaps [rsp+0xD0], xmm14
00007a66921e01a1  vmovaps [rsp+0xE0], xmm15
00007a66921e01aa  sub rsp, 0x30
00007a66921e01ae  movaps [rsp], xmm6
00007a66921e01b2  movaps [rsp+0x10], xmm1
00007a66921e01b7  movaps [rsp+0x20], xmm14
00007a66921e01bd  lea rdi, [rsp]
00007a66921e01c1  mov esi, 0x00
00007a66921e01c6  mov rax, 0x635346DC7530
00007a66921e01d0  call rax
00007a66921e01d2  movaps xmm6, [rsp]
00007a66921e01d6  add rsp, 0x30
00007a66921e01da  vmovaps xmm0, [rsp]
00007a66921e01df  vmovaps xmm1, [rsp+0x10]
00007a66921e01e5  vmovaps xmm2, [rsp+0x20]
00007a66921e01eb  vmovaps xmm3, [rsp+0x30]
00007a66921e01f1  vmovaps xmm4, [rsp+0x40]
00007a66921e01f7  vmovaps xmm5, [rsp+0x50]
00007a66921e01fd  vmovaps xmm7, [rsp+0x60]
00007a66921e0203  vmovaps xmm8, [rsp+0x70]
00007a66921e0209  vmovaps xmm9, [rsp+0x80]
00007a66921e0212  vmovaps xmm10, [rsp+0x90]
00007a66921e021b  vmovaps xmm11, [rsp+0xA0]
00007a66921e0224  vmovaps xmm12, [rsp+0xB0]
00007a66921e022d  vmovaps xmm13, [rsp+0xC0]
00007a66921e0236  vmovaps xmm14, [rsp+0xD0]
00007a66921e023f  vmovaps xmm15, [rsp+0xE0]
00007a66921e0248  add rsp, 0xF0
00007a66921e024f  pop r11
00007a66921e0251  pop r10
00007a66921e0253  pop r9
00007a66921e0255  pop r8
00007a66921e0257  pop rsi
00007a66921e0258  pop rdi
00007a66921e0259  pop rdx
00007a66921e025a  pop rcx
00007a66921e025b  pop rax
00007a66921e025c  add rsp, 0x08
00007a66921e0260  jmp 0x00007A66921DC58D
00007a66921e0265  sub rsp, 0x08
00007a66921e0269  push rax
00007a66921e026a  push rcx
00007a66921e026b  push rdx
00007a66921e026c  push rdi
00007a66921e026d  push rsi
00007a66921e026e  push r8
00007a66921e0270  push r9
00007a66921e0272  push r10
00007a66921e0274  push r11
00007a66921e0276  sub rsp, 0xF0
00007a66921e027d  vmovaps [rsp], xmm0
00007a66921e0282  vmovaps [rsp+0x10], xmm1
00007a66921e0288  vmovaps [rsp+0x20], xmm2
00007a66921e028e  vmovaps [rsp+0x30], xmm3
00007a66921e0294  vmovaps [rsp+0x40], xmm4
00007a66921e029a  vmovaps [rsp+0x50], xmm5
00007a66921e02a0  vmovaps [rsp+0x60], xmm6
00007a66921e02a6  vmovaps [rsp+0x70], xmm7
00007a66921e02ac  vmovaps [rsp+0x80], xmm8
00007a66921e02b5  vmovaps [rsp+0x90], xmm9
00007a66921e02be  vmovaps [rsp+0xA0], xmm10
00007a66921e02c7  vmovaps [rsp+0xB0], xmm11
00007a66921e02d0  vmovaps [rsp+0xC0], xmm12
00007a66921e02d9  vmovaps [rsp+0xD0], xmm13
00007a66921e02e2  vmovaps [rsp+0xE0], xmm15
00007a66921e02eb  sub rsp, 0x30
00007a66921e02ef  movaps [rsp], xmm14
00007a66921e02f4  movaps [rsp+0x10], xmm12
00007a66921e02fa  movaps [rsp+0x20], xmm1
00007a66921e02ff  lea rdi, [rsp]
00007a66921e0303  mov esi, 0x00
00007a66921e0308  mov rax, 0x635346DC7530
00007a66921e0312  call rax
00007a66921e0314  movaps xmm14, [rsp]
00007a66921e0319  add rsp, 0x30
00007a66921e031d  vmovaps xmm0, [rsp]
00007a66921e0322  vmovaps xmm1, [rsp+0x10]
00007a66921e0328  vmovaps xmm2, [rsp+0x20]
00007a66921e032e  vmovaps xmm3, [rsp+0x30]
00007a66921e0334  vmovaps xmm4, [rsp+0x40]
00007a66921e033a  vmovaps xmm5, [rsp+0x50]
00007a66921e0340  vmovaps xmm6, [rsp+0x60]
00007a66921e0346  vmovaps xmm7, [rsp+0x70]
00007a66921e034c  vmovaps xmm8, [rsp+0x80]
00007a66921e0355  vmovaps xmm9, [rsp+0x90]
00007a66921e035e  vmovaps xmm10, [rsp+0xA0]
00007a66921e0367  vmovaps xmm11, [rsp+0xB0]
00007a66921e0370  vmovaps xmm12, [rsp+0xC0]
00007a66921e0379  vmovaps xmm13, [rsp+0xD0]
00007a66921e0382  vmovaps xmm15, [rsp+0xE0]
00007a66921e038b  add rsp, 0xF0
00007a66921e0392  pop r11
00007a66921e0394  pop r10
00007a66921e0396  pop r9
00007a66921e0398  pop r8
00007a66921e039a  pop rsi
00007a66921e039b  pop rdi
00007a66921e039c  pop rdx
00007a66921e039d  pop rcx
00007a66921e039e  pop rax
00007a66921e039f  add rsp, 0x08
00007a66921e03a3  jmp 0x00007A66921DC5B3
00007a66921e03a8  sub rsp, 0x08
00007a66921e03ac  push rax
00007a66921e03ad  push rcx
00007a66921e03ae  push rdx
00007a66921e03af  push rdi
00007a66921e03b0  push rsi
00007a66921e03b1  push r8
00007a66921e03b3  push r9
00007a66921e03b5  push r10
00007a66921e03b7  push r11
00007a66921e03b9  sub rsp, 0xF0
00007a66921e03c0  vmovaps [rsp], xmm0
00007a66921e03c5  vmovaps [rsp+0x10], xmm2
00007a66921e03cb  vmovaps [rsp+0x20], xmm3
00007a66921e03d1  vmovaps [rsp+0x30], xmm4
00007a66921e03d7  vmovaps [rsp+0x40], xmm5
00007a66921e03dd  vmovaps [rsp+0x50], xmm6
00007a66921e03e3  vmovaps [rsp+0x60], xmm7
00007a66921e03e9  vmovaps [rsp+0x70], xmm8
00007a66921e03ef  vmovaps [rsp+0x80], xmm9
00007a66921e03f8  vmovaps [rsp+0x90], xmm10
00007a66921e0401  vmovaps [rsp+0xA0], xmm11
00007a66921e040a  vmovaps [rsp+0xB0], xmm12
00007a66921e0413  vmovaps [rsp+0xC0], xmm13
00007a66921e041c  vmovaps [rsp+0xD0], xmm14
00007a66921e0425  vmovaps [rsp+0xE0], xmm15
00007a66921e042e  sub rsp, 0x30
00007a66921e0432  movaps [rsp], xmm1
00007a66921e0436  movaps [rsp+0x10], xmm13
00007a66921e043c  movaps [rsp+0x20], xmm9
00007a66921e0442  lea rdi, [rsp]
00007a66921e0446  mov esi, 0x00
00007a66921e044b  mov rax, 0x635346DC7530
00007a66921e0455  call rax
00007a66921e0457  movaps xmm1, [rsp]
00007a66921e045b  add rsp, 0x30
00007a66921e045f  vmovaps xmm0, [rsp]
00007a66921e0464  vmovaps xmm2, [rsp+0x10]
00007a66921e046a  vmovaps xmm3, [rsp+0x20]
00007a66921e0470  vmovaps xmm4, [rsp+0x30]
00007a66921e0476  vmovaps xmm5, [rsp+0x40]
00007a66921e047c  vmovaps xmm6, [rsp+0x50]
00007a66921e0482  vmovaps xmm7, [rsp+0x60]
00007a66921e0488  vmovaps xmm8, [rsp+0x70]
00007a66921e048e  vmovaps xmm9, [rsp+0x80]
00007a66921e0497  vmovaps xmm10, [rsp+0x90]
00007a66921e04a0  vmovaps xmm11, [rsp+0xA0]
00007a66921e04a9  vmovaps xmm12, [rsp+0xB0]
00007a66921e04b2  vmovaps xmm13, [rsp+0xC0]
00007a66921e04bb  vmovaps xmm14, [rsp+0xD0]
00007a66921e04c4  vmovaps xmm15, [rsp+0xE0]
00007a66921e04cd  add rsp, 0xF0
00007a66921e04d4  pop r11
00007a66921e04d6  pop r10
00007a66921e04d8  pop r9
00007a66921e04da  pop r8
00007a66921e04dc  pop rsi
00007a66921e04dd  pop rdi
00007a66921e04de  pop rdx
00007a66921e04df  pop rcx
00007a66921e04e0  pop rax
00007a66921e04e1  add rsp, 0x08
00007a66921e04e5  jmp 0x00007A66921DC5CD
00007a66921e04ea  sub rsp, 0x08
00007a66921e04ee  push rax
00007a66921e04ef  push rcx
00007a66921e04f0  push rdx
00007a66921e04f1  push rdi
00007a66921e04f2  push rsi
00007a66921e04f3  push r8
00007a66921e04f5  push r9
00007a66921e04f7  push r10
00007a66921e04f9  push r11
00007a66921e04fb  sub rsp, 0xF0
00007a66921e0502  vmovaps [rsp], xmm0
00007a66921e0507  vmovaps [rsp+0x10], xmm1
00007a66921e050d  vmovaps [rsp+0x20], xmm2
00007a66921e0513  vmovaps [rsp+0x30], xmm3
00007a66921e0519  vmovaps [rsp+0x40], xmm4
00007a66921e051f  vmovaps [rsp+0x50], xmm5
00007a66921e0525  vmovaps [rsp+0x60], xmm6
00007a66921e052b  vmovaps [rsp+0x70], xmm7
00007a66921e0531  vmovaps [rsp+0x80], xmm8
00007a66921e053a  vmovaps [rsp+0x90], xmm9
00007a66921e0543  vmovaps [rsp+0xA0], xmm10
00007a66921e054c  vmovaps [rsp+0xB0], xmm11
00007a66921e0555  vmovaps [rsp+0xC0], xmm13
00007a66921e055e  vmovaps [rsp+0xD0], xmm14
00007a66921e0567  vmovaps [rsp+0xE0], xmm15
00007a66921e0570  sub rsp, 0x30
00007a66921e0574  movaps [rsp], xmm12
00007a66921e0579  movaps [rsp+0x10], xmm7
00007a66921e057e  movaps [rsp+0x20], xmm13
00007a66921e0584  lea rdi, [rsp]
00007a66921e0588  mov esi, 0x00
00007a66921e058d  mov rax, 0x635346DC7530
00007a66921e0597  call rax
00007a66921e0599  movaps xmm12, [rsp]
00007a66921e059e  add rsp, 0x30
00007a66921e05a2  vmovaps xmm0, [rsp]
00007a66921e05a7  vmovaps xmm1, [rsp+0x10]
00007a66921e05ad  vmovaps xmm2, [rsp+0x20]
00007a66921e05b3  vmovaps xmm3, [rsp+0x30]
00007a66921e05b9  vmovaps xmm4, [rsp+0x40]
00007a66921e05bf  vmovaps xmm5, [rsp+0x50]
00007a66921e05c5  vmovaps xmm6, [rsp+0x60]
00007a66921e05cb  vmovaps xmm7, [rsp+0x70]
00007a66921e05d1  vmovaps xmm8, [rsp+0x80]
00007a66921e05da  vmovaps xmm9, [rsp+0x90]
00007a66921e05e3  vmovaps xmm10, [rsp+0xA0]
00007a66921e05ec  vmovaps xmm11, [rsp+0xB0]
00007a66921e05f5  vmovaps xmm13, [rsp+0xC0]
00007a66921e05fe  vmovaps xmm14, [rsp+0xD0]
00007a66921e0607  vmovaps xmm15, [rsp+0xE0]
00007a66921e0610  add rsp, 0xF0
00007a66921e0617  pop r11
00007a66921e0619  pop r10
00007a66921e061b  pop r9
00007a66921e061d  pop r8
00007a66921e061f  pop rsi
00007a66921e0620  pop rdi
00007a66921e0621  pop rdx
00007a66921e0622  pop rcx
00007a66921e0623  pop rax
00007a66921e0624  add rsp, 0x08
00007a66921e0628  jmp 0x00007A66921DC5F4
00007a66921e062d  sub rsp, 0x08
00007a66921e0631  push rax
00007a66921e0632  push rcx
00007a66921e0633  push rdx
00007a66921e0634  push rdi
00007a66921e0635  push rsi
00007a66921e0636  push r8
00007a66921e0638  push r9
00007a66921e063a  push r10
00007a66921e063c  push r11
00007a66921e063e  sub rsp, 0xF0
00007a66921e0645  vmovaps [rsp], xmm0
00007a66921e064a  vmovaps [rsp+0x10], xmm1
00007a66921e0650  vmovaps [rsp+0x20], xmm2
00007a66921e0656  vmovaps [rsp+0x30], xmm3
00007a66921e065c  vmovaps [rsp+0x40], xmm4
00007a66921e0662  vmovaps [rsp+0x50], xmm5
00007a66921e0668  vmovaps [rsp+0x60], xmm6
00007a66921e066e  vmovaps [rsp+0x70], xmm7
00007a66921e0674  vmovaps [rsp+0x80], xmm8
00007a66921e067d  vmovaps [rsp+0x90], xmm9
00007a66921e0686  vmovaps [rsp+0xA0], xmm10
00007a66921e068f  vmovaps [rsp+0xB0], xmm11
00007a66921e0698  vmovaps [rsp+0xC0], xmm12
00007a66921e06a1  vmovaps [rsp+0xD0], xmm14
00007a66921e06aa  vmovaps [rsp+0xE0], xmm15
00007a66921e06b3  sub rsp, 0x30
00007a66921e06b7  movaps [rsp], xmm13
00007a66921e06bc  movaps [rsp+0x10], xmm15
00007a66921e06c2  movaps [rsp+0x20], xmm8
00007a66921e06c8  lea rdi, [rsp]
00007a66921e06cc  mov esi, 0x00
00007a66921e06d1  mov rax, 0x635346DC7530
00007a66921e06db  call rax
00007a66921e06dd  movaps xmm13, [rsp]
00007a66921e06e2  add rsp, 0x30
00007a66921e06e6  vmovaps xmm0, [rsp]
00007a66921e06eb  vmovaps xmm1, [rsp+0x10]
00007a66921e06f1  vmovaps xmm2, [rsp+0x20]
00007a66921e06f7  vmovaps xmm3, [rsp+0x30]
00007a66921e06fd  vmovaps xmm4, [rsp+0x40]
00007a66921e0703  vmovaps xmm5, [rsp+0x50]
00007a66921e0709  vmovaps xmm6, [rsp+0x60]
00007a66921e070f  vmovaps xmm7, [rsp+0x70]
00007a66921e0715  vmovaps xmm8, [rsp+0x80]
00007a66921e071e  vmovaps xmm9, [rsp+0x90]
00007a66921e0727  vmovaps xmm10, [rsp+0xA0]
00007a66921e0730  vmovaps xmm11, [rsp+0xB0]
00007a66921e0739  vmovaps xmm12, [rsp+0xC0]
00007a66921e0742  vmovaps xmm14, [rsp+0xD0]
00007a66921e074b  vmovaps xmm15, [rsp+0xE0]
00007a66921e0754  add rsp, 0xF0
00007a66921e075b  pop r11
00007a66921e075d  pop r10
00007a66921e075f  pop r9
00007a66921e0761  pop r8
00007a66921e0763  pop rsi
00007a66921e0764  pop rdi
00007a66921e0765  pop rdx
00007a66921e0766  pop rcx
00007a66921e0767  pop rax
00007a66921e0768  add rsp, 0x08
00007a66921e076c  jmp 0x00007A66921DC60F
00007a66921e0771  sub rsp, 0x08
00007a66921e0775  push rax
00007a66921e0776  push rcx
00007a66921e0777  push rdx
00007a66921e0778  push rdi
00007a66921e0779  push rsi
00007a66921e077a  push r8
00007a66921e077c  push r9
00007a66921e077e  push r10
00007a66921e0780  push r11
00007a66921e0782  sub rsp, 0xF0
00007a66921e0789  vmovaps [rsp], xmm0
00007a66921e078e  vmovaps [rsp+0x10], xmm1
00007a66921e0794  vmovaps [rsp+0x20], xmm2
00007a66921e079a  vmovaps [rsp+0x30], xmm3
00007a66921e07a0  vmovaps [rsp+0x40], xmm4
00007a66921e07a6  vmovaps [rsp+0x50], xmm5
00007a66921e07ac  vmovaps [rsp+0x60], xmm6
00007a66921e07b2  vmovaps [rsp+0x70], xmm7
00007a66921e07b8  vmovaps [rsp+0x80], xmm9
00007a66921e07c1  vmovaps [rsp+0x90], xmm10
00007a66921e07ca  vmovaps [rsp+0xA0], xmm11
00007a66921e07d3  vmovaps [rsp+0xB0], xmm12
00007a66921e07dc  vmovaps [rsp+0xC0], xmm13
00007a66921e07e5  vmovaps [rsp+0xD0], xmm14
00007a66921e07ee  vmovaps [rsp+0xE0], xmm15
00007a66921e07f7  sub rsp, 0x30
00007a66921e07fb  movaps [rsp], xmm8
00007a66921e0800  movaps [rsp+0x10], xmm15
00007a66921e0806  movaps [rsp+0x20], xmm9
00007a66921e080c  lea rdi, [rsp]
00007a66921e0810  mov esi, 0x00
00007a66921e0815  mov rax, 0x635346DC7530
00007a66921e081f  call rax
00007a66921e0821  movaps xmm8, [rsp]
00007a66921e0826  add rsp, 0x30
00007a66921e082a  vmovaps xmm0, [rsp]
00007a66921e082f  vmovaps xmm1, [rsp+0x10]
00007a66921e0835  vmovaps xmm2, [rsp+0x20]
00007a66921e083b  vmovaps xmm3, [rsp+0x30]
00007a66921e0841  vmovaps xmm4, [rsp+0x40]
00007a66921e0847  vmovaps xmm5, [rsp+0x50]
00007a66921e084d  vmovaps xmm6, [rsp+0x60]
00007a66921e0853  vmovaps xmm7, [rsp+0x70]
00007a66921e0859  vmovaps xmm9, [rsp+0x80]
00007a66921e0862  vmovaps xmm10, [rsp+0x90]
00007a66921e086b  vmovaps xmm11, [rsp+0xA0]
00007a66921e0874  vmovaps xmm12, [rsp+0xB0]
00007a66921e087d  vmovaps xmm13, [rsp+0xC0]
00007a66921e0886  vmovaps xmm14, [rsp+0xD0]
00007a66921e088f  vmovaps xmm15, [rsp+0xE0]
00007a66921e0898  add rsp, 0xF0
00007a66921e089f  pop r11
00007a66921e08a1  pop r10
00007a66921e08a3  pop r9
00007a66921e08a5  pop r8
00007a66921e08a7  pop rsi
00007a66921e08a8  pop rdi
00007a66921e08a9  pop rdx
00007a66921e08aa  pop rcx
00007a66921e08ab  pop rax
00007a66921e08ac  add rsp, 0x08
00007a66921e08b0  jmp 0x00007A66921DC63D
00007a66921e08b5  sub rsp, 0x08
00007a66921e08b9  push rax
00007a66921e08ba  push rcx
00007a66921e08bb  push rdx
00007a66921e08bc  push rdi
00007a66921e08bd  push rsi
00007a66921e08be  push r8
00007a66921e08c0  push r9
00007a66921e08c2  push r10
00007a66921e08c4  push r11
00007a66921e08c6  sub rsp, 0xF0
00007a66921e08cd  vmovaps [rsp], xmm0
00007a66921e08d2  vmovaps [rsp+0x10], xmm1
00007a66921e08d8  vmovaps [rsp+0x20], xmm2
00007a66921e08de  vmovaps [rsp+0x30], xmm3
00007a66921e08e4  vmovaps [rsp+0x40], xmm4
00007a66921e08ea  vmovaps [rsp+0x50], xmm5
00007a66921e08f0  vmovaps [rsp+0x60], xmm6
00007a66921e08f6  vmovaps [rsp+0x70], xmm7
00007a66921e08fc  vmovaps [rsp+0x80], xmm8
00007a66921e0905  vmovaps [rsp+0x90], xmm9
00007a66921e090e  vmovaps [rsp+0xA0], xmm10
00007a66921e0917  vmovaps [rsp+0xB0], xmm11
00007a66921e0920  vmovaps [rsp+0xC0], xmm12
00007a66921e0929  vmovaps [rsp+0xD0], xmm13
00007a66921e0932  vmovaps [rsp+0xE0], xmm14
00007a66921e093b  sub rsp, 0x30
00007a66921e093f  movaps [rsp], xmm15
00007a66921e0944  movaps [rsp+0x10], xmm11
00007a66921e094a  movaps [rsp+0x20], xmm6
00007a66921e094f  lea rdi, [rsp]
00007a66921e0953  mov esi, 0x00
00007a66921e0958  mov rax, 0x635346DC7530
00007a66921e0962  call rax
00007a66921e0964  movaps xmm15, [rsp]
00007a66921e0969  add rsp, 0x30
00007a66921e096d  vmovaps xmm0, [rsp]
00007a66921e0972  vmovaps xmm1, [rsp+0x10]
00007a66921e0978  vmovaps xmm2, [rsp+0x20]
00007a66921e097e  vmovaps xmm3, [rsp+0x30]
00007a66921e0984  vmovaps xmm4, [rsp+0x40]
00007a66921e098a  vmovaps xmm5, [rsp+0x50]
00007a66921e0990  vmovaps xmm6, [rsp+0x60]
00007a66921e0996  vmovaps xmm7, [rsp+0x70]
00007a66921e099c  vmovaps xmm8, [rsp+0x80]
00007a66921e09a5  vmovaps xmm9, [rsp+0x90]
00007a66921e09ae  vmovaps xmm10, [rsp+0xA0]
00007a66921e09b7  vmovaps xmm11, [rsp+0xB0]
00007a66921e09c0  vmovaps xmm12, [rsp+0xC0]
00007a66921e09c9  vmovaps xmm13, [rsp+0xD0]
00007a66921e09d2  vmovaps xmm14, [rsp+0xE0]
00007a66921e09db  add rsp, 0xF0
00007a66921e09e2  pop r11
00007a66921e09e4  pop r10
00007a66921e09e6  pop r9
00007a66921e09e8  pop r8
00007a66921e09ea  pop rsi
00007a66921e09eb  pop rdi
00007a66921e09ec  pop rdx
00007a66921e09ed  pop rcx
00007a66921e09ee  pop rax
00007a66921e09ef  add rsp, 0x08
00007a66921e09f3  jmp 0x00007A66921DC658
00007a66921e09f8  sub rsp, 0x08
00007a66921e09fc  push rax
00007a66921e09fd  push rcx
00007a66921e09fe  push rdx
00007a66921e09ff  push rdi
00007a66921e0a00  push rsi
00007a66921e0a01  push r8
00007a66921e0a03  push r9
00007a66921e0a05  push r10
00007a66921e0a07  push r11
00007a66921e0a09  sub rsp, 0xF0
00007a66921e0a10  vmovaps [rsp], xmm0
00007a66921e0a15  vmovaps [rsp+0x10], xmm1
00007a66921e0a1b  vmovaps [rsp+0x20], xmm2
00007a66921e0a21  vmovaps [rsp+0x30], xmm3
00007a66921e0a27  vmovaps [rsp+0x40], xmm4
00007a66921e0a2d  vmovaps [rsp+0x50], xmm5
00007a66921e0a33  vmovaps [rsp+0x60], xmm6
00007a66921e0a39  vmovaps [rsp+0x70], xmm8
00007a66921e0a3f  vmovaps [rsp+0x80], xmm9
00007a66921e0a48  vmovaps [rsp+0x90], xmm10
00007a66921e0a51  vmovaps [rsp+0xA0], xmm11
00007a66921e0a5a  vmovaps [rsp+0xB0], xmm12
00007a66921e0a63  vmovaps [rsp+0xC0], xmm13
00007a66921e0a6c  vmovaps [rsp+0xD0], xmm14
00007a66921e0a75  vmovaps [rsp+0xE0], xmm15
00007a66921e0a7e  sub rsp, 0x30
00007a66921e0a82  movaps [rsp], xmm7
00007a66921e0a86  movaps [rsp+0x10], xmm11
00007a66921e0a8c  movaps [rsp+0x20], xmm9
00007a66921e0a92  lea rdi, [rsp]
00007a66921e0a96  mov esi, 0x00
00007a66921e0a9b  mov rax, 0x635346DC7530
00007a66921e0aa5  call rax
00007a66921e0aa7  movaps xmm7, [rsp]
00007a66921e0aab  add rsp, 0x30
00007a66921e0aaf  vmovaps xmm0, [rsp]
00007a66921e0ab4  vmovaps xmm1, [rsp+0x10]
00007a66921e0aba  vmovaps xmm2, [rsp+0x20]
00007a66921e0ac0  vmovaps xmm3, [rsp+0x30]
00007a66921e0ac6  vmovaps xmm4, [rsp+0x40]
00007a66921e0acc  vmovaps xmm5, [rsp+0x50]
00007a66921e0ad2  vmovaps xmm6, [rsp+0x60]
00007a66921e0ad8  vmovaps xmm8, [rsp+0x70]
00007a66921e0ade  vmovaps xmm9, [rsp+0x80]
00007a66921e0ae7  vmovaps xmm10, [rsp+0x90]
00007a66921e0af0  vmovaps xmm11, [rsp+0xA0]
00007a66921e0af9  vmovaps xmm12, [rsp+0xB0]
00007a66921e0b02  vmovaps xmm13, [rsp+0xC0]
00007a66921e0b0b  vmovaps xmm14, [rsp+0xD0]
00007a66921e0b14  vmovaps xmm15, [rsp+0xE0]
00007a66921e0b1d  add rsp, 0xF0
00007a66921e0b24  pop r11
00007a66921e0b26  pop r10
00007a66921e0b28  pop r9
00007a66921e0b2a  pop r8
00007a66921e0b2c  pop rsi
00007a66921e0b2d  pop rdi
00007a66921e0b2e  pop rdx
00007a66921e0b2f  pop rcx
00007a66921e0b30  pop rax
00007a66921e0b31  add rsp, 0x08
00007a66921e0b35  jmp 0x00007A66921DC685
00007a66921e0b3a  sub rsp, 0x08
00007a66921e0b3e  push rax
00007a66921e0b3f  push rcx
00007a66921e0b40  push rdx
00007a66921e0b41  push rdi
00007a66921e0b42  push rsi
00007a66921e0b43  push r8
00007a66921e0b45  push r9
00007a66921e0b47  push r10
00007a66921e0b49  push r11
00007a66921e0b4b  sub rsp, 0xF0
00007a66921e0b52  vmovaps [rsp], xmm0
00007a66921e0b57  vmovaps [rsp+0x10], xmm1
00007a66921e0b5d  vmovaps [rsp+0x20], xmm2
00007a66921e0b63  vmovaps [rsp+0x30], xmm3
00007a66921e0b69  vmovaps [rsp+0x40], xmm4
00007a66921e0b6f  vmovaps [rsp+0x50], xmm5
00007a66921e0b75  vmovaps [rsp+0x60], xmm6
00007a66921e0b7b  vmovaps [rsp+0x70], xmm7
00007a66921e0b81  vmovaps [rsp+0x80], xmm8
00007a66921e0b8a  vmovaps [rsp+0x90], xmm9
00007a66921e0b93  vmovaps [rsp+0xA0], xmm10
00007a66921e0b9c  vmovaps [rsp+0xB0], xmm12
00007a66921e0ba5  vmovaps [rsp+0xC0], xmm13
00007a66921e0bae  vmovaps [rsp+0xD0], xmm14
00007a66921e0bb7  vmovaps [rsp+0xE0], xmm15
00007a66921e0bc0  sub rsp, 0x30
00007a66921e0bc4  movaps [rsp], xmm11
00007a66921e0bc9  movaps [rsp+0x10], xmm10
00007a66921e0bcf  movaps [rsp+0x20], xmm14
00007a66921e0bd5  lea rdi, [rsp]
00007a66921e0bd9  mov esi, 0x00
00007a66921e0bde  mov rax, 0x635346DC7530
00007a66921e0be8  call rax
00007a66921e0bea  movaps xmm11, [rsp]
00007a66921e0bef  add rsp, 0x30
00007a66921e0bf3  vmovaps xmm0, [rsp]
00007a66921e0bf8  vmovaps xmm1, [rsp+0x10]
00007a66921e0bfe  vmovaps xmm2, [rsp+0x20]
00007a66921e0c04  vmovaps xmm3, [rsp+0x30]
00007a66921e0c0a  vmovaps xmm4, [rsp+0x40]
00007a66921e0c10  vmovaps xmm5, [rsp+0x50]
00007a66921e0c16  vmovaps xmm6, [rsp+0x60]
00007a66921e0c1c  vmovaps xmm7, [rsp+0x70]
00007a66921e0c22  vmovaps xmm8, [rsp+0x80]
00007a66921e0c2b  vmovaps xmm9, [rsp+0x90]
00007a66921e0c34  vmovaps xmm10, [rsp+0xA0]
00007a66921e0c3d  vmovaps xmm12, [rsp+0xB0]
00007a66921e0c46  vmovaps xmm13, [rsp+0xC0]
00007a66921e0c4f  vmovaps xmm14, [rsp+0xD0]
00007a66921e0c58  vmovaps xmm15, [rsp+0xE0]
00007a66921e0c61  add rsp, 0xF0
00007a66921e0c68  pop r11
00007a66921e0c6a  pop r10
00007a66921e0c6c  pop r9
00007a66921e0c6e  pop r8
00007a66921e0c70  pop rsi
00007a66921e0c71  pop rdi
00007a66921e0c72  pop rdx
00007a66921e0c73  pop rcx
00007a66921e0c74  pop rax
00007a66921e0c75  add rsp, 0x08
00007a66921e0c79  jmp 0x00007A66921DC6A0
00007a66921e0c7e  call 0x00007A66920C33A0
00007a66921e0c83  jmp 0x00007A66921DC6AA
00007a66921e0c88  sub rsp, 0x08
00007a66921e0c8c  push rax
00007a66921e0c8d  push rcx
00007a66921e0c8e  push rdx
00007a66921e0c8f  push rdi
00007a66921e0c90  push rsi
00007a66921e0c91  push r8
00007a66921e0c93  push r9
00007a66921e0c95  push r10
00007a66921e0c97  push r11
00007a66921e0c99  sub rsp, 0xF0
00007a66921e0ca0  vmovaps [rsp], xmm0
00007a66921e0ca5  vmovaps [rsp+0x10], xmm1
00007a66921e0cab  vmovaps [rsp+0x20], xmm2
00007a66921e0cb1  vmovaps [rsp+0x30], xmm3
00007a66921e0cb7  vmovaps [rsp+0x40], xmm4
00007a66921e0cbd  vmovaps [rsp+0x50], xmm5
00007a66921e0cc3  vmovaps [rsp+0x60], xmm6
00007a66921e0cc9  vmovaps [rsp+0x70], xmm7
00007a66921e0ccf  vmovaps [rsp+0x80], xmm8
00007a66921e0cd8  vmovaps [rsp+0x90], xmm9
00007a66921e0ce1  vmovaps [rsp+0xA0], xmm11
00007a66921e0cea  vmovaps [rsp+0xB0], xmm12
00007a66921e0cf3  vmovaps [rsp+0xC0], xmm13
00007a66921e0cfc  vmovaps [rsp+0xD0], xmm14
00007a66921e0d05  vmovaps [rsp+0xE0], xmm15
00007a66921e0d0e  sub rsp, 0x30
00007a66921e0d12  movaps [rsp], xmm10
00007a66921e0d17  movaps [rsp+0x10], xmm1
00007a66921e0d1c  movaps [rsp+0x20], xmm12
00007a66921e0d22  lea rdi, [rsp]
00007a66921e0d26  mov esi, 0x00
00007a66921e0d2b  mov rax, 0x635346DC7530
00007a66921e0d35  call rax
00007a66921e0d37  movaps xmm10, [rsp]
00007a66921e0d3c  add rsp, 0x30
00007a66921e0d40  vmovaps xmm0, [rsp]
00007a66921e0d45  vmovaps xmm1, [rsp+0x10]
00007a66921e0d4b  vmovaps xmm2, [rsp+0x20]
00007a66921e0d51  vmovaps xmm3, [rsp+0x30]
00007a66921e0d57  vmovaps xmm4, [rsp+0x40]
00007a66921e0d5d  vmovaps xmm5, [rsp+0x50]
00007a66921e0d63  vmovaps xmm6, [rsp+0x60]
00007a66921e0d69  vmovaps xmm7, [rsp+0x70]
00007a66921e0d6f  vmovaps xmm8, [rsp+0x80]
00007a66921e0d78  vmovaps xmm9, [rsp+0x90]
00007a66921e0d81  vmovaps xmm11, [rsp+0xA0]
00007a66921e0d8a  vmovaps xmm12, [rsp+0xB0]
00007a66921e0d93  vmovaps xmm13, [rsp+0xC0]
00007a66921e0d9c  vmovaps xmm14, [rsp+0xD0]
00007a66921e0da5  vmovaps xmm15, [rsp+0xE0]
00007a66921e0dae  add rsp, 0xF0
00007a66921e0db5  pop r11
00007a66921e0db7  pop r10
00007a66921e0db9  pop r9
00007a66921e0dbb  pop r8
00007a66921e0dbd  pop rsi
00007a66921e0dbe  pop rdi
00007a66921e0dbf  pop rdx
00007a66921e0dc0  pop rcx
00007a66921e0dc1  pop rax
00007a66921e0dc2  add rsp, 0x08
00007a66921e0dc6  jmp 0x00007A66921DC6CD
00007a66921e0dcb  sub rsp, 0x08
00007a66921e0dcf  push rax
00007a66921e0dd0  push rcx
00007a66921e0dd1  push rdx
00007a66921e0dd2  push rdi
00007a66921e0dd3  push rsi
00007a66921e0dd4  push r8
00007a66921e0dd6  push r9
00007a66921e0dd8  push r10
00007a66921e0dda  push r11
00007a66921e0ddc  sub rsp, 0xF0
00007a66921e0de3  vmovaps [rsp], xmm0
00007a66921e0de8  vmovaps [rsp+0x10], xmm1
00007a66921e0dee  vmovaps [rsp+0x20], xmm2
00007a66921e0df4  vmovaps [rsp+0x30], xmm3
00007a66921e0dfa  vmovaps [rsp+0x40], xmm4
00007a66921e0e00  vmovaps [rsp+0x50], xmm5
00007a66921e0e06  vmovaps [rsp+0x60], xmm6
00007a66921e0e0c  vmovaps [rsp+0x70], xmm7
00007a66921e0e12  vmovaps [rsp+0x80], xmm8
00007a66921e0e1b  vmovaps [rsp+0x90], xmm9
00007a66921e0e24  vmovaps [rsp+0xA0], xmm10
00007a66921e0e2d  vmovaps [rsp+0xB0], xmm11
00007a66921e0e36  vmovaps [rsp+0xC0], xmm13
00007a66921e0e3f  vmovaps [rsp+0xD0], xmm14
00007a66921e0e48  vmovaps [rsp+0xE0], xmm15
00007a66921e0e51  sub rsp, 0x30
00007a66921e0e55  movaps [rsp], xmm12
00007a66921e0e5a  movaps [rsp+0x10], xmm14
00007a66921e0e60  movaps [rsp+0x20], xmm1
00007a66921e0e65  lea rdi, [rsp]
00007a66921e0e69  mov esi, 0x00
00007a66921e0e6e  mov rax, 0x635346DC7530
00007a66921e0e78  call rax
00007a66921e0e7a  movaps xmm12, [rsp]
00007a66921e0e7f  add rsp, 0x30
00007a66921e0e83  vmovaps xmm0, [rsp]
00007a66921e0e88  vmovaps xmm1, [rsp+0x10]
00007a66921e0e8e  vmovaps xmm2, [rsp+0x20]
00007a66921e0e94  vmovaps xmm3, [rsp+0x30]
00007a66921e0e9a  vmovaps xmm4, [rsp+0x40]
00007a66921e0ea0  vmovaps xmm5, [rsp+0x50]
00007a66921e0ea6  vmovaps xmm6, [rsp+0x60]
00007a66921e0eac  vmovaps xmm7, [rsp+0x70]
00007a66921e0eb2  vmovaps xmm8, [rsp+0x80]
00007a66921e0ebb  vmovaps xmm9, [rsp+0x90]
00007a66921e0ec4  vmovaps xmm10, [rsp+0xA0]
00007a66921e0ecd  vmovaps xmm11, [rsp+0xB0]
00007a66921e0ed6  vmovaps xmm13, [rsp+0xC0]
00007a66921e0edf  vmovaps xmm14, [rsp+0xD0]
00007a66921e0ee8  vmovaps xmm15, [rsp+0xE0]
00007a66921e0ef1  add rsp, 0xF0
00007a66921e0ef8  pop r11
00007a66921e0efa  pop r10
00007a66921e0efc  pop r9
00007a66921e0efe  pop r8
00007a66921e0f00  pop rsi
00007a66921e0f01  pop rdi
00007a66921e0f02  pop rdx
00007a66921e0f03  pop rcx
00007a66921e0f04  pop rax
00007a66921e0f05  add rsp, 0x08
00007a66921e0f09  jmp 0x00007A66921DC6FC
00007a66921e0f0e  sub rsp, 0x08
00007a66921e0f12  push rax
00007a66921e0f13  push rcx
00007a66921e0f14  push rdx
00007a66921e0f15  push rdi
00007a66921e0f16  push rsi
00007a66921e0f17  push r8
00007a66921e0f19  push r9
00007a66921e0f1b  push r10
00007a66921e0f1d  push r11
00007a66921e0f1f  sub rsp, 0xF0
00007a66921e0f26  vmovaps [rsp], xmm0
00007a66921e0f2b  vmovaps [rsp+0x10], xmm1
00007a66921e0f31  vmovaps [rsp+0x20], xmm2
00007a66921e0f37  vmovaps [rsp+0x30], xmm3
00007a66921e0f3d  vmovaps [rsp+0x40], xmm4
00007a66921e0f43  vmovaps [rsp+0x50], xmm5
00007a66921e0f49  vmovaps [rsp+0x60], xmm6
00007a66921e0f4f  vmovaps [rsp+0x70], xmm7
00007a66921e0f55  vmovaps [rsp+0x80], xmm8
00007a66921e0f5e  vmovaps [rsp+0x90], xmm9
00007a66921e0f67  vmovaps [rsp+0xA0], xmm10
00007a66921e0f70  vmovaps [rsp+0xB0], xmm11
00007a66921e0f79  vmovaps [rsp+0xC0], xmm12
00007a66921e0f82  vmovaps [rsp+0xD0], xmm13
00007a66921e0f8b  vmovaps [rsp+0xE0], xmm15
00007a66921e0f94  sub rsp, 0x30
00007a66921e0f98  movaps [rsp], xmm14
00007a66921e0f9d  movaps [rsp+0x10], xmm9
00007a66921e0fa3  movaps [rsp+0x20], xmm1
00007a66921e0fa8  lea rdi, [rsp]
00007a66921e0fac  mov esi, 0x00
00007a66921e0fb1  mov rax, 0x635346DC7530
00007a66921e0fbb  call rax
00007a66921e0fbd  movaps xmm14, [rsp]
00007a66921e0fc2  add rsp, 0x30
00007a66921e0fc6  vmovaps xmm0, [rsp]
00007a66921e0fcb  vmovaps xmm1, [rsp+0x10]
00007a66921e0fd1  vmovaps xmm2, [rsp+0x20]
00007a66921e0fd7  vmovaps xmm3, [rsp+0x30]
00007a66921e0fdd  vmovaps xmm4, [rsp+0x40]
00007a66921e0fe3  vmovaps xmm5, [rsp+0x50]
00007a66921e0fe9  vmovaps xmm6, [rsp+0x60]
00007a66921e0fef  vmovaps xmm7, [rsp+0x70]
00007a66921e0ff5  vmovaps xmm8, [rsp+0x80]
00007a66921e0ffe  vmovaps xmm9, [rsp+0x90]
00007a66921e1007  vmovaps xmm10, [rsp+0xA0]
00007a66921e1010  vmovaps xmm11, [rsp+0xB0]
00007a66921e1019  vmovaps xmm12, [rsp+0xC0]
00007a66921e1022  vmovaps xmm13, [rsp+0xD0]
00007a66921e102b  vmovaps xmm15, [rsp+0xE0]
00007a66921e1034  add rsp, 0xF0
00007a66921e103b  pop r11
00007a66921e103d  pop r10
00007a66921e103f  pop r9
00007a66921e1041  pop r8
00007a66921e1043  pop rsi
00007a66921e1044  pop rdi
00007a66921e1045  pop rdx
00007a66921e1046  pop rcx
00007a66921e1047  pop rax
00007a66921e1048  add rsp, 0x08
00007a66921e104c  jmp 0x00007A66921DC72B
00007a66921e1051  sub rsp, 0x08
00007a66921e1055  push rax
00007a66921e1056  push rcx
00007a66921e1057  push rdx
00007a66921e1058  push rdi
00007a66921e1059  push rsi
00007a66921e105a  push r8
00007a66921e105c  push r9
00007a66921e105e  push r10
00007a66921e1060  push r11
00007a66921e1062  sub rsp, 0xF0
00007a66921e1069  vmovaps [rsp], xmm0
00007a66921e106e  vmovaps [rsp+0x10], xmm2
00007a66921e1074  vmovaps [rsp+0x20], xmm3
00007a66921e107a  vmovaps [rsp+0x30], xmm4
00007a66921e1080  vmovaps [rsp+0x40], xmm5
00007a66921e1086  vmovaps [rsp+0x50], xmm6
00007a66921e108c  vmovaps [rsp+0x60], xmm7
00007a66921e1092  vmovaps [rsp+0x70], xmm8
00007a66921e1098  vmovaps [rsp+0x80], xmm9
00007a66921e10a1  vmovaps [rsp+0x90], xmm10
00007a66921e10aa  vmovaps [rsp+0xA0], xmm11
00007a66921e10b3  vmovaps [rsp+0xB0], xmm12
00007a66921e10bc  vmovaps [rsp+0xC0], xmm13
00007a66921e10c5  vmovaps [rsp+0xD0], xmm14
00007a66921e10ce  vmovaps [rsp+0xE0], xmm15
00007a66921e10d7  sub rsp, 0x30
00007a66921e10db  movaps [rsp], xmm1
00007a66921e10df  movaps [rsp+0x10], xmm13
00007a66921e10e5  movaps [rsp+0x20], xmm8
00007a66921e10eb  lea rdi, [rsp]
00007a66921e10ef  mov esi, 0x00
00007a66921e10f4  mov rax, 0x635346DC7530
00007a66921e10fe  call rax
00007a66921e1100  movaps xmm1, [rsp]
00007a66921e1104  add rsp, 0x30
00007a66921e1108  vmovaps xmm0, [rsp]
00007a66921e110d  vmovaps xmm2, [rsp+0x10]
00007a66921e1113  vmovaps xmm3, [rsp+0x20]
00007a66921e1119  vmovaps xmm4, [rsp+0x30]
00007a66921e111f  vmovaps xmm5, [rsp+0x40]
00007a66921e1125  vmovaps xmm6, [rsp+0x50]
00007a66921e112b  vmovaps xmm7, [rsp+0x60]
00007a66921e1131  vmovaps xmm8, [rsp+0x70]
00007a66921e1137  vmovaps xmm9, [rsp+0x80]
00007a66921e1140  vmovaps xmm10, [rsp+0x90]
00007a66921e1149  vmovaps xmm11, [rsp+0xA0]
00007a66921e1152  vmovaps xmm12, [rsp+0xB0]
00007a66921e115b  vmovaps xmm13, [rsp+0xC0]
00007a66921e1164  vmovaps xmm14, [rsp+0xD0]
00007a66921e116d  vmovaps xmm15, [rsp+0xE0]
00007a66921e1176  add rsp, 0xF0
00007a66921e117d  pop r11
00007a66921e117f  pop r10
00007a66921e1181  pop r9
00007a66921e1183  pop r8
00007a66921e1185  pop rsi
00007a66921e1186  pop rdi
00007a66921e1187  pop rdx
00007a66921e1188  pop rcx
00007a66921e1189  pop rax
00007a66921e118a  add rsp, 0x08
00007a66921e118e  jmp 0x00007A66921DC74D
00007a66921e1193  call 0x00007A669200C260
00007a66921e1198  jmp 0x00007A66921DC75B
00007a66921e119d  call 0x00007A66920BD750
00007a66921e11a2  jmp 0x00007A66921DC765
00007a66921e11a7  sub rsp, 0x08
00007a66921e11ab  push rax
00007a66921e11ac  push rcx
00007a66921e11ad  push rdx
00007a66921e11ae  push rdi
00007a66921e11af  push rsi
00007a66921e11b0  push r8
00007a66921e11b2  push r9
00007a66921e11b4  push r10
00007a66921e11b6  push r11
00007a66921e11b8  sub rsp, 0xF0
00007a66921e11bf  vmovaps [rsp], xmm0
00007a66921e11c4  vmovaps [rsp+0x10], xmm1
00007a66921e11ca  vmovaps [rsp+0x20], xmm2
00007a66921e11d0  vmovaps [rsp+0x30], xmm3
00007a66921e11d6  vmovaps [rsp+0x40], xmm4
00007a66921e11dc  vmovaps [rsp+0x50], xmm5
00007a66921e11e2  vmovaps [rsp+0x60], xmm6
00007a66921e11e8  vmovaps [rsp+0x70], xmm7
00007a66921e11ee  vmovaps [rsp+0x80], xmm9
00007a66921e11f7  vmovaps [rsp+0x90], xmm10
00007a66921e1200  vmovaps [rsp+0xA0], xmm11
00007a66921e1209  vmovaps [rsp+0xB0], xmm12
00007a66921e1212  vmovaps [rsp+0xC0], xmm13
00007a66921e121b  vmovaps [rsp+0xD0], xmm14
00007a66921e1224  vmovaps [rsp+0xE0], xmm15
00007a66921e122d  sub rsp, 0x30
00007a66921e1231  movaps [rsp], xmm8
00007a66921e1236  movaps [rsp+0x10], xmm15
00007a66921e123c  movaps [rsp+0x20], xmm7
00007a66921e1241  lea rdi, [rsp]
00007a66921e1245  mov esi, 0x00
00007a66921e124a  mov rax, 0x635346DC7530
00007a66921e1254  call rax
00007a66921e1256  movaps xmm8, [rsp]
00007a66921e125b  add rsp, 0x30
00007a66921e125f  vmovaps xmm0, [rsp]
00007a66921e1264  vmovaps xmm1, [rsp+0x10]
00007a66921e126a  vmovaps xmm2, [rsp+0x20]
00007a66921e1270  vmovaps xmm3, [rsp+0x30]
00007a66921e1276  vmovaps xmm4, [rsp+0x40]
00007a66921e127c  vmovaps xmm5, [rsp+0x50]
00007a66921e1282  vmovaps xmm6, [rsp+0x60]
00007a66921e1288  vmovaps xmm7, [rsp+0x70]
00007a66921e128e  vmovaps xmm9, [rsp+0x80]
00007a66921e1297  vmovaps xmm10, [rsp+0x90]
00007a66921e12a0  vmovaps xmm11, [rsp+0xA0]
00007a66921e12a9  vmovaps xmm12, [rsp+0xB0]
00007a66921e12b2  vmovaps xmm13, [rsp+0xC0]
00007a66921e12bb  vmovaps xmm14, [rsp+0xD0]
00007a66921e12c4  vmovaps xmm15, [rsp+0xE0]
00007a66921e12cd  add rsp, 0xF0
00007a66921e12d4  pop r11
00007a66921e12d6  pop r10
00007a66921e12d8  pop r9
00007a66921e12da  pop r8
00007a66921e12dc  pop rsi
00007a66921e12dd  pop rdi
00007a66921e12de  pop rdx
00007a66921e12df  pop rcx
00007a66921e12e0  pop rax
00007a66921e12e1  add rsp, 0x08
00007a66921e12e5  jmp 0x00007A66921DC787
00007a66921e12ea  sub rsp, 0x08
00007a66921e12ee  push rax
00007a66921e12ef  push rcx
00007a66921e12f0  push rdx
00007a66921e12f1  push rdi
00007a66921e12f2  push rsi
00007a66921e12f3  push r8
00007a66921e12f5  push r9
00007a66921e12f7  push r10
00007a66921e12f9  push r11
00007a66921e12fb  sub rsp, 0xF0
00007a66921e1302  vmovaps [rsp], xmm0
00007a66921e1307  vmovaps [rsp+0x10], xmm1
00007a66921e130d  vmovaps [rsp+0x20], xmm2
00007a66921e1313  vmovaps [rsp+0x30], xmm3
00007a66921e1319  vmovaps [rsp+0x40], xmm4
00007a66921e131f  vmovaps [rsp+0x50], xmm5
00007a66921e1325  vmovaps [rsp+0x60], xmm6
00007a66921e132b  vmovaps [rsp+0x70], xmm8
00007a66921e1331  vmovaps [rsp+0x80], xmm9
00007a66921e133a  vmovaps [rsp+0x90], xmm10
00007a66921e1343  vmovaps [rsp+0xA0], xmm11
00007a66921e134c  vmovaps [rsp+0xB0], xmm12
00007a66921e1355  vmovaps [rsp+0xC0], xmm13
00007a66921e135e  vmovaps [rsp+0xD0], xmm14
00007a66921e1367  vmovaps [rsp+0xE0], xmm15
00007a66921e1370  sub rsp, 0x30
00007a66921e1374  movaps [rsp], xmm7
00007a66921e1378  movaps [rsp+0x10], xmm9
00007a66921e137e  movaps [rsp+0x20], xmm15
00007a66921e1384  lea rdi, [rsp]
00007a66921e1388  mov esi, 0x00
00007a66921e138d  mov rax, 0x635346DC7530
00007a66921e1397  call rax
00007a66921e1399  movaps xmm7, [rsp]
00007a66921e139d  add rsp, 0x30
00007a66921e13a1  vmovaps xmm0, [rsp]
00007a66921e13a6  vmovaps xmm1, [rsp+0x10]
00007a66921e13ac  vmovaps xmm2, [rsp+0x20]
00007a66921e13b2  vmovaps xmm3, [rsp+0x30]
00007a66921e13b8  vmovaps xmm4, [rsp+0x40]
00007a66921e13be  vmovaps xmm5, [rsp+0x50]
00007a66921e13c4  vmovaps xmm6, [rsp+0x60]
00007a66921e13ca  vmovaps xmm8, [rsp+0x70]
00007a66921e13d0  vmovaps xmm9, [rsp+0x80]
00007a66921e13d9  vmovaps xmm10, [rsp+0x90]
00007a66921e13e2  vmovaps xmm11, [rsp+0xA0]
00007a66921e13eb  vmovaps xmm12, [rsp+0xB0]
00007a66921e13f4  vmovaps xmm13, [rsp+0xC0]
00007a66921e13fd  vmovaps xmm14, [rsp+0xD0]
00007a66921e1406  vmovaps xmm15, [rsp+0xE0]
00007a66921e140f  add rsp, 0xF0
00007a66921e1416  pop r11
00007a66921e1418  pop r10
00007a66921e141a  pop r9
00007a66921e141c  pop r8
00007a66921e141e  pop rsi
00007a66921e141f  pop rdi
00007a66921e1420  pop rdx
00007a66921e1421  pop rcx
00007a66921e1422  pop rax
00007a66921e1423  add rsp, 0x08
00007a66921e1427  jmp 0x00007A66921DC7B4
00007a66921e142c  sub rsp, 0x08
00007a66921e1430  push rax
00007a66921e1431  push rcx
00007a66921e1432  push rdx
00007a66921e1433  push rdi
00007a66921e1434  push rsi
00007a66921e1435  push r8
00007a66921e1437  push r9
00007a66921e1439  push r10
00007a66921e143b  push r11
00007a66921e143d  sub rsp, 0xF0
00007a66921e1444  vmovaps [rsp], xmm0
00007a66921e1449  vmovaps [rsp+0x10], xmm1
00007a66921e144f  vmovaps [rsp+0x20], xmm2
00007a66921e1455  vmovaps [rsp+0x30], xmm3
00007a66921e145b  vmovaps [rsp+0x40], xmm4
00007a66921e1461  vmovaps [rsp+0x50], xmm5
00007a66921e1467  vmovaps [rsp+0x60], xmm6
00007a66921e146d  vmovaps [rsp+0x70], xmm7
00007a66921e1473  vmovaps [rsp+0x80], xmm8
00007a66921e147c  vmovaps [rsp+0x90], xmm10
00007a66921e1485  vmovaps [rsp+0xA0], xmm11
00007a66921e148e  vmovaps [rsp+0xB0], xmm12
00007a66921e1497  vmovaps [rsp+0xC0], xmm13
00007a66921e14a0  vmovaps [rsp+0xD0], xmm14
00007a66921e14a9  vmovaps [rsp+0xE0], xmm15
00007a66921e14b2  sub rsp, 0x30
00007a66921e14b6  movaps [rsp], xmm9
00007a66921e14bb  movaps [rsp+0x10], xmm13
00007a66921e14c1  movaps [rsp+0x20], xmm15
00007a66921e14c7  lea rdi, [rsp]
00007a66921e14cb  mov esi, 0x00
00007a66921e14d0  mov rax, 0x635346DC7530
00007a66921e14da  call rax
00007a66921e14dc  movaps xmm9, [rsp]
00007a66921e14e1  add rsp, 0x30
00007a66921e14e5  vmovaps xmm0, [rsp]
00007a66921e14ea  vmovaps xmm1, [rsp+0x10]
00007a66921e14f0  vmovaps xmm2, [rsp+0x20]
00007a66921e14f6  vmovaps xmm3, [rsp+0x30]
00007a66921e14fc  vmovaps xmm4, [rsp+0x40]
00007a66921e1502  vmovaps xmm5, [rsp+0x50]
00007a66921e1508  vmovaps xmm6, [rsp+0x60]
00007a66921e150e  vmovaps xmm7, [rsp+0x70]
00007a66921e1514  vmovaps xmm8, [rsp+0x80]
00007a66921e151d  vmovaps xmm10, [rsp+0x90]
00007a66921e1526  vmovaps xmm11, [rsp+0xA0]
00007a66921e152f  vmovaps xmm12, [rsp+0xB0]
00007a66921e1538  vmovaps xmm13, [rsp+0xC0]
00007a66921e1541  vmovaps xmm14, [rsp+0xD0]
00007a66921e154a  vmovaps xmm15, [rsp+0xE0]
00007a66921e1553  add rsp, 0xF0
00007a66921e155a  pop r11
00007a66921e155c  pop r10
00007a66921e155e  pop r9
00007a66921e1560  pop r8
00007a66921e1562  pop rsi
00007a66921e1563  pop rdi
00007a66921e1564  pop rdx
00007a66921e1565  pop rcx
00007a66921e1566  pop rax
00007a66921e1567  add rsp, 0x08
00007a66921e156b  jmp 0x00007A66921DC7E2
00007a66921e1570  sub rsp, 0x08
00007a66921e1574  push rax
00007a66921e1575  push rcx
00007a66921e1576  push rdx
00007a66921e1577  push rdi
00007a66921e1578  push rsi
00007a66921e1579  push r8
00007a66921e157b  push r9
00007a66921e157d  push r10
00007a66921e157f  push r11
00007a66921e1581  sub rsp, 0xF0
00007a66921e1588  vmovaps [rsp], xmm0
00007a66921e158d  vmovaps [rsp+0x10], xmm1
00007a66921e1593  vmovaps [rsp+0x20], xmm2
00007a66921e1599  vmovaps [rsp+0x30], xmm3
00007a66921e159f  vmovaps [rsp+0x40], xmm4
00007a66921e15a5  vmovaps [rsp+0x50], xmm5
00007a66921e15ab  vmovaps [rsp+0x60], xmm6
00007a66921e15b1  vmovaps [rsp+0x70], xmm7
00007a66921e15b7  vmovaps [rsp+0x80], xmm8
00007a66921e15c0  vmovaps [rsp+0x90], xmm9
00007a66921e15c9  vmovaps [rsp+0xA0], xmm10
00007a66921e15d2  vmovaps [rsp+0xB0], xmm11
00007a66921e15db  vmovaps [rsp+0xC0], xmm12
00007a66921e15e4  vmovaps [rsp+0xD0], xmm13
00007a66921e15ed  vmovaps [rsp+0xE0], xmm14
00007a66921e15f6  sub rsp, 0x30
00007a66921e15fa  movaps [rsp], xmm15
00007a66921e15ff  movaps [rsp+0x10], xmm11
00007a66921e1605  movaps [rsp+0x20], xmm12
00007a66921e160b  lea rdi, [rsp]
00007a66921e160f  mov esi, 0x00
00007a66921e1614  mov rax, 0x635346DC7530
00007a66921e161e  call rax
00007a66921e1620  movaps xmm15, [rsp]
00007a66921e1625  add rsp, 0x30
00007a66921e1629  vmovaps xmm0, [rsp]
00007a66921e162e  vmovaps xmm1, [rsp+0x10]
00007a66921e1634  vmovaps xmm2, [rsp+0x20]
00007a66921e163a  vmovaps xmm3, [rsp+0x30]
00007a66921e1640  vmovaps xmm4, [rsp+0x40]
00007a66921e1646  vmovaps xmm5, [rsp+0x50]
00007a66921e164c  vmovaps xmm6, [rsp+0x60]
00007a66921e1652  vmovaps xmm7, [rsp+0x70]
00007a66921e1658  vmovaps xmm8, [rsp+0x80]
00007a66921e1661  vmovaps xmm9, [rsp+0x90]
00007a66921e166a  vmovaps xmm10, [rsp+0xA0]
00007a66921e1673  vmovaps xmm11, [rsp+0xB0]
00007a66921e167c  vmovaps xmm12, [rsp+0xC0]
00007a66921e1685  vmovaps xmm13, [rsp+0xD0]
00007a66921e168e  vmovaps xmm14, [rsp+0xE0]
00007a66921e1697  add rsp, 0xF0
00007a66921e169e  pop r11
00007a66921e16a0  pop r10
00007a66921e16a2  pop r9
00007a66921e16a4  pop r8
00007a66921e16a6  pop rsi
00007a66921e16a7  pop rdi
00007a66921e16a8  pop rdx
00007a66921e16a9  pop rcx
00007a66921e16aa  pop rax
00007a66921e16ab  add rsp, 0x08
00007a66921e16af  jmp 0x00007A66921DC7FD
00007a66921e16b4  sub rsp, 0x08
00007a66921e16b8  push rax
00007a66921e16b9  push rcx
00007a66921e16ba  push rdx
00007a66921e16bb  push rdi
00007a66921e16bc  push rsi
00007a66921e16bd  push r8
00007a66921e16bf  push r9
00007a66921e16c1  push r10
00007a66921e16c3  push r11
00007a66921e16c5  sub rsp, 0xF0
00007a66921e16cc  vmovaps [rsp], xmm0
00007a66921e16d1  vmovaps [rsp+0x10], xmm1
00007a66921e16d7  vmovaps [rsp+0x20], xmm2
00007a66921e16dd  vmovaps [rsp+0x30], xmm3
00007a66921e16e3  vmovaps [rsp+0x40], xmm4
00007a66921e16e9  vmovaps [rsp+0x50], xmm5
00007a66921e16ef  vmovaps [rsp+0x60], xmm6
00007a66921e16f5  vmovaps [rsp+0x70], xmm7
00007a66921e16fb  vmovaps [rsp+0x80], xmm8
00007a66921e1704  vmovaps [rsp+0x90], xmm9
00007a66921e170d  vmovaps [rsp+0xA0], xmm10
00007a66921e1716  vmovaps [rsp+0xB0], xmm11
00007a66921e171f  vmovaps [rsp+0xC0], xmm12
00007a66921e1728  vmovaps [rsp+0xD0], xmm14
00007a66921e1731  vmovaps [rsp+0xE0], xmm15
00007a66921e173a  sub rsp, 0x30
00007a66921e173e  movaps [rsp], xmm13
00007a66921e1743  movaps [rsp+0x10], xmm10
00007a66921e1749  movaps [rsp+0x20], xmm14
00007a66921e174f  lea rdi, [rsp]
00007a66921e1753  mov esi, 0x00
00007a66921e1758  mov rax, 0x635346DC7530
00007a66921e1762  call rax
00007a66921e1764  movaps xmm13, [rsp]
00007a66921e1769  add rsp, 0x30
00007a66921e176d  vmovaps xmm0, [rsp]
00007a66921e1772  vmovaps xmm1, [rsp+0x10]
00007a66921e1778  vmovaps xmm2, [rsp+0x20]
00007a66921e177e  vmovaps xmm3, [rsp+0x30]
00007a66921e1784  vmovaps xmm4, [rsp+0x40]
00007a66921e178a  vmovaps xmm5, [rsp+0x50]
00007a66921e1790  vmovaps xmm6, [rsp+0x60]
00007a66921e1796  vmovaps xmm7, [rsp+0x70]
00007a66921e179c  vmovaps xmm8, [rsp+0x80]
00007a66921e17a5  vmovaps xmm9, [rsp+0x90]
00007a66921e17ae  vmovaps xmm10, [rsp+0xA0]
00007a66921e17b7  vmovaps xmm11, [rsp+0xB0]
00007a66921e17c0  vmovaps xmm12, [rsp+0xC0]
00007a66921e17c9  vmovaps xmm14, [rsp+0xD0]
00007a66921e17d2  vmovaps xmm15, [rsp+0xE0]
00007a66921e17db  add rsp, 0xF0
00007a66921e17e2  pop r11
00007a66921e17e4  pop r10
00007a66921e17e6  pop r9
00007a66921e17e8  pop r8
00007a66921e17ea  pop rsi
00007a66921e17eb  pop rdi
00007a66921e17ec  pop rdx
00007a66921e17ed  pop rcx
00007a66921e17ee  pop rax
00007a66921e17ef  add rsp, 0x08
00007a66921e17f3  jmp 0x00007A66921DC820
00007a66921e17f8  sub rsp, 0x08
00007a66921e17fc  push rax
00007a66921e17fd  push rcx
00007a66921e17fe  push rdx
00007a66921e17ff  push rdi
00007a66921e1800  push rsi
00007a66921e1801  push r8
00007a66921e1803  push r9
00007a66921e1805  push r10
00007a66921e1807  push r11
00007a66921e1809  sub rsp, 0xF0
00007a66921e1810  vmovaps [rsp], xmm0
00007a66921e1815  vmovaps [rsp+0x10], xmm1
00007a66921e181b  vmovaps [rsp+0x20], xmm2
00007a66921e1821  vmovaps [rsp+0x30], xmm3
00007a66921e1827  vmovaps [rsp+0x40], xmm4
00007a66921e182d  vmovaps [rsp+0x50], xmm5
00007a66921e1833  vmovaps [rsp+0x60], xmm6
00007a66921e1839  vmovaps [rsp+0x70], xmm7
00007a66921e183f  vmovaps [rsp+0x80], xmm8
00007a66921e1848  vmovaps [rsp+0x90], xmm9
00007a66921e1851  vmovaps [rsp+0xA0], xmm10
00007a66921e185a  vmovaps [rsp+0xB0], xmm11
00007a66921e1863  vmovaps [rsp+0xC0], xmm12
00007a66921e186c  vmovaps [rsp+0xD0], xmm13
00007a66921e1875  vmovaps [rsp+0xE0], xmm15
00007a66921e187e  sub rsp, 0x30
00007a66921e1882  movaps [rsp], xmm14
00007a66921e1887  movaps [rsp+0x10], xmm1
00007a66921e188c  movaps [rsp+0x20], xmm7
00007a66921e1891  lea rdi, [rsp]
00007a66921e1895  mov esi, 0x00
00007a66921e189a  mov rax, 0x635346DC7530
00007a66921e18a4  call rax
00007a66921e18a6  movaps xmm14, [rsp]
00007a66921e18ab  add rsp, 0x30
00007a66921e18af  vmovaps xmm0, [rsp]
00007a66921e18b4  vmovaps xmm1, [rsp+0x10]
00007a66921e18ba  vmovaps xmm2, [rsp+0x20]
00007a66921e18c0  vmovaps xmm3, [rsp+0x30]
00007a66921e18c6  vmovaps xmm4, [rsp+0x40]
00007a66921e18cc  vmovaps xmm5, [rsp+0x50]
00007a66921e18d2  vmovaps xmm6, [rsp+0x60]
00007a66921e18d8  vmovaps xmm7, [rsp+0x70]
00007a66921e18de  vmovaps xmm8, [rsp+0x80]
00007a66921e18e7  vmovaps xmm9, [rsp+0x90]
00007a66921e18f0  vmovaps xmm10, [rsp+0xA0]
00007a66921e18f9  vmovaps xmm11, [rsp+0xB0]
00007a66921e1902  vmovaps xmm12, [rsp+0xC0]
00007a66921e190b  vmovaps xmm13, [rsp+0xD0]
00007a66921e1914  vmovaps xmm15, [rsp+0xE0]
00007a66921e191d  add rsp, 0xF0
00007a66921e1924  pop r11
00007a66921e1926  pop r10
00007a66921e1928  pop r9
00007a66921e192a  pop r8
00007a66921e192c  pop rsi
00007a66921e192d  pop rdi
00007a66921e192e  pop rdx
00007a66921e192f  pop rcx
00007a66921e1930  pop rax
00007a66921e1931  add rsp, 0x08
00007a66921e1935  jmp 0x00007A66921DC843
00007a66921e193a  sub rsp, 0x08
00007a66921e193e  push rax
00007a66921e193f  push rcx
00007a66921e1940  push rdx
00007a66921e1941  push rdi
00007a66921e1942  push rsi
00007a66921e1943  push r8
00007a66921e1945  push r9
00007a66921e1947  push r10
00007a66921e1949  push r11
00007a66921e194b  sub rsp, 0xF0
00007a66921e1952  vmovaps [rsp], xmm0
00007a66921e1957  vmovaps [rsp+0x10], xmm2
00007a66921e195d  vmovaps [rsp+0x20], xmm3
00007a66921e1963  vmovaps [rsp+0x30], xmm4
00007a66921e1969  vmovaps [rsp+0x40], xmm5
00007a66921e196f  vmovaps [rsp+0x50], xmm6
00007a66921e1975  vmovaps [rsp+0x60], xmm7
00007a66921e197b  vmovaps [rsp+0x70], xmm8
00007a66921e1981  vmovaps [rsp+0x80], xmm9
00007a66921e198a  vmovaps [rsp+0x90], xmm10
00007a66921e1993  vmovaps [rsp+0xA0], xmm11
00007a66921e199c  vmovaps [rsp+0xB0], xmm12
00007a66921e19a5  vmovaps [rsp+0xC0], xmm13
00007a66921e19ae  vmovaps [rsp+0xD0], xmm14
00007a66921e19b7  vmovaps [rsp+0xE0], xmm15
00007a66921e19c0  sub rsp, 0x30
00007a66921e19c4  movaps [rsp], xmm1
00007a66921e19c8  movaps [rsp+0x10], xmm8
00007a66921e19ce  movaps [rsp+0x20], xmm9
00007a66921e19d4  lea rdi, [rsp]
00007a66921e19d8  mov esi, 0x00
00007a66921e19dd  mov rax, 0x635346DC7530
00007a66921e19e7  call rax
00007a66921e19e9  movaps xmm1, [rsp]
00007a66921e19ed  add rsp, 0x30
00007a66921e19f1  vmovaps xmm0, [rsp]
00007a66921e19f6  vmovaps xmm2, [rsp+0x10]
00007a66921e19fc  vmovaps xmm3, [rsp+0x20]
00007a66921e1a02  vmovaps xmm4, [rsp+0x30]
00007a66921e1a08  vmovaps xmm5, [rsp+0x40]
00007a66921e1a0e  vmovaps xmm6, [rsp+0x50]
00007a66921e1a14  vmovaps xmm7, [rsp+0x60]
00007a66921e1a1a  vmovaps xmm8, [rsp+0x70]
00007a66921e1a20  vmovaps xmm9, [rsp+0x80]
00007a66921e1a29  vmovaps xmm10, [rsp+0x90]
00007a66921e1a32  vmovaps xmm11, [rsp+0xA0]
00007a66921e1a3b  vmovaps xmm12, [rsp+0xB0]
00007a66921e1a44  vmovaps xmm13, [rsp+0xC0]
00007a66921e1a4d  vmovaps xmm14, [rsp+0xD0]
00007a66921e1a56  vmovaps xmm15, [rsp+0xE0]
00007a66921e1a5f  add rsp, 0xF0
00007a66921e1a66  pop r11
00007a66921e1a68  pop r10
00007a66921e1a6a  pop r9
00007a66921e1a6c  pop r8
00007a66921e1a6e  pop rsi
00007a66921e1a6f  pop rdi
00007a66921e1a70  pop rdx
00007a66921e1a71  pop rcx
00007a66921e1a72  pop rax
00007a66921e1a73  add rsp, 0x08
00007a66921e1a77  jmp 0x00007A66921DC865
00007a66921e1a7c  call 0x00007A66920E5940
00007a66921e1a81  jmp 0x00007A66921DC873
00007a66921e1a86  call 0x00007A669200C380
00007a66921e1a8b  jmp 0x00007A66921DC87D
00007a66921e1a90  call 0x00007A669200D600
00007a66921e1a95  jmp 0x00007A66921DC887
00007a66921e1a9a  call 0x00007A6691FFF540
00007a66921e1a9f  jmp 0x00007A66921DC891
00007a66921e1aa4  int3
00007a66921e1aa5  nop [rax+rax*1], ax
00007a66921e1aae  nop
00007a66921e1ab0  mov rax, [r15+0xF8]
00007a66921e1ab7  lea r14, [rax+0x140]
00007a66921e1abe  mov r12, [r13+r14*1]
00007a66921e1ac3  mov [r15+0xE8], r12
00007a66921e1aca  lea r14, [rax+0x130]
00007a66921e1ad1  mov r12, [r13+r14*1]
00007a66921e1ad6  lea r14, [rax+0x138]
00007a66921e1add  mov r11, [r13+r14*1]
00007a66921e1ae2  movq xmm1, r12
00007a66921e1ae7  movq xmm15, r11
00007a66921e1aec  movq xmm1, xmm1
00007a66921e1af0  movq xmm1, xmm1
00007a66921e1af4  movaps [r15+0x1A0], xmm1
00007a66921e1afc  movq xmm15, xmm15
00007a66921e1b01  movq xmm15, xmm15
00007a66921e1b06  movaps [r15+0x190], xmm15
00007a66921e1b0e  lea r14, [rax+0x120]
00007a66921e1b15  mov r12, [r13+r14*1]
00007a66921e1b1a  lea r14, [rax+0x128]
00007a66921e1b21  mov r11, [r13+r14*1]
00007a66921e1b26  movq xmm1, r12
00007a66921e1b2b  movq xmm15, r11
00007a66921e1b30  movq xmm1, xmm1
00007a66921e1b34  movq xmm1, xmm1
00007a66921e1b38  movaps [r15+0x1C0], xmm1
00007a66921e1b40  movq xmm15, xmm15
00007a66921e1b45  movq xmm15, xmm15
00007a66921e1b4a  movaps [r15+0x1B0], xmm15
00007a66921e1b52  lea r14, [rax+0x110]
00007a66921e1b59  mov r12, [r13+r14*1]
00007a66921e1b5e  lea r14, [rax+0x118]
00007a66921e1b65  mov r11, [r13+r14*1]
00007a66921e1b6a  movq xmm1, r12
00007a66921e1b6f  movq xmm15, r11
00007a66921e1b74  movq xmm1, xmm1
00007a66921e1b78  movq xmm1, xmm1
00007a66921e1b7c  movaps [r15+0x1E0], xmm1
00007a66921e1b84  movq xmm15, xmm15
00007a66921e1b89  movq xmm15, xmm15
00007a66921e1b8e  movaps [r15+0x1D0], xmm15
00007a66921e1b96  lea r14, [rax+0x100]
00007a66921e1b9d  mov r12, [r13+r14*1]
00007a66921e1ba2  lea r14, [rax+0x108]
00007a66921e1ba9  mov r11, [r13+r14*1]
00007a66921e1bae  movq xmm1, r12
00007a66921e1bb3  movq xmm15, r11
00007a66921e1bb8  movq xmm1, xmm1
00007a66921e1bbc  movq xmm1, xmm1
00007a66921e1bc0  movaps [r15+0x200], xmm1
00007a66921e1bc8  movq xmm15, xmm15
00007a66921e1bcd  movq xmm15, xmm15
00007a66921e1bd2  movaps [r15+0x1F0], xmm15
00007a66921e1bda  mov qword ptr [r15+0x40], 0x430000
00007a66921e1be2  mov r14d, 0x430510
00007a66921e1be8  mov r12, [r13+r14*1]
00007a66921e1bed  movq xmm1, r12
00007a66921e1bf2  lea r14, [rax+0x150]
00007a66921e1bf9  mov [r15+0xF8], r14
00007a66921e1c00  mov rax, [r15+0x50]
00007a66921e1c04  movups xmm15, [r13+rax*1]
00007a66921e1c0a  movaps [r15+0x120], xmm15
00007a66921e1c12  mov qword ptr [r15+0x48], 0x10
00007a66921e1c1a  xor eax, eax
00007a66921e1c1c  mov r14d, 0x10
00007a66921e1c22  mov r12d, 0x200
00007a66921e1c28  cmp r14, r12
00007a66921e1c2b  cmc
00007a66921e1c2c  lahf
00007a66921e1c2d  seto al
00007a66921e1c30  mov [r15+0x108], eax
00007a66921e1c37  pextrq rax, xmm15, 0x01
00007a66921e1c3e  movq xmm14, rax
00007a66921e1c43  movaps [r15+0x130], xmm14
00007a66921e1c4b  movq rax, xmm1
00007a66921e1c50  movq r14, xmm15
00007a66921e1c55  vmovq xmm1, rax
00007a66921e1c5a  vmovq xmm15, r14
00007a66921e1c5f  movaps xmm13, xmm1
00007a66921e1c63  addsd xmm13, xmm15
00007a66921e1c68  ucomisd xmm13, xmm13
00007a66921e1c6d  jp 0x00007A66921E1D86
00007a66921e1c73  movq xmm13, xmm13
00007a66921e1c78  movq rax, xmm13
00007a66921e1c7d  movq r14, xmm14
00007a66921e1c82  vmovq xmm1, rax
00007a66921e1c87  vmovq xmm15, r14
00007a66921e1c8c  movaps xmm14, xmm1
00007a66921e1c90  addsd xmm14, xmm15
00007a66921e1c95  ucomisd xmm14, xmm14
00007a66921e1c9a  jp 0x00007A66921E1DCE
00007a66921e1ca0  movq xmm14, xmm14
00007a66921e1ca5  movaps [r15+0x110], xmm14
00007a66921e1cad  mov eax, [r15+0x108]
00007a66921e1cb4  sahf
00007a66921e1cb5  jnz 0x00007A66921E1CE7
00007a66921e1cb7  cmp dword ptr [r15+0x318], 0x00
00007a66921e1cbf  jz 0x00007A66921E1FE0
00007a66921e1cc5  nop [rax+rax*1], ax
00007a66921e1cce  nop [rax+rax*1], eax
00007a66921e1cd6  mov eax, 0x410490
00007a66921e1cdb  mov [r15+0x100], rax
00007a66921e1ce2  jmp 0x00007A6691FFE110
00007a66921e1ce7  cmp dword ptr [r15+0x318], 0x00
00007a66921e1cef  jz 0x00007A66921E1E20
00007a66921e1cf5  nop [rax+rax*1], ax
00007a66921e1cfe  nop [rax+rax*1], eax
00007a66921e1d06  mov eax, 0x410474
00007a66921e1d0b  mov [r15+0x100], rax
00007a66921e1d12  jmp 0x00007A6691FFE110
00007a66921e1d17  int3
00007a66921e1d18  call 0x00007A66920E27E0
00007a66921e1d1d  jmp 0x00007A66921E1AC3
00007a66921e1d22  call 0x00007A66920E27E0
00007a66921e1d27  jmp 0x00007A66921E1AD6
00007a66921e1d2c  call 0x00007A66920E1570
00007a66921e1d31  jmp 0x00007A66921E1AE2
00007a66921e1d36  call 0x00007A66920E27E0
00007a66921e1d3b  jmp 0x00007A66921E1B1A
00007a66921e1d40  call 0x00007A66920E1570
00007a66921e1d45  jmp 0x00007A66921E1B26
00007a66921e1d4a  call 0x00007A66920E27E0
00007a66921e1d4f  jmp 0x00007A66921E1B5E
00007a66921e1d54  call 0x00007A66920E1570
00007a66921e1d59  jmp 0x00007A66921E1B6A
00007a66921e1d5e  call 0x00007A66920E27E0
00007a66921e1d63  jmp 0x00007A66921E1BA2
00007a66921e1d68  call 0x00007A66920E1570
00007a66921e1d6d  jmp 0x00007A66921E1BAE
00007a66921e1d72  call 0x00007A66920E27E0
00007a66921e1d77  jmp 0x00007A66921E1BED
00007a66921e1d7c  call 0x00007A669200E760
00007a66921e1d81  jmp 0x00007A66921E1C0A
00007a66921e1d86  ucomisd xmm1, xmm15
00007a66921e1d8b  jp 0x00007A66921E1D9A
00007a66921e1d8d  movaps xmm13, [0x00007A6691DFE060]
00007a66921e1d95  jmp 0x00007A66921E1C73
00007a66921e1d9a  vxorps xmm0, xmm1, xmm15
00007a66921e1d9f  pextrw eax, xmm0, 0x03
00007a66921e1da4  and eax, 0x7FF8
00007a66921e1da9  cmp eax, 0x08
00007a66921e1dac  jnz 0x00007A66921E1C73
00007a66921e1db2  movq rax, xmm15
00007a66921e1db7  shl rax, 0x0D
00007a66921e1dbb  jbe 0x00007A66921E1C73
00007a66921e1dc1  vorps xmm13, xmm15, [0x00007A6691DFE070]
00007a66921e1dc9  jmp 0x00007A66921E1C73
00007a66921e1dce  ucomisd xmm1, xmm15
00007a66921e1dd3  jp 0x00007A66921E1DE2
00007a66921e1dd5  movaps xmm14, [0x00007A6691DFE060]
00007a66921e1ddd  jmp 0x00007A66921E1CA0
00007a66921e1de2  vxorps xmm0, xmm1, xmm15
00007a66921e1de7  pextrw eax, xmm0, 0x03
00007a66921e1dec  and eax, 0x7FF8
00007a66921e1df1  cmp eax, 0x08
00007a66921e1df4  jnz 0x00007A66921E1CA0
00007a66921e1dfa  movq rax, xmm15
00007a66921e1dff  shl rax, 0x0D
00007a66921e1e03  jbe 0x00007A66921E1CA0
00007a66921e1e09  vorps xmm14, xmm15, [0x00007A6691DFE070]
00007a66921e1e11  jmp 0x00007A66921E1CA0
00007a66921e1e16  int3
00007a66921e1e17  nop [rax+rax*1], ax
00007a66921e1e20  mov rax, [r15+0x48]
00007a66921e1e24  mov r14, [r15+0x50]
00007a66921e1e28  lea r12, [r14+rax*1]
00007a66921e1e2c  movups xmm1, [r13+r12*1]
00007a66921e1e32  movaps [r15+0x120], xmm1
00007a66921e1e3a  lea r14, [rax+0x10]
00007a66921e1e3e  mov [r15+0x48], r14
00007a66921e1e42  xor eax, eax
00007a66921e1e44  mov r12d, 0x200
00007a66921e1e4a  cmp r14, r12
00007a66921e1e4d  cmc
00007a66921e1e4e  lahf
00007a66921e1e4f  seto al
00007a66921e1e52  mov [r15+0x108], eax
00007a66921e1e59  pextrq rax, xmm1, 0x01
00007a66921e1e60  movq xmm15, rax
00007a66921e1e65  movaps [r15+0x130], xmm15
00007a66921e1e6d  movaps xmm14, [r15+0x110]
00007a66921e1e75  movq rax, xmm14
00007a66921e1e7a  movq r14, xmm1
00007a66921e1e7f  vmovq xmm1, rax
00007a66921e1e84  vmovq xmm14, r14
00007a66921e1e89  movaps xmm13, xmm1
00007a66921e1e8d  addsd xmm13, xmm14
00007a66921e1e92  ucomisd xmm13, xmm13
00007a66921e1e97  jp 0x00007A66921E1F4C
00007a66921e1e9d  movq xmm13, xmm13
00007a66921e1ea2  movq rax, xmm13
00007a66921e1ea7  movq r14, xmm15
00007a66921e1eac  vmovq xmm1, rax
00007a66921e1eb1  vmovq xmm15, r14
00007a66921e1eb6  movaps xmm14, xmm1
00007a66921e1eba  addsd xmm14, xmm15
00007a66921e1ebf  ucomisd xmm14, xmm14
00007a66921e1ec4  jp 0x00007A66921E1F94
00007a66921e1eca  movq xmm14, xmm14
00007a66921e1ecf  movaps [r15+0x110], xmm14
00007a66921e1ed7  mov eax, [r15+0x108]
00007a66921e1ede  sahf
00007a66921e1edf  jnz 0x00007A66921E1F11
00007a66921e1ee1  cmp dword ptr [r15+0x318], 0x00
00007a66921e1ee9  jz 0x00007A66921E1FE0
00007a66921e1eef  nop [rax+rax*1], ax
00007a66921e1ef8  nop [rax+rax*1], eax
00007a66921e1f00  mov eax, 0x410490
00007a66921e1f05  mov [r15+0x100], rax
00007a66921e1f0c  jmp 0x00007A6691FFE110
00007a66921e1f11  cmp dword ptr [r15+0x318], 0x00
00007a66921e1f19  jz 0x00007A66921E1E20
00007a66921e1f1f  nop [rax+rax*1], ax
00007a66921e1f28  nop [rax+rax*1], eax
00007a66921e1f30  mov eax, 0x410474
00007a66921e1f35  mov [r15+0x100], rax
00007a66921e1f3c  jmp 0x00007A6691FFE110
00007a66921e1f41  int3
00007a66921e1f42  call 0x00007A66920B52F0
00007a66921e1f47  jmp 0x00007A66921E1E32
00007a66921e1f4c  ucomisd xmm1, xmm14
00007a66921e1f51  jp 0x00007A66921E1F60
00007a66921e1f53  movaps xmm13, [0x00007A6691DFE060]
00007a66921e1f5b  jmp 0x00007A66921E1E9D
00007a66921e1f60  vxorps xmm0, xmm1, xmm14
00007a66921e1f65  pextrw eax, xmm0, 0x03
00007a66921e1f6a  and eax, 0x7FF8
00007a66921e1f6f  cmp eax, 0x08
00007a66921e1f72  jnz 0x00007A66921E1E9D
00007a66921e1f78  movq rax, xmm14
00007a66921e1f7d  shl rax, 0x0D
00007a66921e1f81  jbe 0x00007A66921E1E9D
00007a66921e1f87  vorps xmm13, xmm14, [0x00007A6691DFE070]
00007a66921e1f8f  jmp 0x00007A66921E1E9D
00007a66921e1f94  ucomisd xmm1, xmm15
00007a66921e1f99  jp 0x00007A66921E1FA8
00007a66921e1f9b  movaps xmm14, [0x00007A6691DFE060]
00007a66921e1fa3  jmp 0x00007A66921E1ECA
00007a66921e1fa8  vxorps xmm0, xmm1, xmm15
00007a66921e1fad  pextrw eax, xmm0, 0x03
00007a66921e1fb2  and eax, 0x7FF8
00007a66921e1fb7  cmp eax, 0x08
00007a66921e1fba  jnz 0x00007A66921E1ECA
00007a66921e1fc0  movq rax, xmm15
00007a66921e1fc5  shl rax, 0x0D
00007a66921e1fc9  jbe 0x00007A66921E1ECA
00007a66921e1fcf  vorps xmm14, xmm15, [0x00007A6691DFE070]
00007a66921e1fd7  jmp 0x00007A66921E1ECA
00007a66921e1fdc  int3
00007a66921e1fdd  nop [rax], eax
00007a66921e1fe0  mov rax, [r15+0x40]
00007a66921e1fe4  lea r14, [rax+0x510]
00007a66921e1feb  movaps xmm1, [r15+0x110]
00007a66921e1ff3  movq rax, xmm1
00007a66921e1ff8  mov [r13+r14*1], rax
00007a66921e1ffd  mov rax, [r15+0xF0]
00007a66921e2004  mov [r15+0x100], rax
00007a66921e200b  jmp 0x00007A66921CE5C0
00007a66921e2010  int3
00007a66921e2011  call 0x00007A66920D5EB0
00007a66921e2016  jmp 0x00007A66921E1FFD
00007a66921e201b  int3
00007a66921e201c  nop [rax], eax
00007a66921e2020  mov qword ptr [r15+0x100], 0x04
00007a66921e202b  mov esi, 0x00
00007a66921e2030  mov edx, 0x09
00007a66921e2035  mov rdi, 0x7FFEB9EBF690
00007a66921e203f  mov rax, 0x635346C5A970
00007a66921e2049  call rax
00007a66921e204b  cmp dword ptr [r15+0x318], 0x00
00007a66921e2053  jnz 0x00007A6691FFE110
00007a66921e2059  jmp 0x00007A6691FFE0A0
00007a66921e205e  int3
00007a66921e205f  int3
