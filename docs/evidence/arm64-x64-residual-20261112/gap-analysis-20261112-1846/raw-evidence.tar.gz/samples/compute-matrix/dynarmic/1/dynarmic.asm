00007fdcd91ce69b  nop [rax+rax*1], eax
00007fdcd91ce6a0  vmovaps xmm1, [0x00007FDCD8DFE010]
00007fdcd91ce6a8  movq xmm1, xmm1
00007fdcd91ce6ac  movaps [r15+0x110], xmm1
00007fdcd91ce6b4  vmovaps xmm1, [0x00007FDCD8DFE020]
00007fdcd91ce6bc  movq xmm1, xmm1
00007fdcd91ce6c0  movaps [r15+0x120], xmm1
00007fdcd91ce6c8  mov eax, 0x4204C0
00007fdcd91ce6cd  mov r14, [r13+rax*1]
00007fdcd91ce6d2  movq xmm1, r14
00007fdcd91ce6d7  movaps [r15+0x130], xmm1
00007fdcd91ce6df  vmovaps xmm1, [0x00007FDCD8DFE030]
00007fdcd91ce6e7  vpbroadcastq xmm1, xmm1
00007fdcd91ce6ec  movaps [r15+0x140], xmm1
00007fdcd91ce6f4  mov qword ptr [r15+0x40], 0x02
00007fdcd91ce6fc  vmovaps xmm15, [0x00007FDCD8DFE040]
00007fdcd91ce704  movq xmm15, xmm15
00007fdcd91ce709  movaps [r15+0x150], xmm15
00007fdcd91ce711  mov qword ptr [r15+0x58], 0x420000
00007fdcd91ce719  vmovaps xmm15, [0x00007FDCD8DFE050]
00007fdcd91ce721  vpbroadcastq xmm15, xmm15
00007fdcd91ce726  movaps [r15+0x160], xmm15
00007fdcd91ce72e  mov rax, [r15+0x40]
00007fdcd91ce732  vmovq xmm14, rax
00007fdcd91ce737  vpbroadcastq xmm14, xmm14
00007fdcd91ce73c  movaps [r15+0x170], xmm14
00007fdcd91ce744  mov eax, 0x4204D0
00007fdcd91ce749  movups xmm13, [r13+rax*1]
00007fdcd91ce74f  mov qword ptr [r15+0x40], 0x430518
00007fdcd91ce757  mov qword ptr [r15+0x50], 0x430720
00007fdcd91ce75f  vpmovqd xmm12, xmm13
00007fdcd91ce765  pxor xmm11, xmm11
00007fdcd91ce76a  punpcklqdq xmm12, xmm11
00007fdcd91ce76f  movaps [r15+0x210], xmm12
00007fdcd91ce777  movq xmm12, qword ptr [r15+0x120]
00007fdcd91ce780  movq xmm11, qword ptr [r15+0x130]
00007fdcd91ce789  psubd xmm12, xmm11
00007fdcd91ce78e  movq xmm12, xmm12
00007fdcd91ce793  paddq xmm13, xmm14
00007fdcd91ce798  movaps [r15+0x180], xmm13
00007fdcd91ce7a0  movq xmm14, qword ptr [r15+0x150]
00007fdcd91ce7a9  paddd xmm11, xmm14
00007fdcd91ce7ae  movq xmm11, xmm11
00007fdcd91ce7b3  movq xmm11, xmm11
00007fdcd91ce7b8  movaps [r15+0x130], xmm11
00007fdcd91ce7c0  pmovzxdq xmm12, xmm12
00007fdcd91ce7c6  psllq xmm12, 0x00
00007fdcd91ce7cc  movq xmm14, qword ptr [r15+0x210]
00007fdcd91ce7d5  movq xmm13, qword ptr [r15+0x110]
00007fdcd91ce7de  paddd xmm14, xmm13
00007fdcd91ce7e3  movq xmm14, xmm14
00007fdcd91ce7e8  vcvtuqq2pd xmm12, xmm12
00007fdcd91ce7ee  pmovzxdq xmm14, xmm14
00007fdcd91ce7f4  psllq xmm14, 0x00
00007fdcd91ce7fa  vcvtuqq2pd xmm14, xmm14
00007fdcd91ce800  movaps xmm13, xmm12
00007fdcd91ce804  mulpd xmm13, xmm1
00007fdcd91ce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007fdcd91ce80f  ptest xmm11, xmm11
00007fdcd91ce815  jnz 0x00007FDCD91CE8FF
00007fdcd91ce81b  movaps [r15+0x220], xmm13
00007fdcd91ce823  mov eax, 0x430720
00007fdcd91ce828  movups [r13+rax*1], xmm13
00007fdcd91ce82e  movaps xmm1, xmm14
00007fdcd91ce832  mulpd xmm1, xmm15
00007fdcd91ce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007fdcd91ce83c  ptest xmm13, xmm13
00007fdcd91ce842  jnz 0x00007FDCD91CEA4C
00007fdcd91ce848  movaps [r15+0x210], xmm1
00007fdcd91ce850  mov eax, 0x430518
00007fdcd91ce855  movups [r13+rax*1], xmm1
00007fdcd91ce85b  mov qword ptr [r15+0x48], 0x10
00007fdcd91ce863  xor eax, eax
00007fdcd91ce865  mov r14d, 0x10
00007fdcd91ce86b  mov r12d, 0x200
00007fdcd91ce871  cmp r14, r12
00007fdcd91ce874  cmc
00007fdcd91ce875  lahf
00007fdcd91ce876  seto al
00007fdcd91ce879  mov [r15+0x108], eax
00007fdcd91ce880  mov eax, [r15+0x108]
00007fdcd91ce887  sahf
00007fdcd91ce888  jnz 0x00007FDCD91CE8BA
00007fdcd91ce88a  cmp dword ptr [r15+0x318], 0x00
00007fdcd91ce892  jz 0x00007FDCD91CEFF0
00007fdcd91ce898  nop [rax+rax*1], ax
00007fdcd91ce8a1  nop [rax+rax*1], eax
00007fdcd91ce8a9  mov eax, 0x4101EC
00007fdcd91ce8ae  mov [r15+0x100], rax
00007fdcd91ce8b5  jmp 0x00007FDCD8FFE110
00007fdcd91ce8ba  cmp dword ptr [r15+0x318], 0x00
00007fdcd91ce8c2  jz 0x00007FDCD91CEBA0
00007fdcd91ce8c8  nop [rax+rax*1], ax
00007fdcd91ce8d1  nop [rax+rax*1], eax
00007fdcd91ce8d9  mov eax, 0x4101AC
00007fdcd91ce8de  mov [r15+0x100], rax
00007fdcd91ce8e5  jmp 0x00007FDCD8FFE110
00007fdcd91ce8ea  int3
00007fdcd91ce8eb  call 0x00007FDCD900DC20
00007fdcd91ce8f0  jmp 0x00007FDCD91CE6D2
00007fdcd91ce8f5  call 0x00007FDCD900C260
00007fdcd91ce8fa  jmp 0x00007FDCD91CE74F
00007fdcd91ce8ff  sub rsp, 0x08
00007fdcd91ce903  push rax
00007fdcd91ce904  push rcx
00007fdcd91ce905  push rdx
00007fdcd91ce906  push rdi
00007fdcd91ce907  push rsi
00007fdcd91ce908  push r8
00007fdcd91ce90a  push r9
00007fdcd91ce90c  push r10
00007fdcd91ce90e  push r11
00007fdcd91ce910  sub rsp, 0xF0
00007fdcd91ce917  vmovaps [rsp], xmm0
00007fdcd91ce91c  vmovaps [rsp+0x10], xmm1
00007fdcd91ce922  vmovaps [rsp+0x20], xmm2
00007fdcd91ce928  vmovaps [rsp+0x30], xmm3
00007fdcd91ce92e  vmovaps [rsp+0x40], xmm4
00007fdcd91ce934  vmovaps [rsp+0x50], xmm5
00007fdcd91ce93a  vmovaps [rsp+0x60], xmm6
00007fdcd91ce940  vmovaps [rsp+0x70], xmm7
00007fdcd91ce946  vmovaps [rsp+0x80], xmm8
00007fdcd91ce94f  vmovaps [rsp+0x90], xmm9
00007fdcd91ce958  vmovaps [rsp+0xA0], xmm10
00007fdcd91ce961  vmovaps [rsp+0xB0], xmm11
00007fdcd91ce96a  vmovaps [rsp+0xC0], xmm12
00007fdcd91ce973  vmovaps [rsp+0xD0], xmm14
00007fdcd91ce97c  vmovaps [rsp+0xE0], xmm15
00007fdcd91ce985  sub rsp, 0x30
00007fdcd91ce989  movaps [rsp], xmm13
00007fdcd91ce98e  movaps [rsp+0x10], xmm12
00007fdcd91ce994  movaps [rsp+0x20], xmm1
00007fdcd91ce999  lea rdi, [rsp]
00007fdcd91ce99d  mov esi, 0x00
00007fdcd91ce9a2  mov rax, 0x5B56EFBF3530
00007fdcd91ce9ac  call rax
00007fdcd91ce9ae  movaps xmm13, [rsp]
00007fdcd91ce9b3  add rsp, 0x30
00007fdcd91ce9b7  vmovaps xmm0, [rsp]
00007fdcd91ce9bc  vmovaps xmm1, [rsp+0x10]
00007fdcd91ce9c2  vmovaps xmm2, [rsp+0x20]
00007fdcd91ce9c8  vmovaps xmm3, [rsp+0x30]
00007fdcd91ce9ce  vmovaps xmm4, [rsp+0x40]
00007fdcd91ce9d4  vmovaps xmm5, [rsp+0x50]
00007fdcd91ce9da  vmovaps xmm6, [rsp+0x60]
00007fdcd91ce9e0  vmovaps xmm7, [rsp+0x70]
00007fdcd91ce9e6  vmovaps xmm8, [rsp+0x80]
00007fdcd91ce9ef  vmovaps xmm9, [rsp+0x90]
00007fdcd91ce9f8  vmovaps xmm10, [rsp+0xA0]
00007fdcd91cea01  vmovaps xmm11, [rsp+0xB0]
00007fdcd91cea0a  vmovaps xmm12, [rsp+0xC0]
00007fdcd91cea13  vmovaps xmm14, [rsp+0xD0]
00007fdcd91cea1c  vmovaps xmm15, [rsp+0xE0]
00007fdcd91cea25  add rsp, 0xF0
00007fdcd91cea2c  pop r11
00007fdcd91cea2e  pop r10
00007fdcd91cea30  pop r9
00007fdcd91cea32  pop r8
00007fdcd91cea34  pop rsi
00007fdcd91cea35  pop rdi
00007fdcd91cea36  pop rdx
00007fdcd91cea37  pop rcx
00007fdcd91cea38  pop rax
00007fdcd91cea39  add rsp, 0x08
00007fdcd91cea3d  jmp 0x00007FDCD91CE81B
00007fdcd91cea42  call 0x00007FDCD900C380
00007fdcd91cea47  jmp 0x00007FDCD91CE82E
00007fdcd91cea4c  sub rsp, 0x08
00007fdcd91cea50  push rax
00007fdcd91cea51  push rcx
00007fdcd91cea52  push rdx
00007fdcd91cea53  push rdi
00007fdcd91cea54  push rsi
00007fdcd91cea55  push r8
00007fdcd91cea57  push r9
00007fdcd91cea59  push r10
00007fdcd91cea5b  push r11
00007fdcd91cea5d  sub rsp, 0xF0
00007fdcd91cea64  vmovaps [rsp], xmm0
00007fdcd91cea69  vmovaps [rsp+0x10], xmm2
00007fdcd91cea6f  vmovaps [rsp+0x20], xmm3
00007fdcd91cea75  vmovaps [rsp+0x30], xmm4
00007fdcd91cea7b  vmovaps [rsp+0x40], xmm5
00007fdcd91cea81  vmovaps [rsp+0x50], xmm6
00007fdcd91cea87  vmovaps [rsp+0x60], xmm7
00007fdcd91cea8d  vmovaps [rsp+0x70], xmm8
00007fdcd91cea93  vmovaps [rsp+0x80], xmm9
00007fdcd91cea9c  vmovaps [rsp+0x90], xmm10
00007fdcd91ceaa5  vmovaps [rsp+0xA0], xmm11
00007fdcd91ceaae  vmovaps [rsp+0xB0], xmm12
00007fdcd91ceab7  vmovaps [rsp+0xC0], xmm13
00007fdcd91ceac0  vmovaps [rsp+0xD0], xmm14
00007fdcd91ceac9  vmovaps [rsp+0xE0], xmm15
00007fdcd91cead2  sub rsp, 0x30
00007fdcd91cead6  movaps [rsp], xmm1
00007fdcd91ceada  movaps [rsp+0x10], xmm14
00007fdcd91ceae0  movaps [rsp+0x20], xmm15
00007fdcd91ceae6  lea rdi, [rsp]
00007fdcd91ceaea  mov esi, 0x00
00007fdcd91ceaef  mov rax, 0x5B56EFBF3530
00007fdcd91ceaf9  call rax
00007fdcd91ceafb  movaps xmm1, [rsp]
00007fdcd91ceaff  add rsp, 0x30
00007fdcd91ceb03  vmovaps xmm0, [rsp]
00007fdcd91ceb08  vmovaps xmm2, [rsp+0x10]
00007fdcd91ceb0e  vmovaps xmm3, [rsp+0x20]
00007fdcd91ceb14  vmovaps xmm4, [rsp+0x30]
00007fdcd91ceb1a  vmovaps xmm5, [rsp+0x40]
00007fdcd91ceb20  vmovaps xmm6, [rsp+0x50]
00007fdcd91ceb26  vmovaps xmm7, [rsp+0x60]
00007fdcd91ceb2c  vmovaps xmm8, [rsp+0x70]
00007fdcd91ceb32  vmovaps xmm9, [rsp+0x80]
00007fdcd91ceb3b  vmovaps xmm10, [rsp+0x90]
00007fdcd91ceb44  vmovaps xmm11, [rsp+0xA0]
00007fdcd91ceb4d  vmovaps xmm12, [rsp+0xB0]
00007fdcd91ceb56  vmovaps xmm13, [rsp+0xC0]
00007fdcd91ceb5f  vmovaps xmm14, [rsp+0xD0]
00007fdcd91ceb68  vmovaps xmm15, [rsp+0xE0]
00007fdcd91ceb71  add rsp, 0xF0
00007fdcd91ceb78  pop r11
00007fdcd91ceb7a  pop r10
00007fdcd91ceb7c  pop r9
00007fdcd91ceb7e  pop r8
00007fdcd91ceb80  pop rsi
00007fdcd91ceb81  pop rdi
00007fdcd91ceb82  pop rdx
00007fdcd91ceb83  pop rcx
00007fdcd91ceb84  pop rax
00007fdcd91ceb85  add rsp, 0x08
00007fdcd91ceb89  jmp 0x00007FDCD91CE848
00007fdcd91ceb8e  call 0x00007FDCD8FFF540
00007fdcd91ceb93  jmp 0x00007FDCD91CE85B
00007fdcd91ceb98  int3
00007fdcd91ceb99  nop [rax], eax
00007fdcd91ceba0  movaps xmm1, [r15+0x180]
00007fdcd91ceba8  vpmovqd xmm15, xmm1
00007fdcd91cebae  pxor xmm14, xmm14
00007fdcd91cebb3  punpcklqdq xmm15, xmm14
00007fdcd91cebb8  movaps [r15+0x210], xmm15
00007fdcd91cebc0  movq xmm15, qword ptr [r15+0x120]
00007fdcd91cebc9  movq xmm14, qword ptr [r15+0x130]
00007fdcd91cebd2  psubd xmm15, xmm14
00007fdcd91cebd7  movq xmm15, xmm15
00007fdcd91cebdc  movaps xmm13, [r15+0x170]
00007fdcd91cebe4  paddq xmm1, xmm13
00007fdcd91cebe9  movaps [r15+0x180], xmm1
00007fdcd91cebf1  movq xmm1, qword ptr [r15+0x150]
00007fdcd91cebfa  paddd xmm14, xmm1
00007fdcd91cebff  movq xmm14, xmm14
00007fdcd91cec04  movq xmm14, xmm14
00007fdcd91cec09  movaps [r15+0x130], xmm14
00007fdcd91cec11  pmovzxdq xmm15, xmm15
00007fdcd91cec17  psllq xmm15, 0x00
00007fdcd91cec1d  movq xmm1, qword ptr [r15+0x210]
00007fdcd91cec26  movq xmm14, qword ptr [r15+0x110]
00007fdcd91cec2f  paddd xmm1, xmm14
00007fdcd91cec34  movq xmm1, xmm1
00007fdcd91cec38  vcvtuqq2pd xmm15, xmm15
00007fdcd91cec3e  pmovzxdq xmm1, xmm1
00007fdcd91cec43  psllq xmm1, 0x00
00007fdcd91cec48  vcvtuqq2pd xmm1, xmm1
00007fdcd91cec4e  movaps xmm14, [r15+0x140]
00007fdcd91cec56  movaps xmm13, xmm15
00007fdcd91cec5a  mulpd xmm13, xmm14
00007fdcd91cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007fdcd91cec65  ptest xmm12, xmm12
00007fdcd91cec6b  jnz 0x00007FDCD91CED4E
00007fdcd91cec71  movaps [r15+0x220], xmm13
00007fdcd91cec79  mov rax, [r15+0x48]
00007fdcd91cec7d  mov r14, [r15+0x50]
00007fdcd91cec81  lea r12, [r14+rax*1]
00007fdcd91cec85  movups [r13+r12*1], xmm13
00007fdcd91cec8b  movaps xmm15, [r15+0x160]
00007fdcd91cec93  movaps xmm14, xmm1
00007fdcd91cec97  mulpd xmm14, xmm15
00007fdcd91cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007fdcd91ceca2  ptest xmm13, xmm13
00007fdcd91ceca8  jnz 0x00007FDCD91CEE9C
00007fdcd91cecae  movaps [r15+0x210], xmm14
00007fdcd91cecb6  mov r14, [r15+0x40]
00007fdcd91cecba  lea r12, [r14+rax*1]
00007fdcd91cecbe  movups [r13+r12*1], xmm14
00007fdcd91cecc4  lea r14, [rax+0x10]
00007fdcd91cecc8  mov [r15+0x48], r14
00007fdcd91ceccc  xor eax, eax
00007fdcd91cecce  mov r12d, 0x200
00007fdcd91cecd4  cmp r14, r12
00007fdcd91cecd7  cmc
00007fdcd91cecd8  lahf
00007fdcd91cecd9  seto al
00007fdcd91cecdc  mov [r15+0x108], eax
00007fdcd91cece3  mov eax, [r15+0x108]
00007fdcd91cecea  sahf
00007fdcd91ceceb  jnz 0x00007FDCD91CED1D
00007fdcd91ceced  cmp dword ptr [r15+0x318], 0x00
00007fdcd91cecf5  jz 0x00007FDCD91CEFF0
00007fdcd91cecfb  nop [rax+rax*1], ax
00007fdcd91ced04  nop [rax+rax*1], eax
00007fdcd91ced0c  mov eax, 0x4101EC
00007fdcd91ced11  mov [r15+0x100], rax
00007fdcd91ced18  jmp 0x00007FDCD8FFE110
00007fdcd91ced1d  cmp dword ptr [r15+0x318], 0x00
00007fdcd91ced25  jz 0x00007FDCD91CEBA0
00007fdcd91ced2b  nop [rax+rax*1], ax
00007fdcd91ced34  nop [rax+rax*1], eax
00007fdcd91ced3c  mov eax, 0x4101AC
00007fdcd91ced41  mov [r15+0x100], rax
00007fdcd91ced48  jmp 0x00007FDCD8FFE110
00007fdcd91ced4d  int3
00007fdcd91ced4e  sub rsp, 0x08
00007fdcd91ced52  push rax
00007fdcd91ced53  push rcx
00007fdcd91ced54  push rdx
00007fdcd91ced55  push rdi
00007fdcd91ced56  push rsi
00007fdcd91ced57  push r8
00007fdcd91ced59  push r9
00007fdcd91ced5b  push r10
00007fdcd91ced5d  push r11
00007fdcd91ced5f  sub rsp, 0xF0
00007fdcd91ced66  vmovaps [rsp], xmm0
00007fdcd91ced6b  vmovaps [rsp+0x10], xmm1
00007fdcd91ced71  vmovaps [rsp+0x20], xmm2
00007fdcd91ced77  vmovaps [rsp+0x30], xmm3
00007fdcd91ced7d  vmovaps [rsp+0x40], xmm4
00007fdcd91ced83  vmovaps [rsp+0x50], xmm5
00007fdcd91ced89  vmovaps [rsp+0x60], xmm6
00007fdcd91ced8f  vmovaps [rsp+0x70], xmm7
00007fdcd91ced95  vmovaps [rsp+0x80], xmm8
00007fdcd91ced9e  vmovaps [rsp+0x90], xmm9
00007fdcd91ceda7  vmovaps [rsp+0xA0], xmm10
00007fdcd91cedb0  vmovaps [rsp+0xB0], xmm11
00007fdcd91cedb9  vmovaps [rsp+0xC0], xmm12
00007fdcd91cedc2  vmovaps [rsp+0xD0], xmm14
00007fdcd91cedcb  vmovaps [rsp+0xE0], xmm15
00007fdcd91cedd4  sub rsp, 0x30
00007fdcd91cedd8  movaps [rsp], xmm13
00007fdcd91ceddd  movaps [rsp+0x10], xmm15
00007fdcd91cede3  movaps [rsp+0x20], xmm14
00007fdcd91cede9  lea rdi, [rsp]
00007fdcd91ceded  mov esi, 0x00
00007fdcd91cedf2  mov rax, 0x5B56EFBF3530
00007fdcd91cedfc  call rax
00007fdcd91cedfe  movaps xmm13, [rsp]
00007fdcd91cee03  add rsp, 0x30
00007fdcd91cee07  vmovaps xmm0, [rsp]
00007fdcd91cee0c  vmovaps xmm1, [rsp+0x10]
00007fdcd91cee12  vmovaps xmm2, [rsp+0x20]
00007fdcd91cee18  vmovaps xmm3, [rsp+0x30]
00007fdcd91cee1e  vmovaps xmm4, [rsp+0x40]
00007fdcd91cee24  vmovaps xmm5, [rsp+0x50]
00007fdcd91cee2a  vmovaps xmm6, [rsp+0x60]
00007fdcd91cee30  vmovaps xmm7, [rsp+0x70]
00007fdcd91cee36  vmovaps xmm8, [rsp+0x80]
00007fdcd91cee3f  vmovaps xmm9, [rsp+0x90]
00007fdcd91cee48  vmovaps xmm10, [rsp+0xA0]
00007fdcd91cee51  vmovaps xmm11, [rsp+0xB0]
00007fdcd91cee5a  vmovaps xmm12, [rsp+0xC0]
00007fdcd91cee63  vmovaps xmm14, [rsp+0xD0]
00007fdcd91cee6c  vmovaps xmm15, [rsp+0xE0]
00007fdcd91cee75  add rsp, 0xF0
00007fdcd91cee7c  pop r11
00007fdcd91cee7e  pop r10
00007fdcd91cee80  pop r9
00007fdcd91cee82  pop r8
00007fdcd91cee84  pop rsi
00007fdcd91cee85  pop rdi
00007fdcd91cee86  pop rdx
00007fdcd91cee87  pop rcx
00007fdcd91cee88  pop rax
00007fdcd91cee89  add rsp, 0x08
00007fdcd91cee8d  jmp 0x00007FDCD91CEC71
00007fdcd91cee92  call 0x00007FDCD90C2240
00007fdcd91cee97  jmp 0x00007FDCD91CEC8B
00007fdcd91cee9c  sub rsp, 0x08
00007fdcd91ceea0  push rax
00007fdcd91ceea1  push rcx
00007fdcd91ceea2  push rdx
00007fdcd91ceea3  push rdi
00007fdcd91ceea4  push rsi
00007fdcd91ceea5  push r8
00007fdcd91ceea7  push r9
00007fdcd91ceea9  push r10
00007fdcd91ceeab  push r11
00007fdcd91ceead  sub rsp, 0xF0
00007fdcd91ceeb4  vmovaps [rsp], xmm0
00007fdcd91ceeb9  vmovaps [rsp+0x10], xmm1
00007fdcd91ceebf  vmovaps [rsp+0x20], xmm2
00007fdcd91ceec5  vmovaps [rsp+0x30], xmm3
00007fdcd91ceecb  vmovaps [rsp+0x40], xmm4
00007fdcd91ceed1  vmovaps [rsp+0x50], xmm5
00007fdcd91ceed7  vmovaps [rsp+0x60], xmm6
00007fdcd91ceedd  vmovaps [rsp+0x70], xmm7
00007fdcd91ceee3  vmovaps [rsp+0x80], xmm8
00007fdcd91ceeec  vmovaps [rsp+0x90], xmm9
00007fdcd91ceef5  vmovaps [rsp+0xA0], xmm10
00007fdcd91ceefe  vmovaps [rsp+0xB0], xmm11
00007fdcd91cef07  vmovaps [rsp+0xC0], xmm12
00007fdcd91cef10  vmovaps [rsp+0xD0], xmm13
00007fdcd91cef19  vmovaps [rsp+0xE0], xmm15
00007fdcd91cef22  sub rsp, 0x30
00007fdcd91cef26  movaps [rsp], xmm14
00007fdcd91cef2b  movaps [rsp+0x10], xmm1
00007fdcd91cef30  movaps [rsp+0x20], xmm15
00007fdcd91cef36  lea rdi, [rsp]
00007fdcd91cef3a  mov esi, 0x00
00007fdcd91cef3f  mov rax, 0x5B56EFBF3530
00007fdcd91cef49  call rax
00007fdcd91cef4b  movaps xmm14, [rsp]
00007fdcd91cef50  add rsp, 0x30
00007fdcd91cef54  vmovaps xmm0, [rsp]
00007fdcd91cef59  vmovaps xmm1, [rsp+0x10]
00007fdcd91cef5f  vmovaps xmm2, [rsp+0x20]
00007fdcd91cef65  vmovaps xmm3, [rsp+0x30]
00007fdcd91cef6b  vmovaps xmm4, [rsp+0x40]
00007fdcd91cef71  vmovaps xmm5, [rsp+0x50]
00007fdcd91cef77  vmovaps xmm6, [rsp+0x60]
00007fdcd91cef7d  vmovaps xmm7, [rsp+0x70]
00007fdcd91cef83  vmovaps xmm8, [rsp+0x80]
00007fdcd91cef8c  vmovaps xmm9, [rsp+0x90]
00007fdcd91cef95  vmovaps xmm10, [rsp+0xA0]
00007fdcd91cef9e  vmovaps xmm11, [rsp+0xB0]
00007fdcd91cefa7  vmovaps xmm12, [rsp+0xC0]
00007fdcd91cefb0  vmovaps xmm13, [rsp+0xD0]
00007fdcd91cefb9  vmovaps xmm15, [rsp+0xE0]
00007fdcd91cefc2  add rsp, 0xF0
00007fdcd91cefc9  pop r11
00007fdcd91cefcb  pop r10
00007fdcd91cefcd  pop r9
00007fdcd91cefcf  pop r8
00007fdcd91cefd1  pop rsi
00007fdcd91cefd2  pop rdi
00007fdcd91cefd3  pop rdx
00007fdcd91cefd4  pop rcx
00007fdcd91cefd5  pop rax
00007fdcd91cefd6  add rsp, 0x08
00007fdcd91cefda  jmp 0x00007FDCD91CECAE
00007fdcd91cefdf  call 0x00007FDCD90C34C0
00007fdcd91cefe4  jmp 0x00007FDCD91CECC4
00007fdcd91cefe9  int3
00007fdcd91cefea  nop [rax+rax*1], ax
00007fdcd91ceff0  mov rax, [r15+0xF8]
00007fdcd91ceff7  lea r14, [rax-0x150]
00007fdcd91ceffe  mov [r15+0xF8], r14
00007fdcd91cf005  mov rax, [r15+0x50]
00007fdcd91cf009  lea r12, [rax+0x80]
00007fdcd91cf010  movups xmm1, [r13+r12*1]
00007fdcd91cf016  lea r12, [rax+0x90]
00007fdcd91cf01d  movups xmm15, [r13+r12*1]
00007fdcd91cf023  mov qword ptr [r15+0x48], 0x00
00007fdcd91cf02b  lea r12, [rax+0x40]
00007fdcd91cf02f  movups xmm14, [r13+r12*1]
00007fdcd91cf035  lea r12, [rax+0x50]
00007fdcd91cf039  movups xmm13, [r13+r12*1]
00007fdcd91cf03f  lea r12, [r14+0x120]
00007fdcd91cf046  movq xmm12, qword ptr [r15+0x1C0]
00007fdcd91cf04f  movq xmm11, qword ptr [r15+0x1B0]
00007fdcd91cf058  movq r11, xmm12
00007fdcd91cf05d  movq r10, xmm11
00007fdcd91cf062  mov [r13+r12*1], r11
00007fdcd91cf067  lea r12, [r14+0x128]
00007fdcd91cf06e  mov [r13+r12*1], r10
00007fdcd91cf073  vxorps xmm12, xmm12, xmm12
00007fdcd91cf078  vpbroadcastq xmm12, xmm12
00007fdcd91cf07d  lea r12, [r14+0x100]
00007fdcd91cf084  movq xmm11, qword ptr [r15+0x200]
00007fdcd91cf08d  movq xmm10, qword ptr [r15+0x1F0]
00007fdcd91cf096  movq r11, xmm11
00007fdcd91cf09b  movq r10, xmm10
00007fdcd91cf0a0  mov [r13+r12*1], r11
00007fdcd91cf0a5  lea r12, [r14+0x108]
00007fdcd91cf0ac  mov [r13+r12*1], r10
00007fdcd91cf0b1  lea r12, [r14+0xE0]
00007fdcd91cf0b8  movups [r13+r12*1], xmm15
00007fdcd91cf0be  lea r12, [r14+0xF0]
00007fdcd91cf0c5  movups [r13+r12*1], xmm1
00007fdcd91cf0cb  lea r12, [rax+0xC0]
00007fdcd91cf0d2  movups xmm1, [r13+r12*1]
00007fdcd91cf0d8  lea r12, [rax+0xD0]
00007fdcd91cf0df  movups xmm15, [r13+r12*1]
00007fdcd91cf0e5  lea r12, [r14+0x110]
00007fdcd91cf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007fdcd91cf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007fdcd91cf0fe  movq r11, xmm11
00007fdcd91cf103  movq r10, xmm10
00007fdcd91cf108  mov [r13+r12*1], r11
00007fdcd91cf10d  lea r12, [r14+0x118]
00007fdcd91cf114  mov [r13+r12*1], r10
00007fdcd91cf119  movups xmm11, [r13+rax*1]
00007fdcd91cf11f  lea r12, [rax+0x10]
00007fdcd91cf123  movups xmm10, [r13+r12*1]
00007fdcd91cf129  lea r12, [r14+0x130]
00007fdcd91cf130  movq xmm9, qword ptr [r15+0x1A0]
00007fdcd91cf139  movq xmm8, qword ptr [r15+0x190]
00007fdcd91cf142  movq r11, xmm9
00007fdcd91cf147  movq r10, xmm8
00007fdcd91cf14c  mov [r13+r12*1], r11
00007fdcd91cf151  lea r12, [r14+0x138]
00007fdcd91cf158  mov [r13+r12*1], r10
00007fdcd91cf15d  lea r12, [rax+0x140]
00007fdcd91cf164  movups xmm9, [r13+r12*1]
00007fdcd91cf16a  lea r12, [rax+0x150]
00007fdcd91cf171  movups xmm8, [r13+r12*1]
00007fdcd91cf177  lea r12, [r14+0xC0]
00007fdcd91cf17e  movups [r13+r12*1], xmm15
00007fdcd91cf184  lea r12, [r14+0xD0]
00007fdcd91cf18b  movups [r13+r12*1], xmm1
00007fdcd91cf191  lea r12, [rax+0x100]
00007fdcd91cf198  movups xmm1, [r13+r12*1]
00007fdcd91cf19e  lea r12, [rax+0x110]
00007fdcd91cf1a5  movups xmm15, [r13+r12*1]
00007fdcd91cf1ab  lea r12, [r14+0x140]
00007fdcd91cf1b2  mov r11, [r15+0xE8]
00007fdcd91cf1b9  mov [r13+r12*1], r11
00007fdcd91cf1be  lea r12, [rax+0x180]
00007fdcd91cf1c5  movups xmm7, [r13+r12*1]
00007fdcd91cf1cb  lea r12, [rax+0x190]
00007fdcd91cf1d2  movups xmm6, [r13+r12*1]
00007fdcd91cf1d8  lea r12, [rax+0x1C0]
00007fdcd91cf1df  movups xmm5, [r13+r12*1]
00007fdcd91cf1e5  lea r12, [rax+0x1D0]
00007fdcd91cf1ec  movups xmm4, [r13+r12*1]
00007fdcd91cf1f2  lea r12, [r14+0x20]
00007fdcd91cf1f6  movups [r13+r12*1], xmm1
00007fdcd91cf1fc  lea r12, [r14+0x30]
00007fdcd91cf200  movups [r13+r12*1], xmm13
00007fdcd91cf206  lea r12, [rax+0x60]
00007fdcd91cf20a  movups xmm1, [r13+r12*1]
00007fdcd91cf210  lea r12, [rax+0x70]
00007fdcd91cf214  movups xmm13, [r13+r12*1]
00007fdcd91cf21a  lea r12, [rax+0x20]
00007fdcd91cf21e  movups xmm3, [r13+r12*1]
00007fdcd91cf224  lea r12, [rax+0x30]
00007fdcd91cf228  movups xmm2, [r13+r12*1]
00007fdcd91cf22e  movaps [r15+0x1F0], xmm2
00007fdcd91cf236  lea r12, [r14+0x60]
00007fdcd91cf23a  movups [r13+r12*1], xmm11
00007fdcd91cf240  lea r12, [r14+0x70]
00007fdcd91cf244  movups [r13+r12*1], xmm5
00007fdcd91cf24a  lea r12, [rax+0xE0]
00007fdcd91cf251  movups xmm11, [r13+r12*1]
00007fdcd91cf257  lea r12, [rax+0xF0]
00007fdcd91cf25e  movups xmm5, [r13+r12*1]
00007fdcd91cf264  lea r12, [r14+0xA0]
00007fdcd91cf26b  movups [r13+r12*1], xmm13
00007fdcd91cf271  lea r12, [r14+0xB0]
00007fdcd91cf278  movups [r13+r12*1], xmm1
00007fdcd91cf27e  lea r12, [rax+0xA0]
00007fdcd91cf285  movups xmm1, [r13+r12*1]
00007fdcd91cf28b  lea r12, [rax+0xB0]
00007fdcd91cf292  movups xmm13, [r13+r12*1]
00007fdcd91cf298  lea r12, [rax+0x120]
00007fdcd91cf29f  vmovaps [rsp+0x10], xmm1
00007fdcd91cf2a5  movups xmm1, [r13+r12*1]
00007fdcd91cf2ab  lea r12, [rax+0x130]
00007fdcd91cf2b2  vmovaps [rsp+0x20], xmm1
00007fdcd91cf2b8  movups xmm1, [r13+r12*1]
00007fdcd91cf2be  lea r12, [rax+0x160]
00007fdcd91cf2c5  vmovaps [rsp+0x30], xmm1
00007fdcd91cf2cb  movups xmm1, [r13+r12*1]
00007fdcd91cf2d1  lea r12, [rax+0x170]
00007fdcd91cf2d8  vmovaps [rsp+0x40], xmm1
00007fdcd91cf2de  movups xmm1, [r13+r12*1]
00007fdcd91cf2e4  movaps [r15+0x2B0], xmm1
00007fdcd91cf2ec  lea r12, [r14+0x80]
00007fdcd91cf2f3  movups [r13+r12*1], xmm13
00007fdcd91cf2f9  lea r12, [r14+0x90]
00007fdcd91cf300  vmovaps xmm13, [rsp+0x10]
00007fdcd91cf306  movups [r13+r12*1], xmm13
00007fdcd91cf30c  lea r12, [rax+0x1A0]
00007fdcd91cf313  movups xmm13, [r13+r12*1]
00007fdcd91cf319  lea r12, [rax+0x1B0]
00007fdcd91cf320  vmovaps [rsp+0x10], xmm1
00007fdcd91cf326  movups xmm1, [r13+r12*1]
00007fdcd91cf32c  movaps [r15+0x290], xmm13
00007fdcd91cf334  movaps [r15+0x1E0], xmm1
00007fdcd91cf33c  lea r12, [rax+0x1E0]
00007fdcd91cf343  vmovaps [rsp+0x50], xmm1
00007fdcd91cf349  movups xmm1, [r13+r12*1]
00007fdcd91cf34f  lea r12, [rax+0x1F0]
00007fdcd91cf356  vmovaps [rsp+0x60], xmm1
00007fdcd91cf35c  movups xmm1, [r13+r12*1]
00007fdcd91cf362  mov qword ptr [r15+0x50], 0x430920
00007fdcd91cf36a  lea rax, [r14+0x40]
00007fdcd91cf36e  vmovaps [rsp+0x70], xmm1
00007fdcd91cf374  vmovaps xmm1, [rsp+0x40]
00007fdcd91cf37a  movups [r13+rax*1], xmm1
00007fdcd91cf380  lea rax, [r14+0x50]
00007fdcd91cf384  movups [r13+rax*1], xmm10
00007fdcd91cf38a  vmovaps xmm1, [rsp+0x70]
00007fdcd91cf390  movups [r13+r14*1], xmm1
00007fdcd91cf396  lea rax, [r14+0x10]
00007fdcd91cf39a  vmovaps xmm1, [rsp+0x60]
00007fdcd91cf3a0  movups [r13+rax*1], xmm1
00007fdcd91cf3a6  mov rax, [r15+0x40]
00007fdcd91cf3aa  vmovaps [rsp+0x40], xmm3
00007fdcd91cf3b0  vmovaps xmm1, [rsp+0x40]
00007fdcd91cf3b6  por xmm3, xmm1
00007fdcd91cf3ba  vmovaps [rsp+0x40], xmm6
00007fdcd91cf3c0  vmovaps xmm10, [rsp+0x40]
00007fdcd91cf3c6  por xmm6, xmm10
00007fdcd91cf3cb  lea r12, [rax+0x30]
00007fdcd91cf3cf  mov r11, [r13+r12*1]
00007fdcd91cf3d4  lea r12, [rax+0x38]
00007fdcd91cf3d8  mov r10, [r13+r12*1]
00007fdcd91cf3dd  movq xmm10, r11
00007fdcd91cf3e2  vmovaps [rsp+0x40], xmm1
00007fdcd91cf3e8  movq xmm1, r10
00007fdcd91cf3ed  movq xmm10, xmm10
00007fdcd91cf3f2  vmovaps [rsp+0x60], xmm10
00007fdcd91cf3f8  movq xmm10, xmm10
00007fdcd91cf3fd  movaps [r15+0x130], xmm10
00007fdcd91cf405  movq xmm1, xmm1
00007fdcd91cf409  vmovaps [rsp+0x70], xmm1
00007fdcd91cf40f  movq xmm1, xmm1
00007fdcd91cf413  movaps [r15+0x280], xmm1
00007fdcd91cf41b  vmovaps [rsp+0x80], xmm9
00007fdcd91cf424  vmovaps xmm1, [rsp+0x80]
00007fdcd91cf42d  por xmm9, xmm1
00007fdcd91cf432  lea r12, [rax+0x20]
00007fdcd91cf436  mov r11, [r13+r12*1]
00007fdcd91cf43b  lea r12, [rax+0x28]
00007fdcd91cf43f  mov r10, [r13+r12*1]
00007fdcd91cf444  movq xmm1, r11
00007fdcd91cf449  movq xmm10, r10
00007fdcd91cf44e  movq xmm1, xmm1
00007fdcd91cf452  vmovaps [rsp+0x80], xmm1
00007fdcd91cf45b  movq xmm1, xmm1
00007fdcd91cf45f  movaps [r15+0x150], xmm1
00007fdcd91cf467  movq xmm10, xmm10
00007fdcd91cf46c  vmovaps [rsp+0x90], xmm10
00007fdcd91cf475  movq xmm10, xmm10
00007fdcd91cf47a  movaps [r15+0x140], xmm10
00007fdcd91cf482  lea r12, [rax+0x10]
00007fdcd91cf486  mov r11, [r13+r12*1]
00007fdcd91cf48b  lea r12, [rax+0x18]
00007fdcd91cf48f  mov r10, [r13+r12*1]
00007fdcd91cf494  movq xmm1, r11
00007fdcd91cf499  movq xmm10, r10
00007fdcd91cf49e  movq xmm1, xmm1
00007fdcd91cf4a2  vmovaps [rsp+0xA0], xmm1
00007fdcd91cf4ab  movq xmm1, xmm1
00007fdcd91cf4af  movaps [r15+0x170], xmm1
00007fdcd91cf4b7  movq xmm10, xmm10
00007fdcd91cf4bc  vmovaps [rsp+0xB0], xmm10
00007fdcd91cf4c5  movq xmm10, xmm10
00007fdcd91cf4ca  movaps [r15+0x160], xmm10
00007fdcd91cf4d2  mov r12, [r13+rax*1]
00007fdcd91cf4d7  vmovq xmm1, r12
00007fdcd91cf4dc  vpbroadcastq xmm1, xmm1
00007fdcd91cf4e1  lea r12, [rax+0x08]
00007fdcd91cf4e5  mov rax, [r13+r12*1]
00007fdcd91cf4ea  movq xmm10, rax
00007fdcd91cf4ef  movaps [r15+0x230], xmm10
00007fdcd91cf4f7  lea rax, [r14+0x50]
00007fdcd91cf4fb  movups xmm10, [r13+rax*1]
00007fdcd91cf501  lea rax, [r14+0x60]
00007fdcd91cf505  vmovaps [rsp+0xC0], xmm1
00007fdcd91cf50e  movups xmm1, [r13+rax*1]
00007fdcd91cf514  lea rax, [r14+0x30]
00007fdcd91cf518  vmovaps [rsp+0xD0], xmm1
00007fdcd91cf521  movups xmm1, [r13+rax*1]
00007fdcd91cf527  mov qword ptr [r15+0x60], 0x430920
00007fdcd91cf52f  mov qword ptr [r15+0x58], 0x40
00007fdcd91cf537  vmovaps [rsp+0xE0], xmm1
00007fdcd91cf540  vmovaps [rsp+0xF0], xmm15
00007fdcd91cf549  vmovaps xmm15, [rsp+0xC0]
00007fdcd91cf552  vmovaps [rsp+0xC0], xmm14
00007fdcd91cf55b  vmovaps xmm14, [rsp+0x40]
00007fdcd91cf561  vmovaps [rsp+0x40], xmm13
00007fdcd91cf567  movaps xmm1, xmm15
00007fdcd91cf56b  mulpd xmm1, xmm14
00007fdcd91cf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007fdcd91cf575  ptest xmm13, xmm13
00007fdcd91cf57b  jnz 0x00007FDCD91D0682
00007fdcd91cf581  movq xmm14, qword ptr [r15+0x230]
00007fdcd91cf58a  vmovaps [rsp+0x100], xmm14
00007fdcd91cf593  vpermilpd xmm14, xmm14, 0x00
00007fdcd91cf599  vmovaps [rsp+0x110], xmm1
00007fdcd91cf5a2  vmovaps xmm1, [rsp+0xE0]
00007fdcd91cf5ab  vmovaps [rsp+0xE0], xmm15
00007fdcd91cf5b4  movaps xmm13, xmm1
00007fdcd91cf5b8  mulpd xmm13, xmm14
00007fdcd91cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007fdcd91cf5c3  ptest xmm15, xmm15
00007fdcd91cf5c9  jnz 0x00007FDCD91D07C4
00007fdcd91cf5cf  vxorps xmm1, xmm1, xmm1
00007fdcd91cf5d3  vpbroadcastq xmm1, xmm1
00007fdcd91cf5d8  vmovaps xmm14, [rsp+0xE0]
00007fdcd91cf5e1  vmovaps [rsp+0xE0], xmm1
00007fdcd91cf5ea  vmovaps xmm1, [rsp+0xD0]
00007fdcd91cf5f3  vmovaps [rsp+0xD0], xmm13
00007fdcd91cf5fc  movaps xmm15, xmm14
00007fdcd91cf600  mulpd xmm15, xmm1
00007fdcd91cf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007fdcd91cf60b  ptest xmm13, xmm13
00007fdcd91cf611  jnz 0x00007FDCD91D0907
00007fdcd91cf617  movaps xmm1, xmm14
00007fdcd91cf61b  mulpd xmm1, xmm10
00007fdcd91cf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007fdcd91cf625  ptest xmm13, xmm13
00007fdcd91cf62b  jnz 0x00007FDCD91D0A4A
00007fdcd91cf631  movaps xmm13, xmm14
00007fdcd91cf635  mulpd xmm13, xmm2
00007fdcd91cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007fdcd91cf640  ptest xmm10, xmm10
00007fdcd91cf646  jnz 0x00007FDCD91D0B8C
00007fdcd91cf64c  vmovaps [rsp+0x120], xmm7
00007fdcd91cf655  vmovaps xmm14, [rsp+0x120]
00007fdcd91cf65e  por xmm7, xmm14
00007fdcd91cf663  vmovaps xmm14, [rsp+0xC0]
00007fdcd91cf66c  vmovaps xmm10, [rsp+0xC0]
00007fdcd91cf675  por xmm14, xmm10
00007fdcd91cf67a  vmovaps xmm2, [rsp+0x100]
00007fdcd91cf683  vpermilpd xmm2, xmm2, 0x00
00007fdcd91cf689  vmovaps [rsp+0xC0], xmm1
00007fdcd91cf692  vmovaps [rsp+0x120], xmm15
00007fdcd91cf69b  movaps xmm1, xmm10
00007fdcd91cf69f  mulpd xmm1, xmm2
00007fdcd91cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007fdcd91cf6a8  ptest xmm15, xmm15
00007fdcd91cf6ae  jnz 0x00007FDCD91D0CCF
00007fdcd91cf6b4  xor eax, eax
00007fdcd91cf6b6  mov r12d, 0x40
00007fdcd91cf6bc  mov r11d, 0x200
00007fdcd91cf6c2  cmp r12, r11
00007fdcd91cf6c5  cmc
00007fdcd91cf6c6  lahf
00007fdcd91cf6c7  seto al
00007fdcd91cf6ca  mov [r15+0x108], eax
00007fdcd91cf6d1  vmovaps xmm10, [rsp+0x110]
00007fdcd91cf6da  vmovaps xmm2, [rsp+0xE0]
00007fdcd91cf6e3  vmovaps [rsp+0xE0], xmm1
00007fdcd91cf6ec  movaps xmm15, xmm10
00007fdcd91cf6f0  addpd xmm15, xmm2
00007fdcd91cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007fdcd91cf6fb  ptest xmm1, xmm1
00007fdcd91cf700  jnz 0x00007FDCD91D0E10
00007fdcd91cf706  vmovaps xmm10, [rsp+0x120]
00007fdcd91cf70f  vmovaps [rsp+0x110], xmm15
00007fdcd91cf718  movaps xmm1, xmm10
00007fdcd91cf71c  addpd xmm1, xmm12
00007fdcd91cf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007fdcd91cf726  ptest xmm15, xmm15
00007fdcd91cf72c  jnz 0x00007FDCD91D0F53
00007fdcd91cf732  vmovaps xmm10, [rsp+0xC0]
00007fdcd91cf73b  vmovaps [rsp+0xC0], xmm1
00007fdcd91cf744  movaps xmm15, xmm10
00007fdcd91cf748  addpd xmm15, xmm12
00007fdcd91cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007fdcd91cf753  ptest xmm1, xmm1
00007fdcd91cf758  jnz 0x00007FDCD91D1095
00007fdcd91cf75e  vmovaps xmm1, [rsp+0x30]
00007fdcd91cf764  vmovaps xmm12, [rsp+0x30]
00007fdcd91cf76a  por xmm1, xmm12
00007fdcd91cf76f  vmovaps xmm12, [rsp+0x20]
00007fdcd91cf775  vmovaps xmm10, [rsp+0x20]
00007fdcd91cf77b  por xmm12, xmm10
00007fdcd91cf780  vmovaps [rsp+0x20], xmm5
00007fdcd91cf786  vmovaps xmm10, [rsp+0x20]
00007fdcd91cf78c  por xmm5, xmm10
00007fdcd91cf791  vmovaps [rsp+0x20], xmm11
00007fdcd91cf797  vmovaps xmm10, [rsp+0x20]
00007fdcd91cf79d  por xmm11, xmm10
00007fdcd91cf7a2  vmovaps [rsp+0x20], xmm4
00007fdcd91cf7a8  vmovaps xmm10, [rsp+0x20]
00007fdcd91cf7ae  por xmm4, xmm10
00007fdcd91cf7b3  vmovaps [rsp+0x20], xmm8
00007fdcd91cf7b9  vmovaps xmm10, [rsp+0x20]
00007fdcd91cf7bf  por xmm8, xmm10
00007fdcd91cf7c4  vmovaps xmm10, [rsp+0xF0]
00007fdcd91cf7cd  vmovaps [rsp+0x20], xmm1
00007fdcd91cf7d3  vmovaps xmm1, [rsp+0xF0]
00007fdcd91cf7dc  por xmm10, xmm1
00007fdcd91cf7e1  lea rax, [r14+0xA0]
00007fdcd91cf7e8  movups xmm1, [r13+rax*1]
00007fdcd91cf7ee  lea rax, [r14+0xB0]
00007fdcd91cf7f5  vmovaps [rsp+0x30], xmm1
00007fdcd91cf7fb  movups xmm1, [r13+rax*1]
00007fdcd91cf801  vmovaps [rsp+0xF0], xmm1
00007fdcd91cf80a  vmovaps [rsp+0x120], xmm15
00007fdcd91cf813  movaps xmm1, xmm13
00007fdcd91cf817  addpd xmm1, xmm2
00007fdcd91cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007fdcd91cf820  ptest xmm15, xmm15
00007fdcd91cf826  jnz 0x00007FDCD91D11ED
00007fdcd91cf82c  lea rax, [r14+0xF0]
00007fdcd91cf833  movups xmm15, [r13+rax*1]
00007fdcd91cf839  vmovaps xmm2, [rsp+0xC0]
00007fdcd91cf842  vmovaps [rsp+0xC0], xmm1
00007fdcd91cf84b  vmovaps xmm1, [rsp+0xE0]
00007fdcd91cf854  vmovaps [rsp+0xE0], xmm15
00007fdcd91cf85d  movaps xmm13, xmm2
00007fdcd91cf861  addpd xmm13, xmm1
00007fdcd91cf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007fdcd91cf86c  ptest xmm15, xmm15
00007fdcd91cf872  jnz 0x00007FDCD91D1338
00007fdcd91cf878  vmovaps xmm15, [rsp+0x120]
00007fdcd91cf881  vmovaps xmm2, [rsp+0xD0]
00007fdcd91cf88a  vmovaps [rsp+0xD0], xmm14
00007fdcd91cf893  movaps xmm1, xmm15
00007fdcd91cf897  addpd xmm1, xmm2
00007fdcd91cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007fdcd91cf8a0  ptest xmm14, xmm14
00007fdcd91cf8a6  jnz 0x00007FDCD91D147A
00007fdcd91cf8ac  vmovaps xmm15, [rsp+0x100]
00007fdcd91cf8b5  vpermilpd xmm15, xmm15, 0x00
00007fdcd91cf8bb  vmovaps xmm2, [rsp+0xF0]
00007fdcd91cf8c4  vmovaps [rsp+0xF0], xmm1
00007fdcd91cf8cd  movaps xmm14, xmm2
00007fdcd91cf8d1  mulpd xmm14, xmm15
00007fdcd91cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007fdcd91cf8dc  ptest xmm1, xmm1
00007fdcd91cf8e1  jnz 0x00007FDCD91D15BB
00007fdcd91cf8e7  vmovaps xmm1, [rsp+0xA0]
00007fdcd91cf8f0  vpermilpd xmm1, xmm1, 0x00
00007fdcd91cf8f6  vmovaps xmm2, [rsp+0xE0]
00007fdcd91cf8ff  vmovaps [rsp+0xE0], xmm14
00007fdcd91cf908  movaps xmm15, xmm2
00007fdcd91cf90c  mulpd xmm15, xmm1
00007fdcd91cf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007fdcd91cf917  ptest xmm14, xmm14
00007fdcd91cf91d  jnz 0x00007FDCD91D16FE
00007fdcd91cf923  lea rax, [r14+0xE0]
00007fdcd91cf92a  movups xmm1, [r13+rax*1]
00007fdcd91cf930  vmovaps xmm14, [rsp+0x100]
00007fdcd91cf939  vpermilpd xmm14, xmm14, 0x00
00007fdcd91cf93f  vmovaps [rsp+0x100], xmm1
00007fdcd91cf948  vmovaps xmm1, [rsp+0x30]
00007fdcd91cf94e  vmovaps [rsp+0x30], xmm15
00007fdcd91cf954  movaps xmm2, xmm1
00007fdcd91cf957  mulpd xmm2, xmm14
00007fdcd91cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007fdcd91cf961  ptest xmm15, xmm15
00007fdcd91cf967  jnz 0x00007FDCD91D184A
00007fdcd91cf96d  vmovaps [rsp+0x120], xmm10
00007fdcd91cf976  vmovaps xmm1, [rsp+0x120]
00007fdcd91cf97f  por xmm10, xmm1
00007fdcd91cf984  movaps [r15+0x300], xmm10
00007fdcd91cf98c  vmovaps [rsp+0x120], xmm8
00007fdcd91cf995  vmovaps xmm1, [rsp+0x120]
00007fdcd91cf99e  por xmm8, xmm1
00007fdcd91cf9a3  movaps [r15+0x190], xmm8
00007fdcd91cf9ab  vmovaps xmm1, [rsp+0xA0]
00007fdcd91cf9b4  vpermilpd xmm1, xmm1, 0x00
00007fdcd91cf9ba  vmovaps xmm14, [rsp+0x100]
00007fdcd91cf9c3  vmovaps [rsp+0x100], xmm13
00007fdcd91cf9cc  movaps xmm15, xmm14
00007fdcd91cf9d0  mulpd xmm15, xmm1
00007fdcd91cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007fdcd91cf9db  ptest xmm13, xmm13
00007fdcd91cf9e1  jnz 0x00007FDCD91D198B
00007fdcd91cf9e7  lea rax, [r14+0x90]
00007fdcd91cf9ee  movups xmm1, [r13+rax*1]
00007fdcd91cf9f4  vmovaps [rsp+0x120], xmm4
00007fdcd91cf9fd  vmovaps xmm14, [rsp+0x120]
00007fdcd91cfa06  por xmm4, xmm14
00007fdcd91cfa0b  movaps [r15+0x1C0], xmm4
00007fdcd91cfa13  vmovaps [rsp+0x120], xmm11
00007fdcd91cfa1c  vmovaps xmm14, [rsp+0x120]
00007fdcd91cfa25  por xmm11, xmm14
00007fdcd91cfa2a  movaps [r15+0x200], xmm11
00007fdcd91cfa32  vmovaps [rsp+0x120], xmm5
00007fdcd91cfa3b  vmovaps xmm14, [rsp+0x120]
00007fdcd91cfa44  por xmm5, xmm14
00007fdcd91cfa49  movaps [r15+0x2D0], xmm5
00007fdcd91cfa51  vmovaps [rsp+0x120], xmm12
00007fdcd91cfa5a  vmovaps xmm14, [rsp+0x120]
00007fdcd91cfa63  por xmm12, xmm14
00007fdcd91cfa68  movaps [r15+0x2E0], xmm12
00007fdcd91cfa70  vmovaps xmm13, [rsp+0x110]
00007fdcd91cfa79  vmovaps [rsp+0x110], xmm1
00007fdcd91cfa82  vmovaps xmm1, [rsp+0xE0]
00007fdcd91cfa8b  vmovaps [rsp+0xE0], xmm15
00007fdcd91cfa94  movaps xmm14, xmm13
00007fdcd91cfa98  addpd xmm14, xmm1
00007fdcd91cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007fdcd91cfaa3  ptest xmm15, xmm15
00007fdcd91cfaa9  jnz 0x00007FDCD91D1AD8
00007fdcd91cfaaf  vmovaps xmm1, [rsp+0xA0]
00007fdcd91cfab8  vpermilpd xmm1, xmm1, 0x00
00007fdcd91cfabe  vmovaps xmm13, [rsp+0x110]
00007fdcd91cfac7  vmovaps [rsp+0x110], xmm14
00007fdcd91cfad0  movaps xmm15, xmm13
00007fdcd91cfad4  mulpd xmm15, xmm1
00007fdcd91cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007fdcd91cfadf  ptest xmm14, xmm14
00007fdcd91cfae5  jnz 0x00007FDCD91D1C1B
00007fdcd91cfaeb  lea rax, [r14+0x80]
00007fdcd91cfaf2  movups xmm1, [r13+rax*1]
00007fdcd91cfaf8  vmovaps xmm13, [rsp+0xC0]
00007fdcd91cfb01  vmovaps [rsp+0xC0], xmm1
00007fdcd91cfb0a  movaps xmm14, xmm13
00007fdcd91cfb0e  addpd xmm14, xmm2
00007fdcd91cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007fdcd91cfb19  ptest xmm1, xmm1
00007fdcd91cfb1e  jnz 0x00007FDCD91D1D68
00007fdcd91cfb24  vmovaps xmm13, [rsp+0x100]
00007fdcd91cfb2d  vmovaps xmm2, [rsp+0x30]
00007fdcd91cfb33  vmovaps [rsp+0x30], xmm15
00007fdcd91cfb39  movaps xmm1, xmm13
00007fdcd91cfb3d  addpd xmm1, xmm2
00007fdcd91cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007fdcd91cfb46  ptest xmm15, xmm15
00007fdcd91cfb4c  jnz 0x00007FDCD91D1EAB
00007fdcd91cfb52  vmovaps xmm15, [rsp+0x20]
00007fdcd91cfb58  vmovaps xmm13, [rsp+0x20]
00007fdcd91cfb5e  por xmm15, xmm13
00007fdcd91cfb63  movaps [r15+0x2F0], xmm15
00007fdcd91cfb6b  vmovaps xmm13, [rsp+0xA0]
00007fdcd91cfb74  vpermilpd xmm13, xmm13, 0x00
00007fdcd91cfb7a  vmovaps [rsp+0x20], xmm1
00007fdcd91cfb80  vmovaps xmm1, [rsp+0xC0]
00007fdcd91cfb89  vmovaps [rsp+0xA0], xmm15
00007fdcd91cfb92  movaps xmm2, xmm1
00007fdcd91cfb95  mulpd xmm2, xmm13
00007fdcd91cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007fdcd91cfb9f  ptest xmm15, xmm15
00007fdcd91cfba5  jnz 0x00007FDCD91D1FEC
00007fdcd91cfbab  lea rax, [r14+0xD0]
00007fdcd91cfbb2  movups xmm1, [r13+rax*1]
00007fdcd91cfbb8  vmovaps xmm13, [rsp+0xF0]
00007fdcd91cfbc1  vmovaps [rsp+0xC0], xmm1
00007fdcd91cfbca  vmovaps xmm1, [rsp+0xE0]
00007fdcd91cfbd3  vmovaps [rsp+0xE0], xmm14
00007fdcd91cfbdc  movaps xmm15, xmm13
00007fdcd91cfbe0  addpd xmm15, xmm1
00007fdcd91cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007fdcd91cfbeb  ptest xmm14, xmm14
00007fdcd91cfbf1  jnz 0x00007FDCD91D2137
00007fdcd91cfbf7  vmovaps xmm1, [rsp+0xB0]
00007fdcd91cfc00  vpermilpd xmm1, xmm1, 0x00
00007fdcd91cfc06  movaps xmm14, xmm11
00007fdcd91cfc0a  mulpd xmm14, xmm1
00007fdcd91cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007fdcd91cfc15  ptest xmm13, xmm13
00007fdcd91cfc1b  jnz 0x00007FDCD91D227A
00007fdcd91cfc21  movaps [r15+0x260], xmm14
00007fdcd91cfc29  vxorps xmm1, xmm1, xmm1
00007fdcd91cfc2d  vpbroadcastq xmm1, xmm1
00007fdcd91cfc32  movaps [r15+0x1B0], xmm1
00007fdcd91cfc3a  vmovaps xmm1, [rsp+0xB0]
00007fdcd91cfc43  vpermilpd xmm1, xmm1, 0x00
00007fdcd91cfc49  vmovaps xmm11, [rsp+0xC0]
00007fdcd91cfc52  vmovaps [rsp+0xC0], xmm15
00007fdcd91cfc5b  movaps xmm13, xmm11
00007fdcd91cfc5f  mulpd xmm13, xmm1
00007fdcd91cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007fdcd91cfc6a  ptest xmm15, xmm15
00007fdcd91cfc70  jnz 0x00007FDCD91D23BD
00007fdcd91cfc76  lea rax, [r14+0xC0]
00007fdcd91cfc7d  movups xmm1, [r13+rax*1]
00007fdcd91cfc83  vmovaps xmm11, [rsp+0x110]
00007fdcd91cfc8c  vmovaps [rsp+0xF0], xmm1
00007fdcd91cfc95  vmovaps xmm1, [rsp+0x30]
00007fdcd91cfc9b  vmovaps [rsp+0x30], xmm14
00007fdcd91cfca1  movaps xmm15, xmm11
00007fdcd91cfca5  addpd xmm15, xmm1
00007fdcd91cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007fdcd91cfcb0  ptest xmm14, xmm14
00007fdcd91cfcb6  jnz 0x00007FDCD91D250A
00007fdcd91cfcbc  vmovaps [rsp+0x100], xmm9
00007fdcd91cfcc5  vmovaps xmm1, [rsp+0x100]
00007fdcd91cfcce  por xmm9, xmm1
00007fdcd91cfcd3  movaps [r15+0x270], xmm9
00007fdcd91cfcdb  vmovaps [rsp+0x100], xmm6
00007fdcd91cfce4  vmovaps xmm1, [rsp+0x100]
00007fdcd91cfced  por xmm6, xmm1
00007fdcd91cfcf1  movaps [r15+0x1A0], xmm6
00007fdcd91cfcf9  vmovaps xmm14, [rsp+0xB0]
00007fdcd91cfd02  vpermilpd xmm14, xmm14, 0x00
00007fdcd91cfd08  vmovaps xmm6, [rsp+0xF0]
00007fdcd91cfd11  vmovaps [rsp+0xF0], xmm1
00007fdcd91cfd1a  movaps xmm11, xmm6
00007fdcd91cfd1e  mulpd xmm11, xmm14
00007fdcd91cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007fdcd91cfd29  ptest xmm1, xmm1
00007fdcd91cfd2e  jnz 0x00007FDCD91D264D
00007fdcd91cfd34  lea rax, [r14+0x20]
00007fdcd91cfd38  movups xmm1, [r13+rax*1]
00007fdcd91cfd3e  movaps [r15+0x110], xmm1
00007fdcd91cfd46  vmovaps xmm6, [rsp+0xE0]
00007fdcd91cfd4f  vmovaps [rsp+0xE0], xmm1
00007fdcd91cfd58  movaps xmm14, xmm6
00007fdcd91cfd5c  addpd xmm14, xmm2
00007fdcd91cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007fdcd91cfd67  ptest xmm1, xmm1
00007fdcd91cfd6c  jnz 0x00007FDCD91D279A
00007fdcd91cfd72  vmovaps xmm1, [rsp+0xB0]
00007fdcd91cfd7b  vpermilpd xmm1, xmm1, 0x00
00007fdcd91cfd81  movaps xmm6, xmm5
00007fdcd91cfd84  mulpd xmm6, xmm1
00007fdcd91cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007fdcd91cfd8d  ptest xmm2, xmm2
00007fdcd91cfd92  jnz 0x00007FDCD91D28DC
00007fdcd91cfd98  vmovaps xmm5, [rsp+0x20]
00007fdcd91cfd9e  movaps xmm1, xmm5
00007fdcd91cfda1  addpd xmm1, xmm13
00007fdcd91cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007fdcd91cfdab  ptest xmm2, xmm2
00007fdcd91cfdb0  jnz 0x00007FDCD91D2A1C
00007fdcd91cfdb6  vmovaps xmm13, [rsp+0x80]
00007fdcd91cfdbf  vpermilpd xmm13, xmm13, 0x00
00007fdcd91cfdc5  vmovaps xmm2, [rsp+0xE0]
00007fdcd91cfdce  vmovaps [rsp+0x20], xmm1
00007fdcd91cfdd4  movaps xmm5, xmm2
00007fdcd91cfdd7  mulpd xmm5, xmm13
00007fdcd91cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007fdcd91cfde1  ptest xmm1, xmm1
00007fdcd91cfde6  jnz 0x00007FDCD91D2B5D
00007fdcd91cfdec  vmovaps xmm1, [rsp+0x80]
00007fdcd91cfdf5  vpermilpd xmm1, xmm1, 0x00
00007fdcd91cfdfb  movaps xmm13, xmm10
00007fdcd91cfdff  mulpd xmm13, xmm1
00007fdcd91cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007fdcd91cfe0a  ptest xmm2, xmm2
00007fdcd91cfe0f  jnz 0x00007FDCD91D2C9E
00007fdcd91cfe15  vmovaps xmm10, [rsp+0x30]
00007fdcd91cfe1b  movaps xmm1, xmm15
00007fdcd91cfe1f  addpd xmm1, xmm10
00007fdcd91cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007fdcd91cfe29  ptest xmm2, xmm2
00007fdcd91cfe2e  jnz 0x00007FDCD91D2DE1
00007fdcd91cfe34  vmovaps xmm10, [rsp+0xC0]
00007fdcd91cfe3d  movaps xmm15, xmm10
00007fdcd91cfe41  addpd xmm15, xmm11
00007fdcd91cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007fdcd91cfe4c  ptest xmm2, xmm2
00007fdcd91cfe51  jnz 0x00007FDCD91D2F23
00007fdcd91cfe57  vmovaps xmm11, [rsp+0x80]
00007fdcd91cfe60  vpermilpd xmm11, xmm11, 0x00
00007fdcd91cfe66  movaps xmm10, xmm12
00007fdcd91cfe6a  mulpd xmm10, xmm11
00007fdcd91cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007fdcd91cfe75  ptest xmm2, xmm2
00007fdcd91cfe7a  jnz 0x00007FDCD91D3067
00007fdcd91cfe80  vmovaps xmm12, [rsp+0x80]
00007fdcd91cfe89  vpermilpd xmm12, xmm12, 0x00
00007fdcd91cfe8f  vmovaps xmm2, [rsp+0xA0]
00007fdcd91cfe98  vmovaps [rsp+0x30], xmm1
00007fdcd91cfe9e  movaps xmm11, xmm2
00007fdcd91cfea2  mulpd xmm11, xmm12
00007fdcd91cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007fdcd91cfead  ptest xmm1, xmm1
00007fdcd91cfeb2  jnz 0x00007FDCD91D31AB
00007fdcd91cfeb8  movaps xmm1, xmm14
00007fdcd91cfebc  addpd xmm1, xmm6
00007fdcd91cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007fdcd91cfec5  ptest xmm12, xmm12
00007fdcd91cfecb  jnz 0x00007FDCD91D32EE
00007fdcd91cfed1  vmovaps xmm12, [rsp+0x20]
00007fdcd91cfed7  movaps xmm14, xmm12
00007fdcd91cfedb  addpd xmm14, xmm5
00007fdcd91cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007fdcd91cfee6  ptest xmm6, xmm6
00007fdcd91cfeeb  jnz 0x00007FDCD91D342F
00007fdcd91cfef1  vmovaps xmm12, [rsp+0x90]
00007fdcd91cfefa  vpermilpd xmm12, xmm12, 0x00
00007fdcd91cff00  movaps xmm6, xmm9
00007fdcd91cff04  mulpd xmm6, xmm12
00007fdcd91cff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007fdcd91cff0e  ptest xmm5, xmm5
00007fdcd91cff13  jnz 0x00007FDCD91D3572
00007fdcd91cff19  movaps xmm12, xmm15
00007fdcd91cff1d  addpd xmm12, xmm13
00007fdcd91cff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007fdcd91cff28  ptest xmm9, xmm9
00007fdcd91cff2e  jnz 0x00007FDCD91D36B4
00007fdcd91cff34  vmovaps xmm13, [rsp+0x30]
00007fdcd91cff3a  movaps xmm15, xmm13
00007fdcd91cff3e  addpd xmm15, xmm10
00007fdcd91cff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007fdcd91cff49  ptest xmm9, xmm9
00007fdcd91cff4f  jnz 0x00007FDCD91D37F8
00007fdcd91cff55  vmovaps xmm13, [rsp+0xD0]
00007fdcd91cff5e  vmovaps xmm10, [rsp+0xD0]
00007fdcd91cff67  por xmm13, xmm10
00007fdcd91cff6c  movaps [r15+0x250], xmm13
00007fdcd91cff74  vmovaps [rsp+0x20], xmm7
00007fdcd91cff7a  vmovaps xmm13, [rsp+0x20]
00007fdcd91cff80  por xmm7, xmm13
00007fdcd91cff85  movaps [r15+0x2A0], xmm7
00007fdcd91cff8d  vmovaps [rsp+0x20], xmm3
00007fdcd91cff93  vmovaps xmm13, [rsp+0x20]
00007fdcd91cff99  por xmm3, xmm13
00007fdcd91cff9e  movaps [r15+0x1D0], xmm3
00007fdcd91cffa6  lea rax, [r14+0x40]
00007fdcd91cffaa  movups xmm13, [r13+rax*1]
00007fdcd91cffb0  movaps [r15+0x2C0], xmm13
00007fdcd91cffb8  vmovaps xmm10, [rsp+0x90]
00007fdcd91cffc1  vpermilpd xmm10, xmm10, 0x00
00007fdcd91cffc7  movaps xmm9, xmm8
00007fdcd91cffcb  mulpd xmm9, xmm10
00007fdcd91cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007fdcd91cffd6  ptest xmm5, xmm5
00007fdcd91cffdb  jnz 0x00007FDCD91D3946
00007fdcd91cffe1  movaps xmm10, xmm1
00007fdcd91cffe5  addpd xmm10, xmm11
00007fdcd91cffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007fdcd91cfff0  ptest xmm8, xmm8
00007fdcd91cfff6  jnz 0x00007FDCD91D3A8A
00007fdcd91cfffc  movaps xmm1, xmm14
00007fdcd91d0000  addpd xmm1, xmm6
00007fdcd91d0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007fdcd91d0009  ptest xmm11, xmm11
00007fdcd91d000f  jnz 0x00007FDCD91D3BCD
00007fdcd91d0015  vmovaps xmm14, [rsp+0x90]
00007fdcd91d001e  vpermilpd xmm14, xmm14, 0x00
00007fdcd91d0024  movaps xmm11, xmm13
00007fdcd91d0028  mulpd xmm11, xmm14
00007fdcd91d002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007fdcd91d0033  ptest xmm8, xmm8
00007fdcd91d0039  jnz 0x00007FDCD91D3D0E
00007fdcd91d003f  vmovaps xmm14, [rsp+0x90]
00007fdcd91d0048  vpermilpd xmm14, xmm14, 0x00
00007fdcd91d004e  vmovaps xmm8, [rsp+0x10]
00007fdcd91d0054  movaps xmm13, xmm8
00007fdcd91d0058  mulpd xmm13, xmm14
00007fdcd91d005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007fdcd91d0063  ptest xmm6, xmm6
00007fdcd91d0068  jnz 0x00007FDCD91D3E52
00007fdcd91d006e  vmovaps xmm14, [rsp+0x60]
00007fdcd91d0074  vpermilpd xmm14, xmm14, 0x00
00007fdcd91d007a  movaps xmm8, xmm7
00007fdcd91d007e  mulpd xmm8, xmm14
00007fdcd91d0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007fdcd91d0089  ptest xmm6, xmm6
00007fdcd91d008e  jnz 0x00007FDCD91D3F96
00007fdcd91d0094  movaps xmm14, xmm12
00007fdcd91d0098  addpd xmm14, xmm9
00007fdcd91d009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007fdcd91d00a3  ptest xmm7, xmm7
00007fdcd91d00a8  jnz 0x00007FDCD91D40D9
00007fdcd91d00ae  vmovaps xmm12, [rsp+0x60]
00007fdcd91d00b4  vpermilpd xmm12, xmm12, 0x00
00007fdcd91d00ba  vmovaps xmm7, [rsp+0xF0]
00007fdcd91d00c3  movaps xmm9, xmm7
00007fdcd91d00c7  mulpd xmm9, xmm12
00007fdcd91d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007fdcd91d00d2  ptest xmm6, xmm6
00007fdcd91d00d7  jnz 0x00007FDCD91D421D
00007fdcd91d00dd  movaps xmm12, xmm15
00007fdcd91d00e1  addpd xmm12, xmm11
00007fdcd91d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007fdcd91d00ec  ptest xmm7, xmm7
00007fdcd91d00f1  jnz 0x00007FDCD91D4360
00007fdcd91d00f7  vmovaps xmm15, [rsp+0x60]
00007fdcd91d00fd  vpermilpd xmm15, xmm15, 0x00
00007fdcd91d0103  vmovaps xmm7, [rsp+0x40]
00007fdcd91d0109  movaps xmm11, xmm7
00007fdcd91d010d  mulpd xmm11, xmm15
00007fdcd91d0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007fdcd91d0118  ptest xmm6, xmm6
00007fdcd91d011d  jnz 0x00007FDCD91D44A4
00007fdcd91d0123  movaps xmm15, xmm10
00007fdcd91d0127  addpd xmm15, xmm13
00007fdcd91d012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007fdcd91d0132  ptest xmm7, xmm7
00007fdcd91d0137  jnz 0x00007FDCD91D45E7
00007fdcd91d013d  vmovaps xmm13, [rsp+0x60]
00007fdcd91d0143  vpermilpd xmm13, xmm13, 0x00
00007fdcd91d0149  vmovaps xmm7, [rsp+0x50]
00007fdcd91d014f  movaps xmm10, xmm7
00007fdcd91d0153  mulpd xmm10, xmm13
00007fdcd91d0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007fdcd91d015e  ptest xmm6, xmm6
00007fdcd91d0163  jnz 0x00007FDCD91D472B
00007fdcd91d0169  movaps xmm13, xmm1
00007fdcd91d016d  addpd xmm13, xmm8
00007fdcd91d0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007fdcd91d0178  ptest xmm7, xmm7
00007fdcd91d017d  jnz 0x00007FDCD91D486E
00007fdcd91d0183  lea rax, [r14+0x70]
00007fdcd91d0187  movups xmm1, [r13+rax*1]
00007fdcd91d018d  movaps [r15+0x240], xmm1
00007fdcd91d0195  movaps xmm8, xmm14
00007fdcd91d0199  addpd xmm8, xmm9
00007fdcd91d019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007fdcd91d01a4  ptest xmm7, xmm7
00007fdcd91d01a9  jnz 0x00007FDCD91D49BB
00007fdcd91d01af  movaps [r15+0x170], xmm8
00007fdcd91d01b7  vmovaps xmm14, [rsp+0x70]
00007fdcd91d01bd  vpermilpd xmm14, xmm14, 0x00
00007fdcd91d01c3  movaps xmm9, xmm1
00007fdcd91d01c7  mulpd xmm9, xmm14
00007fdcd91d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007fdcd91d01d2  ptest xmm7, xmm7
00007fdcd91d01d7  jnz 0x00007FDCD91D4AFF
00007fdcd91d01dd  vmovaps xmm1, [rsp+0x70]
00007fdcd91d01e3  vpermilpd xmm1, xmm1, 0x00
00007fdcd91d01e9  movaps xmm14, xmm4
00007fdcd91d01ed  mulpd xmm14, xmm1
00007fdcd91d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007fdcd91d01f8  ptest xmm7, xmm7
00007fdcd91d01fd  jnz 0x00007FDCD91D4C42
00007fdcd91d0203  movaps [r15+0x180], xmm14
00007fdcd91d020b  movaps xmm1, xmm12
00007fdcd91d020f  addpd xmm1, xmm11
00007fdcd91d0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007fdcd91d0219  ptest xmm7, xmm7
00007fdcd91d021e  jnz 0x00007FDCD91D4D84
00007fdcd91d0224  movaps [r15+0x210], xmm1
00007fdcd91d022c  movups xmm12, [r13+r14*1]
00007fdcd91d0232  lea rax, [r14+0x10]
00007fdcd91d0236  movups xmm11, [r13+rax*1]
00007fdcd91d023c  movaps [r15+0x230], xmm11
00007fdcd91d0244  movaps xmm7, xmm15
00007fdcd91d0248  addpd xmm7, xmm10
00007fdcd91d024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007fdcd91d0252  ptest xmm6, xmm6
00007fdcd91d0257  jnz 0x00007FDCD91D4EDA
00007fdcd91d025d  movaps [r15+0x130], xmm7
00007fdcd91d0265  vmovaps xmm15, [rsp+0x70]
00007fdcd91d026b  vpermilpd xmm15, xmm15, 0x00
00007fdcd91d0271  movaps xmm10, xmm11
00007fdcd91d0275  mulpd xmm10, xmm15
00007fdcd91d027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007fdcd91d0280  ptest xmm6, xmm6
00007fdcd91d0285  jnz 0x00007FDCD91D501C
00007fdcd91d028b  movaps [r15+0x220], xmm10
00007fdcd91d0293  vmovaps xmm15, [rsp+0x70]
00007fdcd91d0299  vpermilpd xmm15, xmm15, 0x00
00007fdcd91d029f  movaps xmm11, xmm12
00007fdcd91d02a3  mulpd xmm11, xmm15
00007fdcd91d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007fdcd91d02ae  ptest xmm6, xmm6
00007fdcd91d02b3  jnz 0x00007FDCD91D5160
00007fdcd91d02b9  movaps xmm15, xmm13
00007fdcd91d02bd  addpd xmm15, xmm9
00007fdcd91d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007fdcd91d02c8  ptest xmm12, xmm12
00007fdcd91d02ce  jnz 0x00007FDCD91D52A4
00007fdcd91d02d4  movaps [r15+0x140], xmm15
00007fdcd91d02dc  movaps xmm13, xmm8
00007fdcd91d02e0  addpd xmm13, xmm14
00007fdcd91d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007fdcd91d02eb  ptest xmm12, xmm12
00007fdcd91d02f1  jnz 0x00007FDCD91D53E8
00007fdcd91d02f7  movaps [r15+0x150], xmm13
00007fdcd91d02ff  movaps xmm14, xmm1
00007fdcd91d0303  addpd xmm14, xmm10
00007fdcd91d0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007fdcd91d030e  ptest xmm12, xmm12
00007fdcd91d0314  jnz 0x00007FDCD91D552C
00007fdcd91d031a  movaps [r15+0x160], xmm14
00007fdcd91d0322  movaps xmm1, xmm7
00007fdcd91d0325  addpd xmm1, xmm11
00007fdcd91d032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007fdcd91d032f  ptest xmm12, xmm12
00007fdcd91d0335  jnz 0x00007FDCD91D566F
00007fdcd91d033b  movaps [r15+0x120], xmm1
00007fdcd91d0343  mov eax, 0x430920
00007fdcd91d0348  movups [r13+rax*1], xmm15
00007fdcd91d034e  mov eax, 0x430930
00007fdcd91d0353  movups [r13+rax*1], xmm13
00007fdcd91d0359  mov eax, 0x430940
00007fdcd91d035e  movups [r13+rax*1], xmm14
00007fdcd91d0364  mov eax, 0x430950
00007fdcd91d0369  movups [r13+rax*1], xmm1
00007fdcd91d036f  mov eax, [r15+0x108]
00007fdcd91d0376  sahf
00007fdcd91d0377  jnz 0x00007FDCD91D03A9
00007fdcd91d0379  cmp dword ptr [r15+0x318], 0x00
00007fdcd91d0381  jz 0x00007FDCD91DB900
00007fdcd91d0387  nop [rax+rax*1], ax
00007fdcd91d0390  nop [rax+rax*1], eax
00007fdcd91d0398  mov eax, 0x410444
00007fdcd91d039d  mov [r15+0x100], rax
00007fdcd91d03a4  jmp 0x00007FDCD8FFE110
00007fdcd91d03a9  cmp dword ptr [r15+0x318], 0x00
00007fdcd91d03b1  jz 0x00007FDCD91D57E0
00007fdcd91d03b7  nop [rax+rax*1], ax
00007fdcd91d03c0  nop [rax+rax*1], eax
00007fdcd91d03c8  mov eax, 0x410278
00007fdcd91d03cd  mov [r15+0x100], rax
00007fdcd91d03d4  jmp 0x00007FDCD8FFE110
00007fdcd91d03d9  int3
00007fdcd91d03da  call 0x00007FDCD90B52F0
00007fdcd91d03df  jmp 0x00007FDCD91CF016
00007fdcd91d03e4  call 0x00007FDCD90C4620
00007fdcd91d03e9  jmp 0x00007FDCD91CF023
00007fdcd91d03ee  call 0x00007FDCD90C33A0
00007fdcd91d03f3  jmp 0x00007FDCD91CF035
00007fdcd91d03f8  call 0x00007FDCD90C2120
00007fdcd91d03fd  jmp 0x00007FDCD91CF03F
00007fdcd91d0402  call 0x00007FDCD90C0860
00007fdcd91d0407  jmp 0x00007FDCD91CF067
00007fdcd91d040c  call 0x00007FDCD90BF5F0
00007fdcd91d0411  jmp 0x00007FDCD91CF073
00007fdcd91d0416  call 0x00007FDCD90C0860
00007fdcd91d041b  jmp 0x00007FDCD91CF0A5
00007fdcd91d0420  call 0x00007FDCD90BF5F0
00007fdcd91d0425  jmp 0x00007FDCD91CF0B1
00007fdcd91d042a  call 0x00007FDCD90C4740
00007fdcd91d042f  jmp 0x00007FDCD91CF0BE
00007fdcd91d0434  call 0x00007FDCD90B5400
00007fdcd91d0439  jmp 0x00007FDCD91CF0CB
00007fdcd91d043e  call 0x00007FDCD90B52F0
00007fdcd91d0443  jmp 0x00007FDCD91CF0D8
00007fdcd91d0448  call 0x00007FDCD90C4620
00007fdcd91d044d  jmp 0x00007FDCD91CF0E5
00007fdcd91d0452  call 0x00007FDCD90C0860
00007fdcd91d0457  jmp 0x00007FDCD91CF10D
00007fdcd91d045c  call 0x00007FDCD90BF5F0
00007fdcd91d0461  jmp 0x00007FDCD91CF119
00007fdcd91d0466  call 0x00007FDCD9009D70
00007fdcd91d046b  jmp 0x00007FDCD91CF11F
00007fdcd91d0470  call 0x00007FDCD90BE9C0
00007fdcd91d0475  jmp 0x00007FDCD91CF129
00007fdcd91d047a  call 0x00007FDCD90C0860
00007fdcd91d047f  jmp 0x00007FDCD91CF151
00007fdcd91d0484  call 0x00007FDCD90BF5F0
00007fdcd91d0489  jmp 0x00007FDCD91CF15D
00007fdcd91d048e  call 0x00007FDCD90BD750
00007fdcd91d0493  jmp 0x00007FDCD91CF16A
00007fdcd91d0498  call 0x00007FDCD90BC4E0
00007fdcd91d049d  jmp 0x00007FDCD91CF177
00007fdcd91d04a2  call 0x00007FDCD90C4740
00007fdcd91d04a7  jmp 0x00007FDCD91CF184
00007fdcd91d04ac  call 0x00007FDCD90B5400
00007fdcd91d04b1  jmp 0x00007FDCD91CF191
00007fdcd91d04b6  call 0x00007FDCD90B52F0
00007fdcd91d04bb  jmp 0x00007FDCD91CF19E
00007fdcd91d04c0  call 0x00007FDCD90C4620
00007fdcd91d04c5  jmp 0x00007FDCD91CF1AB
00007fdcd91d04ca  call 0x00007FDCD90C0860
00007fdcd91d04cf  jmp 0x00007FDCD91CF1BE
00007fdcd91d04d4  call 0x00007FDCD90BB270
00007fdcd91d04d9  jmp 0x00007FDCD91CF1CB
00007fdcd91d04de  call 0x00007FDCD90BA000
00007fdcd91d04e3  jmp 0x00007FDCD91CF1D8
00007fdcd91d04e8  call 0x00007FDCD90B8D90
00007fdcd91d04ed  jmp 0x00007FDCD91CF1E5
00007fdcd91d04f2  call 0x00007FDCD90B8A20
00007fdcd91d04f7  jmp 0x00007FDCD91CF1F2
00007fdcd91d04fc  call 0x00007FDCD90B5400
00007fdcd91d0501  jmp 0x00007FDCD91CF1FC
00007fdcd91d0506  call 0x00007FDCD90C2240
00007fdcd91d050b  jmp 0x00007FDCD91CF206
00007fdcd91d0510  call 0x00007FDCD90B52F0
00007fdcd91d0515  jmp 0x00007FDCD91CF210
00007fdcd91d051a  call 0x00007FDCD90C2120
00007fdcd91d051f  jmp 0x00007FDCD91CF21A
00007fdcd91d0524  call 0x00007FDCD90B77B0
00007fdcd91d0529  jmp 0x00007FDCD91CF224
00007fdcd91d052e  call 0x00007FDCD90B6550
00007fdcd91d0533  jmp 0x00007FDCD91CF22E
00007fdcd91d0538  call 0x00007FDCD90BFD50
00007fdcd91d053d  jmp 0x00007FDCD91CF240
00007fdcd91d0542  call 0x00007FDCD90B8EA0
00007fdcd91d0547  jmp 0x00007FDCD91CF24A
00007fdcd91d054c  call 0x00007FDCD90BFC30
00007fdcd91d0551  jmp 0x00007FDCD91CF257
00007fdcd91d0556  call 0x00007FDCD90B8D90
00007fdcd91d055b  jmp 0x00007FDCD91CF264
00007fdcd91d0560  call 0x00007FDCD90C2240
00007fdcd91d0565  jmp 0x00007FDCD91CF271
00007fdcd91d056a  call 0x00007FDCD90B5400
00007fdcd91d056f  jmp 0x00007FDCD91CF27E
00007fdcd91d0574  call 0x00007FDCD90B52F0
00007fdcd91d0579  jmp 0x00007FDCD91CF28B
00007fdcd91d057e  call 0x00007FDCD90C2120
00007fdcd91d0583  jmp 0x00007FDCD91CF298
00007fdcd91d0588  call 0x00007FDCD90B52F0
00007fdcd91d058d  jmp 0x00007FDCD91CF2AB
00007fdcd91d0592  call 0x00007FDCD90B52F0
00007fdcd91d0597  jmp 0x00007FDCD91CF2BE
00007fdcd91d059c  call 0x00007FDCD90B52F0
00007fdcd91d05a1  jmp 0x00007FDCD91CF2D1
00007fdcd91d05a6  call 0x00007FDCD90B52F0
00007fdcd91d05ab  jmp 0x00007FDCD91CF2E4
00007fdcd91d05b0  call 0x00007FDCD90C2240
00007fdcd91d05b5  jmp 0x00007FDCD91CF2F9
00007fdcd91d05ba  call 0x00007FDCD90C2240
00007fdcd91d05bf  jmp 0x00007FDCD91CF30C
00007fdcd91d05c4  call 0x00007FDCD90C2120
00007fdcd91d05c9  jmp 0x00007FDCD91CF319
00007fdcd91d05ce  call 0x00007FDCD90B52F0
00007fdcd91d05d3  jmp 0x00007FDCD91CF32C
00007fdcd91d05d8  call 0x00007FDCD90B52F0
00007fdcd91d05dd  jmp 0x00007FDCD91CF34F
00007fdcd91d05e2  call 0x00007FDCD90B52F0
00007fdcd91d05e7  jmp 0x00007FDCD91CF362
00007fdcd91d05ec  call 0x00007FDCD8FFF540
00007fdcd91d05f1  jmp 0x00007FDCD91CF380
00007fdcd91d05f6  call 0x00007FDCD9008C20
00007fdcd91d05fb  jmp 0x00007FDCD91CF38A
00007fdcd91d0600  call 0x00007FDCD90D6600
00007fdcd91d0605  jmp 0x00007FDCD91CF396
00007fdcd91d060a  call 0x00007FDCD8FFF540
00007fdcd91d060f  jmp 0x00007FDCD91CF3A6
00007fdcd91d0614  call 0x00007FDCD90C0370
00007fdcd91d0619  jmp 0x00007FDCD91CF3D4
00007fdcd91d061e  call 0x00007FDCD90BF100
00007fdcd91d0623  jmp 0x00007FDCD91CF3DD
00007fdcd91d0628  call 0x00007FDCD90C0370
00007fdcd91d062d  jmp 0x00007FDCD91CF43B
00007fdcd91d0632  call 0x00007FDCD90BF100
00007fdcd91d0637  jmp 0x00007FDCD91CF444
00007fdcd91d063c  call 0x00007FDCD90C0370
00007fdcd91d0641  jmp 0x00007FDCD91CF48B
00007fdcd91d0646  call 0x00007FDCD90BF100
00007fdcd91d064b  jmp 0x00007FDCD91CF494
00007fdcd91d0650  call 0x00007FDCD900B720
00007fdcd91d0655  jmp 0x00007FDCD91CF4D7
00007fdcd91d065a  call 0x00007FDCD90B47C0
00007fdcd91d065f  jmp 0x00007FDCD91CF4EA
00007fdcd91d0664  call 0x00007FDCD9008B00
00007fdcd91d0669  jmp 0x00007FDCD91CF501
00007fdcd91d066e  call 0x00007FDCD8FFF430
00007fdcd91d0673  jmp 0x00007FDCD91CF514
00007fdcd91d0678  call 0x00007FDCD8FFF430
00007fdcd91d067d  jmp 0x00007FDCD91CF527
00007fdcd91d0682  sub rsp, 0x08
00007fdcd91d0686  push rax
00007fdcd91d0687  push rcx
00007fdcd91d0688  push rdx
00007fdcd91d0689  push rdi
00007fdcd91d068a  push rsi
00007fdcd91d068b  push r8
00007fdcd91d068d  push r9
00007fdcd91d068f  push r10
00007fdcd91d0691  push r11
00007fdcd91d0693  sub rsp, 0xF0
00007fdcd91d069a  vmovaps [rsp], xmm0
00007fdcd91d069f  vmovaps [rsp+0x10], xmm2
00007fdcd91d06a5  vmovaps [rsp+0x20], xmm3
00007fdcd91d06ab  vmovaps [rsp+0x30], xmm4
00007fdcd91d06b1  vmovaps [rsp+0x40], xmm5
00007fdcd91d06b7  vmovaps [rsp+0x50], xmm6
00007fdcd91d06bd  vmovaps [rsp+0x60], xmm7
00007fdcd91d06c3  vmovaps [rsp+0x70], xmm8
00007fdcd91d06c9  vmovaps [rsp+0x80], xmm9
00007fdcd91d06d2  vmovaps [rsp+0x90], xmm10
00007fdcd91d06db  vmovaps [rsp+0xA0], xmm11
00007fdcd91d06e4  vmovaps [rsp+0xB0], xmm12
00007fdcd91d06ed  vmovaps [rsp+0xC0], xmm13
00007fdcd91d06f6  vmovaps [rsp+0xD0], xmm14
00007fdcd91d06ff  vmovaps [rsp+0xE0], xmm15
00007fdcd91d0708  sub rsp, 0x30
00007fdcd91d070c  movaps [rsp], xmm1
00007fdcd91d0710  movaps [rsp+0x10], xmm15
00007fdcd91d0716  movaps [rsp+0x20], xmm14
00007fdcd91d071c  lea rdi, [rsp]
00007fdcd91d0720  mov esi, 0x00
00007fdcd91d0725  mov rax, 0x5B56EFBF3530
00007fdcd91d072f  call rax
00007fdcd91d0731  movaps xmm1, [rsp]
00007fdcd91d0735  add rsp, 0x30
00007fdcd91d0739  vmovaps xmm0, [rsp]
00007fdcd91d073e  vmovaps xmm2, [rsp+0x10]
00007fdcd91d0744  vmovaps xmm3, [rsp+0x20]
00007fdcd91d074a  vmovaps xmm4, [rsp+0x30]
00007fdcd91d0750  vmovaps xmm5, [rsp+0x40]
00007fdcd91d0756  vmovaps xmm6, [rsp+0x50]
00007fdcd91d075c  vmovaps xmm7, [rsp+0x60]
00007fdcd91d0762  vmovaps xmm8, [rsp+0x70]
00007fdcd91d0768  vmovaps xmm9, [rsp+0x80]
00007fdcd91d0771  vmovaps xmm10, [rsp+0x90]
00007fdcd91d077a  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d0783  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d078c  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d0795  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d079e  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d07a7  add rsp, 0xF0
00007fdcd91d07ae  pop r11
00007fdcd91d07b0  pop r10
00007fdcd91d07b2  pop r9
00007fdcd91d07b4  pop r8
00007fdcd91d07b6  pop rsi
00007fdcd91d07b7  pop rdi
00007fdcd91d07b8  pop rdx
00007fdcd91d07b9  pop rcx
00007fdcd91d07ba  pop rax
00007fdcd91d07bb  add rsp, 0x08
00007fdcd91d07bf  jmp 0x00007FDCD91CF581
00007fdcd91d07c4  sub rsp, 0x08
00007fdcd91d07c8  push rax
00007fdcd91d07c9  push rcx
00007fdcd91d07ca  push rdx
00007fdcd91d07cb  push rdi
00007fdcd91d07cc  push rsi
00007fdcd91d07cd  push r8
00007fdcd91d07cf  push r9
00007fdcd91d07d1  push r10
00007fdcd91d07d3  push r11
00007fdcd91d07d5  sub rsp, 0xF0
00007fdcd91d07dc  vmovaps [rsp], xmm0
00007fdcd91d07e1  vmovaps [rsp+0x10], xmm1
00007fdcd91d07e7  vmovaps [rsp+0x20], xmm2
00007fdcd91d07ed  vmovaps [rsp+0x30], xmm3
00007fdcd91d07f3  vmovaps [rsp+0x40], xmm4
00007fdcd91d07f9  vmovaps [rsp+0x50], xmm5
00007fdcd91d07ff  vmovaps [rsp+0x60], xmm6
00007fdcd91d0805  vmovaps [rsp+0x70], xmm7
00007fdcd91d080b  vmovaps [rsp+0x80], xmm8
00007fdcd91d0814  vmovaps [rsp+0x90], xmm9
00007fdcd91d081d  vmovaps [rsp+0xA0], xmm10
00007fdcd91d0826  vmovaps [rsp+0xB0], xmm11
00007fdcd91d082f  vmovaps [rsp+0xC0], xmm12
00007fdcd91d0838  vmovaps [rsp+0xD0], xmm14
00007fdcd91d0841  vmovaps [rsp+0xE0], xmm15
00007fdcd91d084a  sub rsp, 0x30
00007fdcd91d084e  movaps [rsp], xmm13
00007fdcd91d0853  movaps [rsp+0x10], xmm1
00007fdcd91d0858  movaps [rsp+0x20], xmm14
00007fdcd91d085e  lea rdi, [rsp]
00007fdcd91d0862  mov esi, 0x00
00007fdcd91d0867  mov rax, 0x5B56EFBF3530
00007fdcd91d0871  call rax
00007fdcd91d0873  movaps xmm13, [rsp]
00007fdcd91d0878  add rsp, 0x30
00007fdcd91d087c  vmovaps xmm0, [rsp]
00007fdcd91d0881  vmovaps xmm1, [rsp+0x10]
00007fdcd91d0887  vmovaps xmm2, [rsp+0x20]
00007fdcd91d088d  vmovaps xmm3, [rsp+0x30]
00007fdcd91d0893  vmovaps xmm4, [rsp+0x40]
00007fdcd91d0899  vmovaps xmm5, [rsp+0x50]
00007fdcd91d089f  vmovaps xmm6, [rsp+0x60]
00007fdcd91d08a5  vmovaps xmm7, [rsp+0x70]
00007fdcd91d08ab  vmovaps xmm8, [rsp+0x80]
00007fdcd91d08b4  vmovaps xmm9, [rsp+0x90]
00007fdcd91d08bd  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d08c6  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d08cf  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d08d8  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d08e1  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d08ea  add rsp, 0xF0
00007fdcd91d08f1  pop r11
00007fdcd91d08f3  pop r10
00007fdcd91d08f5  pop r9
00007fdcd91d08f7  pop r8
00007fdcd91d08f9  pop rsi
00007fdcd91d08fa  pop rdi
00007fdcd91d08fb  pop rdx
00007fdcd91d08fc  pop rcx
00007fdcd91d08fd  pop rax
00007fdcd91d08fe  add rsp, 0x08
00007fdcd91d0902  jmp 0x00007FDCD91CF5CF
00007fdcd91d0907  sub rsp, 0x08
00007fdcd91d090b  push rax
00007fdcd91d090c  push rcx
00007fdcd91d090d  push rdx
00007fdcd91d090e  push rdi
00007fdcd91d090f  push rsi
00007fdcd91d0910  push r8
00007fdcd91d0912  push r9
00007fdcd91d0914  push r10
00007fdcd91d0916  push r11
00007fdcd91d0918  sub rsp, 0xF0
00007fdcd91d091f  vmovaps [rsp], xmm0
00007fdcd91d0924  vmovaps [rsp+0x10], xmm1
00007fdcd91d092a  vmovaps [rsp+0x20], xmm2
00007fdcd91d0930  vmovaps [rsp+0x30], xmm3
00007fdcd91d0936  vmovaps [rsp+0x40], xmm4
00007fdcd91d093c  vmovaps [rsp+0x50], xmm5
00007fdcd91d0942  vmovaps [rsp+0x60], xmm6
00007fdcd91d0948  vmovaps [rsp+0x70], xmm7
00007fdcd91d094e  vmovaps [rsp+0x80], xmm8
00007fdcd91d0957  vmovaps [rsp+0x90], xmm9
00007fdcd91d0960  vmovaps [rsp+0xA0], xmm10
00007fdcd91d0969  vmovaps [rsp+0xB0], xmm11
00007fdcd91d0972  vmovaps [rsp+0xC0], xmm12
00007fdcd91d097b  vmovaps [rsp+0xD0], xmm13
00007fdcd91d0984  vmovaps [rsp+0xE0], xmm14
00007fdcd91d098d  sub rsp, 0x30
00007fdcd91d0991  movaps [rsp], xmm15
00007fdcd91d0996  movaps [rsp+0x10], xmm14
00007fdcd91d099c  movaps [rsp+0x20], xmm1
00007fdcd91d09a1  lea rdi, [rsp]
00007fdcd91d09a5  mov esi, 0x00
00007fdcd91d09aa  mov rax, 0x5B56EFBF3530
00007fdcd91d09b4  call rax
00007fdcd91d09b6  movaps xmm15, [rsp]
00007fdcd91d09bb  add rsp, 0x30
00007fdcd91d09bf  vmovaps xmm0, [rsp]
00007fdcd91d09c4  vmovaps xmm1, [rsp+0x10]
00007fdcd91d09ca  vmovaps xmm2, [rsp+0x20]
00007fdcd91d09d0  vmovaps xmm3, [rsp+0x30]
00007fdcd91d09d6  vmovaps xmm4, [rsp+0x40]
00007fdcd91d09dc  vmovaps xmm5, [rsp+0x50]
00007fdcd91d09e2  vmovaps xmm6, [rsp+0x60]
00007fdcd91d09e8  vmovaps xmm7, [rsp+0x70]
00007fdcd91d09ee  vmovaps xmm8, [rsp+0x80]
00007fdcd91d09f7  vmovaps xmm9, [rsp+0x90]
00007fdcd91d0a00  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d0a09  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d0a12  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d0a1b  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d0a24  vmovaps xmm14, [rsp+0xE0]
00007fdcd91d0a2d  add rsp, 0xF0
00007fdcd91d0a34  pop r11
00007fdcd91d0a36  pop r10
00007fdcd91d0a38  pop r9
00007fdcd91d0a3a  pop r8
00007fdcd91d0a3c  pop rsi
00007fdcd91d0a3d  pop rdi
00007fdcd91d0a3e  pop rdx
00007fdcd91d0a3f  pop rcx
00007fdcd91d0a40  pop rax
00007fdcd91d0a41  add rsp, 0x08
00007fdcd91d0a45  jmp 0x00007FDCD91CF617
00007fdcd91d0a4a  sub rsp, 0x08
00007fdcd91d0a4e  push rax
00007fdcd91d0a4f  push rcx
00007fdcd91d0a50  push rdx
00007fdcd91d0a51  push rdi
00007fdcd91d0a52  push rsi
00007fdcd91d0a53  push r8
00007fdcd91d0a55  push r9
00007fdcd91d0a57  push r10
00007fdcd91d0a59  push r11
00007fdcd91d0a5b  sub rsp, 0xF0
00007fdcd91d0a62  vmovaps [rsp], xmm0
00007fdcd91d0a67  vmovaps [rsp+0x10], xmm2
00007fdcd91d0a6d  vmovaps [rsp+0x20], xmm3
00007fdcd91d0a73  vmovaps [rsp+0x30], xmm4
00007fdcd91d0a79  vmovaps [rsp+0x40], xmm5
00007fdcd91d0a7f  vmovaps [rsp+0x50], xmm6
00007fdcd91d0a85  vmovaps [rsp+0x60], xmm7
00007fdcd91d0a8b  vmovaps [rsp+0x70], xmm8
00007fdcd91d0a91  vmovaps [rsp+0x80], xmm9
00007fdcd91d0a9a  vmovaps [rsp+0x90], xmm10
00007fdcd91d0aa3  vmovaps [rsp+0xA0], xmm11
00007fdcd91d0aac  vmovaps [rsp+0xB0], xmm12
00007fdcd91d0ab5  vmovaps [rsp+0xC0], xmm13
00007fdcd91d0abe  vmovaps [rsp+0xD0], xmm14
00007fdcd91d0ac7  vmovaps [rsp+0xE0], xmm15
00007fdcd91d0ad0  sub rsp, 0x30
00007fdcd91d0ad4  movaps [rsp], xmm1
00007fdcd91d0ad8  movaps [rsp+0x10], xmm14
00007fdcd91d0ade  movaps [rsp+0x20], xmm10
00007fdcd91d0ae4  lea rdi, [rsp]
00007fdcd91d0ae8  mov esi, 0x00
00007fdcd91d0aed  mov rax, 0x5B56EFBF3530
00007fdcd91d0af7  call rax
00007fdcd91d0af9  movaps xmm1, [rsp]
00007fdcd91d0afd  add rsp, 0x30
00007fdcd91d0b01  vmovaps xmm0, [rsp]
00007fdcd91d0b06  vmovaps xmm2, [rsp+0x10]
00007fdcd91d0b0c  vmovaps xmm3, [rsp+0x20]
00007fdcd91d0b12  vmovaps xmm4, [rsp+0x30]
00007fdcd91d0b18  vmovaps xmm5, [rsp+0x40]
00007fdcd91d0b1e  vmovaps xmm6, [rsp+0x50]
00007fdcd91d0b24  vmovaps xmm7, [rsp+0x60]
00007fdcd91d0b2a  vmovaps xmm8, [rsp+0x70]
00007fdcd91d0b30  vmovaps xmm9, [rsp+0x80]
00007fdcd91d0b39  vmovaps xmm10, [rsp+0x90]
00007fdcd91d0b42  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d0b4b  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d0b54  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d0b5d  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d0b66  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d0b6f  add rsp, 0xF0
00007fdcd91d0b76  pop r11
00007fdcd91d0b78  pop r10
00007fdcd91d0b7a  pop r9
00007fdcd91d0b7c  pop r8
00007fdcd91d0b7e  pop rsi
00007fdcd91d0b7f  pop rdi
00007fdcd91d0b80  pop rdx
00007fdcd91d0b81  pop rcx
00007fdcd91d0b82  pop rax
00007fdcd91d0b83  add rsp, 0x08
00007fdcd91d0b87  jmp 0x00007FDCD91CF631
00007fdcd91d0b8c  sub rsp, 0x08
00007fdcd91d0b90  push rax
00007fdcd91d0b91  push rcx
00007fdcd91d0b92  push rdx
00007fdcd91d0b93  push rdi
00007fdcd91d0b94  push rsi
00007fdcd91d0b95  push r8
00007fdcd91d0b97  push r9
00007fdcd91d0b99  push r10
00007fdcd91d0b9b  push r11
00007fdcd91d0b9d  sub rsp, 0xF0
00007fdcd91d0ba4  vmovaps [rsp], xmm0
00007fdcd91d0ba9  vmovaps [rsp+0x10], xmm1
00007fdcd91d0baf  vmovaps [rsp+0x20], xmm2
00007fdcd91d0bb5  vmovaps [rsp+0x30], xmm3
00007fdcd91d0bbb  vmovaps [rsp+0x40], xmm4
00007fdcd91d0bc1  vmovaps [rsp+0x50], xmm5
00007fdcd91d0bc7  vmovaps [rsp+0x60], xmm6
00007fdcd91d0bcd  vmovaps [rsp+0x70], xmm7
00007fdcd91d0bd3  vmovaps [rsp+0x80], xmm8
00007fdcd91d0bdc  vmovaps [rsp+0x90], xmm9
00007fdcd91d0be5  vmovaps [rsp+0xA0], xmm10
00007fdcd91d0bee  vmovaps [rsp+0xB0], xmm11
00007fdcd91d0bf7  vmovaps [rsp+0xC0], xmm12
00007fdcd91d0c00  vmovaps [rsp+0xD0], xmm14
00007fdcd91d0c09  vmovaps [rsp+0xE0], xmm15
00007fdcd91d0c12  sub rsp, 0x30
00007fdcd91d0c16  movaps [rsp], xmm13
00007fdcd91d0c1b  movaps [rsp+0x10], xmm14
00007fdcd91d0c21  movaps [rsp+0x20], xmm2
00007fdcd91d0c26  lea rdi, [rsp]
00007fdcd91d0c2a  mov esi, 0x00
00007fdcd91d0c2f  mov rax, 0x5B56EFBF3530
00007fdcd91d0c39  call rax
00007fdcd91d0c3b  movaps xmm13, [rsp]
00007fdcd91d0c40  add rsp, 0x30
00007fdcd91d0c44  vmovaps xmm0, [rsp]
00007fdcd91d0c49  vmovaps xmm1, [rsp+0x10]
00007fdcd91d0c4f  vmovaps xmm2, [rsp+0x20]
00007fdcd91d0c55  vmovaps xmm3, [rsp+0x30]
00007fdcd91d0c5b  vmovaps xmm4, [rsp+0x40]
00007fdcd91d0c61  vmovaps xmm5, [rsp+0x50]
00007fdcd91d0c67  vmovaps xmm6, [rsp+0x60]
00007fdcd91d0c6d  vmovaps xmm7, [rsp+0x70]
00007fdcd91d0c73  vmovaps xmm8, [rsp+0x80]
00007fdcd91d0c7c  vmovaps xmm9, [rsp+0x90]
00007fdcd91d0c85  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d0c8e  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d0c97  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d0ca0  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d0ca9  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d0cb2  add rsp, 0xF0
00007fdcd91d0cb9  pop r11
00007fdcd91d0cbb  pop r10
00007fdcd91d0cbd  pop r9
00007fdcd91d0cbf  pop r8
00007fdcd91d0cc1  pop rsi
00007fdcd91d0cc2  pop rdi
00007fdcd91d0cc3  pop rdx
00007fdcd91d0cc4  pop rcx
00007fdcd91d0cc5  pop rax
00007fdcd91d0cc6  add rsp, 0x08
00007fdcd91d0cca  jmp 0x00007FDCD91CF64C
00007fdcd91d0ccf  sub rsp, 0x08
00007fdcd91d0cd3  push rax
00007fdcd91d0cd4  push rcx
00007fdcd91d0cd5  push rdx
00007fdcd91d0cd6  push rdi
00007fdcd91d0cd7  push rsi
00007fdcd91d0cd8  push r8
00007fdcd91d0cda  push r9
00007fdcd91d0cdc  push r10
00007fdcd91d0cde  push r11
00007fdcd91d0ce0  sub rsp, 0xF0
00007fdcd91d0ce7  vmovaps [rsp], xmm0
00007fdcd91d0cec  vmovaps [rsp+0x10], xmm2
00007fdcd91d0cf2  vmovaps [rsp+0x20], xmm3
00007fdcd91d0cf8  vmovaps [rsp+0x30], xmm4
00007fdcd91d0cfe  vmovaps [rsp+0x40], xmm5
00007fdcd91d0d04  vmovaps [rsp+0x50], xmm6
00007fdcd91d0d0a  vmovaps [rsp+0x60], xmm7
00007fdcd91d0d10  vmovaps [rsp+0x70], xmm8
00007fdcd91d0d16  vmovaps [rsp+0x80], xmm9
00007fdcd91d0d1f  vmovaps [rsp+0x90], xmm10
00007fdcd91d0d28  vmovaps [rsp+0xA0], xmm11
00007fdcd91d0d31  vmovaps [rsp+0xB0], xmm12
00007fdcd91d0d3a  vmovaps [rsp+0xC0], xmm13
00007fdcd91d0d43  vmovaps [rsp+0xD0], xmm14
00007fdcd91d0d4c  vmovaps [rsp+0xE0], xmm15
00007fdcd91d0d55  sub rsp, 0x30
00007fdcd91d0d59  movaps [rsp], xmm1
00007fdcd91d0d5d  movaps [rsp+0x10], xmm10
00007fdcd91d0d63  movaps [rsp+0x20], xmm2
00007fdcd91d0d68  lea rdi, [rsp]
00007fdcd91d0d6c  mov esi, 0x00
00007fdcd91d0d71  mov rax, 0x5B56EFBF3530
00007fdcd91d0d7b  call rax
00007fdcd91d0d7d  movaps xmm1, [rsp]
00007fdcd91d0d81  add rsp, 0x30
00007fdcd91d0d85  vmovaps xmm0, [rsp]
00007fdcd91d0d8a  vmovaps xmm2, [rsp+0x10]
00007fdcd91d0d90  vmovaps xmm3, [rsp+0x20]
00007fdcd91d0d96  vmovaps xmm4, [rsp+0x30]
00007fdcd91d0d9c  vmovaps xmm5, [rsp+0x40]
00007fdcd91d0da2  vmovaps xmm6, [rsp+0x50]
00007fdcd91d0da8  vmovaps xmm7, [rsp+0x60]
00007fdcd91d0dae  vmovaps xmm8, [rsp+0x70]
00007fdcd91d0db4  vmovaps xmm9, [rsp+0x80]
00007fdcd91d0dbd  vmovaps xmm10, [rsp+0x90]
00007fdcd91d0dc6  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d0dcf  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d0dd8  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d0de1  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d0dea  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d0df3  add rsp, 0xF0
00007fdcd91d0dfa  pop r11
00007fdcd91d0dfc  pop r10
00007fdcd91d0dfe  pop r9
00007fdcd91d0e00  pop r8
00007fdcd91d0e02  pop rsi
00007fdcd91d0e03  pop rdi
00007fdcd91d0e04  pop rdx
00007fdcd91d0e05  pop rcx
00007fdcd91d0e06  pop rax
00007fdcd91d0e07  add rsp, 0x08
00007fdcd91d0e0b  jmp 0x00007FDCD91CF6B4
00007fdcd91d0e10  sub rsp, 0x08
00007fdcd91d0e14  push rax
00007fdcd91d0e15  push rcx
00007fdcd91d0e16  push rdx
00007fdcd91d0e17  push rdi
00007fdcd91d0e18  push rsi
00007fdcd91d0e19  push r8
00007fdcd91d0e1b  push r9
00007fdcd91d0e1d  push r10
00007fdcd91d0e1f  push r11
00007fdcd91d0e21  sub rsp, 0xF0
00007fdcd91d0e28  vmovaps [rsp], xmm0
00007fdcd91d0e2d  vmovaps [rsp+0x10], xmm1
00007fdcd91d0e33  vmovaps [rsp+0x20], xmm2
00007fdcd91d0e39  vmovaps [rsp+0x30], xmm3
00007fdcd91d0e3f  vmovaps [rsp+0x40], xmm4
00007fdcd91d0e45  vmovaps [rsp+0x50], xmm5
00007fdcd91d0e4b  vmovaps [rsp+0x60], xmm6
00007fdcd91d0e51  vmovaps [rsp+0x70], xmm7
00007fdcd91d0e57  vmovaps [rsp+0x80], xmm8
00007fdcd91d0e60  vmovaps [rsp+0x90], xmm9
00007fdcd91d0e69  vmovaps [rsp+0xA0], xmm10
00007fdcd91d0e72  vmovaps [rsp+0xB0], xmm11
00007fdcd91d0e7b  vmovaps [rsp+0xC0], xmm12
00007fdcd91d0e84  vmovaps [rsp+0xD0], xmm13
00007fdcd91d0e8d  vmovaps [rsp+0xE0], xmm14
00007fdcd91d0e96  sub rsp, 0x30
00007fdcd91d0e9a  movaps [rsp], xmm15
00007fdcd91d0e9f  movaps [rsp+0x10], xmm10
00007fdcd91d0ea5  movaps [rsp+0x20], xmm2
00007fdcd91d0eaa  lea rdi, [rsp]
00007fdcd91d0eae  mov esi, 0x00
00007fdcd91d0eb3  mov rax, 0x5B56EFBF3530
00007fdcd91d0ebd  call rax
00007fdcd91d0ebf  movaps xmm15, [rsp]
00007fdcd91d0ec4  add rsp, 0x30
00007fdcd91d0ec8  vmovaps xmm0, [rsp]
00007fdcd91d0ecd  vmovaps xmm1, [rsp+0x10]
00007fdcd91d0ed3  vmovaps xmm2, [rsp+0x20]
00007fdcd91d0ed9  vmovaps xmm3, [rsp+0x30]
00007fdcd91d0edf  vmovaps xmm4, [rsp+0x40]
00007fdcd91d0ee5  vmovaps xmm5, [rsp+0x50]
00007fdcd91d0eeb  vmovaps xmm6, [rsp+0x60]
00007fdcd91d0ef1  vmovaps xmm7, [rsp+0x70]
00007fdcd91d0ef7  vmovaps xmm8, [rsp+0x80]
00007fdcd91d0f00  vmovaps xmm9, [rsp+0x90]
00007fdcd91d0f09  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d0f12  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d0f1b  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d0f24  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d0f2d  vmovaps xmm14, [rsp+0xE0]
00007fdcd91d0f36  add rsp, 0xF0
00007fdcd91d0f3d  pop r11
00007fdcd91d0f3f  pop r10
00007fdcd91d0f41  pop r9
00007fdcd91d0f43  pop r8
00007fdcd91d0f45  pop rsi
00007fdcd91d0f46  pop rdi
00007fdcd91d0f47  pop rdx
00007fdcd91d0f48  pop rcx
00007fdcd91d0f49  pop rax
00007fdcd91d0f4a  add rsp, 0x08
00007fdcd91d0f4e  jmp 0x00007FDCD91CF706
00007fdcd91d0f53  sub rsp, 0x08
00007fdcd91d0f57  push rax
00007fdcd91d0f58  push rcx
00007fdcd91d0f59  push rdx
00007fdcd91d0f5a  push rdi
00007fdcd91d0f5b  push rsi
00007fdcd91d0f5c  push r8
00007fdcd91d0f5e  push r9
00007fdcd91d0f60  push r10
00007fdcd91d0f62  push r11
00007fdcd91d0f64  sub rsp, 0xF0
00007fdcd91d0f6b  vmovaps [rsp], xmm0
00007fdcd91d0f70  vmovaps [rsp+0x10], xmm2
00007fdcd91d0f76  vmovaps [rsp+0x20], xmm3
00007fdcd91d0f7c  vmovaps [rsp+0x30], xmm4
00007fdcd91d0f82  vmovaps [rsp+0x40], xmm5
00007fdcd91d0f88  vmovaps [rsp+0x50], xmm6
00007fdcd91d0f8e  vmovaps [rsp+0x60], xmm7
00007fdcd91d0f94  vmovaps [rsp+0x70], xmm8
00007fdcd91d0f9a  vmovaps [rsp+0x80], xmm9
00007fdcd91d0fa3  vmovaps [rsp+0x90], xmm10
00007fdcd91d0fac  vmovaps [rsp+0xA0], xmm11
00007fdcd91d0fb5  vmovaps [rsp+0xB0], xmm12
00007fdcd91d0fbe  vmovaps [rsp+0xC0], xmm13
00007fdcd91d0fc7  vmovaps [rsp+0xD0], xmm14
00007fdcd91d0fd0  vmovaps [rsp+0xE0], xmm15
00007fdcd91d0fd9  sub rsp, 0x30
00007fdcd91d0fdd  movaps [rsp], xmm1
00007fdcd91d0fe1  movaps [rsp+0x10], xmm10
00007fdcd91d0fe7  movaps [rsp+0x20], xmm12
00007fdcd91d0fed  lea rdi, [rsp]
00007fdcd91d0ff1  mov esi, 0x00
00007fdcd91d0ff6  mov rax, 0x5B56EFBF3530
00007fdcd91d1000  call rax
00007fdcd91d1002  movaps xmm1, [rsp]
00007fdcd91d1006  add rsp, 0x30
00007fdcd91d100a  vmovaps xmm0, [rsp]
00007fdcd91d100f  vmovaps xmm2, [rsp+0x10]
00007fdcd91d1015  vmovaps xmm3, [rsp+0x20]
00007fdcd91d101b  vmovaps xmm4, [rsp+0x30]
00007fdcd91d1021  vmovaps xmm5, [rsp+0x40]
00007fdcd91d1027  vmovaps xmm6, [rsp+0x50]
00007fdcd91d102d  vmovaps xmm7, [rsp+0x60]
00007fdcd91d1033  vmovaps xmm8, [rsp+0x70]
00007fdcd91d1039  vmovaps xmm9, [rsp+0x80]
00007fdcd91d1042  vmovaps xmm10, [rsp+0x90]
00007fdcd91d104b  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d1054  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d105d  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d1066  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d106f  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d1078  add rsp, 0xF0
00007fdcd91d107f  pop r11
00007fdcd91d1081  pop r10
00007fdcd91d1083  pop r9
00007fdcd91d1085  pop r8
00007fdcd91d1087  pop rsi
00007fdcd91d1088  pop rdi
00007fdcd91d1089  pop rdx
00007fdcd91d108a  pop rcx
00007fdcd91d108b  pop rax
00007fdcd91d108c  add rsp, 0x08
00007fdcd91d1090  jmp 0x00007FDCD91CF732
00007fdcd91d1095  sub rsp, 0x08
00007fdcd91d1099  push rax
00007fdcd91d109a  push rcx
00007fdcd91d109b  push rdx
00007fdcd91d109c  push rdi
00007fdcd91d109d  push rsi
00007fdcd91d109e  push r8
00007fdcd91d10a0  push r9
00007fdcd91d10a2  push r10
00007fdcd91d10a4  push r11
00007fdcd91d10a6  sub rsp, 0xF0
00007fdcd91d10ad  vmovaps [rsp], xmm0
00007fdcd91d10b2  vmovaps [rsp+0x10], xmm1
00007fdcd91d10b8  vmovaps [rsp+0x20], xmm2
00007fdcd91d10be  vmovaps [rsp+0x30], xmm3
00007fdcd91d10c4  vmovaps [rsp+0x40], xmm4
00007fdcd91d10ca  vmovaps [rsp+0x50], xmm5
00007fdcd91d10d0  vmovaps [rsp+0x60], xmm6
00007fdcd91d10d6  vmovaps [rsp+0x70], xmm7
00007fdcd91d10dc  vmovaps [rsp+0x80], xmm8
00007fdcd91d10e5  vmovaps [rsp+0x90], xmm9
00007fdcd91d10ee  vmovaps [rsp+0xA0], xmm10
00007fdcd91d10f7  vmovaps [rsp+0xB0], xmm11
00007fdcd91d1100  vmovaps [rsp+0xC0], xmm12
00007fdcd91d1109  vmovaps [rsp+0xD0], xmm13
00007fdcd91d1112  vmovaps [rsp+0xE0], xmm14
00007fdcd91d111b  sub rsp, 0x30
00007fdcd91d111f  movaps [rsp], xmm15
00007fdcd91d1124  movaps [rsp+0x10], xmm10
00007fdcd91d112a  movaps [rsp+0x20], xmm12
00007fdcd91d1130  lea rdi, [rsp]
00007fdcd91d1134  mov esi, 0x00
00007fdcd91d1139  mov rax, 0x5B56EFBF3530
00007fdcd91d1143  call rax
00007fdcd91d1145  movaps xmm15, [rsp]
00007fdcd91d114a  add rsp, 0x30
00007fdcd91d114e  vmovaps xmm0, [rsp]
00007fdcd91d1153  vmovaps xmm1, [rsp+0x10]
00007fdcd91d1159  vmovaps xmm2, [rsp+0x20]
00007fdcd91d115f  vmovaps xmm3, [rsp+0x30]
00007fdcd91d1165  vmovaps xmm4, [rsp+0x40]
00007fdcd91d116b  vmovaps xmm5, [rsp+0x50]
00007fdcd91d1171  vmovaps xmm6, [rsp+0x60]
00007fdcd91d1177  vmovaps xmm7, [rsp+0x70]
00007fdcd91d117d  vmovaps xmm8, [rsp+0x80]
00007fdcd91d1186  vmovaps xmm9, [rsp+0x90]
00007fdcd91d118f  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d1198  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d11a1  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d11aa  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d11b3  vmovaps xmm14, [rsp+0xE0]
00007fdcd91d11bc  add rsp, 0xF0
00007fdcd91d11c3  pop r11
00007fdcd91d11c5  pop r10
00007fdcd91d11c7  pop r9
00007fdcd91d11c9  pop r8
00007fdcd91d11cb  pop rsi
00007fdcd91d11cc  pop rdi
00007fdcd91d11cd  pop rdx
00007fdcd91d11ce  pop rcx
00007fdcd91d11cf  pop rax
00007fdcd91d11d0  add rsp, 0x08
00007fdcd91d11d4  jmp 0x00007FDCD91CF75E
00007fdcd91d11d9  call 0x00007FDCD8FFF430
00007fdcd91d11de  jmp 0x00007FDCD91CF7EE
00007fdcd91d11e3  call 0x00007FDCD8FFF430
00007fdcd91d11e8  jmp 0x00007FDCD91CF801
00007fdcd91d11ed  sub rsp, 0x08
00007fdcd91d11f1  push rax
00007fdcd91d11f2  push rcx
00007fdcd91d11f3  push rdx
00007fdcd91d11f4  push rdi
00007fdcd91d11f5  push rsi
00007fdcd91d11f6  push r8
00007fdcd91d11f8  push r9
00007fdcd91d11fa  push r10
00007fdcd91d11fc  push r11
00007fdcd91d11fe  sub rsp, 0xF0
00007fdcd91d1205  vmovaps [rsp], xmm0
00007fdcd91d120a  vmovaps [rsp+0x10], xmm2
00007fdcd91d1210  vmovaps [rsp+0x20], xmm3
00007fdcd91d1216  vmovaps [rsp+0x30], xmm4
00007fdcd91d121c  vmovaps [rsp+0x40], xmm5
00007fdcd91d1222  vmovaps [rsp+0x50], xmm6
00007fdcd91d1228  vmovaps [rsp+0x60], xmm7
00007fdcd91d122e  vmovaps [rsp+0x70], xmm8
00007fdcd91d1234  vmovaps [rsp+0x80], xmm9
00007fdcd91d123d  vmovaps [rsp+0x90], xmm10
00007fdcd91d1246  vmovaps [rsp+0xA0], xmm11
00007fdcd91d124f  vmovaps [rsp+0xB0], xmm12
00007fdcd91d1258  vmovaps [rsp+0xC0], xmm13
00007fdcd91d1261  vmovaps [rsp+0xD0], xmm14
00007fdcd91d126a  vmovaps [rsp+0xE0], xmm15
00007fdcd91d1273  sub rsp, 0x30
00007fdcd91d1277  movaps [rsp], xmm1
00007fdcd91d127b  movaps [rsp+0x10], xmm13
00007fdcd91d1281  movaps [rsp+0x20], xmm2
00007fdcd91d1286  lea rdi, [rsp]
00007fdcd91d128a  mov esi, 0x00
00007fdcd91d128f  mov rax, 0x5B56EFBF3530
00007fdcd91d1299  call rax
00007fdcd91d129b  movaps xmm1, [rsp]
00007fdcd91d129f  add rsp, 0x30
00007fdcd91d12a3  vmovaps xmm0, [rsp]
00007fdcd91d12a8  vmovaps xmm2, [rsp+0x10]
00007fdcd91d12ae  vmovaps xmm3, [rsp+0x20]
00007fdcd91d12b4  vmovaps xmm4, [rsp+0x30]
00007fdcd91d12ba  vmovaps xmm5, [rsp+0x40]
00007fdcd91d12c0  vmovaps xmm6, [rsp+0x50]
00007fdcd91d12c6  vmovaps xmm7, [rsp+0x60]
00007fdcd91d12cc  vmovaps xmm8, [rsp+0x70]
00007fdcd91d12d2  vmovaps xmm9, [rsp+0x80]
00007fdcd91d12db  vmovaps xmm10, [rsp+0x90]
00007fdcd91d12e4  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d12ed  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d12f6  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d12ff  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d1308  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d1311  add rsp, 0xF0
00007fdcd91d1318  pop r11
00007fdcd91d131a  pop r10
00007fdcd91d131c  pop r9
00007fdcd91d131e  pop r8
00007fdcd91d1320  pop rsi
00007fdcd91d1321  pop rdi
00007fdcd91d1322  pop rdx
00007fdcd91d1323  pop rcx
00007fdcd91d1324  pop rax
00007fdcd91d1325  add rsp, 0x08
00007fdcd91d1329  jmp 0x00007FDCD91CF82C
00007fdcd91d132e  call 0x00007FDCD900E760
00007fdcd91d1333  jmp 0x00007FDCD91CF839
00007fdcd91d1338  sub rsp, 0x08
00007fdcd91d133c  push rax
00007fdcd91d133d  push rcx
00007fdcd91d133e  push rdx
00007fdcd91d133f  push rdi
00007fdcd91d1340  push rsi
00007fdcd91d1341  push r8
00007fdcd91d1343  push r9
00007fdcd91d1345  push r10
00007fdcd91d1347  push r11
00007fdcd91d1349  sub rsp, 0xF0
00007fdcd91d1350  vmovaps [rsp], xmm0
00007fdcd91d1355  vmovaps [rsp+0x10], xmm1
00007fdcd91d135b  vmovaps [rsp+0x20], xmm2
00007fdcd91d1361  vmovaps [rsp+0x30], xmm3
00007fdcd91d1367  vmovaps [rsp+0x40], xmm4
00007fdcd91d136d  vmovaps [rsp+0x50], xmm5
00007fdcd91d1373  vmovaps [rsp+0x60], xmm6
00007fdcd91d1379  vmovaps [rsp+0x70], xmm7
00007fdcd91d137f  vmovaps [rsp+0x80], xmm8
00007fdcd91d1388  vmovaps [rsp+0x90], xmm9
00007fdcd91d1391  vmovaps [rsp+0xA0], xmm10
00007fdcd91d139a  vmovaps [rsp+0xB0], xmm11
00007fdcd91d13a3  vmovaps [rsp+0xC0], xmm12
00007fdcd91d13ac  vmovaps [rsp+0xD0], xmm14
00007fdcd91d13b5  vmovaps [rsp+0xE0], xmm15
00007fdcd91d13be  sub rsp, 0x30
00007fdcd91d13c2  movaps [rsp], xmm13
00007fdcd91d13c7  movaps [rsp+0x10], xmm2
00007fdcd91d13cc  movaps [rsp+0x20], xmm1
00007fdcd91d13d1  lea rdi, [rsp]
00007fdcd91d13d5  mov esi, 0x00
00007fdcd91d13da  mov rax, 0x5B56EFBF3530
00007fdcd91d13e4  call rax
00007fdcd91d13e6  movaps xmm13, [rsp]
00007fdcd91d13eb  add rsp, 0x30
00007fdcd91d13ef  vmovaps xmm0, [rsp]
00007fdcd91d13f4  vmovaps xmm1, [rsp+0x10]
00007fdcd91d13fa  vmovaps xmm2, [rsp+0x20]
00007fdcd91d1400  vmovaps xmm3, [rsp+0x30]
00007fdcd91d1406  vmovaps xmm4, [rsp+0x40]
00007fdcd91d140c  vmovaps xmm5, [rsp+0x50]
00007fdcd91d1412  vmovaps xmm6, [rsp+0x60]
00007fdcd91d1418  vmovaps xmm7, [rsp+0x70]
00007fdcd91d141e  vmovaps xmm8, [rsp+0x80]
00007fdcd91d1427  vmovaps xmm9, [rsp+0x90]
00007fdcd91d1430  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d1439  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d1442  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d144b  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d1454  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d145d  add rsp, 0xF0
00007fdcd91d1464  pop r11
00007fdcd91d1466  pop r10
00007fdcd91d1468  pop r9
00007fdcd91d146a  pop r8
00007fdcd91d146c  pop rsi
00007fdcd91d146d  pop rdi
00007fdcd91d146e  pop rdx
00007fdcd91d146f  pop rcx
00007fdcd91d1470  pop rax
00007fdcd91d1471  add rsp, 0x08
00007fdcd91d1475  jmp 0x00007FDCD91CF878
00007fdcd91d147a  sub rsp, 0x08
00007fdcd91d147e  push rax
00007fdcd91d147f  push rcx
00007fdcd91d1480  push rdx
00007fdcd91d1481  push rdi
00007fdcd91d1482  push rsi
00007fdcd91d1483  push r8
00007fdcd91d1485  push r9
00007fdcd91d1487  push r10
00007fdcd91d1489  push r11
00007fdcd91d148b  sub rsp, 0xF0
00007fdcd91d1492  vmovaps [rsp], xmm0
00007fdcd91d1497  vmovaps [rsp+0x10], xmm2
00007fdcd91d149d  vmovaps [rsp+0x20], xmm3
00007fdcd91d14a3  vmovaps [rsp+0x30], xmm4
00007fdcd91d14a9  vmovaps [rsp+0x40], xmm5
00007fdcd91d14af  vmovaps [rsp+0x50], xmm6
00007fdcd91d14b5  vmovaps [rsp+0x60], xmm7
00007fdcd91d14bb  vmovaps [rsp+0x70], xmm8
00007fdcd91d14c1  vmovaps [rsp+0x80], xmm9
00007fdcd91d14ca  vmovaps [rsp+0x90], xmm10
00007fdcd91d14d3  vmovaps [rsp+0xA0], xmm11
00007fdcd91d14dc  vmovaps [rsp+0xB0], xmm12
00007fdcd91d14e5  vmovaps [rsp+0xC0], xmm13
00007fdcd91d14ee  vmovaps [rsp+0xD0], xmm14
00007fdcd91d14f7  vmovaps [rsp+0xE0], xmm15
00007fdcd91d1500  sub rsp, 0x30
00007fdcd91d1504  movaps [rsp], xmm1
00007fdcd91d1508  movaps [rsp+0x10], xmm15
00007fdcd91d150e  movaps [rsp+0x20], xmm2
00007fdcd91d1513  lea rdi, [rsp]
00007fdcd91d1517  mov esi, 0x00
00007fdcd91d151c  mov rax, 0x5B56EFBF3530
00007fdcd91d1526  call rax
00007fdcd91d1528  movaps xmm1, [rsp]
00007fdcd91d152c  add rsp, 0x30
00007fdcd91d1530  vmovaps xmm0, [rsp]
00007fdcd91d1535  vmovaps xmm2, [rsp+0x10]
00007fdcd91d153b  vmovaps xmm3, [rsp+0x20]
00007fdcd91d1541  vmovaps xmm4, [rsp+0x30]
00007fdcd91d1547  vmovaps xmm5, [rsp+0x40]
00007fdcd91d154d  vmovaps xmm6, [rsp+0x50]
00007fdcd91d1553  vmovaps xmm7, [rsp+0x60]
00007fdcd91d1559  vmovaps xmm8, [rsp+0x70]
00007fdcd91d155f  vmovaps xmm9, [rsp+0x80]
00007fdcd91d1568  vmovaps xmm10, [rsp+0x90]
00007fdcd91d1571  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d157a  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d1583  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d158c  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d1595  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d159e  add rsp, 0xF0
00007fdcd91d15a5  pop r11
00007fdcd91d15a7  pop r10
00007fdcd91d15a9  pop r9
00007fdcd91d15ab  pop r8
00007fdcd91d15ad  pop rsi
00007fdcd91d15ae  pop rdi
00007fdcd91d15af  pop rdx
00007fdcd91d15b0  pop rcx
00007fdcd91d15b1  pop rax
00007fdcd91d15b2  add rsp, 0x08
00007fdcd91d15b6  jmp 0x00007FDCD91CF8AC
00007fdcd91d15bb  sub rsp, 0x08
00007fdcd91d15bf  push rax
00007fdcd91d15c0  push rcx
00007fdcd91d15c1  push rdx
00007fdcd91d15c2  push rdi
00007fdcd91d15c3  push rsi
00007fdcd91d15c4  push r8
00007fdcd91d15c6  push r9
00007fdcd91d15c8  push r10
00007fdcd91d15ca  push r11
00007fdcd91d15cc  sub rsp, 0xF0
00007fdcd91d15d3  vmovaps [rsp], xmm0
00007fdcd91d15d8  vmovaps [rsp+0x10], xmm1
00007fdcd91d15de  vmovaps [rsp+0x20], xmm2
00007fdcd91d15e4  vmovaps [rsp+0x30], xmm3
00007fdcd91d15ea  vmovaps [rsp+0x40], xmm4
00007fdcd91d15f0  vmovaps [rsp+0x50], xmm5
00007fdcd91d15f6  vmovaps [rsp+0x60], xmm6
00007fdcd91d15fc  vmovaps [rsp+0x70], xmm7
00007fdcd91d1602  vmovaps [rsp+0x80], xmm8
00007fdcd91d160b  vmovaps [rsp+0x90], xmm9
00007fdcd91d1614  vmovaps [rsp+0xA0], xmm10
00007fdcd91d161d  vmovaps [rsp+0xB0], xmm11
00007fdcd91d1626  vmovaps [rsp+0xC0], xmm12
00007fdcd91d162f  vmovaps [rsp+0xD0], xmm13
00007fdcd91d1638  vmovaps [rsp+0xE0], xmm15
00007fdcd91d1641  sub rsp, 0x30
00007fdcd91d1645  movaps [rsp], xmm14
00007fdcd91d164a  movaps [rsp+0x10], xmm2
00007fdcd91d164f  movaps [rsp+0x20], xmm15
00007fdcd91d1655  lea rdi, [rsp]
00007fdcd91d1659  mov esi, 0x00
00007fdcd91d165e  mov rax, 0x5B56EFBF3530
00007fdcd91d1668  call rax
00007fdcd91d166a  movaps xmm14, [rsp]
00007fdcd91d166f  add rsp, 0x30
00007fdcd91d1673  vmovaps xmm0, [rsp]
00007fdcd91d1678  vmovaps xmm1, [rsp+0x10]
00007fdcd91d167e  vmovaps xmm2, [rsp+0x20]
00007fdcd91d1684  vmovaps xmm3, [rsp+0x30]
00007fdcd91d168a  vmovaps xmm4, [rsp+0x40]
00007fdcd91d1690  vmovaps xmm5, [rsp+0x50]
00007fdcd91d1696  vmovaps xmm6, [rsp+0x60]
00007fdcd91d169c  vmovaps xmm7, [rsp+0x70]
00007fdcd91d16a2  vmovaps xmm8, [rsp+0x80]
00007fdcd91d16ab  vmovaps xmm9, [rsp+0x90]
00007fdcd91d16b4  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d16bd  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d16c6  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d16cf  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d16d8  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d16e1  add rsp, 0xF0
00007fdcd91d16e8  pop r11
00007fdcd91d16ea  pop r10
00007fdcd91d16ec  pop r9
00007fdcd91d16ee  pop r8
00007fdcd91d16f0  pop rsi
00007fdcd91d16f1  pop rdi
00007fdcd91d16f2  pop rdx
00007fdcd91d16f3  pop rcx
00007fdcd91d16f4  pop rax
00007fdcd91d16f5  add rsp, 0x08
00007fdcd91d16f9  jmp 0x00007FDCD91CF8E7
00007fdcd91d16fe  sub rsp, 0x08
00007fdcd91d1702  push rax
00007fdcd91d1703  push rcx
00007fdcd91d1704  push rdx
00007fdcd91d1705  push rdi
00007fdcd91d1706  push rsi
00007fdcd91d1707  push r8
00007fdcd91d1709  push r9
00007fdcd91d170b  push r10
00007fdcd91d170d  push r11
00007fdcd91d170f  sub rsp, 0xF0
00007fdcd91d1716  vmovaps [rsp], xmm0
00007fdcd91d171b  vmovaps [rsp+0x10], xmm1
00007fdcd91d1721  vmovaps [rsp+0x20], xmm2
00007fdcd91d1727  vmovaps [rsp+0x30], xmm3
00007fdcd91d172d  vmovaps [rsp+0x40], xmm4
00007fdcd91d1733  vmovaps [rsp+0x50], xmm5
00007fdcd91d1739  vmovaps [rsp+0x60], xmm6
00007fdcd91d173f  vmovaps [rsp+0x70], xmm7
00007fdcd91d1745  vmovaps [rsp+0x80], xmm8
00007fdcd91d174e  vmovaps [rsp+0x90], xmm9
00007fdcd91d1757  vmovaps [rsp+0xA0], xmm10
00007fdcd91d1760  vmovaps [rsp+0xB0], xmm11
00007fdcd91d1769  vmovaps [rsp+0xC0], xmm12
00007fdcd91d1772  vmovaps [rsp+0xD0], xmm13
00007fdcd91d177b  vmovaps [rsp+0xE0], xmm14
00007fdcd91d1784  sub rsp, 0x30
00007fdcd91d1788  movaps [rsp], xmm15
00007fdcd91d178d  movaps [rsp+0x10], xmm2
00007fdcd91d1792  movaps [rsp+0x20], xmm1
00007fdcd91d1797  lea rdi, [rsp]
00007fdcd91d179b  mov esi, 0x00
00007fdcd91d17a0  mov rax, 0x5B56EFBF3530
00007fdcd91d17aa  call rax
00007fdcd91d17ac  movaps xmm15, [rsp]
00007fdcd91d17b1  add rsp, 0x30
00007fdcd91d17b5  vmovaps xmm0, [rsp]
00007fdcd91d17ba  vmovaps xmm1, [rsp+0x10]
00007fdcd91d17c0  vmovaps xmm2, [rsp+0x20]
00007fdcd91d17c6  vmovaps xmm3, [rsp+0x30]
00007fdcd91d17cc  vmovaps xmm4, [rsp+0x40]
00007fdcd91d17d2  vmovaps xmm5, [rsp+0x50]
00007fdcd91d17d8  vmovaps xmm6, [rsp+0x60]
00007fdcd91d17de  vmovaps xmm7, [rsp+0x70]
00007fdcd91d17e4  vmovaps xmm8, [rsp+0x80]
00007fdcd91d17ed  vmovaps xmm9, [rsp+0x90]
00007fdcd91d17f6  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d17ff  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d1808  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d1811  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d181a  vmovaps xmm14, [rsp+0xE0]
00007fdcd91d1823  add rsp, 0xF0
00007fdcd91d182a  pop r11
00007fdcd91d182c  pop r10
00007fdcd91d182e  pop r9
00007fdcd91d1830  pop r8
00007fdcd91d1832  pop rsi
00007fdcd91d1833  pop rdi
00007fdcd91d1834  pop rdx
00007fdcd91d1835  pop rcx
00007fdcd91d1836  pop rax
00007fdcd91d1837  add rsp, 0x08
00007fdcd91d183b  jmp 0x00007FDCD91CF923
00007fdcd91d1840  call 0x00007FDCD8FFF430
00007fdcd91d1845  jmp 0x00007FDCD91CF930
00007fdcd91d184a  sub rsp, 0x08
00007fdcd91d184e  push rax
00007fdcd91d184f  push rcx
00007fdcd91d1850  push rdx
00007fdcd91d1851  push rdi
00007fdcd91d1852  push rsi
00007fdcd91d1853  push r8
00007fdcd91d1855  push r9
00007fdcd91d1857  push r10
00007fdcd91d1859  push r11
00007fdcd91d185b  sub rsp, 0xF0
00007fdcd91d1862  vmovaps [rsp], xmm0
00007fdcd91d1867  vmovaps [rsp+0x10], xmm1
00007fdcd91d186d  vmovaps [rsp+0x20], xmm3
00007fdcd91d1873  vmovaps [rsp+0x30], xmm4
00007fdcd91d1879  vmovaps [rsp+0x40], xmm5
00007fdcd91d187f  vmovaps [rsp+0x50], xmm6
00007fdcd91d1885  vmovaps [rsp+0x60], xmm7
00007fdcd91d188b  vmovaps [rsp+0x70], xmm8
00007fdcd91d1891  vmovaps [rsp+0x80], xmm9
00007fdcd91d189a  vmovaps [rsp+0x90], xmm10
00007fdcd91d18a3  vmovaps [rsp+0xA0], xmm11
00007fdcd91d18ac  vmovaps [rsp+0xB0], xmm12
00007fdcd91d18b5  vmovaps [rsp+0xC0], xmm13
00007fdcd91d18be  vmovaps [rsp+0xD0], xmm14
00007fdcd91d18c7  vmovaps [rsp+0xE0], xmm15
00007fdcd91d18d0  sub rsp, 0x30
00007fdcd91d18d4  movaps [rsp], xmm2
00007fdcd91d18d8  movaps [rsp+0x10], xmm1
00007fdcd91d18dd  movaps [rsp+0x20], xmm14
00007fdcd91d18e3  lea rdi, [rsp]
00007fdcd91d18e7  mov esi, 0x00
00007fdcd91d18ec  mov rax, 0x5B56EFBF3530
00007fdcd91d18f6  call rax
00007fdcd91d18f8  movaps xmm2, [rsp]
00007fdcd91d18fc  add rsp, 0x30
00007fdcd91d1900  vmovaps xmm0, [rsp]
00007fdcd91d1905  vmovaps xmm1, [rsp+0x10]
00007fdcd91d190b  vmovaps xmm3, [rsp+0x20]
00007fdcd91d1911  vmovaps xmm4, [rsp+0x30]
00007fdcd91d1917  vmovaps xmm5, [rsp+0x40]
00007fdcd91d191d  vmovaps xmm6, [rsp+0x50]
00007fdcd91d1923  vmovaps xmm7, [rsp+0x60]
00007fdcd91d1929  vmovaps xmm8, [rsp+0x70]
00007fdcd91d192f  vmovaps xmm9, [rsp+0x80]
00007fdcd91d1938  vmovaps xmm10, [rsp+0x90]
00007fdcd91d1941  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d194a  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d1953  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d195c  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d1965  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d196e  add rsp, 0xF0
00007fdcd91d1975  pop r11
00007fdcd91d1977  pop r10
00007fdcd91d1979  pop r9
00007fdcd91d197b  pop r8
00007fdcd91d197d  pop rsi
00007fdcd91d197e  pop rdi
00007fdcd91d197f  pop rdx
00007fdcd91d1980  pop rcx
00007fdcd91d1981  pop rax
00007fdcd91d1982  add rsp, 0x08
00007fdcd91d1986  jmp 0x00007FDCD91CF96D
00007fdcd91d198b  sub rsp, 0x08
00007fdcd91d198f  push rax
00007fdcd91d1990  push rcx
00007fdcd91d1991  push rdx
00007fdcd91d1992  push rdi
00007fdcd91d1993  push rsi
00007fdcd91d1994  push r8
00007fdcd91d1996  push r9
00007fdcd91d1998  push r10
00007fdcd91d199a  push r11
00007fdcd91d199c  sub rsp, 0xF0
00007fdcd91d19a3  vmovaps [rsp], xmm0
00007fdcd91d19a8  vmovaps [rsp+0x10], xmm1
00007fdcd91d19ae  vmovaps [rsp+0x20], xmm2
00007fdcd91d19b4  vmovaps [rsp+0x30], xmm3
00007fdcd91d19ba  vmovaps [rsp+0x40], xmm4
00007fdcd91d19c0  vmovaps [rsp+0x50], xmm5
00007fdcd91d19c6  vmovaps [rsp+0x60], xmm6
00007fdcd91d19cc  vmovaps [rsp+0x70], xmm7
00007fdcd91d19d2  vmovaps [rsp+0x80], xmm8
00007fdcd91d19db  vmovaps [rsp+0x90], xmm9
00007fdcd91d19e4  vmovaps [rsp+0xA0], xmm10
00007fdcd91d19ed  vmovaps [rsp+0xB0], xmm11
00007fdcd91d19f6  vmovaps [rsp+0xC0], xmm12
00007fdcd91d19ff  vmovaps [rsp+0xD0], xmm13
00007fdcd91d1a08  vmovaps [rsp+0xE0], xmm14
00007fdcd91d1a11  sub rsp, 0x30
00007fdcd91d1a15  movaps [rsp], xmm15
00007fdcd91d1a1a  movaps [rsp+0x10], xmm14
00007fdcd91d1a20  movaps [rsp+0x20], xmm1
00007fdcd91d1a25  lea rdi, [rsp]
00007fdcd91d1a29  mov esi, 0x00
00007fdcd91d1a2e  mov rax, 0x5B56EFBF3530
00007fdcd91d1a38  call rax
00007fdcd91d1a3a  movaps xmm15, [rsp]
00007fdcd91d1a3f  add rsp, 0x30
00007fdcd91d1a43  vmovaps xmm0, [rsp]
00007fdcd91d1a48  vmovaps xmm1, [rsp+0x10]
00007fdcd91d1a4e  vmovaps xmm2, [rsp+0x20]
00007fdcd91d1a54  vmovaps xmm3, [rsp+0x30]
00007fdcd91d1a5a  vmovaps xmm4, [rsp+0x40]
00007fdcd91d1a60  vmovaps xmm5, [rsp+0x50]
00007fdcd91d1a66  vmovaps xmm6, [rsp+0x60]
00007fdcd91d1a6c  vmovaps xmm7, [rsp+0x70]
00007fdcd91d1a72  vmovaps xmm8, [rsp+0x80]
00007fdcd91d1a7b  vmovaps xmm9, [rsp+0x90]
00007fdcd91d1a84  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d1a8d  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d1a96  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d1a9f  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d1aa8  vmovaps xmm14, [rsp+0xE0]
00007fdcd91d1ab1  add rsp, 0xF0
00007fdcd91d1ab8  pop r11
00007fdcd91d1aba  pop r10
00007fdcd91d1abc  pop r9
00007fdcd91d1abe  pop r8
00007fdcd91d1ac0  pop rsi
00007fdcd91d1ac1  pop rdi
00007fdcd91d1ac2  pop rdx
00007fdcd91d1ac3  pop rcx
00007fdcd91d1ac4  pop rax
00007fdcd91d1ac5  add rsp, 0x08
00007fdcd91d1ac9  jmp 0x00007FDCD91CF9E7
00007fdcd91d1ace  call 0x00007FDCD8FFF430
00007fdcd91d1ad3  jmp 0x00007FDCD91CF9F4
00007fdcd91d1ad8  sub rsp, 0x08
00007fdcd91d1adc  push rax
00007fdcd91d1add  push rcx
00007fdcd91d1ade  push rdx
00007fdcd91d1adf  push rdi
00007fdcd91d1ae0  push rsi
00007fdcd91d1ae1  push r8
00007fdcd91d1ae3  push r9
00007fdcd91d1ae5  push r10
00007fdcd91d1ae7  push r11
00007fdcd91d1ae9  sub rsp, 0xF0
00007fdcd91d1af0  vmovaps [rsp], xmm0
00007fdcd91d1af5  vmovaps [rsp+0x10], xmm1
00007fdcd91d1afb  vmovaps [rsp+0x20], xmm2
00007fdcd91d1b01  vmovaps [rsp+0x30], xmm3
00007fdcd91d1b07  vmovaps [rsp+0x40], xmm4
00007fdcd91d1b0d  vmovaps [rsp+0x50], xmm5
00007fdcd91d1b13  vmovaps [rsp+0x60], xmm6
00007fdcd91d1b19  vmovaps [rsp+0x70], xmm7
00007fdcd91d1b1f  vmovaps [rsp+0x80], xmm8
00007fdcd91d1b28  vmovaps [rsp+0x90], xmm9
00007fdcd91d1b31  vmovaps [rsp+0xA0], xmm10
00007fdcd91d1b3a  vmovaps [rsp+0xB0], xmm11
00007fdcd91d1b43  vmovaps [rsp+0xC0], xmm12
00007fdcd91d1b4c  vmovaps [rsp+0xD0], xmm13
00007fdcd91d1b55  vmovaps [rsp+0xE0], xmm15
00007fdcd91d1b5e  sub rsp, 0x30
00007fdcd91d1b62  movaps [rsp], xmm14
00007fdcd91d1b67  movaps [rsp+0x10], xmm13
00007fdcd91d1b6d  movaps [rsp+0x20], xmm1
00007fdcd91d1b72  lea rdi, [rsp]
00007fdcd91d1b76  mov esi, 0x00
00007fdcd91d1b7b  mov rax, 0x5B56EFBF3530
00007fdcd91d1b85  call rax
00007fdcd91d1b87  movaps xmm14, [rsp]
00007fdcd91d1b8c  add rsp, 0x30
00007fdcd91d1b90  vmovaps xmm0, [rsp]
00007fdcd91d1b95  vmovaps xmm1, [rsp+0x10]
00007fdcd91d1b9b  vmovaps xmm2, [rsp+0x20]
00007fdcd91d1ba1  vmovaps xmm3, [rsp+0x30]
00007fdcd91d1ba7  vmovaps xmm4, [rsp+0x40]
00007fdcd91d1bad  vmovaps xmm5, [rsp+0x50]
00007fdcd91d1bb3  vmovaps xmm6, [rsp+0x60]
00007fdcd91d1bb9  vmovaps xmm7, [rsp+0x70]
00007fdcd91d1bbf  vmovaps xmm8, [rsp+0x80]
00007fdcd91d1bc8  vmovaps xmm9, [rsp+0x90]
00007fdcd91d1bd1  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d1bda  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d1be3  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d1bec  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d1bf5  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d1bfe  add rsp, 0xF0
00007fdcd91d1c05  pop r11
00007fdcd91d1c07  pop r10
00007fdcd91d1c09  pop r9
00007fdcd91d1c0b  pop r8
00007fdcd91d1c0d  pop rsi
00007fdcd91d1c0e  pop rdi
00007fdcd91d1c0f  pop rdx
00007fdcd91d1c10  pop rcx
00007fdcd91d1c11  pop rax
00007fdcd91d1c12  add rsp, 0x08
00007fdcd91d1c16  jmp 0x00007FDCD91CFAAF
00007fdcd91d1c1b  sub rsp, 0x08
00007fdcd91d1c1f  push rax
00007fdcd91d1c20  push rcx
00007fdcd91d1c21  push rdx
00007fdcd91d1c22  push rdi
00007fdcd91d1c23  push rsi
00007fdcd91d1c24  push r8
00007fdcd91d1c26  push r9
00007fdcd91d1c28  push r10
00007fdcd91d1c2a  push r11
00007fdcd91d1c2c  sub rsp, 0xF0
00007fdcd91d1c33  vmovaps [rsp], xmm0
00007fdcd91d1c38  vmovaps [rsp+0x10], xmm1
00007fdcd91d1c3e  vmovaps [rsp+0x20], xmm2
00007fdcd91d1c44  vmovaps [rsp+0x30], xmm3
00007fdcd91d1c4a  vmovaps [rsp+0x40], xmm4
00007fdcd91d1c50  vmovaps [rsp+0x50], xmm5
00007fdcd91d1c56  vmovaps [rsp+0x60], xmm6
00007fdcd91d1c5c  vmovaps [rsp+0x70], xmm7
00007fdcd91d1c62  vmovaps [rsp+0x80], xmm8
00007fdcd91d1c6b  vmovaps [rsp+0x90], xmm9
00007fdcd91d1c74  vmovaps [rsp+0xA0], xmm10
00007fdcd91d1c7d  vmovaps [rsp+0xB0], xmm11
00007fdcd91d1c86  vmovaps [rsp+0xC0], xmm12
00007fdcd91d1c8f  vmovaps [rsp+0xD0], xmm13
00007fdcd91d1c98  vmovaps [rsp+0xE0], xmm14
00007fdcd91d1ca1  sub rsp, 0x30
00007fdcd91d1ca5  movaps [rsp], xmm15
00007fdcd91d1caa  movaps [rsp+0x10], xmm13
00007fdcd91d1cb0  movaps [rsp+0x20], xmm1
00007fdcd91d1cb5  lea rdi, [rsp]
00007fdcd91d1cb9  mov esi, 0x00
00007fdcd91d1cbe  mov rax, 0x5B56EFBF3530
00007fdcd91d1cc8  call rax
00007fdcd91d1cca  movaps xmm15, [rsp]
00007fdcd91d1ccf  add rsp, 0x30
00007fdcd91d1cd3  vmovaps xmm0, [rsp]
00007fdcd91d1cd8  vmovaps xmm1, [rsp+0x10]
00007fdcd91d1cde  vmovaps xmm2, [rsp+0x20]
00007fdcd91d1ce4  vmovaps xmm3, [rsp+0x30]
00007fdcd91d1cea  vmovaps xmm4, [rsp+0x40]
00007fdcd91d1cf0  vmovaps xmm5, [rsp+0x50]
00007fdcd91d1cf6  vmovaps xmm6, [rsp+0x60]
00007fdcd91d1cfc  vmovaps xmm7, [rsp+0x70]
00007fdcd91d1d02  vmovaps xmm8, [rsp+0x80]
00007fdcd91d1d0b  vmovaps xmm9, [rsp+0x90]
00007fdcd91d1d14  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d1d1d  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d1d26  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d1d2f  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d1d38  vmovaps xmm14, [rsp+0xE0]
00007fdcd91d1d41  add rsp, 0xF0
00007fdcd91d1d48  pop r11
00007fdcd91d1d4a  pop r10
00007fdcd91d1d4c  pop r9
00007fdcd91d1d4e  pop r8
00007fdcd91d1d50  pop rsi
00007fdcd91d1d51  pop rdi
00007fdcd91d1d52  pop rdx
00007fdcd91d1d53  pop rcx
00007fdcd91d1d54  pop rax
00007fdcd91d1d55  add rsp, 0x08
00007fdcd91d1d59  jmp 0x00007FDCD91CFAEB
00007fdcd91d1d5e  call 0x00007FDCD8FFF430
00007fdcd91d1d63  jmp 0x00007FDCD91CFAF8
00007fdcd91d1d68  sub rsp, 0x08
00007fdcd91d1d6c  push rax
00007fdcd91d1d6d  push rcx
00007fdcd91d1d6e  push rdx
00007fdcd91d1d6f  push rdi
00007fdcd91d1d70  push rsi
00007fdcd91d1d71  push r8
00007fdcd91d1d73  push r9
00007fdcd91d1d75  push r10
00007fdcd91d1d77  push r11
00007fdcd91d1d79  sub rsp, 0xF0
00007fdcd91d1d80  vmovaps [rsp], xmm0
00007fdcd91d1d85  vmovaps [rsp+0x10], xmm1
00007fdcd91d1d8b  vmovaps [rsp+0x20], xmm2
00007fdcd91d1d91  vmovaps [rsp+0x30], xmm3
00007fdcd91d1d97  vmovaps [rsp+0x40], xmm4
00007fdcd91d1d9d  vmovaps [rsp+0x50], xmm5
00007fdcd91d1da3  vmovaps [rsp+0x60], xmm6
00007fdcd91d1da9  vmovaps [rsp+0x70], xmm7
00007fdcd91d1daf  vmovaps [rsp+0x80], xmm8
00007fdcd91d1db8  vmovaps [rsp+0x90], xmm9
00007fdcd91d1dc1  vmovaps [rsp+0xA0], xmm10
00007fdcd91d1dca  vmovaps [rsp+0xB0], xmm11
00007fdcd91d1dd3  vmovaps [rsp+0xC0], xmm12
00007fdcd91d1ddc  vmovaps [rsp+0xD0], xmm13
00007fdcd91d1de5  vmovaps [rsp+0xE0], xmm15
00007fdcd91d1dee  sub rsp, 0x30
00007fdcd91d1df2  movaps [rsp], xmm14
00007fdcd91d1df7  movaps [rsp+0x10], xmm13
00007fdcd91d1dfd  movaps [rsp+0x20], xmm2
00007fdcd91d1e02  lea rdi, [rsp]
00007fdcd91d1e06  mov esi, 0x00
00007fdcd91d1e0b  mov rax, 0x5B56EFBF3530
00007fdcd91d1e15  call rax
00007fdcd91d1e17  movaps xmm14, [rsp]
00007fdcd91d1e1c  add rsp, 0x30
00007fdcd91d1e20  vmovaps xmm0, [rsp]
00007fdcd91d1e25  vmovaps xmm1, [rsp+0x10]
00007fdcd91d1e2b  vmovaps xmm2, [rsp+0x20]
00007fdcd91d1e31  vmovaps xmm3, [rsp+0x30]
00007fdcd91d1e37  vmovaps xmm4, [rsp+0x40]
00007fdcd91d1e3d  vmovaps xmm5, [rsp+0x50]
00007fdcd91d1e43  vmovaps xmm6, [rsp+0x60]
00007fdcd91d1e49  vmovaps xmm7, [rsp+0x70]
00007fdcd91d1e4f  vmovaps xmm8, [rsp+0x80]
00007fdcd91d1e58  vmovaps xmm9, [rsp+0x90]
00007fdcd91d1e61  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d1e6a  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d1e73  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d1e7c  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d1e85  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d1e8e  add rsp, 0xF0
00007fdcd91d1e95  pop r11
00007fdcd91d1e97  pop r10
00007fdcd91d1e99  pop r9
00007fdcd91d1e9b  pop r8
00007fdcd91d1e9d  pop rsi
00007fdcd91d1e9e  pop rdi
00007fdcd91d1e9f  pop rdx
00007fdcd91d1ea0  pop rcx
00007fdcd91d1ea1  pop rax
00007fdcd91d1ea2  add rsp, 0x08
00007fdcd91d1ea6  jmp 0x00007FDCD91CFB24
00007fdcd91d1eab  sub rsp, 0x08
00007fdcd91d1eaf  push rax
00007fdcd91d1eb0  push rcx
00007fdcd91d1eb1  push rdx
00007fdcd91d1eb2  push rdi
00007fdcd91d1eb3  push rsi
00007fdcd91d1eb4  push r8
00007fdcd91d1eb6  push r9
00007fdcd91d1eb8  push r10
00007fdcd91d1eba  push r11
00007fdcd91d1ebc  sub rsp, 0xF0
00007fdcd91d1ec3  vmovaps [rsp], xmm0
00007fdcd91d1ec8  vmovaps [rsp+0x10], xmm2
00007fdcd91d1ece  vmovaps [rsp+0x20], xmm3
00007fdcd91d1ed4  vmovaps [rsp+0x30], xmm4
00007fdcd91d1eda  vmovaps [rsp+0x40], xmm5
00007fdcd91d1ee0  vmovaps [rsp+0x50], xmm6
00007fdcd91d1ee6  vmovaps [rsp+0x60], xmm7
00007fdcd91d1eec  vmovaps [rsp+0x70], xmm8
00007fdcd91d1ef2  vmovaps [rsp+0x80], xmm9
00007fdcd91d1efb  vmovaps [rsp+0x90], xmm10
00007fdcd91d1f04  vmovaps [rsp+0xA0], xmm11
00007fdcd91d1f0d  vmovaps [rsp+0xB0], xmm12
00007fdcd91d1f16  vmovaps [rsp+0xC0], xmm13
00007fdcd91d1f1f  vmovaps [rsp+0xD0], xmm14
00007fdcd91d1f28  vmovaps [rsp+0xE0], xmm15
00007fdcd91d1f31  sub rsp, 0x30
00007fdcd91d1f35  movaps [rsp], xmm1
00007fdcd91d1f39  movaps [rsp+0x10], xmm13
00007fdcd91d1f3f  movaps [rsp+0x20], xmm2
00007fdcd91d1f44  lea rdi, [rsp]
00007fdcd91d1f48  mov esi, 0x00
00007fdcd91d1f4d  mov rax, 0x5B56EFBF3530
00007fdcd91d1f57  call rax
00007fdcd91d1f59  movaps xmm1, [rsp]
00007fdcd91d1f5d  add rsp, 0x30
00007fdcd91d1f61  vmovaps xmm0, [rsp]
00007fdcd91d1f66  vmovaps xmm2, [rsp+0x10]
00007fdcd91d1f6c  vmovaps xmm3, [rsp+0x20]
00007fdcd91d1f72  vmovaps xmm4, [rsp+0x30]
00007fdcd91d1f78  vmovaps xmm5, [rsp+0x40]
00007fdcd91d1f7e  vmovaps xmm6, [rsp+0x50]
00007fdcd91d1f84  vmovaps xmm7, [rsp+0x60]
00007fdcd91d1f8a  vmovaps xmm8, [rsp+0x70]
00007fdcd91d1f90  vmovaps xmm9, [rsp+0x80]
00007fdcd91d1f99  vmovaps xmm10, [rsp+0x90]
00007fdcd91d1fa2  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d1fab  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d1fb4  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d1fbd  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d1fc6  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d1fcf  add rsp, 0xF0
00007fdcd91d1fd6  pop r11
00007fdcd91d1fd8  pop r10
00007fdcd91d1fda  pop r9
00007fdcd91d1fdc  pop r8
00007fdcd91d1fde  pop rsi
00007fdcd91d1fdf  pop rdi
00007fdcd91d1fe0  pop rdx
00007fdcd91d1fe1  pop rcx
00007fdcd91d1fe2  pop rax
00007fdcd91d1fe3  add rsp, 0x08
00007fdcd91d1fe7  jmp 0x00007FDCD91CFB52
00007fdcd91d1fec  sub rsp, 0x08
00007fdcd91d1ff0  push rax
00007fdcd91d1ff1  push rcx
00007fdcd91d1ff2  push rdx
00007fdcd91d1ff3  push rdi
00007fdcd91d1ff4  push rsi
00007fdcd91d1ff5  push r8
00007fdcd91d1ff7  push r9
00007fdcd91d1ff9  push r10
00007fdcd91d1ffb  push r11
00007fdcd91d1ffd  sub rsp, 0xF0
00007fdcd91d2004  vmovaps [rsp], xmm0
00007fdcd91d2009  vmovaps [rsp+0x10], xmm1
00007fdcd91d200f  vmovaps [rsp+0x20], xmm3
00007fdcd91d2015  vmovaps [rsp+0x30], xmm4
00007fdcd91d201b  vmovaps [rsp+0x40], xmm5
00007fdcd91d2021  vmovaps [rsp+0x50], xmm6
00007fdcd91d2027  vmovaps [rsp+0x60], xmm7
00007fdcd91d202d  vmovaps [rsp+0x70], xmm8
00007fdcd91d2033  vmovaps [rsp+0x80], xmm9
00007fdcd91d203c  vmovaps [rsp+0x90], xmm10
00007fdcd91d2045  vmovaps [rsp+0xA0], xmm11
00007fdcd91d204e  vmovaps [rsp+0xB0], xmm12
00007fdcd91d2057  vmovaps [rsp+0xC0], xmm13
00007fdcd91d2060  vmovaps [rsp+0xD0], xmm14
00007fdcd91d2069  vmovaps [rsp+0xE0], xmm15
00007fdcd91d2072  sub rsp, 0x30
00007fdcd91d2076  movaps [rsp], xmm2
00007fdcd91d207a  movaps [rsp+0x10], xmm1
00007fdcd91d207f  movaps [rsp+0x20], xmm13
00007fdcd91d2085  lea rdi, [rsp]
00007fdcd91d2089  mov esi, 0x00
00007fdcd91d208e  mov rax, 0x5B56EFBF3530
00007fdcd91d2098  call rax
00007fdcd91d209a  movaps xmm2, [rsp]
00007fdcd91d209e  add rsp, 0x30
00007fdcd91d20a2  vmovaps xmm0, [rsp]
00007fdcd91d20a7  vmovaps xmm1, [rsp+0x10]
00007fdcd91d20ad  vmovaps xmm3, [rsp+0x20]
00007fdcd91d20b3  vmovaps xmm4, [rsp+0x30]
00007fdcd91d20b9  vmovaps xmm5, [rsp+0x40]
00007fdcd91d20bf  vmovaps xmm6, [rsp+0x50]
00007fdcd91d20c5  vmovaps xmm7, [rsp+0x60]
00007fdcd91d20cb  vmovaps xmm8, [rsp+0x70]
00007fdcd91d20d1  vmovaps xmm9, [rsp+0x80]
00007fdcd91d20da  vmovaps xmm10, [rsp+0x90]
00007fdcd91d20e3  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d20ec  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d20f5  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d20fe  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d2107  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d2110  add rsp, 0xF0
00007fdcd91d2117  pop r11
00007fdcd91d2119  pop r10
00007fdcd91d211b  pop r9
00007fdcd91d211d  pop r8
00007fdcd91d211f  pop rsi
00007fdcd91d2120  pop rdi
00007fdcd91d2121  pop rdx
00007fdcd91d2122  pop rcx
00007fdcd91d2123  pop rax
00007fdcd91d2124  add rsp, 0x08
00007fdcd91d2128  jmp 0x00007FDCD91CFBAB
00007fdcd91d212d  call 0x00007FDCD8FFF430
00007fdcd91d2132  jmp 0x00007FDCD91CFBB8
00007fdcd91d2137  sub rsp, 0x08
00007fdcd91d213b  push rax
00007fdcd91d213c  push rcx
00007fdcd91d213d  push rdx
00007fdcd91d213e  push rdi
00007fdcd91d213f  push rsi
00007fdcd91d2140  push r8
00007fdcd91d2142  push r9
00007fdcd91d2144  push r10
00007fdcd91d2146  push r11
00007fdcd91d2148  sub rsp, 0xF0
00007fdcd91d214f  vmovaps [rsp], xmm0
00007fdcd91d2154  vmovaps [rsp+0x10], xmm1
00007fdcd91d215a  vmovaps [rsp+0x20], xmm2
00007fdcd91d2160  vmovaps [rsp+0x30], xmm3
00007fdcd91d2166  vmovaps [rsp+0x40], xmm4
00007fdcd91d216c  vmovaps [rsp+0x50], xmm5
00007fdcd91d2172  vmovaps [rsp+0x60], xmm6
00007fdcd91d2178  vmovaps [rsp+0x70], xmm7
00007fdcd91d217e  vmovaps [rsp+0x80], xmm8
00007fdcd91d2187  vmovaps [rsp+0x90], xmm9
00007fdcd91d2190  vmovaps [rsp+0xA0], xmm10
00007fdcd91d2199  vmovaps [rsp+0xB0], xmm11
00007fdcd91d21a2  vmovaps [rsp+0xC0], xmm12
00007fdcd91d21ab  vmovaps [rsp+0xD0], xmm13
00007fdcd91d21b4  vmovaps [rsp+0xE0], xmm14
00007fdcd91d21bd  sub rsp, 0x30
00007fdcd91d21c1  movaps [rsp], xmm15
00007fdcd91d21c6  movaps [rsp+0x10], xmm13
00007fdcd91d21cc  movaps [rsp+0x20], xmm1
00007fdcd91d21d1  lea rdi, [rsp]
00007fdcd91d21d5  mov esi, 0x00
00007fdcd91d21da  mov rax, 0x5B56EFBF3530
00007fdcd91d21e4  call rax
00007fdcd91d21e6  movaps xmm15, [rsp]
00007fdcd91d21eb  add rsp, 0x30
00007fdcd91d21ef  vmovaps xmm0, [rsp]
00007fdcd91d21f4  vmovaps xmm1, [rsp+0x10]
00007fdcd91d21fa  vmovaps xmm2, [rsp+0x20]
00007fdcd91d2200  vmovaps xmm3, [rsp+0x30]
00007fdcd91d2206  vmovaps xmm4, [rsp+0x40]
00007fdcd91d220c  vmovaps xmm5, [rsp+0x50]
00007fdcd91d2212  vmovaps xmm6, [rsp+0x60]
00007fdcd91d2218  vmovaps xmm7, [rsp+0x70]
00007fdcd91d221e  vmovaps xmm8, [rsp+0x80]
00007fdcd91d2227  vmovaps xmm9, [rsp+0x90]
00007fdcd91d2230  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d2239  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d2242  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d224b  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d2254  vmovaps xmm14, [rsp+0xE0]
00007fdcd91d225d  add rsp, 0xF0
00007fdcd91d2264  pop r11
00007fdcd91d2266  pop r10
00007fdcd91d2268  pop r9
00007fdcd91d226a  pop r8
00007fdcd91d226c  pop rsi
00007fdcd91d226d  pop rdi
00007fdcd91d226e  pop rdx
00007fdcd91d226f  pop rcx
00007fdcd91d2270  pop rax
00007fdcd91d2271  add rsp, 0x08
00007fdcd91d2275  jmp 0x00007FDCD91CFBF7
00007fdcd91d227a  sub rsp, 0x08
00007fdcd91d227e  push rax
00007fdcd91d227f  push rcx
00007fdcd91d2280  push rdx
00007fdcd91d2281  push rdi
00007fdcd91d2282  push rsi
00007fdcd91d2283  push r8
00007fdcd91d2285  push r9
00007fdcd91d2287  push r10
00007fdcd91d2289  push r11
00007fdcd91d228b  sub rsp, 0xF0
00007fdcd91d2292  vmovaps [rsp], xmm0
00007fdcd91d2297  vmovaps [rsp+0x10], xmm1
00007fdcd91d229d  vmovaps [rsp+0x20], xmm2
00007fdcd91d22a3  vmovaps [rsp+0x30], xmm3
00007fdcd91d22a9  vmovaps [rsp+0x40], xmm4
00007fdcd91d22af  vmovaps [rsp+0x50], xmm5
00007fdcd91d22b5  vmovaps [rsp+0x60], xmm6
00007fdcd91d22bb  vmovaps [rsp+0x70], xmm7
00007fdcd91d22c1  vmovaps [rsp+0x80], xmm8
00007fdcd91d22ca  vmovaps [rsp+0x90], xmm9
00007fdcd91d22d3  vmovaps [rsp+0xA0], xmm10
00007fdcd91d22dc  vmovaps [rsp+0xB0], xmm11
00007fdcd91d22e5  vmovaps [rsp+0xC0], xmm12
00007fdcd91d22ee  vmovaps [rsp+0xD0], xmm13
00007fdcd91d22f7  vmovaps [rsp+0xE0], xmm15
00007fdcd91d2300  sub rsp, 0x30
00007fdcd91d2304  movaps [rsp], xmm14
00007fdcd91d2309  movaps [rsp+0x10], xmm11
00007fdcd91d230f  movaps [rsp+0x20], xmm1
00007fdcd91d2314  lea rdi, [rsp]
00007fdcd91d2318  mov esi, 0x00
00007fdcd91d231d  mov rax, 0x5B56EFBF3530
00007fdcd91d2327  call rax
00007fdcd91d2329  movaps xmm14, [rsp]
00007fdcd91d232e  add rsp, 0x30
00007fdcd91d2332  vmovaps xmm0, [rsp]
00007fdcd91d2337  vmovaps xmm1, [rsp+0x10]
00007fdcd91d233d  vmovaps xmm2, [rsp+0x20]
00007fdcd91d2343  vmovaps xmm3, [rsp+0x30]
00007fdcd91d2349  vmovaps xmm4, [rsp+0x40]
00007fdcd91d234f  vmovaps xmm5, [rsp+0x50]
00007fdcd91d2355  vmovaps xmm6, [rsp+0x60]
00007fdcd91d235b  vmovaps xmm7, [rsp+0x70]
00007fdcd91d2361  vmovaps xmm8, [rsp+0x80]
00007fdcd91d236a  vmovaps xmm9, [rsp+0x90]
00007fdcd91d2373  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d237c  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d2385  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d238e  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d2397  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d23a0  add rsp, 0xF0
00007fdcd91d23a7  pop r11
00007fdcd91d23a9  pop r10
00007fdcd91d23ab  pop r9
00007fdcd91d23ad  pop r8
00007fdcd91d23af  pop rsi
00007fdcd91d23b0  pop rdi
00007fdcd91d23b1  pop rdx
00007fdcd91d23b2  pop rcx
00007fdcd91d23b3  pop rax
00007fdcd91d23b4  add rsp, 0x08
00007fdcd91d23b8  jmp 0x00007FDCD91CFC21
00007fdcd91d23bd  sub rsp, 0x08
00007fdcd91d23c1  push rax
00007fdcd91d23c2  push rcx
00007fdcd91d23c3  push rdx
00007fdcd91d23c4  push rdi
00007fdcd91d23c5  push rsi
00007fdcd91d23c6  push r8
00007fdcd91d23c8  push r9
00007fdcd91d23ca  push r10
00007fdcd91d23cc  push r11
00007fdcd91d23ce  sub rsp, 0xF0
00007fdcd91d23d5  vmovaps [rsp], xmm0
00007fdcd91d23da  vmovaps [rsp+0x10], xmm1
00007fdcd91d23e0  vmovaps [rsp+0x20], xmm2
00007fdcd91d23e6  vmovaps [rsp+0x30], xmm3
00007fdcd91d23ec  vmovaps [rsp+0x40], xmm4
00007fdcd91d23f2  vmovaps [rsp+0x50], xmm5
00007fdcd91d23f8  vmovaps [rsp+0x60], xmm6
00007fdcd91d23fe  vmovaps [rsp+0x70], xmm7
00007fdcd91d2404  vmovaps [rsp+0x80], xmm8
00007fdcd91d240d  vmovaps [rsp+0x90], xmm9
00007fdcd91d2416  vmovaps [rsp+0xA0], xmm10
00007fdcd91d241f  vmovaps [rsp+0xB0], xmm11
00007fdcd91d2428  vmovaps [rsp+0xC0], xmm12
00007fdcd91d2431  vmovaps [rsp+0xD0], xmm14
00007fdcd91d243a  vmovaps [rsp+0xE0], xmm15
00007fdcd91d2443  sub rsp, 0x30
00007fdcd91d2447  movaps [rsp], xmm13
00007fdcd91d244c  movaps [rsp+0x10], xmm11
00007fdcd91d2452  movaps [rsp+0x20], xmm1
00007fdcd91d2457  lea rdi, [rsp]
00007fdcd91d245b  mov esi, 0x00
00007fdcd91d2460  mov rax, 0x5B56EFBF3530
00007fdcd91d246a  call rax
00007fdcd91d246c  movaps xmm13, [rsp]
00007fdcd91d2471  add rsp, 0x30
00007fdcd91d2475  vmovaps xmm0, [rsp]
00007fdcd91d247a  vmovaps xmm1, [rsp+0x10]
00007fdcd91d2480  vmovaps xmm2, [rsp+0x20]
00007fdcd91d2486  vmovaps xmm3, [rsp+0x30]
00007fdcd91d248c  vmovaps xmm4, [rsp+0x40]
00007fdcd91d2492  vmovaps xmm5, [rsp+0x50]
00007fdcd91d2498  vmovaps xmm6, [rsp+0x60]
00007fdcd91d249e  vmovaps xmm7, [rsp+0x70]
00007fdcd91d24a4  vmovaps xmm8, [rsp+0x80]
00007fdcd91d24ad  vmovaps xmm9, [rsp+0x90]
00007fdcd91d24b6  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d24bf  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d24c8  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d24d1  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d24da  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d24e3  add rsp, 0xF0
00007fdcd91d24ea  pop r11
00007fdcd91d24ec  pop r10
00007fdcd91d24ee  pop r9
00007fdcd91d24f0  pop r8
00007fdcd91d24f2  pop rsi
00007fdcd91d24f3  pop rdi
00007fdcd91d24f4  pop rdx
00007fdcd91d24f5  pop rcx
00007fdcd91d24f6  pop rax
00007fdcd91d24f7  add rsp, 0x08
00007fdcd91d24fb  jmp 0x00007FDCD91CFC76
00007fdcd91d2500  call 0x00007FDCD8FFF430
00007fdcd91d2505  jmp 0x00007FDCD91CFC83
00007fdcd91d250a  sub rsp, 0x08
00007fdcd91d250e  push rax
00007fdcd91d250f  push rcx
00007fdcd91d2510  push rdx
00007fdcd91d2511  push rdi
00007fdcd91d2512  push rsi
00007fdcd91d2513  push r8
00007fdcd91d2515  push r9
00007fdcd91d2517  push r10
00007fdcd91d2519  push r11
00007fdcd91d251b  sub rsp, 0xF0
00007fdcd91d2522  vmovaps [rsp], xmm0
00007fdcd91d2527  vmovaps [rsp+0x10], xmm1
00007fdcd91d252d  vmovaps [rsp+0x20], xmm2
00007fdcd91d2533  vmovaps [rsp+0x30], xmm3
00007fdcd91d2539  vmovaps [rsp+0x40], xmm4
00007fdcd91d253f  vmovaps [rsp+0x50], xmm5
00007fdcd91d2545  vmovaps [rsp+0x60], xmm6
00007fdcd91d254b  vmovaps [rsp+0x70], xmm7
00007fdcd91d2551  vmovaps [rsp+0x80], xmm8
00007fdcd91d255a  vmovaps [rsp+0x90], xmm9
00007fdcd91d2563  vmovaps [rsp+0xA0], xmm10
00007fdcd91d256c  vmovaps [rsp+0xB0], xmm11
00007fdcd91d2575  vmovaps [rsp+0xC0], xmm12
00007fdcd91d257e  vmovaps [rsp+0xD0], xmm13
00007fdcd91d2587  vmovaps [rsp+0xE0], xmm14
00007fdcd91d2590  sub rsp, 0x30
00007fdcd91d2594  movaps [rsp], xmm15
00007fdcd91d2599  movaps [rsp+0x10], xmm11
00007fdcd91d259f  movaps [rsp+0x20], xmm1
00007fdcd91d25a4  lea rdi, [rsp]
00007fdcd91d25a8  mov esi, 0x00
00007fdcd91d25ad  mov rax, 0x5B56EFBF3530
00007fdcd91d25b7  call rax
00007fdcd91d25b9  movaps xmm15, [rsp]
00007fdcd91d25be  add rsp, 0x30
00007fdcd91d25c2  vmovaps xmm0, [rsp]
00007fdcd91d25c7  vmovaps xmm1, [rsp+0x10]
00007fdcd91d25cd  vmovaps xmm2, [rsp+0x20]
00007fdcd91d25d3  vmovaps xmm3, [rsp+0x30]
00007fdcd91d25d9  vmovaps xmm4, [rsp+0x40]
00007fdcd91d25df  vmovaps xmm5, [rsp+0x50]
00007fdcd91d25e5  vmovaps xmm6, [rsp+0x60]
00007fdcd91d25eb  vmovaps xmm7, [rsp+0x70]
00007fdcd91d25f1  vmovaps xmm8, [rsp+0x80]
00007fdcd91d25fa  vmovaps xmm9, [rsp+0x90]
00007fdcd91d2603  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d260c  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d2615  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d261e  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d2627  vmovaps xmm14, [rsp+0xE0]
00007fdcd91d2630  add rsp, 0xF0
00007fdcd91d2637  pop r11
00007fdcd91d2639  pop r10
00007fdcd91d263b  pop r9
00007fdcd91d263d  pop r8
00007fdcd91d263f  pop rsi
00007fdcd91d2640  pop rdi
00007fdcd91d2641  pop rdx
00007fdcd91d2642  pop rcx
00007fdcd91d2643  pop rax
00007fdcd91d2644  add rsp, 0x08
00007fdcd91d2648  jmp 0x00007FDCD91CFCBC
00007fdcd91d264d  sub rsp, 0x08
00007fdcd91d2651  push rax
00007fdcd91d2652  push rcx
00007fdcd91d2653  push rdx
00007fdcd91d2654  push rdi
00007fdcd91d2655  push rsi
00007fdcd91d2656  push r8
00007fdcd91d2658  push r9
00007fdcd91d265a  push r10
00007fdcd91d265c  push r11
00007fdcd91d265e  sub rsp, 0xF0
00007fdcd91d2665  vmovaps [rsp], xmm0
00007fdcd91d266a  vmovaps [rsp+0x10], xmm1
00007fdcd91d2670  vmovaps [rsp+0x20], xmm2
00007fdcd91d2676  vmovaps [rsp+0x30], xmm3
00007fdcd91d267c  vmovaps [rsp+0x40], xmm4
00007fdcd91d2682  vmovaps [rsp+0x50], xmm5
00007fdcd91d2688  vmovaps [rsp+0x60], xmm6
00007fdcd91d268e  vmovaps [rsp+0x70], xmm7
00007fdcd91d2694  vmovaps [rsp+0x80], xmm8
00007fdcd91d269d  vmovaps [rsp+0x90], xmm9
00007fdcd91d26a6  vmovaps [rsp+0xA0], xmm10
00007fdcd91d26af  vmovaps [rsp+0xB0], xmm12
00007fdcd91d26b8  vmovaps [rsp+0xC0], xmm13
00007fdcd91d26c1  vmovaps [rsp+0xD0], xmm14
00007fdcd91d26ca  vmovaps [rsp+0xE0], xmm15
00007fdcd91d26d3  sub rsp, 0x30
00007fdcd91d26d7  movaps [rsp], xmm11
00007fdcd91d26dc  movaps [rsp+0x10], xmm6
00007fdcd91d26e1  movaps [rsp+0x20], xmm14
00007fdcd91d26e7  lea rdi, [rsp]
00007fdcd91d26eb  mov esi, 0x00
00007fdcd91d26f0  mov rax, 0x5B56EFBF3530
00007fdcd91d26fa  call rax
00007fdcd91d26fc  movaps xmm11, [rsp]
00007fdcd91d2701  add rsp, 0x30
00007fdcd91d2705  vmovaps xmm0, [rsp]
00007fdcd91d270a  vmovaps xmm1, [rsp+0x10]
00007fdcd91d2710  vmovaps xmm2, [rsp+0x20]
00007fdcd91d2716  vmovaps xmm3, [rsp+0x30]
00007fdcd91d271c  vmovaps xmm4, [rsp+0x40]
00007fdcd91d2722  vmovaps xmm5, [rsp+0x50]
00007fdcd91d2728  vmovaps xmm6, [rsp+0x60]
00007fdcd91d272e  vmovaps xmm7, [rsp+0x70]
00007fdcd91d2734  vmovaps xmm8, [rsp+0x80]
00007fdcd91d273d  vmovaps xmm9, [rsp+0x90]
00007fdcd91d2746  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d274f  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d2758  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d2761  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d276a  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d2773  add rsp, 0xF0
00007fdcd91d277a  pop r11
00007fdcd91d277c  pop r10
00007fdcd91d277e  pop r9
00007fdcd91d2780  pop r8
00007fdcd91d2782  pop rsi
00007fdcd91d2783  pop rdi
00007fdcd91d2784  pop rdx
00007fdcd91d2785  pop rcx
00007fdcd91d2786  pop rax
00007fdcd91d2787  add rsp, 0x08
00007fdcd91d278b  jmp 0x00007FDCD91CFD34
00007fdcd91d2790  call 0x00007FDCD8FFF430
00007fdcd91d2795  jmp 0x00007FDCD91CFD3E
00007fdcd91d279a  sub rsp, 0x08
00007fdcd91d279e  push rax
00007fdcd91d279f  push rcx
00007fdcd91d27a0  push rdx
00007fdcd91d27a1  push rdi
00007fdcd91d27a2  push rsi
00007fdcd91d27a3  push r8
00007fdcd91d27a5  push r9
00007fdcd91d27a7  push r10
00007fdcd91d27a9  push r11
00007fdcd91d27ab  sub rsp, 0xF0
00007fdcd91d27b2  vmovaps [rsp], xmm0
00007fdcd91d27b7  vmovaps [rsp+0x10], xmm1
00007fdcd91d27bd  vmovaps [rsp+0x20], xmm2
00007fdcd91d27c3  vmovaps [rsp+0x30], xmm3
00007fdcd91d27c9  vmovaps [rsp+0x40], xmm4
00007fdcd91d27cf  vmovaps [rsp+0x50], xmm5
00007fdcd91d27d5  vmovaps [rsp+0x60], xmm6
00007fdcd91d27db  vmovaps [rsp+0x70], xmm7
00007fdcd91d27e1  vmovaps [rsp+0x80], xmm8
00007fdcd91d27ea  vmovaps [rsp+0x90], xmm9
00007fdcd91d27f3  vmovaps [rsp+0xA0], xmm10
00007fdcd91d27fc  vmovaps [rsp+0xB0], xmm11
00007fdcd91d2805  vmovaps [rsp+0xC0], xmm12
00007fdcd91d280e  vmovaps [rsp+0xD0], xmm13
00007fdcd91d2817  vmovaps [rsp+0xE0], xmm15
00007fdcd91d2820  sub rsp, 0x30
00007fdcd91d2824  movaps [rsp], xmm14
00007fdcd91d2829  movaps [rsp+0x10], xmm6
00007fdcd91d282e  movaps [rsp+0x20], xmm2
00007fdcd91d2833  lea rdi, [rsp]
00007fdcd91d2837  mov esi, 0x00
00007fdcd91d283c  mov rax, 0x5B56EFBF3530
00007fdcd91d2846  call rax
00007fdcd91d2848  movaps xmm14, [rsp]
00007fdcd91d284d  add rsp, 0x30
00007fdcd91d2851  vmovaps xmm0, [rsp]
00007fdcd91d2856  vmovaps xmm1, [rsp+0x10]
00007fdcd91d285c  vmovaps xmm2, [rsp+0x20]
00007fdcd91d2862  vmovaps xmm3, [rsp+0x30]
00007fdcd91d2868  vmovaps xmm4, [rsp+0x40]
00007fdcd91d286e  vmovaps xmm5, [rsp+0x50]
00007fdcd91d2874  vmovaps xmm6, [rsp+0x60]
00007fdcd91d287a  vmovaps xmm7, [rsp+0x70]
00007fdcd91d2880  vmovaps xmm8, [rsp+0x80]
00007fdcd91d2889  vmovaps xmm9, [rsp+0x90]
00007fdcd91d2892  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d289b  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d28a4  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d28ad  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d28b6  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d28bf  add rsp, 0xF0
00007fdcd91d28c6  pop r11
00007fdcd91d28c8  pop r10
00007fdcd91d28ca  pop r9
00007fdcd91d28cc  pop r8
00007fdcd91d28ce  pop rsi
00007fdcd91d28cf  pop rdi
00007fdcd91d28d0  pop rdx
00007fdcd91d28d1  pop rcx
00007fdcd91d28d2  pop rax
00007fdcd91d28d3  add rsp, 0x08
00007fdcd91d28d7  jmp 0x00007FDCD91CFD72
00007fdcd91d28dc  sub rsp, 0x08
00007fdcd91d28e0  push rax
00007fdcd91d28e1  push rcx
00007fdcd91d28e2  push rdx
00007fdcd91d28e3  push rdi
00007fdcd91d28e4  push rsi
00007fdcd91d28e5  push r8
00007fdcd91d28e7  push r9
00007fdcd91d28e9  push r10
00007fdcd91d28eb  push r11
00007fdcd91d28ed  sub rsp, 0xF0
00007fdcd91d28f4  vmovaps [rsp], xmm0
00007fdcd91d28f9  vmovaps [rsp+0x10], xmm1
00007fdcd91d28ff  vmovaps [rsp+0x20], xmm2
00007fdcd91d2905  vmovaps [rsp+0x30], xmm3
00007fdcd91d290b  vmovaps [rsp+0x40], xmm4
00007fdcd91d2911  vmovaps [rsp+0x50], xmm5
00007fdcd91d2917  vmovaps [rsp+0x60], xmm7
00007fdcd91d291d  vmovaps [rsp+0x70], xmm8
00007fdcd91d2923  vmovaps [rsp+0x80], xmm9
00007fdcd91d292c  vmovaps [rsp+0x90], xmm10
00007fdcd91d2935  vmovaps [rsp+0xA0], xmm11
00007fdcd91d293e  vmovaps [rsp+0xB0], xmm12
00007fdcd91d2947  vmovaps [rsp+0xC0], xmm13
00007fdcd91d2950  vmovaps [rsp+0xD0], xmm14
00007fdcd91d2959  vmovaps [rsp+0xE0], xmm15
00007fdcd91d2962  sub rsp, 0x30
00007fdcd91d2966  movaps [rsp], xmm6
00007fdcd91d296a  movaps [rsp+0x10], xmm5
00007fdcd91d296f  movaps [rsp+0x20], xmm1
00007fdcd91d2974  lea rdi, [rsp]
00007fdcd91d2978  mov esi, 0x00
00007fdcd91d297d  mov rax, 0x5B56EFBF3530
00007fdcd91d2987  call rax
00007fdcd91d2989  movaps xmm6, [rsp]
00007fdcd91d298d  add rsp, 0x30
00007fdcd91d2991  vmovaps xmm0, [rsp]
00007fdcd91d2996  vmovaps xmm1, [rsp+0x10]
00007fdcd91d299c  vmovaps xmm2, [rsp+0x20]
00007fdcd91d29a2  vmovaps xmm3, [rsp+0x30]
00007fdcd91d29a8  vmovaps xmm4, [rsp+0x40]
00007fdcd91d29ae  vmovaps xmm5, [rsp+0x50]
00007fdcd91d29b4  vmovaps xmm7, [rsp+0x60]
00007fdcd91d29ba  vmovaps xmm8, [rsp+0x70]
00007fdcd91d29c0  vmovaps xmm9, [rsp+0x80]
00007fdcd91d29c9  vmovaps xmm10, [rsp+0x90]
00007fdcd91d29d2  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d29db  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d29e4  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d29ed  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d29f6  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d29ff  add rsp, 0xF0
00007fdcd91d2a06  pop r11
00007fdcd91d2a08  pop r10
00007fdcd91d2a0a  pop r9
00007fdcd91d2a0c  pop r8
00007fdcd91d2a0e  pop rsi
00007fdcd91d2a0f  pop rdi
00007fdcd91d2a10  pop rdx
00007fdcd91d2a11  pop rcx
00007fdcd91d2a12  pop rax
00007fdcd91d2a13  add rsp, 0x08
00007fdcd91d2a17  jmp 0x00007FDCD91CFD98
00007fdcd91d2a1c  sub rsp, 0x08
00007fdcd91d2a20  push rax
00007fdcd91d2a21  push rcx
00007fdcd91d2a22  push rdx
00007fdcd91d2a23  push rdi
00007fdcd91d2a24  push rsi
00007fdcd91d2a25  push r8
00007fdcd91d2a27  push r9
00007fdcd91d2a29  push r10
00007fdcd91d2a2b  push r11
00007fdcd91d2a2d  sub rsp, 0xF0
00007fdcd91d2a34  vmovaps [rsp], xmm0
00007fdcd91d2a39  vmovaps [rsp+0x10], xmm2
00007fdcd91d2a3f  vmovaps [rsp+0x20], xmm3
00007fdcd91d2a45  vmovaps [rsp+0x30], xmm4
00007fdcd91d2a4b  vmovaps [rsp+0x40], xmm5
00007fdcd91d2a51  vmovaps [rsp+0x50], xmm6
00007fdcd91d2a57  vmovaps [rsp+0x60], xmm7
00007fdcd91d2a5d  vmovaps [rsp+0x70], xmm8
00007fdcd91d2a63  vmovaps [rsp+0x80], xmm9
00007fdcd91d2a6c  vmovaps [rsp+0x90], xmm10
00007fdcd91d2a75  vmovaps [rsp+0xA0], xmm11
00007fdcd91d2a7e  vmovaps [rsp+0xB0], xmm12
00007fdcd91d2a87  vmovaps [rsp+0xC0], xmm13
00007fdcd91d2a90  vmovaps [rsp+0xD0], xmm14
00007fdcd91d2a99  vmovaps [rsp+0xE0], xmm15
00007fdcd91d2aa2  sub rsp, 0x30
00007fdcd91d2aa6  movaps [rsp], xmm1
00007fdcd91d2aaa  movaps [rsp+0x10], xmm5
00007fdcd91d2aaf  movaps [rsp+0x20], xmm13
00007fdcd91d2ab5  lea rdi, [rsp]
00007fdcd91d2ab9  mov esi, 0x00
00007fdcd91d2abe  mov rax, 0x5B56EFBF3530
00007fdcd91d2ac8  call rax
00007fdcd91d2aca  movaps xmm1, [rsp]
00007fdcd91d2ace  add rsp, 0x30
00007fdcd91d2ad2  vmovaps xmm0, [rsp]
00007fdcd91d2ad7  vmovaps xmm2, [rsp+0x10]
00007fdcd91d2add  vmovaps xmm3, [rsp+0x20]
00007fdcd91d2ae3  vmovaps xmm4, [rsp+0x30]
00007fdcd91d2ae9  vmovaps xmm5, [rsp+0x40]
00007fdcd91d2aef  vmovaps xmm6, [rsp+0x50]
00007fdcd91d2af5  vmovaps xmm7, [rsp+0x60]
00007fdcd91d2afb  vmovaps xmm8, [rsp+0x70]
00007fdcd91d2b01  vmovaps xmm9, [rsp+0x80]
00007fdcd91d2b0a  vmovaps xmm10, [rsp+0x90]
00007fdcd91d2b13  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d2b1c  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d2b25  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d2b2e  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d2b37  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d2b40  add rsp, 0xF0
00007fdcd91d2b47  pop r11
00007fdcd91d2b49  pop r10
00007fdcd91d2b4b  pop r9
00007fdcd91d2b4d  pop r8
00007fdcd91d2b4f  pop rsi
00007fdcd91d2b50  pop rdi
00007fdcd91d2b51  pop rdx
00007fdcd91d2b52  pop rcx
00007fdcd91d2b53  pop rax
00007fdcd91d2b54  add rsp, 0x08
00007fdcd91d2b58  jmp 0x00007FDCD91CFDB6
00007fdcd91d2b5d  sub rsp, 0x08
00007fdcd91d2b61  push rax
00007fdcd91d2b62  push rcx
00007fdcd91d2b63  push rdx
00007fdcd91d2b64  push rdi
00007fdcd91d2b65  push rsi
00007fdcd91d2b66  push r8
00007fdcd91d2b68  push r9
00007fdcd91d2b6a  push r10
00007fdcd91d2b6c  push r11
00007fdcd91d2b6e  sub rsp, 0xF0
00007fdcd91d2b75  vmovaps [rsp], xmm0
00007fdcd91d2b7a  vmovaps [rsp+0x10], xmm1
00007fdcd91d2b80  vmovaps [rsp+0x20], xmm2
00007fdcd91d2b86  vmovaps [rsp+0x30], xmm3
00007fdcd91d2b8c  vmovaps [rsp+0x40], xmm4
00007fdcd91d2b92  vmovaps [rsp+0x50], xmm6
00007fdcd91d2b98  vmovaps [rsp+0x60], xmm7
00007fdcd91d2b9e  vmovaps [rsp+0x70], xmm8
00007fdcd91d2ba4  vmovaps [rsp+0x80], xmm9
00007fdcd91d2bad  vmovaps [rsp+0x90], xmm10
00007fdcd91d2bb6  vmovaps [rsp+0xA0], xmm11
00007fdcd91d2bbf  vmovaps [rsp+0xB0], xmm12
00007fdcd91d2bc8  vmovaps [rsp+0xC0], xmm13
00007fdcd91d2bd1  vmovaps [rsp+0xD0], xmm14
00007fdcd91d2bda  vmovaps [rsp+0xE0], xmm15
00007fdcd91d2be3  sub rsp, 0x30
00007fdcd91d2be7  movaps [rsp], xmm5
00007fdcd91d2beb  movaps [rsp+0x10], xmm2
00007fdcd91d2bf0  movaps [rsp+0x20], xmm13
00007fdcd91d2bf6  lea rdi, [rsp]
00007fdcd91d2bfa  mov esi, 0x00
00007fdcd91d2bff  mov rax, 0x5B56EFBF3530
00007fdcd91d2c09  call rax
00007fdcd91d2c0b  movaps xmm5, [rsp]
00007fdcd91d2c0f  add rsp, 0x30
00007fdcd91d2c13  vmovaps xmm0, [rsp]
00007fdcd91d2c18  vmovaps xmm1, [rsp+0x10]
00007fdcd91d2c1e  vmovaps xmm2, [rsp+0x20]
00007fdcd91d2c24  vmovaps xmm3, [rsp+0x30]
00007fdcd91d2c2a  vmovaps xmm4, [rsp+0x40]
00007fdcd91d2c30  vmovaps xmm6, [rsp+0x50]
00007fdcd91d2c36  vmovaps xmm7, [rsp+0x60]
00007fdcd91d2c3c  vmovaps xmm8, [rsp+0x70]
00007fdcd91d2c42  vmovaps xmm9, [rsp+0x80]
00007fdcd91d2c4b  vmovaps xmm10, [rsp+0x90]
00007fdcd91d2c54  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d2c5d  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d2c66  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d2c6f  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d2c78  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d2c81  add rsp, 0xF0
00007fdcd91d2c88  pop r11
00007fdcd91d2c8a  pop r10
00007fdcd91d2c8c  pop r9
00007fdcd91d2c8e  pop r8
00007fdcd91d2c90  pop rsi
00007fdcd91d2c91  pop rdi
00007fdcd91d2c92  pop rdx
00007fdcd91d2c93  pop rcx
00007fdcd91d2c94  pop rax
00007fdcd91d2c95  add rsp, 0x08
00007fdcd91d2c99  jmp 0x00007FDCD91CFDEC
00007fdcd91d2c9e  sub rsp, 0x08
00007fdcd91d2ca2  push rax
00007fdcd91d2ca3  push rcx
00007fdcd91d2ca4  push rdx
00007fdcd91d2ca5  push rdi
00007fdcd91d2ca6  push rsi
00007fdcd91d2ca7  push r8
00007fdcd91d2ca9  push r9
00007fdcd91d2cab  push r10
00007fdcd91d2cad  push r11
00007fdcd91d2caf  sub rsp, 0xF0
00007fdcd91d2cb6  vmovaps [rsp], xmm0
00007fdcd91d2cbb  vmovaps [rsp+0x10], xmm1
00007fdcd91d2cc1  vmovaps [rsp+0x20], xmm2
00007fdcd91d2cc7  vmovaps [rsp+0x30], xmm3
00007fdcd91d2ccd  vmovaps [rsp+0x40], xmm4
00007fdcd91d2cd3  vmovaps [rsp+0x50], xmm5
00007fdcd91d2cd9  vmovaps [rsp+0x60], xmm6
00007fdcd91d2cdf  vmovaps [rsp+0x70], xmm7
00007fdcd91d2ce5  vmovaps [rsp+0x80], xmm8
00007fdcd91d2cee  vmovaps [rsp+0x90], xmm9
00007fdcd91d2cf7  vmovaps [rsp+0xA0], xmm10
00007fdcd91d2d00  vmovaps [rsp+0xB0], xmm11
00007fdcd91d2d09  vmovaps [rsp+0xC0], xmm12
00007fdcd91d2d12  vmovaps [rsp+0xD0], xmm14
00007fdcd91d2d1b  vmovaps [rsp+0xE0], xmm15
00007fdcd91d2d24  sub rsp, 0x30
00007fdcd91d2d28  movaps [rsp], xmm13
00007fdcd91d2d2d  movaps [rsp+0x10], xmm10
00007fdcd91d2d33  movaps [rsp+0x20], xmm1
00007fdcd91d2d38  lea rdi, [rsp]
00007fdcd91d2d3c  mov esi, 0x00
00007fdcd91d2d41  mov rax, 0x5B56EFBF3530
00007fdcd91d2d4b  call rax
00007fdcd91d2d4d  movaps xmm13, [rsp]
00007fdcd91d2d52  add rsp, 0x30
00007fdcd91d2d56  vmovaps xmm0, [rsp]
00007fdcd91d2d5b  vmovaps xmm1, [rsp+0x10]
00007fdcd91d2d61  vmovaps xmm2, [rsp+0x20]
00007fdcd91d2d67  vmovaps xmm3, [rsp+0x30]
00007fdcd91d2d6d  vmovaps xmm4, [rsp+0x40]
00007fdcd91d2d73  vmovaps xmm5, [rsp+0x50]
00007fdcd91d2d79  vmovaps xmm6, [rsp+0x60]
00007fdcd91d2d7f  vmovaps xmm7, [rsp+0x70]
00007fdcd91d2d85  vmovaps xmm8, [rsp+0x80]
00007fdcd91d2d8e  vmovaps xmm9, [rsp+0x90]
00007fdcd91d2d97  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d2da0  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d2da9  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d2db2  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d2dbb  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d2dc4  add rsp, 0xF0
00007fdcd91d2dcb  pop r11
00007fdcd91d2dcd  pop r10
00007fdcd91d2dcf  pop r9
00007fdcd91d2dd1  pop r8
00007fdcd91d2dd3  pop rsi
00007fdcd91d2dd4  pop rdi
00007fdcd91d2dd5  pop rdx
00007fdcd91d2dd6  pop rcx
00007fdcd91d2dd7  pop rax
00007fdcd91d2dd8  add rsp, 0x08
00007fdcd91d2ddc  jmp 0x00007FDCD91CFE15
00007fdcd91d2de1  sub rsp, 0x08
00007fdcd91d2de5  push rax
00007fdcd91d2de6  push rcx
00007fdcd91d2de7  push rdx
00007fdcd91d2de8  push rdi
00007fdcd91d2de9  push rsi
00007fdcd91d2dea  push r8
00007fdcd91d2dec  push r9
00007fdcd91d2dee  push r10
00007fdcd91d2df0  push r11
00007fdcd91d2df2  sub rsp, 0xF0
00007fdcd91d2df9  vmovaps [rsp], xmm0
00007fdcd91d2dfe  vmovaps [rsp+0x10], xmm2
00007fdcd91d2e04  vmovaps [rsp+0x20], xmm3
00007fdcd91d2e0a  vmovaps [rsp+0x30], xmm4
00007fdcd91d2e10  vmovaps [rsp+0x40], xmm5
00007fdcd91d2e16  vmovaps [rsp+0x50], xmm6
00007fdcd91d2e1c  vmovaps [rsp+0x60], xmm7
00007fdcd91d2e22  vmovaps [rsp+0x70], xmm8
00007fdcd91d2e28  vmovaps [rsp+0x80], xmm9
00007fdcd91d2e31  vmovaps [rsp+0x90], xmm10
00007fdcd91d2e3a  vmovaps [rsp+0xA0], xmm11
00007fdcd91d2e43  vmovaps [rsp+0xB0], xmm12
00007fdcd91d2e4c  vmovaps [rsp+0xC0], xmm13
00007fdcd91d2e55  vmovaps [rsp+0xD0], xmm14
00007fdcd91d2e5e  vmovaps [rsp+0xE0], xmm15
00007fdcd91d2e67  sub rsp, 0x30
00007fdcd91d2e6b  movaps [rsp], xmm1
00007fdcd91d2e6f  movaps [rsp+0x10], xmm15
00007fdcd91d2e75  movaps [rsp+0x20], xmm10
00007fdcd91d2e7b  lea rdi, [rsp]
00007fdcd91d2e7f  mov esi, 0x00
00007fdcd91d2e84  mov rax, 0x5B56EFBF3530
00007fdcd91d2e8e  call rax
00007fdcd91d2e90  movaps xmm1, [rsp]
00007fdcd91d2e94  add rsp, 0x30
00007fdcd91d2e98  vmovaps xmm0, [rsp]
00007fdcd91d2e9d  vmovaps xmm2, [rsp+0x10]
00007fdcd91d2ea3  vmovaps xmm3, [rsp+0x20]
00007fdcd91d2ea9  vmovaps xmm4, [rsp+0x30]
00007fdcd91d2eaf  vmovaps xmm5, [rsp+0x40]
00007fdcd91d2eb5  vmovaps xmm6, [rsp+0x50]
00007fdcd91d2ebb  vmovaps xmm7, [rsp+0x60]
00007fdcd91d2ec1  vmovaps xmm8, [rsp+0x70]
00007fdcd91d2ec7  vmovaps xmm9, [rsp+0x80]
00007fdcd91d2ed0  vmovaps xmm10, [rsp+0x90]
00007fdcd91d2ed9  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d2ee2  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d2eeb  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d2ef4  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d2efd  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d2f06  add rsp, 0xF0
00007fdcd91d2f0d  pop r11
00007fdcd91d2f0f  pop r10
00007fdcd91d2f11  pop r9
00007fdcd91d2f13  pop r8
00007fdcd91d2f15  pop rsi
00007fdcd91d2f16  pop rdi
00007fdcd91d2f17  pop rdx
00007fdcd91d2f18  pop rcx
00007fdcd91d2f19  pop rax
00007fdcd91d2f1a  add rsp, 0x08
00007fdcd91d2f1e  jmp 0x00007FDCD91CFE34
00007fdcd91d2f23  sub rsp, 0x08
00007fdcd91d2f27  push rax
00007fdcd91d2f28  push rcx
00007fdcd91d2f29  push rdx
00007fdcd91d2f2a  push rdi
00007fdcd91d2f2b  push rsi
00007fdcd91d2f2c  push r8
00007fdcd91d2f2e  push r9
00007fdcd91d2f30  push r10
00007fdcd91d2f32  push r11
00007fdcd91d2f34  sub rsp, 0xF0
00007fdcd91d2f3b  vmovaps [rsp], xmm0
00007fdcd91d2f40  vmovaps [rsp+0x10], xmm1
00007fdcd91d2f46  vmovaps [rsp+0x20], xmm2
00007fdcd91d2f4c  vmovaps [rsp+0x30], xmm3
00007fdcd91d2f52  vmovaps [rsp+0x40], xmm4
00007fdcd91d2f58  vmovaps [rsp+0x50], xmm5
00007fdcd91d2f5e  vmovaps [rsp+0x60], xmm6
00007fdcd91d2f64  vmovaps [rsp+0x70], xmm7
00007fdcd91d2f6a  vmovaps [rsp+0x80], xmm8
00007fdcd91d2f73  vmovaps [rsp+0x90], xmm9
00007fdcd91d2f7c  vmovaps [rsp+0xA0], xmm10
00007fdcd91d2f85  vmovaps [rsp+0xB0], xmm11
00007fdcd91d2f8e  vmovaps [rsp+0xC0], xmm12
00007fdcd91d2f97  vmovaps [rsp+0xD0], xmm13
00007fdcd91d2fa0  vmovaps [rsp+0xE0], xmm14
00007fdcd91d2fa9  sub rsp, 0x30
00007fdcd91d2fad  movaps [rsp], xmm15
00007fdcd91d2fb2  movaps [rsp+0x10], xmm10
00007fdcd91d2fb8  movaps [rsp+0x20], xmm11
00007fdcd91d2fbe  lea rdi, [rsp]
00007fdcd91d2fc2  mov esi, 0x00
00007fdcd91d2fc7  mov rax, 0x5B56EFBF3530
00007fdcd91d2fd1  call rax
00007fdcd91d2fd3  movaps xmm15, [rsp]
00007fdcd91d2fd8  add rsp, 0x30
00007fdcd91d2fdc  vmovaps xmm0, [rsp]
00007fdcd91d2fe1  vmovaps xmm1, [rsp+0x10]
00007fdcd91d2fe7  vmovaps xmm2, [rsp+0x20]
00007fdcd91d2fed  vmovaps xmm3, [rsp+0x30]
00007fdcd91d2ff3  vmovaps xmm4, [rsp+0x40]
00007fdcd91d2ff9  vmovaps xmm5, [rsp+0x50]
00007fdcd91d2fff  vmovaps xmm6, [rsp+0x60]
00007fdcd91d3005  vmovaps xmm7, [rsp+0x70]
00007fdcd91d300b  vmovaps xmm8, [rsp+0x80]
00007fdcd91d3014  vmovaps xmm9, [rsp+0x90]
00007fdcd91d301d  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d3026  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d302f  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d3038  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d3041  vmovaps xmm14, [rsp+0xE0]
00007fdcd91d304a  add rsp, 0xF0
00007fdcd91d3051  pop r11
00007fdcd91d3053  pop r10
00007fdcd91d3055  pop r9
00007fdcd91d3057  pop r8
00007fdcd91d3059  pop rsi
00007fdcd91d305a  pop rdi
00007fdcd91d305b  pop rdx
00007fdcd91d305c  pop rcx
00007fdcd91d305d  pop rax
00007fdcd91d305e  add rsp, 0x08
00007fdcd91d3062  jmp 0x00007FDCD91CFE57
00007fdcd91d3067  sub rsp, 0x08
00007fdcd91d306b  push rax
00007fdcd91d306c  push rcx
00007fdcd91d306d  push rdx
00007fdcd91d306e  push rdi
00007fdcd91d306f  push rsi
00007fdcd91d3070  push r8
00007fdcd91d3072  push r9
00007fdcd91d3074  push r10
00007fdcd91d3076  push r11
00007fdcd91d3078  sub rsp, 0xF0
00007fdcd91d307f  vmovaps [rsp], xmm0
00007fdcd91d3084  vmovaps [rsp+0x10], xmm1
00007fdcd91d308a  vmovaps [rsp+0x20], xmm2
00007fdcd91d3090  vmovaps [rsp+0x30], xmm3
00007fdcd91d3096  vmovaps [rsp+0x40], xmm4
00007fdcd91d309c  vmovaps [rsp+0x50], xmm5
00007fdcd91d30a2  vmovaps [rsp+0x60], xmm6
00007fdcd91d30a8  vmovaps [rsp+0x70], xmm7
00007fdcd91d30ae  vmovaps [rsp+0x80], xmm8
00007fdcd91d30b7  vmovaps [rsp+0x90], xmm9
00007fdcd91d30c0  vmovaps [rsp+0xA0], xmm11
00007fdcd91d30c9  vmovaps [rsp+0xB0], xmm12
00007fdcd91d30d2  vmovaps [rsp+0xC0], xmm13
00007fdcd91d30db  vmovaps [rsp+0xD0], xmm14
00007fdcd91d30e4  vmovaps [rsp+0xE0], xmm15
00007fdcd91d30ed  sub rsp, 0x30
00007fdcd91d30f1  movaps [rsp], xmm10
00007fdcd91d30f6  movaps [rsp+0x10], xmm12
00007fdcd91d30fc  movaps [rsp+0x20], xmm11
00007fdcd91d3102  lea rdi, [rsp]
00007fdcd91d3106  mov esi, 0x00
00007fdcd91d310b  mov rax, 0x5B56EFBF3530
00007fdcd91d3115  call rax
00007fdcd91d3117  movaps xmm10, [rsp]
00007fdcd91d311c  add rsp, 0x30
00007fdcd91d3120  vmovaps xmm0, [rsp]
00007fdcd91d3125  vmovaps xmm1, [rsp+0x10]
00007fdcd91d312b  vmovaps xmm2, [rsp+0x20]
00007fdcd91d3131  vmovaps xmm3, [rsp+0x30]
00007fdcd91d3137  vmovaps xmm4, [rsp+0x40]
00007fdcd91d313d  vmovaps xmm5, [rsp+0x50]
00007fdcd91d3143  vmovaps xmm6, [rsp+0x60]
00007fdcd91d3149  vmovaps xmm7, [rsp+0x70]
00007fdcd91d314f  vmovaps xmm8, [rsp+0x80]
00007fdcd91d3158  vmovaps xmm9, [rsp+0x90]
00007fdcd91d3161  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d316a  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d3173  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d317c  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d3185  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d318e  add rsp, 0xF0
00007fdcd91d3195  pop r11
00007fdcd91d3197  pop r10
00007fdcd91d3199  pop r9
00007fdcd91d319b  pop r8
00007fdcd91d319d  pop rsi
00007fdcd91d319e  pop rdi
00007fdcd91d319f  pop rdx
00007fdcd91d31a0  pop rcx
00007fdcd91d31a1  pop rax
00007fdcd91d31a2  add rsp, 0x08
00007fdcd91d31a6  jmp 0x00007FDCD91CFE80
00007fdcd91d31ab  sub rsp, 0x08
00007fdcd91d31af  push rax
00007fdcd91d31b0  push rcx
00007fdcd91d31b1  push rdx
00007fdcd91d31b2  push rdi
00007fdcd91d31b3  push rsi
00007fdcd91d31b4  push r8
00007fdcd91d31b6  push r9
00007fdcd91d31b8  push r10
00007fdcd91d31ba  push r11
00007fdcd91d31bc  sub rsp, 0xF0
00007fdcd91d31c3  vmovaps [rsp], xmm0
00007fdcd91d31c8  vmovaps [rsp+0x10], xmm1
00007fdcd91d31ce  vmovaps [rsp+0x20], xmm2
00007fdcd91d31d4  vmovaps [rsp+0x30], xmm3
00007fdcd91d31da  vmovaps [rsp+0x40], xmm4
00007fdcd91d31e0  vmovaps [rsp+0x50], xmm5
00007fdcd91d31e6  vmovaps [rsp+0x60], xmm6
00007fdcd91d31ec  vmovaps [rsp+0x70], xmm7
00007fdcd91d31f2  vmovaps [rsp+0x80], xmm8
00007fdcd91d31fb  vmovaps [rsp+0x90], xmm9
00007fdcd91d3204  vmovaps [rsp+0xA0], xmm10
00007fdcd91d320d  vmovaps [rsp+0xB0], xmm12
00007fdcd91d3216  vmovaps [rsp+0xC0], xmm13
00007fdcd91d321f  vmovaps [rsp+0xD0], xmm14
00007fdcd91d3228  vmovaps [rsp+0xE0], xmm15
00007fdcd91d3231  sub rsp, 0x30
00007fdcd91d3235  movaps [rsp], xmm11
00007fdcd91d323a  movaps [rsp+0x10], xmm2
00007fdcd91d323f  movaps [rsp+0x20], xmm12
00007fdcd91d3245  lea rdi, [rsp]
00007fdcd91d3249  mov esi, 0x00
00007fdcd91d324e  mov rax, 0x5B56EFBF3530
00007fdcd91d3258  call rax
00007fdcd91d325a  movaps xmm11, [rsp]
00007fdcd91d325f  add rsp, 0x30
00007fdcd91d3263  vmovaps xmm0, [rsp]
00007fdcd91d3268  vmovaps xmm1, [rsp+0x10]
00007fdcd91d326e  vmovaps xmm2, [rsp+0x20]
00007fdcd91d3274  vmovaps xmm3, [rsp+0x30]
00007fdcd91d327a  vmovaps xmm4, [rsp+0x40]
00007fdcd91d3280  vmovaps xmm5, [rsp+0x50]
00007fdcd91d3286  vmovaps xmm6, [rsp+0x60]
00007fdcd91d328c  vmovaps xmm7, [rsp+0x70]
00007fdcd91d3292  vmovaps xmm8, [rsp+0x80]
00007fdcd91d329b  vmovaps xmm9, [rsp+0x90]
00007fdcd91d32a4  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d32ad  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d32b6  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d32bf  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d32c8  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d32d1  add rsp, 0xF0
00007fdcd91d32d8  pop r11
00007fdcd91d32da  pop r10
00007fdcd91d32dc  pop r9
00007fdcd91d32de  pop r8
00007fdcd91d32e0  pop rsi
00007fdcd91d32e1  pop rdi
00007fdcd91d32e2  pop rdx
00007fdcd91d32e3  pop rcx
00007fdcd91d32e4  pop rax
00007fdcd91d32e5  add rsp, 0x08
00007fdcd91d32e9  jmp 0x00007FDCD91CFEB8
00007fdcd91d32ee  sub rsp, 0x08
00007fdcd91d32f2  push rax
00007fdcd91d32f3  push rcx
00007fdcd91d32f4  push rdx
00007fdcd91d32f5  push rdi
00007fdcd91d32f6  push rsi
00007fdcd91d32f7  push r8
00007fdcd91d32f9  push r9
00007fdcd91d32fb  push r10
00007fdcd91d32fd  push r11
00007fdcd91d32ff  sub rsp, 0xF0
00007fdcd91d3306  vmovaps [rsp], xmm0
00007fdcd91d330b  vmovaps [rsp+0x10], xmm2
00007fdcd91d3311  vmovaps [rsp+0x20], xmm3
00007fdcd91d3317  vmovaps [rsp+0x30], xmm4
00007fdcd91d331d  vmovaps [rsp+0x40], xmm5
00007fdcd91d3323  vmovaps [rsp+0x50], xmm6
00007fdcd91d3329  vmovaps [rsp+0x60], xmm7
00007fdcd91d332f  vmovaps [rsp+0x70], xmm8
00007fdcd91d3335  vmovaps [rsp+0x80], xmm9
00007fdcd91d333e  vmovaps [rsp+0x90], xmm10
00007fdcd91d3347  vmovaps [rsp+0xA0], xmm11
00007fdcd91d3350  vmovaps [rsp+0xB0], xmm12
00007fdcd91d3359  vmovaps [rsp+0xC0], xmm13
00007fdcd91d3362  vmovaps [rsp+0xD0], xmm14
00007fdcd91d336b  vmovaps [rsp+0xE0], xmm15
00007fdcd91d3374  sub rsp, 0x30
00007fdcd91d3378  movaps [rsp], xmm1
00007fdcd91d337c  movaps [rsp+0x10], xmm14
00007fdcd91d3382  movaps [rsp+0x20], xmm6
00007fdcd91d3387  lea rdi, [rsp]
00007fdcd91d338b  mov esi, 0x00
00007fdcd91d3390  mov rax, 0x5B56EFBF3530
00007fdcd91d339a  call rax
00007fdcd91d339c  movaps xmm1, [rsp]
00007fdcd91d33a0  add rsp, 0x30
00007fdcd91d33a4  vmovaps xmm0, [rsp]
00007fdcd91d33a9  vmovaps xmm2, [rsp+0x10]
00007fdcd91d33af  vmovaps xmm3, [rsp+0x20]
00007fdcd91d33b5  vmovaps xmm4, [rsp+0x30]
00007fdcd91d33bb  vmovaps xmm5, [rsp+0x40]
00007fdcd91d33c1  vmovaps xmm6, [rsp+0x50]
00007fdcd91d33c7  vmovaps xmm7, [rsp+0x60]
00007fdcd91d33cd  vmovaps xmm8, [rsp+0x70]
00007fdcd91d33d3  vmovaps xmm9, [rsp+0x80]
00007fdcd91d33dc  vmovaps xmm10, [rsp+0x90]
00007fdcd91d33e5  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d33ee  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d33f7  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d3400  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d3409  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d3412  add rsp, 0xF0
00007fdcd91d3419  pop r11
00007fdcd91d341b  pop r10
00007fdcd91d341d  pop r9
00007fdcd91d341f  pop r8
00007fdcd91d3421  pop rsi
00007fdcd91d3422  pop rdi
00007fdcd91d3423  pop rdx
00007fdcd91d3424  pop rcx
00007fdcd91d3425  pop rax
00007fdcd91d3426  add rsp, 0x08
00007fdcd91d342a  jmp 0x00007FDCD91CFED1
00007fdcd91d342f  sub rsp, 0x08
00007fdcd91d3433  push rax
00007fdcd91d3434  push rcx
00007fdcd91d3435  push rdx
00007fdcd91d3436  push rdi
00007fdcd91d3437  push rsi
00007fdcd91d3438  push r8
00007fdcd91d343a  push r9
00007fdcd91d343c  push r10
00007fdcd91d343e  push r11
00007fdcd91d3440  sub rsp, 0xF0
00007fdcd91d3447  vmovaps [rsp], xmm0
00007fdcd91d344c  vmovaps [rsp+0x10], xmm1
00007fdcd91d3452  vmovaps [rsp+0x20], xmm2
00007fdcd91d3458  vmovaps [rsp+0x30], xmm3
00007fdcd91d345e  vmovaps [rsp+0x40], xmm4
00007fdcd91d3464  vmovaps [rsp+0x50], xmm5
00007fdcd91d346a  vmovaps [rsp+0x60], xmm6
00007fdcd91d3470  vmovaps [rsp+0x70], xmm7
00007fdcd91d3476  vmovaps [rsp+0x80], xmm8
00007fdcd91d347f  vmovaps [rsp+0x90], xmm9
00007fdcd91d3488  vmovaps [rsp+0xA0], xmm10
00007fdcd91d3491  vmovaps [rsp+0xB0], xmm11
00007fdcd91d349a  vmovaps [rsp+0xC0], xmm12
00007fdcd91d34a3  vmovaps [rsp+0xD0], xmm13
00007fdcd91d34ac  vmovaps [rsp+0xE0], xmm15
00007fdcd91d34b5  sub rsp, 0x30
00007fdcd91d34b9  movaps [rsp], xmm14
00007fdcd91d34be  movaps [rsp+0x10], xmm12
00007fdcd91d34c4  movaps [rsp+0x20], xmm5
00007fdcd91d34c9  lea rdi, [rsp]
00007fdcd91d34cd  mov esi, 0x00
00007fdcd91d34d2  mov rax, 0x5B56EFBF3530
00007fdcd91d34dc  call rax
00007fdcd91d34de  movaps xmm14, [rsp]
00007fdcd91d34e3  add rsp, 0x30
00007fdcd91d34e7  vmovaps xmm0, [rsp]
00007fdcd91d34ec  vmovaps xmm1, [rsp+0x10]
00007fdcd91d34f2  vmovaps xmm2, [rsp+0x20]
00007fdcd91d34f8  vmovaps xmm3, [rsp+0x30]
00007fdcd91d34fe  vmovaps xmm4, [rsp+0x40]
00007fdcd91d3504  vmovaps xmm5, [rsp+0x50]
00007fdcd91d350a  vmovaps xmm6, [rsp+0x60]
00007fdcd91d3510  vmovaps xmm7, [rsp+0x70]
00007fdcd91d3516  vmovaps xmm8, [rsp+0x80]
00007fdcd91d351f  vmovaps xmm9, [rsp+0x90]
00007fdcd91d3528  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d3531  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d353a  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d3543  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d354c  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d3555  add rsp, 0xF0
00007fdcd91d355c  pop r11
00007fdcd91d355e  pop r10
00007fdcd91d3560  pop r9
00007fdcd91d3562  pop r8
00007fdcd91d3564  pop rsi
00007fdcd91d3565  pop rdi
00007fdcd91d3566  pop rdx
00007fdcd91d3567  pop rcx
00007fdcd91d3568  pop rax
00007fdcd91d3569  add rsp, 0x08
00007fdcd91d356d  jmp 0x00007FDCD91CFEF1
00007fdcd91d3572  sub rsp, 0x08
00007fdcd91d3576  push rax
00007fdcd91d3577  push rcx
00007fdcd91d3578  push rdx
00007fdcd91d3579  push rdi
00007fdcd91d357a  push rsi
00007fdcd91d357b  push r8
00007fdcd91d357d  push r9
00007fdcd91d357f  push r10
00007fdcd91d3581  push r11
00007fdcd91d3583  sub rsp, 0xF0
00007fdcd91d358a  vmovaps [rsp], xmm0
00007fdcd91d358f  vmovaps [rsp+0x10], xmm1
00007fdcd91d3595  vmovaps [rsp+0x20], xmm2
00007fdcd91d359b  vmovaps [rsp+0x30], xmm3
00007fdcd91d35a1  vmovaps [rsp+0x40], xmm4
00007fdcd91d35a7  vmovaps [rsp+0x50], xmm5
00007fdcd91d35ad  vmovaps [rsp+0x60], xmm7
00007fdcd91d35b3  vmovaps [rsp+0x70], xmm8
00007fdcd91d35b9  vmovaps [rsp+0x80], xmm9
00007fdcd91d35c2  vmovaps [rsp+0x90], xmm10
00007fdcd91d35cb  vmovaps [rsp+0xA0], xmm11
00007fdcd91d35d4  vmovaps [rsp+0xB0], xmm12
00007fdcd91d35dd  vmovaps [rsp+0xC0], xmm13
00007fdcd91d35e6  vmovaps [rsp+0xD0], xmm14
00007fdcd91d35ef  vmovaps [rsp+0xE0], xmm15
00007fdcd91d35f8  sub rsp, 0x30
00007fdcd91d35fc  movaps [rsp], xmm6
00007fdcd91d3600  movaps [rsp+0x10], xmm9
00007fdcd91d3606  movaps [rsp+0x20], xmm12
00007fdcd91d360c  lea rdi, [rsp]
00007fdcd91d3610  mov esi, 0x00
00007fdcd91d3615  mov rax, 0x5B56EFBF3530
00007fdcd91d361f  call rax
00007fdcd91d3621  movaps xmm6, [rsp]
00007fdcd91d3625  add rsp, 0x30
00007fdcd91d3629  vmovaps xmm0, [rsp]
00007fdcd91d362e  vmovaps xmm1, [rsp+0x10]
00007fdcd91d3634  vmovaps xmm2, [rsp+0x20]
00007fdcd91d363a  vmovaps xmm3, [rsp+0x30]
00007fdcd91d3640  vmovaps xmm4, [rsp+0x40]
00007fdcd91d3646  vmovaps xmm5, [rsp+0x50]
00007fdcd91d364c  vmovaps xmm7, [rsp+0x60]
00007fdcd91d3652  vmovaps xmm8, [rsp+0x70]
00007fdcd91d3658  vmovaps xmm9, [rsp+0x80]
00007fdcd91d3661  vmovaps xmm10, [rsp+0x90]
00007fdcd91d366a  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d3673  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d367c  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d3685  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d368e  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d3697  add rsp, 0xF0
00007fdcd91d369e  pop r11
00007fdcd91d36a0  pop r10
00007fdcd91d36a2  pop r9
00007fdcd91d36a4  pop r8
00007fdcd91d36a6  pop rsi
00007fdcd91d36a7  pop rdi
00007fdcd91d36a8  pop rdx
00007fdcd91d36a9  pop rcx
00007fdcd91d36aa  pop rax
00007fdcd91d36ab  add rsp, 0x08
00007fdcd91d36af  jmp 0x00007FDCD91CFF19
00007fdcd91d36b4  sub rsp, 0x08
00007fdcd91d36b8  push rax
00007fdcd91d36b9  push rcx
00007fdcd91d36ba  push rdx
00007fdcd91d36bb  push rdi
00007fdcd91d36bc  push rsi
00007fdcd91d36bd  push r8
00007fdcd91d36bf  push r9
00007fdcd91d36c1  push r10
00007fdcd91d36c3  push r11
00007fdcd91d36c5  sub rsp, 0xF0
00007fdcd91d36cc  vmovaps [rsp], xmm0
00007fdcd91d36d1  vmovaps [rsp+0x10], xmm1
00007fdcd91d36d7  vmovaps [rsp+0x20], xmm2
00007fdcd91d36dd  vmovaps [rsp+0x30], xmm3
00007fdcd91d36e3  vmovaps [rsp+0x40], xmm4
00007fdcd91d36e9  vmovaps [rsp+0x50], xmm5
00007fdcd91d36ef  vmovaps [rsp+0x60], xmm6
00007fdcd91d36f5  vmovaps [rsp+0x70], xmm7
00007fdcd91d36fb  vmovaps [rsp+0x80], xmm8
00007fdcd91d3704  vmovaps [rsp+0x90], xmm9
00007fdcd91d370d  vmovaps [rsp+0xA0], xmm10
00007fdcd91d3716  vmovaps [rsp+0xB0], xmm11
00007fdcd91d371f  vmovaps [rsp+0xC0], xmm13
00007fdcd91d3728  vmovaps [rsp+0xD0], xmm14
00007fdcd91d3731  vmovaps [rsp+0xE0], xmm15
00007fdcd91d373a  sub rsp, 0x30
00007fdcd91d373e  movaps [rsp], xmm12
00007fdcd91d3743  movaps [rsp+0x10], xmm15
00007fdcd91d3749  movaps [rsp+0x20], xmm13
00007fdcd91d374f  lea rdi, [rsp]
00007fdcd91d3753  mov esi, 0x00
00007fdcd91d3758  mov rax, 0x5B56EFBF3530
00007fdcd91d3762  call rax
00007fdcd91d3764  movaps xmm12, [rsp]
00007fdcd91d3769  add rsp, 0x30
00007fdcd91d376d  vmovaps xmm0, [rsp]
00007fdcd91d3772  vmovaps xmm1, [rsp+0x10]
00007fdcd91d3778  vmovaps xmm2, [rsp+0x20]
00007fdcd91d377e  vmovaps xmm3, [rsp+0x30]
00007fdcd91d3784  vmovaps xmm4, [rsp+0x40]
00007fdcd91d378a  vmovaps xmm5, [rsp+0x50]
00007fdcd91d3790  vmovaps xmm6, [rsp+0x60]
00007fdcd91d3796  vmovaps xmm7, [rsp+0x70]
00007fdcd91d379c  vmovaps xmm8, [rsp+0x80]
00007fdcd91d37a5  vmovaps xmm9, [rsp+0x90]
00007fdcd91d37ae  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d37b7  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d37c0  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d37c9  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d37d2  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d37db  add rsp, 0xF0
00007fdcd91d37e2  pop r11
00007fdcd91d37e4  pop r10
00007fdcd91d37e6  pop r9
00007fdcd91d37e8  pop r8
00007fdcd91d37ea  pop rsi
00007fdcd91d37eb  pop rdi
00007fdcd91d37ec  pop rdx
00007fdcd91d37ed  pop rcx
00007fdcd91d37ee  pop rax
00007fdcd91d37ef  add rsp, 0x08
00007fdcd91d37f3  jmp 0x00007FDCD91CFF34
00007fdcd91d37f8  sub rsp, 0x08
00007fdcd91d37fc  push rax
00007fdcd91d37fd  push rcx
00007fdcd91d37fe  push rdx
00007fdcd91d37ff  push rdi
00007fdcd91d3800  push rsi
00007fdcd91d3801  push r8
00007fdcd91d3803  push r9
00007fdcd91d3805  push r10
00007fdcd91d3807  push r11
00007fdcd91d3809  sub rsp, 0xF0
00007fdcd91d3810  vmovaps [rsp], xmm0
00007fdcd91d3815  vmovaps [rsp+0x10], xmm1
00007fdcd91d381b  vmovaps [rsp+0x20], xmm2
00007fdcd91d3821  vmovaps [rsp+0x30], xmm3
00007fdcd91d3827  vmovaps [rsp+0x40], xmm4
00007fdcd91d382d  vmovaps [rsp+0x50], xmm5
00007fdcd91d3833  vmovaps [rsp+0x60], xmm6
00007fdcd91d3839  vmovaps [rsp+0x70], xmm7
00007fdcd91d383f  vmovaps [rsp+0x80], xmm8
00007fdcd91d3848  vmovaps [rsp+0x90], xmm9
00007fdcd91d3851  vmovaps [rsp+0xA0], xmm10
00007fdcd91d385a  vmovaps [rsp+0xB0], xmm11
00007fdcd91d3863  vmovaps [rsp+0xC0], xmm12
00007fdcd91d386c  vmovaps [rsp+0xD0], xmm13
00007fdcd91d3875  vmovaps [rsp+0xE0], xmm14
00007fdcd91d387e  sub rsp, 0x30
00007fdcd91d3882  movaps [rsp], xmm15
00007fdcd91d3887  movaps [rsp+0x10], xmm13
00007fdcd91d388d  movaps [rsp+0x20], xmm10
00007fdcd91d3893  lea rdi, [rsp]
00007fdcd91d3897  mov esi, 0x00
00007fdcd91d389c  mov rax, 0x5B56EFBF3530
00007fdcd91d38a6  call rax
00007fdcd91d38a8  movaps xmm15, [rsp]
00007fdcd91d38ad  add rsp, 0x30
00007fdcd91d38b1  vmovaps xmm0, [rsp]
00007fdcd91d38b6  vmovaps xmm1, [rsp+0x10]
00007fdcd91d38bc  vmovaps xmm2, [rsp+0x20]
00007fdcd91d38c2  vmovaps xmm3, [rsp+0x30]
00007fdcd91d38c8  vmovaps xmm4, [rsp+0x40]
00007fdcd91d38ce  vmovaps xmm5, [rsp+0x50]
00007fdcd91d38d4  vmovaps xmm6, [rsp+0x60]
00007fdcd91d38da  vmovaps xmm7, [rsp+0x70]
00007fdcd91d38e0  vmovaps xmm8, [rsp+0x80]
00007fdcd91d38e9  vmovaps xmm9, [rsp+0x90]
00007fdcd91d38f2  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d38fb  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d3904  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d390d  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d3916  vmovaps xmm14, [rsp+0xE0]
00007fdcd91d391f  add rsp, 0xF0
00007fdcd91d3926  pop r11
00007fdcd91d3928  pop r10
00007fdcd91d392a  pop r9
00007fdcd91d392c  pop r8
00007fdcd91d392e  pop rsi
00007fdcd91d392f  pop rdi
00007fdcd91d3930  pop rdx
00007fdcd91d3931  pop rcx
00007fdcd91d3932  pop rax
00007fdcd91d3933  add rsp, 0x08
00007fdcd91d3937  jmp 0x00007FDCD91CFF55
00007fdcd91d393c  call 0x00007FDCD900C260
00007fdcd91d3941  jmp 0x00007FDCD91CFFB0
00007fdcd91d3946  sub rsp, 0x08
00007fdcd91d394a  push rax
00007fdcd91d394b  push rcx
00007fdcd91d394c  push rdx
00007fdcd91d394d  push rdi
00007fdcd91d394e  push rsi
00007fdcd91d394f  push r8
00007fdcd91d3951  push r9
00007fdcd91d3953  push r10
00007fdcd91d3955  push r11
00007fdcd91d3957  sub rsp, 0xF0
00007fdcd91d395e  vmovaps [rsp], xmm0
00007fdcd91d3963  vmovaps [rsp+0x10], xmm1
00007fdcd91d3969  vmovaps [rsp+0x20], xmm2
00007fdcd91d396f  vmovaps [rsp+0x30], xmm3
00007fdcd91d3975  vmovaps [rsp+0x40], xmm4
00007fdcd91d397b  vmovaps [rsp+0x50], xmm5
00007fdcd91d3981  vmovaps [rsp+0x60], xmm6
00007fdcd91d3987  vmovaps [rsp+0x70], xmm7
00007fdcd91d398d  vmovaps [rsp+0x80], xmm8
00007fdcd91d3996  vmovaps [rsp+0x90], xmm10
00007fdcd91d399f  vmovaps [rsp+0xA0], xmm11
00007fdcd91d39a8  vmovaps [rsp+0xB0], xmm12
00007fdcd91d39b1  vmovaps [rsp+0xC0], xmm13
00007fdcd91d39ba  vmovaps [rsp+0xD0], xmm14
00007fdcd91d39c3  vmovaps [rsp+0xE0], xmm15
00007fdcd91d39cc  sub rsp, 0x30
00007fdcd91d39d0  movaps [rsp], xmm9
00007fdcd91d39d5  movaps [rsp+0x10], xmm8
00007fdcd91d39db  movaps [rsp+0x20], xmm10
00007fdcd91d39e1  lea rdi, [rsp]
00007fdcd91d39e5  mov esi, 0x00
00007fdcd91d39ea  mov rax, 0x5B56EFBF3530
00007fdcd91d39f4  call rax
00007fdcd91d39f6  movaps xmm9, [rsp]
00007fdcd91d39fb  add rsp, 0x30
00007fdcd91d39ff  vmovaps xmm0, [rsp]
00007fdcd91d3a04  vmovaps xmm1, [rsp+0x10]
00007fdcd91d3a0a  vmovaps xmm2, [rsp+0x20]
00007fdcd91d3a10  vmovaps xmm3, [rsp+0x30]
00007fdcd91d3a16  vmovaps xmm4, [rsp+0x40]
00007fdcd91d3a1c  vmovaps xmm5, [rsp+0x50]
00007fdcd91d3a22  vmovaps xmm6, [rsp+0x60]
00007fdcd91d3a28  vmovaps xmm7, [rsp+0x70]
00007fdcd91d3a2e  vmovaps xmm8, [rsp+0x80]
00007fdcd91d3a37  vmovaps xmm10, [rsp+0x90]
00007fdcd91d3a40  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d3a49  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d3a52  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d3a5b  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d3a64  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d3a6d  add rsp, 0xF0
00007fdcd91d3a74  pop r11
00007fdcd91d3a76  pop r10
00007fdcd91d3a78  pop r9
00007fdcd91d3a7a  pop r8
00007fdcd91d3a7c  pop rsi
00007fdcd91d3a7d  pop rdi
00007fdcd91d3a7e  pop rdx
00007fdcd91d3a7f  pop rcx
00007fdcd91d3a80  pop rax
00007fdcd91d3a81  add rsp, 0x08
00007fdcd91d3a85  jmp 0x00007FDCD91CFFE1
00007fdcd91d3a8a  sub rsp, 0x08
00007fdcd91d3a8e  push rax
00007fdcd91d3a8f  push rcx
00007fdcd91d3a90  push rdx
00007fdcd91d3a91  push rdi
00007fdcd91d3a92  push rsi
00007fdcd91d3a93  push r8
00007fdcd91d3a95  push r9
00007fdcd91d3a97  push r10
00007fdcd91d3a99  push r11
00007fdcd91d3a9b  sub rsp, 0xF0
00007fdcd91d3aa2  vmovaps [rsp], xmm0
00007fdcd91d3aa7  vmovaps [rsp+0x10], xmm1
00007fdcd91d3aad  vmovaps [rsp+0x20], xmm2
00007fdcd91d3ab3  vmovaps [rsp+0x30], xmm3
00007fdcd91d3ab9  vmovaps [rsp+0x40], xmm4
00007fdcd91d3abf  vmovaps [rsp+0x50], xmm5
00007fdcd91d3ac5  vmovaps [rsp+0x60], xmm6
00007fdcd91d3acb  vmovaps [rsp+0x70], xmm7
00007fdcd91d3ad1  vmovaps [rsp+0x80], xmm8
00007fdcd91d3ada  vmovaps [rsp+0x90], xmm9
00007fdcd91d3ae3  vmovaps [rsp+0xA0], xmm11
00007fdcd91d3aec  vmovaps [rsp+0xB0], xmm12
00007fdcd91d3af5  vmovaps [rsp+0xC0], xmm13
00007fdcd91d3afe  vmovaps [rsp+0xD0], xmm14
00007fdcd91d3b07  vmovaps [rsp+0xE0], xmm15
00007fdcd91d3b10  sub rsp, 0x30
00007fdcd91d3b14  movaps [rsp], xmm10
00007fdcd91d3b19  movaps [rsp+0x10], xmm1
00007fdcd91d3b1e  movaps [rsp+0x20], xmm11
00007fdcd91d3b24  lea rdi, [rsp]
00007fdcd91d3b28  mov esi, 0x00
00007fdcd91d3b2d  mov rax, 0x5B56EFBF3530
00007fdcd91d3b37  call rax
00007fdcd91d3b39  movaps xmm10, [rsp]
00007fdcd91d3b3e  add rsp, 0x30
00007fdcd91d3b42  vmovaps xmm0, [rsp]
00007fdcd91d3b47  vmovaps xmm1, [rsp+0x10]
00007fdcd91d3b4d  vmovaps xmm2, [rsp+0x20]
00007fdcd91d3b53  vmovaps xmm3, [rsp+0x30]
00007fdcd91d3b59  vmovaps xmm4, [rsp+0x40]
00007fdcd91d3b5f  vmovaps xmm5, [rsp+0x50]
00007fdcd91d3b65  vmovaps xmm6, [rsp+0x60]
00007fdcd91d3b6b  vmovaps xmm7, [rsp+0x70]
00007fdcd91d3b71  vmovaps xmm8, [rsp+0x80]
00007fdcd91d3b7a  vmovaps xmm9, [rsp+0x90]
00007fdcd91d3b83  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d3b8c  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d3b95  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d3b9e  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d3ba7  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d3bb0  add rsp, 0xF0
00007fdcd91d3bb7  pop r11
00007fdcd91d3bb9  pop r10
00007fdcd91d3bbb  pop r9
00007fdcd91d3bbd  pop r8
00007fdcd91d3bbf  pop rsi
00007fdcd91d3bc0  pop rdi
00007fdcd91d3bc1  pop rdx
00007fdcd91d3bc2  pop rcx
00007fdcd91d3bc3  pop rax
00007fdcd91d3bc4  add rsp, 0x08
00007fdcd91d3bc8  jmp 0x00007FDCD91CFFFC
00007fdcd91d3bcd  sub rsp, 0x08
00007fdcd91d3bd1  push rax
00007fdcd91d3bd2  push rcx
00007fdcd91d3bd3  push rdx
00007fdcd91d3bd4  push rdi
00007fdcd91d3bd5  push rsi
00007fdcd91d3bd6  push r8
00007fdcd91d3bd8  push r9
00007fdcd91d3bda  push r10
00007fdcd91d3bdc  push r11
00007fdcd91d3bde  sub rsp, 0xF0
00007fdcd91d3be5  vmovaps [rsp], xmm0
00007fdcd91d3bea  vmovaps [rsp+0x10], xmm2
00007fdcd91d3bf0  vmovaps [rsp+0x20], xmm3
00007fdcd91d3bf6  vmovaps [rsp+0x30], xmm4
00007fdcd91d3bfc  vmovaps [rsp+0x40], xmm5
00007fdcd91d3c02  vmovaps [rsp+0x50], xmm6
00007fdcd91d3c08  vmovaps [rsp+0x60], xmm7
00007fdcd91d3c0e  vmovaps [rsp+0x70], xmm8
00007fdcd91d3c14  vmovaps [rsp+0x80], xmm9
00007fdcd91d3c1d  vmovaps [rsp+0x90], xmm10
00007fdcd91d3c26  vmovaps [rsp+0xA0], xmm11
00007fdcd91d3c2f  vmovaps [rsp+0xB0], xmm12
00007fdcd91d3c38  vmovaps [rsp+0xC0], xmm13
00007fdcd91d3c41  vmovaps [rsp+0xD0], xmm14
00007fdcd91d3c4a  vmovaps [rsp+0xE0], xmm15
00007fdcd91d3c53  sub rsp, 0x30
00007fdcd91d3c57  movaps [rsp], xmm1
00007fdcd91d3c5b  movaps [rsp+0x10], xmm14
00007fdcd91d3c61  movaps [rsp+0x20], xmm6
00007fdcd91d3c66  lea rdi, [rsp]
00007fdcd91d3c6a  mov esi, 0x00
00007fdcd91d3c6f  mov rax, 0x5B56EFBF3530
00007fdcd91d3c79  call rax
00007fdcd91d3c7b  movaps xmm1, [rsp]
00007fdcd91d3c7f  add rsp, 0x30
00007fdcd91d3c83  vmovaps xmm0, [rsp]
00007fdcd91d3c88  vmovaps xmm2, [rsp+0x10]
00007fdcd91d3c8e  vmovaps xmm3, [rsp+0x20]
00007fdcd91d3c94  vmovaps xmm4, [rsp+0x30]
00007fdcd91d3c9a  vmovaps xmm5, [rsp+0x40]
00007fdcd91d3ca0  vmovaps xmm6, [rsp+0x50]
00007fdcd91d3ca6  vmovaps xmm7, [rsp+0x60]
00007fdcd91d3cac  vmovaps xmm8, [rsp+0x70]
00007fdcd91d3cb2  vmovaps xmm9, [rsp+0x80]
00007fdcd91d3cbb  vmovaps xmm10, [rsp+0x90]
00007fdcd91d3cc4  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d3ccd  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d3cd6  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d3cdf  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d3ce8  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d3cf1  add rsp, 0xF0
00007fdcd91d3cf8  pop r11
00007fdcd91d3cfa  pop r10
00007fdcd91d3cfc  pop r9
00007fdcd91d3cfe  pop r8
00007fdcd91d3d00  pop rsi
00007fdcd91d3d01  pop rdi
00007fdcd91d3d02  pop rdx
00007fdcd91d3d03  pop rcx
00007fdcd91d3d04  pop rax
00007fdcd91d3d05  add rsp, 0x08
00007fdcd91d3d09  jmp 0x00007FDCD91D0015
00007fdcd91d3d0e  sub rsp, 0x08
00007fdcd91d3d12  push rax
00007fdcd91d3d13  push rcx
00007fdcd91d3d14  push rdx
00007fdcd91d3d15  push rdi
00007fdcd91d3d16  push rsi
00007fdcd91d3d17  push r8
00007fdcd91d3d19  push r9
00007fdcd91d3d1b  push r10
00007fdcd91d3d1d  push r11
00007fdcd91d3d1f  sub rsp, 0xF0
00007fdcd91d3d26  vmovaps [rsp], xmm0
00007fdcd91d3d2b  vmovaps [rsp+0x10], xmm1
00007fdcd91d3d31  vmovaps [rsp+0x20], xmm2
00007fdcd91d3d37  vmovaps [rsp+0x30], xmm3
00007fdcd91d3d3d  vmovaps [rsp+0x40], xmm4
00007fdcd91d3d43  vmovaps [rsp+0x50], xmm5
00007fdcd91d3d49  vmovaps [rsp+0x60], xmm6
00007fdcd91d3d4f  vmovaps [rsp+0x70], xmm7
00007fdcd91d3d55  vmovaps [rsp+0x80], xmm8
00007fdcd91d3d5e  vmovaps [rsp+0x90], xmm9
00007fdcd91d3d67  vmovaps [rsp+0xA0], xmm10
00007fdcd91d3d70  vmovaps [rsp+0xB0], xmm12
00007fdcd91d3d79  vmovaps [rsp+0xC0], xmm13
00007fdcd91d3d82  vmovaps [rsp+0xD0], xmm14
00007fdcd91d3d8b  vmovaps [rsp+0xE0], xmm15
00007fdcd91d3d94  sub rsp, 0x30
00007fdcd91d3d98  movaps [rsp], xmm11
00007fdcd91d3d9d  movaps [rsp+0x10], xmm13
00007fdcd91d3da3  movaps [rsp+0x20], xmm14
00007fdcd91d3da9  lea rdi, [rsp]
00007fdcd91d3dad  mov esi, 0x00
00007fdcd91d3db2  mov rax, 0x5B56EFBF3530
00007fdcd91d3dbc  call rax
00007fdcd91d3dbe  movaps xmm11, [rsp]
00007fdcd91d3dc3  add rsp, 0x30
00007fdcd91d3dc7  vmovaps xmm0, [rsp]
00007fdcd91d3dcc  vmovaps xmm1, [rsp+0x10]
00007fdcd91d3dd2  vmovaps xmm2, [rsp+0x20]
00007fdcd91d3dd8  vmovaps xmm3, [rsp+0x30]
00007fdcd91d3dde  vmovaps xmm4, [rsp+0x40]
00007fdcd91d3de4  vmovaps xmm5, [rsp+0x50]
00007fdcd91d3dea  vmovaps xmm6, [rsp+0x60]
00007fdcd91d3df0  vmovaps xmm7, [rsp+0x70]
00007fdcd91d3df6  vmovaps xmm8, [rsp+0x80]
00007fdcd91d3dff  vmovaps xmm9, [rsp+0x90]
00007fdcd91d3e08  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d3e11  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d3e1a  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d3e23  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d3e2c  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d3e35  add rsp, 0xF0
00007fdcd91d3e3c  pop r11
00007fdcd91d3e3e  pop r10
00007fdcd91d3e40  pop r9
00007fdcd91d3e42  pop r8
00007fdcd91d3e44  pop rsi
00007fdcd91d3e45  pop rdi
00007fdcd91d3e46  pop rdx
00007fdcd91d3e47  pop rcx
00007fdcd91d3e48  pop rax
00007fdcd91d3e49  add rsp, 0x08
00007fdcd91d3e4d  jmp 0x00007FDCD91D003F
00007fdcd91d3e52  sub rsp, 0x08
00007fdcd91d3e56  push rax
00007fdcd91d3e57  push rcx
00007fdcd91d3e58  push rdx
00007fdcd91d3e59  push rdi
00007fdcd91d3e5a  push rsi
00007fdcd91d3e5b  push r8
00007fdcd91d3e5d  push r9
00007fdcd91d3e5f  push r10
00007fdcd91d3e61  push r11
00007fdcd91d3e63  sub rsp, 0xF0
00007fdcd91d3e6a  vmovaps [rsp], xmm0
00007fdcd91d3e6f  vmovaps [rsp+0x10], xmm1
00007fdcd91d3e75  vmovaps [rsp+0x20], xmm2
00007fdcd91d3e7b  vmovaps [rsp+0x30], xmm3
00007fdcd91d3e81  vmovaps [rsp+0x40], xmm4
00007fdcd91d3e87  vmovaps [rsp+0x50], xmm5
00007fdcd91d3e8d  vmovaps [rsp+0x60], xmm6
00007fdcd91d3e93  vmovaps [rsp+0x70], xmm7
00007fdcd91d3e99  vmovaps [rsp+0x80], xmm8
00007fdcd91d3ea2  vmovaps [rsp+0x90], xmm9
00007fdcd91d3eab  vmovaps [rsp+0xA0], xmm10
00007fdcd91d3eb4  vmovaps [rsp+0xB0], xmm11
00007fdcd91d3ebd  vmovaps [rsp+0xC0], xmm12
00007fdcd91d3ec6  vmovaps [rsp+0xD0], xmm14
00007fdcd91d3ecf  vmovaps [rsp+0xE0], xmm15
00007fdcd91d3ed8  sub rsp, 0x30
00007fdcd91d3edc  movaps [rsp], xmm13
00007fdcd91d3ee1  movaps [rsp+0x10], xmm8
00007fdcd91d3ee7  movaps [rsp+0x20], xmm14
00007fdcd91d3eed  lea rdi, [rsp]
00007fdcd91d3ef1  mov esi, 0x00
00007fdcd91d3ef6  mov rax, 0x5B56EFBF3530
00007fdcd91d3f00  call rax
00007fdcd91d3f02  movaps xmm13, [rsp]
00007fdcd91d3f07  add rsp, 0x30
00007fdcd91d3f0b  vmovaps xmm0, [rsp]
00007fdcd91d3f10  vmovaps xmm1, [rsp+0x10]
00007fdcd91d3f16  vmovaps xmm2, [rsp+0x20]
00007fdcd91d3f1c  vmovaps xmm3, [rsp+0x30]
00007fdcd91d3f22  vmovaps xmm4, [rsp+0x40]
00007fdcd91d3f28  vmovaps xmm5, [rsp+0x50]
00007fdcd91d3f2e  vmovaps xmm6, [rsp+0x60]
00007fdcd91d3f34  vmovaps xmm7, [rsp+0x70]
00007fdcd91d3f3a  vmovaps xmm8, [rsp+0x80]
00007fdcd91d3f43  vmovaps xmm9, [rsp+0x90]
00007fdcd91d3f4c  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d3f55  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d3f5e  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d3f67  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d3f70  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d3f79  add rsp, 0xF0
00007fdcd91d3f80  pop r11
00007fdcd91d3f82  pop r10
00007fdcd91d3f84  pop r9
00007fdcd91d3f86  pop r8
00007fdcd91d3f88  pop rsi
00007fdcd91d3f89  pop rdi
00007fdcd91d3f8a  pop rdx
00007fdcd91d3f8b  pop rcx
00007fdcd91d3f8c  pop rax
00007fdcd91d3f8d  add rsp, 0x08
00007fdcd91d3f91  jmp 0x00007FDCD91D006E
00007fdcd91d3f96  sub rsp, 0x08
00007fdcd91d3f9a  push rax
00007fdcd91d3f9b  push rcx
00007fdcd91d3f9c  push rdx
00007fdcd91d3f9d  push rdi
00007fdcd91d3f9e  push rsi
00007fdcd91d3f9f  push r8
00007fdcd91d3fa1  push r9
00007fdcd91d3fa3  push r10
00007fdcd91d3fa5  push r11
00007fdcd91d3fa7  sub rsp, 0xF0
00007fdcd91d3fae  vmovaps [rsp], xmm0
00007fdcd91d3fb3  vmovaps [rsp+0x10], xmm1
00007fdcd91d3fb9  vmovaps [rsp+0x20], xmm2
00007fdcd91d3fbf  vmovaps [rsp+0x30], xmm3
00007fdcd91d3fc5  vmovaps [rsp+0x40], xmm4
00007fdcd91d3fcb  vmovaps [rsp+0x50], xmm5
00007fdcd91d3fd1  vmovaps [rsp+0x60], xmm6
00007fdcd91d3fd7  vmovaps [rsp+0x70], xmm7
00007fdcd91d3fdd  vmovaps [rsp+0x80], xmm9
00007fdcd91d3fe6  vmovaps [rsp+0x90], xmm10
00007fdcd91d3fef  vmovaps [rsp+0xA0], xmm11
00007fdcd91d3ff8  vmovaps [rsp+0xB0], xmm12
00007fdcd91d4001  vmovaps [rsp+0xC0], xmm13
00007fdcd91d400a  vmovaps [rsp+0xD0], xmm14
00007fdcd91d4013  vmovaps [rsp+0xE0], xmm15
00007fdcd91d401c  sub rsp, 0x30
00007fdcd91d4020  movaps [rsp], xmm8
00007fdcd91d4025  movaps [rsp+0x10], xmm7
00007fdcd91d402a  movaps [rsp+0x20], xmm14
00007fdcd91d4030  lea rdi, [rsp]
00007fdcd91d4034  mov esi, 0x00
00007fdcd91d4039  mov rax, 0x5B56EFBF3530
00007fdcd91d4043  call rax
00007fdcd91d4045  movaps xmm8, [rsp]
00007fdcd91d404a  add rsp, 0x30
00007fdcd91d404e  vmovaps xmm0, [rsp]
00007fdcd91d4053  vmovaps xmm1, [rsp+0x10]
00007fdcd91d4059  vmovaps xmm2, [rsp+0x20]
00007fdcd91d405f  vmovaps xmm3, [rsp+0x30]
00007fdcd91d4065  vmovaps xmm4, [rsp+0x40]
00007fdcd91d406b  vmovaps xmm5, [rsp+0x50]
00007fdcd91d4071  vmovaps xmm6, [rsp+0x60]
00007fdcd91d4077  vmovaps xmm7, [rsp+0x70]
00007fdcd91d407d  vmovaps xmm9, [rsp+0x80]
00007fdcd91d4086  vmovaps xmm10, [rsp+0x90]
00007fdcd91d408f  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d4098  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d40a1  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d40aa  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d40b3  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d40bc  add rsp, 0xF0
00007fdcd91d40c3  pop r11
00007fdcd91d40c5  pop r10
00007fdcd91d40c7  pop r9
00007fdcd91d40c9  pop r8
00007fdcd91d40cb  pop rsi
00007fdcd91d40cc  pop rdi
00007fdcd91d40cd  pop rdx
00007fdcd91d40ce  pop rcx
00007fdcd91d40cf  pop rax
00007fdcd91d40d0  add rsp, 0x08
00007fdcd91d40d4  jmp 0x00007FDCD91D0094
00007fdcd91d40d9  sub rsp, 0x08
00007fdcd91d40dd  push rax
00007fdcd91d40de  push rcx
00007fdcd91d40df  push rdx
00007fdcd91d40e0  push rdi
00007fdcd91d40e1  push rsi
00007fdcd91d40e2  push r8
00007fdcd91d40e4  push r9
00007fdcd91d40e6  push r10
00007fdcd91d40e8  push r11
00007fdcd91d40ea  sub rsp, 0xF0
00007fdcd91d40f1  vmovaps [rsp], xmm0
00007fdcd91d40f6  vmovaps [rsp+0x10], xmm1
00007fdcd91d40fc  vmovaps [rsp+0x20], xmm2
00007fdcd91d4102  vmovaps [rsp+0x30], xmm3
00007fdcd91d4108  vmovaps [rsp+0x40], xmm4
00007fdcd91d410e  vmovaps [rsp+0x50], xmm5
00007fdcd91d4114  vmovaps [rsp+0x60], xmm6
00007fdcd91d411a  vmovaps [rsp+0x70], xmm7
00007fdcd91d4120  vmovaps [rsp+0x80], xmm8
00007fdcd91d4129  vmovaps [rsp+0x90], xmm9
00007fdcd91d4132  vmovaps [rsp+0xA0], xmm10
00007fdcd91d413b  vmovaps [rsp+0xB0], xmm11
00007fdcd91d4144  vmovaps [rsp+0xC0], xmm12
00007fdcd91d414d  vmovaps [rsp+0xD0], xmm13
00007fdcd91d4156  vmovaps [rsp+0xE0], xmm15
00007fdcd91d415f  sub rsp, 0x30
00007fdcd91d4163  movaps [rsp], xmm14
00007fdcd91d4168  movaps [rsp+0x10], xmm12
00007fdcd91d416e  movaps [rsp+0x20], xmm9
00007fdcd91d4174  lea rdi, [rsp]
00007fdcd91d4178  mov esi, 0x00
00007fdcd91d417d  mov rax, 0x5B56EFBF3530
00007fdcd91d4187  call rax
00007fdcd91d4189  movaps xmm14, [rsp]
00007fdcd91d418e  add rsp, 0x30
00007fdcd91d4192  vmovaps xmm0, [rsp]
00007fdcd91d4197  vmovaps xmm1, [rsp+0x10]
00007fdcd91d419d  vmovaps xmm2, [rsp+0x20]
00007fdcd91d41a3  vmovaps xmm3, [rsp+0x30]
00007fdcd91d41a9  vmovaps xmm4, [rsp+0x40]
00007fdcd91d41af  vmovaps xmm5, [rsp+0x50]
00007fdcd91d41b5  vmovaps xmm6, [rsp+0x60]
00007fdcd91d41bb  vmovaps xmm7, [rsp+0x70]
00007fdcd91d41c1  vmovaps xmm8, [rsp+0x80]
00007fdcd91d41ca  vmovaps xmm9, [rsp+0x90]
00007fdcd91d41d3  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d41dc  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d41e5  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d41ee  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d41f7  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d4200  add rsp, 0xF0
00007fdcd91d4207  pop r11
00007fdcd91d4209  pop r10
00007fdcd91d420b  pop r9
00007fdcd91d420d  pop r8
00007fdcd91d420f  pop rsi
00007fdcd91d4210  pop rdi
00007fdcd91d4211  pop rdx
00007fdcd91d4212  pop rcx
00007fdcd91d4213  pop rax
00007fdcd91d4214  add rsp, 0x08
00007fdcd91d4218  jmp 0x00007FDCD91D00AE
00007fdcd91d421d  sub rsp, 0x08
00007fdcd91d4221  push rax
00007fdcd91d4222  push rcx
00007fdcd91d4223  push rdx
00007fdcd91d4224  push rdi
00007fdcd91d4225  push rsi
00007fdcd91d4226  push r8
00007fdcd91d4228  push r9
00007fdcd91d422a  push r10
00007fdcd91d422c  push r11
00007fdcd91d422e  sub rsp, 0xF0
00007fdcd91d4235  vmovaps [rsp], xmm0
00007fdcd91d423a  vmovaps [rsp+0x10], xmm1
00007fdcd91d4240  vmovaps [rsp+0x20], xmm2
00007fdcd91d4246  vmovaps [rsp+0x30], xmm3
00007fdcd91d424c  vmovaps [rsp+0x40], xmm4
00007fdcd91d4252  vmovaps [rsp+0x50], xmm5
00007fdcd91d4258  vmovaps [rsp+0x60], xmm6
00007fdcd91d425e  vmovaps [rsp+0x70], xmm7
00007fdcd91d4264  vmovaps [rsp+0x80], xmm8
00007fdcd91d426d  vmovaps [rsp+0x90], xmm10
00007fdcd91d4276  vmovaps [rsp+0xA0], xmm11
00007fdcd91d427f  vmovaps [rsp+0xB0], xmm12
00007fdcd91d4288  vmovaps [rsp+0xC0], xmm13
00007fdcd91d4291  vmovaps [rsp+0xD0], xmm14
00007fdcd91d429a  vmovaps [rsp+0xE0], xmm15
00007fdcd91d42a3  sub rsp, 0x30
00007fdcd91d42a7  movaps [rsp], xmm9
00007fdcd91d42ac  movaps [rsp+0x10], xmm7
00007fdcd91d42b1  movaps [rsp+0x20], xmm12
00007fdcd91d42b7  lea rdi, [rsp]
00007fdcd91d42bb  mov esi, 0x00
00007fdcd91d42c0  mov rax, 0x5B56EFBF3530
00007fdcd91d42ca  call rax
00007fdcd91d42cc  movaps xmm9, [rsp]
00007fdcd91d42d1  add rsp, 0x30
00007fdcd91d42d5  vmovaps xmm0, [rsp]
00007fdcd91d42da  vmovaps xmm1, [rsp+0x10]
00007fdcd91d42e0  vmovaps xmm2, [rsp+0x20]
00007fdcd91d42e6  vmovaps xmm3, [rsp+0x30]
00007fdcd91d42ec  vmovaps xmm4, [rsp+0x40]
00007fdcd91d42f2  vmovaps xmm5, [rsp+0x50]
00007fdcd91d42f8  vmovaps xmm6, [rsp+0x60]
00007fdcd91d42fe  vmovaps xmm7, [rsp+0x70]
00007fdcd91d4304  vmovaps xmm8, [rsp+0x80]
00007fdcd91d430d  vmovaps xmm10, [rsp+0x90]
00007fdcd91d4316  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d431f  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d4328  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d4331  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d433a  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d4343  add rsp, 0xF0
00007fdcd91d434a  pop r11
00007fdcd91d434c  pop r10
00007fdcd91d434e  pop r9
00007fdcd91d4350  pop r8
00007fdcd91d4352  pop rsi
00007fdcd91d4353  pop rdi
00007fdcd91d4354  pop rdx
00007fdcd91d4355  pop rcx
00007fdcd91d4356  pop rax
00007fdcd91d4357  add rsp, 0x08
00007fdcd91d435b  jmp 0x00007FDCD91D00DD
00007fdcd91d4360  sub rsp, 0x08
00007fdcd91d4364  push rax
00007fdcd91d4365  push rcx
00007fdcd91d4366  push rdx
00007fdcd91d4367  push rdi
00007fdcd91d4368  push rsi
00007fdcd91d4369  push r8
00007fdcd91d436b  push r9
00007fdcd91d436d  push r10
00007fdcd91d436f  push r11
00007fdcd91d4371  sub rsp, 0xF0
00007fdcd91d4378  vmovaps [rsp], xmm0
00007fdcd91d437d  vmovaps [rsp+0x10], xmm1
00007fdcd91d4383  vmovaps [rsp+0x20], xmm2
00007fdcd91d4389  vmovaps [rsp+0x30], xmm3
00007fdcd91d438f  vmovaps [rsp+0x40], xmm4
00007fdcd91d4395  vmovaps [rsp+0x50], xmm5
00007fdcd91d439b  vmovaps [rsp+0x60], xmm6
00007fdcd91d43a1  vmovaps [rsp+0x70], xmm7
00007fdcd91d43a7  vmovaps [rsp+0x80], xmm8
00007fdcd91d43b0  vmovaps [rsp+0x90], xmm9
00007fdcd91d43b9  vmovaps [rsp+0xA0], xmm10
00007fdcd91d43c2  vmovaps [rsp+0xB0], xmm11
00007fdcd91d43cb  vmovaps [rsp+0xC0], xmm13
00007fdcd91d43d4  vmovaps [rsp+0xD0], xmm14
00007fdcd91d43dd  vmovaps [rsp+0xE0], xmm15
00007fdcd91d43e6  sub rsp, 0x30
00007fdcd91d43ea  movaps [rsp], xmm12
00007fdcd91d43ef  movaps [rsp+0x10], xmm15
00007fdcd91d43f5  movaps [rsp+0x20], xmm11
00007fdcd91d43fb  lea rdi, [rsp]
00007fdcd91d43ff  mov esi, 0x00
00007fdcd91d4404  mov rax, 0x5B56EFBF3530
00007fdcd91d440e  call rax
00007fdcd91d4410  movaps xmm12, [rsp]
00007fdcd91d4415  add rsp, 0x30
00007fdcd91d4419  vmovaps xmm0, [rsp]
00007fdcd91d441e  vmovaps xmm1, [rsp+0x10]
00007fdcd91d4424  vmovaps xmm2, [rsp+0x20]
00007fdcd91d442a  vmovaps xmm3, [rsp+0x30]
00007fdcd91d4430  vmovaps xmm4, [rsp+0x40]
00007fdcd91d4436  vmovaps xmm5, [rsp+0x50]
00007fdcd91d443c  vmovaps xmm6, [rsp+0x60]
00007fdcd91d4442  vmovaps xmm7, [rsp+0x70]
00007fdcd91d4448  vmovaps xmm8, [rsp+0x80]
00007fdcd91d4451  vmovaps xmm9, [rsp+0x90]
00007fdcd91d445a  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d4463  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d446c  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d4475  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d447e  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d4487  add rsp, 0xF0
00007fdcd91d448e  pop r11
00007fdcd91d4490  pop r10
00007fdcd91d4492  pop r9
00007fdcd91d4494  pop r8
00007fdcd91d4496  pop rsi
00007fdcd91d4497  pop rdi
00007fdcd91d4498  pop rdx
00007fdcd91d4499  pop rcx
00007fdcd91d449a  pop rax
00007fdcd91d449b  add rsp, 0x08
00007fdcd91d449f  jmp 0x00007FDCD91D00F7
00007fdcd91d44a4  sub rsp, 0x08
00007fdcd91d44a8  push rax
00007fdcd91d44a9  push rcx
00007fdcd91d44aa  push rdx
00007fdcd91d44ab  push rdi
00007fdcd91d44ac  push rsi
00007fdcd91d44ad  push r8
00007fdcd91d44af  push r9
00007fdcd91d44b1  push r10
00007fdcd91d44b3  push r11
00007fdcd91d44b5  sub rsp, 0xF0
00007fdcd91d44bc  vmovaps [rsp], xmm0
00007fdcd91d44c1  vmovaps [rsp+0x10], xmm1
00007fdcd91d44c7  vmovaps [rsp+0x20], xmm2
00007fdcd91d44cd  vmovaps [rsp+0x30], xmm3
00007fdcd91d44d3  vmovaps [rsp+0x40], xmm4
00007fdcd91d44d9  vmovaps [rsp+0x50], xmm5
00007fdcd91d44df  vmovaps [rsp+0x60], xmm6
00007fdcd91d44e5  vmovaps [rsp+0x70], xmm7
00007fdcd91d44eb  vmovaps [rsp+0x80], xmm8
00007fdcd91d44f4  vmovaps [rsp+0x90], xmm9
00007fdcd91d44fd  vmovaps [rsp+0xA0], xmm10
00007fdcd91d4506  vmovaps [rsp+0xB0], xmm12
00007fdcd91d450f  vmovaps [rsp+0xC0], xmm13
00007fdcd91d4518  vmovaps [rsp+0xD0], xmm14
00007fdcd91d4521  vmovaps [rsp+0xE0], xmm15
00007fdcd91d452a  sub rsp, 0x30
00007fdcd91d452e  movaps [rsp], xmm11
00007fdcd91d4533  movaps [rsp+0x10], xmm7
00007fdcd91d4538  movaps [rsp+0x20], xmm15
00007fdcd91d453e  lea rdi, [rsp]
00007fdcd91d4542  mov esi, 0x00
00007fdcd91d4547  mov rax, 0x5B56EFBF3530
00007fdcd91d4551  call rax
00007fdcd91d4553  movaps xmm11, [rsp]
00007fdcd91d4558  add rsp, 0x30
00007fdcd91d455c  vmovaps xmm0, [rsp]
00007fdcd91d4561  vmovaps xmm1, [rsp+0x10]
00007fdcd91d4567  vmovaps xmm2, [rsp+0x20]
00007fdcd91d456d  vmovaps xmm3, [rsp+0x30]
00007fdcd91d4573  vmovaps xmm4, [rsp+0x40]
00007fdcd91d4579  vmovaps xmm5, [rsp+0x50]
00007fdcd91d457f  vmovaps xmm6, [rsp+0x60]
00007fdcd91d4585  vmovaps xmm7, [rsp+0x70]
00007fdcd91d458b  vmovaps xmm8, [rsp+0x80]
00007fdcd91d4594  vmovaps xmm9, [rsp+0x90]
00007fdcd91d459d  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d45a6  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d45af  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d45b8  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d45c1  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d45ca  add rsp, 0xF0
00007fdcd91d45d1  pop r11
00007fdcd91d45d3  pop r10
00007fdcd91d45d5  pop r9
00007fdcd91d45d7  pop r8
00007fdcd91d45d9  pop rsi
00007fdcd91d45da  pop rdi
00007fdcd91d45db  pop rdx
00007fdcd91d45dc  pop rcx
00007fdcd91d45dd  pop rax
00007fdcd91d45de  add rsp, 0x08
00007fdcd91d45e2  jmp 0x00007FDCD91D0123
00007fdcd91d45e7  sub rsp, 0x08
00007fdcd91d45eb  push rax
00007fdcd91d45ec  push rcx
00007fdcd91d45ed  push rdx
00007fdcd91d45ee  push rdi
00007fdcd91d45ef  push rsi
00007fdcd91d45f0  push r8
00007fdcd91d45f2  push r9
00007fdcd91d45f4  push r10
00007fdcd91d45f6  push r11
00007fdcd91d45f8  sub rsp, 0xF0
00007fdcd91d45ff  vmovaps [rsp], xmm0
00007fdcd91d4604  vmovaps [rsp+0x10], xmm1
00007fdcd91d460a  vmovaps [rsp+0x20], xmm2
00007fdcd91d4610  vmovaps [rsp+0x30], xmm3
00007fdcd91d4616  vmovaps [rsp+0x40], xmm4
00007fdcd91d461c  vmovaps [rsp+0x50], xmm5
00007fdcd91d4622  vmovaps [rsp+0x60], xmm6
00007fdcd91d4628  vmovaps [rsp+0x70], xmm7
00007fdcd91d462e  vmovaps [rsp+0x80], xmm8
00007fdcd91d4637  vmovaps [rsp+0x90], xmm9
00007fdcd91d4640  vmovaps [rsp+0xA0], xmm10
00007fdcd91d4649  vmovaps [rsp+0xB0], xmm11
00007fdcd91d4652  vmovaps [rsp+0xC0], xmm12
00007fdcd91d465b  vmovaps [rsp+0xD0], xmm13
00007fdcd91d4664  vmovaps [rsp+0xE0], xmm14
00007fdcd91d466d  sub rsp, 0x30
00007fdcd91d4671  movaps [rsp], xmm15
00007fdcd91d4676  movaps [rsp+0x10], xmm10
00007fdcd91d467c  movaps [rsp+0x20], xmm13
00007fdcd91d4682  lea rdi, [rsp]
00007fdcd91d4686  mov esi, 0x00
00007fdcd91d468b  mov rax, 0x5B56EFBF3530
00007fdcd91d4695  call rax
00007fdcd91d4697  movaps xmm15, [rsp]
00007fdcd91d469c  add rsp, 0x30
00007fdcd91d46a0  vmovaps xmm0, [rsp]
00007fdcd91d46a5  vmovaps xmm1, [rsp+0x10]
00007fdcd91d46ab  vmovaps xmm2, [rsp+0x20]
00007fdcd91d46b1  vmovaps xmm3, [rsp+0x30]
00007fdcd91d46b7  vmovaps xmm4, [rsp+0x40]
00007fdcd91d46bd  vmovaps xmm5, [rsp+0x50]
00007fdcd91d46c3  vmovaps xmm6, [rsp+0x60]
00007fdcd91d46c9  vmovaps xmm7, [rsp+0x70]
00007fdcd91d46cf  vmovaps xmm8, [rsp+0x80]
00007fdcd91d46d8  vmovaps xmm9, [rsp+0x90]
00007fdcd91d46e1  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d46ea  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d46f3  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d46fc  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d4705  vmovaps xmm14, [rsp+0xE0]
00007fdcd91d470e  add rsp, 0xF0
00007fdcd91d4715  pop r11
00007fdcd91d4717  pop r10
00007fdcd91d4719  pop r9
00007fdcd91d471b  pop r8
00007fdcd91d471d  pop rsi
00007fdcd91d471e  pop rdi
00007fdcd91d471f  pop rdx
00007fdcd91d4720  pop rcx
00007fdcd91d4721  pop rax
00007fdcd91d4722  add rsp, 0x08
00007fdcd91d4726  jmp 0x00007FDCD91D013D
00007fdcd91d472b  sub rsp, 0x08
00007fdcd91d472f  push rax
00007fdcd91d4730  push rcx
00007fdcd91d4731  push rdx
00007fdcd91d4732  push rdi
00007fdcd91d4733  push rsi
00007fdcd91d4734  push r8
00007fdcd91d4736  push r9
00007fdcd91d4738  push r10
00007fdcd91d473a  push r11
00007fdcd91d473c  sub rsp, 0xF0
00007fdcd91d4743  vmovaps [rsp], xmm0
00007fdcd91d4748  vmovaps [rsp+0x10], xmm1
00007fdcd91d474e  vmovaps [rsp+0x20], xmm2
00007fdcd91d4754  vmovaps [rsp+0x30], xmm3
00007fdcd91d475a  vmovaps [rsp+0x40], xmm4
00007fdcd91d4760  vmovaps [rsp+0x50], xmm5
00007fdcd91d4766  vmovaps [rsp+0x60], xmm6
00007fdcd91d476c  vmovaps [rsp+0x70], xmm7
00007fdcd91d4772  vmovaps [rsp+0x80], xmm8
00007fdcd91d477b  vmovaps [rsp+0x90], xmm9
00007fdcd91d4784  vmovaps [rsp+0xA0], xmm11
00007fdcd91d478d  vmovaps [rsp+0xB0], xmm12
00007fdcd91d4796  vmovaps [rsp+0xC0], xmm13
00007fdcd91d479f  vmovaps [rsp+0xD0], xmm14
00007fdcd91d47a8  vmovaps [rsp+0xE0], xmm15
00007fdcd91d47b1  sub rsp, 0x30
00007fdcd91d47b5  movaps [rsp], xmm10
00007fdcd91d47ba  movaps [rsp+0x10], xmm7
00007fdcd91d47bf  movaps [rsp+0x20], xmm13
00007fdcd91d47c5  lea rdi, [rsp]
00007fdcd91d47c9  mov esi, 0x00
00007fdcd91d47ce  mov rax, 0x5B56EFBF3530
00007fdcd91d47d8  call rax
00007fdcd91d47da  movaps xmm10, [rsp]
00007fdcd91d47df  add rsp, 0x30
00007fdcd91d47e3  vmovaps xmm0, [rsp]
00007fdcd91d47e8  vmovaps xmm1, [rsp+0x10]
00007fdcd91d47ee  vmovaps xmm2, [rsp+0x20]
00007fdcd91d47f4  vmovaps xmm3, [rsp+0x30]
00007fdcd91d47fa  vmovaps xmm4, [rsp+0x40]
00007fdcd91d4800  vmovaps xmm5, [rsp+0x50]
00007fdcd91d4806  vmovaps xmm6, [rsp+0x60]
00007fdcd91d480c  vmovaps xmm7, [rsp+0x70]
00007fdcd91d4812  vmovaps xmm8, [rsp+0x80]
00007fdcd91d481b  vmovaps xmm9, [rsp+0x90]
00007fdcd91d4824  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d482d  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d4836  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d483f  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d4848  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d4851  add rsp, 0xF0
00007fdcd91d4858  pop r11
00007fdcd91d485a  pop r10
00007fdcd91d485c  pop r9
00007fdcd91d485e  pop r8
00007fdcd91d4860  pop rsi
00007fdcd91d4861  pop rdi
00007fdcd91d4862  pop rdx
00007fdcd91d4863  pop rcx
00007fdcd91d4864  pop rax
00007fdcd91d4865  add rsp, 0x08
00007fdcd91d4869  jmp 0x00007FDCD91D0169
00007fdcd91d486e  sub rsp, 0x08
00007fdcd91d4872  push rax
00007fdcd91d4873  push rcx
00007fdcd91d4874  push rdx
00007fdcd91d4875  push rdi
00007fdcd91d4876  push rsi
00007fdcd91d4877  push r8
00007fdcd91d4879  push r9
00007fdcd91d487b  push r10
00007fdcd91d487d  push r11
00007fdcd91d487f  sub rsp, 0xF0
00007fdcd91d4886  vmovaps [rsp], xmm0
00007fdcd91d488b  vmovaps [rsp+0x10], xmm1
00007fdcd91d4891  vmovaps [rsp+0x20], xmm2
00007fdcd91d4897  vmovaps [rsp+0x30], xmm3
00007fdcd91d489d  vmovaps [rsp+0x40], xmm4
00007fdcd91d48a3  vmovaps [rsp+0x50], xmm5
00007fdcd91d48a9  vmovaps [rsp+0x60], xmm6
00007fdcd91d48af  vmovaps [rsp+0x70], xmm7
00007fdcd91d48b5  vmovaps [rsp+0x80], xmm8
00007fdcd91d48be  vmovaps [rsp+0x90], xmm9
00007fdcd91d48c7  vmovaps [rsp+0xA0], xmm10
00007fdcd91d48d0  vmovaps [rsp+0xB0], xmm11
00007fdcd91d48d9  vmovaps [rsp+0xC0], xmm12
00007fdcd91d48e2  vmovaps [rsp+0xD0], xmm14
00007fdcd91d48eb  vmovaps [rsp+0xE0], xmm15
00007fdcd91d48f4  sub rsp, 0x30
00007fdcd91d48f8  movaps [rsp], xmm13
00007fdcd91d48fd  movaps [rsp+0x10], xmm1
00007fdcd91d4902  movaps [rsp+0x20], xmm8
00007fdcd91d4908  lea rdi, [rsp]
00007fdcd91d490c  mov esi, 0x00
00007fdcd91d4911  mov rax, 0x5B56EFBF3530
00007fdcd91d491b  call rax
00007fdcd91d491d  movaps xmm13, [rsp]
00007fdcd91d4922  add rsp, 0x30
00007fdcd91d4926  vmovaps xmm0, [rsp]
00007fdcd91d492b  vmovaps xmm1, [rsp+0x10]
00007fdcd91d4931  vmovaps xmm2, [rsp+0x20]
00007fdcd91d4937  vmovaps xmm3, [rsp+0x30]
00007fdcd91d493d  vmovaps xmm4, [rsp+0x40]
00007fdcd91d4943  vmovaps xmm5, [rsp+0x50]
00007fdcd91d4949  vmovaps xmm6, [rsp+0x60]
00007fdcd91d494f  vmovaps xmm7, [rsp+0x70]
00007fdcd91d4955  vmovaps xmm8, [rsp+0x80]
00007fdcd91d495e  vmovaps xmm9, [rsp+0x90]
00007fdcd91d4967  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d4970  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d4979  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d4982  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d498b  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d4994  add rsp, 0xF0
00007fdcd91d499b  pop r11
00007fdcd91d499d  pop r10
00007fdcd91d499f  pop r9
00007fdcd91d49a1  pop r8
00007fdcd91d49a3  pop rsi
00007fdcd91d49a4  pop rdi
00007fdcd91d49a5  pop rdx
00007fdcd91d49a6  pop rcx
00007fdcd91d49a7  pop rax
00007fdcd91d49a8  add rsp, 0x08
00007fdcd91d49ac  jmp 0x00007FDCD91D0183
00007fdcd91d49b1  call 0x00007FDCD8FFF430
00007fdcd91d49b6  jmp 0x00007FDCD91D018D
00007fdcd91d49bb  sub rsp, 0x08
00007fdcd91d49bf  push rax
00007fdcd91d49c0  push rcx
00007fdcd91d49c1  push rdx
00007fdcd91d49c2  push rdi
00007fdcd91d49c3  push rsi
00007fdcd91d49c4  push r8
00007fdcd91d49c6  push r9
00007fdcd91d49c8  push r10
00007fdcd91d49ca  push r11
00007fdcd91d49cc  sub rsp, 0xF0
00007fdcd91d49d3  vmovaps [rsp], xmm0
00007fdcd91d49d8  vmovaps [rsp+0x10], xmm1
00007fdcd91d49de  vmovaps [rsp+0x20], xmm2
00007fdcd91d49e4  vmovaps [rsp+0x30], xmm3
00007fdcd91d49ea  vmovaps [rsp+0x40], xmm4
00007fdcd91d49f0  vmovaps [rsp+0x50], xmm5
00007fdcd91d49f6  vmovaps [rsp+0x60], xmm6
00007fdcd91d49fc  vmovaps [rsp+0x70], xmm7
00007fdcd91d4a02  vmovaps [rsp+0x80], xmm9
00007fdcd91d4a0b  vmovaps [rsp+0x90], xmm10
00007fdcd91d4a14  vmovaps [rsp+0xA0], xmm11
00007fdcd91d4a1d  vmovaps [rsp+0xB0], xmm12
00007fdcd91d4a26  vmovaps [rsp+0xC0], xmm13
00007fdcd91d4a2f  vmovaps [rsp+0xD0], xmm14
00007fdcd91d4a38  vmovaps [rsp+0xE0], xmm15
00007fdcd91d4a41  sub rsp, 0x30
00007fdcd91d4a45  movaps [rsp], xmm8
00007fdcd91d4a4a  movaps [rsp+0x10], xmm14
00007fdcd91d4a50  movaps [rsp+0x20], xmm9
00007fdcd91d4a56  lea rdi, [rsp]
00007fdcd91d4a5a  mov esi, 0x00
00007fdcd91d4a5f  mov rax, 0x5B56EFBF3530
00007fdcd91d4a69  call rax
00007fdcd91d4a6b  movaps xmm8, [rsp]
00007fdcd91d4a70  add rsp, 0x30
00007fdcd91d4a74  vmovaps xmm0, [rsp]
00007fdcd91d4a79  vmovaps xmm1, [rsp+0x10]
00007fdcd91d4a7f  vmovaps xmm2, [rsp+0x20]
00007fdcd91d4a85  vmovaps xmm3, [rsp+0x30]
00007fdcd91d4a8b  vmovaps xmm4, [rsp+0x40]
00007fdcd91d4a91  vmovaps xmm5, [rsp+0x50]
00007fdcd91d4a97  vmovaps xmm6, [rsp+0x60]
00007fdcd91d4a9d  vmovaps xmm7, [rsp+0x70]
00007fdcd91d4aa3  vmovaps xmm9, [rsp+0x80]
00007fdcd91d4aac  vmovaps xmm10, [rsp+0x90]
00007fdcd91d4ab5  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d4abe  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d4ac7  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d4ad0  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d4ad9  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d4ae2  add rsp, 0xF0
00007fdcd91d4ae9  pop r11
00007fdcd91d4aeb  pop r10
00007fdcd91d4aed  pop r9
00007fdcd91d4aef  pop r8
00007fdcd91d4af1  pop rsi
00007fdcd91d4af2  pop rdi
00007fdcd91d4af3  pop rdx
00007fdcd91d4af4  pop rcx
00007fdcd91d4af5  pop rax
00007fdcd91d4af6  add rsp, 0x08
00007fdcd91d4afa  jmp 0x00007FDCD91D01AF
00007fdcd91d4aff  sub rsp, 0x08
00007fdcd91d4b03  push rax
00007fdcd91d4b04  push rcx
00007fdcd91d4b05  push rdx
00007fdcd91d4b06  push rdi
00007fdcd91d4b07  push rsi
00007fdcd91d4b08  push r8
00007fdcd91d4b0a  push r9
00007fdcd91d4b0c  push r10
00007fdcd91d4b0e  push r11
00007fdcd91d4b10  sub rsp, 0xF0
00007fdcd91d4b17  vmovaps [rsp], xmm0
00007fdcd91d4b1c  vmovaps [rsp+0x10], xmm1
00007fdcd91d4b22  vmovaps [rsp+0x20], xmm2
00007fdcd91d4b28  vmovaps [rsp+0x30], xmm3
00007fdcd91d4b2e  vmovaps [rsp+0x40], xmm4
00007fdcd91d4b34  vmovaps [rsp+0x50], xmm5
00007fdcd91d4b3a  vmovaps [rsp+0x60], xmm6
00007fdcd91d4b40  vmovaps [rsp+0x70], xmm7
00007fdcd91d4b46  vmovaps [rsp+0x80], xmm8
00007fdcd91d4b4f  vmovaps [rsp+0x90], xmm10
00007fdcd91d4b58  vmovaps [rsp+0xA0], xmm11
00007fdcd91d4b61  vmovaps [rsp+0xB0], xmm12
00007fdcd91d4b6a  vmovaps [rsp+0xC0], xmm13
00007fdcd91d4b73  vmovaps [rsp+0xD0], xmm14
00007fdcd91d4b7c  vmovaps [rsp+0xE0], xmm15
00007fdcd91d4b85  sub rsp, 0x30
00007fdcd91d4b89  movaps [rsp], xmm9
00007fdcd91d4b8e  movaps [rsp+0x10], xmm1
00007fdcd91d4b93  movaps [rsp+0x20], xmm14
00007fdcd91d4b99  lea rdi, [rsp]
00007fdcd91d4b9d  mov esi, 0x00
00007fdcd91d4ba2  mov rax, 0x5B56EFBF3530
00007fdcd91d4bac  call rax
00007fdcd91d4bae  movaps xmm9, [rsp]
00007fdcd91d4bb3  add rsp, 0x30
00007fdcd91d4bb7  vmovaps xmm0, [rsp]
00007fdcd91d4bbc  vmovaps xmm1, [rsp+0x10]
00007fdcd91d4bc2  vmovaps xmm2, [rsp+0x20]
00007fdcd91d4bc8  vmovaps xmm3, [rsp+0x30]
00007fdcd91d4bce  vmovaps xmm4, [rsp+0x40]
00007fdcd91d4bd4  vmovaps xmm5, [rsp+0x50]
00007fdcd91d4bda  vmovaps xmm6, [rsp+0x60]
00007fdcd91d4be0  vmovaps xmm7, [rsp+0x70]
00007fdcd91d4be6  vmovaps xmm8, [rsp+0x80]
00007fdcd91d4bef  vmovaps xmm10, [rsp+0x90]
00007fdcd91d4bf8  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d4c01  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d4c0a  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d4c13  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d4c1c  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d4c25  add rsp, 0xF0
00007fdcd91d4c2c  pop r11
00007fdcd91d4c2e  pop r10
00007fdcd91d4c30  pop r9
00007fdcd91d4c32  pop r8
00007fdcd91d4c34  pop rsi
00007fdcd91d4c35  pop rdi
00007fdcd91d4c36  pop rdx
00007fdcd91d4c37  pop rcx
00007fdcd91d4c38  pop rax
00007fdcd91d4c39  add rsp, 0x08
00007fdcd91d4c3d  jmp 0x00007FDCD91D01DD
00007fdcd91d4c42  sub rsp, 0x08
00007fdcd91d4c46  push rax
00007fdcd91d4c47  push rcx
00007fdcd91d4c48  push rdx
00007fdcd91d4c49  push rdi
00007fdcd91d4c4a  push rsi
00007fdcd91d4c4b  push r8
00007fdcd91d4c4d  push r9
00007fdcd91d4c4f  push r10
00007fdcd91d4c51  push r11
00007fdcd91d4c53  sub rsp, 0xF0
00007fdcd91d4c5a  vmovaps [rsp], xmm0
00007fdcd91d4c5f  vmovaps [rsp+0x10], xmm1
00007fdcd91d4c65  vmovaps [rsp+0x20], xmm2
00007fdcd91d4c6b  vmovaps [rsp+0x30], xmm3
00007fdcd91d4c71  vmovaps [rsp+0x40], xmm4
00007fdcd91d4c77  vmovaps [rsp+0x50], xmm5
00007fdcd91d4c7d  vmovaps [rsp+0x60], xmm6
00007fdcd91d4c83  vmovaps [rsp+0x70], xmm7
00007fdcd91d4c89  vmovaps [rsp+0x80], xmm8
00007fdcd91d4c92  vmovaps [rsp+0x90], xmm9
00007fdcd91d4c9b  vmovaps [rsp+0xA0], xmm10
00007fdcd91d4ca4  vmovaps [rsp+0xB0], xmm11
00007fdcd91d4cad  vmovaps [rsp+0xC0], xmm12
00007fdcd91d4cb6  vmovaps [rsp+0xD0], xmm13
00007fdcd91d4cbf  vmovaps [rsp+0xE0], xmm15
00007fdcd91d4cc8  sub rsp, 0x30
00007fdcd91d4ccc  movaps [rsp], xmm14
00007fdcd91d4cd1  movaps [rsp+0x10], xmm4
00007fdcd91d4cd6  movaps [rsp+0x20], xmm1
00007fdcd91d4cdb  lea rdi, [rsp]
00007fdcd91d4cdf  mov esi, 0x00
00007fdcd91d4ce4  mov rax, 0x5B56EFBF3530
00007fdcd91d4cee  call rax
00007fdcd91d4cf0  movaps xmm14, [rsp]
00007fdcd91d4cf5  add rsp, 0x30
00007fdcd91d4cf9  vmovaps xmm0, [rsp]
00007fdcd91d4cfe  vmovaps xmm1, [rsp+0x10]
00007fdcd91d4d04  vmovaps xmm2, [rsp+0x20]
00007fdcd91d4d0a  vmovaps xmm3, [rsp+0x30]
00007fdcd91d4d10  vmovaps xmm4, [rsp+0x40]
00007fdcd91d4d16  vmovaps xmm5, [rsp+0x50]
00007fdcd91d4d1c  vmovaps xmm6, [rsp+0x60]
00007fdcd91d4d22  vmovaps xmm7, [rsp+0x70]
00007fdcd91d4d28  vmovaps xmm8, [rsp+0x80]
00007fdcd91d4d31  vmovaps xmm9, [rsp+0x90]
00007fdcd91d4d3a  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d4d43  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d4d4c  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d4d55  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d4d5e  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d4d67  add rsp, 0xF0
00007fdcd91d4d6e  pop r11
00007fdcd91d4d70  pop r10
00007fdcd91d4d72  pop r9
00007fdcd91d4d74  pop r8
00007fdcd91d4d76  pop rsi
00007fdcd91d4d77  pop rdi
00007fdcd91d4d78  pop rdx
00007fdcd91d4d79  pop rcx
00007fdcd91d4d7a  pop rax
00007fdcd91d4d7b  add rsp, 0x08
00007fdcd91d4d7f  jmp 0x00007FDCD91D0203
00007fdcd91d4d84  sub rsp, 0x08
00007fdcd91d4d88  push rax
00007fdcd91d4d89  push rcx
00007fdcd91d4d8a  push rdx
00007fdcd91d4d8b  push rdi
00007fdcd91d4d8c  push rsi
00007fdcd91d4d8d  push r8
00007fdcd91d4d8f  push r9
00007fdcd91d4d91  push r10
00007fdcd91d4d93  push r11
00007fdcd91d4d95  sub rsp, 0xF0
00007fdcd91d4d9c  vmovaps [rsp], xmm0
00007fdcd91d4da1  vmovaps [rsp+0x10], xmm2
00007fdcd91d4da7  vmovaps [rsp+0x20], xmm3
00007fdcd91d4dad  vmovaps [rsp+0x30], xmm4
00007fdcd91d4db3  vmovaps [rsp+0x40], xmm5
00007fdcd91d4db9  vmovaps [rsp+0x50], xmm6
00007fdcd91d4dbf  vmovaps [rsp+0x60], xmm7
00007fdcd91d4dc5  vmovaps [rsp+0x70], xmm8
00007fdcd91d4dcb  vmovaps [rsp+0x80], xmm9
00007fdcd91d4dd4  vmovaps [rsp+0x90], xmm10
00007fdcd91d4ddd  vmovaps [rsp+0xA0], xmm11
00007fdcd91d4de6  vmovaps [rsp+0xB0], xmm12
00007fdcd91d4def  vmovaps [rsp+0xC0], xmm13
00007fdcd91d4df8  vmovaps [rsp+0xD0], xmm14
00007fdcd91d4e01  vmovaps [rsp+0xE0], xmm15
00007fdcd91d4e0a  sub rsp, 0x30
00007fdcd91d4e0e  movaps [rsp], xmm1
00007fdcd91d4e12  movaps [rsp+0x10], xmm12
00007fdcd91d4e18  movaps [rsp+0x20], xmm11
00007fdcd91d4e1e  lea rdi, [rsp]
00007fdcd91d4e22  mov esi, 0x00
00007fdcd91d4e27  mov rax, 0x5B56EFBF3530
00007fdcd91d4e31  call rax
00007fdcd91d4e33  movaps xmm1, [rsp]
00007fdcd91d4e37  add rsp, 0x30
00007fdcd91d4e3b  vmovaps xmm0, [rsp]
00007fdcd91d4e40  vmovaps xmm2, [rsp+0x10]
00007fdcd91d4e46  vmovaps xmm3, [rsp+0x20]
00007fdcd91d4e4c  vmovaps xmm4, [rsp+0x30]
00007fdcd91d4e52  vmovaps xmm5, [rsp+0x40]
00007fdcd91d4e58  vmovaps xmm6, [rsp+0x50]
00007fdcd91d4e5e  vmovaps xmm7, [rsp+0x60]
00007fdcd91d4e64  vmovaps xmm8, [rsp+0x70]
00007fdcd91d4e6a  vmovaps xmm9, [rsp+0x80]
00007fdcd91d4e73  vmovaps xmm10, [rsp+0x90]
00007fdcd91d4e7c  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d4e85  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d4e8e  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d4e97  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d4ea0  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d4ea9  add rsp, 0xF0
00007fdcd91d4eb0  pop r11
00007fdcd91d4eb2  pop r10
00007fdcd91d4eb4  pop r9
00007fdcd91d4eb6  pop r8
00007fdcd91d4eb8  pop rsi
00007fdcd91d4eb9  pop rdi
00007fdcd91d4eba  pop rdx
00007fdcd91d4ebb  pop rcx
00007fdcd91d4ebc  pop rax
00007fdcd91d4ebd  add rsp, 0x08
00007fdcd91d4ec1  jmp 0x00007FDCD91D0224
00007fdcd91d4ec6  call 0x00007FDCD90E20A0
00007fdcd91d4ecb  jmp 0x00007FDCD91D0232
00007fdcd91d4ed0  call 0x00007FDCD9009D70
00007fdcd91d4ed5  jmp 0x00007FDCD91D023C
00007fdcd91d4eda  sub rsp, 0x08
00007fdcd91d4ede  push rax
00007fdcd91d4edf  push rcx
00007fdcd91d4ee0  push rdx
00007fdcd91d4ee1  push rdi
00007fdcd91d4ee2  push rsi
00007fdcd91d4ee3  push r8
00007fdcd91d4ee5  push r9
00007fdcd91d4ee7  push r10
00007fdcd91d4ee9  push r11
00007fdcd91d4eeb  sub rsp, 0xF0
00007fdcd91d4ef2  vmovaps [rsp], xmm0
00007fdcd91d4ef7  vmovaps [rsp+0x10], xmm1
00007fdcd91d4efd  vmovaps [rsp+0x20], xmm2
00007fdcd91d4f03  vmovaps [rsp+0x30], xmm3
00007fdcd91d4f09  vmovaps [rsp+0x40], xmm4
00007fdcd91d4f0f  vmovaps [rsp+0x50], xmm5
00007fdcd91d4f15  vmovaps [rsp+0x60], xmm6
00007fdcd91d4f1b  vmovaps [rsp+0x70], xmm8
00007fdcd91d4f21  vmovaps [rsp+0x80], xmm9
00007fdcd91d4f2a  vmovaps [rsp+0x90], xmm10
00007fdcd91d4f33  vmovaps [rsp+0xA0], xmm11
00007fdcd91d4f3c  vmovaps [rsp+0xB0], xmm12
00007fdcd91d4f45  vmovaps [rsp+0xC0], xmm13
00007fdcd91d4f4e  vmovaps [rsp+0xD0], xmm14
00007fdcd91d4f57  vmovaps [rsp+0xE0], xmm15
00007fdcd91d4f60  sub rsp, 0x30
00007fdcd91d4f64  movaps [rsp], xmm7
00007fdcd91d4f68  movaps [rsp+0x10], xmm15
00007fdcd91d4f6e  movaps [rsp+0x20], xmm10
00007fdcd91d4f74  lea rdi, [rsp]
00007fdcd91d4f78  mov esi, 0x00
00007fdcd91d4f7d  mov rax, 0x5B56EFBF3530
00007fdcd91d4f87  call rax
00007fdcd91d4f89  movaps xmm7, [rsp]
00007fdcd91d4f8d  add rsp, 0x30
00007fdcd91d4f91  vmovaps xmm0, [rsp]
00007fdcd91d4f96  vmovaps xmm1, [rsp+0x10]
00007fdcd91d4f9c  vmovaps xmm2, [rsp+0x20]
00007fdcd91d4fa2  vmovaps xmm3, [rsp+0x30]
00007fdcd91d4fa8  vmovaps xmm4, [rsp+0x40]
00007fdcd91d4fae  vmovaps xmm5, [rsp+0x50]
00007fdcd91d4fb4  vmovaps xmm6, [rsp+0x60]
00007fdcd91d4fba  vmovaps xmm8, [rsp+0x70]
00007fdcd91d4fc0  vmovaps xmm9, [rsp+0x80]
00007fdcd91d4fc9  vmovaps xmm10, [rsp+0x90]
00007fdcd91d4fd2  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d4fdb  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d4fe4  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d4fed  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d4ff6  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d4fff  add rsp, 0xF0
00007fdcd91d5006  pop r11
00007fdcd91d5008  pop r10
00007fdcd91d500a  pop r9
00007fdcd91d500c  pop r8
00007fdcd91d500e  pop rsi
00007fdcd91d500f  pop rdi
00007fdcd91d5010  pop rdx
00007fdcd91d5011  pop rcx
00007fdcd91d5012  pop rax
00007fdcd91d5013  add rsp, 0x08
00007fdcd91d5017  jmp 0x00007FDCD91D025D
00007fdcd91d501c  sub rsp, 0x08
00007fdcd91d5020  push rax
00007fdcd91d5021  push rcx
00007fdcd91d5022  push rdx
00007fdcd91d5023  push rdi
00007fdcd91d5024  push rsi
00007fdcd91d5025  push r8
00007fdcd91d5027  push r9
00007fdcd91d5029  push r10
00007fdcd91d502b  push r11
00007fdcd91d502d  sub rsp, 0xF0
00007fdcd91d5034  vmovaps [rsp], xmm0
00007fdcd91d5039  vmovaps [rsp+0x10], xmm1
00007fdcd91d503f  vmovaps [rsp+0x20], xmm2
00007fdcd91d5045  vmovaps [rsp+0x30], xmm3
00007fdcd91d504b  vmovaps [rsp+0x40], xmm4
00007fdcd91d5051  vmovaps [rsp+0x50], xmm5
00007fdcd91d5057  vmovaps [rsp+0x60], xmm6
00007fdcd91d505d  vmovaps [rsp+0x70], xmm7
00007fdcd91d5063  vmovaps [rsp+0x80], xmm8
00007fdcd91d506c  vmovaps [rsp+0x90], xmm9
00007fdcd91d5075  vmovaps [rsp+0xA0], xmm11
00007fdcd91d507e  vmovaps [rsp+0xB0], xmm12
00007fdcd91d5087  vmovaps [rsp+0xC0], xmm13
00007fdcd91d5090  vmovaps [rsp+0xD0], xmm14
00007fdcd91d5099  vmovaps [rsp+0xE0], xmm15
00007fdcd91d50a2  sub rsp, 0x30
00007fdcd91d50a6  movaps [rsp], xmm10
00007fdcd91d50ab  movaps [rsp+0x10], xmm11
00007fdcd91d50b1  movaps [rsp+0x20], xmm15
00007fdcd91d50b7  lea rdi, [rsp]
00007fdcd91d50bb  mov esi, 0x00
00007fdcd91d50c0  mov rax, 0x5B56EFBF3530
00007fdcd91d50ca  call rax
00007fdcd91d50cc  movaps xmm10, [rsp]
00007fdcd91d50d1  add rsp, 0x30
00007fdcd91d50d5  vmovaps xmm0, [rsp]
00007fdcd91d50da  vmovaps xmm1, [rsp+0x10]
00007fdcd91d50e0  vmovaps xmm2, [rsp+0x20]
00007fdcd91d50e6  vmovaps xmm3, [rsp+0x30]
00007fdcd91d50ec  vmovaps xmm4, [rsp+0x40]
00007fdcd91d50f2  vmovaps xmm5, [rsp+0x50]
00007fdcd91d50f8  vmovaps xmm6, [rsp+0x60]
00007fdcd91d50fe  vmovaps xmm7, [rsp+0x70]
00007fdcd91d5104  vmovaps xmm8, [rsp+0x80]
00007fdcd91d510d  vmovaps xmm9, [rsp+0x90]
00007fdcd91d5116  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d511f  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d5128  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d5131  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d513a  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d5143  add rsp, 0xF0
00007fdcd91d514a  pop r11
00007fdcd91d514c  pop r10
00007fdcd91d514e  pop r9
00007fdcd91d5150  pop r8
00007fdcd91d5152  pop rsi
00007fdcd91d5153  pop rdi
00007fdcd91d5154  pop rdx
00007fdcd91d5155  pop rcx
00007fdcd91d5156  pop rax
00007fdcd91d5157  add rsp, 0x08
00007fdcd91d515b  jmp 0x00007FDCD91D028B
00007fdcd91d5160  sub rsp, 0x08
00007fdcd91d5164  push rax
00007fdcd91d5165  push rcx
00007fdcd91d5166  push rdx
00007fdcd91d5167  push rdi
00007fdcd91d5168  push rsi
00007fdcd91d5169  push r8
00007fdcd91d516b  push r9
00007fdcd91d516d  push r10
00007fdcd91d516f  push r11
00007fdcd91d5171  sub rsp, 0xF0
00007fdcd91d5178  vmovaps [rsp], xmm0
00007fdcd91d517d  vmovaps [rsp+0x10], xmm1
00007fdcd91d5183  vmovaps [rsp+0x20], xmm2
00007fdcd91d5189  vmovaps [rsp+0x30], xmm3
00007fdcd91d518f  vmovaps [rsp+0x40], xmm4
00007fdcd91d5195  vmovaps [rsp+0x50], xmm5
00007fdcd91d519b  vmovaps [rsp+0x60], xmm6
00007fdcd91d51a1  vmovaps [rsp+0x70], xmm7
00007fdcd91d51a7  vmovaps [rsp+0x80], xmm8
00007fdcd91d51b0  vmovaps [rsp+0x90], xmm9
00007fdcd91d51b9  vmovaps [rsp+0xA0], xmm10
00007fdcd91d51c2  vmovaps [rsp+0xB0], xmm12
00007fdcd91d51cb  vmovaps [rsp+0xC0], xmm13
00007fdcd91d51d4  vmovaps [rsp+0xD0], xmm14
00007fdcd91d51dd  vmovaps [rsp+0xE0], xmm15
00007fdcd91d51e6  sub rsp, 0x30
00007fdcd91d51ea  movaps [rsp], xmm11
00007fdcd91d51ef  movaps [rsp+0x10], xmm12
00007fdcd91d51f5  movaps [rsp+0x20], xmm15
00007fdcd91d51fb  lea rdi, [rsp]
00007fdcd91d51ff  mov esi, 0x00
00007fdcd91d5204  mov rax, 0x5B56EFBF3530
00007fdcd91d520e  call rax
00007fdcd91d5210  movaps xmm11, [rsp]
00007fdcd91d5215  add rsp, 0x30
00007fdcd91d5219  vmovaps xmm0, [rsp]
00007fdcd91d521e  vmovaps xmm1, [rsp+0x10]
00007fdcd91d5224  vmovaps xmm2, [rsp+0x20]
00007fdcd91d522a  vmovaps xmm3, [rsp+0x30]
00007fdcd91d5230  vmovaps xmm4, [rsp+0x40]
00007fdcd91d5236  vmovaps xmm5, [rsp+0x50]
00007fdcd91d523c  vmovaps xmm6, [rsp+0x60]
00007fdcd91d5242  vmovaps xmm7, [rsp+0x70]
00007fdcd91d5248  vmovaps xmm8, [rsp+0x80]
00007fdcd91d5251  vmovaps xmm9, [rsp+0x90]
00007fdcd91d525a  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d5263  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d526c  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d5275  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d527e  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d5287  add rsp, 0xF0
00007fdcd91d528e  pop r11
00007fdcd91d5290  pop r10
00007fdcd91d5292  pop r9
00007fdcd91d5294  pop r8
00007fdcd91d5296  pop rsi
00007fdcd91d5297  pop rdi
00007fdcd91d5298  pop rdx
00007fdcd91d5299  pop rcx
00007fdcd91d529a  pop rax
00007fdcd91d529b  add rsp, 0x08
00007fdcd91d529f  jmp 0x00007FDCD91D02B9
00007fdcd91d52a4  sub rsp, 0x08
00007fdcd91d52a8  push rax
00007fdcd91d52a9  push rcx
00007fdcd91d52aa  push rdx
00007fdcd91d52ab  push rdi
00007fdcd91d52ac  push rsi
00007fdcd91d52ad  push r8
00007fdcd91d52af  push r9
00007fdcd91d52b1  push r10
00007fdcd91d52b3  push r11
00007fdcd91d52b5  sub rsp, 0xF0
00007fdcd91d52bc  vmovaps [rsp], xmm0
00007fdcd91d52c1  vmovaps [rsp+0x10], xmm1
00007fdcd91d52c7  vmovaps [rsp+0x20], xmm2
00007fdcd91d52cd  vmovaps [rsp+0x30], xmm3
00007fdcd91d52d3  vmovaps [rsp+0x40], xmm4
00007fdcd91d52d9  vmovaps [rsp+0x50], xmm5
00007fdcd91d52df  vmovaps [rsp+0x60], xmm6
00007fdcd91d52e5  vmovaps [rsp+0x70], xmm7
00007fdcd91d52eb  vmovaps [rsp+0x80], xmm8
00007fdcd91d52f4  vmovaps [rsp+0x90], xmm9
00007fdcd91d52fd  vmovaps [rsp+0xA0], xmm10
00007fdcd91d5306  vmovaps [rsp+0xB0], xmm11
00007fdcd91d530f  vmovaps [rsp+0xC0], xmm12
00007fdcd91d5318  vmovaps [rsp+0xD0], xmm13
00007fdcd91d5321  vmovaps [rsp+0xE0], xmm14
00007fdcd91d532a  sub rsp, 0x30
00007fdcd91d532e  movaps [rsp], xmm15
00007fdcd91d5333  movaps [rsp+0x10], xmm13
00007fdcd91d5339  movaps [rsp+0x20], xmm9
00007fdcd91d533f  lea rdi, [rsp]
00007fdcd91d5343  mov esi, 0x00
00007fdcd91d5348  mov rax, 0x5B56EFBF3530
00007fdcd91d5352  call rax
00007fdcd91d5354  movaps xmm15, [rsp]
00007fdcd91d5359  add rsp, 0x30
00007fdcd91d535d  vmovaps xmm0, [rsp]
00007fdcd91d5362  vmovaps xmm1, [rsp+0x10]
00007fdcd91d5368  vmovaps xmm2, [rsp+0x20]
00007fdcd91d536e  vmovaps xmm3, [rsp+0x30]
00007fdcd91d5374  vmovaps xmm4, [rsp+0x40]
00007fdcd91d537a  vmovaps xmm5, [rsp+0x50]
00007fdcd91d5380  vmovaps xmm6, [rsp+0x60]
00007fdcd91d5386  vmovaps xmm7, [rsp+0x70]
00007fdcd91d538c  vmovaps xmm8, [rsp+0x80]
00007fdcd91d5395  vmovaps xmm9, [rsp+0x90]
00007fdcd91d539e  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d53a7  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d53b0  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d53b9  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d53c2  vmovaps xmm14, [rsp+0xE0]
00007fdcd91d53cb  add rsp, 0xF0
00007fdcd91d53d2  pop r11
00007fdcd91d53d4  pop r10
00007fdcd91d53d6  pop r9
00007fdcd91d53d8  pop r8
00007fdcd91d53da  pop rsi
00007fdcd91d53db  pop rdi
00007fdcd91d53dc  pop rdx
00007fdcd91d53dd  pop rcx
00007fdcd91d53de  pop rax
00007fdcd91d53df  add rsp, 0x08
00007fdcd91d53e3  jmp 0x00007FDCD91D02D4
00007fdcd91d53e8  sub rsp, 0x08
00007fdcd91d53ec  push rax
00007fdcd91d53ed  push rcx
00007fdcd91d53ee  push rdx
00007fdcd91d53ef  push rdi
00007fdcd91d53f0  push rsi
00007fdcd91d53f1  push r8
00007fdcd91d53f3  push r9
00007fdcd91d53f5  push r10
00007fdcd91d53f7  push r11
00007fdcd91d53f9  sub rsp, 0xF0
00007fdcd91d5400  vmovaps [rsp], xmm0
00007fdcd91d5405  vmovaps [rsp+0x10], xmm1
00007fdcd91d540b  vmovaps [rsp+0x20], xmm2
00007fdcd91d5411  vmovaps [rsp+0x30], xmm3
00007fdcd91d5417  vmovaps [rsp+0x40], xmm4
00007fdcd91d541d  vmovaps [rsp+0x50], xmm5
00007fdcd91d5423  vmovaps [rsp+0x60], xmm6
00007fdcd91d5429  vmovaps [rsp+0x70], xmm7
00007fdcd91d542f  vmovaps [rsp+0x80], xmm8
00007fdcd91d5438  vmovaps [rsp+0x90], xmm9
00007fdcd91d5441  vmovaps [rsp+0xA0], xmm10
00007fdcd91d544a  vmovaps [rsp+0xB0], xmm11
00007fdcd91d5453  vmovaps [rsp+0xC0], xmm12
00007fdcd91d545c  vmovaps [rsp+0xD0], xmm14
00007fdcd91d5465  vmovaps [rsp+0xE0], xmm15
00007fdcd91d546e  sub rsp, 0x30
00007fdcd91d5472  movaps [rsp], xmm13
00007fdcd91d5477  movaps [rsp+0x10], xmm8
00007fdcd91d547d  movaps [rsp+0x20], xmm14
00007fdcd91d5483  lea rdi, [rsp]
00007fdcd91d5487  mov esi, 0x00
00007fdcd91d548c  mov rax, 0x5B56EFBF3530
00007fdcd91d5496  call rax
00007fdcd91d5498  movaps xmm13, [rsp]
00007fdcd91d549d  add rsp, 0x30
00007fdcd91d54a1  vmovaps xmm0, [rsp]
00007fdcd91d54a6  vmovaps xmm1, [rsp+0x10]
00007fdcd91d54ac  vmovaps xmm2, [rsp+0x20]
00007fdcd91d54b2  vmovaps xmm3, [rsp+0x30]
00007fdcd91d54b8  vmovaps xmm4, [rsp+0x40]
00007fdcd91d54be  vmovaps xmm5, [rsp+0x50]
00007fdcd91d54c4  vmovaps xmm6, [rsp+0x60]
00007fdcd91d54ca  vmovaps xmm7, [rsp+0x70]
00007fdcd91d54d0  vmovaps xmm8, [rsp+0x80]
00007fdcd91d54d9  vmovaps xmm9, [rsp+0x90]
00007fdcd91d54e2  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d54eb  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d54f4  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d54fd  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d5506  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d550f  add rsp, 0xF0
00007fdcd91d5516  pop r11
00007fdcd91d5518  pop r10
00007fdcd91d551a  pop r9
00007fdcd91d551c  pop r8
00007fdcd91d551e  pop rsi
00007fdcd91d551f  pop rdi
00007fdcd91d5520  pop rdx
00007fdcd91d5521  pop rcx
00007fdcd91d5522  pop rax
00007fdcd91d5523  add rsp, 0x08
00007fdcd91d5527  jmp 0x00007FDCD91D02F7
00007fdcd91d552c  sub rsp, 0x08
00007fdcd91d5530  push rax
00007fdcd91d5531  push rcx
00007fdcd91d5532  push rdx
00007fdcd91d5533  push rdi
00007fdcd91d5534  push rsi
00007fdcd91d5535  push r8
00007fdcd91d5537  push r9
00007fdcd91d5539  push r10
00007fdcd91d553b  push r11
00007fdcd91d553d  sub rsp, 0xF0
00007fdcd91d5544  vmovaps [rsp], xmm0
00007fdcd91d5549  vmovaps [rsp+0x10], xmm1
00007fdcd91d554f  vmovaps [rsp+0x20], xmm2
00007fdcd91d5555  vmovaps [rsp+0x30], xmm3
00007fdcd91d555b  vmovaps [rsp+0x40], xmm4
00007fdcd91d5561  vmovaps [rsp+0x50], xmm5
00007fdcd91d5567  vmovaps [rsp+0x60], xmm6
00007fdcd91d556d  vmovaps [rsp+0x70], xmm7
00007fdcd91d5573  vmovaps [rsp+0x80], xmm8
00007fdcd91d557c  vmovaps [rsp+0x90], xmm9
00007fdcd91d5585  vmovaps [rsp+0xA0], xmm10
00007fdcd91d558e  vmovaps [rsp+0xB0], xmm11
00007fdcd91d5597  vmovaps [rsp+0xC0], xmm12
00007fdcd91d55a0  vmovaps [rsp+0xD0], xmm13
00007fdcd91d55a9  vmovaps [rsp+0xE0], xmm15
00007fdcd91d55b2  sub rsp, 0x30
00007fdcd91d55b6  movaps [rsp], xmm14
00007fdcd91d55bb  movaps [rsp+0x10], xmm1
00007fdcd91d55c0  movaps [rsp+0x20], xmm10
00007fdcd91d55c6  lea rdi, [rsp]
00007fdcd91d55ca  mov esi, 0x00
00007fdcd91d55cf  mov rax, 0x5B56EFBF3530
00007fdcd91d55d9  call rax
00007fdcd91d55db  movaps xmm14, [rsp]
00007fdcd91d55e0  add rsp, 0x30
00007fdcd91d55e4  vmovaps xmm0, [rsp]
00007fdcd91d55e9  vmovaps xmm1, [rsp+0x10]
00007fdcd91d55ef  vmovaps xmm2, [rsp+0x20]
00007fdcd91d55f5  vmovaps xmm3, [rsp+0x30]
00007fdcd91d55fb  vmovaps xmm4, [rsp+0x40]
00007fdcd91d5601  vmovaps xmm5, [rsp+0x50]
00007fdcd91d5607  vmovaps xmm6, [rsp+0x60]
00007fdcd91d560d  vmovaps xmm7, [rsp+0x70]
00007fdcd91d5613  vmovaps xmm8, [rsp+0x80]
00007fdcd91d561c  vmovaps xmm9, [rsp+0x90]
00007fdcd91d5625  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d562e  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d5637  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d5640  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d5649  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d5652  add rsp, 0xF0
00007fdcd91d5659  pop r11
00007fdcd91d565b  pop r10
00007fdcd91d565d  pop r9
00007fdcd91d565f  pop r8
00007fdcd91d5661  pop rsi
00007fdcd91d5662  pop rdi
00007fdcd91d5663  pop rdx
00007fdcd91d5664  pop rcx
00007fdcd91d5665  pop rax
00007fdcd91d5666  add rsp, 0x08
00007fdcd91d566a  jmp 0x00007FDCD91D031A
00007fdcd91d566f  sub rsp, 0x08
00007fdcd91d5673  push rax
00007fdcd91d5674  push rcx
00007fdcd91d5675  push rdx
00007fdcd91d5676  push rdi
00007fdcd91d5677  push rsi
00007fdcd91d5678  push r8
00007fdcd91d567a  push r9
00007fdcd91d567c  push r10
00007fdcd91d567e  push r11
00007fdcd91d5680  sub rsp, 0xF0
00007fdcd91d5687  vmovaps [rsp], xmm0
00007fdcd91d568c  vmovaps [rsp+0x10], xmm2
00007fdcd91d5692  vmovaps [rsp+0x20], xmm3
00007fdcd91d5698  vmovaps [rsp+0x30], xmm4
00007fdcd91d569e  vmovaps [rsp+0x40], xmm5
00007fdcd91d56a4  vmovaps [rsp+0x50], xmm6
00007fdcd91d56aa  vmovaps [rsp+0x60], xmm7
00007fdcd91d56b0  vmovaps [rsp+0x70], xmm8
00007fdcd91d56b6  vmovaps [rsp+0x80], xmm9
00007fdcd91d56bf  vmovaps [rsp+0x90], xmm10
00007fdcd91d56c8  vmovaps [rsp+0xA0], xmm11
00007fdcd91d56d1  vmovaps [rsp+0xB0], xmm12
00007fdcd91d56da  vmovaps [rsp+0xC0], xmm13
00007fdcd91d56e3  vmovaps [rsp+0xD0], xmm14
00007fdcd91d56ec  vmovaps [rsp+0xE0], xmm15
00007fdcd91d56f5  sub rsp, 0x30
00007fdcd91d56f9  movaps [rsp], xmm1
00007fdcd91d56fd  movaps [rsp+0x10], xmm7
00007fdcd91d5702  movaps [rsp+0x20], xmm11
00007fdcd91d5708  lea rdi, [rsp]
00007fdcd91d570c  mov esi, 0x00
00007fdcd91d5711  mov rax, 0x5B56EFBF3530
00007fdcd91d571b  call rax
00007fdcd91d571d  movaps xmm1, [rsp]
00007fdcd91d5721  add rsp, 0x30
00007fdcd91d5725  vmovaps xmm0, [rsp]
00007fdcd91d572a  vmovaps xmm2, [rsp+0x10]
00007fdcd91d5730  vmovaps xmm3, [rsp+0x20]
00007fdcd91d5736  vmovaps xmm4, [rsp+0x30]
00007fdcd91d573c  vmovaps xmm5, [rsp+0x40]
00007fdcd91d5742  vmovaps xmm6, [rsp+0x50]
00007fdcd91d5748  vmovaps xmm7, [rsp+0x60]
00007fdcd91d574e  vmovaps xmm8, [rsp+0x70]
00007fdcd91d5754  vmovaps xmm9, [rsp+0x80]
00007fdcd91d575d  vmovaps xmm10, [rsp+0x90]
00007fdcd91d5766  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d576f  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d5778  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d5781  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d578a  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d5793  add rsp, 0xF0
00007fdcd91d579a  pop r11
00007fdcd91d579c  pop r10
00007fdcd91d579e  pop r9
00007fdcd91d57a0  pop r8
00007fdcd91d57a2  pop rsi
00007fdcd91d57a3  pop rdi
00007fdcd91d57a4  pop rdx
00007fdcd91d57a5  pop rcx
00007fdcd91d57a6  pop rax
00007fdcd91d57a7  add rsp, 0x08
00007fdcd91d57ab  jmp 0x00007FDCD91D033B
00007fdcd91d57b0  call 0x00007FDCD900E880
00007fdcd91d57b5  jmp 0x00007FDCD91D034E
00007fdcd91d57ba  call 0x00007FDCD900C380
00007fdcd91d57bf  jmp 0x00007FDCD91D0359
00007fdcd91d57c4  call 0x00007FDCD900D600
00007fdcd91d57c9  jmp 0x00007FDCD91D0364
00007fdcd91d57ce  call 0x00007FDCD8FFF540
00007fdcd91d57d3  jmp 0x00007FDCD91D036F
00007fdcd91d57d8  int3
00007fdcd91d57d9  nop [rax], eax
00007fdcd91d57e0  mov rax, [r15+0x40]
00007fdcd91d57e4  mov r14, [r15+0x58]
00007fdcd91d57e8  lea r12, [rax+r14*1]
00007fdcd91d57ec  movaps xmm1, [r15+0x1D0]
00007fdcd91d57f4  vmovaps [rsp+0x10], xmm1
00007fdcd91d57fa  vmovaps xmm15, [rsp+0x10]
00007fdcd91d5800  por xmm1, xmm15
00007fdcd91d5805  movaps xmm14, [r15+0x1A0]
00007fdcd91d580d  vmovaps [rsp+0x10], xmm14
00007fdcd91d5813  vmovaps xmm13, [rsp+0x10]
00007fdcd91d5819  por xmm14, xmm13
00007fdcd91d581e  lea rax, [r12+0x30]
00007fdcd91d5823  mov r11, [r13+rax*1]
00007fdcd91d5828  lea rax, [r12+0x38]
00007fdcd91d582d  mov r10, [r13+rax*1]
00007fdcd91d5832  movq xmm13, r11
00007fdcd91d5837  movq xmm12, r10
00007fdcd91d583c  movq xmm13, xmm13
00007fdcd91d5841  vmovaps [rsp+0x10], xmm13
00007fdcd91d5847  movq xmm13, xmm13
00007fdcd91d584c  movaps [r15+0x130], xmm13
00007fdcd91d5854  movq xmm12, xmm12
00007fdcd91d5859  vmovaps [rsp+0x20], xmm12
00007fdcd91d585f  movq xmm12, xmm12
00007fdcd91d5864  movaps [r15+0x280], xmm12
00007fdcd91d586c  movaps xmm13, [r15+0x270]
00007fdcd91d5874  vmovaps [rsp+0x30], xmm13
00007fdcd91d587a  vmovaps xmm12, [rsp+0x30]
00007fdcd91d5880  por xmm13, xmm12
00007fdcd91d5885  lea rax, [r12+0x20]
00007fdcd91d588a  mov r11, [r13+rax*1]
00007fdcd91d588f  lea rax, [r12+0x28]
00007fdcd91d5894  mov r10, [r13+rax*1]
00007fdcd91d5899  movq xmm12, r11
00007fdcd91d589e  movq xmm11, r10
00007fdcd91d58a3  movq xmm12, xmm12
00007fdcd91d58a8  vmovaps [rsp+0x30], xmm12
00007fdcd91d58ae  movq xmm12, xmm12
00007fdcd91d58b3  movaps [r15+0x150], xmm12
00007fdcd91d58bb  movq xmm11, xmm11
00007fdcd91d58c0  vmovaps [rsp+0x40], xmm11
00007fdcd91d58c6  movq xmm11, xmm11
00007fdcd91d58cb  movaps [r15+0x140], xmm11
00007fdcd91d58d3  lea rax, [r12+0x10]
00007fdcd91d58d8  mov r11, [r13+rax*1]
00007fdcd91d58dd  lea rax, [r12+0x18]
00007fdcd91d58e2  mov r10, [r13+rax*1]
00007fdcd91d58e7  movq xmm12, r11
00007fdcd91d58ec  movq xmm11, r10
00007fdcd91d58f1  movq xmm12, xmm12
00007fdcd91d58f6  vmovaps [rsp+0x50], xmm12
00007fdcd91d58fc  movq xmm12, xmm12
00007fdcd91d5901  movaps [r15+0x170], xmm12
00007fdcd91d5909  movq xmm11, xmm11
00007fdcd91d590e  vmovaps [rsp+0x60], xmm11
00007fdcd91d5914  movq xmm11, xmm11
00007fdcd91d5919  movaps [r15+0x160], xmm11
00007fdcd91d5921  mov rax, [r13+r12*1]
00007fdcd91d5926  vmovq xmm12, rax
00007fdcd91d592b  vpbroadcastq xmm12, xmm12
00007fdcd91d5930  lea rax, [r12+0x08]
00007fdcd91d5935  mov r12, [r13+rax*1]
00007fdcd91d593a  movq xmm11, r12
00007fdcd91d593f  movaps [r15+0x230], xmm11
00007fdcd91d5947  mov rax, [r15+0xF8]
00007fdcd91d594e  lea r12, [rax+0x50]
00007fdcd91d5952  movups xmm11, [r13+r12*1]
00007fdcd91d5958  lea r12, [rax+0x60]
00007fdcd91d595c  movups xmm10, [r13+r12*1]
00007fdcd91d5962  lea r12, [rax+0x30]
00007fdcd91d5966  movups xmm9, [r13+r12*1]
00007fdcd91d596c  mov r12, [r15+0x50]
00007fdcd91d5970  lea r11, [r12+r14*1]
00007fdcd91d5974  mov [r15+0x60], r11
00007fdcd91d5978  lea r12, [r14+0x40]
00007fdcd91d597c  mov [r15+0x58], r12
00007fdcd91d5980  movaps xmm8, xmm12
00007fdcd91d5984  mulpd xmm8, xmm15
00007fdcd91d5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007fdcd91d598f  ptest xmm7, xmm7
00007fdcd91d5994  jnz 0x00007FDCD91D67B7
00007fdcd91d599a  movq xmm15, qword ptr [r15+0x230]
00007fdcd91d59a3  vmovaps [rsp+0x70], xmm15
00007fdcd91d59a9  vpermilpd xmm15, xmm15, 0x00
00007fdcd91d59af  movaps xmm7, xmm9
00007fdcd91d59b3  mulpd xmm7, xmm15
00007fdcd91d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007fdcd91d59bd  ptest xmm6, xmm6
00007fdcd91d59c2  jnz 0x00007FDCD91D68FB
00007fdcd91d59c8  vxorps xmm15, xmm15, xmm15
00007fdcd91d59cd  vpbroadcastq xmm15, xmm15
00007fdcd91d59d2  movaps xmm9, xmm12
00007fdcd91d59d6  mulpd xmm9, xmm10
00007fdcd91d59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007fdcd91d59e1  ptest xmm6, xmm6
00007fdcd91d59e6  jnz 0x00007FDCD91D6A3D
00007fdcd91d59ec  movaps xmm10, xmm12
00007fdcd91d59f0  mulpd xmm10, xmm11
00007fdcd91d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007fdcd91d59fb  ptest xmm6, xmm6
00007fdcd91d5a00  jnz 0x00007FDCD91D6B81
00007fdcd91d5a06  movaps xmm11, [r15+0x1F0]
00007fdcd91d5a0e  movaps xmm6, xmm12
00007fdcd91d5a12  mulpd xmm6, xmm11
00007fdcd91d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007fdcd91d5a1c  ptest xmm5, xmm5
00007fdcd91d5a21  jnz 0x00007FDCD91D6CC5
00007fdcd91d5a27  movaps xmm12, [r15+0x2A0]
00007fdcd91d5a2f  vmovaps [rsp+0x80], xmm12
00007fdcd91d5a38  vmovaps xmm11, [rsp+0x80]
00007fdcd91d5a41  por xmm12, xmm11
00007fdcd91d5a46  movaps xmm11, [r15+0x250]
00007fdcd91d5a4e  vmovaps [rsp+0x80], xmm11
00007fdcd91d5a57  vmovaps xmm5, [rsp+0x80]
00007fdcd91d5a60  por xmm11, xmm5
00007fdcd91d5a65  vmovaps xmm4, [rsp+0x70]
00007fdcd91d5a6b  vpermilpd xmm4, xmm4, 0x00
00007fdcd91d5a71  movaps xmm3, xmm5
00007fdcd91d5a74  mulpd xmm3, xmm4
00007fdcd91d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007fdcd91d5a7d  ptest xmm2, xmm2
00007fdcd91d5a82  jnz 0x00007FDCD91D6E07
00007fdcd91d5a88  mov [rsp+0x80], rax
00007fdcd91d5a90  xor eax, eax
00007fdcd91d5a92  mov r14d, 0x200
00007fdcd91d5a98  cmp r12, r14
00007fdcd91d5a9b  cmc
00007fdcd91d5a9c  lahf
00007fdcd91d5a9d  seto al
00007fdcd91d5aa0  mov [r15+0x108], eax
00007fdcd91d5aa7  movaps xmm5, xmm8
00007fdcd91d5aab  addpd xmm5, xmm15
00007fdcd91d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007fdcd91d5ab5  ptest xmm4, xmm4
00007fdcd91d5aba  jnz 0x00007FDCD91D6F47
00007fdcd91d5ac0  movaps xmm8, [r15+0x1B0]
00007fdcd91d5ac8  movaps xmm4, xmm9
00007fdcd91d5acc  addpd xmm4, xmm8
00007fdcd91d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007fdcd91d5ad6  ptest xmm2, xmm2
00007fdcd91d5adb  jnz 0x00007FDCD91D7089
00007fdcd91d5ae1  movaps xmm9, xmm10
00007fdcd91d5ae5  addpd xmm9, xmm8
00007fdcd91d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007fdcd91d5af0  ptest xmm2, xmm2
00007fdcd91d5af5  jnz 0x00007FDCD91D71CB
00007fdcd91d5afb  movaps xmm10, [r15+0x2F0]
00007fdcd91d5b03  vmovaps [rsp+0x90], xmm10
00007fdcd91d5b0c  vmovaps xmm8, [rsp+0x90]
00007fdcd91d5b15  por xmm10, xmm8
00007fdcd91d5b1a  movaps xmm8, [r15+0x2E0]
00007fdcd91d5b22  vmovaps [rsp+0x90], xmm8
00007fdcd91d5b2b  vmovaps xmm2, [rsp+0x90]
00007fdcd91d5b34  por xmm8, xmm2
00007fdcd91d5b39  movaps xmm2, [r15+0x2D0]
00007fdcd91d5b41  vmovaps [rsp+0x90], xmm2
00007fdcd91d5b4a  vmovaps [rsp+0xA0], xmm1
00007fdcd91d5b53  vmovaps xmm1, [rsp+0x90]
00007fdcd91d5b5c  por xmm2, xmm1
00007fdcd91d5b60  movaps xmm1, [r15+0x200]
00007fdcd91d5b68  vmovaps [rsp+0x90], xmm1
00007fdcd91d5b71  vmovaps [rsp+0xB0], xmm15
00007fdcd91d5b7a  vmovaps xmm15, [rsp+0x90]
00007fdcd91d5b83  por xmm1, xmm15
00007fdcd91d5b88  movaps xmm15, [r15+0x1C0]
00007fdcd91d5b90  vmovaps [rsp+0x90], xmm15
00007fdcd91d5b99  vmovaps [rsp+0xC0], xmm1
00007fdcd91d5ba2  vmovaps xmm1, [rsp+0x90]
00007fdcd91d5bab  por xmm15, xmm1
00007fdcd91d5bb0  movaps xmm1, [r15+0x190]
00007fdcd91d5bb8  vmovaps [rsp+0x90], xmm1
00007fdcd91d5bc1  vmovaps [rsp+0xD0], xmm15
00007fdcd91d5bca  vmovaps xmm15, [rsp+0x90]
00007fdcd91d5bd3  por xmm1, xmm15
00007fdcd91d5bd8  movaps xmm15, [r15+0x300]
00007fdcd91d5be0  vmovaps [rsp+0x90], xmm15
00007fdcd91d5be9  vmovaps [rsp+0xE0], xmm1
00007fdcd91d5bf2  vmovaps xmm1, [rsp+0x90]
00007fdcd91d5bfb  por xmm15, xmm1
00007fdcd91d5c00  mov rax, [rsp+0x80]
00007fdcd91d5c08  lea r14, [rax+0xA0]
00007fdcd91d5c0f  movups xmm1, [r13+r14*1]
00007fdcd91d5c15  lea r14, [rax+0xB0]
00007fdcd91d5c1c  vmovaps [rsp+0x80], xmm1
00007fdcd91d5c25  movups xmm1, [r13+r14*1]
00007fdcd91d5c2b  vmovaps [rsp+0x90], xmm1
00007fdcd91d5c34  vmovaps [rsp+0xF0], xmm15
00007fdcd91d5c3d  vmovaps xmm15, [rsp+0xB0]
00007fdcd91d5c46  vmovaps [rsp+0xB0], xmm14
00007fdcd91d5c4f  movaps xmm1, xmm6
00007fdcd91d5c52  addpd xmm1, xmm15
00007fdcd91d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007fdcd91d5c5c  ptest xmm14, xmm14
00007fdcd91d5c62  jnz 0x00007FDCD91D7323
00007fdcd91d5c68  lea r14, [rax+0xF0]
00007fdcd91d5c6f  movups xmm15, [r13+r14*1]
00007fdcd91d5c75  movaps xmm14, xmm4
00007fdcd91d5c79  addpd xmm14, xmm3
00007fdcd91d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007fdcd91d5c84  ptest xmm6, xmm6
00007fdcd91d5c89  jnz 0x00007FDCD91D746E
00007fdcd91d5c8f  movaps xmm6, xmm9
00007fdcd91d5c93  addpd xmm6, xmm7
00007fdcd91d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007fdcd91d5c9c  ptest xmm4, xmm4
00007fdcd91d5ca1  jnz 0x00007FDCD91D75B0
00007fdcd91d5ca7  vmovaps xmm9, [rsp+0x70]
00007fdcd91d5cad  vpermilpd xmm9, xmm9, 0x00
00007fdcd91d5cb3  vmovaps xmm4, [rsp+0x90]
00007fdcd91d5cbc  movaps xmm7, xmm4
00007fdcd91d5cbf  mulpd xmm7, xmm9
00007fdcd91d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007fdcd91d5cc9  ptest xmm3, xmm3
00007fdcd91d5cce  jnz 0x00007FDCD91D76F1
00007fdcd91d5cd4  vmovaps xmm9, [rsp+0x50]
00007fdcd91d5cda  vpermilpd xmm9, xmm9, 0x00
00007fdcd91d5ce0  movaps xmm4, xmm15
00007fdcd91d5ce4  mulpd xmm4, xmm9
00007fdcd91d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007fdcd91d5cee  ptest xmm3, xmm3
00007fdcd91d5cf3  jnz 0x00007FDCD91D7832
00007fdcd91d5cf9  lea r14, [rax+0xE0]
00007fdcd91d5d00  movups xmm15, [r13+r14*1]
00007fdcd91d5d06  vmovaps xmm9, [rsp+0x70]
00007fdcd91d5d0c  vpermilpd xmm9, xmm9, 0x00
00007fdcd91d5d12  vmovaps [rsp+0x70], xmm1
00007fdcd91d5d18  vmovaps xmm1, [rsp+0x80]
00007fdcd91d5d21  vmovaps [rsp+0x80], xmm15
00007fdcd91d5d2a  movaps xmm3, xmm1
00007fdcd91d5d2d  mulpd xmm3, xmm9
00007fdcd91d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007fdcd91d5d37  ptest xmm15, xmm15
00007fdcd91d5d3d  jnz 0x00007FDCD91D797E
00007fdcd91d5d43  vmovaps xmm1, [rsp+0xF0]
00007fdcd91d5d4c  vmovaps xmm15, [rsp+0xF0]
00007fdcd91d5d55  por xmm1, xmm15
00007fdcd91d5d5a  movaps [r15+0x300], xmm1
00007fdcd91d5d62  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d5d6b  vmovaps xmm9, [rsp+0xE0]
00007fdcd91d5d74  por xmm15, xmm9
00007fdcd91d5d79  movaps [r15+0x190], xmm15
00007fdcd91d5d81  vmovaps xmm9, [rsp+0x50]
00007fdcd91d5d87  vpermilpd xmm9, xmm9, 0x00
00007fdcd91d5d8d  vmovaps [rsp+0x90], xmm1
00007fdcd91d5d96  vmovaps [rsp+0xE0], xmm15
00007fdcd91d5d9f  vmovaps xmm15, [rsp+0x80]
00007fdcd91d5da8  vmovaps [rsp+0x80], xmm14
00007fdcd91d5db1  movaps xmm1, xmm15
00007fdcd91d5db5  mulpd xmm1, xmm9
00007fdcd91d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007fdcd91d5dbf  ptest xmm14, xmm14
00007fdcd91d5dc5  jnz 0x00007FDCD91D7ABF
00007fdcd91d5dcb  lea r14, [rax+0x90]
00007fdcd91d5dd2  movups xmm15, [r13+r14*1]
00007fdcd91d5dd8  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d5de1  vmovaps xmm9, [rsp+0xD0]
00007fdcd91d5dea  por xmm14, xmm9
00007fdcd91d5def  movaps [r15+0x1C0], xmm14
00007fdcd91d5df7  vmovaps xmm9, [rsp+0xC0]
00007fdcd91d5e00  vmovaps [rsp+0xD0], xmm1
00007fdcd91d5e09  vmovaps xmm1, [rsp+0xC0]
00007fdcd91d5e12  por xmm9, xmm1
00007fdcd91d5e17  movaps [r15+0x200], xmm9
00007fdcd91d5e1f  vmovaps [rsp+0xC0], xmm2
00007fdcd91d5e28  vmovaps xmm1, [rsp+0xC0]
00007fdcd91d5e31  por xmm2, xmm1
00007fdcd91d5e35  movaps [r15+0x2D0], xmm2
00007fdcd91d5e3d  vmovaps [rsp+0xC0], xmm8
00007fdcd91d5e46  vmovaps xmm1, [rsp+0xC0]
00007fdcd91d5e4f  por xmm8, xmm1
00007fdcd91d5e54  movaps [r15+0x2E0], xmm8
00007fdcd91d5e5c  vmovaps [rsp+0xC0], xmm15
00007fdcd91d5e65  movaps xmm1, xmm5
00007fdcd91d5e68  addpd xmm1, xmm7
00007fdcd91d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007fdcd91d5e71  ptest xmm15, xmm15
00007fdcd91d5e77  jnz 0x00007FDCD91D7C0B
00007fdcd91d5e7d  vmovaps xmm15, [rsp+0x50]
00007fdcd91d5e83  vpermilpd xmm15, xmm15, 0x00
00007fdcd91d5e89  vmovaps xmm5, [rsp+0xC0]
00007fdcd91d5e92  vmovaps [rsp+0xC0], xmm1
00007fdcd91d5e9b  movaps xmm7, xmm5
00007fdcd91d5e9e  mulpd xmm7, xmm15
00007fdcd91d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007fdcd91d5ea8  ptest xmm1, xmm1
00007fdcd91d5ead  jnz 0x00007FDCD91D7D4B
00007fdcd91d5eb3  lea r14, [rax+0x80]
00007fdcd91d5eba  movups xmm1, [r13+r14*1]
00007fdcd91d5ec0  vmovaps xmm5, [rsp+0x70]
00007fdcd91d5ec6  vmovaps [rsp+0x70], xmm1
00007fdcd91d5ecc  movaps xmm15, xmm5
00007fdcd91d5ed0  addpd xmm15, xmm3
00007fdcd91d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007fdcd91d5edb  ptest xmm1, xmm1
00007fdcd91d5ee0  jnz 0x00007FDCD91D7E96
00007fdcd91d5ee6  vmovaps xmm5, [rsp+0x80]
00007fdcd91d5eef  movaps xmm1, xmm5
00007fdcd91d5ef2  addpd xmm1, xmm4
00007fdcd91d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007fdcd91d5efb  ptest xmm3, xmm3
00007fdcd91d5f00  jnz 0x00007FDCD91D7FD8
00007fdcd91d5f06  vmovaps [rsp+0x80], xmm10
00007fdcd91d5f0f  vmovaps xmm5, [rsp+0x80]
00007fdcd91d5f18  por xmm10, xmm5
00007fdcd91d5f1d  movaps [r15+0x2F0], xmm10
00007fdcd91d5f25  vmovaps xmm5, [rsp+0x50]
00007fdcd91d5f2b  vpermilpd xmm5, xmm5, 0x00
00007fdcd91d5f31  vmovaps xmm3, [rsp+0x70]
00007fdcd91d5f37  vmovaps [rsp+0x50], xmm1
00007fdcd91d5f3d  movaps xmm4, xmm3
00007fdcd91d5f40  mulpd xmm4, xmm5
00007fdcd91d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007fdcd91d5f49  ptest xmm1, xmm1
00007fdcd91d5f4e  jnz 0x00007FDCD91D8118
00007fdcd91d5f54  lea r14, [rax+0xD0]
00007fdcd91d5f5b  movups xmm1, [r13+r14*1]
00007fdcd91d5f61  vmovaps xmm3, [rsp+0xD0]
00007fdcd91d5f6a  vmovaps [rsp+0x70], xmm1
00007fdcd91d5f70  movaps xmm5, xmm6
00007fdcd91d5f73  addpd xmm5, xmm3
00007fdcd91d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007fdcd91d5f7c  ptest xmm1, xmm1
00007fdcd91d5f81  jnz 0x00007FDCD91D8262
00007fdcd91d5f87  vmovaps xmm1, [rsp+0x60]
00007fdcd91d5f8d  vpermilpd xmm1, xmm1, 0x00
00007fdcd91d5f93  movaps xmm6, xmm9
00007fdcd91d5f97  mulpd xmm6, xmm1
00007fdcd91d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007fdcd91d5fa0  ptest xmm3, xmm3
00007fdcd91d5fa5  jnz 0x00007FDCD91D83A2
00007fdcd91d5fab  movaps [r15+0x260], xmm6
00007fdcd91d5fb3  vxorps xmm1, xmm1, xmm1
00007fdcd91d5fb7  vpbroadcastq xmm1, xmm1
00007fdcd91d5fbc  movaps [r15+0x1B0], xmm1
00007fdcd91d5fc4  vmovaps xmm1, [rsp+0x60]
00007fdcd91d5fca  vpermilpd xmm1, xmm1, 0x00
00007fdcd91d5fd0  vmovaps xmm3, [rsp+0x70]
00007fdcd91d5fd6  vmovaps [rsp+0x70], xmm15
00007fdcd91d5fdc  movaps xmm9, xmm3
00007fdcd91d5fe0  mulpd xmm9, xmm1
00007fdcd91d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007fdcd91d5feb  ptest xmm15, xmm15
00007fdcd91d5ff1  jnz 0x00007FDCD91D84E3
00007fdcd91d5ff7  lea r14, [rax+0xC0]
00007fdcd91d5ffe  movups xmm1, [r13+r14*1]
00007fdcd91d6004  vmovaps xmm3, [rsp+0xC0]
00007fdcd91d600d  vmovaps [rsp+0x80], xmm1
00007fdcd91d6016  movaps xmm15, xmm3
00007fdcd91d601a  addpd xmm15, xmm7
00007fdcd91d601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007fdcd91d6025  ptest xmm1, xmm1
00007fdcd91d602a  jnz 0x00007FDCD91D862F
00007fdcd91d6030  vmovaps [rsp+0xC0], xmm13
00007fdcd91d6039  vmovaps xmm1, [rsp+0xC0]
00007fdcd91d6042  por xmm13, xmm1
00007fdcd91d6047  movaps [r15+0x270], xmm13
00007fdcd91d604f  vmovaps xmm1, [rsp+0xB0]
00007fdcd91d6058  vmovaps xmm7, [rsp+0xB0]
00007fdcd91d6061  por xmm1, xmm7
00007fdcd91d6065  movaps [r15+0x1A0], xmm1
00007fdcd91d606d  vmovaps xmm1, [rsp+0x60]
00007fdcd91d6073  vpermilpd xmm1, xmm1, 0x00
00007fdcd91d6079  vmovaps [rsp+0xB0], xmm1
00007fdcd91d6082  vmovaps xmm1, [rsp+0x80]
00007fdcd91d608b  vmovaps [rsp+0x80], xmm15
00007fdcd91d6094  vmovaps xmm15, [rsp+0xB0]
00007fdcd91d609d  vmovaps [rsp+0xB0], xmm14
00007fdcd91d60a6  movaps xmm3, xmm1
00007fdcd91d60a9  mulpd xmm3, xmm15
00007fdcd91d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007fdcd91d60b3  ptest xmm14, xmm14
00007fdcd91d60b9  jnz 0x00007FDCD91D8771
00007fdcd91d60bf  lea r14, [rax+0x20]
00007fdcd91d60c3  movups xmm1, [r13+r14*1]
00007fdcd91d60c9  movaps [r15+0x110], xmm1
00007fdcd91d60d1  vmovaps xmm14, [rsp+0x70]
00007fdcd91d60d7  vmovaps [rsp+0x70], xmm1
00007fdcd91d60dd  movaps xmm15, xmm14
00007fdcd91d60e1  addpd xmm15, xmm4
00007fdcd91d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007fdcd91d60ec  ptest xmm1, xmm1
00007fdcd91d60f1  jnz 0x00007FDCD91D88BC
00007fdcd91d60f7  vmovaps xmm1, [rsp+0x60]
00007fdcd91d60fd  vpermilpd xmm1, xmm1, 0x00
00007fdcd91d6103  movaps xmm14, xmm2
00007fdcd91d6107  mulpd xmm14, xmm1
00007fdcd91d610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007fdcd91d6112  ptest xmm4, xmm4
00007fdcd91d6117  jnz 0x00007FDCD91D89FF
00007fdcd91d611d  vmovaps xmm4, [rsp+0x50]
00007fdcd91d6123  movaps xmm1, xmm4
00007fdcd91d6126  addpd xmm1, xmm9
00007fdcd91d612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007fdcd91d6130  ptest xmm2, xmm2
00007fdcd91d6135  jnz 0x00007FDCD91D8B41
00007fdcd91d613b  vmovaps xmm9, [rsp+0x30]
00007fdcd91d6141  vpermilpd xmm9, xmm9, 0x00
00007fdcd91d6147  vmovaps xmm2, [rsp+0x70]
00007fdcd91d614d  vmovaps [rsp+0x50], xmm1
00007fdcd91d6153  movaps xmm4, xmm2
00007fdcd91d6156  mulpd xmm4, xmm9
00007fdcd91d615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007fdcd91d6160  ptest xmm1, xmm1
00007fdcd91d6165  jnz 0x00007FDCD91D8C82
00007fdcd91d616b  vmovaps xmm1, [rsp+0x30]
00007fdcd91d6171  vpermilpd xmm1, xmm1, 0x00
00007fdcd91d6177  vmovaps xmm2, [rsp+0x90]
00007fdcd91d6180  vmovaps [rsp+0x60], xmm15
00007fdcd91d6186  movaps xmm9, xmm2
00007fdcd91d618a  mulpd xmm9, xmm1
00007fdcd91d618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007fdcd91d6195  ptest xmm15, xmm15
00007fdcd91d619b  jnz 0x00007FDCD91D8DC3
00007fdcd91d61a1  vmovaps xmm15, [rsp+0x80]
00007fdcd91d61aa  movaps xmm1, xmm15
00007fdcd91d61ae  addpd xmm1, xmm6
00007fdcd91d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007fdcd91d61b7  ptest xmm2, xmm2
00007fdcd91d61bc  jnz 0x00007FDCD91D8F05
00007fdcd91d61c2  movaps xmm15, xmm5
00007fdcd91d61c6  addpd xmm15, xmm3
00007fdcd91d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007fdcd91d61d1  ptest xmm6, xmm6
00007fdcd91d61d6  jnz 0x00007FDCD91D9046
00007fdcd91d61dc  vmovaps xmm6, [rsp+0x30]
00007fdcd91d61e2  vpermilpd xmm6, xmm6, 0x00
00007fdcd91d61e8  movaps xmm5, xmm8
00007fdcd91d61ec  mulpd xmm5, xmm6
00007fdcd91d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007fdcd91d61f5  ptest xmm3, xmm3
00007fdcd91d61fa  jnz 0x00007FDCD91D9188
00007fdcd91d6200  vmovaps xmm8, [rsp+0x30]
00007fdcd91d6206  vpermilpd xmm8, xmm8, 0x00
00007fdcd91d620c  movaps xmm6, xmm10
00007fdcd91d6210  mulpd xmm6, xmm8
00007fdcd91d6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007fdcd91d621a  ptest xmm3, xmm3
00007fdcd91d621f  jnz 0x00007FDCD91D92C9
00007fdcd91d6225  vmovaps xmm8, [rsp+0x60]
00007fdcd91d622b  movaps xmm10, xmm8
00007fdcd91d622f  addpd xmm10, xmm14
00007fdcd91d6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007fdcd91d623a  ptest xmm3, xmm3
00007fdcd91d623f  jnz 0x00007FDCD91D940B
00007fdcd91d6245  vmovaps xmm8, [rsp+0x50]
00007fdcd91d624b  movaps xmm14, xmm8
00007fdcd91d624f  addpd xmm14, xmm4
00007fdcd91d6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007fdcd91d625a  ptest xmm3, xmm3
00007fdcd91d625f  jnz 0x00007FDCD91D954F
00007fdcd91d6265  vmovaps xmm8, [rsp+0x40]
00007fdcd91d626b  vpermilpd xmm8, xmm8, 0x00
00007fdcd91d6271  movaps xmm4, xmm13
00007fdcd91d6275  mulpd xmm4, xmm8
00007fdcd91d627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007fdcd91d627f  ptest xmm3, xmm3
00007fdcd91d6284  jnz 0x00007FDCD91D9692
00007fdcd91d628a  movaps xmm13, xmm15
00007fdcd91d628e  addpd xmm13, xmm9
00007fdcd91d6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007fdcd91d6299  ptest xmm8, xmm8
00007fdcd91d629f  jnz 0x00007FDCD91D97D4
00007fdcd91d62a5  movaps xmm15, xmm1
00007fdcd91d62a9  addpd xmm15, xmm5
00007fdcd91d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007fdcd91d62b4  ptest xmm9, xmm9
00007fdcd91d62ba  jnz 0x00007FDCD91D9918
00007fdcd91d62c0  vmovaps [rsp+0x30], xmm11
00007fdcd91d62c6  vmovaps xmm1, [rsp+0x30]
00007fdcd91d62cc  por xmm11, xmm1
00007fdcd91d62d1  movaps [r15+0x250], xmm11
00007fdcd91d62d9  vmovaps [rsp+0x30], xmm12
00007fdcd91d62df  vmovaps xmm1, [rsp+0x30]
00007fdcd91d62e5  por xmm12, xmm1
00007fdcd91d62ea  movaps [r15+0x2A0], xmm12
00007fdcd91d62f2  vmovaps xmm1, [rsp+0xA0]
00007fdcd91d62fb  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d6304  por xmm1, xmm11
00007fdcd91d6309  movaps [r15+0x1D0], xmm1
00007fdcd91d6311  lea r14, [rax+0x40]
00007fdcd91d6315  movups xmm1, [r13+r14*1]
00007fdcd91d631b  movaps [r15+0x2C0], xmm1
00007fdcd91d6323  vmovaps xmm11, [rsp+0x40]
00007fdcd91d6329  vpermilpd xmm11, xmm11, 0x00
00007fdcd91d632f  vmovaps xmm8, [rsp+0xE0]
00007fdcd91d6338  movaps xmm9, xmm8
00007fdcd91d633c  mulpd xmm9, xmm11
00007fdcd91d6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007fdcd91d6347  ptest xmm5, xmm5
00007fdcd91d634c  jnz 0x00007FDCD91D9A64
00007fdcd91d6352  movaps xmm11, xmm10
00007fdcd91d6356  addpd xmm11, xmm6
00007fdcd91d635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007fdcd91d6361  ptest xmm8, xmm8
00007fdcd91d6367  jnz 0x00007FDCD91D9BA8
00007fdcd91d636d  movaps xmm10, xmm14
00007fdcd91d6371  addpd xmm10, xmm4
00007fdcd91d6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007fdcd91d637c  ptest xmm8, xmm8
00007fdcd91d6382  jnz 0x00007FDCD91D9CEB
00007fdcd91d6388  vmovaps xmm14, [rsp+0x40]
00007fdcd91d638e  vpermilpd xmm14, xmm14, 0x00
00007fdcd91d6394  movaps xmm8, xmm1
00007fdcd91d6398  mulpd xmm8, xmm14
00007fdcd91d639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007fdcd91d63a3  ptest xmm6, xmm6
00007fdcd91d63a8  jnz 0x00007FDCD91D9E2E
00007fdcd91d63ae  movaps xmm1, [r15+0x2B0]
00007fdcd91d63b6  vmovaps xmm14, [rsp+0x40]
00007fdcd91d63bc  vpermilpd xmm14, xmm14, 0x00
00007fdcd91d63c2  movaps xmm6, xmm1
00007fdcd91d63c5  mulpd xmm6, xmm14
00007fdcd91d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007fdcd91d63cf  ptest xmm5, xmm5
00007fdcd91d63d4  jnz 0x00007FDCD91D9F71
00007fdcd91d63da  vmovaps xmm1, [rsp+0x10]
00007fdcd91d63e0  vpermilpd xmm1, xmm1, 0x00
00007fdcd91d63e6  movaps xmm14, xmm12
00007fdcd91d63ea  mulpd xmm14, xmm1
00007fdcd91d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007fdcd91d63f5  ptest xmm5, xmm5
00007fdcd91d63fa  jnz 0x00007FDCD91DA0B2
00007fdcd91d6400  movaps xmm1, xmm13
00007fdcd91d6404  addpd xmm1, xmm9
00007fdcd91d6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007fdcd91d640e  ptest xmm12, xmm12
00007fdcd91d6414  jnz 0x00007FDCD91DA1F5
00007fdcd91d641a  vmovaps xmm13, [rsp+0x10]
00007fdcd91d6420  vpermilpd xmm13, xmm13, 0x00
00007fdcd91d6426  movaps xmm12, xmm7
00007fdcd91d642a  mulpd xmm12, xmm13
00007fdcd91d642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007fdcd91d6435  ptest xmm9, xmm9
00007fdcd91d643b  jnz 0x00007FDCD91DA337
00007fdcd91d6441  movaps xmm13, xmm15
00007fdcd91d6445  addpd xmm13, xmm8
00007fdcd91d644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007fdcd91d6450  ptest xmm9, xmm9
00007fdcd91d6456  jnz 0x00007FDCD91DA47A
00007fdcd91d645c  movaps xmm15, [r15+0x290]
00007fdcd91d6464  vmovaps xmm9, [rsp+0x10]
00007fdcd91d646a  vpermilpd xmm9, xmm9, 0x00
00007fdcd91d6470  movaps xmm8, xmm15
00007fdcd91d6474  mulpd xmm8, xmm9
00007fdcd91d6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007fdcd91d647f  ptest xmm7, xmm7
00007fdcd91d6484  jnz 0x00007FDCD91DA5BE
00007fdcd91d648a  movaps xmm15, xmm11
00007fdcd91d648e  addpd xmm15, xmm6
00007fdcd91d6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007fdcd91d6499  ptest xmm9, xmm9
00007fdcd91d649f  jnz 0x00007FDCD91DA702
00007fdcd91d64a5  movaps xmm11, [r15+0x1E0]
00007fdcd91d64ad  vmovaps xmm9, [rsp+0x10]
00007fdcd91d64b3  vpermilpd xmm9, xmm9, 0x00
00007fdcd91d64b9  movaps xmm7, xmm11
00007fdcd91d64bd  mulpd xmm7, xmm9
00007fdcd91d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007fdcd91d64c7  ptest xmm6, xmm6
00007fdcd91d64cc  jnz 0x00007FDCD91DA845
00007fdcd91d64d2  movaps xmm11, xmm10
00007fdcd91d64d6  addpd xmm11, xmm14
00007fdcd91d64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007fdcd91d64e1  ptest xmm9, xmm9
00007fdcd91d64e7  jnz 0x00007FDCD91DA987
00007fdcd91d64ed  lea r14, [rax+0x70]
00007fdcd91d64f1  movups xmm14, [r13+r14*1]
00007fdcd91d64f7  movaps [r15+0x240], xmm14
00007fdcd91d64ff  movaps xmm10, xmm1
00007fdcd91d6503  addpd xmm10, xmm12
00007fdcd91d6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007fdcd91d650e  ptest xmm9, xmm9
00007fdcd91d6514  jnz 0x00007FDCD91DAAD5
00007fdcd91d651a  movaps [r15+0x170], xmm10
00007fdcd91d6522  vmovaps xmm1, [rsp+0x20]
00007fdcd91d6528  vpermilpd xmm1, xmm1, 0x00
00007fdcd91d652e  movaps xmm12, xmm14
00007fdcd91d6532  mulpd xmm12, xmm1
00007fdcd91d6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007fdcd91d653d  ptest xmm9, xmm9
00007fdcd91d6543  jnz 0x00007FDCD91DAC18
00007fdcd91d6549  vmovaps xmm1, [rsp+0x20]
00007fdcd91d654f  vpermilpd xmm1, xmm1, 0x00
00007fdcd91d6555  vmovaps xmm9, [rsp+0xB0]
00007fdcd91d655e  movaps xmm14, xmm9
00007fdcd91d6562  mulpd xmm14, xmm1
00007fdcd91d6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007fdcd91d656d  ptest xmm6, xmm6
00007fdcd91d6572  jnz 0x00007FDCD91DAD5B
00007fdcd91d6578  movaps [r15+0x180], xmm14
00007fdcd91d6580  movaps xmm1, xmm13
00007fdcd91d6584  addpd xmm1, xmm8
00007fdcd91d6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007fdcd91d658e  ptest xmm9, xmm9
00007fdcd91d6594  jnz 0x00007FDCD91DAE9E
00007fdcd91d659a  movaps [r15+0x210], xmm1
00007fdcd91d65a2  movups xmm13, [r13+rax*1]
00007fdcd91d65a8  lea r14, [rax+0x10]
00007fdcd91d65ac  movups xmm9, [r13+r14*1]
00007fdcd91d65b2  movaps [r15+0x230], xmm9
00007fdcd91d65ba  movaps xmm8, xmm15
00007fdcd91d65be  addpd xmm8, xmm7
00007fdcd91d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007fdcd91d65c9  ptest xmm6, xmm6
00007fdcd91d65ce  jnz 0x00007FDCD91DAFF4
00007fdcd91d65d4  movaps [r15+0x130], xmm8
00007fdcd91d65dc  vmovaps xmm15, [rsp+0x20]
00007fdcd91d65e2  vpermilpd xmm15, xmm15, 0x00
00007fdcd91d65e8  movaps xmm7, xmm9
00007fdcd91d65ec  mulpd xmm7, xmm15
00007fdcd91d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007fdcd91d65f6  ptest xmm6, xmm6
00007fdcd91d65fb  jnz 0x00007FDCD91DB137
00007fdcd91d6601  movaps [r15+0x220], xmm7
00007fdcd91d6609  vmovaps xmm15, [rsp+0x20]
00007fdcd91d660f  vpermilpd xmm15, xmm15, 0x00
00007fdcd91d6615  movaps xmm9, xmm13
00007fdcd91d6619  mulpd xmm9, xmm15
00007fdcd91d661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007fdcd91d6624  ptest xmm6, xmm6
00007fdcd91d6629  jnz 0x00007FDCD91DB279
00007fdcd91d662f  movaps xmm15, xmm11
00007fdcd91d6633  addpd xmm15, xmm12
00007fdcd91d6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007fdcd91d663e  ptest xmm13, xmm13
00007fdcd91d6644  jnz 0x00007FDCD91DB3BD
00007fdcd91d664a  movaps [r15+0x140], xmm15
00007fdcd91d6652  movaps xmm13, xmm10
00007fdcd91d6656  addpd xmm13, xmm14
00007fdcd91d665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007fdcd91d6661  ptest xmm12, xmm12
00007fdcd91d6667  jnz 0x00007FDCD91DB501
00007fdcd91d666d  movaps [r15+0x150], xmm13
00007fdcd91d6675  movaps xmm14, xmm1
00007fdcd91d6679  addpd xmm14, xmm7
00007fdcd91d667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007fdcd91d6684  ptest xmm12, xmm12
00007fdcd91d668a  jnz 0x00007FDCD91DB645
00007fdcd91d6690  movaps [r15+0x160], xmm14
00007fdcd91d6698  movaps xmm1, xmm8
00007fdcd91d669c  addpd xmm1, xmm9
00007fdcd91d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007fdcd91d66a6  ptest xmm12, xmm12
00007fdcd91d66ac  jnz 0x00007FDCD91DB787
00007fdcd91d66b2  movaps [r15+0x120], xmm1
00007fdcd91d66ba  movups [r13+r11*1], xmm15
00007fdcd91d66c0  lea rax, [r11+0x10]
00007fdcd91d66c4  movups [r13+rax*1], xmm13
00007fdcd91d66ca  lea rax, [r11+0x20]
00007fdcd91d66ce  movups [r13+rax*1], xmm14
00007fdcd91d66d4  lea rax, [r11+0x30]
00007fdcd91d66d8  movups [r13+rax*1], xmm1
00007fdcd91d66de  mov eax, [r15+0x108]
00007fdcd91d66e5  sahf
00007fdcd91d66e6  jnz 0x00007FDCD91D6718
00007fdcd91d66e8  cmp dword ptr [r15+0x318], 0x00
00007fdcd91d66f0  jz 0x00007FDCD91DB900
00007fdcd91d66f6  nop [rax+rax*1], ax
00007fdcd91d66ff  nop [rax+rax*1], eax
00007fdcd91d6707  mov eax, 0x410444
00007fdcd91d670c  mov [r15+0x100], rax
00007fdcd91d6713  jmp 0x00007FDCD8FFE110
00007fdcd91d6718  cmp dword ptr [r15+0x318], 0x00
00007fdcd91d6720  jz 0x00007FDCD91D57E0
00007fdcd91d6726  nop [rax+rax*1], ax
00007fdcd91d672f  nop [rax+rax*1], eax
00007fdcd91d6737  mov eax, 0x410278
00007fdcd91d673c  mov [r15+0x100], rax
00007fdcd91d6743  jmp 0x00007FDCD8FFE110
00007fdcd91d6748  int3
00007fdcd91d6749  call 0x00007FDCD900A4B0
00007fdcd91d674e  jmp 0x00007FDCD91D5828
00007fdcd91d6753  call 0x00007FDCD9009240
00007fdcd91d6758  jmp 0x00007FDCD91D5832
00007fdcd91d675d  call 0x00007FDCD900A4B0
00007fdcd91d6762  jmp 0x00007FDCD91D588F
00007fdcd91d6767  call 0x00007FDCD9009240
00007fdcd91d676c  jmp 0x00007FDCD91D5899
00007fdcd91d6771  call 0x00007FDCD900A4B0
00007fdcd91d6776  jmp 0x00007FDCD91D58DD
00007fdcd91d677b  call 0x00007FDCD9009240
00007fdcd91d6780  jmp 0x00007FDCD91D58E7
00007fdcd91d6785  call 0x00007FDCD90B47C0
00007fdcd91d678a  jmp 0x00007FDCD91D5926
00007fdcd91d678f  call 0x00007FDCD900B720
00007fdcd91d6794  jmp 0x00007FDCD91D593A
00007fdcd91d6799  call 0x00007FDCD90BFC30
00007fdcd91d679e  jmp 0x00007FDCD91D5958
00007fdcd91d67a3  call 0x00007FDCD90BE9C0
00007fdcd91d67a8  jmp 0x00007FDCD91D5962
00007fdcd91d67ad  call 0x00007FDCD90BD750
00007fdcd91d67b2  jmp 0x00007FDCD91D596C
00007fdcd91d67b7  sub rsp, 0x08
00007fdcd91d67bb  push rax
00007fdcd91d67bc  push rcx
00007fdcd91d67bd  push rdx
00007fdcd91d67be  push rdi
00007fdcd91d67bf  push rsi
00007fdcd91d67c0  push r8
00007fdcd91d67c2  push r9
00007fdcd91d67c4  push r10
00007fdcd91d67c6  push r11
00007fdcd91d67c8  sub rsp, 0xF0
00007fdcd91d67cf  vmovaps [rsp], xmm0
00007fdcd91d67d4  vmovaps [rsp+0x10], xmm1
00007fdcd91d67da  vmovaps [rsp+0x20], xmm2
00007fdcd91d67e0  vmovaps [rsp+0x30], xmm3
00007fdcd91d67e6  vmovaps [rsp+0x40], xmm4
00007fdcd91d67ec  vmovaps [rsp+0x50], xmm5
00007fdcd91d67f2  vmovaps [rsp+0x60], xmm6
00007fdcd91d67f8  vmovaps [rsp+0x70], xmm7
00007fdcd91d67fe  vmovaps [rsp+0x80], xmm9
00007fdcd91d6807  vmovaps [rsp+0x90], xmm10
00007fdcd91d6810  vmovaps [rsp+0xA0], xmm11
00007fdcd91d6819  vmovaps [rsp+0xB0], xmm12
00007fdcd91d6822  vmovaps [rsp+0xC0], xmm13
00007fdcd91d682b  vmovaps [rsp+0xD0], xmm14
00007fdcd91d6834  vmovaps [rsp+0xE0], xmm15
00007fdcd91d683d  sub rsp, 0x30
00007fdcd91d6841  movaps [rsp], xmm8
00007fdcd91d6846  movaps [rsp+0x10], xmm12
00007fdcd91d684c  movaps [rsp+0x20], xmm15
00007fdcd91d6852  lea rdi, [rsp]
00007fdcd91d6856  mov esi, 0x00
00007fdcd91d685b  mov rax, 0x5B56EFBF3530
00007fdcd91d6865  call rax
00007fdcd91d6867  movaps xmm8, [rsp]
00007fdcd91d686c  add rsp, 0x30
00007fdcd91d6870  vmovaps xmm0, [rsp]
00007fdcd91d6875  vmovaps xmm1, [rsp+0x10]
00007fdcd91d687b  vmovaps xmm2, [rsp+0x20]
00007fdcd91d6881  vmovaps xmm3, [rsp+0x30]
00007fdcd91d6887  vmovaps xmm4, [rsp+0x40]
00007fdcd91d688d  vmovaps xmm5, [rsp+0x50]
00007fdcd91d6893  vmovaps xmm6, [rsp+0x60]
00007fdcd91d6899  vmovaps xmm7, [rsp+0x70]
00007fdcd91d689f  vmovaps xmm9, [rsp+0x80]
00007fdcd91d68a8  vmovaps xmm10, [rsp+0x90]
00007fdcd91d68b1  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d68ba  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d68c3  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d68cc  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d68d5  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d68de  add rsp, 0xF0
00007fdcd91d68e5  pop r11
00007fdcd91d68e7  pop r10
00007fdcd91d68e9  pop r9
00007fdcd91d68eb  pop r8
00007fdcd91d68ed  pop rsi
00007fdcd91d68ee  pop rdi
00007fdcd91d68ef  pop rdx
00007fdcd91d68f0  pop rcx
00007fdcd91d68f1  pop rax
00007fdcd91d68f2  add rsp, 0x08
00007fdcd91d68f6  jmp 0x00007FDCD91D599A
00007fdcd91d68fb  sub rsp, 0x08
00007fdcd91d68ff  push rax
00007fdcd91d6900  push rcx
00007fdcd91d6901  push rdx
00007fdcd91d6902  push rdi
00007fdcd91d6903  push rsi
00007fdcd91d6904  push r8
00007fdcd91d6906  push r9
00007fdcd91d6908  push r10
00007fdcd91d690a  push r11
00007fdcd91d690c  sub rsp, 0xF0
00007fdcd91d6913  vmovaps [rsp], xmm0
00007fdcd91d6918  vmovaps [rsp+0x10], xmm1
00007fdcd91d691e  vmovaps [rsp+0x20], xmm2
00007fdcd91d6924  vmovaps [rsp+0x30], xmm3
00007fdcd91d692a  vmovaps [rsp+0x40], xmm4
00007fdcd91d6930  vmovaps [rsp+0x50], xmm5
00007fdcd91d6936  vmovaps [rsp+0x60], xmm6
00007fdcd91d693c  vmovaps [rsp+0x70], xmm8
00007fdcd91d6942  vmovaps [rsp+0x80], xmm9
00007fdcd91d694b  vmovaps [rsp+0x90], xmm10
00007fdcd91d6954  vmovaps [rsp+0xA0], xmm11
00007fdcd91d695d  vmovaps [rsp+0xB0], xmm12
00007fdcd91d6966  vmovaps [rsp+0xC0], xmm13
00007fdcd91d696f  vmovaps [rsp+0xD0], xmm14
00007fdcd91d6978  vmovaps [rsp+0xE0], xmm15
00007fdcd91d6981  sub rsp, 0x30
00007fdcd91d6985  movaps [rsp], xmm7
00007fdcd91d6989  movaps [rsp+0x10], xmm9
00007fdcd91d698f  movaps [rsp+0x20], xmm15
00007fdcd91d6995  lea rdi, [rsp]
00007fdcd91d6999  mov esi, 0x00
00007fdcd91d699e  mov rax, 0x5B56EFBF3530
00007fdcd91d69a8  call rax
00007fdcd91d69aa  movaps xmm7, [rsp]
00007fdcd91d69ae  add rsp, 0x30
00007fdcd91d69b2  vmovaps xmm0, [rsp]
00007fdcd91d69b7  vmovaps xmm1, [rsp+0x10]
00007fdcd91d69bd  vmovaps xmm2, [rsp+0x20]
00007fdcd91d69c3  vmovaps xmm3, [rsp+0x30]
00007fdcd91d69c9  vmovaps xmm4, [rsp+0x40]
00007fdcd91d69cf  vmovaps xmm5, [rsp+0x50]
00007fdcd91d69d5  vmovaps xmm6, [rsp+0x60]
00007fdcd91d69db  vmovaps xmm8, [rsp+0x70]
00007fdcd91d69e1  vmovaps xmm9, [rsp+0x80]
00007fdcd91d69ea  vmovaps xmm10, [rsp+0x90]
00007fdcd91d69f3  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d69fc  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d6a05  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d6a0e  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d6a17  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d6a20  add rsp, 0xF0
00007fdcd91d6a27  pop r11
00007fdcd91d6a29  pop r10
00007fdcd91d6a2b  pop r9
00007fdcd91d6a2d  pop r8
00007fdcd91d6a2f  pop rsi
00007fdcd91d6a30  pop rdi
00007fdcd91d6a31  pop rdx
00007fdcd91d6a32  pop rcx
00007fdcd91d6a33  pop rax
00007fdcd91d6a34  add rsp, 0x08
00007fdcd91d6a38  jmp 0x00007FDCD91D59C8
00007fdcd91d6a3d  sub rsp, 0x08
00007fdcd91d6a41  push rax
00007fdcd91d6a42  push rcx
00007fdcd91d6a43  push rdx
00007fdcd91d6a44  push rdi
00007fdcd91d6a45  push rsi
00007fdcd91d6a46  push r8
00007fdcd91d6a48  push r9
00007fdcd91d6a4a  push r10
00007fdcd91d6a4c  push r11
00007fdcd91d6a4e  sub rsp, 0xF0
00007fdcd91d6a55  vmovaps [rsp], xmm0
00007fdcd91d6a5a  vmovaps [rsp+0x10], xmm1
00007fdcd91d6a60  vmovaps [rsp+0x20], xmm2
00007fdcd91d6a66  vmovaps [rsp+0x30], xmm3
00007fdcd91d6a6c  vmovaps [rsp+0x40], xmm4
00007fdcd91d6a72  vmovaps [rsp+0x50], xmm5
00007fdcd91d6a78  vmovaps [rsp+0x60], xmm6
00007fdcd91d6a7e  vmovaps [rsp+0x70], xmm7
00007fdcd91d6a84  vmovaps [rsp+0x80], xmm8
00007fdcd91d6a8d  vmovaps [rsp+0x90], xmm10
00007fdcd91d6a96  vmovaps [rsp+0xA0], xmm11
00007fdcd91d6a9f  vmovaps [rsp+0xB0], xmm12
00007fdcd91d6aa8  vmovaps [rsp+0xC0], xmm13
00007fdcd91d6ab1  vmovaps [rsp+0xD0], xmm14
00007fdcd91d6aba  vmovaps [rsp+0xE0], xmm15
00007fdcd91d6ac3  sub rsp, 0x30
00007fdcd91d6ac7  movaps [rsp], xmm9
00007fdcd91d6acc  movaps [rsp+0x10], xmm12
00007fdcd91d6ad2  movaps [rsp+0x20], xmm10
00007fdcd91d6ad8  lea rdi, [rsp]
00007fdcd91d6adc  mov esi, 0x00
00007fdcd91d6ae1  mov rax, 0x5B56EFBF3530
00007fdcd91d6aeb  call rax
00007fdcd91d6aed  movaps xmm9, [rsp]
00007fdcd91d6af2  add rsp, 0x30
00007fdcd91d6af6  vmovaps xmm0, [rsp]
00007fdcd91d6afb  vmovaps xmm1, [rsp+0x10]
00007fdcd91d6b01  vmovaps xmm2, [rsp+0x20]
00007fdcd91d6b07  vmovaps xmm3, [rsp+0x30]
00007fdcd91d6b0d  vmovaps xmm4, [rsp+0x40]
00007fdcd91d6b13  vmovaps xmm5, [rsp+0x50]
00007fdcd91d6b19  vmovaps xmm6, [rsp+0x60]
00007fdcd91d6b1f  vmovaps xmm7, [rsp+0x70]
00007fdcd91d6b25  vmovaps xmm8, [rsp+0x80]
00007fdcd91d6b2e  vmovaps xmm10, [rsp+0x90]
00007fdcd91d6b37  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d6b40  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d6b49  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d6b52  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d6b5b  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d6b64  add rsp, 0xF0
00007fdcd91d6b6b  pop r11
00007fdcd91d6b6d  pop r10
00007fdcd91d6b6f  pop r9
00007fdcd91d6b71  pop r8
00007fdcd91d6b73  pop rsi
00007fdcd91d6b74  pop rdi
00007fdcd91d6b75  pop rdx
00007fdcd91d6b76  pop rcx
00007fdcd91d6b77  pop rax
00007fdcd91d6b78  add rsp, 0x08
00007fdcd91d6b7c  jmp 0x00007FDCD91D59EC
00007fdcd91d6b81  sub rsp, 0x08
00007fdcd91d6b85  push rax
00007fdcd91d6b86  push rcx
00007fdcd91d6b87  push rdx
00007fdcd91d6b88  push rdi
00007fdcd91d6b89  push rsi
00007fdcd91d6b8a  push r8
00007fdcd91d6b8c  push r9
00007fdcd91d6b8e  push r10
00007fdcd91d6b90  push r11
00007fdcd91d6b92  sub rsp, 0xF0
00007fdcd91d6b99  vmovaps [rsp], xmm0
00007fdcd91d6b9e  vmovaps [rsp+0x10], xmm1
00007fdcd91d6ba4  vmovaps [rsp+0x20], xmm2
00007fdcd91d6baa  vmovaps [rsp+0x30], xmm3
00007fdcd91d6bb0  vmovaps [rsp+0x40], xmm4
00007fdcd91d6bb6  vmovaps [rsp+0x50], xmm5
00007fdcd91d6bbc  vmovaps [rsp+0x60], xmm6
00007fdcd91d6bc2  vmovaps [rsp+0x70], xmm7
00007fdcd91d6bc8  vmovaps [rsp+0x80], xmm8
00007fdcd91d6bd1  vmovaps [rsp+0x90], xmm9
00007fdcd91d6bda  vmovaps [rsp+0xA0], xmm11
00007fdcd91d6be3  vmovaps [rsp+0xB0], xmm12
00007fdcd91d6bec  vmovaps [rsp+0xC0], xmm13
00007fdcd91d6bf5  vmovaps [rsp+0xD0], xmm14
00007fdcd91d6bfe  vmovaps [rsp+0xE0], xmm15
00007fdcd91d6c07  sub rsp, 0x30
00007fdcd91d6c0b  movaps [rsp], xmm10
00007fdcd91d6c10  movaps [rsp+0x10], xmm12
00007fdcd91d6c16  movaps [rsp+0x20], xmm11
00007fdcd91d6c1c  lea rdi, [rsp]
00007fdcd91d6c20  mov esi, 0x00
00007fdcd91d6c25  mov rax, 0x5B56EFBF3530
00007fdcd91d6c2f  call rax
00007fdcd91d6c31  movaps xmm10, [rsp]
00007fdcd91d6c36  add rsp, 0x30
00007fdcd91d6c3a  vmovaps xmm0, [rsp]
00007fdcd91d6c3f  vmovaps xmm1, [rsp+0x10]
00007fdcd91d6c45  vmovaps xmm2, [rsp+0x20]
00007fdcd91d6c4b  vmovaps xmm3, [rsp+0x30]
00007fdcd91d6c51  vmovaps xmm4, [rsp+0x40]
00007fdcd91d6c57  vmovaps xmm5, [rsp+0x50]
00007fdcd91d6c5d  vmovaps xmm6, [rsp+0x60]
00007fdcd91d6c63  vmovaps xmm7, [rsp+0x70]
00007fdcd91d6c69  vmovaps xmm8, [rsp+0x80]
00007fdcd91d6c72  vmovaps xmm9, [rsp+0x90]
00007fdcd91d6c7b  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d6c84  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d6c8d  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d6c96  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d6c9f  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d6ca8  add rsp, 0xF0
00007fdcd91d6caf  pop r11
00007fdcd91d6cb1  pop r10
00007fdcd91d6cb3  pop r9
00007fdcd91d6cb5  pop r8
00007fdcd91d6cb7  pop rsi
00007fdcd91d6cb8  pop rdi
00007fdcd91d6cb9  pop rdx
00007fdcd91d6cba  pop rcx
00007fdcd91d6cbb  pop rax
00007fdcd91d6cbc  add rsp, 0x08
00007fdcd91d6cc0  jmp 0x00007FDCD91D5A06
00007fdcd91d6cc5  sub rsp, 0x08
00007fdcd91d6cc9  push rax
00007fdcd91d6cca  push rcx
00007fdcd91d6ccb  push rdx
00007fdcd91d6ccc  push rdi
00007fdcd91d6ccd  push rsi
00007fdcd91d6cce  push r8
00007fdcd91d6cd0  push r9
00007fdcd91d6cd2  push r10
00007fdcd91d6cd4  push r11
00007fdcd91d6cd6  sub rsp, 0xF0
00007fdcd91d6cdd  vmovaps [rsp], xmm0
00007fdcd91d6ce2  vmovaps [rsp+0x10], xmm1
00007fdcd91d6ce8  vmovaps [rsp+0x20], xmm2
00007fdcd91d6cee  vmovaps [rsp+0x30], xmm3
00007fdcd91d6cf4  vmovaps [rsp+0x40], xmm4
00007fdcd91d6cfa  vmovaps [rsp+0x50], xmm5
00007fdcd91d6d00  vmovaps [rsp+0x60], xmm7
00007fdcd91d6d06  vmovaps [rsp+0x70], xmm8
00007fdcd91d6d0c  vmovaps [rsp+0x80], xmm9
00007fdcd91d6d15  vmovaps [rsp+0x90], xmm10
00007fdcd91d6d1e  vmovaps [rsp+0xA0], xmm11
00007fdcd91d6d27  vmovaps [rsp+0xB0], xmm12
00007fdcd91d6d30  vmovaps [rsp+0xC0], xmm13
00007fdcd91d6d39  vmovaps [rsp+0xD0], xmm14
00007fdcd91d6d42  vmovaps [rsp+0xE0], xmm15
00007fdcd91d6d4b  sub rsp, 0x30
00007fdcd91d6d4f  movaps [rsp], xmm6
00007fdcd91d6d53  movaps [rsp+0x10], xmm12
00007fdcd91d6d59  movaps [rsp+0x20], xmm11
00007fdcd91d6d5f  lea rdi, [rsp]
00007fdcd91d6d63  mov esi, 0x00
00007fdcd91d6d68  mov rax, 0x5B56EFBF3530
00007fdcd91d6d72  call rax
00007fdcd91d6d74  movaps xmm6, [rsp]
00007fdcd91d6d78  add rsp, 0x30
00007fdcd91d6d7c  vmovaps xmm0, [rsp]
00007fdcd91d6d81  vmovaps xmm1, [rsp+0x10]
00007fdcd91d6d87  vmovaps xmm2, [rsp+0x20]
00007fdcd91d6d8d  vmovaps xmm3, [rsp+0x30]
00007fdcd91d6d93  vmovaps xmm4, [rsp+0x40]
00007fdcd91d6d99  vmovaps xmm5, [rsp+0x50]
00007fdcd91d6d9f  vmovaps xmm7, [rsp+0x60]
00007fdcd91d6da5  vmovaps xmm8, [rsp+0x70]
00007fdcd91d6dab  vmovaps xmm9, [rsp+0x80]
00007fdcd91d6db4  vmovaps xmm10, [rsp+0x90]
00007fdcd91d6dbd  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d6dc6  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d6dcf  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d6dd8  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d6de1  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d6dea  add rsp, 0xF0
00007fdcd91d6df1  pop r11
00007fdcd91d6df3  pop r10
00007fdcd91d6df5  pop r9
00007fdcd91d6df7  pop r8
00007fdcd91d6df9  pop rsi
00007fdcd91d6dfa  pop rdi
00007fdcd91d6dfb  pop rdx
00007fdcd91d6dfc  pop rcx
00007fdcd91d6dfd  pop rax
00007fdcd91d6dfe  add rsp, 0x08
00007fdcd91d6e02  jmp 0x00007FDCD91D5A27
00007fdcd91d6e07  sub rsp, 0x08
00007fdcd91d6e0b  push rax
00007fdcd91d6e0c  push rcx
00007fdcd91d6e0d  push rdx
00007fdcd91d6e0e  push rdi
00007fdcd91d6e0f  push rsi
00007fdcd91d6e10  push r8
00007fdcd91d6e12  push r9
00007fdcd91d6e14  push r10
00007fdcd91d6e16  push r11
00007fdcd91d6e18  sub rsp, 0xF0
00007fdcd91d6e1f  vmovaps [rsp], xmm0
00007fdcd91d6e24  vmovaps [rsp+0x10], xmm1
00007fdcd91d6e2a  vmovaps [rsp+0x20], xmm2
00007fdcd91d6e30  vmovaps [rsp+0x30], xmm4
00007fdcd91d6e36  vmovaps [rsp+0x40], xmm5
00007fdcd91d6e3c  vmovaps [rsp+0x50], xmm6
00007fdcd91d6e42  vmovaps [rsp+0x60], xmm7
00007fdcd91d6e48  vmovaps [rsp+0x70], xmm8
00007fdcd91d6e4e  vmovaps [rsp+0x80], xmm9
00007fdcd91d6e57  vmovaps [rsp+0x90], xmm10
00007fdcd91d6e60  vmovaps [rsp+0xA0], xmm11
00007fdcd91d6e69  vmovaps [rsp+0xB0], xmm12
00007fdcd91d6e72  vmovaps [rsp+0xC0], xmm13
00007fdcd91d6e7b  vmovaps [rsp+0xD0], xmm14
00007fdcd91d6e84  vmovaps [rsp+0xE0], xmm15
00007fdcd91d6e8d  sub rsp, 0x30
00007fdcd91d6e91  movaps [rsp], xmm3
00007fdcd91d6e95  movaps [rsp+0x10], xmm5
00007fdcd91d6e9a  movaps [rsp+0x20], xmm4
00007fdcd91d6e9f  lea rdi, [rsp]
00007fdcd91d6ea3  mov esi, 0x00
00007fdcd91d6ea8  mov rax, 0x5B56EFBF3530
00007fdcd91d6eb2  call rax
00007fdcd91d6eb4  movaps xmm3, [rsp]
00007fdcd91d6eb8  add rsp, 0x30
00007fdcd91d6ebc  vmovaps xmm0, [rsp]
00007fdcd91d6ec1  vmovaps xmm1, [rsp+0x10]
00007fdcd91d6ec7  vmovaps xmm2, [rsp+0x20]
00007fdcd91d6ecd  vmovaps xmm4, [rsp+0x30]
00007fdcd91d6ed3  vmovaps xmm5, [rsp+0x40]
00007fdcd91d6ed9  vmovaps xmm6, [rsp+0x50]
00007fdcd91d6edf  vmovaps xmm7, [rsp+0x60]
00007fdcd91d6ee5  vmovaps xmm8, [rsp+0x70]
00007fdcd91d6eeb  vmovaps xmm9, [rsp+0x80]
00007fdcd91d6ef4  vmovaps xmm10, [rsp+0x90]
00007fdcd91d6efd  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d6f06  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d6f0f  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d6f18  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d6f21  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d6f2a  add rsp, 0xF0
00007fdcd91d6f31  pop r11
00007fdcd91d6f33  pop r10
00007fdcd91d6f35  pop r9
00007fdcd91d6f37  pop r8
00007fdcd91d6f39  pop rsi
00007fdcd91d6f3a  pop rdi
00007fdcd91d6f3b  pop rdx
00007fdcd91d6f3c  pop rcx
00007fdcd91d6f3d  pop rax
00007fdcd91d6f3e  add rsp, 0x08
00007fdcd91d6f42  jmp 0x00007FDCD91D5A88
00007fdcd91d6f47  sub rsp, 0x08
00007fdcd91d6f4b  push rax
00007fdcd91d6f4c  push rcx
00007fdcd91d6f4d  push rdx
00007fdcd91d6f4e  push rdi
00007fdcd91d6f4f  push rsi
00007fdcd91d6f50  push r8
00007fdcd91d6f52  push r9
00007fdcd91d6f54  push r10
00007fdcd91d6f56  push r11
00007fdcd91d6f58  sub rsp, 0xF0
00007fdcd91d6f5f  vmovaps [rsp], xmm0
00007fdcd91d6f64  vmovaps [rsp+0x10], xmm1
00007fdcd91d6f6a  vmovaps [rsp+0x20], xmm2
00007fdcd91d6f70  vmovaps [rsp+0x30], xmm3
00007fdcd91d6f76  vmovaps [rsp+0x40], xmm4
00007fdcd91d6f7c  vmovaps [rsp+0x50], xmm6
00007fdcd91d6f82  vmovaps [rsp+0x60], xmm7
00007fdcd91d6f88  vmovaps [rsp+0x70], xmm8
00007fdcd91d6f8e  vmovaps [rsp+0x80], xmm9
00007fdcd91d6f97  vmovaps [rsp+0x90], xmm10
00007fdcd91d6fa0  vmovaps [rsp+0xA0], xmm11
00007fdcd91d6fa9  vmovaps [rsp+0xB0], xmm12
00007fdcd91d6fb2  vmovaps [rsp+0xC0], xmm13
00007fdcd91d6fbb  vmovaps [rsp+0xD0], xmm14
00007fdcd91d6fc4  vmovaps [rsp+0xE0], xmm15
00007fdcd91d6fcd  sub rsp, 0x30
00007fdcd91d6fd1  movaps [rsp], xmm5
00007fdcd91d6fd5  movaps [rsp+0x10], xmm8
00007fdcd91d6fdb  movaps [rsp+0x20], xmm15
00007fdcd91d6fe1  lea rdi, [rsp]
00007fdcd91d6fe5  mov esi, 0x00
00007fdcd91d6fea  mov rax, 0x5B56EFBF3530
00007fdcd91d6ff4  call rax
00007fdcd91d6ff6  movaps xmm5, [rsp]
00007fdcd91d6ffa  add rsp, 0x30
00007fdcd91d6ffe  vmovaps xmm0, [rsp]
00007fdcd91d7003  vmovaps xmm1, [rsp+0x10]
00007fdcd91d7009  vmovaps xmm2, [rsp+0x20]
00007fdcd91d700f  vmovaps xmm3, [rsp+0x30]
00007fdcd91d7015  vmovaps xmm4, [rsp+0x40]
00007fdcd91d701b  vmovaps xmm6, [rsp+0x50]
00007fdcd91d7021  vmovaps xmm7, [rsp+0x60]
00007fdcd91d7027  vmovaps xmm8, [rsp+0x70]
00007fdcd91d702d  vmovaps xmm9, [rsp+0x80]
00007fdcd91d7036  vmovaps xmm10, [rsp+0x90]
00007fdcd91d703f  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d7048  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d7051  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d705a  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d7063  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d706c  add rsp, 0xF0
00007fdcd91d7073  pop r11
00007fdcd91d7075  pop r10
00007fdcd91d7077  pop r9
00007fdcd91d7079  pop r8
00007fdcd91d707b  pop rsi
00007fdcd91d707c  pop rdi
00007fdcd91d707d  pop rdx
00007fdcd91d707e  pop rcx
00007fdcd91d707f  pop rax
00007fdcd91d7080  add rsp, 0x08
00007fdcd91d7084  jmp 0x00007FDCD91D5AC0
00007fdcd91d7089  sub rsp, 0x08
00007fdcd91d708d  push rax
00007fdcd91d708e  push rcx
00007fdcd91d708f  push rdx
00007fdcd91d7090  push rdi
00007fdcd91d7091  push rsi
00007fdcd91d7092  push r8
00007fdcd91d7094  push r9
00007fdcd91d7096  push r10
00007fdcd91d7098  push r11
00007fdcd91d709a  sub rsp, 0xF0
00007fdcd91d70a1  vmovaps [rsp], xmm0
00007fdcd91d70a6  vmovaps [rsp+0x10], xmm1
00007fdcd91d70ac  vmovaps [rsp+0x20], xmm2
00007fdcd91d70b2  vmovaps [rsp+0x30], xmm3
00007fdcd91d70b8  vmovaps [rsp+0x40], xmm5
00007fdcd91d70be  vmovaps [rsp+0x50], xmm6
00007fdcd91d70c4  vmovaps [rsp+0x60], xmm7
00007fdcd91d70ca  vmovaps [rsp+0x70], xmm8
00007fdcd91d70d0  vmovaps [rsp+0x80], xmm9
00007fdcd91d70d9  vmovaps [rsp+0x90], xmm10
00007fdcd91d70e2  vmovaps [rsp+0xA0], xmm11
00007fdcd91d70eb  vmovaps [rsp+0xB0], xmm12
00007fdcd91d70f4  vmovaps [rsp+0xC0], xmm13
00007fdcd91d70fd  vmovaps [rsp+0xD0], xmm14
00007fdcd91d7106  vmovaps [rsp+0xE0], xmm15
00007fdcd91d710f  sub rsp, 0x30
00007fdcd91d7113  movaps [rsp], xmm4
00007fdcd91d7117  movaps [rsp+0x10], xmm9
00007fdcd91d711d  movaps [rsp+0x20], xmm8
00007fdcd91d7123  lea rdi, [rsp]
00007fdcd91d7127  mov esi, 0x00
00007fdcd91d712c  mov rax, 0x5B56EFBF3530
00007fdcd91d7136  call rax
00007fdcd91d7138  movaps xmm4, [rsp]
00007fdcd91d713c  add rsp, 0x30
00007fdcd91d7140  vmovaps xmm0, [rsp]
00007fdcd91d7145  vmovaps xmm1, [rsp+0x10]
00007fdcd91d714b  vmovaps xmm2, [rsp+0x20]
00007fdcd91d7151  vmovaps xmm3, [rsp+0x30]
00007fdcd91d7157  vmovaps xmm5, [rsp+0x40]
00007fdcd91d715d  vmovaps xmm6, [rsp+0x50]
00007fdcd91d7163  vmovaps xmm7, [rsp+0x60]
00007fdcd91d7169  vmovaps xmm8, [rsp+0x70]
00007fdcd91d716f  vmovaps xmm9, [rsp+0x80]
00007fdcd91d7178  vmovaps xmm10, [rsp+0x90]
00007fdcd91d7181  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d718a  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d7193  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d719c  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d71a5  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d71ae  add rsp, 0xF0
00007fdcd91d71b5  pop r11
00007fdcd91d71b7  pop r10
00007fdcd91d71b9  pop r9
00007fdcd91d71bb  pop r8
00007fdcd91d71bd  pop rsi
00007fdcd91d71be  pop rdi
00007fdcd91d71bf  pop rdx
00007fdcd91d71c0  pop rcx
00007fdcd91d71c1  pop rax
00007fdcd91d71c2  add rsp, 0x08
00007fdcd91d71c6  jmp 0x00007FDCD91D5AE1
00007fdcd91d71cb  sub rsp, 0x08
00007fdcd91d71cf  push rax
00007fdcd91d71d0  push rcx
00007fdcd91d71d1  push rdx
00007fdcd91d71d2  push rdi
00007fdcd91d71d3  push rsi
00007fdcd91d71d4  push r8
00007fdcd91d71d6  push r9
00007fdcd91d71d8  push r10
00007fdcd91d71da  push r11
00007fdcd91d71dc  sub rsp, 0xF0
00007fdcd91d71e3  vmovaps [rsp], xmm0
00007fdcd91d71e8  vmovaps [rsp+0x10], xmm1
00007fdcd91d71ee  vmovaps [rsp+0x20], xmm2
00007fdcd91d71f4  vmovaps [rsp+0x30], xmm3
00007fdcd91d71fa  vmovaps [rsp+0x40], xmm4
00007fdcd91d7200  vmovaps [rsp+0x50], xmm5
00007fdcd91d7206  vmovaps [rsp+0x60], xmm6
00007fdcd91d720c  vmovaps [rsp+0x70], xmm7
00007fdcd91d7212  vmovaps [rsp+0x80], xmm8
00007fdcd91d721b  vmovaps [rsp+0x90], xmm10
00007fdcd91d7224  vmovaps [rsp+0xA0], xmm11
00007fdcd91d722d  vmovaps [rsp+0xB0], xmm12
00007fdcd91d7236  vmovaps [rsp+0xC0], xmm13
00007fdcd91d723f  vmovaps [rsp+0xD0], xmm14
00007fdcd91d7248  vmovaps [rsp+0xE0], xmm15
00007fdcd91d7251  sub rsp, 0x30
00007fdcd91d7255  movaps [rsp], xmm9
00007fdcd91d725a  movaps [rsp+0x10], xmm10
00007fdcd91d7260  movaps [rsp+0x20], xmm8
00007fdcd91d7266  lea rdi, [rsp]
00007fdcd91d726a  mov esi, 0x00
00007fdcd91d726f  mov rax, 0x5B56EFBF3530
00007fdcd91d7279  call rax
00007fdcd91d727b  movaps xmm9, [rsp]
00007fdcd91d7280  add rsp, 0x30
00007fdcd91d7284  vmovaps xmm0, [rsp]
00007fdcd91d7289  vmovaps xmm1, [rsp+0x10]
00007fdcd91d728f  vmovaps xmm2, [rsp+0x20]
00007fdcd91d7295  vmovaps xmm3, [rsp+0x30]
00007fdcd91d729b  vmovaps xmm4, [rsp+0x40]
00007fdcd91d72a1  vmovaps xmm5, [rsp+0x50]
00007fdcd91d72a7  vmovaps xmm6, [rsp+0x60]
00007fdcd91d72ad  vmovaps xmm7, [rsp+0x70]
00007fdcd91d72b3  vmovaps xmm8, [rsp+0x80]
00007fdcd91d72bc  vmovaps xmm10, [rsp+0x90]
00007fdcd91d72c5  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d72ce  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d72d7  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d72e0  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d72e9  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d72f2  add rsp, 0xF0
00007fdcd91d72f9  pop r11
00007fdcd91d72fb  pop r10
00007fdcd91d72fd  pop r9
00007fdcd91d72ff  pop r8
00007fdcd91d7301  pop rsi
00007fdcd91d7302  pop rdi
00007fdcd91d7303  pop rdx
00007fdcd91d7304  pop rcx
00007fdcd91d7305  pop rax
00007fdcd91d7306  add rsp, 0x08
00007fdcd91d730a  jmp 0x00007FDCD91D5AFB
00007fdcd91d730f  call 0x00007FDCD90D64F0
00007fdcd91d7314  jmp 0x00007FDCD91D5C15
00007fdcd91d7319  call 0x00007FDCD90D64F0
00007fdcd91d731e  jmp 0x00007FDCD91D5C2B
00007fdcd91d7323  sub rsp, 0x08
00007fdcd91d7327  push rax
00007fdcd91d7328  push rcx
00007fdcd91d7329  push rdx
00007fdcd91d732a  push rdi
00007fdcd91d732b  push rsi
00007fdcd91d732c  push r8
00007fdcd91d732e  push r9
00007fdcd91d7330  push r10
00007fdcd91d7332  push r11
00007fdcd91d7334  sub rsp, 0xF0
00007fdcd91d733b  vmovaps [rsp], xmm0
00007fdcd91d7340  vmovaps [rsp+0x10], xmm2
00007fdcd91d7346  vmovaps [rsp+0x20], xmm3
00007fdcd91d734c  vmovaps [rsp+0x30], xmm4
00007fdcd91d7352  vmovaps [rsp+0x40], xmm5
00007fdcd91d7358  vmovaps [rsp+0x50], xmm6
00007fdcd91d735e  vmovaps [rsp+0x60], xmm7
00007fdcd91d7364  vmovaps [rsp+0x70], xmm8
00007fdcd91d736a  vmovaps [rsp+0x80], xmm9
00007fdcd91d7373  vmovaps [rsp+0x90], xmm10
00007fdcd91d737c  vmovaps [rsp+0xA0], xmm11
00007fdcd91d7385  vmovaps [rsp+0xB0], xmm12
00007fdcd91d738e  vmovaps [rsp+0xC0], xmm13
00007fdcd91d7397  vmovaps [rsp+0xD0], xmm14
00007fdcd91d73a0  vmovaps [rsp+0xE0], xmm15
00007fdcd91d73a9  sub rsp, 0x30
00007fdcd91d73ad  movaps [rsp], xmm1
00007fdcd91d73b1  movaps [rsp+0x10], xmm6
00007fdcd91d73b6  movaps [rsp+0x20], xmm15
00007fdcd91d73bc  lea rdi, [rsp]
00007fdcd91d73c0  mov esi, 0x00
00007fdcd91d73c5  mov rax, 0x5B56EFBF3530
00007fdcd91d73cf  call rax
00007fdcd91d73d1  movaps xmm1, [rsp]
00007fdcd91d73d5  add rsp, 0x30
00007fdcd91d73d9  vmovaps xmm0, [rsp]
00007fdcd91d73de  vmovaps xmm2, [rsp+0x10]
00007fdcd91d73e4  vmovaps xmm3, [rsp+0x20]
00007fdcd91d73ea  vmovaps xmm4, [rsp+0x30]
00007fdcd91d73f0  vmovaps xmm5, [rsp+0x40]
00007fdcd91d73f6  vmovaps xmm6, [rsp+0x50]
00007fdcd91d73fc  vmovaps xmm7, [rsp+0x60]
00007fdcd91d7402  vmovaps xmm8, [rsp+0x70]
00007fdcd91d7408  vmovaps xmm9, [rsp+0x80]
00007fdcd91d7411  vmovaps xmm10, [rsp+0x90]
00007fdcd91d741a  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d7423  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d742c  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d7435  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d743e  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d7447  add rsp, 0xF0
00007fdcd91d744e  pop r11
00007fdcd91d7450  pop r10
00007fdcd91d7452  pop r9
00007fdcd91d7454  pop r8
00007fdcd91d7456  pop rsi
00007fdcd91d7457  pop rdi
00007fdcd91d7458  pop rdx
00007fdcd91d7459  pop rcx
00007fdcd91d745a  pop rax
00007fdcd91d745b  add rsp, 0x08
00007fdcd91d745f  jmp 0x00007FDCD91D5C68
00007fdcd91d7464  call 0x00007FDCD90E5820
00007fdcd91d7469  jmp 0x00007FDCD91D5C75
00007fdcd91d746e  sub rsp, 0x08
00007fdcd91d7472  push rax
00007fdcd91d7473  push rcx
00007fdcd91d7474  push rdx
00007fdcd91d7475  push rdi
00007fdcd91d7476  push rsi
00007fdcd91d7477  push r8
00007fdcd91d7479  push r9
00007fdcd91d747b  push r10
00007fdcd91d747d  push r11
00007fdcd91d747f  sub rsp, 0xF0
00007fdcd91d7486  vmovaps [rsp], xmm0
00007fdcd91d748b  vmovaps [rsp+0x10], xmm1
00007fdcd91d7491  vmovaps [rsp+0x20], xmm2
00007fdcd91d7497  vmovaps [rsp+0x30], xmm3
00007fdcd91d749d  vmovaps [rsp+0x40], xmm4
00007fdcd91d74a3  vmovaps [rsp+0x50], xmm5
00007fdcd91d74a9  vmovaps [rsp+0x60], xmm6
00007fdcd91d74af  vmovaps [rsp+0x70], xmm7
00007fdcd91d74b5  vmovaps [rsp+0x80], xmm8
00007fdcd91d74be  vmovaps [rsp+0x90], xmm9
00007fdcd91d74c7  vmovaps [rsp+0xA0], xmm10
00007fdcd91d74d0  vmovaps [rsp+0xB0], xmm11
00007fdcd91d74d9  vmovaps [rsp+0xC0], xmm12
00007fdcd91d74e2  vmovaps [rsp+0xD0], xmm13
00007fdcd91d74eb  vmovaps [rsp+0xE0], xmm15
00007fdcd91d74f4  sub rsp, 0x30
00007fdcd91d74f8  movaps [rsp], xmm14
00007fdcd91d74fd  movaps [rsp+0x10], xmm4
00007fdcd91d7502  movaps [rsp+0x20], xmm3
00007fdcd91d7507  lea rdi, [rsp]
00007fdcd91d750b  mov esi, 0x00
00007fdcd91d7510  mov rax, 0x5B56EFBF3530
00007fdcd91d751a  call rax
00007fdcd91d751c  movaps xmm14, [rsp]
00007fdcd91d7521  add rsp, 0x30
00007fdcd91d7525  vmovaps xmm0, [rsp]
00007fdcd91d752a  vmovaps xmm1, [rsp+0x10]
00007fdcd91d7530  vmovaps xmm2, [rsp+0x20]
00007fdcd91d7536  vmovaps xmm3, [rsp+0x30]
00007fdcd91d753c  vmovaps xmm4, [rsp+0x40]
00007fdcd91d7542  vmovaps xmm5, [rsp+0x50]
00007fdcd91d7548  vmovaps xmm6, [rsp+0x60]
00007fdcd91d754e  vmovaps xmm7, [rsp+0x70]
00007fdcd91d7554  vmovaps xmm8, [rsp+0x80]
00007fdcd91d755d  vmovaps xmm9, [rsp+0x90]
00007fdcd91d7566  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d756f  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d7578  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d7581  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d758a  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d7593  add rsp, 0xF0
00007fdcd91d759a  pop r11
00007fdcd91d759c  pop r10
00007fdcd91d759e  pop r9
00007fdcd91d75a0  pop r8
00007fdcd91d75a2  pop rsi
00007fdcd91d75a3  pop rdi
00007fdcd91d75a4  pop rdx
00007fdcd91d75a5  pop rcx
00007fdcd91d75a6  pop rax
00007fdcd91d75a7  add rsp, 0x08
00007fdcd91d75ab  jmp 0x00007FDCD91D5C8F
00007fdcd91d75b0  sub rsp, 0x08
00007fdcd91d75b4  push rax
00007fdcd91d75b5  push rcx
00007fdcd91d75b6  push rdx
00007fdcd91d75b7  push rdi
00007fdcd91d75b8  push rsi
00007fdcd91d75b9  push r8
00007fdcd91d75bb  push r9
00007fdcd91d75bd  push r10
00007fdcd91d75bf  push r11
00007fdcd91d75c1  sub rsp, 0xF0
00007fdcd91d75c8  vmovaps [rsp], xmm0
00007fdcd91d75cd  vmovaps [rsp+0x10], xmm1
00007fdcd91d75d3  vmovaps [rsp+0x20], xmm2
00007fdcd91d75d9  vmovaps [rsp+0x30], xmm3
00007fdcd91d75df  vmovaps [rsp+0x40], xmm4
00007fdcd91d75e5  vmovaps [rsp+0x50], xmm5
00007fdcd91d75eb  vmovaps [rsp+0x60], xmm7
00007fdcd91d75f1  vmovaps [rsp+0x70], xmm8
00007fdcd91d75f7  vmovaps [rsp+0x80], xmm9
00007fdcd91d7600  vmovaps [rsp+0x90], xmm10
00007fdcd91d7609  vmovaps [rsp+0xA0], xmm11
00007fdcd91d7612  vmovaps [rsp+0xB0], xmm12
00007fdcd91d761b  vmovaps [rsp+0xC0], xmm13
00007fdcd91d7624  vmovaps [rsp+0xD0], xmm14
00007fdcd91d762d  vmovaps [rsp+0xE0], xmm15
00007fdcd91d7636  sub rsp, 0x30
00007fdcd91d763a  movaps [rsp], xmm6
00007fdcd91d763e  movaps [rsp+0x10], xmm9
00007fdcd91d7644  movaps [rsp+0x20], xmm7
00007fdcd91d7649  lea rdi, [rsp]
00007fdcd91d764d  mov esi, 0x00
00007fdcd91d7652  mov rax, 0x5B56EFBF3530
00007fdcd91d765c  call rax
00007fdcd91d765e  movaps xmm6, [rsp]
00007fdcd91d7662  add rsp, 0x30
00007fdcd91d7666  vmovaps xmm0, [rsp]
00007fdcd91d766b  vmovaps xmm1, [rsp+0x10]
00007fdcd91d7671  vmovaps xmm2, [rsp+0x20]
00007fdcd91d7677  vmovaps xmm3, [rsp+0x30]
00007fdcd91d767d  vmovaps xmm4, [rsp+0x40]
00007fdcd91d7683  vmovaps xmm5, [rsp+0x50]
00007fdcd91d7689  vmovaps xmm7, [rsp+0x60]
00007fdcd91d768f  vmovaps xmm8, [rsp+0x70]
00007fdcd91d7695  vmovaps xmm9, [rsp+0x80]
00007fdcd91d769e  vmovaps xmm10, [rsp+0x90]
00007fdcd91d76a7  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d76b0  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d76b9  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d76c2  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d76cb  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d76d4  add rsp, 0xF0
00007fdcd91d76db  pop r11
00007fdcd91d76dd  pop r10
00007fdcd91d76df  pop r9
00007fdcd91d76e1  pop r8
00007fdcd91d76e3  pop rsi
00007fdcd91d76e4  pop rdi
00007fdcd91d76e5  pop rdx
00007fdcd91d76e6  pop rcx
00007fdcd91d76e7  pop rax
00007fdcd91d76e8  add rsp, 0x08
00007fdcd91d76ec  jmp 0x00007FDCD91D5CA7
00007fdcd91d76f1  sub rsp, 0x08
00007fdcd91d76f5  push rax
00007fdcd91d76f6  push rcx
00007fdcd91d76f7  push rdx
00007fdcd91d76f8  push rdi
00007fdcd91d76f9  push rsi
00007fdcd91d76fa  push r8
00007fdcd91d76fc  push r9
00007fdcd91d76fe  push r10
00007fdcd91d7700  push r11
00007fdcd91d7702  sub rsp, 0xF0
00007fdcd91d7709  vmovaps [rsp], xmm0
00007fdcd91d770e  vmovaps [rsp+0x10], xmm1
00007fdcd91d7714  vmovaps [rsp+0x20], xmm2
00007fdcd91d771a  vmovaps [rsp+0x30], xmm3
00007fdcd91d7720  vmovaps [rsp+0x40], xmm4
00007fdcd91d7726  vmovaps [rsp+0x50], xmm5
00007fdcd91d772c  vmovaps [rsp+0x60], xmm6
00007fdcd91d7732  vmovaps [rsp+0x70], xmm8
00007fdcd91d7738  vmovaps [rsp+0x80], xmm9
00007fdcd91d7741  vmovaps [rsp+0x90], xmm10
00007fdcd91d774a  vmovaps [rsp+0xA0], xmm11
00007fdcd91d7753  vmovaps [rsp+0xB0], xmm12
00007fdcd91d775c  vmovaps [rsp+0xC0], xmm13
00007fdcd91d7765  vmovaps [rsp+0xD0], xmm14
00007fdcd91d776e  vmovaps [rsp+0xE0], xmm15
00007fdcd91d7777  sub rsp, 0x30
00007fdcd91d777b  movaps [rsp], xmm7
00007fdcd91d777f  movaps [rsp+0x10], xmm4
00007fdcd91d7784  movaps [rsp+0x20], xmm9
00007fdcd91d778a  lea rdi, [rsp]
00007fdcd91d778e  mov esi, 0x00
00007fdcd91d7793  mov rax, 0x5B56EFBF3530
00007fdcd91d779d  call rax
00007fdcd91d779f  movaps xmm7, [rsp]
00007fdcd91d77a3  add rsp, 0x30
00007fdcd91d77a7  vmovaps xmm0, [rsp]
00007fdcd91d77ac  vmovaps xmm1, [rsp+0x10]
00007fdcd91d77b2  vmovaps xmm2, [rsp+0x20]
00007fdcd91d77b8  vmovaps xmm3, [rsp+0x30]
00007fdcd91d77be  vmovaps xmm4, [rsp+0x40]
00007fdcd91d77c4  vmovaps xmm5, [rsp+0x50]
00007fdcd91d77ca  vmovaps xmm6, [rsp+0x60]
00007fdcd91d77d0  vmovaps xmm8, [rsp+0x70]
00007fdcd91d77d6  vmovaps xmm9, [rsp+0x80]
00007fdcd91d77df  vmovaps xmm10, [rsp+0x90]
00007fdcd91d77e8  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d77f1  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d77fa  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d7803  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d780c  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d7815  add rsp, 0xF0
00007fdcd91d781c  pop r11
00007fdcd91d781e  pop r10
00007fdcd91d7820  pop r9
00007fdcd91d7822  pop r8
00007fdcd91d7824  pop rsi
00007fdcd91d7825  pop rdi
00007fdcd91d7826  pop rdx
00007fdcd91d7827  pop rcx
00007fdcd91d7828  pop rax
00007fdcd91d7829  add rsp, 0x08
00007fdcd91d782d  jmp 0x00007FDCD91D5CD4
00007fdcd91d7832  sub rsp, 0x08
00007fdcd91d7836  push rax
00007fdcd91d7837  push rcx
00007fdcd91d7838  push rdx
00007fdcd91d7839  push rdi
00007fdcd91d783a  push rsi
00007fdcd91d783b  push r8
00007fdcd91d783d  push r9
00007fdcd91d783f  push r10
00007fdcd91d7841  push r11
00007fdcd91d7843  sub rsp, 0xF0
00007fdcd91d784a  vmovaps [rsp], xmm0
00007fdcd91d784f  vmovaps [rsp+0x10], xmm1
00007fdcd91d7855  vmovaps [rsp+0x20], xmm2
00007fdcd91d785b  vmovaps [rsp+0x30], xmm3
00007fdcd91d7861  vmovaps [rsp+0x40], xmm5
00007fdcd91d7867  vmovaps [rsp+0x50], xmm6
00007fdcd91d786d  vmovaps [rsp+0x60], xmm7
00007fdcd91d7873  vmovaps [rsp+0x70], xmm8
00007fdcd91d7879  vmovaps [rsp+0x80], xmm9
00007fdcd91d7882  vmovaps [rsp+0x90], xmm10
00007fdcd91d788b  vmovaps [rsp+0xA0], xmm11
00007fdcd91d7894  vmovaps [rsp+0xB0], xmm12
00007fdcd91d789d  vmovaps [rsp+0xC0], xmm13
00007fdcd91d78a6  vmovaps [rsp+0xD0], xmm14
00007fdcd91d78af  vmovaps [rsp+0xE0], xmm15
00007fdcd91d78b8  sub rsp, 0x30
00007fdcd91d78bc  movaps [rsp], xmm4
00007fdcd91d78c0  movaps [rsp+0x10], xmm15
00007fdcd91d78c6  movaps [rsp+0x20], xmm9
00007fdcd91d78cc  lea rdi, [rsp]
00007fdcd91d78d0  mov esi, 0x00
00007fdcd91d78d5  mov rax, 0x5B56EFBF3530
00007fdcd91d78df  call rax
00007fdcd91d78e1  movaps xmm4, [rsp]
00007fdcd91d78e5  add rsp, 0x30
00007fdcd91d78e9  vmovaps xmm0, [rsp]
00007fdcd91d78ee  vmovaps xmm1, [rsp+0x10]
00007fdcd91d78f4  vmovaps xmm2, [rsp+0x20]
00007fdcd91d78fa  vmovaps xmm3, [rsp+0x30]
00007fdcd91d7900  vmovaps xmm5, [rsp+0x40]
00007fdcd91d7906  vmovaps xmm6, [rsp+0x50]
00007fdcd91d790c  vmovaps xmm7, [rsp+0x60]
00007fdcd91d7912  vmovaps xmm8, [rsp+0x70]
00007fdcd91d7918  vmovaps xmm9, [rsp+0x80]
00007fdcd91d7921  vmovaps xmm10, [rsp+0x90]
00007fdcd91d792a  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d7933  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d793c  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d7945  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d794e  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d7957  add rsp, 0xF0
00007fdcd91d795e  pop r11
00007fdcd91d7960  pop r10
00007fdcd91d7962  pop r9
00007fdcd91d7964  pop r8
00007fdcd91d7966  pop rsi
00007fdcd91d7967  pop rdi
00007fdcd91d7968  pop rdx
00007fdcd91d7969  pop rcx
00007fdcd91d796a  pop rax
00007fdcd91d796b  add rsp, 0x08
00007fdcd91d796f  jmp 0x00007FDCD91D5CF9
00007fdcd91d7974  call 0x00007FDCD90E5820
00007fdcd91d7979  jmp 0x00007FDCD91D5D06
00007fdcd91d797e  sub rsp, 0x08
00007fdcd91d7982  push rax
00007fdcd91d7983  push rcx
00007fdcd91d7984  push rdx
00007fdcd91d7985  push rdi
00007fdcd91d7986  push rsi
00007fdcd91d7987  push r8
00007fdcd91d7989  push r9
00007fdcd91d798b  push r10
00007fdcd91d798d  push r11
00007fdcd91d798f  sub rsp, 0xF0
00007fdcd91d7996  vmovaps [rsp], xmm0
00007fdcd91d799b  vmovaps [rsp+0x10], xmm1
00007fdcd91d79a1  vmovaps [rsp+0x20], xmm2
00007fdcd91d79a7  vmovaps [rsp+0x30], xmm4
00007fdcd91d79ad  vmovaps [rsp+0x40], xmm5
00007fdcd91d79b3  vmovaps [rsp+0x50], xmm6
00007fdcd91d79b9  vmovaps [rsp+0x60], xmm7
00007fdcd91d79bf  vmovaps [rsp+0x70], xmm8
00007fdcd91d79c5  vmovaps [rsp+0x80], xmm9
00007fdcd91d79ce  vmovaps [rsp+0x90], xmm10
00007fdcd91d79d7  vmovaps [rsp+0xA0], xmm11
00007fdcd91d79e0  vmovaps [rsp+0xB0], xmm12
00007fdcd91d79e9  vmovaps [rsp+0xC0], xmm13
00007fdcd91d79f2  vmovaps [rsp+0xD0], xmm14
00007fdcd91d79fb  vmovaps [rsp+0xE0], xmm15
00007fdcd91d7a04  sub rsp, 0x30
00007fdcd91d7a08  movaps [rsp], xmm3
00007fdcd91d7a0c  movaps [rsp+0x10], xmm1
00007fdcd91d7a11  movaps [rsp+0x20], xmm9
00007fdcd91d7a17  lea rdi, [rsp]
00007fdcd91d7a1b  mov esi, 0x00
00007fdcd91d7a20  mov rax, 0x5B56EFBF3530
00007fdcd91d7a2a  call rax
00007fdcd91d7a2c  movaps xmm3, [rsp]
00007fdcd91d7a30  add rsp, 0x30
00007fdcd91d7a34  vmovaps xmm0, [rsp]
00007fdcd91d7a39  vmovaps xmm1, [rsp+0x10]
00007fdcd91d7a3f  vmovaps xmm2, [rsp+0x20]
00007fdcd91d7a45  vmovaps xmm4, [rsp+0x30]
00007fdcd91d7a4b  vmovaps xmm5, [rsp+0x40]
00007fdcd91d7a51  vmovaps xmm6, [rsp+0x50]
00007fdcd91d7a57  vmovaps xmm7, [rsp+0x60]
00007fdcd91d7a5d  vmovaps xmm8, [rsp+0x70]
00007fdcd91d7a63  vmovaps xmm9, [rsp+0x80]
00007fdcd91d7a6c  vmovaps xmm10, [rsp+0x90]
00007fdcd91d7a75  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d7a7e  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d7a87  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d7a90  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d7a99  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d7aa2  add rsp, 0xF0
00007fdcd91d7aa9  pop r11
00007fdcd91d7aab  pop r10
00007fdcd91d7aad  pop r9
00007fdcd91d7aaf  pop r8
00007fdcd91d7ab1  pop rsi
00007fdcd91d7ab2  pop rdi
00007fdcd91d7ab3  pop rdx
00007fdcd91d7ab4  pop rcx
00007fdcd91d7ab5  pop rax
00007fdcd91d7ab6  add rsp, 0x08
00007fdcd91d7aba  jmp 0x00007FDCD91D5D43
00007fdcd91d7abf  sub rsp, 0x08
00007fdcd91d7ac3  push rax
00007fdcd91d7ac4  push rcx
00007fdcd91d7ac5  push rdx
00007fdcd91d7ac6  push rdi
00007fdcd91d7ac7  push rsi
00007fdcd91d7ac8  push r8
00007fdcd91d7aca  push r9
00007fdcd91d7acc  push r10
00007fdcd91d7ace  push r11
00007fdcd91d7ad0  sub rsp, 0xF0
00007fdcd91d7ad7  vmovaps [rsp], xmm0
00007fdcd91d7adc  vmovaps [rsp+0x10], xmm2
00007fdcd91d7ae2  vmovaps [rsp+0x20], xmm3
00007fdcd91d7ae8  vmovaps [rsp+0x30], xmm4
00007fdcd91d7aee  vmovaps [rsp+0x40], xmm5
00007fdcd91d7af4  vmovaps [rsp+0x50], xmm6
00007fdcd91d7afa  vmovaps [rsp+0x60], xmm7
00007fdcd91d7b00  vmovaps [rsp+0x70], xmm8
00007fdcd91d7b06  vmovaps [rsp+0x80], xmm9
00007fdcd91d7b0f  vmovaps [rsp+0x90], xmm10
00007fdcd91d7b18  vmovaps [rsp+0xA0], xmm11
00007fdcd91d7b21  vmovaps [rsp+0xB0], xmm12
00007fdcd91d7b2a  vmovaps [rsp+0xC0], xmm13
00007fdcd91d7b33  vmovaps [rsp+0xD0], xmm14
00007fdcd91d7b3c  vmovaps [rsp+0xE0], xmm15
00007fdcd91d7b45  sub rsp, 0x30
00007fdcd91d7b49  movaps [rsp], xmm1
00007fdcd91d7b4d  movaps [rsp+0x10], xmm15
00007fdcd91d7b53  movaps [rsp+0x20], xmm9
00007fdcd91d7b59  lea rdi, [rsp]
00007fdcd91d7b5d  mov esi, 0x00
00007fdcd91d7b62  mov rax, 0x5B56EFBF3530
00007fdcd91d7b6c  call rax
00007fdcd91d7b6e  movaps xmm1, [rsp]
00007fdcd91d7b72  add rsp, 0x30
00007fdcd91d7b76  vmovaps xmm0, [rsp]
00007fdcd91d7b7b  vmovaps xmm2, [rsp+0x10]
00007fdcd91d7b81  vmovaps xmm3, [rsp+0x20]
00007fdcd91d7b87  vmovaps xmm4, [rsp+0x30]
00007fdcd91d7b8d  vmovaps xmm5, [rsp+0x40]
00007fdcd91d7b93  vmovaps xmm6, [rsp+0x50]
00007fdcd91d7b99  vmovaps xmm7, [rsp+0x60]
00007fdcd91d7b9f  vmovaps xmm8, [rsp+0x70]
00007fdcd91d7ba5  vmovaps xmm9, [rsp+0x80]
00007fdcd91d7bae  vmovaps xmm10, [rsp+0x90]
00007fdcd91d7bb7  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d7bc0  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d7bc9  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d7bd2  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d7bdb  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d7be4  add rsp, 0xF0
00007fdcd91d7beb  pop r11
00007fdcd91d7bed  pop r10
00007fdcd91d7bef  pop r9
00007fdcd91d7bf1  pop r8
00007fdcd91d7bf3  pop rsi
00007fdcd91d7bf4  pop rdi
00007fdcd91d7bf5  pop rdx
00007fdcd91d7bf6  pop rcx
00007fdcd91d7bf7  pop rax
00007fdcd91d7bf8  add rsp, 0x08
00007fdcd91d7bfc  jmp 0x00007FDCD91D5DCB
00007fdcd91d7c01  call 0x00007FDCD90E5820
00007fdcd91d7c06  jmp 0x00007FDCD91D5DD8
00007fdcd91d7c0b  sub rsp, 0x08
00007fdcd91d7c0f  push rax
00007fdcd91d7c10  push rcx
00007fdcd91d7c11  push rdx
00007fdcd91d7c12  push rdi
00007fdcd91d7c13  push rsi
00007fdcd91d7c14  push r8
00007fdcd91d7c16  push r9
00007fdcd91d7c18  push r10
00007fdcd91d7c1a  push r11
00007fdcd91d7c1c  sub rsp, 0xF0
00007fdcd91d7c23  vmovaps [rsp], xmm0
00007fdcd91d7c28  vmovaps [rsp+0x10], xmm2
00007fdcd91d7c2e  vmovaps [rsp+0x20], xmm3
00007fdcd91d7c34  vmovaps [rsp+0x30], xmm4
00007fdcd91d7c3a  vmovaps [rsp+0x40], xmm5
00007fdcd91d7c40  vmovaps [rsp+0x50], xmm6
00007fdcd91d7c46  vmovaps [rsp+0x60], xmm7
00007fdcd91d7c4c  vmovaps [rsp+0x70], xmm8
00007fdcd91d7c52  vmovaps [rsp+0x80], xmm9
00007fdcd91d7c5b  vmovaps [rsp+0x90], xmm10
00007fdcd91d7c64  vmovaps [rsp+0xA0], xmm11
00007fdcd91d7c6d  vmovaps [rsp+0xB0], xmm12
00007fdcd91d7c76  vmovaps [rsp+0xC0], xmm13
00007fdcd91d7c7f  vmovaps [rsp+0xD0], xmm14
00007fdcd91d7c88  vmovaps [rsp+0xE0], xmm15
00007fdcd91d7c91  sub rsp, 0x30
00007fdcd91d7c95  movaps [rsp], xmm1
00007fdcd91d7c99  movaps [rsp+0x10], xmm5
00007fdcd91d7c9e  movaps [rsp+0x20], xmm7
00007fdcd91d7ca3  lea rdi, [rsp]
00007fdcd91d7ca7  mov esi, 0x00
00007fdcd91d7cac  mov rax, 0x5B56EFBF3530
00007fdcd91d7cb6  call rax
00007fdcd91d7cb8  movaps xmm1, [rsp]
00007fdcd91d7cbc  add rsp, 0x30
00007fdcd91d7cc0  vmovaps xmm0, [rsp]
00007fdcd91d7cc5  vmovaps xmm2, [rsp+0x10]
00007fdcd91d7ccb  vmovaps xmm3, [rsp+0x20]
00007fdcd91d7cd1  vmovaps xmm4, [rsp+0x30]
00007fdcd91d7cd7  vmovaps xmm5, [rsp+0x40]
00007fdcd91d7cdd  vmovaps xmm6, [rsp+0x50]
00007fdcd91d7ce3  vmovaps xmm7, [rsp+0x60]
00007fdcd91d7ce9  vmovaps xmm8, [rsp+0x70]
00007fdcd91d7cef  vmovaps xmm9, [rsp+0x80]
00007fdcd91d7cf8  vmovaps xmm10, [rsp+0x90]
00007fdcd91d7d01  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d7d0a  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d7d13  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d7d1c  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d7d25  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d7d2e  add rsp, 0xF0
00007fdcd91d7d35  pop r11
00007fdcd91d7d37  pop r10
00007fdcd91d7d39  pop r9
00007fdcd91d7d3b  pop r8
00007fdcd91d7d3d  pop rsi
00007fdcd91d7d3e  pop rdi
00007fdcd91d7d3f  pop rdx
00007fdcd91d7d40  pop rcx
00007fdcd91d7d41  pop rax
00007fdcd91d7d42  add rsp, 0x08
00007fdcd91d7d46  jmp 0x00007FDCD91D5E7D
00007fdcd91d7d4b  sub rsp, 0x08
00007fdcd91d7d4f  push rax
00007fdcd91d7d50  push rcx
00007fdcd91d7d51  push rdx
00007fdcd91d7d52  push rdi
00007fdcd91d7d53  push rsi
00007fdcd91d7d54  push r8
00007fdcd91d7d56  push r9
00007fdcd91d7d58  push r10
00007fdcd91d7d5a  push r11
00007fdcd91d7d5c  sub rsp, 0xF0
00007fdcd91d7d63  vmovaps [rsp], xmm0
00007fdcd91d7d68  vmovaps [rsp+0x10], xmm1
00007fdcd91d7d6e  vmovaps [rsp+0x20], xmm2
00007fdcd91d7d74  vmovaps [rsp+0x30], xmm3
00007fdcd91d7d7a  vmovaps [rsp+0x40], xmm4
00007fdcd91d7d80  vmovaps [rsp+0x50], xmm5
00007fdcd91d7d86  vmovaps [rsp+0x60], xmm6
00007fdcd91d7d8c  vmovaps [rsp+0x70], xmm8
00007fdcd91d7d92  vmovaps [rsp+0x80], xmm9
00007fdcd91d7d9b  vmovaps [rsp+0x90], xmm10
00007fdcd91d7da4  vmovaps [rsp+0xA0], xmm11
00007fdcd91d7dad  vmovaps [rsp+0xB0], xmm12
00007fdcd91d7db6  vmovaps [rsp+0xC0], xmm13
00007fdcd91d7dbf  vmovaps [rsp+0xD0], xmm14
00007fdcd91d7dc8  vmovaps [rsp+0xE0], xmm15
00007fdcd91d7dd1  sub rsp, 0x30
00007fdcd91d7dd5  movaps [rsp], xmm7
00007fdcd91d7dd9  movaps [rsp+0x10], xmm5
00007fdcd91d7dde  movaps [rsp+0x20], xmm15
00007fdcd91d7de4  lea rdi, [rsp]
00007fdcd91d7de8  mov esi, 0x00
00007fdcd91d7ded  mov rax, 0x5B56EFBF3530
00007fdcd91d7df7  call rax
00007fdcd91d7df9  movaps xmm7, [rsp]
00007fdcd91d7dfd  add rsp, 0x30
00007fdcd91d7e01  vmovaps xmm0, [rsp]
00007fdcd91d7e06  vmovaps xmm1, [rsp+0x10]
00007fdcd91d7e0c  vmovaps xmm2, [rsp+0x20]
00007fdcd91d7e12  vmovaps xmm3, [rsp+0x30]
00007fdcd91d7e18  vmovaps xmm4, [rsp+0x40]
00007fdcd91d7e1e  vmovaps xmm5, [rsp+0x50]
00007fdcd91d7e24  vmovaps xmm6, [rsp+0x60]
00007fdcd91d7e2a  vmovaps xmm8, [rsp+0x70]
00007fdcd91d7e30  vmovaps xmm9, [rsp+0x80]
00007fdcd91d7e39  vmovaps xmm10, [rsp+0x90]
00007fdcd91d7e42  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d7e4b  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d7e54  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d7e5d  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d7e66  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d7e6f  add rsp, 0xF0
00007fdcd91d7e76  pop r11
00007fdcd91d7e78  pop r10
00007fdcd91d7e7a  pop r9
00007fdcd91d7e7c  pop r8
00007fdcd91d7e7e  pop rsi
00007fdcd91d7e7f  pop rdi
00007fdcd91d7e80  pop rdx
00007fdcd91d7e81  pop rcx
00007fdcd91d7e82  pop rax
00007fdcd91d7e83  add rsp, 0x08
00007fdcd91d7e87  jmp 0x00007FDCD91D5EB3
00007fdcd91d7e8c  call 0x00007FDCD90D64F0
00007fdcd91d7e91  jmp 0x00007FDCD91D5EC0
00007fdcd91d7e96  sub rsp, 0x08
00007fdcd91d7e9a  push rax
00007fdcd91d7e9b  push rcx
00007fdcd91d7e9c  push rdx
00007fdcd91d7e9d  push rdi
00007fdcd91d7e9e  push rsi
00007fdcd91d7e9f  push r8
00007fdcd91d7ea1  push r9
00007fdcd91d7ea3  push r10
00007fdcd91d7ea5  push r11
00007fdcd91d7ea7  sub rsp, 0xF0
00007fdcd91d7eae  vmovaps [rsp], xmm0
00007fdcd91d7eb3  vmovaps [rsp+0x10], xmm1
00007fdcd91d7eb9  vmovaps [rsp+0x20], xmm2
00007fdcd91d7ebf  vmovaps [rsp+0x30], xmm3
00007fdcd91d7ec5  vmovaps [rsp+0x40], xmm4
00007fdcd91d7ecb  vmovaps [rsp+0x50], xmm5
00007fdcd91d7ed1  vmovaps [rsp+0x60], xmm6
00007fdcd91d7ed7  vmovaps [rsp+0x70], xmm7
00007fdcd91d7edd  vmovaps [rsp+0x80], xmm8
00007fdcd91d7ee6  vmovaps [rsp+0x90], xmm9
00007fdcd91d7eef  vmovaps [rsp+0xA0], xmm10
00007fdcd91d7ef8  vmovaps [rsp+0xB0], xmm11
00007fdcd91d7f01  vmovaps [rsp+0xC0], xmm12
00007fdcd91d7f0a  vmovaps [rsp+0xD0], xmm13
00007fdcd91d7f13  vmovaps [rsp+0xE0], xmm14
00007fdcd91d7f1c  sub rsp, 0x30
00007fdcd91d7f20  movaps [rsp], xmm15
00007fdcd91d7f25  movaps [rsp+0x10], xmm5
00007fdcd91d7f2a  movaps [rsp+0x20], xmm3
00007fdcd91d7f2f  lea rdi, [rsp]
00007fdcd91d7f33  mov esi, 0x00
00007fdcd91d7f38  mov rax, 0x5B56EFBF3530
00007fdcd91d7f42  call rax
00007fdcd91d7f44  movaps xmm15, [rsp]
00007fdcd91d7f49  add rsp, 0x30
00007fdcd91d7f4d  vmovaps xmm0, [rsp]
00007fdcd91d7f52  vmovaps xmm1, [rsp+0x10]
00007fdcd91d7f58  vmovaps xmm2, [rsp+0x20]
00007fdcd91d7f5e  vmovaps xmm3, [rsp+0x30]
00007fdcd91d7f64  vmovaps xmm4, [rsp+0x40]
00007fdcd91d7f6a  vmovaps xmm5, [rsp+0x50]
00007fdcd91d7f70  vmovaps xmm6, [rsp+0x60]
00007fdcd91d7f76  vmovaps xmm7, [rsp+0x70]
00007fdcd91d7f7c  vmovaps xmm8, [rsp+0x80]
00007fdcd91d7f85  vmovaps xmm9, [rsp+0x90]
00007fdcd91d7f8e  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d7f97  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d7fa0  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d7fa9  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d7fb2  vmovaps xmm14, [rsp+0xE0]
00007fdcd91d7fbb  add rsp, 0xF0
00007fdcd91d7fc2  pop r11
00007fdcd91d7fc4  pop r10
00007fdcd91d7fc6  pop r9
00007fdcd91d7fc8  pop r8
00007fdcd91d7fca  pop rsi
00007fdcd91d7fcb  pop rdi
00007fdcd91d7fcc  pop rdx
00007fdcd91d7fcd  pop rcx
00007fdcd91d7fce  pop rax
00007fdcd91d7fcf  add rsp, 0x08
00007fdcd91d7fd3  jmp 0x00007FDCD91D5EE6
00007fdcd91d7fd8  sub rsp, 0x08
00007fdcd91d7fdc  push rax
00007fdcd91d7fdd  push rcx
00007fdcd91d7fde  push rdx
00007fdcd91d7fdf  push rdi
00007fdcd91d7fe0  push rsi
00007fdcd91d7fe1  push r8
00007fdcd91d7fe3  push r9
00007fdcd91d7fe5  push r10
00007fdcd91d7fe7  push r11
00007fdcd91d7fe9  sub rsp, 0xF0
00007fdcd91d7ff0  vmovaps [rsp], xmm0
00007fdcd91d7ff5  vmovaps [rsp+0x10], xmm2
00007fdcd91d7ffb  vmovaps [rsp+0x20], xmm3
00007fdcd91d8001  vmovaps [rsp+0x30], xmm4
00007fdcd91d8007  vmovaps [rsp+0x40], xmm5
00007fdcd91d800d  vmovaps [rsp+0x50], xmm6
00007fdcd91d8013  vmovaps [rsp+0x60], xmm7
00007fdcd91d8019  vmovaps [rsp+0x70], xmm8
00007fdcd91d801f  vmovaps [rsp+0x80], xmm9
00007fdcd91d8028  vmovaps [rsp+0x90], xmm10
00007fdcd91d8031  vmovaps [rsp+0xA0], xmm11
00007fdcd91d803a  vmovaps [rsp+0xB0], xmm12
00007fdcd91d8043  vmovaps [rsp+0xC0], xmm13
00007fdcd91d804c  vmovaps [rsp+0xD0], xmm14
00007fdcd91d8055  vmovaps [rsp+0xE0], xmm15
00007fdcd91d805e  sub rsp, 0x30
00007fdcd91d8062  movaps [rsp], xmm1
00007fdcd91d8066  movaps [rsp+0x10], xmm5
00007fdcd91d806b  movaps [rsp+0x20], xmm4
00007fdcd91d8070  lea rdi, [rsp]
00007fdcd91d8074  mov esi, 0x00
00007fdcd91d8079  mov rax, 0x5B56EFBF3530
00007fdcd91d8083  call rax
00007fdcd91d8085  movaps xmm1, [rsp]
00007fdcd91d8089  add rsp, 0x30
00007fdcd91d808d  vmovaps xmm0, [rsp]
00007fdcd91d8092  vmovaps xmm2, [rsp+0x10]
00007fdcd91d8098  vmovaps xmm3, [rsp+0x20]
00007fdcd91d809e  vmovaps xmm4, [rsp+0x30]
00007fdcd91d80a4  vmovaps xmm5, [rsp+0x40]
00007fdcd91d80aa  vmovaps xmm6, [rsp+0x50]
00007fdcd91d80b0  vmovaps xmm7, [rsp+0x60]
00007fdcd91d80b6  vmovaps xmm8, [rsp+0x70]
00007fdcd91d80bc  vmovaps xmm9, [rsp+0x80]
00007fdcd91d80c5  vmovaps xmm10, [rsp+0x90]
00007fdcd91d80ce  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d80d7  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d80e0  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d80e9  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d80f2  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d80fb  add rsp, 0xF0
00007fdcd91d8102  pop r11
00007fdcd91d8104  pop r10
00007fdcd91d8106  pop r9
00007fdcd91d8108  pop r8
00007fdcd91d810a  pop rsi
00007fdcd91d810b  pop rdi
00007fdcd91d810c  pop rdx
00007fdcd91d810d  pop rcx
00007fdcd91d810e  pop rax
00007fdcd91d810f  add rsp, 0x08
00007fdcd91d8113  jmp 0x00007FDCD91D5F06
00007fdcd91d8118  sub rsp, 0x08
00007fdcd91d811c  push rax
00007fdcd91d811d  push rcx
00007fdcd91d811e  push rdx
00007fdcd91d811f  push rdi
00007fdcd91d8120  push rsi
00007fdcd91d8121  push r8
00007fdcd91d8123  push r9
00007fdcd91d8125  push r10
00007fdcd91d8127  push r11
00007fdcd91d8129  sub rsp, 0xF0
00007fdcd91d8130  vmovaps [rsp], xmm0
00007fdcd91d8135  vmovaps [rsp+0x10], xmm1
00007fdcd91d813b  vmovaps [rsp+0x20], xmm2
00007fdcd91d8141  vmovaps [rsp+0x30], xmm3
00007fdcd91d8147  vmovaps [rsp+0x40], xmm5
00007fdcd91d814d  vmovaps [rsp+0x50], xmm6
00007fdcd91d8153  vmovaps [rsp+0x60], xmm7
00007fdcd91d8159  vmovaps [rsp+0x70], xmm8
00007fdcd91d815f  vmovaps [rsp+0x80], xmm9
00007fdcd91d8168  vmovaps [rsp+0x90], xmm10
00007fdcd91d8171  vmovaps [rsp+0xA0], xmm11
00007fdcd91d817a  vmovaps [rsp+0xB0], xmm12
00007fdcd91d8183  vmovaps [rsp+0xC0], xmm13
00007fdcd91d818c  vmovaps [rsp+0xD0], xmm14
00007fdcd91d8195  vmovaps [rsp+0xE0], xmm15
00007fdcd91d819e  sub rsp, 0x30
00007fdcd91d81a2  movaps [rsp], xmm4
00007fdcd91d81a6  movaps [rsp+0x10], xmm3
00007fdcd91d81ab  movaps [rsp+0x20], xmm5
00007fdcd91d81b0  lea rdi, [rsp]
00007fdcd91d81b4  mov esi, 0x00
00007fdcd91d81b9  mov rax, 0x5B56EFBF3530
00007fdcd91d81c3  call rax
00007fdcd91d81c5  movaps xmm4, [rsp]
00007fdcd91d81c9  add rsp, 0x30
00007fdcd91d81cd  vmovaps xmm0, [rsp]
00007fdcd91d81d2  vmovaps xmm1, [rsp+0x10]
00007fdcd91d81d8  vmovaps xmm2, [rsp+0x20]
00007fdcd91d81de  vmovaps xmm3, [rsp+0x30]
00007fdcd91d81e4  vmovaps xmm5, [rsp+0x40]
00007fdcd91d81ea  vmovaps xmm6, [rsp+0x50]
00007fdcd91d81f0  vmovaps xmm7, [rsp+0x60]
00007fdcd91d81f6  vmovaps xmm8, [rsp+0x70]
00007fdcd91d81fc  vmovaps xmm9, [rsp+0x80]
00007fdcd91d8205  vmovaps xmm10, [rsp+0x90]
00007fdcd91d820e  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d8217  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d8220  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d8229  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d8232  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d823b  add rsp, 0xF0
00007fdcd91d8242  pop r11
00007fdcd91d8244  pop r10
00007fdcd91d8246  pop r9
00007fdcd91d8248  pop r8
00007fdcd91d824a  pop rsi
00007fdcd91d824b  pop rdi
00007fdcd91d824c  pop rdx
00007fdcd91d824d  pop rcx
00007fdcd91d824e  pop rax
00007fdcd91d824f  add rsp, 0x08
00007fdcd91d8253  jmp 0x00007FDCD91D5F54
00007fdcd91d8258  call 0x00007FDCD90D64F0
00007fdcd91d825d  jmp 0x00007FDCD91D5F61
00007fdcd91d8262  sub rsp, 0x08
00007fdcd91d8266  push rax
00007fdcd91d8267  push rcx
00007fdcd91d8268  push rdx
00007fdcd91d8269  push rdi
00007fdcd91d826a  push rsi
00007fdcd91d826b  push r8
00007fdcd91d826d  push r9
00007fdcd91d826f  push r10
00007fdcd91d8271  push r11
00007fdcd91d8273  sub rsp, 0xF0
00007fdcd91d827a  vmovaps [rsp], xmm0
00007fdcd91d827f  vmovaps [rsp+0x10], xmm1
00007fdcd91d8285  vmovaps [rsp+0x20], xmm2
00007fdcd91d828b  vmovaps [rsp+0x30], xmm3
00007fdcd91d8291  vmovaps [rsp+0x40], xmm4
00007fdcd91d8297  vmovaps [rsp+0x50], xmm6
00007fdcd91d829d  vmovaps [rsp+0x60], xmm7
00007fdcd91d82a3  vmovaps [rsp+0x70], xmm8
00007fdcd91d82a9  vmovaps [rsp+0x80], xmm9
00007fdcd91d82b2  vmovaps [rsp+0x90], xmm10
00007fdcd91d82bb  vmovaps [rsp+0xA0], xmm11
00007fdcd91d82c4  vmovaps [rsp+0xB0], xmm12
00007fdcd91d82cd  vmovaps [rsp+0xC0], xmm13
00007fdcd91d82d6  vmovaps [rsp+0xD0], xmm14
00007fdcd91d82df  vmovaps [rsp+0xE0], xmm15
00007fdcd91d82e8  sub rsp, 0x30
00007fdcd91d82ec  movaps [rsp], xmm5
00007fdcd91d82f0  movaps [rsp+0x10], xmm6
00007fdcd91d82f5  movaps [rsp+0x20], xmm3
00007fdcd91d82fa  lea rdi, [rsp]
00007fdcd91d82fe  mov esi, 0x00
00007fdcd91d8303  mov rax, 0x5B56EFBF3530
00007fdcd91d830d  call rax
00007fdcd91d830f  movaps xmm5, [rsp]
00007fdcd91d8313  add rsp, 0x30
00007fdcd91d8317  vmovaps xmm0, [rsp]
00007fdcd91d831c  vmovaps xmm1, [rsp+0x10]
00007fdcd91d8322  vmovaps xmm2, [rsp+0x20]
00007fdcd91d8328  vmovaps xmm3, [rsp+0x30]
00007fdcd91d832e  vmovaps xmm4, [rsp+0x40]
00007fdcd91d8334  vmovaps xmm6, [rsp+0x50]
00007fdcd91d833a  vmovaps xmm7, [rsp+0x60]
00007fdcd91d8340  vmovaps xmm8, [rsp+0x70]
00007fdcd91d8346  vmovaps xmm9, [rsp+0x80]
00007fdcd91d834f  vmovaps xmm10, [rsp+0x90]
00007fdcd91d8358  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d8361  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d836a  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d8373  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d837c  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d8385  add rsp, 0xF0
00007fdcd91d838c  pop r11
00007fdcd91d838e  pop r10
00007fdcd91d8390  pop r9
00007fdcd91d8392  pop r8
00007fdcd91d8394  pop rsi
00007fdcd91d8395  pop rdi
00007fdcd91d8396  pop rdx
00007fdcd91d8397  pop rcx
00007fdcd91d8398  pop rax
00007fdcd91d8399  add rsp, 0x08
00007fdcd91d839d  jmp 0x00007FDCD91D5F87
00007fdcd91d83a2  sub rsp, 0x08
00007fdcd91d83a6  push rax
00007fdcd91d83a7  push rcx
00007fdcd91d83a8  push rdx
00007fdcd91d83a9  push rdi
00007fdcd91d83aa  push rsi
00007fdcd91d83ab  push r8
00007fdcd91d83ad  push r9
00007fdcd91d83af  push r10
00007fdcd91d83b1  push r11
00007fdcd91d83b3  sub rsp, 0xF0
00007fdcd91d83ba  vmovaps [rsp], xmm0
00007fdcd91d83bf  vmovaps [rsp+0x10], xmm1
00007fdcd91d83c5  vmovaps [rsp+0x20], xmm2
00007fdcd91d83cb  vmovaps [rsp+0x30], xmm3
00007fdcd91d83d1  vmovaps [rsp+0x40], xmm4
00007fdcd91d83d7  vmovaps [rsp+0x50], xmm5
00007fdcd91d83dd  vmovaps [rsp+0x60], xmm7
00007fdcd91d83e3  vmovaps [rsp+0x70], xmm8
00007fdcd91d83e9  vmovaps [rsp+0x80], xmm9
00007fdcd91d83f2  vmovaps [rsp+0x90], xmm10
00007fdcd91d83fb  vmovaps [rsp+0xA0], xmm11
00007fdcd91d8404  vmovaps [rsp+0xB0], xmm12
00007fdcd91d840d  vmovaps [rsp+0xC0], xmm13
00007fdcd91d8416  vmovaps [rsp+0xD0], xmm14
00007fdcd91d841f  vmovaps [rsp+0xE0], xmm15
00007fdcd91d8428  sub rsp, 0x30
00007fdcd91d842c  movaps [rsp], xmm6
00007fdcd91d8430  movaps [rsp+0x10], xmm9
00007fdcd91d8436  movaps [rsp+0x20], xmm1
00007fdcd91d843b  lea rdi, [rsp]
00007fdcd91d843f  mov esi, 0x00
00007fdcd91d8444  mov rax, 0x5B56EFBF3530
00007fdcd91d844e  call rax
00007fdcd91d8450  movaps xmm6, [rsp]
00007fdcd91d8454  add rsp, 0x30
00007fdcd91d8458  vmovaps xmm0, [rsp]
00007fdcd91d845d  vmovaps xmm1, [rsp+0x10]
00007fdcd91d8463  vmovaps xmm2, [rsp+0x20]
00007fdcd91d8469  vmovaps xmm3, [rsp+0x30]
00007fdcd91d846f  vmovaps xmm4, [rsp+0x40]
00007fdcd91d8475  vmovaps xmm5, [rsp+0x50]
00007fdcd91d847b  vmovaps xmm7, [rsp+0x60]
00007fdcd91d8481  vmovaps xmm8, [rsp+0x70]
00007fdcd91d8487  vmovaps xmm9, [rsp+0x80]
00007fdcd91d8490  vmovaps xmm10, [rsp+0x90]
00007fdcd91d8499  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d84a2  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d84ab  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d84b4  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d84bd  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d84c6  add rsp, 0xF0
00007fdcd91d84cd  pop r11
00007fdcd91d84cf  pop r10
00007fdcd91d84d1  pop r9
00007fdcd91d84d3  pop r8
00007fdcd91d84d5  pop rsi
00007fdcd91d84d6  pop rdi
00007fdcd91d84d7  pop rdx
00007fdcd91d84d8  pop rcx
00007fdcd91d84d9  pop rax
00007fdcd91d84da  add rsp, 0x08
00007fdcd91d84de  jmp 0x00007FDCD91D5FAB
00007fdcd91d84e3  sub rsp, 0x08
00007fdcd91d84e7  push rax
00007fdcd91d84e8  push rcx
00007fdcd91d84e9  push rdx
00007fdcd91d84ea  push rdi
00007fdcd91d84eb  push rsi
00007fdcd91d84ec  push r8
00007fdcd91d84ee  push r9
00007fdcd91d84f0  push r10
00007fdcd91d84f2  push r11
00007fdcd91d84f4  sub rsp, 0xF0
00007fdcd91d84fb  vmovaps [rsp], xmm0
00007fdcd91d8500  vmovaps [rsp+0x10], xmm1
00007fdcd91d8506  vmovaps [rsp+0x20], xmm2
00007fdcd91d850c  vmovaps [rsp+0x30], xmm3
00007fdcd91d8512  vmovaps [rsp+0x40], xmm4
00007fdcd91d8518  vmovaps [rsp+0x50], xmm5
00007fdcd91d851e  vmovaps [rsp+0x60], xmm6
00007fdcd91d8524  vmovaps [rsp+0x70], xmm7
00007fdcd91d852a  vmovaps [rsp+0x80], xmm8
00007fdcd91d8533  vmovaps [rsp+0x90], xmm10
00007fdcd91d853c  vmovaps [rsp+0xA0], xmm11
00007fdcd91d8545  vmovaps [rsp+0xB0], xmm12
00007fdcd91d854e  vmovaps [rsp+0xC0], xmm13
00007fdcd91d8557  vmovaps [rsp+0xD0], xmm14
00007fdcd91d8560  vmovaps [rsp+0xE0], xmm15
00007fdcd91d8569  sub rsp, 0x30
00007fdcd91d856d  movaps [rsp], xmm9
00007fdcd91d8572  movaps [rsp+0x10], xmm3
00007fdcd91d8577  movaps [rsp+0x20], xmm1
00007fdcd91d857c  lea rdi, [rsp]
00007fdcd91d8580  mov esi, 0x00
00007fdcd91d8585  mov rax, 0x5B56EFBF3530
00007fdcd91d858f  call rax
00007fdcd91d8591  movaps xmm9, [rsp]
00007fdcd91d8596  add rsp, 0x30
00007fdcd91d859a  vmovaps xmm0, [rsp]
00007fdcd91d859f  vmovaps xmm1, [rsp+0x10]
00007fdcd91d85a5  vmovaps xmm2, [rsp+0x20]
00007fdcd91d85ab  vmovaps xmm3, [rsp+0x30]
00007fdcd91d85b1  vmovaps xmm4, [rsp+0x40]
00007fdcd91d85b7  vmovaps xmm5, [rsp+0x50]
00007fdcd91d85bd  vmovaps xmm6, [rsp+0x60]
00007fdcd91d85c3  vmovaps xmm7, [rsp+0x70]
00007fdcd91d85c9  vmovaps xmm8, [rsp+0x80]
00007fdcd91d85d2  vmovaps xmm10, [rsp+0x90]
00007fdcd91d85db  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d85e4  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d85ed  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d85f6  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d85ff  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d8608  add rsp, 0xF0
00007fdcd91d860f  pop r11
00007fdcd91d8611  pop r10
00007fdcd91d8613  pop r9
00007fdcd91d8615  pop r8
00007fdcd91d8617  pop rsi
00007fdcd91d8618  pop rdi
00007fdcd91d8619  pop rdx
00007fdcd91d861a  pop rcx
00007fdcd91d861b  pop rax
00007fdcd91d861c  add rsp, 0x08
00007fdcd91d8620  jmp 0x00007FDCD91D5FF7
00007fdcd91d8625  call 0x00007FDCD90D64F0
00007fdcd91d862a  jmp 0x00007FDCD91D6004
00007fdcd91d862f  sub rsp, 0x08
00007fdcd91d8633  push rax
00007fdcd91d8634  push rcx
00007fdcd91d8635  push rdx
00007fdcd91d8636  push rdi
00007fdcd91d8637  push rsi
00007fdcd91d8638  push r8
00007fdcd91d863a  push r9
00007fdcd91d863c  push r10
00007fdcd91d863e  push r11
00007fdcd91d8640  sub rsp, 0xF0
00007fdcd91d8647  vmovaps [rsp], xmm0
00007fdcd91d864c  vmovaps [rsp+0x10], xmm1
00007fdcd91d8652  vmovaps [rsp+0x20], xmm2
00007fdcd91d8658  vmovaps [rsp+0x30], xmm3
00007fdcd91d865e  vmovaps [rsp+0x40], xmm4
00007fdcd91d8664  vmovaps [rsp+0x50], xmm5
00007fdcd91d866a  vmovaps [rsp+0x60], xmm6
00007fdcd91d8670  vmovaps [rsp+0x70], xmm7
00007fdcd91d8676  vmovaps [rsp+0x80], xmm8
00007fdcd91d867f  vmovaps [rsp+0x90], xmm9
00007fdcd91d8688  vmovaps [rsp+0xA0], xmm10
00007fdcd91d8691  vmovaps [rsp+0xB0], xmm11
00007fdcd91d869a  vmovaps [rsp+0xC0], xmm12
00007fdcd91d86a3  vmovaps [rsp+0xD0], xmm13
00007fdcd91d86ac  vmovaps [rsp+0xE0], xmm14
00007fdcd91d86b5  sub rsp, 0x30
00007fdcd91d86b9  movaps [rsp], xmm15
00007fdcd91d86be  movaps [rsp+0x10], xmm3
00007fdcd91d86c3  movaps [rsp+0x20], xmm7
00007fdcd91d86c8  lea rdi, [rsp]
00007fdcd91d86cc  mov esi, 0x00
00007fdcd91d86d1  mov rax, 0x5B56EFBF3530
00007fdcd91d86db  call rax
00007fdcd91d86dd  movaps xmm15, [rsp]
00007fdcd91d86e2  add rsp, 0x30
00007fdcd91d86e6  vmovaps xmm0, [rsp]
00007fdcd91d86eb  vmovaps xmm1, [rsp+0x10]
00007fdcd91d86f1  vmovaps xmm2, [rsp+0x20]
00007fdcd91d86f7  vmovaps xmm3, [rsp+0x30]
00007fdcd91d86fd  vmovaps xmm4, [rsp+0x40]
00007fdcd91d8703  vmovaps xmm5, [rsp+0x50]
00007fdcd91d8709  vmovaps xmm6, [rsp+0x60]
00007fdcd91d870f  vmovaps xmm7, [rsp+0x70]
00007fdcd91d8715  vmovaps xmm8, [rsp+0x80]
00007fdcd91d871e  vmovaps xmm9, [rsp+0x90]
00007fdcd91d8727  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d8730  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d8739  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d8742  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d874b  vmovaps xmm14, [rsp+0xE0]
00007fdcd91d8754  add rsp, 0xF0
00007fdcd91d875b  pop r11
00007fdcd91d875d  pop r10
00007fdcd91d875f  pop r9
00007fdcd91d8761  pop r8
00007fdcd91d8763  pop rsi
00007fdcd91d8764  pop rdi
00007fdcd91d8765  pop rdx
00007fdcd91d8766  pop rcx
00007fdcd91d8767  pop rax
00007fdcd91d8768  add rsp, 0x08
00007fdcd91d876c  jmp 0x00007FDCD91D6030
00007fdcd91d8771  sub rsp, 0x08
00007fdcd91d8775  push rax
00007fdcd91d8776  push rcx
00007fdcd91d8777  push rdx
00007fdcd91d8778  push rdi
00007fdcd91d8779  push rsi
00007fdcd91d877a  push r8
00007fdcd91d877c  push r9
00007fdcd91d877e  push r10
00007fdcd91d8780  push r11
00007fdcd91d8782  sub rsp, 0xF0
00007fdcd91d8789  vmovaps [rsp], xmm0
00007fdcd91d878e  vmovaps [rsp+0x10], xmm1
00007fdcd91d8794  vmovaps [rsp+0x20], xmm2
00007fdcd91d879a  vmovaps [rsp+0x30], xmm4
00007fdcd91d87a0  vmovaps [rsp+0x40], xmm5
00007fdcd91d87a6  vmovaps [rsp+0x50], xmm6
00007fdcd91d87ac  vmovaps [rsp+0x60], xmm7
00007fdcd91d87b2  vmovaps [rsp+0x70], xmm8
00007fdcd91d87b8  vmovaps [rsp+0x80], xmm9
00007fdcd91d87c1  vmovaps [rsp+0x90], xmm10
00007fdcd91d87ca  vmovaps [rsp+0xA0], xmm11
00007fdcd91d87d3  vmovaps [rsp+0xB0], xmm12
00007fdcd91d87dc  vmovaps [rsp+0xC0], xmm13
00007fdcd91d87e5  vmovaps [rsp+0xD0], xmm14
00007fdcd91d87ee  vmovaps [rsp+0xE0], xmm15
00007fdcd91d87f7  sub rsp, 0x30
00007fdcd91d87fb  movaps [rsp], xmm3
00007fdcd91d87ff  movaps [rsp+0x10], xmm1
00007fdcd91d8804  movaps [rsp+0x20], xmm15
00007fdcd91d880a  lea rdi, [rsp]
00007fdcd91d880e  mov esi, 0x00
00007fdcd91d8813  mov rax, 0x5B56EFBF3530
00007fdcd91d881d  call rax
00007fdcd91d881f  movaps xmm3, [rsp]
00007fdcd91d8823  add rsp, 0x30
00007fdcd91d8827  vmovaps xmm0, [rsp]
00007fdcd91d882c  vmovaps xmm1, [rsp+0x10]
00007fdcd91d8832  vmovaps xmm2, [rsp+0x20]
00007fdcd91d8838  vmovaps xmm4, [rsp+0x30]
00007fdcd91d883e  vmovaps xmm5, [rsp+0x40]
00007fdcd91d8844  vmovaps xmm6, [rsp+0x50]
00007fdcd91d884a  vmovaps xmm7, [rsp+0x60]
00007fdcd91d8850  vmovaps xmm8, [rsp+0x70]
00007fdcd91d8856  vmovaps xmm9, [rsp+0x80]
00007fdcd91d885f  vmovaps xmm10, [rsp+0x90]
00007fdcd91d8868  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d8871  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d887a  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d8883  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d888c  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d8895  add rsp, 0xF0
00007fdcd91d889c  pop r11
00007fdcd91d889e  pop r10
00007fdcd91d88a0  pop r9
00007fdcd91d88a2  pop r8
00007fdcd91d88a4  pop rsi
00007fdcd91d88a5  pop rdi
00007fdcd91d88a6  pop rdx
00007fdcd91d88a7  pop rcx
00007fdcd91d88a8  pop rax
00007fdcd91d88a9  add rsp, 0x08
00007fdcd91d88ad  jmp 0x00007FDCD91D60BF
00007fdcd91d88b2  call 0x00007FDCD90D64F0
00007fdcd91d88b7  jmp 0x00007FDCD91D60C9
00007fdcd91d88bc  sub rsp, 0x08
00007fdcd91d88c0  push rax
00007fdcd91d88c1  push rcx
00007fdcd91d88c2  push rdx
00007fdcd91d88c3  push rdi
00007fdcd91d88c4  push rsi
00007fdcd91d88c5  push r8
00007fdcd91d88c7  push r9
00007fdcd91d88c9  push r10
00007fdcd91d88cb  push r11
00007fdcd91d88cd  sub rsp, 0xF0
00007fdcd91d88d4  vmovaps [rsp], xmm0
00007fdcd91d88d9  vmovaps [rsp+0x10], xmm1
00007fdcd91d88df  vmovaps [rsp+0x20], xmm2
00007fdcd91d88e5  vmovaps [rsp+0x30], xmm3
00007fdcd91d88eb  vmovaps [rsp+0x40], xmm4
00007fdcd91d88f1  vmovaps [rsp+0x50], xmm5
00007fdcd91d88f7  vmovaps [rsp+0x60], xmm6
00007fdcd91d88fd  vmovaps [rsp+0x70], xmm7
00007fdcd91d8903  vmovaps [rsp+0x80], xmm8
00007fdcd91d890c  vmovaps [rsp+0x90], xmm9
00007fdcd91d8915  vmovaps [rsp+0xA0], xmm10
00007fdcd91d891e  vmovaps [rsp+0xB0], xmm11
00007fdcd91d8927  vmovaps [rsp+0xC0], xmm12
00007fdcd91d8930  vmovaps [rsp+0xD0], xmm13
00007fdcd91d8939  vmovaps [rsp+0xE0], xmm14
00007fdcd91d8942  sub rsp, 0x30
00007fdcd91d8946  movaps [rsp], xmm15
00007fdcd91d894b  movaps [rsp+0x10], xmm14
00007fdcd91d8951  movaps [rsp+0x20], xmm4
00007fdcd91d8956  lea rdi, [rsp]
00007fdcd91d895a  mov esi, 0x00
00007fdcd91d895f  mov rax, 0x5B56EFBF3530
00007fdcd91d8969  call rax
00007fdcd91d896b  movaps xmm15, [rsp]
00007fdcd91d8970  add rsp, 0x30
00007fdcd91d8974  vmovaps xmm0, [rsp]
00007fdcd91d8979  vmovaps xmm1, [rsp+0x10]
00007fdcd91d897f  vmovaps xmm2, [rsp+0x20]
00007fdcd91d8985  vmovaps xmm3, [rsp+0x30]
00007fdcd91d898b  vmovaps xmm4, [rsp+0x40]
00007fdcd91d8991  vmovaps xmm5, [rsp+0x50]
00007fdcd91d8997  vmovaps xmm6, [rsp+0x60]
00007fdcd91d899d  vmovaps xmm7, [rsp+0x70]
00007fdcd91d89a3  vmovaps xmm8, [rsp+0x80]
00007fdcd91d89ac  vmovaps xmm9, [rsp+0x90]
00007fdcd91d89b5  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d89be  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d89c7  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d89d0  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d89d9  vmovaps xmm14, [rsp+0xE0]
00007fdcd91d89e2  add rsp, 0xF0
00007fdcd91d89e9  pop r11
00007fdcd91d89eb  pop r10
00007fdcd91d89ed  pop r9
00007fdcd91d89ef  pop r8
00007fdcd91d89f1  pop rsi
00007fdcd91d89f2  pop rdi
00007fdcd91d89f3  pop rdx
00007fdcd91d89f4  pop rcx
00007fdcd91d89f5  pop rax
00007fdcd91d89f6  add rsp, 0x08
00007fdcd91d89fa  jmp 0x00007FDCD91D60F7
00007fdcd91d89ff  sub rsp, 0x08
00007fdcd91d8a03  push rax
00007fdcd91d8a04  push rcx
00007fdcd91d8a05  push rdx
00007fdcd91d8a06  push rdi
00007fdcd91d8a07  push rsi
00007fdcd91d8a08  push r8
00007fdcd91d8a0a  push r9
00007fdcd91d8a0c  push r10
00007fdcd91d8a0e  push r11
00007fdcd91d8a10  sub rsp, 0xF0
00007fdcd91d8a17  vmovaps [rsp], xmm0
00007fdcd91d8a1c  vmovaps [rsp+0x10], xmm1
00007fdcd91d8a22  vmovaps [rsp+0x20], xmm2
00007fdcd91d8a28  vmovaps [rsp+0x30], xmm3
00007fdcd91d8a2e  vmovaps [rsp+0x40], xmm4
00007fdcd91d8a34  vmovaps [rsp+0x50], xmm5
00007fdcd91d8a3a  vmovaps [rsp+0x60], xmm6
00007fdcd91d8a40  vmovaps [rsp+0x70], xmm7
00007fdcd91d8a46  vmovaps [rsp+0x80], xmm8
00007fdcd91d8a4f  vmovaps [rsp+0x90], xmm9
00007fdcd91d8a58  vmovaps [rsp+0xA0], xmm10
00007fdcd91d8a61  vmovaps [rsp+0xB0], xmm11
00007fdcd91d8a6a  vmovaps [rsp+0xC0], xmm12
00007fdcd91d8a73  vmovaps [rsp+0xD0], xmm13
00007fdcd91d8a7c  vmovaps [rsp+0xE0], xmm15
00007fdcd91d8a85  sub rsp, 0x30
00007fdcd91d8a89  movaps [rsp], xmm14
00007fdcd91d8a8e  movaps [rsp+0x10], xmm2
00007fdcd91d8a93  movaps [rsp+0x20], xmm1
00007fdcd91d8a98  lea rdi, [rsp]
00007fdcd91d8a9c  mov esi, 0x00
00007fdcd91d8aa1  mov rax, 0x5B56EFBF3530
00007fdcd91d8aab  call rax
00007fdcd91d8aad  movaps xmm14, [rsp]
00007fdcd91d8ab2  add rsp, 0x30
00007fdcd91d8ab6  vmovaps xmm0, [rsp]
00007fdcd91d8abb  vmovaps xmm1, [rsp+0x10]
00007fdcd91d8ac1  vmovaps xmm2, [rsp+0x20]
00007fdcd91d8ac7  vmovaps xmm3, [rsp+0x30]
00007fdcd91d8acd  vmovaps xmm4, [rsp+0x40]
00007fdcd91d8ad3  vmovaps xmm5, [rsp+0x50]
00007fdcd91d8ad9  vmovaps xmm6, [rsp+0x60]
00007fdcd91d8adf  vmovaps xmm7, [rsp+0x70]
00007fdcd91d8ae5  vmovaps xmm8, [rsp+0x80]
00007fdcd91d8aee  vmovaps xmm9, [rsp+0x90]
00007fdcd91d8af7  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d8b00  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d8b09  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d8b12  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d8b1b  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d8b24  add rsp, 0xF0
00007fdcd91d8b2b  pop r11
00007fdcd91d8b2d  pop r10
00007fdcd91d8b2f  pop r9
00007fdcd91d8b31  pop r8
00007fdcd91d8b33  pop rsi
00007fdcd91d8b34  pop rdi
00007fdcd91d8b35  pop rdx
00007fdcd91d8b36  pop rcx
00007fdcd91d8b37  pop rax
00007fdcd91d8b38  add rsp, 0x08
00007fdcd91d8b3c  jmp 0x00007FDCD91D611D
00007fdcd91d8b41  sub rsp, 0x08
00007fdcd91d8b45  push rax
00007fdcd91d8b46  push rcx
00007fdcd91d8b47  push rdx
00007fdcd91d8b48  push rdi
00007fdcd91d8b49  push rsi
00007fdcd91d8b4a  push r8
00007fdcd91d8b4c  push r9
00007fdcd91d8b4e  push r10
00007fdcd91d8b50  push r11
00007fdcd91d8b52  sub rsp, 0xF0
00007fdcd91d8b59  vmovaps [rsp], xmm0
00007fdcd91d8b5e  vmovaps [rsp+0x10], xmm2
00007fdcd91d8b64  vmovaps [rsp+0x20], xmm3
00007fdcd91d8b6a  vmovaps [rsp+0x30], xmm4
00007fdcd91d8b70  vmovaps [rsp+0x40], xmm5
00007fdcd91d8b76  vmovaps [rsp+0x50], xmm6
00007fdcd91d8b7c  vmovaps [rsp+0x60], xmm7
00007fdcd91d8b82  vmovaps [rsp+0x70], xmm8
00007fdcd91d8b88  vmovaps [rsp+0x80], xmm9
00007fdcd91d8b91  vmovaps [rsp+0x90], xmm10
00007fdcd91d8b9a  vmovaps [rsp+0xA0], xmm11
00007fdcd91d8ba3  vmovaps [rsp+0xB0], xmm12
00007fdcd91d8bac  vmovaps [rsp+0xC0], xmm13
00007fdcd91d8bb5  vmovaps [rsp+0xD0], xmm14
00007fdcd91d8bbe  vmovaps [rsp+0xE0], xmm15
00007fdcd91d8bc7  sub rsp, 0x30
00007fdcd91d8bcb  movaps [rsp], xmm1
00007fdcd91d8bcf  movaps [rsp+0x10], xmm4
00007fdcd91d8bd4  movaps [rsp+0x20], xmm9
00007fdcd91d8bda  lea rdi, [rsp]
00007fdcd91d8bde  mov esi, 0x00
00007fdcd91d8be3  mov rax, 0x5B56EFBF3530
00007fdcd91d8bed  call rax
00007fdcd91d8bef  movaps xmm1, [rsp]
00007fdcd91d8bf3  add rsp, 0x30
00007fdcd91d8bf7  vmovaps xmm0, [rsp]
00007fdcd91d8bfc  vmovaps xmm2, [rsp+0x10]
00007fdcd91d8c02  vmovaps xmm3, [rsp+0x20]
00007fdcd91d8c08  vmovaps xmm4, [rsp+0x30]
00007fdcd91d8c0e  vmovaps xmm5, [rsp+0x40]
00007fdcd91d8c14  vmovaps xmm6, [rsp+0x50]
00007fdcd91d8c1a  vmovaps xmm7, [rsp+0x60]
00007fdcd91d8c20  vmovaps xmm8, [rsp+0x70]
00007fdcd91d8c26  vmovaps xmm9, [rsp+0x80]
00007fdcd91d8c2f  vmovaps xmm10, [rsp+0x90]
00007fdcd91d8c38  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d8c41  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d8c4a  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d8c53  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d8c5c  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d8c65  add rsp, 0xF0
00007fdcd91d8c6c  pop r11
00007fdcd91d8c6e  pop r10
00007fdcd91d8c70  pop r9
00007fdcd91d8c72  pop r8
00007fdcd91d8c74  pop rsi
00007fdcd91d8c75  pop rdi
00007fdcd91d8c76  pop rdx
00007fdcd91d8c77  pop rcx
00007fdcd91d8c78  pop rax
00007fdcd91d8c79  add rsp, 0x08
00007fdcd91d8c7d  jmp 0x00007FDCD91D613B
00007fdcd91d8c82  sub rsp, 0x08
00007fdcd91d8c86  push rax
00007fdcd91d8c87  push rcx
00007fdcd91d8c88  push rdx
00007fdcd91d8c89  push rdi
00007fdcd91d8c8a  push rsi
00007fdcd91d8c8b  push r8
00007fdcd91d8c8d  push r9
00007fdcd91d8c8f  push r10
00007fdcd91d8c91  push r11
00007fdcd91d8c93  sub rsp, 0xF0
00007fdcd91d8c9a  vmovaps [rsp], xmm0
00007fdcd91d8c9f  vmovaps [rsp+0x10], xmm1
00007fdcd91d8ca5  vmovaps [rsp+0x20], xmm2
00007fdcd91d8cab  vmovaps [rsp+0x30], xmm3
00007fdcd91d8cb1  vmovaps [rsp+0x40], xmm5
00007fdcd91d8cb7  vmovaps [rsp+0x50], xmm6
00007fdcd91d8cbd  vmovaps [rsp+0x60], xmm7
00007fdcd91d8cc3  vmovaps [rsp+0x70], xmm8
00007fdcd91d8cc9  vmovaps [rsp+0x80], xmm9
00007fdcd91d8cd2  vmovaps [rsp+0x90], xmm10
00007fdcd91d8cdb  vmovaps [rsp+0xA0], xmm11
00007fdcd91d8ce4  vmovaps [rsp+0xB0], xmm12
00007fdcd91d8ced  vmovaps [rsp+0xC0], xmm13
00007fdcd91d8cf6  vmovaps [rsp+0xD0], xmm14
00007fdcd91d8cff  vmovaps [rsp+0xE0], xmm15
00007fdcd91d8d08  sub rsp, 0x30
00007fdcd91d8d0c  movaps [rsp], xmm4
00007fdcd91d8d10  movaps [rsp+0x10], xmm2
00007fdcd91d8d15  movaps [rsp+0x20], xmm9
00007fdcd91d8d1b  lea rdi, [rsp]
00007fdcd91d8d1f  mov esi, 0x00
00007fdcd91d8d24  mov rax, 0x5B56EFBF3530
00007fdcd91d8d2e  call rax
00007fdcd91d8d30  movaps xmm4, [rsp]
00007fdcd91d8d34  add rsp, 0x30
00007fdcd91d8d38  vmovaps xmm0, [rsp]
00007fdcd91d8d3d  vmovaps xmm1, [rsp+0x10]
00007fdcd91d8d43  vmovaps xmm2, [rsp+0x20]
00007fdcd91d8d49  vmovaps xmm3, [rsp+0x30]
00007fdcd91d8d4f  vmovaps xmm5, [rsp+0x40]
00007fdcd91d8d55  vmovaps xmm6, [rsp+0x50]
00007fdcd91d8d5b  vmovaps xmm7, [rsp+0x60]
00007fdcd91d8d61  vmovaps xmm8, [rsp+0x70]
00007fdcd91d8d67  vmovaps xmm9, [rsp+0x80]
00007fdcd91d8d70  vmovaps xmm10, [rsp+0x90]
00007fdcd91d8d79  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d8d82  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d8d8b  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d8d94  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d8d9d  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d8da6  add rsp, 0xF0
00007fdcd91d8dad  pop r11
00007fdcd91d8daf  pop r10
00007fdcd91d8db1  pop r9
00007fdcd91d8db3  pop r8
00007fdcd91d8db5  pop rsi
00007fdcd91d8db6  pop rdi
00007fdcd91d8db7  pop rdx
00007fdcd91d8db8  pop rcx
00007fdcd91d8db9  pop rax
00007fdcd91d8dba  add rsp, 0x08
00007fdcd91d8dbe  jmp 0x00007FDCD91D616B
00007fdcd91d8dc3  sub rsp, 0x08
00007fdcd91d8dc7  push rax
00007fdcd91d8dc8  push rcx
00007fdcd91d8dc9  push rdx
00007fdcd91d8dca  push rdi
00007fdcd91d8dcb  push rsi
00007fdcd91d8dcc  push r8
00007fdcd91d8dce  push r9
00007fdcd91d8dd0  push r10
00007fdcd91d8dd2  push r11
00007fdcd91d8dd4  sub rsp, 0xF0
00007fdcd91d8ddb  vmovaps [rsp], xmm0
00007fdcd91d8de0  vmovaps [rsp+0x10], xmm1
00007fdcd91d8de6  vmovaps [rsp+0x20], xmm2
00007fdcd91d8dec  vmovaps [rsp+0x30], xmm3
00007fdcd91d8df2  vmovaps [rsp+0x40], xmm4
00007fdcd91d8df8  vmovaps [rsp+0x50], xmm5
00007fdcd91d8dfe  vmovaps [rsp+0x60], xmm6
00007fdcd91d8e04  vmovaps [rsp+0x70], xmm7
00007fdcd91d8e0a  vmovaps [rsp+0x80], xmm8
00007fdcd91d8e13  vmovaps [rsp+0x90], xmm10
00007fdcd91d8e1c  vmovaps [rsp+0xA0], xmm11
00007fdcd91d8e25  vmovaps [rsp+0xB0], xmm12
00007fdcd91d8e2e  vmovaps [rsp+0xC0], xmm13
00007fdcd91d8e37  vmovaps [rsp+0xD0], xmm14
00007fdcd91d8e40  vmovaps [rsp+0xE0], xmm15
00007fdcd91d8e49  sub rsp, 0x30
00007fdcd91d8e4d  movaps [rsp], xmm9
00007fdcd91d8e52  movaps [rsp+0x10], xmm2
00007fdcd91d8e57  movaps [rsp+0x20], xmm1
00007fdcd91d8e5c  lea rdi, [rsp]
00007fdcd91d8e60  mov esi, 0x00
00007fdcd91d8e65  mov rax, 0x5B56EFBF3530
00007fdcd91d8e6f  call rax
00007fdcd91d8e71  movaps xmm9, [rsp]
00007fdcd91d8e76  add rsp, 0x30
00007fdcd91d8e7a  vmovaps xmm0, [rsp]
00007fdcd91d8e7f  vmovaps xmm1, [rsp+0x10]
00007fdcd91d8e85  vmovaps xmm2, [rsp+0x20]
00007fdcd91d8e8b  vmovaps xmm3, [rsp+0x30]
00007fdcd91d8e91  vmovaps xmm4, [rsp+0x40]
00007fdcd91d8e97  vmovaps xmm5, [rsp+0x50]
00007fdcd91d8e9d  vmovaps xmm6, [rsp+0x60]
00007fdcd91d8ea3  vmovaps xmm7, [rsp+0x70]
00007fdcd91d8ea9  vmovaps xmm8, [rsp+0x80]
00007fdcd91d8eb2  vmovaps xmm10, [rsp+0x90]
00007fdcd91d8ebb  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d8ec4  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d8ecd  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d8ed6  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d8edf  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d8ee8  add rsp, 0xF0
00007fdcd91d8eef  pop r11
00007fdcd91d8ef1  pop r10
00007fdcd91d8ef3  pop r9
00007fdcd91d8ef5  pop r8
00007fdcd91d8ef7  pop rsi
00007fdcd91d8ef8  pop rdi
00007fdcd91d8ef9  pop rdx
00007fdcd91d8efa  pop rcx
00007fdcd91d8efb  pop rax
00007fdcd91d8efc  add rsp, 0x08
00007fdcd91d8f00  jmp 0x00007FDCD91D61A1
00007fdcd91d8f05  sub rsp, 0x08
00007fdcd91d8f09  push rax
00007fdcd91d8f0a  push rcx
00007fdcd91d8f0b  push rdx
00007fdcd91d8f0c  push rdi
00007fdcd91d8f0d  push rsi
00007fdcd91d8f0e  push r8
00007fdcd91d8f10  push r9
00007fdcd91d8f12  push r10
00007fdcd91d8f14  push r11
00007fdcd91d8f16  sub rsp, 0xF0
00007fdcd91d8f1d  vmovaps [rsp], xmm0
00007fdcd91d8f22  vmovaps [rsp+0x10], xmm2
00007fdcd91d8f28  vmovaps [rsp+0x20], xmm3
00007fdcd91d8f2e  vmovaps [rsp+0x30], xmm4
00007fdcd91d8f34  vmovaps [rsp+0x40], xmm5
00007fdcd91d8f3a  vmovaps [rsp+0x50], xmm6
00007fdcd91d8f40  vmovaps [rsp+0x60], xmm7
00007fdcd91d8f46  vmovaps [rsp+0x70], xmm8
00007fdcd91d8f4c  vmovaps [rsp+0x80], xmm9
00007fdcd91d8f55  vmovaps [rsp+0x90], xmm10
00007fdcd91d8f5e  vmovaps [rsp+0xA0], xmm11
00007fdcd91d8f67  vmovaps [rsp+0xB0], xmm12
00007fdcd91d8f70  vmovaps [rsp+0xC0], xmm13
00007fdcd91d8f79  vmovaps [rsp+0xD0], xmm14
00007fdcd91d8f82  vmovaps [rsp+0xE0], xmm15
00007fdcd91d8f8b  sub rsp, 0x30
00007fdcd91d8f8f  movaps [rsp], xmm1
00007fdcd91d8f93  movaps [rsp+0x10], xmm15
00007fdcd91d8f99  movaps [rsp+0x20], xmm6
00007fdcd91d8f9e  lea rdi, [rsp]
00007fdcd91d8fa2  mov esi, 0x00
00007fdcd91d8fa7  mov rax, 0x5B56EFBF3530
00007fdcd91d8fb1  call rax
00007fdcd91d8fb3  movaps xmm1, [rsp]
00007fdcd91d8fb7  add rsp, 0x30
00007fdcd91d8fbb  vmovaps xmm0, [rsp]
00007fdcd91d8fc0  vmovaps xmm2, [rsp+0x10]
00007fdcd91d8fc6  vmovaps xmm3, [rsp+0x20]
00007fdcd91d8fcc  vmovaps xmm4, [rsp+0x30]
00007fdcd91d8fd2  vmovaps xmm5, [rsp+0x40]
00007fdcd91d8fd8  vmovaps xmm6, [rsp+0x50]
00007fdcd91d8fde  vmovaps xmm7, [rsp+0x60]
00007fdcd91d8fe4  vmovaps xmm8, [rsp+0x70]
00007fdcd91d8fea  vmovaps xmm9, [rsp+0x80]
00007fdcd91d8ff3  vmovaps xmm10, [rsp+0x90]
00007fdcd91d8ffc  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d9005  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d900e  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d9017  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d9020  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d9029  add rsp, 0xF0
00007fdcd91d9030  pop r11
00007fdcd91d9032  pop r10
00007fdcd91d9034  pop r9
00007fdcd91d9036  pop r8
00007fdcd91d9038  pop rsi
00007fdcd91d9039  pop rdi
00007fdcd91d903a  pop rdx
00007fdcd91d903b  pop rcx
00007fdcd91d903c  pop rax
00007fdcd91d903d  add rsp, 0x08
00007fdcd91d9041  jmp 0x00007FDCD91D61C2
00007fdcd91d9046  sub rsp, 0x08
00007fdcd91d904a  push rax
00007fdcd91d904b  push rcx
00007fdcd91d904c  push rdx
00007fdcd91d904d  push rdi
00007fdcd91d904e  push rsi
00007fdcd91d904f  push r8
00007fdcd91d9051  push r9
00007fdcd91d9053  push r10
00007fdcd91d9055  push r11
00007fdcd91d9057  sub rsp, 0xF0
00007fdcd91d905e  vmovaps [rsp], xmm0
00007fdcd91d9063  vmovaps [rsp+0x10], xmm1
00007fdcd91d9069  vmovaps [rsp+0x20], xmm2
00007fdcd91d906f  vmovaps [rsp+0x30], xmm3
00007fdcd91d9075  vmovaps [rsp+0x40], xmm4
00007fdcd91d907b  vmovaps [rsp+0x50], xmm5
00007fdcd91d9081  vmovaps [rsp+0x60], xmm6
00007fdcd91d9087  vmovaps [rsp+0x70], xmm7
00007fdcd91d908d  vmovaps [rsp+0x80], xmm8
00007fdcd91d9096  vmovaps [rsp+0x90], xmm9
00007fdcd91d909f  vmovaps [rsp+0xA0], xmm10
00007fdcd91d90a8  vmovaps [rsp+0xB0], xmm11
00007fdcd91d90b1  vmovaps [rsp+0xC0], xmm12
00007fdcd91d90ba  vmovaps [rsp+0xD0], xmm13
00007fdcd91d90c3  vmovaps [rsp+0xE0], xmm14
00007fdcd91d90cc  sub rsp, 0x30
00007fdcd91d90d0  movaps [rsp], xmm15
00007fdcd91d90d5  movaps [rsp+0x10], xmm5
00007fdcd91d90da  movaps [rsp+0x20], xmm3
00007fdcd91d90df  lea rdi, [rsp]
00007fdcd91d90e3  mov esi, 0x00
00007fdcd91d90e8  mov rax, 0x5B56EFBF3530
00007fdcd91d90f2  call rax
00007fdcd91d90f4  movaps xmm15, [rsp]
00007fdcd91d90f9  add rsp, 0x30
00007fdcd91d90fd  vmovaps xmm0, [rsp]
00007fdcd91d9102  vmovaps xmm1, [rsp+0x10]
00007fdcd91d9108  vmovaps xmm2, [rsp+0x20]
00007fdcd91d910e  vmovaps xmm3, [rsp+0x30]
00007fdcd91d9114  vmovaps xmm4, [rsp+0x40]
00007fdcd91d911a  vmovaps xmm5, [rsp+0x50]
00007fdcd91d9120  vmovaps xmm6, [rsp+0x60]
00007fdcd91d9126  vmovaps xmm7, [rsp+0x70]
00007fdcd91d912c  vmovaps xmm8, [rsp+0x80]
00007fdcd91d9135  vmovaps xmm9, [rsp+0x90]
00007fdcd91d913e  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d9147  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d9150  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d9159  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d9162  vmovaps xmm14, [rsp+0xE0]
00007fdcd91d916b  add rsp, 0xF0
00007fdcd91d9172  pop r11
00007fdcd91d9174  pop r10
00007fdcd91d9176  pop r9
00007fdcd91d9178  pop r8
00007fdcd91d917a  pop rsi
00007fdcd91d917b  pop rdi
00007fdcd91d917c  pop rdx
00007fdcd91d917d  pop rcx
00007fdcd91d917e  pop rax
00007fdcd91d917f  add rsp, 0x08
00007fdcd91d9183  jmp 0x00007FDCD91D61DC
00007fdcd91d9188  sub rsp, 0x08
00007fdcd91d918c  push rax
00007fdcd91d918d  push rcx
00007fdcd91d918e  push rdx
00007fdcd91d918f  push rdi
00007fdcd91d9190  push rsi
00007fdcd91d9191  push r8
00007fdcd91d9193  push r9
00007fdcd91d9195  push r10
00007fdcd91d9197  push r11
00007fdcd91d9199  sub rsp, 0xF0
00007fdcd91d91a0  vmovaps [rsp], xmm0
00007fdcd91d91a5  vmovaps [rsp+0x10], xmm1
00007fdcd91d91ab  vmovaps [rsp+0x20], xmm2
00007fdcd91d91b1  vmovaps [rsp+0x30], xmm3
00007fdcd91d91b7  vmovaps [rsp+0x40], xmm4
00007fdcd91d91bd  vmovaps [rsp+0x50], xmm6
00007fdcd91d91c3  vmovaps [rsp+0x60], xmm7
00007fdcd91d91c9  vmovaps [rsp+0x70], xmm8
00007fdcd91d91cf  vmovaps [rsp+0x80], xmm9
00007fdcd91d91d8  vmovaps [rsp+0x90], xmm10
00007fdcd91d91e1  vmovaps [rsp+0xA0], xmm11
00007fdcd91d91ea  vmovaps [rsp+0xB0], xmm12
00007fdcd91d91f3  vmovaps [rsp+0xC0], xmm13
00007fdcd91d91fc  vmovaps [rsp+0xD0], xmm14
00007fdcd91d9205  vmovaps [rsp+0xE0], xmm15
00007fdcd91d920e  sub rsp, 0x30
00007fdcd91d9212  movaps [rsp], xmm5
00007fdcd91d9216  movaps [rsp+0x10], xmm8
00007fdcd91d921c  movaps [rsp+0x20], xmm6
00007fdcd91d9221  lea rdi, [rsp]
00007fdcd91d9225  mov esi, 0x00
00007fdcd91d922a  mov rax, 0x5B56EFBF3530
00007fdcd91d9234  call rax
00007fdcd91d9236  movaps xmm5, [rsp]
00007fdcd91d923a  add rsp, 0x30
00007fdcd91d923e  vmovaps xmm0, [rsp]
00007fdcd91d9243  vmovaps xmm1, [rsp+0x10]
00007fdcd91d9249  vmovaps xmm2, [rsp+0x20]
00007fdcd91d924f  vmovaps xmm3, [rsp+0x30]
00007fdcd91d9255  vmovaps xmm4, [rsp+0x40]
00007fdcd91d925b  vmovaps xmm6, [rsp+0x50]
00007fdcd91d9261  vmovaps xmm7, [rsp+0x60]
00007fdcd91d9267  vmovaps xmm8, [rsp+0x70]
00007fdcd91d926d  vmovaps xmm9, [rsp+0x80]
00007fdcd91d9276  vmovaps xmm10, [rsp+0x90]
00007fdcd91d927f  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d9288  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d9291  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d929a  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d92a3  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d92ac  add rsp, 0xF0
00007fdcd91d92b3  pop r11
00007fdcd91d92b5  pop r10
00007fdcd91d92b7  pop r9
00007fdcd91d92b9  pop r8
00007fdcd91d92bb  pop rsi
00007fdcd91d92bc  pop rdi
00007fdcd91d92bd  pop rdx
00007fdcd91d92be  pop rcx
00007fdcd91d92bf  pop rax
00007fdcd91d92c0  add rsp, 0x08
00007fdcd91d92c4  jmp 0x00007FDCD91D6200
00007fdcd91d92c9  sub rsp, 0x08
00007fdcd91d92cd  push rax
00007fdcd91d92ce  push rcx
00007fdcd91d92cf  push rdx
00007fdcd91d92d0  push rdi
00007fdcd91d92d1  push rsi
00007fdcd91d92d2  push r8
00007fdcd91d92d4  push r9
00007fdcd91d92d6  push r10
00007fdcd91d92d8  push r11
00007fdcd91d92da  sub rsp, 0xF0
00007fdcd91d92e1  vmovaps [rsp], xmm0
00007fdcd91d92e6  vmovaps [rsp+0x10], xmm1
00007fdcd91d92ec  vmovaps [rsp+0x20], xmm2
00007fdcd91d92f2  vmovaps [rsp+0x30], xmm3
00007fdcd91d92f8  vmovaps [rsp+0x40], xmm4
00007fdcd91d92fe  vmovaps [rsp+0x50], xmm5
00007fdcd91d9304  vmovaps [rsp+0x60], xmm7
00007fdcd91d930a  vmovaps [rsp+0x70], xmm8
00007fdcd91d9310  vmovaps [rsp+0x80], xmm9
00007fdcd91d9319  vmovaps [rsp+0x90], xmm10
00007fdcd91d9322  vmovaps [rsp+0xA0], xmm11
00007fdcd91d932b  vmovaps [rsp+0xB0], xmm12
00007fdcd91d9334  vmovaps [rsp+0xC0], xmm13
00007fdcd91d933d  vmovaps [rsp+0xD0], xmm14
00007fdcd91d9346  vmovaps [rsp+0xE0], xmm15
00007fdcd91d934f  sub rsp, 0x30
00007fdcd91d9353  movaps [rsp], xmm6
00007fdcd91d9357  movaps [rsp+0x10], xmm10
00007fdcd91d935d  movaps [rsp+0x20], xmm8
00007fdcd91d9363  lea rdi, [rsp]
00007fdcd91d9367  mov esi, 0x00
00007fdcd91d936c  mov rax, 0x5B56EFBF3530
00007fdcd91d9376  call rax
00007fdcd91d9378  movaps xmm6, [rsp]
00007fdcd91d937c  add rsp, 0x30
00007fdcd91d9380  vmovaps xmm0, [rsp]
00007fdcd91d9385  vmovaps xmm1, [rsp+0x10]
00007fdcd91d938b  vmovaps xmm2, [rsp+0x20]
00007fdcd91d9391  vmovaps xmm3, [rsp+0x30]
00007fdcd91d9397  vmovaps xmm4, [rsp+0x40]
00007fdcd91d939d  vmovaps xmm5, [rsp+0x50]
00007fdcd91d93a3  vmovaps xmm7, [rsp+0x60]
00007fdcd91d93a9  vmovaps xmm8, [rsp+0x70]
00007fdcd91d93af  vmovaps xmm9, [rsp+0x80]
00007fdcd91d93b8  vmovaps xmm10, [rsp+0x90]
00007fdcd91d93c1  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d93ca  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d93d3  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d93dc  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d93e5  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d93ee  add rsp, 0xF0
00007fdcd91d93f5  pop r11
00007fdcd91d93f7  pop r10
00007fdcd91d93f9  pop r9
00007fdcd91d93fb  pop r8
00007fdcd91d93fd  pop rsi
00007fdcd91d93fe  pop rdi
00007fdcd91d93ff  pop rdx
00007fdcd91d9400  pop rcx
00007fdcd91d9401  pop rax
00007fdcd91d9402  add rsp, 0x08
00007fdcd91d9406  jmp 0x00007FDCD91D6225
00007fdcd91d940b  sub rsp, 0x08
00007fdcd91d940f  push rax
00007fdcd91d9410  push rcx
00007fdcd91d9411  push rdx
00007fdcd91d9412  push rdi
00007fdcd91d9413  push rsi
00007fdcd91d9414  push r8
00007fdcd91d9416  push r9
00007fdcd91d9418  push r10
00007fdcd91d941a  push r11
00007fdcd91d941c  sub rsp, 0xF0
00007fdcd91d9423  vmovaps [rsp], xmm0
00007fdcd91d9428  vmovaps [rsp+0x10], xmm1
00007fdcd91d942e  vmovaps [rsp+0x20], xmm2
00007fdcd91d9434  vmovaps [rsp+0x30], xmm3
00007fdcd91d943a  vmovaps [rsp+0x40], xmm4
00007fdcd91d9440  vmovaps [rsp+0x50], xmm5
00007fdcd91d9446  vmovaps [rsp+0x60], xmm6
00007fdcd91d944c  vmovaps [rsp+0x70], xmm7
00007fdcd91d9452  vmovaps [rsp+0x80], xmm8
00007fdcd91d945b  vmovaps [rsp+0x90], xmm9
00007fdcd91d9464  vmovaps [rsp+0xA0], xmm11
00007fdcd91d946d  vmovaps [rsp+0xB0], xmm12
00007fdcd91d9476  vmovaps [rsp+0xC0], xmm13
00007fdcd91d947f  vmovaps [rsp+0xD0], xmm14
00007fdcd91d9488  vmovaps [rsp+0xE0], xmm15
00007fdcd91d9491  sub rsp, 0x30
00007fdcd91d9495  movaps [rsp], xmm10
00007fdcd91d949a  movaps [rsp+0x10], xmm8
00007fdcd91d94a0  movaps [rsp+0x20], xmm14
00007fdcd91d94a6  lea rdi, [rsp]
00007fdcd91d94aa  mov esi, 0x00
00007fdcd91d94af  mov rax, 0x5B56EFBF3530
00007fdcd91d94b9  call rax
00007fdcd91d94bb  movaps xmm10, [rsp]
00007fdcd91d94c0  add rsp, 0x30
00007fdcd91d94c4  vmovaps xmm0, [rsp]
00007fdcd91d94c9  vmovaps xmm1, [rsp+0x10]
00007fdcd91d94cf  vmovaps xmm2, [rsp+0x20]
00007fdcd91d94d5  vmovaps xmm3, [rsp+0x30]
00007fdcd91d94db  vmovaps xmm4, [rsp+0x40]
00007fdcd91d94e1  vmovaps xmm5, [rsp+0x50]
00007fdcd91d94e7  vmovaps xmm6, [rsp+0x60]
00007fdcd91d94ed  vmovaps xmm7, [rsp+0x70]
00007fdcd91d94f3  vmovaps xmm8, [rsp+0x80]
00007fdcd91d94fc  vmovaps xmm9, [rsp+0x90]
00007fdcd91d9505  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d950e  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d9517  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d9520  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d9529  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d9532  add rsp, 0xF0
00007fdcd91d9539  pop r11
00007fdcd91d953b  pop r10
00007fdcd91d953d  pop r9
00007fdcd91d953f  pop r8
00007fdcd91d9541  pop rsi
00007fdcd91d9542  pop rdi
00007fdcd91d9543  pop rdx
00007fdcd91d9544  pop rcx
00007fdcd91d9545  pop rax
00007fdcd91d9546  add rsp, 0x08
00007fdcd91d954a  jmp 0x00007FDCD91D6245
00007fdcd91d954f  sub rsp, 0x08
00007fdcd91d9553  push rax
00007fdcd91d9554  push rcx
00007fdcd91d9555  push rdx
00007fdcd91d9556  push rdi
00007fdcd91d9557  push rsi
00007fdcd91d9558  push r8
00007fdcd91d955a  push r9
00007fdcd91d955c  push r10
00007fdcd91d955e  push r11
00007fdcd91d9560  sub rsp, 0xF0
00007fdcd91d9567  vmovaps [rsp], xmm0
00007fdcd91d956c  vmovaps [rsp+0x10], xmm1
00007fdcd91d9572  vmovaps [rsp+0x20], xmm2
00007fdcd91d9578  vmovaps [rsp+0x30], xmm3
00007fdcd91d957e  vmovaps [rsp+0x40], xmm4
00007fdcd91d9584  vmovaps [rsp+0x50], xmm5
00007fdcd91d958a  vmovaps [rsp+0x60], xmm6
00007fdcd91d9590  vmovaps [rsp+0x70], xmm7
00007fdcd91d9596  vmovaps [rsp+0x80], xmm8
00007fdcd91d959f  vmovaps [rsp+0x90], xmm9
00007fdcd91d95a8  vmovaps [rsp+0xA0], xmm10
00007fdcd91d95b1  vmovaps [rsp+0xB0], xmm11
00007fdcd91d95ba  vmovaps [rsp+0xC0], xmm12
00007fdcd91d95c3  vmovaps [rsp+0xD0], xmm13
00007fdcd91d95cc  vmovaps [rsp+0xE0], xmm15
00007fdcd91d95d5  sub rsp, 0x30
00007fdcd91d95d9  movaps [rsp], xmm14
00007fdcd91d95de  movaps [rsp+0x10], xmm8
00007fdcd91d95e4  movaps [rsp+0x20], xmm4
00007fdcd91d95e9  lea rdi, [rsp]
00007fdcd91d95ed  mov esi, 0x00
00007fdcd91d95f2  mov rax, 0x5B56EFBF3530
00007fdcd91d95fc  call rax
00007fdcd91d95fe  movaps xmm14, [rsp]
00007fdcd91d9603  add rsp, 0x30
00007fdcd91d9607  vmovaps xmm0, [rsp]
00007fdcd91d960c  vmovaps xmm1, [rsp+0x10]
00007fdcd91d9612  vmovaps xmm2, [rsp+0x20]
00007fdcd91d9618  vmovaps xmm3, [rsp+0x30]
00007fdcd91d961e  vmovaps xmm4, [rsp+0x40]
00007fdcd91d9624  vmovaps xmm5, [rsp+0x50]
00007fdcd91d962a  vmovaps xmm6, [rsp+0x60]
00007fdcd91d9630  vmovaps xmm7, [rsp+0x70]
00007fdcd91d9636  vmovaps xmm8, [rsp+0x80]
00007fdcd91d963f  vmovaps xmm9, [rsp+0x90]
00007fdcd91d9648  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d9651  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d965a  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d9663  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d966c  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d9675  add rsp, 0xF0
00007fdcd91d967c  pop r11
00007fdcd91d967e  pop r10
00007fdcd91d9680  pop r9
00007fdcd91d9682  pop r8
00007fdcd91d9684  pop rsi
00007fdcd91d9685  pop rdi
00007fdcd91d9686  pop rdx
00007fdcd91d9687  pop rcx
00007fdcd91d9688  pop rax
00007fdcd91d9689  add rsp, 0x08
00007fdcd91d968d  jmp 0x00007FDCD91D6265
00007fdcd91d9692  sub rsp, 0x08
00007fdcd91d9696  push rax
00007fdcd91d9697  push rcx
00007fdcd91d9698  push rdx
00007fdcd91d9699  push rdi
00007fdcd91d969a  push rsi
00007fdcd91d969b  push r8
00007fdcd91d969d  push r9
00007fdcd91d969f  push r10
00007fdcd91d96a1  push r11
00007fdcd91d96a3  sub rsp, 0xF0
00007fdcd91d96aa  vmovaps [rsp], xmm0
00007fdcd91d96af  vmovaps [rsp+0x10], xmm1
00007fdcd91d96b5  vmovaps [rsp+0x20], xmm2
00007fdcd91d96bb  vmovaps [rsp+0x30], xmm3
00007fdcd91d96c1  vmovaps [rsp+0x40], xmm5
00007fdcd91d96c7  vmovaps [rsp+0x50], xmm6
00007fdcd91d96cd  vmovaps [rsp+0x60], xmm7
00007fdcd91d96d3  vmovaps [rsp+0x70], xmm8
00007fdcd91d96d9  vmovaps [rsp+0x80], xmm9
00007fdcd91d96e2  vmovaps [rsp+0x90], xmm10
00007fdcd91d96eb  vmovaps [rsp+0xA0], xmm11
00007fdcd91d96f4  vmovaps [rsp+0xB0], xmm12
00007fdcd91d96fd  vmovaps [rsp+0xC0], xmm13
00007fdcd91d9706  vmovaps [rsp+0xD0], xmm14
00007fdcd91d970f  vmovaps [rsp+0xE0], xmm15
00007fdcd91d9718  sub rsp, 0x30
00007fdcd91d971c  movaps [rsp], xmm4
00007fdcd91d9720  movaps [rsp+0x10], xmm13
00007fdcd91d9726  movaps [rsp+0x20], xmm8
00007fdcd91d972c  lea rdi, [rsp]
00007fdcd91d9730  mov esi, 0x00
00007fdcd91d9735  mov rax, 0x5B56EFBF3530
00007fdcd91d973f  call rax
00007fdcd91d9741  movaps xmm4, [rsp]
00007fdcd91d9745  add rsp, 0x30
00007fdcd91d9749  vmovaps xmm0, [rsp]
00007fdcd91d974e  vmovaps xmm1, [rsp+0x10]
00007fdcd91d9754  vmovaps xmm2, [rsp+0x20]
00007fdcd91d975a  vmovaps xmm3, [rsp+0x30]
00007fdcd91d9760  vmovaps xmm5, [rsp+0x40]
00007fdcd91d9766  vmovaps xmm6, [rsp+0x50]
00007fdcd91d976c  vmovaps xmm7, [rsp+0x60]
00007fdcd91d9772  vmovaps xmm8, [rsp+0x70]
00007fdcd91d9778  vmovaps xmm9, [rsp+0x80]
00007fdcd91d9781  vmovaps xmm10, [rsp+0x90]
00007fdcd91d978a  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d9793  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d979c  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d97a5  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d97ae  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d97b7  add rsp, 0xF0
00007fdcd91d97be  pop r11
00007fdcd91d97c0  pop r10
00007fdcd91d97c2  pop r9
00007fdcd91d97c4  pop r8
00007fdcd91d97c6  pop rsi
00007fdcd91d97c7  pop rdi
00007fdcd91d97c8  pop rdx
00007fdcd91d97c9  pop rcx
00007fdcd91d97ca  pop rax
00007fdcd91d97cb  add rsp, 0x08
00007fdcd91d97cf  jmp 0x00007FDCD91D628A
00007fdcd91d97d4  sub rsp, 0x08
00007fdcd91d97d8  push rax
00007fdcd91d97d9  push rcx
00007fdcd91d97da  push rdx
00007fdcd91d97db  push rdi
00007fdcd91d97dc  push rsi
00007fdcd91d97dd  push r8
00007fdcd91d97df  push r9
00007fdcd91d97e1  push r10
00007fdcd91d97e3  push r11
00007fdcd91d97e5  sub rsp, 0xF0
00007fdcd91d97ec  vmovaps [rsp], xmm0
00007fdcd91d97f1  vmovaps [rsp+0x10], xmm1
00007fdcd91d97f7  vmovaps [rsp+0x20], xmm2
00007fdcd91d97fd  vmovaps [rsp+0x30], xmm3
00007fdcd91d9803  vmovaps [rsp+0x40], xmm4
00007fdcd91d9809  vmovaps [rsp+0x50], xmm5
00007fdcd91d980f  vmovaps [rsp+0x60], xmm6
00007fdcd91d9815  vmovaps [rsp+0x70], xmm7
00007fdcd91d981b  vmovaps [rsp+0x80], xmm8
00007fdcd91d9824  vmovaps [rsp+0x90], xmm9
00007fdcd91d982d  vmovaps [rsp+0xA0], xmm10
00007fdcd91d9836  vmovaps [rsp+0xB0], xmm11
00007fdcd91d983f  vmovaps [rsp+0xC0], xmm12
00007fdcd91d9848  vmovaps [rsp+0xD0], xmm14
00007fdcd91d9851  vmovaps [rsp+0xE0], xmm15
00007fdcd91d985a  sub rsp, 0x30
00007fdcd91d985e  movaps [rsp], xmm13
00007fdcd91d9863  movaps [rsp+0x10], xmm15
00007fdcd91d9869  movaps [rsp+0x20], xmm9
00007fdcd91d986f  lea rdi, [rsp]
00007fdcd91d9873  mov esi, 0x00
00007fdcd91d9878  mov rax, 0x5B56EFBF3530
00007fdcd91d9882  call rax
00007fdcd91d9884  movaps xmm13, [rsp]
00007fdcd91d9889  add rsp, 0x30
00007fdcd91d988d  vmovaps xmm0, [rsp]
00007fdcd91d9892  vmovaps xmm1, [rsp+0x10]
00007fdcd91d9898  vmovaps xmm2, [rsp+0x20]
00007fdcd91d989e  vmovaps xmm3, [rsp+0x30]
00007fdcd91d98a4  vmovaps xmm4, [rsp+0x40]
00007fdcd91d98aa  vmovaps xmm5, [rsp+0x50]
00007fdcd91d98b0  vmovaps xmm6, [rsp+0x60]
00007fdcd91d98b6  vmovaps xmm7, [rsp+0x70]
00007fdcd91d98bc  vmovaps xmm8, [rsp+0x80]
00007fdcd91d98c5  vmovaps xmm9, [rsp+0x90]
00007fdcd91d98ce  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d98d7  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d98e0  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d98e9  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d98f2  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d98fb  add rsp, 0xF0
00007fdcd91d9902  pop r11
00007fdcd91d9904  pop r10
00007fdcd91d9906  pop r9
00007fdcd91d9908  pop r8
00007fdcd91d990a  pop rsi
00007fdcd91d990b  pop rdi
00007fdcd91d990c  pop rdx
00007fdcd91d990d  pop rcx
00007fdcd91d990e  pop rax
00007fdcd91d990f  add rsp, 0x08
00007fdcd91d9913  jmp 0x00007FDCD91D62A5
00007fdcd91d9918  sub rsp, 0x08
00007fdcd91d991c  push rax
00007fdcd91d991d  push rcx
00007fdcd91d991e  push rdx
00007fdcd91d991f  push rdi
00007fdcd91d9920  push rsi
00007fdcd91d9921  push r8
00007fdcd91d9923  push r9
00007fdcd91d9925  push r10
00007fdcd91d9927  push r11
00007fdcd91d9929  sub rsp, 0xF0
00007fdcd91d9930  vmovaps [rsp], xmm0
00007fdcd91d9935  vmovaps [rsp+0x10], xmm1
00007fdcd91d993b  vmovaps [rsp+0x20], xmm2
00007fdcd91d9941  vmovaps [rsp+0x30], xmm3
00007fdcd91d9947  vmovaps [rsp+0x40], xmm4
00007fdcd91d994d  vmovaps [rsp+0x50], xmm5
00007fdcd91d9953  vmovaps [rsp+0x60], xmm6
00007fdcd91d9959  vmovaps [rsp+0x70], xmm7
00007fdcd91d995f  vmovaps [rsp+0x80], xmm8
00007fdcd91d9968  vmovaps [rsp+0x90], xmm9
00007fdcd91d9971  vmovaps [rsp+0xA0], xmm10
00007fdcd91d997a  vmovaps [rsp+0xB0], xmm11
00007fdcd91d9983  vmovaps [rsp+0xC0], xmm12
00007fdcd91d998c  vmovaps [rsp+0xD0], xmm13
00007fdcd91d9995  vmovaps [rsp+0xE0], xmm14
00007fdcd91d999e  sub rsp, 0x30
00007fdcd91d99a2  movaps [rsp], xmm15
00007fdcd91d99a7  movaps [rsp+0x10], xmm1
00007fdcd91d99ac  movaps [rsp+0x20], xmm5
00007fdcd91d99b1  lea rdi, [rsp]
00007fdcd91d99b5  mov esi, 0x00
00007fdcd91d99ba  mov rax, 0x5B56EFBF3530
00007fdcd91d99c4  call rax
00007fdcd91d99c6  movaps xmm15, [rsp]
00007fdcd91d99cb  add rsp, 0x30
00007fdcd91d99cf  vmovaps xmm0, [rsp]
00007fdcd91d99d4  vmovaps xmm1, [rsp+0x10]
00007fdcd91d99da  vmovaps xmm2, [rsp+0x20]
00007fdcd91d99e0  vmovaps xmm3, [rsp+0x30]
00007fdcd91d99e6  vmovaps xmm4, [rsp+0x40]
00007fdcd91d99ec  vmovaps xmm5, [rsp+0x50]
00007fdcd91d99f2  vmovaps xmm6, [rsp+0x60]
00007fdcd91d99f8  vmovaps xmm7, [rsp+0x70]
00007fdcd91d99fe  vmovaps xmm8, [rsp+0x80]
00007fdcd91d9a07  vmovaps xmm9, [rsp+0x90]
00007fdcd91d9a10  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d9a19  vmovaps xmm11, [rsp+0xB0]
00007fdcd91d9a22  vmovaps xmm12, [rsp+0xC0]
00007fdcd91d9a2b  vmovaps xmm13, [rsp+0xD0]
00007fdcd91d9a34  vmovaps xmm14, [rsp+0xE0]
00007fdcd91d9a3d  add rsp, 0xF0
00007fdcd91d9a44  pop r11
00007fdcd91d9a46  pop r10
00007fdcd91d9a48  pop r9
00007fdcd91d9a4a  pop r8
00007fdcd91d9a4c  pop rsi
00007fdcd91d9a4d  pop rdi
00007fdcd91d9a4e  pop rdx
00007fdcd91d9a4f  pop rcx
00007fdcd91d9a50  pop rax
00007fdcd91d9a51  add rsp, 0x08
00007fdcd91d9a55  jmp 0x00007FDCD91D62C0
00007fdcd91d9a5a  call 0x00007FDCD90D64F0
00007fdcd91d9a5f  jmp 0x00007FDCD91D631B
00007fdcd91d9a64  sub rsp, 0x08
00007fdcd91d9a68  push rax
00007fdcd91d9a69  push rcx
00007fdcd91d9a6a  push rdx
00007fdcd91d9a6b  push rdi
00007fdcd91d9a6c  push rsi
00007fdcd91d9a6d  push r8
00007fdcd91d9a6f  push r9
00007fdcd91d9a71  push r10
00007fdcd91d9a73  push r11
00007fdcd91d9a75  sub rsp, 0xF0
00007fdcd91d9a7c  vmovaps [rsp], xmm0
00007fdcd91d9a81  vmovaps [rsp+0x10], xmm1
00007fdcd91d9a87  vmovaps [rsp+0x20], xmm2
00007fdcd91d9a8d  vmovaps [rsp+0x30], xmm3
00007fdcd91d9a93  vmovaps [rsp+0x40], xmm4
00007fdcd91d9a99  vmovaps [rsp+0x50], xmm5
00007fdcd91d9a9f  vmovaps [rsp+0x60], xmm6
00007fdcd91d9aa5  vmovaps [rsp+0x70], xmm7
00007fdcd91d9aab  vmovaps [rsp+0x80], xmm8
00007fdcd91d9ab4  vmovaps [rsp+0x90], xmm10
00007fdcd91d9abd  vmovaps [rsp+0xA0], xmm11
00007fdcd91d9ac6  vmovaps [rsp+0xB0], xmm12
00007fdcd91d9acf  vmovaps [rsp+0xC0], xmm13
00007fdcd91d9ad8  vmovaps [rsp+0xD0], xmm14
00007fdcd91d9ae1  vmovaps [rsp+0xE0], xmm15
00007fdcd91d9aea  sub rsp, 0x30
00007fdcd91d9aee  movaps [rsp], xmm9
00007fdcd91d9af3  movaps [rsp+0x10], xmm8
00007fdcd91d9af9  movaps [rsp+0x20], xmm11
00007fdcd91d9aff  lea rdi, [rsp]
00007fdcd91d9b03  mov esi, 0x00
00007fdcd91d9b08  mov rax, 0x5B56EFBF3530
00007fdcd91d9b12  call rax
00007fdcd91d9b14  movaps xmm9, [rsp]
00007fdcd91d9b19  add rsp, 0x30
00007fdcd91d9b1d  vmovaps xmm0, [rsp]
00007fdcd91d9b22  vmovaps xmm1, [rsp+0x10]
00007fdcd91d9b28  vmovaps xmm2, [rsp+0x20]
00007fdcd91d9b2e  vmovaps xmm3, [rsp+0x30]
00007fdcd91d9b34  vmovaps xmm4, [rsp+0x40]
00007fdcd91d9b3a  vmovaps xmm5, [rsp+0x50]
00007fdcd91d9b40  vmovaps xmm6, [rsp+0x60]
00007fdcd91d9b46  vmovaps xmm7, [rsp+0x70]
00007fdcd91d9b4c  vmovaps xmm8, [rsp+0x80]
00007fdcd91d9b55  vmovaps xmm10, [rsp+0x90]
00007fdcd91d9b5e  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d9b67  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d9b70  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d9b79  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d9b82  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d9b8b  add rsp, 0xF0
00007fdcd91d9b92  pop r11
00007fdcd91d9b94  pop r10
00007fdcd91d9b96  pop r9
00007fdcd91d9b98  pop r8
00007fdcd91d9b9a  pop rsi
00007fdcd91d9b9b  pop rdi
00007fdcd91d9b9c  pop rdx
00007fdcd91d9b9d  pop rcx
00007fdcd91d9b9e  pop rax
00007fdcd91d9b9f  add rsp, 0x08
00007fdcd91d9ba3  jmp 0x00007FDCD91D6352
00007fdcd91d9ba8  sub rsp, 0x08
00007fdcd91d9bac  push rax
00007fdcd91d9bad  push rcx
00007fdcd91d9bae  push rdx
00007fdcd91d9baf  push rdi
00007fdcd91d9bb0  push rsi
00007fdcd91d9bb1  push r8
00007fdcd91d9bb3  push r9
00007fdcd91d9bb5  push r10
00007fdcd91d9bb7  push r11
00007fdcd91d9bb9  sub rsp, 0xF0
00007fdcd91d9bc0  vmovaps [rsp], xmm0
00007fdcd91d9bc5  vmovaps [rsp+0x10], xmm1
00007fdcd91d9bcb  vmovaps [rsp+0x20], xmm2
00007fdcd91d9bd1  vmovaps [rsp+0x30], xmm3
00007fdcd91d9bd7  vmovaps [rsp+0x40], xmm4
00007fdcd91d9bdd  vmovaps [rsp+0x50], xmm5
00007fdcd91d9be3  vmovaps [rsp+0x60], xmm6
00007fdcd91d9be9  vmovaps [rsp+0x70], xmm7
00007fdcd91d9bef  vmovaps [rsp+0x80], xmm8
00007fdcd91d9bf8  vmovaps [rsp+0x90], xmm9
00007fdcd91d9c01  vmovaps [rsp+0xA0], xmm10
00007fdcd91d9c0a  vmovaps [rsp+0xB0], xmm12
00007fdcd91d9c13  vmovaps [rsp+0xC0], xmm13
00007fdcd91d9c1c  vmovaps [rsp+0xD0], xmm14
00007fdcd91d9c25  vmovaps [rsp+0xE0], xmm15
00007fdcd91d9c2e  sub rsp, 0x30
00007fdcd91d9c32  movaps [rsp], xmm11
00007fdcd91d9c37  movaps [rsp+0x10], xmm10
00007fdcd91d9c3d  movaps [rsp+0x20], xmm6
00007fdcd91d9c42  lea rdi, [rsp]
00007fdcd91d9c46  mov esi, 0x00
00007fdcd91d9c4b  mov rax, 0x5B56EFBF3530
00007fdcd91d9c55  call rax
00007fdcd91d9c57  movaps xmm11, [rsp]
00007fdcd91d9c5c  add rsp, 0x30
00007fdcd91d9c60  vmovaps xmm0, [rsp]
00007fdcd91d9c65  vmovaps xmm1, [rsp+0x10]
00007fdcd91d9c6b  vmovaps xmm2, [rsp+0x20]
00007fdcd91d9c71  vmovaps xmm3, [rsp+0x30]
00007fdcd91d9c77  vmovaps xmm4, [rsp+0x40]
00007fdcd91d9c7d  vmovaps xmm5, [rsp+0x50]
00007fdcd91d9c83  vmovaps xmm6, [rsp+0x60]
00007fdcd91d9c89  vmovaps xmm7, [rsp+0x70]
00007fdcd91d9c8f  vmovaps xmm8, [rsp+0x80]
00007fdcd91d9c98  vmovaps xmm9, [rsp+0x90]
00007fdcd91d9ca1  vmovaps xmm10, [rsp+0xA0]
00007fdcd91d9caa  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d9cb3  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d9cbc  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d9cc5  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d9cce  add rsp, 0xF0
00007fdcd91d9cd5  pop r11
00007fdcd91d9cd7  pop r10
00007fdcd91d9cd9  pop r9
00007fdcd91d9cdb  pop r8
00007fdcd91d9cdd  pop rsi
00007fdcd91d9cde  pop rdi
00007fdcd91d9cdf  pop rdx
00007fdcd91d9ce0  pop rcx
00007fdcd91d9ce1  pop rax
00007fdcd91d9ce2  add rsp, 0x08
00007fdcd91d9ce6  jmp 0x00007FDCD91D636D
00007fdcd91d9ceb  sub rsp, 0x08
00007fdcd91d9cef  push rax
00007fdcd91d9cf0  push rcx
00007fdcd91d9cf1  push rdx
00007fdcd91d9cf2  push rdi
00007fdcd91d9cf3  push rsi
00007fdcd91d9cf4  push r8
00007fdcd91d9cf6  push r9
00007fdcd91d9cf8  push r10
00007fdcd91d9cfa  push r11
00007fdcd91d9cfc  sub rsp, 0xF0
00007fdcd91d9d03  vmovaps [rsp], xmm0
00007fdcd91d9d08  vmovaps [rsp+0x10], xmm1
00007fdcd91d9d0e  vmovaps [rsp+0x20], xmm2
00007fdcd91d9d14  vmovaps [rsp+0x30], xmm3
00007fdcd91d9d1a  vmovaps [rsp+0x40], xmm4
00007fdcd91d9d20  vmovaps [rsp+0x50], xmm5
00007fdcd91d9d26  vmovaps [rsp+0x60], xmm6
00007fdcd91d9d2c  vmovaps [rsp+0x70], xmm7
00007fdcd91d9d32  vmovaps [rsp+0x80], xmm8
00007fdcd91d9d3b  vmovaps [rsp+0x90], xmm9
00007fdcd91d9d44  vmovaps [rsp+0xA0], xmm11
00007fdcd91d9d4d  vmovaps [rsp+0xB0], xmm12
00007fdcd91d9d56  vmovaps [rsp+0xC0], xmm13
00007fdcd91d9d5f  vmovaps [rsp+0xD0], xmm14
00007fdcd91d9d68  vmovaps [rsp+0xE0], xmm15
00007fdcd91d9d71  sub rsp, 0x30
00007fdcd91d9d75  movaps [rsp], xmm10
00007fdcd91d9d7a  movaps [rsp+0x10], xmm14
00007fdcd91d9d80  movaps [rsp+0x20], xmm4
00007fdcd91d9d85  lea rdi, [rsp]
00007fdcd91d9d89  mov esi, 0x00
00007fdcd91d9d8e  mov rax, 0x5B56EFBF3530
00007fdcd91d9d98  call rax
00007fdcd91d9d9a  movaps xmm10, [rsp]
00007fdcd91d9d9f  add rsp, 0x30
00007fdcd91d9da3  vmovaps xmm0, [rsp]
00007fdcd91d9da8  vmovaps xmm1, [rsp+0x10]
00007fdcd91d9dae  vmovaps xmm2, [rsp+0x20]
00007fdcd91d9db4  vmovaps xmm3, [rsp+0x30]
00007fdcd91d9dba  vmovaps xmm4, [rsp+0x40]
00007fdcd91d9dc0  vmovaps xmm5, [rsp+0x50]
00007fdcd91d9dc6  vmovaps xmm6, [rsp+0x60]
00007fdcd91d9dcc  vmovaps xmm7, [rsp+0x70]
00007fdcd91d9dd2  vmovaps xmm8, [rsp+0x80]
00007fdcd91d9ddb  vmovaps xmm9, [rsp+0x90]
00007fdcd91d9de4  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d9ded  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d9df6  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d9dff  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d9e08  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d9e11  add rsp, 0xF0
00007fdcd91d9e18  pop r11
00007fdcd91d9e1a  pop r10
00007fdcd91d9e1c  pop r9
00007fdcd91d9e1e  pop r8
00007fdcd91d9e20  pop rsi
00007fdcd91d9e21  pop rdi
00007fdcd91d9e22  pop rdx
00007fdcd91d9e23  pop rcx
00007fdcd91d9e24  pop rax
00007fdcd91d9e25  add rsp, 0x08
00007fdcd91d9e29  jmp 0x00007FDCD91D6388
00007fdcd91d9e2e  sub rsp, 0x08
00007fdcd91d9e32  push rax
00007fdcd91d9e33  push rcx
00007fdcd91d9e34  push rdx
00007fdcd91d9e35  push rdi
00007fdcd91d9e36  push rsi
00007fdcd91d9e37  push r8
00007fdcd91d9e39  push r9
00007fdcd91d9e3b  push r10
00007fdcd91d9e3d  push r11
00007fdcd91d9e3f  sub rsp, 0xF0
00007fdcd91d9e46  vmovaps [rsp], xmm0
00007fdcd91d9e4b  vmovaps [rsp+0x10], xmm1
00007fdcd91d9e51  vmovaps [rsp+0x20], xmm2
00007fdcd91d9e57  vmovaps [rsp+0x30], xmm3
00007fdcd91d9e5d  vmovaps [rsp+0x40], xmm4
00007fdcd91d9e63  vmovaps [rsp+0x50], xmm5
00007fdcd91d9e69  vmovaps [rsp+0x60], xmm6
00007fdcd91d9e6f  vmovaps [rsp+0x70], xmm7
00007fdcd91d9e75  vmovaps [rsp+0x80], xmm9
00007fdcd91d9e7e  vmovaps [rsp+0x90], xmm10
00007fdcd91d9e87  vmovaps [rsp+0xA0], xmm11
00007fdcd91d9e90  vmovaps [rsp+0xB0], xmm12
00007fdcd91d9e99  vmovaps [rsp+0xC0], xmm13
00007fdcd91d9ea2  vmovaps [rsp+0xD0], xmm14
00007fdcd91d9eab  vmovaps [rsp+0xE0], xmm15
00007fdcd91d9eb4  sub rsp, 0x30
00007fdcd91d9eb8  movaps [rsp], xmm8
00007fdcd91d9ebd  movaps [rsp+0x10], xmm1
00007fdcd91d9ec2  movaps [rsp+0x20], xmm14
00007fdcd91d9ec8  lea rdi, [rsp]
00007fdcd91d9ecc  mov esi, 0x00
00007fdcd91d9ed1  mov rax, 0x5B56EFBF3530
00007fdcd91d9edb  call rax
00007fdcd91d9edd  movaps xmm8, [rsp]
00007fdcd91d9ee2  add rsp, 0x30
00007fdcd91d9ee6  vmovaps xmm0, [rsp]
00007fdcd91d9eeb  vmovaps xmm1, [rsp+0x10]
00007fdcd91d9ef1  vmovaps xmm2, [rsp+0x20]
00007fdcd91d9ef7  vmovaps xmm3, [rsp+0x30]
00007fdcd91d9efd  vmovaps xmm4, [rsp+0x40]
00007fdcd91d9f03  vmovaps xmm5, [rsp+0x50]
00007fdcd91d9f09  vmovaps xmm6, [rsp+0x60]
00007fdcd91d9f0f  vmovaps xmm7, [rsp+0x70]
00007fdcd91d9f15  vmovaps xmm9, [rsp+0x80]
00007fdcd91d9f1e  vmovaps xmm10, [rsp+0x90]
00007fdcd91d9f27  vmovaps xmm11, [rsp+0xA0]
00007fdcd91d9f30  vmovaps xmm12, [rsp+0xB0]
00007fdcd91d9f39  vmovaps xmm13, [rsp+0xC0]
00007fdcd91d9f42  vmovaps xmm14, [rsp+0xD0]
00007fdcd91d9f4b  vmovaps xmm15, [rsp+0xE0]
00007fdcd91d9f54  add rsp, 0xF0
00007fdcd91d9f5b  pop r11
00007fdcd91d9f5d  pop r10
00007fdcd91d9f5f  pop r9
00007fdcd91d9f61  pop r8
00007fdcd91d9f63  pop rsi
00007fdcd91d9f64  pop rdi
00007fdcd91d9f65  pop rdx
00007fdcd91d9f66  pop rcx
00007fdcd91d9f67  pop rax
00007fdcd91d9f68  add rsp, 0x08
00007fdcd91d9f6c  jmp 0x00007FDCD91D63AE
00007fdcd91d9f71  sub rsp, 0x08
00007fdcd91d9f75  push rax
00007fdcd91d9f76  push rcx
00007fdcd91d9f77  push rdx
00007fdcd91d9f78  push rdi
00007fdcd91d9f79  push rsi
00007fdcd91d9f7a  push r8
00007fdcd91d9f7c  push r9
00007fdcd91d9f7e  push r10
00007fdcd91d9f80  push r11
00007fdcd91d9f82  sub rsp, 0xF0
00007fdcd91d9f89  vmovaps [rsp], xmm0
00007fdcd91d9f8e  vmovaps [rsp+0x10], xmm1
00007fdcd91d9f94  vmovaps [rsp+0x20], xmm2
00007fdcd91d9f9a  vmovaps [rsp+0x30], xmm3
00007fdcd91d9fa0  vmovaps [rsp+0x40], xmm4
00007fdcd91d9fa6  vmovaps [rsp+0x50], xmm5
00007fdcd91d9fac  vmovaps [rsp+0x60], xmm7
00007fdcd91d9fb2  vmovaps [rsp+0x70], xmm8
00007fdcd91d9fb8  vmovaps [rsp+0x80], xmm9
00007fdcd91d9fc1  vmovaps [rsp+0x90], xmm10
00007fdcd91d9fca  vmovaps [rsp+0xA0], xmm11
00007fdcd91d9fd3  vmovaps [rsp+0xB0], xmm12
00007fdcd91d9fdc  vmovaps [rsp+0xC0], xmm13
00007fdcd91d9fe5  vmovaps [rsp+0xD0], xmm14
00007fdcd91d9fee  vmovaps [rsp+0xE0], xmm15
00007fdcd91d9ff7  sub rsp, 0x30
00007fdcd91d9ffb  movaps [rsp], xmm6
00007fdcd91d9fff  movaps [rsp+0x10], xmm1
00007fdcd91da004  movaps [rsp+0x20], xmm14
00007fdcd91da00a  lea rdi, [rsp]
00007fdcd91da00e  mov esi, 0x00
00007fdcd91da013  mov rax, 0x5B56EFBF3530
00007fdcd91da01d  call rax
00007fdcd91da01f  movaps xmm6, [rsp]
00007fdcd91da023  add rsp, 0x30
00007fdcd91da027  vmovaps xmm0, [rsp]
00007fdcd91da02c  vmovaps xmm1, [rsp+0x10]
00007fdcd91da032  vmovaps xmm2, [rsp+0x20]
00007fdcd91da038  vmovaps xmm3, [rsp+0x30]
00007fdcd91da03e  vmovaps xmm4, [rsp+0x40]
00007fdcd91da044  vmovaps xmm5, [rsp+0x50]
00007fdcd91da04a  vmovaps xmm7, [rsp+0x60]
00007fdcd91da050  vmovaps xmm8, [rsp+0x70]
00007fdcd91da056  vmovaps xmm9, [rsp+0x80]
00007fdcd91da05f  vmovaps xmm10, [rsp+0x90]
00007fdcd91da068  vmovaps xmm11, [rsp+0xA0]
00007fdcd91da071  vmovaps xmm12, [rsp+0xB0]
00007fdcd91da07a  vmovaps xmm13, [rsp+0xC0]
00007fdcd91da083  vmovaps xmm14, [rsp+0xD0]
00007fdcd91da08c  vmovaps xmm15, [rsp+0xE0]
00007fdcd91da095  add rsp, 0xF0
00007fdcd91da09c  pop r11
00007fdcd91da09e  pop r10
00007fdcd91da0a0  pop r9
00007fdcd91da0a2  pop r8
00007fdcd91da0a4  pop rsi
00007fdcd91da0a5  pop rdi
00007fdcd91da0a6  pop rdx
00007fdcd91da0a7  pop rcx
00007fdcd91da0a8  pop rax
00007fdcd91da0a9  add rsp, 0x08
00007fdcd91da0ad  jmp 0x00007FDCD91D63DA
00007fdcd91da0b2  sub rsp, 0x08
00007fdcd91da0b6  push rax
00007fdcd91da0b7  push rcx
00007fdcd91da0b8  push rdx
00007fdcd91da0b9  push rdi
00007fdcd91da0ba  push rsi
00007fdcd91da0bb  push r8
00007fdcd91da0bd  push r9
00007fdcd91da0bf  push r10
00007fdcd91da0c1  push r11
00007fdcd91da0c3  sub rsp, 0xF0
00007fdcd91da0ca  vmovaps [rsp], xmm0
00007fdcd91da0cf  vmovaps [rsp+0x10], xmm1
00007fdcd91da0d5  vmovaps [rsp+0x20], xmm2
00007fdcd91da0db  vmovaps [rsp+0x30], xmm3
00007fdcd91da0e1  vmovaps [rsp+0x40], xmm4
00007fdcd91da0e7  vmovaps [rsp+0x50], xmm5
00007fdcd91da0ed  vmovaps [rsp+0x60], xmm6
00007fdcd91da0f3  vmovaps [rsp+0x70], xmm7
00007fdcd91da0f9  vmovaps [rsp+0x80], xmm8
00007fdcd91da102  vmovaps [rsp+0x90], xmm9
00007fdcd91da10b  vmovaps [rsp+0xA0], xmm10
00007fdcd91da114  vmovaps [rsp+0xB0], xmm11
00007fdcd91da11d  vmovaps [rsp+0xC0], xmm12
00007fdcd91da126  vmovaps [rsp+0xD0], xmm13
00007fdcd91da12f  vmovaps [rsp+0xE0], xmm15
00007fdcd91da138  sub rsp, 0x30
00007fdcd91da13c  movaps [rsp], xmm14
00007fdcd91da141  movaps [rsp+0x10], xmm12
00007fdcd91da147  movaps [rsp+0x20], xmm1
00007fdcd91da14c  lea rdi, [rsp]
00007fdcd91da150  mov esi, 0x00
00007fdcd91da155  mov rax, 0x5B56EFBF3530
00007fdcd91da15f  call rax
00007fdcd91da161  movaps xmm14, [rsp]
00007fdcd91da166  add rsp, 0x30
00007fdcd91da16a  vmovaps xmm0, [rsp]
00007fdcd91da16f  vmovaps xmm1, [rsp+0x10]
00007fdcd91da175  vmovaps xmm2, [rsp+0x20]
00007fdcd91da17b  vmovaps xmm3, [rsp+0x30]
00007fdcd91da181  vmovaps xmm4, [rsp+0x40]
00007fdcd91da187  vmovaps xmm5, [rsp+0x50]
00007fdcd91da18d  vmovaps xmm6, [rsp+0x60]
00007fdcd91da193  vmovaps xmm7, [rsp+0x70]
00007fdcd91da199  vmovaps xmm8, [rsp+0x80]
00007fdcd91da1a2  vmovaps xmm9, [rsp+0x90]
00007fdcd91da1ab  vmovaps xmm10, [rsp+0xA0]
00007fdcd91da1b4  vmovaps xmm11, [rsp+0xB0]
00007fdcd91da1bd  vmovaps xmm12, [rsp+0xC0]
00007fdcd91da1c6  vmovaps xmm13, [rsp+0xD0]
00007fdcd91da1cf  vmovaps xmm15, [rsp+0xE0]
00007fdcd91da1d8  add rsp, 0xF0
00007fdcd91da1df  pop r11
00007fdcd91da1e1  pop r10
00007fdcd91da1e3  pop r9
00007fdcd91da1e5  pop r8
00007fdcd91da1e7  pop rsi
00007fdcd91da1e8  pop rdi
00007fdcd91da1e9  pop rdx
00007fdcd91da1ea  pop rcx
00007fdcd91da1eb  pop rax
00007fdcd91da1ec  add rsp, 0x08
00007fdcd91da1f0  jmp 0x00007FDCD91D6400
00007fdcd91da1f5  sub rsp, 0x08
00007fdcd91da1f9  push rax
00007fdcd91da1fa  push rcx
00007fdcd91da1fb  push rdx
00007fdcd91da1fc  push rdi
00007fdcd91da1fd  push rsi
00007fdcd91da1fe  push r8
00007fdcd91da200  push r9
00007fdcd91da202  push r10
00007fdcd91da204  push r11
00007fdcd91da206  sub rsp, 0xF0
00007fdcd91da20d  vmovaps [rsp], xmm0
00007fdcd91da212  vmovaps [rsp+0x10], xmm2
00007fdcd91da218  vmovaps [rsp+0x20], xmm3
00007fdcd91da21e  vmovaps [rsp+0x30], xmm4
00007fdcd91da224  vmovaps [rsp+0x40], xmm5
00007fdcd91da22a  vmovaps [rsp+0x50], xmm6
00007fdcd91da230  vmovaps [rsp+0x60], xmm7
00007fdcd91da236  vmovaps [rsp+0x70], xmm8
00007fdcd91da23c  vmovaps [rsp+0x80], xmm9
00007fdcd91da245  vmovaps [rsp+0x90], xmm10
00007fdcd91da24e  vmovaps [rsp+0xA0], xmm11
00007fdcd91da257  vmovaps [rsp+0xB0], xmm12
00007fdcd91da260  vmovaps [rsp+0xC0], xmm13
00007fdcd91da269  vmovaps [rsp+0xD0], xmm14
00007fdcd91da272  vmovaps [rsp+0xE0], xmm15
00007fdcd91da27b  sub rsp, 0x30
00007fdcd91da27f  movaps [rsp], xmm1
00007fdcd91da283  movaps [rsp+0x10], xmm13
00007fdcd91da289  movaps [rsp+0x20], xmm9
00007fdcd91da28f  lea rdi, [rsp]
00007fdcd91da293  mov esi, 0x00
00007fdcd91da298  mov rax, 0x5B56EFBF3530
00007fdcd91da2a2  call rax
00007fdcd91da2a4  movaps xmm1, [rsp]
00007fdcd91da2a8  add rsp, 0x30
00007fdcd91da2ac  vmovaps xmm0, [rsp]
00007fdcd91da2b1  vmovaps xmm2, [rsp+0x10]
00007fdcd91da2b7  vmovaps xmm3, [rsp+0x20]
00007fdcd91da2bd  vmovaps xmm4, [rsp+0x30]
00007fdcd91da2c3  vmovaps xmm5, [rsp+0x40]
00007fdcd91da2c9  vmovaps xmm6, [rsp+0x50]
00007fdcd91da2cf  vmovaps xmm7, [rsp+0x60]
00007fdcd91da2d5  vmovaps xmm8, [rsp+0x70]
00007fdcd91da2db  vmovaps xmm9, [rsp+0x80]
00007fdcd91da2e4  vmovaps xmm10, [rsp+0x90]
00007fdcd91da2ed  vmovaps xmm11, [rsp+0xA0]
00007fdcd91da2f6  vmovaps xmm12, [rsp+0xB0]
00007fdcd91da2ff  vmovaps xmm13, [rsp+0xC0]
00007fdcd91da308  vmovaps xmm14, [rsp+0xD0]
00007fdcd91da311  vmovaps xmm15, [rsp+0xE0]
00007fdcd91da31a  add rsp, 0xF0
00007fdcd91da321  pop r11
00007fdcd91da323  pop r10
00007fdcd91da325  pop r9
00007fdcd91da327  pop r8
00007fdcd91da329  pop rsi
00007fdcd91da32a  pop rdi
00007fdcd91da32b  pop rdx
00007fdcd91da32c  pop rcx
00007fdcd91da32d  pop rax
00007fdcd91da32e  add rsp, 0x08
00007fdcd91da332  jmp 0x00007FDCD91D641A
00007fdcd91da337  sub rsp, 0x08
00007fdcd91da33b  push rax
00007fdcd91da33c  push rcx
00007fdcd91da33d  push rdx
00007fdcd91da33e  push rdi
00007fdcd91da33f  push rsi
00007fdcd91da340  push r8
00007fdcd91da342  push r9
00007fdcd91da344  push r10
00007fdcd91da346  push r11
00007fdcd91da348  sub rsp, 0xF0
00007fdcd91da34f  vmovaps [rsp], xmm0
00007fdcd91da354  vmovaps [rsp+0x10], xmm1
00007fdcd91da35a  vmovaps [rsp+0x20], xmm2
00007fdcd91da360  vmovaps [rsp+0x30], xmm3
00007fdcd91da366  vmovaps [rsp+0x40], xmm4
00007fdcd91da36c  vmovaps [rsp+0x50], xmm5
00007fdcd91da372  vmovaps [rsp+0x60], xmm6
00007fdcd91da378  vmovaps [rsp+0x70], xmm7
00007fdcd91da37e  vmovaps [rsp+0x80], xmm8
00007fdcd91da387  vmovaps [rsp+0x90], xmm9
00007fdcd91da390  vmovaps [rsp+0xA0], xmm10
00007fdcd91da399  vmovaps [rsp+0xB0], xmm11
00007fdcd91da3a2  vmovaps [rsp+0xC0], xmm13
00007fdcd91da3ab  vmovaps [rsp+0xD0], xmm14
00007fdcd91da3b4  vmovaps [rsp+0xE0], xmm15
00007fdcd91da3bd  sub rsp, 0x30
00007fdcd91da3c1  movaps [rsp], xmm12
00007fdcd91da3c6  movaps [rsp+0x10], xmm7
00007fdcd91da3cb  movaps [rsp+0x20], xmm13
00007fdcd91da3d1  lea rdi, [rsp]
00007fdcd91da3d5  mov esi, 0x00
00007fdcd91da3da  mov rax, 0x5B56EFBF3530
00007fdcd91da3e4  call rax
00007fdcd91da3e6  movaps xmm12, [rsp]
00007fdcd91da3eb  add rsp, 0x30
00007fdcd91da3ef  vmovaps xmm0, [rsp]
00007fdcd91da3f4  vmovaps xmm1, [rsp+0x10]
00007fdcd91da3fa  vmovaps xmm2, [rsp+0x20]
00007fdcd91da400  vmovaps xmm3, [rsp+0x30]
00007fdcd91da406  vmovaps xmm4, [rsp+0x40]
00007fdcd91da40c  vmovaps xmm5, [rsp+0x50]
00007fdcd91da412  vmovaps xmm6, [rsp+0x60]
00007fdcd91da418  vmovaps xmm7, [rsp+0x70]
00007fdcd91da41e  vmovaps xmm8, [rsp+0x80]
00007fdcd91da427  vmovaps xmm9, [rsp+0x90]
00007fdcd91da430  vmovaps xmm10, [rsp+0xA0]
00007fdcd91da439  vmovaps xmm11, [rsp+0xB0]
00007fdcd91da442  vmovaps xmm13, [rsp+0xC0]
00007fdcd91da44b  vmovaps xmm14, [rsp+0xD0]
00007fdcd91da454  vmovaps xmm15, [rsp+0xE0]
00007fdcd91da45d  add rsp, 0xF0
00007fdcd91da464  pop r11
00007fdcd91da466  pop r10
00007fdcd91da468  pop r9
00007fdcd91da46a  pop r8
00007fdcd91da46c  pop rsi
00007fdcd91da46d  pop rdi
00007fdcd91da46e  pop rdx
00007fdcd91da46f  pop rcx
00007fdcd91da470  pop rax
00007fdcd91da471  add rsp, 0x08
00007fdcd91da475  jmp 0x00007FDCD91D6441
00007fdcd91da47a  sub rsp, 0x08
00007fdcd91da47e  push rax
00007fdcd91da47f  push rcx
00007fdcd91da480  push rdx
00007fdcd91da481  push rdi
00007fdcd91da482  push rsi
00007fdcd91da483  push r8
00007fdcd91da485  push r9
00007fdcd91da487  push r10
00007fdcd91da489  push r11
00007fdcd91da48b  sub rsp, 0xF0
00007fdcd91da492  vmovaps [rsp], xmm0
00007fdcd91da497  vmovaps [rsp+0x10], xmm1
00007fdcd91da49d  vmovaps [rsp+0x20], xmm2
00007fdcd91da4a3  vmovaps [rsp+0x30], xmm3
00007fdcd91da4a9  vmovaps [rsp+0x40], xmm4
00007fdcd91da4af  vmovaps [rsp+0x50], xmm5
00007fdcd91da4b5  vmovaps [rsp+0x60], xmm6
00007fdcd91da4bb  vmovaps [rsp+0x70], xmm7
00007fdcd91da4c1  vmovaps [rsp+0x80], xmm8
00007fdcd91da4ca  vmovaps [rsp+0x90], xmm9
00007fdcd91da4d3  vmovaps [rsp+0xA0], xmm10
00007fdcd91da4dc  vmovaps [rsp+0xB0], xmm11
00007fdcd91da4e5  vmovaps [rsp+0xC0], xmm12
00007fdcd91da4ee  vmovaps [rsp+0xD0], xmm14
00007fdcd91da4f7  vmovaps [rsp+0xE0], xmm15
00007fdcd91da500  sub rsp, 0x30
00007fdcd91da504  movaps [rsp], xmm13
00007fdcd91da509  movaps [rsp+0x10], xmm15
00007fdcd91da50f  movaps [rsp+0x20], xmm8
00007fdcd91da515  lea rdi, [rsp]
00007fdcd91da519  mov esi, 0x00
00007fdcd91da51e  mov rax, 0x5B56EFBF3530
00007fdcd91da528  call rax
00007fdcd91da52a  movaps xmm13, [rsp]
00007fdcd91da52f  add rsp, 0x30
00007fdcd91da533  vmovaps xmm0, [rsp]
00007fdcd91da538  vmovaps xmm1, [rsp+0x10]
00007fdcd91da53e  vmovaps xmm2, [rsp+0x20]
00007fdcd91da544  vmovaps xmm3, [rsp+0x30]
00007fdcd91da54a  vmovaps xmm4, [rsp+0x40]
00007fdcd91da550  vmovaps xmm5, [rsp+0x50]
00007fdcd91da556  vmovaps xmm6, [rsp+0x60]
00007fdcd91da55c  vmovaps xmm7, [rsp+0x70]
00007fdcd91da562  vmovaps xmm8, [rsp+0x80]
00007fdcd91da56b  vmovaps xmm9, [rsp+0x90]
00007fdcd91da574  vmovaps xmm10, [rsp+0xA0]
00007fdcd91da57d  vmovaps xmm11, [rsp+0xB0]
00007fdcd91da586  vmovaps xmm12, [rsp+0xC0]
00007fdcd91da58f  vmovaps xmm14, [rsp+0xD0]
00007fdcd91da598  vmovaps xmm15, [rsp+0xE0]
00007fdcd91da5a1  add rsp, 0xF0
00007fdcd91da5a8  pop r11
00007fdcd91da5aa  pop r10
00007fdcd91da5ac  pop r9
00007fdcd91da5ae  pop r8
00007fdcd91da5b0  pop rsi
00007fdcd91da5b1  pop rdi
00007fdcd91da5b2  pop rdx
00007fdcd91da5b3  pop rcx
00007fdcd91da5b4  pop rax
00007fdcd91da5b5  add rsp, 0x08
00007fdcd91da5b9  jmp 0x00007FDCD91D645C
00007fdcd91da5be  sub rsp, 0x08
00007fdcd91da5c2  push rax
00007fdcd91da5c3  push rcx
00007fdcd91da5c4  push rdx
00007fdcd91da5c5  push rdi
00007fdcd91da5c6  push rsi
00007fdcd91da5c7  push r8
00007fdcd91da5c9  push r9
00007fdcd91da5cb  push r10
00007fdcd91da5cd  push r11
00007fdcd91da5cf  sub rsp, 0xF0
00007fdcd91da5d6  vmovaps [rsp], xmm0
00007fdcd91da5db  vmovaps [rsp+0x10], xmm1
00007fdcd91da5e1  vmovaps [rsp+0x20], xmm2
00007fdcd91da5e7  vmovaps [rsp+0x30], xmm3
00007fdcd91da5ed  vmovaps [rsp+0x40], xmm4
00007fdcd91da5f3  vmovaps [rsp+0x50], xmm5
00007fdcd91da5f9  vmovaps [rsp+0x60], xmm6
00007fdcd91da5ff  vmovaps [rsp+0x70], xmm7
00007fdcd91da605  vmovaps [rsp+0x80], xmm9
00007fdcd91da60e  vmovaps [rsp+0x90], xmm10
00007fdcd91da617  vmovaps [rsp+0xA0], xmm11
00007fdcd91da620  vmovaps [rsp+0xB0], xmm12
00007fdcd91da629  vmovaps [rsp+0xC0], xmm13
00007fdcd91da632  vmovaps [rsp+0xD0], xmm14
00007fdcd91da63b  vmovaps [rsp+0xE0], xmm15
00007fdcd91da644  sub rsp, 0x30
00007fdcd91da648  movaps [rsp], xmm8
00007fdcd91da64d  movaps [rsp+0x10], xmm15
00007fdcd91da653  movaps [rsp+0x20], xmm9
00007fdcd91da659  lea rdi, [rsp]
00007fdcd91da65d  mov esi, 0x00
00007fdcd91da662  mov rax, 0x5B56EFBF3530
00007fdcd91da66c  call rax
00007fdcd91da66e  movaps xmm8, [rsp]
00007fdcd91da673  add rsp, 0x30
00007fdcd91da677  vmovaps xmm0, [rsp]
00007fdcd91da67c  vmovaps xmm1, [rsp+0x10]
00007fdcd91da682  vmovaps xmm2, [rsp+0x20]
00007fdcd91da688  vmovaps xmm3, [rsp+0x30]
00007fdcd91da68e  vmovaps xmm4, [rsp+0x40]
00007fdcd91da694  vmovaps xmm5, [rsp+0x50]
00007fdcd91da69a  vmovaps xmm6, [rsp+0x60]
00007fdcd91da6a0  vmovaps xmm7, [rsp+0x70]
00007fdcd91da6a6  vmovaps xmm9, [rsp+0x80]
00007fdcd91da6af  vmovaps xmm10, [rsp+0x90]
00007fdcd91da6b8  vmovaps xmm11, [rsp+0xA0]
00007fdcd91da6c1  vmovaps xmm12, [rsp+0xB0]
00007fdcd91da6ca  vmovaps xmm13, [rsp+0xC0]
00007fdcd91da6d3  vmovaps xmm14, [rsp+0xD0]
00007fdcd91da6dc  vmovaps xmm15, [rsp+0xE0]
00007fdcd91da6e5  add rsp, 0xF0
00007fdcd91da6ec  pop r11
00007fdcd91da6ee  pop r10
00007fdcd91da6f0  pop r9
00007fdcd91da6f2  pop r8
00007fdcd91da6f4  pop rsi
00007fdcd91da6f5  pop rdi
00007fdcd91da6f6  pop rdx
00007fdcd91da6f7  pop rcx
00007fdcd91da6f8  pop rax
00007fdcd91da6f9  add rsp, 0x08
00007fdcd91da6fd  jmp 0x00007FDCD91D648A
00007fdcd91da702  sub rsp, 0x08
00007fdcd91da706  push rax
00007fdcd91da707  push rcx
00007fdcd91da708  push rdx
00007fdcd91da709  push rdi
00007fdcd91da70a  push rsi
00007fdcd91da70b  push r8
00007fdcd91da70d  push r9
00007fdcd91da70f  push r10
00007fdcd91da711  push r11
00007fdcd91da713  sub rsp, 0xF0
00007fdcd91da71a  vmovaps [rsp], xmm0
00007fdcd91da71f  vmovaps [rsp+0x10], xmm1
00007fdcd91da725  vmovaps [rsp+0x20], xmm2
00007fdcd91da72b  vmovaps [rsp+0x30], xmm3
00007fdcd91da731  vmovaps [rsp+0x40], xmm4
00007fdcd91da737  vmovaps [rsp+0x50], xmm5
00007fdcd91da73d  vmovaps [rsp+0x60], xmm6
00007fdcd91da743  vmovaps [rsp+0x70], xmm7
00007fdcd91da749  vmovaps [rsp+0x80], xmm8
00007fdcd91da752  vmovaps [rsp+0x90], xmm9
00007fdcd91da75b  vmovaps [rsp+0xA0], xmm10
00007fdcd91da764  vmovaps [rsp+0xB0], xmm11
00007fdcd91da76d  vmovaps [rsp+0xC0], xmm12
00007fdcd91da776  vmovaps [rsp+0xD0], xmm13
00007fdcd91da77f  vmovaps [rsp+0xE0], xmm14
00007fdcd91da788  sub rsp, 0x30
00007fdcd91da78c  movaps [rsp], xmm15
00007fdcd91da791  movaps [rsp+0x10], xmm11
00007fdcd91da797  movaps [rsp+0x20], xmm6
00007fdcd91da79c  lea rdi, [rsp]
00007fdcd91da7a0  mov esi, 0x00
00007fdcd91da7a5  mov rax, 0x5B56EFBF3530
00007fdcd91da7af  call rax
00007fdcd91da7b1  movaps xmm15, [rsp]
00007fdcd91da7b6  add rsp, 0x30
00007fdcd91da7ba  vmovaps xmm0, [rsp]
00007fdcd91da7bf  vmovaps xmm1, [rsp+0x10]
00007fdcd91da7c5  vmovaps xmm2, [rsp+0x20]
00007fdcd91da7cb  vmovaps xmm3, [rsp+0x30]
00007fdcd91da7d1  vmovaps xmm4, [rsp+0x40]
00007fdcd91da7d7  vmovaps xmm5, [rsp+0x50]
00007fdcd91da7dd  vmovaps xmm6, [rsp+0x60]
00007fdcd91da7e3  vmovaps xmm7, [rsp+0x70]
00007fdcd91da7e9  vmovaps xmm8, [rsp+0x80]
00007fdcd91da7f2  vmovaps xmm9, [rsp+0x90]
00007fdcd91da7fb  vmovaps xmm10, [rsp+0xA0]
00007fdcd91da804  vmovaps xmm11, [rsp+0xB0]
00007fdcd91da80d  vmovaps xmm12, [rsp+0xC0]
00007fdcd91da816  vmovaps xmm13, [rsp+0xD0]
00007fdcd91da81f  vmovaps xmm14, [rsp+0xE0]
00007fdcd91da828  add rsp, 0xF0
00007fdcd91da82f  pop r11
00007fdcd91da831  pop r10
00007fdcd91da833  pop r9
00007fdcd91da835  pop r8
00007fdcd91da837  pop rsi
00007fdcd91da838  pop rdi
00007fdcd91da839  pop rdx
00007fdcd91da83a  pop rcx
00007fdcd91da83b  pop rax
00007fdcd91da83c  add rsp, 0x08
00007fdcd91da840  jmp 0x00007FDCD91D64A5
00007fdcd91da845  sub rsp, 0x08
00007fdcd91da849  push rax
00007fdcd91da84a  push rcx
00007fdcd91da84b  push rdx
00007fdcd91da84c  push rdi
00007fdcd91da84d  push rsi
00007fdcd91da84e  push r8
00007fdcd91da850  push r9
00007fdcd91da852  push r10
00007fdcd91da854  push r11
00007fdcd91da856  sub rsp, 0xF0
00007fdcd91da85d  vmovaps [rsp], xmm0
00007fdcd91da862  vmovaps [rsp+0x10], xmm1
00007fdcd91da868  vmovaps [rsp+0x20], xmm2
00007fdcd91da86e  vmovaps [rsp+0x30], xmm3
00007fdcd91da874  vmovaps [rsp+0x40], xmm4
00007fdcd91da87a  vmovaps [rsp+0x50], xmm5
00007fdcd91da880  vmovaps [rsp+0x60], xmm6
00007fdcd91da886  vmovaps [rsp+0x70], xmm8
00007fdcd91da88c  vmovaps [rsp+0x80], xmm9
00007fdcd91da895  vmovaps [rsp+0x90], xmm10
00007fdcd91da89e  vmovaps [rsp+0xA0], xmm11
00007fdcd91da8a7  vmovaps [rsp+0xB0], xmm12
00007fdcd91da8b0  vmovaps [rsp+0xC0], xmm13
00007fdcd91da8b9  vmovaps [rsp+0xD0], xmm14
00007fdcd91da8c2  vmovaps [rsp+0xE0], xmm15
00007fdcd91da8cb  sub rsp, 0x30
00007fdcd91da8cf  movaps [rsp], xmm7
00007fdcd91da8d3  movaps [rsp+0x10], xmm11
00007fdcd91da8d9  movaps [rsp+0x20], xmm9
00007fdcd91da8df  lea rdi, [rsp]
00007fdcd91da8e3  mov esi, 0x00
00007fdcd91da8e8  mov rax, 0x5B56EFBF3530
00007fdcd91da8f2  call rax
00007fdcd91da8f4  movaps xmm7, [rsp]
00007fdcd91da8f8  add rsp, 0x30
00007fdcd91da8fc  vmovaps xmm0, [rsp]
00007fdcd91da901  vmovaps xmm1, [rsp+0x10]
00007fdcd91da907  vmovaps xmm2, [rsp+0x20]
00007fdcd91da90d  vmovaps xmm3, [rsp+0x30]
00007fdcd91da913  vmovaps xmm4, [rsp+0x40]
00007fdcd91da919  vmovaps xmm5, [rsp+0x50]
00007fdcd91da91f  vmovaps xmm6, [rsp+0x60]
00007fdcd91da925  vmovaps xmm8, [rsp+0x70]
00007fdcd91da92b  vmovaps xmm9, [rsp+0x80]
00007fdcd91da934  vmovaps xmm10, [rsp+0x90]
00007fdcd91da93d  vmovaps xmm11, [rsp+0xA0]
00007fdcd91da946  vmovaps xmm12, [rsp+0xB0]
00007fdcd91da94f  vmovaps xmm13, [rsp+0xC0]
00007fdcd91da958  vmovaps xmm14, [rsp+0xD0]
00007fdcd91da961  vmovaps xmm15, [rsp+0xE0]
00007fdcd91da96a  add rsp, 0xF0
00007fdcd91da971  pop r11
00007fdcd91da973  pop r10
00007fdcd91da975  pop r9
00007fdcd91da977  pop r8
00007fdcd91da979  pop rsi
00007fdcd91da97a  pop rdi
00007fdcd91da97b  pop rdx
00007fdcd91da97c  pop rcx
00007fdcd91da97d  pop rax
00007fdcd91da97e  add rsp, 0x08
00007fdcd91da982  jmp 0x00007FDCD91D64D2
00007fdcd91da987  sub rsp, 0x08
00007fdcd91da98b  push rax
00007fdcd91da98c  push rcx
00007fdcd91da98d  push rdx
00007fdcd91da98e  push rdi
00007fdcd91da98f  push rsi
00007fdcd91da990  push r8
00007fdcd91da992  push r9
00007fdcd91da994  push r10
00007fdcd91da996  push r11
00007fdcd91da998  sub rsp, 0xF0
00007fdcd91da99f  vmovaps [rsp], xmm0
00007fdcd91da9a4  vmovaps [rsp+0x10], xmm1
00007fdcd91da9aa  vmovaps [rsp+0x20], xmm2
00007fdcd91da9b0  vmovaps [rsp+0x30], xmm3
00007fdcd91da9b6  vmovaps [rsp+0x40], xmm4
00007fdcd91da9bc  vmovaps [rsp+0x50], xmm5
00007fdcd91da9c2  vmovaps [rsp+0x60], xmm6
00007fdcd91da9c8  vmovaps [rsp+0x70], xmm7
00007fdcd91da9ce  vmovaps [rsp+0x80], xmm8
00007fdcd91da9d7  vmovaps [rsp+0x90], xmm9
00007fdcd91da9e0  vmovaps [rsp+0xA0], xmm10
00007fdcd91da9e9  vmovaps [rsp+0xB0], xmm12
00007fdcd91da9f2  vmovaps [rsp+0xC0], xmm13
00007fdcd91da9fb  vmovaps [rsp+0xD0], xmm14
00007fdcd91daa04  vmovaps [rsp+0xE0], xmm15
00007fdcd91daa0d  sub rsp, 0x30
00007fdcd91daa11  movaps [rsp], xmm11
00007fdcd91daa16  movaps [rsp+0x10], xmm10
00007fdcd91daa1c  movaps [rsp+0x20], xmm14
00007fdcd91daa22  lea rdi, [rsp]
00007fdcd91daa26  mov esi, 0x00
00007fdcd91daa2b  mov rax, 0x5B56EFBF3530
00007fdcd91daa35  call rax
00007fdcd91daa37  movaps xmm11, [rsp]
00007fdcd91daa3c  add rsp, 0x30
00007fdcd91daa40  vmovaps xmm0, [rsp]
00007fdcd91daa45  vmovaps xmm1, [rsp+0x10]
00007fdcd91daa4b  vmovaps xmm2, [rsp+0x20]
00007fdcd91daa51  vmovaps xmm3, [rsp+0x30]
00007fdcd91daa57  vmovaps xmm4, [rsp+0x40]
00007fdcd91daa5d  vmovaps xmm5, [rsp+0x50]
00007fdcd91daa63  vmovaps xmm6, [rsp+0x60]
00007fdcd91daa69  vmovaps xmm7, [rsp+0x70]
00007fdcd91daa6f  vmovaps xmm8, [rsp+0x80]
00007fdcd91daa78  vmovaps xmm9, [rsp+0x90]
00007fdcd91daa81  vmovaps xmm10, [rsp+0xA0]
00007fdcd91daa8a  vmovaps xmm12, [rsp+0xB0]
00007fdcd91daa93  vmovaps xmm13, [rsp+0xC0]
00007fdcd91daa9c  vmovaps xmm14, [rsp+0xD0]
00007fdcd91daaa5  vmovaps xmm15, [rsp+0xE0]
00007fdcd91daaae  add rsp, 0xF0
00007fdcd91daab5  pop r11
00007fdcd91daab7  pop r10
00007fdcd91daab9  pop r9
00007fdcd91daabb  pop r8
00007fdcd91daabd  pop rsi
00007fdcd91daabe  pop rdi
00007fdcd91daabf  pop rdx
00007fdcd91daac0  pop rcx
00007fdcd91daac1  pop rax
00007fdcd91daac2  add rsp, 0x08
00007fdcd91daac6  jmp 0x00007FDCD91D64ED
00007fdcd91daacb  call 0x00007FDCD90E45A0
00007fdcd91daad0  jmp 0x00007FDCD91D64F7
00007fdcd91daad5  sub rsp, 0x08
00007fdcd91daad9  push rax
00007fdcd91daada  push rcx
00007fdcd91daadb  push rdx
00007fdcd91daadc  push rdi
00007fdcd91daadd  push rsi
00007fdcd91daade  push r8
00007fdcd91daae0  push r9
00007fdcd91daae2  push r10
00007fdcd91daae4  push r11
00007fdcd91daae6  sub rsp, 0xF0
00007fdcd91daaed  vmovaps [rsp], xmm0
00007fdcd91daaf2  vmovaps [rsp+0x10], xmm1
00007fdcd91daaf8  vmovaps [rsp+0x20], xmm2
00007fdcd91daafe  vmovaps [rsp+0x30], xmm3
00007fdcd91dab04  vmovaps [rsp+0x40], xmm4
00007fdcd91dab0a  vmovaps [rsp+0x50], xmm5
00007fdcd91dab10  vmovaps [rsp+0x60], xmm6
00007fdcd91dab16  vmovaps [rsp+0x70], xmm7
00007fdcd91dab1c  vmovaps [rsp+0x80], xmm8
00007fdcd91dab25  vmovaps [rsp+0x90], xmm9
00007fdcd91dab2e  vmovaps [rsp+0xA0], xmm11
00007fdcd91dab37  vmovaps [rsp+0xB0], xmm12
00007fdcd91dab40  vmovaps [rsp+0xC0], xmm13
00007fdcd91dab49  vmovaps [rsp+0xD0], xmm14
00007fdcd91dab52  vmovaps [rsp+0xE0], xmm15
00007fdcd91dab5b  sub rsp, 0x30
00007fdcd91dab5f  movaps [rsp], xmm10
00007fdcd91dab64  movaps [rsp+0x10], xmm1
00007fdcd91dab69  movaps [rsp+0x20], xmm12
00007fdcd91dab6f  lea rdi, [rsp]
00007fdcd91dab73  mov esi, 0x00
00007fdcd91dab78  mov rax, 0x5B56EFBF3530
00007fdcd91dab82  call rax
00007fdcd91dab84  movaps xmm10, [rsp]
00007fdcd91dab89  add rsp, 0x30
00007fdcd91dab8d  vmovaps xmm0, [rsp]
00007fdcd91dab92  vmovaps xmm1, [rsp+0x10]
00007fdcd91dab98  vmovaps xmm2, [rsp+0x20]
00007fdcd91dab9e  vmovaps xmm3, [rsp+0x30]
00007fdcd91daba4  vmovaps xmm4, [rsp+0x40]
00007fdcd91dabaa  vmovaps xmm5, [rsp+0x50]
00007fdcd91dabb0  vmovaps xmm6, [rsp+0x60]
00007fdcd91dabb6  vmovaps xmm7, [rsp+0x70]
00007fdcd91dabbc  vmovaps xmm8, [rsp+0x80]
00007fdcd91dabc5  vmovaps xmm9, [rsp+0x90]
00007fdcd91dabce  vmovaps xmm11, [rsp+0xA0]
00007fdcd91dabd7  vmovaps xmm12, [rsp+0xB0]
00007fdcd91dabe0  vmovaps xmm13, [rsp+0xC0]
00007fdcd91dabe9  vmovaps xmm14, [rsp+0xD0]
00007fdcd91dabf2  vmovaps xmm15, [rsp+0xE0]
00007fdcd91dabfb  add rsp, 0xF0
00007fdcd91dac02  pop r11
00007fdcd91dac04  pop r10
00007fdcd91dac06  pop r9
00007fdcd91dac08  pop r8
00007fdcd91dac0a  pop rsi
00007fdcd91dac0b  pop rdi
00007fdcd91dac0c  pop rdx
00007fdcd91dac0d  pop rcx
00007fdcd91dac0e  pop rax
00007fdcd91dac0f  add rsp, 0x08
00007fdcd91dac13  jmp 0x00007FDCD91D651A
00007fdcd91dac18  sub rsp, 0x08
00007fdcd91dac1c  push rax
00007fdcd91dac1d  push rcx
00007fdcd91dac1e  push rdx
00007fdcd91dac1f  push rdi
00007fdcd91dac20  push rsi
00007fdcd91dac21  push r8
00007fdcd91dac23  push r9
00007fdcd91dac25  push r10
00007fdcd91dac27  push r11
00007fdcd91dac29  sub rsp, 0xF0
00007fdcd91dac30  vmovaps [rsp], xmm0
00007fdcd91dac35  vmovaps [rsp+0x10], xmm1
00007fdcd91dac3b  vmovaps [rsp+0x20], xmm2
00007fdcd91dac41  vmovaps [rsp+0x30], xmm3
00007fdcd91dac47  vmovaps [rsp+0x40], xmm4
00007fdcd91dac4d  vmovaps [rsp+0x50], xmm5
00007fdcd91dac53  vmovaps [rsp+0x60], xmm6
00007fdcd91dac59  vmovaps [rsp+0x70], xmm7
00007fdcd91dac5f  vmovaps [rsp+0x80], xmm8
00007fdcd91dac68  vmovaps [rsp+0x90], xmm9
00007fdcd91dac71  vmovaps [rsp+0xA0], xmm10
00007fdcd91dac7a  vmovaps [rsp+0xB0], xmm11
00007fdcd91dac83  vmovaps [rsp+0xC0], xmm13
00007fdcd91dac8c  vmovaps [rsp+0xD0], xmm14
00007fdcd91dac95  vmovaps [rsp+0xE0], xmm15
00007fdcd91dac9e  sub rsp, 0x30
00007fdcd91daca2  movaps [rsp], xmm12
00007fdcd91daca7  movaps [rsp+0x10], xmm14
00007fdcd91dacad  movaps [rsp+0x20], xmm1
00007fdcd91dacb2  lea rdi, [rsp]
00007fdcd91dacb6  mov esi, 0x00
00007fdcd91dacbb  mov rax, 0x5B56EFBF3530
00007fdcd91dacc5  call rax
00007fdcd91dacc7  movaps xmm12, [rsp]
00007fdcd91daccc  add rsp, 0x30
00007fdcd91dacd0  vmovaps xmm0, [rsp]
00007fdcd91dacd5  vmovaps xmm1, [rsp+0x10]
00007fdcd91dacdb  vmovaps xmm2, [rsp+0x20]
00007fdcd91dace1  vmovaps xmm3, [rsp+0x30]
00007fdcd91dace7  vmovaps xmm4, [rsp+0x40]
00007fdcd91daced  vmovaps xmm5, [rsp+0x50]
00007fdcd91dacf3  vmovaps xmm6, [rsp+0x60]
00007fdcd91dacf9  vmovaps xmm7, [rsp+0x70]
00007fdcd91dacff  vmovaps xmm8, [rsp+0x80]
00007fdcd91dad08  vmovaps xmm9, [rsp+0x90]
00007fdcd91dad11  vmovaps xmm10, [rsp+0xA0]
00007fdcd91dad1a  vmovaps xmm11, [rsp+0xB0]
00007fdcd91dad23  vmovaps xmm13, [rsp+0xC0]
00007fdcd91dad2c  vmovaps xmm14, [rsp+0xD0]
00007fdcd91dad35  vmovaps xmm15, [rsp+0xE0]
00007fdcd91dad3e  add rsp, 0xF0
00007fdcd91dad45  pop r11
00007fdcd91dad47  pop r10
00007fdcd91dad49  pop r9
00007fdcd91dad4b  pop r8
00007fdcd91dad4d  pop rsi
00007fdcd91dad4e  pop rdi
00007fdcd91dad4f  pop rdx
00007fdcd91dad50  pop rcx
00007fdcd91dad51  pop rax
00007fdcd91dad52  add rsp, 0x08
00007fdcd91dad56  jmp 0x00007FDCD91D6549
00007fdcd91dad5b  sub rsp, 0x08
00007fdcd91dad5f  push rax
00007fdcd91dad60  push rcx
00007fdcd91dad61  push rdx
00007fdcd91dad62  push rdi
00007fdcd91dad63  push rsi
00007fdcd91dad64  push r8
00007fdcd91dad66  push r9
00007fdcd91dad68  push r10
00007fdcd91dad6a  push r11
00007fdcd91dad6c  sub rsp, 0xF0
00007fdcd91dad73  vmovaps [rsp], xmm0
00007fdcd91dad78  vmovaps [rsp+0x10], xmm1
00007fdcd91dad7e  vmovaps [rsp+0x20], xmm2
00007fdcd91dad84  vmovaps [rsp+0x30], xmm3
00007fdcd91dad8a  vmovaps [rsp+0x40], xmm4
00007fdcd91dad90  vmovaps [rsp+0x50], xmm5
00007fdcd91dad96  vmovaps [rsp+0x60], xmm6
00007fdcd91dad9c  vmovaps [rsp+0x70], xmm7
00007fdcd91dada2  vmovaps [rsp+0x80], xmm8
00007fdcd91dadab  vmovaps [rsp+0x90], xmm9
00007fdcd91dadb4  vmovaps [rsp+0xA0], xmm10
00007fdcd91dadbd  vmovaps [rsp+0xB0], xmm11
00007fdcd91dadc6  vmovaps [rsp+0xC0], xmm12
00007fdcd91dadcf  vmovaps [rsp+0xD0], xmm13
00007fdcd91dadd8  vmovaps [rsp+0xE0], xmm15
00007fdcd91dade1  sub rsp, 0x30
00007fdcd91dade5  movaps [rsp], xmm14
00007fdcd91dadea  movaps [rsp+0x10], xmm9
00007fdcd91dadf0  movaps [rsp+0x20], xmm1
00007fdcd91dadf5  lea rdi, [rsp]
00007fdcd91dadf9  mov esi, 0x00
00007fdcd91dadfe  mov rax, 0x5B56EFBF3530
00007fdcd91dae08  call rax
00007fdcd91dae0a  movaps xmm14, [rsp]
00007fdcd91dae0f  add rsp, 0x30
00007fdcd91dae13  vmovaps xmm0, [rsp]
00007fdcd91dae18  vmovaps xmm1, [rsp+0x10]
00007fdcd91dae1e  vmovaps xmm2, [rsp+0x20]
00007fdcd91dae24  vmovaps xmm3, [rsp+0x30]
00007fdcd91dae2a  vmovaps xmm4, [rsp+0x40]
00007fdcd91dae30  vmovaps xmm5, [rsp+0x50]
00007fdcd91dae36  vmovaps xmm6, [rsp+0x60]
00007fdcd91dae3c  vmovaps xmm7, [rsp+0x70]
00007fdcd91dae42  vmovaps xmm8, [rsp+0x80]
00007fdcd91dae4b  vmovaps xmm9, [rsp+0x90]
00007fdcd91dae54  vmovaps xmm10, [rsp+0xA0]
00007fdcd91dae5d  vmovaps xmm11, [rsp+0xB0]
00007fdcd91dae66  vmovaps xmm12, [rsp+0xC0]
00007fdcd91dae6f  vmovaps xmm13, [rsp+0xD0]
00007fdcd91dae78  vmovaps xmm15, [rsp+0xE0]
00007fdcd91dae81  add rsp, 0xF0
00007fdcd91dae88  pop r11
00007fdcd91dae8a  pop r10
00007fdcd91dae8c  pop r9
00007fdcd91dae8e  pop r8
00007fdcd91dae90  pop rsi
00007fdcd91dae91  pop rdi
00007fdcd91dae92  pop rdx
00007fdcd91dae93  pop rcx
00007fdcd91dae94  pop rax
00007fdcd91dae95  add rsp, 0x08
00007fdcd91dae99  jmp 0x00007FDCD91D6578
00007fdcd91dae9e  sub rsp, 0x08
00007fdcd91daea2  push rax
00007fdcd91daea3  push rcx
00007fdcd91daea4  push rdx
00007fdcd91daea5  push rdi
00007fdcd91daea6  push rsi
00007fdcd91daea7  push r8
00007fdcd91daea9  push r9
00007fdcd91daeab  push r10
00007fdcd91daead  push r11
00007fdcd91daeaf  sub rsp, 0xF0
00007fdcd91daeb6  vmovaps [rsp], xmm0
00007fdcd91daebb  vmovaps [rsp+0x10], xmm2
00007fdcd91daec1  vmovaps [rsp+0x20], xmm3
00007fdcd91daec7  vmovaps [rsp+0x30], xmm4
00007fdcd91daecd  vmovaps [rsp+0x40], xmm5
00007fdcd91daed3  vmovaps [rsp+0x50], xmm6
00007fdcd91daed9  vmovaps [rsp+0x60], xmm7
00007fdcd91daedf  vmovaps [rsp+0x70], xmm8
00007fdcd91daee5  vmovaps [rsp+0x80], xmm9
00007fdcd91daeee  vmovaps [rsp+0x90], xmm10
00007fdcd91daef7  vmovaps [rsp+0xA0], xmm11
00007fdcd91daf00  vmovaps [rsp+0xB0], xmm12
00007fdcd91daf09  vmovaps [rsp+0xC0], xmm13
00007fdcd91daf12  vmovaps [rsp+0xD0], xmm14
00007fdcd91daf1b  vmovaps [rsp+0xE0], xmm15
00007fdcd91daf24  sub rsp, 0x30
00007fdcd91daf28  movaps [rsp], xmm1
00007fdcd91daf2c  movaps [rsp+0x10], xmm13
00007fdcd91daf32  movaps [rsp+0x20], xmm8
00007fdcd91daf38  lea rdi, [rsp]
00007fdcd91daf3c  mov esi, 0x00
00007fdcd91daf41  mov rax, 0x5B56EFBF3530
00007fdcd91daf4b  call rax
00007fdcd91daf4d  movaps xmm1, [rsp]
00007fdcd91daf51  add rsp, 0x30
00007fdcd91daf55  vmovaps xmm0, [rsp]
00007fdcd91daf5a  vmovaps xmm2, [rsp+0x10]
00007fdcd91daf60  vmovaps xmm3, [rsp+0x20]
00007fdcd91daf66  vmovaps xmm4, [rsp+0x30]
00007fdcd91daf6c  vmovaps xmm5, [rsp+0x40]
00007fdcd91daf72  vmovaps xmm6, [rsp+0x50]
00007fdcd91daf78  vmovaps xmm7, [rsp+0x60]
00007fdcd91daf7e  vmovaps xmm8, [rsp+0x70]
00007fdcd91daf84  vmovaps xmm9, [rsp+0x80]
00007fdcd91daf8d  vmovaps xmm10, [rsp+0x90]
00007fdcd91daf96  vmovaps xmm11, [rsp+0xA0]
00007fdcd91daf9f  vmovaps xmm12, [rsp+0xB0]
00007fdcd91dafa8  vmovaps xmm13, [rsp+0xC0]
00007fdcd91dafb1  vmovaps xmm14, [rsp+0xD0]
00007fdcd91dafba  vmovaps xmm15, [rsp+0xE0]
00007fdcd91dafc3  add rsp, 0xF0
00007fdcd91dafca  pop r11
00007fdcd91dafcc  pop r10
00007fdcd91dafce  pop r9
00007fdcd91dafd0  pop r8
00007fdcd91dafd2  pop rsi
00007fdcd91dafd3  pop rdi
00007fdcd91dafd4  pop rdx
00007fdcd91dafd5  pop rcx
00007fdcd91dafd6  pop rax
00007fdcd91dafd7  add rsp, 0x08
00007fdcd91dafdb  jmp 0x00007FDCD91D659A
00007fdcd91dafe0  call 0x00007FDCD900C260
00007fdcd91dafe5  jmp 0x00007FDCD91D65A8
00007fdcd91dafea  call 0x00007FDCD90DE950
00007fdcd91dafef  jmp 0x00007FDCD91D65B2
00007fdcd91daff4  sub rsp, 0x08
00007fdcd91daff8  push rax
00007fdcd91daff9  push rcx
00007fdcd91daffa  push rdx
00007fdcd91daffb  push rdi
00007fdcd91daffc  push rsi
00007fdcd91daffd  push r8
00007fdcd91dafff  push r9
00007fdcd91db001  push r10
00007fdcd91db003  push r11
00007fdcd91db005  sub rsp, 0xF0
00007fdcd91db00c  vmovaps [rsp], xmm0
00007fdcd91db011  vmovaps [rsp+0x10], xmm1
00007fdcd91db017  vmovaps [rsp+0x20], xmm2
00007fdcd91db01d  vmovaps [rsp+0x30], xmm3
00007fdcd91db023  vmovaps [rsp+0x40], xmm4
00007fdcd91db029  vmovaps [rsp+0x50], xmm5
00007fdcd91db02f  vmovaps [rsp+0x60], xmm6
00007fdcd91db035  vmovaps [rsp+0x70], xmm7
00007fdcd91db03b  vmovaps [rsp+0x80], xmm9
00007fdcd91db044  vmovaps [rsp+0x90], xmm10
00007fdcd91db04d  vmovaps [rsp+0xA0], xmm11
00007fdcd91db056  vmovaps [rsp+0xB0], xmm12
00007fdcd91db05f  vmovaps [rsp+0xC0], xmm13
00007fdcd91db068  vmovaps [rsp+0xD0], xmm14
00007fdcd91db071  vmovaps [rsp+0xE0], xmm15
00007fdcd91db07a  sub rsp, 0x30
00007fdcd91db07e  movaps [rsp], xmm8
00007fdcd91db083  movaps [rsp+0x10], xmm15
00007fdcd91db089  movaps [rsp+0x20], xmm7
00007fdcd91db08e  lea rdi, [rsp]
00007fdcd91db092  mov esi, 0x00
00007fdcd91db097  mov rax, 0x5B56EFBF3530
00007fdcd91db0a1  call rax
00007fdcd91db0a3  movaps xmm8, [rsp]
00007fdcd91db0a8  add rsp, 0x30
00007fdcd91db0ac  vmovaps xmm0, [rsp]
00007fdcd91db0b1  vmovaps xmm1, [rsp+0x10]
00007fdcd91db0b7  vmovaps xmm2, [rsp+0x20]
00007fdcd91db0bd  vmovaps xmm3, [rsp+0x30]
00007fdcd91db0c3  vmovaps xmm4, [rsp+0x40]
00007fdcd91db0c9  vmovaps xmm5, [rsp+0x50]
00007fdcd91db0cf  vmovaps xmm6, [rsp+0x60]
00007fdcd91db0d5  vmovaps xmm7, [rsp+0x70]
00007fdcd91db0db  vmovaps xmm9, [rsp+0x80]
00007fdcd91db0e4  vmovaps xmm10, [rsp+0x90]
00007fdcd91db0ed  vmovaps xmm11, [rsp+0xA0]
00007fdcd91db0f6  vmovaps xmm12, [rsp+0xB0]
00007fdcd91db0ff  vmovaps xmm13, [rsp+0xC0]
00007fdcd91db108  vmovaps xmm14, [rsp+0xD0]
00007fdcd91db111  vmovaps xmm15, [rsp+0xE0]
00007fdcd91db11a  add rsp, 0xF0
00007fdcd91db121  pop r11
00007fdcd91db123  pop r10
00007fdcd91db125  pop r9
00007fdcd91db127  pop r8
00007fdcd91db129  pop rsi
00007fdcd91db12a  pop rdi
00007fdcd91db12b  pop rdx
00007fdcd91db12c  pop rcx
00007fdcd91db12d  pop rax
00007fdcd91db12e  add rsp, 0x08
00007fdcd91db132  jmp 0x00007FDCD91D65D4
00007fdcd91db137  sub rsp, 0x08
00007fdcd91db13b  push rax
00007fdcd91db13c  push rcx
00007fdcd91db13d  push rdx
00007fdcd91db13e  push rdi
00007fdcd91db13f  push rsi
00007fdcd91db140  push r8
00007fdcd91db142  push r9
00007fdcd91db144  push r10
00007fdcd91db146  push r11
00007fdcd91db148  sub rsp, 0xF0
00007fdcd91db14f  vmovaps [rsp], xmm0
00007fdcd91db154  vmovaps [rsp+0x10], xmm1
00007fdcd91db15a  vmovaps [rsp+0x20], xmm2
00007fdcd91db160  vmovaps [rsp+0x30], xmm3
00007fdcd91db166  vmovaps [rsp+0x40], xmm4
00007fdcd91db16c  vmovaps [rsp+0x50], xmm5
00007fdcd91db172  vmovaps [rsp+0x60], xmm6
00007fdcd91db178  vmovaps [rsp+0x70], xmm8
00007fdcd91db17e  vmovaps [rsp+0x80], xmm9
00007fdcd91db187  vmovaps [rsp+0x90], xmm10
00007fdcd91db190  vmovaps [rsp+0xA0], xmm11
00007fdcd91db199  vmovaps [rsp+0xB0], xmm12
00007fdcd91db1a2  vmovaps [rsp+0xC0], xmm13
00007fdcd91db1ab  vmovaps [rsp+0xD0], xmm14
00007fdcd91db1b4  vmovaps [rsp+0xE0], xmm15
00007fdcd91db1bd  sub rsp, 0x30
00007fdcd91db1c1  movaps [rsp], xmm7
00007fdcd91db1c5  movaps [rsp+0x10], xmm9
00007fdcd91db1cb  movaps [rsp+0x20], xmm15
00007fdcd91db1d1  lea rdi, [rsp]
00007fdcd91db1d5  mov esi, 0x00
00007fdcd91db1da  mov rax, 0x5B56EFBF3530
00007fdcd91db1e4  call rax
00007fdcd91db1e6  movaps xmm7, [rsp]
00007fdcd91db1ea  add rsp, 0x30
00007fdcd91db1ee  vmovaps xmm0, [rsp]
00007fdcd91db1f3  vmovaps xmm1, [rsp+0x10]
00007fdcd91db1f9  vmovaps xmm2, [rsp+0x20]
00007fdcd91db1ff  vmovaps xmm3, [rsp+0x30]
00007fdcd91db205  vmovaps xmm4, [rsp+0x40]
00007fdcd91db20b  vmovaps xmm5, [rsp+0x50]
00007fdcd91db211  vmovaps xmm6, [rsp+0x60]
00007fdcd91db217  vmovaps xmm8, [rsp+0x70]
00007fdcd91db21d  vmovaps xmm9, [rsp+0x80]
00007fdcd91db226  vmovaps xmm10, [rsp+0x90]
00007fdcd91db22f  vmovaps xmm11, [rsp+0xA0]
00007fdcd91db238  vmovaps xmm12, [rsp+0xB0]
00007fdcd91db241  vmovaps xmm13, [rsp+0xC0]
00007fdcd91db24a  vmovaps xmm14, [rsp+0xD0]
00007fdcd91db253  vmovaps xmm15, [rsp+0xE0]
00007fdcd91db25c  add rsp, 0xF0
00007fdcd91db263  pop r11
00007fdcd91db265  pop r10
00007fdcd91db267  pop r9
00007fdcd91db269  pop r8
00007fdcd91db26b  pop rsi
00007fdcd91db26c  pop rdi
00007fdcd91db26d  pop rdx
00007fdcd91db26e  pop rcx
00007fdcd91db26f  pop rax
00007fdcd91db270  add rsp, 0x08
00007fdcd91db274  jmp 0x00007FDCD91D6601
00007fdcd91db279  sub rsp, 0x08
00007fdcd91db27d  push rax
00007fdcd91db27e  push rcx
00007fdcd91db27f  push rdx
00007fdcd91db280  push rdi
00007fdcd91db281  push rsi
00007fdcd91db282  push r8
00007fdcd91db284  push r9
00007fdcd91db286  push r10
00007fdcd91db288  push r11
00007fdcd91db28a  sub rsp, 0xF0
00007fdcd91db291  vmovaps [rsp], xmm0
00007fdcd91db296  vmovaps [rsp+0x10], xmm1
00007fdcd91db29c  vmovaps [rsp+0x20], xmm2
00007fdcd91db2a2  vmovaps [rsp+0x30], xmm3
00007fdcd91db2a8  vmovaps [rsp+0x40], xmm4
00007fdcd91db2ae  vmovaps [rsp+0x50], xmm5
00007fdcd91db2b4  vmovaps [rsp+0x60], xmm6
00007fdcd91db2ba  vmovaps [rsp+0x70], xmm7
00007fdcd91db2c0  vmovaps [rsp+0x80], xmm8
00007fdcd91db2c9  vmovaps [rsp+0x90], xmm10
00007fdcd91db2d2  vmovaps [rsp+0xA0], xmm11
00007fdcd91db2db  vmovaps [rsp+0xB0], xmm12
00007fdcd91db2e4  vmovaps [rsp+0xC0], xmm13
00007fdcd91db2ed  vmovaps [rsp+0xD0], xmm14
00007fdcd91db2f6  vmovaps [rsp+0xE0], xmm15
00007fdcd91db2ff  sub rsp, 0x30
00007fdcd91db303  movaps [rsp], xmm9
00007fdcd91db308  movaps [rsp+0x10], xmm13
00007fdcd91db30e  movaps [rsp+0x20], xmm15
00007fdcd91db314  lea rdi, [rsp]
00007fdcd91db318  mov esi, 0x00
00007fdcd91db31d  mov rax, 0x5B56EFBF3530
00007fdcd91db327  call rax
00007fdcd91db329  movaps xmm9, [rsp]
00007fdcd91db32e  add rsp, 0x30
00007fdcd91db332  vmovaps xmm0, [rsp]
00007fdcd91db337  vmovaps xmm1, [rsp+0x10]
00007fdcd91db33d  vmovaps xmm2, [rsp+0x20]
00007fdcd91db343  vmovaps xmm3, [rsp+0x30]
00007fdcd91db349  vmovaps xmm4, [rsp+0x40]
00007fdcd91db34f  vmovaps xmm5, [rsp+0x50]
00007fdcd91db355  vmovaps xmm6, [rsp+0x60]
00007fdcd91db35b  vmovaps xmm7, [rsp+0x70]
00007fdcd91db361  vmovaps xmm8, [rsp+0x80]
00007fdcd91db36a  vmovaps xmm10, [rsp+0x90]
00007fdcd91db373  vmovaps xmm11, [rsp+0xA0]
00007fdcd91db37c  vmovaps xmm12, [rsp+0xB0]
00007fdcd91db385  vmovaps xmm13, [rsp+0xC0]
00007fdcd91db38e  vmovaps xmm14, [rsp+0xD0]
00007fdcd91db397  vmovaps xmm15, [rsp+0xE0]
00007fdcd91db3a0  add rsp, 0xF0
00007fdcd91db3a7  pop r11
00007fdcd91db3a9  pop r10
00007fdcd91db3ab  pop r9
00007fdcd91db3ad  pop r8
00007fdcd91db3af  pop rsi
00007fdcd91db3b0  pop rdi
00007fdcd91db3b1  pop rdx
00007fdcd91db3b2  pop rcx
00007fdcd91db3b3  pop rax
00007fdcd91db3b4  add rsp, 0x08
00007fdcd91db3b8  jmp 0x00007FDCD91D662F
00007fdcd91db3bd  sub rsp, 0x08
00007fdcd91db3c1  push rax
00007fdcd91db3c2  push rcx
00007fdcd91db3c3  push rdx
00007fdcd91db3c4  push rdi
00007fdcd91db3c5  push rsi
00007fdcd91db3c6  push r8
00007fdcd91db3c8  push r9
00007fdcd91db3ca  push r10
00007fdcd91db3cc  push r11
00007fdcd91db3ce  sub rsp, 0xF0
00007fdcd91db3d5  vmovaps [rsp], xmm0
00007fdcd91db3da  vmovaps [rsp+0x10], xmm1
00007fdcd91db3e0  vmovaps [rsp+0x20], xmm2
00007fdcd91db3e6  vmovaps [rsp+0x30], xmm3
00007fdcd91db3ec  vmovaps [rsp+0x40], xmm4
00007fdcd91db3f2  vmovaps [rsp+0x50], xmm5
00007fdcd91db3f8  vmovaps [rsp+0x60], xmm6
00007fdcd91db3fe  vmovaps [rsp+0x70], xmm7
00007fdcd91db404  vmovaps [rsp+0x80], xmm8
00007fdcd91db40d  vmovaps [rsp+0x90], xmm9
00007fdcd91db416  vmovaps [rsp+0xA0], xmm10
00007fdcd91db41f  vmovaps [rsp+0xB0], xmm11
00007fdcd91db428  vmovaps [rsp+0xC0], xmm12
00007fdcd91db431  vmovaps [rsp+0xD0], xmm13
00007fdcd91db43a  vmovaps [rsp+0xE0], xmm14
00007fdcd91db443  sub rsp, 0x30
00007fdcd91db447  movaps [rsp], xmm15
00007fdcd91db44c  movaps [rsp+0x10], xmm11
00007fdcd91db452  movaps [rsp+0x20], xmm12
00007fdcd91db458  lea rdi, [rsp]
00007fdcd91db45c  mov esi, 0x00
00007fdcd91db461  mov rax, 0x5B56EFBF3530
00007fdcd91db46b  call rax
00007fdcd91db46d  movaps xmm15, [rsp]
00007fdcd91db472  add rsp, 0x30
00007fdcd91db476  vmovaps xmm0, [rsp]
00007fdcd91db47b  vmovaps xmm1, [rsp+0x10]
00007fdcd91db481  vmovaps xmm2, [rsp+0x20]
00007fdcd91db487  vmovaps xmm3, [rsp+0x30]
00007fdcd91db48d  vmovaps xmm4, [rsp+0x40]
00007fdcd91db493  vmovaps xmm5, [rsp+0x50]
00007fdcd91db499  vmovaps xmm6, [rsp+0x60]
00007fdcd91db49f  vmovaps xmm7, [rsp+0x70]
00007fdcd91db4a5  vmovaps xmm8, [rsp+0x80]
00007fdcd91db4ae  vmovaps xmm9, [rsp+0x90]
00007fdcd91db4b7  vmovaps xmm10, [rsp+0xA0]
00007fdcd91db4c0  vmovaps xmm11, [rsp+0xB0]
00007fdcd91db4c9  vmovaps xmm12, [rsp+0xC0]
00007fdcd91db4d2  vmovaps xmm13, [rsp+0xD0]
00007fdcd91db4db  vmovaps xmm14, [rsp+0xE0]
00007fdcd91db4e4  add rsp, 0xF0
00007fdcd91db4eb  pop r11
00007fdcd91db4ed  pop r10
00007fdcd91db4ef  pop r9
00007fdcd91db4f1  pop r8
00007fdcd91db4f3  pop rsi
00007fdcd91db4f4  pop rdi
00007fdcd91db4f5  pop rdx
00007fdcd91db4f6  pop rcx
00007fdcd91db4f7  pop rax
00007fdcd91db4f8  add rsp, 0x08
00007fdcd91db4fc  jmp 0x00007FDCD91D664A
00007fdcd91db501  sub rsp, 0x08
00007fdcd91db505  push rax
00007fdcd91db506  push rcx
00007fdcd91db507  push rdx
00007fdcd91db508  push rdi
00007fdcd91db509  push rsi
00007fdcd91db50a  push r8
00007fdcd91db50c  push r9
00007fdcd91db50e  push r10
00007fdcd91db510  push r11
00007fdcd91db512  sub rsp, 0xF0
00007fdcd91db519  vmovaps [rsp], xmm0
00007fdcd91db51e  vmovaps [rsp+0x10], xmm1
00007fdcd91db524  vmovaps [rsp+0x20], xmm2
00007fdcd91db52a  vmovaps [rsp+0x30], xmm3
00007fdcd91db530  vmovaps [rsp+0x40], xmm4
00007fdcd91db536  vmovaps [rsp+0x50], xmm5
00007fdcd91db53c  vmovaps [rsp+0x60], xmm6
00007fdcd91db542  vmovaps [rsp+0x70], xmm7
00007fdcd91db548  vmovaps [rsp+0x80], xmm8
00007fdcd91db551  vmovaps [rsp+0x90], xmm9
00007fdcd91db55a  vmovaps [rsp+0xA0], xmm10
00007fdcd91db563  vmovaps [rsp+0xB0], xmm11
00007fdcd91db56c  vmovaps [rsp+0xC0], xmm12
00007fdcd91db575  vmovaps [rsp+0xD0], xmm14
00007fdcd91db57e  vmovaps [rsp+0xE0], xmm15
00007fdcd91db587  sub rsp, 0x30
00007fdcd91db58b  movaps [rsp], xmm13
00007fdcd91db590  movaps [rsp+0x10], xmm10
00007fdcd91db596  movaps [rsp+0x20], xmm14
00007fdcd91db59c  lea rdi, [rsp]
00007fdcd91db5a0  mov esi, 0x00
00007fdcd91db5a5  mov rax, 0x5B56EFBF3530
00007fdcd91db5af  call rax
00007fdcd91db5b1  movaps xmm13, [rsp]
00007fdcd91db5b6  add rsp, 0x30
00007fdcd91db5ba  vmovaps xmm0, [rsp]
00007fdcd91db5bf  vmovaps xmm1, [rsp+0x10]
00007fdcd91db5c5  vmovaps xmm2, [rsp+0x20]
00007fdcd91db5cb  vmovaps xmm3, [rsp+0x30]
00007fdcd91db5d1  vmovaps xmm4, [rsp+0x40]
00007fdcd91db5d7  vmovaps xmm5, [rsp+0x50]
00007fdcd91db5dd  vmovaps xmm6, [rsp+0x60]
00007fdcd91db5e3  vmovaps xmm7, [rsp+0x70]
00007fdcd91db5e9  vmovaps xmm8, [rsp+0x80]
00007fdcd91db5f2  vmovaps xmm9, [rsp+0x90]
00007fdcd91db5fb  vmovaps xmm10, [rsp+0xA0]
00007fdcd91db604  vmovaps xmm11, [rsp+0xB0]
00007fdcd91db60d  vmovaps xmm12, [rsp+0xC0]
00007fdcd91db616  vmovaps xmm14, [rsp+0xD0]
00007fdcd91db61f  vmovaps xmm15, [rsp+0xE0]
00007fdcd91db628  add rsp, 0xF0
00007fdcd91db62f  pop r11
00007fdcd91db631  pop r10
00007fdcd91db633  pop r9
00007fdcd91db635  pop r8
00007fdcd91db637  pop rsi
00007fdcd91db638  pop rdi
00007fdcd91db639  pop rdx
00007fdcd91db63a  pop rcx
00007fdcd91db63b  pop rax
00007fdcd91db63c  add rsp, 0x08
00007fdcd91db640  jmp 0x00007FDCD91D666D
00007fdcd91db645  sub rsp, 0x08
00007fdcd91db649  push rax
00007fdcd91db64a  push rcx
00007fdcd91db64b  push rdx
00007fdcd91db64c  push rdi
00007fdcd91db64d  push rsi
00007fdcd91db64e  push r8
00007fdcd91db650  push r9
00007fdcd91db652  push r10
00007fdcd91db654  push r11
00007fdcd91db656  sub rsp, 0xF0
00007fdcd91db65d  vmovaps [rsp], xmm0
00007fdcd91db662  vmovaps [rsp+0x10], xmm1
00007fdcd91db668  vmovaps [rsp+0x20], xmm2
00007fdcd91db66e  vmovaps [rsp+0x30], xmm3
00007fdcd91db674  vmovaps [rsp+0x40], xmm4
00007fdcd91db67a  vmovaps [rsp+0x50], xmm5
00007fdcd91db680  vmovaps [rsp+0x60], xmm6
00007fdcd91db686  vmovaps [rsp+0x70], xmm7
00007fdcd91db68c  vmovaps [rsp+0x80], xmm8
00007fdcd91db695  vmovaps [rsp+0x90], xmm9
00007fdcd91db69e  vmovaps [rsp+0xA0], xmm10
00007fdcd91db6a7  vmovaps [rsp+0xB0], xmm11
00007fdcd91db6b0  vmovaps [rsp+0xC0], xmm12
00007fdcd91db6b9  vmovaps [rsp+0xD0], xmm13
00007fdcd91db6c2  vmovaps [rsp+0xE0], xmm15
00007fdcd91db6cb  sub rsp, 0x30
00007fdcd91db6cf  movaps [rsp], xmm14
00007fdcd91db6d4  movaps [rsp+0x10], xmm1
00007fdcd91db6d9  movaps [rsp+0x20], xmm7
00007fdcd91db6de  lea rdi, [rsp]
00007fdcd91db6e2  mov esi, 0x00
00007fdcd91db6e7  mov rax, 0x5B56EFBF3530
00007fdcd91db6f1  call rax
00007fdcd91db6f3  movaps xmm14, [rsp]
00007fdcd91db6f8  add rsp, 0x30
00007fdcd91db6fc  vmovaps xmm0, [rsp]
00007fdcd91db701  vmovaps xmm1, [rsp+0x10]
00007fdcd91db707  vmovaps xmm2, [rsp+0x20]
00007fdcd91db70d  vmovaps xmm3, [rsp+0x30]
00007fdcd91db713  vmovaps xmm4, [rsp+0x40]
00007fdcd91db719  vmovaps xmm5, [rsp+0x50]
00007fdcd91db71f  vmovaps xmm6, [rsp+0x60]
00007fdcd91db725  vmovaps xmm7, [rsp+0x70]
00007fdcd91db72b  vmovaps xmm8, [rsp+0x80]
00007fdcd91db734  vmovaps xmm9, [rsp+0x90]
00007fdcd91db73d  vmovaps xmm10, [rsp+0xA0]
00007fdcd91db746  vmovaps xmm11, [rsp+0xB0]
00007fdcd91db74f  vmovaps xmm12, [rsp+0xC0]
00007fdcd91db758  vmovaps xmm13, [rsp+0xD0]
00007fdcd91db761  vmovaps xmm15, [rsp+0xE0]
00007fdcd91db76a  add rsp, 0xF0
00007fdcd91db771  pop r11
00007fdcd91db773  pop r10
00007fdcd91db775  pop r9
00007fdcd91db777  pop r8
00007fdcd91db779  pop rsi
00007fdcd91db77a  pop rdi
00007fdcd91db77b  pop rdx
00007fdcd91db77c  pop rcx
00007fdcd91db77d  pop rax
00007fdcd91db77e  add rsp, 0x08
00007fdcd91db782  jmp 0x00007FDCD91D6690
00007fdcd91db787  sub rsp, 0x08
00007fdcd91db78b  push rax
00007fdcd91db78c  push rcx
00007fdcd91db78d  push rdx
00007fdcd91db78e  push rdi
00007fdcd91db78f  push rsi
00007fdcd91db790  push r8
00007fdcd91db792  push r9
00007fdcd91db794  push r10
00007fdcd91db796  push r11
00007fdcd91db798  sub rsp, 0xF0
00007fdcd91db79f  vmovaps [rsp], xmm0
00007fdcd91db7a4  vmovaps [rsp+0x10], xmm2
00007fdcd91db7aa  vmovaps [rsp+0x20], xmm3
00007fdcd91db7b0  vmovaps [rsp+0x30], xmm4
00007fdcd91db7b6  vmovaps [rsp+0x40], xmm5
00007fdcd91db7bc  vmovaps [rsp+0x50], xmm6
00007fdcd91db7c2  vmovaps [rsp+0x60], xmm7
00007fdcd91db7c8  vmovaps [rsp+0x70], xmm8
00007fdcd91db7ce  vmovaps [rsp+0x80], xmm9
00007fdcd91db7d7  vmovaps [rsp+0x90], xmm10
00007fdcd91db7e0  vmovaps [rsp+0xA0], xmm11
00007fdcd91db7e9  vmovaps [rsp+0xB0], xmm12
00007fdcd91db7f2  vmovaps [rsp+0xC0], xmm13
00007fdcd91db7fb  vmovaps [rsp+0xD0], xmm14
00007fdcd91db804  vmovaps [rsp+0xE0], xmm15
00007fdcd91db80d  sub rsp, 0x30
00007fdcd91db811  movaps [rsp], xmm1
00007fdcd91db815  movaps [rsp+0x10], xmm8
00007fdcd91db81b  movaps [rsp+0x20], xmm9
00007fdcd91db821  lea rdi, [rsp]
00007fdcd91db825  mov esi, 0x00
00007fdcd91db82a  mov rax, 0x5B56EFBF3530
00007fdcd91db834  call rax
00007fdcd91db836  movaps xmm1, [rsp]
00007fdcd91db83a  add rsp, 0x30
00007fdcd91db83e  vmovaps xmm0, [rsp]
00007fdcd91db843  vmovaps xmm2, [rsp+0x10]
00007fdcd91db849  vmovaps xmm3, [rsp+0x20]
00007fdcd91db84f  vmovaps xmm4, [rsp+0x30]
00007fdcd91db855  vmovaps xmm5, [rsp+0x40]
00007fdcd91db85b  vmovaps xmm6, [rsp+0x50]
00007fdcd91db861  vmovaps xmm7, [rsp+0x60]
00007fdcd91db867  vmovaps xmm8, [rsp+0x70]
00007fdcd91db86d  vmovaps xmm9, [rsp+0x80]
00007fdcd91db876  vmovaps xmm10, [rsp+0x90]
00007fdcd91db87f  vmovaps xmm11, [rsp+0xA0]
00007fdcd91db888  vmovaps xmm12, [rsp+0xB0]
00007fdcd91db891  vmovaps xmm13, [rsp+0xC0]
00007fdcd91db89a  vmovaps xmm14, [rsp+0xD0]
00007fdcd91db8a3  vmovaps xmm15, [rsp+0xE0]
00007fdcd91db8ac  add rsp, 0xF0
00007fdcd91db8b3  pop r11
00007fdcd91db8b5  pop r10
00007fdcd91db8b7  pop r9
00007fdcd91db8b9  pop r8
00007fdcd91db8bb  pop rsi
00007fdcd91db8bc  pop rdi
00007fdcd91db8bd  pop rdx
00007fdcd91db8be  pop rcx
00007fdcd91db8bf  pop rax
00007fdcd91db8c0  add rsp, 0x08
00007fdcd91db8c4  jmp 0x00007FDCD91D66B2
00007fdcd91db8c9  call 0x00007FDCD90B3E40
00007fdcd91db8ce  jmp 0x00007FDCD91D66C0
00007fdcd91db8d3  call 0x00007FDCD900C380
00007fdcd91db8d8  jmp 0x00007FDCD91D66CA
00007fdcd91db8dd  call 0x00007FDCD900D600
00007fdcd91db8e2  jmp 0x00007FDCD91D66D4
00007fdcd91db8e7  call 0x00007FDCD8FFF540
00007fdcd91db8ec  jmp 0x00007FDCD91D66DE
00007fdcd91db8f1  int3
00007fdcd91db8f2  nop [rax+rax*1], ax
00007fdcd91db8fb  nop [rax+rax*1], eax
00007fdcd91db900  mov eax, [r15+0x48]
00007fdcd91db904  lea r14d, [eax+0x01]
00007fdcd91db909  mov [rsp+0x10], r14d
00007fdcd91db90e  mov r14d, r14d
00007fdcd91db911  mov [r15+0x48], r14
00007fdcd91db915  xor eax, eax
00007fdcd91db917  mov r14d, [rsp+0x10]
00007fdcd91db91c  cmp r14d, 0x1F4
00007fdcd91db923  cmc
00007fdcd91db924  lahf
00007fdcd91db925  seto al
00007fdcd91db928  mov [r15+0x108], eax
00007fdcd91db92f  mov eax, [r15+0x108]
00007fdcd91db936  sahf
00007fdcd91db937  jnz 0x00007FDCD91DB969
00007fdcd91db939  cmp dword ptr [r15+0x318], 0x00
00007fdcd91db941  jz 0x00007FDCD91E1AB0
00007fdcd91db947  nop [rax+rax*1], ax
00007fdcd91db950  nop [rax+rax*1], eax
00007fdcd91db958  mov eax, 0x410450
00007fdcd91db95d  mov [r15+0x100], rax
00007fdcd91db964  jmp 0x00007FDCD8FFE110
00007fdcd91db969  cmp dword ptr [r15+0x318], 0x00
00007fdcd91db971  jz 0x00007FDCD91DB9A0
00007fdcd91db977  nop [rax+rax*1], ax
00007fdcd91db980  nop [rax+rax*1], eax
00007fdcd91db988  mov eax, 0x410274
00007fdcd91db98d  mov [r15+0x100], rax
00007fdcd91db994  jmp 0x00007FDCD8FFE110
00007fdcd91db999  int3
00007fdcd91db99a  int3
00007fdcd91db99b  nop [rax+rax*1], eax
00007fdcd91db9a0  mov rax, [r15+0x40]
00007fdcd91db9a4  movaps xmm1, [r15+0x1D0]
00007fdcd91db9ac  vmovaps [rsp+0x10], xmm1
00007fdcd91db9b2  vmovaps xmm15, [rsp+0x10]
00007fdcd91db9b8  por xmm1, xmm15
00007fdcd91db9bd  movaps xmm14, [r15+0x1A0]
00007fdcd91db9c5  vmovaps [rsp+0x10], xmm14
00007fdcd91db9cb  vmovaps xmm13, [rsp+0x10]
00007fdcd91db9d1  por xmm14, xmm13
00007fdcd91db9d6  lea r14, [rax+0x30]
00007fdcd91db9da  mov r12, [r13+r14*1]
00007fdcd91db9df  lea r14, [rax+0x38]
00007fdcd91db9e3  mov r11, [r13+r14*1]
00007fdcd91db9e8  movq xmm13, r12
00007fdcd91db9ed  movq xmm12, r11
00007fdcd91db9f2  movq xmm13, xmm13
00007fdcd91db9f7  vmovaps [rsp+0x10], xmm13
00007fdcd91db9fd  movq xmm13, xmm13
00007fdcd91dba02  movaps [r15+0x130], xmm13
00007fdcd91dba0a  movq xmm12, xmm12
00007fdcd91dba0f  vmovaps [rsp+0x20], xmm12
00007fdcd91dba15  movq xmm12, xmm12
00007fdcd91dba1a  movaps [r15+0x280], xmm12
00007fdcd91dba22  movaps xmm13, [r15+0x270]
00007fdcd91dba2a  vmovaps [rsp+0x30], xmm13
00007fdcd91dba30  vmovaps xmm12, [rsp+0x30]
00007fdcd91dba36  por xmm13, xmm12
00007fdcd91dba3b  lea r14, [rax+0x20]
00007fdcd91dba3f  mov r12, [r13+r14*1]
00007fdcd91dba44  lea r14, [rax+0x28]
00007fdcd91dba48  mov r11, [r13+r14*1]
00007fdcd91dba4d  movq xmm12, r12
00007fdcd91dba52  movq xmm11, r11
00007fdcd91dba57  movq xmm12, xmm12
00007fdcd91dba5c  vmovaps [rsp+0x30], xmm12
00007fdcd91dba62  movq xmm12, xmm12
00007fdcd91dba67  movaps [r15+0x150], xmm12
00007fdcd91dba6f  movq xmm11, xmm11
00007fdcd91dba74  vmovaps [rsp+0x40], xmm11
00007fdcd91dba7a  movq xmm11, xmm11
00007fdcd91dba7f  movaps [r15+0x140], xmm11
00007fdcd91dba87  lea r14, [rax+0x10]
00007fdcd91dba8b  mov r12, [r13+r14*1]
00007fdcd91dba90  lea r14, [rax+0x18]
00007fdcd91dba94  mov r11, [r13+r14*1]
00007fdcd91dba99  movq xmm12, r12
00007fdcd91dba9e  movq xmm11, r11
00007fdcd91dbaa3  movq xmm12, xmm12
00007fdcd91dbaa8  vmovaps [rsp+0x50], xmm12
00007fdcd91dbaae  movq xmm12, xmm12
00007fdcd91dbab3  movaps [r15+0x170], xmm12
00007fdcd91dbabb  movq xmm11, xmm11
00007fdcd91dbac0  vmovaps [rsp+0x60], xmm11
00007fdcd91dbac6  movq xmm11, xmm11
00007fdcd91dbacb  movaps [r15+0x160], xmm11
00007fdcd91dbad3  mov r14, [r13+rax*1]
00007fdcd91dbad8  vmovq xmm12, r14
00007fdcd91dbadd  vpbroadcastq xmm12, xmm12
00007fdcd91dbae2  lea r14, [rax+0x08]
00007fdcd91dbae6  mov rax, [r13+r14*1]
00007fdcd91dbaeb  movq xmm11, rax
00007fdcd91dbaf0  movaps [r15+0x230], xmm11
00007fdcd91dbaf8  mov rax, [r15+0xF8]
00007fdcd91dbaff  lea r14, [rax+0x50]
00007fdcd91dbb03  movups xmm11, [r13+r14*1]
00007fdcd91dbb09  lea r14, [rax+0x60]
00007fdcd91dbb0d  movups xmm10, [r13+r14*1]
00007fdcd91dbb13  lea r14, [rax+0x30]
00007fdcd91dbb17  movups xmm9, [r13+r14*1]
00007fdcd91dbb1d  mov r14, [r15+0x50]
00007fdcd91dbb21  mov [r15+0x60], r14
00007fdcd91dbb25  mov qword ptr [r15+0x58], 0x40
00007fdcd91dbb2d  movaps xmm8, xmm12
00007fdcd91dbb31  mulpd xmm8, xmm15
00007fdcd91dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007fdcd91dbb3c  ptest xmm7, xmm7
00007fdcd91dbb41  jnz 0x00007FDCD91DC96A
00007fdcd91dbb47  movq xmm15, qword ptr [r15+0x230]
00007fdcd91dbb50  vmovaps [rsp+0x70], xmm15
00007fdcd91dbb56  vpermilpd xmm15, xmm15, 0x00
00007fdcd91dbb5c  movaps xmm7, xmm9
00007fdcd91dbb60  mulpd xmm7, xmm15
00007fdcd91dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007fdcd91dbb6a  ptest xmm6, xmm6
00007fdcd91dbb6f  jnz 0x00007FDCD91DCAAE
00007fdcd91dbb75  vxorps xmm15, xmm15, xmm15
00007fdcd91dbb7a  vpbroadcastq xmm15, xmm15
00007fdcd91dbb7f  movaps xmm9, xmm12
00007fdcd91dbb83  mulpd xmm9, xmm10
00007fdcd91dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007fdcd91dbb8e  ptest xmm6, xmm6
00007fdcd91dbb93  jnz 0x00007FDCD91DCBF0
00007fdcd91dbb99  movaps xmm10, xmm12
00007fdcd91dbb9d  mulpd xmm10, xmm11
00007fdcd91dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007fdcd91dbba8  ptest xmm6, xmm6
00007fdcd91dbbad  jnz 0x00007FDCD91DCD34
00007fdcd91dbbb3  movaps xmm11, [r15+0x1F0]
00007fdcd91dbbbb  movaps xmm6, xmm12
00007fdcd91dbbbf  mulpd xmm6, xmm11
00007fdcd91dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007fdcd91dbbc9  ptest xmm5, xmm5
00007fdcd91dbbce  jnz 0x00007FDCD91DCE78
00007fdcd91dbbd4  movaps xmm12, [r15+0x2A0]
00007fdcd91dbbdc  vmovaps [rsp+0x80], xmm12
00007fdcd91dbbe5  vmovaps xmm11, [rsp+0x80]
00007fdcd91dbbee  por xmm12, xmm11
00007fdcd91dbbf3  movaps xmm11, [r15+0x250]
00007fdcd91dbbfb  vmovaps [rsp+0x80], xmm11
00007fdcd91dbc04  vmovaps xmm5, [rsp+0x80]
00007fdcd91dbc0d  por xmm11, xmm5
00007fdcd91dbc12  vmovaps xmm4, [rsp+0x70]
00007fdcd91dbc18  vpermilpd xmm4, xmm4, 0x00
00007fdcd91dbc1e  movaps xmm3, xmm5
00007fdcd91dbc21  mulpd xmm3, xmm4
00007fdcd91dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007fdcd91dbc2a  ptest xmm2, xmm2
00007fdcd91dbc2f  jnz 0x00007FDCD91DCFBA
00007fdcd91dbc35  mov [rsp+0x80], rax
00007fdcd91dbc3d  xor eax, eax
00007fdcd91dbc3f  mov r12d, 0x40
00007fdcd91dbc45  mov r11d, 0x200
00007fdcd91dbc4b  cmp r12, r11
00007fdcd91dbc4e  cmc
00007fdcd91dbc4f  lahf
00007fdcd91dbc50  seto al
00007fdcd91dbc53  mov [r15+0x108], eax
00007fdcd91dbc5a  movaps xmm5, xmm8
00007fdcd91dbc5e  addpd xmm5, xmm15
00007fdcd91dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007fdcd91dbc68  ptest xmm4, xmm4
00007fdcd91dbc6d  jnz 0x00007FDCD91DD0FA
00007fdcd91dbc73  movaps xmm8, [r15+0x1B0]
00007fdcd91dbc7b  movaps xmm4, xmm9
00007fdcd91dbc7f  addpd xmm4, xmm8
00007fdcd91dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007fdcd91dbc89  ptest xmm2, xmm2
00007fdcd91dbc8e  jnz 0x00007FDCD91DD23C
00007fdcd91dbc94  movaps xmm9, xmm10
00007fdcd91dbc98  addpd xmm9, xmm8
00007fdcd91dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007fdcd91dbca3  ptest xmm2, xmm2
00007fdcd91dbca8  jnz 0x00007FDCD91DD37E
00007fdcd91dbcae  movaps xmm10, [r15+0x2F0]
00007fdcd91dbcb6  vmovaps [rsp+0x90], xmm10
00007fdcd91dbcbf  vmovaps xmm8, [rsp+0x90]
00007fdcd91dbcc8  por xmm10, xmm8
00007fdcd91dbccd  movaps xmm8, [r15+0x2E0]
00007fdcd91dbcd5  vmovaps [rsp+0x90], xmm8
00007fdcd91dbcde  vmovaps xmm2, [rsp+0x90]
00007fdcd91dbce7  por xmm8, xmm2
00007fdcd91dbcec  movaps xmm2, [r15+0x2D0]
00007fdcd91dbcf4  vmovaps [rsp+0x90], xmm2
00007fdcd91dbcfd  vmovaps [rsp+0xA0], xmm1
00007fdcd91dbd06  vmovaps xmm1, [rsp+0x90]
00007fdcd91dbd0f  por xmm2, xmm1
00007fdcd91dbd13  movaps xmm1, [r15+0x200]
00007fdcd91dbd1b  vmovaps [rsp+0x90], xmm1
00007fdcd91dbd24  vmovaps [rsp+0xB0], xmm15
00007fdcd91dbd2d  vmovaps xmm15, [rsp+0x90]
00007fdcd91dbd36  por xmm1, xmm15
00007fdcd91dbd3b  movaps xmm15, [r15+0x1C0]
00007fdcd91dbd43  vmovaps [rsp+0x90], xmm15
00007fdcd91dbd4c  vmovaps [rsp+0xC0], xmm1
00007fdcd91dbd55  vmovaps xmm1, [rsp+0x90]
00007fdcd91dbd5e  por xmm15, xmm1
00007fdcd91dbd63  movaps xmm1, [r15+0x190]
00007fdcd91dbd6b  vmovaps [rsp+0x90], xmm1
00007fdcd91dbd74  vmovaps [rsp+0xD0], xmm15
00007fdcd91dbd7d  vmovaps xmm15, [rsp+0x90]
00007fdcd91dbd86  por xmm1, xmm15
00007fdcd91dbd8b  movaps xmm15, [r15+0x300]
00007fdcd91dbd93  vmovaps [rsp+0x90], xmm15
00007fdcd91dbd9c  vmovaps [rsp+0xE0], xmm1
00007fdcd91dbda5  vmovaps xmm1, [rsp+0x90]
00007fdcd91dbdae  por xmm15, xmm1
00007fdcd91dbdb3  mov rax, [rsp+0x80]
00007fdcd91dbdbb  lea r12, [rax+0xA0]
00007fdcd91dbdc2  movups xmm1, [r13+r12*1]
00007fdcd91dbdc8  lea r12, [rax+0xB0]
00007fdcd91dbdcf  vmovaps [rsp+0x80], xmm1
00007fdcd91dbdd8  movups xmm1, [r13+r12*1]
00007fdcd91dbdde  vmovaps [rsp+0x90], xmm1
00007fdcd91dbde7  vmovaps [rsp+0xF0], xmm15
00007fdcd91dbdf0  vmovaps xmm15, [rsp+0xB0]
00007fdcd91dbdf9  vmovaps [rsp+0xB0], xmm14
00007fdcd91dbe02  movaps xmm1, xmm6
00007fdcd91dbe05  addpd xmm1, xmm15
00007fdcd91dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007fdcd91dbe0f  ptest xmm14, xmm14
00007fdcd91dbe15  jnz 0x00007FDCD91DD4D6
00007fdcd91dbe1b  lea r12, [rax+0xF0]
00007fdcd91dbe22  movups xmm15, [r13+r12*1]
00007fdcd91dbe28  movaps xmm14, xmm4
00007fdcd91dbe2c  addpd xmm14, xmm3
00007fdcd91dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007fdcd91dbe37  ptest xmm6, xmm6
00007fdcd91dbe3c  jnz 0x00007FDCD91DD621
00007fdcd91dbe42  movaps xmm6, xmm9
00007fdcd91dbe46  addpd xmm6, xmm7
00007fdcd91dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007fdcd91dbe4f  ptest xmm4, xmm4
00007fdcd91dbe54  jnz 0x00007FDCD91DD763
00007fdcd91dbe5a  vmovaps xmm9, [rsp+0x70]
00007fdcd91dbe60  vpermilpd xmm9, xmm9, 0x00
00007fdcd91dbe66  vmovaps xmm4, [rsp+0x90]
00007fdcd91dbe6f  movaps xmm7, xmm4
00007fdcd91dbe72  mulpd xmm7, xmm9
00007fdcd91dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007fdcd91dbe7c  ptest xmm3, xmm3
00007fdcd91dbe81  jnz 0x00007FDCD91DD8A4
00007fdcd91dbe87  vmovaps xmm9, [rsp+0x50]
00007fdcd91dbe8d  vpermilpd xmm9, xmm9, 0x00
00007fdcd91dbe93  movaps xmm4, xmm15
00007fdcd91dbe97  mulpd xmm4, xmm9
00007fdcd91dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007fdcd91dbea1  ptest xmm3, xmm3
00007fdcd91dbea6  jnz 0x00007FDCD91DD9E5
00007fdcd91dbeac  lea r12, [rax+0xE0]
00007fdcd91dbeb3  movups xmm15, [r13+r12*1]
00007fdcd91dbeb9  vmovaps xmm9, [rsp+0x70]
00007fdcd91dbebf  vpermilpd xmm9, xmm9, 0x00
00007fdcd91dbec5  vmovaps [rsp+0x70], xmm1
00007fdcd91dbecb  vmovaps xmm1, [rsp+0x80]
00007fdcd91dbed4  vmovaps [rsp+0x80], xmm15
00007fdcd91dbedd  movaps xmm3, xmm1
00007fdcd91dbee0  mulpd xmm3, xmm9
00007fdcd91dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007fdcd91dbeea  ptest xmm15, xmm15
00007fdcd91dbef0  jnz 0x00007FDCD91DDB31
00007fdcd91dbef6  vmovaps xmm1, [rsp+0xF0]
00007fdcd91dbeff  vmovaps xmm15, [rsp+0xF0]
00007fdcd91dbf08  por xmm1, xmm15
00007fdcd91dbf0d  movaps [r15+0x300], xmm1
00007fdcd91dbf15  vmovaps xmm15, [rsp+0xE0]
00007fdcd91dbf1e  vmovaps xmm9, [rsp+0xE0]
00007fdcd91dbf27  por xmm15, xmm9
00007fdcd91dbf2c  movaps [r15+0x190], xmm15
00007fdcd91dbf34  vmovaps xmm9, [rsp+0x50]
00007fdcd91dbf3a  vpermilpd xmm9, xmm9, 0x00
00007fdcd91dbf40  vmovaps [rsp+0x90], xmm1
00007fdcd91dbf49  vmovaps [rsp+0xE0], xmm15
00007fdcd91dbf52  vmovaps xmm15, [rsp+0x80]
00007fdcd91dbf5b  vmovaps [rsp+0x80], xmm14
00007fdcd91dbf64  movaps xmm1, xmm15
00007fdcd91dbf68  mulpd xmm1, xmm9
00007fdcd91dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007fdcd91dbf72  ptest xmm14, xmm14
00007fdcd91dbf78  jnz 0x00007FDCD91DDC72
00007fdcd91dbf7e  lea r12, [rax+0x90]
00007fdcd91dbf85  movups xmm15, [r13+r12*1]
00007fdcd91dbf8b  vmovaps xmm14, [rsp+0xD0]
00007fdcd91dbf94  vmovaps xmm9, [rsp+0xD0]
00007fdcd91dbf9d  por xmm14, xmm9
00007fdcd91dbfa2  movaps [r15+0x1C0], xmm14
00007fdcd91dbfaa  vmovaps xmm9, [rsp+0xC0]
00007fdcd91dbfb3  vmovaps [rsp+0xD0], xmm1
00007fdcd91dbfbc  vmovaps xmm1, [rsp+0xC0]
00007fdcd91dbfc5  por xmm9, xmm1
00007fdcd91dbfca  movaps [r15+0x200], xmm9
00007fdcd91dbfd2  vmovaps [rsp+0xC0], xmm2
00007fdcd91dbfdb  vmovaps xmm1, [rsp+0xC0]
00007fdcd91dbfe4  por xmm2, xmm1
00007fdcd91dbfe8  movaps [r15+0x2D0], xmm2
00007fdcd91dbff0  vmovaps [rsp+0xC0], xmm8
00007fdcd91dbff9  vmovaps xmm1, [rsp+0xC0]
00007fdcd91dc002  por xmm8, xmm1
00007fdcd91dc007  movaps [r15+0x2E0], xmm8
00007fdcd91dc00f  vmovaps [rsp+0xC0], xmm15
00007fdcd91dc018  movaps xmm1, xmm5
00007fdcd91dc01b  addpd xmm1, xmm7
00007fdcd91dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007fdcd91dc024  ptest xmm15, xmm15
00007fdcd91dc02a  jnz 0x00007FDCD91DDDBE
00007fdcd91dc030  vmovaps xmm15, [rsp+0x50]
00007fdcd91dc036  vpermilpd xmm15, xmm15, 0x00
00007fdcd91dc03c  vmovaps xmm5, [rsp+0xC0]
00007fdcd91dc045  vmovaps [rsp+0xC0], xmm1
00007fdcd91dc04e  movaps xmm7, xmm5
00007fdcd91dc051  mulpd xmm7, xmm15
00007fdcd91dc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007fdcd91dc05b  ptest xmm1, xmm1
00007fdcd91dc060  jnz 0x00007FDCD91DDEFE
00007fdcd91dc066  lea r12, [rax+0x80]
00007fdcd91dc06d  movups xmm1, [r13+r12*1]
00007fdcd91dc073  vmovaps xmm5, [rsp+0x70]
00007fdcd91dc079  vmovaps [rsp+0x70], xmm1
00007fdcd91dc07f  movaps xmm15, xmm5
00007fdcd91dc083  addpd xmm15, xmm3
00007fdcd91dc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007fdcd91dc08e  ptest xmm1, xmm1
00007fdcd91dc093  jnz 0x00007FDCD91DE049
00007fdcd91dc099  vmovaps xmm5, [rsp+0x80]
00007fdcd91dc0a2  movaps xmm1, xmm5
00007fdcd91dc0a5  addpd xmm1, xmm4
00007fdcd91dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007fdcd91dc0ae  ptest xmm3, xmm3
00007fdcd91dc0b3  jnz 0x00007FDCD91DE18B
00007fdcd91dc0b9  vmovaps [rsp+0x80], xmm10
00007fdcd91dc0c2  vmovaps xmm5, [rsp+0x80]
00007fdcd91dc0cb  por xmm10, xmm5
00007fdcd91dc0d0  movaps [r15+0x2F0], xmm10
00007fdcd91dc0d8  vmovaps xmm5, [rsp+0x50]
00007fdcd91dc0de  vpermilpd xmm5, xmm5, 0x00
00007fdcd91dc0e4  vmovaps xmm3, [rsp+0x70]
00007fdcd91dc0ea  vmovaps [rsp+0x50], xmm1
00007fdcd91dc0f0  movaps xmm4, xmm3
00007fdcd91dc0f3  mulpd xmm4, xmm5
00007fdcd91dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007fdcd91dc0fc  ptest xmm1, xmm1
00007fdcd91dc101  jnz 0x00007FDCD91DE2CB
00007fdcd91dc107  lea r12, [rax+0xD0]
00007fdcd91dc10e  movups xmm1, [r13+r12*1]
00007fdcd91dc114  vmovaps xmm3, [rsp+0xD0]
00007fdcd91dc11d  vmovaps [rsp+0x70], xmm1
00007fdcd91dc123  movaps xmm5, xmm6
00007fdcd91dc126  addpd xmm5, xmm3
00007fdcd91dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007fdcd91dc12f  ptest xmm1, xmm1
00007fdcd91dc134  jnz 0x00007FDCD91DE415
00007fdcd91dc13a  vmovaps xmm1, [rsp+0x60]
00007fdcd91dc140  vpermilpd xmm1, xmm1, 0x00
00007fdcd91dc146  movaps xmm6, xmm9
00007fdcd91dc14a  mulpd xmm6, xmm1
00007fdcd91dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007fdcd91dc153  ptest xmm3, xmm3
00007fdcd91dc158  jnz 0x00007FDCD91DE555
00007fdcd91dc15e  movaps [r15+0x260], xmm6
00007fdcd91dc166  vxorps xmm1, xmm1, xmm1
00007fdcd91dc16a  vpbroadcastq xmm1, xmm1
00007fdcd91dc16f  movaps [r15+0x1B0], xmm1
00007fdcd91dc177  vmovaps xmm1, [rsp+0x60]
00007fdcd91dc17d  vpermilpd xmm1, xmm1, 0x00
00007fdcd91dc183  vmovaps xmm3, [rsp+0x70]
00007fdcd91dc189  vmovaps [rsp+0x70], xmm15
00007fdcd91dc18f  movaps xmm9, xmm3
00007fdcd91dc193  mulpd xmm9, xmm1
00007fdcd91dc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007fdcd91dc19e  ptest xmm15, xmm15
00007fdcd91dc1a4  jnz 0x00007FDCD91DE696
00007fdcd91dc1aa  lea r12, [rax+0xC0]
00007fdcd91dc1b1  movups xmm1, [r13+r12*1]
00007fdcd91dc1b7  vmovaps xmm3, [rsp+0xC0]
00007fdcd91dc1c0  vmovaps [rsp+0x80], xmm1
00007fdcd91dc1c9  movaps xmm15, xmm3
00007fdcd91dc1cd  addpd xmm15, xmm7
00007fdcd91dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007fdcd91dc1d8  ptest xmm1, xmm1
00007fdcd91dc1dd  jnz 0x00007FDCD91DE7E2
00007fdcd91dc1e3  vmovaps [rsp+0xC0], xmm13
00007fdcd91dc1ec  vmovaps xmm1, [rsp+0xC0]
00007fdcd91dc1f5  por xmm13, xmm1
00007fdcd91dc1fa  movaps [r15+0x270], xmm13
00007fdcd91dc202  vmovaps xmm1, [rsp+0xB0]
00007fdcd91dc20b  vmovaps xmm7, [rsp+0xB0]
00007fdcd91dc214  por xmm1, xmm7
00007fdcd91dc218  movaps [r15+0x1A0], xmm1
00007fdcd91dc220  vmovaps xmm1, [rsp+0x60]
00007fdcd91dc226  vpermilpd xmm1, xmm1, 0x00
00007fdcd91dc22c  vmovaps [rsp+0xB0], xmm1
00007fdcd91dc235  vmovaps xmm1, [rsp+0x80]
00007fdcd91dc23e  vmovaps [rsp+0x80], xmm15
00007fdcd91dc247  vmovaps xmm15, [rsp+0xB0]
00007fdcd91dc250  vmovaps [rsp+0xB0], xmm14
00007fdcd91dc259  movaps xmm3, xmm1
00007fdcd91dc25c  mulpd xmm3, xmm15
00007fdcd91dc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007fdcd91dc266  ptest xmm14, xmm14
00007fdcd91dc26c  jnz 0x00007FDCD91DE924
00007fdcd91dc272  lea r12, [rax+0x20]
00007fdcd91dc276  movups xmm1, [r13+r12*1]
00007fdcd91dc27c  movaps [r15+0x110], xmm1
00007fdcd91dc284  vmovaps xmm14, [rsp+0x70]
00007fdcd91dc28a  vmovaps [rsp+0x70], xmm1
00007fdcd91dc290  movaps xmm15, xmm14
00007fdcd91dc294  addpd xmm15, xmm4
00007fdcd91dc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007fdcd91dc29f  ptest xmm1, xmm1
00007fdcd91dc2a4  jnz 0x00007FDCD91DEA6F
00007fdcd91dc2aa  vmovaps xmm1, [rsp+0x60]
00007fdcd91dc2b0  vpermilpd xmm1, xmm1, 0x00
00007fdcd91dc2b6  movaps xmm14, xmm2
00007fdcd91dc2ba  mulpd xmm14, xmm1
00007fdcd91dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007fdcd91dc2c5  ptest xmm4, xmm4
00007fdcd91dc2ca  jnz 0x00007FDCD91DEBB2
00007fdcd91dc2d0  vmovaps xmm4, [rsp+0x50]
00007fdcd91dc2d6  movaps xmm1, xmm4
00007fdcd91dc2d9  addpd xmm1, xmm9
00007fdcd91dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007fdcd91dc2e3  ptest xmm2, xmm2
00007fdcd91dc2e8  jnz 0x00007FDCD91DECF4
00007fdcd91dc2ee  vmovaps xmm9, [rsp+0x30]
00007fdcd91dc2f4  vpermilpd xmm9, xmm9, 0x00
00007fdcd91dc2fa  vmovaps xmm2, [rsp+0x70]
00007fdcd91dc300  vmovaps [rsp+0x50], xmm1
00007fdcd91dc306  movaps xmm4, xmm2
00007fdcd91dc309  mulpd xmm4, xmm9
00007fdcd91dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007fdcd91dc313  ptest xmm1, xmm1
00007fdcd91dc318  jnz 0x00007FDCD91DEE35
00007fdcd91dc31e  vmovaps xmm1, [rsp+0x30]
00007fdcd91dc324  vpermilpd xmm1, xmm1, 0x00
00007fdcd91dc32a  vmovaps xmm2, [rsp+0x90]
00007fdcd91dc333  vmovaps [rsp+0x60], xmm15
00007fdcd91dc339  movaps xmm9, xmm2
00007fdcd91dc33d  mulpd xmm9, xmm1
00007fdcd91dc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007fdcd91dc348  ptest xmm15, xmm15
00007fdcd91dc34e  jnz 0x00007FDCD91DEF76
00007fdcd91dc354  vmovaps xmm15, [rsp+0x80]
00007fdcd91dc35d  movaps xmm1, xmm15
00007fdcd91dc361  addpd xmm1, xmm6
00007fdcd91dc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007fdcd91dc36a  ptest xmm2, xmm2
00007fdcd91dc36f  jnz 0x00007FDCD91DF0B8
00007fdcd91dc375  movaps xmm15, xmm5
00007fdcd91dc379  addpd xmm15, xmm3
00007fdcd91dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007fdcd91dc384  ptest xmm6, xmm6
00007fdcd91dc389  jnz 0x00007FDCD91DF1F9
00007fdcd91dc38f  vmovaps xmm6, [rsp+0x30]
00007fdcd91dc395  vpermilpd xmm6, xmm6, 0x00
00007fdcd91dc39b  movaps xmm5, xmm8
00007fdcd91dc39f  mulpd xmm5, xmm6
00007fdcd91dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007fdcd91dc3a8  ptest xmm3, xmm3
00007fdcd91dc3ad  jnz 0x00007FDCD91DF33B
00007fdcd91dc3b3  vmovaps xmm8, [rsp+0x30]
00007fdcd91dc3b9  vpermilpd xmm8, xmm8, 0x00
00007fdcd91dc3bf  movaps xmm6, xmm10
00007fdcd91dc3c3  mulpd xmm6, xmm8
00007fdcd91dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007fdcd91dc3cd  ptest xmm3, xmm3
00007fdcd91dc3d2  jnz 0x00007FDCD91DF47C
00007fdcd91dc3d8  vmovaps xmm8, [rsp+0x60]
00007fdcd91dc3de  movaps xmm10, xmm8
00007fdcd91dc3e2  addpd xmm10, xmm14
00007fdcd91dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007fdcd91dc3ed  ptest xmm3, xmm3
00007fdcd91dc3f2  jnz 0x00007FDCD91DF5BE
00007fdcd91dc3f8  vmovaps xmm8, [rsp+0x50]
00007fdcd91dc3fe  movaps xmm14, xmm8
00007fdcd91dc402  addpd xmm14, xmm4
00007fdcd91dc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007fdcd91dc40d  ptest xmm3, xmm3
00007fdcd91dc412  jnz 0x00007FDCD91DF702
00007fdcd91dc418  vmovaps xmm8, [rsp+0x40]
00007fdcd91dc41e  vpermilpd xmm8, xmm8, 0x00
00007fdcd91dc424  movaps xmm4, xmm13
00007fdcd91dc428  mulpd xmm4, xmm8
00007fdcd91dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007fdcd91dc432  ptest xmm3, xmm3
00007fdcd91dc437  jnz 0x00007FDCD91DF845
00007fdcd91dc43d  movaps xmm13, xmm15
00007fdcd91dc441  addpd xmm13, xmm9
00007fdcd91dc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007fdcd91dc44c  ptest xmm8, xmm8
00007fdcd91dc452  jnz 0x00007FDCD91DF987
00007fdcd91dc458  movaps xmm15, xmm1
00007fdcd91dc45c  addpd xmm15, xmm5
00007fdcd91dc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007fdcd91dc467  ptest xmm9, xmm9
00007fdcd91dc46d  jnz 0x00007FDCD91DFACB
00007fdcd91dc473  vmovaps [rsp+0x30], xmm11
00007fdcd91dc479  vmovaps xmm1, [rsp+0x30]
00007fdcd91dc47f  por xmm11, xmm1
00007fdcd91dc484  movaps [r15+0x250], xmm11
00007fdcd91dc48c  vmovaps [rsp+0x30], xmm12
00007fdcd91dc492  vmovaps xmm1, [rsp+0x30]
00007fdcd91dc498  por xmm12, xmm1
00007fdcd91dc49d  movaps [r15+0x2A0], xmm12
00007fdcd91dc4a5  vmovaps xmm1, [rsp+0xA0]
00007fdcd91dc4ae  vmovaps xmm11, [rsp+0xA0]
00007fdcd91dc4b7  por xmm1, xmm11
00007fdcd91dc4bc  movaps [r15+0x1D0], xmm1
00007fdcd91dc4c4  lea r12, [rax+0x40]
00007fdcd91dc4c8  movups xmm1, [r13+r12*1]
00007fdcd91dc4ce  movaps [r15+0x2C0], xmm1
00007fdcd91dc4d6  vmovaps xmm11, [rsp+0x40]
00007fdcd91dc4dc  vpermilpd xmm11, xmm11, 0x00
00007fdcd91dc4e2  vmovaps xmm8, [rsp+0xE0]
00007fdcd91dc4eb  movaps xmm9, xmm8
00007fdcd91dc4ef  mulpd xmm9, xmm11
00007fdcd91dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007fdcd91dc4fa  ptest xmm5, xmm5
00007fdcd91dc4ff  jnz 0x00007FDCD91DFC17
00007fdcd91dc505  movaps xmm11, xmm10
00007fdcd91dc509  addpd xmm11, xmm6
00007fdcd91dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007fdcd91dc514  ptest xmm8, xmm8
00007fdcd91dc51a  jnz 0x00007FDCD91DFD5B
00007fdcd91dc520  movaps xmm10, xmm14
00007fdcd91dc524  addpd xmm10, xmm4
00007fdcd91dc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007fdcd91dc52f  ptest xmm8, xmm8
00007fdcd91dc535  jnz 0x00007FDCD91DFE9E
00007fdcd91dc53b  vmovaps xmm14, [rsp+0x40]
00007fdcd91dc541  vpermilpd xmm14, xmm14, 0x00
00007fdcd91dc547  movaps xmm8, xmm1
00007fdcd91dc54b  mulpd xmm8, xmm14
00007fdcd91dc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007fdcd91dc556  ptest xmm6, xmm6
00007fdcd91dc55b  jnz 0x00007FDCD91DFFE1
00007fdcd91dc561  movaps xmm1, [r15+0x2B0]
00007fdcd91dc569  vmovaps xmm14, [rsp+0x40]
00007fdcd91dc56f  vpermilpd xmm14, xmm14, 0x00
00007fdcd91dc575  movaps xmm6, xmm1
00007fdcd91dc578  mulpd xmm6, xmm14
00007fdcd91dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007fdcd91dc582  ptest xmm5, xmm5
00007fdcd91dc587  jnz 0x00007FDCD91E0124
00007fdcd91dc58d  vmovaps xmm1, [rsp+0x10]
00007fdcd91dc593  vpermilpd xmm1, xmm1, 0x00
00007fdcd91dc599  movaps xmm14, xmm12
00007fdcd91dc59d  mulpd xmm14, xmm1
00007fdcd91dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007fdcd91dc5a8  ptest xmm5, xmm5
00007fdcd91dc5ad  jnz 0x00007FDCD91E0265
00007fdcd91dc5b3  movaps xmm1, xmm13
00007fdcd91dc5b7  addpd xmm1, xmm9
00007fdcd91dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007fdcd91dc5c1  ptest xmm12, xmm12
00007fdcd91dc5c7  jnz 0x00007FDCD91E03A8
00007fdcd91dc5cd  vmovaps xmm13, [rsp+0x10]
00007fdcd91dc5d3  vpermilpd xmm13, xmm13, 0x00
00007fdcd91dc5d9  movaps xmm12, xmm7
00007fdcd91dc5dd  mulpd xmm12, xmm13
00007fdcd91dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007fdcd91dc5e8  ptest xmm9, xmm9
00007fdcd91dc5ee  jnz 0x00007FDCD91E04EA
00007fdcd91dc5f4  movaps xmm13, xmm15
00007fdcd91dc5f8  addpd xmm13, xmm8
00007fdcd91dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007fdcd91dc603  ptest xmm9, xmm9
00007fdcd91dc609  jnz 0x00007FDCD91E062D
00007fdcd91dc60f  movaps xmm15, [r15+0x290]
00007fdcd91dc617  vmovaps xmm9, [rsp+0x10]
00007fdcd91dc61d  vpermilpd xmm9, xmm9, 0x00
00007fdcd91dc623  movaps xmm8, xmm15
00007fdcd91dc627  mulpd xmm8, xmm9
00007fdcd91dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007fdcd91dc632  ptest xmm7, xmm7
00007fdcd91dc637  jnz 0x00007FDCD91E0771
00007fdcd91dc63d  movaps xmm15, xmm11
00007fdcd91dc641  addpd xmm15, xmm6
00007fdcd91dc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007fdcd91dc64c  ptest xmm9, xmm9
00007fdcd91dc652  jnz 0x00007FDCD91E08B5
00007fdcd91dc658  movaps xmm11, [r15+0x1E0]
00007fdcd91dc660  vmovaps xmm9, [rsp+0x10]
00007fdcd91dc666  vpermilpd xmm9, xmm9, 0x00
00007fdcd91dc66c  movaps xmm7, xmm11
00007fdcd91dc670  mulpd xmm7, xmm9
00007fdcd91dc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007fdcd91dc67a  ptest xmm6, xmm6
00007fdcd91dc67f  jnz 0x00007FDCD91E09F8
00007fdcd91dc685  movaps xmm11, xmm10
00007fdcd91dc689  addpd xmm11, xmm14
00007fdcd91dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007fdcd91dc694  ptest xmm9, xmm9
00007fdcd91dc69a  jnz 0x00007FDCD91E0B3A
00007fdcd91dc6a0  lea r12, [rax+0x70]
00007fdcd91dc6a4  movups xmm14, [r13+r12*1]
00007fdcd91dc6aa  movaps [r15+0x240], xmm14
00007fdcd91dc6b2  movaps xmm10, xmm1
00007fdcd91dc6b6  addpd xmm10, xmm12
00007fdcd91dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007fdcd91dc6c1  ptest xmm9, xmm9
00007fdcd91dc6c7  jnz 0x00007FDCD91E0C88
00007fdcd91dc6cd  movaps [r15+0x170], xmm10
00007fdcd91dc6d5  vmovaps xmm1, [rsp+0x20]
00007fdcd91dc6db  vpermilpd xmm1, xmm1, 0x00
00007fdcd91dc6e1  movaps xmm12, xmm14
00007fdcd91dc6e5  mulpd xmm12, xmm1
00007fdcd91dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007fdcd91dc6f0  ptest xmm9, xmm9
00007fdcd91dc6f6  jnz 0x00007FDCD91E0DCB
00007fdcd91dc6fc  vmovaps xmm1, [rsp+0x20]
00007fdcd91dc702  vpermilpd xmm1, xmm1, 0x00
00007fdcd91dc708  vmovaps xmm9, [rsp+0xB0]
00007fdcd91dc711  movaps xmm14, xmm9
00007fdcd91dc715  mulpd xmm14, xmm1
00007fdcd91dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007fdcd91dc720  ptest xmm6, xmm6
00007fdcd91dc725  jnz 0x00007FDCD91E0F0E
00007fdcd91dc72b  movaps [r15+0x180], xmm14
00007fdcd91dc733  movaps xmm1, xmm13
00007fdcd91dc737  addpd xmm1, xmm8
00007fdcd91dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007fdcd91dc741  ptest xmm9, xmm9
00007fdcd91dc747  jnz 0x00007FDCD91E1051
00007fdcd91dc74d  movaps [r15+0x210], xmm1
00007fdcd91dc755  movups xmm13, [r13+rax*1]
00007fdcd91dc75b  lea r12, [rax+0x10]
00007fdcd91dc75f  movups xmm9, [r13+r12*1]
00007fdcd91dc765  movaps [r15+0x230], xmm9
00007fdcd91dc76d  movaps xmm8, xmm15
00007fdcd91dc771  addpd xmm8, xmm7
00007fdcd91dc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007fdcd91dc77c  ptest xmm6, xmm6
00007fdcd91dc781  jnz 0x00007FDCD91E11A7
00007fdcd91dc787  movaps [r15+0x130], xmm8
00007fdcd91dc78f  vmovaps xmm15, [rsp+0x20]
00007fdcd91dc795  vpermilpd xmm15, xmm15, 0x00
00007fdcd91dc79b  movaps xmm7, xmm9
00007fdcd91dc79f  mulpd xmm7, xmm15
00007fdcd91dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007fdcd91dc7a9  ptest xmm6, xmm6
00007fdcd91dc7ae  jnz 0x00007FDCD91E12EA
00007fdcd91dc7b4  movaps [r15+0x220], xmm7
00007fdcd91dc7bc  vmovaps xmm15, [rsp+0x20]
00007fdcd91dc7c2  vpermilpd xmm15, xmm15, 0x00
00007fdcd91dc7c8  movaps xmm9, xmm13
00007fdcd91dc7cc  mulpd xmm9, xmm15
00007fdcd91dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007fdcd91dc7d7  ptest xmm6, xmm6
00007fdcd91dc7dc  jnz 0x00007FDCD91E142C
00007fdcd91dc7e2  movaps xmm15, xmm11
00007fdcd91dc7e6  addpd xmm15, xmm12
00007fdcd91dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007fdcd91dc7f1  ptest xmm13, xmm13
00007fdcd91dc7f7  jnz 0x00007FDCD91E1570
00007fdcd91dc7fd  movaps [r15+0x140], xmm15
00007fdcd91dc805  movaps xmm13, xmm10
00007fdcd91dc809  addpd xmm13, xmm14
00007fdcd91dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007fdcd91dc814  ptest xmm12, xmm12
00007fdcd91dc81a  jnz 0x00007FDCD91E16B4
00007fdcd91dc820  movaps [r15+0x150], xmm13
00007fdcd91dc828  movaps xmm14, xmm1
00007fdcd91dc82c  addpd xmm14, xmm7
00007fdcd91dc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007fdcd91dc837  ptest xmm12, xmm12
00007fdcd91dc83d  jnz 0x00007FDCD91E17F8
00007fdcd91dc843  movaps [r15+0x160], xmm14
00007fdcd91dc84b  movaps xmm1, xmm8
00007fdcd91dc84f  addpd xmm1, xmm9
00007fdcd91dc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007fdcd91dc859  ptest xmm12, xmm12
00007fdcd91dc85f  jnz 0x00007FDCD91E193A
00007fdcd91dc865  movaps [r15+0x120], xmm1
00007fdcd91dc86d  movups [r13+r14*1], xmm15
00007fdcd91dc873  lea rax, [r14+0x10]
00007fdcd91dc877  movups [r13+rax*1], xmm13
00007fdcd91dc87d  lea rax, [r14+0x20]
00007fdcd91dc881  movups [r13+rax*1], xmm14
00007fdcd91dc887  lea rax, [r14+0x30]
00007fdcd91dc88b  movups [r13+rax*1], xmm1
00007fdcd91dc891  mov eax, [r15+0x108]
00007fdcd91dc898  sahf
00007fdcd91dc899  jnz 0x00007FDCD91DC8CB
00007fdcd91dc89b  cmp dword ptr [r15+0x318], 0x00
00007fdcd91dc8a3  jz 0x00007FDCD91DB900
00007fdcd91dc8a9  nop [rax+rax*1], ax
00007fdcd91dc8b2  nop [rax+rax*1], eax
00007fdcd91dc8ba  mov eax, 0x410444
00007fdcd91dc8bf  mov [r15+0x100], rax
00007fdcd91dc8c6  jmp 0x00007FDCD8FFE110
00007fdcd91dc8cb  cmp dword ptr [r15+0x318], 0x00
00007fdcd91dc8d3  jz 0x00007FDCD91D57E0
00007fdcd91dc8d9  nop [rax+rax*1], ax
00007fdcd91dc8e2  nop [rax+rax*1], eax
00007fdcd91dc8ea  mov eax, 0x410278
00007fdcd91dc8ef  mov [r15+0x100], rax
00007fdcd91dc8f6  jmp 0x00007FDCD8FFE110
00007fdcd91dc8fb  int3
00007fdcd91dc8fc  call 0x00007FDCD90E27E0
00007fdcd91dc901  jmp 0x00007FDCD91DB9DF
00007fdcd91dc906  call 0x00007FDCD90E1570
00007fdcd91dc90b  jmp 0x00007FDCD91DB9E8
00007fdcd91dc910  call 0x00007FDCD90E27E0
00007fdcd91dc915  jmp 0x00007FDCD91DBA44
00007fdcd91dc91a  call 0x00007FDCD90E1570
00007fdcd91dc91f  jmp 0x00007FDCD91DBA4D
00007fdcd91dc924  call 0x00007FDCD90E27E0
00007fdcd91dc929  jmp 0x00007FDCD91DBA90
00007fdcd91dc92e  call 0x00007FDCD90E1570
00007fdcd91dc933  jmp 0x00007FDCD91DBA99
00007fdcd91dc938  call 0x00007FDCD900DC20
00007fdcd91dc93d  jmp 0x00007FDCD91DBAD8
00007fdcd91dc942  call 0x00007FDCD90D59C0
00007fdcd91dc947  jmp 0x00007FDCD91DBAEB
00007fdcd91dc94c  call 0x00007FDCD90E0E30
00007fdcd91dc951  jmp 0x00007FDCD91DBB09
00007fdcd91dc956  call 0x00007FDCD90DFBC0
00007fdcd91dc95b  jmp 0x00007FDCD91DBB13
00007fdcd91dc960  call 0x00007FDCD90DE950
00007fdcd91dc965  jmp 0x00007FDCD91DBB1D
00007fdcd91dc96a  sub rsp, 0x08
00007fdcd91dc96e  push rax
00007fdcd91dc96f  push rcx
00007fdcd91dc970  push rdx
00007fdcd91dc971  push rdi
00007fdcd91dc972  push rsi
00007fdcd91dc973  push r8
00007fdcd91dc975  push r9
00007fdcd91dc977  push r10
00007fdcd91dc979  push r11
00007fdcd91dc97b  sub rsp, 0xF0
00007fdcd91dc982  vmovaps [rsp], xmm0
00007fdcd91dc987  vmovaps [rsp+0x10], xmm1
00007fdcd91dc98d  vmovaps [rsp+0x20], xmm2
00007fdcd91dc993  vmovaps [rsp+0x30], xmm3
00007fdcd91dc999  vmovaps [rsp+0x40], xmm4
00007fdcd91dc99f  vmovaps [rsp+0x50], xmm5
00007fdcd91dc9a5  vmovaps [rsp+0x60], xmm6
00007fdcd91dc9ab  vmovaps [rsp+0x70], xmm7
00007fdcd91dc9b1  vmovaps [rsp+0x80], xmm9
00007fdcd91dc9ba  vmovaps [rsp+0x90], xmm10
00007fdcd91dc9c3  vmovaps [rsp+0xA0], xmm11
00007fdcd91dc9cc  vmovaps [rsp+0xB0], xmm12
00007fdcd91dc9d5  vmovaps [rsp+0xC0], xmm13
00007fdcd91dc9de  vmovaps [rsp+0xD0], xmm14
00007fdcd91dc9e7  vmovaps [rsp+0xE0], xmm15
00007fdcd91dc9f0  sub rsp, 0x30
00007fdcd91dc9f4  movaps [rsp], xmm8
00007fdcd91dc9f9  movaps [rsp+0x10], xmm12
00007fdcd91dc9ff  movaps [rsp+0x20], xmm15
00007fdcd91dca05  lea rdi, [rsp]
00007fdcd91dca09  mov esi, 0x00
00007fdcd91dca0e  mov rax, 0x5B56EFBF3530
00007fdcd91dca18  call rax
00007fdcd91dca1a  movaps xmm8, [rsp]
00007fdcd91dca1f  add rsp, 0x30
00007fdcd91dca23  vmovaps xmm0, [rsp]
00007fdcd91dca28  vmovaps xmm1, [rsp+0x10]
00007fdcd91dca2e  vmovaps xmm2, [rsp+0x20]
00007fdcd91dca34  vmovaps xmm3, [rsp+0x30]
00007fdcd91dca3a  vmovaps xmm4, [rsp+0x40]
00007fdcd91dca40  vmovaps xmm5, [rsp+0x50]
00007fdcd91dca46  vmovaps xmm6, [rsp+0x60]
00007fdcd91dca4c  vmovaps xmm7, [rsp+0x70]
00007fdcd91dca52  vmovaps xmm9, [rsp+0x80]
00007fdcd91dca5b  vmovaps xmm10, [rsp+0x90]
00007fdcd91dca64  vmovaps xmm11, [rsp+0xA0]
00007fdcd91dca6d  vmovaps xmm12, [rsp+0xB0]
00007fdcd91dca76  vmovaps xmm13, [rsp+0xC0]
00007fdcd91dca7f  vmovaps xmm14, [rsp+0xD0]
00007fdcd91dca88  vmovaps xmm15, [rsp+0xE0]
00007fdcd91dca91  add rsp, 0xF0
00007fdcd91dca98  pop r11
00007fdcd91dca9a  pop r10
00007fdcd91dca9c  pop r9
00007fdcd91dca9e  pop r8
00007fdcd91dcaa0  pop rsi
00007fdcd91dcaa1  pop rdi
00007fdcd91dcaa2  pop rdx
00007fdcd91dcaa3  pop rcx
00007fdcd91dcaa4  pop rax
00007fdcd91dcaa5  add rsp, 0x08
00007fdcd91dcaa9  jmp 0x00007FDCD91DBB47
00007fdcd91dcaae  sub rsp, 0x08
00007fdcd91dcab2  push rax
00007fdcd91dcab3  push rcx
00007fdcd91dcab4  push rdx
00007fdcd91dcab5  push rdi
00007fdcd91dcab6  push rsi
00007fdcd91dcab7  push r8
00007fdcd91dcab9  push r9
00007fdcd91dcabb  push r10
00007fdcd91dcabd  push r11
00007fdcd91dcabf  sub rsp, 0xF0
00007fdcd91dcac6  vmovaps [rsp], xmm0
00007fdcd91dcacb  vmovaps [rsp+0x10], xmm1
00007fdcd91dcad1  vmovaps [rsp+0x20], xmm2
00007fdcd91dcad7  vmovaps [rsp+0x30], xmm3
00007fdcd91dcadd  vmovaps [rsp+0x40], xmm4
00007fdcd91dcae3  vmovaps [rsp+0x50], xmm5
00007fdcd91dcae9  vmovaps [rsp+0x60], xmm6
00007fdcd91dcaef  vmovaps [rsp+0x70], xmm8
00007fdcd91dcaf5  vmovaps [rsp+0x80], xmm9
00007fdcd91dcafe  vmovaps [rsp+0x90], xmm10
00007fdcd91dcb07  vmovaps [rsp+0xA0], xmm11
00007fdcd91dcb10  vmovaps [rsp+0xB0], xmm12
00007fdcd91dcb19  vmovaps [rsp+0xC0], xmm13
00007fdcd91dcb22  vmovaps [rsp+0xD0], xmm14
00007fdcd91dcb2b  vmovaps [rsp+0xE0], xmm15
00007fdcd91dcb34  sub rsp, 0x30
00007fdcd91dcb38  movaps [rsp], xmm7
00007fdcd91dcb3c  movaps [rsp+0x10], xmm9
00007fdcd91dcb42  movaps [rsp+0x20], xmm15
00007fdcd91dcb48  lea rdi, [rsp]
00007fdcd91dcb4c  mov esi, 0x00
00007fdcd91dcb51  mov rax, 0x5B56EFBF3530
00007fdcd91dcb5b  call rax
00007fdcd91dcb5d  movaps xmm7, [rsp]
00007fdcd91dcb61  add rsp, 0x30
00007fdcd91dcb65  vmovaps xmm0, [rsp]
00007fdcd91dcb6a  vmovaps xmm1, [rsp+0x10]
00007fdcd91dcb70  vmovaps xmm2, [rsp+0x20]
00007fdcd91dcb76  vmovaps xmm3, [rsp+0x30]
00007fdcd91dcb7c  vmovaps xmm4, [rsp+0x40]
00007fdcd91dcb82  vmovaps xmm5, [rsp+0x50]
00007fdcd91dcb88  vmovaps xmm6, [rsp+0x60]
00007fdcd91dcb8e  vmovaps xmm8, [rsp+0x70]
00007fdcd91dcb94  vmovaps xmm9, [rsp+0x80]
00007fdcd91dcb9d  vmovaps xmm10, [rsp+0x90]
00007fdcd91dcba6  vmovaps xmm11, [rsp+0xA0]
00007fdcd91dcbaf  vmovaps xmm12, [rsp+0xB0]
00007fdcd91dcbb8  vmovaps xmm13, [rsp+0xC0]
00007fdcd91dcbc1  vmovaps xmm14, [rsp+0xD0]
00007fdcd91dcbca  vmovaps xmm15, [rsp+0xE0]
00007fdcd91dcbd3  add rsp, 0xF0
00007fdcd91dcbda  pop r11
00007fdcd91dcbdc  pop r10
00007fdcd91dcbde  pop r9
00007fdcd91dcbe0  pop r8
00007fdcd91dcbe2  pop rsi
00007fdcd91dcbe3  pop rdi
00007fdcd91dcbe4  pop rdx
00007fdcd91dcbe5  pop rcx
00007fdcd91dcbe6  pop rax
00007fdcd91dcbe7  add rsp, 0x08
00007fdcd91dcbeb  jmp 0x00007FDCD91DBB75
00007fdcd91dcbf0  sub rsp, 0x08
00007fdcd91dcbf4  push rax
00007fdcd91dcbf5  push rcx
00007fdcd91dcbf6  push rdx
00007fdcd91dcbf7  push rdi
00007fdcd91dcbf8  push rsi
00007fdcd91dcbf9  push r8
00007fdcd91dcbfb  push r9
00007fdcd91dcbfd  push r10
00007fdcd91dcbff  push r11
00007fdcd91dcc01  sub rsp, 0xF0
00007fdcd91dcc08  vmovaps [rsp], xmm0
00007fdcd91dcc0d  vmovaps [rsp+0x10], xmm1
00007fdcd91dcc13  vmovaps [rsp+0x20], xmm2
00007fdcd91dcc19  vmovaps [rsp+0x30], xmm3
00007fdcd91dcc1f  vmovaps [rsp+0x40], xmm4
00007fdcd91dcc25  vmovaps [rsp+0x50], xmm5
00007fdcd91dcc2b  vmovaps [rsp+0x60], xmm6
00007fdcd91dcc31  vmovaps [rsp+0x70], xmm7
00007fdcd91dcc37  vmovaps [rsp+0x80], xmm8
00007fdcd91dcc40  vmovaps [rsp+0x90], xmm10
00007fdcd91dcc49  vmovaps [rsp+0xA0], xmm11
00007fdcd91dcc52  vmovaps [rsp+0xB0], xmm12
00007fdcd91dcc5b  vmovaps [rsp+0xC0], xmm13
00007fdcd91dcc64  vmovaps [rsp+0xD0], xmm14
00007fdcd91dcc6d  vmovaps [rsp+0xE0], xmm15
00007fdcd91dcc76  sub rsp, 0x30
00007fdcd91dcc7a  movaps [rsp], xmm9
00007fdcd91dcc7f  movaps [rsp+0x10], xmm12
00007fdcd91dcc85  movaps [rsp+0x20], xmm10
00007fdcd91dcc8b  lea rdi, [rsp]
00007fdcd91dcc8f  mov esi, 0x00
00007fdcd91dcc94  mov rax, 0x5B56EFBF3530
00007fdcd91dcc9e  call rax
00007fdcd91dcca0  movaps xmm9, [rsp]
00007fdcd91dcca5  add rsp, 0x30
00007fdcd91dcca9  vmovaps xmm0, [rsp]
00007fdcd91dccae  vmovaps xmm1, [rsp+0x10]
00007fdcd91dccb4  vmovaps xmm2, [rsp+0x20]
00007fdcd91dccba  vmovaps xmm3, [rsp+0x30]
00007fdcd91dccc0  vmovaps xmm4, [rsp+0x40]
00007fdcd91dccc6  vmovaps xmm5, [rsp+0x50]
00007fdcd91dcccc  vmovaps xmm6, [rsp+0x60]
00007fdcd91dccd2  vmovaps xmm7, [rsp+0x70]
00007fdcd91dccd8  vmovaps xmm8, [rsp+0x80]
00007fdcd91dcce1  vmovaps xmm10, [rsp+0x90]
00007fdcd91dccea  vmovaps xmm11, [rsp+0xA0]
00007fdcd91dccf3  vmovaps xmm12, [rsp+0xB0]
00007fdcd91dccfc  vmovaps xmm13, [rsp+0xC0]
00007fdcd91dcd05  vmovaps xmm14, [rsp+0xD0]
00007fdcd91dcd0e  vmovaps xmm15, [rsp+0xE0]
00007fdcd91dcd17  add rsp, 0xF0
00007fdcd91dcd1e  pop r11
00007fdcd91dcd20  pop r10
00007fdcd91dcd22  pop r9
00007fdcd91dcd24  pop r8
00007fdcd91dcd26  pop rsi
00007fdcd91dcd27  pop rdi
00007fdcd91dcd28  pop rdx
00007fdcd91dcd29  pop rcx
00007fdcd91dcd2a  pop rax
00007fdcd91dcd2b  add rsp, 0x08
00007fdcd91dcd2f  jmp 0x00007FDCD91DBB99
00007fdcd91dcd34  sub rsp, 0x08
00007fdcd91dcd38  push rax
00007fdcd91dcd39  push rcx
00007fdcd91dcd3a  push rdx
00007fdcd91dcd3b  push rdi
00007fdcd91dcd3c  push rsi
00007fdcd91dcd3d  push r8
00007fdcd91dcd3f  push r9
00007fdcd91dcd41  push r10
00007fdcd91dcd43  push r11
00007fdcd91dcd45  sub rsp, 0xF0
00007fdcd91dcd4c  vmovaps [rsp], xmm0
00007fdcd91dcd51  vmovaps [rsp+0x10], xmm1
00007fdcd91dcd57  vmovaps [rsp+0x20], xmm2
00007fdcd91dcd5d  vmovaps [rsp+0x30], xmm3
00007fdcd91dcd63  vmovaps [rsp+0x40], xmm4
00007fdcd91dcd69  vmovaps [rsp+0x50], xmm5
00007fdcd91dcd6f  vmovaps [rsp+0x60], xmm6
00007fdcd91dcd75  vmovaps [rsp+0x70], xmm7
00007fdcd91dcd7b  vmovaps [rsp+0x80], xmm8
00007fdcd91dcd84  vmovaps [rsp+0x90], xmm9
00007fdcd91dcd8d  vmovaps [rsp+0xA0], xmm11
00007fdcd91dcd96  vmovaps [rsp+0xB0], xmm12
00007fdcd91dcd9f  vmovaps [rsp+0xC0], xmm13
00007fdcd91dcda8  vmovaps [rsp+0xD0], xmm14
00007fdcd91dcdb1  vmovaps [rsp+0xE0], xmm15
00007fdcd91dcdba  sub rsp, 0x30
00007fdcd91dcdbe  movaps [rsp], xmm10
00007fdcd91dcdc3  movaps [rsp+0x10], xmm12
00007fdcd91dcdc9  movaps [rsp+0x20], xmm11
00007fdcd91dcdcf  lea rdi, [rsp]
00007fdcd91dcdd3  mov esi, 0x00
00007fdcd91dcdd8  mov rax, 0x5B56EFBF3530
00007fdcd91dcde2  call rax
00007fdcd91dcde4  movaps xmm10, [rsp]
00007fdcd91dcde9  add rsp, 0x30
00007fdcd91dcded  vmovaps xmm0, [rsp]
00007fdcd91dcdf2  vmovaps xmm1, [rsp+0x10]
00007fdcd91dcdf8  vmovaps xmm2, [rsp+0x20]
00007fdcd91dcdfe  vmovaps xmm3, [rsp+0x30]
00007fdcd91dce04  vmovaps xmm4, [rsp+0x40]
00007fdcd91dce0a  vmovaps xmm5, [rsp+0x50]
00007fdcd91dce10  vmovaps xmm6, [rsp+0x60]
00007fdcd91dce16  vmovaps xmm7, [rsp+0x70]
00007fdcd91dce1c  vmovaps xmm8, [rsp+0x80]
00007fdcd91dce25  vmovaps xmm9, [rsp+0x90]
00007fdcd91dce2e  vmovaps xmm11, [rsp+0xA0]
00007fdcd91dce37  vmovaps xmm12, [rsp+0xB0]
00007fdcd91dce40  vmovaps xmm13, [rsp+0xC0]
00007fdcd91dce49  vmovaps xmm14, [rsp+0xD0]
00007fdcd91dce52  vmovaps xmm15, [rsp+0xE0]
00007fdcd91dce5b  add rsp, 0xF0
00007fdcd91dce62  pop r11
00007fdcd91dce64  pop r10
00007fdcd91dce66  pop r9
00007fdcd91dce68  pop r8
00007fdcd91dce6a  pop rsi
00007fdcd91dce6b  pop rdi
00007fdcd91dce6c  pop rdx
00007fdcd91dce6d  pop rcx
00007fdcd91dce6e  pop rax
00007fdcd91dce6f  add rsp, 0x08
00007fdcd91dce73  jmp 0x00007FDCD91DBBB3
00007fdcd91dce78  sub rsp, 0x08
00007fdcd91dce7c  push rax
00007fdcd91dce7d  push rcx
00007fdcd91dce7e  push rdx
00007fdcd91dce7f  push rdi
00007fdcd91dce80  push rsi
00007fdcd91dce81  push r8
00007fdcd91dce83  push r9
00007fdcd91dce85  push r10
00007fdcd91dce87  push r11
00007fdcd91dce89  sub rsp, 0xF0
00007fdcd91dce90  vmovaps [rsp], xmm0
00007fdcd91dce95  vmovaps [rsp+0x10], xmm1
00007fdcd91dce9b  vmovaps [rsp+0x20], xmm2
00007fdcd91dcea1  vmovaps [rsp+0x30], xmm3
00007fdcd91dcea7  vmovaps [rsp+0x40], xmm4
00007fdcd91dcead  vmovaps [rsp+0x50], xmm5
00007fdcd91dceb3  vmovaps [rsp+0x60], xmm7
00007fdcd91dceb9  vmovaps [rsp+0x70], xmm8
00007fdcd91dcebf  vmovaps [rsp+0x80], xmm9
00007fdcd91dcec8  vmovaps [rsp+0x90], xmm10
00007fdcd91dced1  vmovaps [rsp+0xA0], xmm11
00007fdcd91dceda  vmovaps [rsp+0xB0], xmm12
00007fdcd91dcee3  vmovaps [rsp+0xC0], xmm13
00007fdcd91dceec  vmovaps [rsp+0xD0], xmm14
00007fdcd91dcef5  vmovaps [rsp+0xE0], xmm15
00007fdcd91dcefe  sub rsp, 0x30
00007fdcd91dcf02  movaps [rsp], xmm6
00007fdcd91dcf06  movaps [rsp+0x10], xmm12
00007fdcd91dcf0c  movaps [rsp+0x20], xmm11
00007fdcd91dcf12  lea rdi, [rsp]
00007fdcd91dcf16  mov esi, 0x00
00007fdcd91dcf1b  mov rax, 0x5B56EFBF3530
00007fdcd91dcf25  call rax
00007fdcd91dcf27  movaps xmm6, [rsp]
00007fdcd91dcf2b  add rsp, 0x30
00007fdcd91dcf2f  vmovaps xmm0, [rsp]
00007fdcd91dcf34  vmovaps xmm1, [rsp+0x10]
00007fdcd91dcf3a  vmovaps xmm2, [rsp+0x20]
00007fdcd91dcf40  vmovaps xmm3, [rsp+0x30]
00007fdcd91dcf46  vmovaps xmm4, [rsp+0x40]
00007fdcd91dcf4c  vmovaps xmm5, [rsp+0x50]
00007fdcd91dcf52  vmovaps xmm7, [rsp+0x60]
00007fdcd91dcf58  vmovaps xmm8, [rsp+0x70]
00007fdcd91dcf5e  vmovaps xmm9, [rsp+0x80]
00007fdcd91dcf67  vmovaps xmm10, [rsp+0x90]
00007fdcd91dcf70  vmovaps xmm11, [rsp+0xA0]
00007fdcd91dcf79  vmovaps xmm12, [rsp+0xB0]
00007fdcd91dcf82  vmovaps xmm13, [rsp+0xC0]
00007fdcd91dcf8b  vmovaps xmm14, [rsp+0xD0]
00007fdcd91dcf94  vmovaps xmm15, [rsp+0xE0]
00007fdcd91dcf9d  add rsp, 0xF0
00007fdcd91dcfa4  pop r11
00007fdcd91dcfa6  pop r10
00007fdcd91dcfa8  pop r9
00007fdcd91dcfaa  pop r8
00007fdcd91dcfac  pop rsi
00007fdcd91dcfad  pop rdi
00007fdcd91dcfae  pop rdx
00007fdcd91dcfaf  pop rcx
00007fdcd91dcfb0  pop rax
00007fdcd91dcfb1  add rsp, 0x08
00007fdcd91dcfb5  jmp 0x00007FDCD91DBBD4
00007fdcd91dcfba  sub rsp, 0x08
00007fdcd91dcfbe  push rax
00007fdcd91dcfbf  push rcx
00007fdcd91dcfc0  push rdx
00007fdcd91dcfc1  push rdi
00007fdcd91dcfc2  push rsi
00007fdcd91dcfc3  push r8
00007fdcd91dcfc5  push r9
00007fdcd91dcfc7  push r10
00007fdcd91dcfc9  push r11
00007fdcd91dcfcb  sub rsp, 0xF0
00007fdcd91dcfd2  vmovaps [rsp], xmm0
00007fdcd91dcfd7  vmovaps [rsp+0x10], xmm1
00007fdcd91dcfdd  vmovaps [rsp+0x20], xmm2
00007fdcd91dcfe3  vmovaps [rsp+0x30], xmm4
00007fdcd91dcfe9  vmovaps [rsp+0x40], xmm5
00007fdcd91dcfef  vmovaps [rsp+0x50], xmm6
00007fdcd91dcff5  vmovaps [rsp+0x60], xmm7
00007fdcd91dcffb  vmovaps [rsp+0x70], xmm8
00007fdcd91dd001  vmovaps [rsp+0x80], xmm9
00007fdcd91dd00a  vmovaps [rsp+0x90], xmm10
00007fdcd91dd013  vmovaps [rsp+0xA0], xmm11
00007fdcd91dd01c  vmovaps [rsp+0xB0], xmm12
00007fdcd91dd025  vmovaps [rsp+0xC0], xmm13
00007fdcd91dd02e  vmovaps [rsp+0xD0], xmm14
00007fdcd91dd037  vmovaps [rsp+0xE0], xmm15
00007fdcd91dd040  sub rsp, 0x30
00007fdcd91dd044  movaps [rsp], xmm3
00007fdcd91dd048  movaps [rsp+0x10], xmm5
00007fdcd91dd04d  movaps [rsp+0x20], xmm4
00007fdcd91dd052  lea rdi, [rsp]
00007fdcd91dd056  mov esi, 0x00
00007fdcd91dd05b  mov rax, 0x5B56EFBF3530
00007fdcd91dd065  call rax
00007fdcd91dd067  movaps xmm3, [rsp]
00007fdcd91dd06b  add rsp, 0x30
00007fdcd91dd06f  vmovaps xmm0, [rsp]
00007fdcd91dd074  vmovaps xmm1, [rsp+0x10]
00007fdcd91dd07a  vmovaps xmm2, [rsp+0x20]
00007fdcd91dd080  vmovaps xmm4, [rsp+0x30]
00007fdcd91dd086  vmovaps xmm5, [rsp+0x40]
00007fdcd91dd08c  vmovaps xmm6, [rsp+0x50]
00007fdcd91dd092  vmovaps xmm7, [rsp+0x60]
00007fdcd91dd098  vmovaps xmm8, [rsp+0x70]
00007fdcd91dd09e  vmovaps xmm9, [rsp+0x80]
00007fdcd91dd0a7  vmovaps xmm10, [rsp+0x90]
00007fdcd91dd0b0  vmovaps xmm11, [rsp+0xA0]
00007fdcd91dd0b9  vmovaps xmm12, [rsp+0xB0]
00007fdcd91dd0c2  vmovaps xmm13, [rsp+0xC0]
00007fdcd91dd0cb  vmovaps xmm14, [rsp+0xD0]
00007fdcd91dd0d4  vmovaps xmm15, [rsp+0xE0]
00007fdcd91dd0dd  add rsp, 0xF0
00007fdcd91dd0e4  pop r11
00007fdcd91dd0e6  pop r10
00007fdcd91dd0e8  pop r9
00007fdcd91dd0ea  pop r8
00007fdcd91dd0ec  pop rsi
00007fdcd91dd0ed  pop rdi
00007fdcd91dd0ee  pop rdx
00007fdcd91dd0ef  pop rcx
00007fdcd91dd0f0  pop rax
00007fdcd91dd0f1  add rsp, 0x08
00007fdcd91dd0f5  jmp 0x00007FDCD91DBC35
00007fdcd91dd0fa  sub rsp, 0x08
00007fdcd91dd0fe  push rax
00007fdcd91dd0ff  push rcx
00007fdcd91dd100  push rdx
00007fdcd91dd101  push rdi
00007fdcd91dd102  push rsi
00007fdcd91dd103  push r8
00007fdcd91dd105  push r9
00007fdcd91dd107  push r10
00007fdcd91dd109  push r11
00007fdcd91dd10b  sub rsp, 0xF0
00007fdcd91dd112  vmovaps [rsp], xmm0
00007fdcd91dd117  vmovaps [rsp+0x10], xmm1
00007fdcd91dd11d  vmovaps [rsp+0x20], xmm2
00007fdcd91dd123  vmovaps [rsp+0x30], xmm3
00007fdcd91dd129  vmovaps [rsp+0x40], xmm4
00007fdcd91dd12f  vmovaps [rsp+0x50], xmm6
00007fdcd91dd135  vmovaps [rsp+0x60], xmm7
00007fdcd91dd13b  vmovaps [rsp+0x70], xmm8
00007fdcd91dd141  vmovaps [rsp+0x80], xmm9
00007fdcd91dd14a  vmovaps [rsp+0x90], xmm10
00007fdcd91dd153  vmovaps [rsp+0xA0], xmm11
00007fdcd91dd15c  vmovaps [rsp+0xB0], xmm12
00007fdcd91dd165  vmovaps [rsp+0xC0], xmm13
00007fdcd91dd16e  vmovaps [rsp+0xD0], xmm14
00007fdcd91dd177  vmovaps [rsp+0xE0], xmm15
00007fdcd91dd180  sub rsp, 0x30
00007fdcd91dd184  movaps [rsp], xmm5
00007fdcd91dd188  movaps [rsp+0x10], xmm8
00007fdcd91dd18e  movaps [rsp+0x20], xmm15
00007fdcd91dd194  lea rdi, [rsp]
00007fdcd91dd198  mov esi, 0x00
00007fdcd91dd19d  mov rax, 0x5B56EFBF3530
00007fdcd91dd1a7  call rax
00007fdcd91dd1a9  movaps xmm5, [rsp]
00007fdcd91dd1ad  add rsp, 0x30
00007fdcd91dd1b1  vmovaps xmm0, [rsp]
00007fdcd91dd1b6  vmovaps xmm1, [rsp+0x10]
00007fdcd91dd1bc  vmovaps xmm2, [rsp+0x20]
00007fdcd91dd1c2  vmovaps xmm3, [rsp+0x30]
00007fdcd91dd1c8  vmovaps xmm4, [rsp+0x40]
00007fdcd91dd1ce  vmovaps xmm6, [rsp+0x50]
00007fdcd91dd1d4  vmovaps xmm7, [rsp+0x60]
00007fdcd91dd1da  vmovaps xmm8, [rsp+0x70]
00007fdcd91dd1e0  vmovaps xmm9, [rsp+0x80]
00007fdcd91dd1e9  vmovaps xmm10, [rsp+0x90]
00007fdcd91dd1f2  vmovaps xmm11, [rsp+0xA0]
00007fdcd91dd1fb  vmovaps xmm12, [rsp+0xB0]
00007fdcd91dd204  vmovaps xmm13, [rsp+0xC0]
00007fdcd91dd20d  vmovaps xmm14, [rsp+0xD0]
00007fdcd91dd216  vmovaps xmm15, [rsp+0xE0]
00007fdcd91dd21f  add rsp, 0xF0
00007fdcd91dd226  pop r11
00007fdcd91dd228  pop r10
00007fdcd91dd22a  pop r9
00007fdcd91dd22c  pop r8
00007fdcd91dd22e  pop rsi
00007fdcd91dd22f  pop rdi
00007fdcd91dd230  pop rdx
00007fdcd91dd231  pop rcx
00007fdcd91dd232  pop rax
00007fdcd91dd233  add rsp, 0x08
00007fdcd91dd237  jmp 0x00007FDCD91DBC73
00007fdcd91dd23c  sub rsp, 0x08
00007fdcd91dd240  push rax
00007fdcd91dd241  push rcx
00007fdcd91dd242  push rdx
00007fdcd91dd243  push rdi
00007fdcd91dd244  push rsi
00007fdcd91dd245  push r8
00007fdcd91dd247  push r9
00007fdcd91dd249  push r10
00007fdcd91dd24b  push r11
00007fdcd91dd24d  sub rsp, 0xF0
00007fdcd91dd254  vmovaps [rsp], xmm0
00007fdcd91dd259  vmovaps [rsp+0x10], xmm1
00007fdcd91dd25f  vmovaps [rsp+0x20], xmm2
00007fdcd91dd265  vmovaps [rsp+0x30], xmm3
00007fdcd91dd26b  vmovaps [rsp+0x40], xmm5
00007fdcd91dd271  vmovaps [rsp+0x50], xmm6
00007fdcd91dd277  vmovaps [rsp+0x60], xmm7
00007fdcd91dd27d  vmovaps [rsp+0x70], xmm8
00007fdcd91dd283  vmovaps [rsp+0x80], xmm9
00007fdcd91dd28c  vmovaps [rsp+0x90], xmm10
00007fdcd91dd295  vmovaps [rsp+0xA0], xmm11
00007fdcd91dd29e  vmovaps [rsp+0xB0], xmm12
00007fdcd91dd2a7  vmovaps [rsp+0xC0], xmm13
00007fdcd91dd2b0  vmovaps [rsp+0xD0], xmm14
00007fdcd91dd2b9  vmovaps [rsp+0xE0], xmm15
00007fdcd91dd2c2  sub rsp, 0x30
00007fdcd91dd2c6  movaps [rsp], xmm4
00007fdcd91dd2ca  movaps [rsp+0x10], xmm9
00007fdcd91dd2d0  movaps [rsp+0x20], xmm8
00007fdcd91dd2d6  lea rdi, [rsp]
00007fdcd91dd2da  mov esi, 0x00
00007fdcd91dd2df  mov rax, 0x5B56EFBF3530
00007fdcd91dd2e9  call rax
00007fdcd91dd2eb  movaps xmm4, [rsp]
00007fdcd91dd2ef  add rsp, 0x30
00007fdcd91dd2f3  vmovaps xmm0, [rsp]
00007fdcd91dd2f8  vmovaps xmm1, [rsp+0x10]
00007fdcd91dd2fe  vmovaps xmm2, [rsp+0x20]
00007fdcd91dd304  vmovaps xmm3, [rsp+0x30]
00007fdcd91dd30a  vmovaps xmm5, [rsp+0x40]
00007fdcd91dd310  vmovaps xmm6, [rsp+0x50]
00007fdcd91dd316  vmovaps xmm7, [rsp+0x60]
00007fdcd91dd31c  vmovaps xmm8, [rsp+0x70]
00007fdcd91dd322  vmovaps xmm9, [rsp+0x80]
00007fdcd91dd32b  vmovaps xmm10, [rsp+0x90]
00007fdcd91dd334  vmovaps xmm11, [rsp+0xA0]
00007fdcd91dd33d  vmovaps xmm12, [rsp+0xB0]
00007fdcd91dd346  vmovaps xmm13, [rsp+0xC0]
00007fdcd91dd34f  vmovaps xmm14, [rsp+0xD0]
00007fdcd91dd358  vmovaps xmm15, [rsp+0xE0]
00007fdcd91dd361  add rsp, 0xF0
00007fdcd91dd368  pop r11
00007fdcd91dd36a  pop r10
00007fdcd91dd36c  pop r9
00007fdcd91dd36e  pop r8
00007fdcd91dd370  pop rsi
00007fdcd91dd371  pop rdi
00007fdcd91dd372  pop rdx
00007fdcd91dd373  pop rcx
00007fdcd91dd374  pop rax
00007fdcd91dd375  add rsp, 0x08
00007fdcd91dd379  jmp 0x00007FDCD91DBC94
00007fdcd91dd37e  sub rsp, 0x08
00007fdcd91dd382  push rax
00007fdcd91dd383  push rcx
00007fdcd91dd384  push rdx
00007fdcd91dd385  push rdi
00007fdcd91dd386  push rsi
00007fdcd91dd387  push r8
00007fdcd91dd389  push r9
00007fdcd91dd38b  push r10
00007fdcd91dd38d  push r11
00007fdcd91dd38f  sub rsp, 0xF0
00007fdcd91dd396  vmovaps [rsp], xmm0
00007fdcd91dd39b  vmovaps [rsp+0x10], xmm1
00007fdcd91dd3a1  vmovaps [rsp+0x20], xmm2
00007fdcd91dd3a7  vmovaps [rsp+0x30], xmm3
00007fdcd91dd3ad  vmovaps [rsp+0x40], xmm4
00007fdcd91dd3b3  vmovaps [rsp+0x50], xmm5
00007fdcd91dd3b9  vmovaps [rsp+0x60], xmm6
00007fdcd91dd3bf  vmovaps [rsp+0x70], xmm7
00007fdcd91dd3c5  vmovaps [rsp+0x80], xmm8
00007fdcd91dd3ce  vmovaps [rsp+0x90], xmm10
00007fdcd91dd3d7  vmovaps [rsp+0xA0], xmm11
00007fdcd91dd3e0  vmovaps [rsp+0xB0], xmm12
00007fdcd91dd3e9  vmovaps [rsp+0xC0], xmm13
00007fdcd91dd3f2  vmovaps [rsp+0xD0], xmm14
00007fdcd91dd3fb  vmovaps [rsp+0xE0], xmm15
00007fdcd91dd404  sub rsp, 0x30
00007fdcd91dd408  movaps [rsp], xmm9
00007fdcd91dd40d  movaps [rsp+0x10], xmm10
00007fdcd91dd413  movaps [rsp+0x20], xmm8
00007fdcd91dd419  lea rdi, [rsp]
00007fdcd91dd41d  mov esi, 0x00
00007fdcd91dd422  mov rax, 0x5B56EFBF3530
00007fdcd91dd42c  call rax
00007fdcd91dd42e  movaps xmm9, [rsp]
00007fdcd91dd433  add rsp, 0x30
00007fdcd91dd437  vmovaps xmm0, [rsp]
00007fdcd91dd43c  vmovaps xmm1, [rsp+0x10]
00007fdcd91dd442  vmovaps xmm2, [rsp+0x20]
00007fdcd91dd448  vmovaps xmm3, [rsp+0x30]
00007fdcd91dd44e  vmovaps xmm4, [rsp+0x40]
00007fdcd91dd454  vmovaps xmm5, [rsp+0x50]
00007fdcd91dd45a  vmovaps xmm6, [rsp+0x60]
00007fdcd91dd460  vmovaps xmm7, [rsp+0x70]
00007fdcd91dd466  vmovaps xmm8, [rsp+0x80]
00007fdcd91dd46f  vmovaps xmm10, [rsp+0x90]
00007fdcd91dd478  vmovaps xmm11, [rsp+0xA0]
00007fdcd91dd481  vmovaps xmm12, [rsp+0xB0]
00007fdcd91dd48a  vmovaps xmm13, [rsp+0xC0]
00007fdcd91dd493  vmovaps xmm14, [rsp+0xD0]
00007fdcd91dd49c  vmovaps xmm15, [rsp+0xE0]
00007fdcd91dd4a5  add rsp, 0xF0
00007fdcd91dd4ac  pop r11
00007fdcd91dd4ae  pop r10
00007fdcd91dd4b0  pop r9
00007fdcd91dd4b2  pop r8
00007fdcd91dd4b4  pop rsi
00007fdcd91dd4b5  pop rdi
00007fdcd91dd4b6  pop rdx
00007fdcd91dd4b7  pop rcx
00007fdcd91dd4b8  pop rax
00007fdcd91dd4b9  add rsp, 0x08
00007fdcd91dd4bd  jmp 0x00007FDCD91DBCAE
00007fdcd91dd4c2  call 0x00007FDCD90B52F0
00007fdcd91dd4c7  jmp 0x00007FDCD91DBDC8
00007fdcd91dd4cc  call 0x00007FDCD90B52F0
00007fdcd91dd4d1  jmp 0x00007FDCD91DBDDE
00007fdcd91dd4d6  sub rsp, 0x08
00007fdcd91dd4da  push rax
00007fdcd91dd4db  push rcx
00007fdcd91dd4dc  push rdx
00007fdcd91dd4dd  push rdi
00007fdcd91dd4de  push rsi
00007fdcd91dd4df  push r8
00007fdcd91dd4e1  push r9
00007fdcd91dd4e3  push r10
00007fdcd91dd4e5  push r11
00007fdcd91dd4e7  sub rsp, 0xF0
00007fdcd91dd4ee  vmovaps [rsp], xmm0
00007fdcd91dd4f3  vmovaps [rsp+0x10], xmm2
00007fdcd91dd4f9  vmovaps [rsp+0x20], xmm3
00007fdcd91dd4ff  vmovaps [rsp+0x30], xmm4
00007fdcd91dd505  vmovaps [rsp+0x40], xmm5
00007fdcd91dd50b  vmovaps [rsp+0x50], xmm6
00007fdcd91dd511  vmovaps [rsp+0x60], xmm7
00007fdcd91dd517  vmovaps [rsp+0x70], xmm8
00007fdcd91dd51d  vmovaps [rsp+0x80], xmm9
00007fdcd91dd526  vmovaps [rsp+0x90], xmm10
00007fdcd91dd52f  vmovaps [rsp+0xA0], xmm11
00007fdcd91dd538  vmovaps [rsp+0xB0], xmm12
00007fdcd91dd541  vmovaps [rsp+0xC0], xmm13
00007fdcd91dd54a  vmovaps [rsp+0xD0], xmm14
00007fdcd91dd553  vmovaps [rsp+0xE0], xmm15
00007fdcd91dd55c  sub rsp, 0x30
00007fdcd91dd560  movaps [rsp], xmm1
00007fdcd91dd564  movaps [rsp+0x10], xmm6
00007fdcd91dd569  movaps [rsp+0x20], xmm15
00007fdcd91dd56f  lea rdi, [rsp]
00007fdcd91dd573  mov esi, 0x00
00007fdcd91dd578  mov rax, 0x5B56EFBF3530
00007fdcd91dd582  call rax
00007fdcd91dd584  movaps xmm1, [rsp]
00007fdcd91dd588  add rsp, 0x30
00007fdcd91dd58c  vmovaps xmm0, [rsp]
00007fdcd91dd591  vmovaps xmm2, [rsp+0x10]
00007fdcd91dd597  vmovaps xmm3, [rsp+0x20]
00007fdcd91dd59d  vmovaps xmm4, [rsp+0x30]
00007fdcd91dd5a3  vmovaps xmm5, [rsp+0x40]
00007fdcd91dd5a9  vmovaps xmm6, [rsp+0x50]
00007fdcd91dd5af  vmovaps xmm7, [rsp+0x60]
00007fdcd91dd5b5  vmovaps xmm8, [rsp+0x70]
00007fdcd91dd5bb  vmovaps xmm9, [rsp+0x80]
00007fdcd91dd5c4  vmovaps xmm10, [rsp+0x90]
00007fdcd91dd5cd  vmovaps xmm11, [rsp+0xA0]
00007fdcd91dd5d6  vmovaps xmm12, [rsp+0xB0]
00007fdcd91dd5df  vmovaps xmm13, [rsp+0xC0]
00007fdcd91dd5e8  vmovaps xmm14, [rsp+0xD0]
00007fdcd91dd5f1  vmovaps xmm15, [rsp+0xE0]
00007fdcd91dd5fa  add rsp, 0xF0
00007fdcd91dd601  pop r11
00007fdcd91dd603  pop r10
00007fdcd91dd605  pop r9
00007fdcd91dd607  pop r8
00007fdcd91dd609  pop rsi
00007fdcd91dd60a  pop rdi
00007fdcd91dd60b  pop rdx
00007fdcd91dd60c  pop rcx
00007fdcd91dd60d  pop rax
00007fdcd91dd60e  add rsp, 0x08
00007fdcd91dd612  jmp 0x00007FDCD91DBE1B
00007fdcd91dd617  call 0x00007FDCD90C4620
00007fdcd91dd61c  jmp 0x00007FDCD91DBE28
00007fdcd91dd621  sub rsp, 0x08
00007fdcd91dd625  push rax
00007fdcd91dd626  push rcx
00007fdcd91dd627  push rdx
00007fdcd91dd628  push rdi
00007fdcd91dd629  push rsi
00007fdcd91dd62a  push r8
00007fdcd91dd62c  push r9
00007fdcd91dd62e  push r10
00007fdcd91dd630  push r11
00007fdcd91dd632  sub rsp, 0xF0
00007fdcd91dd639  vmovaps [rsp], xmm0
00007fdcd91dd63e  vmovaps [rsp+0x10], xmm1
00007fdcd91dd644  vmovaps [rsp+0x20], xmm2
00007fdcd91dd64a  vmovaps [rsp+0x30], xmm3
00007fdcd91dd650  vmovaps [rsp+0x40], xmm4
00007fdcd91dd656  vmovaps [rsp+0x50], xmm5
00007fdcd91dd65c  vmovaps [rsp+0x60], xmm6
00007fdcd91dd662  vmovaps [rsp+0x70], xmm7
00007fdcd91dd668  vmovaps [rsp+0x80], xmm8
00007fdcd91dd671  vmovaps [rsp+0x90], xmm9
00007fdcd91dd67a  vmovaps [rsp+0xA0], xmm10
00007fdcd91dd683  vmovaps [rsp+0xB0], xmm11
00007fdcd91dd68c  vmovaps [rsp+0xC0], xmm12
00007fdcd91dd695  vmovaps [rsp+0xD0], xmm13
00007fdcd91dd69e  vmovaps [rsp+0xE0], xmm15
00007fdcd91dd6a7  sub rsp, 0x30
00007fdcd91dd6ab  movaps [rsp], xmm14
00007fdcd91dd6b0  movaps [rsp+0x10], xmm4
00007fdcd91dd6b5  movaps [rsp+0x20], xmm3
00007fdcd91dd6ba  lea rdi, [rsp]
00007fdcd91dd6be  mov esi, 0x00
00007fdcd91dd6c3  mov rax, 0x5B56EFBF3530
00007fdcd91dd6cd  call rax
00007fdcd91dd6cf  movaps xmm14, [rsp]
00007fdcd91dd6d4  add rsp, 0x30
00007fdcd91dd6d8  vmovaps xmm0, [rsp]
00007fdcd91dd6dd  vmovaps xmm1, [rsp+0x10]
00007fdcd91dd6e3  vmovaps xmm2, [rsp+0x20]
00007fdcd91dd6e9  vmovaps xmm3, [rsp+0x30]
00007fdcd91dd6ef  vmovaps xmm4, [rsp+0x40]
00007fdcd91dd6f5  vmovaps xmm5, [rsp+0x50]
00007fdcd91dd6fb  vmovaps xmm6, [rsp+0x60]
00007fdcd91dd701  vmovaps xmm7, [rsp+0x70]
00007fdcd91dd707  vmovaps xmm8, [rsp+0x80]
00007fdcd91dd710  vmovaps xmm9, [rsp+0x90]
00007fdcd91dd719  vmovaps xmm10, [rsp+0xA0]
00007fdcd91dd722  vmovaps xmm11, [rsp+0xB0]
00007fdcd91dd72b  vmovaps xmm12, [rsp+0xC0]
00007fdcd91dd734  vmovaps xmm13, [rsp+0xD0]
00007fdcd91dd73d  vmovaps xmm15, [rsp+0xE0]
00007fdcd91dd746  add rsp, 0xF0
00007fdcd91dd74d  pop r11
00007fdcd91dd74f  pop r10
00007fdcd91dd751  pop r9
00007fdcd91dd753  pop r8
00007fdcd91dd755  pop rsi
00007fdcd91dd756  pop rdi
00007fdcd91dd757  pop rdx
00007fdcd91dd758  pop rcx
00007fdcd91dd759  pop rax
00007fdcd91dd75a  add rsp, 0x08
00007fdcd91dd75e  jmp 0x00007FDCD91DBE42
00007fdcd91dd763  sub rsp, 0x08
00007fdcd91dd767  push rax
00007fdcd91dd768  push rcx
00007fdcd91dd769  push rdx
00007fdcd91dd76a  push rdi
00007fdcd91dd76b  push rsi
00007fdcd91dd76c  push r8
00007fdcd91dd76e  push r9
00007fdcd91dd770  push r10
00007fdcd91dd772  push r11
00007fdcd91dd774  sub rsp, 0xF0
00007fdcd91dd77b  vmovaps [rsp], xmm0
00007fdcd91dd780  vmovaps [rsp+0x10], xmm1
00007fdcd91dd786  vmovaps [rsp+0x20], xmm2
00007fdcd91dd78c  vmovaps [rsp+0x30], xmm3
00007fdcd91dd792  vmovaps [rsp+0x40], xmm4
00007fdcd91dd798  vmovaps [rsp+0x50], xmm5
00007fdcd91dd79e  vmovaps [rsp+0x60], xmm7
00007fdcd91dd7a4  vmovaps [rsp+0x70], xmm8
00007fdcd91dd7aa  vmovaps [rsp+0x80], xmm9
00007fdcd91dd7b3  vmovaps [rsp+0x90], xmm10
00007fdcd91dd7bc  vmovaps [rsp+0xA0], xmm11
00007fdcd91dd7c5  vmovaps [rsp+0xB0], xmm12
00007fdcd91dd7ce  vmovaps [rsp+0xC0], xmm13
00007fdcd91dd7d7  vmovaps [rsp+0xD0], xmm14
00007fdcd91dd7e0  vmovaps [rsp+0xE0], xmm15
00007fdcd91dd7e9  sub rsp, 0x30
00007fdcd91dd7ed  movaps [rsp], xmm6
00007fdcd91dd7f1  movaps [rsp+0x10], xmm9
00007fdcd91dd7f7  movaps [rsp+0x20], xmm7
00007fdcd91dd7fc  lea rdi, [rsp]
00007fdcd91dd800  mov esi, 0x00
00007fdcd91dd805  mov rax, 0x5B56EFBF3530
00007fdcd91dd80f  call rax
00007fdcd91dd811  movaps xmm6, [rsp]
00007fdcd91dd815  add rsp, 0x30
00007fdcd91dd819  vmovaps xmm0, [rsp]
00007fdcd91dd81e  vmovaps xmm1, [rsp+0x10]
00007fdcd91dd824  vmovaps xmm2, [rsp+0x20]
00007fdcd91dd82a  vmovaps xmm3, [rsp+0x30]
00007fdcd91dd830  vmovaps xmm4, [rsp+0x40]
00007fdcd91dd836  vmovaps xmm5, [rsp+0x50]
00007fdcd91dd83c  vmovaps xmm7, [rsp+0x60]
00007fdcd91dd842  vmovaps xmm8, [rsp+0x70]
00007fdcd91dd848  vmovaps xmm9, [rsp+0x80]
00007fdcd91dd851  vmovaps xmm10, [rsp+0x90]
00007fdcd91dd85a  vmovaps xmm11, [rsp+0xA0]
00007fdcd91dd863  vmovaps xmm12, [rsp+0xB0]
00007fdcd91dd86c  vmovaps xmm13, [rsp+0xC0]
00007fdcd91dd875  vmovaps xmm14, [rsp+0xD0]
00007fdcd91dd87e  vmovaps xmm15, [rsp+0xE0]
00007fdcd91dd887  add rsp, 0xF0
00007fdcd91dd88e  pop r11
00007fdcd91dd890  pop r10
00007fdcd91dd892  pop r9
00007fdcd91dd894  pop r8
00007fdcd91dd896  pop rsi
00007fdcd91dd897  pop rdi
00007fdcd91dd898  pop rdx
00007fdcd91dd899  pop rcx
00007fdcd91dd89a  pop rax
00007fdcd91dd89b  add rsp, 0x08
00007fdcd91dd89f  jmp 0x00007FDCD91DBE5A
00007fdcd91dd8a4  sub rsp, 0x08
00007fdcd91dd8a8  push rax
00007fdcd91dd8a9  push rcx
00007fdcd91dd8aa  push rdx
00007fdcd91dd8ab  push rdi
00007fdcd91dd8ac  push rsi
00007fdcd91dd8ad  push r8
00007fdcd91dd8af  push r9
00007fdcd91dd8b1  push r10
00007fdcd91dd8b3  push r11
00007fdcd91dd8b5  sub rsp, 0xF0
00007fdcd91dd8bc  vmovaps [rsp], xmm0
00007fdcd91dd8c1  vmovaps [rsp+0x10], xmm1
00007fdcd91dd8c7  vmovaps [rsp+0x20], xmm2
00007fdcd91dd8cd  vmovaps [rsp+0x30], xmm3
00007fdcd91dd8d3  vmovaps [rsp+0x40], xmm4
00007fdcd91dd8d9  vmovaps [rsp+0x50], xmm5
00007fdcd91dd8df  vmovaps [rsp+0x60], xmm6
00007fdcd91dd8e5  vmovaps [rsp+0x70], xmm8
00007fdcd91dd8eb  vmovaps [rsp+0x80], xmm9
00007fdcd91dd8f4  vmovaps [rsp+0x90], xmm10
00007fdcd91dd8fd  vmovaps [rsp+0xA0], xmm11
00007fdcd91dd906  vmovaps [rsp+0xB0], xmm12
00007fdcd91dd90f  vmovaps [rsp+0xC0], xmm13
00007fdcd91dd918  vmovaps [rsp+0xD0], xmm14
00007fdcd91dd921  vmovaps [rsp+0xE0], xmm15
00007fdcd91dd92a  sub rsp, 0x30
00007fdcd91dd92e  movaps [rsp], xmm7
00007fdcd91dd932  movaps [rsp+0x10], xmm4
00007fdcd91dd937  movaps [rsp+0x20], xmm9
00007fdcd91dd93d  lea rdi, [rsp]
00007fdcd91dd941  mov esi, 0x00
00007fdcd91dd946  mov rax, 0x5B56EFBF3530
00007fdcd91dd950  call rax
00007fdcd91dd952  movaps xmm7, [rsp]
00007fdcd91dd956  add rsp, 0x30
00007fdcd91dd95a  vmovaps xmm0, [rsp]
00007fdcd91dd95f  vmovaps xmm1, [rsp+0x10]
00007fdcd91dd965  vmovaps xmm2, [rsp+0x20]
00007fdcd91dd96b  vmovaps xmm3, [rsp+0x30]
00007fdcd91dd971  vmovaps xmm4, [rsp+0x40]
00007fdcd91dd977  vmovaps xmm5, [rsp+0x50]
00007fdcd91dd97d  vmovaps xmm6, [rsp+0x60]
00007fdcd91dd983  vmovaps xmm8, [rsp+0x70]
00007fdcd91dd989  vmovaps xmm9, [rsp+0x80]
00007fdcd91dd992  vmovaps xmm10, [rsp+0x90]
00007fdcd91dd99b  vmovaps xmm11, [rsp+0xA0]
00007fdcd91dd9a4  vmovaps xmm12, [rsp+0xB0]
00007fdcd91dd9ad  vmovaps xmm13, [rsp+0xC0]
00007fdcd91dd9b6  vmovaps xmm14, [rsp+0xD0]
00007fdcd91dd9bf  vmovaps xmm15, [rsp+0xE0]
00007fdcd91dd9c8  add rsp, 0xF0
00007fdcd91dd9cf  pop r11
00007fdcd91dd9d1  pop r10
00007fdcd91dd9d3  pop r9
00007fdcd91dd9d5  pop r8
00007fdcd91dd9d7  pop rsi
00007fdcd91dd9d8  pop rdi
00007fdcd91dd9d9  pop rdx
00007fdcd91dd9da  pop rcx
00007fdcd91dd9db  pop rax
00007fdcd91dd9dc  add rsp, 0x08
00007fdcd91dd9e0  jmp 0x00007FDCD91DBE87
00007fdcd91dd9e5  sub rsp, 0x08
00007fdcd91dd9e9  push rax
00007fdcd91dd9ea  push rcx
00007fdcd91dd9eb  push rdx
00007fdcd91dd9ec  push rdi
00007fdcd91dd9ed  push rsi
00007fdcd91dd9ee  push r8
00007fdcd91dd9f0  push r9
00007fdcd91dd9f2  push r10
00007fdcd91dd9f4  push r11
00007fdcd91dd9f6  sub rsp, 0xF0
00007fdcd91dd9fd  vmovaps [rsp], xmm0
00007fdcd91dda02  vmovaps [rsp+0x10], xmm1
00007fdcd91dda08  vmovaps [rsp+0x20], xmm2
00007fdcd91dda0e  vmovaps [rsp+0x30], xmm3
00007fdcd91dda14  vmovaps [rsp+0x40], xmm5
00007fdcd91dda1a  vmovaps [rsp+0x50], xmm6
00007fdcd91dda20  vmovaps [rsp+0x60], xmm7
00007fdcd91dda26  vmovaps [rsp+0x70], xmm8
00007fdcd91dda2c  vmovaps [rsp+0x80], xmm9
00007fdcd91dda35  vmovaps [rsp+0x90], xmm10
00007fdcd91dda3e  vmovaps [rsp+0xA0], xmm11
00007fdcd91dda47  vmovaps [rsp+0xB0], xmm12
00007fdcd91dda50  vmovaps [rsp+0xC0], xmm13
00007fdcd91dda59  vmovaps [rsp+0xD0], xmm14
00007fdcd91dda62  vmovaps [rsp+0xE0], xmm15
00007fdcd91dda6b  sub rsp, 0x30
00007fdcd91dda6f  movaps [rsp], xmm4
00007fdcd91dda73  movaps [rsp+0x10], xmm15
00007fdcd91dda79  movaps [rsp+0x20], xmm9
00007fdcd91dda7f  lea rdi, [rsp]
00007fdcd91dda83  mov esi, 0x00
00007fdcd91dda88  mov rax, 0x5B56EFBF3530
00007fdcd91dda92  call rax
00007fdcd91dda94  movaps xmm4, [rsp]
00007fdcd91dda98  add rsp, 0x30
00007fdcd91dda9c  vmovaps xmm0, [rsp]
00007fdcd91ddaa1  vmovaps xmm1, [rsp+0x10]
00007fdcd91ddaa7  vmovaps xmm2, [rsp+0x20]
00007fdcd91ddaad  vmovaps xmm3, [rsp+0x30]
00007fdcd91ddab3  vmovaps xmm5, [rsp+0x40]
00007fdcd91ddab9  vmovaps xmm6, [rsp+0x50]
00007fdcd91ddabf  vmovaps xmm7, [rsp+0x60]
00007fdcd91ddac5  vmovaps xmm8, [rsp+0x70]
00007fdcd91ddacb  vmovaps xmm9, [rsp+0x80]
00007fdcd91ddad4  vmovaps xmm10, [rsp+0x90]
00007fdcd91ddadd  vmovaps xmm11, [rsp+0xA0]
00007fdcd91ddae6  vmovaps xmm12, [rsp+0xB0]
00007fdcd91ddaef  vmovaps xmm13, [rsp+0xC0]
00007fdcd91ddaf8  vmovaps xmm14, [rsp+0xD0]
00007fdcd91ddb01  vmovaps xmm15, [rsp+0xE0]
00007fdcd91ddb0a  add rsp, 0xF0
00007fdcd91ddb11  pop r11
00007fdcd91ddb13  pop r10
00007fdcd91ddb15  pop r9
00007fdcd91ddb17  pop r8
00007fdcd91ddb19  pop rsi
00007fdcd91ddb1a  pop rdi
00007fdcd91ddb1b  pop rdx
00007fdcd91ddb1c  pop rcx
00007fdcd91ddb1d  pop rax
00007fdcd91ddb1e  add rsp, 0x08
00007fdcd91ddb22  jmp 0x00007FDCD91DBEAC
00007fdcd91ddb27  call 0x00007FDCD90C4620
00007fdcd91ddb2c  jmp 0x00007FDCD91DBEB9
00007fdcd91ddb31  sub rsp, 0x08
00007fdcd91ddb35  push rax
00007fdcd91ddb36  push rcx
00007fdcd91ddb37  push rdx
00007fdcd91ddb38  push rdi
00007fdcd91ddb39  push rsi
00007fdcd91ddb3a  push r8
00007fdcd91ddb3c  push r9
00007fdcd91ddb3e  push r10
00007fdcd91ddb40  push r11
00007fdcd91ddb42  sub rsp, 0xF0
00007fdcd91ddb49  vmovaps [rsp], xmm0
00007fdcd91ddb4e  vmovaps [rsp+0x10], xmm1
00007fdcd91ddb54  vmovaps [rsp+0x20], xmm2
00007fdcd91ddb5a  vmovaps [rsp+0x30], xmm4
00007fdcd91ddb60  vmovaps [rsp+0x40], xmm5
00007fdcd91ddb66  vmovaps [rsp+0x50], xmm6
00007fdcd91ddb6c  vmovaps [rsp+0x60], xmm7
00007fdcd91ddb72  vmovaps [rsp+0x70], xmm8
00007fdcd91ddb78  vmovaps [rsp+0x80], xmm9
00007fdcd91ddb81  vmovaps [rsp+0x90], xmm10
00007fdcd91ddb8a  vmovaps [rsp+0xA0], xmm11
00007fdcd91ddb93  vmovaps [rsp+0xB0], xmm12
00007fdcd91ddb9c  vmovaps [rsp+0xC0], xmm13
00007fdcd91ddba5  vmovaps [rsp+0xD0], xmm14
00007fdcd91ddbae  vmovaps [rsp+0xE0], xmm15
00007fdcd91ddbb7  sub rsp, 0x30
00007fdcd91ddbbb  movaps [rsp], xmm3
00007fdcd91ddbbf  movaps [rsp+0x10], xmm1
00007fdcd91ddbc4  movaps [rsp+0x20], xmm9
00007fdcd91ddbca  lea rdi, [rsp]
00007fdcd91ddbce  mov esi, 0x00
00007fdcd91ddbd3  mov rax, 0x5B56EFBF3530
00007fdcd91ddbdd  call rax
00007fdcd91ddbdf  movaps xmm3, [rsp]
00007fdcd91ddbe3  add rsp, 0x30
00007fdcd91ddbe7  vmovaps xmm0, [rsp]
00007fdcd91ddbec  vmovaps xmm1, [rsp+0x10]
00007fdcd91ddbf2  vmovaps xmm2, [rsp+0x20]
00007fdcd91ddbf8  vmovaps xmm4, [rsp+0x30]
00007fdcd91ddbfe  vmovaps xmm5, [rsp+0x40]
00007fdcd91ddc04  vmovaps xmm6, [rsp+0x50]
00007fdcd91ddc0a  vmovaps xmm7, [rsp+0x60]
00007fdcd91ddc10  vmovaps xmm8, [rsp+0x70]
00007fdcd91ddc16  vmovaps xmm9, [rsp+0x80]
00007fdcd91ddc1f  vmovaps xmm10, [rsp+0x90]
00007fdcd91ddc28  vmovaps xmm11, [rsp+0xA0]
00007fdcd91ddc31  vmovaps xmm12, [rsp+0xB0]
00007fdcd91ddc3a  vmovaps xmm13, [rsp+0xC0]
00007fdcd91ddc43  vmovaps xmm14, [rsp+0xD0]
00007fdcd91ddc4c  vmovaps xmm15, [rsp+0xE0]
00007fdcd91ddc55  add rsp, 0xF0
00007fdcd91ddc5c  pop r11
00007fdcd91ddc5e  pop r10
00007fdcd91ddc60  pop r9
00007fdcd91ddc62  pop r8
00007fdcd91ddc64  pop rsi
00007fdcd91ddc65  pop rdi
00007fdcd91ddc66  pop rdx
00007fdcd91ddc67  pop rcx
00007fdcd91ddc68  pop rax
00007fdcd91ddc69  add rsp, 0x08
00007fdcd91ddc6d  jmp 0x00007FDCD91DBEF6
00007fdcd91ddc72  sub rsp, 0x08
00007fdcd91ddc76  push rax
00007fdcd91ddc77  push rcx
00007fdcd91ddc78  push rdx
00007fdcd91ddc79  push rdi
00007fdcd91ddc7a  push rsi
00007fdcd91ddc7b  push r8
00007fdcd91ddc7d  push r9
00007fdcd91ddc7f  push r10
00007fdcd91ddc81  push r11
00007fdcd91ddc83  sub rsp, 0xF0
00007fdcd91ddc8a  vmovaps [rsp], xmm0
00007fdcd91ddc8f  vmovaps [rsp+0x10], xmm2
00007fdcd91ddc95  vmovaps [rsp+0x20], xmm3
00007fdcd91ddc9b  vmovaps [rsp+0x30], xmm4
00007fdcd91ddca1  vmovaps [rsp+0x40], xmm5
00007fdcd91ddca7  vmovaps [rsp+0x50], xmm6
00007fdcd91ddcad  vmovaps [rsp+0x60], xmm7
00007fdcd91ddcb3  vmovaps [rsp+0x70], xmm8
00007fdcd91ddcb9  vmovaps [rsp+0x80], xmm9
00007fdcd91ddcc2  vmovaps [rsp+0x90], xmm10
00007fdcd91ddccb  vmovaps [rsp+0xA0], xmm11
00007fdcd91ddcd4  vmovaps [rsp+0xB0], xmm12
00007fdcd91ddcdd  vmovaps [rsp+0xC0], xmm13
00007fdcd91ddce6  vmovaps [rsp+0xD0], xmm14
00007fdcd91ddcef  vmovaps [rsp+0xE0], xmm15
00007fdcd91ddcf8  sub rsp, 0x30
00007fdcd91ddcfc  movaps [rsp], xmm1
00007fdcd91ddd00  movaps [rsp+0x10], xmm15
00007fdcd91ddd06  movaps [rsp+0x20], xmm9
00007fdcd91ddd0c  lea rdi, [rsp]
00007fdcd91ddd10  mov esi, 0x00
00007fdcd91ddd15  mov rax, 0x5B56EFBF3530
00007fdcd91ddd1f  call rax
00007fdcd91ddd21  movaps xmm1, [rsp]
00007fdcd91ddd25  add rsp, 0x30
00007fdcd91ddd29  vmovaps xmm0, [rsp]
00007fdcd91ddd2e  vmovaps xmm2, [rsp+0x10]
00007fdcd91ddd34  vmovaps xmm3, [rsp+0x20]
00007fdcd91ddd3a  vmovaps xmm4, [rsp+0x30]
00007fdcd91ddd40  vmovaps xmm5, [rsp+0x40]
00007fdcd91ddd46  vmovaps xmm6, [rsp+0x50]
00007fdcd91ddd4c  vmovaps xmm7, [rsp+0x60]
00007fdcd91ddd52  vmovaps xmm8, [rsp+0x70]
00007fdcd91ddd58  vmovaps xmm9, [rsp+0x80]
00007fdcd91ddd61  vmovaps xmm10, [rsp+0x90]
00007fdcd91ddd6a  vmovaps xmm11, [rsp+0xA0]
00007fdcd91ddd73  vmovaps xmm12, [rsp+0xB0]
00007fdcd91ddd7c  vmovaps xmm13, [rsp+0xC0]
00007fdcd91ddd85  vmovaps xmm14, [rsp+0xD0]
00007fdcd91ddd8e  vmovaps xmm15, [rsp+0xE0]
00007fdcd91ddd97  add rsp, 0xF0
00007fdcd91ddd9e  pop r11
00007fdcd91ddda0  pop r10
00007fdcd91ddda2  pop r9
00007fdcd91ddda4  pop r8
00007fdcd91ddda6  pop rsi
00007fdcd91ddda7  pop rdi
00007fdcd91ddda8  pop rdx
00007fdcd91ddda9  pop rcx
00007fdcd91dddaa  pop rax
00007fdcd91dddab  add rsp, 0x08
00007fdcd91dddaf  jmp 0x00007FDCD91DBF7E
00007fdcd91dddb4  call 0x00007FDCD90C4620
00007fdcd91dddb9  jmp 0x00007FDCD91DBF8B
00007fdcd91dddbe  sub rsp, 0x08
00007fdcd91dddc2  push rax
00007fdcd91dddc3  push rcx
00007fdcd91dddc4  push rdx
00007fdcd91dddc5  push rdi
00007fdcd91dddc6  push rsi
00007fdcd91dddc7  push r8
00007fdcd91dddc9  push r9
00007fdcd91dddcb  push r10
00007fdcd91dddcd  push r11
00007fdcd91dddcf  sub rsp, 0xF0
00007fdcd91dddd6  vmovaps [rsp], xmm0
00007fdcd91ddddb  vmovaps [rsp+0x10], xmm2
00007fdcd91ddde1  vmovaps [rsp+0x20], xmm3
00007fdcd91ddde7  vmovaps [rsp+0x30], xmm4
00007fdcd91ddded  vmovaps [rsp+0x40], xmm5
00007fdcd91dddf3  vmovaps [rsp+0x50], xmm6
00007fdcd91dddf9  vmovaps [rsp+0x60], xmm7
00007fdcd91dddff  vmovaps [rsp+0x70], xmm8
00007fdcd91dde05  vmovaps [rsp+0x80], xmm9
00007fdcd91dde0e  vmovaps [rsp+0x90], xmm10
00007fdcd91dde17  vmovaps [rsp+0xA0], xmm11
00007fdcd91dde20  vmovaps [rsp+0xB0], xmm12
00007fdcd91dde29  vmovaps [rsp+0xC0], xmm13
00007fdcd91dde32  vmovaps [rsp+0xD0], xmm14
00007fdcd91dde3b  vmovaps [rsp+0xE0], xmm15
00007fdcd91dde44  sub rsp, 0x30
00007fdcd91dde48  movaps [rsp], xmm1
00007fdcd91dde4c  movaps [rsp+0x10], xmm5
00007fdcd91dde51  movaps [rsp+0x20], xmm7
00007fdcd91dde56  lea rdi, [rsp]
00007fdcd91dde5a  mov esi, 0x00
00007fdcd91dde5f  mov rax, 0x5B56EFBF3530
00007fdcd91dde69  call rax
00007fdcd91dde6b  movaps xmm1, [rsp]
00007fdcd91dde6f  add rsp, 0x30
00007fdcd91dde73  vmovaps xmm0, [rsp]
00007fdcd91dde78  vmovaps xmm2, [rsp+0x10]
00007fdcd91dde7e  vmovaps xmm3, [rsp+0x20]
00007fdcd91dde84  vmovaps xmm4, [rsp+0x30]
00007fdcd91dde8a  vmovaps xmm5, [rsp+0x40]
00007fdcd91dde90  vmovaps xmm6, [rsp+0x50]
00007fdcd91dde96  vmovaps xmm7, [rsp+0x60]
00007fdcd91dde9c  vmovaps xmm8, [rsp+0x70]
00007fdcd91ddea2  vmovaps xmm9, [rsp+0x80]
00007fdcd91ddeab  vmovaps xmm10, [rsp+0x90]
00007fdcd91ddeb4  vmovaps xmm11, [rsp+0xA0]
00007fdcd91ddebd  vmovaps xmm12, [rsp+0xB0]
00007fdcd91ddec6  vmovaps xmm13, [rsp+0xC0]
00007fdcd91ddecf  vmovaps xmm14, [rsp+0xD0]
00007fdcd91dded8  vmovaps xmm15, [rsp+0xE0]
00007fdcd91ddee1  add rsp, 0xF0
00007fdcd91ddee8  pop r11
00007fdcd91ddeea  pop r10
00007fdcd91ddeec  pop r9
00007fdcd91ddeee  pop r8
00007fdcd91ddef0  pop rsi
00007fdcd91ddef1  pop rdi
00007fdcd91ddef2  pop rdx
00007fdcd91ddef3  pop rcx
00007fdcd91ddef4  pop rax
00007fdcd91ddef5  add rsp, 0x08
00007fdcd91ddef9  jmp 0x00007FDCD91DC030
00007fdcd91ddefe  sub rsp, 0x08
00007fdcd91ddf02  push rax
00007fdcd91ddf03  push rcx
00007fdcd91ddf04  push rdx
00007fdcd91ddf05  push rdi
00007fdcd91ddf06  push rsi
00007fdcd91ddf07  push r8
00007fdcd91ddf09  push r9
00007fdcd91ddf0b  push r10
00007fdcd91ddf0d  push r11
00007fdcd91ddf0f  sub rsp, 0xF0
00007fdcd91ddf16  vmovaps [rsp], xmm0
00007fdcd91ddf1b  vmovaps [rsp+0x10], xmm1
00007fdcd91ddf21  vmovaps [rsp+0x20], xmm2
00007fdcd91ddf27  vmovaps [rsp+0x30], xmm3
00007fdcd91ddf2d  vmovaps [rsp+0x40], xmm4
00007fdcd91ddf33  vmovaps [rsp+0x50], xmm5
00007fdcd91ddf39  vmovaps [rsp+0x60], xmm6
00007fdcd91ddf3f  vmovaps [rsp+0x70], xmm8
00007fdcd91ddf45  vmovaps [rsp+0x80], xmm9
00007fdcd91ddf4e  vmovaps [rsp+0x90], xmm10
00007fdcd91ddf57  vmovaps [rsp+0xA0], xmm11
00007fdcd91ddf60  vmovaps [rsp+0xB0], xmm12
00007fdcd91ddf69  vmovaps [rsp+0xC0], xmm13
00007fdcd91ddf72  vmovaps [rsp+0xD0], xmm14
00007fdcd91ddf7b  vmovaps [rsp+0xE0], xmm15
00007fdcd91ddf84  sub rsp, 0x30
00007fdcd91ddf88  movaps [rsp], xmm7
00007fdcd91ddf8c  movaps [rsp+0x10], xmm5
00007fdcd91ddf91  movaps [rsp+0x20], xmm15
00007fdcd91ddf97  lea rdi, [rsp]
00007fdcd91ddf9b  mov esi, 0x00
00007fdcd91ddfa0  mov rax, 0x5B56EFBF3530
00007fdcd91ddfaa  call rax
00007fdcd91ddfac  movaps xmm7, [rsp]
00007fdcd91ddfb0  add rsp, 0x30
00007fdcd91ddfb4  vmovaps xmm0, [rsp]
00007fdcd91ddfb9  vmovaps xmm1, [rsp+0x10]
00007fdcd91ddfbf  vmovaps xmm2, [rsp+0x20]
00007fdcd91ddfc5  vmovaps xmm3, [rsp+0x30]
00007fdcd91ddfcb  vmovaps xmm4, [rsp+0x40]
00007fdcd91ddfd1  vmovaps xmm5, [rsp+0x50]
00007fdcd91ddfd7  vmovaps xmm6, [rsp+0x60]
00007fdcd91ddfdd  vmovaps xmm8, [rsp+0x70]
00007fdcd91ddfe3  vmovaps xmm9, [rsp+0x80]
00007fdcd91ddfec  vmovaps xmm10, [rsp+0x90]
00007fdcd91ddff5  vmovaps xmm11, [rsp+0xA0]
00007fdcd91ddffe  vmovaps xmm12, [rsp+0xB0]
00007fdcd91de007  vmovaps xmm13, [rsp+0xC0]
00007fdcd91de010  vmovaps xmm14, [rsp+0xD0]
00007fdcd91de019  vmovaps xmm15, [rsp+0xE0]
00007fdcd91de022  add rsp, 0xF0
00007fdcd91de029  pop r11
00007fdcd91de02b  pop r10
00007fdcd91de02d  pop r9
00007fdcd91de02f  pop r8
00007fdcd91de031  pop rsi
00007fdcd91de032  pop rdi
00007fdcd91de033  pop rdx
00007fdcd91de034  pop rcx
00007fdcd91de035  pop rax
00007fdcd91de036  add rsp, 0x08
00007fdcd91de03a  jmp 0x00007FDCD91DC066
00007fdcd91de03f  call 0x00007FDCD90B52F0
00007fdcd91de044  jmp 0x00007FDCD91DC073
00007fdcd91de049  sub rsp, 0x08
00007fdcd91de04d  push rax
00007fdcd91de04e  push rcx
00007fdcd91de04f  push rdx
00007fdcd91de050  push rdi
00007fdcd91de051  push rsi
00007fdcd91de052  push r8
00007fdcd91de054  push r9
00007fdcd91de056  push r10
00007fdcd91de058  push r11
00007fdcd91de05a  sub rsp, 0xF0
00007fdcd91de061  vmovaps [rsp], xmm0
00007fdcd91de066  vmovaps [rsp+0x10], xmm1
00007fdcd91de06c  vmovaps [rsp+0x20], xmm2
00007fdcd91de072  vmovaps [rsp+0x30], xmm3
00007fdcd91de078  vmovaps [rsp+0x40], xmm4
00007fdcd91de07e  vmovaps [rsp+0x50], xmm5
00007fdcd91de084  vmovaps [rsp+0x60], xmm6
00007fdcd91de08a  vmovaps [rsp+0x70], xmm7
00007fdcd91de090  vmovaps [rsp+0x80], xmm8
00007fdcd91de099  vmovaps [rsp+0x90], xmm9
00007fdcd91de0a2  vmovaps [rsp+0xA0], xmm10
00007fdcd91de0ab  vmovaps [rsp+0xB0], xmm11
00007fdcd91de0b4  vmovaps [rsp+0xC0], xmm12
00007fdcd91de0bd  vmovaps [rsp+0xD0], xmm13
00007fdcd91de0c6  vmovaps [rsp+0xE0], xmm14
00007fdcd91de0cf  sub rsp, 0x30
00007fdcd91de0d3  movaps [rsp], xmm15
00007fdcd91de0d8  movaps [rsp+0x10], xmm5
00007fdcd91de0dd  movaps [rsp+0x20], xmm3
00007fdcd91de0e2  lea rdi, [rsp]
00007fdcd91de0e6  mov esi, 0x00
00007fdcd91de0eb  mov rax, 0x5B56EFBF3530
00007fdcd91de0f5  call rax
00007fdcd91de0f7  movaps xmm15, [rsp]
00007fdcd91de0fc  add rsp, 0x30
00007fdcd91de100  vmovaps xmm0, [rsp]
00007fdcd91de105  vmovaps xmm1, [rsp+0x10]
00007fdcd91de10b  vmovaps xmm2, [rsp+0x20]
00007fdcd91de111  vmovaps xmm3, [rsp+0x30]
00007fdcd91de117  vmovaps xmm4, [rsp+0x40]
00007fdcd91de11d  vmovaps xmm5, [rsp+0x50]
00007fdcd91de123  vmovaps xmm6, [rsp+0x60]
00007fdcd91de129  vmovaps xmm7, [rsp+0x70]
00007fdcd91de12f  vmovaps xmm8, [rsp+0x80]
00007fdcd91de138  vmovaps xmm9, [rsp+0x90]
00007fdcd91de141  vmovaps xmm10, [rsp+0xA0]
00007fdcd91de14a  vmovaps xmm11, [rsp+0xB0]
00007fdcd91de153  vmovaps xmm12, [rsp+0xC0]
00007fdcd91de15c  vmovaps xmm13, [rsp+0xD0]
00007fdcd91de165  vmovaps xmm14, [rsp+0xE0]
00007fdcd91de16e  add rsp, 0xF0
00007fdcd91de175  pop r11
00007fdcd91de177  pop r10
00007fdcd91de179  pop r9
00007fdcd91de17b  pop r8
00007fdcd91de17d  pop rsi
00007fdcd91de17e  pop rdi
00007fdcd91de17f  pop rdx
00007fdcd91de180  pop rcx
00007fdcd91de181  pop rax
00007fdcd91de182  add rsp, 0x08
00007fdcd91de186  jmp 0x00007FDCD91DC099
00007fdcd91de18b  sub rsp, 0x08
00007fdcd91de18f  push rax
00007fdcd91de190  push rcx
00007fdcd91de191  push rdx
00007fdcd91de192  push rdi
00007fdcd91de193  push rsi
00007fdcd91de194  push r8
00007fdcd91de196  push r9
00007fdcd91de198  push r10
00007fdcd91de19a  push r11
00007fdcd91de19c  sub rsp, 0xF0
00007fdcd91de1a3  vmovaps [rsp], xmm0
00007fdcd91de1a8  vmovaps [rsp+0x10], xmm2
00007fdcd91de1ae  vmovaps [rsp+0x20], xmm3
00007fdcd91de1b4  vmovaps [rsp+0x30], xmm4
00007fdcd91de1ba  vmovaps [rsp+0x40], xmm5
00007fdcd91de1c0  vmovaps [rsp+0x50], xmm6
00007fdcd91de1c6  vmovaps [rsp+0x60], xmm7
00007fdcd91de1cc  vmovaps [rsp+0x70], xmm8
00007fdcd91de1d2  vmovaps [rsp+0x80], xmm9
00007fdcd91de1db  vmovaps [rsp+0x90], xmm10
00007fdcd91de1e4  vmovaps [rsp+0xA0], xmm11
00007fdcd91de1ed  vmovaps [rsp+0xB0], xmm12
00007fdcd91de1f6  vmovaps [rsp+0xC0], xmm13
00007fdcd91de1ff  vmovaps [rsp+0xD0], xmm14
00007fdcd91de208  vmovaps [rsp+0xE0], xmm15
00007fdcd91de211  sub rsp, 0x30
00007fdcd91de215  movaps [rsp], xmm1
00007fdcd91de219  movaps [rsp+0x10], xmm5
00007fdcd91de21e  movaps [rsp+0x20], xmm4
00007fdcd91de223  lea rdi, [rsp]
00007fdcd91de227  mov esi, 0x00
00007fdcd91de22c  mov rax, 0x5B56EFBF3530
00007fdcd91de236  call rax
00007fdcd91de238  movaps xmm1, [rsp]
00007fdcd91de23c  add rsp, 0x30
00007fdcd91de240  vmovaps xmm0, [rsp]
00007fdcd91de245  vmovaps xmm2, [rsp+0x10]
00007fdcd91de24b  vmovaps xmm3, [rsp+0x20]
00007fdcd91de251  vmovaps xmm4, [rsp+0x30]
00007fdcd91de257  vmovaps xmm5, [rsp+0x40]
00007fdcd91de25d  vmovaps xmm6, [rsp+0x50]
00007fdcd91de263  vmovaps xmm7, [rsp+0x60]
00007fdcd91de269  vmovaps xmm8, [rsp+0x70]
00007fdcd91de26f  vmovaps xmm9, [rsp+0x80]
00007fdcd91de278  vmovaps xmm10, [rsp+0x90]
00007fdcd91de281  vmovaps xmm11, [rsp+0xA0]
00007fdcd91de28a  vmovaps xmm12, [rsp+0xB0]
00007fdcd91de293  vmovaps xmm13, [rsp+0xC0]
00007fdcd91de29c  vmovaps xmm14, [rsp+0xD0]
00007fdcd91de2a5  vmovaps xmm15, [rsp+0xE0]
00007fdcd91de2ae  add rsp, 0xF0
00007fdcd91de2b5  pop r11
00007fdcd91de2b7  pop r10
00007fdcd91de2b9  pop r9
00007fdcd91de2bb  pop r8
00007fdcd91de2bd  pop rsi
00007fdcd91de2be  pop rdi
00007fdcd91de2bf  pop rdx
00007fdcd91de2c0  pop rcx
00007fdcd91de2c1  pop rax
00007fdcd91de2c2  add rsp, 0x08
00007fdcd91de2c6  jmp 0x00007FDCD91DC0B9
00007fdcd91de2cb  sub rsp, 0x08
00007fdcd91de2cf  push rax
00007fdcd91de2d0  push rcx
00007fdcd91de2d1  push rdx
00007fdcd91de2d2  push rdi
00007fdcd91de2d3  push rsi
00007fdcd91de2d4  push r8
00007fdcd91de2d6  push r9
00007fdcd91de2d8  push r10
00007fdcd91de2da  push r11
00007fdcd91de2dc  sub rsp, 0xF0
00007fdcd91de2e3  vmovaps [rsp], xmm0
00007fdcd91de2e8  vmovaps [rsp+0x10], xmm1
00007fdcd91de2ee  vmovaps [rsp+0x20], xmm2
00007fdcd91de2f4  vmovaps [rsp+0x30], xmm3
00007fdcd91de2fa  vmovaps [rsp+0x40], xmm5
00007fdcd91de300  vmovaps [rsp+0x50], xmm6
00007fdcd91de306  vmovaps [rsp+0x60], xmm7
00007fdcd91de30c  vmovaps [rsp+0x70], xmm8
00007fdcd91de312  vmovaps [rsp+0x80], xmm9
00007fdcd91de31b  vmovaps [rsp+0x90], xmm10
00007fdcd91de324  vmovaps [rsp+0xA0], xmm11
00007fdcd91de32d  vmovaps [rsp+0xB0], xmm12
00007fdcd91de336  vmovaps [rsp+0xC0], xmm13
00007fdcd91de33f  vmovaps [rsp+0xD0], xmm14
00007fdcd91de348  vmovaps [rsp+0xE0], xmm15
00007fdcd91de351  sub rsp, 0x30
00007fdcd91de355  movaps [rsp], xmm4
00007fdcd91de359  movaps [rsp+0x10], xmm3
00007fdcd91de35e  movaps [rsp+0x20], xmm5
00007fdcd91de363  lea rdi, [rsp]
00007fdcd91de367  mov esi, 0x00
00007fdcd91de36c  mov rax, 0x5B56EFBF3530
00007fdcd91de376  call rax
00007fdcd91de378  movaps xmm4, [rsp]
00007fdcd91de37c  add rsp, 0x30
00007fdcd91de380  vmovaps xmm0, [rsp]
00007fdcd91de385  vmovaps xmm1, [rsp+0x10]
00007fdcd91de38b  vmovaps xmm2, [rsp+0x20]
00007fdcd91de391  vmovaps xmm3, [rsp+0x30]
00007fdcd91de397  vmovaps xmm5, [rsp+0x40]
00007fdcd91de39d  vmovaps xmm6, [rsp+0x50]
00007fdcd91de3a3  vmovaps xmm7, [rsp+0x60]
00007fdcd91de3a9  vmovaps xmm8, [rsp+0x70]
00007fdcd91de3af  vmovaps xmm9, [rsp+0x80]
00007fdcd91de3b8  vmovaps xmm10, [rsp+0x90]
00007fdcd91de3c1  vmovaps xmm11, [rsp+0xA0]
00007fdcd91de3ca  vmovaps xmm12, [rsp+0xB0]
00007fdcd91de3d3  vmovaps xmm13, [rsp+0xC0]
00007fdcd91de3dc  vmovaps xmm14, [rsp+0xD0]
00007fdcd91de3e5  vmovaps xmm15, [rsp+0xE0]
00007fdcd91de3ee  add rsp, 0xF0
00007fdcd91de3f5  pop r11
00007fdcd91de3f7  pop r10
00007fdcd91de3f9  pop r9
00007fdcd91de3fb  pop r8
00007fdcd91de3fd  pop rsi
00007fdcd91de3fe  pop rdi
00007fdcd91de3ff  pop rdx
00007fdcd91de400  pop rcx
00007fdcd91de401  pop rax
00007fdcd91de402  add rsp, 0x08
00007fdcd91de406  jmp 0x00007FDCD91DC107
00007fdcd91de40b  call 0x00007FDCD90B52F0
00007fdcd91de410  jmp 0x00007FDCD91DC114
00007fdcd91de415  sub rsp, 0x08
00007fdcd91de419  push rax
00007fdcd91de41a  push rcx
00007fdcd91de41b  push rdx
00007fdcd91de41c  push rdi
00007fdcd91de41d  push rsi
00007fdcd91de41e  push r8
00007fdcd91de420  push r9
00007fdcd91de422  push r10
00007fdcd91de424  push r11
00007fdcd91de426  sub rsp, 0xF0
00007fdcd91de42d  vmovaps [rsp], xmm0
00007fdcd91de432  vmovaps [rsp+0x10], xmm1
00007fdcd91de438  vmovaps [rsp+0x20], xmm2
00007fdcd91de43e  vmovaps [rsp+0x30], xmm3
00007fdcd91de444  vmovaps [rsp+0x40], xmm4
00007fdcd91de44a  vmovaps [rsp+0x50], xmm6
00007fdcd91de450  vmovaps [rsp+0x60], xmm7
00007fdcd91de456  vmovaps [rsp+0x70], xmm8
00007fdcd91de45c  vmovaps [rsp+0x80], xmm9
00007fdcd91de465  vmovaps [rsp+0x90], xmm10
00007fdcd91de46e  vmovaps [rsp+0xA0], xmm11
00007fdcd91de477  vmovaps [rsp+0xB0], xmm12
00007fdcd91de480  vmovaps [rsp+0xC0], xmm13
00007fdcd91de489  vmovaps [rsp+0xD0], xmm14
00007fdcd91de492  vmovaps [rsp+0xE0], xmm15
00007fdcd91de49b  sub rsp, 0x30
00007fdcd91de49f  movaps [rsp], xmm5
00007fdcd91de4a3  movaps [rsp+0x10], xmm6
00007fdcd91de4a8  movaps [rsp+0x20], xmm3
00007fdcd91de4ad  lea rdi, [rsp]
00007fdcd91de4b1  mov esi, 0x00
00007fdcd91de4b6  mov rax, 0x5B56EFBF3530
00007fdcd91de4c0  call rax
00007fdcd91de4c2  movaps xmm5, [rsp]
00007fdcd91de4c6  add rsp, 0x30
00007fdcd91de4ca  vmovaps xmm0, [rsp]
00007fdcd91de4cf  vmovaps xmm1, [rsp+0x10]
00007fdcd91de4d5  vmovaps xmm2, [rsp+0x20]
00007fdcd91de4db  vmovaps xmm3, [rsp+0x30]
00007fdcd91de4e1  vmovaps xmm4, [rsp+0x40]
00007fdcd91de4e7  vmovaps xmm6, [rsp+0x50]
00007fdcd91de4ed  vmovaps xmm7, [rsp+0x60]
00007fdcd91de4f3  vmovaps xmm8, [rsp+0x70]
00007fdcd91de4f9  vmovaps xmm9, [rsp+0x80]
00007fdcd91de502  vmovaps xmm10, [rsp+0x90]
00007fdcd91de50b  vmovaps xmm11, [rsp+0xA0]
00007fdcd91de514  vmovaps xmm12, [rsp+0xB0]
00007fdcd91de51d  vmovaps xmm13, [rsp+0xC0]
00007fdcd91de526  vmovaps xmm14, [rsp+0xD0]
00007fdcd91de52f  vmovaps xmm15, [rsp+0xE0]
00007fdcd91de538  add rsp, 0xF0
00007fdcd91de53f  pop r11
00007fdcd91de541  pop r10
00007fdcd91de543  pop r9
00007fdcd91de545  pop r8
00007fdcd91de547  pop rsi
00007fdcd91de548  pop rdi
00007fdcd91de549  pop rdx
00007fdcd91de54a  pop rcx
00007fdcd91de54b  pop rax
00007fdcd91de54c  add rsp, 0x08
00007fdcd91de550  jmp 0x00007FDCD91DC13A
00007fdcd91de555  sub rsp, 0x08
00007fdcd91de559  push rax
00007fdcd91de55a  push rcx
00007fdcd91de55b  push rdx
00007fdcd91de55c  push rdi
00007fdcd91de55d  push rsi
00007fdcd91de55e  push r8
00007fdcd91de560  push r9
00007fdcd91de562  push r10
00007fdcd91de564  push r11
00007fdcd91de566  sub rsp, 0xF0
00007fdcd91de56d  vmovaps [rsp], xmm0
00007fdcd91de572  vmovaps [rsp+0x10], xmm1
00007fdcd91de578  vmovaps [rsp+0x20], xmm2
00007fdcd91de57e  vmovaps [rsp+0x30], xmm3
00007fdcd91de584  vmovaps [rsp+0x40], xmm4
00007fdcd91de58a  vmovaps [rsp+0x50], xmm5
00007fdcd91de590  vmovaps [rsp+0x60], xmm7
00007fdcd91de596  vmovaps [rsp+0x70], xmm8
00007fdcd91de59c  vmovaps [rsp+0x80], xmm9
00007fdcd91de5a5  vmovaps [rsp+0x90], xmm10
00007fdcd91de5ae  vmovaps [rsp+0xA0], xmm11
00007fdcd91de5b7  vmovaps [rsp+0xB0], xmm12
00007fdcd91de5c0  vmovaps [rsp+0xC0], xmm13
00007fdcd91de5c9  vmovaps [rsp+0xD0], xmm14
00007fdcd91de5d2  vmovaps [rsp+0xE0], xmm15
00007fdcd91de5db  sub rsp, 0x30
00007fdcd91de5df  movaps [rsp], xmm6
00007fdcd91de5e3  movaps [rsp+0x10], xmm9
00007fdcd91de5e9  movaps [rsp+0x20], xmm1
00007fdcd91de5ee  lea rdi, [rsp]
00007fdcd91de5f2  mov esi, 0x00
00007fdcd91de5f7  mov rax, 0x5B56EFBF3530
00007fdcd91de601  call rax
00007fdcd91de603  movaps xmm6, [rsp]
00007fdcd91de607  add rsp, 0x30
00007fdcd91de60b  vmovaps xmm0, [rsp]
00007fdcd91de610  vmovaps xmm1, [rsp+0x10]
00007fdcd91de616  vmovaps xmm2, [rsp+0x20]
00007fdcd91de61c  vmovaps xmm3, [rsp+0x30]
00007fdcd91de622  vmovaps xmm4, [rsp+0x40]
00007fdcd91de628  vmovaps xmm5, [rsp+0x50]
00007fdcd91de62e  vmovaps xmm7, [rsp+0x60]
00007fdcd91de634  vmovaps xmm8, [rsp+0x70]
00007fdcd91de63a  vmovaps xmm9, [rsp+0x80]
00007fdcd91de643  vmovaps xmm10, [rsp+0x90]
00007fdcd91de64c  vmovaps xmm11, [rsp+0xA0]
00007fdcd91de655  vmovaps xmm12, [rsp+0xB0]
00007fdcd91de65e  vmovaps xmm13, [rsp+0xC0]
00007fdcd91de667  vmovaps xmm14, [rsp+0xD0]
00007fdcd91de670  vmovaps xmm15, [rsp+0xE0]
00007fdcd91de679  add rsp, 0xF0
00007fdcd91de680  pop r11
00007fdcd91de682  pop r10
00007fdcd91de684  pop r9
00007fdcd91de686  pop r8
00007fdcd91de688  pop rsi
00007fdcd91de689  pop rdi
00007fdcd91de68a  pop rdx
00007fdcd91de68b  pop rcx
00007fdcd91de68c  pop rax
00007fdcd91de68d  add rsp, 0x08
00007fdcd91de691  jmp 0x00007FDCD91DC15E
00007fdcd91de696  sub rsp, 0x08
00007fdcd91de69a  push rax
00007fdcd91de69b  push rcx
00007fdcd91de69c  push rdx
00007fdcd91de69d  push rdi
00007fdcd91de69e  push rsi
00007fdcd91de69f  push r8
00007fdcd91de6a1  push r9
00007fdcd91de6a3  push r10
00007fdcd91de6a5  push r11
00007fdcd91de6a7  sub rsp, 0xF0
00007fdcd91de6ae  vmovaps [rsp], xmm0
00007fdcd91de6b3  vmovaps [rsp+0x10], xmm1
00007fdcd91de6b9  vmovaps [rsp+0x20], xmm2
00007fdcd91de6bf  vmovaps [rsp+0x30], xmm3
00007fdcd91de6c5  vmovaps [rsp+0x40], xmm4
00007fdcd91de6cb  vmovaps [rsp+0x50], xmm5
00007fdcd91de6d1  vmovaps [rsp+0x60], xmm6
00007fdcd91de6d7  vmovaps [rsp+0x70], xmm7
00007fdcd91de6dd  vmovaps [rsp+0x80], xmm8
00007fdcd91de6e6  vmovaps [rsp+0x90], xmm10
00007fdcd91de6ef  vmovaps [rsp+0xA0], xmm11
00007fdcd91de6f8  vmovaps [rsp+0xB0], xmm12
00007fdcd91de701  vmovaps [rsp+0xC0], xmm13
00007fdcd91de70a  vmovaps [rsp+0xD0], xmm14
00007fdcd91de713  vmovaps [rsp+0xE0], xmm15
00007fdcd91de71c  sub rsp, 0x30
00007fdcd91de720  movaps [rsp], xmm9
00007fdcd91de725  movaps [rsp+0x10], xmm3
00007fdcd91de72a  movaps [rsp+0x20], xmm1
00007fdcd91de72f  lea rdi, [rsp]
00007fdcd91de733  mov esi, 0x00
00007fdcd91de738  mov rax, 0x5B56EFBF3530
00007fdcd91de742  call rax
00007fdcd91de744  movaps xmm9, [rsp]
00007fdcd91de749  add rsp, 0x30
00007fdcd91de74d  vmovaps xmm0, [rsp]
00007fdcd91de752  vmovaps xmm1, [rsp+0x10]
00007fdcd91de758  vmovaps xmm2, [rsp+0x20]
00007fdcd91de75e  vmovaps xmm3, [rsp+0x30]
00007fdcd91de764  vmovaps xmm4, [rsp+0x40]
00007fdcd91de76a  vmovaps xmm5, [rsp+0x50]
00007fdcd91de770  vmovaps xmm6, [rsp+0x60]
00007fdcd91de776  vmovaps xmm7, [rsp+0x70]
00007fdcd91de77c  vmovaps xmm8, [rsp+0x80]
00007fdcd91de785  vmovaps xmm10, [rsp+0x90]
00007fdcd91de78e  vmovaps xmm11, [rsp+0xA0]
00007fdcd91de797  vmovaps xmm12, [rsp+0xB0]
00007fdcd91de7a0  vmovaps xmm13, [rsp+0xC0]
00007fdcd91de7a9  vmovaps xmm14, [rsp+0xD0]
00007fdcd91de7b2  vmovaps xmm15, [rsp+0xE0]
00007fdcd91de7bb  add rsp, 0xF0
00007fdcd91de7c2  pop r11
00007fdcd91de7c4  pop r10
00007fdcd91de7c6  pop r9
00007fdcd91de7c8  pop r8
00007fdcd91de7ca  pop rsi
00007fdcd91de7cb  pop rdi
00007fdcd91de7cc  pop rdx
00007fdcd91de7cd  pop rcx
00007fdcd91de7ce  pop rax
00007fdcd91de7cf  add rsp, 0x08
00007fdcd91de7d3  jmp 0x00007FDCD91DC1AA
00007fdcd91de7d8  call 0x00007FDCD90B52F0
00007fdcd91de7dd  jmp 0x00007FDCD91DC1B7
00007fdcd91de7e2  sub rsp, 0x08
00007fdcd91de7e6  push rax
00007fdcd91de7e7  push rcx
00007fdcd91de7e8  push rdx
00007fdcd91de7e9  push rdi
00007fdcd91de7ea  push rsi
00007fdcd91de7eb  push r8
00007fdcd91de7ed  push r9
00007fdcd91de7ef  push r10
00007fdcd91de7f1  push r11
00007fdcd91de7f3  sub rsp, 0xF0
00007fdcd91de7fa  vmovaps [rsp], xmm0
00007fdcd91de7ff  vmovaps [rsp+0x10], xmm1
00007fdcd91de805  vmovaps [rsp+0x20], xmm2
00007fdcd91de80b  vmovaps [rsp+0x30], xmm3
00007fdcd91de811  vmovaps [rsp+0x40], xmm4
00007fdcd91de817  vmovaps [rsp+0x50], xmm5
00007fdcd91de81d  vmovaps [rsp+0x60], xmm6
00007fdcd91de823  vmovaps [rsp+0x70], xmm7
00007fdcd91de829  vmovaps [rsp+0x80], xmm8
00007fdcd91de832  vmovaps [rsp+0x90], xmm9
00007fdcd91de83b  vmovaps [rsp+0xA0], xmm10
00007fdcd91de844  vmovaps [rsp+0xB0], xmm11
00007fdcd91de84d  vmovaps [rsp+0xC0], xmm12
00007fdcd91de856  vmovaps [rsp+0xD0], xmm13
00007fdcd91de85f  vmovaps [rsp+0xE0], xmm14
00007fdcd91de868  sub rsp, 0x30
00007fdcd91de86c  movaps [rsp], xmm15
00007fdcd91de871  movaps [rsp+0x10], xmm3
00007fdcd91de876  movaps [rsp+0x20], xmm7
00007fdcd91de87b  lea rdi, [rsp]
00007fdcd91de87f  mov esi, 0x00
00007fdcd91de884  mov rax, 0x5B56EFBF3530
00007fdcd91de88e  call rax
00007fdcd91de890  movaps xmm15, [rsp]
00007fdcd91de895  add rsp, 0x30
00007fdcd91de899  vmovaps xmm0, [rsp]
00007fdcd91de89e  vmovaps xmm1, [rsp+0x10]
00007fdcd91de8a4  vmovaps xmm2, [rsp+0x20]
00007fdcd91de8aa  vmovaps xmm3, [rsp+0x30]
00007fdcd91de8b0  vmovaps xmm4, [rsp+0x40]
00007fdcd91de8b6  vmovaps xmm5, [rsp+0x50]
00007fdcd91de8bc  vmovaps xmm6, [rsp+0x60]
00007fdcd91de8c2  vmovaps xmm7, [rsp+0x70]
00007fdcd91de8c8  vmovaps xmm8, [rsp+0x80]
00007fdcd91de8d1  vmovaps xmm9, [rsp+0x90]
00007fdcd91de8da  vmovaps xmm10, [rsp+0xA0]
00007fdcd91de8e3  vmovaps xmm11, [rsp+0xB0]
00007fdcd91de8ec  vmovaps xmm12, [rsp+0xC0]
00007fdcd91de8f5  vmovaps xmm13, [rsp+0xD0]
00007fdcd91de8fe  vmovaps xmm14, [rsp+0xE0]
00007fdcd91de907  add rsp, 0xF0
00007fdcd91de90e  pop r11
00007fdcd91de910  pop r10
00007fdcd91de912  pop r9
00007fdcd91de914  pop r8
00007fdcd91de916  pop rsi
00007fdcd91de917  pop rdi
00007fdcd91de918  pop rdx
00007fdcd91de919  pop rcx
00007fdcd91de91a  pop rax
00007fdcd91de91b  add rsp, 0x08
00007fdcd91de91f  jmp 0x00007FDCD91DC1E3
00007fdcd91de924  sub rsp, 0x08
00007fdcd91de928  push rax
00007fdcd91de929  push rcx
00007fdcd91de92a  push rdx
00007fdcd91de92b  push rdi
00007fdcd91de92c  push rsi
00007fdcd91de92d  push r8
00007fdcd91de92f  push r9
00007fdcd91de931  push r10
00007fdcd91de933  push r11
00007fdcd91de935  sub rsp, 0xF0
00007fdcd91de93c  vmovaps [rsp], xmm0
00007fdcd91de941  vmovaps [rsp+0x10], xmm1
00007fdcd91de947  vmovaps [rsp+0x20], xmm2
00007fdcd91de94d  vmovaps [rsp+0x30], xmm4
00007fdcd91de953  vmovaps [rsp+0x40], xmm5
00007fdcd91de959  vmovaps [rsp+0x50], xmm6
00007fdcd91de95f  vmovaps [rsp+0x60], xmm7
00007fdcd91de965  vmovaps [rsp+0x70], xmm8
00007fdcd91de96b  vmovaps [rsp+0x80], xmm9
00007fdcd91de974  vmovaps [rsp+0x90], xmm10
00007fdcd91de97d  vmovaps [rsp+0xA0], xmm11
00007fdcd91de986  vmovaps [rsp+0xB0], xmm12
00007fdcd91de98f  vmovaps [rsp+0xC0], xmm13
00007fdcd91de998  vmovaps [rsp+0xD0], xmm14
00007fdcd91de9a1  vmovaps [rsp+0xE0], xmm15
00007fdcd91de9aa  sub rsp, 0x30
00007fdcd91de9ae  movaps [rsp], xmm3
00007fdcd91de9b2  movaps [rsp+0x10], xmm1
00007fdcd91de9b7  movaps [rsp+0x20], xmm15
00007fdcd91de9bd  lea rdi, [rsp]
00007fdcd91de9c1  mov esi, 0x00
00007fdcd91de9c6  mov rax, 0x5B56EFBF3530
00007fdcd91de9d0  call rax
00007fdcd91de9d2  movaps xmm3, [rsp]
00007fdcd91de9d6  add rsp, 0x30
00007fdcd91de9da  vmovaps xmm0, [rsp]
00007fdcd91de9df  vmovaps xmm1, [rsp+0x10]
00007fdcd91de9e5  vmovaps xmm2, [rsp+0x20]
00007fdcd91de9eb  vmovaps xmm4, [rsp+0x30]
00007fdcd91de9f1  vmovaps xmm5, [rsp+0x40]
00007fdcd91de9f7  vmovaps xmm6, [rsp+0x50]
00007fdcd91de9fd  vmovaps xmm7, [rsp+0x60]
00007fdcd91dea03  vmovaps xmm8, [rsp+0x70]
00007fdcd91dea09  vmovaps xmm9, [rsp+0x80]
00007fdcd91dea12  vmovaps xmm10, [rsp+0x90]
00007fdcd91dea1b  vmovaps xmm11, [rsp+0xA0]
00007fdcd91dea24  vmovaps xmm12, [rsp+0xB0]
00007fdcd91dea2d  vmovaps xmm13, [rsp+0xC0]
00007fdcd91dea36  vmovaps xmm14, [rsp+0xD0]
00007fdcd91dea3f  vmovaps xmm15, [rsp+0xE0]
00007fdcd91dea48  add rsp, 0xF0
00007fdcd91dea4f  pop r11
00007fdcd91dea51  pop r10
00007fdcd91dea53  pop r9
00007fdcd91dea55  pop r8
00007fdcd91dea57  pop rsi
00007fdcd91dea58  pop rdi
00007fdcd91dea59  pop rdx
00007fdcd91dea5a  pop rcx
00007fdcd91dea5b  pop rax
00007fdcd91dea5c  add rsp, 0x08
00007fdcd91dea60  jmp 0x00007FDCD91DC272
00007fdcd91dea65  call 0x00007FDCD90B52F0
00007fdcd91dea6a  jmp 0x00007FDCD91DC27C
00007fdcd91dea6f  sub rsp, 0x08
00007fdcd91dea73  push rax
00007fdcd91dea74  push rcx
00007fdcd91dea75  push rdx
00007fdcd91dea76  push rdi
00007fdcd91dea77  push rsi
00007fdcd91dea78  push r8
00007fdcd91dea7a  push r9
00007fdcd91dea7c  push r10
00007fdcd91dea7e  push r11
00007fdcd91dea80  sub rsp, 0xF0
00007fdcd91dea87  vmovaps [rsp], xmm0
00007fdcd91dea8c  vmovaps [rsp+0x10], xmm1
00007fdcd91dea92  vmovaps [rsp+0x20], xmm2
00007fdcd91dea98  vmovaps [rsp+0x30], xmm3
00007fdcd91dea9e  vmovaps [rsp+0x40], xmm4
00007fdcd91deaa4  vmovaps [rsp+0x50], xmm5
00007fdcd91deaaa  vmovaps [rsp+0x60], xmm6
00007fdcd91deab0  vmovaps [rsp+0x70], xmm7
00007fdcd91deab6  vmovaps [rsp+0x80], xmm8
00007fdcd91deabf  vmovaps [rsp+0x90], xmm9
00007fdcd91deac8  vmovaps [rsp+0xA0], xmm10
00007fdcd91dead1  vmovaps [rsp+0xB0], xmm11
00007fdcd91deada  vmovaps [rsp+0xC0], xmm12
00007fdcd91deae3  vmovaps [rsp+0xD0], xmm13
00007fdcd91deaec  vmovaps [rsp+0xE0], xmm14
00007fdcd91deaf5  sub rsp, 0x30
00007fdcd91deaf9  movaps [rsp], xmm15
00007fdcd91deafe  movaps [rsp+0x10], xmm14
00007fdcd91deb04  movaps [rsp+0x20], xmm4
00007fdcd91deb09  lea rdi, [rsp]
00007fdcd91deb0d  mov esi, 0x00
00007fdcd91deb12  mov rax, 0x5B56EFBF3530
00007fdcd91deb1c  call rax
00007fdcd91deb1e  movaps xmm15, [rsp]
00007fdcd91deb23  add rsp, 0x30
00007fdcd91deb27  vmovaps xmm0, [rsp]
00007fdcd91deb2c  vmovaps xmm1, [rsp+0x10]
00007fdcd91deb32  vmovaps xmm2, [rsp+0x20]
00007fdcd91deb38  vmovaps xmm3, [rsp+0x30]
00007fdcd91deb3e  vmovaps xmm4, [rsp+0x40]
00007fdcd91deb44  vmovaps xmm5, [rsp+0x50]
00007fdcd91deb4a  vmovaps xmm6, [rsp+0x60]
00007fdcd91deb50  vmovaps xmm7, [rsp+0x70]
00007fdcd91deb56  vmovaps xmm8, [rsp+0x80]
00007fdcd91deb5f  vmovaps xmm9, [rsp+0x90]
00007fdcd91deb68  vmovaps xmm10, [rsp+0xA0]
00007fdcd91deb71  vmovaps xmm11, [rsp+0xB0]
00007fdcd91deb7a  vmovaps xmm12, [rsp+0xC0]
00007fdcd91deb83  vmovaps xmm13, [rsp+0xD0]
00007fdcd91deb8c  vmovaps xmm14, [rsp+0xE0]
00007fdcd91deb95  add rsp, 0xF0
00007fdcd91deb9c  pop r11
00007fdcd91deb9e  pop r10
00007fdcd91deba0  pop r9
00007fdcd91deba2  pop r8
00007fdcd91deba4  pop rsi
00007fdcd91deba5  pop rdi
00007fdcd91deba6  pop rdx
00007fdcd91deba7  pop rcx
00007fdcd91deba8  pop rax
00007fdcd91deba9  add rsp, 0x08
00007fdcd91debad  jmp 0x00007FDCD91DC2AA
00007fdcd91debb2  sub rsp, 0x08
00007fdcd91debb6  push rax
00007fdcd91debb7  push rcx
00007fdcd91debb8  push rdx
00007fdcd91debb9  push rdi
00007fdcd91debba  push rsi
00007fdcd91debbb  push r8
00007fdcd91debbd  push r9
00007fdcd91debbf  push r10
00007fdcd91debc1  push r11
00007fdcd91debc3  sub rsp, 0xF0
00007fdcd91debca  vmovaps [rsp], xmm0
00007fdcd91debcf  vmovaps [rsp+0x10], xmm1
00007fdcd91debd5  vmovaps [rsp+0x20], xmm2
00007fdcd91debdb  vmovaps [rsp+0x30], xmm3
00007fdcd91debe1  vmovaps [rsp+0x40], xmm4
00007fdcd91debe7  vmovaps [rsp+0x50], xmm5
00007fdcd91debed  vmovaps [rsp+0x60], xmm6
00007fdcd91debf3  vmovaps [rsp+0x70], xmm7
00007fdcd91debf9  vmovaps [rsp+0x80], xmm8
00007fdcd91dec02  vmovaps [rsp+0x90], xmm9
00007fdcd91dec0b  vmovaps [rsp+0xA0], xmm10
00007fdcd91dec14  vmovaps [rsp+0xB0], xmm11
00007fdcd91dec1d  vmovaps [rsp+0xC0], xmm12
00007fdcd91dec26  vmovaps [rsp+0xD0], xmm13
00007fdcd91dec2f  vmovaps [rsp+0xE0], xmm15
00007fdcd91dec38  sub rsp, 0x30
00007fdcd91dec3c  movaps [rsp], xmm14
00007fdcd91dec41  movaps [rsp+0x10], xmm2
00007fdcd91dec46  movaps [rsp+0x20], xmm1
00007fdcd91dec4b  lea rdi, [rsp]
00007fdcd91dec4f  mov esi, 0x00
00007fdcd91dec54  mov rax, 0x5B56EFBF3530
00007fdcd91dec5e  call rax
00007fdcd91dec60  movaps xmm14, [rsp]
00007fdcd91dec65  add rsp, 0x30
00007fdcd91dec69  vmovaps xmm0, [rsp]
00007fdcd91dec6e  vmovaps xmm1, [rsp+0x10]
00007fdcd91dec74  vmovaps xmm2, [rsp+0x20]
00007fdcd91dec7a  vmovaps xmm3, [rsp+0x30]
00007fdcd91dec80  vmovaps xmm4, [rsp+0x40]
00007fdcd91dec86  vmovaps xmm5, [rsp+0x50]
00007fdcd91dec8c  vmovaps xmm6, [rsp+0x60]
00007fdcd91dec92  vmovaps xmm7, [rsp+0x70]
00007fdcd91dec98  vmovaps xmm8, [rsp+0x80]
00007fdcd91deca1  vmovaps xmm9, [rsp+0x90]
00007fdcd91decaa  vmovaps xmm10, [rsp+0xA0]
00007fdcd91decb3  vmovaps xmm11, [rsp+0xB0]
00007fdcd91decbc  vmovaps xmm12, [rsp+0xC0]
00007fdcd91decc5  vmovaps xmm13, [rsp+0xD0]
00007fdcd91decce  vmovaps xmm15, [rsp+0xE0]
00007fdcd91decd7  add rsp, 0xF0
00007fdcd91decde  pop r11
00007fdcd91dece0  pop r10
00007fdcd91dece2  pop r9
00007fdcd91dece4  pop r8
00007fdcd91dece6  pop rsi
00007fdcd91dece7  pop rdi
00007fdcd91dece8  pop rdx
00007fdcd91dece9  pop rcx
00007fdcd91decea  pop rax
00007fdcd91deceb  add rsp, 0x08
00007fdcd91decef  jmp 0x00007FDCD91DC2D0
00007fdcd91decf4  sub rsp, 0x08
00007fdcd91decf8  push rax
00007fdcd91decf9  push rcx
00007fdcd91decfa  push rdx
00007fdcd91decfb  push rdi
00007fdcd91decfc  push rsi
00007fdcd91decfd  push r8
00007fdcd91decff  push r9
00007fdcd91ded01  push r10
00007fdcd91ded03  push r11
00007fdcd91ded05  sub rsp, 0xF0
00007fdcd91ded0c  vmovaps [rsp], xmm0
00007fdcd91ded11  vmovaps [rsp+0x10], xmm2
00007fdcd91ded17  vmovaps [rsp+0x20], xmm3
00007fdcd91ded1d  vmovaps [rsp+0x30], xmm4
00007fdcd91ded23  vmovaps [rsp+0x40], xmm5
00007fdcd91ded29  vmovaps [rsp+0x50], xmm6
00007fdcd91ded2f  vmovaps [rsp+0x60], xmm7
00007fdcd91ded35  vmovaps [rsp+0x70], xmm8
00007fdcd91ded3b  vmovaps [rsp+0x80], xmm9
00007fdcd91ded44  vmovaps [rsp+0x90], xmm10
00007fdcd91ded4d  vmovaps [rsp+0xA0], xmm11
00007fdcd91ded56  vmovaps [rsp+0xB0], xmm12
00007fdcd91ded5f  vmovaps [rsp+0xC0], xmm13
00007fdcd91ded68  vmovaps [rsp+0xD0], xmm14
00007fdcd91ded71  vmovaps [rsp+0xE0], xmm15
00007fdcd91ded7a  sub rsp, 0x30
00007fdcd91ded7e  movaps [rsp], xmm1
00007fdcd91ded82  movaps [rsp+0x10], xmm4
00007fdcd91ded87  movaps [rsp+0x20], xmm9
00007fdcd91ded8d  lea rdi, [rsp]
00007fdcd91ded91  mov esi, 0x00
00007fdcd91ded96  mov rax, 0x5B56EFBF3530
00007fdcd91deda0  call rax
00007fdcd91deda2  movaps xmm1, [rsp]
00007fdcd91deda6  add rsp, 0x30
00007fdcd91dedaa  vmovaps xmm0, [rsp]
00007fdcd91dedaf  vmovaps xmm2, [rsp+0x10]
00007fdcd91dedb5  vmovaps xmm3, [rsp+0x20]
00007fdcd91dedbb  vmovaps xmm4, [rsp+0x30]
00007fdcd91dedc1  vmovaps xmm5, [rsp+0x40]
00007fdcd91dedc7  vmovaps xmm6, [rsp+0x50]
00007fdcd91dedcd  vmovaps xmm7, [rsp+0x60]
00007fdcd91dedd3  vmovaps xmm8, [rsp+0x70]
00007fdcd91dedd9  vmovaps xmm9, [rsp+0x80]
00007fdcd91dede2  vmovaps xmm10, [rsp+0x90]
00007fdcd91dedeb  vmovaps xmm11, [rsp+0xA0]
00007fdcd91dedf4  vmovaps xmm12, [rsp+0xB0]
00007fdcd91dedfd  vmovaps xmm13, [rsp+0xC0]
00007fdcd91dee06  vmovaps xmm14, [rsp+0xD0]
00007fdcd91dee0f  vmovaps xmm15, [rsp+0xE0]
00007fdcd91dee18  add rsp, 0xF0
00007fdcd91dee1f  pop r11
00007fdcd91dee21  pop r10
00007fdcd91dee23  pop r9
00007fdcd91dee25  pop r8
00007fdcd91dee27  pop rsi
00007fdcd91dee28  pop rdi
00007fdcd91dee29  pop rdx
00007fdcd91dee2a  pop rcx
00007fdcd91dee2b  pop rax
00007fdcd91dee2c  add rsp, 0x08
00007fdcd91dee30  jmp 0x00007FDCD91DC2EE
00007fdcd91dee35  sub rsp, 0x08
00007fdcd91dee39  push rax
00007fdcd91dee3a  push rcx
00007fdcd91dee3b  push rdx
00007fdcd91dee3c  push rdi
00007fdcd91dee3d  push rsi
00007fdcd91dee3e  push r8
00007fdcd91dee40  push r9
00007fdcd91dee42  push r10
00007fdcd91dee44  push r11
00007fdcd91dee46  sub rsp, 0xF0
00007fdcd91dee4d  vmovaps [rsp], xmm0
00007fdcd91dee52  vmovaps [rsp+0x10], xmm1
00007fdcd91dee58  vmovaps [rsp+0x20], xmm2
00007fdcd91dee5e  vmovaps [rsp+0x30], xmm3
00007fdcd91dee64  vmovaps [rsp+0x40], xmm5
00007fdcd91dee6a  vmovaps [rsp+0x50], xmm6
00007fdcd91dee70  vmovaps [rsp+0x60], xmm7
00007fdcd91dee76  vmovaps [rsp+0x70], xmm8
00007fdcd91dee7c  vmovaps [rsp+0x80], xmm9
00007fdcd91dee85  vmovaps [rsp+0x90], xmm10
00007fdcd91dee8e  vmovaps [rsp+0xA0], xmm11
00007fdcd91dee97  vmovaps [rsp+0xB0], xmm12
00007fdcd91deea0  vmovaps [rsp+0xC0], xmm13
00007fdcd91deea9  vmovaps [rsp+0xD0], xmm14
00007fdcd91deeb2  vmovaps [rsp+0xE0], xmm15
00007fdcd91deebb  sub rsp, 0x30
00007fdcd91deebf  movaps [rsp], xmm4
00007fdcd91deec3  movaps [rsp+0x10], xmm2
00007fdcd91deec8  movaps [rsp+0x20], xmm9
00007fdcd91deece  lea rdi, [rsp]
00007fdcd91deed2  mov esi, 0x00
00007fdcd91deed7  mov rax, 0x5B56EFBF3530
00007fdcd91deee1  call rax
00007fdcd91deee3  movaps xmm4, [rsp]
00007fdcd91deee7  add rsp, 0x30
00007fdcd91deeeb  vmovaps xmm0, [rsp]
00007fdcd91deef0  vmovaps xmm1, [rsp+0x10]
00007fdcd91deef6  vmovaps xmm2, [rsp+0x20]
00007fdcd91deefc  vmovaps xmm3, [rsp+0x30]
00007fdcd91def02  vmovaps xmm5, [rsp+0x40]
00007fdcd91def08  vmovaps xmm6, [rsp+0x50]
00007fdcd91def0e  vmovaps xmm7, [rsp+0x60]
00007fdcd91def14  vmovaps xmm8, [rsp+0x70]
00007fdcd91def1a  vmovaps xmm9, [rsp+0x80]
00007fdcd91def23  vmovaps xmm10, [rsp+0x90]
00007fdcd91def2c  vmovaps xmm11, [rsp+0xA0]
00007fdcd91def35  vmovaps xmm12, [rsp+0xB0]
00007fdcd91def3e  vmovaps xmm13, [rsp+0xC0]
00007fdcd91def47  vmovaps xmm14, [rsp+0xD0]
00007fdcd91def50  vmovaps xmm15, [rsp+0xE0]
00007fdcd91def59  add rsp, 0xF0
00007fdcd91def60  pop r11
00007fdcd91def62  pop r10
00007fdcd91def64  pop r9
00007fdcd91def66  pop r8
00007fdcd91def68  pop rsi
00007fdcd91def69  pop rdi
00007fdcd91def6a  pop rdx
00007fdcd91def6b  pop rcx
00007fdcd91def6c  pop rax
00007fdcd91def6d  add rsp, 0x08
00007fdcd91def71  jmp 0x00007FDCD91DC31E
00007fdcd91def76  sub rsp, 0x08
00007fdcd91def7a  push rax
00007fdcd91def7b  push rcx
00007fdcd91def7c  push rdx
00007fdcd91def7d  push rdi
00007fdcd91def7e  push rsi
00007fdcd91def7f  push r8
00007fdcd91def81  push r9
00007fdcd91def83  push r10
00007fdcd91def85  push r11
00007fdcd91def87  sub rsp, 0xF0
00007fdcd91def8e  vmovaps [rsp], xmm0
00007fdcd91def93  vmovaps [rsp+0x10], xmm1
00007fdcd91def99  vmovaps [rsp+0x20], xmm2
00007fdcd91def9f  vmovaps [rsp+0x30], xmm3
00007fdcd91defa5  vmovaps [rsp+0x40], xmm4
00007fdcd91defab  vmovaps [rsp+0x50], xmm5
00007fdcd91defb1  vmovaps [rsp+0x60], xmm6
00007fdcd91defb7  vmovaps [rsp+0x70], xmm7
00007fdcd91defbd  vmovaps [rsp+0x80], xmm8
00007fdcd91defc6  vmovaps [rsp+0x90], xmm10
00007fdcd91defcf  vmovaps [rsp+0xA0], xmm11
00007fdcd91defd8  vmovaps [rsp+0xB0], xmm12
00007fdcd91defe1  vmovaps [rsp+0xC0], xmm13
00007fdcd91defea  vmovaps [rsp+0xD0], xmm14
00007fdcd91deff3  vmovaps [rsp+0xE0], xmm15
00007fdcd91deffc  sub rsp, 0x30
00007fdcd91df000  movaps [rsp], xmm9
00007fdcd91df005  movaps [rsp+0x10], xmm2
00007fdcd91df00a  movaps [rsp+0x20], xmm1
00007fdcd91df00f  lea rdi, [rsp]
00007fdcd91df013  mov esi, 0x00
00007fdcd91df018  mov rax, 0x5B56EFBF3530
00007fdcd91df022  call rax
00007fdcd91df024  movaps xmm9, [rsp]
00007fdcd91df029  add rsp, 0x30
00007fdcd91df02d  vmovaps xmm0, [rsp]
00007fdcd91df032  vmovaps xmm1, [rsp+0x10]
00007fdcd91df038  vmovaps xmm2, [rsp+0x20]
00007fdcd91df03e  vmovaps xmm3, [rsp+0x30]
00007fdcd91df044  vmovaps xmm4, [rsp+0x40]
00007fdcd91df04a  vmovaps xmm5, [rsp+0x50]
00007fdcd91df050  vmovaps xmm6, [rsp+0x60]
00007fdcd91df056  vmovaps xmm7, [rsp+0x70]
00007fdcd91df05c  vmovaps xmm8, [rsp+0x80]
00007fdcd91df065  vmovaps xmm10, [rsp+0x90]
00007fdcd91df06e  vmovaps xmm11, [rsp+0xA0]
00007fdcd91df077  vmovaps xmm12, [rsp+0xB0]
00007fdcd91df080  vmovaps xmm13, [rsp+0xC0]
00007fdcd91df089  vmovaps xmm14, [rsp+0xD0]
00007fdcd91df092  vmovaps xmm15, [rsp+0xE0]
00007fdcd91df09b  add rsp, 0xF0
00007fdcd91df0a2  pop r11
00007fdcd91df0a4  pop r10
00007fdcd91df0a6  pop r9
00007fdcd91df0a8  pop r8
00007fdcd91df0aa  pop rsi
00007fdcd91df0ab  pop rdi
00007fdcd91df0ac  pop rdx
00007fdcd91df0ad  pop rcx
00007fdcd91df0ae  pop rax
00007fdcd91df0af  add rsp, 0x08
00007fdcd91df0b3  jmp 0x00007FDCD91DC354
00007fdcd91df0b8  sub rsp, 0x08
00007fdcd91df0bc  push rax
00007fdcd91df0bd  push rcx
00007fdcd91df0be  push rdx
00007fdcd91df0bf  push rdi
00007fdcd91df0c0  push rsi
00007fdcd91df0c1  push r8
00007fdcd91df0c3  push r9
00007fdcd91df0c5  push r10
00007fdcd91df0c7  push r11
00007fdcd91df0c9  sub rsp, 0xF0
00007fdcd91df0d0  vmovaps [rsp], xmm0
00007fdcd91df0d5  vmovaps [rsp+0x10], xmm2
00007fdcd91df0db  vmovaps [rsp+0x20], xmm3
00007fdcd91df0e1  vmovaps [rsp+0x30], xmm4
00007fdcd91df0e7  vmovaps [rsp+0x40], xmm5
00007fdcd91df0ed  vmovaps [rsp+0x50], xmm6
00007fdcd91df0f3  vmovaps [rsp+0x60], xmm7
00007fdcd91df0f9  vmovaps [rsp+0x70], xmm8
00007fdcd91df0ff  vmovaps [rsp+0x80], xmm9
00007fdcd91df108  vmovaps [rsp+0x90], xmm10
00007fdcd91df111  vmovaps [rsp+0xA0], xmm11
00007fdcd91df11a  vmovaps [rsp+0xB0], xmm12
00007fdcd91df123  vmovaps [rsp+0xC0], xmm13
00007fdcd91df12c  vmovaps [rsp+0xD0], xmm14
00007fdcd91df135  vmovaps [rsp+0xE0], xmm15
00007fdcd91df13e  sub rsp, 0x30
00007fdcd91df142  movaps [rsp], xmm1
00007fdcd91df146  movaps [rsp+0x10], xmm15
00007fdcd91df14c  movaps [rsp+0x20], xmm6
00007fdcd91df151  lea rdi, [rsp]
00007fdcd91df155  mov esi, 0x00
00007fdcd91df15a  mov rax, 0x5B56EFBF3530
00007fdcd91df164  call rax
00007fdcd91df166  movaps xmm1, [rsp]
00007fdcd91df16a  add rsp, 0x30
00007fdcd91df16e  vmovaps xmm0, [rsp]
00007fdcd91df173  vmovaps xmm2, [rsp+0x10]
00007fdcd91df179  vmovaps xmm3, [rsp+0x20]
00007fdcd91df17f  vmovaps xmm4, [rsp+0x30]
00007fdcd91df185  vmovaps xmm5, [rsp+0x40]
00007fdcd91df18b  vmovaps xmm6, [rsp+0x50]
00007fdcd91df191  vmovaps xmm7, [rsp+0x60]
00007fdcd91df197  vmovaps xmm8, [rsp+0x70]
00007fdcd91df19d  vmovaps xmm9, [rsp+0x80]
00007fdcd91df1a6  vmovaps xmm10, [rsp+0x90]
00007fdcd91df1af  vmovaps xmm11, [rsp+0xA0]
00007fdcd91df1b8  vmovaps xmm12, [rsp+0xB0]
00007fdcd91df1c1  vmovaps xmm13, [rsp+0xC0]
00007fdcd91df1ca  vmovaps xmm14, [rsp+0xD0]
00007fdcd91df1d3  vmovaps xmm15, [rsp+0xE0]
00007fdcd91df1dc  add rsp, 0xF0
00007fdcd91df1e3  pop r11
00007fdcd91df1e5  pop r10
00007fdcd91df1e7  pop r9
00007fdcd91df1e9  pop r8
00007fdcd91df1eb  pop rsi
00007fdcd91df1ec  pop rdi
00007fdcd91df1ed  pop rdx
00007fdcd91df1ee  pop rcx
00007fdcd91df1ef  pop rax
00007fdcd91df1f0  add rsp, 0x08
00007fdcd91df1f4  jmp 0x00007FDCD91DC375
00007fdcd91df1f9  sub rsp, 0x08
00007fdcd91df1fd  push rax
00007fdcd91df1fe  push rcx
00007fdcd91df1ff  push rdx
00007fdcd91df200  push rdi
00007fdcd91df201  push rsi
00007fdcd91df202  push r8
00007fdcd91df204  push r9
00007fdcd91df206  push r10
00007fdcd91df208  push r11
00007fdcd91df20a  sub rsp, 0xF0
00007fdcd91df211  vmovaps [rsp], xmm0
00007fdcd91df216  vmovaps [rsp+0x10], xmm1
00007fdcd91df21c  vmovaps [rsp+0x20], xmm2
00007fdcd91df222  vmovaps [rsp+0x30], xmm3
00007fdcd91df228  vmovaps [rsp+0x40], xmm4
00007fdcd91df22e  vmovaps [rsp+0x50], xmm5
00007fdcd91df234  vmovaps [rsp+0x60], xmm6
00007fdcd91df23a  vmovaps [rsp+0x70], xmm7
00007fdcd91df240  vmovaps [rsp+0x80], xmm8
00007fdcd91df249  vmovaps [rsp+0x90], xmm9
00007fdcd91df252  vmovaps [rsp+0xA0], xmm10
00007fdcd91df25b  vmovaps [rsp+0xB0], xmm11
00007fdcd91df264  vmovaps [rsp+0xC0], xmm12
00007fdcd91df26d  vmovaps [rsp+0xD0], xmm13
00007fdcd91df276  vmovaps [rsp+0xE0], xmm14
00007fdcd91df27f  sub rsp, 0x30
00007fdcd91df283  movaps [rsp], xmm15
00007fdcd91df288  movaps [rsp+0x10], xmm5
00007fdcd91df28d  movaps [rsp+0x20], xmm3
00007fdcd91df292  lea rdi, [rsp]
00007fdcd91df296  mov esi, 0x00
00007fdcd91df29b  mov rax, 0x5B56EFBF3530
00007fdcd91df2a5  call rax
00007fdcd91df2a7  movaps xmm15, [rsp]
00007fdcd91df2ac  add rsp, 0x30
00007fdcd91df2b0  vmovaps xmm0, [rsp]
00007fdcd91df2b5  vmovaps xmm1, [rsp+0x10]
00007fdcd91df2bb  vmovaps xmm2, [rsp+0x20]
00007fdcd91df2c1  vmovaps xmm3, [rsp+0x30]
00007fdcd91df2c7  vmovaps xmm4, [rsp+0x40]
00007fdcd91df2cd  vmovaps xmm5, [rsp+0x50]
00007fdcd91df2d3  vmovaps xmm6, [rsp+0x60]
00007fdcd91df2d9  vmovaps xmm7, [rsp+0x70]
00007fdcd91df2df  vmovaps xmm8, [rsp+0x80]
00007fdcd91df2e8  vmovaps xmm9, [rsp+0x90]
00007fdcd91df2f1  vmovaps xmm10, [rsp+0xA0]
00007fdcd91df2fa  vmovaps xmm11, [rsp+0xB0]
00007fdcd91df303  vmovaps xmm12, [rsp+0xC0]
00007fdcd91df30c  vmovaps xmm13, [rsp+0xD0]
00007fdcd91df315  vmovaps xmm14, [rsp+0xE0]
00007fdcd91df31e  add rsp, 0xF0
00007fdcd91df325  pop r11
00007fdcd91df327  pop r10
00007fdcd91df329  pop r9
00007fdcd91df32b  pop r8
00007fdcd91df32d  pop rsi
00007fdcd91df32e  pop rdi
00007fdcd91df32f  pop rdx
00007fdcd91df330  pop rcx
00007fdcd91df331  pop rax
00007fdcd91df332  add rsp, 0x08
00007fdcd91df336  jmp 0x00007FDCD91DC38F
00007fdcd91df33b  sub rsp, 0x08
00007fdcd91df33f  push rax
00007fdcd91df340  push rcx
00007fdcd91df341  push rdx
00007fdcd91df342  push rdi
00007fdcd91df343  push rsi
00007fdcd91df344  push r8
00007fdcd91df346  push r9
00007fdcd91df348  push r10
00007fdcd91df34a  push r11
00007fdcd91df34c  sub rsp, 0xF0
00007fdcd91df353  vmovaps [rsp], xmm0
00007fdcd91df358  vmovaps [rsp+0x10], xmm1
00007fdcd91df35e  vmovaps [rsp+0x20], xmm2
00007fdcd91df364  vmovaps [rsp+0x30], xmm3
00007fdcd91df36a  vmovaps [rsp+0x40], xmm4
00007fdcd91df370  vmovaps [rsp+0x50], xmm6
00007fdcd91df376  vmovaps [rsp+0x60], xmm7
00007fdcd91df37c  vmovaps [rsp+0x70], xmm8
00007fdcd91df382  vmovaps [rsp+0x80], xmm9
00007fdcd91df38b  vmovaps [rsp+0x90], xmm10
00007fdcd91df394  vmovaps [rsp+0xA0], xmm11
00007fdcd91df39d  vmovaps [rsp+0xB0], xmm12
00007fdcd91df3a6  vmovaps [rsp+0xC0], xmm13
00007fdcd91df3af  vmovaps [rsp+0xD0], xmm14
00007fdcd91df3b8  vmovaps [rsp+0xE0], xmm15
00007fdcd91df3c1  sub rsp, 0x30
00007fdcd91df3c5  movaps [rsp], xmm5
00007fdcd91df3c9  movaps [rsp+0x10], xmm8
00007fdcd91df3cf  movaps [rsp+0x20], xmm6
00007fdcd91df3d4  lea rdi, [rsp]
00007fdcd91df3d8  mov esi, 0x00
00007fdcd91df3dd  mov rax, 0x5B56EFBF3530
00007fdcd91df3e7  call rax
00007fdcd91df3e9  movaps xmm5, [rsp]
00007fdcd91df3ed  add rsp, 0x30
00007fdcd91df3f1  vmovaps xmm0, [rsp]
00007fdcd91df3f6  vmovaps xmm1, [rsp+0x10]
00007fdcd91df3fc  vmovaps xmm2, [rsp+0x20]
00007fdcd91df402  vmovaps xmm3, [rsp+0x30]
00007fdcd91df408  vmovaps xmm4, [rsp+0x40]
00007fdcd91df40e  vmovaps xmm6, [rsp+0x50]
00007fdcd91df414  vmovaps xmm7, [rsp+0x60]
00007fdcd91df41a  vmovaps xmm8, [rsp+0x70]
00007fdcd91df420  vmovaps xmm9, [rsp+0x80]
00007fdcd91df429  vmovaps xmm10, [rsp+0x90]
00007fdcd91df432  vmovaps xmm11, [rsp+0xA0]
00007fdcd91df43b  vmovaps xmm12, [rsp+0xB0]
00007fdcd91df444  vmovaps xmm13, [rsp+0xC0]
00007fdcd91df44d  vmovaps xmm14, [rsp+0xD0]
00007fdcd91df456  vmovaps xmm15, [rsp+0xE0]
00007fdcd91df45f  add rsp, 0xF0
00007fdcd91df466  pop r11
00007fdcd91df468  pop r10
00007fdcd91df46a  pop r9
00007fdcd91df46c  pop r8
00007fdcd91df46e  pop rsi
00007fdcd91df46f  pop rdi
00007fdcd91df470  pop rdx
00007fdcd91df471  pop rcx
00007fdcd91df472  pop rax
00007fdcd91df473  add rsp, 0x08
00007fdcd91df477  jmp 0x00007FDCD91DC3B3
00007fdcd91df47c  sub rsp, 0x08
00007fdcd91df480  push rax
00007fdcd91df481  push rcx
00007fdcd91df482  push rdx
00007fdcd91df483  push rdi
00007fdcd91df484  push rsi
00007fdcd91df485  push r8
00007fdcd91df487  push r9
00007fdcd91df489  push r10
00007fdcd91df48b  push r11
00007fdcd91df48d  sub rsp, 0xF0
00007fdcd91df494  vmovaps [rsp], xmm0
00007fdcd91df499  vmovaps [rsp+0x10], xmm1
00007fdcd91df49f  vmovaps [rsp+0x20], xmm2
00007fdcd91df4a5  vmovaps [rsp+0x30], xmm3
00007fdcd91df4ab  vmovaps [rsp+0x40], xmm4
00007fdcd91df4b1  vmovaps [rsp+0x50], xmm5
00007fdcd91df4b7  vmovaps [rsp+0x60], xmm7
00007fdcd91df4bd  vmovaps [rsp+0x70], xmm8
00007fdcd91df4c3  vmovaps [rsp+0x80], xmm9
00007fdcd91df4cc  vmovaps [rsp+0x90], xmm10
00007fdcd91df4d5  vmovaps [rsp+0xA0], xmm11
00007fdcd91df4de  vmovaps [rsp+0xB0], xmm12
00007fdcd91df4e7  vmovaps [rsp+0xC0], xmm13
00007fdcd91df4f0  vmovaps [rsp+0xD0], xmm14
00007fdcd91df4f9  vmovaps [rsp+0xE0], xmm15
00007fdcd91df502  sub rsp, 0x30
00007fdcd91df506  movaps [rsp], xmm6
00007fdcd91df50a  movaps [rsp+0x10], xmm10
00007fdcd91df510  movaps [rsp+0x20], xmm8
00007fdcd91df516  lea rdi, [rsp]
00007fdcd91df51a  mov esi, 0x00
00007fdcd91df51f  mov rax, 0x5B56EFBF3530
00007fdcd91df529  call rax
00007fdcd91df52b  movaps xmm6, [rsp]
00007fdcd91df52f  add rsp, 0x30
00007fdcd91df533  vmovaps xmm0, [rsp]
00007fdcd91df538  vmovaps xmm1, [rsp+0x10]
00007fdcd91df53e  vmovaps xmm2, [rsp+0x20]
00007fdcd91df544  vmovaps xmm3, [rsp+0x30]
00007fdcd91df54a  vmovaps xmm4, [rsp+0x40]
00007fdcd91df550  vmovaps xmm5, [rsp+0x50]
00007fdcd91df556  vmovaps xmm7, [rsp+0x60]
00007fdcd91df55c  vmovaps xmm8, [rsp+0x70]
00007fdcd91df562  vmovaps xmm9, [rsp+0x80]
00007fdcd91df56b  vmovaps xmm10, [rsp+0x90]
00007fdcd91df574  vmovaps xmm11, [rsp+0xA0]
00007fdcd91df57d  vmovaps xmm12, [rsp+0xB0]
00007fdcd91df586  vmovaps xmm13, [rsp+0xC0]
00007fdcd91df58f  vmovaps xmm14, [rsp+0xD0]
00007fdcd91df598  vmovaps xmm15, [rsp+0xE0]
00007fdcd91df5a1  add rsp, 0xF0
00007fdcd91df5a8  pop r11
00007fdcd91df5aa  pop r10
00007fdcd91df5ac  pop r9
00007fdcd91df5ae  pop r8
00007fdcd91df5b0  pop rsi
00007fdcd91df5b1  pop rdi
00007fdcd91df5b2  pop rdx
00007fdcd91df5b3  pop rcx
00007fdcd91df5b4  pop rax
00007fdcd91df5b5  add rsp, 0x08
00007fdcd91df5b9  jmp 0x00007FDCD91DC3D8
00007fdcd91df5be  sub rsp, 0x08
00007fdcd91df5c2  push rax
00007fdcd91df5c3  push rcx
00007fdcd91df5c4  push rdx
00007fdcd91df5c5  push rdi
00007fdcd91df5c6  push rsi
00007fdcd91df5c7  push r8
00007fdcd91df5c9  push r9
00007fdcd91df5cb  push r10
00007fdcd91df5cd  push r11
00007fdcd91df5cf  sub rsp, 0xF0
00007fdcd91df5d6  vmovaps [rsp], xmm0
00007fdcd91df5db  vmovaps [rsp+0x10], xmm1
00007fdcd91df5e1  vmovaps [rsp+0x20], xmm2
00007fdcd91df5e7  vmovaps [rsp+0x30], xmm3
00007fdcd91df5ed  vmovaps [rsp+0x40], xmm4
00007fdcd91df5f3  vmovaps [rsp+0x50], xmm5
00007fdcd91df5f9  vmovaps [rsp+0x60], xmm6
00007fdcd91df5ff  vmovaps [rsp+0x70], xmm7
00007fdcd91df605  vmovaps [rsp+0x80], xmm8
00007fdcd91df60e  vmovaps [rsp+0x90], xmm9
00007fdcd91df617  vmovaps [rsp+0xA0], xmm11
00007fdcd91df620  vmovaps [rsp+0xB0], xmm12
00007fdcd91df629  vmovaps [rsp+0xC0], xmm13
00007fdcd91df632  vmovaps [rsp+0xD0], xmm14
00007fdcd91df63b  vmovaps [rsp+0xE0], xmm15
00007fdcd91df644  sub rsp, 0x30
00007fdcd91df648  movaps [rsp], xmm10
00007fdcd91df64d  movaps [rsp+0x10], xmm8
00007fdcd91df653  movaps [rsp+0x20], xmm14
00007fdcd91df659  lea rdi, [rsp]
00007fdcd91df65d  mov esi, 0x00
00007fdcd91df662  mov rax, 0x5B56EFBF3530
00007fdcd91df66c  call rax
00007fdcd91df66e  movaps xmm10, [rsp]
00007fdcd91df673  add rsp, 0x30
00007fdcd91df677  vmovaps xmm0, [rsp]
00007fdcd91df67c  vmovaps xmm1, [rsp+0x10]
00007fdcd91df682  vmovaps xmm2, [rsp+0x20]
00007fdcd91df688  vmovaps xmm3, [rsp+0x30]
00007fdcd91df68e  vmovaps xmm4, [rsp+0x40]
00007fdcd91df694  vmovaps xmm5, [rsp+0x50]
00007fdcd91df69a  vmovaps xmm6, [rsp+0x60]
00007fdcd91df6a0  vmovaps xmm7, [rsp+0x70]
00007fdcd91df6a6  vmovaps xmm8, [rsp+0x80]
00007fdcd91df6af  vmovaps xmm9, [rsp+0x90]
00007fdcd91df6b8  vmovaps xmm11, [rsp+0xA0]
00007fdcd91df6c1  vmovaps xmm12, [rsp+0xB0]
00007fdcd91df6ca  vmovaps xmm13, [rsp+0xC0]
00007fdcd91df6d3  vmovaps xmm14, [rsp+0xD0]
00007fdcd91df6dc  vmovaps xmm15, [rsp+0xE0]
00007fdcd91df6e5  add rsp, 0xF0
00007fdcd91df6ec  pop r11
00007fdcd91df6ee  pop r10
00007fdcd91df6f0  pop r9
00007fdcd91df6f2  pop r8
00007fdcd91df6f4  pop rsi
00007fdcd91df6f5  pop rdi
00007fdcd91df6f6  pop rdx
00007fdcd91df6f7  pop rcx
00007fdcd91df6f8  pop rax
00007fdcd91df6f9  add rsp, 0x08
00007fdcd91df6fd  jmp 0x00007FDCD91DC3F8
00007fdcd91df702  sub rsp, 0x08
00007fdcd91df706  push rax
00007fdcd91df707  push rcx
00007fdcd91df708  push rdx
00007fdcd91df709  push rdi
00007fdcd91df70a  push rsi
00007fdcd91df70b  push r8
00007fdcd91df70d  push r9
00007fdcd91df70f  push r10
00007fdcd91df711  push r11
00007fdcd91df713  sub rsp, 0xF0
00007fdcd91df71a  vmovaps [rsp], xmm0
00007fdcd91df71f  vmovaps [rsp+0x10], xmm1
00007fdcd91df725  vmovaps [rsp+0x20], xmm2
00007fdcd91df72b  vmovaps [rsp+0x30], xmm3
00007fdcd91df731  vmovaps [rsp+0x40], xmm4
00007fdcd91df737  vmovaps [rsp+0x50], xmm5
00007fdcd91df73d  vmovaps [rsp+0x60], xmm6
00007fdcd91df743  vmovaps [rsp+0x70], xmm7
00007fdcd91df749  vmovaps [rsp+0x80], xmm8
00007fdcd91df752  vmovaps [rsp+0x90], xmm9
00007fdcd91df75b  vmovaps [rsp+0xA0], xmm10
00007fdcd91df764  vmovaps [rsp+0xB0], xmm11
00007fdcd91df76d  vmovaps [rsp+0xC0], xmm12
00007fdcd91df776  vmovaps [rsp+0xD0], xmm13
00007fdcd91df77f  vmovaps [rsp+0xE0], xmm15
00007fdcd91df788  sub rsp, 0x30
00007fdcd91df78c  movaps [rsp], xmm14
00007fdcd91df791  movaps [rsp+0x10], xmm8
00007fdcd91df797  movaps [rsp+0x20], xmm4
00007fdcd91df79c  lea rdi, [rsp]
00007fdcd91df7a0  mov esi, 0x00
00007fdcd91df7a5  mov rax, 0x5B56EFBF3530
00007fdcd91df7af  call rax
00007fdcd91df7b1  movaps xmm14, [rsp]
00007fdcd91df7b6  add rsp, 0x30
00007fdcd91df7ba  vmovaps xmm0, [rsp]
00007fdcd91df7bf  vmovaps xmm1, [rsp+0x10]
00007fdcd91df7c5  vmovaps xmm2, [rsp+0x20]
00007fdcd91df7cb  vmovaps xmm3, [rsp+0x30]
00007fdcd91df7d1  vmovaps xmm4, [rsp+0x40]
00007fdcd91df7d7  vmovaps xmm5, [rsp+0x50]
00007fdcd91df7dd  vmovaps xmm6, [rsp+0x60]
00007fdcd91df7e3  vmovaps xmm7, [rsp+0x70]
00007fdcd91df7e9  vmovaps xmm8, [rsp+0x80]
00007fdcd91df7f2  vmovaps xmm9, [rsp+0x90]
00007fdcd91df7fb  vmovaps xmm10, [rsp+0xA0]
00007fdcd91df804  vmovaps xmm11, [rsp+0xB0]
00007fdcd91df80d  vmovaps xmm12, [rsp+0xC0]
00007fdcd91df816  vmovaps xmm13, [rsp+0xD0]
00007fdcd91df81f  vmovaps xmm15, [rsp+0xE0]
00007fdcd91df828  add rsp, 0xF0
00007fdcd91df82f  pop r11
00007fdcd91df831  pop r10
00007fdcd91df833  pop r9
00007fdcd91df835  pop r8
00007fdcd91df837  pop rsi
00007fdcd91df838  pop rdi
00007fdcd91df839  pop rdx
00007fdcd91df83a  pop rcx
00007fdcd91df83b  pop rax
00007fdcd91df83c  add rsp, 0x08
00007fdcd91df840  jmp 0x00007FDCD91DC418
00007fdcd91df845  sub rsp, 0x08
00007fdcd91df849  push rax
00007fdcd91df84a  push rcx
00007fdcd91df84b  push rdx
00007fdcd91df84c  push rdi
00007fdcd91df84d  push rsi
00007fdcd91df84e  push r8
00007fdcd91df850  push r9
00007fdcd91df852  push r10
00007fdcd91df854  push r11
00007fdcd91df856  sub rsp, 0xF0
00007fdcd91df85d  vmovaps [rsp], xmm0
00007fdcd91df862  vmovaps [rsp+0x10], xmm1
00007fdcd91df868  vmovaps [rsp+0x20], xmm2
00007fdcd91df86e  vmovaps [rsp+0x30], xmm3
00007fdcd91df874  vmovaps [rsp+0x40], xmm5
00007fdcd91df87a  vmovaps [rsp+0x50], xmm6
00007fdcd91df880  vmovaps [rsp+0x60], xmm7
00007fdcd91df886  vmovaps [rsp+0x70], xmm8
00007fdcd91df88c  vmovaps [rsp+0x80], xmm9
00007fdcd91df895  vmovaps [rsp+0x90], xmm10
00007fdcd91df89e  vmovaps [rsp+0xA0], xmm11
00007fdcd91df8a7  vmovaps [rsp+0xB0], xmm12
00007fdcd91df8b0  vmovaps [rsp+0xC0], xmm13
00007fdcd91df8b9  vmovaps [rsp+0xD0], xmm14
00007fdcd91df8c2  vmovaps [rsp+0xE0], xmm15
00007fdcd91df8cb  sub rsp, 0x30
00007fdcd91df8cf  movaps [rsp], xmm4
00007fdcd91df8d3  movaps [rsp+0x10], xmm13
00007fdcd91df8d9  movaps [rsp+0x20], xmm8
00007fdcd91df8df  lea rdi, [rsp]
00007fdcd91df8e3  mov esi, 0x00
00007fdcd91df8e8  mov rax, 0x5B56EFBF3530
00007fdcd91df8f2  call rax
00007fdcd91df8f4  movaps xmm4, [rsp]
00007fdcd91df8f8  add rsp, 0x30
00007fdcd91df8fc  vmovaps xmm0, [rsp]
00007fdcd91df901  vmovaps xmm1, [rsp+0x10]
00007fdcd91df907  vmovaps xmm2, [rsp+0x20]
00007fdcd91df90d  vmovaps xmm3, [rsp+0x30]
00007fdcd91df913  vmovaps xmm5, [rsp+0x40]
00007fdcd91df919  vmovaps xmm6, [rsp+0x50]
00007fdcd91df91f  vmovaps xmm7, [rsp+0x60]
00007fdcd91df925  vmovaps xmm8, [rsp+0x70]
00007fdcd91df92b  vmovaps xmm9, [rsp+0x80]
00007fdcd91df934  vmovaps xmm10, [rsp+0x90]
00007fdcd91df93d  vmovaps xmm11, [rsp+0xA0]
00007fdcd91df946  vmovaps xmm12, [rsp+0xB0]
00007fdcd91df94f  vmovaps xmm13, [rsp+0xC0]
00007fdcd91df958  vmovaps xmm14, [rsp+0xD0]
00007fdcd91df961  vmovaps xmm15, [rsp+0xE0]
00007fdcd91df96a  add rsp, 0xF0
00007fdcd91df971  pop r11
00007fdcd91df973  pop r10
00007fdcd91df975  pop r9
00007fdcd91df977  pop r8
00007fdcd91df979  pop rsi
00007fdcd91df97a  pop rdi
00007fdcd91df97b  pop rdx
00007fdcd91df97c  pop rcx
00007fdcd91df97d  pop rax
00007fdcd91df97e  add rsp, 0x08
00007fdcd91df982  jmp 0x00007FDCD91DC43D
00007fdcd91df987  sub rsp, 0x08
00007fdcd91df98b  push rax
00007fdcd91df98c  push rcx
00007fdcd91df98d  push rdx
00007fdcd91df98e  push rdi
00007fdcd91df98f  push rsi
00007fdcd91df990  push r8
00007fdcd91df992  push r9
00007fdcd91df994  push r10
00007fdcd91df996  push r11
00007fdcd91df998  sub rsp, 0xF0
00007fdcd91df99f  vmovaps [rsp], xmm0
00007fdcd91df9a4  vmovaps [rsp+0x10], xmm1
00007fdcd91df9aa  vmovaps [rsp+0x20], xmm2
00007fdcd91df9b0  vmovaps [rsp+0x30], xmm3
00007fdcd91df9b6  vmovaps [rsp+0x40], xmm4
00007fdcd91df9bc  vmovaps [rsp+0x50], xmm5
00007fdcd91df9c2  vmovaps [rsp+0x60], xmm6
00007fdcd91df9c8  vmovaps [rsp+0x70], xmm7
00007fdcd91df9ce  vmovaps [rsp+0x80], xmm8
00007fdcd91df9d7  vmovaps [rsp+0x90], xmm9
00007fdcd91df9e0  vmovaps [rsp+0xA0], xmm10
00007fdcd91df9e9  vmovaps [rsp+0xB0], xmm11
00007fdcd91df9f2  vmovaps [rsp+0xC0], xmm12
00007fdcd91df9fb  vmovaps [rsp+0xD0], xmm14
00007fdcd91dfa04  vmovaps [rsp+0xE0], xmm15
00007fdcd91dfa0d  sub rsp, 0x30
00007fdcd91dfa11  movaps [rsp], xmm13
00007fdcd91dfa16  movaps [rsp+0x10], xmm15
00007fdcd91dfa1c  movaps [rsp+0x20], xmm9
00007fdcd91dfa22  lea rdi, [rsp]
00007fdcd91dfa26  mov esi, 0x00
00007fdcd91dfa2b  mov rax, 0x5B56EFBF3530
00007fdcd91dfa35  call rax
00007fdcd91dfa37  movaps xmm13, [rsp]
00007fdcd91dfa3c  add rsp, 0x30
00007fdcd91dfa40  vmovaps xmm0, [rsp]
00007fdcd91dfa45  vmovaps xmm1, [rsp+0x10]
00007fdcd91dfa4b  vmovaps xmm2, [rsp+0x20]
00007fdcd91dfa51  vmovaps xmm3, [rsp+0x30]
00007fdcd91dfa57  vmovaps xmm4, [rsp+0x40]
00007fdcd91dfa5d  vmovaps xmm5, [rsp+0x50]
00007fdcd91dfa63  vmovaps xmm6, [rsp+0x60]
00007fdcd91dfa69  vmovaps xmm7, [rsp+0x70]
00007fdcd91dfa6f  vmovaps xmm8, [rsp+0x80]
00007fdcd91dfa78  vmovaps xmm9, [rsp+0x90]
00007fdcd91dfa81  vmovaps xmm10, [rsp+0xA0]
00007fdcd91dfa8a  vmovaps xmm11, [rsp+0xB0]
00007fdcd91dfa93  vmovaps xmm12, [rsp+0xC0]
00007fdcd91dfa9c  vmovaps xmm14, [rsp+0xD0]
00007fdcd91dfaa5  vmovaps xmm15, [rsp+0xE0]
00007fdcd91dfaae  add rsp, 0xF0
00007fdcd91dfab5  pop r11
00007fdcd91dfab7  pop r10
00007fdcd91dfab9  pop r9
00007fdcd91dfabb  pop r8
00007fdcd91dfabd  pop rsi
00007fdcd91dfabe  pop rdi
00007fdcd91dfabf  pop rdx
00007fdcd91dfac0  pop rcx
00007fdcd91dfac1  pop rax
00007fdcd91dfac2  add rsp, 0x08
00007fdcd91dfac6  jmp 0x00007FDCD91DC458
00007fdcd91dfacb  sub rsp, 0x08
00007fdcd91dfacf  push rax
00007fdcd91dfad0  push rcx
00007fdcd91dfad1  push rdx
00007fdcd91dfad2  push rdi
00007fdcd91dfad3  push rsi
00007fdcd91dfad4  push r8
00007fdcd91dfad6  push r9
00007fdcd91dfad8  push r10
00007fdcd91dfada  push r11
00007fdcd91dfadc  sub rsp, 0xF0
00007fdcd91dfae3  vmovaps [rsp], xmm0
00007fdcd91dfae8  vmovaps [rsp+0x10], xmm1
00007fdcd91dfaee  vmovaps [rsp+0x20], xmm2
00007fdcd91dfaf4  vmovaps [rsp+0x30], xmm3
00007fdcd91dfafa  vmovaps [rsp+0x40], xmm4
00007fdcd91dfb00  vmovaps [rsp+0x50], xmm5
00007fdcd91dfb06  vmovaps [rsp+0x60], xmm6
00007fdcd91dfb0c  vmovaps [rsp+0x70], xmm7
00007fdcd91dfb12  vmovaps [rsp+0x80], xmm8
00007fdcd91dfb1b  vmovaps [rsp+0x90], xmm9
00007fdcd91dfb24  vmovaps [rsp+0xA0], xmm10
00007fdcd91dfb2d  vmovaps [rsp+0xB0], xmm11
00007fdcd91dfb36  vmovaps [rsp+0xC0], xmm12
00007fdcd91dfb3f  vmovaps [rsp+0xD0], xmm13
00007fdcd91dfb48  vmovaps [rsp+0xE0], xmm14
00007fdcd91dfb51  sub rsp, 0x30
00007fdcd91dfb55  movaps [rsp], xmm15
00007fdcd91dfb5a  movaps [rsp+0x10], xmm1
00007fdcd91dfb5f  movaps [rsp+0x20], xmm5
00007fdcd91dfb64  lea rdi, [rsp]
00007fdcd91dfb68  mov esi, 0x00
00007fdcd91dfb6d  mov rax, 0x5B56EFBF3530
00007fdcd91dfb77  call rax
00007fdcd91dfb79  movaps xmm15, [rsp]
00007fdcd91dfb7e  add rsp, 0x30
00007fdcd91dfb82  vmovaps xmm0, [rsp]
00007fdcd91dfb87  vmovaps xmm1, [rsp+0x10]
00007fdcd91dfb8d  vmovaps xmm2, [rsp+0x20]
00007fdcd91dfb93  vmovaps xmm3, [rsp+0x30]
00007fdcd91dfb99  vmovaps xmm4, [rsp+0x40]
00007fdcd91dfb9f  vmovaps xmm5, [rsp+0x50]
00007fdcd91dfba5  vmovaps xmm6, [rsp+0x60]
00007fdcd91dfbab  vmovaps xmm7, [rsp+0x70]
00007fdcd91dfbb1  vmovaps xmm8, [rsp+0x80]
00007fdcd91dfbba  vmovaps xmm9, [rsp+0x90]
00007fdcd91dfbc3  vmovaps xmm10, [rsp+0xA0]
00007fdcd91dfbcc  vmovaps xmm11, [rsp+0xB0]
00007fdcd91dfbd5  vmovaps xmm12, [rsp+0xC0]
00007fdcd91dfbde  vmovaps xmm13, [rsp+0xD0]
00007fdcd91dfbe7  vmovaps xmm14, [rsp+0xE0]
00007fdcd91dfbf0  add rsp, 0xF0
00007fdcd91dfbf7  pop r11
00007fdcd91dfbf9  pop r10
00007fdcd91dfbfb  pop r9
00007fdcd91dfbfd  pop r8
00007fdcd91dfbff  pop rsi
00007fdcd91dfc00  pop rdi
00007fdcd91dfc01  pop rdx
00007fdcd91dfc02  pop rcx
00007fdcd91dfc03  pop rax
00007fdcd91dfc04  add rsp, 0x08
00007fdcd91dfc08  jmp 0x00007FDCD91DC473
00007fdcd91dfc0d  call 0x00007FDCD90B52F0
00007fdcd91dfc12  jmp 0x00007FDCD91DC4CE
00007fdcd91dfc17  sub rsp, 0x08
00007fdcd91dfc1b  push rax
00007fdcd91dfc1c  push rcx
00007fdcd91dfc1d  push rdx
00007fdcd91dfc1e  push rdi
00007fdcd91dfc1f  push rsi
00007fdcd91dfc20  push r8
00007fdcd91dfc22  push r9
00007fdcd91dfc24  push r10
00007fdcd91dfc26  push r11
00007fdcd91dfc28  sub rsp, 0xF0
00007fdcd91dfc2f  vmovaps [rsp], xmm0
00007fdcd91dfc34  vmovaps [rsp+0x10], xmm1
00007fdcd91dfc3a  vmovaps [rsp+0x20], xmm2
00007fdcd91dfc40  vmovaps [rsp+0x30], xmm3
00007fdcd91dfc46  vmovaps [rsp+0x40], xmm4
00007fdcd91dfc4c  vmovaps [rsp+0x50], xmm5
00007fdcd91dfc52  vmovaps [rsp+0x60], xmm6
00007fdcd91dfc58  vmovaps [rsp+0x70], xmm7
00007fdcd91dfc5e  vmovaps [rsp+0x80], xmm8
00007fdcd91dfc67  vmovaps [rsp+0x90], xmm10
00007fdcd91dfc70  vmovaps [rsp+0xA0], xmm11
00007fdcd91dfc79  vmovaps [rsp+0xB0], xmm12
00007fdcd91dfc82  vmovaps [rsp+0xC0], xmm13
00007fdcd91dfc8b  vmovaps [rsp+0xD0], xmm14
00007fdcd91dfc94  vmovaps [rsp+0xE0], xmm15
00007fdcd91dfc9d  sub rsp, 0x30
00007fdcd91dfca1  movaps [rsp], xmm9
00007fdcd91dfca6  movaps [rsp+0x10], xmm8
00007fdcd91dfcac  movaps [rsp+0x20], xmm11
00007fdcd91dfcb2  lea rdi, [rsp]
00007fdcd91dfcb6  mov esi, 0x00
00007fdcd91dfcbb  mov rax, 0x5B56EFBF3530
00007fdcd91dfcc5  call rax
00007fdcd91dfcc7  movaps xmm9, [rsp]
00007fdcd91dfccc  add rsp, 0x30
00007fdcd91dfcd0  vmovaps xmm0, [rsp]
00007fdcd91dfcd5  vmovaps xmm1, [rsp+0x10]
00007fdcd91dfcdb  vmovaps xmm2, [rsp+0x20]
00007fdcd91dfce1  vmovaps xmm3, [rsp+0x30]
00007fdcd91dfce7  vmovaps xmm4, [rsp+0x40]
00007fdcd91dfced  vmovaps xmm5, [rsp+0x50]
00007fdcd91dfcf3  vmovaps xmm6, [rsp+0x60]
00007fdcd91dfcf9  vmovaps xmm7, [rsp+0x70]
00007fdcd91dfcff  vmovaps xmm8, [rsp+0x80]
00007fdcd91dfd08  vmovaps xmm10, [rsp+0x90]
00007fdcd91dfd11  vmovaps xmm11, [rsp+0xA0]
00007fdcd91dfd1a  vmovaps xmm12, [rsp+0xB0]
00007fdcd91dfd23  vmovaps xmm13, [rsp+0xC0]
00007fdcd91dfd2c  vmovaps xmm14, [rsp+0xD0]
00007fdcd91dfd35  vmovaps xmm15, [rsp+0xE0]
00007fdcd91dfd3e  add rsp, 0xF0
00007fdcd91dfd45  pop r11
00007fdcd91dfd47  pop r10
00007fdcd91dfd49  pop r9
00007fdcd91dfd4b  pop r8
00007fdcd91dfd4d  pop rsi
00007fdcd91dfd4e  pop rdi
00007fdcd91dfd4f  pop rdx
00007fdcd91dfd50  pop rcx
00007fdcd91dfd51  pop rax
00007fdcd91dfd52  add rsp, 0x08
00007fdcd91dfd56  jmp 0x00007FDCD91DC505
00007fdcd91dfd5b  sub rsp, 0x08
00007fdcd91dfd5f  push rax
00007fdcd91dfd60  push rcx
00007fdcd91dfd61  push rdx
00007fdcd91dfd62  push rdi
00007fdcd91dfd63  push rsi
00007fdcd91dfd64  push r8
00007fdcd91dfd66  push r9
00007fdcd91dfd68  push r10
00007fdcd91dfd6a  push r11
00007fdcd91dfd6c  sub rsp, 0xF0
00007fdcd91dfd73  vmovaps [rsp], xmm0
00007fdcd91dfd78  vmovaps [rsp+0x10], xmm1
00007fdcd91dfd7e  vmovaps [rsp+0x20], xmm2
00007fdcd91dfd84  vmovaps [rsp+0x30], xmm3
00007fdcd91dfd8a  vmovaps [rsp+0x40], xmm4
00007fdcd91dfd90  vmovaps [rsp+0x50], xmm5
00007fdcd91dfd96  vmovaps [rsp+0x60], xmm6
00007fdcd91dfd9c  vmovaps [rsp+0x70], xmm7
00007fdcd91dfda2  vmovaps [rsp+0x80], xmm8
00007fdcd91dfdab  vmovaps [rsp+0x90], xmm9
00007fdcd91dfdb4  vmovaps [rsp+0xA0], xmm10
00007fdcd91dfdbd  vmovaps [rsp+0xB0], xmm12
00007fdcd91dfdc6  vmovaps [rsp+0xC0], xmm13
00007fdcd91dfdcf  vmovaps [rsp+0xD0], xmm14
00007fdcd91dfdd8  vmovaps [rsp+0xE0], xmm15
00007fdcd91dfde1  sub rsp, 0x30
00007fdcd91dfde5  movaps [rsp], xmm11
00007fdcd91dfdea  movaps [rsp+0x10], xmm10
00007fdcd91dfdf0  movaps [rsp+0x20], xmm6
00007fdcd91dfdf5  lea rdi, [rsp]
00007fdcd91dfdf9  mov esi, 0x00
00007fdcd91dfdfe  mov rax, 0x5B56EFBF3530
00007fdcd91dfe08  call rax
00007fdcd91dfe0a  movaps xmm11, [rsp]
00007fdcd91dfe0f  add rsp, 0x30
00007fdcd91dfe13  vmovaps xmm0, [rsp]
00007fdcd91dfe18  vmovaps xmm1, [rsp+0x10]
00007fdcd91dfe1e  vmovaps xmm2, [rsp+0x20]
00007fdcd91dfe24  vmovaps xmm3, [rsp+0x30]
00007fdcd91dfe2a  vmovaps xmm4, [rsp+0x40]
00007fdcd91dfe30  vmovaps xmm5, [rsp+0x50]
00007fdcd91dfe36  vmovaps xmm6, [rsp+0x60]
00007fdcd91dfe3c  vmovaps xmm7, [rsp+0x70]
00007fdcd91dfe42  vmovaps xmm8, [rsp+0x80]
00007fdcd91dfe4b  vmovaps xmm9, [rsp+0x90]
00007fdcd91dfe54  vmovaps xmm10, [rsp+0xA0]
00007fdcd91dfe5d  vmovaps xmm12, [rsp+0xB0]
00007fdcd91dfe66  vmovaps xmm13, [rsp+0xC0]
00007fdcd91dfe6f  vmovaps xmm14, [rsp+0xD0]
00007fdcd91dfe78  vmovaps xmm15, [rsp+0xE0]
00007fdcd91dfe81  add rsp, 0xF0
00007fdcd91dfe88  pop r11
00007fdcd91dfe8a  pop r10
00007fdcd91dfe8c  pop r9
00007fdcd91dfe8e  pop r8
00007fdcd91dfe90  pop rsi
00007fdcd91dfe91  pop rdi
00007fdcd91dfe92  pop rdx
00007fdcd91dfe93  pop rcx
00007fdcd91dfe94  pop rax
00007fdcd91dfe95  add rsp, 0x08
00007fdcd91dfe99  jmp 0x00007FDCD91DC520
00007fdcd91dfe9e  sub rsp, 0x08
00007fdcd91dfea2  push rax
00007fdcd91dfea3  push rcx
00007fdcd91dfea4  push rdx
00007fdcd91dfea5  push rdi
00007fdcd91dfea6  push rsi
00007fdcd91dfea7  push r8
00007fdcd91dfea9  push r9
00007fdcd91dfeab  push r10
00007fdcd91dfead  push r11
00007fdcd91dfeaf  sub rsp, 0xF0
00007fdcd91dfeb6  vmovaps [rsp], xmm0
00007fdcd91dfebb  vmovaps [rsp+0x10], xmm1
00007fdcd91dfec1  vmovaps [rsp+0x20], xmm2
00007fdcd91dfec7  vmovaps [rsp+0x30], xmm3
00007fdcd91dfecd  vmovaps [rsp+0x40], xmm4
00007fdcd91dfed3  vmovaps [rsp+0x50], xmm5
00007fdcd91dfed9  vmovaps [rsp+0x60], xmm6
00007fdcd91dfedf  vmovaps [rsp+0x70], xmm7
00007fdcd91dfee5  vmovaps [rsp+0x80], xmm8
00007fdcd91dfeee  vmovaps [rsp+0x90], xmm9
00007fdcd91dfef7  vmovaps [rsp+0xA0], xmm11
00007fdcd91dff00  vmovaps [rsp+0xB0], xmm12
00007fdcd91dff09  vmovaps [rsp+0xC0], xmm13
00007fdcd91dff12  vmovaps [rsp+0xD0], xmm14
00007fdcd91dff1b  vmovaps [rsp+0xE0], xmm15
00007fdcd91dff24  sub rsp, 0x30
00007fdcd91dff28  movaps [rsp], xmm10
00007fdcd91dff2d  movaps [rsp+0x10], xmm14
00007fdcd91dff33  movaps [rsp+0x20], xmm4
00007fdcd91dff38  lea rdi, [rsp]
00007fdcd91dff3c  mov esi, 0x00
00007fdcd91dff41  mov rax, 0x5B56EFBF3530
00007fdcd91dff4b  call rax
00007fdcd91dff4d  movaps xmm10, [rsp]
00007fdcd91dff52  add rsp, 0x30
00007fdcd91dff56  vmovaps xmm0, [rsp]
00007fdcd91dff5b  vmovaps xmm1, [rsp+0x10]
00007fdcd91dff61  vmovaps xmm2, [rsp+0x20]
00007fdcd91dff67  vmovaps xmm3, [rsp+0x30]
00007fdcd91dff6d  vmovaps xmm4, [rsp+0x40]
00007fdcd91dff73  vmovaps xmm5, [rsp+0x50]
00007fdcd91dff79  vmovaps xmm6, [rsp+0x60]
00007fdcd91dff7f  vmovaps xmm7, [rsp+0x70]
00007fdcd91dff85  vmovaps xmm8, [rsp+0x80]
00007fdcd91dff8e  vmovaps xmm9, [rsp+0x90]
00007fdcd91dff97  vmovaps xmm11, [rsp+0xA0]
00007fdcd91dffa0  vmovaps xmm12, [rsp+0xB0]
00007fdcd91dffa9  vmovaps xmm13, [rsp+0xC0]
00007fdcd91dffb2  vmovaps xmm14, [rsp+0xD0]
00007fdcd91dffbb  vmovaps xmm15, [rsp+0xE0]
00007fdcd91dffc4  add rsp, 0xF0
00007fdcd91dffcb  pop r11
00007fdcd91dffcd  pop r10
00007fdcd91dffcf  pop r9
00007fdcd91dffd1  pop r8
00007fdcd91dffd3  pop rsi
00007fdcd91dffd4  pop rdi
00007fdcd91dffd5  pop rdx
00007fdcd91dffd6  pop rcx
00007fdcd91dffd7  pop rax
00007fdcd91dffd8  add rsp, 0x08
00007fdcd91dffdc  jmp 0x00007FDCD91DC53B
00007fdcd91dffe1  sub rsp, 0x08
00007fdcd91dffe5  push rax
00007fdcd91dffe6  push rcx
00007fdcd91dffe7  push rdx
00007fdcd91dffe8  push rdi
00007fdcd91dffe9  push rsi
00007fdcd91dffea  push r8
00007fdcd91dffec  push r9
00007fdcd91dffee  push r10
00007fdcd91dfff0  push r11
00007fdcd91dfff2  sub rsp, 0xF0
00007fdcd91dfff9  vmovaps [rsp], xmm0
00007fdcd91dfffe  vmovaps [rsp+0x10], xmm1
00007fdcd91e0004  vmovaps [rsp+0x20], xmm2
00007fdcd91e000a  vmovaps [rsp+0x30], xmm3
00007fdcd91e0010  vmovaps [rsp+0x40], xmm4
00007fdcd91e0016  vmovaps [rsp+0x50], xmm5
00007fdcd91e001c  vmovaps [rsp+0x60], xmm6
00007fdcd91e0022  vmovaps [rsp+0x70], xmm7
00007fdcd91e0028  vmovaps [rsp+0x80], xmm9
00007fdcd91e0031  vmovaps [rsp+0x90], xmm10
00007fdcd91e003a  vmovaps [rsp+0xA0], xmm11
00007fdcd91e0043  vmovaps [rsp+0xB0], xmm12
00007fdcd91e004c  vmovaps [rsp+0xC0], xmm13
00007fdcd91e0055  vmovaps [rsp+0xD0], xmm14
00007fdcd91e005e  vmovaps [rsp+0xE0], xmm15
00007fdcd91e0067  sub rsp, 0x30
00007fdcd91e006b  movaps [rsp], xmm8
00007fdcd91e0070  movaps [rsp+0x10], xmm1
00007fdcd91e0075  movaps [rsp+0x20], xmm14
00007fdcd91e007b  lea rdi, [rsp]
00007fdcd91e007f  mov esi, 0x00
00007fdcd91e0084  mov rax, 0x5B56EFBF3530
00007fdcd91e008e  call rax
00007fdcd91e0090  movaps xmm8, [rsp]
00007fdcd91e0095  add rsp, 0x30
00007fdcd91e0099  vmovaps xmm0, [rsp]
00007fdcd91e009e  vmovaps xmm1, [rsp+0x10]
00007fdcd91e00a4  vmovaps xmm2, [rsp+0x20]
00007fdcd91e00aa  vmovaps xmm3, [rsp+0x30]
00007fdcd91e00b0  vmovaps xmm4, [rsp+0x40]
00007fdcd91e00b6  vmovaps xmm5, [rsp+0x50]
00007fdcd91e00bc  vmovaps xmm6, [rsp+0x60]
00007fdcd91e00c2  vmovaps xmm7, [rsp+0x70]
00007fdcd91e00c8  vmovaps xmm9, [rsp+0x80]
00007fdcd91e00d1  vmovaps xmm10, [rsp+0x90]
00007fdcd91e00da  vmovaps xmm11, [rsp+0xA0]
00007fdcd91e00e3  vmovaps xmm12, [rsp+0xB0]
00007fdcd91e00ec  vmovaps xmm13, [rsp+0xC0]
00007fdcd91e00f5  vmovaps xmm14, [rsp+0xD0]
00007fdcd91e00fe  vmovaps xmm15, [rsp+0xE0]
00007fdcd91e0107  add rsp, 0xF0
00007fdcd91e010e  pop r11
00007fdcd91e0110  pop r10
00007fdcd91e0112  pop r9
00007fdcd91e0114  pop r8
00007fdcd91e0116  pop rsi
00007fdcd91e0117  pop rdi
00007fdcd91e0118  pop rdx
00007fdcd91e0119  pop rcx
00007fdcd91e011a  pop rax
00007fdcd91e011b  add rsp, 0x08
00007fdcd91e011f  jmp 0x00007FDCD91DC561
00007fdcd91e0124  sub rsp, 0x08
00007fdcd91e0128  push rax
00007fdcd91e0129  push rcx
00007fdcd91e012a  push rdx
00007fdcd91e012b  push rdi
00007fdcd91e012c  push rsi
00007fdcd91e012d  push r8
00007fdcd91e012f  push r9
00007fdcd91e0131  push r10
00007fdcd91e0133  push r11
00007fdcd91e0135  sub rsp, 0xF0
00007fdcd91e013c  vmovaps [rsp], xmm0
00007fdcd91e0141  vmovaps [rsp+0x10], xmm1
00007fdcd91e0147  vmovaps [rsp+0x20], xmm2
00007fdcd91e014d  vmovaps [rsp+0x30], xmm3
00007fdcd91e0153  vmovaps [rsp+0x40], xmm4
00007fdcd91e0159  vmovaps [rsp+0x50], xmm5
00007fdcd91e015f  vmovaps [rsp+0x60], xmm7
00007fdcd91e0165  vmovaps [rsp+0x70], xmm8
00007fdcd91e016b  vmovaps [rsp+0x80], xmm9
00007fdcd91e0174  vmovaps [rsp+0x90], xmm10
00007fdcd91e017d  vmovaps [rsp+0xA0], xmm11
00007fdcd91e0186  vmovaps [rsp+0xB0], xmm12
00007fdcd91e018f  vmovaps [rsp+0xC0], xmm13
00007fdcd91e0198  vmovaps [rsp+0xD0], xmm14
00007fdcd91e01a1  vmovaps [rsp+0xE0], xmm15
00007fdcd91e01aa  sub rsp, 0x30
00007fdcd91e01ae  movaps [rsp], xmm6
00007fdcd91e01b2  movaps [rsp+0x10], xmm1
00007fdcd91e01b7  movaps [rsp+0x20], xmm14
00007fdcd91e01bd  lea rdi, [rsp]
00007fdcd91e01c1  mov esi, 0x00
00007fdcd91e01c6  mov rax, 0x5B56EFBF3530
00007fdcd91e01d0  call rax
00007fdcd91e01d2  movaps xmm6, [rsp]
00007fdcd91e01d6  add rsp, 0x30
00007fdcd91e01da  vmovaps xmm0, [rsp]
00007fdcd91e01df  vmovaps xmm1, [rsp+0x10]
00007fdcd91e01e5  vmovaps xmm2, [rsp+0x20]
00007fdcd91e01eb  vmovaps xmm3, [rsp+0x30]
00007fdcd91e01f1  vmovaps xmm4, [rsp+0x40]
00007fdcd91e01f7  vmovaps xmm5, [rsp+0x50]
00007fdcd91e01fd  vmovaps xmm7, [rsp+0x60]
00007fdcd91e0203  vmovaps xmm8, [rsp+0x70]
00007fdcd91e0209  vmovaps xmm9, [rsp+0x80]
00007fdcd91e0212  vmovaps xmm10, [rsp+0x90]
00007fdcd91e021b  vmovaps xmm11, [rsp+0xA0]
00007fdcd91e0224  vmovaps xmm12, [rsp+0xB0]
00007fdcd91e022d  vmovaps xmm13, [rsp+0xC0]
00007fdcd91e0236  vmovaps xmm14, [rsp+0xD0]
00007fdcd91e023f  vmovaps xmm15, [rsp+0xE0]
00007fdcd91e0248  add rsp, 0xF0
00007fdcd91e024f  pop r11
00007fdcd91e0251  pop r10
00007fdcd91e0253  pop r9
00007fdcd91e0255  pop r8
00007fdcd91e0257  pop rsi
00007fdcd91e0258  pop rdi
00007fdcd91e0259  pop rdx
00007fdcd91e025a  pop rcx
00007fdcd91e025b  pop rax
00007fdcd91e025c  add rsp, 0x08
00007fdcd91e0260  jmp 0x00007FDCD91DC58D
00007fdcd91e0265  sub rsp, 0x08
00007fdcd91e0269  push rax
00007fdcd91e026a  push rcx
00007fdcd91e026b  push rdx
00007fdcd91e026c  push rdi
00007fdcd91e026d  push rsi
00007fdcd91e026e  push r8
00007fdcd91e0270  push r9
00007fdcd91e0272  push r10
00007fdcd91e0274  push r11
00007fdcd91e0276  sub rsp, 0xF0
00007fdcd91e027d  vmovaps [rsp], xmm0
00007fdcd91e0282  vmovaps [rsp+0x10], xmm1
00007fdcd91e0288  vmovaps [rsp+0x20], xmm2
00007fdcd91e028e  vmovaps [rsp+0x30], xmm3
00007fdcd91e0294  vmovaps [rsp+0x40], xmm4
00007fdcd91e029a  vmovaps [rsp+0x50], xmm5
00007fdcd91e02a0  vmovaps [rsp+0x60], xmm6
00007fdcd91e02a6  vmovaps [rsp+0x70], xmm7
00007fdcd91e02ac  vmovaps [rsp+0x80], xmm8
00007fdcd91e02b5  vmovaps [rsp+0x90], xmm9
00007fdcd91e02be  vmovaps [rsp+0xA0], xmm10
00007fdcd91e02c7  vmovaps [rsp+0xB0], xmm11
00007fdcd91e02d0  vmovaps [rsp+0xC0], xmm12
00007fdcd91e02d9  vmovaps [rsp+0xD0], xmm13
00007fdcd91e02e2  vmovaps [rsp+0xE0], xmm15
00007fdcd91e02eb  sub rsp, 0x30
00007fdcd91e02ef  movaps [rsp], xmm14
00007fdcd91e02f4  movaps [rsp+0x10], xmm12
00007fdcd91e02fa  movaps [rsp+0x20], xmm1
00007fdcd91e02ff  lea rdi, [rsp]
00007fdcd91e0303  mov esi, 0x00
00007fdcd91e0308  mov rax, 0x5B56EFBF3530
00007fdcd91e0312  call rax
00007fdcd91e0314  movaps xmm14, [rsp]
00007fdcd91e0319  add rsp, 0x30
00007fdcd91e031d  vmovaps xmm0, [rsp]
00007fdcd91e0322  vmovaps xmm1, [rsp+0x10]
00007fdcd91e0328  vmovaps xmm2, [rsp+0x20]
00007fdcd91e032e  vmovaps xmm3, [rsp+0x30]
00007fdcd91e0334  vmovaps xmm4, [rsp+0x40]
00007fdcd91e033a  vmovaps xmm5, [rsp+0x50]
00007fdcd91e0340  vmovaps xmm6, [rsp+0x60]
00007fdcd91e0346  vmovaps xmm7, [rsp+0x70]
00007fdcd91e034c  vmovaps xmm8, [rsp+0x80]
00007fdcd91e0355  vmovaps xmm9, [rsp+0x90]
00007fdcd91e035e  vmovaps xmm10, [rsp+0xA0]
00007fdcd91e0367  vmovaps xmm11, [rsp+0xB0]
00007fdcd91e0370  vmovaps xmm12, [rsp+0xC0]
00007fdcd91e0379  vmovaps xmm13, [rsp+0xD0]
00007fdcd91e0382  vmovaps xmm15, [rsp+0xE0]
00007fdcd91e038b  add rsp, 0xF0
00007fdcd91e0392  pop r11
00007fdcd91e0394  pop r10
00007fdcd91e0396  pop r9
00007fdcd91e0398  pop r8
00007fdcd91e039a  pop rsi
00007fdcd91e039b  pop rdi
00007fdcd91e039c  pop rdx
00007fdcd91e039d  pop rcx
00007fdcd91e039e  pop rax
00007fdcd91e039f  add rsp, 0x08
00007fdcd91e03a3  jmp 0x00007FDCD91DC5B3
00007fdcd91e03a8  sub rsp, 0x08
00007fdcd91e03ac  push rax
00007fdcd91e03ad  push rcx
00007fdcd91e03ae  push rdx
00007fdcd91e03af  push rdi
00007fdcd91e03b0  push rsi
00007fdcd91e03b1  push r8
00007fdcd91e03b3  push r9
00007fdcd91e03b5  push r10
00007fdcd91e03b7  push r11
00007fdcd91e03b9  sub rsp, 0xF0
00007fdcd91e03c0  vmovaps [rsp], xmm0
00007fdcd91e03c5  vmovaps [rsp+0x10], xmm2
00007fdcd91e03cb  vmovaps [rsp+0x20], xmm3
00007fdcd91e03d1  vmovaps [rsp+0x30], xmm4
00007fdcd91e03d7  vmovaps [rsp+0x40], xmm5
00007fdcd91e03dd  vmovaps [rsp+0x50], xmm6
00007fdcd91e03e3  vmovaps [rsp+0x60], xmm7
00007fdcd91e03e9  vmovaps [rsp+0x70], xmm8
00007fdcd91e03ef  vmovaps [rsp+0x80], xmm9
00007fdcd91e03f8  vmovaps [rsp+0x90], xmm10
00007fdcd91e0401  vmovaps [rsp+0xA0], xmm11
00007fdcd91e040a  vmovaps [rsp+0xB0], xmm12
00007fdcd91e0413  vmovaps [rsp+0xC0], xmm13
00007fdcd91e041c  vmovaps [rsp+0xD0], xmm14
00007fdcd91e0425  vmovaps [rsp+0xE0], xmm15
00007fdcd91e042e  sub rsp, 0x30
00007fdcd91e0432  movaps [rsp], xmm1
00007fdcd91e0436  movaps [rsp+0x10], xmm13
00007fdcd91e043c  movaps [rsp+0x20], xmm9
00007fdcd91e0442  lea rdi, [rsp]
00007fdcd91e0446  mov esi, 0x00
00007fdcd91e044b  mov rax, 0x5B56EFBF3530
00007fdcd91e0455  call rax
00007fdcd91e0457  movaps xmm1, [rsp]
00007fdcd91e045b  add rsp, 0x30
00007fdcd91e045f  vmovaps xmm0, [rsp]
00007fdcd91e0464  vmovaps xmm2, [rsp+0x10]
00007fdcd91e046a  vmovaps xmm3, [rsp+0x20]
00007fdcd91e0470  vmovaps xmm4, [rsp+0x30]
00007fdcd91e0476  vmovaps xmm5, [rsp+0x40]
00007fdcd91e047c  vmovaps xmm6, [rsp+0x50]
00007fdcd91e0482  vmovaps xmm7, [rsp+0x60]
00007fdcd91e0488  vmovaps xmm8, [rsp+0x70]
00007fdcd91e048e  vmovaps xmm9, [rsp+0x80]
00007fdcd91e0497  vmovaps xmm10, [rsp+0x90]
00007fdcd91e04a0  vmovaps xmm11, [rsp+0xA0]
00007fdcd91e04a9  vmovaps xmm12, [rsp+0xB0]
00007fdcd91e04b2  vmovaps xmm13, [rsp+0xC0]
00007fdcd91e04bb  vmovaps xmm14, [rsp+0xD0]
00007fdcd91e04c4  vmovaps xmm15, [rsp+0xE0]
00007fdcd91e04cd  add rsp, 0xF0
00007fdcd91e04d4  pop r11
00007fdcd91e04d6  pop r10
00007fdcd91e04d8  pop r9
00007fdcd91e04da  pop r8
00007fdcd91e04dc  pop rsi
00007fdcd91e04dd  pop rdi
00007fdcd91e04de  pop rdx
00007fdcd91e04df  pop rcx
00007fdcd91e04e0  pop rax
00007fdcd91e04e1  add rsp, 0x08
00007fdcd91e04e5  jmp 0x00007FDCD91DC5CD
00007fdcd91e04ea  sub rsp, 0x08
00007fdcd91e04ee  push rax
00007fdcd91e04ef  push rcx
00007fdcd91e04f0  push rdx
00007fdcd91e04f1  push rdi
00007fdcd91e04f2  push rsi
00007fdcd91e04f3  push r8
00007fdcd91e04f5  push r9
00007fdcd91e04f7  push r10
00007fdcd91e04f9  push r11
00007fdcd91e04fb  sub rsp, 0xF0
00007fdcd91e0502  vmovaps [rsp], xmm0
00007fdcd91e0507  vmovaps [rsp+0x10], xmm1
00007fdcd91e050d  vmovaps [rsp+0x20], xmm2
00007fdcd91e0513  vmovaps [rsp+0x30], xmm3
00007fdcd91e0519  vmovaps [rsp+0x40], xmm4
00007fdcd91e051f  vmovaps [rsp+0x50], xmm5
00007fdcd91e0525  vmovaps [rsp+0x60], xmm6
00007fdcd91e052b  vmovaps [rsp+0x70], xmm7
00007fdcd91e0531  vmovaps [rsp+0x80], xmm8
00007fdcd91e053a  vmovaps [rsp+0x90], xmm9
00007fdcd91e0543  vmovaps [rsp+0xA0], xmm10
00007fdcd91e054c  vmovaps [rsp+0xB0], xmm11
00007fdcd91e0555  vmovaps [rsp+0xC0], xmm13
00007fdcd91e055e  vmovaps [rsp+0xD0], xmm14
00007fdcd91e0567  vmovaps [rsp+0xE0], xmm15
00007fdcd91e0570  sub rsp, 0x30
00007fdcd91e0574  movaps [rsp], xmm12
00007fdcd91e0579  movaps [rsp+0x10], xmm7
00007fdcd91e057e  movaps [rsp+0x20], xmm13
00007fdcd91e0584  lea rdi, [rsp]
00007fdcd91e0588  mov esi, 0x00
00007fdcd91e058d  mov rax, 0x5B56EFBF3530
00007fdcd91e0597  call rax
00007fdcd91e0599  movaps xmm12, [rsp]
00007fdcd91e059e  add rsp, 0x30
00007fdcd91e05a2  vmovaps xmm0, [rsp]
00007fdcd91e05a7  vmovaps xmm1, [rsp+0x10]
00007fdcd91e05ad  vmovaps xmm2, [rsp+0x20]
00007fdcd91e05b3  vmovaps xmm3, [rsp+0x30]
00007fdcd91e05b9  vmovaps xmm4, [rsp+0x40]
00007fdcd91e05bf  vmovaps xmm5, [rsp+0x50]
00007fdcd91e05c5  vmovaps xmm6, [rsp+0x60]
00007fdcd91e05cb  vmovaps xmm7, [rsp+0x70]
00007fdcd91e05d1  vmovaps xmm8, [rsp+0x80]
00007fdcd91e05da  vmovaps xmm9, [rsp+0x90]
00007fdcd91e05e3  vmovaps xmm10, [rsp+0xA0]
00007fdcd91e05ec  vmovaps xmm11, [rsp+0xB0]
00007fdcd91e05f5  vmovaps xmm13, [rsp+0xC0]
00007fdcd91e05fe  vmovaps xmm14, [rsp+0xD0]
00007fdcd91e0607  vmovaps xmm15, [rsp+0xE0]
00007fdcd91e0610  add rsp, 0xF0
00007fdcd91e0617  pop r11
00007fdcd91e0619  pop r10
00007fdcd91e061b  pop r9
00007fdcd91e061d  pop r8
00007fdcd91e061f  pop rsi
00007fdcd91e0620  pop rdi
00007fdcd91e0621  pop rdx
00007fdcd91e0622  pop rcx
00007fdcd91e0623  pop rax
00007fdcd91e0624  add rsp, 0x08
00007fdcd91e0628  jmp 0x00007FDCD91DC5F4
00007fdcd91e062d  sub rsp, 0x08
00007fdcd91e0631  push rax
00007fdcd91e0632  push rcx
00007fdcd91e0633  push rdx
00007fdcd91e0634  push rdi
00007fdcd91e0635  push rsi
00007fdcd91e0636  push r8
00007fdcd91e0638  push r9
00007fdcd91e063a  push r10
00007fdcd91e063c  push r11
00007fdcd91e063e  sub rsp, 0xF0
00007fdcd91e0645  vmovaps [rsp], xmm0
00007fdcd91e064a  vmovaps [rsp+0x10], xmm1
00007fdcd91e0650  vmovaps [rsp+0x20], xmm2
00007fdcd91e0656  vmovaps [rsp+0x30], xmm3
00007fdcd91e065c  vmovaps [rsp+0x40], xmm4
00007fdcd91e0662  vmovaps [rsp+0x50], xmm5
00007fdcd91e0668  vmovaps [rsp+0x60], xmm6
00007fdcd91e066e  vmovaps [rsp+0x70], xmm7
00007fdcd91e0674  vmovaps [rsp+0x80], xmm8
00007fdcd91e067d  vmovaps [rsp+0x90], xmm9
00007fdcd91e0686  vmovaps [rsp+0xA0], xmm10
00007fdcd91e068f  vmovaps [rsp+0xB0], xmm11
00007fdcd91e0698  vmovaps [rsp+0xC0], xmm12
00007fdcd91e06a1  vmovaps [rsp+0xD0], xmm14
00007fdcd91e06aa  vmovaps [rsp+0xE0], xmm15
00007fdcd91e06b3  sub rsp, 0x30
00007fdcd91e06b7  movaps [rsp], xmm13
00007fdcd91e06bc  movaps [rsp+0x10], xmm15
00007fdcd91e06c2  movaps [rsp+0x20], xmm8
00007fdcd91e06c8  lea rdi, [rsp]
00007fdcd91e06cc  mov esi, 0x00
00007fdcd91e06d1  mov rax, 0x5B56EFBF3530
00007fdcd91e06db  call rax
00007fdcd91e06dd  movaps xmm13, [rsp]
00007fdcd91e06e2  add rsp, 0x30
00007fdcd91e06e6  vmovaps xmm0, [rsp]
00007fdcd91e06eb  vmovaps xmm1, [rsp+0x10]
00007fdcd91e06f1  vmovaps xmm2, [rsp+0x20]
00007fdcd91e06f7  vmovaps xmm3, [rsp+0x30]
00007fdcd91e06fd  vmovaps xmm4, [rsp+0x40]
00007fdcd91e0703  vmovaps xmm5, [rsp+0x50]
00007fdcd91e0709  vmovaps xmm6, [rsp+0x60]
00007fdcd91e070f  vmovaps xmm7, [rsp+0x70]
00007fdcd91e0715  vmovaps xmm8, [rsp+0x80]
00007fdcd91e071e  vmovaps xmm9, [rsp+0x90]
00007fdcd91e0727  vmovaps xmm10, [rsp+0xA0]
00007fdcd91e0730  vmovaps xmm11, [rsp+0xB0]
00007fdcd91e0739  vmovaps xmm12, [rsp+0xC0]
00007fdcd91e0742  vmovaps xmm14, [rsp+0xD0]
00007fdcd91e074b  vmovaps xmm15, [rsp+0xE0]
00007fdcd91e0754  add rsp, 0xF0
00007fdcd91e075b  pop r11
00007fdcd91e075d  pop r10
00007fdcd91e075f  pop r9
00007fdcd91e0761  pop r8
00007fdcd91e0763  pop rsi
00007fdcd91e0764  pop rdi
00007fdcd91e0765  pop rdx
00007fdcd91e0766  pop rcx
00007fdcd91e0767  pop rax
00007fdcd91e0768  add rsp, 0x08
00007fdcd91e076c  jmp 0x00007FDCD91DC60F
00007fdcd91e0771  sub rsp, 0x08
00007fdcd91e0775  push rax
00007fdcd91e0776  push rcx
00007fdcd91e0777  push rdx
00007fdcd91e0778  push rdi
00007fdcd91e0779  push rsi
00007fdcd91e077a  push r8
00007fdcd91e077c  push r9
00007fdcd91e077e  push r10
00007fdcd91e0780  push r11
00007fdcd91e0782  sub rsp, 0xF0
00007fdcd91e0789  vmovaps [rsp], xmm0
00007fdcd91e078e  vmovaps [rsp+0x10], xmm1
00007fdcd91e0794  vmovaps [rsp+0x20], xmm2
00007fdcd91e079a  vmovaps [rsp+0x30], xmm3
00007fdcd91e07a0  vmovaps [rsp+0x40], xmm4
00007fdcd91e07a6  vmovaps [rsp+0x50], xmm5
00007fdcd91e07ac  vmovaps [rsp+0x60], xmm6
00007fdcd91e07b2  vmovaps [rsp+0x70], xmm7
00007fdcd91e07b8  vmovaps [rsp+0x80], xmm9
00007fdcd91e07c1  vmovaps [rsp+0x90], xmm10
00007fdcd91e07ca  vmovaps [rsp+0xA0], xmm11
00007fdcd91e07d3  vmovaps [rsp+0xB0], xmm12
00007fdcd91e07dc  vmovaps [rsp+0xC0], xmm13
00007fdcd91e07e5  vmovaps [rsp+0xD0], xmm14
00007fdcd91e07ee  vmovaps [rsp+0xE0], xmm15
00007fdcd91e07f7  sub rsp, 0x30
00007fdcd91e07fb  movaps [rsp], xmm8
00007fdcd91e0800  movaps [rsp+0x10], xmm15
00007fdcd91e0806  movaps [rsp+0x20], xmm9
00007fdcd91e080c  lea rdi, [rsp]
00007fdcd91e0810  mov esi, 0x00
00007fdcd91e0815  mov rax, 0x5B56EFBF3530
00007fdcd91e081f  call rax
00007fdcd91e0821  movaps xmm8, [rsp]
00007fdcd91e0826  add rsp, 0x30
00007fdcd91e082a  vmovaps xmm0, [rsp]
00007fdcd91e082f  vmovaps xmm1, [rsp+0x10]
00007fdcd91e0835  vmovaps xmm2, [rsp+0x20]
00007fdcd91e083b  vmovaps xmm3, [rsp+0x30]
00007fdcd91e0841  vmovaps xmm4, [rsp+0x40]
00007fdcd91e0847  vmovaps xmm5, [rsp+0x50]
00007fdcd91e084d  vmovaps xmm6, [rsp+0x60]
00007fdcd91e0853  vmovaps xmm7, [rsp+0x70]
00007fdcd91e0859  vmovaps xmm9, [rsp+0x80]
00007fdcd91e0862  vmovaps xmm10, [rsp+0x90]
00007fdcd91e086b  vmovaps xmm11, [rsp+0xA0]
00007fdcd91e0874  vmovaps xmm12, [rsp+0xB0]
00007fdcd91e087d  vmovaps xmm13, [rsp+0xC0]
00007fdcd91e0886  vmovaps xmm14, [rsp+0xD0]
00007fdcd91e088f  vmovaps xmm15, [rsp+0xE0]
00007fdcd91e0898  add rsp, 0xF0
00007fdcd91e089f  pop r11
00007fdcd91e08a1  pop r10
00007fdcd91e08a3  pop r9
00007fdcd91e08a5  pop r8
00007fdcd91e08a7  pop rsi
00007fdcd91e08a8  pop rdi
00007fdcd91e08a9  pop rdx
00007fdcd91e08aa  pop rcx
00007fdcd91e08ab  pop rax
00007fdcd91e08ac  add rsp, 0x08
00007fdcd91e08b0  jmp 0x00007FDCD91DC63D
00007fdcd91e08b5  sub rsp, 0x08
00007fdcd91e08b9  push rax
00007fdcd91e08ba  push rcx
00007fdcd91e08bb  push rdx
00007fdcd91e08bc  push rdi
00007fdcd91e08bd  push rsi
00007fdcd91e08be  push r8
00007fdcd91e08c0  push r9
00007fdcd91e08c2  push r10
00007fdcd91e08c4  push r11
00007fdcd91e08c6  sub rsp, 0xF0
00007fdcd91e08cd  vmovaps [rsp], xmm0
00007fdcd91e08d2  vmovaps [rsp+0x10], xmm1
00007fdcd91e08d8  vmovaps [rsp+0x20], xmm2
00007fdcd91e08de  vmovaps [rsp+0x30], xmm3
00007fdcd91e08e4  vmovaps [rsp+0x40], xmm4
00007fdcd91e08ea  vmovaps [rsp+0x50], xmm5
00007fdcd91e08f0  vmovaps [rsp+0x60], xmm6
00007fdcd91e08f6  vmovaps [rsp+0x70], xmm7
00007fdcd91e08fc  vmovaps [rsp+0x80], xmm8
00007fdcd91e0905  vmovaps [rsp+0x90], xmm9
00007fdcd91e090e  vmovaps [rsp+0xA0], xmm10
00007fdcd91e0917  vmovaps [rsp+0xB0], xmm11
00007fdcd91e0920  vmovaps [rsp+0xC0], xmm12
00007fdcd91e0929  vmovaps [rsp+0xD0], xmm13
00007fdcd91e0932  vmovaps [rsp+0xE0], xmm14
00007fdcd91e093b  sub rsp, 0x30
00007fdcd91e093f  movaps [rsp], xmm15
00007fdcd91e0944  movaps [rsp+0x10], xmm11
00007fdcd91e094a  movaps [rsp+0x20], xmm6
00007fdcd91e094f  lea rdi, [rsp]
00007fdcd91e0953  mov esi, 0x00
00007fdcd91e0958  mov rax, 0x5B56EFBF3530
00007fdcd91e0962  call rax
00007fdcd91e0964  movaps xmm15, [rsp]
00007fdcd91e0969  add rsp, 0x30
00007fdcd91e096d  vmovaps xmm0, [rsp]
00007fdcd91e0972  vmovaps xmm1, [rsp+0x10]
00007fdcd91e0978  vmovaps xmm2, [rsp+0x20]
00007fdcd91e097e  vmovaps xmm3, [rsp+0x30]
00007fdcd91e0984  vmovaps xmm4, [rsp+0x40]
00007fdcd91e098a  vmovaps xmm5, [rsp+0x50]
00007fdcd91e0990  vmovaps xmm6, [rsp+0x60]
00007fdcd91e0996  vmovaps xmm7, [rsp+0x70]
00007fdcd91e099c  vmovaps xmm8, [rsp+0x80]
00007fdcd91e09a5  vmovaps xmm9, [rsp+0x90]
00007fdcd91e09ae  vmovaps xmm10, [rsp+0xA0]
00007fdcd91e09b7  vmovaps xmm11, [rsp+0xB0]
00007fdcd91e09c0  vmovaps xmm12, [rsp+0xC0]
00007fdcd91e09c9  vmovaps xmm13, [rsp+0xD0]
00007fdcd91e09d2  vmovaps xmm14, [rsp+0xE0]
00007fdcd91e09db  add rsp, 0xF0
00007fdcd91e09e2  pop r11
00007fdcd91e09e4  pop r10
00007fdcd91e09e6  pop r9
00007fdcd91e09e8  pop r8
00007fdcd91e09ea  pop rsi
00007fdcd91e09eb  pop rdi
00007fdcd91e09ec  pop rdx
00007fdcd91e09ed  pop rcx
00007fdcd91e09ee  pop rax
00007fdcd91e09ef  add rsp, 0x08
00007fdcd91e09f3  jmp 0x00007FDCD91DC658
00007fdcd91e09f8  sub rsp, 0x08
00007fdcd91e09fc  push rax
00007fdcd91e09fd  push rcx
00007fdcd91e09fe  push rdx
00007fdcd91e09ff  push rdi
00007fdcd91e0a00  push rsi
00007fdcd91e0a01  push r8
00007fdcd91e0a03  push r9
00007fdcd91e0a05  push r10
00007fdcd91e0a07  push r11
00007fdcd91e0a09  sub rsp, 0xF0
00007fdcd91e0a10  vmovaps [rsp], xmm0
00007fdcd91e0a15  vmovaps [rsp+0x10], xmm1
00007fdcd91e0a1b  vmovaps [rsp+0x20], xmm2
00007fdcd91e0a21  vmovaps [rsp+0x30], xmm3
00007fdcd91e0a27  vmovaps [rsp+0x40], xmm4
00007fdcd91e0a2d  vmovaps [rsp+0x50], xmm5
00007fdcd91e0a33  vmovaps [rsp+0x60], xmm6
00007fdcd91e0a39  vmovaps [rsp+0x70], xmm8
00007fdcd91e0a3f  vmovaps [rsp+0x80], xmm9
00007fdcd91e0a48  vmovaps [rsp+0x90], xmm10
00007fdcd91e0a51  vmovaps [rsp+0xA0], xmm11
00007fdcd91e0a5a  vmovaps [rsp+0xB0], xmm12
00007fdcd91e0a63  vmovaps [rsp+0xC0], xmm13
00007fdcd91e0a6c  vmovaps [rsp+0xD0], xmm14
00007fdcd91e0a75  vmovaps [rsp+0xE0], xmm15
00007fdcd91e0a7e  sub rsp, 0x30
00007fdcd91e0a82  movaps [rsp], xmm7
00007fdcd91e0a86  movaps [rsp+0x10], xmm11
00007fdcd91e0a8c  movaps [rsp+0x20], xmm9
00007fdcd91e0a92  lea rdi, [rsp]
00007fdcd91e0a96  mov esi, 0x00
00007fdcd91e0a9b  mov rax, 0x5B56EFBF3530
00007fdcd91e0aa5  call rax
00007fdcd91e0aa7  movaps xmm7, [rsp]
00007fdcd91e0aab  add rsp, 0x30
00007fdcd91e0aaf  vmovaps xmm0, [rsp]
00007fdcd91e0ab4  vmovaps xmm1, [rsp+0x10]
00007fdcd91e0aba  vmovaps xmm2, [rsp+0x20]
00007fdcd91e0ac0  vmovaps xmm3, [rsp+0x30]
00007fdcd91e0ac6  vmovaps xmm4, [rsp+0x40]
00007fdcd91e0acc  vmovaps xmm5, [rsp+0x50]
00007fdcd91e0ad2  vmovaps xmm6, [rsp+0x60]
00007fdcd91e0ad8  vmovaps xmm8, [rsp+0x70]
00007fdcd91e0ade  vmovaps xmm9, [rsp+0x80]
00007fdcd91e0ae7  vmovaps xmm10, [rsp+0x90]
00007fdcd91e0af0  vmovaps xmm11, [rsp+0xA0]
00007fdcd91e0af9  vmovaps xmm12, [rsp+0xB0]
00007fdcd91e0b02  vmovaps xmm13, [rsp+0xC0]
00007fdcd91e0b0b  vmovaps xmm14, [rsp+0xD0]
00007fdcd91e0b14  vmovaps xmm15, [rsp+0xE0]
00007fdcd91e0b1d  add rsp, 0xF0
00007fdcd91e0b24  pop r11
00007fdcd91e0b26  pop r10
00007fdcd91e0b28  pop r9
00007fdcd91e0b2a  pop r8
00007fdcd91e0b2c  pop rsi
00007fdcd91e0b2d  pop rdi
00007fdcd91e0b2e  pop rdx
00007fdcd91e0b2f  pop rcx
00007fdcd91e0b30  pop rax
00007fdcd91e0b31  add rsp, 0x08
00007fdcd91e0b35  jmp 0x00007FDCD91DC685
00007fdcd91e0b3a  sub rsp, 0x08
00007fdcd91e0b3e  push rax
00007fdcd91e0b3f  push rcx
00007fdcd91e0b40  push rdx
00007fdcd91e0b41  push rdi
00007fdcd91e0b42  push rsi
00007fdcd91e0b43  push r8
00007fdcd91e0b45  push r9
00007fdcd91e0b47  push r10
00007fdcd91e0b49  push r11
00007fdcd91e0b4b  sub rsp, 0xF0
00007fdcd91e0b52  vmovaps [rsp], xmm0
00007fdcd91e0b57  vmovaps [rsp+0x10], xmm1
00007fdcd91e0b5d  vmovaps [rsp+0x20], xmm2
00007fdcd91e0b63  vmovaps [rsp+0x30], xmm3
00007fdcd91e0b69  vmovaps [rsp+0x40], xmm4
00007fdcd91e0b6f  vmovaps [rsp+0x50], xmm5
00007fdcd91e0b75  vmovaps [rsp+0x60], xmm6
00007fdcd91e0b7b  vmovaps [rsp+0x70], xmm7
00007fdcd91e0b81  vmovaps [rsp+0x80], xmm8
00007fdcd91e0b8a  vmovaps [rsp+0x90], xmm9
00007fdcd91e0b93  vmovaps [rsp+0xA0], xmm10
00007fdcd91e0b9c  vmovaps [rsp+0xB0], xmm12
00007fdcd91e0ba5  vmovaps [rsp+0xC0], xmm13
00007fdcd91e0bae  vmovaps [rsp+0xD0], xmm14
00007fdcd91e0bb7  vmovaps [rsp+0xE0], xmm15
00007fdcd91e0bc0  sub rsp, 0x30
00007fdcd91e0bc4  movaps [rsp], xmm11
00007fdcd91e0bc9  movaps [rsp+0x10], xmm10
00007fdcd91e0bcf  movaps [rsp+0x20], xmm14
00007fdcd91e0bd5  lea rdi, [rsp]
00007fdcd91e0bd9  mov esi, 0x00
00007fdcd91e0bde  mov rax, 0x5B56EFBF3530
00007fdcd91e0be8  call rax
00007fdcd91e0bea  movaps xmm11, [rsp]
00007fdcd91e0bef  add rsp, 0x30
00007fdcd91e0bf3  vmovaps xmm0, [rsp]
00007fdcd91e0bf8  vmovaps xmm1, [rsp+0x10]
00007fdcd91e0bfe  vmovaps xmm2, [rsp+0x20]
00007fdcd91e0c04  vmovaps xmm3, [rsp+0x30]
00007fdcd91e0c0a  vmovaps xmm4, [rsp+0x40]
00007fdcd91e0c10  vmovaps xmm5, [rsp+0x50]
00007fdcd91e0c16  vmovaps xmm6, [rsp+0x60]
00007fdcd91e0c1c  vmovaps xmm7, [rsp+0x70]
00007fdcd91e0c22  vmovaps xmm8, [rsp+0x80]
00007fdcd91e0c2b  vmovaps xmm9, [rsp+0x90]
00007fdcd91e0c34  vmovaps xmm10, [rsp+0xA0]
00007fdcd91e0c3d  vmovaps xmm12, [rsp+0xB0]
00007fdcd91e0c46  vmovaps xmm13, [rsp+0xC0]
00007fdcd91e0c4f  vmovaps xmm14, [rsp+0xD0]
00007fdcd91e0c58  vmovaps xmm15, [rsp+0xE0]
00007fdcd91e0c61  add rsp, 0xF0
00007fdcd91e0c68  pop r11
00007fdcd91e0c6a  pop r10
00007fdcd91e0c6c  pop r9
00007fdcd91e0c6e  pop r8
00007fdcd91e0c70  pop rsi
00007fdcd91e0c71  pop rdi
00007fdcd91e0c72  pop rdx
00007fdcd91e0c73  pop rcx
00007fdcd91e0c74  pop rax
00007fdcd91e0c75  add rsp, 0x08
00007fdcd91e0c79  jmp 0x00007FDCD91DC6A0
00007fdcd91e0c7e  call 0x00007FDCD90C33A0
00007fdcd91e0c83  jmp 0x00007FDCD91DC6AA
00007fdcd91e0c88  sub rsp, 0x08
00007fdcd91e0c8c  push rax
00007fdcd91e0c8d  push rcx
00007fdcd91e0c8e  push rdx
00007fdcd91e0c8f  push rdi
00007fdcd91e0c90  push rsi
00007fdcd91e0c91  push r8
00007fdcd91e0c93  push r9
00007fdcd91e0c95  push r10
00007fdcd91e0c97  push r11
00007fdcd91e0c99  sub rsp, 0xF0
00007fdcd91e0ca0  vmovaps [rsp], xmm0
00007fdcd91e0ca5  vmovaps [rsp+0x10], xmm1
00007fdcd91e0cab  vmovaps [rsp+0x20], xmm2
00007fdcd91e0cb1  vmovaps [rsp+0x30], xmm3
00007fdcd91e0cb7  vmovaps [rsp+0x40], xmm4
00007fdcd91e0cbd  vmovaps [rsp+0x50], xmm5
00007fdcd91e0cc3  vmovaps [rsp+0x60], xmm6
00007fdcd91e0cc9  vmovaps [rsp+0x70], xmm7
00007fdcd91e0ccf  vmovaps [rsp+0x80], xmm8
00007fdcd91e0cd8  vmovaps [rsp+0x90], xmm9
00007fdcd91e0ce1  vmovaps [rsp+0xA0], xmm11
00007fdcd91e0cea  vmovaps [rsp+0xB0], xmm12
00007fdcd91e0cf3  vmovaps [rsp+0xC0], xmm13
00007fdcd91e0cfc  vmovaps [rsp+0xD0], xmm14
00007fdcd91e0d05  vmovaps [rsp+0xE0], xmm15
00007fdcd91e0d0e  sub rsp, 0x30
00007fdcd91e0d12  movaps [rsp], xmm10
00007fdcd91e0d17  movaps [rsp+0x10], xmm1
00007fdcd91e0d1c  movaps [rsp+0x20], xmm12
00007fdcd91e0d22  lea rdi, [rsp]
00007fdcd91e0d26  mov esi, 0x00
00007fdcd91e0d2b  mov rax, 0x5B56EFBF3530
00007fdcd91e0d35  call rax
00007fdcd91e0d37  movaps xmm10, [rsp]
00007fdcd91e0d3c  add rsp, 0x30
00007fdcd91e0d40  vmovaps xmm0, [rsp]
00007fdcd91e0d45  vmovaps xmm1, [rsp+0x10]
00007fdcd91e0d4b  vmovaps xmm2, [rsp+0x20]
00007fdcd91e0d51  vmovaps xmm3, [rsp+0x30]
00007fdcd91e0d57  vmovaps xmm4, [rsp+0x40]
00007fdcd91e0d5d  vmovaps xmm5, [rsp+0x50]
00007fdcd91e0d63  vmovaps xmm6, [rsp+0x60]
00007fdcd91e0d69  vmovaps xmm7, [rsp+0x70]
00007fdcd91e0d6f  vmovaps xmm8, [rsp+0x80]
00007fdcd91e0d78  vmovaps xmm9, [rsp+0x90]
00007fdcd91e0d81  vmovaps xmm11, [rsp+0xA0]
00007fdcd91e0d8a  vmovaps xmm12, [rsp+0xB0]
00007fdcd91e0d93  vmovaps xmm13, [rsp+0xC0]
00007fdcd91e0d9c  vmovaps xmm14, [rsp+0xD0]
00007fdcd91e0da5  vmovaps xmm15, [rsp+0xE0]
00007fdcd91e0dae  add rsp, 0xF0
00007fdcd91e0db5  pop r11
00007fdcd91e0db7  pop r10
00007fdcd91e0db9  pop r9
00007fdcd91e0dbb  pop r8
00007fdcd91e0dbd  pop rsi
00007fdcd91e0dbe  pop rdi
00007fdcd91e0dbf  pop rdx
00007fdcd91e0dc0  pop rcx
00007fdcd91e0dc1  pop rax
00007fdcd91e0dc2  add rsp, 0x08
00007fdcd91e0dc6  jmp 0x00007FDCD91DC6CD
00007fdcd91e0dcb  sub rsp, 0x08
00007fdcd91e0dcf  push rax
00007fdcd91e0dd0  push rcx
00007fdcd91e0dd1  push rdx
00007fdcd91e0dd2  push rdi
00007fdcd91e0dd3  push rsi
00007fdcd91e0dd4  push r8
00007fdcd91e0dd6  push r9
00007fdcd91e0dd8  push r10
00007fdcd91e0dda  push r11
00007fdcd91e0ddc  sub rsp, 0xF0
00007fdcd91e0de3  vmovaps [rsp], xmm0
00007fdcd91e0de8  vmovaps [rsp+0x10], xmm1
00007fdcd91e0dee  vmovaps [rsp+0x20], xmm2
00007fdcd91e0df4  vmovaps [rsp+0x30], xmm3
00007fdcd91e0dfa  vmovaps [rsp+0x40], xmm4
00007fdcd91e0e00  vmovaps [rsp+0x50], xmm5
00007fdcd91e0e06  vmovaps [rsp+0x60], xmm6
00007fdcd91e0e0c  vmovaps [rsp+0x70], xmm7
00007fdcd91e0e12  vmovaps [rsp+0x80], xmm8
00007fdcd91e0e1b  vmovaps [rsp+0x90], xmm9
00007fdcd91e0e24  vmovaps [rsp+0xA0], xmm10
00007fdcd91e0e2d  vmovaps [rsp+0xB0], xmm11
00007fdcd91e0e36  vmovaps [rsp+0xC0], xmm13
00007fdcd91e0e3f  vmovaps [rsp+0xD0], xmm14
00007fdcd91e0e48  vmovaps [rsp+0xE0], xmm15
00007fdcd91e0e51  sub rsp, 0x30
00007fdcd91e0e55  movaps [rsp], xmm12
00007fdcd91e0e5a  movaps [rsp+0x10], xmm14
00007fdcd91e0e60  movaps [rsp+0x20], xmm1
00007fdcd91e0e65  lea rdi, [rsp]
00007fdcd91e0e69  mov esi, 0x00
00007fdcd91e0e6e  mov rax, 0x5B56EFBF3530
00007fdcd91e0e78  call rax
00007fdcd91e0e7a  movaps xmm12, [rsp]
00007fdcd91e0e7f  add rsp, 0x30
00007fdcd91e0e83  vmovaps xmm0, [rsp]
00007fdcd91e0e88  vmovaps xmm1, [rsp+0x10]
00007fdcd91e0e8e  vmovaps xmm2, [rsp+0x20]
00007fdcd91e0e94  vmovaps xmm3, [rsp+0x30]
00007fdcd91e0e9a  vmovaps xmm4, [rsp+0x40]
00007fdcd91e0ea0  vmovaps xmm5, [rsp+0x50]
00007fdcd91e0ea6  vmovaps xmm6, [rsp+0x60]
00007fdcd91e0eac  vmovaps xmm7, [rsp+0x70]
00007fdcd91e0eb2  vmovaps xmm8, [rsp+0x80]
00007fdcd91e0ebb  vmovaps xmm9, [rsp+0x90]
00007fdcd91e0ec4  vmovaps xmm10, [rsp+0xA0]
00007fdcd91e0ecd  vmovaps xmm11, [rsp+0xB0]
00007fdcd91e0ed6  vmovaps xmm13, [rsp+0xC0]
00007fdcd91e0edf  vmovaps xmm14, [rsp+0xD0]
00007fdcd91e0ee8  vmovaps xmm15, [rsp+0xE0]
00007fdcd91e0ef1  add rsp, 0xF0
00007fdcd91e0ef8  pop r11
00007fdcd91e0efa  pop r10
00007fdcd91e0efc  pop r9
00007fdcd91e0efe  pop r8
00007fdcd91e0f00  pop rsi
00007fdcd91e0f01  pop rdi
00007fdcd91e0f02  pop rdx
00007fdcd91e0f03  pop rcx
00007fdcd91e0f04  pop rax
00007fdcd91e0f05  add rsp, 0x08
00007fdcd91e0f09  jmp 0x00007FDCD91DC6FC
00007fdcd91e0f0e  sub rsp, 0x08
00007fdcd91e0f12  push rax
00007fdcd91e0f13  push rcx
00007fdcd91e0f14  push rdx
00007fdcd91e0f15  push rdi
00007fdcd91e0f16  push rsi
00007fdcd91e0f17  push r8
00007fdcd91e0f19  push r9
00007fdcd91e0f1b  push r10
00007fdcd91e0f1d  push r11
00007fdcd91e0f1f  sub rsp, 0xF0
00007fdcd91e0f26  vmovaps [rsp], xmm0
00007fdcd91e0f2b  vmovaps [rsp+0x10], xmm1
00007fdcd91e0f31  vmovaps [rsp+0x20], xmm2
00007fdcd91e0f37  vmovaps [rsp+0x30], xmm3
00007fdcd91e0f3d  vmovaps [rsp+0x40], xmm4
00007fdcd91e0f43  vmovaps [rsp+0x50], xmm5
00007fdcd91e0f49  vmovaps [rsp+0x60], xmm6
00007fdcd91e0f4f  vmovaps [rsp+0x70], xmm7
00007fdcd91e0f55  vmovaps [rsp+0x80], xmm8
00007fdcd91e0f5e  vmovaps [rsp+0x90], xmm9
00007fdcd91e0f67  vmovaps [rsp+0xA0], xmm10
00007fdcd91e0f70  vmovaps [rsp+0xB0], xmm11
00007fdcd91e0f79  vmovaps [rsp+0xC0], xmm12
00007fdcd91e0f82  vmovaps [rsp+0xD0], xmm13
00007fdcd91e0f8b  vmovaps [rsp+0xE0], xmm15
00007fdcd91e0f94  sub rsp, 0x30
00007fdcd91e0f98  movaps [rsp], xmm14
00007fdcd91e0f9d  movaps [rsp+0x10], xmm9
00007fdcd91e0fa3  movaps [rsp+0x20], xmm1
00007fdcd91e0fa8  lea rdi, [rsp]
00007fdcd91e0fac  mov esi, 0x00
00007fdcd91e0fb1  mov rax, 0x5B56EFBF3530
00007fdcd91e0fbb  call rax
00007fdcd91e0fbd  movaps xmm14, [rsp]
00007fdcd91e0fc2  add rsp, 0x30
00007fdcd91e0fc6  vmovaps xmm0, [rsp]
00007fdcd91e0fcb  vmovaps xmm1, [rsp+0x10]
00007fdcd91e0fd1  vmovaps xmm2, [rsp+0x20]
00007fdcd91e0fd7  vmovaps xmm3, [rsp+0x30]
00007fdcd91e0fdd  vmovaps xmm4, [rsp+0x40]
00007fdcd91e0fe3  vmovaps xmm5, [rsp+0x50]
00007fdcd91e0fe9  vmovaps xmm6, [rsp+0x60]
00007fdcd91e0fef  vmovaps xmm7, [rsp+0x70]
00007fdcd91e0ff5  vmovaps xmm8, [rsp+0x80]
00007fdcd91e0ffe  vmovaps xmm9, [rsp+0x90]
00007fdcd91e1007  vmovaps xmm10, [rsp+0xA0]
00007fdcd91e1010  vmovaps xmm11, [rsp+0xB0]
00007fdcd91e1019  vmovaps xmm12, [rsp+0xC0]
00007fdcd91e1022  vmovaps xmm13, [rsp+0xD0]
00007fdcd91e102b  vmovaps xmm15, [rsp+0xE0]
00007fdcd91e1034  add rsp, 0xF0
00007fdcd91e103b  pop r11
00007fdcd91e103d  pop r10
00007fdcd91e103f  pop r9
00007fdcd91e1041  pop r8
00007fdcd91e1043  pop rsi
00007fdcd91e1044  pop rdi
00007fdcd91e1045  pop rdx
00007fdcd91e1046  pop rcx
00007fdcd91e1047  pop rax
00007fdcd91e1048  add rsp, 0x08
00007fdcd91e104c  jmp 0x00007FDCD91DC72B
00007fdcd91e1051  sub rsp, 0x08
00007fdcd91e1055  push rax
00007fdcd91e1056  push rcx
00007fdcd91e1057  push rdx
00007fdcd91e1058  push rdi
00007fdcd91e1059  push rsi
00007fdcd91e105a  push r8
00007fdcd91e105c  push r9
00007fdcd91e105e  push r10
00007fdcd91e1060  push r11
00007fdcd91e1062  sub rsp, 0xF0
00007fdcd91e1069  vmovaps [rsp], xmm0
00007fdcd91e106e  vmovaps [rsp+0x10], xmm2
00007fdcd91e1074  vmovaps [rsp+0x20], xmm3
00007fdcd91e107a  vmovaps [rsp+0x30], xmm4
00007fdcd91e1080  vmovaps [rsp+0x40], xmm5
00007fdcd91e1086  vmovaps [rsp+0x50], xmm6
00007fdcd91e108c  vmovaps [rsp+0x60], xmm7
00007fdcd91e1092  vmovaps [rsp+0x70], xmm8
00007fdcd91e1098  vmovaps [rsp+0x80], xmm9
00007fdcd91e10a1  vmovaps [rsp+0x90], xmm10
00007fdcd91e10aa  vmovaps [rsp+0xA0], xmm11
00007fdcd91e10b3  vmovaps [rsp+0xB0], xmm12
00007fdcd91e10bc  vmovaps [rsp+0xC0], xmm13
00007fdcd91e10c5  vmovaps [rsp+0xD0], xmm14
00007fdcd91e10ce  vmovaps [rsp+0xE0], xmm15
00007fdcd91e10d7  sub rsp, 0x30
00007fdcd91e10db  movaps [rsp], xmm1
00007fdcd91e10df  movaps [rsp+0x10], xmm13
00007fdcd91e10e5  movaps [rsp+0x20], xmm8
00007fdcd91e10eb  lea rdi, [rsp]
00007fdcd91e10ef  mov esi, 0x00
00007fdcd91e10f4  mov rax, 0x5B56EFBF3530
00007fdcd91e10fe  call rax
00007fdcd91e1100  movaps xmm1, [rsp]
00007fdcd91e1104  add rsp, 0x30
00007fdcd91e1108  vmovaps xmm0, [rsp]
00007fdcd91e110d  vmovaps xmm2, [rsp+0x10]
00007fdcd91e1113  vmovaps xmm3, [rsp+0x20]
00007fdcd91e1119  vmovaps xmm4, [rsp+0x30]
00007fdcd91e111f  vmovaps xmm5, [rsp+0x40]
00007fdcd91e1125  vmovaps xmm6, [rsp+0x50]
00007fdcd91e112b  vmovaps xmm7, [rsp+0x60]
00007fdcd91e1131  vmovaps xmm8, [rsp+0x70]
00007fdcd91e1137  vmovaps xmm9, [rsp+0x80]
00007fdcd91e1140  vmovaps xmm10, [rsp+0x90]
00007fdcd91e1149  vmovaps xmm11, [rsp+0xA0]
00007fdcd91e1152  vmovaps xmm12, [rsp+0xB0]
00007fdcd91e115b  vmovaps xmm13, [rsp+0xC0]
00007fdcd91e1164  vmovaps xmm14, [rsp+0xD0]
00007fdcd91e116d  vmovaps xmm15, [rsp+0xE0]
00007fdcd91e1176  add rsp, 0xF0
00007fdcd91e117d  pop r11
00007fdcd91e117f  pop r10
00007fdcd91e1181  pop r9
00007fdcd91e1183  pop r8
00007fdcd91e1185  pop rsi
00007fdcd91e1186  pop rdi
00007fdcd91e1187  pop rdx
00007fdcd91e1188  pop rcx
00007fdcd91e1189  pop rax
00007fdcd91e118a  add rsp, 0x08
00007fdcd91e118e  jmp 0x00007FDCD91DC74D
00007fdcd91e1193  call 0x00007FDCD900C260
00007fdcd91e1198  jmp 0x00007FDCD91DC75B
00007fdcd91e119d  call 0x00007FDCD90BD750
00007fdcd91e11a2  jmp 0x00007FDCD91DC765
00007fdcd91e11a7  sub rsp, 0x08
00007fdcd91e11ab  push rax
00007fdcd91e11ac  push rcx
00007fdcd91e11ad  push rdx
00007fdcd91e11ae  push rdi
00007fdcd91e11af  push rsi
00007fdcd91e11b0  push r8
00007fdcd91e11b2  push r9
00007fdcd91e11b4  push r10
00007fdcd91e11b6  push r11
00007fdcd91e11b8  sub rsp, 0xF0
00007fdcd91e11bf  vmovaps [rsp], xmm0
00007fdcd91e11c4  vmovaps [rsp+0x10], xmm1
00007fdcd91e11ca  vmovaps [rsp+0x20], xmm2
00007fdcd91e11d0  vmovaps [rsp+0x30], xmm3
00007fdcd91e11d6  vmovaps [rsp+0x40], xmm4
00007fdcd91e11dc  vmovaps [rsp+0x50], xmm5
00007fdcd91e11e2  vmovaps [rsp+0x60], xmm6
00007fdcd91e11e8  vmovaps [rsp+0x70], xmm7
00007fdcd91e11ee  vmovaps [rsp+0x80], xmm9
00007fdcd91e11f7  vmovaps [rsp+0x90], xmm10
00007fdcd91e1200  vmovaps [rsp+0xA0], xmm11
00007fdcd91e1209  vmovaps [rsp+0xB0], xmm12
00007fdcd91e1212  vmovaps [rsp+0xC0], xmm13
00007fdcd91e121b  vmovaps [rsp+0xD0], xmm14
00007fdcd91e1224  vmovaps [rsp+0xE0], xmm15
00007fdcd91e122d  sub rsp, 0x30
00007fdcd91e1231  movaps [rsp], xmm8
00007fdcd91e1236  movaps [rsp+0x10], xmm15
00007fdcd91e123c  movaps [rsp+0x20], xmm7
00007fdcd91e1241  lea rdi, [rsp]
00007fdcd91e1245  mov esi, 0x00
00007fdcd91e124a  mov rax, 0x5B56EFBF3530
00007fdcd91e1254  call rax
00007fdcd91e1256  movaps xmm8, [rsp]
00007fdcd91e125b  add rsp, 0x30
00007fdcd91e125f  vmovaps xmm0, [rsp]
00007fdcd91e1264  vmovaps xmm1, [rsp+0x10]
00007fdcd91e126a  vmovaps xmm2, [rsp+0x20]
00007fdcd91e1270  vmovaps xmm3, [rsp+0x30]
00007fdcd91e1276  vmovaps xmm4, [rsp+0x40]
00007fdcd91e127c  vmovaps xmm5, [rsp+0x50]
00007fdcd91e1282  vmovaps xmm6, [rsp+0x60]
00007fdcd91e1288  vmovaps xmm7, [rsp+0x70]
00007fdcd91e128e  vmovaps xmm9, [rsp+0x80]
00007fdcd91e1297  vmovaps xmm10, [rsp+0x90]
00007fdcd91e12a0  vmovaps xmm11, [rsp+0xA0]
00007fdcd91e12a9  vmovaps xmm12, [rsp+0xB0]
00007fdcd91e12b2  vmovaps xmm13, [rsp+0xC0]
00007fdcd91e12bb  vmovaps xmm14, [rsp+0xD0]
00007fdcd91e12c4  vmovaps xmm15, [rsp+0xE0]
00007fdcd91e12cd  add rsp, 0xF0
00007fdcd91e12d4  pop r11
00007fdcd91e12d6  pop r10
00007fdcd91e12d8  pop r9
00007fdcd91e12da  pop r8
00007fdcd91e12dc  pop rsi
00007fdcd91e12dd  pop rdi
00007fdcd91e12de  pop rdx
00007fdcd91e12df  pop rcx
00007fdcd91e12e0  pop rax
00007fdcd91e12e1  add rsp, 0x08
00007fdcd91e12e5  jmp 0x00007FDCD91DC787
00007fdcd91e12ea  sub rsp, 0x08
00007fdcd91e12ee  push rax
00007fdcd91e12ef  push rcx
00007fdcd91e12f0  push rdx
00007fdcd91e12f1  push rdi
00007fdcd91e12f2  push rsi
00007fdcd91e12f3  push r8
00007fdcd91e12f5  push r9
00007fdcd91e12f7  push r10
00007fdcd91e12f9  push r11
00007fdcd91e12fb  sub rsp, 0xF0
00007fdcd91e1302  vmovaps [rsp], xmm0
00007fdcd91e1307  vmovaps [rsp+0x10], xmm1
00007fdcd91e130d  vmovaps [rsp+0x20], xmm2
00007fdcd91e1313  vmovaps [rsp+0x30], xmm3
00007fdcd91e1319  vmovaps [rsp+0x40], xmm4
00007fdcd91e131f  vmovaps [rsp+0x50], xmm5
00007fdcd91e1325  vmovaps [rsp+0x60], xmm6
00007fdcd91e132b  vmovaps [rsp+0x70], xmm8
00007fdcd91e1331  vmovaps [rsp+0x80], xmm9
00007fdcd91e133a  vmovaps [rsp+0x90], xmm10
00007fdcd91e1343  vmovaps [rsp+0xA0], xmm11
00007fdcd91e134c  vmovaps [rsp+0xB0], xmm12
00007fdcd91e1355  vmovaps [rsp+0xC0], xmm13
00007fdcd91e135e  vmovaps [rsp+0xD0], xmm14
00007fdcd91e1367  vmovaps [rsp+0xE0], xmm15
00007fdcd91e1370  sub rsp, 0x30
00007fdcd91e1374  movaps [rsp], xmm7
00007fdcd91e1378  movaps [rsp+0x10], xmm9
00007fdcd91e137e  movaps [rsp+0x20], xmm15
00007fdcd91e1384  lea rdi, [rsp]
00007fdcd91e1388  mov esi, 0x00
00007fdcd91e138d  mov rax, 0x5B56EFBF3530
00007fdcd91e1397  call rax
00007fdcd91e1399  movaps xmm7, [rsp]
00007fdcd91e139d  add rsp, 0x30
00007fdcd91e13a1  vmovaps xmm0, [rsp]
00007fdcd91e13a6  vmovaps xmm1, [rsp+0x10]
00007fdcd91e13ac  vmovaps xmm2, [rsp+0x20]
00007fdcd91e13b2  vmovaps xmm3, [rsp+0x30]
00007fdcd91e13b8  vmovaps xmm4, [rsp+0x40]
00007fdcd91e13be  vmovaps xmm5, [rsp+0x50]
00007fdcd91e13c4  vmovaps xmm6, [rsp+0x60]
00007fdcd91e13ca  vmovaps xmm8, [rsp+0x70]
00007fdcd91e13d0  vmovaps xmm9, [rsp+0x80]
00007fdcd91e13d9  vmovaps xmm10, [rsp+0x90]
00007fdcd91e13e2  vmovaps xmm11, [rsp+0xA0]
00007fdcd91e13eb  vmovaps xmm12, [rsp+0xB0]
00007fdcd91e13f4  vmovaps xmm13, [rsp+0xC0]
00007fdcd91e13fd  vmovaps xmm14, [rsp+0xD0]
00007fdcd91e1406  vmovaps xmm15, [rsp+0xE0]
00007fdcd91e140f  add rsp, 0xF0
00007fdcd91e1416  pop r11
00007fdcd91e1418  pop r10
00007fdcd91e141a  pop r9
00007fdcd91e141c  pop r8
00007fdcd91e141e  pop rsi
00007fdcd91e141f  pop rdi
00007fdcd91e1420  pop rdx
00007fdcd91e1421  pop rcx
00007fdcd91e1422  pop rax
00007fdcd91e1423  add rsp, 0x08
00007fdcd91e1427  jmp 0x00007FDCD91DC7B4
00007fdcd91e142c  sub rsp, 0x08
00007fdcd91e1430  push rax
00007fdcd91e1431  push rcx
00007fdcd91e1432  push rdx
00007fdcd91e1433  push rdi
00007fdcd91e1434  push rsi
00007fdcd91e1435  push r8
00007fdcd91e1437  push r9
00007fdcd91e1439  push r10
00007fdcd91e143b  push r11
00007fdcd91e143d  sub rsp, 0xF0
00007fdcd91e1444  vmovaps [rsp], xmm0
00007fdcd91e1449  vmovaps [rsp+0x10], xmm1
00007fdcd91e144f  vmovaps [rsp+0x20], xmm2
00007fdcd91e1455  vmovaps [rsp+0x30], xmm3
00007fdcd91e145b  vmovaps [rsp+0x40], xmm4
00007fdcd91e1461  vmovaps [rsp+0x50], xmm5
00007fdcd91e1467  vmovaps [rsp+0x60], xmm6
00007fdcd91e146d  vmovaps [rsp+0x70], xmm7
00007fdcd91e1473  vmovaps [rsp+0x80], xmm8
00007fdcd91e147c  vmovaps [rsp+0x90], xmm10
00007fdcd91e1485  vmovaps [rsp+0xA0], xmm11
00007fdcd91e148e  vmovaps [rsp+0xB0], xmm12
00007fdcd91e1497  vmovaps [rsp+0xC0], xmm13
00007fdcd91e14a0  vmovaps [rsp+0xD0], xmm14
00007fdcd91e14a9  vmovaps [rsp+0xE0], xmm15
00007fdcd91e14b2  sub rsp, 0x30
00007fdcd91e14b6  movaps [rsp], xmm9
00007fdcd91e14bb  movaps [rsp+0x10], xmm13
00007fdcd91e14c1  movaps [rsp+0x20], xmm15
00007fdcd91e14c7  lea rdi, [rsp]
00007fdcd91e14cb  mov esi, 0x00
00007fdcd91e14d0  mov rax, 0x5B56EFBF3530
00007fdcd91e14da  call rax
00007fdcd91e14dc  movaps xmm9, [rsp]
00007fdcd91e14e1  add rsp, 0x30
00007fdcd91e14e5  vmovaps xmm0, [rsp]
00007fdcd91e14ea  vmovaps xmm1, [rsp+0x10]
00007fdcd91e14f0  vmovaps xmm2, [rsp+0x20]
00007fdcd91e14f6  vmovaps xmm3, [rsp+0x30]
00007fdcd91e14fc  vmovaps xmm4, [rsp+0x40]
00007fdcd91e1502  vmovaps xmm5, [rsp+0x50]
00007fdcd91e1508  vmovaps xmm6, [rsp+0x60]
00007fdcd91e150e  vmovaps xmm7, [rsp+0x70]
00007fdcd91e1514  vmovaps xmm8, [rsp+0x80]
00007fdcd91e151d  vmovaps xmm10, [rsp+0x90]
00007fdcd91e1526  vmovaps xmm11, [rsp+0xA0]
00007fdcd91e152f  vmovaps xmm12, [rsp+0xB0]
00007fdcd91e1538  vmovaps xmm13, [rsp+0xC0]
00007fdcd91e1541  vmovaps xmm14, [rsp+0xD0]
00007fdcd91e154a  vmovaps xmm15, [rsp+0xE0]
00007fdcd91e1553  add rsp, 0xF0
00007fdcd91e155a  pop r11
00007fdcd91e155c  pop r10
00007fdcd91e155e  pop r9
00007fdcd91e1560  pop r8
00007fdcd91e1562  pop rsi
00007fdcd91e1563  pop rdi
00007fdcd91e1564  pop rdx
00007fdcd91e1565  pop rcx
00007fdcd91e1566  pop rax
00007fdcd91e1567  add rsp, 0x08
00007fdcd91e156b  jmp 0x00007FDCD91DC7E2
00007fdcd91e1570  sub rsp, 0x08
00007fdcd91e1574  push rax
00007fdcd91e1575  push rcx
00007fdcd91e1576  push rdx
00007fdcd91e1577  push rdi
00007fdcd91e1578  push rsi
00007fdcd91e1579  push r8
00007fdcd91e157b  push r9
00007fdcd91e157d  push r10
00007fdcd91e157f  push r11
00007fdcd91e1581  sub rsp, 0xF0
00007fdcd91e1588  vmovaps [rsp], xmm0
00007fdcd91e158d  vmovaps [rsp+0x10], xmm1
00007fdcd91e1593  vmovaps [rsp+0x20], xmm2
00007fdcd91e1599  vmovaps [rsp+0x30], xmm3
00007fdcd91e159f  vmovaps [rsp+0x40], xmm4
00007fdcd91e15a5  vmovaps [rsp+0x50], xmm5
00007fdcd91e15ab  vmovaps [rsp+0x60], xmm6
00007fdcd91e15b1  vmovaps [rsp+0x70], xmm7
00007fdcd91e15b7  vmovaps [rsp+0x80], xmm8
00007fdcd91e15c0  vmovaps [rsp+0x90], xmm9
00007fdcd91e15c9  vmovaps [rsp+0xA0], xmm10
00007fdcd91e15d2  vmovaps [rsp+0xB0], xmm11
00007fdcd91e15db  vmovaps [rsp+0xC0], xmm12
00007fdcd91e15e4  vmovaps [rsp+0xD0], xmm13
00007fdcd91e15ed  vmovaps [rsp+0xE0], xmm14
00007fdcd91e15f6  sub rsp, 0x30
00007fdcd91e15fa  movaps [rsp], xmm15
00007fdcd91e15ff  movaps [rsp+0x10], xmm11
00007fdcd91e1605  movaps [rsp+0x20], xmm12
00007fdcd91e160b  lea rdi, [rsp]
00007fdcd91e160f  mov esi, 0x00
00007fdcd91e1614  mov rax, 0x5B56EFBF3530
00007fdcd91e161e  call rax
00007fdcd91e1620  movaps xmm15, [rsp]
00007fdcd91e1625  add rsp, 0x30
00007fdcd91e1629  vmovaps xmm0, [rsp]
00007fdcd91e162e  vmovaps xmm1, [rsp+0x10]
00007fdcd91e1634  vmovaps xmm2, [rsp+0x20]
00007fdcd91e163a  vmovaps xmm3, [rsp+0x30]
00007fdcd91e1640  vmovaps xmm4, [rsp+0x40]
00007fdcd91e1646  vmovaps xmm5, [rsp+0x50]
00007fdcd91e164c  vmovaps xmm6, [rsp+0x60]
00007fdcd91e1652  vmovaps xmm7, [rsp+0x70]
00007fdcd91e1658  vmovaps xmm8, [rsp+0x80]
00007fdcd91e1661  vmovaps xmm9, [rsp+0x90]
00007fdcd91e166a  vmovaps xmm10, [rsp+0xA0]
00007fdcd91e1673  vmovaps xmm11, [rsp+0xB0]
00007fdcd91e167c  vmovaps xmm12, [rsp+0xC0]
00007fdcd91e1685  vmovaps xmm13, [rsp+0xD0]
00007fdcd91e168e  vmovaps xmm14, [rsp+0xE0]
00007fdcd91e1697  add rsp, 0xF0
00007fdcd91e169e  pop r11
00007fdcd91e16a0  pop r10
00007fdcd91e16a2  pop r9
00007fdcd91e16a4  pop r8
00007fdcd91e16a6  pop rsi
00007fdcd91e16a7  pop rdi
00007fdcd91e16a8  pop rdx
00007fdcd91e16a9  pop rcx
00007fdcd91e16aa  pop rax
00007fdcd91e16ab  add rsp, 0x08
00007fdcd91e16af  jmp 0x00007FDCD91DC7FD
00007fdcd91e16b4  sub rsp, 0x08
00007fdcd91e16b8  push rax
00007fdcd91e16b9  push rcx
00007fdcd91e16ba  push rdx
00007fdcd91e16bb  push rdi
00007fdcd91e16bc  push rsi
00007fdcd91e16bd  push r8
00007fdcd91e16bf  push r9
00007fdcd91e16c1  push r10
00007fdcd91e16c3  push r11
00007fdcd91e16c5  sub rsp, 0xF0
00007fdcd91e16cc  vmovaps [rsp], xmm0
00007fdcd91e16d1  vmovaps [rsp+0x10], xmm1
00007fdcd91e16d7  vmovaps [rsp+0x20], xmm2
00007fdcd91e16dd  vmovaps [rsp+0x30], xmm3
00007fdcd91e16e3  vmovaps [rsp+0x40], xmm4
00007fdcd91e16e9  vmovaps [rsp+0x50], xmm5
00007fdcd91e16ef  vmovaps [rsp+0x60], xmm6
00007fdcd91e16f5  vmovaps [rsp+0x70], xmm7
00007fdcd91e16fb  vmovaps [rsp+0x80], xmm8
00007fdcd91e1704  vmovaps [rsp+0x90], xmm9
00007fdcd91e170d  vmovaps [rsp+0xA0], xmm10
00007fdcd91e1716  vmovaps [rsp+0xB0], xmm11
00007fdcd91e171f  vmovaps [rsp+0xC0], xmm12
00007fdcd91e1728  vmovaps [rsp+0xD0], xmm14
00007fdcd91e1731  vmovaps [rsp+0xE0], xmm15
00007fdcd91e173a  sub rsp, 0x30
00007fdcd91e173e  movaps [rsp], xmm13
00007fdcd91e1743  movaps [rsp+0x10], xmm10
00007fdcd91e1749  movaps [rsp+0x20], xmm14
00007fdcd91e174f  lea rdi, [rsp]
00007fdcd91e1753  mov esi, 0x00
00007fdcd91e1758  mov rax, 0x5B56EFBF3530
00007fdcd91e1762  call rax
00007fdcd91e1764  movaps xmm13, [rsp]
00007fdcd91e1769  add rsp, 0x30
00007fdcd91e176d  vmovaps xmm0, [rsp]
00007fdcd91e1772  vmovaps xmm1, [rsp+0x10]
00007fdcd91e1778  vmovaps xmm2, [rsp+0x20]
00007fdcd91e177e  vmovaps xmm3, [rsp+0x30]
00007fdcd91e1784  vmovaps xmm4, [rsp+0x40]
00007fdcd91e178a  vmovaps xmm5, [rsp+0x50]
00007fdcd91e1790  vmovaps xmm6, [rsp+0x60]
00007fdcd91e1796  vmovaps xmm7, [rsp+0x70]
00007fdcd91e179c  vmovaps xmm8, [rsp+0x80]
00007fdcd91e17a5  vmovaps xmm9, [rsp+0x90]
00007fdcd91e17ae  vmovaps xmm10, [rsp+0xA0]
00007fdcd91e17b7  vmovaps xmm11, [rsp+0xB0]
00007fdcd91e17c0  vmovaps xmm12, [rsp+0xC0]
00007fdcd91e17c9  vmovaps xmm14, [rsp+0xD0]
00007fdcd91e17d2  vmovaps xmm15, [rsp+0xE0]
00007fdcd91e17db  add rsp, 0xF0
00007fdcd91e17e2  pop r11
00007fdcd91e17e4  pop r10
00007fdcd91e17e6  pop r9
00007fdcd91e17e8  pop r8
00007fdcd91e17ea  pop rsi
00007fdcd91e17eb  pop rdi
00007fdcd91e17ec  pop rdx
00007fdcd91e17ed  pop rcx
00007fdcd91e17ee  pop rax
00007fdcd91e17ef  add rsp, 0x08
00007fdcd91e17f3  jmp 0x00007FDCD91DC820
00007fdcd91e17f8  sub rsp, 0x08
00007fdcd91e17fc  push rax
00007fdcd91e17fd  push rcx
00007fdcd91e17fe  push rdx
00007fdcd91e17ff  push rdi
00007fdcd91e1800  push rsi
00007fdcd91e1801  push r8
00007fdcd91e1803  push r9
00007fdcd91e1805  push r10
00007fdcd91e1807  push r11
00007fdcd91e1809  sub rsp, 0xF0
00007fdcd91e1810  vmovaps [rsp], xmm0
00007fdcd91e1815  vmovaps [rsp+0x10], xmm1
00007fdcd91e181b  vmovaps [rsp+0x20], xmm2
00007fdcd91e1821  vmovaps [rsp+0x30], xmm3
00007fdcd91e1827  vmovaps [rsp+0x40], xmm4
00007fdcd91e182d  vmovaps [rsp+0x50], xmm5
00007fdcd91e1833  vmovaps [rsp+0x60], xmm6
00007fdcd91e1839  vmovaps [rsp+0x70], xmm7
00007fdcd91e183f  vmovaps [rsp+0x80], xmm8
00007fdcd91e1848  vmovaps [rsp+0x90], xmm9
00007fdcd91e1851  vmovaps [rsp+0xA0], xmm10
00007fdcd91e185a  vmovaps [rsp+0xB0], xmm11
00007fdcd91e1863  vmovaps [rsp+0xC0], xmm12
00007fdcd91e186c  vmovaps [rsp+0xD0], xmm13
00007fdcd91e1875  vmovaps [rsp+0xE0], xmm15
00007fdcd91e187e  sub rsp, 0x30
00007fdcd91e1882  movaps [rsp], xmm14
00007fdcd91e1887  movaps [rsp+0x10], xmm1
00007fdcd91e188c  movaps [rsp+0x20], xmm7
00007fdcd91e1891  lea rdi, [rsp]
00007fdcd91e1895  mov esi, 0x00
00007fdcd91e189a  mov rax, 0x5B56EFBF3530
00007fdcd91e18a4  call rax
00007fdcd91e18a6  movaps xmm14, [rsp]
00007fdcd91e18ab  add rsp, 0x30
00007fdcd91e18af  vmovaps xmm0, [rsp]
00007fdcd91e18b4  vmovaps xmm1, [rsp+0x10]
00007fdcd91e18ba  vmovaps xmm2, [rsp+0x20]
00007fdcd91e18c0  vmovaps xmm3, [rsp+0x30]
00007fdcd91e18c6  vmovaps xmm4, [rsp+0x40]
00007fdcd91e18cc  vmovaps xmm5, [rsp+0x50]
00007fdcd91e18d2  vmovaps xmm6, [rsp+0x60]
00007fdcd91e18d8  vmovaps xmm7, [rsp+0x70]
00007fdcd91e18de  vmovaps xmm8, [rsp+0x80]
00007fdcd91e18e7  vmovaps xmm9, [rsp+0x90]
00007fdcd91e18f0  vmovaps xmm10, [rsp+0xA0]
00007fdcd91e18f9  vmovaps xmm11, [rsp+0xB0]
00007fdcd91e1902  vmovaps xmm12, [rsp+0xC0]
00007fdcd91e190b  vmovaps xmm13, [rsp+0xD0]
00007fdcd91e1914  vmovaps xmm15, [rsp+0xE0]
00007fdcd91e191d  add rsp, 0xF0
00007fdcd91e1924  pop r11
00007fdcd91e1926  pop r10
00007fdcd91e1928  pop r9
00007fdcd91e192a  pop r8
00007fdcd91e192c  pop rsi
00007fdcd91e192d  pop rdi
00007fdcd91e192e  pop rdx
00007fdcd91e192f  pop rcx
00007fdcd91e1930  pop rax
00007fdcd91e1931  add rsp, 0x08
00007fdcd91e1935  jmp 0x00007FDCD91DC843
00007fdcd91e193a  sub rsp, 0x08
00007fdcd91e193e  push rax
00007fdcd91e193f  push rcx
00007fdcd91e1940  push rdx
00007fdcd91e1941  push rdi
00007fdcd91e1942  push rsi
00007fdcd91e1943  push r8
00007fdcd91e1945  push r9
00007fdcd91e1947  push r10
00007fdcd91e1949  push r11
00007fdcd91e194b  sub rsp, 0xF0
00007fdcd91e1952  vmovaps [rsp], xmm0
00007fdcd91e1957  vmovaps [rsp+0x10], xmm2
00007fdcd91e195d  vmovaps [rsp+0x20], xmm3
00007fdcd91e1963  vmovaps [rsp+0x30], xmm4
00007fdcd91e1969  vmovaps [rsp+0x40], xmm5
00007fdcd91e196f  vmovaps [rsp+0x50], xmm6
00007fdcd91e1975  vmovaps [rsp+0x60], xmm7
00007fdcd91e197b  vmovaps [rsp+0x70], xmm8
00007fdcd91e1981  vmovaps [rsp+0x80], xmm9
00007fdcd91e198a  vmovaps [rsp+0x90], xmm10
00007fdcd91e1993  vmovaps [rsp+0xA0], xmm11
00007fdcd91e199c  vmovaps [rsp+0xB0], xmm12
00007fdcd91e19a5  vmovaps [rsp+0xC0], xmm13
00007fdcd91e19ae  vmovaps [rsp+0xD0], xmm14
00007fdcd91e19b7  vmovaps [rsp+0xE0], xmm15
00007fdcd91e19c0  sub rsp, 0x30
00007fdcd91e19c4  movaps [rsp], xmm1
00007fdcd91e19c8  movaps [rsp+0x10], xmm8
00007fdcd91e19ce  movaps [rsp+0x20], xmm9
00007fdcd91e19d4  lea rdi, [rsp]
00007fdcd91e19d8  mov esi, 0x00
00007fdcd91e19dd  mov rax, 0x5B56EFBF3530
00007fdcd91e19e7  call rax
00007fdcd91e19e9  movaps xmm1, [rsp]
00007fdcd91e19ed  add rsp, 0x30
00007fdcd91e19f1  vmovaps xmm0, [rsp]
00007fdcd91e19f6  vmovaps xmm2, [rsp+0x10]
00007fdcd91e19fc  vmovaps xmm3, [rsp+0x20]
00007fdcd91e1a02  vmovaps xmm4, [rsp+0x30]
00007fdcd91e1a08  vmovaps xmm5, [rsp+0x40]
00007fdcd91e1a0e  vmovaps xmm6, [rsp+0x50]
00007fdcd91e1a14  vmovaps xmm7, [rsp+0x60]
00007fdcd91e1a1a  vmovaps xmm8, [rsp+0x70]
00007fdcd91e1a20  vmovaps xmm9, [rsp+0x80]
00007fdcd91e1a29  vmovaps xmm10, [rsp+0x90]
00007fdcd91e1a32  vmovaps xmm11, [rsp+0xA0]
00007fdcd91e1a3b  vmovaps xmm12, [rsp+0xB0]
00007fdcd91e1a44  vmovaps xmm13, [rsp+0xC0]
00007fdcd91e1a4d  vmovaps xmm14, [rsp+0xD0]
00007fdcd91e1a56  vmovaps xmm15, [rsp+0xE0]
00007fdcd91e1a5f  add rsp, 0xF0
00007fdcd91e1a66  pop r11
00007fdcd91e1a68  pop r10
00007fdcd91e1a6a  pop r9
00007fdcd91e1a6c  pop r8
00007fdcd91e1a6e  pop rsi
00007fdcd91e1a6f  pop rdi
00007fdcd91e1a70  pop rdx
00007fdcd91e1a71  pop rcx
00007fdcd91e1a72  pop rax
00007fdcd91e1a73  add rsp, 0x08
00007fdcd91e1a77  jmp 0x00007FDCD91DC865
00007fdcd91e1a7c  call 0x00007FDCD90E5940
00007fdcd91e1a81  jmp 0x00007FDCD91DC873
00007fdcd91e1a86  call 0x00007FDCD900C380
00007fdcd91e1a8b  jmp 0x00007FDCD91DC87D
00007fdcd91e1a90  call 0x00007FDCD900D600
00007fdcd91e1a95  jmp 0x00007FDCD91DC887
00007fdcd91e1a9a  call 0x00007FDCD8FFF540
00007fdcd91e1a9f  jmp 0x00007FDCD91DC891
00007fdcd91e1aa4  int3
00007fdcd91e1aa5  nop [rax+rax*1], ax
00007fdcd91e1aae  nop
00007fdcd91e1ab0  mov rax, [r15+0xF8]
00007fdcd91e1ab7  lea r14, [rax+0x140]
00007fdcd91e1abe  mov r12, [r13+r14*1]
00007fdcd91e1ac3  mov [r15+0xE8], r12
00007fdcd91e1aca  lea r14, [rax+0x130]
00007fdcd91e1ad1  mov r12, [r13+r14*1]
00007fdcd91e1ad6  lea r14, [rax+0x138]
00007fdcd91e1add  mov r11, [r13+r14*1]
00007fdcd91e1ae2  movq xmm1, r12
00007fdcd91e1ae7  movq xmm15, r11
00007fdcd91e1aec  movq xmm1, xmm1
00007fdcd91e1af0  movq xmm1, xmm1
00007fdcd91e1af4  movaps [r15+0x1A0], xmm1
00007fdcd91e1afc  movq xmm15, xmm15
00007fdcd91e1b01  movq xmm15, xmm15
00007fdcd91e1b06  movaps [r15+0x190], xmm15
00007fdcd91e1b0e  lea r14, [rax+0x120]
00007fdcd91e1b15  mov r12, [r13+r14*1]
00007fdcd91e1b1a  lea r14, [rax+0x128]
00007fdcd91e1b21  mov r11, [r13+r14*1]
00007fdcd91e1b26  movq xmm1, r12
00007fdcd91e1b2b  movq xmm15, r11
00007fdcd91e1b30  movq xmm1, xmm1
00007fdcd91e1b34  movq xmm1, xmm1
00007fdcd91e1b38  movaps [r15+0x1C0], xmm1
00007fdcd91e1b40  movq xmm15, xmm15
00007fdcd91e1b45  movq xmm15, xmm15
00007fdcd91e1b4a  movaps [r15+0x1B0], xmm15
00007fdcd91e1b52  lea r14, [rax+0x110]
00007fdcd91e1b59  mov r12, [r13+r14*1]
00007fdcd91e1b5e  lea r14, [rax+0x118]
00007fdcd91e1b65  mov r11, [r13+r14*1]
00007fdcd91e1b6a  movq xmm1, r12
00007fdcd91e1b6f  movq xmm15, r11
00007fdcd91e1b74  movq xmm1, xmm1
00007fdcd91e1b78  movq xmm1, xmm1
00007fdcd91e1b7c  movaps [r15+0x1E0], xmm1
00007fdcd91e1b84  movq xmm15, xmm15
00007fdcd91e1b89  movq xmm15, xmm15
00007fdcd91e1b8e  movaps [r15+0x1D0], xmm15
00007fdcd91e1b96  lea r14, [rax+0x100]
00007fdcd91e1b9d  mov r12, [r13+r14*1]
00007fdcd91e1ba2  lea r14, [rax+0x108]
00007fdcd91e1ba9  mov r11, [r13+r14*1]
00007fdcd91e1bae  movq xmm1, r12
00007fdcd91e1bb3  movq xmm15, r11
00007fdcd91e1bb8  movq xmm1, xmm1
00007fdcd91e1bbc  movq xmm1, xmm1
00007fdcd91e1bc0  movaps [r15+0x200], xmm1
00007fdcd91e1bc8  movq xmm15, xmm15
00007fdcd91e1bcd  movq xmm15, xmm15
00007fdcd91e1bd2  movaps [r15+0x1F0], xmm15
00007fdcd91e1bda  mov qword ptr [r15+0x40], 0x430000
00007fdcd91e1be2  mov r14d, 0x430510
00007fdcd91e1be8  mov r12, [r13+r14*1]
00007fdcd91e1bed  movq xmm1, r12
00007fdcd91e1bf2  lea r14, [rax+0x150]
00007fdcd91e1bf9  mov [r15+0xF8], r14
00007fdcd91e1c00  mov rax, [r15+0x50]
00007fdcd91e1c04  movups xmm15, [r13+rax*1]
00007fdcd91e1c0a  movaps [r15+0x120], xmm15
00007fdcd91e1c12  mov qword ptr [r15+0x48], 0x10
00007fdcd91e1c1a  xor eax, eax
00007fdcd91e1c1c  mov r14d, 0x10
00007fdcd91e1c22  mov r12d, 0x200
00007fdcd91e1c28  cmp r14, r12
00007fdcd91e1c2b  cmc
00007fdcd91e1c2c  lahf
00007fdcd91e1c2d  seto al
00007fdcd91e1c30  mov [r15+0x108], eax
00007fdcd91e1c37  pextrq rax, xmm15, 0x01
00007fdcd91e1c3e  movq xmm14, rax
00007fdcd91e1c43  movaps [r15+0x130], xmm14
00007fdcd91e1c4b  movq rax, xmm1
00007fdcd91e1c50  movq r14, xmm15
00007fdcd91e1c55  vmovq xmm1, rax
00007fdcd91e1c5a  vmovq xmm15, r14
00007fdcd91e1c5f  movaps xmm13, xmm1
00007fdcd91e1c63  addsd xmm13, xmm15
00007fdcd91e1c68  ucomisd xmm13, xmm13
00007fdcd91e1c6d  jp 0x00007FDCD91E1D86
00007fdcd91e1c73  movq xmm13, xmm13
00007fdcd91e1c78  movq rax, xmm13
00007fdcd91e1c7d  movq r14, xmm14
00007fdcd91e1c82  vmovq xmm1, rax
00007fdcd91e1c87  vmovq xmm15, r14
00007fdcd91e1c8c  movaps xmm14, xmm1
00007fdcd91e1c90  addsd xmm14, xmm15
00007fdcd91e1c95  ucomisd xmm14, xmm14
00007fdcd91e1c9a  jp 0x00007FDCD91E1DCE
00007fdcd91e1ca0  movq xmm14, xmm14
00007fdcd91e1ca5  movaps [r15+0x110], xmm14
00007fdcd91e1cad  mov eax, [r15+0x108]
00007fdcd91e1cb4  sahf
00007fdcd91e1cb5  jnz 0x00007FDCD91E1CE7
00007fdcd91e1cb7  cmp dword ptr [r15+0x318], 0x00
00007fdcd91e1cbf  jz 0x00007FDCD91E1FE0
00007fdcd91e1cc5  nop [rax+rax*1], ax
00007fdcd91e1cce  nop [rax+rax*1], eax
00007fdcd91e1cd6  mov eax, 0x410490
00007fdcd91e1cdb  mov [r15+0x100], rax
00007fdcd91e1ce2  jmp 0x00007FDCD8FFE110
00007fdcd91e1ce7  cmp dword ptr [r15+0x318], 0x00
00007fdcd91e1cef  jz 0x00007FDCD91E1E20
00007fdcd91e1cf5  nop [rax+rax*1], ax
00007fdcd91e1cfe  nop [rax+rax*1], eax
00007fdcd91e1d06  mov eax, 0x410474
00007fdcd91e1d0b  mov [r15+0x100], rax
00007fdcd91e1d12  jmp 0x00007FDCD8FFE110
00007fdcd91e1d17  int3
00007fdcd91e1d18  call 0x00007FDCD90E27E0
00007fdcd91e1d1d  jmp 0x00007FDCD91E1AC3
00007fdcd91e1d22  call 0x00007FDCD90E27E0
00007fdcd91e1d27  jmp 0x00007FDCD91E1AD6
00007fdcd91e1d2c  call 0x00007FDCD90E1570
00007fdcd91e1d31  jmp 0x00007FDCD91E1AE2
00007fdcd91e1d36  call 0x00007FDCD90E27E0
00007fdcd91e1d3b  jmp 0x00007FDCD91E1B1A
00007fdcd91e1d40  call 0x00007FDCD90E1570
00007fdcd91e1d45  jmp 0x00007FDCD91E1B26
00007fdcd91e1d4a  call 0x00007FDCD90E27E0
00007fdcd91e1d4f  jmp 0x00007FDCD91E1B5E
00007fdcd91e1d54  call 0x00007FDCD90E1570
00007fdcd91e1d59  jmp 0x00007FDCD91E1B6A
00007fdcd91e1d5e  call 0x00007FDCD90E27E0
00007fdcd91e1d63  jmp 0x00007FDCD91E1BA2
00007fdcd91e1d68  call 0x00007FDCD90E1570
00007fdcd91e1d6d  jmp 0x00007FDCD91E1BAE
00007fdcd91e1d72  call 0x00007FDCD90E27E0
00007fdcd91e1d77  jmp 0x00007FDCD91E1BED
00007fdcd91e1d7c  call 0x00007FDCD900E760
00007fdcd91e1d81  jmp 0x00007FDCD91E1C0A
00007fdcd91e1d86  ucomisd xmm1, xmm15
00007fdcd91e1d8b  jp 0x00007FDCD91E1D9A
00007fdcd91e1d8d  movaps xmm13, [0x00007FDCD8DFE060]
00007fdcd91e1d95  jmp 0x00007FDCD91E1C73
00007fdcd91e1d9a  vxorps xmm0, xmm1, xmm15
00007fdcd91e1d9f  pextrw eax, xmm0, 0x03
00007fdcd91e1da4  and eax, 0x7FF8
00007fdcd91e1da9  cmp eax, 0x08
00007fdcd91e1dac  jnz 0x00007FDCD91E1C73
00007fdcd91e1db2  movq rax, xmm15
00007fdcd91e1db7  shl rax, 0x0D
00007fdcd91e1dbb  jbe 0x00007FDCD91E1C73
00007fdcd91e1dc1  vorps xmm13, xmm15, [0x00007FDCD8DFE070]
00007fdcd91e1dc9  jmp 0x00007FDCD91E1C73
00007fdcd91e1dce  ucomisd xmm1, xmm15
00007fdcd91e1dd3  jp 0x00007FDCD91E1DE2
00007fdcd91e1dd5  movaps xmm14, [0x00007FDCD8DFE060]
00007fdcd91e1ddd  jmp 0x00007FDCD91E1CA0
00007fdcd91e1de2  vxorps xmm0, xmm1, xmm15
00007fdcd91e1de7  pextrw eax, xmm0, 0x03
00007fdcd91e1dec  and eax, 0x7FF8
00007fdcd91e1df1  cmp eax, 0x08
00007fdcd91e1df4  jnz 0x00007FDCD91E1CA0
00007fdcd91e1dfa  movq rax, xmm15
00007fdcd91e1dff  shl rax, 0x0D
00007fdcd91e1e03  jbe 0x00007FDCD91E1CA0
00007fdcd91e1e09  vorps xmm14, xmm15, [0x00007FDCD8DFE070]
00007fdcd91e1e11  jmp 0x00007FDCD91E1CA0
00007fdcd91e1e16  int3
00007fdcd91e1e17  nop [rax+rax*1], ax
00007fdcd91e1e20  mov rax, [r15+0x48]
00007fdcd91e1e24  mov r14, [r15+0x50]
00007fdcd91e1e28  lea r12, [r14+rax*1]
00007fdcd91e1e2c  movups xmm1, [r13+r12*1]
00007fdcd91e1e32  movaps [r15+0x120], xmm1
00007fdcd91e1e3a  lea r14, [rax+0x10]
00007fdcd91e1e3e  mov [r15+0x48], r14
00007fdcd91e1e42  xor eax, eax
00007fdcd91e1e44  mov r12d, 0x200
00007fdcd91e1e4a  cmp r14, r12
00007fdcd91e1e4d  cmc
00007fdcd91e1e4e  lahf
00007fdcd91e1e4f  seto al
00007fdcd91e1e52  mov [r15+0x108], eax
00007fdcd91e1e59  pextrq rax, xmm1, 0x01
00007fdcd91e1e60  movq xmm15, rax
00007fdcd91e1e65  movaps [r15+0x130], xmm15
00007fdcd91e1e6d  movaps xmm14, [r15+0x110]
00007fdcd91e1e75  movq rax, xmm14
00007fdcd91e1e7a  movq r14, xmm1
00007fdcd91e1e7f  vmovq xmm1, rax
00007fdcd91e1e84  vmovq xmm14, r14
00007fdcd91e1e89  movaps xmm13, xmm1
00007fdcd91e1e8d  addsd xmm13, xmm14
00007fdcd91e1e92  ucomisd xmm13, xmm13
00007fdcd91e1e97  jp 0x00007FDCD91E1F4C
00007fdcd91e1e9d  movq xmm13, xmm13
00007fdcd91e1ea2  movq rax, xmm13
00007fdcd91e1ea7  movq r14, xmm15
00007fdcd91e1eac  vmovq xmm1, rax
00007fdcd91e1eb1  vmovq xmm15, r14
00007fdcd91e1eb6  movaps xmm14, xmm1
00007fdcd91e1eba  addsd xmm14, xmm15
00007fdcd91e1ebf  ucomisd xmm14, xmm14
00007fdcd91e1ec4  jp 0x00007FDCD91E1F94
00007fdcd91e1eca  movq xmm14, xmm14
00007fdcd91e1ecf  movaps [r15+0x110], xmm14
00007fdcd91e1ed7  mov eax, [r15+0x108]
00007fdcd91e1ede  sahf
00007fdcd91e1edf  jnz 0x00007FDCD91E1F11
00007fdcd91e1ee1  cmp dword ptr [r15+0x318], 0x00
00007fdcd91e1ee9  jz 0x00007FDCD91E1FE0
00007fdcd91e1eef  nop [rax+rax*1], ax
00007fdcd91e1ef8  nop [rax+rax*1], eax
00007fdcd91e1f00  mov eax, 0x410490
00007fdcd91e1f05  mov [r15+0x100], rax
00007fdcd91e1f0c  jmp 0x00007FDCD8FFE110
00007fdcd91e1f11  cmp dword ptr [r15+0x318], 0x00
00007fdcd91e1f19  jz 0x00007FDCD91E1E20
00007fdcd91e1f1f  nop [rax+rax*1], ax
00007fdcd91e1f28  nop [rax+rax*1], eax
00007fdcd91e1f30  mov eax, 0x410474
00007fdcd91e1f35  mov [r15+0x100], rax
00007fdcd91e1f3c  jmp 0x00007FDCD8FFE110
00007fdcd91e1f41  int3
00007fdcd91e1f42  call 0x00007FDCD90B52F0
00007fdcd91e1f47  jmp 0x00007FDCD91E1E32
00007fdcd91e1f4c  ucomisd xmm1, xmm14
00007fdcd91e1f51  jp 0x00007FDCD91E1F60
00007fdcd91e1f53  movaps xmm13, [0x00007FDCD8DFE060]
00007fdcd91e1f5b  jmp 0x00007FDCD91E1E9D
00007fdcd91e1f60  vxorps xmm0, xmm1, xmm14
00007fdcd91e1f65  pextrw eax, xmm0, 0x03
00007fdcd91e1f6a  and eax, 0x7FF8
00007fdcd91e1f6f  cmp eax, 0x08
00007fdcd91e1f72  jnz 0x00007FDCD91E1E9D
00007fdcd91e1f78  movq rax, xmm14
00007fdcd91e1f7d  shl rax, 0x0D
00007fdcd91e1f81  jbe 0x00007FDCD91E1E9D
00007fdcd91e1f87  vorps xmm13, xmm14, [0x00007FDCD8DFE070]
00007fdcd91e1f8f  jmp 0x00007FDCD91E1E9D
00007fdcd91e1f94  ucomisd xmm1, xmm15
00007fdcd91e1f99  jp 0x00007FDCD91E1FA8
00007fdcd91e1f9b  movaps xmm14, [0x00007FDCD8DFE060]
00007fdcd91e1fa3  jmp 0x00007FDCD91E1ECA
00007fdcd91e1fa8  vxorps xmm0, xmm1, xmm15
00007fdcd91e1fad  pextrw eax, xmm0, 0x03
00007fdcd91e1fb2  and eax, 0x7FF8
00007fdcd91e1fb7  cmp eax, 0x08
00007fdcd91e1fba  jnz 0x00007FDCD91E1ECA
00007fdcd91e1fc0  movq rax, xmm15
00007fdcd91e1fc5  shl rax, 0x0D
00007fdcd91e1fc9  jbe 0x00007FDCD91E1ECA
00007fdcd91e1fcf  vorps xmm14, xmm15, [0x00007FDCD8DFE070]
00007fdcd91e1fd7  jmp 0x00007FDCD91E1ECA
00007fdcd91e1fdc  int3
00007fdcd91e1fdd  nop [rax], eax
00007fdcd91e1fe0  mov rax, [r15+0x40]
00007fdcd91e1fe4  lea r14, [rax+0x510]
00007fdcd91e1feb  movaps xmm1, [r15+0x110]
00007fdcd91e1ff3  movq rax, xmm1
00007fdcd91e1ff8  mov [r13+r14*1], rax
00007fdcd91e1ffd  mov rax, [r15+0xF0]
00007fdcd91e2004  mov [r15+0x100], rax
00007fdcd91e200b  jmp 0x00007FDCD91CE5C0
00007fdcd91e2010  int3
00007fdcd91e2011  call 0x00007FDCD90D5EB0
00007fdcd91e2016  jmp 0x00007FDCD91E1FFD
00007fdcd91e201b  int3
00007fdcd91e201c  nop [rax], eax
00007fdcd91e2020  mov qword ptr [r15+0x100], 0x04
00007fdcd91e202b  mov esi, 0x00
00007fdcd91e2030  mov edx, 0x09
00007fdcd91e2035  mov rdi, 0x7FFCC729D600
00007fdcd91e203f  mov rax, 0x5B56EFA86970
00007fdcd91e2049  call rax
00007fdcd91e204b  cmp dword ptr [r15+0x318], 0x00
00007fdcd91e2053  jnz 0x00007FDCD8FFE110
00007fdcd91e2059  jmp 0x00007FDCD8FFE0A0
00007fdcd91e205e  int3
00007fdcd91e205f  int3
