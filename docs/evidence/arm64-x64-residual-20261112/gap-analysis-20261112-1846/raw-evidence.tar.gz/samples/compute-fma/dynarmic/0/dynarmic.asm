0000713aae5ce69b  nop [rax+rax*1], eax
0000713aae5ce6a0  mov rax, [r15+0xF8]
0000713aae5ce6a7  lea r14, [rax-0x1B0]
0000713aae5ce6ae  mov [r15+0xF8], r14
0000713aae5ce6b5  lea rax, [r14+0x1A0]
0000713aae5ce6bc  mov r12, [r15+0xA0]
0000713aae5ce6c3  mov r11, [r15+0x98]
0000713aae5ce6ca  mov [r13+rax*1], r12
0000713aae5ce6cf  lea rax, [r14+0x1A8]
0000713aae5ce6d6  mov [r13+rax*1], r11
0000713aae5ce6db  mov eax, 0x420A30
0000713aae5ce6e0  movups xmm1, [r13+rax*1]
0000713aae5ce6e6  mov eax, 0x4209C0
0000713aae5ce6eb  movups xmm15, [r13+rax*1]
0000713aae5ce6f1  mov eax, 0x420A50
0000713aae5ce6f6  movups xmm14, [r13+rax*1]
0000713aae5ce6fc  mov eax, 0x4209F0
0000713aae5ce701  movups xmm13, [r13+rax*1]
0000713aae5ce707  mov qword ptr [r15+0x98], 0x430C60
0000713aae5ce712  mov eax, 0x420A60
0000713aae5ce717  movups xmm12, [r13+rax*1]
0000713aae5ce71d  mov eax, 0x430C60
0000713aae5ce722  movups [r13+rax*1], xmm1
0000713aae5ce728  mov eax, 0x430C70
0000713aae5ce72d  movups [r13+rax*1], xmm15
0000713aae5ce733  mov eax, 0x430C80
0000713aae5ce738  movups [r13+rax*1], xmm14
0000713aae5ce73e  mov eax, 0x430C90
0000713aae5ce743  movups [r13+rax*1], xmm13
0000713aae5ce749  mov eax, 0x4209B0
0000713aae5ce74e  movups xmm14, [r13+rax*1]
0000713aae5ce754  mov eax, 0x4209A0
0000713aae5ce759  movups xmm13, [r13+rax*1]
0000713aae5ce75f  mov eax, 0x430D60
0000713aae5ce764  movups [r13+rax*1], xmm1
0000713aae5ce76a  mov eax, 0x430D70
0000713aae5ce76f  movups [r13+rax*1], xmm15
0000713aae5ce775  mov eax, 0x430CA0
0000713aae5ce77a  movups [r13+rax*1], xmm12
0000713aae5ce780  mov eax, 0x430CB0
0000713aae5ce785  movups [r13+rax*1], xmm14
0000713aae5ce78b  mov eax, 0x420990
0000713aae5ce790  movups xmm1, [r13+rax*1]
0000713aae5ce796  mov eax, 0x420A00
0000713aae5ce79b  movups xmm15, [r13+rax*1]
0000713aae5ce7a1  mov eax, 0x430CC0
0000713aae5ce7a6  movups [r13+rax*1], xmm13
0000713aae5ce7ac  mov eax, 0x430CD0
0000713aae5ce7b1  movups [r13+rax*1], xmm1
0000713aae5ce7b7  mov eax, 0x420A10
0000713aae5ce7bc  movups xmm1, [r13+rax*1]
0000713aae5ce7c2  mov eax, 0x4209E0
0000713aae5ce7c7  movups xmm14, [r13+rax*1]
0000713aae5ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
0000713aae5ce7d5  mov eax, 0x430CE0
0000713aae5ce7da  movups [r13+rax*1], xmm15
0000713aae5ce7e0  mov eax, 0x430CF0
0000713aae5ce7e5  movups [r13+rax*1], xmm1
0000713aae5ce7eb  mov eax, 0x420A80
0000713aae5ce7f0  movups xmm1, [r13+rax*1]
0000713aae5ce7f6  mov eax, 0x420A90
0000713aae5ce7fb  movups xmm15, [r13+rax*1]
0000713aae5ce801  movaps [r15+0x150], xmm15
0000713aae5ce809  mov qword ptr [r15+0xA0], 0x3E8
0000713aae5ce814  mov eax, 0x430D00
0000713aae5ce819  movups [r13+rax*1], xmm14
0000713aae5ce81f  mov eax, 0x430D10
0000713aae5ce824  movups [r13+rax*1], xmm1
0000713aae5ce82a  mov eax, 0x420A70
0000713aae5ce82f  movups xmm1, [r13+rax*1]
0000713aae5ce835  mov eax, 0x420A20
0000713aae5ce83a  movups xmm14, [r13+rax*1]
0000713aae5ce840  movaps [r15+0x140], xmm14
0000713aae5ce848  lea rax, [r14+0x150]
0000713aae5ce84f  movq xmm13, qword ptr [r15+0x200]
0000713aae5ce858  movq xmm12, qword ptr [r15+0x1F0]
0000713aae5ce861  movq r12, xmm13
0000713aae5ce866  movq r11, xmm12
0000713aae5ce86b  mov [r13+rax*1], r12
0000713aae5ce870  lea rax, [r14+0x158]
0000713aae5ce877  mov [r13+rax*1], r11
0000713aae5ce87c  mov eax, 0x430D20
0000713aae5ce881  movups [r13+rax*1], xmm15
0000713aae5ce887  mov eax, 0x430D30
0000713aae5ce88c  movups [r13+rax*1], xmm1
0000713aae5ce892  mov eax, 0x420A40
0000713aae5ce897  movups xmm1, [r13+rax*1]
0000713aae5ce89d  mov eax, 0x420AA8
0000713aae5ce8a2  mov r12, [r13+rax*1]
0000713aae5ce8a7  movq xmm15, r12
0000713aae5ce8ac  mov qword ptr [r15+0x40], 0x420AB0
0000713aae5ce8b4  mov eax, 0x430D40
0000713aae5ce8b9  movups [r13+rax*1], xmm14
0000713aae5ce8bf  mov eax, 0x430D50
0000713aae5ce8c4  movups [r13+rax*1], xmm1
0000713aae5ce8ca  mov eax, 0x420B10
0000713aae5ce8cf  movups xmm1, [r13+rax*1]
0000713aae5ce8d5  movq rax, xmm15
0000713aae5ce8da  mov r12d, 0x430D80
0000713aae5ce8e0  mov [r13+r12*1], rax
0000713aae5ce8e5  mov eax, 0x420AF0
0000713aae5ce8ea  movups xmm15, [r13+rax*1]
0000713aae5ce8f0  mov eax, 0x420B00
0000713aae5ce8f5  movups xmm14, [r13+rax*1]
0000713aae5ce8fb  lea rax, [r14+0x130]
0000713aae5ce902  movups [r13+rax*1], xmm1
0000713aae5ce908  lea rax, [r14+0x160]
0000713aae5ce90f  movq xmm1, qword ptr [r15+0x1E0]
0000713aae5ce918  movq xmm13, qword ptr [r15+0x1D0]
0000713aae5ce921  movq r12, xmm1
0000713aae5ce926  movq r11, xmm13
0000713aae5ce92b  mov [r13+rax*1], r12
0000713aae5ce930  lea rax, [r14+0x168]
0000713aae5ce937  mov [r13+rax*1], r11
0000713aae5ce93c  lea rax, [r14+0x110]
0000713aae5ce943  movups [r13+rax*1], xmm15
0000713aae5ce949  lea rax, [r14+0x120]
0000713aae5ce950  movups [r13+rax*1], xmm14
0000713aae5ce956  mov eax, 0x420AB0
0000713aae5ce95b  movups xmm1, [r13+rax*1]
0000713aae5ce961  mov eax, 0x420AC0
0000713aae5ce966  movups xmm15, [r13+rax*1]
0000713aae5ce96c  movaps [r15+0x120], xmm15
0000713aae5ce974  lea rax, [r14+0x170]
0000713aae5ce97b  movq xmm14, qword ptr [r15+0x1C0]
0000713aae5ce984  movq xmm13, qword ptr [r15+0x1B0]
0000713aae5ce98d  movq r12, xmm14
0000713aae5ce992  movq r11, xmm13
0000713aae5ce997  mov [r13+rax*1], r12
0000713aae5ce99c  lea rax, [r14+0x178]
0000713aae5ce9a3  mov [r13+rax*1], r11
0000713aae5ce9a8  lea rax, [r14+0x180]
0000713aae5ce9af  movq xmm14, qword ptr [r15+0x1A0]
0000713aae5ce9b8  movq xmm13, qword ptr [r15+0x190]
0000713aae5ce9c1  movq r12, xmm14
0000713aae5ce9c6  movq r11, xmm13
0000713aae5ce9cb  mov [r13+rax*1], r12
0000713aae5ce9d0  lea rax, [r14+0x188]
0000713aae5ce9d7  mov [r13+rax*1], r11
0000713aae5ce9dc  lea rax, [r14+0xD0]
0000713aae5ce9e3  movups [r13+rax*1], xmm1
0000713aae5ce9e9  lea rax, [r14+0xE0]
0000713aae5ce9f0  movups [r13+rax*1], xmm15
0000713aae5ce9f6  mov eax, 0x420AD0
0000713aae5ce9fb  movups xmm1, [r13+rax*1]
0000713aae5cea01  mov eax, 0x420AE0
0000713aae5cea06  movups xmm15, [r13+rax*1]
0000713aae5cea0c  movaps [r15+0x110], xmm1
0000713aae5cea14  movaps [r15+0x130], xmm15
0000713aae5cea1c  lea rax, [r14+0x190]
0000713aae5cea23  mov r12, [r15+0xE8]
0000713aae5cea2a  mov r11, [r15+0xF0]
0000713aae5cea31  mov [r13+rax*1], r12
0000713aae5cea36  lea rax, [r14+0x198]
0000713aae5cea3d  mov [r13+rax*1], r11
0000713aae5cea42  mov eax, 0x430D88
0000713aae5cea47  mov r12d, 0x421DF8D3
0000713aae5cea4d  mov [r13+rax*1], r12d
0000713aae5cea52  lea rax, [r14+0xF0]
0000713aae5cea59  movups [r13+rax*1], xmm1
0000713aae5cea5f  lea rax, [r14+0x100]
0000713aae5cea66  movups [r13+rax*1], xmm15
0000713aae5cea6c  lea rax, [r14+0xD0]
0000713aae5cea73  mov [r15], rax
0000713aae5cea76  mov qword ptr [r15+0x08], 0x430C60
0000713aae5cea7e  mov qword ptr [r15+0x10], 0x12C
0000713aae5cea86  mov qword ptr [r15+0xF0], 0x410284
0000713aae5cea91  mov r14d, [r15+0x320]
0000713aae5cea98  mov eax, 0x410284
0000713aae5cea9d  mov rcx, 0x713AAE5D07C0
0000713aae5ceaa7  mov [r15+r14*8+0x328], rax
0000713aae5ceaaf  mov [r15+r14*8+0x368], rcx
0000713aae5ceab7  add r14d, 0x01
0000713aae5ceabb  and r14d, 0x07
0000713aae5ceabf  mov [r15+0x320], r14d
0000713aae5ceac6  cmp dword ptr [r15+0x318], 0x00
0000713aae5ceace  jz 0x0000713AAE5CED70
0000713aae5cead4  nop [rax+rax*1], ax
0000713aae5ceadd  nop [rax+rax*1], eax
0000713aae5ceae5  mov eax, 0x4106BC
0000713aae5ceaea  mov [r15+0x100], rax
0000713aae5ceaf1  jmp 0x0000713AAE3FE110
0000713aae5ceaf6  int3
0000713aae5ceaf7  call 0x0000713AAE40BC20
0000713aae5ceafc  jmp 0x0000713AAE5CE6CF
0000713aae5ceb01  call 0x0000713AAE40A9A0
0000713aae5ceb06  jmp 0x0000713AAE5CE6DB
0000713aae5ceb0b  call 0x0000713AAE3FF430
0000713aae5ceb10  jmp 0x0000713AAE5CE6E6
0000713aae5ceb15  call 0x0000713AAE40E760
0000713aae5ceb1a  jmp 0x0000713AAE5CE6F1
0000713aae5ceb1f  call 0x0000713AAE40D4E0
0000713aae5ceb24  jmp 0x0000713AAE5CE6FC
0000713aae5ceb29  call 0x0000713AAE40C260
0000713aae5ceb2e  jmp 0x0000713AAE5CE707
0000713aae5ceb33  call 0x0000713AAE40AFE0
0000713aae5ceb38  jmp 0x0000713AAE5CE71D
0000713aae5ceb3d  call 0x0000713AAE3FF540
0000713aae5ceb42  jmp 0x0000713AAE5CE728
0000713aae5ceb47  call 0x0000713AAE40E880
0000713aae5ceb4c  jmp 0x0000713AAE5CE733
0000713aae5ceb51  call 0x0000713AAE40D600
0000713aae5ceb56  jmp 0x0000713AAE5CE73E
0000713aae5ceb5b  call 0x0000713AAE40C380
0000713aae5ceb60  jmp 0x0000713AAE5CE749
0000713aae5ceb65  call 0x0000713AAE40D4E0
0000713aae5ceb6a  jmp 0x0000713AAE5CE754
0000713aae5ceb6f  call 0x0000713AAE40C260
0000713aae5ceb74  jmp 0x0000713AAE5CE75F
0000713aae5ceb79  call 0x0000713AAE3FF540
0000713aae5ceb7e  jmp 0x0000713AAE5CE76A
0000713aae5ceb83  call 0x0000713AAE40E880
0000713aae5ceb88  jmp 0x0000713AAE5CE775
0000713aae5ceb8d  call 0x0000713AAE40B100
0000713aae5ceb92  jmp 0x0000713AAE5CE780
0000713aae5ceb97  call 0x0000713AAE40D600
0000713aae5ceb9c  jmp 0x0000713AAE5CE78B
0000713aae5ceba1  call 0x0000713AAE3FF430
0000713aae5ceba6  jmp 0x0000713AAE5CE796
0000713aae5cebab  call 0x0000713AAE40E760
0000713aae5cebb0  jmp 0x0000713AAE5CE7A1
0000713aae5cebb5  call 0x0000713AAE40C380
0000713aae5cebba  jmp 0x0000713AAE5CE7AC
0000713aae5cebbf  call 0x0000713AAE3FF540
0000713aae5cebc4  jmp 0x0000713AAE5CE7B7
0000713aae5cebc9  call 0x0000713AAE3FF430
0000713aae5cebce  jmp 0x0000713AAE5CE7C2
0000713aae5cebd3  call 0x0000713AAE40D4E0
0000713aae5cebd8  jmp 0x0000713AAE5CE7CD
0000713aae5cebdd  call 0x0000713AAE40E880
0000713aae5cebe2  jmp 0x0000713AAE5CE7E0
0000713aae5cebe7  call 0x0000713AAE3FF540
0000713aae5cebec  jmp 0x0000713AAE5CE7EB
0000713aae5cebf1  call 0x0000713AAE3FF430
0000713aae5cebf6  jmp 0x0000713AAE5CE7F6
0000713aae5cebfb  call 0x0000713AAE40E760
0000713aae5cec00  jmp 0x0000713AAE5CE801
0000713aae5cec05  call 0x0000713AAE40D600
0000713aae5cec0a  jmp 0x0000713AAE5CE81F
0000713aae5cec0f  call 0x0000713AAE3FF540
0000713aae5cec14  jmp 0x0000713AAE5CE82A
0000713aae5cec19  call 0x0000713AAE3FF430
0000713aae5cec1e  jmp 0x0000713AAE5CE835
0000713aae5cec23  call 0x0000713AAE40D4E0
0000713aae5cec28  jmp 0x0000713AAE5CE840
0000713aae5cec2d  call 0x0000713AAE40BC20
0000713aae5cec32  jmp 0x0000713AAE5CE870
0000713aae5cec37  call 0x0000713AAE40A9A0
0000713aae5cec3c  jmp 0x0000713AAE5CE87C
0000713aae5cec41  call 0x0000713AAE40E880
0000713aae5cec46  jmp 0x0000713AAE5CE887
0000713aae5cec4b  call 0x0000713AAE3FF540
0000713aae5cec50  jmp 0x0000713AAE5CE892
0000713aae5cec55  call 0x0000713AAE3FF430
0000713aae5cec5a  jmp 0x0000713AAE5CE89D
0000713aae5cec5f  call 0x0000713AAE40B720
0000713aae5cec64  jmp 0x0000713AAE5CE8A7
0000713aae5cec69  call 0x0000713AAE40D600
0000713aae5cec6e  jmp 0x0000713AAE5CE8BF
0000713aae5cec73  call 0x0000713AAE3FF540
0000713aae5cec78  jmp 0x0000713AAE5CE8CA
0000713aae5cec7d  call 0x0000713AAE3FF430
0000713aae5cec82  jmp 0x0000713AAE5CE8D5
0000713aae5cec87  call 0x0000713AAE4B4CB0
0000713aae5cec8c  jmp 0x0000713AAE5CE8E5
0000713aae5cec91  call 0x0000713AAE40E760
0000713aae5cec96  jmp 0x0000713AAE5CE8F0
0000713aae5cec9b  call 0x0000713AAE40D4E0
0000713aae5ceca0  jmp 0x0000713AAE5CE8FB
0000713aae5ceca5  call 0x0000713AAE3FF540
0000713aae5cecaa  jmp 0x0000713AAE5CE908
0000713aae5cecaf  call 0x0000713AAE40BC20
0000713aae5cecb4  jmp 0x0000713AAE5CE930
0000713aae5cecb9  call 0x0000713AAE40A9A0
0000713aae5cecbe  jmp 0x0000713AAE5CE93C
0000713aae5cecc3  call 0x0000713AAE40E880
0000713aae5cecc8  jmp 0x0000713AAE5CE949
0000713aae5ceccd  call 0x0000713AAE40D600
0000713aae5cecd2  jmp 0x0000713AAE5CE956
0000713aae5cecd7  call 0x0000713AAE3FF430
0000713aae5cecdc  jmp 0x0000713AAE5CE961
0000713aae5cece1  call 0x0000713AAE40E760
0000713aae5cece6  jmp 0x0000713AAE5CE96C
0000713aae5ceceb  call 0x0000713AAE40BC20
0000713aae5cecf0  jmp 0x0000713AAE5CE99C
0000713aae5cecf5  call 0x0000713AAE40A9A0
0000713aae5cecfa  jmp 0x0000713AAE5CE9A8
0000713aae5cecff  call 0x0000713AAE40BC20
0000713aae5ced04  jmp 0x0000713AAE5CE9D0
0000713aae5ced09  call 0x0000713AAE40A9A0
0000713aae5ced0e  jmp 0x0000713AAE5CE9DC
0000713aae5ced13  call 0x0000713AAE3FF540
0000713aae5ced18  jmp 0x0000713AAE5CE9E9
0000713aae5ced1d  call 0x0000713AAE40E880
0000713aae5ced22  jmp 0x0000713AAE5CE9F6
0000713aae5ced27  call 0x0000713AAE3FF430
0000713aae5ced2c  jmp 0x0000713AAE5CEA01
0000713aae5ced31  call 0x0000713AAE40E760
0000713aae5ced36  jmp 0x0000713AAE5CEA0C
0000713aae5ced3b  call 0x0000713AAE40BC20
0000713aae5ced40  jmp 0x0000713AAE5CEA36
0000713aae5ced45  call 0x0000713AAE40A9A0
0000713aae5ced4a  jmp 0x0000713AAE5CEA42
0000713aae5ced4f  call 0x0000713AAE40BAE0
0000713aae5ced54  jmp 0x0000713AAE5CEA52
0000713aae5ced59  call 0x0000713AAE3FF540
0000713aae5ced5e  jmp 0x0000713AAE5CEA5F
0000713aae5ced63  call 0x0000713AAE40E880
0000713aae5ced68  jmp 0x0000713AAE5CEA6C
0000713aae5ced6d  int3
0000713aae5ced6e  nop
0000713aae5ced70  mov rax, [r15]
0000713aae5ced73  lea r14, [rax+0x20]
0000713aae5ced77  mov r12, [r13+r14*1]
0000713aae5ced7c  mov r14, [r15+0x10]
0000713aae5ced80  lea r11, [r12+r14*1]
0000713aae5ced84  mov [r15+0x40], r11
0000713aae5ced88  lea r12, [rax+0x20]
0000713aae5ced8c  mov [r13+r12*1], r11
0000713aae5ced91  test r14, r14
0000713aae5ced94  setz r14b
0000713aae5ced98  movzx r14, r14b
0000713aae5ced9c  mov [rsp+0x414], r14b
0000713aae5ceda4  cmp byte ptr [rsp+0x414], 0x00
0000713aae5cedac  jz 0x0000713AAE5CEDDE
0000713aae5cedae  cmp dword ptr [r15+0x318], 0x00
0000713aae5cedb6  mov eax, 0x410934
0000713aae5cedbb  mov [r15+0x100], rax
0000713aae5cedc2  jz 0x0000713AAE3FE0A0
0000713aae5cedc8  nop [rax+rax*1], eax
0000713aae5cedcd  mov eax, 0x410934
0000713aae5cedd2  mov [r15+0x100], rax
0000713aae5cedd9  jmp 0x0000713AAE3FE110
0000713aae5cedde  cmp dword ptr [r15+0x318], 0x00
0000713aae5cede6  jz 0x0000713AAE5CEE30
0000713aae5cedec  nop [rax+rax*1], ax
0000713aae5cedf5  nop [rax+rax*1], eax
0000713aae5cedfd  mov eax, 0x4106CC
0000713aae5cee02  mov [r15+0x100], rax
0000713aae5cee09  jmp 0x0000713AAE3FE110
0000713aae5cee0e  int3
0000713aae5cee0f  call 0x0000713AAE4E27E0
0000713aae5cee14  jmp 0x0000713AAE5CED7C
0000713aae5cee19  call 0x0000713AAE4C0860
0000713aae5cee1e  jmp 0x0000713AAE5CED91
0000713aae5cee23  int3
0000713aae5cee24  nop [rax+rax*1], ax
0000713aae5cee2d  nop [rax], eax
0000713aae5cee30  mov rax, [r15+0xF8]
0000713aae5cee37  lea r14, [rax-0x150]
0000713aae5cee3e  mov [r15+0xF8], r14
0000713aae5cee45  mov rax, [r15]
0000713aae5cee48  lea r12, [rax+0x68]
0000713aae5cee4c  mov r11, [r13+r12*1]
0000713aae5cee51  mov [r15+0x88], r11
0000713aae5cee58  lea r12, [rax+0x28]
0000713aae5cee5c  mov [r15+0x40], r12
0000713aae5cee60  mov [r15+0x48], r14
0000713aae5cee64  mov qword ptr [r15+0x50], 0x420B20
0000713aae5cee6c  lea rax, [r14+0x100]
0000713aae5cee73  mov r12, [r15+0xE8]
0000713aae5cee7a  mov r11, [r15+0xD8]
0000713aae5cee81  mov [r13+rax*1], r12
0000713aae5cee86  lea rax, [r14+0x108]
0000713aae5cee8d  mov [r13+rax*1], r11
0000713aae5cee92  lea rax, [r14+0x110]
0000713aae5cee99  mov r12, [r15+0xD0]
0000713aae5ceea0  mov r11, [r15+0xC8]
0000713aae5ceea7  mov [r13+rax*1], r12
0000713aae5ceeac  lea rax, [r14+0x118]
0000713aae5ceeb3  mov [r13+rax*1], r11
0000713aae5ceeb8  lea rax, [r14+0x120]
0000713aae5ceebf  mov r12, [r15+0xC0]
0000713aae5ceec6  mov r11, [r15+0xB8]
0000713aae5ceecd  mov [r13+rax*1], r12
0000713aae5ceed2  lea rax, [r14+0x128]
0000713aae5ceed9  mov [r13+rax*1], r11
0000713aae5ceede  lea rax, [r14+0x130]
0000713aae5ceee5  mov r12, [r15+0xB0]
0000713aae5ceeec  mov r11, [r15+0xA8]
0000713aae5ceef3  mov [r13+rax*1], r12
0000713aae5ceef8  lea rax, [r14+0x138]
0000713aae5ceeff  mov [r13+rax*1], r11
0000713aae5cef04  lea rax, [r14+0x140]
0000713aae5cef0b  mov r12, [r15+0xA0]
0000713aae5cef12  mov r11, [r15+0x98]
0000713aae5cef19  mov [r13+rax*1], r12
0000713aae5cef1e  lea rax, [r14+0x148]
0000713aae5cef25  mov [r13+rax*1], r11
0000713aae5cef2a  cmp dword ptr [r15+0x318], 0x00
0000713aae5cef32  jz 0x0000713AAE5CEFD0
0000713aae5cef38  nop [rax+rax*1], ax
0000713aae5cef41  nop [rax+rax*1], eax
0000713aae5cef49  mov eax, 0x410704
0000713aae5cef4e  mov [r15+0x100], rax
0000713aae5cef55  jmp 0x0000713AAE3FE110
0000713aae5cef5a  int3
0000713aae5cef5b  call 0x0000713AAE4C0370
0000713aae5cef60  jmp 0x0000713AAE5CEE51
0000713aae5cef65  call 0x0000713AAE40BC20
0000713aae5cef6a  jmp 0x0000713AAE5CEE86
0000713aae5cef6f  call 0x0000713AAE40A9A0
0000713aae5cef74  jmp 0x0000713AAE5CEE92
0000713aae5cef79  call 0x0000713AAE40BC20
0000713aae5cef7e  jmp 0x0000713AAE5CEEAC
0000713aae5cef83  call 0x0000713AAE40A9A0
0000713aae5cef88  jmp 0x0000713AAE5CEEB8
0000713aae5cef8d  call 0x0000713AAE40BC20
0000713aae5cef92  jmp 0x0000713AAE5CEED2
0000713aae5cef97  call 0x0000713AAE40A9A0
0000713aae5cef9c  jmp 0x0000713AAE5CEEDE
0000713aae5cefa1  call 0x0000713AAE40BC20
0000713aae5cefa6  jmp 0x0000713AAE5CEEF8
0000713aae5cefab  call 0x0000713AAE40A9A0
0000713aae5cefb0  jmp 0x0000713AAE5CEF04
0000713aae5cefb5  call 0x0000713AAE40BC20
0000713aae5cefba  jmp 0x0000713AAE5CEF1E
0000713aae5cefbf  call 0x0000713AAE40A9A0
0000713aae5cefc4  jmp 0x0000713AAE5CEF2A
0000713aae5cefc9  int3
0000713aae5cefca  nop [rax+rax*1], ax
0000713aae5cefd0  mov rax, [r15+0x08]
0000713aae5cefd4  movzx r14d, byte ptr [r13+rax*1]
0000713aae5cefda  movzx r14d, r14b
0000713aae5cefde  mov [rsp+0x10], r14d
0000713aae5cefe3  mov r14d, r14d
0000713aae5cefe6  mov [r15+0x58], r14
0000713aae5cefea  lea r14, [rax+0x01]
0000713aae5cefee  mov [r15+0x08], r14
0000713aae5ceff2  mov rax, [r15+0x88]
0000713aae5ceff9  lea r14, [rax+0x01]
0000713aae5ceffd  mov r12, [r15]
0000713aae5cf000  lea r11, [r12+0x68]
0000713aae5cf005  mov [r13+r11*1], r14
0000713aae5cf00a  lea r14, [r12+rax*1]
0000713aae5cf00e  mov [r15+0x60], r14
0000713aae5cf012  lea rax, [r14+0x28]
0000713aae5cf016  mov r11d, [rsp+0x10]
0000713aae5cf01b  movzx r14d, r11b
0000713aae5cf01f  mov [r13+rax*1], r14b
0000713aae5cf024  lea rax, [r12+0x68]
0000713aae5cf029  mov r14, [r13+rax*1]
0000713aae5cf02e  mov [r15+0x88], r14
0000713aae5cf035  xor eax, eax
0000713aae5cf037  mov r12d, 0x40
0000713aae5cf03d  cmp r14, r12
0000713aae5cf040  cmc
0000713aae5cf041  lahf
0000713aae5cf042  seto al
0000713aae5cf045  mov [r15+0x108], eax
0000713aae5cf04c  mov eax, [r15+0x108]
0000713aae5cf053  sahf
0000713aae5cf054  jnz 0x0000713AAE5CF086
0000713aae5cf056  cmp dword ptr [r15+0x318], 0x00
0000713aae5cf05e  jz 0x0000713AAE5CF170
0000713aae5cf064  nop [rax+rax*1], ax
0000713aae5cf06d  nop [rax+rax*1], eax
0000713aae5cf075  mov eax, 0x410724
0000713aae5cf07a  mov [r15+0x100], rax
0000713aae5cf081  jmp 0x0000713AAE3FE110
0000713aae5cf086  cmp dword ptr [r15+0x318], 0x00
0000713aae5cf08e  jz 0x0000713AAE5CF0E0
0000713aae5cf094  nop [rax+rax*1], ax
0000713aae5cf09d  nop [rax+rax*1], eax
0000713aae5cf0a5  mov eax, 0x4106FC
0000713aae5cf0aa  mov [r15+0x100], rax
0000713aae5cf0b1  jmp 0x0000713AAE3FE110
0000713aae5cf0b6  int3
0000713aae5cf0b7  call 0x0000713AAE40D860
0000713aae5cf0bc  jmp 0x0000713AAE5CEFDA
0000713aae5cf0c1  call 0x0000713AAE4B36E0
0000713aae5cf0c6  jmp 0x0000713AAE5CF00A
0000713aae5cf0cb  call 0x0000713AAE40DD60
0000713aae5cf0d0  jmp 0x0000713AAE5CF024
0000713aae5cf0d5  call 0x0000713AAE40DC20
0000713aae5cf0da  jmp 0x0000713AAE5CF02E
0000713aae5cf0df  int3
0000713aae5cf0e0  mov rax, [r15+0x10]
0000713aae5cf0e4  lea r14, [rax-0x01]
0000713aae5cf0e8  mov [r15+0x10], r14
0000713aae5cf0ec  test r14, r14
0000713aae5cf0ef  setz r14b
0000713aae5cf0f3  movzx r14, r14b
0000713aae5cf0f7  mov [rsp+0x414], r14b
0000713aae5cf0ff  cmp byte ptr [rsp+0x414], 0x00
0000713aae5cf107  jz 0x0000713AAE5CF139
0000713aae5cf109  cmp dword ptr [r15+0x318], 0x00
0000713aae5cf111  jz 0x0000713AAE5D0670
0000713aae5cf117  nop [rax+rax*1], ax
0000713aae5cf120  nop [rax+rax*1], eax
0000713aae5cf128  mov eax, 0x41091C
0000713aae5cf12d  mov [r15+0x100], rax
0000713aae5cf134  jmp 0x0000713AAE3FE110
0000713aae5cf139  cmp dword ptr [r15+0x318], 0x00
0000713aae5cf141  jz 0x0000713AAE5CEFD0
0000713aae5cf147  nop [rax+rax*1], ax
0000713aae5cf150  nop [rax+rax*1], eax
0000713aae5cf158  mov eax, 0x410704
0000713aae5cf15d  mov [r15+0x100], rax
0000713aae5cf164  jmp 0x0000713AAE3FE110
0000713aae5cf169  int3
0000713aae5cf16a  int3
0000713aae5cf16b  nop [rax+rax*1], eax
0000713aae5cf170  mov rax, [r15+0x40]
0000713aae5cf174  movzx r14d, byte ptr [r13+rax*1]
0000713aae5cf17a  movaps xmm1, [r15+0x110]
0000713aae5cf182  pinsrb xmm1, r14d, 0x00
0000713aae5cf189  lea r14, [rax+0x01]
0000713aae5cf18d  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf193  movaps xmm15, [r15+0x120]
0000713aae5cf19b  pinsrb xmm15, r12d, 0x00
0000713aae5cf1a2  lea r14, [rax+0x02]
0000713aae5cf1a6  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf1ac  movaps xmm14, [r15+0x130]
0000713aae5cf1b4  pinsrb xmm14, r12d, 0x00
0000713aae5cf1bb  lea r14, [rax+0x03]
0000713aae5cf1bf  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf1c5  movaps xmm13, [r15+0x140]
0000713aae5cf1cd  pinsrb xmm13, r12d, 0x00
0000713aae5cf1d4  lea r14, [rax+0x04]
0000713aae5cf1d8  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf1de  pinsrb xmm1, r12d, 0x01
0000713aae5cf1e5  lea r14, [rax+0x05]
0000713aae5cf1e9  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf1ef  pinsrb xmm15, r12d, 0x01
0000713aae5cf1f6  lea r14, [rax+0x06]
0000713aae5cf1fa  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf200  pinsrb xmm14, r12d, 0x01
0000713aae5cf207  lea r14, [rax+0x07]
0000713aae5cf20b  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf211  pinsrb xmm13, r12d, 0x01
0000713aae5cf218  lea r14, [rax+0x08]
0000713aae5cf21c  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf222  pinsrb xmm1, r12d, 0x02
0000713aae5cf229  lea r14, [rax+0x09]
0000713aae5cf22d  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf233  pinsrb xmm15, r12d, 0x02
0000713aae5cf23a  lea r14, [rax+0x0A]
0000713aae5cf23e  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf244  pinsrb xmm14, r12d, 0x02
0000713aae5cf24b  lea r14, [rax+0x0B]
0000713aae5cf24f  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf255  pinsrb xmm13, r12d, 0x02
0000713aae5cf25c  lea r14, [rax+0x0C]
0000713aae5cf260  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf266  pinsrb xmm1, r12d, 0x03
0000713aae5cf26d  lea r14, [rax+0x0D]
0000713aae5cf271  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf277  pinsrb xmm15, r12d, 0x03
0000713aae5cf27e  lea r14, [rax+0x0E]
0000713aae5cf282  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf288  pinsrb xmm14, r12d, 0x03
0000713aae5cf28f  lea r14, [rax+0x0F]
0000713aae5cf293  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf299  pinsrb xmm13, r12d, 0x03
0000713aae5cf2a0  lea r14, [rax+0x10]
0000713aae5cf2a4  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf2aa  pinsrb xmm1, r12d, 0x04
0000713aae5cf2b1  lea r14, [rax+0x11]
0000713aae5cf2b5  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf2bb  pinsrb xmm15, r12d, 0x04
0000713aae5cf2c2  lea r14, [rax+0x12]
0000713aae5cf2c6  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf2cc  pinsrb xmm14, r12d, 0x04
0000713aae5cf2d3  lea r14, [rax+0x13]
0000713aae5cf2d7  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf2dd  pinsrb xmm13, r12d, 0x04
0000713aae5cf2e4  lea r14, [rax+0x14]
0000713aae5cf2e8  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf2ee  pinsrb xmm1, r12d, 0x05
0000713aae5cf2f5  lea r14, [rax+0x15]
0000713aae5cf2f9  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf2ff  pinsrb xmm15, r12d, 0x05
0000713aae5cf306  lea r14, [rax+0x16]
0000713aae5cf30a  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf310  pinsrb xmm14, r12d, 0x05
0000713aae5cf317  lea r14, [rax+0x17]
0000713aae5cf31b  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf321  pinsrb xmm13, r12d, 0x05
0000713aae5cf328  lea r14, [rax+0x18]
0000713aae5cf32c  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf332  pinsrb xmm1, r12d, 0x06
0000713aae5cf339  lea r14, [rax+0x19]
0000713aae5cf33d  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf343  pinsrb xmm15, r12d, 0x06
0000713aae5cf34a  lea r14, [rax+0x1A]
0000713aae5cf34e  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf354  pinsrb xmm14, r12d, 0x06
0000713aae5cf35b  lea r14, [rax+0x1B]
0000713aae5cf35f  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf365  pinsrb xmm13, r12d, 0x06
0000713aae5cf36c  lea r14, [rax+0x1C]
0000713aae5cf370  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf376  pinsrb xmm1, r12d, 0x07
0000713aae5cf37d  lea r14, [rax+0x1D]
0000713aae5cf381  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf387  pinsrb xmm15, r12d, 0x07
0000713aae5cf38e  lea r14, [rax+0x1E]
0000713aae5cf392  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf398  pinsrb xmm14, r12d, 0x07
0000713aae5cf39f  lea r14, [rax+0x1F]
0000713aae5cf3a3  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf3a9  pinsrb xmm13, r12d, 0x07
0000713aae5cf3b0  lea r14, [rax+0x20]
0000713aae5cf3b4  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf3ba  pinsrb xmm1, r12d, 0x08
0000713aae5cf3c1  lea r14, [rax+0x21]
0000713aae5cf3c5  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf3cb  pinsrb xmm15, r12d, 0x08
0000713aae5cf3d2  lea r14, [rax+0x22]
0000713aae5cf3d6  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf3dc  pinsrb xmm14, r12d, 0x08
0000713aae5cf3e3  lea r14, [rax+0x23]
0000713aae5cf3e7  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf3ed  pinsrb xmm13, r12d, 0x08
0000713aae5cf3f4  lea r14, [rax+0x24]
0000713aae5cf3f8  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf3fe  pinsrb xmm1, r12d, 0x09
0000713aae5cf405  lea r14, [rax+0x25]
0000713aae5cf409  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf40f  pinsrb xmm15, r12d, 0x09
0000713aae5cf416  lea r14, [rax+0x26]
0000713aae5cf41a  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf420  pinsrb xmm14, r12d, 0x09
0000713aae5cf427  lea r14, [rax+0x27]
0000713aae5cf42b  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf431  pinsrb xmm13, r12d, 0x09
0000713aae5cf438  lea r14, [rax+0x28]
0000713aae5cf43c  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf442  pinsrb xmm1, r12d, 0x0A
0000713aae5cf449  lea r14, [rax+0x29]
0000713aae5cf44d  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf453  pinsrb xmm15, r12d, 0x0A
0000713aae5cf45a  lea r14, [rax+0x2A]
0000713aae5cf45e  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf464  pinsrb xmm14, r12d, 0x0A
0000713aae5cf46b  lea r14, [rax+0x2B]
0000713aae5cf46f  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf475  pinsrb xmm13, r12d, 0x0A
0000713aae5cf47c  lea r14, [rax+0x2C]
0000713aae5cf480  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf486  pinsrb xmm1, r12d, 0x0B
0000713aae5cf48d  lea r14, [rax+0x2D]
0000713aae5cf491  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf497  pinsrb xmm15, r12d, 0x0B
0000713aae5cf49e  lea r14, [rax+0x2E]
0000713aae5cf4a2  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf4a8  pinsrb xmm14, r12d, 0x0B
0000713aae5cf4af  lea r14, [rax+0x2F]
0000713aae5cf4b3  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf4b9  pinsrb xmm13, r12d, 0x0B
0000713aae5cf4c0  lea r14, [rax+0x30]
0000713aae5cf4c4  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf4ca  pinsrb xmm1, r12d, 0x0C
0000713aae5cf4d1  lea r14, [rax+0x31]
0000713aae5cf4d5  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf4db  pinsrb xmm15, r12d, 0x0C
0000713aae5cf4e2  lea r14, [rax+0x32]
0000713aae5cf4e6  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf4ec  pinsrb xmm14, r12d, 0x0C
0000713aae5cf4f3  lea r14, [rax+0x33]
0000713aae5cf4f7  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf4fd  pinsrb xmm13, r12d, 0x0C
0000713aae5cf504  lea r14, [rax+0x34]
0000713aae5cf508  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf50e  pinsrb xmm1, r12d, 0x0D
0000713aae5cf515  lea r14, [rax+0x35]
0000713aae5cf519  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf51f  pinsrb xmm15, r12d, 0x0D
0000713aae5cf526  lea r14, [rax+0x36]
0000713aae5cf52a  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf530  pinsrb xmm14, r12d, 0x0D
0000713aae5cf537  lea r14, [rax+0x37]
0000713aae5cf53b  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf541  pinsrb xmm13, r12d, 0x0D
0000713aae5cf548  lea r14, [rax+0x38]
0000713aae5cf54c  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf552  pinsrb xmm1, r12d, 0x0E
0000713aae5cf559  lea r14, [rax+0x39]
0000713aae5cf55d  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf563  pinsrb xmm15, r12d, 0x0E
0000713aae5cf56a  lea r14, [rax+0x3A]
0000713aae5cf56e  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf574  pinsrb xmm14, r12d, 0x0E
0000713aae5cf57b  lea r14, [rax+0x3B]
0000713aae5cf57f  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf585  pinsrb xmm13, r12d, 0x0E
0000713aae5cf58c  lea r14, [rax+0x3C]
0000713aae5cf590  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf596  pinsrb xmm1, r12d, 0x0F
0000713aae5cf59d  movaps [r15+0x110], xmm1
0000713aae5cf5a5  lea r14, [rax+0x3D]
0000713aae5cf5a9  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf5af  pinsrb xmm15, r12d, 0x0F
0000713aae5cf5b6  movaps [r15+0x120], xmm15
0000713aae5cf5be  lea r14, [rax+0x3E]
0000713aae5cf5c2  movzx r12d, byte ptr [r13+r14*1]
0000713aae5cf5c8  pinsrb xmm14, r12d, 0x0F
0000713aae5cf5cf  movaps [r15+0x130], xmm14
0000713aae5cf5d7  lea r14, [rax+0x3F]
0000713aae5cf5db  movzx eax, byte ptr [r13+r14*1]
0000713aae5cf5e1  pinsrb xmm13, eax, 0x0F
0000713aae5cf5e8  movaps [r15+0x140], xmm13
0000713aae5cf5f0  movq xmm1, qword ptr [r15+0x120]
0000713aae5cf5f9  pmovzxbw xmm1, xmm1
0000713aae5cf5fe  psllw xmm1, 0x00
0000713aae5cf603  movaps [r15+0x150], xmm1
0000713aae5cf60b  movq xmm1, qword ptr [r15+0x130]
0000713aae5cf614  pmovzxbw xmm1, xmm1
0000713aae5cf619  psllw xmm1, 0x00
0000713aae5cf61e  movaps [r15+0x160], xmm1
0000713aae5cf626  movq xmm1, qword ptr [r15+0x110]
0000713aae5cf62f  pmovzxbw xmm1, xmm1
0000713aae5cf634  psllw xmm1, 0x00
0000713aae5cf639  movaps [r15+0x170], xmm1
0000713aae5cf641  movaps xmm15, [r15+0x110]
0000713aae5cf649  pextrq rax, xmm15, 0x01
0000713aae5cf650  movq xmm15, rax
0000713aae5cf655  pmovzxbw xmm15, xmm15
0000713aae5cf65b  psllw xmm15, 0x00
0000713aae5cf661  movaps [r15+0x180], xmm15
0000713aae5cf669  movaps xmm14, [r15+0x120]
0000713aae5cf671  pextrq rax, xmm14, 0x01
0000713aae5cf678  movq xmm14, rax
0000713aae5cf67d  pmovzxbw xmm14, xmm14
0000713aae5cf683  psllw xmm14, 0x00
0000713aae5cf689  movaps [r15+0x210], xmm14
0000713aae5cf691  movaps xmm13, [r15+0x130]
0000713aae5cf699  pextrq rax, xmm13, 0x01
0000713aae5cf6a0  movq xmm13, rax
0000713aae5cf6a5  pmovzxbw xmm13, xmm13
0000713aae5cf6ab  psllw xmm13, 0x00
0000713aae5cf6b1  movaps [r15+0x220], xmm13
0000713aae5cf6b9  movq xmm12, qword ptr [r15+0x140]
0000713aae5cf6c2  pmovzxbw xmm12, xmm12
0000713aae5cf6c8  psllw xmm12, 0x00
0000713aae5cf6ce  movaps [r15+0x250], xmm12
0000713aae5cf6d6  movaps xmm12, [r15+0x140]
0000713aae5cf6de  pextrq rax, xmm12, 0x01
0000713aae5cf6e5  movq xmm12, rax
0000713aae5cf6ea  pmovzxbw xmm12, xmm12
0000713aae5cf6f0  psllw xmm12, 0x00
0000713aae5cf6f6  movaps [r15+0x110], xmm12
0000713aae5cf6fe  movq xmm11, qword ptr [r15+0x150]
0000713aae5cf707  pmovzxwd xmm11, xmm11
0000713aae5cf70d  pslld xmm11, 0x10
0000713aae5cf713  movq xmm10, qword ptr [r15+0x160]
0000713aae5cf71c  pmovzxwd xmm10, xmm10
0000713aae5cf722  pslld xmm10, 0x08
0000713aae5cf728  pextrq rax, xmm1, 0x01
0000713aae5cf72f  movq xmm1, rax
0000713aae5cf734  pmovzxwd xmm1, xmm1
0000713aae5cf739  pslld xmm1, 0x00
0000713aae5cf73e  movaps [r15+0x260], xmm1
0000713aae5cf746  pextrq rax, xmm15, 0x01
0000713aae5cf74d  movq xmm15, rax
0000713aae5cf752  pmovzxwd xmm15, xmm15
0000713aae5cf758  pslld xmm15, 0x00
0000713aae5cf75e  movaps [r15+0x270], xmm15
0000713aae5cf766  movq xmm9, qword ptr [r15+0x170]
0000713aae5cf76f  pmovzxwd xmm9, xmm9
0000713aae5cf775  pslld xmm9, 0x00
0000713aae5cf77b  pextrq rax, xmm14, 0x01
0000713aae5cf782  movq xmm14, rax
0000713aae5cf787  pmovzxwd xmm14, xmm14
0000713aae5cf78d  pslld xmm14, 0x10
0000713aae5cf793  movaps [r15+0x280], xmm14
0000713aae5cf79b  movq xmm8, qword ptr [r15+0x180]
0000713aae5cf7a4  pmovzxwd xmm8, xmm8
0000713aae5cf7aa  pslld xmm8, 0x00
0000713aae5cf7b0  movq xmm7, qword ptr [r15+0x210]
0000713aae5cf7b9  pmovzxwd xmm7, xmm7
0000713aae5cf7be  pslld xmm7, 0x10
0000713aae5cf7c3  movaps xmm6, [r15+0x150]
0000713aae5cf7cb  pextrq rax, xmm6, 0x01
0000713aae5cf7d2  movq xmm6, rax
0000713aae5cf7d7  pmovzxwd xmm6, xmm6
0000713aae5cf7dc  pslld xmm6, 0x10
0000713aae5cf7e1  por xmm11, xmm10
0000713aae5cf7e6  movaps [r15+0x230], xmm11
0000713aae5cf7ee  pextrq rax, xmm13, 0x01
0000713aae5cf7f5  movq xmm13, rax
0000713aae5cf7fa  pmovzxwd xmm13, xmm13
0000713aae5cf800  pslld xmm13, 0x08
0000713aae5cf806  movaps [r15+0x240], xmm13
0000713aae5cf80e  movq xmm10, qword ptr [r15+0x220]
0000713aae5cf817  pmovzxwd xmm10, xmm10
0000713aae5cf81d  pslld xmm10, 0x08
0000713aae5cf823  movaps xmm5, [r15+0x160]
0000713aae5cf82b  pextrq rax, xmm5, 0x01
0000713aae5cf832  movq xmm5, rax
0000713aae5cf837  pmovzxwd xmm5, xmm5
0000713aae5cf83c  pslld xmm5, 0x08
0000713aae5cf841  pslld xmm9, 0x18
0000713aae5cf847  pslld xmm15, 0x18
0000713aae5cf84d  pslld xmm8, 0x18
0000713aae5cf853  movq xmm4, qword ptr [r15+0x250]
0000713aae5cf85c  pmovzxwd xmm4, xmm4
0000713aae5cf861  pslld xmm4, 0x00
0000713aae5cf866  por xmm14, xmm13
0000713aae5cf86b  por xmm7, xmm10
0000713aae5cf870  movaps [r15+0x210], xmm7
0000713aae5cf878  pslld xmm1, 0x18
0000713aae5cf87d  movaps [r15+0x220], xmm1
0000713aae5cf885  por xmm6, xmm5
0000713aae5cf889  por xmm11, xmm9
0000713aae5cf88e  movaps [r15+0x160], xmm11
0000713aae5cf896  pextrq rax, xmm12, 0x01
0000713aae5cf89d  movq xmm13, rax
0000713aae5cf8a2  pmovzxwd xmm13, xmm13
0000713aae5cf8a8  pslld xmm13, 0x00
0000713aae5cf8ae  movaps [r15+0x170], xmm13
0000713aae5cf8b6  movq xmm12, qword ptr [r15+0x110]
0000713aae5cf8bf  pmovzxwd xmm12, xmm12
0000713aae5cf8c5  pslld xmm12, 0x00
0000713aae5cf8cb  por xmm14, xmm15
0000713aae5cf8d0  por xmm7, xmm8
0000713aae5cf8d5  movaps xmm15, [r15+0x250]
0000713aae5cf8dd  pextrq rax, xmm15, 0x01
0000713aae5cf8e4  movq xmm15, rax
0000713aae5cf8e9  pmovzxwd xmm15, xmm15
0000713aae5cf8ef  pslld xmm15, 0x00
0000713aae5cf8f5  movaps [r15+0x180], xmm15
0000713aae5cf8fd  por xmm6, xmm1
0000713aae5cf901  movaps [r15+0x150], xmm6
0000713aae5cf909  por xmm11, xmm4
0000713aae5cf90e  movaps [r15+0x140], xmm11
0000713aae5cf916  por xmm7, xmm12
0000713aae5cf91b  movaps [r15+0x110], xmm7
0000713aae5cf923  por xmm14, xmm13
0000713aae5cf928  movaps [r15+0x120], xmm14
0000713aae5cf930  por xmm6, xmm15
0000713aae5cf935  movaps [r15+0x130], xmm6
0000713aae5cf93d  mov rax, [r15+0xF8]
0000713aae5cf944  lea r14, [rax+0x20]
0000713aae5cf948  movups [r13+r14*1], xmm7
0000713aae5cf94e  lea r14, [rax+0x30]
0000713aae5cf952  movups [r13+r14*1], xmm14
0000713aae5cf958  movups [r13+rax*1], xmm11
0000713aae5cf95e  lea r14, [rax+0x10]
0000713aae5cf962  movups [r13+r14*1], xmm6
0000713aae5cf968  mov r14d, [r13+rax*1]
0000713aae5cf96d  mov rax, [r15+0x48]
0000713aae5cf971  mov [r15+0x68], rax
0000713aae5cf975  mov qword ptr [r15+0x58], 0x04
0000713aae5cf97d  lea r12, [rax+0x04]
0000713aae5cf981  mov r11d, [r13+r12*1]
0000713aae5cf986  mov [rsp+0x10], r11d
0000713aae5cf98b  mov r11d, r11d
0000713aae5cf98e  mov [r15+0x70], r11
0000713aae5cf992  lea r12, [rax+0x38]
0000713aae5cf996  mov r11d, [r13+r12*1]
0000713aae5cf99b  lea r12, [rax+0x24]
0000713aae5cf99f  mov r10d, [r13+r12*1]
0000713aae5cf9a4  mov [rsp+0x20], r10d
0000713aae5cf9a9  mov r10d, r10d
0000713aae5cf9ac  mov [r15+0x90], r10
0000713aae5cf9b3  mov [rsp+0x30], rax
0000713aae5cf9b8  xor eax, eax
0000713aae5cf9ba  mov r12d, 0x04
0000713aae5cf9c0  mov r10d, 0xC0
0000713aae5cf9c6  cmp r12, r10
0000713aae5cf9c9  cmc
0000713aae5cf9ca  lahf
0000713aae5cf9cb  seto al
0000713aae5cf9ce  mov [r15+0x108], eax
0000713aae5cf9d5  mov eax, [rsp+0x10]
0000713aae5cf9d9  mov r12d, [rsp+0x10]
0000713aae5cf9de  shrd eax, r12d, 0x07
0000713aae5cf9e3  mov [rsp+0x10], r11d
0000713aae5cf9e8  mov r10d, [rsp+0x10]
0000713aae5cf9ed  shrd r11d, r10d, 0x11
0000713aae5cf9f2  mov r9d, [rsp+0x20]
0000713aae5cf9f7  lea r8d, [r9d+r14d*1]
0000713aae5cf9fc  rorx r14d, r12d, 0x12
0000713aae5cfa02  xor eax, r14d
0000713aae5cfa05  rorx r14d, r10d, 0x13
0000713aae5cfa0b  xor r11d, r14d
0000713aae5cfa0e  mov [rsp+0x10], r11d
0000713aae5cfa13  mov r11d, r11d
0000713aae5cfa16  mov [r15+0x88], r11
0000713aae5cfa1d  mov [rsp+0x20], r12d
0000713aae5cfa22  shr r12d, 0x03
0000713aae5cfa26  xor eax, r12d
0000713aae5cfa29  mov [rsp+0x40], eax
0000713aae5cfa2d  mov eax, eax
0000713aae5cfa2f  mov [r15+0x80], rax
0000713aae5cfa36  shr r10d, 0x0A
0000713aae5cfa3a  mov eax, [rsp+0x10]
0000713aae5cfa3e  xor eax, r10d
0000713aae5cfa41  mov [rsp+0x10], eax
0000713aae5cfa45  mov eax, eax
0000713aae5cfa47  mov [r15+0x78], rax
0000713aae5cfa4b  mov eax, [rsp+0x40]
0000713aae5cfa4f  lea r14d, [r8d+eax*1]
0000713aae5cfa54  mov eax, [rsp+0x10]
0000713aae5cfa58  lea r12d, [r14d+eax*1]
0000713aae5cfa5d  mov rax, [rsp+0x30]
0000713aae5cfa62  lea r14, [rax+0x40]
0000713aae5cfa66  mov [r13+r14*1], r12d
0000713aae5cfa6b  mov eax, [rsp+0x20]
0000713aae5cfa6f  mov eax, eax
0000713aae5cfa71  mov [r15+0x60], rax
0000713aae5cfa75  mov eax, [r15+0x108]
0000713aae5cfa7c  sahf
0000713aae5cfa7d  jnz 0x0000713AAE5CFAAF
0000713aae5cfa7f  cmp dword ptr [r15+0x318], 0x00
0000713aae5cfa87  jz 0x0000713AAE5CFF70
0000713aae5cfa8d  nop [rax+rax*1], ax
0000713aae5cfa96  nop [rax+rax*1], eax
0000713aae5cfa9e  mov eax, 0x410820
0000713aae5cfaa3  mov [r15+0x100], rax
0000713aae5cfaaa  jmp 0x0000713AAE3FE110
0000713aae5cfaaf  cmp dword ptr [r15+0x318], 0x00
0000713aae5cfab7  jz 0x0000713AAE5CFDC0
0000713aae5cfabd  nop [rax+rax*1], ax
0000713aae5cfac6  nop [rax+rax*1], eax
0000713aae5cface  mov eax, 0x4107D8
0000713aae5cfad3  mov [r15+0x100], rax
0000713aae5cfada  jmp 0x0000713AAE3FE110
0000713aae5cfadf  int3
0000713aae5cfae0  call 0x0000713AAE40D860
0000713aae5cfae5  jmp 0x0000713AAE5CF17A
0000713aae5cfaea  call 0x0000713AAE4E2420
0000713aae5cfaef  jmp 0x0000713AAE5CF193
0000713aae5cfaf4  call 0x0000713AAE4E2420
0000713aae5cfaf9  jmp 0x0000713AAE5CF1AC
0000713aae5cfafe  call 0x0000713AAE4E2420
0000713aae5cfb03  jmp 0x0000713AAE5CF1C5
0000713aae5cfb08  call 0x0000713AAE4E2420
0000713aae5cfb0d  jmp 0x0000713AAE5CF1DE
0000713aae5cfb12  call 0x0000713AAE4E2420
0000713aae5cfb17  jmp 0x0000713AAE5CF1EF
0000713aae5cfb1c  call 0x0000713AAE4E2420
0000713aae5cfb21  jmp 0x0000713AAE5CF200
0000713aae5cfb26  call 0x0000713AAE4E2420
0000713aae5cfb2b  jmp 0x0000713AAE5CF211
0000713aae5cfb30  call 0x0000713AAE4E2420
0000713aae5cfb35  jmp 0x0000713AAE5CF222
0000713aae5cfb3a  call 0x0000713AAE4E2420
0000713aae5cfb3f  jmp 0x0000713AAE5CF233
0000713aae5cfb44  call 0x0000713AAE4E2420
0000713aae5cfb49  jmp 0x0000713AAE5CF244
0000713aae5cfb4e  call 0x0000713AAE4E2420
0000713aae5cfb53  jmp 0x0000713AAE5CF255
0000713aae5cfb58  call 0x0000713AAE4E2420
0000713aae5cfb5d  jmp 0x0000713AAE5CF266
0000713aae5cfb62  call 0x0000713AAE4E2420
0000713aae5cfb67  jmp 0x0000713AAE5CF277
0000713aae5cfb6c  call 0x0000713AAE4E2420
0000713aae5cfb71  jmp 0x0000713AAE5CF288
0000713aae5cfb76  call 0x0000713AAE4E2420
0000713aae5cfb7b  jmp 0x0000713AAE5CF299
0000713aae5cfb80  call 0x0000713AAE4E2420
0000713aae5cfb85  jmp 0x0000713AAE5CF2AA
0000713aae5cfb8a  call 0x0000713AAE4E2420
0000713aae5cfb8f  jmp 0x0000713AAE5CF2BB
0000713aae5cfb94  call 0x0000713AAE4E2420
0000713aae5cfb99  jmp 0x0000713AAE5CF2CC
0000713aae5cfb9e  call 0x0000713AAE4E2420
0000713aae5cfba3  jmp 0x0000713AAE5CF2DD
0000713aae5cfba8  call 0x0000713AAE4E2420
0000713aae5cfbad  jmp 0x0000713AAE5CF2EE
0000713aae5cfbb2  call 0x0000713AAE4E2420
0000713aae5cfbb7  jmp 0x0000713AAE5CF2FF
0000713aae5cfbbc  call 0x0000713AAE4E2420
0000713aae5cfbc1  jmp 0x0000713AAE5CF310
0000713aae5cfbc6  call 0x0000713AAE4E2420
0000713aae5cfbcb  jmp 0x0000713AAE5CF321
0000713aae5cfbd0  call 0x0000713AAE4E2420
0000713aae5cfbd5  jmp 0x0000713AAE5CF332
0000713aae5cfbda  call 0x0000713AAE4E2420
0000713aae5cfbdf  jmp 0x0000713AAE5CF343
0000713aae5cfbe4  call 0x0000713AAE4E2420
0000713aae5cfbe9  jmp 0x0000713AAE5CF354
0000713aae5cfbee  call 0x0000713AAE4E2420
0000713aae5cfbf3  jmp 0x0000713AAE5CF365
0000713aae5cfbf8  call 0x0000713AAE4E2420
0000713aae5cfbfd  jmp 0x0000713AAE5CF376
0000713aae5cfc02  call 0x0000713AAE4E2420
0000713aae5cfc07  jmp 0x0000713AAE5CF387
0000713aae5cfc0c  call 0x0000713AAE4E2420
0000713aae5cfc11  jmp 0x0000713AAE5CF398
0000713aae5cfc16  call 0x0000713AAE4E2420
0000713aae5cfc1b  jmp 0x0000713AAE5CF3A9
0000713aae5cfc20  call 0x0000713AAE4E2420
0000713aae5cfc25  jmp 0x0000713AAE5CF3BA
0000713aae5cfc2a  call 0x0000713AAE4E2420
0000713aae5cfc2f  jmp 0x0000713AAE5CF3CB
0000713aae5cfc34  call 0x0000713AAE4E2420
0000713aae5cfc39  jmp 0x0000713AAE5CF3DC
0000713aae5cfc3e  call 0x0000713AAE4E2420
0000713aae5cfc43  jmp 0x0000713AAE5CF3ED
0000713aae5cfc48  call 0x0000713AAE4E2420
0000713aae5cfc4d  jmp 0x0000713AAE5CF3FE
0000713aae5cfc52  call 0x0000713AAE4E2420
0000713aae5cfc57  jmp 0x0000713AAE5CF40F
0000713aae5cfc5c  call 0x0000713AAE4E2420
0000713aae5cfc61  jmp 0x0000713AAE5CF420
0000713aae5cfc66  call 0x0000713AAE4E2420
0000713aae5cfc6b  jmp 0x0000713AAE5CF431
0000713aae5cfc70  call 0x0000713AAE4E2420
0000713aae5cfc75  jmp 0x0000713AAE5CF442
0000713aae5cfc7a  call 0x0000713AAE4E2420
0000713aae5cfc7f  jmp 0x0000713AAE5CF453
0000713aae5cfc84  call 0x0000713AAE4E2420
0000713aae5cfc89  jmp 0x0000713AAE5CF464
0000713aae5cfc8e  call 0x0000713AAE4E2420
0000713aae5cfc93  jmp 0x0000713AAE5CF475
0000713aae5cfc98  call 0x0000713AAE4E2420
0000713aae5cfc9d  jmp 0x0000713AAE5CF486
0000713aae5cfca2  call 0x0000713AAE4E2420
0000713aae5cfca7  jmp 0x0000713AAE5CF497
0000713aae5cfcac  call 0x0000713AAE4E2420
0000713aae5cfcb1  jmp 0x0000713AAE5CF4A8
0000713aae5cfcb6  call 0x0000713AAE4E2420
0000713aae5cfcbb  jmp 0x0000713AAE5CF4B9
0000713aae5cfcc0  call 0x0000713AAE4E2420
0000713aae5cfcc5  jmp 0x0000713AAE5CF4CA
0000713aae5cfcca  call 0x0000713AAE4E2420
0000713aae5cfccf  jmp 0x0000713AAE5CF4DB
0000713aae5cfcd4  call 0x0000713AAE4E2420
0000713aae5cfcd9  jmp 0x0000713AAE5CF4EC
0000713aae5cfcde  call 0x0000713AAE4E2420
0000713aae5cfce3  jmp 0x0000713AAE5CF4FD
0000713aae5cfce8  call 0x0000713AAE4E2420
0000713aae5cfced  jmp 0x0000713AAE5CF50E
0000713aae5cfcf2  call 0x0000713AAE4E2420
0000713aae5cfcf7  jmp 0x0000713AAE5CF51F
0000713aae5cfcfc  call 0x0000713AAE4E2420
0000713aae5cfd01  jmp 0x0000713AAE5CF530
0000713aae5cfd06  call 0x0000713AAE4E2420
0000713aae5cfd0b  jmp 0x0000713AAE5CF541
0000713aae5cfd10  call 0x0000713AAE4E2420
0000713aae5cfd15  jmp 0x0000713AAE5CF552
0000713aae5cfd1a  call 0x0000713AAE4E2420
0000713aae5cfd1f  jmp 0x0000713AAE5CF563
0000713aae5cfd24  call 0x0000713AAE4E2420
0000713aae5cfd29  jmp 0x0000713AAE5CF574
0000713aae5cfd2e  call 0x0000713AAE4E2420
0000713aae5cfd33  jmp 0x0000713AAE5CF585
0000713aae5cfd38  call 0x0000713AAE4E2420
0000713aae5cfd3d  jmp 0x0000713AAE5CF596
0000713aae5cfd42  call 0x0000713AAE4E2420
0000713aae5cfd47  jmp 0x0000713AAE5CF5AF
0000713aae5cfd4c  call 0x0000713AAE4E2420
0000713aae5cfd51  jmp 0x0000713AAE5CF5C8
0000713aae5cfd56  call 0x0000713AAE4D5610
0000713aae5cfd5b  jmp 0x0000713AAE5CF5E1
0000713aae5cfd60  call 0x0000713AAE4DC580
0000713aae5cfd65  jmp 0x0000713AAE5CF94E
0000713aae5cfd6a  call 0x0000713AAE4E46C0
0000713aae5cfd6f  jmp 0x0000713AAE5CF958
0000713aae5cfd74  call 0x0000713AAE409E90
0000713aae5cfd79  jmp 0x0000713AAE5CF95E
0000713aae5cfd7e  call 0x0000713AAE4DB310
0000713aae5cfd83  jmp 0x0000713AAE5CF968
0000713aae5cfd88  call 0x0000713AAE40DAE0
0000713aae5cfd8d  jmp 0x0000713AAE5CF96D
0000713aae5cfd92  call 0x0000713AAE4C0230
0000713aae5cfd97  jmp 0x0000713AAE5CF986
0000713aae5cfd9c  call 0x0000713AAE4C0230
0000713aae5cfda1  jmp 0x0000713AAE5CF99B
0000713aae5cfda6  call 0x0000713AAE4BEFC0
0000713aae5cfdab  jmp 0x0000713AAE5CF9A4
0000713aae5cfdb0  call 0x0000713AAE4E2BA0
0000713aae5cfdb5  jmp 0x0000713AAE5CFA6B
0000713aae5cfdba  int3
0000713aae5cfdbb  nop [rax+rax*1], eax
0000713aae5cfdc0  mov rax, [r15+0x48]
0000713aae5cfdc4  mov r14, [r15+0x58]
0000713aae5cfdc8  lea r12, [rax+r14*1]
0000713aae5cfdcc  mov [r15+0x68], r12
0000713aae5cfdd0  lea rax, [r14+0x04]
0000713aae5cfdd4  mov [r15+0x58], rax
0000713aae5cfdd8  lea r14, [r12+0x04]
0000713aae5cfddd  mov r11d, [r13+r14*1]
0000713aae5cfde2  mov [rsp+0x10], r11d
0000713aae5cfde7  mov r11d, r11d
0000713aae5cfdea  mov [r15+0x70], r11
0000713aae5cfdee  lea r14, [r12+0x38]
0000713aae5cfdf3  mov r11d, [r13+r14*1]
0000713aae5cfdf8  lea r14, [r12+0x24]
0000713aae5cfdfd  mov r10d, [r13+r14*1]
0000713aae5cfe02  mov [rsp+0x20], r10d
0000713aae5cfe07  mov r10d, r10d
0000713aae5cfe0a  mov [r15+0x90], r10
0000713aae5cfe11  mov [rsp+0x30], rax
0000713aae5cfe16  xor eax, eax
0000713aae5cfe18  mov r14, [rsp+0x30]
0000713aae5cfe1d  mov r10d, 0xC0
0000713aae5cfe23  cmp r14, r10
0000713aae5cfe26  cmc
0000713aae5cfe27  lahf
0000713aae5cfe28  seto al
0000713aae5cfe2b  mov [r15+0x108], eax
0000713aae5cfe32  mov eax, [rsp+0x10]
0000713aae5cfe36  mov r14d, [rsp+0x10]
0000713aae5cfe3b  shrd eax, r14d, 0x07
0000713aae5cfe40  mov [rsp+0x10], r11d
0000713aae5cfe45  mov r10d, [rsp+0x10]
0000713aae5cfe4a  shrd r11d, r10d, 0x11
0000713aae5cfe4f  mov r9d, [r15+0x60]
0000713aae5cfe53  mov r8d, [rsp+0x20]
0000713aae5cfe58  lea ebp, [r8d+r9d*1]
0000713aae5cfe5d  rorx r9d, r14d, 0x12
0000713aae5cfe63  xor eax, r9d
0000713aae5cfe66  rorx r9d, r10d, 0x13
0000713aae5cfe6c  xor r11d, r9d
0000713aae5cfe6f  mov [rsp+0x10], r11d
0000713aae5cfe74  mov r11d, r11d
0000713aae5cfe77  mov [r15+0x88], r11
0000713aae5cfe7e  mov [rsp+0x20], r14d
0000713aae5cfe83  shr r14d, 0x03
0000713aae5cfe87  xor eax, r14d
0000713aae5cfe8a  mov [rsp+0x30], eax
0000713aae5cfe8e  mov eax, eax
0000713aae5cfe90  mov [r15+0x80], rax
0000713aae5cfe97  shr r10d, 0x0A
0000713aae5cfe9b  mov eax, [rsp+0x10]
0000713aae5cfe9f  xor eax, r10d
0000713aae5cfea2  mov [rsp+0x10], eax
0000713aae5cfea6  mov eax, eax
0000713aae5cfea8  mov [r15+0x78], rax
0000713aae5cfeac  mov eax, [rsp+0x30]
0000713aae5cfeb0  lea r14d, [ebp+eax*1]
0000713aae5cfeb6  mov eax, [rsp+0x10]
0000713aae5cfeba  lea r11d, [r14d+eax*1]
0000713aae5cfebf  lea rax, [r12+0x40]
0000713aae5cfec4  mov [r13+rax*1], r11d
0000713aae5cfec9  mov eax, [rsp+0x20]
0000713aae5cfecd  mov eax, eax
0000713aae5cfecf  mov [r15+0x60], rax
0000713aae5cfed3  mov eax, [r15+0x108]
0000713aae5cfeda  sahf
0000713aae5cfedb  jnz 0x0000713AAE5CFF0D
0000713aae5cfedd  cmp dword ptr [r15+0x318], 0x00
0000713aae5cfee5  jz 0x0000713AAE5CFF70
0000713aae5cfeeb  nop [rax+rax*1], ax
0000713aae5cfef4  nop [rax+rax*1], eax
0000713aae5cfefc  mov eax, 0x410820
0000713aae5cff01  mov [r15+0x100], rax
0000713aae5cff08  jmp 0x0000713AAE3FE110
0000713aae5cff0d  cmp dword ptr [r15+0x318], 0x00
0000713aae5cff15  jz 0x0000713AAE5CFDC0
0000713aae5cff1b  nop [rax+rax*1], ax
0000713aae5cff24  nop [rax+rax*1], eax
0000713aae5cff2c  mov eax, 0x4107D8
0000713aae5cff31  mov [r15+0x100], rax
0000713aae5cff38  jmp 0x0000713AAE3FE110
0000713aae5cff3d  int3
0000713aae5cff3e  call 0x0000713AAE4E1430
0000713aae5cff43  jmp 0x0000713AAE5CFDE2
0000713aae5cff48  call 0x0000713AAE4E1430
0000713aae5cff4d  jmp 0x0000713AAE5CFDF8
0000713aae5cff52  call 0x0000713AAE4E01C0
0000713aae5cff57  jmp 0x0000713AAE5CFE02
0000713aae5cff5c  call 0x0000713AAE40A860
0000713aae5cff61  jmp 0x0000713AAE5CFEC9
0000713aae5cff66  int3
0000713aae5cff67  nop [rax+rax*1], ax
0000713aae5cff70  mov rax, [r15]
0000713aae5cff73  mov r14d, [r13+rax*1]
0000713aae5cff78  lea r12, [rax+0x04]
0000713aae5cff7c  mov r11d, [r13+r12*1]
0000713aae5cff81  mov [rsp+0x10], r14d
0000713aae5cff86  mov r14d, r14d
0000713aae5cff89  mov [r15+0x78], r14
0000713aae5cff8d  mov [rsp+0x20], r11d
0000713aae5cff92  mov r11d, r11d
0000713aae5cff95  mov [r15+0x80], r11
0000713aae5cff9c  lea r14, [rax+0x08]
0000713aae5cffa0  mov r12d, [r13+r14*1]
0000713aae5cffa5  lea r14, [rax+0x0C]
0000713aae5cffa9  mov r11d, [r13+r14*1]
0000713aae5cffae  mov [rsp+0x30], r12d
0000713aae5cffb3  mov r12d, r12d
0000713aae5cffb6  mov [r15+0x70], r12
0000713aae5cffba  mov [rsp+0x40], r11d
0000713aae5cffbf  mov r11d, r11d
0000713aae5cffc2  mov [r15+0x68], r11
0000713aae5cffc6  lea r14, [rax+0x18]
0000713aae5cffca  mov r12d, [r13+r14*1]
0000713aae5cffcf  lea r14, [rax+0x1C]
0000713aae5cffd3  mov r11d, [r13+r14*1]
0000713aae5cffd8  mov [rsp+0x50], r12d
0000713aae5cffdd  mov r12d, r12d
0000713aae5cffe0  mov [r15+0x58], r12
0000713aae5cffe4  mov [rsp+0x60], r11d
0000713aae5cffe9  mov r11d, r11d
0000713aae5cffec  mov [r15+0x60], r11
0000713aae5cfff0  lea r14, [rax+0x10]
0000713aae5cfff4  mov r12d, [r13+r14*1]
0000713aae5cfff9  lea r14, [rax+0x14]
0000713aae5cfffd  mov eax, [r13+r14*1]
0000713aae5d0002  mov [rsp+0x70], r12d
0000713aae5d0007  mov r12d, r12d
0000713aae5d000a  mov [r15+0x18], r12
0000713aae5d000e  mov [rsp+0x80], eax
0000713aae5d0015  mov eax, eax
0000713aae5d0017  mov [r15+0x90], rax
0000713aae5d001e  mov eax, [rsp+0x70]
0000713aae5d0022  mov eax, eax
0000713aae5d0024  mov [r15+0x30], rax
0000713aae5d0028  mov eax, [rsp+0x50]
0000713aae5d002c  mov eax, eax
0000713aae5d002e  mov [r15+0xA0], rax
0000713aae5d0035  mov eax, [rsp+0x30]
0000713aae5d0039  mov eax, eax
0000713aae5d003b  mov [r15+0x28], rax
0000713aae5d003f  mov eax, [rsp+0x20]
0000713aae5d0043  mov eax, eax
0000713aae5d0045  mov [r15+0x98], rax
0000713aae5d004c  mov eax, [rsp+0x10]
0000713aae5d0050  mov eax, eax
0000713aae5d0052  mov [r15+0x38], rax
0000713aae5d0056  mov eax, [rsp+0x70]
0000713aae5d005a  mov r14d, [rsp+0x70]
0000713aae5d005f  shrd eax, r14d, 0x06
0000713aae5d0064  mov [rsp+0x70], r14d
0000713aae5d0069  mov r12d, [rsp+0x80]
0000713aae5d0071  and r14d, r12d
0000713aae5d0074  mov r11d, [rsp+0x10]
0000713aae5d0079  mov r10d, [rsp+0x10]
0000713aae5d007e  shrd r11d, r10d, 0x02
0000713aae5d0083  mov [rsp+0x10], r12d
0000713aae5d0088  mov r12d, r12d
0000713aae5d008b  mov [r15+0x20], r12
0000713aae5d008f  mov r12, [r15+0x50]
0000713aae5d0093  mov r9d, [r13+r12*1]
0000713aae5d0098  mov r12d, [rsp+0x50]
0000713aae5d009d  mov r8d, [rsp+0x70]
0000713aae5d00a2  andn ebp, r8d, r12d
0000713aae5d00a7  mov edi, [rsp+0x60]
0000713aae5d00ab  lea esi, [r14d+edi*1]
0000713aae5d00b0  rorx r14d, r8d, 0x0B
0000713aae5d00b6  xor eax, r14d
0000713aae5d00b9  rorx r14d, r10d, 0x0D
0000713aae5d00bf  xor r11d, r14d
0000713aae5d00c2  lea edi, [esi+ebp*1]
0000713aae5d00c6  mov r14, [r15+0x48]
0000713aae5d00ca  mov ebp, [r13+r14*1]
0000713aae5d00cf  mov r14d, [rsp+0x30]
0000713aae5d00d4  mov esi, [rsp+0x20]
0000713aae5d00d8  and r14d, esi
0000713aae5d00db  mov [rsp+0x20], r14d
0000713aae5d00e0  mov r14d, r14d
0000713aae5d00e3  mov [r15+0xD8], r14
0000713aae5d00ea  lea r14d, [edi+r9d*1]
0000713aae5d00ef  mov r9d, [rsp+0x30]
0000713aae5d00f4  xor r9d, esi
0000713aae5d00f7  rorx edi, r8d, 0x19
0000713aae5d00fd  xor eax, edi
0000713aae5d00ff  and r9d, r10d
0000713aae5d0102  rorx edi, r10d, 0x16
0000713aae5d0108  xor r11d, edi
0000713aae5d010b  mov [rsp+0x30], r11d
0000713aae5d0110  mov r11d, r11d
0000713aae5d0113  mov [r15+0xD0], r11
0000713aae5d011a  lea r11d, [r14d+ebp*1]
0000713aae5d011f  mov r10d, [rsp+0x20]
0000713aae5d0124  xor r9d, r10d
0000713aae5d0127  lea r14d, [r11d+eax*1]
0000713aae5d012c  mov qword ptr [r15+0x88], 0x04
0000713aae5d0137  mov eax, [rsp+0x30]
0000713aae5d013b  lea r11d, [r9d+eax*1]
0000713aae5d0140  mov eax, [rsp+0x40]
0000713aae5d0144  lea r10d, [r14d+eax*1]
0000713aae5d0149  mov r10d, r10d
0000713aae5d014c  mov [r15+0xB8], r10
0000713aae5d0153  xor eax, eax
0000713aae5d0155  mov r10d, 0x04
0000713aae5d015b  mov r9d, 0x100
0000713aae5d0161  cmp r10, r9
0000713aae5d0164  cmc
0000713aae5d0165  lahf
0000713aae5d0166  seto al
0000713aae5d0169  mov [r15+0x108], eax
0000713aae5d0170  lea eax, [r11d+r14d*1]
0000713aae5d0175  mov eax, eax
0000713aae5d0177  mov [r15+0xA8], rax
0000713aae5d017e  mov r12d, r12d
0000713aae5d0181  mov [r15+0xB0], r12
0000713aae5d0188  mov eax, [rsp+0x10]
0000713aae5d018c  mov eax, eax
0000713aae5d018e  mov [r15+0xC0], rax
0000713aae5d0195  mov r8d, r8d
0000713aae5d0198  mov [r15+0xC8], r8
0000713aae5d019f  mov eax, [r15+0x108]
0000713aae5d01a6  sahf
0000713aae5d01a7  jnz 0x0000713AAE5D01D9
0000713aae5d01a9  cmp dword ptr [r15+0x318], 0x00
0000713aae5d01b1  jz 0x0000713AAE5D04A0
0000713aae5d01b7  nop [rax+rax*1], ax
0000713aae5d01c0  nop [rax+rax*1], eax
0000713aae5d01c8  mov eax, 0x4108E0
0000713aae5d01cd  mov [r15+0x100], rax
0000713aae5d01d4  jmp 0x0000713AAE3FE110
0000713aae5d01d9  cmp dword ptr [r15+0x318], 0x00
0000713aae5d01e1  jz 0x0000713AAE5D0270
0000713aae5d01e7  nop [rax+rax*1], ax
0000713aae5d01f0  nop [rax+rax*1], eax
0000713aae5d01f8  mov eax, 0x410854
0000713aae5d01fd  mov [r15+0x100], rax
0000713aae5d0204  jmp 0x0000713AAE3FE110
0000713aae5d0209  int3
0000713aae5d020a  call 0x0000713AAE40DAE0
0000713aae5d020f  jmp 0x0000713AAE5CFF78
0000713aae5d0214  call 0x0000713AAE4C0230
0000713aae5d0219  jmp 0x0000713AAE5CFF81
0000713aae5d021e  call 0x0000713AAE4E26A0
0000713aae5d0223  jmp 0x0000713AAE5CFFA5
0000713aae5d0228  call 0x0000713AAE4E1430
0000713aae5d022d  jmp 0x0000713AAE5CFFAE
0000713aae5d0232  call 0x0000713AAE4E26A0
0000713aae5d0237  jmp 0x0000713AAE5CFFCF
0000713aae5d023c  call 0x0000713AAE4E1430
0000713aae5d0241  jmp 0x0000713AAE5CFFD8
0000713aae5d0246  call 0x0000713AAE4E26A0
0000713aae5d024b  jmp 0x0000713AAE5CFFF9
0000713aae5d0250  call 0x0000713AAE4D5890
0000713aae5d0255  jmp 0x0000713AAE5D0002
0000713aae5d025a  call 0x0000713AAE4BDD50
0000713aae5d025f  jmp 0x0000713AAE5D0098
0000713aae5d0264  call 0x0000713AAE4DA580
0000713aae5d0269  jmp 0x0000713AAE5D00CF
0000713aae5d026e  int3
0000713aae5d026f  nop
0000713aae5d0270  mov eax, [r15+0xB8]
0000713aae5d0277  mov [rsp+0x10], eax
0000713aae5d027b  mov eax, eax
0000713aae5d027d  mov [r15+0x30], rax
0000713aae5d0281  mov eax, [r15+0xC0]
0000713aae5d0288  mov [rsp+0x20], eax
0000713aae5d028c  mov eax, eax
0000713aae5d028e  mov [r15+0xA0], rax
0000713aae5d0295  mov eax, [r15+0x28]
0000713aae5d0299  mov r14d, [r15+0x98]
0000713aae5d02a0  mov [rsp+0x30], r14d
0000713aae5d02a5  mov r14d, r14d
0000713aae5d02a8  mov [r15+0x28], r14
0000713aae5d02ac  mov r14d, [r15+0x38]
0000713aae5d02b0  mov [rsp+0x40], r14d
0000713aae5d02b5  mov r14d, r14d
0000713aae5d02b8  mov [r15+0x98], r14
0000713aae5d02bf  mov r14d, [r15+0xA8]
0000713aae5d02c6  mov [rsp+0x50], r14d
0000713aae5d02cb  mov r14d, r14d
0000713aae5d02ce  mov [r15+0x38], r14
0000713aae5d02d2  mov r14d, [rsp+0x10]
0000713aae5d02d7  mov r12d, [rsp+0x10]
0000713aae5d02dc  shrd r14d, r12d, 0x06
0000713aae5d02e1  mov r11d, [r15+0xC8]
0000713aae5d02e8  mov [rsp+0x10], r12d
0000713aae5d02ed  and r12d, r11d
0000713aae5d02f0  mov r10d, [rsp+0x50]
0000713aae5d02f5  mov r9d, [rsp+0x50]
0000713aae5d02fa  shrd r10d, r9d, 0x02
0000713aae5d02ff  mov [rsp+0x50], r11d
0000713aae5d0304  mov r11d, r11d
0000713aae5d0307  mov [r15+0x20], r11
0000713aae5d030b  mov r11, [r15+0x88]
0000713aae5d0312  mov r8, [r15+0x50]
0000713aae5d0316  lea rbp, [r8+r11*1]
0000713aae5d031a  mov r8d, [r13+rbp*1]
0000713aae5d031f  mov ebp, [rsp+0x20]
0000713aae5d0323  mov edi, [rsp+0x10]
0000713aae5d0327  andn esi, edi, ebp
0000713aae5d032c  mov edx, [r15+0xB0]
0000713aae5d0333  lea ecx, [r12d+edx*1]
0000713aae5d0338  rorx r12d, edi, 0x0B
0000713aae5d033e  xor r14d, r12d
0000713aae5d0341  rorx r12d, r9d, 0x0D
0000713aae5d0347  xor r10d, r12d
0000713aae5d034a  lea r12d, [ecx+esi*1]
0000713aae5d034f  mov rsi, [r15+0x48]
0000713aae5d0353  lea rdx, [rsi+r11*1]
0000713aae5d0357  mov esi, [r13+rdx*1]
0000713aae5d035c  mov edx, [rsp+0x30]
0000713aae5d0360  mov ecx, [rsp+0x40]
0000713aae5d0364  and edx, ecx
0000713aae5d0366  mov [rsp+0x10], edx
0000713aae5d036a  mov edx, edx
0000713aae5d036c  mov [r15+0xD8], rdx
0000713aae5d0373  lea edx, [r12d+r8d*1]
0000713aae5d0378  mov r12d, [rsp+0x30]
0000713aae5d037d  xor r12d, ecx
0000713aae5d0380  rorx r8d, edi, 0x19
0000713aae5d0386  xor r14d, r8d
0000713aae5d0389  and r12d, r9d
0000713aae5d038c  rorx r8d, r9d, 0x16
0000713aae5d0392  xor r10d, r8d
0000713aae5d0395  mov [rsp+0x20], r10d
0000713aae5d039a  mov r10d, r10d
0000713aae5d039d  mov [r15+0xD0], r10
0000713aae5d03a4  lea r10d, [edx+esi*1]
0000713aae5d03a9  mov r9d, [rsp+0x10]
0000713aae5d03ae  xor r12d, r9d
0000713aae5d03b1  lea r9d, [r10d+r14d*1]
0000713aae5d03b6  lea r14, [r11+0x04]
0000713aae5d03ba  mov [r15+0x88], r14
0000713aae5d03c1  mov r11d, [rsp+0x20]
0000713aae5d03c6  lea r10d, [r12d+r11d*1]
0000713aae5d03cb  lea r11d, [r9d+eax*1]
0000713aae5d03d0  mov r11d, r11d
0000713aae5d03d3  mov [r15+0xB8], r11
0000713aae5d03da  xor eax, eax
0000713aae5d03dc  mov r12d, 0x100
0000713aae5d03e2  cmp r14, r12
0000713aae5d03e5  cmc
0000713aae5d03e6  lahf
0000713aae5d03e7  seto al
0000713aae5d03ea  mov [r15+0x108], eax
0000713aae5d03f1  lea eax, [r10d+r9d*1]
0000713aae5d03f6  mov eax, eax
0000713aae5d03f8  mov [r15+0xA8], rax
0000713aae5d03ff  mov ebp, ebp
0000713aae5d0401  mov [r15+0xB0], rbp
0000713aae5d0408  mov eax, [rsp+0x50]
0000713aae5d040c  mov eax, eax
0000713aae5d040e  mov [r15+0xC0], rax
0000713aae5d0415  mov edi, edi
0000713aae5d0417  mov [r15+0xC8], rdi
0000713aae5d041e  mov eax, [r15+0x108]
0000713aae5d0425  sahf
0000713aae5d0426  jnz 0x0000713AAE5D0458
0000713aae5d0428  cmp dword ptr [r15+0x318], 0x00
0000713aae5d0430  jz 0x0000713AAE5D04A0
0000713aae5d0436  nop [rax+rax*1], ax
0000713aae5d043f  nop [rax+rax*1], eax
0000713aae5d0447  mov eax, 0x4108E0
0000713aae5d044c  mov [r15+0x100], rax
0000713aae5d0453  jmp 0x0000713AAE3FE110
0000713aae5d0458  cmp dword ptr [r15+0x318], 0x00
0000713aae5d0460  jz 0x0000713AAE5D0270
0000713aae5d0466  nop [rax+rax*1], ax
0000713aae5d046f  nop [rax+rax*1], eax
0000713aae5d0477  mov eax, 0x410854
0000713aae5d047c  mov [r15+0x100], rax
0000713aae5d0483  jmp 0x0000713AAE3FE110
0000713aae5d0488  int3
0000713aae5d0489  call 0x0000713AAE449010
0000713aae5d048e  jmp 0x0000713AAE5D031F
0000713aae5d0493  call 0x0000713AAE425930
0000713aae5d0498  jmp 0x0000713AAE5D035C
0000713aae5d049d  int3
0000713aae5d049e  nop
0000713aae5d04a0  mov eax, [r15+0x98]
0000713aae5d04a7  mov r14d, [r15+0x70]
0000713aae5d04ab  lea r12d, [eax+r14d*1]
0000713aae5d04b0  mov eax, [r15+0x28]
0000713aae5d04b4  mov r14d, [r15+0x68]
0000713aae5d04b8  lea r11d, [eax+r14d*1]
0000713aae5d04bd  mov qword ptr [r15+0x88], 0x00
0000713aae5d04c8  mov eax, [r15+0xA8]
0000713aae5d04cf  mov r14d, [r15+0x78]
0000713aae5d04d3  lea r10d, [eax+r14d*1]
0000713aae5d04d8  mov [rsp+0x10], r10d
0000713aae5d04dd  mov r10d, r10d
0000713aae5d04e0  mov [r15+0x78], r10
0000713aae5d04e4  mov eax, [r15+0x38]
0000713aae5d04e8  mov r14d, [r15+0x80]
0000713aae5d04ef  lea r10d, [eax+r14d*1]
0000713aae5d04f4  mov [rsp+0x20], r10d
0000713aae5d04f9  mov r10d, r10d
0000713aae5d04fc  mov [r15+0x80], r10
0000713aae5d0503  mov rax, [r15]
0000713aae5d0506  lea r14, [rax+0x08]
0000713aae5d050a  mov [r13+r14*1], r12d
0000713aae5d050f  lea r14, [rax+0x0C]
0000713aae5d0513  mov [r13+r14*1], r11d
0000713aae5d0518  mov r14d, [r15+0xB8]
0000713aae5d051f  mov r12d, [r15+0x18]
0000713aae5d0523  lea r11d, [r14d+r12d*1]
0000713aae5d0528  mov [rsp+0x30], r11d
0000713aae5d052d  mov r11d, r11d
0000713aae5d0530  mov [r15+0x68], r11
0000713aae5d0534  mov r14d, [r15+0x30]
0000713aae5d0538  mov r12d, [r15+0x90]
0000713aae5d053f  lea r11d, [r14d+r12d*1]
0000713aae5d0544  mov [rsp+0x40], r11d
0000713aae5d0549  mov r11d, r11d
0000713aae5d054c  mov [r15+0x70], r11
0000713aae5d0550  mov r14d, [r15+0x20]
0000713aae5d0554  mov r12d, [r15+0x58]
0000713aae5d0558  lea r11d, [r14d+r12d*1]
0000713aae5d055d  mov [rsp+0x50], r11d
0000713aae5d0562  mov r11d, r11d
0000713aae5d0565  mov [r15+0x58], r11
0000713aae5d0569  mov r14d, [r15+0xA0]
0000713aae5d0570  mov r12d, [r15+0x60]
0000713aae5d0574  lea r11d, [r14d+r12d*1]
0000713aae5d0579  mov [rsp+0x60], r11d
0000713aae5d057e  mov r11d, r11d
0000713aae5d0581  mov [r15+0x60], r11
0000713aae5d0585  mov r14d, [rsp+0x10]
0000713aae5d058a  mov [r13+rax*1], r14d
0000713aae5d058f  lea r14, [rax+0x04]
0000713aae5d0593  mov r12d, [rsp+0x20]
0000713aae5d0598  mov [r13+r14*1], r12d
0000713aae5d059d  lea r14, [rax+0x10]
0000713aae5d05a1  mov r12d, [rsp+0x30]
0000713aae5d05a6  mov [r13+r14*1], r12d
0000713aae5d05ab  lea r14, [rax+0x14]
0000713aae5d05af  mov r12d, [rsp+0x40]
0000713aae5d05b4  mov [r13+r14*1], r12d
0000713aae5d05b9  lea r14, [rax+0x18]
0000713aae5d05bd  mov r12d, [rsp+0x50]
0000713aae5d05c2  mov [r13+r14*1], r12d
0000713aae5d05c7  lea r14, [rax+0x1C]
0000713aae5d05cb  mov r12d, [rsp+0x60]
0000713aae5d05d0  mov [r13+r14*1], r12d
0000713aae5d05d5  lea r14, [rax+0x68]
0000713aae5d05d9  xor eax, eax
0000713aae5d05db  mov [r13+r14*1], rax
0000713aae5d05e0  cmp dword ptr [r15+0x318], 0x00
0000713aae5d05e8  jz 0x0000713AAE5CF0E0
0000713aae5d05ee  nop [rax+rax*1], ax
0000713aae5d05f7  nop [rax+rax*1], eax
0000713aae5d05ff  mov eax, 0x4106FC
0000713aae5d0604  mov [r15+0x100], rax
0000713aae5d060b  jmp 0x0000713AAE3FE110
0000713aae5d0610  int3
0000713aae5d0611  call 0x0000713AAE4E2BA0
0000713aae5d0616  jmp 0x0000713AAE5D050F
0000713aae5d061b  call 0x0000713AAE4E1920
0000713aae5d0620  jmp 0x0000713AAE5D0518
0000713aae5d0625  call 0x0000713AAE40DFE0
0000713aae5d062a  jmp 0x0000713AAE5D058F
0000713aae5d062f  call 0x0000713AAE4E2BA0
0000713aae5d0634  jmp 0x0000713AAE5D059D
0000713aae5d0639  call 0x0000713AAE4E2BA0
0000713aae5d063e  jmp 0x0000713AAE5D05AB
0000713aae5d0643  call 0x0000713AAE4E2BA0
0000713aae5d0648  jmp 0x0000713AAE5D05B9
0000713aae5d064d  call 0x0000713AAE4E2BA0
0000713aae5d0652  jmp 0x0000713AAE5D05C7
0000713aae5d0657  call 0x0000713AAE4E2BA0
0000713aae5d065c  jmp 0x0000713AAE5D05D5
0000713aae5d0661  call 0x0000713AAE4D5EB0
0000713aae5d0666  jmp 0x0000713AAE5D05E0
0000713aae5d066b  int3
0000713aae5d066c  nop [rax], eax
0000713aae5d0670  mov rax, [r15+0xF8]
0000713aae5d0677  lea r14, [rax+0x140]
0000713aae5d067e  mov r12, [r13+r14*1]
0000713aae5d0683  lea r14, [rax+0x148]
0000713aae5d068a  mov r11, [r13+r14*1]
0000713aae5d068f  mov [r15+0xA0], r12
0000713aae5d0696  mov [r15+0x98], r11
0000713aae5d069d  lea r14, [rax+0x130]
0000713aae5d06a4  mov r12, [r13+r14*1]
0000713aae5d06a9  lea r14, [rax+0x138]
0000713aae5d06b0  mov r11, [r13+r14*1]
0000713aae5d06b5  mov [r15+0xB0], r12
0000713aae5d06bc  mov [r15+0xA8], r11
0000713aae5d06c3  lea r14, [rax+0x120]
0000713aae5d06ca  mov r12, [r13+r14*1]
0000713aae5d06cf  lea r14, [rax+0x128]
0000713aae5d06d6  mov r11, [r13+r14*1]
0000713aae5d06db  mov [r15+0xC0], r12
0000713aae5d06e2  mov [r15+0xB8], r11
0000713aae5d06e9  lea r14, [rax+0x110]
0000713aae5d06f0  mov r12, [r13+r14*1]
0000713aae5d06f5  lea r14, [rax+0x118]
0000713aae5d06fc  mov r11, [r13+r14*1]
0000713aae5d0701  mov [r15+0xD0], r12
0000713aae5d0708  mov [r15+0xC8], r11
0000713aae5d070f  lea r14, [rax+0x100]
0000713aae5d0716  mov r12, [r13+r14*1]
0000713aae5d071b  lea r14, [rax+0x108]
0000713aae5d0722  mov r11, [r13+r14*1]
0000713aae5d0727  mov [r15+0xE8], r12
0000713aae5d072e  mov [r15+0xD8], r11
0000713aae5d0735  lea r14, [rax+0x150]
0000713aae5d073c  mov [r15+0xF8], r14
0000713aae5d0743  mov rax, [r15+0xF0]
0000713aae5d074a  mov [r15+0x100], rax
0000713aae5d0751  jmp 0x0000713AAE5CE5C0
0000713aae5d0756  int3
0000713aae5d0757  call 0x0000713AAE4E27E0
0000713aae5d075c  jmp 0x0000713AAE5D0683
0000713aae5d0761  call 0x0000713AAE4E1570
0000713aae5d0766  jmp 0x0000713AAE5D068F
0000713aae5d076b  call 0x0000713AAE4E27E0
0000713aae5d0770  jmp 0x0000713AAE5D06A9
0000713aae5d0775  call 0x0000713AAE4E1570
0000713aae5d077a  jmp 0x0000713AAE5D06B5
0000713aae5d077f  call 0x0000713AAE4E27E0
0000713aae5d0784  jmp 0x0000713AAE5D06CF
0000713aae5d0789  call 0x0000713AAE4E1570
0000713aae5d078e  jmp 0x0000713AAE5D06DB
0000713aae5d0793  call 0x0000713AAE4E27E0
0000713aae5d0798  jmp 0x0000713AAE5D06F5
0000713aae5d079d  call 0x0000713AAE4E1570
0000713aae5d07a2  jmp 0x0000713AAE5D0701
0000713aae5d07a7  call 0x0000713AAE4E27E0
0000713aae5d07ac  jmp 0x0000713AAE5D071B
0000713aae5d07b1  call 0x0000713AAE4E1570
0000713aae5d07b6  jmp 0x0000713AAE5D0727
0000713aae5d07bb  int3
0000713aae5d07bc  nop [rax], eax
0000713aae5d07c0  mov eax, [r15+0xA0]
0000713aae5d07c7  mov [rsp+0x10], eax
0000713aae5d07cb  xor eax, eax
0000713aae5d07cd  mov r14d, [rsp+0x10]
0000713aae5d07d2  sub r14d, 0x01
0000713aae5d07d6  cmc
0000713aae5d07d7  lahf
0000713aae5d07d8  seto al
0000713aae5d07db  mov [r15+0x108], eax
0000713aae5d07e2  mov r14d, r14d
0000713aae5d07e5  mov [r15+0xA0], r14
0000713aae5d07ec  mov eax, [r15+0x108]
0000713aae5d07f3  sahf
0000713aae5d07f4  jnz 0x0000713AAE5D0826
0000713aae5d07f6  cmp dword ptr [r15+0x318], 0x00
0000713aae5d07fe  jz 0x0000713AAE5D0900
0000713aae5d0804  nop [rax+rax*1], ax
0000713aae5d080d  nop [rax+rax*1], eax
0000713aae5d0815  mov eax, 0x41028C
0000713aae5d081a  mov [r15+0x100], rax
0000713aae5d0821  jmp 0x0000713AAE3FE110
0000713aae5d0826  cmp dword ptr [r15+0x318], 0x00
0000713aae5d082e  jz 0x0000713AAE5D0860
0000713aae5d0834  nop [rax+rax*1], ax
0000713aae5d083d  nop [rax+rax*1], eax
0000713aae5d0845  mov eax, 0x410274
0000713aae5d084a  mov [r15+0x100], rax
0000713aae5d0851  jmp 0x0000713AAE3FE110
0000713aae5d0856  int3
0000713aae5d0857  int3
0000713aae5d0858  nop [rax+rax*1], eax
0000713aae5d0860  mov rax, [r15+0xF8]
0000713aae5d0867  lea r14, [rax+0xD0]
0000713aae5d086e  mov [r15], r14
0000713aae5d0871  mov rax, [r15+0x98]
0000713aae5d0878  mov [r15+0x08], rax
0000713aae5d087c  mov qword ptr [r15+0x10], 0x12C
0000713aae5d0884  mov qword ptr [r15+0xF0], 0x410284
0000713aae5d088f  mov r14d, [r15+0x320]
0000713aae5d0896  mov eax, 0x410284
0000713aae5d089b  mov rcx, 0x713AAE5D07C0
0000713aae5d08a5  mov [r15+r14*8+0x328], rax
0000713aae5d08ad  mov [r15+r14*8+0x368], rcx
0000713aae5d08b5  add r14d, 0x01
0000713aae5d08b9  and r14d, 0x07
0000713aae5d08bd  mov [r15+0x320], r14d
0000713aae5d08c4  cmp dword ptr [r15+0x318], 0x00
0000713aae5d08cc  jz 0x0000713AAE5CED70
0000713aae5d08d2  nop [rax+rax*1], ax
0000713aae5d08db  nop [rax+rax*1], eax
0000713aae5d08e3  mov eax, 0x4106BC
0000713aae5d08e8  mov [r15+0x100], rax
0000713aae5d08ef  jmp 0x0000713AAE3FE110
0000713aae5d08f4  int3
0000713aae5d08f5  int3
0000713aae5d08f6  nop [rax+rax*1], ax
0000713aae5d08ff  nop
0000713aae5d0900  mov rax, [r15+0xF8]
0000713aae5d0907  lea r14, [rax+0xF0]
0000713aae5d090e  mov r12, [r13+r14*1]
0000713aae5d0913  mov [r15+0x98], r12
0000713aae5d091a  mov qword ptr [r15+0x40], 0x80
0000713aae5d0922  lea r14, [rax+0xD0]
0000713aae5d0929  mov [r15], r14
0000713aae5d092c  lea r14, [rax+0x14C]
0000713aae5d0933  mov [r15+0x08], r14
0000713aae5d0937  mov qword ptr [r15+0x10], 0x01
0000713aae5d093f  lea r14, [rax+0x14C]
0000713aae5d0946  mov eax, 0x80
0000713aae5d094b  mov [r13+r14*1], al
0000713aae5d0950  mov qword ptr [r15+0xF0], 0x4102A8
0000713aae5d095b  mov r14d, [r15+0x320]
0000713aae5d0962  mov eax, 0x4102A8
0000713aae5d0967  mov rcx, 0x713AAE5D09E0
0000713aae5d0971  mov [r15+r14*8+0x328], rax
0000713aae5d0979  mov [r15+r14*8+0x368], rcx
0000713aae5d0981  add r14d, 0x01
0000713aae5d0985  and r14d, 0x07
0000713aae5d0989  mov [r15+0x320], r14d
0000713aae5d0990  cmp dword ptr [r15+0x318], 0x00
0000713aae5d0998  jz 0x0000713AAE5CED70
0000713aae5d099e  nop [rax+rax*1], ax
0000713aae5d09a7  nop [rax+rax*1], eax
0000713aae5d09af  mov eax, 0x4106BC
0000713aae5d09b4  mov [r15+0x100], rax
0000713aae5d09bb  jmp 0x0000713AAE3FE110
0000713aae5d09c0  int3
0000713aae5d09c1  call 0x0000713AAE4E27E0
0000713aae5d09c6  jmp 0x0000713AAE5D0913
0000713aae5d09cb  call 0x0000713AAE4D5AF0
0000713aae5d09d0  jmp 0x0000713AAE5D0950
0000713aae5d09d5  int3
0000713aae5d09d6  nop [rax+rax*1], ax
0000713aae5d09df  nop
0000713aae5d09e0  mov rax, [r15+0xF8]
0000713aae5d09e7  lea r14, [rax+0x138]
0000713aae5d09ee  mov r12, [r13+r14*1]
0000713aae5d09f3  mov [r15+0x40], r12
0000713aae5d09f7  lea r14, [rax+0x148]
0000713aae5d09fe  xor eax, eax
0000713aae5d0a00  mov [r13+r14*1], al
0000713aae5d0a05  xor eax, eax
0000713aae5d0a07  mov r14d, 0x38
0000713aae5d0a0d  cmp r12, r14
0000713aae5d0a10  cmc
0000713aae5d0a11  lahf
0000713aae5d0a12  seto al
0000713aae5d0a15  mov [r15+0x108], eax
0000713aae5d0a1c  mov eax, [r15+0x108]
0000713aae5d0a23  sahf
0000713aae5d0a24  jz 0x0000713AAE5D0A56
0000713aae5d0a26  cmp dword ptr [r15+0x318], 0x00
0000713aae5d0a2e  jz 0x0000713AAE5D0AA0
0000713aae5d0a34  nop [rax+rax*1], ax
0000713aae5d0a3d  nop [rax+rax*1], eax
0000713aae5d0a45  mov eax, 0x4102B8
0000713aae5d0a4a  mov [r15+0x100], rax
0000713aae5d0a51  jmp 0x0000713AAE3FE110
0000713aae5d0a56  cmp dword ptr [r15+0x318], 0x00
0000713aae5d0a5e  jz 0x0000713AAE5D0BF0
0000713aae5d0a64  nop [rax+rax*1], ax
0000713aae5d0a6d  nop [rax+rax*1], eax
0000713aae5d0a75  mov eax, 0x4102D4
0000713aae5d0a7a  mov [r15+0x100], rax
0000713aae5d0a81  jmp 0x0000713AAE3FE110
0000713aae5d0a86  int3
0000713aae5d0a87  call 0x0000713AAE4E27E0
0000713aae5d0a8c  jmp 0x0000713AAE5D09F3
0000713aae5d0a91  call 0x0000713AAE4D5AF0
0000713aae5d0a96  jmp 0x0000713AAE5D0A05
0000713aae5d0a9b  int3
0000713aae5d0a9c  nop [rax], eax
0000713aae5d0aa0  mov rax, [r15+0xF8]
0000713aae5d0aa7  lea r14, [rax+0xD0]
0000713aae5d0aae  mov [r15], r14
0000713aae5d0ab1  lea r14, [rax+0x148]
0000713aae5d0ab8  mov [r15+0x08], r14
0000713aae5d0abc  mov qword ptr [r15+0x10], 0x01
0000713aae5d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
0000713aae5d0acf  mov r14d, [r15+0x320]
0000713aae5d0ad6  mov eax, 0x4102C8
0000713aae5d0adb  mov rcx, 0x713AAE5D0B40
0000713aae5d0ae5  mov [r15+r14*8+0x328], rax
0000713aae5d0aed  mov [r15+r14*8+0x368], rcx
0000713aae5d0af5  add r14d, 0x01
0000713aae5d0af9  and r14d, 0x07
0000713aae5d0afd  mov [r15+0x320], r14d
0000713aae5d0b04  cmp dword ptr [r15+0x318], 0x00
0000713aae5d0b0c  jz 0x0000713AAE5CED70
0000713aae5d0b12  nop [rax+rax*1], ax
0000713aae5d0b1b  nop [rax+rax*1], eax
0000713aae5d0b23  mov eax, 0x4106BC
0000713aae5d0b28  mov [r15+0x100], rax
0000713aae5d0b2f  jmp 0x0000713AAE3FE110
0000713aae5d0b34  int3
0000713aae5d0b35  int3
0000713aae5d0b36  nop [rax+rax*1], ax
0000713aae5d0b3f  nop
0000713aae5d0b40  mov rax, [r15+0xF8]
0000713aae5d0b47  lea r14, [rax+0x138]
0000713aae5d0b4e  mov rax, [r13+r14*1]
0000713aae5d0b53  mov [r15+0x40], rax
0000713aae5d0b57  mov [rsp+0x10], rax
0000713aae5d0b5c  xor eax, eax
0000713aae5d0b5e  mov r14, [rsp+0x10]
0000713aae5d0b63  mov r12d, 0x38
0000713aae5d0b69  cmp r14, r12
0000713aae5d0b6c  cmc
0000713aae5d0b6d  lahf
0000713aae5d0b6e  seto al
0000713aae5d0b71  mov [r15+0x108], eax
0000713aae5d0b78  mov eax, [r15+0x108]
0000713aae5d0b7f  sahf
0000713aae5d0b80  jnz 0x0000713AAE5D0BB2
0000713aae5d0b82  cmp dword ptr [r15+0x318], 0x00
0000713aae5d0b8a  jz 0x0000713AAE5D0BF0
0000713aae5d0b90  nop [rax+rax*1], ax
0000713aae5d0b99  nop [rax+rax*1], eax
0000713aae5d0ba1  mov eax, 0x4102D4
0000713aae5d0ba6  mov [r15+0x100], rax
0000713aae5d0bad  jmp 0x0000713AAE3FE110
0000713aae5d0bb2  cmp dword ptr [r15+0x318], 0x00
0000713aae5d0bba  jz 0x0000713AAE5D0AA0
0000713aae5d0bc0  nop [rax+rax*1], ax
0000713aae5d0bc9  nop [rax+rax*1], eax
0000713aae5d0bd1  mov eax, 0x4102B8
0000713aae5d0bd6  mov [r15+0x100], rax
0000713aae5d0bdd  jmp 0x0000713AAE3FE110
0000713aae5d0be2  int3
0000713aae5d0be3  call 0x0000713AAE4D59C0
0000713aae5d0be8  jmp 0x0000713AAE5D0B53
0000713aae5d0bed  int3
0000713aae5d0bee  nop
0000713aae5d0bf0  mov rax, [r15+0x98]
0000713aae5d0bf7  rorx r14, rax, 0x3D
0000713aae5d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
0000713aae5d0c01  mov rax, [r15+0xF8]
0000713aae5d0c08  lea r12, [rax+0xD0]
0000713aae5d0c0f  mov [r15], r12
0000713aae5d0c12  lea r12, [rax+0x140]
0000713aae5d0c19  mov [r15+0x08], r12
0000713aae5d0c1d  mov qword ptr [r15+0x10], 0x08
0000713aae5d0c25  bswap r14
0000713aae5d0c28  mov [r15+0x40], r14
0000713aae5d0c2c  lea r12, [rax+0x140]
0000713aae5d0c33  mov [r13+r12*1], r14
0000713aae5d0c38  mov qword ptr [r15+0xF0], 0x4102F0
0000713aae5d0c43  mov r14d, [r15+0x320]
0000713aae5d0c4a  mov eax, 0x4102F0
0000713aae5d0c4f  mov rcx, 0x713AAE5D0CC0
0000713aae5d0c59  mov [r15+r14*8+0x328], rax
0000713aae5d0c61  mov [r15+r14*8+0x368], rcx
0000713aae5d0c69  add r14d, 0x01
0000713aae5d0c6d  and r14d, 0x07
0000713aae5d0c71  mov [r15+0x320], r14d
0000713aae5d0c78  cmp dword ptr [r15+0x318], 0x00
0000713aae5d0c80  jz 0x0000713AAE5CED70
0000713aae5d0c86  nop [rax+rax*1], ax
0000713aae5d0c8f  nop [rax+rax*1], eax
0000713aae5d0c97  mov eax, 0x4106BC
0000713aae5d0c9c  mov [r15+0x100], rax
0000713aae5d0ca3  jmp 0x0000713AAE3FE110
0000713aae5d0ca8  int3
0000713aae5d0ca9  call 0x0000713AAE4C3FE0
0000713aae5d0cae  jmp 0x0000713AAE5D0C38
0000713aae5d0cb3  int3
0000713aae5d0cb4  nop [rax+rax*1], ax
0000713aae5d0cbd  nop [rax], eax
0000713aae5d0cc0  mov rax, [r15+0xF8]
0000713aae5d0cc7  lea r14, [rax+0xD0]
0000713aae5d0cce  mov r12d, [r13+r14*1]
0000713aae5d0cd3  lea r14, [rax+0xD4]
0000713aae5d0cda  mov r11d, [r13+r14*1]
0000713aae5d0cdf  lea r14, [rax+0xD8]
0000713aae5d0ce6  mov r10d, [r13+r14*1]
0000713aae5d0ceb  lea r14, [rax+0xDC]
0000713aae5d0cf2  mov r9d, [r13+r14*1]
0000713aae5d0cf7  mov qword ptr [r15+0x48], 0x430C20
0000713aae5d0cff  mov qword ptr [r15+0xA0], 0x00
0000713aae5d0d0a  bswap r12d
0000713aae5d0d0d  bswap r11d
0000713aae5d0d10  mov qword ptr [r15+0x98], 0x430D8C
0000713aae5d0d1b  mov r14d, 0x430C20
0000713aae5d0d21  mov [r13+r14*1], r12d
0000713aae5d0d26  mov r14d, 0x430C24
0000713aae5d0d2c  mov [r13+r14*1], r11d
0000713aae5d0d31  bswap r10d
0000713aae5d0d34  bswap r9d
0000713aae5d0d37  lea r14, [rax+0xE0]
0000713aae5d0d3e  mov r12d, [r13+r14*1]
0000713aae5d0d43  lea r14, [rax+0xE4]
0000713aae5d0d4a  mov r11d, [r13+r14*1]
0000713aae5d0d4f  mov r14d, 0x430C28
0000713aae5d0d55  mov [r13+r14*1], r10d
0000713aae5d0d5a  mov r14d, 0x430C2C
0000713aae5d0d60  mov [r13+r14*1], r9d
0000713aae5d0d65  bswap r12d
0000713aae5d0d68  bswap r11d
0000713aae5d0d6b  mov [rsp+0x10], r11d
0000713aae5d0d70  mov r11d, r11d
0000713aae5d0d73  mov [r15+0x58], r11
0000713aae5d0d77  lea r14, [rax+0xE8]
0000713aae5d0d7e  mov r11d, [r13+r14*1]
0000713aae5d0d83  lea r14, [rax+0xEC]
0000713aae5d0d8a  mov eax, [r13+r14*1]
0000713aae5d0d8f  mov [rsp+0x20], eax
0000713aae5d0d93  mov eax, eax
0000713aae5d0d95  mov [r15+0x60], rax
0000713aae5d0d99  mov eax, 0x430C30
0000713aae5d0d9e  mov [r13+rax*1], r12d
0000713aae5d0da3  mov eax, 0x430C34
0000713aae5d0da8  mov r14d, [rsp+0x10]
0000713aae5d0dad  mov [r13+rax*1], r14d
0000713aae5d0db2  bswap r11d
0000713aae5d0db5  mov [rsp+0x10], r11d
0000713aae5d0dba  mov r11d, r11d
0000713aae5d0dbd  mov [r15+0x40], r11
0000713aae5d0dc1  mov eax, [rsp+0x20]
0000713aae5d0dc5  bswap eax
0000713aae5d0dc7  mov [rsp+0x20], eax
0000713aae5d0dcb  mov eax, eax
0000713aae5d0dcd  mov [r15+0x50], rax
0000713aae5d0dd1  mov eax, 0x430C38
0000713aae5d0dd6  mov r14d, [rsp+0x10]
0000713aae5d0ddb  mov [r13+rax*1], r14d
0000713aae5d0de0  mov eax, 0x430C3C
0000713aae5d0de5  mov r14d, [rsp+0x20]
0000713aae5d0dea  mov [r13+rax*1], r14d
0000713aae5d0def  mov eax, [r15+0xA0]
0000713aae5d0df6  lea r14d, [eax+0x11]
0000713aae5d0dfb  mov r14d, r14d
0000713aae5d0dfe  mov [r15], r14
0000713aae5d0e01  mov qword ptr [r15+0xF0], 0x41034C
0000713aae5d0e0c  mov r14d, [r15+0x320]
0000713aae5d0e13  mov eax, 0x41034C
0000713aae5d0e18  mov rcx, 0x713AAE5D0F90
0000713aae5d0e22  mov [r15+r14*8+0x328], rax
0000713aae5d0e2a  mov [r15+r14*8+0x368], rcx
0000713aae5d0e32  add r14d, 0x01
0000713aae5d0e36  and r14d, 0x07
0000713aae5d0e3a  mov [r15+0x320], r14d
0000713aae5d0e41  cmp dword ptr [r15+0x318], 0x00
0000713aae5d0e49  jz 0x0000713AAE5D0F20
0000713aae5d0e4f  nop [rax+rax*1], ax
0000713aae5d0e58  nop [rax+rax*1], eax
0000713aae5d0e60  mov eax, 0x410938
0000713aae5d0e65  mov [r15+0x100], rax
0000713aae5d0e6c  jmp 0x0000713AAE3FE110
0000713aae5d0e71  int3
0000713aae5d0e72  call 0x0000713AAE4E26A0
0000713aae5d0e77  jmp 0x0000713AAE5D0CD3
0000713aae5d0e7c  call 0x0000713AAE4E1430
0000713aae5d0e81  jmp 0x0000713AAE5D0CDF
0000713aae5d0e86  call 0x0000713AAE4E01C0
0000713aae5d0e8b  jmp 0x0000713AAE5D0CEB
0000713aae5d0e90  call 0x0000713AAE4DEF50
0000713aae5d0e95  jmp 0x0000713AAE5D0CF7
0000713aae5d0e9a  call 0x0000713AAE4E2BA0
0000713aae5d0e9f  jmp 0x0000713AAE5D0D26
0000713aae5d0ea4  call 0x0000713AAE4E1920
0000713aae5d0ea9  jmp 0x0000713AAE5D0D31
0000713aae5d0eae  call 0x0000713AAE4E26A0
0000713aae5d0eb3  jmp 0x0000713AAE5D0D43
0000713aae5d0eb8  call 0x0000713AAE4E1430
0000713aae5d0ebd  jmp 0x0000713AAE5D0D4F
0000713aae5d0ec2  call 0x0000713AAE4E06B0
0000713aae5d0ec7  jmp 0x0000713AAE5D0D5A
0000713aae5d0ecc  call 0x0000713AAE4DF440
0000713aae5d0ed1  jmp 0x0000713AAE5D0D65
0000713aae5d0ed6  call 0x0000713AAE4E1430
0000713aae5d0edb  jmp 0x0000713AAE5D0D83
0000713aae5d0ee0  call 0x0000713AAE4D5890
0000713aae5d0ee5  jmp 0x0000713AAE5D0D8F
0000713aae5d0eea  call 0x0000713AAE40BAE0
0000713aae5d0eef  jmp 0x0000713AAE5D0DA3
0000713aae5d0ef4  call 0x0000713AAE40DFE0
0000713aae5d0ef9  jmp 0x0000713AAE5D0DB2
0000713aae5d0efe  call 0x0000713AAE40DFE0
0000713aae5d0f03  jmp 0x0000713AAE5D0DE0
0000713aae5d0f08  call 0x0000713AAE40DFE0
0000713aae5d0f0d  jmp 0x0000713AAE5D0DEF
0000713aae5d0f12  int3
0000713aae5d0f13  nop [rax+rax*1], ax
0000713aae5d0f1c  nop [rax], eax
0000713aae5d0f20  mov eax, [r15]
0000713aae5d0f23  mov [rsp+0x10], eax
0000713aae5d0f27  shr eax, 0x10
0000713aae5d0f2a  mov r14d, [rsp+0x10]
0000713aae5d0f2f  xor r14d, eax
0000713aae5d0f32  imul r14d, r14d, 0x7FEB352D
0000713aae5d0f39  mov eax, 0x846CA68B
0000713aae5d0f3e  mov eax, eax
0000713aae5d0f40  mov [r15+0x48], rax
0000713aae5d0f44  mov [rsp+0x10], r14d
0000713aae5d0f49  shr r14d, 0x0F
0000713aae5d0f4d  mov eax, [rsp+0x10]
0000713aae5d0f51  xor eax, r14d
0000713aae5d0f54  imul eax, eax, 0x846CA68B
0000713aae5d0f5a  mov [rsp+0x10], eax
0000713aae5d0f5e  mov eax, eax
0000713aae5d0f60  mov [r15+0x40], rax
0000713aae5d0f64  mov eax, [rsp+0x10]
0000713aae5d0f68  shr eax, 0x10
0000713aae5d0f6b  mov r14d, [rsp+0x10]
0000713aae5d0f70  xor r14d, eax
0000713aae5d0f73  mov r14d, r14d
0000713aae5d0f76  mov [r15], r14
0000713aae5d0f79  mov rax, [r15+0xF0]
0000713aae5d0f80  mov [r15+0x100], rax
0000713aae5d0f87  jmp 0x0000713AAE5CE5C0
0000713aae5d0f8c  int3
0000713aae5d0f8d  int3
0000713aae5d0f8e  nop
0000713aae5d0f90  mov rax, [r15+0xA0]
0000713aae5d0f97  mov [rsp+0x10], rax
0000713aae5d0f9c  shl rax, 0x02
0000713aae5d0fa0  mov r14, [r15+0x98]
0000713aae5d0fa7  lea r12, [r14+rax*1]
0000713aae5d0fab  mov eax, [r15]
0000713aae5d0fae  mov [r13+r12*1], eax
0000713aae5d0fb3  mov rax, [rsp+0x10]
0000713aae5d0fb8  lea r14, [rax+0x01]
0000713aae5d0fbc  mov [r15+0xA0], r14
0000713aae5d0fc3  xor eax, eax
0000713aae5d0fc5  mov r12d, 0x400
0000713aae5d0fcb  cmp r14, r12
0000713aae5d0fce  cmc
0000713aae5d0fcf  lahf
0000713aae5d0fd0  seto al
0000713aae5d0fd3  mov [r15+0x108], eax
0000713aae5d0fda  mov eax, [r15+0x108]
0000713aae5d0fe1  sahf
0000713aae5d0fe2  jnz 0x0000713AAE5D1014
0000713aae5d0fe4  cmp dword ptr [r15+0x318], 0x00
0000713aae5d0fec  jz 0x0000713AAE5D10E0
0000713aae5d0ff2  nop [rax+rax*1], ax
0000713aae5d0ffb  nop [rax+rax*1], eax
0000713aae5d1003  mov eax, 0x41035C
0000713aae5d1008  mov [r15+0x100], rax
0000713aae5d100f  jmp 0x0000713AAE3FE110
0000713aae5d1014  cmp dword ptr [r15+0x318], 0x00
0000713aae5d101c  jz 0x0000713AAE5D1050
0000713aae5d1022  nop [rax+rax*1], ax
0000713aae5d102b  nop [rax+rax*1], eax
0000713aae5d1033  mov eax, 0x410344
0000713aae5d1038  mov [r15+0x100], rax
0000713aae5d103f  jmp 0x0000713AAE3FE110
0000713aae5d1044  int3
0000713aae5d1045  call 0x0000713AAE4B4B70
0000713aae5d104a  jmp 0x0000713AAE5D0FB3
0000713aae5d104f  int3
0000713aae5d1050  mov eax, [r15+0xA0]
0000713aae5d1057  lea r14d, [eax+0x11]
0000713aae5d105c  mov r14d, r14d
0000713aae5d105f  mov [r15], r14
0000713aae5d1062  mov qword ptr [r15+0xF0], 0x41034C
0000713aae5d106d  mov r14d, [r15+0x320]
0000713aae5d1074  mov eax, 0x41034C
0000713aae5d1079  mov rcx, 0x713AAE5D0F90
0000713aae5d1083  mov [r15+r14*8+0x328], rax
0000713aae5d108b  mov [r15+r14*8+0x368], rcx
0000713aae5d1093  add r14d, 0x01
0000713aae5d1097  and r14d, 0x07
0000713aae5d109b  mov [r15+0x320], r14d
0000713aae5d10a2  cmp dword ptr [r15+0x318], 0x00
0000713aae5d10aa  jz 0x0000713AAE5D0F20
0000713aae5d10b0  nop [rax+rax*1], ax
0000713aae5d10b9  nop [rax+rax*1], eax
0000713aae5d10c1  mov eax, 0x410938
0000713aae5d10c6  mov [r15+0x100], rax
0000713aae5d10cd  jmp 0x0000713AAE3FE110
0000713aae5d10d2  int3
0000713aae5d10d3  int3
0000713aae5d10d4  nop [rax+rax*1], ax
0000713aae5d10dd  nop [rax], eax
0000713aae5d10e0  mov qword ptr [r15+0x40], 0x01
0000713aae5d10e8  cmp dword ptr [r15+0x318], 0x00
0000713aae5d10f0  jz 0x0000713AAE5D1120
0000713aae5d10f6  nop [rax+rax*1], ax
0000713aae5d10ff  nop [rax+rax*1], eax
0000713aae5d1107  mov eax, 0x410378
0000713aae5d110c  mov [r15+0x100], rax
0000713aae5d1113  jmp 0x0000713AAE3FE110
0000713aae5d1118  int3
0000713aae5d1119  int3
0000713aae5d111a  nop [rax+rax*1], ax
0000713aae5d1120  mov rax, [r15+0x40]
0000713aae5d1124  mov [rsp+0x10], rax
0000713aae5d1129  shl rax, 0x02
0000713aae5d112d  mov r14, [r15+0x98]
0000713aae5d1134  lea r12, [r14+rax*1]
0000713aae5d1138  mov eax, [r13+r12*1]
0000713aae5d113d  mov [rsp+0x20], eax
0000713aae5d1141  mov eax, eax
0000713aae5d1143  mov [r15+0x48], rax
0000713aae5d1147  mov rax, [rsp+0x10]
0000713aae5d114c  mov [r15+0x50], rax
0000713aae5d1150  mov eax, [r15+0x50]
0000713aae5d1154  lea r12d, [eax-0x01]
0000713aae5d1159  mov r12d, r12d
0000713aae5d115c  mov [r15+0x58], r12
0000713aae5d1160  mov rax, [r15+0x58]
0000713aae5d1164  mov r12d, eax
0000713aae5d1167  mov r12d, r12d
0000713aae5d116a  shl r12, 0x02
0000713aae5d116e  lea rax, [r14+r12*1]
0000713aae5d1172  mov r14d, [r13+rax*1]
0000713aae5d1177  mov [rsp+0x10], r14d
0000713aae5d117c  mov r14d, r14d
0000713aae5d117f  mov [r15+0x60], r14
0000713aae5d1183  xor eax, eax
0000713aae5d1185  mov r14d, [rsp+0x10]
0000713aae5d118a  mov r12d, [rsp+0x20]
0000713aae5d118f  cmp r14d, r12d
0000713aae5d1192  cmc
0000713aae5d1193  lahf
0000713aae5d1194  seto al
0000713aae5d1197  mov [r15+0x108], eax
0000713aae5d119e  mov eax, [r15+0x108]
0000713aae5d11a5  sahf
0000713aae5d11a6  cmc
0000713aae5d11a7  jbe 0x0000713AAE5D11D9
0000713aae5d11a9  cmp dword ptr [r15+0x318], 0x00
0000713aae5d11b1  jz 0x0000713AAE5D1220
0000713aae5d11b7  nop [rax+rax*1], ax
0000713aae5d11c0  nop [rax+rax*1], eax
0000713aae5d11c8  mov eax, 0x410390
0000713aae5d11cd  mov [r15+0x100], rax
0000713aae5d11d4  jmp 0x0000713AAE3FE110
0000713aae5d11d9  cmp dword ptr [r15+0x318], 0x00
0000713aae5d11e1  jz 0x0000713AAE5D14C0
0000713aae5d11e7  nop [rax+rax*1], ax
0000713aae5d11f0  nop [rax+rax*1], eax
0000713aae5d11f8  mov eax, 0x410368
0000713aae5d11fd  mov [r15+0x100], rax
0000713aae5d1204  jmp 0x0000713AAE3FE110
0000713aae5d1209  int3
0000713aae5d120a  call 0x0000713AAE4B4690
0000713aae5d120f  jmp 0x0000713AAE5D113D
0000713aae5d1214  call 0x0000713AAE40DAE0
0000713aae5d1219  jmp 0x0000713AAE5D1177
0000713aae5d121e  int3
0000713aae5d121f  nop
0000713aae5d1220  mov rax, [r15+0x50]
0000713aae5d1224  mov [rsp+0x10], rax
0000713aae5d1229  shl rax, 0x02
0000713aae5d122d  mov r14, [r15+0x98]
0000713aae5d1234  lea r12, [r14+rax*1]
0000713aae5d1238  mov eax, [r15+0x60]
0000713aae5d123c  mov [r13+r12*1], eax
0000713aae5d1241  mov rax, [rsp+0x10]
0000713aae5d1246  lea r14, [rax-0x01]
0000713aae5d124a  mov [r15+0x50], r14
0000713aae5d124e  mov rax, [r15+0x58]
0000713aae5d1252  test rax, rax
0000713aae5d1255  setz al
0000713aae5d1258  movzx rax, al
0000713aae5d125c  mov [rsp+0x414], al
0000713aae5d1263  cmp byte ptr [rsp+0x414], 0x00
0000713aae5d126b  jz 0x0000713AAE5D129D
0000713aae5d126d  cmp dword ptr [r15+0x318], 0x00
0000713aae5d1275  jz 0x0000713AAE5D12E0
0000713aae5d127b  nop [rax+rax*1], ax
0000713aae5d1284  nop [rax+rax*1], eax
0000713aae5d128c  mov eax, 0x41039C
0000713aae5d1291  mov [r15+0x100], rax
0000713aae5d1298  jmp 0x0000713AAE3FE110
0000713aae5d129d  cmp dword ptr [r15+0x318], 0x00
0000713aae5d12a5  jz 0x0000713AAE5D13E0
0000713aae5d12ab  nop [rax+rax*1], ax
0000713aae5d12b4  nop [rax+rax*1], eax
0000713aae5d12bc  mov eax, 0x410380
0000713aae5d12c1  mov [r15+0x100], rax
0000713aae5d12c8  jmp 0x0000713AAE3FE110
0000713aae5d12cd  int3
0000713aae5d12ce  call 0x0000713AAE4B4B70
0000713aae5d12d3  jmp 0x0000713AAE5D1241
0000713aae5d12d8  int3
0000713aae5d12d9  nop [rax], eax
0000713aae5d12e0  cmp dword ptr [r15+0x318], 0x00
0000713aae5d12e8  jz 0x0000713AAE5D1320
0000713aae5d12ee  nop [rax+rax*1], ax
0000713aae5d12f7  nop [rax+rax*1], eax
0000713aae5d12ff  mov eax, 0x410364
0000713aae5d1304  mov [r15+0x100], rax
0000713aae5d130b  jmp 0x0000713AAE3FE110
0000713aae5d1310  int3
0000713aae5d1311  int3
0000713aae5d1312  nop [rax+rax*1], ax
0000713aae5d131b  nop [rax+rax*1], eax
0000713aae5d1320  mov qword ptr [r15+0x50], 0x00
0000713aae5d1328  mov rax, [r15+0x40]
0000713aae5d132c  lea r14, [rax+0x01]
0000713aae5d1330  mov [r15+0x40], r14
0000713aae5d1334  mov rax, [r15+0x98]
0000713aae5d133b  mov r12d, [r15+0x48]
0000713aae5d133f  mov [r13+rax*1], r12d
0000713aae5d1344  xor eax, eax
0000713aae5d1346  mov r12d, 0x400
0000713aae5d134c  cmp r14, r12
0000713aae5d134f  cmc
0000713aae5d1350  lahf
0000713aae5d1351  seto al
0000713aae5d1354  mov [r15+0x108], eax
0000713aae5d135b  mov eax, [r15+0x108]
0000713aae5d1362  sahf
0000713aae5d1363  jz 0x0000713AAE5D1395
0000713aae5d1365  cmp dword ptr [r15+0x318], 0x00
0000713aae5d136d  jz 0x0000713AAE5D1120
0000713aae5d1373  nop [rax+rax*1], ax
0000713aae5d137c  nop [rax+rax*1], eax
0000713aae5d1384  mov eax, 0x410378
0000713aae5d1389  mov [r15+0x100], rax
0000713aae5d1390  jmp 0x0000713AAE3FE110
0000713aae5d1395  cmp dword ptr [r15+0x318], 0x00
0000713aae5d139d  jz 0x0000713AAE5D1580
0000713aae5d13a3  nop [rax+rax*1], ax
0000713aae5d13ac  nop [rax+rax*1], eax
0000713aae5d13b4  mov eax, 0x4103A0
0000713aae5d13b9  mov [r15+0x100], rax
0000713aae5d13c0  jmp 0x0000713AAE3FE110
0000713aae5d13c5  int3
0000713aae5d13c6  call 0x0000713AAE40BAE0
0000713aae5d13cb  jmp 0x0000713AAE5D1344
0000713aae5d13d0  int3
0000713aae5d13d1  nop [rax+rax*1], ax
0000713aae5d13da  nop [rax+rax*1], ax
0000713aae5d13e0  mov eax, [r15+0x50]
0000713aae5d13e4  lea r14d, [eax-0x01]
0000713aae5d13e9  mov r14d, r14d
0000713aae5d13ec  mov [r15+0x58], r14
0000713aae5d13f0  mov rax, [r15+0x58]
0000713aae5d13f4  mov r14d, eax
0000713aae5d13f7  mov r14d, r14d
0000713aae5d13fa  shl r14, 0x02
0000713aae5d13fe  mov rax, [r15+0x98]
0000713aae5d1405  lea r12, [rax+r14*1]
0000713aae5d1409  mov eax, [r13+r12*1]
0000713aae5d140e  mov [rsp+0x10], eax
0000713aae5d1412  mov eax, eax
0000713aae5d1414  mov [r15+0x60], rax
0000713aae5d1418  mov eax, [r15+0x48]
0000713aae5d141c  mov [rsp+0x20], eax
0000713aae5d1420  xor eax, eax
0000713aae5d1422  mov r14d, [rsp+0x10]
0000713aae5d1427  mov r12d, [rsp+0x20]
0000713aae5d142c  cmp r14d, r12d
0000713aae5d142f  cmc
0000713aae5d1430  lahf
0000713aae5d1431  seto al
0000713aae5d1434  mov [r15+0x108], eax
0000713aae5d143b  mov eax, [r15+0x108]
0000713aae5d1442  sahf
0000713aae5d1443  cmc
0000713aae5d1444  jbe 0x0000713AAE5D1476
0000713aae5d1446  cmp dword ptr [r15+0x318], 0x00
0000713aae5d144e  jz 0x0000713AAE5D1220
0000713aae5d1454  nop [rax+rax*1], ax
0000713aae5d145d  nop [rax+rax*1], eax
0000713aae5d1465  mov eax, 0x410390
0000713aae5d146a  mov [r15+0x100], rax
0000713aae5d1471  jmp 0x0000713AAE3FE110
0000713aae5d1476  cmp dword ptr [r15+0x318], 0x00
0000713aae5d147e  jz 0x0000713AAE5D14C0
0000713aae5d1484  nop [rax+rax*1], ax
0000713aae5d148d  nop [rax+rax*1], eax
0000713aae5d1495  mov eax, 0x410368
0000713aae5d149a  mov [r15+0x100], rax
0000713aae5d14a1  jmp 0x0000713AAE3FE110
0000713aae5d14a6  int3
0000713aae5d14a7  call 0x0000713AAE4B4690
0000713aae5d14ac  jmp 0x0000713AAE5D140E
0000713aae5d14b1  int3
0000713aae5d14b2  nop [rax+rax*1], ax
0000713aae5d14bb  nop [rax+rax*1], eax
0000713aae5d14c0  mov rax, [r15+0x40]
0000713aae5d14c4  lea r14, [rax+0x01]
0000713aae5d14c8  mov [r15+0x40], r14
0000713aae5d14cc  mov rax, [r15+0x50]
0000713aae5d14d0  mov r12d, eax
0000713aae5d14d3  mov r12d, r12d
0000713aae5d14d6  shl r12, 0x02
0000713aae5d14da  mov rax, [r15+0x98]
0000713aae5d14e1  lea r11, [rax+r12*1]
0000713aae5d14e5  mov eax, [r15+0x48]
0000713aae5d14e9  mov [r13+r11*1], eax
0000713aae5d14ee  xor eax, eax
0000713aae5d14f0  mov r12d, 0x400
0000713aae5d14f6  cmp r14, r12
0000713aae5d14f9  cmc
0000713aae5d14fa  lahf
0000713aae5d14fb  seto al
0000713aae5d14fe  mov [r15+0x108], eax
0000713aae5d1505  mov eax, [r15+0x108]
0000713aae5d150c  sahf
0000713aae5d150d  jz 0x0000713AAE5D153F
0000713aae5d150f  cmp dword ptr [r15+0x318], 0x00
0000713aae5d1517  jz 0x0000713AAE5D1120
0000713aae5d151d  nop [rax+rax*1], ax
0000713aae5d1526  nop [rax+rax*1], eax
0000713aae5d152e  mov eax, 0x410378
0000713aae5d1533  mov [r15+0x100], rax
0000713aae5d153a  jmp 0x0000713AAE3FE110
0000713aae5d153f  cmp dword ptr [r15+0x318], 0x00
0000713aae5d1547  jz 0x0000713AAE5D1580
0000713aae5d154d  nop [rax+rax*1], ax
0000713aae5d1556  nop [rax+rax*1], eax
0000713aae5d155e  mov eax, 0x4103A0
0000713aae5d1563  mov [r15+0x100], rax
0000713aae5d156a  jmp 0x0000713AAE3FE110
0000713aae5d156f  int3
0000713aae5d1570  call 0x0000713AAE4A4270
0000713aae5d1575  jmp 0x0000713AAE5D14EE
0000713aae5d157a  int3
0000713aae5d157b  nop [rax+rax*1], eax
0000713aae5d1580  mov qword ptr [r15+0x40], 0x430000
0000713aae5d1588  mov eax, 0x430C40
0000713aae5d158d  mov r14, [r13+rax*1]
0000713aae5d1592  mov rax, [r15+0x98]
0000713aae5d1599  mov r12d, [r13+rax*1]
0000713aae5d159e  lea r11, [rax+0x04]
0000713aae5d15a2  mov eax, [r13+r11*1]
0000713aae5d15a7  mov r12d, r12d
0000713aae5d15aa  mov [r15+0x68], r12
0000713aae5d15ae  mov eax, eax
0000713aae5d15b0  mov [r15+0x60], rax
0000713aae5d15b4  mov rax, [r15+0x68]
0000713aae5d15b8  mov [r15+0x68], rax
0000713aae5d15bc  mov qword ptr [r15+0x58], 0x02
0000713aae5d15c4  mov [rsp+0x10], rax
0000713aae5d15c9  xor eax, eax
0000713aae5d15cb  mov r12d, 0x02
0000713aae5d15d1  mov r11d, 0x400
0000713aae5d15d7  cmp r12, r11
0000713aae5d15da  cmc
0000713aae5d15db  lahf
0000713aae5d15dc  seto al
0000713aae5d15df  mov [r15+0x108], eax
0000713aae5d15e6  mov rax, [r15+0x60]
0000713aae5d15ea  mov r12d, 0x02
0000713aae5d15f0  imul rax, r12
0000713aae5d15f4  mov [r15+0x50], rax
0000713aae5d15f8  mov rax, [rsp+0x10]
0000713aae5d15fd  lea r12, [rax+r14*1]
0000713aae5d1601  mov [r15+0x48], r12
0000713aae5d1605  mov eax, [r15+0x108]
0000713aae5d160c  sahf
0000713aae5d160d  jnz 0x0000713AAE5D163F
0000713aae5d160f  cmp dword ptr [r15+0x318], 0x00
0000713aae5d1617  jz 0x0000713AAE5D17B0
0000713aae5d161d  nop [rax+rax*1], ax
0000713aae5d1626  nop [rax+rax*1], eax
0000713aae5d162e  mov eax, 0x4103D0
0000713aae5d1633  mov [r15+0x100], rax
0000713aae5d163a  jmp 0x0000713AAE3FE110
0000713aae5d163f  cmp dword ptr [r15+0x318], 0x00
0000713aae5d1647  jz 0x0000713AAE5D1690
0000713aae5d164d  nop [rax+rax*1], ax
0000713aae5d1656  nop [rax+rax*1], eax
0000713aae5d165e  mov eax, 0x4103B0
0000713aae5d1663  mov [r15+0x100], rax
0000713aae5d166a  jmp 0x0000713AAE3FE110
0000713aae5d166f  int3
0000713aae5d1670  call 0x0000713AAE40DC20
0000713aae5d1675  jmp 0x0000713AAE5D1592
0000713aae5d167a  call 0x0000713AAE40B5E0
0000713aae5d167f  jmp 0x0000713AAE5D159E
0000713aae5d1684  call 0x0000713AAE4A3D90
0000713aae5d1689  jmp 0x0000713AAE5D15A7
0000713aae5d168e  int3
0000713aae5d168f  nop
0000713aae5d1690  mov rax, [r15+0x98]
0000713aae5d1697  mov r14, [r15+0x58]
0000713aae5d169b  mov [rsp+0x10], r14
0000713aae5d16a0  shl r14, 0x02
0000713aae5d16a4  lea r12, [rax+r14*1]
0000713aae5d16a8  mov eax, [r13+r12*1]
0000713aae5d16ad  lea r14, [r12+0x04]
0000713aae5d16b2  mov r12d, [r13+r14*1]
0000713aae5d16b7  mov eax, eax
0000713aae5d16b9  mov [r15+0x68], rax
0000713aae5d16bd  mov r12d, r12d
0000713aae5d16c0  mov [r15+0x60], r12
0000713aae5d16c4  mov rax, [r15+0x68]
0000713aae5d16c8  mov [rsp+0x20], rax
0000713aae5d16cd  mov r14, [rsp+0x10]
0000713aae5d16d2  imul rax, r14
0000713aae5d16d6  mov r12, [rsp+0x20]
0000713aae5d16db  lea r11, [r12+rax*1]
0000713aae5d16df  mov [r15+0x68], r11
0000713aae5d16e3  lea rax, [r14+0x02]
0000713aae5d16e7  mov [r15+0x58], rax
0000713aae5d16eb  mov [rsp+0x10], rax
0000713aae5d16f0  xor eax, eax
0000713aae5d16f2  mov r14, [rsp+0x10]
0000713aae5d16f7  mov r12d, 0x400
0000713aae5d16fd  cmp r14, r12
0000713aae5d1700  cmc
0000713aae5d1701  lahf
0000713aae5d1702  seto al
0000713aae5d1705  mov [r15+0x108], eax
0000713aae5d170c  mov rax, [r15+0x50]
0000713aae5d1710  mov r12, [r15+0x60]
0000713aae5d1714  imul r14, r12
0000713aae5d1718  lea r12, [rax+r14*1]
0000713aae5d171c  mov [r15+0x50], r12
0000713aae5d1720  mov rax, [r15+0x48]
0000713aae5d1724  lea r14, [r11+rax*1]
0000713aae5d1728  mov [r15+0x48], r14
0000713aae5d172c  mov eax, [r15+0x108]
0000713aae5d1733  sahf
0000713aae5d1734  jnz 0x0000713AAE5D1766
0000713aae5d1736  cmp dword ptr [r15+0x318], 0x00
0000713aae5d173e  jz 0x0000713AAE5D17B0
0000713aae5d1744  nop [rax+rax*1], ax
0000713aae5d174d  nop [rax+rax*1], eax
0000713aae5d1755  mov eax, 0x4103D0
0000713aae5d175a  mov [r15+0x100], rax
0000713aae5d1761  jmp 0x0000713AAE3FE110
0000713aae5d1766  cmp dword ptr [r15+0x318], 0x00
0000713aae5d176e  jz 0x0000713AAE5D1690
0000713aae5d1774  nop [rax+rax*1], ax
0000713aae5d177d  nop [rax+rax*1], eax
0000713aae5d1785  mov eax, 0x4103B0
0000713aae5d178a  mov [r15+0x100], rax
0000713aae5d1791  jmp 0x0000713AAE3FE110
0000713aae5d1796  int3
0000713aae5d1797  call 0x0000713AAE4B4690
0000713aae5d179c  jmp 0x0000713AAE5D16AD
0000713aae5d17a1  call 0x0000713AAE4E26A0
0000713aae5d17a6  jmp 0x0000713AAE5D16B7
0000713aae5d17ab  int3
0000713aae5d17ac  nop [rax], eax
0000713aae5d17b0  mov qword ptr [r15+0x98], 0x00
0000713aae5d17bb  mov rax, [r15+0x50]
0000713aae5d17bf  mov r14, [r15+0x48]
0000713aae5d17c3  lea r12, [rax+r14*1]
0000713aae5d17c7  mov [r15+0x48], r12
0000713aae5d17cb  mov rax, [r15+0x40]
0000713aae5d17cf  lea r14, [rax+0xC40]
0000713aae5d17d6  mov [r13+r14*1], r12
0000713aae5d17db  mov qword ptr [r15], 0x01
0000713aae5d17e2  mov qword ptr [r15+0xF0], 0x4103E8
0000713aae5d17ed  mov r14d, [r15+0x320]
0000713aae5d17f4  mov eax, 0x4103E8
0000713aae5d17f9  mov rcx, 0x713AAE5D1860
0000713aae5d1803  mov [r15+r14*8+0x328], rax
0000713aae5d180b  mov [r15+r14*8+0x368], rcx
0000713aae5d1813  add r14d, 0x01
0000713aae5d1817  and r14d, 0x07
0000713aae5d181b  mov [r15+0x320], r14d
0000713aae5d1822  cmp dword ptr [r15+0x318], 0x00
0000713aae5d182a  jz 0x0000713AAE5D0F20
0000713aae5d1830  nop [rax+rax*1], ax
0000713aae5d1839  nop [rax+rax*1], eax
0000713aae5d1841  mov eax, 0x410938
0000713aae5d1846  mov [r15+0x100], rax
0000713aae5d184d  jmp 0x0000713AAE3FE110
0000713aae5d1852  int3
0000713aae5d1853  call 0x0000713AAE4E2CE0
0000713aae5d1858  jmp 0x0000713AAE5D17DB
0000713aae5d185d  int3
0000713aae5d185e  nop
0000713aae5d1860  mov eax, [r15+0x98]
0000713aae5d1867  lea r14d, [eax+0x01]
0000713aae5d186c  mov [rsp+0x10], r14d
0000713aae5d1871  mov r14d, r14d
0000713aae5d1874  mov [r15+0x98], r14
0000713aae5d187b  xor eax, eax
0000713aae5d187d  mov r14d, [rsp+0x10]
0000713aae5d1882  cmp r14d, 0x10000
0000713aae5d1889  cmc
0000713aae5d188a  lahf
0000713aae5d188b  seto al
0000713aae5d188e  mov [r15+0x108], eax
0000713aae5d1895  mov eax, [r15+0x108]
0000713aae5d189c  sahf
0000713aae5d189d  jnz 0x0000713AAE5D18CF
0000713aae5d189f  cmp dword ptr [r15+0x318], 0x00
0000713aae5d18a7  jz 0x0000713AAE5D19A0
0000713aae5d18ad  nop [rax+rax*1], ax
0000713aae5d18b6  nop [rax+rax*1], eax
0000713aae5d18be  mov eax, 0x4103F4
0000713aae5d18c3  mov [r15+0x100], rax
0000713aae5d18ca  jmp 0x0000713AAE3FE110
0000713aae5d18cf  cmp dword ptr [r15+0x318], 0x00
0000713aae5d18d7  jz 0x0000713AAE5D1910
0000713aae5d18dd  nop [rax+rax*1], ax
0000713aae5d18e6  nop [rax+rax*1], eax
0000713aae5d18ee  mov eax, 0x4103E0
0000713aae5d18f3  mov [r15+0x100], rax
0000713aae5d18fa  jmp 0x0000713AAE3FE110
0000713aae5d18ff  int3
0000713aae5d1900  int3
0000713aae5d1901  nop [rax+rax*1], ax
0000713aae5d190a  nop [rax+rax*1], ax
0000713aae5d1910  mov eax, [r15]
0000713aae5d1913  mov r14d, [r15+0x98]
0000713aae5d191a  lea r12d, [eax+r14d*1]
0000713aae5d191f  mov r12d, r12d
0000713aae5d1922  mov [r15], r12
0000713aae5d1925  mov qword ptr [r15+0xF0], 0x4103E8
0000713aae5d1930  mov r14d, [r15+0x320]
0000713aae5d1937  mov eax, 0x4103E8
0000713aae5d193c  mov rcx, 0x713AAE5D1860
0000713aae5d1946  mov [r15+r14*8+0x328], rax
0000713aae5d194e  mov [r15+r14*8+0x368], rcx
0000713aae5d1956  add r14d, 0x01
0000713aae5d195a  and r14d, 0x07
0000713aae5d195e  mov [r15+0x320], r14d
0000713aae5d1965  cmp dword ptr [r15+0x318], 0x00
0000713aae5d196d  jz 0x0000713AAE5D0F20
0000713aae5d1973  nop [rax+rax*1], ax
0000713aae5d197c  nop [rax+rax*1], eax
0000713aae5d1984  mov eax, 0x410938
0000713aae5d1989  mov [r15+0x100], rax
0000713aae5d1990  jmp 0x0000713AAE3FE110
0000713aae5d1995  int3
0000713aae5d1996  int3
0000713aae5d1997  nop [rax+rax*1], ax
0000713aae5d19a0  vmovaps xmm1, [0x0000713AAE1FE010]
0000713aae5d19a8  movq xmm1, xmm1
0000713aae5d19ac  movaps [r15+0x110], xmm1
0000713aae5d19b4  mov eax, 0x420AA0
0000713aae5d19b9  mov r14, [r13+rax*1]
0000713aae5d19be  movq xmm1, r14
0000713aae5d19c3  movaps [r15+0x120], xmm1
0000713aae5d19cb  vmovaps xmm1, [0x0000713AAE1FE020]
0000713aae5d19d3  movq xmm1, xmm1
0000713aae5d19d7  movaps [r15+0x140], xmm1
0000713aae5d19df  vmovaps xmm1, [0x0000713AAE1FE030]
0000713aae5d19e7  vpbroadcastq xmm1, xmm1
0000713aae5d19ec  movaps [r15+0x150], xmm1
0000713aae5d19f4  mov qword ptr [r15+0x40], 0x02
0000713aae5d19fc  vmovaps xmm15, [0x0000713AAE1FE040]
0000713aae5d1a04  movq xmm15, xmm15
0000713aae5d1a09  movaps [r15+0x160], xmm15
0000713aae5d1a11  vmovaps xmm15, [0x0000713AAE1FE050]
0000713aae5d1a19  vpbroadcastq xmm15, xmm15
0000713aae5d1a1e  movaps [r15+0x130], xmm15
0000713aae5d1a26  mov rax, [r15+0x40]
0000713aae5d1a2a  vmovq xmm14, rax
0000713aae5d1a2f  vpbroadcastq xmm14, xmm14
0000713aae5d1a34  movaps [r15+0x170], xmm14
0000713aae5d1a3c  mov eax, 0x4209D0
0000713aae5d1a41  movups xmm13, [r13+rax*1]
0000713aae5d1a47  mov qword ptr [r15+0x40], 0x431D90
0000713aae5d1a4f  mov eax, [r15]
0000713aae5d1a52  mov r14d, 0x430C48
0000713aae5d1a58  mov [r13+r14*1], eax
0000713aae5d1a5d  mov qword ptr [r15+0x50], 0x431F90
0000713aae5d1a65  vpmovqd xmm12, xmm13
0000713aae5d1a6b  pxor xmm11, xmm11
0000713aae5d1a70  punpcklqdq xmm12, xmm11
0000713aae5d1a75  movaps [r15+0x210], xmm12
0000713aae5d1a7d  movq xmm12, qword ptr [r15+0x140]
0000713aae5d1a86  movq xmm11, qword ptr [r15+0x120]
0000713aae5d1a8f  psubd xmm12, xmm11
0000713aae5d1a94  movq xmm12, xmm12
0000713aae5d1a99  paddq xmm13, xmm14
0000713aae5d1a9e  movaps [r15+0x180], xmm13
0000713aae5d1aa6  movq xmm14, qword ptr [r15+0x160]
0000713aae5d1aaf  paddd xmm11, xmm14
0000713aae5d1ab4  movq xmm11, xmm11
0000713aae5d1ab9  movq xmm11, xmm11
0000713aae5d1abe  movaps [r15+0x120], xmm11
0000713aae5d1ac6  pmovzxdq xmm12, xmm12
0000713aae5d1acc  psllq xmm12, 0x00
0000713aae5d1ad2  movq xmm14, qword ptr [r15+0x210]
0000713aae5d1adb  movq xmm13, qword ptr [r15+0x110]
0000713aae5d1ae4  paddd xmm14, xmm13
0000713aae5d1ae9  movq xmm14, xmm14
0000713aae5d1aee  vcvtuqq2pd xmm12, xmm12
0000713aae5d1af4  pmovzxdq xmm14, xmm14
0000713aae5d1afa  psllq xmm14, 0x00
0000713aae5d1b00  vcvtuqq2pd xmm14, xmm14
0000713aae5d1b06  movaps xmm13, xmm12
0000713aae5d1b0a  mulpd xmm13, xmm1
0000713aae5d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
0000713aae5d1b15  ptest xmm11, xmm11
0000713aae5d1b1b  jnz 0x0000713AAE5D1C0F
0000713aae5d1b21  movaps [r15+0x220], xmm13
0000713aae5d1b29  mov eax, 0x431F90
0000713aae5d1b2e  movups [r13+rax*1], xmm13
0000713aae5d1b34  movaps xmm1, xmm14
0000713aae5d1b38  mulpd xmm1, xmm15
0000713aae5d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
0000713aae5d1b42  ptest xmm13, xmm13
0000713aae5d1b48  jnz 0x0000713AAE5D1D5C
0000713aae5d1b4e  movaps [r15+0x210], xmm1
0000713aae5d1b56  mov eax, 0x431D90
0000713aae5d1b5b  movups [r13+rax*1], xmm1
0000713aae5d1b61  mov qword ptr [r15+0x48], 0x10
0000713aae5d1b69  xor eax, eax
0000713aae5d1b6b  mov r14d, 0x10
0000713aae5d1b71  mov r12d, 0x200
0000713aae5d1b77  cmp r14, r12
0000713aae5d1b7a  cmc
0000713aae5d1b7b  lahf
0000713aae5d1b7c  seto al
0000713aae5d1b7f  mov [r15+0x108], eax
0000713aae5d1b86  mov eax, [r15+0x108]
0000713aae5d1b8d  sahf
0000713aae5d1b8e  jnz 0x0000713AAE5D1BC0
0000713aae5d1b90  cmp dword ptr [r15+0x318], 0x00
0000713aae5d1b98  jz 0x0000713AAE5D2300
0000713aae5d1b9e  nop [rax+rax*1], ax
0000713aae5d1ba7  nop [rax+rax*1], eax
0000713aae5d1baf  mov eax, 0x410480
0000713aae5d1bb4  mov [r15+0x100], rax
0000713aae5d1bbb  jmp 0x0000713AAE3FE110
0000713aae5d1bc0  cmp dword ptr [r15+0x318], 0x00
0000713aae5d1bc8  jz 0x0000713AAE5D1EB0
0000713aae5d1bce  nop [rax+rax*1], ax
0000713aae5d1bd7  nop [rax+rax*1], eax
0000713aae5d1bdf  mov eax, 0x410440
0000713aae5d1be4  mov [r15+0x100], rax
0000713aae5d1beb  jmp 0x0000713AAE3FE110
0000713aae5d1bf0  int3
0000713aae5d1bf1  call 0x0000713AAE40DC20
0000713aae5d1bf6  jmp 0x0000713AAE5D19BE
0000713aae5d1bfb  call 0x0000713AAE40C260
0000713aae5d1c00  jmp 0x0000713AAE5D1A47
0000713aae5d1c05  call 0x0000713AAE4D5D70
0000713aae5d1c0a  jmp 0x0000713AAE5D1A5D
0000713aae5d1c0f  sub rsp, 0x08
0000713aae5d1c13  push rax
0000713aae5d1c14  push rcx
0000713aae5d1c15  push rdx
0000713aae5d1c16  push rdi
0000713aae5d1c17  push rsi
0000713aae5d1c18  push r8
0000713aae5d1c1a  push r9
0000713aae5d1c1c  push r10
0000713aae5d1c1e  push r11
0000713aae5d1c20  sub rsp, 0xF0
0000713aae5d1c27  vmovaps [rsp], xmm0
0000713aae5d1c2c  vmovaps [rsp+0x10], xmm1
0000713aae5d1c32  vmovaps [rsp+0x20], xmm2
0000713aae5d1c38  vmovaps [rsp+0x30], xmm3
0000713aae5d1c3e  vmovaps [rsp+0x40], xmm4
0000713aae5d1c44  vmovaps [rsp+0x50], xmm5
0000713aae5d1c4a  vmovaps [rsp+0x60], xmm6
0000713aae5d1c50  vmovaps [rsp+0x70], xmm7
0000713aae5d1c56  vmovaps [rsp+0x80], xmm8
0000713aae5d1c5f  vmovaps [rsp+0x90], xmm9
0000713aae5d1c68  vmovaps [rsp+0xA0], xmm10
0000713aae5d1c71  vmovaps [rsp+0xB0], xmm11
0000713aae5d1c7a  vmovaps [rsp+0xC0], xmm12
0000713aae5d1c83  vmovaps [rsp+0xD0], xmm14
0000713aae5d1c8c  vmovaps [rsp+0xE0], xmm15
0000713aae5d1c95  sub rsp, 0x30
0000713aae5d1c99  movaps [rsp], xmm13
0000713aae5d1c9e  movaps [rsp+0x10], xmm12
0000713aae5d1ca4  movaps [rsp+0x20], xmm1
0000713aae5d1ca9  lea rdi, [rsp]
0000713aae5d1cad  mov esi, 0x00
0000713aae5d1cb2  mov rax, 0x5E9381C89530
0000713aae5d1cbc  call rax
0000713aae5d1cbe  movaps xmm13, [rsp]
0000713aae5d1cc3  add rsp, 0x30
0000713aae5d1cc7  vmovaps xmm0, [rsp]
0000713aae5d1ccc  vmovaps xmm1, [rsp+0x10]
0000713aae5d1cd2  vmovaps xmm2, [rsp+0x20]
0000713aae5d1cd8  vmovaps xmm3, [rsp+0x30]
0000713aae5d1cde  vmovaps xmm4, [rsp+0x40]
0000713aae5d1ce4  vmovaps xmm5, [rsp+0x50]
0000713aae5d1cea  vmovaps xmm6, [rsp+0x60]
0000713aae5d1cf0  vmovaps xmm7, [rsp+0x70]
0000713aae5d1cf6  vmovaps xmm8, [rsp+0x80]
0000713aae5d1cff  vmovaps xmm9, [rsp+0x90]
0000713aae5d1d08  vmovaps xmm10, [rsp+0xA0]
0000713aae5d1d11  vmovaps xmm11, [rsp+0xB0]
0000713aae5d1d1a  vmovaps xmm12, [rsp+0xC0]
0000713aae5d1d23  vmovaps xmm14, [rsp+0xD0]
0000713aae5d1d2c  vmovaps xmm15, [rsp+0xE0]
0000713aae5d1d35  add rsp, 0xF0
0000713aae5d1d3c  pop r11
0000713aae5d1d3e  pop r10
0000713aae5d1d40  pop r9
0000713aae5d1d42  pop r8
0000713aae5d1d44  pop rsi
0000713aae5d1d45  pop rdi
0000713aae5d1d46  pop rdx
0000713aae5d1d47  pop rcx
0000713aae5d1d48  pop rax
0000713aae5d1d49  add rsp, 0x08
0000713aae5d1d4d  jmp 0x0000713AAE5D1B21
0000713aae5d1d52  call 0x0000713AAE40C380
0000713aae5d1d57  jmp 0x0000713AAE5D1B34
0000713aae5d1d5c  sub rsp, 0x08
0000713aae5d1d60  push rax
0000713aae5d1d61  push rcx
0000713aae5d1d62  push rdx
0000713aae5d1d63  push rdi
0000713aae5d1d64  push rsi
0000713aae5d1d65  push r8
0000713aae5d1d67  push r9
0000713aae5d1d69  push r10
0000713aae5d1d6b  push r11
0000713aae5d1d6d  sub rsp, 0xF0
0000713aae5d1d74  vmovaps [rsp], xmm0
0000713aae5d1d79  vmovaps [rsp+0x10], xmm2
0000713aae5d1d7f  vmovaps [rsp+0x20], xmm3
0000713aae5d1d85  vmovaps [rsp+0x30], xmm4
0000713aae5d1d8b  vmovaps [rsp+0x40], xmm5
0000713aae5d1d91  vmovaps [rsp+0x50], xmm6
0000713aae5d1d97  vmovaps [rsp+0x60], xmm7
0000713aae5d1d9d  vmovaps [rsp+0x70], xmm8
0000713aae5d1da3  vmovaps [rsp+0x80], xmm9
0000713aae5d1dac  vmovaps [rsp+0x90], xmm10
0000713aae5d1db5  vmovaps [rsp+0xA0], xmm11
0000713aae5d1dbe  vmovaps [rsp+0xB0], xmm12
0000713aae5d1dc7  vmovaps [rsp+0xC0], xmm13
0000713aae5d1dd0  vmovaps [rsp+0xD0], xmm14
0000713aae5d1dd9  vmovaps [rsp+0xE0], xmm15
0000713aae5d1de2  sub rsp, 0x30
0000713aae5d1de6  movaps [rsp], xmm1
0000713aae5d1dea  movaps [rsp+0x10], xmm14
0000713aae5d1df0  movaps [rsp+0x20], xmm15
0000713aae5d1df6  lea rdi, [rsp]
0000713aae5d1dfa  mov esi, 0x00
0000713aae5d1dff  mov rax, 0x5E9381C89530
0000713aae5d1e09  call rax
0000713aae5d1e0b  movaps xmm1, [rsp]
0000713aae5d1e0f  add rsp, 0x30
0000713aae5d1e13  vmovaps xmm0, [rsp]
0000713aae5d1e18  vmovaps xmm2, [rsp+0x10]
0000713aae5d1e1e  vmovaps xmm3, [rsp+0x20]
0000713aae5d1e24  vmovaps xmm4, [rsp+0x30]
0000713aae5d1e2a  vmovaps xmm5, [rsp+0x40]
0000713aae5d1e30  vmovaps xmm6, [rsp+0x50]
0000713aae5d1e36  vmovaps xmm7, [rsp+0x60]
0000713aae5d1e3c  vmovaps xmm8, [rsp+0x70]
0000713aae5d1e42  vmovaps xmm9, [rsp+0x80]
0000713aae5d1e4b  vmovaps xmm10, [rsp+0x90]
0000713aae5d1e54  vmovaps xmm11, [rsp+0xA0]
0000713aae5d1e5d  vmovaps xmm12, [rsp+0xB0]
0000713aae5d1e66  vmovaps xmm13, [rsp+0xC0]
0000713aae5d1e6f  vmovaps xmm14, [rsp+0xD0]
0000713aae5d1e78  vmovaps xmm15, [rsp+0xE0]
0000713aae5d1e81  add rsp, 0xF0
0000713aae5d1e88  pop r11
0000713aae5d1e8a  pop r10
0000713aae5d1e8c  pop r9
0000713aae5d1e8e  pop r8
0000713aae5d1e90  pop rsi
0000713aae5d1e91  pop rdi
0000713aae5d1e92  pop rdx
0000713aae5d1e93  pop rcx
0000713aae5d1e94  pop rax
0000713aae5d1e95  add rsp, 0x08
0000713aae5d1e99  jmp 0x0000713AAE5D1B4E
0000713aae5d1e9e  call 0x0000713AAE3FF540
0000713aae5d1ea3  jmp 0x0000713AAE5D1B61
0000713aae5d1ea8  int3
0000713aae5d1ea9  nop [rax], eax
0000713aae5d1eb0  movaps xmm1, [r15+0x180]
0000713aae5d1eb8  vpmovqd xmm15, xmm1
0000713aae5d1ebe  pxor xmm14, xmm14
0000713aae5d1ec3  punpcklqdq xmm15, xmm14
0000713aae5d1ec8  movaps [r15+0x210], xmm15
0000713aae5d1ed0  movq xmm15, qword ptr [r15+0x140]
0000713aae5d1ed9  movq xmm14, qword ptr [r15+0x120]
0000713aae5d1ee2  psubd xmm15, xmm14
0000713aae5d1ee7  movq xmm15, xmm15
0000713aae5d1eec  movaps xmm13, [r15+0x170]
0000713aae5d1ef4  paddq xmm1, xmm13
0000713aae5d1ef9  movaps [r15+0x180], xmm1
0000713aae5d1f01  movq xmm1, qword ptr [r15+0x160]
0000713aae5d1f0a  paddd xmm14, xmm1
0000713aae5d1f0f  movq xmm14, xmm14
0000713aae5d1f14  movq xmm14, xmm14
0000713aae5d1f19  movaps [r15+0x120], xmm14
0000713aae5d1f21  pmovzxdq xmm15, xmm15
0000713aae5d1f27  psllq xmm15, 0x00
0000713aae5d1f2d  movq xmm1, qword ptr [r15+0x210]
0000713aae5d1f36  movq xmm14, qword ptr [r15+0x110]
0000713aae5d1f3f  paddd xmm1, xmm14
0000713aae5d1f44  movq xmm1, xmm1
0000713aae5d1f48  vcvtuqq2pd xmm15, xmm15
0000713aae5d1f4e  pmovzxdq xmm1, xmm1
0000713aae5d1f53  psllq xmm1, 0x00
0000713aae5d1f58  vcvtuqq2pd xmm1, xmm1
0000713aae5d1f5e  movaps xmm14, [r15+0x150]
0000713aae5d1f66  movaps xmm13, xmm15
0000713aae5d1f6a  mulpd xmm13, xmm14
0000713aae5d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
0000713aae5d1f75  ptest xmm12, xmm12
0000713aae5d1f7b  jnz 0x0000713AAE5D205E
0000713aae5d1f81  movaps [r15+0x220], xmm13
0000713aae5d1f89  mov rax, [r15+0x48]
0000713aae5d1f8d  mov r14, [r15+0x50]
0000713aae5d1f91  lea r12, [r14+rax*1]
0000713aae5d1f95  movups [r13+r12*1], xmm13
0000713aae5d1f9b  movaps xmm15, [r15+0x130]
0000713aae5d1fa3  movaps xmm14, xmm1
0000713aae5d1fa7  mulpd xmm14, xmm15
0000713aae5d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
0000713aae5d1fb2  ptest xmm13, xmm13
0000713aae5d1fb8  jnz 0x0000713AAE5D21AC
0000713aae5d1fbe  movaps [r15+0x210], xmm14
0000713aae5d1fc6  mov r14, [r15+0x40]
0000713aae5d1fca  lea r12, [r14+rax*1]
0000713aae5d1fce  movups [r13+r12*1], xmm14
0000713aae5d1fd4  lea r14, [rax+0x10]
0000713aae5d1fd8  mov [r15+0x48], r14
0000713aae5d1fdc  xor eax, eax
0000713aae5d1fde  mov r12d, 0x200
0000713aae5d1fe4  cmp r14, r12
0000713aae5d1fe7  cmc
0000713aae5d1fe8  lahf
0000713aae5d1fe9  seto al
0000713aae5d1fec  mov [r15+0x108], eax
0000713aae5d1ff3  mov eax, [r15+0x108]
0000713aae5d1ffa  sahf
0000713aae5d1ffb  jnz 0x0000713AAE5D202D
0000713aae5d1ffd  cmp dword ptr [r15+0x318], 0x00
0000713aae5d2005  jz 0x0000713AAE5D2300
0000713aae5d200b  nop [rax+rax*1], ax
0000713aae5d2014  nop [rax+rax*1], eax
0000713aae5d201c  mov eax, 0x410480
0000713aae5d2021  mov [r15+0x100], rax
0000713aae5d2028  jmp 0x0000713AAE3FE110
0000713aae5d202d  cmp dword ptr [r15+0x318], 0x00
0000713aae5d2035  jz 0x0000713AAE5D1EB0
0000713aae5d203b  nop [rax+rax*1], ax
0000713aae5d2044  nop [rax+rax*1], eax
0000713aae5d204c  mov eax, 0x410440
0000713aae5d2051  mov [r15+0x100], rax
0000713aae5d2058  jmp 0x0000713AAE3FE110
0000713aae5d205d  int3
0000713aae5d205e  sub rsp, 0x08
0000713aae5d2062  push rax
0000713aae5d2063  push rcx
0000713aae5d2064  push rdx
0000713aae5d2065  push rdi
0000713aae5d2066  push rsi
0000713aae5d2067  push r8
0000713aae5d2069  push r9
0000713aae5d206b  push r10
0000713aae5d206d  push r11
0000713aae5d206f  sub rsp, 0xF0
0000713aae5d2076  vmovaps [rsp], xmm0
0000713aae5d207b  vmovaps [rsp+0x10], xmm1
0000713aae5d2081  vmovaps [rsp+0x20], xmm2
0000713aae5d2087  vmovaps [rsp+0x30], xmm3
0000713aae5d208d  vmovaps [rsp+0x40], xmm4
0000713aae5d2093  vmovaps [rsp+0x50], xmm5
0000713aae5d2099  vmovaps [rsp+0x60], xmm6
0000713aae5d209f  vmovaps [rsp+0x70], xmm7
0000713aae5d20a5  vmovaps [rsp+0x80], xmm8
0000713aae5d20ae  vmovaps [rsp+0x90], xmm9
0000713aae5d20b7  vmovaps [rsp+0xA0], xmm10
0000713aae5d20c0  vmovaps [rsp+0xB0], xmm11
0000713aae5d20c9  vmovaps [rsp+0xC0], xmm12
0000713aae5d20d2  vmovaps [rsp+0xD0], xmm14
0000713aae5d20db  vmovaps [rsp+0xE0], xmm15
0000713aae5d20e4  sub rsp, 0x30
0000713aae5d20e8  movaps [rsp], xmm13
0000713aae5d20ed  movaps [rsp+0x10], xmm15
0000713aae5d20f3  movaps [rsp+0x20], xmm14
0000713aae5d20f9  lea rdi, [rsp]
0000713aae5d20fd  mov esi, 0x00
0000713aae5d2102  mov rax, 0x5E9381C89530
0000713aae5d210c  call rax
0000713aae5d210e  movaps xmm13, [rsp]
0000713aae5d2113  add rsp, 0x30
0000713aae5d2117  vmovaps xmm0, [rsp]
0000713aae5d211c  vmovaps xmm1, [rsp+0x10]
0000713aae5d2122  vmovaps xmm2, [rsp+0x20]
0000713aae5d2128  vmovaps xmm3, [rsp+0x30]
0000713aae5d212e  vmovaps xmm4, [rsp+0x40]
0000713aae5d2134  vmovaps xmm5, [rsp+0x50]
0000713aae5d213a  vmovaps xmm6, [rsp+0x60]
0000713aae5d2140  vmovaps xmm7, [rsp+0x70]
0000713aae5d2146  vmovaps xmm8, [rsp+0x80]
0000713aae5d214f  vmovaps xmm9, [rsp+0x90]
0000713aae5d2158  vmovaps xmm10, [rsp+0xA0]
0000713aae5d2161  vmovaps xmm11, [rsp+0xB0]
0000713aae5d216a  vmovaps xmm12, [rsp+0xC0]
0000713aae5d2173  vmovaps xmm14, [rsp+0xD0]
0000713aae5d217c  vmovaps xmm15, [rsp+0xE0]
0000713aae5d2185  add rsp, 0xF0
0000713aae5d218c  pop r11
0000713aae5d218e  pop r10
0000713aae5d2190  pop r9
0000713aae5d2192  pop r8
0000713aae5d2194  pop rsi
0000713aae5d2195  pop rdi
0000713aae5d2196  pop rdx
0000713aae5d2197  pop rcx
0000713aae5d2198  pop rax
0000713aae5d2199  add rsp, 0x08
0000713aae5d219d  jmp 0x0000713AAE5D1F81
0000713aae5d21a2  call 0x0000713AAE4C2240
0000713aae5d21a7  jmp 0x0000713AAE5D1F9B
0000713aae5d21ac  sub rsp, 0x08
0000713aae5d21b0  push rax
0000713aae5d21b1  push rcx
0000713aae5d21b2  push rdx
0000713aae5d21b3  push rdi
0000713aae5d21b4  push rsi
0000713aae5d21b5  push r8
0000713aae5d21b7  push r9
0000713aae5d21b9  push r10
0000713aae5d21bb  push r11
0000713aae5d21bd  sub rsp, 0xF0
0000713aae5d21c4  vmovaps [rsp], xmm0
0000713aae5d21c9  vmovaps [rsp+0x10], xmm1
0000713aae5d21cf  vmovaps [rsp+0x20], xmm2
0000713aae5d21d5  vmovaps [rsp+0x30], xmm3
0000713aae5d21db  vmovaps [rsp+0x40], xmm4
0000713aae5d21e1  vmovaps [rsp+0x50], xmm5
0000713aae5d21e7  vmovaps [rsp+0x60], xmm6
0000713aae5d21ed  vmovaps [rsp+0x70], xmm7
0000713aae5d21f3  vmovaps [rsp+0x80], xmm8
0000713aae5d21fc  vmovaps [rsp+0x90], xmm9
0000713aae5d2205  vmovaps [rsp+0xA0], xmm10
0000713aae5d220e  vmovaps [rsp+0xB0], xmm11
0000713aae5d2217  vmovaps [rsp+0xC0], xmm12
0000713aae5d2220  vmovaps [rsp+0xD0], xmm13
0000713aae5d2229  vmovaps [rsp+0xE0], xmm15
0000713aae5d2232  sub rsp, 0x30
0000713aae5d2236  movaps [rsp], xmm14
0000713aae5d223b  movaps [rsp+0x10], xmm1
0000713aae5d2240  movaps [rsp+0x20], xmm15
0000713aae5d2246  lea rdi, [rsp]
0000713aae5d224a  mov esi, 0x00
0000713aae5d224f  mov rax, 0x5E9381C89530
0000713aae5d2259  call rax
0000713aae5d225b  movaps xmm14, [rsp]
0000713aae5d2260  add rsp, 0x30
0000713aae5d2264  vmovaps xmm0, [rsp]
0000713aae5d2269  vmovaps xmm1, [rsp+0x10]
0000713aae5d226f  vmovaps xmm2, [rsp+0x20]
0000713aae5d2275  vmovaps xmm3, [rsp+0x30]
0000713aae5d227b  vmovaps xmm4, [rsp+0x40]
0000713aae5d2281  vmovaps xmm5, [rsp+0x50]
0000713aae5d2287  vmovaps xmm6, [rsp+0x60]
0000713aae5d228d  vmovaps xmm7, [rsp+0x70]
0000713aae5d2293  vmovaps xmm8, [rsp+0x80]
0000713aae5d229c  vmovaps xmm9, [rsp+0x90]
0000713aae5d22a5  vmovaps xmm10, [rsp+0xA0]
0000713aae5d22ae  vmovaps xmm11, [rsp+0xB0]
0000713aae5d22b7  vmovaps xmm12, [rsp+0xC0]
0000713aae5d22c0  vmovaps xmm13, [rsp+0xD0]
0000713aae5d22c9  vmovaps xmm15, [rsp+0xE0]
0000713aae5d22d2  add rsp, 0xF0
0000713aae5d22d9  pop r11
0000713aae5d22db  pop r10
0000713aae5d22dd  pop r9
0000713aae5d22df  pop r8
0000713aae5d22e1  pop rsi
0000713aae5d22e2  pop rdi
0000713aae5d22e3  pop rdx
0000713aae5d22e4  pop rcx
0000713aae5d22e5  pop rax
0000713aae5d22e6  add rsp, 0x08
0000713aae5d22ea  jmp 0x0000713AAE5D1FBE
0000713aae5d22ef  call 0x0000713AAE4C34C0
0000713aae5d22f4  jmp 0x0000713AAE5D1FD4
0000713aae5d22f9  int3
0000713aae5d22fa  nop [rax+rax*1], ax
0000713aae5d2300  mov rax, [r15+0x50]
0000713aae5d2304  movups xmm1, [r13+rax*1]
0000713aae5d230a  lea r14, [rax+0x10]
0000713aae5d230e  movups xmm15, [r13+r14*1]
0000713aae5d2314  mov qword ptr [r15+0x48], 0x00
0000713aae5d231c  lea r14, [rax+0x40]
0000713aae5d2320  movups xmm14, [r13+r14*1]
0000713aae5d2326  lea r14, [rax+0x50]
0000713aae5d232a  movups xmm13, [r13+r14*1]
0000713aae5d2330  lea r14, [rax+0x80]
0000713aae5d2337  movups xmm12, [r13+r14*1]
0000713aae5d233d  lea r14, [rax+0x90]
0000713aae5d2344  movups xmm11, [r13+r14*1]
0000713aae5d234a  mov r14, [r15+0xF8]
0000713aae5d2351  movups [r13+r14*1], xmm1
0000713aae5d2357  lea r12, [rax+0x20]
0000713aae5d235b  movups xmm1, [r13+r12*1]
0000713aae5d2361  lea r12, [rax+0x30]
0000713aae5d2365  movups xmm10, [r13+r12*1]
0000713aae5d236b  lea r12, [rax+0xC0]
0000713aae5d2372  movups xmm9, [r13+r12*1]
0000713aae5d2378  lea r12, [rax+0xD0]
0000713aae5d237f  movups xmm8, [r13+r12*1]
0000713aae5d2385  lea r12, [rax+0x100]
0000713aae5d238c  movups xmm7, [r13+r12*1]
0000713aae5d2392  lea r12, [rax+0x110]
0000713aae5d2399  movups xmm6, [r13+r12*1]
0000713aae5d239f  lea r12, [rax+0x140]
0000713aae5d23a6  movups xmm5, [r13+r12*1]
0000713aae5d23ac  lea r12, [rax+0x150]
0000713aae5d23b3  movups xmm4, [r13+r12*1]
0000713aae5d23b9  lea r12, [r14+0xB0]
0000713aae5d23c0  movups [r13+r12*1], xmm10
0000713aae5d23c6  lea r12, [r14+0xC0]
0000713aae5d23cd  movups [r13+r12*1], xmm1
0000713aae5d23d3  lea r12, [rax+0x180]
0000713aae5d23da  movups xmm1, [r13+r12*1]
0000713aae5d23e0  lea r12, [rax+0x190]
0000713aae5d23e7  movups xmm10, [r13+r12*1]
0000713aae5d23ed  lea r12, [rax+0x1C0]
0000713aae5d23f4  movups xmm3, [r13+r12*1]
0000713aae5d23fa  lea r12, [rax+0x1D0]
0000713aae5d2401  movups xmm2, [r13+r12*1]
0000713aae5d2407  lea r12, [rax+0x60]
0000713aae5d240b  vmovaps [rsp+0x10], xmm1
0000713aae5d2411  movups xmm1, [r13+r12*1]
0000713aae5d2417  lea r12, [rax+0x70]
0000713aae5d241b  vmovaps [rsp+0x20], xmm1
0000713aae5d2421  movups xmm1, [r13+r12*1]
0000713aae5d2427  lea r12, [r14+0x70]
0000713aae5d242b  movups [r13+r12*1], xmm10
0000713aae5d2431  lea r12, [r14+0x80]
0000713aae5d2438  vmovaps xmm10, [rsp+0x10]
0000713aae5d243e  movups [r13+r12*1], xmm10
0000713aae5d2444  lea r12, [rax+0xA0]
0000713aae5d244b  movups xmm10, [r13+r12*1]
0000713aae5d2451  lea r12, [rax+0xB0]
0000713aae5d2458  vmovaps [rsp+0x10], xmm1
0000713aae5d245e  movups xmm1, [r13+r12*1]
0000713aae5d2464  lea r12, [r14+0x90]
0000713aae5d246b  movups [r13+r12*1], xmm2
0000713aae5d2471  lea r12, [r14+0xA0]
0000713aae5d2478  movups [r13+r12*1], xmm3
0000713aae5d247e  lea r12, [rax+0xE0]
0000713aae5d2485  movups xmm3, [r13+r12*1]
0000713aae5d248b  lea r12, [rax+0xF0]
0000713aae5d2492  movups xmm2, [r13+r12*1]
0000713aae5d2498  lea r12, [rax+0x120]
0000713aae5d249f  vmovaps [rsp+0x30], xmm1
0000713aae5d24a5  movups xmm1, [r13+r12*1]
0000713aae5d24ab  lea r12, [rax+0x130]
0000713aae5d24b2  vmovaps [rsp+0x40], xmm1
0000713aae5d24b8  movups xmm1, [r13+r12*1]
0000713aae5d24be  vmovaps [rsp+0x50], xmm1
0000713aae5d24c4  vmovaps xmm1, [rsp+0x40]
0000713aae5d24ca  movaps [r15+0x190], xmm1
0000713aae5d24d2  lea r12, [rax+0x160]
0000713aae5d24d9  vmovaps [rsp+0x40], xmm1
0000713aae5d24df  movups xmm1, [r13+r12*1]
0000713aae5d24e5  lea r12, [rax+0x170]
0000713aae5d24ec  vmovaps [rsp+0x60], xmm1
0000713aae5d24f2  movups xmm1, [r13+r12*1]
0000713aae5d24f8  lea r12, [rax+0x1A0]
0000713aae5d24ff  vmovaps [rsp+0x70], xmm1
0000713aae5d2505  movups xmm1, [r13+r12*1]
0000713aae5d250b  lea r12, [rax+0x1B0]
0000713aae5d2512  vmovaps [rsp+0x80], xmm1
0000713aae5d251b  movups xmm1, [r13+r12*1]
0000713aae5d2521  lea r12, [rax+0x1E0]
0000713aae5d2528  vmovaps [rsp+0x90], xmm1
0000713aae5d2531  movups xmm1, [r13+r12*1]
0000713aae5d2537  lea r12, [rax+0x1F0]
0000713aae5d253e  vmovaps [rsp+0xA0], xmm1
0000713aae5d2547  movups xmm1, [r13+r12*1]
0000713aae5d254d  mov qword ptr [r15+0x50], 0x432190
0000713aae5d2555  lea rax, [r14+0x50]
0000713aae5d2559  vmovaps [rsp+0xB0], xmm1
0000713aae5d2562  vmovaps xmm1, [rsp+0x60]
0000713aae5d2568  movups [r13+rax*1], xmm1
0000713aae5d256e  lea rax, [r14+0x60]
0000713aae5d2572  movups [r13+rax*1], xmm5
0000713aae5d2578  lea rax, [r14+0x40]
0000713aae5d257c  vmovaps xmm1, [rsp+0x70]
0000713aae5d2582  movups [r13+rax*1], xmm1
0000713aae5d2588  lea rax, [r14+0x20]
0000713aae5d258c  vmovaps xmm1, [rsp+0xA0]
0000713aae5d2595  movups [r13+rax*1], xmm1
0000713aae5d259b  lea rax, [r14+0x30]
0000713aae5d259f  vmovaps xmm1, [rsp+0x90]
0000713aae5d25a8  movups [r13+rax*1], xmm1
0000713aae5d25ae  lea rax, [r14+0x10]
0000713aae5d25b2  vmovaps xmm1, [rsp+0xB0]
0000713aae5d25bb  movups [r13+rax*1], xmm1
0000713aae5d25c1  mov rax, [r15+0x40]
0000713aae5d25c5  vxorps xmm1, xmm1, xmm1
0000713aae5d25c9  vpbroadcastq xmm1, xmm1
0000713aae5d25ce  vxorps xmm5, xmm5, xmm5
0000713aae5d25d2  vpbroadcastq xmm5, xmm5
0000713aae5d25d7  lea r12, [rax+0x30]
0000713aae5d25db  mov r11, [r13+r12*1]
0000713aae5d25e0  lea r12, [rax+0x38]
0000713aae5d25e4  mov r10, [r13+r12*1]
0000713aae5d25e9  vmovaps [rsp+0x60], xmm1
0000713aae5d25ef  movq xmm1, r11
0000713aae5d25f4  vmovaps [rsp+0x70], xmm1
0000713aae5d25fa  movq xmm1, r10
0000713aae5d25ff  vmovaps [rsp+0x90], xmm1
0000713aae5d2608  vmovaps xmm1, [rsp+0x70]
0000713aae5d260e  movq xmm1, xmm1
0000713aae5d2612  vmovaps [rsp+0x70], xmm1
0000713aae5d2618  vmovaps xmm1, [rsp+0x90]
0000713aae5d2621  movq xmm1, xmm1
0000713aae5d2625  vmovaps [rsp+0x90], xmm1
0000713aae5d262e  movq xmm1, xmm1
0000713aae5d2632  movaps [r15+0x270], xmm1
0000713aae5d263a  vmovaps [rsp+0xA0], xmm7
0000713aae5d2643  vmovaps xmm1, [rsp+0xA0]
0000713aae5d264c  por xmm7, xmm1
0000713aae5d2650  lea r12, [rax+0x20]
0000713aae5d2654  mov r11, [r13+r12*1]
0000713aae5d2659  lea r12, [rax+0x28]
0000713aae5d265d  mov r10, [r13+r12*1]
0000713aae5d2662  movq xmm1, r11
0000713aae5d2667  vmovaps [rsp+0xA0], xmm1
0000713aae5d2670  movq xmm1, r10
0000713aae5d2675  vmovaps [rsp+0xB0], xmm1
0000713aae5d267e  vmovaps xmm1, [rsp+0xA0]
0000713aae5d2687  movq xmm1, xmm1
0000713aae5d268b  vmovaps [rsp+0xA0], xmm1
0000713aae5d2694  vmovaps xmm1, [rsp+0xB0]
0000713aae5d269d  movq xmm1, xmm1
0000713aae5d26a1  vmovaps [rsp+0xB0], xmm2
0000713aae5d26aa  vmovaps [rsp+0xC0], xmm1
0000713aae5d26b3  vmovaps xmm1, [rsp+0xB0]
0000713aae5d26bc  por xmm2, xmm1
0000713aae5d26c0  vmovaps [rsp+0xB0], xmm3
0000713aae5d26c9  vmovaps xmm1, [rsp+0xB0]
0000713aae5d26d2  por xmm3, xmm1
0000713aae5d26d6  vmovaps [rsp+0xB0], xmm4
0000713aae5d26df  vmovaps xmm1, [rsp+0xB0]
0000713aae5d26e8  por xmm4, xmm1
0000713aae5d26ec  vmovaps [rsp+0xB0], xmm9
0000713aae5d26f5  vmovaps xmm1, [rsp+0xB0]
0000713aae5d26fe  por xmm9, xmm1
0000713aae5d2703  lea r12, [rax+0x10]
0000713aae5d2707  mov r11, [r13+r12*1]
0000713aae5d270c  lea r12, [rax+0x18]
0000713aae5d2710  mov r10, [r13+r12*1]
0000713aae5d2715  movq xmm1, r11
0000713aae5d271a  vmovaps [rsp+0xB0], xmm1
0000713aae5d2723  movq xmm1, r10
0000713aae5d2728  vmovaps [rsp+0xD0], xmm1
0000713aae5d2731  vmovaps xmm1, [rsp+0xB0]
0000713aae5d273a  movq xmm1, xmm1
0000713aae5d273e  vmovaps [rsp+0xB0], xmm1
0000713aae5d2747  vmovaps xmm1, [rsp+0xD0]
0000713aae5d2750  movq xmm1, xmm1
0000713aae5d2754  vmovaps [rsp+0xD0], xmm1
0000713aae5d275d  vmovaps xmm1, [rsp+0x80]
0000713aae5d2766  vmovaps [rsp+0xE0], xmm15
0000713aae5d276f  vmovaps xmm15, [rsp+0x80]
0000713aae5d2778  por xmm1, xmm15
0000713aae5d277d  vmovaps xmm15, [rsp+0x10]
0000713aae5d2783  vmovaps [rsp+0x80], xmm1
0000713aae5d278c  vmovaps xmm1, [rsp+0x10]
0000713aae5d2792  por xmm15, xmm1
0000713aae5d2797  vmovaps xmm1, [rsp+0x20]
0000713aae5d279d  vmovaps [rsp+0x10], xmm15
0000713aae5d27a3  vmovaps xmm15, [rsp+0x20]
0000713aae5d27a9  por xmm1, xmm15
0000713aae5d27ae  vmovaps [rsp+0x20], xmm6
0000713aae5d27b4  vmovaps xmm15, [rsp+0x20]
0000713aae5d27ba  por xmm6, xmm15
0000713aae5d27bf  vmovaps [rsp+0x20], xmm11
0000713aae5d27c5  vmovaps xmm15, [rsp+0x20]
0000713aae5d27cb  por xmm11, xmm15
0000713aae5d27d0  vmovaps [rsp+0x20], xmm13
0000713aae5d27d6  vmovaps xmm15, [rsp+0x20]
0000713aae5d27dc  por xmm13, xmm15
0000713aae5d27e1  vmovaps [rsp+0x20], xmm14
0000713aae5d27e7  vmovaps xmm15, [rsp+0x20]
0000713aae5d27ed  por xmm14, xmm15
0000713aae5d27f2  mov r12, [r13+rax*1]
0000713aae5d27f7  vmovq xmm15, r12
0000713aae5d27fc  vpbroadcastq xmm15, xmm15
0000713aae5d2801  vmovaps [rsp+0x20], xmm1
0000713aae5d2807  vxorps xmm1, xmm1, xmm1
0000713aae5d280b  vpbroadcastq xmm1, xmm1
0000713aae5d2810  vmovaps [rsp+0xF0], xmm1
0000713aae5d2819  movups xmm1, [r13+r14*1]
0000713aae5d281f  vmovaps [rsp+0x100], xmm1
0000713aae5d2828  vxorps xmm1, xmm1, xmm1
0000713aae5d282c  vpbroadcastq xmm1, xmm1
0000713aae5d2831  lea r12, [rax+0x08]
0000713aae5d2835  mov rax, [r13+r12*1]
0000713aae5d283a  vmovaps [rsp+0x110], xmm1
0000713aae5d2843  movq xmm1, rax
0000713aae5d2848  movaps [r15+0x240], xmm1
0000713aae5d2850  mov qword ptr [r15+0x60], 0x432190
0000713aae5d2858  mov qword ptr [r15+0x58], 0x40
0000713aae5d2860  vmovaps xmm1, [rsp+0x60]
0000713aae5d2866  vmovaps [rsp+0x60], xmm15
0000713aae5d286c  vmovaps xmm15, [rsp+0x100]
0000713aae5d2875  vmovaps [rsp+0x100], xmm14
0000713aae5d287e  vmovaps xmm14, [rsp+0x60]
0000713aae5d2884  vmovaps [rsp+0x60], xmm13
0000713aae5d288a  vmovaps [rsp+0x120], xmm12
0000713aae5d2893  movaps xmm13, xmm1
0000713aae5d2897  vfmadd231pd xmm13, xmm15, xmm14
0000713aae5d289c  vcmppd xmm12, xmm13, xmm13, 0x03
0000713aae5d28a2  vptest xmm12, xmm12
0000713aae5d28a7  jnz 0x0000713AAE5D3482
0000713aae5d28ad  vmovaps xmm1, [rsp+0xE0]
0000713aae5d28b6  movaps xmm15, xmm5
0000713aae5d28ba  vfmadd231pd xmm15, xmm1, xmm14
0000713aae5d28bf  vcmppd xmm12, xmm15, xmm15, 0x03
0000713aae5d28c5  vptest xmm12, xmm12
0000713aae5d28ca  jnz 0x0000713AAE5D35DB
0000713aae5d28d0  vmovaps xmm12, [rsp+0x50]
0000713aae5d28d6  vmovaps xmm5, [rsp+0x50]
0000713aae5d28dc  por xmm12, xmm5
0000713aae5d28e1  vmovaps xmm5, [rsp+0x30]
0000713aae5d28e7  vmovaps [rsp+0x50], xmm1
0000713aae5d28ed  vmovaps xmm1, [rsp+0x30]
0000713aae5d28f3  por xmm5, xmm1
0000713aae5d28f7  vmovaps [rsp+0x30], xmm10
0000713aae5d28fd  vmovaps xmm1, [rsp+0x30]
0000713aae5d2903  por xmm10, xmm1
0000713aae5d2908  vmovaps [rsp+0x30], xmm8
0000713aae5d290e  vmovaps xmm1, [rsp+0x30]
0000713aae5d2914  por xmm8, xmm1
0000713aae5d2919  vmovaps xmm1, [rsp+0x120]
0000713aae5d2922  vmovaps [rsp+0x30], xmm15
0000713aae5d2928  vmovaps xmm15, [rsp+0x120]
0000713aae5d2931  por xmm1, xmm15
0000713aae5d2936  vmovaps xmm15, [rsp+0x50]
0000713aae5d293c  vmovaps [rsp+0xE0], xmm1
0000713aae5d2945  vmovaps xmm1, [rsp+0x50]
0000713aae5d294b  por xmm15, xmm1
0000713aae5d2950  lea rax, [r14+0xC0]
0000713aae5d2957  movups xmm1, [r13+rax*1]
0000713aae5d295d  xor eax, eax
0000713aae5d295f  mov r12d, 0x40
0000713aae5d2965  mov r11d, 0x200
0000713aae5d296b  cmp r12, r11
0000713aae5d296e  cmc
0000713aae5d296f  lahf
0000713aae5d2970  seto al
0000713aae5d2973  mov [r15+0x108], eax
0000713aae5d297a  vmovaps [rsp+0x50], xmm1
0000713aae5d2980  vmovaps xmm1, [rsp+0xF0]
0000713aae5d2989  vmovaps [rsp+0xF0], xmm15
0000713aae5d2992  vmovaps xmm15, [rsp+0x50]
0000713aae5d2998  vmovaps [rsp+0x50], xmm13
0000713aae5d299e  vmovaps [rsp+0x120], xmm12
0000713aae5d29a7  movaps xmm13, xmm1
0000713aae5d29ab  vfmadd231pd xmm13, xmm15, xmm14
0000713aae5d29b0  vcmppd xmm12, xmm13, xmm13, 0x03
0000713aae5d29b6  vptest xmm12, xmm12
0000713aae5d29bb  jnz 0x0000713AAE5D373D
0000713aae5d29c1  lea rax, [r14+0xB0]
0000713aae5d29c8  movups xmm1, [r13+rax*1]
0000713aae5d29ce  vmovaps xmm15, [rsp+0x110]
0000713aae5d29d7  vmovaps [rsp+0x110], xmm13
0000713aae5d29e0  movaps xmm12, xmm15
0000713aae5d29e4  vfmadd231pd xmm12, xmm1, xmm14
0000713aae5d29e9  vcmppd xmm13, xmm12, xmm12, 0x03
0000713aae5d29ef  vptest xmm13, xmm13
0000713aae5d29f4  jnz 0x0000713AAE5D38A0
0000713aae5d29fa  vmovaps xmm1, [rsp+0x100]
0000713aae5d2a03  vmovaps xmm15, [rsp+0x100]
0000713aae5d2a0c  por xmm1, xmm15
0000713aae5d2a11  movaps [r15+0x210], xmm1
0000713aae5d2a19  vmovaps xmm15, [rsp+0x60]
0000713aae5d2a1f  vmovaps xmm14, [rsp+0x60]
0000713aae5d2a25  por xmm15, xmm14
0000713aae5d2a2a  movaps [r15+0x1C0], xmm15
0000713aae5d2a32  vmovaps [rsp+0x60], xmm11
0000713aae5d2a38  vmovaps xmm14, [rsp+0x60]
0000713aae5d2a3e  por xmm11, xmm14
0000713aae5d2a43  movaps [r15+0x280], xmm11
0000713aae5d2a4b  vmovaps [rsp+0x60], xmm6
0000713aae5d2a51  vmovaps xmm14, [rsp+0x60]
0000713aae5d2a57  por xmm6, xmm14
0000713aae5d2a5c  movaps [r15+0x2A0], xmm6
0000713aae5d2a64  vmovaps xmm14, [rsp+0x20]
0000713aae5d2a6a  vmovaps xmm13, [rsp+0x20]
0000713aae5d2a70  por xmm14, xmm13
0000713aae5d2a75  movaps [r15+0x2E0], xmm14
0000713aae5d2a7d  vmovaps xmm13, [rsp+0x10]
0000713aae5d2a83  vmovaps [rsp+0x20], xmm1
0000713aae5d2a89  vmovaps xmm1, [rsp+0x10]
0000713aae5d2a8f  por xmm13, xmm1
0000713aae5d2a94  movaps [r15+0x1F0], xmm13
0000713aae5d2a9c  vmovaps xmm1, [rsp+0xF0]
0000713aae5d2aa5  vmovaps [rsp+0x10], xmm15
0000713aae5d2aab  vmovaps xmm15, [rsp+0xF0]
0000713aae5d2ab4  por xmm1, xmm15
0000713aae5d2ab9  movaps [r15+0x250], xmm1
0000713aae5d2ac1  vmovaps xmm1, [rsp+0xE0]
0000713aae5d2aca  vmovaps xmm15, [rsp+0xE0]
0000713aae5d2ad3  por xmm1, xmm15
0000713aae5d2ad8  movaps [r15+0x260], xmm1
0000713aae5d2ae0  vmovaps [rsp+0x60], xmm8
0000713aae5d2ae6  vmovaps xmm15, [rsp+0x60]
0000713aae5d2aec  por xmm8, xmm15
0000713aae5d2af1  movaps [r15+0x290], xmm8
0000713aae5d2af9  vmovaps [rsp+0x60], xmm10
0000713aae5d2aff  vmovaps xmm15, [rsp+0x60]
0000713aae5d2b05  por xmm10, xmm15
0000713aae5d2b0a  movaps [r15+0x2C0], xmm10
0000713aae5d2b12  movq xmm15, qword ptr [r15+0x240]
0000713aae5d2b1b  vmovaps [rsp+0x60], xmm15
0000713aae5d2b21  vpermilpd xmm15, xmm15, 0x00
0000713aae5d2b27  vmovaps [rsp+0xE0], xmm1
0000713aae5d2b30  vmovaps xmm1, [rsp+0x50]
0000713aae5d2b36  vmovaps [rsp+0x50], xmm15
0000713aae5d2b3c  vmovaps xmm15, [rsp+0x20]
0000713aae5d2b42  vmovaps [rsp+0x20], xmm14
0000713aae5d2b48  vmovaps xmm14, [rsp+0x50]
0000713aae5d2b4e  vmovaps [rsp+0x50], xmm13
0000713aae5d2b54  vmovaps [rsp+0xF0], xmm12
0000713aae5d2b5d  movaps xmm13, xmm1
0000713aae5d2b61  vfmadd231pd xmm13, xmm15, xmm14
0000713aae5d2b66  vcmppd xmm12, xmm13, xmm13, 0x03
0000713aae5d2b6c  vptest xmm12, xmm12
0000713aae5d2b71  jnz 0x0000713AAE5D39F9
0000713aae5d2b77  vmovaps xmm1, [rsp+0x60]
0000713aae5d2b7d  vpermilpd xmm1, xmm1, 0x00
0000713aae5d2b83  vmovaps xmm15, [rsp+0x110]
0000713aae5d2b8c  vmovaps xmm14, [rsp+0x20]
0000713aae5d2b92  vmovaps [rsp+0x20], xmm13
0000713aae5d2b98  movaps xmm12, xmm15
0000713aae5d2b9c  vfmadd231pd xmm12, xmm14, xmm1
0000713aae5d2ba1  vcmppd xmm13, xmm12, xmm12, 0x03
0000713aae5d2ba7  vptest xmm13, xmm13
0000713aae5d2bac  jnz 0x0000713AAE5D3B52
0000713aae5d2bb2  vmovaps xmm1, [rsp+0x60]
0000713aae5d2bb8  vpermilpd xmm1, xmm1, 0x00
0000713aae5d2bbe  vmovaps xmm15, [rsp+0x30]
0000713aae5d2bc4  vmovaps xmm14, [rsp+0x10]
0000713aae5d2bca  vmovaps [rsp+0x10], xmm12
0000713aae5d2bd0  movaps xmm13, xmm15
0000713aae5d2bd4  vfmadd231pd xmm13, xmm14, xmm1
0000713aae5d2bd9  vcmppd xmm12, xmm13, xmm13, 0x03
0000713aae5d2bdf  vptest xmm12, xmm12
0000713aae5d2be4  jnz 0x0000713AAE5D3CAB
0000713aae5d2bea  vmovaps [rsp+0x30], xmm5
0000713aae5d2bf0  vmovaps xmm1, [rsp+0x30]
0000713aae5d2bf6  por xmm5, xmm1
0000713aae5d2bfa  movaps [r15+0x1D0], xmm5
0000713aae5d2c02  vmovaps xmm1, [rsp+0x60]
0000713aae5d2c08  vpermilpd xmm1, xmm1, 0x00
0000713aae5d2c0e  vmovaps xmm15, [rsp+0xF0]
0000713aae5d2c17  vmovaps xmm14, [rsp+0x50]
0000713aae5d2c1d  vmovaps [rsp+0x30], xmm13
0000713aae5d2c23  movaps xmm12, xmm15
0000713aae5d2c27  vfmadd231pd xmm12, xmm14, xmm1
0000713aae5d2c2c  vcmppd xmm13, xmm12, xmm12, 0x03
0000713aae5d2c32  vptest xmm13, xmm13
0000713aae5d2c37  jnz 0x0000713AAE5D3E04
0000713aae5d2c3d  vmovaps xmm1, [rsp+0x80]
0000713aae5d2c46  vmovaps xmm15, [rsp+0x80]
0000713aae5d2c4f  por xmm1, xmm15
0000713aae5d2c54  movaps [r15+0x200], xmm1
0000713aae5d2c5c  vmovaps xmm15, [rsp+0x120]
0000713aae5d2c65  vmovaps xmm14, [rsp+0x120]
0000713aae5d2c6e  por xmm15, xmm14
0000713aae5d2c73  movaps [r15+0x1E0], xmm15
0000713aae5d2c7b  vmovaps [rsp+0x50], xmm4
0000713aae5d2c81  vmovaps xmm13, [rsp+0x50]
0000713aae5d2c87  por xmm4, xmm13
0000713aae5d2c8c  movaps [r15+0x2B0], xmm4
0000713aae5d2c94  vmovaps [rsp+0x50], xmm3
0000713aae5d2c9a  vmovaps xmm13, [rsp+0x50]
0000713aae5d2ca0  por xmm3, xmm13
0000713aae5d2ca5  movaps [r15+0x300], xmm3
0000713aae5d2cad  vmovaps xmm15, [rsp+0xB0]
0000713aae5d2cb6  vpermilpd xmm15, xmm15, 0x00
0000713aae5d2cbc  vmovaps xmm3, [rsp+0x20]
0000713aae5d2cc2  vmovaps [rsp+0x20], xmm1
0000713aae5d2cc8  vmovaps xmm1, [rsp+0xE0]
0000713aae5d2cd1  vmovaps [rsp+0x50], xmm14
0000713aae5d2cd7  vmovaps [rsp+0x60], xmm13
0000713aae5d2cdd  movaps xmm14, xmm3
0000713aae5d2ce1  vfmadd231pd xmm14, xmm1, xmm15
0000713aae5d2ce6  vcmppd xmm13, xmm14, xmm14, 0x03
0000713aae5d2cec  vptest xmm13, xmm13
0000713aae5d2cf1  jnz 0x0000713AAE5D3F5D
0000713aae5d2cf7  vmovaps xmm1, [rsp+0xB0]
0000713aae5d2d00  vpermilpd xmm1, xmm1, 0x00
0000713aae5d2d06  vmovaps xmm15, [rsp+0x10]
0000713aae5d2d0c  movaps xmm13, xmm15
0000713aae5d2d10  vfmadd231pd xmm13, xmm10, xmm1
0000713aae5d2d15  vcmppd xmm3, xmm13, xmm13, 0x03
0000713aae5d2d1b  vptest xmm3, xmm3
0000713aae5d2d20  jnz 0x0000713AAE5D40B5
0000713aae5d2d26  vmovaps xmm1, [rsp+0xB0]
0000713aae5d2d2f  vpermilpd xmm1, xmm1, 0x00
0000713aae5d2d35  vmovaps xmm15, [rsp+0x30]
0000713aae5d2d3b  movaps xmm10, xmm15
0000713aae5d2d3f  vfmadd231pd xmm10, xmm11, xmm1
0000713aae5d2d44  vcmppd xmm3, xmm10, xmm10, 0x03
0000713aae5d2d4a  vptest xmm3, xmm3
0000713aae5d2d4f  jnz 0x0000713AAE5D420E
0000713aae5d2d55  vmovaps xmm1, [rsp+0xB0]
0000713aae5d2d5e  vpermilpd xmm1, xmm1, 0x00
0000713aae5d2d64  movaps xmm15, xmm12
0000713aae5d2d68  vfmadd231pd xmm15, xmm5, xmm1
0000713aae5d2d6d  vcmppd xmm11, xmm15, xmm15, 0x03
0000713aae5d2d73  vptest xmm11, xmm11
0000713aae5d2d78  jnz 0x0000713AAE5D4367
0000713aae5d2d7e  vmovaps [rsp+0x10], xmm9
0000713aae5d2d84  vmovaps xmm1, [rsp+0x10]
0000713aae5d2d8a  por xmm9, xmm1
0000713aae5d2d8f  movaps [r15+0x180], xmm9
0000713aae5d2d97  vmovaps [rsp+0x10], xmm2
0000713aae5d2d9d  vmovaps xmm1, [rsp+0x10]
0000713aae5d2da3  por xmm2, xmm1
0000713aae5d2da7  movaps [r15+0x2D0], xmm2
0000713aae5d2daf  vmovaps xmm12, [rsp+0xD0]
0000713aae5d2db8  vpermilpd xmm12, xmm12, 0x00
0000713aae5d2dbe  vmovaps xmm11, [rsp+0x60]
0000713aae5d2dc4  movaps xmm5, xmm13
0000713aae5d2dc8  vfmadd231pd xmm5, xmm11, xmm12
0000713aae5d2dcd  vcmppd xmm3, xmm5, xmm5, 0x03
0000713aae5d2dd2  vptest xmm3, xmm3
0000713aae5d2dd7  jnz 0x0000713AAE5D44BF
0000713aae5d2ddd  vmovaps xmm13, [rsp+0xD0]
0000713aae5d2de6  vpermilpd xmm13, xmm13, 0x00
0000713aae5d2dec  movaps xmm12, xmm14
0000713aae5d2df0  vfmadd231pd xmm12, xmm9, xmm13
0000713aae5d2df5  vcmppd xmm11, xmm12, xmm12, 0x03
0000713aae5d2dfb  vptest xmm11, xmm11
0000713aae5d2e00  jnz 0x0000713AAE5D4617
0000713aae5d2e06  lea rax, [r14+0x80]
0000713aae5d2e0d  movups xmm14, [r13+rax*1]
0000713aae5d2e13  movaps [r15+0x2F0], xmm14
0000713aae5d2e1b  vmovaps xmm13, [rsp+0xD0]
0000713aae5d2e24  vpermilpd xmm13, xmm13, 0x00
0000713aae5d2e2a  movaps xmm11, xmm10
0000713aae5d2e2e  vfmadd231pd xmm11, xmm8, xmm13
0000713aae5d2e33  vcmppd xmm9, xmm11, xmm11, 0x03
0000713aae5d2e39  vptest xmm9, xmm9
0000713aae5d2e3e  jnz 0x0000713AAE5D477B
0000713aae5d2e44  vmovaps xmm13, [rsp+0xD0]
0000713aae5d2e4d  vpermilpd xmm13, xmm13, 0x00
0000713aae5d2e53  movaps xmm10, xmm15
0000713aae5d2e57  vfmadd231pd xmm10, xmm1, xmm13
0000713aae5d2e5c  vcmppd xmm9, xmm10, xmm10, 0x03
0000713aae5d2e62  vptest xmm9, xmm9
0000713aae5d2e67  jnz 0x0000713AAE5D48D5
0000713aae5d2e6d  vmovaps [rsp+0x10], xmm7
0000713aae5d2e73  vmovaps xmm1, [rsp+0x10]
0000713aae5d2e79  por xmm7, xmm1
0000713aae5d2e7d  movaps [r15+0x160], xmm7
0000713aae5d2e85  lea rax, [r14+0x40]
0000713aae5d2e89  movups xmm1, [r13+rax*1]
0000713aae5d2e8f  lea rax, [r14+0x50]
0000713aae5d2e93  movups xmm15, [r13+rax*1]
0000713aae5d2e99  movaps [r15+0x1B0], xmm1
0000713aae5d2ea1  movaps [r15+0x1A0], xmm15
0000713aae5d2ea9  vmovaps xmm13, [rsp+0xA0]
0000713aae5d2eb2  vpermilpd xmm13, xmm13, 0x00
0000713aae5d2eb8  vmovaps xmm9, [rsp+0x40]
0000713aae5d2ebe  movaps xmm8, xmm5
0000713aae5d2ec2  vfmadd231pd xmm8, xmm9, xmm13
0000713aae5d2ec7  vcmppd xmm3, xmm8, xmm8, 0x03
0000713aae5d2ecd  vptest xmm3, xmm3
0000713aae5d2ed2  jnz 0x0000713AAE5D4A42
0000713aae5d2ed8  vmovaps xmm13, [rsp+0xA0]
0000713aae5d2ee1  vpermilpd xmm13, xmm13, 0x00
0000713aae5d2ee7  movaps xmm9, xmm12
0000713aae5d2eeb  vfmadd231pd xmm9, xmm7, xmm13
0000713aae5d2ef0  vcmppd xmm5, xmm9, xmm9, 0x03
0000713aae5d2ef6  vptest xmm5, xmm5
0000713aae5d2efb  jnz 0x0000713AAE5D4B9B
0000713aae5d2f01  vmovaps xmm13, [rsp+0xA0]
0000713aae5d2f0a  vpermilpd xmm13, xmm13, 0x00
0000713aae5d2f10  movaps xmm12, xmm11
0000713aae5d2f14  vfmadd231pd xmm12, xmm6, xmm13
0000713aae5d2f19  vcmppd xmm7, xmm12, xmm12, 0x03
0000713aae5d2f1f  vptest xmm7, xmm7
0000713aae5d2f24  jnz 0x0000713AAE5D4CF4
0000713aae5d2f2a  vmovaps xmm13, [rsp+0xA0]
0000713aae5d2f33  vpermilpd xmm13, xmm13, 0x00
0000713aae5d2f39  vmovaps xmm11, [rsp+0x50]
0000713aae5d2f3f  movaps xmm7, xmm10
0000713aae5d2f43  vfmadd231pd xmm7, xmm11, xmm13
0000713aae5d2f48  vcmppd xmm6, xmm7, xmm7, 0x03
0000713aae5d2f4d  vptest xmm6, xmm6
0000713aae5d2f52  jnz 0x0000713AAE5D4E4D
0000713aae5d2f58  lea rax, [r14+0x60]
0000713aae5d2f5c  movups xmm13, [r13+rax*1]
0000713aae5d2f62  lea rax, [r14+0x70]
0000713aae5d2f66  movups xmm11, [r13+rax*1]
0000713aae5d2f6c  movaps [r15+0x150], xmm13
0000713aae5d2f74  movaps [r15+0x120], xmm11
0000713aae5d2f7c  vmovaps xmm10, [rsp+0xC0]
0000713aae5d2f85  vpermilpd xmm10, xmm10, 0x00
0000713aae5d2f8b  movaps xmm6, xmm8
0000713aae5d2f8f  vfmadd231pd xmm6, xmm15, xmm10
0000713aae5d2f94  vcmppd xmm5, xmm6, xmm6, 0x03
0000713aae5d2f99  vptest xmm5, xmm5
0000713aae5d2f9e  jnz 0x0000713AAE5D4FB9
0000713aae5d2fa4  vmovaps xmm15, [rsp+0xC0]
0000713aae5d2fad  vpermilpd xmm15, xmm15, 0x00
0000713aae5d2fb3  movaps xmm10, xmm9
0000713aae5d2fb7  vfmadd231pd xmm10, xmm13, xmm15
0000713aae5d2fbc  vcmppd xmm8, xmm10, xmm10, 0x03
0000713aae5d2fc2  vptest xmm8, xmm8
0000713aae5d2fc7  jnz 0x0000713AAE5D5111
0000713aae5d2fcd  vmovaps xmm15, [rsp+0xC0]
0000713aae5d2fd6  vpermilpd xmm15, xmm15, 0x00
0000713aae5d2fdc  movaps xmm13, xmm12
0000713aae5d2fe0  vfmadd231pd xmm13, xmm4, xmm15
0000713aae5d2fe5  vcmppd xmm9, xmm13, xmm13, 0x03
0000713aae5d2feb  vptest xmm9, xmm9
0000713aae5d2ff0  jnz 0x0000713AAE5D526B
0000713aae5d2ff6  vmovaps xmm15, [rsp+0xC0]
0000713aae5d2fff  vpermilpd xmm15, xmm15, 0x00
0000713aae5d3005  movaps xmm12, xmm7
0000713aae5d3009  vfmadd231pd xmm12, xmm1, xmm15
0000713aae5d300e  vcmppd xmm9, xmm12, xmm12, 0x03
0000713aae5d3014  vptest xmm9, xmm9
0000713aae5d3019  jnz 0x0000713AAE5D53C4
0000713aae5d301f  lea rax, [r14+0x20]
0000713aae5d3023  movups xmm1, [r13+rax*1]
0000713aae5d3029  lea rax, [r14+0x30]
0000713aae5d302d  movups xmm15, [r13+rax*1]
0000713aae5d3033  vmovaps xmm9, [rsp+0x70]
0000713aae5d3039  vpermilpd xmm9, xmm9, 0x00
0000713aae5d303f  vmovaps xmm8, [rsp+0x20]
0000713aae5d3045  movaps xmm7, xmm6
0000713aae5d3048  vfmadd231pd xmm7, xmm8, xmm9
0000713aae5d304d  vcmppd xmm5, xmm7, xmm7, 0x03
0000713aae5d3052  vptest xmm5, xmm5
0000713aae5d3057  jnz 0x0000713AAE5D5530
0000713aae5d305d  vmovaps xmm9, [rsp+0x70]
0000713aae5d3063  vpermilpd xmm9, xmm9, 0x00
0000713aae5d3069  movaps xmm8, xmm10
0000713aae5d306d  vfmadd231pd xmm8, xmm14, xmm9
0000713aae5d3072  vcmppd xmm6, xmm8, xmm8, 0x03
0000713aae5d3078  vptest xmm6, xmm6
0000713aae5d307d  jnz 0x0000713AAE5D5687
0000713aae5d3083  vmovaps xmm14, [rsp+0x70]
0000713aae5d3089  vpermilpd xmm14, xmm14, 0x00
0000713aae5d308f  movaps xmm10, xmm13
0000713aae5d3093  vfmadd231pd xmm10, xmm11, xmm14
0000713aae5d3098  vcmppd xmm9, xmm10, xmm10, 0x03
0000713aae5d309e  vptest xmm9, xmm9
0000713aae5d30a3  jnz 0x0000713AAE5D57E1
0000713aae5d30a9  vmovaps xmm14, [rsp+0x70]
0000713aae5d30af  vpermilpd xmm14, xmm14, 0x00
0000713aae5d30b5  movaps xmm13, xmm12
0000713aae5d30b9  vfmadd231pd xmm13, xmm15, xmm14
0000713aae5d30be  vcmppd xmm11, xmm13, xmm13, 0x03
0000713aae5d30c4  vptest xmm11, xmm11
0000713aae5d30c9  jnz 0x0000713AAE5D593B
0000713aae5d30cf  lea rax, [r14+0x90]
0000713aae5d30d6  movups xmm15, [r13+rax*1]
0000713aae5d30dc  lea rax, [r14+0xA0]
0000713aae5d30e3  movups xmm14, [r13+rax*1]
0000713aae5d30e9  movaps [r15+0x140], xmm15
0000713aae5d30f1  movaps [r15+0x130], xmm14
0000713aae5d30f9  vmovaps xmm12, [rsp+0x90]
0000713aae5d3102  vpermilpd xmm12, xmm12, 0x00
0000713aae5d3108  movaps xmm11, xmm7
0000713aae5d310c  vfmadd231pd xmm11, xmm1, xmm12
0000713aae5d3111  vcmppd xmm9, xmm11, xmm11, 0x03
0000713aae5d3117  vptest xmm9, xmm9
0000713aae5d311c  jnz 0x0000713AAE5D5AA9
0000713aae5d3122  movaps [r15+0x220], xmm11
0000713aae5d312a  lea rax, [r14+0x10]
0000713aae5d312e  movups xmm1, [r13+rax*1]
0000713aae5d3134  movaps [r15+0x240], xmm1
0000713aae5d313c  vmovaps xmm12, [rsp+0x90]
0000713aae5d3145  vpermilpd xmm12, xmm12, 0x00
0000713aae5d314b  movaps xmm9, xmm8
0000713aae5d314f  vfmadd231pd xmm9, xmm14, xmm12
0000713aae5d3154  vcmppd xmm7, xmm9, xmm9, 0x03
0000713aae5d315a  vptest xmm7, xmm7
0000713aae5d315f  jnz 0x0000713AAE5D5C0B
0000713aae5d3165  movaps [r15+0x110], xmm9
0000713aae5d316d  vmovaps xmm14, [rsp+0x90]
0000713aae5d3176  vpermilpd xmm14, xmm14, 0x00
0000713aae5d317c  movaps xmm12, xmm10
0000713aae5d3180  vfmadd231pd xmm12, xmm15, xmm14
0000713aae5d3185  vcmppd xmm8, xmm12, xmm12, 0x03
0000713aae5d318b  vptest xmm8, xmm8
0000713aae5d3190  jnz 0x0000713AAE5D5D65
0000713aae5d3196  movaps [r15+0x170], xmm12
0000713aae5d319e  vmovaps xmm15, [rsp+0x90]
0000713aae5d31a7  vpermilpd xmm15, xmm15, 0x00
0000713aae5d31ad  movaps xmm14, xmm13
0000713aae5d31b1  vfmadd231pd xmm14, xmm1, xmm15
0000713aae5d31b6  vcmppd xmm10, xmm14, xmm14, 0x03
0000713aae5d31bc  vptest xmm10, xmm10
0000713aae5d31c1  jnz 0x0000713AAE5D5EBF
0000713aae5d31c7  movaps [r15+0x230], xmm14
0000713aae5d31cf  mov eax, 0x432190
0000713aae5d31d4  movups [r13+rax*1], xmm9
0000713aae5d31da  mov eax, 0x4321A0
0000713aae5d31df  movups [r13+rax*1], xmm12
0000713aae5d31e5  mov eax, 0x4321B0
0000713aae5d31ea  movups [r13+rax*1], xmm11
0000713aae5d31f0  mov eax, 0x4321C0
0000713aae5d31f5  movups [r13+rax*1], xmm14
0000713aae5d31fb  mov eax, [r15+0x108]
0000713aae5d3202  sahf
0000713aae5d3203  jnz 0x0000713AAE5D3235
0000713aae5d3205  cmp dword ptr [r15+0x318], 0x00
0000713aae5d320d  jz 0x0000713AAE5D9950
0000713aae5d3213  nop [rax+rax*1], ax
0000713aae5d321c  nop [rax+rax*1], eax
0000713aae5d3224  mov eax, 0x410664
0000713aae5d3229  mov [r15+0x100], rax
0000713aae5d3230  jmp 0x0000713AAE3FE110
0000713aae5d3235  cmp dword ptr [r15+0x318], 0x00
0000713aae5d323d  jz 0x0000713AAE5D6050
0000713aae5d3243  nop [rax+rax*1], ax
0000713aae5d324c  nop [rax+rax*1], eax
0000713aae5d3254  mov eax, 0x4104F0
0000713aae5d3259  mov [r15+0x100], rax
0000713aae5d3260  jmp 0x0000713AAE3FE110
0000713aae5d3265  int3
0000713aae5d3266  call 0x0000713AAE3FF430
0000713aae5d326b  jmp 0x0000713AAE5D230A
0000713aae5d3270  call 0x0000713AAE4E5820
0000713aae5d3275  jmp 0x0000713AAE5D2314
0000713aae5d327a  call 0x0000713AAE4E45A0
0000713aae5d327f  jmp 0x0000713AAE5D2326
0000713aae5d3284  call 0x0000713AAE4E3320
0000713aae5d3289  jmp 0x0000713AAE5D2330
0000713aae5d328e  call 0x0000713AAE4E20A0
0000713aae5d3293  jmp 0x0000713AAE5D233D
0000713aae5d3298  call 0x0000713AAE4E0E30
0000713aae5d329d  jmp 0x0000713AAE5D234A
0000713aae5d32a2  call 0x0000713AAE4D6600
0000713aae5d32a7  jmp 0x0000713AAE5D2357
0000713aae5d32ac  call 0x0000713AAE4B52F0
0000713aae5d32b1  jmp 0x0000713AAE5D2361
0000713aae5d32b6  call 0x0000713AAE4BE9C0
0000713aae5d32bb  jmp 0x0000713AAE5D236B
0000713aae5d32c0  call 0x0000713AAE4BD750
0000713aae5d32c5  jmp 0x0000713AAE5D2378
0000713aae5d32ca  call 0x0000713AAE4BC4E0
0000713aae5d32cf  jmp 0x0000713AAE5D2385
0000713aae5d32d4  call 0x0000713AAE4BB270
0000713aae5d32d9  jmp 0x0000713AAE5D2392
0000713aae5d32de  call 0x0000713AAE4BA000
0000713aae5d32e3  jmp 0x0000713AAE5D239F
0000713aae5d32e8  call 0x0000713AAE4B8D90
0000713aae5d32ed  jmp 0x0000713AAE5D23AC
0000713aae5d32f2  call 0x0000713AAE4B8A20
0000713aae5d32f7  jmp 0x0000713AAE5D23B9
0000713aae5d32fc  call 0x0000713AAE4BEAE0
0000713aae5d3301  jmp 0x0000713AAE5D23C6
0000713aae5d3306  call 0x0000713AAE4B5400
0000713aae5d330b  jmp 0x0000713AAE5D23D3
0000713aae5d3310  call 0x0000713AAE4B52F0
0000713aae5d3315  jmp 0x0000713AAE5D23E0
0000713aae5d331a  call 0x0000713AAE4BE9C0
0000713aae5d331f  jmp 0x0000713AAE5D23ED
0000713aae5d3324  call 0x0000713AAE4B77B0
0000713aae5d3329  jmp 0x0000713AAE5D23FA
0000713aae5d332e  call 0x0000713AAE4B6550
0000713aae5d3333  jmp 0x0000713AAE5D2407
0000713aae5d3338  call 0x0000713AAE4B52F0
0000713aae5d333d  jmp 0x0000713AAE5D2417
0000713aae5d3342  call 0x0000713AAE4B52F0
0000713aae5d3347  jmp 0x0000713AAE5D2427
0000713aae5d334c  call 0x0000713AAE4BEAE0
0000713aae5d3351  jmp 0x0000713AAE5D2431
0000713aae5d3356  call 0x0000713AAE4BEAE0
0000713aae5d335b  jmp 0x0000713AAE5D2444
0000713aae5d3360  call 0x0000713AAE4BE9C0
0000713aae5d3365  jmp 0x0000713AAE5D2451
0000713aae5d336a  call 0x0000713AAE4B52F0
0000713aae5d336f  jmp 0x0000713AAE5D2464
0000713aae5d3374  call 0x0000713AAE4B6660
0000713aae5d3379  jmp 0x0000713AAE5D2471
0000713aae5d337e  call 0x0000713AAE4B78C0
0000713aae5d3383  jmp 0x0000713AAE5D247E
0000713aae5d3388  call 0x0000713AAE4B77B0
0000713aae5d338d  jmp 0x0000713AAE5D248B
0000713aae5d3392  call 0x0000713AAE4B6550
0000713aae5d3397  jmp 0x0000713AAE5D2498
0000713aae5d339c  call 0x0000713AAE4B52F0
0000713aae5d33a1  jmp 0x0000713AAE5D24AB
0000713aae5d33a6  call 0x0000713AAE4B52F0
0000713aae5d33ab  jmp 0x0000713AAE5D24BE
0000713aae5d33b0  call 0x0000713AAE4B52F0
0000713aae5d33b5  jmp 0x0000713AAE5D24E5
0000713aae5d33ba  call 0x0000713AAE4B52F0
0000713aae5d33bf  jmp 0x0000713AAE5D24F8
0000713aae5d33c4  call 0x0000713AAE4B52F0
0000713aae5d33c9  jmp 0x0000713AAE5D250B
0000713aae5d33ce  call 0x0000713AAE4B52F0
0000713aae5d33d3  jmp 0x0000713AAE5D2521
0000713aae5d33d8  call 0x0000713AAE4B52F0
0000713aae5d33dd  jmp 0x0000713AAE5D2537
0000713aae5d33e2  call 0x0000713AAE4B52F0
0000713aae5d33e7  jmp 0x0000713AAE5D254D
0000713aae5d33ec  call 0x0000713AAE3FF540
0000713aae5d33f1  jmp 0x0000713AAE5D256E
0000713aae5d33f6  call 0x0000713AAE402FE0
0000713aae5d33fb  jmp 0x0000713AAE5D2578
0000713aae5d3400  call 0x0000713AAE3FF540
0000713aae5d3405  jmp 0x0000713AAE5D2588
0000713aae5d340a  call 0x0000713AAE3FF540
0000713aae5d340f  jmp 0x0000713AAE5D259B
0000713aae5d3414  call 0x0000713AAE3FF540
0000713aae5d3419  jmp 0x0000713AAE5D25AE
0000713aae5d341e  call 0x0000713AAE3FF540
0000713aae5d3423  jmp 0x0000713AAE5D25C1
0000713aae5d3428  call 0x0000713AAE4C0370
0000713aae5d342d  jmp 0x0000713AAE5D25E0
0000713aae5d3432  call 0x0000713AAE4BF100
0000713aae5d3437  jmp 0x0000713AAE5D25E9
0000713aae5d343c  call 0x0000713AAE4C0370
0000713aae5d3441  jmp 0x0000713AAE5D2659
0000713aae5d3446  call 0x0000713AAE4BF100
0000713aae5d344b  jmp 0x0000713AAE5D2662
0000713aae5d3450  call 0x0000713AAE4C0370
0000713aae5d3455  jmp 0x0000713AAE5D270C
0000713aae5d345a  call 0x0000713AAE4BF100
0000713aae5d345f  jmp 0x0000713AAE5D2715
0000713aae5d3464  call 0x0000713AAE40B720
0000713aae5d3469  jmp 0x0000713AAE5D27F7
0000713aae5d346e  call 0x0000713AAE4D64F0
0000713aae5d3473  jmp 0x0000713AAE5D281F
0000713aae5d3478  call 0x0000713AAE4B47C0
0000713aae5d347d  jmp 0x0000713AAE5D283A
0000713aae5d3482  sub rsp, 0x08
0000713aae5d3486  push rax
0000713aae5d3487  push rcx
0000713aae5d3488  push rdx
0000713aae5d3489  push rdi
0000713aae5d348a  push rsi
0000713aae5d348b  push r8
0000713aae5d348d  push r9
0000713aae5d348f  push r10
0000713aae5d3491  push r11
0000713aae5d3493  sub rsp, 0xF0
0000713aae5d349a  vmovaps [rsp], xmm0
0000713aae5d349f  vmovaps [rsp+0x10], xmm1
0000713aae5d34a5  vmovaps [rsp+0x20], xmm2
0000713aae5d34ab  vmovaps [rsp+0x30], xmm3
0000713aae5d34b1  vmovaps [rsp+0x40], xmm4
0000713aae5d34b7  vmovaps [rsp+0x50], xmm5
0000713aae5d34bd  vmovaps [rsp+0x60], xmm6
0000713aae5d34c3  vmovaps [rsp+0x70], xmm7
0000713aae5d34c9  vmovaps [rsp+0x80], xmm8
0000713aae5d34d2  vmovaps [rsp+0x90], xmm9
0000713aae5d34db  vmovaps [rsp+0xA0], xmm10
0000713aae5d34e4  vmovaps [rsp+0xB0], xmm11
0000713aae5d34ed  vmovaps [rsp+0xC0], xmm12
0000713aae5d34f6  vmovaps [rsp+0xD0], xmm14
0000713aae5d34ff  vmovaps [rsp+0xE0], xmm15
0000713aae5d3508  sub rsp, 0x40
0000713aae5d350c  lea rdi, [rsp]
0000713aae5d3510  lea rsi, [rsp+0x10]
0000713aae5d3515  lea rdx, [rsp+0x20]
0000713aae5d351a  lea rcx, [rsp+0x30]
0000713aae5d351f  mov r8d, 0x00
0000713aae5d3525  lea r9, [r15+0x3A8]
0000713aae5d352c  movaps [rdi], xmm13
0000713aae5d3530  movaps [rsi], xmm1
0000713aae5d3533  movaps [rdx], xmm15
0000713aae5d3537  movaps [rcx], xmm14
0000713aae5d353b  mov rax, 0x5E9381C89A50
0000713aae5d3545  call rax
0000713aae5d3547  movaps xmm13, [rsp]
0000713aae5d354c  add rsp, 0x40
0000713aae5d3550  vmovaps xmm0, [rsp]
0000713aae5d3555  vmovaps xmm1, [rsp+0x10]
0000713aae5d355b  vmovaps xmm2, [rsp+0x20]
0000713aae5d3561  vmovaps xmm3, [rsp+0x30]
0000713aae5d3567  vmovaps xmm4, [rsp+0x40]
0000713aae5d356d  vmovaps xmm5, [rsp+0x50]
0000713aae5d3573  vmovaps xmm6, [rsp+0x60]
0000713aae5d3579  vmovaps xmm7, [rsp+0x70]
0000713aae5d357f  vmovaps xmm8, [rsp+0x80]
0000713aae5d3588  vmovaps xmm9, [rsp+0x90]
0000713aae5d3591  vmovaps xmm10, [rsp+0xA0]
0000713aae5d359a  vmovaps xmm11, [rsp+0xB0]
0000713aae5d35a3  vmovaps xmm12, [rsp+0xC0]
0000713aae5d35ac  vmovaps xmm14, [rsp+0xD0]
0000713aae5d35b5  vmovaps xmm15, [rsp+0xE0]
0000713aae5d35be  add rsp, 0xF0
0000713aae5d35c5  pop r11
0000713aae5d35c7  pop r10
0000713aae5d35c9  pop r9
0000713aae5d35cb  pop r8
0000713aae5d35cd  pop rsi
0000713aae5d35ce  pop rdi
0000713aae5d35cf  pop rdx
0000713aae5d35d0  pop rcx
0000713aae5d35d1  pop rax
0000713aae5d35d2  add rsp, 0x08
0000713aae5d35d6  jmp 0x0000713AAE5D28AD
0000713aae5d35db  sub rsp, 0x08
0000713aae5d35df  push rax
0000713aae5d35e0  push rcx
0000713aae5d35e1  push rdx
0000713aae5d35e2  push rdi
0000713aae5d35e3  push rsi
0000713aae5d35e4  push r8
0000713aae5d35e6  push r9
0000713aae5d35e8  push r10
0000713aae5d35ea  push r11
0000713aae5d35ec  sub rsp, 0xF0
0000713aae5d35f3  vmovaps [rsp], xmm0
0000713aae5d35f8  vmovaps [rsp+0x10], xmm1
0000713aae5d35fe  vmovaps [rsp+0x20], xmm2
0000713aae5d3604  vmovaps [rsp+0x30], xmm3
0000713aae5d360a  vmovaps [rsp+0x40], xmm4
0000713aae5d3610  vmovaps [rsp+0x50], xmm5
0000713aae5d3616  vmovaps [rsp+0x60], xmm6
0000713aae5d361c  vmovaps [rsp+0x70], xmm7
0000713aae5d3622  vmovaps [rsp+0x80], xmm8
0000713aae5d362b  vmovaps [rsp+0x90], xmm9
0000713aae5d3634  vmovaps [rsp+0xA0], xmm10
0000713aae5d363d  vmovaps [rsp+0xB0], xmm11
0000713aae5d3646  vmovaps [rsp+0xC0], xmm12
0000713aae5d364f  vmovaps [rsp+0xD0], xmm13
0000713aae5d3658  vmovaps [rsp+0xE0], xmm14
0000713aae5d3661  sub rsp, 0x40
0000713aae5d3665  lea rdi, [rsp]
0000713aae5d3669  lea rsi, [rsp+0x10]
0000713aae5d366e  lea rdx, [rsp+0x20]
0000713aae5d3673  lea rcx, [rsp+0x30]
0000713aae5d3678  mov r8d, 0x00
0000713aae5d367e  lea r9, [r15+0x3A8]
0000713aae5d3685  movaps [rdi], xmm15
0000713aae5d3689  movaps [rsi], xmm5
0000713aae5d368c  movaps [rdx], xmm1
0000713aae5d368f  movaps [rcx], xmm14
0000713aae5d3693  mov rax, 0x5E9381C89A50
0000713aae5d369d  call rax
0000713aae5d369f  movaps xmm15, [rsp]
0000713aae5d36a4  add rsp, 0x40
0000713aae5d36a8  vmovaps xmm0, [rsp]
0000713aae5d36ad  vmovaps xmm1, [rsp+0x10]
0000713aae5d36b3  vmovaps xmm2, [rsp+0x20]
0000713aae5d36b9  vmovaps xmm3, [rsp+0x30]
0000713aae5d36bf  vmovaps xmm4, [rsp+0x40]
0000713aae5d36c5  vmovaps xmm5, [rsp+0x50]
0000713aae5d36cb  vmovaps xmm6, [rsp+0x60]
0000713aae5d36d1  vmovaps xmm7, [rsp+0x70]
0000713aae5d36d7  vmovaps xmm8, [rsp+0x80]
0000713aae5d36e0  vmovaps xmm9, [rsp+0x90]
0000713aae5d36e9  vmovaps xmm10, [rsp+0xA0]
0000713aae5d36f2  vmovaps xmm11, [rsp+0xB0]
0000713aae5d36fb  vmovaps xmm12, [rsp+0xC0]
0000713aae5d3704  vmovaps xmm13, [rsp+0xD0]
0000713aae5d370d  vmovaps xmm14, [rsp+0xE0]
0000713aae5d3716  add rsp, 0xF0
0000713aae5d371d  pop r11
0000713aae5d371f  pop r10
0000713aae5d3721  pop r9
0000713aae5d3723  pop r8
0000713aae5d3725  pop rsi
0000713aae5d3726  pop rdi
0000713aae5d3727  pop rdx
0000713aae5d3728  pop rcx
0000713aae5d3729  pop rax
0000713aae5d372a  add rsp, 0x08
0000713aae5d372e  jmp 0x0000713AAE5D28D0
0000713aae5d3733  call 0x0000713AAE3FF430
0000713aae5d3738  jmp 0x0000713AAE5D295D
0000713aae5d373d  sub rsp, 0x08
0000713aae5d3741  push rax
0000713aae5d3742  push rcx
0000713aae5d3743  push rdx
0000713aae5d3744  push rdi
0000713aae5d3745  push rsi
0000713aae5d3746  push r8
0000713aae5d3748  push r9
0000713aae5d374a  push r10
0000713aae5d374c  push r11
0000713aae5d374e  sub rsp, 0xF0
0000713aae5d3755  vmovaps [rsp], xmm0
0000713aae5d375a  vmovaps [rsp+0x10], xmm1
0000713aae5d3760  vmovaps [rsp+0x20], xmm2
0000713aae5d3766  vmovaps [rsp+0x30], xmm3
0000713aae5d376c  vmovaps [rsp+0x40], xmm4
0000713aae5d3772  vmovaps [rsp+0x50], xmm5
0000713aae5d3778  vmovaps [rsp+0x60], xmm6
0000713aae5d377e  vmovaps [rsp+0x70], xmm7
0000713aae5d3784  vmovaps [rsp+0x80], xmm8
0000713aae5d378d  vmovaps [rsp+0x90], xmm9
0000713aae5d3796  vmovaps [rsp+0xA0], xmm10
0000713aae5d379f  vmovaps [rsp+0xB0], xmm11
0000713aae5d37a8  vmovaps [rsp+0xC0], xmm12
0000713aae5d37b1  vmovaps [rsp+0xD0], xmm14
0000713aae5d37ba  vmovaps [rsp+0xE0], xmm15
0000713aae5d37c3  sub rsp, 0x40
0000713aae5d37c7  lea rdi, [rsp]
0000713aae5d37cb  lea rsi, [rsp+0x10]
0000713aae5d37d0  lea rdx, [rsp+0x20]
0000713aae5d37d5  lea rcx, [rsp+0x30]
0000713aae5d37da  mov r8d, 0x00
0000713aae5d37e0  lea r9, [r15+0x3A8]
0000713aae5d37e7  movaps [rdi], xmm13
0000713aae5d37eb  movaps [rsi], xmm1
0000713aae5d37ee  movaps [rdx], xmm15
0000713aae5d37f2  movaps [rcx], xmm14
0000713aae5d37f6  mov rax, 0x5E9381C89A50
0000713aae5d3800  call rax
0000713aae5d3802  movaps xmm13, [rsp]
0000713aae5d3807  add rsp, 0x40
0000713aae5d380b  vmovaps xmm0, [rsp]
0000713aae5d3810  vmovaps xmm1, [rsp+0x10]
0000713aae5d3816  vmovaps xmm2, [rsp+0x20]
0000713aae5d381c  vmovaps xmm3, [rsp+0x30]
0000713aae5d3822  vmovaps xmm4, [rsp+0x40]
0000713aae5d3828  vmovaps xmm5, [rsp+0x50]
0000713aae5d382e  vmovaps xmm6, [rsp+0x60]
0000713aae5d3834  vmovaps xmm7, [rsp+0x70]
0000713aae5d383a  vmovaps xmm8, [rsp+0x80]
0000713aae5d3843  vmovaps xmm9, [rsp+0x90]
0000713aae5d384c  vmovaps xmm10, [rsp+0xA0]
0000713aae5d3855  vmovaps xmm11, [rsp+0xB0]
0000713aae5d385e  vmovaps xmm12, [rsp+0xC0]
0000713aae5d3867  vmovaps xmm14, [rsp+0xD0]
0000713aae5d3870  vmovaps xmm15, [rsp+0xE0]
0000713aae5d3879  add rsp, 0xF0
0000713aae5d3880  pop r11
0000713aae5d3882  pop r10
0000713aae5d3884  pop r9
0000713aae5d3886  pop r8
0000713aae5d3888  pop rsi
0000713aae5d3889  pop rdi
0000713aae5d388a  pop rdx
0000713aae5d388b  pop rcx
0000713aae5d388c  pop rax
0000713aae5d388d  add rsp, 0x08
0000713aae5d3891  jmp 0x0000713AAE5D29C1
0000713aae5d3896  call 0x0000713AAE3FF430
0000713aae5d389b  jmp 0x0000713AAE5D29CE
0000713aae5d38a0  sub rsp, 0x08
0000713aae5d38a4  push rax
0000713aae5d38a5  push rcx
0000713aae5d38a6  push rdx
0000713aae5d38a7  push rdi
0000713aae5d38a8  push rsi
0000713aae5d38a9  push r8
0000713aae5d38ab  push r9
0000713aae5d38ad  push r10
0000713aae5d38af  push r11
0000713aae5d38b1  sub rsp, 0xF0
0000713aae5d38b8  vmovaps [rsp], xmm0
0000713aae5d38bd  vmovaps [rsp+0x10], xmm1
0000713aae5d38c3  vmovaps [rsp+0x20], xmm2
0000713aae5d38c9  vmovaps [rsp+0x30], xmm3
0000713aae5d38cf  vmovaps [rsp+0x40], xmm4
0000713aae5d38d5  vmovaps [rsp+0x50], xmm5
0000713aae5d38db  vmovaps [rsp+0x60], xmm6
0000713aae5d38e1  vmovaps [rsp+0x70], xmm7
0000713aae5d38e7  vmovaps [rsp+0x80], xmm8
0000713aae5d38f0  vmovaps [rsp+0x90], xmm9
0000713aae5d38f9  vmovaps [rsp+0xA0], xmm10
0000713aae5d3902  vmovaps [rsp+0xB0], xmm11
0000713aae5d390b  vmovaps [rsp+0xC0], xmm13
0000713aae5d3914  vmovaps [rsp+0xD0], xmm14
0000713aae5d391d  vmovaps [rsp+0xE0], xmm15
0000713aae5d3926  sub rsp, 0x40
0000713aae5d392a  lea rdi, [rsp]
0000713aae5d392e  lea rsi, [rsp+0x10]
0000713aae5d3933  lea rdx, [rsp+0x20]
0000713aae5d3938  lea rcx, [rsp+0x30]
0000713aae5d393d  mov r8d, 0x00
0000713aae5d3943  lea r9, [r15+0x3A8]
0000713aae5d394a  movaps [rdi], xmm12
0000713aae5d394e  movaps [rsi], xmm15
0000713aae5d3952  movaps [rdx], xmm1
0000713aae5d3955  movaps [rcx], xmm14
0000713aae5d3959  mov rax, 0x5E9381C89A50
0000713aae5d3963  call rax
0000713aae5d3965  movaps xmm12, [rsp]
0000713aae5d396a  add rsp, 0x40
0000713aae5d396e  vmovaps xmm0, [rsp]
0000713aae5d3973  vmovaps xmm1, [rsp+0x10]
0000713aae5d3979  vmovaps xmm2, [rsp+0x20]
0000713aae5d397f  vmovaps xmm3, [rsp+0x30]
0000713aae5d3985  vmovaps xmm4, [rsp+0x40]
0000713aae5d398b  vmovaps xmm5, [rsp+0x50]
0000713aae5d3991  vmovaps xmm6, [rsp+0x60]
0000713aae5d3997  vmovaps xmm7, [rsp+0x70]
0000713aae5d399d  vmovaps xmm8, [rsp+0x80]
0000713aae5d39a6  vmovaps xmm9, [rsp+0x90]
0000713aae5d39af  vmovaps xmm10, [rsp+0xA0]
0000713aae5d39b8  vmovaps xmm11, [rsp+0xB0]
0000713aae5d39c1  vmovaps xmm13, [rsp+0xC0]
0000713aae5d39ca  vmovaps xmm14, [rsp+0xD0]
0000713aae5d39d3  vmovaps xmm15, [rsp+0xE0]
0000713aae5d39dc  add rsp, 0xF0
0000713aae5d39e3  pop r11
0000713aae5d39e5  pop r10
0000713aae5d39e7  pop r9
0000713aae5d39e9  pop r8
0000713aae5d39eb  pop rsi
0000713aae5d39ec  pop rdi
0000713aae5d39ed  pop rdx
0000713aae5d39ee  pop rcx
0000713aae5d39ef  pop rax
0000713aae5d39f0  add rsp, 0x08
0000713aae5d39f4  jmp 0x0000713AAE5D29FA
0000713aae5d39f9  sub rsp, 0x08
0000713aae5d39fd  push rax
0000713aae5d39fe  push rcx
0000713aae5d39ff  push rdx
0000713aae5d3a00  push rdi
0000713aae5d3a01  push rsi
0000713aae5d3a02  push r8
0000713aae5d3a04  push r9
0000713aae5d3a06  push r10
0000713aae5d3a08  push r11
0000713aae5d3a0a  sub rsp, 0xF0
0000713aae5d3a11  vmovaps [rsp], xmm0
0000713aae5d3a16  vmovaps [rsp+0x10], xmm1
0000713aae5d3a1c  vmovaps [rsp+0x20], xmm2
0000713aae5d3a22  vmovaps [rsp+0x30], xmm3
0000713aae5d3a28  vmovaps [rsp+0x40], xmm4
0000713aae5d3a2e  vmovaps [rsp+0x50], xmm5
0000713aae5d3a34  vmovaps [rsp+0x60], xmm6
0000713aae5d3a3a  vmovaps [rsp+0x70], xmm7
0000713aae5d3a40  vmovaps [rsp+0x80], xmm8
0000713aae5d3a49  vmovaps [rsp+0x90], xmm9
0000713aae5d3a52  vmovaps [rsp+0xA0], xmm10
0000713aae5d3a5b  vmovaps [rsp+0xB0], xmm11
0000713aae5d3a64  vmovaps [rsp+0xC0], xmm12
0000713aae5d3a6d  vmovaps [rsp+0xD0], xmm14
0000713aae5d3a76  vmovaps [rsp+0xE0], xmm15
0000713aae5d3a7f  sub rsp, 0x40
0000713aae5d3a83  lea rdi, [rsp]
0000713aae5d3a87  lea rsi, [rsp+0x10]
0000713aae5d3a8c  lea rdx, [rsp+0x20]
0000713aae5d3a91  lea rcx, [rsp+0x30]
0000713aae5d3a96  mov r8d, 0x00
0000713aae5d3a9c  lea r9, [r15+0x3A8]
0000713aae5d3aa3  movaps [rdi], xmm13
0000713aae5d3aa7  movaps [rsi], xmm1
0000713aae5d3aaa  movaps [rdx], xmm15
0000713aae5d3aae  movaps [rcx], xmm14
0000713aae5d3ab2  mov rax, 0x5E9381C89A50
0000713aae5d3abc  call rax
0000713aae5d3abe  movaps xmm13, [rsp]
0000713aae5d3ac3  add rsp, 0x40
0000713aae5d3ac7  vmovaps xmm0, [rsp]
0000713aae5d3acc  vmovaps xmm1, [rsp+0x10]
0000713aae5d3ad2  vmovaps xmm2, [rsp+0x20]
0000713aae5d3ad8  vmovaps xmm3, [rsp+0x30]
0000713aae5d3ade  vmovaps xmm4, [rsp+0x40]
0000713aae5d3ae4  vmovaps xmm5, [rsp+0x50]
0000713aae5d3aea  vmovaps xmm6, [rsp+0x60]
0000713aae5d3af0  vmovaps xmm7, [rsp+0x70]
0000713aae5d3af6  vmovaps xmm8, [rsp+0x80]
0000713aae5d3aff  vmovaps xmm9, [rsp+0x90]
0000713aae5d3b08  vmovaps xmm10, [rsp+0xA0]
0000713aae5d3b11  vmovaps xmm11, [rsp+0xB0]
0000713aae5d3b1a  vmovaps xmm12, [rsp+0xC0]
0000713aae5d3b23  vmovaps xmm14, [rsp+0xD0]
0000713aae5d3b2c  vmovaps xmm15, [rsp+0xE0]
0000713aae5d3b35  add rsp, 0xF0
0000713aae5d3b3c  pop r11
0000713aae5d3b3e  pop r10
0000713aae5d3b40  pop r9
0000713aae5d3b42  pop r8
0000713aae5d3b44  pop rsi
0000713aae5d3b45  pop rdi
0000713aae5d3b46  pop rdx
0000713aae5d3b47  pop rcx
0000713aae5d3b48  pop rax
0000713aae5d3b49  add rsp, 0x08
0000713aae5d3b4d  jmp 0x0000713AAE5D2B77
0000713aae5d3b52  sub rsp, 0x08
0000713aae5d3b56  push rax
0000713aae5d3b57  push rcx
0000713aae5d3b58  push rdx
0000713aae5d3b59  push rdi
0000713aae5d3b5a  push rsi
0000713aae5d3b5b  push r8
0000713aae5d3b5d  push r9
0000713aae5d3b5f  push r10
0000713aae5d3b61  push r11
0000713aae5d3b63  sub rsp, 0xF0
0000713aae5d3b6a  vmovaps [rsp], xmm0
0000713aae5d3b6f  vmovaps [rsp+0x10], xmm1
0000713aae5d3b75  vmovaps [rsp+0x20], xmm2
0000713aae5d3b7b  vmovaps [rsp+0x30], xmm3
0000713aae5d3b81  vmovaps [rsp+0x40], xmm4
0000713aae5d3b87  vmovaps [rsp+0x50], xmm5
0000713aae5d3b8d  vmovaps [rsp+0x60], xmm6
0000713aae5d3b93  vmovaps [rsp+0x70], xmm7
0000713aae5d3b99  vmovaps [rsp+0x80], xmm8
0000713aae5d3ba2  vmovaps [rsp+0x90], xmm9
0000713aae5d3bab  vmovaps [rsp+0xA0], xmm10
0000713aae5d3bb4  vmovaps [rsp+0xB0], xmm11
0000713aae5d3bbd  vmovaps [rsp+0xC0], xmm13
0000713aae5d3bc6  vmovaps [rsp+0xD0], xmm14
0000713aae5d3bcf  vmovaps [rsp+0xE0], xmm15
0000713aae5d3bd8  sub rsp, 0x40
0000713aae5d3bdc  lea rdi, [rsp]
0000713aae5d3be0  lea rsi, [rsp+0x10]
0000713aae5d3be5  lea rdx, [rsp+0x20]
0000713aae5d3bea  lea rcx, [rsp+0x30]
0000713aae5d3bef  mov r8d, 0x00
0000713aae5d3bf5  lea r9, [r15+0x3A8]
0000713aae5d3bfc  movaps [rdi], xmm12
0000713aae5d3c00  movaps [rsi], xmm15
0000713aae5d3c04  movaps [rdx], xmm14
0000713aae5d3c08  movaps [rcx], xmm1
0000713aae5d3c0b  mov rax, 0x5E9381C89A50
0000713aae5d3c15  call rax
0000713aae5d3c17  movaps xmm12, [rsp]
0000713aae5d3c1c  add rsp, 0x40
0000713aae5d3c20  vmovaps xmm0, [rsp]
0000713aae5d3c25  vmovaps xmm1, [rsp+0x10]
0000713aae5d3c2b  vmovaps xmm2, [rsp+0x20]
0000713aae5d3c31  vmovaps xmm3, [rsp+0x30]
0000713aae5d3c37  vmovaps xmm4, [rsp+0x40]
0000713aae5d3c3d  vmovaps xmm5, [rsp+0x50]
0000713aae5d3c43  vmovaps xmm6, [rsp+0x60]
0000713aae5d3c49  vmovaps xmm7, [rsp+0x70]
0000713aae5d3c4f  vmovaps xmm8, [rsp+0x80]
0000713aae5d3c58  vmovaps xmm9, [rsp+0x90]
0000713aae5d3c61  vmovaps xmm10, [rsp+0xA0]
0000713aae5d3c6a  vmovaps xmm11, [rsp+0xB0]
0000713aae5d3c73  vmovaps xmm13, [rsp+0xC0]
0000713aae5d3c7c  vmovaps xmm14, [rsp+0xD0]
0000713aae5d3c85  vmovaps xmm15, [rsp+0xE0]
0000713aae5d3c8e  add rsp, 0xF0
0000713aae5d3c95  pop r11
0000713aae5d3c97  pop r10
0000713aae5d3c99  pop r9
0000713aae5d3c9b  pop r8
0000713aae5d3c9d  pop rsi
0000713aae5d3c9e  pop rdi
0000713aae5d3c9f  pop rdx
0000713aae5d3ca0  pop rcx
0000713aae5d3ca1  pop rax
0000713aae5d3ca2  add rsp, 0x08
0000713aae5d3ca6  jmp 0x0000713AAE5D2BB2
0000713aae5d3cab  sub rsp, 0x08
0000713aae5d3caf  push rax
0000713aae5d3cb0  push rcx
0000713aae5d3cb1  push rdx
0000713aae5d3cb2  push rdi
0000713aae5d3cb3  push rsi
0000713aae5d3cb4  push r8
0000713aae5d3cb6  push r9
0000713aae5d3cb8  push r10
0000713aae5d3cba  push r11
0000713aae5d3cbc  sub rsp, 0xF0
0000713aae5d3cc3  vmovaps [rsp], xmm0
0000713aae5d3cc8  vmovaps [rsp+0x10], xmm1
0000713aae5d3cce  vmovaps [rsp+0x20], xmm2
0000713aae5d3cd4  vmovaps [rsp+0x30], xmm3
0000713aae5d3cda  vmovaps [rsp+0x40], xmm4
0000713aae5d3ce0  vmovaps [rsp+0x50], xmm5
0000713aae5d3ce6  vmovaps [rsp+0x60], xmm6
0000713aae5d3cec  vmovaps [rsp+0x70], xmm7
0000713aae5d3cf2  vmovaps [rsp+0x80], xmm8
0000713aae5d3cfb  vmovaps [rsp+0x90], xmm9
0000713aae5d3d04  vmovaps [rsp+0xA0], xmm10
0000713aae5d3d0d  vmovaps [rsp+0xB0], xmm11
0000713aae5d3d16  vmovaps [rsp+0xC0], xmm12
0000713aae5d3d1f  vmovaps [rsp+0xD0], xmm14
0000713aae5d3d28  vmovaps [rsp+0xE0], xmm15
0000713aae5d3d31  sub rsp, 0x40
0000713aae5d3d35  lea rdi, [rsp]
0000713aae5d3d39  lea rsi, [rsp+0x10]
0000713aae5d3d3e  lea rdx, [rsp+0x20]
0000713aae5d3d43  lea rcx, [rsp+0x30]
0000713aae5d3d48  mov r8d, 0x00
0000713aae5d3d4e  lea r9, [r15+0x3A8]
0000713aae5d3d55  movaps [rdi], xmm13
0000713aae5d3d59  movaps [rsi], xmm15
0000713aae5d3d5d  movaps [rdx], xmm14
0000713aae5d3d61  movaps [rcx], xmm1
0000713aae5d3d64  mov rax, 0x5E9381C89A50
0000713aae5d3d6e  call rax
0000713aae5d3d70  movaps xmm13, [rsp]
0000713aae5d3d75  add rsp, 0x40
0000713aae5d3d79  vmovaps xmm0, [rsp]
0000713aae5d3d7e  vmovaps xmm1, [rsp+0x10]
0000713aae5d3d84  vmovaps xmm2, [rsp+0x20]
0000713aae5d3d8a  vmovaps xmm3, [rsp+0x30]
0000713aae5d3d90  vmovaps xmm4, [rsp+0x40]
0000713aae5d3d96  vmovaps xmm5, [rsp+0x50]
0000713aae5d3d9c  vmovaps xmm6, [rsp+0x60]
0000713aae5d3da2  vmovaps xmm7, [rsp+0x70]
0000713aae5d3da8  vmovaps xmm8, [rsp+0x80]
0000713aae5d3db1  vmovaps xmm9, [rsp+0x90]
0000713aae5d3dba  vmovaps xmm10, [rsp+0xA0]
0000713aae5d3dc3  vmovaps xmm11, [rsp+0xB0]
0000713aae5d3dcc  vmovaps xmm12, [rsp+0xC0]
0000713aae5d3dd5  vmovaps xmm14, [rsp+0xD0]
0000713aae5d3dde  vmovaps xmm15, [rsp+0xE0]
0000713aae5d3de7  add rsp, 0xF0
0000713aae5d3dee  pop r11
0000713aae5d3df0  pop r10
0000713aae5d3df2  pop r9
0000713aae5d3df4  pop r8
0000713aae5d3df6  pop rsi
0000713aae5d3df7  pop rdi
0000713aae5d3df8  pop rdx
0000713aae5d3df9  pop rcx
0000713aae5d3dfa  pop rax
0000713aae5d3dfb  add rsp, 0x08
0000713aae5d3dff  jmp 0x0000713AAE5D2BEA
0000713aae5d3e04  sub rsp, 0x08
0000713aae5d3e08  push rax
0000713aae5d3e09  push rcx
0000713aae5d3e0a  push rdx
0000713aae5d3e0b  push rdi
0000713aae5d3e0c  push rsi
0000713aae5d3e0d  push r8
0000713aae5d3e0f  push r9
0000713aae5d3e11  push r10
0000713aae5d3e13  push r11
0000713aae5d3e15  sub rsp, 0xF0
0000713aae5d3e1c  vmovaps [rsp], xmm0
0000713aae5d3e21  vmovaps [rsp+0x10], xmm1
0000713aae5d3e27  vmovaps [rsp+0x20], xmm2
0000713aae5d3e2d  vmovaps [rsp+0x30], xmm3
0000713aae5d3e33  vmovaps [rsp+0x40], xmm4
0000713aae5d3e39  vmovaps [rsp+0x50], xmm5
0000713aae5d3e3f  vmovaps [rsp+0x60], xmm6
0000713aae5d3e45  vmovaps [rsp+0x70], xmm7
0000713aae5d3e4b  vmovaps [rsp+0x80], xmm8
0000713aae5d3e54  vmovaps [rsp+0x90], xmm9
0000713aae5d3e5d  vmovaps [rsp+0xA0], xmm10
0000713aae5d3e66  vmovaps [rsp+0xB0], xmm11
0000713aae5d3e6f  vmovaps [rsp+0xC0], xmm13
0000713aae5d3e78  vmovaps [rsp+0xD0], xmm14
0000713aae5d3e81  vmovaps [rsp+0xE0], xmm15
0000713aae5d3e8a  sub rsp, 0x40
0000713aae5d3e8e  lea rdi, [rsp]
0000713aae5d3e92  lea rsi, [rsp+0x10]
0000713aae5d3e97  lea rdx, [rsp+0x20]
0000713aae5d3e9c  lea rcx, [rsp+0x30]
0000713aae5d3ea1  mov r8d, 0x00
0000713aae5d3ea7  lea r9, [r15+0x3A8]
0000713aae5d3eae  movaps [rdi], xmm12
0000713aae5d3eb2  movaps [rsi], xmm15
0000713aae5d3eb6  movaps [rdx], xmm14
0000713aae5d3eba  movaps [rcx], xmm1
0000713aae5d3ebd  mov rax, 0x5E9381C89A50
0000713aae5d3ec7  call rax
0000713aae5d3ec9  movaps xmm12, [rsp]
0000713aae5d3ece  add rsp, 0x40
0000713aae5d3ed2  vmovaps xmm0, [rsp]
0000713aae5d3ed7  vmovaps xmm1, [rsp+0x10]
0000713aae5d3edd  vmovaps xmm2, [rsp+0x20]
0000713aae5d3ee3  vmovaps xmm3, [rsp+0x30]
0000713aae5d3ee9  vmovaps xmm4, [rsp+0x40]
0000713aae5d3eef  vmovaps xmm5, [rsp+0x50]
0000713aae5d3ef5  vmovaps xmm6, [rsp+0x60]
0000713aae5d3efb  vmovaps xmm7, [rsp+0x70]
0000713aae5d3f01  vmovaps xmm8, [rsp+0x80]
0000713aae5d3f0a  vmovaps xmm9, [rsp+0x90]
0000713aae5d3f13  vmovaps xmm10, [rsp+0xA0]
0000713aae5d3f1c  vmovaps xmm11, [rsp+0xB0]
0000713aae5d3f25  vmovaps xmm13, [rsp+0xC0]
0000713aae5d3f2e  vmovaps xmm14, [rsp+0xD0]
0000713aae5d3f37  vmovaps xmm15, [rsp+0xE0]
0000713aae5d3f40  add rsp, 0xF0
0000713aae5d3f47  pop r11
0000713aae5d3f49  pop r10
0000713aae5d3f4b  pop r9
0000713aae5d3f4d  pop r8
0000713aae5d3f4f  pop rsi
0000713aae5d3f50  pop rdi
0000713aae5d3f51  pop rdx
0000713aae5d3f52  pop rcx
0000713aae5d3f53  pop rax
0000713aae5d3f54  add rsp, 0x08
0000713aae5d3f58  jmp 0x0000713AAE5D2C3D
0000713aae5d3f5d  sub rsp, 0x08
0000713aae5d3f61  push rax
0000713aae5d3f62  push rcx
0000713aae5d3f63  push rdx
0000713aae5d3f64  push rdi
0000713aae5d3f65  push rsi
0000713aae5d3f66  push r8
0000713aae5d3f68  push r9
0000713aae5d3f6a  push r10
0000713aae5d3f6c  push r11
0000713aae5d3f6e  sub rsp, 0xF0
0000713aae5d3f75  vmovaps [rsp], xmm0
0000713aae5d3f7a  vmovaps [rsp+0x10], xmm1
0000713aae5d3f80  vmovaps [rsp+0x20], xmm2
0000713aae5d3f86  vmovaps [rsp+0x30], xmm3
0000713aae5d3f8c  vmovaps [rsp+0x40], xmm4
0000713aae5d3f92  vmovaps [rsp+0x50], xmm5
0000713aae5d3f98  vmovaps [rsp+0x60], xmm6
0000713aae5d3f9e  vmovaps [rsp+0x70], xmm7
0000713aae5d3fa4  vmovaps [rsp+0x80], xmm8
0000713aae5d3fad  vmovaps [rsp+0x90], xmm9
0000713aae5d3fb6  vmovaps [rsp+0xA0], xmm10
0000713aae5d3fbf  vmovaps [rsp+0xB0], xmm11
0000713aae5d3fc8  vmovaps [rsp+0xC0], xmm12
0000713aae5d3fd1  vmovaps [rsp+0xD0], xmm13
0000713aae5d3fda  vmovaps [rsp+0xE0], xmm15
0000713aae5d3fe3  sub rsp, 0x40
0000713aae5d3fe7  lea rdi, [rsp]
0000713aae5d3feb  lea rsi, [rsp+0x10]
0000713aae5d3ff0  lea rdx, [rsp+0x20]
0000713aae5d3ff5  lea rcx, [rsp+0x30]
0000713aae5d3ffa  mov r8d, 0x00
0000713aae5d4000  lea r9, [r15+0x3A8]
0000713aae5d4007  movaps [rdi], xmm14
0000713aae5d400b  movaps [rsi], xmm3
0000713aae5d400e  movaps [rdx], xmm1
0000713aae5d4011  movaps [rcx], xmm15
0000713aae5d4015  mov rax, 0x5E9381C89A50
0000713aae5d401f  call rax
0000713aae5d4021  movaps xmm14, [rsp]
0000713aae5d4026  add rsp, 0x40
0000713aae5d402a  vmovaps xmm0, [rsp]
0000713aae5d402f  vmovaps xmm1, [rsp+0x10]
0000713aae5d4035  vmovaps xmm2, [rsp+0x20]
0000713aae5d403b  vmovaps xmm3, [rsp+0x30]
0000713aae5d4041  vmovaps xmm4, [rsp+0x40]
0000713aae5d4047  vmovaps xmm5, [rsp+0x50]
0000713aae5d404d  vmovaps xmm6, [rsp+0x60]
0000713aae5d4053  vmovaps xmm7, [rsp+0x70]
0000713aae5d4059  vmovaps xmm8, [rsp+0x80]
0000713aae5d4062  vmovaps xmm9, [rsp+0x90]
0000713aae5d406b  vmovaps xmm10, [rsp+0xA0]
0000713aae5d4074  vmovaps xmm11, [rsp+0xB0]
0000713aae5d407d  vmovaps xmm12, [rsp+0xC0]
0000713aae5d4086  vmovaps xmm13, [rsp+0xD0]
0000713aae5d408f  vmovaps xmm15, [rsp+0xE0]
0000713aae5d4098  add rsp, 0xF0
0000713aae5d409f  pop r11
0000713aae5d40a1  pop r10
0000713aae5d40a3  pop r9
0000713aae5d40a5  pop r8
0000713aae5d40a7  pop rsi
0000713aae5d40a8  pop rdi
0000713aae5d40a9  pop rdx
0000713aae5d40aa  pop rcx
0000713aae5d40ab  pop rax
0000713aae5d40ac  add rsp, 0x08
0000713aae5d40b0  jmp 0x0000713AAE5D2CF7
0000713aae5d40b5  sub rsp, 0x08
0000713aae5d40b9  push rax
0000713aae5d40ba  push rcx
0000713aae5d40bb  push rdx
0000713aae5d40bc  push rdi
0000713aae5d40bd  push rsi
0000713aae5d40be  push r8
0000713aae5d40c0  push r9
0000713aae5d40c2  push r10
0000713aae5d40c4  push r11
0000713aae5d40c6  sub rsp, 0xF0
0000713aae5d40cd  vmovaps [rsp], xmm0
0000713aae5d40d2  vmovaps [rsp+0x10], xmm1
0000713aae5d40d8  vmovaps [rsp+0x20], xmm2
0000713aae5d40de  vmovaps [rsp+0x30], xmm3
0000713aae5d40e4  vmovaps [rsp+0x40], xmm4
0000713aae5d40ea  vmovaps [rsp+0x50], xmm5
0000713aae5d40f0  vmovaps [rsp+0x60], xmm6
0000713aae5d40f6  vmovaps [rsp+0x70], xmm7
0000713aae5d40fc  vmovaps [rsp+0x80], xmm8
0000713aae5d4105  vmovaps [rsp+0x90], xmm9
0000713aae5d410e  vmovaps [rsp+0xA0], xmm10
0000713aae5d4117  vmovaps [rsp+0xB0], xmm11
0000713aae5d4120  vmovaps [rsp+0xC0], xmm12
0000713aae5d4129  vmovaps [rsp+0xD0], xmm14
0000713aae5d4132  vmovaps [rsp+0xE0], xmm15
0000713aae5d413b  sub rsp, 0x40
0000713aae5d413f  lea rdi, [rsp]
0000713aae5d4143  lea rsi, [rsp+0x10]
0000713aae5d4148  lea rdx, [rsp+0x20]
0000713aae5d414d  lea rcx, [rsp+0x30]
0000713aae5d4152  mov r8d, 0x00
0000713aae5d4158  lea r9, [r15+0x3A8]
0000713aae5d415f  movaps [rdi], xmm13
0000713aae5d4163  movaps [rsi], xmm15
0000713aae5d4167  movaps [rdx], xmm10
0000713aae5d416b  movaps [rcx], xmm1
0000713aae5d416e  mov rax, 0x5E9381C89A50
0000713aae5d4178  call rax
0000713aae5d417a  movaps xmm13, [rsp]
0000713aae5d417f  add rsp, 0x40
0000713aae5d4183  vmovaps xmm0, [rsp]
0000713aae5d4188  vmovaps xmm1, [rsp+0x10]
0000713aae5d418e  vmovaps xmm2, [rsp+0x20]
0000713aae5d4194  vmovaps xmm3, [rsp+0x30]
0000713aae5d419a  vmovaps xmm4, [rsp+0x40]
0000713aae5d41a0  vmovaps xmm5, [rsp+0x50]
0000713aae5d41a6  vmovaps xmm6, [rsp+0x60]
0000713aae5d41ac  vmovaps xmm7, [rsp+0x70]
0000713aae5d41b2  vmovaps xmm8, [rsp+0x80]
0000713aae5d41bb  vmovaps xmm9, [rsp+0x90]
0000713aae5d41c4  vmovaps xmm10, [rsp+0xA0]
0000713aae5d41cd  vmovaps xmm11, [rsp+0xB0]
0000713aae5d41d6  vmovaps xmm12, [rsp+0xC0]
0000713aae5d41df  vmovaps xmm14, [rsp+0xD0]
0000713aae5d41e8  vmovaps xmm15, [rsp+0xE0]
0000713aae5d41f1  add rsp, 0xF0
0000713aae5d41f8  pop r11
0000713aae5d41fa  pop r10
0000713aae5d41fc  pop r9
0000713aae5d41fe  pop r8
0000713aae5d4200  pop rsi
0000713aae5d4201  pop rdi
0000713aae5d4202  pop rdx
0000713aae5d4203  pop rcx
0000713aae5d4204  pop rax
0000713aae5d4205  add rsp, 0x08
0000713aae5d4209  jmp 0x0000713AAE5D2D26
0000713aae5d420e  sub rsp, 0x08
0000713aae5d4212  push rax
0000713aae5d4213  push rcx
0000713aae5d4214  push rdx
0000713aae5d4215  push rdi
0000713aae5d4216  push rsi
0000713aae5d4217  push r8
0000713aae5d4219  push r9
0000713aae5d421b  push r10
0000713aae5d421d  push r11
0000713aae5d421f  sub rsp, 0xF0
0000713aae5d4226  vmovaps [rsp], xmm0
0000713aae5d422b  vmovaps [rsp+0x10], xmm1
0000713aae5d4231  vmovaps [rsp+0x20], xmm2
0000713aae5d4237  vmovaps [rsp+0x30], xmm3
0000713aae5d423d  vmovaps [rsp+0x40], xmm4
0000713aae5d4243  vmovaps [rsp+0x50], xmm5
0000713aae5d4249  vmovaps [rsp+0x60], xmm6
0000713aae5d424f  vmovaps [rsp+0x70], xmm7
0000713aae5d4255  vmovaps [rsp+0x80], xmm8
0000713aae5d425e  vmovaps [rsp+0x90], xmm9
0000713aae5d4267  vmovaps [rsp+0xA0], xmm11
0000713aae5d4270  vmovaps [rsp+0xB0], xmm12
0000713aae5d4279  vmovaps [rsp+0xC0], xmm13
0000713aae5d4282  vmovaps [rsp+0xD0], xmm14
0000713aae5d428b  vmovaps [rsp+0xE0], xmm15
0000713aae5d4294  sub rsp, 0x40
0000713aae5d4298  lea rdi, [rsp]
0000713aae5d429c  lea rsi, [rsp+0x10]
0000713aae5d42a1  lea rdx, [rsp+0x20]
0000713aae5d42a6  lea rcx, [rsp+0x30]
0000713aae5d42ab  mov r8d, 0x00
0000713aae5d42b1  lea r9, [r15+0x3A8]
0000713aae5d42b8  movaps [rdi], xmm10
0000713aae5d42bc  movaps [rsi], xmm15
0000713aae5d42c0  movaps [rdx], xmm11
0000713aae5d42c4  movaps [rcx], xmm1
0000713aae5d42c7  mov rax, 0x5E9381C89A50
0000713aae5d42d1  call rax
0000713aae5d42d3  movaps xmm10, [rsp]
0000713aae5d42d8  add rsp, 0x40
0000713aae5d42dc  vmovaps xmm0, [rsp]
0000713aae5d42e1  vmovaps xmm1, [rsp+0x10]
0000713aae5d42e7  vmovaps xmm2, [rsp+0x20]
0000713aae5d42ed  vmovaps xmm3, [rsp+0x30]
0000713aae5d42f3  vmovaps xmm4, [rsp+0x40]
0000713aae5d42f9  vmovaps xmm5, [rsp+0x50]
0000713aae5d42ff  vmovaps xmm6, [rsp+0x60]
0000713aae5d4305  vmovaps xmm7, [rsp+0x70]
0000713aae5d430b  vmovaps xmm8, [rsp+0x80]
0000713aae5d4314  vmovaps xmm9, [rsp+0x90]
0000713aae5d431d  vmovaps xmm11, [rsp+0xA0]
0000713aae5d4326  vmovaps xmm12, [rsp+0xB0]
0000713aae5d432f  vmovaps xmm13, [rsp+0xC0]
0000713aae5d4338  vmovaps xmm14, [rsp+0xD0]
0000713aae5d4341  vmovaps xmm15, [rsp+0xE0]
0000713aae5d434a  add rsp, 0xF0
0000713aae5d4351  pop r11
0000713aae5d4353  pop r10
0000713aae5d4355  pop r9
0000713aae5d4357  pop r8
0000713aae5d4359  pop rsi
0000713aae5d435a  pop rdi
0000713aae5d435b  pop rdx
0000713aae5d435c  pop rcx
0000713aae5d435d  pop rax
0000713aae5d435e  add rsp, 0x08
0000713aae5d4362  jmp 0x0000713AAE5D2D55
0000713aae5d4367  sub rsp, 0x08
0000713aae5d436b  push rax
0000713aae5d436c  push rcx
0000713aae5d436d  push rdx
0000713aae5d436e  push rdi
0000713aae5d436f  push rsi
0000713aae5d4370  push r8
0000713aae5d4372  push r9
0000713aae5d4374  push r10
0000713aae5d4376  push r11
0000713aae5d4378  sub rsp, 0xF0
0000713aae5d437f  vmovaps [rsp], xmm0
0000713aae5d4384  vmovaps [rsp+0x10], xmm1
0000713aae5d438a  vmovaps [rsp+0x20], xmm2
0000713aae5d4390  vmovaps [rsp+0x30], xmm3
0000713aae5d4396  vmovaps [rsp+0x40], xmm4
0000713aae5d439c  vmovaps [rsp+0x50], xmm5
0000713aae5d43a2  vmovaps [rsp+0x60], xmm6
0000713aae5d43a8  vmovaps [rsp+0x70], xmm7
0000713aae5d43ae  vmovaps [rsp+0x80], xmm8
0000713aae5d43b7  vmovaps [rsp+0x90], xmm9
0000713aae5d43c0  vmovaps [rsp+0xA0], xmm10
0000713aae5d43c9  vmovaps [rsp+0xB0], xmm11
0000713aae5d43d2  vmovaps [rsp+0xC0], xmm12
0000713aae5d43db  vmovaps [rsp+0xD0], xmm13
0000713aae5d43e4  vmovaps [rsp+0xE0], xmm14
0000713aae5d43ed  sub rsp, 0x40
0000713aae5d43f1  lea rdi, [rsp]
0000713aae5d43f5  lea rsi, [rsp+0x10]
0000713aae5d43fa  lea rdx, [rsp+0x20]
0000713aae5d43ff  lea rcx, [rsp+0x30]
0000713aae5d4404  mov r8d, 0x00
0000713aae5d440a  lea r9, [r15+0x3A8]
0000713aae5d4411  movaps [rdi], xmm15
0000713aae5d4415  movaps [rsi], xmm12
0000713aae5d4419  movaps [rdx], xmm5
0000713aae5d441c  movaps [rcx], xmm1
0000713aae5d441f  mov rax, 0x5E9381C89A50
0000713aae5d4429  call rax
0000713aae5d442b  movaps xmm15, [rsp]
0000713aae5d4430  add rsp, 0x40
0000713aae5d4434  vmovaps xmm0, [rsp]
0000713aae5d4439  vmovaps xmm1, [rsp+0x10]
0000713aae5d443f  vmovaps xmm2, [rsp+0x20]
0000713aae5d4445  vmovaps xmm3, [rsp+0x30]
0000713aae5d444b  vmovaps xmm4, [rsp+0x40]
0000713aae5d4451  vmovaps xmm5, [rsp+0x50]
0000713aae5d4457  vmovaps xmm6, [rsp+0x60]
0000713aae5d445d  vmovaps xmm7, [rsp+0x70]
0000713aae5d4463  vmovaps xmm8, [rsp+0x80]
0000713aae5d446c  vmovaps xmm9, [rsp+0x90]
0000713aae5d4475  vmovaps xmm10, [rsp+0xA0]
0000713aae5d447e  vmovaps xmm11, [rsp+0xB0]
0000713aae5d4487  vmovaps xmm12, [rsp+0xC0]
0000713aae5d4490  vmovaps xmm13, [rsp+0xD0]
0000713aae5d4499  vmovaps xmm14, [rsp+0xE0]
0000713aae5d44a2  add rsp, 0xF0
0000713aae5d44a9  pop r11
0000713aae5d44ab  pop r10
0000713aae5d44ad  pop r9
0000713aae5d44af  pop r8
0000713aae5d44b1  pop rsi
0000713aae5d44b2  pop rdi
0000713aae5d44b3  pop rdx
0000713aae5d44b4  pop rcx
0000713aae5d44b5  pop rax
0000713aae5d44b6  add rsp, 0x08
0000713aae5d44ba  jmp 0x0000713AAE5D2D7E
0000713aae5d44bf  sub rsp, 0x08
0000713aae5d44c3  push rax
0000713aae5d44c4  push rcx
0000713aae5d44c5  push rdx
0000713aae5d44c6  push rdi
0000713aae5d44c7  push rsi
0000713aae5d44c8  push r8
0000713aae5d44ca  push r9
0000713aae5d44cc  push r10
0000713aae5d44ce  push r11
0000713aae5d44d0  sub rsp, 0xF0
0000713aae5d44d7  vmovaps [rsp], xmm0
0000713aae5d44dc  vmovaps [rsp+0x10], xmm1
0000713aae5d44e2  vmovaps [rsp+0x20], xmm2
0000713aae5d44e8  vmovaps [rsp+0x30], xmm3
0000713aae5d44ee  vmovaps [rsp+0x40], xmm4
0000713aae5d44f4  vmovaps [rsp+0x50], xmm6
0000713aae5d44fa  vmovaps [rsp+0x60], xmm7
0000713aae5d4500  vmovaps [rsp+0x70], xmm8
0000713aae5d4506  vmovaps [rsp+0x80], xmm9
0000713aae5d450f  vmovaps [rsp+0x90], xmm10
0000713aae5d4518  vmovaps [rsp+0xA0], xmm11
0000713aae5d4521  vmovaps [rsp+0xB0], xmm12
0000713aae5d452a  vmovaps [rsp+0xC0], xmm13
0000713aae5d4533  vmovaps [rsp+0xD0], xmm14
0000713aae5d453c  vmovaps [rsp+0xE0], xmm15
0000713aae5d4545  sub rsp, 0x40
0000713aae5d4549  lea rdi, [rsp]
0000713aae5d454d  lea rsi, [rsp+0x10]
0000713aae5d4552  lea rdx, [rsp+0x20]
0000713aae5d4557  lea rcx, [rsp+0x30]
0000713aae5d455c  mov r8d, 0x00
0000713aae5d4562  lea r9, [r15+0x3A8]
0000713aae5d4569  movaps [rdi], xmm5
0000713aae5d456c  movaps [rsi], xmm13
0000713aae5d4570  movaps [rdx], xmm11
0000713aae5d4574  movaps [rcx], xmm12
0000713aae5d4578  mov rax, 0x5E9381C89A50
0000713aae5d4582  call rax
0000713aae5d4584  movaps xmm5, [rsp]
0000713aae5d4588  add rsp, 0x40
0000713aae5d458c  vmovaps xmm0, [rsp]
0000713aae5d4591  vmovaps xmm1, [rsp+0x10]
0000713aae5d4597  vmovaps xmm2, [rsp+0x20]
0000713aae5d459d  vmovaps xmm3, [rsp+0x30]
0000713aae5d45a3  vmovaps xmm4, [rsp+0x40]
0000713aae5d45a9  vmovaps xmm6, [rsp+0x50]
0000713aae5d45af  vmovaps xmm7, [rsp+0x60]
0000713aae5d45b5  vmovaps xmm8, [rsp+0x70]
0000713aae5d45bb  vmovaps xmm9, [rsp+0x80]
0000713aae5d45c4  vmovaps xmm10, [rsp+0x90]
0000713aae5d45cd  vmovaps xmm11, [rsp+0xA0]
0000713aae5d45d6  vmovaps xmm12, [rsp+0xB0]
0000713aae5d45df  vmovaps xmm13, [rsp+0xC0]
0000713aae5d45e8  vmovaps xmm14, [rsp+0xD0]
0000713aae5d45f1  vmovaps xmm15, [rsp+0xE0]
0000713aae5d45fa  add rsp, 0xF0
0000713aae5d4601  pop r11
0000713aae5d4603  pop r10
0000713aae5d4605  pop r9
0000713aae5d4607  pop r8
0000713aae5d4609  pop rsi
0000713aae5d460a  pop rdi
0000713aae5d460b  pop rdx
0000713aae5d460c  pop rcx
0000713aae5d460d  pop rax
0000713aae5d460e  add rsp, 0x08
0000713aae5d4612  jmp 0x0000713AAE5D2DDD
0000713aae5d4617  sub rsp, 0x08
0000713aae5d461b  push rax
0000713aae5d461c  push rcx
0000713aae5d461d  push rdx
0000713aae5d461e  push rdi
0000713aae5d461f  push rsi
0000713aae5d4620  push r8
0000713aae5d4622  push r9
0000713aae5d4624  push r10
0000713aae5d4626  push r11
0000713aae5d4628  sub rsp, 0xF0
0000713aae5d462f  vmovaps [rsp], xmm0
0000713aae5d4634  vmovaps [rsp+0x10], xmm1
0000713aae5d463a  vmovaps [rsp+0x20], xmm2
0000713aae5d4640  vmovaps [rsp+0x30], xmm3
0000713aae5d4646  vmovaps [rsp+0x40], xmm4
0000713aae5d464c  vmovaps [rsp+0x50], xmm5
0000713aae5d4652  vmovaps [rsp+0x60], xmm6
0000713aae5d4658  vmovaps [rsp+0x70], xmm7
0000713aae5d465e  vmovaps [rsp+0x80], xmm8
0000713aae5d4667  vmovaps [rsp+0x90], xmm9
0000713aae5d4670  vmovaps [rsp+0xA0], xmm10
0000713aae5d4679  vmovaps [rsp+0xB0], xmm11
0000713aae5d4682  vmovaps [rsp+0xC0], xmm13
0000713aae5d468b  vmovaps [rsp+0xD0], xmm14
0000713aae5d4694  vmovaps [rsp+0xE0], xmm15
0000713aae5d469d  sub rsp, 0x40
0000713aae5d46a1  lea rdi, [rsp]
0000713aae5d46a5  lea rsi, [rsp+0x10]
0000713aae5d46aa  lea rdx, [rsp+0x20]
0000713aae5d46af  lea rcx, [rsp+0x30]
0000713aae5d46b4  mov r8d, 0x00
0000713aae5d46ba  lea r9, [r15+0x3A8]
0000713aae5d46c1  movaps [rdi], xmm12
0000713aae5d46c5  movaps [rsi], xmm14
0000713aae5d46c9  movaps [rdx], xmm9
0000713aae5d46cd  movaps [rcx], xmm13
0000713aae5d46d1  mov rax, 0x5E9381C89A50
0000713aae5d46db  call rax
0000713aae5d46dd  movaps xmm12, [rsp]
0000713aae5d46e2  add rsp, 0x40
0000713aae5d46e6  vmovaps xmm0, [rsp]
0000713aae5d46eb  vmovaps xmm1, [rsp+0x10]
0000713aae5d46f1  vmovaps xmm2, [rsp+0x20]
0000713aae5d46f7  vmovaps xmm3, [rsp+0x30]
0000713aae5d46fd  vmovaps xmm4, [rsp+0x40]
0000713aae5d4703  vmovaps xmm5, [rsp+0x50]
0000713aae5d4709  vmovaps xmm6, [rsp+0x60]
0000713aae5d470f  vmovaps xmm7, [rsp+0x70]
0000713aae5d4715  vmovaps xmm8, [rsp+0x80]
0000713aae5d471e  vmovaps xmm9, [rsp+0x90]
0000713aae5d4727  vmovaps xmm10, [rsp+0xA0]
0000713aae5d4730  vmovaps xmm11, [rsp+0xB0]
0000713aae5d4739  vmovaps xmm13, [rsp+0xC0]
0000713aae5d4742  vmovaps xmm14, [rsp+0xD0]
0000713aae5d474b  vmovaps xmm15, [rsp+0xE0]
0000713aae5d4754  add rsp, 0xF0
0000713aae5d475b  pop r11
0000713aae5d475d  pop r10
0000713aae5d475f  pop r9
0000713aae5d4761  pop r8
0000713aae5d4763  pop rsi
0000713aae5d4764  pop rdi
0000713aae5d4765  pop rdx
0000713aae5d4766  pop rcx
0000713aae5d4767  pop rax
0000713aae5d4768  add rsp, 0x08
0000713aae5d476c  jmp 0x0000713AAE5D2E06
0000713aae5d4771  call 0x0000713AAE40D4E0
0000713aae5d4776  jmp 0x0000713AAE5D2E13
0000713aae5d477b  sub rsp, 0x08
0000713aae5d477f  push rax
0000713aae5d4780  push rcx
0000713aae5d4781  push rdx
0000713aae5d4782  push rdi
0000713aae5d4783  push rsi
0000713aae5d4784  push r8
0000713aae5d4786  push r9
0000713aae5d4788  push r10
0000713aae5d478a  push r11
0000713aae5d478c  sub rsp, 0xF0
0000713aae5d4793  vmovaps [rsp], xmm0
0000713aae5d4798  vmovaps [rsp+0x10], xmm1
0000713aae5d479e  vmovaps [rsp+0x20], xmm2
0000713aae5d47a4  vmovaps [rsp+0x30], xmm3
0000713aae5d47aa  vmovaps [rsp+0x40], xmm4
0000713aae5d47b0  vmovaps [rsp+0x50], xmm5
0000713aae5d47b6  vmovaps [rsp+0x60], xmm6
0000713aae5d47bc  vmovaps [rsp+0x70], xmm7
0000713aae5d47c2  vmovaps [rsp+0x80], xmm8
0000713aae5d47cb  vmovaps [rsp+0x90], xmm9
0000713aae5d47d4  vmovaps [rsp+0xA0], xmm10
0000713aae5d47dd  vmovaps [rsp+0xB0], xmm12
0000713aae5d47e6  vmovaps [rsp+0xC0], xmm13
0000713aae5d47ef  vmovaps [rsp+0xD0], xmm14
0000713aae5d47f8  vmovaps [rsp+0xE0], xmm15
0000713aae5d4801  sub rsp, 0x40
0000713aae5d4805  lea rdi, [rsp]
0000713aae5d4809  lea rsi, [rsp+0x10]
0000713aae5d480e  lea rdx, [rsp+0x20]
0000713aae5d4813  lea rcx, [rsp+0x30]
0000713aae5d4818  mov r8d, 0x00
0000713aae5d481e  lea r9, [r15+0x3A8]
0000713aae5d4825  movaps [rdi], xmm11
0000713aae5d4829  movaps [rsi], xmm10
0000713aae5d482d  movaps [rdx], xmm8
0000713aae5d4831  movaps [rcx], xmm13
0000713aae5d4835  mov rax, 0x5E9381C89A50
0000713aae5d483f  call rax
0000713aae5d4841  movaps xmm11, [rsp]
0000713aae5d4846  add rsp, 0x40
0000713aae5d484a  vmovaps xmm0, [rsp]
0000713aae5d484f  vmovaps xmm1, [rsp+0x10]
0000713aae5d4855  vmovaps xmm2, [rsp+0x20]
0000713aae5d485b  vmovaps xmm3, [rsp+0x30]
0000713aae5d4861  vmovaps xmm4, [rsp+0x40]
0000713aae5d4867  vmovaps xmm5, [rsp+0x50]
0000713aae5d486d  vmovaps xmm6, [rsp+0x60]
0000713aae5d4873  vmovaps xmm7, [rsp+0x70]
0000713aae5d4879  vmovaps xmm8, [rsp+0x80]
0000713aae5d4882  vmovaps xmm9, [rsp+0x90]
0000713aae5d488b  vmovaps xmm10, [rsp+0xA0]
0000713aae5d4894  vmovaps xmm12, [rsp+0xB0]
0000713aae5d489d  vmovaps xmm13, [rsp+0xC0]
0000713aae5d48a6  vmovaps xmm14, [rsp+0xD0]
0000713aae5d48af  vmovaps xmm15, [rsp+0xE0]
0000713aae5d48b8  add rsp, 0xF0
0000713aae5d48bf  pop r11
0000713aae5d48c1  pop r10
0000713aae5d48c3  pop r9
0000713aae5d48c5  pop r8
0000713aae5d48c7  pop rsi
0000713aae5d48c8  pop rdi
0000713aae5d48c9  pop rdx
0000713aae5d48ca  pop rcx
0000713aae5d48cb  pop rax
0000713aae5d48cc  add rsp, 0x08
0000713aae5d48d0  jmp 0x0000713AAE5D2E44
0000713aae5d48d5  sub rsp, 0x08
0000713aae5d48d9  push rax
0000713aae5d48da  push rcx
0000713aae5d48db  push rdx
0000713aae5d48dc  push rdi
0000713aae5d48dd  push rsi
0000713aae5d48de  push r8
0000713aae5d48e0  push r9
0000713aae5d48e2  push r10
0000713aae5d48e4  push r11
0000713aae5d48e6  sub rsp, 0xF0
0000713aae5d48ed  vmovaps [rsp], xmm0
0000713aae5d48f2  vmovaps [rsp+0x10], xmm1
0000713aae5d48f8  vmovaps [rsp+0x20], xmm2
0000713aae5d48fe  vmovaps [rsp+0x30], xmm3
0000713aae5d4904  vmovaps [rsp+0x40], xmm4
0000713aae5d490a  vmovaps [rsp+0x50], xmm5
0000713aae5d4910  vmovaps [rsp+0x60], xmm6
0000713aae5d4916  vmovaps [rsp+0x70], xmm7
0000713aae5d491c  vmovaps [rsp+0x80], xmm8
0000713aae5d4925  vmovaps [rsp+0x90], xmm9
0000713aae5d492e  vmovaps [rsp+0xA0], xmm11
0000713aae5d4937  vmovaps [rsp+0xB0], xmm12
0000713aae5d4940  vmovaps [rsp+0xC0], xmm13
0000713aae5d4949  vmovaps [rsp+0xD0], xmm14
0000713aae5d4952  vmovaps [rsp+0xE0], xmm15
0000713aae5d495b  sub rsp, 0x40
0000713aae5d495f  lea rdi, [rsp]
0000713aae5d4963  lea rsi, [rsp+0x10]
0000713aae5d4968  lea rdx, [rsp+0x20]
0000713aae5d496d  lea rcx, [rsp+0x30]
0000713aae5d4972  mov r8d, 0x00
0000713aae5d4978  lea r9, [r15+0x3A8]
0000713aae5d497f  movaps [rdi], xmm10
0000713aae5d4983  movaps [rsi], xmm15
0000713aae5d4987  movaps [rdx], xmm1
0000713aae5d498a  movaps [rcx], xmm13
0000713aae5d498e  mov rax, 0x5E9381C89A50
0000713aae5d4998  call rax
0000713aae5d499a  movaps xmm10, [rsp]
0000713aae5d499f  add rsp, 0x40
0000713aae5d49a3  vmovaps xmm0, [rsp]
0000713aae5d49a8  vmovaps xmm1, [rsp+0x10]
0000713aae5d49ae  vmovaps xmm2, [rsp+0x20]
0000713aae5d49b4  vmovaps xmm3, [rsp+0x30]
0000713aae5d49ba  vmovaps xmm4, [rsp+0x40]
0000713aae5d49c0  vmovaps xmm5, [rsp+0x50]
0000713aae5d49c6  vmovaps xmm6, [rsp+0x60]
0000713aae5d49cc  vmovaps xmm7, [rsp+0x70]
0000713aae5d49d2  vmovaps xmm8, [rsp+0x80]
0000713aae5d49db  vmovaps xmm9, [rsp+0x90]
0000713aae5d49e4  vmovaps xmm11, [rsp+0xA0]
0000713aae5d49ed  vmovaps xmm12, [rsp+0xB0]
0000713aae5d49f6  vmovaps xmm13, [rsp+0xC0]
0000713aae5d49ff  vmovaps xmm14, [rsp+0xD0]
0000713aae5d4a08  vmovaps xmm15, [rsp+0xE0]
0000713aae5d4a11  add rsp, 0xF0
0000713aae5d4a18  pop r11
0000713aae5d4a1a  pop r10
0000713aae5d4a1c  pop r9
0000713aae5d4a1e  pop r8
0000713aae5d4a20  pop rsi
0000713aae5d4a21  pop rdi
0000713aae5d4a22  pop rdx
0000713aae5d4a23  pop rcx
0000713aae5d4a24  pop rax
0000713aae5d4a25  add rsp, 0x08
0000713aae5d4a29  jmp 0x0000713AAE5D2E6D
0000713aae5d4a2e  call 0x0000713AAE3FF430
0000713aae5d4a33  jmp 0x0000713AAE5D2E8F
0000713aae5d4a38  call 0x0000713AAE40E760
0000713aae5d4a3d  jmp 0x0000713AAE5D2E99
0000713aae5d4a42  sub rsp, 0x08
0000713aae5d4a46  push rax
0000713aae5d4a47  push rcx
0000713aae5d4a48  push rdx
0000713aae5d4a49  push rdi
0000713aae5d4a4a  push rsi
0000713aae5d4a4b  push r8
0000713aae5d4a4d  push r9
0000713aae5d4a4f  push r10
0000713aae5d4a51  push r11
0000713aae5d4a53  sub rsp, 0xF0
0000713aae5d4a5a  vmovaps [rsp], xmm0
0000713aae5d4a5f  vmovaps [rsp+0x10], xmm1
0000713aae5d4a65  vmovaps [rsp+0x20], xmm2
0000713aae5d4a6b  vmovaps [rsp+0x30], xmm3
0000713aae5d4a71  vmovaps [rsp+0x40], xmm4
0000713aae5d4a77  vmovaps [rsp+0x50], xmm5
0000713aae5d4a7d  vmovaps [rsp+0x60], xmm6
0000713aae5d4a83  vmovaps [rsp+0x70], xmm7
0000713aae5d4a89  vmovaps [rsp+0x80], xmm9
0000713aae5d4a92  vmovaps [rsp+0x90], xmm10
0000713aae5d4a9b  vmovaps [rsp+0xA0], xmm11
0000713aae5d4aa4  vmovaps [rsp+0xB0], xmm12
0000713aae5d4aad  vmovaps [rsp+0xC0], xmm13
0000713aae5d4ab6  vmovaps [rsp+0xD0], xmm14
0000713aae5d4abf  vmovaps [rsp+0xE0], xmm15
0000713aae5d4ac8  sub rsp, 0x40
0000713aae5d4acc  lea rdi, [rsp]
0000713aae5d4ad0  lea rsi, [rsp+0x10]
0000713aae5d4ad5  lea rdx, [rsp+0x20]
0000713aae5d4ada  lea rcx, [rsp+0x30]
0000713aae5d4adf  mov r8d, 0x00
0000713aae5d4ae5  lea r9, [r15+0x3A8]
0000713aae5d4aec  movaps [rdi], xmm8
0000713aae5d4af0  movaps [rsi], xmm5
0000713aae5d4af3  movaps [rdx], xmm9
0000713aae5d4af7  movaps [rcx], xmm13
0000713aae5d4afb  mov rax, 0x5E9381C89A50
0000713aae5d4b05  call rax
0000713aae5d4b07  movaps xmm8, [rsp]
0000713aae5d4b0c  add rsp, 0x40
0000713aae5d4b10  vmovaps xmm0, [rsp]
0000713aae5d4b15  vmovaps xmm1, [rsp+0x10]
0000713aae5d4b1b  vmovaps xmm2, [rsp+0x20]
0000713aae5d4b21  vmovaps xmm3, [rsp+0x30]
0000713aae5d4b27  vmovaps xmm4, [rsp+0x40]
0000713aae5d4b2d  vmovaps xmm5, [rsp+0x50]
0000713aae5d4b33  vmovaps xmm6, [rsp+0x60]
0000713aae5d4b39  vmovaps xmm7, [rsp+0x70]
0000713aae5d4b3f  vmovaps xmm9, [rsp+0x80]
0000713aae5d4b48  vmovaps xmm10, [rsp+0x90]
0000713aae5d4b51  vmovaps xmm11, [rsp+0xA0]
0000713aae5d4b5a  vmovaps xmm12, [rsp+0xB0]
0000713aae5d4b63  vmovaps xmm13, [rsp+0xC0]
0000713aae5d4b6c  vmovaps xmm14, [rsp+0xD0]
0000713aae5d4b75  vmovaps xmm15, [rsp+0xE0]
0000713aae5d4b7e  add rsp, 0xF0
0000713aae5d4b85  pop r11
0000713aae5d4b87  pop r10
0000713aae5d4b89  pop r9
0000713aae5d4b8b  pop r8
0000713aae5d4b8d  pop rsi
0000713aae5d4b8e  pop rdi
0000713aae5d4b8f  pop rdx
0000713aae5d4b90  pop rcx
0000713aae5d4b91  pop rax
0000713aae5d4b92  add rsp, 0x08
0000713aae5d4b96  jmp 0x0000713AAE5D2ED8
0000713aae5d4b9b  sub rsp, 0x08
0000713aae5d4b9f  push rax
0000713aae5d4ba0  push rcx
0000713aae5d4ba1  push rdx
0000713aae5d4ba2  push rdi
0000713aae5d4ba3  push rsi
0000713aae5d4ba4  push r8
0000713aae5d4ba6  push r9
0000713aae5d4ba8  push r10
0000713aae5d4baa  push r11
0000713aae5d4bac  sub rsp, 0xF0
0000713aae5d4bb3  vmovaps [rsp], xmm0
0000713aae5d4bb8  vmovaps [rsp+0x10], xmm1
0000713aae5d4bbe  vmovaps [rsp+0x20], xmm2
0000713aae5d4bc4  vmovaps [rsp+0x30], xmm3
0000713aae5d4bca  vmovaps [rsp+0x40], xmm4
0000713aae5d4bd0  vmovaps [rsp+0x50], xmm5
0000713aae5d4bd6  vmovaps [rsp+0x60], xmm6
0000713aae5d4bdc  vmovaps [rsp+0x70], xmm7
0000713aae5d4be2  vmovaps [rsp+0x80], xmm8
0000713aae5d4beb  vmovaps [rsp+0x90], xmm10
0000713aae5d4bf4  vmovaps [rsp+0xA0], xmm11
0000713aae5d4bfd  vmovaps [rsp+0xB0], xmm12
0000713aae5d4c06  vmovaps [rsp+0xC0], xmm13
0000713aae5d4c0f  vmovaps [rsp+0xD0], xmm14
0000713aae5d4c18  vmovaps [rsp+0xE0], xmm15
0000713aae5d4c21  sub rsp, 0x40
0000713aae5d4c25  lea rdi, [rsp]
0000713aae5d4c29  lea rsi, [rsp+0x10]
0000713aae5d4c2e  lea rdx, [rsp+0x20]
0000713aae5d4c33  lea rcx, [rsp+0x30]
0000713aae5d4c38  mov r8d, 0x00
0000713aae5d4c3e  lea r9, [r15+0x3A8]
0000713aae5d4c45  movaps [rdi], xmm9
0000713aae5d4c49  movaps [rsi], xmm12
0000713aae5d4c4d  movaps [rdx], xmm7
0000713aae5d4c50  movaps [rcx], xmm13
0000713aae5d4c54  mov rax, 0x5E9381C89A50
0000713aae5d4c5e  call rax
0000713aae5d4c60  movaps xmm9, [rsp]
0000713aae5d4c65  add rsp, 0x40
0000713aae5d4c69  vmovaps xmm0, [rsp]
0000713aae5d4c6e  vmovaps xmm1, [rsp+0x10]
0000713aae5d4c74  vmovaps xmm2, [rsp+0x20]
0000713aae5d4c7a  vmovaps xmm3, [rsp+0x30]
0000713aae5d4c80  vmovaps xmm4, [rsp+0x40]
0000713aae5d4c86  vmovaps xmm5, [rsp+0x50]
0000713aae5d4c8c  vmovaps xmm6, [rsp+0x60]
0000713aae5d4c92  vmovaps xmm7, [rsp+0x70]
0000713aae5d4c98  vmovaps xmm8, [rsp+0x80]
0000713aae5d4ca1  vmovaps xmm10, [rsp+0x90]
0000713aae5d4caa  vmovaps xmm11, [rsp+0xA0]
0000713aae5d4cb3  vmovaps xmm12, [rsp+0xB0]
0000713aae5d4cbc  vmovaps xmm13, [rsp+0xC0]
0000713aae5d4cc5  vmovaps xmm14, [rsp+0xD0]
0000713aae5d4cce  vmovaps xmm15, [rsp+0xE0]
0000713aae5d4cd7  add rsp, 0xF0
0000713aae5d4cde  pop r11
0000713aae5d4ce0  pop r10
0000713aae5d4ce2  pop r9
0000713aae5d4ce4  pop r8
0000713aae5d4ce6  pop rsi
0000713aae5d4ce7  pop rdi
0000713aae5d4ce8  pop rdx
0000713aae5d4ce9  pop rcx
0000713aae5d4cea  pop rax
0000713aae5d4ceb  add rsp, 0x08
0000713aae5d4cef  jmp 0x0000713AAE5D2F01
0000713aae5d4cf4  sub rsp, 0x08
0000713aae5d4cf8  push rax
0000713aae5d4cf9  push rcx
0000713aae5d4cfa  push rdx
0000713aae5d4cfb  push rdi
0000713aae5d4cfc  push rsi
0000713aae5d4cfd  push r8
0000713aae5d4cff  push r9
0000713aae5d4d01  push r10
0000713aae5d4d03  push r11
0000713aae5d4d05  sub rsp, 0xF0
0000713aae5d4d0c  vmovaps [rsp], xmm0
0000713aae5d4d11  vmovaps [rsp+0x10], xmm1
0000713aae5d4d17  vmovaps [rsp+0x20], xmm2
0000713aae5d4d1d  vmovaps [rsp+0x30], xmm3
0000713aae5d4d23  vmovaps [rsp+0x40], xmm4
0000713aae5d4d29  vmovaps [rsp+0x50], xmm5
0000713aae5d4d2f  vmovaps [rsp+0x60], xmm6
0000713aae5d4d35  vmovaps [rsp+0x70], xmm7
0000713aae5d4d3b  vmovaps [rsp+0x80], xmm8
0000713aae5d4d44  vmovaps [rsp+0x90], xmm9
0000713aae5d4d4d  vmovaps [rsp+0xA0], xmm10
0000713aae5d4d56  vmovaps [rsp+0xB0], xmm11
0000713aae5d4d5f  vmovaps [rsp+0xC0], xmm13
0000713aae5d4d68  vmovaps [rsp+0xD0], xmm14
0000713aae5d4d71  vmovaps [rsp+0xE0], xmm15
0000713aae5d4d7a  sub rsp, 0x40
0000713aae5d4d7e  lea rdi, [rsp]
0000713aae5d4d82  lea rsi, [rsp+0x10]
0000713aae5d4d87  lea rdx, [rsp+0x20]
0000713aae5d4d8c  lea rcx, [rsp+0x30]
0000713aae5d4d91  mov r8d, 0x00
0000713aae5d4d97  lea r9, [r15+0x3A8]
0000713aae5d4d9e  movaps [rdi], xmm12
0000713aae5d4da2  movaps [rsi], xmm11
0000713aae5d4da6  movaps [rdx], xmm6
0000713aae5d4da9  movaps [rcx], xmm13
0000713aae5d4dad  mov rax, 0x5E9381C89A50
0000713aae5d4db7  call rax
0000713aae5d4db9  movaps xmm12, [rsp]
0000713aae5d4dbe  add rsp, 0x40
0000713aae5d4dc2  vmovaps xmm0, [rsp]
0000713aae5d4dc7  vmovaps xmm1, [rsp+0x10]
0000713aae5d4dcd  vmovaps xmm2, [rsp+0x20]
0000713aae5d4dd3  vmovaps xmm3, [rsp+0x30]
0000713aae5d4dd9  vmovaps xmm4, [rsp+0x40]
0000713aae5d4ddf  vmovaps xmm5, [rsp+0x50]
0000713aae5d4de5  vmovaps xmm6, [rsp+0x60]
0000713aae5d4deb  vmovaps xmm7, [rsp+0x70]
0000713aae5d4df1  vmovaps xmm8, [rsp+0x80]
0000713aae5d4dfa  vmovaps xmm9, [rsp+0x90]
0000713aae5d4e03  vmovaps xmm10, [rsp+0xA0]
0000713aae5d4e0c  vmovaps xmm11, [rsp+0xB0]
0000713aae5d4e15  vmovaps xmm13, [rsp+0xC0]
0000713aae5d4e1e  vmovaps xmm14, [rsp+0xD0]
0000713aae5d4e27  vmovaps xmm15, [rsp+0xE0]
0000713aae5d4e30  add rsp, 0xF0
0000713aae5d4e37  pop r11
0000713aae5d4e39  pop r10
0000713aae5d4e3b  pop r9
0000713aae5d4e3d  pop r8
0000713aae5d4e3f  pop rsi
0000713aae5d4e40  pop rdi
0000713aae5d4e41  pop rdx
0000713aae5d4e42  pop rcx
0000713aae5d4e43  pop rax
0000713aae5d4e44  add rsp, 0x08
0000713aae5d4e48  jmp 0x0000713AAE5D2F2A
0000713aae5d4e4d  sub rsp, 0x08
0000713aae5d4e51  push rax
0000713aae5d4e52  push rcx
0000713aae5d4e53  push rdx
0000713aae5d4e54  push rdi
0000713aae5d4e55  push rsi
0000713aae5d4e56  push r8
0000713aae5d4e58  push r9
0000713aae5d4e5a  push r10
0000713aae5d4e5c  push r11
0000713aae5d4e5e  sub rsp, 0xF0
0000713aae5d4e65  vmovaps [rsp], xmm0
0000713aae5d4e6a  vmovaps [rsp+0x10], xmm1
0000713aae5d4e70  vmovaps [rsp+0x20], xmm2
0000713aae5d4e76  vmovaps [rsp+0x30], xmm3
0000713aae5d4e7c  vmovaps [rsp+0x40], xmm4
0000713aae5d4e82  vmovaps [rsp+0x50], xmm5
0000713aae5d4e88  vmovaps [rsp+0x60], xmm6
0000713aae5d4e8e  vmovaps [rsp+0x70], xmm8
0000713aae5d4e94  vmovaps [rsp+0x80], xmm9
0000713aae5d4e9d  vmovaps [rsp+0x90], xmm10
0000713aae5d4ea6  vmovaps [rsp+0xA0], xmm11
0000713aae5d4eaf  vmovaps [rsp+0xB0], xmm12
0000713aae5d4eb8  vmovaps [rsp+0xC0], xmm13
0000713aae5d4ec1  vmovaps [rsp+0xD0], xmm14
0000713aae5d4eca  vmovaps [rsp+0xE0], xmm15
0000713aae5d4ed3  sub rsp, 0x40
0000713aae5d4ed7  lea rdi, [rsp]
0000713aae5d4edb  lea rsi, [rsp+0x10]
0000713aae5d4ee0  lea rdx, [rsp+0x20]
0000713aae5d4ee5  lea rcx, [rsp+0x30]
0000713aae5d4eea  mov r8d, 0x00
0000713aae5d4ef0  lea r9, [r15+0x3A8]
0000713aae5d4ef7  movaps [rdi], xmm7
0000713aae5d4efa  movaps [rsi], xmm10
0000713aae5d4efe  movaps [rdx], xmm11
0000713aae5d4f02  movaps [rcx], xmm13
0000713aae5d4f06  mov rax, 0x5E9381C89A50
0000713aae5d4f10  call rax
0000713aae5d4f12  movaps xmm7, [rsp]
0000713aae5d4f16  add rsp, 0x40
0000713aae5d4f1a  vmovaps xmm0, [rsp]
0000713aae5d4f1f  vmovaps xmm1, [rsp+0x10]
0000713aae5d4f25  vmovaps xmm2, [rsp+0x20]
0000713aae5d4f2b  vmovaps xmm3, [rsp+0x30]
0000713aae5d4f31  vmovaps xmm4, [rsp+0x40]
0000713aae5d4f37  vmovaps xmm5, [rsp+0x50]
0000713aae5d4f3d  vmovaps xmm6, [rsp+0x60]
0000713aae5d4f43  vmovaps xmm8, [rsp+0x70]
0000713aae5d4f49  vmovaps xmm9, [rsp+0x80]
0000713aae5d4f52  vmovaps xmm10, [rsp+0x90]
0000713aae5d4f5b  vmovaps xmm11, [rsp+0xA0]
0000713aae5d4f64  vmovaps xmm12, [rsp+0xB0]
0000713aae5d4f6d  vmovaps xmm13, [rsp+0xC0]
0000713aae5d4f76  vmovaps xmm14, [rsp+0xD0]
0000713aae5d4f7f  vmovaps xmm15, [rsp+0xE0]
0000713aae5d4f88  add rsp, 0xF0
0000713aae5d4f8f  pop r11
0000713aae5d4f91  pop r10
0000713aae5d4f93  pop r9
0000713aae5d4f95  pop r8
0000713aae5d4f97  pop rsi
0000713aae5d4f98  pop rdi
0000713aae5d4f99  pop rdx
0000713aae5d4f9a  pop rcx
0000713aae5d4f9b  pop rax
0000713aae5d4f9c  add rsp, 0x08
0000713aae5d4fa0  jmp 0x0000713AAE5D2F58
0000713aae5d4fa5  call 0x0000713AAE40C260
0000713aae5d4faa  jmp 0x0000713AAE5D2F62
0000713aae5d4faf  call 0x0000713AAE409D70
0000713aae5d4fb4  jmp 0x0000713AAE5D2F6C
0000713aae5d4fb9  sub rsp, 0x08
0000713aae5d4fbd  push rax
0000713aae5d4fbe  push rcx
0000713aae5d4fbf  push rdx
0000713aae5d4fc0  push rdi
0000713aae5d4fc1  push rsi
0000713aae5d4fc2  push r8
0000713aae5d4fc4  push r9
0000713aae5d4fc6  push r10
0000713aae5d4fc8  push r11
0000713aae5d4fca  sub rsp, 0xF0
0000713aae5d4fd1  vmovaps [rsp], xmm0
0000713aae5d4fd6  vmovaps [rsp+0x10], xmm1
0000713aae5d4fdc  vmovaps [rsp+0x20], xmm2
0000713aae5d4fe2  vmovaps [rsp+0x30], xmm3
0000713aae5d4fe8  vmovaps [rsp+0x40], xmm4
0000713aae5d4fee  vmovaps [rsp+0x50], xmm5
0000713aae5d4ff4  vmovaps [rsp+0x60], xmm7
0000713aae5d4ffa  vmovaps [rsp+0x70], xmm8
0000713aae5d5000  vmovaps [rsp+0x80], xmm9
0000713aae5d5009  vmovaps [rsp+0x90], xmm10
0000713aae5d5012  vmovaps [rsp+0xA0], xmm11
0000713aae5d501b  vmovaps [rsp+0xB0], xmm12
0000713aae5d5024  vmovaps [rsp+0xC0], xmm13
0000713aae5d502d  vmovaps [rsp+0xD0], xmm14
0000713aae5d5036  vmovaps [rsp+0xE0], xmm15
0000713aae5d503f  sub rsp, 0x40
0000713aae5d5043  lea rdi, [rsp]
0000713aae5d5047  lea rsi, [rsp+0x10]
0000713aae5d504c  lea rdx, [rsp+0x20]
0000713aae5d5051  lea rcx, [rsp+0x30]
0000713aae5d5056  mov r8d, 0x00
0000713aae5d505c  lea r9, [r15+0x3A8]
0000713aae5d5063  movaps [rdi], xmm6
0000713aae5d5066  movaps [rsi], xmm8
0000713aae5d506a  movaps [rdx], xmm15
0000713aae5d506e  movaps [rcx], xmm10
0000713aae5d5072  mov rax, 0x5E9381C89A50
0000713aae5d507c  call rax
0000713aae5d507e  movaps xmm6, [rsp]
0000713aae5d5082  add rsp, 0x40
0000713aae5d5086  vmovaps xmm0, [rsp]
0000713aae5d508b  vmovaps xmm1, [rsp+0x10]
0000713aae5d5091  vmovaps xmm2, [rsp+0x20]
0000713aae5d5097  vmovaps xmm3, [rsp+0x30]
0000713aae5d509d  vmovaps xmm4, [rsp+0x40]
0000713aae5d50a3  vmovaps xmm5, [rsp+0x50]
0000713aae5d50a9  vmovaps xmm7, [rsp+0x60]
0000713aae5d50af  vmovaps xmm8, [rsp+0x70]
0000713aae5d50b5  vmovaps xmm9, [rsp+0x80]
0000713aae5d50be  vmovaps xmm10, [rsp+0x90]
0000713aae5d50c7  vmovaps xmm11, [rsp+0xA0]
0000713aae5d50d0  vmovaps xmm12, [rsp+0xB0]
0000713aae5d50d9  vmovaps xmm13, [rsp+0xC0]
0000713aae5d50e2  vmovaps xmm14, [rsp+0xD0]
0000713aae5d50eb  vmovaps xmm15, [rsp+0xE0]
0000713aae5d50f4  add rsp, 0xF0
0000713aae5d50fb  pop r11
0000713aae5d50fd  pop r10
0000713aae5d50ff  pop r9
0000713aae5d5101  pop r8
0000713aae5d5103  pop rsi
0000713aae5d5104  pop rdi
0000713aae5d5105  pop rdx
0000713aae5d5106  pop rcx
0000713aae5d5107  pop rax
0000713aae5d5108  add rsp, 0x08
0000713aae5d510c  jmp 0x0000713AAE5D2FA4
0000713aae5d5111  sub rsp, 0x08
0000713aae5d5115  push rax
0000713aae5d5116  push rcx
0000713aae5d5117  push rdx
0000713aae5d5118  push rdi
0000713aae5d5119  push rsi
0000713aae5d511a  push r8
0000713aae5d511c  push r9
0000713aae5d511e  push r10
0000713aae5d5120  push r11
0000713aae5d5122  sub rsp, 0xF0
0000713aae5d5129  vmovaps [rsp], xmm0
0000713aae5d512e  vmovaps [rsp+0x10], xmm1
0000713aae5d5134  vmovaps [rsp+0x20], xmm2
0000713aae5d513a  vmovaps [rsp+0x30], xmm3
0000713aae5d5140  vmovaps [rsp+0x40], xmm4
0000713aae5d5146  vmovaps [rsp+0x50], xmm5
0000713aae5d514c  vmovaps [rsp+0x60], xmm6
0000713aae5d5152  vmovaps [rsp+0x70], xmm7
0000713aae5d5158  vmovaps [rsp+0x80], xmm8
0000713aae5d5161  vmovaps [rsp+0x90], xmm9
0000713aae5d516a  vmovaps [rsp+0xA0], xmm11
0000713aae5d5173  vmovaps [rsp+0xB0], xmm12
0000713aae5d517c  vmovaps [rsp+0xC0], xmm13
0000713aae5d5185  vmovaps [rsp+0xD0], xmm14
0000713aae5d518e  vmovaps [rsp+0xE0], xmm15
0000713aae5d5197  sub rsp, 0x40
0000713aae5d519b  lea rdi, [rsp]
0000713aae5d519f  lea rsi, [rsp+0x10]
0000713aae5d51a4  lea rdx, [rsp+0x20]
0000713aae5d51a9  lea rcx, [rsp+0x30]
0000713aae5d51ae  mov r8d, 0x00
0000713aae5d51b4  lea r9, [r15+0x3A8]
0000713aae5d51bb  movaps [rdi], xmm10
0000713aae5d51bf  movaps [rsi], xmm9
0000713aae5d51c3  movaps [rdx], xmm13
0000713aae5d51c7  movaps [rcx], xmm15
0000713aae5d51cb  mov rax, 0x5E9381C89A50
0000713aae5d51d5  call rax
0000713aae5d51d7  movaps xmm10, [rsp]
0000713aae5d51dc  add rsp, 0x40
0000713aae5d51e0  vmovaps xmm0, [rsp]
0000713aae5d51e5  vmovaps xmm1, [rsp+0x10]
0000713aae5d51eb  vmovaps xmm2, [rsp+0x20]
0000713aae5d51f1  vmovaps xmm3, [rsp+0x30]
0000713aae5d51f7  vmovaps xmm4, [rsp+0x40]
0000713aae5d51fd  vmovaps xmm5, [rsp+0x50]
0000713aae5d5203  vmovaps xmm6, [rsp+0x60]
0000713aae5d5209  vmovaps xmm7, [rsp+0x70]
0000713aae5d520f  vmovaps xmm8, [rsp+0x80]
0000713aae5d5218  vmovaps xmm9, [rsp+0x90]
0000713aae5d5221  vmovaps xmm11, [rsp+0xA0]
0000713aae5d522a  vmovaps xmm12, [rsp+0xB0]
0000713aae5d5233  vmovaps xmm13, [rsp+0xC0]
0000713aae5d523c  vmovaps xmm14, [rsp+0xD0]
0000713aae5d5245  vmovaps xmm15, [rsp+0xE0]
0000713aae5d524e  add rsp, 0xF0
0000713aae5d5255  pop r11
0000713aae5d5257  pop r10
0000713aae5d5259  pop r9
0000713aae5d525b  pop r8
0000713aae5d525d  pop rsi
0000713aae5d525e  pop rdi
0000713aae5d525f  pop rdx
0000713aae5d5260  pop rcx
0000713aae5d5261  pop rax
0000713aae5d5262  add rsp, 0x08
0000713aae5d5266  jmp 0x0000713AAE5D2FCD
0000713aae5d526b  sub rsp, 0x08
0000713aae5d526f  push rax
0000713aae5d5270  push rcx
0000713aae5d5271  push rdx
0000713aae5d5272  push rdi
0000713aae5d5273  push rsi
0000713aae5d5274  push r8
0000713aae5d5276  push r9
0000713aae5d5278  push r10
0000713aae5d527a  push r11
0000713aae5d527c  sub rsp, 0xF0
0000713aae5d5283  vmovaps [rsp], xmm0
0000713aae5d5288  vmovaps [rsp+0x10], xmm1
0000713aae5d528e  vmovaps [rsp+0x20], xmm2
0000713aae5d5294  vmovaps [rsp+0x30], xmm3
0000713aae5d529a  vmovaps [rsp+0x40], xmm4
0000713aae5d52a0  vmovaps [rsp+0x50], xmm5
0000713aae5d52a6  vmovaps [rsp+0x60], xmm6
0000713aae5d52ac  vmovaps [rsp+0x70], xmm7
0000713aae5d52b2  vmovaps [rsp+0x80], xmm8
0000713aae5d52bb  vmovaps [rsp+0x90], xmm9
0000713aae5d52c4  vmovaps [rsp+0xA0], xmm10
0000713aae5d52cd  vmovaps [rsp+0xB0], xmm11
0000713aae5d52d6  vmovaps [rsp+0xC0], xmm12
0000713aae5d52df  vmovaps [rsp+0xD0], xmm14
0000713aae5d52e8  vmovaps [rsp+0xE0], xmm15
0000713aae5d52f1  sub rsp, 0x40
0000713aae5d52f5  lea rdi, [rsp]
0000713aae5d52f9  lea rsi, [rsp+0x10]
0000713aae5d52fe  lea rdx, [rsp+0x20]
0000713aae5d5303  lea rcx, [rsp+0x30]
0000713aae5d5308  mov r8d, 0x00
0000713aae5d530e  lea r9, [r15+0x3A8]
0000713aae5d5315  movaps [rdi], xmm13
0000713aae5d5319  movaps [rsi], xmm12
0000713aae5d531d  movaps [rdx], xmm4
0000713aae5d5320  movaps [rcx], xmm15
0000713aae5d5324  mov rax, 0x5E9381C89A50
0000713aae5d532e  call rax
0000713aae5d5330  movaps xmm13, [rsp]
0000713aae5d5335  add rsp, 0x40
0000713aae5d5339  vmovaps xmm0, [rsp]
0000713aae5d533e  vmovaps xmm1, [rsp+0x10]
0000713aae5d5344  vmovaps xmm2, [rsp+0x20]
0000713aae5d534a  vmovaps xmm3, [rsp+0x30]
0000713aae5d5350  vmovaps xmm4, [rsp+0x40]
0000713aae5d5356  vmovaps xmm5, [rsp+0x50]
0000713aae5d535c  vmovaps xmm6, [rsp+0x60]
0000713aae5d5362  vmovaps xmm7, [rsp+0x70]
0000713aae5d5368  vmovaps xmm8, [rsp+0x80]
0000713aae5d5371  vmovaps xmm9, [rsp+0x90]
0000713aae5d537a  vmovaps xmm10, [rsp+0xA0]
0000713aae5d5383  vmovaps xmm11, [rsp+0xB0]
0000713aae5d538c  vmovaps xmm12, [rsp+0xC0]
0000713aae5d5395  vmovaps xmm14, [rsp+0xD0]
0000713aae5d539e  vmovaps xmm15, [rsp+0xE0]
0000713aae5d53a7  add rsp, 0xF0
0000713aae5d53ae  pop r11
0000713aae5d53b0  pop r10
0000713aae5d53b2  pop r9
0000713aae5d53b4  pop r8
0000713aae5d53b6  pop rsi
0000713aae5d53b7  pop rdi
0000713aae5d53b8  pop rdx
0000713aae5d53b9  pop rcx
0000713aae5d53ba  pop rax
0000713aae5d53bb  add rsp, 0x08
0000713aae5d53bf  jmp 0x0000713AAE5D2FF6
0000713aae5d53c4  sub rsp, 0x08
0000713aae5d53c8  push rax
0000713aae5d53c9  push rcx
0000713aae5d53ca  push rdx
0000713aae5d53cb  push rdi
0000713aae5d53cc  push rsi
0000713aae5d53cd  push r8
0000713aae5d53cf  push r9
0000713aae5d53d1  push r10
0000713aae5d53d3  push r11
0000713aae5d53d5  sub rsp, 0xF0
0000713aae5d53dc  vmovaps [rsp], xmm0
0000713aae5d53e1  vmovaps [rsp+0x10], xmm1
0000713aae5d53e7  vmovaps [rsp+0x20], xmm2
0000713aae5d53ed  vmovaps [rsp+0x30], xmm3
0000713aae5d53f3  vmovaps [rsp+0x40], xmm4
0000713aae5d53f9  vmovaps [rsp+0x50], xmm5
0000713aae5d53ff  vmovaps [rsp+0x60], xmm6
0000713aae5d5405  vmovaps [rsp+0x70], xmm7
0000713aae5d540b  vmovaps [rsp+0x80], xmm8
0000713aae5d5414  vmovaps [rsp+0x90], xmm9
0000713aae5d541d  vmovaps [rsp+0xA0], xmm10
0000713aae5d5426  vmovaps [rsp+0xB0], xmm11
0000713aae5d542f  vmovaps [rsp+0xC0], xmm13
0000713aae5d5438  vmovaps [rsp+0xD0], xmm14
0000713aae5d5441  vmovaps [rsp+0xE0], xmm15
0000713aae5d544a  sub rsp, 0x40
0000713aae5d544e  lea rdi, [rsp]
0000713aae5d5452  lea rsi, [rsp+0x10]
0000713aae5d5457  lea rdx, [rsp+0x20]
0000713aae5d545c  lea rcx, [rsp+0x30]
0000713aae5d5461  mov r8d, 0x00
0000713aae5d5467  lea r9, [r15+0x3A8]
0000713aae5d546e  movaps [rdi], xmm12
0000713aae5d5472  movaps [rsi], xmm7
0000713aae5d5475  movaps [rdx], xmm1
0000713aae5d5478  movaps [rcx], xmm15
0000713aae5d547c  mov rax, 0x5E9381C89A50
0000713aae5d5486  call rax
0000713aae5d5488  movaps xmm12, [rsp]
0000713aae5d548d  add rsp, 0x40
0000713aae5d5491  vmovaps xmm0, [rsp]
0000713aae5d5496  vmovaps xmm1, [rsp+0x10]
0000713aae5d549c  vmovaps xmm2, [rsp+0x20]
0000713aae5d54a2  vmovaps xmm3, [rsp+0x30]
0000713aae5d54a8  vmovaps xmm4, [rsp+0x40]
0000713aae5d54ae  vmovaps xmm5, [rsp+0x50]
0000713aae5d54b4  vmovaps xmm6, [rsp+0x60]
0000713aae5d54ba  vmovaps xmm7, [rsp+0x70]
0000713aae5d54c0  vmovaps xmm8, [rsp+0x80]
0000713aae5d54c9  vmovaps xmm9, [rsp+0x90]
0000713aae5d54d2  vmovaps xmm10, [rsp+0xA0]
0000713aae5d54db  vmovaps xmm11, [rsp+0xB0]
0000713aae5d54e4  vmovaps xmm13, [rsp+0xC0]
0000713aae5d54ed  vmovaps xmm14, [rsp+0xD0]
0000713aae5d54f6  vmovaps xmm15, [rsp+0xE0]
0000713aae5d54ff  add rsp, 0xF0
0000713aae5d5506  pop r11
0000713aae5d5508  pop r10
0000713aae5d550a  pop r9
0000713aae5d550c  pop r8
0000713aae5d550e  pop rsi
0000713aae5d550f  pop rdi
0000713aae5d5510  pop rdx
0000713aae5d5511  pop rcx
0000713aae5d5512  pop rax
0000713aae5d5513  add rsp, 0x08
0000713aae5d5517  jmp 0x0000713AAE5D301F
0000713aae5d551c  call 0x0000713AAE3FF430
0000713aae5d5521  jmp 0x0000713AAE5D3029
0000713aae5d5526  call 0x0000713AAE40E760
0000713aae5d552b  jmp 0x0000713AAE5D3033
0000713aae5d5530  sub rsp, 0x08
0000713aae5d5534  push rax
0000713aae5d5535  push rcx
0000713aae5d5536  push rdx
0000713aae5d5537  push rdi
0000713aae5d5538  push rsi
0000713aae5d5539  push r8
0000713aae5d553b  push r9
0000713aae5d553d  push r10
0000713aae5d553f  push r11
0000713aae5d5541  sub rsp, 0xF0
0000713aae5d5548  vmovaps [rsp], xmm0
0000713aae5d554d  vmovaps [rsp+0x10], xmm1
0000713aae5d5553  vmovaps [rsp+0x20], xmm2
0000713aae5d5559  vmovaps [rsp+0x30], xmm3
0000713aae5d555f  vmovaps [rsp+0x40], xmm4
0000713aae5d5565  vmovaps [rsp+0x50], xmm5
0000713aae5d556b  vmovaps [rsp+0x60], xmm6
0000713aae5d5571  vmovaps [rsp+0x70], xmm8
0000713aae5d5577  vmovaps [rsp+0x80], xmm9
0000713aae5d5580  vmovaps [rsp+0x90], xmm10
0000713aae5d5589  vmovaps [rsp+0xA0], xmm11
0000713aae5d5592  vmovaps [rsp+0xB0], xmm12
0000713aae5d559b  vmovaps [rsp+0xC0], xmm13
0000713aae5d55a4  vmovaps [rsp+0xD0], xmm14
0000713aae5d55ad  vmovaps [rsp+0xE0], xmm15
0000713aae5d55b6  sub rsp, 0x40
0000713aae5d55ba  lea rdi, [rsp]
0000713aae5d55be  lea rsi, [rsp+0x10]
0000713aae5d55c3  lea rdx, [rsp+0x20]
0000713aae5d55c8  lea rcx, [rsp+0x30]
0000713aae5d55cd  mov r8d, 0x00
0000713aae5d55d3  lea r9, [r15+0x3A8]
0000713aae5d55da  movaps [rdi], xmm7
0000713aae5d55dd  movaps [rsi], xmm6
0000713aae5d55e0  movaps [rdx], xmm8
0000713aae5d55e4  movaps [rcx], xmm9
0000713aae5d55e8  mov rax, 0x5E9381C89A50
0000713aae5d55f2  call rax
0000713aae5d55f4  movaps xmm7, [rsp]
0000713aae5d55f8  add rsp, 0x40
0000713aae5d55fc  vmovaps xmm0, [rsp]
0000713aae5d5601  vmovaps xmm1, [rsp+0x10]
0000713aae5d5607  vmovaps xmm2, [rsp+0x20]
0000713aae5d560d  vmovaps xmm3, [rsp+0x30]
0000713aae5d5613  vmovaps xmm4, [rsp+0x40]
0000713aae5d5619  vmovaps xmm5, [rsp+0x50]
0000713aae5d561f  vmovaps xmm6, [rsp+0x60]
0000713aae5d5625  vmovaps xmm8, [rsp+0x70]
0000713aae5d562b  vmovaps xmm9, [rsp+0x80]
0000713aae5d5634  vmovaps xmm10, [rsp+0x90]
0000713aae5d563d  vmovaps xmm11, [rsp+0xA0]
0000713aae5d5646  vmovaps xmm12, [rsp+0xB0]
0000713aae5d564f  vmovaps xmm13, [rsp+0xC0]
0000713aae5d5658  vmovaps xmm14, [rsp+0xD0]
0000713aae5d5661  vmovaps xmm15, [rsp+0xE0]
0000713aae5d566a  add rsp, 0xF0
0000713aae5d5671  pop r11
0000713aae5d5673  pop r10
0000713aae5d5675  pop r9
0000713aae5d5677  pop r8
0000713aae5d5679  pop rsi
0000713aae5d567a  pop rdi
0000713aae5d567b  pop rdx
0000713aae5d567c  pop rcx
0000713aae5d567d  pop rax
0000713aae5d567e  add rsp, 0x08
0000713aae5d5682  jmp 0x0000713AAE5D305D
0000713aae5d5687  sub rsp, 0x08
0000713aae5d568b  push rax
0000713aae5d568c  push rcx
0000713aae5d568d  push rdx
0000713aae5d568e  push rdi
0000713aae5d568f  push rsi
0000713aae5d5690  push r8
0000713aae5d5692  push r9
0000713aae5d5694  push r10
0000713aae5d5696  push r11
0000713aae5d5698  sub rsp, 0xF0
0000713aae5d569f  vmovaps [rsp], xmm0
0000713aae5d56a4  vmovaps [rsp+0x10], xmm1
0000713aae5d56aa  vmovaps [rsp+0x20], xmm2
0000713aae5d56b0  vmovaps [rsp+0x30], xmm3
0000713aae5d56b6  vmovaps [rsp+0x40], xmm4
0000713aae5d56bc  vmovaps [rsp+0x50], xmm5
0000713aae5d56c2  vmovaps [rsp+0x60], xmm6
0000713aae5d56c8  vmovaps [rsp+0x70], xmm7
0000713aae5d56ce  vmovaps [rsp+0x80], xmm9
0000713aae5d56d7  vmovaps [rsp+0x90], xmm10
0000713aae5d56e0  vmovaps [rsp+0xA0], xmm11
0000713aae5d56e9  vmovaps [rsp+0xB0], xmm12
0000713aae5d56f2  vmovaps [rsp+0xC0], xmm13
0000713aae5d56fb  vmovaps [rsp+0xD0], xmm14
0000713aae5d5704  vmovaps [rsp+0xE0], xmm15
0000713aae5d570d  sub rsp, 0x40
0000713aae5d5711  lea rdi, [rsp]
0000713aae5d5715  lea rsi, [rsp+0x10]
0000713aae5d571a  lea rdx, [rsp+0x20]
0000713aae5d571f  lea rcx, [rsp+0x30]
0000713aae5d5724  mov r8d, 0x00
0000713aae5d572a  lea r9, [r15+0x3A8]
0000713aae5d5731  movaps [rdi], xmm8
0000713aae5d5735  movaps [rsi], xmm10
0000713aae5d5739  movaps [rdx], xmm14
0000713aae5d573d  movaps [rcx], xmm9
0000713aae5d5741  mov rax, 0x5E9381C89A50
0000713aae5d574b  call rax
0000713aae5d574d  movaps xmm8, [rsp]
0000713aae5d5752  add rsp, 0x40
0000713aae5d5756  vmovaps xmm0, [rsp]
0000713aae5d575b  vmovaps xmm1, [rsp+0x10]
0000713aae5d5761  vmovaps xmm2, [rsp+0x20]
0000713aae5d5767  vmovaps xmm3, [rsp+0x30]
0000713aae5d576d  vmovaps xmm4, [rsp+0x40]
0000713aae5d5773  vmovaps xmm5, [rsp+0x50]
0000713aae5d5779  vmovaps xmm6, [rsp+0x60]
0000713aae5d577f  vmovaps xmm7, [rsp+0x70]
0000713aae5d5785  vmovaps xmm9, [rsp+0x80]
0000713aae5d578e  vmovaps xmm10, [rsp+0x90]
0000713aae5d5797  vmovaps xmm11, [rsp+0xA0]
0000713aae5d57a0  vmovaps xmm12, [rsp+0xB0]
0000713aae5d57a9  vmovaps xmm13, [rsp+0xC0]
0000713aae5d57b2  vmovaps xmm14, [rsp+0xD0]
0000713aae5d57bb  vmovaps xmm15, [rsp+0xE0]
0000713aae5d57c4  add rsp, 0xF0
0000713aae5d57cb  pop r11
0000713aae5d57cd  pop r10
0000713aae5d57cf  pop r9
0000713aae5d57d1  pop r8
0000713aae5d57d3  pop rsi
0000713aae5d57d4  pop rdi
0000713aae5d57d5  pop rdx
0000713aae5d57d6  pop rcx
0000713aae5d57d7  pop rax
0000713aae5d57d8  add rsp, 0x08
0000713aae5d57dc  jmp 0x0000713AAE5D3083
0000713aae5d57e1  sub rsp, 0x08
0000713aae5d57e5  push rax
0000713aae5d57e6  push rcx
0000713aae5d57e7  push rdx
0000713aae5d57e8  push rdi
0000713aae5d57e9  push rsi
0000713aae5d57ea  push r8
0000713aae5d57ec  push r9
0000713aae5d57ee  push r10
0000713aae5d57f0  push r11
0000713aae5d57f2  sub rsp, 0xF0
0000713aae5d57f9  vmovaps [rsp], xmm0
0000713aae5d57fe  vmovaps [rsp+0x10], xmm1
0000713aae5d5804  vmovaps [rsp+0x20], xmm2
0000713aae5d580a  vmovaps [rsp+0x30], xmm3
0000713aae5d5810  vmovaps [rsp+0x40], xmm4
0000713aae5d5816  vmovaps [rsp+0x50], xmm5
0000713aae5d581c  vmovaps [rsp+0x60], xmm6
0000713aae5d5822  vmovaps [rsp+0x70], xmm7
0000713aae5d5828  vmovaps [rsp+0x80], xmm8
0000713aae5d5831  vmovaps [rsp+0x90], xmm9
0000713aae5d583a  vmovaps [rsp+0xA0], xmm11
0000713aae5d5843  vmovaps [rsp+0xB0], xmm12
0000713aae5d584c  vmovaps [rsp+0xC0], xmm13
0000713aae5d5855  vmovaps [rsp+0xD0], xmm14
0000713aae5d585e  vmovaps [rsp+0xE0], xmm15
0000713aae5d5867  sub rsp, 0x40
0000713aae5d586b  lea rdi, [rsp]
0000713aae5d586f  lea rsi, [rsp+0x10]
0000713aae5d5874  lea rdx, [rsp+0x20]
0000713aae5d5879  lea rcx, [rsp+0x30]
0000713aae5d587e  mov r8d, 0x00
0000713aae5d5884  lea r9, [r15+0x3A8]
0000713aae5d588b  movaps [rdi], xmm10
0000713aae5d588f  movaps [rsi], xmm13
0000713aae5d5893  movaps [rdx], xmm11
0000713aae5d5897  movaps [rcx], xmm14
0000713aae5d589b  mov rax, 0x5E9381C89A50
0000713aae5d58a5  call rax
0000713aae5d58a7  movaps xmm10, [rsp]
0000713aae5d58ac  add rsp, 0x40
0000713aae5d58b0  vmovaps xmm0, [rsp]
0000713aae5d58b5  vmovaps xmm1, [rsp+0x10]
0000713aae5d58bb  vmovaps xmm2, [rsp+0x20]
0000713aae5d58c1  vmovaps xmm3, [rsp+0x30]
0000713aae5d58c7  vmovaps xmm4, [rsp+0x40]
0000713aae5d58cd  vmovaps xmm5, [rsp+0x50]
0000713aae5d58d3  vmovaps xmm6, [rsp+0x60]
0000713aae5d58d9  vmovaps xmm7, [rsp+0x70]
0000713aae5d58df  vmovaps xmm8, [rsp+0x80]
0000713aae5d58e8  vmovaps xmm9, [rsp+0x90]
0000713aae5d58f1  vmovaps xmm11, [rsp+0xA0]
0000713aae5d58fa  vmovaps xmm12, [rsp+0xB0]
0000713aae5d5903  vmovaps xmm13, [rsp+0xC0]
0000713aae5d590c  vmovaps xmm14, [rsp+0xD0]
0000713aae5d5915  vmovaps xmm15, [rsp+0xE0]
0000713aae5d591e  add rsp, 0xF0
0000713aae5d5925  pop r11
0000713aae5d5927  pop r10
0000713aae5d5929  pop r9
0000713aae5d592b  pop r8
0000713aae5d592d  pop rsi
0000713aae5d592e  pop rdi
0000713aae5d592f  pop rdx
0000713aae5d5930  pop rcx
0000713aae5d5931  pop rax
0000713aae5d5932  add rsp, 0x08
0000713aae5d5936  jmp 0x0000713AAE5D30A9
0000713aae5d593b  sub rsp, 0x08
0000713aae5d593f  push rax
0000713aae5d5940  push rcx
0000713aae5d5941  push rdx
0000713aae5d5942  push rdi
0000713aae5d5943  push rsi
0000713aae5d5944  push r8
0000713aae5d5946  push r9
0000713aae5d5948  push r10
0000713aae5d594a  push r11
0000713aae5d594c  sub rsp, 0xF0
0000713aae5d5953  vmovaps [rsp], xmm0
0000713aae5d5958  vmovaps [rsp+0x10], xmm1
0000713aae5d595e  vmovaps [rsp+0x20], xmm2
0000713aae5d5964  vmovaps [rsp+0x30], xmm3
0000713aae5d596a  vmovaps [rsp+0x40], xmm4
0000713aae5d5970  vmovaps [rsp+0x50], xmm5
0000713aae5d5976  vmovaps [rsp+0x60], xmm6
0000713aae5d597c  vmovaps [rsp+0x70], xmm7
0000713aae5d5982  vmovaps [rsp+0x80], xmm8
0000713aae5d598b  vmovaps [rsp+0x90], xmm9
0000713aae5d5994  vmovaps [rsp+0xA0], xmm10
0000713aae5d599d  vmovaps [rsp+0xB0], xmm11
0000713aae5d59a6  vmovaps [rsp+0xC0], xmm12
0000713aae5d59af  vmovaps [rsp+0xD0], xmm14
0000713aae5d59b8  vmovaps [rsp+0xE0], xmm15
0000713aae5d59c1  sub rsp, 0x40
0000713aae5d59c5  lea rdi, [rsp]
0000713aae5d59c9  lea rsi, [rsp+0x10]
0000713aae5d59ce  lea rdx, [rsp+0x20]
0000713aae5d59d3  lea rcx, [rsp+0x30]
0000713aae5d59d8  mov r8d, 0x00
0000713aae5d59de  lea r9, [r15+0x3A8]
0000713aae5d59e5  movaps [rdi], xmm13
0000713aae5d59e9  movaps [rsi], xmm12
0000713aae5d59ed  movaps [rdx], xmm15
0000713aae5d59f1  movaps [rcx], xmm14
0000713aae5d59f5  mov rax, 0x5E9381C89A50
0000713aae5d59ff  call rax
0000713aae5d5a01  movaps xmm13, [rsp]
0000713aae5d5a06  add rsp, 0x40
0000713aae5d5a0a  vmovaps xmm0, [rsp]
0000713aae5d5a0f  vmovaps xmm1, [rsp+0x10]
0000713aae5d5a15  vmovaps xmm2, [rsp+0x20]
0000713aae5d5a1b  vmovaps xmm3, [rsp+0x30]
0000713aae5d5a21  vmovaps xmm4, [rsp+0x40]
0000713aae5d5a27  vmovaps xmm5, [rsp+0x50]
0000713aae5d5a2d  vmovaps xmm6, [rsp+0x60]
0000713aae5d5a33  vmovaps xmm7, [rsp+0x70]
0000713aae5d5a39  vmovaps xmm8, [rsp+0x80]
0000713aae5d5a42  vmovaps xmm9, [rsp+0x90]
0000713aae5d5a4b  vmovaps xmm10, [rsp+0xA0]
0000713aae5d5a54  vmovaps xmm11, [rsp+0xB0]
0000713aae5d5a5d  vmovaps xmm12, [rsp+0xC0]
0000713aae5d5a66  vmovaps xmm14, [rsp+0xD0]
0000713aae5d5a6f  vmovaps xmm15, [rsp+0xE0]
0000713aae5d5a78  add rsp, 0xF0
0000713aae5d5a7f  pop r11
0000713aae5d5a81  pop r10
0000713aae5d5a83  pop r9
0000713aae5d5a85  pop r8
0000713aae5d5a87  pop rsi
0000713aae5d5a88  pop rdi
0000713aae5d5a89  pop rdx
0000713aae5d5a8a  pop rcx
0000713aae5d5a8b  pop rax
0000713aae5d5a8c  add rsp, 0x08
0000713aae5d5a90  jmp 0x0000713AAE5D30CF
0000713aae5d5a95  call 0x0000713AAE40E760
0000713aae5d5a9a  jmp 0x0000713AAE5D30DC
0000713aae5d5a9f  call 0x0000713AAE40D4E0
0000713aae5d5aa4  jmp 0x0000713AAE5D30E9
0000713aae5d5aa9  sub rsp, 0x08
0000713aae5d5aad  push rax
0000713aae5d5aae  push rcx
0000713aae5d5aaf  push rdx
0000713aae5d5ab0  push rdi
0000713aae5d5ab1  push rsi
0000713aae5d5ab2  push r8
0000713aae5d5ab4  push r9
0000713aae5d5ab6  push r10
0000713aae5d5ab8  push r11
0000713aae5d5aba  sub rsp, 0xF0
0000713aae5d5ac1  vmovaps [rsp], xmm0
0000713aae5d5ac6  vmovaps [rsp+0x10], xmm1
0000713aae5d5acc  vmovaps [rsp+0x20], xmm2
0000713aae5d5ad2  vmovaps [rsp+0x30], xmm3
0000713aae5d5ad8  vmovaps [rsp+0x40], xmm4
0000713aae5d5ade  vmovaps [rsp+0x50], xmm5
0000713aae5d5ae4  vmovaps [rsp+0x60], xmm6
0000713aae5d5aea  vmovaps [rsp+0x70], xmm7
0000713aae5d5af0  vmovaps [rsp+0x80], xmm8
0000713aae5d5af9  vmovaps [rsp+0x90], xmm9
0000713aae5d5b02  vmovaps [rsp+0xA0], xmm10
0000713aae5d5b0b  vmovaps [rsp+0xB0], xmm12
0000713aae5d5b14  vmovaps [rsp+0xC0], xmm13
0000713aae5d5b1d  vmovaps [rsp+0xD0], xmm14
0000713aae5d5b26  vmovaps [rsp+0xE0], xmm15
0000713aae5d5b2f  sub rsp, 0x40
0000713aae5d5b33  lea rdi, [rsp]
0000713aae5d5b37  lea rsi, [rsp+0x10]
0000713aae5d5b3c  lea rdx, [rsp+0x20]
0000713aae5d5b41  lea rcx, [rsp+0x30]
0000713aae5d5b46  mov r8d, 0x00
0000713aae5d5b4c  lea r9, [r15+0x3A8]
0000713aae5d5b53  movaps [rdi], xmm11
0000713aae5d5b57  movaps [rsi], xmm7
0000713aae5d5b5a  movaps [rdx], xmm1
0000713aae5d5b5d  movaps [rcx], xmm12
0000713aae5d5b61  mov rax, 0x5E9381C89A50
0000713aae5d5b6b  call rax
0000713aae5d5b6d  movaps xmm11, [rsp]
0000713aae5d5b72  add rsp, 0x40
0000713aae5d5b76  vmovaps xmm0, [rsp]
0000713aae5d5b7b  vmovaps xmm1, [rsp+0x10]
0000713aae5d5b81  vmovaps xmm2, [rsp+0x20]
0000713aae5d5b87  vmovaps xmm3, [rsp+0x30]
0000713aae5d5b8d  vmovaps xmm4, [rsp+0x40]
0000713aae5d5b93  vmovaps xmm5, [rsp+0x50]
0000713aae5d5b99  vmovaps xmm6, [rsp+0x60]
0000713aae5d5b9f  vmovaps xmm7, [rsp+0x70]
0000713aae5d5ba5  vmovaps xmm8, [rsp+0x80]
0000713aae5d5bae  vmovaps xmm9, [rsp+0x90]
0000713aae5d5bb7  vmovaps xmm10, [rsp+0xA0]
0000713aae5d5bc0  vmovaps xmm12, [rsp+0xB0]
0000713aae5d5bc9  vmovaps xmm13, [rsp+0xC0]
0000713aae5d5bd2  vmovaps xmm14, [rsp+0xD0]
0000713aae5d5bdb  vmovaps xmm15, [rsp+0xE0]
0000713aae5d5be4  add rsp, 0xF0
0000713aae5d5beb  pop r11
0000713aae5d5bed  pop r10
0000713aae5d5bef  pop r9
0000713aae5d5bf1  pop r8
0000713aae5d5bf3  pop rsi
0000713aae5d5bf4  pop rdi
0000713aae5d5bf5  pop rdx
0000713aae5d5bf6  pop rcx
0000713aae5d5bf7  pop rax
0000713aae5d5bf8  add rsp, 0x08
0000713aae5d5bfc  jmp 0x0000713AAE5D3122
0000713aae5d5c01  call 0x0000713AAE3FF430
0000713aae5d5c06  jmp 0x0000713AAE5D3134
0000713aae5d5c0b  sub rsp, 0x08
0000713aae5d5c0f  push rax
0000713aae5d5c10  push rcx
0000713aae5d5c11  push rdx
0000713aae5d5c12  push rdi
0000713aae5d5c13  push rsi
0000713aae5d5c14  push r8
0000713aae5d5c16  push r9
0000713aae5d5c18  push r10
0000713aae5d5c1a  push r11
0000713aae5d5c1c  sub rsp, 0xF0
0000713aae5d5c23  vmovaps [rsp], xmm0
0000713aae5d5c28  vmovaps [rsp+0x10], xmm1
0000713aae5d5c2e  vmovaps [rsp+0x20], xmm2
0000713aae5d5c34  vmovaps [rsp+0x30], xmm3
0000713aae5d5c3a  vmovaps [rsp+0x40], xmm4
0000713aae5d5c40  vmovaps [rsp+0x50], xmm5
0000713aae5d5c46  vmovaps [rsp+0x60], xmm6
0000713aae5d5c4c  vmovaps [rsp+0x70], xmm7
0000713aae5d5c52  vmovaps [rsp+0x80], xmm8
0000713aae5d5c5b  vmovaps [rsp+0x90], xmm10
0000713aae5d5c64  vmovaps [rsp+0xA0], xmm11
0000713aae5d5c6d  vmovaps [rsp+0xB0], xmm12
0000713aae5d5c76  vmovaps [rsp+0xC0], xmm13
0000713aae5d5c7f  vmovaps [rsp+0xD0], xmm14
0000713aae5d5c88  vmovaps [rsp+0xE0], xmm15
0000713aae5d5c91  sub rsp, 0x40
0000713aae5d5c95  lea rdi, [rsp]
0000713aae5d5c99  lea rsi, [rsp+0x10]
0000713aae5d5c9e  lea rdx, [rsp+0x20]
0000713aae5d5ca3  lea rcx, [rsp+0x30]
0000713aae5d5ca8  mov r8d, 0x00
0000713aae5d5cae  lea r9, [r15+0x3A8]
0000713aae5d5cb5  movaps [rdi], xmm9
0000713aae5d5cb9  movaps [rsi], xmm8
0000713aae5d5cbd  movaps [rdx], xmm14
0000713aae5d5cc1  movaps [rcx], xmm12
0000713aae5d5cc5  mov rax, 0x5E9381C89A50
0000713aae5d5ccf  call rax
0000713aae5d5cd1  movaps xmm9, [rsp]
0000713aae5d5cd6  add rsp, 0x40
0000713aae5d5cda  vmovaps xmm0, [rsp]
0000713aae5d5cdf  vmovaps xmm1, [rsp+0x10]
0000713aae5d5ce5  vmovaps xmm2, [rsp+0x20]
0000713aae5d5ceb  vmovaps xmm3, [rsp+0x30]
0000713aae5d5cf1  vmovaps xmm4, [rsp+0x40]
0000713aae5d5cf7  vmovaps xmm5, [rsp+0x50]
0000713aae5d5cfd  vmovaps xmm6, [rsp+0x60]
0000713aae5d5d03  vmovaps xmm7, [rsp+0x70]
0000713aae5d5d09  vmovaps xmm8, [rsp+0x80]
0000713aae5d5d12  vmovaps xmm10, [rsp+0x90]
0000713aae5d5d1b  vmovaps xmm11, [rsp+0xA0]
0000713aae5d5d24  vmovaps xmm12, [rsp+0xB0]
0000713aae5d5d2d  vmovaps xmm13, [rsp+0xC0]
0000713aae5d5d36  vmovaps xmm14, [rsp+0xD0]
0000713aae5d5d3f  vmovaps xmm15, [rsp+0xE0]
0000713aae5d5d48  add rsp, 0xF0
0000713aae5d5d4f  pop r11
0000713aae5d5d51  pop r10
0000713aae5d5d53  pop r9
0000713aae5d5d55  pop r8
0000713aae5d5d57  pop rsi
0000713aae5d5d58  pop rdi
0000713aae5d5d59  pop rdx
0000713aae5d5d5a  pop rcx
0000713aae5d5d5b  pop rax
0000713aae5d5d5c  add rsp, 0x08
0000713aae5d5d60  jmp 0x0000713AAE5D3165
0000713aae5d5d65  sub rsp, 0x08
0000713aae5d5d69  push rax
0000713aae5d5d6a  push rcx
0000713aae5d5d6b  push rdx
0000713aae5d5d6c  push rdi
0000713aae5d5d6d  push rsi
0000713aae5d5d6e  push r8
0000713aae5d5d70  push r9
0000713aae5d5d72  push r10
0000713aae5d5d74  push r11
0000713aae5d5d76  sub rsp, 0xF0
0000713aae5d5d7d  vmovaps [rsp], xmm0
0000713aae5d5d82  vmovaps [rsp+0x10], xmm1
0000713aae5d5d88  vmovaps [rsp+0x20], xmm2
0000713aae5d5d8e  vmovaps [rsp+0x30], xmm3
0000713aae5d5d94  vmovaps [rsp+0x40], xmm4
0000713aae5d5d9a  vmovaps [rsp+0x50], xmm5
0000713aae5d5da0  vmovaps [rsp+0x60], xmm6
0000713aae5d5da6  vmovaps [rsp+0x70], xmm7
0000713aae5d5dac  vmovaps [rsp+0x80], xmm8
0000713aae5d5db5  vmovaps [rsp+0x90], xmm9
0000713aae5d5dbe  vmovaps [rsp+0xA0], xmm10
0000713aae5d5dc7  vmovaps [rsp+0xB0], xmm11
0000713aae5d5dd0  vmovaps [rsp+0xC0], xmm13
0000713aae5d5dd9  vmovaps [rsp+0xD0], xmm14
0000713aae5d5de2  vmovaps [rsp+0xE0], xmm15
0000713aae5d5deb  sub rsp, 0x40
0000713aae5d5def  lea rdi, [rsp]
0000713aae5d5df3  lea rsi, [rsp+0x10]
0000713aae5d5df8  lea rdx, [rsp+0x20]
0000713aae5d5dfd  lea rcx, [rsp+0x30]
0000713aae5d5e02  mov r8d, 0x00
0000713aae5d5e08  lea r9, [r15+0x3A8]
0000713aae5d5e0f  movaps [rdi], xmm12
0000713aae5d5e13  movaps [rsi], xmm10
0000713aae5d5e17  movaps [rdx], xmm15
0000713aae5d5e1b  movaps [rcx], xmm14
0000713aae5d5e1f  mov rax, 0x5E9381C89A50
0000713aae5d5e29  call rax
0000713aae5d5e2b  movaps xmm12, [rsp]
0000713aae5d5e30  add rsp, 0x40
0000713aae5d5e34  vmovaps xmm0, [rsp]
0000713aae5d5e39  vmovaps xmm1, [rsp+0x10]
0000713aae5d5e3f  vmovaps xmm2, [rsp+0x20]
0000713aae5d5e45  vmovaps xmm3, [rsp+0x30]
0000713aae5d5e4b  vmovaps xmm4, [rsp+0x40]
0000713aae5d5e51  vmovaps xmm5, [rsp+0x50]
0000713aae5d5e57  vmovaps xmm6, [rsp+0x60]
0000713aae5d5e5d  vmovaps xmm7, [rsp+0x70]
0000713aae5d5e63  vmovaps xmm8, [rsp+0x80]
0000713aae5d5e6c  vmovaps xmm9, [rsp+0x90]
0000713aae5d5e75  vmovaps xmm10, [rsp+0xA0]
0000713aae5d5e7e  vmovaps xmm11, [rsp+0xB0]
0000713aae5d5e87  vmovaps xmm13, [rsp+0xC0]
0000713aae5d5e90  vmovaps xmm14, [rsp+0xD0]
0000713aae5d5e99  vmovaps xmm15, [rsp+0xE0]
0000713aae5d5ea2  add rsp, 0xF0
0000713aae5d5ea9  pop r11
0000713aae5d5eab  pop r10
0000713aae5d5ead  pop r9
0000713aae5d5eaf  pop r8
0000713aae5d5eb1  pop rsi
0000713aae5d5eb2  pop rdi
0000713aae5d5eb3  pop rdx
0000713aae5d5eb4  pop rcx
0000713aae5d5eb5  pop rax
0000713aae5d5eb6  add rsp, 0x08
0000713aae5d5eba  jmp 0x0000713AAE5D3196
0000713aae5d5ebf  sub rsp, 0x08
0000713aae5d5ec3  push rax
0000713aae5d5ec4  push rcx
0000713aae5d5ec5  push rdx
0000713aae5d5ec6  push rdi
0000713aae5d5ec7  push rsi
0000713aae5d5ec8  push r8
0000713aae5d5eca  push r9
0000713aae5d5ecc  push r10
0000713aae5d5ece  push r11
0000713aae5d5ed0  sub rsp, 0xF0
0000713aae5d5ed7  vmovaps [rsp], xmm0
0000713aae5d5edc  vmovaps [rsp+0x10], xmm1
0000713aae5d5ee2  vmovaps [rsp+0x20], xmm2
0000713aae5d5ee8  vmovaps [rsp+0x30], xmm3
0000713aae5d5eee  vmovaps [rsp+0x40], xmm4
0000713aae5d5ef4  vmovaps [rsp+0x50], xmm5
0000713aae5d5efa  vmovaps [rsp+0x60], xmm6
0000713aae5d5f00  vmovaps [rsp+0x70], xmm7
0000713aae5d5f06  vmovaps [rsp+0x80], xmm8
0000713aae5d5f0f  vmovaps [rsp+0x90], xmm9
0000713aae5d5f18  vmovaps [rsp+0xA0], xmm10
0000713aae5d5f21  vmovaps [rsp+0xB0], xmm11
0000713aae5d5f2a  vmovaps [rsp+0xC0], xmm12
0000713aae5d5f33  vmovaps [rsp+0xD0], xmm13
0000713aae5d5f3c  vmovaps [rsp+0xE0], xmm15
0000713aae5d5f45  sub rsp, 0x40
0000713aae5d5f49  lea rdi, [rsp]
0000713aae5d5f4d  lea rsi, [rsp+0x10]
0000713aae5d5f52  lea rdx, [rsp+0x20]
0000713aae5d5f57  lea rcx, [rsp+0x30]
0000713aae5d5f5c  mov r8d, 0x00
0000713aae5d5f62  lea r9, [r15+0x3A8]
0000713aae5d5f69  movaps [rdi], xmm14
0000713aae5d5f6d  movaps [rsi], xmm13
0000713aae5d5f71  movaps [rdx], xmm1
0000713aae5d5f74  movaps [rcx], xmm15
0000713aae5d5f78  mov rax, 0x5E9381C89A50
0000713aae5d5f82  call rax
0000713aae5d5f84  movaps xmm14, [rsp]
0000713aae5d5f89  add rsp, 0x40
0000713aae5d5f8d  vmovaps xmm0, [rsp]
0000713aae5d5f92  vmovaps xmm1, [rsp+0x10]
0000713aae5d5f98  vmovaps xmm2, [rsp+0x20]
0000713aae5d5f9e  vmovaps xmm3, [rsp+0x30]
0000713aae5d5fa4  vmovaps xmm4, [rsp+0x40]
0000713aae5d5faa  vmovaps xmm5, [rsp+0x50]
0000713aae5d5fb0  vmovaps xmm6, [rsp+0x60]
0000713aae5d5fb6  vmovaps xmm7, [rsp+0x70]
0000713aae5d5fbc  vmovaps xmm8, [rsp+0x80]
0000713aae5d5fc5  vmovaps xmm9, [rsp+0x90]
0000713aae5d5fce  vmovaps xmm10, [rsp+0xA0]
0000713aae5d5fd7  vmovaps xmm11, [rsp+0xB0]
0000713aae5d5fe0  vmovaps xmm12, [rsp+0xC0]
0000713aae5d5fe9  vmovaps xmm13, [rsp+0xD0]
0000713aae5d5ff2  vmovaps xmm15, [rsp+0xE0]
0000713aae5d5ffb  add rsp, 0xF0
0000713aae5d6002  pop r11
0000713aae5d6004  pop r10
0000713aae5d6006  pop r9
0000713aae5d6008  pop r8
0000713aae5d600a  pop rsi
0000713aae5d600b  pop rdi
0000713aae5d600c  pop rdx
0000713aae5d600d  pop rcx
0000713aae5d600e  pop rax
0000713aae5d600f  add rsp, 0x08
0000713aae5d6013  jmp 0x0000713AAE5D31C7
0000713aae5d6018  call 0x0000713AAE4079B0
0000713aae5d601d  jmp 0x0000713AAE5D31DA
0000713aae5d6022  call 0x0000713AAE40B100
0000713aae5d6027  jmp 0x0000713AAE5D31E5
0000713aae5d602c  call 0x0000713AAE409E90
0000713aae5d6031  jmp 0x0000713AAE5D31F0
0000713aae5d6036  call 0x0000713AAE40D600
0000713aae5d603b  jmp 0x0000713AAE5D31FB
0000713aae5d6040  int3
0000713aae5d6041  nop [rax+rax*1], ax
0000713aae5d604a  nop [rax+rax*1], ax
0000713aae5d6050  mov rax, [r15+0x40]
0000713aae5d6054  mov r14, [r15+0x58]
0000713aae5d6058  lea r12, [rax+r14*1]
0000713aae5d605c  vxorps xmm1, xmm1, xmm1
0000713aae5d6060  vpbroadcastq xmm1, xmm1
0000713aae5d6065  vxorps xmm15, xmm15, xmm15
0000713aae5d606a  vpbroadcastq xmm15, xmm15
0000713aae5d606f  lea rax, [r12+0x30]
0000713aae5d6074  mov r11, [r13+rax*1]
0000713aae5d6079  lea rax, [r12+0x38]
0000713aae5d607e  mov r10, [r13+rax*1]
0000713aae5d6083  movq xmm14, r11
0000713aae5d6088  movq xmm13, r10
0000713aae5d608d  movq xmm14, xmm14
0000713aae5d6092  movq xmm13, xmm13
0000713aae5d6097  vmovaps [rsp+0x10], xmm13
0000713aae5d609d  movq xmm13, xmm13
0000713aae5d60a2  movaps [r15+0x270], xmm13
0000713aae5d60aa  movaps xmm13, [r15+0x160]
0000713aae5d60b2  vmovaps [rsp+0x20], xmm13
0000713aae5d60b8  vmovaps xmm12, [rsp+0x20]
0000713aae5d60be  por xmm13, xmm12
0000713aae5d60c3  lea rax, [r12+0x20]
0000713aae5d60c8  mov r11, [r13+rax*1]
0000713aae5d60cd  lea rax, [r12+0x28]
0000713aae5d60d2  mov r10, [r13+rax*1]
0000713aae5d60d7  movq xmm12, r11
0000713aae5d60dc  movq xmm11, r10
0000713aae5d60e1  movq xmm12, xmm12
0000713aae5d60e6  movq xmm11, xmm11
0000713aae5d60eb  movaps xmm10, [r15+0x2D0]
0000713aae5d60f3  vmovaps [rsp+0x20], xmm10
0000713aae5d60f9  vmovaps xmm9, [rsp+0x20]
0000713aae5d60ff  por xmm10, xmm9
0000713aae5d6104  movaps xmm9, [r15+0x300]
0000713aae5d610c  vmovaps [rsp+0x20], xmm9
0000713aae5d6112  vmovaps xmm8, [rsp+0x20]
0000713aae5d6118  por xmm9, xmm8
0000713aae5d611d  movaps xmm8, [r15+0x2B0]
0000713aae5d6125  vmovaps [rsp+0x20], xmm8
0000713aae5d612b  vmovaps xmm7, [rsp+0x20]
0000713aae5d6131  por xmm8, xmm7
0000713aae5d6136  movaps xmm7, [r15+0x180]
0000713aae5d613e  vmovaps [rsp+0x20], xmm7
0000713aae5d6144  vmovaps xmm6, [rsp+0x20]
0000713aae5d614a  por xmm7, xmm6
0000713aae5d614e  lea rax, [r12+0x10]
0000713aae5d6153  mov r11, [r13+rax*1]
0000713aae5d6158  lea rax, [r12+0x18]
0000713aae5d615d  mov r10, [r13+rax*1]
0000713aae5d6162  movq xmm6, r11
0000713aae5d6167  movq xmm5, r10
0000713aae5d616c  movq xmm6, xmm6
0000713aae5d6170  movq xmm5, xmm5
0000713aae5d6174  movaps xmm4, [r15+0x200]
0000713aae5d617c  vmovaps [rsp+0x20], xmm4
0000713aae5d6182  vmovaps xmm3, [rsp+0x20]
0000713aae5d6188  por xmm4, xmm3
0000713aae5d618c  movaps xmm3, [r15+0x1F0]
0000713aae5d6194  vmovaps [rsp+0x20], xmm3
0000713aae5d619a  vmovaps xmm2, [rsp+0x20]
0000713aae5d61a0  por xmm3, xmm2
0000713aae5d61a4  movaps xmm2, [r15+0x2E0]
0000713aae5d61ac  vmovaps [rsp+0x20], xmm2
0000713aae5d61b2  vmovaps [rsp+0x30], xmm1
0000713aae5d61b8  vmovaps xmm1, [rsp+0x20]
0000713aae5d61be  por xmm2, xmm1
0000713aae5d61c2  movaps xmm1, [r15+0x2A0]
0000713aae5d61ca  vmovaps [rsp+0x20], xmm1
0000713aae5d61d0  vmovaps [rsp+0x40], xmm15
0000713aae5d61d6  vmovaps xmm15, [rsp+0x20]
0000713aae5d61dc  por xmm1, xmm15
0000713aae5d61e1  movaps xmm15, [r15+0x280]
0000713aae5d61e9  vmovaps [rsp+0x20], xmm15
0000713aae5d61ef  vmovaps [rsp+0x50], xmm1
0000713aae5d61f5  vmovaps xmm1, [rsp+0x20]
0000713aae5d61fb  por xmm15, xmm1
0000713aae5d6200  movaps xmm1, [r15+0x1C0]
0000713aae5d6208  vmovaps [rsp+0x20], xmm1
0000713aae5d620e  vmovaps [rsp+0x60], xmm15
0000713aae5d6214  vmovaps xmm15, [rsp+0x20]
0000713aae5d621a  por xmm1, xmm15
0000713aae5d621f  movaps xmm15, [r15+0x210]
0000713aae5d6227  vmovaps [rsp+0x20], xmm15
0000713aae5d622d  vmovaps [rsp+0x70], xmm1
0000713aae5d6233  vmovaps xmm1, [rsp+0x20]
0000713aae5d6239  por xmm15, xmm1
0000713aae5d623e  mov rax, [r13+r12*1]
0000713aae5d6243  vmovq xmm1, rax
0000713aae5d6248  vpbroadcastq xmm1, xmm1
0000713aae5d624d  vmovaps [rsp+0x20], xmm1
0000713aae5d6253  vxorps xmm1, xmm1, xmm1
0000713aae5d6257  vpbroadcastq xmm1, xmm1
0000713aae5d625c  mov rax, [r15+0xF8]
0000713aae5d6263  vmovaps [rsp+0x80], xmm1
0000713aae5d626c  movups xmm1, [r13+rax*1]
0000713aae5d6272  vmovaps [rsp+0x90], xmm1
0000713aae5d627b  vxorps xmm1, xmm1, xmm1
0000713aae5d627f  vpbroadcastq xmm1, xmm1
0000713aae5d6284  lea r11, [r12+0x08]
0000713aae5d6289  mov r12, [r13+r11*1]
0000713aae5d628e  vmovaps [rsp+0xA0], xmm1
0000713aae5d6297  movq xmm1, r12
0000713aae5d629c  movaps [r15+0x240], xmm1
0000713aae5d62a4  mov r12, [r15+0x50]
0000713aae5d62a8  lea r11, [r12+r14*1]
0000713aae5d62ac  mov [r15+0x60], r11
0000713aae5d62b0  lea r12, [r14+0x40]
0000713aae5d62b4  mov [r15+0x58], r12
0000713aae5d62b8  vmovaps xmm1, [rsp+0x30]
0000713aae5d62be  vmovaps [rsp+0x30], xmm15
0000713aae5d62c4  vmovaps xmm15, [rsp+0x90]
0000713aae5d62cd  vmovaps [rsp+0x90], xmm14
0000713aae5d62d6  vmovaps xmm14, [rsp+0x20]
0000713aae5d62dc  vmovaps [rsp+0x20], xmm13
0000713aae5d62e2  vmovaps [rsp+0xB0], xmm12
0000713aae5d62eb  movaps xmm13, xmm1
0000713aae5d62ef  vfmadd231pd xmm13, xmm15, xmm14
0000713aae5d62f4  vcmppd xmm12, xmm13, xmm13, 0x03
0000713aae5d62fa  vptest xmm12, xmm12
0000713aae5d62ff  jnz 0x0000713AAE5D6D9C
0000713aae5d6305  movaps xmm1, [r15+0x250]
0000713aae5d630d  vmovaps xmm15, [rsp+0x40]
0000713aae5d6313  vmovaps [rsp+0x40], xmm13
0000713aae5d6319  movaps xmm12, xmm15
0000713aae5d631d  vfmadd231pd xmm12, xmm1, xmm14
0000713aae5d6322  vcmppd xmm13, xmm12, xmm12, 0x03
0000713aae5d6328  vptest xmm13, xmm13
0000713aae5d632d  jnz 0x0000713AAE5D6EF5
0000713aae5d6333  movaps xmm15, [r15+0x1E0]
0000713aae5d633b  vmovaps [rsp+0xC0], xmm15
0000713aae5d6344  vmovaps xmm13, [rsp+0xC0]
0000713aae5d634d  por xmm15, xmm13
0000713aae5d6352  movaps xmm13, [r15+0x1D0]
0000713aae5d635a  vmovaps [rsp+0xC0], xmm13
0000713aae5d6363  vmovaps [rsp+0xD0], xmm1
0000713aae5d636c  vmovaps xmm1, [rsp+0xC0]
0000713aae5d6375  por xmm13, xmm1
0000713aae5d637a  movaps xmm1, [r15+0x2C0]
0000713aae5d6382  vmovaps [rsp+0xC0], xmm1
0000713aae5d638b  vmovaps [rsp+0xE0], xmm15
0000713aae5d6394  vmovaps xmm15, [rsp+0xC0]
0000713aae5d639d  por xmm1, xmm15
0000713aae5d63a2  movaps xmm15, [r15+0x290]
0000713aae5d63aa  vmovaps [rsp+0xC0], xmm15
0000713aae5d63b3  vmovaps [rsp+0xF0], xmm1
0000713aae5d63bc  vmovaps xmm1, [rsp+0xC0]
0000713aae5d63c5  por xmm15, xmm1
0000713aae5d63ca  movaps xmm1, [r15+0x260]
0000713aae5d63d2  vmovaps [rsp+0xC0], xmm1
0000713aae5d63db  vmovaps [rsp+0x100], xmm15
0000713aae5d63e4  vmovaps xmm15, [rsp+0xC0]
0000713aae5d63ed  por xmm1, xmm15
0000713aae5d63f2  vmovaps xmm15, [rsp+0xD0]
0000713aae5d63fb  vmovaps [rsp+0xC0], xmm1
0000713aae5d6404  vmovaps xmm1, [rsp+0xD0]
0000713aae5d640d  por xmm15, xmm1
0000713aae5d6412  lea r14, [rax+0xC0]
0000713aae5d6419  movups xmm1, [r13+r14*1]
0000713aae5d641f  mov [rsp+0xD0], rax
0000713aae5d6427  xor eax, eax
0000713aae5d6429  mov r14d, 0x200
0000713aae5d642f  cmp r12, r14
0000713aae5d6432  cmc
0000713aae5d6433  lahf
0000713aae5d6434  seto al
0000713aae5d6437  mov [r15+0x108], eax
0000713aae5d643e  vmovaps [rsp+0x110], xmm1
0000713aae5d6447  vmovaps xmm1, [rsp+0x80]
0000713aae5d6450  vmovaps [rsp+0x80], xmm15
0000713aae5d6459  vmovaps xmm15, [rsp+0x110]
0000713aae5d6462  vmovaps [rsp+0x110], xmm13
0000713aae5d646b  vmovaps [rsp+0x120], xmm12
0000713aae5d6474  movaps xmm13, xmm1
0000713aae5d6478  vfmadd231pd xmm13, xmm15, xmm14
0000713aae5d647d  vcmppd xmm12, xmm13, xmm13, 0x03
0000713aae5d6483  vptest xmm12, xmm12
0000713aae5d6488  jnz 0x0000713AAE5D7058
0000713aae5d648e  mov rax, [rsp+0xD0]
0000713aae5d6496  lea r14, [rax+0xB0]
0000713aae5d649d  movups xmm1, [r13+r14*1]
0000713aae5d64a3  vmovaps xmm15, [rsp+0xA0]
0000713aae5d64ac  vmovaps [rsp+0xA0], xmm13
0000713aae5d64b5  movaps xmm12, xmm15
0000713aae5d64b9  vfmadd231pd xmm12, xmm1, xmm14
0000713aae5d64be  vcmppd xmm13, xmm12, xmm12, 0x03
0000713aae5d64c4  vptest xmm13, xmm13
0000713aae5d64c9  jnz 0x0000713AAE5D71BB
0000713aae5d64cf  vmovaps xmm1, [rsp+0x30]
0000713aae5d64d5  vmovaps xmm15, [rsp+0x30]
0000713aae5d64db  por xmm1, xmm15
0000713aae5d64e0  movaps [r15+0x210], xmm1
0000713aae5d64e8  vmovaps xmm15, [rsp+0x70]
0000713aae5d64ee  vmovaps xmm14, [rsp+0x70]
0000713aae5d64f4  por xmm15, xmm14
0000713aae5d64f9  movaps [r15+0x1C0], xmm15
0000713aae5d6501  vmovaps xmm14, [rsp+0x60]
0000713aae5d6507  vmovaps xmm13, [rsp+0x60]
0000713aae5d650d  por xmm14, xmm13
0000713aae5d6512  movaps [r15+0x280], xmm14
0000713aae5d651a  vmovaps xmm13, [rsp+0x50]
0000713aae5d6520  vmovaps [rsp+0x30], xmm1
0000713aae5d6526  vmovaps xmm1, [rsp+0x50]
0000713aae5d652c  por xmm13, xmm1
0000713aae5d6531  movaps [r15+0x2A0], xmm13
0000713aae5d6539  vmovaps [rsp+0x50], xmm2
0000713aae5d653f  vmovaps xmm1, [rsp+0x50]
0000713aae5d6545  por xmm2, xmm1
0000713aae5d6549  movaps [r15+0x2E0], xmm2
0000713aae5d6551  vmovaps [rsp+0x50], xmm3
0000713aae5d6557  vmovaps xmm1, [rsp+0x50]
0000713aae5d655d  por xmm3, xmm1
0000713aae5d6561  movaps [r15+0x1F0], xmm3
0000713aae5d6569  vmovaps xmm1, [rsp+0x80]
0000713aae5d6572  vmovaps [rsp+0x50], xmm15
0000713aae5d6578  vmovaps xmm15, [rsp+0x80]
0000713aae5d6581  por xmm1, xmm15
0000713aae5d6586  movaps [r15+0x250], xmm1
0000713aae5d658e  vmovaps xmm1, [rsp+0xC0]
0000713aae5d6597  vmovaps xmm15, [rsp+0xC0]
0000713aae5d65a0  por xmm1, xmm15
0000713aae5d65a5  movaps [r15+0x260], xmm1
0000713aae5d65ad  vmovaps xmm15, [rsp+0x100]
0000713aae5d65b6  vmovaps [rsp+0x60], xmm1
0000713aae5d65bc  vmovaps xmm1, [rsp+0x100]
0000713aae5d65c5  por xmm15, xmm1
0000713aae5d65ca  movaps [r15+0x290], xmm15
0000713aae5d65d2  vmovaps xmm1, [rsp+0xF0]
0000713aae5d65db  vmovaps [rsp+0x70], xmm15
0000713aae5d65e1  vmovaps xmm15, [rsp+0xF0]
0000713aae5d65ea  por xmm1, xmm15
0000713aae5d65ef  movaps [r15+0x2C0], xmm1
0000713aae5d65f7  movq xmm15, qword ptr [r15+0x240]
0000713aae5d6600  vmovaps [rsp+0x80], xmm15
0000713aae5d6609  vpermilpd xmm15, xmm15, 0x00
0000713aae5d660f  vmovaps [rsp+0xC0], xmm1
0000713aae5d6618  vmovaps xmm1, [rsp+0x40]
0000713aae5d661e  vmovaps [rsp+0x40], xmm15
0000713aae5d6624  vmovaps xmm15, [rsp+0x30]
0000713aae5d662a  vmovaps [rsp+0x30], xmm14
0000713aae5d6630  vmovaps xmm14, [rsp+0x40]
0000713aae5d6636  vmovaps [rsp+0x40], xmm13
0000713aae5d663c  vmovaps [rsp+0xD0], xmm12
0000713aae5d6645  movaps xmm13, xmm1
0000713aae5d6649  vfmadd231pd xmm13, xmm15, xmm14
0000713aae5d664e  vcmppd xmm12, xmm13, xmm13, 0x03
0000713aae5d6654  vptest xmm12, xmm12
0000713aae5d6659  jnz 0x0000713AAE5D7314
0000713aae5d665f  vmovaps xmm1, [rsp+0x80]
0000713aae5d6668  vpermilpd xmm1, xmm1, 0x00
0000713aae5d666e  vmovaps xmm15, [rsp+0xA0]
0000713aae5d6677  movaps xmm14, xmm15
0000713aae5d667b  vfmadd231pd xmm14, xmm2, xmm1
0000713aae5d6680  vcmppd xmm12, xmm14, xmm14, 0x03
0000713aae5d6686  vptest xmm12, xmm12
0000713aae5d668b  jnz 0x0000713AAE5D746D
0000713aae5d6691  vmovaps xmm1, [rsp+0x80]
0000713aae5d669a  vpermilpd xmm1, xmm1, 0x00
0000713aae5d66a0  vmovaps xmm15, [rsp+0x120]
0000713aae5d66a9  vmovaps xmm12, [rsp+0x50]
0000713aae5d66af  vmovaps [rsp+0x50], xmm14
0000713aae5d66b5  movaps xmm2, xmm15
0000713aae5d66b9  vfmadd231pd xmm2, xmm12, xmm1
0000713aae5d66be  vcmppd xmm14, xmm2, xmm2, 0x03
0000713aae5d66c3  vptest xmm14, xmm14
0000713aae5d66c8  jnz 0x0000713AAE5D75C5
0000713aae5d66ce  vmovaps xmm1, [rsp+0x110]
0000713aae5d66d7  vmovaps xmm15, [rsp+0x110]
0000713aae5d66e0  por xmm1, xmm15
0000713aae5d66e5  movaps [r15+0x1D0], xmm1
0000713aae5d66ed  vmovaps xmm15, [rsp+0x80]
0000713aae5d66f6  vpermilpd xmm15, xmm15, 0x00
0000713aae5d66fc  vmovaps xmm14, [rsp+0xD0]
0000713aae5d6705  vmovaps [rsp+0x80], xmm1
0000713aae5d670e  movaps xmm12, xmm14
0000713aae5d6712  vfmadd231pd xmm12, xmm3, xmm15
0000713aae5d6717  vcmppd xmm1, xmm12, xmm12, 0x03
0000713aae5d671d  vptest xmm1, xmm1
0000713aae5d6722  jnz 0x0000713AAE5D771C
0000713aae5d6728  vmovaps [rsp+0xA0], xmm4
0000713aae5d6731  vmovaps xmm1, [rsp+0xA0]
0000713aae5d673a  por xmm4, xmm1
0000713aae5d673e  movaps [r15+0x200], xmm4
0000713aae5d6746  vmovaps xmm1, [rsp+0xE0]
0000713aae5d674f  vmovaps xmm15, [rsp+0xE0]
0000713aae5d6758  por xmm1, xmm15
0000713aae5d675d  movaps [r15+0x1E0], xmm1
0000713aae5d6765  vmovaps [rsp+0xA0], xmm8
0000713aae5d676e  vmovaps xmm1, [rsp+0xA0]
0000713aae5d6777  por xmm8, xmm1
0000713aae5d677c  movaps [r15+0x2B0], xmm8
0000713aae5d6784  vmovaps [rsp+0xA0], xmm9
0000713aae5d678d  vmovaps xmm1, [rsp+0xA0]
0000713aae5d6796  por xmm9, xmm1
0000713aae5d679b  movaps [r15+0x300], xmm9
0000713aae5d67a3  vmovaps [rsp+0xA0], xmm6
0000713aae5d67ac  vpermilpd xmm6, xmm6, 0x00
0000713aae5d67b2  vmovaps xmm14, [rsp+0x60]
0000713aae5d67b8  movaps xmm9, xmm13
0000713aae5d67bc  vfmadd231pd xmm9, xmm14, xmm6
0000713aae5d67c1  vcmppd xmm3, xmm9, xmm9, 0x03
0000713aae5d67c7  vptest xmm3, xmm3
0000713aae5d67cc  jnz 0x0000713AAE5D7875
0000713aae5d67d2  vmovaps xmm14, [rsp+0xA0]
0000713aae5d67db  vpermilpd xmm14, xmm14, 0x00
0000713aae5d67e1  vmovaps xmm13, [rsp+0x50]
0000713aae5d67e7  vmovaps xmm6, [rsp+0xC0]
0000713aae5d67f0  vmovaps [rsp+0x50], xmm1
0000713aae5d67f6  movaps xmm3, xmm13
0000713aae5d67fa  vfmadd231pd xmm3, xmm6, xmm14
0000713aae5d67ff  vcmppd xmm1, xmm3, xmm3, 0x03
0000713aae5d6804  vptest xmm1, xmm1
0000713aae5d6809  jnz 0x0000713AAE5D79CE
0000713aae5d680f  vmovaps xmm1, [rsp+0xA0]
0000713aae5d6818  vpermilpd xmm1, xmm1, 0x00
0000713aae5d681e  vmovaps xmm14, [rsp+0x30]
0000713aae5d6824  movaps xmm6, xmm2
0000713aae5d6827  vfmadd231pd xmm6, xmm14, xmm1
0000713aae5d682c  vcmppd xmm13, xmm6, xmm6, 0x03
0000713aae5d6831  vptest xmm13, xmm13
0000713aae5d6836  jnz 0x0000713AAE5D7B25
0000713aae5d683c  vmovaps xmm1, [rsp+0xA0]
0000713aae5d6845  vpermilpd xmm1, xmm1, 0x00
0000713aae5d684b  vmovaps xmm14, [rsp+0x80]
0000713aae5d6854  movaps xmm13, xmm12
0000713aae5d6858  vfmadd231pd xmm13, xmm14, xmm1
0000713aae5d685d  vcmppd xmm2, xmm13, xmm13, 0x03
0000713aae5d6863  vptest xmm2, xmm2
0000713aae5d6868  jnz 0x0000713AAE5D7C7B
0000713aae5d686e  vmovaps [rsp+0x30], xmm7
0000713aae5d6874  vmovaps xmm1, [rsp+0x30]
0000713aae5d687a  por xmm7, xmm1
0000713aae5d687e  movaps [r15+0x180], xmm7
0000713aae5d6886  vmovaps [rsp+0x30], xmm10
0000713aae5d688c  vmovaps xmm1, [rsp+0x30]
0000713aae5d6892  por xmm10, xmm1
0000713aae5d6897  movaps [r15+0x2D0], xmm10
0000713aae5d689f  vmovaps [rsp+0x30], xmm5
0000713aae5d68a5  vpermilpd xmm5, xmm5, 0x00
0000713aae5d68ab  vmovaps xmm14, [rsp+0x50]
0000713aae5d68b1  movaps xmm12, xmm3
0000713aae5d68b5  vfmadd231pd xmm12, xmm14, xmm5
0000713aae5d68ba  vcmppd xmm10, xmm12, xmm12, 0x03
0000713aae5d68c0  vptest xmm10, xmm10
0000713aae5d68c5  jnz 0x0000713AAE5D7DD4
0000713aae5d68cb  vmovaps xmm14, [rsp+0x30]
0000713aae5d68d1  vpermilpd xmm14, xmm14, 0x00
0000713aae5d68d7  movaps xmm10, xmm9
0000713aae5d68db  vfmadd231pd xmm10, xmm7, xmm14
0000713aae5d68e0  vcmppd xmm5, xmm10, xmm10, 0x03
0000713aae5d68e6  vptest xmm5, xmm5
0000713aae5d68eb  jnz 0x0000713AAE5D7F2C
0000713aae5d68f1  lea r14, [rax+0x80]
0000713aae5d68f8  movups xmm14, [r13+r14*1]
0000713aae5d68fe  movaps [r15+0x2F0], xmm14
0000713aae5d6906  vmovaps xmm9, [rsp+0x30]
0000713aae5d690c  vpermilpd xmm9, xmm9, 0x00
0000713aae5d6912  vmovaps xmm7, [rsp+0x70]
0000713aae5d6918  movaps xmm5, xmm6
0000713aae5d691b  vfmadd231pd xmm5, xmm7, xmm9
0000713aae5d6920  vcmppd xmm3, xmm5, xmm5, 0x03
0000713aae5d6925  vptest xmm3, xmm3
0000713aae5d692a  jnz 0x0000713AAE5D808F
0000713aae5d6930  vmovaps xmm9, [rsp+0x30]
0000713aae5d6936  vpermilpd xmm9, xmm9, 0x00
0000713aae5d693c  movaps xmm7, xmm13
0000713aae5d6940  vfmadd231pd xmm7, xmm1, xmm9
0000713aae5d6945  vcmppd xmm6, xmm7, xmm7, 0x03
0000713aae5d694a  vptest xmm6, xmm6
0000713aae5d694f  jnz 0x0000713AAE5D81E5
0000713aae5d6955  vmovaps xmm1, [rsp+0x20]
0000713aae5d695b  vmovaps xmm13, [rsp+0x20]
0000713aae5d6961  por xmm1, xmm13
0000713aae5d6966  movaps [r15+0x160], xmm1
0000713aae5d696e  lea r14, [rax+0x40]
0000713aae5d6972  movups xmm13, [r13+r14*1]
0000713aae5d6978  lea r14, [rax+0x50]
0000713aae5d697c  movups xmm9, [r13+r14*1]
0000713aae5d6982  movaps [r15+0x1B0], xmm13
0000713aae5d698a  movaps [r15+0x1A0], xmm9
0000713aae5d6992  movaps xmm6, [r15+0x190]
0000713aae5d699a  vmovaps xmm3, [rsp+0xB0]
0000713aae5d69a3  vpermilpd xmm3, xmm3, 0x00
0000713aae5d69a9  vmovaps [rsp+0x20], xmm1
0000713aae5d69af  movaps xmm2, xmm12
0000713aae5d69b3  vfmadd231pd xmm2, xmm6, xmm3
0000713aae5d69b8  vcmppd xmm1, xmm2, xmm2, 0x03
0000713aae5d69bd  vptest xmm1, xmm1
0000713aae5d69c2  jnz 0x0000713AAE5D8350
0000713aae5d69c8  vmovaps xmm1, [rsp+0xB0]
0000713aae5d69d1  vpermilpd xmm1, xmm1, 0x00
0000713aae5d69d7  vmovaps xmm12, [rsp+0x20]
0000713aae5d69dd  movaps xmm6, xmm10
0000713aae5d69e1  vfmadd231pd xmm6, xmm12, xmm1
0000713aae5d69e6  vcmppd xmm3, xmm6, xmm6, 0x03
0000713aae5d69eb  vptest xmm3, xmm3
0000713aae5d69f0  jnz 0x0000713AAE5D84A6
0000713aae5d69f6  vmovaps xmm1, [rsp+0xB0]
0000713aae5d69ff  vpermilpd xmm1, xmm1, 0x00
0000713aae5d6a05  vmovaps xmm12, [rsp+0x40]
0000713aae5d6a0b  movaps xmm10, xmm5
0000713aae5d6a0f  vfmadd231pd xmm10, xmm12, xmm1
0000713aae5d6a14  vcmppd xmm3, xmm10, xmm10, 0x03
0000713aae5d6a1a  vptest xmm3, xmm3
0000713aae5d6a1f  jnz 0x0000713AAE5D85FD
0000713aae5d6a25  vmovaps xmm1, [rsp+0xB0]
0000713aae5d6a2e  vpermilpd xmm1, xmm1, 0x00
0000713aae5d6a34  movaps xmm12, xmm7
0000713aae5d6a38  vfmadd231pd xmm12, xmm15, xmm1
0000713aae5d6a3d  vcmppd xmm5, xmm12, xmm12, 0x03
0000713aae5d6a43  vptest xmm5, xmm5
0000713aae5d6a48  jnz 0x0000713AAE5D8755
0000713aae5d6a4e  lea r14, [rax+0x60]
0000713aae5d6a52  movups xmm1, [r13+r14*1]
0000713aae5d6a58  lea r14, [rax+0x70]
0000713aae5d6a5c  movups xmm15, [r13+r14*1]
0000713aae5d6a62  movaps [r15+0x150], xmm1
0000713aae5d6a6a  movaps [r15+0x120], xmm15
0000713aae5d6a72  vmovaps [rsp+0x20], xmm11
0000713aae5d6a78  vpermilpd xmm11, xmm11, 0x00
0000713aae5d6a7e  movaps xmm7, xmm2
0000713aae5d6a81  vfmadd231pd xmm7, xmm9, xmm11
0000713aae5d6a86  vcmppd xmm5, xmm7, xmm7, 0x03
0000713aae5d6a8b  vptest xmm5, xmm5
0000713aae5d6a90  jnz 0x0000713AAE5D88C1
0000713aae5d6a96  vmovaps xmm11, [rsp+0x20]
0000713aae5d6a9c  vpermilpd xmm11, xmm11, 0x00
0000713aae5d6aa2  movaps xmm9, xmm6
0000713aae5d6aa6  vfmadd231pd xmm9, xmm1, xmm11
0000713aae5d6aab  vcmppd xmm5, xmm9, xmm9, 0x03
0000713aae5d6ab1  vptest xmm5, xmm5
0000713aae5d6ab6  jnz 0x0000713AAE5D8A18
0000713aae5d6abc  vmovaps xmm1, [rsp+0x20]
0000713aae5d6ac2  vpermilpd xmm1, xmm1, 0x00
0000713aae5d6ac8  movaps xmm11, xmm10
0000713aae5d6acc  vfmadd231pd xmm11, xmm8, xmm1
0000713aae5d6ad1  vcmppd xmm6, xmm11, xmm11, 0x03
0000713aae5d6ad7  vptest xmm6, xmm6
0000713aae5d6adc  jnz 0x0000713AAE5D8B70
0000713aae5d6ae2  vmovaps xmm1, [rsp+0x20]
0000713aae5d6ae8  vpermilpd xmm1, xmm1, 0x00
0000713aae5d6aee  movaps xmm10, xmm12
0000713aae5d6af2  vfmadd231pd xmm10, xmm13, xmm1
0000713aae5d6af7  vcmppd xmm8, xmm10, xmm10, 0x03
0000713aae5d6afd  vptest xmm8, xmm8
0000713aae5d6b02  jnz 0x0000713AAE5D8CC9
0000713aae5d6b08  lea r14, [rax+0x20]
0000713aae5d6b0c  movups xmm1, [r13+r14*1]
0000713aae5d6b12  lea r14, [rax+0x30]
0000713aae5d6b16  movups xmm13, [r13+r14*1]
0000713aae5d6b1c  vmovaps xmm12, [rsp+0x90]
0000713aae5d6b25  vpermilpd xmm12, xmm12, 0x00
0000713aae5d6b2b  movaps xmm8, xmm7
0000713aae5d6b2f  vfmadd231pd xmm8, xmm4, xmm12
0000713aae5d6b34  vcmppd xmm6, xmm8, xmm8, 0x03
0000713aae5d6b3a  vptest xmm6, xmm6
0000713aae5d6b3f  jnz 0x0000713AAE5D8E36
0000713aae5d6b45  vmovaps xmm12, [rsp+0x90]
0000713aae5d6b4e  vpermilpd xmm12, xmm12, 0x00
0000713aae5d6b54  movaps xmm7, xmm9
0000713aae5d6b58  vfmadd231pd xmm7, xmm14, xmm12
0000713aae5d6b5d  vcmppd xmm6, xmm7, xmm7, 0x03
0000713aae5d6b62  vptest xmm6, xmm6
0000713aae5d6b67  jnz 0x0000713AAE5D8F8E
0000713aae5d6b6d  vmovaps xmm14, [rsp+0x90]
0000713aae5d6b76  vpermilpd xmm14, xmm14, 0x00
0000713aae5d6b7c  movaps xmm12, xmm11
0000713aae5d6b80  vfmadd231pd xmm12, xmm15, xmm14
0000713aae5d6b85  vcmppd xmm9, xmm12, xmm12, 0x03
0000713aae5d6b8b  vptest xmm9, xmm9
0000713aae5d6b90  jnz 0x0000713AAE5D90E6
0000713aae5d6b96  vmovaps xmm15, [rsp+0x90]
0000713aae5d6b9f  vpermilpd xmm15, xmm15, 0x00
0000713aae5d6ba5  movaps xmm11, xmm10
0000713aae5d6ba9  vfmadd231pd xmm11, xmm13, xmm15
0000713aae5d6bae  vcmppd xmm14, xmm11, xmm11, 0x03
0000713aae5d6bb4  vptest xmm14, xmm14
0000713aae5d6bb9  jnz 0x0000713AAE5D9240
0000713aae5d6bbf  lea r14, [rax+0x90]
0000713aae5d6bc6  movups xmm15, [r13+r14*1]
0000713aae5d6bcc  lea r14, [rax+0xA0]
0000713aae5d6bd3  movups xmm14, [r13+r14*1]
0000713aae5d6bd9  movaps [r15+0x140], xmm15
0000713aae5d6be1  movaps [r15+0x130], xmm14
0000713aae5d6be9  vmovaps xmm13, [rsp+0x10]
0000713aae5d6bef  vpermilpd xmm13, xmm13, 0x00
0000713aae5d6bf5  movaps xmm10, xmm8
0000713aae5d6bf9  vfmadd231pd xmm10, xmm1, xmm13
0000713aae5d6bfe  vcmppd xmm9, xmm10, xmm10, 0x03
0000713aae5d6c04  vptest xmm9, xmm9
0000713aae5d6c09  jnz 0x0000713AAE5D93AE
0000713aae5d6c0f  movaps [r15+0x220], xmm10
0000713aae5d6c17  lea r14, [rax+0x10]
0000713aae5d6c1b  movups xmm1, [r13+r14*1]
0000713aae5d6c21  movaps [r15+0x240], xmm1
0000713aae5d6c29  vmovaps xmm13, [rsp+0x10]
0000713aae5d6c2f  vpermilpd xmm13, xmm13, 0x00
0000713aae5d6c35  movaps xmm9, xmm7
0000713aae5d6c39  vfmadd231pd xmm9, xmm14, xmm13
0000713aae5d6c3e  vcmppd xmm8, xmm9, xmm9, 0x03
0000713aae5d6c44  vptest xmm8, xmm8
0000713aae5d6c49  jnz 0x0000713AAE5D9511
0000713aae5d6c4f  movaps [r15+0x110], xmm9
0000713aae5d6c57  vmovaps xmm14, [rsp+0x10]
0000713aae5d6c5d  vpermilpd xmm14, xmm14, 0x00
0000713aae5d6c63  movaps xmm13, xmm12
0000713aae5d6c67  vfmadd231pd xmm13, xmm15, xmm14
0000713aae5d6c6c  vcmppd xmm8, xmm13, xmm13, 0x03
0000713aae5d6c72  vptest xmm8, xmm8
0000713aae5d6c77  jnz 0x0000713AAE5D966A
0000713aae5d6c7d  movaps [r15+0x170], xmm13
0000713aae5d6c85  vmovaps xmm15, [rsp+0x10]
0000713aae5d6c8b  vpermilpd xmm15, xmm15, 0x00
0000713aae5d6c91  movaps xmm14, xmm11
0000713aae5d6c95  vfmadd231pd xmm14, xmm1, xmm15
0000713aae5d6c9a  vcmppd xmm12, xmm14, xmm14, 0x03
0000713aae5d6ca0  vptest xmm12, xmm12
0000713aae5d6ca5  jnz 0x0000713AAE5D97C4
0000713aae5d6cab  movaps [r15+0x230], xmm14
0000713aae5d6cb3  movups [r13+r11*1], xmm9
0000713aae5d6cb9  lea rax, [r11+0x10]
0000713aae5d6cbd  movups [r13+rax*1], xmm13
0000713aae5d6cc3  lea rax, [r11+0x20]
0000713aae5d6cc7  movups [r13+rax*1], xmm10
0000713aae5d6ccd  lea rax, [r11+0x30]
0000713aae5d6cd1  movups [r13+rax*1], xmm14
0000713aae5d6cd7  mov eax, [r15+0x108]
0000713aae5d6cde  sahf
0000713aae5d6cdf  jnz 0x0000713AAE5D6D11
0000713aae5d6ce1  cmp dword ptr [r15+0x318], 0x00
0000713aae5d6ce9  jz 0x0000713AAE5D9950
0000713aae5d6cef  nop [rax+rax*1], ax
0000713aae5d6cf8  nop [rax+rax*1], eax
0000713aae5d6d00  mov eax, 0x410664
0000713aae5d6d05  mov [r15+0x100], rax
0000713aae5d6d0c  jmp 0x0000713AAE3FE110
0000713aae5d6d11  cmp dword ptr [r15+0x318], 0x00
0000713aae5d6d19  jz 0x0000713AAE5D6050
0000713aae5d6d1f  nop [rax+rax*1], ax
0000713aae5d6d28  nop [rax+rax*1], eax
0000713aae5d6d30  mov eax, 0x4104F0
0000713aae5d6d35  mov [r15+0x100], rax
0000713aae5d6d3c  jmp 0x0000713AAE3FE110
0000713aae5d6d41  int3
0000713aae5d6d42  call 0x0000713AAE40A4B0
0000713aae5d6d47  jmp 0x0000713AAE5D6079
0000713aae5d6d4c  call 0x0000713AAE409240
0000713aae5d6d51  jmp 0x0000713AAE5D6083
0000713aae5d6d56  call 0x0000713AAE40A4B0
0000713aae5d6d5b  jmp 0x0000713AAE5D60CD
0000713aae5d6d60  call 0x0000713AAE409240
0000713aae5d6d65  jmp 0x0000713AAE5D60D7
0000713aae5d6d6a  call 0x0000713AAE40A4B0
0000713aae5d6d6f  jmp 0x0000713AAE5D6158
0000713aae5d6d74  call 0x0000713AAE409240
0000713aae5d6d79  jmp 0x0000713AAE5D6162
0000713aae5d6d7e  call 0x0000713AAE4B47C0
0000713aae5d6d83  jmp 0x0000713AAE5D6243
0000713aae5d6d88  call 0x0000713AAE3FF430
0000713aae5d6d8d  jmp 0x0000713AAE5D6272
0000713aae5d6d92  call 0x0000713AAE4B0CE0
0000713aae5d6d97  jmp 0x0000713AAE5D628E
0000713aae5d6d9c  sub rsp, 0x08
0000713aae5d6da0  push rax
0000713aae5d6da1  push rcx
0000713aae5d6da2  push rdx
0000713aae5d6da3  push rdi
0000713aae5d6da4  push rsi
0000713aae5d6da5  push r8
0000713aae5d6da7  push r9
0000713aae5d6da9  push r10
0000713aae5d6dab  push r11
0000713aae5d6dad  sub rsp, 0xF0
0000713aae5d6db4  vmovaps [rsp], xmm0
0000713aae5d6db9  vmovaps [rsp+0x10], xmm1
0000713aae5d6dbf  vmovaps [rsp+0x20], xmm2
0000713aae5d6dc5  vmovaps [rsp+0x30], xmm3
0000713aae5d6dcb  vmovaps [rsp+0x40], xmm4
0000713aae5d6dd1  vmovaps [rsp+0x50], xmm5
0000713aae5d6dd7  vmovaps [rsp+0x60], xmm6
0000713aae5d6ddd  vmovaps [rsp+0x70], xmm7
0000713aae5d6de3  vmovaps [rsp+0x80], xmm8
0000713aae5d6dec  vmovaps [rsp+0x90], xmm9
0000713aae5d6df5  vmovaps [rsp+0xA0], xmm10
0000713aae5d6dfe  vmovaps [rsp+0xB0], xmm11
0000713aae5d6e07  vmovaps [rsp+0xC0], xmm12
0000713aae5d6e10  vmovaps [rsp+0xD0], xmm14
0000713aae5d6e19  vmovaps [rsp+0xE0], xmm15
0000713aae5d6e22  sub rsp, 0x40
0000713aae5d6e26  lea rdi, [rsp]
0000713aae5d6e2a  lea rsi, [rsp+0x10]
0000713aae5d6e2f  lea rdx, [rsp+0x20]
0000713aae5d6e34  lea rcx, [rsp+0x30]
0000713aae5d6e39  mov r8d, 0x00
0000713aae5d6e3f  lea r9, [r15+0x3A8]
0000713aae5d6e46  movaps [rdi], xmm13
0000713aae5d6e4a  movaps [rsi], xmm1
0000713aae5d6e4d  movaps [rdx], xmm15
0000713aae5d6e51  movaps [rcx], xmm14
0000713aae5d6e55  mov rax, 0x5E9381C89A50
0000713aae5d6e5f  call rax
0000713aae5d6e61  movaps xmm13, [rsp]
0000713aae5d6e66  add rsp, 0x40
0000713aae5d6e6a  vmovaps xmm0, [rsp]
0000713aae5d6e6f  vmovaps xmm1, [rsp+0x10]
0000713aae5d6e75  vmovaps xmm2, [rsp+0x20]
0000713aae5d6e7b  vmovaps xmm3, [rsp+0x30]
0000713aae5d6e81  vmovaps xmm4, [rsp+0x40]
0000713aae5d6e87  vmovaps xmm5, [rsp+0x50]
0000713aae5d6e8d  vmovaps xmm6, [rsp+0x60]
0000713aae5d6e93  vmovaps xmm7, [rsp+0x70]
0000713aae5d6e99  vmovaps xmm8, [rsp+0x80]
0000713aae5d6ea2  vmovaps xmm9, [rsp+0x90]
0000713aae5d6eab  vmovaps xmm10, [rsp+0xA0]
0000713aae5d6eb4  vmovaps xmm11, [rsp+0xB0]
0000713aae5d6ebd  vmovaps xmm12, [rsp+0xC0]
0000713aae5d6ec6  vmovaps xmm14, [rsp+0xD0]
0000713aae5d6ecf  vmovaps xmm15, [rsp+0xE0]
0000713aae5d6ed8  add rsp, 0xF0
0000713aae5d6edf  pop r11
0000713aae5d6ee1  pop r10
0000713aae5d6ee3  pop r9
0000713aae5d6ee5  pop r8
0000713aae5d6ee7  pop rsi
0000713aae5d6ee8  pop rdi
0000713aae5d6ee9  pop rdx
0000713aae5d6eea  pop rcx
0000713aae5d6eeb  pop rax
0000713aae5d6eec  add rsp, 0x08
0000713aae5d6ef0  jmp 0x0000713AAE5D6305
0000713aae5d6ef5  sub rsp, 0x08
0000713aae5d6ef9  push rax
0000713aae5d6efa  push rcx
0000713aae5d6efb  push rdx
0000713aae5d6efc  push rdi
0000713aae5d6efd  push rsi
0000713aae5d6efe  push r8
0000713aae5d6f00  push r9
0000713aae5d6f02  push r10
0000713aae5d6f04  push r11
0000713aae5d6f06  sub rsp, 0xF0
0000713aae5d6f0d  vmovaps [rsp], xmm0
0000713aae5d6f12  vmovaps [rsp+0x10], xmm1
0000713aae5d6f18  vmovaps [rsp+0x20], xmm2
0000713aae5d6f1e  vmovaps [rsp+0x30], xmm3
0000713aae5d6f24  vmovaps [rsp+0x40], xmm4
0000713aae5d6f2a  vmovaps [rsp+0x50], xmm5
0000713aae5d6f30  vmovaps [rsp+0x60], xmm6
0000713aae5d6f36  vmovaps [rsp+0x70], xmm7
0000713aae5d6f3c  vmovaps [rsp+0x80], xmm8
0000713aae5d6f45  vmovaps [rsp+0x90], xmm9
0000713aae5d6f4e  vmovaps [rsp+0xA0], xmm10
0000713aae5d6f57  vmovaps [rsp+0xB0], xmm11
0000713aae5d6f60  vmovaps [rsp+0xC0], xmm13
0000713aae5d6f69  vmovaps [rsp+0xD0], xmm14
0000713aae5d6f72  vmovaps [rsp+0xE0], xmm15
0000713aae5d6f7b  sub rsp, 0x40
0000713aae5d6f7f  lea rdi, [rsp]
0000713aae5d6f83  lea rsi, [rsp+0x10]
0000713aae5d6f88  lea rdx, [rsp+0x20]
0000713aae5d6f8d  lea rcx, [rsp+0x30]
0000713aae5d6f92  mov r8d, 0x00
0000713aae5d6f98  lea r9, [r15+0x3A8]
0000713aae5d6f9f  movaps [rdi], xmm12
0000713aae5d6fa3  movaps [rsi], xmm15
0000713aae5d6fa7  movaps [rdx], xmm1
0000713aae5d6faa  movaps [rcx], xmm14
0000713aae5d6fae  mov rax, 0x5E9381C89A50
0000713aae5d6fb8  call rax
0000713aae5d6fba  movaps xmm12, [rsp]
0000713aae5d6fbf  add rsp, 0x40
0000713aae5d6fc3  vmovaps xmm0, [rsp]
0000713aae5d6fc8  vmovaps xmm1, [rsp+0x10]
0000713aae5d6fce  vmovaps xmm2, [rsp+0x20]
0000713aae5d6fd4  vmovaps xmm3, [rsp+0x30]
0000713aae5d6fda  vmovaps xmm4, [rsp+0x40]
0000713aae5d6fe0  vmovaps xmm5, [rsp+0x50]
0000713aae5d6fe6  vmovaps xmm6, [rsp+0x60]
0000713aae5d6fec  vmovaps xmm7, [rsp+0x70]
0000713aae5d6ff2  vmovaps xmm8, [rsp+0x80]
0000713aae5d6ffb  vmovaps xmm9, [rsp+0x90]
0000713aae5d7004  vmovaps xmm10, [rsp+0xA0]
0000713aae5d700d  vmovaps xmm11, [rsp+0xB0]
0000713aae5d7016  vmovaps xmm13, [rsp+0xC0]
0000713aae5d701f  vmovaps xmm14, [rsp+0xD0]
0000713aae5d7028  vmovaps xmm15, [rsp+0xE0]
0000713aae5d7031  add rsp, 0xF0
0000713aae5d7038  pop r11
0000713aae5d703a  pop r10
0000713aae5d703c  pop r9
0000713aae5d703e  pop r8
0000713aae5d7040  pop rsi
0000713aae5d7041  pop rdi
0000713aae5d7042  pop rdx
0000713aae5d7043  pop rcx
0000713aae5d7044  pop rax
0000713aae5d7045  add rsp, 0x08
0000713aae5d7049  jmp 0x0000713AAE5D6333
0000713aae5d704e  call 0x0000713AAE4D64F0
0000713aae5d7053  jmp 0x0000713AAE5D641F
0000713aae5d7058  sub rsp, 0x08
0000713aae5d705c  push rax
0000713aae5d705d  push rcx
0000713aae5d705e  push rdx
0000713aae5d705f  push rdi
0000713aae5d7060  push rsi
0000713aae5d7061  push r8
0000713aae5d7063  push r9
0000713aae5d7065  push r10
0000713aae5d7067  push r11
0000713aae5d7069  sub rsp, 0xF0
0000713aae5d7070  vmovaps [rsp], xmm0
0000713aae5d7075  vmovaps [rsp+0x10], xmm1
0000713aae5d707b  vmovaps [rsp+0x20], xmm2
0000713aae5d7081  vmovaps [rsp+0x30], xmm3
0000713aae5d7087  vmovaps [rsp+0x40], xmm4
0000713aae5d708d  vmovaps [rsp+0x50], xmm5
0000713aae5d7093  vmovaps [rsp+0x60], xmm6
0000713aae5d7099  vmovaps [rsp+0x70], xmm7
0000713aae5d709f  vmovaps [rsp+0x80], xmm8
0000713aae5d70a8  vmovaps [rsp+0x90], xmm9
0000713aae5d70b1  vmovaps [rsp+0xA0], xmm10
0000713aae5d70ba  vmovaps [rsp+0xB0], xmm11
0000713aae5d70c3  vmovaps [rsp+0xC0], xmm12
0000713aae5d70cc  vmovaps [rsp+0xD0], xmm14
0000713aae5d70d5  vmovaps [rsp+0xE0], xmm15
0000713aae5d70de  sub rsp, 0x40
0000713aae5d70e2  lea rdi, [rsp]
0000713aae5d70e6  lea rsi, [rsp+0x10]
0000713aae5d70eb  lea rdx, [rsp+0x20]
0000713aae5d70f0  lea rcx, [rsp+0x30]
0000713aae5d70f5  mov r8d, 0x00
0000713aae5d70fb  lea r9, [r15+0x3A8]
0000713aae5d7102  movaps [rdi], xmm13
0000713aae5d7106  movaps [rsi], xmm1
0000713aae5d7109  movaps [rdx], xmm15
0000713aae5d710d  movaps [rcx], xmm14
0000713aae5d7111  mov rax, 0x5E9381C89A50
0000713aae5d711b  call rax
0000713aae5d711d  movaps xmm13, [rsp]
0000713aae5d7122  add rsp, 0x40
0000713aae5d7126  vmovaps xmm0, [rsp]
0000713aae5d712b  vmovaps xmm1, [rsp+0x10]
0000713aae5d7131  vmovaps xmm2, [rsp+0x20]
0000713aae5d7137  vmovaps xmm3, [rsp+0x30]
0000713aae5d713d  vmovaps xmm4, [rsp+0x40]
0000713aae5d7143  vmovaps xmm5, [rsp+0x50]
0000713aae5d7149  vmovaps xmm6, [rsp+0x60]
0000713aae5d714f  vmovaps xmm7, [rsp+0x70]
0000713aae5d7155  vmovaps xmm8, [rsp+0x80]
0000713aae5d715e  vmovaps xmm9, [rsp+0x90]
0000713aae5d7167  vmovaps xmm10, [rsp+0xA0]
0000713aae5d7170  vmovaps xmm11, [rsp+0xB0]
0000713aae5d7179  vmovaps xmm12, [rsp+0xC0]
0000713aae5d7182  vmovaps xmm14, [rsp+0xD0]
0000713aae5d718b  vmovaps xmm15, [rsp+0xE0]
0000713aae5d7194  add rsp, 0xF0
0000713aae5d719b  pop r11
0000713aae5d719d  pop r10
0000713aae5d719f  pop r9
0000713aae5d71a1  pop r8
0000713aae5d71a3  pop rsi
0000713aae5d71a4  pop rdi
0000713aae5d71a5  pop rdx
0000713aae5d71a6  pop rcx
0000713aae5d71a7  pop rax
0000713aae5d71a8  add rsp, 0x08
0000713aae5d71ac  jmp 0x0000713AAE5D648E
0000713aae5d71b1  call 0x0000713AAE4D64F0
0000713aae5d71b6  jmp 0x0000713AAE5D64A3
0000713aae5d71bb  sub rsp, 0x08
0000713aae5d71bf  push rax
0000713aae5d71c0  push rcx
0000713aae5d71c1  push rdx
0000713aae5d71c2  push rdi
0000713aae5d71c3  push rsi
0000713aae5d71c4  push r8
0000713aae5d71c6  push r9
0000713aae5d71c8  push r10
0000713aae5d71ca  push r11
0000713aae5d71cc  sub rsp, 0xF0
0000713aae5d71d3  vmovaps [rsp], xmm0
0000713aae5d71d8  vmovaps [rsp+0x10], xmm1
0000713aae5d71de  vmovaps [rsp+0x20], xmm2
0000713aae5d71e4  vmovaps [rsp+0x30], xmm3
0000713aae5d71ea  vmovaps [rsp+0x40], xmm4
0000713aae5d71f0  vmovaps [rsp+0x50], xmm5
0000713aae5d71f6  vmovaps [rsp+0x60], xmm6
0000713aae5d71fc  vmovaps [rsp+0x70], xmm7
0000713aae5d7202  vmovaps [rsp+0x80], xmm8
0000713aae5d720b  vmovaps [rsp+0x90], xmm9
0000713aae5d7214  vmovaps [rsp+0xA0], xmm10
0000713aae5d721d  vmovaps [rsp+0xB0], xmm11
0000713aae5d7226  vmovaps [rsp+0xC0], xmm13
0000713aae5d722f  vmovaps [rsp+0xD0], xmm14
0000713aae5d7238  vmovaps [rsp+0xE0], xmm15
0000713aae5d7241  sub rsp, 0x40
0000713aae5d7245  lea rdi, [rsp]
0000713aae5d7249  lea rsi, [rsp+0x10]
0000713aae5d724e  lea rdx, [rsp+0x20]
0000713aae5d7253  lea rcx, [rsp+0x30]
0000713aae5d7258  mov r8d, 0x00
0000713aae5d725e  lea r9, [r15+0x3A8]
0000713aae5d7265  movaps [rdi], xmm12
0000713aae5d7269  movaps [rsi], xmm15
0000713aae5d726d  movaps [rdx], xmm1
0000713aae5d7270  movaps [rcx], xmm14
0000713aae5d7274  mov rax, 0x5E9381C89A50
0000713aae5d727e  call rax
0000713aae5d7280  movaps xmm12, [rsp]
0000713aae5d7285  add rsp, 0x40
0000713aae5d7289  vmovaps xmm0, [rsp]
0000713aae5d728e  vmovaps xmm1, [rsp+0x10]
0000713aae5d7294  vmovaps xmm2, [rsp+0x20]
0000713aae5d729a  vmovaps xmm3, [rsp+0x30]
0000713aae5d72a0  vmovaps xmm4, [rsp+0x40]
0000713aae5d72a6  vmovaps xmm5, [rsp+0x50]
0000713aae5d72ac  vmovaps xmm6, [rsp+0x60]
0000713aae5d72b2  vmovaps xmm7, [rsp+0x70]
0000713aae5d72b8  vmovaps xmm8, [rsp+0x80]
0000713aae5d72c1  vmovaps xmm9, [rsp+0x90]
0000713aae5d72ca  vmovaps xmm10, [rsp+0xA0]
0000713aae5d72d3  vmovaps xmm11, [rsp+0xB0]
0000713aae5d72dc  vmovaps xmm13, [rsp+0xC0]
0000713aae5d72e5  vmovaps xmm14, [rsp+0xD0]
0000713aae5d72ee  vmovaps xmm15, [rsp+0xE0]
0000713aae5d72f7  add rsp, 0xF0
0000713aae5d72fe  pop r11
0000713aae5d7300  pop r10
0000713aae5d7302  pop r9
0000713aae5d7304  pop r8
0000713aae5d7306  pop rsi
0000713aae5d7307  pop rdi
0000713aae5d7308  pop rdx
0000713aae5d7309  pop rcx
0000713aae5d730a  pop rax
0000713aae5d730b  add rsp, 0x08
0000713aae5d730f  jmp 0x0000713AAE5D64CF
0000713aae5d7314  sub rsp, 0x08
0000713aae5d7318  push rax
0000713aae5d7319  push rcx
0000713aae5d731a  push rdx
0000713aae5d731b  push rdi
0000713aae5d731c  push rsi
0000713aae5d731d  push r8
0000713aae5d731f  push r9
0000713aae5d7321  push r10
0000713aae5d7323  push r11
0000713aae5d7325  sub rsp, 0xF0
0000713aae5d732c  vmovaps [rsp], xmm0
0000713aae5d7331  vmovaps [rsp+0x10], xmm1
0000713aae5d7337  vmovaps [rsp+0x20], xmm2
0000713aae5d733d  vmovaps [rsp+0x30], xmm3
0000713aae5d7343  vmovaps [rsp+0x40], xmm4
0000713aae5d7349  vmovaps [rsp+0x50], xmm5
0000713aae5d734f  vmovaps [rsp+0x60], xmm6
0000713aae5d7355  vmovaps [rsp+0x70], xmm7
0000713aae5d735b  vmovaps [rsp+0x80], xmm8
0000713aae5d7364  vmovaps [rsp+0x90], xmm9
0000713aae5d736d  vmovaps [rsp+0xA0], xmm10
0000713aae5d7376  vmovaps [rsp+0xB0], xmm11
0000713aae5d737f  vmovaps [rsp+0xC0], xmm12
0000713aae5d7388  vmovaps [rsp+0xD0], xmm14
0000713aae5d7391  vmovaps [rsp+0xE0], xmm15
0000713aae5d739a  sub rsp, 0x40
0000713aae5d739e  lea rdi, [rsp]
0000713aae5d73a2  lea rsi, [rsp+0x10]
0000713aae5d73a7  lea rdx, [rsp+0x20]
0000713aae5d73ac  lea rcx, [rsp+0x30]
0000713aae5d73b1  mov r8d, 0x00
0000713aae5d73b7  lea r9, [r15+0x3A8]
0000713aae5d73be  movaps [rdi], xmm13
0000713aae5d73c2  movaps [rsi], xmm1
0000713aae5d73c5  movaps [rdx], xmm15
0000713aae5d73c9  movaps [rcx], xmm14
0000713aae5d73cd  mov rax, 0x5E9381C89A50
0000713aae5d73d7  call rax
0000713aae5d73d9  movaps xmm13, [rsp]
0000713aae5d73de  add rsp, 0x40
0000713aae5d73e2  vmovaps xmm0, [rsp]
0000713aae5d73e7  vmovaps xmm1, [rsp+0x10]
0000713aae5d73ed  vmovaps xmm2, [rsp+0x20]
0000713aae5d73f3  vmovaps xmm3, [rsp+0x30]
0000713aae5d73f9  vmovaps xmm4, [rsp+0x40]
0000713aae5d73ff  vmovaps xmm5, [rsp+0x50]
0000713aae5d7405  vmovaps xmm6, [rsp+0x60]
0000713aae5d740b  vmovaps xmm7, [rsp+0x70]
0000713aae5d7411  vmovaps xmm8, [rsp+0x80]
0000713aae5d741a  vmovaps xmm9, [rsp+0x90]
0000713aae5d7423  vmovaps xmm10, [rsp+0xA0]
0000713aae5d742c  vmovaps xmm11, [rsp+0xB0]
0000713aae5d7435  vmovaps xmm12, [rsp+0xC0]
0000713aae5d743e  vmovaps xmm14, [rsp+0xD0]
0000713aae5d7447  vmovaps xmm15, [rsp+0xE0]
0000713aae5d7450  add rsp, 0xF0
0000713aae5d7457  pop r11
0000713aae5d7459  pop r10
0000713aae5d745b  pop r9
0000713aae5d745d  pop r8
0000713aae5d745f  pop rsi
0000713aae5d7460  pop rdi
0000713aae5d7461  pop rdx
0000713aae5d7462  pop rcx
0000713aae5d7463  pop rax
0000713aae5d7464  add rsp, 0x08
0000713aae5d7468  jmp 0x0000713AAE5D665F
0000713aae5d746d  sub rsp, 0x08
0000713aae5d7471  push rax
0000713aae5d7472  push rcx
0000713aae5d7473  push rdx
0000713aae5d7474  push rdi
0000713aae5d7475  push rsi
0000713aae5d7476  push r8
0000713aae5d7478  push r9
0000713aae5d747a  push r10
0000713aae5d747c  push r11
0000713aae5d747e  sub rsp, 0xF0
0000713aae5d7485  vmovaps [rsp], xmm0
0000713aae5d748a  vmovaps [rsp+0x10], xmm1
0000713aae5d7490  vmovaps [rsp+0x20], xmm2
0000713aae5d7496  vmovaps [rsp+0x30], xmm3
0000713aae5d749c  vmovaps [rsp+0x40], xmm4
0000713aae5d74a2  vmovaps [rsp+0x50], xmm5
0000713aae5d74a8  vmovaps [rsp+0x60], xmm6
0000713aae5d74ae  vmovaps [rsp+0x70], xmm7
0000713aae5d74b4  vmovaps [rsp+0x80], xmm8
0000713aae5d74bd  vmovaps [rsp+0x90], xmm9
0000713aae5d74c6  vmovaps [rsp+0xA0], xmm10
0000713aae5d74cf  vmovaps [rsp+0xB0], xmm11
0000713aae5d74d8  vmovaps [rsp+0xC0], xmm12
0000713aae5d74e1  vmovaps [rsp+0xD0], xmm13
0000713aae5d74ea  vmovaps [rsp+0xE0], xmm15
0000713aae5d74f3  sub rsp, 0x40
0000713aae5d74f7  lea rdi, [rsp]
0000713aae5d74fb  lea rsi, [rsp+0x10]
0000713aae5d7500  lea rdx, [rsp+0x20]
0000713aae5d7505  lea rcx, [rsp+0x30]
0000713aae5d750a  mov r8d, 0x00
0000713aae5d7510  lea r9, [r15+0x3A8]
0000713aae5d7517  movaps [rdi], xmm14
0000713aae5d751b  movaps [rsi], xmm15
0000713aae5d751f  movaps [rdx], xmm2
0000713aae5d7522  movaps [rcx], xmm1
0000713aae5d7525  mov rax, 0x5E9381C89A50
0000713aae5d752f  call rax
0000713aae5d7531  movaps xmm14, [rsp]
0000713aae5d7536  add rsp, 0x40
0000713aae5d753a  vmovaps xmm0, [rsp]
0000713aae5d753f  vmovaps xmm1, [rsp+0x10]
0000713aae5d7545  vmovaps xmm2, [rsp+0x20]
0000713aae5d754b  vmovaps xmm3, [rsp+0x30]
0000713aae5d7551  vmovaps xmm4, [rsp+0x40]
0000713aae5d7557  vmovaps xmm5, [rsp+0x50]
0000713aae5d755d  vmovaps xmm6, [rsp+0x60]
0000713aae5d7563  vmovaps xmm7, [rsp+0x70]
0000713aae5d7569  vmovaps xmm8, [rsp+0x80]
0000713aae5d7572  vmovaps xmm9, [rsp+0x90]
0000713aae5d757b  vmovaps xmm10, [rsp+0xA0]
0000713aae5d7584  vmovaps xmm11, [rsp+0xB0]
0000713aae5d758d  vmovaps xmm12, [rsp+0xC0]
0000713aae5d7596  vmovaps xmm13, [rsp+0xD0]
0000713aae5d759f  vmovaps xmm15, [rsp+0xE0]
0000713aae5d75a8  add rsp, 0xF0
0000713aae5d75af  pop r11
0000713aae5d75b1  pop r10
0000713aae5d75b3  pop r9
0000713aae5d75b5  pop r8
0000713aae5d75b7  pop rsi
0000713aae5d75b8  pop rdi
0000713aae5d75b9  pop rdx
0000713aae5d75ba  pop rcx
0000713aae5d75bb  pop rax
0000713aae5d75bc  add rsp, 0x08
0000713aae5d75c0  jmp 0x0000713AAE5D6691
0000713aae5d75c5  sub rsp, 0x08
0000713aae5d75c9  push rax
0000713aae5d75ca  push rcx
0000713aae5d75cb  push rdx
0000713aae5d75cc  push rdi
0000713aae5d75cd  push rsi
0000713aae5d75ce  push r8
0000713aae5d75d0  push r9
0000713aae5d75d2  push r10
0000713aae5d75d4  push r11
0000713aae5d75d6  sub rsp, 0xF0
0000713aae5d75dd  vmovaps [rsp], xmm0
0000713aae5d75e2  vmovaps [rsp+0x10], xmm1
0000713aae5d75e8  vmovaps [rsp+0x20], xmm3
0000713aae5d75ee  vmovaps [rsp+0x30], xmm4
0000713aae5d75f4  vmovaps [rsp+0x40], xmm5
0000713aae5d75fa  vmovaps [rsp+0x50], xmm6
0000713aae5d7600  vmovaps [rsp+0x60], xmm7
0000713aae5d7606  vmovaps [rsp+0x70], xmm8
0000713aae5d760c  vmovaps [rsp+0x80], xmm9
0000713aae5d7615  vmovaps [rsp+0x90], xmm10
0000713aae5d761e  vmovaps [rsp+0xA0], xmm11
0000713aae5d7627  vmovaps [rsp+0xB0], xmm12
0000713aae5d7630  vmovaps [rsp+0xC0], xmm13
0000713aae5d7639  vmovaps [rsp+0xD0], xmm14
0000713aae5d7642  vmovaps [rsp+0xE0], xmm15
0000713aae5d764b  sub rsp, 0x40
0000713aae5d764f  lea rdi, [rsp]
0000713aae5d7653  lea rsi, [rsp+0x10]
0000713aae5d7658  lea rdx, [rsp+0x20]
0000713aae5d765d  lea rcx, [rsp+0x30]
0000713aae5d7662  mov r8d, 0x00
0000713aae5d7668  lea r9, [r15+0x3A8]
0000713aae5d766f  movaps [rdi], xmm2
0000713aae5d7672  movaps [rsi], xmm15
0000713aae5d7676  movaps [rdx], xmm12
0000713aae5d767a  movaps [rcx], xmm1
0000713aae5d767d  mov rax, 0x5E9381C89A50
0000713aae5d7687  call rax
0000713aae5d7689  movaps xmm2, [rsp]
0000713aae5d768d  add rsp, 0x40
0000713aae5d7691  vmovaps xmm0, [rsp]
0000713aae5d7696  vmovaps xmm1, [rsp+0x10]
0000713aae5d769c  vmovaps xmm3, [rsp+0x20]
0000713aae5d76a2  vmovaps xmm4, [rsp+0x30]
0000713aae5d76a8  vmovaps xmm5, [rsp+0x40]
0000713aae5d76ae  vmovaps xmm6, [rsp+0x50]
0000713aae5d76b4  vmovaps xmm7, [rsp+0x60]
0000713aae5d76ba  vmovaps xmm8, [rsp+0x70]
0000713aae5d76c0  vmovaps xmm9, [rsp+0x80]
0000713aae5d76c9  vmovaps xmm10, [rsp+0x90]
0000713aae5d76d2  vmovaps xmm11, [rsp+0xA0]
0000713aae5d76db  vmovaps xmm12, [rsp+0xB0]
0000713aae5d76e4  vmovaps xmm13, [rsp+0xC0]
0000713aae5d76ed  vmovaps xmm14, [rsp+0xD0]
0000713aae5d76f6  vmovaps xmm15, [rsp+0xE0]
0000713aae5d76ff  add rsp, 0xF0
0000713aae5d7706  pop r11
0000713aae5d7708  pop r10
0000713aae5d770a  pop r9
0000713aae5d770c  pop r8
0000713aae5d770e  pop rsi
0000713aae5d770f  pop rdi
0000713aae5d7710  pop rdx
0000713aae5d7711  pop rcx
0000713aae5d7712  pop rax
0000713aae5d7713  add rsp, 0x08
0000713aae5d7717  jmp 0x0000713AAE5D66CE
0000713aae5d771c  sub rsp, 0x08
0000713aae5d7720  push rax
0000713aae5d7721  push rcx
0000713aae5d7722  push rdx
0000713aae5d7723  push rdi
0000713aae5d7724  push rsi
0000713aae5d7725  push r8
0000713aae5d7727  push r9
0000713aae5d7729  push r10
0000713aae5d772b  push r11
0000713aae5d772d  sub rsp, 0xF0
0000713aae5d7734  vmovaps [rsp], xmm0
0000713aae5d7739  vmovaps [rsp+0x10], xmm1
0000713aae5d773f  vmovaps [rsp+0x20], xmm2
0000713aae5d7745  vmovaps [rsp+0x30], xmm3
0000713aae5d774b  vmovaps [rsp+0x40], xmm4
0000713aae5d7751  vmovaps [rsp+0x50], xmm5
0000713aae5d7757  vmovaps [rsp+0x60], xmm6
0000713aae5d775d  vmovaps [rsp+0x70], xmm7
0000713aae5d7763  vmovaps [rsp+0x80], xmm8
0000713aae5d776c  vmovaps [rsp+0x90], xmm9
0000713aae5d7775  vmovaps [rsp+0xA0], xmm10
0000713aae5d777e  vmovaps [rsp+0xB0], xmm11
0000713aae5d7787  vmovaps [rsp+0xC0], xmm13
0000713aae5d7790  vmovaps [rsp+0xD0], xmm14
0000713aae5d7799  vmovaps [rsp+0xE0], xmm15
0000713aae5d77a2  sub rsp, 0x40
0000713aae5d77a6  lea rdi, [rsp]
0000713aae5d77aa  lea rsi, [rsp+0x10]
0000713aae5d77af  lea rdx, [rsp+0x20]
0000713aae5d77b4  lea rcx, [rsp+0x30]
0000713aae5d77b9  mov r8d, 0x00
0000713aae5d77bf  lea r9, [r15+0x3A8]
0000713aae5d77c6  movaps [rdi], xmm12
0000713aae5d77ca  movaps [rsi], xmm14
0000713aae5d77ce  movaps [rdx], xmm3
0000713aae5d77d1  movaps [rcx], xmm15
0000713aae5d77d5  mov rax, 0x5E9381C89A50
0000713aae5d77df  call rax
0000713aae5d77e1  movaps xmm12, [rsp]
0000713aae5d77e6  add rsp, 0x40
0000713aae5d77ea  vmovaps xmm0, [rsp]
0000713aae5d77ef  vmovaps xmm1, [rsp+0x10]
0000713aae5d77f5  vmovaps xmm2, [rsp+0x20]
0000713aae5d77fb  vmovaps xmm3, [rsp+0x30]
0000713aae5d7801  vmovaps xmm4, [rsp+0x40]
0000713aae5d7807  vmovaps xmm5, [rsp+0x50]
0000713aae5d780d  vmovaps xmm6, [rsp+0x60]
0000713aae5d7813  vmovaps xmm7, [rsp+0x70]
0000713aae5d7819  vmovaps xmm8, [rsp+0x80]
0000713aae5d7822  vmovaps xmm9, [rsp+0x90]
0000713aae5d782b  vmovaps xmm10, [rsp+0xA0]
0000713aae5d7834  vmovaps xmm11, [rsp+0xB0]
0000713aae5d783d  vmovaps xmm13, [rsp+0xC0]
0000713aae5d7846  vmovaps xmm14, [rsp+0xD0]
0000713aae5d784f  vmovaps xmm15, [rsp+0xE0]
0000713aae5d7858  add rsp, 0xF0
0000713aae5d785f  pop r11
0000713aae5d7861  pop r10
0000713aae5d7863  pop r9
0000713aae5d7865  pop r8
0000713aae5d7867  pop rsi
0000713aae5d7868  pop rdi
0000713aae5d7869  pop rdx
0000713aae5d786a  pop rcx
0000713aae5d786b  pop rax
0000713aae5d786c  add rsp, 0x08
0000713aae5d7870  jmp 0x0000713AAE5D6728
0000713aae5d7875  sub rsp, 0x08
0000713aae5d7879  push rax
0000713aae5d787a  push rcx
0000713aae5d787b  push rdx
0000713aae5d787c  push rdi
0000713aae5d787d  push rsi
0000713aae5d787e  push r8
0000713aae5d7880  push r9
0000713aae5d7882  push r10
0000713aae5d7884  push r11
0000713aae5d7886  sub rsp, 0xF0
0000713aae5d788d  vmovaps [rsp], xmm0
0000713aae5d7892  vmovaps [rsp+0x10], xmm1
0000713aae5d7898  vmovaps [rsp+0x20], xmm2
0000713aae5d789e  vmovaps [rsp+0x30], xmm3
0000713aae5d78a4  vmovaps [rsp+0x40], xmm4
0000713aae5d78aa  vmovaps [rsp+0x50], xmm5
0000713aae5d78b0  vmovaps [rsp+0x60], xmm6
0000713aae5d78b6  vmovaps [rsp+0x70], xmm7
0000713aae5d78bc  vmovaps [rsp+0x80], xmm8
0000713aae5d78c5  vmovaps [rsp+0x90], xmm10
0000713aae5d78ce  vmovaps [rsp+0xA0], xmm11
0000713aae5d78d7  vmovaps [rsp+0xB0], xmm12
0000713aae5d78e0  vmovaps [rsp+0xC0], xmm13
0000713aae5d78e9  vmovaps [rsp+0xD0], xmm14
0000713aae5d78f2  vmovaps [rsp+0xE0], xmm15
0000713aae5d78fb  sub rsp, 0x40
0000713aae5d78ff  lea rdi, [rsp]
0000713aae5d7903  lea rsi, [rsp+0x10]
0000713aae5d7908  lea rdx, [rsp+0x20]
0000713aae5d790d  lea rcx, [rsp+0x30]
0000713aae5d7912  mov r8d, 0x00
0000713aae5d7918  lea r9, [r15+0x3A8]
0000713aae5d791f  movaps [rdi], xmm9
0000713aae5d7923  movaps [rsi], xmm13
0000713aae5d7927  movaps [rdx], xmm14
0000713aae5d792b  movaps [rcx], xmm6
0000713aae5d792e  mov rax, 0x5E9381C89A50
0000713aae5d7938  call rax
0000713aae5d793a  movaps xmm9, [rsp]
0000713aae5d793f  add rsp, 0x40
0000713aae5d7943  vmovaps xmm0, [rsp]
0000713aae5d7948  vmovaps xmm1, [rsp+0x10]
0000713aae5d794e  vmovaps xmm2, [rsp+0x20]
0000713aae5d7954  vmovaps xmm3, [rsp+0x30]
0000713aae5d795a  vmovaps xmm4, [rsp+0x40]
0000713aae5d7960  vmovaps xmm5, [rsp+0x50]
0000713aae5d7966  vmovaps xmm6, [rsp+0x60]
0000713aae5d796c  vmovaps xmm7, [rsp+0x70]
0000713aae5d7972  vmovaps xmm8, [rsp+0x80]
0000713aae5d797b  vmovaps xmm10, [rsp+0x90]
0000713aae5d7984  vmovaps xmm11, [rsp+0xA0]
0000713aae5d798d  vmovaps xmm12, [rsp+0xB0]
0000713aae5d7996  vmovaps xmm13, [rsp+0xC0]
0000713aae5d799f  vmovaps xmm14, [rsp+0xD0]
0000713aae5d79a8  vmovaps xmm15, [rsp+0xE0]
0000713aae5d79b1  add rsp, 0xF0
0000713aae5d79b8  pop r11
0000713aae5d79ba  pop r10
0000713aae5d79bc  pop r9
0000713aae5d79be  pop r8
0000713aae5d79c0  pop rsi
0000713aae5d79c1  pop rdi
0000713aae5d79c2  pop rdx
0000713aae5d79c3  pop rcx
0000713aae5d79c4  pop rax
0000713aae5d79c5  add rsp, 0x08
0000713aae5d79c9  jmp 0x0000713AAE5D67D2
0000713aae5d79ce  sub rsp, 0x08
0000713aae5d79d2  push rax
0000713aae5d79d3  push rcx
0000713aae5d79d4  push rdx
0000713aae5d79d5  push rdi
0000713aae5d79d6  push rsi
0000713aae5d79d7  push r8
0000713aae5d79d9  push r9
0000713aae5d79db  push r10
0000713aae5d79dd  push r11
0000713aae5d79df  sub rsp, 0xF0
0000713aae5d79e6  vmovaps [rsp], xmm0
0000713aae5d79eb  vmovaps [rsp+0x10], xmm1
0000713aae5d79f1  vmovaps [rsp+0x20], xmm2
0000713aae5d79f7  vmovaps [rsp+0x30], xmm4
0000713aae5d79fd  vmovaps [rsp+0x40], xmm5
0000713aae5d7a03  vmovaps [rsp+0x50], xmm6
0000713aae5d7a09  vmovaps [rsp+0x60], xmm7
0000713aae5d7a0f  vmovaps [rsp+0x70], xmm8
0000713aae5d7a15  vmovaps [rsp+0x80], xmm9
0000713aae5d7a1e  vmovaps [rsp+0x90], xmm10
0000713aae5d7a27  vmovaps [rsp+0xA0], xmm11
0000713aae5d7a30  vmovaps [rsp+0xB0], xmm12
0000713aae5d7a39  vmovaps [rsp+0xC0], xmm13
0000713aae5d7a42  vmovaps [rsp+0xD0], xmm14
0000713aae5d7a4b  vmovaps [rsp+0xE0], xmm15
0000713aae5d7a54  sub rsp, 0x40
0000713aae5d7a58  lea rdi, [rsp]
0000713aae5d7a5c  lea rsi, [rsp+0x10]
0000713aae5d7a61  lea rdx, [rsp+0x20]
0000713aae5d7a66  lea rcx, [rsp+0x30]
0000713aae5d7a6b  mov r8d, 0x00
0000713aae5d7a71  lea r9, [r15+0x3A8]
0000713aae5d7a78  movaps [rdi], xmm3
0000713aae5d7a7b  movaps [rsi], xmm13
0000713aae5d7a7f  movaps [rdx], xmm6
0000713aae5d7a82  movaps [rcx], xmm14
0000713aae5d7a86  mov rax, 0x5E9381C89A50
0000713aae5d7a90  call rax
0000713aae5d7a92  movaps xmm3, [rsp]
0000713aae5d7a96  add rsp, 0x40
0000713aae5d7a9a  vmovaps xmm0, [rsp]
0000713aae5d7a9f  vmovaps xmm1, [rsp+0x10]
0000713aae5d7aa5  vmovaps xmm2, [rsp+0x20]
0000713aae5d7aab  vmovaps xmm4, [rsp+0x30]
0000713aae5d7ab1  vmovaps xmm5, [rsp+0x40]
0000713aae5d7ab7  vmovaps xmm6, [rsp+0x50]
0000713aae5d7abd  vmovaps xmm7, [rsp+0x60]
0000713aae5d7ac3  vmovaps xmm8, [rsp+0x70]
0000713aae5d7ac9  vmovaps xmm9, [rsp+0x80]
0000713aae5d7ad2  vmovaps xmm10, [rsp+0x90]
0000713aae5d7adb  vmovaps xmm11, [rsp+0xA0]
0000713aae5d7ae4  vmovaps xmm12, [rsp+0xB0]
0000713aae5d7aed  vmovaps xmm13, [rsp+0xC0]
0000713aae5d7af6  vmovaps xmm14, [rsp+0xD0]
0000713aae5d7aff  vmovaps xmm15, [rsp+0xE0]
0000713aae5d7b08  add rsp, 0xF0
0000713aae5d7b0f  pop r11
0000713aae5d7b11  pop r10
0000713aae5d7b13  pop r9
0000713aae5d7b15  pop r8
0000713aae5d7b17  pop rsi
0000713aae5d7b18  pop rdi
0000713aae5d7b19  pop rdx
0000713aae5d7b1a  pop rcx
0000713aae5d7b1b  pop rax
0000713aae5d7b1c  add rsp, 0x08
0000713aae5d7b20  jmp 0x0000713AAE5D680F
0000713aae5d7b25  sub rsp, 0x08
0000713aae5d7b29  push rax
0000713aae5d7b2a  push rcx
0000713aae5d7b2b  push rdx
0000713aae5d7b2c  push rdi
0000713aae5d7b2d  push rsi
0000713aae5d7b2e  push r8
0000713aae5d7b30  push r9
0000713aae5d7b32  push r10
0000713aae5d7b34  push r11
0000713aae5d7b36  sub rsp, 0xF0
0000713aae5d7b3d  vmovaps [rsp], xmm0
0000713aae5d7b42  vmovaps [rsp+0x10], xmm1
0000713aae5d7b48  vmovaps [rsp+0x20], xmm2
0000713aae5d7b4e  vmovaps [rsp+0x30], xmm3
0000713aae5d7b54  vmovaps [rsp+0x40], xmm4
0000713aae5d7b5a  vmovaps [rsp+0x50], xmm5
0000713aae5d7b60  vmovaps [rsp+0x60], xmm7
0000713aae5d7b66  vmovaps [rsp+0x70], xmm8
0000713aae5d7b6c  vmovaps [rsp+0x80], xmm9
0000713aae5d7b75  vmovaps [rsp+0x90], xmm10
0000713aae5d7b7e  vmovaps [rsp+0xA0], xmm11
0000713aae5d7b87  vmovaps [rsp+0xB0], xmm12
0000713aae5d7b90  vmovaps [rsp+0xC0], xmm13
0000713aae5d7b99  vmovaps [rsp+0xD0], xmm14
0000713aae5d7ba2  vmovaps [rsp+0xE0], xmm15
0000713aae5d7bab  sub rsp, 0x40
0000713aae5d7baf  lea rdi, [rsp]
0000713aae5d7bb3  lea rsi, [rsp+0x10]
0000713aae5d7bb8  lea rdx, [rsp+0x20]
0000713aae5d7bbd  lea rcx, [rsp+0x30]
0000713aae5d7bc2  mov r8d, 0x00
0000713aae5d7bc8  lea r9, [r15+0x3A8]
0000713aae5d7bcf  movaps [rdi], xmm6
0000713aae5d7bd2  movaps [rsi], xmm2
0000713aae5d7bd5  movaps [rdx], xmm14
0000713aae5d7bd9  movaps [rcx], xmm1
0000713aae5d7bdc  mov rax, 0x5E9381C89A50
0000713aae5d7be6  call rax
0000713aae5d7be8  movaps xmm6, [rsp]
0000713aae5d7bec  add rsp, 0x40
0000713aae5d7bf0  vmovaps xmm0, [rsp]
0000713aae5d7bf5  vmovaps xmm1, [rsp+0x10]
0000713aae5d7bfb  vmovaps xmm2, [rsp+0x20]
0000713aae5d7c01  vmovaps xmm3, [rsp+0x30]
0000713aae5d7c07  vmovaps xmm4, [rsp+0x40]
0000713aae5d7c0d  vmovaps xmm5, [rsp+0x50]
0000713aae5d7c13  vmovaps xmm7, [rsp+0x60]
0000713aae5d7c19  vmovaps xmm8, [rsp+0x70]
0000713aae5d7c1f  vmovaps xmm9, [rsp+0x80]
0000713aae5d7c28  vmovaps xmm10, [rsp+0x90]
0000713aae5d7c31  vmovaps xmm11, [rsp+0xA0]
0000713aae5d7c3a  vmovaps xmm12, [rsp+0xB0]
0000713aae5d7c43  vmovaps xmm13, [rsp+0xC0]
0000713aae5d7c4c  vmovaps xmm14, [rsp+0xD0]
0000713aae5d7c55  vmovaps xmm15, [rsp+0xE0]
0000713aae5d7c5e  add rsp, 0xF0
0000713aae5d7c65  pop r11
0000713aae5d7c67  pop r10
0000713aae5d7c69  pop r9
0000713aae5d7c6b  pop r8
0000713aae5d7c6d  pop rsi
0000713aae5d7c6e  pop rdi
0000713aae5d7c6f  pop rdx
0000713aae5d7c70  pop rcx
0000713aae5d7c71  pop rax
0000713aae5d7c72  add rsp, 0x08
0000713aae5d7c76  jmp 0x0000713AAE5D683C
0000713aae5d7c7b  sub rsp, 0x08
0000713aae5d7c7f  push rax
0000713aae5d7c80  push rcx
0000713aae5d7c81  push rdx
0000713aae5d7c82  push rdi
0000713aae5d7c83  push rsi
0000713aae5d7c84  push r8
0000713aae5d7c86  push r9
0000713aae5d7c88  push r10
0000713aae5d7c8a  push r11
0000713aae5d7c8c  sub rsp, 0xF0
0000713aae5d7c93  vmovaps [rsp], xmm0
0000713aae5d7c98  vmovaps [rsp+0x10], xmm1
0000713aae5d7c9e  vmovaps [rsp+0x20], xmm2
0000713aae5d7ca4  vmovaps [rsp+0x30], xmm3
0000713aae5d7caa  vmovaps [rsp+0x40], xmm4
0000713aae5d7cb0  vmovaps [rsp+0x50], xmm5
0000713aae5d7cb6  vmovaps [rsp+0x60], xmm6
0000713aae5d7cbc  vmovaps [rsp+0x70], xmm7
0000713aae5d7cc2  vmovaps [rsp+0x80], xmm8
0000713aae5d7ccb  vmovaps [rsp+0x90], xmm9
0000713aae5d7cd4  vmovaps [rsp+0xA0], xmm10
0000713aae5d7cdd  vmovaps [rsp+0xB0], xmm11
0000713aae5d7ce6  vmovaps [rsp+0xC0], xmm12
0000713aae5d7cef  vmovaps [rsp+0xD0], xmm14
0000713aae5d7cf8  vmovaps [rsp+0xE0], xmm15
0000713aae5d7d01  sub rsp, 0x40
0000713aae5d7d05  lea rdi, [rsp]
0000713aae5d7d09  lea rsi, [rsp+0x10]
0000713aae5d7d0e  lea rdx, [rsp+0x20]
0000713aae5d7d13  lea rcx, [rsp+0x30]
0000713aae5d7d18  mov r8d, 0x00
0000713aae5d7d1e  lea r9, [r15+0x3A8]
0000713aae5d7d25  movaps [rdi], xmm13
0000713aae5d7d29  movaps [rsi], xmm12
0000713aae5d7d2d  movaps [rdx], xmm14
0000713aae5d7d31  movaps [rcx], xmm1
0000713aae5d7d34  mov rax, 0x5E9381C89A50
0000713aae5d7d3e  call rax
0000713aae5d7d40  movaps xmm13, [rsp]
0000713aae5d7d45  add rsp, 0x40
0000713aae5d7d49  vmovaps xmm0, [rsp]
0000713aae5d7d4e  vmovaps xmm1, [rsp+0x10]
0000713aae5d7d54  vmovaps xmm2, [rsp+0x20]
0000713aae5d7d5a  vmovaps xmm3, [rsp+0x30]
0000713aae5d7d60  vmovaps xmm4, [rsp+0x40]
0000713aae5d7d66  vmovaps xmm5, [rsp+0x50]
0000713aae5d7d6c  vmovaps xmm6, [rsp+0x60]
0000713aae5d7d72  vmovaps xmm7, [rsp+0x70]
0000713aae5d7d78  vmovaps xmm8, [rsp+0x80]
0000713aae5d7d81  vmovaps xmm9, [rsp+0x90]
0000713aae5d7d8a  vmovaps xmm10, [rsp+0xA0]
0000713aae5d7d93  vmovaps xmm11, [rsp+0xB0]
0000713aae5d7d9c  vmovaps xmm12, [rsp+0xC0]
0000713aae5d7da5  vmovaps xmm14, [rsp+0xD0]
0000713aae5d7dae  vmovaps xmm15, [rsp+0xE0]
0000713aae5d7db7  add rsp, 0xF0
0000713aae5d7dbe  pop r11
0000713aae5d7dc0  pop r10
0000713aae5d7dc2  pop r9
0000713aae5d7dc4  pop r8
0000713aae5d7dc6  pop rsi
0000713aae5d7dc7  pop rdi
0000713aae5d7dc8  pop rdx
0000713aae5d7dc9  pop rcx
0000713aae5d7dca  pop rax
0000713aae5d7dcb  add rsp, 0x08
0000713aae5d7dcf  jmp 0x0000713AAE5D686E
0000713aae5d7dd4  sub rsp, 0x08
0000713aae5d7dd8  push rax
0000713aae5d7dd9  push rcx
0000713aae5d7dda  push rdx
0000713aae5d7ddb  push rdi
0000713aae5d7ddc  push rsi
0000713aae5d7ddd  push r8
0000713aae5d7ddf  push r9
0000713aae5d7de1  push r10
0000713aae5d7de3  push r11
0000713aae5d7de5  sub rsp, 0xF0
0000713aae5d7dec  vmovaps [rsp], xmm0
0000713aae5d7df1  vmovaps [rsp+0x10], xmm1
0000713aae5d7df7  vmovaps [rsp+0x20], xmm2
0000713aae5d7dfd  vmovaps [rsp+0x30], xmm3
0000713aae5d7e03  vmovaps [rsp+0x40], xmm4
0000713aae5d7e09  vmovaps [rsp+0x50], xmm5
0000713aae5d7e0f  vmovaps [rsp+0x60], xmm6
0000713aae5d7e15  vmovaps [rsp+0x70], xmm7
0000713aae5d7e1b  vmovaps [rsp+0x80], xmm8
0000713aae5d7e24  vmovaps [rsp+0x90], xmm9
0000713aae5d7e2d  vmovaps [rsp+0xA0], xmm10
0000713aae5d7e36  vmovaps [rsp+0xB0], xmm11
0000713aae5d7e3f  vmovaps [rsp+0xC0], xmm13
0000713aae5d7e48  vmovaps [rsp+0xD0], xmm14
0000713aae5d7e51  vmovaps [rsp+0xE0], xmm15
0000713aae5d7e5a  sub rsp, 0x40
0000713aae5d7e5e  lea rdi, [rsp]
0000713aae5d7e62  lea rsi, [rsp+0x10]
0000713aae5d7e67  lea rdx, [rsp+0x20]
0000713aae5d7e6c  lea rcx, [rsp+0x30]
0000713aae5d7e71  mov r8d, 0x00
0000713aae5d7e77  lea r9, [r15+0x3A8]
0000713aae5d7e7e  movaps [rdi], xmm12
0000713aae5d7e82  movaps [rsi], xmm3
0000713aae5d7e85  movaps [rdx], xmm14
0000713aae5d7e89  movaps [rcx], xmm5
0000713aae5d7e8c  mov rax, 0x5E9381C89A50
0000713aae5d7e96  call rax
0000713aae5d7e98  movaps xmm12, [rsp]
0000713aae5d7e9d  add rsp, 0x40
0000713aae5d7ea1  vmovaps xmm0, [rsp]
0000713aae5d7ea6  vmovaps xmm1, [rsp+0x10]
0000713aae5d7eac  vmovaps xmm2, [rsp+0x20]
0000713aae5d7eb2  vmovaps xmm3, [rsp+0x30]
0000713aae5d7eb8  vmovaps xmm4, [rsp+0x40]
0000713aae5d7ebe  vmovaps xmm5, [rsp+0x50]
0000713aae5d7ec4  vmovaps xmm6, [rsp+0x60]
0000713aae5d7eca  vmovaps xmm7, [rsp+0x70]
0000713aae5d7ed0  vmovaps xmm8, [rsp+0x80]
0000713aae5d7ed9  vmovaps xmm9, [rsp+0x90]
0000713aae5d7ee2  vmovaps xmm10, [rsp+0xA0]
0000713aae5d7eeb  vmovaps xmm11, [rsp+0xB0]
0000713aae5d7ef4  vmovaps xmm13, [rsp+0xC0]
0000713aae5d7efd  vmovaps xmm14, [rsp+0xD0]
0000713aae5d7f06  vmovaps xmm15, [rsp+0xE0]
0000713aae5d7f0f  add rsp, 0xF0
0000713aae5d7f16  pop r11
0000713aae5d7f18  pop r10
0000713aae5d7f1a  pop r9
0000713aae5d7f1c  pop r8
0000713aae5d7f1e  pop rsi
0000713aae5d7f1f  pop rdi
0000713aae5d7f20  pop rdx
0000713aae5d7f21  pop rcx
0000713aae5d7f22  pop rax
0000713aae5d7f23  add rsp, 0x08
0000713aae5d7f27  jmp 0x0000713AAE5D68CB
0000713aae5d7f2c  sub rsp, 0x08
0000713aae5d7f30  push rax
0000713aae5d7f31  push rcx
0000713aae5d7f32  push rdx
0000713aae5d7f33  push rdi
0000713aae5d7f34  push rsi
0000713aae5d7f35  push r8
0000713aae5d7f37  push r9
0000713aae5d7f39  push r10
0000713aae5d7f3b  push r11
0000713aae5d7f3d  sub rsp, 0xF0
0000713aae5d7f44  vmovaps [rsp], xmm0
0000713aae5d7f49  vmovaps [rsp+0x10], xmm1
0000713aae5d7f4f  vmovaps [rsp+0x20], xmm2
0000713aae5d7f55  vmovaps [rsp+0x30], xmm3
0000713aae5d7f5b  vmovaps [rsp+0x40], xmm4
0000713aae5d7f61  vmovaps [rsp+0x50], xmm5
0000713aae5d7f67  vmovaps [rsp+0x60], xmm6
0000713aae5d7f6d  vmovaps [rsp+0x70], xmm7
0000713aae5d7f73  vmovaps [rsp+0x80], xmm8
0000713aae5d7f7c  vmovaps [rsp+0x90], xmm9
0000713aae5d7f85  vmovaps [rsp+0xA0], xmm11
0000713aae5d7f8e  vmovaps [rsp+0xB0], xmm12
0000713aae5d7f97  vmovaps [rsp+0xC0], xmm13
0000713aae5d7fa0  vmovaps [rsp+0xD0], xmm14
0000713aae5d7fa9  vmovaps [rsp+0xE0], xmm15
0000713aae5d7fb2  sub rsp, 0x40
0000713aae5d7fb6  lea rdi, [rsp]
0000713aae5d7fba  lea rsi, [rsp+0x10]
0000713aae5d7fbf  lea rdx, [rsp+0x20]
0000713aae5d7fc4  lea rcx, [rsp+0x30]
0000713aae5d7fc9  mov r8d, 0x00
0000713aae5d7fcf  lea r9, [r15+0x3A8]
0000713aae5d7fd6  movaps [rdi], xmm10
0000713aae5d7fda  movaps [rsi], xmm9
0000713aae5d7fde  movaps [rdx], xmm7
0000713aae5d7fe1  movaps [rcx], xmm14
0000713aae5d7fe5  mov rax, 0x5E9381C89A50
0000713aae5d7fef  call rax
0000713aae5d7ff1  movaps xmm10, [rsp]
0000713aae5d7ff6  add rsp, 0x40
0000713aae5d7ffa  vmovaps xmm0, [rsp]
0000713aae5d7fff  vmovaps xmm1, [rsp+0x10]
0000713aae5d8005  vmovaps xmm2, [rsp+0x20]
0000713aae5d800b  vmovaps xmm3, [rsp+0x30]
0000713aae5d8011  vmovaps xmm4, [rsp+0x40]
0000713aae5d8017  vmovaps xmm5, [rsp+0x50]
0000713aae5d801d  vmovaps xmm6, [rsp+0x60]
0000713aae5d8023  vmovaps xmm7, [rsp+0x70]
0000713aae5d8029  vmovaps xmm8, [rsp+0x80]
0000713aae5d8032  vmovaps xmm9, [rsp+0x90]
0000713aae5d803b  vmovaps xmm11, [rsp+0xA0]
0000713aae5d8044  vmovaps xmm12, [rsp+0xB0]
0000713aae5d804d  vmovaps xmm13, [rsp+0xC0]
0000713aae5d8056  vmovaps xmm14, [rsp+0xD0]
0000713aae5d805f  vmovaps xmm15, [rsp+0xE0]
0000713aae5d8068  add rsp, 0xF0
0000713aae5d806f  pop r11
0000713aae5d8071  pop r10
0000713aae5d8073  pop r9
0000713aae5d8075  pop r8
0000713aae5d8077  pop rsi
0000713aae5d8078  pop rdi
0000713aae5d8079  pop rdx
0000713aae5d807a  pop rcx
0000713aae5d807b  pop rax
0000713aae5d807c  add rsp, 0x08
0000713aae5d8080  jmp 0x0000713AAE5D68F1
0000713aae5d8085  call 0x0000713AAE4E45A0
0000713aae5d808a  jmp 0x0000713AAE5D68FE
0000713aae5d808f  sub rsp, 0x08
0000713aae5d8093  push rax
0000713aae5d8094  push rcx
0000713aae5d8095  push rdx
0000713aae5d8096  push rdi
0000713aae5d8097  push rsi
0000713aae5d8098  push r8
0000713aae5d809a  push r9
0000713aae5d809c  push r10
0000713aae5d809e  push r11
0000713aae5d80a0  sub rsp, 0xF0
0000713aae5d80a7  vmovaps [rsp], xmm0
0000713aae5d80ac  vmovaps [rsp+0x10], xmm1
0000713aae5d80b2  vmovaps [rsp+0x20], xmm2
0000713aae5d80b8  vmovaps [rsp+0x30], xmm3
0000713aae5d80be  vmovaps [rsp+0x40], xmm4
0000713aae5d80c4  vmovaps [rsp+0x50], xmm6
0000713aae5d80ca  vmovaps [rsp+0x60], xmm7
0000713aae5d80d0  vmovaps [rsp+0x70], xmm8
0000713aae5d80d6  vmovaps [rsp+0x80], xmm9
0000713aae5d80df  vmovaps [rsp+0x90], xmm10
0000713aae5d80e8  vmovaps [rsp+0xA0], xmm11
0000713aae5d80f1  vmovaps [rsp+0xB0], xmm12
0000713aae5d80fa  vmovaps [rsp+0xC0], xmm13
0000713aae5d8103  vmovaps [rsp+0xD0], xmm14
0000713aae5d810c  vmovaps [rsp+0xE0], xmm15
0000713aae5d8115  sub rsp, 0x40
0000713aae5d8119  lea rdi, [rsp]
0000713aae5d811d  lea rsi, [rsp+0x10]
0000713aae5d8122  lea rdx, [rsp+0x20]
0000713aae5d8127  lea rcx, [rsp+0x30]
0000713aae5d812c  mov r8d, 0x00
0000713aae5d8132  lea r9, [r15+0x3A8]
0000713aae5d8139  movaps [rdi], xmm5
0000713aae5d813c  movaps [rsi], xmm6
0000713aae5d813f  movaps [rdx], xmm7
0000713aae5d8142  movaps [rcx], xmm9
0000713aae5d8146  mov rax, 0x5E9381C89A50
0000713aae5d8150  call rax
0000713aae5d8152  movaps xmm5, [rsp]
0000713aae5d8156  add rsp, 0x40
0000713aae5d815a  vmovaps xmm0, [rsp]
0000713aae5d815f  vmovaps xmm1, [rsp+0x10]
0000713aae5d8165  vmovaps xmm2, [rsp+0x20]
0000713aae5d816b  vmovaps xmm3, [rsp+0x30]
0000713aae5d8171  vmovaps xmm4, [rsp+0x40]
0000713aae5d8177  vmovaps xmm6, [rsp+0x50]
0000713aae5d817d  vmovaps xmm7, [rsp+0x60]
0000713aae5d8183  vmovaps xmm8, [rsp+0x70]
0000713aae5d8189  vmovaps xmm9, [rsp+0x80]
0000713aae5d8192  vmovaps xmm10, [rsp+0x90]
0000713aae5d819b  vmovaps xmm11, [rsp+0xA0]
0000713aae5d81a4  vmovaps xmm12, [rsp+0xB0]
0000713aae5d81ad  vmovaps xmm13, [rsp+0xC0]
0000713aae5d81b6  vmovaps xmm14, [rsp+0xD0]
0000713aae5d81bf  vmovaps xmm15, [rsp+0xE0]
0000713aae5d81c8  add rsp, 0xF0
0000713aae5d81cf  pop r11
0000713aae5d81d1  pop r10
0000713aae5d81d3  pop r9
0000713aae5d81d5  pop r8
0000713aae5d81d7  pop rsi
0000713aae5d81d8  pop rdi
0000713aae5d81d9  pop rdx
0000713aae5d81da  pop rcx
0000713aae5d81db  pop rax
0000713aae5d81dc  add rsp, 0x08
0000713aae5d81e0  jmp 0x0000713AAE5D6930
0000713aae5d81e5  sub rsp, 0x08
0000713aae5d81e9  push rax
0000713aae5d81ea  push rcx
0000713aae5d81eb  push rdx
0000713aae5d81ec  push rdi
0000713aae5d81ed  push rsi
0000713aae5d81ee  push r8
0000713aae5d81f0  push r9
0000713aae5d81f2  push r10
0000713aae5d81f4  push r11
0000713aae5d81f6  sub rsp, 0xF0
0000713aae5d81fd  vmovaps [rsp], xmm0
0000713aae5d8202  vmovaps [rsp+0x10], xmm1
0000713aae5d8208  vmovaps [rsp+0x20], xmm2
0000713aae5d820e  vmovaps [rsp+0x30], xmm3
0000713aae5d8214  vmovaps [rsp+0x40], xmm4
0000713aae5d821a  vmovaps [rsp+0x50], xmm5
0000713aae5d8220  vmovaps [rsp+0x60], xmm6
0000713aae5d8226  vmovaps [rsp+0x70], xmm8
0000713aae5d822c  vmovaps [rsp+0x80], xmm9
0000713aae5d8235  vmovaps [rsp+0x90], xmm10
0000713aae5d823e  vmovaps [rsp+0xA0], xmm11
0000713aae5d8247  vmovaps [rsp+0xB0], xmm12
0000713aae5d8250  vmovaps [rsp+0xC0], xmm13
0000713aae5d8259  vmovaps [rsp+0xD0], xmm14
0000713aae5d8262  vmovaps [rsp+0xE0], xmm15
0000713aae5d826b  sub rsp, 0x40
0000713aae5d826f  lea rdi, [rsp]
0000713aae5d8273  lea rsi, [rsp+0x10]
0000713aae5d8278  lea rdx, [rsp+0x20]
0000713aae5d827d  lea rcx, [rsp+0x30]
0000713aae5d8282  mov r8d, 0x00
0000713aae5d8288  lea r9, [r15+0x3A8]
0000713aae5d828f  movaps [rdi], xmm7
0000713aae5d8292  movaps [rsi], xmm13
0000713aae5d8296  movaps [rdx], xmm1
0000713aae5d8299  movaps [rcx], xmm9
0000713aae5d829d  mov rax, 0x5E9381C89A50
0000713aae5d82a7  call rax
0000713aae5d82a9  movaps xmm7, [rsp]
0000713aae5d82ad  add rsp, 0x40
0000713aae5d82b1  vmovaps xmm0, [rsp]
0000713aae5d82b6  vmovaps xmm1, [rsp+0x10]
0000713aae5d82bc  vmovaps xmm2, [rsp+0x20]
0000713aae5d82c2  vmovaps xmm3, [rsp+0x30]
0000713aae5d82c8  vmovaps xmm4, [rsp+0x40]
0000713aae5d82ce  vmovaps xmm5, [rsp+0x50]
0000713aae5d82d4  vmovaps xmm6, [rsp+0x60]
0000713aae5d82da  vmovaps xmm8, [rsp+0x70]
0000713aae5d82e0  vmovaps xmm9, [rsp+0x80]
0000713aae5d82e9  vmovaps xmm10, [rsp+0x90]
0000713aae5d82f2  vmovaps xmm11, [rsp+0xA0]
0000713aae5d82fb  vmovaps xmm12, [rsp+0xB0]
0000713aae5d8304  vmovaps xmm13, [rsp+0xC0]
0000713aae5d830d  vmovaps xmm14, [rsp+0xD0]
0000713aae5d8316  vmovaps xmm15, [rsp+0xE0]
0000713aae5d831f  add rsp, 0xF0
0000713aae5d8326  pop r11
0000713aae5d8328  pop r10
0000713aae5d832a  pop r9
0000713aae5d832c  pop r8
0000713aae5d832e  pop rsi
0000713aae5d832f  pop rdi
0000713aae5d8330  pop rdx
0000713aae5d8331  pop rcx
0000713aae5d8332  pop rax
0000713aae5d8333  add rsp, 0x08
0000713aae5d8337  jmp 0x0000713AAE5D6955
0000713aae5d833c  call 0x0000713AAE4E3320
0000713aae5d8341  jmp 0x0000713AAE5D6978
0000713aae5d8346  call 0x0000713AAE4DE950
0000713aae5d834b  jmp 0x0000713AAE5D6982
0000713aae5d8350  sub rsp, 0x08
0000713aae5d8354  push rax
0000713aae5d8355  push rcx
0000713aae5d8356  push rdx
0000713aae5d8357  push rdi
0000713aae5d8358  push rsi
0000713aae5d8359  push r8
0000713aae5d835b  push r9
0000713aae5d835d  push r10
0000713aae5d835f  push r11
0000713aae5d8361  sub rsp, 0xF0
0000713aae5d8368  vmovaps [rsp], xmm0
0000713aae5d836d  vmovaps [rsp+0x10], xmm1
0000713aae5d8373  vmovaps [rsp+0x20], xmm3
0000713aae5d8379  vmovaps [rsp+0x30], xmm4
0000713aae5d837f  vmovaps [rsp+0x40], xmm5
0000713aae5d8385  vmovaps [rsp+0x50], xmm6
0000713aae5d838b  vmovaps [rsp+0x60], xmm7
0000713aae5d8391  vmovaps [rsp+0x70], xmm8
0000713aae5d8397  vmovaps [rsp+0x80], xmm9
0000713aae5d83a0  vmovaps [rsp+0x90], xmm10
0000713aae5d83a9  vmovaps [rsp+0xA0], xmm11
0000713aae5d83b2  vmovaps [rsp+0xB0], xmm12
0000713aae5d83bb  vmovaps [rsp+0xC0], xmm13
0000713aae5d83c4  vmovaps [rsp+0xD0], xmm14
0000713aae5d83cd  vmovaps [rsp+0xE0], xmm15
0000713aae5d83d6  sub rsp, 0x40
0000713aae5d83da  lea rdi, [rsp]
0000713aae5d83de  lea rsi, [rsp+0x10]
0000713aae5d83e3  lea rdx, [rsp+0x20]
0000713aae5d83e8  lea rcx, [rsp+0x30]
0000713aae5d83ed  mov r8d, 0x00
0000713aae5d83f3  lea r9, [r15+0x3A8]
0000713aae5d83fa  movaps [rdi], xmm2
0000713aae5d83fd  movaps [rsi], xmm12
0000713aae5d8401  movaps [rdx], xmm6
0000713aae5d8404  movaps [rcx], xmm3
0000713aae5d8407  mov rax, 0x5E9381C89A50
0000713aae5d8411  call rax
0000713aae5d8413  movaps xmm2, [rsp]
0000713aae5d8417  add rsp, 0x40
0000713aae5d841b  vmovaps xmm0, [rsp]
0000713aae5d8420  vmovaps xmm1, [rsp+0x10]
0000713aae5d8426  vmovaps xmm3, [rsp+0x20]
0000713aae5d842c  vmovaps xmm4, [rsp+0x30]
0000713aae5d8432  vmovaps xmm5, [rsp+0x40]
0000713aae5d8438  vmovaps xmm6, [rsp+0x50]
0000713aae5d843e  vmovaps xmm7, [rsp+0x60]
0000713aae5d8444  vmovaps xmm8, [rsp+0x70]
0000713aae5d844a  vmovaps xmm9, [rsp+0x80]
0000713aae5d8453  vmovaps xmm10, [rsp+0x90]
0000713aae5d845c  vmovaps xmm11, [rsp+0xA0]
0000713aae5d8465  vmovaps xmm12, [rsp+0xB0]
0000713aae5d846e  vmovaps xmm13, [rsp+0xC0]
0000713aae5d8477  vmovaps xmm14, [rsp+0xD0]
0000713aae5d8480  vmovaps xmm15, [rsp+0xE0]
0000713aae5d8489  add rsp, 0xF0
0000713aae5d8490  pop r11
0000713aae5d8492  pop r10
0000713aae5d8494  pop r9
0000713aae5d8496  pop r8
0000713aae5d8498  pop rsi
0000713aae5d8499  pop rdi
0000713aae5d849a  pop rdx
0000713aae5d849b  pop rcx
0000713aae5d849c  pop rax
0000713aae5d849d  add rsp, 0x08
0000713aae5d84a1  jmp 0x0000713AAE5D69C8
0000713aae5d84a6  sub rsp, 0x08
0000713aae5d84aa  push rax
0000713aae5d84ab  push rcx
0000713aae5d84ac  push rdx
0000713aae5d84ad  push rdi
0000713aae5d84ae  push rsi
0000713aae5d84af  push r8
0000713aae5d84b1  push r9
0000713aae5d84b3  push r10
0000713aae5d84b5  push r11
0000713aae5d84b7  sub rsp, 0xF0
0000713aae5d84be  vmovaps [rsp], xmm0
0000713aae5d84c3  vmovaps [rsp+0x10], xmm1
0000713aae5d84c9  vmovaps [rsp+0x20], xmm2
0000713aae5d84cf  vmovaps [rsp+0x30], xmm3
0000713aae5d84d5  vmovaps [rsp+0x40], xmm4
0000713aae5d84db  vmovaps [rsp+0x50], xmm5
0000713aae5d84e1  vmovaps [rsp+0x60], xmm7
0000713aae5d84e7  vmovaps [rsp+0x70], xmm8
0000713aae5d84ed  vmovaps [rsp+0x80], xmm9
0000713aae5d84f6  vmovaps [rsp+0x90], xmm10
0000713aae5d84ff  vmovaps [rsp+0xA0], xmm11
0000713aae5d8508  vmovaps [rsp+0xB0], xmm12
0000713aae5d8511  vmovaps [rsp+0xC0], xmm13
0000713aae5d851a  vmovaps [rsp+0xD0], xmm14
0000713aae5d8523  vmovaps [rsp+0xE0], xmm15
0000713aae5d852c  sub rsp, 0x40
0000713aae5d8530  lea rdi, [rsp]
0000713aae5d8534  lea rsi, [rsp+0x10]
0000713aae5d8539  lea rdx, [rsp+0x20]
0000713aae5d853e  lea rcx, [rsp+0x30]
0000713aae5d8543  mov r8d, 0x00
0000713aae5d8549  lea r9, [r15+0x3A8]
0000713aae5d8550  movaps [rdi], xmm6
0000713aae5d8553  movaps [rsi], xmm10
0000713aae5d8557  movaps [rdx], xmm12
0000713aae5d855b  movaps [rcx], xmm1
0000713aae5d855e  mov rax, 0x5E9381C89A50
0000713aae5d8568  call rax
0000713aae5d856a  movaps xmm6, [rsp]
0000713aae5d856e  add rsp, 0x40
0000713aae5d8572  vmovaps xmm0, [rsp]
0000713aae5d8577  vmovaps xmm1, [rsp+0x10]
0000713aae5d857d  vmovaps xmm2, [rsp+0x20]
0000713aae5d8583  vmovaps xmm3, [rsp+0x30]
0000713aae5d8589  vmovaps xmm4, [rsp+0x40]
0000713aae5d858f  vmovaps xmm5, [rsp+0x50]
0000713aae5d8595  vmovaps xmm7, [rsp+0x60]
0000713aae5d859b  vmovaps xmm8, [rsp+0x70]
0000713aae5d85a1  vmovaps xmm9, [rsp+0x80]
0000713aae5d85aa  vmovaps xmm10, [rsp+0x90]
0000713aae5d85b3  vmovaps xmm11, [rsp+0xA0]
0000713aae5d85bc  vmovaps xmm12, [rsp+0xB0]
0000713aae5d85c5  vmovaps xmm13, [rsp+0xC0]
0000713aae5d85ce  vmovaps xmm14, [rsp+0xD0]
0000713aae5d85d7  vmovaps xmm15, [rsp+0xE0]
0000713aae5d85e0  add rsp, 0xF0
0000713aae5d85e7  pop r11
0000713aae5d85e9  pop r10
0000713aae5d85eb  pop r9
0000713aae5d85ed  pop r8
0000713aae5d85ef  pop rsi
0000713aae5d85f0  pop rdi
0000713aae5d85f1  pop rdx
0000713aae5d85f2  pop rcx
0000713aae5d85f3  pop rax
0000713aae5d85f4  add rsp, 0x08
0000713aae5d85f8  jmp 0x0000713AAE5D69F6
0000713aae5d85fd  sub rsp, 0x08
0000713aae5d8601  push rax
0000713aae5d8602  push rcx
0000713aae5d8603  push rdx
0000713aae5d8604  push rdi
0000713aae5d8605  push rsi
0000713aae5d8606  push r8
0000713aae5d8608  push r9
0000713aae5d860a  push r10
0000713aae5d860c  push r11
0000713aae5d860e  sub rsp, 0xF0
0000713aae5d8615  vmovaps [rsp], xmm0
0000713aae5d861a  vmovaps [rsp+0x10], xmm1
0000713aae5d8620  vmovaps [rsp+0x20], xmm2
0000713aae5d8626  vmovaps [rsp+0x30], xmm3
0000713aae5d862c  vmovaps [rsp+0x40], xmm4
0000713aae5d8632  vmovaps [rsp+0x50], xmm5
0000713aae5d8638  vmovaps [rsp+0x60], xmm6
0000713aae5d863e  vmovaps [rsp+0x70], xmm7
0000713aae5d8644  vmovaps [rsp+0x80], xmm8
0000713aae5d864d  vmovaps [rsp+0x90], xmm9
0000713aae5d8656  vmovaps [rsp+0xA0], xmm11
0000713aae5d865f  vmovaps [rsp+0xB0], xmm12
0000713aae5d8668  vmovaps [rsp+0xC0], xmm13
0000713aae5d8671  vmovaps [rsp+0xD0], xmm14
0000713aae5d867a  vmovaps [rsp+0xE0], xmm15
0000713aae5d8683  sub rsp, 0x40
0000713aae5d8687  lea rdi, [rsp]
0000713aae5d868b  lea rsi, [rsp+0x10]
0000713aae5d8690  lea rdx, [rsp+0x20]
0000713aae5d8695  lea rcx, [rsp+0x30]
0000713aae5d869a  mov r8d, 0x00
0000713aae5d86a0  lea r9, [r15+0x3A8]
0000713aae5d86a7  movaps [rdi], xmm10
0000713aae5d86ab  movaps [rsi], xmm5
0000713aae5d86ae  movaps [rdx], xmm12
0000713aae5d86b2  movaps [rcx], xmm1
0000713aae5d86b5  mov rax, 0x5E9381C89A50
0000713aae5d86bf  call rax
0000713aae5d86c1  movaps xmm10, [rsp]
0000713aae5d86c6  add rsp, 0x40
0000713aae5d86ca  vmovaps xmm0, [rsp]
0000713aae5d86cf  vmovaps xmm1, [rsp+0x10]
0000713aae5d86d5  vmovaps xmm2, [rsp+0x20]
0000713aae5d86db  vmovaps xmm3, [rsp+0x30]
0000713aae5d86e1  vmovaps xmm4, [rsp+0x40]
0000713aae5d86e7  vmovaps xmm5, [rsp+0x50]
0000713aae5d86ed  vmovaps xmm6, [rsp+0x60]
0000713aae5d86f3  vmovaps xmm7, [rsp+0x70]
0000713aae5d86f9  vmovaps xmm8, [rsp+0x80]
0000713aae5d8702  vmovaps xmm9, [rsp+0x90]
0000713aae5d870b  vmovaps xmm11, [rsp+0xA0]
0000713aae5d8714  vmovaps xmm12, [rsp+0xB0]
0000713aae5d871d  vmovaps xmm13, [rsp+0xC0]
0000713aae5d8726  vmovaps xmm14, [rsp+0xD0]
0000713aae5d872f  vmovaps xmm15, [rsp+0xE0]
0000713aae5d8738  add rsp, 0xF0
0000713aae5d873f  pop r11
0000713aae5d8741  pop r10
0000713aae5d8743  pop r9
0000713aae5d8745  pop r8
0000713aae5d8747  pop rsi
0000713aae5d8748  pop rdi
0000713aae5d8749  pop rdx
0000713aae5d874a  pop rcx
0000713aae5d874b  pop rax
0000713aae5d874c  add rsp, 0x08
0000713aae5d8750  jmp 0x0000713AAE5D6A25
0000713aae5d8755  sub rsp, 0x08
0000713aae5d8759  push rax
0000713aae5d875a  push rcx
0000713aae5d875b  push rdx
0000713aae5d875c  push rdi
0000713aae5d875d  push rsi
0000713aae5d875e  push r8
0000713aae5d8760  push r9
0000713aae5d8762  push r10
0000713aae5d8764  push r11
0000713aae5d8766  sub rsp, 0xF0
0000713aae5d876d  vmovaps [rsp], xmm0
0000713aae5d8772  vmovaps [rsp+0x10], xmm1
0000713aae5d8778  vmovaps [rsp+0x20], xmm2
0000713aae5d877e  vmovaps [rsp+0x30], xmm3
0000713aae5d8784  vmovaps [rsp+0x40], xmm4
0000713aae5d878a  vmovaps [rsp+0x50], xmm5
0000713aae5d8790  vmovaps [rsp+0x60], xmm6
0000713aae5d8796  vmovaps [rsp+0x70], xmm7
0000713aae5d879c  vmovaps [rsp+0x80], xmm8
0000713aae5d87a5  vmovaps [rsp+0x90], xmm9
0000713aae5d87ae  vmovaps [rsp+0xA0], xmm10
0000713aae5d87b7  vmovaps [rsp+0xB0], xmm11
0000713aae5d87c0  vmovaps [rsp+0xC0], xmm13
0000713aae5d87c9  vmovaps [rsp+0xD0], xmm14
0000713aae5d87d2  vmovaps [rsp+0xE0], xmm15
0000713aae5d87db  sub rsp, 0x40
0000713aae5d87df  lea rdi, [rsp]
0000713aae5d87e3  lea rsi, [rsp+0x10]
0000713aae5d87e8  lea rdx, [rsp+0x20]
0000713aae5d87ed  lea rcx, [rsp+0x30]
0000713aae5d87f2  mov r8d, 0x00
0000713aae5d87f8  lea r9, [r15+0x3A8]
0000713aae5d87ff  movaps [rdi], xmm12
0000713aae5d8803  movaps [rsi], xmm7
0000713aae5d8806  movaps [rdx], xmm15
0000713aae5d880a  movaps [rcx], xmm1
0000713aae5d880d  mov rax, 0x5E9381C89A50
0000713aae5d8817  call rax
0000713aae5d8819  movaps xmm12, [rsp]
0000713aae5d881e  add rsp, 0x40
0000713aae5d8822  vmovaps xmm0, [rsp]
0000713aae5d8827  vmovaps xmm1, [rsp+0x10]
0000713aae5d882d  vmovaps xmm2, [rsp+0x20]
0000713aae5d8833  vmovaps xmm3, [rsp+0x30]
0000713aae5d8839  vmovaps xmm4, [rsp+0x40]
0000713aae5d883f  vmovaps xmm5, [rsp+0x50]
0000713aae5d8845  vmovaps xmm6, [rsp+0x60]
0000713aae5d884b  vmovaps xmm7, [rsp+0x70]
0000713aae5d8851  vmovaps xmm8, [rsp+0x80]
0000713aae5d885a  vmovaps xmm9, [rsp+0x90]
0000713aae5d8863  vmovaps xmm10, [rsp+0xA0]
0000713aae5d886c  vmovaps xmm11, [rsp+0xB0]
0000713aae5d8875  vmovaps xmm13, [rsp+0xC0]
0000713aae5d887e  vmovaps xmm14, [rsp+0xD0]
0000713aae5d8887  vmovaps xmm15, [rsp+0xE0]
0000713aae5d8890  add rsp, 0xF0
0000713aae5d8897  pop r11
0000713aae5d8899  pop r10
0000713aae5d889b  pop r9
0000713aae5d889d  pop r8
0000713aae5d889f  pop rsi
0000713aae5d88a0  pop rdi
0000713aae5d88a1  pop rdx
0000713aae5d88a2  pop rcx
0000713aae5d88a3  pop rax
0000713aae5d88a4  add rsp, 0x08
0000713aae5d88a8  jmp 0x0000713AAE5D6A4E
0000713aae5d88ad  call 0x0000713AAE4D64F0
0000713aae5d88b2  jmp 0x0000713AAE5D6A58
0000713aae5d88b7  call 0x0000713AAE4E5820
0000713aae5d88bc  jmp 0x0000713AAE5D6A62
0000713aae5d88c1  sub rsp, 0x08
0000713aae5d88c5  push rax
0000713aae5d88c6  push rcx
0000713aae5d88c7  push rdx
0000713aae5d88c8  push rdi
0000713aae5d88c9  push rsi
0000713aae5d88ca  push r8
0000713aae5d88cc  push r9
0000713aae5d88ce  push r10
0000713aae5d88d0  push r11
0000713aae5d88d2  sub rsp, 0xF0
0000713aae5d88d9  vmovaps [rsp], xmm0
0000713aae5d88de  vmovaps [rsp+0x10], xmm1
0000713aae5d88e4  vmovaps [rsp+0x20], xmm2
0000713aae5d88ea  vmovaps [rsp+0x30], xmm3
0000713aae5d88f0  vmovaps [rsp+0x40], xmm4
0000713aae5d88f6  vmovaps [rsp+0x50], xmm5
0000713aae5d88fc  vmovaps [rsp+0x60], xmm6
0000713aae5d8902  vmovaps [rsp+0x70], xmm8
0000713aae5d8908  vmovaps [rsp+0x80], xmm9
0000713aae5d8911  vmovaps [rsp+0x90], xmm10
0000713aae5d891a  vmovaps [rsp+0xA0], xmm11
0000713aae5d8923  vmovaps [rsp+0xB0], xmm12
0000713aae5d892c  vmovaps [rsp+0xC0], xmm13
0000713aae5d8935  vmovaps [rsp+0xD0], xmm14
0000713aae5d893e  vmovaps [rsp+0xE0], xmm15
0000713aae5d8947  sub rsp, 0x40
0000713aae5d894b  lea rdi, [rsp]
0000713aae5d894f  lea rsi, [rsp+0x10]
0000713aae5d8954  lea rdx, [rsp+0x20]
0000713aae5d8959  lea rcx, [rsp+0x30]
0000713aae5d895e  mov r8d, 0x00
0000713aae5d8964  lea r9, [r15+0x3A8]
0000713aae5d896b  movaps [rdi], xmm7
0000713aae5d896e  movaps [rsi], xmm2
0000713aae5d8971  movaps [rdx], xmm9
0000713aae5d8975  movaps [rcx], xmm11
0000713aae5d8979  mov rax, 0x5E9381C89A50
0000713aae5d8983  call rax
0000713aae5d8985  movaps xmm7, [rsp]
0000713aae5d8989  add rsp, 0x40
0000713aae5d898d  vmovaps xmm0, [rsp]
0000713aae5d8992  vmovaps xmm1, [rsp+0x10]
0000713aae5d8998  vmovaps xmm2, [rsp+0x20]
0000713aae5d899e  vmovaps xmm3, [rsp+0x30]
0000713aae5d89a4  vmovaps xmm4, [rsp+0x40]
0000713aae5d89aa  vmovaps xmm5, [rsp+0x50]
0000713aae5d89b0  vmovaps xmm6, [rsp+0x60]
0000713aae5d89b6  vmovaps xmm8, [rsp+0x70]
0000713aae5d89bc  vmovaps xmm9, [rsp+0x80]
0000713aae5d89c5  vmovaps xmm10, [rsp+0x90]
0000713aae5d89ce  vmovaps xmm11, [rsp+0xA0]
0000713aae5d89d7  vmovaps xmm12, [rsp+0xB0]
0000713aae5d89e0  vmovaps xmm13, [rsp+0xC0]
0000713aae5d89e9  vmovaps xmm14, [rsp+0xD0]
0000713aae5d89f2  vmovaps xmm15, [rsp+0xE0]
0000713aae5d89fb  add rsp, 0xF0
0000713aae5d8a02  pop r11
0000713aae5d8a04  pop r10
0000713aae5d8a06  pop r9
0000713aae5d8a08  pop r8
0000713aae5d8a0a  pop rsi
0000713aae5d8a0b  pop rdi
0000713aae5d8a0c  pop rdx
0000713aae5d8a0d  pop rcx
0000713aae5d8a0e  pop rax
0000713aae5d8a0f  add rsp, 0x08
0000713aae5d8a13  jmp 0x0000713AAE5D6A96
0000713aae5d8a18  sub rsp, 0x08
0000713aae5d8a1c  push rax
0000713aae5d8a1d  push rcx
0000713aae5d8a1e  push rdx
0000713aae5d8a1f  push rdi
0000713aae5d8a20  push rsi
0000713aae5d8a21  push r8
0000713aae5d8a23  push r9
0000713aae5d8a25  push r10
0000713aae5d8a27  push r11
0000713aae5d8a29  sub rsp, 0xF0
0000713aae5d8a30  vmovaps [rsp], xmm0
0000713aae5d8a35  vmovaps [rsp+0x10], xmm1
0000713aae5d8a3b  vmovaps [rsp+0x20], xmm2
0000713aae5d8a41  vmovaps [rsp+0x30], xmm3
0000713aae5d8a47  vmovaps [rsp+0x40], xmm4
0000713aae5d8a4d  vmovaps [rsp+0x50], xmm5
0000713aae5d8a53  vmovaps [rsp+0x60], xmm6
0000713aae5d8a59  vmovaps [rsp+0x70], xmm7
0000713aae5d8a5f  vmovaps [rsp+0x80], xmm8
0000713aae5d8a68  vmovaps [rsp+0x90], xmm10
0000713aae5d8a71  vmovaps [rsp+0xA0], xmm11
0000713aae5d8a7a  vmovaps [rsp+0xB0], xmm12
0000713aae5d8a83  vmovaps [rsp+0xC0], xmm13
0000713aae5d8a8c  vmovaps [rsp+0xD0], xmm14
0000713aae5d8a95  vmovaps [rsp+0xE0], xmm15
0000713aae5d8a9e  sub rsp, 0x40
0000713aae5d8aa2  lea rdi, [rsp]
0000713aae5d8aa6  lea rsi, [rsp+0x10]
0000713aae5d8aab  lea rdx, [rsp+0x20]
0000713aae5d8ab0  lea rcx, [rsp+0x30]
0000713aae5d8ab5  mov r8d, 0x00
0000713aae5d8abb  lea r9, [r15+0x3A8]
0000713aae5d8ac2  movaps [rdi], xmm9
0000713aae5d8ac6  movaps [rsi], xmm6
0000713aae5d8ac9  movaps [rdx], xmm1
0000713aae5d8acc  movaps [rcx], xmm11
0000713aae5d8ad0  mov rax, 0x5E9381C89A50
0000713aae5d8ada  call rax
0000713aae5d8adc  movaps xmm9, [rsp]
0000713aae5d8ae1  add rsp, 0x40
0000713aae5d8ae5  vmovaps xmm0, [rsp]
0000713aae5d8aea  vmovaps xmm1, [rsp+0x10]
0000713aae5d8af0  vmovaps xmm2, [rsp+0x20]
0000713aae5d8af6  vmovaps xmm3, [rsp+0x30]
0000713aae5d8afc  vmovaps xmm4, [rsp+0x40]
0000713aae5d8b02  vmovaps xmm5, [rsp+0x50]
0000713aae5d8b08  vmovaps xmm6, [rsp+0x60]
0000713aae5d8b0e  vmovaps xmm7, [rsp+0x70]
0000713aae5d8b14  vmovaps xmm8, [rsp+0x80]
0000713aae5d8b1d  vmovaps xmm10, [rsp+0x90]
0000713aae5d8b26  vmovaps xmm11, [rsp+0xA0]
0000713aae5d8b2f  vmovaps xmm12, [rsp+0xB0]
0000713aae5d8b38  vmovaps xmm13, [rsp+0xC0]
0000713aae5d8b41  vmovaps xmm14, [rsp+0xD0]
0000713aae5d8b4a  vmovaps xmm15, [rsp+0xE0]
0000713aae5d8b53  add rsp, 0xF0
0000713aae5d8b5a  pop r11
0000713aae5d8b5c  pop r10
0000713aae5d8b5e  pop r9
0000713aae5d8b60  pop r8
0000713aae5d8b62  pop rsi
0000713aae5d8b63  pop rdi
0000713aae5d8b64  pop rdx
0000713aae5d8b65  pop rcx
0000713aae5d8b66  pop rax
0000713aae5d8b67  add rsp, 0x08
0000713aae5d8b6b  jmp 0x0000713AAE5D6ABC
0000713aae5d8b70  sub rsp, 0x08
0000713aae5d8b74  push rax
0000713aae5d8b75  push rcx
0000713aae5d8b76  push rdx
0000713aae5d8b77  push rdi
0000713aae5d8b78  push rsi
0000713aae5d8b79  push r8
0000713aae5d8b7b  push r9
0000713aae5d8b7d  push r10
0000713aae5d8b7f  push r11
0000713aae5d8b81  sub rsp, 0xF0
0000713aae5d8b88  vmovaps [rsp], xmm0
0000713aae5d8b8d  vmovaps [rsp+0x10], xmm1
0000713aae5d8b93  vmovaps [rsp+0x20], xmm2
0000713aae5d8b99  vmovaps [rsp+0x30], xmm3
0000713aae5d8b9f  vmovaps [rsp+0x40], xmm4
0000713aae5d8ba5  vmovaps [rsp+0x50], xmm5
0000713aae5d8bab  vmovaps [rsp+0x60], xmm6
0000713aae5d8bb1  vmovaps [rsp+0x70], xmm7
0000713aae5d8bb7  vmovaps [rsp+0x80], xmm8
0000713aae5d8bc0  vmovaps [rsp+0x90], xmm9
0000713aae5d8bc9  vmovaps [rsp+0xA0], xmm10
0000713aae5d8bd2  vmovaps [rsp+0xB0], xmm12
0000713aae5d8bdb  vmovaps [rsp+0xC0], xmm13
0000713aae5d8be4  vmovaps [rsp+0xD0], xmm14
0000713aae5d8bed  vmovaps [rsp+0xE0], xmm15
0000713aae5d8bf6  sub rsp, 0x40
0000713aae5d8bfa  lea rdi, [rsp]
0000713aae5d8bfe  lea rsi, [rsp+0x10]
0000713aae5d8c03  lea rdx, [rsp+0x20]
0000713aae5d8c08  lea rcx, [rsp+0x30]
0000713aae5d8c0d  mov r8d, 0x00
0000713aae5d8c13  lea r9, [r15+0x3A8]
0000713aae5d8c1a  movaps [rdi], xmm11
0000713aae5d8c1e  movaps [rsi], xmm10
0000713aae5d8c22  movaps [rdx], xmm8
0000713aae5d8c26  movaps [rcx], xmm1
0000713aae5d8c29  mov rax, 0x5E9381C89A50
0000713aae5d8c33  call rax
0000713aae5d8c35  movaps xmm11, [rsp]
0000713aae5d8c3a  add rsp, 0x40
0000713aae5d8c3e  vmovaps xmm0, [rsp]
0000713aae5d8c43  vmovaps xmm1, [rsp+0x10]
0000713aae5d8c49  vmovaps xmm2, [rsp+0x20]
0000713aae5d8c4f  vmovaps xmm3, [rsp+0x30]
0000713aae5d8c55  vmovaps xmm4, [rsp+0x40]
0000713aae5d8c5b  vmovaps xmm5, [rsp+0x50]
0000713aae5d8c61  vmovaps xmm6, [rsp+0x60]
0000713aae5d8c67  vmovaps xmm7, [rsp+0x70]
0000713aae5d8c6d  vmovaps xmm8, [rsp+0x80]
0000713aae5d8c76  vmovaps xmm9, [rsp+0x90]
0000713aae5d8c7f  vmovaps xmm10, [rsp+0xA0]
0000713aae5d8c88  vmovaps xmm12, [rsp+0xB0]
0000713aae5d8c91  vmovaps xmm13, [rsp+0xC0]
0000713aae5d8c9a  vmovaps xmm14, [rsp+0xD0]
0000713aae5d8ca3  vmovaps xmm15, [rsp+0xE0]
0000713aae5d8cac  add rsp, 0xF0
0000713aae5d8cb3  pop r11
0000713aae5d8cb5  pop r10
0000713aae5d8cb7  pop r9
0000713aae5d8cb9  pop r8
0000713aae5d8cbb  pop rsi
0000713aae5d8cbc  pop rdi
0000713aae5d8cbd  pop rdx
0000713aae5d8cbe  pop rcx
0000713aae5d8cbf  pop rax
0000713aae5d8cc0  add rsp, 0x08
0000713aae5d8cc4  jmp 0x0000713AAE5D6AE2
0000713aae5d8cc9  sub rsp, 0x08
0000713aae5d8ccd  push rax
0000713aae5d8cce  push rcx
0000713aae5d8ccf  push rdx
0000713aae5d8cd0  push rdi
0000713aae5d8cd1  push rsi
0000713aae5d8cd2  push r8
0000713aae5d8cd4  push r9
0000713aae5d8cd6  push r10
0000713aae5d8cd8  push r11
0000713aae5d8cda  sub rsp, 0xF0
0000713aae5d8ce1  vmovaps [rsp], xmm0
0000713aae5d8ce6  vmovaps [rsp+0x10], xmm1
0000713aae5d8cec  vmovaps [rsp+0x20], xmm2
0000713aae5d8cf2  vmovaps [rsp+0x30], xmm3
0000713aae5d8cf8  vmovaps [rsp+0x40], xmm4
0000713aae5d8cfe  vmovaps [rsp+0x50], xmm5
0000713aae5d8d04  vmovaps [rsp+0x60], xmm6
0000713aae5d8d0a  vmovaps [rsp+0x70], xmm7
0000713aae5d8d10  vmovaps [rsp+0x80], xmm8
0000713aae5d8d19  vmovaps [rsp+0x90], xmm9
0000713aae5d8d22  vmovaps [rsp+0xA0], xmm11
0000713aae5d8d2b  vmovaps [rsp+0xB0], xmm12
0000713aae5d8d34  vmovaps [rsp+0xC0], xmm13
0000713aae5d8d3d  vmovaps [rsp+0xD0], xmm14
0000713aae5d8d46  vmovaps [rsp+0xE0], xmm15
0000713aae5d8d4f  sub rsp, 0x40
0000713aae5d8d53  lea rdi, [rsp]
0000713aae5d8d57  lea rsi, [rsp+0x10]
0000713aae5d8d5c  lea rdx, [rsp+0x20]
0000713aae5d8d61  lea rcx, [rsp+0x30]
0000713aae5d8d66  mov r8d, 0x00
0000713aae5d8d6c  lea r9, [r15+0x3A8]
0000713aae5d8d73  movaps [rdi], xmm10
0000713aae5d8d77  movaps [rsi], xmm12
0000713aae5d8d7b  movaps [rdx], xmm13
0000713aae5d8d7f  movaps [rcx], xmm1
0000713aae5d8d82  mov rax, 0x5E9381C89A50
0000713aae5d8d8c  call rax
0000713aae5d8d8e  movaps xmm10, [rsp]
0000713aae5d8d93  add rsp, 0x40
0000713aae5d8d97  vmovaps xmm0, [rsp]
0000713aae5d8d9c  vmovaps xmm1, [rsp+0x10]
0000713aae5d8da2  vmovaps xmm2, [rsp+0x20]
0000713aae5d8da8  vmovaps xmm3, [rsp+0x30]
0000713aae5d8dae  vmovaps xmm4, [rsp+0x40]
0000713aae5d8db4  vmovaps xmm5, [rsp+0x50]
0000713aae5d8dba  vmovaps xmm6, [rsp+0x60]
0000713aae5d8dc0  vmovaps xmm7, [rsp+0x70]
0000713aae5d8dc6  vmovaps xmm8, [rsp+0x80]
0000713aae5d8dcf  vmovaps xmm9, [rsp+0x90]
0000713aae5d8dd8  vmovaps xmm11, [rsp+0xA0]
0000713aae5d8de1  vmovaps xmm12, [rsp+0xB0]
0000713aae5d8dea  vmovaps xmm13, [rsp+0xC0]
0000713aae5d8df3  vmovaps xmm14, [rsp+0xD0]
0000713aae5d8dfc  vmovaps xmm15, [rsp+0xE0]
0000713aae5d8e05  add rsp, 0xF0
0000713aae5d8e0c  pop r11
0000713aae5d8e0e  pop r10
0000713aae5d8e10  pop r9
0000713aae5d8e12  pop r8
0000713aae5d8e14  pop rsi
0000713aae5d8e15  pop rdi
0000713aae5d8e16  pop rdx
0000713aae5d8e17  pop rcx
0000713aae5d8e18  pop rax
0000713aae5d8e19  add rsp, 0x08
0000713aae5d8e1d  jmp 0x0000713AAE5D6B08
0000713aae5d8e22  call 0x0000713AAE4D64F0
0000713aae5d8e27  jmp 0x0000713AAE5D6B12
0000713aae5d8e2c  call 0x0000713AAE4E3320
0000713aae5d8e31  jmp 0x0000713AAE5D6B1C
0000713aae5d8e36  sub rsp, 0x08
0000713aae5d8e3a  push rax
0000713aae5d8e3b  push rcx
0000713aae5d8e3c  push rdx
0000713aae5d8e3d  push rdi
0000713aae5d8e3e  push rsi
0000713aae5d8e3f  push r8
0000713aae5d8e41  push r9
0000713aae5d8e43  push r10
0000713aae5d8e45  push r11
0000713aae5d8e47  sub rsp, 0xF0
0000713aae5d8e4e  vmovaps [rsp], xmm0
0000713aae5d8e53  vmovaps [rsp+0x10], xmm1
0000713aae5d8e59  vmovaps [rsp+0x20], xmm2
0000713aae5d8e5f  vmovaps [rsp+0x30], xmm3
0000713aae5d8e65  vmovaps [rsp+0x40], xmm4
0000713aae5d8e6b  vmovaps [rsp+0x50], xmm5
0000713aae5d8e71  vmovaps [rsp+0x60], xmm6
0000713aae5d8e77  vmovaps [rsp+0x70], xmm7
0000713aae5d8e7d  vmovaps [rsp+0x80], xmm9
0000713aae5d8e86  vmovaps [rsp+0x90], xmm10
0000713aae5d8e8f  vmovaps [rsp+0xA0], xmm11
0000713aae5d8e98  vmovaps [rsp+0xB0], xmm12
0000713aae5d8ea1  vmovaps [rsp+0xC0], xmm13
0000713aae5d8eaa  vmovaps [rsp+0xD0], xmm14
0000713aae5d8eb3  vmovaps [rsp+0xE0], xmm15
0000713aae5d8ebc  sub rsp, 0x40
0000713aae5d8ec0  lea rdi, [rsp]
0000713aae5d8ec4  lea rsi, [rsp+0x10]
0000713aae5d8ec9  lea rdx, [rsp+0x20]
0000713aae5d8ece  lea rcx, [rsp+0x30]
0000713aae5d8ed3  mov r8d, 0x00
0000713aae5d8ed9  lea r9, [r15+0x3A8]
0000713aae5d8ee0  movaps [rdi], xmm8
0000713aae5d8ee4  movaps [rsi], xmm7
0000713aae5d8ee7  movaps [rdx], xmm4
0000713aae5d8eea  movaps [rcx], xmm12
0000713aae5d8eee  mov rax, 0x5E9381C89A50
0000713aae5d8ef8  call rax
0000713aae5d8efa  movaps xmm8, [rsp]
0000713aae5d8eff  add rsp, 0x40
0000713aae5d8f03  vmovaps xmm0, [rsp]
0000713aae5d8f08  vmovaps xmm1, [rsp+0x10]
0000713aae5d8f0e  vmovaps xmm2, [rsp+0x20]
0000713aae5d8f14  vmovaps xmm3, [rsp+0x30]
0000713aae5d8f1a  vmovaps xmm4, [rsp+0x40]
0000713aae5d8f20  vmovaps xmm5, [rsp+0x50]
0000713aae5d8f26  vmovaps xmm6, [rsp+0x60]
0000713aae5d8f2c  vmovaps xmm7, [rsp+0x70]
0000713aae5d8f32  vmovaps xmm9, [rsp+0x80]
0000713aae5d8f3b  vmovaps xmm10, [rsp+0x90]
0000713aae5d8f44  vmovaps xmm11, [rsp+0xA0]
0000713aae5d8f4d  vmovaps xmm12, [rsp+0xB0]
0000713aae5d8f56  vmovaps xmm13, [rsp+0xC0]
0000713aae5d8f5f  vmovaps xmm14, [rsp+0xD0]
0000713aae5d8f68  vmovaps xmm15, [rsp+0xE0]
0000713aae5d8f71  add rsp, 0xF0
0000713aae5d8f78  pop r11
0000713aae5d8f7a  pop r10
0000713aae5d8f7c  pop r9
0000713aae5d8f7e  pop r8
0000713aae5d8f80  pop rsi
0000713aae5d8f81  pop rdi
0000713aae5d8f82  pop rdx
0000713aae5d8f83  pop rcx
0000713aae5d8f84  pop rax
0000713aae5d8f85  add rsp, 0x08
0000713aae5d8f89  jmp 0x0000713AAE5D6B45
0000713aae5d8f8e  sub rsp, 0x08
0000713aae5d8f92  push rax
0000713aae5d8f93  push rcx
0000713aae5d8f94  push rdx
0000713aae5d8f95  push rdi
0000713aae5d8f96  push rsi
0000713aae5d8f97  push r8
0000713aae5d8f99  push r9
0000713aae5d8f9b  push r10
0000713aae5d8f9d  push r11
0000713aae5d8f9f  sub rsp, 0xF0
0000713aae5d8fa6  vmovaps [rsp], xmm0
0000713aae5d8fab  vmovaps [rsp+0x10], xmm1
0000713aae5d8fb1  vmovaps [rsp+0x20], xmm2
0000713aae5d8fb7  vmovaps [rsp+0x30], xmm3
0000713aae5d8fbd  vmovaps [rsp+0x40], xmm4
0000713aae5d8fc3  vmovaps [rsp+0x50], xmm5
0000713aae5d8fc9  vmovaps [rsp+0x60], xmm6
0000713aae5d8fcf  vmovaps [rsp+0x70], xmm8
0000713aae5d8fd5  vmovaps [rsp+0x80], xmm9
0000713aae5d8fde  vmovaps [rsp+0x90], xmm10
0000713aae5d8fe7  vmovaps [rsp+0xA0], xmm11
0000713aae5d8ff0  vmovaps [rsp+0xB0], xmm12
0000713aae5d8ff9  vmovaps [rsp+0xC0], xmm13
0000713aae5d9002  vmovaps [rsp+0xD0], xmm14
0000713aae5d900b  vmovaps [rsp+0xE0], xmm15
0000713aae5d9014  sub rsp, 0x40
0000713aae5d9018  lea rdi, [rsp]
0000713aae5d901c  lea rsi, [rsp+0x10]
0000713aae5d9021  lea rdx, [rsp+0x20]
0000713aae5d9026  lea rcx, [rsp+0x30]
0000713aae5d902b  mov r8d, 0x00
0000713aae5d9031  lea r9, [r15+0x3A8]
0000713aae5d9038  movaps [rdi], xmm7
0000713aae5d903b  movaps [rsi], xmm9
0000713aae5d903f  movaps [rdx], xmm14
0000713aae5d9043  movaps [rcx], xmm12
0000713aae5d9047  mov rax, 0x5E9381C89A50
0000713aae5d9051  call rax
0000713aae5d9053  movaps xmm7, [rsp]
0000713aae5d9057  add rsp, 0x40
0000713aae5d905b  vmovaps xmm0, [rsp]
0000713aae5d9060  vmovaps xmm1, [rsp+0x10]
0000713aae5d9066  vmovaps xmm2, [rsp+0x20]
0000713aae5d906c  vmovaps xmm3, [rsp+0x30]
0000713aae5d9072  vmovaps xmm4, [rsp+0x40]
0000713aae5d9078  vmovaps xmm5, [rsp+0x50]
0000713aae5d907e  vmovaps xmm6, [rsp+0x60]
0000713aae5d9084  vmovaps xmm8, [rsp+0x70]
0000713aae5d908a  vmovaps xmm9, [rsp+0x80]
0000713aae5d9093  vmovaps xmm10, [rsp+0x90]
0000713aae5d909c  vmovaps xmm11, [rsp+0xA0]
0000713aae5d90a5  vmovaps xmm12, [rsp+0xB0]
0000713aae5d90ae  vmovaps xmm13, [rsp+0xC0]
0000713aae5d90b7  vmovaps xmm14, [rsp+0xD0]
0000713aae5d90c0  vmovaps xmm15, [rsp+0xE0]
0000713aae5d90c9  add rsp, 0xF0
0000713aae5d90d0  pop r11
0000713aae5d90d2  pop r10
0000713aae5d90d4  pop r9
0000713aae5d90d6  pop r8
0000713aae5d90d8  pop rsi
0000713aae5d90d9  pop rdi
0000713aae5d90da  pop rdx
0000713aae5d90db  pop rcx
0000713aae5d90dc  pop rax
0000713aae5d90dd  add rsp, 0x08
0000713aae5d90e1  jmp 0x0000713AAE5D6B6D
0000713aae5d90e6  sub rsp, 0x08
0000713aae5d90ea  push rax
0000713aae5d90eb  push rcx
0000713aae5d90ec  push rdx
0000713aae5d90ed  push rdi
0000713aae5d90ee  push rsi
0000713aae5d90ef  push r8
0000713aae5d90f1  push r9
0000713aae5d90f3  push r10
0000713aae5d90f5  push r11
0000713aae5d90f7  sub rsp, 0xF0
0000713aae5d90fe  vmovaps [rsp], xmm0
0000713aae5d9103  vmovaps [rsp+0x10], xmm1
0000713aae5d9109  vmovaps [rsp+0x20], xmm2
0000713aae5d910f  vmovaps [rsp+0x30], xmm3
0000713aae5d9115  vmovaps [rsp+0x40], xmm4
0000713aae5d911b  vmovaps [rsp+0x50], xmm5
0000713aae5d9121  vmovaps [rsp+0x60], xmm6
0000713aae5d9127  vmovaps [rsp+0x70], xmm7
0000713aae5d912d  vmovaps [rsp+0x80], xmm8
0000713aae5d9136  vmovaps [rsp+0x90], xmm9
0000713aae5d913f  vmovaps [rsp+0xA0], xmm10
0000713aae5d9148  vmovaps [rsp+0xB0], xmm11
0000713aae5d9151  vmovaps [rsp+0xC0], xmm13
0000713aae5d915a  vmovaps [rsp+0xD0], xmm14
0000713aae5d9163  vmovaps [rsp+0xE0], xmm15
0000713aae5d916c  sub rsp, 0x40
0000713aae5d9170  lea rdi, [rsp]
0000713aae5d9174  lea rsi, [rsp+0x10]
0000713aae5d9179  lea rdx, [rsp+0x20]
0000713aae5d917e  lea rcx, [rsp+0x30]
0000713aae5d9183  mov r8d, 0x00
0000713aae5d9189  lea r9, [r15+0x3A8]
0000713aae5d9190  movaps [rdi], xmm12
0000713aae5d9194  movaps [rsi], xmm11
0000713aae5d9198  movaps [rdx], xmm15
0000713aae5d919c  movaps [rcx], xmm14
0000713aae5d91a0  mov rax, 0x5E9381C89A50
0000713aae5d91aa  call rax
0000713aae5d91ac  movaps xmm12, [rsp]
0000713aae5d91b1  add rsp, 0x40
0000713aae5d91b5  vmovaps xmm0, [rsp]
0000713aae5d91ba  vmovaps xmm1, [rsp+0x10]
0000713aae5d91c0  vmovaps xmm2, [rsp+0x20]
0000713aae5d91c6  vmovaps xmm3, [rsp+0x30]
0000713aae5d91cc  vmovaps xmm4, [rsp+0x40]
0000713aae5d91d2  vmovaps xmm5, [rsp+0x50]
0000713aae5d91d8  vmovaps xmm6, [rsp+0x60]
0000713aae5d91de  vmovaps xmm7, [rsp+0x70]
0000713aae5d91e4  vmovaps xmm8, [rsp+0x80]
0000713aae5d91ed  vmovaps xmm9, [rsp+0x90]
0000713aae5d91f6  vmovaps xmm10, [rsp+0xA0]
0000713aae5d91ff  vmovaps xmm11, [rsp+0xB0]
0000713aae5d9208  vmovaps xmm13, [rsp+0xC0]
0000713aae5d9211  vmovaps xmm14, [rsp+0xD0]
0000713aae5d921a  vmovaps xmm15, [rsp+0xE0]
0000713aae5d9223  add rsp, 0xF0
0000713aae5d922a  pop r11
0000713aae5d922c  pop r10
0000713aae5d922e  pop r9
0000713aae5d9230  pop r8
0000713aae5d9232  pop rsi
0000713aae5d9233  pop rdi
0000713aae5d9234  pop rdx
0000713aae5d9235  pop rcx
0000713aae5d9236  pop rax
0000713aae5d9237  add rsp, 0x08
0000713aae5d923b  jmp 0x0000713AAE5D6B96
0000713aae5d9240  sub rsp, 0x08
0000713aae5d9244  push rax
0000713aae5d9245  push rcx
0000713aae5d9246  push rdx
0000713aae5d9247  push rdi
0000713aae5d9248  push rsi
0000713aae5d9249  push r8
0000713aae5d924b  push r9
0000713aae5d924d  push r10
0000713aae5d924f  push r11
0000713aae5d9251  sub rsp, 0xF0
0000713aae5d9258  vmovaps [rsp], xmm0
0000713aae5d925d  vmovaps [rsp+0x10], xmm1
0000713aae5d9263  vmovaps [rsp+0x20], xmm2
0000713aae5d9269  vmovaps [rsp+0x30], xmm3
0000713aae5d926f  vmovaps [rsp+0x40], xmm4
0000713aae5d9275  vmovaps [rsp+0x50], xmm5
0000713aae5d927b  vmovaps [rsp+0x60], xmm6
0000713aae5d9281  vmovaps [rsp+0x70], xmm7
0000713aae5d9287  vmovaps [rsp+0x80], xmm8
0000713aae5d9290  vmovaps [rsp+0x90], xmm9
0000713aae5d9299  vmovaps [rsp+0xA0], xmm10
0000713aae5d92a2  vmovaps [rsp+0xB0], xmm12
0000713aae5d92ab  vmovaps [rsp+0xC0], xmm13
0000713aae5d92b4  vmovaps [rsp+0xD0], xmm14
0000713aae5d92bd  vmovaps [rsp+0xE0], xmm15
0000713aae5d92c6  sub rsp, 0x40
0000713aae5d92ca  lea rdi, [rsp]
0000713aae5d92ce  lea rsi, [rsp+0x10]
0000713aae5d92d3  lea rdx, [rsp+0x20]
0000713aae5d92d8  lea rcx, [rsp+0x30]
0000713aae5d92dd  mov r8d, 0x00
0000713aae5d92e3  lea r9, [r15+0x3A8]
0000713aae5d92ea  movaps [rdi], xmm11
0000713aae5d92ee  movaps [rsi], xmm10
0000713aae5d92f2  movaps [rdx], xmm13
0000713aae5d92f6  movaps [rcx], xmm15
0000713aae5d92fa  mov rax, 0x5E9381C89A50
0000713aae5d9304  call rax
0000713aae5d9306  movaps xmm11, [rsp]
0000713aae5d930b  add rsp, 0x40
0000713aae5d930f  vmovaps xmm0, [rsp]
0000713aae5d9314  vmovaps xmm1, [rsp+0x10]
0000713aae5d931a  vmovaps xmm2, [rsp+0x20]
0000713aae5d9320  vmovaps xmm3, [rsp+0x30]
0000713aae5d9326  vmovaps xmm4, [rsp+0x40]
0000713aae5d932c  vmovaps xmm5, [rsp+0x50]
0000713aae5d9332  vmovaps xmm6, [rsp+0x60]
0000713aae5d9338  vmovaps xmm7, [rsp+0x70]
0000713aae5d933e  vmovaps xmm8, [rsp+0x80]
0000713aae5d9347  vmovaps xmm9, [rsp+0x90]
0000713aae5d9350  vmovaps xmm10, [rsp+0xA0]
0000713aae5d9359  vmovaps xmm12, [rsp+0xB0]
0000713aae5d9362  vmovaps xmm13, [rsp+0xC0]
0000713aae5d936b  vmovaps xmm14, [rsp+0xD0]
0000713aae5d9374  vmovaps xmm15, [rsp+0xE0]
0000713aae5d937d  add rsp, 0xF0
0000713aae5d9384  pop r11
0000713aae5d9386  pop r10
0000713aae5d9388  pop r9
0000713aae5d938a  pop r8
0000713aae5d938c  pop rsi
0000713aae5d938d  pop rdi
0000713aae5d938e  pop rdx
0000713aae5d938f  pop rcx
0000713aae5d9390  pop rax
0000713aae5d9391  add rsp, 0x08
0000713aae5d9395  jmp 0x0000713AAE5D6BBF
0000713aae5d939a  call 0x0000713AAE4E5820
0000713aae5d939f  jmp 0x0000713AAE5D6BCC
0000713aae5d93a4  call 0x0000713AAE4E45A0
0000713aae5d93a9  jmp 0x0000713AAE5D6BD9
0000713aae5d93ae  sub rsp, 0x08
0000713aae5d93b2  push rax
0000713aae5d93b3  push rcx
0000713aae5d93b4  push rdx
0000713aae5d93b5  push rdi
0000713aae5d93b6  push rsi
0000713aae5d93b7  push r8
0000713aae5d93b9  push r9
0000713aae5d93bb  push r10
0000713aae5d93bd  push r11
0000713aae5d93bf  sub rsp, 0xF0
0000713aae5d93c6  vmovaps [rsp], xmm0
0000713aae5d93cb  vmovaps [rsp+0x10], xmm1
0000713aae5d93d1  vmovaps [rsp+0x20], xmm2
0000713aae5d93d7  vmovaps [rsp+0x30], xmm3
0000713aae5d93dd  vmovaps [rsp+0x40], xmm4
0000713aae5d93e3  vmovaps [rsp+0x50], xmm5
0000713aae5d93e9  vmovaps [rsp+0x60], xmm6
0000713aae5d93ef  vmovaps [rsp+0x70], xmm7
0000713aae5d93f5  vmovaps [rsp+0x80], xmm8
0000713aae5d93fe  vmovaps [rsp+0x90], xmm9
0000713aae5d9407  vmovaps [rsp+0xA0], xmm11
0000713aae5d9410  vmovaps [rsp+0xB0], xmm12
0000713aae5d9419  vmovaps [rsp+0xC0], xmm13
0000713aae5d9422  vmovaps [rsp+0xD0], xmm14
0000713aae5d942b  vmovaps [rsp+0xE0], xmm15
0000713aae5d9434  sub rsp, 0x40
0000713aae5d9438  lea rdi, [rsp]
0000713aae5d943c  lea rsi, [rsp+0x10]
0000713aae5d9441  lea rdx, [rsp+0x20]
0000713aae5d9446  lea rcx, [rsp+0x30]
0000713aae5d944b  mov r8d, 0x00
0000713aae5d9451  lea r9, [r15+0x3A8]
0000713aae5d9458  movaps [rdi], xmm10
0000713aae5d945c  movaps [rsi], xmm8
0000713aae5d9460  movaps [rdx], xmm1
0000713aae5d9463  movaps [rcx], xmm13
0000713aae5d9467  mov rax, 0x5E9381C89A50
0000713aae5d9471  call rax
0000713aae5d9473  movaps xmm10, [rsp]
0000713aae5d9478  add rsp, 0x40
0000713aae5d947c  vmovaps xmm0, [rsp]
0000713aae5d9481  vmovaps xmm1, [rsp+0x10]
0000713aae5d9487  vmovaps xmm2, [rsp+0x20]
0000713aae5d948d  vmovaps xmm3, [rsp+0x30]
0000713aae5d9493  vmovaps xmm4, [rsp+0x40]
0000713aae5d9499  vmovaps xmm5, [rsp+0x50]
0000713aae5d949f  vmovaps xmm6, [rsp+0x60]
0000713aae5d94a5  vmovaps xmm7, [rsp+0x70]
0000713aae5d94ab  vmovaps xmm8, [rsp+0x80]
0000713aae5d94b4  vmovaps xmm9, [rsp+0x90]
0000713aae5d94bd  vmovaps xmm11, [rsp+0xA0]
0000713aae5d94c6  vmovaps xmm12, [rsp+0xB0]
0000713aae5d94cf  vmovaps xmm13, [rsp+0xC0]
0000713aae5d94d8  vmovaps xmm14, [rsp+0xD0]
0000713aae5d94e1  vmovaps xmm15, [rsp+0xE0]
0000713aae5d94ea  add rsp, 0xF0
0000713aae5d94f1  pop r11
0000713aae5d94f3  pop r10
0000713aae5d94f5  pop r9
0000713aae5d94f7  pop r8
0000713aae5d94f9  pop rsi
0000713aae5d94fa  pop rdi
0000713aae5d94fb  pop rdx
0000713aae5d94fc  pop rcx
0000713aae5d94fd  pop rax
0000713aae5d94fe  add rsp, 0x08
0000713aae5d9502  jmp 0x0000713AAE5D6C0F
0000713aae5d9507  call 0x0000713AAE4D64F0
0000713aae5d950c  jmp 0x0000713AAE5D6C21
0000713aae5d9511  sub rsp, 0x08
0000713aae5d9515  push rax
0000713aae5d9516  push rcx
0000713aae5d9517  push rdx
0000713aae5d9518  push rdi
0000713aae5d9519  push rsi
0000713aae5d951a  push r8
0000713aae5d951c  push r9
0000713aae5d951e  push r10
0000713aae5d9520  push r11
0000713aae5d9522  sub rsp, 0xF0
0000713aae5d9529  vmovaps [rsp], xmm0
0000713aae5d952e  vmovaps [rsp+0x10], xmm1
0000713aae5d9534  vmovaps [rsp+0x20], xmm2
0000713aae5d953a  vmovaps [rsp+0x30], xmm3
0000713aae5d9540  vmovaps [rsp+0x40], xmm4
0000713aae5d9546  vmovaps [rsp+0x50], xmm5
0000713aae5d954c  vmovaps [rsp+0x60], xmm6
0000713aae5d9552  vmovaps [rsp+0x70], xmm7
0000713aae5d9558  vmovaps [rsp+0x80], xmm8
0000713aae5d9561  vmovaps [rsp+0x90], xmm10
0000713aae5d956a  vmovaps [rsp+0xA0], xmm11
0000713aae5d9573  vmovaps [rsp+0xB0], xmm12
0000713aae5d957c  vmovaps [rsp+0xC0], xmm13
0000713aae5d9585  vmovaps [rsp+0xD0], xmm14
0000713aae5d958e  vmovaps [rsp+0xE0], xmm15
0000713aae5d9597  sub rsp, 0x40
0000713aae5d959b  lea rdi, [rsp]
0000713aae5d959f  lea rsi, [rsp+0x10]
0000713aae5d95a4  lea rdx, [rsp+0x20]
0000713aae5d95a9  lea rcx, [rsp+0x30]
0000713aae5d95ae  mov r8d, 0x00
0000713aae5d95b4  lea r9, [r15+0x3A8]
0000713aae5d95bb  movaps [rdi], xmm9
0000713aae5d95bf  movaps [rsi], xmm7
0000713aae5d95c2  movaps [rdx], xmm14
0000713aae5d95c6  movaps [rcx], xmm13
0000713aae5d95ca  mov rax, 0x5E9381C89A50
0000713aae5d95d4  call rax
0000713aae5d95d6  movaps xmm9, [rsp]
0000713aae5d95db  add rsp, 0x40
0000713aae5d95df  vmovaps xmm0, [rsp]
0000713aae5d95e4  vmovaps xmm1, [rsp+0x10]
0000713aae5d95ea  vmovaps xmm2, [rsp+0x20]
0000713aae5d95f0  vmovaps xmm3, [rsp+0x30]
0000713aae5d95f6  vmovaps xmm4, [rsp+0x40]
0000713aae5d95fc  vmovaps xmm5, [rsp+0x50]
0000713aae5d9602  vmovaps xmm6, [rsp+0x60]
0000713aae5d9608  vmovaps xmm7, [rsp+0x70]
0000713aae5d960e  vmovaps xmm8, [rsp+0x80]
0000713aae5d9617  vmovaps xmm10, [rsp+0x90]
0000713aae5d9620  vmovaps xmm11, [rsp+0xA0]
0000713aae5d9629  vmovaps xmm12, [rsp+0xB0]
0000713aae5d9632  vmovaps xmm13, [rsp+0xC0]
0000713aae5d963b  vmovaps xmm14, [rsp+0xD0]
0000713aae5d9644  vmovaps xmm15, [rsp+0xE0]
0000713aae5d964d  add rsp, 0xF0
0000713aae5d9654  pop r11
0000713aae5d9656  pop r10
0000713aae5d9658  pop r9
0000713aae5d965a  pop r8
0000713aae5d965c  pop rsi
0000713aae5d965d  pop rdi
0000713aae5d965e  pop rdx
0000713aae5d965f  pop rcx
0000713aae5d9660  pop rax
0000713aae5d9661  add rsp, 0x08
0000713aae5d9665  jmp 0x0000713AAE5D6C4F
0000713aae5d966a  sub rsp, 0x08
0000713aae5d966e  push rax
0000713aae5d966f  push rcx
0000713aae5d9670  push rdx
0000713aae5d9671  push rdi
0000713aae5d9672  push rsi
0000713aae5d9673  push r8
0000713aae5d9675  push r9
0000713aae5d9677  push r10
0000713aae5d9679  push r11
0000713aae5d967b  sub rsp, 0xF0
0000713aae5d9682  vmovaps [rsp], xmm0
0000713aae5d9687  vmovaps [rsp+0x10], xmm1
0000713aae5d968d  vmovaps [rsp+0x20], xmm2
0000713aae5d9693  vmovaps [rsp+0x30], xmm3
0000713aae5d9699  vmovaps [rsp+0x40], xmm4
0000713aae5d969f  vmovaps [rsp+0x50], xmm5
0000713aae5d96a5  vmovaps [rsp+0x60], xmm6
0000713aae5d96ab  vmovaps [rsp+0x70], xmm7
0000713aae5d96b1  vmovaps [rsp+0x80], xmm8
0000713aae5d96ba  vmovaps [rsp+0x90], xmm9
0000713aae5d96c3  vmovaps [rsp+0xA0], xmm10
0000713aae5d96cc  vmovaps [rsp+0xB0], xmm11
0000713aae5d96d5  vmovaps [rsp+0xC0], xmm12
0000713aae5d96de  vmovaps [rsp+0xD0], xmm14
0000713aae5d96e7  vmovaps [rsp+0xE0], xmm15
0000713aae5d96f0  sub rsp, 0x40
0000713aae5d96f4  lea rdi, [rsp]
0000713aae5d96f8  lea rsi, [rsp+0x10]
0000713aae5d96fd  lea rdx, [rsp+0x20]
0000713aae5d9702  lea rcx, [rsp+0x30]
0000713aae5d9707  mov r8d, 0x00
0000713aae5d970d  lea r9, [r15+0x3A8]
0000713aae5d9714  movaps [rdi], xmm13
0000713aae5d9718  movaps [rsi], xmm12
0000713aae5d971c  movaps [rdx], xmm15
0000713aae5d9720  movaps [rcx], xmm14
0000713aae5d9724  mov rax, 0x5E9381C89A50
0000713aae5d972e  call rax
0000713aae5d9730  movaps xmm13, [rsp]
0000713aae5d9735  add rsp, 0x40
0000713aae5d9739  vmovaps xmm0, [rsp]
0000713aae5d973e  vmovaps xmm1, [rsp+0x10]
0000713aae5d9744  vmovaps xmm2, [rsp+0x20]
0000713aae5d974a  vmovaps xmm3, [rsp+0x30]
0000713aae5d9750  vmovaps xmm4, [rsp+0x40]
0000713aae5d9756  vmovaps xmm5, [rsp+0x50]
0000713aae5d975c  vmovaps xmm6, [rsp+0x60]
0000713aae5d9762  vmovaps xmm7, [rsp+0x70]
0000713aae5d9768  vmovaps xmm8, [rsp+0x80]
0000713aae5d9771  vmovaps xmm9, [rsp+0x90]
0000713aae5d977a  vmovaps xmm10, [rsp+0xA0]
0000713aae5d9783  vmovaps xmm11, [rsp+0xB0]
0000713aae5d978c  vmovaps xmm12, [rsp+0xC0]
0000713aae5d9795  vmovaps xmm14, [rsp+0xD0]
0000713aae5d979e  vmovaps xmm15, [rsp+0xE0]
0000713aae5d97a7  add rsp, 0xF0
0000713aae5d97ae  pop r11
0000713aae5d97b0  pop r10
0000713aae5d97b2  pop r9
0000713aae5d97b4  pop r8
0000713aae5d97b6  pop rsi
0000713aae5d97b7  pop rdi
0000713aae5d97b8  pop rdx
0000713aae5d97b9  pop rcx
0000713aae5d97ba  pop rax
0000713aae5d97bb  add rsp, 0x08
0000713aae5d97bf  jmp 0x0000713AAE5D6C7D
0000713aae5d97c4  sub rsp, 0x08
0000713aae5d97c8  push rax
0000713aae5d97c9  push rcx
0000713aae5d97ca  push rdx
0000713aae5d97cb  push rdi
0000713aae5d97cc  push rsi
0000713aae5d97cd  push r8
0000713aae5d97cf  push r9
0000713aae5d97d1  push r10
0000713aae5d97d3  push r11
0000713aae5d97d5  sub rsp, 0xF0
0000713aae5d97dc  vmovaps [rsp], xmm0
0000713aae5d97e1  vmovaps [rsp+0x10], xmm1
0000713aae5d97e7  vmovaps [rsp+0x20], xmm2
0000713aae5d97ed  vmovaps [rsp+0x30], xmm3
0000713aae5d97f3  vmovaps [rsp+0x40], xmm4
0000713aae5d97f9  vmovaps [rsp+0x50], xmm5
0000713aae5d97ff  vmovaps [rsp+0x60], xmm6
0000713aae5d9805  vmovaps [rsp+0x70], xmm7
0000713aae5d980b  vmovaps [rsp+0x80], xmm8
0000713aae5d9814  vmovaps [rsp+0x90], xmm9
0000713aae5d981d  vmovaps [rsp+0xA0], xmm10
0000713aae5d9826  vmovaps [rsp+0xB0], xmm11
0000713aae5d982f  vmovaps [rsp+0xC0], xmm12
0000713aae5d9838  vmovaps [rsp+0xD0], xmm13
0000713aae5d9841  vmovaps [rsp+0xE0], xmm15
0000713aae5d984a  sub rsp, 0x40
0000713aae5d984e  lea rdi, [rsp]
0000713aae5d9852  lea rsi, [rsp+0x10]
0000713aae5d9857  lea rdx, [rsp+0x20]
0000713aae5d985c  lea rcx, [rsp+0x30]
0000713aae5d9861  mov r8d, 0x00
0000713aae5d9867  lea r9, [r15+0x3A8]
0000713aae5d986e  movaps [rdi], xmm14
0000713aae5d9872  movaps [rsi], xmm11
0000713aae5d9876  movaps [rdx], xmm1
0000713aae5d9879  movaps [rcx], xmm15
0000713aae5d987d  mov rax, 0x5E9381C89A50
0000713aae5d9887  call rax
0000713aae5d9889  movaps xmm14, [rsp]
0000713aae5d988e  add rsp, 0x40
0000713aae5d9892  vmovaps xmm0, [rsp]
0000713aae5d9897  vmovaps xmm1, [rsp+0x10]
0000713aae5d989d  vmovaps xmm2, [rsp+0x20]
0000713aae5d98a3  vmovaps xmm3, [rsp+0x30]
0000713aae5d98a9  vmovaps xmm4, [rsp+0x40]
0000713aae5d98af  vmovaps xmm5, [rsp+0x50]
0000713aae5d98b5  vmovaps xmm6, [rsp+0x60]
0000713aae5d98bb  vmovaps xmm7, [rsp+0x70]
0000713aae5d98c1  vmovaps xmm8, [rsp+0x80]
0000713aae5d98ca  vmovaps xmm9, [rsp+0x90]
0000713aae5d98d3  vmovaps xmm10, [rsp+0xA0]
0000713aae5d98dc  vmovaps xmm11, [rsp+0xB0]
0000713aae5d98e5  vmovaps xmm12, [rsp+0xC0]
0000713aae5d98ee  vmovaps xmm13, [rsp+0xD0]
0000713aae5d98f7  vmovaps xmm15, [rsp+0xE0]
0000713aae5d9900  add rsp, 0xF0
0000713aae5d9907  pop r11
0000713aae5d9909  pop r10
0000713aae5d990b  pop r9
0000713aae5d990d  pop r8
0000713aae5d990f  pop rsi
0000713aae5d9910  pop rdi
0000713aae5d9911  pop rdx
0000713aae5d9912  pop rcx
0000713aae5d9913  pop rax
0000713aae5d9914  add rsp, 0x08
0000713aae5d9918  jmp 0x0000713AAE5D6CAB
0000713aae5d991d  call 0x0000713AAE4ACF70
0000713aae5d9922  jmp 0x0000713AAE5D6CB9
0000713aae5d9927  call 0x0000713AAE40C380
0000713aae5d992c  jmp 0x0000713AAE5D6CC3
0000713aae5d9931  call 0x0000713AAE408C20
0000713aae5d9936  jmp 0x0000713AAE5D6CCD
0000713aae5d993b  call 0x0000713AAE40D600
0000713aae5d9940  jmp 0x0000713AAE5D6CD7
0000713aae5d9945  int3
0000713aae5d9946  nop [rax+rax*1], ax
0000713aae5d994f  nop
0000713aae5d9950  mov eax, [r15+0x48]
0000713aae5d9954  lea r14d, [eax+0x01]
0000713aae5d9959  mov [rsp+0x10], r14d
0000713aae5d995e  mov r14d, r14d
0000713aae5d9961  mov [r15+0x48], r14
0000713aae5d9965  xor eax, eax
0000713aae5d9967  mov r14d, [rsp+0x10]
0000713aae5d996c  cmp r14d, 0x1F4
0000713aae5d9973  cmc
0000713aae5d9974  lahf
0000713aae5d9975  seto al
0000713aae5d9978  mov [r15+0x108], eax
0000713aae5d997f  mov eax, [r15+0x108]
0000713aae5d9986  sahf
0000713aae5d9987  jnz 0x0000713AAE5D99B9
0000713aae5d9989  cmp dword ptr [r15+0x318], 0x00
0000713aae5d9991  jz 0x0000713AAE5DD2E0
0000713aae5d9997  nop [rax+rax*1], ax
0000713aae5d99a0  nop [rax+rax*1], eax
0000713aae5d99a8  mov eax, 0x410670
0000713aae5d99ad  mov [r15+0x100], rax
0000713aae5d99b4  jmp 0x0000713AAE3FE110
0000713aae5d99b9  cmp dword ptr [r15+0x318], 0x00
0000713aae5d99c1  jz 0x0000713AAE5D99F0
0000713aae5d99c7  nop [rax+rax*1], ax
0000713aae5d99d0  nop [rax+rax*1], eax
0000713aae5d99d8  mov eax, 0x4104EC
0000713aae5d99dd  mov [r15+0x100], rax
0000713aae5d99e4  jmp 0x0000713AAE3FE110
0000713aae5d99e9  int3
0000713aae5d99ea  int3
0000713aae5d99eb  nop [rax+rax*1], eax
0000713aae5d99f0  mov rax, [r15+0x40]
0000713aae5d99f4  vxorps xmm1, xmm1, xmm1
0000713aae5d99f8  vpbroadcastq xmm1, xmm1
0000713aae5d99fd  vxorps xmm15, xmm15, xmm15
0000713aae5d9a02  vpbroadcastq xmm15, xmm15
0000713aae5d9a07  lea r14, [rax+0x30]
0000713aae5d9a0b  mov r12, [r13+r14*1]
0000713aae5d9a10  lea r14, [rax+0x38]
0000713aae5d9a14  mov r11, [r13+r14*1]
0000713aae5d9a19  movq xmm14, r12
0000713aae5d9a1e  movq xmm13, r11
0000713aae5d9a23  movq xmm14, xmm14
0000713aae5d9a28  movq xmm13, xmm13
0000713aae5d9a2d  vmovaps [rsp+0x10], xmm13
0000713aae5d9a33  movq xmm13, xmm13
0000713aae5d9a38  movaps [r15+0x270], xmm13
0000713aae5d9a40  movaps xmm13, [r15+0x160]
0000713aae5d9a48  vmovaps [rsp+0x20], xmm13
0000713aae5d9a4e  vmovaps xmm12, [rsp+0x20]
0000713aae5d9a54  por xmm13, xmm12
0000713aae5d9a59  lea r14, [rax+0x20]
0000713aae5d9a5d  mov r12, [r13+r14*1]
0000713aae5d9a62  lea r14, [rax+0x28]
0000713aae5d9a66  mov r11, [r13+r14*1]
0000713aae5d9a6b  movq xmm12, r12
0000713aae5d9a70  movq xmm11, r11
0000713aae5d9a75  movq xmm12, xmm12
0000713aae5d9a7a  movq xmm11, xmm11
0000713aae5d9a7f  movaps xmm10, [r15+0x2D0]
0000713aae5d9a87  vmovaps [rsp+0x20], xmm10
0000713aae5d9a8d  vmovaps xmm9, [rsp+0x20]
0000713aae5d9a93  por xmm10, xmm9
0000713aae5d9a98  movaps xmm9, [r15+0x300]
0000713aae5d9aa0  vmovaps [rsp+0x20], xmm9
0000713aae5d9aa6  vmovaps xmm8, [rsp+0x20]
0000713aae5d9aac  por xmm9, xmm8
0000713aae5d9ab1  movaps xmm8, [r15+0x2B0]
0000713aae5d9ab9  vmovaps [rsp+0x20], xmm8
0000713aae5d9abf  vmovaps xmm7, [rsp+0x20]
0000713aae5d9ac5  por xmm8, xmm7
0000713aae5d9aca  movaps xmm7, [r15+0x180]
0000713aae5d9ad2  vmovaps [rsp+0x20], xmm7
0000713aae5d9ad8  vmovaps xmm6, [rsp+0x20]
0000713aae5d9ade  por xmm7, xmm6
0000713aae5d9ae2  lea r14, [rax+0x10]
0000713aae5d9ae6  mov r12, [r13+r14*1]
0000713aae5d9aeb  lea r14, [rax+0x18]
0000713aae5d9aef  mov r11, [r13+r14*1]
0000713aae5d9af4  movq xmm6, r12
0000713aae5d9af9  movq xmm5, r11
0000713aae5d9afe  movq xmm6, xmm6
0000713aae5d9b02  movq xmm5, xmm5
0000713aae5d9b06  movaps xmm4, [r15+0x200]
0000713aae5d9b0e  vmovaps [rsp+0x20], xmm4
0000713aae5d9b14  vmovaps xmm3, [rsp+0x20]
0000713aae5d9b1a  por xmm4, xmm3
0000713aae5d9b1e  movaps xmm3, [r15+0x1F0]
0000713aae5d9b26  vmovaps [rsp+0x20], xmm3
0000713aae5d9b2c  vmovaps xmm2, [rsp+0x20]
0000713aae5d9b32  por xmm3, xmm2
0000713aae5d9b36  movaps xmm2, [r15+0x2E0]
0000713aae5d9b3e  vmovaps [rsp+0x20], xmm2
0000713aae5d9b44  vmovaps [rsp+0x30], xmm1
0000713aae5d9b4a  vmovaps xmm1, [rsp+0x20]
0000713aae5d9b50  por xmm2, xmm1
0000713aae5d9b54  movaps xmm1, [r15+0x2A0]
0000713aae5d9b5c  vmovaps [rsp+0x20], xmm1
0000713aae5d9b62  vmovaps [rsp+0x40], xmm15
0000713aae5d9b68  vmovaps xmm15, [rsp+0x20]
0000713aae5d9b6e  por xmm1, xmm15
0000713aae5d9b73  movaps xmm15, [r15+0x280]
0000713aae5d9b7b  vmovaps [rsp+0x20], xmm15
0000713aae5d9b81  vmovaps [rsp+0x50], xmm1
0000713aae5d9b87  vmovaps xmm1, [rsp+0x20]
0000713aae5d9b8d  por xmm15, xmm1
0000713aae5d9b92  movaps xmm1, [r15+0x1C0]
0000713aae5d9b9a  vmovaps [rsp+0x20], xmm1
0000713aae5d9ba0  vmovaps [rsp+0x60], xmm15
0000713aae5d9ba6  vmovaps xmm15, [rsp+0x20]
0000713aae5d9bac  por xmm1, xmm15
0000713aae5d9bb1  movaps xmm15, [r15+0x210]
0000713aae5d9bb9  vmovaps [rsp+0x20], xmm15
0000713aae5d9bbf  vmovaps [rsp+0x70], xmm1
0000713aae5d9bc5  vmovaps xmm1, [rsp+0x20]
0000713aae5d9bcb  por xmm15, xmm1
0000713aae5d9bd0  mov r14, [r13+rax*1]
0000713aae5d9bd5  vmovq xmm1, r14
0000713aae5d9bda  vpbroadcastq xmm1, xmm1
0000713aae5d9bdf  vmovaps [rsp+0x20], xmm1
0000713aae5d9be5  vxorps xmm1, xmm1, xmm1
0000713aae5d9be9  vpbroadcastq xmm1, xmm1
0000713aae5d9bee  mov r14, [r15+0xF8]
0000713aae5d9bf5  vmovaps [rsp+0x80], xmm1
0000713aae5d9bfe  movups xmm1, [r13+r14*1]
0000713aae5d9c04  vmovaps [rsp+0x90], xmm1
0000713aae5d9c0d  vxorps xmm1, xmm1, xmm1
0000713aae5d9c11  vpbroadcastq xmm1, xmm1
0000713aae5d9c16  lea r12, [rax+0x08]
0000713aae5d9c1a  mov rax, [r13+r12*1]
0000713aae5d9c1f  vmovaps [rsp+0xA0], xmm1
0000713aae5d9c28  movq xmm1, rax
0000713aae5d9c2d  movaps [r15+0x240], xmm1
0000713aae5d9c35  mov rax, [r15+0x50]
0000713aae5d9c39  mov [r15+0x60], rax
0000713aae5d9c3d  mov qword ptr [r15+0x58], 0x40
0000713aae5d9c45  vmovaps xmm1, [rsp+0x30]
0000713aae5d9c4b  vmovaps [rsp+0x30], xmm15
0000713aae5d9c51  vmovaps xmm15, [rsp+0x90]
0000713aae5d9c5a  vmovaps [rsp+0x90], xmm14
0000713aae5d9c63  vmovaps xmm14, [rsp+0x20]
0000713aae5d9c69  vmovaps [rsp+0x20], xmm13
0000713aae5d9c6f  vmovaps [rsp+0xB0], xmm12
0000713aae5d9c78  movaps xmm13, xmm1
0000713aae5d9c7c  vfmadd231pd xmm13, xmm15, xmm14
0000713aae5d9c81  vcmppd xmm12, xmm13, xmm13, 0x03
0000713aae5d9c87  vptest xmm12, xmm12
0000713aae5d9c8c  jnz 0x0000713AAE5DA72F
0000713aae5d9c92  movaps xmm1, [r15+0x250]
0000713aae5d9c9a  vmovaps xmm15, [rsp+0x40]
0000713aae5d9ca0  vmovaps [rsp+0x40], xmm13
0000713aae5d9ca6  movaps xmm12, xmm15
0000713aae5d9caa  vfmadd231pd xmm12, xmm1, xmm14
0000713aae5d9caf  vcmppd xmm13, xmm12, xmm12, 0x03
0000713aae5d9cb5  vptest xmm13, xmm13
0000713aae5d9cba  jnz 0x0000713AAE5DA888
0000713aae5d9cc0  movaps xmm15, [r15+0x1E0]
0000713aae5d9cc8  vmovaps [rsp+0xC0], xmm15
0000713aae5d9cd1  vmovaps xmm13, [rsp+0xC0]
0000713aae5d9cda  por xmm15, xmm13
0000713aae5d9cdf  movaps xmm13, [r15+0x1D0]
0000713aae5d9ce7  vmovaps [rsp+0xC0], xmm13
0000713aae5d9cf0  vmovaps [rsp+0xD0], xmm1
0000713aae5d9cf9  vmovaps xmm1, [rsp+0xC0]
0000713aae5d9d02  por xmm13, xmm1
0000713aae5d9d07  movaps xmm1, [r15+0x2C0]
0000713aae5d9d0f  vmovaps [rsp+0xC0], xmm1
0000713aae5d9d18  vmovaps [rsp+0xE0], xmm15
0000713aae5d9d21  vmovaps xmm15, [rsp+0xC0]
0000713aae5d9d2a  por xmm1, xmm15
0000713aae5d9d2f  movaps xmm15, [r15+0x290]
0000713aae5d9d37  vmovaps [rsp+0xC0], xmm15
0000713aae5d9d40  vmovaps [rsp+0xF0], xmm1
0000713aae5d9d49  vmovaps xmm1, [rsp+0xC0]
0000713aae5d9d52  por xmm15, xmm1
0000713aae5d9d57  movaps xmm1, [r15+0x260]
0000713aae5d9d5f  vmovaps [rsp+0xC0], xmm1
0000713aae5d9d68  vmovaps [rsp+0x100], xmm15
0000713aae5d9d71  vmovaps xmm15, [rsp+0xC0]
0000713aae5d9d7a  por xmm1, xmm15
0000713aae5d9d7f  vmovaps xmm15, [rsp+0xD0]
0000713aae5d9d88  vmovaps [rsp+0xC0], xmm1
0000713aae5d9d91  vmovaps xmm1, [rsp+0xD0]
0000713aae5d9d9a  por xmm15, xmm1
0000713aae5d9d9f  lea r12, [r14+0xC0]
0000713aae5d9da6  movups xmm1, [r13+r12*1]
0000713aae5d9dac  mov [rsp+0xD0], rax
0000713aae5d9db4  xor eax, eax
0000713aae5d9db6  mov r12d, 0x40
0000713aae5d9dbc  mov r11d, 0x200
0000713aae5d9dc2  cmp r12, r11
0000713aae5d9dc5  cmc
0000713aae5d9dc6  lahf
0000713aae5d9dc7  seto al
0000713aae5d9dca  mov [r15+0x108], eax
0000713aae5d9dd1  vmovaps [rsp+0x110], xmm1
0000713aae5d9dda  vmovaps xmm1, [rsp+0x80]
0000713aae5d9de3  vmovaps [rsp+0x80], xmm15
0000713aae5d9dec  vmovaps xmm15, [rsp+0x110]
0000713aae5d9df5  vmovaps [rsp+0x110], xmm13
0000713aae5d9dfe  vmovaps [rsp+0x120], xmm12
0000713aae5d9e07  movaps xmm13, xmm1
0000713aae5d9e0b  vfmadd231pd xmm13, xmm15, xmm14
0000713aae5d9e10  vcmppd xmm12, xmm13, xmm13, 0x03
0000713aae5d9e16  vptest xmm12, xmm12
0000713aae5d9e1b  jnz 0x0000713AAE5DA9EB
0000713aae5d9e21  lea rax, [r14+0xB0]
0000713aae5d9e28  movups xmm1, [r13+rax*1]
0000713aae5d9e2e  vmovaps xmm15, [rsp+0xA0]
0000713aae5d9e37  vmovaps [rsp+0xA0], xmm13
0000713aae5d9e40  movaps xmm12, xmm15
0000713aae5d9e44  vfmadd231pd xmm12, xmm1, xmm14
0000713aae5d9e49  vcmppd xmm13, xmm12, xmm12, 0x03
0000713aae5d9e4f  vptest xmm13, xmm13
0000713aae5d9e54  jnz 0x0000713AAE5DAB4E
0000713aae5d9e5a  vmovaps xmm1, [rsp+0x30]
0000713aae5d9e60  vmovaps xmm15, [rsp+0x30]
0000713aae5d9e66  por xmm1, xmm15
0000713aae5d9e6b  movaps [r15+0x210], xmm1
0000713aae5d9e73  vmovaps xmm15, [rsp+0x70]
0000713aae5d9e79  vmovaps xmm14, [rsp+0x70]
0000713aae5d9e7f  por xmm15, xmm14
0000713aae5d9e84  movaps [r15+0x1C0], xmm15
0000713aae5d9e8c  vmovaps xmm14, [rsp+0x60]
0000713aae5d9e92  vmovaps xmm13, [rsp+0x60]
0000713aae5d9e98  por xmm14, xmm13
0000713aae5d9e9d  movaps [r15+0x280], xmm14
0000713aae5d9ea5  vmovaps xmm13, [rsp+0x50]
0000713aae5d9eab  vmovaps [rsp+0x30], xmm1
0000713aae5d9eb1  vmovaps xmm1, [rsp+0x50]
0000713aae5d9eb7  por xmm13, xmm1
0000713aae5d9ebc  movaps [r15+0x2A0], xmm13
0000713aae5d9ec4  vmovaps [rsp+0x50], xmm2
0000713aae5d9eca  vmovaps xmm1, [rsp+0x50]
0000713aae5d9ed0  por xmm2, xmm1
0000713aae5d9ed4  movaps [r15+0x2E0], xmm2
0000713aae5d9edc  vmovaps [rsp+0x50], xmm3
0000713aae5d9ee2  vmovaps xmm1, [rsp+0x50]
0000713aae5d9ee8  por xmm3, xmm1
0000713aae5d9eec  movaps [r15+0x1F0], xmm3
0000713aae5d9ef4  vmovaps xmm1, [rsp+0x80]
0000713aae5d9efd  vmovaps [rsp+0x50], xmm15
0000713aae5d9f03  vmovaps xmm15, [rsp+0x80]
0000713aae5d9f0c  por xmm1, xmm15
0000713aae5d9f11  movaps [r15+0x250], xmm1
0000713aae5d9f19  vmovaps xmm1, [rsp+0xC0]
0000713aae5d9f22  vmovaps xmm15, [rsp+0xC0]
0000713aae5d9f2b  por xmm1, xmm15
0000713aae5d9f30  movaps [r15+0x260], xmm1
0000713aae5d9f38  vmovaps xmm15, [rsp+0x100]
0000713aae5d9f41  vmovaps [rsp+0x60], xmm1
0000713aae5d9f47  vmovaps xmm1, [rsp+0x100]
0000713aae5d9f50  por xmm15, xmm1
0000713aae5d9f55  movaps [r15+0x290], xmm15
0000713aae5d9f5d  vmovaps xmm1, [rsp+0xF0]
0000713aae5d9f66  vmovaps [rsp+0x70], xmm15
0000713aae5d9f6c  vmovaps xmm15, [rsp+0xF0]
0000713aae5d9f75  por xmm1, xmm15
0000713aae5d9f7a  movaps [r15+0x2C0], xmm1
0000713aae5d9f82  movq xmm15, qword ptr [r15+0x240]
0000713aae5d9f8b  vmovaps [rsp+0x80], xmm15
0000713aae5d9f94  vpermilpd xmm15, xmm15, 0x00
0000713aae5d9f9a  vmovaps [rsp+0xC0], xmm1
0000713aae5d9fa3  vmovaps xmm1, [rsp+0x40]
0000713aae5d9fa9  vmovaps [rsp+0x40], xmm15
0000713aae5d9faf  vmovaps xmm15, [rsp+0x30]
0000713aae5d9fb5  vmovaps [rsp+0x30], xmm14
0000713aae5d9fbb  vmovaps xmm14, [rsp+0x40]
0000713aae5d9fc1  vmovaps [rsp+0x40], xmm13
0000713aae5d9fc7  vmovaps [rsp+0xF0], xmm12
0000713aae5d9fd0  movaps xmm13, xmm1
0000713aae5d9fd4  vfmadd231pd xmm13, xmm15, xmm14
0000713aae5d9fd9  vcmppd xmm12, xmm13, xmm13, 0x03
0000713aae5d9fdf  vptest xmm12, xmm12
0000713aae5d9fe4  jnz 0x0000713AAE5DACA7
0000713aae5d9fea  vmovaps xmm1, [rsp+0x80]
0000713aae5d9ff3  vpermilpd xmm1, xmm1, 0x00
0000713aae5d9ff9  vmovaps xmm15, [rsp+0xA0]
0000713aae5da002  movaps xmm14, xmm15
0000713aae5da006  vfmadd231pd xmm14, xmm2, xmm1
0000713aae5da00b  vcmppd xmm12, xmm14, xmm14, 0x03
0000713aae5da011  vptest xmm12, xmm12
0000713aae5da016  jnz 0x0000713AAE5DAE00
0000713aae5da01c  vmovaps xmm1, [rsp+0x80]
0000713aae5da025  vpermilpd xmm1, xmm1, 0x00
0000713aae5da02b  vmovaps xmm15, [rsp+0x120]
0000713aae5da034  vmovaps xmm12, [rsp+0x50]
0000713aae5da03a  vmovaps [rsp+0x50], xmm14
0000713aae5da040  movaps xmm2, xmm15
0000713aae5da044  vfmadd231pd xmm2, xmm12, xmm1
0000713aae5da049  vcmppd xmm14, xmm2, xmm2, 0x03
0000713aae5da04e  vptest xmm14, xmm14
0000713aae5da053  jnz 0x0000713AAE5DAF58
0000713aae5da059  vmovaps xmm1, [rsp+0x110]
0000713aae5da062  vmovaps xmm15, [rsp+0x110]
0000713aae5da06b  por xmm1, xmm15
0000713aae5da070  movaps [r15+0x1D0], xmm1
0000713aae5da078  vmovaps xmm15, [rsp+0x80]
0000713aae5da081  vpermilpd xmm15, xmm15, 0x00
0000713aae5da087  vmovaps xmm14, [rsp+0xF0]
0000713aae5da090  vmovaps [rsp+0x80], xmm1
0000713aae5da099  movaps xmm12, xmm14
0000713aae5da09d  vfmadd231pd xmm12, xmm3, xmm15
0000713aae5da0a2  vcmppd xmm1, xmm12, xmm12, 0x03
0000713aae5da0a8  vptest xmm1, xmm1
0000713aae5da0ad  jnz 0x0000713AAE5DB0AF
0000713aae5da0b3  vmovaps [rsp+0xA0], xmm4
0000713aae5da0bc  vmovaps xmm1, [rsp+0xA0]
0000713aae5da0c5  por xmm4, xmm1
0000713aae5da0c9  movaps [r15+0x200], xmm4
0000713aae5da0d1  vmovaps xmm1, [rsp+0xE0]
0000713aae5da0da  vmovaps xmm15, [rsp+0xE0]
0000713aae5da0e3  por xmm1, xmm15
0000713aae5da0e8  movaps [r15+0x1E0], xmm1
0000713aae5da0f0  vmovaps [rsp+0xA0], xmm8
0000713aae5da0f9  vmovaps xmm1, [rsp+0xA0]
0000713aae5da102  por xmm8, xmm1
0000713aae5da107  movaps [r15+0x2B0], xmm8
0000713aae5da10f  vmovaps [rsp+0xA0], xmm9
0000713aae5da118  vmovaps xmm1, [rsp+0xA0]
0000713aae5da121  por xmm9, xmm1
0000713aae5da126  movaps [r15+0x300], xmm9
0000713aae5da12e  vmovaps [rsp+0xA0], xmm6
0000713aae5da137  vpermilpd xmm6, xmm6, 0x00
0000713aae5da13d  vmovaps xmm14, [rsp+0x60]
0000713aae5da143  movaps xmm9, xmm13
0000713aae5da147  vfmadd231pd xmm9, xmm14, xmm6
0000713aae5da14c  vcmppd xmm3, xmm9, xmm9, 0x03
0000713aae5da152  vptest xmm3, xmm3
0000713aae5da157  jnz 0x0000713AAE5DB208
0000713aae5da15d  vmovaps xmm14, [rsp+0xA0]
0000713aae5da166  vpermilpd xmm14, xmm14, 0x00
0000713aae5da16c  vmovaps xmm13, [rsp+0x50]
0000713aae5da172  vmovaps xmm6, [rsp+0xC0]
0000713aae5da17b  vmovaps [rsp+0x50], xmm1
0000713aae5da181  movaps xmm3, xmm13
0000713aae5da185  vfmadd231pd xmm3, xmm6, xmm14
0000713aae5da18a  vcmppd xmm1, xmm3, xmm3, 0x03
0000713aae5da18f  vptest xmm1, xmm1
0000713aae5da194  jnz 0x0000713AAE5DB361
0000713aae5da19a  vmovaps xmm1, [rsp+0xA0]
0000713aae5da1a3  vpermilpd xmm1, xmm1, 0x00
0000713aae5da1a9  vmovaps xmm14, [rsp+0x30]
0000713aae5da1af  movaps xmm6, xmm2
0000713aae5da1b2  vfmadd231pd xmm6, xmm14, xmm1
0000713aae5da1b7  vcmppd xmm13, xmm6, xmm6, 0x03
0000713aae5da1bc  vptest xmm13, xmm13
0000713aae5da1c1  jnz 0x0000713AAE5DB4B8
0000713aae5da1c7  vmovaps xmm1, [rsp+0xA0]
0000713aae5da1d0  vpermilpd xmm1, xmm1, 0x00
0000713aae5da1d6  vmovaps xmm14, [rsp+0x80]
0000713aae5da1df  movaps xmm13, xmm12
0000713aae5da1e3  vfmadd231pd xmm13, xmm14, xmm1
0000713aae5da1e8  vcmppd xmm2, xmm13, xmm13, 0x03
0000713aae5da1ee  vptest xmm2, xmm2
0000713aae5da1f3  jnz 0x0000713AAE5DB60E
0000713aae5da1f9  vmovaps [rsp+0x30], xmm7
0000713aae5da1ff  vmovaps xmm1, [rsp+0x30]
0000713aae5da205  por xmm7, xmm1
0000713aae5da209  movaps [r15+0x180], xmm7
0000713aae5da211  vmovaps [rsp+0x30], xmm10
0000713aae5da217  vmovaps xmm1, [rsp+0x30]
0000713aae5da21d  por xmm10, xmm1
0000713aae5da222  movaps [r15+0x2D0], xmm10
0000713aae5da22a  vmovaps [rsp+0x30], xmm5
0000713aae5da230  vpermilpd xmm5, xmm5, 0x00
0000713aae5da236  vmovaps xmm14, [rsp+0x50]
0000713aae5da23c  movaps xmm12, xmm3
0000713aae5da240  vfmadd231pd xmm12, xmm14, xmm5
0000713aae5da245  vcmppd xmm10, xmm12, xmm12, 0x03
0000713aae5da24b  vptest xmm10, xmm10
0000713aae5da250  jnz 0x0000713AAE5DB767
0000713aae5da256  vmovaps xmm14, [rsp+0x30]
0000713aae5da25c  vpermilpd xmm14, xmm14, 0x00
0000713aae5da262  movaps xmm10, xmm9
0000713aae5da266  vfmadd231pd xmm10, xmm7, xmm14
0000713aae5da26b  vcmppd xmm5, xmm10, xmm10, 0x03
0000713aae5da271  vptest xmm5, xmm5
0000713aae5da276  jnz 0x0000713AAE5DB8BF
0000713aae5da27c  lea rax, [r14+0x80]
0000713aae5da283  movups xmm14, [r13+rax*1]
0000713aae5da289  movaps [r15+0x2F0], xmm14
0000713aae5da291  vmovaps xmm9, [rsp+0x30]
0000713aae5da297  vpermilpd xmm9, xmm9, 0x00
0000713aae5da29d  vmovaps xmm7, [rsp+0x70]
0000713aae5da2a3  movaps xmm5, xmm6
0000713aae5da2a6  vfmadd231pd xmm5, xmm7, xmm9
0000713aae5da2ab  vcmppd xmm3, xmm5, xmm5, 0x03
0000713aae5da2b0  vptest xmm3, xmm3
0000713aae5da2b5  jnz 0x0000713AAE5DBA22
0000713aae5da2bb  vmovaps xmm9, [rsp+0x30]
0000713aae5da2c1  vpermilpd xmm9, xmm9, 0x00
0000713aae5da2c7  movaps xmm7, xmm13
0000713aae5da2cb  vfmadd231pd xmm7, xmm1, xmm9
0000713aae5da2d0  vcmppd xmm6, xmm7, xmm7, 0x03
0000713aae5da2d5  vptest xmm6, xmm6
0000713aae5da2da  jnz 0x0000713AAE5DBB78
0000713aae5da2e0  vmovaps xmm1, [rsp+0x20]
0000713aae5da2e6  vmovaps xmm13, [rsp+0x20]
0000713aae5da2ec  por xmm1, xmm13
0000713aae5da2f1  movaps [r15+0x160], xmm1
0000713aae5da2f9  lea rax, [r14+0x40]
0000713aae5da2fd  movups xmm13, [r13+rax*1]
0000713aae5da303  lea rax, [r14+0x50]
0000713aae5da307  movups xmm9, [r13+rax*1]
0000713aae5da30d  movaps [r15+0x1B0], xmm13
0000713aae5da315  movaps [r15+0x1A0], xmm9
0000713aae5da31d  movaps xmm6, [r15+0x190]
0000713aae5da325  vmovaps xmm3, [rsp+0xB0]
0000713aae5da32e  vpermilpd xmm3, xmm3, 0x00
0000713aae5da334  vmovaps [rsp+0x20], xmm1
0000713aae5da33a  movaps xmm2, xmm12
0000713aae5da33e  vfmadd231pd xmm2, xmm6, xmm3
0000713aae5da343  vcmppd xmm1, xmm2, xmm2, 0x03
0000713aae5da348  vptest xmm1, xmm1
0000713aae5da34d  jnz 0x0000713AAE5DBCE3
0000713aae5da353  vmovaps xmm1, [rsp+0xB0]
0000713aae5da35c  vpermilpd xmm1, xmm1, 0x00
0000713aae5da362  vmovaps xmm12, [rsp+0x20]
0000713aae5da368  movaps xmm6, xmm10
0000713aae5da36c  vfmadd231pd xmm6, xmm12, xmm1
0000713aae5da371  vcmppd xmm3, xmm6, xmm6, 0x03
0000713aae5da376  vptest xmm3, xmm3
0000713aae5da37b  jnz 0x0000713AAE5DBE39
0000713aae5da381  vmovaps xmm1, [rsp+0xB0]
0000713aae5da38a  vpermilpd xmm1, xmm1, 0x00
0000713aae5da390  vmovaps xmm12, [rsp+0x40]
0000713aae5da396  movaps xmm10, xmm5
0000713aae5da39a  vfmadd231pd xmm10, xmm12, xmm1
0000713aae5da39f  vcmppd xmm3, xmm10, xmm10, 0x03
0000713aae5da3a5  vptest xmm3, xmm3
0000713aae5da3aa  jnz 0x0000713AAE5DBF90
0000713aae5da3b0  vmovaps xmm1, [rsp+0xB0]
0000713aae5da3b9  vpermilpd xmm1, xmm1, 0x00
0000713aae5da3bf  movaps xmm12, xmm7
0000713aae5da3c3  vfmadd231pd xmm12, xmm15, xmm1
0000713aae5da3c8  vcmppd xmm5, xmm12, xmm12, 0x03
0000713aae5da3ce  vptest xmm5, xmm5
0000713aae5da3d3  jnz 0x0000713AAE5DC0E8
0000713aae5da3d9  lea rax, [r14+0x60]
0000713aae5da3dd  movups xmm1, [r13+rax*1]
0000713aae5da3e3  lea rax, [r14+0x70]
0000713aae5da3e7  movups xmm15, [r13+rax*1]
0000713aae5da3ed  movaps [r15+0x150], xmm1
0000713aae5da3f5  movaps [r15+0x120], xmm15
0000713aae5da3fd  vmovaps [rsp+0x20], xmm11
0000713aae5da403  vpermilpd xmm11, xmm11, 0x00
0000713aae5da409  movaps xmm7, xmm2
0000713aae5da40c  vfmadd231pd xmm7, xmm9, xmm11
0000713aae5da411  vcmppd xmm5, xmm7, xmm7, 0x03
0000713aae5da416  vptest xmm5, xmm5
0000713aae5da41b  jnz 0x0000713AAE5DC254
0000713aae5da421  vmovaps xmm11, [rsp+0x20]
0000713aae5da427  vpermilpd xmm11, xmm11, 0x00
0000713aae5da42d  movaps xmm9, xmm6
0000713aae5da431  vfmadd231pd xmm9, xmm1, xmm11
0000713aae5da436  vcmppd xmm5, xmm9, xmm9, 0x03
0000713aae5da43c  vptest xmm5, xmm5
0000713aae5da441  jnz 0x0000713AAE5DC3AB
0000713aae5da447  vmovaps xmm1, [rsp+0x20]
0000713aae5da44d  vpermilpd xmm1, xmm1, 0x00
0000713aae5da453  movaps xmm11, xmm10
0000713aae5da457  vfmadd231pd xmm11, xmm8, xmm1
0000713aae5da45c  vcmppd xmm6, xmm11, xmm11, 0x03
0000713aae5da462  vptest xmm6, xmm6
0000713aae5da467  jnz 0x0000713AAE5DC503
0000713aae5da46d  vmovaps xmm1, [rsp+0x20]
0000713aae5da473  vpermilpd xmm1, xmm1, 0x00
0000713aae5da479  movaps xmm10, xmm12
0000713aae5da47d  vfmadd231pd xmm10, xmm13, xmm1
0000713aae5da482  vcmppd xmm8, xmm10, xmm10, 0x03
0000713aae5da488  vptest xmm8, xmm8
0000713aae5da48d  jnz 0x0000713AAE5DC65C
0000713aae5da493  lea rax, [r14+0x20]
0000713aae5da497  movups xmm1, [r13+rax*1]
0000713aae5da49d  lea rax, [r14+0x30]
0000713aae5da4a1  movups xmm13, [r13+rax*1]
0000713aae5da4a7  vmovaps xmm12, [rsp+0x90]
0000713aae5da4b0  vpermilpd xmm12, xmm12, 0x00
0000713aae5da4b6  movaps xmm8, xmm7
0000713aae5da4ba  vfmadd231pd xmm8, xmm4, xmm12
0000713aae5da4bf  vcmppd xmm6, xmm8, xmm8, 0x03
0000713aae5da4c5  vptest xmm6, xmm6
0000713aae5da4ca  jnz 0x0000713AAE5DC7C9
0000713aae5da4d0  vmovaps xmm12, [rsp+0x90]
0000713aae5da4d9  vpermilpd xmm12, xmm12, 0x00
0000713aae5da4df  movaps xmm7, xmm9
0000713aae5da4e3  vfmadd231pd xmm7, xmm14, xmm12
0000713aae5da4e8  vcmppd xmm6, xmm7, xmm7, 0x03
0000713aae5da4ed  vptest xmm6, xmm6
0000713aae5da4f2  jnz 0x0000713AAE5DC921
0000713aae5da4f8  vmovaps xmm14, [rsp+0x90]
0000713aae5da501  vpermilpd xmm14, xmm14, 0x00
0000713aae5da507  movaps xmm12, xmm11
0000713aae5da50b  vfmadd231pd xmm12, xmm15, xmm14
0000713aae5da510  vcmppd xmm9, xmm12, xmm12, 0x03
0000713aae5da516  vptest xmm9, xmm9
0000713aae5da51b  jnz 0x0000713AAE5DCA79
0000713aae5da521  vmovaps xmm15, [rsp+0x90]
0000713aae5da52a  vpermilpd xmm15, xmm15, 0x00
0000713aae5da530  movaps xmm11, xmm10
0000713aae5da534  vfmadd231pd xmm11, xmm13, xmm15
0000713aae5da539  vcmppd xmm14, xmm11, xmm11, 0x03
0000713aae5da53f  vptest xmm14, xmm14
0000713aae5da544  jnz 0x0000713AAE5DCBD3
0000713aae5da54a  lea rax, [r14+0x90]
0000713aae5da551  movups xmm15, [r13+rax*1]
0000713aae5da557  lea rax, [r14+0xA0]
0000713aae5da55e  movups xmm14, [r13+rax*1]
0000713aae5da564  movaps [r15+0x140], xmm15
0000713aae5da56c  movaps [r15+0x130], xmm14
0000713aae5da574  vmovaps xmm13, [rsp+0x10]
0000713aae5da57a  vpermilpd xmm13, xmm13, 0x00
0000713aae5da580  movaps xmm10, xmm8
0000713aae5da584  vfmadd231pd xmm10, xmm1, xmm13
0000713aae5da589  vcmppd xmm9, xmm10, xmm10, 0x03
0000713aae5da58f  vptest xmm9, xmm9
0000713aae5da594  jnz 0x0000713AAE5DCD41
0000713aae5da59a  movaps [r15+0x220], xmm10
0000713aae5da5a2  lea rax, [r14+0x10]
0000713aae5da5a6  movups xmm1, [r13+rax*1]
0000713aae5da5ac  movaps [r15+0x240], xmm1
0000713aae5da5b4  vmovaps xmm13, [rsp+0x10]
0000713aae5da5ba  vpermilpd xmm13, xmm13, 0x00
0000713aae5da5c0  movaps xmm9, xmm7
0000713aae5da5c4  vfmadd231pd xmm9, xmm14, xmm13
0000713aae5da5c9  vcmppd xmm8, xmm9, xmm9, 0x03
0000713aae5da5cf  vptest xmm8, xmm8
0000713aae5da5d4  jnz 0x0000713AAE5DCEA4
0000713aae5da5da  movaps [r15+0x110], xmm9
0000713aae5da5e2  vmovaps xmm14, [rsp+0x10]
0000713aae5da5e8  vpermilpd xmm14, xmm14, 0x00
0000713aae5da5ee  movaps xmm13, xmm12
0000713aae5da5f2  vfmadd231pd xmm13, xmm15, xmm14
0000713aae5da5f7  vcmppd xmm8, xmm13, xmm13, 0x03
0000713aae5da5fd  vptest xmm8, xmm8
0000713aae5da602  jnz 0x0000713AAE5DCFFD
0000713aae5da608  movaps [r15+0x170], xmm13
0000713aae5da610  vmovaps xmm15, [rsp+0x10]
0000713aae5da616  vpermilpd xmm15, xmm15, 0x00
0000713aae5da61c  movaps xmm14, xmm11
0000713aae5da620  vfmadd231pd xmm14, xmm1, xmm15
0000713aae5da625  vcmppd xmm12, xmm14, xmm14, 0x03
0000713aae5da62b  vptest xmm12, xmm12
0000713aae5da630  jnz 0x0000713AAE5DD157
0000713aae5da636  movaps [r15+0x230], xmm14
0000713aae5da63e  mov rax, [rsp+0xD0]
0000713aae5da646  movups [r13+rax*1], xmm9
0000713aae5da64c  lea r14, [rax+0x10]
0000713aae5da650  movups [r13+r14*1], xmm13
0000713aae5da656  lea r14, [rax+0x20]
0000713aae5da65a  movups [r13+r14*1], xmm10
0000713aae5da660  lea r14, [rax+0x30]
0000713aae5da664  movups [r13+r14*1], xmm14
0000713aae5da66a  mov eax, [r15+0x108]
0000713aae5da671  sahf
0000713aae5da672  jnz 0x0000713AAE5DA6A4
0000713aae5da674  cmp dword ptr [r15+0x318], 0x00
0000713aae5da67c  jz 0x0000713AAE5D9950
0000713aae5da682  nop [rax+rax*1], ax
0000713aae5da68b  nop [rax+rax*1], eax
0000713aae5da693  mov eax, 0x410664
0000713aae5da698  mov [r15+0x100], rax
0000713aae5da69f  jmp 0x0000713AAE3FE110
0000713aae5da6a4  cmp dword ptr [r15+0x318], 0x00
0000713aae5da6ac  jz 0x0000713AAE5D6050
0000713aae5da6b2  nop [rax+rax*1], ax
0000713aae5da6bb  nop [rax+rax*1], eax
0000713aae5da6c3  mov eax, 0x4104F0
0000713aae5da6c8  mov [r15+0x100], rax
0000713aae5da6cf  jmp 0x0000713AAE3FE110
0000713aae5da6d4  int3
0000713aae5da6d5  call 0x0000713AAE4E27E0
0000713aae5da6da  jmp 0x0000713AAE5D9A10
0000713aae5da6df  call 0x0000713AAE4E1570
0000713aae5da6e4  jmp 0x0000713AAE5D9A19
0000713aae5da6e9  call 0x0000713AAE4E27E0
0000713aae5da6ee  jmp 0x0000713AAE5D9A62
0000713aae5da6f3  call 0x0000713AAE4E1570
0000713aae5da6f8  jmp 0x0000713AAE5D9A6B
0000713aae5da6fd  call 0x0000713AAE4E27E0
0000713aae5da702  jmp 0x0000713AAE5D9AEB
0000713aae5da707  call 0x0000713AAE4E1570
0000713aae5da70c  jmp 0x0000713AAE5D9AF4
0000713aae5da711  call 0x0000713AAE40DC20
0000713aae5da716  jmp 0x0000713AAE5D9BD5
0000713aae5da71b  call 0x0000713AAE4D64F0
0000713aae5da720  jmp 0x0000713AAE5D9C04
0000713aae5da725  call 0x0000713AAE4B47C0
0000713aae5da72a  jmp 0x0000713AAE5D9C1F
0000713aae5da72f  sub rsp, 0x08
0000713aae5da733  push rax
0000713aae5da734  push rcx
0000713aae5da735  push rdx
0000713aae5da736  push rdi
0000713aae5da737  push rsi
0000713aae5da738  push r8
0000713aae5da73a  push r9
0000713aae5da73c  push r10
0000713aae5da73e  push r11
0000713aae5da740  sub rsp, 0xF0
0000713aae5da747  vmovaps [rsp], xmm0
0000713aae5da74c  vmovaps [rsp+0x10], xmm1
0000713aae5da752  vmovaps [rsp+0x20], xmm2
0000713aae5da758  vmovaps [rsp+0x30], xmm3
0000713aae5da75e  vmovaps [rsp+0x40], xmm4
0000713aae5da764  vmovaps [rsp+0x50], xmm5
0000713aae5da76a  vmovaps [rsp+0x60], xmm6
0000713aae5da770  vmovaps [rsp+0x70], xmm7
0000713aae5da776  vmovaps [rsp+0x80], xmm8
0000713aae5da77f  vmovaps [rsp+0x90], xmm9
0000713aae5da788  vmovaps [rsp+0xA0], xmm10
0000713aae5da791  vmovaps [rsp+0xB0], xmm11
0000713aae5da79a  vmovaps [rsp+0xC0], xmm12
0000713aae5da7a3  vmovaps [rsp+0xD0], xmm14
0000713aae5da7ac  vmovaps [rsp+0xE0], xmm15
0000713aae5da7b5  sub rsp, 0x40
0000713aae5da7b9  lea rdi, [rsp]
0000713aae5da7bd  lea rsi, [rsp+0x10]
0000713aae5da7c2  lea rdx, [rsp+0x20]
0000713aae5da7c7  lea rcx, [rsp+0x30]
0000713aae5da7cc  mov r8d, 0x00
0000713aae5da7d2  lea r9, [r15+0x3A8]
0000713aae5da7d9  movaps [rdi], xmm13
0000713aae5da7dd  movaps [rsi], xmm1
0000713aae5da7e0  movaps [rdx], xmm15
0000713aae5da7e4  movaps [rcx], xmm14
0000713aae5da7e8  mov rax, 0x5E9381C89A50
0000713aae5da7f2  call rax
0000713aae5da7f4  movaps xmm13, [rsp]
0000713aae5da7f9  add rsp, 0x40
0000713aae5da7fd  vmovaps xmm0, [rsp]
0000713aae5da802  vmovaps xmm1, [rsp+0x10]
0000713aae5da808  vmovaps xmm2, [rsp+0x20]
0000713aae5da80e  vmovaps xmm3, [rsp+0x30]
0000713aae5da814  vmovaps xmm4, [rsp+0x40]
0000713aae5da81a  vmovaps xmm5, [rsp+0x50]
0000713aae5da820  vmovaps xmm6, [rsp+0x60]
0000713aae5da826  vmovaps xmm7, [rsp+0x70]
0000713aae5da82c  vmovaps xmm8, [rsp+0x80]
0000713aae5da835  vmovaps xmm9, [rsp+0x90]
0000713aae5da83e  vmovaps xmm10, [rsp+0xA0]
0000713aae5da847  vmovaps xmm11, [rsp+0xB0]
0000713aae5da850  vmovaps xmm12, [rsp+0xC0]
0000713aae5da859  vmovaps xmm14, [rsp+0xD0]
0000713aae5da862  vmovaps xmm15, [rsp+0xE0]
0000713aae5da86b  add rsp, 0xF0
0000713aae5da872  pop r11
0000713aae5da874  pop r10
0000713aae5da876  pop r9
0000713aae5da878  pop r8
0000713aae5da87a  pop rsi
0000713aae5da87b  pop rdi
0000713aae5da87c  pop rdx
0000713aae5da87d  pop rcx
0000713aae5da87e  pop rax
0000713aae5da87f  add rsp, 0x08
0000713aae5da883  jmp 0x0000713AAE5D9C92
0000713aae5da888  sub rsp, 0x08
0000713aae5da88c  push rax
0000713aae5da88d  push rcx
0000713aae5da88e  push rdx
0000713aae5da88f  push rdi
0000713aae5da890  push rsi
0000713aae5da891  push r8
0000713aae5da893  push r9
0000713aae5da895  push r10
0000713aae5da897  push r11
0000713aae5da899  sub rsp, 0xF0
0000713aae5da8a0  vmovaps [rsp], xmm0
0000713aae5da8a5  vmovaps [rsp+0x10], xmm1
0000713aae5da8ab  vmovaps [rsp+0x20], xmm2
0000713aae5da8b1  vmovaps [rsp+0x30], xmm3
0000713aae5da8b7  vmovaps [rsp+0x40], xmm4
0000713aae5da8bd  vmovaps [rsp+0x50], xmm5
0000713aae5da8c3  vmovaps [rsp+0x60], xmm6
0000713aae5da8c9  vmovaps [rsp+0x70], xmm7
0000713aae5da8cf  vmovaps [rsp+0x80], xmm8
0000713aae5da8d8  vmovaps [rsp+0x90], xmm9
0000713aae5da8e1  vmovaps [rsp+0xA0], xmm10
0000713aae5da8ea  vmovaps [rsp+0xB0], xmm11
0000713aae5da8f3  vmovaps [rsp+0xC0], xmm13
0000713aae5da8fc  vmovaps [rsp+0xD0], xmm14
0000713aae5da905  vmovaps [rsp+0xE0], xmm15
0000713aae5da90e  sub rsp, 0x40
0000713aae5da912  lea rdi, [rsp]
0000713aae5da916  lea rsi, [rsp+0x10]
0000713aae5da91b  lea rdx, [rsp+0x20]
0000713aae5da920  lea rcx, [rsp+0x30]
0000713aae5da925  mov r8d, 0x00
0000713aae5da92b  lea r9, [r15+0x3A8]
0000713aae5da932  movaps [rdi], xmm12
0000713aae5da936  movaps [rsi], xmm15
0000713aae5da93a  movaps [rdx], xmm1
0000713aae5da93d  movaps [rcx], xmm14
0000713aae5da941  mov rax, 0x5E9381C89A50
0000713aae5da94b  call rax
0000713aae5da94d  movaps xmm12, [rsp]
0000713aae5da952  add rsp, 0x40
0000713aae5da956  vmovaps xmm0, [rsp]
0000713aae5da95b  vmovaps xmm1, [rsp+0x10]
0000713aae5da961  vmovaps xmm2, [rsp+0x20]
0000713aae5da967  vmovaps xmm3, [rsp+0x30]
0000713aae5da96d  vmovaps xmm4, [rsp+0x40]
0000713aae5da973  vmovaps xmm5, [rsp+0x50]
0000713aae5da979  vmovaps xmm6, [rsp+0x60]
0000713aae5da97f  vmovaps xmm7, [rsp+0x70]
0000713aae5da985  vmovaps xmm8, [rsp+0x80]
0000713aae5da98e  vmovaps xmm9, [rsp+0x90]
0000713aae5da997  vmovaps xmm10, [rsp+0xA0]
0000713aae5da9a0  vmovaps xmm11, [rsp+0xB0]
0000713aae5da9a9  vmovaps xmm13, [rsp+0xC0]
0000713aae5da9b2  vmovaps xmm14, [rsp+0xD0]
0000713aae5da9bb  vmovaps xmm15, [rsp+0xE0]
0000713aae5da9c4  add rsp, 0xF0
0000713aae5da9cb  pop r11
0000713aae5da9cd  pop r10
0000713aae5da9cf  pop r9
0000713aae5da9d1  pop r8
0000713aae5da9d3  pop rsi
0000713aae5da9d4  pop rdi
0000713aae5da9d5  pop rdx
0000713aae5da9d6  pop rcx
0000713aae5da9d7  pop rax
0000713aae5da9d8  add rsp, 0x08
0000713aae5da9dc  jmp 0x0000713AAE5D9CC0
0000713aae5da9e1  call 0x0000713AAE4B52F0
0000713aae5da9e6  jmp 0x0000713AAE5D9DAC
0000713aae5da9eb  sub rsp, 0x08
0000713aae5da9ef  push rax
0000713aae5da9f0  push rcx
0000713aae5da9f1  push rdx
0000713aae5da9f2  push rdi
0000713aae5da9f3  push rsi
0000713aae5da9f4  push r8
0000713aae5da9f6  push r9
0000713aae5da9f8  push r10
0000713aae5da9fa  push r11
0000713aae5da9fc  sub rsp, 0xF0
0000713aae5daa03  vmovaps [rsp], xmm0
0000713aae5daa08  vmovaps [rsp+0x10], xmm1
0000713aae5daa0e  vmovaps [rsp+0x20], xmm2
0000713aae5daa14  vmovaps [rsp+0x30], xmm3
0000713aae5daa1a  vmovaps [rsp+0x40], xmm4
0000713aae5daa20  vmovaps [rsp+0x50], xmm5
0000713aae5daa26  vmovaps [rsp+0x60], xmm6
0000713aae5daa2c  vmovaps [rsp+0x70], xmm7
0000713aae5daa32  vmovaps [rsp+0x80], xmm8
0000713aae5daa3b  vmovaps [rsp+0x90], xmm9
0000713aae5daa44  vmovaps [rsp+0xA0], xmm10
0000713aae5daa4d  vmovaps [rsp+0xB0], xmm11
0000713aae5daa56  vmovaps [rsp+0xC0], xmm12
0000713aae5daa5f  vmovaps [rsp+0xD0], xmm14
0000713aae5daa68  vmovaps [rsp+0xE0], xmm15
0000713aae5daa71  sub rsp, 0x40
0000713aae5daa75  lea rdi, [rsp]
0000713aae5daa79  lea rsi, [rsp+0x10]
0000713aae5daa7e  lea rdx, [rsp+0x20]
0000713aae5daa83  lea rcx, [rsp+0x30]
0000713aae5daa88  mov r8d, 0x00
0000713aae5daa8e  lea r9, [r15+0x3A8]
0000713aae5daa95  movaps [rdi], xmm13
0000713aae5daa99  movaps [rsi], xmm1
0000713aae5daa9c  movaps [rdx], xmm15
0000713aae5daaa0  movaps [rcx], xmm14
0000713aae5daaa4  mov rax, 0x5E9381C89A50
0000713aae5daaae  call rax
0000713aae5daab0  movaps xmm13, [rsp]
0000713aae5daab5  add rsp, 0x40
0000713aae5daab9  vmovaps xmm0, [rsp]
0000713aae5daabe  vmovaps xmm1, [rsp+0x10]
0000713aae5daac4  vmovaps xmm2, [rsp+0x20]
0000713aae5daaca  vmovaps xmm3, [rsp+0x30]
0000713aae5daad0  vmovaps xmm4, [rsp+0x40]
0000713aae5daad6  vmovaps xmm5, [rsp+0x50]
0000713aae5daadc  vmovaps xmm6, [rsp+0x60]
0000713aae5daae2  vmovaps xmm7, [rsp+0x70]
0000713aae5daae8  vmovaps xmm8, [rsp+0x80]
0000713aae5daaf1  vmovaps xmm9, [rsp+0x90]
0000713aae5daafa  vmovaps xmm10, [rsp+0xA0]
0000713aae5dab03  vmovaps xmm11, [rsp+0xB0]
0000713aae5dab0c  vmovaps xmm12, [rsp+0xC0]
0000713aae5dab15  vmovaps xmm14, [rsp+0xD0]
0000713aae5dab1e  vmovaps xmm15, [rsp+0xE0]
0000713aae5dab27  add rsp, 0xF0
0000713aae5dab2e  pop r11
0000713aae5dab30  pop r10
0000713aae5dab32  pop r9
0000713aae5dab34  pop r8
0000713aae5dab36  pop rsi
0000713aae5dab37  pop rdi
0000713aae5dab38  pop rdx
0000713aae5dab39  pop rcx
0000713aae5dab3a  pop rax
0000713aae5dab3b  add rsp, 0x08
0000713aae5dab3f  jmp 0x0000713AAE5D9E21
0000713aae5dab44  call 0x0000713AAE3FF430
0000713aae5dab49  jmp 0x0000713AAE5D9E2E
0000713aae5dab4e  sub rsp, 0x08
0000713aae5dab52  push rax
0000713aae5dab53  push rcx
0000713aae5dab54  push rdx
0000713aae5dab55  push rdi
0000713aae5dab56  push rsi
0000713aae5dab57  push r8
0000713aae5dab59  push r9
0000713aae5dab5b  push r10
0000713aae5dab5d  push r11
0000713aae5dab5f  sub rsp, 0xF0
0000713aae5dab66  vmovaps [rsp], xmm0
0000713aae5dab6b  vmovaps [rsp+0x10], xmm1
0000713aae5dab71  vmovaps [rsp+0x20], xmm2
0000713aae5dab77  vmovaps [rsp+0x30], xmm3
0000713aae5dab7d  vmovaps [rsp+0x40], xmm4
0000713aae5dab83  vmovaps [rsp+0x50], xmm5
0000713aae5dab89  vmovaps [rsp+0x60], xmm6
0000713aae5dab8f  vmovaps [rsp+0x70], xmm7
0000713aae5dab95  vmovaps [rsp+0x80], xmm8
0000713aae5dab9e  vmovaps [rsp+0x90], xmm9
0000713aae5daba7  vmovaps [rsp+0xA0], xmm10
0000713aae5dabb0  vmovaps [rsp+0xB0], xmm11
0000713aae5dabb9  vmovaps [rsp+0xC0], xmm13
0000713aae5dabc2  vmovaps [rsp+0xD0], xmm14
0000713aae5dabcb  vmovaps [rsp+0xE0], xmm15
0000713aae5dabd4  sub rsp, 0x40
0000713aae5dabd8  lea rdi, [rsp]
0000713aae5dabdc  lea rsi, [rsp+0x10]
0000713aae5dabe1  lea rdx, [rsp+0x20]
0000713aae5dabe6  lea rcx, [rsp+0x30]
0000713aae5dabeb  mov r8d, 0x00
0000713aae5dabf1  lea r9, [r15+0x3A8]
0000713aae5dabf8  movaps [rdi], xmm12
0000713aae5dabfc  movaps [rsi], xmm15
0000713aae5dac00  movaps [rdx], xmm1
0000713aae5dac03  movaps [rcx], xmm14
0000713aae5dac07  mov rax, 0x5E9381C89A50
0000713aae5dac11  call rax
0000713aae5dac13  movaps xmm12, [rsp]
0000713aae5dac18  add rsp, 0x40
0000713aae5dac1c  vmovaps xmm0, [rsp]
0000713aae5dac21  vmovaps xmm1, [rsp+0x10]
0000713aae5dac27  vmovaps xmm2, [rsp+0x20]
0000713aae5dac2d  vmovaps xmm3, [rsp+0x30]
0000713aae5dac33  vmovaps xmm4, [rsp+0x40]
0000713aae5dac39  vmovaps xmm5, [rsp+0x50]
0000713aae5dac3f  vmovaps xmm6, [rsp+0x60]
0000713aae5dac45  vmovaps xmm7, [rsp+0x70]
0000713aae5dac4b  vmovaps xmm8, [rsp+0x80]
0000713aae5dac54  vmovaps xmm9, [rsp+0x90]
0000713aae5dac5d  vmovaps xmm10, [rsp+0xA0]
0000713aae5dac66  vmovaps xmm11, [rsp+0xB0]
0000713aae5dac6f  vmovaps xmm13, [rsp+0xC0]
0000713aae5dac78  vmovaps xmm14, [rsp+0xD0]
0000713aae5dac81  vmovaps xmm15, [rsp+0xE0]
0000713aae5dac8a  add rsp, 0xF0
0000713aae5dac91  pop r11
0000713aae5dac93  pop r10
0000713aae5dac95  pop r9
0000713aae5dac97  pop r8
0000713aae5dac99  pop rsi
0000713aae5dac9a  pop rdi
0000713aae5dac9b  pop rdx
0000713aae5dac9c  pop rcx
0000713aae5dac9d  pop rax
0000713aae5dac9e  add rsp, 0x08
0000713aae5daca2  jmp 0x0000713AAE5D9E5A
0000713aae5daca7  sub rsp, 0x08
0000713aae5dacab  push rax
0000713aae5dacac  push rcx
0000713aae5dacad  push rdx
0000713aae5dacae  push rdi
0000713aae5dacaf  push rsi
0000713aae5dacb0  push r8
0000713aae5dacb2  push r9
0000713aae5dacb4  push r10
0000713aae5dacb6  push r11
0000713aae5dacb8  sub rsp, 0xF0
0000713aae5dacbf  vmovaps [rsp], xmm0
0000713aae5dacc4  vmovaps [rsp+0x10], xmm1
0000713aae5dacca  vmovaps [rsp+0x20], xmm2
0000713aae5dacd0  vmovaps [rsp+0x30], xmm3
0000713aae5dacd6  vmovaps [rsp+0x40], xmm4
0000713aae5dacdc  vmovaps [rsp+0x50], xmm5
0000713aae5dace2  vmovaps [rsp+0x60], xmm6
0000713aae5dace8  vmovaps [rsp+0x70], xmm7
0000713aae5dacee  vmovaps [rsp+0x80], xmm8
0000713aae5dacf7  vmovaps [rsp+0x90], xmm9
0000713aae5dad00  vmovaps [rsp+0xA0], xmm10
0000713aae5dad09  vmovaps [rsp+0xB0], xmm11
0000713aae5dad12  vmovaps [rsp+0xC0], xmm12
0000713aae5dad1b  vmovaps [rsp+0xD0], xmm14
0000713aae5dad24  vmovaps [rsp+0xE0], xmm15
0000713aae5dad2d  sub rsp, 0x40
0000713aae5dad31  lea rdi, [rsp]
0000713aae5dad35  lea rsi, [rsp+0x10]
0000713aae5dad3a  lea rdx, [rsp+0x20]
0000713aae5dad3f  lea rcx, [rsp+0x30]
0000713aae5dad44  mov r8d, 0x00
0000713aae5dad4a  lea r9, [r15+0x3A8]
0000713aae5dad51  movaps [rdi], xmm13
0000713aae5dad55  movaps [rsi], xmm1
0000713aae5dad58  movaps [rdx], xmm15
0000713aae5dad5c  movaps [rcx], xmm14
0000713aae5dad60  mov rax, 0x5E9381C89A50
0000713aae5dad6a  call rax
0000713aae5dad6c  movaps xmm13, [rsp]
0000713aae5dad71  add rsp, 0x40
0000713aae5dad75  vmovaps xmm0, [rsp]
0000713aae5dad7a  vmovaps xmm1, [rsp+0x10]
0000713aae5dad80  vmovaps xmm2, [rsp+0x20]
0000713aae5dad86  vmovaps xmm3, [rsp+0x30]
0000713aae5dad8c  vmovaps xmm4, [rsp+0x40]
0000713aae5dad92  vmovaps xmm5, [rsp+0x50]
0000713aae5dad98  vmovaps xmm6, [rsp+0x60]
0000713aae5dad9e  vmovaps xmm7, [rsp+0x70]
0000713aae5dada4  vmovaps xmm8, [rsp+0x80]
0000713aae5dadad  vmovaps xmm9, [rsp+0x90]
0000713aae5dadb6  vmovaps xmm10, [rsp+0xA0]
0000713aae5dadbf  vmovaps xmm11, [rsp+0xB0]
0000713aae5dadc8  vmovaps xmm12, [rsp+0xC0]
0000713aae5dadd1  vmovaps xmm14, [rsp+0xD0]
0000713aae5dadda  vmovaps xmm15, [rsp+0xE0]
0000713aae5dade3  add rsp, 0xF0
0000713aae5dadea  pop r11
0000713aae5dadec  pop r10
0000713aae5dadee  pop r9
0000713aae5dadf0  pop r8
0000713aae5dadf2  pop rsi
0000713aae5dadf3  pop rdi
0000713aae5dadf4  pop rdx
0000713aae5dadf5  pop rcx
0000713aae5dadf6  pop rax
0000713aae5dadf7  add rsp, 0x08
0000713aae5dadfb  jmp 0x0000713AAE5D9FEA
0000713aae5dae00  sub rsp, 0x08
0000713aae5dae04  push rax
0000713aae5dae05  push rcx
0000713aae5dae06  push rdx
0000713aae5dae07  push rdi
0000713aae5dae08  push rsi
0000713aae5dae09  push r8
0000713aae5dae0b  push r9
0000713aae5dae0d  push r10
0000713aae5dae0f  push r11
0000713aae5dae11  sub rsp, 0xF0
0000713aae5dae18  vmovaps [rsp], xmm0
0000713aae5dae1d  vmovaps [rsp+0x10], xmm1
0000713aae5dae23  vmovaps [rsp+0x20], xmm2
0000713aae5dae29  vmovaps [rsp+0x30], xmm3
0000713aae5dae2f  vmovaps [rsp+0x40], xmm4
0000713aae5dae35  vmovaps [rsp+0x50], xmm5
0000713aae5dae3b  vmovaps [rsp+0x60], xmm6
0000713aae5dae41  vmovaps [rsp+0x70], xmm7
0000713aae5dae47  vmovaps [rsp+0x80], xmm8
0000713aae5dae50  vmovaps [rsp+0x90], xmm9
0000713aae5dae59  vmovaps [rsp+0xA0], xmm10
0000713aae5dae62  vmovaps [rsp+0xB0], xmm11
0000713aae5dae6b  vmovaps [rsp+0xC0], xmm12
0000713aae5dae74  vmovaps [rsp+0xD0], xmm13
0000713aae5dae7d  vmovaps [rsp+0xE0], xmm15
0000713aae5dae86  sub rsp, 0x40
0000713aae5dae8a  lea rdi, [rsp]
0000713aae5dae8e  lea rsi, [rsp+0x10]
0000713aae5dae93  lea rdx, [rsp+0x20]
0000713aae5dae98  lea rcx, [rsp+0x30]
0000713aae5dae9d  mov r8d, 0x00
0000713aae5daea3  lea r9, [r15+0x3A8]
0000713aae5daeaa  movaps [rdi], xmm14
0000713aae5daeae  movaps [rsi], xmm15
0000713aae5daeb2  movaps [rdx], xmm2
0000713aae5daeb5  movaps [rcx], xmm1
0000713aae5daeb8  mov rax, 0x5E9381C89A50
0000713aae5daec2  call rax
0000713aae5daec4  movaps xmm14, [rsp]
0000713aae5daec9  add rsp, 0x40
0000713aae5daecd  vmovaps xmm0, [rsp]
0000713aae5daed2  vmovaps xmm1, [rsp+0x10]
0000713aae5daed8  vmovaps xmm2, [rsp+0x20]
0000713aae5daede  vmovaps xmm3, [rsp+0x30]
0000713aae5daee4  vmovaps xmm4, [rsp+0x40]
0000713aae5daeea  vmovaps xmm5, [rsp+0x50]
0000713aae5daef0  vmovaps xmm6, [rsp+0x60]
0000713aae5daef6  vmovaps xmm7, [rsp+0x70]
0000713aae5daefc  vmovaps xmm8, [rsp+0x80]
0000713aae5daf05  vmovaps xmm9, [rsp+0x90]
0000713aae5daf0e  vmovaps xmm10, [rsp+0xA0]
0000713aae5daf17  vmovaps xmm11, [rsp+0xB0]
0000713aae5daf20  vmovaps xmm12, [rsp+0xC0]
0000713aae5daf29  vmovaps xmm13, [rsp+0xD0]
0000713aae5daf32  vmovaps xmm15, [rsp+0xE0]
0000713aae5daf3b  add rsp, 0xF0
0000713aae5daf42  pop r11
0000713aae5daf44  pop r10
0000713aae5daf46  pop r9
0000713aae5daf48  pop r8
0000713aae5daf4a  pop rsi
0000713aae5daf4b  pop rdi
0000713aae5daf4c  pop rdx
0000713aae5daf4d  pop rcx
0000713aae5daf4e  pop rax
0000713aae5daf4f  add rsp, 0x08
0000713aae5daf53  jmp 0x0000713AAE5DA01C
0000713aae5daf58  sub rsp, 0x08
0000713aae5daf5c  push rax
0000713aae5daf5d  push rcx
0000713aae5daf5e  push rdx
0000713aae5daf5f  push rdi
0000713aae5daf60  push rsi
0000713aae5daf61  push r8
0000713aae5daf63  push r9
0000713aae5daf65  push r10
0000713aae5daf67  push r11
0000713aae5daf69  sub rsp, 0xF0
0000713aae5daf70  vmovaps [rsp], xmm0
0000713aae5daf75  vmovaps [rsp+0x10], xmm1
0000713aae5daf7b  vmovaps [rsp+0x20], xmm3
0000713aae5daf81  vmovaps [rsp+0x30], xmm4
0000713aae5daf87  vmovaps [rsp+0x40], xmm5
0000713aae5daf8d  vmovaps [rsp+0x50], xmm6
0000713aae5daf93  vmovaps [rsp+0x60], xmm7
0000713aae5daf99  vmovaps [rsp+0x70], xmm8
0000713aae5daf9f  vmovaps [rsp+0x80], xmm9
0000713aae5dafa8  vmovaps [rsp+0x90], xmm10
0000713aae5dafb1  vmovaps [rsp+0xA0], xmm11
0000713aae5dafba  vmovaps [rsp+0xB0], xmm12
0000713aae5dafc3  vmovaps [rsp+0xC0], xmm13
0000713aae5dafcc  vmovaps [rsp+0xD0], xmm14
0000713aae5dafd5  vmovaps [rsp+0xE0], xmm15
0000713aae5dafde  sub rsp, 0x40
0000713aae5dafe2  lea rdi, [rsp]
0000713aae5dafe6  lea rsi, [rsp+0x10]
0000713aae5dafeb  lea rdx, [rsp+0x20]
0000713aae5daff0  lea rcx, [rsp+0x30]
0000713aae5daff5  mov r8d, 0x00
0000713aae5daffb  lea r9, [r15+0x3A8]
0000713aae5db002  movaps [rdi], xmm2
0000713aae5db005  movaps [rsi], xmm15
0000713aae5db009  movaps [rdx], xmm12
0000713aae5db00d  movaps [rcx], xmm1
0000713aae5db010  mov rax, 0x5E9381C89A50
0000713aae5db01a  call rax
0000713aae5db01c  movaps xmm2, [rsp]
0000713aae5db020  add rsp, 0x40
0000713aae5db024  vmovaps xmm0, [rsp]
0000713aae5db029  vmovaps xmm1, [rsp+0x10]
0000713aae5db02f  vmovaps xmm3, [rsp+0x20]
0000713aae5db035  vmovaps xmm4, [rsp+0x30]
0000713aae5db03b  vmovaps xmm5, [rsp+0x40]
0000713aae5db041  vmovaps xmm6, [rsp+0x50]
0000713aae5db047  vmovaps xmm7, [rsp+0x60]
0000713aae5db04d  vmovaps xmm8, [rsp+0x70]
0000713aae5db053  vmovaps xmm9, [rsp+0x80]
0000713aae5db05c  vmovaps xmm10, [rsp+0x90]
0000713aae5db065  vmovaps xmm11, [rsp+0xA0]
0000713aae5db06e  vmovaps xmm12, [rsp+0xB0]
0000713aae5db077  vmovaps xmm13, [rsp+0xC0]
0000713aae5db080  vmovaps xmm14, [rsp+0xD0]
0000713aae5db089  vmovaps xmm15, [rsp+0xE0]
0000713aae5db092  add rsp, 0xF0
0000713aae5db099  pop r11
0000713aae5db09b  pop r10
0000713aae5db09d  pop r9
0000713aae5db09f  pop r8
0000713aae5db0a1  pop rsi
0000713aae5db0a2  pop rdi
0000713aae5db0a3  pop rdx
0000713aae5db0a4  pop rcx
0000713aae5db0a5  pop rax
0000713aae5db0a6  add rsp, 0x08
0000713aae5db0aa  jmp 0x0000713AAE5DA059
0000713aae5db0af  sub rsp, 0x08
0000713aae5db0b3  push rax
0000713aae5db0b4  push rcx
0000713aae5db0b5  push rdx
0000713aae5db0b6  push rdi
0000713aae5db0b7  push rsi
0000713aae5db0b8  push r8
0000713aae5db0ba  push r9
0000713aae5db0bc  push r10
0000713aae5db0be  push r11
0000713aae5db0c0  sub rsp, 0xF0
0000713aae5db0c7  vmovaps [rsp], xmm0
0000713aae5db0cc  vmovaps [rsp+0x10], xmm1
0000713aae5db0d2  vmovaps [rsp+0x20], xmm2
0000713aae5db0d8  vmovaps [rsp+0x30], xmm3
0000713aae5db0de  vmovaps [rsp+0x40], xmm4
0000713aae5db0e4  vmovaps [rsp+0x50], xmm5
0000713aae5db0ea  vmovaps [rsp+0x60], xmm6
0000713aae5db0f0  vmovaps [rsp+0x70], xmm7
0000713aae5db0f6  vmovaps [rsp+0x80], xmm8
0000713aae5db0ff  vmovaps [rsp+0x90], xmm9
0000713aae5db108  vmovaps [rsp+0xA0], xmm10
0000713aae5db111  vmovaps [rsp+0xB0], xmm11
0000713aae5db11a  vmovaps [rsp+0xC0], xmm13
0000713aae5db123  vmovaps [rsp+0xD0], xmm14
0000713aae5db12c  vmovaps [rsp+0xE0], xmm15
0000713aae5db135  sub rsp, 0x40
0000713aae5db139  lea rdi, [rsp]
0000713aae5db13d  lea rsi, [rsp+0x10]
0000713aae5db142  lea rdx, [rsp+0x20]
0000713aae5db147  lea rcx, [rsp+0x30]
0000713aae5db14c  mov r8d, 0x00
0000713aae5db152  lea r9, [r15+0x3A8]
0000713aae5db159  movaps [rdi], xmm12
0000713aae5db15d  movaps [rsi], xmm14
0000713aae5db161  movaps [rdx], xmm3
0000713aae5db164  movaps [rcx], xmm15
0000713aae5db168  mov rax, 0x5E9381C89A50
0000713aae5db172  call rax
0000713aae5db174  movaps xmm12, [rsp]
0000713aae5db179  add rsp, 0x40
0000713aae5db17d  vmovaps xmm0, [rsp]
0000713aae5db182  vmovaps xmm1, [rsp+0x10]
0000713aae5db188  vmovaps xmm2, [rsp+0x20]
0000713aae5db18e  vmovaps xmm3, [rsp+0x30]
0000713aae5db194  vmovaps xmm4, [rsp+0x40]
0000713aae5db19a  vmovaps xmm5, [rsp+0x50]
0000713aae5db1a0  vmovaps xmm6, [rsp+0x60]
0000713aae5db1a6  vmovaps xmm7, [rsp+0x70]
0000713aae5db1ac  vmovaps xmm8, [rsp+0x80]
0000713aae5db1b5  vmovaps xmm9, [rsp+0x90]
0000713aae5db1be  vmovaps xmm10, [rsp+0xA0]
0000713aae5db1c7  vmovaps xmm11, [rsp+0xB0]
0000713aae5db1d0  vmovaps xmm13, [rsp+0xC0]
0000713aae5db1d9  vmovaps xmm14, [rsp+0xD0]
0000713aae5db1e2  vmovaps xmm15, [rsp+0xE0]
0000713aae5db1eb  add rsp, 0xF0
0000713aae5db1f2  pop r11
0000713aae5db1f4  pop r10
0000713aae5db1f6  pop r9
0000713aae5db1f8  pop r8
0000713aae5db1fa  pop rsi
0000713aae5db1fb  pop rdi
0000713aae5db1fc  pop rdx
0000713aae5db1fd  pop rcx
0000713aae5db1fe  pop rax
0000713aae5db1ff  add rsp, 0x08
0000713aae5db203  jmp 0x0000713AAE5DA0B3
0000713aae5db208  sub rsp, 0x08
0000713aae5db20c  push rax
0000713aae5db20d  push rcx
0000713aae5db20e  push rdx
0000713aae5db20f  push rdi
0000713aae5db210  push rsi
0000713aae5db211  push r8
0000713aae5db213  push r9
0000713aae5db215  push r10
0000713aae5db217  push r11
0000713aae5db219  sub rsp, 0xF0
0000713aae5db220  vmovaps [rsp], xmm0
0000713aae5db225  vmovaps [rsp+0x10], xmm1
0000713aae5db22b  vmovaps [rsp+0x20], xmm2
0000713aae5db231  vmovaps [rsp+0x30], xmm3
0000713aae5db237  vmovaps [rsp+0x40], xmm4
0000713aae5db23d  vmovaps [rsp+0x50], xmm5
0000713aae5db243  vmovaps [rsp+0x60], xmm6
0000713aae5db249  vmovaps [rsp+0x70], xmm7
0000713aae5db24f  vmovaps [rsp+0x80], xmm8
0000713aae5db258  vmovaps [rsp+0x90], xmm10
0000713aae5db261  vmovaps [rsp+0xA0], xmm11
0000713aae5db26a  vmovaps [rsp+0xB0], xmm12
0000713aae5db273  vmovaps [rsp+0xC0], xmm13
0000713aae5db27c  vmovaps [rsp+0xD0], xmm14
0000713aae5db285  vmovaps [rsp+0xE0], xmm15
0000713aae5db28e  sub rsp, 0x40
0000713aae5db292  lea rdi, [rsp]
0000713aae5db296  lea rsi, [rsp+0x10]
0000713aae5db29b  lea rdx, [rsp+0x20]
0000713aae5db2a0  lea rcx, [rsp+0x30]
0000713aae5db2a5  mov r8d, 0x00
0000713aae5db2ab  lea r9, [r15+0x3A8]
0000713aae5db2b2  movaps [rdi], xmm9
0000713aae5db2b6  movaps [rsi], xmm13
0000713aae5db2ba  movaps [rdx], xmm14
0000713aae5db2be  movaps [rcx], xmm6
0000713aae5db2c1  mov rax, 0x5E9381C89A50
0000713aae5db2cb  call rax
0000713aae5db2cd  movaps xmm9, [rsp]
0000713aae5db2d2  add rsp, 0x40
0000713aae5db2d6  vmovaps xmm0, [rsp]
0000713aae5db2db  vmovaps xmm1, [rsp+0x10]
0000713aae5db2e1  vmovaps xmm2, [rsp+0x20]
0000713aae5db2e7  vmovaps xmm3, [rsp+0x30]
0000713aae5db2ed  vmovaps xmm4, [rsp+0x40]
0000713aae5db2f3  vmovaps xmm5, [rsp+0x50]
0000713aae5db2f9  vmovaps xmm6, [rsp+0x60]
0000713aae5db2ff  vmovaps xmm7, [rsp+0x70]
0000713aae5db305  vmovaps xmm8, [rsp+0x80]
0000713aae5db30e  vmovaps xmm10, [rsp+0x90]
0000713aae5db317  vmovaps xmm11, [rsp+0xA0]
0000713aae5db320  vmovaps xmm12, [rsp+0xB0]
0000713aae5db329  vmovaps xmm13, [rsp+0xC0]
0000713aae5db332  vmovaps xmm14, [rsp+0xD0]
0000713aae5db33b  vmovaps xmm15, [rsp+0xE0]
0000713aae5db344  add rsp, 0xF0
0000713aae5db34b  pop r11
0000713aae5db34d  pop r10
0000713aae5db34f  pop r9
0000713aae5db351  pop r8
0000713aae5db353  pop rsi
0000713aae5db354  pop rdi
0000713aae5db355  pop rdx
0000713aae5db356  pop rcx
0000713aae5db357  pop rax
0000713aae5db358  add rsp, 0x08
0000713aae5db35c  jmp 0x0000713AAE5DA15D
0000713aae5db361  sub rsp, 0x08
0000713aae5db365  push rax
0000713aae5db366  push rcx
0000713aae5db367  push rdx
0000713aae5db368  push rdi
0000713aae5db369  push rsi
0000713aae5db36a  push r8
0000713aae5db36c  push r9
0000713aae5db36e  push r10
0000713aae5db370  push r11
0000713aae5db372  sub rsp, 0xF0
0000713aae5db379  vmovaps [rsp], xmm0
0000713aae5db37e  vmovaps [rsp+0x10], xmm1
0000713aae5db384  vmovaps [rsp+0x20], xmm2
0000713aae5db38a  vmovaps [rsp+0x30], xmm4
0000713aae5db390  vmovaps [rsp+0x40], xmm5
0000713aae5db396  vmovaps [rsp+0x50], xmm6
0000713aae5db39c  vmovaps [rsp+0x60], xmm7
0000713aae5db3a2  vmovaps [rsp+0x70], xmm8
0000713aae5db3a8  vmovaps [rsp+0x80], xmm9
0000713aae5db3b1  vmovaps [rsp+0x90], xmm10
0000713aae5db3ba  vmovaps [rsp+0xA0], xmm11
0000713aae5db3c3  vmovaps [rsp+0xB0], xmm12
0000713aae5db3cc  vmovaps [rsp+0xC0], xmm13
0000713aae5db3d5  vmovaps [rsp+0xD0], xmm14
0000713aae5db3de  vmovaps [rsp+0xE0], xmm15
0000713aae5db3e7  sub rsp, 0x40
0000713aae5db3eb  lea rdi, [rsp]
0000713aae5db3ef  lea rsi, [rsp+0x10]
0000713aae5db3f4  lea rdx, [rsp+0x20]
0000713aae5db3f9  lea rcx, [rsp+0x30]
0000713aae5db3fe  mov r8d, 0x00
0000713aae5db404  lea r9, [r15+0x3A8]
0000713aae5db40b  movaps [rdi], xmm3
0000713aae5db40e  movaps [rsi], xmm13
0000713aae5db412  movaps [rdx], xmm6
0000713aae5db415  movaps [rcx], xmm14
0000713aae5db419  mov rax, 0x5E9381C89A50
0000713aae5db423  call rax
0000713aae5db425  movaps xmm3, [rsp]
0000713aae5db429  add rsp, 0x40
0000713aae5db42d  vmovaps xmm0, [rsp]
0000713aae5db432  vmovaps xmm1, [rsp+0x10]
0000713aae5db438  vmovaps xmm2, [rsp+0x20]
0000713aae5db43e  vmovaps xmm4, [rsp+0x30]
0000713aae5db444  vmovaps xmm5, [rsp+0x40]
0000713aae5db44a  vmovaps xmm6, [rsp+0x50]
0000713aae5db450  vmovaps xmm7, [rsp+0x60]
0000713aae5db456  vmovaps xmm8, [rsp+0x70]
0000713aae5db45c  vmovaps xmm9, [rsp+0x80]
0000713aae5db465  vmovaps xmm10, [rsp+0x90]
0000713aae5db46e  vmovaps xmm11, [rsp+0xA0]
0000713aae5db477  vmovaps xmm12, [rsp+0xB0]
0000713aae5db480  vmovaps xmm13, [rsp+0xC0]
0000713aae5db489  vmovaps xmm14, [rsp+0xD0]
0000713aae5db492  vmovaps xmm15, [rsp+0xE0]
0000713aae5db49b  add rsp, 0xF0
0000713aae5db4a2  pop r11
0000713aae5db4a4  pop r10
0000713aae5db4a6  pop r9
0000713aae5db4a8  pop r8
0000713aae5db4aa  pop rsi
0000713aae5db4ab  pop rdi
0000713aae5db4ac  pop rdx
0000713aae5db4ad  pop rcx
0000713aae5db4ae  pop rax
0000713aae5db4af  add rsp, 0x08
0000713aae5db4b3  jmp 0x0000713AAE5DA19A
0000713aae5db4b8  sub rsp, 0x08
0000713aae5db4bc  push rax
0000713aae5db4bd  push rcx
0000713aae5db4be  push rdx
0000713aae5db4bf  push rdi
0000713aae5db4c0  push rsi
0000713aae5db4c1  push r8
0000713aae5db4c3  push r9
0000713aae5db4c5  push r10
0000713aae5db4c7  push r11
0000713aae5db4c9  sub rsp, 0xF0
0000713aae5db4d0  vmovaps [rsp], xmm0
0000713aae5db4d5  vmovaps [rsp+0x10], xmm1
0000713aae5db4db  vmovaps [rsp+0x20], xmm2
0000713aae5db4e1  vmovaps [rsp+0x30], xmm3
0000713aae5db4e7  vmovaps [rsp+0x40], xmm4
0000713aae5db4ed  vmovaps [rsp+0x50], xmm5
0000713aae5db4f3  vmovaps [rsp+0x60], xmm7
0000713aae5db4f9  vmovaps [rsp+0x70], xmm8
0000713aae5db4ff  vmovaps [rsp+0x80], xmm9
0000713aae5db508  vmovaps [rsp+0x90], xmm10
0000713aae5db511  vmovaps [rsp+0xA0], xmm11
0000713aae5db51a  vmovaps [rsp+0xB0], xmm12
0000713aae5db523  vmovaps [rsp+0xC0], xmm13
0000713aae5db52c  vmovaps [rsp+0xD0], xmm14
0000713aae5db535  vmovaps [rsp+0xE0], xmm15
0000713aae5db53e  sub rsp, 0x40
0000713aae5db542  lea rdi, [rsp]
0000713aae5db546  lea rsi, [rsp+0x10]
0000713aae5db54b  lea rdx, [rsp+0x20]
0000713aae5db550  lea rcx, [rsp+0x30]
0000713aae5db555  mov r8d, 0x00
0000713aae5db55b  lea r9, [r15+0x3A8]
0000713aae5db562  movaps [rdi], xmm6
0000713aae5db565  movaps [rsi], xmm2
0000713aae5db568  movaps [rdx], xmm14
0000713aae5db56c  movaps [rcx], xmm1
0000713aae5db56f  mov rax, 0x5E9381C89A50
0000713aae5db579  call rax
0000713aae5db57b  movaps xmm6, [rsp]
0000713aae5db57f  add rsp, 0x40
0000713aae5db583  vmovaps xmm0, [rsp]
0000713aae5db588  vmovaps xmm1, [rsp+0x10]
0000713aae5db58e  vmovaps xmm2, [rsp+0x20]
0000713aae5db594  vmovaps xmm3, [rsp+0x30]
0000713aae5db59a  vmovaps xmm4, [rsp+0x40]
0000713aae5db5a0  vmovaps xmm5, [rsp+0x50]
0000713aae5db5a6  vmovaps xmm7, [rsp+0x60]
0000713aae5db5ac  vmovaps xmm8, [rsp+0x70]
0000713aae5db5b2  vmovaps xmm9, [rsp+0x80]
0000713aae5db5bb  vmovaps xmm10, [rsp+0x90]
0000713aae5db5c4  vmovaps xmm11, [rsp+0xA0]
0000713aae5db5cd  vmovaps xmm12, [rsp+0xB0]
0000713aae5db5d6  vmovaps xmm13, [rsp+0xC0]
0000713aae5db5df  vmovaps xmm14, [rsp+0xD0]
0000713aae5db5e8  vmovaps xmm15, [rsp+0xE0]
0000713aae5db5f1  add rsp, 0xF0
0000713aae5db5f8  pop r11
0000713aae5db5fa  pop r10
0000713aae5db5fc  pop r9
0000713aae5db5fe  pop r8
0000713aae5db600  pop rsi
0000713aae5db601  pop rdi
0000713aae5db602  pop rdx
0000713aae5db603  pop rcx
0000713aae5db604  pop rax
0000713aae5db605  add rsp, 0x08
0000713aae5db609  jmp 0x0000713AAE5DA1C7
0000713aae5db60e  sub rsp, 0x08
0000713aae5db612  push rax
0000713aae5db613  push rcx
0000713aae5db614  push rdx
0000713aae5db615  push rdi
0000713aae5db616  push rsi
0000713aae5db617  push r8
0000713aae5db619  push r9
0000713aae5db61b  push r10
0000713aae5db61d  push r11
0000713aae5db61f  sub rsp, 0xF0
0000713aae5db626  vmovaps [rsp], xmm0
0000713aae5db62b  vmovaps [rsp+0x10], xmm1
0000713aae5db631  vmovaps [rsp+0x20], xmm2
0000713aae5db637  vmovaps [rsp+0x30], xmm3
0000713aae5db63d  vmovaps [rsp+0x40], xmm4
0000713aae5db643  vmovaps [rsp+0x50], xmm5
0000713aae5db649  vmovaps [rsp+0x60], xmm6
0000713aae5db64f  vmovaps [rsp+0x70], xmm7
0000713aae5db655  vmovaps [rsp+0x80], xmm8
0000713aae5db65e  vmovaps [rsp+0x90], xmm9
0000713aae5db667  vmovaps [rsp+0xA0], xmm10
0000713aae5db670  vmovaps [rsp+0xB0], xmm11
0000713aae5db679  vmovaps [rsp+0xC0], xmm12
0000713aae5db682  vmovaps [rsp+0xD0], xmm14
0000713aae5db68b  vmovaps [rsp+0xE0], xmm15
0000713aae5db694  sub rsp, 0x40
0000713aae5db698  lea rdi, [rsp]
0000713aae5db69c  lea rsi, [rsp+0x10]
0000713aae5db6a1  lea rdx, [rsp+0x20]
0000713aae5db6a6  lea rcx, [rsp+0x30]
0000713aae5db6ab  mov r8d, 0x00
0000713aae5db6b1  lea r9, [r15+0x3A8]
0000713aae5db6b8  movaps [rdi], xmm13
0000713aae5db6bc  movaps [rsi], xmm12
0000713aae5db6c0  movaps [rdx], xmm14
0000713aae5db6c4  movaps [rcx], xmm1
0000713aae5db6c7  mov rax, 0x5E9381C89A50
0000713aae5db6d1  call rax
0000713aae5db6d3  movaps xmm13, [rsp]
0000713aae5db6d8  add rsp, 0x40
0000713aae5db6dc  vmovaps xmm0, [rsp]
0000713aae5db6e1  vmovaps xmm1, [rsp+0x10]
0000713aae5db6e7  vmovaps xmm2, [rsp+0x20]
0000713aae5db6ed  vmovaps xmm3, [rsp+0x30]
0000713aae5db6f3  vmovaps xmm4, [rsp+0x40]
0000713aae5db6f9  vmovaps xmm5, [rsp+0x50]
0000713aae5db6ff  vmovaps xmm6, [rsp+0x60]
0000713aae5db705  vmovaps xmm7, [rsp+0x70]
0000713aae5db70b  vmovaps xmm8, [rsp+0x80]
0000713aae5db714  vmovaps xmm9, [rsp+0x90]
0000713aae5db71d  vmovaps xmm10, [rsp+0xA0]
0000713aae5db726  vmovaps xmm11, [rsp+0xB0]
0000713aae5db72f  vmovaps xmm12, [rsp+0xC0]
0000713aae5db738  vmovaps xmm14, [rsp+0xD0]
0000713aae5db741  vmovaps xmm15, [rsp+0xE0]
0000713aae5db74a  add rsp, 0xF0
0000713aae5db751  pop r11
0000713aae5db753  pop r10
0000713aae5db755  pop r9
0000713aae5db757  pop r8
0000713aae5db759  pop rsi
0000713aae5db75a  pop rdi
0000713aae5db75b  pop rdx
0000713aae5db75c  pop rcx
0000713aae5db75d  pop rax
0000713aae5db75e  add rsp, 0x08
0000713aae5db762  jmp 0x0000713AAE5DA1F9
0000713aae5db767  sub rsp, 0x08
0000713aae5db76b  push rax
0000713aae5db76c  push rcx
0000713aae5db76d  push rdx
0000713aae5db76e  push rdi
0000713aae5db76f  push rsi
0000713aae5db770  push r8
0000713aae5db772  push r9
0000713aae5db774  push r10
0000713aae5db776  push r11
0000713aae5db778  sub rsp, 0xF0
0000713aae5db77f  vmovaps [rsp], xmm0
0000713aae5db784  vmovaps [rsp+0x10], xmm1
0000713aae5db78a  vmovaps [rsp+0x20], xmm2
0000713aae5db790  vmovaps [rsp+0x30], xmm3
0000713aae5db796  vmovaps [rsp+0x40], xmm4
0000713aae5db79c  vmovaps [rsp+0x50], xmm5
0000713aae5db7a2  vmovaps [rsp+0x60], xmm6
0000713aae5db7a8  vmovaps [rsp+0x70], xmm7
0000713aae5db7ae  vmovaps [rsp+0x80], xmm8
0000713aae5db7b7  vmovaps [rsp+0x90], xmm9
0000713aae5db7c0  vmovaps [rsp+0xA0], xmm10
0000713aae5db7c9  vmovaps [rsp+0xB0], xmm11
0000713aae5db7d2  vmovaps [rsp+0xC0], xmm13
0000713aae5db7db  vmovaps [rsp+0xD0], xmm14
0000713aae5db7e4  vmovaps [rsp+0xE0], xmm15
0000713aae5db7ed  sub rsp, 0x40
0000713aae5db7f1  lea rdi, [rsp]
0000713aae5db7f5  lea rsi, [rsp+0x10]
0000713aae5db7fa  lea rdx, [rsp+0x20]
0000713aae5db7ff  lea rcx, [rsp+0x30]
0000713aae5db804  mov r8d, 0x00
0000713aae5db80a  lea r9, [r15+0x3A8]
0000713aae5db811  movaps [rdi], xmm12
0000713aae5db815  movaps [rsi], xmm3
0000713aae5db818  movaps [rdx], xmm14
0000713aae5db81c  movaps [rcx], xmm5
0000713aae5db81f  mov rax, 0x5E9381C89A50
0000713aae5db829  call rax
0000713aae5db82b  movaps xmm12, [rsp]
0000713aae5db830  add rsp, 0x40
0000713aae5db834  vmovaps xmm0, [rsp]
0000713aae5db839  vmovaps xmm1, [rsp+0x10]
0000713aae5db83f  vmovaps xmm2, [rsp+0x20]
0000713aae5db845  vmovaps xmm3, [rsp+0x30]
0000713aae5db84b  vmovaps xmm4, [rsp+0x40]
0000713aae5db851  vmovaps xmm5, [rsp+0x50]
0000713aae5db857  vmovaps xmm6, [rsp+0x60]
0000713aae5db85d  vmovaps xmm7, [rsp+0x70]
0000713aae5db863  vmovaps xmm8, [rsp+0x80]
0000713aae5db86c  vmovaps xmm9, [rsp+0x90]
0000713aae5db875  vmovaps xmm10, [rsp+0xA0]
0000713aae5db87e  vmovaps xmm11, [rsp+0xB0]
0000713aae5db887  vmovaps xmm13, [rsp+0xC0]
0000713aae5db890  vmovaps xmm14, [rsp+0xD0]
0000713aae5db899  vmovaps xmm15, [rsp+0xE0]
0000713aae5db8a2  add rsp, 0xF0
0000713aae5db8a9  pop r11
0000713aae5db8ab  pop r10
0000713aae5db8ad  pop r9
0000713aae5db8af  pop r8
0000713aae5db8b1  pop rsi
0000713aae5db8b2  pop rdi
0000713aae5db8b3  pop rdx
0000713aae5db8b4  pop rcx
0000713aae5db8b5  pop rax
0000713aae5db8b6  add rsp, 0x08
0000713aae5db8ba  jmp 0x0000713AAE5DA256
0000713aae5db8bf  sub rsp, 0x08
0000713aae5db8c3  push rax
0000713aae5db8c4  push rcx
0000713aae5db8c5  push rdx
0000713aae5db8c6  push rdi
0000713aae5db8c7  push rsi
0000713aae5db8c8  push r8
0000713aae5db8ca  push r9
0000713aae5db8cc  push r10
0000713aae5db8ce  push r11
0000713aae5db8d0  sub rsp, 0xF0
0000713aae5db8d7  vmovaps [rsp], xmm0
0000713aae5db8dc  vmovaps [rsp+0x10], xmm1
0000713aae5db8e2  vmovaps [rsp+0x20], xmm2
0000713aae5db8e8  vmovaps [rsp+0x30], xmm3
0000713aae5db8ee  vmovaps [rsp+0x40], xmm4
0000713aae5db8f4  vmovaps [rsp+0x50], xmm5
0000713aae5db8fa  vmovaps [rsp+0x60], xmm6
0000713aae5db900  vmovaps [rsp+0x70], xmm7
0000713aae5db906  vmovaps [rsp+0x80], xmm8
0000713aae5db90f  vmovaps [rsp+0x90], xmm9
0000713aae5db918  vmovaps [rsp+0xA0], xmm11
0000713aae5db921  vmovaps [rsp+0xB0], xmm12
0000713aae5db92a  vmovaps [rsp+0xC0], xmm13
0000713aae5db933  vmovaps [rsp+0xD0], xmm14
0000713aae5db93c  vmovaps [rsp+0xE0], xmm15
0000713aae5db945  sub rsp, 0x40
0000713aae5db949  lea rdi, [rsp]
0000713aae5db94d  lea rsi, [rsp+0x10]
0000713aae5db952  lea rdx, [rsp+0x20]
0000713aae5db957  lea rcx, [rsp+0x30]
0000713aae5db95c  mov r8d, 0x00
0000713aae5db962  lea r9, [r15+0x3A8]
0000713aae5db969  movaps [rdi], xmm10
0000713aae5db96d  movaps [rsi], xmm9
0000713aae5db971  movaps [rdx], xmm7
0000713aae5db974  movaps [rcx], xmm14
0000713aae5db978  mov rax, 0x5E9381C89A50
0000713aae5db982  call rax
0000713aae5db984  movaps xmm10, [rsp]
0000713aae5db989  add rsp, 0x40
0000713aae5db98d  vmovaps xmm0, [rsp]
0000713aae5db992  vmovaps xmm1, [rsp+0x10]
0000713aae5db998  vmovaps xmm2, [rsp+0x20]
0000713aae5db99e  vmovaps xmm3, [rsp+0x30]
0000713aae5db9a4  vmovaps xmm4, [rsp+0x40]
0000713aae5db9aa  vmovaps xmm5, [rsp+0x50]
0000713aae5db9b0  vmovaps xmm6, [rsp+0x60]
0000713aae5db9b6  vmovaps xmm7, [rsp+0x70]
0000713aae5db9bc  vmovaps xmm8, [rsp+0x80]
0000713aae5db9c5  vmovaps xmm9, [rsp+0x90]
0000713aae5db9ce  vmovaps xmm11, [rsp+0xA0]
0000713aae5db9d7  vmovaps xmm12, [rsp+0xB0]
0000713aae5db9e0  vmovaps xmm13, [rsp+0xC0]
0000713aae5db9e9  vmovaps xmm14, [rsp+0xD0]
0000713aae5db9f2  vmovaps xmm15, [rsp+0xE0]
0000713aae5db9fb  add rsp, 0xF0
0000713aae5dba02  pop r11
0000713aae5dba04  pop r10
0000713aae5dba06  pop r9
0000713aae5dba08  pop r8
0000713aae5dba0a  pop rsi
0000713aae5dba0b  pop rdi
0000713aae5dba0c  pop rdx
0000713aae5dba0d  pop rcx
0000713aae5dba0e  pop rax
0000713aae5dba0f  add rsp, 0x08
0000713aae5dba13  jmp 0x0000713AAE5DA27C
0000713aae5dba18  call 0x0000713AAE40D4E0
0000713aae5dba1d  jmp 0x0000713AAE5DA289
0000713aae5dba22  sub rsp, 0x08
0000713aae5dba26  push rax
0000713aae5dba27  push rcx
0000713aae5dba28  push rdx
0000713aae5dba29  push rdi
0000713aae5dba2a  push rsi
0000713aae5dba2b  push r8
0000713aae5dba2d  push r9
0000713aae5dba2f  push r10
0000713aae5dba31  push r11
0000713aae5dba33  sub rsp, 0xF0
0000713aae5dba3a  vmovaps [rsp], xmm0
0000713aae5dba3f  vmovaps [rsp+0x10], xmm1
0000713aae5dba45  vmovaps [rsp+0x20], xmm2
0000713aae5dba4b  vmovaps [rsp+0x30], xmm3
0000713aae5dba51  vmovaps [rsp+0x40], xmm4
0000713aae5dba57  vmovaps [rsp+0x50], xmm6
0000713aae5dba5d  vmovaps [rsp+0x60], xmm7
0000713aae5dba63  vmovaps [rsp+0x70], xmm8
0000713aae5dba69  vmovaps [rsp+0x80], xmm9
0000713aae5dba72  vmovaps [rsp+0x90], xmm10
0000713aae5dba7b  vmovaps [rsp+0xA0], xmm11
0000713aae5dba84  vmovaps [rsp+0xB0], xmm12
0000713aae5dba8d  vmovaps [rsp+0xC0], xmm13
0000713aae5dba96  vmovaps [rsp+0xD0], xmm14
0000713aae5dba9f  vmovaps [rsp+0xE0], xmm15
0000713aae5dbaa8  sub rsp, 0x40
0000713aae5dbaac  lea rdi, [rsp]
0000713aae5dbab0  lea rsi, [rsp+0x10]
0000713aae5dbab5  lea rdx, [rsp+0x20]
0000713aae5dbaba  lea rcx, [rsp+0x30]
0000713aae5dbabf  mov r8d, 0x00
0000713aae5dbac5  lea r9, [r15+0x3A8]
0000713aae5dbacc  movaps [rdi], xmm5
0000713aae5dbacf  movaps [rsi], xmm6
0000713aae5dbad2  movaps [rdx], xmm7
0000713aae5dbad5  movaps [rcx], xmm9
0000713aae5dbad9  mov rax, 0x5E9381C89A50
0000713aae5dbae3  call rax
0000713aae5dbae5  movaps xmm5, [rsp]
0000713aae5dbae9  add rsp, 0x40
0000713aae5dbaed  vmovaps xmm0, [rsp]
0000713aae5dbaf2  vmovaps xmm1, [rsp+0x10]
0000713aae5dbaf8  vmovaps xmm2, [rsp+0x20]
0000713aae5dbafe  vmovaps xmm3, [rsp+0x30]
0000713aae5dbb04  vmovaps xmm4, [rsp+0x40]
0000713aae5dbb0a  vmovaps xmm6, [rsp+0x50]
0000713aae5dbb10  vmovaps xmm7, [rsp+0x60]
0000713aae5dbb16  vmovaps xmm8, [rsp+0x70]
0000713aae5dbb1c  vmovaps xmm9, [rsp+0x80]
0000713aae5dbb25  vmovaps xmm10, [rsp+0x90]
0000713aae5dbb2e  vmovaps xmm11, [rsp+0xA0]
0000713aae5dbb37  vmovaps xmm12, [rsp+0xB0]
0000713aae5dbb40  vmovaps xmm13, [rsp+0xC0]
0000713aae5dbb49  vmovaps xmm14, [rsp+0xD0]
0000713aae5dbb52  vmovaps xmm15, [rsp+0xE0]
0000713aae5dbb5b  add rsp, 0xF0
0000713aae5dbb62  pop r11
0000713aae5dbb64  pop r10
0000713aae5dbb66  pop r9
0000713aae5dbb68  pop r8
0000713aae5dbb6a  pop rsi
0000713aae5dbb6b  pop rdi
0000713aae5dbb6c  pop rdx
0000713aae5dbb6d  pop rcx
0000713aae5dbb6e  pop rax
0000713aae5dbb6f  add rsp, 0x08
0000713aae5dbb73  jmp 0x0000713AAE5DA2BB
0000713aae5dbb78  sub rsp, 0x08
0000713aae5dbb7c  push rax
0000713aae5dbb7d  push rcx
0000713aae5dbb7e  push rdx
0000713aae5dbb7f  push rdi
0000713aae5dbb80  push rsi
0000713aae5dbb81  push r8
0000713aae5dbb83  push r9
0000713aae5dbb85  push r10
0000713aae5dbb87  push r11
0000713aae5dbb89  sub rsp, 0xF0
0000713aae5dbb90  vmovaps [rsp], xmm0
0000713aae5dbb95  vmovaps [rsp+0x10], xmm1
0000713aae5dbb9b  vmovaps [rsp+0x20], xmm2
0000713aae5dbba1  vmovaps [rsp+0x30], xmm3
0000713aae5dbba7  vmovaps [rsp+0x40], xmm4
0000713aae5dbbad  vmovaps [rsp+0x50], xmm5
0000713aae5dbbb3  vmovaps [rsp+0x60], xmm6
0000713aae5dbbb9  vmovaps [rsp+0x70], xmm8
0000713aae5dbbbf  vmovaps [rsp+0x80], xmm9
0000713aae5dbbc8  vmovaps [rsp+0x90], xmm10
0000713aae5dbbd1  vmovaps [rsp+0xA0], xmm11
0000713aae5dbbda  vmovaps [rsp+0xB0], xmm12
0000713aae5dbbe3  vmovaps [rsp+0xC0], xmm13
0000713aae5dbbec  vmovaps [rsp+0xD0], xmm14
0000713aae5dbbf5  vmovaps [rsp+0xE0], xmm15
0000713aae5dbbfe  sub rsp, 0x40
0000713aae5dbc02  lea rdi, [rsp]
0000713aae5dbc06  lea rsi, [rsp+0x10]
0000713aae5dbc0b  lea rdx, [rsp+0x20]
0000713aae5dbc10  lea rcx, [rsp+0x30]
0000713aae5dbc15  mov r8d, 0x00
0000713aae5dbc1b  lea r9, [r15+0x3A8]
0000713aae5dbc22  movaps [rdi], xmm7
0000713aae5dbc25  movaps [rsi], xmm13
0000713aae5dbc29  movaps [rdx], xmm1
0000713aae5dbc2c  movaps [rcx], xmm9
0000713aae5dbc30  mov rax, 0x5E9381C89A50
0000713aae5dbc3a  call rax
0000713aae5dbc3c  movaps xmm7, [rsp]
0000713aae5dbc40  add rsp, 0x40
0000713aae5dbc44  vmovaps xmm0, [rsp]
0000713aae5dbc49  vmovaps xmm1, [rsp+0x10]
0000713aae5dbc4f  vmovaps xmm2, [rsp+0x20]
0000713aae5dbc55  vmovaps xmm3, [rsp+0x30]
0000713aae5dbc5b  vmovaps xmm4, [rsp+0x40]
0000713aae5dbc61  vmovaps xmm5, [rsp+0x50]
0000713aae5dbc67  vmovaps xmm6, [rsp+0x60]
0000713aae5dbc6d  vmovaps xmm8, [rsp+0x70]
0000713aae5dbc73  vmovaps xmm9, [rsp+0x80]
0000713aae5dbc7c  vmovaps xmm10, [rsp+0x90]
0000713aae5dbc85  vmovaps xmm11, [rsp+0xA0]
0000713aae5dbc8e  vmovaps xmm12, [rsp+0xB0]
0000713aae5dbc97  vmovaps xmm13, [rsp+0xC0]
0000713aae5dbca0  vmovaps xmm14, [rsp+0xD0]
0000713aae5dbca9  vmovaps xmm15, [rsp+0xE0]
0000713aae5dbcb2  add rsp, 0xF0
0000713aae5dbcb9  pop r11
0000713aae5dbcbb  pop r10
0000713aae5dbcbd  pop r9
0000713aae5dbcbf  pop r8
0000713aae5dbcc1  pop rsi
0000713aae5dbcc2  pop rdi
0000713aae5dbcc3  pop rdx
0000713aae5dbcc4  pop rcx
0000713aae5dbcc5  pop rax
0000713aae5dbcc6  add rsp, 0x08
0000713aae5dbcca  jmp 0x0000713AAE5DA2E0
0000713aae5dbccf  call 0x0000713AAE40C260
0000713aae5dbcd4  jmp 0x0000713AAE5DA303
0000713aae5dbcd9  call 0x0000713AAE407890
0000713aae5dbcde  jmp 0x0000713AAE5DA30D
0000713aae5dbce3  sub rsp, 0x08
0000713aae5dbce7  push rax
0000713aae5dbce8  push rcx
0000713aae5dbce9  push rdx
0000713aae5dbcea  push rdi
0000713aae5dbceb  push rsi
0000713aae5dbcec  push r8
0000713aae5dbcee  push r9
0000713aae5dbcf0  push r10
0000713aae5dbcf2  push r11
0000713aae5dbcf4  sub rsp, 0xF0
0000713aae5dbcfb  vmovaps [rsp], xmm0
0000713aae5dbd00  vmovaps [rsp+0x10], xmm1
0000713aae5dbd06  vmovaps [rsp+0x20], xmm3
0000713aae5dbd0c  vmovaps [rsp+0x30], xmm4
0000713aae5dbd12  vmovaps [rsp+0x40], xmm5
0000713aae5dbd18  vmovaps [rsp+0x50], xmm6
0000713aae5dbd1e  vmovaps [rsp+0x60], xmm7
0000713aae5dbd24  vmovaps [rsp+0x70], xmm8
0000713aae5dbd2a  vmovaps [rsp+0x80], xmm9
0000713aae5dbd33  vmovaps [rsp+0x90], xmm10
0000713aae5dbd3c  vmovaps [rsp+0xA0], xmm11
0000713aae5dbd45  vmovaps [rsp+0xB0], xmm12
0000713aae5dbd4e  vmovaps [rsp+0xC0], xmm13
0000713aae5dbd57  vmovaps [rsp+0xD0], xmm14
0000713aae5dbd60  vmovaps [rsp+0xE0], xmm15
0000713aae5dbd69  sub rsp, 0x40
0000713aae5dbd6d  lea rdi, [rsp]
0000713aae5dbd71  lea rsi, [rsp+0x10]
0000713aae5dbd76  lea rdx, [rsp+0x20]
0000713aae5dbd7b  lea rcx, [rsp+0x30]
0000713aae5dbd80  mov r8d, 0x00
0000713aae5dbd86  lea r9, [r15+0x3A8]
0000713aae5dbd8d  movaps [rdi], xmm2
0000713aae5dbd90  movaps [rsi], xmm12
0000713aae5dbd94  movaps [rdx], xmm6
0000713aae5dbd97  movaps [rcx], xmm3
0000713aae5dbd9a  mov rax, 0x5E9381C89A50
0000713aae5dbda4  call rax
0000713aae5dbda6  movaps xmm2, [rsp]
0000713aae5dbdaa  add rsp, 0x40
0000713aae5dbdae  vmovaps xmm0, [rsp]
0000713aae5dbdb3  vmovaps xmm1, [rsp+0x10]
0000713aae5dbdb9  vmovaps xmm3, [rsp+0x20]
0000713aae5dbdbf  vmovaps xmm4, [rsp+0x30]
0000713aae5dbdc5  vmovaps xmm5, [rsp+0x40]
0000713aae5dbdcb  vmovaps xmm6, [rsp+0x50]
0000713aae5dbdd1  vmovaps xmm7, [rsp+0x60]
0000713aae5dbdd7  vmovaps xmm8, [rsp+0x70]
0000713aae5dbddd  vmovaps xmm9, [rsp+0x80]
0000713aae5dbde6  vmovaps xmm10, [rsp+0x90]
0000713aae5dbdef  vmovaps xmm11, [rsp+0xA0]
0000713aae5dbdf8  vmovaps xmm12, [rsp+0xB0]
0000713aae5dbe01  vmovaps xmm13, [rsp+0xC0]
0000713aae5dbe0a  vmovaps xmm14, [rsp+0xD0]
0000713aae5dbe13  vmovaps xmm15, [rsp+0xE0]
0000713aae5dbe1c  add rsp, 0xF0
0000713aae5dbe23  pop r11
0000713aae5dbe25  pop r10
0000713aae5dbe27  pop r9
0000713aae5dbe29  pop r8
0000713aae5dbe2b  pop rsi
0000713aae5dbe2c  pop rdi
0000713aae5dbe2d  pop rdx
0000713aae5dbe2e  pop rcx
0000713aae5dbe2f  pop rax
0000713aae5dbe30  add rsp, 0x08
0000713aae5dbe34  jmp 0x0000713AAE5DA353
0000713aae5dbe39  sub rsp, 0x08
0000713aae5dbe3d  push rax
0000713aae5dbe3e  push rcx
0000713aae5dbe3f  push rdx
0000713aae5dbe40  push rdi
0000713aae5dbe41  push rsi
0000713aae5dbe42  push r8
0000713aae5dbe44  push r9
0000713aae5dbe46  push r10
0000713aae5dbe48  push r11
0000713aae5dbe4a  sub rsp, 0xF0
0000713aae5dbe51  vmovaps [rsp], xmm0
0000713aae5dbe56  vmovaps [rsp+0x10], xmm1
0000713aae5dbe5c  vmovaps [rsp+0x20], xmm2
0000713aae5dbe62  vmovaps [rsp+0x30], xmm3
0000713aae5dbe68  vmovaps [rsp+0x40], xmm4
0000713aae5dbe6e  vmovaps [rsp+0x50], xmm5
0000713aae5dbe74  vmovaps [rsp+0x60], xmm7
0000713aae5dbe7a  vmovaps [rsp+0x70], xmm8
0000713aae5dbe80  vmovaps [rsp+0x80], xmm9
0000713aae5dbe89  vmovaps [rsp+0x90], xmm10
0000713aae5dbe92  vmovaps [rsp+0xA0], xmm11
0000713aae5dbe9b  vmovaps [rsp+0xB0], xmm12
0000713aae5dbea4  vmovaps [rsp+0xC0], xmm13
0000713aae5dbead  vmovaps [rsp+0xD0], xmm14
0000713aae5dbeb6  vmovaps [rsp+0xE0], xmm15
0000713aae5dbebf  sub rsp, 0x40
0000713aae5dbec3  lea rdi, [rsp]
0000713aae5dbec7  lea rsi, [rsp+0x10]
0000713aae5dbecc  lea rdx, [rsp+0x20]
0000713aae5dbed1  lea rcx, [rsp+0x30]
0000713aae5dbed6  mov r8d, 0x00
0000713aae5dbedc  lea r9, [r15+0x3A8]
0000713aae5dbee3  movaps [rdi], xmm6
0000713aae5dbee6  movaps [rsi], xmm10
0000713aae5dbeea  movaps [rdx], xmm12
0000713aae5dbeee  movaps [rcx], xmm1
0000713aae5dbef1  mov rax, 0x5E9381C89A50
0000713aae5dbefb  call rax
0000713aae5dbefd  movaps xmm6, [rsp]
0000713aae5dbf01  add rsp, 0x40
0000713aae5dbf05  vmovaps xmm0, [rsp]
0000713aae5dbf0a  vmovaps xmm1, [rsp+0x10]
0000713aae5dbf10  vmovaps xmm2, [rsp+0x20]
0000713aae5dbf16  vmovaps xmm3, [rsp+0x30]
0000713aae5dbf1c  vmovaps xmm4, [rsp+0x40]
0000713aae5dbf22  vmovaps xmm5, [rsp+0x50]
0000713aae5dbf28  vmovaps xmm7, [rsp+0x60]
0000713aae5dbf2e  vmovaps xmm8, [rsp+0x70]
0000713aae5dbf34  vmovaps xmm9, [rsp+0x80]
0000713aae5dbf3d  vmovaps xmm10, [rsp+0x90]
0000713aae5dbf46  vmovaps xmm11, [rsp+0xA0]
0000713aae5dbf4f  vmovaps xmm12, [rsp+0xB0]
0000713aae5dbf58  vmovaps xmm13, [rsp+0xC0]
0000713aae5dbf61  vmovaps xmm14, [rsp+0xD0]
0000713aae5dbf6a  vmovaps xmm15, [rsp+0xE0]
0000713aae5dbf73  add rsp, 0xF0
0000713aae5dbf7a  pop r11
0000713aae5dbf7c  pop r10
0000713aae5dbf7e  pop r9
0000713aae5dbf80  pop r8
0000713aae5dbf82  pop rsi
0000713aae5dbf83  pop rdi
0000713aae5dbf84  pop rdx
0000713aae5dbf85  pop rcx
0000713aae5dbf86  pop rax
0000713aae5dbf87  add rsp, 0x08
0000713aae5dbf8b  jmp 0x0000713AAE5DA381
0000713aae5dbf90  sub rsp, 0x08
0000713aae5dbf94  push rax
0000713aae5dbf95  push rcx
0000713aae5dbf96  push rdx
0000713aae5dbf97  push rdi
0000713aae5dbf98  push rsi
0000713aae5dbf99  push r8
0000713aae5dbf9b  push r9
0000713aae5dbf9d  push r10
0000713aae5dbf9f  push r11
0000713aae5dbfa1  sub rsp, 0xF0
0000713aae5dbfa8  vmovaps [rsp], xmm0
0000713aae5dbfad  vmovaps [rsp+0x10], xmm1
0000713aae5dbfb3  vmovaps [rsp+0x20], xmm2
0000713aae5dbfb9  vmovaps [rsp+0x30], xmm3
0000713aae5dbfbf  vmovaps [rsp+0x40], xmm4
0000713aae5dbfc5  vmovaps [rsp+0x50], xmm5
0000713aae5dbfcb  vmovaps [rsp+0x60], xmm6
0000713aae5dbfd1  vmovaps [rsp+0x70], xmm7
0000713aae5dbfd7  vmovaps [rsp+0x80], xmm8
0000713aae5dbfe0  vmovaps [rsp+0x90], xmm9
0000713aae5dbfe9  vmovaps [rsp+0xA0], xmm11
0000713aae5dbff2  vmovaps [rsp+0xB0], xmm12
0000713aae5dbffb  vmovaps [rsp+0xC0], xmm13
0000713aae5dc004  vmovaps [rsp+0xD0], xmm14
0000713aae5dc00d  vmovaps [rsp+0xE0], xmm15
0000713aae5dc016  sub rsp, 0x40
0000713aae5dc01a  lea rdi, [rsp]
0000713aae5dc01e  lea rsi, [rsp+0x10]
0000713aae5dc023  lea rdx, [rsp+0x20]
0000713aae5dc028  lea rcx, [rsp+0x30]
0000713aae5dc02d  mov r8d, 0x00
0000713aae5dc033  lea r9, [r15+0x3A8]
0000713aae5dc03a  movaps [rdi], xmm10
0000713aae5dc03e  movaps [rsi], xmm5
0000713aae5dc041  movaps [rdx], xmm12
0000713aae5dc045  movaps [rcx], xmm1
0000713aae5dc048  mov rax, 0x5E9381C89A50
0000713aae5dc052  call rax
0000713aae5dc054  movaps xmm10, [rsp]
0000713aae5dc059  add rsp, 0x40
0000713aae5dc05d  vmovaps xmm0, [rsp]
0000713aae5dc062  vmovaps xmm1, [rsp+0x10]
0000713aae5dc068  vmovaps xmm2, [rsp+0x20]
0000713aae5dc06e  vmovaps xmm3, [rsp+0x30]
0000713aae5dc074  vmovaps xmm4, [rsp+0x40]
0000713aae5dc07a  vmovaps xmm5, [rsp+0x50]
0000713aae5dc080  vmovaps xmm6, [rsp+0x60]
0000713aae5dc086  vmovaps xmm7, [rsp+0x70]
0000713aae5dc08c  vmovaps xmm8, [rsp+0x80]
0000713aae5dc095  vmovaps xmm9, [rsp+0x90]
0000713aae5dc09e  vmovaps xmm11, [rsp+0xA0]
0000713aae5dc0a7  vmovaps xmm12, [rsp+0xB0]
0000713aae5dc0b0  vmovaps xmm13, [rsp+0xC0]
0000713aae5dc0b9  vmovaps xmm14, [rsp+0xD0]
0000713aae5dc0c2  vmovaps xmm15, [rsp+0xE0]
0000713aae5dc0cb  add rsp, 0xF0
0000713aae5dc0d2  pop r11
0000713aae5dc0d4  pop r10
0000713aae5dc0d6  pop r9
0000713aae5dc0d8  pop r8
0000713aae5dc0da  pop rsi
0000713aae5dc0db  pop rdi
0000713aae5dc0dc  pop rdx
0000713aae5dc0dd  pop rcx
0000713aae5dc0de  pop rax
0000713aae5dc0df  add rsp, 0x08
0000713aae5dc0e3  jmp 0x0000713AAE5DA3B0
0000713aae5dc0e8  sub rsp, 0x08
0000713aae5dc0ec  push rax
0000713aae5dc0ed  push rcx
0000713aae5dc0ee  push rdx
0000713aae5dc0ef  push rdi
0000713aae5dc0f0  push rsi
0000713aae5dc0f1  push r8
0000713aae5dc0f3  push r9
0000713aae5dc0f5  push r10
0000713aae5dc0f7  push r11
0000713aae5dc0f9  sub rsp, 0xF0
0000713aae5dc100  vmovaps [rsp], xmm0
0000713aae5dc105  vmovaps [rsp+0x10], xmm1
0000713aae5dc10b  vmovaps [rsp+0x20], xmm2
0000713aae5dc111  vmovaps [rsp+0x30], xmm3
0000713aae5dc117  vmovaps [rsp+0x40], xmm4
0000713aae5dc11d  vmovaps [rsp+0x50], xmm5
0000713aae5dc123  vmovaps [rsp+0x60], xmm6
0000713aae5dc129  vmovaps [rsp+0x70], xmm7
0000713aae5dc12f  vmovaps [rsp+0x80], xmm8
0000713aae5dc138  vmovaps [rsp+0x90], xmm9
0000713aae5dc141  vmovaps [rsp+0xA0], xmm10
0000713aae5dc14a  vmovaps [rsp+0xB0], xmm11
0000713aae5dc153  vmovaps [rsp+0xC0], xmm13
0000713aae5dc15c  vmovaps [rsp+0xD0], xmm14
0000713aae5dc165  vmovaps [rsp+0xE0], xmm15
0000713aae5dc16e  sub rsp, 0x40
0000713aae5dc172  lea rdi, [rsp]
0000713aae5dc176  lea rsi, [rsp+0x10]
0000713aae5dc17b  lea rdx, [rsp+0x20]
0000713aae5dc180  lea rcx, [rsp+0x30]
0000713aae5dc185  mov r8d, 0x00
0000713aae5dc18b  lea r9, [r15+0x3A8]
0000713aae5dc192  movaps [rdi], xmm12
0000713aae5dc196  movaps [rsi], xmm7
0000713aae5dc199  movaps [rdx], xmm15
0000713aae5dc19d  movaps [rcx], xmm1
0000713aae5dc1a0  mov rax, 0x5E9381C89A50
0000713aae5dc1aa  call rax
0000713aae5dc1ac  movaps xmm12, [rsp]
0000713aae5dc1b1  add rsp, 0x40
0000713aae5dc1b5  vmovaps xmm0, [rsp]
0000713aae5dc1ba  vmovaps xmm1, [rsp+0x10]
0000713aae5dc1c0  vmovaps xmm2, [rsp+0x20]
0000713aae5dc1c6  vmovaps xmm3, [rsp+0x30]
0000713aae5dc1cc  vmovaps xmm4, [rsp+0x40]
0000713aae5dc1d2  vmovaps xmm5, [rsp+0x50]
0000713aae5dc1d8  vmovaps xmm6, [rsp+0x60]
0000713aae5dc1de  vmovaps xmm7, [rsp+0x70]
0000713aae5dc1e4  vmovaps xmm8, [rsp+0x80]
0000713aae5dc1ed  vmovaps xmm9, [rsp+0x90]
0000713aae5dc1f6  vmovaps xmm10, [rsp+0xA0]
0000713aae5dc1ff  vmovaps xmm11, [rsp+0xB0]
0000713aae5dc208  vmovaps xmm13, [rsp+0xC0]
0000713aae5dc211  vmovaps xmm14, [rsp+0xD0]
0000713aae5dc21a  vmovaps xmm15, [rsp+0xE0]
0000713aae5dc223  add rsp, 0xF0
0000713aae5dc22a  pop r11
0000713aae5dc22c  pop r10
0000713aae5dc22e  pop r9
0000713aae5dc230  pop r8
0000713aae5dc232  pop rsi
0000713aae5dc233  pop rdi
0000713aae5dc234  pop rdx
0000713aae5dc235  pop rcx
0000713aae5dc236  pop rax
0000713aae5dc237  add rsp, 0x08
0000713aae5dc23b  jmp 0x0000713AAE5DA3D9
0000713aae5dc240  call 0x0000713AAE3FF430
0000713aae5dc245  jmp 0x0000713AAE5DA3E3
0000713aae5dc24a  call 0x0000713AAE40E760
0000713aae5dc24f  jmp 0x0000713AAE5DA3ED
0000713aae5dc254  sub rsp, 0x08
0000713aae5dc258  push rax
0000713aae5dc259  push rcx
0000713aae5dc25a  push rdx
0000713aae5dc25b  push rdi
0000713aae5dc25c  push rsi
0000713aae5dc25d  push r8
0000713aae5dc25f  push r9
0000713aae5dc261  push r10
0000713aae5dc263  push r11
0000713aae5dc265  sub rsp, 0xF0
0000713aae5dc26c  vmovaps [rsp], xmm0
0000713aae5dc271  vmovaps [rsp+0x10], xmm1
0000713aae5dc277  vmovaps [rsp+0x20], xmm2
0000713aae5dc27d  vmovaps [rsp+0x30], xmm3
0000713aae5dc283  vmovaps [rsp+0x40], xmm4
0000713aae5dc289  vmovaps [rsp+0x50], xmm5
0000713aae5dc28f  vmovaps [rsp+0x60], xmm6
0000713aae5dc295  vmovaps [rsp+0x70], xmm8
0000713aae5dc29b  vmovaps [rsp+0x80], xmm9
0000713aae5dc2a4  vmovaps [rsp+0x90], xmm10
0000713aae5dc2ad  vmovaps [rsp+0xA0], xmm11
0000713aae5dc2b6  vmovaps [rsp+0xB0], xmm12
0000713aae5dc2bf  vmovaps [rsp+0xC0], xmm13
0000713aae5dc2c8  vmovaps [rsp+0xD0], xmm14
0000713aae5dc2d1  vmovaps [rsp+0xE0], xmm15
0000713aae5dc2da  sub rsp, 0x40
0000713aae5dc2de  lea rdi, [rsp]
0000713aae5dc2e2  lea rsi, [rsp+0x10]
0000713aae5dc2e7  lea rdx, [rsp+0x20]
0000713aae5dc2ec  lea rcx, [rsp+0x30]
0000713aae5dc2f1  mov r8d, 0x00
0000713aae5dc2f7  lea r9, [r15+0x3A8]
0000713aae5dc2fe  movaps [rdi], xmm7
0000713aae5dc301  movaps [rsi], xmm2
0000713aae5dc304  movaps [rdx], xmm9
0000713aae5dc308  movaps [rcx], xmm11
0000713aae5dc30c  mov rax, 0x5E9381C89A50
0000713aae5dc316  call rax
0000713aae5dc318  movaps xmm7, [rsp]
0000713aae5dc31c  add rsp, 0x40
0000713aae5dc320  vmovaps xmm0, [rsp]
0000713aae5dc325  vmovaps xmm1, [rsp+0x10]
0000713aae5dc32b  vmovaps xmm2, [rsp+0x20]
0000713aae5dc331  vmovaps xmm3, [rsp+0x30]
0000713aae5dc337  vmovaps xmm4, [rsp+0x40]
0000713aae5dc33d  vmovaps xmm5, [rsp+0x50]
0000713aae5dc343  vmovaps xmm6, [rsp+0x60]
0000713aae5dc349  vmovaps xmm8, [rsp+0x70]
0000713aae5dc34f  vmovaps xmm9, [rsp+0x80]
0000713aae5dc358  vmovaps xmm10, [rsp+0x90]
0000713aae5dc361  vmovaps xmm11, [rsp+0xA0]
0000713aae5dc36a  vmovaps xmm12, [rsp+0xB0]
0000713aae5dc373  vmovaps xmm13, [rsp+0xC0]
0000713aae5dc37c  vmovaps xmm14, [rsp+0xD0]
0000713aae5dc385  vmovaps xmm15, [rsp+0xE0]
0000713aae5dc38e  add rsp, 0xF0
0000713aae5dc395  pop r11
0000713aae5dc397  pop r10
0000713aae5dc399  pop r9
0000713aae5dc39b  pop r8
0000713aae5dc39d  pop rsi
0000713aae5dc39e  pop rdi
0000713aae5dc39f  pop rdx
0000713aae5dc3a0  pop rcx
0000713aae5dc3a1  pop rax
0000713aae5dc3a2  add rsp, 0x08
0000713aae5dc3a6  jmp 0x0000713AAE5DA421
0000713aae5dc3ab  sub rsp, 0x08
0000713aae5dc3af  push rax
0000713aae5dc3b0  push rcx
0000713aae5dc3b1  push rdx
0000713aae5dc3b2  push rdi
0000713aae5dc3b3  push rsi
0000713aae5dc3b4  push r8
0000713aae5dc3b6  push r9
0000713aae5dc3b8  push r10
0000713aae5dc3ba  push r11
0000713aae5dc3bc  sub rsp, 0xF0
0000713aae5dc3c3  vmovaps [rsp], xmm0
0000713aae5dc3c8  vmovaps [rsp+0x10], xmm1
0000713aae5dc3ce  vmovaps [rsp+0x20], xmm2
0000713aae5dc3d4  vmovaps [rsp+0x30], xmm3
0000713aae5dc3da  vmovaps [rsp+0x40], xmm4
0000713aae5dc3e0  vmovaps [rsp+0x50], xmm5
0000713aae5dc3e6  vmovaps [rsp+0x60], xmm6
0000713aae5dc3ec  vmovaps [rsp+0x70], xmm7
0000713aae5dc3f2  vmovaps [rsp+0x80], xmm8
0000713aae5dc3fb  vmovaps [rsp+0x90], xmm10
0000713aae5dc404  vmovaps [rsp+0xA0], xmm11
0000713aae5dc40d  vmovaps [rsp+0xB0], xmm12
0000713aae5dc416  vmovaps [rsp+0xC0], xmm13
0000713aae5dc41f  vmovaps [rsp+0xD0], xmm14
0000713aae5dc428  vmovaps [rsp+0xE0], xmm15
0000713aae5dc431  sub rsp, 0x40
0000713aae5dc435  lea rdi, [rsp]
0000713aae5dc439  lea rsi, [rsp+0x10]
0000713aae5dc43e  lea rdx, [rsp+0x20]
0000713aae5dc443  lea rcx, [rsp+0x30]
0000713aae5dc448  mov r8d, 0x00
0000713aae5dc44e  lea r9, [r15+0x3A8]
0000713aae5dc455  movaps [rdi], xmm9
0000713aae5dc459  movaps [rsi], xmm6
0000713aae5dc45c  movaps [rdx], xmm1
0000713aae5dc45f  movaps [rcx], xmm11
0000713aae5dc463  mov rax, 0x5E9381C89A50
0000713aae5dc46d  call rax
0000713aae5dc46f  movaps xmm9, [rsp]
0000713aae5dc474  add rsp, 0x40
0000713aae5dc478  vmovaps xmm0, [rsp]
0000713aae5dc47d  vmovaps xmm1, [rsp+0x10]
0000713aae5dc483  vmovaps xmm2, [rsp+0x20]
0000713aae5dc489  vmovaps xmm3, [rsp+0x30]
0000713aae5dc48f  vmovaps xmm4, [rsp+0x40]
0000713aae5dc495  vmovaps xmm5, [rsp+0x50]
0000713aae5dc49b  vmovaps xmm6, [rsp+0x60]
0000713aae5dc4a1  vmovaps xmm7, [rsp+0x70]
0000713aae5dc4a7  vmovaps xmm8, [rsp+0x80]
0000713aae5dc4b0  vmovaps xmm10, [rsp+0x90]
0000713aae5dc4b9  vmovaps xmm11, [rsp+0xA0]
0000713aae5dc4c2  vmovaps xmm12, [rsp+0xB0]
0000713aae5dc4cb  vmovaps xmm13, [rsp+0xC0]
0000713aae5dc4d4  vmovaps xmm14, [rsp+0xD0]
0000713aae5dc4dd  vmovaps xmm15, [rsp+0xE0]
0000713aae5dc4e6  add rsp, 0xF0
0000713aae5dc4ed  pop r11
0000713aae5dc4ef  pop r10
0000713aae5dc4f1  pop r9
0000713aae5dc4f3  pop r8
0000713aae5dc4f5  pop rsi
0000713aae5dc4f6  pop rdi
0000713aae5dc4f7  pop rdx
0000713aae5dc4f8  pop rcx
0000713aae5dc4f9  pop rax
0000713aae5dc4fa  add rsp, 0x08
0000713aae5dc4fe  jmp 0x0000713AAE5DA447
0000713aae5dc503  sub rsp, 0x08
0000713aae5dc507  push rax
0000713aae5dc508  push rcx
0000713aae5dc509  push rdx
0000713aae5dc50a  push rdi
0000713aae5dc50b  push rsi
0000713aae5dc50c  push r8
0000713aae5dc50e  push r9
0000713aae5dc510  push r10
0000713aae5dc512  push r11
0000713aae5dc514  sub rsp, 0xF0
0000713aae5dc51b  vmovaps [rsp], xmm0
0000713aae5dc520  vmovaps [rsp+0x10], xmm1
0000713aae5dc526  vmovaps [rsp+0x20], xmm2
0000713aae5dc52c  vmovaps [rsp+0x30], xmm3
0000713aae5dc532  vmovaps [rsp+0x40], xmm4
0000713aae5dc538  vmovaps [rsp+0x50], xmm5
0000713aae5dc53e  vmovaps [rsp+0x60], xmm6
0000713aae5dc544  vmovaps [rsp+0x70], xmm7
0000713aae5dc54a  vmovaps [rsp+0x80], xmm8
0000713aae5dc553  vmovaps [rsp+0x90], xmm9
0000713aae5dc55c  vmovaps [rsp+0xA0], xmm10
0000713aae5dc565  vmovaps [rsp+0xB0], xmm12
0000713aae5dc56e  vmovaps [rsp+0xC0], xmm13
0000713aae5dc577  vmovaps [rsp+0xD0], xmm14
0000713aae5dc580  vmovaps [rsp+0xE0], xmm15
0000713aae5dc589  sub rsp, 0x40
0000713aae5dc58d  lea rdi, [rsp]
0000713aae5dc591  lea rsi, [rsp+0x10]
0000713aae5dc596  lea rdx, [rsp+0x20]
0000713aae5dc59b  lea rcx, [rsp+0x30]
0000713aae5dc5a0  mov r8d, 0x00
0000713aae5dc5a6  lea r9, [r15+0x3A8]
0000713aae5dc5ad  movaps [rdi], xmm11
0000713aae5dc5b1  movaps [rsi], xmm10
0000713aae5dc5b5  movaps [rdx], xmm8
0000713aae5dc5b9  movaps [rcx], xmm1
0000713aae5dc5bc  mov rax, 0x5E9381C89A50
0000713aae5dc5c6  call rax
0000713aae5dc5c8  movaps xmm11, [rsp]
0000713aae5dc5cd  add rsp, 0x40
0000713aae5dc5d1  vmovaps xmm0, [rsp]
0000713aae5dc5d6  vmovaps xmm1, [rsp+0x10]
0000713aae5dc5dc  vmovaps xmm2, [rsp+0x20]
0000713aae5dc5e2  vmovaps xmm3, [rsp+0x30]
0000713aae5dc5e8  vmovaps xmm4, [rsp+0x40]
0000713aae5dc5ee  vmovaps xmm5, [rsp+0x50]
0000713aae5dc5f4  vmovaps xmm6, [rsp+0x60]
0000713aae5dc5fa  vmovaps xmm7, [rsp+0x70]
0000713aae5dc600  vmovaps xmm8, [rsp+0x80]
0000713aae5dc609  vmovaps xmm9, [rsp+0x90]
0000713aae5dc612  vmovaps xmm10, [rsp+0xA0]
0000713aae5dc61b  vmovaps xmm12, [rsp+0xB0]
0000713aae5dc624  vmovaps xmm13, [rsp+0xC0]
0000713aae5dc62d  vmovaps xmm14, [rsp+0xD0]
0000713aae5dc636  vmovaps xmm15, [rsp+0xE0]
0000713aae5dc63f  add rsp, 0xF0
0000713aae5dc646  pop r11
0000713aae5dc648  pop r10
0000713aae5dc64a  pop r9
0000713aae5dc64c  pop r8
0000713aae5dc64e  pop rsi
0000713aae5dc64f  pop rdi
0000713aae5dc650  pop rdx
0000713aae5dc651  pop rcx
0000713aae5dc652  pop rax
0000713aae5dc653  add rsp, 0x08
0000713aae5dc657  jmp 0x0000713AAE5DA46D
0000713aae5dc65c  sub rsp, 0x08
0000713aae5dc660  push rax
0000713aae5dc661  push rcx
0000713aae5dc662  push rdx
0000713aae5dc663  push rdi
0000713aae5dc664  push rsi
0000713aae5dc665  push r8
0000713aae5dc667  push r9
0000713aae5dc669  push r10
0000713aae5dc66b  push r11
0000713aae5dc66d  sub rsp, 0xF0
0000713aae5dc674  vmovaps [rsp], xmm0
0000713aae5dc679  vmovaps [rsp+0x10], xmm1
0000713aae5dc67f  vmovaps [rsp+0x20], xmm2
0000713aae5dc685  vmovaps [rsp+0x30], xmm3
0000713aae5dc68b  vmovaps [rsp+0x40], xmm4
0000713aae5dc691  vmovaps [rsp+0x50], xmm5
0000713aae5dc697  vmovaps [rsp+0x60], xmm6
0000713aae5dc69d  vmovaps [rsp+0x70], xmm7
0000713aae5dc6a3  vmovaps [rsp+0x80], xmm8
0000713aae5dc6ac  vmovaps [rsp+0x90], xmm9
0000713aae5dc6b5  vmovaps [rsp+0xA0], xmm11
0000713aae5dc6be  vmovaps [rsp+0xB0], xmm12
0000713aae5dc6c7  vmovaps [rsp+0xC0], xmm13
0000713aae5dc6d0  vmovaps [rsp+0xD0], xmm14
0000713aae5dc6d9  vmovaps [rsp+0xE0], xmm15
0000713aae5dc6e2  sub rsp, 0x40
0000713aae5dc6e6  lea rdi, [rsp]
0000713aae5dc6ea  lea rsi, [rsp+0x10]
0000713aae5dc6ef  lea rdx, [rsp+0x20]
0000713aae5dc6f4  lea rcx, [rsp+0x30]
0000713aae5dc6f9  mov r8d, 0x00
0000713aae5dc6ff  lea r9, [r15+0x3A8]
0000713aae5dc706  movaps [rdi], xmm10
0000713aae5dc70a  movaps [rsi], xmm12
0000713aae5dc70e  movaps [rdx], xmm13
0000713aae5dc712  movaps [rcx], xmm1
0000713aae5dc715  mov rax, 0x5E9381C89A50
0000713aae5dc71f  call rax
0000713aae5dc721  movaps xmm10, [rsp]
0000713aae5dc726  add rsp, 0x40
0000713aae5dc72a  vmovaps xmm0, [rsp]
0000713aae5dc72f  vmovaps xmm1, [rsp+0x10]
0000713aae5dc735  vmovaps xmm2, [rsp+0x20]
0000713aae5dc73b  vmovaps xmm3, [rsp+0x30]
0000713aae5dc741  vmovaps xmm4, [rsp+0x40]
0000713aae5dc747  vmovaps xmm5, [rsp+0x50]
0000713aae5dc74d  vmovaps xmm6, [rsp+0x60]
0000713aae5dc753  vmovaps xmm7, [rsp+0x70]
0000713aae5dc759  vmovaps xmm8, [rsp+0x80]
0000713aae5dc762  vmovaps xmm9, [rsp+0x90]
0000713aae5dc76b  vmovaps xmm11, [rsp+0xA0]
0000713aae5dc774  vmovaps xmm12, [rsp+0xB0]
0000713aae5dc77d  vmovaps xmm13, [rsp+0xC0]
0000713aae5dc786  vmovaps xmm14, [rsp+0xD0]
0000713aae5dc78f  vmovaps xmm15, [rsp+0xE0]
0000713aae5dc798  add rsp, 0xF0
0000713aae5dc79f  pop r11
0000713aae5dc7a1  pop r10
0000713aae5dc7a3  pop r9
0000713aae5dc7a5  pop r8
0000713aae5dc7a7  pop rsi
0000713aae5dc7a8  pop rdi
0000713aae5dc7a9  pop rdx
0000713aae5dc7aa  pop rcx
0000713aae5dc7ab  pop rax
0000713aae5dc7ac  add rsp, 0x08
0000713aae5dc7b0  jmp 0x0000713AAE5DA493
0000713aae5dc7b5  call 0x0000713AAE3FF430
0000713aae5dc7ba  jmp 0x0000713AAE5DA49D
0000713aae5dc7bf  call 0x0000713AAE40C260
0000713aae5dc7c4  jmp 0x0000713AAE5DA4A7
0000713aae5dc7c9  sub rsp, 0x08
0000713aae5dc7cd  push rax
0000713aae5dc7ce  push rcx
0000713aae5dc7cf  push rdx
0000713aae5dc7d0  push rdi
0000713aae5dc7d1  push rsi
0000713aae5dc7d2  push r8
0000713aae5dc7d4  push r9
0000713aae5dc7d6  push r10
0000713aae5dc7d8  push r11
0000713aae5dc7da  sub rsp, 0xF0
0000713aae5dc7e1  vmovaps [rsp], xmm0
0000713aae5dc7e6  vmovaps [rsp+0x10], xmm1
0000713aae5dc7ec  vmovaps [rsp+0x20], xmm2
0000713aae5dc7f2  vmovaps [rsp+0x30], xmm3
0000713aae5dc7f8  vmovaps [rsp+0x40], xmm4
0000713aae5dc7fe  vmovaps [rsp+0x50], xmm5
0000713aae5dc804  vmovaps [rsp+0x60], xmm6
0000713aae5dc80a  vmovaps [rsp+0x70], xmm7
0000713aae5dc810  vmovaps [rsp+0x80], xmm9
0000713aae5dc819  vmovaps [rsp+0x90], xmm10
0000713aae5dc822  vmovaps [rsp+0xA0], xmm11
0000713aae5dc82b  vmovaps [rsp+0xB0], xmm12
0000713aae5dc834  vmovaps [rsp+0xC0], xmm13
0000713aae5dc83d  vmovaps [rsp+0xD0], xmm14
0000713aae5dc846  vmovaps [rsp+0xE0], xmm15
0000713aae5dc84f  sub rsp, 0x40
0000713aae5dc853  lea rdi, [rsp]
0000713aae5dc857  lea rsi, [rsp+0x10]
0000713aae5dc85c  lea rdx, [rsp+0x20]
0000713aae5dc861  lea rcx, [rsp+0x30]
0000713aae5dc866  mov r8d, 0x00
0000713aae5dc86c  lea r9, [r15+0x3A8]
0000713aae5dc873  movaps [rdi], xmm8
0000713aae5dc877  movaps [rsi], xmm7
0000713aae5dc87a  movaps [rdx], xmm4
0000713aae5dc87d  movaps [rcx], xmm12
0000713aae5dc881  mov rax, 0x5E9381C89A50
0000713aae5dc88b  call rax
0000713aae5dc88d  movaps xmm8, [rsp]
0000713aae5dc892  add rsp, 0x40
0000713aae5dc896  vmovaps xmm0, [rsp]
0000713aae5dc89b  vmovaps xmm1, [rsp+0x10]
0000713aae5dc8a1  vmovaps xmm2, [rsp+0x20]
0000713aae5dc8a7  vmovaps xmm3, [rsp+0x30]
0000713aae5dc8ad  vmovaps xmm4, [rsp+0x40]
0000713aae5dc8b3  vmovaps xmm5, [rsp+0x50]
0000713aae5dc8b9  vmovaps xmm6, [rsp+0x60]
0000713aae5dc8bf  vmovaps xmm7, [rsp+0x70]
0000713aae5dc8c5  vmovaps xmm9, [rsp+0x80]
0000713aae5dc8ce  vmovaps xmm10, [rsp+0x90]
0000713aae5dc8d7  vmovaps xmm11, [rsp+0xA0]
0000713aae5dc8e0  vmovaps xmm12, [rsp+0xB0]
0000713aae5dc8e9  vmovaps xmm13, [rsp+0xC0]
0000713aae5dc8f2  vmovaps xmm14, [rsp+0xD0]
0000713aae5dc8fb  vmovaps xmm15, [rsp+0xE0]
0000713aae5dc904  add rsp, 0xF0
0000713aae5dc90b  pop r11
0000713aae5dc90d  pop r10
0000713aae5dc90f  pop r9
0000713aae5dc911  pop r8
0000713aae5dc913  pop rsi
0000713aae5dc914  pop rdi
0000713aae5dc915  pop rdx
0000713aae5dc916  pop rcx
0000713aae5dc917  pop rax
0000713aae5dc918  add rsp, 0x08
0000713aae5dc91c  jmp 0x0000713AAE5DA4D0
0000713aae5dc921  sub rsp, 0x08
0000713aae5dc925  push rax
0000713aae5dc926  push rcx
0000713aae5dc927  push rdx
0000713aae5dc928  push rdi
0000713aae5dc929  push rsi
0000713aae5dc92a  push r8
0000713aae5dc92c  push r9
0000713aae5dc92e  push r10
0000713aae5dc930  push r11
0000713aae5dc932  sub rsp, 0xF0
0000713aae5dc939  vmovaps [rsp], xmm0
0000713aae5dc93e  vmovaps [rsp+0x10], xmm1
0000713aae5dc944  vmovaps [rsp+0x20], xmm2
0000713aae5dc94a  vmovaps [rsp+0x30], xmm3
0000713aae5dc950  vmovaps [rsp+0x40], xmm4
0000713aae5dc956  vmovaps [rsp+0x50], xmm5
0000713aae5dc95c  vmovaps [rsp+0x60], xmm6
0000713aae5dc962  vmovaps [rsp+0x70], xmm8
0000713aae5dc968  vmovaps [rsp+0x80], xmm9
0000713aae5dc971  vmovaps [rsp+0x90], xmm10
0000713aae5dc97a  vmovaps [rsp+0xA0], xmm11
0000713aae5dc983  vmovaps [rsp+0xB0], xmm12
0000713aae5dc98c  vmovaps [rsp+0xC0], xmm13
0000713aae5dc995  vmovaps [rsp+0xD0], xmm14
0000713aae5dc99e  vmovaps [rsp+0xE0], xmm15
0000713aae5dc9a7  sub rsp, 0x40
0000713aae5dc9ab  lea rdi, [rsp]
0000713aae5dc9af  lea rsi, [rsp+0x10]
0000713aae5dc9b4  lea rdx, [rsp+0x20]
0000713aae5dc9b9  lea rcx, [rsp+0x30]
0000713aae5dc9be  mov r8d, 0x00
0000713aae5dc9c4  lea r9, [r15+0x3A8]
0000713aae5dc9cb  movaps [rdi], xmm7
0000713aae5dc9ce  movaps [rsi], xmm9
0000713aae5dc9d2  movaps [rdx], xmm14
0000713aae5dc9d6  movaps [rcx], xmm12
0000713aae5dc9da  mov rax, 0x5E9381C89A50
0000713aae5dc9e4  call rax
0000713aae5dc9e6  movaps xmm7, [rsp]
0000713aae5dc9ea  add rsp, 0x40
0000713aae5dc9ee  vmovaps xmm0, [rsp]
0000713aae5dc9f3  vmovaps xmm1, [rsp+0x10]
0000713aae5dc9f9  vmovaps xmm2, [rsp+0x20]
0000713aae5dc9ff  vmovaps xmm3, [rsp+0x30]
0000713aae5dca05  vmovaps xmm4, [rsp+0x40]
0000713aae5dca0b  vmovaps xmm5, [rsp+0x50]
0000713aae5dca11  vmovaps xmm6, [rsp+0x60]
0000713aae5dca17  vmovaps xmm8, [rsp+0x70]
0000713aae5dca1d  vmovaps xmm9, [rsp+0x80]
0000713aae5dca26  vmovaps xmm10, [rsp+0x90]
0000713aae5dca2f  vmovaps xmm11, [rsp+0xA0]
0000713aae5dca38  vmovaps xmm12, [rsp+0xB0]
0000713aae5dca41  vmovaps xmm13, [rsp+0xC0]
0000713aae5dca4a  vmovaps xmm14, [rsp+0xD0]
0000713aae5dca53  vmovaps xmm15, [rsp+0xE0]
0000713aae5dca5c  add rsp, 0xF0
0000713aae5dca63  pop r11
0000713aae5dca65  pop r10
0000713aae5dca67  pop r9
0000713aae5dca69  pop r8
0000713aae5dca6b  pop rsi
0000713aae5dca6c  pop rdi
0000713aae5dca6d  pop rdx
0000713aae5dca6e  pop rcx
0000713aae5dca6f  pop rax
0000713aae5dca70  add rsp, 0x08
0000713aae5dca74  jmp 0x0000713AAE5DA4F8
0000713aae5dca79  sub rsp, 0x08
0000713aae5dca7d  push rax
0000713aae5dca7e  push rcx
0000713aae5dca7f  push rdx
0000713aae5dca80  push rdi
0000713aae5dca81  push rsi
0000713aae5dca82  push r8
0000713aae5dca84  push r9
0000713aae5dca86  push r10
0000713aae5dca88  push r11
0000713aae5dca8a  sub rsp, 0xF0
0000713aae5dca91  vmovaps [rsp], xmm0
0000713aae5dca96  vmovaps [rsp+0x10], xmm1
0000713aae5dca9c  vmovaps [rsp+0x20], xmm2
0000713aae5dcaa2  vmovaps [rsp+0x30], xmm3
0000713aae5dcaa8  vmovaps [rsp+0x40], xmm4
0000713aae5dcaae  vmovaps [rsp+0x50], xmm5
0000713aae5dcab4  vmovaps [rsp+0x60], xmm6
0000713aae5dcaba  vmovaps [rsp+0x70], xmm7
0000713aae5dcac0  vmovaps [rsp+0x80], xmm8
0000713aae5dcac9  vmovaps [rsp+0x90], xmm9
0000713aae5dcad2  vmovaps [rsp+0xA0], xmm10
0000713aae5dcadb  vmovaps [rsp+0xB0], xmm11
0000713aae5dcae4  vmovaps [rsp+0xC0], xmm13
0000713aae5dcaed  vmovaps [rsp+0xD0], xmm14
0000713aae5dcaf6  vmovaps [rsp+0xE0], xmm15
0000713aae5dcaff  sub rsp, 0x40
0000713aae5dcb03  lea rdi, [rsp]
0000713aae5dcb07  lea rsi, [rsp+0x10]
0000713aae5dcb0c  lea rdx, [rsp+0x20]
0000713aae5dcb11  lea rcx, [rsp+0x30]
0000713aae5dcb16  mov r8d, 0x00
0000713aae5dcb1c  lea r9, [r15+0x3A8]
0000713aae5dcb23  movaps [rdi], xmm12
0000713aae5dcb27  movaps [rsi], xmm11
0000713aae5dcb2b  movaps [rdx], xmm15
0000713aae5dcb2f  movaps [rcx], xmm14
0000713aae5dcb33  mov rax, 0x5E9381C89A50
0000713aae5dcb3d  call rax
0000713aae5dcb3f  movaps xmm12, [rsp]
0000713aae5dcb44  add rsp, 0x40
0000713aae5dcb48  vmovaps xmm0, [rsp]
0000713aae5dcb4d  vmovaps xmm1, [rsp+0x10]
0000713aae5dcb53  vmovaps xmm2, [rsp+0x20]
0000713aae5dcb59  vmovaps xmm3, [rsp+0x30]
0000713aae5dcb5f  vmovaps xmm4, [rsp+0x40]
0000713aae5dcb65  vmovaps xmm5, [rsp+0x50]
0000713aae5dcb6b  vmovaps xmm6, [rsp+0x60]
0000713aae5dcb71  vmovaps xmm7, [rsp+0x70]
0000713aae5dcb77  vmovaps xmm8, [rsp+0x80]
0000713aae5dcb80  vmovaps xmm9, [rsp+0x90]
0000713aae5dcb89  vmovaps xmm10, [rsp+0xA0]
0000713aae5dcb92  vmovaps xmm11, [rsp+0xB0]
0000713aae5dcb9b  vmovaps xmm13, [rsp+0xC0]
0000713aae5dcba4  vmovaps xmm14, [rsp+0xD0]
0000713aae5dcbad  vmovaps xmm15, [rsp+0xE0]
0000713aae5dcbb6  add rsp, 0xF0
0000713aae5dcbbd  pop r11
0000713aae5dcbbf  pop r10
0000713aae5dcbc1  pop r9
0000713aae5dcbc3  pop r8
0000713aae5dcbc5  pop rsi
0000713aae5dcbc6  pop rdi
0000713aae5dcbc7  pop rdx
0000713aae5dcbc8  pop rcx
0000713aae5dcbc9  pop rax
0000713aae5dcbca  add rsp, 0x08
0000713aae5dcbce  jmp 0x0000713AAE5DA521
0000713aae5dcbd3  sub rsp, 0x08
0000713aae5dcbd7  push rax
0000713aae5dcbd8  push rcx
0000713aae5dcbd9  push rdx
0000713aae5dcbda  push rdi
0000713aae5dcbdb  push rsi
0000713aae5dcbdc  push r8
0000713aae5dcbde  push r9
0000713aae5dcbe0  push r10
0000713aae5dcbe2  push r11
0000713aae5dcbe4  sub rsp, 0xF0
0000713aae5dcbeb  vmovaps [rsp], xmm0
0000713aae5dcbf0  vmovaps [rsp+0x10], xmm1
0000713aae5dcbf6  vmovaps [rsp+0x20], xmm2
0000713aae5dcbfc  vmovaps [rsp+0x30], xmm3
0000713aae5dcc02  vmovaps [rsp+0x40], xmm4
0000713aae5dcc08  vmovaps [rsp+0x50], xmm5
0000713aae5dcc0e  vmovaps [rsp+0x60], xmm6
0000713aae5dcc14  vmovaps [rsp+0x70], xmm7
0000713aae5dcc1a  vmovaps [rsp+0x80], xmm8
0000713aae5dcc23  vmovaps [rsp+0x90], xmm9
0000713aae5dcc2c  vmovaps [rsp+0xA0], xmm10
0000713aae5dcc35  vmovaps [rsp+0xB0], xmm12
0000713aae5dcc3e  vmovaps [rsp+0xC0], xmm13
0000713aae5dcc47  vmovaps [rsp+0xD0], xmm14
0000713aae5dcc50  vmovaps [rsp+0xE0], xmm15
0000713aae5dcc59  sub rsp, 0x40
0000713aae5dcc5d  lea rdi, [rsp]
0000713aae5dcc61  lea rsi, [rsp+0x10]
0000713aae5dcc66  lea rdx, [rsp+0x20]
0000713aae5dcc6b  lea rcx, [rsp+0x30]
0000713aae5dcc70  mov r8d, 0x00
0000713aae5dcc76  lea r9, [r15+0x3A8]
0000713aae5dcc7d  movaps [rdi], xmm11
0000713aae5dcc81  movaps [rsi], xmm10
0000713aae5dcc85  movaps [rdx], xmm13
0000713aae5dcc89  movaps [rcx], xmm15
0000713aae5dcc8d  mov rax, 0x5E9381C89A50
0000713aae5dcc97  call rax
0000713aae5dcc99  movaps xmm11, [rsp]
0000713aae5dcc9e  add rsp, 0x40
0000713aae5dcca2  vmovaps xmm0, [rsp]
0000713aae5dcca7  vmovaps xmm1, [rsp+0x10]
0000713aae5dccad  vmovaps xmm2, [rsp+0x20]
0000713aae5dccb3  vmovaps xmm3, [rsp+0x30]
0000713aae5dccb9  vmovaps xmm4, [rsp+0x40]
0000713aae5dccbf  vmovaps xmm5, [rsp+0x50]
0000713aae5dccc5  vmovaps xmm6, [rsp+0x60]
0000713aae5dcccb  vmovaps xmm7, [rsp+0x70]
0000713aae5dccd1  vmovaps xmm8, [rsp+0x80]
0000713aae5dccda  vmovaps xmm9, [rsp+0x90]
0000713aae5dcce3  vmovaps xmm10, [rsp+0xA0]
0000713aae5dccec  vmovaps xmm12, [rsp+0xB0]
0000713aae5dccf5  vmovaps xmm13, [rsp+0xC0]
0000713aae5dccfe  vmovaps xmm14, [rsp+0xD0]
0000713aae5dcd07  vmovaps xmm15, [rsp+0xE0]
0000713aae5dcd10  add rsp, 0xF0
0000713aae5dcd17  pop r11
0000713aae5dcd19  pop r10
0000713aae5dcd1b  pop r9
0000713aae5dcd1d  pop r8
0000713aae5dcd1f  pop rsi
0000713aae5dcd20  pop rdi
0000713aae5dcd21  pop rdx
0000713aae5dcd22  pop rcx
0000713aae5dcd23  pop rax
0000713aae5dcd24  add rsp, 0x08
0000713aae5dcd28  jmp 0x0000713AAE5DA54A
0000713aae5dcd2d  call 0x0000713AAE40E760
0000713aae5dcd32  jmp 0x0000713AAE5DA557
0000713aae5dcd37  call 0x0000713AAE40D4E0
0000713aae5dcd3c  jmp 0x0000713AAE5DA564
0000713aae5dcd41  sub rsp, 0x08
0000713aae5dcd45  push rax
0000713aae5dcd46  push rcx
0000713aae5dcd47  push rdx
0000713aae5dcd48  push rdi
0000713aae5dcd49  push rsi
0000713aae5dcd4a  push r8
0000713aae5dcd4c  push r9
0000713aae5dcd4e  push r10
0000713aae5dcd50  push r11
0000713aae5dcd52  sub rsp, 0xF0
0000713aae5dcd59  vmovaps [rsp], xmm0
0000713aae5dcd5e  vmovaps [rsp+0x10], xmm1
0000713aae5dcd64  vmovaps [rsp+0x20], xmm2
0000713aae5dcd6a  vmovaps [rsp+0x30], xmm3
0000713aae5dcd70  vmovaps [rsp+0x40], xmm4
0000713aae5dcd76  vmovaps [rsp+0x50], xmm5
0000713aae5dcd7c  vmovaps [rsp+0x60], xmm6
0000713aae5dcd82  vmovaps [rsp+0x70], xmm7
0000713aae5dcd88  vmovaps [rsp+0x80], xmm8
0000713aae5dcd91  vmovaps [rsp+0x90], xmm9
0000713aae5dcd9a  vmovaps [rsp+0xA0], xmm11
0000713aae5dcda3  vmovaps [rsp+0xB0], xmm12
0000713aae5dcdac  vmovaps [rsp+0xC0], xmm13
0000713aae5dcdb5  vmovaps [rsp+0xD0], xmm14
0000713aae5dcdbe  vmovaps [rsp+0xE0], xmm15
0000713aae5dcdc7  sub rsp, 0x40
0000713aae5dcdcb  lea rdi, [rsp]
0000713aae5dcdcf  lea rsi, [rsp+0x10]
0000713aae5dcdd4  lea rdx, [rsp+0x20]
0000713aae5dcdd9  lea rcx, [rsp+0x30]
0000713aae5dcdde  mov r8d, 0x00
0000713aae5dcde4  lea r9, [r15+0x3A8]
0000713aae5dcdeb  movaps [rdi], xmm10
0000713aae5dcdef  movaps [rsi], xmm8
0000713aae5dcdf3  movaps [rdx], xmm1
0000713aae5dcdf6  movaps [rcx], xmm13
0000713aae5dcdfa  mov rax, 0x5E9381C89A50
0000713aae5dce04  call rax
0000713aae5dce06  movaps xmm10, [rsp]
0000713aae5dce0b  add rsp, 0x40
0000713aae5dce0f  vmovaps xmm0, [rsp]
0000713aae5dce14  vmovaps xmm1, [rsp+0x10]
0000713aae5dce1a  vmovaps xmm2, [rsp+0x20]
0000713aae5dce20  vmovaps xmm3, [rsp+0x30]
0000713aae5dce26  vmovaps xmm4, [rsp+0x40]
0000713aae5dce2c  vmovaps xmm5, [rsp+0x50]
0000713aae5dce32  vmovaps xmm6, [rsp+0x60]
0000713aae5dce38  vmovaps xmm7, [rsp+0x70]
0000713aae5dce3e  vmovaps xmm8, [rsp+0x80]
0000713aae5dce47  vmovaps xmm9, [rsp+0x90]
0000713aae5dce50  vmovaps xmm11, [rsp+0xA0]
0000713aae5dce59  vmovaps xmm12, [rsp+0xB0]
0000713aae5dce62  vmovaps xmm13, [rsp+0xC0]
0000713aae5dce6b  vmovaps xmm14, [rsp+0xD0]
0000713aae5dce74  vmovaps xmm15, [rsp+0xE0]
0000713aae5dce7d  add rsp, 0xF0
0000713aae5dce84  pop r11
0000713aae5dce86  pop r10
0000713aae5dce88  pop r9
0000713aae5dce8a  pop r8
0000713aae5dce8c  pop rsi
0000713aae5dce8d  pop rdi
0000713aae5dce8e  pop rdx
0000713aae5dce8f  pop rcx
0000713aae5dce90  pop rax
0000713aae5dce91  add rsp, 0x08
0000713aae5dce95  jmp 0x0000713AAE5DA59A
0000713aae5dce9a  call 0x0000713AAE3FF430
0000713aae5dce9f  jmp 0x0000713AAE5DA5AC
0000713aae5dcea4  sub rsp, 0x08
0000713aae5dcea8  push rax
0000713aae5dcea9  push rcx
0000713aae5dceaa  push rdx
0000713aae5dceab  push rdi
0000713aae5dceac  push rsi
0000713aae5dcead  push r8
0000713aae5dceaf  push r9
0000713aae5dceb1  push r10
0000713aae5dceb3  push r11
0000713aae5dceb5  sub rsp, 0xF0
0000713aae5dcebc  vmovaps [rsp], xmm0
0000713aae5dcec1  vmovaps [rsp+0x10], xmm1
0000713aae5dcec7  vmovaps [rsp+0x20], xmm2
0000713aae5dcecd  vmovaps [rsp+0x30], xmm3
0000713aae5dced3  vmovaps [rsp+0x40], xmm4
0000713aae5dced9  vmovaps [rsp+0x50], xmm5
0000713aae5dcedf  vmovaps [rsp+0x60], xmm6
0000713aae5dcee5  vmovaps [rsp+0x70], xmm7
0000713aae5dceeb  vmovaps [rsp+0x80], xmm8
0000713aae5dcef4  vmovaps [rsp+0x90], xmm10
0000713aae5dcefd  vmovaps [rsp+0xA0], xmm11
0000713aae5dcf06  vmovaps [rsp+0xB0], xmm12
0000713aae5dcf0f  vmovaps [rsp+0xC0], xmm13
0000713aae5dcf18  vmovaps [rsp+0xD0], xmm14
0000713aae5dcf21  vmovaps [rsp+0xE0], xmm15
0000713aae5dcf2a  sub rsp, 0x40
0000713aae5dcf2e  lea rdi, [rsp]
0000713aae5dcf32  lea rsi, [rsp+0x10]
0000713aae5dcf37  lea rdx, [rsp+0x20]
0000713aae5dcf3c  lea rcx, [rsp+0x30]
0000713aae5dcf41  mov r8d, 0x00
0000713aae5dcf47  lea r9, [r15+0x3A8]
0000713aae5dcf4e  movaps [rdi], xmm9
0000713aae5dcf52  movaps [rsi], xmm7
0000713aae5dcf55  movaps [rdx], xmm14
0000713aae5dcf59  movaps [rcx], xmm13
0000713aae5dcf5d  mov rax, 0x5E9381C89A50
0000713aae5dcf67  call rax
0000713aae5dcf69  movaps xmm9, [rsp]
0000713aae5dcf6e  add rsp, 0x40
0000713aae5dcf72  vmovaps xmm0, [rsp]
0000713aae5dcf77  vmovaps xmm1, [rsp+0x10]
0000713aae5dcf7d  vmovaps xmm2, [rsp+0x20]
0000713aae5dcf83  vmovaps xmm3, [rsp+0x30]
0000713aae5dcf89  vmovaps xmm4, [rsp+0x40]
0000713aae5dcf8f  vmovaps xmm5, [rsp+0x50]
0000713aae5dcf95  vmovaps xmm6, [rsp+0x60]
0000713aae5dcf9b  vmovaps xmm7, [rsp+0x70]
0000713aae5dcfa1  vmovaps xmm8, [rsp+0x80]
0000713aae5dcfaa  vmovaps xmm10, [rsp+0x90]
0000713aae5dcfb3  vmovaps xmm11, [rsp+0xA0]
0000713aae5dcfbc  vmovaps xmm12, [rsp+0xB0]
0000713aae5dcfc5  vmovaps xmm13, [rsp+0xC0]
0000713aae5dcfce  vmovaps xmm14, [rsp+0xD0]
0000713aae5dcfd7  vmovaps xmm15, [rsp+0xE0]
0000713aae5dcfe0  add rsp, 0xF0
0000713aae5dcfe7  pop r11
0000713aae5dcfe9  pop r10
0000713aae5dcfeb  pop r9
0000713aae5dcfed  pop r8
0000713aae5dcfef  pop rsi
0000713aae5dcff0  pop rdi
0000713aae5dcff1  pop rdx
0000713aae5dcff2  pop rcx
0000713aae5dcff3  pop rax
0000713aae5dcff4  add rsp, 0x08
0000713aae5dcff8  jmp 0x0000713AAE5DA5DA
0000713aae5dcffd  sub rsp, 0x08
0000713aae5dd001  push rax
0000713aae5dd002  push rcx
0000713aae5dd003  push rdx
0000713aae5dd004  push rdi
0000713aae5dd005  push rsi
0000713aae5dd006  push r8
0000713aae5dd008  push r9
0000713aae5dd00a  push r10
0000713aae5dd00c  push r11
0000713aae5dd00e  sub rsp, 0xF0
0000713aae5dd015  vmovaps [rsp], xmm0
0000713aae5dd01a  vmovaps [rsp+0x10], xmm1
0000713aae5dd020  vmovaps [rsp+0x20], xmm2
0000713aae5dd026  vmovaps [rsp+0x30], xmm3
0000713aae5dd02c  vmovaps [rsp+0x40], xmm4
0000713aae5dd032  vmovaps [rsp+0x50], xmm5
0000713aae5dd038  vmovaps [rsp+0x60], xmm6
0000713aae5dd03e  vmovaps [rsp+0x70], xmm7
0000713aae5dd044  vmovaps [rsp+0x80], xmm8
0000713aae5dd04d  vmovaps [rsp+0x90], xmm9
0000713aae5dd056  vmovaps [rsp+0xA0], xmm10
0000713aae5dd05f  vmovaps [rsp+0xB0], xmm11
0000713aae5dd068  vmovaps [rsp+0xC0], xmm12
0000713aae5dd071  vmovaps [rsp+0xD0], xmm14
0000713aae5dd07a  vmovaps [rsp+0xE0], xmm15
0000713aae5dd083  sub rsp, 0x40
0000713aae5dd087  lea rdi, [rsp]
0000713aae5dd08b  lea rsi, [rsp+0x10]
0000713aae5dd090  lea rdx, [rsp+0x20]
0000713aae5dd095  lea rcx, [rsp+0x30]
0000713aae5dd09a  mov r8d, 0x00
0000713aae5dd0a0  lea r9, [r15+0x3A8]
0000713aae5dd0a7  movaps [rdi], xmm13
0000713aae5dd0ab  movaps [rsi], xmm12
0000713aae5dd0af  movaps [rdx], xmm15
0000713aae5dd0b3  movaps [rcx], xmm14
0000713aae5dd0b7  mov rax, 0x5E9381C89A50
0000713aae5dd0c1  call rax
0000713aae5dd0c3  movaps xmm13, [rsp]
0000713aae5dd0c8  add rsp, 0x40
0000713aae5dd0cc  vmovaps xmm0, [rsp]
0000713aae5dd0d1  vmovaps xmm1, [rsp+0x10]
0000713aae5dd0d7  vmovaps xmm2, [rsp+0x20]
0000713aae5dd0dd  vmovaps xmm3, [rsp+0x30]
0000713aae5dd0e3  vmovaps xmm4, [rsp+0x40]
0000713aae5dd0e9  vmovaps xmm5, [rsp+0x50]
0000713aae5dd0ef  vmovaps xmm6, [rsp+0x60]
0000713aae5dd0f5  vmovaps xmm7, [rsp+0x70]
0000713aae5dd0fb  vmovaps xmm8, [rsp+0x80]
0000713aae5dd104  vmovaps xmm9, [rsp+0x90]
0000713aae5dd10d  vmovaps xmm10, [rsp+0xA0]
0000713aae5dd116  vmovaps xmm11, [rsp+0xB0]
0000713aae5dd11f  vmovaps xmm12, [rsp+0xC0]
0000713aae5dd128  vmovaps xmm14, [rsp+0xD0]
0000713aae5dd131  vmovaps xmm15, [rsp+0xE0]
0000713aae5dd13a  add rsp, 0xF0
0000713aae5dd141  pop r11
0000713aae5dd143  pop r10
0000713aae5dd145  pop r9
0000713aae5dd147  pop r8
0000713aae5dd149  pop rsi
0000713aae5dd14a  pop rdi
0000713aae5dd14b  pop rdx
0000713aae5dd14c  pop rcx
0000713aae5dd14d  pop rax
0000713aae5dd14e  add rsp, 0x08
0000713aae5dd152  jmp 0x0000713AAE5DA608
0000713aae5dd157  sub rsp, 0x08
0000713aae5dd15b  push rax
0000713aae5dd15c  push rcx
0000713aae5dd15d  push rdx
0000713aae5dd15e  push rdi
0000713aae5dd15f  push rsi
0000713aae5dd160  push r8
0000713aae5dd162  push r9
0000713aae5dd164  push r10
0000713aae5dd166  push r11
0000713aae5dd168  sub rsp, 0xF0
0000713aae5dd16f  vmovaps [rsp], xmm0
0000713aae5dd174  vmovaps [rsp+0x10], xmm1
0000713aae5dd17a  vmovaps [rsp+0x20], xmm2
0000713aae5dd180  vmovaps [rsp+0x30], xmm3
0000713aae5dd186  vmovaps [rsp+0x40], xmm4
0000713aae5dd18c  vmovaps [rsp+0x50], xmm5
0000713aae5dd192  vmovaps [rsp+0x60], xmm6
0000713aae5dd198  vmovaps [rsp+0x70], xmm7
0000713aae5dd19e  vmovaps [rsp+0x80], xmm8
0000713aae5dd1a7  vmovaps [rsp+0x90], xmm9
0000713aae5dd1b0  vmovaps [rsp+0xA0], xmm10
0000713aae5dd1b9  vmovaps [rsp+0xB0], xmm11
0000713aae5dd1c2  vmovaps [rsp+0xC0], xmm12
0000713aae5dd1cb  vmovaps [rsp+0xD0], xmm13
0000713aae5dd1d4  vmovaps [rsp+0xE0], xmm15
0000713aae5dd1dd  sub rsp, 0x40
0000713aae5dd1e1  lea rdi, [rsp]
0000713aae5dd1e5  lea rsi, [rsp+0x10]
0000713aae5dd1ea  lea rdx, [rsp+0x20]
0000713aae5dd1ef  lea rcx, [rsp+0x30]
0000713aae5dd1f4  mov r8d, 0x00
0000713aae5dd1fa  lea r9, [r15+0x3A8]
0000713aae5dd201  movaps [rdi], xmm14
0000713aae5dd205  movaps [rsi], xmm11
0000713aae5dd209  movaps [rdx], xmm1
0000713aae5dd20c  movaps [rcx], xmm15
0000713aae5dd210  mov rax, 0x5E9381C89A50
0000713aae5dd21a  call rax
0000713aae5dd21c  movaps xmm14, [rsp]
0000713aae5dd221  add rsp, 0x40
0000713aae5dd225  vmovaps xmm0, [rsp]
0000713aae5dd22a  vmovaps xmm1, [rsp+0x10]
0000713aae5dd230  vmovaps xmm2, [rsp+0x20]
0000713aae5dd236  vmovaps xmm3, [rsp+0x30]
0000713aae5dd23c  vmovaps xmm4, [rsp+0x40]
0000713aae5dd242  vmovaps xmm5, [rsp+0x50]
0000713aae5dd248  vmovaps xmm6, [rsp+0x60]
0000713aae5dd24e  vmovaps xmm7, [rsp+0x70]
0000713aae5dd254  vmovaps xmm8, [rsp+0x80]
0000713aae5dd25d  vmovaps xmm9, [rsp+0x90]
0000713aae5dd266  vmovaps xmm10, [rsp+0xA0]
0000713aae5dd26f  vmovaps xmm11, [rsp+0xB0]
0000713aae5dd278  vmovaps xmm12, [rsp+0xC0]
0000713aae5dd281  vmovaps xmm13, [rsp+0xD0]
0000713aae5dd28a  vmovaps xmm15, [rsp+0xE0]
0000713aae5dd293  add rsp, 0xF0
0000713aae5dd29a  pop r11
0000713aae5dd29c  pop r10
0000713aae5dd29e  pop r9
0000713aae5dd2a0  pop r8
0000713aae5dd2a2  pop rsi
0000713aae5dd2a3  pop rdi
0000713aae5dd2a4  pop rdx
0000713aae5dd2a5  pop rcx
0000713aae5dd2a6  pop rax
0000713aae5dd2a7  add rsp, 0x08
0000713aae5dd2ab  jmp 0x0000713AAE5DA636
0000713aae5dd2b0  call 0x0000713AAE4079B0
0000713aae5dd2b5  jmp 0x0000713AAE5DA64C
0000713aae5dd2ba  call 0x0000713AAE4E3440
0000713aae5dd2bf  jmp 0x0000713AAE5DA656
0000713aae5dd2c4  call 0x0000713AAE4DFCE0
0000713aae5dd2c9  jmp 0x0000713AAE5DA660
0000713aae5dd2ce  call 0x0000713AAE4E46C0
0000713aae5dd2d3  jmp 0x0000713AAE5DA66A
0000713aae5dd2d8  int3
0000713aae5dd2d9  nop [rax], eax
0000713aae5dd2e0  mov qword ptr [r15+0x40], 0x430000
0000713aae5dd2e8  mov eax, 0x430C50
0000713aae5dd2ed  mov r14, [r13+rax*1]
0000713aae5dd2f2  movq xmm1, r14
0000713aae5dd2f7  mov rax, [r15+0x50]
0000713aae5dd2fb  movups xmm15, [r13+rax*1]
0000713aae5dd301  movaps [r15+0x120], xmm15
0000713aae5dd309  mov qword ptr [r15+0x48], 0x10
0000713aae5dd311  xor eax, eax
0000713aae5dd313  mov r14d, 0x10
0000713aae5dd319  mov r12d, 0x200
0000713aae5dd31f  cmp r14, r12
0000713aae5dd322  cmc
0000713aae5dd323  lahf
0000713aae5dd324  seto al
0000713aae5dd327  mov [r15+0x108], eax
0000713aae5dd32e  pextrq rax, xmm15, 0x01
0000713aae5dd335  movq xmm14, rax
0000713aae5dd33a  movaps [r15+0x130], xmm14
0000713aae5dd342  movq rax, xmm1
0000713aae5dd347  movq r14, xmm15
0000713aae5dd34c  vmovq xmm1, rax
0000713aae5dd351  vmovq xmm15, r14
0000713aae5dd356  movaps xmm13, xmm1
0000713aae5dd35a  addsd xmm13, xmm15
0000713aae5dd35f  ucomisd xmm13, xmm13
0000713aae5dd364  jp 0x0000713AAE5DD423
0000713aae5dd36a  movq xmm13, xmm13
0000713aae5dd36f  movq rax, xmm13
0000713aae5dd374  movq r14, xmm14
0000713aae5dd379  vmovq xmm1, rax
0000713aae5dd37e  vmovq xmm15, r14
0000713aae5dd383  movaps xmm14, xmm1
0000713aae5dd387  addsd xmm14, xmm15
0000713aae5dd38c  ucomisd xmm14, xmm14
0000713aae5dd391  jp 0x0000713AAE5DD46B
0000713aae5dd397  movq xmm14, xmm14
0000713aae5dd39c  movaps [r15+0x110], xmm14
0000713aae5dd3a4  mov eax, [r15+0x108]
0000713aae5dd3ab  sahf
0000713aae5dd3ac  jnz 0x0000713AAE5DD3DE
0000713aae5dd3ae  cmp dword ptr [r15+0x318], 0x00
0000713aae5dd3b6  jz 0x0000713AAE5DD680
0000713aae5dd3bc  nop [rax+rax*1], ax
0000713aae5dd3c5  nop [rax+rax*1], eax
0000713aae5dd3cd  mov eax, 0x410698
0000713aae5dd3d2  mov [r15+0x100], rax
0000713aae5dd3d9  jmp 0x0000713AAE3FE110
0000713aae5dd3de  cmp dword ptr [r15+0x318], 0x00
0000713aae5dd3e6  jz 0x0000713AAE5DD4C0
0000713aae5dd3ec  nop [rax+rax*1], ax
0000713aae5dd3f5  nop [rax+rax*1], eax
0000713aae5dd3fd  mov eax, 0x41067C
0000713aae5dd402  mov [r15+0x100], rax
0000713aae5dd409  jmp 0x0000713AAE3FE110
0000713aae5dd40e  int3
0000713aae5dd40f  call 0x0000713AAE40DC20
0000713aae5dd414  jmp 0x0000713AAE5DD2F2
0000713aae5dd419  call 0x0000713AAE40E760
0000713aae5dd41e  jmp 0x0000713AAE5DD301
0000713aae5dd423  ucomisd xmm1, xmm15
0000713aae5dd428  jp 0x0000713AAE5DD437
0000713aae5dd42a  movaps xmm13, [0x0000713AAE1FE060]
0000713aae5dd432  jmp 0x0000713AAE5DD36A
0000713aae5dd437  vxorps xmm0, xmm1, xmm15
0000713aae5dd43c  pextrw eax, xmm0, 0x03
0000713aae5dd441  and eax, 0x7FF8
0000713aae5dd446  cmp eax, 0x08
0000713aae5dd449  jnz 0x0000713AAE5DD36A
0000713aae5dd44f  movq rax, xmm15
0000713aae5dd454  shl rax, 0x0D
0000713aae5dd458  jbe 0x0000713AAE5DD36A
0000713aae5dd45e  vorps xmm13, xmm15, [0x0000713AAE1FE070]
0000713aae5dd466  jmp 0x0000713AAE5DD36A
0000713aae5dd46b  ucomisd xmm1, xmm15
0000713aae5dd470  jp 0x0000713AAE5DD47F
0000713aae5dd472  movaps xmm14, [0x0000713AAE1FE060]
0000713aae5dd47a  jmp 0x0000713AAE5DD397
0000713aae5dd47f  vxorps xmm0, xmm1, xmm15
0000713aae5dd484  pextrw eax, xmm0, 0x03
0000713aae5dd489  and eax, 0x7FF8
0000713aae5dd48e  cmp eax, 0x08
0000713aae5dd491  jnz 0x0000713AAE5DD397
0000713aae5dd497  movq rax, xmm15
0000713aae5dd49c  shl rax, 0x0D
0000713aae5dd4a0  jbe 0x0000713AAE5DD397
0000713aae5dd4a6  vorps xmm14, xmm15, [0x0000713AAE1FE070]
0000713aae5dd4ae  jmp 0x0000713AAE5DD397
0000713aae5dd4b3  int3
0000713aae5dd4b4  nop [rax+rax*1], ax
0000713aae5dd4bd  nop [rax], eax
0000713aae5dd4c0  mov rax, [r15+0x48]
0000713aae5dd4c4  mov r14, [r15+0x50]
0000713aae5dd4c8  lea r12, [r14+rax*1]
0000713aae5dd4cc  movups xmm1, [r13+r12*1]
0000713aae5dd4d2  movaps [r15+0x120], xmm1
0000713aae5dd4da  lea r14, [rax+0x10]
0000713aae5dd4de  mov [r15+0x48], r14
0000713aae5dd4e2  xor eax, eax
0000713aae5dd4e4  mov r12d, 0x200
0000713aae5dd4ea  cmp r14, r12
0000713aae5dd4ed  cmc
0000713aae5dd4ee  lahf
0000713aae5dd4ef  seto al
0000713aae5dd4f2  mov [r15+0x108], eax
0000713aae5dd4f9  pextrq rax, xmm1, 0x01
0000713aae5dd500  movq xmm15, rax
0000713aae5dd505  movaps [r15+0x130], xmm15
0000713aae5dd50d  movaps xmm14, [r15+0x110]
0000713aae5dd515  movq rax, xmm14
0000713aae5dd51a  movq r14, xmm1
0000713aae5dd51f  vmovq xmm1, rax
0000713aae5dd524  vmovq xmm14, r14
0000713aae5dd529  movaps xmm13, xmm1
0000713aae5dd52d  addsd xmm13, xmm14
0000713aae5dd532  ucomisd xmm13, xmm13
0000713aae5dd537  jp 0x0000713AAE5DD5EC
0000713aae5dd53d  movq xmm13, xmm13
0000713aae5dd542  movq rax, xmm13
0000713aae5dd547  movq r14, xmm15
0000713aae5dd54c  vmovq xmm1, rax
0000713aae5dd551  vmovq xmm15, r14
0000713aae5dd556  movaps xmm14, xmm1
0000713aae5dd55a  addsd xmm14, xmm15
0000713aae5dd55f  ucomisd xmm14, xmm14
0000713aae5dd564  jp 0x0000713AAE5DD634
0000713aae5dd56a  movq xmm14, xmm14
0000713aae5dd56f  movaps [r15+0x110], xmm14
0000713aae5dd577  mov eax, [r15+0x108]
0000713aae5dd57e  sahf
0000713aae5dd57f  jnz 0x0000713AAE5DD5B1
0000713aae5dd581  cmp dword ptr [r15+0x318], 0x00
0000713aae5dd589  jz 0x0000713AAE5DD680
0000713aae5dd58f  nop [rax+rax*1], ax
0000713aae5dd598  nop [rax+rax*1], eax
0000713aae5dd5a0  mov eax, 0x410698
0000713aae5dd5a5  mov [r15+0x100], rax
0000713aae5dd5ac  jmp 0x0000713AAE3FE110
0000713aae5dd5b1  cmp dword ptr [r15+0x318], 0x00
0000713aae5dd5b9  jz 0x0000713AAE5DD4C0
0000713aae5dd5bf  nop [rax+rax*1], ax
0000713aae5dd5c8  nop [rax+rax*1], eax
0000713aae5dd5d0  mov eax, 0x41067C
0000713aae5dd5d5  mov [r15+0x100], rax
0000713aae5dd5dc  jmp 0x0000713AAE3FE110
0000713aae5dd5e1  int3
0000713aae5dd5e2  call 0x0000713AAE4B52F0
0000713aae5dd5e7  jmp 0x0000713AAE5DD4D2
0000713aae5dd5ec  ucomisd xmm1, xmm14
0000713aae5dd5f1  jp 0x0000713AAE5DD600
0000713aae5dd5f3  movaps xmm13, [0x0000713AAE1FE060]
0000713aae5dd5fb  jmp 0x0000713AAE5DD53D
0000713aae5dd600  vxorps xmm0, xmm1, xmm14
0000713aae5dd605  pextrw eax, xmm0, 0x03
0000713aae5dd60a  and eax, 0x7FF8
0000713aae5dd60f  cmp eax, 0x08
0000713aae5dd612  jnz 0x0000713AAE5DD53D
0000713aae5dd618  movq rax, xmm14
0000713aae5dd61d  shl rax, 0x0D
0000713aae5dd621  jbe 0x0000713AAE5DD53D
0000713aae5dd627  vorps xmm13, xmm14, [0x0000713AAE1FE070]
0000713aae5dd62f  jmp 0x0000713AAE5DD53D
0000713aae5dd634  ucomisd xmm1, xmm15
0000713aae5dd639  jp 0x0000713AAE5DD648
0000713aae5dd63b  movaps xmm14, [0x0000713AAE1FE060]
0000713aae5dd643  jmp 0x0000713AAE5DD56A
0000713aae5dd648  vxorps xmm0, xmm1, xmm15
0000713aae5dd64d  pextrw eax, xmm0, 0x03
0000713aae5dd652  and eax, 0x7FF8
0000713aae5dd657  cmp eax, 0x08
0000713aae5dd65a  jnz 0x0000713AAE5DD56A
0000713aae5dd660  movq rax, xmm15
0000713aae5dd665  shl rax, 0x0D
0000713aae5dd669  jbe 0x0000713AAE5DD56A
0000713aae5dd66f  vorps xmm14, xmm15, [0x0000713AAE1FE070]
0000713aae5dd677  jmp 0x0000713AAE5DD56A
0000713aae5dd67c  int3
0000713aae5dd67d  nop [rax], eax
0000713aae5dd680  mov rax, [r15+0xF8]
0000713aae5dd687  lea r14, [rax+0x1A0]
0000713aae5dd68e  mov r12, [r13+r14*1]
0000713aae5dd693  lea r14, [rax+0x1A8]
0000713aae5dd69a  mov r11, [r13+r14*1]
0000713aae5dd69f  mov [r15+0xA0], r12
0000713aae5dd6a6  mov [r15+0x98], r11
0000713aae5dd6ad  mov r14, [r15+0x40]
0000713aae5dd6b1  lea r12, [r14+0xC50]
0000713aae5dd6b8  movaps xmm1, [r15+0x110]
0000713aae5dd6c0  movq r14, xmm1
0000713aae5dd6c5  mov [r13+r12*1], r14
0000713aae5dd6ca  lea r14, [rax+0x190]
0000713aae5dd6d1  mov r12, [r13+r14*1]
0000713aae5dd6d6  lea r14, [rax+0x198]
0000713aae5dd6dd  mov r11, [r13+r14*1]
0000713aae5dd6e2  mov [r15+0xE8], r12
0000713aae5dd6e9  mov [r15+0xF0], r11
0000713aae5dd6f0  lea r14, [rax+0x180]
0000713aae5dd6f7  mov r12, [r13+r14*1]
0000713aae5dd6fc  lea r14, [rax+0x188]
0000713aae5dd703  mov r10, [r13+r14*1]
0000713aae5dd708  movq xmm1, r12
0000713aae5dd70d  movq xmm15, r10
0000713aae5dd712  movq xmm1, xmm1
0000713aae5dd716  movq xmm1, xmm1
0000713aae5dd71a  movaps [r15+0x1A0], xmm1
0000713aae5dd722  movq xmm15, xmm15
0000713aae5dd727  movq xmm15, xmm15
0000713aae5dd72c  movaps [r15+0x190], xmm15
0000713aae5dd734  lea r14, [rax+0x170]
0000713aae5dd73b  mov r12, [r13+r14*1]
0000713aae5dd740  lea r14, [rax+0x178]
0000713aae5dd747  mov r10, [r13+r14*1]
0000713aae5dd74c  movq xmm1, r12
0000713aae5dd751  movq xmm15, r10
0000713aae5dd756  movq xmm1, xmm1
0000713aae5dd75a  movq xmm1, xmm1
0000713aae5dd75e  movaps [r15+0x1C0], xmm1
0000713aae5dd766  movq xmm15, xmm15
0000713aae5dd76b  movq xmm15, xmm15
0000713aae5dd770  movaps [r15+0x1B0], xmm15
0000713aae5dd778  lea r14, [rax+0x160]
0000713aae5dd77f  mov r12, [r13+r14*1]
0000713aae5dd784  lea r14, [rax+0x168]
0000713aae5dd78b  mov r10, [r13+r14*1]
0000713aae5dd790  movq xmm1, r12
0000713aae5dd795  movq xmm15, r10
0000713aae5dd79a  movq xmm1, xmm1
0000713aae5dd79e  movq xmm1, xmm1
0000713aae5dd7a2  movaps [r15+0x1E0], xmm1
0000713aae5dd7aa  movq xmm15, xmm15
0000713aae5dd7af  movq xmm15, xmm15
0000713aae5dd7b4  movaps [r15+0x1D0], xmm15
0000713aae5dd7bc  lea r14, [rax+0x150]
0000713aae5dd7c3  mov r12, [r13+r14*1]
0000713aae5dd7c8  lea r14, [rax+0x158]
0000713aae5dd7cf  mov r10, [r13+r14*1]
0000713aae5dd7d4  movq xmm1, r12
0000713aae5dd7d9  movq xmm15, r10
0000713aae5dd7de  movq xmm1, xmm1
0000713aae5dd7e2  movq xmm1, xmm1
0000713aae5dd7e6  movaps [r15+0x200], xmm1
0000713aae5dd7ee  movq xmm15, xmm15
0000713aae5dd7f3  movq xmm15, xmm15
0000713aae5dd7f8  movaps [r15+0x1F0], xmm15
0000713aae5dd800  lea r14, [rax+0x1B0]
0000713aae5dd807  mov [r15+0xF8], r14
0000713aae5dd80e  mov [r15+0x100], r11
0000713aae5dd815  jmp 0x0000713AAE5CE5C0
0000713aae5dd81a  int3
0000713aae5dd81b  call 0x0000713AAE4E27E0
0000713aae5dd820  jmp 0x0000713AAE5DD693
0000713aae5dd825  call 0x0000713AAE4E1570
0000713aae5dd82a  jmp 0x0000713AAE5DD69F
0000713aae5dd82f  call 0x0000713AAE4C3FE0
0000713aae5dd834  jmp 0x0000713AAE5DD6CA
0000713aae5dd839  call 0x0000713AAE4E27E0
0000713aae5dd83e  jmp 0x0000713AAE5DD6D6
0000713aae5dd843  call 0x0000713AAE4E1570
0000713aae5dd848  jmp 0x0000713AAE5DD6E2
0000713aae5dd84d  call 0x0000713AAE4E27E0
0000713aae5dd852  jmp 0x0000713AAE5DD6FC
0000713aae5dd857  call 0x0000713AAE4E0300
0000713aae5dd85c  jmp 0x0000713AAE5DD708
0000713aae5dd861  call 0x0000713AAE4E27E0
0000713aae5dd866  jmp 0x0000713AAE5DD740
0000713aae5dd86b  call 0x0000713AAE4E0300
0000713aae5dd870  jmp 0x0000713AAE5DD74C
0000713aae5dd875  call 0x0000713AAE4E27E0
0000713aae5dd87a  jmp 0x0000713AAE5DD784
0000713aae5dd87f  call 0x0000713AAE4E0300
0000713aae5dd884  jmp 0x0000713AAE5DD790
0000713aae5dd889  call 0x0000713AAE4E27E0
0000713aae5dd88e  jmp 0x0000713AAE5DD7C8
0000713aae5dd893  call 0x0000713AAE4E0300
0000713aae5dd898  jmp 0x0000713AAE5DD7D4
0000713aae5dd89d  int3
0000713aae5dd89e  nop
0000713aae5dd8a0  mov qword ptr [r15+0x100], 0x04
0000713aae5dd8ab  mov esi, 0x00
0000713aae5dd8b0  mov edx, 0x09
0000713aae5dd8b5  mov rdi, 0x7FFEBACFA3D0
0000713aae5dd8bf  mov rax, 0x5E9381B1C970
0000713aae5dd8c9  call rax
0000713aae5dd8cb  cmp dword ptr [r15+0x318], 0x00
0000713aae5dd8d3  jnz 0x0000713AAE3FE110
0000713aae5dd8d9  jmp 0x0000713AAE3FE0A0
0000713aae5dd8de  int3
0000713aae5dd8df  int3
