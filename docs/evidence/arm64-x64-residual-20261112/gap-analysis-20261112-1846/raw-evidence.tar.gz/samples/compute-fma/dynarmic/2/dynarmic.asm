000070a59adce69b  nop [rax+rax*1], eax
000070a59adce6a0  mov rax, [r15+0xF8]
000070a59adce6a7  lea r14, [rax-0x1B0]
000070a59adce6ae  mov [r15+0xF8], r14
000070a59adce6b5  lea rax, [r14+0x1A0]
000070a59adce6bc  mov r12, [r15+0xA0]
000070a59adce6c3  mov r11, [r15+0x98]
000070a59adce6ca  mov [r13+rax*1], r12
000070a59adce6cf  lea rax, [r14+0x1A8]
000070a59adce6d6  mov [r13+rax*1], r11
000070a59adce6db  mov eax, 0x420A30
000070a59adce6e0  movups xmm1, [r13+rax*1]
000070a59adce6e6  mov eax, 0x4209C0
000070a59adce6eb  movups xmm15, [r13+rax*1]
000070a59adce6f1  mov eax, 0x420A50
000070a59adce6f6  movups xmm14, [r13+rax*1]
000070a59adce6fc  mov eax, 0x4209F0
000070a59adce701  movups xmm13, [r13+rax*1]
000070a59adce707  mov qword ptr [r15+0x98], 0x430C60
000070a59adce712  mov eax, 0x420A60
000070a59adce717  movups xmm12, [r13+rax*1]
000070a59adce71d  mov eax, 0x430C60
000070a59adce722  movups [r13+rax*1], xmm1
000070a59adce728  mov eax, 0x430C70
000070a59adce72d  movups [r13+rax*1], xmm15
000070a59adce733  mov eax, 0x430C80
000070a59adce738  movups [r13+rax*1], xmm14
000070a59adce73e  mov eax, 0x430C90
000070a59adce743  movups [r13+rax*1], xmm13
000070a59adce749  mov eax, 0x4209B0
000070a59adce74e  movups xmm14, [r13+rax*1]
000070a59adce754  mov eax, 0x4209A0
000070a59adce759  movups xmm13, [r13+rax*1]
000070a59adce75f  mov eax, 0x430D60
000070a59adce764  movups [r13+rax*1], xmm1
000070a59adce76a  mov eax, 0x430D70
000070a59adce76f  movups [r13+rax*1], xmm15
000070a59adce775  mov eax, 0x430CA0
000070a59adce77a  movups [r13+rax*1], xmm12
000070a59adce780  mov eax, 0x430CB0
000070a59adce785  movups [r13+rax*1], xmm14
000070a59adce78b  mov eax, 0x420990
000070a59adce790  movups xmm1, [r13+rax*1]
000070a59adce796  mov eax, 0x420A00
000070a59adce79b  movups xmm15, [r13+rax*1]
000070a59adce7a1  mov eax, 0x430CC0
000070a59adce7a6  movups [r13+rax*1], xmm13
000070a59adce7ac  mov eax, 0x430CD0
000070a59adce7b1  movups [r13+rax*1], xmm1
000070a59adce7b7  mov eax, 0x420A10
000070a59adce7bc  movups xmm1, [r13+rax*1]
000070a59adce7c2  mov eax, 0x4209E0
000070a59adce7c7  movups xmm14, [r13+rax*1]
000070a59adce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
000070a59adce7d5  mov eax, 0x430CE0
000070a59adce7da  movups [r13+rax*1], xmm15
000070a59adce7e0  mov eax, 0x430CF0
000070a59adce7e5  movups [r13+rax*1], xmm1
000070a59adce7eb  mov eax, 0x420A80
000070a59adce7f0  movups xmm1, [r13+rax*1]
000070a59adce7f6  mov eax, 0x420A90
000070a59adce7fb  movups xmm15, [r13+rax*1]
000070a59adce801  movaps [r15+0x150], xmm15
000070a59adce809  mov qword ptr [r15+0xA0], 0x3E8
000070a59adce814  mov eax, 0x430D00
000070a59adce819  movups [r13+rax*1], xmm14
000070a59adce81f  mov eax, 0x430D10
000070a59adce824  movups [r13+rax*1], xmm1
000070a59adce82a  mov eax, 0x420A70
000070a59adce82f  movups xmm1, [r13+rax*1]
000070a59adce835  mov eax, 0x420A20
000070a59adce83a  movups xmm14, [r13+rax*1]
000070a59adce840  movaps [r15+0x140], xmm14
000070a59adce848  lea rax, [r14+0x150]
000070a59adce84f  movq xmm13, qword ptr [r15+0x200]
000070a59adce858  movq xmm12, qword ptr [r15+0x1F0]
000070a59adce861  movq r12, xmm13
000070a59adce866  movq r11, xmm12
000070a59adce86b  mov [r13+rax*1], r12
000070a59adce870  lea rax, [r14+0x158]
000070a59adce877  mov [r13+rax*1], r11
000070a59adce87c  mov eax, 0x430D20
000070a59adce881  movups [r13+rax*1], xmm15
000070a59adce887  mov eax, 0x430D30
000070a59adce88c  movups [r13+rax*1], xmm1
000070a59adce892  mov eax, 0x420A40
000070a59adce897  movups xmm1, [r13+rax*1]
000070a59adce89d  mov eax, 0x420AA8
000070a59adce8a2  mov r12, [r13+rax*1]
000070a59adce8a7  movq xmm15, r12
000070a59adce8ac  mov qword ptr [r15+0x40], 0x420AB0
000070a59adce8b4  mov eax, 0x430D40
000070a59adce8b9  movups [r13+rax*1], xmm14
000070a59adce8bf  mov eax, 0x430D50
000070a59adce8c4  movups [r13+rax*1], xmm1
000070a59adce8ca  mov eax, 0x420B10
000070a59adce8cf  movups xmm1, [r13+rax*1]
000070a59adce8d5  movq rax, xmm15
000070a59adce8da  mov r12d, 0x430D80
000070a59adce8e0  mov [r13+r12*1], rax
000070a59adce8e5  mov eax, 0x420AF0
000070a59adce8ea  movups xmm15, [r13+rax*1]
000070a59adce8f0  mov eax, 0x420B00
000070a59adce8f5  movups xmm14, [r13+rax*1]
000070a59adce8fb  lea rax, [r14+0x130]
000070a59adce902  movups [r13+rax*1], xmm1
000070a59adce908  lea rax, [r14+0x160]
000070a59adce90f  movq xmm1, qword ptr [r15+0x1E0]
000070a59adce918  movq xmm13, qword ptr [r15+0x1D0]
000070a59adce921  movq r12, xmm1
000070a59adce926  movq r11, xmm13
000070a59adce92b  mov [r13+rax*1], r12
000070a59adce930  lea rax, [r14+0x168]
000070a59adce937  mov [r13+rax*1], r11
000070a59adce93c  lea rax, [r14+0x110]
000070a59adce943  movups [r13+rax*1], xmm15
000070a59adce949  lea rax, [r14+0x120]
000070a59adce950  movups [r13+rax*1], xmm14
000070a59adce956  mov eax, 0x420AB0
000070a59adce95b  movups xmm1, [r13+rax*1]
000070a59adce961  mov eax, 0x420AC0
000070a59adce966  movups xmm15, [r13+rax*1]
000070a59adce96c  movaps [r15+0x120], xmm15
000070a59adce974  lea rax, [r14+0x170]
000070a59adce97b  movq xmm14, qword ptr [r15+0x1C0]
000070a59adce984  movq xmm13, qword ptr [r15+0x1B0]
000070a59adce98d  movq r12, xmm14
000070a59adce992  movq r11, xmm13
000070a59adce997  mov [r13+rax*1], r12
000070a59adce99c  lea rax, [r14+0x178]
000070a59adce9a3  mov [r13+rax*1], r11
000070a59adce9a8  lea rax, [r14+0x180]
000070a59adce9af  movq xmm14, qword ptr [r15+0x1A0]
000070a59adce9b8  movq xmm13, qword ptr [r15+0x190]
000070a59adce9c1  movq r12, xmm14
000070a59adce9c6  movq r11, xmm13
000070a59adce9cb  mov [r13+rax*1], r12
000070a59adce9d0  lea rax, [r14+0x188]
000070a59adce9d7  mov [r13+rax*1], r11
000070a59adce9dc  lea rax, [r14+0xD0]
000070a59adce9e3  movups [r13+rax*1], xmm1
000070a59adce9e9  lea rax, [r14+0xE0]
000070a59adce9f0  movups [r13+rax*1], xmm15
000070a59adce9f6  mov eax, 0x420AD0
000070a59adce9fb  movups xmm1, [r13+rax*1]
000070a59adcea01  mov eax, 0x420AE0
000070a59adcea06  movups xmm15, [r13+rax*1]
000070a59adcea0c  movaps [r15+0x110], xmm1
000070a59adcea14  movaps [r15+0x130], xmm15
000070a59adcea1c  lea rax, [r14+0x190]
000070a59adcea23  mov r12, [r15+0xE8]
000070a59adcea2a  mov r11, [r15+0xF0]
000070a59adcea31  mov [r13+rax*1], r12
000070a59adcea36  lea rax, [r14+0x198]
000070a59adcea3d  mov [r13+rax*1], r11
000070a59adcea42  mov eax, 0x430D88
000070a59adcea47  mov r12d, 0x421DF8D3
000070a59adcea4d  mov [r13+rax*1], r12d
000070a59adcea52  lea rax, [r14+0xF0]
000070a59adcea59  movups [r13+rax*1], xmm1
000070a59adcea5f  lea rax, [r14+0x100]
000070a59adcea66  movups [r13+rax*1], xmm15
000070a59adcea6c  lea rax, [r14+0xD0]
000070a59adcea73  mov [r15], rax
000070a59adcea76  mov qword ptr [r15+0x08], 0x430C60
000070a59adcea7e  mov qword ptr [r15+0x10], 0x12C
000070a59adcea86  mov qword ptr [r15+0xF0], 0x410284
000070a59adcea91  mov r14d, [r15+0x320]
000070a59adcea98  mov eax, 0x410284
000070a59adcea9d  mov rcx, 0x70A59ADD07C0
000070a59adceaa7  mov [r15+r14*8+0x328], rax
000070a59adceaaf  mov [r15+r14*8+0x368], rcx
000070a59adceab7  add r14d, 0x01
000070a59adceabb  and r14d, 0x07
000070a59adceabf  mov [r15+0x320], r14d
000070a59adceac6  cmp dword ptr [r15+0x318], 0x00
000070a59adceace  jz 0x000070A59ADCED70
000070a59adcead4  nop [rax+rax*1], ax
000070a59adceadd  nop [rax+rax*1], eax
000070a59adceae5  mov eax, 0x4106BC
000070a59adceaea  mov [r15+0x100], rax
000070a59adceaf1  jmp 0x000070A59ABFE110
000070a59adceaf6  int3
000070a59adceaf7  call 0x000070A59AC0BC20
000070a59adceafc  jmp 0x000070A59ADCE6CF
000070a59adceb01  call 0x000070A59AC0A9A0
000070a59adceb06  jmp 0x000070A59ADCE6DB
000070a59adceb0b  call 0x000070A59ABFF430
000070a59adceb10  jmp 0x000070A59ADCE6E6
000070a59adceb15  call 0x000070A59AC0E760
000070a59adceb1a  jmp 0x000070A59ADCE6F1
000070a59adceb1f  call 0x000070A59AC0D4E0
000070a59adceb24  jmp 0x000070A59ADCE6FC
000070a59adceb29  call 0x000070A59AC0C260
000070a59adceb2e  jmp 0x000070A59ADCE707
000070a59adceb33  call 0x000070A59AC0AFE0
000070a59adceb38  jmp 0x000070A59ADCE71D
000070a59adceb3d  call 0x000070A59ABFF540
000070a59adceb42  jmp 0x000070A59ADCE728
000070a59adceb47  call 0x000070A59AC0E880
000070a59adceb4c  jmp 0x000070A59ADCE733
000070a59adceb51  call 0x000070A59AC0D600
000070a59adceb56  jmp 0x000070A59ADCE73E
000070a59adceb5b  call 0x000070A59AC0C380
000070a59adceb60  jmp 0x000070A59ADCE749
000070a59adceb65  call 0x000070A59AC0D4E0
000070a59adceb6a  jmp 0x000070A59ADCE754
000070a59adceb6f  call 0x000070A59AC0C260
000070a59adceb74  jmp 0x000070A59ADCE75F
000070a59adceb79  call 0x000070A59ABFF540
000070a59adceb7e  jmp 0x000070A59ADCE76A
000070a59adceb83  call 0x000070A59AC0E880
000070a59adceb88  jmp 0x000070A59ADCE775
000070a59adceb8d  call 0x000070A59AC0B100
000070a59adceb92  jmp 0x000070A59ADCE780
000070a59adceb97  call 0x000070A59AC0D600
000070a59adceb9c  jmp 0x000070A59ADCE78B
000070a59adceba1  call 0x000070A59ABFF430
000070a59adceba6  jmp 0x000070A59ADCE796
000070a59adcebab  call 0x000070A59AC0E760
000070a59adcebb0  jmp 0x000070A59ADCE7A1
000070a59adcebb5  call 0x000070A59AC0C380
000070a59adcebba  jmp 0x000070A59ADCE7AC
000070a59adcebbf  call 0x000070A59ABFF540
000070a59adcebc4  jmp 0x000070A59ADCE7B7
000070a59adcebc9  call 0x000070A59ABFF430
000070a59adcebce  jmp 0x000070A59ADCE7C2
000070a59adcebd3  call 0x000070A59AC0D4E0
000070a59adcebd8  jmp 0x000070A59ADCE7CD
000070a59adcebdd  call 0x000070A59AC0E880
000070a59adcebe2  jmp 0x000070A59ADCE7E0
000070a59adcebe7  call 0x000070A59ABFF540
000070a59adcebec  jmp 0x000070A59ADCE7EB
000070a59adcebf1  call 0x000070A59ABFF430
000070a59adcebf6  jmp 0x000070A59ADCE7F6
000070a59adcebfb  call 0x000070A59AC0E760
000070a59adcec00  jmp 0x000070A59ADCE801
000070a59adcec05  call 0x000070A59AC0D600
000070a59adcec0a  jmp 0x000070A59ADCE81F
000070a59adcec0f  call 0x000070A59ABFF540
000070a59adcec14  jmp 0x000070A59ADCE82A
000070a59adcec19  call 0x000070A59ABFF430
000070a59adcec1e  jmp 0x000070A59ADCE835
000070a59adcec23  call 0x000070A59AC0D4E0
000070a59adcec28  jmp 0x000070A59ADCE840
000070a59adcec2d  call 0x000070A59AC0BC20
000070a59adcec32  jmp 0x000070A59ADCE870
000070a59adcec37  call 0x000070A59AC0A9A0
000070a59adcec3c  jmp 0x000070A59ADCE87C
000070a59adcec41  call 0x000070A59AC0E880
000070a59adcec46  jmp 0x000070A59ADCE887
000070a59adcec4b  call 0x000070A59ABFF540
000070a59adcec50  jmp 0x000070A59ADCE892
000070a59adcec55  call 0x000070A59ABFF430
000070a59adcec5a  jmp 0x000070A59ADCE89D
000070a59adcec5f  call 0x000070A59AC0B720
000070a59adcec64  jmp 0x000070A59ADCE8A7
000070a59adcec69  call 0x000070A59AC0D600
000070a59adcec6e  jmp 0x000070A59ADCE8BF
000070a59adcec73  call 0x000070A59ABFF540
000070a59adcec78  jmp 0x000070A59ADCE8CA
000070a59adcec7d  call 0x000070A59ABFF430
000070a59adcec82  jmp 0x000070A59ADCE8D5
000070a59adcec87  call 0x000070A59ACB4CB0
000070a59adcec8c  jmp 0x000070A59ADCE8E5
000070a59adcec91  call 0x000070A59AC0E760
000070a59adcec96  jmp 0x000070A59ADCE8F0
000070a59adcec9b  call 0x000070A59AC0D4E0
000070a59adceca0  jmp 0x000070A59ADCE8FB
000070a59adceca5  call 0x000070A59ABFF540
000070a59adcecaa  jmp 0x000070A59ADCE908
000070a59adcecaf  call 0x000070A59AC0BC20
000070a59adcecb4  jmp 0x000070A59ADCE930
000070a59adcecb9  call 0x000070A59AC0A9A0
000070a59adcecbe  jmp 0x000070A59ADCE93C
000070a59adcecc3  call 0x000070A59AC0E880
000070a59adcecc8  jmp 0x000070A59ADCE949
000070a59adceccd  call 0x000070A59AC0D600
000070a59adcecd2  jmp 0x000070A59ADCE956
000070a59adcecd7  call 0x000070A59ABFF430
000070a59adcecdc  jmp 0x000070A59ADCE961
000070a59adcece1  call 0x000070A59AC0E760
000070a59adcece6  jmp 0x000070A59ADCE96C
000070a59adceceb  call 0x000070A59AC0BC20
000070a59adcecf0  jmp 0x000070A59ADCE99C
000070a59adcecf5  call 0x000070A59AC0A9A0
000070a59adcecfa  jmp 0x000070A59ADCE9A8
000070a59adcecff  call 0x000070A59AC0BC20
000070a59adced04  jmp 0x000070A59ADCE9D0
000070a59adced09  call 0x000070A59AC0A9A0
000070a59adced0e  jmp 0x000070A59ADCE9DC
000070a59adced13  call 0x000070A59ABFF540
000070a59adced18  jmp 0x000070A59ADCE9E9
000070a59adced1d  call 0x000070A59AC0E880
000070a59adced22  jmp 0x000070A59ADCE9F6
000070a59adced27  call 0x000070A59ABFF430
000070a59adced2c  jmp 0x000070A59ADCEA01
000070a59adced31  call 0x000070A59AC0E760
000070a59adced36  jmp 0x000070A59ADCEA0C
000070a59adced3b  call 0x000070A59AC0BC20
000070a59adced40  jmp 0x000070A59ADCEA36
000070a59adced45  call 0x000070A59AC0A9A0
000070a59adced4a  jmp 0x000070A59ADCEA42
000070a59adced4f  call 0x000070A59AC0BAE0
000070a59adced54  jmp 0x000070A59ADCEA52
000070a59adced59  call 0x000070A59ABFF540
000070a59adced5e  jmp 0x000070A59ADCEA5F
000070a59adced63  call 0x000070A59AC0E880
000070a59adced68  jmp 0x000070A59ADCEA6C
000070a59adced6d  int3
000070a59adced6e  nop
000070a59adced70  mov rax, [r15]
000070a59adced73  lea r14, [rax+0x20]
000070a59adced77  mov r12, [r13+r14*1]
000070a59adced7c  mov r14, [r15+0x10]
000070a59adced80  lea r11, [r12+r14*1]
000070a59adced84  mov [r15+0x40], r11
000070a59adced88  lea r12, [rax+0x20]
000070a59adced8c  mov [r13+r12*1], r11
000070a59adced91  test r14, r14
000070a59adced94  setz r14b
000070a59adced98  movzx r14, r14b
000070a59adced9c  mov [rsp+0x414], r14b
000070a59adceda4  cmp byte ptr [rsp+0x414], 0x00
000070a59adcedac  jz 0x000070A59ADCEDDE
000070a59adcedae  cmp dword ptr [r15+0x318], 0x00
000070a59adcedb6  mov eax, 0x410934
000070a59adcedbb  mov [r15+0x100], rax
000070a59adcedc2  jz 0x000070A59ABFE0A0
000070a59adcedc8  nop [rax+rax*1], eax
000070a59adcedcd  mov eax, 0x410934
000070a59adcedd2  mov [r15+0x100], rax
000070a59adcedd9  jmp 0x000070A59ABFE110
000070a59adcedde  cmp dword ptr [r15+0x318], 0x00
000070a59adcede6  jz 0x000070A59ADCEE30
000070a59adcedec  nop [rax+rax*1], ax
000070a59adcedf5  nop [rax+rax*1], eax
000070a59adcedfd  mov eax, 0x4106CC
000070a59adcee02  mov [r15+0x100], rax
000070a59adcee09  jmp 0x000070A59ABFE110
000070a59adcee0e  int3
000070a59adcee0f  call 0x000070A59ACE27E0
000070a59adcee14  jmp 0x000070A59ADCED7C
000070a59adcee19  call 0x000070A59ACC0860
000070a59adcee1e  jmp 0x000070A59ADCED91
000070a59adcee23  int3
000070a59adcee24  nop [rax+rax*1], ax
000070a59adcee2d  nop [rax], eax
000070a59adcee30  mov rax, [r15+0xF8]
000070a59adcee37  lea r14, [rax-0x150]
000070a59adcee3e  mov [r15+0xF8], r14
000070a59adcee45  mov rax, [r15]
000070a59adcee48  lea r12, [rax+0x68]
000070a59adcee4c  mov r11, [r13+r12*1]
000070a59adcee51  mov [r15+0x88], r11
000070a59adcee58  lea r12, [rax+0x28]
000070a59adcee5c  mov [r15+0x40], r12
000070a59adcee60  mov [r15+0x48], r14
000070a59adcee64  mov qword ptr [r15+0x50], 0x420B20
000070a59adcee6c  lea rax, [r14+0x100]
000070a59adcee73  mov r12, [r15+0xE8]
000070a59adcee7a  mov r11, [r15+0xD8]
000070a59adcee81  mov [r13+rax*1], r12
000070a59adcee86  lea rax, [r14+0x108]
000070a59adcee8d  mov [r13+rax*1], r11
000070a59adcee92  lea rax, [r14+0x110]
000070a59adcee99  mov r12, [r15+0xD0]
000070a59adceea0  mov r11, [r15+0xC8]
000070a59adceea7  mov [r13+rax*1], r12
000070a59adceeac  lea rax, [r14+0x118]
000070a59adceeb3  mov [r13+rax*1], r11
000070a59adceeb8  lea rax, [r14+0x120]
000070a59adceebf  mov r12, [r15+0xC0]
000070a59adceec6  mov r11, [r15+0xB8]
000070a59adceecd  mov [r13+rax*1], r12
000070a59adceed2  lea rax, [r14+0x128]
000070a59adceed9  mov [r13+rax*1], r11
000070a59adceede  lea rax, [r14+0x130]
000070a59adceee5  mov r12, [r15+0xB0]
000070a59adceeec  mov r11, [r15+0xA8]
000070a59adceef3  mov [r13+rax*1], r12
000070a59adceef8  lea rax, [r14+0x138]
000070a59adceeff  mov [r13+rax*1], r11
000070a59adcef04  lea rax, [r14+0x140]
000070a59adcef0b  mov r12, [r15+0xA0]
000070a59adcef12  mov r11, [r15+0x98]
000070a59adcef19  mov [r13+rax*1], r12
000070a59adcef1e  lea rax, [r14+0x148]
000070a59adcef25  mov [r13+rax*1], r11
000070a59adcef2a  cmp dword ptr [r15+0x318], 0x00
000070a59adcef32  jz 0x000070A59ADCEFD0
000070a59adcef38  nop [rax+rax*1], ax
000070a59adcef41  nop [rax+rax*1], eax
000070a59adcef49  mov eax, 0x410704
000070a59adcef4e  mov [r15+0x100], rax
000070a59adcef55  jmp 0x000070A59ABFE110
000070a59adcef5a  int3
000070a59adcef5b  call 0x000070A59ACC0370
000070a59adcef60  jmp 0x000070A59ADCEE51
000070a59adcef65  call 0x000070A59AC0BC20
000070a59adcef6a  jmp 0x000070A59ADCEE86
000070a59adcef6f  call 0x000070A59AC0A9A0
000070a59adcef74  jmp 0x000070A59ADCEE92
000070a59adcef79  call 0x000070A59AC0BC20
000070a59adcef7e  jmp 0x000070A59ADCEEAC
000070a59adcef83  call 0x000070A59AC0A9A0
000070a59adcef88  jmp 0x000070A59ADCEEB8
000070a59adcef8d  call 0x000070A59AC0BC20
000070a59adcef92  jmp 0x000070A59ADCEED2
000070a59adcef97  call 0x000070A59AC0A9A0
000070a59adcef9c  jmp 0x000070A59ADCEEDE
000070a59adcefa1  call 0x000070A59AC0BC20
000070a59adcefa6  jmp 0x000070A59ADCEEF8
000070a59adcefab  call 0x000070A59AC0A9A0
000070a59adcefb0  jmp 0x000070A59ADCEF04
000070a59adcefb5  call 0x000070A59AC0BC20
000070a59adcefba  jmp 0x000070A59ADCEF1E
000070a59adcefbf  call 0x000070A59AC0A9A0
000070a59adcefc4  jmp 0x000070A59ADCEF2A
000070a59adcefc9  int3
000070a59adcefca  nop [rax+rax*1], ax
000070a59adcefd0  mov rax, [r15+0x08]
000070a59adcefd4  movzx r14d, byte ptr [r13+rax*1]
000070a59adcefda  movzx r14d, r14b
000070a59adcefde  mov [rsp+0x10], r14d
000070a59adcefe3  mov r14d, r14d
000070a59adcefe6  mov [r15+0x58], r14
000070a59adcefea  lea r14, [rax+0x01]
000070a59adcefee  mov [r15+0x08], r14
000070a59adceff2  mov rax, [r15+0x88]
000070a59adceff9  lea r14, [rax+0x01]
000070a59adceffd  mov r12, [r15]
000070a59adcf000  lea r11, [r12+0x68]
000070a59adcf005  mov [r13+r11*1], r14
000070a59adcf00a  lea r14, [r12+rax*1]
000070a59adcf00e  mov [r15+0x60], r14
000070a59adcf012  lea rax, [r14+0x28]
000070a59adcf016  mov r11d, [rsp+0x10]
000070a59adcf01b  movzx r14d, r11b
000070a59adcf01f  mov [r13+rax*1], r14b
000070a59adcf024  lea rax, [r12+0x68]
000070a59adcf029  mov r14, [r13+rax*1]
000070a59adcf02e  mov [r15+0x88], r14
000070a59adcf035  xor eax, eax
000070a59adcf037  mov r12d, 0x40
000070a59adcf03d  cmp r14, r12
000070a59adcf040  cmc
000070a59adcf041  lahf
000070a59adcf042  seto al
000070a59adcf045  mov [r15+0x108], eax
000070a59adcf04c  mov eax, [r15+0x108]
000070a59adcf053  sahf
000070a59adcf054  jnz 0x000070A59ADCF086
000070a59adcf056  cmp dword ptr [r15+0x318], 0x00
000070a59adcf05e  jz 0x000070A59ADCF170
000070a59adcf064  nop [rax+rax*1], ax
000070a59adcf06d  nop [rax+rax*1], eax
000070a59adcf075  mov eax, 0x410724
000070a59adcf07a  mov [r15+0x100], rax
000070a59adcf081  jmp 0x000070A59ABFE110
000070a59adcf086  cmp dword ptr [r15+0x318], 0x00
000070a59adcf08e  jz 0x000070A59ADCF0E0
000070a59adcf094  nop [rax+rax*1], ax
000070a59adcf09d  nop [rax+rax*1], eax
000070a59adcf0a5  mov eax, 0x4106FC
000070a59adcf0aa  mov [r15+0x100], rax
000070a59adcf0b1  jmp 0x000070A59ABFE110
000070a59adcf0b6  int3
000070a59adcf0b7  call 0x000070A59AC0D860
000070a59adcf0bc  jmp 0x000070A59ADCEFDA
000070a59adcf0c1  call 0x000070A59ACB36E0
000070a59adcf0c6  jmp 0x000070A59ADCF00A
000070a59adcf0cb  call 0x000070A59AC0DD60
000070a59adcf0d0  jmp 0x000070A59ADCF024
000070a59adcf0d5  call 0x000070A59AC0DC20
000070a59adcf0da  jmp 0x000070A59ADCF02E
000070a59adcf0df  int3
000070a59adcf0e0  mov rax, [r15+0x10]
000070a59adcf0e4  lea r14, [rax-0x01]
000070a59adcf0e8  mov [r15+0x10], r14
000070a59adcf0ec  test r14, r14
000070a59adcf0ef  setz r14b
000070a59adcf0f3  movzx r14, r14b
000070a59adcf0f7  mov [rsp+0x414], r14b
000070a59adcf0ff  cmp byte ptr [rsp+0x414], 0x00
000070a59adcf107  jz 0x000070A59ADCF139
000070a59adcf109  cmp dword ptr [r15+0x318], 0x00
000070a59adcf111  jz 0x000070A59ADD0670
000070a59adcf117  nop [rax+rax*1], ax
000070a59adcf120  nop [rax+rax*1], eax
000070a59adcf128  mov eax, 0x41091C
000070a59adcf12d  mov [r15+0x100], rax
000070a59adcf134  jmp 0x000070A59ABFE110
000070a59adcf139  cmp dword ptr [r15+0x318], 0x00
000070a59adcf141  jz 0x000070A59ADCEFD0
000070a59adcf147  nop [rax+rax*1], ax
000070a59adcf150  nop [rax+rax*1], eax
000070a59adcf158  mov eax, 0x410704
000070a59adcf15d  mov [r15+0x100], rax
000070a59adcf164  jmp 0x000070A59ABFE110
000070a59adcf169  int3
000070a59adcf16a  int3
000070a59adcf16b  nop [rax+rax*1], eax
000070a59adcf170  mov rax, [r15+0x40]
000070a59adcf174  movzx r14d, byte ptr [r13+rax*1]
000070a59adcf17a  movaps xmm1, [r15+0x110]
000070a59adcf182  pinsrb xmm1, r14d, 0x00
000070a59adcf189  lea r14, [rax+0x01]
000070a59adcf18d  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf193  movaps xmm15, [r15+0x120]
000070a59adcf19b  pinsrb xmm15, r12d, 0x00
000070a59adcf1a2  lea r14, [rax+0x02]
000070a59adcf1a6  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf1ac  movaps xmm14, [r15+0x130]
000070a59adcf1b4  pinsrb xmm14, r12d, 0x00
000070a59adcf1bb  lea r14, [rax+0x03]
000070a59adcf1bf  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf1c5  movaps xmm13, [r15+0x140]
000070a59adcf1cd  pinsrb xmm13, r12d, 0x00
000070a59adcf1d4  lea r14, [rax+0x04]
000070a59adcf1d8  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf1de  pinsrb xmm1, r12d, 0x01
000070a59adcf1e5  lea r14, [rax+0x05]
000070a59adcf1e9  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf1ef  pinsrb xmm15, r12d, 0x01
000070a59adcf1f6  lea r14, [rax+0x06]
000070a59adcf1fa  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf200  pinsrb xmm14, r12d, 0x01
000070a59adcf207  lea r14, [rax+0x07]
000070a59adcf20b  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf211  pinsrb xmm13, r12d, 0x01
000070a59adcf218  lea r14, [rax+0x08]
000070a59adcf21c  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf222  pinsrb xmm1, r12d, 0x02
000070a59adcf229  lea r14, [rax+0x09]
000070a59adcf22d  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf233  pinsrb xmm15, r12d, 0x02
000070a59adcf23a  lea r14, [rax+0x0A]
000070a59adcf23e  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf244  pinsrb xmm14, r12d, 0x02
000070a59adcf24b  lea r14, [rax+0x0B]
000070a59adcf24f  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf255  pinsrb xmm13, r12d, 0x02
000070a59adcf25c  lea r14, [rax+0x0C]
000070a59adcf260  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf266  pinsrb xmm1, r12d, 0x03
000070a59adcf26d  lea r14, [rax+0x0D]
000070a59adcf271  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf277  pinsrb xmm15, r12d, 0x03
000070a59adcf27e  lea r14, [rax+0x0E]
000070a59adcf282  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf288  pinsrb xmm14, r12d, 0x03
000070a59adcf28f  lea r14, [rax+0x0F]
000070a59adcf293  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf299  pinsrb xmm13, r12d, 0x03
000070a59adcf2a0  lea r14, [rax+0x10]
000070a59adcf2a4  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf2aa  pinsrb xmm1, r12d, 0x04
000070a59adcf2b1  lea r14, [rax+0x11]
000070a59adcf2b5  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf2bb  pinsrb xmm15, r12d, 0x04
000070a59adcf2c2  lea r14, [rax+0x12]
000070a59adcf2c6  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf2cc  pinsrb xmm14, r12d, 0x04
000070a59adcf2d3  lea r14, [rax+0x13]
000070a59adcf2d7  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf2dd  pinsrb xmm13, r12d, 0x04
000070a59adcf2e4  lea r14, [rax+0x14]
000070a59adcf2e8  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf2ee  pinsrb xmm1, r12d, 0x05
000070a59adcf2f5  lea r14, [rax+0x15]
000070a59adcf2f9  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf2ff  pinsrb xmm15, r12d, 0x05
000070a59adcf306  lea r14, [rax+0x16]
000070a59adcf30a  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf310  pinsrb xmm14, r12d, 0x05
000070a59adcf317  lea r14, [rax+0x17]
000070a59adcf31b  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf321  pinsrb xmm13, r12d, 0x05
000070a59adcf328  lea r14, [rax+0x18]
000070a59adcf32c  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf332  pinsrb xmm1, r12d, 0x06
000070a59adcf339  lea r14, [rax+0x19]
000070a59adcf33d  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf343  pinsrb xmm15, r12d, 0x06
000070a59adcf34a  lea r14, [rax+0x1A]
000070a59adcf34e  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf354  pinsrb xmm14, r12d, 0x06
000070a59adcf35b  lea r14, [rax+0x1B]
000070a59adcf35f  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf365  pinsrb xmm13, r12d, 0x06
000070a59adcf36c  lea r14, [rax+0x1C]
000070a59adcf370  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf376  pinsrb xmm1, r12d, 0x07
000070a59adcf37d  lea r14, [rax+0x1D]
000070a59adcf381  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf387  pinsrb xmm15, r12d, 0x07
000070a59adcf38e  lea r14, [rax+0x1E]
000070a59adcf392  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf398  pinsrb xmm14, r12d, 0x07
000070a59adcf39f  lea r14, [rax+0x1F]
000070a59adcf3a3  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf3a9  pinsrb xmm13, r12d, 0x07
000070a59adcf3b0  lea r14, [rax+0x20]
000070a59adcf3b4  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf3ba  pinsrb xmm1, r12d, 0x08
000070a59adcf3c1  lea r14, [rax+0x21]
000070a59adcf3c5  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf3cb  pinsrb xmm15, r12d, 0x08
000070a59adcf3d2  lea r14, [rax+0x22]
000070a59adcf3d6  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf3dc  pinsrb xmm14, r12d, 0x08
000070a59adcf3e3  lea r14, [rax+0x23]
000070a59adcf3e7  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf3ed  pinsrb xmm13, r12d, 0x08
000070a59adcf3f4  lea r14, [rax+0x24]
000070a59adcf3f8  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf3fe  pinsrb xmm1, r12d, 0x09
000070a59adcf405  lea r14, [rax+0x25]
000070a59adcf409  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf40f  pinsrb xmm15, r12d, 0x09
000070a59adcf416  lea r14, [rax+0x26]
000070a59adcf41a  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf420  pinsrb xmm14, r12d, 0x09
000070a59adcf427  lea r14, [rax+0x27]
000070a59adcf42b  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf431  pinsrb xmm13, r12d, 0x09
000070a59adcf438  lea r14, [rax+0x28]
000070a59adcf43c  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf442  pinsrb xmm1, r12d, 0x0A
000070a59adcf449  lea r14, [rax+0x29]
000070a59adcf44d  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf453  pinsrb xmm15, r12d, 0x0A
000070a59adcf45a  lea r14, [rax+0x2A]
000070a59adcf45e  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf464  pinsrb xmm14, r12d, 0x0A
000070a59adcf46b  lea r14, [rax+0x2B]
000070a59adcf46f  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf475  pinsrb xmm13, r12d, 0x0A
000070a59adcf47c  lea r14, [rax+0x2C]
000070a59adcf480  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf486  pinsrb xmm1, r12d, 0x0B
000070a59adcf48d  lea r14, [rax+0x2D]
000070a59adcf491  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf497  pinsrb xmm15, r12d, 0x0B
000070a59adcf49e  lea r14, [rax+0x2E]
000070a59adcf4a2  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf4a8  pinsrb xmm14, r12d, 0x0B
000070a59adcf4af  lea r14, [rax+0x2F]
000070a59adcf4b3  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf4b9  pinsrb xmm13, r12d, 0x0B
000070a59adcf4c0  lea r14, [rax+0x30]
000070a59adcf4c4  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf4ca  pinsrb xmm1, r12d, 0x0C
000070a59adcf4d1  lea r14, [rax+0x31]
000070a59adcf4d5  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf4db  pinsrb xmm15, r12d, 0x0C
000070a59adcf4e2  lea r14, [rax+0x32]
000070a59adcf4e6  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf4ec  pinsrb xmm14, r12d, 0x0C
000070a59adcf4f3  lea r14, [rax+0x33]
000070a59adcf4f7  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf4fd  pinsrb xmm13, r12d, 0x0C
000070a59adcf504  lea r14, [rax+0x34]
000070a59adcf508  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf50e  pinsrb xmm1, r12d, 0x0D
000070a59adcf515  lea r14, [rax+0x35]
000070a59adcf519  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf51f  pinsrb xmm15, r12d, 0x0D
000070a59adcf526  lea r14, [rax+0x36]
000070a59adcf52a  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf530  pinsrb xmm14, r12d, 0x0D
000070a59adcf537  lea r14, [rax+0x37]
000070a59adcf53b  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf541  pinsrb xmm13, r12d, 0x0D
000070a59adcf548  lea r14, [rax+0x38]
000070a59adcf54c  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf552  pinsrb xmm1, r12d, 0x0E
000070a59adcf559  lea r14, [rax+0x39]
000070a59adcf55d  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf563  pinsrb xmm15, r12d, 0x0E
000070a59adcf56a  lea r14, [rax+0x3A]
000070a59adcf56e  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf574  pinsrb xmm14, r12d, 0x0E
000070a59adcf57b  lea r14, [rax+0x3B]
000070a59adcf57f  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf585  pinsrb xmm13, r12d, 0x0E
000070a59adcf58c  lea r14, [rax+0x3C]
000070a59adcf590  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf596  pinsrb xmm1, r12d, 0x0F
000070a59adcf59d  movaps [r15+0x110], xmm1
000070a59adcf5a5  lea r14, [rax+0x3D]
000070a59adcf5a9  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf5af  pinsrb xmm15, r12d, 0x0F
000070a59adcf5b6  movaps [r15+0x120], xmm15
000070a59adcf5be  lea r14, [rax+0x3E]
000070a59adcf5c2  movzx r12d, byte ptr [r13+r14*1]
000070a59adcf5c8  pinsrb xmm14, r12d, 0x0F
000070a59adcf5cf  movaps [r15+0x130], xmm14
000070a59adcf5d7  lea r14, [rax+0x3F]
000070a59adcf5db  movzx eax, byte ptr [r13+r14*1]
000070a59adcf5e1  pinsrb xmm13, eax, 0x0F
000070a59adcf5e8  movaps [r15+0x140], xmm13
000070a59adcf5f0  movq xmm1, qword ptr [r15+0x120]
000070a59adcf5f9  pmovzxbw xmm1, xmm1
000070a59adcf5fe  psllw xmm1, 0x00
000070a59adcf603  movaps [r15+0x150], xmm1
000070a59adcf60b  movq xmm1, qword ptr [r15+0x130]
000070a59adcf614  pmovzxbw xmm1, xmm1
000070a59adcf619  psllw xmm1, 0x00
000070a59adcf61e  movaps [r15+0x160], xmm1
000070a59adcf626  movq xmm1, qword ptr [r15+0x110]
000070a59adcf62f  pmovzxbw xmm1, xmm1
000070a59adcf634  psllw xmm1, 0x00
000070a59adcf639  movaps [r15+0x170], xmm1
000070a59adcf641  movaps xmm15, [r15+0x110]
000070a59adcf649  pextrq rax, xmm15, 0x01
000070a59adcf650  movq xmm15, rax
000070a59adcf655  pmovzxbw xmm15, xmm15
000070a59adcf65b  psllw xmm15, 0x00
000070a59adcf661  movaps [r15+0x180], xmm15
000070a59adcf669  movaps xmm14, [r15+0x120]
000070a59adcf671  pextrq rax, xmm14, 0x01
000070a59adcf678  movq xmm14, rax
000070a59adcf67d  pmovzxbw xmm14, xmm14
000070a59adcf683  psllw xmm14, 0x00
000070a59adcf689  movaps [r15+0x210], xmm14
000070a59adcf691  movaps xmm13, [r15+0x130]
000070a59adcf699  pextrq rax, xmm13, 0x01
000070a59adcf6a0  movq xmm13, rax
000070a59adcf6a5  pmovzxbw xmm13, xmm13
000070a59adcf6ab  psllw xmm13, 0x00
000070a59adcf6b1  movaps [r15+0x220], xmm13
000070a59adcf6b9  movq xmm12, qword ptr [r15+0x140]
000070a59adcf6c2  pmovzxbw xmm12, xmm12
000070a59adcf6c8  psllw xmm12, 0x00
000070a59adcf6ce  movaps [r15+0x250], xmm12
000070a59adcf6d6  movaps xmm12, [r15+0x140]
000070a59adcf6de  pextrq rax, xmm12, 0x01
000070a59adcf6e5  movq xmm12, rax
000070a59adcf6ea  pmovzxbw xmm12, xmm12
000070a59adcf6f0  psllw xmm12, 0x00
000070a59adcf6f6  movaps [r15+0x110], xmm12
000070a59adcf6fe  movq xmm11, qword ptr [r15+0x150]
000070a59adcf707  pmovzxwd xmm11, xmm11
000070a59adcf70d  pslld xmm11, 0x10
000070a59adcf713  movq xmm10, qword ptr [r15+0x160]
000070a59adcf71c  pmovzxwd xmm10, xmm10
000070a59adcf722  pslld xmm10, 0x08
000070a59adcf728  pextrq rax, xmm1, 0x01
000070a59adcf72f  movq xmm1, rax
000070a59adcf734  pmovzxwd xmm1, xmm1
000070a59adcf739  pslld xmm1, 0x00
000070a59adcf73e  movaps [r15+0x260], xmm1
000070a59adcf746  pextrq rax, xmm15, 0x01
000070a59adcf74d  movq xmm15, rax
000070a59adcf752  pmovzxwd xmm15, xmm15
000070a59adcf758  pslld xmm15, 0x00
000070a59adcf75e  movaps [r15+0x270], xmm15
000070a59adcf766  movq xmm9, qword ptr [r15+0x170]
000070a59adcf76f  pmovzxwd xmm9, xmm9
000070a59adcf775  pslld xmm9, 0x00
000070a59adcf77b  pextrq rax, xmm14, 0x01
000070a59adcf782  movq xmm14, rax
000070a59adcf787  pmovzxwd xmm14, xmm14
000070a59adcf78d  pslld xmm14, 0x10
000070a59adcf793  movaps [r15+0x280], xmm14
000070a59adcf79b  movq xmm8, qword ptr [r15+0x180]
000070a59adcf7a4  pmovzxwd xmm8, xmm8
000070a59adcf7aa  pslld xmm8, 0x00
000070a59adcf7b0  movq xmm7, qword ptr [r15+0x210]
000070a59adcf7b9  pmovzxwd xmm7, xmm7
000070a59adcf7be  pslld xmm7, 0x10
000070a59adcf7c3  movaps xmm6, [r15+0x150]
000070a59adcf7cb  pextrq rax, xmm6, 0x01
000070a59adcf7d2  movq xmm6, rax
000070a59adcf7d7  pmovzxwd xmm6, xmm6
000070a59adcf7dc  pslld xmm6, 0x10
000070a59adcf7e1  por xmm11, xmm10
000070a59adcf7e6  movaps [r15+0x230], xmm11
000070a59adcf7ee  pextrq rax, xmm13, 0x01
000070a59adcf7f5  movq xmm13, rax
000070a59adcf7fa  pmovzxwd xmm13, xmm13
000070a59adcf800  pslld xmm13, 0x08
000070a59adcf806  movaps [r15+0x240], xmm13
000070a59adcf80e  movq xmm10, qword ptr [r15+0x220]
000070a59adcf817  pmovzxwd xmm10, xmm10
000070a59adcf81d  pslld xmm10, 0x08
000070a59adcf823  movaps xmm5, [r15+0x160]
000070a59adcf82b  pextrq rax, xmm5, 0x01
000070a59adcf832  movq xmm5, rax
000070a59adcf837  pmovzxwd xmm5, xmm5
000070a59adcf83c  pslld xmm5, 0x08
000070a59adcf841  pslld xmm9, 0x18
000070a59adcf847  pslld xmm15, 0x18
000070a59adcf84d  pslld xmm8, 0x18
000070a59adcf853  movq xmm4, qword ptr [r15+0x250]
000070a59adcf85c  pmovzxwd xmm4, xmm4
000070a59adcf861  pslld xmm4, 0x00
000070a59adcf866  por xmm14, xmm13
000070a59adcf86b  por xmm7, xmm10
000070a59adcf870  movaps [r15+0x210], xmm7
000070a59adcf878  pslld xmm1, 0x18
000070a59adcf87d  movaps [r15+0x220], xmm1
000070a59adcf885  por xmm6, xmm5
000070a59adcf889  por xmm11, xmm9
000070a59adcf88e  movaps [r15+0x160], xmm11
000070a59adcf896  pextrq rax, xmm12, 0x01
000070a59adcf89d  movq xmm13, rax
000070a59adcf8a2  pmovzxwd xmm13, xmm13
000070a59adcf8a8  pslld xmm13, 0x00
000070a59adcf8ae  movaps [r15+0x170], xmm13
000070a59adcf8b6  movq xmm12, qword ptr [r15+0x110]
000070a59adcf8bf  pmovzxwd xmm12, xmm12
000070a59adcf8c5  pslld xmm12, 0x00
000070a59adcf8cb  por xmm14, xmm15
000070a59adcf8d0  por xmm7, xmm8
000070a59adcf8d5  movaps xmm15, [r15+0x250]
000070a59adcf8dd  pextrq rax, xmm15, 0x01
000070a59adcf8e4  movq xmm15, rax
000070a59adcf8e9  pmovzxwd xmm15, xmm15
000070a59adcf8ef  pslld xmm15, 0x00
000070a59adcf8f5  movaps [r15+0x180], xmm15
000070a59adcf8fd  por xmm6, xmm1
000070a59adcf901  movaps [r15+0x150], xmm6
000070a59adcf909  por xmm11, xmm4
000070a59adcf90e  movaps [r15+0x140], xmm11
000070a59adcf916  por xmm7, xmm12
000070a59adcf91b  movaps [r15+0x110], xmm7
000070a59adcf923  por xmm14, xmm13
000070a59adcf928  movaps [r15+0x120], xmm14
000070a59adcf930  por xmm6, xmm15
000070a59adcf935  movaps [r15+0x130], xmm6
000070a59adcf93d  mov rax, [r15+0xF8]
000070a59adcf944  lea r14, [rax+0x20]
000070a59adcf948  movups [r13+r14*1], xmm7
000070a59adcf94e  lea r14, [rax+0x30]
000070a59adcf952  movups [r13+r14*1], xmm14
000070a59adcf958  movups [r13+rax*1], xmm11
000070a59adcf95e  lea r14, [rax+0x10]
000070a59adcf962  movups [r13+r14*1], xmm6
000070a59adcf968  mov r14d, [r13+rax*1]
000070a59adcf96d  mov rax, [r15+0x48]
000070a59adcf971  mov [r15+0x68], rax
000070a59adcf975  mov qword ptr [r15+0x58], 0x04
000070a59adcf97d  lea r12, [rax+0x04]
000070a59adcf981  mov r11d, [r13+r12*1]
000070a59adcf986  mov [rsp+0x10], r11d
000070a59adcf98b  mov r11d, r11d
000070a59adcf98e  mov [r15+0x70], r11
000070a59adcf992  lea r12, [rax+0x38]
000070a59adcf996  mov r11d, [r13+r12*1]
000070a59adcf99b  lea r12, [rax+0x24]
000070a59adcf99f  mov r10d, [r13+r12*1]
000070a59adcf9a4  mov [rsp+0x20], r10d
000070a59adcf9a9  mov r10d, r10d
000070a59adcf9ac  mov [r15+0x90], r10
000070a59adcf9b3  mov [rsp+0x30], rax
000070a59adcf9b8  xor eax, eax
000070a59adcf9ba  mov r12d, 0x04
000070a59adcf9c0  mov r10d, 0xC0
000070a59adcf9c6  cmp r12, r10
000070a59adcf9c9  cmc
000070a59adcf9ca  lahf
000070a59adcf9cb  seto al
000070a59adcf9ce  mov [r15+0x108], eax
000070a59adcf9d5  mov eax, [rsp+0x10]
000070a59adcf9d9  mov r12d, [rsp+0x10]
000070a59adcf9de  shrd eax, r12d, 0x07
000070a59adcf9e3  mov [rsp+0x10], r11d
000070a59adcf9e8  mov r10d, [rsp+0x10]
000070a59adcf9ed  shrd r11d, r10d, 0x11
000070a59adcf9f2  mov r9d, [rsp+0x20]
000070a59adcf9f7  lea r8d, [r9d+r14d*1]
000070a59adcf9fc  rorx r14d, r12d, 0x12
000070a59adcfa02  xor eax, r14d
000070a59adcfa05  rorx r14d, r10d, 0x13
000070a59adcfa0b  xor r11d, r14d
000070a59adcfa0e  mov [rsp+0x10], r11d
000070a59adcfa13  mov r11d, r11d
000070a59adcfa16  mov [r15+0x88], r11
000070a59adcfa1d  mov [rsp+0x20], r12d
000070a59adcfa22  shr r12d, 0x03
000070a59adcfa26  xor eax, r12d
000070a59adcfa29  mov [rsp+0x40], eax
000070a59adcfa2d  mov eax, eax
000070a59adcfa2f  mov [r15+0x80], rax
000070a59adcfa36  shr r10d, 0x0A
000070a59adcfa3a  mov eax, [rsp+0x10]
000070a59adcfa3e  xor eax, r10d
000070a59adcfa41  mov [rsp+0x10], eax
000070a59adcfa45  mov eax, eax
000070a59adcfa47  mov [r15+0x78], rax
000070a59adcfa4b  mov eax, [rsp+0x40]
000070a59adcfa4f  lea r14d, [r8d+eax*1]
000070a59adcfa54  mov eax, [rsp+0x10]
000070a59adcfa58  lea r12d, [r14d+eax*1]
000070a59adcfa5d  mov rax, [rsp+0x30]
000070a59adcfa62  lea r14, [rax+0x40]
000070a59adcfa66  mov [r13+r14*1], r12d
000070a59adcfa6b  mov eax, [rsp+0x20]
000070a59adcfa6f  mov eax, eax
000070a59adcfa71  mov [r15+0x60], rax
000070a59adcfa75  mov eax, [r15+0x108]
000070a59adcfa7c  sahf
000070a59adcfa7d  jnz 0x000070A59ADCFAAF
000070a59adcfa7f  cmp dword ptr [r15+0x318], 0x00
000070a59adcfa87  jz 0x000070A59ADCFF70
000070a59adcfa8d  nop [rax+rax*1], ax
000070a59adcfa96  nop [rax+rax*1], eax
000070a59adcfa9e  mov eax, 0x410820
000070a59adcfaa3  mov [r15+0x100], rax
000070a59adcfaaa  jmp 0x000070A59ABFE110
000070a59adcfaaf  cmp dword ptr [r15+0x318], 0x00
000070a59adcfab7  jz 0x000070A59ADCFDC0
000070a59adcfabd  nop [rax+rax*1], ax
000070a59adcfac6  nop [rax+rax*1], eax
000070a59adcface  mov eax, 0x4107D8
000070a59adcfad3  mov [r15+0x100], rax
000070a59adcfada  jmp 0x000070A59ABFE110
000070a59adcfadf  int3
000070a59adcfae0  call 0x000070A59AC0D860
000070a59adcfae5  jmp 0x000070A59ADCF17A
000070a59adcfaea  call 0x000070A59ACE2420
000070a59adcfaef  jmp 0x000070A59ADCF193
000070a59adcfaf4  call 0x000070A59ACE2420
000070a59adcfaf9  jmp 0x000070A59ADCF1AC
000070a59adcfafe  call 0x000070A59ACE2420
000070a59adcfb03  jmp 0x000070A59ADCF1C5
000070a59adcfb08  call 0x000070A59ACE2420
000070a59adcfb0d  jmp 0x000070A59ADCF1DE
000070a59adcfb12  call 0x000070A59ACE2420
000070a59adcfb17  jmp 0x000070A59ADCF1EF
000070a59adcfb1c  call 0x000070A59ACE2420
000070a59adcfb21  jmp 0x000070A59ADCF200
000070a59adcfb26  call 0x000070A59ACE2420
000070a59adcfb2b  jmp 0x000070A59ADCF211
000070a59adcfb30  call 0x000070A59ACE2420
000070a59adcfb35  jmp 0x000070A59ADCF222
000070a59adcfb3a  call 0x000070A59ACE2420
000070a59adcfb3f  jmp 0x000070A59ADCF233
000070a59adcfb44  call 0x000070A59ACE2420
000070a59adcfb49  jmp 0x000070A59ADCF244
000070a59adcfb4e  call 0x000070A59ACE2420
000070a59adcfb53  jmp 0x000070A59ADCF255
000070a59adcfb58  call 0x000070A59ACE2420
000070a59adcfb5d  jmp 0x000070A59ADCF266
000070a59adcfb62  call 0x000070A59ACE2420
000070a59adcfb67  jmp 0x000070A59ADCF277
000070a59adcfb6c  call 0x000070A59ACE2420
000070a59adcfb71  jmp 0x000070A59ADCF288
000070a59adcfb76  call 0x000070A59ACE2420
000070a59adcfb7b  jmp 0x000070A59ADCF299
000070a59adcfb80  call 0x000070A59ACE2420
000070a59adcfb85  jmp 0x000070A59ADCF2AA
000070a59adcfb8a  call 0x000070A59ACE2420
000070a59adcfb8f  jmp 0x000070A59ADCF2BB
000070a59adcfb94  call 0x000070A59ACE2420
000070a59adcfb99  jmp 0x000070A59ADCF2CC
000070a59adcfb9e  call 0x000070A59ACE2420
000070a59adcfba3  jmp 0x000070A59ADCF2DD
000070a59adcfba8  call 0x000070A59ACE2420
000070a59adcfbad  jmp 0x000070A59ADCF2EE
000070a59adcfbb2  call 0x000070A59ACE2420
000070a59adcfbb7  jmp 0x000070A59ADCF2FF
000070a59adcfbbc  call 0x000070A59ACE2420
000070a59adcfbc1  jmp 0x000070A59ADCF310
000070a59adcfbc6  call 0x000070A59ACE2420
000070a59adcfbcb  jmp 0x000070A59ADCF321
000070a59adcfbd0  call 0x000070A59ACE2420
000070a59adcfbd5  jmp 0x000070A59ADCF332
000070a59adcfbda  call 0x000070A59ACE2420
000070a59adcfbdf  jmp 0x000070A59ADCF343
000070a59adcfbe4  call 0x000070A59ACE2420
000070a59adcfbe9  jmp 0x000070A59ADCF354
000070a59adcfbee  call 0x000070A59ACE2420
000070a59adcfbf3  jmp 0x000070A59ADCF365
000070a59adcfbf8  call 0x000070A59ACE2420
000070a59adcfbfd  jmp 0x000070A59ADCF376
000070a59adcfc02  call 0x000070A59ACE2420
000070a59adcfc07  jmp 0x000070A59ADCF387
000070a59adcfc0c  call 0x000070A59ACE2420
000070a59adcfc11  jmp 0x000070A59ADCF398
000070a59adcfc16  call 0x000070A59ACE2420
000070a59adcfc1b  jmp 0x000070A59ADCF3A9
000070a59adcfc20  call 0x000070A59ACE2420
000070a59adcfc25  jmp 0x000070A59ADCF3BA
000070a59adcfc2a  call 0x000070A59ACE2420
000070a59adcfc2f  jmp 0x000070A59ADCF3CB
000070a59adcfc34  call 0x000070A59ACE2420
000070a59adcfc39  jmp 0x000070A59ADCF3DC
000070a59adcfc3e  call 0x000070A59ACE2420
000070a59adcfc43  jmp 0x000070A59ADCF3ED
000070a59adcfc48  call 0x000070A59ACE2420
000070a59adcfc4d  jmp 0x000070A59ADCF3FE
000070a59adcfc52  call 0x000070A59ACE2420
000070a59adcfc57  jmp 0x000070A59ADCF40F
000070a59adcfc5c  call 0x000070A59ACE2420
000070a59adcfc61  jmp 0x000070A59ADCF420
000070a59adcfc66  call 0x000070A59ACE2420
000070a59adcfc6b  jmp 0x000070A59ADCF431
000070a59adcfc70  call 0x000070A59ACE2420
000070a59adcfc75  jmp 0x000070A59ADCF442
000070a59adcfc7a  call 0x000070A59ACE2420
000070a59adcfc7f  jmp 0x000070A59ADCF453
000070a59adcfc84  call 0x000070A59ACE2420
000070a59adcfc89  jmp 0x000070A59ADCF464
000070a59adcfc8e  call 0x000070A59ACE2420
000070a59adcfc93  jmp 0x000070A59ADCF475
000070a59adcfc98  call 0x000070A59ACE2420
000070a59adcfc9d  jmp 0x000070A59ADCF486
000070a59adcfca2  call 0x000070A59ACE2420
000070a59adcfca7  jmp 0x000070A59ADCF497
000070a59adcfcac  call 0x000070A59ACE2420
000070a59adcfcb1  jmp 0x000070A59ADCF4A8
000070a59adcfcb6  call 0x000070A59ACE2420
000070a59adcfcbb  jmp 0x000070A59ADCF4B9
000070a59adcfcc0  call 0x000070A59ACE2420
000070a59adcfcc5  jmp 0x000070A59ADCF4CA
000070a59adcfcca  call 0x000070A59ACE2420
000070a59adcfccf  jmp 0x000070A59ADCF4DB
000070a59adcfcd4  call 0x000070A59ACE2420
000070a59adcfcd9  jmp 0x000070A59ADCF4EC
000070a59adcfcde  call 0x000070A59ACE2420
000070a59adcfce3  jmp 0x000070A59ADCF4FD
000070a59adcfce8  call 0x000070A59ACE2420
000070a59adcfced  jmp 0x000070A59ADCF50E
000070a59adcfcf2  call 0x000070A59ACE2420
000070a59adcfcf7  jmp 0x000070A59ADCF51F
000070a59adcfcfc  call 0x000070A59ACE2420
000070a59adcfd01  jmp 0x000070A59ADCF530
000070a59adcfd06  call 0x000070A59ACE2420
000070a59adcfd0b  jmp 0x000070A59ADCF541
000070a59adcfd10  call 0x000070A59ACE2420
000070a59adcfd15  jmp 0x000070A59ADCF552
000070a59adcfd1a  call 0x000070A59ACE2420
000070a59adcfd1f  jmp 0x000070A59ADCF563
000070a59adcfd24  call 0x000070A59ACE2420
000070a59adcfd29  jmp 0x000070A59ADCF574
000070a59adcfd2e  call 0x000070A59ACE2420
000070a59adcfd33  jmp 0x000070A59ADCF585
000070a59adcfd38  call 0x000070A59ACE2420
000070a59adcfd3d  jmp 0x000070A59ADCF596
000070a59adcfd42  call 0x000070A59ACE2420
000070a59adcfd47  jmp 0x000070A59ADCF5AF
000070a59adcfd4c  call 0x000070A59ACE2420
000070a59adcfd51  jmp 0x000070A59ADCF5C8
000070a59adcfd56  call 0x000070A59ACD5610
000070a59adcfd5b  jmp 0x000070A59ADCF5E1
000070a59adcfd60  call 0x000070A59ACDC580
000070a59adcfd65  jmp 0x000070A59ADCF94E
000070a59adcfd6a  call 0x000070A59ACE46C0
000070a59adcfd6f  jmp 0x000070A59ADCF958
000070a59adcfd74  call 0x000070A59AC09E90
000070a59adcfd79  jmp 0x000070A59ADCF95E
000070a59adcfd7e  call 0x000070A59ACDB310
000070a59adcfd83  jmp 0x000070A59ADCF968
000070a59adcfd88  call 0x000070A59AC0DAE0
000070a59adcfd8d  jmp 0x000070A59ADCF96D
000070a59adcfd92  call 0x000070A59ACC0230
000070a59adcfd97  jmp 0x000070A59ADCF986
000070a59adcfd9c  call 0x000070A59ACC0230
000070a59adcfda1  jmp 0x000070A59ADCF99B
000070a59adcfda6  call 0x000070A59ACBEFC0
000070a59adcfdab  jmp 0x000070A59ADCF9A4
000070a59adcfdb0  call 0x000070A59ACE2BA0
000070a59adcfdb5  jmp 0x000070A59ADCFA6B
000070a59adcfdba  int3
000070a59adcfdbb  nop [rax+rax*1], eax
000070a59adcfdc0  mov rax, [r15+0x48]
000070a59adcfdc4  mov r14, [r15+0x58]
000070a59adcfdc8  lea r12, [rax+r14*1]
000070a59adcfdcc  mov [r15+0x68], r12
000070a59adcfdd0  lea rax, [r14+0x04]
000070a59adcfdd4  mov [r15+0x58], rax
000070a59adcfdd8  lea r14, [r12+0x04]
000070a59adcfddd  mov r11d, [r13+r14*1]
000070a59adcfde2  mov [rsp+0x10], r11d
000070a59adcfde7  mov r11d, r11d
000070a59adcfdea  mov [r15+0x70], r11
000070a59adcfdee  lea r14, [r12+0x38]
000070a59adcfdf3  mov r11d, [r13+r14*1]
000070a59adcfdf8  lea r14, [r12+0x24]
000070a59adcfdfd  mov r10d, [r13+r14*1]
000070a59adcfe02  mov [rsp+0x20], r10d
000070a59adcfe07  mov r10d, r10d
000070a59adcfe0a  mov [r15+0x90], r10
000070a59adcfe11  mov [rsp+0x30], rax
000070a59adcfe16  xor eax, eax
000070a59adcfe18  mov r14, [rsp+0x30]
000070a59adcfe1d  mov r10d, 0xC0
000070a59adcfe23  cmp r14, r10
000070a59adcfe26  cmc
000070a59adcfe27  lahf
000070a59adcfe28  seto al
000070a59adcfe2b  mov [r15+0x108], eax
000070a59adcfe32  mov eax, [rsp+0x10]
000070a59adcfe36  mov r14d, [rsp+0x10]
000070a59adcfe3b  shrd eax, r14d, 0x07
000070a59adcfe40  mov [rsp+0x10], r11d
000070a59adcfe45  mov r10d, [rsp+0x10]
000070a59adcfe4a  shrd r11d, r10d, 0x11
000070a59adcfe4f  mov r9d, [r15+0x60]
000070a59adcfe53  mov r8d, [rsp+0x20]
000070a59adcfe58  lea ebp, [r8d+r9d*1]
000070a59adcfe5d  rorx r9d, r14d, 0x12
000070a59adcfe63  xor eax, r9d
000070a59adcfe66  rorx r9d, r10d, 0x13
000070a59adcfe6c  xor r11d, r9d
000070a59adcfe6f  mov [rsp+0x10], r11d
000070a59adcfe74  mov r11d, r11d
000070a59adcfe77  mov [r15+0x88], r11
000070a59adcfe7e  mov [rsp+0x20], r14d
000070a59adcfe83  shr r14d, 0x03
000070a59adcfe87  xor eax, r14d
000070a59adcfe8a  mov [rsp+0x30], eax
000070a59adcfe8e  mov eax, eax
000070a59adcfe90  mov [r15+0x80], rax
000070a59adcfe97  shr r10d, 0x0A
000070a59adcfe9b  mov eax, [rsp+0x10]
000070a59adcfe9f  xor eax, r10d
000070a59adcfea2  mov [rsp+0x10], eax
000070a59adcfea6  mov eax, eax
000070a59adcfea8  mov [r15+0x78], rax
000070a59adcfeac  mov eax, [rsp+0x30]
000070a59adcfeb0  lea r14d, [ebp+eax*1]
000070a59adcfeb6  mov eax, [rsp+0x10]
000070a59adcfeba  lea r11d, [r14d+eax*1]
000070a59adcfebf  lea rax, [r12+0x40]
000070a59adcfec4  mov [r13+rax*1], r11d
000070a59adcfec9  mov eax, [rsp+0x20]
000070a59adcfecd  mov eax, eax
000070a59adcfecf  mov [r15+0x60], rax
000070a59adcfed3  mov eax, [r15+0x108]
000070a59adcfeda  sahf
000070a59adcfedb  jnz 0x000070A59ADCFF0D
000070a59adcfedd  cmp dword ptr [r15+0x318], 0x00
000070a59adcfee5  jz 0x000070A59ADCFF70
000070a59adcfeeb  nop [rax+rax*1], ax
000070a59adcfef4  nop [rax+rax*1], eax
000070a59adcfefc  mov eax, 0x410820
000070a59adcff01  mov [r15+0x100], rax
000070a59adcff08  jmp 0x000070A59ABFE110
000070a59adcff0d  cmp dword ptr [r15+0x318], 0x00
000070a59adcff15  jz 0x000070A59ADCFDC0
000070a59adcff1b  nop [rax+rax*1], ax
000070a59adcff24  nop [rax+rax*1], eax
000070a59adcff2c  mov eax, 0x4107D8
000070a59adcff31  mov [r15+0x100], rax
000070a59adcff38  jmp 0x000070A59ABFE110
000070a59adcff3d  int3
000070a59adcff3e  call 0x000070A59ACE1430
000070a59adcff43  jmp 0x000070A59ADCFDE2
000070a59adcff48  call 0x000070A59ACE1430
000070a59adcff4d  jmp 0x000070A59ADCFDF8
000070a59adcff52  call 0x000070A59ACE01C0
000070a59adcff57  jmp 0x000070A59ADCFE02
000070a59adcff5c  call 0x000070A59AC0A860
000070a59adcff61  jmp 0x000070A59ADCFEC9
000070a59adcff66  int3
000070a59adcff67  nop [rax+rax*1], ax
000070a59adcff70  mov rax, [r15]
000070a59adcff73  mov r14d, [r13+rax*1]
000070a59adcff78  lea r12, [rax+0x04]
000070a59adcff7c  mov r11d, [r13+r12*1]
000070a59adcff81  mov [rsp+0x10], r14d
000070a59adcff86  mov r14d, r14d
000070a59adcff89  mov [r15+0x78], r14
000070a59adcff8d  mov [rsp+0x20], r11d
000070a59adcff92  mov r11d, r11d
000070a59adcff95  mov [r15+0x80], r11
000070a59adcff9c  lea r14, [rax+0x08]
000070a59adcffa0  mov r12d, [r13+r14*1]
000070a59adcffa5  lea r14, [rax+0x0C]
000070a59adcffa9  mov r11d, [r13+r14*1]
000070a59adcffae  mov [rsp+0x30], r12d
000070a59adcffb3  mov r12d, r12d
000070a59adcffb6  mov [r15+0x70], r12
000070a59adcffba  mov [rsp+0x40], r11d
000070a59adcffbf  mov r11d, r11d
000070a59adcffc2  mov [r15+0x68], r11
000070a59adcffc6  lea r14, [rax+0x18]
000070a59adcffca  mov r12d, [r13+r14*1]
000070a59adcffcf  lea r14, [rax+0x1C]
000070a59adcffd3  mov r11d, [r13+r14*1]
000070a59adcffd8  mov [rsp+0x50], r12d
000070a59adcffdd  mov r12d, r12d
000070a59adcffe0  mov [r15+0x58], r12
000070a59adcffe4  mov [rsp+0x60], r11d
000070a59adcffe9  mov r11d, r11d
000070a59adcffec  mov [r15+0x60], r11
000070a59adcfff0  lea r14, [rax+0x10]
000070a59adcfff4  mov r12d, [r13+r14*1]
000070a59adcfff9  lea r14, [rax+0x14]
000070a59adcfffd  mov eax, [r13+r14*1]
000070a59add0002  mov [rsp+0x70], r12d
000070a59add0007  mov r12d, r12d
000070a59add000a  mov [r15+0x18], r12
000070a59add000e  mov [rsp+0x80], eax
000070a59add0015  mov eax, eax
000070a59add0017  mov [r15+0x90], rax
000070a59add001e  mov eax, [rsp+0x70]
000070a59add0022  mov eax, eax
000070a59add0024  mov [r15+0x30], rax
000070a59add0028  mov eax, [rsp+0x50]
000070a59add002c  mov eax, eax
000070a59add002e  mov [r15+0xA0], rax
000070a59add0035  mov eax, [rsp+0x30]
000070a59add0039  mov eax, eax
000070a59add003b  mov [r15+0x28], rax
000070a59add003f  mov eax, [rsp+0x20]
000070a59add0043  mov eax, eax
000070a59add0045  mov [r15+0x98], rax
000070a59add004c  mov eax, [rsp+0x10]
000070a59add0050  mov eax, eax
000070a59add0052  mov [r15+0x38], rax
000070a59add0056  mov eax, [rsp+0x70]
000070a59add005a  mov r14d, [rsp+0x70]
000070a59add005f  shrd eax, r14d, 0x06
000070a59add0064  mov [rsp+0x70], r14d
000070a59add0069  mov r12d, [rsp+0x80]
000070a59add0071  and r14d, r12d
000070a59add0074  mov r11d, [rsp+0x10]
000070a59add0079  mov r10d, [rsp+0x10]
000070a59add007e  shrd r11d, r10d, 0x02
000070a59add0083  mov [rsp+0x10], r12d
000070a59add0088  mov r12d, r12d
000070a59add008b  mov [r15+0x20], r12
000070a59add008f  mov r12, [r15+0x50]
000070a59add0093  mov r9d, [r13+r12*1]
000070a59add0098  mov r12d, [rsp+0x50]
000070a59add009d  mov r8d, [rsp+0x70]
000070a59add00a2  andn ebp, r8d, r12d
000070a59add00a7  mov edi, [rsp+0x60]
000070a59add00ab  lea esi, [r14d+edi*1]
000070a59add00b0  rorx r14d, r8d, 0x0B
000070a59add00b6  xor eax, r14d
000070a59add00b9  rorx r14d, r10d, 0x0D
000070a59add00bf  xor r11d, r14d
000070a59add00c2  lea edi, [esi+ebp*1]
000070a59add00c6  mov r14, [r15+0x48]
000070a59add00ca  mov ebp, [r13+r14*1]
000070a59add00cf  mov r14d, [rsp+0x30]
000070a59add00d4  mov esi, [rsp+0x20]
000070a59add00d8  and r14d, esi
000070a59add00db  mov [rsp+0x20], r14d
000070a59add00e0  mov r14d, r14d
000070a59add00e3  mov [r15+0xD8], r14
000070a59add00ea  lea r14d, [edi+r9d*1]
000070a59add00ef  mov r9d, [rsp+0x30]
000070a59add00f4  xor r9d, esi
000070a59add00f7  rorx edi, r8d, 0x19
000070a59add00fd  xor eax, edi
000070a59add00ff  and r9d, r10d
000070a59add0102  rorx edi, r10d, 0x16
000070a59add0108  xor r11d, edi
000070a59add010b  mov [rsp+0x30], r11d
000070a59add0110  mov r11d, r11d
000070a59add0113  mov [r15+0xD0], r11
000070a59add011a  lea r11d, [r14d+ebp*1]
000070a59add011f  mov r10d, [rsp+0x20]
000070a59add0124  xor r9d, r10d
000070a59add0127  lea r14d, [r11d+eax*1]
000070a59add012c  mov qword ptr [r15+0x88], 0x04
000070a59add0137  mov eax, [rsp+0x30]
000070a59add013b  lea r11d, [r9d+eax*1]
000070a59add0140  mov eax, [rsp+0x40]
000070a59add0144  lea r10d, [r14d+eax*1]
000070a59add0149  mov r10d, r10d
000070a59add014c  mov [r15+0xB8], r10
000070a59add0153  xor eax, eax
000070a59add0155  mov r10d, 0x04
000070a59add015b  mov r9d, 0x100
000070a59add0161  cmp r10, r9
000070a59add0164  cmc
000070a59add0165  lahf
000070a59add0166  seto al
000070a59add0169  mov [r15+0x108], eax
000070a59add0170  lea eax, [r11d+r14d*1]
000070a59add0175  mov eax, eax
000070a59add0177  mov [r15+0xA8], rax
000070a59add017e  mov r12d, r12d
000070a59add0181  mov [r15+0xB0], r12
000070a59add0188  mov eax, [rsp+0x10]
000070a59add018c  mov eax, eax
000070a59add018e  mov [r15+0xC0], rax
000070a59add0195  mov r8d, r8d
000070a59add0198  mov [r15+0xC8], r8
000070a59add019f  mov eax, [r15+0x108]
000070a59add01a6  sahf
000070a59add01a7  jnz 0x000070A59ADD01D9
000070a59add01a9  cmp dword ptr [r15+0x318], 0x00
000070a59add01b1  jz 0x000070A59ADD04A0
000070a59add01b7  nop [rax+rax*1], ax
000070a59add01c0  nop [rax+rax*1], eax
000070a59add01c8  mov eax, 0x4108E0
000070a59add01cd  mov [r15+0x100], rax
000070a59add01d4  jmp 0x000070A59ABFE110
000070a59add01d9  cmp dword ptr [r15+0x318], 0x00
000070a59add01e1  jz 0x000070A59ADD0270
000070a59add01e7  nop [rax+rax*1], ax
000070a59add01f0  nop [rax+rax*1], eax
000070a59add01f8  mov eax, 0x410854
000070a59add01fd  mov [r15+0x100], rax
000070a59add0204  jmp 0x000070A59ABFE110
000070a59add0209  int3
000070a59add020a  call 0x000070A59AC0DAE0
000070a59add020f  jmp 0x000070A59ADCFF78
000070a59add0214  call 0x000070A59ACC0230
000070a59add0219  jmp 0x000070A59ADCFF81
000070a59add021e  call 0x000070A59ACE26A0
000070a59add0223  jmp 0x000070A59ADCFFA5
000070a59add0228  call 0x000070A59ACE1430
000070a59add022d  jmp 0x000070A59ADCFFAE
000070a59add0232  call 0x000070A59ACE26A0
000070a59add0237  jmp 0x000070A59ADCFFCF
000070a59add023c  call 0x000070A59ACE1430
000070a59add0241  jmp 0x000070A59ADCFFD8
000070a59add0246  call 0x000070A59ACE26A0
000070a59add024b  jmp 0x000070A59ADCFFF9
000070a59add0250  call 0x000070A59ACD5890
000070a59add0255  jmp 0x000070A59ADD0002
000070a59add025a  call 0x000070A59ACBDD50
000070a59add025f  jmp 0x000070A59ADD0098
000070a59add0264  call 0x000070A59ACDA580
000070a59add0269  jmp 0x000070A59ADD00CF
000070a59add026e  int3
000070a59add026f  nop
000070a59add0270  mov eax, [r15+0xB8]
000070a59add0277  mov [rsp+0x10], eax
000070a59add027b  mov eax, eax
000070a59add027d  mov [r15+0x30], rax
000070a59add0281  mov eax, [r15+0xC0]
000070a59add0288  mov [rsp+0x20], eax
000070a59add028c  mov eax, eax
000070a59add028e  mov [r15+0xA0], rax
000070a59add0295  mov eax, [r15+0x28]
000070a59add0299  mov r14d, [r15+0x98]
000070a59add02a0  mov [rsp+0x30], r14d
000070a59add02a5  mov r14d, r14d
000070a59add02a8  mov [r15+0x28], r14
000070a59add02ac  mov r14d, [r15+0x38]
000070a59add02b0  mov [rsp+0x40], r14d
000070a59add02b5  mov r14d, r14d
000070a59add02b8  mov [r15+0x98], r14
000070a59add02bf  mov r14d, [r15+0xA8]
000070a59add02c6  mov [rsp+0x50], r14d
000070a59add02cb  mov r14d, r14d
000070a59add02ce  mov [r15+0x38], r14
000070a59add02d2  mov r14d, [rsp+0x10]
000070a59add02d7  mov r12d, [rsp+0x10]
000070a59add02dc  shrd r14d, r12d, 0x06
000070a59add02e1  mov r11d, [r15+0xC8]
000070a59add02e8  mov [rsp+0x10], r12d
000070a59add02ed  and r12d, r11d
000070a59add02f0  mov r10d, [rsp+0x50]
000070a59add02f5  mov r9d, [rsp+0x50]
000070a59add02fa  shrd r10d, r9d, 0x02
000070a59add02ff  mov [rsp+0x50], r11d
000070a59add0304  mov r11d, r11d
000070a59add0307  mov [r15+0x20], r11
000070a59add030b  mov r11, [r15+0x88]
000070a59add0312  mov r8, [r15+0x50]
000070a59add0316  lea rbp, [r8+r11*1]
000070a59add031a  mov r8d, [r13+rbp*1]
000070a59add031f  mov ebp, [rsp+0x20]
000070a59add0323  mov edi, [rsp+0x10]
000070a59add0327  andn esi, edi, ebp
000070a59add032c  mov edx, [r15+0xB0]
000070a59add0333  lea ecx, [r12d+edx*1]
000070a59add0338  rorx r12d, edi, 0x0B
000070a59add033e  xor r14d, r12d
000070a59add0341  rorx r12d, r9d, 0x0D
000070a59add0347  xor r10d, r12d
000070a59add034a  lea r12d, [ecx+esi*1]
000070a59add034f  mov rsi, [r15+0x48]
000070a59add0353  lea rdx, [rsi+r11*1]
000070a59add0357  mov esi, [r13+rdx*1]
000070a59add035c  mov edx, [rsp+0x30]
000070a59add0360  mov ecx, [rsp+0x40]
000070a59add0364  and edx, ecx
000070a59add0366  mov [rsp+0x10], edx
000070a59add036a  mov edx, edx
000070a59add036c  mov [r15+0xD8], rdx
000070a59add0373  lea edx, [r12d+r8d*1]
000070a59add0378  mov r12d, [rsp+0x30]
000070a59add037d  xor r12d, ecx
000070a59add0380  rorx r8d, edi, 0x19
000070a59add0386  xor r14d, r8d
000070a59add0389  and r12d, r9d
000070a59add038c  rorx r8d, r9d, 0x16
000070a59add0392  xor r10d, r8d
000070a59add0395  mov [rsp+0x20], r10d
000070a59add039a  mov r10d, r10d
000070a59add039d  mov [r15+0xD0], r10
000070a59add03a4  lea r10d, [edx+esi*1]
000070a59add03a9  mov r9d, [rsp+0x10]
000070a59add03ae  xor r12d, r9d
000070a59add03b1  lea r9d, [r10d+r14d*1]
000070a59add03b6  lea r14, [r11+0x04]
000070a59add03ba  mov [r15+0x88], r14
000070a59add03c1  mov r11d, [rsp+0x20]
000070a59add03c6  lea r10d, [r12d+r11d*1]
000070a59add03cb  lea r11d, [r9d+eax*1]
000070a59add03d0  mov r11d, r11d
000070a59add03d3  mov [r15+0xB8], r11
000070a59add03da  xor eax, eax
000070a59add03dc  mov r12d, 0x100
000070a59add03e2  cmp r14, r12
000070a59add03e5  cmc
000070a59add03e6  lahf
000070a59add03e7  seto al
000070a59add03ea  mov [r15+0x108], eax
000070a59add03f1  lea eax, [r10d+r9d*1]
000070a59add03f6  mov eax, eax
000070a59add03f8  mov [r15+0xA8], rax
000070a59add03ff  mov ebp, ebp
000070a59add0401  mov [r15+0xB0], rbp
000070a59add0408  mov eax, [rsp+0x50]
000070a59add040c  mov eax, eax
000070a59add040e  mov [r15+0xC0], rax
000070a59add0415  mov edi, edi
000070a59add0417  mov [r15+0xC8], rdi
000070a59add041e  mov eax, [r15+0x108]
000070a59add0425  sahf
000070a59add0426  jnz 0x000070A59ADD0458
000070a59add0428  cmp dword ptr [r15+0x318], 0x00
000070a59add0430  jz 0x000070A59ADD04A0
000070a59add0436  nop [rax+rax*1], ax
000070a59add043f  nop [rax+rax*1], eax
000070a59add0447  mov eax, 0x4108E0
000070a59add044c  mov [r15+0x100], rax
000070a59add0453  jmp 0x000070A59ABFE110
000070a59add0458  cmp dword ptr [r15+0x318], 0x00
000070a59add0460  jz 0x000070A59ADD0270
000070a59add0466  nop [rax+rax*1], ax
000070a59add046f  nop [rax+rax*1], eax
000070a59add0477  mov eax, 0x410854
000070a59add047c  mov [r15+0x100], rax
000070a59add0483  jmp 0x000070A59ABFE110
000070a59add0488  int3
000070a59add0489  call 0x000070A59AC49010
000070a59add048e  jmp 0x000070A59ADD031F
000070a59add0493  call 0x000070A59AC25930
000070a59add0498  jmp 0x000070A59ADD035C
000070a59add049d  int3
000070a59add049e  nop
000070a59add04a0  mov eax, [r15+0x98]
000070a59add04a7  mov r14d, [r15+0x70]
000070a59add04ab  lea r12d, [eax+r14d*1]
000070a59add04b0  mov eax, [r15+0x28]
000070a59add04b4  mov r14d, [r15+0x68]
000070a59add04b8  lea r11d, [eax+r14d*1]
000070a59add04bd  mov qword ptr [r15+0x88], 0x00
000070a59add04c8  mov eax, [r15+0xA8]
000070a59add04cf  mov r14d, [r15+0x78]
000070a59add04d3  lea r10d, [eax+r14d*1]
000070a59add04d8  mov [rsp+0x10], r10d
000070a59add04dd  mov r10d, r10d
000070a59add04e0  mov [r15+0x78], r10
000070a59add04e4  mov eax, [r15+0x38]
000070a59add04e8  mov r14d, [r15+0x80]
000070a59add04ef  lea r10d, [eax+r14d*1]
000070a59add04f4  mov [rsp+0x20], r10d
000070a59add04f9  mov r10d, r10d
000070a59add04fc  mov [r15+0x80], r10
000070a59add0503  mov rax, [r15]
000070a59add0506  lea r14, [rax+0x08]
000070a59add050a  mov [r13+r14*1], r12d
000070a59add050f  lea r14, [rax+0x0C]
000070a59add0513  mov [r13+r14*1], r11d
000070a59add0518  mov r14d, [r15+0xB8]
000070a59add051f  mov r12d, [r15+0x18]
000070a59add0523  lea r11d, [r14d+r12d*1]
000070a59add0528  mov [rsp+0x30], r11d
000070a59add052d  mov r11d, r11d
000070a59add0530  mov [r15+0x68], r11
000070a59add0534  mov r14d, [r15+0x30]
000070a59add0538  mov r12d, [r15+0x90]
000070a59add053f  lea r11d, [r14d+r12d*1]
000070a59add0544  mov [rsp+0x40], r11d
000070a59add0549  mov r11d, r11d
000070a59add054c  mov [r15+0x70], r11
000070a59add0550  mov r14d, [r15+0x20]
000070a59add0554  mov r12d, [r15+0x58]
000070a59add0558  lea r11d, [r14d+r12d*1]
000070a59add055d  mov [rsp+0x50], r11d
000070a59add0562  mov r11d, r11d
000070a59add0565  mov [r15+0x58], r11
000070a59add0569  mov r14d, [r15+0xA0]
000070a59add0570  mov r12d, [r15+0x60]
000070a59add0574  lea r11d, [r14d+r12d*1]
000070a59add0579  mov [rsp+0x60], r11d
000070a59add057e  mov r11d, r11d
000070a59add0581  mov [r15+0x60], r11
000070a59add0585  mov r14d, [rsp+0x10]
000070a59add058a  mov [r13+rax*1], r14d
000070a59add058f  lea r14, [rax+0x04]
000070a59add0593  mov r12d, [rsp+0x20]
000070a59add0598  mov [r13+r14*1], r12d
000070a59add059d  lea r14, [rax+0x10]
000070a59add05a1  mov r12d, [rsp+0x30]
000070a59add05a6  mov [r13+r14*1], r12d
000070a59add05ab  lea r14, [rax+0x14]
000070a59add05af  mov r12d, [rsp+0x40]
000070a59add05b4  mov [r13+r14*1], r12d
000070a59add05b9  lea r14, [rax+0x18]
000070a59add05bd  mov r12d, [rsp+0x50]
000070a59add05c2  mov [r13+r14*1], r12d
000070a59add05c7  lea r14, [rax+0x1C]
000070a59add05cb  mov r12d, [rsp+0x60]
000070a59add05d0  mov [r13+r14*1], r12d
000070a59add05d5  lea r14, [rax+0x68]
000070a59add05d9  xor eax, eax
000070a59add05db  mov [r13+r14*1], rax
000070a59add05e0  cmp dword ptr [r15+0x318], 0x00
000070a59add05e8  jz 0x000070A59ADCF0E0
000070a59add05ee  nop [rax+rax*1], ax
000070a59add05f7  nop [rax+rax*1], eax
000070a59add05ff  mov eax, 0x4106FC
000070a59add0604  mov [r15+0x100], rax
000070a59add060b  jmp 0x000070A59ABFE110
000070a59add0610  int3
000070a59add0611  call 0x000070A59ACE2BA0
000070a59add0616  jmp 0x000070A59ADD050F
000070a59add061b  call 0x000070A59ACE1920
000070a59add0620  jmp 0x000070A59ADD0518
000070a59add0625  call 0x000070A59AC0DFE0
000070a59add062a  jmp 0x000070A59ADD058F
000070a59add062f  call 0x000070A59ACE2BA0
000070a59add0634  jmp 0x000070A59ADD059D
000070a59add0639  call 0x000070A59ACE2BA0
000070a59add063e  jmp 0x000070A59ADD05AB
000070a59add0643  call 0x000070A59ACE2BA0
000070a59add0648  jmp 0x000070A59ADD05B9
000070a59add064d  call 0x000070A59ACE2BA0
000070a59add0652  jmp 0x000070A59ADD05C7
000070a59add0657  call 0x000070A59ACE2BA0
000070a59add065c  jmp 0x000070A59ADD05D5
000070a59add0661  call 0x000070A59ACD5EB0
000070a59add0666  jmp 0x000070A59ADD05E0
000070a59add066b  int3
000070a59add066c  nop [rax], eax
000070a59add0670  mov rax, [r15+0xF8]
000070a59add0677  lea r14, [rax+0x140]
000070a59add067e  mov r12, [r13+r14*1]
000070a59add0683  lea r14, [rax+0x148]
000070a59add068a  mov r11, [r13+r14*1]
000070a59add068f  mov [r15+0xA0], r12
000070a59add0696  mov [r15+0x98], r11
000070a59add069d  lea r14, [rax+0x130]
000070a59add06a4  mov r12, [r13+r14*1]
000070a59add06a9  lea r14, [rax+0x138]
000070a59add06b0  mov r11, [r13+r14*1]
000070a59add06b5  mov [r15+0xB0], r12
000070a59add06bc  mov [r15+0xA8], r11
000070a59add06c3  lea r14, [rax+0x120]
000070a59add06ca  mov r12, [r13+r14*1]
000070a59add06cf  lea r14, [rax+0x128]
000070a59add06d6  mov r11, [r13+r14*1]
000070a59add06db  mov [r15+0xC0], r12
000070a59add06e2  mov [r15+0xB8], r11
000070a59add06e9  lea r14, [rax+0x110]
000070a59add06f0  mov r12, [r13+r14*1]
000070a59add06f5  lea r14, [rax+0x118]
000070a59add06fc  mov r11, [r13+r14*1]
000070a59add0701  mov [r15+0xD0], r12
000070a59add0708  mov [r15+0xC8], r11
000070a59add070f  lea r14, [rax+0x100]
000070a59add0716  mov r12, [r13+r14*1]
000070a59add071b  lea r14, [rax+0x108]
000070a59add0722  mov r11, [r13+r14*1]
000070a59add0727  mov [r15+0xE8], r12
000070a59add072e  mov [r15+0xD8], r11
000070a59add0735  lea r14, [rax+0x150]
000070a59add073c  mov [r15+0xF8], r14
000070a59add0743  mov rax, [r15+0xF0]
000070a59add074a  mov [r15+0x100], rax
000070a59add0751  jmp 0x000070A59ADCE5C0
000070a59add0756  int3
000070a59add0757  call 0x000070A59ACE27E0
000070a59add075c  jmp 0x000070A59ADD0683
000070a59add0761  call 0x000070A59ACE1570
000070a59add0766  jmp 0x000070A59ADD068F
000070a59add076b  call 0x000070A59ACE27E0
000070a59add0770  jmp 0x000070A59ADD06A9
000070a59add0775  call 0x000070A59ACE1570
000070a59add077a  jmp 0x000070A59ADD06B5
000070a59add077f  call 0x000070A59ACE27E0
000070a59add0784  jmp 0x000070A59ADD06CF
000070a59add0789  call 0x000070A59ACE1570
000070a59add078e  jmp 0x000070A59ADD06DB
000070a59add0793  call 0x000070A59ACE27E0
000070a59add0798  jmp 0x000070A59ADD06F5
000070a59add079d  call 0x000070A59ACE1570
000070a59add07a2  jmp 0x000070A59ADD0701
000070a59add07a7  call 0x000070A59ACE27E0
000070a59add07ac  jmp 0x000070A59ADD071B
000070a59add07b1  call 0x000070A59ACE1570
000070a59add07b6  jmp 0x000070A59ADD0727
000070a59add07bb  int3
000070a59add07bc  nop [rax], eax
000070a59add07c0  mov eax, [r15+0xA0]
000070a59add07c7  mov [rsp+0x10], eax
000070a59add07cb  xor eax, eax
000070a59add07cd  mov r14d, [rsp+0x10]
000070a59add07d2  sub r14d, 0x01
000070a59add07d6  cmc
000070a59add07d7  lahf
000070a59add07d8  seto al
000070a59add07db  mov [r15+0x108], eax
000070a59add07e2  mov r14d, r14d
000070a59add07e5  mov [r15+0xA0], r14
000070a59add07ec  mov eax, [r15+0x108]
000070a59add07f3  sahf
000070a59add07f4  jnz 0x000070A59ADD0826
000070a59add07f6  cmp dword ptr [r15+0x318], 0x00
000070a59add07fe  jz 0x000070A59ADD0900
000070a59add0804  nop [rax+rax*1], ax
000070a59add080d  nop [rax+rax*1], eax
000070a59add0815  mov eax, 0x41028C
000070a59add081a  mov [r15+0x100], rax
000070a59add0821  jmp 0x000070A59ABFE110
000070a59add0826  cmp dword ptr [r15+0x318], 0x00
000070a59add082e  jz 0x000070A59ADD0860
000070a59add0834  nop [rax+rax*1], ax
000070a59add083d  nop [rax+rax*1], eax
000070a59add0845  mov eax, 0x410274
000070a59add084a  mov [r15+0x100], rax
000070a59add0851  jmp 0x000070A59ABFE110
000070a59add0856  int3
000070a59add0857  int3
000070a59add0858  nop [rax+rax*1], eax
000070a59add0860  mov rax, [r15+0xF8]
000070a59add0867  lea r14, [rax+0xD0]
000070a59add086e  mov [r15], r14
000070a59add0871  mov rax, [r15+0x98]
000070a59add0878  mov [r15+0x08], rax
000070a59add087c  mov qword ptr [r15+0x10], 0x12C
000070a59add0884  mov qword ptr [r15+0xF0], 0x410284
000070a59add088f  mov r14d, [r15+0x320]
000070a59add0896  mov eax, 0x410284
000070a59add089b  mov rcx, 0x70A59ADD07C0
000070a59add08a5  mov [r15+r14*8+0x328], rax
000070a59add08ad  mov [r15+r14*8+0x368], rcx
000070a59add08b5  add r14d, 0x01
000070a59add08b9  and r14d, 0x07
000070a59add08bd  mov [r15+0x320], r14d
000070a59add08c4  cmp dword ptr [r15+0x318], 0x00
000070a59add08cc  jz 0x000070A59ADCED70
000070a59add08d2  nop [rax+rax*1], ax
000070a59add08db  nop [rax+rax*1], eax
000070a59add08e3  mov eax, 0x4106BC
000070a59add08e8  mov [r15+0x100], rax
000070a59add08ef  jmp 0x000070A59ABFE110
000070a59add08f4  int3
000070a59add08f5  int3
000070a59add08f6  nop [rax+rax*1], ax
000070a59add08ff  nop
000070a59add0900  mov rax, [r15+0xF8]
000070a59add0907  lea r14, [rax+0xF0]
000070a59add090e  mov r12, [r13+r14*1]
000070a59add0913  mov [r15+0x98], r12
000070a59add091a  mov qword ptr [r15+0x40], 0x80
000070a59add0922  lea r14, [rax+0xD0]
000070a59add0929  mov [r15], r14
000070a59add092c  lea r14, [rax+0x14C]
000070a59add0933  mov [r15+0x08], r14
000070a59add0937  mov qword ptr [r15+0x10], 0x01
000070a59add093f  lea r14, [rax+0x14C]
000070a59add0946  mov eax, 0x80
000070a59add094b  mov [r13+r14*1], al
000070a59add0950  mov qword ptr [r15+0xF0], 0x4102A8
000070a59add095b  mov r14d, [r15+0x320]
000070a59add0962  mov eax, 0x4102A8
000070a59add0967  mov rcx, 0x70A59ADD09E0
000070a59add0971  mov [r15+r14*8+0x328], rax
000070a59add0979  mov [r15+r14*8+0x368], rcx
000070a59add0981  add r14d, 0x01
000070a59add0985  and r14d, 0x07
000070a59add0989  mov [r15+0x320], r14d
000070a59add0990  cmp dword ptr [r15+0x318], 0x00
000070a59add0998  jz 0x000070A59ADCED70
000070a59add099e  nop [rax+rax*1], ax
000070a59add09a7  nop [rax+rax*1], eax
000070a59add09af  mov eax, 0x4106BC
000070a59add09b4  mov [r15+0x100], rax
000070a59add09bb  jmp 0x000070A59ABFE110
000070a59add09c0  int3
000070a59add09c1  call 0x000070A59ACE27E0
000070a59add09c6  jmp 0x000070A59ADD0913
000070a59add09cb  call 0x000070A59ACD5AF0
000070a59add09d0  jmp 0x000070A59ADD0950
000070a59add09d5  int3
000070a59add09d6  nop [rax+rax*1], ax
000070a59add09df  nop
000070a59add09e0  mov rax, [r15+0xF8]
000070a59add09e7  lea r14, [rax+0x138]
000070a59add09ee  mov r12, [r13+r14*1]
000070a59add09f3  mov [r15+0x40], r12
000070a59add09f7  lea r14, [rax+0x148]
000070a59add09fe  xor eax, eax
000070a59add0a00  mov [r13+r14*1], al
000070a59add0a05  xor eax, eax
000070a59add0a07  mov r14d, 0x38
000070a59add0a0d  cmp r12, r14
000070a59add0a10  cmc
000070a59add0a11  lahf
000070a59add0a12  seto al
000070a59add0a15  mov [r15+0x108], eax
000070a59add0a1c  mov eax, [r15+0x108]
000070a59add0a23  sahf
000070a59add0a24  jz 0x000070A59ADD0A56
000070a59add0a26  cmp dword ptr [r15+0x318], 0x00
000070a59add0a2e  jz 0x000070A59ADD0AA0
000070a59add0a34  nop [rax+rax*1], ax
000070a59add0a3d  nop [rax+rax*1], eax
000070a59add0a45  mov eax, 0x4102B8
000070a59add0a4a  mov [r15+0x100], rax
000070a59add0a51  jmp 0x000070A59ABFE110
000070a59add0a56  cmp dword ptr [r15+0x318], 0x00
000070a59add0a5e  jz 0x000070A59ADD0BF0
000070a59add0a64  nop [rax+rax*1], ax
000070a59add0a6d  nop [rax+rax*1], eax
000070a59add0a75  mov eax, 0x4102D4
000070a59add0a7a  mov [r15+0x100], rax
000070a59add0a81  jmp 0x000070A59ABFE110
000070a59add0a86  int3
000070a59add0a87  call 0x000070A59ACE27E0
000070a59add0a8c  jmp 0x000070A59ADD09F3
000070a59add0a91  call 0x000070A59ACD5AF0
000070a59add0a96  jmp 0x000070A59ADD0A05
000070a59add0a9b  int3
000070a59add0a9c  nop [rax], eax
000070a59add0aa0  mov rax, [r15+0xF8]
000070a59add0aa7  lea r14, [rax+0xD0]
000070a59add0aae  mov [r15], r14
000070a59add0ab1  lea r14, [rax+0x148]
000070a59add0ab8  mov [r15+0x08], r14
000070a59add0abc  mov qword ptr [r15+0x10], 0x01
000070a59add0ac4  mov qword ptr [r15+0xF0], 0x4102C8
000070a59add0acf  mov r14d, [r15+0x320]
000070a59add0ad6  mov eax, 0x4102C8
000070a59add0adb  mov rcx, 0x70A59ADD0B40
000070a59add0ae5  mov [r15+r14*8+0x328], rax
000070a59add0aed  mov [r15+r14*8+0x368], rcx
000070a59add0af5  add r14d, 0x01
000070a59add0af9  and r14d, 0x07
000070a59add0afd  mov [r15+0x320], r14d
000070a59add0b04  cmp dword ptr [r15+0x318], 0x00
000070a59add0b0c  jz 0x000070A59ADCED70
000070a59add0b12  nop [rax+rax*1], ax
000070a59add0b1b  nop [rax+rax*1], eax
000070a59add0b23  mov eax, 0x4106BC
000070a59add0b28  mov [r15+0x100], rax
000070a59add0b2f  jmp 0x000070A59ABFE110
000070a59add0b34  int3
000070a59add0b35  int3
000070a59add0b36  nop [rax+rax*1], ax
000070a59add0b3f  nop
000070a59add0b40  mov rax, [r15+0xF8]
000070a59add0b47  lea r14, [rax+0x138]
000070a59add0b4e  mov rax, [r13+r14*1]
000070a59add0b53  mov [r15+0x40], rax
000070a59add0b57  mov [rsp+0x10], rax
000070a59add0b5c  xor eax, eax
000070a59add0b5e  mov r14, [rsp+0x10]
000070a59add0b63  mov r12d, 0x38
000070a59add0b69  cmp r14, r12
000070a59add0b6c  cmc
000070a59add0b6d  lahf
000070a59add0b6e  seto al
000070a59add0b71  mov [r15+0x108], eax
000070a59add0b78  mov eax, [r15+0x108]
000070a59add0b7f  sahf
000070a59add0b80  jnz 0x000070A59ADD0BB2
000070a59add0b82  cmp dword ptr [r15+0x318], 0x00
000070a59add0b8a  jz 0x000070A59ADD0BF0
000070a59add0b90  nop [rax+rax*1], ax
000070a59add0b99  nop [rax+rax*1], eax
000070a59add0ba1  mov eax, 0x4102D4
000070a59add0ba6  mov [r15+0x100], rax
000070a59add0bad  jmp 0x000070A59ABFE110
000070a59add0bb2  cmp dword ptr [r15+0x318], 0x00
000070a59add0bba  jz 0x000070A59ADD0AA0
000070a59add0bc0  nop [rax+rax*1], ax
000070a59add0bc9  nop [rax+rax*1], eax
000070a59add0bd1  mov eax, 0x4102B8
000070a59add0bd6  mov [r15+0x100], rax
000070a59add0bdd  jmp 0x000070A59ABFE110
000070a59add0be2  int3
000070a59add0be3  call 0x000070A59ACD59C0
000070a59add0be8  jmp 0x000070A59ADD0B53
000070a59add0bed  int3
000070a59add0bee  nop
000070a59add0bf0  mov rax, [r15+0x98]
000070a59add0bf7  rorx r14, rax, 0x3D
000070a59add0bfd  and r14, 0xFFFFFFFFFFFFFFF8
000070a59add0c01  mov rax, [r15+0xF8]
000070a59add0c08  lea r12, [rax+0xD0]
000070a59add0c0f  mov [r15], r12
000070a59add0c12  lea r12, [rax+0x140]
000070a59add0c19  mov [r15+0x08], r12
000070a59add0c1d  mov qword ptr [r15+0x10], 0x08
000070a59add0c25  bswap r14
000070a59add0c28  mov [r15+0x40], r14
000070a59add0c2c  lea r12, [rax+0x140]
000070a59add0c33  mov [r13+r12*1], r14
000070a59add0c38  mov qword ptr [r15+0xF0], 0x4102F0
000070a59add0c43  mov r14d, [r15+0x320]
000070a59add0c4a  mov eax, 0x4102F0
000070a59add0c4f  mov rcx, 0x70A59ADD0CC0
000070a59add0c59  mov [r15+r14*8+0x328], rax
000070a59add0c61  mov [r15+r14*8+0x368], rcx
000070a59add0c69  add r14d, 0x01
000070a59add0c6d  and r14d, 0x07
000070a59add0c71  mov [r15+0x320], r14d
000070a59add0c78  cmp dword ptr [r15+0x318], 0x00
000070a59add0c80  jz 0x000070A59ADCED70
000070a59add0c86  nop [rax+rax*1], ax
000070a59add0c8f  nop [rax+rax*1], eax
000070a59add0c97  mov eax, 0x4106BC
000070a59add0c9c  mov [r15+0x100], rax
000070a59add0ca3  jmp 0x000070A59ABFE110
000070a59add0ca8  int3
000070a59add0ca9  call 0x000070A59ACC3FE0
000070a59add0cae  jmp 0x000070A59ADD0C38
000070a59add0cb3  int3
000070a59add0cb4  nop [rax+rax*1], ax
000070a59add0cbd  nop [rax], eax
000070a59add0cc0  mov rax, [r15+0xF8]
000070a59add0cc7  lea r14, [rax+0xD0]
000070a59add0cce  mov r12d, [r13+r14*1]
000070a59add0cd3  lea r14, [rax+0xD4]
000070a59add0cda  mov r11d, [r13+r14*1]
000070a59add0cdf  lea r14, [rax+0xD8]
000070a59add0ce6  mov r10d, [r13+r14*1]
000070a59add0ceb  lea r14, [rax+0xDC]
000070a59add0cf2  mov r9d, [r13+r14*1]
000070a59add0cf7  mov qword ptr [r15+0x48], 0x430C20
000070a59add0cff  mov qword ptr [r15+0xA0], 0x00
000070a59add0d0a  bswap r12d
000070a59add0d0d  bswap r11d
000070a59add0d10  mov qword ptr [r15+0x98], 0x430D8C
000070a59add0d1b  mov r14d, 0x430C20
000070a59add0d21  mov [r13+r14*1], r12d
000070a59add0d26  mov r14d, 0x430C24
000070a59add0d2c  mov [r13+r14*1], r11d
000070a59add0d31  bswap r10d
000070a59add0d34  bswap r9d
000070a59add0d37  lea r14, [rax+0xE0]
000070a59add0d3e  mov r12d, [r13+r14*1]
000070a59add0d43  lea r14, [rax+0xE4]
000070a59add0d4a  mov r11d, [r13+r14*1]
000070a59add0d4f  mov r14d, 0x430C28
000070a59add0d55  mov [r13+r14*1], r10d
000070a59add0d5a  mov r14d, 0x430C2C
000070a59add0d60  mov [r13+r14*1], r9d
000070a59add0d65  bswap r12d
000070a59add0d68  bswap r11d
000070a59add0d6b  mov [rsp+0x10], r11d
000070a59add0d70  mov r11d, r11d
000070a59add0d73  mov [r15+0x58], r11
000070a59add0d77  lea r14, [rax+0xE8]
000070a59add0d7e  mov r11d, [r13+r14*1]
000070a59add0d83  lea r14, [rax+0xEC]
000070a59add0d8a  mov eax, [r13+r14*1]
000070a59add0d8f  mov [rsp+0x20], eax
000070a59add0d93  mov eax, eax
000070a59add0d95  mov [r15+0x60], rax
000070a59add0d99  mov eax, 0x430C30
000070a59add0d9e  mov [r13+rax*1], r12d
000070a59add0da3  mov eax, 0x430C34
000070a59add0da8  mov r14d, [rsp+0x10]
000070a59add0dad  mov [r13+rax*1], r14d
000070a59add0db2  bswap r11d
000070a59add0db5  mov [rsp+0x10], r11d
000070a59add0dba  mov r11d, r11d
000070a59add0dbd  mov [r15+0x40], r11
000070a59add0dc1  mov eax, [rsp+0x20]
000070a59add0dc5  bswap eax
000070a59add0dc7  mov [rsp+0x20], eax
000070a59add0dcb  mov eax, eax
000070a59add0dcd  mov [r15+0x50], rax
000070a59add0dd1  mov eax, 0x430C38
000070a59add0dd6  mov r14d, [rsp+0x10]
000070a59add0ddb  mov [r13+rax*1], r14d
000070a59add0de0  mov eax, 0x430C3C
000070a59add0de5  mov r14d, [rsp+0x20]
000070a59add0dea  mov [r13+rax*1], r14d
000070a59add0def  mov eax, [r15+0xA0]
000070a59add0df6  lea r14d, [eax+0x11]
000070a59add0dfb  mov r14d, r14d
000070a59add0dfe  mov [r15], r14
000070a59add0e01  mov qword ptr [r15+0xF0], 0x41034C
000070a59add0e0c  mov r14d, [r15+0x320]
000070a59add0e13  mov eax, 0x41034C
000070a59add0e18  mov rcx, 0x70A59ADD0F90
000070a59add0e22  mov [r15+r14*8+0x328], rax
000070a59add0e2a  mov [r15+r14*8+0x368], rcx
000070a59add0e32  add r14d, 0x01
000070a59add0e36  and r14d, 0x07
000070a59add0e3a  mov [r15+0x320], r14d
000070a59add0e41  cmp dword ptr [r15+0x318], 0x00
000070a59add0e49  jz 0x000070A59ADD0F20
000070a59add0e4f  nop [rax+rax*1], ax
000070a59add0e58  nop [rax+rax*1], eax
000070a59add0e60  mov eax, 0x410938
000070a59add0e65  mov [r15+0x100], rax
000070a59add0e6c  jmp 0x000070A59ABFE110
000070a59add0e71  int3
000070a59add0e72  call 0x000070A59ACE26A0
000070a59add0e77  jmp 0x000070A59ADD0CD3
000070a59add0e7c  call 0x000070A59ACE1430
000070a59add0e81  jmp 0x000070A59ADD0CDF
000070a59add0e86  call 0x000070A59ACE01C0
000070a59add0e8b  jmp 0x000070A59ADD0CEB
000070a59add0e90  call 0x000070A59ACDEF50
000070a59add0e95  jmp 0x000070A59ADD0CF7
000070a59add0e9a  call 0x000070A59ACE2BA0
000070a59add0e9f  jmp 0x000070A59ADD0D26
000070a59add0ea4  call 0x000070A59ACE1920
000070a59add0ea9  jmp 0x000070A59ADD0D31
000070a59add0eae  call 0x000070A59ACE26A0
000070a59add0eb3  jmp 0x000070A59ADD0D43
000070a59add0eb8  call 0x000070A59ACE1430
000070a59add0ebd  jmp 0x000070A59ADD0D4F
000070a59add0ec2  call 0x000070A59ACE06B0
000070a59add0ec7  jmp 0x000070A59ADD0D5A
000070a59add0ecc  call 0x000070A59ACDF440
000070a59add0ed1  jmp 0x000070A59ADD0D65
000070a59add0ed6  call 0x000070A59ACE1430
000070a59add0edb  jmp 0x000070A59ADD0D83
000070a59add0ee0  call 0x000070A59ACD5890
000070a59add0ee5  jmp 0x000070A59ADD0D8F
000070a59add0eea  call 0x000070A59AC0BAE0
000070a59add0eef  jmp 0x000070A59ADD0DA3
000070a59add0ef4  call 0x000070A59AC0DFE0
000070a59add0ef9  jmp 0x000070A59ADD0DB2
000070a59add0efe  call 0x000070A59AC0DFE0
000070a59add0f03  jmp 0x000070A59ADD0DE0
000070a59add0f08  call 0x000070A59AC0DFE0
000070a59add0f0d  jmp 0x000070A59ADD0DEF
000070a59add0f12  int3
000070a59add0f13  nop [rax+rax*1], ax
000070a59add0f1c  nop [rax], eax
000070a59add0f20  mov eax, [r15]
000070a59add0f23  mov [rsp+0x10], eax
000070a59add0f27  shr eax, 0x10
000070a59add0f2a  mov r14d, [rsp+0x10]
000070a59add0f2f  xor r14d, eax
000070a59add0f32  imul r14d, r14d, 0x7FEB352D
000070a59add0f39  mov eax, 0x846CA68B
000070a59add0f3e  mov eax, eax
000070a59add0f40  mov [r15+0x48], rax
000070a59add0f44  mov [rsp+0x10], r14d
000070a59add0f49  shr r14d, 0x0F
000070a59add0f4d  mov eax, [rsp+0x10]
000070a59add0f51  xor eax, r14d
000070a59add0f54  imul eax, eax, 0x846CA68B
000070a59add0f5a  mov [rsp+0x10], eax
000070a59add0f5e  mov eax, eax
000070a59add0f60  mov [r15+0x40], rax
000070a59add0f64  mov eax, [rsp+0x10]
000070a59add0f68  shr eax, 0x10
000070a59add0f6b  mov r14d, [rsp+0x10]
000070a59add0f70  xor r14d, eax
000070a59add0f73  mov r14d, r14d
000070a59add0f76  mov [r15], r14
000070a59add0f79  mov rax, [r15+0xF0]
000070a59add0f80  mov [r15+0x100], rax
000070a59add0f87  jmp 0x000070A59ADCE5C0
000070a59add0f8c  int3
000070a59add0f8d  int3
000070a59add0f8e  nop
000070a59add0f90  mov rax, [r15+0xA0]
000070a59add0f97  mov [rsp+0x10], rax
000070a59add0f9c  shl rax, 0x02
000070a59add0fa0  mov r14, [r15+0x98]
000070a59add0fa7  lea r12, [r14+rax*1]
000070a59add0fab  mov eax, [r15]
000070a59add0fae  mov [r13+r12*1], eax
000070a59add0fb3  mov rax, [rsp+0x10]
000070a59add0fb8  lea r14, [rax+0x01]
000070a59add0fbc  mov [r15+0xA0], r14
000070a59add0fc3  xor eax, eax
000070a59add0fc5  mov r12d, 0x400
000070a59add0fcb  cmp r14, r12
000070a59add0fce  cmc
000070a59add0fcf  lahf
000070a59add0fd0  seto al
000070a59add0fd3  mov [r15+0x108], eax
000070a59add0fda  mov eax, [r15+0x108]
000070a59add0fe1  sahf
000070a59add0fe2  jnz 0x000070A59ADD1014
000070a59add0fe4  cmp dword ptr [r15+0x318], 0x00
000070a59add0fec  jz 0x000070A59ADD10E0
000070a59add0ff2  nop [rax+rax*1], ax
000070a59add0ffb  nop [rax+rax*1], eax
000070a59add1003  mov eax, 0x41035C
000070a59add1008  mov [r15+0x100], rax
000070a59add100f  jmp 0x000070A59ABFE110
000070a59add1014  cmp dword ptr [r15+0x318], 0x00
000070a59add101c  jz 0x000070A59ADD1050
000070a59add1022  nop [rax+rax*1], ax
000070a59add102b  nop [rax+rax*1], eax
000070a59add1033  mov eax, 0x410344
000070a59add1038  mov [r15+0x100], rax
000070a59add103f  jmp 0x000070A59ABFE110
000070a59add1044  int3
000070a59add1045  call 0x000070A59ACB4B70
000070a59add104a  jmp 0x000070A59ADD0FB3
000070a59add104f  int3
000070a59add1050  mov eax, [r15+0xA0]
000070a59add1057  lea r14d, [eax+0x11]
000070a59add105c  mov r14d, r14d
000070a59add105f  mov [r15], r14
000070a59add1062  mov qword ptr [r15+0xF0], 0x41034C
000070a59add106d  mov r14d, [r15+0x320]
000070a59add1074  mov eax, 0x41034C
000070a59add1079  mov rcx, 0x70A59ADD0F90
000070a59add1083  mov [r15+r14*8+0x328], rax
000070a59add108b  mov [r15+r14*8+0x368], rcx
000070a59add1093  add r14d, 0x01
000070a59add1097  and r14d, 0x07
000070a59add109b  mov [r15+0x320], r14d
000070a59add10a2  cmp dword ptr [r15+0x318], 0x00
000070a59add10aa  jz 0x000070A59ADD0F20
000070a59add10b0  nop [rax+rax*1], ax
000070a59add10b9  nop [rax+rax*1], eax
000070a59add10c1  mov eax, 0x410938
000070a59add10c6  mov [r15+0x100], rax
000070a59add10cd  jmp 0x000070A59ABFE110
000070a59add10d2  int3
000070a59add10d3  int3
000070a59add10d4  nop [rax+rax*1], ax
000070a59add10dd  nop [rax], eax
000070a59add10e0  mov qword ptr [r15+0x40], 0x01
000070a59add10e8  cmp dword ptr [r15+0x318], 0x00
000070a59add10f0  jz 0x000070A59ADD1120
000070a59add10f6  nop [rax+rax*1], ax
000070a59add10ff  nop [rax+rax*1], eax
000070a59add1107  mov eax, 0x410378
000070a59add110c  mov [r15+0x100], rax
000070a59add1113  jmp 0x000070A59ABFE110
000070a59add1118  int3
000070a59add1119  int3
000070a59add111a  nop [rax+rax*1], ax
000070a59add1120  mov rax, [r15+0x40]
000070a59add1124  mov [rsp+0x10], rax
000070a59add1129  shl rax, 0x02
000070a59add112d  mov r14, [r15+0x98]
000070a59add1134  lea r12, [r14+rax*1]
000070a59add1138  mov eax, [r13+r12*1]
000070a59add113d  mov [rsp+0x20], eax
000070a59add1141  mov eax, eax
000070a59add1143  mov [r15+0x48], rax
000070a59add1147  mov rax, [rsp+0x10]
000070a59add114c  mov [r15+0x50], rax
000070a59add1150  mov eax, [r15+0x50]
000070a59add1154  lea r12d, [eax-0x01]
000070a59add1159  mov r12d, r12d
000070a59add115c  mov [r15+0x58], r12
000070a59add1160  mov rax, [r15+0x58]
000070a59add1164  mov r12d, eax
000070a59add1167  mov r12d, r12d
000070a59add116a  shl r12, 0x02
000070a59add116e  lea rax, [r14+r12*1]
000070a59add1172  mov r14d, [r13+rax*1]
000070a59add1177  mov [rsp+0x10], r14d
000070a59add117c  mov r14d, r14d
000070a59add117f  mov [r15+0x60], r14
000070a59add1183  xor eax, eax
000070a59add1185  mov r14d, [rsp+0x10]
000070a59add118a  mov r12d, [rsp+0x20]
000070a59add118f  cmp r14d, r12d
000070a59add1192  cmc
000070a59add1193  lahf
000070a59add1194  seto al
000070a59add1197  mov [r15+0x108], eax
000070a59add119e  mov eax, [r15+0x108]
000070a59add11a5  sahf
000070a59add11a6  cmc
000070a59add11a7  jbe 0x000070A59ADD11D9
000070a59add11a9  cmp dword ptr [r15+0x318], 0x00
000070a59add11b1  jz 0x000070A59ADD1220
000070a59add11b7  nop [rax+rax*1], ax
000070a59add11c0  nop [rax+rax*1], eax
000070a59add11c8  mov eax, 0x410390
000070a59add11cd  mov [r15+0x100], rax
000070a59add11d4  jmp 0x000070A59ABFE110
000070a59add11d9  cmp dword ptr [r15+0x318], 0x00
000070a59add11e1  jz 0x000070A59ADD14C0
000070a59add11e7  nop [rax+rax*1], ax
000070a59add11f0  nop [rax+rax*1], eax
000070a59add11f8  mov eax, 0x410368
000070a59add11fd  mov [r15+0x100], rax
000070a59add1204  jmp 0x000070A59ABFE110
000070a59add1209  int3
000070a59add120a  call 0x000070A59ACB4690
000070a59add120f  jmp 0x000070A59ADD113D
000070a59add1214  call 0x000070A59AC0DAE0
000070a59add1219  jmp 0x000070A59ADD1177
000070a59add121e  int3
000070a59add121f  nop
000070a59add1220  mov rax, [r15+0x50]
000070a59add1224  mov [rsp+0x10], rax
000070a59add1229  shl rax, 0x02
000070a59add122d  mov r14, [r15+0x98]
000070a59add1234  lea r12, [r14+rax*1]
000070a59add1238  mov eax, [r15+0x60]
000070a59add123c  mov [r13+r12*1], eax
000070a59add1241  mov rax, [rsp+0x10]
000070a59add1246  lea r14, [rax-0x01]
000070a59add124a  mov [r15+0x50], r14
000070a59add124e  mov rax, [r15+0x58]
000070a59add1252  test rax, rax
000070a59add1255  setz al
000070a59add1258  movzx rax, al
000070a59add125c  mov [rsp+0x414], al
000070a59add1263  cmp byte ptr [rsp+0x414], 0x00
000070a59add126b  jz 0x000070A59ADD129D
000070a59add126d  cmp dword ptr [r15+0x318], 0x00
000070a59add1275  jz 0x000070A59ADD12E0
000070a59add127b  nop [rax+rax*1], ax
000070a59add1284  nop [rax+rax*1], eax
000070a59add128c  mov eax, 0x41039C
000070a59add1291  mov [r15+0x100], rax
000070a59add1298  jmp 0x000070A59ABFE110
000070a59add129d  cmp dword ptr [r15+0x318], 0x00
000070a59add12a5  jz 0x000070A59ADD13E0
000070a59add12ab  nop [rax+rax*1], ax
000070a59add12b4  nop [rax+rax*1], eax
000070a59add12bc  mov eax, 0x410380
000070a59add12c1  mov [r15+0x100], rax
000070a59add12c8  jmp 0x000070A59ABFE110
000070a59add12cd  int3
000070a59add12ce  call 0x000070A59ACB4B70
000070a59add12d3  jmp 0x000070A59ADD1241
000070a59add12d8  int3
000070a59add12d9  nop [rax], eax
000070a59add12e0  cmp dword ptr [r15+0x318], 0x00
000070a59add12e8  jz 0x000070A59ADD1320
000070a59add12ee  nop [rax+rax*1], ax
000070a59add12f7  nop [rax+rax*1], eax
000070a59add12ff  mov eax, 0x410364
000070a59add1304  mov [r15+0x100], rax
000070a59add130b  jmp 0x000070A59ABFE110
000070a59add1310  int3
000070a59add1311  int3
000070a59add1312  nop [rax+rax*1], ax
000070a59add131b  nop [rax+rax*1], eax
000070a59add1320  mov qword ptr [r15+0x50], 0x00
000070a59add1328  mov rax, [r15+0x40]
000070a59add132c  lea r14, [rax+0x01]
000070a59add1330  mov [r15+0x40], r14
000070a59add1334  mov rax, [r15+0x98]
000070a59add133b  mov r12d, [r15+0x48]
000070a59add133f  mov [r13+rax*1], r12d
000070a59add1344  xor eax, eax
000070a59add1346  mov r12d, 0x400
000070a59add134c  cmp r14, r12
000070a59add134f  cmc
000070a59add1350  lahf
000070a59add1351  seto al
000070a59add1354  mov [r15+0x108], eax
000070a59add135b  mov eax, [r15+0x108]
000070a59add1362  sahf
000070a59add1363  jz 0x000070A59ADD1395
000070a59add1365  cmp dword ptr [r15+0x318], 0x00
000070a59add136d  jz 0x000070A59ADD1120
000070a59add1373  nop [rax+rax*1], ax
000070a59add137c  nop [rax+rax*1], eax
000070a59add1384  mov eax, 0x410378
000070a59add1389  mov [r15+0x100], rax
000070a59add1390  jmp 0x000070A59ABFE110
000070a59add1395  cmp dword ptr [r15+0x318], 0x00
000070a59add139d  jz 0x000070A59ADD1580
000070a59add13a3  nop [rax+rax*1], ax
000070a59add13ac  nop [rax+rax*1], eax
000070a59add13b4  mov eax, 0x4103A0
000070a59add13b9  mov [r15+0x100], rax
000070a59add13c0  jmp 0x000070A59ABFE110
000070a59add13c5  int3
000070a59add13c6  call 0x000070A59AC0BAE0
000070a59add13cb  jmp 0x000070A59ADD1344
000070a59add13d0  int3
000070a59add13d1  nop [rax+rax*1], ax
000070a59add13da  nop [rax+rax*1], ax
000070a59add13e0  mov eax, [r15+0x50]
000070a59add13e4  lea r14d, [eax-0x01]
000070a59add13e9  mov r14d, r14d
000070a59add13ec  mov [r15+0x58], r14
000070a59add13f0  mov rax, [r15+0x58]
000070a59add13f4  mov r14d, eax
000070a59add13f7  mov r14d, r14d
000070a59add13fa  shl r14, 0x02
000070a59add13fe  mov rax, [r15+0x98]
000070a59add1405  lea r12, [rax+r14*1]
000070a59add1409  mov eax, [r13+r12*1]
000070a59add140e  mov [rsp+0x10], eax
000070a59add1412  mov eax, eax
000070a59add1414  mov [r15+0x60], rax
000070a59add1418  mov eax, [r15+0x48]
000070a59add141c  mov [rsp+0x20], eax
000070a59add1420  xor eax, eax
000070a59add1422  mov r14d, [rsp+0x10]
000070a59add1427  mov r12d, [rsp+0x20]
000070a59add142c  cmp r14d, r12d
000070a59add142f  cmc
000070a59add1430  lahf
000070a59add1431  seto al
000070a59add1434  mov [r15+0x108], eax
000070a59add143b  mov eax, [r15+0x108]
000070a59add1442  sahf
000070a59add1443  cmc
000070a59add1444  jbe 0x000070A59ADD1476
000070a59add1446  cmp dword ptr [r15+0x318], 0x00
000070a59add144e  jz 0x000070A59ADD1220
000070a59add1454  nop [rax+rax*1], ax
000070a59add145d  nop [rax+rax*1], eax
000070a59add1465  mov eax, 0x410390
000070a59add146a  mov [r15+0x100], rax
000070a59add1471  jmp 0x000070A59ABFE110
000070a59add1476  cmp dword ptr [r15+0x318], 0x00
000070a59add147e  jz 0x000070A59ADD14C0
000070a59add1484  nop [rax+rax*1], ax
000070a59add148d  nop [rax+rax*1], eax
000070a59add1495  mov eax, 0x410368
000070a59add149a  mov [r15+0x100], rax
000070a59add14a1  jmp 0x000070A59ABFE110
000070a59add14a6  int3
000070a59add14a7  call 0x000070A59ACB4690
000070a59add14ac  jmp 0x000070A59ADD140E
000070a59add14b1  int3
000070a59add14b2  nop [rax+rax*1], ax
000070a59add14bb  nop [rax+rax*1], eax
000070a59add14c0  mov rax, [r15+0x40]
000070a59add14c4  lea r14, [rax+0x01]
000070a59add14c8  mov [r15+0x40], r14
000070a59add14cc  mov rax, [r15+0x50]
000070a59add14d0  mov r12d, eax
000070a59add14d3  mov r12d, r12d
000070a59add14d6  shl r12, 0x02
000070a59add14da  mov rax, [r15+0x98]
000070a59add14e1  lea r11, [rax+r12*1]
000070a59add14e5  mov eax, [r15+0x48]
000070a59add14e9  mov [r13+r11*1], eax
000070a59add14ee  xor eax, eax
000070a59add14f0  mov r12d, 0x400
000070a59add14f6  cmp r14, r12
000070a59add14f9  cmc
000070a59add14fa  lahf
000070a59add14fb  seto al
000070a59add14fe  mov [r15+0x108], eax
000070a59add1505  mov eax, [r15+0x108]
000070a59add150c  sahf
000070a59add150d  jz 0x000070A59ADD153F
000070a59add150f  cmp dword ptr [r15+0x318], 0x00
000070a59add1517  jz 0x000070A59ADD1120
000070a59add151d  nop [rax+rax*1], ax
000070a59add1526  nop [rax+rax*1], eax
000070a59add152e  mov eax, 0x410378
000070a59add1533  mov [r15+0x100], rax
000070a59add153a  jmp 0x000070A59ABFE110
000070a59add153f  cmp dword ptr [r15+0x318], 0x00
000070a59add1547  jz 0x000070A59ADD1580
000070a59add154d  nop [rax+rax*1], ax
000070a59add1556  nop [rax+rax*1], eax
000070a59add155e  mov eax, 0x4103A0
000070a59add1563  mov [r15+0x100], rax
000070a59add156a  jmp 0x000070A59ABFE110
000070a59add156f  int3
000070a59add1570  call 0x000070A59ACA4270
000070a59add1575  jmp 0x000070A59ADD14EE
000070a59add157a  int3
000070a59add157b  nop [rax+rax*1], eax
000070a59add1580  mov qword ptr [r15+0x40], 0x430000
000070a59add1588  mov eax, 0x430C40
000070a59add158d  mov r14, [r13+rax*1]
000070a59add1592  mov rax, [r15+0x98]
000070a59add1599  mov r12d, [r13+rax*1]
000070a59add159e  lea r11, [rax+0x04]
000070a59add15a2  mov eax, [r13+r11*1]
000070a59add15a7  mov r12d, r12d
000070a59add15aa  mov [r15+0x68], r12
000070a59add15ae  mov eax, eax
000070a59add15b0  mov [r15+0x60], rax
000070a59add15b4  mov rax, [r15+0x68]
000070a59add15b8  mov [r15+0x68], rax
000070a59add15bc  mov qword ptr [r15+0x58], 0x02
000070a59add15c4  mov [rsp+0x10], rax
000070a59add15c9  xor eax, eax
000070a59add15cb  mov r12d, 0x02
000070a59add15d1  mov r11d, 0x400
000070a59add15d7  cmp r12, r11
000070a59add15da  cmc
000070a59add15db  lahf
000070a59add15dc  seto al
000070a59add15df  mov [r15+0x108], eax
000070a59add15e6  mov rax, [r15+0x60]
000070a59add15ea  mov r12d, 0x02
000070a59add15f0  imul rax, r12
000070a59add15f4  mov [r15+0x50], rax
000070a59add15f8  mov rax, [rsp+0x10]
000070a59add15fd  lea r12, [rax+r14*1]
000070a59add1601  mov [r15+0x48], r12
000070a59add1605  mov eax, [r15+0x108]
000070a59add160c  sahf
000070a59add160d  jnz 0x000070A59ADD163F
000070a59add160f  cmp dword ptr [r15+0x318], 0x00
000070a59add1617  jz 0x000070A59ADD17B0
000070a59add161d  nop [rax+rax*1], ax
000070a59add1626  nop [rax+rax*1], eax
000070a59add162e  mov eax, 0x4103D0
000070a59add1633  mov [r15+0x100], rax
000070a59add163a  jmp 0x000070A59ABFE110
000070a59add163f  cmp dword ptr [r15+0x318], 0x00
000070a59add1647  jz 0x000070A59ADD1690
000070a59add164d  nop [rax+rax*1], ax
000070a59add1656  nop [rax+rax*1], eax
000070a59add165e  mov eax, 0x4103B0
000070a59add1663  mov [r15+0x100], rax
000070a59add166a  jmp 0x000070A59ABFE110
000070a59add166f  int3
000070a59add1670  call 0x000070A59AC0DC20
000070a59add1675  jmp 0x000070A59ADD1592
000070a59add167a  call 0x000070A59AC0B5E0
000070a59add167f  jmp 0x000070A59ADD159E
000070a59add1684  call 0x000070A59ACA3D90
000070a59add1689  jmp 0x000070A59ADD15A7
000070a59add168e  int3
000070a59add168f  nop
000070a59add1690  mov rax, [r15+0x98]
000070a59add1697  mov r14, [r15+0x58]
000070a59add169b  mov [rsp+0x10], r14
000070a59add16a0  shl r14, 0x02
000070a59add16a4  lea r12, [rax+r14*1]
000070a59add16a8  mov eax, [r13+r12*1]
000070a59add16ad  lea r14, [r12+0x04]
000070a59add16b2  mov r12d, [r13+r14*1]
000070a59add16b7  mov eax, eax
000070a59add16b9  mov [r15+0x68], rax
000070a59add16bd  mov r12d, r12d
000070a59add16c0  mov [r15+0x60], r12
000070a59add16c4  mov rax, [r15+0x68]
000070a59add16c8  mov [rsp+0x20], rax
000070a59add16cd  mov r14, [rsp+0x10]
000070a59add16d2  imul rax, r14
000070a59add16d6  mov r12, [rsp+0x20]
000070a59add16db  lea r11, [r12+rax*1]
000070a59add16df  mov [r15+0x68], r11
000070a59add16e3  lea rax, [r14+0x02]
000070a59add16e7  mov [r15+0x58], rax
000070a59add16eb  mov [rsp+0x10], rax
000070a59add16f0  xor eax, eax
000070a59add16f2  mov r14, [rsp+0x10]
000070a59add16f7  mov r12d, 0x400
000070a59add16fd  cmp r14, r12
000070a59add1700  cmc
000070a59add1701  lahf
000070a59add1702  seto al
000070a59add1705  mov [r15+0x108], eax
000070a59add170c  mov rax, [r15+0x50]
000070a59add1710  mov r12, [r15+0x60]
000070a59add1714  imul r14, r12
000070a59add1718  lea r12, [rax+r14*1]
000070a59add171c  mov [r15+0x50], r12
000070a59add1720  mov rax, [r15+0x48]
000070a59add1724  lea r14, [r11+rax*1]
000070a59add1728  mov [r15+0x48], r14
000070a59add172c  mov eax, [r15+0x108]
000070a59add1733  sahf
000070a59add1734  jnz 0x000070A59ADD1766
000070a59add1736  cmp dword ptr [r15+0x318], 0x00
000070a59add173e  jz 0x000070A59ADD17B0
000070a59add1744  nop [rax+rax*1], ax
000070a59add174d  nop [rax+rax*1], eax
000070a59add1755  mov eax, 0x4103D0
000070a59add175a  mov [r15+0x100], rax
000070a59add1761  jmp 0x000070A59ABFE110
000070a59add1766  cmp dword ptr [r15+0x318], 0x00
000070a59add176e  jz 0x000070A59ADD1690
000070a59add1774  nop [rax+rax*1], ax
000070a59add177d  nop [rax+rax*1], eax
000070a59add1785  mov eax, 0x4103B0
000070a59add178a  mov [r15+0x100], rax
000070a59add1791  jmp 0x000070A59ABFE110
000070a59add1796  int3
000070a59add1797  call 0x000070A59ACB4690
000070a59add179c  jmp 0x000070A59ADD16AD
000070a59add17a1  call 0x000070A59ACE26A0
000070a59add17a6  jmp 0x000070A59ADD16B7
000070a59add17ab  int3
000070a59add17ac  nop [rax], eax
000070a59add17b0  mov qword ptr [r15+0x98], 0x00
000070a59add17bb  mov rax, [r15+0x50]
000070a59add17bf  mov r14, [r15+0x48]
000070a59add17c3  lea r12, [rax+r14*1]
000070a59add17c7  mov [r15+0x48], r12
000070a59add17cb  mov rax, [r15+0x40]
000070a59add17cf  lea r14, [rax+0xC40]
000070a59add17d6  mov [r13+r14*1], r12
000070a59add17db  mov qword ptr [r15], 0x01
000070a59add17e2  mov qword ptr [r15+0xF0], 0x4103E8
000070a59add17ed  mov r14d, [r15+0x320]
000070a59add17f4  mov eax, 0x4103E8
000070a59add17f9  mov rcx, 0x70A59ADD1860
000070a59add1803  mov [r15+r14*8+0x328], rax
000070a59add180b  mov [r15+r14*8+0x368], rcx
000070a59add1813  add r14d, 0x01
000070a59add1817  and r14d, 0x07
000070a59add181b  mov [r15+0x320], r14d
000070a59add1822  cmp dword ptr [r15+0x318], 0x00
000070a59add182a  jz 0x000070A59ADD0F20
000070a59add1830  nop [rax+rax*1], ax
000070a59add1839  nop [rax+rax*1], eax
000070a59add1841  mov eax, 0x410938
000070a59add1846  mov [r15+0x100], rax
000070a59add184d  jmp 0x000070A59ABFE110
000070a59add1852  int3
000070a59add1853  call 0x000070A59ACE2CE0
000070a59add1858  jmp 0x000070A59ADD17DB
000070a59add185d  int3
000070a59add185e  nop
000070a59add1860  mov eax, [r15+0x98]
000070a59add1867  lea r14d, [eax+0x01]
000070a59add186c  mov [rsp+0x10], r14d
000070a59add1871  mov r14d, r14d
000070a59add1874  mov [r15+0x98], r14
000070a59add187b  xor eax, eax
000070a59add187d  mov r14d, [rsp+0x10]
000070a59add1882  cmp r14d, 0x10000
000070a59add1889  cmc
000070a59add188a  lahf
000070a59add188b  seto al
000070a59add188e  mov [r15+0x108], eax
000070a59add1895  mov eax, [r15+0x108]
000070a59add189c  sahf
000070a59add189d  jnz 0x000070A59ADD18CF
000070a59add189f  cmp dword ptr [r15+0x318], 0x00
000070a59add18a7  jz 0x000070A59ADD19A0
000070a59add18ad  nop [rax+rax*1], ax
000070a59add18b6  nop [rax+rax*1], eax
000070a59add18be  mov eax, 0x4103F4
000070a59add18c3  mov [r15+0x100], rax
000070a59add18ca  jmp 0x000070A59ABFE110
000070a59add18cf  cmp dword ptr [r15+0x318], 0x00
000070a59add18d7  jz 0x000070A59ADD1910
000070a59add18dd  nop [rax+rax*1], ax
000070a59add18e6  nop [rax+rax*1], eax
000070a59add18ee  mov eax, 0x4103E0
000070a59add18f3  mov [r15+0x100], rax
000070a59add18fa  jmp 0x000070A59ABFE110
000070a59add18ff  int3
000070a59add1900  int3
000070a59add1901  nop [rax+rax*1], ax
000070a59add190a  nop [rax+rax*1], ax
000070a59add1910  mov eax, [r15]
000070a59add1913  mov r14d, [r15+0x98]
000070a59add191a  lea r12d, [eax+r14d*1]
000070a59add191f  mov r12d, r12d
000070a59add1922  mov [r15], r12
000070a59add1925  mov qword ptr [r15+0xF0], 0x4103E8
000070a59add1930  mov r14d, [r15+0x320]
000070a59add1937  mov eax, 0x4103E8
000070a59add193c  mov rcx, 0x70A59ADD1860
000070a59add1946  mov [r15+r14*8+0x328], rax
000070a59add194e  mov [r15+r14*8+0x368], rcx
000070a59add1956  add r14d, 0x01
000070a59add195a  and r14d, 0x07
000070a59add195e  mov [r15+0x320], r14d
000070a59add1965  cmp dword ptr [r15+0x318], 0x00
000070a59add196d  jz 0x000070A59ADD0F20
000070a59add1973  nop [rax+rax*1], ax
000070a59add197c  nop [rax+rax*1], eax
000070a59add1984  mov eax, 0x410938
000070a59add1989  mov [r15+0x100], rax
000070a59add1990  jmp 0x000070A59ABFE110
000070a59add1995  int3
000070a59add1996  int3
000070a59add1997  nop [rax+rax*1], ax
000070a59add19a0  vmovaps xmm1, [0x000070A59A9FE010]
000070a59add19a8  movq xmm1, xmm1
000070a59add19ac  movaps [r15+0x110], xmm1
000070a59add19b4  mov eax, 0x420AA0
000070a59add19b9  mov r14, [r13+rax*1]
000070a59add19be  movq xmm1, r14
000070a59add19c3  movaps [r15+0x120], xmm1
000070a59add19cb  vmovaps xmm1, [0x000070A59A9FE020]
000070a59add19d3  movq xmm1, xmm1
000070a59add19d7  movaps [r15+0x140], xmm1
000070a59add19df  vmovaps xmm1, [0x000070A59A9FE030]
000070a59add19e7  vpbroadcastq xmm1, xmm1
000070a59add19ec  movaps [r15+0x150], xmm1
000070a59add19f4  mov qword ptr [r15+0x40], 0x02
000070a59add19fc  vmovaps xmm15, [0x000070A59A9FE040]
000070a59add1a04  movq xmm15, xmm15
000070a59add1a09  movaps [r15+0x160], xmm15
000070a59add1a11  vmovaps xmm15, [0x000070A59A9FE050]
000070a59add1a19  vpbroadcastq xmm15, xmm15
000070a59add1a1e  movaps [r15+0x130], xmm15
000070a59add1a26  mov rax, [r15+0x40]
000070a59add1a2a  vmovq xmm14, rax
000070a59add1a2f  vpbroadcastq xmm14, xmm14
000070a59add1a34  movaps [r15+0x170], xmm14
000070a59add1a3c  mov eax, 0x4209D0
000070a59add1a41  movups xmm13, [r13+rax*1]
000070a59add1a47  mov qword ptr [r15+0x40], 0x431D90
000070a59add1a4f  mov eax, [r15]
000070a59add1a52  mov r14d, 0x430C48
000070a59add1a58  mov [r13+r14*1], eax
000070a59add1a5d  mov qword ptr [r15+0x50], 0x431F90
000070a59add1a65  vpmovqd xmm12, xmm13
000070a59add1a6b  pxor xmm11, xmm11
000070a59add1a70  punpcklqdq xmm12, xmm11
000070a59add1a75  movaps [r15+0x210], xmm12
000070a59add1a7d  movq xmm12, qword ptr [r15+0x140]
000070a59add1a86  movq xmm11, qword ptr [r15+0x120]
000070a59add1a8f  psubd xmm12, xmm11
000070a59add1a94  movq xmm12, xmm12
000070a59add1a99  paddq xmm13, xmm14
000070a59add1a9e  movaps [r15+0x180], xmm13
000070a59add1aa6  movq xmm14, qword ptr [r15+0x160]
000070a59add1aaf  paddd xmm11, xmm14
000070a59add1ab4  movq xmm11, xmm11
000070a59add1ab9  movq xmm11, xmm11
000070a59add1abe  movaps [r15+0x120], xmm11
000070a59add1ac6  pmovzxdq xmm12, xmm12
000070a59add1acc  psllq xmm12, 0x00
000070a59add1ad2  movq xmm14, qword ptr [r15+0x210]
000070a59add1adb  movq xmm13, qword ptr [r15+0x110]
000070a59add1ae4  paddd xmm14, xmm13
000070a59add1ae9  movq xmm14, xmm14
000070a59add1aee  vcvtuqq2pd xmm12, xmm12
000070a59add1af4  pmovzxdq xmm14, xmm14
000070a59add1afa  psllq xmm14, 0x00
000070a59add1b00  vcvtuqq2pd xmm14, xmm14
000070a59add1b06  movaps xmm13, xmm12
000070a59add1b0a  mulpd xmm13, xmm1
000070a59add1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
000070a59add1b15  ptest xmm11, xmm11
000070a59add1b1b  jnz 0x000070A59ADD1C0F
000070a59add1b21  movaps [r15+0x220], xmm13
000070a59add1b29  mov eax, 0x431F90
000070a59add1b2e  movups [r13+rax*1], xmm13
000070a59add1b34  movaps xmm1, xmm14
000070a59add1b38  mulpd xmm1, xmm15
000070a59add1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
000070a59add1b42  ptest xmm13, xmm13
000070a59add1b48  jnz 0x000070A59ADD1D5C
000070a59add1b4e  movaps [r15+0x210], xmm1
000070a59add1b56  mov eax, 0x431D90
000070a59add1b5b  movups [r13+rax*1], xmm1
000070a59add1b61  mov qword ptr [r15+0x48], 0x10
000070a59add1b69  xor eax, eax
000070a59add1b6b  mov r14d, 0x10
000070a59add1b71  mov r12d, 0x200
000070a59add1b77  cmp r14, r12
000070a59add1b7a  cmc
000070a59add1b7b  lahf
000070a59add1b7c  seto al
000070a59add1b7f  mov [r15+0x108], eax
000070a59add1b86  mov eax, [r15+0x108]
000070a59add1b8d  sahf
000070a59add1b8e  jnz 0x000070A59ADD1BC0
000070a59add1b90  cmp dword ptr [r15+0x318], 0x00
000070a59add1b98  jz 0x000070A59ADD2300
000070a59add1b9e  nop [rax+rax*1], ax
000070a59add1ba7  nop [rax+rax*1], eax
000070a59add1baf  mov eax, 0x410480
000070a59add1bb4  mov [r15+0x100], rax
000070a59add1bbb  jmp 0x000070A59ABFE110
000070a59add1bc0  cmp dword ptr [r15+0x318], 0x00
000070a59add1bc8  jz 0x000070A59ADD1EB0
000070a59add1bce  nop [rax+rax*1], ax
000070a59add1bd7  nop [rax+rax*1], eax
000070a59add1bdf  mov eax, 0x410440
000070a59add1be4  mov [r15+0x100], rax
000070a59add1beb  jmp 0x000070A59ABFE110
000070a59add1bf0  int3
000070a59add1bf1  call 0x000070A59AC0DC20
000070a59add1bf6  jmp 0x000070A59ADD19BE
000070a59add1bfb  call 0x000070A59AC0C260
000070a59add1c00  jmp 0x000070A59ADD1A47
000070a59add1c05  call 0x000070A59ACD5D70
000070a59add1c0a  jmp 0x000070A59ADD1A5D
000070a59add1c0f  sub rsp, 0x08
000070a59add1c13  push rax
000070a59add1c14  push rcx
000070a59add1c15  push rdx
000070a59add1c16  push rdi
000070a59add1c17  push rsi
000070a59add1c18  push r8
000070a59add1c1a  push r9
000070a59add1c1c  push r10
000070a59add1c1e  push r11
000070a59add1c20  sub rsp, 0xF0
000070a59add1c27  vmovaps [rsp], xmm0
000070a59add1c2c  vmovaps [rsp+0x10], xmm1
000070a59add1c32  vmovaps [rsp+0x20], xmm2
000070a59add1c38  vmovaps [rsp+0x30], xmm3
000070a59add1c3e  vmovaps [rsp+0x40], xmm4
000070a59add1c44  vmovaps [rsp+0x50], xmm5
000070a59add1c4a  vmovaps [rsp+0x60], xmm6
000070a59add1c50  vmovaps [rsp+0x70], xmm7
000070a59add1c56  vmovaps [rsp+0x80], xmm8
000070a59add1c5f  vmovaps [rsp+0x90], xmm9
000070a59add1c68  vmovaps [rsp+0xA0], xmm10
000070a59add1c71  vmovaps [rsp+0xB0], xmm11
000070a59add1c7a  vmovaps [rsp+0xC0], xmm12
000070a59add1c83  vmovaps [rsp+0xD0], xmm14
000070a59add1c8c  vmovaps [rsp+0xE0], xmm15
000070a59add1c95  sub rsp, 0x30
000070a59add1c99  movaps [rsp], xmm13
000070a59add1c9e  movaps [rsp+0x10], xmm12
000070a59add1ca4  movaps [rsp+0x20], xmm1
000070a59add1ca9  lea rdi, [rsp]
000070a59add1cad  mov esi, 0x00
000070a59add1cb2  mov rax, 0x622906D8F530
000070a59add1cbc  call rax
000070a59add1cbe  movaps xmm13, [rsp]
000070a59add1cc3  add rsp, 0x30
000070a59add1cc7  vmovaps xmm0, [rsp]
000070a59add1ccc  vmovaps xmm1, [rsp+0x10]
000070a59add1cd2  vmovaps xmm2, [rsp+0x20]
000070a59add1cd8  vmovaps xmm3, [rsp+0x30]
000070a59add1cde  vmovaps xmm4, [rsp+0x40]
000070a59add1ce4  vmovaps xmm5, [rsp+0x50]
000070a59add1cea  vmovaps xmm6, [rsp+0x60]
000070a59add1cf0  vmovaps xmm7, [rsp+0x70]
000070a59add1cf6  vmovaps xmm8, [rsp+0x80]
000070a59add1cff  vmovaps xmm9, [rsp+0x90]
000070a59add1d08  vmovaps xmm10, [rsp+0xA0]
000070a59add1d11  vmovaps xmm11, [rsp+0xB0]
000070a59add1d1a  vmovaps xmm12, [rsp+0xC0]
000070a59add1d23  vmovaps xmm14, [rsp+0xD0]
000070a59add1d2c  vmovaps xmm15, [rsp+0xE0]
000070a59add1d35  add rsp, 0xF0
000070a59add1d3c  pop r11
000070a59add1d3e  pop r10
000070a59add1d40  pop r9
000070a59add1d42  pop r8
000070a59add1d44  pop rsi
000070a59add1d45  pop rdi
000070a59add1d46  pop rdx
000070a59add1d47  pop rcx
000070a59add1d48  pop rax
000070a59add1d49  add rsp, 0x08
000070a59add1d4d  jmp 0x000070A59ADD1B21
000070a59add1d52  call 0x000070A59AC0C380
000070a59add1d57  jmp 0x000070A59ADD1B34
000070a59add1d5c  sub rsp, 0x08
000070a59add1d60  push rax
000070a59add1d61  push rcx
000070a59add1d62  push rdx
000070a59add1d63  push rdi
000070a59add1d64  push rsi
000070a59add1d65  push r8
000070a59add1d67  push r9
000070a59add1d69  push r10
000070a59add1d6b  push r11
000070a59add1d6d  sub rsp, 0xF0
000070a59add1d74  vmovaps [rsp], xmm0
000070a59add1d79  vmovaps [rsp+0x10], xmm2
000070a59add1d7f  vmovaps [rsp+0x20], xmm3
000070a59add1d85  vmovaps [rsp+0x30], xmm4
000070a59add1d8b  vmovaps [rsp+0x40], xmm5
000070a59add1d91  vmovaps [rsp+0x50], xmm6
000070a59add1d97  vmovaps [rsp+0x60], xmm7
000070a59add1d9d  vmovaps [rsp+0x70], xmm8
000070a59add1da3  vmovaps [rsp+0x80], xmm9
000070a59add1dac  vmovaps [rsp+0x90], xmm10
000070a59add1db5  vmovaps [rsp+0xA0], xmm11
000070a59add1dbe  vmovaps [rsp+0xB0], xmm12
000070a59add1dc7  vmovaps [rsp+0xC0], xmm13
000070a59add1dd0  vmovaps [rsp+0xD0], xmm14
000070a59add1dd9  vmovaps [rsp+0xE0], xmm15
000070a59add1de2  sub rsp, 0x30
000070a59add1de6  movaps [rsp], xmm1
000070a59add1dea  movaps [rsp+0x10], xmm14
000070a59add1df0  movaps [rsp+0x20], xmm15
000070a59add1df6  lea rdi, [rsp]
000070a59add1dfa  mov esi, 0x00
000070a59add1dff  mov rax, 0x622906D8F530
000070a59add1e09  call rax
000070a59add1e0b  movaps xmm1, [rsp]
000070a59add1e0f  add rsp, 0x30
000070a59add1e13  vmovaps xmm0, [rsp]
000070a59add1e18  vmovaps xmm2, [rsp+0x10]
000070a59add1e1e  vmovaps xmm3, [rsp+0x20]
000070a59add1e24  vmovaps xmm4, [rsp+0x30]
000070a59add1e2a  vmovaps xmm5, [rsp+0x40]
000070a59add1e30  vmovaps xmm6, [rsp+0x50]
000070a59add1e36  vmovaps xmm7, [rsp+0x60]
000070a59add1e3c  vmovaps xmm8, [rsp+0x70]
000070a59add1e42  vmovaps xmm9, [rsp+0x80]
000070a59add1e4b  vmovaps xmm10, [rsp+0x90]
000070a59add1e54  vmovaps xmm11, [rsp+0xA0]
000070a59add1e5d  vmovaps xmm12, [rsp+0xB0]
000070a59add1e66  vmovaps xmm13, [rsp+0xC0]
000070a59add1e6f  vmovaps xmm14, [rsp+0xD0]
000070a59add1e78  vmovaps xmm15, [rsp+0xE0]
000070a59add1e81  add rsp, 0xF0
000070a59add1e88  pop r11
000070a59add1e8a  pop r10
000070a59add1e8c  pop r9
000070a59add1e8e  pop r8
000070a59add1e90  pop rsi
000070a59add1e91  pop rdi
000070a59add1e92  pop rdx
000070a59add1e93  pop rcx
000070a59add1e94  pop rax
000070a59add1e95  add rsp, 0x08
000070a59add1e99  jmp 0x000070A59ADD1B4E
000070a59add1e9e  call 0x000070A59ABFF540
000070a59add1ea3  jmp 0x000070A59ADD1B61
000070a59add1ea8  int3
000070a59add1ea9  nop [rax], eax
000070a59add1eb0  movaps xmm1, [r15+0x180]
000070a59add1eb8  vpmovqd xmm15, xmm1
000070a59add1ebe  pxor xmm14, xmm14
000070a59add1ec3  punpcklqdq xmm15, xmm14
000070a59add1ec8  movaps [r15+0x210], xmm15
000070a59add1ed0  movq xmm15, qword ptr [r15+0x140]
000070a59add1ed9  movq xmm14, qword ptr [r15+0x120]
000070a59add1ee2  psubd xmm15, xmm14
000070a59add1ee7  movq xmm15, xmm15
000070a59add1eec  movaps xmm13, [r15+0x170]
000070a59add1ef4  paddq xmm1, xmm13
000070a59add1ef9  movaps [r15+0x180], xmm1
000070a59add1f01  movq xmm1, qword ptr [r15+0x160]
000070a59add1f0a  paddd xmm14, xmm1
000070a59add1f0f  movq xmm14, xmm14
000070a59add1f14  movq xmm14, xmm14
000070a59add1f19  movaps [r15+0x120], xmm14
000070a59add1f21  pmovzxdq xmm15, xmm15
000070a59add1f27  psllq xmm15, 0x00
000070a59add1f2d  movq xmm1, qword ptr [r15+0x210]
000070a59add1f36  movq xmm14, qword ptr [r15+0x110]
000070a59add1f3f  paddd xmm1, xmm14
000070a59add1f44  movq xmm1, xmm1
000070a59add1f48  vcvtuqq2pd xmm15, xmm15
000070a59add1f4e  pmovzxdq xmm1, xmm1
000070a59add1f53  psllq xmm1, 0x00
000070a59add1f58  vcvtuqq2pd xmm1, xmm1
000070a59add1f5e  movaps xmm14, [r15+0x150]
000070a59add1f66  movaps xmm13, xmm15
000070a59add1f6a  mulpd xmm13, xmm14
000070a59add1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
000070a59add1f75  ptest xmm12, xmm12
000070a59add1f7b  jnz 0x000070A59ADD205E
000070a59add1f81  movaps [r15+0x220], xmm13
000070a59add1f89  mov rax, [r15+0x48]
000070a59add1f8d  mov r14, [r15+0x50]
000070a59add1f91  lea r12, [r14+rax*1]
000070a59add1f95  movups [r13+r12*1], xmm13
000070a59add1f9b  movaps xmm15, [r15+0x130]
000070a59add1fa3  movaps xmm14, xmm1
000070a59add1fa7  mulpd xmm14, xmm15
000070a59add1fac  vcmppd xmm13, xmm14, xmm14, 0x03
000070a59add1fb2  ptest xmm13, xmm13
000070a59add1fb8  jnz 0x000070A59ADD21AC
000070a59add1fbe  movaps [r15+0x210], xmm14
000070a59add1fc6  mov r14, [r15+0x40]
000070a59add1fca  lea r12, [r14+rax*1]
000070a59add1fce  movups [r13+r12*1], xmm14
000070a59add1fd4  lea r14, [rax+0x10]
000070a59add1fd8  mov [r15+0x48], r14
000070a59add1fdc  xor eax, eax
000070a59add1fde  mov r12d, 0x200
000070a59add1fe4  cmp r14, r12
000070a59add1fe7  cmc
000070a59add1fe8  lahf
000070a59add1fe9  seto al
000070a59add1fec  mov [r15+0x108], eax
000070a59add1ff3  mov eax, [r15+0x108]
000070a59add1ffa  sahf
000070a59add1ffb  jnz 0x000070A59ADD202D
000070a59add1ffd  cmp dword ptr [r15+0x318], 0x00
000070a59add2005  jz 0x000070A59ADD2300
000070a59add200b  nop [rax+rax*1], ax
000070a59add2014  nop [rax+rax*1], eax
000070a59add201c  mov eax, 0x410480
000070a59add2021  mov [r15+0x100], rax
000070a59add2028  jmp 0x000070A59ABFE110
000070a59add202d  cmp dword ptr [r15+0x318], 0x00
000070a59add2035  jz 0x000070A59ADD1EB0
000070a59add203b  nop [rax+rax*1], ax
000070a59add2044  nop [rax+rax*1], eax
000070a59add204c  mov eax, 0x410440
000070a59add2051  mov [r15+0x100], rax
000070a59add2058  jmp 0x000070A59ABFE110
000070a59add205d  int3
000070a59add205e  sub rsp, 0x08
000070a59add2062  push rax
000070a59add2063  push rcx
000070a59add2064  push rdx
000070a59add2065  push rdi
000070a59add2066  push rsi
000070a59add2067  push r8
000070a59add2069  push r9
000070a59add206b  push r10
000070a59add206d  push r11
000070a59add206f  sub rsp, 0xF0
000070a59add2076  vmovaps [rsp], xmm0
000070a59add207b  vmovaps [rsp+0x10], xmm1
000070a59add2081  vmovaps [rsp+0x20], xmm2
000070a59add2087  vmovaps [rsp+0x30], xmm3
000070a59add208d  vmovaps [rsp+0x40], xmm4
000070a59add2093  vmovaps [rsp+0x50], xmm5
000070a59add2099  vmovaps [rsp+0x60], xmm6
000070a59add209f  vmovaps [rsp+0x70], xmm7
000070a59add20a5  vmovaps [rsp+0x80], xmm8
000070a59add20ae  vmovaps [rsp+0x90], xmm9
000070a59add20b7  vmovaps [rsp+0xA0], xmm10
000070a59add20c0  vmovaps [rsp+0xB0], xmm11
000070a59add20c9  vmovaps [rsp+0xC0], xmm12
000070a59add20d2  vmovaps [rsp+0xD0], xmm14
000070a59add20db  vmovaps [rsp+0xE0], xmm15
000070a59add20e4  sub rsp, 0x30
000070a59add20e8  movaps [rsp], xmm13
000070a59add20ed  movaps [rsp+0x10], xmm15
000070a59add20f3  movaps [rsp+0x20], xmm14
000070a59add20f9  lea rdi, [rsp]
000070a59add20fd  mov esi, 0x00
000070a59add2102  mov rax, 0x622906D8F530
000070a59add210c  call rax
000070a59add210e  movaps xmm13, [rsp]
000070a59add2113  add rsp, 0x30
000070a59add2117  vmovaps xmm0, [rsp]
000070a59add211c  vmovaps xmm1, [rsp+0x10]
000070a59add2122  vmovaps xmm2, [rsp+0x20]
000070a59add2128  vmovaps xmm3, [rsp+0x30]
000070a59add212e  vmovaps xmm4, [rsp+0x40]
000070a59add2134  vmovaps xmm5, [rsp+0x50]
000070a59add213a  vmovaps xmm6, [rsp+0x60]
000070a59add2140  vmovaps xmm7, [rsp+0x70]
000070a59add2146  vmovaps xmm8, [rsp+0x80]
000070a59add214f  vmovaps xmm9, [rsp+0x90]
000070a59add2158  vmovaps xmm10, [rsp+0xA0]
000070a59add2161  vmovaps xmm11, [rsp+0xB0]
000070a59add216a  vmovaps xmm12, [rsp+0xC0]
000070a59add2173  vmovaps xmm14, [rsp+0xD0]
000070a59add217c  vmovaps xmm15, [rsp+0xE0]
000070a59add2185  add rsp, 0xF0
000070a59add218c  pop r11
000070a59add218e  pop r10
000070a59add2190  pop r9
000070a59add2192  pop r8
000070a59add2194  pop rsi
000070a59add2195  pop rdi
000070a59add2196  pop rdx
000070a59add2197  pop rcx
000070a59add2198  pop rax
000070a59add2199  add rsp, 0x08
000070a59add219d  jmp 0x000070A59ADD1F81
000070a59add21a2  call 0x000070A59ACC2240
000070a59add21a7  jmp 0x000070A59ADD1F9B
000070a59add21ac  sub rsp, 0x08
000070a59add21b0  push rax
000070a59add21b1  push rcx
000070a59add21b2  push rdx
000070a59add21b3  push rdi
000070a59add21b4  push rsi
000070a59add21b5  push r8
000070a59add21b7  push r9
000070a59add21b9  push r10
000070a59add21bb  push r11
000070a59add21bd  sub rsp, 0xF0
000070a59add21c4  vmovaps [rsp], xmm0
000070a59add21c9  vmovaps [rsp+0x10], xmm1
000070a59add21cf  vmovaps [rsp+0x20], xmm2
000070a59add21d5  vmovaps [rsp+0x30], xmm3
000070a59add21db  vmovaps [rsp+0x40], xmm4
000070a59add21e1  vmovaps [rsp+0x50], xmm5
000070a59add21e7  vmovaps [rsp+0x60], xmm6
000070a59add21ed  vmovaps [rsp+0x70], xmm7
000070a59add21f3  vmovaps [rsp+0x80], xmm8
000070a59add21fc  vmovaps [rsp+0x90], xmm9
000070a59add2205  vmovaps [rsp+0xA0], xmm10
000070a59add220e  vmovaps [rsp+0xB0], xmm11
000070a59add2217  vmovaps [rsp+0xC0], xmm12
000070a59add2220  vmovaps [rsp+0xD0], xmm13
000070a59add2229  vmovaps [rsp+0xE0], xmm15
000070a59add2232  sub rsp, 0x30
000070a59add2236  movaps [rsp], xmm14
000070a59add223b  movaps [rsp+0x10], xmm1
000070a59add2240  movaps [rsp+0x20], xmm15
000070a59add2246  lea rdi, [rsp]
000070a59add224a  mov esi, 0x00
000070a59add224f  mov rax, 0x622906D8F530
000070a59add2259  call rax
000070a59add225b  movaps xmm14, [rsp]
000070a59add2260  add rsp, 0x30
000070a59add2264  vmovaps xmm0, [rsp]
000070a59add2269  vmovaps xmm1, [rsp+0x10]
000070a59add226f  vmovaps xmm2, [rsp+0x20]
000070a59add2275  vmovaps xmm3, [rsp+0x30]
000070a59add227b  vmovaps xmm4, [rsp+0x40]
000070a59add2281  vmovaps xmm5, [rsp+0x50]
000070a59add2287  vmovaps xmm6, [rsp+0x60]
000070a59add228d  vmovaps xmm7, [rsp+0x70]
000070a59add2293  vmovaps xmm8, [rsp+0x80]
000070a59add229c  vmovaps xmm9, [rsp+0x90]
000070a59add22a5  vmovaps xmm10, [rsp+0xA0]
000070a59add22ae  vmovaps xmm11, [rsp+0xB0]
000070a59add22b7  vmovaps xmm12, [rsp+0xC0]
000070a59add22c0  vmovaps xmm13, [rsp+0xD0]
000070a59add22c9  vmovaps xmm15, [rsp+0xE0]
000070a59add22d2  add rsp, 0xF0
000070a59add22d9  pop r11
000070a59add22db  pop r10
000070a59add22dd  pop r9
000070a59add22df  pop r8
000070a59add22e1  pop rsi
000070a59add22e2  pop rdi
000070a59add22e3  pop rdx
000070a59add22e4  pop rcx
000070a59add22e5  pop rax
000070a59add22e6  add rsp, 0x08
000070a59add22ea  jmp 0x000070A59ADD1FBE
000070a59add22ef  call 0x000070A59ACC34C0
000070a59add22f4  jmp 0x000070A59ADD1FD4
000070a59add22f9  int3
000070a59add22fa  nop [rax+rax*1], ax
000070a59add2300  mov rax, [r15+0x50]
000070a59add2304  movups xmm1, [r13+rax*1]
000070a59add230a  lea r14, [rax+0x10]
000070a59add230e  movups xmm15, [r13+r14*1]
000070a59add2314  mov qword ptr [r15+0x48], 0x00
000070a59add231c  lea r14, [rax+0x40]
000070a59add2320  movups xmm14, [r13+r14*1]
000070a59add2326  lea r14, [rax+0x50]
000070a59add232a  movups xmm13, [r13+r14*1]
000070a59add2330  lea r14, [rax+0x80]
000070a59add2337  movups xmm12, [r13+r14*1]
000070a59add233d  lea r14, [rax+0x90]
000070a59add2344  movups xmm11, [r13+r14*1]
000070a59add234a  mov r14, [r15+0xF8]
000070a59add2351  movups [r13+r14*1], xmm1
000070a59add2357  lea r12, [rax+0x20]
000070a59add235b  movups xmm1, [r13+r12*1]
000070a59add2361  lea r12, [rax+0x30]
000070a59add2365  movups xmm10, [r13+r12*1]
000070a59add236b  lea r12, [rax+0xC0]
000070a59add2372  movups xmm9, [r13+r12*1]
000070a59add2378  lea r12, [rax+0xD0]
000070a59add237f  movups xmm8, [r13+r12*1]
000070a59add2385  lea r12, [rax+0x100]
000070a59add238c  movups xmm7, [r13+r12*1]
000070a59add2392  lea r12, [rax+0x110]
000070a59add2399  movups xmm6, [r13+r12*1]
000070a59add239f  lea r12, [rax+0x140]
000070a59add23a6  movups xmm5, [r13+r12*1]
000070a59add23ac  lea r12, [rax+0x150]
000070a59add23b3  movups xmm4, [r13+r12*1]
000070a59add23b9  lea r12, [r14+0xB0]
000070a59add23c0  movups [r13+r12*1], xmm10
000070a59add23c6  lea r12, [r14+0xC0]
000070a59add23cd  movups [r13+r12*1], xmm1
000070a59add23d3  lea r12, [rax+0x180]
000070a59add23da  movups xmm1, [r13+r12*1]
000070a59add23e0  lea r12, [rax+0x190]
000070a59add23e7  movups xmm10, [r13+r12*1]
000070a59add23ed  lea r12, [rax+0x1C0]
000070a59add23f4  movups xmm3, [r13+r12*1]
000070a59add23fa  lea r12, [rax+0x1D0]
000070a59add2401  movups xmm2, [r13+r12*1]
000070a59add2407  lea r12, [rax+0x60]
000070a59add240b  vmovaps [rsp+0x10], xmm1
000070a59add2411  movups xmm1, [r13+r12*1]
000070a59add2417  lea r12, [rax+0x70]
000070a59add241b  vmovaps [rsp+0x20], xmm1
000070a59add2421  movups xmm1, [r13+r12*1]
000070a59add2427  lea r12, [r14+0x70]
000070a59add242b  movups [r13+r12*1], xmm10
000070a59add2431  lea r12, [r14+0x80]
000070a59add2438  vmovaps xmm10, [rsp+0x10]
000070a59add243e  movups [r13+r12*1], xmm10
000070a59add2444  lea r12, [rax+0xA0]
000070a59add244b  movups xmm10, [r13+r12*1]
000070a59add2451  lea r12, [rax+0xB0]
000070a59add2458  vmovaps [rsp+0x10], xmm1
000070a59add245e  movups xmm1, [r13+r12*1]
000070a59add2464  lea r12, [r14+0x90]
000070a59add246b  movups [r13+r12*1], xmm2
000070a59add2471  lea r12, [r14+0xA0]
000070a59add2478  movups [r13+r12*1], xmm3
000070a59add247e  lea r12, [rax+0xE0]
000070a59add2485  movups xmm3, [r13+r12*1]
000070a59add248b  lea r12, [rax+0xF0]
000070a59add2492  movups xmm2, [r13+r12*1]
000070a59add2498  lea r12, [rax+0x120]
000070a59add249f  vmovaps [rsp+0x30], xmm1
000070a59add24a5  movups xmm1, [r13+r12*1]
000070a59add24ab  lea r12, [rax+0x130]
000070a59add24b2  vmovaps [rsp+0x40], xmm1
000070a59add24b8  movups xmm1, [r13+r12*1]
000070a59add24be  vmovaps [rsp+0x50], xmm1
000070a59add24c4  vmovaps xmm1, [rsp+0x40]
000070a59add24ca  movaps [r15+0x190], xmm1
000070a59add24d2  lea r12, [rax+0x160]
000070a59add24d9  vmovaps [rsp+0x40], xmm1
000070a59add24df  movups xmm1, [r13+r12*1]
000070a59add24e5  lea r12, [rax+0x170]
000070a59add24ec  vmovaps [rsp+0x60], xmm1
000070a59add24f2  movups xmm1, [r13+r12*1]
000070a59add24f8  lea r12, [rax+0x1A0]
000070a59add24ff  vmovaps [rsp+0x70], xmm1
000070a59add2505  movups xmm1, [r13+r12*1]
000070a59add250b  lea r12, [rax+0x1B0]
000070a59add2512  vmovaps [rsp+0x80], xmm1
000070a59add251b  movups xmm1, [r13+r12*1]
000070a59add2521  lea r12, [rax+0x1E0]
000070a59add2528  vmovaps [rsp+0x90], xmm1
000070a59add2531  movups xmm1, [r13+r12*1]
000070a59add2537  lea r12, [rax+0x1F0]
000070a59add253e  vmovaps [rsp+0xA0], xmm1
000070a59add2547  movups xmm1, [r13+r12*1]
000070a59add254d  mov qword ptr [r15+0x50], 0x432190
000070a59add2555  lea rax, [r14+0x50]
000070a59add2559  vmovaps [rsp+0xB0], xmm1
000070a59add2562  vmovaps xmm1, [rsp+0x60]
000070a59add2568  movups [r13+rax*1], xmm1
000070a59add256e  lea rax, [r14+0x60]
000070a59add2572  movups [r13+rax*1], xmm5
000070a59add2578  lea rax, [r14+0x40]
000070a59add257c  vmovaps xmm1, [rsp+0x70]
000070a59add2582  movups [r13+rax*1], xmm1
000070a59add2588  lea rax, [r14+0x20]
000070a59add258c  vmovaps xmm1, [rsp+0xA0]
000070a59add2595  movups [r13+rax*1], xmm1
000070a59add259b  lea rax, [r14+0x30]
000070a59add259f  vmovaps xmm1, [rsp+0x90]
000070a59add25a8  movups [r13+rax*1], xmm1
000070a59add25ae  lea rax, [r14+0x10]
000070a59add25b2  vmovaps xmm1, [rsp+0xB0]
000070a59add25bb  movups [r13+rax*1], xmm1
000070a59add25c1  mov rax, [r15+0x40]
000070a59add25c5  vxorps xmm1, xmm1, xmm1
000070a59add25c9  vpbroadcastq xmm1, xmm1
000070a59add25ce  vxorps xmm5, xmm5, xmm5
000070a59add25d2  vpbroadcastq xmm5, xmm5
000070a59add25d7  lea r12, [rax+0x30]
000070a59add25db  mov r11, [r13+r12*1]
000070a59add25e0  lea r12, [rax+0x38]
000070a59add25e4  mov r10, [r13+r12*1]
000070a59add25e9  vmovaps [rsp+0x60], xmm1
000070a59add25ef  movq xmm1, r11
000070a59add25f4  vmovaps [rsp+0x70], xmm1
000070a59add25fa  movq xmm1, r10
000070a59add25ff  vmovaps [rsp+0x90], xmm1
000070a59add2608  vmovaps xmm1, [rsp+0x70]
000070a59add260e  movq xmm1, xmm1
000070a59add2612  vmovaps [rsp+0x70], xmm1
000070a59add2618  vmovaps xmm1, [rsp+0x90]
000070a59add2621  movq xmm1, xmm1
000070a59add2625  vmovaps [rsp+0x90], xmm1
000070a59add262e  movq xmm1, xmm1
000070a59add2632  movaps [r15+0x270], xmm1
000070a59add263a  vmovaps [rsp+0xA0], xmm7
000070a59add2643  vmovaps xmm1, [rsp+0xA0]
000070a59add264c  por xmm7, xmm1
000070a59add2650  lea r12, [rax+0x20]
000070a59add2654  mov r11, [r13+r12*1]
000070a59add2659  lea r12, [rax+0x28]
000070a59add265d  mov r10, [r13+r12*1]
000070a59add2662  movq xmm1, r11
000070a59add2667  vmovaps [rsp+0xA0], xmm1
000070a59add2670  movq xmm1, r10
000070a59add2675  vmovaps [rsp+0xB0], xmm1
000070a59add267e  vmovaps xmm1, [rsp+0xA0]
000070a59add2687  movq xmm1, xmm1
000070a59add268b  vmovaps [rsp+0xA0], xmm1
000070a59add2694  vmovaps xmm1, [rsp+0xB0]
000070a59add269d  movq xmm1, xmm1
000070a59add26a1  vmovaps [rsp+0xB0], xmm2
000070a59add26aa  vmovaps [rsp+0xC0], xmm1
000070a59add26b3  vmovaps xmm1, [rsp+0xB0]
000070a59add26bc  por xmm2, xmm1
000070a59add26c0  vmovaps [rsp+0xB0], xmm3
000070a59add26c9  vmovaps xmm1, [rsp+0xB0]
000070a59add26d2  por xmm3, xmm1
000070a59add26d6  vmovaps [rsp+0xB0], xmm4
000070a59add26df  vmovaps xmm1, [rsp+0xB0]
000070a59add26e8  por xmm4, xmm1
000070a59add26ec  vmovaps [rsp+0xB0], xmm9
000070a59add26f5  vmovaps xmm1, [rsp+0xB0]
000070a59add26fe  por xmm9, xmm1
000070a59add2703  lea r12, [rax+0x10]
000070a59add2707  mov r11, [r13+r12*1]
000070a59add270c  lea r12, [rax+0x18]
000070a59add2710  mov r10, [r13+r12*1]
000070a59add2715  movq xmm1, r11
000070a59add271a  vmovaps [rsp+0xB0], xmm1
000070a59add2723  movq xmm1, r10
000070a59add2728  vmovaps [rsp+0xD0], xmm1
000070a59add2731  vmovaps xmm1, [rsp+0xB0]
000070a59add273a  movq xmm1, xmm1
000070a59add273e  vmovaps [rsp+0xB0], xmm1
000070a59add2747  vmovaps xmm1, [rsp+0xD0]
000070a59add2750  movq xmm1, xmm1
000070a59add2754  vmovaps [rsp+0xD0], xmm1
000070a59add275d  vmovaps xmm1, [rsp+0x80]
000070a59add2766  vmovaps [rsp+0xE0], xmm15
000070a59add276f  vmovaps xmm15, [rsp+0x80]
000070a59add2778  por xmm1, xmm15
000070a59add277d  vmovaps xmm15, [rsp+0x10]
000070a59add2783  vmovaps [rsp+0x80], xmm1
000070a59add278c  vmovaps xmm1, [rsp+0x10]
000070a59add2792  por xmm15, xmm1
000070a59add2797  vmovaps xmm1, [rsp+0x20]
000070a59add279d  vmovaps [rsp+0x10], xmm15
000070a59add27a3  vmovaps xmm15, [rsp+0x20]
000070a59add27a9  por xmm1, xmm15
000070a59add27ae  vmovaps [rsp+0x20], xmm6
000070a59add27b4  vmovaps xmm15, [rsp+0x20]
000070a59add27ba  por xmm6, xmm15
000070a59add27bf  vmovaps [rsp+0x20], xmm11
000070a59add27c5  vmovaps xmm15, [rsp+0x20]
000070a59add27cb  por xmm11, xmm15
000070a59add27d0  vmovaps [rsp+0x20], xmm13
000070a59add27d6  vmovaps xmm15, [rsp+0x20]
000070a59add27dc  por xmm13, xmm15
000070a59add27e1  vmovaps [rsp+0x20], xmm14
000070a59add27e7  vmovaps xmm15, [rsp+0x20]
000070a59add27ed  por xmm14, xmm15
000070a59add27f2  mov r12, [r13+rax*1]
000070a59add27f7  vmovq xmm15, r12
000070a59add27fc  vpbroadcastq xmm15, xmm15
000070a59add2801  vmovaps [rsp+0x20], xmm1
000070a59add2807  vxorps xmm1, xmm1, xmm1
000070a59add280b  vpbroadcastq xmm1, xmm1
000070a59add2810  vmovaps [rsp+0xF0], xmm1
000070a59add2819  movups xmm1, [r13+r14*1]
000070a59add281f  vmovaps [rsp+0x100], xmm1
000070a59add2828  vxorps xmm1, xmm1, xmm1
000070a59add282c  vpbroadcastq xmm1, xmm1
000070a59add2831  lea r12, [rax+0x08]
000070a59add2835  mov rax, [r13+r12*1]
000070a59add283a  vmovaps [rsp+0x110], xmm1
000070a59add2843  movq xmm1, rax
000070a59add2848  movaps [r15+0x240], xmm1
000070a59add2850  mov qword ptr [r15+0x60], 0x432190
000070a59add2858  mov qword ptr [r15+0x58], 0x40
000070a59add2860  vmovaps xmm1, [rsp+0x60]
000070a59add2866  vmovaps [rsp+0x60], xmm15
000070a59add286c  vmovaps xmm15, [rsp+0x100]
000070a59add2875  vmovaps [rsp+0x100], xmm14
000070a59add287e  vmovaps xmm14, [rsp+0x60]
000070a59add2884  vmovaps [rsp+0x60], xmm13
000070a59add288a  vmovaps [rsp+0x120], xmm12
000070a59add2893  movaps xmm13, xmm1
000070a59add2897  vfmadd231pd xmm13, xmm15, xmm14
000070a59add289c  vcmppd xmm12, xmm13, xmm13, 0x03
000070a59add28a2  vptest xmm12, xmm12
000070a59add28a7  jnz 0x000070A59ADD3482
000070a59add28ad  vmovaps xmm1, [rsp+0xE0]
000070a59add28b6  movaps xmm15, xmm5
000070a59add28ba  vfmadd231pd xmm15, xmm1, xmm14
000070a59add28bf  vcmppd xmm12, xmm15, xmm15, 0x03
000070a59add28c5  vptest xmm12, xmm12
000070a59add28ca  jnz 0x000070A59ADD35DB
000070a59add28d0  vmovaps xmm12, [rsp+0x50]
000070a59add28d6  vmovaps xmm5, [rsp+0x50]
000070a59add28dc  por xmm12, xmm5
000070a59add28e1  vmovaps xmm5, [rsp+0x30]
000070a59add28e7  vmovaps [rsp+0x50], xmm1
000070a59add28ed  vmovaps xmm1, [rsp+0x30]
000070a59add28f3  por xmm5, xmm1
000070a59add28f7  vmovaps [rsp+0x30], xmm10
000070a59add28fd  vmovaps xmm1, [rsp+0x30]
000070a59add2903  por xmm10, xmm1
000070a59add2908  vmovaps [rsp+0x30], xmm8
000070a59add290e  vmovaps xmm1, [rsp+0x30]
000070a59add2914  por xmm8, xmm1
000070a59add2919  vmovaps xmm1, [rsp+0x120]
000070a59add2922  vmovaps [rsp+0x30], xmm15
000070a59add2928  vmovaps xmm15, [rsp+0x120]
000070a59add2931  por xmm1, xmm15
000070a59add2936  vmovaps xmm15, [rsp+0x50]
000070a59add293c  vmovaps [rsp+0xE0], xmm1
000070a59add2945  vmovaps xmm1, [rsp+0x50]
000070a59add294b  por xmm15, xmm1
000070a59add2950  lea rax, [r14+0xC0]
000070a59add2957  movups xmm1, [r13+rax*1]
000070a59add295d  xor eax, eax
000070a59add295f  mov r12d, 0x40
000070a59add2965  mov r11d, 0x200
000070a59add296b  cmp r12, r11
000070a59add296e  cmc
000070a59add296f  lahf
000070a59add2970  seto al
000070a59add2973  mov [r15+0x108], eax
000070a59add297a  vmovaps [rsp+0x50], xmm1
000070a59add2980  vmovaps xmm1, [rsp+0xF0]
000070a59add2989  vmovaps [rsp+0xF0], xmm15
000070a59add2992  vmovaps xmm15, [rsp+0x50]
000070a59add2998  vmovaps [rsp+0x50], xmm13
000070a59add299e  vmovaps [rsp+0x120], xmm12
000070a59add29a7  movaps xmm13, xmm1
000070a59add29ab  vfmadd231pd xmm13, xmm15, xmm14
000070a59add29b0  vcmppd xmm12, xmm13, xmm13, 0x03
000070a59add29b6  vptest xmm12, xmm12
000070a59add29bb  jnz 0x000070A59ADD373D
000070a59add29c1  lea rax, [r14+0xB0]
000070a59add29c8  movups xmm1, [r13+rax*1]
000070a59add29ce  vmovaps xmm15, [rsp+0x110]
000070a59add29d7  vmovaps [rsp+0x110], xmm13
000070a59add29e0  movaps xmm12, xmm15
000070a59add29e4  vfmadd231pd xmm12, xmm1, xmm14
000070a59add29e9  vcmppd xmm13, xmm12, xmm12, 0x03
000070a59add29ef  vptest xmm13, xmm13
000070a59add29f4  jnz 0x000070A59ADD38A0
000070a59add29fa  vmovaps xmm1, [rsp+0x100]
000070a59add2a03  vmovaps xmm15, [rsp+0x100]
000070a59add2a0c  por xmm1, xmm15
000070a59add2a11  movaps [r15+0x210], xmm1
000070a59add2a19  vmovaps xmm15, [rsp+0x60]
000070a59add2a1f  vmovaps xmm14, [rsp+0x60]
000070a59add2a25  por xmm15, xmm14
000070a59add2a2a  movaps [r15+0x1C0], xmm15
000070a59add2a32  vmovaps [rsp+0x60], xmm11
000070a59add2a38  vmovaps xmm14, [rsp+0x60]
000070a59add2a3e  por xmm11, xmm14
000070a59add2a43  movaps [r15+0x280], xmm11
000070a59add2a4b  vmovaps [rsp+0x60], xmm6
000070a59add2a51  vmovaps xmm14, [rsp+0x60]
000070a59add2a57  por xmm6, xmm14
000070a59add2a5c  movaps [r15+0x2A0], xmm6
000070a59add2a64  vmovaps xmm14, [rsp+0x20]
000070a59add2a6a  vmovaps xmm13, [rsp+0x20]
000070a59add2a70  por xmm14, xmm13
000070a59add2a75  movaps [r15+0x2E0], xmm14
000070a59add2a7d  vmovaps xmm13, [rsp+0x10]
000070a59add2a83  vmovaps [rsp+0x20], xmm1
000070a59add2a89  vmovaps xmm1, [rsp+0x10]
000070a59add2a8f  por xmm13, xmm1
000070a59add2a94  movaps [r15+0x1F0], xmm13
000070a59add2a9c  vmovaps xmm1, [rsp+0xF0]
000070a59add2aa5  vmovaps [rsp+0x10], xmm15
000070a59add2aab  vmovaps xmm15, [rsp+0xF0]
000070a59add2ab4  por xmm1, xmm15
000070a59add2ab9  movaps [r15+0x250], xmm1
000070a59add2ac1  vmovaps xmm1, [rsp+0xE0]
000070a59add2aca  vmovaps xmm15, [rsp+0xE0]
000070a59add2ad3  por xmm1, xmm15
000070a59add2ad8  movaps [r15+0x260], xmm1
000070a59add2ae0  vmovaps [rsp+0x60], xmm8
000070a59add2ae6  vmovaps xmm15, [rsp+0x60]
000070a59add2aec  por xmm8, xmm15
000070a59add2af1  movaps [r15+0x290], xmm8
000070a59add2af9  vmovaps [rsp+0x60], xmm10
000070a59add2aff  vmovaps xmm15, [rsp+0x60]
000070a59add2b05  por xmm10, xmm15
000070a59add2b0a  movaps [r15+0x2C0], xmm10
000070a59add2b12  movq xmm15, qword ptr [r15+0x240]
000070a59add2b1b  vmovaps [rsp+0x60], xmm15
000070a59add2b21  vpermilpd xmm15, xmm15, 0x00
000070a59add2b27  vmovaps [rsp+0xE0], xmm1
000070a59add2b30  vmovaps xmm1, [rsp+0x50]
000070a59add2b36  vmovaps [rsp+0x50], xmm15
000070a59add2b3c  vmovaps xmm15, [rsp+0x20]
000070a59add2b42  vmovaps [rsp+0x20], xmm14
000070a59add2b48  vmovaps xmm14, [rsp+0x50]
000070a59add2b4e  vmovaps [rsp+0x50], xmm13
000070a59add2b54  vmovaps [rsp+0xF0], xmm12
000070a59add2b5d  movaps xmm13, xmm1
000070a59add2b61  vfmadd231pd xmm13, xmm15, xmm14
000070a59add2b66  vcmppd xmm12, xmm13, xmm13, 0x03
000070a59add2b6c  vptest xmm12, xmm12
000070a59add2b71  jnz 0x000070A59ADD39F9
000070a59add2b77  vmovaps xmm1, [rsp+0x60]
000070a59add2b7d  vpermilpd xmm1, xmm1, 0x00
000070a59add2b83  vmovaps xmm15, [rsp+0x110]
000070a59add2b8c  vmovaps xmm14, [rsp+0x20]
000070a59add2b92  vmovaps [rsp+0x20], xmm13
000070a59add2b98  movaps xmm12, xmm15
000070a59add2b9c  vfmadd231pd xmm12, xmm14, xmm1
000070a59add2ba1  vcmppd xmm13, xmm12, xmm12, 0x03
000070a59add2ba7  vptest xmm13, xmm13
000070a59add2bac  jnz 0x000070A59ADD3B52
000070a59add2bb2  vmovaps xmm1, [rsp+0x60]
000070a59add2bb8  vpermilpd xmm1, xmm1, 0x00
000070a59add2bbe  vmovaps xmm15, [rsp+0x30]
000070a59add2bc4  vmovaps xmm14, [rsp+0x10]
000070a59add2bca  vmovaps [rsp+0x10], xmm12
000070a59add2bd0  movaps xmm13, xmm15
000070a59add2bd4  vfmadd231pd xmm13, xmm14, xmm1
000070a59add2bd9  vcmppd xmm12, xmm13, xmm13, 0x03
000070a59add2bdf  vptest xmm12, xmm12
000070a59add2be4  jnz 0x000070A59ADD3CAB
000070a59add2bea  vmovaps [rsp+0x30], xmm5
000070a59add2bf0  vmovaps xmm1, [rsp+0x30]
000070a59add2bf6  por xmm5, xmm1
000070a59add2bfa  movaps [r15+0x1D0], xmm5
000070a59add2c02  vmovaps xmm1, [rsp+0x60]
000070a59add2c08  vpermilpd xmm1, xmm1, 0x00
000070a59add2c0e  vmovaps xmm15, [rsp+0xF0]
000070a59add2c17  vmovaps xmm14, [rsp+0x50]
000070a59add2c1d  vmovaps [rsp+0x30], xmm13
000070a59add2c23  movaps xmm12, xmm15
000070a59add2c27  vfmadd231pd xmm12, xmm14, xmm1
000070a59add2c2c  vcmppd xmm13, xmm12, xmm12, 0x03
000070a59add2c32  vptest xmm13, xmm13
000070a59add2c37  jnz 0x000070A59ADD3E04
000070a59add2c3d  vmovaps xmm1, [rsp+0x80]
000070a59add2c46  vmovaps xmm15, [rsp+0x80]
000070a59add2c4f  por xmm1, xmm15
000070a59add2c54  movaps [r15+0x200], xmm1
000070a59add2c5c  vmovaps xmm15, [rsp+0x120]
000070a59add2c65  vmovaps xmm14, [rsp+0x120]
000070a59add2c6e  por xmm15, xmm14
000070a59add2c73  movaps [r15+0x1E0], xmm15
000070a59add2c7b  vmovaps [rsp+0x50], xmm4
000070a59add2c81  vmovaps xmm13, [rsp+0x50]
000070a59add2c87  por xmm4, xmm13
000070a59add2c8c  movaps [r15+0x2B0], xmm4
000070a59add2c94  vmovaps [rsp+0x50], xmm3
000070a59add2c9a  vmovaps xmm13, [rsp+0x50]
000070a59add2ca0  por xmm3, xmm13
000070a59add2ca5  movaps [r15+0x300], xmm3
000070a59add2cad  vmovaps xmm15, [rsp+0xB0]
000070a59add2cb6  vpermilpd xmm15, xmm15, 0x00
000070a59add2cbc  vmovaps xmm3, [rsp+0x20]
000070a59add2cc2  vmovaps [rsp+0x20], xmm1
000070a59add2cc8  vmovaps xmm1, [rsp+0xE0]
000070a59add2cd1  vmovaps [rsp+0x50], xmm14
000070a59add2cd7  vmovaps [rsp+0x60], xmm13
000070a59add2cdd  movaps xmm14, xmm3
000070a59add2ce1  vfmadd231pd xmm14, xmm1, xmm15
000070a59add2ce6  vcmppd xmm13, xmm14, xmm14, 0x03
000070a59add2cec  vptest xmm13, xmm13
000070a59add2cf1  jnz 0x000070A59ADD3F5D
000070a59add2cf7  vmovaps xmm1, [rsp+0xB0]
000070a59add2d00  vpermilpd xmm1, xmm1, 0x00
000070a59add2d06  vmovaps xmm15, [rsp+0x10]
000070a59add2d0c  movaps xmm13, xmm15
000070a59add2d10  vfmadd231pd xmm13, xmm10, xmm1
000070a59add2d15  vcmppd xmm3, xmm13, xmm13, 0x03
000070a59add2d1b  vptest xmm3, xmm3
000070a59add2d20  jnz 0x000070A59ADD40B5
000070a59add2d26  vmovaps xmm1, [rsp+0xB0]
000070a59add2d2f  vpermilpd xmm1, xmm1, 0x00
000070a59add2d35  vmovaps xmm15, [rsp+0x30]
000070a59add2d3b  movaps xmm10, xmm15
000070a59add2d3f  vfmadd231pd xmm10, xmm11, xmm1
000070a59add2d44  vcmppd xmm3, xmm10, xmm10, 0x03
000070a59add2d4a  vptest xmm3, xmm3
000070a59add2d4f  jnz 0x000070A59ADD420E
000070a59add2d55  vmovaps xmm1, [rsp+0xB0]
000070a59add2d5e  vpermilpd xmm1, xmm1, 0x00
000070a59add2d64  movaps xmm15, xmm12
000070a59add2d68  vfmadd231pd xmm15, xmm5, xmm1
000070a59add2d6d  vcmppd xmm11, xmm15, xmm15, 0x03
000070a59add2d73  vptest xmm11, xmm11
000070a59add2d78  jnz 0x000070A59ADD4367
000070a59add2d7e  vmovaps [rsp+0x10], xmm9
000070a59add2d84  vmovaps xmm1, [rsp+0x10]
000070a59add2d8a  por xmm9, xmm1
000070a59add2d8f  movaps [r15+0x180], xmm9
000070a59add2d97  vmovaps [rsp+0x10], xmm2
000070a59add2d9d  vmovaps xmm1, [rsp+0x10]
000070a59add2da3  por xmm2, xmm1
000070a59add2da7  movaps [r15+0x2D0], xmm2
000070a59add2daf  vmovaps xmm12, [rsp+0xD0]
000070a59add2db8  vpermilpd xmm12, xmm12, 0x00
000070a59add2dbe  vmovaps xmm11, [rsp+0x60]
000070a59add2dc4  movaps xmm5, xmm13
000070a59add2dc8  vfmadd231pd xmm5, xmm11, xmm12
000070a59add2dcd  vcmppd xmm3, xmm5, xmm5, 0x03
000070a59add2dd2  vptest xmm3, xmm3
000070a59add2dd7  jnz 0x000070A59ADD44BF
000070a59add2ddd  vmovaps xmm13, [rsp+0xD0]
000070a59add2de6  vpermilpd xmm13, xmm13, 0x00
000070a59add2dec  movaps xmm12, xmm14
000070a59add2df0  vfmadd231pd xmm12, xmm9, xmm13
000070a59add2df5  vcmppd xmm11, xmm12, xmm12, 0x03
000070a59add2dfb  vptest xmm11, xmm11
000070a59add2e00  jnz 0x000070A59ADD4617
000070a59add2e06  lea rax, [r14+0x80]
000070a59add2e0d  movups xmm14, [r13+rax*1]
000070a59add2e13  movaps [r15+0x2F0], xmm14
000070a59add2e1b  vmovaps xmm13, [rsp+0xD0]
000070a59add2e24  vpermilpd xmm13, xmm13, 0x00
000070a59add2e2a  movaps xmm11, xmm10
000070a59add2e2e  vfmadd231pd xmm11, xmm8, xmm13
000070a59add2e33  vcmppd xmm9, xmm11, xmm11, 0x03
000070a59add2e39  vptest xmm9, xmm9
000070a59add2e3e  jnz 0x000070A59ADD477B
000070a59add2e44  vmovaps xmm13, [rsp+0xD0]
000070a59add2e4d  vpermilpd xmm13, xmm13, 0x00
000070a59add2e53  movaps xmm10, xmm15
000070a59add2e57  vfmadd231pd xmm10, xmm1, xmm13
000070a59add2e5c  vcmppd xmm9, xmm10, xmm10, 0x03
000070a59add2e62  vptest xmm9, xmm9
000070a59add2e67  jnz 0x000070A59ADD48D5
000070a59add2e6d  vmovaps [rsp+0x10], xmm7
000070a59add2e73  vmovaps xmm1, [rsp+0x10]
000070a59add2e79  por xmm7, xmm1
000070a59add2e7d  movaps [r15+0x160], xmm7
000070a59add2e85  lea rax, [r14+0x40]
000070a59add2e89  movups xmm1, [r13+rax*1]
000070a59add2e8f  lea rax, [r14+0x50]
000070a59add2e93  movups xmm15, [r13+rax*1]
000070a59add2e99  movaps [r15+0x1B0], xmm1
000070a59add2ea1  movaps [r15+0x1A0], xmm15
000070a59add2ea9  vmovaps xmm13, [rsp+0xA0]
000070a59add2eb2  vpermilpd xmm13, xmm13, 0x00
000070a59add2eb8  vmovaps xmm9, [rsp+0x40]
000070a59add2ebe  movaps xmm8, xmm5
000070a59add2ec2  vfmadd231pd xmm8, xmm9, xmm13
000070a59add2ec7  vcmppd xmm3, xmm8, xmm8, 0x03
000070a59add2ecd  vptest xmm3, xmm3
000070a59add2ed2  jnz 0x000070A59ADD4A42
000070a59add2ed8  vmovaps xmm13, [rsp+0xA0]
000070a59add2ee1  vpermilpd xmm13, xmm13, 0x00
000070a59add2ee7  movaps xmm9, xmm12
000070a59add2eeb  vfmadd231pd xmm9, xmm7, xmm13
000070a59add2ef0  vcmppd xmm5, xmm9, xmm9, 0x03
000070a59add2ef6  vptest xmm5, xmm5
000070a59add2efb  jnz 0x000070A59ADD4B9B
000070a59add2f01  vmovaps xmm13, [rsp+0xA0]
000070a59add2f0a  vpermilpd xmm13, xmm13, 0x00
000070a59add2f10  movaps xmm12, xmm11
000070a59add2f14  vfmadd231pd xmm12, xmm6, xmm13
000070a59add2f19  vcmppd xmm7, xmm12, xmm12, 0x03
000070a59add2f1f  vptest xmm7, xmm7
000070a59add2f24  jnz 0x000070A59ADD4CF4
000070a59add2f2a  vmovaps xmm13, [rsp+0xA0]
000070a59add2f33  vpermilpd xmm13, xmm13, 0x00
000070a59add2f39  vmovaps xmm11, [rsp+0x50]
000070a59add2f3f  movaps xmm7, xmm10
000070a59add2f43  vfmadd231pd xmm7, xmm11, xmm13
000070a59add2f48  vcmppd xmm6, xmm7, xmm7, 0x03
000070a59add2f4d  vptest xmm6, xmm6
000070a59add2f52  jnz 0x000070A59ADD4E4D
000070a59add2f58  lea rax, [r14+0x60]
000070a59add2f5c  movups xmm13, [r13+rax*1]
000070a59add2f62  lea rax, [r14+0x70]
000070a59add2f66  movups xmm11, [r13+rax*1]
000070a59add2f6c  movaps [r15+0x150], xmm13
000070a59add2f74  movaps [r15+0x120], xmm11
000070a59add2f7c  vmovaps xmm10, [rsp+0xC0]
000070a59add2f85  vpermilpd xmm10, xmm10, 0x00
000070a59add2f8b  movaps xmm6, xmm8
000070a59add2f8f  vfmadd231pd xmm6, xmm15, xmm10
000070a59add2f94  vcmppd xmm5, xmm6, xmm6, 0x03
000070a59add2f99  vptest xmm5, xmm5
000070a59add2f9e  jnz 0x000070A59ADD4FB9
000070a59add2fa4  vmovaps xmm15, [rsp+0xC0]
000070a59add2fad  vpermilpd xmm15, xmm15, 0x00
000070a59add2fb3  movaps xmm10, xmm9
000070a59add2fb7  vfmadd231pd xmm10, xmm13, xmm15
000070a59add2fbc  vcmppd xmm8, xmm10, xmm10, 0x03
000070a59add2fc2  vptest xmm8, xmm8
000070a59add2fc7  jnz 0x000070A59ADD5111
000070a59add2fcd  vmovaps xmm15, [rsp+0xC0]
000070a59add2fd6  vpermilpd xmm15, xmm15, 0x00
000070a59add2fdc  movaps xmm13, xmm12
000070a59add2fe0  vfmadd231pd xmm13, xmm4, xmm15
000070a59add2fe5  vcmppd xmm9, xmm13, xmm13, 0x03
000070a59add2feb  vptest xmm9, xmm9
000070a59add2ff0  jnz 0x000070A59ADD526B
000070a59add2ff6  vmovaps xmm15, [rsp+0xC0]
000070a59add2fff  vpermilpd xmm15, xmm15, 0x00
000070a59add3005  movaps xmm12, xmm7
000070a59add3009  vfmadd231pd xmm12, xmm1, xmm15
000070a59add300e  vcmppd xmm9, xmm12, xmm12, 0x03
000070a59add3014  vptest xmm9, xmm9
000070a59add3019  jnz 0x000070A59ADD53C4
000070a59add301f  lea rax, [r14+0x20]
000070a59add3023  movups xmm1, [r13+rax*1]
000070a59add3029  lea rax, [r14+0x30]
000070a59add302d  movups xmm15, [r13+rax*1]
000070a59add3033  vmovaps xmm9, [rsp+0x70]
000070a59add3039  vpermilpd xmm9, xmm9, 0x00
000070a59add303f  vmovaps xmm8, [rsp+0x20]
000070a59add3045  movaps xmm7, xmm6
000070a59add3048  vfmadd231pd xmm7, xmm8, xmm9
000070a59add304d  vcmppd xmm5, xmm7, xmm7, 0x03
000070a59add3052  vptest xmm5, xmm5
000070a59add3057  jnz 0x000070A59ADD5530
000070a59add305d  vmovaps xmm9, [rsp+0x70]
000070a59add3063  vpermilpd xmm9, xmm9, 0x00
000070a59add3069  movaps xmm8, xmm10
000070a59add306d  vfmadd231pd xmm8, xmm14, xmm9
000070a59add3072  vcmppd xmm6, xmm8, xmm8, 0x03
000070a59add3078  vptest xmm6, xmm6
000070a59add307d  jnz 0x000070A59ADD5687
000070a59add3083  vmovaps xmm14, [rsp+0x70]
000070a59add3089  vpermilpd xmm14, xmm14, 0x00
000070a59add308f  movaps xmm10, xmm13
000070a59add3093  vfmadd231pd xmm10, xmm11, xmm14
000070a59add3098  vcmppd xmm9, xmm10, xmm10, 0x03
000070a59add309e  vptest xmm9, xmm9
000070a59add30a3  jnz 0x000070A59ADD57E1
000070a59add30a9  vmovaps xmm14, [rsp+0x70]
000070a59add30af  vpermilpd xmm14, xmm14, 0x00
000070a59add30b5  movaps xmm13, xmm12
000070a59add30b9  vfmadd231pd xmm13, xmm15, xmm14
000070a59add30be  vcmppd xmm11, xmm13, xmm13, 0x03
000070a59add30c4  vptest xmm11, xmm11
000070a59add30c9  jnz 0x000070A59ADD593B
000070a59add30cf  lea rax, [r14+0x90]
000070a59add30d6  movups xmm15, [r13+rax*1]
000070a59add30dc  lea rax, [r14+0xA0]
000070a59add30e3  movups xmm14, [r13+rax*1]
000070a59add30e9  movaps [r15+0x140], xmm15
000070a59add30f1  movaps [r15+0x130], xmm14
000070a59add30f9  vmovaps xmm12, [rsp+0x90]
000070a59add3102  vpermilpd xmm12, xmm12, 0x00
000070a59add3108  movaps xmm11, xmm7
000070a59add310c  vfmadd231pd xmm11, xmm1, xmm12
000070a59add3111  vcmppd xmm9, xmm11, xmm11, 0x03
000070a59add3117  vptest xmm9, xmm9
000070a59add311c  jnz 0x000070A59ADD5AA9
000070a59add3122  movaps [r15+0x220], xmm11
000070a59add312a  lea rax, [r14+0x10]
000070a59add312e  movups xmm1, [r13+rax*1]
000070a59add3134  movaps [r15+0x240], xmm1
000070a59add313c  vmovaps xmm12, [rsp+0x90]
000070a59add3145  vpermilpd xmm12, xmm12, 0x00
000070a59add314b  movaps xmm9, xmm8
000070a59add314f  vfmadd231pd xmm9, xmm14, xmm12
000070a59add3154  vcmppd xmm7, xmm9, xmm9, 0x03
000070a59add315a  vptest xmm7, xmm7
000070a59add315f  jnz 0x000070A59ADD5C0B
000070a59add3165  movaps [r15+0x110], xmm9
000070a59add316d  vmovaps xmm14, [rsp+0x90]
000070a59add3176  vpermilpd xmm14, xmm14, 0x00
000070a59add317c  movaps xmm12, xmm10
000070a59add3180  vfmadd231pd xmm12, xmm15, xmm14
000070a59add3185  vcmppd xmm8, xmm12, xmm12, 0x03
000070a59add318b  vptest xmm8, xmm8
000070a59add3190  jnz 0x000070A59ADD5D65
000070a59add3196  movaps [r15+0x170], xmm12
000070a59add319e  vmovaps xmm15, [rsp+0x90]
000070a59add31a7  vpermilpd xmm15, xmm15, 0x00
000070a59add31ad  movaps xmm14, xmm13
000070a59add31b1  vfmadd231pd xmm14, xmm1, xmm15
000070a59add31b6  vcmppd xmm10, xmm14, xmm14, 0x03
000070a59add31bc  vptest xmm10, xmm10
000070a59add31c1  jnz 0x000070A59ADD5EBF
000070a59add31c7  movaps [r15+0x230], xmm14
000070a59add31cf  mov eax, 0x432190
000070a59add31d4  movups [r13+rax*1], xmm9
000070a59add31da  mov eax, 0x4321A0
000070a59add31df  movups [r13+rax*1], xmm12
000070a59add31e5  mov eax, 0x4321B0
000070a59add31ea  movups [r13+rax*1], xmm11
000070a59add31f0  mov eax, 0x4321C0
000070a59add31f5  movups [r13+rax*1], xmm14
000070a59add31fb  mov eax, [r15+0x108]
000070a59add3202  sahf
000070a59add3203  jnz 0x000070A59ADD3235
000070a59add3205  cmp dword ptr [r15+0x318], 0x00
000070a59add320d  jz 0x000070A59ADD9950
000070a59add3213  nop [rax+rax*1], ax
000070a59add321c  nop [rax+rax*1], eax
000070a59add3224  mov eax, 0x410664
000070a59add3229  mov [r15+0x100], rax
000070a59add3230  jmp 0x000070A59ABFE110
000070a59add3235  cmp dword ptr [r15+0x318], 0x00
000070a59add323d  jz 0x000070A59ADD6050
000070a59add3243  nop [rax+rax*1], ax
000070a59add324c  nop [rax+rax*1], eax
000070a59add3254  mov eax, 0x4104F0
000070a59add3259  mov [r15+0x100], rax
000070a59add3260  jmp 0x000070A59ABFE110
000070a59add3265  int3
000070a59add3266  call 0x000070A59ABFF430
000070a59add326b  jmp 0x000070A59ADD230A
000070a59add3270  call 0x000070A59ACE5820
000070a59add3275  jmp 0x000070A59ADD2314
000070a59add327a  call 0x000070A59ACE45A0
000070a59add327f  jmp 0x000070A59ADD2326
000070a59add3284  call 0x000070A59ACE3320
000070a59add3289  jmp 0x000070A59ADD2330
000070a59add328e  call 0x000070A59ACE20A0
000070a59add3293  jmp 0x000070A59ADD233D
000070a59add3298  call 0x000070A59ACE0E30
000070a59add329d  jmp 0x000070A59ADD234A
000070a59add32a2  call 0x000070A59ACD6600
000070a59add32a7  jmp 0x000070A59ADD2357
000070a59add32ac  call 0x000070A59ACB52F0
000070a59add32b1  jmp 0x000070A59ADD2361
000070a59add32b6  call 0x000070A59ACBE9C0
000070a59add32bb  jmp 0x000070A59ADD236B
000070a59add32c0  call 0x000070A59ACBD750
000070a59add32c5  jmp 0x000070A59ADD2378
000070a59add32ca  call 0x000070A59ACBC4E0
000070a59add32cf  jmp 0x000070A59ADD2385
000070a59add32d4  call 0x000070A59ACBB270
000070a59add32d9  jmp 0x000070A59ADD2392
000070a59add32de  call 0x000070A59ACBA000
000070a59add32e3  jmp 0x000070A59ADD239F
000070a59add32e8  call 0x000070A59ACB8D90
000070a59add32ed  jmp 0x000070A59ADD23AC
000070a59add32f2  call 0x000070A59ACB8A20
000070a59add32f7  jmp 0x000070A59ADD23B9
000070a59add32fc  call 0x000070A59ACBEAE0
000070a59add3301  jmp 0x000070A59ADD23C6
000070a59add3306  call 0x000070A59ACB5400
000070a59add330b  jmp 0x000070A59ADD23D3
000070a59add3310  call 0x000070A59ACB52F0
000070a59add3315  jmp 0x000070A59ADD23E0
000070a59add331a  call 0x000070A59ACBE9C0
000070a59add331f  jmp 0x000070A59ADD23ED
000070a59add3324  call 0x000070A59ACB77B0
000070a59add3329  jmp 0x000070A59ADD23FA
000070a59add332e  call 0x000070A59ACB6550
000070a59add3333  jmp 0x000070A59ADD2407
000070a59add3338  call 0x000070A59ACB52F0
000070a59add333d  jmp 0x000070A59ADD2417
000070a59add3342  call 0x000070A59ACB52F0
000070a59add3347  jmp 0x000070A59ADD2427
000070a59add334c  call 0x000070A59ACBEAE0
000070a59add3351  jmp 0x000070A59ADD2431
000070a59add3356  call 0x000070A59ACBEAE0
000070a59add335b  jmp 0x000070A59ADD2444
000070a59add3360  call 0x000070A59ACBE9C0
000070a59add3365  jmp 0x000070A59ADD2451
000070a59add336a  call 0x000070A59ACB52F0
000070a59add336f  jmp 0x000070A59ADD2464
000070a59add3374  call 0x000070A59ACB6660
000070a59add3379  jmp 0x000070A59ADD2471
000070a59add337e  call 0x000070A59ACB78C0
000070a59add3383  jmp 0x000070A59ADD247E
000070a59add3388  call 0x000070A59ACB77B0
000070a59add338d  jmp 0x000070A59ADD248B
000070a59add3392  call 0x000070A59ACB6550
000070a59add3397  jmp 0x000070A59ADD2498
000070a59add339c  call 0x000070A59ACB52F0
000070a59add33a1  jmp 0x000070A59ADD24AB
000070a59add33a6  call 0x000070A59ACB52F0
000070a59add33ab  jmp 0x000070A59ADD24BE
000070a59add33b0  call 0x000070A59ACB52F0
000070a59add33b5  jmp 0x000070A59ADD24E5
000070a59add33ba  call 0x000070A59ACB52F0
000070a59add33bf  jmp 0x000070A59ADD24F8
000070a59add33c4  call 0x000070A59ACB52F0
000070a59add33c9  jmp 0x000070A59ADD250B
000070a59add33ce  call 0x000070A59ACB52F0
000070a59add33d3  jmp 0x000070A59ADD2521
000070a59add33d8  call 0x000070A59ACB52F0
000070a59add33dd  jmp 0x000070A59ADD2537
000070a59add33e2  call 0x000070A59ACB52F0
000070a59add33e7  jmp 0x000070A59ADD254D
000070a59add33ec  call 0x000070A59ABFF540
000070a59add33f1  jmp 0x000070A59ADD256E
000070a59add33f6  call 0x000070A59AC02FE0
000070a59add33fb  jmp 0x000070A59ADD2578
000070a59add3400  call 0x000070A59ABFF540
000070a59add3405  jmp 0x000070A59ADD2588
000070a59add340a  call 0x000070A59ABFF540
000070a59add340f  jmp 0x000070A59ADD259B
000070a59add3414  call 0x000070A59ABFF540
000070a59add3419  jmp 0x000070A59ADD25AE
000070a59add341e  call 0x000070A59ABFF540
000070a59add3423  jmp 0x000070A59ADD25C1
000070a59add3428  call 0x000070A59ACC0370
000070a59add342d  jmp 0x000070A59ADD25E0
000070a59add3432  call 0x000070A59ACBF100
000070a59add3437  jmp 0x000070A59ADD25E9
000070a59add343c  call 0x000070A59ACC0370
000070a59add3441  jmp 0x000070A59ADD2659
000070a59add3446  call 0x000070A59ACBF100
000070a59add344b  jmp 0x000070A59ADD2662
000070a59add3450  call 0x000070A59ACC0370
000070a59add3455  jmp 0x000070A59ADD270C
000070a59add345a  call 0x000070A59ACBF100
000070a59add345f  jmp 0x000070A59ADD2715
000070a59add3464  call 0x000070A59AC0B720
000070a59add3469  jmp 0x000070A59ADD27F7
000070a59add346e  call 0x000070A59ACD64F0
000070a59add3473  jmp 0x000070A59ADD281F
000070a59add3478  call 0x000070A59ACB47C0
000070a59add347d  jmp 0x000070A59ADD283A
000070a59add3482  sub rsp, 0x08
000070a59add3486  push rax
000070a59add3487  push rcx
000070a59add3488  push rdx
000070a59add3489  push rdi
000070a59add348a  push rsi
000070a59add348b  push r8
000070a59add348d  push r9
000070a59add348f  push r10
000070a59add3491  push r11
000070a59add3493  sub rsp, 0xF0
000070a59add349a  vmovaps [rsp], xmm0
000070a59add349f  vmovaps [rsp+0x10], xmm1
000070a59add34a5  vmovaps [rsp+0x20], xmm2
000070a59add34ab  vmovaps [rsp+0x30], xmm3
000070a59add34b1  vmovaps [rsp+0x40], xmm4
000070a59add34b7  vmovaps [rsp+0x50], xmm5
000070a59add34bd  vmovaps [rsp+0x60], xmm6
000070a59add34c3  vmovaps [rsp+0x70], xmm7
000070a59add34c9  vmovaps [rsp+0x80], xmm8
000070a59add34d2  vmovaps [rsp+0x90], xmm9
000070a59add34db  vmovaps [rsp+0xA0], xmm10
000070a59add34e4  vmovaps [rsp+0xB0], xmm11
000070a59add34ed  vmovaps [rsp+0xC0], xmm12
000070a59add34f6  vmovaps [rsp+0xD0], xmm14
000070a59add34ff  vmovaps [rsp+0xE0], xmm15
000070a59add3508  sub rsp, 0x40
000070a59add350c  lea rdi, [rsp]
000070a59add3510  lea rsi, [rsp+0x10]
000070a59add3515  lea rdx, [rsp+0x20]
000070a59add351a  lea rcx, [rsp+0x30]
000070a59add351f  mov r8d, 0x00
000070a59add3525  lea r9, [r15+0x3A8]
000070a59add352c  movaps [rdi], xmm13
000070a59add3530  movaps [rsi], xmm1
000070a59add3533  movaps [rdx], xmm15
000070a59add3537  movaps [rcx], xmm14
000070a59add353b  mov rax, 0x622906D8FA50
000070a59add3545  call rax
000070a59add3547  movaps xmm13, [rsp]
000070a59add354c  add rsp, 0x40
000070a59add3550  vmovaps xmm0, [rsp]
000070a59add3555  vmovaps xmm1, [rsp+0x10]
000070a59add355b  vmovaps xmm2, [rsp+0x20]
000070a59add3561  vmovaps xmm3, [rsp+0x30]
000070a59add3567  vmovaps xmm4, [rsp+0x40]
000070a59add356d  vmovaps xmm5, [rsp+0x50]
000070a59add3573  vmovaps xmm6, [rsp+0x60]
000070a59add3579  vmovaps xmm7, [rsp+0x70]
000070a59add357f  vmovaps xmm8, [rsp+0x80]
000070a59add3588  vmovaps xmm9, [rsp+0x90]
000070a59add3591  vmovaps xmm10, [rsp+0xA0]
000070a59add359a  vmovaps xmm11, [rsp+0xB0]
000070a59add35a3  vmovaps xmm12, [rsp+0xC0]
000070a59add35ac  vmovaps xmm14, [rsp+0xD0]
000070a59add35b5  vmovaps xmm15, [rsp+0xE0]
000070a59add35be  add rsp, 0xF0
000070a59add35c5  pop r11
000070a59add35c7  pop r10
000070a59add35c9  pop r9
000070a59add35cb  pop r8
000070a59add35cd  pop rsi
000070a59add35ce  pop rdi
000070a59add35cf  pop rdx
000070a59add35d0  pop rcx
000070a59add35d1  pop rax
000070a59add35d2  add rsp, 0x08
000070a59add35d6  jmp 0x000070A59ADD28AD
000070a59add35db  sub rsp, 0x08
000070a59add35df  push rax
000070a59add35e0  push rcx
000070a59add35e1  push rdx
000070a59add35e2  push rdi
000070a59add35e3  push rsi
000070a59add35e4  push r8
000070a59add35e6  push r9
000070a59add35e8  push r10
000070a59add35ea  push r11
000070a59add35ec  sub rsp, 0xF0
000070a59add35f3  vmovaps [rsp], xmm0
000070a59add35f8  vmovaps [rsp+0x10], xmm1
000070a59add35fe  vmovaps [rsp+0x20], xmm2
000070a59add3604  vmovaps [rsp+0x30], xmm3
000070a59add360a  vmovaps [rsp+0x40], xmm4
000070a59add3610  vmovaps [rsp+0x50], xmm5
000070a59add3616  vmovaps [rsp+0x60], xmm6
000070a59add361c  vmovaps [rsp+0x70], xmm7
000070a59add3622  vmovaps [rsp+0x80], xmm8
000070a59add362b  vmovaps [rsp+0x90], xmm9
000070a59add3634  vmovaps [rsp+0xA0], xmm10
000070a59add363d  vmovaps [rsp+0xB0], xmm11
000070a59add3646  vmovaps [rsp+0xC0], xmm12
000070a59add364f  vmovaps [rsp+0xD0], xmm13
000070a59add3658  vmovaps [rsp+0xE0], xmm14
000070a59add3661  sub rsp, 0x40
000070a59add3665  lea rdi, [rsp]
000070a59add3669  lea rsi, [rsp+0x10]
000070a59add366e  lea rdx, [rsp+0x20]
000070a59add3673  lea rcx, [rsp+0x30]
000070a59add3678  mov r8d, 0x00
000070a59add367e  lea r9, [r15+0x3A8]
000070a59add3685  movaps [rdi], xmm15
000070a59add3689  movaps [rsi], xmm5
000070a59add368c  movaps [rdx], xmm1
000070a59add368f  movaps [rcx], xmm14
000070a59add3693  mov rax, 0x622906D8FA50
000070a59add369d  call rax
000070a59add369f  movaps xmm15, [rsp]
000070a59add36a4  add rsp, 0x40
000070a59add36a8  vmovaps xmm0, [rsp]
000070a59add36ad  vmovaps xmm1, [rsp+0x10]
000070a59add36b3  vmovaps xmm2, [rsp+0x20]
000070a59add36b9  vmovaps xmm3, [rsp+0x30]
000070a59add36bf  vmovaps xmm4, [rsp+0x40]
000070a59add36c5  vmovaps xmm5, [rsp+0x50]
000070a59add36cb  vmovaps xmm6, [rsp+0x60]
000070a59add36d1  vmovaps xmm7, [rsp+0x70]
000070a59add36d7  vmovaps xmm8, [rsp+0x80]
000070a59add36e0  vmovaps xmm9, [rsp+0x90]
000070a59add36e9  vmovaps xmm10, [rsp+0xA0]
000070a59add36f2  vmovaps xmm11, [rsp+0xB0]
000070a59add36fb  vmovaps xmm12, [rsp+0xC0]
000070a59add3704  vmovaps xmm13, [rsp+0xD0]
000070a59add370d  vmovaps xmm14, [rsp+0xE0]
000070a59add3716  add rsp, 0xF0
000070a59add371d  pop r11
000070a59add371f  pop r10
000070a59add3721  pop r9
000070a59add3723  pop r8
000070a59add3725  pop rsi
000070a59add3726  pop rdi
000070a59add3727  pop rdx
000070a59add3728  pop rcx
000070a59add3729  pop rax
000070a59add372a  add rsp, 0x08
000070a59add372e  jmp 0x000070A59ADD28D0
000070a59add3733  call 0x000070A59ABFF430
000070a59add3738  jmp 0x000070A59ADD295D
000070a59add373d  sub rsp, 0x08
000070a59add3741  push rax
000070a59add3742  push rcx
000070a59add3743  push rdx
000070a59add3744  push rdi
000070a59add3745  push rsi
000070a59add3746  push r8
000070a59add3748  push r9
000070a59add374a  push r10
000070a59add374c  push r11
000070a59add374e  sub rsp, 0xF0
000070a59add3755  vmovaps [rsp], xmm0
000070a59add375a  vmovaps [rsp+0x10], xmm1
000070a59add3760  vmovaps [rsp+0x20], xmm2
000070a59add3766  vmovaps [rsp+0x30], xmm3
000070a59add376c  vmovaps [rsp+0x40], xmm4
000070a59add3772  vmovaps [rsp+0x50], xmm5
000070a59add3778  vmovaps [rsp+0x60], xmm6
000070a59add377e  vmovaps [rsp+0x70], xmm7
000070a59add3784  vmovaps [rsp+0x80], xmm8
000070a59add378d  vmovaps [rsp+0x90], xmm9
000070a59add3796  vmovaps [rsp+0xA0], xmm10
000070a59add379f  vmovaps [rsp+0xB0], xmm11
000070a59add37a8  vmovaps [rsp+0xC0], xmm12
000070a59add37b1  vmovaps [rsp+0xD0], xmm14
000070a59add37ba  vmovaps [rsp+0xE0], xmm15
000070a59add37c3  sub rsp, 0x40
000070a59add37c7  lea rdi, [rsp]
000070a59add37cb  lea rsi, [rsp+0x10]
000070a59add37d0  lea rdx, [rsp+0x20]
000070a59add37d5  lea rcx, [rsp+0x30]
000070a59add37da  mov r8d, 0x00
000070a59add37e0  lea r9, [r15+0x3A8]
000070a59add37e7  movaps [rdi], xmm13
000070a59add37eb  movaps [rsi], xmm1
000070a59add37ee  movaps [rdx], xmm15
000070a59add37f2  movaps [rcx], xmm14
000070a59add37f6  mov rax, 0x622906D8FA50
000070a59add3800  call rax
000070a59add3802  movaps xmm13, [rsp]
000070a59add3807  add rsp, 0x40
000070a59add380b  vmovaps xmm0, [rsp]
000070a59add3810  vmovaps xmm1, [rsp+0x10]
000070a59add3816  vmovaps xmm2, [rsp+0x20]
000070a59add381c  vmovaps xmm3, [rsp+0x30]
000070a59add3822  vmovaps xmm4, [rsp+0x40]
000070a59add3828  vmovaps xmm5, [rsp+0x50]
000070a59add382e  vmovaps xmm6, [rsp+0x60]
000070a59add3834  vmovaps xmm7, [rsp+0x70]
000070a59add383a  vmovaps xmm8, [rsp+0x80]
000070a59add3843  vmovaps xmm9, [rsp+0x90]
000070a59add384c  vmovaps xmm10, [rsp+0xA0]
000070a59add3855  vmovaps xmm11, [rsp+0xB0]
000070a59add385e  vmovaps xmm12, [rsp+0xC0]
000070a59add3867  vmovaps xmm14, [rsp+0xD0]
000070a59add3870  vmovaps xmm15, [rsp+0xE0]
000070a59add3879  add rsp, 0xF0
000070a59add3880  pop r11
000070a59add3882  pop r10
000070a59add3884  pop r9
000070a59add3886  pop r8
000070a59add3888  pop rsi
000070a59add3889  pop rdi
000070a59add388a  pop rdx
000070a59add388b  pop rcx
000070a59add388c  pop rax
000070a59add388d  add rsp, 0x08
000070a59add3891  jmp 0x000070A59ADD29C1
000070a59add3896  call 0x000070A59ABFF430
000070a59add389b  jmp 0x000070A59ADD29CE
000070a59add38a0  sub rsp, 0x08
000070a59add38a4  push rax
000070a59add38a5  push rcx
000070a59add38a6  push rdx
000070a59add38a7  push rdi
000070a59add38a8  push rsi
000070a59add38a9  push r8
000070a59add38ab  push r9
000070a59add38ad  push r10
000070a59add38af  push r11
000070a59add38b1  sub rsp, 0xF0
000070a59add38b8  vmovaps [rsp], xmm0
000070a59add38bd  vmovaps [rsp+0x10], xmm1
000070a59add38c3  vmovaps [rsp+0x20], xmm2
000070a59add38c9  vmovaps [rsp+0x30], xmm3
000070a59add38cf  vmovaps [rsp+0x40], xmm4
000070a59add38d5  vmovaps [rsp+0x50], xmm5
000070a59add38db  vmovaps [rsp+0x60], xmm6
000070a59add38e1  vmovaps [rsp+0x70], xmm7
000070a59add38e7  vmovaps [rsp+0x80], xmm8
000070a59add38f0  vmovaps [rsp+0x90], xmm9
000070a59add38f9  vmovaps [rsp+0xA0], xmm10
000070a59add3902  vmovaps [rsp+0xB0], xmm11
000070a59add390b  vmovaps [rsp+0xC0], xmm13
000070a59add3914  vmovaps [rsp+0xD0], xmm14
000070a59add391d  vmovaps [rsp+0xE0], xmm15
000070a59add3926  sub rsp, 0x40
000070a59add392a  lea rdi, [rsp]
000070a59add392e  lea rsi, [rsp+0x10]
000070a59add3933  lea rdx, [rsp+0x20]
000070a59add3938  lea rcx, [rsp+0x30]
000070a59add393d  mov r8d, 0x00
000070a59add3943  lea r9, [r15+0x3A8]
000070a59add394a  movaps [rdi], xmm12
000070a59add394e  movaps [rsi], xmm15
000070a59add3952  movaps [rdx], xmm1
000070a59add3955  movaps [rcx], xmm14
000070a59add3959  mov rax, 0x622906D8FA50
000070a59add3963  call rax
000070a59add3965  movaps xmm12, [rsp]
000070a59add396a  add rsp, 0x40
000070a59add396e  vmovaps xmm0, [rsp]
000070a59add3973  vmovaps xmm1, [rsp+0x10]
000070a59add3979  vmovaps xmm2, [rsp+0x20]
000070a59add397f  vmovaps xmm3, [rsp+0x30]
000070a59add3985  vmovaps xmm4, [rsp+0x40]
000070a59add398b  vmovaps xmm5, [rsp+0x50]
000070a59add3991  vmovaps xmm6, [rsp+0x60]
000070a59add3997  vmovaps xmm7, [rsp+0x70]
000070a59add399d  vmovaps xmm8, [rsp+0x80]
000070a59add39a6  vmovaps xmm9, [rsp+0x90]
000070a59add39af  vmovaps xmm10, [rsp+0xA0]
000070a59add39b8  vmovaps xmm11, [rsp+0xB0]
000070a59add39c1  vmovaps xmm13, [rsp+0xC0]
000070a59add39ca  vmovaps xmm14, [rsp+0xD0]
000070a59add39d3  vmovaps xmm15, [rsp+0xE0]
000070a59add39dc  add rsp, 0xF0
000070a59add39e3  pop r11
000070a59add39e5  pop r10
000070a59add39e7  pop r9
000070a59add39e9  pop r8
000070a59add39eb  pop rsi
000070a59add39ec  pop rdi
000070a59add39ed  pop rdx
000070a59add39ee  pop rcx
000070a59add39ef  pop rax
000070a59add39f0  add rsp, 0x08
000070a59add39f4  jmp 0x000070A59ADD29FA
000070a59add39f9  sub rsp, 0x08
000070a59add39fd  push rax
000070a59add39fe  push rcx
000070a59add39ff  push rdx
000070a59add3a00  push rdi
000070a59add3a01  push rsi
000070a59add3a02  push r8
000070a59add3a04  push r9
000070a59add3a06  push r10
000070a59add3a08  push r11
000070a59add3a0a  sub rsp, 0xF0
000070a59add3a11  vmovaps [rsp], xmm0
000070a59add3a16  vmovaps [rsp+0x10], xmm1
000070a59add3a1c  vmovaps [rsp+0x20], xmm2
000070a59add3a22  vmovaps [rsp+0x30], xmm3
000070a59add3a28  vmovaps [rsp+0x40], xmm4
000070a59add3a2e  vmovaps [rsp+0x50], xmm5
000070a59add3a34  vmovaps [rsp+0x60], xmm6
000070a59add3a3a  vmovaps [rsp+0x70], xmm7
000070a59add3a40  vmovaps [rsp+0x80], xmm8
000070a59add3a49  vmovaps [rsp+0x90], xmm9
000070a59add3a52  vmovaps [rsp+0xA0], xmm10
000070a59add3a5b  vmovaps [rsp+0xB0], xmm11
000070a59add3a64  vmovaps [rsp+0xC0], xmm12
000070a59add3a6d  vmovaps [rsp+0xD0], xmm14
000070a59add3a76  vmovaps [rsp+0xE0], xmm15
000070a59add3a7f  sub rsp, 0x40
000070a59add3a83  lea rdi, [rsp]
000070a59add3a87  lea rsi, [rsp+0x10]
000070a59add3a8c  lea rdx, [rsp+0x20]
000070a59add3a91  lea rcx, [rsp+0x30]
000070a59add3a96  mov r8d, 0x00
000070a59add3a9c  lea r9, [r15+0x3A8]
000070a59add3aa3  movaps [rdi], xmm13
000070a59add3aa7  movaps [rsi], xmm1
000070a59add3aaa  movaps [rdx], xmm15
000070a59add3aae  movaps [rcx], xmm14
000070a59add3ab2  mov rax, 0x622906D8FA50
000070a59add3abc  call rax
000070a59add3abe  movaps xmm13, [rsp]
000070a59add3ac3  add rsp, 0x40
000070a59add3ac7  vmovaps xmm0, [rsp]
000070a59add3acc  vmovaps xmm1, [rsp+0x10]
000070a59add3ad2  vmovaps xmm2, [rsp+0x20]
000070a59add3ad8  vmovaps xmm3, [rsp+0x30]
000070a59add3ade  vmovaps xmm4, [rsp+0x40]
000070a59add3ae4  vmovaps xmm5, [rsp+0x50]
000070a59add3aea  vmovaps xmm6, [rsp+0x60]
000070a59add3af0  vmovaps xmm7, [rsp+0x70]
000070a59add3af6  vmovaps xmm8, [rsp+0x80]
000070a59add3aff  vmovaps xmm9, [rsp+0x90]
000070a59add3b08  vmovaps xmm10, [rsp+0xA0]
000070a59add3b11  vmovaps xmm11, [rsp+0xB0]
000070a59add3b1a  vmovaps xmm12, [rsp+0xC0]
000070a59add3b23  vmovaps xmm14, [rsp+0xD0]
000070a59add3b2c  vmovaps xmm15, [rsp+0xE0]
000070a59add3b35  add rsp, 0xF0
000070a59add3b3c  pop r11
000070a59add3b3e  pop r10
000070a59add3b40  pop r9
000070a59add3b42  pop r8
000070a59add3b44  pop rsi
000070a59add3b45  pop rdi
000070a59add3b46  pop rdx
000070a59add3b47  pop rcx
000070a59add3b48  pop rax
000070a59add3b49  add rsp, 0x08
000070a59add3b4d  jmp 0x000070A59ADD2B77
000070a59add3b52  sub rsp, 0x08
000070a59add3b56  push rax
000070a59add3b57  push rcx
000070a59add3b58  push rdx
000070a59add3b59  push rdi
000070a59add3b5a  push rsi
000070a59add3b5b  push r8
000070a59add3b5d  push r9
000070a59add3b5f  push r10
000070a59add3b61  push r11
000070a59add3b63  sub rsp, 0xF0
000070a59add3b6a  vmovaps [rsp], xmm0
000070a59add3b6f  vmovaps [rsp+0x10], xmm1
000070a59add3b75  vmovaps [rsp+0x20], xmm2
000070a59add3b7b  vmovaps [rsp+0x30], xmm3
000070a59add3b81  vmovaps [rsp+0x40], xmm4
000070a59add3b87  vmovaps [rsp+0x50], xmm5
000070a59add3b8d  vmovaps [rsp+0x60], xmm6
000070a59add3b93  vmovaps [rsp+0x70], xmm7
000070a59add3b99  vmovaps [rsp+0x80], xmm8
000070a59add3ba2  vmovaps [rsp+0x90], xmm9
000070a59add3bab  vmovaps [rsp+0xA0], xmm10
000070a59add3bb4  vmovaps [rsp+0xB0], xmm11
000070a59add3bbd  vmovaps [rsp+0xC0], xmm13
000070a59add3bc6  vmovaps [rsp+0xD0], xmm14
000070a59add3bcf  vmovaps [rsp+0xE0], xmm15
000070a59add3bd8  sub rsp, 0x40
000070a59add3bdc  lea rdi, [rsp]
000070a59add3be0  lea rsi, [rsp+0x10]
000070a59add3be5  lea rdx, [rsp+0x20]
000070a59add3bea  lea rcx, [rsp+0x30]
000070a59add3bef  mov r8d, 0x00
000070a59add3bf5  lea r9, [r15+0x3A8]
000070a59add3bfc  movaps [rdi], xmm12
000070a59add3c00  movaps [rsi], xmm15
000070a59add3c04  movaps [rdx], xmm14
000070a59add3c08  movaps [rcx], xmm1
000070a59add3c0b  mov rax, 0x622906D8FA50
000070a59add3c15  call rax
000070a59add3c17  movaps xmm12, [rsp]
000070a59add3c1c  add rsp, 0x40
000070a59add3c20  vmovaps xmm0, [rsp]
000070a59add3c25  vmovaps xmm1, [rsp+0x10]
000070a59add3c2b  vmovaps xmm2, [rsp+0x20]
000070a59add3c31  vmovaps xmm3, [rsp+0x30]
000070a59add3c37  vmovaps xmm4, [rsp+0x40]
000070a59add3c3d  vmovaps xmm5, [rsp+0x50]
000070a59add3c43  vmovaps xmm6, [rsp+0x60]
000070a59add3c49  vmovaps xmm7, [rsp+0x70]
000070a59add3c4f  vmovaps xmm8, [rsp+0x80]
000070a59add3c58  vmovaps xmm9, [rsp+0x90]
000070a59add3c61  vmovaps xmm10, [rsp+0xA0]
000070a59add3c6a  vmovaps xmm11, [rsp+0xB0]
000070a59add3c73  vmovaps xmm13, [rsp+0xC0]
000070a59add3c7c  vmovaps xmm14, [rsp+0xD0]
000070a59add3c85  vmovaps xmm15, [rsp+0xE0]
000070a59add3c8e  add rsp, 0xF0
000070a59add3c95  pop r11
000070a59add3c97  pop r10
000070a59add3c99  pop r9
000070a59add3c9b  pop r8
000070a59add3c9d  pop rsi
000070a59add3c9e  pop rdi
000070a59add3c9f  pop rdx
000070a59add3ca0  pop rcx
000070a59add3ca1  pop rax
000070a59add3ca2  add rsp, 0x08
000070a59add3ca6  jmp 0x000070A59ADD2BB2
000070a59add3cab  sub rsp, 0x08
000070a59add3caf  push rax
000070a59add3cb0  push rcx
000070a59add3cb1  push rdx
000070a59add3cb2  push rdi
000070a59add3cb3  push rsi
000070a59add3cb4  push r8
000070a59add3cb6  push r9
000070a59add3cb8  push r10
000070a59add3cba  push r11
000070a59add3cbc  sub rsp, 0xF0
000070a59add3cc3  vmovaps [rsp], xmm0
000070a59add3cc8  vmovaps [rsp+0x10], xmm1
000070a59add3cce  vmovaps [rsp+0x20], xmm2
000070a59add3cd4  vmovaps [rsp+0x30], xmm3
000070a59add3cda  vmovaps [rsp+0x40], xmm4
000070a59add3ce0  vmovaps [rsp+0x50], xmm5
000070a59add3ce6  vmovaps [rsp+0x60], xmm6
000070a59add3cec  vmovaps [rsp+0x70], xmm7
000070a59add3cf2  vmovaps [rsp+0x80], xmm8
000070a59add3cfb  vmovaps [rsp+0x90], xmm9
000070a59add3d04  vmovaps [rsp+0xA0], xmm10
000070a59add3d0d  vmovaps [rsp+0xB0], xmm11
000070a59add3d16  vmovaps [rsp+0xC0], xmm12
000070a59add3d1f  vmovaps [rsp+0xD0], xmm14
000070a59add3d28  vmovaps [rsp+0xE0], xmm15
000070a59add3d31  sub rsp, 0x40
000070a59add3d35  lea rdi, [rsp]
000070a59add3d39  lea rsi, [rsp+0x10]
000070a59add3d3e  lea rdx, [rsp+0x20]
000070a59add3d43  lea rcx, [rsp+0x30]
000070a59add3d48  mov r8d, 0x00
000070a59add3d4e  lea r9, [r15+0x3A8]
000070a59add3d55  movaps [rdi], xmm13
000070a59add3d59  movaps [rsi], xmm15
000070a59add3d5d  movaps [rdx], xmm14
000070a59add3d61  movaps [rcx], xmm1
000070a59add3d64  mov rax, 0x622906D8FA50
000070a59add3d6e  call rax
000070a59add3d70  movaps xmm13, [rsp]
000070a59add3d75  add rsp, 0x40
000070a59add3d79  vmovaps xmm0, [rsp]
000070a59add3d7e  vmovaps xmm1, [rsp+0x10]
000070a59add3d84  vmovaps xmm2, [rsp+0x20]
000070a59add3d8a  vmovaps xmm3, [rsp+0x30]
000070a59add3d90  vmovaps xmm4, [rsp+0x40]
000070a59add3d96  vmovaps xmm5, [rsp+0x50]
000070a59add3d9c  vmovaps xmm6, [rsp+0x60]
000070a59add3da2  vmovaps xmm7, [rsp+0x70]
000070a59add3da8  vmovaps xmm8, [rsp+0x80]
000070a59add3db1  vmovaps xmm9, [rsp+0x90]
000070a59add3dba  vmovaps xmm10, [rsp+0xA0]
000070a59add3dc3  vmovaps xmm11, [rsp+0xB0]
000070a59add3dcc  vmovaps xmm12, [rsp+0xC0]
000070a59add3dd5  vmovaps xmm14, [rsp+0xD0]
000070a59add3dde  vmovaps xmm15, [rsp+0xE0]
000070a59add3de7  add rsp, 0xF0
000070a59add3dee  pop r11
000070a59add3df0  pop r10
000070a59add3df2  pop r9
000070a59add3df4  pop r8
000070a59add3df6  pop rsi
000070a59add3df7  pop rdi
000070a59add3df8  pop rdx
000070a59add3df9  pop rcx
000070a59add3dfa  pop rax
000070a59add3dfb  add rsp, 0x08
000070a59add3dff  jmp 0x000070A59ADD2BEA
000070a59add3e04  sub rsp, 0x08
000070a59add3e08  push rax
000070a59add3e09  push rcx
000070a59add3e0a  push rdx
000070a59add3e0b  push rdi
000070a59add3e0c  push rsi
000070a59add3e0d  push r8
000070a59add3e0f  push r9
000070a59add3e11  push r10
000070a59add3e13  push r11
000070a59add3e15  sub rsp, 0xF0
000070a59add3e1c  vmovaps [rsp], xmm0
000070a59add3e21  vmovaps [rsp+0x10], xmm1
000070a59add3e27  vmovaps [rsp+0x20], xmm2
000070a59add3e2d  vmovaps [rsp+0x30], xmm3
000070a59add3e33  vmovaps [rsp+0x40], xmm4
000070a59add3e39  vmovaps [rsp+0x50], xmm5
000070a59add3e3f  vmovaps [rsp+0x60], xmm6
000070a59add3e45  vmovaps [rsp+0x70], xmm7
000070a59add3e4b  vmovaps [rsp+0x80], xmm8
000070a59add3e54  vmovaps [rsp+0x90], xmm9
000070a59add3e5d  vmovaps [rsp+0xA0], xmm10
000070a59add3e66  vmovaps [rsp+0xB0], xmm11
000070a59add3e6f  vmovaps [rsp+0xC0], xmm13
000070a59add3e78  vmovaps [rsp+0xD0], xmm14
000070a59add3e81  vmovaps [rsp+0xE0], xmm15
000070a59add3e8a  sub rsp, 0x40
000070a59add3e8e  lea rdi, [rsp]
000070a59add3e92  lea rsi, [rsp+0x10]
000070a59add3e97  lea rdx, [rsp+0x20]
000070a59add3e9c  lea rcx, [rsp+0x30]
000070a59add3ea1  mov r8d, 0x00
000070a59add3ea7  lea r9, [r15+0x3A8]
000070a59add3eae  movaps [rdi], xmm12
000070a59add3eb2  movaps [rsi], xmm15
000070a59add3eb6  movaps [rdx], xmm14
000070a59add3eba  movaps [rcx], xmm1
000070a59add3ebd  mov rax, 0x622906D8FA50
000070a59add3ec7  call rax
000070a59add3ec9  movaps xmm12, [rsp]
000070a59add3ece  add rsp, 0x40
000070a59add3ed2  vmovaps xmm0, [rsp]
000070a59add3ed7  vmovaps xmm1, [rsp+0x10]
000070a59add3edd  vmovaps xmm2, [rsp+0x20]
000070a59add3ee3  vmovaps xmm3, [rsp+0x30]
000070a59add3ee9  vmovaps xmm4, [rsp+0x40]
000070a59add3eef  vmovaps xmm5, [rsp+0x50]
000070a59add3ef5  vmovaps xmm6, [rsp+0x60]
000070a59add3efb  vmovaps xmm7, [rsp+0x70]
000070a59add3f01  vmovaps xmm8, [rsp+0x80]
000070a59add3f0a  vmovaps xmm9, [rsp+0x90]
000070a59add3f13  vmovaps xmm10, [rsp+0xA0]
000070a59add3f1c  vmovaps xmm11, [rsp+0xB0]
000070a59add3f25  vmovaps xmm13, [rsp+0xC0]
000070a59add3f2e  vmovaps xmm14, [rsp+0xD0]
000070a59add3f37  vmovaps xmm15, [rsp+0xE0]
000070a59add3f40  add rsp, 0xF0
000070a59add3f47  pop r11
000070a59add3f49  pop r10
000070a59add3f4b  pop r9
000070a59add3f4d  pop r8
000070a59add3f4f  pop rsi
000070a59add3f50  pop rdi
000070a59add3f51  pop rdx
000070a59add3f52  pop rcx
000070a59add3f53  pop rax
000070a59add3f54  add rsp, 0x08
000070a59add3f58  jmp 0x000070A59ADD2C3D
000070a59add3f5d  sub rsp, 0x08
000070a59add3f61  push rax
000070a59add3f62  push rcx
000070a59add3f63  push rdx
000070a59add3f64  push rdi
000070a59add3f65  push rsi
000070a59add3f66  push r8
000070a59add3f68  push r9
000070a59add3f6a  push r10
000070a59add3f6c  push r11
000070a59add3f6e  sub rsp, 0xF0
000070a59add3f75  vmovaps [rsp], xmm0
000070a59add3f7a  vmovaps [rsp+0x10], xmm1
000070a59add3f80  vmovaps [rsp+0x20], xmm2
000070a59add3f86  vmovaps [rsp+0x30], xmm3
000070a59add3f8c  vmovaps [rsp+0x40], xmm4
000070a59add3f92  vmovaps [rsp+0x50], xmm5
000070a59add3f98  vmovaps [rsp+0x60], xmm6
000070a59add3f9e  vmovaps [rsp+0x70], xmm7
000070a59add3fa4  vmovaps [rsp+0x80], xmm8
000070a59add3fad  vmovaps [rsp+0x90], xmm9
000070a59add3fb6  vmovaps [rsp+0xA0], xmm10
000070a59add3fbf  vmovaps [rsp+0xB0], xmm11
000070a59add3fc8  vmovaps [rsp+0xC0], xmm12
000070a59add3fd1  vmovaps [rsp+0xD0], xmm13
000070a59add3fda  vmovaps [rsp+0xE0], xmm15
000070a59add3fe3  sub rsp, 0x40
000070a59add3fe7  lea rdi, [rsp]
000070a59add3feb  lea rsi, [rsp+0x10]
000070a59add3ff0  lea rdx, [rsp+0x20]
000070a59add3ff5  lea rcx, [rsp+0x30]
000070a59add3ffa  mov r8d, 0x00
000070a59add4000  lea r9, [r15+0x3A8]
000070a59add4007  movaps [rdi], xmm14
000070a59add400b  movaps [rsi], xmm3
000070a59add400e  movaps [rdx], xmm1
000070a59add4011  movaps [rcx], xmm15
000070a59add4015  mov rax, 0x622906D8FA50
000070a59add401f  call rax
000070a59add4021  movaps xmm14, [rsp]
000070a59add4026  add rsp, 0x40
000070a59add402a  vmovaps xmm0, [rsp]
000070a59add402f  vmovaps xmm1, [rsp+0x10]
000070a59add4035  vmovaps xmm2, [rsp+0x20]
000070a59add403b  vmovaps xmm3, [rsp+0x30]
000070a59add4041  vmovaps xmm4, [rsp+0x40]
000070a59add4047  vmovaps xmm5, [rsp+0x50]
000070a59add404d  vmovaps xmm6, [rsp+0x60]
000070a59add4053  vmovaps xmm7, [rsp+0x70]
000070a59add4059  vmovaps xmm8, [rsp+0x80]
000070a59add4062  vmovaps xmm9, [rsp+0x90]
000070a59add406b  vmovaps xmm10, [rsp+0xA0]
000070a59add4074  vmovaps xmm11, [rsp+0xB0]
000070a59add407d  vmovaps xmm12, [rsp+0xC0]
000070a59add4086  vmovaps xmm13, [rsp+0xD0]
000070a59add408f  vmovaps xmm15, [rsp+0xE0]
000070a59add4098  add rsp, 0xF0
000070a59add409f  pop r11
000070a59add40a1  pop r10
000070a59add40a3  pop r9
000070a59add40a5  pop r8
000070a59add40a7  pop rsi
000070a59add40a8  pop rdi
000070a59add40a9  pop rdx
000070a59add40aa  pop rcx
000070a59add40ab  pop rax
000070a59add40ac  add rsp, 0x08
000070a59add40b0  jmp 0x000070A59ADD2CF7
000070a59add40b5  sub rsp, 0x08
000070a59add40b9  push rax
000070a59add40ba  push rcx
000070a59add40bb  push rdx
000070a59add40bc  push rdi
000070a59add40bd  push rsi
000070a59add40be  push r8
000070a59add40c0  push r9
000070a59add40c2  push r10
000070a59add40c4  push r11
000070a59add40c6  sub rsp, 0xF0
000070a59add40cd  vmovaps [rsp], xmm0
000070a59add40d2  vmovaps [rsp+0x10], xmm1
000070a59add40d8  vmovaps [rsp+0x20], xmm2
000070a59add40de  vmovaps [rsp+0x30], xmm3
000070a59add40e4  vmovaps [rsp+0x40], xmm4
000070a59add40ea  vmovaps [rsp+0x50], xmm5
000070a59add40f0  vmovaps [rsp+0x60], xmm6
000070a59add40f6  vmovaps [rsp+0x70], xmm7
000070a59add40fc  vmovaps [rsp+0x80], xmm8
000070a59add4105  vmovaps [rsp+0x90], xmm9
000070a59add410e  vmovaps [rsp+0xA0], xmm10
000070a59add4117  vmovaps [rsp+0xB0], xmm11
000070a59add4120  vmovaps [rsp+0xC0], xmm12
000070a59add4129  vmovaps [rsp+0xD0], xmm14
000070a59add4132  vmovaps [rsp+0xE0], xmm15
000070a59add413b  sub rsp, 0x40
000070a59add413f  lea rdi, [rsp]
000070a59add4143  lea rsi, [rsp+0x10]
000070a59add4148  lea rdx, [rsp+0x20]
000070a59add414d  lea rcx, [rsp+0x30]
000070a59add4152  mov r8d, 0x00
000070a59add4158  lea r9, [r15+0x3A8]
000070a59add415f  movaps [rdi], xmm13
000070a59add4163  movaps [rsi], xmm15
000070a59add4167  movaps [rdx], xmm10
000070a59add416b  movaps [rcx], xmm1
000070a59add416e  mov rax, 0x622906D8FA50
000070a59add4178  call rax
000070a59add417a  movaps xmm13, [rsp]
000070a59add417f  add rsp, 0x40
000070a59add4183  vmovaps xmm0, [rsp]
000070a59add4188  vmovaps xmm1, [rsp+0x10]
000070a59add418e  vmovaps xmm2, [rsp+0x20]
000070a59add4194  vmovaps xmm3, [rsp+0x30]
000070a59add419a  vmovaps xmm4, [rsp+0x40]
000070a59add41a0  vmovaps xmm5, [rsp+0x50]
000070a59add41a6  vmovaps xmm6, [rsp+0x60]
000070a59add41ac  vmovaps xmm7, [rsp+0x70]
000070a59add41b2  vmovaps xmm8, [rsp+0x80]
000070a59add41bb  vmovaps xmm9, [rsp+0x90]
000070a59add41c4  vmovaps xmm10, [rsp+0xA0]
000070a59add41cd  vmovaps xmm11, [rsp+0xB0]
000070a59add41d6  vmovaps xmm12, [rsp+0xC0]
000070a59add41df  vmovaps xmm14, [rsp+0xD0]
000070a59add41e8  vmovaps xmm15, [rsp+0xE0]
000070a59add41f1  add rsp, 0xF0
000070a59add41f8  pop r11
000070a59add41fa  pop r10
000070a59add41fc  pop r9
000070a59add41fe  pop r8
000070a59add4200  pop rsi
000070a59add4201  pop rdi
000070a59add4202  pop rdx
000070a59add4203  pop rcx
000070a59add4204  pop rax
000070a59add4205  add rsp, 0x08
000070a59add4209  jmp 0x000070A59ADD2D26
000070a59add420e  sub rsp, 0x08
000070a59add4212  push rax
000070a59add4213  push rcx
000070a59add4214  push rdx
000070a59add4215  push rdi
000070a59add4216  push rsi
000070a59add4217  push r8
000070a59add4219  push r9
000070a59add421b  push r10
000070a59add421d  push r11
000070a59add421f  sub rsp, 0xF0
000070a59add4226  vmovaps [rsp], xmm0
000070a59add422b  vmovaps [rsp+0x10], xmm1
000070a59add4231  vmovaps [rsp+0x20], xmm2
000070a59add4237  vmovaps [rsp+0x30], xmm3
000070a59add423d  vmovaps [rsp+0x40], xmm4
000070a59add4243  vmovaps [rsp+0x50], xmm5
000070a59add4249  vmovaps [rsp+0x60], xmm6
000070a59add424f  vmovaps [rsp+0x70], xmm7
000070a59add4255  vmovaps [rsp+0x80], xmm8
000070a59add425e  vmovaps [rsp+0x90], xmm9
000070a59add4267  vmovaps [rsp+0xA0], xmm11
000070a59add4270  vmovaps [rsp+0xB0], xmm12
000070a59add4279  vmovaps [rsp+0xC0], xmm13
000070a59add4282  vmovaps [rsp+0xD0], xmm14
000070a59add428b  vmovaps [rsp+0xE0], xmm15
000070a59add4294  sub rsp, 0x40
000070a59add4298  lea rdi, [rsp]
000070a59add429c  lea rsi, [rsp+0x10]
000070a59add42a1  lea rdx, [rsp+0x20]
000070a59add42a6  lea rcx, [rsp+0x30]
000070a59add42ab  mov r8d, 0x00
000070a59add42b1  lea r9, [r15+0x3A8]
000070a59add42b8  movaps [rdi], xmm10
000070a59add42bc  movaps [rsi], xmm15
000070a59add42c0  movaps [rdx], xmm11
000070a59add42c4  movaps [rcx], xmm1
000070a59add42c7  mov rax, 0x622906D8FA50
000070a59add42d1  call rax
000070a59add42d3  movaps xmm10, [rsp]
000070a59add42d8  add rsp, 0x40
000070a59add42dc  vmovaps xmm0, [rsp]
000070a59add42e1  vmovaps xmm1, [rsp+0x10]
000070a59add42e7  vmovaps xmm2, [rsp+0x20]
000070a59add42ed  vmovaps xmm3, [rsp+0x30]
000070a59add42f3  vmovaps xmm4, [rsp+0x40]
000070a59add42f9  vmovaps xmm5, [rsp+0x50]
000070a59add42ff  vmovaps xmm6, [rsp+0x60]
000070a59add4305  vmovaps xmm7, [rsp+0x70]
000070a59add430b  vmovaps xmm8, [rsp+0x80]
000070a59add4314  vmovaps xmm9, [rsp+0x90]
000070a59add431d  vmovaps xmm11, [rsp+0xA0]
000070a59add4326  vmovaps xmm12, [rsp+0xB0]
000070a59add432f  vmovaps xmm13, [rsp+0xC0]
000070a59add4338  vmovaps xmm14, [rsp+0xD0]
000070a59add4341  vmovaps xmm15, [rsp+0xE0]
000070a59add434a  add rsp, 0xF0
000070a59add4351  pop r11
000070a59add4353  pop r10
000070a59add4355  pop r9
000070a59add4357  pop r8
000070a59add4359  pop rsi
000070a59add435a  pop rdi
000070a59add435b  pop rdx
000070a59add435c  pop rcx
000070a59add435d  pop rax
000070a59add435e  add rsp, 0x08
000070a59add4362  jmp 0x000070A59ADD2D55
000070a59add4367  sub rsp, 0x08
000070a59add436b  push rax
000070a59add436c  push rcx
000070a59add436d  push rdx
000070a59add436e  push rdi
000070a59add436f  push rsi
000070a59add4370  push r8
000070a59add4372  push r9
000070a59add4374  push r10
000070a59add4376  push r11
000070a59add4378  sub rsp, 0xF0
000070a59add437f  vmovaps [rsp], xmm0
000070a59add4384  vmovaps [rsp+0x10], xmm1
000070a59add438a  vmovaps [rsp+0x20], xmm2
000070a59add4390  vmovaps [rsp+0x30], xmm3
000070a59add4396  vmovaps [rsp+0x40], xmm4
000070a59add439c  vmovaps [rsp+0x50], xmm5
000070a59add43a2  vmovaps [rsp+0x60], xmm6
000070a59add43a8  vmovaps [rsp+0x70], xmm7
000070a59add43ae  vmovaps [rsp+0x80], xmm8
000070a59add43b7  vmovaps [rsp+0x90], xmm9
000070a59add43c0  vmovaps [rsp+0xA0], xmm10
000070a59add43c9  vmovaps [rsp+0xB0], xmm11
000070a59add43d2  vmovaps [rsp+0xC0], xmm12
000070a59add43db  vmovaps [rsp+0xD0], xmm13
000070a59add43e4  vmovaps [rsp+0xE0], xmm14
000070a59add43ed  sub rsp, 0x40
000070a59add43f1  lea rdi, [rsp]
000070a59add43f5  lea rsi, [rsp+0x10]
000070a59add43fa  lea rdx, [rsp+0x20]
000070a59add43ff  lea rcx, [rsp+0x30]
000070a59add4404  mov r8d, 0x00
000070a59add440a  lea r9, [r15+0x3A8]
000070a59add4411  movaps [rdi], xmm15
000070a59add4415  movaps [rsi], xmm12
000070a59add4419  movaps [rdx], xmm5
000070a59add441c  movaps [rcx], xmm1
000070a59add441f  mov rax, 0x622906D8FA50
000070a59add4429  call rax
000070a59add442b  movaps xmm15, [rsp]
000070a59add4430  add rsp, 0x40
000070a59add4434  vmovaps xmm0, [rsp]
000070a59add4439  vmovaps xmm1, [rsp+0x10]
000070a59add443f  vmovaps xmm2, [rsp+0x20]
000070a59add4445  vmovaps xmm3, [rsp+0x30]
000070a59add444b  vmovaps xmm4, [rsp+0x40]
000070a59add4451  vmovaps xmm5, [rsp+0x50]
000070a59add4457  vmovaps xmm6, [rsp+0x60]
000070a59add445d  vmovaps xmm7, [rsp+0x70]
000070a59add4463  vmovaps xmm8, [rsp+0x80]
000070a59add446c  vmovaps xmm9, [rsp+0x90]
000070a59add4475  vmovaps xmm10, [rsp+0xA0]
000070a59add447e  vmovaps xmm11, [rsp+0xB0]
000070a59add4487  vmovaps xmm12, [rsp+0xC0]
000070a59add4490  vmovaps xmm13, [rsp+0xD0]
000070a59add4499  vmovaps xmm14, [rsp+0xE0]
000070a59add44a2  add rsp, 0xF0
000070a59add44a9  pop r11
000070a59add44ab  pop r10
000070a59add44ad  pop r9
000070a59add44af  pop r8
000070a59add44b1  pop rsi
000070a59add44b2  pop rdi
000070a59add44b3  pop rdx
000070a59add44b4  pop rcx
000070a59add44b5  pop rax
000070a59add44b6  add rsp, 0x08
000070a59add44ba  jmp 0x000070A59ADD2D7E
000070a59add44bf  sub rsp, 0x08
000070a59add44c3  push rax
000070a59add44c4  push rcx
000070a59add44c5  push rdx
000070a59add44c6  push rdi
000070a59add44c7  push rsi
000070a59add44c8  push r8
000070a59add44ca  push r9
000070a59add44cc  push r10
000070a59add44ce  push r11
000070a59add44d0  sub rsp, 0xF0
000070a59add44d7  vmovaps [rsp], xmm0
000070a59add44dc  vmovaps [rsp+0x10], xmm1
000070a59add44e2  vmovaps [rsp+0x20], xmm2
000070a59add44e8  vmovaps [rsp+0x30], xmm3
000070a59add44ee  vmovaps [rsp+0x40], xmm4
000070a59add44f4  vmovaps [rsp+0x50], xmm6
000070a59add44fa  vmovaps [rsp+0x60], xmm7
000070a59add4500  vmovaps [rsp+0x70], xmm8
000070a59add4506  vmovaps [rsp+0x80], xmm9
000070a59add450f  vmovaps [rsp+0x90], xmm10
000070a59add4518  vmovaps [rsp+0xA0], xmm11
000070a59add4521  vmovaps [rsp+0xB0], xmm12
000070a59add452a  vmovaps [rsp+0xC0], xmm13
000070a59add4533  vmovaps [rsp+0xD0], xmm14
000070a59add453c  vmovaps [rsp+0xE0], xmm15
000070a59add4545  sub rsp, 0x40
000070a59add4549  lea rdi, [rsp]
000070a59add454d  lea rsi, [rsp+0x10]
000070a59add4552  lea rdx, [rsp+0x20]
000070a59add4557  lea rcx, [rsp+0x30]
000070a59add455c  mov r8d, 0x00
000070a59add4562  lea r9, [r15+0x3A8]
000070a59add4569  movaps [rdi], xmm5
000070a59add456c  movaps [rsi], xmm13
000070a59add4570  movaps [rdx], xmm11
000070a59add4574  movaps [rcx], xmm12
000070a59add4578  mov rax, 0x622906D8FA50
000070a59add4582  call rax
000070a59add4584  movaps xmm5, [rsp]
000070a59add4588  add rsp, 0x40
000070a59add458c  vmovaps xmm0, [rsp]
000070a59add4591  vmovaps xmm1, [rsp+0x10]
000070a59add4597  vmovaps xmm2, [rsp+0x20]
000070a59add459d  vmovaps xmm3, [rsp+0x30]
000070a59add45a3  vmovaps xmm4, [rsp+0x40]
000070a59add45a9  vmovaps xmm6, [rsp+0x50]
000070a59add45af  vmovaps xmm7, [rsp+0x60]
000070a59add45b5  vmovaps xmm8, [rsp+0x70]
000070a59add45bb  vmovaps xmm9, [rsp+0x80]
000070a59add45c4  vmovaps xmm10, [rsp+0x90]
000070a59add45cd  vmovaps xmm11, [rsp+0xA0]
000070a59add45d6  vmovaps xmm12, [rsp+0xB0]
000070a59add45df  vmovaps xmm13, [rsp+0xC0]
000070a59add45e8  vmovaps xmm14, [rsp+0xD0]
000070a59add45f1  vmovaps xmm15, [rsp+0xE0]
000070a59add45fa  add rsp, 0xF0
000070a59add4601  pop r11
000070a59add4603  pop r10
000070a59add4605  pop r9
000070a59add4607  pop r8
000070a59add4609  pop rsi
000070a59add460a  pop rdi
000070a59add460b  pop rdx
000070a59add460c  pop rcx
000070a59add460d  pop rax
000070a59add460e  add rsp, 0x08
000070a59add4612  jmp 0x000070A59ADD2DDD
000070a59add4617  sub rsp, 0x08
000070a59add461b  push rax
000070a59add461c  push rcx
000070a59add461d  push rdx
000070a59add461e  push rdi
000070a59add461f  push rsi
000070a59add4620  push r8
000070a59add4622  push r9
000070a59add4624  push r10
000070a59add4626  push r11
000070a59add4628  sub rsp, 0xF0
000070a59add462f  vmovaps [rsp], xmm0
000070a59add4634  vmovaps [rsp+0x10], xmm1
000070a59add463a  vmovaps [rsp+0x20], xmm2
000070a59add4640  vmovaps [rsp+0x30], xmm3
000070a59add4646  vmovaps [rsp+0x40], xmm4
000070a59add464c  vmovaps [rsp+0x50], xmm5
000070a59add4652  vmovaps [rsp+0x60], xmm6
000070a59add4658  vmovaps [rsp+0x70], xmm7
000070a59add465e  vmovaps [rsp+0x80], xmm8
000070a59add4667  vmovaps [rsp+0x90], xmm9
000070a59add4670  vmovaps [rsp+0xA0], xmm10
000070a59add4679  vmovaps [rsp+0xB0], xmm11
000070a59add4682  vmovaps [rsp+0xC0], xmm13
000070a59add468b  vmovaps [rsp+0xD0], xmm14
000070a59add4694  vmovaps [rsp+0xE0], xmm15
000070a59add469d  sub rsp, 0x40
000070a59add46a1  lea rdi, [rsp]
000070a59add46a5  lea rsi, [rsp+0x10]
000070a59add46aa  lea rdx, [rsp+0x20]
000070a59add46af  lea rcx, [rsp+0x30]
000070a59add46b4  mov r8d, 0x00
000070a59add46ba  lea r9, [r15+0x3A8]
000070a59add46c1  movaps [rdi], xmm12
000070a59add46c5  movaps [rsi], xmm14
000070a59add46c9  movaps [rdx], xmm9
000070a59add46cd  movaps [rcx], xmm13
000070a59add46d1  mov rax, 0x622906D8FA50
000070a59add46db  call rax
000070a59add46dd  movaps xmm12, [rsp]
000070a59add46e2  add rsp, 0x40
000070a59add46e6  vmovaps xmm0, [rsp]
000070a59add46eb  vmovaps xmm1, [rsp+0x10]
000070a59add46f1  vmovaps xmm2, [rsp+0x20]
000070a59add46f7  vmovaps xmm3, [rsp+0x30]
000070a59add46fd  vmovaps xmm4, [rsp+0x40]
000070a59add4703  vmovaps xmm5, [rsp+0x50]
000070a59add4709  vmovaps xmm6, [rsp+0x60]
000070a59add470f  vmovaps xmm7, [rsp+0x70]
000070a59add4715  vmovaps xmm8, [rsp+0x80]
000070a59add471e  vmovaps xmm9, [rsp+0x90]
000070a59add4727  vmovaps xmm10, [rsp+0xA0]
000070a59add4730  vmovaps xmm11, [rsp+0xB0]
000070a59add4739  vmovaps xmm13, [rsp+0xC0]
000070a59add4742  vmovaps xmm14, [rsp+0xD0]
000070a59add474b  vmovaps xmm15, [rsp+0xE0]
000070a59add4754  add rsp, 0xF0
000070a59add475b  pop r11
000070a59add475d  pop r10
000070a59add475f  pop r9
000070a59add4761  pop r8
000070a59add4763  pop rsi
000070a59add4764  pop rdi
000070a59add4765  pop rdx
000070a59add4766  pop rcx
000070a59add4767  pop rax
000070a59add4768  add rsp, 0x08
000070a59add476c  jmp 0x000070A59ADD2E06
000070a59add4771  call 0x000070A59AC0D4E0
000070a59add4776  jmp 0x000070A59ADD2E13
000070a59add477b  sub rsp, 0x08
000070a59add477f  push rax
000070a59add4780  push rcx
000070a59add4781  push rdx
000070a59add4782  push rdi
000070a59add4783  push rsi
000070a59add4784  push r8
000070a59add4786  push r9
000070a59add4788  push r10
000070a59add478a  push r11
000070a59add478c  sub rsp, 0xF0
000070a59add4793  vmovaps [rsp], xmm0
000070a59add4798  vmovaps [rsp+0x10], xmm1
000070a59add479e  vmovaps [rsp+0x20], xmm2
000070a59add47a4  vmovaps [rsp+0x30], xmm3
000070a59add47aa  vmovaps [rsp+0x40], xmm4
000070a59add47b0  vmovaps [rsp+0x50], xmm5
000070a59add47b6  vmovaps [rsp+0x60], xmm6
000070a59add47bc  vmovaps [rsp+0x70], xmm7
000070a59add47c2  vmovaps [rsp+0x80], xmm8
000070a59add47cb  vmovaps [rsp+0x90], xmm9
000070a59add47d4  vmovaps [rsp+0xA0], xmm10
000070a59add47dd  vmovaps [rsp+0xB0], xmm12
000070a59add47e6  vmovaps [rsp+0xC0], xmm13
000070a59add47ef  vmovaps [rsp+0xD0], xmm14
000070a59add47f8  vmovaps [rsp+0xE0], xmm15
000070a59add4801  sub rsp, 0x40
000070a59add4805  lea rdi, [rsp]
000070a59add4809  lea rsi, [rsp+0x10]
000070a59add480e  lea rdx, [rsp+0x20]
000070a59add4813  lea rcx, [rsp+0x30]
000070a59add4818  mov r8d, 0x00
000070a59add481e  lea r9, [r15+0x3A8]
000070a59add4825  movaps [rdi], xmm11
000070a59add4829  movaps [rsi], xmm10
000070a59add482d  movaps [rdx], xmm8
000070a59add4831  movaps [rcx], xmm13
000070a59add4835  mov rax, 0x622906D8FA50
000070a59add483f  call rax
000070a59add4841  movaps xmm11, [rsp]
000070a59add4846  add rsp, 0x40
000070a59add484a  vmovaps xmm0, [rsp]
000070a59add484f  vmovaps xmm1, [rsp+0x10]
000070a59add4855  vmovaps xmm2, [rsp+0x20]
000070a59add485b  vmovaps xmm3, [rsp+0x30]
000070a59add4861  vmovaps xmm4, [rsp+0x40]
000070a59add4867  vmovaps xmm5, [rsp+0x50]
000070a59add486d  vmovaps xmm6, [rsp+0x60]
000070a59add4873  vmovaps xmm7, [rsp+0x70]
000070a59add4879  vmovaps xmm8, [rsp+0x80]
000070a59add4882  vmovaps xmm9, [rsp+0x90]
000070a59add488b  vmovaps xmm10, [rsp+0xA0]
000070a59add4894  vmovaps xmm12, [rsp+0xB0]
000070a59add489d  vmovaps xmm13, [rsp+0xC0]
000070a59add48a6  vmovaps xmm14, [rsp+0xD0]
000070a59add48af  vmovaps xmm15, [rsp+0xE0]
000070a59add48b8  add rsp, 0xF0
000070a59add48bf  pop r11
000070a59add48c1  pop r10
000070a59add48c3  pop r9
000070a59add48c5  pop r8
000070a59add48c7  pop rsi
000070a59add48c8  pop rdi
000070a59add48c9  pop rdx
000070a59add48ca  pop rcx
000070a59add48cb  pop rax
000070a59add48cc  add rsp, 0x08
000070a59add48d0  jmp 0x000070A59ADD2E44
000070a59add48d5  sub rsp, 0x08
000070a59add48d9  push rax
000070a59add48da  push rcx
000070a59add48db  push rdx
000070a59add48dc  push rdi
000070a59add48dd  push rsi
000070a59add48de  push r8
000070a59add48e0  push r9
000070a59add48e2  push r10
000070a59add48e4  push r11
000070a59add48e6  sub rsp, 0xF0
000070a59add48ed  vmovaps [rsp], xmm0
000070a59add48f2  vmovaps [rsp+0x10], xmm1
000070a59add48f8  vmovaps [rsp+0x20], xmm2
000070a59add48fe  vmovaps [rsp+0x30], xmm3
000070a59add4904  vmovaps [rsp+0x40], xmm4
000070a59add490a  vmovaps [rsp+0x50], xmm5
000070a59add4910  vmovaps [rsp+0x60], xmm6
000070a59add4916  vmovaps [rsp+0x70], xmm7
000070a59add491c  vmovaps [rsp+0x80], xmm8
000070a59add4925  vmovaps [rsp+0x90], xmm9
000070a59add492e  vmovaps [rsp+0xA0], xmm11
000070a59add4937  vmovaps [rsp+0xB0], xmm12
000070a59add4940  vmovaps [rsp+0xC0], xmm13
000070a59add4949  vmovaps [rsp+0xD0], xmm14
000070a59add4952  vmovaps [rsp+0xE0], xmm15
000070a59add495b  sub rsp, 0x40
000070a59add495f  lea rdi, [rsp]
000070a59add4963  lea rsi, [rsp+0x10]
000070a59add4968  lea rdx, [rsp+0x20]
000070a59add496d  lea rcx, [rsp+0x30]
000070a59add4972  mov r8d, 0x00
000070a59add4978  lea r9, [r15+0x3A8]
000070a59add497f  movaps [rdi], xmm10
000070a59add4983  movaps [rsi], xmm15
000070a59add4987  movaps [rdx], xmm1
000070a59add498a  movaps [rcx], xmm13
000070a59add498e  mov rax, 0x622906D8FA50
000070a59add4998  call rax
000070a59add499a  movaps xmm10, [rsp]
000070a59add499f  add rsp, 0x40
000070a59add49a3  vmovaps xmm0, [rsp]
000070a59add49a8  vmovaps xmm1, [rsp+0x10]
000070a59add49ae  vmovaps xmm2, [rsp+0x20]
000070a59add49b4  vmovaps xmm3, [rsp+0x30]
000070a59add49ba  vmovaps xmm4, [rsp+0x40]
000070a59add49c0  vmovaps xmm5, [rsp+0x50]
000070a59add49c6  vmovaps xmm6, [rsp+0x60]
000070a59add49cc  vmovaps xmm7, [rsp+0x70]
000070a59add49d2  vmovaps xmm8, [rsp+0x80]
000070a59add49db  vmovaps xmm9, [rsp+0x90]
000070a59add49e4  vmovaps xmm11, [rsp+0xA0]
000070a59add49ed  vmovaps xmm12, [rsp+0xB0]
000070a59add49f6  vmovaps xmm13, [rsp+0xC0]
000070a59add49ff  vmovaps xmm14, [rsp+0xD0]
000070a59add4a08  vmovaps xmm15, [rsp+0xE0]
000070a59add4a11  add rsp, 0xF0
000070a59add4a18  pop r11
000070a59add4a1a  pop r10
000070a59add4a1c  pop r9
000070a59add4a1e  pop r8
000070a59add4a20  pop rsi
000070a59add4a21  pop rdi
000070a59add4a22  pop rdx
000070a59add4a23  pop rcx
000070a59add4a24  pop rax
000070a59add4a25  add rsp, 0x08
000070a59add4a29  jmp 0x000070A59ADD2E6D
000070a59add4a2e  call 0x000070A59ABFF430
000070a59add4a33  jmp 0x000070A59ADD2E8F
000070a59add4a38  call 0x000070A59AC0E760
000070a59add4a3d  jmp 0x000070A59ADD2E99
000070a59add4a42  sub rsp, 0x08
000070a59add4a46  push rax
000070a59add4a47  push rcx
000070a59add4a48  push rdx
000070a59add4a49  push rdi
000070a59add4a4a  push rsi
000070a59add4a4b  push r8
000070a59add4a4d  push r9
000070a59add4a4f  push r10
000070a59add4a51  push r11
000070a59add4a53  sub rsp, 0xF0
000070a59add4a5a  vmovaps [rsp], xmm0
000070a59add4a5f  vmovaps [rsp+0x10], xmm1
000070a59add4a65  vmovaps [rsp+0x20], xmm2
000070a59add4a6b  vmovaps [rsp+0x30], xmm3
000070a59add4a71  vmovaps [rsp+0x40], xmm4
000070a59add4a77  vmovaps [rsp+0x50], xmm5
000070a59add4a7d  vmovaps [rsp+0x60], xmm6
000070a59add4a83  vmovaps [rsp+0x70], xmm7
000070a59add4a89  vmovaps [rsp+0x80], xmm9
000070a59add4a92  vmovaps [rsp+0x90], xmm10
000070a59add4a9b  vmovaps [rsp+0xA0], xmm11
000070a59add4aa4  vmovaps [rsp+0xB0], xmm12
000070a59add4aad  vmovaps [rsp+0xC0], xmm13
000070a59add4ab6  vmovaps [rsp+0xD0], xmm14
000070a59add4abf  vmovaps [rsp+0xE0], xmm15
000070a59add4ac8  sub rsp, 0x40
000070a59add4acc  lea rdi, [rsp]
000070a59add4ad0  lea rsi, [rsp+0x10]
000070a59add4ad5  lea rdx, [rsp+0x20]
000070a59add4ada  lea rcx, [rsp+0x30]
000070a59add4adf  mov r8d, 0x00
000070a59add4ae5  lea r9, [r15+0x3A8]
000070a59add4aec  movaps [rdi], xmm8
000070a59add4af0  movaps [rsi], xmm5
000070a59add4af3  movaps [rdx], xmm9
000070a59add4af7  movaps [rcx], xmm13
000070a59add4afb  mov rax, 0x622906D8FA50
000070a59add4b05  call rax
000070a59add4b07  movaps xmm8, [rsp]
000070a59add4b0c  add rsp, 0x40
000070a59add4b10  vmovaps xmm0, [rsp]
000070a59add4b15  vmovaps xmm1, [rsp+0x10]
000070a59add4b1b  vmovaps xmm2, [rsp+0x20]
000070a59add4b21  vmovaps xmm3, [rsp+0x30]
000070a59add4b27  vmovaps xmm4, [rsp+0x40]
000070a59add4b2d  vmovaps xmm5, [rsp+0x50]
000070a59add4b33  vmovaps xmm6, [rsp+0x60]
000070a59add4b39  vmovaps xmm7, [rsp+0x70]
000070a59add4b3f  vmovaps xmm9, [rsp+0x80]
000070a59add4b48  vmovaps xmm10, [rsp+0x90]
000070a59add4b51  vmovaps xmm11, [rsp+0xA0]
000070a59add4b5a  vmovaps xmm12, [rsp+0xB0]
000070a59add4b63  vmovaps xmm13, [rsp+0xC0]
000070a59add4b6c  vmovaps xmm14, [rsp+0xD0]
000070a59add4b75  vmovaps xmm15, [rsp+0xE0]
000070a59add4b7e  add rsp, 0xF0
000070a59add4b85  pop r11
000070a59add4b87  pop r10
000070a59add4b89  pop r9
000070a59add4b8b  pop r8
000070a59add4b8d  pop rsi
000070a59add4b8e  pop rdi
000070a59add4b8f  pop rdx
000070a59add4b90  pop rcx
000070a59add4b91  pop rax
000070a59add4b92  add rsp, 0x08
000070a59add4b96  jmp 0x000070A59ADD2ED8
000070a59add4b9b  sub rsp, 0x08
000070a59add4b9f  push rax
000070a59add4ba0  push rcx
000070a59add4ba1  push rdx
000070a59add4ba2  push rdi
000070a59add4ba3  push rsi
000070a59add4ba4  push r8
000070a59add4ba6  push r9
000070a59add4ba8  push r10
000070a59add4baa  push r11
000070a59add4bac  sub rsp, 0xF0
000070a59add4bb3  vmovaps [rsp], xmm0
000070a59add4bb8  vmovaps [rsp+0x10], xmm1
000070a59add4bbe  vmovaps [rsp+0x20], xmm2
000070a59add4bc4  vmovaps [rsp+0x30], xmm3
000070a59add4bca  vmovaps [rsp+0x40], xmm4
000070a59add4bd0  vmovaps [rsp+0x50], xmm5
000070a59add4bd6  vmovaps [rsp+0x60], xmm6
000070a59add4bdc  vmovaps [rsp+0x70], xmm7
000070a59add4be2  vmovaps [rsp+0x80], xmm8
000070a59add4beb  vmovaps [rsp+0x90], xmm10
000070a59add4bf4  vmovaps [rsp+0xA0], xmm11
000070a59add4bfd  vmovaps [rsp+0xB0], xmm12
000070a59add4c06  vmovaps [rsp+0xC0], xmm13
000070a59add4c0f  vmovaps [rsp+0xD0], xmm14
000070a59add4c18  vmovaps [rsp+0xE0], xmm15
000070a59add4c21  sub rsp, 0x40
000070a59add4c25  lea rdi, [rsp]
000070a59add4c29  lea rsi, [rsp+0x10]
000070a59add4c2e  lea rdx, [rsp+0x20]
000070a59add4c33  lea rcx, [rsp+0x30]
000070a59add4c38  mov r8d, 0x00
000070a59add4c3e  lea r9, [r15+0x3A8]
000070a59add4c45  movaps [rdi], xmm9
000070a59add4c49  movaps [rsi], xmm12
000070a59add4c4d  movaps [rdx], xmm7
000070a59add4c50  movaps [rcx], xmm13
000070a59add4c54  mov rax, 0x622906D8FA50
000070a59add4c5e  call rax
000070a59add4c60  movaps xmm9, [rsp]
000070a59add4c65  add rsp, 0x40
000070a59add4c69  vmovaps xmm0, [rsp]
000070a59add4c6e  vmovaps xmm1, [rsp+0x10]
000070a59add4c74  vmovaps xmm2, [rsp+0x20]
000070a59add4c7a  vmovaps xmm3, [rsp+0x30]
000070a59add4c80  vmovaps xmm4, [rsp+0x40]
000070a59add4c86  vmovaps xmm5, [rsp+0x50]
000070a59add4c8c  vmovaps xmm6, [rsp+0x60]
000070a59add4c92  vmovaps xmm7, [rsp+0x70]
000070a59add4c98  vmovaps xmm8, [rsp+0x80]
000070a59add4ca1  vmovaps xmm10, [rsp+0x90]
000070a59add4caa  vmovaps xmm11, [rsp+0xA0]
000070a59add4cb3  vmovaps xmm12, [rsp+0xB0]
000070a59add4cbc  vmovaps xmm13, [rsp+0xC0]
000070a59add4cc5  vmovaps xmm14, [rsp+0xD0]
000070a59add4cce  vmovaps xmm15, [rsp+0xE0]
000070a59add4cd7  add rsp, 0xF0
000070a59add4cde  pop r11
000070a59add4ce0  pop r10
000070a59add4ce2  pop r9
000070a59add4ce4  pop r8
000070a59add4ce6  pop rsi
000070a59add4ce7  pop rdi
000070a59add4ce8  pop rdx
000070a59add4ce9  pop rcx
000070a59add4cea  pop rax
000070a59add4ceb  add rsp, 0x08
000070a59add4cef  jmp 0x000070A59ADD2F01
000070a59add4cf4  sub rsp, 0x08
000070a59add4cf8  push rax
000070a59add4cf9  push rcx
000070a59add4cfa  push rdx
000070a59add4cfb  push rdi
000070a59add4cfc  push rsi
000070a59add4cfd  push r8
000070a59add4cff  push r9
000070a59add4d01  push r10
000070a59add4d03  push r11
000070a59add4d05  sub rsp, 0xF0
000070a59add4d0c  vmovaps [rsp], xmm0
000070a59add4d11  vmovaps [rsp+0x10], xmm1
000070a59add4d17  vmovaps [rsp+0x20], xmm2
000070a59add4d1d  vmovaps [rsp+0x30], xmm3
000070a59add4d23  vmovaps [rsp+0x40], xmm4
000070a59add4d29  vmovaps [rsp+0x50], xmm5
000070a59add4d2f  vmovaps [rsp+0x60], xmm6
000070a59add4d35  vmovaps [rsp+0x70], xmm7
000070a59add4d3b  vmovaps [rsp+0x80], xmm8
000070a59add4d44  vmovaps [rsp+0x90], xmm9
000070a59add4d4d  vmovaps [rsp+0xA0], xmm10
000070a59add4d56  vmovaps [rsp+0xB0], xmm11
000070a59add4d5f  vmovaps [rsp+0xC0], xmm13
000070a59add4d68  vmovaps [rsp+0xD0], xmm14
000070a59add4d71  vmovaps [rsp+0xE0], xmm15
000070a59add4d7a  sub rsp, 0x40
000070a59add4d7e  lea rdi, [rsp]
000070a59add4d82  lea rsi, [rsp+0x10]
000070a59add4d87  lea rdx, [rsp+0x20]
000070a59add4d8c  lea rcx, [rsp+0x30]
000070a59add4d91  mov r8d, 0x00
000070a59add4d97  lea r9, [r15+0x3A8]
000070a59add4d9e  movaps [rdi], xmm12
000070a59add4da2  movaps [rsi], xmm11
000070a59add4da6  movaps [rdx], xmm6
000070a59add4da9  movaps [rcx], xmm13
000070a59add4dad  mov rax, 0x622906D8FA50
000070a59add4db7  call rax
000070a59add4db9  movaps xmm12, [rsp]
000070a59add4dbe  add rsp, 0x40
000070a59add4dc2  vmovaps xmm0, [rsp]
000070a59add4dc7  vmovaps xmm1, [rsp+0x10]
000070a59add4dcd  vmovaps xmm2, [rsp+0x20]
000070a59add4dd3  vmovaps xmm3, [rsp+0x30]
000070a59add4dd9  vmovaps xmm4, [rsp+0x40]
000070a59add4ddf  vmovaps xmm5, [rsp+0x50]
000070a59add4de5  vmovaps xmm6, [rsp+0x60]
000070a59add4deb  vmovaps xmm7, [rsp+0x70]
000070a59add4df1  vmovaps xmm8, [rsp+0x80]
000070a59add4dfa  vmovaps xmm9, [rsp+0x90]
000070a59add4e03  vmovaps xmm10, [rsp+0xA0]
000070a59add4e0c  vmovaps xmm11, [rsp+0xB0]
000070a59add4e15  vmovaps xmm13, [rsp+0xC0]
000070a59add4e1e  vmovaps xmm14, [rsp+0xD0]
000070a59add4e27  vmovaps xmm15, [rsp+0xE0]
000070a59add4e30  add rsp, 0xF0
000070a59add4e37  pop r11
000070a59add4e39  pop r10
000070a59add4e3b  pop r9
000070a59add4e3d  pop r8
000070a59add4e3f  pop rsi
000070a59add4e40  pop rdi
000070a59add4e41  pop rdx
000070a59add4e42  pop rcx
000070a59add4e43  pop rax
000070a59add4e44  add rsp, 0x08
000070a59add4e48  jmp 0x000070A59ADD2F2A
000070a59add4e4d  sub rsp, 0x08
000070a59add4e51  push rax
000070a59add4e52  push rcx
000070a59add4e53  push rdx
000070a59add4e54  push rdi
000070a59add4e55  push rsi
000070a59add4e56  push r8
000070a59add4e58  push r9
000070a59add4e5a  push r10
000070a59add4e5c  push r11
000070a59add4e5e  sub rsp, 0xF0
000070a59add4e65  vmovaps [rsp], xmm0
000070a59add4e6a  vmovaps [rsp+0x10], xmm1
000070a59add4e70  vmovaps [rsp+0x20], xmm2
000070a59add4e76  vmovaps [rsp+0x30], xmm3
000070a59add4e7c  vmovaps [rsp+0x40], xmm4
000070a59add4e82  vmovaps [rsp+0x50], xmm5
000070a59add4e88  vmovaps [rsp+0x60], xmm6
000070a59add4e8e  vmovaps [rsp+0x70], xmm8
000070a59add4e94  vmovaps [rsp+0x80], xmm9
000070a59add4e9d  vmovaps [rsp+0x90], xmm10
000070a59add4ea6  vmovaps [rsp+0xA0], xmm11
000070a59add4eaf  vmovaps [rsp+0xB0], xmm12
000070a59add4eb8  vmovaps [rsp+0xC0], xmm13
000070a59add4ec1  vmovaps [rsp+0xD0], xmm14
000070a59add4eca  vmovaps [rsp+0xE0], xmm15
000070a59add4ed3  sub rsp, 0x40
000070a59add4ed7  lea rdi, [rsp]
000070a59add4edb  lea rsi, [rsp+0x10]
000070a59add4ee0  lea rdx, [rsp+0x20]
000070a59add4ee5  lea rcx, [rsp+0x30]
000070a59add4eea  mov r8d, 0x00
000070a59add4ef0  lea r9, [r15+0x3A8]
000070a59add4ef7  movaps [rdi], xmm7
000070a59add4efa  movaps [rsi], xmm10
000070a59add4efe  movaps [rdx], xmm11
000070a59add4f02  movaps [rcx], xmm13
000070a59add4f06  mov rax, 0x622906D8FA50
000070a59add4f10  call rax
000070a59add4f12  movaps xmm7, [rsp]
000070a59add4f16  add rsp, 0x40
000070a59add4f1a  vmovaps xmm0, [rsp]
000070a59add4f1f  vmovaps xmm1, [rsp+0x10]
000070a59add4f25  vmovaps xmm2, [rsp+0x20]
000070a59add4f2b  vmovaps xmm3, [rsp+0x30]
000070a59add4f31  vmovaps xmm4, [rsp+0x40]
000070a59add4f37  vmovaps xmm5, [rsp+0x50]
000070a59add4f3d  vmovaps xmm6, [rsp+0x60]
000070a59add4f43  vmovaps xmm8, [rsp+0x70]
000070a59add4f49  vmovaps xmm9, [rsp+0x80]
000070a59add4f52  vmovaps xmm10, [rsp+0x90]
000070a59add4f5b  vmovaps xmm11, [rsp+0xA0]
000070a59add4f64  vmovaps xmm12, [rsp+0xB0]
000070a59add4f6d  vmovaps xmm13, [rsp+0xC0]
000070a59add4f76  vmovaps xmm14, [rsp+0xD0]
000070a59add4f7f  vmovaps xmm15, [rsp+0xE0]
000070a59add4f88  add rsp, 0xF0
000070a59add4f8f  pop r11
000070a59add4f91  pop r10
000070a59add4f93  pop r9
000070a59add4f95  pop r8
000070a59add4f97  pop rsi
000070a59add4f98  pop rdi
000070a59add4f99  pop rdx
000070a59add4f9a  pop rcx
000070a59add4f9b  pop rax
000070a59add4f9c  add rsp, 0x08
000070a59add4fa0  jmp 0x000070A59ADD2F58
000070a59add4fa5  call 0x000070A59AC0C260
000070a59add4faa  jmp 0x000070A59ADD2F62
000070a59add4faf  call 0x000070A59AC09D70
000070a59add4fb4  jmp 0x000070A59ADD2F6C
000070a59add4fb9  sub rsp, 0x08
000070a59add4fbd  push rax
000070a59add4fbe  push rcx
000070a59add4fbf  push rdx
000070a59add4fc0  push rdi
000070a59add4fc1  push rsi
000070a59add4fc2  push r8
000070a59add4fc4  push r9
000070a59add4fc6  push r10
000070a59add4fc8  push r11
000070a59add4fca  sub rsp, 0xF0
000070a59add4fd1  vmovaps [rsp], xmm0
000070a59add4fd6  vmovaps [rsp+0x10], xmm1
000070a59add4fdc  vmovaps [rsp+0x20], xmm2
000070a59add4fe2  vmovaps [rsp+0x30], xmm3
000070a59add4fe8  vmovaps [rsp+0x40], xmm4
000070a59add4fee  vmovaps [rsp+0x50], xmm5
000070a59add4ff4  vmovaps [rsp+0x60], xmm7
000070a59add4ffa  vmovaps [rsp+0x70], xmm8
000070a59add5000  vmovaps [rsp+0x80], xmm9
000070a59add5009  vmovaps [rsp+0x90], xmm10
000070a59add5012  vmovaps [rsp+0xA0], xmm11
000070a59add501b  vmovaps [rsp+0xB0], xmm12
000070a59add5024  vmovaps [rsp+0xC0], xmm13
000070a59add502d  vmovaps [rsp+0xD0], xmm14
000070a59add5036  vmovaps [rsp+0xE0], xmm15
000070a59add503f  sub rsp, 0x40
000070a59add5043  lea rdi, [rsp]
000070a59add5047  lea rsi, [rsp+0x10]
000070a59add504c  lea rdx, [rsp+0x20]
000070a59add5051  lea rcx, [rsp+0x30]
000070a59add5056  mov r8d, 0x00
000070a59add505c  lea r9, [r15+0x3A8]
000070a59add5063  movaps [rdi], xmm6
000070a59add5066  movaps [rsi], xmm8
000070a59add506a  movaps [rdx], xmm15
000070a59add506e  movaps [rcx], xmm10
000070a59add5072  mov rax, 0x622906D8FA50
000070a59add507c  call rax
000070a59add507e  movaps xmm6, [rsp]
000070a59add5082  add rsp, 0x40
000070a59add5086  vmovaps xmm0, [rsp]
000070a59add508b  vmovaps xmm1, [rsp+0x10]
000070a59add5091  vmovaps xmm2, [rsp+0x20]
000070a59add5097  vmovaps xmm3, [rsp+0x30]
000070a59add509d  vmovaps xmm4, [rsp+0x40]
000070a59add50a3  vmovaps xmm5, [rsp+0x50]
000070a59add50a9  vmovaps xmm7, [rsp+0x60]
000070a59add50af  vmovaps xmm8, [rsp+0x70]
000070a59add50b5  vmovaps xmm9, [rsp+0x80]
000070a59add50be  vmovaps xmm10, [rsp+0x90]
000070a59add50c7  vmovaps xmm11, [rsp+0xA0]
000070a59add50d0  vmovaps xmm12, [rsp+0xB0]
000070a59add50d9  vmovaps xmm13, [rsp+0xC0]
000070a59add50e2  vmovaps xmm14, [rsp+0xD0]
000070a59add50eb  vmovaps xmm15, [rsp+0xE0]
000070a59add50f4  add rsp, 0xF0
000070a59add50fb  pop r11
000070a59add50fd  pop r10
000070a59add50ff  pop r9
000070a59add5101  pop r8
000070a59add5103  pop rsi
000070a59add5104  pop rdi
000070a59add5105  pop rdx
000070a59add5106  pop rcx
000070a59add5107  pop rax
000070a59add5108  add rsp, 0x08
000070a59add510c  jmp 0x000070A59ADD2FA4
000070a59add5111  sub rsp, 0x08
000070a59add5115  push rax
000070a59add5116  push rcx
000070a59add5117  push rdx
000070a59add5118  push rdi
000070a59add5119  push rsi
000070a59add511a  push r8
000070a59add511c  push r9
000070a59add511e  push r10
000070a59add5120  push r11
000070a59add5122  sub rsp, 0xF0
000070a59add5129  vmovaps [rsp], xmm0
000070a59add512e  vmovaps [rsp+0x10], xmm1
000070a59add5134  vmovaps [rsp+0x20], xmm2
000070a59add513a  vmovaps [rsp+0x30], xmm3
000070a59add5140  vmovaps [rsp+0x40], xmm4
000070a59add5146  vmovaps [rsp+0x50], xmm5
000070a59add514c  vmovaps [rsp+0x60], xmm6
000070a59add5152  vmovaps [rsp+0x70], xmm7
000070a59add5158  vmovaps [rsp+0x80], xmm8
000070a59add5161  vmovaps [rsp+0x90], xmm9
000070a59add516a  vmovaps [rsp+0xA0], xmm11
000070a59add5173  vmovaps [rsp+0xB0], xmm12
000070a59add517c  vmovaps [rsp+0xC0], xmm13
000070a59add5185  vmovaps [rsp+0xD0], xmm14
000070a59add518e  vmovaps [rsp+0xE0], xmm15
000070a59add5197  sub rsp, 0x40
000070a59add519b  lea rdi, [rsp]
000070a59add519f  lea rsi, [rsp+0x10]
000070a59add51a4  lea rdx, [rsp+0x20]
000070a59add51a9  lea rcx, [rsp+0x30]
000070a59add51ae  mov r8d, 0x00
000070a59add51b4  lea r9, [r15+0x3A8]
000070a59add51bb  movaps [rdi], xmm10
000070a59add51bf  movaps [rsi], xmm9
000070a59add51c3  movaps [rdx], xmm13
000070a59add51c7  movaps [rcx], xmm15
000070a59add51cb  mov rax, 0x622906D8FA50
000070a59add51d5  call rax
000070a59add51d7  movaps xmm10, [rsp]
000070a59add51dc  add rsp, 0x40
000070a59add51e0  vmovaps xmm0, [rsp]
000070a59add51e5  vmovaps xmm1, [rsp+0x10]
000070a59add51eb  vmovaps xmm2, [rsp+0x20]
000070a59add51f1  vmovaps xmm3, [rsp+0x30]
000070a59add51f7  vmovaps xmm4, [rsp+0x40]
000070a59add51fd  vmovaps xmm5, [rsp+0x50]
000070a59add5203  vmovaps xmm6, [rsp+0x60]
000070a59add5209  vmovaps xmm7, [rsp+0x70]
000070a59add520f  vmovaps xmm8, [rsp+0x80]
000070a59add5218  vmovaps xmm9, [rsp+0x90]
000070a59add5221  vmovaps xmm11, [rsp+0xA0]
000070a59add522a  vmovaps xmm12, [rsp+0xB0]
000070a59add5233  vmovaps xmm13, [rsp+0xC0]
000070a59add523c  vmovaps xmm14, [rsp+0xD0]
000070a59add5245  vmovaps xmm15, [rsp+0xE0]
000070a59add524e  add rsp, 0xF0
000070a59add5255  pop r11
000070a59add5257  pop r10
000070a59add5259  pop r9
000070a59add525b  pop r8
000070a59add525d  pop rsi
000070a59add525e  pop rdi
000070a59add525f  pop rdx
000070a59add5260  pop rcx
000070a59add5261  pop rax
000070a59add5262  add rsp, 0x08
000070a59add5266  jmp 0x000070A59ADD2FCD
000070a59add526b  sub rsp, 0x08
000070a59add526f  push rax
000070a59add5270  push rcx
000070a59add5271  push rdx
000070a59add5272  push rdi
000070a59add5273  push rsi
000070a59add5274  push r8
000070a59add5276  push r9
000070a59add5278  push r10
000070a59add527a  push r11
000070a59add527c  sub rsp, 0xF0
000070a59add5283  vmovaps [rsp], xmm0
000070a59add5288  vmovaps [rsp+0x10], xmm1
000070a59add528e  vmovaps [rsp+0x20], xmm2
000070a59add5294  vmovaps [rsp+0x30], xmm3
000070a59add529a  vmovaps [rsp+0x40], xmm4
000070a59add52a0  vmovaps [rsp+0x50], xmm5
000070a59add52a6  vmovaps [rsp+0x60], xmm6
000070a59add52ac  vmovaps [rsp+0x70], xmm7
000070a59add52b2  vmovaps [rsp+0x80], xmm8
000070a59add52bb  vmovaps [rsp+0x90], xmm9
000070a59add52c4  vmovaps [rsp+0xA0], xmm10
000070a59add52cd  vmovaps [rsp+0xB0], xmm11
000070a59add52d6  vmovaps [rsp+0xC0], xmm12
000070a59add52df  vmovaps [rsp+0xD0], xmm14
000070a59add52e8  vmovaps [rsp+0xE0], xmm15
000070a59add52f1  sub rsp, 0x40
000070a59add52f5  lea rdi, [rsp]
000070a59add52f9  lea rsi, [rsp+0x10]
000070a59add52fe  lea rdx, [rsp+0x20]
000070a59add5303  lea rcx, [rsp+0x30]
000070a59add5308  mov r8d, 0x00
000070a59add530e  lea r9, [r15+0x3A8]
000070a59add5315  movaps [rdi], xmm13
000070a59add5319  movaps [rsi], xmm12
000070a59add531d  movaps [rdx], xmm4
000070a59add5320  movaps [rcx], xmm15
000070a59add5324  mov rax, 0x622906D8FA50
000070a59add532e  call rax
000070a59add5330  movaps xmm13, [rsp]
000070a59add5335  add rsp, 0x40
000070a59add5339  vmovaps xmm0, [rsp]
000070a59add533e  vmovaps xmm1, [rsp+0x10]
000070a59add5344  vmovaps xmm2, [rsp+0x20]
000070a59add534a  vmovaps xmm3, [rsp+0x30]
000070a59add5350  vmovaps xmm4, [rsp+0x40]
000070a59add5356  vmovaps xmm5, [rsp+0x50]
000070a59add535c  vmovaps xmm6, [rsp+0x60]
000070a59add5362  vmovaps xmm7, [rsp+0x70]
000070a59add5368  vmovaps xmm8, [rsp+0x80]
000070a59add5371  vmovaps xmm9, [rsp+0x90]
000070a59add537a  vmovaps xmm10, [rsp+0xA0]
000070a59add5383  vmovaps xmm11, [rsp+0xB0]
000070a59add538c  vmovaps xmm12, [rsp+0xC0]
000070a59add5395  vmovaps xmm14, [rsp+0xD0]
000070a59add539e  vmovaps xmm15, [rsp+0xE0]
000070a59add53a7  add rsp, 0xF0
000070a59add53ae  pop r11
000070a59add53b0  pop r10
000070a59add53b2  pop r9
000070a59add53b4  pop r8
000070a59add53b6  pop rsi
000070a59add53b7  pop rdi
000070a59add53b8  pop rdx
000070a59add53b9  pop rcx
000070a59add53ba  pop rax
000070a59add53bb  add rsp, 0x08
000070a59add53bf  jmp 0x000070A59ADD2FF6
000070a59add53c4  sub rsp, 0x08
000070a59add53c8  push rax
000070a59add53c9  push rcx
000070a59add53ca  push rdx
000070a59add53cb  push rdi
000070a59add53cc  push rsi
000070a59add53cd  push r8
000070a59add53cf  push r9
000070a59add53d1  push r10
000070a59add53d3  push r11
000070a59add53d5  sub rsp, 0xF0
000070a59add53dc  vmovaps [rsp], xmm0
000070a59add53e1  vmovaps [rsp+0x10], xmm1
000070a59add53e7  vmovaps [rsp+0x20], xmm2
000070a59add53ed  vmovaps [rsp+0x30], xmm3
000070a59add53f3  vmovaps [rsp+0x40], xmm4
000070a59add53f9  vmovaps [rsp+0x50], xmm5
000070a59add53ff  vmovaps [rsp+0x60], xmm6
000070a59add5405  vmovaps [rsp+0x70], xmm7
000070a59add540b  vmovaps [rsp+0x80], xmm8
000070a59add5414  vmovaps [rsp+0x90], xmm9
000070a59add541d  vmovaps [rsp+0xA0], xmm10
000070a59add5426  vmovaps [rsp+0xB0], xmm11
000070a59add542f  vmovaps [rsp+0xC0], xmm13
000070a59add5438  vmovaps [rsp+0xD0], xmm14
000070a59add5441  vmovaps [rsp+0xE0], xmm15
000070a59add544a  sub rsp, 0x40
000070a59add544e  lea rdi, [rsp]
000070a59add5452  lea rsi, [rsp+0x10]
000070a59add5457  lea rdx, [rsp+0x20]
000070a59add545c  lea rcx, [rsp+0x30]
000070a59add5461  mov r8d, 0x00
000070a59add5467  lea r9, [r15+0x3A8]
000070a59add546e  movaps [rdi], xmm12
000070a59add5472  movaps [rsi], xmm7
000070a59add5475  movaps [rdx], xmm1
000070a59add5478  movaps [rcx], xmm15
000070a59add547c  mov rax, 0x622906D8FA50
000070a59add5486  call rax
000070a59add5488  movaps xmm12, [rsp]
000070a59add548d  add rsp, 0x40
000070a59add5491  vmovaps xmm0, [rsp]
000070a59add5496  vmovaps xmm1, [rsp+0x10]
000070a59add549c  vmovaps xmm2, [rsp+0x20]
000070a59add54a2  vmovaps xmm3, [rsp+0x30]
000070a59add54a8  vmovaps xmm4, [rsp+0x40]
000070a59add54ae  vmovaps xmm5, [rsp+0x50]
000070a59add54b4  vmovaps xmm6, [rsp+0x60]
000070a59add54ba  vmovaps xmm7, [rsp+0x70]
000070a59add54c0  vmovaps xmm8, [rsp+0x80]
000070a59add54c9  vmovaps xmm9, [rsp+0x90]
000070a59add54d2  vmovaps xmm10, [rsp+0xA0]
000070a59add54db  vmovaps xmm11, [rsp+0xB0]
000070a59add54e4  vmovaps xmm13, [rsp+0xC0]
000070a59add54ed  vmovaps xmm14, [rsp+0xD0]
000070a59add54f6  vmovaps xmm15, [rsp+0xE0]
000070a59add54ff  add rsp, 0xF0
000070a59add5506  pop r11
000070a59add5508  pop r10
000070a59add550a  pop r9
000070a59add550c  pop r8
000070a59add550e  pop rsi
000070a59add550f  pop rdi
000070a59add5510  pop rdx
000070a59add5511  pop rcx
000070a59add5512  pop rax
000070a59add5513  add rsp, 0x08
000070a59add5517  jmp 0x000070A59ADD301F
000070a59add551c  call 0x000070A59ABFF430
000070a59add5521  jmp 0x000070A59ADD3029
000070a59add5526  call 0x000070A59AC0E760
000070a59add552b  jmp 0x000070A59ADD3033
000070a59add5530  sub rsp, 0x08
000070a59add5534  push rax
000070a59add5535  push rcx
000070a59add5536  push rdx
000070a59add5537  push rdi
000070a59add5538  push rsi
000070a59add5539  push r8
000070a59add553b  push r9
000070a59add553d  push r10
000070a59add553f  push r11
000070a59add5541  sub rsp, 0xF0
000070a59add5548  vmovaps [rsp], xmm0
000070a59add554d  vmovaps [rsp+0x10], xmm1
000070a59add5553  vmovaps [rsp+0x20], xmm2
000070a59add5559  vmovaps [rsp+0x30], xmm3
000070a59add555f  vmovaps [rsp+0x40], xmm4
000070a59add5565  vmovaps [rsp+0x50], xmm5
000070a59add556b  vmovaps [rsp+0x60], xmm6
000070a59add5571  vmovaps [rsp+0x70], xmm8
000070a59add5577  vmovaps [rsp+0x80], xmm9
000070a59add5580  vmovaps [rsp+0x90], xmm10
000070a59add5589  vmovaps [rsp+0xA0], xmm11
000070a59add5592  vmovaps [rsp+0xB0], xmm12
000070a59add559b  vmovaps [rsp+0xC0], xmm13
000070a59add55a4  vmovaps [rsp+0xD0], xmm14
000070a59add55ad  vmovaps [rsp+0xE0], xmm15
000070a59add55b6  sub rsp, 0x40
000070a59add55ba  lea rdi, [rsp]
000070a59add55be  lea rsi, [rsp+0x10]
000070a59add55c3  lea rdx, [rsp+0x20]
000070a59add55c8  lea rcx, [rsp+0x30]
000070a59add55cd  mov r8d, 0x00
000070a59add55d3  lea r9, [r15+0x3A8]
000070a59add55da  movaps [rdi], xmm7
000070a59add55dd  movaps [rsi], xmm6
000070a59add55e0  movaps [rdx], xmm8
000070a59add55e4  movaps [rcx], xmm9
000070a59add55e8  mov rax, 0x622906D8FA50
000070a59add55f2  call rax
000070a59add55f4  movaps xmm7, [rsp]
000070a59add55f8  add rsp, 0x40
000070a59add55fc  vmovaps xmm0, [rsp]
000070a59add5601  vmovaps xmm1, [rsp+0x10]
000070a59add5607  vmovaps xmm2, [rsp+0x20]
000070a59add560d  vmovaps xmm3, [rsp+0x30]
000070a59add5613  vmovaps xmm4, [rsp+0x40]
000070a59add5619  vmovaps xmm5, [rsp+0x50]
000070a59add561f  vmovaps xmm6, [rsp+0x60]
000070a59add5625  vmovaps xmm8, [rsp+0x70]
000070a59add562b  vmovaps xmm9, [rsp+0x80]
000070a59add5634  vmovaps xmm10, [rsp+0x90]
000070a59add563d  vmovaps xmm11, [rsp+0xA0]
000070a59add5646  vmovaps xmm12, [rsp+0xB0]
000070a59add564f  vmovaps xmm13, [rsp+0xC0]
000070a59add5658  vmovaps xmm14, [rsp+0xD0]
000070a59add5661  vmovaps xmm15, [rsp+0xE0]
000070a59add566a  add rsp, 0xF0
000070a59add5671  pop r11
000070a59add5673  pop r10
000070a59add5675  pop r9
000070a59add5677  pop r8
000070a59add5679  pop rsi
000070a59add567a  pop rdi
000070a59add567b  pop rdx
000070a59add567c  pop rcx
000070a59add567d  pop rax
000070a59add567e  add rsp, 0x08
000070a59add5682  jmp 0x000070A59ADD305D
000070a59add5687  sub rsp, 0x08
000070a59add568b  push rax
000070a59add568c  push rcx
000070a59add568d  push rdx
000070a59add568e  push rdi
000070a59add568f  push rsi
000070a59add5690  push r8
000070a59add5692  push r9
000070a59add5694  push r10
000070a59add5696  push r11
000070a59add5698  sub rsp, 0xF0
000070a59add569f  vmovaps [rsp], xmm0
000070a59add56a4  vmovaps [rsp+0x10], xmm1
000070a59add56aa  vmovaps [rsp+0x20], xmm2
000070a59add56b0  vmovaps [rsp+0x30], xmm3
000070a59add56b6  vmovaps [rsp+0x40], xmm4
000070a59add56bc  vmovaps [rsp+0x50], xmm5
000070a59add56c2  vmovaps [rsp+0x60], xmm6
000070a59add56c8  vmovaps [rsp+0x70], xmm7
000070a59add56ce  vmovaps [rsp+0x80], xmm9
000070a59add56d7  vmovaps [rsp+0x90], xmm10
000070a59add56e0  vmovaps [rsp+0xA0], xmm11
000070a59add56e9  vmovaps [rsp+0xB0], xmm12
000070a59add56f2  vmovaps [rsp+0xC0], xmm13
000070a59add56fb  vmovaps [rsp+0xD0], xmm14
000070a59add5704  vmovaps [rsp+0xE0], xmm15
000070a59add570d  sub rsp, 0x40
000070a59add5711  lea rdi, [rsp]
000070a59add5715  lea rsi, [rsp+0x10]
000070a59add571a  lea rdx, [rsp+0x20]
000070a59add571f  lea rcx, [rsp+0x30]
000070a59add5724  mov r8d, 0x00
000070a59add572a  lea r9, [r15+0x3A8]
000070a59add5731  movaps [rdi], xmm8
000070a59add5735  movaps [rsi], xmm10
000070a59add5739  movaps [rdx], xmm14
000070a59add573d  movaps [rcx], xmm9
000070a59add5741  mov rax, 0x622906D8FA50
000070a59add574b  call rax
000070a59add574d  movaps xmm8, [rsp]
000070a59add5752  add rsp, 0x40
000070a59add5756  vmovaps xmm0, [rsp]
000070a59add575b  vmovaps xmm1, [rsp+0x10]
000070a59add5761  vmovaps xmm2, [rsp+0x20]
000070a59add5767  vmovaps xmm3, [rsp+0x30]
000070a59add576d  vmovaps xmm4, [rsp+0x40]
000070a59add5773  vmovaps xmm5, [rsp+0x50]
000070a59add5779  vmovaps xmm6, [rsp+0x60]
000070a59add577f  vmovaps xmm7, [rsp+0x70]
000070a59add5785  vmovaps xmm9, [rsp+0x80]
000070a59add578e  vmovaps xmm10, [rsp+0x90]
000070a59add5797  vmovaps xmm11, [rsp+0xA0]
000070a59add57a0  vmovaps xmm12, [rsp+0xB0]
000070a59add57a9  vmovaps xmm13, [rsp+0xC0]
000070a59add57b2  vmovaps xmm14, [rsp+0xD0]
000070a59add57bb  vmovaps xmm15, [rsp+0xE0]
000070a59add57c4  add rsp, 0xF0
000070a59add57cb  pop r11
000070a59add57cd  pop r10
000070a59add57cf  pop r9
000070a59add57d1  pop r8
000070a59add57d3  pop rsi
000070a59add57d4  pop rdi
000070a59add57d5  pop rdx
000070a59add57d6  pop rcx
000070a59add57d7  pop rax
000070a59add57d8  add rsp, 0x08
000070a59add57dc  jmp 0x000070A59ADD3083
000070a59add57e1  sub rsp, 0x08
000070a59add57e5  push rax
000070a59add57e6  push rcx
000070a59add57e7  push rdx
000070a59add57e8  push rdi
000070a59add57e9  push rsi
000070a59add57ea  push r8
000070a59add57ec  push r9
000070a59add57ee  push r10
000070a59add57f0  push r11
000070a59add57f2  sub rsp, 0xF0
000070a59add57f9  vmovaps [rsp], xmm0
000070a59add57fe  vmovaps [rsp+0x10], xmm1
000070a59add5804  vmovaps [rsp+0x20], xmm2
000070a59add580a  vmovaps [rsp+0x30], xmm3
000070a59add5810  vmovaps [rsp+0x40], xmm4
000070a59add5816  vmovaps [rsp+0x50], xmm5
000070a59add581c  vmovaps [rsp+0x60], xmm6
000070a59add5822  vmovaps [rsp+0x70], xmm7
000070a59add5828  vmovaps [rsp+0x80], xmm8
000070a59add5831  vmovaps [rsp+0x90], xmm9
000070a59add583a  vmovaps [rsp+0xA0], xmm11
000070a59add5843  vmovaps [rsp+0xB0], xmm12
000070a59add584c  vmovaps [rsp+0xC0], xmm13
000070a59add5855  vmovaps [rsp+0xD0], xmm14
000070a59add585e  vmovaps [rsp+0xE0], xmm15
000070a59add5867  sub rsp, 0x40
000070a59add586b  lea rdi, [rsp]
000070a59add586f  lea rsi, [rsp+0x10]
000070a59add5874  lea rdx, [rsp+0x20]
000070a59add5879  lea rcx, [rsp+0x30]
000070a59add587e  mov r8d, 0x00
000070a59add5884  lea r9, [r15+0x3A8]
000070a59add588b  movaps [rdi], xmm10
000070a59add588f  movaps [rsi], xmm13
000070a59add5893  movaps [rdx], xmm11
000070a59add5897  movaps [rcx], xmm14
000070a59add589b  mov rax, 0x622906D8FA50
000070a59add58a5  call rax
000070a59add58a7  movaps xmm10, [rsp]
000070a59add58ac  add rsp, 0x40
000070a59add58b0  vmovaps xmm0, [rsp]
000070a59add58b5  vmovaps xmm1, [rsp+0x10]
000070a59add58bb  vmovaps xmm2, [rsp+0x20]
000070a59add58c1  vmovaps xmm3, [rsp+0x30]
000070a59add58c7  vmovaps xmm4, [rsp+0x40]
000070a59add58cd  vmovaps xmm5, [rsp+0x50]
000070a59add58d3  vmovaps xmm6, [rsp+0x60]
000070a59add58d9  vmovaps xmm7, [rsp+0x70]
000070a59add58df  vmovaps xmm8, [rsp+0x80]
000070a59add58e8  vmovaps xmm9, [rsp+0x90]
000070a59add58f1  vmovaps xmm11, [rsp+0xA0]
000070a59add58fa  vmovaps xmm12, [rsp+0xB0]
000070a59add5903  vmovaps xmm13, [rsp+0xC0]
000070a59add590c  vmovaps xmm14, [rsp+0xD0]
000070a59add5915  vmovaps xmm15, [rsp+0xE0]
000070a59add591e  add rsp, 0xF0
000070a59add5925  pop r11
000070a59add5927  pop r10
000070a59add5929  pop r9
000070a59add592b  pop r8
000070a59add592d  pop rsi
000070a59add592e  pop rdi
000070a59add592f  pop rdx
000070a59add5930  pop rcx
000070a59add5931  pop rax
000070a59add5932  add rsp, 0x08
000070a59add5936  jmp 0x000070A59ADD30A9
000070a59add593b  sub rsp, 0x08
000070a59add593f  push rax
000070a59add5940  push rcx
000070a59add5941  push rdx
000070a59add5942  push rdi
000070a59add5943  push rsi
000070a59add5944  push r8
000070a59add5946  push r9
000070a59add5948  push r10
000070a59add594a  push r11
000070a59add594c  sub rsp, 0xF0
000070a59add5953  vmovaps [rsp], xmm0
000070a59add5958  vmovaps [rsp+0x10], xmm1
000070a59add595e  vmovaps [rsp+0x20], xmm2
000070a59add5964  vmovaps [rsp+0x30], xmm3
000070a59add596a  vmovaps [rsp+0x40], xmm4
000070a59add5970  vmovaps [rsp+0x50], xmm5
000070a59add5976  vmovaps [rsp+0x60], xmm6
000070a59add597c  vmovaps [rsp+0x70], xmm7
000070a59add5982  vmovaps [rsp+0x80], xmm8
000070a59add598b  vmovaps [rsp+0x90], xmm9
000070a59add5994  vmovaps [rsp+0xA0], xmm10
000070a59add599d  vmovaps [rsp+0xB0], xmm11
000070a59add59a6  vmovaps [rsp+0xC0], xmm12
000070a59add59af  vmovaps [rsp+0xD0], xmm14
000070a59add59b8  vmovaps [rsp+0xE0], xmm15
000070a59add59c1  sub rsp, 0x40
000070a59add59c5  lea rdi, [rsp]
000070a59add59c9  lea rsi, [rsp+0x10]
000070a59add59ce  lea rdx, [rsp+0x20]
000070a59add59d3  lea rcx, [rsp+0x30]
000070a59add59d8  mov r8d, 0x00
000070a59add59de  lea r9, [r15+0x3A8]
000070a59add59e5  movaps [rdi], xmm13
000070a59add59e9  movaps [rsi], xmm12
000070a59add59ed  movaps [rdx], xmm15
000070a59add59f1  movaps [rcx], xmm14
000070a59add59f5  mov rax, 0x622906D8FA50
000070a59add59ff  call rax
000070a59add5a01  movaps xmm13, [rsp]
000070a59add5a06  add rsp, 0x40
000070a59add5a0a  vmovaps xmm0, [rsp]
000070a59add5a0f  vmovaps xmm1, [rsp+0x10]
000070a59add5a15  vmovaps xmm2, [rsp+0x20]
000070a59add5a1b  vmovaps xmm3, [rsp+0x30]
000070a59add5a21  vmovaps xmm4, [rsp+0x40]
000070a59add5a27  vmovaps xmm5, [rsp+0x50]
000070a59add5a2d  vmovaps xmm6, [rsp+0x60]
000070a59add5a33  vmovaps xmm7, [rsp+0x70]
000070a59add5a39  vmovaps xmm8, [rsp+0x80]
000070a59add5a42  vmovaps xmm9, [rsp+0x90]
000070a59add5a4b  vmovaps xmm10, [rsp+0xA0]
000070a59add5a54  vmovaps xmm11, [rsp+0xB0]
000070a59add5a5d  vmovaps xmm12, [rsp+0xC0]
000070a59add5a66  vmovaps xmm14, [rsp+0xD0]
000070a59add5a6f  vmovaps xmm15, [rsp+0xE0]
000070a59add5a78  add rsp, 0xF0
000070a59add5a7f  pop r11
000070a59add5a81  pop r10
000070a59add5a83  pop r9
000070a59add5a85  pop r8
000070a59add5a87  pop rsi
000070a59add5a88  pop rdi
000070a59add5a89  pop rdx
000070a59add5a8a  pop rcx
000070a59add5a8b  pop rax
000070a59add5a8c  add rsp, 0x08
000070a59add5a90  jmp 0x000070A59ADD30CF
000070a59add5a95  call 0x000070A59AC0E760
000070a59add5a9a  jmp 0x000070A59ADD30DC
000070a59add5a9f  call 0x000070A59AC0D4E0
000070a59add5aa4  jmp 0x000070A59ADD30E9
000070a59add5aa9  sub rsp, 0x08
000070a59add5aad  push rax
000070a59add5aae  push rcx
000070a59add5aaf  push rdx
000070a59add5ab0  push rdi
000070a59add5ab1  push rsi
000070a59add5ab2  push r8
000070a59add5ab4  push r9
000070a59add5ab6  push r10
000070a59add5ab8  push r11
000070a59add5aba  sub rsp, 0xF0
000070a59add5ac1  vmovaps [rsp], xmm0
000070a59add5ac6  vmovaps [rsp+0x10], xmm1
000070a59add5acc  vmovaps [rsp+0x20], xmm2
000070a59add5ad2  vmovaps [rsp+0x30], xmm3
000070a59add5ad8  vmovaps [rsp+0x40], xmm4
000070a59add5ade  vmovaps [rsp+0x50], xmm5
000070a59add5ae4  vmovaps [rsp+0x60], xmm6
000070a59add5aea  vmovaps [rsp+0x70], xmm7
000070a59add5af0  vmovaps [rsp+0x80], xmm8
000070a59add5af9  vmovaps [rsp+0x90], xmm9
000070a59add5b02  vmovaps [rsp+0xA0], xmm10
000070a59add5b0b  vmovaps [rsp+0xB0], xmm12
000070a59add5b14  vmovaps [rsp+0xC0], xmm13
000070a59add5b1d  vmovaps [rsp+0xD0], xmm14
000070a59add5b26  vmovaps [rsp+0xE0], xmm15
000070a59add5b2f  sub rsp, 0x40
000070a59add5b33  lea rdi, [rsp]
000070a59add5b37  lea rsi, [rsp+0x10]
000070a59add5b3c  lea rdx, [rsp+0x20]
000070a59add5b41  lea rcx, [rsp+0x30]
000070a59add5b46  mov r8d, 0x00
000070a59add5b4c  lea r9, [r15+0x3A8]
000070a59add5b53  movaps [rdi], xmm11
000070a59add5b57  movaps [rsi], xmm7
000070a59add5b5a  movaps [rdx], xmm1
000070a59add5b5d  movaps [rcx], xmm12
000070a59add5b61  mov rax, 0x622906D8FA50
000070a59add5b6b  call rax
000070a59add5b6d  movaps xmm11, [rsp]
000070a59add5b72  add rsp, 0x40
000070a59add5b76  vmovaps xmm0, [rsp]
000070a59add5b7b  vmovaps xmm1, [rsp+0x10]
000070a59add5b81  vmovaps xmm2, [rsp+0x20]
000070a59add5b87  vmovaps xmm3, [rsp+0x30]
000070a59add5b8d  vmovaps xmm4, [rsp+0x40]
000070a59add5b93  vmovaps xmm5, [rsp+0x50]
000070a59add5b99  vmovaps xmm6, [rsp+0x60]
000070a59add5b9f  vmovaps xmm7, [rsp+0x70]
000070a59add5ba5  vmovaps xmm8, [rsp+0x80]
000070a59add5bae  vmovaps xmm9, [rsp+0x90]
000070a59add5bb7  vmovaps xmm10, [rsp+0xA0]
000070a59add5bc0  vmovaps xmm12, [rsp+0xB0]
000070a59add5bc9  vmovaps xmm13, [rsp+0xC0]
000070a59add5bd2  vmovaps xmm14, [rsp+0xD0]
000070a59add5bdb  vmovaps xmm15, [rsp+0xE0]
000070a59add5be4  add rsp, 0xF0
000070a59add5beb  pop r11
000070a59add5bed  pop r10
000070a59add5bef  pop r9
000070a59add5bf1  pop r8
000070a59add5bf3  pop rsi
000070a59add5bf4  pop rdi
000070a59add5bf5  pop rdx
000070a59add5bf6  pop rcx
000070a59add5bf7  pop rax
000070a59add5bf8  add rsp, 0x08
000070a59add5bfc  jmp 0x000070A59ADD3122
000070a59add5c01  call 0x000070A59ABFF430
000070a59add5c06  jmp 0x000070A59ADD3134
000070a59add5c0b  sub rsp, 0x08
000070a59add5c0f  push rax
000070a59add5c10  push rcx
000070a59add5c11  push rdx
000070a59add5c12  push rdi
000070a59add5c13  push rsi
000070a59add5c14  push r8
000070a59add5c16  push r9
000070a59add5c18  push r10
000070a59add5c1a  push r11
000070a59add5c1c  sub rsp, 0xF0
000070a59add5c23  vmovaps [rsp], xmm0
000070a59add5c28  vmovaps [rsp+0x10], xmm1
000070a59add5c2e  vmovaps [rsp+0x20], xmm2
000070a59add5c34  vmovaps [rsp+0x30], xmm3
000070a59add5c3a  vmovaps [rsp+0x40], xmm4
000070a59add5c40  vmovaps [rsp+0x50], xmm5
000070a59add5c46  vmovaps [rsp+0x60], xmm6
000070a59add5c4c  vmovaps [rsp+0x70], xmm7
000070a59add5c52  vmovaps [rsp+0x80], xmm8
000070a59add5c5b  vmovaps [rsp+0x90], xmm10
000070a59add5c64  vmovaps [rsp+0xA0], xmm11
000070a59add5c6d  vmovaps [rsp+0xB0], xmm12
000070a59add5c76  vmovaps [rsp+0xC0], xmm13
000070a59add5c7f  vmovaps [rsp+0xD0], xmm14
000070a59add5c88  vmovaps [rsp+0xE0], xmm15
000070a59add5c91  sub rsp, 0x40
000070a59add5c95  lea rdi, [rsp]
000070a59add5c99  lea rsi, [rsp+0x10]
000070a59add5c9e  lea rdx, [rsp+0x20]
000070a59add5ca3  lea rcx, [rsp+0x30]
000070a59add5ca8  mov r8d, 0x00
000070a59add5cae  lea r9, [r15+0x3A8]
000070a59add5cb5  movaps [rdi], xmm9
000070a59add5cb9  movaps [rsi], xmm8
000070a59add5cbd  movaps [rdx], xmm14
000070a59add5cc1  movaps [rcx], xmm12
000070a59add5cc5  mov rax, 0x622906D8FA50
000070a59add5ccf  call rax
000070a59add5cd1  movaps xmm9, [rsp]
000070a59add5cd6  add rsp, 0x40
000070a59add5cda  vmovaps xmm0, [rsp]
000070a59add5cdf  vmovaps xmm1, [rsp+0x10]
000070a59add5ce5  vmovaps xmm2, [rsp+0x20]
000070a59add5ceb  vmovaps xmm3, [rsp+0x30]
000070a59add5cf1  vmovaps xmm4, [rsp+0x40]
000070a59add5cf7  vmovaps xmm5, [rsp+0x50]
000070a59add5cfd  vmovaps xmm6, [rsp+0x60]
000070a59add5d03  vmovaps xmm7, [rsp+0x70]
000070a59add5d09  vmovaps xmm8, [rsp+0x80]
000070a59add5d12  vmovaps xmm10, [rsp+0x90]
000070a59add5d1b  vmovaps xmm11, [rsp+0xA0]
000070a59add5d24  vmovaps xmm12, [rsp+0xB0]
000070a59add5d2d  vmovaps xmm13, [rsp+0xC0]
000070a59add5d36  vmovaps xmm14, [rsp+0xD0]
000070a59add5d3f  vmovaps xmm15, [rsp+0xE0]
000070a59add5d48  add rsp, 0xF0
000070a59add5d4f  pop r11
000070a59add5d51  pop r10
000070a59add5d53  pop r9
000070a59add5d55  pop r8
000070a59add5d57  pop rsi
000070a59add5d58  pop rdi
000070a59add5d59  pop rdx
000070a59add5d5a  pop rcx
000070a59add5d5b  pop rax
000070a59add5d5c  add rsp, 0x08
000070a59add5d60  jmp 0x000070A59ADD3165
000070a59add5d65  sub rsp, 0x08
000070a59add5d69  push rax
000070a59add5d6a  push rcx
000070a59add5d6b  push rdx
000070a59add5d6c  push rdi
000070a59add5d6d  push rsi
000070a59add5d6e  push r8
000070a59add5d70  push r9
000070a59add5d72  push r10
000070a59add5d74  push r11
000070a59add5d76  sub rsp, 0xF0
000070a59add5d7d  vmovaps [rsp], xmm0
000070a59add5d82  vmovaps [rsp+0x10], xmm1
000070a59add5d88  vmovaps [rsp+0x20], xmm2
000070a59add5d8e  vmovaps [rsp+0x30], xmm3
000070a59add5d94  vmovaps [rsp+0x40], xmm4
000070a59add5d9a  vmovaps [rsp+0x50], xmm5
000070a59add5da0  vmovaps [rsp+0x60], xmm6
000070a59add5da6  vmovaps [rsp+0x70], xmm7
000070a59add5dac  vmovaps [rsp+0x80], xmm8
000070a59add5db5  vmovaps [rsp+0x90], xmm9
000070a59add5dbe  vmovaps [rsp+0xA0], xmm10
000070a59add5dc7  vmovaps [rsp+0xB0], xmm11
000070a59add5dd0  vmovaps [rsp+0xC0], xmm13
000070a59add5dd9  vmovaps [rsp+0xD0], xmm14
000070a59add5de2  vmovaps [rsp+0xE0], xmm15
000070a59add5deb  sub rsp, 0x40
000070a59add5def  lea rdi, [rsp]
000070a59add5df3  lea rsi, [rsp+0x10]
000070a59add5df8  lea rdx, [rsp+0x20]
000070a59add5dfd  lea rcx, [rsp+0x30]
000070a59add5e02  mov r8d, 0x00
000070a59add5e08  lea r9, [r15+0x3A8]
000070a59add5e0f  movaps [rdi], xmm12
000070a59add5e13  movaps [rsi], xmm10
000070a59add5e17  movaps [rdx], xmm15
000070a59add5e1b  movaps [rcx], xmm14
000070a59add5e1f  mov rax, 0x622906D8FA50
000070a59add5e29  call rax
000070a59add5e2b  movaps xmm12, [rsp]
000070a59add5e30  add rsp, 0x40
000070a59add5e34  vmovaps xmm0, [rsp]
000070a59add5e39  vmovaps xmm1, [rsp+0x10]
000070a59add5e3f  vmovaps xmm2, [rsp+0x20]
000070a59add5e45  vmovaps xmm3, [rsp+0x30]
000070a59add5e4b  vmovaps xmm4, [rsp+0x40]
000070a59add5e51  vmovaps xmm5, [rsp+0x50]
000070a59add5e57  vmovaps xmm6, [rsp+0x60]
000070a59add5e5d  vmovaps xmm7, [rsp+0x70]
000070a59add5e63  vmovaps xmm8, [rsp+0x80]
000070a59add5e6c  vmovaps xmm9, [rsp+0x90]
000070a59add5e75  vmovaps xmm10, [rsp+0xA0]
000070a59add5e7e  vmovaps xmm11, [rsp+0xB0]
000070a59add5e87  vmovaps xmm13, [rsp+0xC0]
000070a59add5e90  vmovaps xmm14, [rsp+0xD0]
000070a59add5e99  vmovaps xmm15, [rsp+0xE0]
000070a59add5ea2  add rsp, 0xF0
000070a59add5ea9  pop r11
000070a59add5eab  pop r10
000070a59add5ead  pop r9
000070a59add5eaf  pop r8
000070a59add5eb1  pop rsi
000070a59add5eb2  pop rdi
000070a59add5eb3  pop rdx
000070a59add5eb4  pop rcx
000070a59add5eb5  pop rax
000070a59add5eb6  add rsp, 0x08
000070a59add5eba  jmp 0x000070A59ADD3196
000070a59add5ebf  sub rsp, 0x08
000070a59add5ec3  push rax
000070a59add5ec4  push rcx
000070a59add5ec5  push rdx
000070a59add5ec6  push rdi
000070a59add5ec7  push rsi
000070a59add5ec8  push r8
000070a59add5eca  push r9
000070a59add5ecc  push r10
000070a59add5ece  push r11
000070a59add5ed0  sub rsp, 0xF0
000070a59add5ed7  vmovaps [rsp], xmm0
000070a59add5edc  vmovaps [rsp+0x10], xmm1
000070a59add5ee2  vmovaps [rsp+0x20], xmm2
000070a59add5ee8  vmovaps [rsp+0x30], xmm3
000070a59add5eee  vmovaps [rsp+0x40], xmm4
000070a59add5ef4  vmovaps [rsp+0x50], xmm5
000070a59add5efa  vmovaps [rsp+0x60], xmm6
000070a59add5f00  vmovaps [rsp+0x70], xmm7
000070a59add5f06  vmovaps [rsp+0x80], xmm8
000070a59add5f0f  vmovaps [rsp+0x90], xmm9
000070a59add5f18  vmovaps [rsp+0xA0], xmm10
000070a59add5f21  vmovaps [rsp+0xB0], xmm11
000070a59add5f2a  vmovaps [rsp+0xC0], xmm12
000070a59add5f33  vmovaps [rsp+0xD0], xmm13
000070a59add5f3c  vmovaps [rsp+0xE0], xmm15
000070a59add5f45  sub rsp, 0x40
000070a59add5f49  lea rdi, [rsp]
000070a59add5f4d  lea rsi, [rsp+0x10]
000070a59add5f52  lea rdx, [rsp+0x20]
000070a59add5f57  lea rcx, [rsp+0x30]
000070a59add5f5c  mov r8d, 0x00
000070a59add5f62  lea r9, [r15+0x3A8]
000070a59add5f69  movaps [rdi], xmm14
000070a59add5f6d  movaps [rsi], xmm13
000070a59add5f71  movaps [rdx], xmm1
000070a59add5f74  movaps [rcx], xmm15
000070a59add5f78  mov rax, 0x622906D8FA50
000070a59add5f82  call rax
000070a59add5f84  movaps xmm14, [rsp]
000070a59add5f89  add rsp, 0x40
000070a59add5f8d  vmovaps xmm0, [rsp]
000070a59add5f92  vmovaps xmm1, [rsp+0x10]
000070a59add5f98  vmovaps xmm2, [rsp+0x20]
000070a59add5f9e  vmovaps xmm3, [rsp+0x30]
000070a59add5fa4  vmovaps xmm4, [rsp+0x40]
000070a59add5faa  vmovaps xmm5, [rsp+0x50]
000070a59add5fb0  vmovaps xmm6, [rsp+0x60]
000070a59add5fb6  vmovaps xmm7, [rsp+0x70]
000070a59add5fbc  vmovaps xmm8, [rsp+0x80]
000070a59add5fc5  vmovaps xmm9, [rsp+0x90]
000070a59add5fce  vmovaps xmm10, [rsp+0xA0]
000070a59add5fd7  vmovaps xmm11, [rsp+0xB0]
000070a59add5fe0  vmovaps xmm12, [rsp+0xC0]
000070a59add5fe9  vmovaps xmm13, [rsp+0xD0]
000070a59add5ff2  vmovaps xmm15, [rsp+0xE0]
000070a59add5ffb  add rsp, 0xF0
000070a59add6002  pop r11
000070a59add6004  pop r10
000070a59add6006  pop r9
000070a59add6008  pop r8
000070a59add600a  pop rsi
000070a59add600b  pop rdi
000070a59add600c  pop rdx
000070a59add600d  pop rcx
000070a59add600e  pop rax
000070a59add600f  add rsp, 0x08
000070a59add6013  jmp 0x000070A59ADD31C7
000070a59add6018  call 0x000070A59AC079B0
000070a59add601d  jmp 0x000070A59ADD31DA
000070a59add6022  call 0x000070A59AC0B100
000070a59add6027  jmp 0x000070A59ADD31E5
000070a59add602c  call 0x000070A59AC09E90
000070a59add6031  jmp 0x000070A59ADD31F0
000070a59add6036  call 0x000070A59AC0D600
000070a59add603b  jmp 0x000070A59ADD31FB
000070a59add6040  int3
000070a59add6041  nop [rax+rax*1], ax
000070a59add604a  nop [rax+rax*1], ax
000070a59add6050  mov rax, [r15+0x40]
000070a59add6054  mov r14, [r15+0x58]
000070a59add6058  lea r12, [rax+r14*1]
000070a59add605c  vxorps xmm1, xmm1, xmm1
000070a59add6060  vpbroadcastq xmm1, xmm1
000070a59add6065  vxorps xmm15, xmm15, xmm15
000070a59add606a  vpbroadcastq xmm15, xmm15
000070a59add606f  lea rax, [r12+0x30]
000070a59add6074  mov r11, [r13+rax*1]
000070a59add6079  lea rax, [r12+0x38]
000070a59add607e  mov r10, [r13+rax*1]
000070a59add6083  movq xmm14, r11
000070a59add6088  movq xmm13, r10
000070a59add608d  movq xmm14, xmm14
000070a59add6092  movq xmm13, xmm13
000070a59add6097  vmovaps [rsp+0x10], xmm13
000070a59add609d  movq xmm13, xmm13
000070a59add60a2  movaps [r15+0x270], xmm13
000070a59add60aa  movaps xmm13, [r15+0x160]
000070a59add60b2  vmovaps [rsp+0x20], xmm13
000070a59add60b8  vmovaps xmm12, [rsp+0x20]
000070a59add60be  por xmm13, xmm12
000070a59add60c3  lea rax, [r12+0x20]
000070a59add60c8  mov r11, [r13+rax*1]
000070a59add60cd  lea rax, [r12+0x28]
000070a59add60d2  mov r10, [r13+rax*1]
000070a59add60d7  movq xmm12, r11
000070a59add60dc  movq xmm11, r10
000070a59add60e1  movq xmm12, xmm12
000070a59add60e6  movq xmm11, xmm11
000070a59add60eb  movaps xmm10, [r15+0x2D0]
000070a59add60f3  vmovaps [rsp+0x20], xmm10
000070a59add60f9  vmovaps xmm9, [rsp+0x20]
000070a59add60ff  por xmm10, xmm9
000070a59add6104  movaps xmm9, [r15+0x300]
000070a59add610c  vmovaps [rsp+0x20], xmm9
000070a59add6112  vmovaps xmm8, [rsp+0x20]
000070a59add6118  por xmm9, xmm8
000070a59add611d  movaps xmm8, [r15+0x2B0]
000070a59add6125  vmovaps [rsp+0x20], xmm8
000070a59add612b  vmovaps xmm7, [rsp+0x20]
000070a59add6131  por xmm8, xmm7
000070a59add6136  movaps xmm7, [r15+0x180]
000070a59add613e  vmovaps [rsp+0x20], xmm7
000070a59add6144  vmovaps xmm6, [rsp+0x20]
000070a59add614a  por xmm7, xmm6
000070a59add614e  lea rax, [r12+0x10]
000070a59add6153  mov r11, [r13+rax*1]
000070a59add6158  lea rax, [r12+0x18]
000070a59add615d  mov r10, [r13+rax*1]
000070a59add6162  movq xmm6, r11
000070a59add6167  movq xmm5, r10
000070a59add616c  movq xmm6, xmm6
000070a59add6170  movq xmm5, xmm5
000070a59add6174  movaps xmm4, [r15+0x200]
000070a59add617c  vmovaps [rsp+0x20], xmm4
000070a59add6182  vmovaps xmm3, [rsp+0x20]
000070a59add6188  por xmm4, xmm3
000070a59add618c  movaps xmm3, [r15+0x1F0]
000070a59add6194  vmovaps [rsp+0x20], xmm3
000070a59add619a  vmovaps xmm2, [rsp+0x20]
000070a59add61a0  por xmm3, xmm2
000070a59add61a4  movaps xmm2, [r15+0x2E0]
000070a59add61ac  vmovaps [rsp+0x20], xmm2
000070a59add61b2  vmovaps [rsp+0x30], xmm1
000070a59add61b8  vmovaps xmm1, [rsp+0x20]
000070a59add61be  por xmm2, xmm1
000070a59add61c2  movaps xmm1, [r15+0x2A0]
000070a59add61ca  vmovaps [rsp+0x20], xmm1
000070a59add61d0  vmovaps [rsp+0x40], xmm15
000070a59add61d6  vmovaps xmm15, [rsp+0x20]
000070a59add61dc  por xmm1, xmm15
000070a59add61e1  movaps xmm15, [r15+0x280]
000070a59add61e9  vmovaps [rsp+0x20], xmm15
000070a59add61ef  vmovaps [rsp+0x50], xmm1
000070a59add61f5  vmovaps xmm1, [rsp+0x20]
000070a59add61fb  por xmm15, xmm1
000070a59add6200  movaps xmm1, [r15+0x1C0]
000070a59add6208  vmovaps [rsp+0x20], xmm1
000070a59add620e  vmovaps [rsp+0x60], xmm15
000070a59add6214  vmovaps xmm15, [rsp+0x20]
000070a59add621a  por xmm1, xmm15
000070a59add621f  movaps xmm15, [r15+0x210]
000070a59add6227  vmovaps [rsp+0x20], xmm15
000070a59add622d  vmovaps [rsp+0x70], xmm1
000070a59add6233  vmovaps xmm1, [rsp+0x20]
000070a59add6239  por xmm15, xmm1
000070a59add623e  mov rax, [r13+r12*1]
000070a59add6243  vmovq xmm1, rax
000070a59add6248  vpbroadcastq xmm1, xmm1
000070a59add624d  vmovaps [rsp+0x20], xmm1
000070a59add6253  vxorps xmm1, xmm1, xmm1
000070a59add6257  vpbroadcastq xmm1, xmm1
000070a59add625c  mov rax, [r15+0xF8]
000070a59add6263  vmovaps [rsp+0x80], xmm1
000070a59add626c  movups xmm1, [r13+rax*1]
000070a59add6272  vmovaps [rsp+0x90], xmm1
000070a59add627b  vxorps xmm1, xmm1, xmm1
000070a59add627f  vpbroadcastq xmm1, xmm1
000070a59add6284  lea r11, [r12+0x08]
000070a59add6289  mov r12, [r13+r11*1]
000070a59add628e  vmovaps [rsp+0xA0], xmm1
000070a59add6297  movq xmm1, r12
000070a59add629c  movaps [r15+0x240], xmm1
000070a59add62a4  mov r12, [r15+0x50]
000070a59add62a8  lea r11, [r12+r14*1]
000070a59add62ac  mov [r15+0x60], r11
000070a59add62b0  lea r12, [r14+0x40]
000070a59add62b4  mov [r15+0x58], r12
000070a59add62b8  vmovaps xmm1, [rsp+0x30]
000070a59add62be  vmovaps [rsp+0x30], xmm15
000070a59add62c4  vmovaps xmm15, [rsp+0x90]
000070a59add62cd  vmovaps [rsp+0x90], xmm14
000070a59add62d6  vmovaps xmm14, [rsp+0x20]
000070a59add62dc  vmovaps [rsp+0x20], xmm13
000070a59add62e2  vmovaps [rsp+0xB0], xmm12
000070a59add62eb  movaps xmm13, xmm1
000070a59add62ef  vfmadd231pd xmm13, xmm15, xmm14
000070a59add62f4  vcmppd xmm12, xmm13, xmm13, 0x03
000070a59add62fa  vptest xmm12, xmm12
000070a59add62ff  jnz 0x000070A59ADD6D9C
000070a59add6305  movaps xmm1, [r15+0x250]
000070a59add630d  vmovaps xmm15, [rsp+0x40]
000070a59add6313  vmovaps [rsp+0x40], xmm13
000070a59add6319  movaps xmm12, xmm15
000070a59add631d  vfmadd231pd xmm12, xmm1, xmm14
000070a59add6322  vcmppd xmm13, xmm12, xmm12, 0x03
000070a59add6328  vptest xmm13, xmm13
000070a59add632d  jnz 0x000070A59ADD6EF5
000070a59add6333  movaps xmm15, [r15+0x1E0]
000070a59add633b  vmovaps [rsp+0xC0], xmm15
000070a59add6344  vmovaps xmm13, [rsp+0xC0]
000070a59add634d  por xmm15, xmm13
000070a59add6352  movaps xmm13, [r15+0x1D0]
000070a59add635a  vmovaps [rsp+0xC0], xmm13
000070a59add6363  vmovaps [rsp+0xD0], xmm1
000070a59add636c  vmovaps xmm1, [rsp+0xC0]
000070a59add6375  por xmm13, xmm1
000070a59add637a  movaps xmm1, [r15+0x2C0]
000070a59add6382  vmovaps [rsp+0xC0], xmm1
000070a59add638b  vmovaps [rsp+0xE0], xmm15
000070a59add6394  vmovaps xmm15, [rsp+0xC0]
000070a59add639d  por xmm1, xmm15
000070a59add63a2  movaps xmm15, [r15+0x290]
000070a59add63aa  vmovaps [rsp+0xC0], xmm15
000070a59add63b3  vmovaps [rsp+0xF0], xmm1
000070a59add63bc  vmovaps xmm1, [rsp+0xC0]
000070a59add63c5  por xmm15, xmm1
000070a59add63ca  movaps xmm1, [r15+0x260]
000070a59add63d2  vmovaps [rsp+0xC0], xmm1
000070a59add63db  vmovaps [rsp+0x100], xmm15
000070a59add63e4  vmovaps xmm15, [rsp+0xC0]
000070a59add63ed  por xmm1, xmm15
000070a59add63f2  vmovaps xmm15, [rsp+0xD0]
000070a59add63fb  vmovaps [rsp+0xC0], xmm1
000070a59add6404  vmovaps xmm1, [rsp+0xD0]
000070a59add640d  por xmm15, xmm1
000070a59add6412  lea r14, [rax+0xC0]
000070a59add6419  movups xmm1, [r13+r14*1]
000070a59add641f  mov [rsp+0xD0], rax
000070a59add6427  xor eax, eax
000070a59add6429  mov r14d, 0x200
000070a59add642f  cmp r12, r14
000070a59add6432  cmc
000070a59add6433  lahf
000070a59add6434  seto al
000070a59add6437  mov [r15+0x108], eax
000070a59add643e  vmovaps [rsp+0x110], xmm1
000070a59add6447  vmovaps xmm1, [rsp+0x80]
000070a59add6450  vmovaps [rsp+0x80], xmm15
000070a59add6459  vmovaps xmm15, [rsp+0x110]
000070a59add6462  vmovaps [rsp+0x110], xmm13
000070a59add646b  vmovaps [rsp+0x120], xmm12
000070a59add6474  movaps xmm13, xmm1
000070a59add6478  vfmadd231pd xmm13, xmm15, xmm14
000070a59add647d  vcmppd xmm12, xmm13, xmm13, 0x03
000070a59add6483  vptest xmm12, xmm12
000070a59add6488  jnz 0x000070A59ADD7058
000070a59add648e  mov rax, [rsp+0xD0]
000070a59add6496  lea r14, [rax+0xB0]
000070a59add649d  movups xmm1, [r13+r14*1]
000070a59add64a3  vmovaps xmm15, [rsp+0xA0]
000070a59add64ac  vmovaps [rsp+0xA0], xmm13
000070a59add64b5  movaps xmm12, xmm15
000070a59add64b9  vfmadd231pd xmm12, xmm1, xmm14
000070a59add64be  vcmppd xmm13, xmm12, xmm12, 0x03
000070a59add64c4  vptest xmm13, xmm13
000070a59add64c9  jnz 0x000070A59ADD71BB
000070a59add64cf  vmovaps xmm1, [rsp+0x30]
000070a59add64d5  vmovaps xmm15, [rsp+0x30]
000070a59add64db  por xmm1, xmm15
000070a59add64e0  movaps [r15+0x210], xmm1
000070a59add64e8  vmovaps xmm15, [rsp+0x70]
000070a59add64ee  vmovaps xmm14, [rsp+0x70]
000070a59add64f4  por xmm15, xmm14
000070a59add64f9  movaps [r15+0x1C0], xmm15
000070a59add6501  vmovaps xmm14, [rsp+0x60]
000070a59add6507  vmovaps xmm13, [rsp+0x60]
000070a59add650d  por xmm14, xmm13
000070a59add6512  movaps [r15+0x280], xmm14
000070a59add651a  vmovaps xmm13, [rsp+0x50]
000070a59add6520  vmovaps [rsp+0x30], xmm1
000070a59add6526  vmovaps xmm1, [rsp+0x50]
000070a59add652c  por xmm13, xmm1
000070a59add6531  movaps [r15+0x2A0], xmm13
000070a59add6539  vmovaps [rsp+0x50], xmm2
000070a59add653f  vmovaps xmm1, [rsp+0x50]
000070a59add6545  por xmm2, xmm1
000070a59add6549  movaps [r15+0x2E0], xmm2
000070a59add6551  vmovaps [rsp+0x50], xmm3
000070a59add6557  vmovaps xmm1, [rsp+0x50]
000070a59add655d  por xmm3, xmm1
000070a59add6561  movaps [r15+0x1F0], xmm3
000070a59add6569  vmovaps xmm1, [rsp+0x80]
000070a59add6572  vmovaps [rsp+0x50], xmm15
000070a59add6578  vmovaps xmm15, [rsp+0x80]
000070a59add6581  por xmm1, xmm15
000070a59add6586  movaps [r15+0x250], xmm1
000070a59add658e  vmovaps xmm1, [rsp+0xC0]
000070a59add6597  vmovaps xmm15, [rsp+0xC0]
000070a59add65a0  por xmm1, xmm15
000070a59add65a5  movaps [r15+0x260], xmm1
000070a59add65ad  vmovaps xmm15, [rsp+0x100]
000070a59add65b6  vmovaps [rsp+0x60], xmm1
000070a59add65bc  vmovaps xmm1, [rsp+0x100]
000070a59add65c5  por xmm15, xmm1
000070a59add65ca  movaps [r15+0x290], xmm15
000070a59add65d2  vmovaps xmm1, [rsp+0xF0]
000070a59add65db  vmovaps [rsp+0x70], xmm15
000070a59add65e1  vmovaps xmm15, [rsp+0xF0]
000070a59add65ea  por xmm1, xmm15
000070a59add65ef  movaps [r15+0x2C0], xmm1
000070a59add65f7  movq xmm15, qword ptr [r15+0x240]
000070a59add6600  vmovaps [rsp+0x80], xmm15
000070a59add6609  vpermilpd xmm15, xmm15, 0x00
000070a59add660f  vmovaps [rsp+0xC0], xmm1
000070a59add6618  vmovaps xmm1, [rsp+0x40]
000070a59add661e  vmovaps [rsp+0x40], xmm15
000070a59add6624  vmovaps xmm15, [rsp+0x30]
000070a59add662a  vmovaps [rsp+0x30], xmm14
000070a59add6630  vmovaps xmm14, [rsp+0x40]
000070a59add6636  vmovaps [rsp+0x40], xmm13
000070a59add663c  vmovaps [rsp+0xD0], xmm12
000070a59add6645  movaps xmm13, xmm1
000070a59add6649  vfmadd231pd xmm13, xmm15, xmm14
000070a59add664e  vcmppd xmm12, xmm13, xmm13, 0x03
000070a59add6654  vptest xmm12, xmm12
000070a59add6659  jnz 0x000070A59ADD7314
000070a59add665f  vmovaps xmm1, [rsp+0x80]
000070a59add6668  vpermilpd xmm1, xmm1, 0x00
000070a59add666e  vmovaps xmm15, [rsp+0xA0]
000070a59add6677  movaps xmm14, xmm15
000070a59add667b  vfmadd231pd xmm14, xmm2, xmm1
000070a59add6680  vcmppd xmm12, xmm14, xmm14, 0x03
000070a59add6686  vptest xmm12, xmm12
000070a59add668b  jnz 0x000070A59ADD746D
000070a59add6691  vmovaps xmm1, [rsp+0x80]
000070a59add669a  vpermilpd xmm1, xmm1, 0x00
000070a59add66a0  vmovaps xmm15, [rsp+0x120]
000070a59add66a9  vmovaps xmm12, [rsp+0x50]
000070a59add66af  vmovaps [rsp+0x50], xmm14
000070a59add66b5  movaps xmm2, xmm15
000070a59add66b9  vfmadd231pd xmm2, xmm12, xmm1
000070a59add66be  vcmppd xmm14, xmm2, xmm2, 0x03
000070a59add66c3  vptest xmm14, xmm14
000070a59add66c8  jnz 0x000070A59ADD75C5
000070a59add66ce  vmovaps xmm1, [rsp+0x110]
000070a59add66d7  vmovaps xmm15, [rsp+0x110]
000070a59add66e0  por xmm1, xmm15
000070a59add66e5  movaps [r15+0x1D0], xmm1
000070a59add66ed  vmovaps xmm15, [rsp+0x80]
000070a59add66f6  vpermilpd xmm15, xmm15, 0x00
000070a59add66fc  vmovaps xmm14, [rsp+0xD0]
000070a59add6705  vmovaps [rsp+0x80], xmm1
000070a59add670e  movaps xmm12, xmm14
000070a59add6712  vfmadd231pd xmm12, xmm3, xmm15
000070a59add6717  vcmppd xmm1, xmm12, xmm12, 0x03
000070a59add671d  vptest xmm1, xmm1
000070a59add6722  jnz 0x000070A59ADD771C
000070a59add6728  vmovaps [rsp+0xA0], xmm4
000070a59add6731  vmovaps xmm1, [rsp+0xA0]
000070a59add673a  por xmm4, xmm1
000070a59add673e  movaps [r15+0x200], xmm4
000070a59add6746  vmovaps xmm1, [rsp+0xE0]
000070a59add674f  vmovaps xmm15, [rsp+0xE0]
000070a59add6758  por xmm1, xmm15
000070a59add675d  movaps [r15+0x1E0], xmm1
000070a59add6765  vmovaps [rsp+0xA0], xmm8
000070a59add676e  vmovaps xmm1, [rsp+0xA0]
000070a59add6777  por xmm8, xmm1
000070a59add677c  movaps [r15+0x2B0], xmm8
000070a59add6784  vmovaps [rsp+0xA0], xmm9
000070a59add678d  vmovaps xmm1, [rsp+0xA0]
000070a59add6796  por xmm9, xmm1
000070a59add679b  movaps [r15+0x300], xmm9
000070a59add67a3  vmovaps [rsp+0xA0], xmm6
000070a59add67ac  vpermilpd xmm6, xmm6, 0x00
000070a59add67b2  vmovaps xmm14, [rsp+0x60]
000070a59add67b8  movaps xmm9, xmm13
000070a59add67bc  vfmadd231pd xmm9, xmm14, xmm6
000070a59add67c1  vcmppd xmm3, xmm9, xmm9, 0x03
000070a59add67c7  vptest xmm3, xmm3
000070a59add67cc  jnz 0x000070A59ADD7875
000070a59add67d2  vmovaps xmm14, [rsp+0xA0]
000070a59add67db  vpermilpd xmm14, xmm14, 0x00
000070a59add67e1  vmovaps xmm13, [rsp+0x50]
000070a59add67e7  vmovaps xmm6, [rsp+0xC0]
000070a59add67f0  vmovaps [rsp+0x50], xmm1
000070a59add67f6  movaps xmm3, xmm13
000070a59add67fa  vfmadd231pd xmm3, xmm6, xmm14
000070a59add67ff  vcmppd xmm1, xmm3, xmm3, 0x03
000070a59add6804  vptest xmm1, xmm1
000070a59add6809  jnz 0x000070A59ADD79CE
000070a59add680f  vmovaps xmm1, [rsp+0xA0]
000070a59add6818  vpermilpd xmm1, xmm1, 0x00
000070a59add681e  vmovaps xmm14, [rsp+0x30]
000070a59add6824  movaps xmm6, xmm2
000070a59add6827  vfmadd231pd xmm6, xmm14, xmm1
000070a59add682c  vcmppd xmm13, xmm6, xmm6, 0x03
000070a59add6831  vptest xmm13, xmm13
000070a59add6836  jnz 0x000070A59ADD7B25
000070a59add683c  vmovaps xmm1, [rsp+0xA0]
000070a59add6845  vpermilpd xmm1, xmm1, 0x00
000070a59add684b  vmovaps xmm14, [rsp+0x80]
000070a59add6854  movaps xmm13, xmm12
000070a59add6858  vfmadd231pd xmm13, xmm14, xmm1
000070a59add685d  vcmppd xmm2, xmm13, xmm13, 0x03
000070a59add6863  vptest xmm2, xmm2
000070a59add6868  jnz 0x000070A59ADD7C7B
000070a59add686e  vmovaps [rsp+0x30], xmm7
000070a59add6874  vmovaps xmm1, [rsp+0x30]
000070a59add687a  por xmm7, xmm1
000070a59add687e  movaps [r15+0x180], xmm7
000070a59add6886  vmovaps [rsp+0x30], xmm10
000070a59add688c  vmovaps xmm1, [rsp+0x30]
000070a59add6892  por xmm10, xmm1
000070a59add6897  movaps [r15+0x2D0], xmm10
000070a59add689f  vmovaps [rsp+0x30], xmm5
000070a59add68a5  vpermilpd xmm5, xmm5, 0x00
000070a59add68ab  vmovaps xmm14, [rsp+0x50]
000070a59add68b1  movaps xmm12, xmm3
000070a59add68b5  vfmadd231pd xmm12, xmm14, xmm5
000070a59add68ba  vcmppd xmm10, xmm12, xmm12, 0x03
000070a59add68c0  vptest xmm10, xmm10
000070a59add68c5  jnz 0x000070A59ADD7DD4
000070a59add68cb  vmovaps xmm14, [rsp+0x30]
000070a59add68d1  vpermilpd xmm14, xmm14, 0x00
000070a59add68d7  movaps xmm10, xmm9
000070a59add68db  vfmadd231pd xmm10, xmm7, xmm14
000070a59add68e0  vcmppd xmm5, xmm10, xmm10, 0x03
000070a59add68e6  vptest xmm5, xmm5
000070a59add68eb  jnz 0x000070A59ADD7F2C
000070a59add68f1  lea r14, [rax+0x80]
000070a59add68f8  movups xmm14, [r13+r14*1]
000070a59add68fe  movaps [r15+0x2F0], xmm14
000070a59add6906  vmovaps xmm9, [rsp+0x30]
000070a59add690c  vpermilpd xmm9, xmm9, 0x00
000070a59add6912  vmovaps xmm7, [rsp+0x70]
000070a59add6918  movaps xmm5, xmm6
000070a59add691b  vfmadd231pd xmm5, xmm7, xmm9
000070a59add6920  vcmppd xmm3, xmm5, xmm5, 0x03
000070a59add6925  vptest xmm3, xmm3
000070a59add692a  jnz 0x000070A59ADD808F
000070a59add6930  vmovaps xmm9, [rsp+0x30]
000070a59add6936  vpermilpd xmm9, xmm9, 0x00
000070a59add693c  movaps xmm7, xmm13
000070a59add6940  vfmadd231pd xmm7, xmm1, xmm9
000070a59add6945  vcmppd xmm6, xmm7, xmm7, 0x03
000070a59add694a  vptest xmm6, xmm6
000070a59add694f  jnz 0x000070A59ADD81E5
000070a59add6955  vmovaps xmm1, [rsp+0x20]
000070a59add695b  vmovaps xmm13, [rsp+0x20]
000070a59add6961  por xmm1, xmm13
000070a59add6966  movaps [r15+0x160], xmm1
000070a59add696e  lea r14, [rax+0x40]
000070a59add6972  movups xmm13, [r13+r14*1]
000070a59add6978  lea r14, [rax+0x50]
000070a59add697c  movups xmm9, [r13+r14*1]
000070a59add6982  movaps [r15+0x1B0], xmm13
000070a59add698a  movaps [r15+0x1A0], xmm9
000070a59add6992  movaps xmm6, [r15+0x190]
000070a59add699a  vmovaps xmm3, [rsp+0xB0]
000070a59add69a3  vpermilpd xmm3, xmm3, 0x00
000070a59add69a9  vmovaps [rsp+0x20], xmm1
000070a59add69af  movaps xmm2, xmm12
000070a59add69b3  vfmadd231pd xmm2, xmm6, xmm3
000070a59add69b8  vcmppd xmm1, xmm2, xmm2, 0x03
000070a59add69bd  vptest xmm1, xmm1
000070a59add69c2  jnz 0x000070A59ADD8350
000070a59add69c8  vmovaps xmm1, [rsp+0xB0]
000070a59add69d1  vpermilpd xmm1, xmm1, 0x00
000070a59add69d7  vmovaps xmm12, [rsp+0x20]
000070a59add69dd  movaps xmm6, xmm10
000070a59add69e1  vfmadd231pd xmm6, xmm12, xmm1
000070a59add69e6  vcmppd xmm3, xmm6, xmm6, 0x03
000070a59add69eb  vptest xmm3, xmm3
000070a59add69f0  jnz 0x000070A59ADD84A6
000070a59add69f6  vmovaps xmm1, [rsp+0xB0]
000070a59add69ff  vpermilpd xmm1, xmm1, 0x00
000070a59add6a05  vmovaps xmm12, [rsp+0x40]
000070a59add6a0b  movaps xmm10, xmm5
000070a59add6a0f  vfmadd231pd xmm10, xmm12, xmm1
000070a59add6a14  vcmppd xmm3, xmm10, xmm10, 0x03
000070a59add6a1a  vptest xmm3, xmm3
000070a59add6a1f  jnz 0x000070A59ADD85FD
000070a59add6a25  vmovaps xmm1, [rsp+0xB0]
000070a59add6a2e  vpermilpd xmm1, xmm1, 0x00
000070a59add6a34  movaps xmm12, xmm7
000070a59add6a38  vfmadd231pd xmm12, xmm15, xmm1
000070a59add6a3d  vcmppd xmm5, xmm12, xmm12, 0x03
000070a59add6a43  vptest xmm5, xmm5
000070a59add6a48  jnz 0x000070A59ADD8755
000070a59add6a4e  lea r14, [rax+0x60]
000070a59add6a52  movups xmm1, [r13+r14*1]
000070a59add6a58  lea r14, [rax+0x70]
000070a59add6a5c  movups xmm15, [r13+r14*1]
000070a59add6a62  movaps [r15+0x150], xmm1
000070a59add6a6a  movaps [r15+0x120], xmm15
000070a59add6a72  vmovaps [rsp+0x20], xmm11
000070a59add6a78  vpermilpd xmm11, xmm11, 0x00
000070a59add6a7e  movaps xmm7, xmm2
000070a59add6a81  vfmadd231pd xmm7, xmm9, xmm11
000070a59add6a86  vcmppd xmm5, xmm7, xmm7, 0x03
000070a59add6a8b  vptest xmm5, xmm5
000070a59add6a90  jnz 0x000070A59ADD88C1
000070a59add6a96  vmovaps xmm11, [rsp+0x20]
000070a59add6a9c  vpermilpd xmm11, xmm11, 0x00
000070a59add6aa2  movaps xmm9, xmm6
000070a59add6aa6  vfmadd231pd xmm9, xmm1, xmm11
000070a59add6aab  vcmppd xmm5, xmm9, xmm9, 0x03
000070a59add6ab1  vptest xmm5, xmm5
000070a59add6ab6  jnz 0x000070A59ADD8A18
000070a59add6abc  vmovaps xmm1, [rsp+0x20]
000070a59add6ac2  vpermilpd xmm1, xmm1, 0x00
000070a59add6ac8  movaps xmm11, xmm10
000070a59add6acc  vfmadd231pd xmm11, xmm8, xmm1
000070a59add6ad1  vcmppd xmm6, xmm11, xmm11, 0x03
000070a59add6ad7  vptest xmm6, xmm6
000070a59add6adc  jnz 0x000070A59ADD8B70
000070a59add6ae2  vmovaps xmm1, [rsp+0x20]
000070a59add6ae8  vpermilpd xmm1, xmm1, 0x00
000070a59add6aee  movaps xmm10, xmm12
000070a59add6af2  vfmadd231pd xmm10, xmm13, xmm1
000070a59add6af7  vcmppd xmm8, xmm10, xmm10, 0x03
000070a59add6afd  vptest xmm8, xmm8
000070a59add6b02  jnz 0x000070A59ADD8CC9
000070a59add6b08  lea r14, [rax+0x20]
000070a59add6b0c  movups xmm1, [r13+r14*1]
000070a59add6b12  lea r14, [rax+0x30]
000070a59add6b16  movups xmm13, [r13+r14*1]
000070a59add6b1c  vmovaps xmm12, [rsp+0x90]
000070a59add6b25  vpermilpd xmm12, xmm12, 0x00
000070a59add6b2b  movaps xmm8, xmm7
000070a59add6b2f  vfmadd231pd xmm8, xmm4, xmm12
000070a59add6b34  vcmppd xmm6, xmm8, xmm8, 0x03
000070a59add6b3a  vptest xmm6, xmm6
000070a59add6b3f  jnz 0x000070A59ADD8E36
000070a59add6b45  vmovaps xmm12, [rsp+0x90]
000070a59add6b4e  vpermilpd xmm12, xmm12, 0x00
000070a59add6b54  movaps xmm7, xmm9
000070a59add6b58  vfmadd231pd xmm7, xmm14, xmm12
000070a59add6b5d  vcmppd xmm6, xmm7, xmm7, 0x03
000070a59add6b62  vptest xmm6, xmm6
000070a59add6b67  jnz 0x000070A59ADD8F8E
000070a59add6b6d  vmovaps xmm14, [rsp+0x90]
000070a59add6b76  vpermilpd xmm14, xmm14, 0x00
000070a59add6b7c  movaps xmm12, xmm11
000070a59add6b80  vfmadd231pd xmm12, xmm15, xmm14
000070a59add6b85  vcmppd xmm9, xmm12, xmm12, 0x03
000070a59add6b8b  vptest xmm9, xmm9
000070a59add6b90  jnz 0x000070A59ADD90E6
000070a59add6b96  vmovaps xmm15, [rsp+0x90]
000070a59add6b9f  vpermilpd xmm15, xmm15, 0x00
000070a59add6ba5  movaps xmm11, xmm10
000070a59add6ba9  vfmadd231pd xmm11, xmm13, xmm15
000070a59add6bae  vcmppd xmm14, xmm11, xmm11, 0x03
000070a59add6bb4  vptest xmm14, xmm14
000070a59add6bb9  jnz 0x000070A59ADD9240
000070a59add6bbf  lea r14, [rax+0x90]
000070a59add6bc6  movups xmm15, [r13+r14*1]
000070a59add6bcc  lea r14, [rax+0xA0]
000070a59add6bd3  movups xmm14, [r13+r14*1]
000070a59add6bd9  movaps [r15+0x140], xmm15
000070a59add6be1  movaps [r15+0x130], xmm14
000070a59add6be9  vmovaps xmm13, [rsp+0x10]
000070a59add6bef  vpermilpd xmm13, xmm13, 0x00
000070a59add6bf5  movaps xmm10, xmm8
000070a59add6bf9  vfmadd231pd xmm10, xmm1, xmm13
000070a59add6bfe  vcmppd xmm9, xmm10, xmm10, 0x03
000070a59add6c04  vptest xmm9, xmm9
000070a59add6c09  jnz 0x000070A59ADD93AE
000070a59add6c0f  movaps [r15+0x220], xmm10
000070a59add6c17  lea r14, [rax+0x10]
000070a59add6c1b  movups xmm1, [r13+r14*1]
000070a59add6c21  movaps [r15+0x240], xmm1
000070a59add6c29  vmovaps xmm13, [rsp+0x10]
000070a59add6c2f  vpermilpd xmm13, xmm13, 0x00
000070a59add6c35  movaps xmm9, xmm7
000070a59add6c39  vfmadd231pd xmm9, xmm14, xmm13
000070a59add6c3e  vcmppd xmm8, xmm9, xmm9, 0x03
000070a59add6c44  vptest xmm8, xmm8
000070a59add6c49  jnz 0x000070A59ADD9511
000070a59add6c4f  movaps [r15+0x110], xmm9
000070a59add6c57  vmovaps xmm14, [rsp+0x10]
000070a59add6c5d  vpermilpd xmm14, xmm14, 0x00
000070a59add6c63  movaps xmm13, xmm12
000070a59add6c67  vfmadd231pd xmm13, xmm15, xmm14
000070a59add6c6c  vcmppd xmm8, xmm13, xmm13, 0x03
000070a59add6c72  vptest xmm8, xmm8
000070a59add6c77  jnz 0x000070A59ADD966A
000070a59add6c7d  movaps [r15+0x170], xmm13
000070a59add6c85  vmovaps xmm15, [rsp+0x10]
000070a59add6c8b  vpermilpd xmm15, xmm15, 0x00
000070a59add6c91  movaps xmm14, xmm11
000070a59add6c95  vfmadd231pd xmm14, xmm1, xmm15
000070a59add6c9a  vcmppd xmm12, xmm14, xmm14, 0x03
000070a59add6ca0  vptest xmm12, xmm12
000070a59add6ca5  jnz 0x000070A59ADD97C4
000070a59add6cab  movaps [r15+0x230], xmm14
000070a59add6cb3  movups [r13+r11*1], xmm9
000070a59add6cb9  lea rax, [r11+0x10]
000070a59add6cbd  movups [r13+rax*1], xmm13
000070a59add6cc3  lea rax, [r11+0x20]
000070a59add6cc7  movups [r13+rax*1], xmm10
000070a59add6ccd  lea rax, [r11+0x30]
000070a59add6cd1  movups [r13+rax*1], xmm14
000070a59add6cd7  mov eax, [r15+0x108]
000070a59add6cde  sahf
000070a59add6cdf  jnz 0x000070A59ADD6D11
000070a59add6ce1  cmp dword ptr [r15+0x318], 0x00
000070a59add6ce9  jz 0x000070A59ADD9950
000070a59add6cef  nop [rax+rax*1], ax
000070a59add6cf8  nop [rax+rax*1], eax
000070a59add6d00  mov eax, 0x410664
000070a59add6d05  mov [r15+0x100], rax
000070a59add6d0c  jmp 0x000070A59ABFE110
000070a59add6d11  cmp dword ptr [r15+0x318], 0x00
000070a59add6d19  jz 0x000070A59ADD6050
000070a59add6d1f  nop [rax+rax*1], ax
000070a59add6d28  nop [rax+rax*1], eax
000070a59add6d30  mov eax, 0x4104F0
000070a59add6d35  mov [r15+0x100], rax
000070a59add6d3c  jmp 0x000070A59ABFE110
000070a59add6d41  int3
000070a59add6d42  call 0x000070A59AC0A4B0
000070a59add6d47  jmp 0x000070A59ADD6079
000070a59add6d4c  call 0x000070A59AC09240
000070a59add6d51  jmp 0x000070A59ADD6083
000070a59add6d56  call 0x000070A59AC0A4B0
000070a59add6d5b  jmp 0x000070A59ADD60CD
000070a59add6d60  call 0x000070A59AC09240
000070a59add6d65  jmp 0x000070A59ADD60D7
000070a59add6d6a  call 0x000070A59AC0A4B0
000070a59add6d6f  jmp 0x000070A59ADD6158
000070a59add6d74  call 0x000070A59AC09240
000070a59add6d79  jmp 0x000070A59ADD6162
000070a59add6d7e  call 0x000070A59ACB47C0
000070a59add6d83  jmp 0x000070A59ADD6243
000070a59add6d88  call 0x000070A59ABFF430
000070a59add6d8d  jmp 0x000070A59ADD6272
000070a59add6d92  call 0x000070A59ACB0CE0
000070a59add6d97  jmp 0x000070A59ADD628E
000070a59add6d9c  sub rsp, 0x08
000070a59add6da0  push rax
000070a59add6da1  push rcx
000070a59add6da2  push rdx
000070a59add6da3  push rdi
000070a59add6da4  push rsi
000070a59add6da5  push r8
000070a59add6da7  push r9
000070a59add6da9  push r10
000070a59add6dab  push r11
000070a59add6dad  sub rsp, 0xF0
000070a59add6db4  vmovaps [rsp], xmm0
000070a59add6db9  vmovaps [rsp+0x10], xmm1
000070a59add6dbf  vmovaps [rsp+0x20], xmm2
000070a59add6dc5  vmovaps [rsp+0x30], xmm3
000070a59add6dcb  vmovaps [rsp+0x40], xmm4
000070a59add6dd1  vmovaps [rsp+0x50], xmm5
000070a59add6dd7  vmovaps [rsp+0x60], xmm6
000070a59add6ddd  vmovaps [rsp+0x70], xmm7
000070a59add6de3  vmovaps [rsp+0x80], xmm8
000070a59add6dec  vmovaps [rsp+0x90], xmm9
000070a59add6df5  vmovaps [rsp+0xA0], xmm10
000070a59add6dfe  vmovaps [rsp+0xB0], xmm11
000070a59add6e07  vmovaps [rsp+0xC0], xmm12
000070a59add6e10  vmovaps [rsp+0xD0], xmm14
000070a59add6e19  vmovaps [rsp+0xE0], xmm15
000070a59add6e22  sub rsp, 0x40
000070a59add6e26  lea rdi, [rsp]
000070a59add6e2a  lea rsi, [rsp+0x10]
000070a59add6e2f  lea rdx, [rsp+0x20]
000070a59add6e34  lea rcx, [rsp+0x30]
000070a59add6e39  mov r8d, 0x00
000070a59add6e3f  lea r9, [r15+0x3A8]
000070a59add6e46  movaps [rdi], xmm13
000070a59add6e4a  movaps [rsi], xmm1
000070a59add6e4d  movaps [rdx], xmm15
000070a59add6e51  movaps [rcx], xmm14
000070a59add6e55  mov rax, 0x622906D8FA50
000070a59add6e5f  call rax
000070a59add6e61  movaps xmm13, [rsp]
000070a59add6e66  add rsp, 0x40
000070a59add6e6a  vmovaps xmm0, [rsp]
000070a59add6e6f  vmovaps xmm1, [rsp+0x10]
000070a59add6e75  vmovaps xmm2, [rsp+0x20]
000070a59add6e7b  vmovaps xmm3, [rsp+0x30]
000070a59add6e81  vmovaps xmm4, [rsp+0x40]
000070a59add6e87  vmovaps xmm5, [rsp+0x50]
000070a59add6e8d  vmovaps xmm6, [rsp+0x60]
000070a59add6e93  vmovaps xmm7, [rsp+0x70]
000070a59add6e99  vmovaps xmm8, [rsp+0x80]
000070a59add6ea2  vmovaps xmm9, [rsp+0x90]
000070a59add6eab  vmovaps xmm10, [rsp+0xA0]
000070a59add6eb4  vmovaps xmm11, [rsp+0xB0]
000070a59add6ebd  vmovaps xmm12, [rsp+0xC0]
000070a59add6ec6  vmovaps xmm14, [rsp+0xD0]
000070a59add6ecf  vmovaps xmm15, [rsp+0xE0]
000070a59add6ed8  add rsp, 0xF0
000070a59add6edf  pop r11
000070a59add6ee1  pop r10
000070a59add6ee3  pop r9
000070a59add6ee5  pop r8
000070a59add6ee7  pop rsi
000070a59add6ee8  pop rdi
000070a59add6ee9  pop rdx
000070a59add6eea  pop rcx
000070a59add6eeb  pop rax
000070a59add6eec  add rsp, 0x08
000070a59add6ef0  jmp 0x000070A59ADD6305
000070a59add6ef5  sub rsp, 0x08
000070a59add6ef9  push rax
000070a59add6efa  push rcx
000070a59add6efb  push rdx
000070a59add6efc  push rdi
000070a59add6efd  push rsi
000070a59add6efe  push r8
000070a59add6f00  push r9
000070a59add6f02  push r10
000070a59add6f04  push r11
000070a59add6f06  sub rsp, 0xF0
000070a59add6f0d  vmovaps [rsp], xmm0
000070a59add6f12  vmovaps [rsp+0x10], xmm1
000070a59add6f18  vmovaps [rsp+0x20], xmm2
000070a59add6f1e  vmovaps [rsp+0x30], xmm3
000070a59add6f24  vmovaps [rsp+0x40], xmm4
000070a59add6f2a  vmovaps [rsp+0x50], xmm5
000070a59add6f30  vmovaps [rsp+0x60], xmm6
000070a59add6f36  vmovaps [rsp+0x70], xmm7
000070a59add6f3c  vmovaps [rsp+0x80], xmm8
000070a59add6f45  vmovaps [rsp+0x90], xmm9
000070a59add6f4e  vmovaps [rsp+0xA0], xmm10
000070a59add6f57  vmovaps [rsp+0xB0], xmm11
000070a59add6f60  vmovaps [rsp+0xC0], xmm13
000070a59add6f69  vmovaps [rsp+0xD0], xmm14
000070a59add6f72  vmovaps [rsp+0xE0], xmm15
000070a59add6f7b  sub rsp, 0x40
000070a59add6f7f  lea rdi, [rsp]
000070a59add6f83  lea rsi, [rsp+0x10]
000070a59add6f88  lea rdx, [rsp+0x20]
000070a59add6f8d  lea rcx, [rsp+0x30]
000070a59add6f92  mov r8d, 0x00
000070a59add6f98  lea r9, [r15+0x3A8]
000070a59add6f9f  movaps [rdi], xmm12
000070a59add6fa3  movaps [rsi], xmm15
000070a59add6fa7  movaps [rdx], xmm1
000070a59add6faa  movaps [rcx], xmm14
000070a59add6fae  mov rax, 0x622906D8FA50
000070a59add6fb8  call rax
000070a59add6fba  movaps xmm12, [rsp]
000070a59add6fbf  add rsp, 0x40
000070a59add6fc3  vmovaps xmm0, [rsp]
000070a59add6fc8  vmovaps xmm1, [rsp+0x10]
000070a59add6fce  vmovaps xmm2, [rsp+0x20]
000070a59add6fd4  vmovaps xmm3, [rsp+0x30]
000070a59add6fda  vmovaps xmm4, [rsp+0x40]
000070a59add6fe0  vmovaps xmm5, [rsp+0x50]
000070a59add6fe6  vmovaps xmm6, [rsp+0x60]
000070a59add6fec  vmovaps xmm7, [rsp+0x70]
000070a59add6ff2  vmovaps xmm8, [rsp+0x80]
000070a59add6ffb  vmovaps xmm9, [rsp+0x90]
000070a59add7004  vmovaps xmm10, [rsp+0xA0]
000070a59add700d  vmovaps xmm11, [rsp+0xB0]
000070a59add7016  vmovaps xmm13, [rsp+0xC0]
000070a59add701f  vmovaps xmm14, [rsp+0xD0]
000070a59add7028  vmovaps xmm15, [rsp+0xE0]
000070a59add7031  add rsp, 0xF0
000070a59add7038  pop r11
000070a59add703a  pop r10
000070a59add703c  pop r9
000070a59add703e  pop r8
000070a59add7040  pop rsi
000070a59add7041  pop rdi
000070a59add7042  pop rdx
000070a59add7043  pop rcx
000070a59add7044  pop rax
000070a59add7045  add rsp, 0x08
000070a59add7049  jmp 0x000070A59ADD6333
000070a59add704e  call 0x000070A59ACD64F0
000070a59add7053  jmp 0x000070A59ADD641F
000070a59add7058  sub rsp, 0x08
000070a59add705c  push rax
000070a59add705d  push rcx
000070a59add705e  push rdx
000070a59add705f  push rdi
000070a59add7060  push rsi
000070a59add7061  push r8
000070a59add7063  push r9
000070a59add7065  push r10
000070a59add7067  push r11
000070a59add7069  sub rsp, 0xF0
000070a59add7070  vmovaps [rsp], xmm0
000070a59add7075  vmovaps [rsp+0x10], xmm1
000070a59add707b  vmovaps [rsp+0x20], xmm2
000070a59add7081  vmovaps [rsp+0x30], xmm3
000070a59add7087  vmovaps [rsp+0x40], xmm4
000070a59add708d  vmovaps [rsp+0x50], xmm5
000070a59add7093  vmovaps [rsp+0x60], xmm6
000070a59add7099  vmovaps [rsp+0x70], xmm7
000070a59add709f  vmovaps [rsp+0x80], xmm8
000070a59add70a8  vmovaps [rsp+0x90], xmm9
000070a59add70b1  vmovaps [rsp+0xA0], xmm10
000070a59add70ba  vmovaps [rsp+0xB0], xmm11
000070a59add70c3  vmovaps [rsp+0xC0], xmm12
000070a59add70cc  vmovaps [rsp+0xD0], xmm14
000070a59add70d5  vmovaps [rsp+0xE0], xmm15
000070a59add70de  sub rsp, 0x40
000070a59add70e2  lea rdi, [rsp]
000070a59add70e6  lea rsi, [rsp+0x10]
000070a59add70eb  lea rdx, [rsp+0x20]
000070a59add70f0  lea rcx, [rsp+0x30]
000070a59add70f5  mov r8d, 0x00
000070a59add70fb  lea r9, [r15+0x3A8]
000070a59add7102  movaps [rdi], xmm13
000070a59add7106  movaps [rsi], xmm1
000070a59add7109  movaps [rdx], xmm15
000070a59add710d  movaps [rcx], xmm14
000070a59add7111  mov rax, 0x622906D8FA50
000070a59add711b  call rax
000070a59add711d  movaps xmm13, [rsp]
000070a59add7122  add rsp, 0x40
000070a59add7126  vmovaps xmm0, [rsp]
000070a59add712b  vmovaps xmm1, [rsp+0x10]
000070a59add7131  vmovaps xmm2, [rsp+0x20]
000070a59add7137  vmovaps xmm3, [rsp+0x30]
000070a59add713d  vmovaps xmm4, [rsp+0x40]
000070a59add7143  vmovaps xmm5, [rsp+0x50]
000070a59add7149  vmovaps xmm6, [rsp+0x60]
000070a59add714f  vmovaps xmm7, [rsp+0x70]
000070a59add7155  vmovaps xmm8, [rsp+0x80]
000070a59add715e  vmovaps xmm9, [rsp+0x90]
000070a59add7167  vmovaps xmm10, [rsp+0xA0]
000070a59add7170  vmovaps xmm11, [rsp+0xB0]
000070a59add7179  vmovaps xmm12, [rsp+0xC0]
000070a59add7182  vmovaps xmm14, [rsp+0xD0]
000070a59add718b  vmovaps xmm15, [rsp+0xE0]
000070a59add7194  add rsp, 0xF0
000070a59add719b  pop r11
000070a59add719d  pop r10
000070a59add719f  pop r9
000070a59add71a1  pop r8
000070a59add71a3  pop rsi
000070a59add71a4  pop rdi
000070a59add71a5  pop rdx
000070a59add71a6  pop rcx
000070a59add71a7  pop rax
000070a59add71a8  add rsp, 0x08
000070a59add71ac  jmp 0x000070A59ADD648E
000070a59add71b1  call 0x000070A59ACD64F0
000070a59add71b6  jmp 0x000070A59ADD64A3
000070a59add71bb  sub rsp, 0x08
000070a59add71bf  push rax
000070a59add71c0  push rcx
000070a59add71c1  push rdx
000070a59add71c2  push rdi
000070a59add71c3  push rsi
000070a59add71c4  push r8
000070a59add71c6  push r9
000070a59add71c8  push r10
000070a59add71ca  push r11
000070a59add71cc  sub rsp, 0xF0
000070a59add71d3  vmovaps [rsp], xmm0
000070a59add71d8  vmovaps [rsp+0x10], xmm1
000070a59add71de  vmovaps [rsp+0x20], xmm2
000070a59add71e4  vmovaps [rsp+0x30], xmm3
000070a59add71ea  vmovaps [rsp+0x40], xmm4
000070a59add71f0  vmovaps [rsp+0x50], xmm5
000070a59add71f6  vmovaps [rsp+0x60], xmm6
000070a59add71fc  vmovaps [rsp+0x70], xmm7
000070a59add7202  vmovaps [rsp+0x80], xmm8
000070a59add720b  vmovaps [rsp+0x90], xmm9
000070a59add7214  vmovaps [rsp+0xA0], xmm10
000070a59add721d  vmovaps [rsp+0xB0], xmm11
000070a59add7226  vmovaps [rsp+0xC0], xmm13
000070a59add722f  vmovaps [rsp+0xD0], xmm14
000070a59add7238  vmovaps [rsp+0xE0], xmm15
000070a59add7241  sub rsp, 0x40
000070a59add7245  lea rdi, [rsp]
000070a59add7249  lea rsi, [rsp+0x10]
000070a59add724e  lea rdx, [rsp+0x20]
000070a59add7253  lea rcx, [rsp+0x30]
000070a59add7258  mov r8d, 0x00
000070a59add725e  lea r9, [r15+0x3A8]
000070a59add7265  movaps [rdi], xmm12
000070a59add7269  movaps [rsi], xmm15
000070a59add726d  movaps [rdx], xmm1
000070a59add7270  movaps [rcx], xmm14
000070a59add7274  mov rax, 0x622906D8FA50
000070a59add727e  call rax
000070a59add7280  movaps xmm12, [rsp]
000070a59add7285  add rsp, 0x40
000070a59add7289  vmovaps xmm0, [rsp]
000070a59add728e  vmovaps xmm1, [rsp+0x10]
000070a59add7294  vmovaps xmm2, [rsp+0x20]
000070a59add729a  vmovaps xmm3, [rsp+0x30]
000070a59add72a0  vmovaps xmm4, [rsp+0x40]
000070a59add72a6  vmovaps xmm5, [rsp+0x50]
000070a59add72ac  vmovaps xmm6, [rsp+0x60]
000070a59add72b2  vmovaps xmm7, [rsp+0x70]
000070a59add72b8  vmovaps xmm8, [rsp+0x80]
000070a59add72c1  vmovaps xmm9, [rsp+0x90]
000070a59add72ca  vmovaps xmm10, [rsp+0xA0]
000070a59add72d3  vmovaps xmm11, [rsp+0xB0]
000070a59add72dc  vmovaps xmm13, [rsp+0xC0]
000070a59add72e5  vmovaps xmm14, [rsp+0xD0]
000070a59add72ee  vmovaps xmm15, [rsp+0xE0]
000070a59add72f7  add rsp, 0xF0
000070a59add72fe  pop r11
000070a59add7300  pop r10
000070a59add7302  pop r9
000070a59add7304  pop r8
000070a59add7306  pop rsi
000070a59add7307  pop rdi
000070a59add7308  pop rdx
000070a59add7309  pop rcx
000070a59add730a  pop rax
000070a59add730b  add rsp, 0x08
000070a59add730f  jmp 0x000070A59ADD64CF
000070a59add7314  sub rsp, 0x08
000070a59add7318  push rax
000070a59add7319  push rcx
000070a59add731a  push rdx
000070a59add731b  push rdi
000070a59add731c  push rsi
000070a59add731d  push r8
000070a59add731f  push r9
000070a59add7321  push r10
000070a59add7323  push r11
000070a59add7325  sub rsp, 0xF0
000070a59add732c  vmovaps [rsp], xmm0
000070a59add7331  vmovaps [rsp+0x10], xmm1
000070a59add7337  vmovaps [rsp+0x20], xmm2
000070a59add733d  vmovaps [rsp+0x30], xmm3
000070a59add7343  vmovaps [rsp+0x40], xmm4
000070a59add7349  vmovaps [rsp+0x50], xmm5
000070a59add734f  vmovaps [rsp+0x60], xmm6
000070a59add7355  vmovaps [rsp+0x70], xmm7
000070a59add735b  vmovaps [rsp+0x80], xmm8
000070a59add7364  vmovaps [rsp+0x90], xmm9
000070a59add736d  vmovaps [rsp+0xA0], xmm10
000070a59add7376  vmovaps [rsp+0xB0], xmm11
000070a59add737f  vmovaps [rsp+0xC0], xmm12
000070a59add7388  vmovaps [rsp+0xD0], xmm14
000070a59add7391  vmovaps [rsp+0xE0], xmm15
000070a59add739a  sub rsp, 0x40
000070a59add739e  lea rdi, [rsp]
000070a59add73a2  lea rsi, [rsp+0x10]
000070a59add73a7  lea rdx, [rsp+0x20]
000070a59add73ac  lea rcx, [rsp+0x30]
000070a59add73b1  mov r8d, 0x00
000070a59add73b7  lea r9, [r15+0x3A8]
000070a59add73be  movaps [rdi], xmm13
000070a59add73c2  movaps [rsi], xmm1
000070a59add73c5  movaps [rdx], xmm15
000070a59add73c9  movaps [rcx], xmm14
000070a59add73cd  mov rax, 0x622906D8FA50
000070a59add73d7  call rax
000070a59add73d9  movaps xmm13, [rsp]
000070a59add73de  add rsp, 0x40
000070a59add73e2  vmovaps xmm0, [rsp]
000070a59add73e7  vmovaps xmm1, [rsp+0x10]
000070a59add73ed  vmovaps xmm2, [rsp+0x20]
000070a59add73f3  vmovaps xmm3, [rsp+0x30]
000070a59add73f9  vmovaps xmm4, [rsp+0x40]
000070a59add73ff  vmovaps xmm5, [rsp+0x50]
000070a59add7405  vmovaps xmm6, [rsp+0x60]
000070a59add740b  vmovaps xmm7, [rsp+0x70]
000070a59add7411  vmovaps xmm8, [rsp+0x80]
000070a59add741a  vmovaps xmm9, [rsp+0x90]
000070a59add7423  vmovaps xmm10, [rsp+0xA0]
000070a59add742c  vmovaps xmm11, [rsp+0xB0]
000070a59add7435  vmovaps xmm12, [rsp+0xC0]
000070a59add743e  vmovaps xmm14, [rsp+0xD0]
000070a59add7447  vmovaps xmm15, [rsp+0xE0]
000070a59add7450  add rsp, 0xF0
000070a59add7457  pop r11
000070a59add7459  pop r10
000070a59add745b  pop r9
000070a59add745d  pop r8
000070a59add745f  pop rsi
000070a59add7460  pop rdi
000070a59add7461  pop rdx
000070a59add7462  pop rcx
000070a59add7463  pop rax
000070a59add7464  add rsp, 0x08
000070a59add7468  jmp 0x000070A59ADD665F
000070a59add746d  sub rsp, 0x08
000070a59add7471  push rax
000070a59add7472  push rcx
000070a59add7473  push rdx
000070a59add7474  push rdi
000070a59add7475  push rsi
000070a59add7476  push r8
000070a59add7478  push r9
000070a59add747a  push r10
000070a59add747c  push r11
000070a59add747e  sub rsp, 0xF0
000070a59add7485  vmovaps [rsp], xmm0
000070a59add748a  vmovaps [rsp+0x10], xmm1
000070a59add7490  vmovaps [rsp+0x20], xmm2
000070a59add7496  vmovaps [rsp+0x30], xmm3
000070a59add749c  vmovaps [rsp+0x40], xmm4
000070a59add74a2  vmovaps [rsp+0x50], xmm5
000070a59add74a8  vmovaps [rsp+0x60], xmm6
000070a59add74ae  vmovaps [rsp+0x70], xmm7
000070a59add74b4  vmovaps [rsp+0x80], xmm8
000070a59add74bd  vmovaps [rsp+0x90], xmm9
000070a59add74c6  vmovaps [rsp+0xA0], xmm10
000070a59add74cf  vmovaps [rsp+0xB0], xmm11
000070a59add74d8  vmovaps [rsp+0xC0], xmm12
000070a59add74e1  vmovaps [rsp+0xD0], xmm13
000070a59add74ea  vmovaps [rsp+0xE0], xmm15
000070a59add74f3  sub rsp, 0x40
000070a59add74f7  lea rdi, [rsp]
000070a59add74fb  lea rsi, [rsp+0x10]
000070a59add7500  lea rdx, [rsp+0x20]
000070a59add7505  lea rcx, [rsp+0x30]
000070a59add750a  mov r8d, 0x00
000070a59add7510  lea r9, [r15+0x3A8]
000070a59add7517  movaps [rdi], xmm14
000070a59add751b  movaps [rsi], xmm15
000070a59add751f  movaps [rdx], xmm2
000070a59add7522  movaps [rcx], xmm1
000070a59add7525  mov rax, 0x622906D8FA50
000070a59add752f  call rax
000070a59add7531  movaps xmm14, [rsp]
000070a59add7536  add rsp, 0x40
000070a59add753a  vmovaps xmm0, [rsp]
000070a59add753f  vmovaps xmm1, [rsp+0x10]
000070a59add7545  vmovaps xmm2, [rsp+0x20]
000070a59add754b  vmovaps xmm3, [rsp+0x30]
000070a59add7551  vmovaps xmm4, [rsp+0x40]
000070a59add7557  vmovaps xmm5, [rsp+0x50]
000070a59add755d  vmovaps xmm6, [rsp+0x60]
000070a59add7563  vmovaps xmm7, [rsp+0x70]
000070a59add7569  vmovaps xmm8, [rsp+0x80]
000070a59add7572  vmovaps xmm9, [rsp+0x90]
000070a59add757b  vmovaps xmm10, [rsp+0xA0]
000070a59add7584  vmovaps xmm11, [rsp+0xB0]
000070a59add758d  vmovaps xmm12, [rsp+0xC0]
000070a59add7596  vmovaps xmm13, [rsp+0xD0]
000070a59add759f  vmovaps xmm15, [rsp+0xE0]
000070a59add75a8  add rsp, 0xF0
000070a59add75af  pop r11
000070a59add75b1  pop r10
000070a59add75b3  pop r9
000070a59add75b5  pop r8
000070a59add75b7  pop rsi
000070a59add75b8  pop rdi
000070a59add75b9  pop rdx
000070a59add75ba  pop rcx
000070a59add75bb  pop rax
000070a59add75bc  add rsp, 0x08
000070a59add75c0  jmp 0x000070A59ADD6691
000070a59add75c5  sub rsp, 0x08
000070a59add75c9  push rax
000070a59add75ca  push rcx
000070a59add75cb  push rdx
000070a59add75cc  push rdi
000070a59add75cd  push rsi
000070a59add75ce  push r8
000070a59add75d0  push r9
000070a59add75d2  push r10
000070a59add75d4  push r11
000070a59add75d6  sub rsp, 0xF0
000070a59add75dd  vmovaps [rsp], xmm0
000070a59add75e2  vmovaps [rsp+0x10], xmm1
000070a59add75e8  vmovaps [rsp+0x20], xmm3
000070a59add75ee  vmovaps [rsp+0x30], xmm4
000070a59add75f4  vmovaps [rsp+0x40], xmm5
000070a59add75fa  vmovaps [rsp+0x50], xmm6
000070a59add7600  vmovaps [rsp+0x60], xmm7
000070a59add7606  vmovaps [rsp+0x70], xmm8
000070a59add760c  vmovaps [rsp+0x80], xmm9
000070a59add7615  vmovaps [rsp+0x90], xmm10
000070a59add761e  vmovaps [rsp+0xA0], xmm11
000070a59add7627  vmovaps [rsp+0xB0], xmm12
000070a59add7630  vmovaps [rsp+0xC0], xmm13
000070a59add7639  vmovaps [rsp+0xD0], xmm14
000070a59add7642  vmovaps [rsp+0xE0], xmm15
000070a59add764b  sub rsp, 0x40
000070a59add764f  lea rdi, [rsp]
000070a59add7653  lea rsi, [rsp+0x10]
000070a59add7658  lea rdx, [rsp+0x20]
000070a59add765d  lea rcx, [rsp+0x30]
000070a59add7662  mov r8d, 0x00
000070a59add7668  lea r9, [r15+0x3A8]
000070a59add766f  movaps [rdi], xmm2
000070a59add7672  movaps [rsi], xmm15
000070a59add7676  movaps [rdx], xmm12
000070a59add767a  movaps [rcx], xmm1
000070a59add767d  mov rax, 0x622906D8FA50
000070a59add7687  call rax
000070a59add7689  movaps xmm2, [rsp]
000070a59add768d  add rsp, 0x40
000070a59add7691  vmovaps xmm0, [rsp]
000070a59add7696  vmovaps xmm1, [rsp+0x10]
000070a59add769c  vmovaps xmm3, [rsp+0x20]
000070a59add76a2  vmovaps xmm4, [rsp+0x30]
000070a59add76a8  vmovaps xmm5, [rsp+0x40]
000070a59add76ae  vmovaps xmm6, [rsp+0x50]
000070a59add76b4  vmovaps xmm7, [rsp+0x60]
000070a59add76ba  vmovaps xmm8, [rsp+0x70]
000070a59add76c0  vmovaps xmm9, [rsp+0x80]
000070a59add76c9  vmovaps xmm10, [rsp+0x90]
000070a59add76d2  vmovaps xmm11, [rsp+0xA0]
000070a59add76db  vmovaps xmm12, [rsp+0xB0]
000070a59add76e4  vmovaps xmm13, [rsp+0xC0]
000070a59add76ed  vmovaps xmm14, [rsp+0xD0]
000070a59add76f6  vmovaps xmm15, [rsp+0xE0]
000070a59add76ff  add rsp, 0xF0
000070a59add7706  pop r11
000070a59add7708  pop r10
000070a59add770a  pop r9
000070a59add770c  pop r8
000070a59add770e  pop rsi
000070a59add770f  pop rdi
000070a59add7710  pop rdx
000070a59add7711  pop rcx
000070a59add7712  pop rax
000070a59add7713  add rsp, 0x08
000070a59add7717  jmp 0x000070A59ADD66CE
000070a59add771c  sub rsp, 0x08
000070a59add7720  push rax
000070a59add7721  push rcx
000070a59add7722  push rdx
000070a59add7723  push rdi
000070a59add7724  push rsi
000070a59add7725  push r8
000070a59add7727  push r9
000070a59add7729  push r10
000070a59add772b  push r11
000070a59add772d  sub rsp, 0xF0
000070a59add7734  vmovaps [rsp], xmm0
000070a59add7739  vmovaps [rsp+0x10], xmm1
000070a59add773f  vmovaps [rsp+0x20], xmm2
000070a59add7745  vmovaps [rsp+0x30], xmm3
000070a59add774b  vmovaps [rsp+0x40], xmm4
000070a59add7751  vmovaps [rsp+0x50], xmm5
000070a59add7757  vmovaps [rsp+0x60], xmm6
000070a59add775d  vmovaps [rsp+0x70], xmm7
000070a59add7763  vmovaps [rsp+0x80], xmm8
000070a59add776c  vmovaps [rsp+0x90], xmm9
000070a59add7775  vmovaps [rsp+0xA0], xmm10
000070a59add777e  vmovaps [rsp+0xB0], xmm11
000070a59add7787  vmovaps [rsp+0xC0], xmm13
000070a59add7790  vmovaps [rsp+0xD0], xmm14
000070a59add7799  vmovaps [rsp+0xE0], xmm15
000070a59add77a2  sub rsp, 0x40
000070a59add77a6  lea rdi, [rsp]
000070a59add77aa  lea rsi, [rsp+0x10]
000070a59add77af  lea rdx, [rsp+0x20]
000070a59add77b4  lea rcx, [rsp+0x30]
000070a59add77b9  mov r8d, 0x00
000070a59add77bf  lea r9, [r15+0x3A8]
000070a59add77c6  movaps [rdi], xmm12
000070a59add77ca  movaps [rsi], xmm14
000070a59add77ce  movaps [rdx], xmm3
000070a59add77d1  movaps [rcx], xmm15
000070a59add77d5  mov rax, 0x622906D8FA50
000070a59add77df  call rax
000070a59add77e1  movaps xmm12, [rsp]
000070a59add77e6  add rsp, 0x40
000070a59add77ea  vmovaps xmm0, [rsp]
000070a59add77ef  vmovaps xmm1, [rsp+0x10]
000070a59add77f5  vmovaps xmm2, [rsp+0x20]
000070a59add77fb  vmovaps xmm3, [rsp+0x30]
000070a59add7801  vmovaps xmm4, [rsp+0x40]
000070a59add7807  vmovaps xmm5, [rsp+0x50]
000070a59add780d  vmovaps xmm6, [rsp+0x60]
000070a59add7813  vmovaps xmm7, [rsp+0x70]
000070a59add7819  vmovaps xmm8, [rsp+0x80]
000070a59add7822  vmovaps xmm9, [rsp+0x90]
000070a59add782b  vmovaps xmm10, [rsp+0xA0]
000070a59add7834  vmovaps xmm11, [rsp+0xB0]
000070a59add783d  vmovaps xmm13, [rsp+0xC0]
000070a59add7846  vmovaps xmm14, [rsp+0xD0]
000070a59add784f  vmovaps xmm15, [rsp+0xE0]
000070a59add7858  add rsp, 0xF0
000070a59add785f  pop r11
000070a59add7861  pop r10
000070a59add7863  pop r9
000070a59add7865  pop r8
000070a59add7867  pop rsi
000070a59add7868  pop rdi
000070a59add7869  pop rdx
000070a59add786a  pop rcx
000070a59add786b  pop rax
000070a59add786c  add rsp, 0x08
000070a59add7870  jmp 0x000070A59ADD6728
000070a59add7875  sub rsp, 0x08
000070a59add7879  push rax
000070a59add787a  push rcx
000070a59add787b  push rdx
000070a59add787c  push rdi
000070a59add787d  push rsi
000070a59add787e  push r8
000070a59add7880  push r9
000070a59add7882  push r10
000070a59add7884  push r11
000070a59add7886  sub rsp, 0xF0
000070a59add788d  vmovaps [rsp], xmm0
000070a59add7892  vmovaps [rsp+0x10], xmm1
000070a59add7898  vmovaps [rsp+0x20], xmm2
000070a59add789e  vmovaps [rsp+0x30], xmm3
000070a59add78a4  vmovaps [rsp+0x40], xmm4
000070a59add78aa  vmovaps [rsp+0x50], xmm5
000070a59add78b0  vmovaps [rsp+0x60], xmm6
000070a59add78b6  vmovaps [rsp+0x70], xmm7
000070a59add78bc  vmovaps [rsp+0x80], xmm8
000070a59add78c5  vmovaps [rsp+0x90], xmm10
000070a59add78ce  vmovaps [rsp+0xA0], xmm11
000070a59add78d7  vmovaps [rsp+0xB0], xmm12
000070a59add78e0  vmovaps [rsp+0xC0], xmm13
000070a59add78e9  vmovaps [rsp+0xD0], xmm14
000070a59add78f2  vmovaps [rsp+0xE0], xmm15
000070a59add78fb  sub rsp, 0x40
000070a59add78ff  lea rdi, [rsp]
000070a59add7903  lea rsi, [rsp+0x10]
000070a59add7908  lea rdx, [rsp+0x20]
000070a59add790d  lea rcx, [rsp+0x30]
000070a59add7912  mov r8d, 0x00
000070a59add7918  lea r9, [r15+0x3A8]
000070a59add791f  movaps [rdi], xmm9
000070a59add7923  movaps [rsi], xmm13
000070a59add7927  movaps [rdx], xmm14
000070a59add792b  movaps [rcx], xmm6
000070a59add792e  mov rax, 0x622906D8FA50
000070a59add7938  call rax
000070a59add793a  movaps xmm9, [rsp]
000070a59add793f  add rsp, 0x40
000070a59add7943  vmovaps xmm0, [rsp]
000070a59add7948  vmovaps xmm1, [rsp+0x10]
000070a59add794e  vmovaps xmm2, [rsp+0x20]
000070a59add7954  vmovaps xmm3, [rsp+0x30]
000070a59add795a  vmovaps xmm4, [rsp+0x40]
000070a59add7960  vmovaps xmm5, [rsp+0x50]
000070a59add7966  vmovaps xmm6, [rsp+0x60]
000070a59add796c  vmovaps xmm7, [rsp+0x70]
000070a59add7972  vmovaps xmm8, [rsp+0x80]
000070a59add797b  vmovaps xmm10, [rsp+0x90]
000070a59add7984  vmovaps xmm11, [rsp+0xA0]
000070a59add798d  vmovaps xmm12, [rsp+0xB0]
000070a59add7996  vmovaps xmm13, [rsp+0xC0]
000070a59add799f  vmovaps xmm14, [rsp+0xD0]
000070a59add79a8  vmovaps xmm15, [rsp+0xE0]
000070a59add79b1  add rsp, 0xF0
000070a59add79b8  pop r11
000070a59add79ba  pop r10
000070a59add79bc  pop r9
000070a59add79be  pop r8
000070a59add79c0  pop rsi
000070a59add79c1  pop rdi
000070a59add79c2  pop rdx
000070a59add79c3  pop rcx
000070a59add79c4  pop rax
000070a59add79c5  add rsp, 0x08
000070a59add79c9  jmp 0x000070A59ADD67D2
000070a59add79ce  sub rsp, 0x08
000070a59add79d2  push rax
000070a59add79d3  push rcx
000070a59add79d4  push rdx
000070a59add79d5  push rdi
000070a59add79d6  push rsi
000070a59add79d7  push r8
000070a59add79d9  push r9
000070a59add79db  push r10
000070a59add79dd  push r11
000070a59add79df  sub rsp, 0xF0
000070a59add79e6  vmovaps [rsp], xmm0
000070a59add79eb  vmovaps [rsp+0x10], xmm1
000070a59add79f1  vmovaps [rsp+0x20], xmm2
000070a59add79f7  vmovaps [rsp+0x30], xmm4
000070a59add79fd  vmovaps [rsp+0x40], xmm5
000070a59add7a03  vmovaps [rsp+0x50], xmm6
000070a59add7a09  vmovaps [rsp+0x60], xmm7
000070a59add7a0f  vmovaps [rsp+0x70], xmm8
000070a59add7a15  vmovaps [rsp+0x80], xmm9
000070a59add7a1e  vmovaps [rsp+0x90], xmm10
000070a59add7a27  vmovaps [rsp+0xA0], xmm11
000070a59add7a30  vmovaps [rsp+0xB0], xmm12
000070a59add7a39  vmovaps [rsp+0xC0], xmm13
000070a59add7a42  vmovaps [rsp+0xD0], xmm14
000070a59add7a4b  vmovaps [rsp+0xE0], xmm15
000070a59add7a54  sub rsp, 0x40
000070a59add7a58  lea rdi, [rsp]
000070a59add7a5c  lea rsi, [rsp+0x10]
000070a59add7a61  lea rdx, [rsp+0x20]
000070a59add7a66  lea rcx, [rsp+0x30]
000070a59add7a6b  mov r8d, 0x00
000070a59add7a71  lea r9, [r15+0x3A8]
000070a59add7a78  movaps [rdi], xmm3
000070a59add7a7b  movaps [rsi], xmm13
000070a59add7a7f  movaps [rdx], xmm6
000070a59add7a82  movaps [rcx], xmm14
000070a59add7a86  mov rax, 0x622906D8FA50
000070a59add7a90  call rax
000070a59add7a92  movaps xmm3, [rsp]
000070a59add7a96  add rsp, 0x40
000070a59add7a9a  vmovaps xmm0, [rsp]
000070a59add7a9f  vmovaps xmm1, [rsp+0x10]
000070a59add7aa5  vmovaps xmm2, [rsp+0x20]
000070a59add7aab  vmovaps xmm4, [rsp+0x30]
000070a59add7ab1  vmovaps xmm5, [rsp+0x40]
000070a59add7ab7  vmovaps xmm6, [rsp+0x50]
000070a59add7abd  vmovaps xmm7, [rsp+0x60]
000070a59add7ac3  vmovaps xmm8, [rsp+0x70]
000070a59add7ac9  vmovaps xmm9, [rsp+0x80]
000070a59add7ad2  vmovaps xmm10, [rsp+0x90]
000070a59add7adb  vmovaps xmm11, [rsp+0xA0]
000070a59add7ae4  vmovaps xmm12, [rsp+0xB0]
000070a59add7aed  vmovaps xmm13, [rsp+0xC0]
000070a59add7af6  vmovaps xmm14, [rsp+0xD0]
000070a59add7aff  vmovaps xmm15, [rsp+0xE0]
000070a59add7b08  add rsp, 0xF0
000070a59add7b0f  pop r11
000070a59add7b11  pop r10
000070a59add7b13  pop r9
000070a59add7b15  pop r8
000070a59add7b17  pop rsi
000070a59add7b18  pop rdi
000070a59add7b19  pop rdx
000070a59add7b1a  pop rcx
000070a59add7b1b  pop rax
000070a59add7b1c  add rsp, 0x08
000070a59add7b20  jmp 0x000070A59ADD680F
000070a59add7b25  sub rsp, 0x08
000070a59add7b29  push rax
000070a59add7b2a  push rcx
000070a59add7b2b  push rdx
000070a59add7b2c  push rdi
000070a59add7b2d  push rsi
000070a59add7b2e  push r8
000070a59add7b30  push r9
000070a59add7b32  push r10
000070a59add7b34  push r11
000070a59add7b36  sub rsp, 0xF0
000070a59add7b3d  vmovaps [rsp], xmm0
000070a59add7b42  vmovaps [rsp+0x10], xmm1
000070a59add7b48  vmovaps [rsp+0x20], xmm2
000070a59add7b4e  vmovaps [rsp+0x30], xmm3
000070a59add7b54  vmovaps [rsp+0x40], xmm4
000070a59add7b5a  vmovaps [rsp+0x50], xmm5
000070a59add7b60  vmovaps [rsp+0x60], xmm7
000070a59add7b66  vmovaps [rsp+0x70], xmm8
000070a59add7b6c  vmovaps [rsp+0x80], xmm9
000070a59add7b75  vmovaps [rsp+0x90], xmm10
000070a59add7b7e  vmovaps [rsp+0xA0], xmm11
000070a59add7b87  vmovaps [rsp+0xB0], xmm12
000070a59add7b90  vmovaps [rsp+0xC0], xmm13
000070a59add7b99  vmovaps [rsp+0xD0], xmm14
000070a59add7ba2  vmovaps [rsp+0xE0], xmm15
000070a59add7bab  sub rsp, 0x40
000070a59add7baf  lea rdi, [rsp]
000070a59add7bb3  lea rsi, [rsp+0x10]
000070a59add7bb8  lea rdx, [rsp+0x20]
000070a59add7bbd  lea rcx, [rsp+0x30]
000070a59add7bc2  mov r8d, 0x00
000070a59add7bc8  lea r9, [r15+0x3A8]
000070a59add7bcf  movaps [rdi], xmm6
000070a59add7bd2  movaps [rsi], xmm2
000070a59add7bd5  movaps [rdx], xmm14
000070a59add7bd9  movaps [rcx], xmm1
000070a59add7bdc  mov rax, 0x622906D8FA50
000070a59add7be6  call rax
000070a59add7be8  movaps xmm6, [rsp]
000070a59add7bec  add rsp, 0x40
000070a59add7bf0  vmovaps xmm0, [rsp]
000070a59add7bf5  vmovaps xmm1, [rsp+0x10]
000070a59add7bfb  vmovaps xmm2, [rsp+0x20]
000070a59add7c01  vmovaps xmm3, [rsp+0x30]
000070a59add7c07  vmovaps xmm4, [rsp+0x40]
000070a59add7c0d  vmovaps xmm5, [rsp+0x50]
000070a59add7c13  vmovaps xmm7, [rsp+0x60]
000070a59add7c19  vmovaps xmm8, [rsp+0x70]
000070a59add7c1f  vmovaps xmm9, [rsp+0x80]
000070a59add7c28  vmovaps xmm10, [rsp+0x90]
000070a59add7c31  vmovaps xmm11, [rsp+0xA0]
000070a59add7c3a  vmovaps xmm12, [rsp+0xB0]
000070a59add7c43  vmovaps xmm13, [rsp+0xC0]
000070a59add7c4c  vmovaps xmm14, [rsp+0xD0]
000070a59add7c55  vmovaps xmm15, [rsp+0xE0]
000070a59add7c5e  add rsp, 0xF0
000070a59add7c65  pop r11
000070a59add7c67  pop r10
000070a59add7c69  pop r9
000070a59add7c6b  pop r8
000070a59add7c6d  pop rsi
000070a59add7c6e  pop rdi
000070a59add7c6f  pop rdx
000070a59add7c70  pop rcx
000070a59add7c71  pop rax
000070a59add7c72  add rsp, 0x08
000070a59add7c76  jmp 0x000070A59ADD683C
000070a59add7c7b  sub rsp, 0x08
000070a59add7c7f  push rax
000070a59add7c80  push rcx
000070a59add7c81  push rdx
000070a59add7c82  push rdi
000070a59add7c83  push rsi
000070a59add7c84  push r8
000070a59add7c86  push r9
000070a59add7c88  push r10
000070a59add7c8a  push r11
000070a59add7c8c  sub rsp, 0xF0
000070a59add7c93  vmovaps [rsp], xmm0
000070a59add7c98  vmovaps [rsp+0x10], xmm1
000070a59add7c9e  vmovaps [rsp+0x20], xmm2
000070a59add7ca4  vmovaps [rsp+0x30], xmm3
000070a59add7caa  vmovaps [rsp+0x40], xmm4
000070a59add7cb0  vmovaps [rsp+0x50], xmm5
000070a59add7cb6  vmovaps [rsp+0x60], xmm6
000070a59add7cbc  vmovaps [rsp+0x70], xmm7
000070a59add7cc2  vmovaps [rsp+0x80], xmm8
000070a59add7ccb  vmovaps [rsp+0x90], xmm9
000070a59add7cd4  vmovaps [rsp+0xA0], xmm10
000070a59add7cdd  vmovaps [rsp+0xB0], xmm11
000070a59add7ce6  vmovaps [rsp+0xC0], xmm12
000070a59add7cef  vmovaps [rsp+0xD0], xmm14
000070a59add7cf8  vmovaps [rsp+0xE0], xmm15
000070a59add7d01  sub rsp, 0x40
000070a59add7d05  lea rdi, [rsp]
000070a59add7d09  lea rsi, [rsp+0x10]
000070a59add7d0e  lea rdx, [rsp+0x20]
000070a59add7d13  lea rcx, [rsp+0x30]
000070a59add7d18  mov r8d, 0x00
000070a59add7d1e  lea r9, [r15+0x3A8]
000070a59add7d25  movaps [rdi], xmm13
000070a59add7d29  movaps [rsi], xmm12
000070a59add7d2d  movaps [rdx], xmm14
000070a59add7d31  movaps [rcx], xmm1
000070a59add7d34  mov rax, 0x622906D8FA50
000070a59add7d3e  call rax
000070a59add7d40  movaps xmm13, [rsp]
000070a59add7d45  add rsp, 0x40
000070a59add7d49  vmovaps xmm0, [rsp]
000070a59add7d4e  vmovaps xmm1, [rsp+0x10]
000070a59add7d54  vmovaps xmm2, [rsp+0x20]
000070a59add7d5a  vmovaps xmm3, [rsp+0x30]
000070a59add7d60  vmovaps xmm4, [rsp+0x40]
000070a59add7d66  vmovaps xmm5, [rsp+0x50]
000070a59add7d6c  vmovaps xmm6, [rsp+0x60]
000070a59add7d72  vmovaps xmm7, [rsp+0x70]
000070a59add7d78  vmovaps xmm8, [rsp+0x80]
000070a59add7d81  vmovaps xmm9, [rsp+0x90]
000070a59add7d8a  vmovaps xmm10, [rsp+0xA0]
000070a59add7d93  vmovaps xmm11, [rsp+0xB0]
000070a59add7d9c  vmovaps xmm12, [rsp+0xC0]
000070a59add7da5  vmovaps xmm14, [rsp+0xD0]
000070a59add7dae  vmovaps xmm15, [rsp+0xE0]
000070a59add7db7  add rsp, 0xF0
000070a59add7dbe  pop r11
000070a59add7dc0  pop r10
000070a59add7dc2  pop r9
000070a59add7dc4  pop r8
000070a59add7dc6  pop rsi
000070a59add7dc7  pop rdi
000070a59add7dc8  pop rdx
000070a59add7dc9  pop rcx
000070a59add7dca  pop rax
000070a59add7dcb  add rsp, 0x08
000070a59add7dcf  jmp 0x000070A59ADD686E
000070a59add7dd4  sub rsp, 0x08
000070a59add7dd8  push rax
000070a59add7dd9  push rcx
000070a59add7dda  push rdx
000070a59add7ddb  push rdi
000070a59add7ddc  push rsi
000070a59add7ddd  push r8
000070a59add7ddf  push r9
000070a59add7de1  push r10
000070a59add7de3  push r11
000070a59add7de5  sub rsp, 0xF0
000070a59add7dec  vmovaps [rsp], xmm0
000070a59add7df1  vmovaps [rsp+0x10], xmm1
000070a59add7df7  vmovaps [rsp+0x20], xmm2
000070a59add7dfd  vmovaps [rsp+0x30], xmm3
000070a59add7e03  vmovaps [rsp+0x40], xmm4
000070a59add7e09  vmovaps [rsp+0x50], xmm5
000070a59add7e0f  vmovaps [rsp+0x60], xmm6
000070a59add7e15  vmovaps [rsp+0x70], xmm7
000070a59add7e1b  vmovaps [rsp+0x80], xmm8
000070a59add7e24  vmovaps [rsp+0x90], xmm9
000070a59add7e2d  vmovaps [rsp+0xA0], xmm10
000070a59add7e36  vmovaps [rsp+0xB0], xmm11
000070a59add7e3f  vmovaps [rsp+0xC0], xmm13
000070a59add7e48  vmovaps [rsp+0xD0], xmm14
000070a59add7e51  vmovaps [rsp+0xE0], xmm15
000070a59add7e5a  sub rsp, 0x40
000070a59add7e5e  lea rdi, [rsp]
000070a59add7e62  lea rsi, [rsp+0x10]
000070a59add7e67  lea rdx, [rsp+0x20]
000070a59add7e6c  lea rcx, [rsp+0x30]
000070a59add7e71  mov r8d, 0x00
000070a59add7e77  lea r9, [r15+0x3A8]
000070a59add7e7e  movaps [rdi], xmm12
000070a59add7e82  movaps [rsi], xmm3
000070a59add7e85  movaps [rdx], xmm14
000070a59add7e89  movaps [rcx], xmm5
000070a59add7e8c  mov rax, 0x622906D8FA50
000070a59add7e96  call rax
000070a59add7e98  movaps xmm12, [rsp]
000070a59add7e9d  add rsp, 0x40
000070a59add7ea1  vmovaps xmm0, [rsp]
000070a59add7ea6  vmovaps xmm1, [rsp+0x10]
000070a59add7eac  vmovaps xmm2, [rsp+0x20]
000070a59add7eb2  vmovaps xmm3, [rsp+0x30]
000070a59add7eb8  vmovaps xmm4, [rsp+0x40]
000070a59add7ebe  vmovaps xmm5, [rsp+0x50]
000070a59add7ec4  vmovaps xmm6, [rsp+0x60]
000070a59add7eca  vmovaps xmm7, [rsp+0x70]
000070a59add7ed0  vmovaps xmm8, [rsp+0x80]
000070a59add7ed9  vmovaps xmm9, [rsp+0x90]
000070a59add7ee2  vmovaps xmm10, [rsp+0xA0]
000070a59add7eeb  vmovaps xmm11, [rsp+0xB0]
000070a59add7ef4  vmovaps xmm13, [rsp+0xC0]
000070a59add7efd  vmovaps xmm14, [rsp+0xD0]
000070a59add7f06  vmovaps xmm15, [rsp+0xE0]
000070a59add7f0f  add rsp, 0xF0
000070a59add7f16  pop r11
000070a59add7f18  pop r10
000070a59add7f1a  pop r9
000070a59add7f1c  pop r8
000070a59add7f1e  pop rsi
000070a59add7f1f  pop rdi
000070a59add7f20  pop rdx
000070a59add7f21  pop rcx
000070a59add7f22  pop rax
000070a59add7f23  add rsp, 0x08
000070a59add7f27  jmp 0x000070A59ADD68CB
000070a59add7f2c  sub rsp, 0x08
000070a59add7f30  push rax
000070a59add7f31  push rcx
000070a59add7f32  push rdx
000070a59add7f33  push rdi
000070a59add7f34  push rsi
000070a59add7f35  push r8
000070a59add7f37  push r9
000070a59add7f39  push r10
000070a59add7f3b  push r11
000070a59add7f3d  sub rsp, 0xF0
000070a59add7f44  vmovaps [rsp], xmm0
000070a59add7f49  vmovaps [rsp+0x10], xmm1
000070a59add7f4f  vmovaps [rsp+0x20], xmm2
000070a59add7f55  vmovaps [rsp+0x30], xmm3
000070a59add7f5b  vmovaps [rsp+0x40], xmm4
000070a59add7f61  vmovaps [rsp+0x50], xmm5
000070a59add7f67  vmovaps [rsp+0x60], xmm6
000070a59add7f6d  vmovaps [rsp+0x70], xmm7
000070a59add7f73  vmovaps [rsp+0x80], xmm8
000070a59add7f7c  vmovaps [rsp+0x90], xmm9
000070a59add7f85  vmovaps [rsp+0xA0], xmm11
000070a59add7f8e  vmovaps [rsp+0xB0], xmm12
000070a59add7f97  vmovaps [rsp+0xC0], xmm13
000070a59add7fa0  vmovaps [rsp+0xD0], xmm14
000070a59add7fa9  vmovaps [rsp+0xE0], xmm15
000070a59add7fb2  sub rsp, 0x40
000070a59add7fb6  lea rdi, [rsp]
000070a59add7fba  lea rsi, [rsp+0x10]
000070a59add7fbf  lea rdx, [rsp+0x20]
000070a59add7fc4  lea rcx, [rsp+0x30]
000070a59add7fc9  mov r8d, 0x00
000070a59add7fcf  lea r9, [r15+0x3A8]
000070a59add7fd6  movaps [rdi], xmm10
000070a59add7fda  movaps [rsi], xmm9
000070a59add7fde  movaps [rdx], xmm7
000070a59add7fe1  movaps [rcx], xmm14
000070a59add7fe5  mov rax, 0x622906D8FA50
000070a59add7fef  call rax
000070a59add7ff1  movaps xmm10, [rsp]
000070a59add7ff6  add rsp, 0x40
000070a59add7ffa  vmovaps xmm0, [rsp]
000070a59add7fff  vmovaps xmm1, [rsp+0x10]
000070a59add8005  vmovaps xmm2, [rsp+0x20]
000070a59add800b  vmovaps xmm3, [rsp+0x30]
000070a59add8011  vmovaps xmm4, [rsp+0x40]
000070a59add8017  vmovaps xmm5, [rsp+0x50]
000070a59add801d  vmovaps xmm6, [rsp+0x60]
000070a59add8023  vmovaps xmm7, [rsp+0x70]
000070a59add8029  vmovaps xmm8, [rsp+0x80]
000070a59add8032  vmovaps xmm9, [rsp+0x90]
000070a59add803b  vmovaps xmm11, [rsp+0xA0]
000070a59add8044  vmovaps xmm12, [rsp+0xB0]
000070a59add804d  vmovaps xmm13, [rsp+0xC0]
000070a59add8056  vmovaps xmm14, [rsp+0xD0]
000070a59add805f  vmovaps xmm15, [rsp+0xE0]
000070a59add8068  add rsp, 0xF0
000070a59add806f  pop r11
000070a59add8071  pop r10
000070a59add8073  pop r9
000070a59add8075  pop r8
000070a59add8077  pop rsi
000070a59add8078  pop rdi
000070a59add8079  pop rdx
000070a59add807a  pop rcx
000070a59add807b  pop rax
000070a59add807c  add rsp, 0x08
000070a59add8080  jmp 0x000070A59ADD68F1
000070a59add8085  call 0x000070A59ACE45A0
000070a59add808a  jmp 0x000070A59ADD68FE
000070a59add808f  sub rsp, 0x08
000070a59add8093  push rax
000070a59add8094  push rcx
000070a59add8095  push rdx
000070a59add8096  push rdi
000070a59add8097  push rsi
000070a59add8098  push r8
000070a59add809a  push r9
000070a59add809c  push r10
000070a59add809e  push r11
000070a59add80a0  sub rsp, 0xF0
000070a59add80a7  vmovaps [rsp], xmm0
000070a59add80ac  vmovaps [rsp+0x10], xmm1
000070a59add80b2  vmovaps [rsp+0x20], xmm2
000070a59add80b8  vmovaps [rsp+0x30], xmm3
000070a59add80be  vmovaps [rsp+0x40], xmm4
000070a59add80c4  vmovaps [rsp+0x50], xmm6
000070a59add80ca  vmovaps [rsp+0x60], xmm7
000070a59add80d0  vmovaps [rsp+0x70], xmm8
000070a59add80d6  vmovaps [rsp+0x80], xmm9
000070a59add80df  vmovaps [rsp+0x90], xmm10
000070a59add80e8  vmovaps [rsp+0xA0], xmm11
000070a59add80f1  vmovaps [rsp+0xB0], xmm12
000070a59add80fa  vmovaps [rsp+0xC0], xmm13
000070a59add8103  vmovaps [rsp+0xD0], xmm14
000070a59add810c  vmovaps [rsp+0xE0], xmm15
000070a59add8115  sub rsp, 0x40
000070a59add8119  lea rdi, [rsp]
000070a59add811d  lea rsi, [rsp+0x10]
000070a59add8122  lea rdx, [rsp+0x20]
000070a59add8127  lea rcx, [rsp+0x30]
000070a59add812c  mov r8d, 0x00
000070a59add8132  lea r9, [r15+0x3A8]
000070a59add8139  movaps [rdi], xmm5
000070a59add813c  movaps [rsi], xmm6
000070a59add813f  movaps [rdx], xmm7
000070a59add8142  movaps [rcx], xmm9
000070a59add8146  mov rax, 0x622906D8FA50
000070a59add8150  call rax
000070a59add8152  movaps xmm5, [rsp]
000070a59add8156  add rsp, 0x40
000070a59add815a  vmovaps xmm0, [rsp]
000070a59add815f  vmovaps xmm1, [rsp+0x10]
000070a59add8165  vmovaps xmm2, [rsp+0x20]
000070a59add816b  vmovaps xmm3, [rsp+0x30]
000070a59add8171  vmovaps xmm4, [rsp+0x40]
000070a59add8177  vmovaps xmm6, [rsp+0x50]
000070a59add817d  vmovaps xmm7, [rsp+0x60]
000070a59add8183  vmovaps xmm8, [rsp+0x70]
000070a59add8189  vmovaps xmm9, [rsp+0x80]
000070a59add8192  vmovaps xmm10, [rsp+0x90]
000070a59add819b  vmovaps xmm11, [rsp+0xA0]
000070a59add81a4  vmovaps xmm12, [rsp+0xB0]
000070a59add81ad  vmovaps xmm13, [rsp+0xC0]
000070a59add81b6  vmovaps xmm14, [rsp+0xD0]
000070a59add81bf  vmovaps xmm15, [rsp+0xE0]
000070a59add81c8  add rsp, 0xF0
000070a59add81cf  pop r11
000070a59add81d1  pop r10
000070a59add81d3  pop r9
000070a59add81d5  pop r8
000070a59add81d7  pop rsi
000070a59add81d8  pop rdi
000070a59add81d9  pop rdx
000070a59add81da  pop rcx
000070a59add81db  pop rax
000070a59add81dc  add rsp, 0x08
000070a59add81e0  jmp 0x000070A59ADD6930
000070a59add81e5  sub rsp, 0x08
000070a59add81e9  push rax
000070a59add81ea  push rcx
000070a59add81eb  push rdx
000070a59add81ec  push rdi
000070a59add81ed  push rsi
000070a59add81ee  push r8
000070a59add81f0  push r9
000070a59add81f2  push r10
000070a59add81f4  push r11
000070a59add81f6  sub rsp, 0xF0
000070a59add81fd  vmovaps [rsp], xmm0
000070a59add8202  vmovaps [rsp+0x10], xmm1
000070a59add8208  vmovaps [rsp+0x20], xmm2
000070a59add820e  vmovaps [rsp+0x30], xmm3
000070a59add8214  vmovaps [rsp+0x40], xmm4
000070a59add821a  vmovaps [rsp+0x50], xmm5
000070a59add8220  vmovaps [rsp+0x60], xmm6
000070a59add8226  vmovaps [rsp+0x70], xmm8
000070a59add822c  vmovaps [rsp+0x80], xmm9
000070a59add8235  vmovaps [rsp+0x90], xmm10
000070a59add823e  vmovaps [rsp+0xA0], xmm11
000070a59add8247  vmovaps [rsp+0xB0], xmm12
000070a59add8250  vmovaps [rsp+0xC0], xmm13
000070a59add8259  vmovaps [rsp+0xD0], xmm14
000070a59add8262  vmovaps [rsp+0xE0], xmm15
000070a59add826b  sub rsp, 0x40
000070a59add826f  lea rdi, [rsp]
000070a59add8273  lea rsi, [rsp+0x10]
000070a59add8278  lea rdx, [rsp+0x20]
000070a59add827d  lea rcx, [rsp+0x30]
000070a59add8282  mov r8d, 0x00
000070a59add8288  lea r9, [r15+0x3A8]
000070a59add828f  movaps [rdi], xmm7
000070a59add8292  movaps [rsi], xmm13
000070a59add8296  movaps [rdx], xmm1
000070a59add8299  movaps [rcx], xmm9
000070a59add829d  mov rax, 0x622906D8FA50
000070a59add82a7  call rax
000070a59add82a9  movaps xmm7, [rsp]
000070a59add82ad  add rsp, 0x40
000070a59add82b1  vmovaps xmm0, [rsp]
000070a59add82b6  vmovaps xmm1, [rsp+0x10]
000070a59add82bc  vmovaps xmm2, [rsp+0x20]
000070a59add82c2  vmovaps xmm3, [rsp+0x30]
000070a59add82c8  vmovaps xmm4, [rsp+0x40]
000070a59add82ce  vmovaps xmm5, [rsp+0x50]
000070a59add82d4  vmovaps xmm6, [rsp+0x60]
000070a59add82da  vmovaps xmm8, [rsp+0x70]
000070a59add82e0  vmovaps xmm9, [rsp+0x80]
000070a59add82e9  vmovaps xmm10, [rsp+0x90]
000070a59add82f2  vmovaps xmm11, [rsp+0xA0]
000070a59add82fb  vmovaps xmm12, [rsp+0xB0]
000070a59add8304  vmovaps xmm13, [rsp+0xC0]
000070a59add830d  vmovaps xmm14, [rsp+0xD0]
000070a59add8316  vmovaps xmm15, [rsp+0xE0]
000070a59add831f  add rsp, 0xF0
000070a59add8326  pop r11
000070a59add8328  pop r10
000070a59add832a  pop r9
000070a59add832c  pop r8
000070a59add832e  pop rsi
000070a59add832f  pop rdi
000070a59add8330  pop rdx
000070a59add8331  pop rcx
000070a59add8332  pop rax
000070a59add8333  add rsp, 0x08
000070a59add8337  jmp 0x000070A59ADD6955
000070a59add833c  call 0x000070A59ACE3320
000070a59add8341  jmp 0x000070A59ADD6978
000070a59add8346  call 0x000070A59ACDE950
000070a59add834b  jmp 0x000070A59ADD6982
000070a59add8350  sub rsp, 0x08
000070a59add8354  push rax
000070a59add8355  push rcx
000070a59add8356  push rdx
000070a59add8357  push rdi
000070a59add8358  push rsi
000070a59add8359  push r8
000070a59add835b  push r9
000070a59add835d  push r10
000070a59add835f  push r11
000070a59add8361  sub rsp, 0xF0
000070a59add8368  vmovaps [rsp], xmm0
000070a59add836d  vmovaps [rsp+0x10], xmm1
000070a59add8373  vmovaps [rsp+0x20], xmm3
000070a59add8379  vmovaps [rsp+0x30], xmm4
000070a59add837f  vmovaps [rsp+0x40], xmm5
000070a59add8385  vmovaps [rsp+0x50], xmm6
000070a59add838b  vmovaps [rsp+0x60], xmm7
000070a59add8391  vmovaps [rsp+0x70], xmm8
000070a59add8397  vmovaps [rsp+0x80], xmm9
000070a59add83a0  vmovaps [rsp+0x90], xmm10
000070a59add83a9  vmovaps [rsp+0xA0], xmm11
000070a59add83b2  vmovaps [rsp+0xB0], xmm12
000070a59add83bb  vmovaps [rsp+0xC0], xmm13
000070a59add83c4  vmovaps [rsp+0xD0], xmm14
000070a59add83cd  vmovaps [rsp+0xE0], xmm15
000070a59add83d6  sub rsp, 0x40
000070a59add83da  lea rdi, [rsp]
000070a59add83de  lea rsi, [rsp+0x10]
000070a59add83e3  lea rdx, [rsp+0x20]
000070a59add83e8  lea rcx, [rsp+0x30]
000070a59add83ed  mov r8d, 0x00
000070a59add83f3  lea r9, [r15+0x3A8]
000070a59add83fa  movaps [rdi], xmm2
000070a59add83fd  movaps [rsi], xmm12
000070a59add8401  movaps [rdx], xmm6
000070a59add8404  movaps [rcx], xmm3
000070a59add8407  mov rax, 0x622906D8FA50
000070a59add8411  call rax
000070a59add8413  movaps xmm2, [rsp]
000070a59add8417  add rsp, 0x40
000070a59add841b  vmovaps xmm0, [rsp]
000070a59add8420  vmovaps xmm1, [rsp+0x10]
000070a59add8426  vmovaps xmm3, [rsp+0x20]
000070a59add842c  vmovaps xmm4, [rsp+0x30]
000070a59add8432  vmovaps xmm5, [rsp+0x40]
000070a59add8438  vmovaps xmm6, [rsp+0x50]
000070a59add843e  vmovaps xmm7, [rsp+0x60]
000070a59add8444  vmovaps xmm8, [rsp+0x70]
000070a59add844a  vmovaps xmm9, [rsp+0x80]
000070a59add8453  vmovaps xmm10, [rsp+0x90]
000070a59add845c  vmovaps xmm11, [rsp+0xA0]
000070a59add8465  vmovaps xmm12, [rsp+0xB0]
000070a59add846e  vmovaps xmm13, [rsp+0xC0]
000070a59add8477  vmovaps xmm14, [rsp+0xD0]
000070a59add8480  vmovaps xmm15, [rsp+0xE0]
000070a59add8489  add rsp, 0xF0
000070a59add8490  pop r11
000070a59add8492  pop r10
000070a59add8494  pop r9
000070a59add8496  pop r8
000070a59add8498  pop rsi
000070a59add8499  pop rdi
000070a59add849a  pop rdx
000070a59add849b  pop rcx
000070a59add849c  pop rax
000070a59add849d  add rsp, 0x08
000070a59add84a1  jmp 0x000070A59ADD69C8
000070a59add84a6  sub rsp, 0x08
000070a59add84aa  push rax
000070a59add84ab  push rcx
000070a59add84ac  push rdx
000070a59add84ad  push rdi
000070a59add84ae  push rsi
000070a59add84af  push r8
000070a59add84b1  push r9
000070a59add84b3  push r10
000070a59add84b5  push r11
000070a59add84b7  sub rsp, 0xF0
000070a59add84be  vmovaps [rsp], xmm0
000070a59add84c3  vmovaps [rsp+0x10], xmm1
000070a59add84c9  vmovaps [rsp+0x20], xmm2
000070a59add84cf  vmovaps [rsp+0x30], xmm3
000070a59add84d5  vmovaps [rsp+0x40], xmm4
000070a59add84db  vmovaps [rsp+0x50], xmm5
000070a59add84e1  vmovaps [rsp+0x60], xmm7
000070a59add84e7  vmovaps [rsp+0x70], xmm8
000070a59add84ed  vmovaps [rsp+0x80], xmm9
000070a59add84f6  vmovaps [rsp+0x90], xmm10
000070a59add84ff  vmovaps [rsp+0xA0], xmm11
000070a59add8508  vmovaps [rsp+0xB0], xmm12
000070a59add8511  vmovaps [rsp+0xC0], xmm13
000070a59add851a  vmovaps [rsp+0xD0], xmm14
000070a59add8523  vmovaps [rsp+0xE0], xmm15
000070a59add852c  sub rsp, 0x40
000070a59add8530  lea rdi, [rsp]
000070a59add8534  lea rsi, [rsp+0x10]
000070a59add8539  lea rdx, [rsp+0x20]
000070a59add853e  lea rcx, [rsp+0x30]
000070a59add8543  mov r8d, 0x00
000070a59add8549  lea r9, [r15+0x3A8]
000070a59add8550  movaps [rdi], xmm6
000070a59add8553  movaps [rsi], xmm10
000070a59add8557  movaps [rdx], xmm12
000070a59add855b  movaps [rcx], xmm1
000070a59add855e  mov rax, 0x622906D8FA50
000070a59add8568  call rax
000070a59add856a  movaps xmm6, [rsp]
000070a59add856e  add rsp, 0x40
000070a59add8572  vmovaps xmm0, [rsp]
000070a59add8577  vmovaps xmm1, [rsp+0x10]
000070a59add857d  vmovaps xmm2, [rsp+0x20]
000070a59add8583  vmovaps xmm3, [rsp+0x30]
000070a59add8589  vmovaps xmm4, [rsp+0x40]
000070a59add858f  vmovaps xmm5, [rsp+0x50]
000070a59add8595  vmovaps xmm7, [rsp+0x60]
000070a59add859b  vmovaps xmm8, [rsp+0x70]
000070a59add85a1  vmovaps xmm9, [rsp+0x80]
000070a59add85aa  vmovaps xmm10, [rsp+0x90]
000070a59add85b3  vmovaps xmm11, [rsp+0xA0]
000070a59add85bc  vmovaps xmm12, [rsp+0xB0]
000070a59add85c5  vmovaps xmm13, [rsp+0xC0]
000070a59add85ce  vmovaps xmm14, [rsp+0xD0]
000070a59add85d7  vmovaps xmm15, [rsp+0xE0]
000070a59add85e0  add rsp, 0xF0
000070a59add85e7  pop r11
000070a59add85e9  pop r10
000070a59add85eb  pop r9
000070a59add85ed  pop r8
000070a59add85ef  pop rsi
000070a59add85f0  pop rdi
000070a59add85f1  pop rdx
000070a59add85f2  pop rcx
000070a59add85f3  pop rax
000070a59add85f4  add rsp, 0x08
000070a59add85f8  jmp 0x000070A59ADD69F6
000070a59add85fd  sub rsp, 0x08
000070a59add8601  push rax
000070a59add8602  push rcx
000070a59add8603  push rdx
000070a59add8604  push rdi
000070a59add8605  push rsi
000070a59add8606  push r8
000070a59add8608  push r9
000070a59add860a  push r10
000070a59add860c  push r11
000070a59add860e  sub rsp, 0xF0
000070a59add8615  vmovaps [rsp], xmm0
000070a59add861a  vmovaps [rsp+0x10], xmm1
000070a59add8620  vmovaps [rsp+0x20], xmm2
000070a59add8626  vmovaps [rsp+0x30], xmm3
000070a59add862c  vmovaps [rsp+0x40], xmm4
000070a59add8632  vmovaps [rsp+0x50], xmm5
000070a59add8638  vmovaps [rsp+0x60], xmm6
000070a59add863e  vmovaps [rsp+0x70], xmm7
000070a59add8644  vmovaps [rsp+0x80], xmm8
000070a59add864d  vmovaps [rsp+0x90], xmm9
000070a59add8656  vmovaps [rsp+0xA0], xmm11
000070a59add865f  vmovaps [rsp+0xB0], xmm12
000070a59add8668  vmovaps [rsp+0xC0], xmm13
000070a59add8671  vmovaps [rsp+0xD0], xmm14
000070a59add867a  vmovaps [rsp+0xE0], xmm15
000070a59add8683  sub rsp, 0x40
000070a59add8687  lea rdi, [rsp]
000070a59add868b  lea rsi, [rsp+0x10]
000070a59add8690  lea rdx, [rsp+0x20]
000070a59add8695  lea rcx, [rsp+0x30]
000070a59add869a  mov r8d, 0x00
000070a59add86a0  lea r9, [r15+0x3A8]
000070a59add86a7  movaps [rdi], xmm10
000070a59add86ab  movaps [rsi], xmm5
000070a59add86ae  movaps [rdx], xmm12
000070a59add86b2  movaps [rcx], xmm1
000070a59add86b5  mov rax, 0x622906D8FA50
000070a59add86bf  call rax
000070a59add86c1  movaps xmm10, [rsp]
000070a59add86c6  add rsp, 0x40
000070a59add86ca  vmovaps xmm0, [rsp]
000070a59add86cf  vmovaps xmm1, [rsp+0x10]
000070a59add86d5  vmovaps xmm2, [rsp+0x20]
000070a59add86db  vmovaps xmm3, [rsp+0x30]
000070a59add86e1  vmovaps xmm4, [rsp+0x40]
000070a59add86e7  vmovaps xmm5, [rsp+0x50]
000070a59add86ed  vmovaps xmm6, [rsp+0x60]
000070a59add86f3  vmovaps xmm7, [rsp+0x70]
000070a59add86f9  vmovaps xmm8, [rsp+0x80]
000070a59add8702  vmovaps xmm9, [rsp+0x90]
000070a59add870b  vmovaps xmm11, [rsp+0xA0]
000070a59add8714  vmovaps xmm12, [rsp+0xB0]
000070a59add871d  vmovaps xmm13, [rsp+0xC0]
000070a59add8726  vmovaps xmm14, [rsp+0xD0]
000070a59add872f  vmovaps xmm15, [rsp+0xE0]
000070a59add8738  add rsp, 0xF0
000070a59add873f  pop r11
000070a59add8741  pop r10
000070a59add8743  pop r9
000070a59add8745  pop r8
000070a59add8747  pop rsi
000070a59add8748  pop rdi
000070a59add8749  pop rdx
000070a59add874a  pop rcx
000070a59add874b  pop rax
000070a59add874c  add rsp, 0x08
000070a59add8750  jmp 0x000070A59ADD6A25
000070a59add8755  sub rsp, 0x08
000070a59add8759  push rax
000070a59add875a  push rcx
000070a59add875b  push rdx
000070a59add875c  push rdi
000070a59add875d  push rsi
000070a59add875e  push r8
000070a59add8760  push r9
000070a59add8762  push r10
000070a59add8764  push r11
000070a59add8766  sub rsp, 0xF0
000070a59add876d  vmovaps [rsp], xmm0
000070a59add8772  vmovaps [rsp+0x10], xmm1
000070a59add8778  vmovaps [rsp+0x20], xmm2
000070a59add877e  vmovaps [rsp+0x30], xmm3
000070a59add8784  vmovaps [rsp+0x40], xmm4
000070a59add878a  vmovaps [rsp+0x50], xmm5
000070a59add8790  vmovaps [rsp+0x60], xmm6
000070a59add8796  vmovaps [rsp+0x70], xmm7
000070a59add879c  vmovaps [rsp+0x80], xmm8
000070a59add87a5  vmovaps [rsp+0x90], xmm9
000070a59add87ae  vmovaps [rsp+0xA0], xmm10
000070a59add87b7  vmovaps [rsp+0xB0], xmm11
000070a59add87c0  vmovaps [rsp+0xC0], xmm13
000070a59add87c9  vmovaps [rsp+0xD0], xmm14
000070a59add87d2  vmovaps [rsp+0xE0], xmm15
000070a59add87db  sub rsp, 0x40
000070a59add87df  lea rdi, [rsp]
000070a59add87e3  lea rsi, [rsp+0x10]
000070a59add87e8  lea rdx, [rsp+0x20]
000070a59add87ed  lea rcx, [rsp+0x30]
000070a59add87f2  mov r8d, 0x00
000070a59add87f8  lea r9, [r15+0x3A8]
000070a59add87ff  movaps [rdi], xmm12
000070a59add8803  movaps [rsi], xmm7
000070a59add8806  movaps [rdx], xmm15
000070a59add880a  movaps [rcx], xmm1
000070a59add880d  mov rax, 0x622906D8FA50
000070a59add8817  call rax
000070a59add8819  movaps xmm12, [rsp]
000070a59add881e  add rsp, 0x40
000070a59add8822  vmovaps xmm0, [rsp]
000070a59add8827  vmovaps xmm1, [rsp+0x10]
000070a59add882d  vmovaps xmm2, [rsp+0x20]
000070a59add8833  vmovaps xmm3, [rsp+0x30]
000070a59add8839  vmovaps xmm4, [rsp+0x40]
000070a59add883f  vmovaps xmm5, [rsp+0x50]
000070a59add8845  vmovaps xmm6, [rsp+0x60]
000070a59add884b  vmovaps xmm7, [rsp+0x70]
000070a59add8851  vmovaps xmm8, [rsp+0x80]
000070a59add885a  vmovaps xmm9, [rsp+0x90]
000070a59add8863  vmovaps xmm10, [rsp+0xA0]
000070a59add886c  vmovaps xmm11, [rsp+0xB0]
000070a59add8875  vmovaps xmm13, [rsp+0xC0]
000070a59add887e  vmovaps xmm14, [rsp+0xD0]
000070a59add8887  vmovaps xmm15, [rsp+0xE0]
000070a59add8890  add rsp, 0xF0
000070a59add8897  pop r11
000070a59add8899  pop r10
000070a59add889b  pop r9
000070a59add889d  pop r8
000070a59add889f  pop rsi
000070a59add88a0  pop rdi
000070a59add88a1  pop rdx
000070a59add88a2  pop rcx
000070a59add88a3  pop rax
000070a59add88a4  add rsp, 0x08
000070a59add88a8  jmp 0x000070A59ADD6A4E
000070a59add88ad  call 0x000070A59ACD64F0
000070a59add88b2  jmp 0x000070A59ADD6A58
000070a59add88b7  call 0x000070A59ACE5820
000070a59add88bc  jmp 0x000070A59ADD6A62
000070a59add88c1  sub rsp, 0x08
000070a59add88c5  push rax
000070a59add88c6  push rcx
000070a59add88c7  push rdx
000070a59add88c8  push rdi
000070a59add88c9  push rsi
000070a59add88ca  push r8
000070a59add88cc  push r9
000070a59add88ce  push r10
000070a59add88d0  push r11
000070a59add88d2  sub rsp, 0xF0
000070a59add88d9  vmovaps [rsp], xmm0
000070a59add88de  vmovaps [rsp+0x10], xmm1
000070a59add88e4  vmovaps [rsp+0x20], xmm2
000070a59add88ea  vmovaps [rsp+0x30], xmm3
000070a59add88f0  vmovaps [rsp+0x40], xmm4
000070a59add88f6  vmovaps [rsp+0x50], xmm5
000070a59add88fc  vmovaps [rsp+0x60], xmm6
000070a59add8902  vmovaps [rsp+0x70], xmm8
000070a59add8908  vmovaps [rsp+0x80], xmm9
000070a59add8911  vmovaps [rsp+0x90], xmm10
000070a59add891a  vmovaps [rsp+0xA0], xmm11
000070a59add8923  vmovaps [rsp+0xB0], xmm12
000070a59add892c  vmovaps [rsp+0xC0], xmm13
000070a59add8935  vmovaps [rsp+0xD0], xmm14
000070a59add893e  vmovaps [rsp+0xE0], xmm15
000070a59add8947  sub rsp, 0x40
000070a59add894b  lea rdi, [rsp]
000070a59add894f  lea rsi, [rsp+0x10]
000070a59add8954  lea rdx, [rsp+0x20]
000070a59add8959  lea rcx, [rsp+0x30]
000070a59add895e  mov r8d, 0x00
000070a59add8964  lea r9, [r15+0x3A8]
000070a59add896b  movaps [rdi], xmm7
000070a59add896e  movaps [rsi], xmm2
000070a59add8971  movaps [rdx], xmm9
000070a59add8975  movaps [rcx], xmm11
000070a59add8979  mov rax, 0x622906D8FA50
000070a59add8983  call rax
000070a59add8985  movaps xmm7, [rsp]
000070a59add8989  add rsp, 0x40
000070a59add898d  vmovaps xmm0, [rsp]
000070a59add8992  vmovaps xmm1, [rsp+0x10]
000070a59add8998  vmovaps xmm2, [rsp+0x20]
000070a59add899e  vmovaps xmm3, [rsp+0x30]
000070a59add89a4  vmovaps xmm4, [rsp+0x40]
000070a59add89aa  vmovaps xmm5, [rsp+0x50]
000070a59add89b0  vmovaps xmm6, [rsp+0x60]
000070a59add89b6  vmovaps xmm8, [rsp+0x70]
000070a59add89bc  vmovaps xmm9, [rsp+0x80]
000070a59add89c5  vmovaps xmm10, [rsp+0x90]
000070a59add89ce  vmovaps xmm11, [rsp+0xA0]
000070a59add89d7  vmovaps xmm12, [rsp+0xB0]
000070a59add89e0  vmovaps xmm13, [rsp+0xC0]
000070a59add89e9  vmovaps xmm14, [rsp+0xD0]
000070a59add89f2  vmovaps xmm15, [rsp+0xE0]
000070a59add89fb  add rsp, 0xF0
000070a59add8a02  pop r11
000070a59add8a04  pop r10
000070a59add8a06  pop r9
000070a59add8a08  pop r8
000070a59add8a0a  pop rsi
000070a59add8a0b  pop rdi
000070a59add8a0c  pop rdx
000070a59add8a0d  pop rcx
000070a59add8a0e  pop rax
000070a59add8a0f  add rsp, 0x08
000070a59add8a13  jmp 0x000070A59ADD6A96
000070a59add8a18  sub rsp, 0x08
000070a59add8a1c  push rax
000070a59add8a1d  push rcx
000070a59add8a1e  push rdx
000070a59add8a1f  push rdi
000070a59add8a20  push rsi
000070a59add8a21  push r8
000070a59add8a23  push r9
000070a59add8a25  push r10
000070a59add8a27  push r11
000070a59add8a29  sub rsp, 0xF0
000070a59add8a30  vmovaps [rsp], xmm0
000070a59add8a35  vmovaps [rsp+0x10], xmm1
000070a59add8a3b  vmovaps [rsp+0x20], xmm2
000070a59add8a41  vmovaps [rsp+0x30], xmm3
000070a59add8a47  vmovaps [rsp+0x40], xmm4
000070a59add8a4d  vmovaps [rsp+0x50], xmm5
000070a59add8a53  vmovaps [rsp+0x60], xmm6
000070a59add8a59  vmovaps [rsp+0x70], xmm7
000070a59add8a5f  vmovaps [rsp+0x80], xmm8
000070a59add8a68  vmovaps [rsp+0x90], xmm10
000070a59add8a71  vmovaps [rsp+0xA0], xmm11
000070a59add8a7a  vmovaps [rsp+0xB0], xmm12
000070a59add8a83  vmovaps [rsp+0xC0], xmm13
000070a59add8a8c  vmovaps [rsp+0xD0], xmm14
000070a59add8a95  vmovaps [rsp+0xE0], xmm15
000070a59add8a9e  sub rsp, 0x40
000070a59add8aa2  lea rdi, [rsp]
000070a59add8aa6  lea rsi, [rsp+0x10]
000070a59add8aab  lea rdx, [rsp+0x20]
000070a59add8ab0  lea rcx, [rsp+0x30]
000070a59add8ab5  mov r8d, 0x00
000070a59add8abb  lea r9, [r15+0x3A8]
000070a59add8ac2  movaps [rdi], xmm9
000070a59add8ac6  movaps [rsi], xmm6
000070a59add8ac9  movaps [rdx], xmm1
000070a59add8acc  movaps [rcx], xmm11
000070a59add8ad0  mov rax, 0x622906D8FA50
000070a59add8ada  call rax
000070a59add8adc  movaps xmm9, [rsp]
000070a59add8ae1  add rsp, 0x40
000070a59add8ae5  vmovaps xmm0, [rsp]
000070a59add8aea  vmovaps xmm1, [rsp+0x10]
000070a59add8af0  vmovaps xmm2, [rsp+0x20]
000070a59add8af6  vmovaps xmm3, [rsp+0x30]
000070a59add8afc  vmovaps xmm4, [rsp+0x40]
000070a59add8b02  vmovaps xmm5, [rsp+0x50]
000070a59add8b08  vmovaps xmm6, [rsp+0x60]
000070a59add8b0e  vmovaps xmm7, [rsp+0x70]
000070a59add8b14  vmovaps xmm8, [rsp+0x80]
000070a59add8b1d  vmovaps xmm10, [rsp+0x90]
000070a59add8b26  vmovaps xmm11, [rsp+0xA0]
000070a59add8b2f  vmovaps xmm12, [rsp+0xB0]
000070a59add8b38  vmovaps xmm13, [rsp+0xC0]
000070a59add8b41  vmovaps xmm14, [rsp+0xD0]
000070a59add8b4a  vmovaps xmm15, [rsp+0xE0]
000070a59add8b53  add rsp, 0xF0
000070a59add8b5a  pop r11
000070a59add8b5c  pop r10
000070a59add8b5e  pop r9
000070a59add8b60  pop r8
000070a59add8b62  pop rsi
000070a59add8b63  pop rdi
000070a59add8b64  pop rdx
000070a59add8b65  pop rcx
000070a59add8b66  pop rax
000070a59add8b67  add rsp, 0x08
000070a59add8b6b  jmp 0x000070A59ADD6ABC
000070a59add8b70  sub rsp, 0x08
000070a59add8b74  push rax
000070a59add8b75  push rcx
000070a59add8b76  push rdx
000070a59add8b77  push rdi
000070a59add8b78  push rsi
000070a59add8b79  push r8
000070a59add8b7b  push r9
000070a59add8b7d  push r10
000070a59add8b7f  push r11
000070a59add8b81  sub rsp, 0xF0
000070a59add8b88  vmovaps [rsp], xmm0
000070a59add8b8d  vmovaps [rsp+0x10], xmm1
000070a59add8b93  vmovaps [rsp+0x20], xmm2
000070a59add8b99  vmovaps [rsp+0x30], xmm3
000070a59add8b9f  vmovaps [rsp+0x40], xmm4
000070a59add8ba5  vmovaps [rsp+0x50], xmm5
000070a59add8bab  vmovaps [rsp+0x60], xmm6
000070a59add8bb1  vmovaps [rsp+0x70], xmm7
000070a59add8bb7  vmovaps [rsp+0x80], xmm8
000070a59add8bc0  vmovaps [rsp+0x90], xmm9
000070a59add8bc9  vmovaps [rsp+0xA0], xmm10
000070a59add8bd2  vmovaps [rsp+0xB0], xmm12
000070a59add8bdb  vmovaps [rsp+0xC0], xmm13
000070a59add8be4  vmovaps [rsp+0xD0], xmm14
000070a59add8bed  vmovaps [rsp+0xE0], xmm15
000070a59add8bf6  sub rsp, 0x40
000070a59add8bfa  lea rdi, [rsp]
000070a59add8bfe  lea rsi, [rsp+0x10]
000070a59add8c03  lea rdx, [rsp+0x20]
000070a59add8c08  lea rcx, [rsp+0x30]
000070a59add8c0d  mov r8d, 0x00
000070a59add8c13  lea r9, [r15+0x3A8]
000070a59add8c1a  movaps [rdi], xmm11
000070a59add8c1e  movaps [rsi], xmm10
000070a59add8c22  movaps [rdx], xmm8
000070a59add8c26  movaps [rcx], xmm1
000070a59add8c29  mov rax, 0x622906D8FA50
000070a59add8c33  call rax
000070a59add8c35  movaps xmm11, [rsp]
000070a59add8c3a  add rsp, 0x40
000070a59add8c3e  vmovaps xmm0, [rsp]
000070a59add8c43  vmovaps xmm1, [rsp+0x10]
000070a59add8c49  vmovaps xmm2, [rsp+0x20]
000070a59add8c4f  vmovaps xmm3, [rsp+0x30]
000070a59add8c55  vmovaps xmm4, [rsp+0x40]
000070a59add8c5b  vmovaps xmm5, [rsp+0x50]
000070a59add8c61  vmovaps xmm6, [rsp+0x60]
000070a59add8c67  vmovaps xmm7, [rsp+0x70]
000070a59add8c6d  vmovaps xmm8, [rsp+0x80]
000070a59add8c76  vmovaps xmm9, [rsp+0x90]
000070a59add8c7f  vmovaps xmm10, [rsp+0xA0]
000070a59add8c88  vmovaps xmm12, [rsp+0xB0]
000070a59add8c91  vmovaps xmm13, [rsp+0xC0]
000070a59add8c9a  vmovaps xmm14, [rsp+0xD0]
000070a59add8ca3  vmovaps xmm15, [rsp+0xE0]
000070a59add8cac  add rsp, 0xF0
000070a59add8cb3  pop r11
000070a59add8cb5  pop r10
000070a59add8cb7  pop r9
000070a59add8cb9  pop r8
000070a59add8cbb  pop rsi
000070a59add8cbc  pop rdi
000070a59add8cbd  pop rdx
000070a59add8cbe  pop rcx
000070a59add8cbf  pop rax
000070a59add8cc0  add rsp, 0x08
000070a59add8cc4  jmp 0x000070A59ADD6AE2
000070a59add8cc9  sub rsp, 0x08
000070a59add8ccd  push rax
000070a59add8cce  push rcx
000070a59add8ccf  push rdx
000070a59add8cd0  push rdi
000070a59add8cd1  push rsi
000070a59add8cd2  push r8
000070a59add8cd4  push r9
000070a59add8cd6  push r10
000070a59add8cd8  push r11
000070a59add8cda  sub rsp, 0xF0
000070a59add8ce1  vmovaps [rsp], xmm0
000070a59add8ce6  vmovaps [rsp+0x10], xmm1
000070a59add8cec  vmovaps [rsp+0x20], xmm2
000070a59add8cf2  vmovaps [rsp+0x30], xmm3
000070a59add8cf8  vmovaps [rsp+0x40], xmm4
000070a59add8cfe  vmovaps [rsp+0x50], xmm5
000070a59add8d04  vmovaps [rsp+0x60], xmm6
000070a59add8d0a  vmovaps [rsp+0x70], xmm7
000070a59add8d10  vmovaps [rsp+0x80], xmm8
000070a59add8d19  vmovaps [rsp+0x90], xmm9
000070a59add8d22  vmovaps [rsp+0xA0], xmm11
000070a59add8d2b  vmovaps [rsp+0xB0], xmm12
000070a59add8d34  vmovaps [rsp+0xC0], xmm13
000070a59add8d3d  vmovaps [rsp+0xD0], xmm14
000070a59add8d46  vmovaps [rsp+0xE0], xmm15
000070a59add8d4f  sub rsp, 0x40
000070a59add8d53  lea rdi, [rsp]
000070a59add8d57  lea rsi, [rsp+0x10]
000070a59add8d5c  lea rdx, [rsp+0x20]
000070a59add8d61  lea rcx, [rsp+0x30]
000070a59add8d66  mov r8d, 0x00
000070a59add8d6c  lea r9, [r15+0x3A8]
000070a59add8d73  movaps [rdi], xmm10
000070a59add8d77  movaps [rsi], xmm12
000070a59add8d7b  movaps [rdx], xmm13
000070a59add8d7f  movaps [rcx], xmm1
000070a59add8d82  mov rax, 0x622906D8FA50
000070a59add8d8c  call rax
000070a59add8d8e  movaps xmm10, [rsp]
000070a59add8d93  add rsp, 0x40
000070a59add8d97  vmovaps xmm0, [rsp]
000070a59add8d9c  vmovaps xmm1, [rsp+0x10]
000070a59add8da2  vmovaps xmm2, [rsp+0x20]
000070a59add8da8  vmovaps xmm3, [rsp+0x30]
000070a59add8dae  vmovaps xmm4, [rsp+0x40]
000070a59add8db4  vmovaps xmm5, [rsp+0x50]
000070a59add8dba  vmovaps xmm6, [rsp+0x60]
000070a59add8dc0  vmovaps xmm7, [rsp+0x70]
000070a59add8dc6  vmovaps xmm8, [rsp+0x80]
000070a59add8dcf  vmovaps xmm9, [rsp+0x90]
000070a59add8dd8  vmovaps xmm11, [rsp+0xA0]
000070a59add8de1  vmovaps xmm12, [rsp+0xB0]
000070a59add8dea  vmovaps xmm13, [rsp+0xC0]
000070a59add8df3  vmovaps xmm14, [rsp+0xD0]
000070a59add8dfc  vmovaps xmm15, [rsp+0xE0]
000070a59add8e05  add rsp, 0xF0
000070a59add8e0c  pop r11
000070a59add8e0e  pop r10
000070a59add8e10  pop r9
000070a59add8e12  pop r8
000070a59add8e14  pop rsi
000070a59add8e15  pop rdi
000070a59add8e16  pop rdx
000070a59add8e17  pop rcx
000070a59add8e18  pop rax
000070a59add8e19  add rsp, 0x08
000070a59add8e1d  jmp 0x000070A59ADD6B08
000070a59add8e22  call 0x000070A59ACD64F0
000070a59add8e27  jmp 0x000070A59ADD6B12
000070a59add8e2c  call 0x000070A59ACE3320
000070a59add8e31  jmp 0x000070A59ADD6B1C
000070a59add8e36  sub rsp, 0x08
000070a59add8e3a  push rax
000070a59add8e3b  push rcx
000070a59add8e3c  push rdx
000070a59add8e3d  push rdi
000070a59add8e3e  push rsi
000070a59add8e3f  push r8
000070a59add8e41  push r9
000070a59add8e43  push r10
000070a59add8e45  push r11
000070a59add8e47  sub rsp, 0xF0
000070a59add8e4e  vmovaps [rsp], xmm0
000070a59add8e53  vmovaps [rsp+0x10], xmm1
000070a59add8e59  vmovaps [rsp+0x20], xmm2
000070a59add8e5f  vmovaps [rsp+0x30], xmm3
000070a59add8e65  vmovaps [rsp+0x40], xmm4
000070a59add8e6b  vmovaps [rsp+0x50], xmm5
000070a59add8e71  vmovaps [rsp+0x60], xmm6
000070a59add8e77  vmovaps [rsp+0x70], xmm7
000070a59add8e7d  vmovaps [rsp+0x80], xmm9
000070a59add8e86  vmovaps [rsp+0x90], xmm10
000070a59add8e8f  vmovaps [rsp+0xA0], xmm11
000070a59add8e98  vmovaps [rsp+0xB0], xmm12
000070a59add8ea1  vmovaps [rsp+0xC0], xmm13
000070a59add8eaa  vmovaps [rsp+0xD0], xmm14
000070a59add8eb3  vmovaps [rsp+0xE0], xmm15
000070a59add8ebc  sub rsp, 0x40
000070a59add8ec0  lea rdi, [rsp]
000070a59add8ec4  lea rsi, [rsp+0x10]
000070a59add8ec9  lea rdx, [rsp+0x20]
000070a59add8ece  lea rcx, [rsp+0x30]
000070a59add8ed3  mov r8d, 0x00
000070a59add8ed9  lea r9, [r15+0x3A8]
000070a59add8ee0  movaps [rdi], xmm8
000070a59add8ee4  movaps [rsi], xmm7
000070a59add8ee7  movaps [rdx], xmm4
000070a59add8eea  movaps [rcx], xmm12
000070a59add8eee  mov rax, 0x622906D8FA50
000070a59add8ef8  call rax
000070a59add8efa  movaps xmm8, [rsp]
000070a59add8eff  add rsp, 0x40
000070a59add8f03  vmovaps xmm0, [rsp]
000070a59add8f08  vmovaps xmm1, [rsp+0x10]
000070a59add8f0e  vmovaps xmm2, [rsp+0x20]
000070a59add8f14  vmovaps xmm3, [rsp+0x30]
000070a59add8f1a  vmovaps xmm4, [rsp+0x40]
000070a59add8f20  vmovaps xmm5, [rsp+0x50]
000070a59add8f26  vmovaps xmm6, [rsp+0x60]
000070a59add8f2c  vmovaps xmm7, [rsp+0x70]
000070a59add8f32  vmovaps xmm9, [rsp+0x80]
000070a59add8f3b  vmovaps xmm10, [rsp+0x90]
000070a59add8f44  vmovaps xmm11, [rsp+0xA0]
000070a59add8f4d  vmovaps xmm12, [rsp+0xB0]
000070a59add8f56  vmovaps xmm13, [rsp+0xC0]
000070a59add8f5f  vmovaps xmm14, [rsp+0xD0]
000070a59add8f68  vmovaps xmm15, [rsp+0xE0]
000070a59add8f71  add rsp, 0xF0
000070a59add8f78  pop r11
000070a59add8f7a  pop r10
000070a59add8f7c  pop r9
000070a59add8f7e  pop r8
000070a59add8f80  pop rsi
000070a59add8f81  pop rdi
000070a59add8f82  pop rdx
000070a59add8f83  pop rcx
000070a59add8f84  pop rax
000070a59add8f85  add rsp, 0x08
000070a59add8f89  jmp 0x000070A59ADD6B45
000070a59add8f8e  sub rsp, 0x08
000070a59add8f92  push rax
000070a59add8f93  push rcx
000070a59add8f94  push rdx
000070a59add8f95  push rdi
000070a59add8f96  push rsi
000070a59add8f97  push r8
000070a59add8f99  push r9
000070a59add8f9b  push r10
000070a59add8f9d  push r11
000070a59add8f9f  sub rsp, 0xF0
000070a59add8fa6  vmovaps [rsp], xmm0
000070a59add8fab  vmovaps [rsp+0x10], xmm1
000070a59add8fb1  vmovaps [rsp+0x20], xmm2
000070a59add8fb7  vmovaps [rsp+0x30], xmm3
000070a59add8fbd  vmovaps [rsp+0x40], xmm4
000070a59add8fc3  vmovaps [rsp+0x50], xmm5
000070a59add8fc9  vmovaps [rsp+0x60], xmm6
000070a59add8fcf  vmovaps [rsp+0x70], xmm8
000070a59add8fd5  vmovaps [rsp+0x80], xmm9
000070a59add8fde  vmovaps [rsp+0x90], xmm10
000070a59add8fe7  vmovaps [rsp+0xA0], xmm11
000070a59add8ff0  vmovaps [rsp+0xB0], xmm12
000070a59add8ff9  vmovaps [rsp+0xC0], xmm13
000070a59add9002  vmovaps [rsp+0xD0], xmm14
000070a59add900b  vmovaps [rsp+0xE0], xmm15
000070a59add9014  sub rsp, 0x40
000070a59add9018  lea rdi, [rsp]
000070a59add901c  lea rsi, [rsp+0x10]
000070a59add9021  lea rdx, [rsp+0x20]
000070a59add9026  lea rcx, [rsp+0x30]
000070a59add902b  mov r8d, 0x00
000070a59add9031  lea r9, [r15+0x3A8]
000070a59add9038  movaps [rdi], xmm7
000070a59add903b  movaps [rsi], xmm9
000070a59add903f  movaps [rdx], xmm14
000070a59add9043  movaps [rcx], xmm12
000070a59add9047  mov rax, 0x622906D8FA50
000070a59add9051  call rax
000070a59add9053  movaps xmm7, [rsp]
000070a59add9057  add rsp, 0x40
000070a59add905b  vmovaps xmm0, [rsp]
000070a59add9060  vmovaps xmm1, [rsp+0x10]
000070a59add9066  vmovaps xmm2, [rsp+0x20]
000070a59add906c  vmovaps xmm3, [rsp+0x30]
000070a59add9072  vmovaps xmm4, [rsp+0x40]
000070a59add9078  vmovaps xmm5, [rsp+0x50]
000070a59add907e  vmovaps xmm6, [rsp+0x60]
000070a59add9084  vmovaps xmm8, [rsp+0x70]
000070a59add908a  vmovaps xmm9, [rsp+0x80]
000070a59add9093  vmovaps xmm10, [rsp+0x90]
000070a59add909c  vmovaps xmm11, [rsp+0xA0]
000070a59add90a5  vmovaps xmm12, [rsp+0xB0]
000070a59add90ae  vmovaps xmm13, [rsp+0xC0]
000070a59add90b7  vmovaps xmm14, [rsp+0xD0]
000070a59add90c0  vmovaps xmm15, [rsp+0xE0]
000070a59add90c9  add rsp, 0xF0
000070a59add90d0  pop r11
000070a59add90d2  pop r10
000070a59add90d4  pop r9
000070a59add90d6  pop r8
000070a59add90d8  pop rsi
000070a59add90d9  pop rdi
000070a59add90da  pop rdx
000070a59add90db  pop rcx
000070a59add90dc  pop rax
000070a59add90dd  add rsp, 0x08
000070a59add90e1  jmp 0x000070A59ADD6B6D
000070a59add90e6  sub rsp, 0x08
000070a59add90ea  push rax
000070a59add90eb  push rcx
000070a59add90ec  push rdx
000070a59add90ed  push rdi
000070a59add90ee  push rsi
000070a59add90ef  push r8
000070a59add90f1  push r9
000070a59add90f3  push r10
000070a59add90f5  push r11
000070a59add90f7  sub rsp, 0xF0
000070a59add90fe  vmovaps [rsp], xmm0
000070a59add9103  vmovaps [rsp+0x10], xmm1
000070a59add9109  vmovaps [rsp+0x20], xmm2
000070a59add910f  vmovaps [rsp+0x30], xmm3
000070a59add9115  vmovaps [rsp+0x40], xmm4
000070a59add911b  vmovaps [rsp+0x50], xmm5
000070a59add9121  vmovaps [rsp+0x60], xmm6
000070a59add9127  vmovaps [rsp+0x70], xmm7
000070a59add912d  vmovaps [rsp+0x80], xmm8
000070a59add9136  vmovaps [rsp+0x90], xmm9
000070a59add913f  vmovaps [rsp+0xA0], xmm10
000070a59add9148  vmovaps [rsp+0xB0], xmm11
000070a59add9151  vmovaps [rsp+0xC0], xmm13
000070a59add915a  vmovaps [rsp+0xD0], xmm14
000070a59add9163  vmovaps [rsp+0xE0], xmm15
000070a59add916c  sub rsp, 0x40
000070a59add9170  lea rdi, [rsp]
000070a59add9174  lea rsi, [rsp+0x10]
000070a59add9179  lea rdx, [rsp+0x20]
000070a59add917e  lea rcx, [rsp+0x30]
000070a59add9183  mov r8d, 0x00
000070a59add9189  lea r9, [r15+0x3A8]
000070a59add9190  movaps [rdi], xmm12
000070a59add9194  movaps [rsi], xmm11
000070a59add9198  movaps [rdx], xmm15
000070a59add919c  movaps [rcx], xmm14
000070a59add91a0  mov rax, 0x622906D8FA50
000070a59add91aa  call rax
000070a59add91ac  movaps xmm12, [rsp]
000070a59add91b1  add rsp, 0x40
000070a59add91b5  vmovaps xmm0, [rsp]
000070a59add91ba  vmovaps xmm1, [rsp+0x10]
000070a59add91c0  vmovaps xmm2, [rsp+0x20]
000070a59add91c6  vmovaps xmm3, [rsp+0x30]
000070a59add91cc  vmovaps xmm4, [rsp+0x40]
000070a59add91d2  vmovaps xmm5, [rsp+0x50]
000070a59add91d8  vmovaps xmm6, [rsp+0x60]
000070a59add91de  vmovaps xmm7, [rsp+0x70]
000070a59add91e4  vmovaps xmm8, [rsp+0x80]
000070a59add91ed  vmovaps xmm9, [rsp+0x90]
000070a59add91f6  vmovaps xmm10, [rsp+0xA0]
000070a59add91ff  vmovaps xmm11, [rsp+0xB0]
000070a59add9208  vmovaps xmm13, [rsp+0xC0]
000070a59add9211  vmovaps xmm14, [rsp+0xD0]
000070a59add921a  vmovaps xmm15, [rsp+0xE0]
000070a59add9223  add rsp, 0xF0
000070a59add922a  pop r11
000070a59add922c  pop r10
000070a59add922e  pop r9
000070a59add9230  pop r8
000070a59add9232  pop rsi
000070a59add9233  pop rdi
000070a59add9234  pop rdx
000070a59add9235  pop rcx
000070a59add9236  pop rax
000070a59add9237  add rsp, 0x08
000070a59add923b  jmp 0x000070A59ADD6B96
000070a59add9240  sub rsp, 0x08
000070a59add9244  push rax
000070a59add9245  push rcx
000070a59add9246  push rdx
000070a59add9247  push rdi
000070a59add9248  push rsi
000070a59add9249  push r8
000070a59add924b  push r9
000070a59add924d  push r10
000070a59add924f  push r11
000070a59add9251  sub rsp, 0xF0
000070a59add9258  vmovaps [rsp], xmm0
000070a59add925d  vmovaps [rsp+0x10], xmm1
000070a59add9263  vmovaps [rsp+0x20], xmm2
000070a59add9269  vmovaps [rsp+0x30], xmm3
000070a59add926f  vmovaps [rsp+0x40], xmm4
000070a59add9275  vmovaps [rsp+0x50], xmm5
000070a59add927b  vmovaps [rsp+0x60], xmm6
000070a59add9281  vmovaps [rsp+0x70], xmm7
000070a59add9287  vmovaps [rsp+0x80], xmm8
000070a59add9290  vmovaps [rsp+0x90], xmm9
000070a59add9299  vmovaps [rsp+0xA0], xmm10
000070a59add92a2  vmovaps [rsp+0xB0], xmm12
000070a59add92ab  vmovaps [rsp+0xC0], xmm13
000070a59add92b4  vmovaps [rsp+0xD0], xmm14
000070a59add92bd  vmovaps [rsp+0xE0], xmm15
000070a59add92c6  sub rsp, 0x40
000070a59add92ca  lea rdi, [rsp]
000070a59add92ce  lea rsi, [rsp+0x10]
000070a59add92d3  lea rdx, [rsp+0x20]
000070a59add92d8  lea rcx, [rsp+0x30]
000070a59add92dd  mov r8d, 0x00
000070a59add92e3  lea r9, [r15+0x3A8]
000070a59add92ea  movaps [rdi], xmm11
000070a59add92ee  movaps [rsi], xmm10
000070a59add92f2  movaps [rdx], xmm13
000070a59add92f6  movaps [rcx], xmm15
000070a59add92fa  mov rax, 0x622906D8FA50
000070a59add9304  call rax
000070a59add9306  movaps xmm11, [rsp]
000070a59add930b  add rsp, 0x40
000070a59add930f  vmovaps xmm0, [rsp]
000070a59add9314  vmovaps xmm1, [rsp+0x10]
000070a59add931a  vmovaps xmm2, [rsp+0x20]
000070a59add9320  vmovaps xmm3, [rsp+0x30]
000070a59add9326  vmovaps xmm4, [rsp+0x40]
000070a59add932c  vmovaps xmm5, [rsp+0x50]
000070a59add9332  vmovaps xmm6, [rsp+0x60]
000070a59add9338  vmovaps xmm7, [rsp+0x70]
000070a59add933e  vmovaps xmm8, [rsp+0x80]
000070a59add9347  vmovaps xmm9, [rsp+0x90]
000070a59add9350  vmovaps xmm10, [rsp+0xA0]
000070a59add9359  vmovaps xmm12, [rsp+0xB0]
000070a59add9362  vmovaps xmm13, [rsp+0xC0]
000070a59add936b  vmovaps xmm14, [rsp+0xD0]
000070a59add9374  vmovaps xmm15, [rsp+0xE0]
000070a59add937d  add rsp, 0xF0
000070a59add9384  pop r11
000070a59add9386  pop r10
000070a59add9388  pop r9
000070a59add938a  pop r8
000070a59add938c  pop rsi
000070a59add938d  pop rdi
000070a59add938e  pop rdx
000070a59add938f  pop rcx
000070a59add9390  pop rax
000070a59add9391  add rsp, 0x08
000070a59add9395  jmp 0x000070A59ADD6BBF
000070a59add939a  call 0x000070A59ACE5820
000070a59add939f  jmp 0x000070A59ADD6BCC
000070a59add93a4  call 0x000070A59ACE45A0
000070a59add93a9  jmp 0x000070A59ADD6BD9
000070a59add93ae  sub rsp, 0x08
000070a59add93b2  push rax
000070a59add93b3  push rcx
000070a59add93b4  push rdx
000070a59add93b5  push rdi
000070a59add93b6  push rsi
000070a59add93b7  push r8
000070a59add93b9  push r9
000070a59add93bb  push r10
000070a59add93bd  push r11
000070a59add93bf  sub rsp, 0xF0
000070a59add93c6  vmovaps [rsp], xmm0
000070a59add93cb  vmovaps [rsp+0x10], xmm1
000070a59add93d1  vmovaps [rsp+0x20], xmm2
000070a59add93d7  vmovaps [rsp+0x30], xmm3
000070a59add93dd  vmovaps [rsp+0x40], xmm4
000070a59add93e3  vmovaps [rsp+0x50], xmm5
000070a59add93e9  vmovaps [rsp+0x60], xmm6
000070a59add93ef  vmovaps [rsp+0x70], xmm7
000070a59add93f5  vmovaps [rsp+0x80], xmm8
000070a59add93fe  vmovaps [rsp+0x90], xmm9
000070a59add9407  vmovaps [rsp+0xA0], xmm11
000070a59add9410  vmovaps [rsp+0xB0], xmm12
000070a59add9419  vmovaps [rsp+0xC0], xmm13
000070a59add9422  vmovaps [rsp+0xD0], xmm14
000070a59add942b  vmovaps [rsp+0xE0], xmm15
000070a59add9434  sub rsp, 0x40
000070a59add9438  lea rdi, [rsp]
000070a59add943c  lea rsi, [rsp+0x10]
000070a59add9441  lea rdx, [rsp+0x20]
000070a59add9446  lea rcx, [rsp+0x30]
000070a59add944b  mov r8d, 0x00
000070a59add9451  lea r9, [r15+0x3A8]
000070a59add9458  movaps [rdi], xmm10
000070a59add945c  movaps [rsi], xmm8
000070a59add9460  movaps [rdx], xmm1
000070a59add9463  movaps [rcx], xmm13
000070a59add9467  mov rax, 0x622906D8FA50
000070a59add9471  call rax
000070a59add9473  movaps xmm10, [rsp]
000070a59add9478  add rsp, 0x40
000070a59add947c  vmovaps xmm0, [rsp]
000070a59add9481  vmovaps xmm1, [rsp+0x10]
000070a59add9487  vmovaps xmm2, [rsp+0x20]
000070a59add948d  vmovaps xmm3, [rsp+0x30]
000070a59add9493  vmovaps xmm4, [rsp+0x40]
000070a59add9499  vmovaps xmm5, [rsp+0x50]
000070a59add949f  vmovaps xmm6, [rsp+0x60]
000070a59add94a5  vmovaps xmm7, [rsp+0x70]
000070a59add94ab  vmovaps xmm8, [rsp+0x80]
000070a59add94b4  vmovaps xmm9, [rsp+0x90]
000070a59add94bd  vmovaps xmm11, [rsp+0xA0]
000070a59add94c6  vmovaps xmm12, [rsp+0xB0]
000070a59add94cf  vmovaps xmm13, [rsp+0xC0]
000070a59add94d8  vmovaps xmm14, [rsp+0xD0]
000070a59add94e1  vmovaps xmm15, [rsp+0xE0]
000070a59add94ea  add rsp, 0xF0
000070a59add94f1  pop r11
000070a59add94f3  pop r10
000070a59add94f5  pop r9
000070a59add94f7  pop r8
000070a59add94f9  pop rsi
000070a59add94fa  pop rdi
000070a59add94fb  pop rdx
000070a59add94fc  pop rcx
000070a59add94fd  pop rax
000070a59add94fe  add rsp, 0x08
000070a59add9502  jmp 0x000070A59ADD6C0F
000070a59add9507  call 0x000070A59ACD64F0
000070a59add950c  jmp 0x000070A59ADD6C21
000070a59add9511  sub rsp, 0x08
000070a59add9515  push rax
000070a59add9516  push rcx
000070a59add9517  push rdx
000070a59add9518  push rdi
000070a59add9519  push rsi
000070a59add951a  push r8
000070a59add951c  push r9
000070a59add951e  push r10
000070a59add9520  push r11
000070a59add9522  sub rsp, 0xF0
000070a59add9529  vmovaps [rsp], xmm0
000070a59add952e  vmovaps [rsp+0x10], xmm1
000070a59add9534  vmovaps [rsp+0x20], xmm2
000070a59add953a  vmovaps [rsp+0x30], xmm3
000070a59add9540  vmovaps [rsp+0x40], xmm4
000070a59add9546  vmovaps [rsp+0x50], xmm5
000070a59add954c  vmovaps [rsp+0x60], xmm6
000070a59add9552  vmovaps [rsp+0x70], xmm7
000070a59add9558  vmovaps [rsp+0x80], xmm8
000070a59add9561  vmovaps [rsp+0x90], xmm10
000070a59add956a  vmovaps [rsp+0xA0], xmm11
000070a59add9573  vmovaps [rsp+0xB0], xmm12
000070a59add957c  vmovaps [rsp+0xC0], xmm13
000070a59add9585  vmovaps [rsp+0xD0], xmm14
000070a59add958e  vmovaps [rsp+0xE0], xmm15
000070a59add9597  sub rsp, 0x40
000070a59add959b  lea rdi, [rsp]
000070a59add959f  lea rsi, [rsp+0x10]
000070a59add95a4  lea rdx, [rsp+0x20]
000070a59add95a9  lea rcx, [rsp+0x30]
000070a59add95ae  mov r8d, 0x00
000070a59add95b4  lea r9, [r15+0x3A8]
000070a59add95bb  movaps [rdi], xmm9
000070a59add95bf  movaps [rsi], xmm7
000070a59add95c2  movaps [rdx], xmm14
000070a59add95c6  movaps [rcx], xmm13
000070a59add95ca  mov rax, 0x622906D8FA50
000070a59add95d4  call rax
000070a59add95d6  movaps xmm9, [rsp]
000070a59add95db  add rsp, 0x40
000070a59add95df  vmovaps xmm0, [rsp]
000070a59add95e4  vmovaps xmm1, [rsp+0x10]
000070a59add95ea  vmovaps xmm2, [rsp+0x20]
000070a59add95f0  vmovaps xmm3, [rsp+0x30]
000070a59add95f6  vmovaps xmm4, [rsp+0x40]
000070a59add95fc  vmovaps xmm5, [rsp+0x50]
000070a59add9602  vmovaps xmm6, [rsp+0x60]
000070a59add9608  vmovaps xmm7, [rsp+0x70]
000070a59add960e  vmovaps xmm8, [rsp+0x80]
000070a59add9617  vmovaps xmm10, [rsp+0x90]
000070a59add9620  vmovaps xmm11, [rsp+0xA0]
000070a59add9629  vmovaps xmm12, [rsp+0xB0]
000070a59add9632  vmovaps xmm13, [rsp+0xC0]
000070a59add963b  vmovaps xmm14, [rsp+0xD0]
000070a59add9644  vmovaps xmm15, [rsp+0xE0]
000070a59add964d  add rsp, 0xF0
000070a59add9654  pop r11
000070a59add9656  pop r10
000070a59add9658  pop r9
000070a59add965a  pop r8
000070a59add965c  pop rsi
000070a59add965d  pop rdi
000070a59add965e  pop rdx
000070a59add965f  pop rcx
000070a59add9660  pop rax
000070a59add9661  add rsp, 0x08
000070a59add9665  jmp 0x000070A59ADD6C4F
000070a59add966a  sub rsp, 0x08
000070a59add966e  push rax
000070a59add966f  push rcx
000070a59add9670  push rdx
000070a59add9671  push rdi
000070a59add9672  push rsi
000070a59add9673  push r8
000070a59add9675  push r9
000070a59add9677  push r10
000070a59add9679  push r11
000070a59add967b  sub rsp, 0xF0
000070a59add9682  vmovaps [rsp], xmm0
000070a59add9687  vmovaps [rsp+0x10], xmm1
000070a59add968d  vmovaps [rsp+0x20], xmm2
000070a59add9693  vmovaps [rsp+0x30], xmm3
000070a59add9699  vmovaps [rsp+0x40], xmm4
000070a59add969f  vmovaps [rsp+0x50], xmm5
000070a59add96a5  vmovaps [rsp+0x60], xmm6
000070a59add96ab  vmovaps [rsp+0x70], xmm7
000070a59add96b1  vmovaps [rsp+0x80], xmm8
000070a59add96ba  vmovaps [rsp+0x90], xmm9
000070a59add96c3  vmovaps [rsp+0xA0], xmm10
000070a59add96cc  vmovaps [rsp+0xB0], xmm11
000070a59add96d5  vmovaps [rsp+0xC0], xmm12
000070a59add96de  vmovaps [rsp+0xD0], xmm14
000070a59add96e7  vmovaps [rsp+0xE0], xmm15
000070a59add96f0  sub rsp, 0x40
000070a59add96f4  lea rdi, [rsp]
000070a59add96f8  lea rsi, [rsp+0x10]
000070a59add96fd  lea rdx, [rsp+0x20]
000070a59add9702  lea rcx, [rsp+0x30]
000070a59add9707  mov r8d, 0x00
000070a59add970d  lea r9, [r15+0x3A8]
000070a59add9714  movaps [rdi], xmm13
000070a59add9718  movaps [rsi], xmm12
000070a59add971c  movaps [rdx], xmm15
000070a59add9720  movaps [rcx], xmm14
000070a59add9724  mov rax, 0x622906D8FA50
000070a59add972e  call rax
000070a59add9730  movaps xmm13, [rsp]
000070a59add9735  add rsp, 0x40
000070a59add9739  vmovaps xmm0, [rsp]
000070a59add973e  vmovaps xmm1, [rsp+0x10]
000070a59add9744  vmovaps xmm2, [rsp+0x20]
000070a59add974a  vmovaps xmm3, [rsp+0x30]
000070a59add9750  vmovaps xmm4, [rsp+0x40]
000070a59add9756  vmovaps xmm5, [rsp+0x50]
000070a59add975c  vmovaps xmm6, [rsp+0x60]
000070a59add9762  vmovaps xmm7, [rsp+0x70]
000070a59add9768  vmovaps xmm8, [rsp+0x80]
000070a59add9771  vmovaps xmm9, [rsp+0x90]
000070a59add977a  vmovaps xmm10, [rsp+0xA0]
000070a59add9783  vmovaps xmm11, [rsp+0xB0]
000070a59add978c  vmovaps xmm12, [rsp+0xC0]
000070a59add9795  vmovaps xmm14, [rsp+0xD0]
000070a59add979e  vmovaps xmm15, [rsp+0xE0]
000070a59add97a7  add rsp, 0xF0
000070a59add97ae  pop r11
000070a59add97b0  pop r10
000070a59add97b2  pop r9
000070a59add97b4  pop r8
000070a59add97b6  pop rsi
000070a59add97b7  pop rdi
000070a59add97b8  pop rdx
000070a59add97b9  pop rcx
000070a59add97ba  pop rax
000070a59add97bb  add rsp, 0x08
000070a59add97bf  jmp 0x000070A59ADD6C7D
000070a59add97c4  sub rsp, 0x08
000070a59add97c8  push rax
000070a59add97c9  push rcx
000070a59add97ca  push rdx
000070a59add97cb  push rdi
000070a59add97cc  push rsi
000070a59add97cd  push r8
000070a59add97cf  push r9
000070a59add97d1  push r10
000070a59add97d3  push r11
000070a59add97d5  sub rsp, 0xF0
000070a59add97dc  vmovaps [rsp], xmm0
000070a59add97e1  vmovaps [rsp+0x10], xmm1
000070a59add97e7  vmovaps [rsp+0x20], xmm2
000070a59add97ed  vmovaps [rsp+0x30], xmm3
000070a59add97f3  vmovaps [rsp+0x40], xmm4
000070a59add97f9  vmovaps [rsp+0x50], xmm5
000070a59add97ff  vmovaps [rsp+0x60], xmm6
000070a59add9805  vmovaps [rsp+0x70], xmm7
000070a59add980b  vmovaps [rsp+0x80], xmm8
000070a59add9814  vmovaps [rsp+0x90], xmm9
000070a59add981d  vmovaps [rsp+0xA0], xmm10
000070a59add9826  vmovaps [rsp+0xB0], xmm11
000070a59add982f  vmovaps [rsp+0xC0], xmm12
000070a59add9838  vmovaps [rsp+0xD0], xmm13
000070a59add9841  vmovaps [rsp+0xE0], xmm15
000070a59add984a  sub rsp, 0x40
000070a59add984e  lea rdi, [rsp]
000070a59add9852  lea rsi, [rsp+0x10]
000070a59add9857  lea rdx, [rsp+0x20]
000070a59add985c  lea rcx, [rsp+0x30]
000070a59add9861  mov r8d, 0x00
000070a59add9867  lea r9, [r15+0x3A8]
000070a59add986e  movaps [rdi], xmm14
000070a59add9872  movaps [rsi], xmm11
000070a59add9876  movaps [rdx], xmm1
000070a59add9879  movaps [rcx], xmm15
000070a59add987d  mov rax, 0x622906D8FA50
000070a59add9887  call rax
000070a59add9889  movaps xmm14, [rsp]
000070a59add988e  add rsp, 0x40
000070a59add9892  vmovaps xmm0, [rsp]
000070a59add9897  vmovaps xmm1, [rsp+0x10]
000070a59add989d  vmovaps xmm2, [rsp+0x20]
000070a59add98a3  vmovaps xmm3, [rsp+0x30]
000070a59add98a9  vmovaps xmm4, [rsp+0x40]
000070a59add98af  vmovaps xmm5, [rsp+0x50]
000070a59add98b5  vmovaps xmm6, [rsp+0x60]
000070a59add98bb  vmovaps xmm7, [rsp+0x70]
000070a59add98c1  vmovaps xmm8, [rsp+0x80]
000070a59add98ca  vmovaps xmm9, [rsp+0x90]
000070a59add98d3  vmovaps xmm10, [rsp+0xA0]
000070a59add98dc  vmovaps xmm11, [rsp+0xB0]
000070a59add98e5  vmovaps xmm12, [rsp+0xC0]
000070a59add98ee  vmovaps xmm13, [rsp+0xD0]
000070a59add98f7  vmovaps xmm15, [rsp+0xE0]
000070a59add9900  add rsp, 0xF0
000070a59add9907  pop r11
000070a59add9909  pop r10
000070a59add990b  pop r9
000070a59add990d  pop r8
000070a59add990f  pop rsi
000070a59add9910  pop rdi
000070a59add9911  pop rdx
000070a59add9912  pop rcx
000070a59add9913  pop rax
000070a59add9914  add rsp, 0x08
000070a59add9918  jmp 0x000070A59ADD6CAB
000070a59add991d  call 0x000070A59ACACF70
000070a59add9922  jmp 0x000070A59ADD6CB9
000070a59add9927  call 0x000070A59AC0C380
000070a59add992c  jmp 0x000070A59ADD6CC3
000070a59add9931  call 0x000070A59AC08C20
000070a59add9936  jmp 0x000070A59ADD6CCD
000070a59add993b  call 0x000070A59AC0D600
000070a59add9940  jmp 0x000070A59ADD6CD7
000070a59add9945  int3
000070a59add9946  nop [rax+rax*1], ax
000070a59add994f  nop
000070a59add9950  mov eax, [r15+0x48]
000070a59add9954  lea r14d, [eax+0x01]
000070a59add9959  mov [rsp+0x10], r14d
000070a59add995e  mov r14d, r14d
000070a59add9961  mov [r15+0x48], r14
000070a59add9965  xor eax, eax
000070a59add9967  mov r14d, [rsp+0x10]
000070a59add996c  cmp r14d, 0x1F4
000070a59add9973  cmc
000070a59add9974  lahf
000070a59add9975  seto al
000070a59add9978  mov [r15+0x108], eax
000070a59add997f  mov eax, [r15+0x108]
000070a59add9986  sahf
000070a59add9987  jnz 0x000070A59ADD99B9
000070a59add9989  cmp dword ptr [r15+0x318], 0x00
000070a59add9991  jz 0x000070A59ADDD2E0
000070a59add9997  nop [rax+rax*1], ax
000070a59add99a0  nop [rax+rax*1], eax
000070a59add99a8  mov eax, 0x410670
000070a59add99ad  mov [r15+0x100], rax
000070a59add99b4  jmp 0x000070A59ABFE110
000070a59add99b9  cmp dword ptr [r15+0x318], 0x00
000070a59add99c1  jz 0x000070A59ADD99F0
000070a59add99c7  nop [rax+rax*1], ax
000070a59add99d0  nop [rax+rax*1], eax
000070a59add99d8  mov eax, 0x4104EC
000070a59add99dd  mov [r15+0x100], rax
000070a59add99e4  jmp 0x000070A59ABFE110
000070a59add99e9  int3
000070a59add99ea  int3
000070a59add99eb  nop [rax+rax*1], eax
000070a59add99f0  mov rax, [r15+0x40]
000070a59add99f4  vxorps xmm1, xmm1, xmm1
000070a59add99f8  vpbroadcastq xmm1, xmm1
000070a59add99fd  vxorps xmm15, xmm15, xmm15
000070a59add9a02  vpbroadcastq xmm15, xmm15
000070a59add9a07  lea r14, [rax+0x30]
000070a59add9a0b  mov r12, [r13+r14*1]
000070a59add9a10  lea r14, [rax+0x38]
000070a59add9a14  mov r11, [r13+r14*1]
000070a59add9a19  movq xmm14, r12
000070a59add9a1e  movq xmm13, r11
000070a59add9a23  movq xmm14, xmm14
000070a59add9a28  movq xmm13, xmm13
000070a59add9a2d  vmovaps [rsp+0x10], xmm13
000070a59add9a33  movq xmm13, xmm13
000070a59add9a38  movaps [r15+0x270], xmm13
000070a59add9a40  movaps xmm13, [r15+0x160]
000070a59add9a48  vmovaps [rsp+0x20], xmm13
000070a59add9a4e  vmovaps xmm12, [rsp+0x20]
000070a59add9a54  por xmm13, xmm12
000070a59add9a59  lea r14, [rax+0x20]
000070a59add9a5d  mov r12, [r13+r14*1]
000070a59add9a62  lea r14, [rax+0x28]
000070a59add9a66  mov r11, [r13+r14*1]
000070a59add9a6b  movq xmm12, r12
000070a59add9a70  movq xmm11, r11
000070a59add9a75  movq xmm12, xmm12
000070a59add9a7a  movq xmm11, xmm11
000070a59add9a7f  movaps xmm10, [r15+0x2D0]
000070a59add9a87  vmovaps [rsp+0x20], xmm10
000070a59add9a8d  vmovaps xmm9, [rsp+0x20]
000070a59add9a93  por xmm10, xmm9
000070a59add9a98  movaps xmm9, [r15+0x300]
000070a59add9aa0  vmovaps [rsp+0x20], xmm9
000070a59add9aa6  vmovaps xmm8, [rsp+0x20]
000070a59add9aac  por xmm9, xmm8
000070a59add9ab1  movaps xmm8, [r15+0x2B0]
000070a59add9ab9  vmovaps [rsp+0x20], xmm8
000070a59add9abf  vmovaps xmm7, [rsp+0x20]
000070a59add9ac5  por xmm8, xmm7
000070a59add9aca  movaps xmm7, [r15+0x180]
000070a59add9ad2  vmovaps [rsp+0x20], xmm7
000070a59add9ad8  vmovaps xmm6, [rsp+0x20]
000070a59add9ade  por xmm7, xmm6
000070a59add9ae2  lea r14, [rax+0x10]
000070a59add9ae6  mov r12, [r13+r14*1]
000070a59add9aeb  lea r14, [rax+0x18]
000070a59add9aef  mov r11, [r13+r14*1]
000070a59add9af4  movq xmm6, r12
000070a59add9af9  movq xmm5, r11
000070a59add9afe  movq xmm6, xmm6
000070a59add9b02  movq xmm5, xmm5
000070a59add9b06  movaps xmm4, [r15+0x200]
000070a59add9b0e  vmovaps [rsp+0x20], xmm4
000070a59add9b14  vmovaps xmm3, [rsp+0x20]
000070a59add9b1a  por xmm4, xmm3
000070a59add9b1e  movaps xmm3, [r15+0x1F0]
000070a59add9b26  vmovaps [rsp+0x20], xmm3
000070a59add9b2c  vmovaps xmm2, [rsp+0x20]
000070a59add9b32  por xmm3, xmm2
000070a59add9b36  movaps xmm2, [r15+0x2E0]
000070a59add9b3e  vmovaps [rsp+0x20], xmm2
000070a59add9b44  vmovaps [rsp+0x30], xmm1
000070a59add9b4a  vmovaps xmm1, [rsp+0x20]
000070a59add9b50  por xmm2, xmm1
000070a59add9b54  movaps xmm1, [r15+0x2A0]
000070a59add9b5c  vmovaps [rsp+0x20], xmm1
000070a59add9b62  vmovaps [rsp+0x40], xmm15
000070a59add9b68  vmovaps xmm15, [rsp+0x20]
000070a59add9b6e  por xmm1, xmm15
000070a59add9b73  movaps xmm15, [r15+0x280]
000070a59add9b7b  vmovaps [rsp+0x20], xmm15
000070a59add9b81  vmovaps [rsp+0x50], xmm1
000070a59add9b87  vmovaps xmm1, [rsp+0x20]
000070a59add9b8d  por xmm15, xmm1
000070a59add9b92  movaps xmm1, [r15+0x1C0]
000070a59add9b9a  vmovaps [rsp+0x20], xmm1
000070a59add9ba0  vmovaps [rsp+0x60], xmm15
000070a59add9ba6  vmovaps xmm15, [rsp+0x20]
000070a59add9bac  por xmm1, xmm15
000070a59add9bb1  movaps xmm15, [r15+0x210]
000070a59add9bb9  vmovaps [rsp+0x20], xmm15
000070a59add9bbf  vmovaps [rsp+0x70], xmm1
000070a59add9bc5  vmovaps xmm1, [rsp+0x20]
000070a59add9bcb  por xmm15, xmm1
000070a59add9bd0  mov r14, [r13+rax*1]
000070a59add9bd5  vmovq xmm1, r14
000070a59add9bda  vpbroadcastq xmm1, xmm1
000070a59add9bdf  vmovaps [rsp+0x20], xmm1
000070a59add9be5  vxorps xmm1, xmm1, xmm1
000070a59add9be9  vpbroadcastq xmm1, xmm1
000070a59add9bee  mov r14, [r15+0xF8]
000070a59add9bf5  vmovaps [rsp+0x80], xmm1
000070a59add9bfe  movups xmm1, [r13+r14*1]
000070a59add9c04  vmovaps [rsp+0x90], xmm1
000070a59add9c0d  vxorps xmm1, xmm1, xmm1
000070a59add9c11  vpbroadcastq xmm1, xmm1
000070a59add9c16  lea r12, [rax+0x08]
000070a59add9c1a  mov rax, [r13+r12*1]
000070a59add9c1f  vmovaps [rsp+0xA0], xmm1
000070a59add9c28  movq xmm1, rax
000070a59add9c2d  movaps [r15+0x240], xmm1
000070a59add9c35  mov rax, [r15+0x50]
000070a59add9c39  mov [r15+0x60], rax
000070a59add9c3d  mov qword ptr [r15+0x58], 0x40
000070a59add9c45  vmovaps xmm1, [rsp+0x30]
000070a59add9c4b  vmovaps [rsp+0x30], xmm15
000070a59add9c51  vmovaps xmm15, [rsp+0x90]
000070a59add9c5a  vmovaps [rsp+0x90], xmm14
000070a59add9c63  vmovaps xmm14, [rsp+0x20]
000070a59add9c69  vmovaps [rsp+0x20], xmm13
000070a59add9c6f  vmovaps [rsp+0xB0], xmm12
000070a59add9c78  movaps xmm13, xmm1
000070a59add9c7c  vfmadd231pd xmm13, xmm15, xmm14
000070a59add9c81  vcmppd xmm12, xmm13, xmm13, 0x03
000070a59add9c87  vptest xmm12, xmm12
000070a59add9c8c  jnz 0x000070A59ADDA72F
000070a59add9c92  movaps xmm1, [r15+0x250]
000070a59add9c9a  vmovaps xmm15, [rsp+0x40]
000070a59add9ca0  vmovaps [rsp+0x40], xmm13
000070a59add9ca6  movaps xmm12, xmm15
000070a59add9caa  vfmadd231pd xmm12, xmm1, xmm14
000070a59add9caf  vcmppd xmm13, xmm12, xmm12, 0x03
000070a59add9cb5  vptest xmm13, xmm13
000070a59add9cba  jnz 0x000070A59ADDA888
000070a59add9cc0  movaps xmm15, [r15+0x1E0]
000070a59add9cc8  vmovaps [rsp+0xC0], xmm15
000070a59add9cd1  vmovaps xmm13, [rsp+0xC0]
000070a59add9cda  por xmm15, xmm13
000070a59add9cdf  movaps xmm13, [r15+0x1D0]
000070a59add9ce7  vmovaps [rsp+0xC0], xmm13
000070a59add9cf0  vmovaps [rsp+0xD0], xmm1
000070a59add9cf9  vmovaps xmm1, [rsp+0xC0]
000070a59add9d02  por xmm13, xmm1
000070a59add9d07  movaps xmm1, [r15+0x2C0]
000070a59add9d0f  vmovaps [rsp+0xC0], xmm1
000070a59add9d18  vmovaps [rsp+0xE0], xmm15
000070a59add9d21  vmovaps xmm15, [rsp+0xC0]
000070a59add9d2a  por xmm1, xmm15
000070a59add9d2f  movaps xmm15, [r15+0x290]
000070a59add9d37  vmovaps [rsp+0xC0], xmm15
000070a59add9d40  vmovaps [rsp+0xF0], xmm1
000070a59add9d49  vmovaps xmm1, [rsp+0xC0]
000070a59add9d52  por xmm15, xmm1
000070a59add9d57  movaps xmm1, [r15+0x260]
000070a59add9d5f  vmovaps [rsp+0xC0], xmm1
000070a59add9d68  vmovaps [rsp+0x100], xmm15
000070a59add9d71  vmovaps xmm15, [rsp+0xC0]
000070a59add9d7a  por xmm1, xmm15
000070a59add9d7f  vmovaps xmm15, [rsp+0xD0]
000070a59add9d88  vmovaps [rsp+0xC0], xmm1
000070a59add9d91  vmovaps xmm1, [rsp+0xD0]
000070a59add9d9a  por xmm15, xmm1
000070a59add9d9f  lea r12, [r14+0xC0]
000070a59add9da6  movups xmm1, [r13+r12*1]
000070a59add9dac  mov [rsp+0xD0], rax
000070a59add9db4  xor eax, eax
000070a59add9db6  mov r12d, 0x40
000070a59add9dbc  mov r11d, 0x200
000070a59add9dc2  cmp r12, r11
000070a59add9dc5  cmc
000070a59add9dc6  lahf
000070a59add9dc7  seto al
000070a59add9dca  mov [r15+0x108], eax
000070a59add9dd1  vmovaps [rsp+0x110], xmm1
000070a59add9dda  vmovaps xmm1, [rsp+0x80]
000070a59add9de3  vmovaps [rsp+0x80], xmm15
000070a59add9dec  vmovaps xmm15, [rsp+0x110]
000070a59add9df5  vmovaps [rsp+0x110], xmm13
000070a59add9dfe  vmovaps [rsp+0x120], xmm12
000070a59add9e07  movaps xmm13, xmm1
000070a59add9e0b  vfmadd231pd xmm13, xmm15, xmm14
000070a59add9e10  vcmppd xmm12, xmm13, xmm13, 0x03
000070a59add9e16  vptest xmm12, xmm12
000070a59add9e1b  jnz 0x000070A59ADDA9EB
000070a59add9e21  lea rax, [r14+0xB0]
000070a59add9e28  movups xmm1, [r13+rax*1]
000070a59add9e2e  vmovaps xmm15, [rsp+0xA0]
000070a59add9e37  vmovaps [rsp+0xA0], xmm13
000070a59add9e40  movaps xmm12, xmm15
000070a59add9e44  vfmadd231pd xmm12, xmm1, xmm14
000070a59add9e49  vcmppd xmm13, xmm12, xmm12, 0x03
000070a59add9e4f  vptest xmm13, xmm13
000070a59add9e54  jnz 0x000070A59ADDAB4E
000070a59add9e5a  vmovaps xmm1, [rsp+0x30]
000070a59add9e60  vmovaps xmm15, [rsp+0x30]
000070a59add9e66  por xmm1, xmm15
000070a59add9e6b  movaps [r15+0x210], xmm1
000070a59add9e73  vmovaps xmm15, [rsp+0x70]
000070a59add9e79  vmovaps xmm14, [rsp+0x70]
000070a59add9e7f  por xmm15, xmm14
000070a59add9e84  movaps [r15+0x1C0], xmm15
000070a59add9e8c  vmovaps xmm14, [rsp+0x60]
000070a59add9e92  vmovaps xmm13, [rsp+0x60]
000070a59add9e98  por xmm14, xmm13
000070a59add9e9d  movaps [r15+0x280], xmm14
000070a59add9ea5  vmovaps xmm13, [rsp+0x50]
000070a59add9eab  vmovaps [rsp+0x30], xmm1
000070a59add9eb1  vmovaps xmm1, [rsp+0x50]
000070a59add9eb7  por xmm13, xmm1
000070a59add9ebc  movaps [r15+0x2A0], xmm13
000070a59add9ec4  vmovaps [rsp+0x50], xmm2
000070a59add9eca  vmovaps xmm1, [rsp+0x50]
000070a59add9ed0  por xmm2, xmm1
000070a59add9ed4  movaps [r15+0x2E0], xmm2
000070a59add9edc  vmovaps [rsp+0x50], xmm3
000070a59add9ee2  vmovaps xmm1, [rsp+0x50]
000070a59add9ee8  por xmm3, xmm1
000070a59add9eec  movaps [r15+0x1F0], xmm3
000070a59add9ef4  vmovaps xmm1, [rsp+0x80]
000070a59add9efd  vmovaps [rsp+0x50], xmm15
000070a59add9f03  vmovaps xmm15, [rsp+0x80]
000070a59add9f0c  por xmm1, xmm15
000070a59add9f11  movaps [r15+0x250], xmm1
000070a59add9f19  vmovaps xmm1, [rsp+0xC0]
000070a59add9f22  vmovaps xmm15, [rsp+0xC0]
000070a59add9f2b  por xmm1, xmm15
000070a59add9f30  movaps [r15+0x260], xmm1
000070a59add9f38  vmovaps xmm15, [rsp+0x100]
000070a59add9f41  vmovaps [rsp+0x60], xmm1
000070a59add9f47  vmovaps xmm1, [rsp+0x100]
000070a59add9f50  por xmm15, xmm1
000070a59add9f55  movaps [r15+0x290], xmm15
000070a59add9f5d  vmovaps xmm1, [rsp+0xF0]
000070a59add9f66  vmovaps [rsp+0x70], xmm15
000070a59add9f6c  vmovaps xmm15, [rsp+0xF0]
000070a59add9f75  por xmm1, xmm15
000070a59add9f7a  movaps [r15+0x2C0], xmm1
000070a59add9f82  movq xmm15, qword ptr [r15+0x240]
000070a59add9f8b  vmovaps [rsp+0x80], xmm15
000070a59add9f94  vpermilpd xmm15, xmm15, 0x00
000070a59add9f9a  vmovaps [rsp+0xC0], xmm1
000070a59add9fa3  vmovaps xmm1, [rsp+0x40]
000070a59add9fa9  vmovaps [rsp+0x40], xmm15
000070a59add9faf  vmovaps xmm15, [rsp+0x30]
000070a59add9fb5  vmovaps [rsp+0x30], xmm14
000070a59add9fbb  vmovaps xmm14, [rsp+0x40]
000070a59add9fc1  vmovaps [rsp+0x40], xmm13
000070a59add9fc7  vmovaps [rsp+0xF0], xmm12
000070a59add9fd0  movaps xmm13, xmm1
000070a59add9fd4  vfmadd231pd xmm13, xmm15, xmm14
000070a59add9fd9  vcmppd xmm12, xmm13, xmm13, 0x03
000070a59add9fdf  vptest xmm12, xmm12
000070a59add9fe4  jnz 0x000070A59ADDACA7
000070a59add9fea  vmovaps xmm1, [rsp+0x80]
000070a59add9ff3  vpermilpd xmm1, xmm1, 0x00
000070a59add9ff9  vmovaps xmm15, [rsp+0xA0]
000070a59adda002  movaps xmm14, xmm15
000070a59adda006  vfmadd231pd xmm14, xmm2, xmm1
000070a59adda00b  vcmppd xmm12, xmm14, xmm14, 0x03
000070a59adda011  vptest xmm12, xmm12
000070a59adda016  jnz 0x000070A59ADDAE00
000070a59adda01c  vmovaps xmm1, [rsp+0x80]
000070a59adda025  vpermilpd xmm1, xmm1, 0x00
000070a59adda02b  vmovaps xmm15, [rsp+0x120]
000070a59adda034  vmovaps xmm12, [rsp+0x50]
000070a59adda03a  vmovaps [rsp+0x50], xmm14
000070a59adda040  movaps xmm2, xmm15
000070a59adda044  vfmadd231pd xmm2, xmm12, xmm1
000070a59adda049  vcmppd xmm14, xmm2, xmm2, 0x03
000070a59adda04e  vptest xmm14, xmm14
000070a59adda053  jnz 0x000070A59ADDAF58
000070a59adda059  vmovaps xmm1, [rsp+0x110]
000070a59adda062  vmovaps xmm15, [rsp+0x110]
000070a59adda06b  por xmm1, xmm15
000070a59adda070  movaps [r15+0x1D0], xmm1
000070a59adda078  vmovaps xmm15, [rsp+0x80]
000070a59adda081  vpermilpd xmm15, xmm15, 0x00
000070a59adda087  vmovaps xmm14, [rsp+0xF0]
000070a59adda090  vmovaps [rsp+0x80], xmm1
000070a59adda099  movaps xmm12, xmm14
000070a59adda09d  vfmadd231pd xmm12, xmm3, xmm15
000070a59adda0a2  vcmppd xmm1, xmm12, xmm12, 0x03
000070a59adda0a8  vptest xmm1, xmm1
000070a59adda0ad  jnz 0x000070A59ADDB0AF
000070a59adda0b3  vmovaps [rsp+0xA0], xmm4
000070a59adda0bc  vmovaps xmm1, [rsp+0xA0]
000070a59adda0c5  por xmm4, xmm1
000070a59adda0c9  movaps [r15+0x200], xmm4
000070a59adda0d1  vmovaps xmm1, [rsp+0xE0]
000070a59adda0da  vmovaps xmm15, [rsp+0xE0]
000070a59adda0e3  por xmm1, xmm15
000070a59adda0e8  movaps [r15+0x1E0], xmm1
000070a59adda0f0  vmovaps [rsp+0xA0], xmm8
000070a59adda0f9  vmovaps xmm1, [rsp+0xA0]
000070a59adda102  por xmm8, xmm1
000070a59adda107  movaps [r15+0x2B0], xmm8
000070a59adda10f  vmovaps [rsp+0xA0], xmm9
000070a59adda118  vmovaps xmm1, [rsp+0xA0]
000070a59adda121  por xmm9, xmm1
000070a59adda126  movaps [r15+0x300], xmm9
000070a59adda12e  vmovaps [rsp+0xA0], xmm6
000070a59adda137  vpermilpd xmm6, xmm6, 0x00
000070a59adda13d  vmovaps xmm14, [rsp+0x60]
000070a59adda143  movaps xmm9, xmm13
000070a59adda147  vfmadd231pd xmm9, xmm14, xmm6
000070a59adda14c  vcmppd xmm3, xmm9, xmm9, 0x03
000070a59adda152  vptest xmm3, xmm3
000070a59adda157  jnz 0x000070A59ADDB208
000070a59adda15d  vmovaps xmm14, [rsp+0xA0]
000070a59adda166  vpermilpd xmm14, xmm14, 0x00
000070a59adda16c  vmovaps xmm13, [rsp+0x50]
000070a59adda172  vmovaps xmm6, [rsp+0xC0]
000070a59adda17b  vmovaps [rsp+0x50], xmm1
000070a59adda181  movaps xmm3, xmm13
000070a59adda185  vfmadd231pd xmm3, xmm6, xmm14
000070a59adda18a  vcmppd xmm1, xmm3, xmm3, 0x03
000070a59adda18f  vptest xmm1, xmm1
000070a59adda194  jnz 0x000070A59ADDB361
000070a59adda19a  vmovaps xmm1, [rsp+0xA0]
000070a59adda1a3  vpermilpd xmm1, xmm1, 0x00
000070a59adda1a9  vmovaps xmm14, [rsp+0x30]
000070a59adda1af  movaps xmm6, xmm2
000070a59adda1b2  vfmadd231pd xmm6, xmm14, xmm1
000070a59adda1b7  vcmppd xmm13, xmm6, xmm6, 0x03
000070a59adda1bc  vptest xmm13, xmm13
000070a59adda1c1  jnz 0x000070A59ADDB4B8
000070a59adda1c7  vmovaps xmm1, [rsp+0xA0]
000070a59adda1d0  vpermilpd xmm1, xmm1, 0x00
000070a59adda1d6  vmovaps xmm14, [rsp+0x80]
000070a59adda1df  movaps xmm13, xmm12
000070a59adda1e3  vfmadd231pd xmm13, xmm14, xmm1
000070a59adda1e8  vcmppd xmm2, xmm13, xmm13, 0x03
000070a59adda1ee  vptest xmm2, xmm2
000070a59adda1f3  jnz 0x000070A59ADDB60E
000070a59adda1f9  vmovaps [rsp+0x30], xmm7
000070a59adda1ff  vmovaps xmm1, [rsp+0x30]
000070a59adda205  por xmm7, xmm1
000070a59adda209  movaps [r15+0x180], xmm7
000070a59adda211  vmovaps [rsp+0x30], xmm10
000070a59adda217  vmovaps xmm1, [rsp+0x30]
000070a59adda21d  por xmm10, xmm1
000070a59adda222  movaps [r15+0x2D0], xmm10
000070a59adda22a  vmovaps [rsp+0x30], xmm5
000070a59adda230  vpermilpd xmm5, xmm5, 0x00
000070a59adda236  vmovaps xmm14, [rsp+0x50]
000070a59adda23c  movaps xmm12, xmm3
000070a59adda240  vfmadd231pd xmm12, xmm14, xmm5
000070a59adda245  vcmppd xmm10, xmm12, xmm12, 0x03
000070a59adda24b  vptest xmm10, xmm10
000070a59adda250  jnz 0x000070A59ADDB767
000070a59adda256  vmovaps xmm14, [rsp+0x30]
000070a59adda25c  vpermilpd xmm14, xmm14, 0x00
000070a59adda262  movaps xmm10, xmm9
000070a59adda266  vfmadd231pd xmm10, xmm7, xmm14
000070a59adda26b  vcmppd xmm5, xmm10, xmm10, 0x03
000070a59adda271  vptest xmm5, xmm5
000070a59adda276  jnz 0x000070A59ADDB8BF
000070a59adda27c  lea rax, [r14+0x80]
000070a59adda283  movups xmm14, [r13+rax*1]
000070a59adda289  movaps [r15+0x2F0], xmm14
000070a59adda291  vmovaps xmm9, [rsp+0x30]
000070a59adda297  vpermilpd xmm9, xmm9, 0x00
000070a59adda29d  vmovaps xmm7, [rsp+0x70]
000070a59adda2a3  movaps xmm5, xmm6
000070a59adda2a6  vfmadd231pd xmm5, xmm7, xmm9
000070a59adda2ab  vcmppd xmm3, xmm5, xmm5, 0x03
000070a59adda2b0  vptest xmm3, xmm3
000070a59adda2b5  jnz 0x000070A59ADDBA22
000070a59adda2bb  vmovaps xmm9, [rsp+0x30]
000070a59adda2c1  vpermilpd xmm9, xmm9, 0x00
000070a59adda2c7  movaps xmm7, xmm13
000070a59adda2cb  vfmadd231pd xmm7, xmm1, xmm9
000070a59adda2d0  vcmppd xmm6, xmm7, xmm7, 0x03
000070a59adda2d5  vptest xmm6, xmm6
000070a59adda2da  jnz 0x000070A59ADDBB78
000070a59adda2e0  vmovaps xmm1, [rsp+0x20]
000070a59adda2e6  vmovaps xmm13, [rsp+0x20]
000070a59adda2ec  por xmm1, xmm13
000070a59adda2f1  movaps [r15+0x160], xmm1
000070a59adda2f9  lea rax, [r14+0x40]
000070a59adda2fd  movups xmm13, [r13+rax*1]
000070a59adda303  lea rax, [r14+0x50]
000070a59adda307  movups xmm9, [r13+rax*1]
000070a59adda30d  movaps [r15+0x1B0], xmm13
000070a59adda315  movaps [r15+0x1A0], xmm9
000070a59adda31d  movaps xmm6, [r15+0x190]
000070a59adda325  vmovaps xmm3, [rsp+0xB0]
000070a59adda32e  vpermilpd xmm3, xmm3, 0x00
000070a59adda334  vmovaps [rsp+0x20], xmm1
000070a59adda33a  movaps xmm2, xmm12
000070a59adda33e  vfmadd231pd xmm2, xmm6, xmm3
000070a59adda343  vcmppd xmm1, xmm2, xmm2, 0x03
000070a59adda348  vptest xmm1, xmm1
000070a59adda34d  jnz 0x000070A59ADDBCE3
000070a59adda353  vmovaps xmm1, [rsp+0xB0]
000070a59adda35c  vpermilpd xmm1, xmm1, 0x00
000070a59adda362  vmovaps xmm12, [rsp+0x20]
000070a59adda368  movaps xmm6, xmm10
000070a59adda36c  vfmadd231pd xmm6, xmm12, xmm1
000070a59adda371  vcmppd xmm3, xmm6, xmm6, 0x03
000070a59adda376  vptest xmm3, xmm3
000070a59adda37b  jnz 0x000070A59ADDBE39
000070a59adda381  vmovaps xmm1, [rsp+0xB0]
000070a59adda38a  vpermilpd xmm1, xmm1, 0x00
000070a59adda390  vmovaps xmm12, [rsp+0x40]
000070a59adda396  movaps xmm10, xmm5
000070a59adda39a  vfmadd231pd xmm10, xmm12, xmm1
000070a59adda39f  vcmppd xmm3, xmm10, xmm10, 0x03
000070a59adda3a5  vptest xmm3, xmm3
000070a59adda3aa  jnz 0x000070A59ADDBF90
000070a59adda3b0  vmovaps xmm1, [rsp+0xB0]
000070a59adda3b9  vpermilpd xmm1, xmm1, 0x00
000070a59adda3bf  movaps xmm12, xmm7
000070a59adda3c3  vfmadd231pd xmm12, xmm15, xmm1
000070a59adda3c8  vcmppd xmm5, xmm12, xmm12, 0x03
000070a59adda3ce  vptest xmm5, xmm5
000070a59adda3d3  jnz 0x000070A59ADDC0E8
000070a59adda3d9  lea rax, [r14+0x60]
000070a59adda3dd  movups xmm1, [r13+rax*1]
000070a59adda3e3  lea rax, [r14+0x70]
000070a59adda3e7  movups xmm15, [r13+rax*1]
000070a59adda3ed  movaps [r15+0x150], xmm1
000070a59adda3f5  movaps [r15+0x120], xmm15
000070a59adda3fd  vmovaps [rsp+0x20], xmm11
000070a59adda403  vpermilpd xmm11, xmm11, 0x00
000070a59adda409  movaps xmm7, xmm2
000070a59adda40c  vfmadd231pd xmm7, xmm9, xmm11
000070a59adda411  vcmppd xmm5, xmm7, xmm7, 0x03
000070a59adda416  vptest xmm5, xmm5
000070a59adda41b  jnz 0x000070A59ADDC254
000070a59adda421  vmovaps xmm11, [rsp+0x20]
000070a59adda427  vpermilpd xmm11, xmm11, 0x00
000070a59adda42d  movaps xmm9, xmm6
000070a59adda431  vfmadd231pd xmm9, xmm1, xmm11
000070a59adda436  vcmppd xmm5, xmm9, xmm9, 0x03
000070a59adda43c  vptest xmm5, xmm5
000070a59adda441  jnz 0x000070A59ADDC3AB
000070a59adda447  vmovaps xmm1, [rsp+0x20]
000070a59adda44d  vpermilpd xmm1, xmm1, 0x00
000070a59adda453  movaps xmm11, xmm10
000070a59adda457  vfmadd231pd xmm11, xmm8, xmm1
000070a59adda45c  vcmppd xmm6, xmm11, xmm11, 0x03
000070a59adda462  vptest xmm6, xmm6
000070a59adda467  jnz 0x000070A59ADDC503
000070a59adda46d  vmovaps xmm1, [rsp+0x20]
000070a59adda473  vpermilpd xmm1, xmm1, 0x00
000070a59adda479  movaps xmm10, xmm12
000070a59adda47d  vfmadd231pd xmm10, xmm13, xmm1
000070a59adda482  vcmppd xmm8, xmm10, xmm10, 0x03
000070a59adda488  vptest xmm8, xmm8
000070a59adda48d  jnz 0x000070A59ADDC65C
000070a59adda493  lea rax, [r14+0x20]
000070a59adda497  movups xmm1, [r13+rax*1]
000070a59adda49d  lea rax, [r14+0x30]
000070a59adda4a1  movups xmm13, [r13+rax*1]
000070a59adda4a7  vmovaps xmm12, [rsp+0x90]
000070a59adda4b0  vpermilpd xmm12, xmm12, 0x00
000070a59adda4b6  movaps xmm8, xmm7
000070a59adda4ba  vfmadd231pd xmm8, xmm4, xmm12
000070a59adda4bf  vcmppd xmm6, xmm8, xmm8, 0x03
000070a59adda4c5  vptest xmm6, xmm6
000070a59adda4ca  jnz 0x000070A59ADDC7C9
000070a59adda4d0  vmovaps xmm12, [rsp+0x90]
000070a59adda4d9  vpermilpd xmm12, xmm12, 0x00
000070a59adda4df  movaps xmm7, xmm9
000070a59adda4e3  vfmadd231pd xmm7, xmm14, xmm12
000070a59adda4e8  vcmppd xmm6, xmm7, xmm7, 0x03
000070a59adda4ed  vptest xmm6, xmm6
000070a59adda4f2  jnz 0x000070A59ADDC921
000070a59adda4f8  vmovaps xmm14, [rsp+0x90]
000070a59adda501  vpermilpd xmm14, xmm14, 0x00
000070a59adda507  movaps xmm12, xmm11
000070a59adda50b  vfmadd231pd xmm12, xmm15, xmm14
000070a59adda510  vcmppd xmm9, xmm12, xmm12, 0x03
000070a59adda516  vptest xmm9, xmm9
000070a59adda51b  jnz 0x000070A59ADDCA79
000070a59adda521  vmovaps xmm15, [rsp+0x90]
000070a59adda52a  vpermilpd xmm15, xmm15, 0x00
000070a59adda530  movaps xmm11, xmm10
000070a59adda534  vfmadd231pd xmm11, xmm13, xmm15
000070a59adda539  vcmppd xmm14, xmm11, xmm11, 0x03
000070a59adda53f  vptest xmm14, xmm14
000070a59adda544  jnz 0x000070A59ADDCBD3
000070a59adda54a  lea rax, [r14+0x90]
000070a59adda551  movups xmm15, [r13+rax*1]
000070a59adda557  lea rax, [r14+0xA0]
000070a59adda55e  movups xmm14, [r13+rax*1]
000070a59adda564  movaps [r15+0x140], xmm15
000070a59adda56c  movaps [r15+0x130], xmm14
000070a59adda574  vmovaps xmm13, [rsp+0x10]
000070a59adda57a  vpermilpd xmm13, xmm13, 0x00
000070a59adda580  movaps xmm10, xmm8
000070a59adda584  vfmadd231pd xmm10, xmm1, xmm13
000070a59adda589  vcmppd xmm9, xmm10, xmm10, 0x03
000070a59adda58f  vptest xmm9, xmm9
000070a59adda594  jnz 0x000070A59ADDCD41
000070a59adda59a  movaps [r15+0x220], xmm10
000070a59adda5a2  lea rax, [r14+0x10]
000070a59adda5a6  movups xmm1, [r13+rax*1]
000070a59adda5ac  movaps [r15+0x240], xmm1
000070a59adda5b4  vmovaps xmm13, [rsp+0x10]
000070a59adda5ba  vpermilpd xmm13, xmm13, 0x00
000070a59adda5c0  movaps xmm9, xmm7
000070a59adda5c4  vfmadd231pd xmm9, xmm14, xmm13
000070a59adda5c9  vcmppd xmm8, xmm9, xmm9, 0x03
000070a59adda5cf  vptest xmm8, xmm8
000070a59adda5d4  jnz 0x000070A59ADDCEA4
000070a59adda5da  movaps [r15+0x110], xmm9
000070a59adda5e2  vmovaps xmm14, [rsp+0x10]
000070a59adda5e8  vpermilpd xmm14, xmm14, 0x00
000070a59adda5ee  movaps xmm13, xmm12
000070a59adda5f2  vfmadd231pd xmm13, xmm15, xmm14
000070a59adda5f7  vcmppd xmm8, xmm13, xmm13, 0x03
000070a59adda5fd  vptest xmm8, xmm8
000070a59adda602  jnz 0x000070A59ADDCFFD
000070a59adda608  movaps [r15+0x170], xmm13
000070a59adda610  vmovaps xmm15, [rsp+0x10]
000070a59adda616  vpermilpd xmm15, xmm15, 0x00
000070a59adda61c  movaps xmm14, xmm11
000070a59adda620  vfmadd231pd xmm14, xmm1, xmm15
000070a59adda625  vcmppd xmm12, xmm14, xmm14, 0x03
000070a59adda62b  vptest xmm12, xmm12
000070a59adda630  jnz 0x000070A59ADDD157
000070a59adda636  movaps [r15+0x230], xmm14
000070a59adda63e  mov rax, [rsp+0xD0]
000070a59adda646  movups [r13+rax*1], xmm9
000070a59adda64c  lea r14, [rax+0x10]
000070a59adda650  movups [r13+r14*1], xmm13
000070a59adda656  lea r14, [rax+0x20]
000070a59adda65a  movups [r13+r14*1], xmm10
000070a59adda660  lea r14, [rax+0x30]
000070a59adda664  movups [r13+r14*1], xmm14
000070a59adda66a  mov eax, [r15+0x108]
000070a59adda671  sahf
000070a59adda672  jnz 0x000070A59ADDA6A4
000070a59adda674  cmp dword ptr [r15+0x318], 0x00
000070a59adda67c  jz 0x000070A59ADD9950
000070a59adda682  nop [rax+rax*1], ax
000070a59adda68b  nop [rax+rax*1], eax
000070a59adda693  mov eax, 0x410664
000070a59adda698  mov [r15+0x100], rax
000070a59adda69f  jmp 0x000070A59ABFE110
000070a59adda6a4  cmp dword ptr [r15+0x318], 0x00
000070a59adda6ac  jz 0x000070A59ADD6050
000070a59adda6b2  nop [rax+rax*1], ax
000070a59adda6bb  nop [rax+rax*1], eax
000070a59adda6c3  mov eax, 0x4104F0
000070a59adda6c8  mov [r15+0x100], rax
000070a59adda6cf  jmp 0x000070A59ABFE110
000070a59adda6d4  int3
000070a59adda6d5  call 0x000070A59ACE27E0
000070a59adda6da  jmp 0x000070A59ADD9A10
000070a59adda6df  call 0x000070A59ACE1570
000070a59adda6e4  jmp 0x000070A59ADD9A19
000070a59adda6e9  call 0x000070A59ACE27E0
000070a59adda6ee  jmp 0x000070A59ADD9A62
000070a59adda6f3  call 0x000070A59ACE1570
000070a59adda6f8  jmp 0x000070A59ADD9A6B
000070a59adda6fd  call 0x000070A59ACE27E0
000070a59adda702  jmp 0x000070A59ADD9AEB
000070a59adda707  call 0x000070A59ACE1570
000070a59adda70c  jmp 0x000070A59ADD9AF4
000070a59adda711  call 0x000070A59AC0DC20
000070a59adda716  jmp 0x000070A59ADD9BD5
000070a59adda71b  call 0x000070A59ACD64F0
000070a59adda720  jmp 0x000070A59ADD9C04
000070a59adda725  call 0x000070A59ACB47C0
000070a59adda72a  jmp 0x000070A59ADD9C1F
000070a59adda72f  sub rsp, 0x08
000070a59adda733  push rax
000070a59adda734  push rcx
000070a59adda735  push rdx
000070a59adda736  push rdi
000070a59adda737  push rsi
000070a59adda738  push r8
000070a59adda73a  push r9
000070a59adda73c  push r10
000070a59adda73e  push r11
000070a59adda740  sub rsp, 0xF0
000070a59adda747  vmovaps [rsp], xmm0
000070a59adda74c  vmovaps [rsp+0x10], xmm1
000070a59adda752  vmovaps [rsp+0x20], xmm2
000070a59adda758  vmovaps [rsp+0x30], xmm3
000070a59adda75e  vmovaps [rsp+0x40], xmm4
000070a59adda764  vmovaps [rsp+0x50], xmm5
000070a59adda76a  vmovaps [rsp+0x60], xmm6
000070a59adda770  vmovaps [rsp+0x70], xmm7
000070a59adda776  vmovaps [rsp+0x80], xmm8
000070a59adda77f  vmovaps [rsp+0x90], xmm9
000070a59adda788  vmovaps [rsp+0xA0], xmm10
000070a59adda791  vmovaps [rsp+0xB0], xmm11
000070a59adda79a  vmovaps [rsp+0xC0], xmm12
000070a59adda7a3  vmovaps [rsp+0xD0], xmm14
000070a59adda7ac  vmovaps [rsp+0xE0], xmm15
000070a59adda7b5  sub rsp, 0x40
000070a59adda7b9  lea rdi, [rsp]
000070a59adda7bd  lea rsi, [rsp+0x10]
000070a59adda7c2  lea rdx, [rsp+0x20]
000070a59adda7c7  lea rcx, [rsp+0x30]
000070a59adda7cc  mov r8d, 0x00
000070a59adda7d2  lea r9, [r15+0x3A8]
000070a59adda7d9  movaps [rdi], xmm13
000070a59adda7dd  movaps [rsi], xmm1
000070a59adda7e0  movaps [rdx], xmm15
000070a59adda7e4  movaps [rcx], xmm14
000070a59adda7e8  mov rax, 0x622906D8FA50
000070a59adda7f2  call rax
000070a59adda7f4  movaps xmm13, [rsp]
000070a59adda7f9  add rsp, 0x40
000070a59adda7fd  vmovaps xmm0, [rsp]
000070a59adda802  vmovaps xmm1, [rsp+0x10]
000070a59adda808  vmovaps xmm2, [rsp+0x20]
000070a59adda80e  vmovaps xmm3, [rsp+0x30]
000070a59adda814  vmovaps xmm4, [rsp+0x40]
000070a59adda81a  vmovaps xmm5, [rsp+0x50]
000070a59adda820  vmovaps xmm6, [rsp+0x60]
000070a59adda826  vmovaps xmm7, [rsp+0x70]
000070a59adda82c  vmovaps xmm8, [rsp+0x80]
000070a59adda835  vmovaps xmm9, [rsp+0x90]
000070a59adda83e  vmovaps xmm10, [rsp+0xA0]
000070a59adda847  vmovaps xmm11, [rsp+0xB0]
000070a59adda850  vmovaps xmm12, [rsp+0xC0]
000070a59adda859  vmovaps xmm14, [rsp+0xD0]
000070a59adda862  vmovaps xmm15, [rsp+0xE0]
000070a59adda86b  add rsp, 0xF0
000070a59adda872  pop r11
000070a59adda874  pop r10
000070a59adda876  pop r9
000070a59adda878  pop r8
000070a59adda87a  pop rsi
000070a59adda87b  pop rdi
000070a59adda87c  pop rdx
000070a59adda87d  pop rcx
000070a59adda87e  pop rax
000070a59adda87f  add rsp, 0x08
000070a59adda883  jmp 0x000070A59ADD9C92
000070a59adda888  sub rsp, 0x08
000070a59adda88c  push rax
000070a59adda88d  push rcx
000070a59adda88e  push rdx
000070a59adda88f  push rdi
000070a59adda890  push rsi
000070a59adda891  push r8
000070a59adda893  push r9
000070a59adda895  push r10
000070a59adda897  push r11
000070a59adda899  sub rsp, 0xF0
000070a59adda8a0  vmovaps [rsp], xmm0
000070a59adda8a5  vmovaps [rsp+0x10], xmm1
000070a59adda8ab  vmovaps [rsp+0x20], xmm2
000070a59adda8b1  vmovaps [rsp+0x30], xmm3
000070a59adda8b7  vmovaps [rsp+0x40], xmm4
000070a59adda8bd  vmovaps [rsp+0x50], xmm5
000070a59adda8c3  vmovaps [rsp+0x60], xmm6
000070a59adda8c9  vmovaps [rsp+0x70], xmm7
000070a59adda8cf  vmovaps [rsp+0x80], xmm8
000070a59adda8d8  vmovaps [rsp+0x90], xmm9
000070a59adda8e1  vmovaps [rsp+0xA0], xmm10
000070a59adda8ea  vmovaps [rsp+0xB0], xmm11
000070a59adda8f3  vmovaps [rsp+0xC0], xmm13
000070a59adda8fc  vmovaps [rsp+0xD0], xmm14
000070a59adda905  vmovaps [rsp+0xE0], xmm15
000070a59adda90e  sub rsp, 0x40
000070a59adda912  lea rdi, [rsp]
000070a59adda916  lea rsi, [rsp+0x10]
000070a59adda91b  lea rdx, [rsp+0x20]
000070a59adda920  lea rcx, [rsp+0x30]
000070a59adda925  mov r8d, 0x00
000070a59adda92b  lea r9, [r15+0x3A8]
000070a59adda932  movaps [rdi], xmm12
000070a59adda936  movaps [rsi], xmm15
000070a59adda93a  movaps [rdx], xmm1
000070a59adda93d  movaps [rcx], xmm14
000070a59adda941  mov rax, 0x622906D8FA50
000070a59adda94b  call rax
000070a59adda94d  movaps xmm12, [rsp]
000070a59adda952  add rsp, 0x40
000070a59adda956  vmovaps xmm0, [rsp]
000070a59adda95b  vmovaps xmm1, [rsp+0x10]
000070a59adda961  vmovaps xmm2, [rsp+0x20]
000070a59adda967  vmovaps xmm3, [rsp+0x30]
000070a59adda96d  vmovaps xmm4, [rsp+0x40]
000070a59adda973  vmovaps xmm5, [rsp+0x50]
000070a59adda979  vmovaps xmm6, [rsp+0x60]
000070a59adda97f  vmovaps xmm7, [rsp+0x70]
000070a59adda985  vmovaps xmm8, [rsp+0x80]
000070a59adda98e  vmovaps xmm9, [rsp+0x90]
000070a59adda997  vmovaps xmm10, [rsp+0xA0]
000070a59adda9a0  vmovaps xmm11, [rsp+0xB0]
000070a59adda9a9  vmovaps xmm13, [rsp+0xC0]
000070a59adda9b2  vmovaps xmm14, [rsp+0xD0]
000070a59adda9bb  vmovaps xmm15, [rsp+0xE0]
000070a59adda9c4  add rsp, 0xF0
000070a59adda9cb  pop r11
000070a59adda9cd  pop r10
000070a59adda9cf  pop r9
000070a59adda9d1  pop r8
000070a59adda9d3  pop rsi
000070a59adda9d4  pop rdi
000070a59adda9d5  pop rdx
000070a59adda9d6  pop rcx
000070a59adda9d7  pop rax
000070a59adda9d8  add rsp, 0x08
000070a59adda9dc  jmp 0x000070A59ADD9CC0
000070a59adda9e1  call 0x000070A59ACB52F0
000070a59adda9e6  jmp 0x000070A59ADD9DAC
000070a59adda9eb  sub rsp, 0x08
000070a59adda9ef  push rax
000070a59adda9f0  push rcx
000070a59adda9f1  push rdx
000070a59adda9f2  push rdi
000070a59adda9f3  push rsi
000070a59adda9f4  push r8
000070a59adda9f6  push r9
000070a59adda9f8  push r10
000070a59adda9fa  push r11
000070a59adda9fc  sub rsp, 0xF0
000070a59addaa03  vmovaps [rsp], xmm0
000070a59addaa08  vmovaps [rsp+0x10], xmm1
000070a59addaa0e  vmovaps [rsp+0x20], xmm2
000070a59addaa14  vmovaps [rsp+0x30], xmm3
000070a59addaa1a  vmovaps [rsp+0x40], xmm4
000070a59addaa20  vmovaps [rsp+0x50], xmm5
000070a59addaa26  vmovaps [rsp+0x60], xmm6
000070a59addaa2c  vmovaps [rsp+0x70], xmm7
000070a59addaa32  vmovaps [rsp+0x80], xmm8
000070a59addaa3b  vmovaps [rsp+0x90], xmm9
000070a59addaa44  vmovaps [rsp+0xA0], xmm10
000070a59addaa4d  vmovaps [rsp+0xB0], xmm11
000070a59addaa56  vmovaps [rsp+0xC0], xmm12
000070a59addaa5f  vmovaps [rsp+0xD0], xmm14
000070a59addaa68  vmovaps [rsp+0xE0], xmm15
000070a59addaa71  sub rsp, 0x40
000070a59addaa75  lea rdi, [rsp]
000070a59addaa79  lea rsi, [rsp+0x10]
000070a59addaa7e  lea rdx, [rsp+0x20]
000070a59addaa83  lea rcx, [rsp+0x30]
000070a59addaa88  mov r8d, 0x00
000070a59addaa8e  lea r9, [r15+0x3A8]
000070a59addaa95  movaps [rdi], xmm13
000070a59addaa99  movaps [rsi], xmm1
000070a59addaa9c  movaps [rdx], xmm15
000070a59addaaa0  movaps [rcx], xmm14
000070a59addaaa4  mov rax, 0x622906D8FA50
000070a59addaaae  call rax
000070a59addaab0  movaps xmm13, [rsp]
000070a59addaab5  add rsp, 0x40
000070a59addaab9  vmovaps xmm0, [rsp]
000070a59addaabe  vmovaps xmm1, [rsp+0x10]
000070a59addaac4  vmovaps xmm2, [rsp+0x20]
000070a59addaaca  vmovaps xmm3, [rsp+0x30]
000070a59addaad0  vmovaps xmm4, [rsp+0x40]
000070a59addaad6  vmovaps xmm5, [rsp+0x50]
000070a59addaadc  vmovaps xmm6, [rsp+0x60]
000070a59addaae2  vmovaps xmm7, [rsp+0x70]
000070a59addaae8  vmovaps xmm8, [rsp+0x80]
000070a59addaaf1  vmovaps xmm9, [rsp+0x90]
000070a59addaafa  vmovaps xmm10, [rsp+0xA0]
000070a59addab03  vmovaps xmm11, [rsp+0xB0]
000070a59addab0c  vmovaps xmm12, [rsp+0xC0]
000070a59addab15  vmovaps xmm14, [rsp+0xD0]
000070a59addab1e  vmovaps xmm15, [rsp+0xE0]
000070a59addab27  add rsp, 0xF0
000070a59addab2e  pop r11
000070a59addab30  pop r10
000070a59addab32  pop r9
000070a59addab34  pop r8
000070a59addab36  pop rsi
000070a59addab37  pop rdi
000070a59addab38  pop rdx
000070a59addab39  pop rcx
000070a59addab3a  pop rax
000070a59addab3b  add rsp, 0x08
000070a59addab3f  jmp 0x000070A59ADD9E21
000070a59addab44  call 0x000070A59ABFF430
000070a59addab49  jmp 0x000070A59ADD9E2E
000070a59addab4e  sub rsp, 0x08
000070a59addab52  push rax
000070a59addab53  push rcx
000070a59addab54  push rdx
000070a59addab55  push rdi
000070a59addab56  push rsi
000070a59addab57  push r8
000070a59addab59  push r9
000070a59addab5b  push r10
000070a59addab5d  push r11
000070a59addab5f  sub rsp, 0xF0
000070a59addab66  vmovaps [rsp], xmm0
000070a59addab6b  vmovaps [rsp+0x10], xmm1
000070a59addab71  vmovaps [rsp+0x20], xmm2
000070a59addab77  vmovaps [rsp+0x30], xmm3
000070a59addab7d  vmovaps [rsp+0x40], xmm4
000070a59addab83  vmovaps [rsp+0x50], xmm5
000070a59addab89  vmovaps [rsp+0x60], xmm6
000070a59addab8f  vmovaps [rsp+0x70], xmm7
000070a59addab95  vmovaps [rsp+0x80], xmm8
000070a59addab9e  vmovaps [rsp+0x90], xmm9
000070a59addaba7  vmovaps [rsp+0xA0], xmm10
000070a59addabb0  vmovaps [rsp+0xB0], xmm11
000070a59addabb9  vmovaps [rsp+0xC0], xmm13
000070a59addabc2  vmovaps [rsp+0xD0], xmm14
000070a59addabcb  vmovaps [rsp+0xE0], xmm15
000070a59addabd4  sub rsp, 0x40
000070a59addabd8  lea rdi, [rsp]
000070a59addabdc  lea rsi, [rsp+0x10]
000070a59addabe1  lea rdx, [rsp+0x20]
000070a59addabe6  lea rcx, [rsp+0x30]
000070a59addabeb  mov r8d, 0x00
000070a59addabf1  lea r9, [r15+0x3A8]
000070a59addabf8  movaps [rdi], xmm12
000070a59addabfc  movaps [rsi], xmm15
000070a59addac00  movaps [rdx], xmm1
000070a59addac03  movaps [rcx], xmm14
000070a59addac07  mov rax, 0x622906D8FA50
000070a59addac11  call rax
000070a59addac13  movaps xmm12, [rsp]
000070a59addac18  add rsp, 0x40
000070a59addac1c  vmovaps xmm0, [rsp]
000070a59addac21  vmovaps xmm1, [rsp+0x10]
000070a59addac27  vmovaps xmm2, [rsp+0x20]
000070a59addac2d  vmovaps xmm3, [rsp+0x30]
000070a59addac33  vmovaps xmm4, [rsp+0x40]
000070a59addac39  vmovaps xmm5, [rsp+0x50]
000070a59addac3f  vmovaps xmm6, [rsp+0x60]
000070a59addac45  vmovaps xmm7, [rsp+0x70]
000070a59addac4b  vmovaps xmm8, [rsp+0x80]
000070a59addac54  vmovaps xmm9, [rsp+0x90]
000070a59addac5d  vmovaps xmm10, [rsp+0xA0]
000070a59addac66  vmovaps xmm11, [rsp+0xB0]
000070a59addac6f  vmovaps xmm13, [rsp+0xC0]
000070a59addac78  vmovaps xmm14, [rsp+0xD0]
000070a59addac81  vmovaps xmm15, [rsp+0xE0]
000070a59addac8a  add rsp, 0xF0
000070a59addac91  pop r11
000070a59addac93  pop r10
000070a59addac95  pop r9
000070a59addac97  pop r8
000070a59addac99  pop rsi
000070a59addac9a  pop rdi
000070a59addac9b  pop rdx
000070a59addac9c  pop rcx
000070a59addac9d  pop rax
000070a59addac9e  add rsp, 0x08
000070a59addaca2  jmp 0x000070A59ADD9E5A
000070a59addaca7  sub rsp, 0x08
000070a59addacab  push rax
000070a59addacac  push rcx
000070a59addacad  push rdx
000070a59addacae  push rdi
000070a59addacaf  push rsi
000070a59addacb0  push r8
000070a59addacb2  push r9
000070a59addacb4  push r10
000070a59addacb6  push r11
000070a59addacb8  sub rsp, 0xF0
000070a59addacbf  vmovaps [rsp], xmm0
000070a59addacc4  vmovaps [rsp+0x10], xmm1
000070a59addacca  vmovaps [rsp+0x20], xmm2
000070a59addacd0  vmovaps [rsp+0x30], xmm3
000070a59addacd6  vmovaps [rsp+0x40], xmm4
000070a59addacdc  vmovaps [rsp+0x50], xmm5
000070a59addace2  vmovaps [rsp+0x60], xmm6
000070a59addace8  vmovaps [rsp+0x70], xmm7
000070a59addacee  vmovaps [rsp+0x80], xmm8
000070a59addacf7  vmovaps [rsp+0x90], xmm9
000070a59addad00  vmovaps [rsp+0xA0], xmm10
000070a59addad09  vmovaps [rsp+0xB0], xmm11
000070a59addad12  vmovaps [rsp+0xC0], xmm12
000070a59addad1b  vmovaps [rsp+0xD0], xmm14
000070a59addad24  vmovaps [rsp+0xE0], xmm15
000070a59addad2d  sub rsp, 0x40
000070a59addad31  lea rdi, [rsp]
000070a59addad35  lea rsi, [rsp+0x10]
000070a59addad3a  lea rdx, [rsp+0x20]
000070a59addad3f  lea rcx, [rsp+0x30]
000070a59addad44  mov r8d, 0x00
000070a59addad4a  lea r9, [r15+0x3A8]
000070a59addad51  movaps [rdi], xmm13
000070a59addad55  movaps [rsi], xmm1
000070a59addad58  movaps [rdx], xmm15
000070a59addad5c  movaps [rcx], xmm14
000070a59addad60  mov rax, 0x622906D8FA50
000070a59addad6a  call rax
000070a59addad6c  movaps xmm13, [rsp]
000070a59addad71  add rsp, 0x40
000070a59addad75  vmovaps xmm0, [rsp]
000070a59addad7a  vmovaps xmm1, [rsp+0x10]
000070a59addad80  vmovaps xmm2, [rsp+0x20]
000070a59addad86  vmovaps xmm3, [rsp+0x30]
000070a59addad8c  vmovaps xmm4, [rsp+0x40]
000070a59addad92  vmovaps xmm5, [rsp+0x50]
000070a59addad98  vmovaps xmm6, [rsp+0x60]
000070a59addad9e  vmovaps xmm7, [rsp+0x70]
000070a59addada4  vmovaps xmm8, [rsp+0x80]
000070a59addadad  vmovaps xmm9, [rsp+0x90]
000070a59addadb6  vmovaps xmm10, [rsp+0xA0]
000070a59addadbf  vmovaps xmm11, [rsp+0xB0]
000070a59addadc8  vmovaps xmm12, [rsp+0xC0]
000070a59addadd1  vmovaps xmm14, [rsp+0xD0]
000070a59addadda  vmovaps xmm15, [rsp+0xE0]
000070a59addade3  add rsp, 0xF0
000070a59addadea  pop r11
000070a59addadec  pop r10
000070a59addadee  pop r9
000070a59addadf0  pop r8
000070a59addadf2  pop rsi
000070a59addadf3  pop rdi
000070a59addadf4  pop rdx
000070a59addadf5  pop rcx
000070a59addadf6  pop rax
000070a59addadf7  add rsp, 0x08
000070a59addadfb  jmp 0x000070A59ADD9FEA
000070a59addae00  sub rsp, 0x08
000070a59addae04  push rax
000070a59addae05  push rcx
000070a59addae06  push rdx
000070a59addae07  push rdi
000070a59addae08  push rsi
000070a59addae09  push r8
000070a59addae0b  push r9
000070a59addae0d  push r10
000070a59addae0f  push r11
000070a59addae11  sub rsp, 0xF0
000070a59addae18  vmovaps [rsp], xmm0
000070a59addae1d  vmovaps [rsp+0x10], xmm1
000070a59addae23  vmovaps [rsp+0x20], xmm2
000070a59addae29  vmovaps [rsp+0x30], xmm3
000070a59addae2f  vmovaps [rsp+0x40], xmm4
000070a59addae35  vmovaps [rsp+0x50], xmm5
000070a59addae3b  vmovaps [rsp+0x60], xmm6
000070a59addae41  vmovaps [rsp+0x70], xmm7
000070a59addae47  vmovaps [rsp+0x80], xmm8
000070a59addae50  vmovaps [rsp+0x90], xmm9
000070a59addae59  vmovaps [rsp+0xA0], xmm10
000070a59addae62  vmovaps [rsp+0xB0], xmm11
000070a59addae6b  vmovaps [rsp+0xC0], xmm12
000070a59addae74  vmovaps [rsp+0xD0], xmm13
000070a59addae7d  vmovaps [rsp+0xE0], xmm15
000070a59addae86  sub rsp, 0x40
000070a59addae8a  lea rdi, [rsp]
000070a59addae8e  lea rsi, [rsp+0x10]
000070a59addae93  lea rdx, [rsp+0x20]
000070a59addae98  lea rcx, [rsp+0x30]
000070a59addae9d  mov r8d, 0x00
000070a59addaea3  lea r9, [r15+0x3A8]
000070a59addaeaa  movaps [rdi], xmm14
000070a59addaeae  movaps [rsi], xmm15
000070a59addaeb2  movaps [rdx], xmm2
000070a59addaeb5  movaps [rcx], xmm1
000070a59addaeb8  mov rax, 0x622906D8FA50
000070a59addaec2  call rax
000070a59addaec4  movaps xmm14, [rsp]
000070a59addaec9  add rsp, 0x40
000070a59addaecd  vmovaps xmm0, [rsp]
000070a59addaed2  vmovaps xmm1, [rsp+0x10]
000070a59addaed8  vmovaps xmm2, [rsp+0x20]
000070a59addaede  vmovaps xmm3, [rsp+0x30]
000070a59addaee4  vmovaps xmm4, [rsp+0x40]
000070a59addaeea  vmovaps xmm5, [rsp+0x50]
000070a59addaef0  vmovaps xmm6, [rsp+0x60]
000070a59addaef6  vmovaps xmm7, [rsp+0x70]
000070a59addaefc  vmovaps xmm8, [rsp+0x80]
000070a59addaf05  vmovaps xmm9, [rsp+0x90]
000070a59addaf0e  vmovaps xmm10, [rsp+0xA0]
000070a59addaf17  vmovaps xmm11, [rsp+0xB0]
000070a59addaf20  vmovaps xmm12, [rsp+0xC0]
000070a59addaf29  vmovaps xmm13, [rsp+0xD0]
000070a59addaf32  vmovaps xmm15, [rsp+0xE0]
000070a59addaf3b  add rsp, 0xF0
000070a59addaf42  pop r11
000070a59addaf44  pop r10
000070a59addaf46  pop r9
000070a59addaf48  pop r8
000070a59addaf4a  pop rsi
000070a59addaf4b  pop rdi
000070a59addaf4c  pop rdx
000070a59addaf4d  pop rcx
000070a59addaf4e  pop rax
000070a59addaf4f  add rsp, 0x08
000070a59addaf53  jmp 0x000070A59ADDA01C
000070a59addaf58  sub rsp, 0x08
000070a59addaf5c  push rax
000070a59addaf5d  push rcx
000070a59addaf5e  push rdx
000070a59addaf5f  push rdi
000070a59addaf60  push rsi
000070a59addaf61  push r8
000070a59addaf63  push r9
000070a59addaf65  push r10
000070a59addaf67  push r11
000070a59addaf69  sub rsp, 0xF0
000070a59addaf70  vmovaps [rsp], xmm0
000070a59addaf75  vmovaps [rsp+0x10], xmm1
000070a59addaf7b  vmovaps [rsp+0x20], xmm3
000070a59addaf81  vmovaps [rsp+0x30], xmm4
000070a59addaf87  vmovaps [rsp+0x40], xmm5
000070a59addaf8d  vmovaps [rsp+0x50], xmm6
000070a59addaf93  vmovaps [rsp+0x60], xmm7
000070a59addaf99  vmovaps [rsp+0x70], xmm8
000070a59addaf9f  vmovaps [rsp+0x80], xmm9
000070a59addafa8  vmovaps [rsp+0x90], xmm10
000070a59addafb1  vmovaps [rsp+0xA0], xmm11
000070a59addafba  vmovaps [rsp+0xB0], xmm12
000070a59addafc3  vmovaps [rsp+0xC0], xmm13
000070a59addafcc  vmovaps [rsp+0xD0], xmm14
000070a59addafd5  vmovaps [rsp+0xE0], xmm15
000070a59addafde  sub rsp, 0x40
000070a59addafe2  lea rdi, [rsp]
000070a59addafe6  lea rsi, [rsp+0x10]
000070a59addafeb  lea rdx, [rsp+0x20]
000070a59addaff0  lea rcx, [rsp+0x30]
000070a59addaff5  mov r8d, 0x00
000070a59addaffb  lea r9, [r15+0x3A8]
000070a59addb002  movaps [rdi], xmm2
000070a59addb005  movaps [rsi], xmm15
000070a59addb009  movaps [rdx], xmm12
000070a59addb00d  movaps [rcx], xmm1
000070a59addb010  mov rax, 0x622906D8FA50
000070a59addb01a  call rax
000070a59addb01c  movaps xmm2, [rsp]
000070a59addb020  add rsp, 0x40
000070a59addb024  vmovaps xmm0, [rsp]
000070a59addb029  vmovaps xmm1, [rsp+0x10]
000070a59addb02f  vmovaps xmm3, [rsp+0x20]
000070a59addb035  vmovaps xmm4, [rsp+0x30]
000070a59addb03b  vmovaps xmm5, [rsp+0x40]
000070a59addb041  vmovaps xmm6, [rsp+0x50]
000070a59addb047  vmovaps xmm7, [rsp+0x60]
000070a59addb04d  vmovaps xmm8, [rsp+0x70]
000070a59addb053  vmovaps xmm9, [rsp+0x80]
000070a59addb05c  vmovaps xmm10, [rsp+0x90]
000070a59addb065  vmovaps xmm11, [rsp+0xA0]
000070a59addb06e  vmovaps xmm12, [rsp+0xB0]
000070a59addb077  vmovaps xmm13, [rsp+0xC0]
000070a59addb080  vmovaps xmm14, [rsp+0xD0]
000070a59addb089  vmovaps xmm15, [rsp+0xE0]
000070a59addb092  add rsp, 0xF0
000070a59addb099  pop r11
000070a59addb09b  pop r10
000070a59addb09d  pop r9
000070a59addb09f  pop r8
000070a59addb0a1  pop rsi
000070a59addb0a2  pop rdi
000070a59addb0a3  pop rdx
000070a59addb0a4  pop rcx
000070a59addb0a5  pop rax
000070a59addb0a6  add rsp, 0x08
000070a59addb0aa  jmp 0x000070A59ADDA059
000070a59addb0af  sub rsp, 0x08
000070a59addb0b3  push rax
000070a59addb0b4  push rcx
000070a59addb0b5  push rdx
000070a59addb0b6  push rdi
000070a59addb0b7  push rsi
000070a59addb0b8  push r8
000070a59addb0ba  push r9
000070a59addb0bc  push r10
000070a59addb0be  push r11
000070a59addb0c0  sub rsp, 0xF0
000070a59addb0c7  vmovaps [rsp], xmm0
000070a59addb0cc  vmovaps [rsp+0x10], xmm1
000070a59addb0d2  vmovaps [rsp+0x20], xmm2
000070a59addb0d8  vmovaps [rsp+0x30], xmm3
000070a59addb0de  vmovaps [rsp+0x40], xmm4
000070a59addb0e4  vmovaps [rsp+0x50], xmm5
000070a59addb0ea  vmovaps [rsp+0x60], xmm6
000070a59addb0f0  vmovaps [rsp+0x70], xmm7
000070a59addb0f6  vmovaps [rsp+0x80], xmm8
000070a59addb0ff  vmovaps [rsp+0x90], xmm9
000070a59addb108  vmovaps [rsp+0xA0], xmm10
000070a59addb111  vmovaps [rsp+0xB0], xmm11
000070a59addb11a  vmovaps [rsp+0xC0], xmm13
000070a59addb123  vmovaps [rsp+0xD0], xmm14
000070a59addb12c  vmovaps [rsp+0xE0], xmm15
000070a59addb135  sub rsp, 0x40
000070a59addb139  lea rdi, [rsp]
000070a59addb13d  lea rsi, [rsp+0x10]
000070a59addb142  lea rdx, [rsp+0x20]
000070a59addb147  lea rcx, [rsp+0x30]
000070a59addb14c  mov r8d, 0x00
000070a59addb152  lea r9, [r15+0x3A8]
000070a59addb159  movaps [rdi], xmm12
000070a59addb15d  movaps [rsi], xmm14
000070a59addb161  movaps [rdx], xmm3
000070a59addb164  movaps [rcx], xmm15
000070a59addb168  mov rax, 0x622906D8FA50
000070a59addb172  call rax
000070a59addb174  movaps xmm12, [rsp]
000070a59addb179  add rsp, 0x40
000070a59addb17d  vmovaps xmm0, [rsp]
000070a59addb182  vmovaps xmm1, [rsp+0x10]
000070a59addb188  vmovaps xmm2, [rsp+0x20]
000070a59addb18e  vmovaps xmm3, [rsp+0x30]
000070a59addb194  vmovaps xmm4, [rsp+0x40]
000070a59addb19a  vmovaps xmm5, [rsp+0x50]
000070a59addb1a0  vmovaps xmm6, [rsp+0x60]
000070a59addb1a6  vmovaps xmm7, [rsp+0x70]
000070a59addb1ac  vmovaps xmm8, [rsp+0x80]
000070a59addb1b5  vmovaps xmm9, [rsp+0x90]
000070a59addb1be  vmovaps xmm10, [rsp+0xA0]
000070a59addb1c7  vmovaps xmm11, [rsp+0xB0]
000070a59addb1d0  vmovaps xmm13, [rsp+0xC0]
000070a59addb1d9  vmovaps xmm14, [rsp+0xD0]
000070a59addb1e2  vmovaps xmm15, [rsp+0xE0]
000070a59addb1eb  add rsp, 0xF0
000070a59addb1f2  pop r11
000070a59addb1f4  pop r10
000070a59addb1f6  pop r9
000070a59addb1f8  pop r8
000070a59addb1fa  pop rsi
000070a59addb1fb  pop rdi
000070a59addb1fc  pop rdx
000070a59addb1fd  pop rcx
000070a59addb1fe  pop rax
000070a59addb1ff  add rsp, 0x08
000070a59addb203  jmp 0x000070A59ADDA0B3
000070a59addb208  sub rsp, 0x08
000070a59addb20c  push rax
000070a59addb20d  push rcx
000070a59addb20e  push rdx
000070a59addb20f  push rdi
000070a59addb210  push rsi
000070a59addb211  push r8
000070a59addb213  push r9
000070a59addb215  push r10
000070a59addb217  push r11
000070a59addb219  sub rsp, 0xF0
000070a59addb220  vmovaps [rsp], xmm0
000070a59addb225  vmovaps [rsp+0x10], xmm1
000070a59addb22b  vmovaps [rsp+0x20], xmm2
000070a59addb231  vmovaps [rsp+0x30], xmm3
000070a59addb237  vmovaps [rsp+0x40], xmm4
000070a59addb23d  vmovaps [rsp+0x50], xmm5
000070a59addb243  vmovaps [rsp+0x60], xmm6
000070a59addb249  vmovaps [rsp+0x70], xmm7
000070a59addb24f  vmovaps [rsp+0x80], xmm8
000070a59addb258  vmovaps [rsp+0x90], xmm10
000070a59addb261  vmovaps [rsp+0xA0], xmm11
000070a59addb26a  vmovaps [rsp+0xB0], xmm12
000070a59addb273  vmovaps [rsp+0xC0], xmm13
000070a59addb27c  vmovaps [rsp+0xD0], xmm14
000070a59addb285  vmovaps [rsp+0xE0], xmm15
000070a59addb28e  sub rsp, 0x40
000070a59addb292  lea rdi, [rsp]
000070a59addb296  lea rsi, [rsp+0x10]
000070a59addb29b  lea rdx, [rsp+0x20]
000070a59addb2a0  lea rcx, [rsp+0x30]
000070a59addb2a5  mov r8d, 0x00
000070a59addb2ab  lea r9, [r15+0x3A8]
000070a59addb2b2  movaps [rdi], xmm9
000070a59addb2b6  movaps [rsi], xmm13
000070a59addb2ba  movaps [rdx], xmm14
000070a59addb2be  movaps [rcx], xmm6
000070a59addb2c1  mov rax, 0x622906D8FA50
000070a59addb2cb  call rax
000070a59addb2cd  movaps xmm9, [rsp]
000070a59addb2d2  add rsp, 0x40
000070a59addb2d6  vmovaps xmm0, [rsp]
000070a59addb2db  vmovaps xmm1, [rsp+0x10]
000070a59addb2e1  vmovaps xmm2, [rsp+0x20]
000070a59addb2e7  vmovaps xmm3, [rsp+0x30]
000070a59addb2ed  vmovaps xmm4, [rsp+0x40]
000070a59addb2f3  vmovaps xmm5, [rsp+0x50]
000070a59addb2f9  vmovaps xmm6, [rsp+0x60]
000070a59addb2ff  vmovaps xmm7, [rsp+0x70]
000070a59addb305  vmovaps xmm8, [rsp+0x80]
000070a59addb30e  vmovaps xmm10, [rsp+0x90]
000070a59addb317  vmovaps xmm11, [rsp+0xA0]
000070a59addb320  vmovaps xmm12, [rsp+0xB0]
000070a59addb329  vmovaps xmm13, [rsp+0xC0]
000070a59addb332  vmovaps xmm14, [rsp+0xD0]
000070a59addb33b  vmovaps xmm15, [rsp+0xE0]
000070a59addb344  add rsp, 0xF0
000070a59addb34b  pop r11
000070a59addb34d  pop r10
000070a59addb34f  pop r9
000070a59addb351  pop r8
000070a59addb353  pop rsi
000070a59addb354  pop rdi
000070a59addb355  pop rdx
000070a59addb356  pop rcx
000070a59addb357  pop rax
000070a59addb358  add rsp, 0x08
000070a59addb35c  jmp 0x000070A59ADDA15D
000070a59addb361  sub rsp, 0x08
000070a59addb365  push rax
000070a59addb366  push rcx
000070a59addb367  push rdx
000070a59addb368  push rdi
000070a59addb369  push rsi
000070a59addb36a  push r8
000070a59addb36c  push r9
000070a59addb36e  push r10
000070a59addb370  push r11
000070a59addb372  sub rsp, 0xF0
000070a59addb379  vmovaps [rsp], xmm0
000070a59addb37e  vmovaps [rsp+0x10], xmm1
000070a59addb384  vmovaps [rsp+0x20], xmm2
000070a59addb38a  vmovaps [rsp+0x30], xmm4
000070a59addb390  vmovaps [rsp+0x40], xmm5
000070a59addb396  vmovaps [rsp+0x50], xmm6
000070a59addb39c  vmovaps [rsp+0x60], xmm7
000070a59addb3a2  vmovaps [rsp+0x70], xmm8
000070a59addb3a8  vmovaps [rsp+0x80], xmm9
000070a59addb3b1  vmovaps [rsp+0x90], xmm10
000070a59addb3ba  vmovaps [rsp+0xA0], xmm11
000070a59addb3c3  vmovaps [rsp+0xB0], xmm12
000070a59addb3cc  vmovaps [rsp+0xC0], xmm13
000070a59addb3d5  vmovaps [rsp+0xD0], xmm14
000070a59addb3de  vmovaps [rsp+0xE0], xmm15
000070a59addb3e7  sub rsp, 0x40
000070a59addb3eb  lea rdi, [rsp]
000070a59addb3ef  lea rsi, [rsp+0x10]
000070a59addb3f4  lea rdx, [rsp+0x20]
000070a59addb3f9  lea rcx, [rsp+0x30]
000070a59addb3fe  mov r8d, 0x00
000070a59addb404  lea r9, [r15+0x3A8]
000070a59addb40b  movaps [rdi], xmm3
000070a59addb40e  movaps [rsi], xmm13
000070a59addb412  movaps [rdx], xmm6
000070a59addb415  movaps [rcx], xmm14
000070a59addb419  mov rax, 0x622906D8FA50
000070a59addb423  call rax
000070a59addb425  movaps xmm3, [rsp]
000070a59addb429  add rsp, 0x40
000070a59addb42d  vmovaps xmm0, [rsp]
000070a59addb432  vmovaps xmm1, [rsp+0x10]
000070a59addb438  vmovaps xmm2, [rsp+0x20]
000070a59addb43e  vmovaps xmm4, [rsp+0x30]
000070a59addb444  vmovaps xmm5, [rsp+0x40]
000070a59addb44a  vmovaps xmm6, [rsp+0x50]
000070a59addb450  vmovaps xmm7, [rsp+0x60]
000070a59addb456  vmovaps xmm8, [rsp+0x70]
000070a59addb45c  vmovaps xmm9, [rsp+0x80]
000070a59addb465  vmovaps xmm10, [rsp+0x90]
000070a59addb46e  vmovaps xmm11, [rsp+0xA0]
000070a59addb477  vmovaps xmm12, [rsp+0xB0]
000070a59addb480  vmovaps xmm13, [rsp+0xC0]
000070a59addb489  vmovaps xmm14, [rsp+0xD0]
000070a59addb492  vmovaps xmm15, [rsp+0xE0]
000070a59addb49b  add rsp, 0xF0
000070a59addb4a2  pop r11
000070a59addb4a4  pop r10
000070a59addb4a6  pop r9
000070a59addb4a8  pop r8
000070a59addb4aa  pop rsi
000070a59addb4ab  pop rdi
000070a59addb4ac  pop rdx
000070a59addb4ad  pop rcx
000070a59addb4ae  pop rax
000070a59addb4af  add rsp, 0x08
000070a59addb4b3  jmp 0x000070A59ADDA19A
000070a59addb4b8  sub rsp, 0x08
000070a59addb4bc  push rax
000070a59addb4bd  push rcx
000070a59addb4be  push rdx
000070a59addb4bf  push rdi
000070a59addb4c0  push rsi
000070a59addb4c1  push r8
000070a59addb4c3  push r9
000070a59addb4c5  push r10
000070a59addb4c7  push r11
000070a59addb4c9  sub rsp, 0xF0
000070a59addb4d0  vmovaps [rsp], xmm0
000070a59addb4d5  vmovaps [rsp+0x10], xmm1
000070a59addb4db  vmovaps [rsp+0x20], xmm2
000070a59addb4e1  vmovaps [rsp+0x30], xmm3
000070a59addb4e7  vmovaps [rsp+0x40], xmm4
000070a59addb4ed  vmovaps [rsp+0x50], xmm5
000070a59addb4f3  vmovaps [rsp+0x60], xmm7
000070a59addb4f9  vmovaps [rsp+0x70], xmm8
000070a59addb4ff  vmovaps [rsp+0x80], xmm9
000070a59addb508  vmovaps [rsp+0x90], xmm10
000070a59addb511  vmovaps [rsp+0xA0], xmm11
000070a59addb51a  vmovaps [rsp+0xB0], xmm12
000070a59addb523  vmovaps [rsp+0xC0], xmm13
000070a59addb52c  vmovaps [rsp+0xD0], xmm14
000070a59addb535  vmovaps [rsp+0xE0], xmm15
000070a59addb53e  sub rsp, 0x40
000070a59addb542  lea rdi, [rsp]
000070a59addb546  lea rsi, [rsp+0x10]
000070a59addb54b  lea rdx, [rsp+0x20]
000070a59addb550  lea rcx, [rsp+0x30]
000070a59addb555  mov r8d, 0x00
000070a59addb55b  lea r9, [r15+0x3A8]
000070a59addb562  movaps [rdi], xmm6
000070a59addb565  movaps [rsi], xmm2
000070a59addb568  movaps [rdx], xmm14
000070a59addb56c  movaps [rcx], xmm1
000070a59addb56f  mov rax, 0x622906D8FA50
000070a59addb579  call rax
000070a59addb57b  movaps xmm6, [rsp]
000070a59addb57f  add rsp, 0x40
000070a59addb583  vmovaps xmm0, [rsp]
000070a59addb588  vmovaps xmm1, [rsp+0x10]
000070a59addb58e  vmovaps xmm2, [rsp+0x20]
000070a59addb594  vmovaps xmm3, [rsp+0x30]
000070a59addb59a  vmovaps xmm4, [rsp+0x40]
000070a59addb5a0  vmovaps xmm5, [rsp+0x50]
000070a59addb5a6  vmovaps xmm7, [rsp+0x60]
000070a59addb5ac  vmovaps xmm8, [rsp+0x70]
000070a59addb5b2  vmovaps xmm9, [rsp+0x80]
000070a59addb5bb  vmovaps xmm10, [rsp+0x90]
000070a59addb5c4  vmovaps xmm11, [rsp+0xA0]
000070a59addb5cd  vmovaps xmm12, [rsp+0xB0]
000070a59addb5d6  vmovaps xmm13, [rsp+0xC0]
000070a59addb5df  vmovaps xmm14, [rsp+0xD0]
000070a59addb5e8  vmovaps xmm15, [rsp+0xE0]
000070a59addb5f1  add rsp, 0xF0
000070a59addb5f8  pop r11
000070a59addb5fa  pop r10
000070a59addb5fc  pop r9
000070a59addb5fe  pop r8
000070a59addb600  pop rsi
000070a59addb601  pop rdi
000070a59addb602  pop rdx
000070a59addb603  pop rcx
000070a59addb604  pop rax
000070a59addb605  add rsp, 0x08
000070a59addb609  jmp 0x000070A59ADDA1C7
000070a59addb60e  sub rsp, 0x08
000070a59addb612  push rax
000070a59addb613  push rcx
000070a59addb614  push rdx
000070a59addb615  push rdi
000070a59addb616  push rsi
000070a59addb617  push r8
000070a59addb619  push r9
000070a59addb61b  push r10
000070a59addb61d  push r11
000070a59addb61f  sub rsp, 0xF0
000070a59addb626  vmovaps [rsp], xmm0
000070a59addb62b  vmovaps [rsp+0x10], xmm1
000070a59addb631  vmovaps [rsp+0x20], xmm2
000070a59addb637  vmovaps [rsp+0x30], xmm3
000070a59addb63d  vmovaps [rsp+0x40], xmm4
000070a59addb643  vmovaps [rsp+0x50], xmm5
000070a59addb649  vmovaps [rsp+0x60], xmm6
000070a59addb64f  vmovaps [rsp+0x70], xmm7
000070a59addb655  vmovaps [rsp+0x80], xmm8
000070a59addb65e  vmovaps [rsp+0x90], xmm9
000070a59addb667  vmovaps [rsp+0xA0], xmm10
000070a59addb670  vmovaps [rsp+0xB0], xmm11
000070a59addb679  vmovaps [rsp+0xC0], xmm12
000070a59addb682  vmovaps [rsp+0xD0], xmm14
000070a59addb68b  vmovaps [rsp+0xE0], xmm15
000070a59addb694  sub rsp, 0x40
000070a59addb698  lea rdi, [rsp]
000070a59addb69c  lea rsi, [rsp+0x10]
000070a59addb6a1  lea rdx, [rsp+0x20]
000070a59addb6a6  lea rcx, [rsp+0x30]
000070a59addb6ab  mov r8d, 0x00
000070a59addb6b1  lea r9, [r15+0x3A8]
000070a59addb6b8  movaps [rdi], xmm13
000070a59addb6bc  movaps [rsi], xmm12
000070a59addb6c0  movaps [rdx], xmm14
000070a59addb6c4  movaps [rcx], xmm1
000070a59addb6c7  mov rax, 0x622906D8FA50
000070a59addb6d1  call rax
000070a59addb6d3  movaps xmm13, [rsp]
000070a59addb6d8  add rsp, 0x40
000070a59addb6dc  vmovaps xmm0, [rsp]
000070a59addb6e1  vmovaps xmm1, [rsp+0x10]
000070a59addb6e7  vmovaps xmm2, [rsp+0x20]
000070a59addb6ed  vmovaps xmm3, [rsp+0x30]
000070a59addb6f3  vmovaps xmm4, [rsp+0x40]
000070a59addb6f9  vmovaps xmm5, [rsp+0x50]
000070a59addb6ff  vmovaps xmm6, [rsp+0x60]
000070a59addb705  vmovaps xmm7, [rsp+0x70]
000070a59addb70b  vmovaps xmm8, [rsp+0x80]
000070a59addb714  vmovaps xmm9, [rsp+0x90]
000070a59addb71d  vmovaps xmm10, [rsp+0xA0]
000070a59addb726  vmovaps xmm11, [rsp+0xB0]
000070a59addb72f  vmovaps xmm12, [rsp+0xC0]
000070a59addb738  vmovaps xmm14, [rsp+0xD0]
000070a59addb741  vmovaps xmm15, [rsp+0xE0]
000070a59addb74a  add rsp, 0xF0
000070a59addb751  pop r11
000070a59addb753  pop r10
000070a59addb755  pop r9
000070a59addb757  pop r8
000070a59addb759  pop rsi
000070a59addb75a  pop rdi
000070a59addb75b  pop rdx
000070a59addb75c  pop rcx
000070a59addb75d  pop rax
000070a59addb75e  add rsp, 0x08
000070a59addb762  jmp 0x000070A59ADDA1F9
000070a59addb767  sub rsp, 0x08
000070a59addb76b  push rax
000070a59addb76c  push rcx
000070a59addb76d  push rdx
000070a59addb76e  push rdi
000070a59addb76f  push rsi
000070a59addb770  push r8
000070a59addb772  push r9
000070a59addb774  push r10
000070a59addb776  push r11
000070a59addb778  sub rsp, 0xF0
000070a59addb77f  vmovaps [rsp], xmm0
000070a59addb784  vmovaps [rsp+0x10], xmm1
000070a59addb78a  vmovaps [rsp+0x20], xmm2
000070a59addb790  vmovaps [rsp+0x30], xmm3
000070a59addb796  vmovaps [rsp+0x40], xmm4
000070a59addb79c  vmovaps [rsp+0x50], xmm5
000070a59addb7a2  vmovaps [rsp+0x60], xmm6
000070a59addb7a8  vmovaps [rsp+0x70], xmm7
000070a59addb7ae  vmovaps [rsp+0x80], xmm8
000070a59addb7b7  vmovaps [rsp+0x90], xmm9
000070a59addb7c0  vmovaps [rsp+0xA0], xmm10
000070a59addb7c9  vmovaps [rsp+0xB0], xmm11
000070a59addb7d2  vmovaps [rsp+0xC0], xmm13
000070a59addb7db  vmovaps [rsp+0xD0], xmm14
000070a59addb7e4  vmovaps [rsp+0xE0], xmm15
000070a59addb7ed  sub rsp, 0x40
000070a59addb7f1  lea rdi, [rsp]
000070a59addb7f5  lea rsi, [rsp+0x10]
000070a59addb7fa  lea rdx, [rsp+0x20]
000070a59addb7ff  lea rcx, [rsp+0x30]
000070a59addb804  mov r8d, 0x00
000070a59addb80a  lea r9, [r15+0x3A8]
000070a59addb811  movaps [rdi], xmm12
000070a59addb815  movaps [rsi], xmm3
000070a59addb818  movaps [rdx], xmm14
000070a59addb81c  movaps [rcx], xmm5
000070a59addb81f  mov rax, 0x622906D8FA50
000070a59addb829  call rax
000070a59addb82b  movaps xmm12, [rsp]
000070a59addb830  add rsp, 0x40
000070a59addb834  vmovaps xmm0, [rsp]
000070a59addb839  vmovaps xmm1, [rsp+0x10]
000070a59addb83f  vmovaps xmm2, [rsp+0x20]
000070a59addb845  vmovaps xmm3, [rsp+0x30]
000070a59addb84b  vmovaps xmm4, [rsp+0x40]
000070a59addb851  vmovaps xmm5, [rsp+0x50]
000070a59addb857  vmovaps xmm6, [rsp+0x60]
000070a59addb85d  vmovaps xmm7, [rsp+0x70]
000070a59addb863  vmovaps xmm8, [rsp+0x80]
000070a59addb86c  vmovaps xmm9, [rsp+0x90]
000070a59addb875  vmovaps xmm10, [rsp+0xA0]
000070a59addb87e  vmovaps xmm11, [rsp+0xB0]
000070a59addb887  vmovaps xmm13, [rsp+0xC0]
000070a59addb890  vmovaps xmm14, [rsp+0xD0]
000070a59addb899  vmovaps xmm15, [rsp+0xE0]
000070a59addb8a2  add rsp, 0xF0
000070a59addb8a9  pop r11
000070a59addb8ab  pop r10
000070a59addb8ad  pop r9
000070a59addb8af  pop r8
000070a59addb8b1  pop rsi
000070a59addb8b2  pop rdi
000070a59addb8b3  pop rdx
000070a59addb8b4  pop rcx
000070a59addb8b5  pop rax
000070a59addb8b6  add rsp, 0x08
000070a59addb8ba  jmp 0x000070A59ADDA256
000070a59addb8bf  sub rsp, 0x08
000070a59addb8c3  push rax
000070a59addb8c4  push rcx
000070a59addb8c5  push rdx
000070a59addb8c6  push rdi
000070a59addb8c7  push rsi
000070a59addb8c8  push r8
000070a59addb8ca  push r9
000070a59addb8cc  push r10
000070a59addb8ce  push r11
000070a59addb8d0  sub rsp, 0xF0
000070a59addb8d7  vmovaps [rsp], xmm0
000070a59addb8dc  vmovaps [rsp+0x10], xmm1
000070a59addb8e2  vmovaps [rsp+0x20], xmm2
000070a59addb8e8  vmovaps [rsp+0x30], xmm3
000070a59addb8ee  vmovaps [rsp+0x40], xmm4
000070a59addb8f4  vmovaps [rsp+0x50], xmm5
000070a59addb8fa  vmovaps [rsp+0x60], xmm6
000070a59addb900  vmovaps [rsp+0x70], xmm7
000070a59addb906  vmovaps [rsp+0x80], xmm8
000070a59addb90f  vmovaps [rsp+0x90], xmm9
000070a59addb918  vmovaps [rsp+0xA0], xmm11
000070a59addb921  vmovaps [rsp+0xB0], xmm12
000070a59addb92a  vmovaps [rsp+0xC0], xmm13
000070a59addb933  vmovaps [rsp+0xD0], xmm14
000070a59addb93c  vmovaps [rsp+0xE0], xmm15
000070a59addb945  sub rsp, 0x40
000070a59addb949  lea rdi, [rsp]
000070a59addb94d  lea rsi, [rsp+0x10]
000070a59addb952  lea rdx, [rsp+0x20]
000070a59addb957  lea rcx, [rsp+0x30]
000070a59addb95c  mov r8d, 0x00
000070a59addb962  lea r9, [r15+0x3A8]
000070a59addb969  movaps [rdi], xmm10
000070a59addb96d  movaps [rsi], xmm9
000070a59addb971  movaps [rdx], xmm7
000070a59addb974  movaps [rcx], xmm14
000070a59addb978  mov rax, 0x622906D8FA50
000070a59addb982  call rax
000070a59addb984  movaps xmm10, [rsp]
000070a59addb989  add rsp, 0x40
000070a59addb98d  vmovaps xmm0, [rsp]
000070a59addb992  vmovaps xmm1, [rsp+0x10]
000070a59addb998  vmovaps xmm2, [rsp+0x20]
000070a59addb99e  vmovaps xmm3, [rsp+0x30]
000070a59addb9a4  vmovaps xmm4, [rsp+0x40]
000070a59addb9aa  vmovaps xmm5, [rsp+0x50]
000070a59addb9b0  vmovaps xmm6, [rsp+0x60]
000070a59addb9b6  vmovaps xmm7, [rsp+0x70]
000070a59addb9bc  vmovaps xmm8, [rsp+0x80]
000070a59addb9c5  vmovaps xmm9, [rsp+0x90]
000070a59addb9ce  vmovaps xmm11, [rsp+0xA0]
000070a59addb9d7  vmovaps xmm12, [rsp+0xB0]
000070a59addb9e0  vmovaps xmm13, [rsp+0xC0]
000070a59addb9e9  vmovaps xmm14, [rsp+0xD0]
000070a59addb9f2  vmovaps xmm15, [rsp+0xE0]
000070a59addb9fb  add rsp, 0xF0
000070a59addba02  pop r11
000070a59addba04  pop r10
000070a59addba06  pop r9
000070a59addba08  pop r8
000070a59addba0a  pop rsi
000070a59addba0b  pop rdi
000070a59addba0c  pop rdx
000070a59addba0d  pop rcx
000070a59addba0e  pop rax
000070a59addba0f  add rsp, 0x08
000070a59addba13  jmp 0x000070A59ADDA27C
000070a59addba18  call 0x000070A59AC0D4E0
000070a59addba1d  jmp 0x000070A59ADDA289
000070a59addba22  sub rsp, 0x08
000070a59addba26  push rax
000070a59addba27  push rcx
000070a59addba28  push rdx
000070a59addba29  push rdi
000070a59addba2a  push rsi
000070a59addba2b  push r8
000070a59addba2d  push r9
000070a59addba2f  push r10
000070a59addba31  push r11
000070a59addba33  sub rsp, 0xF0
000070a59addba3a  vmovaps [rsp], xmm0
000070a59addba3f  vmovaps [rsp+0x10], xmm1
000070a59addba45  vmovaps [rsp+0x20], xmm2
000070a59addba4b  vmovaps [rsp+0x30], xmm3
000070a59addba51  vmovaps [rsp+0x40], xmm4
000070a59addba57  vmovaps [rsp+0x50], xmm6
000070a59addba5d  vmovaps [rsp+0x60], xmm7
000070a59addba63  vmovaps [rsp+0x70], xmm8
000070a59addba69  vmovaps [rsp+0x80], xmm9
000070a59addba72  vmovaps [rsp+0x90], xmm10
000070a59addba7b  vmovaps [rsp+0xA0], xmm11
000070a59addba84  vmovaps [rsp+0xB0], xmm12
000070a59addba8d  vmovaps [rsp+0xC0], xmm13
000070a59addba96  vmovaps [rsp+0xD0], xmm14
000070a59addba9f  vmovaps [rsp+0xE0], xmm15
000070a59addbaa8  sub rsp, 0x40
000070a59addbaac  lea rdi, [rsp]
000070a59addbab0  lea rsi, [rsp+0x10]
000070a59addbab5  lea rdx, [rsp+0x20]
000070a59addbaba  lea rcx, [rsp+0x30]
000070a59addbabf  mov r8d, 0x00
000070a59addbac5  lea r9, [r15+0x3A8]
000070a59addbacc  movaps [rdi], xmm5
000070a59addbacf  movaps [rsi], xmm6
000070a59addbad2  movaps [rdx], xmm7
000070a59addbad5  movaps [rcx], xmm9
000070a59addbad9  mov rax, 0x622906D8FA50
000070a59addbae3  call rax
000070a59addbae5  movaps xmm5, [rsp]
000070a59addbae9  add rsp, 0x40
000070a59addbaed  vmovaps xmm0, [rsp]
000070a59addbaf2  vmovaps xmm1, [rsp+0x10]
000070a59addbaf8  vmovaps xmm2, [rsp+0x20]
000070a59addbafe  vmovaps xmm3, [rsp+0x30]
000070a59addbb04  vmovaps xmm4, [rsp+0x40]
000070a59addbb0a  vmovaps xmm6, [rsp+0x50]
000070a59addbb10  vmovaps xmm7, [rsp+0x60]
000070a59addbb16  vmovaps xmm8, [rsp+0x70]
000070a59addbb1c  vmovaps xmm9, [rsp+0x80]
000070a59addbb25  vmovaps xmm10, [rsp+0x90]
000070a59addbb2e  vmovaps xmm11, [rsp+0xA0]
000070a59addbb37  vmovaps xmm12, [rsp+0xB0]
000070a59addbb40  vmovaps xmm13, [rsp+0xC0]
000070a59addbb49  vmovaps xmm14, [rsp+0xD0]
000070a59addbb52  vmovaps xmm15, [rsp+0xE0]
000070a59addbb5b  add rsp, 0xF0
000070a59addbb62  pop r11
000070a59addbb64  pop r10
000070a59addbb66  pop r9
000070a59addbb68  pop r8
000070a59addbb6a  pop rsi
000070a59addbb6b  pop rdi
000070a59addbb6c  pop rdx
000070a59addbb6d  pop rcx
000070a59addbb6e  pop rax
000070a59addbb6f  add rsp, 0x08
000070a59addbb73  jmp 0x000070A59ADDA2BB
000070a59addbb78  sub rsp, 0x08
000070a59addbb7c  push rax
000070a59addbb7d  push rcx
000070a59addbb7e  push rdx
000070a59addbb7f  push rdi
000070a59addbb80  push rsi
000070a59addbb81  push r8
000070a59addbb83  push r9
000070a59addbb85  push r10
000070a59addbb87  push r11
000070a59addbb89  sub rsp, 0xF0
000070a59addbb90  vmovaps [rsp], xmm0
000070a59addbb95  vmovaps [rsp+0x10], xmm1
000070a59addbb9b  vmovaps [rsp+0x20], xmm2
000070a59addbba1  vmovaps [rsp+0x30], xmm3
000070a59addbba7  vmovaps [rsp+0x40], xmm4
000070a59addbbad  vmovaps [rsp+0x50], xmm5
000070a59addbbb3  vmovaps [rsp+0x60], xmm6
000070a59addbbb9  vmovaps [rsp+0x70], xmm8
000070a59addbbbf  vmovaps [rsp+0x80], xmm9
000070a59addbbc8  vmovaps [rsp+0x90], xmm10
000070a59addbbd1  vmovaps [rsp+0xA0], xmm11
000070a59addbbda  vmovaps [rsp+0xB0], xmm12
000070a59addbbe3  vmovaps [rsp+0xC0], xmm13
000070a59addbbec  vmovaps [rsp+0xD0], xmm14
000070a59addbbf5  vmovaps [rsp+0xE0], xmm15
000070a59addbbfe  sub rsp, 0x40
000070a59addbc02  lea rdi, [rsp]
000070a59addbc06  lea rsi, [rsp+0x10]
000070a59addbc0b  lea rdx, [rsp+0x20]
000070a59addbc10  lea rcx, [rsp+0x30]
000070a59addbc15  mov r8d, 0x00
000070a59addbc1b  lea r9, [r15+0x3A8]
000070a59addbc22  movaps [rdi], xmm7
000070a59addbc25  movaps [rsi], xmm13
000070a59addbc29  movaps [rdx], xmm1
000070a59addbc2c  movaps [rcx], xmm9
000070a59addbc30  mov rax, 0x622906D8FA50
000070a59addbc3a  call rax
000070a59addbc3c  movaps xmm7, [rsp]
000070a59addbc40  add rsp, 0x40
000070a59addbc44  vmovaps xmm0, [rsp]
000070a59addbc49  vmovaps xmm1, [rsp+0x10]
000070a59addbc4f  vmovaps xmm2, [rsp+0x20]
000070a59addbc55  vmovaps xmm3, [rsp+0x30]
000070a59addbc5b  vmovaps xmm4, [rsp+0x40]
000070a59addbc61  vmovaps xmm5, [rsp+0x50]
000070a59addbc67  vmovaps xmm6, [rsp+0x60]
000070a59addbc6d  vmovaps xmm8, [rsp+0x70]
000070a59addbc73  vmovaps xmm9, [rsp+0x80]
000070a59addbc7c  vmovaps xmm10, [rsp+0x90]
000070a59addbc85  vmovaps xmm11, [rsp+0xA0]
000070a59addbc8e  vmovaps xmm12, [rsp+0xB0]
000070a59addbc97  vmovaps xmm13, [rsp+0xC0]
000070a59addbca0  vmovaps xmm14, [rsp+0xD0]
000070a59addbca9  vmovaps xmm15, [rsp+0xE0]
000070a59addbcb2  add rsp, 0xF0
000070a59addbcb9  pop r11
000070a59addbcbb  pop r10
000070a59addbcbd  pop r9
000070a59addbcbf  pop r8
000070a59addbcc1  pop rsi
000070a59addbcc2  pop rdi
000070a59addbcc3  pop rdx
000070a59addbcc4  pop rcx
000070a59addbcc5  pop rax
000070a59addbcc6  add rsp, 0x08
000070a59addbcca  jmp 0x000070A59ADDA2E0
000070a59addbccf  call 0x000070A59AC0C260
000070a59addbcd4  jmp 0x000070A59ADDA303
000070a59addbcd9  call 0x000070A59AC07890
000070a59addbcde  jmp 0x000070A59ADDA30D
000070a59addbce3  sub rsp, 0x08
000070a59addbce7  push rax
000070a59addbce8  push rcx
000070a59addbce9  push rdx
000070a59addbcea  push rdi
000070a59addbceb  push rsi
000070a59addbcec  push r8
000070a59addbcee  push r9
000070a59addbcf0  push r10
000070a59addbcf2  push r11
000070a59addbcf4  sub rsp, 0xF0
000070a59addbcfb  vmovaps [rsp], xmm0
000070a59addbd00  vmovaps [rsp+0x10], xmm1
000070a59addbd06  vmovaps [rsp+0x20], xmm3
000070a59addbd0c  vmovaps [rsp+0x30], xmm4
000070a59addbd12  vmovaps [rsp+0x40], xmm5
000070a59addbd18  vmovaps [rsp+0x50], xmm6
000070a59addbd1e  vmovaps [rsp+0x60], xmm7
000070a59addbd24  vmovaps [rsp+0x70], xmm8
000070a59addbd2a  vmovaps [rsp+0x80], xmm9
000070a59addbd33  vmovaps [rsp+0x90], xmm10
000070a59addbd3c  vmovaps [rsp+0xA0], xmm11
000070a59addbd45  vmovaps [rsp+0xB0], xmm12
000070a59addbd4e  vmovaps [rsp+0xC0], xmm13
000070a59addbd57  vmovaps [rsp+0xD0], xmm14
000070a59addbd60  vmovaps [rsp+0xE0], xmm15
000070a59addbd69  sub rsp, 0x40
000070a59addbd6d  lea rdi, [rsp]
000070a59addbd71  lea rsi, [rsp+0x10]
000070a59addbd76  lea rdx, [rsp+0x20]
000070a59addbd7b  lea rcx, [rsp+0x30]
000070a59addbd80  mov r8d, 0x00
000070a59addbd86  lea r9, [r15+0x3A8]
000070a59addbd8d  movaps [rdi], xmm2
000070a59addbd90  movaps [rsi], xmm12
000070a59addbd94  movaps [rdx], xmm6
000070a59addbd97  movaps [rcx], xmm3
000070a59addbd9a  mov rax, 0x622906D8FA50
000070a59addbda4  call rax
000070a59addbda6  movaps xmm2, [rsp]
000070a59addbdaa  add rsp, 0x40
000070a59addbdae  vmovaps xmm0, [rsp]
000070a59addbdb3  vmovaps xmm1, [rsp+0x10]
000070a59addbdb9  vmovaps xmm3, [rsp+0x20]
000070a59addbdbf  vmovaps xmm4, [rsp+0x30]
000070a59addbdc5  vmovaps xmm5, [rsp+0x40]
000070a59addbdcb  vmovaps xmm6, [rsp+0x50]
000070a59addbdd1  vmovaps xmm7, [rsp+0x60]
000070a59addbdd7  vmovaps xmm8, [rsp+0x70]
000070a59addbddd  vmovaps xmm9, [rsp+0x80]
000070a59addbde6  vmovaps xmm10, [rsp+0x90]
000070a59addbdef  vmovaps xmm11, [rsp+0xA0]
000070a59addbdf8  vmovaps xmm12, [rsp+0xB0]
000070a59addbe01  vmovaps xmm13, [rsp+0xC0]
000070a59addbe0a  vmovaps xmm14, [rsp+0xD0]
000070a59addbe13  vmovaps xmm15, [rsp+0xE0]
000070a59addbe1c  add rsp, 0xF0
000070a59addbe23  pop r11
000070a59addbe25  pop r10
000070a59addbe27  pop r9
000070a59addbe29  pop r8
000070a59addbe2b  pop rsi
000070a59addbe2c  pop rdi
000070a59addbe2d  pop rdx
000070a59addbe2e  pop rcx
000070a59addbe2f  pop rax
000070a59addbe30  add rsp, 0x08
000070a59addbe34  jmp 0x000070A59ADDA353
000070a59addbe39  sub rsp, 0x08
000070a59addbe3d  push rax
000070a59addbe3e  push rcx
000070a59addbe3f  push rdx
000070a59addbe40  push rdi
000070a59addbe41  push rsi
000070a59addbe42  push r8
000070a59addbe44  push r9
000070a59addbe46  push r10
000070a59addbe48  push r11
000070a59addbe4a  sub rsp, 0xF0
000070a59addbe51  vmovaps [rsp], xmm0
000070a59addbe56  vmovaps [rsp+0x10], xmm1
000070a59addbe5c  vmovaps [rsp+0x20], xmm2
000070a59addbe62  vmovaps [rsp+0x30], xmm3
000070a59addbe68  vmovaps [rsp+0x40], xmm4
000070a59addbe6e  vmovaps [rsp+0x50], xmm5
000070a59addbe74  vmovaps [rsp+0x60], xmm7
000070a59addbe7a  vmovaps [rsp+0x70], xmm8
000070a59addbe80  vmovaps [rsp+0x80], xmm9
000070a59addbe89  vmovaps [rsp+0x90], xmm10
000070a59addbe92  vmovaps [rsp+0xA0], xmm11
000070a59addbe9b  vmovaps [rsp+0xB0], xmm12
000070a59addbea4  vmovaps [rsp+0xC0], xmm13
000070a59addbead  vmovaps [rsp+0xD0], xmm14
000070a59addbeb6  vmovaps [rsp+0xE0], xmm15
000070a59addbebf  sub rsp, 0x40
000070a59addbec3  lea rdi, [rsp]
000070a59addbec7  lea rsi, [rsp+0x10]
000070a59addbecc  lea rdx, [rsp+0x20]
000070a59addbed1  lea rcx, [rsp+0x30]
000070a59addbed6  mov r8d, 0x00
000070a59addbedc  lea r9, [r15+0x3A8]
000070a59addbee3  movaps [rdi], xmm6
000070a59addbee6  movaps [rsi], xmm10
000070a59addbeea  movaps [rdx], xmm12
000070a59addbeee  movaps [rcx], xmm1
000070a59addbef1  mov rax, 0x622906D8FA50
000070a59addbefb  call rax
000070a59addbefd  movaps xmm6, [rsp]
000070a59addbf01  add rsp, 0x40
000070a59addbf05  vmovaps xmm0, [rsp]
000070a59addbf0a  vmovaps xmm1, [rsp+0x10]
000070a59addbf10  vmovaps xmm2, [rsp+0x20]
000070a59addbf16  vmovaps xmm3, [rsp+0x30]
000070a59addbf1c  vmovaps xmm4, [rsp+0x40]
000070a59addbf22  vmovaps xmm5, [rsp+0x50]
000070a59addbf28  vmovaps xmm7, [rsp+0x60]
000070a59addbf2e  vmovaps xmm8, [rsp+0x70]
000070a59addbf34  vmovaps xmm9, [rsp+0x80]
000070a59addbf3d  vmovaps xmm10, [rsp+0x90]
000070a59addbf46  vmovaps xmm11, [rsp+0xA0]
000070a59addbf4f  vmovaps xmm12, [rsp+0xB0]
000070a59addbf58  vmovaps xmm13, [rsp+0xC0]
000070a59addbf61  vmovaps xmm14, [rsp+0xD0]
000070a59addbf6a  vmovaps xmm15, [rsp+0xE0]
000070a59addbf73  add rsp, 0xF0
000070a59addbf7a  pop r11
000070a59addbf7c  pop r10
000070a59addbf7e  pop r9
000070a59addbf80  pop r8
000070a59addbf82  pop rsi
000070a59addbf83  pop rdi
000070a59addbf84  pop rdx
000070a59addbf85  pop rcx
000070a59addbf86  pop rax
000070a59addbf87  add rsp, 0x08
000070a59addbf8b  jmp 0x000070A59ADDA381
000070a59addbf90  sub rsp, 0x08
000070a59addbf94  push rax
000070a59addbf95  push rcx
000070a59addbf96  push rdx
000070a59addbf97  push rdi
000070a59addbf98  push rsi
000070a59addbf99  push r8
000070a59addbf9b  push r9
000070a59addbf9d  push r10
000070a59addbf9f  push r11
000070a59addbfa1  sub rsp, 0xF0
000070a59addbfa8  vmovaps [rsp], xmm0
000070a59addbfad  vmovaps [rsp+0x10], xmm1
000070a59addbfb3  vmovaps [rsp+0x20], xmm2
000070a59addbfb9  vmovaps [rsp+0x30], xmm3
000070a59addbfbf  vmovaps [rsp+0x40], xmm4
000070a59addbfc5  vmovaps [rsp+0x50], xmm5
000070a59addbfcb  vmovaps [rsp+0x60], xmm6
000070a59addbfd1  vmovaps [rsp+0x70], xmm7
000070a59addbfd7  vmovaps [rsp+0x80], xmm8
000070a59addbfe0  vmovaps [rsp+0x90], xmm9
000070a59addbfe9  vmovaps [rsp+0xA0], xmm11
000070a59addbff2  vmovaps [rsp+0xB0], xmm12
000070a59addbffb  vmovaps [rsp+0xC0], xmm13
000070a59addc004  vmovaps [rsp+0xD0], xmm14
000070a59addc00d  vmovaps [rsp+0xE0], xmm15
000070a59addc016  sub rsp, 0x40
000070a59addc01a  lea rdi, [rsp]
000070a59addc01e  lea rsi, [rsp+0x10]
000070a59addc023  lea rdx, [rsp+0x20]
000070a59addc028  lea rcx, [rsp+0x30]
000070a59addc02d  mov r8d, 0x00
000070a59addc033  lea r9, [r15+0x3A8]
000070a59addc03a  movaps [rdi], xmm10
000070a59addc03e  movaps [rsi], xmm5
000070a59addc041  movaps [rdx], xmm12
000070a59addc045  movaps [rcx], xmm1
000070a59addc048  mov rax, 0x622906D8FA50
000070a59addc052  call rax
000070a59addc054  movaps xmm10, [rsp]
000070a59addc059  add rsp, 0x40
000070a59addc05d  vmovaps xmm0, [rsp]
000070a59addc062  vmovaps xmm1, [rsp+0x10]
000070a59addc068  vmovaps xmm2, [rsp+0x20]
000070a59addc06e  vmovaps xmm3, [rsp+0x30]
000070a59addc074  vmovaps xmm4, [rsp+0x40]
000070a59addc07a  vmovaps xmm5, [rsp+0x50]
000070a59addc080  vmovaps xmm6, [rsp+0x60]
000070a59addc086  vmovaps xmm7, [rsp+0x70]
000070a59addc08c  vmovaps xmm8, [rsp+0x80]
000070a59addc095  vmovaps xmm9, [rsp+0x90]
000070a59addc09e  vmovaps xmm11, [rsp+0xA0]
000070a59addc0a7  vmovaps xmm12, [rsp+0xB0]
000070a59addc0b0  vmovaps xmm13, [rsp+0xC0]
000070a59addc0b9  vmovaps xmm14, [rsp+0xD0]
000070a59addc0c2  vmovaps xmm15, [rsp+0xE0]
000070a59addc0cb  add rsp, 0xF0
000070a59addc0d2  pop r11
000070a59addc0d4  pop r10
000070a59addc0d6  pop r9
000070a59addc0d8  pop r8
000070a59addc0da  pop rsi
000070a59addc0db  pop rdi
000070a59addc0dc  pop rdx
000070a59addc0dd  pop rcx
000070a59addc0de  pop rax
000070a59addc0df  add rsp, 0x08
000070a59addc0e3  jmp 0x000070A59ADDA3B0
000070a59addc0e8  sub rsp, 0x08
000070a59addc0ec  push rax
000070a59addc0ed  push rcx
000070a59addc0ee  push rdx
000070a59addc0ef  push rdi
000070a59addc0f0  push rsi
000070a59addc0f1  push r8
000070a59addc0f3  push r9
000070a59addc0f5  push r10
000070a59addc0f7  push r11
000070a59addc0f9  sub rsp, 0xF0
000070a59addc100  vmovaps [rsp], xmm0
000070a59addc105  vmovaps [rsp+0x10], xmm1
000070a59addc10b  vmovaps [rsp+0x20], xmm2
000070a59addc111  vmovaps [rsp+0x30], xmm3
000070a59addc117  vmovaps [rsp+0x40], xmm4
000070a59addc11d  vmovaps [rsp+0x50], xmm5
000070a59addc123  vmovaps [rsp+0x60], xmm6
000070a59addc129  vmovaps [rsp+0x70], xmm7
000070a59addc12f  vmovaps [rsp+0x80], xmm8
000070a59addc138  vmovaps [rsp+0x90], xmm9
000070a59addc141  vmovaps [rsp+0xA0], xmm10
000070a59addc14a  vmovaps [rsp+0xB0], xmm11
000070a59addc153  vmovaps [rsp+0xC0], xmm13
000070a59addc15c  vmovaps [rsp+0xD0], xmm14
000070a59addc165  vmovaps [rsp+0xE0], xmm15
000070a59addc16e  sub rsp, 0x40
000070a59addc172  lea rdi, [rsp]
000070a59addc176  lea rsi, [rsp+0x10]
000070a59addc17b  lea rdx, [rsp+0x20]
000070a59addc180  lea rcx, [rsp+0x30]
000070a59addc185  mov r8d, 0x00
000070a59addc18b  lea r9, [r15+0x3A8]
000070a59addc192  movaps [rdi], xmm12
000070a59addc196  movaps [rsi], xmm7
000070a59addc199  movaps [rdx], xmm15
000070a59addc19d  movaps [rcx], xmm1
000070a59addc1a0  mov rax, 0x622906D8FA50
000070a59addc1aa  call rax
000070a59addc1ac  movaps xmm12, [rsp]
000070a59addc1b1  add rsp, 0x40
000070a59addc1b5  vmovaps xmm0, [rsp]
000070a59addc1ba  vmovaps xmm1, [rsp+0x10]
000070a59addc1c0  vmovaps xmm2, [rsp+0x20]
000070a59addc1c6  vmovaps xmm3, [rsp+0x30]
000070a59addc1cc  vmovaps xmm4, [rsp+0x40]
000070a59addc1d2  vmovaps xmm5, [rsp+0x50]
000070a59addc1d8  vmovaps xmm6, [rsp+0x60]
000070a59addc1de  vmovaps xmm7, [rsp+0x70]
000070a59addc1e4  vmovaps xmm8, [rsp+0x80]
000070a59addc1ed  vmovaps xmm9, [rsp+0x90]
000070a59addc1f6  vmovaps xmm10, [rsp+0xA0]
000070a59addc1ff  vmovaps xmm11, [rsp+0xB0]
000070a59addc208  vmovaps xmm13, [rsp+0xC0]
000070a59addc211  vmovaps xmm14, [rsp+0xD0]
000070a59addc21a  vmovaps xmm15, [rsp+0xE0]
000070a59addc223  add rsp, 0xF0
000070a59addc22a  pop r11
000070a59addc22c  pop r10
000070a59addc22e  pop r9
000070a59addc230  pop r8
000070a59addc232  pop rsi
000070a59addc233  pop rdi
000070a59addc234  pop rdx
000070a59addc235  pop rcx
000070a59addc236  pop rax
000070a59addc237  add rsp, 0x08
000070a59addc23b  jmp 0x000070A59ADDA3D9
000070a59addc240  call 0x000070A59ABFF430
000070a59addc245  jmp 0x000070A59ADDA3E3
000070a59addc24a  call 0x000070A59AC0E760
000070a59addc24f  jmp 0x000070A59ADDA3ED
000070a59addc254  sub rsp, 0x08
000070a59addc258  push rax
000070a59addc259  push rcx
000070a59addc25a  push rdx
000070a59addc25b  push rdi
000070a59addc25c  push rsi
000070a59addc25d  push r8
000070a59addc25f  push r9
000070a59addc261  push r10
000070a59addc263  push r11
000070a59addc265  sub rsp, 0xF0
000070a59addc26c  vmovaps [rsp], xmm0
000070a59addc271  vmovaps [rsp+0x10], xmm1
000070a59addc277  vmovaps [rsp+0x20], xmm2
000070a59addc27d  vmovaps [rsp+0x30], xmm3
000070a59addc283  vmovaps [rsp+0x40], xmm4
000070a59addc289  vmovaps [rsp+0x50], xmm5
000070a59addc28f  vmovaps [rsp+0x60], xmm6
000070a59addc295  vmovaps [rsp+0x70], xmm8
000070a59addc29b  vmovaps [rsp+0x80], xmm9
000070a59addc2a4  vmovaps [rsp+0x90], xmm10
000070a59addc2ad  vmovaps [rsp+0xA0], xmm11
000070a59addc2b6  vmovaps [rsp+0xB0], xmm12
000070a59addc2bf  vmovaps [rsp+0xC0], xmm13
000070a59addc2c8  vmovaps [rsp+0xD0], xmm14
000070a59addc2d1  vmovaps [rsp+0xE0], xmm15
000070a59addc2da  sub rsp, 0x40
000070a59addc2de  lea rdi, [rsp]
000070a59addc2e2  lea rsi, [rsp+0x10]
000070a59addc2e7  lea rdx, [rsp+0x20]
000070a59addc2ec  lea rcx, [rsp+0x30]
000070a59addc2f1  mov r8d, 0x00
000070a59addc2f7  lea r9, [r15+0x3A8]
000070a59addc2fe  movaps [rdi], xmm7
000070a59addc301  movaps [rsi], xmm2
000070a59addc304  movaps [rdx], xmm9
000070a59addc308  movaps [rcx], xmm11
000070a59addc30c  mov rax, 0x622906D8FA50
000070a59addc316  call rax
000070a59addc318  movaps xmm7, [rsp]
000070a59addc31c  add rsp, 0x40
000070a59addc320  vmovaps xmm0, [rsp]
000070a59addc325  vmovaps xmm1, [rsp+0x10]
000070a59addc32b  vmovaps xmm2, [rsp+0x20]
000070a59addc331  vmovaps xmm3, [rsp+0x30]
000070a59addc337  vmovaps xmm4, [rsp+0x40]
000070a59addc33d  vmovaps xmm5, [rsp+0x50]
000070a59addc343  vmovaps xmm6, [rsp+0x60]
000070a59addc349  vmovaps xmm8, [rsp+0x70]
000070a59addc34f  vmovaps xmm9, [rsp+0x80]
000070a59addc358  vmovaps xmm10, [rsp+0x90]
000070a59addc361  vmovaps xmm11, [rsp+0xA0]
000070a59addc36a  vmovaps xmm12, [rsp+0xB0]
000070a59addc373  vmovaps xmm13, [rsp+0xC0]
000070a59addc37c  vmovaps xmm14, [rsp+0xD0]
000070a59addc385  vmovaps xmm15, [rsp+0xE0]
000070a59addc38e  add rsp, 0xF0
000070a59addc395  pop r11
000070a59addc397  pop r10
000070a59addc399  pop r9
000070a59addc39b  pop r8
000070a59addc39d  pop rsi
000070a59addc39e  pop rdi
000070a59addc39f  pop rdx
000070a59addc3a0  pop rcx
000070a59addc3a1  pop rax
000070a59addc3a2  add rsp, 0x08
000070a59addc3a6  jmp 0x000070A59ADDA421
000070a59addc3ab  sub rsp, 0x08
000070a59addc3af  push rax
000070a59addc3b0  push rcx
000070a59addc3b1  push rdx
000070a59addc3b2  push rdi
000070a59addc3b3  push rsi
000070a59addc3b4  push r8
000070a59addc3b6  push r9
000070a59addc3b8  push r10
000070a59addc3ba  push r11
000070a59addc3bc  sub rsp, 0xF0
000070a59addc3c3  vmovaps [rsp], xmm0
000070a59addc3c8  vmovaps [rsp+0x10], xmm1
000070a59addc3ce  vmovaps [rsp+0x20], xmm2
000070a59addc3d4  vmovaps [rsp+0x30], xmm3
000070a59addc3da  vmovaps [rsp+0x40], xmm4
000070a59addc3e0  vmovaps [rsp+0x50], xmm5
000070a59addc3e6  vmovaps [rsp+0x60], xmm6
000070a59addc3ec  vmovaps [rsp+0x70], xmm7
000070a59addc3f2  vmovaps [rsp+0x80], xmm8
000070a59addc3fb  vmovaps [rsp+0x90], xmm10
000070a59addc404  vmovaps [rsp+0xA0], xmm11
000070a59addc40d  vmovaps [rsp+0xB0], xmm12
000070a59addc416  vmovaps [rsp+0xC0], xmm13
000070a59addc41f  vmovaps [rsp+0xD0], xmm14
000070a59addc428  vmovaps [rsp+0xE0], xmm15
000070a59addc431  sub rsp, 0x40
000070a59addc435  lea rdi, [rsp]
000070a59addc439  lea rsi, [rsp+0x10]
000070a59addc43e  lea rdx, [rsp+0x20]
000070a59addc443  lea rcx, [rsp+0x30]
000070a59addc448  mov r8d, 0x00
000070a59addc44e  lea r9, [r15+0x3A8]
000070a59addc455  movaps [rdi], xmm9
000070a59addc459  movaps [rsi], xmm6
000070a59addc45c  movaps [rdx], xmm1
000070a59addc45f  movaps [rcx], xmm11
000070a59addc463  mov rax, 0x622906D8FA50
000070a59addc46d  call rax
000070a59addc46f  movaps xmm9, [rsp]
000070a59addc474  add rsp, 0x40
000070a59addc478  vmovaps xmm0, [rsp]
000070a59addc47d  vmovaps xmm1, [rsp+0x10]
000070a59addc483  vmovaps xmm2, [rsp+0x20]
000070a59addc489  vmovaps xmm3, [rsp+0x30]
000070a59addc48f  vmovaps xmm4, [rsp+0x40]
000070a59addc495  vmovaps xmm5, [rsp+0x50]
000070a59addc49b  vmovaps xmm6, [rsp+0x60]
000070a59addc4a1  vmovaps xmm7, [rsp+0x70]
000070a59addc4a7  vmovaps xmm8, [rsp+0x80]
000070a59addc4b0  vmovaps xmm10, [rsp+0x90]
000070a59addc4b9  vmovaps xmm11, [rsp+0xA0]
000070a59addc4c2  vmovaps xmm12, [rsp+0xB0]
000070a59addc4cb  vmovaps xmm13, [rsp+0xC0]
000070a59addc4d4  vmovaps xmm14, [rsp+0xD0]
000070a59addc4dd  vmovaps xmm15, [rsp+0xE0]
000070a59addc4e6  add rsp, 0xF0
000070a59addc4ed  pop r11
000070a59addc4ef  pop r10
000070a59addc4f1  pop r9
000070a59addc4f3  pop r8
000070a59addc4f5  pop rsi
000070a59addc4f6  pop rdi
000070a59addc4f7  pop rdx
000070a59addc4f8  pop rcx
000070a59addc4f9  pop rax
000070a59addc4fa  add rsp, 0x08
000070a59addc4fe  jmp 0x000070A59ADDA447
000070a59addc503  sub rsp, 0x08
000070a59addc507  push rax
000070a59addc508  push rcx
000070a59addc509  push rdx
000070a59addc50a  push rdi
000070a59addc50b  push rsi
000070a59addc50c  push r8
000070a59addc50e  push r9
000070a59addc510  push r10
000070a59addc512  push r11
000070a59addc514  sub rsp, 0xF0
000070a59addc51b  vmovaps [rsp], xmm0
000070a59addc520  vmovaps [rsp+0x10], xmm1
000070a59addc526  vmovaps [rsp+0x20], xmm2
000070a59addc52c  vmovaps [rsp+0x30], xmm3
000070a59addc532  vmovaps [rsp+0x40], xmm4
000070a59addc538  vmovaps [rsp+0x50], xmm5
000070a59addc53e  vmovaps [rsp+0x60], xmm6
000070a59addc544  vmovaps [rsp+0x70], xmm7
000070a59addc54a  vmovaps [rsp+0x80], xmm8
000070a59addc553  vmovaps [rsp+0x90], xmm9
000070a59addc55c  vmovaps [rsp+0xA0], xmm10
000070a59addc565  vmovaps [rsp+0xB0], xmm12
000070a59addc56e  vmovaps [rsp+0xC0], xmm13
000070a59addc577  vmovaps [rsp+0xD0], xmm14
000070a59addc580  vmovaps [rsp+0xE0], xmm15
000070a59addc589  sub rsp, 0x40
000070a59addc58d  lea rdi, [rsp]
000070a59addc591  lea rsi, [rsp+0x10]
000070a59addc596  lea rdx, [rsp+0x20]
000070a59addc59b  lea rcx, [rsp+0x30]
000070a59addc5a0  mov r8d, 0x00
000070a59addc5a6  lea r9, [r15+0x3A8]
000070a59addc5ad  movaps [rdi], xmm11
000070a59addc5b1  movaps [rsi], xmm10
000070a59addc5b5  movaps [rdx], xmm8
000070a59addc5b9  movaps [rcx], xmm1
000070a59addc5bc  mov rax, 0x622906D8FA50
000070a59addc5c6  call rax
000070a59addc5c8  movaps xmm11, [rsp]
000070a59addc5cd  add rsp, 0x40
000070a59addc5d1  vmovaps xmm0, [rsp]
000070a59addc5d6  vmovaps xmm1, [rsp+0x10]
000070a59addc5dc  vmovaps xmm2, [rsp+0x20]
000070a59addc5e2  vmovaps xmm3, [rsp+0x30]
000070a59addc5e8  vmovaps xmm4, [rsp+0x40]
000070a59addc5ee  vmovaps xmm5, [rsp+0x50]
000070a59addc5f4  vmovaps xmm6, [rsp+0x60]
000070a59addc5fa  vmovaps xmm7, [rsp+0x70]
000070a59addc600  vmovaps xmm8, [rsp+0x80]
000070a59addc609  vmovaps xmm9, [rsp+0x90]
000070a59addc612  vmovaps xmm10, [rsp+0xA0]
000070a59addc61b  vmovaps xmm12, [rsp+0xB0]
000070a59addc624  vmovaps xmm13, [rsp+0xC0]
000070a59addc62d  vmovaps xmm14, [rsp+0xD0]
000070a59addc636  vmovaps xmm15, [rsp+0xE0]
000070a59addc63f  add rsp, 0xF0
000070a59addc646  pop r11
000070a59addc648  pop r10
000070a59addc64a  pop r9
000070a59addc64c  pop r8
000070a59addc64e  pop rsi
000070a59addc64f  pop rdi
000070a59addc650  pop rdx
000070a59addc651  pop rcx
000070a59addc652  pop rax
000070a59addc653  add rsp, 0x08
000070a59addc657  jmp 0x000070A59ADDA46D
000070a59addc65c  sub rsp, 0x08
000070a59addc660  push rax
000070a59addc661  push rcx
000070a59addc662  push rdx
000070a59addc663  push rdi
000070a59addc664  push rsi
000070a59addc665  push r8
000070a59addc667  push r9
000070a59addc669  push r10
000070a59addc66b  push r11
000070a59addc66d  sub rsp, 0xF0
000070a59addc674  vmovaps [rsp], xmm0
000070a59addc679  vmovaps [rsp+0x10], xmm1
000070a59addc67f  vmovaps [rsp+0x20], xmm2
000070a59addc685  vmovaps [rsp+0x30], xmm3
000070a59addc68b  vmovaps [rsp+0x40], xmm4
000070a59addc691  vmovaps [rsp+0x50], xmm5
000070a59addc697  vmovaps [rsp+0x60], xmm6
000070a59addc69d  vmovaps [rsp+0x70], xmm7
000070a59addc6a3  vmovaps [rsp+0x80], xmm8
000070a59addc6ac  vmovaps [rsp+0x90], xmm9
000070a59addc6b5  vmovaps [rsp+0xA0], xmm11
000070a59addc6be  vmovaps [rsp+0xB0], xmm12
000070a59addc6c7  vmovaps [rsp+0xC0], xmm13
000070a59addc6d0  vmovaps [rsp+0xD0], xmm14
000070a59addc6d9  vmovaps [rsp+0xE0], xmm15
000070a59addc6e2  sub rsp, 0x40
000070a59addc6e6  lea rdi, [rsp]
000070a59addc6ea  lea rsi, [rsp+0x10]
000070a59addc6ef  lea rdx, [rsp+0x20]
000070a59addc6f4  lea rcx, [rsp+0x30]
000070a59addc6f9  mov r8d, 0x00
000070a59addc6ff  lea r9, [r15+0x3A8]
000070a59addc706  movaps [rdi], xmm10
000070a59addc70a  movaps [rsi], xmm12
000070a59addc70e  movaps [rdx], xmm13
000070a59addc712  movaps [rcx], xmm1
000070a59addc715  mov rax, 0x622906D8FA50
000070a59addc71f  call rax
000070a59addc721  movaps xmm10, [rsp]
000070a59addc726  add rsp, 0x40
000070a59addc72a  vmovaps xmm0, [rsp]
000070a59addc72f  vmovaps xmm1, [rsp+0x10]
000070a59addc735  vmovaps xmm2, [rsp+0x20]
000070a59addc73b  vmovaps xmm3, [rsp+0x30]
000070a59addc741  vmovaps xmm4, [rsp+0x40]
000070a59addc747  vmovaps xmm5, [rsp+0x50]
000070a59addc74d  vmovaps xmm6, [rsp+0x60]
000070a59addc753  vmovaps xmm7, [rsp+0x70]
000070a59addc759  vmovaps xmm8, [rsp+0x80]
000070a59addc762  vmovaps xmm9, [rsp+0x90]
000070a59addc76b  vmovaps xmm11, [rsp+0xA0]
000070a59addc774  vmovaps xmm12, [rsp+0xB0]
000070a59addc77d  vmovaps xmm13, [rsp+0xC0]
000070a59addc786  vmovaps xmm14, [rsp+0xD0]
000070a59addc78f  vmovaps xmm15, [rsp+0xE0]
000070a59addc798  add rsp, 0xF0
000070a59addc79f  pop r11
000070a59addc7a1  pop r10
000070a59addc7a3  pop r9
000070a59addc7a5  pop r8
000070a59addc7a7  pop rsi
000070a59addc7a8  pop rdi
000070a59addc7a9  pop rdx
000070a59addc7aa  pop rcx
000070a59addc7ab  pop rax
000070a59addc7ac  add rsp, 0x08
000070a59addc7b0  jmp 0x000070A59ADDA493
000070a59addc7b5  call 0x000070A59ABFF430
000070a59addc7ba  jmp 0x000070A59ADDA49D
000070a59addc7bf  call 0x000070A59AC0C260
000070a59addc7c4  jmp 0x000070A59ADDA4A7
000070a59addc7c9  sub rsp, 0x08
000070a59addc7cd  push rax
000070a59addc7ce  push rcx
000070a59addc7cf  push rdx
000070a59addc7d0  push rdi
000070a59addc7d1  push rsi
000070a59addc7d2  push r8
000070a59addc7d4  push r9
000070a59addc7d6  push r10
000070a59addc7d8  push r11
000070a59addc7da  sub rsp, 0xF0
000070a59addc7e1  vmovaps [rsp], xmm0
000070a59addc7e6  vmovaps [rsp+0x10], xmm1
000070a59addc7ec  vmovaps [rsp+0x20], xmm2
000070a59addc7f2  vmovaps [rsp+0x30], xmm3
000070a59addc7f8  vmovaps [rsp+0x40], xmm4
000070a59addc7fe  vmovaps [rsp+0x50], xmm5
000070a59addc804  vmovaps [rsp+0x60], xmm6
000070a59addc80a  vmovaps [rsp+0x70], xmm7
000070a59addc810  vmovaps [rsp+0x80], xmm9
000070a59addc819  vmovaps [rsp+0x90], xmm10
000070a59addc822  vmovaps [rsp+0xA0], xmm11
000070a59addc82b  vmovaps [rsp+0xB0], xmm12
000070a59addc834  vmovaps [rsp+0xC0], xmm13
000070a59addc83d  vmovaps [rsp+0xD0], xmm14
000070a59addc846  vmovaps [rsp+0xE0], xmm15
000070a59addc84f  sub rsp, 0x40
000070a59addc853  lea rdi, [rsp]
000070a59addc857  lea rsi, [rsp+0x10]
000070a59addc85c  lea rdx, [rsp+0x20]
000070a59addc861  lea rcx, [rsp+0x30]
000070a59addc866  mov r8d, 0x00
000070a59addc86c  lea r9, [r15+0x3A8]
000070a59addc873  movaps [rdi], xmm8
000070a59addc877  movaps [rsi], xmm7
000070a59addc87a  movaps [rdx], xmm4
000070a59addc87d  movaps [rcx], xmm12
000070a59addc881  mov rax, 0x622906D8FA50
000070a59addc88b  call rax
000070a59addc88d  movaps xmm8, [rsp]
000070a59addc892  add rsp, 0x40
000070a59addc896  vmovaps xmm0, [rsp]
000070a59addc89b  vmovaps xmm1, [rsp+0x10]
000070a59addc8a1  vmovaps xmm2, [rsp+0x20]
000070a59addc8a7  vmovaps xmm3, [rsp+0x30]
000070a59addc8ad  vmovaps xmm4, [rsp+0x40]
000070a59addc8b3  vmovaps xmm5, [rsp+0x50]
000070a59addc8b9  vmovaps xmm6, [rsp+0x60]
000070a59addc8bf  vmovaps xmm7, [rsp+0x70]
000070a59addc8c5  vmovaps xmm9, [rsp+0x80]
000070a59addc8ce  vmovaps xmm10, [rsp+0x90]
000070a59addc8d7  vmovaps xmm11, [rsp+0xA0]
000070a59addc8e0  vmovaps xmm12, [rsp+0xB0]
000070a59addc8e9  vmovaps xmm13, [rsp+0xC0]
000070a59addc8f2  vmovaps xmm14, [rsp+0xD0]
000070a59addc8fb  vmovaps xmm15, [rsp+0xE0]
000070a59addc904  add rsp, 0xF0
000070a59addc90b  pop r11
000070a59addc90d  pop r10
000070a59addc90f  pop r9
000070a59addc911  pop r8
000070a59addc913  pop rsi
000070a59addc914  pop rdi
000070a59addc915  pop rdx
000070a59addc916  pop rcx
000070a59addc917  pop rax
000070a59addc918  add rsp, 0x08
000070a59addc91c  jmp 0x000070A59ADDA4D0
000070a59addc921  sub rsp, 0x08
000070a59addc925  push rax
000070a59addc926  push rcx
000070a59addc927  push rdx
000070a59addc928  push rdi
000070a59addc929  push rsi
000070a59addc92a  push r8
000070a59addc92c  push r9
000070a59addc92e  push r10
000070a59addc930  push r11
000070a59addc932  sub rsp, 0xF0
000070a59addc939  vmovaps [rsp], xmm0
000070a59addc93e  vmovaps [rsp+0x10], xmm1
000070a59addc944  vmovaps [rsp+0x20], xmm2
000070a59addc94a  vmovaps [rsp+0x30], xmm3
000070a59addc950  vmovaps [rsp+0x40], xmm4
000070a59addc956  vmovaps [rsp+0x50], xmm5
000070a59addc95c  vmovaps [rsp+0x60], xmm6
000070a59addc962  vmovaps [rsp+0x70], xmm8
000070a59addc968  vmovaps [rsp+0x80], xmm9
000070a59addc971  vmovaps [rsp+0x90], xmm10
000070a59addc97a  vmovaps [rsp+0xA0], xmm11
000070a59addc983  vmovaps [rsp+0xB0], xmm12
000070a59addc98c  vmovaps [rsp+0xC0], xmm13
000070a59addc995  vmovaps [rsp+0xD0], xmm14
000070a59addc99e  vmovaps [rsp+0xE0], xmm15
000070a59addc9a7  sub rsp, 0x40
000070a59addc9ab  lea rdi, [rsp]
000070a59addc9af  lea rsi, [rsp+0x10]
000070a59addc9b4  lea rdx, [rsp+0x20]
000070a59addc9b9  lea rcx, [rsp+0x30]
000070a59addc9be  mov r8d, 0x00
000070a59addc9c4  lea r9, [r15+0x3A8]
000070a59addc9cb  movaps [rdi], xmm7
000070a59addc9ce  movaps [rsi], xmm9
000070a59addc9d2  movaps [rdx], xmm14
000070a59addc9d6  movaps [rcx], xmm12
000070a59addc9da  mov rax, 0x622906D8FA50
000070a59addc9e4  call rax
000070a59addc9e6  movaps xmm7, [rsp]
000070a59addc9ea  add rsp, 0x40
000070a59addc9ee  vmovaps xmm0, [rsp]
000070a59addc9f3  vmovaps xmm1, [rsp+0x10]
000070a59addc9f9  vmovaps xmm2, [rsp+0x20]
000070a59addc9ff  vmovaps xmm3, [rsp+0x30]
000070a59addca05  vmovaps xmm4, [rsp+0x40]
000070a59addca0b  vmovaps xmm5, [rsp+0x50]
000070a59addca11  vmovaps xmm6, [rsp+0x60]
000070a59addca17  vmovaps xmm8, [rsp+0x70]
000070a59addca1d  vmovaps xmm9, [rsp+0x80]
000070a59addca26  vmovaps xmm10, [rsp+0x90]
000070a59addca2f  vmovaps xmm11, [rsp+0xA0]
000070a59addca38  vmovaps xmm12, [rsp+0xB0]
000070a59addca41  vmovaps xmm13, [rsp+0xC0]
000070a59addca4a  vmovaps xmm14, [rsp+0xD0]
000070a59addca53  vmovaps xmm15, [rsp+0xE0]
000070a59addca5c  add rsp, 0xF0
000070a59addca63  pop r11
000070a59addca65  pop r10
000070a59addca67  pop r9
000070a59addca69  pop r8
000070a59addca6b  pop rsi
000070a59addca6c  pop rdi
000070a59addca6d  pop rdx
000070a59addca6e  pop rcx
000070a59addca6f  pop rax
000070a59addca70  add rsp, 0x08
000070a59addca74  jmp 0x000070A59ADDA4F8
000070a59addca79  sub rsp, 0x08
000070a59addca7d  push rax
000070a59addca7e  push rcx
000070a59addca7f  push rdx
000070a59addca80  push rdi
000070a59addca81  push rsi
000070a59addca82  push r8
000070a59addca84  push r9
000070a59addca86  push r10
000070a59addca88  push r11
000070a59addca8a  sub rsp, 0xF0
000070a59addca91  vmovaps [rsp], xmm0
000070a59addca96  vmovaps [rsp+0x10], xmm1
000070a59addca9c  vmovaps [rsp+0x20], xmm2
000070a59addcaa2  vmovaps [rsp+0x30], xmm3
000070a59addcaa8  vmovaps [rsp+0x40], xmm4
000070a59addcaae  vmovaps [rsp+0x50], xmm5
000070a59addcab4  vmovaps [rsp+0x60], xmm6
000070a59addcaba  vmovaps [rsp+0x70], xmm7
000070a59addcac0  vmovaps [rsp+0x80], xmm8
000070a59addcac9  vmovaps [rsp+0x90], xmm9
000070a59addcad2  vmovaps [rsp+0xA0], xmm10
000070a59addcadb  vmovaps [rsp+0xB0], xmm11
000070a59addcae4  vmovaps [rsp+0xC0], xmm13
000070a59addcaed  vmovaps [rsp+0xD0], xmm14
000070a59addcaf6  vmovaps [rsp+0xE0], xmm15
000070a59addcaff  sub rsp, 0x40
000070a59addcb03  lea rdi, [rsp]
000070a59addcb07  lea rsi, [rsp+0x10]
000070a59addcb0c  lea rdx, [rsp+0x20]
000070a59addcb11  lea rcx, [rsp+0x30]
000070a59addcb16  mov r8d, 0x00
000070a59addcb1c  lea r9, [r15+0x3A8]
000070a59addcb23  movaps [rdi], xmm12
000070a59addcb27  movaps [rsi], xmm11
000070a59addcb2b  movaps [rdx], xmm15
000070a59addcb2f  movaps [rcx], xmm14
000070a59addcb33  mov rax, 0x622906D8FA50
000070a59addcb3d  call rax
000070a59addcb3f  movaps xmm12, [rsp]
000070a59addcb44  add rsp, 0x40
000070a59addcb48  vmovaps xmm0, [rsp]
000070a59addcb4d  vmovaps xmm1, [rsp+0x10]
000070a59addcb53  vmovaps xmm2, [rsp+0x20]
000070a59addcb59  vmovaps xmm3, [rsp+0x30]
000070a59addcb5f  vmovaps xmm4, [rsp+0x40]
000070a59addcb65  vmovaps xmm5, [rsp+0x50]
000070a59addcb6b  vmovaps xmm6, [rsp+0x60]
000070a59addcb71  vmovaps xmm7, [rsp+0x70]
000070a59addcb77  vmovaps xmm8, [rsp+0x80]
000070a59addcb80  vmovaps xmm9, [rsp+0x90]
000070a59addcb89  vmovaps xmm10, [rsp+0xA0]
000070a59addcb92  vmovaps xmm11, [rsp+0xB0]
000070a59addcb9b  vmovaps xmm13, [rsp+0xC0]
000070a59addcba4  vmovaps xmm14, [rsp+0xD0]
000070a59addcbad  vmovaps xmm15, [rsp+0xE0]
000070a59addcbb6  add rsp, 0xF0
000070a59addcbbd  pop r11
000070a59addcbbf  pop r10
000070a59addcbc1  pop r9
000070a59addcbc3  pop r8
000070a59addcbc5  pop rsi
000070a59addcbc6  pop rdi
000070a59addcbc7  pop rdx
000070a59addcbc8  pop rcx
000070a59addcbc9  pop rax
000070a59addcbca  add rsp, 0x08
000070a59addcbce  jmp 0x000070A59ADDA521
000070a59addcbd3  sub rsp, 0x08
000070a59addcbd7  push rax
000070a59addcbd8  push rcx
000070a59addcbd9  push rdx
000070a59addcbda  push rdi
000070a59addcbdb  push rsi
000070a59addcbdc  push r8
000070a59addcbde  push r9
000070a59addcbe0  push r10
000070a59addcbe2  push r11
000070a59addcbe4  sub rsp, 0xF0
000070a59addcbeb  vmovaps [rsp], xmm0
000070a59addcbf0  vmovaps [rsp+0x10], xmm1
000070a59addcbf6  vmovaps [rsp+0x20], xmm2
000070a59addcbfc  vmovaps [rsp+0x30], xmm3
000070a59addcc02  vmovaps [rsp+0x40], xmm4
000070a59addcc08  vmovaps [rsp+0x50], xmm5
000070a59addcc0e  vmovaps [rsp+0x60], xmm6
000070a59addcc14  vmovaps [rsp+0x70], xmm7
000070a59addcc1a  vmovaps [rsp+0x80], xmm8
000070a59addcc23  vmovaps [rsp+0x90], xmm9
000070a59addcc2c  vmovaps [rsp+0xA0], xmm10
000070a59addcc35  vmovaps [rsp+0xB0], xmm12
000070a59addcc3e  vmovaps [rsp+0xC0], xmm13
000070a59addcc47  vmovaps [rsp+0xD0], xmm14
000070a59addcc50  vmovaps [rsp+0xE0], xmm15
000070a59addcc59  sub rsp, 0x40
000070a59addcc5d  lea rdi, [rsp]
000070a59addcc61  lea rsi, [rsp+0x10]
000070a59addcc66  lea rdx, [rsp+0x20]
000070a59addcc6b  lea rcx, [rsp+0x30]
000070a59addcc70  mov r8d, 0x00
000070a59addcc76  lea r9, [r15+0x3A8]
000070a59addcc7d  movaps [rdi], xmm11
000070a59addcc81  movaps [rsi], xmm10
000070a59addcc85  movaps [rdx], xmm13
000070a59addcc89  movaps [rcx], xmm15
000070a59addcc8d  mov rax, 0x622906D8FA50
000070a59addcc97  call rax
000070a59addcc99  movaps xmm11, [rsp]
000070a59addcc9e  add rsp, 0x40
000070a59addcca2  vmovaps xmm0, [rsp]
000070a59addcca7  vmovaps xmm1, [rsp+0x10]
000070a59addccad  vmovaps xmm2, [rsp+0x20]
000070a59addccb3  vmovaps xmm3, [rsp+0x30]
000070a59addccb9  vmovaps xmm4, [rsp+0x40]
000070a59addccbf  vmovaps xmm5, [rsp+0x50]
000070a59addccc5  vmovaps xmm6, [rsp+0x60]
000070a59addcccb  vmovaps xmm7, [rsp+0x70]
000070a59addccd1  vmovaps xmm8, [rsp+0x80]
000070a59addccda  vmovaps xmm9, [rsp+0x90]
000070a59addcce3  vmovaps xmm10, [rsp+0xA0]
000070a59addccec  vmovaps xmm12, [rsp+0xB0]
000070a59addccf5  vmovaps xmm13, [rsp+0xC0]
000070a59addccfe  vmovaps xmm14, [rsp+0xD0]
000070a59addcd07  vmovaps xmm15, [rsp+0xE0]
000070a59addcd10  add rsp, 0xF0
000070a59addcd17  pop r11
000070a59addcd19  pop r10
000070a59addcd1b  pop r9
000070a59addcd1d  pop r8
000070a59addcd1f  pop rsi
000070a59addcd20  pop rdi
000070a59addcd21  pop rdx
000070a59addcd22  pop rcx
000070a59addcd23  pop rax
000070a59addcd24  add rsp, 0x08
000070a59addcd28  jmp 0x000070A59ADDA54A
000070a59addcd2d  call 0x000070A59AC0E760
000070a59addcd32  jmp 0x000070A59ADDA557
000070a59addcd37  call 0x000070A59AC0D4E0
000070a59addcd3c  jmp 0x000070A59ADDA564
000070a59addcd41  sub rsp, 0x08
000070a59addcd45  push rax
000070a59addcd46  push rcx
000070a59addcd47  push rdx
000070a59addcd48  push rdi
000070a59addcd49  push rsi
000070a59addcd4a  push r8
000070a59addcd4c  push r9
000070a59addcd4e  push r10
000070a59addcd50  push r11
000070a59addcd52  sub rsp, 0xF0
000070a59addcd59  vmovaps [rsp], xmm0
000070a59addcd5e  vmovaps [rsp+0x10], xmm1
000070a59addcd64  vmovaps [rsp+0x20], xmm2
000070a59addcd6a  vmovaps [rsp+0x30], xmm3
000070a59addcd70  vmovaps [rsp+0x40], xmm4
000070a59addcd76  vmovaps [rsp+0x50], xmm5
000070a59addcd7c  vmovaps [rsp+0x60], xmm6
000070a59addcd82  vmovaps [rsp+0x70], xmm7
000070a59addcd88  vmovaps [rsp+0x80], xmm8
000070a59addcd91  vmovaps [rsp+0x90], xmm9
000070a59addcd9a  vmovaps [rsp+0xA0], xmm11
000070a59addcda3  vmovaps [rsp+0xB0], xmm12
000070a59addcdac  vmovaps [rsp+0xC0], xmm13
000070a59addcdb5  vmovaps [rsp+0xD0], xmm14
000070a59addcdbe  vmovaps [rsp+0xE0], xmm15
000070a59addcdc7  sub rsp, 0x40
000070a59addcdcb  lea rdi, [rsp]
000070a59addcdcf  lea rsi, [rsp+0x10]
000070a59addcdd4  lea rdx, [rsp+0x20]
000070a59addcdd9  lea rcx, [rsp+0x30]
000070a59addcdde  mov r8d, 0x00
000070a59addcde4  lea r9, [r15+0x3A8]
000070a59addcdeb  movaps [rdi], xmm10
000070a59addcdef  movaps [rsi], xmm8
000070a59addcdf3  movaps [rdx], xmm1
000070a59addcdf6  movaps [rcx], xmm13
000070a59addcdfa  mov rax, 0x622906D8FA50
000070a59addce04  call rax
000070a59addce06  movaps xmm10, [rsp]
000070a59addce0b  add rsp, 0x40
000070a59addce0f  vmovaps xmm0, [rsp]
000070a59addce14  vmovaps xmm1, [rsp+0x10]
000070a59addce1a  vmovaps xmm2, [rsp+0x20]
000070a59addce20  vmovaps xmm3, [rsp+0x30]
000070a59addce26  vmovaps xmm4, [rsp+0x40]
000070a59addce2c  vmovaps xmm5, [rsp+0x50]
000070a59addce32  vmovaps xmm6, [rsp+0x60]
000070a59addce38  vmovaps xmm7, [rsp+0x70]
000070a59addce3e  vmovaps xmm8, [rsp+0x80]
000070a59addce47  vmovaps xmm9, [rsp+0x90]
000070a59addce50  vmovaps xmm11, [rsp+0xA0]
000070a59addce59  vmovaps xmm12, [rsp+0xB0]
000070a59addce62  vmovaps xmm13, [rsp+0xC0]
000070a59addce6b  vmovaps xmm14, [rsp+0xD0]
000070a59addce74  vmovaps xmm15, [rsp+0xE0]
000070a59addce7d  add rsp, 0xF0
000070a59addce84  pop r11
000070a59addce86  pop r10
000070a59addce88  pop r9
000070a59addce8a  pop r8
000070a59addce8c  pop rsi
000070a59addce8d  pop rdi
000070a59addce8e  pop rdx
000070a59addce8f  pop rcx
000070a59addce90  pop rax
000070a59addce91  add rsp, 0x08
000070a59addce95  jmp 0x000070A59ADDA59A
000070a59addce9a  call 0x000070A59ABFF430
000070a59addce9f  jmp 0x000070A59ADDA5AC
000070a59addcea4  sub rsp, 0x08
000070a59addcea8  push rax
000070a59addcea9  push rcx
000070a59addceaa  push rdx
000070a59addceab  push rdi
000070a59addceac  push rsi
000070a59addcead  push r8
000070a59addceaf  push r9
000070a59addceb1  push r10
000070a59addceb3  push r11
000070a59addceb5  sub rsp, 0xF0
000070a59addcebc  vmovaps [rsp], xmm0
000070a59addcec1  vmovaps [rsp+0x10], xmm1
000070a59addcec7  vmovaps [rsp+0x20], xmm2
000070a59addcecd  vmovaps [rsp+0x30], xmm3
000070a59addced3  vmovaps [rsp+0x40], xmm4
000070a59addced9  vmovaps [rsp+0x50], xmm5
000070a59addcedf  vmovaps [rsp+0x60], xmm6
000070a59addcee5  vmovaps [rsp+0x70], xmm7
000070a59addceeb  vmovaps [rsp+0x80], xmm8
000070a59addcef4  vmovaps [rsp+0x90], xmm10
000070a59addcefd  vmovaps [rsp+0xA0], xmm11
000070a59addcf06  vmovaps [rsp+0xB0], xmm12
000070a59addcf0f  vmovaps [rsp+0xC0], xmm13
000070a59addcf18  vmovaps [rsp+0xD0], xmm14
000070a59addcf21  vmovaps [rsp+0xE0], xmm15
000070a59addcf2a  sub rsp, 0x40
000070a59addcf2e  lea rdi, [rsp]
000070a59addcf32  lea rsi, [rsp+0x10]
000070a59addcf37  lea rdx, [rsp+0x20]
000070a59addcf3c  lea rcx, [rsp+0x30]
000070a59addcf41  mov r8d, 0x00
000070a59addcf47  lea r9, [r15+0x3A8]
000070a59addcf4e  movaps [rdi], xmm9
000070a59addcf52  movaps [rsi], xmm7
000070a59addcf55  movaps [rdx], xmm14
000070a59addcf59  movaps [rcx], xmm13
000070a59addcf5d  mov rax, 0x622906D8FA50
000070a59addcf67  call rax
000070a59addcf69  movaps xmm9, [rsp]
000070a59addcf6e  add rsp, 0x40
000070a59addcf72  vmovaps xmm0, [rsp]
000070a59addcf77  vmovaps xmm1, [rsp+0x10]
000070a59addcf7d  vmovaps xmm2, [rsp+0x20]
000070a59addcf83  vmovaps xmm3, [rsp+0x30]
000070a59addcf89  vmovaps xmm4, [rsp+0x40]
000070a59addcf8f  vmovaps xmm5, [rsp+0x50]
000070a59addcf95  vmovaps xmm6, [rsp+0x60]
000070a59addcf9b  vmovaps xmm7, [rsp+0x70]
000070a59addcfa1  vmovaps xmm8, [rsp+0x80]
000070a59addcfaa  vmovaps xmm10, [rsp+0x90]
000070a59addcfb3  vmovaps xmm11, [rsp+0xA0]
000070a59addcfbc  vmovaps xmm12, [rsp+0xB0]
000070a59addcfc5  vmovaps xmm13, [rsp+0xC0]
000070a59addcfce  vmovaps xmm14, [rsp+0xD0]
000070a59addcfd7  vmovaps xmm15, [rsp+0xE0]
000070a59addcfe0  add rsp, 0xF0
000070a59addcfe7  pop r11
000070a59addcfe9  pop r10
000070a59addcfeb  pop r9
000070a59addcfed  pop r8
000070a59addcfef  pop rsi
000070a59addcff0  pop rdi
000070a59addcff1  pop rdx
000070a59addcff2  pop rcx
000070a59addcff3  pop rax
000070a59addcff4  add rsp, 0x08
000070a59addcff8  jmp 0x000070A59ADDA5DA
000070a59addcffd  sub rsp, 0x08
000070a59addd001  push rax
000070a59addd002  push rcx
000070a59addd003  push rdx
000070a59addd004  push rdi
000070a59addd005  push rsi
000070a59addd006  push r8
000070a59addd008  push r9
000070a59addd00a  push r10
000070a59addd00c  push r11
000070a59addd00e  sub rsp, 0xF0
000070a59addd015  vmovaps [rsp], xmm0
000070a59addd01a  vmovaps [rsp+0x10], xmm1
000070a59addd020  vmovaps [rsp+0x20], xmm2
000070a59addd026  vmovaps [rsp+0x30], xmm3
000070a59addd02c  vmovaps [rsp+0x40], xmm4
000070a59addd032  vmovaps [rsp+0x50], xmm5
000070a59addd038  vmovaps [rsp+0x60], xmm6
000070a59addd03e  vmovaps [rsp+0x70], xmm7
000070a59addd044  vmovaps [rsp+0x80], xmm8
000070a59addd04d  vmovaps [rsp+0x90], xmm9
000070a59addd056  vmovaps [rsp+0xA0], xmm10
000070a59addd05f  vmovaps [rsp+0xB0], xmm11
000070a59addd068  vmovaps [rsp+0xC0], xmm12
000070a59addd071  vmovaps [rsp+0xD0], xmm14
000070a59addd07a  vmovaps [rsp+0xE0], xmm15
000070a59addd083  sub rsp, 0x40
000070a59addd087  lea rdi, [rsp]
000070a59addd08b  lea rsi, [rsp+0x10]
000070a59addd090  lea rdx, [rsp+0x20]
000070a59addd095  lea rcx, [rsp+0x30]
000070a59addd09a  mov r8d, 0x00
000070a59addd0a0  lea r9, [r15+0x3A8]
000070a59addd0a7  movaps [rdi], xmm13
000070a59addd0ab  movaps [rsi], xmm12
000070a59addd0af  movaps [rdx], xmm15
000070a59addd0b3  movaps [rcx], xmm14
000070a59addd0b7  mov rax, 0x622906D8FA50
000070a59addd0c1  call rax
000070a59addd0c3  movaps xmm13, [rsp]
000070a59addd0c8  add rsp, 0x40
000070a59addd0cc  vmovaps xmm0, [rsp]
000070a59addd0d1  vmovaps xmm1, [rsp+0x10]
000070a59addd0d7  vmovaps xmm2, [rsp+0x20]
000070a59addd0dd  vmovaps xmm3, [rsp+0x30]
000070a59addd0e3  vmovaps xmm4, [rsp+0x40]
000070a59addd0e9  vmovaps xmm5, [rsp+0x50]
000070a59addd0ef  vmovaps xmm6, [rsp+0x60]
000070a59addd0f5  vmovaps xmm7, [rsp+0x70]
000070a59addd0fb  vmovaps xmm8, [rsp+0x80]
000070a59addd104  vmovaps xmm9, [rsp+0x90]
000070a59addd10d  vmovaps xmm10, [rsp+0xA0]
000070a59addd116  vmovaps xmm11, [rsp+0xB0]
000070a59addd11f  vmovaps xmm12, [rsp+0xC0]
000070a59addd128  vmovaps xmm14, [rsp+0xD0]
000070a59addd131  vmovaps xmm15, [rsp+0xE0]
000070a59addd13a  add rsp, 0xF0
000070a59addd141  pop r11
000070a59addd143  pop r10
000070a59addd145  pop r9
000070a59addd147  pop r8
000070a59addd149  pop rsi
000070a59addd14a  pop rdi
000070a59addd14b  pop rdx
000070a59addd14c  pop rcx
000070a59addd14d  pop rax
000070a59addd14e  add rsp, 0x08
000070a59addd152  jmp 0x000070A59ADDA608
000070a59addd157  sub rsp, 0x08
000070a59addd15b  push rax
000070a59addd15c  push rcx
000070a59addd15d  push rdx
000070a59addd15e  push rdi
000070a59addd15f  push rsi
000070a59addd160  push r8
000070a59addd162  push r9
000070a59addd164  push r10
000070a59addd166  push r11
000070a59addd168  sub rsp, 0xF0
000070a59addd16f  vmovaps [rsp], xmm0
000070a59addd174  vmovaps [rsp+0x10], xmm1
000070a59addd17a  vmovaps [rsp+0x20], xmm2
000070a59addd180  vmovaps [rsp+0x30], xmm3
000070a59addd186  vmovaps [rsp+0x40], xmm4
000070a59addd18c  vmovaps [rsp+0x50], xmm5
000070a59addd192  vmovaps [rsp+0x60], xmm6
000070a59addd198  vmovaps [rsp+0x70], xmm7
000070a59addd19e  vmovaps [rsp+0x80], xmm8
000070a59addd1a7  vmovaps [rsp+0x90], xmm9
000070a59addd1b0  vmovaps [rsp+0xA0], xmm10
000070a59addd1b9  vmovaps [rsp+0xB0], xmm11
000070a59addd1c2  vmovaps [rsp+0xC0], xmm12
000070a59addd1cb  vmovaps [rsp+0xD0], xmm13
000070a59addd1d4  vmovaps [rsp+0xE0], xmm15
000070a59addd1dd  sub rsp, 0x40
000070a59addd1e1  lea rdi, [rsp]
000070a59addd1e5  lea rsi, [rsp+0x10]
000070a59addd1ea  lea rdx, [rsp+0x20]
000070a59addd1ef  lea rcx, [rsp+0x30]
000070a59addd1f4  mov r8d, 0x00
000070a59addd1fa  lea r9, [r15+0x3A8]
000070a59addd201  movaps [rdi], xmm14
000070a59addd205  movaps [rsi], xmm11
000070a59addd209  movaps [rdx], xmm1
000070a59addd20c  movaps [rcx], xmm15
000070a59addd210  mov rax, 0x622906D8FA50
000070a59addd21a  call rax
000070a59addd21c  movaps xmm14, [rsp]
000070a59addd221  add rsp, 0x40
000070a59addd225  vmovaps xmm0, [rsp]
000070a59addd22a  vmovaps xmm1, [rsp+0x10]
000070a59addd230  vmovaps xmm2, [rsp+0x20]
000070a59addd236  vmovaps xmm3, [rsp+0x30]
000070a59addd23c  vmovaps xmm4, [rsp+0x40]
000070a59addd242  vmovaps xmm5, [rsp+0x50]
000070a59addd248  vmovaps xmm6, [rsp+0x60]
000070a59addd24e  vmovaps xmm7, [rsp+0x70]
000070a59addd254  vmovaps xmm8, [rsp+0x80]
000070a59addd25d  vmovaps xmm9, [rsp+0x90]
000070a59addd266  vmovaps xmm10, [rsp+0xA0]
000070a59addd26f  vmovaps xmm11, [rsp+0xB0]
000070a59addd278  vmovaps xmm12, [rsp+0xC0]
000070a59addd281  vmovaps xmm13, [rsp+0xD0]
000070a59addd28a  vmovaps xmm15, [rsp+0xE0]
000070a59addd293  add rsp, 0xF0
000070a59addd29a  pop r11
000070a59addd29c  pop r10
000070a59addd29e  pop r9
000070a59addd2a0  pop r8
000070a59addd2a2  pop rsi
000070a59addd2a3  pop rdi
000070a59addd2a4  pop rdx
000070a59addd2a5  pop rcx
000070a59addd2a6  pop rax
000070a59addd2a7  add rsp, 0x08
000070a59addd2ab  jmp 0x000070A59ADDA636
000070a59addd2b0  call 0x000070A59AC079B0
000070a59addd2b5  jmp 0x000070A59ADDA64C
000070a59addd2ba  call 0x000070A59ACE3440
000070a59addd2bf  jmp 0x000070A59ADDA656
000070a59addd2c4  call 0x000070A59ACDFCE0
000070a59addd2c9  jmp 0x000070A59ADDA660
000070a59addd2ce  call 0x000070A59ACE46C0
000070a59addd2d3  jmp 0x000070A59ADDA66A
000070a59addd2d8  int3
000070a59addd2d9  nop [rax], eax
000070a59addd2e0  mov qword ptr [r15+0x40], 0x430000
000070a59addd2e8  mov eax, 0x430C50
000070a59addd2ed  mov r14, [r13+rax*1]
000070a59addd2f2  movq xmm1, r14
000070a59addd2f7  mov rax, [r15+0x50]
000070a59addd2fb  movups xmm15, [r13+rax*1]
000070a59addd301  movaps [r15+0x120], xmm15
000070a59addd309  mov qword ptr [r15+0x48], 0x10
000070a59addd311  xor eax, eax
000070a59addd313  mov r14d, 0x10
000070a59addd319  mov r12d, 0x200
000070a59addd31f  cmp r14, r12
000070a59addd322  cmc
000070a59addd323  lahf
000070a59addd324  seto al
000070a59addd327  mov [r15+0x108], eax
000070a59addd32e  pextrq rax, xmm15, 0x01
000070a59addd335  movq xmm14, rax
000070a59addd33a  movaps [r15+0x130], xmm14
000070a59addd342  movq rax, xmm1
000070a59addd347  movq r14, xmm15
000070a59addd34c  vmovq xmm1, rax
000070a59addd351  vmovq xmm15, r14
000070a59addd356  movaps xmm13, xmm1
000070a59addd35a  addsd xmm13, xmm15
000070a59addd35f  ucomisd xmm13, xmm13
000070a59addd364  jp 0x000070A59ADDD423
000070a59addd36a  movq xmm13, xmm13
000070a59addd36f  movq rax, xmm13
000070a59addd374  movq r14, xmm14
000070a59addd379  vmovq xmm1, rax
000070a59addd37e  vmovq xmm15, r14
000070a59addd383  movaps xmm14, xmm1
000070a59addd387  addsd xmm14, xmm15
000070a59addd38c  ucomisd xmm14, xmm14
000070a59addd391  jp 0x000070A59ADDD46B
000070a59addd397  movq xmm14, xmm14
000070a59addd39c  movaps [r15+0x110], xmm14
000070a59addd3a4  mov eax, [r15+0x108]
000070a59addd3ab  sahf
000070a59addd3ac  jnz 0x000070A59ADDD3DE
000070a59addd3ae  cmp dword ptr [r15+0x318], 0x00
000070a59addd3b6  jz 0x000070A59ADDD680
000070a59addd3bc  nop [rax+rax*1], ax
000070a59addd3c5  nop [rax+rax*1], eax
000070a59addd3cd  mov eax, 0x410698
000070a59addd3d2  mov [r15+0x100], rax
000070a59addd3d9  jmp 0x000070A59ABFE110
000070a59addd3de  cmp dword ptr [r15+0x318], 0x00
000070a59addd3e6  jz 0x000070A59ADDD4C0
000070a59addd3ec  nop [rax+rax*1], ax
000070a59addd3f5  nop [rax+rax*1], eax
000070a59addd3fd  mov eax, 0x41067C
000070a59addd402  mov [r15+0x100], rax
000070a59addd409  jmp 0x000070A59ABFE110
000070a59addd40e  int3
000070a59addd40f  call 0x000070A59AC0DC20
000070a59addd414  jmp 0x000070A59ADDD2F2
000070a59addd419  call 0x000070A59AC0E760
000070a59addd41e  jmp 0x000070A59ADDD301
000070a59addd423  ucomisd xmm1, xmm15
000070a59addd428  jp 0x000070A59ADDD437
000070a59addd42a  movaps xmm13, [0x000070A59A9FE060]
000070a59addd432  jmp 0x000070A59ADDD36A
000070a59addd437  vxorps xmm0, xmm1, xmm15
000070a59addd43c  pextrw eax, xmm0, 0x03
000070a59addd441  and eax, 0x7FF8
000070a59addd446  cmp eax, 0x08
000070a59addd449  jnz 0x000070A59ADDD36A
000070a59addd44f  movq rax, xmm15
000070a59addd454  shl rax, 0x0D
000070a59addd458  jbe 0x000070A59ADDD36A
000070a59addd45e  vorps xmm13, xmm15, [0x000070A59A9FE070]
000070a59addd466  jmp 0x000070A59ADDD36A
000070a59addd46b  ucomisd xmm1, xmm15
000070a59addd470  jp 0x000070A59ADDD47F
000070a59addd472  movaps xmm14, [0x000070A59A9FE060]
000070a59addd47a  jmp 0x000070A59ADDD397
000070a59addd47f  vxorps xmm0, xmm1, xmm15
000070a59addd484  pextrw eax, xmm0, 0x03
000070a59addd489  and eax, 0x7FF8
000070a59addd48e  cmp eax, 0x08
000070a59addd491  jnz 0x000070A59ADDD397
000070a59addd497  movq rax, xmm15
000070a59addd49c  shl rax, 0x0D
000070a59addd4a0  jbe 0x000070A59ADDD397
000070a59addd4a6  vorps xmm14, xmm15, [0x000070A59A9FE070]
000070a59addd4ae  jmp 0x000070A59ADDD397
000070a59addd4b3  int3
000070a59addd4b4  nop [rax+rax*1], ax
000070a59addd4bd  nop [rax], eax
000070a59addd4c0  mov rax, [r15+0x48]
000070a59addd4c4  mov r14, [r15+0x50]
000070a59addd4c8  lea r12, [r14+rax*1]
000070a59addd4cc  movups xmm1, [r13+r12*1]
000070a59addd4d2  movaps [r15+0x120], xmm1
000070a59addd4da  lea r14, [rax+0x10]
000070a59addd4de  mov [r15+0x48], r14
000070a59addd4e2  xor eax, eax
000070a59addd4e4  mov r12d, 0x200
000070a59addd4ea  cmp r14, r12
000070a59addd4ed  cmc
000070a59addd4ee  lahf
000070a59addd4ef  seto al
000070a59addd4f2  mov [r15+0x108], eax
000070a59addd4f9  pextrq rax, xmm1, 0x01
000070a59addd500  movq xmm15, rax
000070a59addd505  movaps [r15+0x130], xmm15
000070a59addd50d  movaps xmm14, [r15+0x110]
000070a59addd515  movq rax, xmm14
000070a59addd51a  movq r14, xmm1
000070a59addd51f  vmovq xmm1, rax
000070a59addd524  vmovq xmm14, r14
000070a59addd529  movaps xmm13, xmm1
000070a59addd52d  addsd xmm13, xmm14
000070a59addd532  ucomisd xmm13, xmm13
000070a59addd537  jp 0x000070A59ADDD5EC
000070a59addd53d  movq xmm13, xmm13
000070a59addd542  movq rax, xmm13
000070a59addd547  movq r14, xmm15
000070a59addd54c  vmovq xmm1, rax
000070a59addd551  vmovq xmm15, r14
000070a59addd556  movaps xmm14, xmm1
000070a59addd55a  addsd xmm14, xmm15
000070a59addd55f  ucomisd xmm14, xmm14
000070a59addd564  jp 0x000070A59ADDD634
000070a59addd56a  movq xmm14, xmm14
000070a59addd56f  movaps [r15+0x110], xmm14
000070a59addd577  mov eax, [r15+0x108]
000070a59addd57e  sahf
000070a59addd57f  jnz 0x000070A59ADDD5B1
000070a59addd581  cmp dword ptr [r15+0x318], 0x00
000070a59addd589  jz 0x000070A59ADDD680
000070a59addd58f  nop [rax+rax*1], ax
000070a59addd598  nop [rax+rax*1], eax
000070a59addd5a0  mov eax, 0x410698
000070a59addd5a5  mov [r15+0x100], rax
000070a59addd5ac  jmp 0x000070A59ABFE110
000070a59addd5b1  cmp dword ptr [r15+0x318], 0x00
000070a59addd5b9  jz 0x000070A59ADDD4C0
000070a59addd5bf  nop [rax+rax*1], ax
000070a59addd5c8  nop [rax+rax*1], eax
000070a59addd5d0  mov eax, 0x41067C
000070a59addd5d5  mov [r15+0x100], rax
000070a59addd5dc  jmp 0x000070A59ABFE110
000070a59addd5e1  int3
000070a59addd5e2  call 0x000070A59ACB52F0
000070a59addd5e7  jmp 0x000070A59ADDD4D2
000070a59addd5ec  ucomisd xmm1, xmm14
000070a59addd5f1  jp 0x000070A59ADDD600
000070a59addd5f3  movaps xmm13, [0x000070A59A9FE060]
000070a59addd5fb  jmp 0x000070A59ADDD53D
000070a59addd600  vxorps xmm0, xmm1, xmm14
000070a59addd605  pextrw eax, xmm0, 0x03
000070a59addd60a  and eax, 0x7FF8
000070a59addd60f  cmp eax, 0x08
000070a59addd612  jnz 0x000070A59ADDD53D
000070a59addd618  movq rax, xmm14
000070a59addd61d  shl rax, 0x0D
000070a59addd621  jbe 0x000070A59ADDD53D
000070a59addd627  vorps xmm13, xmm14, [0x000070A59A9FE070]
000070a59addd62f  jmp 0x000070A59ADDD53D
000070a59addd634  ucomisd xmm1, xmm15
000070a59addd639  jp 0x000070A59ADDD648
000070a59addd63b  movaps xmm14, [0x000070A59A9FE060]
000070a59addd643  jmp 0x000070A59ADDD56A
000070a59addd648  vxorps xmm0, xmm1, xmm15
000070a59addd64d  pextrw eax, xmm0, 0x03
000070a59addd652  and eax, 0x7FF8
000070a59addd657  cmp eax, 0x08
000070a59addd65a  jnz 0x000070A59ADDD56A
000070a59addd660  movq rax, xmm15
000070a59addd665  shl rax, 0x0D
000070a59addd669  jbe 0x000070A59ADDD56A
000070a59addd66f  vorps xmm14, xmm15, [0x000070A59A9FE070]
000070a59addd677  jmp 0x000070A59ADDD56A
000070a59addd67c  int3
000070a59addd67d  nop [rax], eax
000070a59addd680  mov rax, [r15+0xF8]
000070a59addd687  lea r14, [rax+0x1A0]
000070a59addd68e  mov r12, [r13+r14*1]
000070a59addd693  lea r14, [rax+0x1A8]
000070a59addd69a  mov r11, [r13+r14*1]
000070a59addd69f  mov [r15+0xA0], r12
000070a59addd6a6  mov [r15+0x98], r11
000070a59addd6ad  mov r14, [r15+0x40]
000070a59addd6b1  lea r12, [r14+0xC50]
000070a59addd6b8  movaps xmm1, [r15+0x110]
000070a59addd6c0  movq r14, xmm1
000070a59addd6c5  mov [r13+r12*1], r14
000070a59addd6ca  lea r14, [rax+0x190]
000070a59addd6d1  mov r12, [r13+r14*1]
000070a59addd6d6  lea r14, [rax+0x198]
000070a59addd6dd  mov r11, [r13+r14*1]
000070a59addd6e2  mov [r15+0xE8], r12
000070a59addd6e9  mov [r15+0xF0], r11
000070a59addd6f0  lea r14, [rax+0x180]
000070a59addd6f7  mov r12, [r13+r14*1]
000070a59addd6fc  lea r14, [rax+0x188]
000070a59addd703  mov r10, [r13+r14*1]
000070a59addd708  movq xmm1, r12
000070a59addd70d  movq xmm15, r10
000070a59addd712  movq xmm1, xmm1
000070a59addd716  movq xmm1, xmm1
000070a59addd71a  movaps [r15+0x1A0], xmm1
000070a59addd722  movq xmm15, xmm15
000070a59addd727  movq xmm15, xmm15
000070a59addd72c  movaps [r15+0x190], xmm15
000070a59addd734  lea r14, [rax+0x170]
000070a59addd73b  mov r12, [r13+r14*1]
000070a59addd740  lea r14, [rax+0x178]
000070a59addd747  mov r10, [r13+r14*1]
000070a59addd74c  movq xmm1, r12
000070a59addd751  movq xmm15, r10
000070a59addd756  movq xmm1, xmm1
000070a59addd75a  movq xmm1, xmm1
000070a59addd75e  movaps [r15+0x1C0], xmm1
000070a59addd766  movq xmm15, xmm15
000070a59addd76b  movq xmm15, xmm15
000070a59addd770  movaps [r15+0x1B0], xmm15
000070a59addd778  lea r14, [rax+0x160]
000070a59addd77f  mov r12, [r13+r14*1]
000070a59addd784  lea r14, [rax+0x168]
000070a59addd78b  mov r10, [r13+r14*1]
000070a59addd790  movq xmm1, r12
000070a59addd795  movq xmm15, r10
000070a59addd79a  movq xmm1, xmm1
000070a59addd79e  movq xmm1, xmm1
000070a59addd7a2  movaps [r15+0x1E0], xmm1
000070a59addd7aa  movq xmm15, xmm15
000070a59addd7af  movq xmm15, xmm15
000070a59addd7b4  movaps [r15+0x1D0], xmm15
000070a59addd7bc  lea r14, [rax+0x150]
000070a59addd7c3  mov r12, [r13+r14*1]
000070a59addd7c8  lea r14, [rax+0x158]
000070a59addd7cf  mov r10, [r13+r14*1]
000070a59addd7d4  movq xmm1, r12
000070a59addd7d9  movq xmm15, r10
000070a59addd7de  movq xmm1, xmm1
000070a59addd7e2  movq xmm1, xmm1
000070a59addd7e6  movaps [r15+0x200], xmm1
000070a59addd7ee  movq xmm15, xmm15
000070a59addd7f3  movq xmm15, xmm15
000070a59addd7f8  movaps [r15+0x1F0], xmm15
000070a59addd800  lea r14, [rax+0x1B0]
000070a59addd807  mov [r15+0xF8], r14
000070a59addd80e  mov [r15+0x100], r11
000070a59addd815  jmp 0x000070A59ADCE5C0
000070a59addd81a  int3
000070a59addd81b  call 0x000070A59ACE27E0
000070a59addd820  jmp 0x000070A59ADDD693
000070a59addd825  call 0x000070A59ACE1570
000070a59addd82a  jmp 0x000070A59ADDD69F
000070a59addd82f  call 0x000070A59ACC3FE0
000070a59addd834  jmp 0x000070A59ADDD6CA
000070a59addd839  call 0x000070A59ACE27E0
000070a59addd83e  jmp 0x000070A59ADDD6D6
000070a59addd843  call 0x000070A59ACE1570
000070a59addd848  jmp 0x000070A59ADDD6E2
000070a59addd84d  call 0x000070A59ACE27E0
000070a59addd852  jmp 0x000070A59ADDD6FC
000070a59addd857  call 0x000070A59ACE0300
000070a59addd85c  jmp 0x000070A59ADDD708
000070a59addd861  call 0x000070A59ACE27E0
000070a59addd866  jmp 0x000070A59ADDD740
000070a59addd86b  call 0x000070A59ACE0300
000070a59addd870  jmp 0x000070A59ADDD74C
000070a59addd875  call 0x000070A59ACE27E0
000070a59addd87a  jmp 0x000070A59ADDD784
000070a59addd87f  call 0x000070A59ACE0300
000070a59addd884  jmp 0x000070A59ADDD790
000070a59addd889  call 0x000070A59ACE27E0
000070a59addd88e  jmp 0x000070A59ADDD7C8
000070a59addd893  call 0x000070A59ACE0300
000070a59addd898  jmp 0x000070A59ADDD7D4
000070a59addd89d  int3
000070a59addd89e  nop
000070a59addd8a0  mov qword ptr [r15+0x100], 0x04
000070a59addd8ab  mov esi, 0x00
000070a59addd8b0  mov edx, 0x09
000070a59addd8b5  mov rdi, 0x7FFDA5470D20
000070a59addd8bf  mov rax, 0x622906C22970
000070a59addd8c9  call rax
000070a59addd8cb  cmp dword ptr [r15+0x318], 0x00
000070a59addd8d3  jnz 0x000070A59ABFE110
000070a59addd8d9  jmp 0x000070A59ABFE0A0
000070a59addd8de  int3
000070a59addd8df  int3
