
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/1/0.bin:     file format binary


Disassembly of section .data:

000072fde4efe000 <.data>:
    72fde4efe000:	sub    rsp,0x10
    72fde4efe004:	mov    r11,QWORD PTR [r12+0x398]
    72fde4efe00c:	mov    QWORD PTR [rsp],r11
    72fde4efe010:	mov    r13,QWORD PTR [r12+0xf8]
    72fde4efe018:	sub    r13,0x1b0
    72fde4efe01f:	mov    QWORD PTR [r12+0xf8],r13
    72fde4efe027:	mov    r14d,0x420000
    72fde4efe02d:	mov    QWORD PTR [r12+0x40],r14
    72fde4efe032:	mov    r14d,0x420000
    72fde4efe038:	mov    QWORD PTR [r12+0x48],r14
    72fde4efe03d:	mov    r14,r13
    72fde4efe040:	add    r14,0x1a0
    72fde4efe047:	mov    r15,r14
    72fde4efe04a:	add    r15,0x8
    72fde4efe04e:	mov    rbp,QWORD PTR [r12+0xa0]
    72fde4efe056:	mov    r8,QWORD PTR [r12+0x98]
    72fde4efe05e:	mov    QWORD PTR [r14],rbp
    72fde4efe061:	mov    r14d,0x0
    72fde4efe067:	mov    DWORD PTR [r12+0x32c],r14d
    72fde4efe06f:	mov    QWORD PTR [r15],r8
    72fde4efe072:	mov    r14d,0x420a30
    72fde4efe078:	movdqu xmm2,XMMWORD PTR [r14]
    72fde4efe07d:	movdqu XMMWORD PTR [r12+0x110],xmm2
    72fde4efe087:	mov    r14d,0x4209c0
    72fde4efe08d:	movdqu xmm3,XMMWORD PTR [r14]
    72fde4efe092:	movdqu XMMWORD PTR [r12+0x120],xmm3
    72fde4efe09c:	mov    r14d,0x420a50
    72fde4efe0a2:	movdqu xmm4,XMMWORD PTR [r14]
    72fde4efe0a7:	movdqu XMMWORD PTR [r12+0x130],xmm4
    72fde4efe0b1:	mov    r14d,0x4209f0
    72fde4efe0b7:	movdqu xmm5,XMMWORD PTR [r14]
    72fde4efe0bc:	movdqu XMMWORD PTR [r12+0x140],xmm5
    72fde4efe0c6:	mov    r14d,0x430000
    72fde4efe0cc:	mov    rax,r14
    72fde4efe0cf:	add    rax,0xc60
    72fde4efe0d5:	mov    QWORD PTR [r12+0x98],rax
    72fde4efe0dd:	mov    r15d,0x420a60
    72fde4efe0e3:	movdqu xmm6,XMMWORD PTR [r15]
    72fde4efe0e8:	movdqu XMMWORD PTR [r12+0x150],xmm6
    72fde4efe0f2:	mov    r15,QWORD PTR [r12+0x98]
    72fde4efe0fa:	add    r15,0x10
    72fde4efe0fe:	mov    rdi,QWORD PTR [r12+0x98]
    72fde4efe106:	movdqu XMMWORD PTR [rdi],xmm2
    72fde4efe10a:	movdqu XMMWORD PTR [r15],xmm3
    72fde4efe10f:	mov    r15,QWORD PTR [r12+0x98]
    72fde4efe117:	add    r15,0x20
    72fde4efe11b:	mov    rbp,r15
    72fde4efe11e:	add    rbp,0x10
    72fde4efe122:	movdqu XMMWORD PTR [r15],xmm4
    72fde4efe127:	movdqu XMMWORD PTR [rbp+0x0],xmm5
    72fde4efe12c:	mov    r15d,0x4209b0
    72fde4efe132:	movdqu xmm4,XMMWORD PTR [r15]
    72fde4efe137:	movdqu XMMWORD PTR [r12+0x130],xmm4
    72fde4efe141:	mov    r15d,0x4209a0
    72fde4efe147:	movdqu xmm5,XMMWORD PTR [r15]
    72fde4efe14c:	movdqu XMMWORD PTR [r12+0x140],xmm5
    72fde4efe156:	mov    r15,QWORD PTR [r12+0x98]
    72fde4efe15e:	add    r15,0x100
    72fde4efe165:	mov    rbp,r15
    72fde4efe168:	add    rbp,0x10
    72fde4efe16c:	movdqu XMMWORD PTR [r15],xmm2
    72fde4efe171:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    72fde4efe176:	mov    r15,QWORD PTR [r12+0x98]
    72fde4efe17e:	add    r15,0x40
    72fde4efe182:	mov    rbp,r15
    72fde4efe185:	add    rbp,0x10
    72fde4efe189:	movdqu XMMWORD PTR [r15],xmm6
    72fde4efe18e:	movdqu XMMWORD PTR [rbp+0x0],xmm4
    72fde4efe193:	mov    r15d,0x420990
    72fde4efe199:	movdqu xmm2,XMMWORD PTR [r15]
    72fde4efe19e:	movdqu XMMWORD PTR [r12+0x130],xmm2
    72fde4efe1a8:	mov    r15d,0x420a00
    72fde4efe1ae:	movdqu xmm3,XMMWORD PTR [r15]
    72fde4efe1b3:	movdqu XMMWORD PTR [r12+0x150],xmm3
    72fde4efe1bd:	mov    r15d,0xf8d3
    72fde4efe1c3:	mov    QWORD PTR [r12+0x48],r15
    72fde4efe1c8:	mov    r15,QWORD PTR [r12+0x98]
    72fde4efe1d0:	add    r15,0x60
    72fde4efe1d4:	mov    rbp,r15
    72fde4efe1d7:	add    rbp,0x10
    72fde4efe1db:	movdqu XMMWORD PTR [r15],xmm5
    72fde4efe1e0:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    72fde4efe1e5:	mov    r15d,0x420a10
    72fde4efe1eb:	movdqu xmm2,XMMWORD PTR [r15]
    72fde4efe1f0:	movdqu XMMWORD PTR [r12+0x130],xmm2
    72fde4efe1fa:	mov    r15d,0x4209e0
    72fde4efe200:	movdqu xmm4,XMMWORD PTR [r15]
    72fde4efe205:	movdqu XMMWORD PTR [r12+0x140],xmm4
    72fde4efe20f:	mov    r15d,0xf8d3
    72fde4efe215:	mov    ebp,0x421d
    72fde4efe21a:	and    ebp,0xffff
    72fde4efe220:	mov    rax,r15
    72fde4efe223:	movabs rcx,0xffffffff0000ffff
    72fde4efe22d:	and    rax,rcx
    72fde4efe230:	mov    rdx,rbp
    72fde4efe233:	shl    rdx,0x10
    72fde4efe237:	mov    ecx,0xffff0000
    72fde4efe23c:	and    rdx,rcx
    72fde4efe23f:	or     rax,rdx
    72fde4efe242:	mov    r8d,eax
    72fde4efe245:	mov    QWORD PTR [r12+0x48],r8
    72fde4efe24a:	mov    r15,QWORD PTR [r12+0x98]
    72fde4efe252:	add    r15,0x80
    72fde4efe259:	mov    rbp,r15
    72fde4efe25c:	add    rbp,0x10
    72fde4efe260:	movdqu XMMWORD PTR [r15],xmm3
    72fde4efe265:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    72fde4efe26a:	mov    r15d,0x420a80
    72fde4efe270:	movdqu xmm2,XMMWORD PTR [r15]
    72fde4efe275:	movdqu XMMWORD PTR [r12+0x130],xmm2
    72fde4efe27f:	mov    r15d,0x420a90
    72fde4efe285:	movdqu xmm3,XMMWORD PTR [r15]
    72fde4efe28a:	movdqu XMMWORD PTR [r12+0x150],xmm3
    72fde4efe294:	mov    r15d,0x3e8
    72fde4efe29a:	mov    QWORD PTR [r12+0xa0],r15
    72fde4efe2a2:	mov    r15,QWORD PTR [r12+0x98]
    72fde4efe2aa:	add    r15,0xa0
    72fde4efe2b1:	mov    rbp,r15
    72fde4efe2b4:	add    rbp,0x10
    72fde4efe2b8:	movdqu XMMWORD PTR [r15],xmm4
    72fde4efe2bd:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    72fde4efe2c2:	mov    r15d,0x420a70
    72fde4efe2c8:	movdqu xmm2,XMMWORD PTR [r15]
    72fde4efe2cd:	movdqu XMMWORD PTR [r12+0x130],xmm2
    72fde4efe2d7:	mov    r15d,0x420a20
    72fde4efe2dd:	movdqu xmm4,XMMWORD PTR [r15]
    72fde4efe2e2:	movdqu XMMWORD PTR [r12+0x140],xmm4
    72fde4efe2ec:	mov    r15,r13
    72fde4efe2ef:	add    r15,0x150
    72fde4efe2f6:	mov    rbp,r15
    72fde4efe2f9:	add    rbp,0x8
    72fde4efe2fd:	mov    r9,QWORD PTR [r12+0x200]
    72fde4efe305:	mov    r14,QWORD PTR [r12+0x1f0]
    72fde4efe30d:	mov    QWORD PTR [r15],r9
    72fde4efe310:	mov    QWORD PTR [rbp+0x0],r14
    72fde4efe314:	mov    r14,QWORD PTR [r12+0x98]
    72fde4efe31c:	add    r14,0xc0
    72fde4efe323:	mov    r15,r14
    72fde4efe326:	add    r15,0x10
    72fde4efe32a:	movdqu XMMWORD PTR [r14],xmm3
    72fde4efe32f:	movdqu XMMWORD PTR [r15],xmm2
    72fde4efe334:	mov    r14d,0x420a40
    72fde4efe33a:	movdqu xmm2,XMMWORD PTR [r14]
    72fde4efe33f:	movdqu XMMWORD PTR [r12+0x130],xmm2
    72fde4efe349:	mov    r14d,0x420aa8
    72fde4efe34f:	mov    r15,QWORD PTR [r14]
    72fde4efe352:	mov    r14d,0x0
    72fde4efe358:	mov    QWORD PTR [r12+0x110],r15
    72fde4efe360:	mov    QWORD PTR [r12+0x118],r14
    72fde4efe368:	mov    r14d,0x420ab0
    72fde4efe36e:	mov    QWORD PTR [r12+0x40],r14
    72fde4efe373:	mov    r14,QWORD PTR [r12+0x98]
    72fde4efe37b:	add    r14,0xe0
    72fde4efe382:	mov    rbp,r14
    72fde4efe385:	add    rbp,0x10
    72fde4efe389:	movdqu XMMWORD PTR [r14],xmm4
    72fde4efe38e:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    72fde4efe393:	mov    r14d,0x420b10
    72fde4efe399:	movdqu xmm2,XMMWORD PTR [r14]
    72fde4efe39e:	movdqu XMMWORD PTR [r12+0x130],xmm2
    72fde4efe3a8:	mov    r14,QWORD PTR [r12+0x98]
    72fde4efe3b0:	add    r14,0x120
    72fde4efe3b7:	mov    QWORD PTR [r14],r15
    72fde4efe3ba:	mov    r14d,0x420af0
    72fde4efe3c0:	mov    r15d,0x420b00
    72fde4efe3c6:	movdqu xmm3,XMMWORD PTR [r14]
    72fde4efe3cb:	movdqu xmm4,XMMWORD PTR [r15]
    72fde4efe3d0:	movdqu XMMWORD PTR [r12+0x120],xmm3
    72fde4efe3da:	movdqu XMMWORD PTR [r12+0x110],xmm4
    72fde4efe3e4:	mov    r14,r13
    72fde4efe3e7:	add    r14,0x130
    72fde4efe3ee:	movdqu XMMWORD PTR [r14],xmm2
    72fde4efe3f3:	mov    r14,r13
    72fde4efe3f6:	add    r14,0x160
    72fde4efe3fd:	mov    r15,r14
    72fde4efe400:	add    r15,0x8
    72fde4efe404:	mov    rbp,QWORD PTR [r12+0x1e0]
    72fde4efe40c:	mov    r9,QWORD PTR [r12+0x1d0]
    72fde4efe414:	mov    QWORD PTR [r14],rbp
    72fde4efe417:	mov    QWORD PTR [r15],r9
    72fde4efe41a:	mov    r14,r13
    72fde4efe41d:	add    r14,0x110
    72fde4efe424:	mov    r15,r14
    72fde4efe427:	add    r15,0x10
    72fde4efe42b:	movdqu XMMWORD PTR [r14],xmm3
    72fde4efe430:	movdqu XMMWORD PTR [r15],xmm4
    72fde4efe435:	mov    r14d,0x420ab0
    72fde4efe43b:	mov    r15d,0x420ac0
    72fde4efe441:	movdqu xmm2,XMMWORD PTR [r14]
    72fde4efe446:	movdqu xmm3,XMMWORD PTR [r15]
    72fde4efe44b:	movdqu XMMWORD PTR [r12+0x110],xmm2
    72fde4efe455:	movdqu XMMWORD PTR [r12+0x120],xmm3
    72fde4efe45f:	mov    r14,r13
    72fde4efe462:	add    r14,0x170
    72fde4efe469:	mov    r15,r14
    72fde4efe46c:	add    r15,0x8
    72fde4efe470:	mov    rbp,QWORD PTR [r12+0x1c0]
    72fde4efe478:	mov    r9,QWORD PTR [r12+0x1b0]
    72fde4efe480:	mov    QWORD PTR [r14],rbp
    72fde4efe483:	mov    QWORD PTR [r15],r9
    72fde4efe486:	mov    r14,r13
    72fde4efe489:	add    r14,0x180
    72fde4efe490:	mov    r15,r14
    72fde4efe493:	add    r15,0x8
    72fde4efe497:	mov    rbp,QWORD PTR [r12+0x1a0]
    72fde4efe49f:	mov    r9,QWORD PTR [r12+0x190]
    72fde4efe4a7:	mov    QWORD PTR [r14],rbp
    72fde4efe4aa:	mov    QWORD PTR [r15],r9
    72fde4efe4ad:	mov    r14,r13
    72fde4efe4b0:	add    r14,0xd0
    72fde4efe4b7:	mov    r15,r14
    72fde4efe4ba:	add    r15,0x10
    72fde4efe4be:	movdqu XMMWORD PTR [r14],xmm2
    72fde4efe4c3:	movdqu XMMWORD PTR [r15],xmm3
    72fde4efe4c8:	mov    r14d,0x420ad0
    72fde4efe4ce:	mov    r15d,0x420ae0
    72fde4efe4d4:	movdqu xmm2,XMMWORD PTR [r14]
    72fde4efe4d9:	movdqu xmm3,XMMWORD PTR [r15]
    72fde4efe4de:	movdqu XMMWORD PTR [r12+0x110],xmm2
    72fde4efe4e8:	movdqu XMMWORD PTR [r12+0x130],xmm3
    72fde4efe4f2:	mov    r14,r13
    72fde4efe4f5:	add    r14,0x190
    72fde4efe4fc:	mov    r15,r14
    72fde4efe4ff:	add    r15,0x8
    72fde4efe503:	mov    rbp,QWORD PTR [r12+0xe8]
    72fde4efe50b:	mov    r9,QWORD PTR [r12+0xf0]
    72fde4efe513:	mov    QWORD PTR [r14],rbp
    72fde4efe516:	mov    QWORD PTR [r15],r9
    72fde4efe519:	mov    r14,QWORD PTR [r12+0x98]
    72fde4efe521:	add    r14,0x128
    72fde4efe528:	mov    DWORD PTR [r14],r8d
    72fde4efe52b:	mov    r14,r13
    72fde4efe52e:	add    r14,0xf0
    72fde4efe535:	mov    r15,r14
    72fde4efe538:	add    r15,0x10
    72fde4efe53c:	movdqu XMMWORD PTR [r14],xmm2
    72fde4efe541:	movdqu XMMWORD PTR [r15],xmm3
    72fde4efe546:	add    r13,0xd0
    72fde4efe54d:	mov    QWORD PTR [r12],r13
    72fde4efe551:	mov    r13d,0x0
    72fde4efe557:	mov    rcx,QWORD PTR [r12+0x98]
    72fde4efe55f:	or     r13,rcx
    72fde4efe562:	mov    QWORD PTR [r12+0x8],r13
    72fde4efe567:	mov    r13d,0x12c
    72fde4efe56d:	mov    QWORD PTR [r12+0x10],r13
    72fde4efe572:	mov    r13d,0x410284
    72fde4efe578:	mov    QWORD PTR [r12+0xf0],r13
    72fde4efe580:	mov    r13d,0x4106bc
    72fde4efe586:	mov    QWORD PTR [r12+0x100],r13
    72fde4efe58e:	mov    r11,QWORD PTR [rsp]
    72fde4efe592:	mov    QWORD PTR [r12+0x398],r11
    72fde4efe59a:	mov    edi,0x4106bc
    72fde4efe59f:	mov    QWORD PTR [r12+0x100],rdi
    72fde4efe5a7:	add    rsp,0x10
    72fde4efe5ab:	nop    DWORD PTR [rax+rax*1+0x0]
    72fde4efe5b0:	jmp    QWORD PTR [rip+0x2]        # 0x72fde4efe5b8
    72fde4efe5b6:	xchg   ax,ax
    72fde4efe5b8:	loopne 0x72fde4efe59f
    72fde4efe5ba:	out    dx,eax
    72fde4efe5bb:	in     al,0xfd
    72fde4efe5bd:	jb     0x72fde4efe5bf
    72fde4efe5bf:	add    al,cl
    72fde4efe5c1:	in     eax,0xef
    72fde4efe5c3:	in     al,0xfd
    72fde4efe5c5:	jb     0x72fde4efe5c7
    72fde4efe5c7:	add    BYTE PTR [rcx-0x45],cl
    72fde4efe5ca:	rex or ebp,esi
    72fde4efe5cd:	sahf
    72fde4efe5ce:	int    0x5c
    72fde4efe5d0:	add    BYTE PTR [rax],al
    72fde4efe5d2:	jmp    r11
    72fde4efe5d5:	nop
    72fde4efe5d6:	nop
    72fde4efe5d7:	nop
