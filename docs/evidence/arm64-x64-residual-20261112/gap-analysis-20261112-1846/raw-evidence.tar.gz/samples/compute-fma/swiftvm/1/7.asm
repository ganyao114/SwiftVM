
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/1/7.bin:     file format binary


Disassembly of section .data:

000072fde4f01900 <.data>:
    72fde4f01900:	sub    rsp,0x10
    72fde4f01904:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f0190c:	mov    QWORD PTR [rsp],r11
    72fde4f01910:	mov    r13,QWORD PTR [r12+0xa0]
    72fde4f01918:	mov    r14,r13
    72fde4f0191b:	shl    r14,0x2
    72fde4f0191f:	mov    r15,QWORD PTR [r12+0x98]
    72fde4f01927:	add    r15,r14
    72fde4f0192a:	mov    r14d,DWORD PTR [r12]
    72fde4f0192e:	mov    DWORD PTR [r15],r14d
    72fde4f01931:	mov    r14d,0x0
    72fde4f01937:	mov    DWORD PTR [r12+0x32c],r14d
    72fde4f0193f:	add    r13,0x1
    72fde4f01943:	mov    QWORD PTR [r12+0xa0],r13
    72fde4f0194b:	sub    r13,0x400
    72fde4f01952:	mov    rcx,QWORD PTR [r12+0x380]
    72fde4f0195a:	jrcxz  0x72fde4f01961
    72fde4f0195c:	jmp    0x72fde4f01d3d
    72fde4f01961:	jne    0x72fde4f0197a
    72fde4f01967:	mov    r11,rax
    72fde4f0196a:	lahf
    72fde4f0196b:	seto   al
    72fde4f0196e:	mov    WORD PTR [rsp],ax
    72fde4f01972:	mov    rax,r11
    72fde4f01975:	jmp    0x72fde4f0198d
    72fde4f0197a:	mov    r11,rax
    72fde4f0197d:	lahf
    72fde4f0197e:	seto   al
    72fde4f01981:	mov    WORD PTR [rsp],ax
    72fde4f01985:	mov    rax,r11
    72fde4f01988:	jmp    0x72fde4f01ccd
    72fde4f0198d:	mov    r13d,0x1
    72fde4f01993:	mov    QWORD PTR [r12+0x40],r13
    72fde4f01998:	mov    r11,rax
    72fde4f0199b:	movzx  eax,WORD PTR [rsp]
    72fde4f0199f:	add    al,0x7f
    72fde4f019a1:	sahf
    72fde4f019a2:	mov    rax,r11
    72fde4f019a5:	jmp    0x72fde4f019aa
    72fde4f019aa:	mov    r13,QWORD PTR [r12+0x40]
    72fde4f019af:	mov    r14,r13
    72fde4f019b2:	lea    r14,[r14*4+0x0]
    72fde4f019ba:	mov    r15,QWORD PTR [r12+0x98]
    72fde4f019c2:	mov    r11,rax
    72fde4f019c5:	lahf
    72fde4f019c6:	seto   al
    72fde4f019c9:	mov    WORD PTR [rsp],ax
    72fde4f019cd:	mov    rax,r11
    72fde4f019d0:	add    r15,r14
    72fde4f019d3:	mov    r14d,DWORD PTR [r15]
    72fde4f019d6:	mov    QWORD PTR [r12+0x48],r14
    72fde4f019db:	mov    r14d,0x0
    72fde4f019e1:	or     r14,r13
    72fde4f019e4:	mov    QWORD PTR [r12+0x50],r14
    72fde4f019e9:	jmp    0x72fde4f019ee
    72fde4f019ee:	mov    r13d,DWORD PTR [r12+0x50]
    72fde4f019f3:	sub    r13d,0x1
    72fde4f019f7:	mov    QWORD PTR [r12+0x58],r13
    72fde4f019fc:	mov    ecx,0xffffffff
    72fde4f01a01:	mov    r14,r13
    72fde4f01a04:	and    r14,rcx
    72fde4f01a07:	shl    r14,0x2
    72fde4f01a0b:	mov    r13,QWORD PTR [r12+0x98]
    72fde4f01a13:	add    r13,r14
    72fde4f01a16:	mov    r14d,DWORD PTR [r13+0x0]
    72fde4f01a1a:	mov    QWORD PTR [r12+0x60],r14
    72fde4f01a1f:	mov    r13d,DWORD PTR [r12+0x48]
    72fde4f01a24:	sub    r14d,r13d
    72fde4f01a27:	mov    rcx,QWORD PTR [r12+0x380]
    72fde4f01a2f:	jrcxz  0x72fde4f01a36
    72fde4f01a31:	jmp    0x72fde4f01dce
    72fde4f01a36:	jbe    0x72fde4f01a4f
    72fde4f01a3c:	mov    r11,rax
    72fde4f01a3f:	lahf
    72fde4f01a40:	seto   al
    72fde4f01a43:	mov    WORD PTR [rsp],ax
    72fde4f01a47:	mov    rax,r11
    72fde4f01a4a:	jmp    0x72fde4f01a62
    72fde4f01a4f:	mov    r11,rax
    72fde4f01a52:	lahf
    72fde4f01a53:	seto   al
    72fde4f01a56:	mov    WORD PTR [rsp],ax
    72fde4f01a5a:	mov    rax,r11
    72fde4f01a5d:	jmp    0x72fde4f01ae1
    72fde4f01a62:	mov    r13,QWORD PTR [r12+0x50]
    72fde4f01a67:	mov    r14,r13
    72fde4f01a6a:	shl    r14,0x2
    72fde4f01a6e:	mov    r15,QWORD PTR [r12+0x98]
    72fde4f01a76:	add    r15,r14
    72fde4f01a79:	mov    r14d,DWORD PTR [r12+0x60]
    72fde4f01a7e:	mov    DWORD PTR [r15],r14d
    72fde4f01a81:	mov    r14d,0x0
    72fde4f01a87:	mov    DWORD PTR [r12+0x32c],r14d
    72fde4f01a8f:	sub    r13,0x1
    72fde4f01a93:	mov    QWORD PTR [r12+0x50],r13
    72fde4f01a98:	mov    rcx,QWORD PTR [r12+0x380]
    72fde4f01aa0:	jrcxz  0x72fde4f01aa7
    72fde4f01aa2:	jmp    0x72fde4f01e5f
    72fde4f01aa7:	mov    r13,QWORD PTR [r12+0x58]
    72fde4f01aac:	mov    rax,r13
    72fde4f01aaf:	test   rax,rax
    72fde4f01ab2:	jne    0x72fde4f019ee
    72fde4f01ab8:	jmp    0x72fde4f01abd
    72fde4f01abd:	mov    rcx,QWORD PTR [r12+0x380]
    72fde4f01ac5:	jrcxz  0x72fde4f01acc
    72fde4f01ac7:	jmp    0x72fde4f01ee1
    72fde4f01acc:	jmp    0x72fde4f01ad1
    72fde4f01ad1:	mov    r13d,0x0
    72fde4f01ad7:	mov    QWORD PTR [r12+0x50],r13
    72fde4f01adc:	jmp    0x72fde4f01ae1
    72fde4f01ae1:	mov    r13,QWORD PTR [r12+0x40]
    72fde4f01ae6:	add    r13,0x1
    72fde4f01aea:	mov    QWORD PTR [r12+0x40],r13
    72fde4f01aef:	mov    r14,QWORD PTR [r12+0x50]
    72fde4f01af4:	mov    ecx,0xffffffff
    72fde4f01af9:	and    r14,rcx
    72fde4f01afc:	shl    r14,0x2
    72fde4f01b00:	mov    r15,QWORD PTR [r12+0x98]
    72fde4f01b08:	add    r15,r14
    72fde4f01b0b:	mov    r14d,DWORD PTR [r12+0x48]
    72fde4f01b10:	mov    DWORD PTR [r15],r14d
    72fde4f01b13:	mov    r14d,0x0
    72fde4f01b19:	mov    DWORD PTR [r12+0x32c],r14d
    72fde4f01b21:	sub    r13,0x400
    72fde4f01b28:	jne    0x72fde4f019aa
    72fde4f01b2e:	mov    r11,rax
    72fde4f01b31:	lahf
    72fde4f01b32:	seto   al
    72fde4f01b35:	mov    WORD PTR [rsp],ax
    72fde4f01b39:	mov    rax,r11
    72fde4f01b3c:	jmp    0x72fde4f01b41
    72fde4f01b41:	mov    r13d,0x430000
    72fde4f01b47:	mov    QWORD PTR [r12+0x40],r13
    72fde4f01b4c:	mov    r13d,0x0
    72fde4f01b52:	mov    QWORD PTR [r12+0x58],r13
    72fde4f01b57:	mov    r13d,0x0
    72fde4f01b5d:	mov    QWORD PTR [r12+0x50],r13
    72fde4f01b62:	mov    r13d,0x430c40
    72fde4f01b68:	mov    r14,QWORD PTR [r13+0x0]
    72fde4f01b6c:	mov    QWORD PTR [r12+0x48],r14
    72fde4f01b71:	jmp    0x72fde4f01b76
    72fde4f01b76:	mov    r13,QWORD PTR [r12+0x58]
    72fde4f01b7b:	mov    r14,r13
    72fde4f01b7e:	shl    r14,0x2
    72fde4f01b82:	mov    r15,QWORD PTR [r12+0x98]
    72fde4f01b8a:	add    r15,r14
    72fde4f01b8d:	mov    QWORD PTR [r12+0x60],r15
    72fde4f01b92:	mov    r14,r15
    72fde4f01b95:	add    r14,0x4
    72fde4f01b99:	mov    ebp,DWORD PTR [r15]
    72fde4f01b9c:	mov    r15d,DWORD PTR [r14]
    72fde4f01b9f:	mov    QWORD PTR [r12+0x60],r15
    72fde4f01ba4:	mov    r14,rbp
    72fde4f01ba7:	imul   r14,r13
    72fde4f01bab:	mov    r8,rbp
    72fde4f01bae:	add    r8,r14
    72fde4f01bb1:	mov    QWORD PTR [r12+0x68],r8
    72fde4f01bb6:	add    r13,0x2
    72fde4f01bba:	mov    QWORD PTR [r12+0x58],r13
    72fde4f01bbf:	mov    r14,r13
    72fde4f01bc2:	sub    r14,0x400
    72fde4f01bc9:	mov    r14,QWORD PTR [r12+0x50]
    72fde4f01bce:	setne  BYTE PTR [rsp+0x8]
    72fde4f01bd3:	mov    r11,rax
    72fde4f01bd6:	lahf
    72fde4f01bd7:	seto   al
    72fde4f01bda:	mov    WORD PTR [rsp],ax
    72fde4f01bde:	mov    rax,r11
    72fde4f01be1:	imul   r13,r15
    72fde4f01be5:	add    r14,r13
    72fde4f01be8:	mov    QWORD PTR [r12+0x50],r14
    72fde4f01bed:	mov    r13,QWORD PTR [r12+0x48]
    72fde4f01bf2:	add    r8,r13
    72fde4f01bf5:	mov    QWORD PTR [r12+0x48],r8
    72fde4f01bfa:	mov    rcx,QWORD PTR [r12+0x380]
    72fde4f01c02:	jrcxz  0x72fde4f01c09
    72fde4f01c04:	jmp    0x72fde4f01f63
    72fde4f01c09:	cmp    BYTE PTR [rsp+0x8],0x0
    72fde4f01c0e:	jne    0x72fde4f01b76
    72fde4f01c14:	jmp    0x72fde4f01c19
    72fde4f01c19:	mov    r13d,0x0
    72fde4f01c1f:	mov    QWORD PTR [r12+0x98],r13
    72fde4f01c27:	mov    r13,QWORD PTR [r12+0x48]
    72fde4f01c2c:	mov    r14,QWORD PTR [r12+0x50]
    72fde4f01c31:	add    r14,r13
    72fde4f01c34:	mov    QWORD PTR [r12+0x48],r14
    72fde4f01c39:	mov    r13d,0x1
    72fde4f01c3f:	mov    QWORD PTR [r12],r13
    72fde4f01c43:	mov    r13,QWORD PTR [r12+0x40]
    72fde4f01c48:	add    r13,0xc40
    72fde4f01c4f:	mov    QWORD PTR [r13+0x0],r14
    72fde4f01c53:	mov    r13d,0x0
    72fde4f01c59:	mov    DWORD PTR [r12+0x32c],r13d
    72fde4f01c61:	mov    r13d,0x1
    72fde4f01c67:	mov    QWORD PTR [r12],r13
    72fde4f01c6b:	mov    r13d,0x4103e8
    72fde4f01c71:	mov    QWORD PTR [r12+0xf0],r13
    72fde4f01c79:	mov    r13d,0x410938
    72fde4f01c7f:	mov    QWORD PTR [r12+0x100],r13
    72fde4f01c87:	mov    r11,QWORD PTR [rsp]
    72fde4f01c8b:	mov    QWORD PTR [r12+0x398],r11
    72fde4f01c93:	mov    edi,0x410938
    72fde4f01c98:	mov    QWORD PTR [r12+0x100],rdi
    72fde4f01ca0:	add    rsp,0x10
    72fde4f01ca4:	nop    DWORD PTR [rax+0x0]
    72fde4f01ca8:	jmp    QWORD PTR [rip+0x2]        # 0x72fde4f01cb0
    72fde4f01cae:	xchg   ax,ax
    72fde4f01cb0:	xor    BYTE PTR [rdi],dl
    72fde4f01cb2:	lock in al,0xfd
    72fde4f01cb5:	jb     0x72fde4f01cb7
    72fde4f01cb7:	add    al,al
    72fde4f01cb9:	sbb    al,0xf0
    72fde4f01cbb:	in     al,0xfd
    72fde4f01cbd:	jb     0x72fde4f01cbf
    72fde4f01cbf:	add    BYTE PTR [rcx-0x45],cl
    72fde4f01cc2:	rex or ebp,esi
    72fde4f01cc5:	sahf
    72fde4f01cc6:	int    0x5c
    72fde4f01cc8:	add    BYTE PTR [rax],al
    72fde4f01cca:	jmp    r11
    72fde4f01ccd:	mov    r13d,DWORD PTR [r12+0xa0]
    72fde4f01cd5:	add    r13d,0x11
    72fde4f01cd9:	mov    QWORD PTR [r12],r13
    72fde4f01cdd:	mov    r13d,0x41034c
    72fde4f01ce3:	mov    QWORD PTR [r12+0xf0],r13
    72fde4f01ceb:	mov    r13d,0x410938
    72fde4f01cf1:	mov    QWORD PTR [r12+0x100],r13
    72fde4f01cf9:	mov    r11,QWORD PTR [rsp]
    72fde4f01cfd:	mov    QWORD PTR [r12+0x398],r11
    72fde4f01d05:	mov    edi,0x410938
    72fde4f01d0a:	mov    QWORD PTR [r12+0x100],rdi
    72fde4f01d12:	add    rsp,0x10
    72fde4f01d16:	xchg   ax,ax
    72fde4f01d18:	jmp    QWORD PTR [rip+0x2]        # 0x72fde4f01d20
    72fde4f01d1e:	xchg   ax,ax
    72fde4f01d20:	xor    BYTE PTR [rdi],dl
    72fde4f01d22:	lock in al,0xfd
    72fde4f01d25:	jb     0x72fde4f01d27
    72fde4f01d27:	add    BYTE PTR [rax],dh
    72fde4f01d29:	sbb    eax,0x72fde4f0
    72fde4f01d2e:	add    BYTE PTR [rax],al
    72fde4f01d30:	movabs r11,0x5ccd9ef50940
    72fde4f01d3a:	jmp    r11
    72fde4f01d3d:	mov    eax,0x410358
    72fde4f01d42:	mov    QWORD PTR [r12+0x100],rax
    72fde4f01d4a:	push   rdx
    72fde4f01d4b:	push   rsi
    72fde4f01d4c:	push   r10
    72fde4f01d4e:	push   r11
    72fde4f01d50:	mov    r11,rax
    72fde4f01d53:	lahf
    72fde4f01d54:	seto   al
    72fde4f01d57:	mov    WORD PTR [rsp+0x20],ax
    72fde4f01d5c:	mov    rax,r11
    72fde4f01d5f:	mov    rdx,QWORD PTR [rsp+0x20]
    72fde4f01d64:	mov    r10d,edx
    72fde4f01d67:	and    r10d,0xc000
    72fde4f01d6e:	shl    r10d,0x10
    72fde4f01d72:	mov    r11d,edx
    72fde4f01d75:	and    r11d,0x100
    72fde4f01d7c:	shl    r11d,0x15
    72fde4f01d80:	or     r10d,r11d
    72fde4f01d83:	and    edx,0x1
    72fde4f01d86:	shl    edx,0x1c
    72fde4f01d89:	or     r10d,edx
    72fde4f01d8c:	btc    r10,0x1d
    72fde4f01d91:	mov    r11d,0xf0000000
    72fde4f01d97:	and    r11,r10
    72fde4f01d9a:	movabs rsi,0xffffffff0fffffff
    72fde4f01da4:	and    rbx,rsi
    72fde4f01da7:	or     rbx,r11
    72fde4f01daa:	pop    r11
    72fde4f01dac:	pop    r10
    72fde4f01dae:	pop    rsi
    72fde4f01daf:	pop    rdx
    72fde4f01db0:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f01db8:	add    rsp,0x10
    72fde4f01dbc:	mov    eax,0xc
    72fde4f01dc1:	movabs r11,0x5ccd9ef50ca0
    72fde4f01dcb:	jmp    r11
    72fde4f01dce:	mov    eax,0x41038c
    72fde4f01dd3:	mov    QWORD PTR [r12+0x100],rax
    72fde4f01ddb:	push   rdx
    72fde4f01ddc:	push   rsi
    72fde4f01ddd:	push   r10
    72fde4f01ddf:	push   r11
    72fde4f01de1:	mov    r11,rax
    72fde4f01de4:	lahf
    72fde4f01de5:	seto   al
    72fde4f01de8:	mov    WORD PTR [rsp+0x20],ax
    72fde4f01ded:	mov    rax,r11
    72fde4f01df0:	mov    rdx,QWORD PTR [rsp+0x20]
    72fde4f01df5:	mov    r10d,edx
    72fde4f01df8:	and    r10d,0xc000
    72fde4f01dff:	shl    r10d,0x10
    72fde4f01e03:	mov    r11d,edx
    72fde4f01e06:	and    r11d,0x100
    72fde4f01e0d:	shl    r11d,0x15
    72fde4f01e11:	or     r10d,r11d
    72fde4f01e14:	and    edx,0x1
    72fde4f01e17:	shl    edx,0x1c
    72fde4f01e1a:	or     r10d,edx
    72fde4f01e1d:	btc    r10,0x1d
    72fde4f01e22:	mov    r11d,0xf0000000
    72fde4f01e28:	and    r11,r10
    72fde4f01e2b:	movabs rsi,0xffffffff0fffffff
    72fde4f01e35:	and    rbx,rsi
    72fde4f01e38:	or     rbx,r11
    72fde4f01e3b:	pop    r11
    72fde4f01e3d:	pop    r10
    72fde4f01e3f:	pop    rsi
    72fde4f01e40:	pop    rdx
    72fde4f01e41:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f01e49:	add    rsp,0x10
    72fde4f01e4d:	mov    eax,0xc
    72fde4f01e52:	movabs r11,0x5ccd9ef50ca0
    72fde4f01e5c:	jmp    r11
    72fde4f01e5f:	mov    eax,0x410398
    72fde4f01e64:	mov    QWORD PTR [r12+0x100],rax
    72fde4f01e6c:	push   rdx
    72fde4f01e6d:	push   rsi
    72fde4f01e6e:	push   r10
    72fde4f01e70:	push   r11
    72fde4f01e72:	mov    rdx,QWORD PTR [rsp+0x20]
    72fde4f01e77:	mov    r10d,edx
    72fde4f01e7a:	and    r10d,0xc000
    72fde4f01e81:	shl    r10d,0x10
    72fde4f01e85:	mov    r11d,edx
    72fde4f01e88:	and    r11d,0x100
    72fde4f01e8f:	shl    r11d,0x15
    72fde4f01e93:	or     r10d,r11d
    72fde4f01e96:	and    edx,0x1
    72fde4f01e99:	shl    edx,0x1c
    72fde4f01e9c:	or     r10d,edx
    72fde4f01e9f:	btc    r10,0x1d
    72fde4f01ea4:	mov    r11d,0xf0000000
    72fde4f01eaa:	and    r11,r10
    72fde4f01ead:	movabs rsi,0xffffffff0fffffff
    72fde4f01eb7:	and    rbx,rsi
    72fde4f01eba:	or     rbx,r11
    72fde4f01ebd:	pop    r11
    72fde4f01ebf:	pop    r10
    72fde4f01ec1:	pop    rsi
    72fde4f01ec2:	pop    rdx
    72fde4f01ec3:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f01ecb:	add    rsp,0x10
    72fde4f01ecf:	mov    eax,0xc
    72fde4f01ed4:	movabs r11,0x5ccd9ef50ca0
    72fde4f01ede:	jmp    r11
    72fde4f01ee1:	mov    eax,0x41039c
    72fde4f01ee6:	mov    QWORD PTR [r12+0x100],rax
    72fde4f01eee:	push   rdx
    72fde4f01eef:	push   rsi
    72fde4f01ef0:	push   r10
    72fde4f01ef2:	push   r11
    72fde4f01ef4:	mov    rdx,QWORD PTR [rsp+0x20]
    72fde4f01ef9:	mov    r10d,edx
    72fde4f01efc:	and    r10d,0xc000
    72fde4f01f03:	shl    r10d,0x10
    72fde4f01f07:	mov    r11d,edx
    72fde4f01f0a:	and    r11d,0x100
    72fde4f01f11:	shl    r11d,0x15
    72fde4f01f15:	or     r10d,r11d
    72fde4f01f18:	and    edx,0x1
    72fde4f01f1b:	shl    edx,0x1c
    72fde4f01f1e:	or     r10d,edx
    72fde4f01f21:	btc    r10,0x1d
    72fde4f01f26:	mov    r11d,0xf0000000
    72fde4f01f2c:	and    r11,r10
    72fde4f01f2f:	movabs rsi,0xffffffff0fffffff
    72fde4f01f39:	and    rbx,rsi
    72fde4f01f3c:	or     rbx,r11
    72fde4f01f3f:	pop    r11
    72fde4f01f41:	pop    r10
    72fde4f01f43:	pop    rsi
    72fde4f01f44:	pop    rdx
    72fde4f01f45:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f01f4d:	add    rsp,0x10
    72fde4f01f51:	mov    eax,0xc
    72fde4f01f56:	movabs r11,0x5ccd9ef50ca0
    72fde4f01f60:	jmp    r11
    72fde4f01f63:	mov    eax,0x4103cc
    72fde4f01f68:	mov    QWORD PTR [r12+0x100],rax
    72fde4f01f70:	push   rdx
    72fde4f01f71:	push   rsi
    72fde4f01f72:	push   r10
    72fde4f01f74:	push   r11
    72fde4f01f76:	mov    rdx,QWORD PTR [rsp+0x20]
    72fde4f01f7b:	mov    r10d,edx
    72fde4f01f7e:	and    r10d,0xc000
    72fde4f01f85:	shl    r10d,0x10
    72fde4f01f89:	mov    r11d,edx
    72fde4f01f8c:	and    r11d,0x100
    72fde4f01f93:	shl    r11d,0x15
    72fde4f01f97:	or     r10d,r11d
    72fde4f01f9a:	and    edx,0x1
    72fde4f01f9d:	shl    edx,0x1c
    72fde4f01fa0:	or     r10d,edx
    72fde4f01fa3:	btc    r10,0x1d
    72fde4f01fa8:	mov    r11d,0xf0000000
    72fde4f01fae:	and    r11,r10
    72fde4f01fb1:	movabs rsi,0xffffffff0fffffff
    72fde4f01fbb:	and    rbx,rsi
    72fde4f01fbe:	or     rbx,r11
    72fde4f01fc1:	pop    r11
    72fde4f01fc3:	pop    r10
    72fde4f01fc5:	pop    rsi
    72fde4f01fc6:	pop    rdx
    72fde4f01fc7:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f01fcf:	add    rsp,0x10
    72fde4f01fd3:	mov    eax,0xc
    72fde4f01fd8:	movabs r11,0x5ccd9ef50ca0
    72fde4f01fe2:	jmp    r11
    72fde4f01fe5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72fde4f01ff0:	sub    rsp,0x10
    72fde4f01ff4:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f01ffc:	mov    QWORD PTR [rsp],r11
    72fde4f02000:	jmp    0x72fde4f0198d
    72fde4f02005:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72fde4f02010:	sub    rsp,0x10
    72fde4f02014:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f0201c:	mov    QWORD PTR [rsp],r11
    72fde4f02020:	mov    r11,rax
    72fde4f02023:	movzx  eax,WORD PTR [rsp]
    72fde4f02027:	add    al,0x7f
    72fde4f02029:	sahf
    72fde4f0202a:	mov    rax,r11
    72fde4f0202d:	jmp    0x72fde4f019aa
    72fde4f02032:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72fde4f02040:	sub    rsp,0x10
    72fde4f02044:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f0204c:	mov    QWORD PTR [rsp],r11
    72fde4f02050:	jmp    0x72fde4f019ee
    72fde4f02055:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72fde4f02060:	sub    rsp,0x10
    72fde4f02064:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f0206c:	mov    QWORD PTR [rsp],r11
    72fde4f02070:	jmp    0x72fde4f01a62
    72fde4f02075:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72fde4f02080:	sub    rsp,0x10
    72fde4f02084:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f0208c:	mov    QWORD PTR [rsp],r11
    72fde4f02090:	jmp    0x72fde4f01abd
    72fde4f02095:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72fde4f020a0:	sub    rsp,0x10
    72fde4f020a4:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f020ac:	mov    QWORD PTR [rsp],r11
    72fde4f020b0:	jmp    0x72fde4f01ad1
    72fde4f020b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72fde4f020c0:	sub    rsp,0x10
    72fde4f020c4:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f020cc:	mov    QWORD PTR [rsp],r11
    72fde4f020d0:	jmp    0x72fde4f01ae1
    72fde4f020d5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72fde4f020e0:	sub    rsp,0x10
    72fde4f020e4:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f020ec:	mov    QWORD PTR [rsp],r11
    72fde4f020f0:	jmp    0x72fde4f01b41
    72fde4f020f5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72fde4f02100:	sub    rsp,0x10
    72fde4f02104:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f0210c:	mov    QWORD PTR [rsp],r11
    72fde4f02110:	jmp    0x72fde4f01b76
    72fde4f02115:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72fde4f02120:	sub    rsp,0x10
    72fde4f02124:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f0212c:	mov    QWORD PTR [rsp],r11
    72fde4f02130:	jmp    0x72fde4f01c19
    72fde4f02135:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72fde4f02140:	sub    rsp,0x10
    72fde4f02144:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f0214c:	mov    QWORD PTR [rsp],r11
    72fde4f02150:	jmp    0x72fde4f01ccd
    72fde4f02155:	nop
    72fde4f02156:	nop
    72fde4f02157:	nop
