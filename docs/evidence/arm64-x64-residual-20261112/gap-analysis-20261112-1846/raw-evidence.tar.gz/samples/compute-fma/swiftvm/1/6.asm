
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/1/6.bin:     file format binary


Disassembly of section .data:

000072fde4f01730 <.data>:
    72fde4f01730:	sub    rsp,0x10
    72fde4f01734:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f0173c:	mov    QWORD PTR [rsp],r11
    72fde4f01740:	mov    r13d,DWORD PTR [r12]
    72fde4f01744:	mov    r14d,r13d
    72fde4f01747:	mov    r14d,r14d
    72fde4f0174a:	shr    r14d,0x10
    72fde4f0174e:	xor    r13d,r14d
    72fde4f01751:	mov    QWORD PTR [r12+0x40],r13
    72fde4f01756:	mov    r14d,0x352d
    72fde4f0175c:	mov    QWORD PTR [r12+0x48],r14
    72fde4f01761:	mov    r14d,0x352d
    72fde4f01767:	mov    r15d,0x7feb
    72fde4f0176d:	and    r15d,0xffff
    72fde4f01774:	mov    rax,r14
    72fde4f01777:	movabs rcx,0xffffffff0000ffff
    72fde4f01781:	and    rax,rcx
    72fde4f01784:	mov    rdx,r15
    72fde4f01787:	shl    rdx,0x10
    72fde4f0178b:	mov    ecx,0xffff0000
    72fde4f01790:	and    rdx,rcx
    72fde4f01793:	or     rax,rdx
    72fde4f01796:	mov    ebp,eax
    72fde4f01798:	mov    QWORD PTR [r12+0x48],rbp
    72fde4f0179d:	mov    r14d,0x0
    72fde4f017a3:	imul   r13d,ebp
    72fde4f017a7:	mov    r15d,r14d
    72fde4f017aa:	add    r15d,r13d
    72fde4f017ad:	mov    QWORD PTR [r12+0x40],r15
    72fde4f017b2:	mov    r13d,0xa68b
    72fde4f017b8:	mov    QWORD PTR [r12+0x48],r13
    72fde4f017bd:	mov    r13d,0xa68b
    72fde4f017c3:	mov    r14d,0x846c
    72fde4f017c9:	and    r14d,0xffff
    72fde4f017d0:	mov    rax,r13
    72fde4f017d3:	movabs rcx,0xffffffff0000ffff
    72fde4f017dd:	and    rax,rcx
    72fde4f017e0:	mov    rdx,r14
    72fde4f017e3:	shl    rdx,0x10
    72fde4f017e7:	mov    ecx,0xffff0000
    72fde4f017ec:	and    rdx,rcx
    72fde4f017ef:	or     rax,rdx
    72fde4f017f2:	mov    ebp,eax
    72fde4f017f4:	mov    QWORD PTR [r12+0x48],rbp
    72fde4f017f9:	mov    r13d,r15d
    72fde4f017fc:	mov    r13d,r13d
    72fde4f017ff:	shr    r13d,0xf
    72fde4f01803:	xor    r15d,r13d
    72fde4f01806:	mov    QWORD PTR [r12+0x40],r15
    72fde4f0180b:	mov    r13d,0x0
    72fde4f01811:	imul   r15d,ebp
    72fde4f01815:	mov    r14d,r13d
    72fde4f01818:	add    r14d,r15d
    72fde4f0181b:	mov    QWORD PTR [r12+0x40],r14
    72fde4f01820:	mov    r13d,r14d
    72fde4f01823:	mov    r13d,r13d
    72fde4f01826:	shr    r13d,0x10
    72fde4f0182a:	xor    r14d,r13d
    72fde4f0182d:	mov    QWORD PTR [r12],r14
    72fde4f01831:	mov    rcx,QWORD PTR [r12+0x380]
    72fde4f01839:	jrcxz  0x72fde4f01840
    72fde4f0183b:	jmp    0x72fde4f01875
    72fde4f01840:	mov    r13,QWORD PTR [r12+0xf0]
    72fde4f01848:	mov    QWORD PTR [r12+0x100],r13
    72fde4f01850:	mov    r11,QWORD PTR [rsp]
    72fde4f01854:	mov    QWORD PTR [r12+0x398],r11
    72fde4f0185c:	mov    rdi,QWORD PTR [r12+0x100]
    72fde4f01864:	add    rsp,0x10
    72fde4f01868:	movabs r11,0x5ccd9ef50940
    72fde4f01872:	jmp    r11
    72fde4f01875:	mov    eax,0x41095c
    72fde4f0187a:	mov    QWORD PTR [r12+0x100],rax
    72fde4f01882:	push   rdx
    72fde4f01883:	push   rsi
    72fde4f01884:	push   r10
    72fde4f01886:	push   r11
    72fde4f01888:	mov    rdx,QWORD PTR [rsp+0x20]
    72fde4f0188d:	mov    r10d,edx
    72fde4f01890:	and    r10d,0xc000
    72fde4f01897:	shl    r10d,0x10
    72fde4f0189b:	mov    r11d,edx
    72fde4f0189e:	and    r11d,0x100
    72fde4f018a5:	shl    r11d,0x15
    72fde4f018a9:	or     r10d,r11d
    72fde4f018ac:	and    edx,0x1
    72fde4f018af:	shl    edx,0x1c
    72fde4f018b2:	or     r10d,edx
    72fde4f018b5:	btc    r10,0x1d
    72fde4f018ba:	mov    r11d,0xf0000000
    72fde4f018c0:	and    r11,r10
    72fde4f018c3:	movabs rsi,0xffffffff0fffffff
    72fde4f018cd:	and    rbx,rsi
    72fde4f018d0:	or     rbx,r11
    72fde4f018d3:	pop    r11
    72fde4f018d5:	pop    r10
    72fde4f018d7:	pop    rsi
    72fde4f018d8:	pop    rdx
    72fde4f018d9:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f018e1:	add    rsp,0x10
    72fde4f018e5:	mov    eax,0xc
    72fde4f018ea:	movabs r11,0x5ccd9ef50ca0
    72fde4f018f4:	jmp    r11
    72fde4f018f7:	nop
