
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/0/0.bin:     file format binary


Disassembly of section .data:

00007076cdcfe000 <.data>:
    7076cdcfe000:	sub    rsp,0x10
    7076cdcfe004:	mov    r11,QWORD PTR [r12+0x398]
    7076cdcfe00c:	mov    QWORD PTR [rsp],r11
    7076cdcfe010:	mov    r13,QWORD PTR [r12+0xf8]
    7076cdcfe018:	sub    r13,0x1b0
    7076cdcfe01f:	mov    QWORD PTR [r12+0xf8],r13
    7076cdcfe027:	mov    r14d,0x420000
    7076cdcfe02d:	mov    QWORD PTR [r12+0x40],r14
    7076cdcfe032:	mov    r14d,0x420000
    7076cdcfe038:	mov    QWORD PTR [r12+0x48],r14
    7076cdcfe03d:	mov    r14,r13
    7076cdcfe040:	add    r14,0x1a0
    7076cdcfe047:	mov    r15,r14
    7076cdcfe04a:	add    r15,0x8
    7076cdcfe04e:	mov    rbp,QWORD PTR [r12+0xa0]
    7076cdcfe056:	mov    r8,QWORD PTR [r12+0x98]
    7076cdcfe05e:	mov    QWORD PTR [r14],rbp
    7076cdcfe061:	mov    r14d,0x0
    7076cdcfe067:	mov    DWORD PTR [r12+0x32c],r14d
    7076cdcfe06f:	mov    QWORD PTR [r15],r8
    7076cdcfe072:	mov    r14d,0x420a30
    7076cdcfe078:	movdqu xmm2,XMMWORD PTR [r14]
    7076cdcfe07d:	movdqu XMMWORD PTR [r12+0x110],xmm2
    7076cdcfe087:	mov    r14d,0x4209c0
    7076cdcfe08d:	movdqu xmm3,XMMWORD PTR [r14]
    7076cdcfe092:	movdqu XMMWORD PTR [r12+0x120],xmm3
    7076cdcfe09c:	mov    r14d,0x420a50
    7076cdcfe0a2:	movdqu xmm4,XMMWORD PTR [r14]
    7076cdcfe0a7:	movdqu XMMWORD PTR [r12+0x130],xmm4
    7076cdcfe0b1:	mov    r14d,0x4209f0
    7076cdcfe0b7:	movdqu xmm5,XMMWORD PTR [r14]
    7076cdcfe0bc:	movdqu XMMWORD PTR [r12+0x140],xmm5
    7076cdcfe0c6:	mov    r14d,0x430000
    7076cdcfe0cc:	mov    rax,r14
    7076cdcfe0cf:	add    rax,0xc60
    7076cdcfe0d5:	mov    QWORD PTR [r12+0x98],rax
    7076cdcfe0dd:	mov    r15d,0x420a60
    7076cdcfe0e3:	movdqu xmm6,XMMWORD PTR [r15]
    7076cdcfe0e8:	movdqu XMMWORD PTR [r12+0x150],xmm6
    7076cdcfe0f2:	mov    r15,QWORD PTR [r12+0x98]
    7076cdcfe0fa:	add    r15,0x10
    7076cdcfe0fe:	mov    rdi,QWORD PTR [r12+0x98]
    7076cdcfe106:	movdqu XMMWORD PTR [rdi],xmm2
    7076cdcfe10a:	movdqu XMMWORD PTR [r15],xmm3
    7076cdcfe10f:	mov    r15,QWORD PTR [r12+0x98]
    7076cdcfe117:	add    r15,0x20
    7076cdcfe11b:	mov    rbp,r15
    7076cdcfe11e:	add    rbp,0x10
    7076cdcfe122:	movdqu XMMWORD PTR [r15],xmm4
    7076cdcfe127:	movdqu XMMWORD PTR [rbp+0x0],xmm5
    7076cdcfe12c:	mov    r15d,0x4209b0
    7076cdcfe132:	movdqu xmm4,XMMWORD PTR [r15]
    7076cdcfe137:	movdqu XMMWORD PTR [r12+0x130],xmm4
    7076cdcfe141:	mov    r15d,0x4209a0
    7076cdcfe147:	movdqu xmm5,XMMWORD PTR [r15]
    7076cdcfe14c:	movdqu XMMWORD PTR [r12+0x140],xmm5
    7076cdcfe156:	mov    r15,QWORD PTR [r12+0x98]
    7076cdcfe15e:	add    r15,0x100
    7076cdcfe165:	mov    rbp,r15
    7076cdcfe168:	add    rbp,0x10
    7076cdcfe16c:	movdqu XMMWORD PTR [r15],xmm2
    7076cdcfe171:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    7076cdcfe176:	mov    r15,QWORD PTR [r12+0x98]
    7076cdcfe17e:	add    r15,0x40
    7076cdcfe182:	mov    rbp,r15
    7076cdcfe185:	add    rbp,0x10
    7076cdcfe189:	movdqu XMMWORD PTR [r15],xmm6
    7076cdcfe18e:	movdqu XMMWORD PTR [rbp+0x0],xmm4
    7076cdcfe193:	mov    r15d,0x420990
    7076cdcfe199:	movdqu xmm2,XMMWORD PTR [r15]
    7076cdcfe19e:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7076cdcfe1a8:	mov    r15d,0x420a00
    7076cdcfe1ae:	movdqu xmm3,XMMWORD PTR [r15]
    7076cdcfe1b3:	movdqu XMMWORD PTR [r12+0x150],xmm3
    7076cdcfe1bd:	mov    r15d,0xf8d3
    7076cdcfe1c3:	mov    QWORD PTR [r12+0x48],r15
    7076cdcfe1c8:	mov    r15,QWORD PTR [r12+0x98]
    7076cdcfe1d0:	add    r15,0x60
    7076cdcfe1d4:	mov    rbp,r15
    7076cdcfe1d7:	add    rbp,0x10
    7076cdcfe1db:	movdqu XMMWORD PTR [r15],xmm5
    7076cdcfe1e0:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7076cdcfe1e5:	mov    r15d,0x420a10
    7076cdcfe1eb:	movdqu xmm2,XMMWORD PTR [r15]
    7076cdcfe1f0:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7076cdcfe1fa:	mov    r15d,0x4209e0
    7076cdcfe200:	movdqu xmm4,XMMWORD PTR [r15]
    7076cdcfe205:	movdqu XMMWORD PTR [r12+0x140],xmm4
    7076cdcfe20f:	mov    r15d,0xf8d3
    7076cdcfe215:	mov    ebp,0x421d
    7076cdcfe21a:	and    ebp,0xffff
    7076cdcfe220:	mov    rax,r15
    7076cdcfe223:	movabs rcx,0xffffffff0000ffff
    7076cdcfe22d:	and    rax,rcx
    7076cdcfe230:	mov    rdx,rbp
    7076cdcfe233:	shl    rdx,0x10
    7076cdcfe237:	mov    ecx,0xffff0000
    7076cdcfe23c:	and    rdx,rcx
    7076cdcfe23f:	or     rax,rdx
    7076cdcfe242:	mov    r8d,eax
    7076cdcfe245:	mov    QWORD PTR [r12+0x48],r8
    7076cdcfe24a:	mov    r15,QWORD PTR [r12+0x98]
    7076cdcfe252:	add    r15,0x80
    7076cdcfe259:	mov    rbp,r15
    7076cdcfe25c:	add    rbp,0x10
    7076cdcfe260:	movdqu XMMWORD PTR [r15],xmm3
    7076cdcfe265:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7076cdcfe26a:	mov    r15d,0x420a80
    7076cdcfe270:	movdqu xmm2,XMMWORD PTR [r15]
    7076cdcfe275:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7076cdcfe27f:	mov    r15d,0x420a90
    7076cdcfe285:	movdqu xmm3,XMMWORD PTR [r15]
    7076cdcfe28a:	movdqu XMMWORD PTR [r12+0x150],xmm3
    7076cdcfe294:	mov    r15d,0x3e8
    7076cdcfe29a:	mov    QWORD PTR [r12+0xa0],r15
    7076cdcfe2a2:	mov    r15,QWORD PTR [r12+0x98]
    7076cdcfe2aa:	add    r15,0xa0
    7076cdcfe2b1:	mov    rbp,r15
    7076cdcfe2b4:	add    rbp,0x10
    7076cdcfe2b8:	movdqu XMMWORD PTR [r15],xmm4
    7076cdcfe2bd:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7076cdcfe2c2:	mov    r15d,0x420a70
    7076cdcfe2c8:	movdqu xmm2,XMMWORD PTR [r15]
    7076cdcfe2cd:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7076cdcfe2d7:	mov    r15d,0x420a20
    7076cdcfe2dd:	movdqu xmm4,XMMWORD PTR [r15]
    7076cdcfe2e2:	movdqu XMMWORD PTR [r12+0x140],xmm4
    7076cdcfe2ec:	mov    r15,r13
    7076cdcfe2ef:	add    r15,0x150
    7076cdcfe2f6:	mov    rbp,r15
    7076cdcfe2f9:	add    rbp,0x8
    7076cdcfe2fd:	mov    r9,QWORD PTR [r12+0x200]
    7076cdcfe305:	mov    r14,QWORD PTR [r12+0x1f0]
    7076cdcfe30d:	mov    QWORD PTR [r15],r9
    7076cdcfe310:	mov    QWORD PTR [rbp+0x0],r14
    7076cdcfe314:	mov    r14,QWORD PTR [r12+0x98]
    7076cdcfe31c:	add    r14,0xc0
    7076cdcfe323:	mov    r15,r14
    7076cdcfe326:	add    r15,0x10
    7076cdcfe32a:	movdqu XMMWORD PTR [r14],xmm3
    7076cdcfe32f:	movdqu XMMWORD PTR [r15],xmm2
    7076cdcfe334:	mov    r14d,0x420a40
    7076cdcfe33a:	movdqu xmm2,XMMWORD PTR [r14]
    7076cdcfe33f:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7076cdcfe349:	mov    r14d,0x420aa8
    7076cdcfe34f:	mov    r15,QWORD PTR [r14]
    7076cdcfe352:	mov    r14d,0x0
    7076cdcfe358:	mov    QWORD PTR [r12+0x110],r15
    7076cdcfe360:	mov    QWORD PTR [r12+0x118],r14
    7076cdcfe368:	mov    r14d,0x420ab0
    7076cdcfe36e:	mov    QWORD PTR [r12+0x40],r14
    7076cdcfe373:	mov    r14,QWORD PTR [r12+0x98]
    7076cdcfe37b:	add    r14,0xe0
    7076cdcfe382:	mov    rbp,r14
    7076cdcfe385:	add    rbp,0x10
    7076cdcfe389:	movdqu XMMWORD PTR [r14],xmm4
    7076cdcfe38e:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7076cdcfe393:	mov    r14d,0x420b10
    7076cdcfe399:	movdqu xmm2,XMMWORD PTR [r14]
    7076cdcfe39e:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7076cdcfe3a8:	mov    r14,QWORD PTR [r12+0x98]
    7076cdcfe3b0:	add    r14,0x120
    7076cdcfe3b7:	mov    QWORD PTR [r14],r15
    7076cdcfe3ba:	mov    r14d,0x420af0
    7076cdcfe3c0:	mov    r15d,0x420b00
    7076cdcfe3c6:	movdqu xmm3,XMMWORD PTR [r14]
    7076cdcfe3cb:	movdqu xmm4,XMMWORD PTR [r15]
    7076cdcfe3d0:	movdqu XMMWORD PTR [r12+0x120],xmm3
    7076cdcfe3da:	movdqu XMMWORD PTR [r12+0x110],xmm4
    7076cdcfe3e4:	mov    r14,r13
    7076cdcfe3e7:	add    r14,0x130
    7076cdcfe3ee:	movdqu XMMWORD PTR [r14],xmm2
    7076cdcfe3f3:	mov    r14,r13
    7076cdcfe3f6:	add    r14,0x160
    7076cdcfe3fd:	mov    r15,r14
    7076cdcfe400:	add    r15,0x8
    7076cdcfe404:	mov    rbp,QWORD PTR [r12+0x1e0]
    7076cdcfe40c:	mov    r9,QWORD PTR [r12+0x1d0]
    7076cdcfe414:	mov    QWORD PTR [r14],rbp
    7076cdcfe417:	mov    QWORD PTR [r15],r9
    7076cdcfe41a:	mov    r14,r13
    7076cdcfe41d:	add    r14,0x110
    7076cdcfe424:	mov    r15,r14
    7076cdcfe427:	add    r15,0x10
    7076cdcfe42b:	movdqu XMMWORD PTR [r14],xmm3
    7076cdcfe430:	movdqu XMMWORD PTR [r15],xmm4
    7076cdcfe435:	mov    r14d,0x420ab0
    7076cdcfe43b:	mov    r15d,0x420ac0
    7076cdcfe441:	movdqu xmm2,XMMWORD PTR [r14]
    7076cdcfe446:	movdqu xmm3,XMMWORD PTR [r15]
    7076cdcfe44b:	movdqu XMMWORD PTR [r12+0x110],xmm2
    7076cdcfe455:	movdqu XMMWORD PTR [r12+0x120],xmm3
    7076cdcfe45f:	mov    r14,r13
    7076cdcfe462:	add    r14,0x170
    7076cdcfe469:	mov    r15,r14
    7076cdcfe46c:	add    r15,0x8
    7076cdcfe470:	mov    rbp,QWORD PTR [r12+0x1c0]
    7076cdcfe478:	mov    r9,QWORD PTR [r12+0x1b0]
    7076cdcfe480:	mov    QWORD PTR [r14],rbp
    7076cdcfe483:	mov    QWORD PTR [r15],r9
    7076cdcfe486:	mov    r14,r13
    7076cdcfe489:	add    r14,0x180
    7076cdcfe490:	mov    r15,r14
    7076cdcfe493:	add    r15,0x8
    7076cdcfe497:	mov    rbp,QWORD PTR [r12+0x1a0]
    7076cdcfe49f:	mov    r9,QWORD PTR [r12+0x190]
    7076cdcfe4a7:	mov    QWORD PTR [r14],rbp
    7076cdcfe4aa:	mov    QWORD PTR [r15],r9
    7076cdcfe4ad:	mov    r14,r13
    7076cdcfe4b0:	add    r14,0xd0
    7076cdcfe4b7:	mov    r15,r14
    7076cdcfe4ba:	add    r15,0x10
    7076cdcfe4be:	movdqu XMMWORD PTR [r14],xmm2
    7076cdcfe4c3:	movdqu XMMWORD PTR [r15],xmm3
    7076cdcfe4c8:	mov    r14d,0x420ad0
    7076cdcfe4ce:	mov    r15d,0x420ae0
    7076cdcfe4d4:	movdqu xmm2,XMMWORD PTR [r14]
    7076cdcfe4d9:	movdqu xmm3,XMMWORD PTR [r15]
    7076cdcfe4de:	movdqu XMMWORD PTR [r12+0x110],xmm2
    7076cdcfe4e8:	movdqu XMMWORD PTR [r12+0x130],xmm3
    7076cdcfe4f2:	mov    r14,r13
    7076cdcfe4f5:	add    r14,0x190
    7076cdcfe4fc:	mov    r15,r14
    7076cdcfe4ff:	add    r15,0x8
    7076cdcfe503:	mov    rbp,QWORD PTR [r12+0xe8]
    7076cdcfe50b:	mov    r9,QWORD PTR [r12+0xf0]
    7076cdcfe513:	mov    QWORD PTR [r14],rbp
    7076cdcfe516:	mov    QWORD PTR [r15],r9
    7076cdcfe519:	mov    r14,QWORD PTR [r12+0x98]
    7076cdcfe521:	add    r14,0x128
    7076cdcfe528:	mov    DWORD PTR [r14],r8d
    7076cdcfe52b:	mov    r14,r13
    7076cdcfe52e:	add    r14,0xf0
    7076cdcfe535:	mov    r15,r14
    7076cdcfe538:	add    r15,0x10
    7076cdcfe53c:	movdqu XMMWORD PTR [r14],xmm2
    7076cdcfe541:	movdqu XMMWORD PTR [r15],xmm3
    7076cdcfe546:	add    r13,0xd0
    7076cdcfe54d:	mov    QWORD PTR [r12],r13
    7076cdcfe551:	mov    r13d,0x0
    7076cdcfe557:	mov    rcx,QWORD PTR [r12+0x98]
    7076cdcfe55f:	or     r13,rcx
    7076cdcfe562:	mov    QWORD PTR [r12+0x8],r13
    7076cdcfe567:	mov    r13d,0x12c
    7076cdcfe56d:	mov    QWORD PTR [r12+0x10],r13
    7076cdcfe572:	mov    r13d,0x410284
    7076cdcfe578:	mov    QWORD PTR [r12+0xf0],r13
    7076cdcfe580:	mov    r13d,0x4106bc
    7076cdcfe586:	mov    QWORD PTR [r12+0x100],r13
    7076cdcfe58e:	mov    r11,QWORD PTR [rsp]
    7076cdcfe592:	mov    QWORD PTR [r12+0x398],r11
    7076cdcfe59a:	mov    edi,0x4106bc
    7076cdcfe59f:	mov    QWORD PTR [r12+0x100],rdi
    7076cdcfe5a7:	add    rsp,0x10
    7076cdcfe5ab:	nop    DWORD PTR [rax+rax*1+0x0]
    7076cdcfe5b0:	jmp    QWORD PTR [rip+0x2]        # 0x7076cdcfe5b8
    7076cdcfe5b6:	xchg   ax,ax
    7076cdcfe5b8:	loopne 0x7076cdcfe59f
    7076cdcfe5ba:	iret
    7076cdcfe5bb:	int    0x76
    7076cdcfe5bd:	jo     0x7076cdcfe5bf
    7076cdcfe5bf:	add    al,cl
    7076cdcfe5c1:	in     eax,0xcf
    7076cdcfe5c3:	int    0x76
    7076cdcfe5c5:	jo     0x7076cdcfe5c7
    7076cdcfe5c7:	add    BYTE PTR [rcx-0x45],cl
    7076cdcfe5ca:	rex cdq
    7076cdcfe5cc:	ds out 0x61,eax
    7076cdcfe5cf:	pop    rbx
    7076cdcfe5d0:	add    BYTE PTR [rax],al
    7076cdcfe5d2:	jmp    r11
    7076cdcfe5d5:	nop
    7076cdcfe5d6:	nop
    7076cdcfe5d7:	nop
