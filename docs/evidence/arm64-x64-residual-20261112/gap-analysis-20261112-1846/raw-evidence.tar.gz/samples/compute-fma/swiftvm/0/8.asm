
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/0/8.bin:     file format binary


Disassembly of section .data:

00007076cdd02160 <.data>:
    7076cdd02160:	sub    rsp,0x150
    7076cdd02167:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd0216f:	mov    QWORD PTR [rsp],r11
    7076cdd02173:	cmp    DWORD PTR [r12+0x310],0x0
    7076cdd0217c:	je     0x7076cdd02207
    7076cdd02182:	push   rdx
    7076cdd02183:	push   rsi
    7076cdd02184:	push   r10
    7076cdd02186:	push   r11
    7076cdd02188:	mov    rdx,QWORD PTR [rsp+0x20]
    7076cdd0218d:	mov    r10d,edx
    7076cdd02190:	and    r10d,0xc000
    7076cdd02197:	shl    r10d,0x10
    7076cdd0219b:	mov    r11d,edx
    7076cdd0219e:	and    r11d,0x100
    7076cdd021a5:	shl    r11d,0x15
    7076cdd021a9:	or     r10d,r11d
    7076cdd021ac:	and    edx,0x1
    7076cdd021af:	shl    edx,0x1c
    7076cdd021b2:	or     r10d,edx
    7076cdd021b5:	btc    r10,0x1d
    7076cdd021ba:	mov    r11d,0xf0000000
    7076cdd021c0:	and    r11,r10
    7076cdd021c3:	movabs rsi,0xffffffff0fffffff
    7076cdd021cd:	and    rbx,rsi
    7076cdd021d0:	or     rbx,r11
    7076cdd021d3:	pop    r11
    7076cdd021d5:	pop    r10
    7076cdd021d7:	pop    rsi
    7076cdd021d8:	pop    rdx
    7076cdd021d9:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd021e1:	mov    eax,0x4103e8
    7076cdd021e6:	mov    QWORD PTR [r12+0x100],rax
    7076cdd021ee:	add    rsp,0x150
    7076cdd021f5:	mov    eax,0x3
    7076cdd021fa:	movabs r11,0x5b61e73e9ca0
    7076cdd02204:	jmp    r11
    7076cdd02207:	mov    r13d,DWORD PTR [r12+0x98]
    7076cdd0220f:	add    r13d,0x1
    7076cdd02213:	mov    QWORD PTR [r12+0x98],r13
    7076cdd0221b:	sub    r13d,0x10000
    7076cdd02222:	mov    rcx,QWORD PTR [r12+0x380]
    7076cdd0222a:	jrcxz  0x7076cdd02231
    7076cdd0222c:	jmp    0x7076cdd06065
    7076cdd02231:	jne    0x7076cdd0224a
    7076cdd02237:	mov    r11,rax
    7076cdd0223a:	lahf
    7076cdd0223b:	seto   al
    7076cdd0223e:	mov    WORD PTR [rsp],ax
    7076cdd02242:	mov    rax,r11
    7076cdd02245:	jmp    0x7076cdd0225d
    7076cdd0224a:	mov    r11,rax
    7076cdd0224d:	lahf
    7076cdd0224e:	seto   al
    7076cdd02251:	mov    WORD PTR [rsp],ax
    7076cdd02255:	mov    rax,r11
    7076cdd02258:	jmp    0x7076cdd04add
    7076cdd0225d:	mov    r13d,0x420000
    7076cdd02263:	mov    QWORD PTR [r12+0x40],r13
    7076cdd02268:	movabs r13,0x100000001
    7076cdd02272:	mov    r14d,0x0
    7076cdd02278:	mov    QWORD PTR [r12+0x110],r13
    7076cdd02280:	mov    QWORD PTR [r12+0x118],r14
    7076cdd02288:	movabs r13,0x3fa0000000000000
    7076cdd02292:	mov    QWORD PTR [r12+0x50],r13
    7076cdd02297:	mov    r13d,0x420aa0
    7076cdd0229d:	mov    r14,QWORD PTR [r13+0x0]
    7076cdd022a1:	mov    r13d,0x0
    7076cdd022a7:	mov    QWORD PTR [r12+0x120],r14
    7076cdd022af:	mov    QWORD PTR [r12+0x128],r13
    7076cdd022b7:	movabs r13,0x4100000041
    7076cdd022c1:	mov    r14d,0x0
    7076cdd022c7:	mov    QWORD PTR [r12+0x140],r13
    7076cdd022cf:	mov    QWORD PTR [r12+0x148],r14
    7076cdd022d7:	movabs r13,0x3fc0000000000000
    7076cdd022e1:	movabs r14,0x3fc0000000000000
    7076cdd022eb:	mov    QWORD PTR [r12+0x150],r13
    7076cdd022f3:	mov    QWORD PTR [r12+0x158],r14
    7076cdd022fb:	movabs r13,0x200000002
    7076cdd02305:	mov    r14d,0x0
    7076cdd0230b:	mov    QWORD PTR [r12+0x160],r13
    7076cdd02313:	mov    QWORD PTR [r12+0x168],r14
    7076cdd0231b:	movabs r13,0x3fa0000000000000
    7076cdd02325:	mov    QWORD PTR [r12+0x130],r13
    7076cdd0232d:	mov    QWORD PTR [r12+0x138],r13
    7076cdd02335:	mov    r13d,0x2
    7076cdd0233b:	mov    QWORD PTR [r12+0x170],r13
    7076cdd02343:	mov    QWORD PTR [r12+0x178],r13
    7076cdd0234b:	mov    r13d,0x420000
    7076cdd02351:	mov    QWORD PTR [r12+0x40],r13
    7076cdd02356:	mov    r13d,0x430000
    7076cdd0235c:	mov    QWORD PTR [r12+0x50],r13
    7076cdd02361:	mov    r13d,0x4209d0
    7076cdd02367:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7076cdd0236d:	movdqu XMMWORD PTR [r12+0x180],xmm2
    7076cdd02377:	mov    r13d,0x0
    7076cdd0237d:	mov    QWORD PTR [r12+0x48],r13
    7076cdd02382:	mov    r13d,0x431000
    7076cdd02388:	add    r13,0xd90
    7076cdd0238f:	mov    QWORD PTR [r12+0x40],r13
    7076cdd02394:	mov    r13d,0x430c48
    7076cdd0239a:	mov    r14d,DWORD PTR [r12]
    7076cdd0239e:	mov    DWORD PTR [r13+0x0],r14d
    7076cdd023a2:	mov    r13d,0x0
    7076cdd023a8:	mov    DWORD PTR [r12+0x32c],r13d
    7076cdd023b0:	mov    r13d,0x431000
    7076cdd023b6:	add    r13,0xf90
    7076cdd023bd:	mov    QWORD PTR [r12+0x50],r13
    7076cdd023c2:	mov    r11,rax
    7076cdd023c5:	movzx  eax,WORD PTR [rsp]
    7076cdd023c9:	add    al,0x7f
    7076cdd023cb:	sahf
    7076cdd023cc:	mov    rax,r11
    7076cdd023cf:	jmp    0x7076cdd023d4
    7076cdd023d4:	mov    r13,QWORD PTR [r12+0x180]
    7076cdd023dc:	mov    r14,QWORD PTR [r12+0x188]
    7076cdd023e4:	mov    r15d,0x0
    7076cdd023ea:	mov    r11,rax
    7076cdd023ed:	lahf
    7076cdd023ee:	seto   al
    7076cdd023f1:	mov    WORD PTR [rsp],ax
    7076cdd023f5:	mov    rax,r11
    7076cdd023f8:	mov    ecx,0xffffffff
    7076cdd023fd:	and    r13,rcx
    7076cdd02400:	mov    rbp,r15
    7076cdd02403:	or     rbp,r13
    7076cdd02406:	mov    ecx,0xffffffff
    7076cdd0240b:	and    r14,rcx
    7076cdd0240e:	shl    r14,0x20
    7076cdd02412:	or     rbp,r14
    7076cdd02415:	mov    QWORD PTR [r12+0x210],rbp
    7076cdd0241d:	mov    QWORD PTR [r12+0x218],r15
    7076cdd02425:	movdqu xmm2,XMMWORD PTR [r12+0x140]
    7076cdd0242f:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    7076cdd02439:	movdqa xmm1,xmm3
    7076cdd0243d:	psubd  xmm2,xmm1
    7076cdd02441:	movdqa xmm14,xmm2
    7076cdd02446:	movdqa xmm1,xmm14
    7076cdd0244b:	movq   rax,xmm1
    7076cdd02450:	mov    r13,rax
    7076cdd02453:	movdqu xmm2,XMMWORD PTR [r12+0x180]
    7076cdd0245d:	movdqu xmm4,XMMWORD PTR [r12+0x170]
    7076cdd02467:	movdqa xmm1,xmm4
    7076cdd0246b:	paddq  xmm2,xmm1
    7076cdd0246f:	movdqu XMMWORD PTR [r12+0x180],xmm2
    7076cdd02479:	movdqu xmm2,XMMWORD PTR [r12+0x160]
    7076cdd02483:	movdqa xmm1,xmm2
    7076cdd02487:	paddd  xmm3,xmm1
    7076cdd0248b:	movdqa xmm14,xmm3
    7076cdd02490:	movdqa xmm1,xmm14
    7076cdd02495:	movq   rax,xmm1
    7076cdd0249a:	mov    r14,rax
    7076cdd0249d:	mov    r15d,0x0
    7076cdd024a3:	mov    QWORD PTR [r12+0x120],r14
    7076cdd024ab:	mov    QWORD PTR [r12+0x128],r15
    7076cdd024b3:	mov    r14d,0x0
    7076cdd024b9:	mov    ecx,0xffffffff
    7076cdd024be:	mov    r15,r13
    7076cdd024c1:	and    r15,rcx
    7076cdd024c4:	mov    rbp,r14
    7076cdd024c7:	or     rbp,r15
    7076cdd024ca:	shr    r13,0x20
    7076cdd024ce:	mov    ecx,0xffffffff
    7076cdd024d3:	and    r13,rcx
    7076cdd024d6:	or     r14,r13
    7076cdd024d9:	mov    QWORD PTR [r12+0x220],rbp
    7076cdd024e1:	mov    QWORD PTR [r12+0x228],r14
    7076cdd024e9:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    7076cdd024f3:	movdqu xmm3,XMMWORD PTR [r12+0x110]
    7076cdd024fd:	movdqa xmm1,xmm3
    7076cdd02501:	paddd  xmm2,xmm1
    7076cdd02505:	movdqa xmm14,xmm2
    7076cdd0250a:	movdqa xmm1,xmm14
    7076cdd0250f:	movq   rax,xmm1
    7076cdd02514:	mov    r13,rax
    7076cdd02517:	mov    r14d,0x0
    7076cdd0251d:	mov    QWORD PTR [r12+0x210],r13
    7076cdd02525:	mov    QWORD PTR [r12+0x218],r14
    7076cdd0252d:	lea    r13,[r12]
    7076cdd02531:	movabs r14,0xb6e61da31
    7076cdd0253b:	mov    r15d,0x410458
    7076cdd02541:	mov    rdx,QWORD PTR [rsp]
    7076cdd02545:	mov    r10d,edx
    7076cdd02548:	and    r10d,0xc000
    7076cdd0254f:	shl    r10d,0x10
    7076cdd02553:	mov    r11d,edx
    7076cdd02556:	and    r11d,0x100
    7076cdd0255d:	shl    r11d,0x15
    7076cdd02561:	or     r10d,r11d
    7076cdd02564:	and    edx,0x1
    7076cdd02567:	shl    edx,0x1c
    7076cdd0256a:	or     r10d,edx
    7076cdd0256d:	btc    r10,0x1d
    7076cdd02572:	mov    r11d,0xf0000000
    7076cdd02578:	and    r11,r10
    7076cdd0257b:	movabs rsi,0xffffffff0fffffff
    7076cdd02585:	and    rbx,rsi
    7076cdd02588:	or     rbx,r11
    7076cdd0258b:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd02597:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd0259f:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd025a5:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd025aa:	test   r10d,0x3f
    7076cdd025b1:	je     0x7076cdd025d6
    7076cdd025b7:	mov    r11d,r10d
    7076cdd025ba:	shr    r10d,1
    7076cdd025bd:	and    r10d,0x1e
    7076cdd025c1:	and    r11d,0x1
    7076cdd025c5:	or     r10d,r11d
    7076cdd025c8:	or     DWORD PTR [r12+0x314],r10d
    7076cdd025d0:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd025d6:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd025dc:	movabs r11,0x5b61e724b5e0
    7076cdd025e6:	mov    rdi,r13
    7076cdd025e9:	mov    rsi,r14
    7076cdd025ec:	mov    rdx,r15
    7076cdd025ef:	call   r11
    7076cdd025f2:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd025f8:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd02600:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd0260c:	mov    rbp,rax
    7076cdd0260f:	mov    r13,QWORD PTR [r12+0x210]
    7076cdd02617:	mov    r14d,0x0
    7076cdd0261d:	mov    ecx,0xffffffff
    7076cdd02622:	mov    r15,r13
    7076cdd02625:	and    r15,rcx
    7076cdd02628:	mov    rbp,r14
    7076cdd0262b:	or     rbp,r15
    7076cdd0262e:	shr    r13,0x20
    7076cdd02632:	mov    ecx,0xffffffff
    7076cdd02637:	and    r13,rcx
    7076cdd0263a:	or     r14,r13
    7076cdd0263d:	mov    QWORD PTR [r12+0x210],rbp
    7076cdd02645:	mov    QWORD PTR [r12+0x218],r14
    7076cdd0264d:	lea    r13,[r12]
    7076cdd02651:	movabs r14,0xb6e61da10
    7076cdd0265b:	mov    r15d,0x410460
    7076cdd02661:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd0266d:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd02675:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd0267b:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd02680:	test   r10d,0x3f
    7076cdd02687:	je     0x7076cdd026ac
    7076cdd0268d:	mov    r11d,r10d
    7076cdd02690:	shr    r10d,1
    7076cdd02693:	and    r10d,0x1e
    7076cdd02697:	and    r11d,0x1
    7076cdd0269b:	or     r10d,r11d
    7076cdd0269e:	or     DWORD PTR [r12+0x314],r10d
    7076cdd026a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd026ac:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd026b2:	movabs r11,0x5b61e724b5e0
    7076cdd026bc:	mov    rdi,r13
    7076cdd026bf:	mov    rsi,r14
    7076cdd026c2:	mov    rdx,r15
    7076cdd026c5:	call   r11
    7076cdd026c8:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd026ce:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd026d6:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd026e2:	mov    rbp,rax
    7076cdd026e5:	movdqu xmm2,XMMWORD PTR [r12+0x220]
    7076cdd026ef:	movdqu xmm3,XMMWORD PTR [r12+0x150]
    7076cdd026f9:	movdqa xmm0,xmm2
    7076cdd026fd:	movdqa xmm1,xmm3
    7076cdd02701:	mulpd  xmm0,xmm1
    7076cdd02705:	movdqa xmm14,xmm0
    7076cdd0270a:	movdqu xmm15,XMMWORD PTR [rip+0x435d]        # 0x7076cdd06a70
    7076cdd02713:	pand   xmm14,xmm15
    7076cdd02718:	movdqu xmm15,XMMWORD PTR [rip+0x435f]        # 0x7076cdd06a80
    7076cdd02721:	pcmpeqq xmm14,xmm15
    7076cdd02727:	movdqa xmm15,xmm0
    7076cdd0272c:	cmpunordpd xmm15,xmm0
    7076cdd02732:	por    xmm14,xmm15
    7076cdd02737:	pmovmskb ecx,xmm14
    7076cdd0273c:	jrcxz  0x7076cdd02743
    7076cdd0273e:	jmp    0x7076cdd04b55
    7076cdd02743:	movdqa xmm4,xmm0
    7076cdd02747:	movdqu XMMWORD PTR [r12+0x220],xmm4
    7076cdd02751:	mov    r13,QWORD PTR [r12+0x48]
    7076cdd02756:	mov    r14,QWORD PTR [r12+0x50]
    7076cdd0275b:	add    r14,r13
    7076cdd0275e:	movdqu XMMWORD PTR [r14],xmm4
    7076cdd02763:	mov    r14d,0x0
    7076cdd02769:	mov    DWORD PTR [r12+0x32c],r14d
    7076cdd02771:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    7076cdd0277b:	movdqu xmm3,XMMWORD PTR [r12+0x130]
    7076cdd02785:	movdqa xmm0,xmm2
    7076cdd02789:	movdqa xmm1,xmm3
    7076cdd0278d:	mulpd  xmm0,xmm1
    7076cdd02791:	movdqa xmm14,xmm0
    7076cdd02796:	movdqu xmm15,XMMWORD PTR [rip+0x42d1]        # 0x7076cdd06a70
    7076cdd0279f:	pand   xmm14,xmm15
    7076cdd027a4:	movdqu xmm15,XMMWORD PTR [rip+0x42d3]        # 0x7076cdd06a80
    7076cdd027ad:	pcmpeqq xmm14,xmm15
    7076cdd027b3:	movdqa xmm15,xmm0
    7076cdd027b8:	cmpunordpd xmm15,xmm0
    7076cdd027be:	por    xmm14,xmm15
    7076cdd027c3:	pmovmskb ecx,xmm14
    7076cdd027c8:	jrcxz  0x7076cdd027cf
    7076cdd027ca:	jmp    0x7076cdd04b79
    7076cdd027cf:	movdqa xmm4,xmm0
    7076cdd027d3:	movdqu XMMWORD PTR [r12+0x210],xmm4
    7076cdd027dd:	mov    r14,QWORD PTR [r12+0x40]
    7076cdd027e2:	add    r14,r13
    7076cdd027e5:	movdqu XMMWORD PTR [r14],xmm4
    7076cdd027ea:	add    r13,0x10
    7076cdd027ee:	mov    QWORD PTR [r12+0x48],r13
    7076cdd027f3:	sub    r13,0x200
    7076cdd027fa:	mov    rcx,QWORD PTR [r12+0x380]
    7076cdd02802:	jrcxz  0x7076cdd02809
    7076cdd02804:	jmp    0x7076cdd060f9
    7076cdd02809:	jne    0x7076cdd023d4
    7076cdd0280f:	mov    r11,rax
    7076cdd02812:	lahf
    7076cdd02813:	seto   al
    7076cdd02816:	mov    WORD PTR [rsp],ax
    7076cdd0281a:	mov    rax,r11
    7076cdd0281d:	jmp    0x7076cdd02822
    7076cdd02822:	mov    r13,QWORD PTR [r12+0x50]
    7076cdd02827:	mov    r14,r13
    7076cdd0282a:	add    r14,0x10
    7076cdd0282e:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7076cdd02834:	movdqu xmm3,XMMWORD PTR [r14]
    7076cdd02839:	movdqu XMMWORD PTR [r12+0x110],xmm2
    7076cdd02843:	movdqu XMMWORD PTR [r12+0x250],xmm3
    7076cdd0284d:	mov    r14d,0x0
    7076cdd02853:	mov    QWORD PTR [r12+0x48],r14
    7076cdd02858:	mov    r14,r13
    7076cdd0285b:	add    r14,0x40
    7076cdd0285f:	mov    r15,r14
    7076cdd02862:	add    r15,0x10
    7076cdd02866:	movdqu xmm3,XMMWORD PTR [r14]
    7076cdd0286b:	movdqu xmm4,XMMWORD PTR [r15]
    7076cdd02870:	movdqu XMMWORD PTR [r12+0x210],xmm3
    7076cdd0287a:	movdqu XMMWORD PTR [r12+0x1c0],xmm4
    7076cdd02884:	mov    r14,r13
    7076cdd02887:	add    r14,0x80
    7076cdd0288e:	mov    r15,r14
    7076cdd02891:	add    r15,0x10
    7076cdd02895:	movdqu xmm3,XMMWORD PTR [r14]
    7076cdd0289a:	movdqu xmm4,XMMWORD PTR [r15]
    7076cdd0289f:	movdqu XMMWORD PTR [r12+0x260],xmm3
    7076cdd028a9:	movdqu XMMWORD PTR [r12+0x280],xmm4
    7076cdd028b3:	mov    r14,QWORD PTR [r12+0xf8]
    7076cdd028bb:	movdqu XMMWORD PTR [r14],xmm2
    7076cdd028c0:	mov    r15d,0x0
    7076cdd028c6:	mov    DWORD PTR [r12+0x32c],r15d
    7076cdd028ce:	mov    r15,r13
    7076cdd028d1:	add    r15,0x20
    7076cdd028d5:	mov    rbp,r15
    7076cdd028d8:	add    rbp,0x10
    7076cdd028dc:	movdqu xmm2,XMMWORD PTR [r15]
    7076cdd028e1:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7076cdd028e6:	movdqu XMMWORD PTR [r12+0x170],xmm2
    7076cdd028f0:	movdqu XMMWORD PTR [r12+0x110],xmm3
    7076cdd028fa:	mov    r15,r13
    7076cdd028fd:	add    r15,0xc0
    7076cdd02904:	mov    rbp,r15
    7076cdd02907:	add    rbp,0x10
    7076cdd0290b:	movdqu xmm4,XMMWORD PTR [r15]
    7076cdd02910:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    7076cdd02915:	movdqu XMMWORD PTR [r12+0x180],xmm4
    7076cdd0291f:	movdqu XMMWORD PTR [r12+0x290],xmm5
    7076cdd02929:	mov    r15,r13
    7076cdd0292c:	add    r15,0x100
    7076cdd02933:	mov    rbp,r15
    7076cdd02936:	add    rbp,0x10
    7076cdd0293a:	movdqu xmm4,XMMWORD PTR [r15]
    7076cdd0293f:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    7076cdd02944:	movdqu XMMWORD PTR [r12+0x160],xmm4
    7076cdd0294e:	movdqu XMMWORD PTR [r12+0x2a0],xmm5
    7076cdd02958:	mov    r15,r13
    7076cdd0295b:	add    r15,0x140
    7076cdd02962:	mov    rbp,r15
    7076cdd02965:	add    rbp,0x10
    7076cdd02969:	movdqu xmm4,XMMWORD PTR [r15]
    7076cdd0296e:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    7076cdd02973:	movdqu XMMWORD PTR [r12+0x150],xmm4
    7076cdd0297d:	movdqu XMMWORD PTR [r12+0x2b0],xmm5
    7076cdd02987:	mov    r15,r14
    7076cdd0298a:	add    r15,0xb0
    7076cdd02991:	mov    rbp,r15
    7076cdd02994:	add    rbp,0x10
    7076cdd02998:	movdqu XMMWORD PTR [r15],xmm3
    7076cdd0299d:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7076cdd029a2:	mov    r15,r13
    7076cdd029a5:	add    r15,0x180
    7076cdd029ac:	mov    rbp,r15
    7076cdd029af:	add    rbp,0x10
    7076cdd029b3:	movdqu xmm2,XMMWORD PTR [r15]
    7076cdd029b8:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7076cdd029bd:	movdqu XMMWORD PTR [r12+0x2f0],xmm2
    7076cdd029c7:	movdqu XMMWORD PTR [r12+0x120],xmm3
    7076cdd029d1:	mov    r15,r13
    7076cdd029d4:	add    r15,0x1c0
    7076cdd029db:	mov    rbp,r15
    7076cdd029de:	add    rbp,0x10
    7076cdd029e2:	movdqu xmm5,XMMWORD PTR [r15]
    7076cdd029e7:	movdqu xmm6,XMMWORD PTR [rbp+0x0]
    7076cdd029ec:	movdqu XMMWORD PTR [r12+0x130],xmm5
    7076cdd029f6:	movdqu XMMWORD PTR [r12+0x140],xmm6
    7076cdd02a00:	mov    r15,r13
    7076cdd02a03:	add    r15,0x60
    7076cdd02a07:	mov    rbp,r15
    7076cdd02a0a:	add    rbp,0x10
    7076cdd02a0e:	movdqu xmm7,XMMWORD PTR [r15]
    7076cdd02a13:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    7076cdd02a19:	movdqu XMMWORD PTR [r12+0x2e0],xmm7
    7076cdd02a23:	movdqu XMMWORD PTR [r12+0x1f0],xmm8
    7076cdd02a2d:	mov    r15,r14
    7076cdd02a30:	add    r15,0x70
    7076cdd02a34:	mov    rbp,r15
    7076cdd02a37:	add    rbp,0x10
    7076cdd02a3b:	movdqu XMMWORD PTR [r15],xmm3
    7076cdd02a40:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7076cdd02a45:	mov    r15,r13
    7076cdd02a48:	add    r15,0xa0
    7076cdd02a4f:	mov    rbp,r15
    7076cdd02a52:	add    rbp,0x10
    7076cdd02a56:	movdqu xmm2,XMMWORD PTR [r15]
    7076cdd02a5b:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7076cdd02a60:	movdqu XMMWORD PTR [r12+0x2c0],xmm2
    7076cdd02a6a:	movdqu XMMWORD PTR [r12+0x1d0],xmm3
    7076cdd02a74:	mov    r15,r14
    7076cdd02a77:	add    r15,0x90
    7076cdd02a7e:	mov    rbp,r15
    7076cdd02a81:	add    rbp,0x10
    7076cdd02a85:	movdqu XMMWORD PTR [r15],xmm6
    7076cdd02a8a:	movdqu XMMWORD PTR [rbp+0x0],xmm5
    7076cdd02a8f:	mov    r15,r13
    7076cdd02a92:	add    r15,0xe0
    7076cdd02a99:	mov    rbp,r15
    7076cdd02a9c:	add    rbp,0x10
    7076cdd02aa0:	movdqu xmm2,XMMWORD PTR [r15]
    7076cdd02aa5:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7076cdd02aaa:	movdqu XMMWORD PTR [r12+0x300],xmm2
    7076cdd02ab4:	movdqu XMMWORD PTR [r12+0x2d0],xmm3
    7076cdd02abe:	mov    r15,r13
    7076cdd02ac1:	add    r15,0x120
    7076cdd02ac8:	mov    rbp,r15
    7076cdd02acb:	add    rbp,0x10
    7076cdd02acf:	movdqu xmm2,XMMWORD PTR [r15]
    7076cdd02ad4:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7076cdd02ad9:	movdqu XMMWORD PTR [r12+0x190],xmm2
    7076cdd02ae3:	movdqu XMMWORD PTR [r12+0x1e0],xmm3
    7076cdd02aed:	mov    r15,r13
    7076cdd02af0:	add    r15,0x160
    7076cdd02af7:	mov    rbp,r15
    7076cdd02afa:	add    rbp,0x10
    7076cdd02afe:	movdqu xmm2,XMMWORD PTR [r15]
    7076cdd02b03:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7076cdd02b08:	movdqu XMMWORD PTR [r12+0x1a0],xmm2
    7076cdd02b12:	movdqu XMMWORD PTR [r12+0x1b0],xmm3
    7076cdd02b1c:	mov    r15,r13
    7076cdd02b1f:	add    r15,0x1a0
    7076cdd02b26:	mov    rbp,r15
    7076cdd02b29:	add    rbp,0x10
    7076cdd02b2d:	movdqu xmm5,XMMWORD PTR [r15]
    7076cdd02b32:	movdqu xmm6,XMMWORD PTR [rbp+0x0]
    7076cdd02b37:	movdqu XMMWORD PTR [r12+0x200],xmm5
    7076cdd02b41:	movdqu XMMWORD PTR [r12+0x170],xmm6
    7076cdd02b4b:	add    r13,0x1e0
    7076cdd02b52:	mov    r15,r13
    7076cdd02b55:	add    r15,0x10
    7076cdd02b59:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    7076cdd02b5f:	movdqu xmm7,XMMWORD PTR [r15]
    7076cdd02b64:	movdqu XMMWORD PTR [r12+0x110],xmm5
    7076cdd02b6e:	movdqu XMMWORD PTR [r12+0x270],xmm7
    7076cdd02b78:	mov    r13d,0x432000
    7076cdd02b7e:	add    r13,0x190
    7076cdd02b85:	mov    QWORD PTR [r12+0x50],r13
    7076cdd02b8a:	mov    r13,r14
    7076cdd02b8d:	add    r13,0x50
    7076cdd02b91:	mov    r15,r13
    7076cdd02b94:	add    r15,0x10
    7076cdd02b98:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7076cdd02b9e:	movdqu XMMWORD PTR [r15],xmm4
    7076cdd02ba3:	mov    r13,r14
    7076cdd02ba6:	add    r13,0x40
    7076cdd02baa:	movdqu XMMWORD PTR [r13+0x0],xmm3
    7076cdd02bb0:	mov    r13,r14
    7076cdd02bb3:	add    r13,0x20
    7076cdd02bb7:	mov    r15,r13
    7076cdd02bba:	add    r15,0x10
    7076cdd02bbe:	movdqu XMMWORD PTR [r13+0x0],xmm5
    7076cdd02bc4:	movdqu XMMWORD PTR [r15],xmm6
    7076cdd02bc9:	add    r14,0x10
    7076cdd02bcd:	movdqu XMMWORD PTR [r14],xmm7
    7076cdd02bd2:	mov    r11,rax
    7076cdd02bd5:	movzx  eax,WORD PTR [rsp]
    7076cdd02bd9:	add    al,0x7f
    7076cdd02bdb:	sahf
    7076cdd02bdc:	mov    rax,r11
    7076cdd02bdf:	jmp    0x7076cdd02be4
    7076cdd02be4:	mov    r13d,0x0
    7076cdd02bea:	mov    QWORD PTR [r12+0x58],r13
    7076cdd02bef:	mov    r11,rax
    7076cdd02bf2:	lahf
    7076cdd02bf3:	seto   al
    7076cdd02bf6:	mov    WORD PTR [rsp],ax
    7076cdd02bfa:	mov    rax,r11
    7076cdd02bfd:	jmp    0x7076cdd02c02
    7076cdd02c02:	mov    r13,QWORD PTR [r12+0x58]
    7076cdd02c07:	mov    r14,QWORD PTR [r12+0x40]
    7076cdd02c0c:	add    r14,r13
    7076cdd02c0f:	mov    QWORD PTR [r12+0x60],r14
    7076cdd02c14:	mov    r15d,0x0
    7076cdd02c1a:	mov    ebp,0x0
    7076cdd02c1f:	mov    QWORD PTR [r12+0x110],r15
    7076cdd02c27:	mov    QWORD PTR [r12+0x118],rbp
    7076cdd02c2f:	mov    r15d,0x0
    7076cdd02c35:	mov    ebp,0x0
    7076cdd02c3a:	mov    QWORD PTR [r12+0x170],r15
    7076cdd02c42:	mov    QWORD PTR [r12+0x178],rbp
    7076cdd02c4a:	mov    r15,r14
    7076cdd02c4d:	add    r15,0x30
    7076cdd02c51:	mov    rbp,r15
    7076cdd02c54:	add    rbp,0x8
    7076cdd02c58:	mov    r8,QWORD PTR [r15]
    7076cdd02c5b:	mov    r15,QWORD PTR [rbp+0x0]
    7076cdd02c5f:	mov    ebp,0x0
    7076cdd02c64:	mov    QWORD PTR [r12+0x130],r8
    7076cdd02c6c:	mov    QWORD PTR [r12+0x138],rbp
    7076cdd02c74:	mov    ebp,0x0
    7076cdd02c79:	mov    QWORD PTR [r12+0x270],r15
    7076cdd02c81:	mov    QWORD PTR [r12+0x278],rbp
    7076cdd02c89:	movdqu xmm2,XMMWORD PTR [r12+0x160]
    7076cdd02c93:	movdqa xmm1,xmm2
    7076cdd02c97:	por    xmm2,xmm1
    7076cdd02c9b:	movdqu XMMWORD PTR [r12+0x1b0],xmm2
    7076cdd02ca5:	mov    r15,r14
    7076cdd02ca8:	add    r15,0x20
    7076cdd02cac:	mov    rbp,r15
    7076cdd02caf:	add    rbp,0x8
    7076cdd02cb3:	mov    r8,QWORD PTR [r15]
    7076cdd02cb6:	mov    r15,QWORD PTR [rbp+0x0]
    7076cdd02cba:	mov    ebp,0x0
    7076cdd02cbf:	mov    QWORD PTR [r12+0x150],r8
    7076cdd02cc7:	mov    QWORD PTR [r12+0x158],rbp
    7076cdd02ccf:	mov    ebp,0x0
    7076cdd02cd4:	mov    QWORD PTR [r12+0x140],r15
    7076cdd02cdc:	mov    QWORD PTR [r12+0x148],rbp
    7076cdd02ce4:	movdqu xmm2,XMMWORD PTR [r12+0x2d0]
    7076cdd02cee:	movdqa xmm1,xmm2
    7076cdd02cf2:	por    xmm2,xmm1
    7076cdd02cf6:	movdqu XMMWORD PTR [r12+0x1a0],xmm2
    7076cdd02d00:	movdqu xmm2,XMMWORD PTR [r12+0x300]
    7076cdd02d0a:	movdqa xmm1,xmm2
    7076cdd02d0e:	por    xmm2,xmm1
    7076cdd02d12:	movdqu XMMWORD PTR [r12+0x2f0],xmm2
    7076cdd02d1c:	movdqu xmm2,XMMWORD PTR [r12+0x2b0]
    7076cdd02d26:	movdqa xmm1,xmm2
    7076cdd02d2a:	por    xmm2,xmm1
    7076cdd02d2e:	movdqu XMMWORD PTR [r12+0x300],xmm2
    7076cdd02d38:	movdqu xmm2,XMMWORD PTR [r12+0x180]
    7076cdd02d42:	movdqa xmm1,xmm2
    7076cdd02d46:	por    xmm2,xmm1
    7076cdd02d4a:	movdqu XMMWORD PTR [r12+0x2d0],xmm2
    7076cdd02d54:	mov    r15,r14
    7076cdd02d57:	add    r15,0x10
    7076cdd02d5b:	mov    rbp,r15
    7076cdd02d5e:	add    rbp,0x8
    7076cdd02d62:	mov    r8,QWORD PTR [r15]
    7076cdd02d65:	mov    r15,QWORD PTR [rbp+0x0]
    7076cdd02d69:	mov    ebp,0x0
    7076cdd02d6e:	mov    QWORD PTR [r12+0x180],r8
    7076cdd02d76:	mov    QWORD PTR [r12+0x188],rbp
    7076cdd02d7e:	mov    ebp,0x0
    7076cdd02d83:	mov    QWORD PTR [r12+0x160],r15
    7076cdd02d8b:	mov    QWORD PTR [r12+0x168],rbp
    7076cdd02d93:	movdqu xmm2,XMMWORD PTR [r12+0x200]
    7076cdd02d9d:	movdqa xmm1,xmm2
    7076cdd02da1:	por    xmm2,xmm1
    7076cdd02da5:	movdqu XMMWORD PTR [r12+0x2b0],xmm2
    7076cdd02daf:	movdqu xmm2,XMMWORD PTR [r12+0x1f0]
    7076cdd02db9:	movdqa xmm1,xmm2
    7076cdd02dbd:	por    xmm2,xmm1
    7076cdd02dc1:	movdqu XMMWORD PTR [r12+0x200],xmm2
    7076cdd02dcb:	movdqu xmm2,XMMWORD PTR [r12+0x2e0]
    7076cdd02dd5:	movdqa xmm1,xmm2
    7076cdd02dd9:	por    xmm2,xmm1
    7076cdd02ddd:	movdqu XMMWORD PTR [r12+0x1f0],xmm2
    7076cdd02de7:	movdqu xmm2,XMMWORD PTR [r12+0x2a0]
    7076cdd02df1:	movdqa xmm1,xmm2
    7076cdd02df5:	por    xmm2,xmm1
    7076cdd02df9:	movdqu XMMWORD PTR [r12+0x2e0],xmm2
    7076cdd02e03:	movdqu xmm2,XMMWORD PTR [r12+0x280]
    7076cdd02e0d:	movdqa xmm1,xmm2
    7076cdd02e11:	por    xmm2,xmm1
    7076cdd02e15:	movdqu XMMWORD PTR [r12+0x2a0],xmm2
    7076cdd02e1f:	movdqu xmm2,XMMWORD PTR [r12+0x1c0]
    7076cdd02e29:	movdqa xmm1,xmm2
    7076cdd02e2d:	por    xmm2,xmm1
    7076cdd02e31:	movdqu XMMWORD PTR [r12+0x280],xmm2
    7076cdd02e3b:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    7076cdd02e45:	movdqa xmm1,xmm2
    7076cdd02e49:	por    xmm2,xmm1
    7076cdd02e4d:	movdqu XMMWORD PTR [r12+0x1c0],xmm2
    7076cdd02e57:	mov    r15d,0x8
    7076cdd02e5d:	mov    rbp,QWORD PTR [r14]
    7076cdd02e60:	mov    QWORD PTR [r12+0x210],rbp
    7076cdd02e68:	mov    QWORD PTR [r12+0x218],rbp
    7076cdd02e70:	add    r14,r15
    7076cdd02e73:	mov    QWORD PTR [r12+0x60],r14
    7076cdd02e78:	mov    r15d,0x0
    7076cdd02e7e:	mov    ebp,0x0
    7076cdd02e83:	mov    QWORD PTR [r12+0x220],r15
    7076cdd02e8b:	mov    QWORD PTR [r12+0x228],rbp
    7076cdd02e93:	mov    r15,QWORD PTR [r12+0xf8]
    7076cdd02e9b:	movdqu xmm2,XMMWORD PTR [r15]
    7076cdd02ea0:	movdqu XMMWORD PTR [r12+0x120],xmm2
    7076cdd02eaa:	mov    r15d,0x0
    7076cdd02eb0:	mov    ebp,0x0
    7076cdd02eb5:	mov    QWORD PTR [r12+0x230],r15
    7076cdd02ebd:	mov    QWORD PTR [r12+0x238],rbp
    7076cdd02ec5:	mov    r15,QWORD PTR [r14]
    7076cdd02ec8:	mov    r14d,0x0
    7076cdd02ece:	mov    QWORD PTR [r12+0x240],r15
    7076cdd02ed6:	mov    QWORD PTR [r12+0x248],r14
    7076cdd02ede:	mov    r14,QWORD PTR [r12+0x50]
    7076cdd02ee3:	add    r14,r13
    7076cdd02ee6:	mov    QWORD PTR [r12+0x60],r14
    7076cdd02eeb:	add    r13,0x40
    7076cdd02eef:	mov    QWORD PTR [r12+0x58],r13
    7076cdd02ef4:	lea    r13,[r12]
    7076cdd02ef8:	movabs r14,0x164e70cc20
    7076cdd02f02:	mov    r15d,0x410554
    7076cdd02f08:	mov    rdx,QWORD PTR [rsp]
    7076cdd02f0c:	mov    r10d,edx
    7076cdd02f0f:	and    r10d,0xc000
    7076cdd02f16:	shl    r10d,0x10
    7076cdd02f1a:	mov    r11d,edx
    7076cdd02f1d:	and    r11d,0x100
    7076cdd02f24:	shl    r11d,0x15
    7076cdd02f28:	or     r10d,r11d
    7076cdd02f2b:	and    edx,0x1
    7076cdd02f2e:	shl    edx,0x1c
    7076cdd02f31:	or     r10d,edx
    7076cdd02f34:	btc    r10,0x1d
    7076cdd02f39:	mov    r11d,0xf0000000
    7076cdd02f3f:	and    r11,r10
    7076cdd02f42:	movabs rsi,0xffffffff0fffffff
    7076cdd02f4c:	and    rbx,rsi
    7076cdd02f4f:	or     rbx,r11
    7076cdd02f52:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7076cdd02f5c:	movdqu xmm1,XMMWORD PTR [r12+0x210]
    7076cdd02f66:	movdqu xmm14,XMMWORD PTR [r12+0x110]
    7076cdd02f70:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd02f75:	movdqa xmm14,xmm0
    7076cdd02f7a:	movdqu xmm15,XMMWORD PTR [rip+0x3aed]        # 0x7076cdd06a70
    7076cdd02f83:	pand   xmm14,xmm15
    7076cdd02f88:	movdqu xmm15,XMMWORD PTR [rip+0x3aef]        # 0x7076cdd06a80
    7076cdd02f91:	pcmpeqq xmm14,xmm15
    7076cdd02f97:	movdqa xmm15,xmm0
    7076cdd02f9c:	cmpunordpd xmm15,xmm0
    7076cdd02fa2:	por    xmm14,xmm15
    7076cdd02fa7:	pmovmskb ecx,xmm14
    7076cdd02fac:	jrcxz  0x7076cdd02fb3
    7076cdd02fae:	jmp    0x7076cdd04fa5
    7076cdd02fb3:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7076cdd02fbd:	mov    eax,0x0
    7076cdd02fc2:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd02fce:	mov    rbp,rax
    7076cdd02fd1:	lea    r13,[r12]
    7076cdd02fd5:	movabs r14,0x164e70ce86
    7076cdd02fdf:	mov    r15d,0x410558
    7076cdd02fe5:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    7076cdd02fef:	movdqu xmm1,XMMWORD PTR [r12+0x210]
    7076cdd02ff9:	movdqu xmm14,XMMWORD PTR [r12+0x170]
    7076cdd03003:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd03008:	movdqa xmm14,xmm0
    7076cdd0300d:	movdqu xmm15,XMMWORD PTR [rip+0x3a5a]        # 0x7076cdd06a70
    7076cdd03016:	pand   xmm14,xmm15
    7076cdd0301b:	movdqu xmm15,XMMWORD PTR [rip+0x3a5c]        # 0x7076cdd06a80
    7076cdd03024:	pcmpeqq xmm14,xmm15
    7076cdd0302a:	movdqa xmm15,xmm0
    7076cdd0302f:	cmpunordpd xmm15,xmm0
    7076cdd03035:	por    xmm14,xmm15
    7076cdd0303a:	pmovmskb ecx,xmm14
    7076cdd0303f:	jrcxz  0x7076cdd03046
    7076cdd03041:	jmp    0x7076cdd0502b
    7076cdd03046:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7076cdd03050:	mov    eax,0x0
    7076cdd03055:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd03061:	mov    rbp,rax
    7076cdd03064:	movdqu xmm2,XMMWORD PTR [r12+0x1e0]
    7076cdd0306e:	movdqa xmm1,xmm2
    7076cdd03072:	por    xmm2,xmm1
    7076cdd03076:	movdqu XMMWORD PTR [r12+0x120],xmm2
    7076cdd03080:	movdqu xmm2,XMMWORD PTR [r12+0x1d0]
    7076cdd0308a:	movdqa xmm1,xmm2
    7076cdd0308e:	por    xmm2,xmm1
    7076cdd03092:	movdqu XMMWORD PTR [r12+0x1e0],xmm2
    7076cdd0309c:	movdqu xmm2,XMMWORD PTR [r12+0x2c0]
    7076cdd030a6:	movdqa xmm1,xmm2
    7076cdd030aa:	por    xmm2,xmm1
    7076cdd030ae:	movdqu XMMWORD PTR [r12+0x1d0],xmm2
    7076cdd030b8:	movdqu xmm2,XMMWORD PTR [r12+0x290]
    7076cdd030c2:	movdqa xmm1,xmm2
    7076cdd030c6:	por    xmm2,xmm1
    7076cdd030ca:	movdqu XMMWORD PTR [r12+0x2c0],xmm2
    7076cdd030d4:	movdqu xmm2,XMMWORD PTR [r12+0x260]
    7076cdd030de:	movdqa xmm1,xmm2
    7076cdd030e2:	por    xmm2,xmm1
    7076cdd030e6:	movdqu XMMWORD PTR [r12+0x290],xmm2
    7076cdd030f0:	movdqu xmm2,XMMWORD PTR [r12+0x250]
    7076cdd030fa:	movdqa xmm1,xmm2
    7076cdd030fe:	por    xmm2,xmm1
    7076cdd03102:	movdqu XMMWORD PTR [r12+0x260],xmm2
    7076cdd0310c:	mov    r13,QWORD PTR [r12+0xf8]
    7076cdd03114:	add    r13,0xc0
    7076cdd0311b:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7076cdd03121:	movdqu XMMWORD PTR [r12+0x250],xmm2
    7076cdd0312b:	mov    r13,QWORD PTR [r12+0x58]
    7076cdd03130:	sub    r13,0x200
    7076cdd03137:	lea    r13,[r12]
    7076cdd0313b:	movabs r14,0x164e70ce91
    7076cdd03145:	mov    r15d,0x41057c
    7076cdd0314b:	mov    r11,rax
    7076cdd0314e:	lahf
    7076cdd0314f:	seto   al
    7076cdd03152:	mov    WORD PTR [rsp],ax
    7076cdd03156:	mov    rax,r11
    7076cdd03159:	mov    rdx,QWORD PTR [rsp]
    7076cdd0315d:	mov    r10d,edx
    7076cdd03160:	and    r10d,0xc000
    7076cdd03167:	shl    r10d,0x10
    7076cdd0316b:	mov    r11d,edx
    7076cdd0316e:	and    r11d,0x100
    7076cdd03175:	shl    r11d,0x15
    7076cdd03179:	or     r10d,r11d
    7076cdd0317c:	and    edx,0x1
    7076cdd0317f:	shl    edx,0x1c
    7076cdd03182:	or     r10d,edx
    7076cdd03185:	btc    r10,0x1d
    7076cdd0318a:	mov    r11d,0xf0000000
    7076cdd03190:	and    r11,r10
    7076cdd03193:	movabs rsi,0xffffffff0fffffff
    7076cdd0319d:	and    rbx,rsi
    7076cdd031a0:	or     rbx,r11
    7076cdd031a3:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    7076cdd031ad:	movdqu xmm1,XMMWORD PTR [r12+0x210]
    7076cdd031b7:	movdqu xmm14,XMMWORD PTR [r12+0x220]
    7076cdd031c1:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd031c6:	movdqa xmm14,xmm0
    7076cdd031cb:	movdqu xmm15,XMMWORD PTR [rip+0x389c]        # 0x7076cdd06a70
    7076cdd031d4:	pand   xmm14,xmm15
    7076cdd031d9:	movdqu xmm15,XMMWORD PTR [rip+0x389e]        # 0x7076cdd06a80
    7076cdd031e2:	pcmpeqq xmm14,xmm15
    7076cdd031e8:	movdqa xmm15,xmm0
    7076cdd031ed:	cmpunordpd xmm15,xmm0
    7076cdd031f3:	por    xmm14,xmm15
    7076cdd031f8:	pmovmskb ecx,xmm14
    7076cdd031fd:	jrcxz  0x7076cdd03204
    7076cdd031ff:	jmp    0x7076cdd050b1
    7076cdd03204:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7076cdd0320e:	mov    eax,0x0
    7076cdd03213:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd0321f:	mov    rbp,rax
    7076cdd03222:	mov    r13,QWORD PTR [r12+0xf8]
    7076cdd0322a:	add    r13,0xb0
    7076cdd03231:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7076cdd03237:	movdqu XMMWORD PTR [r12+0x250],xmm2
    7076cdd03241:	lea    r13,[r12]
    7076cdd03245:	movabs r14,0x164e70ce92
    7076cdd0324f:	mov    r15d,0x410584
    7076cdd03255:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    7076cdd0325f:	movdqu xmm1,XMMWORD PTR [r12+0x210]
    7076cdd03269:	movdqu xmm14,XMMWORD PTR [r12+0x230]
    7076cdd03273:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd03278:	movdqa xmm14,xmm0
    7076cdd0327d:	movdqu xmm15,XMMWORD PTR [rip+0x37ea]        # 0x7076cdd06a70
    7076cdd03286:	pand   xmm14,xmm15
    7076cdd0328b:	movdqu xmm15,XMMWORD PTR [rip+0x37ec]        # 0x7076cdd06a80
    7076cdd03294:	pcmpeqq xmm14,xmm15
    7076cdd0329a:	movdqa xmm15,xmm0
    7076cdd0329f:	cmpunordpd xmm15,xmm0
    7076cdd032a5:	por    xmm14,xmm15
    7076cdd032aa:	pmovmskb ecx,xmm14
    7076cdd032af:	jrcxz  0x7076cdd032b6
    7076cdd032b1:	jmp    0x7076cdd05137
    7076cdd032b6:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7076cdd032c0:	mov    eax,0x0
    7076cdd032c5:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd032d1:	mov    rbp,rax
    7076cdd032d4:	movdqu xmm2,XMMWORD PTR [r12+0x1c0]
    7076cdd032de:	movdqa xmm1,xmm2
    7076cdd032e2:	por    xmm2,xmm1
    7076cdd032e6:	movdqu XMMWORD PTR [r12+0x210],xmm2
    7076cdd032f0:	movdqu xmm2,XMMWORD PTR [r12+0x280]
    7076cdd032fa:	movdqa xmm1,xmm2
    7076cdd032fe:	por    xmm2,xmm1
    7076cdd03302:	movdqu XMMWORD PTR [r12+0x1c0],xmm2
    7076cdd0330c:	movdqu xmm2,XMMWORD PTR [r12+0x2a0]
    7076cdd03316:	movdqa xmm1,xmm2
    7076cdd0331a:	por    xmm2,xmm1
    7076cdd0331e:	movdqu XMMWORD PTR [r12+0x280],xmm2
    7076cdd03328:	movdqu xmm2,XMMWORD PTR [r12+0x2e0]
    7076cdd03332:	movdqa xmm1,xmm2
    7076cdd03336:	por    xmm2,xmm1
    7076cdd0333a:	movdqu XMMWORD PTR [r12+0x2a0],xmm2
    7076cdd03344:	movdqu xmm2,XMMWORD PTR [r12+0x1f0]
    7076cdd0334e:	movdqa xmm1,xmm2
    7076cdd03352:	por    xmm2,xmm1
    7076cdd03356:	movdqu XMMWORD PTR [r12+0x2e0],xmm2
    7076cdd03360:	movdqu xmm2,XMMWORD PTR [r12+0x200]
    7076cdd0336a:	movdqa xmm1,xmm2
    7076cdd0336e:	por    xmm2,xmm1
    7076cdd03372:	movdqu XMMWORD PTR [r12+0x1f0],xmm2
    7076cdd0337c:	movdqu xmm2,XMMWORD PTR [r12+0x260]
    7076cdd03386:	movdqa xmm1,xmm2
    7076cdd0338a:	por    xmm2,xmm1
    7076cdd0338e:	movdqu XMMWORD PTR [r12+0x250],xmm2
    7076cdd03398:	movdqu xmm2,XMMWORD PTR [r12+0x290]
    7076cdd033a2:	movdqa xmm1,xmm2
    7076cdd033a6:	por    xmm2,xmm1
    7076cdd033aa:	movdqu XMMWORD PTR [r12+0x260],xmm2
    7076cdd033b4:	movdqu xmm2,XMMWORD PTR [r12+0x2c0]
    7076cdd033be:	movdqa xmm1,xmm2
    7076cdd033c2:	por    xmm2,xmm1
    7076cdd033c6:	movdqu XMMWORD PTR [r12+0x290],xmm2
    7076cdd033d0:	movdqu xmm2,XMMWORD PTR [r12+0x1d0]
    7076cdd033da:	movdqa xmm1,xmm2
    7076cdd033de:	por    xmm2,xmm1
    7076cdd033e2:	movdqu XMMWORD PTR [r12+0x2c0],xmm2
    7076cdd033ec:	lea    r13,[r12]
    7076cdd033f0:	movabs r14,0x184fd31200
    7076cdd033fa:	mov    r15d,0x4105b0
    7076cdd03400:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7076cdd0340a:	movdqu xmm1,XMMWORD PTR [r12+0x240]
    7076cdd03414:	pshufd xmm1,xmm1,0x44
    7076cdd03419:	movdqu xmm14,XMMWORD PTR [r12+0x110]
    7076cdd03423:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd03428:	movdqa xmm14,xmm0
    7076cdd0342d:	movdqu xmm15,XMMWORD PTR [rip+0x363a]        # 0x7076cdd06a70
    7076cdd03436:	pand   xmm14,xmm15
    7076cdd0343b:	movdqu xmm15,XMMWORD PTR [rip+0x363c]        # 0x7076cdd06a80
    7076cdd03444:	pcmpeqq xmm14,xmm15
    7076cdd0344a:	movdqa xmm15,xmm0
    7076cdd0344f:	cmpunordpd xmm15,xmm0
    7076cdd03455:	por    xmm14,xmm15
    7076cdd0345a:	pmovmskb ecx,xmm14
    7076cdd0345f:	jrcxz  0x7076cdd03466
    7076cdd03461:	jmp    0x7076cdd051bd
    7076cdd03466:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7076cdd03470:	mov    eax,0x0
    7076cdd03475:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd03481:	mov    rbp,rax
    7076cdd03484:	lea    r13,[r12]
    7076cdd03488:	movabs r14,0x184fd313b1
    7076cdd03492:	mov    r15d,0x4105b4
    7076cdd03498:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    7076cdd034a2:	movdqu xmm1,XMMWORD PTR [r12+0x240]
    7076cdd034ac:	pshufd xmm1,xmm1,0x44
    7076cdd034b1:	movdqu xmm14,XMMWORD PTR [r12+0x220]
    7076cdd034bb:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd034c0:	movdqa xmm14,xmm0
    7076cdd034c5:	movdqu xmm15,XMMWORD PTR [rip+0x35a2]        # 0x7076cdd06a70
    7076cdd034ce:	pand   xmm14,xmm15
    7076cdd034d3:	movdqu xmm15,XMMWORD PTR [rip+0x35a4]        # 0x7076cdd06a80
    7076cdd034dc:	pcmpeqq xmm14,xmm15
    7076cdd034e2:	movdqa xmm15,xmm0
    7076cdd034e7:	cmpunordpd xmm15,xmm0
    7076cdd034ed:	por    xmm14,xmm15
    7076cdd034f2:	pmovmskb ecx,xmm14
    7076cdd034f7:	jrcxz  0x7076cdd034fe
    7076cdd034f9:	jmp    0x7076cdd05243
    7076cdd034fe:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7076cdd03508:	mov    eax,0x0
    7076cdd0350d:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd03519:	mov    rbp,rax
    7076cdd0351c:	lea    r13,[r12]
    7076cdd03520:	movabs r14,0x184fd31166
    7076cdd0352a:	mov    r15d,0x4105b8
    7076cdd03530:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    7076cdd0353a:	movdqu xmm1,XMMWORD PTR [r12+0x240]
    7076cdd03544:	pshufd xmm1,xmm1,0x44
    7076cdd03549:	movdqu xmm14,XMMWORD PTR [r12+0x170]
    7076cdd03553:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd03558:	movdqa xmm14,xmm0
    7076cdd0355d:	movdqu xmm15,XMMWORD PTR [rip+0x350a]        # 0x7076cdd06a70
    7076cdd03566:	pand   xmm14,xmm15
    7076cdd0356b:	movdqu xmm15,XMMWORD PTR [rip+0x350c]        # 0x7076cdd06a80
    7076cdd03574:	pcmpeqq xmm14,xmm15
    7076cdd0357a:	movdqa xmm15,xmm0
    7076cdd0357f:	cmpunordpd xmm15,xmm0
    7076cdd03585:	por    xmm14,xmm15
    7076cdd0358a:	pmovmskb ecx,xmm14
    7076cdd0358f:	jrcxz  0x7076cdd03596
    7076cdd03591:	jmp    0x7076cdd052c9
    7076cdd03596:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7076cdd035a0:	mov    eax,0x0
    7076cdd035a5:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd035b1:	mov    rbp,rax
    7076cdd035b4:	movdqu xmm2,XMMWORD PTR [r12+0x1e0]
    7076cdd035be:	movdqa xmm1,xmm2
    7076cdd035c2:	por    xmm2,xmm1
    7076cdd035c6:	movdqu XMMWORD PTR [r12+0x1d0],xmm2
    7076cdd035d0:	lea    r13,[r12]
    7076cdd035d4:	movabs r14,0x184fd311d2
    7076cdd035de:	mov    r15d,0x4105c0
    7076cdd035e4:	movdqu xmm0,XMMWORD PTR [r12+0x1f0]
    7076cdd035ee:	movdqu xmm1,XMMWORD PTR [r12+0x240]
    7076cdd035f8:	pshufd xmm1,xmm1,0x44
    7076cdd035fd:	movdqu xmm14,XMMWORD PTR [r12+0x230]
    7076cdd03607:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd0360c:	movdqa xmm14,xmm0
    7076cdd03611:	movdqu xmm15,XMMWORD PTR [rip+0x3456]        # 0x7076cdd06a70
    7076cdd0361a:	pand   xmm14,xmm15
    7076cdd0361f:	movdqu xmm15,XMMWORD PTR [rip+0x3458]        # 0x7076cdd06a80
    7076cdd03628:	pcmpeqq xmm14,xmm15
    7076cdd0362e:	movdqa xmm15,xmm0
    7076cdd03633:	cmpunordpd xmm15,xmm0
    7076cdd03639:	por    xmm14,xmm15
    7076cdd0363e:	pmovmskb ecx,xmm14
    7076cdd03643:	jrcxz  0x7076cdd0364a
    7076cdd03645:	jmp    0x7076cdd0534f
    7076cdd0364a:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7076cdd03654:	mov    eax,0x0
    7076cdd03659:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd03665:	mov    rbp,rax
    7076cdd03668:	movdqu xmm2,XMMWORD PTR [r12+0x2b0]
    7076cdd03672:	movdqa xmm1,xmm2
    7076cdd03676:	por    xmm2,xmm1
    7076cdd0367a:	movdqu XMMWORD PTR [r12+0x200],xmm2
    7076cdd03684:	movdqu xmm2,XMMWORD PTR [r12+0x120]
    7076cdd0368e:	movdqa xmm1,xmm2
    7076cdd03692:	por    xmm2,xmm1
    7076cdd03696:	movdqu XMMWORD PTR [r12+0x1e0],xmm2
    7076cdd036a0:	movdqu xmm2,XMMWORD PTR [r12+0x300]
    7076cdd036aa:	movdqa xmm1,xmm2
    7076cdd036ae:	por    xmm2,xmm1
    7076cdd036b2:	movdqu XMMWORD PTR [r12+0x2b0],xmm2
    7076cdd036bc:	movdqu xmm2,XMMWORD PTR [r12+0x2f0]
    7076cdd036c6:	movdqa xmm1,xmm2
    7076cdd036ca:	por    xmm2,xmm1
    7076cdd036ce:	movdqu XMMWORD PTR [r12+0x300],xmm2
    7076cdd036d8:	lea    r13,[r12]
    7076cdd036dc:	movabs r14,0x184fc712a0
    7076cdd036e6:	mov    r15d,0x4105d4
    7076cdd036ec:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    7076cdd036f6:	movdqu xmm1,XMMWORD PTR [r12+0x180]
    7076cdd03700:	pshufd xmm1,xmm1,0x44
    7076cdd03705:	movdqu xmm14,XMMWORD PTR [r12+0x110]
    7076cdd0370f:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd03714:	movdqa xmm14,xmm0
    7076cdd03719:	movdqu xmm15,XMMWORD PTR [rip+0x334e]        # 0x7076cdd06a70
    7076cdd03722:	pand   xmm14,xmm15
    7076cdd03727:	movdqu xmm15,XMMWORD PTR [rip+0x3350]        # 0x7076cdd06a80
    7076cdd03730:	pcmpeqq xmm14,xmm15
    7076cdd03736:	movdqa xmm15,xmm0
    7076cdd0373b:	cmpunordpd xmm15,xmm0
    7076cdd03741:	por    xmm14,xmm15
    7076cdd03746:	pmovmskb ecx,xmm14
    7076cdd0374b:	jrcxz  0x7076cdd03752
    7076cdd0374d:	jmp    0x7076cdd053d5
    7076cdd03752:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7076cdd0375c:	mov    eax,0x0
    7076cdd03761:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd0376d:	mov    rbp,rax
    7076cdd03770:	lea    r13,[r12]
    7076cdd03774:	movabs r14,0x184fc71371
    7076cdd0377e:	mov    r15d,0x4105d8
    7076cdd03784:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    7076cdd0378e:	movdqu xmm1,XMMWORD PTR [r12+0x180]
    7076cdd03798:	pshufd xmm1,xmm1,0x44
    7076cdd0379d:	movdqu xmm14,XMMWORD PTR [r12+0x220]
    7076cdd037a7:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd037ac:	movdqa xmm14,xmm0
    7076cdd037b1:	movdqu xmm15,XMMWORD PTR [rip+0x32b6]        # 0x7076cdd06a70
    7076cdd037ba:	pand   xmm14,xmm15
    7076cdd037bf:	movdqu xmm15,XMMWORD PTR [rip+0x32b8]        # 0x7076cdd06a80
    7076cdd037c8:	pcmpeqq xmm14,xmm15
    7076cdd037ce:	movdqa xmm15,xmm0
    7076cdd037d3:	cmpunordpd xmm15,xmm0
    7076cdd037d9:	por    xmm14,xmm15
    7076cdd037de:	pmovmskb ecx,xmm14
    7076cdd037e3:	jrcxz  0x7076cdd037ea
    7076cdd037e5:	jmp    0x7076cdd0545b
    7076cdd037ea:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7076cdd037f4:	mov    eax,0x0
    7076cdd037f9:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd03805:	mov    rbp,rax
    7076cdd03808:	lea    r13,[r12]
    7076cdd0380c:	movabs r14,0x184fc712e6
    7076cdd03816:	mov    r15d,0x4105dc
    7076cdd0381c:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    7076cdd03826:	movdqu xmm1,XMMWORD PTR [r12+0x180]
    7076cdd03830:	pshufd xmm1,xmm1,0x44
    7076cdd03835:	movdqu xmm14,XMMWORD PTR [r12+0x170]
    7076cdd0383f:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd03844:	movdqa xmm14,xmm0
    7076cdd03849:	movdqu xmm15,XMMWORD PTR [rip+0x321e]        # 0x7076cdd06a70
    7076cdd03852:	pand   xmm14,xmm15
    7076cdd03857:	movdqu xmm15,XMMWORD PTR [rip+0x3220]        # 0x7076cdd06a80
    7076cdd03860:	pcmpeqq xmm14,xmm15
    7076cdd03866:	movdqa xmm15,xmm0
    7076cdd0386b:	cmpunordpd xmm15,xmm0
    7076cdd03871:	por    xmm14,xmm15
    7076cdd03876:	pmovmskb ecx,xmm14
    7076cdd0387b:	jrcxz  0x7076cdd03882
    7076cdd0387d:	jmp    0x7076cdd054e1
    7076cdd03882:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7076cdd0388c:	mov    eax,0x0
    7076cdd03891:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd0389d:	mov    rbp,rax
    7076cdd038a0:	lea    r13,[r12]
    7076cdd038a4:	movabs r14,0x184fc71192
    7076cdd038ae:	mov    r15d,0x4105e0
    7076cdd038b4:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    7076cdd038be:	movdqu xmm1,XMMWORD PTR [r12+0x180]
    7076cdd038c8:	pshufd xmm1,xmm1,0x44
    7076cdd038cd:	movdqu xmm14,XMMWORD PTR [r12+0x230]
    7076cdd038d7:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd038dc:	movdqa xmm14,xmm0
    7076cdd038e1:	movdqu xmm15,XMMWORD PTR [rip+0x3186]        # 0x7076cdd06a70
    7076cdd038ea:	pand   xmm14,xmm15
    7076cdd038ef:	movdqu xmm15,XMMWORD PTR [rip+0x3188]        # 0x7076cdd06a80
    7076cdd038f8:	pcmpeqq xmm14,xmm15
    7076cdd038fe:	movdqa xmm15,xmm0
    7076cdd03903:	cmpunordpd xmm15,xmm0
    7076cdd03909:	por    xmm14,xmm15
    7076cdd0390e:	pmovmskb ecx,xmm14
    7076cdd03913:	jrcxz  0x7076cdd0391a
    7076cdd03915:	jmp    0x7076cdd05567
    7076cdd0391a:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7076cdd03924:	mov    eax,0x0
    7076cdd03929:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd03935:	mov    rbp,rax
    7076cdd03938:	movdqu xmm2,XMMWORD PTR [r12+0x2d0]
    7076cdd03942:	movdqa xmm1,xmm2
    7076cdd03946:	por    xmm2,xmm1
    7076cdd0394a:	movdqu XMMWORD PTR [r12+0x180],xmm2
    7076cdd03954:	movdqu xmm2,XMMWORD PTR [r12+0x1a0]
    7076cdd0395e:	movdqa xmm1,xmm2
    7076cdd03962:	por    xmm2,xmm1
    7076cdd03966:	movdqu XMMWORD PTR [r12+0x2d0],xmm2
    7076cdd03970:	lea    r13,[r12]
    7076cdd03974:	movabs r14,0x184fc513d1
    7076cdd0397e:	mov    r15d,0x4105ec
    7076cdd03984:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    7076cdd0398e:	movdqu xmm1,XMMWORD PTR [r12+0x160]
    7076cdd03998:	pshufd xmm1,xmm1,0x44
    7076cdd0399d:	movdqu xmm14,XMMWORD PTR [r12+0x220]
    7076cdd039a7:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd039ac:	movdqa xmm14,xmm0
    7076cdd039b1:	movdqu xmm15,XMMWORD PTR [rip+0x30b6]        # 0x7076cdd06a70
    7076cdd039ba:	pand   xmm14,xmm15
    7076cdd039bf:	movdqu xmm15,XMMWORD PTR [rip+0x30b8]        # 0x7076cdd06a80
    7076cdd039c8:	pcmpeqq xmm14,xmm15
    7076cdd039ce:	movdqa xmm15,xmm0
    7076cdd039d3:	cmpunordpd xmm15,xmm0
    7076cdd039d9:	por    xmm14,xmm15
    7076cdd039de:	pmovmskb ecx,xmm14
    7076cdd039e3:	jrcxz  0x7076cdd039ea
    7076cdd039e5:	jmp    0x7076cdd055ed
    7076cdd039ea:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7076cdd039f4:	mov    eax,0x0
    7076cdd039f9:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd03a05:	mov    rbp,rax
    7076cdd03a08:	lea    r13,[r12]
    7076cdd03a0c:	movabs r14,0x184fc510e0
    7076cdd03a16:	mov    r15d,0x4105f0
    7076cdd03a1c:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7076cdd03a26:	movdqu xmm1,XMMWORD PTR [r12+0x160]
    7076cdd03a30:	pshufd xmm1,xmm1,0x44
    7076cdd03a35:	movdqu xmm14,XMMWORD PTR [r12+0x110]
    7076cdd03a3f:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd03a44:	movdqa xmm14,xmm0
    7076cdd03a49:	movdqu xmm15,XMMWORD PTR [rip+0x301e]        # 0x7076cdd06a70
    7076cdd03a52:	pand   xmm14,xmm15
    7076cdd03a57:	movdqu xmm15,XMMWORD PTR [rip+0x3020]        # 0x7076cdd06a80
    7076cdd03a60:	pcmpeqq xmm14,xmm15
    7076cdd03a66:	movdqa xmm15,xmm0
    7076cdd03a6b:	cmpunordpd xmm15,xmm0
    7076cdd03a71:	por    xmm14,xmm15
    7076cdd03a76:	pmovmskb ecx,xmm14
    7076cdd03a7b:	jrcxz  0x7076cdd03a82
    7076cdd03a7d:	jmp    0x7076cdd05673
    7076cdd03a82:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7076cdd03a8c:	mov    eax,0x0
    7076cdd03a91:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd03a9d:	mov    rbp,rax
    7076cdd03aa0:	mov    r13,QWORD PTR [r12+0xf8]
    7076cdd03aa8:	add    r13,0x80
    7076cdd03aaf:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7076cdd03ab5:	movdqu XMMWORD PTR [r12+0x2f0],xmm2
    7076cdd03abf:	lea    r13,[r12]
    7076cdd03ac3:	movabs r14,0x184fc51306
    7076cdd03acd:	mov    r15d,0x4105f8
    7076cdd03ad3:	movdqu xmm0,XMMWORD PTR [r12+0x290]
    7076cdd03add:	movdqu xmm1,XMMWORD PTR [r12+0x160]
    7076cdd03ae7:	pshufd xmm1,xmm1,0x44
    7076cdd03aec:	movdqu xmm14,XMMWORD PTR [r12+0x170]
    7076cdd03af6:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd03afb:	movdqa xmm14,xmm0
    7076cdd03b00:	movdqu xmm15,XMMWORD PTR [rip+0x2f67]        # 0x7076cdd06a70
    7076cdd03b09:	pand   xmm14,xmm15
    7076cdd03b0e:	movdqu xmm15,XMMWORD PTR [rip+0x2f69]        # 0x7076cdd06a80
    7076cdd03b17:	pcmpeqq xmm14,xmm15
    7076cdd03b1d:	movdqa xmm15,xmm0
    7076cdd03b22:	cmpunordpd xmm15,xmm0
    7076cdd03b28:	por    xmm14,xmm15
    7076cdd03b2d:	pmovmskb ecx,xmm14
    7076cdd03b32:	jrcxz  0x7076cdd03b39
    7076cdd03b34:	jmp    0x7076cdd056f9
    7076cdd03b39:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7076cdd03b43:	mov    eax,0x0
    7076cdd03b48:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd03b54:	mov    rbp,rax
    7076cdd03b57:	lea    r13,[r12]
    7076cdd03b5b:	movabs r14,0x184fc51132
    7076cdd03b65:	mov    r15d,0x4105fc
    7076cdd03b6b:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    7076cdd03b75:	movdqu xmm1,XMMWORD PTR [r12+0x160]
    7076cdd03b7f:	pshufd xmm1,xmm1,0x44
    7076cdd03b84:	movdqu xmm14,XMMWORD PTR [r12+0x230]
    7076cdd03b8e:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd03b93:	movdqa xmm14,xmm0
    7076cdd03b98:	movdqu xmm15,XMMWORD PTR [rip+0x2ecf]        # 0x7076cdd06a70
    7076cdd03ba1:	pand   xmm14,xmm15
    7076cdd03ba6:	movdqu xmm15,XMMWORD PTR [rip+0x2ed1]        # 0x7076cdd06a80
    7076cdd03baf:	pcmpeqq xmm14,xmm15
    7076cdd03bb5:	movdqa xmm15,xmm0
    7076cdd03bba:	cmpunordpd xmm15,xmm0
    7076cdd03bc0:	por    xmm14,xmm15
    7076cdd03bc5:	pmovmskb ecx,xmm14
    7076cdd03bca:	jrcxz  0x7076cdd03bd1
    7076cdd03bcc:	jmp    0x7076cdd0577f
    7076cdd03bd1:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7076cdd03bdb:	mov    eax,0x0
    7076cdd03be0:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd03bec:	mov    rbp,rax
    7076cdd03bef:	movdqu xmm2,XMMWORD PTR [r12+0x1b0]
    7076cdd03bf9:	movdqa xmm1,xmm2
    7076cdd03bfd:	por    xmm2,xmm1
    7076cdd03c01:	movdqu XMMWORD PTR [r12+0x160],xmm2
    7076cdd03c0b:	mov    r13,QWORD PTR [r12+0xf8]
    7076cdd03c13:	add    r13,0x40
    7076cdd03c17:	mov    r14,r13
    7076cdd03c1a:	add    r14,0x10
    7076cdd03c1e:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7076cdd03c24:	movdqu xmm3,XMMWORD PTR [r14]
    7076cdd03c29:	movdqu XMMWORD PTR [r12+0x1b0],xmm2
    7076cdd03c33:	movdqu XMMWORD PTR [r12+0x1a0],xmm3
    7076cdd03c3d:	lea    r13,[r12]
    7076cdd03c41:	movabs r14,0x184fc41111
    7076cdd03c4b:	mov    r15d,0x410608
    7076cdd03c51:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    7076cdd03c5b:	movdqu xmm1,XMMWORD PTR [r12+0x150]
    7076cdd03c65:	pshufd xmm1,xmm1,0x44
    7076cdd03c6a:	movdqu xmm14,XMMWORD PTR [r12+0x220]
    7076cdd03c74:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd03c79:	movdqa xmm14,xmm0
    7076cdd03c7e:	movdqu xmm15,XMMWORD PTR [rip+0x2de9]        # 0x7076cdd06a70
    7076cdd03c87:	pand   xmm14,xmm15
    7076cdd03c8c:	movdqu xmm15,XMMWORD PTR [rip+0x2deb]        # 0x7076cdd06a80
    7076cdd03c95:	pcmpeqq xmm14,xmm15
    7076cdd03c9b:	movdqa xmm15,xmm0
    7076cdd03ca0:	cmpunordpd xmm15,xmm0
    7076cdd03ca6:	por    xmm14,xmm15
    7076cdd03cab:	pmovmskb ecx,xmm14
    7076cdd03cb0:	jrcxz  0x7076cdd03cb7
    7076cdd03cb2:	jmp    0x7076cdd05805
    7076cdd03cb7:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7076cdd03cc1:	mov    eax,0x0
    7076cdd03cc6:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd03cd2:	mov    rbp,rax
    7076cdd03cd5:	lea    r13,[r12]
    7076cdd03cd9:	movabs r14,0x184fc410a0
    7076cdd03ce3:	mov    r15d,0x41060c
    7076cdd03ce9:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7076cdd03cf3:	movdqu xmm1,XMMWORD PTR [r12+0x150]
    7076cdd03cfd:	pshufd xmm1,xmm1,0x44
    7076cdd03d02:	movdqu xmm14,XMMWORD PTR [r12+0x110]
    7076cdd03d0c:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd03d11:	movdqa xmm14,xmm0
    7076cdd03d16:	movdqu xmm15,XMMWORD PTR [rip+0x2d51]        # 0x7076cdd06a70
    7076cdd03d1f:	pand   xmm14,xmm15
    7076cdd03d24:	movdqu xmm15,XMMWORD PTR [rip+0x2d53]        # 0x7076cdd06a80
    7076cdd03d2d:	pcmpeqq xmm14,xmm15
    7076cdd03d33:	movdqa xmm15,xmm0
    7076cdd03d38:	cmpunordpd xmm15,xmm0
    7076cdd03d3e:	por    xmm14,xmm15
    7076cdd03d43:	pmovmskb ecx,xmm14
    7076cdd03d48:	jrcxz  0x7076cdd03d4f
    7076cdd03d4a:	jmp    0x7076cdd0588b
    7076cdd03d4f:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7076cdd03d59:	mov    eax,0x0
    7076cdd03d5e:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd03d6a:	mov    rbp,rax
    7076cdd03d6d:	lea    r13,[r12]
    7076cdd03d71:	movabs r14,0x184fc41326
    7076cdd03d7b:	mov    r15d,0x410610
    7076cdd03d81:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    7076cdd03d8b:	movdqu xmm1,XMMWORD PTR [r12+0x150]
    7076cdd03d95:	pshufd xmm1,xmm1,0x44
    7076cdd03d9a:	movdqu xmm14,XMMWORD PTR [r12+0x170]
    7076cdd03da4:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd03da9:	movdqa xmm14,xmm0
    7076cdd03dae:	movdqu xmm15,XMMWORD PTR [rip+0x2cb9]        # 0x7076cdd06a70
    7076cdd03db7:	pand   xmm14,xmm15
    7076cdd03dbc:	movdqu xmm15,XMMWORD PTR [rip+0x2cbb]        # 0x7076cdd06a80
    7076cdd03dc5:	pcmpeqq xmm14,xmm15
    7076cdd03dcb:	movdqa xmm15,xmm0
    7076cdd03dd0:	cmpunordpd xmm15,xmm0
    7076cdd03dd6:	por    xmm14,xmm15
    7076cdd03ddb:	pmovmskb ecx,xmm14
    7076cdd03de0:	jrcxz  0x7076cdd03de7
    7076cdd03de2:	jmp    0x7076cdd05911
    7076cdd03de7:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7076cdd03df1:	mov    eax,0x0
    7076cdd03df6:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd03e02:	mov    rbp,rax
    7076cdd03e05:	lea    r13,[r12]
    7076cdd03e09:	movabs r14,0x184fc41032
    7076cdd03e13:	mov    r15d,0x410614
    7076cdd03e19:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7076cdd03e23:	movdqu xmm1,XMMWORD PTR [r12+0x150]
    7076cdd03e2d:	pshufd xmm1,xmm1,0x44
    7076cdd03e32:	movdqu xmm14,XMMWORD PTR [r12+0x230]
    7076cdd03e3c:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd03e41:	movdqa xmm14,xmm0
    7076cdd03e46:	movdqu xmm15,XMMWORD PTR [rip+0x2c21]        # 0x7076cdd06a70
    7076cdd03e4f:	pand   xmm14,xmm15
    7076cdd03e54:	movdqu xmm15,XMMWORD PTR [rip+0x2c23]        # 0x7076cdd06a80
    7076cdd03e5d:	pcmpeqq xmm14,xmm15
    7076cdd03e63:	movdqa xmm15,xmm0
    7076cdd03e68:	cmpunordpd xmm15,xmm0
    7076cdd03e6e:	por    xmm14,xmm15
    7076cdd03e73:	pmovmskb ecx,xmm14
    7076cdd03e78:	jrcxz  0x7076cdd03e7f
    7076cdd03e7a:	jmp    0x7076cdd05997
    7076cdd03e7f:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7076cdd03e89:	mov    eax,0x0
    7076cdd03e8e:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd03e9a:	mov    rbp,rax
    7076cdd03e9d:	mov    r13,QWORD PTR [r12+0xf8]
    7076cdd03ea5:	add    r13,0x60
    7076cdd03ea9:	mov    r14,r13
    7076cdd03eac:	add    r14,0x10
    7076cdd03eb0:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7076cdd03eb6:	movdqu xmm3,XMMWORD PTR [r14]
    7076cdd03ebb:	movdqu XMMWORD PTR [r12+0x150],xmm2
    7076cdd03ec5:	movdqu XMMWORD PTR [r12+0x120],xmm3
    7076cdd03ecf:	lea    r13,[r12]
    7076cdd03ed3:	movabs r14,0x184fc31131
    7076cdd03edd:	mov    r15d,0x41061c
    7076cdd03ee3:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    7076cdd03eed:	movdqu xmm1,XMMWORD PTR [r12+0x140]
    7076cdd03ef7:	pshufd xmm1,xmm1,0x44
    7076cdd03efc:	movdqu xmm14,XMMWORD PTR [r12+0x220]
    7076cdd03f06:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd03f0b:	movdqa xmm14,xmm0
    7076cdd03f10:	movdqu xmm15,XMMWORD PTR [rip+0x2b57]        # 0x7076cdd06a70
    7076cdd03f19:	pand   xmm14,xmm15
    7076cdd03f1e:	movdqu xmm15,XMMWORD PTR [rip+0x2b59]        # 0x7076cdd06a80
    7076cdd03f27:	pcmpeqq xmm14,xmm15
    7076cdd03f2d:	movdqa xmm15,xmm0
    7076cdd03f32:	cmpunordpd xmm15,xmm0
    7076cdd03f38:	por    xmm14,xmm15
    7076cdd03f3d:	pmovmskb ecx,xmm14
    7076cdd03f42:	jrcxz  0x7076cdd03f49
    7076cdd03f44:	jmp    0x7076cdd05a1d
    7076cdd03f49:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7076cdd03f53:	mov    eax,0x0
    7076cdd03f58:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd03f64:	mov    rbp,rax
    7076cdd03f67:	lea    r13,[r12]
    7076cdd03f6b:	movabs r14,0x184fc31080
    7076cdd03f75:	mov    r15d,0x410620
    7076cdd03f7b:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7076cdd03f85:	movdqu xmm1,XMMWORD PTR [r12+0x140]
    7076cdd03f8f:	pshufd xmm1,xmm1,0x44
    7076cdd03f94:	movdqu xmm14,XMMWORD PTR [r12+0x110]
    7076cdd03f9e:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd03fa3:	movdqa xmm14,xmm0
    7076cdd03fa8:	movdqu xmm15,XMMWORD PTR [rip+0x2abf]        # 0x7076cdd06a70
    7076cdd03fb1:	pand   xmm14,xmm15
    7076cdd03fb6:	movdqu xmm15,XMMWORD PTR [rip+0x2ac1]        # 0x7076cdd06a80
    7076cdd03fbf:	pcmpeqq xmm14,xmm15
    7076cdd03fc5:	movdqa xmm15,xmm0
    7076cdd03fca:	cmpunordpd xmm15,xmm0
    7076cdd03fd0:	por    xmm14,xmm15
    7076cdd03fd5:	pmovmskb ecx,xmm14
    7076cdd03fda:	jrcxz  0x7076cdd03fe1
    7076cdd03fdc:	jmp    0x7076cdd05aa3
    7076cdd03fe1:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7076cdd03feb:	mov    eax,0x0
    7076cdd03ff0:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd03ffc:	mov    rbp,rax
    7076cdd03fff:	lea    r13,[r12]
    7076cdd04003:	movabs r14,0x184fc31346
    7076cdd0400d:	mov    r15d,0x410624
    7076cdd04013:	movdqu xmm0,XMMWORD PTR [r12+0x2b0]
    7076cdd0401d:	movdqu xmm1,XMMWORD PTR [r12+0x140]
    7076cdd04027:	pshufd xmm1,xmm1,0x44
    7076cdd0402c:	movdqu xmm14,XMMWORD PTR [r12+0x170]
    7076cdd04036:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd0403b:	movdqa xmm14,xmm0
    7076cdd04040:	movdqu xmm15,XMMWORD PTR [rip+0x2a27]        # 0x7076cdd06a70
    7076cdd04049:	pand   xmm14,xmm15
    7076cdd0404e:	movdqu xmm15,XMMWORD PTR [rip+0x2a29]        # 0x7076cdd06a80
    7076cdd04057:	pcmpeqq xmm14,xmm15
    7076cdd0405d:	movdqa xmm15,xmm0
    7076cdd04062:	cmpunordpd xmm15,xmm0
    7076cdd04068:	por    xmm14,xmm15
    7076cdd0406d:	pmovmskb ecx,xmm14
    7076cdd04072:	jrcxz  0x7076cdd04079
    7076cdd04074:	jmp    0x7076cdd05b29
    7076cdd04079:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7076cdd04083:	mov    eax,0x0
    7076cdd04088:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd04094:	mov    rbp,rax
    7076cdd04097:	lea    r13,[r12]
    7076cdd0409b:	movabs r14,0x184fc31152
    7076cdd040a5:	mov    r15d,0x410628
    7076cdd040ab:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    7076cdd040b5:	movdqu xmm1,XMMWORD PTR [r12+0x140]
    7076cdd040bf:	pshufd xmm1,xmm1,0x44
    7076cdd040c4:	movdqu xmm14,XMMWORD PTR [r12+0x230]
    7076cdd040ce:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd040d3:	movdqa xmm14,xmm0
    7076cdd040d8:	movdqu xmm15,XMMWORD PTR [rip+0x298f]        # 0x7076cdd06a70
    7076cdd040e1:	pand   xmm14,xmm15
    7076cdd040e6:	movdqu xmm15,XMMWORD PTR [rip+0x2991]        # 0x7076cdd06a80
    7076cdd040ef:	pcmpeqq xmm14,xmm15
    7076cdd040f5:	movdqa xmm15,xmm0
    7076cdd040fa:	cmpunordpd xmm15,xmm0
    7076cdd04100:	por    xmm14,xmm15
    7076cdd04105:	pmovmskb ecx,xmm14
    7076cdd0410a:	jrcxz  0x7076cdd04111
    7076cdd0410c:	jmp    0x7076cdd05baf
    7076cdd04111:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7076cdd0411b:	mov    eax,0x0
    7076cdd04120:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd0412c:	mov    rbp,rax
    7076cdd0412f:	mov    r13,QWORD PTR [r12+0xf8]
    7076cdd04137:	add    r13,0x20
    7076cdd0413b:	mov    r14,r13
    7076cdd0413e:	add    r14,0x10
    7076cdd04142:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7076cdd04148:	movdqu xmm3,XMMWORD PTR [r14]
    7076cdd0414d:	movdqu XMMWORD PTR [r12+0x240],xmm2
    7076cdd04157:	movdqu XMMWORD PTR [r12+0x140],xmm3
    7076cdd04161:	lea    r13,[r12]
    7076cdd04165:	movabs r14,0x184fc211f1
    7076cdd0416f:	mov    r15d,0x410630
    7076cdd04175:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    7076cdd0417f:	movdqu xmm1,XMMWORD PTR [r12+0x130]
    7076cdd04189:	pshufd xmm1,xmm1,0x44
    7076cdd0418e:	movdqu xmm14,XMMWORD PTR [r12+0x220]
    7076cdd04198:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd0419d:	movdqa xmm14,xmm0
    7076cdd041a2:	movdqu xmm15,XMMWORD PTR [rip+0x28c5]        # 0x7076cdd06a70
    7076cdd041ab:	pand   xmm14,xmm15
    7076cdd041b0:	movdqu xmm15,XMMWORD PTR [rip+0x28c7]        # 0x7076cdd06a80
    7076cdd041b9:	pcmpeqq xmm14,xmm15
    7076cdd041bf:	movdqa xmm15,xmm0
    7076cdd041c4:	cmpunordpd xmm15,xmm0
    7076cdd041ca:	por    xmm14,xmm15
    7076cdd041cf:	pmovmskb ecx,xmm14
    7076cdd041d4:	jrcxz  0x7076cdd041db
    7076cdd041d6:	jmp    0x7076cdd05c35
    7076cdd041db:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7076cdd041e5:	mov    eax,0x0
    7076cdd041ea:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd041f6:	mov    rbp,rax
    7076cdd041f9:	lea    r13,[r12]
    7076cdd041fd:	movabs r14,0x184fc213c0
    7076cdd04207:	mov    r15d,0x410634
    7076cdd0420d:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    7076cdd04217:	movdqu xmm1,XMMWORD PTR [r12+0x130]
    7076cdd04221:	pshufd xmm1,xmm1,0x44
    7076cdd04226:	movdqu xmm14,XMMWORD PTR [r12+0x110]
    7076cdd04230:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd04235:	movdqa xmm14,xmm0
    7076cdd0423a:	movdqu xmm15,XMMWORD PTR [rip+0x282d]        # 0x7076cdd06a70
    7076cdd04243:	pand   xmm14,xmm15
    7076cdd04248:	movdqu xmm15,XMMWORD PTR [rip+0x282f]        # 0x7076cdd06a80
    7076cdd04251:	pcmpeqq xmm14,xmm15
    7076cdd04257:	movdqa xmm15,xmm0
    7076cdd0425c:	cmpunordpd xmm15,xmm0
    7076cdd04262:	por    xmm14,xmm15
    7076cdd04267:	pmovmskb ecx,xmm14
    7076cdd0426c:	jrcxz  0x7076cdd04273
    7076cdd0426e:	jmp    0x7076cdd05cbb
    7076cdd04273:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7076cdd0427d:	mov    eax,0x0
    7076cdd04282:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd0428e:	mov    rbp,rax
    7076cdd04291:	lea    r13,[r12]
    7076cdd04295:	movabs r14,0x184fc21026
    7076cdd0429f:	mov    r15d,0x410638
    7076cdd042a5:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7076cdd042af:	movdqu xmm1,XMMWORD PTR [r12+0x130]
    7076cdd042b9:	pshufd xmm1,xmm1,0x44
    7076cdd042be:	movdqu xmm14,XMMWORD PTR [r12+0x170]
    7076cdd042c8:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd042cd:	movdqa xmm14,xmm0
    7076cdd042d2:	movdqu xmm15,XMMWORD PTR [rip+0x2795]        # 0x7076cdd06a70
    7076cdd042db:	pand   xmm14,xmm15
    7076cdd042e0:	movdqu xmm15,XMMWORD PTR [rip+0x2797]        # 0x7076cdd06a80
    7076cdd042e9:	pcmpeqq xmm14,xmm15
    7076cdd042ef:	movdqa xmm15,xmm0
    7076cdd042f4:	cmpunordpd xmm15,xmm0
    7076cdd042fa:	por    xmm14,xmm15
    7076cdd042ff:	pmovmskb ecx,xmm14
    7076cdd04304:	jrcxz  0x7076cdd0430b
    7076cdd04306:	jmp    0x7076cdd05d41
    7076cdd0430b:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7076cdd04315:	mov    eax,0x0
    7076cdd0431a:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd04326:	mov    rbp,rax
    7076cdd04329:	lea    r13,[r12]
    7076cdd0432d:	movabs r14,0x184fc21072
    7076cdd04337:	mov    r15d,0x41063c
    7076cdd0433d:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7076cdd04347:	movdqu xmm1,XMMWORD PTR [r12+0x130]
    7076cdd04351:	pshufd xmm1,xmm1,0x44
    7076cdd04356:	movdqu xmm14,XMMWORD PTR [r12+0x230]
    7076cdd04360:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd04365:	movdqa xmm14,xmm0
    7076cdd0436a:	movdqu xmm15,XMMWORD PTR [rip+0x26fd]        # 0x7076cdd06a70
    7076cdd04373:	pand   xmm14,xmm15
    7076cdd04378:	movdqu xmm15,XMMWORD PTR [rip+0x26ff]        # 0x7076cdd06a80
    7076cdd04381:	pcmpeqq xmm14,xmm15
    7076cdd04387:	movdqa xmm15,xmm0
    7076cdd0438c:	cmpunordpd xmm15,xmm0
    7076cdd04392:	por    xmm14,xmm15
    7076cdd04397:	pmovmskb ecx,xmm14
    7076cdd0439c:	jrcxz  0x7076cdd043a3
    7076cdd0439e:	jmp    0x7076cdd05dc7
    7076cdd043a3:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7076cdd043ad:	mov    eax,0x0
    7076cdd043b2:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd043be:	mov    rbp,rax
    7076cdd043c1:	mov    r13,QWORD PTR [r12+0xf8]
    7076cdd043c9:	add    r13,0x90
    7076cdd043d0:	mov    r14,r13
    7076cdd043d3:	add    r14,0x10
    7076cdd043d7:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7076cdd043dd:	movdqu xmm3,XMMWORD PTR [r14]
    7076cdd043e2:	movdqu XMMWORD PTR [r12+0x140],xmm2
    7076cdd043ec:	movdqu XMMWORD PTR [r12+0x130],xmm3
    7076cdd043f6:	lea    r13,[r12]
    7076cdd043fa:	movabs r14,0x184fd61271
    7076cdd04404:	mov    r15d,0x410644
    7076cdd0440a:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7076cdd04414:	movdqu xmm1,XMMWORD PTR [r12+0x270]
    7076cdd0441e:	pshufd xmm1,xmm1,0x44
    7076cdd04423:	movdqu xmm14,XMMWORD PTR [r12+0x220]
    7076cdd0442d:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd04432:	movdqa xmm14,xmm0
    7076cdd04437:	movdqu xmm15,XMMWORD PTR [rip+0x2630]        # 0x7076cdd06a70
    7076cdd04440:	pand   xmm14,xmm15
    7076cdd04445:	movdqu xmm15,XMMWORD PTR [rip+0x2632]        # 0x7076cdd06a80
    7076cdd0444e:	pcmpeqq xmm14,xmm15
    7076cdd04454:	movdqa xmm15,xmm0
    7076cdd04459:	cmpunordpd xmm15,xmm0
    7076cdd0445f:	por    xmm14,xmm15
    7076cdd04464:	pmovmskb ecx,xmm14
    7076cdd04469:	jrcxz  0x7076cdd04470
    7076cdd0446b:	jmp    0x7076cdd05e4d
    7076cdd04470:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7076cdd0447a:	mov    eax,0x0
    7076cdd0447f:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd0448b:	mov    rbp,rax
    7076cdd0448e:	mov    r13,QWORD PTR [r12+0xf8]
    7076cdd04496:	add    r13,0x10
    7076cdd0449a:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7076cdd044a0:	movdqu XMMWORD PTR [r12+0x240],xmm2
    7076cdd044aa:	lea    r13,[r12]
    7076cdd044ae:	movabs r14,0x184fd61040
    7076cdd044b8:	mov    r15d,0x41064c
    7076cdd044be:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7076cdd044c8:	movdqu xmm1,XMMWORD PTR [r12+0x270]
    7076cdd044d2:	pshufd xmm1,xmm1,0x44
    7076cdd044d7:	movdqu xmm14,XMMWORD PTR [r12+0x110]
    7076cdd044e1:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd044e6:	movdqa xmm14,xmm0
    7076cdd044eb:	movdqu xmm15,XMMWORD PTR [rip+0x257c]        # 0x7076cdd06a70
    7076cdd044f4:	pand   xmm14,xmm15
    7076cdd044f9:	movdqu xmm15,XMMWORD PTR [rip+0x257e]        # 0x7076cdd06a80
    7076cdd04502:	pcmpeqq xmm14,xmm15
    7076cdd04508:	movdqa xmm15,xmm0
    7076cdd0450d:	cmpunordpd xmm15,xmm0
    7076cdd04513:	por    xmm14,xmm15
    7076cdd04518:	pmovmskb ecx,xmm14
    7076cdd0451d:	jrcxz  0x7076cdd04524
    7076cdd0451f:	jmp    0x7076cdd05ed3
    7076cdd04524:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7076cdd0452e:	mov    eax,0x0
    7076cdd04533:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd0453f:	mov    rbp,rax
    7076cdd04542:	lea    r13,[r12]
    7076cdd04546:	movabs r14,0x184fd61066
    7076cdd04550:	mov    r15d,0x410650
    7076cdd04556:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7076cdd04560:	movdqu xmm1,XMMWORD PTR [r12+0x270]
    7076cdd0456a:	pshufd xmm1,xmm1,0x44
    7076cdd0456f:	movdqu xmm14,XMMWORD PTR [r12+0x170]
    7076cdd04579:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd0457e:	movdqa xmm14,xmm0
    7076cdd04583:	movdqu xmm15,XMMWORD PTR [rip+0x24e4]        # 0x7076cdd06a70
    7076cdd0458c:	pand   xmm14,xmm15
    7076cdd04591:	movdqu xmm15,XMMWORD PTR [rip+0x24e6]        # 0x7076cdd06a80
    7076cdd0459a:	pcmpeqq xmm14,xmm15
    7076cdd045a0:	movdqa xmm15,xmm0
    7076cdd045a5:	cmpunordpd xmm15,xmm0
    7076cdd045ab:	por    xmm14,xmm15
    7076cdd045b0:	pmovmskb ecx,xmm14
    7076cdd045b5:	jrcxz  0x7076cdd045bc
    7076cdd045b7:	jmp    0x7076cdd05f59
    7076cdd045bc:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7076cdd045c6:	mov    eax,0x0
    7076cdd045cb:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd045d7:	mov    rbp,rax
    7076cdd045da:	lea    r13,[r12]
    7076cdd045de:	movabs r14,0x184fd61272
    7076cdd045e8:	mov    r15d,0x410654
    7076cdd045ee:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7076cdd045f8:	movdqu xmm1,XMMWORD PTR [r12+0x270]
    7076cdd04602:	pshufd xmm1,xmm1,0x44
    7076cdd04607:	movdqu xmm14,XMMWORD PTR [r12+0x230]
    7076cdd04611:	vfmadd213pd xmm0,xmm1,xmm14
    7076cdd04616:	movdqa xmm14,xmm0
    7076cdd0461b:	movdqu xmm15,XMMWORD PTR [rip+0x244c]        # 0x7076cdd06a70
    7076cdd04624:	pand   xmm14,xmm15
    7076cdd04629:	movdqu xmm15,XMMWORD PTR [rip+0x244e]        # 0x7076cdd06a80
    7076cdd04632:	pcmpeqq xmm14,xmm15
    7076cdd04638:	movdqa xmm15,xmm0
    7076cdd0463d:	cmpunordpd xmm15,xmm0
    7076cdd04643:	por    xmm14,xmm15
    7076cdd04648:	pmovmskb ecx,xmm14
    7076cdd0464d:	jrcxz  0x7076cdd04654
    7076cdd0464f:	jmp    0x7076cdd05fdf
    7076cdd04654:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7076cdd0465e:	mov    eax,0x0
    7076cdd04663:	mov    DWORD PTR [r12+0x324],0x0
    7076cdd0466f:	mov    rbp,rax
    7076cdd04672:	mov    r13,QWORD PTR [r12+0x60]
    7076cdd04677:	mov    r14,r13
    7076cdd0467a:	add    r14,0x10
    7076cdd0467e:	movdqu xmm2,XMMWORD PTR [r12+0x110]
    7076cdd04688:	movdqu xmm3,XMMWORD PTR [r12+0x170]
    7076cdd04692:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7076cdd04698:	mov    r15d,0x0
    7076cdd0469e:	mov    DWORD PTR [r12+0x32c],r15d
    7076cdd046a6:	movdqu XMMWORD PTR [r14],xmm3
    7076cdd046ab:	add    r13,0x20
    7076cdd046af:	mov    r14,r13
    7076cdd046b2:	add    r14,0x10
    7076cdd046b6:	movdqu xmm2,XMMWORD PTR [r12+0x220]
    7076cdd046c0:	movdqu xmm3,XMMWORD PTR [r12+0x230]
    7076cdd046ca:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7076cdd046d0:	movdqu XMMWORD PTR [r14],xmm3
    7076cdd046d5:	mov    rcx,QWORD PTR [r12+0x380]
    7076cdd046dd:	jrcxz  0x7076cdd046e4
    7076cdd046df:	jmp    0x7076cdd0618d
    7076cdd046e4:	mov    rdx,rbx
    7076cdd046e7:	shr    rdx,0x10
    7076cdd046eb:	and    edx,0xc000
    7076cdd046f1:	mov    rax,rbx
    7076cdd046f4:	shr    rax,0x15
    7076cdd046f8:	and    eax,0x100
    7076cdd046fd:	xor    eax,0x100
    7076cdd04702:	or     edx,eax
    7076cdd04704:	mov    rax,rbx
    7076cdd04707:	shr    rax,0x1c
    7076cdd0470b:	and    eax,0x1
    7076cdd0470e:	or     edx,eax
    7076cdd04710:	mov    QWORD PTR [rsp],rdx
    7076cdd04714:	mov    rax,rbx
    7076cdd04717:	shr    rax,0x1e
    7076cdd0471b:	and    eax,0x1
    7076cdd0471e:	xor    eax,0x1
    7076cdd04721:	test   rax,rax
    7076cdd04724:	jne    0x7076cdd02c02
    7076cdd0472a:	jmp    0x7076cdd0472f
    7076cdd0472f:	mov    r13d,DWORD PTR [r12+0x48]
    7076cdd04734:	add    r13d,0x1
    7076cdd04738:	mov    QWORD PTR [r12+0x48],r13
    7076cdd0473d:	sub    r13d,0x1f4
    7076cdd04744:	mov    rcx,QWORD PTR [r12+0x380]
    7076cdd0474c:	jrcxz  0x7076cdd04753
    7076cdd0474e:	jmp    0x7076cdd061bb
    7076cdd04753:	jne    0x7076cdd02be4
    7076cdd04759:	mov    r11,rax
    7076cdd0475c:	lahf
    7076cdd0475d:	seto   al
    7076cdd04760:	mov    WORD PTR [rsp],ax
    7076cdd04764:	mov    rax,r11
    7076cdd04767:	jmp    0x7076cdd0476c
    7076cdd0476c:	mov    r13d,0x430000
    7076cdd04772:	mov    QWORD PTR [r12+0x40],r13
    7076cdd04777:	mov    r13d,0x0
    7076cdd0477d:	mov    QWORD PTR [r12+0x48],r13
    7076cdd04782:	mov    r13d,0x430c50
    7076cdd04788:	mov    r14,QWORD PTR [r13+0x0]
    7076cdd0478c:	mov    r13d,0x0
    7076cdd04792:	mov    QWORD PTR [r12+0x110],r14
    7076cdd0479a:	mov    QWORD PTR [r12+0x118],r13
    7076cdd047a2:	jmp    0x7076cdd047a7
    7076cdd047a7:	mov    r13,QWORD PTR [r12+0x48]
    7076cdd047ac:	mov    r14,QWORD PTR [r12+0x50]
    7076cdd047b1:	add    r14,r13
    7076cdd047b4:	movdqu xmm2,XMMWORD PTR [r14]
    7076cdd047b9:	movdqu XMMWORD PTR [r12+0x120],xmm2
    7076cdd047c3:	add    r13,0x10
    7076cdd047c7:	mov    QWORD PTR [r12+0x48],r13
    7076cdd047cc:	sub    r13,0x200
    7076cdd047d3:	mov    r13,QWORD PTR [r12+0x128]
    7076cdd047db:	mov    r14d,0x0
    7076cdd047e1:	mov    QWORD PTR [r12+0x130],r13
    7076cdd047e9:	mov    QWORD PTR [r12+0x138],r14
    7076cdd047f1:	movdqu xmm2,XMMWORD PTR [r12+0x110]
    7076cdd047fb:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    7076cdd04805:	movdqa xmm0,xmm2
    7076cdd04809:	movdqa xmm1,xmm3
    7076cdd0480d:	movq   xmm0,xmm0
    7076cdd04811:	movq   xmm1,xmm1
    7076cdd04815:	addsd  xmm0,xmm1
    7076cdd04819:	movdqa xmm14,xmm0
    7076cdd0481e:	movdqu xmm15,XMMWORD PTR [rip+0x2249]        # 0x7076cdd06a70
    7076cdd04827:	pand   xmm14,xmm15
    7076cdd0482c:	movdqu xmm15,XMMWORD PTR [rip+0x224b]        # 0x7076cdd06a80
    7076cdd04835:	pcmpeqq xmm14,xmm15
    7076cdd0483b:	movdqa xmm15,xmm0
    7076cdd04840:	cmpunordpd xmm15,xmm0
    7076cdd04846:	por    xmm14,xmm15
    7076cdd0484b:	pmovmskb ecx,xmm14
    7076cdd04850:	jrcxz  0x7076cdd04857
    7076cdd04852:	jmp    0x7076cdd04b9d
    7076cdd04857:	movdqa xmm4,xmm0
    7076cdd0485b:	movdqu xmm2,XMMWORD PTR [r12+0x130]
    7076cdd04865:	movdqa xmm0,xmm4
    7076cdd04869:	movdqa xmm1,xmm2
    7076cdd0486d:	movq   xmm0,xmm0
    7076cdd04871:	movq   xmm1,xmm1
    7076cdd04875:	addsd  xmm0,xmm1
    7076cdd04879:	movdqa xmm14,xmm0
    7076cdd0487e:	movdqu xmm15,XMMWORD PTR [rip+0x21e9]        # 0x7076cdd06a70
    7076cdd04887:	pand   xmm14,xmm15
    7076cdd0488c:	movdqu xmm15,XMMWORD PTR [rip+0x21eb]        # 0x7076cdd06a80
    7076cdd04895:	pcmpeqq xmm14,xmm15
    7076cdd0489b:	movdqa xmm15,xmm0
    7076cdd048a0:	cmpunordpd xmm15,xmm0
    7076cdd048a6:	por    xmm14,xmm15
    7076cdd048ab:	pmovmskb ecx,xmm14
    7076cdd048b0:	jrcxz  0x7076cdd048b7
    7076cdd048b2:	jmp    0x7076cdd04bdc
    7076cdd048b7:	movdqa xmm3,xmm0
    7076cdd048bb:	movdqu XMMWORD PTR [r12+0x110],xmm3
    7076cdd048c5:	mov    rcx,QWORD PTR [r12+0x380]
    7076cdd048cd:	jrcxz  0x7076cdd048d4
    7076cdd048cf:	jmp    0x7076cdd0624f
    7076cdd048d4:	jne    0x7076cdd048ed
    7076cdd048da:	mov    r11,rax
    7076cdd048dd:	lahf
    7076cdd048de:	seto   al
    7076cdd048e1:	mov    WORD PTR [rsp],ax
    7076cdd048e5:	mov    rax,r11
    7076cdd048e8:	jmp    0x7076cdd04900
    7076cdd048ed:	mov    r11,rax
    7076cdd048f0:	lahf
    7076cdd048f1:	seto   al
    7076cdd048f4:	mov    WORD PTR [rsp],ax
    7076cdd048f8:	mov    rax,r11
    7076cdd048fb:	jmp    0x7076cdd047a7
    7076cdd04900:	mov    r13,QWORD PTR [r12+0xf8]
    7076cdd04908:	mov    r14,r13
    7076cdd0490b:	add    r14,0x1a0
    7076cdd04912:	mov    r15,r14
    7076cdd04915:	add    r15,0x8
    7076cdd04919:	mov    rbp,QWORD PTR [r14]
    7076cdd0491c:	mov    r14,QWORD PTR [r15]
    7076cdd0491f:	mov    QWORD PTR [r12+0xa0],rbp
    7076cdd04927:	mov    QWORD PTR [r12+0x98],r14
    7076cdd0492f:	mov    r14,QWORD PTR [r12+0x40]
    7076cdd04934:	add    r14,0xc50
    7076cdd0493b:	mov    r15,QWORD PTR [r12+0x110]
    7076cdd04943:	mov    QWORD PTR [r14],r15
    7076cdd04946:	mov    r14d,0x0
    7076cdd0494c:	mov    DWORD PTR [r12+0x32c],r14d
    7076cdd04954:	mov    r14,r13
    7076cdd04957:	add    r14,0x190
    7076cdd0495e:	mov    r15,r14
    7076cdd04961:	add    r15,0x8
    7076cdd04965:	mov    rbp,QWORD PTR [r14]
    7076cdd04968:	mov    r14,QWORD PTR [r15]
    7076cdd0496b:	mov    QWORD PTR [r12+0xe8],rbp
    7076cdd04973:	mov    QWORD PTR [r12+0xf0],r14
    7076cdd0497b:	mov    r14,r13
    7076cdd0497e:	add    r14,0x180
    7076cdd04985:	mov    r15,r14
    7076cdd04988:	add    r15,0x8
    7076cdd0498c:	mov    rbp,QWORD PTR [r14]
    7076cdd0498f:	mov    r14,QWORD PTR [r15]
    7076cdd04992:	mov    r15d,0x0
    7076cdd04998:	mov    QWORD PTR [r12+0x1a0],rbp
    7076cdd049a0:	mov    QWORD PTR [r12+0x1a8],r15
    7076cdd049a8:	mov    r15d,0x0
    7076cdd049ae:	mov    QWORD PTR [r12+0x190],r14
    7076cdd049b6:	mov    QWORD PTR [r12+0x198],r15
    7076cdd049be:	mov    r14,r13
    7076cdd049c1:	add    r14,0x170
    7076cdd049c8:	mov    r15,r14
    7076cdd049cb:	add    r15,0x8
    7076cdd049cf:	mov    rbp,QWORD PTR [r14]
    7076cdd049d2:	mov    r14,QWORD PTR [r15]
    7076cdd049d5:	mov    r15d,0x0
    7076cdd049db:	mov    QWORD PTR [r12+0x1c0],rbp
    7076cdd049e3:	mov    QWORD PTR [r12+0x1c8],r15
    7076cdd049eb:	mov    r15d,0x0
    7076cdd049f1:	mov    QWORD PTR [r12+0x1b0],r14
    7076cdd049f9:	mov    QWORD PTR [r12+0x1b8],r15
    7076cdd04a01:	mov    r14,r13
    7076cdd04a04:	add    r14,0x160
    7076cdd04a0b:	mov    r15,r14
    7076cdd04a0e:	add    r15,0x8
    7076cdd04a12:	mov    rbp,QWORD PTR [r14]
    7076cdd04a15:	mov    r14,QWORD PTR [r15]
    7076cdd04a18:	mov    r15d,0x0
    7076cdd04a1e:	mov    QWORD PTR [r12+0x1e0],rbp
    7076cdd04a26:	mov    QWORD PTR [r12+0x1e8],r15
    7076cdd04a2e:	mov    r15d,0x0
    7076cdd04a34:	mov    QWORD PTR [r12+0x1d0],r14
    7076cdd04a3c:	mov    QWORD PTR [r12+0x1d8],r15
    7076cdd04a44:	mov    r14,r13
    7076cdd04a47:	add    r14,0x150
    7076cdd04a4e:	mov    r15,r14
    7076cdd04a51:	add    r15,0x8
    7076cdd04a55:	mov    rbp,QWORD PTR [r14]
    7076cdd04a58:	mov    r14,QWORD PTR [r15]
    7076cdd04a5b:	mov    r15d,0x0
    7076cdd04a61:	mov    QWORD PTR [r12+0x200],rbp
    7076cdd04a69:	mov    QWORD PTR [r12+0x208],r15
    7076cdd04a71:	mov    r15d,0x0
    7076cdd04a77:	mov    QWORD PTR [r12+0x1f0],r14
    7076cdd04a7f:	mov    QWORD PTR [r12+0x1f8],r15
    7076cdd04a87:	add    r13,0x1b0
    7076cdd04a8e:	mov    QWORD PTR [r12+0xf8],r13
    7076cdd04a96:	mov    rcx,QWORD PTR [r12+0x380]
    7076cdd04a9e:	jrcxz  0x7076cdd04aa5
    7076cdd04aa0:	jmp    0x7076cdd062e3
    7076cdd04aa5:	mov    r13,QWORD PTR [r12+0xf0]
    7076cdd04aad:	mov    QWORD PTR [r12+0x100],r13
    7076cdd04ab5:	mov    r11,QWORD PTR [rsp]
    7076cdd04ab9:	mov    QWORD PTR [r12+0x398],r11
    7076cdd04ac1:	mov    rdi,QWORD PTR [r12+0x100]
    7076cdd04ac9:	add    rsp,0x150
    7076cdd04ad0:	movabs r11,0x5b61e73e9940
    7076cdd04ada:	jmp    r11
    7076cdd04add:	mov    r13d,DWORD PTR [r12+0x98]
    7076cdd04ae5:	mov    r14d,DWORD PTR [r12]
    7076cdd04ae9:	add    r14d,r13d
    7076cdd04aec:	mov    QWORD PTR [r12],r14
    7076cdd04af0:	mov    r13d,0x4103e8
    7076cdd04af6:	mov    QWORD PTR [r12+0xf0],r13
    7076cdd04afe:	mov    r13d,0x410938
    7076cdd04b04:	mov    QWORD PTR [r12+0x100],r13
    7076cdd04b0c:	mov    r11,QWORD PTR [rsp]
    7076cdd04b10:	mov    QWORD PTR [r12+0x398],r11
    7076cdd04b18:	mov    edi,0x410938
    7076cdd04b1d:	mov    QWORD PTR [r12+0x100],rdi
    7076cdd04b25:	add    rsp,0x150
    7076cdd04b2c:	nop    DWORD PTR [rax+0x0]
    7076cdd04b30:	jmp    QWORD PTR [rip+0x2]        # 0x7076cdd04b38
    7076cdd04b36:	xchg   ax,ax
    7076cdd04b38:	xor    BYTE PTR [rdi],dl
    7076cdd04b3a:	ror    ch,1
    7076cdd04b3c:	jbe    0x7076cdd04bae
    7076cdd04b3e:	add    BYTE PTR [rax],al
    7076cdd04b40:	rex.W
    7076cdd04b41:	rex.WXB ror r13b,1
    7076cdd04b44:	jbe    0x7076cdd04bb6
    7076cdd04b46:	add    BYTE PTR [rax],al
    7076cdd04b48:	movabs r11,0x5b61e73e9940
    7076cdd04b52:	jmp    r11
    7076cdd04b55:	movdqa xmm0,xmm2
    7076cdd04b59:	movdqa xmm1,xmm3
    7076cdd04b5d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7076cdd04b66:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7076cdd04b6f:	call   0x7076cdd04c20
    7076cdd04b74:	jmp    0x7076cdd02743
    7076cdd04b79:	movdqa xmm0,xmm2
    7076cdd04b7d:	movdqa xmm1,xmm3
    7076cdd04b81:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7076cdd04b8a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7076cdd04b93:	call   0x7076cdd04c20
    7076cdd04b98:	jmp    0x7076cdd027cf
    7076cdd04b9d:	mov    r11,rax
    7076cdd04ba0:	lahf
    7076cdd04ba1:	seto   al
    7076cdd04ba4:	mov    WORD PTR [rsp],ax
    7076cdd04ba8:	mov    rax,r11
    7076cdd04bab:	movdqa xmm0,xmm2
    7076cdd04baf:	movdqa xmm1,xmm3
    7076cdd04bb3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7076cdd04bbc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7076cdd04bc5:	call   0x7076cdd04cf0
    7076cdd04bca:	mov    r11,rax
    7076cdd04bcd:	movzx  eax,WORD PTR [rsp]
    7076cdd04bd1:	add    al,0x7f
    7076cdd04bd3:	sahf
    7076cdd04bd4:	mov    rax,r11
    7076cdd04bd7:	jmp    0x7076cdd04857
    7076cdd04bdc:	mov    r11,rax
    7076cdd04bdf:	lahf
    7076cdd04be0:	seto   al
    7076cdd04be3:	mov    WORD PTR [rsp],ax
    7076cdd04be7:	mov    rax,r11
    7076cdd04bea:	movdqa xmm0,xmm4
    7076cdd04bee:	movdqa xmm1,xmm2
    7076cdd04bf2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7076cdd04bfb:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7076cdd04c04:	call   0x7076cdd04e50
    7076cdd04c09:	mov    r11,rax
    7076cdd04c0c:	movzx  eax,WORD PTR [rsp]
    7076cdd04c10:	add    al,0x7f
    7076cdd04c12:	sahf
    7076cdd04c13:	mov    rax,r11
    7076cdd04c16:	jmp    0x7076cdd048b7
    7076cdd04c1b:	nop    DWORD PTR [rax+rax*1+0x0]
    7076cdd04c20:	sub    rsp,0x8
    7076cdd04c24:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd04c30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7076cdd04c36:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7076cdd04c3c:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd04c44:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd04c4a:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd04c4f:	test   r10d,0x3f
    7076cdd04c56:	je     0x7076cdd04c7b
    7076cdd04c5c:	mov    r11d,r10d
    7076cdd04c5f:	shr    r10d,1
    7076cdd04c62:	and    r10d,0x1e
    7076cdd04c66:	and    r11d,0x1
    7076cdd04c6a:	or     r10d,r11d
    7076cdd04c6d:	or     DWORD PTR [r12+0x314],r10d
    7076cdd04c75:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd04c7b:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd04c81:	lea    rdi,[rsp+0x110]
    7076cdd04c89:	lea    rsi,[rsp+0xf0]
    7076cdd04c91:	lea    rdx,[rsp+0x100]
    7076cdd04c99:	mov    ecx,0x16
    7076cdd04c9e:	mov    r8d,0x0
    7076cdd04ca4:	lea    r9,[r12+0x314]
    7076cdd04cac:	movabs r11,0x5b61e7250650
    7076cdd04cb6:	call   r11
    7076cdd04cb9:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd04cbf:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7076cdd04cc5:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7076cdd04ccb:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd04cd3:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd04cdf:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7076cdd04ce8:	add    rsp,0x8
    7076cdd04cec:	ret
    7076cdd04ced:	nop    DWORD PTR [rax]
    7076cdd04cf0:	sub    rsp,0x8
    7076cdd04cf4:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd04d00:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7076cdd04d06:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7076cdd04d0c:	push   rdx
    7076cdd04d0d:	push   rsi
    7076cdd04d0e:	push   r10
    7076cdd04d10:	push   r11
    7076cdd04d12:	mov    rdx,QWORD PTR [rsp+0x30]
    7076cdd04d17:	mov    r10d,edx
    7076cdd04d1a:	and    r10d,0xc000
    7076cdd04d21:	shl    r10d,0x10
    7076cdd04d25:	mov    r11d,edx
    7076cdd04d28:	and    r11d,0x100
    7076cdd04d2f:	shl    r11d,0x15
    7076cdd04d33:	or     r10d,r11d
    7076cdd04d36:	and    edx,0x1
    7076cdd04d39:	shl    edx,0x1c
    7076cdd04d3c:	or     r10d,edx
    7076cdd04d3f:	btc    r10,0x1d
    7076cdd04d44:	mov    r11d,0xf0000000
    7076cdd04d4a:	and    r11,r10
    7076cdd04d4d:	movabs rsi,0xffffffff0fffffff
    7076cdd04d57:	and    rbx,rsi
    7076cdd04d5a:	or     rbx,r11
    7076cdd04d5d:	pop    r11
    7076cdd04d5f:	pop    r10
    7076cdd04d61:	pop    rsi
    7076cdd04d62:	pop    rdx
    7076cdd04d63:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd04d6b:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd04d71:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd04d76:	test   r10d,0x3f
    7076cdd04d7d:	je     0x7076cdd04da2
    7076cdd04d83:	mov    r11d,r10d
    7076cdd04d86:	shr    r10d,1
    7076cdd04d89:	and    r10d,0x1e
    7076cdd04d8d:	and    r11d,0x1
    7076cdd04d91:	or     r10d,r11d
    7076cdd04d94:	or     DWORD PTR [r12+0x314],r10d
    7076cdd04d9c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd04da2:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd04da8:	lea    rdi,[rsp+0x110]
    7076cdd04db0:	lea    rsi,[rsp+0xf0]
    7076cdd04db8:	lea    rdx,[rsp+0x100]
    7076cdd04dc0:	mov    ecx,0xc
    7076cdd04dc5:	mov    r8d,0x0
    7076cdd04dcb:	lea    r9,[r12+0x314]
    7076cdd04dd3:	movabs r11,0x5b61e7250650
    7076cdd04ddd:	call   r11
    7076cdd04de0:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd04de6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7076cdd04dec:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7076cdd04df2:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd04dfa:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd04e06:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7076cdd04e0f:	mov    rdx,rbx
    7076cdd04e12:	shr    rdx,0x10
    7076cdd04e16:	and    edx,0xc000
    7076cdd04e1c:	mov    rax,rbx
    7076cdd04e1f:	shr    rax,0x15
    7076cdd04e23:	and    eax,0x100
    7076cdd04e28:	xor    eax,0x100
    7076cdd04e2d:	or     edx,eax
    7076cdd04e2f:	mov    rax,rbx
    7076cdd04e32:	shr    rax,0x1c
    7076cdd04e36:	and    eax,0x1
    7076cdd04e39:	or     edx,eax
    7076cdd04e3b:	mov    QWORD PTR [rsp+0x10],rdx
    7076cdd04e40:	add    rsp,0x8
    7076cdd04e44:	ret
    7076cdd04e45:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7076cdd04e50:	sub    rsp,0x8
    7076cdd04e54:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd04e60:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7076cdd04e66:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7076cdd04e6c:	push   rdx
    7076cdd04e6d:	push   rsi
    7076cdd04e6e:	push   r10
    7076cdd04e70:	push   r11
    7076cdd04e72:	mov    rdx,QWORD PTR [rsp+0x30]
    7076cdd04e77:	mov    r10d,edx
    7076cdd04e7a:	and    r10d,0xc000
    7076cdd04e81:	shl    r10d,0x10
    7076cdd04e85:	mov    r11d,edx
    7076cdd04e88:	and    r11d,0x100
    7076cdd04e8f:	shl    r11d,0x15
    7076cdd04e93:	or     r10d,r11d
    7076cdd04e96:	and    edx,0x1
    7076cdd04e99:	shl    edx,0x1c
    7076cdd04e9c:	or     r10d,edx
    7076cdd04e9f:	btc    r10,0x1d
    7076cdd04ea4:	mov    r11d,0xf0000000
    7076cdd04eaa:	and    r11,r10
    7076cdd04ead:	movabs rsi,0xffffffff0fffffff
    7076cdd04eb7:	and    rbx,rsi
    7076cdd04eba:	or     rbx,r11
    7076cdd04ebd:	pop    r11
    7076cdd04ebf:	pop    r10
    7076cdd04ec1:	pop    rsi
    7076cdd04ec2:	pop    rdx
    7076cdd04ec3:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd04ecb:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd04ed1:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd04ed6:	test   r10d,0x3f
    7076cdd04edd:	je     0x7076cdd04f02
    7076cdd04ee3:	mov    r11d,r10d
    7076cdd04ee6:	shr    r10d,1
    7076cdd04ee9:	and    r10d,0x1e
    7076cdd04eed:	and    r11d,0x1
    7076cdd04ef1:	or     r10d,r11d
    7076cdd04ef4:	or     DWORD PTR [r12+0x314],r10d
    7076cdd04efc:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd04f02:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd04f08:	lea    rdi,[rsp+0x110]
    7076cdd04f10:	lea    rsi,[rsp+0xf0]
    7076cdd04f18:	lea    rdx,[rsp+0x100]
    7076cdd04f20:	mov    ecx,0xc
    7076cdd04f25:	mov    r8d,0x0
    7076cdd04f2b:	lea    r9,[r12+0x314]
    7076cdd04f33:	movabs r11,0x5b61e7250650
    7076cdd04f3d:	call   r11
    7076cdd04f40:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd04f46:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7076cdd04f4c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7076cdd04f52:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd04f5a:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd04f66:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7076cdd04f6f:	mov    rdx,rbx
    7076cdd04f72:	shr    rdx,0x10
    7076cdd04f76:	and    edx,0xc000
    7076cdd04f7c:	mov    rax,rbx
    7076cdd04f7f:	shr    rax,0x15
    7076cdd04f83:	and    eax,0x100
    7076cdd04f88:	xor    eax,0x100
    7076cdd04f8d:	or     edx,eax
    7076cdd04f8f:	mov    rax,rbx
    7076cdd04f92:	shr    rax,0x1c
    7076cdd04f96:	and    eax,0x1
    7076cdd04f99:	or     edx,eax
    7076cdd04f9b:	mov    QWORD PTR [rsp+0x10],rdx
    7076cdd04fa0:	add    rsp,0x8
    7076cdd04fa4:	ret
    7076cdd04fa5:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd04fb1:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd04fb9:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd04fbf:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd04fc4:	test   r10d,0x3f
    7076cdd04fcb:	je     0x7076cdd04ff0
    7076cdd04fd1:	mov    r11d,r10d
    7076cdd04fd4:	shr    r10d,1
    7076cdd04fd7:	and    r10d,0x1e
    7076cdd04fdb:	and    r11d,0x1
    7076cdd04fdf:	or     r10d,r11d
    7076cdd04fe2:	or     DWORD PTR [r12+0x314],r10d
    7076cdd04fea:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd04ff0:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd04ff6:	movabs r11,0x5b61e724b5e0
    7076cdd05000:	mov    rdi,r13
    7076cdd05003:	mov    rsi,r14
    7076cdd05006:	mov    rdx,r15
    7076cdd05009:	call   r11
    7076cdd0500c:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd05012:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd0501a:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd05026:	jmp    0x7076cdd02fce
    7076cdd0502b:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd05037:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd0503f:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd05045:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd0504a:	test   r10d,0x3f
    7076cdd05051:	je     0x7076cdd05076
    7076cdd05057:	mov    r11d,r10d
    7076cdd0505a:	shr    r10d,1
    7076cdd0505d:	and    r10d,0x1e
    7076cdd05061:	and    r11d,0x1
    7076cdd05065:	or     r10d,r11d
    7076cdd05068:	or     DWORD PTR [r12+0x314],r10d
    7076cdd05070:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd05076:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd0507c:	movabs r11,0x5b61e724b5e0
    7076cdd05086:	mov    rdi,r13
    7076cdd05089:	mov    rsi,r14
    7076cdd0508c:	mov    rdx,r15
    7076cdd0508f:	call   r11
    7076cdd05092:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd05098:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd050a0:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd050ac:	jmp    0x7076cdd03061
    7076cdd050b1:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd050bd:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd050c5:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd050cb:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd050d0:	test   r10d,0x3f
    7076cdd050d7:	je     0x7076cdd050fc
    7076cdd050dd:	mov    r11d,r10d
    7076cdd050e0:	shr    r10d,1
    7076cdd050e3:	and    r10d,0x1e
    7076cdd050e7:	and    r11d,0x1
    7076cdd050eb:	or     r10d,r11d
    7076cdd050ee:	or     DWORD PTR [r12+0x314],r10d
    7076cdd050f6:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd050fc:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd05102:	movabs r11,0x5b61e724b5e0
    7076cdd0510c:	mov    rdi,r13
    7076cdd0510f:	mov    rsi,r14
    7076cdd05112:	mov    rdx,r15
    7076cdd05115:	call   r11
    7076cdd05118:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd0511e:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd05126:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd05132:	jmp    0x7076cdd0321f
    7076cdd05137:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd05143:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd0514b:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd05151:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd05156:	test   r10d,0x3f
    7076cdd0515d:	je     0x7076cdd05182
    7076cdd05163:	mov    r11d,r10d
    7076cdd05166:	shr    r10d,1
    7076cdd05169:	and    r10d,0x1e
    7076cdd0516d:	and    r11d,0x1
    7076cdd05171:	or     r10d,r11d
    7076cdd05174:	or     DWORD PTR [r12+0x314],r10d
    7076cdd0517c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd05182:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd05188:	movabs r11,0x5b61e724b5e0
    7076cdd05192:	mov    rdi,r13
    7076cdd05195:	mov    rsi,r14
    7076cdd05198:	mov    rdx,r15
    7076cdd0519b:	call   r11
    7076cdd0519e:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd051a4:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd051ac:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd051b8:	jmp    0x7076cdd032d1
    7076cdd051bd:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd051c9:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd051d1:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd051d7:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd051dc:	test   r10d,0x3f
    7076cdd051e3:	je     0x7076cdd05208
    7076cdd051e9:	mov    r11d,r10d
    7076cdd051ec:	shr    r10d,1
    7076cdd051ef:	and    r10d,0x1e
    7076cdd051f3:	and    r11d,0x1
    7076cdd051f7:	or     r10d,r11d
    7076cdd051fa:	or     DWORD PTR [r12+0x314],r10d
    7076cdd05202:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd05208:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd0520e:	movabs r11,0x5b61e724b5e0
    7076cdd05218:	mov    rdi,r13
    7076cdd0521b:	mov    rsi,r14
    7076cdd0521e:	mov    rdx,r15
    7076cdd05221:	call   r11
    7076cdd05224:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd0522a:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd05232:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd0523e:	jmp    0x7076cdd03481
    7076cdd05243:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd0524f:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd05257:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd0525d:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd05262:	test   r10d,0x3f
    7076cdd05269:	je     0x7076cdd0528e
    7076cdd0526f:	mov    r11d,r10d
    7076cdd05272:	shr    r10d,1
    7076cdd05275:	and    r10d,0x1e
    7076cdd05279:	and    r11d,0x1
    7076cdd0527d:	or     r10d,r11d
    7076cdd05280:	or     DWORD PTR [r12+0x314],r10d
    7076cdd05288:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd0528e:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd05294:	movabs r11,0x5b61e724b5e0
    7076cdd0529e:	mov    rdi,r13
    7076cdd052a1:	mov    rsi,r14
    7076cdd052a4:	mov    rdx,r15
    7076cdd052a7:	call   r11
    7076cdd052aa:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd052b0:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd052b8:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd052c4:	jmp    0x7076cdd03519
    7076cdd052c9:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd052d5:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd052dd:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd052e3:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd052e8:	test   r10d,0x3f
    7076cdd052ef:	je     0x7076cdd05314
    7076cdd052f5:	mov    r11d,r10d
    7076cdd052f8:	shr    r10d,1
    7076cdd052fb:	and    r10d,0x1e
    7076cdd052ff:	and    r11d,0x1
    7076cdd05303:	or     r10d,r11d
    7076cdd05306:	or     DWORD PTR [r12+0x314],r10d
    7076cdd0530e:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd05314:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd0531a:	movabs r11,0x5b61e724b5e0
    7076cdd05324:	mov    rdi,r13
    7076cdd05327:	mov    rsi,r14
    7076cdd0532a:	mov    rdx,r15
    7076cdd0532d:	call   r11
    7076cdd05330:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd05336:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd0533e:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd0534a:	jmp    0x7076cdd035b1
    7076cdd0534f:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd0535b:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd05363:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd05369:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd0536e:	test   r10d,0x3f
    7076cdd05375:	je     0x7076cdd0539a
    7076cdd0537b:	mov    r11d,r10d
    7076cdd0537e:	shr    r10d,1
    7076cdd05381:	and    r10d,0x1e
    7076cdd05385:	and    r11d,0x1
    7076cdd05389:	or     r10d,r11d
    7076cdd0538c:	or     DWORD PTR [r12+0x314],r10d
    7076cdd05394:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd0539a:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd053a0:	movabs r11,0x5b61e724b5e0
    7076cdd053aa:	mov    rdi,r13
    7076cdd053ad:	mov    rsi,r14
    7076cdd053b0:	mov    rdx,r15
    7076cdd053b3:	call   r11
    7076cdd053b6:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd053bc:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd053c4:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd053d0:	jmp    0x7076cdd03665
    7076cdd053d5:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd053e1:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd053e9:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd053ef:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd053f4:	test   r10d,0x3f
    7076cdd053fb:	je     0x7076cdd05420
    7076cdd05401:	mov    r11d,r10d
    7076cdd05404:	shr    r10d,1
    7076cdd05407:	and    r10d,0x1e
    7076cdd0540b:	and    r11d,0x1
    7076cdd0540f:	or     r10d,r11d
    7076cdd05412:	or     DWORD PTR [r12+0x314],r10d
    7076cdd0541a:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd05420:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd05426:	movabs r11,0x5b61e724b5e0
    7076cdd05430:	mov    rdi,r13
    7076cdd05433:	mov    rsi,r14
    7076cdd05436:	mov    rdx,r15
    7076cdd05439:	call   r11
    7076cdd0543c:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd05442:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd0544a:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd05456:	jmp    0x7076cdd0376d
    7076cdd0545b:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd05467:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd0546f:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd05475:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd0547a:	test   r10d,0x3f
    7076cdd05481:	je     0x7076cdd054a6
    7076cdd05487:	mov    r11d,r10d
    7076cdd0548a:	shr    r10d,1
    7076cdd0548d:	and    r10d,0x1e
    7076cdd05491:	and    r11d,0x1
    7076cdd05495:	or     r10d,r11d
    7076cdd05498:	or     DWORD PTR [r12+0x314],r10d
    7076cdd054a0:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd054a6:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd054ac:	movabs r11,0x5b61e724b5e0
    7076cdd054b6:	mov    rdi,r13
    7076cdd054b9:	mov    rsi,r14
    7076cdd054bc:	mov    rdx,r15
    7076cdd054bf:	call   r11
    7076cdd054c2:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd054c8:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd054d0:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd054dc:	jmp    0x7076cdd03805
    7076cdd054e1:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd054ed:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd054f5:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd054fb:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd05500:	test   r10d,0x3f
    7076cdd05507:	je     0x7076cdd0552c
    7076cdd0550d:	mov    r11d,r10d
    7076cdd05510:	shr    r10d,1
    7076cdd05513:	and    r10d,0x1e
    7076cdd05517:	and    r11d,0x1
    7076cdd0551b:	or     r10d,r11d
    7076cdd0551e:	or     DWORD PTR [r12+0x314],r10d
    7076cdd05526:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd0552c:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd05532:	movabs r11,0x5b61e724b5e0
    7076cdd0553c:	mov    rdi,r13
    7076cdd0553f:	mov    rsi,r14
    7076cdd05542:	mov    rdx,r15
    7076cdd05545:	call   r11
    7076cdd05548:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd0554e:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd05556:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd05562:	jmp    0x7076cdd0389d
    7076cdd05567:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd05573:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd0557b:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd05581:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd05586:	test   r10d,0x3f
    7076cdd0558d:	je     0x7076cdd055b2
    7076cdd05593:	mov    r11d,r10d
    7076cdd05596:	shr    r10d,1
    7076cdd05599:	and    r10d,0x1e
    7076cdd0559d:	and    r11d,0x1
    7076cdd055a1:	or     r10d,r11d
    7076cdd055a4:	or     DWORD PTR [r12+0x314],r10d
    7076cdd055ac:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd055b2:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd055b8:	movabs r11,0x5b61e724b5e0
    7076cdd055c2:	mov    rdi,r13
    7076cdd055c5:	mov    rsi,r14
    7076cdd055c8:	mov    rdx,r15
    7076cdd055cb:	call   r11
    7076cdd055ce:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd055d4:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd055dc:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd055e8:	jmp    0x7076cdd03935
    7076cdd055ed:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd055f9:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd05601:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd05607:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd0560c:	test   r10d,0x3f
    7076cdd05613:	je     0x7076cdd05638
    7076cdd05619:	mov    r11d,r10d
    7076cdd0561c:	shr    r10d,1
    7076cdd0561f:	and    r10d,0x1e
    7076cdd05623:	and    r11d,0x1
    7076cdd05627:	or     r10d,r11d
    7076cdd0562a:	or     DWORD PTR [r12+0x314],r10d
    7076cdd05632:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd05638:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd0563e:	movabs r11,0x5b61e724b5e0
    7076cdd05648:	mov    rdi,r13
    7076cdd0564b:	mov    rsi,r14
    7076cdd0564e:	mov    rdx,r15
    7076cdd05651:	call   r11
    7076cdd05654:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd0565a:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd05662:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd0566e:	jmp    0x7076cdd03a05
    7076cdd05673:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd0567f:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd05687:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd0568d:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd05692:	test   r10d,0x3f
    7076cdd05699:	je     0x7076cdd056be
    7076cdd0569f:	mov    r11d,r10d
    7076cdd056a2:	shr    r10d,1
    7076cdd056a5:	and    r10d,0x1e
    7076cdd056a9:	and    r11d,0x1
    7076cdd056ad:	or     r10d,r11d
    7076cdd056b0:	or     DWORD PTR [r12+0x314],r10d
    7076cdd056b8:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd056be:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd056c4:	movabs r11,0x5b61e724b5e0
    7076cdd056ce:	mov    rdi,r13
    7076cdd056d1:	mov    rsi,r14
    7076cdd056d4:	mov    rdx,r15
    7076cdd056d7:	call   r11
    7076cdd056da:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd056e0:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd056e8:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd056f4:	jmp    0x7076cdd03a9d
    7076cdd056f9:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd05705:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd0570d:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd05713:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd05718:	test   r10d,0x3f
    7076cdd0571f:	je     0x7076cdd05744
    7076cdd05725:	mov    r11d,r10d
    7076cdd05728:	shr    r10d,1
    7076cdd0572b:	and    r10d,0x1e
    7076cdd0572f:	and    r11d,0x1
    7076cdd05733:	or     r10d,r11d
    7076cdd05736:	or     DWORD PTR [r12+0x314],r10d
    7076cdd0573e:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd05744:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd0574a:	movabs r11,0x5b61e724b5e0
    7076cdd05754:	mov    rdi,r13
    7076cdd05757:	mov    rsi,r14
    7076cdd0575a:	mov    rdx,r15
    7076cdd0575d:	call   r11
    7076cdd05760:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd05766:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd0576e:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd0577a:	jmp    0x7076cdd03b54
    7076cdd0577f:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd0578b:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd05793:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd05799:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd0579e:	test   r10d,0x3f
    7076cdd057a5:	je     0x7076cdd057ca
    7076cdd057ab:	mov    r11d,r10d
    7076cdd057ae:	shr    r10d,1
    7076cdd057b1:	and    r10d,0x1e
    7076cdd057b5:	and    r11d,0x1
    7076cdd057b9:	or     r10d,r11d
    7076cdd057bc:	or     DWORD PTR [r12+0x314],r10d
    7076cdd057c4:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd057ca:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd057d0:	movabs r11,0x5b61e724b5e0
    7076cdd057da:	mov    rdi,r13
    7076cdd057dd:	mov    rsi,r14
    7076cdd057e0:	mov    rdx,r15
    7076cdd057e3:	call   r11
    7076cdd057e6:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd057ec:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd057f4:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd05800:	jmp    0x7076cdd03bec
    7076cdd05805:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd05811:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd05819:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd0581f:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd05824:	test   r10d,0x3f
    7076cdd0582b:	je     0x7076cdd05850
    7076cdd05831:	mov    r11d,r10d
    7076cdd05834:	shr    r10d,1
    7076cdd05837:	and    r10d,0x1e
    7076cdd0583b:	and    r11d,0x1
    7076cdd0583f:	or     r10d,r11d
    7076cdd05842:	or     DWORD PTR [r12+0x314],r10d
    7076cdd0584a:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd05850:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd05856:	movabs r11,0x5b61e724b5e0
    7076cdd05860:	mov    rdi,r13
    7076cdd05863:	mov    rsi,r14
    7076cdd05866:	mov    rdx,r15
    7076cdd05869:	call   r11
    7076cdd0586c:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd05872:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd0587a:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd05886:	jmp    0x7076cdd03cd2
    7076cdd0588b:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd05897:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd0589f:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd058a5:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd058aa:	test   r10d,0x3f
    7076cdd058b1:	je     0x7076cdd058d6
    7076cdd058b7:	mov    r11d,r10d
    7076cdd058ba:	shr    r10d,1
    7076cdd058bd:	and    r10d,0x1e
    7076cdd058c1:	and    r11d,0x1
    7076cdd058c5:	or     r10d,r11d
    7076cdd058c8:	or     DWORD PTR [r12+0x314],r10d
    7076cdd058d0:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd058d6:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd058dc:	movabs r11,0x5b61e724b5e0
    7076cdd058e6:	mov    rdi,r13
    7076cdd058e9:	mov    rsi,r14
    7076cdd058ec:	mov    rdx,r15
    7076cdd058ef:	call   r11
    7076cdd058f2:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd058f8:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd05900:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd0590c:	jmp    0x7076cdd03d6a
    7076cdd05911:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd0591d:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd05925:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd0592b:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd05930:	test   r10d,0x3f
    7076cdd05937:	je     0x7076cdd0595c
    7076cdd0593d:	mov    r11d,r10d
    7076cdd05940:	shr    r10d,1
    7076cdd05943:	and    r10d,0x1e
    7076cdd05947:	and    r11d,0x1
    7076cdd0594b:	or     r10d,r11d
    7076cdd0594e:	or     DWORD PTR [r12+0x314],r10d
    7076cdd05956:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd0595c:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd05962:	movabs r11,0x5b61e724b5e0
    7076cdd0596c:	mov    rdi,r13
    7076cdd0596f:	mov    rsi,r14
    7076cdd05972:	mov    rdx,r15
    7076cdd05975:	call   r11
    7076cdd05978:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd0597e:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd05986:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd05992:	jmp    0x7076cdd03e02
    7076cdd05997:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd059a3:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd059ab:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd059b1:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd059b6:	test   r10d,0x3f
    7076cdd059bd:	je     0x7076cdd059e2
    7076cdd059c3:	mov    r11d,r10d
    7076cdd059c6:	shr    r10d,1
    7076cdd059c9:	and    r10d,0x1e
    7076cdd059cd:	and    r11d,0x1
    7076cdd059d1:	or     r10d,r11d
    7076cdd059d4:	or     DWORD PTR [r12+0x314],r10d
    7076cdd059dc:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd059e2:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd059e8:	movabs r11,0x5b61e724b5e0
    7076cdd059f2:	mov    rdi,r13
    7076cdd059f5:	mov    rsi,r14
    7076cdd059f8:	mov    rdx,r15
    7076cdd059fb:	call   r11
    7076cdd059fe:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd05a04:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd05a0c:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd05a18:	jmp    0x7076cdd03e9a
    7076cdd05a1d:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd05a29:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd05a31:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd05a37:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd05a3c:	test   r10d,0x3f
    7076cdd05a43:	je     0x7076cdd05a68
    7076cdd05a49:	mov    r11d,r10d
    7076cdd05a4c:	shr    r10d,1
    7076cdd05a4f:	and    r10d,0x1e
    7076cdd05a53:	and    r11d,0x1
    7076cdd05a57:	or     r10d,r11d
    7076cdd05a5a:	or     DWORD PTR [r12+0x314],r10d
    7076cdd05a62:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd05a68:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd05a6e:	movabs r11,0x5b61e724b5e0
    7076cdd05a78:	mov    rdi,r13
    7076cdd05a7b:	mov    rsi,r14
    7076cdd05a7e:	mov    rdx,r15
    7076cdd05a81:	call   r11
    7076cdd05a84:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd05a8a:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd05a92:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd05a9e:	jmp    0x7076cdd03f64
    7076cdd05aa3:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd05aaf:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd05ab7:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd05abd:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd05ac2:	test   r10d,0x3f
    7076cdd05ac9:	je     0x7076cdd05aee
    7076cdd05acf:	mov    r11d,r10d
    7076cdd05ad2:	shr    r10d,1
    7076cdd05ad5:	and    r10d,0x1e
    7076cdd05ad9:	and    r11d,0x1
    7076cdd05add:	or     r10d,r11d
    7076cdd05ae0:	or     DWORD PTR [r12+0x314],r10d
    7076cdd05ae8:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd05aee:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd05af4:	movabs r11,0x5b61e724b5e0
    7076cdd05afe:	mov    rdi,r13
    7076cdd05b01:	mov    rsi,r14
    7076cdd05b04:	mov    rdx,r15
    7076cdd05b07:	call   r11
    7076cdd05b0a:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd05b10:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd05b18:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd05b24:	jmp    0x7076cdd03ffc
    7076cdd05b29:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd05b35:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd05b3d:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd05b43:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd05b48:	test   r10d,0x3f
    7076cdd05b4f:	je     0x7076cdd05b74
    7076cdd05b55:	mov    r11d,r10d
    7076cdd05b58:	shr    r10d,1
    7076cdd05b5b:	and    r10d,0x1e
    7076cdd05b5f:	and    r11d,0x1
    7076cdd05b63:	or     r10d,r11d
    7076cdd05b66:	or     DWORD PTR [r12+0x314],r10d
    7076cdd05b6e:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd05b74:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd05b7a:	movabs r11,0x5b61e724b5e0
    7076cdd05b84:	mov    rdi,r13
    7076cdd05b87:	mov    rsi,r14
    7076cdd05b8a:	mov    rdx,r15
    7076cdd05b8d:	call   r11
    7076cdd05b90:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd05b96:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd05b9e:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd05baa:	jmp    0x7076cdd04094
    7076cdd05baf:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd05bbb:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd05bc3:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd05bc9:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd05bce:	test   r10d,0x3f
    7076cdd05bd5:	je     0x7076cdd05bfa
    7076cdd05bdb:	mov    r11d,r10d
    7076cdd05bde:	shr    r10d,1
    7076cdd05be1:	and    r10d,0x1e
    7076cdd05be5:	and    r11d,0x1
    7076cdd05be9:	or     r10d,r11d
    7076cdd05bec:	or     DWORD PTR [r12+0x314],r10d
    7076cdd05bf4:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd05bfa:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd05c00:	movabs r11,0x5b61e724b5e0
    7076cdd05c0a:	mov    rdi,r13
    7076cdd05c0d:	mov    rsi,r14
    7076cdd05c10:	mov    rdx,r15
    7076cdd05c13:	call   r11
    7076cdd05c16:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd05c1c:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd05c24:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd05c30:	jmp    0x7076cdd0412c
    7076cdd05c35:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd05c41:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd05c49:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd05c4f:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd05c54:	test   r10d,0x3f
    7076cdd05c5b:	je     0x7076cdd05c80
    7076cdd05c61:	mov    r11d,r10d
    7076cdd05c64:	shr    r10d,1
    7076cdd05c67:	and    r10d,0x1e
    7076cdd05c6b:	and    r11d,0x1
    7076cdd05c6f:	or     r10d,r11d
    7076cdd05c72:	or     DWORD PTR [r12+0x314],r10d
    7076cdd05c7a:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd05c80:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd05c86:	movabs r11,0x5b61e724b5e0
    7076cdd05c90:	mov    rdi,r13
    7076cdd05c93:	mov    rsi,r14
    7076cdd05c96:	mov    rdx,r15
    7076cdd05c99:	call   r11
    7076cdd05c9c:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd05ca2:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd05caa:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd05cb6:	jmp    0x7076cdd041f6
    7076cdd05cbb:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd05cc7:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd05ccf:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd05cd5:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd05cda:	test   r10d,0x3f
    7076cdd05ce1:	je     0x7076cdd05d06
    7076cdd05ce7:	mov    r11d,r10d
    7076cdd05cea:	shr    r10d,1
    7076cdd05ced:	and    r10d,0x1e
    7076cdd05cf1:	and    r11d,0x1
    7076cdd05cf5:	or     r10d,r11d
    7076cdd05cf8:	or     DWORD PTR [r12+0x314],r10d
    7076cdd05d00:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd05d06:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd05d0c:	movabs r11,0x5b61e724b5e0
    7076cdd05d16:	mov    rdi,r13
    7076cdd05d19:	mov    rsi,r14
    7076cdd05d1c:	mov    rdx,r15
    7076cdd05d1f:	call   r11
    7076cdd05d22:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd05d28:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd05d30:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd05d3c:	jmp    0x7076cdd0428e
    7076cdd05d41:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd05d4d:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd05d55:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd05d5b:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd05d60:	test   r10d,0x3f
    7076cdd05d67:	je     0x7076cdd05d8c
    7076cdd05d6d:	mov    r11d,r10d
    7076cdd05d70:	shr    r10d,1
    7076cdd05d73:	and    r10d,0x1e
    7076cdd05d77:	and    r11d,0x1
    7076cdd05d7b:	or     r10d,r11d
    7076cdd05d7e:	or     DWORD PTR [r12+0x314],r10d
    7076cdd05d86:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd05d8c:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd05d92:	movabs r11,0x5b61e724b5e0
    7076cdd05d9c:	mov    rdi,r13
    7076cdd05d9f:	mov    rsi,r14
    7076cdd05da2:	mov    rdx,r15
    7076cdd05da5:	call   r11
    7076cdd05da8:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd05dae:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd05db6:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd05dc2:	jmp    0x7076cdd04326
    7076cdd05dc7:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd05dd3:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd05ddb:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd05de1:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd05de6:	test   r10d,0x3f
    7076cdd05ded:	je     0x7076cdd05e12
    7076cdd05df3:	mov    r11d,r10d
    7076cdd05df6:	shr    r10d,1
    7076cdd05df9:	and    r10d,0x1e
    7076cdd05dfd:	and    r11d,0x1
    7076cdd05e01:	or     r10d,r11d
    7076cdd05e04:	or     DWORD PTR [r12+0x314],r10d
    7076cdd05e0c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd05e12:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd05e18:	movabs r11,0x5b61e724b5e0
    7076cdd05e22:	mov    rdi,r13
    7076cdd05e25:	mov    rsi,r14
    7076cdd05e28:	mov    rdx,r15
    7076cdd05e2b:	call   r11
    7076cdd05e2e:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd05e34:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd05e3c:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd05e48:	jmp    0x7076cdd043be
    7076cdd05e4d:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd05e59:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd05e61:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd05e67:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd05e6c:	test   r10d,0x3f
    7076cdd05e73:	je     0x7076cdd05e98
    7076cdd05e79:	mov    r11d,r10d
    7076cdd05e7c:	shr    r10d,1
    7076cdd05e7f:	and    r10d,0x1e
    7076cdd05e83:	and    r11d,0x1
    7076cdd05e87:	or     r10d,r11d
    7076cdd05e8a:	or     DWORD PTR [r12+0x314],r10d
    7076cdd05e92:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd05e98:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd05e9e:	movabs r11,0x5b61e724b5e0
    7076cdd05ea8:	mov    rdi,r13
    7076cdd05eab:	mov    rsi,r14
    7076cdd05eae:	mov    rdx,r15
    7076cdd05eb1:	call   r11
    7076cdd05eb4:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd05eba:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd05ec2:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd05ece:	jmp    0x7076cdd0448b
    7076cdd05ed3:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd05edf:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd05ee7:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd05eed:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd05ef2:	test   r10d,0x3f
    7076cdd05ef9:	je     0x7076cdd05f1e
    7076cdd05eff:	mov    r11d,r10d
    7076cdd05f02:	shr    r10d,1
    7076cdd05f05:	and    r10d,0x1e
    7076cdd05f09:	and    r11d,0x1
    7076cdd05f0d:	or     r10d,r11d
    7076cdd05f10:	or     DWORD PTR [r12+0x314],r10d
    7076cdd05f18:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd05f1e:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd05f24:	movabs r11,0x5b61e724b5e0
    7076cdd05f2e:	mov    rdi,r13
    7076cdd05f31:	mov    rsi,r14
    7076cdd05f34:	mov    rdx,r15
    7076cdd05f37:	call   r11
    7076cdd05f3a:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd05f40:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd05f48:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd05f54:	jmp    0x7076cdd0453f
    7076cdd05f59:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd05f65:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd05f6d:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd05f73:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd05f78:	test   r10d,0x3f
    7076cdd05f7f:	je     0x7076cdd05fa4
    7076cdd05f85:	mov    r11d,r10d
    7076cdd05f88:	shr    r10d,1
    7076cdd05f8b:	and    r10d,0x1e
    7076cdd05f8f:	and    r11d,0x1
    7076cdd05f93:	or     r10d,r11d
    7076cdd05f96:	or     DWORD PTR [r12+0x314],r10d
    7076cdd05f9e:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd05fa4:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd05faa:	movabs r11,0x5b61e724b5e0
    7076cdd05fb4:	mov    rdi,r13
    7076cdd05fb7:	mov    rsi,r14
    7076cdd05fba:	mov    rdx,r15
    7076cdd05fbd:	call   r11
    7076cdd05fc0:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd05fc6:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd05fce:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd05fda:	jmp    0x7076cdd045d7
    7076cdd05fdf:	mov    QWORD PTR [r12+0x378],0x3
    7076cdd05feb:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd05ff3:	stmxcsr DWORD PTR [r12-0x28]
    7076cdd05ff9:	mov    r10d,DWORD PTR [r12-0x28]
    7076cdd05ffe:	test   r10d,0x3f
    7076cdd06005:	je     0x7076cdd0602a
    7076cdd0600b:	mov    r11d,r10d
    7076cdd0600e:	shr    r10d,1
    7076cdd06011:	and    r10d,0x1e
    7076cdd06015:	and    r11d,0x1
    7076cdd06019:	or     r10d,r11d
    7076cdd0601c:	or     DWORD PTR [r12+0x314],r10d
    7076cdd06024:	and    DWORD PTR [r12-0x28],0xffffffc0
    7076cdd0602a:	ldmxcsr DWORD PTR [r12-0x38]
    7076cdd06030:	movabs r11,0x5b61e724b5e0
    7076cdd0603a:	mov    rdi,r13
    7076cdd0603d:	mov    rsi,r14
    7076cdd06040:	mov    rdx,r15
    7076cdd06043:	call   r11
    7076cdd06046:	ldmxcsr DWORD PTR [r12-0x28]
    7076cdd0604c:	mov    rbx,QWORD PTR [r12+0x108]
    7076cdd06054:	mov    QWORD PTR [r12+0x378],0x2
    7076cdd06060:	jmp    0x7076cdd0466f
    7076cdd06065:	mov    eax,0x4103f0
    7076cdd0606a:	mov    QWORD PTR [r12+0x100],rax
    7076cdd06072:	push   rdx
    7076cdd06073:	push   rsi
    7076cdd06074:	push   r10
    7076cdd06076:	push   r11
    7076cdd06078:	mov    r11,rax
    7076cdd0607b:	lahf
    7076cdd0607c:	seto   al
    7076cdd0607f:	mov    WORD PTR [rsp+0x20],ax
    7076cdd06084:	mov    rax,r11
    7076cdd06087:	mov    rdx,QWORD PTR [rsp+0x20]
    7076cdd0608c:	mov    r10d,edx
    7076cdd0608f:	and    r10d,0xc000
    7076cdd06096:	shl    r10d,0x10
    7076cdd0609a:	mov    r11d,edx
    7076cdd0609d:	and    r11d,0x100
    7076cdd060a4:	shl    r11d,0x15
    7076cdd060a8:	or     r10d,r11d
    7076cdd060ab:	and    edx,0x1
    7076cdd060ae:	shl    edx,0x1c
    7076cdd060b1:	or     r10d,edx
    7076cdd060b4:	btc    r10,0x1d
    7076cdd060b9:	mov    r11d,0xf0000000
    7076cdd060bf:	and    r11,r10
    7076cdd060c2:	movabs rsi,0xffffffff0fffffff
    7076cdd060cc:	and    rbx,rsi
    7076cdd060cf:	or     rbx,r11
    7076cdd060d2:	pop    r11
    7076cdd060d4:	pop    r10
    7076cdd060d6:	pop    rsi
    7076cdd060d7:	pop    rdx
    7076cdd060d8:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd060e0:	add    rsp,0x150
    7076cdd060e7:	mov    eax,0xc
    7076cdd060ec:	movabs r11,0x5b61e73e9ca0
    7076cdd060f6:	jmp    r11
    7076cdd060f9:	mov    eax,0x41047c
    7076cdd060fe:	mov    QWORD PTR [r12+0x100],rax
    7076cdd06106:	push   rdx
    7076cdd06107:	push   rsi
    7076cdd06108:	push   r10
    7076cdd0610a:	push   r11
    7076cdd0610c:	mov    r11,rax
    7076cdd0610f:	lahf
    7076cdd06110:	seto   al
    7076cdd06113:	mov    WORD PTR [rsp+0x20],ax
    7076cdd06118:	mov    rax,r11
    7076cdd0611b:	mov    rdx,QWORD PTR [rsp+0x20]
    7076cdd06120:	mov    r10d,edx
    7076cdd06123:	and    r10d,0xc000
    7076cdd0612a:	shl    r10d,0x10
    7076cdd0612e:	mov    r11d,edx
    7076cdd06131:	and    r11d,0x100
    7076cdd06138:	shl    r11d,0x15
    7076cdd0613c:	or     r10d,r11d
    7076cdd0613f:	and    edx,0x1
    7076cdd06142:	shl    edx,0x1c
    7076cdd06145:	or     r10d,edx
    7076cdd06148:	btc    r10,0x1d
    7076cdd0614d:	mov    r11d,0xf0000000
    7076cdd06153:	and    r11,r10
    7076cdd06156:	movabs rsi,0xffffffff0fffffff
    7076cdd06160:	and    rbx,rsi
    7076cdd06163:	or     rbx,r11
    7076cdd06166:	pop    r11
    7076cdd06168:	pop    r10
    7076cdd0616a:	pop    rsi
    7076cdd0616b:	pop    rdx
    7076cdd0616c:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd06174:	add    rsp,0x150
    7076cdd0617b:	mov    eax,0xc
    7076cdd06180:	movabs r11,0x5b61e73e9ca0
    7076cdd0618a:	jmp    r11
    7076cdd0618d:	mov    eax,0x410660
    7076cdd06192:	mov    QWORD PTR [r12+0x100],rax
    7076cdd0619a:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd061a2:	add    rsp,0x150
    7076cdd061a9:	mov    eax,0xc
    7076cdd061ae:	movabs r11,0x5b61e73e9ca0
    7076cdd061b8:	jmp    r11
    7076cdd061bb:	mov    eax,0x41066c
    7076cdd061c0:	mov    QWORD PTR [r12+0x100],rax
    7076cdd061c8:	push   rdx
    7076cdd061c9:	push   rsi
    7076cdd061ca:	push   r10
    7076cdd061cc:	push   r11
    7076cdd061ce:	mov    r11,rax
    7076cdd061d1:	lahf
    7076cdd061d2:	seto   al
    7076cdd061d5:	mov    WORD PTR [rsp+0x20],ax
    7076cdd061da:	mov    rax,r11
    7076cdd061dd:	mov    rdx,QWORD PTR [rsp+0x20]
    7076cdd061e2:	mov    r10d,edx
    7076cdd061e5:	and    r10d,0xc000
    7076cdd061ec:	shl    r10d,0x10
    7076cdd061f0:	mov    r11d,edx
    7076cdd061f3:	and    r11d,0x100
    7076cdd061fa:	shl    r11d,0x15
    7076cdd061fe:	or     r10d,r11d
    7076cdd06201:	and    edx,0x1
    7076cdd06204:	shl    edx,0x1c
    7076cdd06207:	or     r10d,edx
    7076cdd0620a:	btc    r10,0x1d
    7076cdd0620f:	mov    r11d,0xf0000000
    7076cdd06215:	and    r11,r10
    7076cdd06218:	movabs rsi,0xffffffff0fffffff
    7076cdd06222:	and    rbx,rsi
    7076cdd06225:	or     rbx,r11
    7076cdd06228:	pop    r11
    7076cdd0622a:	pop    r10
    7076cdd0622c:	pop    rsi
    7076cdd0622d:	pop    rdx
    7076cdd0622e:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd06236:	add    rsp,0x150
    7076cdd0623d:	mov    eax,0xc
    7076cdd06242:	movabs r11,0x5b61e73e9ca0
    7076cdd0624c:	jmp    r11
    7076cdd0624f:	mov    eax,0x410694
    7076cdd06254:	mov    QWORD PTR [r12+0x100],rax
    7076cdd0625c:	push   rdx
    7076cdd0625d:	push   rsi
    7076cdd0625e:	push   r10
    7076cdd06260:	push   r11
    7076cdd06262:	mov    r11,rax
    7076cdd06265:	lahf
    7076cdd06266:	seto   al
    7076cdd06269:	mov    WORD PTR [rsp+0x20],ax
    7076cdd0626e:	mov    rax,r11
    7076cdd06271:	mov    rdx,QWORD PTR [rsp+0x20]
    7076cdd06276:	mov    r10d,edx
    7076cdd06279:	and    r10d,0xc000
    7076cdd06280:	shl    r10d,0x10
    7076cdd06284:	mov    r11d,edx
    7076cdd06287:	and    r11d,0x100
    7076cdd0628e:	shl    r11d,0x15
    7076cdd06292:	or     r10d,r11d
    7076cdd06295:	and    edx,0x1
    7076cdd06298:	shl    edx,0x1c
    7076cdd0629b:	or     r10d,edx
    7076cdd0629e:	btc    r10,0x1d
    7076cdd062a3:	mov    r11d,0xf0000000
    7076cdd062a9:	and    r11,r10
    7076cdd062ac:	movabs rsi,0xffffffff0fffffff
    7076cdd062b6:	and    rbx,rsi
    7076cdd062b9:	or     rbx,r11
    7076cdd062bc:	pop    r11
    7076cdd062be:	pop    r10
    7076cdd062c0:	pop    rsi
    7076cdd062c1:	pop    rdx
    7076cdd062c2:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd062ca:	add    rsp,0x150
    7076cdd062d1:	mov    eax,0xc
    7076cdd062d6:	movabs r11,0x5b61e73e9ca0
    7076cdd062e0:	jmp    r11
    7076cdd062e3:	mov    eax,0x4106b8
    7076cdd062e8:	mov    QWORD PTR [r12+0x100],rax
    7076cdd062f0:	push   rdx
    7076cdd062f1:	push   rsi
    7076cdd062f2:	push   r10
    7076cdd062f4:	push   r11
    7076cdd062f6:	mov    rdx,QWORD PTR [rsp+0x20]
    7076cdd062fb:	mov    r10d,edx
    7076cdd062fe:	and    r10d,0xc000
    7076cdd06305:	shl    r10d,0x10
    7076cdd06309:	mov    r11d,edx
    7076cdd0630c:	and    r11d,0x100
    7076cdd06313:	shl    r11d,0x15
    7076cdd06317:	or     r10d,r11d
    7076cdd0631a:	and    edx,0x1
    7076cdd0631d:	shl    edx,0x1c
    7076cdd06320:	or     r10d,edx
    7076cdd06323:	btc    r10,0x1d
    7076cdd06328:	mov    r11d,0xf0000000
    7076cdd0632e:	and    r11,r10
    7076cdd06331:	movabs rsi,0xffffffff0fffffff
    7076cdd0633b:	and    rbx,rsi
    7076cdd0633e:	or     rbx,r11
    7076cdd06341:	pop    r11
    7076cdd06343:	pop    r10
    7076cdd06345:	pop    rsi
    7076cdd06346:	pop    rdx
    7076cdd06347:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd0634f:	add    rsp,0x150
    7076cdd06356:	mov    eax,0xc
    7076cdd0635b:	movabs r11,0x5b61e73e9ca0
    7076cdd06365:	jmp    r11
    7076cdd06368:	nop    DWORD PTR [rax+rax*1+0x0]
    7076cdd06370:	sub    rsp,0x150
    7076cdd06377:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd0637f:	mov    QWORD PTR [rsp],r11
    7076cdd06383:	cmp    DWORD PTR [r12+0x310],0x0
    7076cdd0638c:	je     0x7076cdd06417
    7076cdd06392:	push   rdx
    7076cdd06393:	push   rsi
    7076cdd06394:	push   r10
    7076cdd06396:	push   r11
    7076cdd06398:	mov    rdx,QWORD PTR [rsp+0x20]
    7076cdd0639d:	mov    r10d,edx
    7076cdd063a0:	and    r10d,0xc000
    7076cdd063a7:	shl    r10d,0x10
    7076cdd063ab:	mov    r11d,edx
    7076cdd063ae:	and    r11d,0x100
    7076cdd063b5:	shl    r11d,0x15
    7076cdd063b9:	or     r10d,r11d
    7076cdd063bc:	and    edx,0x1
    7076cdd063bf:	shl    edx,0x1c
    7076cdd063c2:	or     r10d,edx
    7076cdd063c5:	btc    r10,0x1d
    7076cdd063ca:	mov    r11d,0xf0000000
    7076cdd063d0:	and    r11,r10
    7076cdd063d3:	movabs rsi,0xffffffff0fffffff
    7076cdd063dd:	and    rbx,rsi
    7076cdd063e0:	or     rbx,r11
    7076cdd063e3:	pop    r11
    7076cdd063e5:	pop    r10
    7076cdd063e7:	pop    rsi
    7076cdd063e8:	pop    rdx
    7076cdd063e9:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd063f1:	mov    eax,0x4103f4
    7076cdd063f6:	mov    QWORD PTR [r12+0x100],rax
    7076cdd063fe:	add    rsp,0x150
    7076cdd06405:	mov    eax,0x3
    7076cdd0640a:	movabs r11,0x5b61e73e9ca0
    7076cdd06414:	jmp    r11
    7076cdd06417:	jmp    0x7076cdd0225d
    7076cdd0641c:	nop    DWORD PTR [rax+0x0]
    7076cdd06420:	sub    rsp,0x150
    7076cdd06427:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd0642f:	mov    QWORD PTR [rsp],r11
    7076cdd06433:	cmp    DWORD PTR [r12+0x310],0x0
    7076cdd0643c:	je     0x7076cdd064c7
    7076cdd06442:	push   rdx
    7076cdd06443:	push   rsi
    7076cdd06444:	push   r10
    7076cdd06446:	push   r11
    7076cdd06448:	mov    rdx,QWORD PTR [rsp+0x20]
    7076cdd0644d:	mov    r10d,edx
    7076cdd06450:	and    r10d,0xc000
    7076cdd06457:	shl    r10d,0x10
    7076cdd0645b:	mov    r11d,edx
    7076cdd0645e:	and    r11d,0x100
    7076cdd06465:	shl    r11d,0x15
    7076cdd06469:	or     r10d,r11d
    7076cdd0646c:	and    edx,0x1
    7076cdd0646f:	shl    edx,0x1c
    7076cdd06472:	or     r10d,edx
    7076cdd06475:	btc    r10,0x1d
    7076cdd0647a:	mov    r11d,0xf0000000
    7076cdd06480:	and    r11,r10
    7076cdd06483:	movabs rsi,0xffffffff0fffffff
    7076cdd0648d:	and    rbx,rsi
    7076cdd06490:	or     rbx,r11
    7076cdd06493:	pop    r11
    7076cdd06495:	pop    r10
    7076cdd06497:	pop    rsi
    7076cdd06498:	pop    rdx
    7076cdd06499:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd064a1:	mov    eax,0x410440
    7076cdd064a6:	mov    QWORD PTR [r12+0x100],rax
    7076cdd064ae:	add    rsp,0x150
    7076cdd064b5:	mov    eax,0x3
    7076cdd064ba:	movabs r11,0x5b61e73e9ca0
    7076cdd064c4:	jmp    r11
    7076cdd064c7:	mov    r11,rax
    7076cdd064ca:	movzx  eax,WORD PTR [rsp]
    7076cdd064ce:	add    al,0x7f
    7076cdd064d0:	sahf
    7076cdd064d1:	mov    rax,r11
    7076cdd064d4:	jmp    0x7076cdd023d4
    7076cdd064d9:	nop    DWORD PTR [rax+0x0]
    7076cdd064e0:	sub    rsp,0x150
    7076cdd064e7:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd064ef:	mov    QWORD PTR [rsp],r11
    7076cdd064f3:	cmp    DWORD PTR [r12+0x310],0x0
    7076cdd064fc:	je     0x7076cdd06587
    7076cdd06502:	push   rdx
    7076cdd06503:	push   rsi
    7076cdd06504:	push   r10
    7076cdd06506:	push   r11
    7076cdd06508:	mov    rdx,QWORD PTR [rsp+0x20]
    7076cdd0650d:	mov    r10d,edx
    7076cdd06510:	and    r10d,0xc000
    7076cdd06517:	shl    r10d,0x10
    7076cdd0651b:	mov    r11d,edx
    7076cdd0651e:	and    r11d,0x100
    7076cdd06525:	shl    r11d,0x15
    7076cdd06529:	or     r10d,r11d
    7076cdd0652c:	and    edx,0x1
    7076cdd0652f:	shl    edx,0x1c
    7076cdd06532:	or     r10d,edx
    7076cdd06535:	btc    r10,0x1d
    7076cdd0653a:	mov    r11d,0xf0000000
    7076cdd06540:	and    r11,r10
    7076cdd06543:	movabs rsi,0xffffffff0fffffff
    7076cdd0654d:	and    rbx,rsi
    7076cdd06550:	or     rbx,r11
    7076cdd06553:	pop    r11
    7076cdd06555:	pop    r10
    7076cdd06557:	pop    rsi
    7076cdd06558:	pop    rdx
    7076cdd06559:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd06561:	mov    eax,0x410480
    7076cdd06566:	mov    QWORD PTR [r12+0x100],rax
    7076cdd0656e:	add    rsp,0x150
    7076cdd06575:	mov    eax,0x3
    7076cdd0657a:	movabs r11,0x5b61e73e9ca0
    7076cdd06584:	jmp    r11
    7076cdd06587:	jmp    0x7076cdd02822
    7076cdd0658c:	nop    DWORD PTR [rax+0x0]
    7076cdd06590:	sub    rsp,0x150
    7076cdd06597:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd0659f:	mov    QWORD PTR [rsp],r11
    7076cdd065a3:	cmp    DWORD PTR [r12+0x310],0x0
    7076cdd065ac:	je     0x7076cdd06637
    7076cdd065b2:	push   rdx
    7076cdd065b3:	push   rsi
    7076cdd065b4:	push   r10
    7076cdd065b6:	push   r11
    7076cdd065b8:	mov    rdx,QWORD PTR [rsp+0x20]
    7076cdd065bd:	mov    r10d,edx
    7076cdd065c0:	and    r10d,0xc000
    7076cdd065c7:	shl    r10d,0x10
    7076cdd065cb:	mov    r11d,edx
    7076cdd065ce:	and    r11d,0x100
    7076cdd065d5:	shl    r11d,0x15
    7076cdd065d9:	or     r10d,r11d
    7076cdd065dc:	and    edx,0x1
    7076cdd065df:	shl    edx,0x1c
    7076cdd065e2:	or     r10d,edx
    7076cdd065e5:	btc    r10,0x1d
    7076cdd065ea:	mov    r11d,0xf0000000
    7076cdd065f0:	and    r11,r10
    7076cdd065f3:	movabs rsi,0xffffffff0fffffff
    7076cdd065fd:	and    rbx,rsi
    7076cdd06600:	or     rbx,r11
    7076cdd06603:	pop    r11
    7076cdd06605:	pop    r10
    7076cdd06607:	pop    rsi
    7076cdd06608:	pop    rdx
    7076cdd06609:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd06611:	mov    eax,0x4104ec
    7076cdd06616:	mov    QWORD PTR [r12+0x100],rax
    7076cdd0661e:	add    rsp,0x150
    7076cdd06625:	mov    eax,0x3
    7076cdd0662a:	movabs r11,0x5b61e73e9ca0
    7076cdd06634:	jmp    r11
    7076cdd06637:	mov    r11,rax
    7076cdd0663a:	movzx  eax,WORD PTR [rsp]
    7076cdd0663e:	add    al,0x7f
    7076cdd06640:	sahf
    7076cdd06641:	mov    rax,r11
    7076cdd06644:	jmp    0x7076cdd02be4
    7076cdd06649:	nop    DWORD PTR [rax+0x0]
    7076cdd06650:	sub    rsp,0x150
    7076cdd06657:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd0665f:	mov    QWORD PTR [rsp],r11
    7076cdd06663:	cmp    DWORD PTR [r12+0x310],0x0
    7076cdd0666c:	je     0x7076cdd066f7
    7076cdd06672:	push   rdx
    7076cdd06673:	push   rsi
    7076cdd06674:	push   r10
    7076cdd06676:	push   r11
    7076cdd06678:	mov    rdx,QWORD PTR [rsp+0x20]
    7076cdd0667d:	mov    r10d,edx
    7076cdd06680:	and    r10d,0xc000
    7076cdd06687:	shl    r10d,0x10
    7076cdd0668b:	mov    r11d,edx
    7076cdd0668e:	and    r11d,0x100
    7076cdd06695:	shl    r11d,0x15
    7076cdd06699:	or     r10d,r11d
    7076cdd0669c:	and    edx,0x1
    7076cdd0669f:	shl    edx,0x1c
    7076cdd066a2:	or     r10d,edx
    7076cdd066a5:	btc    r10,0x1d
    7076cdd066aa:	mov    r11d,0xf0000000
    7076cdd066b0:	and    r11,r10
    7076cdd066b3:	movabs rsi,0xffffffff0fffffff
    7076cdd066bd:	and    rbx,rsi
    7076cdd066c0:	or     rbx,r11
    7076cdd066c3:	pop    r11
    7076cdd066c5:	pop    r10
    7076cdd066c7:	pop    rsi
    7076cdd066c8:	pop    rdx
    7076cdd066c9:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd066d1:	mov    eax,0x4104f0
    7076cdd066d6:	mov    QWORD PTR [r12+0x100],rax
    7076cdd066de:	add    rsp,0x150
    7076cdd066e5:	mov    eax,0x3
    7076cdd066ea:	movabs r11,0x5b61e73e9ca0
    7076cdd066f4:	jmp    r11
    7076cdd066f7:	jmp    0x7076cdd02c02
    7076cdd066fc:	nop    DWORD PTR [rax+0x0]
    7076cdd06700:	sub    rsp,0x150
    7076cdd06707:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd0670f:	mov    QWORD PTR [rsp],r11
    7076cdd06713:	cmp    DWORD PTR [r12+0x310],0x0
    7076cdd0671c:	je     0x7076cdd067a7
    7076cdd06722:	push   rdx
    7076cdd06723:	push   rsi
    7076cdd06724:	push   r10
    7076cdd06726:	push   r11
    7076cdd06728:	mov    rdx,QWORD PTR [rsp+0x20]
    7076cdd0672d:	mov    r10d,edx
    7076cdd06730:	and    r10d,0xc000
    7076cdd06737:	shl    r10d,0x10
    7076cdd0673b:	mov    r11d,edx
    7076cdd0673e:	and    r11d,0x100
    7076cdd06745:	shl    r11d,0x15
    7076cdd06749:	or     r10d,r11d
    7076cdd0674c:	and    edx,0x1
    7076cdd0674f:	shl    edx,0x1c
    7076cdd06752:	or     r10d,edx
    7076cdd06755:	btc    r10,0x1d
    7076cdd0675a:	mov    r11d,0xf0000000
    7076cdd06760:	and    r11,r10
    7076cdd06763:	movabs rsi,0xffffffff0fffffff
    7076cdd0676d:	and    rbx,rsi
    7076cdd06770:	or     rbx,r11
    7076cdd06773:	pop    r11
    7076cdd06775:	pop    r10
    7076cdd06777:	pop    rsi
    7076cdd06778:	pop    rdx
    7076cdd06779:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd06781:	mov    eax,0x410664
    7076cdd06786:	mov    QWORD PTR [r12+0x100],rax
    7076cdd0678e:	add    rsp,0x150
    7076cdd06795:	mov    eax,0x3
    7076cdd0679a:	movabs r11,0x5b61e73e9ca0
    7076cdd067a4:	jmp    r11
    7076cdd067a7:	jmp    0x7076cdd0472f
    7076cdd067ac:	nop    DWORD PTR [rax+0x0]
    7076cdd067b0:	sub    rsp,0x150
    7076cdd067b7:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd067bf:	mov    QWORD PTR [rsp],r11
    7076cdd067c3:	cmp    DWORD PTR [r12+0x310],0x0
    7076cdd067cc:	je     0x7076cdd06857
    7076cdd067d2:	push   rdx
    7076cdd067d3:	push   rsi
    7076cdd067d4:	push   r10
    7076cdd067d6:	push   r11
    7076cdd067d8:	mov    rdx,QWORD PTR [rsp+0x20]
    7076cdd067dd:	mov    r10d,edx
    7076cdd067e0:	and    r10d,0xc000
    7076cdd067e7:	shl    r10d,0x10
    7076cdd067eb:	mov    r11d,edx
    7076cdd067ee:	and    r11d,0x100
    7076cdd067f5:	shl    r11d,0x15
    7076cdd067f9:	or     r10d,r11d
    7076cdd067fc:	and    edx,0x1
    7076cdd067ff:	shl    edx,0x1c
    7076cdd06802:	or     r10d,edx
    7076cdd06805:	btc    r10,0x1d
    7076cdd0680a:	mov    r11d,0xf0000000
    7076cdd06810:	and    r11,r10
    7076cdd06813:	movabs rsi,0xffffffff0fffffff
    7076cdd0681d:	and    rbx,rsi
    7076cdd06820:	or     rbx,r11
    7076cdd06823:	pop    r11
    7076cdd06825:	pop    r10
    7076cdd06827:	pop    rsi
    7076cdd06828:	pop    rdx
    7076cdd06829:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd06831:	mov    eax,0x410670
    7076cdd06836:	mov    QWORD PTR [r12+0x100],rax
    7076cdd0683e:	add    rsp,0x150
    7076cdd06845:	mov    eax,0x3
    7076cdd0684a:	movabs r11,0x5b61e73e9ca0
    7076cdd06854:	jmp    r11
    7076cdd06857:	jmp    0x7076cdd0476c
    7076cdd0685c:	nop    DWORD PTR [rax+0x0]
    7076cdd06860:	sub    rsp,0x150
    7076cdd06867:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd0686f:	mov    QWORD PTR [rsp],r11
    7076cdd06873:	cmp    DWORD PTR [r12+0x310],0x0
    7076cdd0687c:	je     0x7076cdd06907
    7076cdd06882:	push   rdx
    7076cdd06883:	push   rsi
    7076cdd06884:	push   r10
    7076cdd06886:	push   r11
    7076cdd06888:	mov    rdx,QWORD PTR [rsp+0x20]
    7076cdd0688d:	mov    r10d,edx
    7076cdd06890:	and    r10d,0xc000
    7076cdd06897:	shl    r10d,0x10
    7076cdd0689b:	mov    r11d,edx
    7076cdd0689e:	and    r11d,0x100
    7076cdd068a5:	shl    r11d,0x15
    7076cdd068a9:	or     r10d,r11d
    7076cdd068ac:	and    edx,0x1
    7076cdd068af:	shl    edx,0x1c
    7076cdd068b2:	or     r10d,edx
    7076cdd068b5:	btc    r10,0x1d
    7076cdd068ba:	mov    r11d,0xf0000000
    7076cdd068c0:	and    r11,r10
    7076cdd068c3:	movabs rsi,0xffffffff0fffffff
    7076cdd068cd:	and    rbx,rsi
    7076cdd068d0:	or     rbx,r11
    7076cdd068d3:	pop    r11
    7076cdd068d5:	pop    r10
    7076cdd068d7:	pop    rsi
    7076cdd068d8:	pop    rdx
    7076cdd068d9:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd068e1:	mov    eax,0x41067c
    7076cdd068e6:	mov    QWORD PTR [r12+0x100],rax
    7076cdd068ee:	add    rsp,0x150
    7076cdd068f5:	mov    eax,0x3
    7076cdd068fa:	movabs r11,0x5b61e73e9ca0
    7076cdd06904:	jmp    r11
    7076cdd06907:	jmp    0x7076cdd047a7
    7076cdd0690c:	nop    DWORD PTR [rax+0x0]
    7076cdd06910:	sub    rsp,0x150
    7076cdd06917:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd0691f:	mov    QWORD PTR [rsp],r11
    7076cdd06923:	cmp    DWORD PTR [r12+0x310],0x0
    7076cdd0692c:	je     0x7076cdd069b7
    7076cdd06932:	push   rdx
    7076cdd06933:	push   rsi
    7076cdd06934:	push   r10
    7076cdd06936:	push   r11
    7076cdd06938:	mov    rdx,QWORD PTR [rsp+0x20]
    7076cdd0693d:	mov    r10d,edx
    7076cdd06940:	and    r10d,0xc000
    7076cdd06947:	shl    r10d,0x10
    7076cdd0694b:	mov    r11d,edx
    7076cdd0694e:	and    r11d,0x100
    7076cdd06955:	shl    r11d,0x15
    7076cdd06959:	or     r10d,r11d
    7076cdd0695c:	and    edx,0x1
    7076cdd0695f:	shl    edx,0x1c
    7076cdd06962:	or     r10d,edx
    7076cdd06965:	btc    r10,0x1d
    7076cdd0696a:	mov    r11d,0xf0000000
    7076cdd06970:	and    r11,r10
    7076cdd06973:	movabs rsi,0xffffffff0fffffff
    7076cdd0697d:	and    rbx,rsi
    7076cdd06980:	or     rbx,r11
    7076cdd06983:	pop    r11
    7076cdd06985:	pop    r10
    7076cdd06987:	pop    rsi
    7076cdd06988:	pop    rdx
    7076cdd06989:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd06991:	mov    eax,0x410698
    7076cdd06996:	mov    QWORD PTR [r12+0x100],rax
    7076cdd0699e:	add    rsp,0x150
    7076cdd069a5:	mov    eax,0x3
    7076cdd069aa:	movabs r11,0x5b61e73e9ca0
    7076cdd069b4:	jmp    r11
    7076cdd069b7:	jmp    0x7076cdd04900
    7076cdd069bc:	nop    DWORD PTR [rax+0x0]
    7076cdd069c0:	sub    rsp,0x150
    7076cdd069c7:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd069cf:	mov    QWORD PTR [rsp],r11
    7076cdd069d3:	cmp    DWORD PTR [r12+0x310],0x0
    7076cdd069dc:	je     0x7076cdd06a67
    7076cdd069e2:	push   rdx
    7076cdd069e3:	push   rsi
    7076cdd069e4:	push   r10
    7076cdd069e6:	push   r11
    7076cdd069e8:	mov    rdx,QWORD PTR [rsp+0x20]
    7076cdd069ed:	mov    r10d,edx
    7076cdd069f0:	and    r10d,0xc000
    7076cdd069f7:	shl    r10d,0x10
    7076cdd069fb:	mov    r11d,edx
    7076cdd069fe:	and    r11d,0x100
    7076cdd06a05:	shl    r11d,0x15
    7076cdd06a09:	or     r10d,r11d
    7076cdd06a0c:	and    edx,0x1
    7076cdd06a0f:	shl    edx,0x1c
    7076cdd06a12:	or     r10d,edx
    7076cdd06a15:	btc    r10,0x1d
    7076cdd06a1a:	mov    r11d,0xf0000000
    7076cdd06a20:	and    r11,r10
    7076cdd06a23:	movabs rsi,0xffffffff0fffffff
    7076cdd06a2d:	and    rbx,rsi
    7076cdd06a30:	or     rbx,r11
    7076cdd06a33:	pop    r11
    7076cdd06a35:	pop    r10
    7076cdd06a37:	pop    rsi
    7076cdd06a38:	pop    rdx
    7076cdd06a39:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd06a41:	mov    eax,0x4103e0
    7076cdd06a46:	mov    QWORD PTR [r12+0x100],rax
    7076cdd06a4e:	add    rsp,0x150
    7076cdd06a55:	mov    eax,0x3
    7076cdd06a5a:	movabs r11,0x5b61e73e9ca0
    7076cdd06a64:	jmp    r11
    7076cdd06a67:	jmp    0x7076cdd04add
    7076cdd06a6c:	nop    DWORD PTR [rax+0x0]
    7076cdd06a70:	(bad)
    7076cdd06a71:	(bad)
    7076cdd06a72:	(bad)
    7076cdd06a73:	(bad)
    7076cdd06a74:	(bad)
    7076cdd06a75:	(bad)
    7076cdd06a76:	(bad)
    7076cdd06a77:	jg     0x7076cdd06a78
    7076cdd06a79:	(bad)
    7076cdd06a7a:	(bad)
    7076cdd06a7b:	(bad)
    7076cdd06a7c:	(bad)
    7076cdd06a7d:	(bad)
    7076cdd06a7e:	(bad)
    7076cdd06a7f:	jg     0x7076cdd06a81
    7076cdd06a81:	add    BYTE PTR [rax],al
    7076cdd06a83:	add    BYTE PTR [rax],al
    7076cdd06a85:	add    BYTE PTR [rax],dl
    7076cdd06a87:	add    BYTE PTR [rax],al
    7076cdd06a89:	add    BYTE PTR [rax],al
    7076cdd06a8b:	add    BYTE PTR [rax],al
    7076cdd06a8d:	add    BYTE PTR [rax],dl
	...
