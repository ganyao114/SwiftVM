
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/1/4.bin:     file format binary


Disassembly of section .data:

000072fde4f01080 <.data>:
    72fde4f01080:	sub    rsp,0x10
    72fde4f01084:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f0108c:	mov    QWORD PTR [rsp],r11
    72fde4f01090:	mov    r13,QWORD PTR [r12+0xf8]
    72fde4f01098:	add    r13,0x138
    72fde4f0109f:	mov    r14,QWORD PTR [r13+0x0]
    72fde4f010a3:	mov    QWORD PTR [r12+0x40],r14
    72fde4f010a8:	sub    r14,0x38
    72fde4f010ac:	mov    rcx,QWORD PTR [r12+0x380]
    72fde4f010b4:	jrcxz  0x72fde4f010bb
    72fde4f010b6:	jmp    0x72fde4f0118d
    72fde4f010bb:	jne    0x72fde4f010d4
    72fde4f010c1:	mov    r11,rax
    72fde4f010c4:	lahf
    72fde4f010c5:	seto   al
    72fde4f010c8:	mov    WORD PTR [rsp],ax
    72fde4f010cc:	mov    rax,r11
    72fde4f010cf:	jmp    0x72fde4f010e7
    72fde4f010d4:	mov    r11,rax
    72fde4f010d7:	lahf
    72fde4f010d8:	seto   al
    72fde4f010db:	mov    WORD PTR [rsp],ax
    72fde4f010df:	mov    rax,r11
    72fde4f010e2:	jmp    0x72fde4f0113d
    72fde4f010e7:	mov    r13d,0x4102d4
    72fde4f010ed:	mov    QWORD PTR [r12+0x100],r13
    72fde4f010f5:	mov    r11,QWORD PTR [rsp]
    72fde4f010f9:	mov    QWORD PTR [r12+0x398],r11
    72fde4f01101:	mov    edi,0x4102d4
    72fde4f01106:	mov    QWORD PTR [r12+0x100],rdi
    72fde4f0110e:	add    rsp,0x10
    72fde4f01112:	nop    WORD PTR [rax+rax*1+0x0]
    72fde4f01118:	jmp    QWORD PTR [rip+0x2]        # 0x72fde4f01120
    72fde4f0111e:	xchg   ax,ax
    72fde4f01120:	(bad)
    72fde4f01121:	adc    al,dh
    72fde4f01123:	in     al,0xfd
    72fde4f01125:	jb     0x72fde4f01127
    72fde4f01127:	add    BYTE PTR [rax],dh
    72fde4f01129:	adc    eax,esi
    72fde4f0112b:	in     al,0xfd
    72fde4f0112d:	jb     0x72fde4f0112f
    72fde4f0112f:	add    BYTE PTR [rcx-0x45],cl
    72fde4f01132:	rex or ebp,esi
    72fde4f01135:	sahf
    72fde4f01136:	int    0x5c
    72fde4f01138:	add    BYTE PTR [rax],al
    72fde4f0113a:	jmp    r11
    72fde4f0113d:	mov    r13d,0x4102b8
    72fde4f01143:	mov    QWORD PTR [r12+0x100],r13
    72fde4f0114b:	mov    r11,QWORD PTR [rsp]
    72fde4f0114f:	mov    QWORD PTR [r12+0x398],r11
    72fde4f01157:	mov    edi,0x4102b8
    72fde4f0115c:	mov    QWORD PTR [r12+0x100],rdi
    72fde4f01164:	add    rsp,0x10
    72fde4f01168:	jmp    QWORD PTR [rip+0x2]        # 0x72fde4f01170
    72fde4f0116e:	xchg   ax,ax
    72fde4f01170:	adc    al,sil
    72fde4f01173:	in     al,0xfd
    72fde4f01175:	jb     0x72fde4f01177
    72fde4f01177:	add    BYTE PTR [rax-0x21b0fef],al
    72fde4f0117d:	jb     0x72fde4f0117f
    72fde4f0117f:	add    BYTE PTR [rcx-0x45],cl
    72fde4f01182:	rex or ebp,esi
    72fde4f01185:	sahf
    72fde4f01186:	int    0x5c
    72fde4f01188:	add    BYTE PTR [rax],al
    72fde4f0118a:	jmp    r11
    72fde4f0118d:	mov    eax,0x4102d0
    72fde4f01192:	mov    QWORD PTR [r12+0x100],rax
    72fde4f0119a:	push   rdx
    72fde4f0119b:	push   rsi
    72fde4f0119c:	push   r10
    72fde4f0119e:	push   r11
    72fde4f011a0:	mov    r11,rax
    72fde4f011a3:	lahf
    72fde4f011a4:	seto   al
    72fde4f011a7:	mov    WORD PTR [rsp+0x20],ax
    72fde4f011ac:	mov    rax,r11
    72fde4f011af:	mov    rdx,QWORD PTR [rsp+0x20]
    72fde4f011b4:	mov    r10d,edx
    72fde4f011b7:	and    r10d,0xc000
    72fde4f011be:	shl    r10d,0x10
    72fde4f011c2:	mov    r11d,edx
    72fde4f011c5:	and    r11d,0x100
    72fde4f011cc:	shl    r11d,0x15
    72fde4f011d0:	or     r10d,r11d
    72fde4f011d3:	and    edx,0x1
    72fde4f011d6:	shl    edx,0x1c
    72fde4f011d9:	or     r10d,edx
    72fde4f011dc:	btc    r10,0x1d
    72fde4f011e1:	mov    r11d,0xf0000000
    72fde4f011e7:	and    r11,r10
    72fde4f011ea:	movabs rsi,0xffffffff0fffffff
    72fde4f011f4:	and    rbx,rsi
    72fde4f011f7:	or     rbx,r11
    72fde4f011fa:	pop    r11
    72fde4f011fc:	pop    r10
    72fde4f011fe:	pop    rsi
    72fde4f011ff:	pop    rdx
    72fde4f01200:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f01208:	add    rsp,0x10
    72fde4f0120c:	mov    eax,0xc
    72fde4f01211:	movabs r11,0x5ccd9ef50ca0
    72fde4f0121b:	jmp    r11
    72fde4f0121e:	nop
    72fde4f0121f:	nop
