
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/1/8.bin:     file format binary


Disassembly of section .data:

000072fde4f02160 <.data>:
    72fde4f02160:	sub    rsp,0x150
    72fde4f02167:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f0216f:	mov    QWORD PTR [rsp],r11
    72fde4f02173:	cmp    DWORD PTR [r12+0x310],0x0
    72fde4f0217c:	je     0x72fde4f02207
    72fde4f02182:	push   rdx
    72fde4f02183:	push   rsi
    72fde4f02184:	push   r10
    72fde4f02186:	push   r11
    72fde4f02188:	mov    rdx,QWORD PTR [rsp+0x20]
    72fde4f0218d:	mov    r10d,edx
    72fde4f02190:	and    r10d,0xc000
    72fde4f02197:	shl    r10d,0x10
    72fde4f0219b:	mov    r11d,edx
    72fde4f0219e:	and    r11d,0x100
    72fde4f021a5:	shl    r11d,0x15
    72fde4f021a9:	or     r10d,r11d
    72fde4f021ac:	and    edx,0x1
    72fde4f021af:	shl    edx,0x1c
    72fde4f021b2:	or     r10d,edx
    72fde4f021b5:	btc    r10,0x1d
    72fde4f021ba:	mov    r11d,0xf0000000
    72fde4f021c0:	and    r11,r10
    72fde4f021c3:	movabs rsi,0xffffffff0fffffff
    72fde4f021cd:	and    rbx,rsi
    72fde4f021d0:	or     rbx,r11
    72fde4f021d3:	pop    r11
    72fde4f021d5:	pop    r10
    72fde4f021d7:	pop    rsi
    72fde4f021d8:	pop    rdx
    72fde4f021d9:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f021e1:	mov    eax,0x4103e8
    72fde4f021e6:	mov    QWORD PTR [r12+0x100],rax
    72fde4f021ee:	add    rsp,0x150
    72fde4f021f5:	mov    eax,0x3
    72fde4f021fa:	movabs r11,0x5ccd9ef50ca0
    72fde4f02204:	jmp    r11
    72fde4f02207:	mov    r13d,DWORD PTR [r12+0x98]
    72fde4f0220f:	add    r13d,0x1
    72fde4f02213:	mov    QWORD PTR [r12+0x98],r13
    72fde4f0221b:	sub    r13d,0x10000
    72fde4f02222:	mov    rcx,QWORD PTR [r12+0x380]
    72fde4f0222a:	jrcxz  0x72fde4f02231
    72fde4f0222c:	jmp    0x72fde4f06065
    72fde4f02231:	jne    0x72fde4f0224a
    72fde4f02237:	mov    r11,rax
    72fde4f0223a:	lahf
    72fde4f0223b:	seto   al
    72fde4f0223e:	mov    WORD PTR [rsp],ax
    72fde4f02242:	mov    rax,r11
    72fde4f02245:	jmp    0x72fde4f0225d
    72fde4f0224a:	mov    r11,rax
    72fde4f0224d:	lahf
    72fde4f0224e:	seto   al
    72fde4f02251:	mov    WORD PTR [rsp],ax
    72fde4f02255:	mov    rax,r11
    72fde4f02258:	jmp    0x72fde4f04add
    72fde4f0225d:	mov    r13d,0x420000
    72fde4f02263:	mov    QWORD PTR [r12+0x40],r13
    72fde4f02268:	movabs r13,0x100000001
    72fde4f02272:	mov    r14d,0x0
    72fde4f02278:	mov    QWORD PTR [r12+0x110],r13
    72fde4f02280:	mov    QWORD PTR [r12+0x118],r14
    72fde4f02288:	movabs r13,0x3fa0000000000000
    72fde4f02292:	mov    QWORD PTR [r12+0x50],r13
    72fde4f02297:	mov    r13d,0x420aa0
    72fde4f0229d:	mov    r14,QWORD PTR [r13+0x0]
    72fde4f022a1:	mov    r13d,0x0
    72fde4f022a7:	mov    QWORD PTR [r12+0x120],r14
    72fde4f022af:	mov    QWORD PTR [r12+0x128],r13
    72fde4f022b7:	movabs r13,0x4100000041
    72fde4f022c1:	mov    r14d,0x0
    72fde4f022c7:	mov    QWORD PTR [r12+0x140],r13
    72fde4f022cf:	mov    QWORD PTR [r12+0x148],r14
    72fde4f022d7:	movabs r13,0x3fc0000000000000
    72fde4f022e1:	movabs r14,0x3fc0000000000000
    72fde4f022eb:	mov    QWORD PTR [r12+0x150],r13
    72fde4f022f3:	mov    QWORD PTR [r12+0x158],r14
    72fde4f022fb:	movabs r13,0x200000002
    72fde4f02305:	mov    r14d,0x0
    72fde4f0230b:	mov    QWORD PTR [r12+0x160],r13
    72fde4f02313:	mov    QWORD PTR [r12+0x168],r14
    72fde4f0231b:	movabs r13,0x3fa0000000000000
    72fde4f02325:	mov    QWORD PTR [r12+0x130],r13
    72fde4f0232d:	mov    QWORD PTR [r12+0x138],r13
    72fde4f02335:	mov    r13d,0x2
    72fde4f0233b:	mov    QWORD PTR [r12+0x170],r13
    72fde4f02343:	mov    QWORD PTR [r12+0x178],r13
    72fde4f0234b:	mov    r13d,0x420000
    72fde4f02351:	mov    QWORD PTR [r12+0x40],r13
    72fde4f02356:	mov    r13d,0x430000
    72fde4f0235c:	mov    QWORD PTR [r12+0x50],r13
    72fde4f02361:	mov    r13d,0x4209d0
    72fde4f02367:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    72fde4f0236d:	movdqu XMMWORD PTR [r12+0x180],xmm2
    72fde4f02377:	mov    r13d,0x0
    72fde4f0237d:	mov    QWORD PTR [r12+0x48],r13
    72fde4f02382:	mov    r13d,0x431000
    72fde4f02388:	add    r13,0xd90
    72fde4f0238f:	mov    QWORD PTR [r12+0x40],r13
    72fde4f02394:	mov    r13d,0x430c48
    72fde4f0239a:	mov    r14d,DWORD PTR [r12]
    72fde4f0239e:	mov    DWORD PTR [r13+0x0],r14d
    72fde4f023a2:	mov    r13d,0x0
    72fde4f023a8:	mov    DWORD PTR [r12+0x32c],r13d
    72fde4f023b0:	mov    r13d,0x431000
    72fde4f023b6:	add    r13,0xf90
    72fde4f023bd:	mov    QWORD PTR [r12+0x50],r13
    72fde4f023c2:	mov    r11,rax
    72fde4f023c5:	movzx  eax,WORD PTR [rsp]
    72fde4f023c9:	add    al,0x7f
    72fde4f023cb:	sahf
    72fde4f023cc:	mov    rax,r11
    72fde4f023cf:	jmp    0x72fde4f023d4
    72fde4f023d4:	mov    r13,QWORD PTR [r12+0x180]
    72fde4f023dc:	mov    r14,QWORD PTR [r12+0x188]
    72fde4f023e4:	mov    r15d,0x0
    72fde4f023ea:	mov    r11,rax
    72fde4f023ed:	lahf
    72fde4f023ee:	seto   al
    72fde4f023f1:	mov    WORD PTR [rsp],ax
    72fde4f023f5:	mov    rax,r11
    72fde4f023f8:	mov    ecx,0xffffffff
    72fde4f023fd:	and    r13,rcx
    72fde4f02400:	mov    rbp,r15
    72fde4f02403:	or     rbp,r13
    72fde4f02406:	mov    ecx,0xffffffff
    72fde4f0240b:	and    r14,rcx
    72fde4f0240e:	shl    r14,0x20
    72fde4f02412:	or     rbp,r14
    72fde4f02415:	mov    QWORD PTR [r12+0x210],rbp
    72fde4f0241d:	mov    QWORD PTR [r12+0x218],r15
    72fde4f02425:	movdqu xmm2,XMMWORD PTR [r12+0x140]
    72fde4f0242f:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    72fde4f02439:	movdqa xmm1,xmm3
    72fde4f0243d:	psubd  xmm2,xmm1
    72fde4f02441:	movdqa xmm14,xmm2
    72fde4f02446:	movdqa xmm1,xmm14
    72fde4f0244b:	movq   rax,xmm1
    72fde4f02450:	mov    r13,rax
    72fde4f02453:	movdqu xmm2,XMMWORD PTR [r12+0x180]
    72fde4f0245d:	movdqu xmm4,XMMWORD PTR [r12+0x170]
    72fde4f02467:	movdqa xmm1,xmm4
    72fde4f0246b:	paddq  xmm2,xmm1
    72fde4f0246f:	movdqu XMMWORD PTR [r12+0x180],xmm2
    72fde4f02479:	movdqu xmm2,XMMWORD PTR [r12+0x160]
    72fde4f02483:	movdqa xmm1,xmm2
    72fde4f02487:	paddd  xmm3,xmm1
    72fde4f0248b:	movdqa xmm14,xmm3
    72fde4f02490:	movdqa xmm1,xmm14
    72fde4f02495:	movq   rax,xmm1
    72fde4f0249a:	mov    r14,rax
    72fde4f0249d:	mov    r15d,0x0
    72fde4f024a3:	mov    QWORD PTR [r12+0x120],r14
    72fde4f024ab:	mov    QWORD PTR [r12+0x128],r15
    72fde4f024b3:	mov    r14d,0x0
    72fde4f024b9:	mov    ecx,0xffffffff
    72fde4f024be:	mov    r15,r13
    72fde4f024c1:	and    r15,rcx
    72fde4f024c4:	mov    rbp,r14
    72fde4f024c7:	or     rbp,r15
    72fde4f024ca:	shr    r13,0x20
    72fde4f024ce:	mov    ecx,0xffffffff
    72fde4f024d3:	and    r13,rcx
    72fde4f024d6:	or     r14,r13
    72fde4f024d9:	mov    QWORD PTR [r12+0x220],rbp
    72fde4f024e1:	mov    QWORD PTR [r12+0x228],r14
    72fde4f024e9:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    72fde4f024f3:	movdqu xmm3,XMMWORD PTR [r12+0x110]
    72fde4f024fd:	movdqa xmm1,xmm3
    72fde4f02501:	paddd  xmm2,xmm1
    72fde4f02505:	movdqa xmm14,xmm2
    72fde4f0250a:	movdqa xmm1,xmm14
    72fde4f0250f:	movq   rax,xmm1
    72fde4f02514:	mov    r13,rax
    72fde4f02517:	mov    r14d,0x0
    72fde4f0251d:	mov    QWORD PTR [r12+0x210],r13
    72fde4f02525:	mov    QWORD PTR [r12+0x218],r14
    72fde4f0252d:	lea    r13,[r12]
    72fde4f02531:	movabs r14,0xb6e61da31
    72fde4f0253b:	mov    r15d,0x410458
    72fde4f02541:	mov    rdx,QWORD PTR [rsp]
    72fde4f02545:	mov    r10d,edx
    72fde4f02548:	and    r10d,0xc000
    72fde4f0254f:	shl    r10d,0x10
    72fde4f02553:	mov    r11d,edx
    72fde4f02556:	and    r11d,0x100
    72fde4f0255d:	shl    r11d,0x15
    72fde4f02561:	or     r10d,r11d
    72fde4f02564:	and    edx,0x1
    72fde4f02567:	shl    edx,0x1c
    72fde4f0256a:	or     r10d,edx
    72fde4f0256d:	btc    r10,0x1d
    72fde4f02572:	mov    r11d,0xf0000000
    72fde4f02578:	and    r11,r10
    72fde4f0257b:	movabs rsi,0xffffffff0fffffff
    72fde4f02585:	and    rbx,rsi
    72fde4f02588:	or     rbx,r11
    72fde4f0258b:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f02597:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f0259f:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f025a5:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f025aa:	test   r10d,0x3f
    72fde4f025b1:	je     0x72fde4f025d6
    72fde4f025b7:	mov    r11d,r10d
    72fde4f025ba:	shr    r10d,1
    72fde4f025bd:	and    r10d,0x1e
    72fde4f025c1:	and    r11d,0x1
    72fde4f025c5:	or     r10d,r11d
    72fde4f025c8:	or     DWORD PTR [r12+0x314],r10d
    72fde4f025d0:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f025d6:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f025dc:	movabs r11,0x5ccd9edb25e0
    72fde4f025e6:	mov    rdi,r13
    72fde4f025e9:	mov    rsi,r14
    72fde4f025ec:	mov    rdx,r15
    72fde4f025ef:	call   r11
    72fde4f025f2:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f025f8:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f02600:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f0260c:	mov    rbp,rax
    72fde4f0260f:	mov    r13,QWORD PTR [r12+0x210]
    72fde4f02617:	mov    r14d,0x0
    72fde4f0261d:	mov    ecx,0xffffffff
    72fde4f02622:	mov    r15,r13
    72fde4f02625:	and    r15,rcx
    72fde4f02628:	mov    rbp,r14
    72fde4f0262b:	or     rbp,r15
    72fde4f0262e:	shr    r13,0x20
    72fde4f02632:	mov    ecx,0xffffffff
    72fde4f02637:	and    r13,rcx
    72fde4f0263a:	or     r14,r13
    72fde4f0263d:	mov    QWORD PTR [r12+0x210],rbp
    72fde4f02645:	mov    QWORD PTR [r12+0x218],r14
    72fde4f0264d:	lea    r13,[r12]
    72fde4f02651:	movabs r14,0xb6e61da10
    72fde4f0265b:	mov    r15d,0x410460
    72fde4f02661:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f0266d:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f02675:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f0267b:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f02680:	test   r10d,0x3f
    72fde4f02687:	je     0x72fde4f026ac
    72fde4f0268d:	mov    r11d,r10d
    72fde4f02690:	shr    r10d,1
    72fde4f02693:	and    r10d,0x1e
    72fde4f02697:	and    r11d,0x1
    72fde4f0269b:	or     r10d,r11d
    72fde4f0269e:	or     DWORD PTR [r12+0x314],r10d
    72fde4f026a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f026ac:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f026b2:	movabs r11,0x5ccd9edb25e0
    72fde4f026bc:	mov    rdi,r13
    72fde4f026bf:	mov    rsi,r14
    72fde4f026c2:	mov    rdx,r15
    72fde4f026c5:	call   r11
    72fde4f026c8:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f026ce:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f026d6:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f026e2:	mov    rbp,rax
    72fde4f026e5:	movdqu xmm2,XMMWORD PTR [r12+0x220]
    72fde4f026ef:	movdqu xmm3,XMMWORD PTR [r12+0x150]
    72fde4f026f9:	movdqa xmm0,xmm2
    72fde4f026fd:	movdqa xmm1,xmm3
    72fde4f02701:	mulpd  xmm0,xmm1
    72fde4f02705:	movdqa xmm14,xmm0
    72fde4f0270a:	movdqu xmm15,XMMWORD PTR [rip+0x435d]        # 0x72fde4f06a70
    72fde4f02713:	pand   xmm14,xmm15
    72fde4f02718:	movdqu xmm15,XMMWORD PTR [rip+0x435f]        # 0x72fde4f06a80
    72fde4f02721:	pcmpeqq xmm14,xmm15
    72fde4f02727:	movdqa xmm15,xmm0
    72fde4f0272c:	cmpunordpd xmm15,xmm0
    72fde4f02732:	por    xmm14,xmm15
    72fde4f02737:	pmovmskb ecx,xmm14
    72fde4f0273c:	jrcxz  0x72fde4f02743
    72fde4f0273e:	jmp    0x72fde4f04b55
    72fde4f02743:	movdqa xmm4,xmm0
    72fde4f02747:	movdqu XMMWORD PTR [r12+0x220],xmm4
    72fde4f02751:	mov    r13,QWORD PTR [r12+0x48]
    72fde4f02756:	mov    r14,QWORD PTR [r12+0x50]
    72fde4f0275b:	add    r14,r13
    72fde4f0275e:	movdqu XMMWORD PTR [r14],xmm4
    72fde4f02763:	mov    r14d,0x0
    72fde4f02769:	mov    DWORD PTR [r12+0x32c],r14d
    72fde4f02771:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    72fde4f0277b:	movdqu xmm3,XMMWORD PTR [r12+0x130]
    72fde4f02785:	movdqa xmm0,xmm2
    72fde4f02789:	movdqa xmm1,xmm3
    72fde4f0278d:	mulpd  xmm0,xmm1
    72fde4f02791:	movdqa xmm14,xmm0
    72fde4f02796:	movdqu xmm15,XMMWORD PTR [rip+0x42d1]        # 0x72fde4f06a70
    72fde4f0279f:	pand   xmm14,xmm15
    72fde4f027a4:	movdqu xmm15,XMMWORD PTR [rip+0x42d3]        # 0x72fde4f06a80
    72fde4f027ad:	pcmpeqq xmm14,xmm15
    72fde4f027b3:	movdqa xmm15,xmm0
    72fde4f027b8:	cmpunordpd xmm15,xmm0
    72fde4f027be:	por    xmm14,xmm15
    72fde4f027c3:	pmovmskb ecx,xmm14
    72fde4f027c8:	jrcxz  0x72fde4f027cf
    72fde4f027ca:	jmp    0x72fde4f04b79
    72fde4f027cf:	movdqa xmm4,xmm0
    72fde4f027d3:	movdqu XMMWORD PTR [r12+0x210],xmm4
    72fde4f027dd:	mov    r14,QWORD PTR [r12+0x40]
    72fde4f027e2:	add    r14,r13
    72fde4f027e5:	movdqu XMMWORD PTR [r14],xmm4
    72fde4f027ea:	add    r13,0x10
    72fde4f027ee:	mov    QWORD PTR [r12+0x48],r13
    72fde4f027f3:	sub    r13,0x200
    72fde4f027fa:	mov    rcx,QWORD PTR [r12+0x380]
    72fde4f02802:	jrcxz  0x72fde4f02809
    72fde4f02804:	jmp    0x72fde4f060f9
    72fde4f02809:	jne    0x72fde4f023d4
    72fde4f0280f:	mov    r11,rax
    72fde4f02812:	lahf
    72fde4f02813:	seto   al
    72fde4f02816:	mov    WORD PTR [rsp],ax
    72fde4f0281a:	mov    rax,r11
    72fde4f0281d:	jmp    0x72fde4f02822
    72fde4f02822:	mov    r13,QWORD PTR [r12+0x50]
    72fde4f02827:	mov    r14,r13
    72fde4f0282a:	add    r14,0x10
    72fde4f0282e:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    72fde4f02834:	movdqu xmm3,XMMWORD PTR [r14]
    72fde4f02839:	movdqu XMMWORD PTR [r12+0x110],xmm2
    72fde4f02843:	movdqu XMMWORD PTR [r12+0x250],xmm3
    72fde4f0284d:	mov    r14d,0x0
    72fde4f02853:	mov    QWORD PTR [r12+0x48],r14
    72fde4f02858:	mov    r14,r13
    72fde4f0285b:	add    r14,0x40
    72fde4f0285f:	mov    r15,r14
    72fde4f02862:	add    r15,0x10
    72fde4f02866:	movdqu xmm3,XMMWORD PTR [r14]
    72fde4f0286b:	movdqu xmm4,XMMWORD PTR [r15]
    72fde4f02870:	movdqu XMMWORD PTR [r12+0x210],xmm3
    72fde4f0287a:	movdqu XMMWORD PTR [r12+0x1c0],xmm4
    72fde4f02884:	mov    r14,r13
    72fde4f02887:	add    r14,0x80
    72fde4f0288e:	mov    r15,r14
    72fde4f02891:	add    r15,0x10
    72fde4f02895:	movdqu xmm3,XMMWORD PTR [r14]
    72fde4f0289a:	movdqu xmm4,XMMWORD PTR [r15]
    72fde4f0289f:	movdqu XMMWORD PTR [r12+0x260],xmm3
    72fde4f028a9:	movdqu XMMWORD PTR [r12+0x280],xmm4
    72fde4f028b3:	mov    r14,QWORD PTR [r12+0xf8]
    72fde4f028bb:	movdqu XMMWORD PTR [r14],xmm2
    72fde4f028c0:	mov    r15d,0x0
    72fde4f028c6:	mov    DWORD PTR [r12+0x32c],r15d
    72fde4f028ce:	mov    r15,r13
    72fde4f028d1:	add    r15,0x20
    72fde4f028d5:	mov    rbp,r15
    72fde4f028d8:	add    rbp,0x10
    72fde4f028dc:	movdqu xmm2,XMMWORD PTR [r15]
    72fde4f028e1:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    72fde4f028e6:	movdqu XMMWORD PTR [r12+0x170],xmm2
    72fde4f028f0:	movdqu XMMWORD PTR [r12+0x110],xmm3
    72fde4f028fa:	mov    r15,r13
    72fde4f028fd:	add    r15,0xc0
    72fde4f02904:	mov    rbp,r15
    72fde4f02907:	add    rbp,0x10
    72fde4f0290b:	movdqu xmm4,XMMWORD PTR [r15]
    72fde4f02910:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    72fde4f02915:	movdqu XMMWORD PTR [r12+0x180],xmm4
    72fde4f0291f:	movdqu XMMWORD PTR [r12+0x290],xmm5
    72fde4f02929:	mov    r15,r13
    72fde4f0292c:	add    r15,0x100
    72fde4f02933:	mov    rbp,r15
    72fde4f02936:	add    rbp,0x10
    72fde4f0293a:	movdqu xmm4,XMMWORD PTR [r15]
    72fde4f0293f:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    72fde4f02944:	movdqu XMMWORD PTR [r12+0x160],xmm4
    72fde4f0294e:	movdqu XMMWORD PTR [r12+0x2a0],xmm5
    72fde4f02958:	mov    r15,r13
    72fde4f0295b:	add    r15,0x140
    72fde4f02962:	mov    rbp,r15
    72fde4f02965:	add    rbp,0x10
    72fde4f02969:	movdqu xmm4,XMMWORD PTR [r15]
    72fde4f0296e:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    72fde4f02973:	movdqu XMMWORD PTR [r12+0x150],xmm4
    72fde4f0297d:	movdqu XMMWORD PTR [r12+0x2b0],xmm5
    72fde4f02987:	mov    r15,r14
    72fde4f0298a:	add    r15,0xb0
    72fde4f02991:	mov    rbp,r15
    72fde4f02994:	add    rbp,0x10
    72fde4f02998:	movdqu XMMWORD PTR [r15],xmm3
    72fde4f0299d:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    72fde4f029a2:	mov    r15,r13
    72fde4f029a5:	add    r15,0x180
    72fde4f029ac:	mov    rbp,r15
    72fde4f029af:	add    rbp,0x10
    72fde4f029b3:	movdqu xmm2,XMMWORD PTR [r15]
    72fde4f029b8:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    72fde4f029bd:	movdqu XMMWORD PTR [r12+0x2f0],xmm2
    72fde4f029c7:	movdqu XMMWORD PTR [r12+0x120],xmm3
    72fde4f029d1:	mov    r15,r13
    72fde4f029d4:	add    r15,0x1c0
    72fde4f029db:	mov    rbp,r15
    72fde4f029de:	add    rbp,0x10
    72fde4f029e2:	movdqu xmm5,XMMWORD PTR [r15]
    72fde4f029e7:	movdqu xmm6,XMMWORD PTR [rbp+0x0]
    72fde4f029ec:	movdqu XMMWORD PTR [r12+0x130],xmm5
    72fde4f029f6:	movdqu XMMWORD PTR [r12+0x140],xmm6
    72fde4f02a00:	mov    r15,r13
    72fde4f02a03:	add    r15,0x60
    72fde4f02a07:	mov    rbp,r15
    72fde4f02a0a:	add    rbp,0x10
    72fde4f02a0e:	movdqu xmm7,XMMWORD PTR [r15]
    72fde4f02a13:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    72fde4f02a19:	movdqu XMMWORD PTR [r12+0x2e0],xmm7
    72fde4f02a23:	movdqu XMMWORD PTR [r12+0x1f0],xmm8
    72fde4f02a2d:	mov    r15,r14
    72fde4f02a30:	add    r15,0x70
    72fde4f02a34:	mov    rbp,r15
    72fde4f02a37:	add    rbp,0x10
    72fde4f02a3b:	movdqu XMMWORD PTR [r15],xmm3
    72fde4f02a40:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    72fde4f02a45:	mov    r15,r13
    72fde4f02a48:	add    r15,0xa0
    72fde4f02a4f:	mov    rbp,r15
    72fde4f02a52:	add    rbp,0x10
    72fde4f02a56:	movdqu xmm2,XMMWORD PTR [r15]
    72fde4f02a5b:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    72fde4f02a60:	movdqu XMMWORD PTR [r12+0x2c0],xmm2
    72fde4f02a6a:	movdqu XMMWORD PTR [r12+0x1d0],xmm3
    72fde4f02a74:	mov    r15,r14
    72fde4f02a77:	add    r15,0x90
    72fde4f02a7e:	mov    rbp,r15
    72fde4f02a81:	add    rbp,0x10
    72fde4f02a85:	movdqu XMMWORD PTR [r15],xmm6
    72fde4f02a8a:	movdqu XMMWORD PTR [rbp+0x0],xmm5
    72fde4f02a8f:	mov    r15,r13
    72fde4f02a92:	add    r15,0xe0
    72fde4f02a99:	mov    rbp,r15
    72fde4f02a9c:	add    rbp,0x10
    72fde4f02aa0:	movdqu xmm2,XMMWORD PTR [r15]
    72fde4f02aa5:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    72fde4f02aaa:	movdqu XMMWORD PTR [r12+0x300],xmm2
    72fde4f02ab4:	movdqu XMMWORD PTR [r12+0x2d0],xmm3
    72fde4f02abe:	mov    r15,r13
    72fde4f02ac1:	add    r15,0x120
    72fde4f02ac8:	mov    rbp,r15
    72fde4f02acb:	add    rbp,0x10
    72fde4f02acf:	movdqu xmm2,XMMWORD PTR [r15]
    72fde4f02ad4:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    72fde4f02ad9:	movdqu XMMWORD PTR [r12+0x190],xmm2
    72fde4f02ae3:	movdqu XMMWORD PTR [r12+0x1e0],xmm3
    72fde4f02aed:	mov    r15,r13
    72fde4f02af0:	add    r15,0x160
    72fde4f02af7:	mov    rbp,r15
    72fde4f02afa:	add    rbp,0x10
    72fde4f02afe:	movdqu xmm2,XMMWORD PTR [r15]
    72fde4f02b03:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    72fde4f02b08:	movdqu XMMWORD PTR [r12+0x1a0],xmm2
    72fde4f02b12:	movdqu XMMWORD PTR [r12+0x1b0],xmm3
    72fde4f02b1c:	mov    r15,r13
    72fde4f02b1f:	add    r15,0x1a0
    72fde4f02b26:	mov    rbp,r15
    72fde4f02b29:	add    rbp,0x10
    72fde4f02b2d:	movdqu xmm5,XMMWORD PTR [r15]
    72fde4f02b32:	movdqu xmm6,XMMWORD PTR [rbp+0x0]
    72fde4f02b37:	movdqu XMMWORD PTR [r12+0x200],xmm5
    72fde4f02b41:	movdqu XMMWORD PTR [r12+0x170],xmm6
    72fde4f02b4b:	add    r13,0x1e0
    72fde4f02b52:	mov    r15,r13
    72fde4f02b55:	add    r15,0x10
    72fde4f02b59:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    72fde4f02b5f:	movdqu xmm7,XMMWORD PTR [r15]
    72fde4f02b64:	movdqu XMMWORD PTR [r12+0x110],xmm5
    72fde4f02b6e:	movdqu XMMWORD PTR [r12+0x270],xmm7
    72fde4f02b78:	mov    r13d,0x432000
    72fde4f02b7e:	add    r13,0x190
    72fde4f02b85:	mov    QWORD PTR [r12+0x50],r13
    72fde4f02b8a:	mov    r13,r14
    72fde4f02b8d:	add    r13,0x50
    72fde4f02b91:	mov    r15,r13
    72fde4f02b94:	add    r15,0x10
    72fde4f02b98:	movdqu XMMWORD PTR [r13+0x0],xmm2
    72fde4f02b9e:	movdqu XMMWORD PTR [r15],xmm4
    72fde4f02ba3:	mov    r13,r14
    72fde4f02ba6:	add    r13,0x40
    72fde4f02baa:	movdqu XMMWORD PTR [r13+0x0],xmm3
    72fde4f02bb0:	mov    r13,r14
    72fde4f02bb3:	add    r13,0x20
    72fde4f02bb7:	mov    r15,r13
    72fde4f02bba:	add    r15,0x10
    72fde4f02bbe:	movdqu XMMWORD PTR [r13+0x0],xmm5
    72fde4f02bc4:	movdqu XMMWORD PTR [r15],xmm6
    72fde4f02bc9:	add    r14,0x10
    72fde4f02bcd:	movdqu XMMWORD PTR [r14],xmm7
    72fde4f02bd2:	mov    r11,rax
    72fde4f02bd5:	movzx  eax,WORD PTR [rsp]
    72fde4f02bd9:	add    al,0x7f
    72fde4f02bdb:	sahf
    72fde4f02bdc:	mov    rax,r11
    72fde4f02bdf:	jmp    0x72fde4f02be4
    72fde4f02be4:	mov    r13d,0x0
    72fde4f02bea:	mov    QWORD PTR [r12+0x58],r13
    72fde4f02bef:	mov    r11,rax
    72fde4f02bf2:	lahf
    72fde4f02bf3:	seto   al
    72fde4f02bf6:	mov    WORD PTR [rsp],ax
    72fde4f02bfa:	mov    rax,r11
    72fde4f02bfd:	jmp    0x72fde4f02c02
    72fde4f02c02:	mov    r13,QWORD PTR [r12+0x58]
    72fde4f02c07:	mov    r14,QWORD PTR [r12+0x40]
    72fde4f02c0c:	add    r14,r13
    72fde4f02c0f:	mov    QWORD PTR [r12+0x60],r14
    72fde4f02c14:	mov    r15d,0x0
    72fde4f02c1a:	mov    ebp,0x0
    72fde4f02c1f:	mov    QWORD PTR [r12+0x110],r15
    72fde4f02c27:	mov    QWORD PTR [r12+0x118],rbp
    72fde4f02c2f:	mov    r15d,0x0
    72fde4f02c35:	mov    ebp,0x0
    72fde4f02c3a:	mov    QWORD PTR [r12+0x170],r15
    72fde4f02c42:	mov    QWORD PTR [r12+0x178],rbp
    72fde4f02c4a:	mov    r15,r14
    72fde4f02c4d:	add    r15,0x30
    72fde4f02c51:	mov    rbp,r15
    72fde4f02c54:	add    rbp,0x8
    72fde4f02c58:	mov    r8,QWORD PTR [r15]
    72fde4f02c5b:	mov    r15,QWORD PTR [rbp+0x0]
    72fde4f02c5f:	mov    ebp,0x0
    72fde4f02c64:	mov    QWORD PTR [r12+0x130],r8
    72fde4f02c6c:	mov    QWORD PTR [r12+0x138],rbp
    72fde4f02c74:	mov    ebp,0x0
    72fde4f02c79:	mov    QWORD PTR [r12+0x270],r15
    72fde4f02c81:	mov    QWORD PTR [r12+0x278],rbp
    72fde4f02c89:	movdqu xmm2,XMMWORD PTR [r12+0x160]
    72fde4f02c93:	movdqa xmm1,xmm2
    72fde4f02c97:	por    xmm2,xmm1
    72fde4f02c9b:	movdqu XMMWORD PTR [r12+0x1b0],xmm2
    72fde4f02ca5:	mov    r15,r14
    72fde4f02ca8:	add    r15,0x20
    72fde4f02cac:	mov    rbp,r15
    72fde4f02caf:	add    rbp,0x8
    72fde4f02cb3:	mov    r8,QWORD PTR [r15]
    72fde4f02cb6:	mov    r15,QWORD PTR [rbp+0x0]
    72fde4f02cba:	mov    ebp,0x0
    72fde4f02cbf:	mov    QWORD PTR [r12+0x150],r8
    72fde4f02cc7:	mov    QWORD PTR [r12+0x158],rbp
    72fde4f02ccf:	mov    ebp,0x0
    72fde4f02cd4:	mov    QWORD PTR [r12+0x140],r15
    72fde4f02cdc:	mov    QWORD PTR [r12+0x148],rbp
    72fde4f02ce4:	movdqu xmm2,XMMWORD PTR [r12+0x2d0]
    72fde4f02cee:	movdqa xmm1,xmm2
    72fde4f02cf2:	por    xmm2,xmm1
    72fde4f02cf6:	movdqu XMMWORD PTR [r12+0x1a0],xmm2
    72fde4f02d00:	movdqu xmm2,XMMWORD PTR [r12+0x300]
    72fde4f02d0a:	movdqa xmm1,xmm2
    72fde4f02d0e:	por    xmm2,xmm1
    72fde4f02d12:	movdqu XMMWORD PTR [r12+0x2f0],xmm2
    72fde4f02d1c:	movdqu xmm2,XMMWORD PTR [r12+0x2b0]
    72fde4f02d26:	movdqa xmm1,xmm2
    72fde4f02d2a:	por    xmm2,xmm1
    72fde4f02d2e:	movdqu XMMWORD PTR [r12+0x300],xmm2
    72fde4f02d38:	movdqu xmm2,XMMWORD PTR [r12+0x180]
    72fde4f02d42:	movdqa xmm1,xmm2
    72fde4f02d46:	por    xmm2,xmm1
    72fde4f02d4a:	movdqu XMMWORD PTR [r12+0x2d0],xmm2
    72fde4f02d54:	mov    r15,r14
    72fde4f02d57:	add    r15,0x10
    72fde4f02d5b:	mov    rbp,r15
    72fde4f02d5e:	add    rbp,0x8
    72fde4f02d62:	mov    r8,QWORD PTR [r15]
    72fde4f02d65:	mov    r15,QWORD PTR [rbp+0x0]
    72fde4f02d69:	mov    ebp,0x0
    72fde4f02d6e:	mov    QWORD PTR [r12+0x180],r8
    72fde4f02d76:	mov    QWORD PTR [r12+0x188],rbp
    72fde4f02d7e:	mov    ebp,0x0
    72fde4f02d83:	mov    QWORD PTR [r12+0x160],r15
    72fde4f02d8b:	mov    QWORD PTR [r12+0x168],rbp
    72fde4f02d93:	movdqu xmm2,XMMWORD PTR [r12+0x200]
    72fde4f02d9d:	movdqa xmm1,xmm2
    72fde4f02da1:	por    xmm2,xmm1
    72fde4f02da5:	movdqu XMMWORD PTR [r12+0x2b0],xmm2
    72fde4f02daf:	movdqu xmm2,XMMWORD PTR [r12+0x1f0]
    72fde4f02db9:	movdqa xmm1,xmm2
    72fde4f02dbd:	por    xmm2,xmm1
    72fde4f02dc1:	movdqu XMMWORD PTR [r12+0x200],xmm2
    72fde4f02dcb:	movdqu xmm2,XMMWORD PTR [r12+0x2e0]
    72fde4f02dd5:	movdqa xmm1,xmm2
    72fde4f02dd9:	por    xmm2,xmm1
    72fde4f02ddd:	movdqu XMMWORD PTR [r12+0x1f0],xmm2
    72fde4f02de7:	movdqu xmm2,XMMWORD PTR [r12+0x2a0]
    72fde4f02df1:	movdqa xmm1,xmm2
    72fde4f02df5:	por    xmm2,xmm1
    72fde4f02df9:	movdqu XMMWORD PTR [r12+0x2e0],xmm2
    72fde4f02e03:	movdqu xmm2,XMMWORD PTR [r12+0x280]
    72fde4f02e0d:	movdqa xmm1,xmm2
    72fde4f02e11:	por    xmm2,xmm1
    72fde4f02e15:	movdqu XMMWORD PTR [r12+0x2a0],xmm2
    72fde4f02e1f:	movdqu xmm2,XMMWORD PTR [r12+0x1c0]
    72fde4f02e29:	movdqa xmm1,xmm2
    72fde4f02e2d:	por    xmm2,xmm1
    72fde4f02e31:	movdqu XMMWORD PTR [r12+0x280],xmm2
    72fde4f02e3b:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    72fde4f02e45:	movdqa xmm1,xmm2
    72fde4f02e49:	por    xmm2,xmm1
    72fde4f02e4d:	movdqu XMMWORD PTR [r12+0x1c0],xmm2
    72fde4f02e57:	mov    r15d,0x8
    72fde4f02e5d:	mov    rbp,QWORD PTR [r14]
    72fde4f02e60:	mov    QWORD PTR [r12+0x210],rbp
    72fde4f02e68:	mov    QWORD PTR [r12+0x218],rbp
    72fde4f02e70:	add    r14,r15
    72fde4f02e73:	mov    QWORD PTR [r12+0x60],r14
    72fde4f02e78:	mov    r15d,0x0
    72fde4f02e7e:	mov    ebp,0x0
    72fde4f02e83:	mov    QWORD PTR [r12+0x220],r15
    72fde4f02e8b:	mov    QWORD PTR [r12+0x228],rbp
    72fde4f02e93:	mov    r15,QWORD PTR [r12+0xf8]
    72fde4f02e9b:	movdqu xmm2,XMMWORD PTR [r15]
    72fde4f02ea0:	movdqu XMMWORD PTR [r12+0x120],xmm2
    72fde4f02eaa:	mov    r15d,0x0
    72fde4f02eb0:	mov    ebp,0x0
    72fde4f02eb5:	mov    QWORD PTR [r12+0x230],r15
    72fde4f02ebd:	mov    QWORD PTR [r12+0x238],rbp
    72fde4f02ec5:	mov    r15,QWORD PTR [r14]
    72fde4f02ec8:	mov    r14d,0x0
    72fde4f02ece:	mov    QWORD PTR [r12+0x240],r15
    72fde4f02ed6:	mov    QWORD PTR [r12+0x248],r14
    72fde4f02ede:	mov    r14,QWORD PTR [r12+0x50]
    72fde4f02ee3:	add    r14,r13
    72fde4f02ee6:	mov    QWORD PTR [r12+0x60],r14
    72fde4f02eeb:	add    r13,0x40
    72fde4f02eef:	mov    QWORD PTR [r12+0x58],r13
    72fde4f02ef4:	lea    r13,[r12]
    72fde4f02ef8:	movabs r14,0x164e70cc20
    72fde4f02f02:	mov    r15d,0x410554
    72fde4f02f08:	mov    rdx,QWORD PTR [rsp]
    72fde4f02f0c:	mov    r10d,edx
    72fde4f02f0f:	and    r10d,0xc000
    72fde4f02f16:	shl    r10d,0x10
    72fde4f02f1a:	mov    r11d,edx
    72fde4f02f1d:	and    r11d,0x100
    72fde4f02f24:	shl    r11d,0x15
    72fde4f02f28:	or     r10d,r11d
    72fde4f02f2b:	and    edx,0x1
    72fde4f02f2e:	shl    edx,0x1c
    72fde4f02f31:	or     r10d,edx
    72fde4f02f34:	btc    r10,0x1d
    72fde4f02f39:	mov    r11d,0xf0000000
    72fde4f02f3f:	and    r11,r10
    72fde4f02f42:	movabs rsi,0xffffffff0fffffff
    72fde4f02f4c:	and    rbx,rsi
    72fde4f02f4f:	or     rbx,r11
    72fde4f02f52:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    72fde4f02f5c:	movdqu xmm1,XMMWORD PTR [r12+0x210]
    72fde4f02f66:	movdqu xmm14,XMMWORD PTR [r12+0x110]
    72fde4f02f70:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f02f75:	movdqa xmm14,xmm0
    72fde4f02f7a:	movdqu xmm15,XMMWORD PTR [rip+0x3aed]        # 0x72fde4f06a70
    72fde4f02f83:	pand   xmm14,xmm15
    72fde4f02f88:	movdqu xmm15,XMMWORD PTR [rip+0x3aef]        # 0x72fde4f06a80
    72fde4f02f91:	pcmpeqq xmm14,xmm15
    72fde4f02f97:	movdqa xmm15,xmm0
    72fde4f02f9c:	cmpunordpd xmm15,xmm0
    72fde4f02fa2:	por    xmm14,xmm15
    72fde4f02fa7:	pmovmskb ecx,xmm14
    72fde4f02fac:	jrcxz  0x72fde4f02fb3
    72fde4f02fae:	jmp    0x72fde4f04fa5
    72fde4f02fb3:	movdqu XMMWORD PTR [r12+0x110],xmm0
    72fde4f02fbd:	mov    eax,0x0
    72fde4f02fc2:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f02fce:	mov    rbp,rax
    72fde4f02fd1:	lea    r13,[r12]
    72fde4f02fd5:	movabs r14,0x164e70ce86
    72fde4f02fdf:	mov    r15d,0x410558
    72fde4f02fe5:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    72fde4f02fef:	movdqu xmm1,XMMWORD PTR [r12+0x210]
    72fde4f02ff9:	movdqu xmm14,XMMWORD PTR [r12+0x170]
    72fde4f03003:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f03008:	movdqa xmm14,xmm0
    72fde4f0300d:	movdqu xmm15,XMMWORD PTR [rip+0x3a5a]        # 0x72fde4f06a70
    72fde4f03016:	pand   xmm14,xmm15
    72fde4f0301b:	movdqu xmm15,XMMWORD PTR [rip+0x3a5c]        # 0x72fde4f06a80
    72fde4f03024:	pcmpeqq xmm14,xmm15
    72fde4f0302a:	movdqa xmm15,xmm0
    72fde4f0302f:	cmpunordpd xmm15,xmm0
    72fde4f03035:	por    xmm14,xmm15
    72fde4f0303a:	pmovmskb ecx,xmm14
    72fde4f0303f:	jrcxz  0x72fde4f03046
    72fde4f03041:	jmp    0x72fde4f0502b
    72fde4f03046:	movdqu XMMWORD PTR [r12+0x170],xmm0
    72fde4f03050:	mov    eax,0x0
    72fde4f03055:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f03061:	mov    rbp,rax
    72fde4f03064:	movdqu xmm2,XMMWORD PTR [r12+0x1e0]
    72fde4f0306e:	movdqa xmm1,xmm2
    72fde4f03072:	por    xmm2,xmm1
    72fde4f03076:	movdqu XMMWORD PTR [r12+0x120],xmm2
    72fde4f03080:	movdqu xmm2,XMMWORD PTR [r12+0x1d0]
    72fde4f0308a:	movdqa xmm1,xmm2
    72fde4f0308e:	por    xmm2,xmm1
    72fde4f03092:	movdqu XMMWORD PTR [r12+0x1e0],xmm2
    72fde4f0309c:	movdqu xmm2,XMMWORD PTR [r12+0x2c0]
    72fde4f030a6:	movdqa xmm1,xmm2
    72fde4f030aa:	por    xmm2,xmm1
    72fde4f030ae:	movdqu XMMWORD PTR [r12+0x1d0],xmm2
    72fde4f030b8:	movdqu xmm2,XMMWORD PTR [r12+0x290]
    72fde4f030c2:	movdqa xmm1,xmm2
    72fde4f030c6:	por    xmm2,xmm1
    72fde4f030ca:	movdqu XMMWORD PTR [r12+0x2c0],xmm2
    72fde4f030d4:	movdqu xmm2,XMMWORD PTR [r12+0x260]
    72fde4f030de:	movdqa xmm1,xmm2
    72fde4f030e2:	por    xmm2,xmm1
    72fde4f030e6:	movdqu XMMWORD PTR [r12+0x290],xmm2
    72fde4f030f0:	movdqu xmm2,XMMWORD PTR [r12+0x250]
    72fde4f030fa:	movdqa xmm1,xmm2
    72fde4f030fe:	por    xmm2,xmm1
    72fde4f03102:	movdqu XMMWORD PTR [r12+0x260],xmm2
    72fde4f0310c:	mov    r13,QWORD PTR [r12+0xf8]
    72fde4f03114:	add    r13,0xc0
    72fde4f0311b:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    72fde4f03121:	movdqu XMMWORD PTR [r12+0x250],xmm2
    72fde4f0312b:	mov    r13,QWORD PTR [r12+0x58]
    72fde4f03130:	sub    r13,0x200
    72fde4f03137:	lea    r13,[r12]
    72fde4f0313b:	movabs r14,0x164e70ce91
    72fde4f03145:	mov    r15d,0x41057c
    72fde4f0314b:	mov    r11,rax
    72fde4f0314e:	lahf
    72fde4f0314f:	seto   al
    72fde4f03152:	mov    WORD PTR [rsp],ax
    72fde4f03156:	mov    rax,r11
    72fde4f03159:	mov    rdx,QWORD PTR [rsp]
    72fde4f0315d:	mov    r10d,edx
    72fde4f03160:	and    r10d,0xc000
    72fde4f03167:	shl    r10d,0x10
    72fde4f0316b:	mov    r11d,edx
    72fde4f0316e:	and    r11d,0x100
    72fde4f03175:	shl    r11d,0x15
    72fde4f03179:	or     r10d,r11d
    72fde4f0317c:	and    edx,0x1
    72fde4f0317f:	shl    edx,0x1c
    72fde4f03182:	or     r10d,edx
    72fde4f03185:	btc    r10,0x1d
    72fde4f0318a:	mov    r11d,0xf0000000
    72fde4f03190:	and    r11,r10
    72fde4f03193:	movabs rsi,0xffffffff0fffffff
    72fde4f0319d:	and    rbx,rsi
    72fde4f031a0:	or     rbx,r11
    72fde4f031a3:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    72fde4f031ad:	movdqu xmm1,XMMWORD PTR [r12+0x210]
    72fde4f031b7:	movdqu xmm14,XMMWORD PTR [r12+0x220]
    72fde4f031c1:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f031c6:	movdqa xmm14,xmm0
    72fde4f031cb:	movdqu xmm15,XMMWORD PTR [rip+0x389c]        # 0x72fde4f06a70
    72fde4f031d4:	pand   xmm14,xmm15
    72fde4f031d9:	movdqu xmm15,XMMWORD PTR [rip+0x389e]        # 0x72fde4f06a80
    72fde4f031e2:	pcmpeqq xmm14,xmm15
    72fde4f031e8:	movdqa xmm15,xmm0
    72fde4f031ed:	cmpunordpd xmm15,xmm0
    72fde4f031f3:	por    xmm14,xmm15
    72fde4f031f8:	pmovmskb ecx,xmm14
    72fde4f031fd:	jrcxz  0x72fde4f03204
    72fde4f031ff:	jmp    0x72fde4f050b1
    72fde4f03204:	movdqu XMMWORD PTR [r12+0x220],xmm0
    72fde4f0320e:	mov    eax,0x0
    72fde4f03213:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f0321f:	mov    rbp,rax
    72fde4f03222:	mov    r13,QWORD PTR [r12+0xf8]
    72fde4f0322a:	add    r13,0xb0
    72fde4f03231:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    72fde4f03237:	movdqu XMMWORD PTR [r12+0x250],xmm2
    72fde4f03241:	lea    r13,[r12]
    72fde4f03245:	movabs r14,0x164e70ce92
    72fde4f0324f:	mov    r15d,0x410584
    72fde4f03255:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    72fde4f0325f:	movdqu xmm1,XMMWORD PTR [r12+0x210]
    72fde4f03269:	movdqu xmm14,XMMWORD PTR [r12+0x230]
    72fde4f03273:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f03278:	movdqa xmm14,xmm0
    72fde4f0327d:	movdqu xmm15,XMMWORD PTR [rip+0x37ea]        # 0x72fde4f06a70
    72fde4f03286:	pand   xmm14,xmm15
    72fde4f0328b:	movdqu xmm15,XMMWORD PTR [rip+0x37ec]        # 0x72fde4f06a80
    72fde4f03294:	pcmpeqq xmm14,xmm15
    72fde4f0329a:	movdqa xmm15,xmm0
    72fde4f0329f:	cmpunordpd xmm15,xmm0
    72fde4f032a5:	por    xmm14,xmm15
    72fde4f032aa:	pmovmskb ecx,xmm14
    72fde4f032af:	jrcxz  0x72fde4f032b6
    72fde4f032b1:	jmp    0x72fde4f05137
    72fde4f032b6:	movdqu XMMWORD PTR [r12+0x230],xmm0
    72fde4f032c0:	mov    eax,0x0
    72fde4f032c5:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f032d1:	mov    rbp,rax
    72fde4f032d4:	movdqu xmm2,XMMWORD PTR [r12+0x1c0]
    72fde4f032de:	movdqa xmm1,xmm2
    72fde4f032e2:	por    xmm2,xmm1
    72fde4f032e6:	movdqu XMMWORD PTR [r12+0x210],xmm2
    72fde4f032f0:	movdqu xmm2,XMMWORD PTR [r12+0x280]
    72fde4f032fa:	movdqa xmm1,xmm2
    72fde4f032fe:	por    xmm2,xmm1
    72fde4f03302:	movdqu XMMWORD PTR [r12+0x1c0],xmm2
    72fde4f0330c:	movdqu xmm2,XMMWORD PTR [r12+0x2a0]
    72fde4f03316:	movdqa xmm1,xmm2
    72fde4f0331a:	por    xmm2,xmm1
    72fde4f0331e:	movdqu XMMWORD PTR [r12+0x280],xmm2
    72fde4f03328:	movdqu xmm2,XMMWORD PTR [r12+0x2e0]
    72fde4f03332:	movdqa xmm1,xmm2
    72fde4f03336:	por    xmm2,xmm1
    72fde4f0333a:	movdqu XMMWORD PTR [r12+0x2a0],xmm2
    72fde4f03344:	movdqu xmm2,XMMWORD PTR [r12+0x1f0]
    72fde4f0334e:	movdqa xmm1,xmm2
    72fde4f03352:	por    xmm2,xmm1
    72fde4f03356:	movdqu XMMWORD PTR [r12+0x2e0],xmm2
    72fde4f03360:	movdqu xmm2,XMMWORD PTR [r12+0x200]
    72fde4f0336a:	movdqa xmm1,xmm2
    72fde4f0336e:	por    xmm2,xmm1
    72fde4f03372:	movdqu XMMWORD PTR [r12+0x1f0],xmm2
    72fde4f0337c:	movdqu xmm2,XMMWORD PTR [r12+0x260]
    72fde4f03386:	movdqa xmm1,xmm2
    72fde4f0338a:	por    xmm2,xmm1
    72fde4f0338e:	movdqu XMMWORD PTR [r12+0x250],xmm2
    72fde4f03398:	movdqu xmm2,XMMWORD PTR [r12+0x290]
    72fde4f033a2:	movdqa xmm1,xmm2
    72fde4f033a6:	por    xmm2,xmm1
    72fde4f033aa:	movdqu XMMWORD PTR [r12+0x260],xmm2
    72fde4f033b4:	movdqu xmm2,XMMWORD PTR [r12+0x2c0]
    72fde4f033be:	movdqa xmm1,xmm2
    72fde4f033c2:	por    xmm2,xmm1
    72fde4f033c6:	movdqu XMMWORD PTR [r12+0x290],xmm2
    72fde4f033d0:	movdqu xmm2,XMMWORD PTR [r12+0x1d0]
    72fde4f033da:	movdqa xmm1,xmm2
    72fde4f033de:	por    xmm2,xmm1
    72fde4f033e2:	movdqu XMMWORD PTR [r12+0x2c0],xmm2
    72fde4f033ec:	lea    r13,[r12]
    72fde4f033f0:	movabs r14,0x184fd31200
    72fde4f033fa:	mov    r15d,0x4105b0
    72fde4f03400:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    72fde4f0340a:	movdqu xmm1,XMMWORD PTR [r12+0x240]
    72fde4f03414:	pshufd xmm1,xmm1,0x44
    72fde4f03419:	movdqu xmm14,XMMWORD PTR [r12+0x110]
    72fde4f03423:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f03428:	movdqa xmm14,xmm0
    72fde4f0342d:	movdqu xmm15,XMMWORD PTR [rip+0x363a]        # 0x72fde4f06a70
    72fde4f03436:	pand   xmm14,xmm15
    72fde4f0343b:	movdqu xmm15,XMMWORD PTR [rip+0x363c]        # 0x72fde4f06a80
    72fde4f03444:	pcmpeqq xmm14,xmm15
    72fde4f0344a:	movdqa xmm15,xmm0
    72fde4f0344f:	cmpunordpd xmm15,xmm0
    72fde4f03455:	por    xmm14,xmm15
    72fde4f0345a:	pmovmskb ecx,xmm14
    72fde4f0345f:	jrcxz  0x72fde4f03466
    72fde4f03461:	jmp    0x72fde4f051bd
    72fde4f03466:	movdqu XMMWORD PTR [r12+0x110],xmm0
    72fde4f03470:	mov    eax,0x0
    72fde4f03475:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f03481:	mov    rbp,rax
    72fde4f03484:	lea    r13,[r12]
    72fde4f03488:	movabs r14,0x184fd313b1
    72fde4f03492:	mov    r15d,0x4105b4
    72fde4f03498:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    72fde4f034a2:	movdqu xmm1,XMMWORD PTR [r12+0x240]
    72fde4f034ac:	pshufd xmm1,xmm1,0x44
    72fde4f034b1:	movdqu xmm14,XMMWORD PTR [r12+0x220]
    72fde4f034bb:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f034c0:	movdqa xmm14,xmm0
    72fde4f034c5:	movdqu xmm15,XMMWORD PTR [rip+0x35a2]        # 0x72fde4f06a70
    72fde4f034ce:	pand   xmm14,xmm15
    72fde4f034d3:	movdqu xmm15,XMMWORD PTR [rip+0x35a4]        # 0x72fde4f06a80
    72fde4f034dc:	pcmpeqq xmm14,xmm15
    72fde4f034e2:	movdqa xmm15,xmm0
    72fde4f034e7:	cmpunordpd xmm15,xmm0
    72fde4f034ed:	por    xmm14,xmm15
    72fde4f034f2:	pmovmskb ecx,xmm14
    72fde4f034f7:	jrcxz  0x72fde4f034fe
    72fde4f034f9:	jmp    0x72fde4f05243
    72fde4f034fe:	movdqu XMMWORD PTR [r12+0x220],xmm0
    72fde4f03508:	mov    eax,0x0
    72fde4f0350d:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f03519:	mov    rbp,rax
    72fde4f0351c:	lea    r13,[r12]
    72fde4f03520:	movabs r14,0x184fd31166
    72fde4f0352a:	mov    r15d,0x4105b8
    72fde4f03530:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    72fde4f0353a:	movdqu xmm1,XMMWORD PTR [r12+0x240]
    72fde4f03544:	pshufd xmm1,xmm1,0x44
    72fde4f03549:	movdqu xmm14,XMMWORD PTR [r12+0x170]
    72fde4f03553:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f03558:	movdqa xmm14,xmm0
    72fde4f0355d:	movdqu xmm15,XMMWORD PTR [rip+0x350a]        # 0x72fde4f06a70
    72fde4f03566:	pand   xmm14,xmm15
    72fde4f0356b:	movdqu xmm15,XMMWORD PTR [rip+0x350c]        # 0x72fde4f06a80
    72fde4f03574:	pcmpeqq xmm14,xmm15
    72fde4f0357a:	movdqa xmm15,xmm0
    72fde4f0357f:	cmpunordpd xmm15,xmm0
    72fde4f03585:	por    xmm14,xmm15
    72fde4f0358a:	pmovmskb ecx,xmm14
    72fde4f0358f:	jrcxz  0x72fde4f03596
    72fde4f03591:	jmp    0x72fde4f052c9
    72fde4f03596:	movdqu XMMWORD PTR [r12+0x170],xmm0
    72fde4f035a0:	mov    eax,0x0
    72fde4f035a5:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f035b1:	mov    rbp,rax
    72fde4f035b4:	movdqu xmm2,XMMWORD PTR [r12+0x1e0]
    72fde4f035be:	movdqa xmm1,xmm2
    72fde4f035c2:	por    xmm2,xmm1
    72fde4f035c6:	movdqu XMMWORD PTR [r12+0x1d0],xmm2
    72fde4f035d0:	lea    r13,[r12]
    72fde4f035d4:	movabs r14,0x184fd311d2
    72fde4f035de:	mov    r15d,0x4105c0
    72fde4f035e4:	movdqu xmm0,XMMWORD PTR [r12+0x1f0]
    72fde4f035ee:	movdqu xmm1,XMMWORD PTR [r12+0x240]
    72fde4f035f8:	pshufd xmm1,xmm1,0x44
    72fde4f035fd:	movdqu xmm14,XMMWORD PTR [r12+0x230]
    72fde4f03607:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f0360c:	movdqa xmm14,xmm0
    72fde4f03611:	movdqu xmm15,XMMWORD PTR [rip+0x3456]        # 0x72fde4f06a70
    72fde4f0361a:	pand   xmm14,xmm15
    72fde4f0361f:	movdqu xmm15,XMMWORD PTR [rip+0x3458]        # 0x72fde4f06a80
    72fde4f03628:	pcmpeqq xmm14,xmm15
    72fde4f0362e:	movdqa xmm15,xmm0
    72fde4f03633:	cmpunordpd xmm15,xmm0
    72fde4f03639:	por    xmm14,xmm15
    72fde4f0363e:	pmovmskb ecx,xmm14
    72fde4f03643:	jrcxz  0x72fde4f0364a
    72fde4f03645:	jmp    0x72fde4f0534f
    72fde4f0364a:	movdqu XMMWORD PTR [r12+0x230],xmm0
    72fde4f03654:	mov    eax,0x0
    72fde4f03659:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f03665:	mov    rbp,rax
    72fde4f03668:	movdqu xmm2,XMMWORD PTR [r12+0x2b0]
    72fde4f03672:	movdqa xmm1,xmm2
    72fde4f03676:	por    xmm2,xmm1
    72fde4f0367a:	movdqu XMMWORD PTR [r12+0x200],xmm2
    72fde4f03684:	movdqu xmm2,XMMWORD PTR [r12+0x120]
    72fde4f0368e:	movdqa xmm1,xmm2
    72fde4f03692:	por    xmm2,xmm1
    72fde4f03696:	movdqu XMMWORD PTR [r12+0x1e0],xmm2
    72fde4f036a0:	movdqu xmm2,XMMWORD PTR [r12+0x300]
    72fde4f036aa:	movdqa xmm1,xmm2
    72fde4f036ae:	por    xmm2,xmm1
    72fde4f036b2:	movdqu XMMWORD PTR [r12+0x2b0],xmm2
    72fde4f036bc:	movdqu xmm2,XMMWORD PTR [r12+0x2f0]
    72fde4f036c6:	movdqa xmm1,xmm2
    72fde4f036ca:	por    xmm2,xmm1
    72fde4f036ce:	movdqu XMMWORD PTR [r12+0x300],xmm2
    72fde4f036d8:	lea    r13,[r12]
    72fde4f036dc:	movabs r14,0x184fc712a0
    72fde4f036e6:	mov    r15d,0x4105d4
    72fde4f036ec:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    72fde4f036f6:	movdqu xmm1,XMMWORD PTR [r12+0x180]
    72fde4f03700:	pshufd xmm1,xmm1,0x44
    72fde4f03705:	movdqu xmm14,XMMWORD PTR [r12+0x110]
    72fde4f0370f:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f03714:	movdqa xmm14,xmm0
    72fde4f03719:	movdqu xmm15,XMMWORD PTR [rip+0x334e]        # 0x72fde4f06a70
    72fde4f03722:	pand   xmm14,xmm15
    72fde4f03727:	movdqu xmm15,XMMWORD PTR [rip+0x3350]        # 0x72fde4f06a80
    72fde4f03730:	pcmpeqq xmm14,xmm15
    72fde4f03736:	movdqa xmm15,xmm0
    72fde4f0373b:	cmpunordpd xmm15,xmm0
    72fde4f03741:	por    xmm14,xmm15
    72fde4f03746:	pmovmskb ecx,xmm14
    72fde4f0374b:	jrcxz  0x72fde4f03752
    72fde4f0374d:	jmp    0x72fde4f053d5
    72fde4f03752:	movdqu XMMWORD PTR [r12+0x110],xmm0
    72fde4f0375c:	mov    eax,0x0
    72fde4f03761:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f0376d:	mov    rbp,rax
    72fde4f03770:	lea    r13,[r12]
    72fde4f03774:	movabs r14,0x184fc71371
    72fde4f0377e:	mov    r15d,0x4105d8
    72fde4f03784:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    72fde4f0378e:	movdqu xmm1,XMMWORD PTR [r12+0x180]
    72fde4f03798:	pshufd xmm1,xmm1,0x44
    72fde4f0379d:	movdqu xmm14,XMMWORD PTR [r12+0x220]
    72fde4f037a7:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f037ac:	movdqa xmm14,xmm0
    72fde4f037b1:	movdqu xmm15,XMMWORD PTR [rip+0x32b6]        # 0x72fde4f06a70
    72fde4f037ba:	pand   xmm14,xmm15
    72fde4f037bf:	movdqu xmm15,XMMWORD PTR [rip+0x32b8]        # 0x72fde4f06a80
    72fde4f037c8:	pcmpeqq xmm14,xmm15
    72fde4f037ce:	movdqa xmm15,xmm0
    72fde4f037d3:	cmpunordpd xmm15,xmm0
    72fde4f037d9:	por    xmm14,xmm15
    72fde4f037de:	pmovmskb ecx,xmm14
    72fde4f037e3:	jrcxz  0x72fde4f037ea
    72fde4f037e5:	jmp    0x72fde4f0545b
    72fde4f037ea:	movdqu XMMWORD PTR [r12+0x220],xmm0
    72fde4f037f4:	mov    eax,0x0
    72fde4f037f9:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f03805:	mov    rbp,rax
    72fde4f03808:	lea    r13,[r12]
    72fde4f0380c:	movabs r14,0x184fc712e6
    72fde4f03816:	mov    r15d,0x4105dc
    72fde4f0381c:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    72fde4f03826:	movdqu xmm1,XMMWORD PTR [r12+0x180]
    72fde4f03830:	pshufd xmm1,xmm1,0x44
    72fde4f03835:	movdqu xmm14,XMMWORD PTR [r12+0x170]
    72fde4f0383f:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f03844:	movdqa xmm14,xmm0
    72fde4f03849:	movdqu xmm15,XMMWORD PTR [rip+0x321e]        # 0x72fde4f06a70
    72fde4f03852:	pand   xmm14,xmm15
    72fde4f03857:	movdqu xmm15,XMMWORD PTR [rip+0x3220]        # 0x72fde4f06a80
    72fde4f03860:	pcmpeqq xmm14,xmm15
    72fde4f03866:	movdqa xmm15,xmm0
    72fde4f0386b:	cmpunordpd xmm15,xmm0
    72fde4f03871:	por    xmm14,xmm15
    72fde4f03876:	pmovmskb ecx,xmm14
    72fde4f0387b:	jrcxz  0x72fde4f03882
    72fde4f0387d:	jmp    0x72fde4f054e1
    72fde4f03882:	movdqu XMMWORD PTR [r12+0x170],xmm0
    72fde4f0388c:	mov    eax,0x0
    72fde4f03891:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f0389d:	mov    rbp,rax
    72fde4f038a0:	lea    r13,[r12]
    72fde4f038a4:	movabs r14,0x184fc71192
    72fde4f038ae:	mov    r15d,0x4105e0
    72fde4f038b4:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    72fde4f038be:	movdqu xmm1,XMMWORD PTR [r12+0x180]
    72fde4f038c8:	pshufd xmm1,xmm1,0x44
    72fde4f038cd:	movdqu xmm14,XMMWORD PTR [r12+0x230]
    72fde4f038d7:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f038dc:	movdqa xmm14,xmm0
    72fde4f038e1:	movdqu xmm15,XMMWORD PTR [rip+0x3186]        # 0x72fde4f06a70
    72fde4f038ea:	pand   xmm14,xmm15
    72fde4f038ef:	movdqu xmm15,XMMWORD PTR [rip+0x3188]        # 0x72fde4f06a80
    72fde4f038f8:	pcmpeqq xmm14,xmm15
    72fde4f038fe:	movdqa xmm15,xmm0
    72fde4f03903:	cmpunordpd xmm15,xmm0
    72fde4f03909:	por    xmm14,xmm15
    72fde4f0390e:	pmovmskb ecx,xmm14
    72fde4f03913:	jrcxz  0x72fde4f0391a
    72fde4f03915:	jmp    0x72fde4f05567
    72fde4f0391a:	movdqu XMMWORD PTR [r12+0x230],xmm0
    72fde4f03924:	mov    eax,0x0
    72fde4f03929:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f03935:	mov    rbp,rax
    72fde4f03938:	movdqu xmm2,XMMWORD PTR [r12+0x2d0]
    72fde4f03942:	movdqa xmm1,xmm2
    72fde4f03946:	por    xmm2,xmm1
    72fde4f0394a:	movdqu XMMWORD PTR [r12+0x180],xmm2
    72fde4f03954:	movdqu xmm2,XMMWORD PTR [r12+0x1a0]
    72fde4f0395e:	movdqa xmm1,xmm2
    72fde4f03962:	por    xmm2,xmm1
    72fde4f03966:	movdqu XMMWORD PTR [r12+0x2d0],xmm2
    72fde4f03970:	lea    r13,[r12]
    72fde4f03974:	movabs r14,0x184fc513d1
    72fde4f0397e:	mov    r15d,0x4105ec
    72fde4f03984:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    72fde4f0398e:	movdqu xmm1,XMMWORD PTR [r12+0x160]
    72fde4f03998:	pshufd xmm1,xmm1,0x44
    72fde4f0399d:	movdqu xmm14,XMMWORD PTR [r12+0x220]
    72fde4f039a7:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f039ac:	movdqa xmm14,xmm0
    72fde4f039b1:	movdqu xmm15,XMMWORD PTR [rip+0x30b6]        # 0x72fde4f06a70
    72fde4f039ba:	pand   xmm14,xmm15
    72fde4f039bf:	movdqu xmm15,XMMWORD PTR [rip+0x30b8]        # 0x72fde4f06a80
    72fde4f039c8:	pcmpeqq xmm14,xmm15
    72fde4f039ce:	movdqa xmm15,xmm0
    72fde4f039d3:	cmpunordpd xmm15,xmm0
    72fde4f039d9:	por    xmm14,xmm15
    72fde4f039de:	pmovmskb ecx,xmm14
    72fde4f039e3:	jrcxz  0x72fde4f039ea
    72fde4f039e5:	jmp    0x72fde4f055ed
    72fde4f039ea:	movdqu XMMWORD PTR [r12+0x220],xmm0
    72fde4f039f4:	mov    eax,0x0
    72fde4f039f9:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f03a05:	mov    rbp,rax
    72fde4f03a08:	lea    r13,[r12]
    72fde4f03a0c:	movabs r14,0x184fc510e0
    72fde4f03a16:	mov    r15d,0x4105f0
    72fde4f03a1c:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    72fde4f03a26:	movdqu xmm1,XMMWORD PTR [r12+0x160]
    72fde4f03a30:	pshufd xmm1,xmm1,0x44
    72fde4f03a35:	movdqu xmm14,XMMWORD PTR [r12+0x110]
    72fde4f03a3f:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f03a44:	movdqa xmm14,xmm0
    72fde4f03a49:	movdqu xmm15,XMMWORD PTR [rip+0x301e]        # 0x72fde4f06a70
    72fde4f03a52:	pand   xmm14,xmm15
    72fde4f03a57:	movdqu xmm15,XMMWORD PTR [rip+0x3020]        # 0x72fde4f06a80
    72fde4f03a60:	pcmpeqq xmm14,xmm15
    72fde4f03a66:	movdqa xmm15,xmm0
    72fde4f03a6b:	cmpunordpd xmm15,xmm0
    72fde4f03a71:	por    xmm14,xmm15
    72fde4f03a76:	pmovmskb ecx,xmm14
    72fde4f03a7b:	jrcxz  0x72fde4f03a82
    72fde4f03a7d:	jmp    0x72fde4f05673
    72fde4f03a82:	movdqu XMMWORD PTR [r12+0x110],xmm0
    72fde4f03a8c:	mov    eax,0x0
    72fde4f03a91:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f03a9d:	mov    rbp,rax
    72fde4f03aa0:	mov    r13,QWORD PTR [r12+0xf8]
    72fde4f03aa8:	add    r13,0x80
    72fde4f03aaf:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    72fde4f03ab5:	movdqu XMMWORD PTR [r12+0x2f0],xmm2
    72fde4f03abf:	lea    r13,[r12]
    72fde4f03ac3:	movabs r14,0x184fc51306
    72fde4f03acd:	mov    r15d,0x4105f8
    72fde4f03ad3:	movdqu xmm0,XMMWORD PTR [r12+0x290]
    72fde4f03add:	movdqu xmm1,XMMWORD PTR [r12+0x160]
    72fde4f03ae7:	pshufd xmm1,xmm1,0x44
    72fde4f03aec:	movdqu xmm14,XMMWORD PTR [r12+0x170]
    72fde4f03af6:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f03afb:	movdqa xmm14,xmm0
    72fde4f03b00:	movdqu xmm15,XMMWORD PTR [rip+0x2f67]        # 0x72fde4f06a70
    72fde4f03b09:	pand   xmm14,xmm15
    72fde4f03b0e:	movdqu xmm15,XMMWORD PTR [rip+0x2f69]        # 0x72fde4f06a80
    72fde4f03b17:	pcmpeqq xmm14,xmm15
    72fde4f03b1d:	movdqa xmm15,xmm0
    72fde4f03b22:	cmpunordpd xmm15,xmm0
    72fde4f03b28:	por    xmm14,xmm15
    72fde4f03b2d:	pmovmskb ecx,xmm14
    72fde4f03b32:	jrcxz  0x72fde4f03b39
    72fde4f03b34:	jmp    0x72fde4f056f9
    72fde4f03b39:	movdqu XMMWORD PTR [r12+0x170],xmm0
    72fde4f03b43:	mov    eax,0x0
    72fde4f03b48:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f03b54:	mov    rbp,rax
    72fde4f03b57:	lea    r13,[r12]
    72fde4f03b5b:	movabs r14,0x184fc51132
    72fde4f03b65:	mov    r15d,0x4105fc
    72fde4f03b6b:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    72fde4f03b75:	movdqu xmm1,XMMWORD PTR [r12+0x160]
    72fde4f03b7f:	pshufd xmm1,xmm1,0x44
    72fde4f03b84:	movdqu xmm14,XMMWORD PTR [r12+0x230]
    72fde4f03b8e:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f03b93:	movdqa xmm14,xmm0
    72fde4f03b98:	movdqu xmm15,XMMWORD PTR [rip+0x2ecf]        # 0x72fde4f06a70
    72fde4f03ba1:	pand   xmm14,xmm15
    72fde4f03ba6:	movdqu xmm15,XMMWORD PTR [rip+0x2ed1]        # 0x72fde4f06a80
    72fde4f03baf:	pcmpeqq xmm14,xmm15
    72fde4f03bb5:	movdqa xmm15,xmm0
    72fde4f03bba:	cmpunordpd xmm15,xmm0
    72fde4f03bc0:	por    xmm14,xmm15
    72fde4f03bc5:	pmovmskb ecx,xmm14
    72fde4f03bca:	jrcxz  0x72fde4f03bd1
    72fde4f03bcc:	jmp    0x72fde4f0577f
    72fde4f03bd1:	movdqu XMMWORD PTR [r12+0x230],xmm0
    72fde4f03bdb:	mov    eax,0x0
    72fde4f03be0:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f03bec:	mov    rbp,rax
    72fde4f03bef:	movdqu xmm2,XMMWORD PTR [r12+0x1b0]
    72fde4f03bf9:	movdqa xmm1,xmm2
    72fde4f03bfd:	por    xmm2,xmm1
    72fde4f03c01:	movdqu XMMWORD PTR [r12+0x160],xmm2
    72fde4f03c0b:	mov    r13,QWORD PTR [r12+0xf8]
    72fde4f03c13:	add    r13,0x40
    72fde4f03c17:	mov    r14,r13
    72fde4f03c1a:	add    r14,0x10
    72fde4f03c1e:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    72fde4f03c24:	movdqu xmm3,XMMWORD PTR [r14]
    72fde4f03c29:	movdqu XMMWORD PTR [r12+0x1b0],xmm2
    72fde4f03c33:	movdqu XMMWORD PTR [r12+0x1a0],xmm3
    72fde4f03c3d:	lea    r13,[r12]
    72fde4f03c41:	movabs r14,0x184fc41111
    72fde4f03c4b:	mov    r15d,0x410608
    72fde4f03c51:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    72fde4f03c5b:	movdqu xmm1,XMMWORD PTR [r12+0x150]
    72fde4f03c65:	pshufd xmm1,xmm1,0x44
    72fde4f03c6a:	movdqu xmm14,XMMWORD PTR [r12+0x220]
    72fde4f03c74:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f03c79:	movdqa xmm14,xmm0
    72fde4f03c7e:	movdqu xmm15,XMMWORD PTR [rip+0x2de9]        # 0x72fde4f06a70
    72fde4f03c87:	pand   xmm14,xmm15
    72fde4f03c8c:	movdqu xmm15,XMMWORD PTR [rip+0x2deb]        # 0x72fde4f06a80
    72fde4f03c95:	pcmpeqq xmm14,xmm15
    72fde4f03c9b:	movdqa xmm15,xmm0
    72fde4f03ca0:	cmpunordpd xmm15,xmm0
    72fde4f03ca6:	por    xmm14,xmm15
    72fde4f03cab:	pmovmskb ecx,xmm14
    72fde4f03cb0:	jrcxz  0x72fde4f03cb7
    72fde4f03cb2:	jmp    0x72fde4f05805
    72fde4f03cb7:	movdqu XMMWORD PTR [r12+0x220],xmm0
    72fde4f03cc1:	mov    eax,0x0
    72fde4f03cc6:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f03cd2:	mov    rbp,rax
    72fde4f03cd5:	lea    r13,[r12]
    72fde4f03cd9:	movabs r14,0x184fc410a0
    72fde4f03ce3:	mov    r15d,0x41060c
    72fde4f03ce9:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    72fde4f03cf3:	movdqu xmm1,XMMWORD PTR [r12+0x150]
    72fde4f03cfd:	pshufd xmm1,xmm1,0x44
    72fde4f03d02:	movdqu xmm14,XMMWORD PTR [r12+0x110]
    72fde4f03d0c:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f03d11:	movdqa xmm14,xmm0
    72fde4f03d16:	movdqu xmm15,XMMWORD PTR [rip+0x2d51]        # 0x72fde4f06a70
    72fde4f03d1f:	pand   xmm14,xmm15
    72fde4f03d24:	movdqu xmm15,XMMWORD PTR [rip+0x2d53]        # 0x72fde4f06a80
    72fde4f03d2d:	pcmpeqq xmm14,xmm15
    72fde4f03d33:	movdqa xmm15,xmm0
    72fde4f03d38:	cmpunordpd xmm15,xmm0
    72fde4f03d3e:	por    xmm14,xmm15
    72fde4f03d43:	pmovmskb ecx,xmm14
    72fde4f03d48:	jrcxz  0x72fde4f03d4f
    72fde4f03d4a:	jmp    0x72fde4f0588b
    72fde4f03d4f:	movdqu XMMWORD PTR [r12+0x110],xmm0
    72fde4f03d59:	mov    eax,0x0
    72fde4f03d5e:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f03d6a:	mov    rbp,rax
    72fde4f03d6d:	lea    r13,[r12]
    72fde4f03d71:	movabs r14,0x184fc41326
    72fde4f03d7b:	mov    r15d,0x410610
    72fde4f03d81:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    72fde4f03d8b:	movdqu xmm1,XMMWORD PTR [r12+0x150]
    72fde4f03d95:	pshufd xmm1,xmm1,0x44
    72fde4f03d9a:	movdqu xmm14,XMMWORD PTR [r12+0x170]
    72fde4f03da4:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f03da9:	movdqa xmm14,xmm0
    72fde4f03dae:	movdqu xmm15,XMMWORD PTR [rip+0x2cb9]        # 0x72fde4f06a70
    72fde4f03db7:	pand   xmm14,xmm15
    72fde4f03dbc:	movdqu xmm15,XMMWORD PTR [rip+0x2cbb]        # 0x72fde4f06a80
    72fde4f03dc5:	pcmpeqq xmm14,xmm15
    72fde4f03dcb:	movdqa xmm15,xmm0
    72fde4f03dd0:	cmpunordpd xmm15,xmm0
    72fde4f03dd6:	por    xmm14,xmm15
    72fde4f03ddb:	pmovmskb ecx,xmm14
    72fde4f03de0:	jrcxz  0x72fde4f03de7
    72fde4f03de2:	jmp    0x72fde4f05911
    72fde4f03de7:	movdqu XMMWORD PTR [r12+0x170],xmm0
    72fde4f03df1:	mov    eax,0x0
    72fde4f03df6:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f03e02:	mov    rbp,rax
    72fde4f03e05:	lea    r13,[r12]
    72fde4f03e09:	movabs r14,0x184fc41032
    72fde4f03e13:	mov    r15d,0x410614
    72fde4f03e19:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    72fde4f03e23:	movdqu xmm1,XMMWORD PTR [r12+0x150]
    72fde4f03e2d:	pshufd xmm1,xmm1,0x44
    72fde4f03e32:	movdqu xmm14,XMMWORD PTR [r12+0x230]
    72fde4f03e3c:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f03e41:	movdqa xmm14,xmm0
    72fde4f03e46:	movdqu xmm15,XMMWORD PTR [rip+0x2c21]        # 0x72fde4f06a70
    72fde4f03e4f:	pand   xmm14,xmm15
    72fde4f03e54:	movdqu xmm15,XMMWORD PTR [rip+0x2c23]        # 0x72fde4f06a80
    72fde4f03e5d:	pcmpeqq xmm14,xmm15
    72fde4f03e63:	movdqa xmm15,xmm0
    72fde4f03e68:	cmpunordpd xmm15,xmm0
    72fde4f03e6e:	por    xmm14,xmm15
    72fde4f03e73:	pmovmskb ecx,xmm14
    72fde4f03e78:	jrcxz  0x72fde4f03e7f
    72fde4f03e7a:	jmp    0x72fde4f05997
    72fde4f03e7f:	movdqu XMMWORD PTR [r12+0x230],xmm0
    72fde4f03e89:	mov    eax,0x0
    72fde4f03e8e:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f03e9a:	mov    rbp,rax
    72fde4f03e9d:	mov    r13,QWORD PTR [r12+0xf8]
    72fde4f03ea5:	add    r13,0x60
    72fde4f03ea9:	mov    r14,r13
    72fde4f03eac:	add    r14,0x10
    72fde4f03eb0:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    72fde4f03eb6:	movdqu xmm3,XMMWORD PTR [r14]
    72fde4f03ebb:	movdqu XMMWORD PTR [r12+0x150],xmm2
    72fde4f03ec5:	movdqu XMMWORD PTR [r12+0x120],xmm3
    72fde4f03ecf:	lea    r13,[r12]
    72fde4f03ed3:	movabs r14,0x184fc31131
    72fde4f03edd:	mov    r15d,0x41061c
    72fde4f03ee3:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    72fde4f03eed:	movdqu xmm1,XMMWORD PTR [r12+0x140]
    72fde4f03ef7:	pshufd xmm1,xmm1,0x44
    72fde4f03efc:	movdqu xmm14,XMMWORD PTR [r12+0x220]
    72fde4f03f06:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f03f0b:	movdqa xmm14,xmm0
    72fde4f03f10:	movdqu xmm15,XMMWORD PTR [rip+0x2b57]        # 0x72fde4f06a70
    72fde4f03f19:	pand   xmm14,xmm15
    72fde4f03f1e:	movdqu xmm15,XMMWORD PTR [rip+0x2b59]        # 0x72fde4f06a80
    72fde4f03f27:	pcmpeqq xmm14,xmm15
    72fde4f03f2d:	movdqa xmm15,xmm0
    72fde4f03f32:	cmpunordpd xmm15,xmm0
    72fde4f03f38:	por    xmm14,xmm15
    72fde4f03f3d:	pmovmskb ecx,xmm14
    72fde4f03f42:	jrcxz  0x72fde4f03f49
    72fde4f03f44:	jmp    0x72fde4f05a1d
    72fde4f03f49:	movdqu XMMWORD PTR [r12+0x220],xmm0
    72fde4f03f53:	mov    eax,0x0
    72fde4f03f58:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f03f64:	mov    rbp,rax
    72fde4f03f67:	lea    r13,[r12]
    72fde4f03f6b:	movabs r14,0x184fc31080
    72fde4f03f75:	mov    r15d,0x410620
    72fde4f03f7b:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    72fde4f03f85:	movdqu xmm1,XMMWORD PTR [r12+0x140]
    72fde4f03f8f:	pshufd xmm1,xmm1,0x44
    72fde4f03f94:	movdqu xmm14,XMMWORD PTR [r12+0x110]
    72fde4f03f9e:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f03fa3:	movdqa xmm14,xmm0
    72fde4f03fa8:	movdqu xmm15,XMMWORD PTR [rip+0x2abf]        # 0x72fde4f06a70
    72fde4f03fb1:	pand   xmm14,xmm15
    72fde4f03fb6:	movdqu xmm15,XMMWORD PTR [rip+0x2ac1]        # 0x72fde4f06a80
    72fde4f03fbf:	pcmpeqq xmm14,xmm15
    72fde4f03fc5:	movdqa xmm15,xmm0
    72fde4f03fca:	cmpunordpd xmm15,xmm0
    72fde4f03fd0:	por    xmm14,xmm15
    72fde4f03fd5:	pmovmskb ecx,xmm14
    72fde4f03fda:	jrcxz  0x72fde4f03fe1
    72fde4f03fdc:	jmp    0x72fde4f05aa3
    72fde4f03fe1:	movdqu XMMWORD PTR [r12+0x110],xmm0
    72fde4f03feb:	mov    eax,0x0
    72fde4f03ff0:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f03ffc:	mov    rbp,rax
    72fde4f03fff:	lea    r13,[r12]
    72fde4f04003:	movabs r14,0x184fc31346
    72fde4f0400d:	mov    r15d,0x410624
    72fde4f04013:	movdqu xmm0,XMMWORD PTR [r12+0x2b0]
    72fde4f0401d:	movdqu xmm1,XMMWORD PTR [r12+0x140]
    72fde4f04027:	pshufd xmm1,xmm1,0x44
    72fde4f0402c:	movdqu xmm14,XMMWORD PTR [r12+0x170]
    72fde4f04036:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f0403b:	movdqa xmm14,xmm0
    72fde4f04040:	movdqu xmm15,XMMWORD PTR [rip+0x2a27]        # 0x72fde4f06a70
    72fde4f04049:	pand   xmm14,xmm15
    72fde4f0404e:	movdqu xmm15,XMMWORD PTR [rip+0x2a29]        # 0x72fde4f06a80
    72fde4f04057:	pcmpeqq xmm14,xmm15
    72fde4f0405d:	movdqa xmm15,xmm0
    72fde4f04062:	cmpunordpd xmm15,xmm0
    72fde4f04068:	por    xmm14,xmm15
    72fde4f0406d:	pmovmskb ecx,xmm14
    72fde4f04072:	jrcxz  0x72fde4f04079
    72fde4f04074:	jmp    0x72fde4f05b29
    72fde4f04079:	movdqu XMMWORD PTR [r12+0x170],xmm0
    72fde4f04083:	mov    eax,0x0
    72fde4f04088:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f04094:	mov    rbp,rax
    72fde4f04097:	lea    r13,[r12]
    72fde4f0409b:	movabs r14,0x184fc31152
    72fde4f040a5:	mov    r15d,0x410628
    72fde4f040ab:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    72fde4f040b5:	movdqu xmm1,XMMWORD PTR [r12+0x140]
    72fde4f040bf:	pshufd xmm1,xmm1,0x44
    72fde4f040c4:	movdqu xmm14,XMMWORD PTR [r12+0x230]
    72fde4f040ce:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f040d3:	movdqa xmm14,xmm0
    72fde4f040d8:	movdqu xmm15,XMMWORD PTR [rip+0x298f]        # 0x72fde4f06a70
    72fde4f040e1:	pand   xmm14,xmm15
    72fde4f040e6:	movdqu xmm15,XMMWORD PTR [rip+0x2991]        # 0x72fde4f06a80
    72fde4f040ef:	pcmpeqq xmm14,xmm15
    72fde4f040f5:	movdqa xmm15,xmm0
    72fde4f040fa:	cmpunordpd xmm15,xmm0
    72fde4f04100:	por    xmm14,xmm15
    72fde4f04105:	pmovmskb ecx,xmm14
    72fde4f0410a:	jrcxz  0x72fde4f04111
    72fde4f0410c:	jmp    0x72fde4f05baf
    72fde4f04111:	movdqu XMMWORD PTR [r12+0x230],xmm0
    72fde4f0411b:	mov    eax,0x0
    72fde4f04120:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f0412c:	mov    rbp,rax
    72fde4f0412f:	mov    r13,QWORD PTR [r12+0xf8]
    72fde4f04137:	add    r13,0x20
    72fde4f0413b:	mov    r14,r13
    72fde4f0413e:	add    r14,0x10
    72fde4f04142:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    72fde4f04148:	movdqu xmm3,XMMWORD PTR [r14]
    72fde4f0414d:	movdqu XMMWORD PTR [r12+0x240],xmm2
    72fde4f04157:	movdqu XMMWORD PTR [r12+0x140],xmm3
    72fde4f04161:	lea    r13,[r12]
    72fde4f04165:	movabs r14,0x184fc211f1
    72fde4f0416f:	mov    r15d,0x410630
    72fde4f04175:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    72fde4f0417f:	movdqu xmm1,XMMWORD PTR [r12+0x130]
    72fde4f04189:	pshufd xmm1,xmm1,0x44
    72fde4f0418e:	movdqu xmm14,XMMWORD PTR [r12+0x220]
    72fde4f04198:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f0419d:	movdqa xmm14,xmm0
    72fde4f041a2:	movdqu xmm15,XMMWORD PTR [rip+0x28c5]        # 0x72fde4f06a70
    72fde4f041ab:	pand   xmm14,xmm15
    72fde4f041b0:	movdqu xmm15,XMMWORD PTR [rip+0x28c7]        # 0x72fde4f06a80
    72fde4f041b9:	pcmpeqq xmm14,xmm15
    72fde4f041bf:	movdqa xmm15,xmm0
    72fde4f041c4:	cmpunordpd xmm15,xmm0
    72fde4f041ca:	por    xmm14,xmm15
    72fde4f041cf:	pmovmskb ecx,xmm14
    72fde4f041d4:	jrcxz  0x72fde4f041db
    72fde4f041d6:	jmp    0x72fde4f05c35
    72fde4f041db:	movdqu XMMWORD PTR [r12+0x220],xmm0
    72fde4f041e5:	mov    eax,0x0
    72fde4f041ea:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f041f6:	mov    rbp,rax
    72fde4f041f9:	lea    r13,[r12]
    72fde4f041fd:	movabs r14,0x184fc213c0
    72fde4f04207:	mov    r15d,0x410634
    72fde4f0420d:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    72fde4f04217:	movdqu xmm1,XMMWORD PTR [r12+0x130]
    72fde4f04221:	pshufd xmm1,xmm1,0x44
    72fde4f04226:	movdqu xmm14,XMMWORD PTR [r12+0x110]
    72fde4f04230:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f04235:	movdqa xmm14,xmm0
    72fde4f0423a:	movdqu xmm15,XMMWORD PTR [rip+0x282d]        # 0x72fde4f06a70
    72fde4f04243:	pand   xmm14,xmm15
    72fde4f04248:	movdqu xmm15,XMMWORD PTR [rip+0x282f]        # 0x72fde4f06a80
    72fde4f04251:	pcmpeqq xmm14,xmm15
    72fde4f04257:	movdqa xmm15,xmm0
    72fde4f0425c:	cmpunordpd xmm15,xmm0
    72fde4f04262:	por    xmm14,xmm15
    72fde4f04267:	pmovmskb ecx,xmm14
    72fde4f0426c:	jrcxz  0x72fde4f04273
    72fde4f0426e:	jmp    0x72fde4f05cbb
    72fde4f04273:	movdqu XMMWORD PTR [r12+0x110],xmm0
    72fde4f0427d:	mov    eax,0x0
    72fde4f04282:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f0428e:	mov    rbp,rax
    72fde4f04291:	lea    r13,[r12]
    72fde4f04295:	movabs r14,0x184fc21026
    72fde4f0429f:	mov    r15d,0x410638
    72fde4f042a5:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    72fde4f042af:	movdqu xmm1,XMMWORD PTR [r12+0x130]
    72fde4f042b9:	pshufd xmm1,xmm1,0x44
    72fde4f042be:	movdqu xmm14,XMMWORD PTR [r12+0x170]
    72fde4f042c8:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f042cd:	movdqa xmm14,xmm0
    72fde4f042d2:	movdqu xmm15,XMMWORD PTR [rip+0x2795]        # 0x72fde4f06a70
    72fde4f042db:	pand   xmm14,xmm15
    72fde4f042e0:	movdqu xmm15,XMMWORD PTR [rip+0x2797]        # 0x72fde4f06a80
    72fde4f042e9:	pcmpeqq xmm14,xmm15
    72fde4f042ef:	movdqa xmm15,xmm0
    72fde4f042f4:	cmpunordpd xmm15,xmm0
    72fde4f042fa:	por    xmm14,xmm15
    72fde4f042ff:	pmovmskb ecx,xmm14
    72fde4f04304:	jrcxz  0x72fde4f0430b
    72fde4f04306:	jmp    0x72fde4f05d41
    72fde4f0430b:	movdqu XMMWORD PTR [r12+0x170],xmm0
    72fde4f04315:	mov    eax,0x0
    72fde4f0431a:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f04326:	mov    rbp,rax
    72fde4f04329:	lea    r13,[r12]
    72fde4f0432d:	movabs r14,0x184fc21072
    72fde4f04337:	mov    r15d,0x41063c
    72fde4f0433d:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    72fde4f04347:	movdqu xmm1,XMMWORD PTR [r12+0x130]
    72fde4f04351:	pshufd xmm1,xmm1,0x44
    72fde4f04356:	movdqu xmm14,XMMWORD PTR [r12+0x230]
    72fde4f04360:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f04365:	movdqa xmm14,xmm0
    72fde4f0436a:	movdqu xmm15,XMMWORD PTR [rip+0x26fd]        # 0x72fde4f06a70
    72fde4f04373:	pand   xmm14,xmm15
    72fde4f04378:	movdqu xmm15,XMMWORD PTR [rip+0x26ff]        # 0x72fde4f06a80
    72fde4f04381:	pcmpeqq xmm14,xmm15
    72fde4f04387:	movdqa xmm15,xmm0
    72fde4f0438c:	cmpunordpd xmm15,xmm0
    72fde4f04392:	por    xmm14,xmm15
    72fde4f04397:	pmovmskb ecx,xmm14
    72fde4f0439c:	jrcxz  0x72fde4f043a3
    72fde4f0439e:	jmp    0x72fde4f05dc7
    72fde4f043a3:	movdqu XMMWORD PTR [r12+0x230],xmm0
    72fde4f043ad:	mov    eax,0x0
    72fde4f043b2:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f043be:	mov    rbp,rax
    72fde4f043c1:	mov    r13,QWORD PTR [r12+0xf8]
    72fde4f043c9:	add    r13,0x90
    72fde4f043d0:	mov    r14,r13
    72fde4f043d3:	add    r14,0x10
    72fde4f043d7:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    72fde4f043dd:	movdqu xmm3,XMMWORD PTR [r14]
    72fde4f043e2:	movdqu XMMWORD PTR [r12+0x140],xmm2
    72fde4f043ec:	movdqu XMMWORD PTR [r12+0x130],xmm3
    72fde4f043f6:	lea    r13,[r12]
    72fde4f043fa:	movabs r14,0x184fd61271
    72fde4f04404:	mov    r15d,0x410644
    72fde4f0440a:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    72fde4f04414:	movdqu xmm1,XMMWORD PTR [r12+0x270]
    72fde4f0441e:	pshufd xmm1,xmm1,0x44
    72fde4f04423:	movdqu xmm14,XMMWORD PTR [r12+0x220]
    72fde4f0442d:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f04432:	movdqa xmm14,xmm0
    72fde4f04437:	movdqu xmm15,XMMWORD PTR [rip+0x2630]        # 0x72fde4f06a70
    72fde4f04440:	pand   xmm14,xmm15
    72fde4f04445:	movdqu xmm15,XMMWORD PTR [rip+0x2632]        # 0x72fde4f06a80
    72fde4f0444e:	pcmpeqq xmm14,xmm15
    72fde4f04454:	movdqa xmm15,xmm0
    72fde4f04459:	cmpunordpd xmm15,xmm0
    72fde4f0445f:	por    xmm14,xmm15
    72fde4f04464:	pmovmskb ecx,xmm14
    72fde4f04469:	jrcxz  0x72fde4f04470
    72fde4f0446b:	jmp    0x72fde4f05e4d
    72fde4f04470:	movdqu XMMWORD PTR [r12+0x220],xmm0
    72fde4f0447a:	mov    eax,0x0
    72fde4f0447f:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f0448b:	mov    rbp,rax
    72fde4f0448e:	mov    r13,QWORD PTR [r12+0xf8]
    72fde4f04496:	add    r13,0x10
    72fde4f0449a:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    72fde4f044a0:	movdqu XMMWORD PTR [r12+0x240],xmm2
    72fde4f044aa:	lea    r13,[r12]
    72fde4f044ae:	movabs r14,0x184fd61040
    72fde4f044b8:	mov    r15d,0x41064c
    72fde4f044be:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    72fde4f044c8:	movdqu xmm1,XMMWORD PTR [r12+0x270]
    72fde4f044d2:	pshufd xmm1,xmm1,0x44
    72fde4f044d7:	movdqu xmm14,XMMWORD PTR [r12+0x110]
    72fde4f044e1:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f044e6:	movdqa xmm14,xmm0
    72fde4f044eb:	movdqu xmm15,XMMWORD PTR [rip+0x257c]        # 0x72fde4f06a70
    72fde4f044f4:	pand   xmm14,xmm15
    72fde4f044f9:	movdqu xmm15,XMMWORD PTR [rip+0x257e]        # 0x72fde4f06a80
    72fde4f04502:	pcmpeqq xmm14,xmm15
    72fde4f04508:	movdqa xmm15,xmm0
    72fde4f0450d:	cmpunordpd xmm15,xmm0
    72fde4f04513:	por    xmm14,xmm15
    72fde4f04518:	pmovmskb ecx,xmm14
    72fde4f0451d:	jrcxz  0x72fde4f04524
    72fde4f0451f:	jmp    0x72fde4f05ed3
    72fde4f04524:	movdqu XMMWORD PTR [r12+0x110],xmm0
    72fde4f0452e:	mov    eax,0x0
    72fde4f04533:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f0453f:	mov    rbp,rax
    72fde4f04542:	lea    r13,[r12]
    72fde4f04546:	movabs r14,0x184fd61066
    72fde4f04550:	mov    r15d,0x410650
    72fde4f04556:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    72fde4f04560:	movdqu xmm1,XMMWORD PTR [r12+0x270]
    72fde4f0456a:	pshufd xmm1,xmm1,0x44
    72fde4f0456f:	movdqu xmm14,XMMWORD PTR [r12+0x170]
    72fde4f04579:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f0457e:	movdqa xmm14,xmm0
    72fde4f04583:	movdqu xmm15,XMMWORD PTR [rip+0x24e4]        # 0x72fde4f06a70
    72fde4f0458c:	pand   xmm14,xmm15
    72fde4f04591:	movdqu xmm15,XMMWORD PTR [rip+0x24e6]        # 0x72fde4f06a80
    72fde4f0459a:	pcmpeqq xmm14,xmm15
    72fde4f045a0:	movdqa xmm15,xmm0
    72fde4f045a5:	cmpunordpd xmm15,xmm0
    72fde4f045ab:	por    xmm14,xmm15
    72fde4f045b0:	pmovmskb ecx,xmm14
    72fde4f045b5:	jrcxz  0x72fde4f045bc
    72fde4f045b7:	jmp    0x72fde4f05f59
    72fde4f045bc:	movdqu XMMWORD PTR [r12+0x170],xmm0
    72fde4f045c6:	mov    eax,0x0
    72fde4f045cb:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f045d7:	mov    rbp,rax
    72fde4f045da:	lea    r13,[r12]
    72fde4f045de:	movabs r14,0x184fd61272
    72fde4f045e8:	mov    r15d,0x410654
    72fde4f045ee:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    72fde4f045f8:	movdqu xmm1,XMMWORD PTR [r12+0x270]
    72fde4f04602:	pshufd xmm1,xmm1,0x44
    72fde4f04607:	movdqu xmm14,XMMWORD PTR [r12+0x230]
    72fde4f04611:	vfmadd213pd xmm0,xmm1,xmm14
    72fde4f04616:	movdqa xmm14,xmm0
    72fde4f0461b:	movdqu xmm15,XMMWORD PTR [rip+0x244c]        # 0x72fde4f06a70
    72fde4f04624:	pand   xmm14,xmm15
    72fde4f04629:	movdqu xmm15,XMMWORD PTR [rip+0x244e]        # 0x72fde4f06a80
    72fde4f04632:	pcmpeqq xmm14,xmm15
    72fde4f04638:	movdqa xmm15,xmm0
    72fde4f0463d:	cmpunordpd xmm15,xmm0
    72fde4f04643:	por    xmm14,xmm15
    72fde4f04648:	pmovmskb ecx,xmm14
    72fde4f0464d:	jrcxz  0x72fde4f04654
    72fde4f0464f:	jmp    0x72fde4f05fdf
    72fde4f04654:	movdqu XMMWORD PTR [r12+0x230],xmm0
    72fde4f0465e:	mov    eax,0x0
    72fde4f04663:	mov    DWORD PTR [r12+0x324],0x0
    72fde4f0466f:	mov    rbp,rax
    72fde4f04672:	mov    r13,QWORD PTR [r12+0x60]
    72fde4f04677:	mov    r14,r13
    72fde4f0467a:	add    r14,0x10
    72fde4f0467e:	movdqu xmm2,XMMWORD PTR [r12+0x110]
    72fde4f04688:	movdqu xmm3,XMMWORD PTR [r12+0x170]
    72fde4f04692:	movdqu XMMWORD PTR [r13+0x0],xmm2
    72fde4f04698:	mov    r15d,0x0
    72fde4f0469e:	mov    DWORD PTR [r12+0x32c],r15d
    72fde4f046a6:	movdqu XMMWORD PTR [r14],xmm3
    72fde4f046ab:	add    r13,0x20
    72fde4f046af:	mov    r14,r13
    72fde4f046b2:	add    r14,0x10
    72fde4f046b6:	movdqu xmm2,XMMWORD PTR [r12+0x220]
    72fde4f046c0:	movdqu xmm3,XMMWORD PTR [r12+0x230]
    72fde4f046ca:	movdqu XMMWORD PTR [r13+0x0],xmm2
    72fde4f046d0:	movdqu XMMWORD PTR [r14],xmm3
    72fde4f046d5:	mov    rcx,QWORD PTR [r12+0x380]
    72fde4f046dd:	jrcxz  0x72fde4f046e4
    72fde4f046df:	jmp    0x72fde4f0618d
    72fde4f046e4:	mov    rdx,rbx
    72fde4f046e7:	shr    rdx,0x10
    72fde4f046eb:	and    edx,0xc000
    72fde4f046f1:	mov    rax,rbx
    72fde4f046f4:	shr    rax,0x15
    72fde4f046f8:	and    eax,0x100
    72fde4f046fd:	xor    eax,0x100
    72fde4f04702:	or     edx,eax
    72fde4f04704:	mov    rax,rbx
    72fde4f04707:	shr    rax,0x1c
    72fde4f0470b:	and    eax,0x1
    72fde4f0470e:	or     edx,eax
    72fde4f04710:	mov    QWORD PTR [rsp],rdx
    72fde4f04714:	mov    rax,rbx
    72fde4f04717:	shr    rax,0x1e
    72fde4f0471b:	and    eax,0x1
    72fde4f0471e:	xor    eax,0x1
    72fde4f04721:	test   rax,rax
    72fde4f04724:	jne    0x72fde4f02c02
    72fde4f0472a:	jmp    0x72fde4f0472f
    72fde4f0472f:	mov    r13d,DWORD PTR [r12+0x48]
    72fde4f04734:	add    r13d,0x1
    72fde4f04738:	mov    QWORD PTR [r12+0x48],r13
    72fde4f0473d:	sub    r13d,0x1f4
    72fde4f04744:	mov    rcx,QWORD PTR [r12+0x380]
    72fde4f0474c:	jrcxz  0x72fde4f04753
    72fde4f0474e:	jmp    0x72fde4f061bb
    72fde4f04753:	jne    0x72fde4f02be4
    72fde4f04759:	mov    r11,rax
    72fde4f0475c:	lahf
    72fde4f0475d:	seto   al
    72fde4f04760:	mov    WORD PTR [rsp],ax
    72fde4f04764:	mov    rax,r11
    72fde4f04767:	jmp    0x72fde4f0476c
    72fde4f0476c:	mov    r13d,0x430000
    72fde4f04772:	mov    QWORD PTR [r12+0x40],r13
    72fde4f04777:	mov    r13d,0x0
    72fde4f0477d:	mov    QWORD PTR [r12+0x48],r13
    72fde4f04782:	mov    r13d,0x430c50
    72fde4f04788:	mov    r14,QWORD PTR [r13+0x0]
    72fde4f0478c:	mov    r13d,0x0
    72fde4f04792:	mov    QWORD PTR [r12+0x110],r14
    72fde4f0479a:	mov    QWORD PTR [r12+0x118],r13
    72fde4f047a2:	jmp    0x72fde4f047a7
    72fde4f047a7:	mov    r13,QWORD PTR [r12+0x48]
    72fde4f047ac:	mov    r14,QWORD PTR [r12+0x50]
    72fde4f047b1:	add    r14,r13
    72fde4f047b4:	movdqu xmm2,XMMWORD PTR [r14]
    72fde4f047b9:	movdqu XMMWORD PTR [r12+0x120],xmm2
    72fde4f047c3:	add    r13,0x10
    72fde4f047c7:	mov    QWORD PTR [r12+0x48],r13
    72fde4f047cc:	sub    r13,0x200
    72fde4f047d3:	mov    r13,QWORD PTR [r12+0x128]
    72fde4f047db:	mov    r14d,0x0
    72fde4f047e1:	mov    QWORD PTR [r12+0x130],r13
    72fde4f047e9:	mov    QWORD PTR [r12+0x138],r14
    72fde4f047f1:	movdqu xmm2,XMMWORD PTR [r12+0x110]
    72fde4f047fb:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    72fde4f04805:	movdqa xmm0,xmm2
    72fde4f04809:	movdqa xmm1,xmm3
    72fde4f0480d:	movq   xmm0,xmm0
    72fde4f04811:	movq   xmm1,xmm1
    72fde4f04815:	addsd  xmm0,xmm1
    72fde4f04819:	movdqa xmm14,xmm0
    72fde4f0481e:	movdqu xmm15,XMMWORD PTR [rip+0x2249]        # 0x72fde4f06a70
    72fde4f04827:	pand   xmm14,xmm15
    72fde4f0482c:	movdqu xmm15,XMMWORD PTR [rip+0x224b]        # 0x72fde4f06a80
    72fde4f04835:	pcmpeqq xmm14,xmm15
    72fde4f0483b:	movdqa xmm15,xmm0
    72fde4f04840:	cmpunordpd xmm15,xmm0
    72fde4f04846:	por    xmm14,xmm15
    72fde4f0484b:	pmovmskb ecx,xmm14
    72fde4f04850:	jrcxz  0x72fde4f04857
    72fde4f04852:	jmp    0x72fde4f04b9d
    72fde4f04857:	movdqa xmm4,xmm0
    72fde4f0485b:	movdqu xmm2,XMMWORD PTR [r12+0x130]
    72fde4f04865:	movdqa xmm0,xmm4
    72fde4f04869:	movdqa xmm1,xmm2
    72fde4f0486d:	movq   xmm0,xmm0
    72fde4f04871:	movq   xmm1,xmm1
    72fde4f04875:	addsd  xmm0,xmm1
    72fde4f04879:	movdqa xmm14,xmm0
    72fde4f0487e:	movdqu xmm15,XMMWORD PTR [rip+0x21e9]        # 0x72fde4f06a70
    72fde4f04887:	pand   xmm14,xmm15
    72fde4f0488c:	movdqu xmm15,XMMWORD PTR [rip+0x21eb]        # 0x72fde4f06a80
    72fde4f04895:	pcmpeqq xmm14,xmm15
    72fde4f0489b:	movdqa xmm15,xmm0
    72fde4f048a0:	cmpunordpd xmm15,xmm0
    72fde4f048a6:	por    xmm14,xmm15
    72fde4f048ab:	pmovmskb ecx,xmm14
    72fde4f048b0:	jrcxz  0x72fde4f048b7
    72fde4f048b2:	jmp    0x72fde4f04bdc
    72fde4f048b7:	movdqa xmm3,xmm0
    72fde4f048bb:	movdqu XMMWORD PTR [r12+0x110],xmm3
    72fde4f048c5:	mov    rcx,QWORD PTR [r12+0x380]
    72fde4f048cd:	jrcxz  0x72fde4f048d4
    72fde4f048cf:	jmp    0x72fde4f0624f
    72fde4f048d4:	jne    0x72fde4f048ed
    72fde4f048da:	mov    r11,rax
    72fde4f048dd:	lahf
    72fde4f048de:	seto   al
    72fde4f048e1:	mov    WORD PTR [rsp],ax
    72fde4f048e5:	mov    rax,r11
    72fde4f048e8:	jmp    0x72fde4f04900
    72fde4f048ed:	mov    r11,rax
    72fde4f048f0:	lahf
    72fde4f048f1:	seto   al
    72fde4f048f4:	mov    WORD PTR [rsp],ax
    72fde4f048f8:	mov    rax,r11
    72fde4f048fb:	jmp    0x72fde4f047a7
    72fde4f04900:	mov    r13,QWORD PTR [r12+0xf8]
    72fde4f04908:	mov    r14,r13
    72fde4f0490b:	add    r14,0x1a0
    72fde4f04912:	mov    r15,r14
    72fde4f04915:	add    r15,0x8
    72fde4f04919:	mov    rbp,QWORD PTR [r14]
    72fde4f0491c:	mov    r14,QWORD PTR [r15]
    72fde4f0491f:	mov    QWORD PTR [r12+0xa0],rbp
    72fde4f04927:	mov    QWORD PTR [r12+0x98],r14
    72fde4f0492f:	mov    r14,QWORD PTR [r12+0x40]
    72fde4f04934:	add    r14,0xc50
    72fde4f0493b:	mov    r15,QWORD PTR [r12+0x110]
    72fde4f04943:	mov    QWORD PTR [r14],r15
    72fde4f04946:	mov    r14d,0x0
    72fde4f0494c:	mov    DWORD PTR [r12+0x32c],r14d
    72fde4f04954:	mov    r14,r13
    72fde4f04957:	add    r14,0x190
    72fde4f0495e:	mov    r15,r14
    72fde4f04961:	add    r15,0x8
    72fde4f04965:	mov    rbp,QWORD PTR [r14]
    72fde4f04968:	mov    r14,QWORD PTR [r15]
    72fde4f0496b:	mov    QWORD PTR [r12+0xe8],rbp
    72fde4f04973:	mov    QWORD PTR [r12+0xf0],r14
    72fde4f0497b:	mov    r14,r13
    72fde4f0497e:	add    r14,0x180
    72fde4f04985:	mov    r15,r14
    72fde4f04988:	add    r15,0x8
    72fde4f0498c:	mov    rbp,QWORD PTR [r14]
    72fde4f0498f:	mov    r14,QWORD PTR [r15]
    72fde4f04992:	mov    r15d,0x0
    72fde4f04998:	mov    QWORD PTR [r12+0x1a0],rbp
    72fde4f049a0:	mov    QWORD PTR [r12+0x1a8],r15
    72fde4f049a8:	mov    r15d,0x0
    72fde4f049ae:	mov    QWORD PTR [r12+0x190],r14
    72fde4f049b6:	mov    QWORD PTR [r12+0x198],r15
    72fde4f049be:	mov    r14,r13
    72fde4f049c1:	add    r14,0x170
    72fde4f049c8:	mov    r15,r14
    72fde4f049cb:	add    r15,0x8
    72fde4f049cf:	mov    rbp,QWORD PTR [r14]
    72fde4f049d2:	mov    r14,QWORD PTR [r15]
    72fde4f049d5:	mov    r15d,0x0
    72fde4f049db:	mov    QWORD PTR [r12+0x1c0],rbp
    72fde4f049e3:	mov    QWORD PTR [r12+0x1c8],r15
    72fde4f049eb:	mov    r15d,0x0
    72fde4f049f1:	mov    QWORD PTR [r12+0x1b0],r14
    72fde4f049f9:	mov    QWORD PTR [r12+0x1b8],r15
    72fde4f04a01:	mov    r14,r13
    72fde4f04a04:	add    r14,0x160
    72fde4f04a0b:	mov    r15,r14
    72fde4f04a0e:	add    r15,0x8
    72fde4f04a12:	mov    rbp,QWORD PTR [r14]
    72fde4f04a15:	mov    r14,QWORD PTR [r15]
    72fde4f04a18:	mov    r15d,0x0
    72fde4f04a1e:	mov    QWORD PTR [r12+0x1e0],rbp
    72fde4f04a26:	mov    QWORD PTR [r12+0x1e8],r15
    72fde4f04a2e:	mov    r15d,0x0
    72fde4f04a34:	mov    QWORD PTR [r12+0x1d0],r14
    72fde4f04a3c:	mov    QWORD PTR [r12+0x1d8],r15
    72fde4f04a44:	mov    r14,r13
    72fde4f04a47:	add    r14,0x150
    72fde4f04a4e:	mov    r15,r14
    72fde4f04a51:	add    r15,0x8
    72fde4f04a55:	mov    rbp,QWORD PTR [r14]
    72fde4f04a58:	mov    r14,QWORD PTR [r15]
    72fde4f04a5b:	mov    r15d,0x0
    72fde4f04a61:	mov    QWORD PTR [r12+0x200],rbp
    72fde4f04a69:	mov    QWORD PTR [r12+0x208],r15
    72fde4f04a71:	mov    r15d,0x0
    72fde4f04a77:	mov    QWORD PTR [r12+0x1f0],r14
    72fde4f04a7f:	mov    QWORD PTR [r12+0x1f8],r15
    72fde4f04a87:	add    r13,0x1b0
    72fde4f04a8e:	mov    QWORD PTR [r12+0xf8],r13
    72fde4f04a96:	mov    rcx,QWORD PTR [r12+0x380]
    72fde4f04a9e:	jrcxz  0x72fde4f04aa5
    72fde4f04aa0:	jmp    0x72fde4f062e3
    72fde4f04aa5:	mov    r13,QWORD PTR [r12+0xf0]
    72fde4f04aad:	mov    QWORD PTR [r12+0x100],r13
    72fde4f04ab5:	mov    r11,QWORD PTR [rsp]
    72fde4f04ab9:	mov    QWORD PTR [r12+0x398],r11
    72fde4f04ac1:	mov    rdi,QWORD PTR [r12+0x100]
    72fde4f04ac9:	add    rsp,0x150
    72fde4f04ad0:	movabs r11,0x5ccd9ef50940
    72fde4f04ada:	jmp    r11
    72fde4f04add:	mov    r13d,DWORD PTR [r12+0x98]
    72fde4f04ae5:	mov    r14d,DWORD PTR [r12]
    72fde4f04ae9:	add    r14d,r13d
    72fde4f04aec:	mov    QWORD PTR [r12],r14
    72fde4f04af0:	mov    r13d,0x4103e8
    72fde4f04af6:	mov    QWORD PTR [r12+0xf0],r13
    72fde4f04afe:	mov    r13d,0x410938
    72fde4f04b04:	mov    QWORD PTR [r12+0x100],r13
    72fde4f04b0c:	mov    r11,QWORD PTR [rsp]
    72fde4f04b10:	mov    QWORD PTR [r12+0x398],r11
    72fde4f04b18:	mov    edi,0x410938
    72fde4f04b1d:	mov    QWORD PTR [r12+0x100],rdi
    72fde4f04b25:	add    rsp,0x150
    72fde4f04b2c:	nop    DWORD PTR [rax+0x0]
    72fde4f04b30:	jmp    QWORD PTR [rip+0x2]        # 0x72fde4f04b38
    72fde4f04b36:	xchg   ax,ax
    72fde4f04b38:	xor    BYTE PTR [rdi],dl
    72fde4f04b3a:	lock in al,0xfd
    72fde4f04b3d:	jb     0x72fde4f04b3f
    72fde4f04b3f:	add    BYTE PTR [rax+0x4b],cl
    72fde4f04b42:	lock in al,0xfd
    72fde4f04b45:	jb     0x72fde4f04b47
    72fde4f04b47:	add    BYTE PTR [rcx-0x45],cl
    72fde4f04b4a:	rex or ebp,esi
    72fde4f04b4d:	sahf
    72fde4f04b4e:	int    0x5c
    72fde4f04b50:	add    BYTE PTR [rax],al
    72fde4f04b52:	jmp    r11
    72fde4f04b55:	movdqa xmm0,xmm2
    72fde4f04b59:	movdqa xmm1,xmm3
    72fde4f04b5d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72fde4f04b66:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72fde4f04b6f:	call   0x72fde4f04c20
    72fde4f04b74:	jmp    0x72fde4f02743
    72fde4f04b79:	movdqa xmm0,xmm2
    72fde4f04b7d:	movdqa xmm1,xmm3
    72fde4f04b81:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72fde4f04b8a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72fde4f04b93:	call   0x72fde4f04c20
    72fde4f04b98:	jmp    0x72fde4f027cf
    72fde4f04b9d:	mov    r11,rax
    72fde4f04ba0:	lahf
    72fde4f04ba1:	seto   al
    72fde4f04ba4:	mov    WORD PTR [rsp],ax
    72fde4f04ba8:	mov    rax,r11
    72fde4f04bab:	movdqa xmm0,xmm2
    72fde4f04baf:	movdqa xmm1,xmm3
    72fde4f04bb3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72fde4f04bbc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72fde4f04bc5:	call   0x72fde4f04cf0
    72fde4f04bca:	mov    r11,rax
    72fde4f04bcd:	movzx  eax,WORD PTR [rsp]
    72fde4f04bd1:	add    al,0x7f
    72fde4f04bd3:	sahf
    72fde4f04bd4:	mov    rax,r11
    72fde4f04bd7:	jmp    0x72fde4f04857
    72fde4f04bdc:	mov    r11,rax
    72fde4f04bdf:	lahf
    72fde4f04be0:	seto   al
    72fde4f04be3:	mov    WORD PTR [rsp],ax
    72fde4f04be7:	mov    rax,r11
    72fde4f04bea:	movdqa xmm0,xmm4
    72fde4f04bee:	movdqa xmm1,xmm2
    72fde4f04bf2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    72fde4f04bfb:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    72fde4f04c04:	call   0x72fde4f04e50
    72fde4f04c09:	mov    r11,rax
    72fde4f04c0c:	movzx  eax,WORD PTR [rsp]
    72fde4f04c10:	add    al,0x7f
    72fde4f04c12:	sahf
    72fde4f04c13:	mov    rax,r11
    72fde4f04c16:	jmp    0x72fde4f048b7
    72fde4f04c1b:	nop    DWORD PTR [rax+rax*1+0x0]
    72fde4f04c20:	sub    rsp,0x8
    72fde4f04c24:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f04c30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72fde4f04c36:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72fde4f04c3c:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f04c44:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f04c4a:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f04c4f:	test   r10d,0x3f
    72fde4f04c56:	je     0x72fde4f04c7b
    72fde4f04c5c:	mov    r11d,r10d
    72fde4f04c5f:	shr    r10d,1
    72fde4f04c62:	and    r10d,0x1e
    72fde4f04c66:	and    r11d,0x1
    72fde4f04c6a:	or     r10d,r11d
    72fde4f04c6d:	or     DWORD PTR [r12+0x314],r10d
    72fde4f04c75:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f04c7b:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f04c81:	lea    rdi,[rsp+0x110]
    72fde4f04c89:	lea    rsi,[rsp+0xf0]
    72fde4f04c91:	lea    rdx,[rsp+0x100]
    72fde4f04c99:	mov    ecx,0x16
    72fde4f04c9e:	mov    r8d,0x0
    72fde4f04ca4:	lea    r9,[r12+0x314]
    72fde4f04cac:	movabs r11,0x5ccd9edb7650
    72fde4f04cb6:	call   r11
    72fde4f04cb9:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f04cbf:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72fde4f04cc5:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72fde4f04ccb:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f04cd3:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f04cdf:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72fde4f04ce8:	add    rsp,0x8
    72fde4f04cec:	ret
    72fde4f04ced:	nop    DWORD PTR [rax]
    72fde4f04cf0:	sub    rsp,0x8
    72fde4f04cf4:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f04d00:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72fde4f04d06:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    72fde4f04d0c:	push   rdx
    72fde4f04d0d:	push   rsi
    72fde4f04d0e:	push   r10
    72fde4f04d10:	push   r11
    72fde4f04d12:	mov    rdx,QWORD PTR [rsp+0x30]
    72fde4f04d17:	mov    r10d,edx
    72fde4f04d1a:	and    r10d,0xc000
    72fde4f04d21:	shl    r10d,0x10
    72fde4f04d25:	mov    r11d,edx
    72fde4f04d28:	and    r11d,0x100
    72fde4f04d2f:	shl    r11d,0x15
    72fde4f04d33:	or     r10d,r11d
    72fde4f04d36:	and    edx,0x1
    72fde4f04d39:	shl    edx,0x1c
    72fde4f04d3c:	or     r10d,edx
    72fde4f04d3f:	btc    r10,0x1d
    72fde4f04d44:	mov    r11d,0xf0000000
    72fde4f04d4a:	and    r11,r10
    72fde4f04d4d:	movabs rsi,0xffffffff0fffffff
    72fde4f04d57:	and    rbx,rsi
    72fde4f04d5a:	or     rbx,r11
    72fde4f04d5d:	pop    r11
    72fde4f04d5f:	pop    r10
    72fde4f04d61:	pop    rsi
    72fde4f04d62:	pop    rdx
    72fde4f04d63:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f04d6b:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f04d71:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f04d76:	test   r10d,0x3f
    72fde4f04d7d:	je     0x72fde4f04da2
    72fde4f04d83:	mov    r11d,r10d
    72fde4f04d86:	shr    r10d,1
    72fde4f04d89:	and    r10d,0x1e
    72fde4f04d8d:	and    r11d,0x1
    72fde4f04d91:	or     r10d,r11d
    72fde4f04d94:	or     DWORD PTR [r12+0x314],r10d
    72fde4f04d9c:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f04da2:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f04da8:	lea    rdi,[rsp+0x110]
    72fde4f04db0:	lea    rsi,[rsp+0xf0]
    72fde4f04db8:	lea    rdx,[rsp+0x100]
    72fde4f04dc0:	mov    ecx,0xc
    72fde4f04dc5:	mov    r8d,0x0
    72fde4f04dcb:	lea    r9,[r12+0x314]
    72fde4f04dd3:	movabs r11,0x5ccd9edb7650
    72fde4f04ddd:	call   r11
    72fde4f04de0:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f04de6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72fde4f04dec:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    72fde4f04df2:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f04dfa:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f04e06:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72fde4f04e0f:	mov    rdx,rbx
    72fde4f04e12:	shr    rdx,0x10
    72fde4f04e16:	and    edx,0xc000
    72fde4f04e1c:	mov    rax,rbx
    72fde4f04e1f:	shr    rax,0x15
    72fde4f04e23:	and    eax,0x100
    72fde4f04e28:	xor    eax,0x100
    72fde4f04e2d:	or     edx,eax
    72fde4f04e2f:	mov    rax,rbx
    72fde4f04e32:	shr    rax,0x1c
    72fde4f04e36:	and    eax,0x1
    72fde4f04e39:	or     edx,eax
    72fde4f04e3b:	mov    QWORD PTR [rsp+0x10],rdx
    72fde4f04e40:	add    rsp,0x8
    72fde4f04e44:	ret
    72fde4f04e45:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72fde4f04e50:	sub    rsp,0x8
    72fde4f04e54:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f04e60:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    72fde4f04e66:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    72fde4f04e6c:	push   rdx
    72fde4f04e6d:	push   rsi
    72fde4f04e6e:	push   r10
    72fde4f04e70:	push   r11
    72fde4f04e72:	mov    rdx,QWORD PTR [rsp+0x30]
    72fde4f04e77:	mov    r10d,edx
    72fde4f04e7a:	and    r10d,0xc000
    72fde4f04e81:	shl    r10d,0x10
    72fde4f04e85:	mov    r11d,edx
    72fde4f04e88:	and    r11d,0x100
    72fde4f04e8f:	shl    r11d,0x15
    72fde4f04e93:	or     r10d,r11d
    72fde4f04e96:	and    edx,0x1
    72fde4f04e99:	shl    edx,0x1c
    72fde4f04e9c:	or     r10d,edx
    72fde4f04e9f:	btc    r10,0x1d
    72fde4f04ea4:	mov    r11d,0xf0000000
    72fde4f04eaa:	and    r11,r10
    72fde4f04ead:	movabs rsi,0xffffffff0fffffff
    72fde4f04eb7:	and    rbx,rsi
    72fde4f04eba:	or     rbx,r11
    72fde4f04ebd:	pop    r11
    72fde4f04ebf:	pop    r10
    72fde4f04ec1:	pop    rsi
    72fde4f04ec2:	pop    rdx
    72fde4f04ec3:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f04ecb:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f04ed1:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f04ed6:	test   r10d,0x3f
    72fde4f04edd:	je     0x72fde4f04f02
    72fde4f04ee3:	mov    r11d,r10d
    72fde4f04ee6:	shr    r10d,1
    72fde4f04ee9:	and    r10d,0x1e
    72fde4f04eed:	and    r11d,0x1
    72fde4f04ef1:	or     r10d,r11d
    72fde4f04ef4:	or     DWORD PTR [r12+0x314],r10d
    72fde4f04efc:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f04f02:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f04f08:	lea    rdi,[rsp+0x110]
    72fde4f04f10:	lea    rsi,[rsp+0xf0]
    72fde4f04f18:	lea    rdx,[rsp+0x100]
    72fde4f04f20:	mov    ecx,0xc
    72fde4f04f25:	mov    r8d,0x0
    72fde4f04f2b:	lea    r9,[r12+0x314]
    72fde4f04f33:	movabs r11,0x5ccd9edb7650
    72fde4f04f3d:	call   r11
    72fde4f04f40:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f04f46:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    72fde4f04f4c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    72fde4f04f52:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f04f5a:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f04f66:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    72fde4f04f6f:	mov    rdx,rbx
    72fde4f04f72:	shr    rdx,0x10
    72fde4f04f76:	and    edx,0xc000
    72fde4f04f7c:	mov    rax,rbx
    72fde4f04f7f:	shr    rax,0x15
    72fde4f04f83:	and    eax,0x100
    72fde4f04f88:	xor    eax,0x100
    72fde4f04f8d:	or     edx,eax
    72fde4f04f8f:	mov    rax,rbx
    72fde4f04f92:	shr    rax,0x1c
    72fde4f04f96:	and    eax,0x1
    72fde4f04f99:	or     edx,eax
    72fde4f04f9b:	mov    QWORD PTR [rsp+0x10],rdx
    72fde4f04fa0:	add    rsp,0x8
    72fde4f04fa4:	ret
    72fde4f04fa5:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f04fb1:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f04fb9:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f04fbf:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f04fc4:	test   r10d,0x3f
    72fde4f04fcb:	je     0x72fde4f04ff0
    72fde4f04fd1:	mov    r11d,r10d
    72fde4f04fd4:	shr    r10d,1
    72fde4f04fd7:	and    r10d,0x1e
    72fde4f04fdb:	and    r11d,0x1
    72fde4f04fdf:	or     r10d,r11d
    72fde4f04fe2:	or     DWORD PTR [r12+0x314],r10d
    72fde4f04fea:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f04ff0:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f04ff6:	movabs r11,0x5ccd9edb25e0
    72fde4f05000:	mov    rdi,r13
    72fde4f05003:	mov    rsi,r14
    72fde4f05006:	mov    rdx,r15
    72fde4f05009:	call   r11
    72fde4f0500c:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f05012:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f0501a:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f05026:	jmp    0x72fde4f02fce
    72fde4f0502b:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f05037:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f0503f:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f05045:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f0504a:	test   r10d,0x3f
    72fde4f05051:	je     0x72fde4f05076
    72fde4f05057:	mov    r11d,r10d
    72fde4f0505a:	shr    r10d,1
    72fde4f0505d:	and    r10d,0x1e
    72fde4f05061:	and    r11d,0x1
    72fde4f05065:	or     r10d,r11d
    72fde4f05068:	or     DWORD PTR [r12+0x314],r10d
    72fde4f05070:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f05076:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f0507c:	movabs r11,0x5ccd9edb25e0
    72fde4f05086:	mov    rdi,r13
    72fde4f05089:	mov    rsi,r14
    72fde4f0508c:	mov    rdx,r15
    72fde4f0508f:	call   r11
    72fde4f05092:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f05098:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f050a0:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f050ac:	jmp    0x72fde4f03061
    72fde4f050b1:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f050bd:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f050c5:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f050cb:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f050d0:	test   r10d,0x3f
    72fde4f050d7:	je     0x72fde4f050fc
    72fde4f050dd:	mov    r11d,r10d
    72fde4f050e0:	shr    r10d,1
    72fde4f050e3:	and    r10d,0x1e
    72fde4f050e7:	and    r11d,0x1
    72fde4f050eb:	or     r10d,r11d
    72fde4f050ee:	or     DWORD PTR [r12+0x314],r10d
    72fde4f050f6:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f050fc:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f05102:	movabs r11,0x5ccd9edb25e0
    72fde4f0510c:	mov    rdi,r13
    72fde4f0510f:	mov    rsi,r14
    72fde4f05112:	mov    rdx,r15
    72fde4f05115:	call   r11
    72fde4f05118:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f0511e:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f05126:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f05132:	jmp    0x72fde4f0321f
    72fde4f05137:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f05143:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f0514b:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f05151:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f05156:	test   r10d,0x3f
    72fde4f0515d:	je     0x72fde4f05182
    72fde4f05163:	mov    r11d,r10d
    72fde4f05166:	shr    r10d,1
    72fde4f05169:	and    r10d,0x1e
    72fde4f0516d:	and    r11d,0x1
    72fde4f05171:	or     r10d,r11d
    72fde4f05174:	or     DWORD PTR [r12+0x314],r10d
    72fde4f0517c:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f05182:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f05188:	movabs r11,0x5ccd9edb25e0
    72fde4f05192:	mov    rdi,r13
    72fde4f05195:	mov    rsi,r14
    72fde4f05198:	mov    rdx,r15
    72fde4f0519b:	call   r11
    72fde4f0519e:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f051a4:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f051ac:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f051b8:	jmp    0x72fde4f032d1
    72fde4f051bd:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f051c9:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f051d1:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f051d7:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f051dc:	test   r10d,0x3f
    72fde4f051e3:	je     0x72fde4f05208
    72fde4f051e9:	mov    r11d,r10d
    72fde4f051ec:	shr    r10d,1
    72fde4f051ef:	and    r10d,0x1e
    72fde4f051f3:	and    r11d,0x1
    72fde4f051f7:	or     r10d,r11d
    72fde4f051fa:	or     DWORD PTR [r12+0x314],r10d
    72fde4f05202:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f05208:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f0520e:	movabs r11,0x5ccd9edb25e0
    72fde4f05218:	mov    rdi,r13
    72fde4f0521b:	mov    rsi,r14
    72fde4f0521e:	mov    rdx,r15
    72fde4f05221:	call   r11
    72fde4f05224:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f0522a:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f05232:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f0523e:	jmp    0x72fde4f03481
    72fde4f05243:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f0524f:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f05257:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f0525d:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f05262:	test   r10d,0x3f
    72fde4f05269:	je     0x72fde4f0528e
    72fde4f0526f:	mov    r11d,r10d
    72fde4f05272:	shr    r10d,1
    72fde4f05275:	and    r10d,0x1e
    72fde4f05279:	and    r11d,0x1
    72fde4f0527d:	or     r10d,r11d
    72fde4f05280:	or     DWORD PTR [r12+0x314],r10d
    72fde4f05288:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f0528e:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f05294:	movabs r11,0x5ccd9edb25e0
    72fde4f0529e:	mov    rdi,r13
    72fde4f052a1:	mov    rsi,r14
    72fde4f052a4:	mov    rdx,r15
    72fde4f052a7:	call   r11
    72fde4f052aa:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f052b0:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f052b8:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f052c4:	jmp    0x72fde4f03519
    72fde4f052c9:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f052d5:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f052dd:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f052e3:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f052e8:	test   r10d,0x3f
    72fde4f052ef:	je     0x72fde4f05314
    72fde4f052f5:	mov    r11d,r10d
    72fde4f052f8:	shr    r10d,1
    72fde4f052fb:	and    r10d,0x1e
    72fde4f052ff:	and    r11d,0x1
    72fde4f05303:	or     r10d,r11d
    72fde4f05306:	or     DWORD PTR [r12+0x314],r10d
    72fde4f0530e:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f05314:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f0531a:	movabs r11,0x5ccd9edb25e0
    72fde4f05324:	mov    rdi,r13
    72fde4f05327:	mov    rsi,r14
    72fde4f0532a:	mov    rdx,r15
    72fde4f0532d:	call   r11
    72fde4f05330:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f05336:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f0533e:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f0534a:	jmp    0x72fde4f035b1
    72fde4f0534f:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f0535b:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f05363:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f05369:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f0536e:	test   r10d,0x3f
    72fde4f05375:	je     0x72fde4f0539a
    72fde4f0537b:	mov    r11d,r10d
    72fde4f0537e:	shr    r10d,1
    72fde4f05381:	and    r10d,0x1e
    72fde4f05385:	and    r11d,0x1
    72fde4f05389:	or     r10d,r11d
    72fde4f0538c:	or     DWORD PTR [r12+0x314],r10d
    72fde4f05394:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f0539a:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f053a0:	movabs r11,0x5ccd9edb25e0
    72fde4f053aa:	mov    rdi,r13
    72fde4f053ad:	mov    rsi,r14
    72fde4f053b0:	mov    rdx,r15
    72fde4f053b3:	call   r11
    72fde4f053b6:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f053bc:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f053c4:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f053d0:	jmp    0x72fde4f03665
    72fde4f053d5:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f053e1:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f053e9:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f053ef:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f053f4:	test   r10d,0x3f
    72fde4f053fb:	je     0x72fde4f05420
    72fde4f05401:	mov    r11d,r10d
    72fde4f05404:	shr    r10d,1
    72fde4f05407:	and    r10d,0x1e
    72fde4f0540b:	and    r11d,0x1
    72fde4f0540f:	or     r10d,r11d
    72fde4f05412:	or     DWORD PTR [r12+0x314],r10d
    72fde4f0541a:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f05420:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f05426:	movabs r11,0x5ccd9edb25e0
    72fde4f05430:	mov    rdi,r13
    72fde4f05433:	mov    rsi,r14
    72fde4f05436:	mov    rdx,r15
    72fde4f05439:	call   r11
    72fde4f0543c:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f05442:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f0544a:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f05456:	jmp    0x72fde4f0376d
    72fde4f0545b:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f05467:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f0546f:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f05475:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f0547a:	test   r10d,0x3f
    72fde4f05481:	je     0x72fde4f054a6
    72fde4f05487:	mov    r11d,r10d
    72fde4f0548a:	shr    r10d,1
    72fde4f0548d:	and    r10d,0x1e
    72fde4f05491:	and    r11d,0x1
    72fde4f05495:	or     r10d,r11d
    72fde4f05498:	or     DWORD PTR [r12+0x314],r10d
    72fde4f054a0:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f054a6:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f054ac:	movabs r11,0x5ccd9edb25e0
    72fde4f054b6:	mov    rdi,r13
    72fde4f054b9:	mov    rsi,r14
    72fde4f054bc:	mov    rdx,r15
    72fde4f054bf:	call   r11
    72fde4f054c2:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f054c8:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f054d0:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f054dc:	jmp    0x72fde4f03805
    72fde4f054e1:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f054ed:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f054f5:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f054fb:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f05500:	test   r10d,0x3f
    72fde4f05507:	je     0x72fde4f0552c
    72fde4f0550d:	mov    r11d,r10d
    72fde4f05510:	shr    r10d,1
    72fde4f05513:	and    r10d,0x1e
    72fde4f05517:	and    r11d,0x1
    72fde4f0551b:	or     r10d,r11d
    72fde4f0551e:	or     DWORD PTR [r12+0x314],r10d
    72fde4f05526:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f0552c:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f05532:	movabs r11,0x5ccd9edb25e0
    72fde4f0553c:	mov    rdi,r13
    72fde4f0553f:	mov    rsi,r14
    72fde4f05542:	mov    rdx,r15
    72fde4f05545:	call   r11
    72fde4f05548:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f0554e:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f05556:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f05562:	jmp    0x72fde4f0389d
    72fde4f05567:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f05573:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f0557b:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f05581:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f05586:	test   r10d,0x3f
    72fde4f0558d:	je     0x72fde4f055b2
    72fde4f05593:	mov    r11d,r10d
    72fde4f05596:	shr    r10d,1
    72fde4f05599:	and    r10d,0x1e
    72fde4f0559d:	and    r11d,0x1
    72fde4f055a1:	or     r10d,r11d
    72fde4f055a4:	or     DWORD PTR [r12+0x314],r10d
    72fde4f055ac:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f055b2:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f055b8:	movabs r11,0x5ccd9edb25e0
    72fde4f055c2:	mov    rdi,r13
    72fde4f055c5:	mov    rsi,r14
    72fde4f055c8:	mov    rdx,r15
    72fde4f055cb:	call   r11
    72fde4f055ce:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f055d4:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f055dc:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f055e8:	jmp    0x72fde4f03935
    72fde4f055ed:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f055f9:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f05601:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f05607:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f0560c:	test   r10d,0x3f
    72fde4f05613:	je     0x72fde4f05638
    72fde4f05619:	mov    r11d,r10d
    72fde4f0561c:	shr    r10d,1
    72fde4f0561f:	and    r10d,0x1e
    72fde4f05623:	and    r11d,0x1
    72fde4f05627:	or     r10d,r11d
    72fde4f0562a:	or     DWORD PTR [r12+0x314],r10d
    72fde4f05632:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f05638:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f0563e:	movabs r11,0x5ccd9edb25e0
    72fde4f05648:	mov    rdi,r13
    72fde4f0564b:	mov    rsi,r14
    72fde4f0564e:	mov    rdx,r15
    72fde4f05651:	call   r11
    72fde4f05654:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f0565a:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f05662:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f0566e:	jmp    0x72fde4f03a05
    72fde4f05673:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f0567f:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f05687:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f0568d:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f05692:	test   r10d,0x3f
    72fde4f05699:	je     0x72fde4f056be
    72fde4f0569f:	mov    r11d,r10d
    72fde4f056a2:	shr    r10d,1
    72fde4f056a5:	and    r10d,0x1e
    72fde4f056a9:	and    r11d,0x1
    72fde4f056ad:	or     r10d,r11d
    72fde4f056b0:	or     DWORD PTR [r12+0x314],r10d
    72fde4f056b8:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f056be:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f056c4:	movabs r11,0x5ccd9edb25e0
    72fde4f056ce:	mov    rdi,r13
    72fde4f056d1:	mov    rsi,r14
    72fde4f056d4:	mov    rdx,r15
    72fde4f056d7:	call   r11
    72fde4f056da:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f056e0:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f056e8:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f056f4:	jmp    0x72fde4f03a9d
    72fde4f056f9:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f05705:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f0570d:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f05713:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f05718:	test   r10d,0x3f
    72fde4f0571f:	je     0x72fde4f05744
    72fde4f05725:	mov    r11d,r10d
    72fde4f05728:	shr    r10d,1
    72fde4f0572b:	and    r10d,0x1e
    72fde4f0572f:	and    r11d,0x1
    72fde4f05733:	or     r10d,r11d
    72fde4f05736:	or     DWORD PTR [r12+0x314],r10d
    72fde4f0573e:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f05744:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f0574a:	movabs r11,0x5ccd9edb25e0
    72fde4f05754:	mov    rdi,r13
    72fde4f05757:	mov    rsi,r14
    72fde4f0575a:	mov    rdx,r15
    72fde4f0575d:	call   r11
    72fde4f05760:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f05766:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f0576e:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f0577a:	jmp    0x72fde4f03b54
    72fde4f0577f:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f0578b:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f05793:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f05799:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f0579e:	test   r10d,0x3f
    72fde4f057a5:	je     0x72fde4f057ca
    72fde4f057ab:	mov    r11d,r10d
    72fde4f057ae:	shr    r10d,1
    72fde4f057b1:	and    r10d,0x1e
    72fde4f057b5:	and    r11d,0x1
    72fde4f057b9:	or     r10d,r11d
    72fde4f057bc:	or     DWORD PTR [r12+0x314],r10d
    72fde4f057c4:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f057ca:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f057d0:	movabs r11,0x5ccd9edb25e0
    72fde4f057da:	mov    rdi,r13
    72fde4f057dd:	mov    rsi,r14
    72fde4f057e0:	mov    rdx,r15
    72fde4f057e3:	call   r11
    72fde4f057e6:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f057ec:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f057f4:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f05800:	jmp    0x72fde4f03bec
    72fde4f05805:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f05811:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f05819:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f0581f:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f05824:	test   r10d,0x3f
    72fde4f0582b:	je     0x72fde4f05850
    72fde4f05831:	mov    r11d,r10d
    72fde4f05834:	shr    r10d,1
    72fde4f05837:	and    r10d,0x1e
    72fde4f0583b:	and    r11d,0x1
    72fde4f0583f:	or     r10d,r11d
    72fde4f05842:	or     DWORD PTR [r12+0x314],r10d
    72fde4f0584a:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f05850:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f05856:	movabs r11,0x5ccd9edb25e0
    72fde4f05860:	mov    rdi,r13
    72fde4f05863:	mov    rsi,r14
    72fde4f05866:	mov    rdx,r15
    72fde4f05869:	call   r11
    72fde4f0586c:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f05872:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f0587a:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f05886:	jmp    0x72fde4f03cd2
    72fde4f0588b:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f05897:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f0589f:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f058a5:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f058aa:	test   r10d,0x3f
    72fde4f058b1:	je     0x72fde4f058d6
    72fde4f058b7:	mov    r11d,r10d
    72fde4f058ba:	shr    r10d,1
    72fde4f058bd:	and    r10d,0x1e
    72fde4f058c1:	and    r11d,0x1
    72fde4f058c5:	or     r10d,r11d
    72fde4f058c8:	or     DWORD PTR [r12+0x314],r10d
    72fde4f058d0:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f058d6:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f058dc:	movabs r11,0x5ccd9edb25e0
    72fde4f058e6:	mov    rdi,r13
    72fde4f058e9:	mov    rsi,r14
    72fde4f058ec:	mov    rdx,r15
    72fde4f058ef:	call   r11
    72fde4f058f2:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f058f8:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f05900:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f0590c:	jmp    0x72fde4f03d6a
    72fde4f05911:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f0591d:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f05925:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f0592b:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f05930:	test   r10d,0x3f
    72fde4f05937:	je     0x72fde4f0595c
    72fde4f0593d:	mov    r11d,r10d
    72fde4f05940:	shr    r10d,1
    72fde4f05943:	and    r10d,0x1e
    72fde4f05947:	and    r11d,0x1
    72fde4f0594b:	or     r10d,r11d
    72fde4f0594e:	or     DWORD PTR [r12+0x314],r10d
    72fde4f05956:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f0595c:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f05962:	movabs r11,0x5ccd9edb25e0
    72fde4f0596c:	mov    rdi,r13
    72fde4f0596f:	mov    rsi,r14
    72fde4f05972:	mov    rdx,r15
    72fde4f05975:	call   r11
    72fde4f05978:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f0597e:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f05986:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f05992:	jmp    0x72fde4f03e02
    72fde4f05997:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f059a3:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f059ab:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f059b1:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f059b6:	test   r10d,0x3f
    72fde4f059bd:	je     0x72fde4f059e2
    72fde4f059c3:	mov    r11d,r10d
    72fde4f059c6:	shr    r10d,1
    72fde4f059c9:	and    r10d,0x1e
    72fde4f059cd:	and    r11d,0x1
    72fde4f059d1:	or     r10d,r11d
    72fde4f059d4:	or     DWORD PTR [r12+0x314],r10d
    72fde4f059dc:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f059e2:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f059e8:	movabs r11,0x5ccd9edb25e0
    72fde4f059f2:	mov    rdi,r13
    72fde4f059f5:	mov    rsi,r14
    72fde4f059f8:	mov    rdx,r15
    72fde4f059fb:	call   r11
    72fde4f059fe:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f05a04:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f05a0c:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f05a18:	jmp    0x72fde4f03e9a
    72fde4f05a1d:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f05a29:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f05a31:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f05a37:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f05a3c:	test   r10d,0x3f
    72fde4f05a43:	je     0x72fde4f05a68
    72fde4f05a49:	mov    r11d,r10d
    72fde4f05a4c:	shr    r10d,1
    72fde4f05a4f:	and    r10d,0x1e
    72fde4f05a53:	and    r11d,0x1
    72fde4f05a57:	or     r10d,r11d
    72fde4f05a5a:	or     DWORD PTR [r12+0x314],r10d
    72fde4f05a62:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f05a68:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f05a6e:	movabs r11,0x5ccd9edb25e0
    72fde4f05a78:	mov    rdi,r13
    72fde4f05a7b:	mov    rsi,r14
    72fde4f05a7e:	mov    rdx,r15
    72fde4f05a81:	call   r11
    72fde4f05a84:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f05a8a:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f05a92:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f05a9e:	jmp    0x72fde4f03f64
    72fde4f05aa3:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f05aaf:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f05ab7:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f05abd:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f05ac2:	test   r10d,0x3f
    72fde4f05ac9:	je     0x72fde4f05aee
    72fde4f05acf:	mov    r11d,r10d
    72fde4f05ad2:	shr    r10d,1
    72fde4f05ad5:	and    r10d,0x1e
    72fde4f05ad9:	and    r11d,0x1
    72fde4f05add:	or     r10d,r11d
    72fde4f05ae0:	or     DWORD PTR [r12+0x314],r10d
    72fde4f05ae8:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f05aee:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f05af4:	movabs r11,0x5ccd9edb25e0
    72fde4f05afe:	mov    rdi,r13
    72fde4f05b01:	mov    rsi,r14
    72fde4f05b04:	mov    rdx,r15
    72fde4f05b07:	call   r11
    72fde4f05b0a:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f05b10:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f05b18:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f05b24:	jmp    0x72fde4f03ffc
    72fde4f05b29:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f05b35:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f05b3d:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f05b43:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f05b48:	test   r10d,0x3f
    72fde4f05b4f:	je     0x72fde4f05b74
    72fde4f05b55:	mov    r11d,r10d
    72fde4f05b58:	shr    r10d,1
    72fde4f05b5b:	and    r10d,0x1e
    72fde4f05b5f:	and    r11d,0x1
    72fde4f05b63:	or     r10d,r11d
    72fde4f05b66:	or     DWORD PTR [r12+0x314],r10d
    72fde4f05b6e:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f05b74:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f05b7a:	movabs r11,0x5ccd9edb25e0
    72fde4f05b84:	mov    rdi,r13
    72fde4f05b87:	mov    rsi,r14
    72fde4f05b8a:	mov    rdx,r15
    72fde4f05b8d:	call   r11
    72fde4f05b90:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f05b96:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f05b9e:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f05baa:	jmp    0x72fde4f04094
    72fde4f05baf:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f05bbb:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f05bc3:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f05bc9:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f05bce:	test   r10d,0x3f
    72fde4f05bd5:	je     0x72fde4f05bfa
    72fde4f05bdb:	mov    r11d,r10d
    72fde4f05bde:	shr    r10d,1
    72fde4f05be1:	and    r10d,0x1e
    72fde4f05be5:	and    r11d,0x1
    72fde4f05be9:	or     r10d,r11d
    72fde4f05bec:	or     DWORD PTR [r12+0x314],r10d
    72fde4f05bf4:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f05bfa:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f05c00:	movabs r11,0x5ccd9edb25e0
    72fde4f05c0a:	mov    rdi,r13
    72fde4f05c0d:	mov    rsi,r14
    72fde4f05c10:	mov    rdx,r15
    72fde4f05c13:	call   r11
    72fde4f05c16:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f05c1c:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f05c24:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f05c30:	jmp    0x72fde4f0412c
    72fde4f05c35:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f05c41:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f05c49:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f05c4f:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f05c54:	test   r10d,0x3f
    72fde4f05c5b:	je     0x72fde4f05c80
    72fde4f05c61:	mov    r11d,r10d
    72fde4f05c64:	shr    r10d,1
    72fde4f05c67:	and    r10d,0x1e
    72fde4f05c6b:	and    r11d,0x1
    72fde4f05c6f:	or     r10d,r11d
    72fde4f05c72:	or     DWORD PTR [r12+0x314],r10d
    72fde4f05c7a:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f05c80:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f05c86:	movabs r11,0x5ccd9edb25e0
    72fde4f05c90:	mov    rdi,r13
    72fde4f05c93:	mov    rsi,r14
    72fde4f05c96:	mov    rdx,r15
    72fde4f05c99:	call   r11
    72fde4f05c9c:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f05ca2:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f05caa:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f05cb6:	jmp    0x72fde4f041f6
    72fde4f05cbb:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f05cc7:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f05ccf:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f05cd5:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f05cda:	test   r10d,0x3f
    72fde4f05ce1:	je     0x72fde4f05d06
    72fde4f05ce7:	mov    r11d,r10d
    72fde4f05cea:	shr    r10d,1
    72fde4f05ced:	and    r10d,0x1e
    72fde4f05cf1:	and    r11d,0x1
    72fde4f05cf5:	or     r10d,r11d
    72fde4f05cf8:	or     DWORD PTR [r12+0x314],r10d
    72fde4f05d00:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f05d06:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f05d0c:	movabs r11,0x5ccd9edb25e0
    72fde4f05d16:	mov    rdi,r13
    72fde4f05d19:	mov    rsi,r14
    72fde4f05d1c:	mov    rdx,r15
    72fde4f05d1f:	call   r11
    72fde4f05d22:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f05d28:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f05d30:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f05d3c:	jmp    0x72fde4f0428e
    72fde4f05d41:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f05d4d:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f05d55:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f05d5b:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f05d60:	test   r10d,0x3f
    72fde4f05d67:	je     0x72fde4f05d8c
    72fde4f05d6d:	mov    r11d,r10d
    72fde4f05d70:	shr    r10d,1
    72fde4f05d73:	and    r10d,0x1e
    72fde4f05d77:	and    r11d,0x1
    72fde4f05d7b:	or     r10d,r11d
    72fde4f05d7e:	or     DWORD PTR [r12+0x314],r10d
    72fde4f05d86:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f05d8c:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f05d92:	movabs r11,0x5ccd9edb25e0
    72fde4f05d9c:	mov    rdi,r13
    72fde4f05d9f:	mov    rsi,r14
    72fde4f05da2:	mov    rdx,r15
    72fde4f05da5:	call   r11
    72fde4f05da8:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f05dae:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f05db6:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f05dc2:	jmp    0x72fde4f04326
    72fde4f05dc7:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f05dd3:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f05ddb:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f05de1:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f05de6:	test   r10d,0x3f
    72fde4f05ded:	je     0x72fde4f05e12
    72fde4f05df3:	mov    r11d,r10d
    72fde4f05df6:	shr    r10d,1
    72fde4f05df9:	and    r10d,0x1e
    72fde4f05dfd:	and    r11d,0x1
    72fde4f05e01:	or     r10d,r11d
    72fde4f05e04:	or     DWORD PTR [r12+0x314],r10d
    72fde4f05e0c:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f05e12:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f05e18:	movabs r11,0x5ccd9edb25e0
    72fde4f05e22:	mov    rdi,r13
    72fde4f05e25:	mov    rsi,r14
    72fde4f05e28:	mov    rdx,r15
    72fde4f05e2b:	call   r11
    72fde4f05e2e:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f05e34:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f05e3c:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f05e48:	jmp    0x72fde4f043be
    72fde4f05e4d:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f05e59:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f05e61:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f05e67:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f05e6c:	test   r10d,0x3f
    72fde4f05e73:	je     0x72fde4f05e98
    72fde4f05e79:	mov    r11d,r10d
    72fde4f05e7c:	shr    r10d,1
    72fde4f05e7f:	and    r10d,0x1e
    72fde4f05e83:	and    r11d,0x1
    72fde4f05e87:	or     r10d,r11d
    72fde4f05e8a:	or     DWORD PTR [r12+0x314],r10d
    72fde4f05e92:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f05e98:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f05e9e:	movabs r11,0x5ccd9edb25e0
    72fde4f05ea8:	mov    rdi,r13
    72fde4f05eab:	mov    rsi,r14
    72fde4f05eae:	mov    rdx,r15
    72fde4f05eb1:	call   r11
    72fde4f05eb4:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f05eba:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f05ec2:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f05ece:	jmp    0x72fde4f0448b
    72fde4f05ed3:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f05edf:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f05ee7:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f05eed:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f05ef2:	test   r10d,0x3f
    72fde4f05ef9:	je     0x72fde4f05f1e
    72fde4f05eff:	mov    r11d,r10d
    72fde4f05f02:	shr    r10d,1
    72fde4f05f05:	and    r10d,0x1e
    72fde4f05f09:	and    r11d,0x1
    72fde4f05f0d:	or     r10d,r11d
    72fde4f05f10:	or     DWORD PTR [r12+0x314],r10d
    72fde4f05f18:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f05f1e:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f05f24:	movabs r11,0x5ccd9edb25e0
    72fde4f05f2e:	mov    rdi,r13
    72fde4f05f31:	mov    rsi,r14
    72fde4f05f34:	mov    rdx,r15
    72fde4f05f37:	call   r11
    72fde4f05f3a:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f05f40:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f05f48:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f05f54:	jmp    0x72fde4f0453f
    72fde4f05f59:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f05f65:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f05f6d:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f05f73:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f05f78:	test   r10d,0x3f
    72fde4f05f7f:	je     0x72fde4f05fa4
    72fde4f05f85:	mov    r11d,r10d
    72fde4f05f88:	shr    r10d,1
    72fde4f05f8b:	and    r10d,0x1e
    72fde4f05f8f:	and    r11d,0x1
    72fde4f05f93:	or     r10d,r11d
    72fde4f05f96:	or     DWORD PTR [r12+0x314],r10d
    72fde4f05f9e:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f05fa4:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f05faa:	movabs r11,0x5ccd9edb25e0
    72fde4f05fb4:	mov    rdi,r13
    72fde4f05fb7:	mov    rsi,r14
    72fde4f05fba:	mov    rdx,r15
    72fde4f05fbd:	call   r11
    72fde4f05fc0:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f05fc6:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f05fce:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f05fda:	jmp    0x72fde4f045d7
    72fde4f05fdf:	mov    QWORD PTR [r12+0x378],0x3
    72fde4f05feb:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f05ff3:	stmxcsr DWORD PTR [r12-0x28]
    72fde4f05ff9:	mov    r10d,DWORD PTR [r12-0x28]
    72fde4f05ffe:	test   r10d,0x3f
    72fde4f06005:	je     0x72fde4f0602a
    72fde4f0600b:	mov    r11d,r10d
    72fde4f0600e:	shr    r10d,1
    72fde4f06011:	and    r10d,0x1e
    72fde4f06015:	and    r11d,0x1
    72fde4f06019:	or     r10d,r11d
    72fde4f0601c:	or     DWORD PTR [r12+0x314],r10d
    72fde4f06024:	and    DWORD PTR [r12-0x28],0xffffffc0
    72fde4f0602a:	ldmxcsr DWORD PTR [r12-0x38]
    72fde4f06030:	movabs r11,0x5ccd9edb25e0
    72fde4f0603a:	mov    rdi,r13
    72fde4f0603d:	mov    rsi,r14
    72fde4f06040:	mov    rdx,r15
    72fde4f06043:	call   r11
    72fde4f06046:	ldmxcsr DWORD PTR [r12-0x28]
    72fde4f0604c:	mov    rbx,QWORD PTR [r12+0x108]
    72fde4f06054:	mov    QWORD PTR [r12+0x378],0x2
    72fde4f06060:	jmp    0x72fde4f0466f
    72fde4f06065:	mov    eax,0x4103f0
    72fde4f0606a:	mov    QWORD PTR [r12+0x100],rax
    72fde4f06072:	push   rdx
    72fde4f06073:	push   rsi
    72fde4f06074:	push   r10
    72fde4f06076:	push   r11
    72fde4f06078:	mov    r11,rax
    72fde4f0607b:	lahf
    72fde4f0607c:	seto   al
    72fde4f0607f:	mov    WORD PTR [rsp+0x20],ax
    72fde4f06084:	mov    rax,r11
    72fde4f06087:	mov    rdx,QWORD PTR [rsp+0x20]
    72fde4f0608c:	mov    r10d,edx
    72fde4f0608f:	and    r10d,0xc000
    72fde4f06096:	shl    r10d,0x10
    72fde4f0609a:	mov    r11d,edx
    72fde4f0609d:	and    r11d,0x100
    72fde4f060a4:	shl    r11d,0x15
    72fde4f060a8:	or     r10d,r11d
    72fde4f060ab:	and    edx,0x1
    72fde4f060ae:	shl    edx,0x1c
    72fde4f060b1:	or     r10d,edx
    72fde4f060b4:	btc    r10,0x1d
    72fde4f060b9:	mov    r11d,0xf0000000
    72fde4f060bf:	and    r11,r10
    72fde4f060c2:	movabs rsi,0xffffffff0fffffff
    72fde4f060cc:	and    rbx,rsi
    72fde4f060cf:	or     rbx,r11
    72fde4f060d2:	pop    r11
    72fde4f060d4:	pop    r10
    72fde4f060d6:	pop    rsi
    72fde4f060d7:	pop    rdx
    72fde4f060d8:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f060e0:	add    rsp,0x150
    72fde4f060e7:	mov    eax,0xc
    72fde4f060ec:	movabs r11,0x5ccd9ef50ca0
    72fde4f060f6:	jmp    r11
    72fde4f060f9:	mov    eax,0x41047c
    72fde4f060fe:	mov    QWORD PTR [r12+0x100],rax
    72fde4f06106:	push   rdx
    72fde4f06107:	push   rsi
    72fde4f06108:	push   r10
    72fde4f0610a:	push   r11
    72fde4f0610c:	mov    r11,rax
    72fde4f0610f:	lahf
    72fde4f06110:	seto   al
    72fde4f06113:	mov    WORD PTR [rsp+0x20],ax
    72fde4f06118:	mov    rax,r11
    72fde4f0611b:	mov    rdx,QWORD PTR [rsp+0x20]
    72fde4f06120:	mov    r10d,edx
    72fde4f06123:	and    r10d,0xc000
    72fde4f0612a:	shl    r10d,0x10
    72fde4f0612e:	mov    r11d,edx
    72fde4f06131:	and    r11d,0x100
    72fde4f06138:	shl    r11d,0x15
    72fde4f0613c:	or     r10d,r11d
    72fde4f0613f:	and    edx,0x1
    72fde4f06142:	shl    edx,0x1c
    72fde4f06145:	or     r10d,edx
    72fde4f06148:	btc    r10,0x1d
    72fde4f0614d:	mov    r11d,0xf0000000
    72fde4f06153:	and    r11,r10
    72fde4f06156:	movabs rsi,0xffffffff0fffffff
    72fde4f06160:	and    rbx,rsi
    72fde4f06163:	or     rbx,r11
    72fde4f06166:	pop    r11
    72fde4f06168:	pop    r10
    72fde4f0616a:	pop    rsi
    72fde4f0616b:	pop    rdx
    72fde4f0616c:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f06174:	add    rsp,0x150
    72fde4f0617b:	mov    eax,0xc
    72fde4f06180:	movabs r11,0x5ccd9ef50ca0
    72fde4f0618a:	jmp    r11
    72fde4f0618d:	mov    eax,0x410660
    72fde4f06192:	mov    QWORD PTR [r12+0x100],rax
    72fde4f0619a:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f061a2:	add    rsp,0x150
    72fde4f061a9:	mov    eax,0xc
    72fde4f061ae:	movabs r11,0x5ccd9ef50ca0
    72fde4f061b8:	jmp    r11
    72fde4f061bb:	mov    eax,0x41066c
    72fde4f061c0:	mov    QWORD PTR [r12+0x100],rax
    72fde4f061c8:	push   rdx
    72fde4f061c9:	push   rsi
    72fde4f061ca:	push   r10
    72fde4f061cc:	push   r11
    72fde4f061ce:	mov    r11,rax
    72fde4f061d1:	lahf
    72fde4f061d2:	seto   al
    72fde4f061d5:	mov    WORD PTR [rsp+0x20],ax
    72fde4f061da:	mov    rax,r11
    72fde4f061dd:	mov    rdx,QWORD PTR [rsp+0x20]
    72fde4f061e2:	mov    r10d,edx
    72fde4f061e5:	and    r10d,0xc000
    72fde4f061ec:	shl    r10d,0x10
    72fde4f061f0:	mov    r11d,edx
    72fde4f061f3:	and    r11d,0x100
    72fde4f061fa:	shl    r11d,0x15
    72fde4f061fe:	or     r10d,r11d
    72fde4f06201:	and    edx,0x1
    72fde4f06204:	shl    edx,0x1c
    72fde4f06207:	or     r10d,edx
    72fde4f0620a:	btc    r10,0x1d
    72fde4f0620f:	mov    r11d,0xf0000000
    72fde4f06215:	and    r11,r10
    72fde4f06218:	movabs rsi,0xffffffff0fffffff
    72fde4f06222:	and    rbx,rsi
    72fde4f06225:	or     rbx,r11
    72fde4f06228:	pop    r11
    72fde4f0622a:	pop    r10
    72fde4f0622c:	pop    rsi
    72fde4f0622d:	pop    rdx
    72fde4f0622e:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f06236:	add    rsp,0x150
    72fde4f0623d:	mov    eax,0xc
    72fde4f06242:	movabs r11,0x5ccd9ef50ca0
    72fde4f0624c:	jmp    r11
    72fde4f0624f:	mov    eax,0x410694
    72fde4f06254:	mov    QWORD PTR [r12+0x100],rax
    72fde4f0625c:	push   rdx
    72fde4f0625d:	push   rsi
    72fde4f0625e:	push   r10
    72fde4f06260:	push   r11
    72fde4f06262:	mov    r11,rax
    72fde4f06265:	lahf
    72fde4f06266:	seto   al
    72fde4f06269:	mov    WORD PTR [rsp+0x20],ax
    72fde4f0626e:	mov    rax,r11
    72fde4f06271:	mov    rdx,QWORD PTR [rsp+0x20]
    72fde4f06276:	mov    r10d,edx
    72fde4f06279:	and    r10d,0xc000
    72fde4f06280:	shl    r10d,0x10
    72fde4f06284:	mov    r11d,edx
    72fde4f06287:	and    r11d,0x100
    72fde4f0628e:	shl    r11d,0x15
    72fde4f06292:	or     r10d,r11d
    72fde4f06295:	and    edx,0x1
    72fde4f06298:	shl    edx,0x1c
    72fde4f0629b:	or     r10d,edx
    72fde4f0629e:	btc    r10,0x1d
    72fde4f062a3:	mov    r11d,0xf0000000
    72fde4f062a9:	and    r11,r10
    72fde4f062ac:	movabs rsi,0xffffffff0fffffff
    72fde4f062b6:	and    rbx,rsi
    72fde4f062b9:	or     rbx,r11
    72fde4f062bc:	pop    r11
    72fde4f062be:	pop    r10
    72fde4f062c0:	pop    rsi
    72fde4f062c1:	pop    rdx
    72fde4f062c2:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f062ca:	add    rsp,0x150
    72fde4f062d1:	mov    eax,0xc
    72fde4f062d6:	movabs r11,0x5ccd9ef50ca0
    72fde4f062e0:	jmp    r11
    72fde4f062e3:	mov    eax,0x4106b8
    72fde4f062e8:	mov    QWORD PTR [r12+0x100],rax
    72fde4f062f0:	push   rdx
    72fde4f062f1:	push   rsi
    72fde4f062f2:	push   r10
    72fde4f062f4:	push   r11
    72fde4f062f6:	mov    rdx,QWORD PTR [rsp+0x20]
    72fde4f062fb:	mov    r10d,edx
    72fde4f062fe:	and    r10d,0xc000
    72fde4f06305:	shl    r10d,0x10
    72fde4f06309:	mov    r11d,edx
    72fde4f0630c:	and    r11d,0x100
    72fde4f06313:	shl    r11d,0x15
    72fde4f06317:	or     r10d,r11d
    72fde4f0631a:	and    edx,0x1
    72fde4f0631d:	shl    edx,0x1c
    72fde4f06320:	or     r10d,edx
    72fde4f06323:	btc    r10,0x1d
    72fde4f06328:	mov    r11d,0xf0000000
    72fde4f0632e:	and    r11,r10
    72fde4f06331:	movabs rsi,0xffffffff0fffffff
    72fde4f0633b:	and    rbx,rsi
    72fde4f0633e:	or     rbx,r11
    72fde4f06341:	pop    r11
    72fde4f06343:	pop    r10
    72fde4f06345:	pop    rsi
    72fde4f06346:	pop    rdx
    72fde4f06347:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f0634f:	add    rsp,0x150
    72fde4f06356:	mov    eax,0xc
    72fde4f0635b:	movabs r11,0x5ccd9ef50ca0
    72fde4f06365:	jmp    r11
    72fde4f06368:	nop    DWORD PTR [rax+rax*1+0x0]
    72fde4f06370:	sub    rsp,0x150
    72fde4f06377:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f0637f:	mov    QWORD PTR [rsp],r11
    72fde4f06383:	cmp    DWORD PTR [r12+0x310],0x0
    72fde4f0638c:	je     0x72fde4f06417
    72fde4f06392:	push   rdx
    72fde4f06393:	push   rsi
    72fde4f06394:	push   r10
    72fde4f06396:	push   r11
    72fde4f06398:	mov    rdx,QWORD PTR [rsp+0x20]
    72fde4f0639d:	mov    r10d,edx
    72fde4f063a0:	and    r10d,0xc000
    72fde4f063a7:	shl    r10d,0x10
    72fde4f063ab:	mov    r11d,edx
    72fde4f063ae:	and    r11d,0x100
    72fde4f063b5:	shl    r11d,0x15
    72fde4f063b9:	or     r10d,r11d
    72fde4f063bc:	and    edx,0x1
    72fde4f063bf:	shl    edx,0x1c
    72fde4f063c2:	or     r10d,edx
    72fde4f063c5:	btc    r10,0x1d
    72fde4f063ca:	mov    r11d,0xf0000000
    72fde4f063d0:	and    r11,r10
    72fde4f063d3:	movabs rsi,0xffffffff0fffffff
    72fde4f063dd:	and    rbx,rsi
    72fde4f063e0:	or     rbx,r11
    72fde4f063e3:	pop    r11
    72fde4f063e5:	pop    r10
    72fde4f063e7:	pop    rsi
    72fde4f063e8:	pop    rdx
    72fde4f063e9:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f063f1:	mov    eax,0x4103f4
    72fde4f063f6:	mov    QWORD PTR [r12+0x100],rax
    72fde4f063fe:	add    rsp,0x150
    72fde4f06405:	mov    eax,0x3
    72fde4f0640a:	movabs r11,0x5ccd9ef50ca0
    72fde4f06414:	jmp    r11
    72fde4f06417:	jmp    0x72fde4f0225d
    72fde4f0641c:	nop    DWORD PTR [rax+0x0]
    72fde4f06420:	sub    rsp,0x150
    72fde4f06427:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f0642f:	mov    QWORD PTR [rsp],r11
    72fde4f06433:	cmp    DWORD PTR [r12+0x310],0x0
    72fde4f0643c:	je     0x72fde4f064c7
    72fde4f06442:	push   rdx
    72fde4f06443:	push   rsi
    72fde4f06444:	push   r10
    72fde4f06446:	push   r11
    72fde4f06448:	mov    rdx,QWORD PTR [rsp+0x20]
    72fde4f0644d:	mov    r10d,edx
    72fde4f06450:	and    r10d,0xc000
    72fde4f06457:	shl    r10d,0x10
    72fde4f0645b:	mov    r11d,edx
    72fde4f0645e:	and    r11d,0x100
    72fde4f06465:	shl    r11d,0x15
    72fde4f06469:	or     r10d,r11d
    72fde4f0646c:	and    edx,0x1
    72fde4f0646f:	shl    edx,0x1c
    72fde4f06472:	or     r10d,edx
    72fde4f06475:	btc    r10,0x1d
    72fde4f0647a:	mov    r11d,0xf0000000
    72fde4f06480:	and    r11,r10
    72fde4f06483:	movabs rsi,0xffffffff0fffffff
    72fde4f0648d:	and    rbx,rsi
    72fde4f06490:	or     rbx,r11
    72fde4f06493:	pop    r11
    72fde4f06495:	pop    r10
    72fde4f06497:	pop    rsi
    72fde4f06498:	pop    rdx
    72fde4f06499:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f064a1:	mov    eax,0x410440
    72fde4f064a6:	mov    QWORD PTR [r12+0x100],rax
    72fde4f064ae:	add    rsp,0x150
    72fde4f064b5:	mov    eax,0x3
    72fde4f064ba:	movabs r11,0x5ccd9ef50ca0
    72fde4f064c4:	jmp    r11
    72fde4f064c7:	mov    r11,rax
    72fde4f064ca:	movzx  eax,WORD PTR [rsp]
    72fde4f064ce:	add    al,0x7f
    72fde4f064d0:	sahf
    72fde4f064d1:	mov    rax,r11
    72fde4f064d4:	jmp    0x72fde4f023d4
    72fde4f064d9:	nop    DWORD PTR [rax+0x0]
    72fde4f064e0:	sub    rsp,0x150
    72fde4f064e7:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f064ef:	mov    QWORD PTR [rsp],r11
    72fde4f064f3:	cmp    DWORD PTR [r12+0x310],0x0
    72fde4f064fc:	je     0x72fde4f06587
    72fde4f06502:	push   rdx
    72fde4f06503:	push   rsi
    72fde4f06504:	push   r10
    72fde4f06506:	push   r11
    72fde4f06508:	mov    rdx,QWORD PTR [rsp+0x20]
    72fde4f0650d:	mov    r10d,edx
    72fde4f06510:	and    r10d,0xc000
    72fde4f06517:	shl    r10d,0x10
    72fde4f0651b:	mov    r11d,edx
    72fde4f0651e:	and    r11d,0x100
    72fde4f06525:	shl    r11d,0x15
    72fde4f06529:	or     r10d,r11d
    72fde4f0652c:	and    edx,0x1
    72fde4f0652f:	shl    edx,0x1c
    72fde4f06532:	or     r10d,edx
    72fde4f06535:	btc    r10,0x1d
    72fde4f0653a:	mov    r11d,0xf0000000
    72fde4f06540:	and    r11,r10
    72fde4f06543:	movabs rsi,0xffffffff0fffffff
    72fde4f0654d:	and    rbx,rsi
    72fde4f06550:	or     rbx,r11
    72fde4f06553:	pop    r11
    72fde4f06555:	pop    r10
    72fde4f06557:	pop    rsi
    72fde4f06558:	pop    rdx
    72fde4f06559:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f06561:	mov    eax,0x410480
    72fde4f06566:	mov    QWORD PTR [r12+0x100],rax
    72fde4f0656e:	add    rsp,0x150
    72fde4f06575:	mov    eax,0x3
    72fde4f0657a:	movabs r11,0x5ccd9ef50ca0
    72fde4f06584:	jmp    r11
    72fde4f06587:	jmp    0x72fde4f02822
    72fde4f0658c:	nop    DWORD PTR [rax+0x0]
    72fde4f06590:	sub    rsp,0x150
    72fde4f06597:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f0659f:	mov    QWORD PTR [rsp],r11
    72fde4f065a3:	cmp    DWORD PTR [r12+0x310],0x0
    72fde4f065ac:	je     0x72fde4f06637
    72fde4f065b2:	push   rdx
    72fde4f065b3:	push   rsi
    72fde4f065b4:	push   r10
    72fde4f065b6:	push   r11
    72fde4f065b8:	mov    rdx,QWORD PTR [rsp+0x20]
    72fde4f065bd:	mov    r10d,edx
    72fde4f065c0:	and    r10d,0xc000
    72fde4f065c7:	shl    r10d,0x10
    72fde4f065cb:	mov    r11d,edx
    72fde4f065ce:	and    r11d,0x100
    72fde4f065d5:	shl    r11d,0x15
    72fde4f065d9:	or     r10d,r11d
    72fde4f065dc:	and    edx,0x1
    72fde4f065df:	shl    edx,0x1c
    72fde4f065e2:	or     r10d,edx
    72fde4f065e5:	btc    r10,0x1d
    72fde4f065ea:	mov    r11d,0xf0000000
    72fde4f065f0:	and    r11,r10
    72fde4f065f3:	movabs rsi,0xffffffff0fffffff
    72fde4f065fd:	and    rbx,rsi
    72fde4f06600:	or     rbx,r11
    72fde4f06603:	pop    r11
    72fde4f06605:	pop    r10
    72fde4f06607:	pop    rsi
    72fde4f06608:	pop    rdx
    72fde4f06609:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f06611:	mov    eax,0x4104ec
    72fde4f06616:	mov    QWORD PTR [r12+0x100],rax
    72fde4f0661e:	add    rsp,0x150
    72fde4f06625:	mov    eax,0x3
    72fde4f0662a:	movabs r11,0x5ccd9ef50ca0
    72fde4f06634:	jmp    r11
    72fde4f06637:	mov    r11,rax
    72fde4f0663a:	movzx  eax,WORD PTR [rsp]
    72fde4f0663e:	add    al,0x7f
    72fde4f06640:	sahf
    72fde4f06641:	mov    rax,r11
    72fde4f06644:	jmp    0x72fde4f02be4
    72fde4f06649:	nop    DWORD PTR [rax+0x0]
    72fde4f06650:	sub    rsp,0x150
    72fde4f06657:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f0665f:	mov    QWORD PTR [rsp],r11
    72fde4f06663:	cmp    DWORD PTR [r12+0x310],0x0
    72fde4f0666c:	je     0x72fde4f066f7
    72fde4f06672:	push   rdx
    72fde4f06673:	push   rsi
    72fde4f06674:	push   r10
    72fde4f06676:	push   r11
    72fde4f06678:	mov    rdx,QWORD PTR [rsp+0x20]
    72fde4f0667d:	mov    r10d,edx
    72fde4f06680:	and    r10d,0xc000
    72fde4f06687:	shl    r10d,0x10
    72fde4f0668b:	mov    r11d,edx
    72fde4f0668e:	and    r11d,0x100
    72fde4f06695:	shl    r11d,0x15
    72fde4f06699:	or     r10d,r11d
    72fde4f0669c:	and    edx,0x1
    72fde4f0669f:	shl    edx,0x1c
    72fde4f066a2:	or     r10d,edx
    72fde4f066a5:	btc    r10,0x1d
    72fde4f066aa:	mov    r11d,0xf0000000
    72fde4f066b0:	and    r11,r10
    72fde4f066b3:	movabs rsi,0xffffffff0fffffff
    72fde4f066bd:	and    rbx,rsi
    72fde4f066c0:	or     rbx,r11
    72fde4f066c3:	pop    r11
    72fde4f066c5:	pop    r10
    72fde4f066c7:	pop    rsi
    72fde4f066c8:	pop    rdx
    72fde4f066c9:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f066d1:	mov    eax,0x4104f0
    72fde4f066d6:	mov    QWORD PTR [r12+0x100],rax
    72fde4f066de:	add    rsp,0x150
    72fde4f066e5:	mov    eax,0x3
    72fde4f066ea:	movabs r11,0x5ccd9ef50ca0
    72fde4f066f4:	jmp    r11
    72fde4f066f7:	jmp    0x72fde4f02c02
    72fde4f066fc:	nop    DWORD PTR [rax+0x0]
    72fde4f06700:	sub    rsp,0x150
    72fde4f06707:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f0670f:	mov    QWORD PTR [rsp],r11
    72fde4f06713:	cmp    DWORD PTR [r12+0x310],0x0
    72fde4f0671c:	je     0x72fde4f067a7
    72fde4f06722:	push   rdx
    72fde4f06723:	push   rsi
    72fde4f06724:	push   r10
    72fde4f06726:	push   r11
    72fde4f06728:	mov    rdx,QWORD PTR [rsp+0x20]
    72fde4f0672d:	mov    r10d,edx
    72fde4f06730:	and    r10d,0xc000
    72fde4f06737:	shl    r10d,0x10
    72fde4f0673b:	mov    r11d,edx
    72fde4f0673e:	and    r11d,0x100
    72fde4f06745:	shl    r11d,0x15
    72fde4f06749:	or     r10d,r11d
    72fde4f0674c:	and    edx,0x1
    72fde4f0674f:	shl    edx,0x1c
    72fde4f06752:	or     r10d,edx
    72fde4f06755:	btc    r10,0x1d
    72fde4f0675a:	mov    r11d,0xf0000000
    72fde4f06760:	and    r11,r10
    72fde4f06763:	movabs rsi,0xffffffff0fffffff
    72fde4f0676d:	and    rbx,rsi
    72fde4f06770:	or     rbx,r11
    72fde4f06773:	pop    r11
    72fde4f06775:	pop    r10
    72fde4f06777:	pop    rsi
    72fde4f06778:	pop    rdx
    72fde4f06779:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f06781:	mov    eax,0x410664
    72fde4f06786:	mov    QWORD PTR [r12+0x100],rax
    72fde4f0678e:	add    rsp,0x150
    72fde4f06795:	mov    eax,0x3
    72fde4f0679a:	movabs r11,0x5ccd9ef50ca0
    72fde4f067a4:	jmp    r11
    72fde4f067a7:	jmp    0x72fde4f0472f
    72fde4f067ac:	nop    DWORD PTR [rax+0x0]
    72fde4f067b0:	sub    rsp,0x150
    72fde4f067b7:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f067bf:	mov    QWORD PTR [rsp],r11
    72fde4f067c3:	cmp    DWORD PTR [r12+0x310],0x0
    72fde4f067cc:	je     0x72fde4f06857
    72fde4f067d2:	push   rdx
    72fde4f067d3:	push   rsi
    72fde4f067d4:	push   r10
    72fde4f067d6:	push   r11
    72fde4f067d8:	mov    rdx,QWORD PTR [rsp+0x20]
    72fde4f067dd:	mov    r10d,edx
    72fde4f067e0:	and    r10d,0xc000
    72fde4f067e7:	shl    r10d,0x10
    72fde4f067eb:	mov    r11d,edx
    72fde4f067ee:	and    r11d,0x100
    72fde4f067f5:	shl    r11d,0x15
    72fde4f067f9:	or     r10d,r11d
    72fde4f067fc:	and    edx,0x1
    72fde4f067ff:	shl    edx,0x1c
    72fde4f06802:	or     r10d,edx
    72fde4f06805:	btc    r10,0x1d
    72fde4f0680a:	mov    r11d,0xf0000000
    72fde4f06810:	and    r11,r10
    72fde4f06813:	movabs rsi,0xffffffff0fffffff
    72fde4f0681d:	and    rbx,rsi
    72fde4f06820:	or     rbx,r11
    72fde4f06823:	pop    r11
    72fde4f06825:	pop    r10
    72fde4f06827:	pop    rsi
    72fde4f06828:	pop    rdx
    72fde4f06829:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f06831:	mov    eax,0x410670
    72fde4f06836:	mov    QWORD PTR [r12+0x100],rax
    72fde4f0683e:	add    rsp,0x150
    72fde4f06845:	mov    eax,0x3
    72fde4f0684a:	movabs r11,0x5ccd9ef50ca0
    72fde4f06854:	jmp    r11
    72fde4f06857:	jmp    0x72fde4f0476c
    72fde4f0685c:	nop    DWORD PTR [rax+0x0]
    72fde4f06860:	sub    rsp,0x150
    72fde4f06867:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f0686f:	mov    QWORD PTR [rsp],r11
    72fde4f06873:	cmp    DWORD PTR [r12+0x310],0x0
    72fde4f0687c:	je     0x72fde4f06907
    72fde4f06882:	push   rdx
    72fde4f06883:	push   rsi
    72fde4f06884:	push   r10
    72fde4f06886:	push   r11
    72fde4f06888:	mov    rdx,QWORD PTR [rsp+0x20]
    72fde4f0688d:	mov    r10d,edx
    72fde4f06890:	and    r10d,0xc000
    72fde4f06897:	shl    r10d,0x10
    72fde4f0689b:	mov    r11d,edx
    72fde4f0689e:	and    r11d,0x100
    72fde4f068a5:	shl    r11d,0x15
    72fde4f068a9:	or     r10d,r11d
    72fde4f068ac:	and    edx,0x1
    72fde4f068af:	shl    edx,0x1c
    72fde4f068b2:	or     r10d,edx
    72fde4f068b5:	btc    r10,0x1d
    72fde4f068ba:	mov    r11d,0xf0000000
    72fde4f068c0:	and    r11,r10
    72fde4f068c3:	movabs rsi,0xffffffff0fffffff
    72fde4f068cd:	and    rbx,rsi
    72fde4f068d0:	or     rbx,r11
    72fde4f068d3:	pop    r11
    72fde4f068d5:	pop    r10
    72fde4f068d7:	pop    rsi
    72fde4f068d8:	pop    rdx
    72fde4f068d9:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f068e1:	mov    eax,0x41067c
    72fde4f068e6:	mov    QWORD PTR [r12+0x100],rax
    72fde4f068ee:	add    rsp,0x150
    72fde4f068f5:	mov    eax,0x3
    72fde4f068fa:	movabs r11,0x5ccd9ef50ca0
    72fde4f06904:	jmp    r11
    72fde4f06907:	jmp    0x72fde4f047a7
    72fde4f0690c:	nop    DWORD PTR [rax+0x0]
    72fde4f06910:	sub    rsp,0x150
    72fde4f06917:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f0691f:	mov    QWORD PTR [rsp],r11
    72fde4f06923:	cmp    DWORD PTR [r12+0x310],0x0
    72fde4f0692c:	je     0x72fde4f069b7
    72fde4f06932:	push   rdx
    72fde4f06933:	push   rsi
    72fde4f06934:	push   r10
    72fde4f06936:	push   r11
    72fde4f06938:	mov    rdx,QWORD PTR [rsp+0x20]
    72fde4f0693d:	mov    r10d,edx
    72fde4f06940:	and    r10d,0xc000
    72fde4f06947:	shl    r10d,0x10
    72fde4f0694b:	mov    r11d,edx
    72fde4f0694e:	and    r11d,0x100
    72fde4f06955:	shl    r11d,0x15
    72fde4f06959:	or     r10d,r11d
    72fde4f0695c:	and    edx,0x1
    72fde4f0695f:	shl    edx,0x1c
    72fde4f06962:	or     r10d,edx
    72fde4f06965:	btc    r10,0x1d
    72fde4f0696a:	mov    r11d,0xf0000000
    72fde4f06970:	and    r11,r10
    72fde4f06973:	movabs rsi,0xffffffff0fffffff
    72fde4f0697d:	and    rbx,rsi
    72fde4f06980:	or     rbx,r11
    72fde4f06983:	pop    r11
    72fde4f06985:	pop    r10
    72fde4f06987:	pop    rsi
    72fde4f06988:	pop    rdx
    72fde4f06989:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f06991:	mov    eax,0x410698
    72fde4f06996:	mov    QWORD PTR [r12+0x100],rax
    72fde4f0699e:	add    rsp,0x150
    72fde4f069a5:	mov    eax,0x3
    72fde4f069aa:	movabs r11,0x5ccd9ef50ca0
    72fde4f069b4:	jmp    r11
    72fde4f069b7:	jmp    0x72fde4f04900
    72fde4f069bc:	nop    DWORD PTR [rax+0x0]
    72fde4f069c0:	sub    rsp,0x150
    72fde4f069c7:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f069cf:	mov    QWORD PTR [rsp],r11
    72fde4f069d3:	cmp    DWORD PTR [r12+0x310],0x0
    72fde4f069dc:	je     0x72fde4f06a67
    72fde4f069e2:	push   rdx
    72fde4f069e3:	push   rsi
    72fde4f069e4:	push   r10
    72fde4f069e6:	push   r11
    72fde4f069e8:	mov    rdx,QWORD PTR [rsp+0x20]
    72fde4f069ed:	mov    r10d,edx
    72fde4f069f0:	and    r10d,0xc000
    72fde4f069f7:	shl    r10d,0x10
    72fde4f069fb:	mov    r11d,edx
    72fde4f069fe:	and    r11d,0x100
    72fde4f06a05:	shl    r11d,0x15
    72fde4f06a09:	or     r10d,r11d
    72fde4f06a0c:	and    edx,0x1
    72fde4f06a0f:	shl    edx,0x1c
    72fde4f06a12:	or     r10d,edx
    72fde4f06a15:	btc    r10,0x1d
    72fde4f06a1a:	mov    r11d,0xf0000000
    72fde4f06a20:	and    r11,r10
    72fde4f06a23:	movabs rsi,0xffffffff0fffffff
    72fde4f06a2d:	and    rbx,rsi
    72fde4f06a30:	or     rbx,r11
    72fde4f06a33:	pop    r11
    72fde4f06a35:	pop    r10
    72fde4f06a37:	pop    rsi
    72fde4f06a38:	pop    rdx
    72fde4f06a39:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f06a41:	mov    eax,0x4103e0
    72fde4f06a46:	mov    QWORD PTR [r12+0x100],rax
    72fde4f06a4e:	add    rsp,0x150
    72fde4f06a55:	mov    eax,0x3
    72fde4f06a5a:	movabs r11,0x5ccd9ef50ca0
    72fde4f06a64:	jmp    r11
    72fde4f06a67:	jmp    0x72fde4f04add
    72fde4f06a6c:	nop    DWORD PTR [rax+0x0]
    72fde4f06a70:	(bad)
    72fde4f06a71:	(bad)
    72fde4f06a72:	(bad)
    72fde4f06a73:	(bad)
    72fde4f06a74:	(bad)
    72fde4f06a75:	(bad)
    72fde4f06a76:	(bad)
    72fde4f06a77:	jg     0x72fde4f06a78
    72fde4f06a79:	(bad)
    72fde4f06a7a:	(bad)
    72fde4f06a7b:	(bad)
    72fde4f06a7c:	(bad)
    72fde4f06a7d:	(bad)
    72fde4f06a7e:	(bad)
    72fde4f06a7f:	jg     0x72fde4f06a81
    72fde4f06a81:	add    BYTE PTR [rax],al
    72fde4f06a83:	add    BYTE PTR [rax],al
    72fde4f06a85:	add    BYTE PTR [rax],dl
    72fde4f06a87:	add    BYTE PTR [rax],al
    72fde4f06a89:	add    BYTE PTR [rax],al
    72fde4f06a8b:	add    BYTE PTR [rax],al
    72fde4f06a8d:	add    BYTE PTR [rax],dl
	...
