
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/2/6.bin:     file format binary


Disassembly of section .data:

00007db2f9501730 <.data>:
    7db2f9501730:	sub    rsp,0x10
    7db2f9501734:	mov    r11,QWORD PTR [r12+0x398]
    7db2f950173c:	mov    QWORD PTR [rsp],r11
    7db2f9501740:	mov    r13d,DWORD PTR [r12]
    7db2f9501744:	mov    r14d,r13d
    7db2f9501747:	mov    r14d,r14d
    7db2f950174a:	shr    r14d,0x10
    7db2f950174e:	xor    r13d,r14d
    7db2f9501751:	mov    QWORD PTR [r12+0x40],r13
    7db2f9501756:	mov    r14d,0x352d
    7db2f950175c:	mov    QWORD PTR [r12+0x48],r14
    7db2f9501761:	mov    r14d,0x352d
    7db2f9501767:	mov    r15d,0x7feb
    7db2f950176d:	and    r15d,0xffff
    7db2f9501774:	mov    rax,r14
    7db2f9501777:	movabs rcx,0xffffffff0000ffff
    7db2f9501781:	and    rax,rcx
    7db2f9501784:	mov    rdx,r15
    7db2f9501787:	shl    rdx,0x10
    7db2f950178b:	mov    ecx,0xffff0000
    7db2f9501790:	and    rdx,rcx
    7db2f9501793:	or     rax,rdx
    7db2f9501796:	mov    ebp,eax
    7db2f9501798:	mov    QWORD PTR [r12+0x48],rbp
    7db2f950179d:	mov    r14d,0x0
    7db2f95017a3:	imul   r13d,ebp
    7db2f95017a7:	mov    r15d,r14d
    7db2f95017aa:	add    r15d,r13d
    7db2f95017ad:	mov    QWORD PTR [r12+0x40],r15
    7db2f95017b2:	mov    r13d,0xa68b
    7db2f95017b8:	mov    QWORD PTR [r12+0x48],r13
    7db2f95017bd:	mov    r13d,0xa68b
    7db2f95017c3:	mov    r14d,0x846c
    7db2f95017c9:	and    r14d,0xffff
    7db2f95017d0:	mov    rax,r13
    7db2f95017d3:	movabs rcx,0xffffffff0000ffff
    7db2f95017dd:	and    rax,rcx
    7db2f95017e0:	mov    rdx,r14
    7db2f95017e3:	shl    rdx,0x10
    7db2f95017e7:	mov    ecx,0xffff0000
    7db2f95017ec:	and    rdx,rcx
    7db2f95017ef:	or     rax,rdx
    7db2f95017f2:	mov    ebp,eax
    7db2f95017f4:	mov    QWORD PTR [r12+0x48],rbp
    7db2f95017f9:	mov    r13d,r15d
    7db2f95017fc:	mov    r13d,r13d
    7db2f95017ff:	shr    r13d,0xf
    7db2f9501803:	xor    r15d,r13d
    7db2f9501806:	mov    QWORD PTR [r12+0x40],r15
    7db2f950180b:	mov    r13d,0x0
    7db2f9501811:	imul   r15d,ebp
    7db2f9501815:	mov    r14d,r13d
    7db2f9501818:	add    r14d,r15d
    7db2f950181b:	mov    QWORD PTR [r12+0x40],r14
    7db2f9501820:	mov    r13d,r14d
    7db2f9501823:	mov    r13d,r13d
    7db2f9501826:	shr    r13d,0x10
    7db2f950182a:	xor    r14d,r13d
    7db2f950182d:	mov    QWORD PTR [r12],r14
    7db2f9501831:	mov    rcx,QWORD PTR [r12+0x380]
    7db2f9501839:	jrcxz  0x7db2f9501840
    7db2f950183b:	jmp    0x7db2f9501875
    7db2f9501840:	mov    r13,QWORD PTR [r12+0xf0]
    7db2f9501848:	mov    QWORD PTR [r12+0x100],r13
    7db2f9501850:	mov    r11,QWORD PTR [rsp]
    7db2f9501854:	mov    QWORD PTR [r12+0x398],r11
    7db2f950185c:	mov    rdi,QWORD PTR [r12+0x100]
    7db2f9501864:	add    rsp,0x10
    7db2f9501868:	movabs r11,0x5a58c9ed2940
    7db2f9501872:	jmp    r11
    7db2f9501875:	mov    eax,0x41095c
    7db2f950187a:	mov    QWORD PTR [r12+0x100],rax
    7db2f9501882:	push   rdx
    7db2f9501883:	push   rsi
    7db2f9501884:	push   r10
    7db2f9501886:	push   r11
    7db2f9501888:	mov    rdx,QWORD PTR [rsp+0x20]
    7db2f950188d:	mov    r10d,edx
    7db2f9501890:	and    r10d,0xc000
    7db2f9501897:	shl    r10d,0x10
    7db2f950189b:	mov    r11d,edx
    7db2f950189e:	and    r11d,0x100
    7db2f95018a5:	shl    r11d,0x15
    7db2f95018a9:	or     r10d,r11d
    7db2f95018ac:	and    edx,0x1
    7db2f95018af:	shl    edx,0x1c
    7db2f95018b2:	or     r10d,edx
    7db2f95018b5:	btc    r10,0x1d
    7db2f95018ba:	mov    r11d,0xf0000000
    7db2f95018c0:	and    r11,r10
    7db2f95018c3:	movabs rsi,0xffffffff0fffffff
    7db2f95018cd:	and    rbx,rsi
    7db2f95018d0:	or     rbx,r11
    7db2f95018d3:	pop    r11
    7db2f95018d5:	pop    r10
    7db2f95018d7:	pop    rsi
    7db2f95018d8:	pop    rdx
    7db2f95018d9:	mov    QWORD PTR [r12+0x108],rbx
    7db2f95018e1:	add    rsp,0x10
    7db2f95018e5:	mov    eax,0xc
    7db2f95018ea:	movabs r11,0x5a58c9ed2ca0
    7db2f95018f4:	jmp    r11
    7db2f95018f7:	nop
