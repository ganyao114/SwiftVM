
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/1/2.bin:     file format binary


Disassembly of section .data:

000072fde4f00b80 <.data>:
    72fde4f00b80:	sub    rsp,0x10
    72fde4f00b84:	mov    r13d,DWORD PTR [r12+0xa0]
    72fde4f00b8c:	sub    r13d,0x1
    72fde4f00b90:	mov    QWORD PTR [r12+0xa0],r13
    72fde4f00b98:	mov    rcx,QWORD PTR [r12+0x380]
    72fde4f00ba0:	jrcxz  0x72fde4f00ba7
    72fde4f00ba2:	jmp    0x72fde4f00d3d
    72fde4f00ba7:	jne    0x72fde4f00bc0
    72fde4f00bad:	mov    r11,rax
    72fde4f00bb0:	lahf
    72fde4f00bb1:	seto   al
    72fde4f00bb4:	mov    WORD PTR [rsp],ax
    72fde4f00bb8:	mov    rax,r11
    72fde4f00bbb:	jmp    0x72fde4f00bd3
    72fde4f00bc0:	mov    r11,rax
    72fde4f00bc3:	lahf
    72fde4f00bc4:	seto   al
    72fde4f00bc7:	mov    WORD PTR [rsp],ax
    72fde4f00bcb:	mov    rax,r11
    72fde4f00bce:	jmp    0x72fde4f00ca5
    72fde4f00bd3:	mov    r13,QWORD PTR [r12+0xf8]
    72fde4f00bdb:	mov    r14,r13
    72fde4f00bde:	add    r14,0xf0
    72fde4f00be5:	mov    r15,QWORD PTR [r14]
    72fde4f00be8:	mov    QWORD PTR [r12+0x98],r15
    72fde4f00bf0:	mov    r14d,0x80
    72fde4f00bf6:	mov    QWORD PTR [r12+0x40],r14
    72fde4f00bfb:	mov    r14,r13
    72fde4f00bfe:	add    r14,0xd0
    72fde4f00c05:	mov    QWORD PTR [r12],r14
    72fde4f00c09:	mov    r14,r13
    72fde4f00c0c:	add    r14,0x14c
    72fde4f00c13:	mov    QWORD PTR [r12+0x8],r14
    72fde4f00c18:	mov    r14d,0x1
    72fde4f00c1e:	mov    QWORD PTR [r12+0x10],r14
    72fde4f00c23:	add    r13,0x14c
    72fde4f00c2a:	movzx  r14d,BYTE PTR [r12+0x40]
    72fde4f00c30:	mov    BYTE PTR [r13+0x0],r14b
    72fde4f00c34:	mov    r13d,0x0
    72fde4f00c3a:	mov    DWORD PTR [r12+0x32c],r13d
    72fde4f00c42:	mov    r13d,0x4102a8
    72fde4f00c48:	mov    QWORD PTR [r12+0xf0],r13
    72fde4f00c50:	mov    r13d,0x4106bc
    72fde4f00c56:	mov    QWORD PTR [r12+0x100],r13
    72fde4f00c5e:	mov    r11,QWORD PTR [rsp]
    72fde4f00c62:	mov    QWORD PTR [r12+0x398],r11
    72fde4f00c6a:	mov    edi,0x4106bc
    72fde4f00c6f:	mov    QWORD PTR [r12+0x100],rdi
    72fde4f00c77:	add    rsp,0x10
    72fde4f00c7b:	nop    DWORD PTR [rax+rax*1+0x0]
    72fde4f00c80:	jmp    QWORD PTR [rip+0x2]        # 0x72fde4f00c88
    72fde4f00c86:	xchg   ax,ax
    72fde4f00c88:	loopne 0x72fde4f00c6f
    72fde4f00c8a:	out    dx,eax
    72fde4f00c8b:	in     al,0xfd
    72fde4f00c8d:	jb     0x72fde4f00c8f
    72fde4f00c8f:	add    BYTE PTR [rax-0x21b0ff4],bl
    72fde4f00c95:	jb     0x72fde4f00c97
    72fde4f00c97:	add    BYTE PTR [rcx-0x45],cl
    72fde4f00c9a:	rex or ebp,esi
    72fde4f00c9d:	sahf
    72fde4f00c9e:	int    0x5c
    72fde4f00ca0:	add    BYTE PTR [rax],al
    72fde4f00ca2:	jmp    r11
    72fde4f00ca5:	mov    r13,QWORD PTR [r12+0xf8]
    72fde4f00cad:	add    r13,0xd0
    72fde4f00cb4:	mov    QWORD PTR [r12],r13
    72fde4f00cb8:	mov    r13d,0x0
    72fde4f00cbe:	mov    r14,QWORD PTR [r12+0x98]
    72fde4f00cc6:	or     r13,r14
    72fde4f00cc9:	mov    QWORD PTR [r12+0x8],r13
    72fde4f00cce:	mov    r13d,0x12c
    72fde4f00cd4:	mov    QWORD PTR [r12+0x10],r13
    72fde4f00cd9:	mov    r13d,0x410284
    72fde4f00cdf:	mov    QWORD PTR [r12+0xf0],r13
    72fde4f00ce7:	mov    r13d,0x4106bc
    72fde4f00ced:	mov    QWORD PTR [r12+0x100],r13
    72fde4f00cf5:	mov    r11,QWORD PTR [rsp]
    72fde4f00cf9:	mov    QWORD PTR [r12+0x398],r11
    72fde4f00d01:	mov    edi,0x4106bc
    72fde4f00d06:	mov    QWORD PTR [r12+0x100],rdi
    72fde4f00d0e:	add    rsp,0x10
    72fde4f00d12:	nop    WORD PTR [rax+rax*1+0x0]
    72fde4f00d18:	jmp    QWORD PTR [rip+0x2]        # 0x72fde4f00d20
    72fde4f00d1e:	xchg   ax,ax
    72fde4f00d20:	loopne 0x72fde4f00d07
    72fde4f00d22:	out    dx,eax
    72fde4f00d23:	in     al,0xfd
    72fde4f00d25:	jb     0x72fde4f00d27
    72fde4f00d27:	add    BYTE PTR [rax],dh
    72fde4f00d29:	or     eax,0x72fde4f0
    72fde4f00d2e:	add    BYTE PTR [rax],al
    72fde4f00d30:	movabs r11,0x5ccd9ef50940
    72fde4f00d3a:	jmp    r11
    72fde4f00d3d:	mov    eax,0x410288
    72fde4f00d42:	mov    QWORD PTR [r12+0x100],rax
    72fde4f00d4a:	push   rdx
    72fde4f00d4b:	push   rsi
    72fde4f00d4c:	push   r10
    72fde4f00d4e:	push   r11
    72fde4f00d50:	mov    r11,rax
    72fde4f00d53:	lahf
    72fde4f00d54:	seto   al
    72fde4f00d57:	mov    WORD PTR [rsp+0x20],ax
    72fde4f00d5c:	mov    rax,r11
    72fde4f00d5f:	mov    rdx,QWORD PTR [rsp+0x20]
    72fde4f00d64:	mov    r10d,edx
    72fde4f00d67:	and    r10d,0xc000
    72fde4f00d6e:	shl    r10d,0x10
    72fde4f00d72:	mov    r11d,edx
    72fde4f00d75:	and    r11d,0x100
    72fde4f00d7c:	shl    r11d,0x15
    72fde4f00d80:	or     r10d,r11d
    72fde4f00d83:	and    edx,0x1
    72fde4f00d86:	shl    edx,0x1c
    72fde4f00d89:	or     r10d,edx
    72fde4f00d8c:	btc    r10,0x1d
    72fde4f00d91:	mov    r11d,0xf0000000
    72fde4f00d97:	and    r11,r10
    72fde4f00d9a:	movabs rsi,0xffffffff0fffffff
    72fde4f00da4:	and    rbx,rsi
    72fde4f00da7:	or     rbx,r11
    72fde4f00daa:	pop    r11
    72fde4f00dac:	pop    r10
    72fde4f00dae:	pop    rsi
    72fde4f00daf:	pop    rdx
    72fde4f00db0:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f00db8:	add    rsp,0x10
    72fde4f00dbc:	mov    eax,0xc
    72fde4f00dc1:	movabs r11,0x5ccd9ef50ca0
    72fde4f00dcb:	jmp    r11
    72fde4f00dce:	xchg   ax,ax
    72fde4f00dd0:	sub    rsp,0x10
    72fde4f00dd4:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f00ddc:	mov    QWORD PTR [rsp],r11
    72fde4f00de0:	jmp    0x72fde4f00bd3
    72fde4f00de5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72fde4f00df0:	sub    rsp,0x10
    72fde4f00df4:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f00dfc:	mov    QWORD PTR [rsp],r11
    72fde4f00e00:	jmp    0x72fde4f00ca5
    72fde4f00e05:	nop
    72fde4f00e06:	nop
    72fde4f00e07:	nop
