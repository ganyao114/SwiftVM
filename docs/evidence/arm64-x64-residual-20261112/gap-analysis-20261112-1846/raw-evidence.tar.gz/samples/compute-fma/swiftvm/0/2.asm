
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/0/2.bin:     file format binary


Disassembly of section .data:

00007076cdd00b80 <.data>:
    7076cdd00b80:	sub    rsp,0x10
    7076cdd00b84:	mov    r13d,DWORD PTR [r12+0xa0]
    7076cdd00b8c:	sub    r13d,0x1
    7076cdd00b90:	mov    QWORD PTR [r12+0xa0],r13
    7076cdd00b98:	mov    rcx,QWORD PTR [r12+0x380]
    7076cdd00ba0:	jrcxz  0x7076cdd00ba7
    7076cdd00ba2:	jmp    0x7076cdd00d3d
    7076cdd00ba7:	jne    0x7076cdd00bc0
    7076cdd00bad:	mov    r11,rax
    7076cdd00bb0:	lahf
    7076cdd00bb1:	seto   al
    7076cdd00bb4:	mov    WORD PTR [rsp],ax
    7076cdd00bb8:	mov    rax,r11
    7076cdd00bbb:	jmp    0x7076cdd00bd3
    7076cdd00bc0:	mov    r11,rax
    7076cdd00bc3:	lahf
    7076cdd00bc4:	seto   al
    7076cdd00bc7:	mov    WORD PTR [rsp],ax
    7076cdd00bcb:	mov    rax,r11
    7076cdd00bce:	jmp    0x7076cdd00ca5
    7076cdd00bd3:	mov    r13,QWORD PTR [r12+0xf8]
    7076cdd00bdb:	mov    r14,r13
    7076cdd00bde:	add    r14,0xf0
    7076cdd00be5:	mov    r15,QWORD PTR [r14]
    7076cdd00be8:	mov    QWORD PTR [r12+0x98],r15
    7076cdd00bf0:	mov    r14d,0x80
    7076cdd00bf6:	mov    QWORD PTR [r12+0x40],r14
    7076cdd00bfb:	mov    r14,r13
    7076cdd00bfe:	add    r14,0xd0
    7076cdd00c05:	mov    QWORD PTR [r12],r14
    7076cdd00c09:	mov    r14,r13
    7076cdd00c0c:	add    r14,0x14c
    7076cdd00c13:	mov    QWORD PTR [r12+0x8],r14
    7076cdd00c18:	mov    r14d,0x1
    7076cdd00c1e:	mov    QWORD PTR [r12+0x10],r14
    7076cdd00c23:	add    r13,0x14c
    7076cdd00c2a:	movzx  r14d,BYTE PTR [r12+0x40]
    7076cdd00c30:	mov    BYTE PTR [r13+0x0],r14b
    7076cdd00c34:	mov    r13d,0x0
    7076cdd00c3a:	mov    DWORD PTR [r12+0x32c],r13d
    7076cdd00c42:	mov    r13d,0x4102a8
    7076cdd00c48:	mov    QWORD PTR [r12+0xf0],r13
    7076cdd00c50:	mov    r13d,0x4106bc
    7076cdd00c56:	mov    QWORD PTR [r12+0x100],r13
    7076cdd00c5e:	mov    r11,QWORD PTR [rsp]
    7076cdd00c62:	mov    QWORD PTR [r12+0x398],r11
    7076cdd00c6a:	mov    edi,0x4106bc
    7076cdd00c6f:	mov    QWORD PTR [r12+0x100],rdi
    7076cdd00c77:	add    rsp,0x10
    7076cdd00c7b:	nop    DWORD PTR [rax+rax*1+0x0]
    7076cdd00c80:	jmp    QWORD PTR [rip+0x2]        # 0x7076cdd00c88
    7076cdd00c86:	xchg   ax,ax
    7076cdd00c88:	loopne 0x7076cdd00c6f
    7076cdd00c8a:	iret
    7076cdd00c8b:	int    0x76
    7076cdd00c8d:	jo     0x7076cdd00c8f
    7076cdd00c8f:	add    BYTE PTR [rax+0x76cdd00c],bl
    7076cdd00c95:	jo     0x7076cdd00c97
    7076cdd00c97:	add    BYTE PTR [rcx-0x45],cl
    7076cdd00c9a:	rex cdq
    7076cdd00c9c:	ds out 0x61,eax
    7076cdd00c9f:	pop    rbx
    7076cdd00ca0:	add    BYTE PTR [rax],al
    7076cdd00ca2:	jmp    r11
    7076cdd00ca5:	mov    r13,QWORD PTR [r12+0xf8]
    7076cdd00cad:	add    r13,0xd0
    7076cdd00cb4:	mov    QWORD PTR [r12],r13
    7076cdd00cb8:	mov    r13d,0x0
    7076cdd00cbe:	mov    r14,QWORD PTR [r12+0x98]
    7076cdd00cc6:	or     r13,r14
    7076cdd00cc9:	mov    QWORD PTR [r12+0x8],r13
    7076cdd00cce:	mov    r13d,0x12c
    7076cdd00cd4:	mov    QWORD PTR [r12+0x10],r13
    7076cdd00cd9:	mov    r13d,0x410284
    7076cdd00cdf:	mov    QWORD PTR [r12+0xf0],r13
    7076cdd00ce7:	mov    r13d,0x4106bc
    7076cdd00ced:	mov    QWORD PTR [r12+0x100],r13
    7076cdd00cf5:	mov    r11,QWORD PTR [rsp]
    7076cdd00cf9:	mov    QWORD PTR [r12+0x398],r11
    7076cdd00d01:	mov    edi,0x4106bc
    7076cdd00d06:	mov    QWORD PTR [r12+0x100],rdi
    7076cdd00d0e:	add    rsp,0x10
    7076cdd00d12:	nop    WORD PTR [rax+rax*1+0x0]
    7076cdd00d18:	jmp    QWORD PTR [rip+0x2]        # 0x7076cdd00d20
    7076cdd00d1e:	xchg   ax,ax
    7076cdd00d20:	loopne 0x7076cdd00d07
    7076cdd00d22:	iret
    7076cdd00d23:	int    0x76
    7076cdd00d25:	jo     0x7076cdd00d27
    7076cdd00d27:	add    BYTE PTR [rax],dh
    7076cdd00d29:	or     eax,0x7076cdd0
    7076cdd00d2e:	add    BYTE PTR [rax],al
    7076cdd00d30:	movabs r11,0x5b61e73e9940
    7076cdd00d3a:	jmp    r11
    7076cdd00d3d:	mov    eax,0x410288
    7076cdd00d42:	mov    QWORD PTR [r12+0x100],rax
    7076cdd00d4a:	push   rdx
    7076cdd00d4b:	push   rsi
    7076cdd00d4c:	push   r10
    7076cdd00d4e:	push   r11
    7076cdd00d50:	mov    r11,rax
    7076cdd00d53:	lahf
    7076cdd00d54:	seto   al
    7076cdd00d57:	mov    WORD PTR [rsp+0x20],ax
    7076cdd00d5c:	mov    rax,r11
    7076cdd00d5f:	mov    rdx,QWORD PTR [rsp+0x20]
    7076cdd00d64:	mov    r10d,edx
    7076cdd00d67:	and    r10d,0xc000
    7076cdd00d6e:	shl    r10d,0x10
    7076cdd00d72:	mov    r11d,edx
    7076cdd00d75:	and    r11d,0x100
    7076cdd00d7c:	shl    r11d,0x15
    7076cdd00d80:	or     r10d,r11d
    7076cdd00d83:	and    edx,0x1
    7076cdd00d86:	shl    edx,0x1c
    7076cdd00d89:	or     r10d,edx
    7076cdd00d8c:	btc    r10,0x1d
    7076cdd00d91:	mov    r11d,0xf0000000
    7076cdd00d97:	and    r11,r10
    7076cdd00d9a:	movabs rsi,0xffffffff0fffffff
    7076cdd00da4:	and    rbx,rsi
    7076cdd00da7:	or     rbx,r11
    7076cdd00daa:	pop    r11
    7076cdd00dac:	pop    r10
    7076cdd00dae:	pop    rsi
    7076cdd00daf:	pop    rdx
    7076cdd00db0:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd00db8:	add    rsp,0x10
    7076cdd00dbc:	mov    eax,0xc
    7076cdd00dc1:	movabs r11,0x5b61e73e9ca0
    7076cdd00dcb:	jmp    r11
    7076cdd00dce:	xchg   ax,ax
    7076cdd00dd0:	sub    rsp,0x10
    7076cdd00dd4:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd00ddc:	mov    QWORD PTR [rsp],r11
    7076cdd00de0:	jmp    0x7076cdd00bd3
    7076cdd00de5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7076cdd00df0:	sub    rsp,0x10
    7076cdd00df4:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd00dfc:	mov    QWORD PTR [rsp],r11
    7076cdd00e00:	jmp    0x7076cdd00ca5
    7076cdd00e05:	nop
    7076cdd00e06:	nop
    7076cdd00e07:	nop
