
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/1/1.bin:     file format binary


Disassembly of section .data:

000072fde4efe5e0 <.data>:
    72fde4efe5e0:	sub    rsp,0xc0
    72fde4efe5e7:	mov    r11,QWORD PTR [r12+0x398]
    72fde4efe5ef:	mov    QWORD PTR [rsp+0xb0],r11
    72fde4efe5f7:	mov    r13,QWORD PTR [r12]
    72fde4efe5fb:	mov    r14,r13
    72fde4efe5fe:	add    r14,0x20
    72fde4efe602:	mov    r15,QWORD PTR [r14]
    72fde4efe605:	mov    r14,QWORD PTR [r12+0x10]
    72fde4efe60a:	add    r15,r14
    72fde4efe60d:	mov    QWORD PTR [r12+0x40],r15
    72fde4efe612:	add    r13,0x20
    72fde4efe616:	mov    QWORD PTR [r13+0x0],r15
    72fde4efe61a:	mov    r13d,0x0
    72fde4efe620:	mov    DWORD PTR [r12+0x32c],r13d
    72fde4efe628:	mov    rax,r14
    72fde4efe62b:	test   rax,rax
    72fde4efe62e:	je     0x72fde4f00735
    72fde4efe634:	jmp    0x72fde4efe639
    72fde4efe639:	mov    r13,QWORD PTR [r12+0xf8]
    72fde4efe641:	sub    r13,0x150
    72fde4efe648:	mov    QWORD PTR [r12+0xf8],r13
    72fde4efe650:	mov    r14,QWORD PTR [r12]
    72fde4efe654:	mov    r15,r14
    72fde4efe657:	add    r15,0x68
    72fde4efe65b:	mov    rbp,QWORD PTR [r15]
    72fde4efe65e:	mov    QWORD PTR [r12+0x88],rbp
    72fde4efe666:	add    r14,0x28
    72fde4efe66a:	mov    QWORD PTR [r12+0x40],r14
    72fde4efe66f:	mov    QWORD PTR [r12+0x48],r13
    72fde4efe674:	mov    r14d,0x420000
    72fde4efe67a:	add    r14,0xb20
    72fde4efe681:	mov    QWORD PTR [r12+0x50],r14
    72fde4efe686:	mov    r14,r13
    72fde4efe689:	add    r14,0x100
    72fde4efe690:	mov    r15,r14
    72fde4efe693:	add    r15,0x8
    72fde4efe697:	mov    rbp,QWORD PTR [r12+0xe8]
    72fde4efe69f:	mov    r8,QWORD PTR [r12+0xd8]
    72fde4efe6a7:	mov    QWORD PTR [r14],rbp
    72fde4efe6aa:	mov    r14d,0x0
    72fde4efe6b0:	mov    DWORD PTR [r12+0x32c],r14d
    72fde4efe6b8:	mov    QWORD PTR [r15],r8
    72fde4efe6bb:	mov    r14,r13
    72fde4efe6be:	add    r14,0x110
    72fde4efe6c5:	mov    r15,r14
    72fde4efe6c8:	add    r15,0x8
    72fde4efe6cc:	mov    rbp,QWORD PTR [r12+0xd0]
    72fde4efe6d4:	mov    r8,QWORD PTR [r12+0xc8]
    72fde4efe6dc:	mov    QWORD PTR [r14],rbp
    72fde4efe6df:	mov    QWORD PTR [r15],r8
    72fde4efe6e2:	mov    r14,r13
    72fde4efe6e5:	add    r14,0x120
    72fde4efe6ec:	mov    r15,r14
    72fde4efe6ef:	add    r15,0x8
    72fde4efe6f3:	mov    rbp,QWORD PTR [r12+0xc0]
    72fde4efe6fb:	mov    r8,QWORD PTR [r12+0xb8]
    72fde4efe703:	mov    QWORD PTR [r14],rbp
    72fde4efe706:	mov    QWORD PTR [r15],r8
    72fde4efe709:	mov    r14,r13
    72fde4efe70c:	add    r14,0x130
    72fde4efe713:	mov    r15,r14
    72fde4efe716:	add    r15,0x8
    72fde4efe71a:	mov    rbp,QWORD PTR [r12+0xb0]
    72fde4efe722:	mov    r8,QWORD PTR [r12+0xa8]
    72fde4efe72a:	mov    QWORD PTR [r14],rbp
    72fde4efe72d:	mov    QWORD PTR [r15],r8
    72fde4efe730:	add    r13,0x140
    72fde4efe737:	mov    r14,r13
    72fde4efe73a:	add    r14,0x8
    72fde4efe73e:	mov    r15,QWORD PTR [r12+0xa0]
    72fde4efe746:	mov    rbp,QWORD PTR [r12+0x98]
    72fde4efe74e:	mov    QWORD PTR [r13+0x0],r15
    72fde4efe752:	mov    QWORD PTR [r14],rbp
    72fde4efe755:	jmp    0x72fde4efe75a
    72fde4efe75a:	mov    r13,QWORD PTR [r12+0x8]
    72fde4efe75f:	mov    r14,r13
    72fde4efe762:	add    r14,0x1
    72fde4efe766:	movzx  r15d,BYTE PTR [r13+0x0]
    72fde4efe76b:	mov    QWORD PTR [r12+0x58],r15
    72fde4efe770:	mov    QWORD PTR [r12+0x8],r14
    72fde4efe775:	mov    r13,QWORD PTR [r12+0x88]
    72fde4efe77d:	mov    r14,r13
    72fde4efe780:	add    r14,0x1
    72fde4efe784:	mov    QWORD PTR [r12+0x60],r14
    72fde4efe789:	mov    r15,QWORD PTR [r12]
    72fde4efe78d:	mov    rbp,r15
    72fde4efe790:	add    rbp,0x68
    72fde4efe794:	mov    QWORD PTR [rbp+0x0],r14
    72fde4efe798:	mov    r14d,0x0
    72fde4efe79e:	mov    DWORD PTR [r12+0x32c],r14d
    72fde4efe7a6:	mov    r14,r15
    72fde4efe7a9:	add    r14,r13
    72fde4efe7ac:	mov    QWORD PTR [r12+0x60],r14
    72fde4efe7b1:	add    r14,0x28
    72fde4efe7b5:	movzx  r13d,BYTE PTR [r12+0x58]
    72fde4efe7bb:	mov    BYTE PTR [r14],r13b
    72fde4efe7be:	add    r15,0x68
    72fde4efe7c2:	mov    r13,QWORD PTR [r15]
    72fde4efe7c5:	mov    QWORD PTR [r12+0x88],r13
    72fde4efe7cd:	sub    r13,0x40
    72fde4efe7d1:	mov    rcx,QWORD PTR [r12+0x380]
    72fde4efe7d9:	jrcxz  0x72fde4efe7e0
    72fde4efe7db:	jmp    0x72fde4f00780
    72fde4efe7e0:	jne    0x72fde4efe7fd
    72fde4efe7e6:	mov    r11,rax
    72fde4efe7e9:	lahf
    72fde4efe7ea:	seto   al
    72fde4efe7ed:	mov    WORD PTR [rsp+0xb0],ax
    72fde4efe7f5:	mov    rax,r11
    72fde4efe7f8:	jmp    0x72fde4efe814
    72fde4efe7fd:	mov    r11,rax
    72fde4efe800:	lahf
    72fde4efe801:	seto   al
    72fde4efe804:	mov    WORD PTR [rsp+0xb0],ax
    72fde4efe80c:	mov    rax,r11
    72fde4efe80f:	jmp    0x72fde4f00637
    72fde4efe814:	mov    rax,QWORD PTR [r12+0x40]
    72fde4efe819:	mov    eax,0x0
    72fde4efe81e:	mov    QWORD PTR [rsp+0x18],rax
    72fde4efe823:	mov    eax,0x0
    72fde4efe828:	mov    QWORD PTR [rsp+0x10],rax
    72fde4efe82d:	mov    eax,0x0
    72fde4efe832:	mov    QWORD PTR [rsp+0x8],rax
    72fde4efe837:	mov    eax,0x0
    72fde4efe83c:	mov    QWORD PTR [rsp],rax
    72fde4efe840:	mov    rdi,QWORD PTR [r12+0x40]
    72fde4efe845:	movzx  r9d,BYTE PTR [rdi]
    72fde4efe849:	mov    r13,QWORD PTR [rsp+0x18]
    72fde4efe84e:	or     r13,r9
    72fde4efe851:	mov    r9,QWORD PTR [r12+0x40]
    72fde4efe856:	add    r9,0x1
    72fde4efe85a:	movzx  r8d,BYTE PTR [r9]
    72fde4efe85e:	mov    r9,QWORD PTR [rsp+0x10]
    72fde4efe863:	or     r9,r8
    72fde4efe866:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efe86b:	add    r8,0x2
    72fde4efe86f:	movzx  ebp,BYTE PTR [r8]
    72fde4efe873:	mov    r8,QWORD PTR [rsp+0x8]
    72fde4efe878:	or     r8,rbp
    72fde4efe87b:	mov    rbp,QWORD PTR [r12+0x40]
    72fde4efe880:	add    rbp,0x3
    72fde4efe884:	movzx  r15d,BYTE PTR [rbp+0x0]
    72fde4efe889:	mov    rbp,QWORD PTR [rsp]
    72fde4efe88d:	or     rbp,r15
    72fde4efe890:	mov    r15,QWORD PTR [r12+0x40]
    72fde4efe895:	add    r15,0x4
    72fde4efe899:	movzx  r14d,BYTE PTR [r15]
    72fde4efe89d:	mov    r15,r14
    72fde4efe8a0:	shl    r15,0x8
    72fde4efe8a4:	or     r13,r15
    72fde4efe8a7:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efe8ac:	add    r14,0x5
    72fde4efe8b0:	movzx  r15d,BYTE PTR [r14]
    72fde4efe8b4:	mov    r14,r15
    72fde4efe8b7:	shl    r14,0x8
    72fde4efe8bb:	or     r9,r14
    72fde4efe8be:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efe8c3:	add    r14,0x6
    72fde4efe8c7:	movzx  r15d,BYTE PTR [r14]
    72fde4efe8cb:	mov    r14,r15
    72fde4efe8ce:	shl    r14,0x8
    72fde4efe8d2:	or     r8,r14
    72fde4efe8d5:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efe8da:	add    r14,0x7
    72fde4efe8de:	movzx  r15d,BYTE PTR [r14]
    72fde4efe8e2:	mov    r14,r15
    72fde4efe8e5:	shl    r14,0x8
    72fde4efe8e9:	or     rbp,r14
    72fde4efe8ec:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efe8f1:	add    r14,0x8
    72fde4efe8f5:	movzx  r15d,BYTE PTR [r14]
    72fde4efe8f9:	mov    r14,r15
    72fde4efe8fc:	shl    r14,0x10
    72fde4efe900:	or     r13,r14
    72fde4efe903:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efe908:	add    r14,0x9
    72fde4efe90c:	movzx  r15d,BYTE PTR [r14]
    72fde4efe910:	mov    r14,r15
    72fde4efe913:	shl    r14,0x10
    72fde4efe917:	or     r9,r14
    72fde4efe91a:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efe91f:	add    r14,0xa
    72fde4efe923:	movzx  r15d,BYTE PTR [r14]
    72fde4efe927:	mov    r14,r15
    72fde4efe92a:	shl    r14,0x10
    72fde4efe92e:	or     r8,r14
    72fde4efe931:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efe936:	add    r14,0xb
    72fde4efe93a:	movzx  r15d,BYTE PTR [r14]
    72fde4efe93e:	mov    r14,r15
    72fde4efe941:	shl    r14,0x10
    72fde4efe945:	or     rbp,r14
    72fde4efe948:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efe94d:	add    r14,0xc
    72fde4efe951:	movzx  r15d,BYTE PTR [r14]
    72fde4efe955:	mov    r14,r15
    72fde4efe958:	shl    r14,0x18
    72fde4efe95c:	or     r13,r14
    72fde4efe95f:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efe964:	add    r14,0xd
    72fde4efe968:	movzx  r15d,BYTE PTR [r14]
    72fde4efe96c:	mov    r14,r15
    72fde4efe96f:	shl    r14,0x18
    72fde4efe973:	or     r9,r14
    72fde4efe976:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efe97b:	add    r14,0xe
    72fde4efe97f:	movzx  r15d,BYTE PTR [r14]
    72fde4efe983:	mov    r14,r15
    72fde4efe986:	shl    r14,0x18
    72fde4efe98a:	or     r8,r14
    72fde4efe98d:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efe992:	add    r14,0xf
    72fde4efe996:	movzx  r15d,BYTE PTR [r14]
    72fde4efe99a:	mov    r14,r15
    72fde4efe99d:	shl    r14,0x18
    72fde4efe9a1:	or     rbp,r14
    72fde4efe9a4:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efe9a9:	add    r14,0x10
    72fde4efe9ad:	movzx  r15d,BYTE PTR [r14]
    72fde4efe9b1:	mov    r14,r15
    72fde4efe9b4:	shl    r14,0x20
    72fde4efe9b8:	or     r13,r14
    72fde4efe9bb:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efe9c0:	add    r14,0x11
    72fde4efe9c4:	movzx  r15d,BYTE PTR [r14]
    72fde4efe9c8:	mov    r14,r15
    72fde4efe9cb:	shl    r14,0x20
    72fde4efe9cf:	or     r9,r14
    72fde4efe9d2:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efe9d7:	add    r14,0x12
    72fde4efe9db:	movzx  r15d,BYTE PTR [r14]
    72fde4efe9df:	mov    r14,r15
    72fde4efe9e2:	shl    r14,0x20
    72fde4efe9e6:	or     r8,r14
    72fde4efe9e9:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efe9ee:	add    r14,0x13
    72fde4efe9f2:	movzx  r15d,BYTE PTR [r14]
    72fde4efe9f6:	mov    r14,r15
    72fde4efe9f9:	shl    r14,0x20
    72fde4efe9fd:	or     rbp,r14
    72fde4efea00:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efea05:	add    r14,0x14
    72fde4efea09:	movzx  r15d,BYTE PTR [r14]
    72fde4efea0d:	mov    r14,r15
    72fde4efea10:	shl    r14,0x28
    72fde4efea14:	or     r13,r14
    72fde4efea17:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efea1c:	add    r14,0x15
    72fde4efea20:	movzx  r15d,BYTE PTR [r14]
    72fde4efea24:	mov    r14,r15
    72fde4efea27:	shl    r14,0x28
    72fde4efea2b:	or     r9,r14
    72fde4efea2e:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efea33:	add    r14,0x16
    72fde4efea37:	movzx  r15d,BYTE PTR [r14]
    72fde4efea3b:	mov    r14,r15
    72fde4efea3e:	shl    r14,0x28
    72fde4efea42:	or     r8,r14
    72fde4efea45:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efea4a:	add    r14,0x17
    72fde4efea4e:	movzx  r15d,BYTE PTR [r14]
    72fde4efea52:	mov    r14,r15
    72fde4efea55:	shl    r14,0x28
    72fde4efea59:	or     rbp,r14
    72fde4efea5c:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efea61:	add    r14,0x18
    72fde4efea65:	movzx  r15d,BYTE PTR [r14]
    72fde4efea69:	mov    r14,r15
    72fde4efea6c:	shl    r14,0x30
    72fde4efea70:	or     r13,r14
    72fde4efea73:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efea78:	add    r14,0x19
    72fde4efea7c:	movzx  r15d,BYTE PTR [r14]
    72fde4efea80:	mov    r14,r15
    72fde4efea83:	shl    r14,0x30
    72fde4efea87:	or     r9,r14
    72fde4efea8a:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efea8f:	add    r14,0x1a
    72fde4efea93:	movzx  r15d,BYTE PTR [r14]
    72fde4efea97:	mov    r14,r15
    72fde4efea9a:	shl    r14,0x30
    72fde4efea9e:	or     r8,r14
    72fde4efeaa1:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efeaa6:	add    r14,0x1b
    72fde4efeaaa:	movzx  r15d,BYTE PTR [r14]
    72fde4efeaae:	mov    r14,r15
    72fde4efeab1:	shl    r14,0x30
    72fde4efeab5:	or     rbp,r14
    72fde4efeab8:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efeabd:	add    r14,0x1c
    72fde4efeac1:	movzx  r15d,BYTE PTR [r14]
    72fde4efeac5:	mov    r14,r15
    72fde4efeac8:	shl    r14,0x38
    72fde4efeacc:	mov    rax,r13
    72fde4efeacf:	or     rax,r14
    72fde4efead2:	mov    QWORD PTR [rsp+0x28],rax
    72fde4efead7:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efeadc:	add    r14,0x1d
    72fde4efeae0:	movzx  r15d,BYTE PTR [r14]
    72fde4efeae4:	mov    r14,r15
    72fde4efeae7:	shl    r14,0x38
    72fde4efeaeb:	mov    rax,r9
    72fde4efeaee:	or     rax,r14
    72fde4efeaf1:	mov    QWORD PTR [rsp+0x38],rax
    72fde4efeaf6:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efeafb:	add    r14,0x1e
    72fde4efeaff:	movzx  r15d,BYTE PTR [r14]
    72fde4efeb03:	mov    r14,r15
    72fde4efeb06:	shl    r14,0x38
    72fde4efeb0a:	mov    rax,r8
    72fde4efeb0d:	or     rax,r14
    72fde4efeb10:	mov    QWORD PTR [rsp+0x30],rax
    72fde4efeb15:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efeb1a:	add    r14,0x1f
    72fde4efeb1e:	movzx  r15d,BYTE PTR [r14]
    72fde4efeb22:	mov    r14,r15
    72fde4efeb25:	shl    r14,0x38
    72fde4efeb29:	mov    rax,rbp
    72fde4efeb2c:	or     rax,r14
    72fde4efeb2f:	mov    QWORD PTR [rsp+0x20],rax
    72fde4efeb34:	mov    r14,QWORD PTR [r12+0x40]
    72fde4efeb39:	add    r14,0x20
    72fde4efeb3d:	movzx  r15d,BYTE PTR [r14]
    72fde4efeb41:	mov    r14,QWORD PTR [rsp+0x18]
    72fde4efeb46:	or     r14,r15
    72fde4efeb49:	mov    r15,QWORD PTR [r12+0x40]
    72fde4efeb4e:	add    r15,0x21
    72fde4efeb52:	movzx  ebp,BYTE PTR [r15]
    72fde4efeb56:	mov    r15,QWORD PTR [rsp+0x10]
    72fde4efeb5b:	or     r15,rbp
    72fde4efeb5e:	mov    rbp,QWORD PTR [r12+0x40]
    72fde4efeb63:	add    rbp,0x22
    72fde4efeb67:	movzx  r13d,BYTE PTR [rbp+0x0]
    72fde4efeb6c:	mov    rbp,QWORD PTR [rsp+0x8]
    72fde4efeb71:	or     rbp,r13
    72fde4efeb74:	mov    r13,QWORD PTR [r12+0x40]
    72fde4efeb79:	add    r13,0x23
    72fde4efeb7d:	movzx  r8d,BYTE PTR [r13+0x0]
    72fde4efeb82:	mov    r13,QWORD PTR [rsp]
    72fde4efeb86:	or     r13,r8
    72fde4efeb89:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efeb8e:	add    r8,0x24
    72fde4efeb92:	movzx  r9d,BYTE PTR [r8]
    72fde4efeb96:	mov    r8,r9
    72fde4efeb99:	shl    r8,0x8
    72fde4efeb9d:	or     r14,r8
    72fde4efeba0:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efeba5:	add    r8,0x25
    72fde4efeba9:	movzx  r9d,BYTE PTR [r8]
    72fde4efebad:	mov    r8,r9
    72fde4efebb0:	shl    r8,0x8
    72fde4efebb4:	or     r15,r8
    72fde4efebb7:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efebbc:	add    r8,0x26
    72fde4efebc0:	movzx  r9d,BYTE PTR [r8]
    72fde4efebc4:	mov    r8,r9
    72fde4efebc7:	shl    r8,0x8
    72fde4efebcb:	or     rbp,r8
    72fde4efebce:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efebd3:	add    r8,0x27
    72fde4efebd7:	movzx  r9d,BYTE PTR [r8]
    72fde4efebdb:	mov    r8,r9
    72fde4efebde:	shl    r8,0x8
    72fde4efebe2:	or     r13,r8
    72fde4efebe5:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efebea:	add    r8,0x28
    72fde4efebee:	movzx  r9d,BYTE PTR [r8]
    72fde4efebf2:	mov    r8,r9
    72fde4efebf5:	shl    r8,0x10
    72fde4efebf9:	or     r14,r8
    72fde4efebfc:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efec01:	add    r8,0x29
    72fde4efec05:	movzx  r9d,BYTE PTR [r8]
    72fde4efec09:	mov    r8,r9
    72fde4efec0c:	shl    r8,0x10
    72fde4efec10:	or     r15,r8
    72fde4efec13:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efec18:	add    r8,0x2a
    72fde4efec1c:	movzx  r9d,BYTE PTR [r8]
    72fde4efec20:	mov    r8,r9
    72fde4efec23:	shl    r8,0x10
    72fde4efec27:	or     rbp,r8
    72fde4efec2a:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efec2f:	add    r8,0x2b
    72fde4efec33:	movzx  r9d,BYTE PTR [r8]
    72fde4efec37:	mov    r8,r9
    72fde4efec3a:	shl    r8,0x10
    72fde4efec3e:	or     r13,r8
    72fde4efec41:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efec46:	add    r8,0x2c
    72fde4efec4a:	movzx  r9d,BYTE PTR [r8]
    72fde4efec4e:	mov    r8,r9
    72fde4efec51:	shl    r8,0x18
    72fde4efec55:	or     r14,r8
    72fde4efec58:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efec5d:	add    r8,0x2d
    72fde4efec61:	movzx  r9d,BYTE PTR [r8]
    72fde4efec65:	mov    r8,r9
    72fde4efec68:	shl    r8,0x18
    72fde4efec6c:	or     r15,r8
    72fde4efec6f:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efec74:	add    r8,0x2e
    72fde4efec78:	movzx  r9d,BYTE PTR [r8]
    72fde4efec7c:	mov    r8,r9
    72fde4efec7f:	shl    r8,0x18
    72fde4efec83:	or     rbp,r8
    72fde4efec86:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efec8b:	add    r8,0x2f
    72fde4efec8f:	movzx  r9d,BYTE PTR [r8]
    72fde4efec93:	mov    r8,r9
    72fde4efec96:	shl    r8,0x18
    72fde4efec9a:	or     r13,r8
    72fde4efec9d:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efeca2:	add    r8,0x30
    72fde4efeca6:	movzx  r9d,BYTE PTR [r8]
    72fde4efecaa:	mov    r8,r9
    72fde4efecad:	shl    r8,0x20
    72fde4efecb1:	or     r14,r8
    72fde4efecb4:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efecb9:	add    r8,0x31
    72fde4efecbd:	movzx  r9d,BYTE PTR [r8]
    72fde4efecc1:	mov    r8,r9
    72fde4efecc4:	shl    r8,0x20
    72fde4efecc8:	or     r15,r8
    72fde4efeccb:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efecd0:	add    r8,0x32
    72fde4efecd4:	movzx  r9d,BYTE PTR [r8]
    72fde4efecd8:	mov    r8,r9
    72fde4efecdb:	shl    r8,0x20
    72fde4efecdf:	or     rbp,r8
    72fde4efece2:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efece7:	add    r8,0x33
    72fde4efeceb:	movzx  r9d,BYTE PTR [r8]
    72fde4efecef:	mov    r8,r9
    72fde4efecf2:	shl    r8,0x20
    72fde4efecf6:	or     r13,r8
    72fde4efecf9:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efecfe:	add    r8,0x34
    72fde4efed02:	movzx  r9d,BYTE PTR [r8]
    72fde4efed06:	mov    r8,r9
    72fde4efed09:	shl    r8,0x28
    72fde4efed0d:	or     r14,r8
    72fde4efed10:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efed15:	add    r8,0x35
    72fde4efed19:	movzx  r9d,BYTE PTR [r8]
    72fde4efed1d:	mov    r8,r9
    72fde4efed20:	shl    r8,0x28
    72fde4efed24:	or     r15,r8
    72fde4efed27:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efed2c:	add    r8,0x36
    72fde4efed30:	movzx  r9d,BYTE PTR [r8]
    72fde4efed34:	mov    r8,r9
    72fde4efed37:	shl    r8,0x28
    72fde4efed3b:	or     rbp,r8
    72fde4efed3e:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efed43:	add    r8,0x37
    72fde4efed47:	movzx  r9d,BYTE PTR [r8]
    72fde4efed4b:	mov    r8,r9
    72fde4efed4e:	shl    r8,0x28
    72fde4efed52:	or     r13,r8
    72fde4efed55:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efed5a:	add    r8,0x38
    72fde4efed5e:	movzx  r9d,BYTE PTR [r8]
    72fde4efed62:	mov    r8,r9
    72fde4efed65:	shl    r8,0x30
    72fde4efed69:	or     r14,r8
    72fde4efed6c:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efed71:	add    r8,0x39
    72fde4efed75:	movzx  r9d,BYTE PTR [r8]
    72fde4efed79:	mov    r8,r9
    72fde4efed7c:	shl    r8,0x30
    72fde4efed80:	or     r15,r8
    72fde4efed83:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efed88:	add    r8,0x3a
    72fde4efed8c:	movzx  r9d,BYTE PTR [r8]
    72fde4efed90:	mov    r8,r9
    72fde4efed93:	shl    r8,0x30
    72fde4efed97:	or     rbp,r8
    72fde4efed9a:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efed9f:	add    r8,0x3b
    72fde4efeda3:	movzx  r9d,BYTE PTR [r8]
    72fde4efeda7:	mov    r8,r9
    72fde4efedaa:	shl    r8,0x30
    72fde4efedae:	or     r13,r8
    72fde4efedb1:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efedb6:	add    r8,0x3c
    72fde4efedba:	movzx  r9d,BYTE PTR [r8]
    72fde4efedbe:	mov    r8,r9
    72fde4efedc1:	shl    r8,0x38
    72fde4efedc5:	or     r14,r8
    72fde4efedc8:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efedcd:	add    r8,0x3d
    72fde4efedd1:	movzx  r9d,BYTE PTR [r8]
    72fde4efedd5:	mov    r8,r9
    72fde4efedd8:	shl    r8,0x38
    72fde4efeddc:	or     r15,r8
    72fde4efeddf:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efede4:	add    r8,0x3e
    72fde4efede8:	movzx  r9d,BYTE PTR [r8]
    72fde4efedec:	mov    r8,r9
    72fde4efedef:	shl    r8,0x38
    72fde4efedf3:	or     rbp,r8
    72fde4efedf6:	mov    r8,QWORD PTR [r12+0x40]
    72fde4efedfb:	add    r8,0x3f
    72fde4efedff:	movzx  r9d,BYTE PTR [r8]
    72fde4efee03:	mov    r8,r9
    72fde4efee06:	shl    r8,0x38
    72fde4efee0a:	mov    rax,r13
    72fde4efee0d:	or     rax,r8
    72fde4efee10:	mov    QWORD PTR [rsp+0x40],rax
    72fde4efee15:	mov    r8d,0x0
    72fde4efee1b:	mov    QWORD PTR [r12+0x58],r8
    72fde4efee20:	mov    r8d,0x0
    72fde4efee26:	mov    r9,QWORD PTR [rsp+0x38]
    72fde4efee2b:	and    r9,0xff
    72fde4efee32:	and    r9,0xffff
    72fde4efee39:	mov    r13,r8
    72fde4efee3c:	or     r13,r9
    72fde4efee3f:	mov    r9,QWORD PTR [rsp+0x38]
    72fde4efee44:	shr    r9,0x8
    72fde4efee48:	and    r9,0xff
    72fde4efee4f:	and    r9,0xffff
    72fde4efee56:	shl    r9,0x10
    72fde4efee5a:	or     r13,r9
    72fde4efee5d:	mov    r9,QWORD PTR [rsp+0x38]
    72fde4efee62:	shr    r9,0x10
    72fde4efee66:	and    r9,0xff
    72fde4efee6d:	and    r9,0xffff
    72fde4efee74:	shl    r9,0x20
    72fde4efee78:	or     r13,r9
    72fde4efee7b:	mov    r9,QWORD PTR [rsp+0x38]
    72fde4efee80:	shr    r9,0x18
    72fde4efee84:	and    r9,0xff
    72fde4efee8b:	and    r9,0xffff
    72fde4efee92:	shl    r9,0x30
    72fde4efee96:	or     r13,r9
    72fde4efee99:	mov    r9,QWORD PTR [rsp+0x38]
    72fde4efee9e:	shr    r9,0x20
    72fde4efeea2:	and    r9,0xff
    72fde4efeea9:	and    r9,0xffff
    72fde4efeeb0:	or     r8,r9
    72fde4efeeb3:	mov    r9,QWORD PTR [rsp+0x38]
    72fde4efeeb8:	shr    r9,0x28
    72fde4efeebc:	and    r9,0xff
    72fde4efeec3:	and    r9,0xffff
    72fde4efeeca:	shl    r9,0x10
    72fde4efeece:	or     r8,r9
    72fde4efeed1:	mov    r9,QWORD PTR [rsp+0x38]
    72fde4efeed6:	shr    r9,0x30
    72fde4efeeda:	and    r9,0xff
    72fde4efeee1:	and    r9,0xffff
    72fde4efeee8:	shl    r9,0x20
    72fde4efeeec:	or     r8,r9
    72fde4efeeef:	mov    r9,QWORD PTR [rsp+0x38]
    72fde4efeef4:	shr    r9,0x38
    72fde4efeef8:	and    r9,0xff
    72fde4efeeff:	and    r9,0xffff
    72fde4efef06:	shl    r9,0x30
    72fde4efef0a:	or     r8,r9
    72fde4efef0d:	mov    QWORD PTR [r12+0x150],r13
    72fde4efef15:	mov    QWORD PTR [r12+0x158],r8
    72fde4efef1d:	mov    r13d,0x0
    72fde4efef23:	mov    r8,QWORD PTR [rsp+0x30]
    72fde4efef28:	and    r8,0xff
    72fde4efef2f:	and    r8,0xffff
    72fde4efef36:	mov    r9,r13
    72fde4efef39:	or     r9,r8
    72fde4efef3c:	mov    r8,QWORD PTR [rsp+0x30]
    72fde4efef41:	shr    r8,0x8
    72fde4efef45:	and    r8,0xff
    72fde4efef4c:	and    r8,0xffff
    72fde4efef53:	shl    r8,0x10
    72fde4efef57:	or     r9,r8
    72fde4efef5a:	mov    r8,QWORD PTR [rsp+0x30]
    72fde4efef5f:	shr    r8,0x10
    72fde4efef63:	and    r8,0xff
    72fde4efef6a:	and    r8,0xffff
    72fde4efef71:	shl    r8,0x20
    72fde4efef75:	or     r9,r8
    72fde4efef78:	mov    r8,QWORD PTR [rsp+0x30]
    72fde4efef7d:	shr    r8,0x18
    72fde4efef81:	and    r8,0xff
    72fde4efef88:	and    r8,0xffff
    72fde4efef8f:	shl    r8,0x30
    72fde4efef93:	mov    rax,r9
    72fde4efef96:	or     rax,r8
    72fde4efef99:	mov    QWORD PTR [rsp+0x50],rax
    72fde4efef9e:	mov    r8,QWORD PTR [rsp+0x30]
    72fde4efefa3:	shr    r8,0x20
    72fde4efefa7:	and    r8,0xff
    72fde4efefae:	and    r8,0xffff
    72fde4efefb5:	or     r13,r8
    72fde4efefb8:	mov    r8,QWORD PTR [rsp+0x30]
    72fde4efefbd:	shr    r8,0x28
    72fde4efefc1:	and    r8,0xff
    72fde4efefc8:	and    r8,0xffff
    72fde4efefcf:	shl    r8,0x10
    72fde4efefd3:	or     r13,r8
    72fde4efefd6:	mov    r8,QWORD PTR [rsp+0x30]
    72fde4efefdb:	shr    r8,0x30
    72fde4efefdf:	and    r8,0xff
    72fde4efefe6:	and    r8,0xffff
    72fde4efefed:	shl    r8,0x20
    72fde4efeff1:	or     r13,r8
    72fde4efeff4:	mov    r8,QWORD PTR [rsp+0x30]
    72fde4efeff9:	shr    r8,0x38
    72fde4efeffd:	and    r8,0xff
    72fde4eff004:	and    r8,0xffff
    72fde4eff00b:	shl    r8,0x30
    72fde4eff00f:	mov    rax,r13
    72fde4eff012:	or     rax,r8
    72fde4eff015:	mov    QWORD PTR [rsp+0x48],rax
    72fde4eff01a:	mov    r8d,0x0
    72fde4eff020:	mov    r13,QWORD PTR [rsp+0x28]
    72fde4eff025:	and    r13,0xff
    72fde4eff02c:	and    r13,0xffff
    72fde4eff033:	mov    r9,r8
    72fde4eff036:	or     r9,r13
    72fde4eff039:	mov    r13,QWORD PTR [rsp+0x28]
    72fde4eff03e:	shr    r13,0x8
    72fde4eff042:	and    r13,0xff
    72fde4eff049:	and    r13,0xffff
    72fde4eff050:	shl    r13,0x10
    72fde4eff054:	or     r9,r13
    72fde4eff057:	mov    r13,QWORD PTR [rsp+0x28]
    72fde4eff05c:	shr    r13,0x10
    72fde4eff060:	and    r13,0xff
    72fde4eff067:	and    r13,0xffff
    72fde4eff06e:	shl    r13,0x20
    72fde4eff072:	or     r9,r13
    72fde4eff075:	mov    r13,QWORD PTR [rsp+0x28]
    72fde4eff07a:	shr    r13,0x18
    72fde4eff07e:	and    r13,0xff
    72fde4eff085:	and    r13,0xffff
    72fde4eff08c:	shl    r13,0x30
    72fde4eff090:	mov    rax,r9
    72fde4eff093:	or     rax,r13
    72fde4eff096:	mov    QWORD PTR [rsp+0x58],rax
    72fde4eff09b:	mov    r13,QWORD PTR [rsp+0x28]
    72fde4eff0a0:	shr    r13,0x20
    72fde4eff0a4:	and    r13,0xff
    72fde4eff0ab:	and    r13,0xffff
    72fde4eff0b2:	or     r8,r13
    72fde4eff0b5:	mov    r13,QWORD PTR [rsp+0x28]
    72fde4eff0ba:	shr    r13,0x28
    72fde4eff0be:	and    r13,0xff
    72fde4eff0c5:	and    r13,0xffff
    72fde4eff0cc:	shl    r13,0x10
    72fde4eff0d0:	or     r8,r13
    72fde4eff0d3:	mov    r13,QWORD PTR [rsp+0x28]
    72fde4eff0d8:	shr    r13,0x30
    72fde4eff0dc:	and    r13,0xff
    72fde4eff0e3:	and    r13,0xffff
    72fde4eff0ea:	shl    r13,0x20
    72fde4eff0ee:	or     r8,r13
    72fde4eff0f1:	mov    r13,QWORD PTR [rsp+0x28]
    72fde4eff0f6:	shr    r13,0x38
    72fde4eff0fa:	and    r13,0xff
    72fde4eff101:	and    r13,0xffff
    72fde4eff108:	shl    r13,0x30
    72fde4eff10c:	mov    rax,r8
    72fde4eff10f:	or     rax,r13
    72fde4eff112:	mov    QWORD PTR [rsp+0x60],rax
    72fde4eff117:	mov    r13d,0x0
    72fde4eff11d:	mov    r9,r14
    72fde4eff120:	and    r9,0xff
    72fde4eff127:	and    r9,0xffff
    72fde4eff12e:	mov    r8,r13
    72fde4eff131:	or     r8,r9
    72fde4eff134:	mov    r9,r14
    72fde4eff137:	shr    r9,0x8
    72fde4eff13b:	and    r9,0xff
    72fde4eff142:	and    r9,0xffff
    72fde4eff149:	shl    r9,0x10
    72fde4eff14d:	or     r8,r9
    72fde4eff150:	mov    r9,r14
    72fde4eff153:	shr    r9,0x10
    72fde4eff157:	and    r9,0xff
    72fde4eff15e:	and    r9,0xffff
    72fde4eff165:	shl    r9,0x20
    72fde4eff169:	or     r8,r9
    72fde4eff16c:	mov    r9,r14
    72fde4eff16f:	shr    r9,0x18
    72fde4eff173:	and    r9,0xff
    72fde4eff17a:	and    r9,0xffff
    72fde4eff181:	shl    r9,0x30
    72fde4eff185:	mov    rax,r8
    72fde4eff188:	or     rax,r9
    72fde4eff18b:	mov    QWORD PTR [rsp+0x68],rax
    72fde4eff190:	mov    r9,r14
    72fde4eff193:	shr    r9,0x20
    72fde4eff197:	and    r9,0xff
    72fde4eff19e:	and    r9,0xffff
    72fde4eff1a5:	or     r13,r9
    72fde4eff1a8:	mov    r9,r14
    72fde4eff1ab:	shr    r9,0x28
    72fde4eff1af:	and    r9,0xff
    72fde4eff1b6:	and    r9,0xffff
    72fde4eff1bd:	shl    r9,0x10
    72fde4eff1c1:	or     r13,r9
    72fde4eff1c4:	mov    r9,r14
    72fde4eff1c7:	shr    r9,0x30
    72fde4eff1cb:	and    r9,0xff
    72fde4eff1d2:	and    r9,0xffff
    72fde4eff1d9:	shl    r9,0x20
    72fde4eff1dd:	or     r13,r9
    72fde4eff1e0:	shr    r14,0x38
    72fde4eff1e4:	and    r14,0xff
    72fde4eff1eb:	and    r14,0xffff
    72fde4eff1f2:	shl    r14,0x30
    72fde4eff1f6:	or     r13,r14
    72fde4eff1f9:	mov    r14d,0x0
    72fde4eff1ff:	mov    r9,r15
    72fde4eff202:	and    r9,0xff
    72fde4eff209:	and    r9,0xffff
    72fde4eff210:	mov    r8,r14
    72fde4eff213:	or     r8,r9
    72fde4eff216:	mov    r9,r15
    72fde4eff219:	shr    r9,0x8
    72fde4eff21d:	and    r9,0xff
    72fde4eff224:	and    r9,0xffff
    72fde4eff22b:	shl    r9,0x10
    72fde4eff22f:	or     r8,r9
    72fde4eff232:	mov    r9,r15
    72fde4eff235:	shr    r9,0x10
    72fde4eff239:	and    r9,0xff
    72fde4eff240:	and    r9,0xffff
    72fde4eff247:	shl    r9,0x20
    72fde4eff24b:	or     r8,r9
    72fde4eff24e:	mov    r9,r15
    72fde4eff251:	shr    r9,0x18
    72fde4eff255:	and    r9,0xff
    72fde4eff25c:	and    r9,0xffff
    72fde4eff263:	shl    r9,0x30
    72fde4eff267:	or     r8,r9
    72fde4eff26a:	mov    r9,r15
    72fde4eff26d:	shr    r9,0x20
    72fde4eff271:	and    r9,0xff
    72fde4eff278:	and    r9,0xffff
    72fde4eff27f:	or     r14,r9
    72fde4eff282:	mov    r9,r15
    72fde4eff285:	shr    r9,0x28
    72fde4eff289:	and    r9,0xff
    72fde4eff290:	and    r9,0xffff
    72fde4eff297:	shl    r9,0x10
    72fde4eff29b:	or     r14,r9
    72fde4eff29e:	mov    r9,r15
    72fde4eff2a1:	shr    r9,0x30
    72fde4eff2a5:	and    r9,0xff
    72fde4eff2ac:	and    r9,0xffff
    72fde4eff2b3:	shl    r9,0x20
    72fde4eff2b7:	or     r14,r9
    72fde4eff2ba:	shr    r15,0x38
    72fde4eff2be:	and    r15,0xff
    72fde4eff2c5:	and    r15,0xffff
    72fde4eff2cc:	shl    r15,0x30
    72fde4eff2d0:	or     r14,r15
    72fde4eff2d3:	mov    QWORD PTR [r12+0x210],r8
    72fde4eff2db:	mov    QWORD PTR [r12+0x218],r14
    72fde4eff2e3:	mov    r14d,0x0
    72fde4eff2e9:	mov    r15,rbp
    72fde4eff2ec:	and    r15,0xff
    72fde4eff2f3:	and    r15,0xffff
    72fde4eff2fa:	mov    r8,r14
    72fde4eff2fd:	or     r8,r15
    72fde4eff300:	mov    r15,rbp
    72fde4eff303:	shr    r15,0x8
    72fde4eff307:	and    r15,0xff
    72fde4eff30e:	and    r15,0xffff
    72fde4eff315:	shl    r15,0x10
    72fde4eff319:	or     r8,r15
    72fde4eff31c:	mov    r15,rbp
    72fde4eff31f:	shr    r15,0x10
    72fde4eff323:	and    r15,0xff
    72fde4eff32a:	and    r15,0xffff
    72fde4eff331:	shl    r15,0x20
    72fde4eff335:	or     r8,r15
    72fde4eff338:	mov    r15,rbp
    72fde4eff33b:	shr    r15,0x18
    72fde4eff33f:	and    r15,0xff
    72fde4eff346:	and    r15,0xffff
    72fde4eff34d:	shl    r15,0x30
    72fde4eff351:	or     r8,r15
    72fde4eff354:	mov    r15,rbp
    72fde4eff357:	shr    r15,0x20
    72fde4eff35b:	and    r15,0xff
    72fde4eff362:	and    r15,0xffff
    72fde4eff369:	or     r14,r15
    72fde4eff36c:	mov    r15,rbp
    72fde4eff36f:	shr    r15,0x28
    72fde4eff373:	and    r15,0xff
    72fde4eff37a:	and    r15,0xffff
    72fde4eff381:	shl    r15,0x10
    72fde4eff385:	or     r14,r15
    72fde4eff388:	mov    r15,rbp
    72fde4eff38b:	shr    r15,0x30
    72fde4eff38f:	and    r15,0xff
    72fde4eff396:	and    r15,0xffff
    72fde4eff39d:	shl    r15,0x20
    72fde4eff3a1:	or     r14,r15
    72fde4eff3a4:	shr    rbp,0x38
    72fde4eff3a8:	and    rbp,0xff
    72fde4eff3af:	and    rbp,0xffff
    72fde4eff3b6:	shl    rbp,0x30
    72fde4eff3ba:	or     r14,rbp
    72fde4eff3bd:	mov    r15d,0x0
    72fde4eff3c3:	mov    rbp,QWORD PTR [rsp+0x20]
    72fde4eff3c8:	and    rbp,0xff
    72fde4eff3cf:	and    rbp,0xffff
    72fde4eff3d6:	mov    r9,r15
    72fde4eff3d9:	or     r9,rbp
    72fde4eff3dc:	mov    rbp,QWORD PTR [rsp+0x20]
    72fde4eff3e1:	shr    rbp,0x8
    72fde4eff3e5:	and    rbp,0xff
    72fde4eff3ec:	and    rbp,0xffff
    72fde4eff3f3:	shl    rbp,0x10
    72fde4eff3f7:	or     r9,rbp
    72fde4eff3fa:	mov    rbp,QWORD PTR [rsp+0x20]
    72fde4eff3ff:	shr    rbp,0x10
    72fde4eff403:	and    rbp,0xff
    72fde4eff40a:	and    rbp,0xffff
    72fde4eff411:	shl    rbp,0x20
    72fde4eff415:	or     r9,rbp
    72fde4eff418:	mov    rbp,QWORD PTR [rsp+0x20]
    72fde4eff41d:	shr    rbp,0x18
    72fde4eff421:	and    rbp,0xff
    72fde4eff428:	and    rbp,0xffff
    72fde4eff42f:	shl    rbp,0x30
    72fde4eff433:	mov    rax,r9
    72fde4eff436:	or     rax,rbp
    72fde4eff439:	mov    QWORD PTR [rsp+0x78],rax
    72fde4eff43e:	mov    rbp,QWORD PTR [rsp+0x20]
    72fde4eff443:	shr    rbp,0x20
    72fde4eff447:	and    rbp,0xff
    72fde4eff44e:	and    rbp,0xffff
    72fde4eff455:	or     r15,rbp
    72fde4eff458:	mov    rbp,QWORD PTR [rsp+0x20]
    72fde4eff45d:	shr    rbp,0x28
    72fde4eff461:	and    rbp,0xff
    72fde4eff468:	and    rbp,0xffff
    72fde4eff46f:	shl    rbp,0x10
    72fde4eff473:	or     r15,rbp
    72fde4eff476:	mov    rbp,QWORD PTR [rsp+0x20]
    72fde4eff47b:	shr    rbp,0x30
    72fde4eff47f:	and    rbp,0xff
    72fde4eff486:	and    rbp,0xffff
    72fde4eff48d:	shl    rbp,0x20
    72fde4eff491:	or     r15,rbp
    72fde4eff494:	mov    rbp,QWORD PTR [rsp+0x20]
    72fde4eff499:	shr    rbp,0x38
    72fde4eff49d:	and    rbp,0xff
    72fde4eff4a4:	and    rbp,0xffff
    72fde4eff4ab:	shl    rbp,0x30
    72fde4eff4af:	mov    rax,r15
    72fde4eff4b2:	or     rax,rbp
    72fde4eff4b5:	mov    QWORD PTR [rsp+0x70],rax
    72fde4eff4ba:	mov    rax,QWORD PTR [rsp+0x78]
    72fde4eff4bf:	mov    QWORD PTR [r12+0x250],rax
    72fde4eff4c7:	mov    rax,QWORD PTR [rsp+0x70]
    72fde4eff4cc:	mov    QWORD PTR [r12+0x258],rax
    72fde4eff4d4:	mov    ebp,0x0
    72fde4eff4d9:	mov    r15,QWORD PTR [rsp+0x40]
    72fde4eff4de:	and    r15,0xff
    72fde4eff4e5:	and    r15,0xffff
    72fde4eff4ec:	mov    r9,rbp
    72fde4eff4ef:	or     r9,r15
    72fde4eff4f2:	mov    r15,QWORD PTR [rsp+0x40]
    72fde4eff4f7:	shr    r15,0x8
    72fde4eff4fb:	and    r15,0xff
    72fde4eff502:	and    r15,0xffff
    72fde4eff509:	shl    r15,0x10
    72fde4eff50d:	or     r9,r15
    72fde4eff510:	mov    r15,QWORD PTR [rsp+0x40]
    72fde4eff515:	shr    r15,0x10
    72fde4eff519:	and    r15,0xff
    72fde4eff520:	and    r15,0xffff
    72fde4eff527:	shl    r15,0x20
    72fde4eff52b:	or     r9,r15
    72fde4eff52e:	mov    r15,QWORD PTR [rsp+0x40]
    72fde4eff533:	shr    r15,0x18
    72fde4eff537:	and    r15,0xff
    72fde4eff53e:	and    r15,0xffff
    72fde4eff545:	shl    r15,0x30
    72fde4eff549:	mov    rax,r9
    72fde4eff54c:	or     rax,r15
    72fde4eff54f:	mov    QWORD PTR [rsp+0x80],rax
    72fde4eff557:	mov    r15,QWORD PTR [rsp+0x40]
    72fde4eff55c:	shr    r15,0x20
    72fde4eff560:	and    r15,0xff
    72fde4eff567:	and    r15,0xffff
    72fde4eff56e:	or     rbp,r15
    72fde4eff571:	mov    r15,QWORD PTR [rsp+0x40]
    72fde4eff576:	shr    r15,0x28
    72fde4eff57a:	and    r15,0xff
    72fde4eff581:	and    r15,0xffff
    72fde4eff588:	shl    r15,0x10
    72fde4eff58c:	or     rbp,r15
    72fde4eff58f:	mov    r15,QWORD PTR [rsp+0x40]
    72fde4eff594:	shr    r15,0x30
    72fde4eff598:	and    r15,0xff
    72fde4eff59f:	and    r15,0xffff
    72fde4eff5a6:	shl    r15,0x20
    72fde4eff5aa:	or     rbp,r15
    72fde4eff5ad:	mov    r15,QWORD PTR [rsp+0x40]
    72fde4eff5b2:	shr    r15,0x38
    72fde4eff5b6:	and    r15,0xff
    72fde4eff5bd:	and    r15,0xffff
    72fde4eff5c4:	shl    r15,0x30
    72fde4eff5c8:	mov    rax,rbp
    72fde4eff5cb:	or     rax,r15
    72fde4eff5ce:	mov    QWORD PTR [rsp+0x88],rax
    72fde4eff5d6:	movdqu xmm2,XMMWORD PTR [r12+0x150]
    72fde4eff5e0:	pxor   xmm0,xmm0
    72fde4eff5e4:	movdqa xmm3,xmm0
    72fde4eff5e8:	movdqa xmm0,xmm2
    72fde4eff5ec:	movdqa xmm1,xmm3
    72fde4eff5f0:	punpcklwd xmm0,xmm1
    72fde4eff5f4:	movdqa xmm4,xmm0
    72fde4eff5f8:	movdqa xmm0,xmm4
    72fde4eff5fc:	pslld  xmm0,0x10
    72fde4eff601:	movdqa xmm3,xmm0
    72fde4eff605:	mov    r15d,0x0
    72fde4eff60b:	mov    r9,QWORD PTR [rsp+0x50]
    72fde4eff610:	and    r9,0xffff
    72fde4eff617:	shl    r9,0x8
    72fde4eff61b:	mov    ecx,0xffffffff
    72fde4eff620:	and    r9,rcx
    72fde4eff623:	mov    rbp,r15
    72fde4eff626:	or     rbp,r9
    72fde4eff629:	mov    r9,QWORD PTR [rsp+0x50]
    72fde4eff62e:	shr    r9,0x10
    72fde4eff632:	and    r9,0xffff
    72fde4eff639:	shl    r9,0x8
    72fde4eff63d:	mov    ecx,0xffffffff
    72fde4eff642:	and    r9,rcx
    72fde4eff645:	shl    r9,0x20
    72fde4eff649:	or     rbp,r9
    72fde4eff64c:	mov    r9,QWORD PTR [rsp+0x50]
    72fde4eff651:	shr    r9,0x20
    72fde4eff655:	and    r9,0xffff
    72fde4eff65c:	shl    r9,0x8
    72fde4eff660:	mov    ecx,0xffffffff
    72fde4eff665:	and    r9,rcx
    72fde4eff668:	or     r15,r9
    72fde4eff66b:	mov    r9,QWORD PTR [rsp+0x50]
    72fde4eff670:	shr    r9,0x30
    72fde4eff674:	and    r9,0xffff
    72fde4eff67b:	shl    r9,0x8
    72fde4eff67f:	mov    ecx,0xffffffff
    72fde4eff684:	and    r9,rcx
    72fde4eff687:	shl    r9,0x20
    72fde4eff68b:	or     r15,r9
    72fde4eff68e:	mov    QWORD PTR [r12+0x240],rbp
    72fde4eff696:	mov    QWORD PTR [r12+0x248],r15
    72fde4eff69e:	mov    r15d,0x0
    72fde4eff6a4:	mov    rbp,QWORD PTR [rsp+0x60]
    72fde4eff6a9:	and    rbp,0xffff
    72fde4eff6b0:	mov    ecx,0xffffffff
    72fde4eff6b5:	and    rbp,rcx
    72fde4eff6b8:	mov    r9,r15
    72fde4eff6bb:	or     r9,rbp
    72fde4eff6be:	mov    rbp,QWORD PTR [rsp+0x60]
    72fde4eff6c3:	shr    rbp,0x10
    72fde4eff6c7:	and    rbp,0xffff
    72fde4eff6ce:	mov    ecx,0xffffffff
    72fde4eff6d3:	and    rbp,rcx
    72fde4eff6d6:	shl    rbp,0x20
    72fde4eff6da:	or     r9,rbp
    72fde4eff6dd:	mov    rbp,QWORD PTR [rsp+0x60]
    72fde4eff6e2:	shr    rbp,0x20
    72fde4eff6e6:	and    rbp,0xffff
    72fde4eff6ed:	mov    ecx,0xffffffff
    72fde4eff6f2:	and    rbp,rcx
    72fde4eff6f5:	or     r15,rbp
    72fde4eff6f8:	mov    rbp,QWORD PTR [rsp+0x60]
    72fde4eff6fd:	shr    rbp,0x30
    72fde4eff701:	and    rbp,0xffff
    72fde4eff708:	mov    ecx,0xffffffff
    72fde4eff70d:	and    rbp,rcx
    72fde4eff710:	shl    rbp,0x20
    72fde4eff714:	or     r15,rbp
    72fde4eff717:	mov    QWORD PTR [r12+0x260],r9
    72fde4eff71f:	mov    QWORD PTR [r12+0x268],r15
    72fde4eff727:	mov    r15d,0x0
    72fde4eff72d:	mov    rbp,r13
    72fde4eff730:	and    rbp,0xffff
    72fde4eff737:	mov    ecx,0xffffffff
    72fde4eff73c:	and    rbp,rcx
    72fde4eff73f:	mov    r9,r15
    72fde4eff742:	or     r9,rbp
    72fde4eff745:	mov    rbp,r13
    72fde4eff748:	shr    rbp,0x10
    72fde4eff74c:	and    rbp,0xffff
    72fde4eff753:	mov    ecx,0xffffffff
    72fde4eff758:	and    rbp,rcx
    72fde4eff75b:	shl    rbp,0x20
    72fde4eff75f:	or     r9,rbp
    72fde4eff762:	mov    rbp,r13
    72fde4eff765:	shr    rbp,0x20
    72fde4eff769:	and    rbp,0xffff
    72fde4eff770:	mov    ecx,0xffffffff
    72fde4eff775:	and    rbp,rcx
    72fde4eff778:	or     r15,rbp
    72fde4eff77b:	shr    r13,0x30
    72fde4eff77f:	and    r13,0xffff
    72fde4eff786:	mov    ecx,0xffffffff
    72fde4eff78b:	and    r13,rcx
    72fde4eff78e:	shl    r13,0x20
    72fde4eff792:	or     r15,r13
    72fde4eff795:	mov    QWORD PTR [r12+0x270],r9
    72fde4eff79d:	mov    QWORD PTR [r12+0x278],r15
    72fde4eff7a5:	mov    r13d,0x0
    72fde4eff7ab:	mov    r15,QWORD PTR [rsp+0x58]
    72fde4eff7b0:	and    r15,0xffff
    72fde4eff7b7:	mov    ecx,0xffffffff
    72fde4eff7bc:	and    r15,rcx
    72fde4eff7bf:	mov    rbp,r13
    72fde4eff7c2:	or     rbp,r15
    72fde4eff7c5:	mov    r15,QWORD PTR [rsp+0x58]
    72fde4eff7ca:	shr    r15,0x10
    72fde4eff7ce:	and    r15,0xffff
    72fde4eff7d5:	mov    ecx,0xffffffff
    72fde4eff7da:	and    r15,rcx
    72fde4eff7dd:	shl    r15,0x20
    72fde4eff7e1:	or     rbp,r15
    72fde4eff7e4:	mov    r15,QWORD PTR [rsp+0x58]
    72fde4eff7e9:	shr    r15,0x20
    72fde4eff7ed:	and    r15,0xffff
    72fde4eff7f4:	mov    ecx,0xffffffff
    72fde4eff7f9:	and    r15,rcx
    72fde4eff7fc:	or     r13,r15
    72fde4eff7ff:	mov    r15,QWORD PTR [rsp+0x58]
    72fde4eff804:	shr    r15,0x30
    72fde4eff808:	and    r15,0xffff
    72fde4eff80f:	mov    ecx,0xffffffff
    72fde4eff814:	and    r15,rcx
    72fde4eff817:	shl    r15,0x20
    72fde4eff81b:	or     r13,r15
    72fde4eff81e:	mov    QWORD PTR [r12+0x170],rbp
    72fde4eff826:	mov    QWORD PTR [r12+0x178],r13
    72fde4eff82e:	movdqu xmm4,XMMWORD PTR [r12+0x210]
    72fde4eff838:	pxor   xmm0,xmm0
    72fde4eff83c:	movdqa xmm5,xmm0
    72fde4eff840:	movdqa xmm0,xmm4
    72fde4eff844:	movdqa xmm1,xmm5
    72fde4eff848:	punpckhwd xmm0,xmm1
    72fde4eff84c:	movdqa xmm6,xmm0
    72fde4eff850:	movdqa xmm0,xmm6
    72fde4eff854:	pslld  xmm0,0x10
    72fde4eff859:	movdqa xmm5,xmm0
    72fde4eff85d:	movdqu XMMWORD PTR [r12+0x280],xmm5
    72fde4eff867:	mov    r13d,0x0
    72fde4eff86d:	mov    r15,QWORD PTR [rsp+0x68]
    72fde4eff872:	and    r15,0xffff
    72fde4eff879:	mov    ecx,0xffffffff
    72fde4eff87e:	and    r15,rcx
    72fde4eff881:	mov    rbp,r13
    72fde4eff884:	or     rbp,r15
    72fde4eff887:	mov    r15,QWORD PTR [rsp+0x68]
    72fde4eff88c:	shr    r15,0x10
    72fde4eff890:	and    r15,0xffff
    72fde4eff897:	mov    ecx,0xffffffff
    72fde4eff89c:	and    r15,rcx
    72fde4eff89f:	shl    r15,0x20
    72fde4eff8a3:	or     rbp,r15
    72fde4eff8a6:	mov    r15,QWORD PTR [rsp+0x68]
    72fde4eff8ab:	shr    r15,0x20
    72fde4eff8af:	and    r15,0xffff
    72fde4eff8b6:	mov    ecx,0xffffffff
    72fde4eff8bb:	and    r15,rcx
    72fde4eff8be:	or     r13,r15
    72fde4eff8c1:	mov    r15,QWORD PTR [rsp+0x68]
    72fde4eff8c6:	shr    r15,0x30
    72fde4eff8ca:	and    r15,0xffff
    72fde4eff8d1:	mov    ecx,0xffffffff
    72fde4eff8d6:	and    r15,rcx
    72fde4eff8d9:	shl    r15,0x20
    72fde4eff8dd:	or     r13,r15
    72fde4eff8e0:	mov    QWORD PTR [r12+0x180],rbp
    72fde4eff8e8:	mov    QWORD PTR [r12+0x188],r13
    72fde4eff8f0:	pxor   xmm0,xmm0
    72fde4eff8f4:	movdqa xmm6,xmm0
    72fde4eff8f8:	movdqa xmm0,xmm4
    72fde4eff8fc:	movdqa xmm1,xmm6
    72fde4eff900:	punpcklwd xmm0,xmm1
    72fde4eff904:	movdqa xmm7,xmm0
    72fde4eff908:	movdqa xmm0,xmm7
    72fde4eff90c:	pslld  xmm0,0x10
    72fde4eff911:	movdqa xmm4,xmm0
    72fde4eff915:	pxor   xmm0,xmm0
    72fde4eff919:	movdqa xmm6,xmm0
    72fde4eff91d:	movdqa xmm0,xmm2
    72fde4eff921:	movdqa xmm1,xmm6
    72fde4eff925:	punpckhwd xmm0,xmm1
    72fde4eff929:	movdqa xmm7,xmm0
    72fde4eff92d:	movdqa xmm0,xmm7
    72fde4eff931:	pslld  xmm0,0x10
    72fde4eff936:	movdqa xmm2,xmm0
    72fde4eff93a:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    72fde4eff944:	movdqa xmm1,xmm6
    72fde4eff948:	por    xmm3,xmm1
    72fde4eff94c:	movdqu XMMWORD PTR [r12+0x230],xmm3
    72fde4eff956:	mov    r13d,0x0
    72fde4eff95c:	mov    r15,r14
    72fde4eff95f:	and    r15,0xffff
    72fde4eff966:	shl    r15,0x8
    72fde4eff96a:	mov    ecx,0xffffffff
    72fde4eff96f:	and    r15,rcx
    72fde4eff972:	mov    rbp,r13
    72fde4eff975:	or     rbp,r15
    72fde4eff978:	mov    r15,r14
    72fde4eff97b:	shr    r15,0x10
    72fde4eff97f:	and    r15,0xffff
    72fde4eff986:	shl    r15,0x8
    72fde4eff98a:	mov    ecx,0xffffffff
    72fde4eff98f:	and    r15,rcx
    72fde4eff992:	shl    r15,0x20
    72fde4eff996:	or     rbp,r15
    72fde4eff999:	mov    r15,r14
    72fde4eff99c:	shr    r15,0x20
    72fde4eff9a0:	and    r15,0xffff
    72fde4eff9a7:	shl    r15,0x8
    72fde4eff9ab:	mov    ecx,0xffffffff
    72fde4eff9b0:	and    r15,rcx
    72fde4eff9b3:	or     r13,r15
    72fde4eff9b6:	shr    r14,0x30
    72fde4eff9ba:	and    r14,0xffff
    72fde4eff9c1:	shl    r14,0x8
    72fde4eff9c5:	mov    ecx,0xffffffff
    72fde4eff9ca:	and    r14,rcx
    72fde4eff9cd:	shl    r14,0x20
    72fde4eff9d1:	or     r13,r14
    72fde4eff9d4:	mov    QWORD PTR [r12+0x240],rbp
    72fde4eff9dc:	mov    QWORD PTR [r12+0x248],r13
    72fde4eff9e4:	mov    r13d,0x0
    72fde4eff9ea:	mov    r14,r8
    72fde4eff9ed:	and    r14,0xffff
    72fde4eff9f4:	shl    r14,0x8
    72fde4eff9f8:	mov    ecx,0xffffffff
    72fde4eff9fd:	and    r14,rcx
    72fde4effa00:	mov    r15,r13
    72fde4effa03:	or     r15,r14
    72fde4effa06:	mov    r14,r8
    72fde4effa09:	shr    r14,0x10
    72fde4effa0d:	and    r14,0xffff
    72fde4effa14:	shl    r14,0x8
    72fde4effa18:	mov    ecx,0xffffffff
    72fde4effa1d:	and    r14,rcx
    72fde4effa20:	shl    r14,0x20
    72fde4effa24:	or     r15,r14
    72fde4effa27:	mov    r14,r8
    72fde4effa2a:	shr    r14,0x20
    72fde4effa2e:	and    r14,0xffff
    72fde4effa35:	shl    r14,0x8
    72fde4effa39:	mov    ecx,0xffffffff
    72fde4effa3e:	and    r14,rcx
    72fde4effa41:	or     r13,r14
    72fde4effa44:	shr    r8,0x30
    72fde4effa48:	and    r8,0xffff
    72fde4effa4f:	shl    r8,0x8
    72fde4effa53:	mov    ecx,0xffffffff
    72fde4effa58:	and    r8,rcx
    72fde4effa5b:	shl    r8,0x20
    72fde4effa5f:	or     r13,r8
    72fde4effa62:	mov    QWORD PTR [r12+0x220],r15
    72fde4effa6a:	mov    QWORD PTR [r12+0x228],r13
    72fde4effa72:	mov    r13d,0x0
    72fde4effa78:	mov    r14,QWORD PTR [rsp+0x48]
    72fde4effa7d:	and    r14,0xffff
    72fde4effa84:	shl    r14,0x8
    72fde4effa88:	mov    ecx,0xffffffff
    72fde4effa8d:	and    r14,rcx
    72fde4effa90:	mov    r15,r13
    72fde4effa93:	or     r15,r14
    72fde4effa96:	mov    r14,QWORD PTR [rsp+0x48]
    72fde4effa9b:	shr    r14,0x10
    72fde4effa9f:	and    r14,0xffff
    72fde4effaa6:	shl    r14,0x8
    72fde4effaaa:	mov    ecx,0xffffffff
    72fde4effaaf:	and    r14,rcx
    72fde4effab2:	shl    r14,0x20
    72fde4effab6:	or     r15,r14
    72fde4effab9:	mov    r14,QWORD PTR [rsp+0x48]
    72fde4effabe:	shr    r14,0x20
    72fde4effac2:	and    r14,0xffff
    72fde4effac9:	shl    r14,0x8
    72fde4effacd:	mov    ecx,0xffffffff
    72fde4effad2:	and    r14,rcx
    72fde4effad5:	or     r13,r14
    72fde4effad8:	mov    r14,QWORD PTR [rsp+0x48]
    72fde4effadd:	shr    r14,0x30
    72fde4effae1:	and    r14,0xffff
    72fde4effae8:	shl    r14,0x8
    72fde4effaec:	mov    ecx,0xffffffff
    72fde4effaf1:	and    r14,rcx
    72fde4effaf4:	shl    r14,0x20
    72fde4effaf8:	or     r13,r14
    72fde4effafb:	mov    QWORD PTR [r12+0x160],r15
    72fde4effb03:	mov    QWORD PTR [r12+0x168],r13
    72fde4effb0b:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    72fde4effb15:	movdqa xmm0,xmm6
    72fde4effb19:	pslld  xmm0,0x18
    72fde4effb1e:	movdqa xmm7,xmm0
    72fde4effb22:	movdqu XMMWORD PTR [r12+0x170],xmm7
    72fde4effb2c:	movdqu xmm6,XMMWORD PTR [r12+0x270]
    72fde4effb36:	movdqa xmm0,xmm6
    72fde4effb3a:	pslld  xmm0,0x18
    72fde4effb3f:	movdqa xmm8,xmm0
    72fde4effb44:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    72fde4effb4e:	movdqa xmm0,xmm6
    72fde4effb52:	pslld  xmm0,0x18
    72fde4effb57:	movdqa xmm9,xmm0
    72fde4effb5c:	movdqu XMMWORD PTR [r12+0x180],xmm9
    72fde4effb66:	mov    r13d,0x0
    72fde4effb6c:	mov    r14,QWORD PTR [rsp+0x78]
    72fde4effb71:	and    r14,0xffff
    72fde4effb78:	mov    ecx,0xffffffff
    72fde4effb7d:	and    r14,rcx
    72fde4effb80:	mov    r15,r13
    72fde4effb83:	or     r15,r14
    72fde4effb86:	mov    r14,QWORD PTR [rsp+0x78]
    72fde4effb8b:	shr    r14,0x10
    72fde4effb8f:	and    r14,0xffff
    72fde4effb96:	mov    ecx,0xffffffff
    72fde4effb9b:	and    r14,rcx
    72fde4effb9e:	shl    r14,0x20
    72fde4effba2:	or     r15,r14
    72fde4effba5:	mov    r14,QWORD PTR [rsp+0x78]
    72fde4effbaa:	shr    r14,0x20
    72fde4effbae:	and    r14,0xffff
    72fde4effbb5:	mov    ecx,0xffffffff
    72fde4effbba:	and    r14,rcx
    72fde4effbbd:	or     r13,r14
    72fde4effbc0:	mov    r14,QWORD PTR [rsp+0x78]
    72fde4effbc5:	shr    r14,0x30
    72fde4effbc9:	and    r14,0xffff
    72fde4effbd0:	mov    ecx,0xffffffff
    72fde4effbd5:	and    r14,rcx
    72fde4effbd8:	shl    r14,0x20
    72fde4effbdc:	or     r13,r14
    72fde4effbdf:	mov    QWORD PTR [r12+0x140],r15
    72fde4effbe7:	mov    QWORD PTR [r12+0x148],r13
    72fde4effbef:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    72fde4effbf9:	movdqa xmm1,xmm6
    72fde4effbfd:	por    xmm5,xmm1
    72fde4effc01:	movdqu xmm6,XMMWORD PTR [r12+0x220]
    72fde4effc0b:	movdqa xmm1,xmm6
    72fde4effc0f:	por    xmm4,xmm1
    72fde4effc13:	movdqu XMMWORD PTR [r12+0x210],xmm4
    72fde4effc1d:	movdqu xmm6,XMMWORD PTR [r12+0x260]
    72fde4effc27:	movdqa xmm0,xmm6
    72fde4effc2b:	pslld  xmm0,0x18
    72fde4effc30:	movdqa xmm10,xmm0
    72fde4effc35:	movdqu XMMWORD PTR [r12+0x220],xmm10
    72fde4effc3f:	movdqu xmm6,XMMWORD PTR [r12+0x160]
    72fde4effc49:	movdqa xmm1,xmm6
    72fde4effc4d:	por    xmm2,xmm1
    72fde4effc51:	movdqa xmm1,xmm7
    72fde4effc55:	por    xmm3,xmm1
    72fde4effc59:	movdqu XMMWORD PTR [r12+0x160],xmm3
    72fde4effc63:	mov    r13d,0x0
    72fde4effc69:	mov    r14,QWORD PTR [rsp+0x88]
    72fde4effc71:	and    r14,0xffff
    72fde4effc78:	mov    ecx,0xffffffff
    72fde4effc7d:	and    r14,rcx
    72fde4effc80:	mov    r15,r13
    72fde4effc83:	or     r15,r14
    72fde4effc86:	mov    r14,QWORD PTR [rsp+0x88]
    72fde4effc8e:	shr    r14,0x10
    72fde4effc92:	and    r14,0xffff
    72fde4effc99:	mov    ecx,0xffffffff
    72fde4effc9e:	and    r14,rcx
    72fde4effca1:	shl    r14,0x20
    72fde4effca5:	or     r15,r14
    72fde4effca8:	mov    r14,QWORD PTR [rsp+0x88]
    72fde4effcb0:	shr    r14,0x20
    72fde4effcb4:	and    r14,0xffff
    72fde4effcbb:	mov    ecx,0xffffffff
    72fde4effcc0:	and    r14,rcx
    72fde4effcc3:	or     r13,r14
    72fde4effcc6:	mov    r14,QWORD PTR [rsp+0x88]
    72fde4effcce:	shr    r14,0x30
    72fde4effcd2:	and    r14,0xffff
    72fde4effcd9:	mov    ecx,0xffffffff
    72fde4effcde:	and    r14,rcx
    72fde4effce1:	shl    r14,0x20
    72fde4effce5:	or     r13,r14
    72fde4effce8:	mov    QWORD PTR [r12+0x170],r15
    72fde4effcf0:	mov    QWORD PTR [r12+0x178],r13
    72fde4effcf8:	mov    r13d,0x0
    72fde4effcfe:	mov    r14,QWORD PTR [rsp+0x80]
    72fde4effd06:	and    r14,0xffff
    72fde4effd0d:	mov    ecx,0xffffffff
    72fde4effd12:	and    r14,rcx
    72fde4effd15:	mov    r15,r13
    72fde4effd18:	or     r15,r14
    72fde4effd1b:	mov    r14,QWORD PTR [rsp+0x80]
    72fde4effd23:	shr    r14,0x10
    72fde4effd27:	and    r14,0xffff
    72fde4effd2e:	mov    ecx,0xffffffff
    72fde4effd33:	and    r14,rcx
    72fde4effd36:	shl    r14,0x20
    72fde4effd3a:	or     r15,r14
    72fde4effd3d:	mov    r14,QWORD PTR [rsp+0x80]
    72fde4effd45:	shr    r14,0x20
    72fde4effd49:	and    r14,0xffff
    72fde4effd50:	mov    ecx,0xffffffff
    72fde4effd55:	and    r14,rcx
    72fde4effd58:	or     r13,r14
    72fde4effd5b:	mov    r14,QWORD PTR [rsp+0x80]
    72fde4effd63:	shr    r14,0x30
    72fde4effd67:	and    r14,0xffff
    72fde4effd6e:	mov    ecx,0xffffffff
    72fde4effd73:	and    r14,rcx
    72fde4effd76:	shl    r14,0x20
    72fde4effd7a:	or     r13,r14
    72fde4effd7d:	mov    QWORD PTR [r12+0x110],r15
    72fde4effd85:	mov    QWORD PTR [r12+0x118],r13
    72fde4effd8d:	movdqa xmm1,xmm8
    72fde4effd92:	por    xmm5,xmm1
    72fde4effd96:	movdqa xmm1,xmm9
    72fde4effd9b:	por    xmm4,xmm1
    72fde4effd9f:	mov    r13d,0x0
    72fde4effda5:	mov    r14,QWORD PTR [rsp+0x70]
    72fde4effdaa:	and    r14,0xffff
    72fde4effdb1:	mov    ecx,0xffffffff
    72fde4effdb6:	and    r14,rcx
    72fde4effdb9:	mov    r15,r13
    72fde4effdbc:	or     r15,r14
    72fde4effdbf:	mov    r14,QWORD PTR [rsp+0x70]
    72fde4effdc4:	shr    r14,0x10
    72fde4effdc8:	and    r14,0xffff
    72fde4effdcf:	mov    ecx,0xffffffff
    72fde4effdd4:	and    r14,rcx
    72fde4effdd7:	shl    r14,0x20
    72fde4effddb:	or     r15,r14
    72fde4effdde:	mov    r14,QWORD PTR [rsp+0x70]
    72fde4effde3:	shr    r14,0x20
    72fde4effde7:	and    r14,0xffff
    72fde4effdee:	mov    ecx,0xffffffff
    72fde4effdf3:	and    r14,rcx
    72fde4effdf6:	or     r13,r14
    72fde4effdf9:	mov    r14,QWORD PTR [rsp+0x70]
    72fde4effdfe:	shr    r14,0x30
    72fde4effe02:	and    r14,0xffff
    72fde4effe09:	mov    ecx,0xffffffff
    72fde4effe0e:	and    r14,rcx
    72fde4effe11:	shl    r14,0x20
    72fde4effe15:	or     r13,r14
    72fde4effe18:	mov    QWORD PTR [r12+0x180],r15
    72fde4effe20:	mov    QWORD PTR [r12+0x188],r13
    72fde4effe28:	movdqa xmm1,xmm10
    72fde4effe2d:	por    xmm2,xmm1
    72fde4effe31:	movdqu XMMWORD PTR [r12+0x150],xmm2
    72fde4effe3b:	movdqu xmm6,XMMWORD PTR [r12+0x140]
    72fde4effe45:	movdqa xmm1,xmm6
    72fde4effe49:	por    xmm3,xmm1
    72fde4effe4d:	movdqu XMMWORD PTR [r12+0x140],xmm3
    72fde4effe57:	movdqu xmm6,XMMWORD PTR [r12+0x110]
    72fde4effe61:	movdqa xmm1,xmm6
    72fde4effe65:	por    xmm4,xmm1
    72fde4effe69:	movdqu XMMWORD PTR [r12+0x110],xmm4
    72fde4effe73:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    72fde4effe7d:	movdqa xmm1,xmm6
    72fde4effe81:	por    xmm5,xmm1
    72fde4effe85:	movdqu XMMWORD PTR [r12+0x120],xmm5
    72fde4effe8f:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    72fde4effe99:	movdqa xmm1,xmm6
    72fde4effe9d:	por    xmm2,xmm1
    72fde4effea1:	movdqu XMMWORD PTR [r12+0x130],xmm2
    72fde4effeab:	mov    r13,QWORD PTR [r12+0xf8]
    72fde4effeb3:	mov    r14,r13
    72fde4effeb6:	add    r14,0x20
    72fde4effeba:	mov    r15,r14
    72fde4effebd:	add    r15,0x10
    72fde4effec1:	movdqu XMMWORD PTR [r14],xmm4
    72fde4effec6:	mov    r14d,0x0
    72fde4effecc:	mov    DWORD PTR [r12+0x32c],r14d
    72fde4effed4:	movdqu XMMWORD PTR [r15],xmm5
    72fde4effed9:	mov    r14,r13
    72fde4effedc:	add    r14,0x10
    72fde4effee0:	movdqu XMMWORD PTR [r13+0x0],xmm3
    72fde4effee6:	movdqu XMMWORD PTR [r14],xmm2
    72fde4effeeb:	mov    r14d,DWORD PTR [r13+0x0]
    72fde4effeef:	mov    QWORD PTR [r12+0x60],r14
    72fde4effef4:	jmp    0x72fde4effef9
    72fde4effef9:	mov    r13,QWORD PTR [r12+0x58]
    72fde4effefe:	mov    r14,QWORD PTR [r12+0x48]
    72fde4efff03:	add    r14,r13
    72fde4efff06:	mov    QWORD PTR [r12+0x68],r14
    72fde4efff0b:	add    r13,0x4
    72fde4efff0f:	mov    QWORD PTR [r12+0x58],r13
    72fde4efff14:	mov    r15,r14
    72fde4efff17:	add    r15,0x4
    72fde4efff1b:	mov    eax,DWORD PTR [r15]
    72fde4efff1e:	mov    QWORD PTR [r12+0x70],rax
    72fde4efff23:	mov    r15,r14
    72fde4efff26:	add    r15,0x38
    72fde4efff2a:	mov    r8d,DWORD PTR [r15]
    72fde4efff2d:	mov    QWORD PTR [r12+0x78],r8
    72fde4efff32:	mov    r15,r14
    72fde4efff35:	add    r15,0x24
    72fde4efff39:	mov    r9d,DWORD PTR [r15]
    72fde4efff3c:	mov    QWORD PTR [r12+0x90],r9
    72fde4efff44:	sub    r13,0xc0
    72fde4efff4b:	setne  BYTE PTR [rsp+0xb8]
    72fde4efff53:	mov    r11,rax
    72fde4efff56:	lahf
    72fde4efff57:	seto   al
    72fde4efff5a:	mov    WORD PTR [rsp+0xb0],ax
    72fde4efff62:	mov    rax,r11
    72fde4efff65:	mov    r13d,DWORD PTR [r12+0x70]
    72fde4efff6a:	mov    r13d,r13d
    72fde4efff6d:	mov    r13d,r13d
    72fde4efff70:	ror    r13d,0x7
    72fde4efff74:	mov    QWORD PTR [r12+0x80],r13
    72fde4efff7c:	mov    r15d,r8d
    72fde4efff7f:	mov    r15d,r15d
    72fde4efff82:	ror    r15d,0x11
    72fde4efff86:	mov    QWORD PTR [r12+0x88],r15
    72fde4efff8e:	mov    ebp,DWORD PTR [r12+0x60]
    72fde4efff93:	add    r9d,ebp
    72fde4efff96:	mov    QWORD PTR [r12+0x60],r9
    72fde4efff9b:	mov    ebp,DWORD PTR [r12+0x70]
    72fde4efffa0:	mov    ebp,ebp
    72fde4efffa2:	mov    ebp,ebp
    72fde4efffa4:	ror    ebp,0x12
    72fde4efffa7:	xor    r13d,ebp
    72fde4efffaa:	mov    QWORD PTR [r12+0x80],r13
    72fde4efffb2:	mov    ebp,r8d
    72fde4efffb5:	mov    ebp,ebp
    72fde4efffb7:	ror    ebp,0x13
    72fde4efffba:	xor    r15d,ebp
    72fde4efffbd:	mov    QWORD PTR [r12+0x88],r15
    72fde4efffc5:	mov    ebp,DWORD PTR [r12+0x70]
    72fde4efffca:	mov    ebp,ebp
    72fde4efffcc:	mov    ebp,ebp
    72fde4efffce:	shr    ebp,0x3
    72fde4efffd1:	xor    r13d,ebp
    72fde4efffd4:	mov    QWORD PTR [r12+0x80],r13
    72fde4efffdc:	mov    r8d,r8d
    72fde4efffdf:	shr    r8d,0xa
    72fde4efffe3:	xor    r15d,r8d
    72fde4efffe6:	mov    QWORD PTR [r12+0x78],r15
    72fde4efffeb:	add    r9d,r13d
    72fde4efffee:	mov    QWORD PTR [r12+0x60],r9
    72fde4effff3:	add    r9d,r15d
    72fde4effff6:	mov    QWORD PTR [r12+0x60],r9
    72fde4effffb:	add    r14,0x40
    72fde4efffff:	mov    DWORD PTR [r14],r9d
    72fde4f00002:	mov    r13d,0x0
    72fde4f00008:	mov    DWORD PTR [r12+0x32c],r13d
    72fde4f00010:	mov    r13d,0x0
    72fde4f00016:	mov    ecx,DWORD PTR [r12+0x70]
    72fde4f0001b:	mov    ecx,ecx
    72fde4f0001d:	mov    r14d,r13d
    72fde4f00020:	or     r14d,ecx
    72fde4f00023:	mov    QWORD PTR [r12+0x60],r14
    72fde4f00028:	mov    rcx,QWORD PTR [r12+0x380]
    72fde4f00030:	jrcxz  0x72fde4f00037
    72fde4f00032:	jmp    0x72fde4f0081a
    72fde4f00037:	cmp    BYTE PTR [rsp+0xb8],0x0
    72fde4f0003f:	jne    0x72fde4effef9
    72fde4f00045:	jmp    0x72fde4f0004a
    72fde4f0004a:	mov    r13,QWORD PTR [r12]
    72fde4f0004e:	mov    r14,r13
    72fde4f00051:	add    r14,0x4
    72fde4f00055:	mov    r15d,DWORD PTR [r13+0x0]
    72fde4f00059:	mov    ebp,DWORD PTR [r14]
    72fde4f0005c:	mov    QWORD PTR [r12+0x78],r15
    72fde4f00061:	mov    QWORD PTR [r12+0x80],rbp
    72fde4f00069:	mov    r14,r13
    72fde4f0006c:	add    r14,0x8
    72fde4f00070:	mov    r8,r14
    72fde4f00073:	add    r8,0x4
    72fde4f00077:	mov    r9d,DWORD PTR [r14]
    72fde4f0007a:	mov    eax,DWORD PTR [r8]
    72fde4f0007d:	mov    QWORD PTR [rsp+0x90],rax
    72fde4f00085:	mov    QWORD PTR [r12+0x70],r9
    72fde4f0008a:	mov    rax,QWORD PTR [rsp+0x90]
    72fde4f00092:	mov    QWORD PTR [r12+0x68],rax
    72fde4f00097:	mov    r8,r13
    72fde4f0009a:	add    r8,0x18
    72fde4f0009e:	mov    r14,r8
    72fde4f000a1:	add    r14,0x4
    72fde4f000a5:	mov    eax,DWORD PTR [r8]
    72fde4f000a8:	mov    QWORD PTR [rsp+0x98],rax
    72fde4f000b0:	mov    r8d,DWORD PTR [r14]
    72fde4f000b3:	mov    rax,QWORD PTR [rsp+0x98]
    72fde4f000bb:	mov    QWORD PTR [r12+0x58],rax
    72fde4f000c0:	mov    QWORD PTR [r12+0x60],r8
    72fde4f000c5:	add    r13,0x10
    72fde4f000c9:	mov    r14,r13
    72fde4f000cc:	add    r14,0x4
    72fde4f000d0:	mov    eax,DWORD PTR [r13+0x0]
    72fde4f000d4:	mov    QWORD PTR [rsp+0xa0],rax
    72fde4f000dc:	mov    eax,DWORD PTR [r14]
    72fde4f000df:	mov    QWORD PTR [rsp+0xa8],rax
    72fde4f000e7:	mov    rax,QWORD PTR [rsp+0xa0]
    72fde4f000ef:	mov    QWORD PTR [r12+0x18],rax
    72fde4f000f4:	mov    rax,QWORD PTR [rsp+0xa8]
    72fde4f000fc:	mov    QWORD PTR [r12+0x90],rax
    72fde4f00104:	mov    r14d,0x0
    72fde4f0010a:	mov    QWORD PTR [r12+0x88],r14
    72fde4f00112:	mov    r14d,0x0
    72fde4f00118:	mov    r13d,r14d
    72fde4f0011b:	or     r13d,r15d
    72fde4f0011e:	mov    QWORD PTR [r12+0xa8],r13
    72fde4f00126:	mov    r13d,0x0
    72fde4f0012c:	mov    r14d,r13d
    72fde4f0012f:	or     r14d,ebp
    72fde4f00132:	mov    QWORD PTR [r12+0x38],r14
    72fde4f00137:	mov    r13d,0x0
    72fde4f0013d:	mov    r14d,r13d
    72fde4f00140:	or     r14d,r9d
    72fde4f00143:	mov    QWORD PTR [r12+0x98],r14
    72fde4f0014b:	mov    r13d,0x0
    72fde4f00151:	mov    ecx,DWORD PTR [rsp+0x90]
    72fde4f00158:	mov    r14d,r13d
    72fde4f0015b:	or     r14d,ecx
    72fde4f0015e:	mov    QWORD PTR [r12+0x28],r14
    72fde4f00163:	mov    r13d,0x0
    72fde4f00169:	mov    r14d,r13d
    72fde4f0016c:	or     r14d,r8d
    72fde4f0016f:	mov    QWORD PTR [r12+0xb0],r14
    72fde4f00177:	mov    r13d,0x0
    72fde4f0017d:	mov    ecx,DWORD PTR [rsp+0x98]
    72fde4f00184:	mov    r14d,r13d
    72fde4f00187:	or     r14d,ecx
    72fde4f0018a:	mov    QWORD PTR [r12+0xc0],r14
    72fde4f00192:	mov    r13d,0x0
    72fde4f00198:	mov    ecx,DWORD PTR [rsp+0xa8]
    72fde4f0019f:	mov    r14d,r13d
    72fde4f001a2:	or     r14d,ecx
    72fde4f001a5:	mov    QWORD PTR [r12+0xc8],r14
    72fde4f001ad:	mov    r13d,0x0
    72fde4f001b3:	mov    ecx,DWORD PTR [rsp+0xa0]
    72fde4f001ba:	mov    r14d,r13d
    72fde4f001bd:	or     r14d,ecx
    72fde4f001c0:	mov    QWORD PTR [r12+0xb8],r14
    72fde4f001c8:	jmp    0x72fde4f001cd
    72fde4f001cd:	mov    r13d,0x0
    72fde4f001d3:	mov    r14d,DWORD PTR [r12+0xb8]
    72fde4f001db:	mov    eax,r13d
    72fde4f001de:	or     eax,r14d
    72fde4f001e1:	mov    QWORD PTR [r12+0x30],rax
    72fde4f001e6:	mov    r13d,0x0
    72fde4f001ec:	mov    ebp,DWORD PTR [r12+0xc0]
    72fde4f001f4:	mov    eax,r13d
    72fde4f001f7:	or     eax,ebp
    72fde4f001f9:	mov    QWORD PTR [r12+0xa0],rax
    72fde4f00201:	mov    r13d,0x0
    72fde4f00207:	mov    ebp,DWORD PTR [r12+0x28]
    72fde4f0020c:	mov    eax,r13d
    72fde4f0020f:	or     eax,ebp
    72fde4f00211:	mov    QWORD PTR [r12+0xc0],rax
    72fde4f00219:	mov    r13d,0x0
    72fde4f0021f:	mov    ebp,DWORD PTR [r12+0x98]
    72fde4f00227:	mov    eax,r13d
    72fde4f0022a:	or     eax,ebp
    72fde4f0022c:	mov    QWORD PTR [r12+0x28],rax
    72fde4f00231:	mov    r13d,0x0
    72fde4f00237:	mov    ebp,DWORD PTR [r12+0x38]
    72fde4f0023c:	mov    eax,r13d
    72fde4f0023f:	or     eax,ebp
    72fde4f00241:	mov    QWORD PTR [r12+0x98],rax
    72fde4f00249:	mov    r13d,0x0
    72fde4f0024f:	mov    ebp,DWORD PTR [r12+0xa8]
    72fde4f00257:	mov    eax,r13d
    72fde4f0025a:	or     eax,ebp
    72fde4f0025c:	mov    QWORD PTR [r12+0x38],rax
    72fde4f00261:	mov    r14d,r14d
    72fde4f00264:	ror    r14d,0x6
    72fde4f00268:	mov    QWORD PTR [r12+0xb8],r14
    72fde4f00270:	mov    r13d,DWORD PTR [r12+0xc8]
    72fde4f00278:	mov    ebp,DWORD PTR [r12+0x30]
    72fde4f0027d:	mov    ebp,ebp
    72fde4f0027f:	and    ebp,r13d
    72fde4f00282:	mov    QWORD PTR [r12+0xa8],rbp
    72fde4f0028a:	mov    r9d,DWORD PTR [r12+0x38]
    72fde4f0028f:	mov    r9d,r9d
    72fde4f00292:	mov    r9d,r9d
    72fde4f00295:	ror    r9d,0x2
    72fde4f00299:	mov    QWORD PTR [r12+0xd0],r9
    72fde4f002a1:	mov    r15d,0x0
    72fde4f002a7:	mov    eax,r15d
    72fde4f002aa:	or     eax,r13d
    72fde4f002ad:	mov    QWORD PTR [r12+0x20],rax
    72fde4f002b2:	mov    rax,QWORD PTR [r12+0x88]
    72fde4f002ba:	mov    r15,QWORD PTR [r12+0x50]
    72fde4f002bf:	mov    rcx,QWORD PTR [r12+0x88]
    72fde4f002c7:	add    r15,rcx
    72fde4f002ca:	mov    r13d,DWORD PTR [r15]
    72fde4f002cd:	mov    QWORD PTR [r12+0xc8],r13
    72fde4f002d5:	mov    ecx,DWORD PTR [r12+0x30]
    72fde4f002da:	mov    ecx,ecx
    72fde4f002dc:	mov    r15d,DWORD PTR [r12+0xa0]
    72fde4f002e4:	mov    r15d,r15d
    72fde4f002e7:	not    rcx
    72fde4f002ea:	and    r15d,ecx
    72fde4f002ed:	mov    QWORD PTR [r12+0xd8],r15
    72fde4f002f5:	mov    r8d,DWORD PTR [r12+0xb0]
    72fde4f002fd:	add    ebp,r8d
    72fde4f00300:	mov    QWORD PTR [r12+0xa8],rbp
    72fde4f00308:	mov    r8d,DWORD PTR [r12+0x30]
    72fde4f0030d:	mov    r8d,r8d
    72fde4f00310:	mov    r8d,r8d
    72fde4f00313:	ror    r8d,0xb
    72fde4f00317:	xor    r14d,r8d
    72fde4f0031a:	mov    QWORD PTR [r12+0xb0],r14
    72fde4f00322:	mov    r8d,DWORD PTR [r12+0x38]
    72fde4f00327:	mov    r8d,r8d
    72fde4f0032a:	mov    r8d,r8d
    72fde4f0032d:	ror    r8d,0xd
    72fde4f00331:	xor    r9d,r8d
    72fde4f00334:	mov    QWORD PTR [r12+0xd0],r9
    72fde4f0033c:	add    ebp,r15d
    72fde4f0033f:	mov    QWORD PTR [r12+0xa8],rbp
    72fde4f00347:	mov    r15,QWORD PTR [r12+0x48]
    72fde4f0034c:	mov    rcx,QWORD PTR [r12+0x88]
    72fde4f00354:	add    r15,rcx
    72fde4f00357:	mov    r8d,DWORD PTR [r15]
    72fde4f0035a:	mov    QWORD PTR [r12+0xb8],r8
    72fde4f00362:	mov    ecx,DWORD PTR [r12+0x98]
    72fde4f0036a:	mov    ecx,ecx
    72fde4f0036c:	mov    eax,DWORD PTR [r12+0x28]
    72fde4f00371:	mov    eax,eax
    72fde4f00373:	and    eax,ecx
    72fde4f00375:	mov    QWORD PTR [r12+0xd8],rax
    72fde4f0037d:	add    ebp,r13d
    72fde4f00380:	mov    QWORD PTR [r12+0xa8],rbp
    72fde4f00388:	mov    ecx,DWORD PTR [r12+0x98]
    72fde4f00390:	mov    ecx,ecx
    72fde4f00392:	mov    r13d,DWORD PTR [r12+0x28]
    72fde4f00397:	mov    r13d,r13d
    72fde4f0039a:	xor    r13d,ecx
    72fde4f0039d:	mov    QWORD PTR [r12+0xc8],r13
    72fde4f003a5:	mov    r15d,DWORD PTR [r12+0x30]
    72fde4f003aa:	mov    r15d,r15d
    72fde4f003ad:	mov    r15d,r15d
    72fde4f003b0:	ror    r15d,0x19
    72fde4f003b4:	xor    r14d,r15d
    72fde4f003b7:	mov    QWORD PTR [r12+0xb0],r14
    72fde4f003bf:	mov    ecx,DWORD PTR [r12+0x38]
    72fde4f003c4:	mov    ecx,ecx
    72fde4f003c6:	and    r13d,ecx
    72fde4f003c9:	mov    QWORD PTR [r12+0xc8],r13
    72fde4f003d1:	mov    r15d,DWORD PTR [r12+0x38]
    72fde4f003d6:	mov    r15d,r15d
    72fde4f003d9:	mov    r15d,r15d
    72fde4f003dc:	ror    r15d,0x16
    72fde4f003e0:	xor    r9d,r15d
    72fde4f003e3:	mov    QWORD PTR [r12+0xd0],r9
    72fde4f003eb:	add    ebp,r8d
    72fde4f003ee:	mov    QWORD PTR [r12+0xa8],rbp
    72fde4f003f6:	mov    ecx,DWORD PTR [r12+0xd8]
    72fde4f003fe:	mov    ecx,ecx
    72fde4f00400:	xor    r13d,ecx
    72fde4f00403:	mov    QWORD PTR [r12+0xb8],r13
    72fde4f0040b:	add    ebp,r14d
    72fde4f0040e:	mov    QWORD PTR [r12+0xa8],rbp
    72fde4f00416:	mov    r14,QWORD PTR [r12+0x88]
    72fde4f0041e:	add    r14,0x4
    72fde4f00422:	mov    QWORD PTR [r12+0x88],r14
    72fde4f0042a:	add    r13d,r9d
    72fde4f0042d:	mov    QWORD PTR [r12+0xb0],r13
    72fde4f00435:	mov    ecx,DWORD PTR [r12+0xc0]
    72fde4f0043d:	mov    ecx,ecx
    72fde4f0043f:	mov    r15d,ebp
    72fde4f00442:	add    r15d,ecx
    72fde4f00445:	mov    QWORD PTR [r12+0xb8],r15
    72fde4f0044d:	sub    r14,0x100
    72fde4f00454:	setne  BYTE PTR [rsp+0xb8]
    72fde4f0045c:	mov    r11,rax
    72fde4f0045f:	lahf
    72fde4f00460:	seto   al
    72fde4f00463:	mov    WORD PTR [rsp+0xb0],ax
    72fde4f0046b:	mov    rax,r11
    72fde4f0046e:	add    r13d,ebp
    72fde4f00471:	mov    QWORD PTR [r12+0xa8],r13
    72fde4f00479:	mov    r13d,0x0
    72fde4f0047f:	mov    ecx,DWORD PTR [r12+0xa0]
    72fde4f00487:	mov    ecx,ecx
    72fde4f00489:	mov    r14d,r13d
    72fde4f0048c:	or     r14d,ecx
    72fde4f0048f:	mov    QWORD PTR [r12+0xb0],r14
    72fde4f00497:	mov    r13d,0x0
    72fde4f0049d:	mov    ecx,DWORD PTR [r12+0x20]
    72fde4f004a2:	mov    ecx,ecx
    72fde4f004a4:	mov    r14d,r13d
    72fde4f004a7:	or     r14d,ecx
    72fde4f004aa:	mov    QWORD PTR [r12+0xc0],r14
    72fde4f004b2:	mov    r13d,0x0
    72fde4f004b8:	mov    ecx,DWORD PTR [r12+0x30]
    72fde4f004bd:	mov    ecx,ecx
    72fde4f004bf:	mov    r14d,r13d
    72fde4f004c2:	or     r14d,ecx
    72fde4f004c5:	mov    QWORD PTR [r12+0xc8],r14
    72fde4f004cd:	mov    rcx,QWORD PTR [r12+0x380]
    72fde4f004d5:	jrcxz  0x72fde4f004dc
    72fde4f004d7:	jmp    0x72fde4f008a2
    72fde4f004dc:	cmp    BYTE PTR [rsp+0xb8],0x0
    72fde4f004e4:	jne    0x72fde4f001cd
    72fde4f004ea:	jmp    0x72fde4f004ef
    72fde4f004ef:	mov    r13d,DWORD PTR [r12+0x70]
    72fde4f004f4:	mov    r14d,DWORD PTR [r12+0x98]
    72fde4f004fc:	add    r14d,r13d
    72fde4f004ff:	mov    QWORD PTR [r12+0x70],r14
    72fde4f00504:	mov    r13d,DWORD PTR [r12+0x68]
    72fde4f00509:	mov    r15d,DWORD PTR [r12+0x28]
    72fde4f0050e:	add    r15d,r13d
    72fde4f00511:	mov    QWORD PTR [r12+0x68],r15
    72fde4f00516:	mov    r13d,0x0
    72fde4f0051c:	mov    QWORD PTR [r12+0x88],r13
    72fde4f00524:	mov    r13d,DWORD PTR [r12+0x78]
    72fde4f00529:	mov    ebp,DWORD PTR [r12+0xa8]
    72fde4f00531:	add    ebp,r13d
    72fde4f00534:	mov    QWORD PTR [r12+0x78],rbp
    72fde4f00539:	mov    r13d,DWORD PTR [r12+0x80]
    72fde4f00541:	mov    r8d,DWORD PTR [r12+0x38]
    72fde4f00546:	add    r8d,r13d
    72fde4f00549:	mov    QWORD PTR [r12+0x80],r8
    72fde4f00551:	mov    rax,QWORD PTR [r12]
    72fde4f00555:	mov    r9,QWORD PTR [r12]
    72fde4f00559:	add    r9,0x8
    72fde4f0055d:	mov    r13,r9
    72fde4f00560:	add    r13,0x4
    72fde4f00564:	mov    DWORD PTR [r9],r14d
    72fde4f00567:	mov    r14d,0x0
    72fde4f0056d:	mov    DWORD PTR [r12+0x32c],r14d
    72fde4f00575:	mov    DWORD PTR [r13+0x0],r15d
    72fde4f00579:	mov    r13d,DWORD PTR [r12+0x18]
    72fde4f0057e:	mov    r14d,DWORD PTR [r12+0xb8]
    72fde4f00586:	add    r14d,r13d
    72fde4f00589:	mov    QWORD PTR [r12+0x68],r14
    72fde4f0058e:	mov    r13d,DWORD PTR [r12+0x90]
    72fde4f00596:	mov    r15d,DWORD PTR [r12+0x30]
    72fde4f0059b:	add    r15d,r13d
    72fde4f0059e:	mov    QWORD PTR [r12+0x70],r15
    72fde4f005a3:	mov    r13d,DWORD PTR [r12+0x58]
    72fde4f005a8:	mov    r9d,DWORD PTR [r12+0x20]
    72fde4f005ad:	mov    eax,r9d
    72fde4f005b0:	add    eax,r13d
    72fde4f005b3:	mov    QWORD PTR [r12+0x58],rax
    72fde4f005b8:	mov    r13d,DWORD PTR [r12+0x60]
    72fde4f005bd:	mov    r9d,DWORD PTR [r12+0xa0]
    72fde4f005c5:	add    r9d,r13d
    72fde4f005c8:	mov    QWORD PTR [r12+0x60],r9
    72fde4f005cd:	mov    r13,QWORD PTR [r12]
    72fde4f005d1:	add    r13,0x4
    72fde4f005d5:	mov    rdi,QWORD PTR [r12]
    72fde4f005d9:	mov    DWORD PTR [rdi],ebp
    72fde4f005db:	mov    DWORD PTR [r13+0x0],r8d
    72fde4f005df:	mov    r13,QWORD PTR [r12]
    72fde4f005e3:	add    r13,0x10
    72fde4f005e7:	mov    rbp,r13
    72fde4f005ea:	add    rbp,0x4
    72fde4f005ee:	mov    DWORD PTR [r13+0x0],r14d
    72fde4f005f2:	mov    DWORD PTR [rbp+0x0],r15d
    72fde4f005f6:	mov    r13,QWORD PTR [r12]
    72fde4f005fa:	add    r13,0x18
    72fde4f005fe:	mov    r14,r13
    72fde4f00601:	add    r14,0x4
    72fde4f00605:	mov    eax,DWORD PTR [r12+0x58]
    72fde4f0060a:	mov    DWORD PTR [r13+0x0],eax
    72fde4f0060e:	mov    DWORD PTR [r14],r9d
    72fde4f00611:	mov    r13,QWORD PTR [r12]
    72fde4f00615:	add    r13,0x68
    72fde4f00619:	mov    r14d,0x0
    72fde4f0061f:	mov    QWORD PTR [r13+0x0],r14
    72fde4f00623:	mov    rcx,QWORD PTR [r12+0x380]
    72fde4f0062b:	jrcxz  0x72fde4f00632
    72fde4f0062d:	jmp    0x72fde4f0092a
    72fde4f00632:	jmp    0x72fde4f00637
    72fde4f00637:	mov    r13,QWORD PTR [r12+0x10]
    72fde4f0063c:	sub    r13,0x1
    72fde4f00640:	mov    QWORD PTR [r12+0x10],r13
    72fde4f00645:	mov    rax,r13
    72fde4f00648:	test   rax,rax
    72fde4f0064b:	je     0x72fde4f00656
    72fde4f00651:	jmp    0x72fde4efe75a
    72fde4f00656:	mov    r13,QWORD PTR [r12+0xf8]
    72fde4f0065e:	mov    r14,r13
    72fde4f00661:	add    r14,0x140
    72fde4f00668:	mov    r15,r14
    72fde4f0066b:	add    r15,0x8
    72fde4f0066f:	mov    rbp,QWORD PTR [r14]
    72fde4f00672:	mov    r14,QWORD PTR [r15]
    72fde4f00675:	mov    QWORD PTR [r12+0xa0],rbp
    72fde4f0067d:	mov    QWORD PTR [r12+0x98],r14
    72fde4f00685:	mov    r14,r13
    72fde4f00688:	add    r14,0x130
    72fde4f0068f:	mov    r15,r14
    72fde4f00692:	add    r15,0x8
    72fde4f00696:	mov    rbp,QWORD PTR [r14]
    72fde4f00699:	mov    r14,QWORD PTR [r15]
    72fde4f0069c:	mov    QWORD PTR [r12+0xb0],rbp
    72fde4f006a4:	mov    QWORD PTR [r12+0xa8],r14
    72fde4f006ac:	mov    r14,r13
    72fde4f006af:	add    r14,0x120
    72fde4f006b6:	mov    r15,r14
    72fde4f006b9:	add    r15,0x8
    72fde4f006bd:	mov    rbp,QWORD PTR [r14]
    72fde4f006c0:	mov    r14,QWORD PTR [r15]
    72fde4f006c3:	mov    QWORD PTR [r12+0xc0],rbp
    72fde4f006cb:	mov    QWORD PTR [r12+0xb8],r14
    72fde4f006d3:	mov    r14,r13
    72fde4f006d6:	add    r14,0x110
    72fde4f006dd:	mov    r15,r14
    72fde4f006e0:	add    r15,0x8
    72fde4f006e4:	mov    rbp,QWORD PTR [r14]
    72fde4f006e7:	mov    r14,QWORD PTR [r15]
    72fde4f006ea:	mov    QWORD PTR [r12+0xd0],rbp
    72fde4f006f2:	mov    QWORD PTR [r12+0xc8],r14
    72fde4f006fa:	mov    r14,r13
    72fde4f006fd:	add    r14,0x100
    72fde4f00704:	mov    r15,r14
    72fde4f00707:	add    r15,0x8
    72fde4f0070b:	mov    rbp,QWORD PTR [r14]
    72fde4f0070e:	mov    r14,QWORD PTR [r15]
    72fde4f00711:	mov    QWORD PTR [r12+0xe8],rbp
    72fde4f00719:	mov    QWORD PTR [r12+0xd8],r14
    72fde4f00721:	add    r13,0x150
    72fde4f00728:	mov    QWORD PTR [r12+0xf8],r13
    72fde4f00730:	jmp    0x72fde4f00735
    72fde4f00735:	mov    rcx,QWORD PTR [r12+0x380]
    72fde4f0073d:	jrcxz  0x72fde4f00744
    72fde4f0073f:	jmp    0x72fde4f009b2
    72fde4f00744:	mov    r13,QWORD PTR [r12+0xf0]
    72fde4f0074c:	mov    QWORD PTR [r12+0x100],r13
    72fde4f00754:	mov    r11,QWORD PTR [rsp+0xb0]
    72fde4f0075c:	mov    QWORD PTR [r12+0x398],r11
    72fde4f00764:	mov    rdi,QWORD PTR [r12+0x100]
    72fde4f0076c:	add    rsp,0xc0
    72fde4f00773:	movabs r11,0x5ccd9ef50940
    72fde4f0077d:	jmp    r11
    72fde4f00780:	mov    eax,0x410720
    72fde4f00785:	mov    QWORD PTR [r12+0x100],rax
    72fde4f0078d:	push   rdx
    72fde4f0078e:	push   rsi
    72fde4f0078f:	push   r10
    72fde4f00791:	push   r11
    72fde4f00793:	mov    r11,rax
    72fde4f00796:	lahf
    72fde4f00797:	seto   al
    72fde4f0079a:	mov    WORD PTR [rsp+0xd0],ax
    72fde4f007a2:	mov    rax,r11
    72fde4f007a5:	mov    rdx,QWORD PTR [rsp+0xd0]
    72fde4f007ad:	mov    r10d,edx
    72fde4f007b0:	and    r10d,0xc000
    72fde4f007b7:	shl    r10d,0x10
    72fde4f007bb:	mov    r11d,edx
    72fde4f007be:	and    r11d,0x100
    72fde4f007c5:	shl    r11d,0x15
    72fde4f007c9:	or     r10d,r11d
    72fde4f007cc:	and    edx,0x1
    72fde4f007cf:	shl    edx,0x1c
    72fde4f007d2:	or     r10d,edx
    72fde4f007d5:	btc    r10,0x1d
    72fde4f007da:	mov    r11d,0xf0000000
    72fde4f007e0:	and    r11,r10
    72fde4f007e3:	movabs rsi,0xffffffff0fffffff
    72fde4f007ed:	and    rbx,rsi
    72fde4f007f0:	or     rbx,r11
    72fde4f007f3:	pop    r11
    72fde4f007f5:	pop    r10
    72fde4f007f7:	pop    rsi
    72fde4f007f8:	pop    rdx
    72fde4f007f9:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f00801:	add    rsp,0xc0
    72fde4f00808:	mov    eax,0xc
    72fde4f0080d:	movabs r11,0x5ccd9ef50ca0
    72fde4f00817:	jmp    r11
    72fde4f0081a:	mov    eax,0x41081c
    72fde4f0081f:	mov    QWORD PTR [r12+0x100],rax
    72fde4f00827:	push   rdx
    72fde4f00828:	push   rsi
    72fde4f00829:	push   r10
    72fde4f0082b:	push   r11
    72fde4f0082d:	mov    rdx,QWORD PTR [rsp+0xd0]
    72fde4f00835:	mov    r10d,edx
    72fde4f00838:	and    r10d,0xc000
    72fde4f0083f:	shl    r10d,0x10
    72fde4f00843:	mov    r11d,edx
    72fde4f00846:	and    r11d,0x100
    72fde4f0084d:	shl    r11d,0x15
    72fde4f00851:	or     r10d,r11d
    72fde4f00854:	and    edx,0x1
    72fde4f00857:	shl    edx,0x1c
    72fde4f0085a:	or     r10d,edx
    72fde4f0085d:	btc    r10,0x1d
    72fde4f00862:	mov    r11d,0xf0000000
    72fde4f00868:	and    r11,r10
    72fde4f0086b:	movabs rsi,0xffffffff0fffffff
    72fde4f00875:	and    rbx,rsi
    72fde4f00878:	or     rbx,r11
    72fde4f0087b:	pop    r11
    72fde4f0087d:	pop    r10
    72fde4f0087f:	pop    rsi
    72fde4f00880:	pop    rdx
    72fde4f00881:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f00889:	add    rsp,0xc0
    72fde4f00890:	mov    eax,0xc
    72fde4f00895:	movabs r11,0x5ccd9ef50ca0
    72fde4f0089f:	jmp    r11
    72fde4f008a2:	mov    eax,0x4108dc
    72fde4f008a7:	mov    QWORD PTR [r12+0x100],rax
    72fde4f008af:	push   rdx
    72fde4f008b0:	push   rsi
    72fde4f008b1:	push   r10
    72fde4f008b3:	push   r11
    72fde4f008b5:	mov    rdx,QWORD PTR [rsp+0xd0]
    72fde4f008bd:	mov    r10d,edx
    72fde4f008c0:	and    r10d,0xc000
    72fde4f008c7:	shl    r10d,0x10
    72fde4f008cb:	mov    r11d,edx
    72fde4f008ce:	and    r11d,0x100
    72fde4f008d5:	shl    r11d,0x15
    72fde4f008d9:	or     r10d,r11d
    72fde4f008dc:	and    edx,0x1
    72fde4f008df:	shl    edx,0x1c
    72fde4f008e2:	or     r10d,edx
    72fde4f008e5:	btc    r10,0x1d
    72fde4f008ea:	mov    r11d,0xf0000000
    72fde4f008f0:	and    r11,r10
    72fde4f008f3:	movabs rsi,0xffffffff0fffffff
    72fde4f008fd:	and    rbx,rsi
    72fde4f00900:	or     rbx,r11
    72fde4f00903:	pop    r11
    72fde4f00905:	pop    r10
    72fde4f00907:	pop    rsi
    72fde4f00908:	pop    rdx
    72fde4f00909:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f00911:	add    rsp,0xc0
    72fde4f00918:	mov    eax,0xc
    72fde4f0091d:	movabs r11,0x5ccd9ef50ca0
    72fde4f00927:	jmp    r11
    72fde4f0092a:	mov    eax,0x410918
    72fde4f0092f:	mov    QWORD PTR [r12+0x100],rax
    72fde4f00937:	push   rdx
    72fde4f00938:	push   rsi
    72fde4f00939:	push   r10
    72fde4f0093b:	push   r11
    72fde4f0093d:	mov    rdx,QWORD PTR [rsp+0xd0]
    72fde4f00945:	mov    r10d,edx
    72fde4f00948:	and    r10d,0xc000
    72fde4f0094f:	shl    r10d,0x10
    72fde4f00953:	mov    r11d,edx
    72fde4f00956:	and    r11d,0x100
    72fde4f0095d:	shl    r11d,0x15
    72fde4f00961:	or     r10d,r11d
    72fde4f00964:	and    edx,0x1
    72fde4f00967:	shl    edx,0x1c
    72fde4f0096a:	or     r10d,edx
    72fde4f0096d:	btc    r10,0x1d
    72fde4f00972:	mov    r11d,0xf0000000
    72fde4f00978:	and    r11,r10
    72fde4f0097b:	movabs rsi,0xffffffff0fffffff
    72fde4f00985:	and    rbx,rsi
    72fde4f00988:	or     rbx,r11
    72fde4f0098b:	pop    r11
    72fde4f0098d:	pop    r10
    72fde4f0098f:	pop    rsi
    72fde4f00990:	pop    rdx
    72fde4f00991:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f00999:	add    rsp,0xc0
    72fde4f009a0:	mov    eax,0xc
    72fde4f009a5:	movabs r11,0x5ccd9ef50ca0
    72fde4f009af:	jmp    r11
    72fde4f009b2:	mov    eax,0x410934
    72fde4f009b7:	mov    QWORD PTR [r12+0x100],rax
    72fde4f009bf:	push   rdx
    72fde4f009c0:	push   rsi
    72fde4f009c1:	push   r10
    72fde4f009c3:	push   r11
    72fde4f009c5:	mov    rdx,QWORD PTR [rsp+0xd0]
    72fde4f009cd:	mov    r10d,edx
    72fde4f009d0:	and    r10d,0xc000
    72fde4f009d7:	shl    r10d,0x10
    72fde4f009db:	mov    r11d,edx
    72fde4f009de:	and    r11d,0x100
    72fde4f009e5:	shl    r11d,0x15
    72fde4f009e9:	or     r10d,r11d
    72fde4f009ec:	and    edx,0x1
    72fde4f009ef:	shl    edx,0x1c
    72fde4f009f2:	or     r10d,edx
    72fde4f009f5:	btc    r10,0x1d
    72fde4f009fa:	mov    r11d,0xf0000000
    72fde4f00a00:	and    r11,r10
    72fde4f00a03:	movabs rsi,0xffffffff0fffffff
    72fde4f00a0d:	and    rbx,rsi
    72fde4f00a10:	or     rbx,r11
    72fde4f00a13:	pop    r11
    72fde4f00a15:	pop    r10
    72fde4f00a17:	pop    rsi
    72fde4f00a18:	pop    rdx
    72fde4f00a19:	mov    QWORD PTR [r12+0x108],rbx
    72fde4f00a21:	add    rsp,0xc0
    72fde4f00a28:	mov    eax,0xc
    72fde4f00a2d:	movabs r11,0x5ccd9ef50ca0
    72fde4f00a37:	jmp    r11
    72fde4f00a3a:	nop    WORD PTR [rax+rax*1+0x0]
    72fde4f00a40:	sub    rsp,0xc0
    72fde4f00a47:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f00a4f:	mov    QWORD PTR [rsp+0xb0],r11
    72fde4f00a57:	jmp    0x72fde4efe639
    72fde4f00a5c:	nop    DWORD PTR [rax+0x0]
    72fde4f00a60:	sub    rsp,0xc0
    72fde4f00a67:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f00a6f:	mov    QWORD PTR [rsp+0xb0],r11
    72fde4f00a77:	jmp    0x72fde4efe75a
    72fde4f00a7c:	nop    DWORD PTR [rax+0x0]
    72fde4f00a80:	sub    rsp,0xc0
    72fde4f00a87:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f00a8f:	mov    QWORD PTR [rsp+0xb0],r11
    72fde4f00a97:	jmp    0x72fde4efe814
    72fde4f00a9c:	nop    DWORD PTR [rax+0x0]
    72fde4f00aa0:	sub    rsp,0xc0
    72fde4f00aa7:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f00aaf:	mov    QWORD PTR [rsp+0xb0],r11
    72fde4f00ab7:	jmp    0x72fde4effef9
    72fde4f00abc:	nop    DWORD PTR [rax+0x0]
    72fde4f00ac0:	sub    rsp,0xc0
    72fde4f00ac7:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f00acf:	mov    QWORD PTR [rsp+0xb0],r11
    72fde4f00ad7:	jmp    0x72fde4f0004a
    72fde4f00adc:	nop    DWORD PTR [rax+0x0]
    72fde4f00ae0:	sub    rsp,0xc0
    72fde4f00ae7:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f00aef:	mov    QWORD PTR [rsp+0xb0],r11
    72fde4f00af7:	jmp    0x72fde4f001cd
    72fde4f00afc:	nop    DWORD PTR [rax+0x0]
    72fde4f00b00:	sub    rsp,0xc0
    72fde4f00b07:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f00b0f:	mov    QWORD PTR [rsp+0xb0],r11
    72fde4f00b17:	jmp    0x72fde4f004ef
    72fde4f00b1c:	nop    DWORD PTR [rax+0x0]
    72fde4f00b20:	sub    rsp,0xc0
    72fde4f00b27:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f00b2f:	mov    QWORD PTR [rsp+0xb0],r11
    72fde4f00b37:	jmp    0x72fde4f00637
    72fde4f00b3c:	nop    DWORD PTR [rax+0x0]
    72fde4f00b40:	sub    rsp,0xc0
    72fde4f00b47:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f00b4f:	mov    QWORD PTR [rsp+0xb0],r11
    72fde4f00b57:	jmp    0x72fde4f00656
    72fde4f00b5c:	nop    DWORD PTR [rax+0x0]
    72fde4f00b60:	sub    rsp,0xc0
    72fde4f00b67:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f00b6f:	mov    QWORD PTR [rsp+0xb0],r11
    72fde4f00b77:	jmp    0x72fde4f00735
