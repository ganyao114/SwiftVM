
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/2/1.bin:     file format binary


Disassembly of section .data:

00007db2f94fe5e0 <.data>:
    7db2f94fe5e0:	sub    rsp,0xc0
    7db2f94fe5e7:	mov    r11,QWORD PTR [r12+0x398]
    7db2f94fe5ef:	mov    QWORD PTR [rsp+0xb0],r11
    7db2f94fe5f7:	mov    r13,QWORD PTR [r12]
    7db2f94fe5fb:	mov    r14,r13
    7db2f94fe5fe:	add    r14,0x20
    7db2f94fe602:	mov    r15,QWORD PTR [r14]
    7db2f94fe605:	mov    r14,QWORD PTR [r12+0x10]
    7db2f94fe60a:	add    r15,r14
    7db2f94fe60d:	mov    QWORD PTR [r12+0x40],r15
    7db2f94fe612:	add    r13,0x20
    7db2f94fe616:	mov    QWORD PTR [r13+0x0],r15
    7db2f94fe61a:	mov    r13d,0x0
    7db2f94fe620:	mov    DWORD PTR [r12+0x32c],r13d
    7db2f94fe628:	mov    rax,r14
    7db2f94fe62b:	test   rax,rax
    7db2f94fe62e:	je     0x7db2f9500735
    7db2f94fe634:	jmp    0x7db2f94fe639
    7db2f94fe639:	mov    r13,QWORD PTR [r12+0xf8]
    7db2f94fe641:	sub    r13,0x150
    7db2f94fe648:	mov    QWORD PTR [r12+0xf8],r13
    7db2f94fe650:	mov    r14,QWORD PTR [r12]
    7db2f94fe654:	mov    r15,r14
    7db2f94fe657:	add    r15,0x68
    7db2f94fe65b:	mov    rbp,QWORD PTR [r15]
    7db2f94fe65e:	mov    QWORD PTR [r12+0x88],rbp
    7db2f94fe666:	add    r14,0x28
    7db2f94fe66a:	mov    QWORD PTR [r12+0x40],r14
    7db2f94fe66f:	mov    QWORD PTR [r12+0x48],r13
    7db2f94fe674:	mov    r14d,0x420000
    7db2f94fe67a:	add    r14,0xb20
    7db2f94fe681:	mov    QWORD PTR [r12+0x50],r14
    7db2f94fe686:	mov    r14,r13
    7db2f94fe689:	add    r14,0x100
    7db2f94fe690:	mov    r15,r14
    7db2f94fe693:	add    r15,0x8
    7db2f94fe697:	mov    rbp,QWORD PTR [r12+0xe8]
    7db2f94fe69f:	mov    r8,QWORD PTR [r12+0xd8]
    7db2f94fe6a7:	mov    QWORD PTR [r14],rbp
    7db2f94fe6aa:	mov    r14d,0x0
    7db2f94fe6b0:	mov    DWORD PTR [r12+0x32c],r14d
    7db2f94fe6b8:	mov    QWORD PTR [r15],r8
    7db2f94fe6bb:	mov    r14,r13
    7db2f94fe6be:	add    r14,0x110
    7db2f94fe6c5:	mov    r15,r14
    7db2f94fe6c8:	add    r15,0x8
    7db2f94fe6cc:	mov    rbp,QWORD PTR [r12+0xd0]
    7db2f94fe6d4:	mov    r8,QWORD PTR [r12+0xc8]
    7db2f94fe6dc:	mov    QWORD PTR [r14],rbp
    7db2f94fe6df:	mov    QWORD PTR [r15],r8
    7db2f94fe6e2:	mov    r14,r13
    7db2f94fe6e5:	add    r14,0x120
    7db2f94fe6ec:	mov    r15,r14
    7db2f94fe6ef:	add    r15,0x8
    7db2f94fe6f3:	mov    rbp,QWORD PTR [r12+0xc0]
    7db2f94fe6fb:	mov    r8,QWORD PTR [r12+0xb8]
    7db2f94fe703:	mov    QWORD PTR [r14],rbp
    7db2f94fe706:	mov    QWORD PTR [r15],r8
    7db2f94fe709:	mov    r14,r13
    7db2f94fe70c:	add    r14,0x130
    7db2f94fe713:	mov    r15,r14
    7db2f94fe716:	add    r15,0x8
    7db2f94fe71a:	mov    rbp,QWORD PTR [r12+0xb0]
    7db2f94fe722:	mov    r8,QWORD PTR [r12+0xa8]
    7db2f94fe72a:	mov    QWORD PTR [r14],rbp
    7db2f94fe72d:	mov    QWORD PTR [r15],r8
    7db2f94fe730:	add    r13,0x140
    7db2f94fe737:	mov    r14,r13
    7db2f94fe73a:	add    r14,0x8
    7db2f94fe73e:	mov    r15,QWORD PTR [r12+0xa0]
    7db2f94fe746:	mov    rbp,QWORD PTR [r12+0x98]
    7db2f94fe74e:	mov    QWORD PTR [r13+0x0],r15
    7db2f94fe752:	mov    QWORD PTR [r14],rbp
    7db2f94fe755:	jmp    0x7db2f94fe75a
    7db2f94fe75a:	mov    r13,QWORD PTR [r12+0x8]
    7db2f94fe75f:	mov    r14,r13
    7db2f94fe762:	add    r14,0x1
    7db2f94fe766:	movzx  r15d,BYTE PTR [r13+0x0]
    7db2f94fe76b:	mov    QWORD PTR [r12+0x58],r15
    7db2f94fe770:	mov    QWORD PTR [r12+0x8],r14
    7db2f94fe775:	mov    r13,QWORD PTR [r12+0x88]
    7db2f94fe77d:	mov    r14,r13
    7db2f94fe780:	add    r14,0x1
    7db2f94fe784:	mov    QWORD PTR [r12+0x60],r14
    7db2f94fe789:	mov    r15,QWORD PTR [r12]
    7db2f94fe78d:	mov    rbp,r15
    7db2f94fe790:	add    rbp,0x68
    7db2f94fe794:	mov    QWORD PTR [rbp+0x0],r14
    7db2f94fe798:	mov    r14d,0x0
    7db2f94fe79e:	mov    DWORD PTR [r12+0x32c],r14d
    7db2f94fe7a6:	mov    r14,r15
    7db2f94fe7a9:	add    r14,r13
    7db2f94fe7ac:	mov    QWORD PTR [r12+0x60],r14
    7db2f94fe7b1:	add    r14,0x28
    7db2f94fe7b5:	movzx  r13d,BYTE PTR [r12+0x58]
    7db2f94fe7bb:	mov    BYTE PTR [r14],r13b
    7db2f94fe7be:	add    r15,0x68
    7db2f94fe7c2:	mov    r13,QWORD PTR [r15]
    7db2f94fe7c5:	mov    QWORD PTR [r12+0x88],r13
    7db2f94fe7cd:	sub    r13,0x40
    7db2f94fe7d1:	mov    rcx,QWORD PTR [r12+0x380]
    7db2f94fe7d9:	jrcxz  0x7db2f94fe7e0
    7db2f94fe7db:	jmp    0x7db2f9500780
    7db2f94fe7e0:	jne    0x7db2f94fe7fd
    7db2f94fe7e6:	mov    r11,rax
    7db2f94fe7e9:	lahf
    7db2f94fe7ea:	seto   al
    7db2f94fe7ed:	mov    WORD PTR [rsp+0xb0],ax
    7db2f94fe7f5:	mov    rax,r11
    7db2f94fe7f8:	jmp    0x7db2f94fe814
    7db2f94fe7fd:	mov    r11,rax
    7db2f94fe800:	lahf
    7db2f94fe801:	seto   al
    7db2f94fe804:	mov    WORD PTR [rsp+0xb0],ax
    7db2f94fe80c:	mov    rax,r11
    7db2f94fe80f:	jmp    0x7db2f9500637
    7db2f94fe814:	mov    rax,QWORD PTR [r12+0x40]
    7db2f94fe819:	mov    eax,0x0
    7db2f94fe81e:	mov    QWORD PTR [rsp+0x18],rax
    7db2f94fe823:	mov    eax,0x0
    7db2f94fe828:	mov    QWORD PTR [rsp+0x10],rax
    7db2f94fe82d:	mov    eax,0x0
    7db2f94fe832:	mov    QWORD PTR [rsp+0x8],rax
    7db2f94fe837:	mov    eax,0x0
    7db2f94fe83c:	mov    QWORD PTR [rsp],rax
    7db2f94fe840:	mov    rdi,QWORD PTR [r12+0x40]
    7db2f94fe845:	movzx  r9d,BYTE PTR [rdi]
    7db2f94fe849:	mov    r13,QWORD PTR [rsp+0x18]
    7db2f94fe84e:	or     r13,r9
    7db2f94fe851:	mov    r9,QWORD PTR [r12+0x40]
    7db2f94fe856:	add    r9,0x1
    7db2f94fe85a:	movzx  r8d,BYTE PTR [r9]
    7db2f94fe85e:	mov    r9,QWORD PTR [rsp+0x10]
    7db2f94fe863:	or     r9,r8
    7db2f94fe866:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94fe86b:	add    r8,0x2
    7db2f94fe86f:	movzx  ebp,BYTE PTR [r8]
    7db2f94fe873:	mov    r8,QWORD PTR [rsp+0x8]
    7db2f94fe878:	or     r8,rbp
    7db2f94fe87b:	mov    rbp,QWORD PTR [r12+0x40]
    7db2f94fe880:	add    rbp,0x3
    7db2f94fe884:	movzx  r15d,BYTE PTR [rbp+0x0]
    7db2f94fe889:	mov    rbp,QWORD PTR [rsp]
    7db2f94fe88d:	or     rbp,r15
    7db2f94fe890:	mov    r15,QWORD PTR [r12+0x40]
    7db2f94fe895:	add    r15,0x4
    7db2f94fe899:	movzx  r14d,BYTE PTR [r15]
    7db2f94fe89d:	mov    r15,r14
    7db2f94fe8a0:	shl    r15,0x8
    7db2f94fe8a4:	or     r13,r15
    7db2f94fe8a7:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94fe8ac:	add    r14,0x5
    7db2f94fe8b0:	movzx  r15d,BYTE PTR [r14]
    7db2f94fe8b4:	mov    r14,r15
    7db2f94fe8b7:	shl    r14,0x8
    7db2f94fe8bb:	or     r9,r14
    7db2f94fe8be:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94fe8c3:	add    r14,0x6
    7db2f94fe8c7:	movzx  r15d,BYTE PTR [r14]
    7db2f94fe8cb:	mov    r14,r15
    7db2f94fe8ce:	shl    r14,0x8
    7db2f94fe8d2:	or     r8,r14
    7db2f94fe8d5:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94fe8da:	add    r14,0x7
    7db2f94fe8de:	movzx  r15d,BYTE PTR [r14]
    7db2f94fe8e2:	mov    r14,r15
    7db2f94fe8e5:	shl    r14,0x8
    7db2f94fe8e9:	or     rbp,r14
    7db2f94fe8ec:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94fe8f1:	add    r14,0x8
    7db2f94fe8f5:	movzx  r15d,BYTE PTR [r14]
    7db2f94fe8f9:	mov    r14,r15
    7db2f94fe8fc:	shl    r14,0x10
    7db2f94fe900:	or     r13,r14
    7db2f94fe903:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94fe908:	add    r14,0x9
    7db2f94fe90c:	movzx  r15d,BYTE PTR [r14]
    7db2f94fe910:	mov    r14,r15
    7db2f94fe913:	shl    r14,0x10
    7db2f94fe917:	or     r9,r14
    7db2f94fe91a:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94fe91f:	add    r14,0xa
    7db2f94fe923:	movzx  r15d,BYTE PTR [r14]
    7db2f94fe927:	mov    r14,r15
    7db2f94fe92a:	shl    r14,0x10
    7db2f94fe92e:	or     r8,r14
    7db2f94fe931:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94fe936:	add    r14,0xb
    7db2f94fe93a:	movzx  r15d,BYTE PTR [r14]
    7db2f94fe93e:	mov    r14,r15
    7db2f94fe941:	shl    r14,0x10
    7db2f94fe945:	or     rbp,r14
    7db2f94fe948:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94fe94d:	add    r14,0xc
    7db2f94fe951:	movzx  r15d,BYTE PTR [r14]
    7db2f94fe955:	mov    r14,r15
    7db2f94fe958:	shl    r14,0x18
    7db2f94fe95c:	or     r13,r14
    7db2f94fe95f:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94fe964:	add    r14,0xd
    7db2f94fe968:	movzx  r15d,BYTE PTR [r14]
    7db2f94fe96c:	mov    r14,r15
    7db2f94fe96f:	shl    r14,0x18
    7db2f94fe973:	or     r9,r14
    7db2f94fe976:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94fe97b:	add    r14,0xe
    7db2f94fe97f:	movzx  r15d,BYTE PTR [r14]
    7db2f94fe983:	mov    r14,r15
    7db2f94fe986:	shl    r14,0x18
    7db2f94fe98a:	or     r8,r14
    7db2f94fe98d:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94fe992:	add    r14,0xf
    7db2f94fe996:	movzx  r15d,BYTE PTR [r14]
    7db2f94fe99a:	mov    r14,r15
    7db2f94fe99d:	shl    r14,0x18
    7db2f94fe9a1:	or     rbp,r14
    7db2f94fe9a4:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94fe9a9:	add    r14,0x10
    7db2f94fe9ad:	movzx  r15d,BYTE PTR [r14]
    7db2f94fe9b1:	mov    r14,r15
    7db2f94fe9b4:	shl    r14,0x20
    7db2f94fe9b8:	or     r13,r14
    7db2f94fe9bb:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94fe9c0:	add    r14,0x11
    7db2f94fe9c4:	movzx  r15d,BYTE PTR [r14]
    7db2f94fe9c8:	mov    r14,r15
    7db2f94fe9cb:	shl    r14,0x20
    7db2f94fe9cf:	or     r9,r14
    7db2f94fe9d2:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94fe9d7:	add    r14,0x12
    7db2f94fe9db:	movzx  r15d,BYTE PTR [r14]
    7db2f94fe9df:	mov    r14,r15
    7db2f94fe9e2:	shl    r14,0x20
    7db2f94fe9e6:	or     r8,r14
    7db2f94fe9e9:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94fe9ee:	add    r14,0x13
    7db2f94fe9f2:	movzx  r15d,BYTE PTR [r14]
    7db2f94fe9f6:	mov    r14,r15
    7db2f94fe9f9:	shl    r14,0x20
    7db2f94fe9fd:	or     rbp,r14
    7db2f94fea00:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94fea05:	add    r14,0x14
    7db2f94fea09:	movzx  r15d,BYTE PTR [r14]
    7db2f94fea0d:	mov    r14,r15
    7db2f94fea10:	shl    r14,0x28
    7db2f94fea14:	or     r13,r14
    7db2f94fea17:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94fea1c:	add    r14,0x15
    7db2f94fea20:	movzx  r15d,BYTE PTR [r14]
    7db2f94fea24:	mov    r14,r15
    7db2f94fea27:	shl    r14,0x28
    7db2f94fea2b:	or     r9,r14
    7db2f94fea2e:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94fea33:	add    r14,0x16
    7db2f94fea37:	movzx  r15d,BYTE PTR [r14]
    7db2f94fea3b:	mov    r14,r15
    7db2f94fea3e:	shl    r14,0x28
    7db2f94fea42:	or     r8,r14
    7db2f94fea45:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94fea4a:	add    r14,0x17
    7db2f94fea4e:	movzx  r15d,BYTE PTR [r14]
    7db2f94fea52:	mov    r14,r15
    7db2f94fea55:	shl    r14,0x28
    7db2f94fea59:	or     rbp,r14
    7db2f94fea5c:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94fea61:	add    r14,0x18
    7db2f94fea65:	movzx  r15d,BYTE PTR [r14]
    7db2f94fea69:	mov    r14,r15
    7db2f94fea6c:	shl    r14,0x30
    7db2f94fea70:	or     r13,r14
    7db2f94fea73:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94fea78:	add    r14,0x19
    7db2f94fea7c:	movzx  r15d,BYTE PTR [r14]
    7db2f94fea80:	mov    r14,r15
    7db2f94fea83:	shl    r14,0x30
    7db2f94fea87:	or     r9,r14
    7db2f94fea8a:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94fea8f:	add    r14,0x1a
    7db2f94fea93:	movzx  r15d,BYTE PTR [r14]
    7db2f94fea97:	mov    r14,r15
    7db2f94fea9a:	shl    r14,0x30
    7db2f94fea9e:	or     r8,r14
    7db2f94feaa1:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94feaa6:	add    r14,0x1b
    7db2f94feaaa:	movzx  r15d,BYTE PTR [r14]
    7db2f94feaae:	mov    r14,r15
    7db2f94feab1:	shl    r14,0x30
    7db2f94feab5:	or     rbp,r14
    7db2f94feab8:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94feabd:	add    r14,0x1c
    7db2f94feac1:	movzx  r15d,BYTE PTR [r14]
    7db2f94feac5:	mov    r14,r15
    7db2f94feac8:	shl    r14,0x38
    7db2f94feacc:	mov    rax,r13
    7db2f94feacf:	or     rax,r14
    7db2f94fead2:	mov    QWORD PTR [rsp+0x28],rax
    7db2f94fead7:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94feadc:	add    r14,0x1d
    7db2f94feae0:	movzx  r15d,BYTE PTR [r14]
    7db2f94feae4:	mov    r14,r15
    7db2f94feae7:	shl    r14,0x38
    7db2f94feaeb:	mov    rax,r9
    7db2f94feaee:	or     rax,r14
    7db2f94feaf1:	mov    QWORD PTR [rsp+0x38],rax
    7db2f94feaf6:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94feafb:	add    r14,0x1e
    7db2f94feaff:	movzx  r15d,BYTE PTR [r14]
    7db2f94feb03:	mov    r14,r15
    7db2f94feb06:	shl    r14,0x38
    7db2f94feb0a:	mov    rax,r8
    7db2f94feb0d:	or     rax,r14
    7db2f94feb10:	mov    QWORD PTR [rsp+0x30],rax
    7db2f94feb15:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94feb1a:	add    r14,0x1f
    7db2f94feb1e:	movzx  r15d,BYTE PTR [r14]
    7db2f94feb22:	mov    r14,r15
    7db2f94feb25:	shl    r14,0x38
    7db2f94feb29:	mov    rax,rbp
    7db2f94feb2c:	or     rax,r14
    7db2f94feb2f:	mov    QWORD PTR [rsp+0x20],rax
    7db2f94feb34:	mov    r14,QWORD PTR [r12+0x40]
    7db2f94feb39:	add    r14,0x20
    7db2f94feb3d:	movzx  r15d,BYTE PTR [r14]
    7db2f94feb41:	mov    r14,QWORD PTR [rsp+0x18]
    7db2f94feb46:	or     r14,r15
    7db2f94feb49:	mov    r15,QWORD PTR [r12+0x40]
    7db2f94feb4e:	add    r15,0x21
    7db2f94feb52:	movzx  ebp,BYTE PTR [r15]
    7db2f94feb56:	mov    r15,QWORD PTR [rsp+0x10]
    7db2f94feb5b:	or     r15,rbp
    7db2f94feb5e:	mov    rbp,QWORD PTR [r12+0x40]
    7db2f94feb63:	add    rbp,0x22
    7db2f94feb67:	movzx  r13d,BYTE PTR [rbp+0x0]
    7db2f94feb6c:	mov    rbp,QWORD PTR [rsp+0x8]
    7db2f94feb71:	or     rbp,r13
    7db2f94feb74:	mov    r13,QWORD PTR [r12+0x40]
    7db2f94feb79:	add    r13,0x23
    7db2f94feb7d:	movzx  r8d,BYTE PTR [r13+0x0]
    7db2f94feb82:	mov    r13,QWORD PTR [rsp]
    7db2f94feb86:	or     r13,r8
    7db2f94feb89:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94feb8e:	add    r8,0x24
    7db2f94feb92:	movzx  r9d,BYTE PTR [r8]
    7db2f94feb96:	mov    r8,r9
    7db2f94feb99:	shl    r8,0x8
    7db2f94feb9d:	or     r14,r8
    7db2f94feba0:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94feba5:	add    r8,0x25
    7db2f94feba9:	movzx  r9d,BYTE PTR [r8]
    7db2f94febad:	mov    r8,r9
    7db2f94febb0:	shl    r8,0x8
    7db2f94febb4:	or     r15,r8
    7db2f94febb7:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94febbc:	add    r8,0x26
    7db2f94febc0:	movzx  r9d,BYTE PTR [r8]
    7db2f94febc4:	mov    r8,r9
    7db2f94febc7:	shl    r8,0x8
    7db2f94febcb:	or     rbp,r8
    7db2f94febce:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94febd3:	add    r8,0x27
    7db2f94febd7:	movzx  r9d,BYTE PTR [r8]
    7db2f94febdb:	mov    r8,r9
    7db2f94febde:	shl    r8,0x8
    7db2f94febe2:	or     r13,r8
    7db2f94febe5:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94febea:	add    r8,0x28
    7db2f94febee:	movzx  r9d,BYTE PTR [r8]
    7db2f94febf2:	mov    r8,r9
    7db2f94febf5:	shl    r8,0x10
    7db2f94febf9:	or     r14,r8
    7db2f94febfc:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94fec01:	add    r8,0x29
    7db2f94fec05:	movzx  r9d,BYTE PTR [r8]
    7db2f94fec09:	mov    r8,r9
    7db2f94fec0c:	shl    r8,0x10
    7db2f94fec10:	or     r15,r8
    7db2f94fec13:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94fec18:	add    r8,0x2a
    7db2f94fec1c:	movzx  r9d,BYTE PTR [r8]
    7db2f94fec20:	mov    r8,r9
    7db2f94fec23:	shl    r8,0x10
    7db2f94fec27:	or     rbp,r8
    7db2f94fec2a:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94fec2f:	add    r8,0x2b
    7db2f94fec33:	movzx  r9d,BYTE PTR [r8]
    7db2f94fec37:	mov    r8,r9
    7db2f94fec3a:	shl    r8,0x10
    7db2f94fec3e:	or     r13,r8
    7db2f94fec41:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94fec46:	add    r8,0x2c
    7db2f94fec4a:	movzx  r9d,BYTE PTR [r8]
    7db2f94fec4e:	mov    r8,r9
    7db2f94fec51:	shl    r8,0x18
    7db2f94fec55:	or     r14,r8
    7db2f94fec58:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94fec5d:	add    r8,0x2d
    7db2f94fec61:	movzx  r9d,BYTE PTR [r8]
    7db2f94fec65:	mov    r8,r9
    7db2f94fec68:	shl    r8,0x18
    7db2f94fec6c:	or     r15,r8
    7db2f94fec6f:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94fec74:	add    r8,0x2e
    7db2f94fec78:	movzx  r9d,BYTE PTR [r8]
    7db2f94fec7c:	mov    r8,r9
    7db2f94fec7f:	shl    r8,0x18
    7db2f94fec83:	or     rbp,r8
    7db2f94fec86:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94fec8b:	add    r8,0x2f
    7db2f94fec8f:	movzx  r9d,BYTE PTR [r8]
    7db2f94fec93:	mov    r8,r9
    7db2f94fec96:	shl    r8,0x18
    7db2f94fec9a:	or     r13,r8
    7db2f94fec9d:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94feca2:	add    r8,0x30
    7db2f94feca6:	movzx  r9d,BYTE PTR [r8]
    7db2f94fecaa:	mov    r8,r9
    7db2f94fecad:	shl    r8,0x20
    7db2f94fecb1:	or     r14,r8
    7db2f94fecb4:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94fecb9:	add    r8,0x31
    7db2f94fecbd:	movzx  r9d,BYTE PTR [r8]
    7db2f94fecc1:	mov    r8,r9
    7db2f94fecc4:	shl    r8,0x20
    7db2f94fecc8:	or     r15,r8
    7db2f94feccb:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94fecd0:	add    r8,0x32
    7db2f94fecd4:	movzx  r9d,BYTE PTR [r8]
    7db2f94fecd8:	mov    r8,r9
    7db2f94fecdb:	shl    r8,0x20
    7db2f94fecdf:	or     rbp,r8
    7db2f94fece2:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94fece7:	add    r8,0x33
    7db2f94feceb:	movzx  r9d,BYTE PTR [r8]
    7db2f94fecef:	mov    r8,r9
    7db2f94fecf2:	shl    r8,0x20
    7db2f94fecf6:	or     r13,r8
    7db2f94fecf9:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94fecfe:	add    r8,0x34
    7db2f94fed02:	movzx  r9d,BYTE PTR [r8]
    7db2f94fed06:	mov    r8,r9
    7db2f94fed09:	shl    r8,0x28
    7db2f94fed0d:	or     r14,r8
    7db2f94fed10:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94fed15:	add    r8,0x35
    7db2f94fed19:	movzx  r9d,BYTE PTR [r8]
    7db2f94fed1d:	mov    r8,r9
    7db2f94fed20:	shl    r8,0x28
    7db2f94fed24:	or     r15,r8
    7db2f94fed27:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94fed2c:	add    r8,0x36
    7db2f94fed30:	movzx  r9d,BYTE PTR [r8]
    7db2f94fed34:	mov    r8,r9
    7db2f94fed37:	shl    r8,0x28
    7db2f94fed3b:	or     rbp,r8
    7db2f94fed3e:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94fed43:	add    r8,0x37
    7db2f94fed47:	movzx  r9d,BYTE PTR [r8]
    7db2f94fed4b:	mov    r8,r9
    7db2f94fed4e:	shl    r8,0x28
    7db2f94fed52:	or     r13,r8
    7db2f94fed55:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94fed5a:	add    r8,0x38
    7db2f94fed5e:	movzx  r9d,BYTE PTR [r8]
    7db2f94fed62:	mov    r8,r9
    7db2f94fed65:	shl    r8,0x30
    7db2f94fed69:	or     r14,r8
    7db2f94fed6c:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94fed71:	add    r8,0x39
    7db2f94fed75:	movzx  r9d,BYTE PTR [r8]
    7db2f94fed79:	mov    r8,r9
    7db2f94fed7c:	shl    r8,0x30
    7db2f94fed80:	or     r15,r8
    7db2f94fed83:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94fed88:	add    r8,0x3a
    7db2f94fed8c:	movzx  r9d,BYTE PTR [r8]
    7db2f94fed90:	mov    r8,r9
    7db2f94fed93:	shl    r8,0x30
    7db2f94fed97:	or     rbp,r8
    7db2f94fed9a:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94fed9f:	add    r8,0x3b
    7db2f94feda3:	movzx  r9d,BYTE PTR [r8]
    7db2f94feda7:	mov    r8,r9
    7db2f94fedaa:	shl    r8,0x30
    7db2f94fedae:	or     r13,r8
    7db2f94fedb1:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94fedb6:	add    r8,0x3c
    7db2f94fedba:	movzx  r9d,BYTE PTR [r8]
    7db2f94fedbe:	mov    r8,r9
    7db2f94fedc1:	shl    r8,0x38
    7db2f94fedc5:	or     r14,r8
    7db2f94fedc8:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94fedcd:	add    r8,0x3d
    7db2f94fedd1:	movzx  r9d,BYTE PTR [r8]
    7db2f94fedd5:	mov    r8,r9
    7db2f94fedd8:	shl    r8,0x38
    7db2f94feddc:	or     r15,r8
    7db2f94feddf:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94fede4:	add    r8,0x3e
    7db2f94fede8:	movzx  r9d,BYTE PTR [r8]
    7db2f94fedec:	mov    r8,r9
    7db2f94fedef:	shl    r8,0x38
    7db2f94fedf3:	or     rbp,r8
    7db2f94fedf6:	mov    r8,QWORD PTR [r12+0x40]
    7db2f94fedfb:	add    r8,0x3f
    7db2f94fedff:	movzx  r9d,BYTE PTR [r8]
    7db2f94fee03:	mov    r8,r9
    7db2f94fee06:	shl    r8,0x38
    7db2f94fee0a:	mov    rax,r13
    7db2f94fee0d:	or     rax,r8
    7db2f94fee10:	mov    QWORD PTR [rsp+0x40],rax
    7db2f94fee15:	mov    r8d,0x0
    7db2f94fee1b:	mov    QWORD PTR [r12+0x58],r8
    7db2f94fee20:	mov    r8d,0x0
    7db2f94fee26:	mov    r9,QWORD PTR [rsp+0x38]
    7db2f94fee2b:	and    r9,0xff
    7db2f94fee32:	and    r9,0xffff
    7db2f94fee39:	mov    r13,r8
    7db2f94fee3c:	or     r13,r9
    7db2f94fee3f:	mov    r9,QWORD PTR [rsp+0x38]
    7db2f94fee44:	shr    r9,0x8
    7db2f94fee48:	and    r9,0xff
    7db2f94fee4f:	and    r9,0xffff
    7db2f94fee56:	shl    r9,0x10
    7db2f94fee5a:	or     r13,r9
    7db2f94fee5d:	mov    r9,QWORD PTR [rsp+0x38]
    7db2f94fee62:	shr    r9,0x10
    7db2f94fee66:	and    r9,0xff
    7db2f94fee6d:	and    r9,0xffff
    7db2f94fee74:	shl    r9,0x20
    7db2f94fee78:	or     r13,r9
    7db2f94fee7b:	mov    r9,QWORD PTR [rsp+0x38]
    7db2f94fee80:	shr    r9,0x18
    7db2f94fee84:	and    r9,0xff
    7db2f94fee8b:	and    r9,0xffff
    7db2f94fee92:	shl    r9,0x30
    7db2f94fee96:	or     r13,r9
    7db2f94fee99:	mov    r9,QWORD PTR [rsp+0x38]
    7db2f94fee9e:	shr    r9,0x20
    7db2f94feea2:	and    r9,0xff
    7db2f94feea9:	and    r9,0xffff
    7db2f94feeb0:	or     r8,r9
    7db2f94feeb3:	mov    r9,QWORD PTR [rsp+0x38]
    7db2f94feeb8:	shr    r9,0x28
    7db2f94feebc:	and    r9,0xff
    7db2f94feec3:	and    r9,0xffff
    7db2f94feeca:	shl    r9,0x10
    7db2f94feece:	or     r8,r9
    7db2f94feed1:	mov    r9,QWORD PTR [rsp+0x38]
    7db2f94feed6:	shr    r9,0x30
    7db2f94feeda:	and    r9,0xff
    7db2f94feee1:	and    r9,0xffff
    7db2f94feee8:	shl    r9,0x20
    7db2f94feeec:	or     r8,r9
    7db2f94feeef:	mov    r9,QWORD PTR [rsp+0x38]
    7db2f94feef4:	shr    r9,0x38
    7db2f94feef8:	and    r9,0xff
    7db2f94feeff:	and    r9,0xffff
    7db2f94fef06:	shl    r9,0x30
    7db2f94fef0a:	or     r8,r9
    7db2f94fef0d:	mov    QWORD PTR [r12+0x150],r13
    7db2f94fef15:	mov    QWORD PTR [r12+0x158],r8
    7db2f94fef1d:	mov    r13d,0x0
    7db2f94fef23:	mov    r8,QWORD PTR [rsp+0x30]
    7db2f94fef28:	and    r8,0xff
    7db2f94fef2f:	and    r8,0xffff
    7db2f94fef36:	mov    r9,r13
    7db2f94fef39:	or     r9,r8
    7db2f94fef3c:	mov    r8,QWORD PTR [rsp+0x30]
    7db2f94fef41:	shr    r8,0x8
    7db2f94fef45:	and    r8,0xff
    7db2f94fef4c:	and    r8,0xffff
    7db2f94fef53:	shl    r8,0x10
    7db2f94fef57:	or     r9,r8
    7db2f94fef5a:	mov    r8,QWORD PTR [rsp+0x30]
    7db2f94fef5f:	shr    r8,0x10
    7db2f94fef63:	and    r8,0xff
    7db2f94fef6a:	and    r8,0xffff
    7db2f94fef71:	shl    r8,0x20
    7db2f94fef75:	or     r9,r8
    7db2f94fef78:	mov    r8,QWORD PTR [rsp+0x30]
    7db2f94fef7d:	shr    r8,0x18
    7db2f94fef81:	and    r8,0xff
    7db2f94fef88:	and    r8,0xffff
    7db2f94fef8f:	shl    r8,0x30
    7db2f94fef93:	mov    rax,r9
    7db2f94fef96:	or     rax,r8
    7db2f94fef99:	mov    QWORD PTR [rsp+0x50],rax
    7db2f94fef9e:	mov    r8,QWORD PTR [rsp+0x30]
    7db2f94fefa3:	shr    r8,0x20
    7db2f94fefa7:	and    r8,0xff
    7db2f94fefae:	and    r8,0xffff
    7db2f94fefb5:	or     r13,r8
    7db2f94fefb8:	mov    r8,QWORD PTR [rsp+0x30]
    7db2f94fefbd:	shr    r8,0x28
    7db2f94fefc1:	and    r8,0xff
    7db2f94fefc8:	and    r8,0xffff
    7db2f94fefcf:	shl    r8,0x10
    7db2f94fefd3:	or     r13,r8
    7db2f94fefd6:	mov    r8,QWORD PTR [rsp+0x30]
    7db2f94fefdb:	shr    r8,0x30
    7db2f94fefdf:	and    r8,0xff
    7db2f94fefe6:	and    r8,0xffff
    7db2f94fefed:	shl    r8,0x20
    7db2f94feff1:	or     r13,r8
    7db2f94feff4:	mov    r8,QWORD PTR [rsp+0x30]
    7db2f94feff9:	shr    r8,0x38
    7db2f94feffd:	and    r8,0xff
    7db2f94ff004:	and    r8,0xffff
    7db2f94ff00b:	shl    r8,0x30
    7db2f94ff00f:	mov    rax,r13
    7db2f94ff012:	or     rax,r8
    7db2f94ff015:	mov    QWORD PTR [rsp+0x48],rax
    7db2f94ff01a:	mov    r8d,0x0
    7db2f94ff020:	mov    r13,QWORD PTR [rsp+0x28]
    7db2f94ff025:	and    r13,0xff
    7db2f94ff02c:	and    r13,0xffff
    7db2f94ff033:	mov    r9,r8
    7db2f94ff036:	or     r9,r13
    7db2f94ff039:	mov    r13,QWORD PTR [rsp+0x28]
    7db2f94ff03e:	shr    r13,0x8
    7db2f94ff042:	and    r13,0xff
    7db2f94ff049:	and    r13,0xffff
    7db2f94ff050:	shl    r13,0x10
    7db2f94ff054:	or     r9,r13
    7db2f94ff057:	mov    r13,QWORD PTR [rsp+0x28]
    7db2f94ff05c:	shr    r13,0x10
    7db2f94ff060:	and    r13,0xff
    7db2f94ff067:	and    r13,0xffff
    7db2f94ff06e:	shl    r13,0x20
    7db2f94ff072:	or     r9,r13
    7db2f94ff075:	mov    r13,QWORD PTR [rsp+0x28]
    7db2f94ff07a:	shr    r13,0x18
    7db2f94ff07e:	and    r13,0xff
    7db2f94ff085:	and    r13,0xffff
    7db2f94ff08c:	shl    r13,0x30
    7db2f94ff090:	mov    rax,r9
    7db2f94ff093:	or     rax,r13
    7db2f94ff096:	mov    QWORD PTR [rsp+0x58],rax
    7db2f94ff09b:	mov    r13,QWORD PTR [rsp+0x28]
    7db2f94ff0a0:	shr    r13,0x20
    7db2f94ff0a4:	and    r13,0xff
    7db2f94ff0ab:	and    r13,0xffff
    7db2f94ff0b2:	or     r8,r13
    7db2f94ff0b5:	mov    r13,QWORD PTR [rsp+0x28]
    7db2f94ff0ba:	shr    r13,0x28
    7db2f94ff0be:	and    r13,0xff
    7db2f94ff0c5:	and    r13,0xffff
    7db2f94ff0cc:	shl    r13,0x10
    7db2f94ff0d0:	or     r8,r13
    7db2f94ff0d3:	mov    r13,QWORD PTR [rsp+0x28]
    7db2f94ff0d8:	shr    r13,0x30
    7db2f94ff0dc:	and    r13,0xff
    7db2f94ff0e3:	and    r13,0xffff
    7db2f94ff0ea:	shl    r13,0x20
    7db2f94ff0ee:	or     r8,r13
    7db2f94ff0f1:	mov    r13,QWORD PTR [rsp+0x28]
    7db2f94ff0f6:	shr    r13,0x38
    7db2f94ff0fa:	and    r13,0xff
    7db2f94ff101:	and    r13,0xffff
    7db2f94ff108:	shl    r13,0x30
    7db2f94ff10c:	mov    rax,r8
    7db2f94ff10f:	or     rax,r13
    7db2f94ff112:	mov    QWORD PTR [rsp+0x60],rax
    7db2f94ff117:	mov    r13d,0x0
    7db2f94ff11d:	mov    r9,r14
    7db2f94ff120:	and    r9,0xff
    7db2f94ff127:	and    r9,0xffff
    7db2f94ff12e:	mov    r8,r13
    7db2f94ff131:	or     r8,r9
    7db2f94ff134:	mov    r9,r14
    7db2f94ff137:	shr    r9,0x8
    7db2f94ff13b:	and    r9,0xff
    7db2f94ff142:	and    r9,0xffff
    7db2f94ff149:	shl    r9,0x10
    7db2f94ff14d:	or     r8,r9
    7db2f94ff150:	mov    r9,r14
    7db2f94ff153:	shr    r9,0x10
    7db2f94ff157:	and    r9,0xff
    7db2f94ff15e:	and    r9,0xffff
    7db2f94ff165:	shl    r9,0x20
    7db2f94ff169:	or     r8,r9
    7db2f94ff16c:	mov    r9,r14
    7db2f94ff16f:	shr    r9,0x18
    7db2f94ff173:	and    r9,0xff
    7db2f94ff17a:	and    r9,0xffff
    7db2f94ff181:	shl    r9,0x30
    7db2f94ff185:	mov    rax,r8
    7db2f94ff188:	or     rax,r9
    7db2f94ff18b:	mov    QWORD PTR [rsp+0x68],rax
    7db2f94ff190:	mov    r9,r14
    7db2f94ff193:	shr    r9,0x20
    7db2f94ff197:	and    r9,0xff
    7db2f94ff19e:	and    r9,0xffff
    7db2f94ff1a5:	or     r13,r9
    7db2f94ff1a8:	mov    r9,r14
    7db2f94ff1ab:	shr    r9,0x28
    7db2f94ff1af:	and    r9,0xff
    7db2f94ff1b6:	and    r9,0xffff
    7db2f94ff1bd:	shl    r9,0x10
    7db2f94ff1c1:	or     r13,r9
    7db2f94ff1c4:	mov    r9,r14
    7db2f94ff1c7:	shr    r9,0x30
    7db2f94ff1cb:	and    r9,0xff
    7db2f94ff1d2:	and    r9,0xffff
    7db2f94ff1d9:	shl    r9,0x20
    7db2f94ff1dd:	or     r13,r9
    7db2f94ff1e0:	shr    r14,0x38
    7db2f94ff1e4:	and    r14,0xff
    7db2f94ff1eb:	and    r14,0xffff
    7db2f94ff1f2:	shl    r14,0x30
    7db2f94ff1f6:	or     r13,r14
    7db2f94ff1f9:	mov    r14d,0x0
    7db2f94ff1ff:	mov    r9,r15
    7db2f94ff202:	and    r9,0xff
    7db2f94ff209:	and    r9,0xffff
    7db2f94ff210:	mov    r8,r14
    7db2f94ff213:	or     r8,r9
    7db2f94ff216:	mov    r9,r15
    7db2f94ff219:	shr    r9,0x8
    7db2f94ff21d:	and    r9,0xff
    7db2f94ff224:	and    r9,0xffff
    7db2f94ff22b:	shl    r9,0x10
    7db2f94ff22f:	or     r8,r9
    7db2f94ff232:	mov    r9,r15
    7db2f94ff235:	shr    r9,0x10
    7db2f94ff239:	and    r9,0xff
    7db2f94ff240:	and    r9,0xffff
    7db2f94ff247:	shl    r9,0x20
    7db2f94ff24b:	or     r8,r9
    7db2f94ff24e:	mov    r9,r15
    7db2f94ff251:	shr    r9,0x18
    7db2f94ff255:	and    r9,0xff
    7db2f94ff25c:	and    r9,0xffff
    7db2f94ff263:	shl    r9,0x30
    7db2f94ff267:	or     r8,r9
    7db2f94ff26a:	mov    r9,r15
    7db2f94ff26d:	shr    r9,0x20
    7db2f94ff271:	and    r9,0xff
    7db2f94ff278:	and    r9,0xffff
    7db2f94ff27f:	or     r14,r9
    7db2f94ff282:	mov    r9,r15
    7db2f94ff285:	shr    r9,0x28
    7db2f94ff289:	and    r9,0xff
    7db2f94ff290:	and    r9,0xffff
    7db2f94ff297:	shl    r9,0x10
    7db2f94ff29b:	or     r14,r9
    7db2f94ff29e:	mov    r9,r15
    7db2f94ff2a1:	shr    r9,0x30
    7db2f94ff2a5:	and    r9,0xff
    7db2f94ff2ac:	and    r9,0xffff
    7db2f94ff2b3:	shl    r9,0x20
    7db2f94ff2b7:	or     r14,r9
    7db2f94ff2ba:	shr    r15,0x38
    7db2f94ff2be:	and    r15,0xff
    7db2f94ff2c5:	and    r15,0xffff
    7db2f94ff2cc:	shl    r15,0x30
    7db2f94ff2d0:	or     r14,r15
    7db2f94ff2d3:	mov    QWORD PTR [r12+0x210],r8
    7db2f94ff2db:	mov    QWORD PTR [r12+0x218],r14
    7db2f94ff2e3:	mov    r14d,0x0
    7db2f94ff2e9:	mov    r15,rbp
    7db2f94ff2ec:	and    r15,0xff
    7db2f94ff2f3:	and    r15,0xffff
    7db2f94ff2fa:	mov    r8,r14
    7db2f94ff2fd:	or     r8,r15
    7db2f94ff300:	mov    r15,rbp
    7db2f94ff303:	shr    r15,0x8
    7db2f94ff307:	and    r15,0xff
    7db2f94ff30e:	and    r15,0xffff
    7db2f94ff315:	shl    r15,0x10
    7db2f94ff319:	or     r8,r15
    7db2f94ff31c:	mov    r15,rbp
    7db2f94ff31f:	shr    r15,0x10
    7db2f94ff323:	and    r15,0xff
    7db2f94ff32a:	and    r15,0xffff
    7db2f94ff331:	shl    r15,0x20
    7db2f94ff335:	or     r8,r15
    7db2f94ff338:	mov    r15,rbp
    7db2f94ff33b:	shr    r15,0x18
    7db2f94ff33f:	and    r15,0xff
    7db2f94ff346:	and    r15,0xffff
    7db2f94ff34d:	shl    r15,0x30
    7db2f94ff351:	or     r8,r15
    7db2f94ff354:	mov    r15,rbp
    7db2f94ff357:	shr    r15,0x20
    7db2f94ff35b:	and    r15,0xff
    7db2f94ff362:	and    r15,0xffff
    7db2f94ff369:	or     r14,r15
    7db2f94ff36c:	mov    r15,rbp
    7db2f94ff36f:	shr    r15,0x28
    7db2f94ff373:	and    r15,0xff
    7db2f94ff37a:	and    r15,0xffff
    7db2f94ff381:	shl    r15,0x10
    7db2f94ff385:	or     r14,r15
    7db2f94ff388:	mov    r15,rbp
    7db2f94ff38b:	shr    r15,0x30
    7db2f94ff38f:	and    r15,0xff
    7db2f94ff396:	and    r15,0xffff
    7db2f94ff39d:	shl    r15,0x20
    7db2f94ff3a1:	or     r14,r15
    7db2f94ff3a4:	shr    rbp,0x38
    7db2f94ff3a8:	and    rbp,0xff
    7db2f94ff3af:	and    rbp,0xffff
    7db2f94ff3b6:	shl    rbp,0x30
    7db2f94ff3ba:	or     r14,rbp
    7db2f94ff3bd:	mov    r15d,0x0
    7db2f94ff3c3:	mov    rbp,QWORD PTR [rsp+0x20]
    7db2f94ff3c8:	and    rbp,0xff
    7db2f94ff3cf:	and    rbp,0xffff
    7db2f94ff3d6:	mov    r9,r15
    7db2f94ff3d9:	or     r9,rbp
    7db2f94ff3dc:	mov    rbp,QWORD PTR [rsp+0x20]
    7db2f94ff3e1:	shr    rbp,0x8
    7db2f94ff3e5:	and    rbp,0xff
    7db2f94ff3ec:	and    rbp,0xffff
    7db2f94ff3f3:	shl    rbp,0x10
    7db2f94ff3f7:	or     r9,rbp
    7db2f94ff3fa:	mov    rbp,QWORD PTR [rsp+0x20]
    7db2f94ff3ff:	shr    rbp,0x10
    7db2f94ff403:	and    rbp,0xff
    7db2f94ff40a:	and    rbp,0xffff
    7db2f94ff411:	shl    rbp,0x20
    7db2f94ff415:	or     r9,rbp
    7db2f94ff418:	mov    rbp,QWORD PTR [rsp+0x20]
    7db2f94ff41d:	shr    rbp,0x18
    7db2f94ff421:	and    rbp,0xff
    7db2f94ff428:	and    rbp,0xffff
    7db2f94ff42f:	shl    rbp,0x30
    7db2f94ff433:	mov    rax,r9
    7db2f94ff436:	or     rax,rbp
    7db2f94ff439:	mov    QWORD PTR [rsp+0x78],rax
    7db2f94ff43e:	mov    rbp,QWORD PTR [rsp+0x20]
    7db2f94ff443:	shr    rbp,0x20
    7db2f94ff447:	and    rbp,0xff
    7db2f94ff44e:	and    rbp,0xffff
    7db2f94ff455:	or     r15,rbp
    7db2f94ff458:	mov    rbp,QWORD PTR [rsp+0x20]
    7db2f94ff45d:	shr    rbp,0x28
    7db2f94ff461:	and    rbp,0xff
    7db2f94ff468:	and    rbp,0xffff
    7db2f94ff46f:	shl    rbp,0x10
    7db2f94ff473:	or     r15,rbp
    7db2f94ff476:	mov    rbp,QWORD PTR [rsp+0x20]
    7db2f94ff47b:	shr    rbp,0x30
    7db2f94ff47f:	and    rbp,0xff
    7db2f94ff486:	and    rbp,0xffff
    7db2f94ff48d:	shl    rbp,0x20
    7db2f94ff491:	or     r15,rbp
    7db2f94ff494:	mov    rbp,QWORD PTR [rsp+0x20]
    7db2f94ff499:	shr    rbp,0x38
    7db2f94ff49d:	and    rbp,0xff
    7db2f94ff4a4:	and    rbp,0xffff
    7db2f94ff4ab:	shl    rbp,0x30
    7db2f94ff4af:	mov    rax,r15
    7db2f94ff4b2:	or     rax,rbp
    7db2f94ff4b5:	mov    QWORD PTR [rsp+0x70],rax
    7db2f94ff4ba:	mov    rax,QWORD PTR [rsp+0x78]
    7db2f94ff4bf:	mov    QWORD PTR [r12+0x250],rax
    7db2f94ff4c7:	mov    rax,QWORD PTR [rsp+0x70]
    7db2f94ff4cc:	mov    QWORD PTR [r12+0x258],rax
    7db2f94ff4d4:	mov    ebp,0x0
    7db2f94ff4d9:	mov    r15,QWORD PTR [rsp+0x40]
    7db2f94ff4de:	and    r15,0xff
    7db2f94ff4e5:	and    r15,0xffff
    7db2f94ff4ec:	mov    r9,rbp
    7db2f94ff4ef:	or     r9,r15
    7db2f94ff4f2:	mov    r15,QWORD PTR [rsp+0x40]
    7db2f94ff4f7:	shr    r15,0x8
    7db2f94ff4fb:	and    r15,0xff
    7db2f94ff502:	and    r15,0xffff
    7db2f94ff509:	shl    r15,0x10
    7db2f94ff50d:	or     r9,r15
    7db2f94ff510:	mov    r15,QWORD PTR [rsp+0x40]
    7db2f94ff515:	shr    r15,0x10
    7db2f94ff519:	and    r15,0xff
    7db2f94ff520:	and    r15,0xffff
    7db2f94ff527:	shl    r15,0x20
    7db2f94ff52b:	or     r9,r15
    7db2f94ff52e:	mov    r15,QWORD PTR [rsp+0x40]
    7db2f94ff533:	shr    r15,0x18
    7db2f94ff537:	and    r15,0xff
    7db2f94ff53e:	and    r15,0xffff
    7db2f94ff545:	shl    r15,0x30
    7db2f94ff549:	mov    rax,r9
    7db2f94ff54c:	or     rax,r15
    7db2f94ff54f:	mov    QWORD PTR [rsp+0x80],rax
    7db2f94ff557:	mov    r15,QWORD PTR [rsp+0x40]
    7db2f94ff55c:	shr    r15,0x20
    7db2f94ff560:	and    r15,0xff
    7db2f94ff567:	and    r15,0xffff
    7db2f94ff56e:	or     rbp,r15
    7db2f94ff571:	mov    r15,QWORD PTR [rsp+0x40]
    7db2f94ff576:	shr    r15,0x28
    7db2f94ff57a:	and    r15,0xff
    7db2f94ff581:	and    r15,0xffff
    7db2f94ff588:	shl    r15,0x10
    7db2f94ff58c:	or     rbp,r15
    7db2f94ff58f:	mov    r15,QWORD PTR [rsp+0x40]
    7db2f94ff594:	shr    r15,0x30
    7db2f94ff598:	and    r15,0xff
    7db2f94ff59f:	and    r15,0xffff
    7db2f94ff5a6:	shl    r15,0x20
    7db2f94ff5aa:	or     rbp,r15
    7db2f94ff5ad:	mov    r15,QWORD PTR [rsp+0x40]
    7db2f94ff5b2:	shr    r15,0x38
    7db2f94ff5b6:	and    r15,0xff
    7db2f94ff5bd:	and    r15,0xffff
    7db2f94ff5c4:	shl    r15,0x30
    7db2f94ff5c8:	mov    rax,rbp
    7db2f94ff5cb:	or     rax,r15
    7db2f94ff5ce:	mov    QWORD PTR [rsp+0x88],rax
    7db2f94ff5d6:	movdqu xmm2,XMMWORD PTR [r12+0x150]
    7db2f94ff5e0:	pxor   xmm0,xmm0
    7db2f94ff5e4:	movdqa xmm3,xmm0
    7db2f94ff5e8:	movdqa xmm0,xmm2
    7db2f94ff5ec:	movdqa xmm1,xmm3
    7db2f94ff5f0:	punpcklwd xmm0,xmm1
    7db2f94ff5f4:	movdqa xmm4,xmm0
    7db2f94ff5f8:	movdqa xmm0,xmm4
    7db2f94ff5fc:	pslld  xmm0,0x10
    7db2f94ff601:	movdqa xmm3,xmm0
    7db2f94ff605:	mov    r15d,0x0
    7db2f94ff60b:	mov    r9,QWORD PTR [rsp+0x50]
    7db2f94ff610:	and    r9,0xffff
    7db2f94ff617:	shl    r9,0x8
    7db2f94ff61b:	mov    ecx,0xffffffff
    7db2f94ff620:	and    r9,rcx
    7db2f94ff623:	mov    rbp,r15
    7db2f94ff626:	or     rbp,r9
    7db2f94ff629:	mov    r9,QWORD PTR [rsp+0x50]
    7db2f94ff62e:	shr    r9,0x10
    7db2f94ff632:	and    r9,0xffff
    7db2f94ff639:	shl    r9,0x8
    7db2f94ff63d:	mov    ecx,0xffffffff
    7db2f94ff642:	and    r9,rcx
    7db2f94ff645:	shl    r9,0x20
    7db2f94ff649:	or     rbp,r9
    7db2f94ff64c:	mov    r9,QWORD PTR [rsp+0x50]
    7db2f94ff651:	shr    r9,0x20
    7db2f94ff655:	and    r9,0xffff
    7db2f94ff65c:	shl    r9,0x8
    7db2f94ff660:	mov    ecx,0xffffffff
    7db2f94ff665:	and    r9,rcx
    7db2f94ff668:	or     r15,r9
    7db2f94ff66b:	mov    r9,QWORD PTR [rsp+0x50]
    7db2f94ff670:	shr    r9,0x30
    7db2f94ff674:	and    r9,0xffff
    7db2f94ff67b:	shl    r9,0x8
    7db2f94ff67f:	mov    ecx,0xffffffff
    7db2f94ff684:	and    r9,rcx
    7db2f94ff687:	shl    r9,0x20
    7db2f94ff68b:	or     r15,r9
    7db2f94ff68e:	mov    QWORD PTR [r12+0x240],rbp
    7db2f94ff696:	mov    QWORD PTR [r12+0x248],r15
    7db2f94ff69e:	mov    r15d,0x0
    7db2f94ff6a4:	mov    rbp,QWORD PTR [rsp+0x60]
    7db2f94ff6a9:	and    rbp,0xffff
    7db2f94ff6b0:	mov    ecx,0xffffffff
    7db2f94ff6b5:	and    rbp,rcx
    7db2f94ff6b8:	mov    r9,r15
    7db2f94ff6bb:	or     r9,rbp
    7db2f94ff6be:	mov    rbp,QWORD PTR [rsp+0x60]
    7db2f94ff6c3:	shr    rbp,0x10
    7db2f94ff6c7:	and    rbp,0xffff
    7db2f94ff6ce:	mov    ecx,0xffffffff
    7db2f94ff6d3:	and    rbp,rcx
    7db2f94ff6d6:	shl    rbp,0x20
    7db2f94ff6da:	or     r9,rbp
    7db2f94ff6dd:	mov    rbp,QWORD PTR [rsp+0x60]
    7db2f94ff6e2:	shr    rbp,0x20
    7db2f94ff6e6:	and    rbp,0xffff
    7db2f94ff6ed:	mov    ecx,0xffffffff
    7db2f94ff6f2:	and    rbp,rcx
    7db2f94ff6f5:	or     r15,rbp
    7db2f94ff6f8:	mov    rbp,QWORD PTR [rsp+0x60]
    7db2f94ff6fd:	shr    rbp,0x30
    7db2f94ff701:	and    rbp,0xffff
    7db2f94ff708:	mov    ecx,0xffffffff
    7db2f94ff70d:	and    rbp,rcx
    7db2f94ff710:	shl    rbp,0x20
    7db2f94ff714:	or     r15,rbp
    7db2f94ff717:	mov    QWORD PTR [r12+0x260],r9
    7db2f94ff71f:	mov    QWORD PTR [r12+0x268],r15
    7db2f94ff727:	mov    r15d,0x0
    7db2f94ff72d:	mov    rbp,r13
    7db2f94ff730:	and    rbp,0xffff
    7db2f94ff737:	mov    ecx,0xffffffff
    7db2f94ff73c:	and    rbp,rcx
    7db2f94ff73f:	mov    r9,r15
    7db2f94ff742:	or     r9,rbp
    7db2f94ff745:	mov    rbp,r13
    7db2f94ff748:	shr    rbp,0x10
    7db2f94ff74c:	and    rbp,0xffff
    7db2f94ff753:	mov    ecx,0xffffffff
    7db2f94ff758:	and    rbp,rcx
    7db2f94ff75b:	shl    rbp,0x20
    7db2f94ff75f:	or     r9,rbp
    7db2f94ff762:	mov    rbp,r13
    7db2f94ff765:	shr    rbp,0x20
    7db2f94ff769:	and    rbp,0xffff
    7db2f94ff770:	mov    ecx,0xffffffff
    7db2f94ff775:	and    rbp,rcx
    7db2f94ff778:	or     r15,rbp
    7db2f94ff77b:	shr    r13,0x30
    7db2f94ff77f:	and    r13,0xffff
    7db2f94ff786:	mov    ecx,0xffffffff
    7db2f94ff78b:	and    r13,rcx
    7db2f94ff78e:	shl    r13,0x20
    7db2f94ff792:	or     r15,r13
    7db2f94ff795:	mov    QWORD PTR [r12+0x270],r9
    7db2f94ff79d:	mov    QWORD PTR [r12+0x278],r15
    7db2f94ff7a5:	mov    r13d,0x0
    7db2f94ff7ab:	mov    r15,QWORD PTR [rsp+0x58]
    7db2f94ff7b0:	and    r15,0xffff
    7db2f94ff7b7:	mov    ecx,0xffffffff
    7db2f94ff7bc:	and    r15,rcx
    7db2f94ff7bf:	mov    rbp,r13
    7db2f94ff7c2:	or     rbp,r15
    7db2f94ff7c5:	mov    r15,QWORD PTR [rsp+0x58]
    7db2f94ff7ca:	shr    r15,0x10
    7db2f94ff7ce:	and    r15,0xffff
    7db2f94ff7d5:	mov    ecx,0xffffffff
    7db2f94ff7da:	and    r15,rcx
    7db2f94ff7dd:	shl    r15,0x20
    7db2f94ff7e1:	or     rbp,r15
    7db2f94ff7e4:	mov    r15,QWORD PTR [rsp+0x58]
    7db2f94ff7e9:	shr    r15,0x20
    7db2f94ff7ed:	and    r15,0xffff
    7db2f94ff7f4:	mov    ecx,0xffffffff
    7db2f94ff7f9:	and    r15,rcx
    7db2f94ff7fc:	or     r13,r15
    7db2f94ff7ff:	mov    r15,QWORD PTR [rsp+0x58]
    7db2f94ff804:	shr    r15,0x30
    7db2f94ff808:	and    r15,0xffff
    7db2f94ff80f:	mov    ecx,0xffffffff
    7db2f94ff814:	and    r15,rcx
    7db2f94ff817:	shl    r15,0x20
    7db2f94ff81b:	or     r13,r15
    7db2f94ff81e:	mov    QWORD PTR [r12+0x170],rbp
    7db2f94ff826:	mov    QWORD PTR [r12+0x178],r13
    7db2f94ff82e:	movdqu xmm4,XMMWORD PTR [r12+0x210]
    7db2f94ff838:	pxor   xmm0,xmm0
    7db2f94ff83c:	movdqa xmm5,xmm0
    7db2f94ff840:	movdqa xmm0,xmm4
    7db2f94ff844:	movdqa xmm1,xmm5
    7db2f94ff848:	punpckhwd xmm0,xmm1
    7db2f94ff84c:	movdqa xmm6,xmm0
    7db2f94ff850:	movdqa xmm0,xmm6
    7db2f94ff854:	pslld  xmm0,0x10
    7db2f94ff859:	movdqa xmm5,xmm0
    7db2f94ff85d:	movdqu XMMWORD PTR [r12+0x280],xmm5
    7db2f94ff867:	mov    r13d,0x0
    7db2f94ff86d:	mov    r15,QWORD PTR [rsp+0x68]
    7db2f94ff872:	and    r15,0xffff
    7db2f94ff879:	mov    ecx,0xffffffff
    7db2f94ff87e:	and    r15,rcx
    7db2f94ff881:	mov    rbp,r13
    7db2f94ff884:	or     rbp,r15
    7db2f94ff887:	mov    r15,QWORD PTR [rsp+0x68]
    7db2f94ff88c:	shr    r15,0x10
    7db2f94ff890:	and    r15,0xffff
    7db2f94ff897:	mov    ecx,0xffffffff
    7db2f94ff89c:	and    r15,rcx
    7db2f94ff89f:	shl    r15,0x20
    7db2f94ff8a3:	or     rbp,r15
    7db2f94ff8a6:	mov    r15,QWORD PTR [rsp+0x68]
    7db2f94ff8ab:	shr    r15,0x20
    7db2f94ff8af:	and    r15,0xffff
    7db2f94ff8b6:	mov    ecx,0xffffffff
    7db2f94ff8bb:	and    r15,rcx
    7db2f94ff8be:	or     r13,r15
    7db2f94ff8c1:	mov    r15,QWORD PTR [rsp+0x68]
    7db2f94ff8c6:	shr    r15,0x30
    7db2f94ff8ca:	and    r15,0xffff
    7db2f94ff8d1:	mov    ecx,0xffffffff
    7db2f94ff8d6:	and    r15,rcx
    7db2f94ff8d9:	shl    r15,0x20
    7db2f94ff8dd:	or     r13,r15
    7db2f94ff8e0:	mov    QWORD PTR [r12+0x180],rbp
    7db2f94ff8e8:	mov    QWORD PTR [r12+0x188],r13
    7db2f94ff8f0:	pxor   xmm0,xmm0
    7db2f94ff8f4:	movdqa xmm6,xmm0
    7db2f94ff8f8:	movdqa xmm0,xmm4
    7db2f94ff8fc:	movdqa xmm1,xmm6
    7db2f94ff900:	punpcklwd xmm0,xmm1
    7db2f94ff904:	movdqa xmm7,xmm0
    7db2f94ff908:	movdqa xmm0,xmm7
    7db2f94ff90c:	pslld  xmm0,0x10
    7db2f94ff911:	movdqa xmm4,xmm0
    7db2f94ff915:	pxor   xmm0,xmm0
    7db2f94ff919:	movdqa xmm6,xmm0
    7db2f94ff91d:	movdqa xmm0,xmm2
    7db2f94ff921:	movdqa xmm1,xmm6
    7db2f94ff925:	punpckhwd xmm0,xmm1
    7db2f94ff929:	movdqa xmm7,xmm0
    7db2f94ff92d:	movdqa xmm0,xmm7
    7db2f94ff931:	pslld  xmm0,0x10
    7db2f94ff936:	movdqa xmm2,xmm0
    7db2f94ff93a:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    7db2f94ff944:	movdqa xmm1,xmm6
    7db2f94ff948:	por    xmm3,xmm1
    7db2f94ff94c:	movdqu XMMWORD PTR [r12+0x230],xmm3
    7db2f94ff956:	mov    r13d,0x0
    7db2f94ff95c:	mov    r15,r14
    7db2f94ff95f:	and    r15,0xffff
    7db2f94ff966:	shl    r15,0x8
    7db2f94ff96a:	mov    ecx,0xffffffff
    7db2f94ff96f:	and    r15,rcx
    7db2f94ff972:	mov    rbp,r13
    7db2f94ff975:	or     rbp,r15
    7db2f94ff978:	mov    r15,r14
    7db2f94ff97b:	shr    r15,0x10
    7db2f94ff97f:	and    r15,0xffff
    7db2f94ff986:	shl    r15,0x8
    7db2f94ff98a:	mov    ecx,0xffffffff
    7db2f94ff98f:	and    r15,rcx
    7db2f94ff992:	shl    r15,0x20
    7db2f94ff996:	or     rbp,r15
    7db2f94ff999:	mov    r15,r14
    7db2f94ff99c:	shr    r15,0x20
    7db2f94ff9a0:	and    r15,0xffff
    7db2f94ff9a7:	shl    r15,0x8
    7db2f94ff9ab:	mov    ecx,0xffffffff
    7db2f94ff9b0:	and    r15,rcx
    7db2f94ff9b3:	or     r13,r15
    7db2f94ff9b6:	shr    r14,0x30
    7db2f94ff9ba:	and    r14,0xffff
    7db2f94ff9c1:	shl    r14,0x8
    7db2f94ff9c5:	mov    ecx,0xffffffff
    7db2f94ff9ca:	and    r14,rcx
    7db2f94ff9cd:	shl    r14,0x20
    7db2f94ff9d1:	or     r13,r14
    7db2f94ff9d4:	mov    QWORD PTR [r12+0x240],rbp
    7db2f94ff9dc:	mov    QWORD PTR [r12+0x248],r13
    7db2f94ff9e4:	mov    r13d,0x0
    7db2f94ff9ea:	mov    r14,r8
    7db2f94ff9ed:	and    r14,0xffff
    7db2f94ff9f4:	shl    r14,0x8
    7db2f94ff9f8:	mov    ecx,0xffffffff
    7db2f94ff9fd:	and    r14,rcx
    7db2f94ffa00:	mov    r15,r13
    7db2f94ffa03:	or     r15,r14
    7db2f94ffa06:	mov    r14,r8
    7db2f94ffa09:	shr    r14,0x10
    7db2f94ffa0d:	and    r14,0xffff
    7db2f94ffa14:	shl    r14,0x8
    7db2f94ffa18:	mov    ecx,0xffffffff
    7db2f94ffa1d:	and    r14,rcx
    7db2f94ffa20:	shl    r14,0x20
    7db2f94ffa24:	or     r15,r14
    7db2f94ffa27:	mov    r14,r8
    7db2f94ffa2a:	shr    r14,0x20
    7db2f94ffa2e:	and    r14,0xffff
    7db2f94ffa35:	shl    r14,0x8
    7db2f94ffa39:	mov    ecx,0xffffffff
    7db2f94ffa3e:	and    r14,rcx
    7db2f94ffa41:	or     r13,r14
    7db2f94ffa44:	shr    r8,0x30
    7db2f94ffa48:	and    r8,0xffff
    7db2f94ffa4f:	shl    r8,0x8
    7db2f94ffa53:	mov    ecx,0xffffffff
    7db2f94ffa58:	and    r8,rcx
    7db2f94ffa5b:	shl    r8,0x20
    7db2f94ffa5f:	or     r13,r8
    7db2f94ffa62:	mov    QWORD PTR [r12+0x220],r15
    7db2f94ffa6a:	mov    QWORD PTR [r12+0x228],r13
    7db2f94ffa72:	mov    r13d,0x0
    7db2f94ffa78:	mov    r14,QWORD PTR [rsp+0x48]
    7db2f94ffa7d:	and    r14,0xffff
    7db2f94ffa84:	shl    r14,0x8
    7db2f94ffa88:	mov    ecx,0xffffffff
    7db2f94ffa8d:	and    r14,rcx
    7db2f94ffa90:	mov    r15,r13
    7db2f94ffa93:	or     r15,r14
    7db2f94ffa96:	mov    r14,QWORD PTR [rsp+0x48]
    7db2f94ffa9b:	shr    r14,0x10
    7db2f94ffa9f:	and    r14,0xffff
    7db2f94ffaa6:	shl    r14,0x8
    7db2f94ffaaa:	mov    ecx,0xffffffff
    7db2f94ffaaf:	and    r14,rcx
    7db2f94ffab2:	shl    r14,0x20
    7db2f94ffab6:	or     r15,r14
    7db2f94ffab9:	mov    r14,QWORD PTR [rsp+0x48]
    7db2f94ffabe:	shr    r14,0x20
    7db2f94ffac2:	and    r14,0xffff
    7db2f94ffac9:	shl    r14,0x8
    7db2f94ffacd:	mov    ecx,0xffffffff
    7db2f94ffad2:	and    r14,rcx
    7db2f94ffad5:	or     r13,r14
    7db2f94ffad8:	mov    r14,QWORD PTR [rsp+0x48]
    7db2f94ffadd:	shr    r14,0x30
    7db2f94ffae1:	and    r14,0xffff
    7db2f94ffae8:	shl    r14,0x8
    7db2f94ffaec:	mov    ecx,0xffffffff
    7db2f94ffaf1:	and    r14,rcx
    7db2f94ffaf4:	shl    r14,0x20
    7db2f94ffaf8:	or     r13,r14
    7db2f94ffafb:	mov    QWORD PTR [r12+0x160],r15
    7db2f94ffb03:	mov    QWORD PTR [r12+0x168],r13
    7db2f94ffb0b:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    7db2f94ffb15:	movdqa xmm0,xmm6
    7db2f94ffb19:	pslld  xmm0,0x18
    7db2f94ffb1e:	movdqa xmm7,xmm0
    7db2f94ffb22:	movdqu XMMWORD PTR [r12+0x170],xmm7
    7db2f94ffb2c:	movdqu xmm6,XMMWORD PTR [r12+0x270]
    7db2f94ffb36:	movdqa xmm0,xmm6
    7db2f94ffb3a:	pslld  xmm0,0x18
    7db2f94ffb3f:	movdqa xmm8,xmm0
    7db2f94ffb44:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    7db2f94ffb4e:	movdqa xmm0,xmm6
    7db2f94ffb52:	pslld  xmm0,0x18
    7db2f94ffb57:	movdqa xmm9,xmm0
    7db2f94ffb5c:	movdqu XMMWORD PTR [r12+0x180],xmm9
    7db2f94ffb66:	mov    r13d,0x0
    7db2f94ffb6c:	mov    r14,QWORD PTR [rsp+0x78]
    7db2f94ffb71:	and    r14,0xffff
    7db2f94ffb78:	mov    ecx,0xffffffff
    7db2f94ffb7d:	and    r14,rcx
    7db2f94ffb80:	mov    r15,r13
    7db2f94ffb83:	or     r15,r14
    7db2f94ffb86:	mov    r14,QWORD PTR [rsp+0x78]
    7db2f94ffb8b:	shr    r14,0x10
    7db2f94ffb8f:	and    r14,0xffff
    7db2f94ffb96:	mov    ecx,0xffffffff
    7db2f94ffb9b:	and    r14,rcx
    7db2f94ffb9e:	shl    r14,0x20
    7db2f94ffba2:	or     r15,r14
    7db2f94ffba5:	mov    r14,QWORD PTR [rsp+0x78]
    7db2f94ffbaa:	shr    r14,0x20
    7db2f94ffbae:	and    r14,0xffff
    7db2f94ffbb5:	mov    ecx,0xffffffff
    7db2f94ffbba:	and    r14,rcx
    7db2f94ffbbd:	or     r13,r14
    7db2f94ffbc0:	mov    r14,QWORD PTR [rsp+0x78]
    7db2f94ffbc5:	shr    r14,0x30
    7db2f94ffbc9:	and    r14,0xffff
    7db2f94ffbd0:	mov    ecx,0xffffffff
    7db2f94ffbd5:	and    r14,rcx
    7db2f94ffbd8:	shl    r14,0x20
    7db2f94ffbdc:	or     r13,r14
    7db2f94ffbdf:	mov    QWORD PTR [r12+0x140],r15
    7db2f94ffbe7:	mov    QWORD PTR [r12+0x148],r13
    7db2f94ffbef:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    7db2f94ffbf9:	movdqa xmm1,xmm6
    7db2f94ffbfd:	por    xmm5,xmm1
    7db2f94ffc01:	movdqu xmm6,XMMWORD PTR [r12+0x220]
    7db2f94ffc0b:	movdqa xmm1,xmm6
    7db2f94ffc0f:	por    xmm4,xmm1
    7db2f94ffc13:	movdqu XMMWORD PTR [r12+0x210],xmm4
    7db2f94ffc1d:	movdqu xmm6,XMMWORD PTR [r12+0x260]
    7db2f94ffc27:	movdqa xmm0,xmm6
    7db2f94ffc2b:	pslld  xmm0,0x18
    7db2f94ffc30:	movdqa xmm10,xmm0
    7db2f94ffc35:	movdqu XMMWORD PTR [r12+0x220],xmm10
    7db2f94ffc3f:	movdqu xmm6,XMMWORD PTR [r12+0x160]
    7db2f94ffc49:	movdqa xmm1,xmm6
    7db2f94ffc4d:	por    xmm2,xmm1
    7db2f94ffc51:	movdqa xmm1,xmm7
    7db2f94ffc55:	por    xmm3,xmm1
    7db2f94ffc59:	movdqu XMMWORD PTR [r12+0x160],xmm3
    7db2f94ffc63:	mov    r13d,0x0
    7db2f94ffc69:	mov    r14,QWORD PTR [rsp+0x88]
    7db2f94ffc71:	and    r14,0xffff
    7db2f94ffc78:	mov    ecx,0xffffffff
    7db2f94ffc7d:	and    r14,rcx
    7db2f94ffc80:	mov    r15,r13
    7db2f94ffc83:	or     r15,r14
    7db2f94ffc86:	mov    r14,QWORD PTR [rsp+0x88]
    7db2f94ffc8e:	shr    r14,0x10
    7db2f94ffc92:	and    r14,0xffff
    7db2f94ffc99:	mov    ecx,0xffffffff
    7db2f94ffc9e:	and    r14,rcx
    7db2f94ffca1:	shl    r14,0x20
    7db2f94ffca5:	or     r15,r14
    7db2f94ffca8:	mov    r14,QWORD PTR [rsp+0x88]
    7db2f94ffcb0:	shr    r14,0x20
    7db2f94ffcb4:	and    r14,0xffff
    7db2f94ffcbb:	mov    ecx,0xffffffff
    7db2f94ffcc0:	and    r14,rcx
    7db2f94ffcc3:	or     r13,r14
    7db2f94ffcc6:	mov    r14,QWORD PTR [rsp+0x88]
    7db2f94ffcce:	shr    r14,0x30
    7db2f94ffcd2:	and    r14,0xffff
    7db2f94ffcd9:	mov    ecx,0xffffffff
    7db2f94ffcde:	and    r14,rcx
    7db2f94ffce1:	shl    r14,0x20
    7db2f94ffce5:	or     r13,r14
    7db2f94ffce8:	mov    QWORD PTR [r12+0x170],r15
    7db2f94ffcf0:	mov    QWORD PTR [r12+0x178],r13
    7db2f94ffcf8:	mov    r13d,0x0
    7db2f94ffcfe:	mov    r14,QWORD PTR [rsp+0x80]
    7db2f94ffd06:	and    r14,0xffff
    7db2f94ffd0d:	mov    ecx,0xffffffff
    7db2f94ffd12:	and    r14,rcx
    7db2f94ffd15:	mov    r15,r13
    7db2f94ffd18:	or     r15,r14
    7db2f94ffd1b:	mov    r14,QWORD PTR [rsp+0x80]
    7db2f94ffd23:	shr    r14,0x10
    7db2f94ffd27:	and    r14,0xffff
    7db2f94ffd2e:	mov    ecx,0xffffffff
    7db2f94ffd33:	and    r14,rcx
    7db2f94ffd36:	shl    r14,0x20
    7db2f94ffd3a:	or     r15,r14
    7db2f94ffd3d:	mov    r14,QWORD PTR [rsp+0x80]
    7db2f94ffd45:	shr    r14,0x20
    7db2f94ffd49:	and    r14,0xffff
    7db2f94ffd50:	mov    ecx,0xffffffff
    7db2f94ffd55:	and    r14,rcx
    7db2f94ffd58:	or     r13,r14
    7db2f94ffd5b:	mov    r14,QWORD PTR [rsp+0x80]
    7db2f94ffd63:	shr    r14,0x30
    7db2f94ffd67:	and    r14,0xffff
    7db2f94ffd6e:	mov    ecx,0xffffffff
    7db2f94ffd73:	and    r14,rcx
    7db2f94ffd76:	shl    r14,0x20
    7db2f94ffd7a:	or     r13,r14
    7db2f94ffd7d:	mov    QWORD PTR [r12+0x110],r15
    7db2f94ffd85:	mov    QWORD PTR [r12+0x118],r13
    7db2f94ffd8d:	movdqa xmm1,xmm8
    7db2f94ffd92:	por    xmm5,xmm1
    7db2f94ffd96:	movdqa xmm1,xmm9
    7db2f94ffd9b:	por    xmm4,xmm1
    7db2f94ffd9f:	mov    r13d,0x0
    7db2f94ffda5:	mov    r14,QWORD PTR [rsp+0x70]
    7db2f94ffdaa:	and    r14,0xffff
    7db2f94ffdb1:	mov    ecx,0xffffffff
    7db2f94ffdb6:	and    r14,rcx
    7db2f94ffdb9:	mov    r15,r13
    7db2f94ffdbc:	or     r15,r14
    7db2f94ffdbf:	mov    r14,QWORD PTR [rsp+0x70]
    7db2f94ffdc4:	shr    r14,0x10
    7db2f94ffdc8:	and    r14,0xffff
    7db2f94ffdcf:	mov    ecx,0xffffffff
    7db2f94ffdd4:	and    r14,rcx
    7db2f94ffdd7:	shl    r14,0x20
    7db2f94ffddb:	or     r15,r14
    7db2f94ffdde:	mov    r14,QWORD PTR [rsp+0x70]
    7db2f94ffde3:	shr    r14,0x20
    7db2f94ffde7:	and    r14,0xffff
    7db2f94ffdee:	mov    ecx,0xffffffff
    7db2f94ffdf3:	and    r14,rcx
    7db2f94ffdf6:	or     r13,r14
    7db2f94ffdf9:	mov    r14,QWORD PTR [rsp+0x70]
    7db2f94ffdfe:	shr    r14,0x30
    7db2f94ffe02:	and    r14,0xffff
    7db2f94ffe09:	mov    ecx,0xffffffff
    7db2f94ffe0e:	and    r14,rcx
    7db2f94ffe11:	shl    r14,0x20
    7db2f94ffe15:	or     r13,r14
    7db2f94ffe18:	mov    QWORD PTR [r12+0x180],r15
    7db2f94ffe20:	mov    QWORD PTR [r12+0x188],r13
    7db2f94ffe28:	movdqa xmm1,xmm10
    7db2f94ffe2d:	por    xmm2,xmm1
    7db2f94ffe31:	movdqu XMMWORD PTR [r12+0x150],xmm2
    7db2f94ffe3b:	movdqu xmm6,XMMWORD PTR [r12+0x140]
    7db2f94ffe45:	movdqa xmm1,xmm6
    7db2f94ffe49:	por    xmm3,xmm1
    7db2f94ffe4d:	movdqu XMMWORD PTR [r12+0x140],xmm3
    7db2f94ffe57:	movdqu xmm6,XMMWORD PTR [r12+0x110]
    7db2f94ffe61:	movdqa xmm1,xmm6
    7db2f94ffe65:	por    xmm4,xmm1
    7db2f94ffe69:	movdqu XMMWORD PTR [r12+0x110],xmm4
    7db2f94ffe73:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    7db2f94ffe7d:	movdqa xmm1,xmm6
    7db2f94ffe81:	por    xmm5,xmm1
    7db2f94ffe85:	movdqu XMMWORD PTR [r12+0x120],xmm5
    7db2f94ffe8f:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    7db2f94ffe99:	movdqa xmm1,xmm6
    7db2f94ffe9d:	por    xmm2,xmm1
    7db2f94ffea1:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7db2f94ffeab:	mov    r13,QWORD PTR [r12+0xf8]
    7db2f94ffeb3:	mov    r14,r13
    7db2f94ffeb6:	add    r14,0x20
    7db2f94ffeba:	mov    r15,r14
    7db2f94ffebd:	add    r15,0x10
    7db2f94ffec1:	movdqu XMMWORD PTR [r14],xmm4
    7db2f94ffec6:	mov    r14d,0x0
    7db2f94ffecc:	mov    DWORD PTR [r12+0x32c],r14d
    7db2f94ffed4:	movdqu XMMWORD PTR [r15],xmm5
    7db2f94ffed9:	mov    r14,r13
    7db2f94ffedc:	add    r14,0x10
    7db2f94ffee0:	movdqu XMMWORD PTR [r13+0x0],xmm3
    7db2f94ffee6:	movdqu XMMWORD PTR [r14],xmm2
    7db2f94ffeeb:	mov    r14d,DWORD PTR [r13+0x0]
    7db2f94ffeef:	mov    QWORD PTR [r12+0x60],r14
    7db2f94ffef4:	jmp    0x7db2f94ffef9
    7db2f94ffef9:	mov    r13,QWORD PTR [r12+0x58]
    7db2f94ffefe:	mov    r14,QWORD PTR [r12+0x48]
    7db2f94fff03:	add    r14,r13
    7db2f94fff06:	mov    QWORD PTR [r12+0x68],r14
    7db2f94fff0b:	add    r13,0x4
    7db2f94fff0f:	mov    QWORD PTR [r12+0x58],r13
    7db2f94fff14:	mov    r15,r14
    7db2f94fff17:	add    r15,0x4
    7db2f94fff1b:	mov    eax,DWORD PTR [r15]
    7db2f94fff1e:	mov    QWORD PTR [r12+0x70],rax
    7db2f94fff23:	mov    r15,r14
    7db2f94fff26:	add    r15,0x38
    7db2f94fff2a:	mov    r8d,DWORD PTR [r15]
    7db2f94fff2d:	mov    QWORD PTR [r12+0x78],r8
    7db2f94fff32:	mov    r15,r14
    7db2f94fff35:	add    r15,0x24
    7db2f94fff39:	mov    r9d,DWORD PTR [r15]
    7db2f94fff3c:	mov    QWORD PTR [r12+0x90],r9
    7db2f94fff44:	sub    r13,0xc0
    7db2f94fff4b:	setne  BYTE PTR [rsp+0xb8]
    7db2f94fff53:	mov    r11,rax
    7db2f94fff56:	lahf
    7db2f94fff57:	seto   al
    7db2f94fff5a:	mov    WORD PTR [rsp+0xb0],ax
    7db2f94fff62:	mov    rax,r11
    7db2f94fff65:	mov    r13d,DWORD PTR [r12+0x70]
    7db2f94fff6a:	mov    r13d,r13d
    7db2f94fff6d:	mov    r13d,r13d
    7db2f94fff70:	ror    r13d,0x7
    7db2f94fff74:	mov    QWORD PTR [r12+0x80],r13
    7db2f94fff7c:	mov    r15d,r8d
    7db2f94fff7f:	mov    r15d,r15d
    7db2f94fff82:	ror    r15d,0x11
    7db2f94fff86:	mov    QWORD PTR [r12+0x88],r15
    7db2f94fff8e:	mov    ebp,DWORD PTR [r12+0x60]
    7db2f94fff93:	add    r9d,ebp
    7db2f94fff96:	mov    QWORD PTR [r12+0x60],r9
    7db2f94fff9b:	mov    ebp,DWORD PTR [r12+0x70]
    7db2f94fffa0:	mov    ebp,ebp
    7db2f94fffa2:	mov    ebp,ebp
    7db2f94fffa4:	ror    ebp,0x12
    7db2f94fffa7:	xor    r13d,ebp
    7db2f94fffaa:	mov    QWORD PTR [r12+0x80],r13
    7db2f94fffb2:	mov    ebp,r8d
    7db2f94fffb5:	mov    ebp,ebp
    7db2f94fffb7:	ror    ebp,0x13
    7db2f94fffba:	xor    r15d,ebp
    7db2f94fffbd:	mov    QWORD PTR [r12+0x88],r15
    7db2f94fffc5:	mov    ebp,DWORD PTR [r12+0x70]
    7db2f94fffca:	mov    ebp,ebp
    7db2f94fffcc:	mov    ebp,ebp
    7db2f94fffce:	shr    ebp,0x3
    7db2f94fffd1:	xor    r13d,ebp
    7db2f94fffd4:	mov    QWORD PTR [r12+0x80],r13
    7db2f94fffdc:	mov    r8d,r8d
    7db2f94fffdf:	shr    r8d,0xa
    7db2f94fffe3:	xor    r15d,r8d
    7db2f94fffe6:	mov    QWORD PTR [r12+0x78],r15
    7db2f94fffeb:	add    r9d,r13d
    7db2f94fffee:	mov    QWORD PTR [r12+0x60],r9
    7db2f94ffff3:	add    r9d,r15d
    7db2f94ffff6:	mov    QWORD PTR [r12+0x60],r9
    7db2f94ffffb:	add    r14,0x40
    7db2f94fffff:	mov    DWORD PTR [r14],r9d
    7db2f9500002:	mov    r13d,0x0
    7db2f9500008:	mov    DWORD PTR [r12+0x32c],r13d
    7db2f9500010:	mov    r13d,0x0
    7db2f9500016:	mov    ecx,DWORD PTR [r12+0x70]
    7db2f950001b:	mov    ecx,ecx
    7db2f950001d:	mov    r14d,r13d
    7db2f9500020:	or     r14d,ecx
    7db2f9500023:	mov    QWORD PTR [r12+0x60],r14
    7db2f9500028:	mov    rcx,QWORD PTR [r12+0x380]
    7db2f9500030:	jrcxz  0x7db2f9500037
    7db2f9500032:	jmp    0x7db2f950081a
    7db2f9500037:	cmp    BYTE PTR [rsp+0xb8],0x0
    7db2f950003f:	jne    0x7db2f94ffef9
    7db2f9500045:	jmp    0x7db2f950004a
    7db2f950004a:	mov    r13,QWORD PTR [r12]
    7db2f950004e:	mov    r14,r13
    7db2f9500051:	add    r14,0x4
    7db2f9500055:	mov    r15d,DWORD PTR [r13+0x0]
    7db2f9500059:	mov    ebp,DWORD PTR [r14]
    7db2f950005c:	mov    QWORD PTR [r12+0x78],r15
    7db2f9500061:	mov    QWORD PTR [r12+0x80],rbp
    7db2f9500069:	mov    r14,r13
    7db2f950006c:	add    r14,0x8
    7db2f9500070:	mov    r8,r14
    7db2f9500073:	add    r8,0x4
    7db2f9500077:	mov    r9d,DWORD PTR [r14]
    7db2f950007a:	mov    eax,DWORD PTR [r8]
    7db2f950007d:	mov    QWORD PTR [rsp+0x90],rax
    7db2f9500085:	mov    QWORD PTR [r12+0x70],r9
    7db2f950008a:	mov    rax,QWORD PTR [rsp+0x90]
    7db2f9500092:	mov    QWORD PTR [r12+0x68],rax
    7db2f9500097:	mov    r8,r13
    7db2f950009a:	add    r8,0x18
    7db2f950009e:	mov    r14,r8
    7db2f95000a1:	add    r14,0x4
    7db2f95000a5:	mov    eax,DWORD PTR [r8]
    7db2f95000a8:	mov    QWORD PTR [rsp+0x98],rax
    7db2f95000b0:	mov    r8d,DWORD PTR [r14]
    7db2f95000b3:	mov    rax,QWORD PTR [rsp+0x98]
    7db2f95000bb:	mov    QWORD PTR [r12+0x58],rax
    7db2f95000c0:	mov    QWORD PTR [r12+0x60],r8
    7db2f95000c5:	add    r13,0x10
    7db2f95000c9:	mov    r14,r13
    7db2f95000cc:	add    r14,0x4
    7db2f95000d0:	mov    eax,DWORD PTR [r13+0x0]
    7db2f95000d4:	mov    QWORD PTR [rsp+0xa0],rax
    7db2f95000dc:	mov    eax,DWORD PTR [r14]
    7db2f95000df:	mov    QWORD PTR [rsp+0xa8],rax
    7db2f95000e7:	mov    rax,QWORD PTR [rsp+0xa0]
    7db2f95000ef:	mov    QWORD PTR [r12+0x18],rax
    7db2f95000f4:	mov    rax,QWORD PTR [rsp+0xa8]
    7db2f95000fc:	mov    QWORD PTR [r12+0x90],rax
    7db2f9500104:	mov    r14d,0x0
    7db2f950010a:	mov    QWORD PTR [r12+0x88],r14
    7db2f9500112:	mov    r14d,0x0
    7db2f9500118:	mov    r13d,r14d
    7db2f950011b:	or     r13d,r15d
    7db2f950011e:	mov    QWORD PTR [r12+0xa8],r13
    7db2f9500126:	mov    r13d,0x0
    7db2f950012c:	mov    r14d,r13d
    7db2f950012f:	or     r14d,ebp
    7db2f9500132:	mov    QWORD PTR [r12+0x38],r14
    7db2f9500137:	mov    r13d,0x0
    7db2f950013d:	mov    r14d,r13d
    7db2f9500140:	or     r14d,r9d
    7db2f9500143:	mov    QWORD PTR [r12+0x98],r14
    7db2f950014b:	mov    r13d,0x0
    7db2f9500151:	mov    ecx,DWORD PTR [rsp+0x90]
    7db2f9500158:	mov    r14d,r13d
    7db2f950015b:	or     r14d,ecx
    7db2f950015e:	mov    QWORD PTR [r12+0x28],r14
    7db2f9500163:	mov    r13d,0x0
    7db2f9500169:	mov    r14d,r13d
    7db2f950016c:	or     r14d,r8d
    7db2f950016f:	mov    QWORD PTR [r12+0xb0],r14
    7db2f9500177:	mov    r13d,0x0
    7db2f950017d:	mov    ecx,DWORD PTR [rsp+0x98]
    7db2f9500184:	mov    r14d,r13d
    7db2f9500187:	or     r14d,ecx
    7db2f950018a:	mov    QWORD PTR [r12+0xc0],r14
    7db2f9500192:	mov    r13d,0x0
    7db2f9500198:	mov    ecx,DWORD PTR [rsp+0xa8]
    7db2f950019f:	mov    r14d,r13d
    7db2f95001a2:	or     r14d,ecx
    7db2f95001a5:	mov    QWORD PTR [r12+0xc8],r14
    7db2f95001ad:	mov    r13d,0x0
    7db2f95001b3:	mov    ecx,DWORD PTR [rsp+0xa0]
    7db2f95001ba:	mov    r14d,r13d
    7db2f95001bd:	or     r14d,ecx
    7db2f95001c0:	mov    QWORD PTR [r12+0xb8],r14
    7db2f95001c8:	jmp    0x7db2f95001cd
    7db2f95001cd:	mov    r13d,0x0
    7db2f95001d3:	mov    r14d,DWORD PTR [r12+0xb8]
    7db2f95001db:	mov    eax,r13d
    7db2f95001de:	or     eax,r14d
    7db2f95001e1:	mov    QWORD PTR [r12+0x30],rax
    7db2f95001e6:	mov    r13d,0x0
    7db2f95001ec:	mov    ebp,DWORD PTR [r12+0xc0]
    7db2f95001f4:	mov    eax,r13d
    7db2f95001f7:	or     eax,ebp
    7db2f95001f9:	mov    QWORD PTR [r12+0xa0],rax
    7db2f9500201:	mov    r13d,0x0
    7db2f9500207:	mov    ebp,DWORD PTR [r12+0x28]
    7db2f950020c:	mov    eax,r13d
    7db2f950020f:	or     eax,ebp
    7db2f9500211:	mov    QWORD PTR [r12+0xc0],rax
    7db2f9500219:	mov    r13d,0x0
    7db2f950021f:	mov    ebp,DWORD PTR [r12+0x98]
    7db2f9500227:	mov    eax,r13d
    7db2f950022a:	or     eax,ebp
    7db2f950022c:	mov    QWORD PTR [r12+0x28],rax
    7db2f9500231:	mov    r13d,0x0
    7db2f9500237:	mov    ebp,DWORD PTR [r12+0x38]
    7db2f950023c:	mov    eax,r13d
    7db2f950023f:	or     eax,ebp
    7db2f9500241:	mov    QWORD PTR [r12+0x98],rax
    7db2f9500249:	mov    r13d,0x0
    7db2f950024f:	mov    ebp,DWORD PTR [r12+0xa8]
    7db2f9500257:	mov    eax,r13d
    7db2f950025a:	or     eax,ebp
    7db2f950025c:	mov    QWORD PTR [r12+0x38],rax
    7db2f9500261:	mov    r14d,r14d
    7db2f9500264:	ror    r14d,0x6
    7db2f9500268:	mov    QWORD PTR [r12+0xb8],r14
    7db2f9500270:	mov    r13d,DWORD PTR [r12+0xc8]
    7db2f9500278:	mov    ebp,DWORD PTR [r12+0x30]
    7db2f950027d:	mov    ebp,ebp
    7db2f950027f:	and    ebp,r13d
    7db2f9500282:	mov    QWORD PTR [r12+0xa8],rbp
    7db2f950028a:	mov    r9d,DWORD PTR [r12+0x38]
    7db2f950028f:	mov    r9d,r9d
    7db2f9500292:	mov    r9d,r9d
    7db2f9500295:	ror    r9d,0x2
    7db2f9500299:	mov    QWORD PTR [r12+0xd0],r9
    7db2f95002a1:	mov    r15d,0x0
    7db2f95002a7:	mov    eax,r15d
    7db2f95002aa:	or     eax,r13d
    7db2f95002ad:	mov    QWORD PTR [r12+0x20],rax
    7db2f95002b2:	mov    rax,QWORD PTR [r12+0x88]
    7db2f95002ba:	mov    r15,QWORD PTR [r12+0x50]
    7db2f95002bf:	mov    rcx,QWORD PTR [r12+0x88]
    7db2f95002c7:	add    r15,rcx
    7db2f95002ca:	mov    r13d,DWORD PTR [r15]
    7db2f95002cd:	mov    QWORD PTR [r12+0xc8],r13
    7db2f95002d5:	mov    ecx,DWORD PTR [r12+0x30]
    7db2f95002da:	mov    ecx,ecx
    7db2f95002dc:	mov    r15d,DWORD PTR [r12+0xa0]
    7db2f95002e4:	mov    r15d,r15d
    7db2f95002e7:	not    rcx
    7db2f95002ea:	and    r15d,ecx
    7db2f95002ed:	mov    QWORD PTR [r12+0xd8],r15
    7db2f95002f5:	mov    r8d,DWORD PTR [r12+0xb0]
    7db2f95002fd:	add    ebp,r8d
    7db2f9500300:	mov    QWORD PTR [r12+0xa8],rbp
    7db2f9500308:	mov    r8d,DWORD PTR [r12+0x30]
    7db2f950030d:	mov    r8d,r8d
    7db2f9500310:	mov    r8d,r8d
    7db2f9500313:	ror    r8d,0xb
    7db2f9500317:	xor    r14d,r8d
    7db2f950031a:	mov    QWORD PTR [r12+0xb0],r14
    7db2f9500322:	mov    r8d,DWORD PTR [r12+0x38]
    7db2f9500327:	mov    r8d,r8d
    7db2f950032a:	mov    r8d,r8d
    7db2f950032d:	ror    r8d,0xd
    7db2f9500331:	xor    r9d,r8d
    7db2f9500334:	mov    QWORD PTR [r12+0xd0],r9
    7db2f950033c:	add    ebp,r15d
    7db2f950033f:	mov    QWORD PTR [r12+0xa8],rbp
    7db2f9500347:	mov    r15,QWORD PTR [r12+0x48]
    7db2f950034c:	mov    rcx,QWORD PTR [r12+0x88]
    7db2f9500354:	add    r15,rcx
    7db2f9500357:	mov    r8d,DWORD PTR [r15]
    7db2f950035a:	mov    QWORD PTR [r12+0xb8],r8
    7db2f9500362:	mov    ecx,DWORD PTR [r12+0x98]
    7db2f950036a:	mov    ecx,ecx
    7db2f950036c:	mov    eax,DWORD PTR [r12+0x28]
    7db2f9500371:	mov    eax,eax
    7db2f9500373:	and    eax,ecx
    7db2f9500375:	mov    QWORD PTR [r12+0xd8],rax
    7db2f950037d:	add    ebp,r13d
    7db2f9500380:	mov    QWORD PTR [r12+0xa8],rbp
    7db2f9500388:	mov    ecx,DWORD PTR [r12+0x98]
    7db2f9500390:	mov    ecx,ecx
    7db2f9500392:	mov    r13d,DWORD PTR [r12+0x28]
    7db2f9500397:	mov    r13d,r13d
    7db2f950039a:	xor    r13d,ecx
    7db2f950039d:	mov    QWORD PTR [r12+0xc8],r13
    7db2f95003a5:	mov    r15d,DWORD PTR [r12+0x30]
    7db2f95003aa:	mov    r15d,r15d
    7db2f95003ad:	mov    r15d,r15d
    7db2f95003b0:	ror    r15d,0x19
    7db2f95003b4:	xor    r14d,r15d
    7db2f95003b7:	mov    QWORD PTR [r12+0xb0],r14
    7db2f95003bf:	mov    ecx,DWORD PTR [r12+0x38]
    7db2f95003c4:	mov    ecx,ecx
    7db2f95003c6:	and    r13d,ecx
    7db2f95003c9:	mov    QWORD PTR [r12+0xc8],r13
    7db2f95003d1:	mov    r15d,DWORD PTR [r12+0x38]
    7db2f95003d6:	mov    r15d,r15d
    7db2f95003d9:	mov    r15d,r15d
    7db2f95003dc:	ror    r15d,0x16
    7db2f95003e0:	xor    r9d,r15d
    7db2f95003e3:	mov    QWORD PTR [r12+0xd0],r9
    7db2f95003eb:	add    ebp,r8d
    7db2f95003ee:	mov    QWORD PTR [r12+0xa8],rbp
    7db2f95003f6:	mov    ecx,DWORD PTR [r12+0xd8]
    7db2f95003fe:	mov    ecx,ecx
    7db2f9500400:	xor    r13d,ecx
    7db2f9500403:	mov    QWORD PTR [r12+0xb8],r13
    7db2f950040b:	add    ebp,r14d
    7db2f950040e:	mov    QWORD PTR [r12+0xa8],rbp
    7db2f9500416:	mov    r14,QWORD PTR [r12+0x88]
    7db2f950041e:	add    r14,0x4
    7db2f9500422:	mov    QWORD PTR [r12+0x88],r14
    7db2f950042a:	add    r13d,r9d
    7db2f950042d:	mov    QWORD PTR [r12+0xb0],r13
    7db2f9500435:	mov    ecx,DWORD PTR [r12+0xc0]
    7db2f950043d:	mov    ecx,ecx
    7db2f950043f:	mov    r15d,ebp
    7db2f9500442:	add    r15d,ecx
    7db2f9500445:	mov    QWORD PTR [r12+0xb8],r15
    7db2f950044d:	sub    r14,0x100
    7db2f9500454:	setne  BYTE PTR [rsp+0xb8]
    7db2f950045c:	mov    r11,rax
    7db2f950045f:	lahf
    7db2f9500460:	seto   al
    7db2f9500463:	mov    WORD PTR [rsp+0xb0],ax
    7db2f950046b:	mov    rax,r11
    7db2f950046e:	add    r13d,ebp
    7db2f9500471:	mov    QWORD PTR [r12+0xa8],r13
    7db2f9500479:	mov    r13d,0x0
    7db2f950047f:	mov    ecx,DWORD PTR [r12+0xa0]
    7db2f9500487:	mov    ecx,ecx
    7db2f9500489:	mov    r14d,r13d
    7db2f950048c:	or     r14d,ecx
    7db2f950048f:	mov    QWORD PTR [r12+0xb0],r14
    7db2f9500497:	mov    r13d,0x0
    7db2f950049d:	mov    ecx,DWORD PTR [r12+0x20]
    7db2f95004a2:	mov    ecx,ecx
    7db2f95004a4:	mov    r14d,r13d
    7db2f95004a7:	or     r14d,ecx
    7db2f95004aa:	mov    QWORD PTR [r12+0xc0],r14
    7db2f95004b2:	mov    r13d,0x0
    7db2f95004b8:	mov    ecx,DWORD PTR [r12+0x30]
    7db2f95004bd:	mov    ecx,ecx
    7db2f95004bf:	mov    r14d,r13d
    7db2f95004c2:	or     r14d,ecx
    7db2f95004c5:	mov    QWORD PTR [r12+0xc8],r14
    7db2f95004cd:	mov    rcx,QWORD PTR [r12+0x380]
    7db2f95004d5:	jrcxz  0x7db2f95004dc
    7db2f95004d7:	jmp    0x7db2f95008a2
    7db2f95004dc:	cmp    BYTE PTR [rsp+0xb8],0x0
    7db2f95004e4:	jne    0x7db2f95001cd
    7db2f95004ea:	jmp    0x7db2f95004ef
    7db2f95004ef:	mov    r13d,DWORD PTR [r12+0x70]
    7db2f95004f4:	mov    r14d,DWORD PTR [r12+0x98]
    7db2f95004fc:	add    r14d,r13d
    7db2f95004ff:	mov    QWORD PTR [r12+0x70],r14
    7db2f9500504:	mov    r13d,DWORD PTR [r12+0x68]
    7db2f9500509:	mov    r15d,DWORD PTR [r12+0x28]
    7db2f950050e:	add    r15d,r13d
    7db2f9500511:	mov    QWORD PTR [r12+0x68],r15
    7db2f9500516:	mov    r13d,0x0
    7db2f950051c:	mov    QWORD PTR [r12+0x88],r13
    7db2f9500524:	mov    r13d,DWORD PTR [r12+0x78]
    7db2f9500529:	mov    ebp,DWORD PTR [r12+0xa8]
    7db2f9500531:	add    ebp,r13d
    7db2f9500534:	mov    QWORD PTR [r12+0x78],rbp
    7db2f9500539:	mov    r13d,DWORD PTR [r12+0x80]
    7db2f9500541:	mov    r8d,DWORD PTR [r12+0x38]
    7db2f9500546:	add    r8d,r13d
    7db2f9500549:	mov    QWORD PTR [r12+0x80],r8
    7db2f9500551:	mov    rax,QWORD PTR [r12]
    7db2f9500555:	mov    r9,QWORD PTR [r12]
    7db2f9500559:	add    r9,0x8
    7db2f950055d:	mov    r13,r9
    7db2f9500560:	add    r13,0x4
    7db2f9500564:	mov    DWORD PTR [r9],r14d
    7db2f9500567:	mov    r14d,0x0
    7db2f950056d:	mov    DWORD PTR [r12+0x32c],r14d
    7db2f9500575:	mov    DWORD PTR [r13+0x0],r15d
    7db2f9500579:	mov    r13d,DWORD PTR [r12+0x18]
    7db2f950057e:	mov    r14d,DWORD PTR [r12+0xb8]
    7db2f9500586:	add    r14d,r13d
    7db2f9500589:	mov    QWORD PTR [r12+0x68],r14
    7db2f950058e:	mov    r13d,DWORD PTR [r12+0x90]
    7db2f9500596:	mov    r15d,DWORD PTR [r12+0x30]
    7db2f950059b:	add    r15d,r13d
    7db2f950059e:	mov    QWORD PTR [r12+0x70],r15
    7db2f95005a3:	mov    r13d,DWORD PTR [r12+0x58]
    7db2f95005a8:	mov    r9d,DWORD PTR [r12+0x20]
    7db2f95005ad:	mov    eax,r9d
    7db2f95005b0:	add    eax,r13d
    7db2f95005b3:	mov    QWORD PTR [r12+0x58],rax
    7db2f95005b8:	mov    r13d,DWORD PTR [r12+0x60]
    7db2f95005bd:	mov    r9d,DWORD PTR [r12+0xa0]
    7db2f95005c5:	add    r9d,r13d
    7db2f95005c8:	mov    QWORD PTR [r12+0x60],r9
    7db2f95005cd:	mov    r13,QWORD PTR [r12]
    7db2f95005d1:	add    r13,0x4
    7db2f95005d5:	mov    rdi,QWORD PTR [r12]
    7db2f95005d9:	mov    DWORD PTR [rdi],ebp
    7db2f95005db:	mov    DWORD PTR [r13+0x0],r8d
    7db2f95005df:	mov    r13,QWORD PTR [r12]
    7db2f95005e3:	add    r13,0x10
    7db2f95005e7:	mov    rbp,r13
    7db2f95005ea:	add    rbp,0x4
    7db2f95005ee:	mov    DWORD PTR [r13+0x0],r14d
    7db2f95005f2:	mov    DWORD PTR [rbp+0x0],r15d
    7db2f95005f6:	mov    r13,QWORD PTR [r12]
    7db2f95005fa:	add    r13,0x18
    7db2f95005fe:	mov    r14,r13
    7db2f9500601:	add    r14,0x4
    7db2f9500605:	mov    eax,DWORD PTR [r12+0x58]
    7db2f950060a:	mov    DWORD PTR [r13+0x0],eax
    7db2f950060e:	mov    DWORD PTR [r14],r9d
    7db2f9500611:	mov    r13,QWORD PTR [r12]
    7db2f9500615:	add    r13,0x68
    7db2f9500619:	mov    r14d,0x0
    7db2f950061f:	mov    QWORD PTR [r13+0x0],r14
    7db2f9500623:	mov    rcx,QWORD PTR [r12+0x380]
    7db2f950062b:	jrcxz  0x7db2f9500632
    7db2f950062d:	jmp    0x7db2f950092a
    7db2f9500632:	jmp    0x7db2f9500637
    7db2f9500637:	mov    r13,QWORD PTR [r12+0x10]
    7db2f950063c:	sub    r13,0x1
    7db2f9500640:	mov    QWORD PTR [r12+0x10],r13
    7db2f9500645:	mov    rax,r13
    7db2f9500648:	test   rax,rax
    7db2f950064b:	je     0x7db2f9500656
    7db2f9500651:	jmp    0x7db2f94fe75a
    7db2f9500656:	mov    r13,QWORD PTR [r12+0xf8]
    7db2f950065e:	mov    r14,r13
    7db2f9500661:	add    r14,0x140
    7db2f9500668:	mov    r15,r14
    7db2f950066b:	add    r15,0x8
    7db2f950066f:	mov    rbp,QWORD PTR [r14]
    7db2f9500672:	mov    r14,QWORD PTR [r15]
    7db2f9500675:	mov    QWORD PTR [r12+0xa0],rbp
    7db2f950067d:	mov    QWORD PTR [r12+0x98],r14
    7db2f9500685:	mov    r14,r13
    7db2f9500688:	add    r14,0x130
    7db2f950068f:	mov    r15,r14
    7db2f9500692:	add    r15,0x8
    7db2f9500696:	mov    rbp,QWORD PTR [r14]
    7db2f9500699:	mov    r14,QWORD PTR [r15]
    7db2f950069c:	mov    QWORD PTR [r12+0xb0],rbp
    7db2f95006a4:	mov    QWORD PTR [r12+0xa8],r14
    7db2f95006ac:	mov    r14,r13
    7db2f95006af:	add    r14,0x120
    7db2f95006b6:	mov    r15,r14
    7db2f95006b9:	add    r15,0x8
    7db2f95006bd:	mov    rbp,QWORD PTR [r14]
    7db2f95006c0:	mov    r14,QWORD PTR [r15]
    7db2f95006c3:	mov    QWORD PTR [r12+0xc0],rbp
    7db2f95006cb:	mov    QWORD PTR [r12+0xb8],r14
    7db2f95006d3:	mov    r14,r13
    7db2f95006d6:	add    r14,0x110
    7db2f95006dd:	mov    r15,r14
    7db2f95006e0:	add    r15,0x8
    7db2f95006e4:	mov    rbp,QWORD PTR [r14]
    7db2f95006e7:	mov    r14,QWORD PTR [r15]
    7db2f95006ea:	mov    QWORD PTR [r12+0xd0],rbp
    7db2f95006f2:	mov    QWORD PTR [r12+0xc8],r14
    7db2f95006fa:	mov    r14,r13
    7db2f95006fd:	add    r14,0x100
    7db2f9500704:	mov    r15,r14
    7db2f9500707:	add    r15,0x8
    7db2f950070b:	mov    rbp,QWORD PTR [r14]
    7db2f950070e:	mov    r14,QWORD PTR [r15]
    7db2f9500711:	mov    QWORD PTR [r12+0xe8],rbp
    7db2f9500719:	mov    QWORD PTR [r12+0xd8],r14
    7db2f9500721:	add    r13,0x150
    7db2f9500728:	mov    QWORD PTR [r12+0xf8],r13
    7db2f9500730:	jmp    0x7db2f9500735
    7db2f9500735:	mov    rcx,QWORD PTR [r12+0x380]
    7db2f950073d:	jrcxz  0x7db2f9500744
    7db2f950073f:	jmp    0x7db2f95009b2
    7db2f9500744:	mov    r13,QWORD PTR [r12+0xf0]
    7db2f950074c:	mov    QWORD PTR [r12+0x100],r13
    7db2f9500754:	mov    r11,QWORD PTR [rsp+0xb0]
    7db2f950075c:	mov    QWORD PTR [r12+0x398],r11
    7db2f9500764:	mov    rdi,QWORD PTR [r12+0x100]
    7db2f950076c:	add    rsp,0xc0
    7db2f9500773:	movabs r11,0x5a58c9ed2940
    7db2f950077d:	jmp    r11
    7db2f9500780:	mov    eax,0x410720
    7db2f9500785:	mov    QWORD PTR [r12+0x100],rax
    7db2f950078d:	push   rdx
    7db2f950078e:	push   rsi
    7db2f950078f:	push   r10
    7db2f9500791:	push   r11
    7db2f9500793:	mov    r11,rax
    7db2f9500796:	lahf
    7db2f9500797:	seto   al
    7db2f950079a:	mov    WORD PTR [rsp+0xd0],ax
    7db2f95007a2:	mov    rax,r11
    7db2f95007a5:	mov    rdx,QWORD PTR [rsp+0xd0]
    7db2f95007ad:	mov    r10d,edx
    7db2f95007b0:	and    r10d,0xc000
    7db2f95007b7:	shl    r10d,0x10
    7db2f95007bb:	mov    r11d,edx
    7db2f95007be:	and    r11d,0x100
    7db2f95007c5:	shl    r11d,0x15
    7db2f95007c9:	or     r10d,r11d
    7db2f95007cc:	and    edx,0x1
    7db2f95007cf:	shl    edx,0x1c
    7db2f95007d2:	or     r10d,edx
    7db2f95007d5:	btc    r10,0x1d
    7db2f95007da:	mov    r11d,0xf0000000
    7db2f95007e0:	and    r11,r10
    7db2f95007e3:	movabs rsi,0xffffffff0fffffff
    7db2f95007ed:	and    rbx,rsi
    7db2f95007f0:	or     rbx,r11
    7db2f95007f3:	pop    r11
    7db2f95007f5:	pop    r10
    7db2f95007f7:	pop    rsi
    7db2f95007f8:	pop    rdx
    7db2f95007f9:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9500801:	add    rsp,0xc0
    7db2f9500808:	mov    eax,0xc
    7db2f950080d:	movabs r11,0x5a58c9ed2ca0
    7db2f9500817:	jmp    r11
    7db2f950081a:	mov    eax,0x41081c
    7db2f950081f:	mov    QWORD PTR [r12+0x100],rax
    7db2f9500827:	push   rdx
    7db2f9500828:	push   rsi
    7db2f9500829:	push   r10
    7db2f950082b:	push   r11
    7db2f950082d:	mov    rdx,QWORD PTR [rsp+0xd0]
    7db2f9500835:	mov    r10d,edx
    7db2f9500838:	and    r10d,0xc000
    7db2f950083f:	shl    r10d,0x10
    7db2f9500843:	mov    r11d,edx
    7db2f9500846:	and    r11d,0x100
    7db2f950084d:	shl    r11d,0x15
    7db2f9500851:	or     r10d,r11d
    7db2f9500854:	and    edx,0x1
    7db2f9500857:	shl    edx,0x1c
    7db2f950085a:	or     r10d,edx
    7db2f950085d:	btc    r10,0x1d
    7db2f9500862:	mov    r11d,0xf0000000
    7db2f9500868:	and    r11,r10
    7db2f950086b:	movabs rsi,0xffffffff0fffffff
    7db2f9500875:	and    rbx,rsi
    7db2f9500878:	or     rbx,r11
    7db2f950087b:	pop    r11
    7db2f950087d:	pop    r10
    7db2f950087f:	pop    rsi
    7db2f9500880:	pop    rdx
    7db2f9500881:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9500889:	add    rsp,0xc0
    7db2f9500890:	mov    eax,0xc
    7db2f9500895:	movabs r11,0x5a58c9ed2ca0
    7db2f950089f:	jmp    r11
    7db2f95008a2:	mov    eax,0x4108dc
    7db2f95008a7:	mov    QWORD PTR [r12+0x100],rax
    7db2f95008af:	push   rdx
    7db2f95008b0:	push   rsi
    7db2f95008b1:	push   r10
    7db2f95008b3:	push   r11
    7db2f95008b5:	mov    rdx,QWORD PTR [rsp+0xd0]
    7db2f95008bd:	mov    r10d,edx
    7db2f95008c0:	and    r10d,0xc000
    7db2f95008c7:	shl    r10d,0x10
    7db2f95008cb:	mov    r11d,edx
    7db2f95008ce:	and    r11d,0x100
    7db2f95008d5:	shl    r11d,0x15
    7db2f95008d9:	or     r10d,r11d
    7db2f95008dc:	and    edx,0x1
    7db2f95008df:	shl    edx,0x1c
    7db2f95008e2:	or     r10d,edx
    7db2f95008e5:	btc    r10,0x1d
    7db2f95008ea:	mov    r11d,0xf0000000
    7db2f95008f0:	and    r11,r10
    7db2f95008f3:	movabs rsi,0xffffffff0fffffff
    7db2f95008fd:	and    rbx,rsi
    7db2f9500900:	or     rbx,r11
    7db2f9500903:	pop    r11
    7db2f9500905:	pop    r10
    7db2f9500907:	pop    rsi
    7db2f9500908:	pop    rdx
    7db2f9500909:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9500911:	add    rsp,0xc0
    7db2f9500918:	mov    eax,0xc
    7db2f950091d:	movabs r11,0x5a58c9ed2ca0
    7db2f9500927:	jmp    r11
    7db2f950092a:	mov    eax,0x410918
    7db2f950092f:	mov    QWORD PTR [r12+0x100],rax
    7db2f9500937:	push   rdx
    7db2f9500938:	push   rsi
    7db2f9500939:	push   r10
    7db2f950093b:	push   r11
    7db2f950093d:	mov    rdx,QWORD PTR [rsp+0xd0]
    7db2f9500945:	mov    r10d,edx
    7db2f9500948:	and    r10d,0xc000
    7db2f950094f:	shl    r10d,0x10
    7db2f9500953:	mov    r11d,edx
    7db2f9500956:	and    r11d,0x100
    7db2f950095d:	shl    r11d,0x15
    7db2f9500961:	or     r10d,r11d
    7db2f9500964:	and    edx,0x1
    7db2f9500967:	shl    edx,0x1c
    7db2f950096a:	or     r10d,edx
    7db2f950096d:	btc    r10,0x1d
    7db2f9500972:	mov    r11d,0xf0000000
    7db2f9500978:	and    r11,r10
    7db2f950097b:	movabs rsi,0xffffffff0fffffff
    7db2f9500985:	and    rbx,rsi
    7db2f9500988:	or     rbx,r11
    7db2f950098b:	pop    r11
    7db2f950098d:	pop    r10
    7db2f950098f:	pop    rsi
    7db2f9500990:	pop    rdx
    7db2f9500991:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9500999:	add    rsp,0xc0
    7db2f95009a0:	mov    eax,0xc
    7db2f95009a5:	movabs r11,0x5a58c9ed2ca0
    7db2f95009af:	jmp    r11
    7db2f95009b2:	mov    eax,0x410934
    7db2f95009b7:	mov    QWORD PTR [r12+0x100],rax
    7db2f95009bf:	push   rdx
    7db2f95009c0:	push   rsi
    7db2f95009c1:	push   r10
    7db2f95009c3:	push   r11
    7db2f95009c5:	mov    rdx,QWORD PTR [rsp+0xd0]
    7db2f95009cd:	mov    r10d,edx
    7db2f95009d0:	and    r10d,0xc000
    7db2f95009d7:	shl    r10d,0x10
    7db2f95009db:	mov    r11d,edx
    7db2f95009de:	and    r11d,0x100
    7db2f95009e5:	shl    r11d,0x15
    7db2f95009e9:	or     r10d,r11d
    7db2f95009ec:	and    edx,0x1
    7db2f95009ef:	shl    edx,0x1c
    7db2f95009f2:	or     r10d,edx
    7db2f95009f5:	btc    r10,0x1d
    7db2f95009fa:	mov    r11d,0xf0000000
    7db2f9500a00:	and    r11,r10
    7db2f9500a03:	movabs rsi,0xffffffff0fffffff
    7db2f9500a0d:	and    rbx,rsi
    7db2f9500a10:	or     rbx,r11
    7db2f9500a13:	pop    r11
    7db2f9500a15:	pop    r10
    7db2f9500a17:	pop    rsi
    7db2f9500a18:	pop    rdx
    7db2f9500a19:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9500a21:	add    rsp,0xc0
    7db2f9500a28:	mov    eax,0xc
    7db2f9500a2d:	movabs r11,0x5a58c9ed2ca0
    7db2f9500a37:	jmp    r11
    7db2f9500a3a:	nop    WORD PTR [rax+rax*1+0x0]
    7db2f9500a40:	sub    rsp,0xc0
    7db2f9500a47:	mov    r11,QWORD PTR [r12+0x398]
    7db2f9500a4f:	mov    QWORD PTR [rsp+0xb0],r11
    7db2f9500a57:	jmp    0x7db2f94fe639
    7db2f9500a5c:	nop    DWORD PTR [rax+0x0]
    7db2f9500a60:	sub    rsp,0xc0
    7db2f9500a67:	mov    r11,QWORD PTR [r12+0x398]
    7db2f9500a6f:	mov    QWORD PTR [rsp+0xb0],r11
    7db2f9500a77:	jmp    0x7db2f94fe75a
    7db2f9500a7c:	nop    DWORD PTR [rax+0x0]
    7db2f9500a80:	sub    rsp,0xc0
    7db2f9500a87:	mov    r11,QWORD PTR [r12+0x398]
    7db2f9500a8f:	mov    QWORD PTR [rsp+0xb0],r11
    7db2f9500a97:	jmp    0x7db2f94fe814
    7db2f9500a9c:	nop    DWORD PTR [rax+0x0]
    7db2f9500aa0:	sub    rsp,0xc0
    7db2f9500aa7:	mov    r11,QWORD PTR [r12+0x398]
    7db2f9500aaf:	mov    QWORD PTR [rsp+0xb0],r11
    7db2f9500ab7:	jmp    0x7db2f94ffef9
    7db2f9500abc:	nop    DWORD PTR [rax+0x0]
    7db2f9500ac0:	sub    rsp,0xc0
    7db2f9500ac7:	mov    r11,QWORD PTR [r12+0x398]
    7db2f9500acf:	mov    QWORD PTR [rsp+0xb0],r11
    7db2f9500ad7:	jmp    0x7db2f950004a
    7db2f9500adc:	nop    DWORD PTR [rax+0x0]
    7db2f9500ae0:	sub    rsp,0xc0
    7db2f9500ae7:	mov    r11,QWORD PTR [r12+0x398]
    7db2f9500aef:	mov    QWORD PTR [rsp+0xb0],r11
    7db2f9500af7:	jmp    0x7db2f95001cd
    7db2f9500afc:	nop    DWORD PTR [rax+0x0]
    7db2f9500b00:	sub    rsp,0xc0
    7db2f9500b07:	mov    r11,QWORD PTR [r12+0x398]
    7db2f9500b0f:	mov    QWORD PTR [rsp+0xb0],r11
    7db2f9500b17:	jmp    0x7db2f95004ef
    7db2f9500b1c:	nop    DWORD PTR [rax+0x0]
    7db2f9500b20:	sub    rsp,0xc0
    7db2f9500b27:	mov    r11,QWORD PTR [r12+0x398]
    7db2f9500b2f:	mov    QWORD PTR [rsp+0xb0],r11
    7db2f9500b37:	jmp    0x7db2f9500637
    7db2f9500b3c:	nop    DWORD PTR [rax+0x0]
    7db2f9500b40:	sub    rsp,0xc0
    7db2f9500b47:	mov    r11,QWORD PTR [r12+0x398]
    7db2f9500b4f:	mov    QWORD PTR [rsp+0xb0],r11
    7db2f9500b57:	jmp    0x7db2f9500656
    7db2f9500b5c:	nop    DWORD PTR [rax+0x0]
    7db2f9500b60:	sub    rsp,0xc0
    7db2f9500b67:	mov    r11,QWORD PTR [r12+0x398]
    7db2f9500b6f:	mov    QWORD PTR [rsp+0xb0],r11
    7db2f9500b77:	jmp    0x7db2f9500735
