
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/2/7.bin:     file format binary


Disassembly of section .data:

00007db2f9501900 <.data>:
    7db2f9501900:	sub    rsp,0x10
    7db2f9501904:	mov    r11,QWORD PTR [r12+0x398]
    7db2f950190c:	mov    QWORD PTR [rsp],r11
    7db2f9501910:	mov    r13,QWORD PTR [r12+0xa0]
    7db2f9501918:	mov    r14,r13
    7db2f950191b:	shl    r14,0x2
    7db2f950191f:	mov    r15,QWORD PTR [r12+0x98]
    7db2f9501927:	add    r15,r14
    7db2f950192a:	mov    r14d,DWORD PTR [r12]
    7db2f950192e:	mov    DWORD PTR [r15],r14d
    7db2f9501931:	mov    r14d,0x0
    7db2f9501937:	mov    DWORD PTR [r12+0x32c],r14d
    7db2f950193f:	add    r13,0x1
    7db2f9501943:	mov    QWORD PTR [r12+0xa0],r13
    7db2f950194b:	sub    r13,0x400
    7db2f9501952:	mov    rcx,QWORD PTR [r12+0x380]
    7db2f950195a:	jrcxz  0x7db2f9501961
    7db2f950195c:	jmp    0x7db2f9501d3d
    7db2f9501961:	jne    0x7db2f950197a
    7db2f9501967:	mov    r11,rax
    7db2f950196a:	lahf
    7db2f950196b:	seto   al
    7db2f950196e:	mov    WORD PTR [rsp],ax
    7db2f9501972:	mov    rax,r11
    7db2f9501975:	jmp    0x7db2f950198d
    7db2f950197a:	mov    r11,rax
    7db2f950197d:	lahf
    7db2f950197e:	seto   al
    7db2f9501981:	mov    WORD PTR [rsp],ax
    7db2f9501985:	mov    rax,r11
    7db2f9501988:	jmp    0x7db2f9501ccd
    7db2f950198d:	mov    r13d,0x1
    7db2f9501993:	mov    QWORD PTR [r12+0x40],r13
    7db2f9501998:	mov    r11,rax
    7db2f950199b:	movzx  eax,WORD PTR [rsp]
    7db2f950199f:	add    al,0x7f
    7db2f95019a1:	sahf
    7db2f95019a2:	mov    rax,r11
    7db2f95019a5:	jmp    0x7db2f95019aa
    7db2f95019aa:	mov    r13,QWORD PTR [r12+0x40]
    7db2f95019af:	mov    r14,r13
    7db2f95019b2:	lea    r14,[r14*4+0x0]
    7db2f95019ba:	mov    r15,QWORD PTR [r12+0x98]
    7db2f95019c2:	mov    r11,rax
    7db2f95019c5:	lahf
    7db2f95019c6:	seto   al
    7db2f95019c9:	mov    WORD PTR [rsp],ax
    7db2f95019cd:	mov    rax,r11
    7db2f95019d0:	add    r15,r14
    7db2f95019d3:	mov    r14d,DWORD PTR [r15]
    7db2f95019d6:	mov    QWORD PTR [r12+0x48],r14
    7db2f95019db:	mov    r14d,0x0
    7db2f95019e1:	or     r14,r13
    7db2f95019e4:	mov    QWORD PTR [r12+0x50],r14
    7db2f95019e9:	jmp    0x7db2f95019ee
    7db2f95019ee:	mov    r13d,DWORD PTR [r12+0x50]
    7db2f95019f3:	sub    r13d,0x1
    7db2f95019f7:	mov    QWORD PTR [r12+0x58],r13
    7db2f95019fc:	mov    ecx,0xffffffff
    7db2f9501a01:	mov    r14,r13
    7db2f9501a04:	and    r14,rcx
    7db2f9501a07:	shl    r14,0x2
    7db2f9501a0b:	mov    r13,QWORD PTR [r12+0x98]
    7db2f9501a13:	add    r13,r14
    7db2f9501a16:	mov    r14d,DWORD PTR [r13+0x0]
    7db2f9501a1a:	mov    QWORD PTR [r12+0x60],r14
    7db2f9501a1f:	mov    r13d,DWORD PTR [r12+0x48]
    7db2f9501a24:	sub    r14d,r13d
    7db2f9501a27:	mov    rcx,QWORD PTR [r12+0x380]
    7db2f9501a2f:	jrcxz  0x7db2f9501a36
    7db2f9501a31:	jmp    0x7db2f9501dce
    7db2f9501a36:	jbe    0x7db2f9501a4f
    7db2f9501a3c:	mov    r11,rax
    7db2f9501a3f:	lahf
    7db2f9501a40:	seto   al
    7db2f9501a43:	mov    WORD PTR [rsp],ax
    7db2f9501a47:	mov    rax,r11
    7db2f9501a4a:	jmp    0x7db2f9501a62
    7db2f9501a4f:	mov    r11,rax
    7db2f9501a52:	lahf
    7db2f9501a53:	seto   al
    7db2f9501a56:	mov    WORD PTR [rsp],ax
    7db2f9501a5a:	mov    rax,r11
    7db2f9501a5d:	jmp    0x7db2f9501ae1
    7db2f9501a62:	mov    r13,QWORD PTR [r12+0x50]
    7db2f9501a67:	mov    r14,r13
    7db2f9501a6a:	shl    r14,0x2
    7db2f9501a6e:	mov    r15,QWORD PTR [r12+0x98]
    7db2f9501a76:	add    r15,r14
    7db2f9501a79:	mov    r14d,DWORD PTR [r12+0x60]
    7db2f9501a7e:	mov    DWORD PTR [r15],r14d
    7db2f9501a81:	mov    r14d,0x0
    7db2f9501a87:	mov    DWORD PTR [r12+0x32c],r14d
    7db2f9501a8f:	sub    r13,0x1
    7db2f9501a93:	mov    QWORD PTR [r12+0x50],r13
    7db2f9501a98:	mov    rcx,QWORD PTR [r12+0x380]
    7db2f9501aa0:	jrcxz  0x7db2f9501aa7
    7db2f9501aa2:	jmp    0x7db2f9501e5f
    7db2f9501aa7:	mov    r13,QWORD PTR [r12+0x58]
    7db2f9501aac:	mov    rax,r13
    7db2f9501aaf:	test   rax,rax
    7db2f9501ab2:	jne    0x7db2f95019ee
    7db2f9501ab8:	jmp    0x7db2f9501abd
    7db2f9501abd:	mov    rcx,QWORD PTR [r12+0x380]
    7db2f9501ac5:	jrcxz  0x7db2f9501acc
    7db2f9501ac7:	jmp    0x7db2f9501ee1
    7db2f9501acc:	jmp    0x7db2f9501ad1
    7db2f9501ad1:	mov    r13d,0x0
    7db2f9501ad7:	mov    QWORD PTR [r12+0x50],r13
    7db2f9501adc:	jmp    0x7db2f9501ae1
    7db2f9501ae1:	mov    r13,QWORD PTR [r12+0x40]
    7db2f9501ae6:	add    r13,0x1
    7db2f9501aea:	mov    QWORD PTR [r12+0x40],r13
    7db2f9501aef:	mov    r14,QWORD PTR [r12+0x50]
    7db2f9501af4:	mov    ecx,0xffffffff
    7db2f9501af9:	and    r14,rcx
    7db2f9501afc:	shl    r14,0x2
    7db2f9501b00:	mov    r15,QWORD PTR [r12+0x98]
    7db2f9501b08:	add    r15,r14
    7db2f9501b0b:	mov    r14d,DWORD PTR [r12+0x48]
    7db2f9501b10:	mov    DWORD PTR [r15],r14d
    7db2f9501b13:	mov    r14d,0x0
    7db2f9501b19:	mov    DWORD PTR [r12+0x32c],r14d
    7db2f9501b21:	sub    r13,0x400
    7db2f9501b28:	jne    0x7db2f95019aa
    7db2f9501b2e:	mov    r11,rax
    7db2f9501b31:	lahf
    7db2f9501b32:	seto   al
    7db2f9501b35:	mov    WORD PTR [rsp],ax
    7db2f9501b39:	mov    rax,r11
    7db2f9501b3c:	jmp    0x7db2f9501b41
    7db2f9501b41:	mov    r13d,0x430000
    7db2f9501b47:	mov    QWORD PTR [r12+0x40],r13
    7db2f9501b4c:	mov    r13d,0x0
    7db2f9501b52:	mov    QWORD PTR [r12+0x58],r13
    7db2f9501b57:	mov    r13d,0x0
    7db2f9501b5d:	mov    QWORD PTR [r12+0x50],r13
    7db2f9501b62:	mov    r13d,0x430c40
    7db2f9501b68:	mov    r14,QWORD PTR [r13+0x0]
    7db2f9501b6c:	mov    QWORD PTR [r12+0x48],r14
    7db2f9501b71:	jmp    0x7db2f9501b76
    7db2f9501b76:	mov    r13,QWORD PTR [r12+0x58]
    7db2f9501b7b:	mov    r14,r13
    7db2f9501b7e:	shl    r14,0x2
    7db2f9501b82:	mov    r15,QWORD PTR [r12+0x98]
    7db2f9501b8a:	add    r15,r14
    7db2f9501b8d:	mov    QWORD PTR [r12+0x60],r15
    7db2f9501b92:	mov    r14,r15
    7db2f9501b95:	add    r14,0x4
    7db2f9501b99:	mov    ebp,DWORD PTR [r15]
    7db2f9501b9c:	mov    r15d,DWORD PTR [r14]
    7db2f9501b9f:	mov    QWORD PTR [r12+0x60],r15
    7db2f9501ba4:	mov    r14,rbp
    7db2f9501ba7:	imul   r14,r13
    7db2f9501bab:	mov    r8,rbp
    7db2f9501bae:	add    r8,r14
    7db2f9501bb1:	mov    QWORD PTR [r12+0x68],r8
    7db2f9501bb6:	add    r13,0x2
    7db2f9501bba:	mov    QWORD PTR [r12+0x58],r13
    7db2f9501bbf:	mov    r14,r13
    7db2f9501bc2:	sub    r14,0x400
    7db2f9501bc9:	mov    r14,QWORD PTR [r12+0x50]
    7db2f9501bce:	setne  BYTE PTR [rsp+0x8]
    7db2f9501bd3:	mov    r11,rax
    7db2f9501bd6:	lahf
    7db2f9501bd7:	seto   al
    7db2f9501bda:	mov    WORD PTR [rsp],ax
    7db2f9501bde:	mov    rax,r11
    7db2f9501be1:	imul   r13,r15
    7db2f9501be5:	add    r14,r13
    7db2f9501be8:	mov    QWORD PTR [r12+0x50],r14
    7db2f9501bed:	mov    r13,QWORD PTR [r12+0x48]
    7db2f9501bf2:	add    r8,r13
    7db2f9501bf5:	mov    QWORD PTR [r12+0x48],r8
    7db2f9501bfa:	mov    rcx,QWORD PTR [r12+0x380]
    7db2f9501c02:	jrcxz  0x7db2f9501c09
    7db2f9501c04:	jmp    0x7db2f9501f63
    7db2f9501c09:	cmp    BYTE PTR [rsp+0x8],0x0
    7db2f9501c0e:	jne    0x7db2f9501b76
    7db2f9501c14:	jmp    0x7db2f9501c19
    7db2f9501c19:	mov    r13d,0x0
    7db2f9501c1f:	mov    QWORD PTR [r12+0x98],r13
    7db2f9501c27:	mov    r13,QWORD PTR [r12+0x48]
    7db2f9501c2c:	mov    r14,QWORD PTR [r12+0x50]
    7db2f9501c31:	add    r14,r13
    7db2f9501c34:	mov    QWORD PTR [r12+0x48],r14
    7db2f9501c39:	mov    r13d,0x1
    7db2f9501c3f:	mov    QWORD PTR [r12],r13
    7db2f9501c43:	mov    r13,QWORD PTR [r12+0x40]
    7db2f9501c48:	add    r13,0xc40
    7db2f9501c4f:	mov    QWORD PTR [r13+0x0],r14
    7db2f9501c53:	mov    r13d,0x0
    7db2f9501c59:	mov    DWORD PTR [r12+0x32c],r13d
    7db2f9501c61:	mov    r13d,0x1
    7db2f9501c67:	mov    QWORD PTR [r12],r13
    7db2f9501c6b:	mov    r13d,0x4103e8
    7db2f9501c71:	mov    QWORD PTR [r12+0xf0],r13
    7db2f9501c79:	mov    r13d,0x410938
    7db2f9501c7f:	mov    QWORD PTR [r12+0x100],r13
    7db2f9501c87:	mov    r11,QWORD PTR [rsp]
    7db2f9501c8b:	mov    QWORD PTR [r12+0x398],r11
    7db2f9501c93:	mov    edi,0x410938
    7db2f9501c98:	mov    QWORD PTR [r12+0x100],rdi
    7db2f9501ca0:	add    rsp,0x10
    7db2f9501ca4:	nop    DWORD PTR [rax+0x0]
    7db2f9501ca8:	jmp    QWORD PTR [rip+0x2]        # 0x7db2f9501cb0
    7db2f9501cae:	xchg   ax,ax
    7db2f9501cb0:	xor    BYTE PTR [rdi],dl
    7db2f9501cb2:	push   rax
    7db2f9501cb3:	stc
    7db2f9501cb4:	mov    dl,0x7d
    7db2f9501cb6:	add    BYTE PTR [rax],al
    7db2f9501cb8:	rcr    BYTE PTR [rax+rdx*2],0xf9
    7db2f9501cbc:	mov    dl,0x7d
    7db2f9501cbe:	add    BYTE PTR [rax],al
    7db2f9501cc0:	movabs r11,0x5a58c9ed2940
    7db2f9501cca:	jmp    r11
    7db2f9501ccd:	mov    r13d,DWORD PTR [r12+0xa0]
    7db2f9501cd5:	add    r13d,0x11
    7db2f9501cd9:	mov    QWORD PTR [r12],r13
    7db2f9501cdd:	mov    r13d,0x41034c
    7db2f9501ce3:	mov    QWORD PTR [r12+0xf0],r13
    7db2f9501ceb:	mov    r13d,0x410938
    7db2f9501cf1:	mov    QWORD PTR [r12+0x100],r13
    7db2f9501cf9:	mov    r11,QWORD PTR [rsp]
    7db2f9501cfd:	mov    QWORD PTR [r12+0x398],r11
    7db2f9501d05:	mov    edi,0x410938
    7db2f9501d0a:	mov    QWORD PTR [r12+0x100],rdi
    7db2f9501d12:	add    rsp,0x10
    7db2f9501d16:	xchg   ax,ax
    7db2f9501d18:	jmp    QWORD PTR [rip+0x2]        # 0x7db2f9501d20
    7db2f9501d1e:	xchg   ax,ax
    7db2f9501d20:	xor    BYTE PTR [rdi],dl
    7db2f9501d22:	push   rax
    7db2f9501d23:	stc
    7db2f9501d24:	mov    dl,0x7d
    7db2f9501d26:	add    BYTE PTR [rax],al
    7db2f9501d28:	xor    BYTE PTR [rip+0x7db2f950],bl        # 0x7db37703167e
    7db2f9501d2e:	add    BYTE PTR [rax],al
    7db2f9501d30:	movabs r11,0x5a58c9ed2940
    7db2f9501d3a:	jmp    r11
    7db2f9501d3d:	mov    eax,0x410358
    7db2f9501d42:	mov    QWORD PTR [r12+0x100],rax
    7db2f9501d4a:	push   rdx
    7db2f9501d4b:	push   rsi
    7db2f9501d4c:	push   r10
    7db2f9501d4e:	push   r11
    7db2f9501d50:	mov    r11,rax
    7db2f9501d53:	lahf
    7db2f9501d54:	seto   al
    7db2f9501d57:	mov    WORD PTR [rsp+0x20],ax
    7db2f9501d5c:	mov    rax,r11
    7db2f9501d5f:	mov    rdx,QWORD PTR [rsp+0x20]
    7db2f9501d64:	mov    r10d,edx
    7db2f9501d67:	and    r10d,0xc000
    7db2f9501d6e:	shl    r10d,0x10
    7db2f9501d72:	mov    r11d,edx
    7db2f9501d75:	and    r11d,0x100
    7db2f9501d7c:	shl    r11d,0x15
    7db2f9501d80:	or     r10d,r11d
    7db2f9501d83:	and    edx,0x1
    7db2f9501d86:	shl    edx,0x1c
    7db2f9501d89:	or     r10d,edx
    7db2f9501d8c:	btc    r10,0x1d
    7db2f9501d91:	mov    r11d,0xf0000000
    7db2f9501d97:	and    r11,r10
    7db2f9501d9a:	movabs rsi,0xffffffff0fffffff
    7db2f9501da4:	and    rbx,rsi
    7db2f9501da7:	or     rbx,r11
    7db2f9501daa:	pop    r11
    7db2f9501dac:	pop    r10
    7db2f9501dae:	pop    rsi
    7db2f9501daf:	pop    rdx
    7db2f9501db0:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9501db8:	add    rsp,0x10
    7db2f9501dbc:	mov    eax,0xc
    7db2f9501dc1:	movabs r11,0x5a58c9ed2ca0
    7db2f9501dcb:	jmp    r11
    7db2f9501dce:	mov    eax,0x41038c
    7db2f9501dd3:	mov    QWORD PTR [r12+0x100],rax
    7db2f9501ddb:	push   rdx
    7db2f9501ddc:	push   rsi
    7db2f9501ddd:	push   r10
    7db2f9501ddf:	push   r11
    7db2f9501de1:	mov    r11,rax
    7db2f9501de4:	lahf
    7db2f9501de5:	seto   al
    7db2f9501de8:	mov    WORD PTR [rsp+0x20],ax
    7db2f9501ded:	mov    rax,r11
    7db2f9501df0:	mov    rdx,QWORD PTR [rsp+0x20]
    7db2f9501df5:	mov    r10d,edx
    7db2f9501df8:	and    r10d,0xc000
    7db2f9501dff:	shl    r10d,0x10
    7db2f9501e03:	mov    r11d,edx
    7db2f9501e06:	and    r11d,0x100
    7db2f9501e0d:	shl    r11d,0x15
    7db2f9501e11:	or     r10d,r11d
    7db2f9501e14:	and    edx,0x1
    7db2f9501e17:	shl    edx,0x1c
    7db2f9501e1a:	or     r10d,edx
    7db2f9501e1d:	btc    r10,0x1d
    7db2f9501e22:	mov    r11d,0xf0000000
    7db2f9501e28:	and    r11,r10
    7db2f9501e2b:	movabs rsi,0xffffffff0fffffff
    7db2f9501e35:	and    rbx,rsi
    7db2f9501e38:	or     rbx,r11
    7db2f9501e3b:	pop    r11
    7db2f9501e3d:	pop    r10
    7db2f9501e3f:	pop    rsi
    7db2f9501e40:	pop    rdx
    7db2f9501e41:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9501e49:	add    rsp,0x10
    7db2f9501e4d:	mov    eax,0xc
    7db2f9501e52:	movabs r11,0x5a58c9ed2ca0
    7db2f9501e5c:	jmp    r11
    7db2f9501e5f:	mov    eax,0x410398
    7db2f9501e64:	mov    QWORD PTR [r12+0x100],rax
    7db2f9501e6c:	push   rdx
    7db2f9501e6d:	push   rsi
    7db2f9501e6e:	push   r10
    7db2f9501e70:	push   r11
    7db2f9501e72:	mov    rdx,QWORD PTR [rsp+0x20]
    7db2f9501e77:	mov    r10d,edx
    7db2f9501e7a:	and    r10d,0xc000
    7db2f9501e81:	shl    r10d,0x10
    7db2f9501e85:	mov    r11d,edx
    7db2f9501e88:	and    r11d,0x100
    7db2f9501e8f:	shl    r11d,0x15
    7db2f9501e93:	or     r10d,r11d
    7db2f9501e96:	and    edx,0x1
    7db2f9501e99:	shl    edx,0x1c
    7db2f9501e9c:	or     r10d,edx
    7db2f9501e9f:	btc    r10,0x1d
    7db2f9501ea4:	mov    r11d,0xf0000000
    7db2f9501eaa:	and    r11,r10
    7db2f9501ead:	movabs rsi,0xffffffff0fffffff
    7db2f9501eb7:	and    rbx,rsi
    7db2f9501eba:	or     rbx,r11
    7db2f9501ebd:	pop    r11
    7db2f9501ebf:	pop    r10
    7db2f9501ec1:	pop    rsi
    7db2f9501ec2:	pop    rdx
    7db2f9501ec3:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9501ecb:	add    rsp,0x10
    7db2f9501ecf:	mov    eax,0xc
    7db2f9501ed4:	movabs r11,0x5a58c9ed2ca0
    7db2f9501ede:	jmp    r11
    7db2f9501ee1:	mov    eax,0x41039c
    7db2f9501ee6:	mov    QWORD PTR [r12+0x100],rax
    7db2f9501eee:	push   rdx
    7db2f9501eef:	push   rsi
    7db2f9501ef0:	push   r10
    7db2f9501ef2:	push   r11
    7db2f9501ef4:	mov    rdx,QWORD PTR [rsp+0x20]
    7db2f9501ef9:	mov    r10d,edx
    7db2f9501efc:	and    r10d,0xc000
    7db2f9501f03:	shl    r10d,0x10
    7db2f9501f07:	mov    r11d,edx
    7db2f9501f0a:	and    r11d,0x100
    7db2f9501f11:	shl    r11d,0x15
    7db2f9501f15:	or     r10d,r11d
    7db2f9501f18:	and    edx,0x1
    7db2f9501f1b:	shl    edx,0x1c
    7db2f9501f1e:	or     r10d,edx
    7db2f9501f21:	btc    r10,0x1d
    7db2f9501f26:	mov    r11d,0xf0000000
    7db2f9501f2c:	and    r11,r10
    7db2f9501f2f:	movabs rsi,0xffffffff0fffffff
    7db2f9501f39:	and    rbx,rsi
    7db2f9501f3c:	or     rbx,r11
    7db2f9501f3f:	pop    r11
    7db2f9501f41:	pop    r10
    7db2f9501f43:	pop    rsi
    7db2f9501f44:	pop    rdx
    7db2f9501f45:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9501f4d:	add    rsp,0x10
    7db2f9501f51:	mov    eax,0xc
    7db2f9501f56:	movabs r11,0x5a58c9ed2ca0
    7db2f9501f60:	jmp    r11
    7db2f9501f63:	mov    eax,0x4103cc
    7db2f9501f68:	mov    QWORD PTR [r12+0x100],rax
    7db2f9501f70:	push   rdx
    7db2f9501f71:	push   rsi
    7db2f9501f72:	push   r10
    7db2f9501f74:	push   r11
    7db2f9501f76:	mov    rdx,QWORD PTR [rsp+0x20]
    7db2f9501f7b:	mov    r10d,edx
    7db2f9501f7e:	and    r10d,0xc000
    7db2f9501f85:	shl    r10d,0x10
    7db2f9501f89:	mov    r11d,edx
    7db2f9501f8c:	and    r11d,0x100
    7db2f9501f93:	shl    r11d,0x15
    7db2f9501f97:	or     r10d,r11d
    7db2f9501f9a:	and    edx,0x1
    7db2f9501f9d:	shl    edx,0x1c
    7db2f9501fa0:	or     r10d,edx
    7db2f9501fa3:	btc    r10,0x1d
    7db2f9501fa8:	mov    r11d,0xf0000000
    7db2f9501fae:	and    r11,r10
    7db2f9501fb1:	movabs rsi,0xffffffff0fffffff
    7db2f9501fbb:	and    rbx,rsi
    7db2f9501fbe:	or     rbx,r11
    7db2f9501fc1:	pop    r11
    7db2f9501fc3:	pop    r10
    7db2f9501fc5:	pop    rsi
    7db2f9501fc6:	pop    rdx
    7db2f9501fc7:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9501fcf:	add    rsp,0x10
    7db2f9501fd3:	mov    eax,0xc
    7db2f9501fd8:	movabs r11,0x5a58c9ed2ca0
    7db2f9501fe2:	jmp    r11
    7db2f9501fe5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7db2f9501ff0:	sub    rsp,0x10
    7db2f9501ff4:	mov    r11,QWORD PTR [r12+0x398]
    7db2f9501ffc:	mov    QWORD PTR [rsp],r11
    7db2f9502000:	jmp    0x7db2f950198d
    7db2f9502005:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7db2f9502010:	sub    rsp,0x10
    7db2f9502014:	mov    r11,QWORD PTR [r12+0x398]
    7db2f950201c:	mov    QWORD PTR [rsp],r11
    7db2f9502020:	mov    r11,rax
    7db2f9502023:	movzx  eax,WORD PTR [rsp]
    7db2f9502027:	add    al,0x7f
    7db2f9502029:	sahf
    7db2f950202a:	mov    rax,r11
    7db2f950202d:	jmp    0x7db2f95019aa
    7db2f9502032:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7db2f9502040:	sub    rsp,0x10
    7db2f9502044:	mov    r11,QWORD PTR [r12+0x398]
    7db2f950204c:	mov    QWORD PTR [rsp],r11
    7db2f9502050:	jmp    0x7db2f95019ee
    7db2f9502055:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7db2f9502060:	sub    rsp,0x10
    7db2f9502064:	mov    r11,QWORD PTR [r12+0x398]
    7db2f950206c:	mov    QWORD PTR [rsp],r11
    7db2f9502070:	jmp    0x7db2f9501a62
    7db2f9502075:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7db2f9502080:	sub    rsp,0x10
    7db2f9502084:	mov    r11,QWORD PTR [r12+0x398]
    7db2f950208c:	mov    QWORD PTR [rsp],r11
    7db2f9502090:	jmp    0x7db2f9501abd
    7db2f9502095:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7db2f95020a0:	sub    rsp,0x10
    7db2f95020a4:	mov    r11,QWORD PTR [r12+0x398]
    7db2f95020ac:	mov    QWORD PTR [rsp],r11
    7db2f95020b0:	jmp    0x7db2f9501ad1
    7db2f95020b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7db2f95020c0:	sub    rsp,0x10
    7db2f95020c4:	mov    r11,QWORD PTR [r12+0x398]
    7db2f95020cc:	mov    QWORD PTR [rsp],r11
    7db2f95020d0:	jmp    0x7db2f9501ae1
    7db2f95020d5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7db2f95020e0:	sub    rsp,0x10
    7db2f95020e4:	mov    r11,QWORD PTR [r12+0x398]
    7db2f95020ec:	mov    QWORD PTR [rsp],r11
    7db2f95020f0:	jmp    0x7db2f9501b41
    7db2f95020f5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7db2f9502100:	sub    rsp,0x10
    7db2f9502104:	mov    r11,QWORD PTR [r12+0x398]
    7db2f950210c:	mov    QWORD PTR [rsp],r11
    7db2f9502110:	jmp    0x7db2f9501b76
    7db2f9502115:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7db2f9502120:	sub    rsp,0x10
    7db2f9502124:	mov    r11,QWORD PTR [r12+0x398]
    7db2f950212c:	mov    QWORD PTR [rsp],r11
    7db2f9502130:	jmp    0x7db2f9501c19
    7db2f9502135:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7db2f9502140:	sub    rsp,0x10
    7db2f9502144:	mov    r11,QWORD PTR [r12+0x398]
    7db2f950214c:	mov    QWORD PTR [rsp],r11
    7db2f9502150:	jmp    0x7db2f9501ccd
    7db2f9502155:	nop
    7db2f9502156:	nop
    7db2f9502157:	nop
