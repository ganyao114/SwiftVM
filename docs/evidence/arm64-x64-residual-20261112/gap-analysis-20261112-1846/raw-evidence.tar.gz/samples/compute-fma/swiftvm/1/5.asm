
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/1/5.bin:     file format binary


Disassembly of section .data:

000072fde4f01220 <.data>:
    72fde4f01220:	sub    rsp,0x30
    72fde4f01224:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f0122c:	mov    QWORD PTR [rsp+0x18],r11
    72fde4f01231:	mov    rax,QWORD PTR [r12+0xf8]
    72fde4f01239:	mov    r14,QWORD PTR [r12+0xf8]
    72fde4f01241:	add    r14,0xd0
    72fde4f01248:	mov    r15,r14
    72fde4f0124b:	add    r15,0x4
    72fde4f0124f:	mov    ebp,DWORD PTR [r14]
    72fde4f01252:	mov    r14d,DWORD PTR [r15]
    72fde4f01255:	mov    QWORD PTR [r12+0x40],rbp
    72fde4f0125a:	mov    QWORD PTR [r12+0x50],r14
    72fde4f0125f:	mov    r15,QWORD PTR [r12+0xf8]
    72fde4f01267:	add    r15,0xd8
    72fde4f0126e:	mov    r8,r15
    72fde4f01271:	add    r8,0x4
    72fde4f01275:	mov    r9d,DWORD PTR [r15]
    72fde4f01278:	mov    eax,DWORD PTR [r8]
    72fde4f0127b:	mov    QWORD PTR [rsp],rax
    72fde4f0127f:	mov    QWORD PTR [r12+0x58],r9
    72fde4f01284:	mov    rax,QWORD PTR [rsp]
    72fde4f01288:	mov    QWORD PTR [r12+0x60],rax
    72fde4f0128d:	mov    r8d,0x430c20
    72fde4f01293:	mov    QWORD PTR [r12+0x48],r8
    72fde4f01298:	mov    r8d,0x0
    72fde4f0129e:	mov    QWORD PTR [r12+0xa0],r8
    72fde4f012a6:	movabs rcx,0xff00ff00ff00ff
    72fde4f012b0:	mov    r8,rbp
    72fde4f012b3:	and    r8,rcx
    72fde4f012b6:	shl    r8,0x8
    72fde4f012ba:	movabs rcx,0xff00ff00ff00ff00
    72fde4f012c4:	mov    r13,rbp
    72fde4f012c7:	and    r13,rcx
    72fde4f012ca:	shr    r13,0x8
    72fde4f012ce:	or     r13,r8
    72fde4f012d1:	movabs rcx,0xffff0000ffff
    72fde4f012db:	mov    rbp,r13
    72fde4f012de:	and    rbp,rcx
    72fde4f012e1:	shl    rbp,0x10
    72fde4f012e5:	movabs rcx,0xffff0000ffff0000
    72fde4f012ef:	and    r13,rcx
    72fde4f012f2:	shr    r13,0x10
    72fde4f012f6:	or     r13,rbp
    72fde4f012f9:	mov    ecx,0xffffffff
    72fde4f012fe:	and    r13,rcx
    72fde4f01301:	mov    QWORD PTR [r12+0x40],r13
    72fde4f01306:	movabs rcx,0xff00ff00ff00ff
    72fde4f01310:	mov    rbp,r14
    72fde4f01313:	and    rbp,rcx
    72fde4f01316:	shl    rbp,0x8
    72fde4f0131a:	movabs rcx,0xff00ff00ff00ff00
    72fde4f01324:	mov    r8,r14
    72fde4f01327:	and    r8,rcx
    72fde4f0132a:	shr    r8,0x8
    72fde4f0132e:	or     r8,rbp
    72fde4f01331:	movabs rcx,0xffff0000ffff
    72fde4f0133b:	mov    r14,r8
    72fde4f0133e:	and    r14,rcx
    72fde4f01341:	shl    r14,0x10
    72fde4f01345:	movabs rcx,0xffff0000ffff0000
    72fde4f0134f:	and    r8,rcx
    72fde4f01352:	shr    r8,0x10
    72fde4f01356:	or     r8,r14
    72fde4f01359:	mov    ecx,0xffffffff
    72fde4f0135e:	and    r8,rcx
    72fde4f01361:	mov    QWORD PTR [r12+0x50],r8
    72fde4f01366:	mov    r14d,0x430000
    72fde4f0136c:	add    r14,0xd8c
    72fde4f01373:	mov    QWORD PTR [r12+0x98],r14
    72fde4f0137b:	mov    r14d,0x430c20
    72fde4f01381:	mov    ebp,0x430c24
    72fde4f01386:	mov    rax,r13
    72fde4f01389:	mov    eax,eax
    72fde4f0138b:	mov    r15d,eax
    72fde4f0138e:	mov    rax,r8
    72fde4f01391:	mov    eax,eax
    72fde4f01393:	mov    r13d,eax
    72fde4f01396:	mov    DWORD PTR [r14],r15d
    72fde4f01399:	mov    r14d,0x0
    72fde4f0139f:	mov    DWORD PTR [r12+0x32c],r14d
    72fde4f013a7:	mov    DWORD PTR [rbp+0x0],r13d
    72fde4f013ab:	movabs rcx,0xff00ff00ff00ff
    72fde4f013b5:	mov    r13,r9
    72fde4f013b8:	and    r13,rcx
    72fde4f013bb:	shl    r13,0x8
    72fde4f013bf:	movabs rcx,0xff00ff00ff00ff00
    72fde4f013c9:	mov    r14,r9
    72fde4f013cc:	and    r14,rcx
    72fde4f013cf:	shr    r14,0x8
    72fde4f013d3:	or     r14,r13
    72fde4f013d6:	movabs rcx,0xffff0000ffff
    72fde4f013e0:	mov    r13,r14
    72fde4f013e3:	and    r13,rcx
    72fde4f013e6:	shl    r13,0x10
    72fde4f013ea:	movabs rcx,0xffff0000ffff0000
    72fde4f013f4:	and    r14,rcx
    72fde4f013f7:	shr    r14,0x10
    72fde4f013fb:	or     r14,r13
    72fde4f013fe:	mov    ecx,0xffffffff
    72fde4f01403:	and    r14,rcx
    72fde4f01406:	mov    QWORD PTR [r12+0x40],r14
    72fde4f0140b:	movabs rcx,0xff00ff00ff00ff
    72fde4f01415:	mov    r13,QWORD PTR [rsp]
    72fde4f01419:	and    r13,rcx
    72fde4f0141c:	shl    r13,0x8
    72fde4f01420:	movabs rcx,0xff00ff00ff00ff00
    72fde4f0142a:	mov    r15,QWORD PTR [rsp]
    72fde4f0142e:	and    r15,rcx
    72fde4f01431:	shr    r15,0x8
    72fde4f01435:	or     r15,r13
    72fde4f01438:	movabs rcx,0xffff0000ffff
    72fde4f01442:	mov    r13,r15
    72fde4f01445:	and    r13,rcx
    72fde4f01448:	shl    r13,0x10
    72fde4f0144c:	movabs rcx,0xffff0000ffff0000
    72fde4f01456:	and    r15,rcx
    72fde4f01459:	shr    r15,0x10
    72fde4f0145d:	or     r15,r13
    72fde4f01460:	mov    ecx,0xffffffff
    72fde4f01465:	and    r15,rcx
    72fde4f01468:	mov    QWORD PTR [r12+0x58],r15
    72fde4f0146d:	mov    r13,QWORD PTR [r12+0xf8]
    72fde4f01475:	add    r13,0xe0
    72fde4f0147c:	mov    rbp,r13
    72fde4f0147f:	add    rbp,0x4
    72fde4f01483:	mov    r8d,DWORD PTR [r13+0x0]
    72fde4f01487:	mov    eax,DWORD PTR [rbp+0x0]
    72fde4f0148a:	mov    QWORD PTR [rsp+0x8],rax
    72fde4f0148f:	mov    QWORD PTR [r12+0x50],r8
    72fde4f01494:	mov    rax,QWORD PTR [rsp+0x8]
    72fde4f01499:	mov    QWORD PTR [r12+0x60],rax
    72fde4f0149e:	mov    ebp,0x430c28
    72fde4f014a3:	mov    r9d,0x430c2c
    72fde4f014a9:	mov    rax,r14
    72fde4f014ac:	mov    eax,eax
    72fde4f014ae:	mov    r13d,eax
    72fde4f014b1:	mov    rax,r15
    72fde4f014b4:	mov    eax,eax
    72fde4f014b6:	mov    r14d,eax
    72fde4f014b9:	mov    DWORD PTR [rbp+0x0],r13d
    72fde4f014bd:	mov    DWORD PTR [r9],r14d
    72fde4f014c0:	movabs rcx,0xff00ff00ff00ff
    72fde4f014ca:	mov    r13,r8
    72fde4f014cd:	and    r13,rcx
    72fde4f014d0:	shl    r13,0x8
    72fde4f014d4:	movabs rcx,0xff00ff00ff00ff00
    72fde4f014de:	mov    r14,r8
    72fde4f014e1:	and    r14,rcx
    72fde4f014e4:	shr    r14,0x8
    72fde4f014e8:	or     r14,r13
    72fde4f014eb:	movabs rcx,0xffff0000ffff
    72fde4f014f5:	mov    r13,r14
    72fde4f014f8:	and    r13,rcx
    72fde4f014fb:	shl    r13,0x10
    72fde4f014ff:	movabs rcx,0xffff0000ffff0000
    72fde4f01509:	and    r14,rcx
    72fde4f0150c:	shr    r14,0x10
    72fde4f01510:	or     r14,r13
    72fde4f01513:	mov    ecx,0xffffffff
    72fde4f01518:	and    r14,rcx
    72fde4f0151b:	mov    QWORD PTR [r12+0x40],r14
    72fde4f01520:	movabs rcx,0xff00ff00ff00ff
    72fde4f0152a:	mov    r13,QWORD PTR [rsp+0x8]
    72fde4f0152f:	and    r13,rcx
    72fde4f01532:	shl    r13,0x8
    72fde4f01536:	movabs rcx,0xff00ff00ff00ff00
    72fde4f01540:	mov    r15,QWORD PTR [rsp+0x8]
    72fde4f01545:	and    r15,rcx
    72fde4f01548:	shr    r15,0x8
    72fde4f0154c:	or     r15,r13
    72fde4f0154f:	movabs rcx,0xffff0000ffff
    72fde4f01559:	mov    r13,r15
    72fde4f0155c:	and    r13,rcx
    72fde4f0155f:	shl    r13,0x10
    72fde4f01563:	movabs rcx,0xffff0000ffff0000
    72fde4f0156d:	and    r15,rcx
    72fde4f01570:	shr    r15,0x10
    72fde4f01574:	or     r15,r13
    72fde4f01577:	mov    ecx,0xffffffff
    72fde4f0157c:	and    r15,rcx
    72fde4f0157f:	mov    QWORD PTR [r12+0x58],r15
    72fde4f01584:	mov    r13,QWORD PTR [r12+0xf8]
    72fde4f0158c:	add    r13,0xe8
    72fde4f01593:	mov    rbp,r13
    72fde4f01596:	add    rbp,0x4
    72fde4f0159a:	mov    r8d,DWORD PTR [r13+0x0]
    72fde4f0159e:	mov    eax,DWORD PTR [rbp+0x0]
    72fde4f015a1:	mov    QWORD PTR [rsp+0x10],rax
    72fde4f015a6:	mov    QWORD PTR [r12+0x50],r8
    72fde4f015ab:	mov    rax,QWORD PTR [rsp+0x10]
    72fde4f015b0:	mov    QWORD PTR [r12+0x60],rax
    72fde4f015b5:	mov    ebp,0x430c30
    72fde4f015ba:	mov    r9d,0x430c34
    72fde4f015c0:	mov    rax,r14
    72fde4f015c3:	mov    eax,eax
    72fde4f015c5:	mov    r13d,eax
    72fde4f015c8:	mov    rax,r15
    72fde4f015cb:	mov    eax,eax
    72fde4f015cd:	mov    r14d,eax
    72fde4f015d0:	mov    DWORD PTR [rbp+0x0],r13d
    72fde4f015d4:	mov    DWORD PTR [r9],r14d
    72fde4f015d7:	movabs rcx,0xff00ff00ff00ff
    72fde4f015e1:	mov    r13,r8
    72fde4f015e4:	and    r13,rcx
    72fde4f015e7:	shl    r13,0x8
    72fde4f015eb:	movabs rcx,0xff00ff00ff00ff00
    72fde4f015f5:	mov    r14,r8
    72fde4f015f8:	and    r14,rcx
    72fde4f015fb:	shr    r14,0x8
    72fde4f015ff:	or     r14,r13
    72fde4f01602:	movabs rcx,0xffff0000ffff
    72fde4f0160c:	mov    r13,r14
    72fde4f0160f:	and    r13,rcx
    72fde4f01612:	shl    r13,0x10
    72fde4f01616:	movabs rcx,0xffff0000ffff0000
    72fde4f01620:	and    r14,rcx
    72fde4f01623:	shr    r14,0x10
    72fde4f01627:	or     r14,r13
    72fde4f0162a:	mov    ecx,0xffffffff
    72fde4f0162f:	and    r14,rcx
    72fde4f01632:	mov    QWORD PTR [r12+0x40],r14
    72fde4f01637:	movabs rcx,0xff00ff00ff00ff
    72fde4f01641:	mov    r13,QWORD PTR [rsp+0x10]
    72fde4f01646:	and    r13,rcx
    72fde4f01649:	shl    r13,0x8
    72fde4f0164d:	movabs rcx,0xff00ff00ff00ff00
    72fde4f01657:	mov    r15,QWORD PTR [rsp+0x10]
    72fde4f0165c:	and    r15,rcx
    72fde4f0165f:	shr    r15,0x8
    72fde4f01663:	or     r15,r13
    72fde4f01666:	movabs rcx,0xffff0000ffff
    72fde4f01670:	mov    r13,r15
    72fde4f01673:	and    r13,rcx
    72fde4f01676:	shl    r13,0x10
    72fde4f0167a:	movabs rcx,0xffff0000ffff0000
    72fde4f01684:	and    r15,rcx
    72fde4f01687:	shr    r15,0x10
    72fde4f0168b:	or     r15,r13
    72fde4f0168e:	mov    ecx,0xffffffff
    72fde4f01693:	and    r15,rcx
    72fde4f01696:	mov    QWORD PTR [r12+0x50],r15
    72fde4f0169b:	mov    r13d,0x430c38
    72fde4f016a1:	mov    ebp,0x430c3c
    72fde4f016a6:	mov    rax,r14
    72fde4f016a9:	mov    eax,eax
    72fde4f016ab:	mov    r8d,eax
    72fde4f016ae:	mov    rax,r15
    72fde4f016b1:	mov    eax,eax
    72fde4f016b3:	mov    r14d,eax
    72fde4f016b6:	mov    DWORD PTR [r13+0x0],r8d
    72fde4f016ba:	mov    DWORD PTR [rbp+0x0],r14d
    72fde4f016be:	mov    r13d,0x11
    72fde4f016c4:	mov    QWORD PTR [r12],r13
    72fde4f016c8:	mov    r13d,0x41034c
    72fde4f016ce:	mov    QWORD PTR [r12+0xf0],r13
    72fde4f016d6:	mov    r13d,0x410938
    72fde4f016dc:	mov    QWORD PTR [r12+0x100],r13
    72fde4f016e4:	mov    r11,QWORD PTR [rsp+0x18]
    72fde4f016e9:	mov    QWORD PTR [r12+0x398],r11
    72fde4f016f1:	mov    edi,0x410938
    72fde4f016f6:	mov    QWORD PTR [r12+0x100],rdi
    72fde4f016fe:	add    rsp,0x30
    72fde4f01702:	nop    WORD PTR [rax+rax*1+0x0]
    72fde4f01708:	jmp    QWORD PTR [rip+0x2]        # 0x72fde4f01710
    72fde4f0170e:	xchg   ax,ax
    72fde4f01710:	xor    BYTE PTR [rdi],dl
    72fde4f01712:	lock in al,0xfd
    72fde4f01715:	jb     0x72fde4f01717
    72fde4f01717:	add    BYTE PTR [rax],ah
    72fde4f01719:	(bad)
    72fde4f0171a:	lock in al,0xfd
    72fde4f0171d:	jb     0x72fde4f0171f
    72fde4f0171f:	add    BYTE PTR [rcx-0x45],cl
    72fde4f01722:	rex or ebp,esi
    72fde4f01725:	sahf
    72fde4f01726:	int    0x5c
    72fde4f01728:	add    BYTE PTR [rax],al
    72fde4f0172a:	jmp    r11
    72fde4f0172d:	nop
    72fde4f0172e:	nop
    72fde4f0172f:	nop
