
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/0/7.bin:     file format binary


Disassembly of section .data:

00007076cdd01900 <.data>:
    7076cdd01900:	sub    rsp,0x10
    7076cdd01904:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd0190c:	mov    QWORD PTR [rsp],r11
    7076cdd01910:	mov    r13,QWORD PTR [r12+0xa0]
    7076cdd01918:	mov    r14,r13
    7076cdd0191b:	shl    r14,0x2
    7076cdd0191f:	mov    r15,QWORD PTR [r12+0x98]
    7076cdd01927:	add    r15,r14
    7076cdd0192a:	mov    r14d,DWORD PTR [r12]
    7076cdd0192e:	mov    DWORD PTR [r15],r14d
    7076cdd01931:	mov    r14d,0x0
    7076cdd01937:	mov    DWORD PTR [r12+0x32c],r14d
    7076cdd0193f:	add    r13,0x1
    7076cdd01943:	mov    QWORD PTR [r12+0xa0],r13
    7076cdd0194b:	sub    r13,0x400
    7076cdd01952:	mov    rcx,QWORD PTR [r12+0x380]
    7076cdd0195a:	jrcxz  0x7076cdd01961
    7076cdd0195c:	jmp    0x7076cdd01d3d
    7076cdd01961:	jne    0x7076cdd0197a
    7076cdd01967:	mov    r11,rax
    7076cdd0196a:	lahf
    7076cdd0196b:	seto   al
    7076cdd0196e:	mov    WORD PTR [rsp],ax
    7076cdd01972:	mov    rax,r11
    7076cdd01975:	jmp    0x7076cdd0198d
    7076cdd0197a:	mov    r11,rax
    7076cdd0197d:	lahf
    7076cdd0197e:	seto   al
    7076cdd01981:	mov    WORD PTR [rsp],ax
    7076cdd01985:	mov    rax,r11
    7076cdd01988:	jmp    0x7076cdd01ccd
    7076cdd0198d:	mov    r13d,0x1
    7076cdd01993:	mov    QWORD PTR [r12+0x40],r13
    7076cdd01998:	mov    r11,rax
    7076cdd0199b:	movzx  eax,WORD PTR [rsp]
    7076cdd0199f:	add    al,0x7f
    7076cdd019a1:	sahf
    7076cdd019a2:	mov    rax,r11
    7076cdd019a5:	jmp    0x7076cdd019aa
    7076cdd019aa:	mov    r13,QWORD PTR [r12+0x40]
    7076cdd019af:	mov    r14,r13
    7076cdd019b2:	lea    r14,[r14*4+0x0]
    7076cdd019ba:	mov    r15,QWORD PTR [r12+0x98]
    7076cdd019c2:	mov    r11,rax
    7076cdd019c5:	lahf
    7076cdd019c6:	seto   al
    7076cdd019c9:	mov    WORD PTR [rsp],ax
    7076cdd019cd:	mov    rax,r11
    7076cdd019d0:	add    r15,r14
    7076cdd019d3:	mov    r14d,DWORD PTR [r15]
    7076cdd019d6:	mov    QWORD PTR [r12+0x48],r14
    7076cdd019db:	mov    r14d,0x0
    7076cdd019e1:	or     r14,r13
    7076cdd019e4:	mov    QWORD PTR [r12+0x50],r14
    7076cdd019e9:	jmp    0x7076cdd019ee
    7076cdd019ee:	mov    r13d,DWORD PTR [r12+0x50]
    7076cdd019f3:	sub    r13d,0x1
    7076cdd019f7:	mov    QWORD PTR [r12+0x58],r13
    7076cdd019fc:	mov    ecx,0xffffffff
    7076cdd01a01:	mov    r14,r13
    7076cdd01a04:	and    r14,rcx
    7076cdd01a07:	shl    r14,0x2
    7076cdd01a0b:	mov    r13,QWORD PTR [r12+0x98]
    7076cdd01a13:	add    r13,r14
    7076cdd01a16:	mov    r14d,DWORD PTR [r13+0x0]
    7076cdd01a1a:	mov    QWORD PTR [r12+0x60],r14
    7076cdd01a1f:	mov    r13d,DWORD PTR [r12+0x48]
    7076cdd01a24:	sub    r14d,r13d
    7076cdd01a27:	mov    rcx,QWORD PTR [r12+0x380]
    7076cdd01a2f:	jrcxz  0x7076cdd01a36
    7076cdd01a31:	jmp    0x7076cdd01dce
    7076cdd01a36:	jbe    0x7076cdd01a4f
    7076cdd01a3c:	mov    r11,rax
    7076cdd01a3f:	lahf
    7076cdd01a40:	seto   al
    7076cdd01a43:	mov    WORD PTR [rsp],ax
    7076cdd01a47:	mov    rax,r11
    7076cdd01a4a:	jmp    0x7076cdd01a62
    7076cdd01a4f:	mov    r11,rax
    7076cdd01a52:	lahf
    7076cdd01a53:	seto   al
    7076cdd01a56:	mov    WORD PTR [rsp],ax
    7076cdd01a5a:	mov    rax,r11
    7076cdd01a5d:	jmp    0x7076cdd01ae1
    7076cdd01a62:	mov    r13,QWORD PTR [r12+0x50]
    7076cdd01a67:	mov    r14,r13
    7076cdd01a6a:	shl    r14,0x2
    7076cdd01a6e:	mov    r15,QWORD PTR [r12+0x98]
    7076cdd01a76:	add    r15,r14
    7076cdd01a79:	mov    r14d,DWORD PTR [r12+0x60]
    7076cdd01a7e:	mov    DWORD PTR [r15],r14d
    7076cdd01a81:	mov    r14d,0x0
    7076cdd01a87:	mov    DWORD PTR [r12+0x32c],r14d
    7076cdd01a8f:	sub    r13,0x1
    7076cdd01a93:	mov    QWORD PTR [r12+0x50],r13
    7076cdd01a98:	mov    rcx,QWORD PTR [r12+0x380]
    7076cdd01aa0:	jrcxz  0x7076cdd01aa7
    7076cdd01aa2:	jmp    0x7076cdd01e5f
    7076cdd01aa7:	mov    r13,QWORD PTR [r12+0x58]
    7076cdd01aac:	mov    rax,r13
    7076cdd01aaf:	test   rax,rax
    7076cdd01ab2:	jne    0x7076cdd019ee
    7076cdd01ab8:	jmp    0x7076cdd01abd
    7076cdd01abd:	mov    rcx,QWORD PTR [r12+0x380]
    7076cdd01ac5:	jrcxz  0x7076cdd01acc
    7076cdd01ac7:	jmp    0x7076cdd01ee1
    7076cdd01acc:	jmp    0x7076cdd01ad1
    7076cdd01ad1:	mov    r13d,0x0
    7076cdd01ad7:	mov    QWORD PTR [r12+0x50],r13
    7076cdd01adc:	jmp    0x7076cdd01ae1
    7076cdd01ae1:	mov    r13,QWORD PTR [r12+0x40]
    7076cdd01ae6:	add    r13,0x1
    7076cdd01aea:	mov    QWORD PTR [r12+0x40],r13
    7076cdd01aef:	mov    r14,QWORD PTR [r12+0x50]
    7076cdd01af4:	mov    ecx,0xffffffff
    7076cdd01af9:	and    r14,rcx
    7076cdd01afc:	shl    r14,0x2
    7076cdd01b00:	mov    r15,QWORD PTR [r12+0x98]
    7076cdd01b08:	add    r15,r14
    7076cdd01b0b:	mov    r14d,DWORD PTR [r12+0x48]
    7076cdd01b10:	mov    DWORD PTR [r15],r14d
    7076cdd01b13:	mov    r14d,0x0
    7076cdd01b19:	mov    DWORD PTR [r12+0x32c],r14d
    7076cdd01b21:	sub    r13,0x400
    7076cdd01b28:	jne    0x7076cdd019aa
    7076cdd01b2e:	mov    r11,rax
    7076cdd01b31:	lahf
    7076cdd01b32:	seto   al
    7076cdd01b35:	mov    WORD PTR [rsp],ax
    7076cdd01b39:	mov    rax,r11
    7076cdd01b3c:	jmp    0x7076cdd01b41
    7076cdd01b41:	mov    r13d,0x430000
    7076cdd01b47:	mov    QWORD PTR [r12+0x40],r13
    7076cdd01b4c:	mov    r13d,0x0
    7076cdd01b52:	mov    QWORD PTR [r12+0x58],r13
    7076cdd01b57:	mov    r13d,0x0
    7076cdd01b5d:	mov    QWORD PTR [r12+0x50],r13
    7076cdd01b62:	mov    r13d,0x430c40
    7076cdd01b68:	mov    r14,QWORD PTR [r13+0x0]
    7076cdd01b6c:	mov    QWORD PTR [r12+0x48],r14
    7076cdd01b71:	jmp    0x7076cdd01b76
    7076cdd01b76:	mov    r13,QWORD PTR [r12+0x58]
    7076cdd01b7b:	mov    r14,r13
    7076cdd01b7e:	shl    r14,0x2
    7076cdd01b82:	mov    r15,QWORD PTR [r12+0x98]
    7076cdd01b8a:	add    r15,r14
    7076cdd01b8d:	mov    QWORD PTR [r12+0x60],r15
    7076cdd01b92:	mov    r14,r15
    7076cdd01b95:	add    r14,0x4
    7076cdd01b99:	mov    ebp,DWORD PTR [r15]
    7076cdd01b9c:	mov    r15d,DWORD PTR [r14]
    7076cdd01b9f:	mov    QWORD PTR [r12+0x60],r15
    7076cdd01ba4:	mov    r14,rbp
    7076cdd01ba7:	imul   r14,r13
    7076cdd01bab:	mov    r8,rbp
    7076cdd01bae:	add    r8,r14
    7076cdd01bb1:	mov    QWORD PTR [r12+0x68],r8
    7076cdd01bb6:	add    r13,0x2
    7076cdd01bba:	mov    QWORD PTR [r12+0x58],r13
    7076cdd01bbf:	mov    r14,r13
    7076cdd01bc2:	sub    r14,0x400
    7076cdd01bc9:	mov    r14,QWORD PTR [r12+0x50]
    7076cdd01bce:	setne  BYTE PTR [rsp+0x8]
    7076cdd01bd3:	mov    r11,rax
    7076cdd01bd6:	lahf
    7076cdd01bd7:	seto   al
    7076cdd01bda:	mov    WORD PTR [rsp],ax
    7076cdd01bde:	mov    rax,r11
    7076cdd01be1:	imul   r13,r15
    7076cdd01be5:	add    r14,r13
    7076cdd01be8:	mov    QWORD PTR [r12+0x50],r14
    7076cdd01bed:	mov    r13,QWORD PTR [r12+0x48]
    7076cdd01bf2:	add    r8,r13
    7076cdd01bf5:	mov    QWORD PTR [r12+0x48],r8
    7076cdd01bfa:	mov    rcx,QWORD PTR [r12+0x380]
    7076cdd01c02:	jrcxz  0x7076cdd01c09
    7076cdd01c04:	jmp    0x7076cdd01f63
    7076cdd01c09:	cmp    BYTE PTR [rsp+0x8],0x0
    7076cdd01c0e:	jne    0x7076cdd01b76
    7076cdd01c14:	jmp    0x7076cdd01c19
    7076cdd01c19:	mov    r13d,0x0
    7076cdd01c1f:	mov    QWORD PTR [r12+0x98],r13
    7076cdd01c27:	mov    r13,QWORD PTR [r12+0x48]
    7076cdd01c2c:	mov    r14,QWORD PTR [r12+0x50]
    7076cdd01c31:	add    r14,r13
    7076cdd01c34:	mov    QWORD PTR [r12+0x48],r14
    7076cdd01c39:	mov    r13d,0x1
    7076cdd01c3f:	mov    QWORD PTR [r12],r13
    7076cdd01c43:	mov    r13,QWORD PTR [r12+0x40]
    7076cdd01c48:	add    r13,0xc40
    7076cdd01c4f:	mov    QWORD PTR [r13+0x0],r14
    7076cdd01c53:	mov    r13d,0x0
    7076cdd01c59:	mov    DWORD PTR [r12+0x32c],r13d
    7076cdd01c61:	mov    r13d,0x1
    7076cdd01c67:	mov    QWORD PTR [r12],r13
    7076cdd01c6b:	mov    r13d,0x4103e8
    7076cdd01c71:	mov    QWORD PTR [r12+0xf0],r13
    7076cdd01c79:	mov    r13d,0x410938
    7076cdd01c7f:	mov    QWORD PTR [r12+0x100],r13
    7076cdd01c87:	mov    r11,QWORD PTR [rsp]
    7076cdd01c8b:	mov    QWORD PTR [r12+0x398],r11
    7076cdd01c93:	mov    edi,0x410938
    7076cdd01c98:	mov    QWORD PTR [r12+0x100],rdi
    7076cdd01ca0:	add    rsp,0x10
    7076cdd01ca4:	nop    DWORD PTR [rax+0x0]
    7076cdd01ca8:	jmp    QWORD PTR [rip+0x2]        # 0x7076cdd01cb0
    7076cdd01cae:	xchg   ax,ax
    7076cdd01cb0:	xor    BYTE PTR [rdi],dl
    7076cdd01cb2:	ror    ch,1
    7076cdd01cb4:	jbe    0x7076cdd01d26
    7076cdd01cb6:	add    BYTE PTR [rax],al
    7076cdd01cb8:	rcr    BYTE PTR [rax+rdx*8],0xcd
    7076cdd01cbc:	jbe    0x7076cdd01d2e
    7076cdd01cbe:	add    BYTE PTR [rax],al
    7076cdd01cc0:	movabs r11,0x5b61e73e9940
    7076cdd01cca:	jmp    r11
    7076cdd01ccd:	mov    r13d,DWORD PTR [r12+0xa0]
    7076cdd01cd5:	add    r13d,0x11
    7076cdd01cd9:	mov    QWORD PTR [r12],r13
    7076cdd01cdd:	mov    r13d,0x41034c
    7076cdd01ce3:	mov    QWORD PTR [r12+0xf0],r13
    7076cdd01ceb:	mov    r13d,0x410938
    7076cdd01cf1:	mov    QWORD PTR [r12+0x100],r13
    7076cdd01cf9:	mov    r11,QWORD PTR [rsp]
    7076cdd01cfd:	mov    QWORD PTR [r12+0x398],r11
    7076cdd01d05:	mov    edi,0x410938
    7076cdd01d0a:	mov    QWORD PTR [r12+0x100],rdi
    7076cdd01d12:	add    rsp,0x10
    7076cdd01d16:	xchg   ax,ax
    7076cdd01d18:	jmp    QWORD PTR [rip+0x2]        # 0x7076cdd01d20
    7076cdd01d1e:	xchg   ax,ax
    7076cdd01d20:	xor    BYTE PTR [rdi],dl
    7076cdd01d22:	ror    ch,1
    7076cdd01d24:	jbe    0x7076cdd01d96
    7076cdd01d26:	add    BYTE PTR [rax],al
    7076cdd01d28:	xor    BYTE PTR [rip+0x7076cdd0],bl        # 0x70773e46eafe
    7076cdd01d2e:	add    BYTE PTR [rax],al
    7076cdd01d30:	movabs r11,0x5b61e73e9940
    7076cdd01d3a:	jmp    r11
    7076cdd01d3d:	mov    eax,0x410358
    7076cdd01d42:	mov    QWORD PTR [r12+0x100],rax
    7076cdd01d4a:	push   rdx
    7076cdd01d4b:	push   rsi
    7076cdd01d4c:	push   r10
    7076cdd01d4e:	push   r11
    7076cdd01d50:	mov    r11,rax
    7076cdd01d53:	lahf
    7076cdd01d54:	seto   al
    7076cdd01d57:	mov    WORD PTR [rsp+0x20],ax
    7076cdd01d5c:	mov    rax,r11
    7076cdd01d5f:	mov    rdx,QWORD PTR [rsp+0x20]
    7076cdd01d64:	mov    r10d,edx
    7076cdd01d67:	and    r10d,0xc000
    7076cdd01d6e:	shl    r10d,0x10
    7076cdd01d72:	mov    r11d,edx
    7076cdd01d75:	and    r11d,0x100
    7076cdd01d7c:	shl    r11d,0x15
    7076cdd01d80:	or     r10d,r11d
    7076cdd01d83:	and    edx,0x1
    7076cdd01d86:	shl    edx,0x1c
    7076cdd01d89:	or     r10d,edx
    7076cdd01d8c:	btc    r10,0x1d
    7076cdd01d91:	mov    r11d,0xf0000000
    7076cdd01d97:	and    r11,r10
    7076cdd01d9a:	movabs rsi,0xffffffff0fffffff
    7076cdd01da4:	and    rbx,rsi
    7076cdd01da7:	or     rbx,r11
    7076cdd01daa:	pop    r11
    7076cdd01dac:	pop    r10
    7076cdd01dae:	pop    rsi
    7076cdd01daf:	pop    rdx
    7076cdd01db0:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd01db8:	add    rsp,0x10
    7076cdd01dbc:	mov    eax,0xc
    7076cdd01dc1:	movabs r11,0x5b61e73e9ca0
    7076cdd01dcb:	jmp    r11
    7076cdd01dce:	mov    eax,0x41038c
    7076cdd01dd3:	mov    QWORD PTR [r12+0x100],rax
    7076cdd01ddb:	push   rdx
    7076cdd01ddc:	push   rsi
    7076cdd01ddd:	push   r10
    7076cdd01ddf:	push   r11
    7076cdd01de1:	mov    r11,rax
    7076cdd01de4:	lahf
    7076cdd01de5:	seto   al
    7076cdd01de8:	mov    WORD PTR [rsp+0x20],ax
    7076cdd01ded:	mov    rax,r11
    7076cdd01df0:	mov    rdx,QWORD PTR [rsp+0x20]
    7076cdd01df5:	mov    r10d,edx
    7076cdd01df8:	and    r10d,0xc000
    7076cdd01dff:	shl    r10d,0x10
    7076cdd01e03:	mov    r11d,edx
    7076cdd01e06:	and    r11d,0x100
    7076cdd01e0d:	shl    r11d,0x15
    7076cdd01e11:	or     r10d,r11d
    7076cdd01e14:	and    edx,0x1
    7076cdd01e17:	shl    edx,0x1c
    7076cdd01e1a:	or     r10d,edx
    7076cdd01e1d:	btc    r10,0x1d
    7076cdd01e22:	mov    r11d,0xf0000000
    7076cdd01e28:	and    r11,r10
    7076cdd01e2b:	movabs rsi,0xffffffff0fffffff
    7076cdd01e35:	and    rbx,rsi
    7076cdd01e38:	or     rbx,r11
    7076cdd01e3b:	pop    r11
    7076cdd01e3d:	pop    r10
    7076cdd01e3f:	pop    rsi
    7076cdd01e40:	pop    rdx
    7076cdd01e41:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd01e49:	add    rsp,0x10
    7076cdd01e4d:	mov    eax,0xc
    7076cdd01e52:	movabs r11,0x5b61e73e9ca0
    7076cdd01e5c:	jmp    r11
    7076cdd01e5f:	mov    eax,0x410398
    7076cdd01e64:	mov    QWORD PTR [r12+0x100],rax
    7076cdd01e6c:	push   rdx
    7076cdd01e6d:	push   rsi
    7076cdd01e6e:	push   r10
    7076cdd01e70:	push   r11
    7076cdd01e72:	mov    rdx,QWORD PTR [rsp+0x20]
    7076cdd01e77:	mov    r10d,edx
    7076cdd01e7a:	and    r10d,0xc000
    7076cdd01e81:	shl    r10d,0x10
    7076cdd01e85:	mov    r11d,edx
    7076cdd01e88:	and    r11d,0x100
    7076cdd01e8f:	shl    r11d,0x15
    7076cdd01e93:	or     r10d,r11d
    7076cdd01e96:	and    edx,0x1
    7076cdd01e99:	shl    edx,0x1c
    7076cdd01e9c:	or     r10d,edx
    7076cdd01e9f:	btc    r10,0x1d
    7076cdd01ea4:	mov    r11d,0xf0000000
    7076cdd01eaa:	and    r11,r10
    7076cdd01ead:	movabs rsi,0xffffffff0fffffff
    7076cdd01eb7:	and    rbx,rsi
    7076cdd01eba:	or     rbx,r11
    7076cdd01ebd:	pop    r11
    7076cdd01ebf:	pop    r10
    7076cdd01ec1:	pop    rsi
    7076cdd01ec2:	pop    rdx
    7076cdd01ec3:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd01ecb:	add    rsp,0x10
    7076cdd01ecf:	mov    eax,0xc
    7076cdd01ed4:	movabs r11,0x5b61e73e9ca0
    7076cdd01ede:	jmp    r11
    7076cdd01ee1:	mov    eax,0x41039c
    7076cdd01ee6:	mov    QWORD PTR [r12+0x100],rax
    7076cdd01eee:	push   rdx
    7076cdd01eef:	push   rsi
    7076cdd01ef0:	push   r10
    7076cdd01ef2:	push   r11
    7076cdd01ef4:	mov    rdx,QWORD PTR [rsp+0x20]
    7076cdd01ef9:	mov    r10d,edx
    7076cdd01efc:	and    r10d,0xc000
    7076cdd01f03:	shl    r10d,0x10
    7076cdd01f07:	mov    r11d,edx
    7076cdd01f0a:	and    r11d,0x100
    7076cdd01f11:	shl    r11d,0x15
    7076cdd01f15:	or     r10d,r11d
    7076cdd01f18:	and    edx,0x1
    7076cdd01f1b:	shl    edx,0x1c
    7076cdd01f1e:	or     r10d,edx
    7076cdd01f21:	btc    r10,0x1d
    7076cdd01f26:	mov    r11d,0xf0000000
    7076cdd01f2c:	and    r11,r10
    7076cdd01f2f:	movabs rsi,0xffffffff0fffffff
    7076cdd01f39:	and    rbx,rsi
    7076cdd01f3c:	or     rbx,r11
    7076cdd01f3f:	pop    r11
    7076cdd01f41:	pop    r10
    7076cdd01f43:	pop    rsi
    7076cdd01f44:	pop    rdx
    7076cdd01f45:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd01f4d:	add    rsp,0x10
    7076cdd01f51:	mov    eax,0xc
    7076cdd01f56:	movabs r11,0x5b61e73e9ca0
    7076cdd01f60:	jmp    r11
    7076cdd01f63:	mov    eax,0x4103cc
    7076cdd01f68:	mov    QWORD PTR [r12+0x100],rax
    7076cdd01f70:	push   rdx
    7076cdd01f71:	push   rsi
    7076cdd01f72:	push   r10
    7076cdd01f74:	push   r11
    7076cdd01f76:	mov    rdx,QWORD PTR [rsp+0x20]
    7076cdd01f7b:	mov    r10d,edx
    7076cdd01f7e:	and    r10d,0xc000
    7076cdd01f85:	shl    r10d,0x10
    7076cdd01f89:	mov    r11d,edx
    7076cdd01f8c:	and    r11d,0x100
    7076cdd01f93:	shl    r11d,0x15
    7076cdd01f97:	or     r10d,r11d
    7076cdd01f9a:	and    edx,0x1
    7076cdd01f9d:	shl    edx,0x1c
    7076cdd01fa0:	or     r10d,edx
    7076cdd01fa3:	btc    r10,0x1d
    7076cdd01fa8:	mov    r11d,0xf0000000
    7076cdd01fae:	and    r11,r10
    7076cdd01fb1:	movabs rsi,0xffffffff0fffffff
    7076cdd01fbb:	and    rbx,rsi
    7076cdd01fbe:	or     rbx,r11
    7076cdd01fc1:	pop    r11
    7076cdd01fc3:	pop    r10
    7076cdd01fc5:	pop    rsi
    7076cdd01fc6:	pop    rdx
    7076cdd01fc7:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd01fcf:	add    rsp,0x10
    7076cdd01fd3:	mov    eax,0xc
    7076cdd01fd8:	movabs r11,0x5b61e73e9ca0
    7076cdd01fe2:	jmp    r11
    7076cdd01fe5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7076cdd01ff0:	sub    rsp,0x10
    7076cdd01ff4:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd01ffc:	mov    QWORD PTR [rsp],r11
    7076cdd02000:	jmp    0x7076cdd0198d
    7076cdd02005:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7076cdd02010:	sub    rsp,0x10
    7076cdd02014:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd0201c:	mov    QWORD PTR [rsp],r11
    7076cdd02020:	mov    r11,rax
    7076cdd02023:	movzx  eax,WORD PTR [rsp]
    7076cdd02027:	add    al,0x7f
    7076cdd02029:	sahf
    7076cdd0202a:	mov    rax,r11
    7076cdd0202d:	jmp    0x7076cdd019aa
    7076cdd02032:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7076cdd02040:	sub    rsp,0x10
    7076cdd02044:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd0204c:	mov    QWORD PTR [rsp],r11
    7076cdd02050:	jmp    0x7076cdd019ee
    7076cdd02055:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7076cdd02060:	sub    rsp,0x10
    7076cdd02064:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd0206c:	mov    QWORD PTR [rsp],r11
    7076cdd02070:	jmp    0x7076cdd01a62
    7076cdd02075:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7076cdd02080:	sub    rsp,0x10
    7076cdd02084:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd0208c:	mov    QWORD PTR [rsp],r11
    7076cdd02090:	jmp    0x7076cdd01abd
    7076cdd02095:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7076cdd020a0:	sub    rsp,0x10
    7076cdd020a4:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd020ac:	mov    QWORD PTR [rsp],r11
    7076cdd020b0:	jmp    0x7076cdd01ad1
    7076cdd020b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7076cdd020c0:	sub    rsp,0x10
    7076cdd020c4:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd020cc:	mov    QWORD PTR [rsp],r11
    7076cdd020d0:	jmp    0x7076cdd01ae1
    7076cdd020d5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7076cdd020e0:	sub    rsp,0x10
    7076cdd020e4:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd020ec:	mov    QWORD PTR [rsp],r11
    7076cdd020f0:	jmp    0x7076cdd01b41
    7076cdd020f5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7076cdd02100:	sub    rsp,0x10
    7076cdd02104:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd0210c:	mov    QWORD PTR [rsp],r11
    7076cdd02110:	jmp    0x7076cdd01b76
    7076cdd02115:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7076cdd02120:	sub    rsp,0x10
    7076cdd02124:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd0212c:	mov    QWORD PTR [rsp],r11
    7076cdd02130:	jmp    0x7076cdd01c19
    7076cdd02135:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7076cdd02140:	sub    rsp,0x10
    7076cdd02144:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd0214c:	mov    QWORD PTR [rsp],r11
    7076cdd02150:	jmp    0x7076cdd01ccd
    7076cdd02155:	nop
    7076cdd02156:	nop
    7076cdd02157:	nop
