
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/0/5.bin:     file format binary


Disassembly of section .data:

00007076cdd01220 <.data>:
    7076cdd01220:	sub    rsp,0x30
    7076cdd01224:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd0122c:	mov    QWORD PTR [rsp+0x18],r11
    7076cdd01231:	mov    rax,QWORD PTR [r12+0xf8]
    7076cdd01239:	mov    r14,QWORD PTR [r12+0xf8]
    7076cdd01241:	add    r14,0xd0
    7076cdd01248:	mov    r15,r14
    7076cdd0124b:	add    r15,0x4
    7076cdd0124f:	mov    ebp,DWORD PTR [r14]
    7076cdd01252:	mov    r14d,DWORD PTR [r15]
    7076cdd01255:	mov    QWORD PTR [r12+0x40],rbp
    7076cdd0125a:	mov    QWORD PTR [r12+0x50],r14
    7076cdd0125f:	mov    r15,QWORD PTR [r12+0xf8]
    7076cdd01267:	add    r15,0xd8
    7076cdd0126e:	mov    r8,r15
    7076cdd01271:	add    r8,0x4
    7076cdd01275:	mov    r9d,DWORD PTR [r15]
    7076cdd01278:	mov    eax,DWORD PTR [r8]
    7076cdd0127b:	mov    QWORD PTR [rsp],rax
    7076cdd0127f:	mov    QWORD PTR [r12+0x58],r9
    7076cdd01284:	mov    rax,QWORD PTR [rsp]
    7076cdd01288:	mov    QWORD PTR [r12+0x60],rax
    7076cdd0128d:	mov    r8d,0x430c20
    7076cdd01293:	mov    QWORD PTR [r12+0x48],r8
    7076cdd01298:	mov    r8d,0x0
    7076cdd0129e:	mov    QWORD PTR [r12+0xa0],r8
    7076cdd012a6:	movabs rcx,0xff00ff00ff00ff
    7076cdd012b0:	mov    r8,rbp
    7076cdd012b3:	and    r8,rcx
    7076cdd012b6:	shl    r8,0x8
    7076cdd012ba:	movabs rcx,0xff00ff00ff00ff00
    7076cdd012c4:	mov    r13,rbp
    7076cdd012c7:	and    r13,rcx
    7076cdd012ca:	shr    r13,0x8
    7076cdd012ce:	or     r13,r8
    7076cdd012d1:	movabs rcx,0xffff0000ffff
    7076cdd012db:	mov    rbp,r13
    7076cdd012de:	and    rbp,rcx
    7076cdd012e1:	shl    rbp,0x10
    7076cdd012e5:	movabs rcx,0xffff0000ffff0000
    7076cdd012ef:	and    r13,rcx
    7076cdd012f2:	shr    r13,0x10
    7076cdd012f6:	or     r13,rbp
    7076cdd012f9:	mov    ecx,0xffffffff
    7076cdd012fe:	and    r13,rcx
    7076cdd01301:	mov    QWORD PTR [r12+0x40],r13
    7076cdd01306:	movabs rcx,0xff00ff00ff00ff
    7076cdd01310:	mov    rbp,r14
    7076cdd01313:	and    rbp,rcx
    7076cdd01316:	shl    rbp,0x8
    7076cdd0131a:	movabs rcx,0xff00ff00ff00ff00
    7076cdd01324:	mov    r8,r14
    7076cdd01327:	and    r8,rcx
    7076cdd0132a:	shr    r8,0x8
    7076cdd0132e:	or     r8,rbp
    7076cdd01331:	movabs rcx,0xffff0000ffff
    7076cdd0133b:	mov    r14,r8
    7076cdd0133e:	and    r14,rcx
    7076cdd01341:	shl    r14,0x10
    7076cdd01345:	movabs rcx,0xffff0000ffff0000
    7076cdd0134f:	and    r8,rcx
    7076cdd01352:	shr    r8,0x10
    7076cdd01356:	or     r8,r14
    7076cdd01359:	mov    ecx,0xffffffff
    7076cdd0135e:	and    r8,rcx
    7076cdd01361:	mov    QWORD PTR [r12+0x50],r8
    7076cdd01366:	mov    r14d,0x430000
    7076cdd0136c:	add    r14,0xd8c
    7076cdd01373:	mov    QWORD PTR [r12+0x98],r14
    7076cdd0137b:	mov    r14d,0x430c20
    7076cdd01381:	mov    ebp,0x430c24
    7076cdd01386:	mov    rax,r13
    7076cdd01389:	mov    eax,eax
    7076cdd0138b:	mov    r15d,eax
    7076cdd0138e:	mov    rax,r8
    7076cdd01391:	mov    eax,eax
    7076cdd01393:	mov    r13d,eax
    7076cdd01396:	mov    DWORD PTR [r14],r15d
    7076cdd01399:	mov    r14d,0x0
    7076cdd0139f:	mov    DWORD PTR [r12+0x32c],r14d
    7076cdd013a7:	mov    DWORD PTR [rbp+0x0],r13d
    7076cdd013ab:	movabs rcx,0xff00ff00ff00ff
    7076cdd013b5:	mov    r13,r9
    7076cdd013b8:	and    r13,rcx
    7076cdd013bb:	shl    r13,0x8
    7076cdd013bf:	movabs rcx,0xff00ff00ff00ff00
    7076cdd013c9:	mov    r14,r9
    7076cdd013cc:	and    r14,rcx
    7076cdd013cf:	shr    r14,0x8
    7076cdd013d3:	or     r14,r13
    7076cdd013d6:	movabs rcx,0xffff0000ffff
    7076cdd013e0:	mov    r13,r14
    7076cdd013e3:	and    r13,rcx
    7076cdd013e6:	shl    r13,0x10
    7076cdd013ea:	movabs rcx,0xffff0000ffff0000
    7076cdd013f4:	and    r14,rcx
    7076cdd013f7:	shr    r14,0x10
    7076cdd013fb:	or     r14,r13
    7076cdd013fe:	mov    ecx,0xffffffff
    7076cdd01403:	and    r14,rcx
    7076cdd01406:	mov    QWORD PTR [r12+0x40],r14
    7076cdd0140b:	movabs rcx,0xff00ff00ff00ff
    7076cdd01415:	mov    r13,QWORD PTR [rsp]
    7076cdd01419:	and    r13,rcx
    7076cdd0141c:	shl    r13,0x8
    7076cdd01420:	movabs rcx,0xff00ff00ff00ff00
    7076cdd0142a:	mov    r15,QWORD PTR [rsp]
    7076cdd0142e:	and    r15,rcx
    7076cdd01431:	shr    r15,0x8
    7076cdd01435:	or     r15,r13
    7076cdd01438:	movabs rcx,0xffff0000ffff
    7076cdd01442:	mov    r13,r15
    7076cdd01445:	and    r13,rcx
    7076cdd01448:	shl    r13,0x10
    7076cdd0144c:	movabs rcx,0xffff0000ffff0000
    7076cdd01456:	and    r15,rcx
    7076cdd01459:	shr    r15,0x10
    7076cdd0145d:	or     r15,r13
    7076cdd01460:	mov    ecx,0xffffffff
    7076cdd01465:	and    r15,rcx
    7076cdd01468:	mov    QWORD PTR [r12+0x58],r15
    7076cdd0146d:	mov    r13,QWORD PTR [r12+0xf8]
    7076cdd01475:	add    r13,0xe0
    7076cdd0147c:	mov    rbp,r13
    7076cdd0147f:	add    rbp,0x4
    7076cdd01483:	mov    r8d,DWORD PTR [r13+0x0]
    7076cdd01487:	mov    eax,DWORD PTR [rbp+0x0]
    7076cdd0148a:	mov    QWORD PTR [rsp+0x8],rax
    7076cdd0148f:	mov    QWORD PTR [r12+0x50],r8
    7076cdd01494:	mov    rax,QWORD PTR [rsp+0x8]
    7076cdd01499:	mov    QWORD PTR [r12+0x60],rax
    7076cdd0149e:	mov    ebp,0x430c28
    7076cdd014a3:	mov    r9d,0x430c2c
    7076cdd014a9:	mov    rax,r14
    7076cdd014ac:	mov    eax,eax
    7076cdd014ae:	mov    r13d,eax
    7076cdd014b1:	mov    rax,r15
    7076cdd014b4:	mov    eax,eax
    7076cdd014b6:	mov    r14d,eax
    7076cdd014b9:	mov    DWORD PTR [rbp+0x0],r13d
    7076cdd014bd:	mov    DWORD PTR [r9],r14d
    7076cdd014c0:	movabs rcx,0xff00ff00ff00ff
    7076cdd014ca:	mov    r13,r8
    7076cdd014cd:	and    r13,rcx
    7076cdd014d0:	shl    r13,0x8
    7076cdd014d4:	movabs rcx,0xff00ff00ff00ff00
    7076cdd014de:	mov    r14,r8
    7076cdd014e1:	and    r14,rcx
    7076cdd014e4:	shr    r14,0x8
    7076cdd014e8:	or     r14,r13
    7076cdd014eb:	movabs rcx,0xffff0000ffff
    7076cdd014f5:	mov    r13,r14
    7076cdd014f8:	and    r13,rcx
    7076cdd014fb:	shl    r13,0x10
    7076cdd014ff:	movabs rcx,0xffff0000ffff0000
    7076cdd01509:	and    r14,rcx
    7076cdd0150c:	shr    r14,0x10
    7076cdd01510:	or     r14,r13
    7076cdd01513:	mov    ecx,0xffffffff
    7076cdd01518:	and    r14,rcx
    7076cdd0151b:	mov    QWORD PTR [r12+0x40],r14
    7076cdd01520:	movabs rcx,0xff00ff00ff00ff
    7076cdd0152a:	mov    r13,QWORD PTR [rsp+0x8]
    7076cdd0152f:	and    r13,rcx
    7076cdd01532:	shl    r13,0x8
    7076cdd01536:	movabs rcx,0xff00ff00ff00ff00
    7076cdd01540:	mov    r15,QWORD PTR [rsp+0x8]
    7076cdd01545:	and    r15,rcx
    7076cdd01548:	shr    r15,0x8
    7076cdd0154c:	or     r15,r13
    7076cdd0154f:	movabs rcx,0xffff0000ffff
    7076cdd01559:	mov    r13,r15
    7076cdd0155c:	and    r13,rcx
    7076cdd0155f:	shl    r13,0x10
    7076cdd01563:	movabs rcx,0xffff0000ffff0000
    7076cdd0156d:	and    r15,rcx
    7076cdd01570:	shr    r15,0x10
    7076cdd01574:	or     r15,r13
    7076cdd01577:	mov    ecx,0xffffffff
    7076cdd0157c:	and    r15,rcx
    7076cdd0157f:	mov    QWORD PTR [r12+0x58],r15
    7076cdd01584:	mov    r13,QWORD PTR [r12+0xf8]
    7076cdd0158c:	add    r13,0xe8
    7076cdd01593:	mov    rbp,r13
    7076cdd01596:	add    rbp,0x4
    7076cdd0159a:	mov    r8d,DWORD PTR [r13+0x0]
    7076cdd0159e:	mov    eax,DWORD PTR [rbp+0x0]
    7076cdd015a1:	mov    QWORD PTR [rsp+0x10],rax
    7076cdd015a6:	mov    QWORD PTR [r12+0x50],r8
    7076cdd015ab:	mov    rax,QWORD PTR [rsp+0x10]
    7076cdd015b0:	mov    QWORD PTR [r12+0x60],rax
    7076cdd015b5:	mov    ebp,0x430c30
    7076cdd015ba:	mov    r9d,0x430c34
    7076cdd015c0:	mov    rax,r14
    7076cdd015c3:	mov    eax,eax
    7076cdd015c5:	mov    r13d,eax
    7076cdd015c8:	mov    rax,r15
    7076cdd015cb:	mov    eax,eax
    7076cdd015cd:	mov    r14d,eax
    7076cdd015d0:	mov    DWORD PTR [rbp+0x0],r13d
    7076cdd015d4:	mov    DWORD PTR [r9],r14d
    7076cdd015d7:	movabs rcx,0xff00ff00ff00ff
    7076cdd015e1:	mov    r13,r8
    7076cdd015e4:	and    r13,rcx
    7076cdd015e7:	shl    r13,0x8
    7076cdd015eb:	movabs rcx,0xff00ff00ff00ff00
    7076cdd015f5:	mov    r14,r8
    7076cdd015f8:	and    r14,rcx
    7076cdd015fb:	shr    r14,0x8
    7076cdd015ff:	or     r14,r13
    7076cdd01602:	movabs rcx,0xffff0000ffff
    7076cdd0160c:	mov    r13,r14
    7076cdd0160f:	and    r13,rcx
    7076cdd01612:	shl    r13,0x10
    7076cdd01616:	movabs rcx,0xffff0000ffff0000
    7076cdd01620:	and    r14,rcx
    7076cdd01623:	shr    r14,0x10
    7076cdd01627:	or     r14,r13
    7076cdd0162a:	mov    ecx,0xffffffff
    7076cdd0162f:	and    r14,rcx
    7076cdd01632:	mov    QWORD PTR [r12+0x40],r14
    7076cdd01637:	movabs rcx,0xff00ff00ff00ff
    7076cdd01641:	mov    r13,QWORD PTR [rsp+0x10]
    7076cdd01646:	and    r13,rcx
    7076cdd01649:	shl    r13,0x8
    7076cdd0164d:	movabs rcx,0xff00ff00ff00ff00
    7076cdd01657:	mov    r15,QWORD PTR [rsp+0x10]
    7076cdd0165c:	and    r15,rcx
    7076cdd0165f:	shr    r15,0x8
    7076cdd01663:	or     r15,r13
    7076cdd01666:	movabs rcx,0xffff0000ffff
    7076cdd01670:	mov    r13,r15
    7076cdd01673:	and    r13,rcx
    7076cdd01676:	shl    r13,0x10
    7076cdd0167a:	movabs rcx,0xffff0000ffff0000
    7076cdd01684:	and    r15,rcx
    7076cdd01687:	shr    r15,0x10
    7076cdd0168b:	or     r15,r13
    7076cdd0168e:	mov    ecx,0xffffffff
    7076cdd01693:	and    r15,rcx
    7076cdd01696:	mov    QWORD PTR [r12+0x50],r15
    7076cdd0169b:	mov    r13d,0x430c38
    7076cdd016a1:	mov    ebp,0x430c3c
    7076cdd016a6:	mov    rax,r14
    7076cdd016a9:	mov    eax,eax
    7076cdd016ab:	mov    r8d,eax
    7076cdd016ae:	mov    rax,r15
    7076cdd016b1:	mov    eax,eax
    7076cdd016b3:	mov    r14d,eax
    7076cdd016b6:	mov    DWORD PTR [r13+0x0],r8d
    7076cdd016ba:	mov    DWORD PTR [rbp+0x0],r14d
    7076cdd016be:	mov    r13d,0x11
    7076cdd016c4:	mov    QWORD PTR [r12],r13
    7076cdd016c8:	mov    r13d,0x41034c
    7076cdd016ce:	mov    QWORD PTR [r12+0xf0],r13
    7076cdd016d6:	mov    r13d,0x410938
    7076cdd016dc:	mov    QWORD PTR [r12+0x100],r13
    7076cdd016e4:	mov    r11,QWORD PTR [rsp+0x18]
    7076cdd016e9:	mov    QWORD PTR [r12+0x398],r11
    7076cdd016f1:	mov    edi,0x410938
    7076cdd016f6:	mov    QWORD PTR [r12+0x100],rdi
    7076cdd016fe:	add    rsp,0x30
    7076cdd01702:	nop    WORD PTR [rax+rax*1+0x0]
    7076cdd01708:	jmp    QWORD PTR [rip+0x2]        # 0x7076cdd01710
    7076cdd0170e:	xchg   ax,ax
    7076cdd01710:	xor    BYTE PTR [rdi],dl
    7076cdd01712:	ror    ch,1
    7076cdd01714:	jbe    0x7076cdd01786
    7076cdd01716:	add    BYTE PTR [rax],al
    7076cdd01718:	and    BYTE PTR [rdi],dl
    7076cdd0171a:	ror    ch,1
    7076cdd0171c:	jbe    0x7076cdd0178e
    7076cdd0171e:	add    BYTE PTR [rax],al
    7076cdd01720:	movabs r11,0x5b61e73e9940
    7076cdd0172a:	jmp    r11
    7076cdd0172d:	nop
    7076cdd0172e:	nop
    7076cdd0172f:	nop
