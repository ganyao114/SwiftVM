
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/0/1.bin:     file format binary


Disassembly of section .data:

00007076cdcfe5e0 <.data>:
    7076cdcfe5e0:	sub    rsp,0xc0
    7076cdcfe5e7:	mov    r11,QWORD PTR [r12+0x398]
    7076cdcfe5ef:	mov    QWORD PTR [rsp+0xb0],r11
    7076cdcfe5f7:	mov    r13,QWORD PTR [r12]
    7076cdcfe5fb:	mov    r14,r13
    7076cdcfe5fe:	add    r14,0x20
    7076cdcfe602:	mov    r15,QWORD PTR [r14]
    7076cdcfe605:	mov    r14,QWORD PTR [r12+0x10]
    7076cdcfe60a:	add    r15,r14
    7076cdcfe60d:	mov    QWORD PTR [r12+0x40],r15
    7076cdcfe612:	add    r13,0x20
    7076cdcfe616:	mov    QWORD PTR [r13+0x0],r15
    7076cdcfe61a:	mov    r13d,0x0
    7076cdcfe620:	mov    DWORD PTR [r12+0x32c],r13d
    7076cdcfe628:	mov    rax,r14
    7076cdcfe62b:	test   rax,rax
    7076cdcfe62e:	je     0x7076cdd00735
    7076cdcfe634:	jmp    0x7076cdcfe639
    7076cdcfe639:	mov    r13,QWORD PTR [r12+0xf8]
    7076cdcfe641:	sub    r13,0x150
    7076cdcfe648:	mov    QWORD PTR [r12+0xf8],r13
    7076cdcfe650:	mov    r14,QWORD PTR [r12]
    7076cdcfe654:	mov    r15,r14
    7076cdcfe657:	add    r15,0x68
    7076cdcfe65b:	mov    rbp,QWORD PTR [r15]
    7076cdcfe65e:	mov    QWORD PTR [r12+0x88],rbp
    7076cdcfe666:	add    r14,0x28
    7076cdcfe66a:	mov    QWORD PTR [r12+0x40],r14
    7076cdcfe66f:	mov    QWORD PTR [r12+0x48],r13
    7076cdcfe674:	mov    r14d,0x420000
    7076cdcfe67a:	add    r14,0xb20
    7076cdcfe681:	mov    QWORD PTR [r12+0x50],r14
    7076cdcfe686:	mov    r14,r13
    7076cdcfe689:	add    r14,0x100
    7076cdcfe690:	mov    r15,r14
    7076cdcfe693:	add    r15,0x8
    7076cdcfe697:	mov    rbp,QWORD PTR [r12+0xe8]
    7076cdcfe69f:	mov    r8,QWORD PTR [r12+0xd8]
    7076cdcfe6a7:	mov    QWORD PTR [r14],rbp
    7076cdcfe6aa:	mov    r14d,0x0
    7076cdcfe6b0:	mov    DWORD PTR [r12+0x32c],r14d
    7076cdcfe6b8:	mov    QWORD PTR [r15],r8
    7076cdcfe6bb:	mov    r14,r13
    7076cdcfe6be:	add    r14,0x110
    7076cdcfe6c5:	mov    r15,r14
    7076cdcfe6c8:	add    r15,0x8
    7076cdcfe6cc:	mov    rbp,QWORD PTR [r12+0xd0]
    7076cdcfe6d4:	mov    r8,QWORD PTR [r12+0xc8]
    7076cdcfe6dc:	mov    QWORD PTR [r14],rbp
    7076cdcfe6df:	mov    QWORD PTR [r15],r8
    7076cdcfe6e2:	mov    r14,r13
    7076cdcfe6e5:	add    r14,0x120
    7076cdcfe6ec:	mov    r15,r14
    7076cdcfe6ef:	add    r15,0x8
    7076cdcfe6f3:	mov    rbp,QWORD PTR [r12+0xc0]
    7076cdcfe6fb:	mov    r8,QWORD PTR [r12+0xb8]
    7076cdcfe703:	mov    QWORD PTR [r14],rbp
    7076cdcfe706:	mov    QWORD PTR [r15],r8
    7076cdcfe709:	mov    r14,r13
    7076cdcfe70c:	add    r14,0x130
    7076cdcfe713:	mov    r15,r14
    7076cdcfe716:	add    r15,0x8
    7076cdcfe71a:	mov    rbp,QWORD PTR [r12+0xb0]
    7076cdcfe722:	mov    r8,QWORD PTR [r12+0xa8]
    7076cdcfe72a:	mov    QWORD PTR [r14],rbp
    7076cdcfe72d:	mov    QWORD PTR [r15],r8
    7076cdcfe730:	add    r13,0x140
    7076cdcfe737:	mov    r14,r13
    7076cdcfe73a:	add    r14,0x8
    7076cdcfe73e:	mov    r15,QWORD PTR [r12+0xa0]
    7076cdcfe746:	mov    rbp,QWORD PTR [r12+0x98]
    7076cdcfe74e:	mov    QWORD PTR [r13+0x0],r15
    7076cdcfe752:	mov    QWORD PTR [r14],rbp
    7076cdcfe755:	jmp    0x7076cdcfe75a
    7076cdcfe75a:	mov    r13,QWORD PTR [r12+0x8]
    7076cdcfe75f:	mov    r14,r13
    7076cdcfe762:	add    r14,0x1
    7076cdcfe766:	movzx  r15d,BYTE PTR [r13+0x0]
    7076cdcfe76b:	mov    QWORD PTR [r12+0x58],r15
    7076cdcfe770:	mov    QWORD PTR [r12+0x8],r14
    7076cdcfe775:	mov    r13,QWORD PTR [r12+0x88]
    7076cdcfe77d:	mov    r14,r13
    7076cdcfe780:	add    r14,0x1
    7076cdcfe784:	mov    QWORD PTR [r12+0x60],r14
    7076cdcfe789:	mov    r15,QWORD PTR [r12]
    7076cdcfe78d:	mov    rbp,r15
    7076cdcfe790:	add    rbp,0x68
    7076cdcfe794:	mov    QWORD PTR [rbp+0x0],r14
    7076cdcfe798:	mov    r14d,0x0
    7076cdcfe79e:	mov    DWORD PTR [r12+0x32c],r14d
    7076cdcfe7a6:	mov    r14,r15
    7076cdcfe7a9:	add    r14,r13
    7076cdcfe7ac:	mov    QWORD PTR [r12+0x60],r14
    7076cdcfe7b1:	add    r14,0x28
    7076cdcfe7b5:	movzx  r13d,BYTE PTR [r12+0x58]
    7076cdcfe7bb:	mov    BYTE PTR [r14],r13b
    7076cdcfe7be:	add    r15,0x68
    7076cdcfe7c2:	mov    r13,QWORD PTR [r15]
    7076cdcfe7c5:	mov    QWORD PTR [r12+0x88],r13
    7076cdcfe7cd:	sub    r13,0x40
    7076cdcfe7d1:	mov    rcx,QWORD PTR [r12+0x380]
    7076cdcfe7d9:	jrcxz  0x7076cdcfe7e0
    7076cdcfe7db:	jmp    0x7076cdd00780
    7076cdcfe7e0:	jne    0x7076cdcfe7fd
    7076cdcfe7e6:	mov    r11,rax
    7076cdcfe7e9:	lahf
    7076cdcfe7ea:	seto   al
    7076cdcfe7ed:	mov    WORD PTR [rsp+0xb0],ax
    7076cdcfe7f5:	mov    rax,r11
    7076cdcfe7f8:	jmp    0x7076cdcfe814
    7076cdcfe7fd:	mov    r11,rax
    7076cdcfe800:	lahf
    7076cdcfe801:	seto   al
    7076cdcfe804:	mov    WORD PTR [rsp+0xb0],ax
    7076cdcfe80c:	mov    rax,r11
    7076cdcfe80f:	jmp    0x7076cdd00637
    7076cdcfe814:	mov    rax,QWORD PTR [r12+0x40]
    7076cdcfe819:	mov    eax,0x0
    7076cdcfe81e:	mov    QWORD PTR [rsp+0x18],rax
    7076cdcfe823:	mov    eax,0x0
    7076cdcfe828:	mov    QWORD PTR [rsp+0x10],rax
    7076cdcfe82d:	mov    eax,0x0
    7076cdcfe832:	mov    QWORD PTR [rsp+0x8],rax
    7076cdcfe837:	mov    eax,0x0
    7076cdcfe83c:	mov    QWORD PTR [rsp],rax
    7076cdcfe840:	mov    rdi,QWORD PTR [r12+0x40]
    7076cdcfe845:	movzx  r9d,BYTE PTR [rdi]
    7076cdcfe849:	mov    r13,QWORD PTR [rsp+0x18]
    7076cdcfe84e:	or     r13,r9
    7076cdcfe851:	mov    r9,QWORD PTR [r12+0x40]
    7076cdcfe856:	add    r9,0x1
    7076cdcfe85a:	movzx  r8d,BYTE PTR [r9]
    7076cdcfe85e:	mov    r9,QWORD PTR [rsp+0x10]
    7076cdcfe863:	or     r9,r8
    7076cdcfe866:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfe86b:	add    r8,0x2
    7076cdcfe86f:	movzx  ebp,BYTE PTR [r8]
    7076cdcfe873:	mov    r8,QWORD PTR [rsp+0x8]
    7076cdcfe878:	or     r8,rbp
    7076cdcfe87b:	mov    rbp,QWORD PTR [r12+0x40]
    7076cdcfe880:	add    rbp,0x3
    7076cdcfe884:	movzx  r15d,BYTE PTR [rbp+0x0]
    7076cdcfe889:	mov    rbp,QWORD PTR [rsp]
    7076cdcfe88d:	or     rbp,r15
    7076cdcfe890:	mov    r15,QWORD PTR [r12+0x40]
    7076cdcfe895:	add    r15,0x4
    7076cdcfe899:	movzx  r14d,BYTE PTR [r15]
    7076cdcfe89d:	mov    r15,r14
    7076cdcfe8a0:	shl    r15,0x8
    7076cdcfe8a4:	or     r13,r15
    7076cdcfe8a7:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfe8ac:	add    r14,0x5
    7076cdcfe8b0:	movzx  r15d,BYTE PTR [r14]
    7076cdcfe8b4:	mov    r14,r15
    7076cdcfe8b7:	shl    r14,0x8
    7076cdcfe8bb:	or     r9,r14
    7076cdcfe8be:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfe8c3:	add    r14,0x6
    7076cdcfe8c7:	movzx  r15d,BYTE PTR [r14]
    7076cdcfe8cb:	mov    r14,r15
    7076cdcfe8ce:	shl    r14,0x8
    7076cdcfe8d2:	or     r8,r14
    7076cdcfe8d5:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfe8da:	add    r14,0x7
    7076cdcfe8de:	movzx  r15d,BYTE PTR [r14]
    7076cdcfe8e2:	mov    r14,r15
    7076cdcfe8e5:	shl    r14,0x8
    7076cdcfe8e9:	or     rbp,r14
    7076cdcfe8ec:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfe8f1:	add    r14,0x8
    7076cdcfe8f5:	movzx  r15d,BYTE PTR [r14]
    7076cdcfe8f9:	mov    r14,r15
    7076cdcfe8fc:	shl    r14,0x10
    7076cdcfe900:	or     r13,r14
    7076cdcfe903:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfe908:	add    r14,0x9
    7076cdcfe90c:	movzx  r15d,BYTE PTR [r14]
    7076cdcfe910:	mov    r14,r15
    7076cdcfe913:	shl    r14,0x10
    7076cdcfe917:	or     r9,r14
    7076cdcfe91a:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfe91f:	add    r14,0xa
    7076cdcfe923:	movzx  r15d,BYTE PTR [r14]
    7076cdcfe927:	mov    r14,r15
    7076cdcfe92a:	shl    r14,0x10
    7076cdcfe92e:	or     r8,r14
    7076cdcfe931:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfe936:	add    r14,0xb
    7076cdcfe93a:	movzx  r15d,BYTE PTR [r14]
    7076cdcfe93e:	mov    r14,r15
    7076cdcfe941:	shl    r14,0x10
    7076cdcfe945:	or     rbp,r14
    7076cdcfe948:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfe94d:	add    r14,0xc
    7076cdcfe951:	movzx  r15d,BYTE PTR [r14]
    7076cdcfe955:	mov    r14,r15
    7076cdcfe958:	shl    r14,0x18
    7076cdcfe95c:	or     r13,r14
    7076cdcfe95f:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfe964:	add    r14,0xd
    7076cdcfe968:	movzx  r15d,BYTE PTR [r14]
    7076cdcfe96c:	mov    r14,r15
    7076cdcfe96f:	shl    r14,0x18
    7076cdcfe973:	or     r9,r14
    7076cdcfe976:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfe97b:	add    r14,0xe
    7076cdcfe97f:	movzx  r15d,BYTE PTR [r14]
    7076cdcfe983:	mov    r14,r15
    7076cdcfe986:	shl    r14,0x18
    7076cdcfe98a:	or     r8,r14
    7076cdcfe98d:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfe992:	add    r14,0xf
    7076cdcfe996:	movzx  r15d,BYTE PTR [r14]
    7076cdcfe99a:	mov    r14,r15
    7076cdcfe99d:	shl    r14,0x18
    7076cdcfe9a1:	or     rbp,r14
    7076cdcfe9a4:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfe9a9:	add    r14,0x10
    7076cdcfe9ad:	movzx  r15d,BYTE PTR [r14]
    7076cdcfe9b1:	mov    r14,r15
    7076cdcfe9b4:	shl    r14,0x20
    7076cdcfe9b8:	or     r13,r14
    7076cdcfe9bb:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfe9c0:	add    r14,0x11
    7076cdcfe9c4:	movzx  r15d,BYTE PTR [r14]
    7076cdcfe9c8:	mov    r14,r15
    7076cdcfe9cb:	shl    r14,0x20
    7076cdcfe9cf:	or     r9,r14
    7076cdcfe9d2:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfe9d7:	add    r14,0x12
    7076cdcfe9db:	movzx  r15d,BYTE PTR [r14]
    7076cdcfe9df:	mov    r14,r15
    7076cdcfe9e2:	shl    r14,0x20
    7076cdcfe9e6:	or     r8,r14
    7076cdcfe9e9:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfe9ee:	add    r14,0x13
    7076cdcfe9f2:	movzx  r15d,BYTE PTR [r14]
    7076cdcfe9f6:	mov    r14,r15
    7076cdcfe9f9:	shl    r14,0x20
    7076cdcfe9fd:	or     rbp,r14
    7076cdcfea00:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfea05:	add    r14,0x14
    7076cdcfea09:	movzx  r15d,BYTE PTR [r14]
    7076cdcfea0d:	mov    r14,r15
    7076cdcfea10:	shl    r14,0x28
    7076cdcfea14:	or     r13,r14
    7076cdcfea17:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfea1c:	add    r14,0x15
    7076cdcfea20:	movzx  r15d,BYTE PTR [r14]
    7076cdcfea24:	mov    r14,r15
    7076cdcfea27:	shl    r14,0x28
    7076cdcfea2b:	or     r9,r14
    7076cdcfea2e:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfea33:	add    r14,0x16
    7076cdcfea37:	movzx  r15d,BYTE PTR [r14]
    7076cdcfea3b:	mov    r14,r15
    7076cdcfea3e:	shl    r14,0x28
    7076cdcfea42:	or     r8,r14
    7076cdcfea45:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfea4a:	add    r14,0x17
    7076cdcfea4e:	movzx  r15d,BYTE PTR [r14]
    7076cdcfea52:	mov    r14,r15
    7076cdcfea55:	shl    r14,0x28
    7076cdcfea59:	or     rbp,r14
    7076cdcfea5c:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfea61:	add    r14,0x18
    7076cdcfea65:	movzx  r15d,BYTE PTR [r14]
    7076cdcfea69:	mov    r14,r15
    7076cdcfea6c:	shl    r14,0x30
    7076cdcfea70:	or     r13,r14
    7076cdcfea73:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfea78:	add    r14,0x19
    7076cdcfea7c:	movzx  r15d,BYTE PTR [r14]
    7076cdcfea80:	mov    r14,r15
    7076cdcfea83:	shl    r14,0x30
    7076cdcfea87:	or     r9,r14
    7076cdcfea8a:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfea8f:	add    r14,0x1a
    7076cdcfea93:	movzx  r15d,BYTE PTR [r14]
    7076cdcfea97:	mov    r14,r15
    7076cdcfea9a:	shl    r14,0x30
    7076cdcfea9e:	or     r8,r14
    7076cdcfeaa1:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfeaa6:	add    r14,0x1b
    7076cdcfeaaa:	movzx  r15d,BYTE PTR [r14]
    7076cdcfeaae:	mov    r14,r15
    7076cdcfeab1:	shl    r14,0x30
    7076cdcfeab5:	or     rbp,r14
    7076cdcfeab8:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfeabd:	add    r14,0x1c
    7076cdcfeac1:	movzx  r15d,BYTE PTR [r14]
    7076cdcfeac5:	mov    r14,r15
    7076cdcfeac8:	shl    r14,0x38
    7076cdcfeacc:	mov    rax,r13
    7076cdcfeacf:	or     rax,r14
    7076cdcfead2:	mov    QWORD PTR [rsp+0x28],rax
    7076cdcfead7:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfeadc:	add    r14,0x1d
    7076cdcfeae0:	movzx  r15d,BYTE PTR [r14]
    7076cdcfeae4:	mov    r14,r15
    7076cdcfeae7:	shl    r14,0x38
    7076cdcfeaeb:	mov    rax,r9
    7076cdcfeaee:	or     rax,r14
    7076cdcfeaf1:	mov    QWORD PTR [rsp+0x38],rax
    7076cdcfeaf6:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfeafb:	add    r14,0x1e
    7076cdcfeaff:	movzx  r15d,BYTE PTR [r14]
    7076cdcfeb03:	mov    r14,r15
    7076cdcfeb06:	shl    r14,0x38
    7076cdcfeb0a:	mov    rax,r8
    7076cdcfeb0d:	or     rax,r14
    7076cdcfeb10:	mov    QWORD PTR [rsp+0x30],rax
    7076cdcfeb15:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfeb1a:	add    r14,0x1f
    7076cdcfeb1e:	movzx  r15d,BYTE PTR [r14]
    7076cdcfeb22:	mov    r14,r15
    7076cdcfeb25:	shl    r14,0x38
    7076cdcfeb29:	mov    rax,rbp
    7076cdcfeb2c:	or     rax,r14
    7076cdcfeb2f:	mov    QWORD PTR [rsp+0x20],rax
    7076cdcfeb34:	mov    r14,QWORD PTR [r12+0x40]
    7076cdcfeb39:	add    r14,0x20
    7076cdcfeb3d:	movzx  r15d,BYTE PTR [r14]
    7076cdcfeb41:	mov    r14,QWORD PTR [rsp+0x18]
    7076cdcfeb46:	or     r14,r15
    7076cdcfeb49:	mov    r15,QWORD PTR [r12+0x40]
    7076cdcfeb4e:	add    r15,0x21
    7076cdcfeb52:	movzx  ebp,BYTE PTR [r15]
    7076cdcfeb56:	mov    r15,QWORD PTR [rsp+0x10]
    7076cdcfeb5b:	or     r15,rbp
    7076cdcfeb5e:	mov    rbp,QWORD PTR [r12+0x40]
    7076cdcfeb63:	add    rbp,0x22
    7076cdcfeb67:	movzx  r13d,BYTE PTR [rbp+0x0]
    7076cdcfeb6c:	mov    rbp,QWORD PTR [rsp+0x8]
    7076cdcfeb71:	or     rbp,r13
    7076cdcfeb74:	mov    r13,QWORD PTR [r12+0x40]
    7076cdcfeb79:	add    r13,0x23
    7076cdcfeb7d:	movzx  r8d,BYTE PTR [r13+0x0]
    7076cdcfeb82:	mov    r13,QWORD PTR [rsp]
    7076cdcfeb86:	or     r13,r8
    7076cdcfeb89:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfeb8e:	add    r8,0x24
    7076cdcfeb92:	movzx  r9d,BYTE PTR [r8]
    7076cdcfeb96:	mov    r8,r9
    7076cdcfeb99:	shl    r8,0x8
    7076cdcfeb9d:	or     r14,r8
    7076cdcfeba0:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfeba5:	add    r8,0x25
    7076cdcfeba9:	movzx  r9d,BYTE PTR [r8]
    7076cdcfebad:	mov    r8,r9
    7076cdcfebb0:	shl    r8,0x8
    7076cdcfebb4:	or     r15,r8
    7076cdcfebb7:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfebbc:	add    r8,0x26
    7076cdcfebc0:	movzx  r9d,BYTE PTR [r8]
    7076cdcfebc4:	mov    r8,r9
    7076cdcfebc7:	shl    r8,0x8
    7076cdcfebcb:	or     rbp,r8
    7076cdcfebce:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfebd3:	add    r8,0x27
    7076cdcfebd7:	movzx  r9d,BYTE PTR [r8]
    7076cdcfebdb:	mov    r8,r9
    7076cdcfebde:	shl    r8,0x8
    7076cdcfebe2:	or     r13,r8
    7076cdcfebe5:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfebea:	add    r8,0x28
    7076cdcfebee:	movzx  r9d,BYTE PTR [r8]
    7076cdcfebf2:	mov    r8,r9
    7076cdcfebf5:	shl    r8,0x10
    7076cdcfebf9:	or     r14,r8
    7076cdcfebfc:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfec01:	add    r8,0x29
    7076cdcfec05:	movzx  r9d,BYTE PTR [r8]
    7076cdcfec09:	mov    r8,r9
    7076cdcfec0c:	shl    r8,0x10
    7076cdcfec10:	or     r15,r8
    7076cdcfec13:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfec18:	add    r8,0x2a
    7076cdcfec1c:	movzx  r9d,BYTE PTR [r8]
    7076cdcfec20:	mov    r8,r9
    7076cdcfec23:	shl    r8,0x10
    7076cdcfec27:	or     rbp,r8
    7076cdcfec2a:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfec2f:	add    r8,0x2b
    7076cdcfec33:	movzx  r9d,BYTE PTR [r8]
    7076cdcfec37:	mov    r8,r9
    7076cdcfec3a:	shl    r8,0x10
    7076cdcfec3e:	or     r13,r8
    7076cdcfec41:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfec46:	add    r8,0x2c
    7076cdcfec4a:	movzx  r9d,BYTE PTR [r8]
    7076cdcfec4e:	mov    r8,r9
    7076cdcfec51:	shl    r8,0x18
    7076cdcfec55:	or     r14,r8
    7076cdcfec58:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfec5d:	add    r8,0x2d
    7076cdcfec61:	movzx  r9d,BYTE PTR [r8]
    7076cdcfec65:	mov    r8,r9
    7076cdcfec68:	shl    r8,0x18
    7076cdcfec6c:	or     r15,r8
    7076cdcfec6f:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfec74:	add    r8,0x2e
    7076cdcfec78:	movzx  r9d,BYTE PTR [r8]
    7076cdcfec7c:	mov    r8,r9
    7076cdcfec7f:	shl    r8,0x18
    7076cdcfec83:	or     rbp,r8
    7076cdcfec86:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfec8b:	add    r8,0x2f
    7076cdcfec8f:	movzx  r9d,BYTE PTR [r8]
    7076cdcfec93:	mov    r8,r9
    7076cdcfec96:	shl    r8,0x18
    7076cdcfec9a:	or     r13,r8
    7076cdcfec9d:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfeca2:	add    r8,0x30
    7076cdcfeca6:	movzx  r9d,BYTE PTR [r8]
    7076cdcfecaa:	mov    r8,r9
    7076cdcfecad:	shl    r8,0x20
    7076cdcfecb1:	or     r14,r8
    7076cdcfecb4:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfecb9:	add    r8,0x31
    7076cdcfecbd:	movzx  r9d,BYTE PTR [r8]
    7076cdcfecc1:	mov    r8,r9
    7076cdcfecc4:	shl    r8,0x20
    7076cdcfecc8:	or     r15,r8
    7076cdcfeccb:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfecd0:	add    r8,0x32
    7076cdcfecd4:	movzx  r9d,BYTE PTR [r8]
    7076cdcfecd8:	mov    r8,r9
    7076cdcfecdb:	shl    r8,0x20
    7076cdcfecdf:	or     rbp,r8
    7076cdcfece2:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfece7:	add    r8,0x33
    7076cdcfeceb:	movzx  r9d,BYTE PTR [r8]
    7076cdcfecef:	mov    r8,r9
    7076cdcfecf2:	shl    r8,0x20
    7076cdcfecf6:	or     r13,r8
    7076cdcfecf9:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfecfe:	add    r8,0x34
    7076cdcfed02:	movzx  r9d,BYTE PTR [r8]
    7076cdcfed06:	mov    r8,r9
    7076cdcfed09:	shl    r8,0x28
    7076cdcfed0d:	or     r14,r8
    7076cdcfed10:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfed15:	add    r8,0x35
    7076cdcfed19:	movzx  r9d,BYTE PTR [r8]
    7076cdcfed1d:	mov    r8,r9
    7076cdcfed20:	shl    r8,0x28
    7076cdcfed24:	or     r15,r8
    7076cdcfed27:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfed2c:	add    r8,0x36
    7076cdcfed30:	movzx  r9d,BYTE PTR [r8]
    7076cdcfed34:	mov    r8,r9
    7076cdcfed37:	shl    r8,0x28
    7076cdcfed3b:	or     rbp,r8
    7076cdcfed3e:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfed43:	add    r8,0x37
    7076cdcfed47:	movzx  r9d,BYTE PTR [r8]
    7076cdcfed4b:	mov    r8,r9
    7076cdcfed4e:	shl    r8,0x28
    7076cdcfed52:	or     r13,r8
    7076cdcfed55:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfed5a:	add    r8,0x38
    7076cdcfed5e:	movzx  r9d,BYTE PTR [r8]
    7076cdcfed62:	mov    r8,r9
    7076cdcfed65:	shl    r8,0x30
    7076cdcfed69:	or     r14,r8
    7076cdcfed6c:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfed71:	add    r8,0x39
    7076cdcfed75:	movzx  r9d,BYTE PTR [r8]
    7076cdcfed79:	mov    r8,r9
    7076cdcfed7c:	shl    r8,0x30
    7076cdcfed80:	or     r15,r8
    7076cdcfed83:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfed88:	add    r8,0x3a
    7076cdcfed8c:	movzx  r9d,BYTE PTR [r8]
    7076cdcfed90:	mov    r8,r9
    7076cdcfed93:	shl    r8,0x30
    7076cdcfed97:	or     rbp,r8
    7076cdcfed9a:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfed9f:	add    r8,0x3b
    7076cdcfeda3:	movzx  r9d,BYTE PTR [r8]
    7076cdcfeda7:	mov    r8,r9
    7076cdcfedaa:	shl    r8,0x30
    7076cdcfedae:	or     r13,r8
    7076cdcfedb1:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfedb6:	add    r8,0x3c
    7076cdcfedba:	movzx  r9d,BYTE PTR [r8]
    7076cdcfedbe:	mov    r8,r9
    7076cdcfedc1:	shl    r8,0x38
    7076cdcfedc5:	or     r14,r8
    7076cdcfedc8:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfedcd:	add    r8,0x3d
    7076cdcfedd1:	movzx  r9d,BYTE PTR [r8]
    7076cdcfedd5:	mov    r8,r9
    7076cdcfedd8:	shl    r8,0x38
    7076cdcfeddc:	or     r15,r8
    7076cdcfeddf:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfede4:	add    r8,0x3e
    7076cdcfede8:	movzx  r9d,BYTE PTR [r8]
    7076cdcfedec:	mov    r8,r9
    7076cdcfedef:	shl    r8,0x38
    7076cdcfedf3:	or     rbp,r8
    7076cdcfedf6:	mov    r8,QWORD PTR [r12+0x40]
    7076cdcfedfb:	add    r8,0x3f
    7076cdcfedff:	movzx  r9d,BYTE PTR [r8]
    7076cdcfee03:	mov    r8,r9
    7076cdcfee06:	shl    r8,0x38
    7076cdcfee0a:	mov    rax,r13
    7076cdcfee0d:	or     rax,r8
    7076cdcfee10:	mov    QWORD PTR [rsp+0x40],rax
    7076cdcfee15:	mov    r8d,0x0
    7076cdcfee1b:	mov    QWORD PTR [r12+0x58],r8
    7076cdcfee20:	mov    r8d,0x0
    7076cdcfee26:	mov    r9,QWORD PTR [rsp+0x38]
    7076cdcfee2b:	and    r9,0xff
    7076cdcfee32:	and    r9,0xffff
    7076cdcfee39:	mov    r13,r8
    7076cdcfee3c:	or     r13,r9
    7076cdcfee3f:	mov    r9,QWORD PTR [rsp+0x38]
    7076cdcfee44:	shr    r9,0x8
    7076cdcfee48:	and    r9,0xff
    7076cdcfee4f:	and    r9,0xffff
    7076cdcfee56:	shl    r9,0x10
    7076cdcfee5a:	or     r13,r9
    7076cdcfee5d:	mov    r9,QWORD PTR [rsp+0x38]
    7076cdcfee62:	shr    r9,0x10
    7076cdcfee66:	and    r9,0xff
    7076cdcfee6d:	and    r9,0xffff
    7076cdcfee74:	shl    r9,0x20
    7076cdcfee78:	or     r13,r9
    7076cdcfee7b:	mov    r9,QWORD PTR [rsp+0x38]
    7076cdcfee80:	shr    r9,0x18
    7076cdcfee84:	and    r9,0xff
    7076cdcfee8b:	and    r9,0xffff
    7076cdcfee92:	shl    r9,0x30
    7076cdcfee96:	or     r13,r9
    7076cdcfee99:	mov    r9,QWORD PTR [rsp+0x38]
    7076cdcfee9e:	shr    r9,0x20
    7076cdcfeea2:	and    r9,0xff
    7076cdcfeea9:	and    r9,0xffff
    7076cdcfeeb0:	or     r8,r9
    7076cdcfeeb3:	mov    r9,QWORD PTR [rsp+0x38]
    7076cdcfeeb8:	shr    r9,0x28
    7076cdcfeebc:	and    r9,0xff
    7076cdcfeec3:	and    r9,0xffff
    7076cdcfeeca:	shl    r9,0x10
    7076cdcfeece:	or     r8,r9
    7076cdcfeed1:	mov    r9,QWORD PTR [rsp+0x38]
    7076cdcfeed6:	shr    r9,0x30
    7076cdcfeeda:	and    r9,0xff
    7076cdcfeee1:	and    r9,0xffff
    7076cdcfeee8:	shl    r9,0x20
    7076cdcfeeec:	or     r8,r9
    7076cdcfeeef:	mov    r9,QWORD PTR [rsp+0x38]
    7076cdcfeef4:	shr    r9,0x38
    7076cdcfeef8:	and    r9,0xff
    7076cdcfeeff:	and    r9,0xffff
    7076cdcfef06:	shl    r9,0x30
    7076cdcfef0a:	or     r8,r9
    7076cdcfef0d:	mov    QWORD PTR [r12+0x150],r13
    7076cdcfef15:	mov    QWORD PTR [r12+0x158],r8
    7076cdcfef1d:	mov    r13d,0x0
    7076cdcfef23:	mov    r8,QWORD PTR [rsp+0x30]
    7076cdcfef28:	and    r8,0xff
    7076cdcfef2f:	and    r8,0xffff
    7076cdcfef36:	mov    r9,r13
    7076cdcfef39:	or     r9,r8
    7076cdcfef3c:	mov    r8,QWORD PTR [rsp+0x30]
    7076cdcfef41:	shr    r8,0x8
    7076cdcfef45:	and    r8,0xff
    7076cdcfef4c:	and    r8,0xffff
    7076cdcfef53:	shl    r8,0x10
    7076cdcfef57:	or     r9,r8
    7076cdcfef5a:	mov    r8,QWORD PTR [rsp+0x30]
    7076cdcfef5f:	shr    r8,0x10
    7076cdcfef63:	and    r8,0xff
    7076cdcfef6a:	and    r8,0xffff
    7076cdcfef71:	shl    r8,0x20
    7076cdcfef75:	or     r9,r8
    7076cdcfef78:	mov    r8,QWORD PTR [rsp+0x30]
    7076cdcfef7d:	shr    r8,0x18
    7076cdcfef81:	and    r8,0xff
    7076cdcfef88:	and    r8,0xffff
    7076cdcfef8f:	shl    r8,0x30
    7076cdcfef93:	mov    rax,r9
    7076cdcfef96:	or     rax,r8
    7076cdcfef99:	mov    QWORD PTR [rsp+0x50],rax
    7076cdcfef9e:	mov    r8,QWORD PTR [rsp+0x30]
    7076cdcfefa3:	shr    r8,0x20
    7076cdcfefa7:	and    r8,0xff
    7076cdcfefae:	and    r8,0xffff
    7076cdcfefb5:	or     r13,r8
    7076cdcfefb8:	mov    r8,QWORD PTR [rsp+0x30]
    7076cdcfefbd:	shr    r8,0x28
    7076cdcfefc1:	and    r8,0xff
    7076cdcfefc8:	and    r8,0xffff
    7076cdcfefcf:	shl    r8,0x10
    7076cdcfefd3:	or     r13,r8
    7076cdcfefd6:	mov    r8,QWORD PTR [rsp+0x30]
    7076cdcfefdb:	shr    r8,0x30
    7076cdcfefdf:	and    r8,0xff
    7076cdcfefe6:	and    r8,0xffff
    7076cdcfefed:	shl    r8,0x20
    7076cdcfeff1:	or     r13,r8
    7076cdcfeff4:	mov    r8,QWORD PTR [rsp+0x30]
    7076cdcfeff9:	shr    r8,0x38
    7076cdcfeffd:	and    r8,0xff
    7076cdcff004:	and    r8,0xffff
    7076cdcff00b:	shl    r8,0x30
    7076cdcff00f:	mov    rax,r13
    7076cdcff012:	or     rax,r8
    7076cdcff015:	mov    QWORD PTR [rsp+0x48],rax
    7076cdcff01a:	mov    r8d,0x0
    7076cdcff020:	mov    r13,QWORD PTR [rsp+0x28]
    7076cdcff025:	and    r13,0xff
    7076cdcff02c:	and    r13,0xffff
    7076cdcff033:	mov    r9,r8
    7076cdcff036:	or     r9,r13
    7076cdcff039:	mov    r13,QWORD PTR [rsp+0x28]
    7076cdcff03e:	shr    r13,0x8
    7076cdcff042:	and    r13,0xff
    7076cdcff049:	and    r13,0xffff
    7076cdcff050:	shl    r13,0x10
    7076cdcff054:	or     r9,r13
    7076cdcff057:	mov    r13,QWORD PTR [rsp+0x28]
    7076cdcff05c:	shr    r13,0x10
    7076cdcff060:	and    r13,0xff
    7076cdcff067:	and    r13,0xffff
    7076cdcff06e:	shl    r13,0x20
    7076cdcff072:	or     r9,r13
    7076cdcff075:	mov    r13,QWORD PTR [rsp+0x28]
    7076cdcff07a:	shr    r13,0x18
    7076cdcff07e:	and    r13,0xff
    7076cdcff085:	and    r13,0xffff
    7076cdcff08c:	shl    r13,0x30
    7076cdcff090:	mov    rax,r9
    7076cdcff093:	or     rax,r13
    7076cdcff096:	mov    QWORD PTR [rsp+0x58],rax
    7076cdcff09b:	mov    r13,QWORD PTR [rsp+0x28]
    7076cdcff0a0:	shr    r13,0x20
    7076cdcff0a4:	and    r13,0xff
    7076cdcff0ab:	and    r13,0xffff
    7076cdcff0b2:	or     r8,r13
    7076cdcff0b5:	mov    r13,QWORD PTR [rsp+0x28]
    7076cdcff0ba:	shr    r13,0x28
    7076cdcff0be:	and    r13,0xff
    7076cdcff0c5:	and    r13,0xffff
    7076cdcff0cc:	shl    r13,0x10
    7076cdcff0d0:	or     r8,r13
    7076cdcff0d3:	mov    r13,QWORD PTR [rsp+0x28]
    7076cdcff0d8:	shr    r13,0x30
    7076cdcff0dc:	and    r13,0xff
    7076cdcff0e3:	and    r13,0xffff
    7076cdcff0ea:	shl    r13,0x20
    7076cdcff0ee:	or     r8,r13
    7076cdcff0f1:	mov    r13,QWORD PTR [rsp+0x28]
    7076cdcff0f6:	shr    r13,0x38
    7076cdcff0fa:	and    r13,0xff
    7076cdcff101:	and    r13,0xffff
    7076cdcff108:	shl    r13,0x30
    7076cdcff10c:	mov    rax,r8
    7076cdcff10f:	or     rax,r13
    7076cdcff112:	mov    QWORD PTR [rsp+0x60],rax
    7076cdcff117:	mov    r13d,0x0
    7076cdcff11d:	mov    r9,r14
    7076cdcff120:	and    r9,0xff
    7076cdcff127:	and    r9,0xffff
    7076cdcff12e:	mov    r8,r13
    7076cdcff131:	or     r8,r9
    7076cdcff134:	mov    r9,r14
    7076cdcff137:	shr    r9,0x8
    7076cdcff13b:	and    r9,0xff
    7076cdcff142:	and    r9,0xffff
    7076cdcff149:	shl    r9,0x10
    7076cdcff14d:	or     r8,r9
    7076cdcff150:	mov    r9,r14
    7076cdcff153:	shr    r9,0x10
    7076cdcff157:	and    r9,0xff
    7076cdcff15e:	and    r9,0xffff
    7076cdcff165:	shl    r9,0x20
    7076cdcff169:	or     r8,r9
    7076cdcff16c:	mov    r9,r14
    7076cdcff16f:	shr    r9,0x18
    7076cdcff173:	and    r9,0xff
    7076cdcff17a:	and    r9,0xffff
    7076cdcff181:	shl    r9,0x30
    7076cdcff185:	mov    rax,r8
    7076cdcff188:	or     rax,r9
    7076cdcff18b:	mov    QWORD PTR [rsp+0x68],rax
    7076cdcff190:	mov    r9,r14
    7076cdcff193:	shr    r9,0x20
    7076cdcff197:	and    r9,0xff
    7076cdcff19e:	and    r9,0xffff
    7076cdcff1a5:	or     r13,r9
    7076cdcff1a8:	mov    r9,r14
    7076cdcff1ab:	shr    r9,0x28
    7076cdcff1af:	and    r9,0xff
    7076cdcff1b6:	and    r9,0xffff
    7076cdcff1bd:	shl    r9,0x10
    7076cdcff1c1:	or     r13,r9
    7076cdcff1c4:	mov    r9,r14
    7076cdcff1c7:	shr    r9,0x30
    7076cdcff1cb:	and    r9,0xff
    7076cdcff1d2:	and    r9,0xffff
    7076cdcff1d9:	shl    r9,0x20
    7076cdcff1dd:	or     r13,r9
    7076cdcff1e0:	shr    r14,0x38
    7076cdcff1e4:	and    r14,0xff
    7076cdcff1eb:	and    r14,0xffff
    7076cdcff1f2:	shl    r14,0x30
    7076cdcff1f6:	or     r13,r14
    7076cdcff1f9:	mov    r14d,0x0
    7076cdcff1ff:	mov    r9,r15
    7076cdcff202:	and    r9,0xff
    7076cdcff209:	and    r9,0xffff
    7076cdcff210:	mov    r8,r14
    7076cdcff213:	or     r8,r9
    7076cdcff216:	mov    r9,r15
    7076cdcff219:	shr    r9,0x8
    7076cdcff21d:	and    r9,0xff
    7076cdcff224:	and    r9,0xffff
    7076cdcff22b:	shl    r9,0x10
    7076cdcff22f:	or     r8,r9
    7076cdcff232:	mov    r9,r15
    7076cdcff235:	shr    r9,0x10
    7076cdcff239:	and    r9,0xff
    7076cdcff240:	and    r9,0xffff
    7076cdcff247:	shl    r9,0x20
    7076cdcff24b:	or     r8,r9
    7076cdcff24e:	mov    r9,r15
    7076cdcff251:	shr    r9,0x18
    7076cdcff255:	and    r9,0xff
    7076cdcff25c:	and    r9,0xffff
    7076cdcff263:	shl    r9,0x30
    7076cdcff267:	or     r8,r9
    7076cdcff26a:	mov    r9,r15
    7076cdcff26d:	shr    r9,0x20
    7076cdcff271:	and    r9,0xff
    7076cdcff278:	and    r9,0xffff
    7076cdcff27f:	or     r14,r9
    7076cdcff282:	mov    r9,r15
    7076cdcff285:	shr    r9,0x28
    7076cdcff289:	and    r9,0xff
    7076cdcff290:	and    r9,0xffff
    7076cdcff297:	shl    r9,0x10
    7076cdcff29b:	or     r14,r9
    7076cdcff29e:	mov    r9,r15
    7076cdcff2a1:	shr    r9,0x30
    7076cdcff2a5:	and    r9,0xff
    7076cdcff2ac:	and    r9,0xffff
    7076cdcff2b3:	shl    r9,0x20
    7076cdcff2b7:	or     r14,r9
    7076cdcff2ba:	shr    r15,0x38
    7076cdcff2be:	and    r15,0xff
    7076cdcff2c5:	and    r15,0xffff
    7076cdcff2cc:	shl    r15,0x30
    7076cdcff2d0:	or     r14,r15
    7076cdcff2d3:	mov    QWORD PTR [r12+0x210],r8
    7076cdcff2db:	mov    QWORD PTR [r12+0x218],r14
    7076cdcff2e3:	mov    r14d,0x0
    7076cdcff2e9:	mov    r15,rbp
    7076cdcff2ec:	and    r15,0xff
    7076cdcff2f3:	and    r15,0xffff
    7076cdcff2fa:	mov    r8,r14
    7076cdcff2fd:	or     r8,r15
    7076cdcff300:	mov    r15,rbp
    7076cdcff303:	shr    r15,0x8
    7076cdcff307:	and    r15,0xff
    7076cdcff30e:	and    r15,0xffff
    7076cdcff315:	shl    r15,0x10
    7076cdcff319:	or     r8,r15
    7076cdcff31c:	mov    r15,rbp
    7076cdcff31f:	shr    r15,0x10
    7076cdcff323:	and    r15,0xff
    7076cdcff32a:	and    r15,0xffff
    7076cdcff331:	shl    r15,0x20
    7076cdcff335:	or     r8,r15
    7076cdcff338:	mov    r15,rbp
    7076cdcff33b:	shr    r15,0x18
    7076cdcff33f:	and    r15,0xff
    7076cdcff346:	and    r15,0xffff
    7076cdcff34d:	shl    r15,0x30
    7076cdcff351:	or     r8,r15
    7076cdcff354:	mov    r15,rbp
    7076cdcff357:	shr    r15,0x20
    7076cdcff35b:	and    r15,0xff
    7076cdcff362:	and    r15,0xffff
    7076cdcff369:	or     r14,r15
    7076cdcff36c:	mov    r15,rbp
    7076cdcff36f:	shr    r15,0x28
    7076cdcff373:	and    r15,0xff
    7076cdcff37a:	and    r15,0xffff
    7076cdcff381:	shl    r15,0x10
    7076cdcff385:	or     r14,r15
    7076cdcff388:	mov    r15,rbp
    7076cdcff38b:	shr    r15,0x30
    7076cdcff38f:	and    r15,0xff
    7076cdcff396:	and    r15,0xffff
    7076cdcff39d:	shl    r15,0x20
    7076cdcff3a1:	or     r14,r15
    7076cdcff3a4:	shr    rbp,0x38
    7076cdcff3a8:	and    rbp,0xff
    7076cdcff3af:	and    rbp,0xffff
    7076cdcff3b6:	shl    rbp,0x30
    7076cdcff3ba:	or     r14,rbp
    7076cdcff3bd:	mov    r15d,0x0
    7076cdcff3c3:	mov    rbp,QWORD PTR [rsp+0x20]
    7076cdcff3c8:	and    rbp,0xff
    7076cdcff3cf:	and    rbp,0xffff
    7076cdcff3d6:	mov    r9,r15
    7076cdcff3d9:	or     r9,rbp
    7076cdcff3dc:	mov    rbp,QWORD PTR [rsp+0x20]
    7076cdcff3e1:	shr    rbp,0x8
    7076cdcff3e5:	and    rbp,0xff
    7076cdcff3ec:	and    rbp,0xffff
    7076cdcff3f3:	shl    rbp,0x10
    7076cdcff3f7:	or     r9,rbp
    7076cdcff3fa:	mov    rbp,QWORD PTR [rsp+0x20]
    7076cdcff3ff:	shr    rbp,0x10
    7076cdcff403:	and    rbp,0xff
    7076cdcff40a:	and    rbp,0xffff
    7076cdcff411:	shl    rbp,0x20
    7076cdcff415:	or     r9,rbp
    7076cdcff418:	mov    rbp,QWORD PTR [rsp+0x20]
    7076cdcff41d:	shr    rbp,0x18
    7076cdcff421:	and    rbp,0xff
    7076cdcff428:	and    rbp,0xffff
    7076cdcff42f:	shl    rbp,0x30
    7076cdcff433:	mov    rax,r9
    7076cdcff436:	or     rax,rbp
    7076cdcff439:	mov    QWORD PTR [rsp+0x78],rax
    7076cdcff43e:	mov    rbp,QWORD PTR [rsp+0x20]
    7076cdcff443:	shr    rbp,0x20
    7076cdcff447:	and    rbp,0xff
    7076cdcff44e:	and    rbp,0xffff
    7076cdcff455:	or     r15,rbp
    7076cdcff458:	mov    rbp,QWORD PTR [rsp+0x20]
    7076cdcff45d:	shr    rbp,0x28
    7076cdcff461:	and    rbp,0xff
    7076cdcff468:	and    rbp,0xffff
    7076cdcff46f:	shl    rbp,0x10
    7076cdcff473:	or     r15,rbp
    7076cdcff476:	mov    rbp,QWORD PTR [rsp+0x20]
    7076cdcff47b:	shr    rbp,0x30
    7076cdcff47f:	and    rbp,0xff
    7076cdcff486:	and    rbp,0xffff
    7076cdcff48d:	shl    rbp,0x20
    7076cdcff491:	or     r15,rbp
    7076cdcff494:	mov    rbp,QWORD PTR [rsp+0x20]
    7076cdcff499:	shr    rbp,0x38
    7076cdcff49d:	and    rbp,0xff
    7076cdcff4a4:	and    rbp,0xffff
    7076cdcff4ab:	shl    rbp,0x30
    7076cdcff4af:	mov    rax,r15
    7076cdcff4b2:	or     rax,rbp
    7076cdcff4b5:	mov    QWORD PTR [rsp+0x70],rax
    7076cdcff4ba:	mov    rax,QWORD PTR [rsp+0x78]
    7076cdcff4bf:	mov    QWORD PTR [r12+0x250],rax
    7076cdcff4c7:	mov    rax,QWORD PTR [rsp+0x70]
    7076cdcff4cc:	mov    QWORD PTR [r12+0x258],rax
    7076cdcff4d4:	mov    ebp,0x0
    7076cdcff4d9:	mov    r15,QWORD PTR [rsp+0x40]
    7076cdcff4de:	and    r15,0xff
    7076cdcff4e5:	and    r15,0xffff
    7076cdcff4ec:	mov    r9,rbp
    7076cdcff4ef:	or     r9,r15
    7076cdcff4f2:	mov    r15,QWORD PTR [rsp+0x40]
    7076cdcff4f7:	shr    r15,0x8
    7076cdcff4fb:	and    r15,0xff
    7076cdcff502:	and    r15,0xffff
    7076cdcff509:	shl    r15,0x10
    7076cdcff50d:	or     r9,r15
    7076cdcff510:	mov    r15,QWORD PTR [rsp+0x40]
    7076cdcff515:	shr    r15,0x10
    7076cdcff519:	and    r15,0xff
    7076cdcff520:	and    r15,0xffff
    7076cdcff527:	shl    r15,0x20
    7076cdcff52b:	or     r9,r15
    7076cdcff52e:	mov    r15,QWORD PTR [rsp+0x40]
    7076cdcff533:	shr    r15,0x18
    7076cdcff537:	and    r15,0xff
    7076cdcff53e:	and    r15,0xffff
    7076cdcff545:	shl    r15,0x30
    7076cdcff549:	mov    rax,r9
    7076cdcff54c:	or     rax,r15
    7076cdcff54f:	mov    QWORD PTR [rsp+0x80],rax
    7076cdcff557:	mov    r15,QWORD PTR [rsp+0x40]
    7076cdcff55c:	shr    r15,0x20
    7076cdcff560:	and    r15,0xff
    7076cdcff567:	and    r15,0xffff
    7076cdcff56e:	or     rbp,r15
    7076cdcff571:	mov    r15,QWORD PTR [rsp+0x40]
    7076cdcff576:	shr    r15,0x28
    7076cdcff57a:	and    r15,0xff
    7076cdcff581:	and    r15,0xffff
    7076cdcff588:	shl    r15,0x10
    7076cdcff58c:	or     rbp,r15
    7076cdcff58f:	mov    r15,QWORD PTR [rsp+0x40]
    7076cdcff594:	shr    r15,0x30
    7076cdcff598:	and    r15,0xff
    7076cdcff59f:	and    r15,0xffff
    7076cdcff5a6:	shl    r15,0x20
    7076cdcff5aa:	or     rbp,r15
    7076cdcff5ad:	mov    r15,QWORD PTR [rsp+0x40]
    7076cdcff5b2:	shr    r15,0x38
    7076cdcff5b6:	and    r15,0xff
    7076cdcff5bd:	and    r15,0xffff
    7076cdcff5c4:	shl    r15,0x30
    7076cdcff5c8:	mov    rax,rbp
    7076cdcff5cb:	or     rax,r15
    7076cdcff5ce:	mov    QWORD PTR [rsp+0x88],rax
    7076cdcff5d6:	movdqu xmm2,XMMWORD PTR [r12+0x150]
    7076cdcff5e0:	pxor   xmm0,xmm0
    7076cdcff5e4:	movdqa xmm3,xmm0
    7076cdcff5e8:	movdqa xmm0,xmm2
    7076cdcff5ec:	movdqa xmm1,xmm3
    7076cdcff5f0:	punpcklwd xmm0,xmm1
    7076cdcff5f4:	movdqa xmm4,xmm0
    7076cdcff5f8:	movdqa xmm0,xmm4
    7076cdcff5fc:	pslld  xmm0,0x10
    7076cdcff601:	movdqa xmm3,xmm0
    7076cdcff605:	mov    r15d,0x0
    7076cdcff60b:	mov    r9,QWORD PTR [rsp+0x50]
    7076cdcff610:	and    r9,0xffff
    7076cdcff617:	shl    r9,0x8
    7076cdcff61b:	mov    ecx,0xffffffff
    7076cdcff620:	and    r9,rcx
    7076cdcff623:	mov    rbp,r15
    7076cdcff626:	or     rbp,r9
    7076cdcff629:	mov    r9,QWORD PTR [rsp+0x50]
    7076cdcff62e:	shr    r9,0x10
    7076cdcff632:	and    r9,0xffff
    7076cdcff639:	shl    r9,0x8
    7076cdcff63d:	mov    ecx,0xffffffff
    7076cdcff642:	and    r9,rcx
    7076cdcff645:	shl    r9,0x20
    7076cdcff649:	or     rbp,r9
    7076cdcff64c:	mov    r9,QWORD PTR [rsp+0x50]
    7076cdcff651:	shr    r9,0x20
    7076cdcff655:	and    r9,0xffff
    7076cdcff65c:	shl    r9,0x8
    7076cdcff660:	mov    ecx,0xffffffff
    7076cdcff665:	and    r9,rcx
    7076cdcff668:	or     r15,r9
    7076cdcff66b:	mov    r9,QWORD PTR [rsp+0x50]
    7076cdcff670:	shr    r9,0x30
    7076cdcff674:	and    r9,0xffff
    7076cdcff67b:	shl    r9,0x8
    7076cdcff67f:	mov    ecx,0xffffffff
    7076cdcff684:	and    r9,rcx
    7076cdcff687:	shl    r9,0x20
    7076cdcff68b:	or     r15,r9
    7076cdcff68e:	mov    QWORD PTR [r12+0x240],rbp
    7076cdcff696:	mov    QWORD PTR [r12+0x248],r15
    7076cdcff69e:	mov    r15d,0x0
    7076cdcff6a4:	mov    rbp,QWORD PTR [rsp+0x60]
    7076cdcff6a9:	and    rbp,0xffff
    7076cdcff6b0:	mov    ecx,0xffffffff
    7076cdcff6b5:	and    rbp,rcx
    7076cdcff6b8:	mov    r9,r15
    7076cdcff6bb:	or     r9,rbp
    7076cdcff6be:	mov    rbp,QWORD PTR [rsp+0x60]
    7076cdcff6c3:	shr    rbp,0x10
    7076cdcff6c7:	and    rbp,0xffff
    7076cdcff6ce:	mov    ecx,0xffffffff
    7076cdcff6d3:	and    rbp,rcx
    7076cdcff6d6:	shl    rbp,0x20
    7076cdcff6da:	or     r9,rbp
    7076cdcff6dd:	mov    rbp,QWORD PTR [rsp+0x60]
    7076cdcff6e2:	shr    rbp,0x20
    7076cdcff6e6:	and    rbp,0xffff
    7076cdcff6ed:	mov    ecx,0xffffffff
    7076cdcff6f2:	and    rbp,rcx
    7076cdcff6f5:	or     r15,rbp
    7076cdcff6f8:	mov    rbp,QWORD PTR [rsp+0x60]
    7076cdcff6fd:	shr    rbp,0x30
    7076cdcff701:	and    rbp,0xffff
    7076cdcff708:	mov    ecx,0xffffffff
    7076cdcff70d:	and    rbp,rcx
    7076cdcff710:	shl    rbp,0x20
    7076cdcff714:	or     r15,rbp
    7076cdcff717:	mov    QWORD PTR [r12+0x260],r9
    7076cdcff71f:	mov    QWORD PTR [r12+0x268],r15
    7076cdcff727:	mov    r15d,0x0
    7076cdcff72d:	mov    rbp,r13
    7076cdcff730:	and    rbp,0xffff
    7076cdcff737:	mov    ecx,0xffffffff
    7076cdcff73c:	and    rbp,rcx
    7076cdcff73f:	mov    r9,r15
    7076cdcff742:	or     r9,rbp
    7076cdcff745:	mov    rbp,r13
    7076cdcff748:	shr    rbp,0x10
    7076cdcff74c:	and    rbp,0xffff
    7076cdcff753:	mov    ecx,0xffffffff
    7076cdcff758:	and    rbp,rcx
    7076cdcff75b:	shl    rbp,0x20
    7076cdcff75f:	or     r9,rbp
    7076cdcff762:	mov    rbp,r13
    7076cdcff765:	shr    rbp,0x20
    7076cdcff769:	and    rbp,0xffff
    7076cdcff770:	mov    ecx,0xffffffff
    7076cdcff775:	and    rbp,rcx
    7076cdcff778:	or     r15,rbp
    7076cdcff77b:	shr    r13,0x30
    7076cdcff77f:	and    r13,0xffff
    7076cdcff786:	mov    ecx,0xffffffff
    7076cdcff78b:	and    r13,rcx
    7076cdcff78e:	shl    r13,0x20
    7076cdcff792:	or     r15,r13
    7076cdcff795:	mov    QWORD PTR [r12+0x270],r9
    7076cdcff79d:	mov    QWORD PTR [r12+0x278],r15
    7076cdcff7a5:	mov    r13d,0x0
    7076cdcff7ab:	mov    r15,QWORD PTR [rsp+0x58]
    7076cdcff7b0:	and    r15,0xffff
    7076cdcff7b7:	mov    ecx,0xffffffff
    7076cdcff7bc:	and    r15,rcx
    7076cdcff7bf:	mov    rbp,r13
    7076cdcff7c2:	or     rbp,r15
    7076cdcff7c5:	mov    r15,QWORD PTR [rsp+0x58]
    7076cdcff7ca:	shr    r15,0x10
    7076cdcff7ce:	and    r15,0xffff
    7076cdcff7d5:	mov    ecx,0xffffffff
    7076cdcff7da:	and    r15,rcx
    7076cdcff7dd:	shl    r15,0x20
    7076cdcff7e1:	or     rbp,r15
    7076cdcff7e4:	mov    r15,QWORD PTR [rsp+0x58]
    7076cdcff7e9:	shr    r15,0x20
    7076cdcff7ed:	and    r15,0xffff
    7076cdcff7f4:	mov    ecx,0xffffffff
    7076cdcff7f9:	and    r15,rcx
    7076cdcff7fc:	or     r13,r15
    7076cdcff7ff:	mov    r15,QWORD PTR [rsp+0x58]
    7076cdcff804:	shr    r15,0x30
    7076cdcff808:	and    r15,0xffff
    7076cdcff80f:	mov    ecx,0xffffffff
    7076cdcff814:	and    r15,rcx
    7076cdcff817:	shl    r15,0x20
    7076cdcff81b:	or     r13,r15
    7076cdcff81e:	mov    QWORD PTR [r12+0x170],rbp
    7076cdcff826:	mov    QWORD PTR [r12+0x178],r13
    7076cdcff82e:	movdqu xmm4,XMMWORD PTR [r12+0x210]
    7076cdcff838:	pxor   xmm0,xmm0
    7076cdcff83c:	movdqa xmm5,xmm0
    7076cdcff840:	movdqa xmm0,xmm4
    7076cdcff844:	movdqa xmm1,xmm5
    7076cdcff848:	punpckhwd xmm0,xmm1
    7076cdcff84c:	movdqa xmm6,xmm0
    7076cdcff850:	movdqa xmm0,xmm6
    7076cdcff854:	pslld  xmm0,0x10
    7076cdcff859:	movdqa xmm5,xmm0
    7076cdcff85d:	movdqu XMMWORD PTR [r12+0x280],xmm5
    7076cdcff867:	mov    r13d,0x0
    7076cdcff86d:	mov    r15,QWORD PTR [rsp+0x68]
    7076cdcff872:	and    r15,0xffff
    7076cdcff879:	mov    ecx,0xffffffff
    7076cdcff87e:	and    r15,rcx
    7076cdcff881:	mov    rbp,r13
    7076cdcff884:	or     rbp,r15
    7076cdcff887:	mov    r15,QWORD PTR [rsp+0x68]
    7076cdcff88c:	shr    r15,0x10
    7076cdcff890:	and    r15,0xffff
    7076cdcff897:	mov    ecx,0xffffffff
    7076cdcff89c:	and    r15,rcx
    7076cdcff89f:	shl    r15,0x20
    7076cdcff8a3:	or     rbp,r15
    7076cdcff8a6:	mov    r15,QWORD PTR [rsp+0x68]
    7076cdcff8ab:	shr    r15,0x20
    7076cdcff8af:	and    r15,0xffff
    7076cdcff8b6:	mov    ecx,0xffffffff
    7076cdcff8bb:	and    r15,rcx
    7076cdcff8be:	or     r13,r15
    7076cdcff8c1:	mov    r15,QWORD PTR [rsp+0x68]
    7076cdcff8c6:	shr    r15,0x30
    7076cdcff8ca:	and    r15,0xffff
    7076cdcff8d1:	mov    ecx,0xffffffff
    7076cdcff8d6:	and    r15,rcx
    7076cdcff8d9:	shl    r15,0x20
    7076cdcff8dd:	or     r13,r15
    7076cdcff8e0:	mov    QWORD PTR [r12+0x180],rbp
    7076cdcff8e8:	mov    QWORD PTR [r12+0x188],r13
    7076cdcff8f0:	pxor   xmm0,xmm0
    7076cdcff8f4:	movdqa xmm6,xmm0
    7076cdcff8f8:	movdqa xmm0,xmm4
    7076cdcff8fc:	movdqa xmm1,xmm6
    7076cdcff900:	punpcklwd xmm0,xmm1
    7076cdcff904:	movdqa xmm7,xmm0
    7076cdcff908:	movdqa xmm0,xmm7
    7076cdcff90c:	pslld  xmm0,0x10
    7076cdcff911:	movdqa xmm4,xmm0
    7076cdcff915:	pxor   xmm0,xmm0
    7076cdcff919:	movdqa xmm6,xmm0
    7076cdcff91d:	movdqa xmm0,xmm2
    7076cdcff921:	movdqa xmm1,xmm6
    7076cdcff925:	punpckhwd xmm0,xmm1
    7076cdcff929:	movdqa xmm7,xmm0
    7076cdcff92d:	movdqa xmm0,xmm7
    7076cdcff931:	pslld  xmm0,0x10
    7076cdcff936:	movdqa xmm2,xmm0
    7076cdcff93a:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    7076cdcff944:	movdqa xmm1,xmm6
    7076cdcff948:	por    xmm3,xmm1
    7076cdcff94c:	movdqu XMMWORD PTR [r12+0x230],xmm3
    7076cdcff956:	mov    r13d,0x0
    7076cdcff95c:	mov    r15,r14
    7076cdcff95f:	and    r15,0xffff
    7076cdcff966:	shl    r15,0x8
    7076cdcff96a:	mov    ecx,0xffffffff
    7076cdcff96f:	and    r15,rcx
    7076cdcff972:	mov    rbp,r13
    7076cdcff975:	or     rbp,r15
    7076cdcff978:	mov    r15,r14
    7076cdcff97b:	shr    r15,0x10
    7076cdcff97f:	and    r15,0xffff
    7076cdcff986:	shl    r15,0x8
    7076cdcff98a:	mov    ecx,0xffffffff
    7076cdcff98f:	and    r15,rcx
    7076cdcff992:	shl    r15,0x20
    7076cdcff996:	or     rbp,r15
    7076cdcff999:	mov    r15,r14
    7076cdcff99c:	shr    r15,0x20
    7076cdcff9a0:	and    r15,0xffff
    7076cdcff9a7:	shl    r15,0x8
    7076cdcff9ab:	mov    ecx,0xffffffff
    7076cdcff9b0:	and    r15,rcx
    7076cdcff9b3:	or     r13,r15
    7076cdcff9b6:	shr    r14,0x30
    7076cdcff9ba:	and    r14,0xffff
    7076cdcff9c1:	shl    r14,0x8
    7076cdcff9c5:	mov    ecx,0xffffffff
    7076cdcff9ca:	and    r14,rcx
    7076cdcff9cd:	shl    r14,0x20
    7076cdcff9d1:	or     r13,r14
    7076cdcff9d4:	mov    QWORD PTR [r12+0x240],rbp
    7076cdcff9dc:	mov    QWORD PTR [r12+0x248],r13
    7076cdcff9e4:	mov    r13d,0x0
    7076cdcff9ea:	mov    r14,r8
    7076cdcff9ed:	and    r14,0xffff
    7076cdcff9f4:	shl    r14,0x8
    7076cdcff9f8:	mov    ecx,0xffffffff
    7076cdcff9fd:	and    r14,rcx
    7076cdcffa00:	mov    r15,r13
    7076cdcffa03:	or     r15,r14
    7076cdcffa06:	mov    r14,r8
    7076cdcffa09:	shr    r14,0x10
    7076cdcffa0d:	and    r14,0xffff
    7076cdcffa14:	shl    r14,0x8
    7076cdcffa18:	mov    ecx,0xffffffff
    7076cdcffa1d:	and    r14,rcx
    7076cdcffa20:	shl    r14,0x20
    7076cdcffa24:	or     r15,r14
    7076cdcffa27:	mov    r14,r8
    7076cdcffa2a:	shr    r14,0x20
    7076cdcffa2e:	and    r14,0xffff
    7076cdcffa35:	shl    r14,0x8
    7076cdcffa39:	mov    ecx,0xffffffff
    7076cdcffa3e:	and    r14,rcx
    7076cdcffa41:	or     r13,r14
    7076cdcffa44:	shr    r8,0x30
    7076cdcffa48:	and    r8,0xffff
    7076cdcffa4f:	shl    r8,0x8
    7076cdcffa53:	mov    ecx,0xffffffff
    7076cdcffa58:	and    r8,rcx
    7076cdcffa5b:	shl    r8,0x20
    7076cdcffa5f:	or     r13,r8
    7076cdcffa62:	mov    QWORD PTR [r12+0x220],r15
    7076cdcffa6a:	mov    QWORD PTR [r12+0x228],r13
    7076cdcffa72:	mov    r13d,0x0
    7076cdcffa78:	mov    r14,QWORD PTR [rsp+0x48]
    7076cdcffa7d:	and    r14,0xffff
    7076cdcffa84:	shl    r14,0x8
    7076cdcffa88:	mov    ecx,0xffffffff
    7076cdcffa8d:	and    r14,rcx
    7076cdcffa90:	mov    r15,r13
    7076cdcffa93:	or     r15,r14
    7076cdcffa96:	mov    r14,QWORD PTR [rsp+0x48]
    7076cdcffa9b:	shr    r14,0x10
    7076cdcffa9f:	and    r14,0xffff
    7076cdcffaa6:	shl    r14,0x8
    7076cdcffaaa:	mov    ecx,0xffffffff
    7076cdcffaaf:	and    r14,rcx
    7076cdcffab2:	shl    r14,0x20
    7076cdcffab6:	or     r15,r14
    7076cdcffab9:	mov    r14,QWORD PTR [rsp+0x48]
    7076cdcffabe:	shr    r14,0x20
    7076cdcffac2:	and    r14,0xffff
    7076cdcffac9:	shl    r14,0x8
    7076cdcffacd:	mov    ecx,0xffffffff
    7076cdcffad2:	and    r14,rcx
    7076cdcffad5:	or     r13,r14
    7076cdcffad8:	mov    r14,QWORD PTR [rsp+0x48]
    7076cdcffadd:	shr    r14,0x30
    7076cdcffae1:	and    r14,0xffff
    7076cdcffae8:	shl    r14,0x8
    7076cdcffaec:	mov    ecx,0xffffffff
    7076cdcffaf1:	and    r14,rcx
    7076cdcffaf4:	shl    r14,0x20
    7076cdcffaf8:	or     r13,r14
    7076cdcffafb:	mov    QWORD PTR [r12+0x160],r15
    7076cdcffb03:	mov    QWORD PTR [r12+0x168],r13
    7076cdcffb0b:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    7076cdcffb15:	movdqa xmm0,xmm6
    7076cdcffb19:	pslld  xmm0,0x18
    7076cdcffb1e:	movdqa xmm7,xmm0
    7076cdcffb22:	movdqu XMMWORD PTR [r12+0x170],xmm7
    7076cdcffb2c:	movdqu xmm6,XMMWORD PTR [r12+0x270]
    7076cdcffb36:	movdqa xmm0,xmm6
    7076cdcffb3a:	pslld  xmm0,0x18
    7076cdcffb3f:	movdqa xmm8,xmm0
    7076cdcffb44:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    7076cdcffb4e:	movdqa xmm0,xmm6
    7076cdcffb52:	pslld  xmm0,0x18
    7076cdcffb57:	movdqa xmm9,xmm0
    7076cdcffb5c:	movdqu XMMWORD PTR [r12+0x180],xmm9
    7076cdcffb66:	mov    r13d,0x0
    7076cdcffb6c:	mov    r14,QWORD PTR [rsp+0x78]
    7076cdcffb71:	and    r14,0xffff
    7076cdcffb78:	mov    ecx,0xffffffff
    7076cdcffb7d:	and    r14,rcx
    7076cdcffb80:	mov    r15,r13
    7076cdcffb83:	or     r15,r14
    7076cdcffb86:	mov    r14,QWORD PTR [rsp+0x78]
    7076cdcffb8b:	shr    r14,0x10
    7076cdcffb8f:	and    r14,0xffff
    7076cdcffb96:	mov    ecx,0xffffffff
    7076cdcffb9b:	and    r14,rcx
    7076cdcffb9e:	shl    r14,0x20
    7076cdcffba2:	or     r15,r14
    7076cdcffba5:	mov    r14,QWORD PTR [rsp+0x78]
    7076cdcffbaa:	shr    r14,0x20
    7076cdcffbae:	and    r14,0xffff
    7076cdcffbb5:	mov    ecx,0xffffffff
    7076cdcffbba:	and    r14,rcx
    7076cdcffbbd:	or     r13,r14
    7076cdcffbc0:	mov    r14,QWORD PTR [rsp+0x78]
    7076cdcffbc5:	shr    r14,0x30
    7076cdcffbc9:	and    r14,0xffff
    7076cdcffbd0:	mov    ecx,0xffffffff
    7076cdcffbd5:	and    r14,rcx
    7076cdcffbd8:	shl    r14,0x20
    7076cdcffbdc:	or     r13,r14
    7076cdcffbdf:	mov    QWORD PTR [r12+0x140],r15
    7076cdcffbe7:	mov    QWORD PTR [r12+0x148],r13
    7076cdcffbef:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    7076cdcffbf9:	movdqa xmm1,xmm6
    7076cdcffbfd:	por    xmm5,xmm1
    7076cdcffc01:	movdqu xmm6,XMMWORD PTR [r12+0x220]
    7076cdcffc0b:	movdqa xmm1,xmm6
    7076cdcffc0f:	por    xmm4,xmm1
    7076cdcffc13:	movdqu XMMWORD PTR [r12+0x210],xmm4
    7076cdcffc1d:	movdqu xmm6,XMMWORD PTR [r12+0x260]
    7076cdcffc27:	movdqa xmm0,xmm6
    7076cdcffc2b:	pslld  xmm0,0x18
    7076cdcffc30:	movdqa xmm10,xmm0
    7076cdcffc35:	movdqu XMMWORD PTR [r12+0x220],xmm10
    7076cdcffc3f:	movdqu xmm6,XMMWORD PTR [r12+0x160]
    7076cdcffc49:	movdqa xmm1,xmm6
    7076cdcffc4d:	por    xmm2,xmm1
    7076cdcffc51:	movdqa xmm1,xmm7
    7076cdcffc55:	por    xmm3,xmm1
    7076cdcffc59:	movdqu XMMWORD PTR [r12+0x160],xmm3
    7076cdcffc63:	mov    r13d,0x0
    7076cdcffc69:	mov    r14,QWORD PTR [rsp+0x88]
    7076cdcffc71:	and    r14,0xffff
    7076cdcffc78:	mov    ecx,0xffffffff
    7076cdcffc7d:	and    r14,rcx
    7076cdcffc80:	mov    r15,r13
    7076cdcffc83:	or     r15,r14
    7076cdcffc86:	mov    r14,QWORD PTR [rsp+0x88]
    7076cdcffc8e:	shr    r14,0x10
    7076cdcffc92:	and    r14,0xffff
    7076cdcffc99:	mov    ecx,0xffffffff
    7076cdcffc9e:	and    r14,rcx
    7076cdcffca1:	shl    r14,0x20
    7076cdcffca5:	or     r15,r14
    7076cdcffca8:	mov    r14,QWORD PTR [rsp+0x88]
    7076cdcffcb0:	shr    r14,0x20
    7076cdcffcb4:	and    r14,0xffff
    7076cdcffcbb:	mov    ecx,0xffffffff
    7076cdcffcc0:	and    r14,rcx
    7076cdcffcc3:	or     r13,r14
    7076cdcffcc6:	mov    r14,QWORD PTR [rsp+0x88]
    7076cdcffcce:	shr    r14,0x30
    7076cdcffcd2:	and    r14,0xffff
    7076cdcffcd9:	mov    ecx,0xffffffff
    7076cdcffcde:	and    r14,rcx
    7076cdcffce1:	shl    r14,0x20
    7076cdcffce5:	or     r13,r14
    7076cdcffce8:	mov    QWORD PTR [r12+0x170],r15
    7076cdcffcf0:	mov    QWORD PTR [r12+0x178],r13
    7076cdcffcf8:	mov    r13d,0x0
    7076cdcffcfe:	mov    r14,QWORD PTR [rsp+0x80]
    7076cdcffd06:	and    r14,0xffff
    7076cdcffd0d:	mov    ecx,0xffffffff
    7076cdcffd12:	and    r14,rcx
    7076cdcffd15:	mov    r15,r13
    7076cdcffd18:	or     r15,r14
    7076cdcffd1b:	mov    r14,QWORD PTR [rsp+0x80]
    7076cdcffd23:	shr    r14,0x10
    7076cdcffd27:	and    r14,0xffff
    7076cdcffd2e:	mov    ecx,0xffffffff
    7076cdcffd33:	and    r14,rcx
    7076cdcffd36:	shl    r14,0x20
    7076cdcffd3a:	or     r15,r14
    7076cdcffd3d:	mov    r14,QWORD PTR [rsp+0x80]
    7076cdcffd45:	shr    r14,0x20
    7076cdcffd49:	and    r14,0xffff
    7076cdcffd50:	mov    ecx,0xffffffff
    7076cdcffd55:	and    r14,rcx
    7076cdcffd58:	or     r13,r14
    7076cdcffd5b:	mov    r14,QWORD PTR [rsp+0x80]
    7076cdcffd63:	shr    r14,0x30
    7076cdcffd67:	and    r14,0xffff
    7076cdcffd6e:	mov    ecx,0xffffffff
    7076cdcffd73:	and    r14,rcx
    7076cdcffd76:	shl    r14,0x20
    7076cdcffd7a:	or     r13,r14
    7076cdcffd7d:	mov    QWORD PTR [r12+0x110],r15
    7076cdcffd85:	mov    QWORD PTR [r12+0x118],r13
    7076cdcffd8d:	movdqa xmm1,xmm8
    7076cdcffd92:	por    xmm5,xmm1
    7076cdcffd96:	movdqa xmm1,xmm9
    7076cdcffd9b:	por    xmm4,xmm1
    7076cdcffd9f:	mov    r13d,0x0
    7076cdcffda5:	mov    r14,QWORD PTR [rsp+0x70]
    7076cdcffdaa:	and    r14,0xffff
    7076cdcffdb1:	mov    ecx,0xffffffff
    7076cdcffdb6:	and    r14,rcx
    7076cdcffdb9:	mov    r15,r13
    7076cdcffdbc:	or     r15,r14
    7076cdcffdbf:	mov    r14,QWORD PTR [rsp+0x70]
    7076cdcffdc4:	shr    r14,0x10
    7076cdcffdc8:	and    r14,0xffff
    7076cdcffdcf:	mov    ecx,0xffffffff
    7076cdcffdd4:	and    r14,rcx
    7076cdcffdd7:	shl    r14,0x20
    7076cdcffddb:	or     r15,r14
    7076cdcffdde:	mov    r14,QWORD PTR [rsp+0x70]
    7076cdcffde3:	shr    r14,0x20
    7076cdcffde7:	and    r14,0xffff
    7076cdcffdee:	mov    ecx,0xffffffff
    7076cdcffdf3:	and    r14,rcx
    7076cdcffdf6:	or     r13,r14
    7076cdcffdf9:	mov    r14,QWORD PTR [rsp+0x70]
    7076cdcffdfe:	shr    r14,0x30
    7076cdcffe02:	and    r14,0xffff
    7076cdcffe09:	mov    ecx,0xffffffff
    7076cdcffe0e:	and    r14,rcx
    7076cdcffe11:	shl    r14,0x20
    7076cdcffe15:	or     r13,r14
    7076cdcffe18:	mov    QWORD PTR [r12+0x180],r15
    7076cdcffe20:	mov    QWORD PTR [r12+0x188],r13
    7076cdcffe28:	movdqa xmm1,xmm10
    7076cdcffe2d:	por    xmm2,xmm1
    7076cdcffe31:	movdqu XMMWORD PTR [r12+0x150],xmm2
    7076cdcffe3b:	movdqu xmm6,XMMWORD PTR [r12+0x140]
    7076cdcffe45:	movdqa xmm1,xmm6
    7076cdcffe49:	por    xmm3,xmm1
    7076cdcffe4d:	movdqu XMMWORD PTR [r12+0x140],xmm3
    7076cdcffe57:	movdqu xmm6,XMMWORD PTR [r12+0x110]
    7076cdcffe61:	movdqa xmm1,xmm6
    7076cdcffe65:	por    xmm4,xmm1
    7076cdcffe69:	movdqu XMMWORD PTR [r12+0x110],xmm4
    7076cdcffe73:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    7076cdcffe7d:	movdqa xmm1,xmm6
    7076cdcffe81:	por    xmm5,xmm1
    7076cdcffe85:	movdqu XMMWORD PTR [r12+0x120],xmm5
    7076cdcffe8f:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    7076cdcffe99:	movdqa xmm1,xmm6
    7076cdcffe9d:	por    xmm2,xmm1
    7076cdcffea1:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7076cdcffeab:	mov    r13,QWORD PTR [r12+0xf8]
    7076cdcffeb3:	mov    r14,r13
    7076cdcffeb6:	add    r14,0x20
    7076cdcffeba:	mov    r15,r14
    7076cdcffebd:	add    r15,0x10
    7076cdcffec1:	movdqu XMMWORD PTR [r14],xmm4
    7076cdcffec6:	mov    r14d,0x0
    7076cdcffecc:	mov    DWORD PTR [r12+0x32c],r14d
    7076cdcffed4:	movdqu XMMWORD PTR [r15],xmm5
    7076cdcffed9:	mov    r14,r13
    7076cdcffedc:	add    r14,0x10
    7076cdcffee0:	movdqu XMMWORD PTR [r13+0x0],xmm3
    7076cdcffee6:	movdqu XMMWORD PTR [r14],xmm2
    7076cdcffeeb:	mov    r14d,DWORD PTR [r13+0x0]
    7076cdcffeef:	mov    QWORD PTR [r12+0x60],r14
    7076cdcffef4:	jmp    0x7076cdcffef9
    7076cdcffef9:	mov    r13,QWORD PTR [r12+0x58]
    7076cdcffefe:	mov    r14,QWORD PTR [r12+0x48]
    7076cdcfff03:	add    r14,r13
    7076cdcfff06:	mov    QWORD PTR [r12+0x68],r14
    7076cdcfff0b:	add    r13,0x4
    7076cdcfff0f:	mov    QWORD PTR [r12+0x58],r13
    7076cdcfff14:	mov    r15,r14
    7076cdcfff17:	add    r15,0x4
    7076cdcfff1b:	mov    eax,DWORD PTR [r15]
    7076cdcfff1e:	mov    QWORD PTR [r12+0x70],rax
    7076cdcfff23:	mov    r15,r14
    7076cdcfff26:	add    r15,0x38
    7076cdcfff2a:	mov    r8d,DWORD PTR [r15]
    7076cdcfff2d:	mov    QWORD PTR [r12+0x78],r8
    7076cdcfff32:	mov    r15,r14
    7076cdcfff35:	add    r15,0x24
    7076cdcfff39:	mov    r9d,DWORD PTR [r15]
    7076cdcfff3c:	mov    QWORD PTR [r12+0x90],r9
    7076cdcfff44:	sub    r13,0xc0
    7076cdcfff4b:	setne  BYTE PTR [rsp+0xb8]
    7076cdcfff53:	mov    r11,rax
    7076cdcfff56:	lahf
    7076cdcfff57:	seto   al
    7076cdcfff5a:	mov    WORD PTR [rsp+0xb0],ax
    7076cdcfff62:	mov    rax,r11
    7076cdcfff65:	mov    r13d,DWORD PTR [r12+0x70]
    7076cdcfff6a:	mov    r13d,r13d
    7076cdcfff6d:	mov    r13d,r13d
    7076cdcfff70:	ror    r13d,0x7
    7076cdcfff74:	mov    QWORD PTR [r12+0x80],r13
    7076cdcfff7c:	mov    r15d,r8d
    7076cdcfff7f:	mov    r15d,r15d
    7076cdcfff82:	ror    r15d,0x11
    7076cdcfff86:	mov    QWORD PTR [r12+0x88],r15
    7076cdcfff8e:	mov    ebp,DWORD PTR [r12+0x60]
    7076cdcfff93:	add    r9d,ebp
    7076cdcfff96:	mov    QWORD PTR [r12+0x60],r9
    7076cdcfff9b:	mov    ebp,DWORD PTR [r12+0x70]
    7076cdcfffa0:	mov    ebp,ebp
    7076cdcfffa2:	mov    ebp,ebp
    7076cdcfffa4:	ror    ebp,0x12
    7076cdcfffa7:	xor    r13d,ebp
    7076cdcfffaa:	mov    QWORD PTR [r12+0x80],r13
    7076cdcfffb2:	mov    ebp,r8d
    7076cdcfffb5:	mov    ebp,ebp
    7076cdcfffb7:	ror    ebp,0x13
    7076cdcfffba:	xor    r15d,ebp
    7076cdcfffbd:	mov    QWORD PTR [r12+0x88],r15
    7076cdcfffc5:	mov    ebp,DWORD PTR [r12+0x70]
    7076cdcfffca:	mov    ebp,ebp
    7076cdcfffcc:	mov    ebp,ebp
    7076cdcfffce:	shr    ebp,0x3
    7076cdcfffd1:	xor    r13d,ebp
    7076cdcfffd4:	mov    QWORD PTR [r12+0x80],r13
    7076cdcfffdc:	mov    r8d,r8d
    7076cdcfffdf:	shr    r8d,0xa
    7076cdcfffe3:	xor    r15d,r8d
    7076cdcfffe6:	mov    QWORD PTR [r12+0x78],r15
    7076cdcfffeb:	add    r9d,r13d
    7076cdcfffee:	mov    QWORD PTR [r12+0x60],r9
    7076cdcffff3:	add    r9d,r15d
    7076cdcffff6:	mov    QWORD PTR [r12+0x60],r9
    7076cdcffffb:	add    r14,0x40
    7076cdcfffff:	mov    DWORD PTR [r14],r9d
    7076cdd00002:	mov    r13d,0x0
    7076cdd00008:	mov    DWORD PTR [r12+0x32c],r13d
    7076cdd00010:	mov    r13d,0x0
    7076cdd00016:	mov    ecx,DWORD PTR [r12+0x70]
    7076cdd0001b:	mov    ecx,ecx
    7076cdd0001d:	mov    r14d,r13d
    7076cdd00020:	or     r14d,ecx
    7076cdd00023:	mov    QWORD PTR [r12+0x60],r14
    7076cdd00028:	mov    rcx,QWORD PTR [r12+0x380]
    7076cdd00030:	jrcxz  0x7076cdd00037
    7076cdd00032:	jmp    0x7076cdd0081a
    7076cdd00037:	cmp    BYTE PTR [rsp+0xb8],0x0
    7076cdd0003f:	jne    0x7076cdcffef9
    7076cdd00045:	jmp    0x7076cdd0004a
    7076cdd0004a:	mov    r13,QWORD PTR [r12]
    7076cdd0004e:	mov    r14,r13
    7076cdd00051:	add    r14,0x4
    7076cdd00055:	mov    r15d,DWORD PTR [r13+0x0]
    7076cdd00059:	mov    ebp,DWORD PTR [r14]
    7076cdd0005c:	mov    QWORD PTR [r12+0x78],r15
    7076cdd00061:	mov    QWORD PTR [r12+0x80],rbp
    7076cdd00069:	mov    r14,r13
    7076cdd0006c:	add    r14,0x8
    7076cdd00070:	mov    r8,r14
    7076cdd00073:	add    r8,0x4
    7076cdd00077:	mov    r9d,DWORD PTR [r14]
    7076cdd0007a:	mov    eax,DWORD PTR [r8]
    7076cdd0007d:	mov    QWORD PTR [rsp+0x90],rax
    7076cdd00085:	mov    QWORD PTR [r12+0x70],r9
    7076cdd0008a:	mov    rax,QWORD PTR [rsp+0x90]
    7076cdd00092:	mov    QWORD PTR [r12+0x68],rax
    7076cdd00097:	mov    r8,r13
    7076cdd0009a:	add    r8,0x18
    7076cdd0009e:	mov    r14,r8
    7076cdd000a1:	add    r14,0x4
    7076cdd000a5:	mov    eax,DWORD PTR [r8]
    7076cdd000a8:	mov    QWORD PTR [rsp+0x98],rax
    7076cdd000b0:	mov    r8d,DWORD PTR [r14]
    7076cdd000b3:	mov    rax,QWORD PTR [rsp+0x98]
    7076cdd000bb:	mov    QWORD PTR [r12+0x58],rax
    7076cdd000c0:	mov    QWORD PTR [r12+0x60],r8
    7076cdd000c5:	add    r13,0x10
    7076cdd000c9:	mov    r14,r13
    7076cdd000cc:	add    r14,0x4
    7076cdd000d0:	mov    eax,DWORD PTR [r13+0x0]
    7076cdd000d4:	mov    QWORD PTR [rsp+0xa0],rax
    7076cdd000dc:	mov    eax,DWORD PTR [r14]
    7076cdd000df:	mov    QWORD PTR [rsp+0xa8],rax
    7076cdd000e7:	mov    rax,QWORD PTR [rsp+0xa0]
    7076cdd000ef:	mov    QWORD PTR [r12+0x18],rax
    7076cdd000f4:	mov    rax,QWORD PTR [rsp+0xa8]
    7076cdd000fc:	mov    QWORD PTR [r12+0x90],rax
    7076cdd00104:	mov    r14d,0x0
    7076cdd0010a:	mov    QWORD PTR [r12+0x88],r14
    7076cdd00112:	mov    r14d,0x0
    7076cdd00118:	mov    r13d,r14d
    7076cdd0011b:	or     r13d,r15d
    7076cdd0011e:	mov    QWORD PTR [r12+0xa8],r13
    7076cdd00126:	mov    r13d,0x0
    7076cdd0012c:	mov    r14d,r13d
    7076cdd0012f:	or     r14d,ebp
    7076cdd00132:	mov    QWORD PTR [r12+0x38],r14
    7076cdd00137:	mov    r13d,0x0
    7076cdd0013d:	mov    r14d,r13d
    7076cdd00140:	or     r14d,r9d
    7076cdd00143:	mov    QWORD PTR [r12+0x98],r14
    7076cdd0014b:	mov    r13d,0x0
    7076cdd00151:	mov    ecx,DWORD PTR [rsp+0x90]
    7076cdd00158:	mov    r14d,r13d
    7076cdd0015b:	or     r14d,ecx
    7076cdd0015e:	mov    QWORD PTR [r12+0x28],r14
    7076cdd00163:	mov    r13d,0x0
    7076cdd00169:	mov    r14d,r13d
    7076cdd0016c:	or     r14d,r8d
    7076cdd0016f:	mov    QWORD PTR [r12+0xb0],r14
    7076cdd00177:	mov    r13d,0x0
    7076cdd0017d:	mov    ecx,DWORD PTR [rsp+0x98]
    7076cdd00184:	mov    r14d,r13d
    7076cdd00187:	or     r14d,ecx
    7076cdd0018a:	mov    QWORD PTR [r12+0xc0],r14
    7076cdd00192:	mov    r13d,0x0
    7076cdd00198:	mov    ecx,DWORD PTR [rsp+0xa8]
    7076cdd0019f:	mov    r14d,r13d
    7076cdd001a2:	or     r14d,ecx
    7076cdd001a5:	mov    QWORD PTR [r12+0xc8],r14
    7076cdd001ad:	mov    r13d,0x0
    7076cdd001b3:	mov    ecx,DWORD PTR [rsp+0xa0]
    7076cdd001ba:	mov    r14d,r13d
    7076cdd001bd:	or     r14d,ecx
    7076cdd001c0:	mov    QWORD PTR [r12+0xb8],r14
    7076cdd001c8:	jmp    0x7076cdd001cd
    7076cdd001cd:	mov    r13d,0x0
    7076cdd001d3:	mov    r14d,DWORD PTR [r12+0xb8]
    7076cdd001db:	mov    eax,r13d
    7076cdd001de:	or     eax,r14d
    7076cdd001e1:	mov    QWORD PTR [r12+0x30],rax
    7076cdd001e6:	mov    r13d,0x0
    7076cdd001ec:	mov    ebp,DWORD PTR [r12+0xc0]
    7076cdd001f4:	mov    eax,r13d
    7076cdd001f7:	or     eax,ebp
    7076cdd001f9:	mov    QWORD PTR [r12+0xa0],rax
    7076cdd00201:	mov    r13d,0x0
    7076cdd00207:	mov    ebp,DWORD PTR [r12+0x28]
    7076cdd0020c:	mov    eax,r13d
    7076cdd0020f:	or     eax,ebp
    7076cdd00211:	mov    QWORD PTR [r12+0xc0],rax
    7076cdd00219:	mov    r13d,0x0
    7076cdd0021f:	mov    ebp,DWORD PTR [r12+0x98]
    7076cdd00227:	mov    eax,r13d
    7076cdd0022a:	or     eax,ebp
    7076cdd0022c:	mov    QWORD PTR [r12+0x28],rax
    7076cdd00231:	mov    r13d,0x0
    7076cdd00237:	mov    ebp,DWORD PTR [r12+0x38]
    7076cdd0023c:	mov    eax,r13d
    7076cdd0023f:	or     eax,ebp
    7076cdd00241:	mov    QWORD PTR [r12+0x98],rax
    7076cdd00249:	mov    r13d,0x0
    7076cdd0024f:	mov    ebp,DWORD PTR [r12+0xa8]
    7076cdd00257:	mov    eax,r13d
    7076cdd0025a:	or     eax,ebp
    7076cdd0025c:	mov    QWORD PTR [r12+0x38],rax
    7076cdd00261:	mov    r14d,r14d
    7076cdd00264:	ror    r14d,0x6
    7076cdd00268:	mov    QWORD PTR [r12+0xb8],r14
    7076cdd00270:	mov    r13d,DWORD PTR [r12+0xc8]
    7076cdd00278:	mov    ebp,DWORD PTR [r12+0x30]
    7076cdd0027d:	mov    ebp,ebp
    7076cdd0027f:	and    ebp,r13d
    7076cdd00282:	mov    QWORD PTR [r12+0xa8],rbp
    7076cdd0028a:	mov    r9d,DWORD PTR [r12+0x38]
    7076cdd0028f:	mov    r9d,r9d
    7076cdd00292:	mov    r9d,r9d
    7076cdd00295:	ror    r9d,0x2
    7076cdd00299:	mov    QWORD PTR [r12+0xd0],r9
    7076cdd002a1:	mov    r15d,0x0
    7076cdd002a7:	mov    eax,r15d
    7076cdd002aa:	or     eax,r13d
    7076cdd002ad:	mov    QWORD PTR [r12+0x20],rax
    7076cdd002b2:	mov    rax,QWORD PTR [r12+0x88]
    7076cdd002ba:	mov    r15,QWORD PTR [r12+0x50]
    7076cdd002bf:	mov    rcx,QWORD PTR [r12+0x88]
    7076cdd002c7:	add    r15,rcx
    7076cdd002ca:	mov    r13d,DWORD PTR [r15]
    7076cdd002cd:	mov    QWORD PTR [r12+0xc8],r13
    7076cdd002d5:	mov    ecx,DWORD PTR [r12+0x30]
    7076cdd002da:	mov    ecx,ecx
    7076cdd002dc:	mov    r15d,DWORD PTR [r12+0xa0]
    7076cdd002e4:	mov    r15d,r15d
    7076cdd002e7:	not    rcx
    7076cdd002ea:	and    r15d,ecx
    7076cdd002ed:	mov    QWORD PTR [r12+0xd8],r15
    7076cdd002f5:	mov    r8d,DWORD PTR [r12+0xb0]
    7076cdd002fd:	add    ebp,r8d
    7076cdd00300:	mov    QWORD PTR [r12+0xa8],rbp
    7076cdd00308:	mov    r8d,DWORD PTR [r12+0x30]
    7076cdd0030d:	mov    r8d,r8d
    7076cdd00310:	mov    r8d,r8d
    7076cdd00313:	ror    r8d,0xb
    7076cdd00317:	xor    r14d,r8d
    7076cdd0031a:	mov    QWORD PTR [r12+0xb0],r14
    7076cdd00322:	mov    r8d,DWORD PTR [r12+0x38]
    7076cdd00327:	mov    r8d,r8d
    7076cdd0032a:	mov    r8d,r8d
    7076cdd0032d:	ror    r8d,0xd
    7076cdd00331:	xor    r9d,r8d
    7076cdd00334:	mov    QWORD PTR [r12+0xd0],r9
    7076cdd0033c:	add    ebp,r15d
    7076cdd0033f:	mov    QWORD PTR [r12+0xa8],rbp
    7076cdd00347:	mov    r15,QWORD PTR [r12+0x48]
    7076cdd0034c:	mov    rcx,QWORD PTR [r12+0x88]
    7076cdd00354:	add    r15,rcx
    7076cdd00357:	mov    r8d,DWORD PTR [r15]
    7076cdd0035a:	mov    QWORD PTR [r12+0xb8],r8
    7076cdd00362:	mov    ecx,DWORD PTR [r12+0x98]
    7076cdd0036a:	mov    ecx,ecx
    7076cdd0036c:	mov    eax,DWORD PTR [r12+0x28]
    7076cdd00371:	mov    eax,eax
    7076cdd00373:	and    eax,ecx
    7076cdd00375:	mov    QWORD PTR [r12+0xd8],rax
    7076cdd0037d:	add    ebp,r13d
    7076cdd00380:	mov    QWORD PTR [r12+0xa8],rbp
    7076cdd00388:	mov    ecx,DWORD PTR [r12+0x98]
    7076cdd00390:	mov    ecx,ecx
    7076cdd00392:	mov    r13d,DWORD PTR [r12+0x28]
    7076cdd00397:	mov    r13d,r13d
    7076cdd0039a:	xor    r13d,ecx
    7076cdd0039d:	mov    QWORD PTR [r12+0xc8],r13
    7076cdd003a5:	mov    r15d,DWORD PTR [r12+0x30]
    7076cdd003aa:	mov    r15d,r15d
    7076cdd003ad:	mov    r15d,r15d
    7076cdd003b0:	ror    r15d,0x19
    7076cdd003b4:	xor    r14d,r15d
    7076cdd003b7:	mov    QWORD PTR [r12+0xb0],r14
    7076cdd003bf:	mov    ecx,DWORD PTR [r12+0x38]
    7076cdd003c4:	mov    ecx,ecx
    7076cdd003c6:	and    r13d,ecx
    7076cdd003c9:	mov    QWORD PTR [r12+0xc8],r13
    7076cdd003d1:	mov    r15d,DWORD PTR [r12+0x38]
    7076cdd003d6:	mov    r15d,r15d
    7076cdd003d9:	mov    r15d,r15d
    7076cdd003dc:	ror    r15d,0x16
    7076cdd003e0:	xor    r9d,r15d
    7076cdd003e3:	mov    QWORD PTR [r12+0xd0],r9
    7076cdd003eb:	add    ebp,r8d
    7076cdd003ee:	mov    QWORD PTR [r12+0xa8],rbp
    7076cdd003f6:	mov    ecx,DWORD PTR [r12+0xd8]
    7076cdd003fe:	mov    ecx,ecx
    7076cdd00400:	xor    r13d,ecx
    7076cdd00403:	mov    QWORD PTR [r12+0xb8],r13
    7076cdd0040b:	add    ebp,r14d
    7076cdd0040e:	mov    QWORD PTR [r12+0xa8],rbp
    7076cdd00416:	mov    r14,QWORD PTR [r12+0x88]
    7076cdd0041e:	add    r14,0x4
    7076cdd00422:	mov    QWORD PTR [r12+0x88],r14
    7076cdd0042a:	add    r13d,r9d
    7076cdd0042d:	mov    QWORD PTR [r12+0xb0],r13
    7076cdd00435:	mov    ecx,DWORD PTR [r12+0xc0]
    7076cdd0043d:	mov    ecx,ecx
    7076cdd0043f:	mov    r15d,ebp
    7076cdd00442:	add    r15d,ecx
    7076cdd00445:	mov    QWORD PTR [r12+0xb8],r15
    7076cdd0044d:	sub    r14,0x100
    7076cdd00454:	setne  BYTE PTR [rsp+0xb8]
    7076cdd0045c:	mov    r11,rax
    7076cdd0045f:	lahf
    7076cdd00460:	seto   al
    7076cdd00463:	mov    WORD PTR [rsp+0xb0],ax
    7076cdd0046b:	mov    rax,r11
    7076cdd0046e:	add    r13d,ebp
    7076cdd00471:	mov    QWORD PTR [r12+0xa8],r13
    7076cdd00479:	mov    r13d,0x0
    7076cdd0047f:	mov    ecx,DWORD PTR [r12+0xa0]
    7076cdd00487:	mov    ecx,ecx
    7076cdd00489:	mov    r14d,r13d
    7076cdd0048c:	or     r14d,ecx
    7076cdd0048f:	mov    QWORD PTR [r12+0xb0],r14
    7076cdd00497:	mov    r13d,0x0
    7076cdd0049d:	mov    ecx,DWORD PTR [r12+0x20]
    7076cdd004a2:	mov    ecx,ecx
    7076cdd004a4:	mov    r14d,r13d
    7076cdd004a7:	or     r14d,ecx
    7076cdd004aa:	mov    QWORD PTR [r12+0xc0],r14
    7076cdd004b2:	mov    r13d,0x0
    7076cdd004b8:	mov    ecx,DWORD PTR [r12+0x30]
    7076cdd004bd:	mov    ecx,ecx
    7076cdd004bf:	mov    r14d,r13d
    7076cdd004c2:	or     r14d,ecx
    7076cdd004c5:	mov    QWORD PTR [r12+0xc8],r14
    7076cdd004cd:	mov    rcx,QWORD PTR [r12+0x380]
    7076cdd004d5:	jrcxz  0x7076cdd004dc
    7076cdd004d7:	jmp    0x7076cdd008a2
    7076cdd004dc:	cmp    BYTE PTR [rsp+0xb8],0x0
    7076cdd004e4:	jne    0x7076cdd001cd
    7076cdd004ea:	jmp    0x7076cdd004ef
    7076cdd004ef:	mov    r13d,DWORD PTR [r12+0x70]
    7076cdd004f4:	mov    r14d,DWORD PTR [r12+0x98]
    7076cdd004fc:	add    r14d,r13d
    7076cdd004ff:	mov    QWORD PTR [r12+0x70],r14
    7076cdd00504:	mov    r13d,DWORD PTR [r12+0x68]
    7076cdd00509:	mov    r15d,DWORD PTR [r12+0x28]
    7076cdd0050e:	add    r15d,r13d
    7076cdd00511:	mov    QWORD PTR [r12+0x68],r15
    7076cdd00516:	mov    r13d,0x0
    7076cdd0051c:	mov    QWORD PTR [r12+0x88],r13
    7076cdd00524:	mov    r13d,DWORD PTR [r12+0x78]
    7076cdd00529:	mov    ebp,DWORD PTR [r12+0xa8]
    7076cdd00531:	add    ebp,r13d
    7076cdd00534:	mov    QWORD PTR [r12+0x78],rbp
    7076cdd00539:	mov    r13d,DWORD PTR [r12+0x80]
    7076cdd00541:	mov    r8d,DWORD PTR [r12+0x38]
    7076cdd00546:	add    r8d,r13d
    7076cdd00549:	mov    QWORD PTR [r12+0x80],r8
    7076cdd00551:	mov    rax,QWORD PTR [r12]
    7076cdd00555:	mov    r9,QWORD PTR [r12]
    7076cdd00559:	add    r9,0x8
    7076cdd0055d:	mov    r13,r9
    7076cdd00560:	add    r13,0x4
    7076cdd00564:	mov    DWORD PTR [r9],r14d
    7076cdd00567:	mov    r14d,0x0
    7076cdd0056d:	mov    DWORD PTR [r12+0x32c],r14d
    7076cdd00575:	mov    DWORD PTR [r13+0x0],r15d
    7076cdd00579:	mov    r13d,DWORD PTR [r12+0x18]
    7076cdd0057e:	mov    r14d,DWORD PTR [r12+0xb8]
    7076cdd00586:	add    r14d,r13d
    7076cdd00589:	mov    QWORD PTR [r12+0x68],r14
    7076cdd0058e:	mov    r13d,DWORD PTR [r12+0x90]
    7076cdd00596:	mov    r15d,DWORD PTR [r12+0x30]
    7076cdd0059b:	add    r15d,r13d
    7076cdd0059e:	mov    QWORD PTR [r12+0x70],r15
    7076cdd005a3:	mov    r13d,DWORD PTR [r12+0x58]
    7076cdd005a8:	mov    r9d,DWORD PTR [r12+0x20]
    7076cdd005ad:	mov    eax,r9d
    7076cdd005b0:	add    eax,r13d
    7076cdd005b3:	mov    QWORD PTR [r12+0x58],rax
    7076cdd005b8:	mov    r13d,DWORD PTR [r12+0x60]
    7076cdd005bd:	mov    r9d,DWORD PTR [r12+0xa0]
    7076cdd005c5:	add    r9d,r13d
    7076cdd005c8:	mov    QWORD PTR [r12+0x60],r9
    7076cdd005cd:	mov    r13,QWORD PTR [r12]
    7076cdd005d1:	add    r13,0x4
    7076cdd005d5:	mov    rdi,QWORD PTR [r12]
    7076cdd005d9:	mov    DWORD PTR [rdi],ebp
    7076cdd005db:	mov    DWORD PTR [r13+0x0],r8d
    7076cdd005df:	mov    r13,QWORD PTR [r12]
    7076cdd005e3:	add    r13,0x10
    7076cdd005e7:	mov    rbp,r13
    7076cdd005ea:	add    rbp,0x4
    7076cdd005ee:	mov    DWORD PTR [r13+0x0],r14d
    7076cdd005f2:	mov    DWORD PTR [rbp+0x0],r15d
    7076cdd005f6:	mov    r13,QWORD PTR [r12]
    7076cdd005fa:	add    r13,0x18
    7076cdd005fe:	mov    r14,r13
    7076cdd00601:	add    r14,0x4
    7076cdd00605:	mov    eax,DWORD PTR [r12+0x58]
    7076cdd0060a:	mov    DWORD PTR [r13+0x0],eax
    7076cdd0060e:	mov    DWORD PTR [r14],r9d
    7076cdd00611:	mov    r13,QWORD PTR [r12]
    7076cdd00615:	add    r13,0x68
    7076cdd00619:	mov    r14d,0x0
    7076cdd0061f:	mov    QWORD PTR [r13+0x0],r14
    7076cdd00623:	mov    rcx,QWORD PTR [r12+0x380]
    7076cdd0062b:	jrcxz  0x7076cdd00632
    7076cdd0062d:	jmp    0x7076cdd0092a
    7076cdd00632:	jmp    0x7076cdd00637
    7076cdd00637:	mov    r13,QWORD PTR [r12+0x10]
    7076cdd0063c:	sub    r13,0x1
    7076cdd00640:	mov    QWORD PTR [r12+0x10],r13
    7076cdd00645:	mov    rax,r13
    7076cdd00648:	test   rax,rax
    7076cdd0064b:	je     0x7076cdd00656
    7076cdd00651:	jmp    0x7076cdcfe75a
    7076cdd00656:	mov    r13,QWORD PTR [r12+0xf8]
    7076cdd0065e:	mov    r14,r13
    7076cdd00661:	add    r14,0x140
    7076cdd00668:	mov    r15,r14
    7076cdd0066b:	add    r15,0x8
    7076cdd0066f:	mov    rbp,QWORD PTR [r14]
    7076cdd00672:	mov    r14,QWORD PTR [r15]
    7076cdd00675:	mov    QWORD PTR [r12+0xa0],rbp
    7076cdd0067d:	mov    QWORD PTR [r12+0x98],r14
    7076cdd00685:	mov    r14,r13
    7076cdd00688:	add    r14,0x130
    7076cdd0068f:	mov    r15,r14
    7076cdd00692:	add    r15,0x8
    7076cdd00696:	mov    rbp,QWORD PTR [r14]
    7076cdd00699:	mov    r14,QWORD PTR [r15]
    7076cdd0069c:	mov    QWORD PTR [r12+0xb0],rbp
    7076cdd006a4:	mov    QWORD PTR [r12+0xa8],r14
    7076cdd006ac:	mov    r14,r13
    7076cdd006af:	add    r14,0x120
    7076cdd006b6:	mov    r15,r14
    7076cdd006b9:	add    r15,0x8
    7076cdd006bd:	mov    rbp,QWORD PTR [r14]
    7076cdd006c0:	mov    r14,QWORD PTR [r15]
    7076cdd006c3:	mov    QWORD PTR [r12+0xc0],rbp
    7076cdd006cb:	mov    QWORD PTR [r12+0xb8],r14
    7076cdd006d3:	mov    r14,r13
    7076cdd006d6:	add    r14,0x110
    7076cdd006dd:	mov    r15,r14
    7076cdd006e0:	add    r15,0x8
    7076cdd006e4:	mov    rbp,QWORD PTR [r14]
    7076cdd006e7:	mov    r14,QWORD PTR [r15]
    7076cdd006ea:	mov    QWORD PTR [r12+0xd0],rbp
    7076cdd006f2:	mov    QWORD PTR [r12+0xc8],r14
    7076cdd006fa:	mov    r14,r13
    7076cdd006fd:	add    r14,0x100
    7076cdd00704:	mov    r15,r14
    7076cdd00707:	add    r15,0x8
    7076cdd0070b:	mov    rbp,QWORD PTR [r14]
    7076cdd0070e:	mov    r14,QWORD PTR [r15]
    7076cdd00711:	mov    QWORD PTR [r12+0xe8],rbp
    7076cdd00719:	mov    QWORD PTR [r12+0xd8],r14
    7076cdd00721:	add    r13,0x150
    7076cdd00728:	mov    QWORD PTR [r12+0xf8],r13
    7076cdd00730:	jmp    0x7076cdd00735
    7076cdd00735:	mov    rcx,QWORD PTR [r12+0x380]
    7076cdd0073d:	jrcxz  0x7076cdd00744
    7076cdd0073f:	jmp    0x7076cdd009b2
    7076cdd00744:	mov    r13,QWORD PTR [r12+0xf0]
    7076cdd0074c:	mov    QWORD PTR [r12+0x100],r13
    7076cdd00754:	mov    r11,QWORD PTR [rsp+0xb0]
    7076cdd0075c:	mov    QWORD PTR [r12+0x398],r11
    7076cdd00764:	mov    rdi,QWORD PTR [r12+0x100]
    7076cdd0076c:	add    rsp,0xc0
    7076cdd00773:	movabs r11,0x5b61e73e9940
    7076cdd0077d:	jmp    r11
    7076cdd00780:	mov    eax,0x410720
    7076cdd00785:	mov    QWORD PTR [r12+0x100],rax
    7076cdd0078d:	push   rdx
    7076cdd0078e:	push   rsi
    7076cdd0078f:	push   r10
    7076cdd00791:	push   r11
    7076cdd00793:	mov    r11,rax
    7076cdd00796:	lahf
    7076cdd00797:	seto   al
    7076cdd0079a:	mov    WORD PTR [rsp+0xd0],ax
    7076cdd007a2:	mov    rax,r11
    7076cdd007a5:	mov    rdx,QWORD PTR [rsp+0xd0]
    7076cdd007ad:	mov    r10d,edx
    7076cdd007b0:	and    r10d,0xc000
    7076cdd007b7:	shl    r10d,0x10
    7076cdd007bb:	mov    r11d,edx
    7076cdd007be:	and    r11d,0x100
    7076cdd007c5:	shl    r11d,0x15
    7076cdd007c9:	or     r10d,r11d
    7076cdd007cc:	and    edx,0x1
    7076cdd007cf:	shl    edx,0x1c
    7076cdd007d2:	or     r10d,edx
    7076cdd007d5:	btc    r10,0x1d
    7076cdd007da:	mov    r11d,0xf0000000
    7076cdd007e0:	and    r11,r10
    7076cdd007e3:	movabs rsi,0xffffffff0fffffff
    7076cdd007ed:	and    rbx,rsi
    7076cdd007f0:	or     rbx,r11
    7076cdd007f3:	pop    r11
    7076cdd007f5:	pop    r10
    7076cdd007f7:	pop    rsi
    7076cdd007f8:	pop    rdx
    7076cdd007f9:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd00801:	add    rsp,0xc0
    7076cdd00808:	mov    eax,0xc
    7076cdd0080d:	movabs r11,0x5b61e73e9ca0
    7076cdd00817:	jmp    r11
    7076cdd0081a:	mov    eax,0x41081c
    7076cdd0081f:	mov    QWORD PTR [r12+0x100],rax
    7076cdd00827:	push   rdx
    7076cdd00828:	push   rsi
    7076cdd00829:	push   r10
    7076cdd0082b:	push   r11
    7076cdd0082d:	mov    rdx,QWORD PTR [rsp+0xd0]
    7076cdd00835:	mov    r10d,edx
    7076cdd00838:	and    r10d,0xc000
    7076cdd0083f:	shl    r10d,0x10
    7076cdd00843:	mov    r11d,edx
    7076cdd00846:	and    r11d,0x100
    7076cdd0084d:	shl    r11d,0x15
    7076cdd00851:	or     r10d,r11d
    7076cdd00854:	and    edx,0x1
    7076cdd00857:	shl    edx,0x1c
    7076cdd0085a:	or     r10d,edx
    7076cdd0085d:	btc    r10,0x1d
    7076cdd00862:	mov    r11d,0xf0000000
    7076cdd00868:	and    r11,r10
    7076cdd0086b:	movabs rsi,0xffffffff0fffffff
    7076cdd00875:	and    rbx,rsi
    7076cdd00878:	or     rbx,r11
    7076cdd0087b:	pop    r11
    7076cdd0087d:	pop    r10
    7076cdd0087f:	pop    rsi
    7076cdd00880:	pop    rdx
    7076cdd00881:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd00889:	add    rsp,0xc0
    7076cdd00890:	mov    eax,0xc
    7076cdd00895:	movabs r11,0x5b61e73e9ca0
    7076cdd0089f:	jmp    r11
    7076cdd008a2:	mov    eax,0x4108dc
    7076cdd008a7:	mov    QWORD PTR [r12+0x100],rax
    7076cdd008af:	push   rdx
    7076cdd008b0:	push   rsi
    7076cdd008b1:	push   r10
    7076cdd008b3:	push   r11
    7076cdd008b5:	mov    rdx,QWORD PTR [rsp+0xd0]
    7076cdd008bd:	mov    r10d,edx
    7076cdd008c0:	and    r10d,0xc000
    7076cdd008c7:	shl    r10d,0x10
    7076cdd008cb:	mov    r11d,edx
    7076cdd008ce:	and    r11d,0x100
    7076cdd008d5:	shl    r11d,0x15
    7076cdd008d9:	or     r10d,r11d
    7076cdd008dc:	and    edx,0x1
    7076cdd008df:	shl    edx,0x1c
    7076cdd008e2:	or     r10d,edx
    7076cdd008e5:	btc    r10,0x1d
    7076cdd008ea:	mov    r11d,0xf0000000
    7076cdd008f0:	and    r11,r10
    7076cdd008f3:	movabs rsi,0xffffffff0fffffff
    7076cdd008fd:	and    rbx,rsi
    7076cdd00900:	or     rbx,r11
    7076cdd00903:	pop    r11
    7076cdd00905:	pop    r10
    7076cdd00907:	pop    rsi
    7076cdd00908:	pop    rdx
    7076cdd00909:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd00911:	add    rsp,0xc0
    7076cdd00918:	mov    eax,0xc
    7076cdd0091d:	movabs r11,0x5b61e73e9ca0
    7076cdd00927:	jmp    r11
    7076cdd0092a:	mov    eax,0x410918
    7076cdd0092f:	mov    QWORD PTR [r12+0x100],rax
    7076cdd00937:	push   rdx
    7076cdd00938:	push   rsi
    7076cdd00939:	push   r10
    7076cdd0093b:	push   r11
    7076cdd0093d:	mov    rdx,QWORD PTR [rsp+0xd0]
    7076cdd00945:	mov    r10d,edx
    7076cdd00948:	and    r10d,0xc000
    7076cdd0094f:	shl    r10d,0x10
    7076cdd00953:	mov    r11d,edx
    7076cdd00956:	and    r11d,0x100
    7076cdd0095d:	shl    r11d,0x15
    7076cdd00961:	or     r10d,r11d
    7076cdd00964:	and    edx,0x1
    7076cdd00967:	shl    edx,0x1c
    7076cdd0096a:	or     r10d,edx
    7076cdd0096d:	btc    r10,0x1d
    7076cdd00972:	mov    r11d,0xf0000000
    7076cdd00978:	and    r11,r10
    7076cdd0097b:	movabs rsi,0xffffffff0fffffff
    7076cdd00985:	and    rbx,rsi
    7076cdd00988:	or     rbx,r11
    7076cdd0098b:	pop    r11
    7076cdd0098d:	pop    r10
    7076cdd0098f:	pop    rsi
    7076cdd00990:	pop    rdx
    7076cdd00991:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd00999:	add    rsp,0xc0
    7076cdd009a0:	mov    eax,0xc
    7076cdd009a5:	movabs r11,0x5b61e73e9ca0
    7076cdd009af:	jmp    r11
    7076cdd009b2:	mov    eax,0x410934
    7076cdd009b7:	mov    QWORD PTR [r12+0x100],rax
    7076cdd009bf:	push   rdx
    7076cdd009c0:	push   rsi
    7076cdd009c1:	push   r10
    7076cdd009c3:	push   r11
    7076cdd009c5:	mov    rdx,QWORD PTR [rsp+0xd0]
    7076cdd009cd:	mov    r10d,edx
    7076cdd009d0:	and    r10d,0xc000
    7076cdd009d7:	shl    r10d,0x10
    7076cdd009db:	mov    r11d,edx
    7076cdd009de:	and    r11d,0x100
    7076cdd009e5:	shl    r11d,0x15
    7076cdd009e9:	or     r10d,r11d
    7076cdd009ec:	and    edx,0x1
    7076cdd009ef:	shl    edx,0x1c
    7076cdd009f2:	or     r10d,edx
    7076cdd009f5:	btc    r10,0x1d
    7076cdd009fa:	mov    r11d,0xf0000000
    7076cdd00a00:	and    r11,r10
    7076cdd00a03:	movabs rsi,0xffffffff0fffffff
    7076cdd00a0d:	and    rbx,rsi
    7076cdd00a10:	or     rbx,r11
    7076cdd00a13:	pop    r11
    7076cdd00a15:	pop    r10
    7076cdd00a17:	pop    rsi
    7076cdd00a18:	pop    rdx
    7076cdd00a19:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd00a21:	add    rsp,0xc0
    7076cdd00a28:	mov    eax,0xc
    7076cdd00a2d:	movabs r11,0x5b61e73e9ca0
    7076cdd00a37:	jmp    r11
    7076cdd00a3a:	nop    WORD PTR [rax+rax*1+0x0]
    7076cdd00a40:	sub    rsp,0xc0
    7076cdd00a47:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd00a4f:	mov    QWORD PTR [rsp+0xb0],r11
    7076cdd00a57:	jmp    0x7076cdcfe639
    7076cdd00a5c:	nop    DWORD PTR [rax+0x0]
    7076cdd00a60:	sub    rsp,0xc0
    7076cdd00a67:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd00a6f:	mov    QWORD PTR [rsp+0xb0],r11
    7076cdd00a77:	jmp    0x7076cdcfe75a
    7076cdd00a7c:	nop    DWORD PTR [rax+0x0]
    7076cdd00a80:	sub    rsp,0xc0
    7076cdd00a87:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd00a8f:	mov    QWORD PTR [rsp+0xb0],r11
    7076cdd00a97:	jmp    0x7076cdcfe814
    7076cdd00a9c:	nop    DWORD PTR [rax+0x0]
    7076cdd00aa0:	sub    rsp,0xc0
    7076cdd00aa7:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd00aaf:	mov    QWORD PTR [rsp+0xb0],r11
    7076cdd00ab7:	jmp    0x7076cdcffef9
    7076cdd00abc:	nop    DWORD PTR [rax+0x0]
    7076cdd00ac0:	sub    rsp,0xc0
    7076cdd00ac7:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd00acf:	mov    QWORD PTR [rsp+0xb0],r11
    7076cdd00ad7:	jmp    0x7076cdd0004a
    7076cdd00adc:	nop    DWORD PTR [rax+0x0]
    7076cdd00ae0:	sub    rsp,0xc0
    7076cdd00ae7:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd00aef:	mov    QWORD PTR [rsp+0xb0],r11
    7076cdd00af7:	jmp    0x7076cdd001cd
    7076cdd00afc:	nop    DWORD PTR [rax+0x0]
    7076cdd00b00:	sub    rsp,0xc0
    7076cdd00b07:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd00b0f:	mov    QWORD PTR [rsp+0xb0],r11
    7076cdd00b17:	jmp    0x7076cdd004ef
    7076cdd00b1c:	nop    DWORD PTR [rax+0x0]
    7076cdd00b20:	sub    rsp,0xc0
    7076cdd00b27:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd00b2f:	mov    QWORD PTR [rsp+0xb0],r11
    7076cdd00b37:	jmp    0x7076cdd00637
    7076cdd00b3c:	nop    DWORD PTR [rax+0x0]
    7076cdd00b40:	sub    rsp,0xc0
    7076cdd00b47:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd00b4f:	mov    QWORD PTR [rsp+0xb0],r11
    7076cdd00b57:	jmp    0x7076cdd00656
    7076cdd00b5c:	nop    DWORD PTR [rax+0x0]
    7076cdd00b60:	sub    rsp,0xc0
    7076cdd00b67:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd00b6f:	mov    QWORD PTR [rsp+0xb0],r11
    7076cdd00b77:	jmp    0x7076cdd00735
