
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/2/8.bin:     file format binary


Disassembly of section .data:

00007db2f9502160 <.data>:
    7db2f9502160:	sub    rsp,0x150
    7db2f9502167:	mov    r11,QWORD PTR [r12+0x398]
    7db2f950216f:	mov    QWORD PTR [rsp],r11
    7db2f9502173:	cmp    DWORD PTR [r12+0x310],0x0
    7db2f950217c:	je     0x7db2f9502207
    7db2f9502182:	push   rdx
    7db2f9502183:	push   rsi
    7db2f9502184:	push   r10
    7db2f9502186:	push   r11
    7db2f9502188:	mov    rdx,QWORD PTR [rsp+0x20]
    7db2f950218d:	mov    r10d,edx
    7db2f9502190:	and    r10d,0xc000
    7db2f9502197:	shl    r10d,0x10
    7db2f950219b:	mov    r11d,edx
    7db2f950219e:	and    r11d,0x100
    7db2f95021a5:	shl    r11d,0x15
    7db2f95021a9:	or     r10d,r11d
    7db2f95021ac:	and    edx,0x1
    7db2f95021af:	shl    edx,0x1c
    7db2f95021b2:	or     r10d,edx
    7db2f95021b5:	btc    r10,0x1d
    7db2f95021ba:	mov    r11d,0xf0000000
    7db2f95021c0:	and    r11,r10
    7db2f95021c3:	movabs rsi,0xffffffff0fffffff
    7db2f95021cd:	and    rbx,rsi
    7db2f95021d0:	or     rbx,r11
    7db2f95021d3:	pop    r11
    7db2f95021d5:	pop    r10
    7db2f95021d7:	pop    rsi
    7db2f95021d8:	pop    rdx
    7db2f95021d9:	mov    QWORD PTR [r12+0x108],rbx
    7db2f95021e1:	mov    eax,0x4103e8
    7db2f95021e6:	mov    QWORD PTR [r12+0x100],rax
    7db2f95021ee:	add    rsp,0x150
    7db2f95021f5:	mov    eax,0x3
    7db2f95021fa:	movabs r11,0x5a58c9ed2ca0
    7db2f9502204:	jmp    r11
    7db2f9502207:	mov    r13d,DWORD PTR [r12+0x98]
    7db2f950220f:	add    r13d,0x1
    7db2f9502213:	mov    QWORD PTR [r12+0x98],r13
    7db2f950221b:	sub    r13d,0x10000
    7db2f9502222:	mov    rcx,QWORD PTR [r12+0x380]
    7db2f950222a:	jrcxz  0x7db2f9502231
    7db2f950222c:	jmp    0x7db2f9506065
    7db2f9502231:	jne    0x7db2f950224a
    7db2f9502237:	mov    r11,rax
    7db2f950223a:	lahf
    7db2f950223b:	seto   al
    7db2f950223e:	mov    WORD PTR [rsp],ax
    7db2f9502242:	mov    rax,r11
    7db2f9502245:	jmp    0x7db2f950225d
    7db2f950224a:	mov    r11,rax
    7db2f950224d:	lahf
    7db2f950224e:	seto   al
    7db2f9502251:	mov    WORD PTR [rsp],ax
    7db2f9502255:	mov    rax,r11
    7db2f9502258:	jmp    0x7db2f9504add
    7db2f950225d:	mov    r13d,0x420000
    7db2f9502263:	mov    QWORD PTR [r12+0x40],r13
    7db2f9502268:	movabs r13,0x100000001
    7db2f9502272:	mov    r14d,0x0
    7db2f9502278:	mov    QWORD PTR [r12+0x110],r13
    7db2f9502280:	mov    QWORD PTR [r12+0x118],r14
    7db2f9502288:	movabs r13,0x3fa0000000000000
    7db2f9502292:	mov    QWORD PTR [r12+0x50],r13
    7db2f9502297:	mov    r13d,0x420aa0
    7db2f950229d:	mov    r14,QWORD PTR [r13+0x0]
    7db2f95022a1:	mov    r13d,0x0
    7db2f95022a7:	mov    QWORD PTR [r12+0x120],r14
    7db2f95022af:	mov    QWORD PTR [r12+0x128],r13
    7db2f95022b7:	movabs r13,0x4100000041
    7db2f95022c1:	mov    r14d,0x0
    7db2f95022c7:	mov    QWORD PTR [r12+0x140],r13
    7db2f95022cf:	mov    QWORD PTR [r12+0x148],r14
    7db2f95022d7:	movabs r13,0x3fc0000000000000
    7db2f95022e1:	movabs r14,0x3fc0000000000000
    7db2f95022eb:	mov    QWORD PTR [r12+0x150],r13
    7db2f95022f3:	mov    QWORD PTR [r12+0x158],r14
    7db2f95022fb:	movabs r13,0x200000002
    7db2f9502305:	mov    r14d,0x0
    7db2f950230b:	mov    QWORD PTR [r12+0x160],r13
    7db2f9502313:	mov    QWORD PTR [r12+0x168],r14
    7db2f950231b:	movabs r13,0x3fa0000000000000
    7db2f9502325:	mov    QWORD PTR [r12+0x130],r13
    7db2f950232d:	mov    QWORD PTR [r12+0x138],r13
    7db2f9502335:	mov    r13d,0x2
    7db2f950233b:	mov    QWORD PTR [r12+0x170],r13
    7db2f9502343:	mov    QWORD PTR [r12+0x178],r13
    7db2f950234b:	mov    r13d,0x420000
    7db2f9502351:	mov    QWORD PTR [r12+0x40],r13
    7db2f9502356:	mov    r13d,0x430000
    7db2f950235c:	mov    QWORD PTR [r12+0x50],r13
    7db2f9502361:	mov    r13d,0x4209d0
    7db2f9502367:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7db2f950236d:	movdqu XMMWORD PTR [r12+0x180],xmm2
    7db2f9502377:	mov    r13d,0x0
    7db2f950237d:	mov    QWORD PTR [r12+0x48],r13
    7db2f9502382:	mov    r13d,0x431000
    7db2f9502388:	add    r13,0xd90
    7db2f950238f:	mov    QWORD PTR [r12+0x40],r13
    7db2f9502394:	mov    r13d,0x430c48
    7db2f950239a:	mov    r14d,DWORD PTR [r12]
    7db2f950239e:	mov    DWORD PTR [r13+0x0],r14d
    7db2f95023a2:	mov    r13d,0x0
    7db2f95023a8:	mov    DWORD PTR [r12+0x32c],r13d
    7db2f95023b0:	mov    r13d,0x431000
    7db2f95023b6:	add    r13,0xf90
    7db2f95023bd:	mov    QWORD PTR [r12+0x50],r13
    7db2f95023c2:	mov    r11,rax
    7db2f95023c5:	movzx  eax,WORD PTR [rsp]
    7db2f95023c9:	add    al,0x7f
    7db2f95023cb:	sahf
    7db2f95023cc:	mov    rax,r11
    7db2f95023cf:	jmp    0x7db2f95023d4
    7db2f95023d4:	mov    r13,QWORD PTR [r12+0x180]
    7db2f95023dc:	mov    r14,QWORD PTR [r12+0x188]
    7db2f95023e4:	mov    r15d,0x0
    7db2f95023ea:	mov    r11,rax
    7db2f95023ed:	lahf
    7db2f95023ee:	seto   al
    7db2f95023f1:	mov    WORD PTR [rsp],ax
    7db2f95023f5:	mov    rax,r11
    7db2f95023f8:	mov    ecx,0xffffffff
    7db2f95023fd:	and    r13,rcx
    7db2f9502400:	mov    rbp,r15
    7db2f9502403:	or     rbp,r13
    7db2f9502406:	mov    ecx,0xffffffff
    7db2f950240b:	and    r14,rcx
    7db2f950240e:	shl    r14,0x20
    7db2f9502412:	or     rbp,r14
    7db2f9502415:	mov    QWORD PTR [r12+0x210],rbp
    7db2f950241d:	mov    QWORD PTR [r12+0x218],r15
    7db2f9502425:	movdqu xmm2,XMMWORD PTR [r12+0x140]
    7db2f950242f:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    7db2f9502439:	movdqa xmm1,xmm3
    7db2f950243d:	psubd  xmm2,xmm1
    7db2f9502441:	movdqa xmm14,xmm2
    7db2f9502446:	movdqa xmm1,xmm14
    7db2f950244b:	movq   rax,xmm1
    7db2f9502450:	mov    r13,rax
    7db2f9502453:	movdqu xmm2,XMMWORD PTR [r12+0x180]
    7db2f950245d:	movdqu xmm4,XMMWORD PTR [r12+0x170]
    7db2f9502467:	movdqa xmm1,xmm4
    7db2f950246b:	paddq  xmm2,xmm1
    7db2f950246f:	movdqu XMMWORD PTR [r12+0x180],xmm2
    7db2f9502479:	movdqu xmm2,XMMWORD PTR [r12+0x160]
    7db2f9502483:	movdqa xmm1,xmm2
    7db2f9502487:	paddd  xmm3,xmm1
    7db2f950248b:	movdqa xmm14,xmm3
    7db2f9502490:	movdqa xmm1,xmm14
    7db2f9502495:	movq   rax,xmm1
    7db2f950249a:	mov    r14,rax
    7db2f950249d:	mov    r15d,0x0
    7db2f95024a3:	mov    QWORD PTR [r12+0x120],r14
    7db2f95024ab:	mov    QWORD PTR [r12+0x128],r15
    7db2f95024b3:	mov    r14d,0x0
    7db2f95024b9:	mov    ecx,0xffffffff
    7db2f95024be:	mov    r15,r13
    7db2f95024c1:	and    r15,rcx
    7db2f95024c4:	mov    rbp,r14
    7db2f95024c7:	or     rbp,r15
    7db2f95024ca:	shr    r13,0x20
    7db2f95024ce:	mov    ecx,0xffffffff
    7db2f95024d3:	and    r13,rcx
    7db2f95024d6:	or     r14,r13
    7db2f95024d9:	mov    QWORD PTR [r12+0x220],rbp
    7db2f95024e1:	mov    QWORD PTR [r12+0x228],r14
    7db2f95024e9:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    7db2f95024f3:	movdqu xmm3,XMMWORD PTR [r12+0x110]
    7db2f95024fd:	movdqa xmm1,xmm3
    7db2f9502501:	paddd  xmm2,xmm1
    7db2f9502505:	movdqa xmm14,xmm2
    7db2f950250a:	movdqa xmm1,xmm14
    7db2f950250f:	movq   rax,xmm1
    7db2f9502514:	mov    r13,rax
    7db2f9502517:	mov    r14d,0x0
    7db2f950251d:	mov    QWORD PTR [r12+0x210],r13
    7db2f9502525:	mov    QWORD PTR [r12+0x218],r14
    7db2f950252d:	lea    r13,[r12]
    7db2f9502531:	movabs r14,0xb6e61da31
    7db2f950253b:	mov    r15d,0x410458
    7db2f9502541:	mov    rdx,QWORD PTR [rsp]
    7db2f9502545:	mov    r10d,edx
    7db2f9502548:	and    r10d,0xc000
    7db2f950254f:	shl    r10d,0x10
    7db2f9502553:	mov    r11d,edx
    7db2f9502556:	and    r11d,0x100
    7db2f950255d:	shl    r11d,0x15
    7db2f9502561:	or     r10d,r11d
    7db2f9502564:	and    edx,0x1
    7db2f9502567:	shl    edx,0x1c
    7db2f950256a:	or     r10d,edx
    7db2f950256d:	btc    r10,0x1d
    7db2f9502572:	mov    r11d,0xf0000000
    7db2f9502578:	and    r11,r10
    7db2f950257b:	movabs rsi,0xffffffff0fffffff
    7db2f9502585:	and    rbx,rsi
    7db2f9502588:	or     rbx,r11
    7db2f950258b:	mov    QWORD PTR [r12+0x378],0x3
    7db2f9502597:	mov    QWORD PTR [r12+0x108],rbx
    7db2f950259f:	stmxcsr DWORD PTR [r12-0x28]
    7db2f95025a5:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f95025aa:	test   r10d,0x3f
    7db2f95025b1:	je     0x7db2f95025d6
    7db2f95025b7:	mov    r11d,r10d
    7db2f95025ba:	shr    r10d,1
    7db2f95025bd:	and    r10d,0x1e
    7db2f95025c1:	and    r11d,0x1
    7db2f95025c5:	or     r10d,r11d
    7db2f95025c8:	or     DWORD PTR [r12+0x314],r10d
    7db2f95025d0:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f95025d6:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f95025dc:	movabs r11,0x5a58c9d345e0
    7db2f95025e6:	mov    rdi,r13
    7db2f95025e9:	mov    rsi,r14
    7db2f95025ec:	mov    rdx,r15
    7db2f95025ef:	call   r11
    7db2f95025f2:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f95025f8:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f9502600:	mov    QWORD PTR [r12+0x378],0x2
    7db2f950260c:	mov    rbp,rax
    7db2f950260f:	mov    r13,QWORD PTR [r12+0x210]
    7db2f9502617:	mov    r14d,0x0
    7db2f950261d:	mov    ecx,0xffffffff
    7db2f9502622:	mov    r15,r13
    7db2f9502625:	and    r15,rcx
    7db2f9502628:	mov    rbp,r14
    7db2f950262b:	or     rbp,r15
    7db2f950262e:	shr    r13,0x20
    7db2f9502632:	mov    ecx,0xffffffff
    7db2f9502637:	and    r13,rcx
    7db2f950263a:	or     r14,r13
    7db2f950263d:	mov    QWORD PTR [r12+0x210],rbp
    7db2f9502645:	mov    QWORD PTR [r12+0x218],r14
    7db2f950264d:	lea    r13,[r12]
    7db2f9502651:	movabs r14,0xb6e61da10
    7db2f950265b:	mov    r15d,0x410460
    7db2f9502661:	mov    QWORD PTR [r12+0x378],0x3
    7db2f950266d:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9502675:	stmxcsr DWORD PTR [r12-0x28]
    7db2f950267b:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f9502680:	test   r10d,0x3f
    7db2f9502687:	je     0x7db2f95026ac
    7db2f950268d:	mov    r11d,r10d
    7db2f9502690:	shr    r10d,1
    7db2f9502693:	and    r10d,0x1e
    7db2f9502697:	and    r11d,0x1
    7db2f950269b:	or     r10d,r11d
    7db2f950269e:	or     DWORD PTR [r12+0x314],r10d
    7db2f95026a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f95026ac:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f95026b2:	movabs r11,0x5a58c9d345e0
    7db2f95026bc:	mov    rdi,r13
    7db2f95026bf:	mov    rsi,r14
    7db2f95026c2:	mov    rdx,r15
    7db2f95026c5:	call   r11
    7db2f95026c8:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f95026ce:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f95026d6:	mov    QWORD PTR [r12+0x378],0x2
    7db2f95026e2:	mov    rbp,rax
    7db2f95026e5:	movdqu xmm2,XMMWORD PTR [r12+0x220]
    7db2f95026ef:	movdqu xmm3,XMMWORD PTR [r12+0x150]
    7db2f95026f9:	movdqa xmm0,xmm2
    7db2f95026fd:	movdqa xmm1,xmm3
    7db2f9502701:	mulpd  xmm0,xmm1
    7db2f9502705:	movdqa xmm14,xmm0
    7db2f950270a:	movdqu xmm15,XMMWORD PTR [rip+0x435d]        # 0x7db2f9506a70
    7db2f9502713:	pand   xmm14,xmm15
    7db2f9502718:	movdqu xmm15,XMMWORD PTR [rip+0x435f]        # 0x7db2f9506a80
    7db2f9502721:	pcmpeqq xmm14,xmm15
    7db2f9502727:	movdqa xmm15,xmm0
    7db2f950272c:	cmpunordpd xmm15,xmm0
    7db2f9502732:	por    xmm14,xmm15
    7db2f9502737:	pmovmskb ecx,xmm14
    7db2f950273c:	jrcxz  0x7db2f9502743
    7db2f950273e:	jmp    0x7db2f9504b55
    7db2f9502743:	movdqa xmm4,xmm0
    7db2f9502747:	movdqu XMMWORD PTR [r12+0x220],xmm4
    7db2f9502751:	mov    r13,QWORD PTR [r12+0x48]
    7db2f9502756:	mov    r14,QWORD PTR [r12+0x50]
    7db2f950275b:	add    r14,r13
    7db2f950275e:	movdqu XMMWORD PTR [r14],xmm4
    7db2f9502763:	mov    r14d,0x0
    7db2f9502769:	mov    DWORD PTR [r12+0x32c],r14d
    7db2f9502771:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    7db2f950277b:	movdqu xmm3,XMMWORD PTR [r12+0x130]
    7db2f9502785:	movdqa xmm0,xmm2
    7db2f9502789:	movdqa xmm1,xmm3
    7db2f950278d:	mulpd  xmm0,xmm1
    7db2f9502791:	movdqa xmm14,xmm0
    7db2f9502796:	movdqu xmm15,XMMWORD PTR [rip+0x42d1]        # 0x7db2f9506a70
    7db2f950279f:	pand   xmm14,xmm15
    7db2f95027a4:	movdqu xmm15,XMMWORD PTR [rip+0x42d3]        # 0x7db2f9506a80
    7db2f95027ad:	pcmpeqq xmm14,xmm15
    7db2f95027b3:	movdqa xmm15,xmm0
    7db2f95027b8:	cmpunordpd xmm15,xmm0
    7db2f95027be:	por    xmm14,xmm15
    7db2f95027c3:	pmovmskb ecx,xmm14
    7db2f95027c8:	jrcxz  0x7db2f95027cf
    7db2f95027ca:	jmp    0x7db2f9504b79
    7db2f95027cf:	movdqa xmm4,xmm0
    7db2f95027d3:	movdqu XMMWORD PTR [r12+0x210],xmm4
    7db2f95027dd:	mov    r14,QWORD PTR [r12+0x40]
    7db2f95027e2:	add    r14,r13
    7db2f95027e5:	movdqu XMMWORD PTR [r14],xmm4
    7db2f95027ea:	add    r13,0x10
    7db2f95027ee:	mov    QWORD PTR [r12+0x48],r13
    7db2f95027f3:	sub    r13,0x200
    7db2f95027fa:	mov    rcx,QWORD PTR [r12+0x380]
    7db2f9502802:	jrcxz  0x7db2f9502809
    7db2f9502804:	jmp    0x7db2f95060f9
    7db2f9502809:	jne    0x7db2f95023d4
    7db2f950280f:	mov    r11,rax
    7db2f9502812:	lahf
    7db2f9502813:	seto   al
    7db2f9502816:	mov    WORD PTR [rsp],ax
    7db2f950281a:	mov    rax,r11
    7db2f950281d:	jmp    0x7db2f9502822
    7db2f9502822:	mov    r13,QWORD PTR [r12+0x50]
    7db2f9502827:	mov    r14,r13
    7db2f950282a:	add    r14,0x10
    7db2f950282e:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7db2f9502834:	movdqu xmm3,XMMWORD PTR [r14]
    7db2f9502839:	movdqu XMMWORD PTR [r12+0x110],xmm2
    7db2f9502843:	movdqu XMMWORD PTR [r12+0x250],xmm3
    7db2f950284d:	mov    r14d,0x0
    7db2f9502853:	mov    QWORD PTR [r12+0x48],r14
    7db2f9502858:	mov    r14,r13
    7db2f950285b:	add    r14,0x40
    7db2f950285f:	mov    r15,r14
    7db2f9502862:	add    r15,0x10
    7db2f9502866:	movdqu xmm3,XMMWORD PTR [r14]
    7db2f950286b:	movdqu xmm4,XMMWORD PTR [r15]
    7db2f9502870:	movdqu XMMWORD PTR [r12+0x210],xmm3
    7db2f950287a:	movdqu XMMWORD PTR [r12+0x1c0],xmm4
    7db2f9502884:	mov    r14,r13
    7db2f9502887:	add    r14,0x80
    7db2f950288e:	mov    r15,r14
    7db2f9502891:	add    r15,0x10
    7db2f9502895:	movdqu xmm3,XMMWORD PTR [r14]
    7db2f950289a:	movdqu xmm4,XMMWORD PTR [r15]
    7db2f950289f:	movdqu XMMWORD PTR [r12+0x260],xmm3
    7db2f95028a9:	movdqu XMMWORD PTR [r12+0x280],xmm4
    7db2f95028b3:	mov    r14,QWORD PTR [r12+0xf8]
    7db2f95028bb:	movdqu XMMWORD PTR [r14],xmm2
    7db2f95028c0:	mov    r15d,0x0
    7db2f95028c6:	mov    DWORD PTR [r12+0x32c],r15d
    7db2f95028ce:	mov    r15,r13
    7db2f95028d1:	add    r15,0x20
    7db2f95028d5:	mov    rbp,r15
    7db2f95028d8:	add    rbp,0x10
    7db2f95028dc:	movdqu xmm2,XMMWORD PTR [r15]
    7db2f95028e1:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7db2f95028e6:	movdqu XMMWORD PTR [r12+0x170],xmm2
    7db2f95028f0:	movdqu XMMWORD PTR [r12+0x110],xmm3
    7db2f95028fa:	mov    r15,r13
    7db2f95028fd:	add    r15,0xc0
    7db2f9502904:	mov    rbp,r15
    7db2f9502907:	add    rbp,0x10
    7db2f950290b:	movdqu xmm4,XMMWORD PTR [r15]
    7db2f9502910:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    7db2f9502915:	movdqu XMMWORD PTR [r12+0x180],xmm4
    7db2f950291f:	movdqu XMMWORD PTR [r12+0x290],xmm5
    7db2f9502929:	mov    r15,r13
    7db2f950292c:	add    r15,0x100
    7db2f9502933:	mov    rbp,r15
    7db2f9502936:	add    rbp,0x10
    7db2f950293a:	movdqu xmm4,XMMWORD PTR [r15]
    7db2f950293f:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    7db2f9502944:	movdqu XMMWORD PTR [r12+0x160],xmm4
    7db2f950294e:	movdqu XMMWORD PTR [r12+0x2a0],xmm5
    7db2f9502958:	mov    r15,r13
    7db2f950295b:	add    r15,0x140
    7db2f9502962:	mov    rbp,r15
    7db2f9502965:	add    rbp,0x10
    7db2f9502969:	movdqu xmm4,XMMWORD PTR [r15]
    7db2f950296e:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    7db2f9502973:	movdqu XMMWORD PTR [r12+0x150],xmm4
    7db2f950297d:	movdqu XMMWORD PTR [r12+0x2b0],xmm5
    7db2f9502987:	mov    r15,r14
    7db2f950298a:	add    r15,0xb0
    7db2f9502991:	mov    rbp,r15
    7db2f9502994:	add    rbp,0x10
    7db2f9502998:	movdqu XMMWORD PTR [r15],xmm3
    7db2f950299d:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7db2f95029a2:	mov    r15,r13
    7db2f95029a5:	add    r15,0x180
    7db2f95029ac:	mov    rbp,r15
    7db2f95029af:	add    rbp,0x10
    7db2f95029b3:	movdqu xmm2,XMMWORD PTR [r15]
    7db2f95029b8:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7db2f95029bd:	movdqu XMMWORD PTR [r12+0x2f0],xmm2
    7db2f95029c7:	movdqu XMMWORD PTR [r12+0x120],xmm3
    7db2f95029d1:	mov    r15,r13
    7db2f95029d4:	add    r15,0x1c0
    7db2f95029db:	mov    rbp,r15
    7db2f95029de:	add    rbp,0x10
    7db2f95029e2:	movdqu xmm5,XMMWORD PTR [r15]
    7db2f95029e7:	movdqu xmm6,XMMWORD PTR [rbp+0x0]
    7db2f95029ec:	movdqu XMMWORD PTR [r12+0x130],xmm5
    7db2f95029f6:	movdqu XMMWORD PTR [r12+0x140],xmm6
    7db2f9502a00:	mov    r15,r13
    7db2f9502a03:	add    r15,0x60
    7db2f9502a07:	mov    rbp,r15
    7db2f9502a0a:	add    rbp,0x10
    7db2f9502a0e:	movdqu xmm7,XMMWORD PTR [r15]
    7db2f9502a13:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    7db2f9502a19:	movdqu XMMWORD PTR [r12+0x2e0],xmm7
    7db2f9502a23:	movdqu XMMWORD PTR [r12+0x1f0],xmm8
    7db2f9502a2d:	mov    r15,r14
    7db2f9502a30:	add    r15,0x70
    7db2f9502a34:	mov    rbp,r15
    7db2f9502a37:	add    rbp,0x10
    7db2f9502a3b:	movdqu XMMWORD PTR [r15],xmm3
    7db2f9502a40:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7db2f9502a45:	mov    r15,r13
    7db2f9502a48:	add    r15,0xa0
    7db2f9502a4f:	mov    rbp,r15
    7db2f9502a52:	add    rbp,0x10
    7db2f9502a56:	movdqu xmm2,XMMWORD PTR [r15]
    7db2f9502a5b:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7db2f9502a60:	movdqu XMMWORD PTR [r12+0x2c0],xmm2
    7db2f9502a6a:	movdqu XMMWORD PTR [r12+0x1d0],xmm3
    7db2f9502a74:	mov    r15,r14
    7db2f9502a77:	add    r15,0x90
    7db2f9502a7e:	mov    rbp,r15
    7db2f9502a81:	add    rbp,0x10
    7db2f9502a85:	movdqu XMMWORD PTR [r15],xmm6
    7db2f9502a8a:	movdqu XMMWORD PTR [rbp+0x0],xmm5
    7db2f9502a8f:	mov    r15,r13
    7db2f9502a92:	add    r15,0xe0
    7db2f9502a99:	mov    rbp,r15
    7db2f9502a9c:	add    rbp,0x10
    7db2f9502aa0:	movdqu xmm2,XMMWORD PTR [r15]
    7db2f9502aa5:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7db2f9502aaa:	movdqu XMMWORD PTR [r12+0x300],xmm2
    7db2f9502ab4:	movdqu XMMWORD PTR [r12+0x2d0],xmm3
    7db2f9502abe:	mov    r15,r13
    7db2f9502ac1:	add    r15,0x120
    7db2f9502ac8:	mov    rbp,r15
    7db2f9502acb:	add    rbp,0x10
    7db2f9502acf:	movdqu xmm2,XMMWORD PTR [r15]
    7db2f9502ad4:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7db2f9502ad9:	movdqu XMMWORD PTR [r12+0x190],xmm2
    7db2f9502ae3:	movdqu XMMWORD PTR [r12+0x1e0],xmm3
    7db2f9502aed:	mov    r15,r13
    7db2f9502af0:	add    r15,0x160
    7db2f9502af7:	mov    rbp,r15
    7db2f9502afa:	add    rbp,0x10
    7db2f9502afe:	movdqu xmm2,XMMWORD PTR [r15]
    7db2f9502b03:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    7db2f9502b08:	movdqu XMMWORD PTR [r12+0x1a0],xmm2
    7db2f9502b12:	movdqu XMMWORD PTR [r12+0x1b0],xmm3
    7db2f9502b1c:	mov    r15,r13
    7db2f9502b1f:	add    r15,0x1a0
    7db2f9502b26:	mov    rbp,r15
    7db2f9502b29:	add    rbp,0x10
    7db2f9502b2d:	movdqu xmm5,XMMWORD PTR [r15]
    7db2f9502b32:	movdqu xmm6,XMMWORD PTR [rbp+0x0]
    7db2f9502b37:	movdqu XMMWORD PTR [r12+0x200],xmm5
    7db2f9502b41:	movdqu XMMWORD PTR [r12+0x170],xmm6
    7db2f9502b4b:	add    r13,0x1e0
    7db2f9502b52:	mov    r15,r13
    7db2f9502b55:	add    r15,0x10
    7db2f9502b59:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    7db2f9502b5f:	movdqu xmm7,XMMWORD PTR [r15]
    7db2f9502b64:	movdqu XMMWORD PTR [r12+0x110],xmm5
    7db2f9502b6e:	movdqu XMMWORD PTR [r12+0x270],xmm7
    7db2f9502b78:	mov    r13d,0x432000
    7db2f9502b7e:	add    r13,0x190
    7db2f9502b85:	mov    QWORD PTR [r12+0x50],r13
    7db2f9502b8a:	mov    r13,r14
    7db2f9502b8d:	add    r13,0x50
    7db2f9502b91:	mov    r15,r13
    7db2f9502b94:	add    r15,0x10
    7db2f9502b98:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7db2f9502b9e:	movdqu XMMWORD PTR [r15],xmm4
    7db2f9502ba3:	mov    r13,r14
    7db2f9502ba6:	add    r13,0x40
    7db2f9502baa:	movdqu XMMWORD PTR [r13+0x0],xmm3
    7db2f9502bb0:	mov    r13,r14
    7db2f9502bb3:	add    r13,0x20
    7db2f9502bb7:	mov    r15,r13
    7db2f9502bba:	add    r15,0x10
    7db2f9502bbe:	movdqu XMMWORD PTR [r13+0x0],xmm5
    7db2f9502bc4:	movdqu XMMWORD PTR [r15],xmm6
    7db2f9502bc9:	add    r14,0x10
    7db2f9502bcd:	movdqu XMMWORD PTR [r14],xmm7
    7db2f9502bd2:	mov    r11,rax
    7db2f9502bd5:	movzx  eax,WORD PTR [rsp]
    7db2f9502bd9:	add    al,0x7f
    7db2f9502bdb:	sahf
    7db2f9502bdc:	mov    rax,r11
    7db2f9502bdf:	jmp    0x7db2f9502be4
    7db2f9502be4:	mov    r13d,0x0
    7db2f9502bea:	mov    QWORD PTR [r12+0x58],r13
    7db2f9502bef:	mov    r11,rax
    7db2f9502bf2:	lahf
    7db2f9502bf3:	seto   al
    7db2f9502bf6:	mov    WORD PTR [rsp],ax
    7db2f9502bfa:	mov    rax,r11
    7db2f9502bfd:	jmp    0x7db2f9502c02
    7db2f9502c02:	mov    r13,QWORD PTR [r12+0x58]
    7db2f9502c07:	mov    r14,QWORD PTR [r12+0x40]
    7db2f9502c0c:	add    r14,r13
    7db2f9502c0f:	mov    QWORD PTR [r12+0x60],r14
    7db2f9502c14:	mov    r15d,0x0
    7db2f9502c1a:	mov    ebp,0x0
    7db2f9502c1f:	mov    QWORD PTR [r12+0x110],r15
    7db2f9502c27:	mov    QWORD PTR [r12+0x118],rbp
    7db2f9502c2f:	mov    r15d,0x0
    7db2f9502c35:	mov    ebp,0x0
    7db2f9502c3a:	mov    QWORD PTR [r12+0x170],r15
    7db2f9502c42:	mov    QWORD PTR [r12+0x178],rbp
    7db2f9502c4a:	mov    r15,r14
    7db2f9502c4d:	add    r15,0x30
    7db2f9502c51:	mov    rbp,r15
    7db2f9502c54:	add    rbp,0x8
    7db2f9502c58:	mov    r8,QWORD PTR [r15]
    7db2f9502c5b:	mov    r15,QWORD PTR [rbp+0x0]
    7db2f9502c5f:	mov    ebp,0x0
    7db2f9502c64:	mov    QWORD PTR [r12+0x130],r8
    7db2f9502c6c:	mov    QWORD PTR [r12+0x138],rbp
    7db2f9502c74:	mov    ebp,0x0
    7db2f9502c79:	mov    QWORD PTR [r12+0x270],r15
    7db2f9502c81:	mov    QWORD PTR [r12+0x278],rbp
    7db2f9502c89:	movdqu xmm2,XMMWORD PTR [r12+0x160]
    7db2f9502c93:	movdqa xmm1,xmm2
    7db2f9502c97:	por    xmm2,xmm1
    7db2f9502c9b:	movdqu XMMWORD PTR [r12+0x1b0],xmm2
    7db2f9502ca5:	mov    r15,r14
    7db2f9502ca8:	add    r15,0x20
    7db2f9502cac:	mov    rbp,r15
    7db2f9502caf:	add    rbp,0x8
    7db2f9502cb3:	mov    r8,QWORD PTR [r15]
    7db2f9502cb6:	mov    r15,QWORD PTR [rbp+0x0]
    7db2f9502cba:	mov    ebp,0x0
    7db2f9502cbf:	mov    QWORD PTR [r12+0x150],r8
    7db2f9502cc7:	mov    QWORD PTR [r12+0x158],rbp
    7db2f9502ccf:	mov    ebp,0x0
    7db2f9502cd4:	mov    QWORD PTR [r12+0x140],r15
    7db2f9502cdc:	mov    QWORD PTR [r12+0x148],rbp
    7db2f9502ce4:	movdqu xmm2,XMMWORD PTR [r12+0x2d0]
    7db2f9502cee:	movdqa xmm1,xmm2
    7db2f9502cf2:	por    xmm2,xmm1
    7db2f9502cf6:	movdqu XMMWORD PTR [r12+0x1a0],xmm2
    7db2f9502d00:	movdqu xmm2,XMMWORD PTR [r12+0x300]
    7db2f9502d0a:	movdqa xmm1,xmm2
    7db2f9502d0e:	por    xmm2,xmm1
    7db2f9502d12:	movdqu XMMWORD PTR [r12+0x2f0],xmm2
    7db2f9502d1c:	movdqu xmm2,XMMWORD PTR [r12+0x2b0]
    7db2f9502d26:	movdqa xmm1,xmm2
    7db2f9502d2a:	por    xmm2,xmm1
    7db2f9502d2e:	movdqu XMMWORD PTR [r12+0x300],xmm2
    7db2f9502d38:	movdqu xmm2,XMMWORD PTR [r12+0x180]
    7db2f9502d42:	movdqa xmm1,xmm2
    7db2f9502d46:	por    xmm2,xmm1
    7db2f9502d4a:	movdqu XMMWORD PTR [r12+0x2d0],xmm2
    7db2f9502d54:	mov    r15,r14
    7db2f9502d57:	add    r15,0x10
    7db2f9502d5b:	mov    rbp,r15
    7db2f9502d5e:	add    rbp,0x8
    7db2f9502d62:	mov    r8,QWORD PTR [r15]
    7db2f9502d65:	mov    r15,QWORD PTR [rbp+0x0]
    7db2f9502d69:	mov    ebp,0x0
    7db2f9502d6e:	mov    QWORD PTR [r12+0x180],r8
    7db2f9502d76:	mov    QWORD PTR [r12+0x188],rbp
    7db2f9502d7e:	mov    ebp,0x0
    7db2f9502d83:	mov    QWORD PTR [r12+0x160],r15
    7db2f9502d8b:	mov    QWORD PTR [r12+0x168],rbp
    7db2f9502d93:	movdqu xmm2,XMMWORD PTR [r12+0x200]
    7db2f9502d9d:	movdqa xmm1,xmm2
    7db2f9502da1:	por    xmm2,xmm1
    7db2f9502da5:	movdqu XMMWORD PTR [r12+0x2b0],xmm2
    7db2f9502daf:	movdqu xmm2,XMMWORD PTR [r12+0x1f0]
    7db2f9502db9:	movdqa xmm1,xmm2
    7db2f9502dbd:	por    xmm2,xmm1
    7db2f9502dc1:	movdqu XMMWORD PTR [r12+0x200],xmm2
    7db2f9502dcb:	movdqu xmm2,XMMWORD PTR [r12+0x2e0]
    7db2f9502dd5:	movdqa xmm1,xmm2
    7db2f9502dd9:	por    xmm2,xmm1
    7db2f9502ddd:	movdqu XMMWORD PTR [r12+0x1f0],xmm2
    7db2f9502de7:	movdqu xmm2,XMMWORD PTR [r12+0x2a0]
    7db2f9502df1:	movdqa xmm1,xmm2
    7db2f9502df5:	por    xmm2,xmm1
    7db2f9502df9:	movdqu XMMWORD PTR [r12+0x2e0],xmm2
    7db2f9502e03:	movdqu xmm2,XMMWORD PTR [r12+0x280]
    7db2f9502e0d:	movdqa xmm1,xmm2
    7db2f9502e11:	por    xmm2,xmm1
    7db2f9502e15:	movdqu XMMWORD PTR [r12+0x2a0],xmm2
    7db2f9502e1f:	movdqu xmm2,XMMWORD PTR [r12+0x1c0]
    7db2f9502e29:	movdqa xmm1,xmm2
    7db2f9502e2d:	por    xmm2,xmm1
    7db2f9502e31:	movdqu XMMWORD PTR [r12+0x280],xmm2
    7db2f9502e3b:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    7db2f9502e45:	movdqa xmm1,xmm2
    7db2f9502e49:	por    xmm2,xmm1
    7db2f9502e4d:	movdqu XMMWORD PTR [r12+0x1c0],xmm2
    7db2f9502e57:	mov    r15d,0x8
    7db2f9502e5d:	mov    rbp,QWORD PTR [r14]
    7db2f9502e60:	mov    QWORD PTR [r12+0x210],rbp
    7db2f9502e68:	mov    QWORD PTR [r12+0x218],rbp
    7db2f9502e70:	add    r14,r15
    7db2f9502e73:	mov    QWORD PTR [r12+0x60],r14
    7db2f9502e78:	mov    r15d,0x0
    7db2f9502e7e:	mov    ebp,0x0
    7db2f9502e83:	mov    QWORD PTR [r12+0x220],r15
    7db2f9502e8b:	mov    QWORD PTR [r12+0x228],rbp
    7db2f9502e93:	mov    r15,QWORD PTR [r12+0xf8]
    7db2f9502e9b:	movdqu xmm2,XMMWORD PTR [r15]
    7db2f9502ea0:	movdqu XMMWORD PTR [r12+0x120],xmm2
    7db2f9502eaa:	mov    r15d,0x0
    7db2f9502eb0:	mov    ebp,0x0
    7db2f9502eb5:	mov    QWORD PTR [r12+0x230],r15
    7db2f9502ebd:	mov    QWORD PTR [r12+0x238],rbp
    7db2f9502ec5:	mov    r15,QWORD PTR [r14]
    7db2f9502ec8:	mov    r14d,0x0
    7db2f9502ece:	mov    QWORD PTR [r12+0x240],r15
    7db2f9502ed6:	mov    QWORD PTR [r12+0x248],r14
    7db2f9502ede:	mov    r14,QWORD PTR [r12+0x50]
    7db2f9502ee3:	add    r14,r13
    7db2f9502ee6:	mov    QWORD PTR [r12+0x60],r14
    7db2f9502eeb:	add    r13,0x40
    7db2f9502eef:	mov    QWORD PTR [r12+0x58],r13
    7db2f9502ef4:	lea    r13,[r12]
    7db2f9502ef8:	movabs r14,0x164e70cc20
    7db2f9502f02:	mov    r15d,0x410554
    7db2f9502f08:	mov    rdx,QWORD PTR [rsp]
    7db2f9502f0c:	mov    r10d,edx
    7db2f9502f0f:	and    r10d,0xc000
    7db2f9502f16:	shl    r10d,0x10
    7db2f9502f1a:	mov    r11d,edx
    7db2f9502f1d:	and    r11d,0x100
    7db2f9502f24:	shl    r11d,0x15
    7db2f9502f28:	or     r10d,r11d
    7db2f9502f2b:	and    edx,0x1
    7db2f9502f2e:	shl    edx,0x1c
    7db2f9502f31:	or     r10d,edx
    7db2f9502f34:	btc    r10,0x1d
    7db2f9502f39:	mov    r11d,0xf0000000
    7db2f9502f3f:	and    r11,r10
    7db2f9502f42:	movabs rsi,0xffffffff0fffffff
    7db2f9502f4c:	and    rbx,rsi
    7db2f9502f4f:	or     rbx,r11
    7db2f9502f52:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7db2f9502f5c:	movdqu xmm1,XMMWORD PTR [r12+0x210]
    7db2f9502f66:	movdqu xmm14,XMMWORD PTR [r12+0x110]
    7db2f9502f70:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f9502f75:	movdqa xmm14,xmm0
    7db2f9502f7a:	movdqu xmm15,XMMWORD PTR [rip+0x3aed]        # 0x7db2f9506a70
    7db2f9502f83:	pand   xmm14,xmm15
    7db2f9502f88:	movdqu xmm15,XMMWORD PTR [rip+0x3aef]        # 0x7db2f9506a80
    7db2f9502f91:	pcmpeqq xmm14,xmm15
    7db2f9502f97:	movdqa xmm15,xmm0
    7db2f9502f9c:	cmpunordpd xmm15,xmm0
    7db2f9502fa2:	por    xmm14,xmm15
    7db2f9502fa7:	pmovmskb ecx,xmm14
    7db2f9502fac:	jrcxz  0x7db2f9502fb3
    7db2f9502fae:	jmp    0x7db2f9504fa5
    7db2f9502fb3:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7db2f9502fbd:	mov    eax,0x0
    7db2f9502fc2:	mov    DWORD PTR [r12+0x324],0x0
    7db2f9502fce:	mov    rbp,rax
    7db2f9502fd1:	lea    r13,[r12]
    7db2f9502fd5:	movabs r14,0x164e70ce86
    7db2f9502fdf:	mov    r15d,0x410558
    7db2f9502fe5:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    7db2f9502fef:	movdqu xmm1,XMMWORD PTR [r12+0x210]
    7db2f9502ff9:	movdqu xmm14,XMMWORD PTR [r12+0x170]
    7db2f9503003:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f9503008:	movdqa xmm14,xmm0
    7db2f950300d:	movdqu xmm15,XMMWORD PTR [rip+0x3a5a]        # 0x7db2f9506a70
    7db2f9503016:	pand   xmm14,xmm15
    7db2f950301b:	movdqu xmm15,XMMWORD PTR [rip+0x3a5c]        # 0x7db2f9506a80
    7db2f9503024:	pcmpeqq xmm14,xmm15
    7db2f950302a:	movdqa xmm15,xmm0
    7db2f950302f:	cmpunordpd xmm15,xmm0
    7db2f9503035:	por    xmm14,xmm15
    7db2f950303a:	pmovmskb ecx,xmm14
    7db2f950303f:	jrcxz  0x7db2f9503046
    7db2f9503041:	jmp    0x7db2f950502b
    7db2f9503046:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7db2f9503050:	mov    eax,0x0
    7db2f9503055:	mov    DWORD PTR [r12+0x324],0x0
    7db2f9503061:	mov    rbp,rax
    7db2f9503064:	movdqu xmm2,XMMWORD PTR [r12+0x1e0]
    7db2f950306e:	movdqa xmm1,xmm2
    7db2f9503072:	por    xmm2,xmm1
    7db2f9503076:	movdqu XMMWORD PTR [r12+0x120],xmm2
    7db2f9503080:	movdqu xmm2,XMMWORD PTR [r12+0x1d0]
    7db2f950308a:	movdqa xmm1,xmm2
    7db2f950308e:	por    xmm2,xmm1
    7db2f9503092:	movdqu XMMWORD PTR [r12+0x1e0],xmm2
    7db2f950309c:	movdqu xmm2,XMMWORD PTR [r12+0x2c0]
    7db2f95030a6:	movdqa xmm1,xmm2
    7db2f95030aa:	por    xmm2,xmm1
    7db2f95030ae:	movdqu XMMWORD PTR [r12+0x1d0],xmm2
    7db2f95030b8:	movdqu xmm2,XMMWORD PTR [r12+0x290]
    7db2f95030c2:	movdqa xmm1,xmm2
    7db2f95030c6:	por    xmm2,xmm1
    7db2f95030ca:	movdqu XMMWORD PTR [r12+0x2c0],xmm2
    7db2f95030d4:	movdqu xmm2,XMMWORD PTR [r12+0x260]
    7db2f95030de:	movdqa xmm1,xmm2
    7db2f95030e2:	por    xmm2,xmm1
    7db2f95030e6:	movdqu XMMWORD PTR [r12+0x290],xmm2
    7db2f95030f0:	movdqu xmm2,XMMWORD PTR [r12+0x250]
    7db2f95030fa:	movdqa xmm1,xmm2
    7db2f95030fe:	por    xmm2,xmm1
    7db2f9503102:	movdqu XMMWORD PTR [r12+0x260],xmm2
    7db2f950310c:	mov    r13,QWORD PTR [r12+0xf8]
    7db2f9503114:	add    r13,0xc0
    7db2f950311b:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7db2f9503121:	movdqu XMMWORD PTR [r12+0x250],xmm2
    7db2f950312b:	mov    r13,QWORD PTR [r12+0x58]
    7db2f9503130:	sub    r13,0x200
    7db2f9503137:	lea    r13,[r12]
    7db2f950313b:	movabs r14,0x164e70ce91
    7db2f9503145:	mov    r15d,0x41057c
    7db2f950314b:	mov    r11,rax
    7db2f950314e:	lahf
    7db2f950314f:	seto   al
    7db2f9503152:	mov    WORD PTR [rsp],ax
    7db2f9503156:	mov    rax,r11
    7db2f9503159:	mov    rdx,QWORD PTR [rsp]
    7db2f950315d:	mov    r10d,edx
    7db2f9503160:	and    r10d,0xc000
    7db2f9503167:	shl    r10d,0x10
    7db2f950316b:	mov    r11d,edx
    7db2f950316e:	and    r11d,0x100
    7db2f9503175:	shl    r11d,0x15
    7db2f9503179:	or     r10d,r11d
    7db2f950317c:	and    edx,0x1
    7db2f950317f:	shl    edx,0x1c
    7db2f9503182:	or     r10d,edx
    7db2f9503185:	btc    r10,0x1d
    7db2f950318a:	mov    r11d,0xf0000000
    7db2f9503190:	and    r11,r10
    7db2f9503193:	movabs rsi,0xffffffff0fffffff
    7db2f950319d:	and    rbx,rsi
    7db2f95031a0:	or     rbx,r11
    7db2f95031a3:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    7db2f95031ad:	movdqu xmm1,XMMWORD PTR [r12+0x210]
    7db2f95031b7:	movdqu xmm14,XMMWORD PTR [r12+0x220]
    7db2f95031c1:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f95031c6:	movdqa xmm14,xmm0
    7db2f95031cb:	movdqu xmm15,XMMWORD PTR [rip+0x389c]        # 0x7db2f9506a70
    7db2f95031d4:	pand   xmm14,xmm15
    7db2f95031d9:	movdqu xmm15,XMMWORD PTR [rip+0x389e]        # 0x7db2f9506a80
    7db2f95031e2:	pcmpeqq xmm14,xmm15
    7db2f95031e8:	movdqa xmm15,xmm0
    7db2f95031ed:	cmpunordpd xmm15,xmm0
    7db2f95031f3:	por    xmm14,xmm15
    7db2f95031f8:	pmovmskb ecx,xmm14
    7db2f95031fd:	jrcxz  0x7db2f9503204
    7db2f95031ff:	jmp    0x7db2f95050b1
    7db2f9503204:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7db2f950320e:	mov    eax,0x0
    7db2f9503213:	mov    DWORD PTR [r12+0x324],0x0
    7db2f950321f:	mov    rbp,rax
    7db2f9503222:	mov    r13,QWORD PTR [r12+0xf8]
    7db2f950322a:	add    r13,0xb0
    7db2f9503231:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7db2f9503237:	movdqu XMMWORD PTR [r12+0x250],xmm2
    7db2f9503241:	lea    r13,[r12]
    7db2f9503245:	movabs r14,0x164e70ce92
    7db2f950324f:	mov    r15d,0x410584
    7db2f9503255:	movdqu xmm0,XMMWORD PTR [r12+0x250]
    7db2f950325f:	movdqu xmm1,XMMWORD PTR [r12+0x210]
    7db2f9503269:	movdqu xmm14,XMMWORD PTR [r12+0x230]
    7db2f9503273:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f9503278:	movdqa xmm14,xmm0
    7db2f950327d:	movdqu xmm15,XMMWORD PTR [rip+0x37ea]        # 0x7db2f9506a70
    7db2f9503286:	pand   xmm14,xmm15
    7db2f950328b:	movdqu xmm15,XMMWORD PTR [rip+0x37ec]        # 0x7db2f9506a80
    7db2f9503294:	pcmpeqq xmm14,xmm15
    7db2f950329a:	movdqa xmm15,xmm0
    7db2f950329f:	cmpunordpd xmm15,xmm0
    7db2f95032a5:	por    xmm14,xmm15
    7db2f95032aa:	pmovmskb ecx,xmm14
    7db2f95032af:	jrcxz  0x7db2f95032b6
    7db2f95032b1:	jmp    0x7db2f9505137
    7db2f95032b6:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7db2f95032c0:	mov    eax,0x0
    7db2f95032c5:	mov    DWORD PTR [r12+0x324],0x0
    7db2f95032d1:	mov    rbp,rax
    7db2f95032d4:	movdqu xmm2,XMMWORD PTR [r12+0x1c0]
    7db2f95032de:	movdqa xmm1,xmm2
    7db2f95032e2:	por    xmm2,xmm1
    7db2f95032e6:	movdqu XMMWORD PTR [r12+0x210],xmm2
    7db2f95032f0:	movdqu xmm2,XMMWORD PTR [r12+0x280]
    7db2f95032fa:	movdqa xmm1,xmm2
    7db2f95032fe:	por    xmm2,xmm1
    7db2f9503302:	movdqu XMMWORD PTR [r12+0x1c0],xmm2
    7db2f950330c:	movdqu xmm2,XMMWORD PTR [r12+0x2a0]
    7db2f9503316:	movdqa xmm1,xmm2
    7db2f950331a:	por    xmm2,xmm1
    7db2f950331e:	movdqu XMMWORD PTR [r12+0x280],xmm2
    7db2f9503328:	movdqu xmm2,XMMWORD PTR [r12+0x2e0]
    7db2f9503332:	movdqa xmm1,xmm2
    7db2f9503336:	por    xmm2,xmm1
    7db2f950333a:	movdqu XMMWORD PTR [r12+0x2a0],xmm2
    7db2f9503344:	movdqu xmm2,XMMWORD PTR [r12+0x1f0]
    7db2f950334e:	movdqa xmm1,xmm2
    7db2f9503352:	por    xmm2,xmm1
    7db2f9503356:	movdqu XMMWORD PTR [r12+0x2e0],xmm2
    7db2f9503360:	movdqu xmm2,XMMWORD PTR [r12+0x200]
    7db2f950336a:	movdqa xmm1,xmm2
    7db2f950336e:	por    xmm2,xmm1
    7db2f9503372:	movdqu XMMWORD PTR [r12+0x1f0],xmm2
    7db2f950337c:	movdqu xmm2,XMMWORD PTR [r12+0x260]
    7db2f9503386:	movdqa xmm1,xmm2
    7db2f950338a:	por    xmm2,xmm1
    7db2f950338e:	movdqu XMMWORD PTR [r12+0x250],xmm2
    7db2f9503398:	movdqu xmm2,XMMWORD PTR [r12+0x290]
    7db2f95033a2:	movdqa xmm1,xmm2
    7db2f95033a6:	por    xmm2,xmm1
    7db2f95033aa:	movdqu XMMWORD PTR [r12+0x260],xmm2
    7db2f95033b4:	movdqu xmm2,XMMWORD PTR [r12+0x2c0]
    7db2f95033be:	movdqa xmm1,xmm2
    7db2f95033c2:	por    xmm2,xmm1
    7db2f95033c6:	movdqu XMMWORD PTR [r12+0x290],xmm2
    7db2f95033d0:	movdqu xmm2,XMMWORD PTR [r12+0x1d0]
    7db2f95033da:	movdqa xmm1,xmm2
    7db2f95033de:	por    xmm2,xmm1
    7db2f95033e2:	movdqu XMMWORD PTR [r12+0x2c0],xmm2
    7db2f95033ec:	lea    r13,[r12]
    7db2f95033f0:	movabs r14,0x184fd31200
    7db2f95033fa:	mov    r15d,0x4105b0
    7db2f9503400:	movdqu xmm0,XMMWORD PTR [r12+0x210]
    7db2f950340a:	movdqu xmm1,XMMWORD PTR [r12+0x240]
    7db2f9503414:	pshufd xmm1,xmm1,0x44
    7db2f9503419:	movdqu xmm14,XMMWORD PTR [r12+0x110]
    7db2f9503423:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f9503428:	movdqa xmm14,xmm0
    7db2f950342d:	movdqu xmm15,XMMWORD PTR [rip+0x363a]        # 0x7db2f9506a70
    7db2f9503436:	pand   xmm14,xmm15
    7db2f950343b:	movdqu xmm15,XMMWORD PTR [rip+0x363c]        # 0x7db2f9506a80
    7db2f9503444:	pcmpeqq xmm14,xmm15
    7db2f950344a:	movdqa xmm15,xmm0
    7db2f950344f:	cmpunordpd xmm15,xmm0
    7db2f9503455:	por    xmm14,xmm15
    7db2f950345a:	pmovmskb ecx,xmm14
    7db2f950345f:	jrcxz  0x7db2f9503466
    7db2f9503461:	jmp    0x7db2f95051bd
    7db2f9503466:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7db2f9503470:	mov    eax,0x0
    7db2f9503475:	mov    DWORD PTR [r12+0x324],0x0
    7db2f9503481:	mov    rbp,rax
    7db2f9503484:	lea    r13,[r12]
    7db2f9503488:	movabs r14,0x184fd313b1
    7db2f9503492:	mov    r15d,0x4105b4
    7db2f9503498:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    7db2f95034a2:	movdqu xmm1,XMMWORD PTR [r12+0x240]
    7db2f95034ac:	pshufd xmm1,xmm1,0x44
    7db2f95034b1:	movdqu xmm14,XMMWORD PTR [r12+0x220]
    7db2f95034bb:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f95034c0:	movdqa xmm14,xmm0
    7db2f95034c5:	movdqu xmm15,XMMWORD PTR [rip+0x35a2]        # 0x7db2f9506a70
    7db2f95034ce:	pand   xmm14,xmm15
    7db2f95034d3:	movdqu xmm15,XMMWORD PTR [rip+0x35a4]        # 0x7db2f9506a80
    7db2f95034dc:	pcmpeqq xmm14,xmm15
    7db2f95034e2:	movdqa xmm15,xmm0
    7db2f95034e7:	cmpunordpd xmm15,xmm0
    7db2f95034ed:	por    xmm14,xmm15
    7db2f95034f2:	pmovmskb ecx,xmm14
    7db2f95034f7:	jrcxz  0x7db2f95034fe
    7db2f95034f9:	jmp    0x7db2f9505243
    7db2f95034fe:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7db2f9503508:	mov    eax,0x0
    7db2f950350d:	mov    DWORD PTR [r12+0x324],0x0
    7db2f9503519:	mov    rbp,rax
    7db2f950351c:	lea    r13,[r12]
    7db2f9503520:	movabs r14,0x184fd31166
    7db2f950352a:	mov    r15d,0x4105b8
    7db2f9503530:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    7db2f950353a:	movdqu xmm1,XMMWORD PTR [r12+0x240]
    7db2f9503544:	pshufd xmm1,xmm1,0x44
    7db2f9503549:	movdqu xmm14,XMMWORD PTR [r12+0x170]
    7db2f9503553:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f9503558:	movdqa xmm14,xmm0
    7db2f950355d:	movdqu xmm15,XMMWORD PTR [rip+0x350a]        # 0x7db2f9506a70
    7db2f9503566:	pand   xmm14,xmm15
    7db2f950356b:	movdqu xmm15,XMMWORD PTR [rip+0x350c]        # 0x7db2f9506a80
    7db2f9503574:	pcmpeqq xmm14,xmm15
    7db2f950357a:	movdqa xmm15,xmm0
    7db2f950357f:	cmpunordpd xmm15,xmm0
    7db2f9503585:	por    xmm14,xmm15
    7db2f950358a:	pmovmskb ecx,xmm14
    7db2f950358f:	jrcxz  0x7db2f9503596
    7db2f9503591:	jmp    0x7db2f95052c9
    7db2f9503596:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7db2f95035a0:	mov    eax,0x0
    7db2f95035a5:	mov    DWORD PTR [r12+0x324],0x0
    7db2f95035b1:	mov    rbp,rax
    7db2f95035b4:	movdqu xmm2,XMMWORD PTR [r12+0x1e0]
    7db2f95035be:	movdqa xmm1,xmm2
    7db2f95035c2:	por    xmm2,xmm1
    7db2f95035c6:	movdqu XMMWORD PTR [r12+0x1d0],xmm2
    7db2f95035d0:	lea    r13,[r12]
    7db2f95035d4:	movabs r14,0x184fd311d2
    7db2f95035de:	mov    r15d,0x4105c0
    7db2f95035e4:	movdqu xmm0,XMMWORD PTR [r12+0x1f0]
    7db2f95035ee:	movdqu xmm1,XMMWORD PTR [r12+0x240]
    7db2f95035f8:	pshufd xmm1,xmm1,0x44
    7db2f95035fd:	movdqu xmm14,XMMWORD PTR [r12+0x230]
    7db2f9503607:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f950360c:	movdqa xmm14,xmm0
    7db2f9503611:	movdqu xmm15,XMMWORD PTR [rip+0x3456]        # 0x7db2f9506a70
    7db2f950361a:	pand   xmm14,xmm15
    7db2f950361f:	movdqu xmm15,XMMWORD PTR [rip+0x3458]        # 0x7db2f9506a80
    7db2f9503628:	pcmpeqq xmm14,xmm15
    7db2f950362e:	movdqa xmm15,xmm0
    7db2f9503633:	cmpunordpd xmm15,xmm0
    7db2f9503639:	por    xmm14,xmm15
    7db2f950363e:	pmovmskb ecx,xmm14
    7db2f9503643:	jrcxz  0x7db2f950364a
    7db2f9503645:	jmp    0x7db2f950534f
    7db2f950364a:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7db2f9503654:	mov    eax,0x0
    7db2f9503659:	mov    DWORD PTR [r12+0x324],0x0
    7db2f9503665:	mov    rbp,rax
    7db2f9503668:	movdqu xmm2,XMMWORD PTR [r12+0x2b0]
    7db2f9503672:	movdqa xmm1,xmm2
    7db2f9503676:	por    xmm2,xmm1
    7db2f950367a:	movdqu XMMWORD PTR [r12+0x200],xmm2
    7db2f9503684:	movdqu xmm2,XMMWORD PTR [r12+0x120]
    7db2f950368e:	movdqa xmm1,xmm2
    7db2f9503692:	por    xmm2,xmm1
    7db2f9503696:	movdqu XMMWORD PTR [r12+0x1e0],xmm2
    7db2f95036a0:	movdqu xmm2,XMMWORD PTR [r12+0x300]
    7db2f95036aa:	movdqa xmm1,xmm2
    7db2f95036ae:	por    xmm2,xmm1
    7db2f95036b2:	movdqu XMMWORD PTR [r12+0x2b0],xmm2
    7db2f95036bc:	movdqu xmm2,XMMWORD PTR [r12+0x2f0]
    7db2f95036c6:	movdqa xmm1,xmm2
    7db2f95036ca:	por    xmm2,xmm1
    7db2f95036ce:	movdqu XMMWORD PTR [r12+0x300],xmm2
    7db2f95036d8:	lea    r13,[r12]
    7db2f95036dc:	movabs r14,0x184fc712a0
    7db2f95036e6:	mov    r15d,0x4105d4
    7db2f95036ec:	movdqu xmm0,XMMWORD PTR [r12+0x260]
    7db2f95036f6:	movdqu xmm1,XMMWORD PTR [r12+0x180]
    7db2f9503700:	pshufd xmm1,xmm1,0x44
    7db2f9503705:	movdqu xmm14,XMMWORD PTR [r12+0x110]
    7db2f950370f:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f9503714:	movdqa xmm14,xmm0
    7db2f9503719:	movdqu xmm15,XMMWORD PTR [rip+0x334e]        # 0x7db2f9506a70
    7db2f9503722:	pand   xmm14,xmm15
    7db2f9503727:	movdqu xmm15,XMMWORD PTR [rip+0x3350]        # 0x7db2f9506a80
    7db2f9503730:	pcmpeqq xmm14,xmm15
    7db2f9503736:	movdqa xmm15,xmm0
    7db2f950373b:	cmpunordpd xmm15,xmm0
    7db2f9503741:	por    xmm14,xmm15
    7db2f9503746:	pmovmskb ecx,xmm14
    7db2f950374b:	jrcxz  0x7db2f9503752
    7db2f950374d:	jmp    0x7db2f95053d5
    7db2f9503752:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7db2f950375c:	mov    eax,0x0
    7db2f9503761:	mov    DWORD PTR [r12+0x324],0x0
    7db2f950376d:	mov    rbp,rax
    7db2f9503770:	lea    r13,[r12]
    7db2f9503774:	movabs r14,0x184fc71371
    7db2f950377e:	mov    r15d,0x4105d8
    7db2f9503784:	movdqu xmm0,XMMWORD PTR [r12+0x2c0]
    7db2f950378e:	movdqu xmm1,XMMWORD PTR [r12+0x180]
    7db2f9503798:	pshufd xmm1,xmm1,0x44
    7db2f950379d:	movdqu xmm14,XMMWORD PTR [r12+0x220]
    7db2f95037a7:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f95037ac:	movdqa xmm14,xmm0
    7db2f95037b1:	movdqu xmm15,XMMWORD PTR [rip+0x32b6]        # 0x7db2f9506a70
    7db2f95037ba:	pand   xmm14,xmm15
    7db2f95037bf:	movdqu xmm15,XMMWORD PTR [rip+0x32b8]        # 0x7db2f9506a80
    7db2f95037c8:	pcmpeqq xmm14,xmm15
    7db2f95037ce:	movdqa xmm15,xmm0
    7db2f95037d3:	cmpunordpd xmm15,xmm0
    7db2f95037d9:	por    xmm14,xmm15
    7db2f95037de:	pmovmskb ecx,xmm14
    7db2f95037e3:	jrcxz  0x7db2f95037ea
    7db2f95037e5:	jmp    0x7db2f950545b
    7db2f95037ea:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7db2f95037f4:	mov    eax,0x0
    7db2f95037f9:	mov    DWORD PTR [r12+0x324],0x0
    7db2f9503805:	mov    rbp,rax
    7db2f9503808:	lea    r13,[r12]
    7db2f950380c:	movabs r14,0x184fc712e6
    7db2f9503816:	mov    r15d,0x4105dc
    7db2f950381c:	movdqu xmm0,XMMWORD PTR [r12+0x280]
    7db2f9503826:	movdqu xmm1,XMMWORD PTR [r12+0x180]
    7db2f9503830:	pshufd xmm1,xmm1,0x44
    7db2f9503835:	movdqu xmm14,XMMWORD PTR [r12+0x170]
    7db2f950383f:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f9503844:	movdqa xmm14,xmm0
    7db2f9503849:	movdqu xmm15,XMMWORD PTR [rip+0x321e]        # 0x7db2f9506a70
    7db2f9503852:	pand   xmm14,xmm15
    7db2f9503857:	movdqu xmm15,XMMWORD PTR [rip+0x3220]        # 0x7db2f9506a80
    7db2f9503860:	pcmpeqq xmm14,xmm15
    7db2f9503866:	movdqa xmm15,xmm0
    7db2f950386b:	cmpunordpd xmm15,xmm0
    7db2f9503871:	por    xmm14,xmm15
    7db2f9503876:	pmovmskb ecx,xmm14
    7db2f950387b:	jrcxz  0x7db2f9503882
    7db2f950387d:	jmp    0x7db2f95054e1
    7db2f9503882:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7db2f950388c:	mov    eax,0x0
    7db2f9503891:	mov    DWORD PTR [r12+0x324],0x0
    7db2f950389d:	mov    rbp,rax
    7db2f95038a0:	lea    r13,[r12]
    7db2f95038a4:	movabs r14,0x184fc71192
    7db2f95038ae:	mov    r15d,0x4105e0
    7db2f95038b4:	movdqu xmm0,XMMWORD PTR [r12+0x1d0]
    7db2f95038be:	movdqu xmm1,XMMWORD PTR [r12+0x180]
    7db2f95038c8:	pshufd xmm1,xmm1,0x44
    7db2f95038cd:	movdqu xmm14,XMMWORD PTR [r12+0x230]
    7db2f95038d7:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f95038dc:	movdqa xmm14,xmm0
    7db2f95038e1:	movdqu xmm15,XMMWORD PTR [rip+0x3186]        # 0x7db2f9506a70
    7db2f95038ea:	pand   xmm14,xmm15
    7db2f95038ef:	movdqu xmm15,XMMWORD PTR [rip+0x3188]        # 0x7db2f9506a80
    7db2f95038f8:	pcmpeqq xmm14,xmm15
    7db2f95038fe:	movdqa xmm15,xmm0
    7db2f9503903:	cmpunordpd xmm15,xmm0
    7db2f9503909:	por    xmm14,xmm15
    7db2f950390e:	pmovmskb ecx,xmm14
    7db2f9503913:	jrcxz  0x7db2f950391a
    7db2f9503915:	jmp    0x7db2f9505567
    7db2f950391a:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7db2f9503924:	mov    eax,0x0
    7db2f9503929:	mov    DWORD PTR [r12+0x324],0x0
    7db2f9503935:	mov    rbp,rax
    7db2f9503938:	movdqu xmm2,XMMWORD PTR [r12+0x2d0]
    7db2f9503942:	movdqa xmm1,xmm2
    7db2f9503946:	por    xmm2,xmm1
    7db2f950394a:	movdqu XMMWORD PTR [r12+0x180],xmm2
    7db2f9503954:	movdqu xmm2,XMMWORD PTR [r12+0x1a0]
    7db2f950395e:	movdqa xmm1,xmm2
    7db2f9503962:	por    xmm2,xmm1
    7db2f9503966:	movdqu XMMWORD PTR [r12+0x2d0],xmm2
    7db2f9503970:	lea    r13,[r12]
    7db2f9503974:	movabs r14,0x184fc513d1
    7db2f950397e:	mov    r15d,0x4105ec
    7db2f9503984:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    7db2f950398e:	movdqu xmm1,XMMWORD PTR [r12+0x160]
    7db2f9503998:	pshufd xmm1,xmm1,0x44
    7db2f950399d:	movdqu xmm14,XMMWORD PTR [r12+0x220]
    7db2f95039a7:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f95039ac:	movdqa xmm14,xmm0
    7db2f95039b1:	movdqu xmm15,XMMWORD PTR [rip+0x30b6]        # 0x7db2f9506a70
    7db2f95039ba:	pand   xmm14,xmm15
    7db2f95039bf:	movdqu xmm15,XMMWORD PTR [rip+0x30b8]        # 0x7db2f9506a80
    7db2f95039c8:	pcmpeqq xmm14,xmm15
    7db2f95039ce:	movdqa xmm15,xmm0
    7db2f95039d3:	cmpunordpd xmm15,xmm0
    7db2f95039d9:	por    xmm14,xmm15
    7db2f95039de:	pmovmskb ecx,xmm14
    7db2f95039e3:	jrcxz  0x7db2f95039ea
    7db2f95039e5:	jmp    0x7db2f95055ed
    7db2f95039ea:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7db2f95039f4:	mov    eax,0x0
    7db2f95039f9:	mov    DWORD PTR [r12+0x324],0x0
    7db2f9503a05:	mov    rbp,rax
    7db2f9503a08:	lea    r13,[r12]
    7db2f9503a0c:	movabs r14,0x184fc510e0
    7db2f9503a16:	mov    r15d,0x4105f0
    7db2f9503a1c:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    7db2f9503a26:	movdqu xmm1,XMMWORD PTR [r12+0x160]
    7db2f9503a30:	pshufd xmm1,xmm1,0x44
    7db2f9503a35:	movdqu xmm14,XMMWORD PTR [r12+0x110]
    7db2f9503a3f:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f9503a44:	movdqa xmm14,xmm0
    7db2f9503a49:	movdqu xmm15,XMMWORD PTR [rip+0x301e]        # 0x7db2f9506a70
    7db2f9503a52:	pand   xmm14,xmm15
    7db2f9503a57:	movdqu xmm15,XMMWORD PTR [rip+0x3020]        # 0x7db2f9506a80
    7db2f9503a60:	pcmpeqq xmm14,xmm15
    7db2f9503a66:	movdqa xmm15,xmm0
    7db2f9503a6b:	cmpunordpd xmm15,xmm0
    7db2f9503a71:	por    xmm14,xmm15
    7db2f9503a76:	pmovmskb ecx,xmm14
    7db2f9503a7b:	jrcxz  0x7db2f9503a82
    7db2f9503a7d:	jmp    0x7db2f9505673
    7db2f9503a82:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7db2f9503a8c:	mov    eax,0x0
    7db2f9503a91:	mov    DWORD PTR [r12+0x324],0x0
    7db2f9503a9d:	mov    rbp,rax
    7db2f9503aa0:	mov    r13,QWORD PTR [r12+0xf8]
    7db2f9503aa8:	add    r13,0x80
    7db2f9503aaf:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7db2f9503ab5:	movdqu XMMWORD PTR [r12+0x2f0],xmm2
    7db2f9503abf:	lea    r13,[r12]
    7db2f9503ac3:	movabs r14,0x184fc51306
    7db2f9503acd:	mov    r15d,0x4105f8
    7db2f9503ad3:	movdqu xmm0,XMMWORD PTR [r12+0x290]
    7db2f9503add:	movdqu xmm1,XMMWORD PTR [r12+0x160]
    7db2f9503ae7:	pshufd xmm1,xmm1,0x44
    7db2f9503aec:	movdqu xmm14,XMMWORD PTR [r12+0x170]
    7db2f9503af6:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f9503afb:	movdqa xmm14,xmm0
    7db2f9503b00:	movdqu xmm15,XMMWORD PTR [rip+0x2f67]        # 0x7db2f9506a70
    7db2f9503b09:	pand   xmm14,xmm15
    7db2f9503b0e:	movdqu xmm15,XMMWORD PTR [rip+0x2f69]        # 0x7db2f9506a80
    7db2f9503b17:	pcmpeqq xmm14,xmm15
    7db2f9503b1d:	movdqa xmm15,xmm0
    7db2f9503b22:	cmpunordpd xmm15,xmm0
    7db2f9503b28:	por    xmm14,xmm15
    7db2f9503b2d:	pmovmskb ecx,xmm14
    7db2f9503b32:	jrcxz  0x7db2f9503b39
    7db2f9503b34:	jmp    0x7db2f95056f9
    7db2f9503b39:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7db2f9503b43:	mov    eax,0x0
    7db2f9503b48:	mov    DWORD PTR [r12+0x324],0x0
    7db2f9503b54:	mov    rbp,rax
    7db2f9503b57:	lea    r13,[r12]
    7db2f9503b5b:	movabs r14,0x184fc51132
    7db2f9503b65:	mov    r15d,0x4105fc
    7db2f9503b6b:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    7db2f9503b75:	movdqu xmm1,XMMWORD PTR [r12+0x160]
    7db2f9503b7f:	pshufd xmm1,xmm1,0x44
    7db2f9503b84:	movdqu xmm14,XMMWORD PTR [r12+0x230]
    7db2f9503b8e:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f9503b93:	movdqa xmm14,xmm0
    7db2f9503b98:	movdqu xmm15,XMMWORD PTR [rip+0x2ecf]        # 0x7db2f9506a70
    7db2f9503ba1:	pand   xmm14,xmm15
    7db2f9503ba6:	movdqu xmm15,XMMWORD PTR [rip+0x2ed1]        # 0x7db2f9506a80
    7db2f9503baf:	pcmpeqq xmm14,xmm15
    7db2f9503bb5:	movdqa xmm15,xmm0
    7db2f9503bba:	cmpunordpd xmm15,xmm0
    7db2f9503bc0:	por    xmm14,xmm15
    7db2f9503bc5:	pmovmskb ecx,xmm14
    7db2f9503bca:	jrcxz  0x7db2f9503bd1
    7db2f9503bcc:	jmp    0x7db2f950577f
    7db2f9503bd1:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7db2f9503bdb:	mov    eax,0x0
    7db2f9503be0:	mov    DWORD PTR [r12+0x324],0x0
    7db2f9503bec:	mov    rbp,rax
    7db2f9503bef:	movdqu xmm2,XMMWORD PTR [r12+0x1b0]
    7db2f9503bf9:	movdqa xmm1,xmm2
    7db2f9503bfd:	por    xmm2,xmm1
    7db2f9503c01:	movdqu XMMWORD PTR [r12+0x160],xmm2
    7db2f9503c0b:	mov    r13,QWORD PTR [r12+0xf8]
    7db2f9503c13:	add    r13,0x40
    7db2f9503c17:	mov    r14,r13
    7db2f9503c1a:	add    r14,0x10
    7db2f9503c1e:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7db2f9503c24:	movdqu xmm3,XMMWORD PTR [r14]
    7db2f9503c29:	movdqu XMMWORD PTR [r12+0x1b0],xmm2
    7db2f9503c33:	movdqu XMMWORD PTR [r12+0x1a0],xmm3
    7db2f9503c3d:	lea    r13,[r12]
    7db2f9503c41:	movabs r14,0x184fc41111
    7db2f9503c4b:	mov    r15d,0x410608
    7db2f9503c51:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    7db2f9503c5b:	movdqu xmm1,XMMWORD PTR [r12+0x150]
    7db2f9503c65:	pshufd xmm1,xmm1,0x44
    7db2f9503c6a:	movdqu xmm14,XMMWORD PTR [r12+0x220]
    7db2f9503c74:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f9503c79:	movdqa xmm14,xmm0
    7db2f9503c7e:	movdqu xmm15,XMMWORD PTR [rip+0x2de9]        # 0x7db2f9506a70
    7db2f9503c87:	pand   xmm14,xmm15
    7db2f9503c8c:	movdqu xmm15,XMMWORD PTR [rip+0x2deb]        # 0x7db2f9506a80
    7db2f9503c95:	pcmpeqq xmm14,xmm15
    7db2f9503c9b:	movdqa xmm15,xmm0
    7db2f9503ca0:	cmpunordpd xmm15,xmm0
    7db2f9503ca6:	por    xmm14,xmm15
    7db2f9503cab:	pmovmskb ecx,xmm14
    7db2f9503cb0:	jrcxz  0x7db2f9503cb7
    7db2f9503cb2:	jmp    0x7db2f9505805
    7db2f9503cb7:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7db2f9503cc1:	mov    eax,0x0
    7db2f9503cc6:	mov    DWORD PTR [r12+0x324],0x0
    7db2f9503cd2:	mov    rbp,rax
    7db2f9503cd5:	lea    r13,[r12]
    7db2f9503cd9:	movabs r14,0x184fc410a0
    7db2f9503ce3:	mov    r15d,0x41060c
    7db2f9503ce9:	movdqu xmm0,XMMWORD PTR [r12+0x160]
    7db2f9503cf3:	movdqu xmm1,XMMWORD PTR [r12+0x150]
    7db2f9503cfd:	pshufd xmm1,xmm1,0x44
    7db2f9503d02:	movdqu xmm14,XMMWORD PTR [r12+0x110]
    7db2f9503d0c:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f9503d11:	movdqa xmm14,xmm0
    7db2f9503d16:	movdqu xmm15,XMMWORD PTR [rip+0x2d51]        # 0x7db2f9506a70
    7db2f9503d1f:	pand   xmm14,xmm15
    7db2f9503d24:	movdqu xmm15,XMMWORD PTR [rip+0x2d53]        # 0x7db2f9506a80
    7db2f9503d2d:	pcmpeqq xmm14,xmm15
    7db2f9503d33:	movdqa xmm15,xmm0
    7db2f9503d38:	cmpunordpd xmm15,xmm0
    7db2f9503d3e:	por    xmm14,xmm15
    7db2f9503d43:	pmovmskb ecx,xmm14
    7db2f9503d48:	jrcxz  0x7db2f9503d4f
    7db2f9503d4a:	jmp    0x7db2f950588b
    7db2f9503d4f:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7db2f9503d59:	mov    eax,0x0
    7db2f9503d5e:	mov    DWORD PTR [r12+0x324],0x0
    7db2f9503d6a:	mov    rbp,rax
    7db2f9503d6d:	lea    r13,[r12]
    7db2f9503d71:	movabs r14,0x184fc41326
    7db2f9503d7b:	mov    r15d,0x410610
    7db2f9503d81:	movdqu xmm0,XMMWORD PTR [r12+0x2a0]
    7db2f9503d8b:	movdqu xmm1,XMMWORD PTR [r12+0x150]
    7db2f9503d95:	pshufd xmm1,xmm1,0x44
    7db2f9503d9a:	movdqu xmm14,XMMWORD PTR [r12+0x170]
    7db2f9503da4:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f9503da9:	movdqa xmm14,xmm0
    7db2f9503dae:	movdqu xmm15,XMMWORD PTR [rip+0x2cb9]        # 0x7db2f9506a70
    7db2f9503db7:	pand   xmm14,xmm15
    7db2f9503dbc:	movdqu xmm15,XMMWORD PTR [rip+0x2cbb]        # 0x7db2f9506a80
    7db2f9503dc5:	pcmpeqq xmm14,xmm15
    7db2f9503dcb:	movdqa xmm15,xmm0
    7db2f9503dd0:	cmpunordpd xmm15,xmm0
    7db2f9503dd6:	por    xmm14,xmm15
    7db2f9503ddb:	pmovmskb ecx,xmm14
    7db2f9503de0:	jrcxz  0x7db2f9503de7
    7db2f9503de2:	jmp    0x7db2f9505911
    7db2f9503de7:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7db2f9503df1:	mov    eax,0x0
    7db2f9503df6:	mov    DWORD PTR [r12+0x324],0x0
    7db2f9503e02:	mov    rbp,rax
    7db2f9503e05:	lea    r13,[r12]
    7db2f9503e09:	movabs r14,0x184fc41032
    7db2f9503e13:	mov    r15d,0x410614
    7db2f9503e19:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7db2f9503e23:	movdqu xmm1,XMMWORD PTR [r12+0x150]
    7db2f9503e2d:	pshufd xmm1,xmm1,0x44
    7db2f9503e32:	movdqu xmm14,XMMWORD PTR [r12+0x230]
    7db2f9503e3c:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f9503e41:	movdqa xmm14,xmm0
    7db2f9503e46:	movdqu xmm15,XMMWORD PTR [rip+0x2c21]        # 0x7db2f9506a70
    7db2f9503e4f:	pand   xmm14,xmm15
    7db2f9503e54:	movdqu xmm15,XMMWORD PTR [rip+0x2c23]        # 0x7db2f9506a80
    7db2f9503e5d:	pcmpeqq xmm14,xmm15
    7db2f9503e63:	movdqa xmm15,xmm0
    7db2f9503e68:	cmpunordpd xmm15,xmm0
    7db2f9503e6e:	por    xmm14,xmm15
    7db2f9503e73:	pmovmskb ecx,xmm14
    7db2f9503e78:	jrcxz  0x7db2f9503e7f
    7db2f9503e7a:	jmp    0x7db2f9505997
    7db2f9503e7f:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7db2f9503e89:	mov    eax,0x0
    7db2f9503e8e:	mov    DWORD PTR [r12+0x324],0x0
    7db2f9503e9a:	mov    rbp,rax
    7db2f9503e9d:	mov    r13,QWORD PTR [r12+0xf8]
    7db2f9503ea5:	add    r13,0x60
    7db2f9503ea9:	mov    r14,r13
    7db2f9503eac:	add    r14,0x10
    7db2f9503eb0:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7db2f9503eb6:	movdqu xmm3,XMMWORD PTR [r14]
    7db2f9503ebb:	movdqu XMMWORD PTR [r12+0x150],xmm2
    7db2f9503ec5:	movdqu XMMWORD PTR [r12+0x120],xmm3
    7db2f9503ecf:	lea    r13,[r12]
    7db2f9503ed3:	movabs r14,0x184fc31131
    7db2f9503edd:	mov    r15d,0x41061c
    7db2f9503ee3:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    7db2f9503eed:	movdqu xmm1,XMMWORD PTR [r12+0x140]
    7db2f9503ef7:	pshufd xmm1,xmm1,0x44
    7db2f9503efc:	movdqu xmm14,XMMWORD PTR [r12+0x220]
    7db2f9503f06:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f9503f0b:	movdqa xmm14,xmm0
    7db2f9503f10:	movdqu xmm15,XMMWORD PTR [rip+0x2b57]        # 0x7db2f9506a70
    7db2f9503f19:	pand   xmm14,xmm15
    7db2f9503f1e:	movdqu xmm15,XMMWORD PTR [rip+0x2b59]        # 0x7db2f9506a80
    7db2f9503f27:	pcmpeqq xmm14,xmm15
    7db2f9503f2d:	movdqa xmm15,xmm0
    7db2f9503f32:	cmpunordpd xmm15,xmm0
    7db2f9503f38:	por    xmm14,xmm15
    7db2f9503f3d:	pmovmskb ecx,xmm14
    7db2f9503f42:	jrcxz  0x7db2f9503f49
    7db2f9503f44:	jmp    0x7db2f9505a1d
    7db2f9503f49:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7db2f9503f53:	mov    eax,0x0
    7db2f9503f58:	mov    DWORD PTR [r12+0x324],0x0
    7db2f9503f64:	mov    rbp,rax
    7db2f9503f67:	lea    r13,[r12]
    7db2f9503f6b:	movabs r14,0x184fc31080
    7db2f9503f75:	mov    r15d,0x410620
    7db2f9503f7b:	movdqu xmm0,XMMWORD PTR [r12+0x150]
    7db2f9503f85:	movdqu xmm1,XMMWORD PTR [r12+0x140]
    7db2f9503f8f:	pshufd xmm1,xmm1,0x44
    7db2f9503f94:	movdqu xmm14,XMMWORD PTR [r12+0x110]
    7db2f9503f9e:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f9503fa3:	movdqa xmm14,xmm0
    7db2f9503fa8:	movdqu xmm15,XMMWORD PTR [rip+0x2abf]        # 0x7db2f9506a70
    7db2f9503fb1:	pand   xmm14,xmm15
    7db2f9503fb6:	movdqu xmm15,XMMWORD PTR [rip+0x2ac1]        # 0x7db2f9506a80
    7db2f9503fbf:	pcmpeqq xmm14,xmm15
    7db2f9503fc5:	movdqa xmm15,xmm0
    7db2f9503fca:	cmpunordpd xmm15,xmm0
    7db2f9503fd0:	por    xmm14,xmm15
    7db2f9503fd5:	pmovmskb ecx,xmm14
    7db2f9503fda:	jrcxz  0x7db2f9503fe1
    7db2f9503fdc:	jmp    0x7db2f9505aa3
    7db2f9503fe1:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7db2f9503feb:	mov    eax,0x0
    7db2f9503ff0:	mov    DWORD PTR [r12+0x324],0x0
    7db2f9503ffc:	mov    rbp,rax
    7db2f9503fff:	lea    r13,[r12]
    7db2f9504003:	movabs r14,0x184fc31346
    7db2f950400d:	mov    r15d,0x410624
    7db2f9504013:	movdqu xmm0,XMMWORD PTR [r12+0x2b0]
    7db2f950401d:	movdqu xmm1,XMMWORD PTR [r12+0x140]
    7db2f9504027:	pshufd xmm1,xmm1,0x44
    7db2f950402c:	movdqu xmm14,XMMWORD PTR [r12+0x170]
    7db2f9504036:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f950403b:	movdqa xmm14,xmm0
    7db2f9504040:	movdqu xmm15,XMMWORD PTR [rip+0x2a27]        # 0x7db2f9506a70
    7db2f9504049:	pand   xmm14,xmm15
    7db2f950404e:	movdqu xmm15,XMMWORD PTR [rip+0x2a29]        # 0x7db2f9506a80
    7db2f9504057:	pcmpeqq xmm14,xmm15
    7db2f950405d:	movdqa xmm15,xmm0
    7db2f9504062:	cmpunordpd xmm15,xmm0
    7db2f9504068:	por    xmm14,xmm15
    7db2f950406d:	pmovmskb ecx,xmm14
    7db2f9504072:	jrcxz  0x7db2f9504079
    7db2f9504074:	jmp    0x7db2f9505b29
    7db2f9504079:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7db2f9504083:	mov    eax,0x0
    7db2f9504088:	mov    DWORD PTR [r12+0x324],0x0
    7db2f9504094:	mov    rbp,rax
    7db2f9504097:	lea    r13,[r12]
    7db2f950409b:	movabs r14,0x184fc31152
    7db2f95040a5:	mov    r15d,0x410628
    7db2f95040ab:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    7db2f95040b5:	movdqu xmm1,XMMWORD PTR [r12+0x140]
    7db2f95040bf:	pshufd xmm1,xmm1,0x44
    7db2f95040c4:	movdqu xmm14,XMMWORD PTR [r12+0x230]
    7db2f95040ce:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f95040d3:	movdqa xmm14,xmm0
    7db2f95040d8:	movdqu xmm15,XMMWORD PTR [rip+0x298f]        # 0x7db2f9506a70
    7db2f95040e1:	pand   xmm14,xmm15
    7db2f95040e6:	movdqu xmm15,XMMWORD PTR [rip+0x2991]        # 0x7db2f9506a80
    7db2f95040ef:	pcmpeqq xmm14,xmm15
    7db2f95040f5:	movdqa xmm15,xmm0
    7db2f95040fa:	cmpunordpd xmm15,xmm0
    7db2f9504100:	por    xmm14,xmm15
    7db2f9504105:	pmovmskb ecx,xmm14
    7db2f950410a:	jrcxz  0x7db2f9504111
    7db2f950410c:	jmp    0x7db2f9505baf
    7db2f9504111:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7db2f950411b:	mov    eax,0x0
    7db2f9504120:	mov    DWORD PTR [r12+0x324],0x0
    7db2f950412c:	mov    rbp,rax
    7db2f950412f:	mov    r13,QWORD PTR [r12+0xf8]
    7db2f9504137:	add    r13,0x20
    7db2f950413b:	mov    r14,r13
    7db2f950413e:	add    r14,0x10
    7db2f9504142:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7db2f9504148:	movdqu xmm3,XMMWORD PTR [r14]
    7db2f950414d:	movdqu XMMWORD PTR [r12+0x240],xmm2
    7db2f9504157:	movdqu XMMWORD PTR [r12+0x140],xmm3
    7db2f9504161:	lea    r13,[r12]
    7db2f9504165:	movabs r14,0x184fc211f1
    7db2f950416f:	mov    r15d,0x410630
    7db2f9504175:	movdqu xmm0,XMMWORD PTR [r12+0x200]
    7db2f950417f:	movdqu xmm1,XMMWORD PTR [r12+0x130]
    7db2f9504189:	pshufd xmm1,xmm1,0x44
    7db2f950418e:	movdqu xmm14,XMMWORD PTR [r12+0x220]
    7db2f9504198:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f950419d:	movdqa xmm14,xmm0
    7db2f95041a2:	movdqu xmm15,XMMWORD PTR [rip+0x28c5]        # 0x7db2f9506a70
    7db2f95041ab:	pand   xmm14,xmm15
    7db2f95041b0:	movdqu xmm15,XMMWORD PTR [rip+0x28c7]        # 0x7db2f9506a80
    7db2f95041b9:	pcmpeqq xmm14,xmm15
    7db2f95041bf:	movdqa xmm15,xmm0
    7db2f95041c4:	cmpunordpd xmm15,xmm0
    7db2f95041ca:	por    xmm14,xmm15
    7db2f95041cf:	pmovmskb ecx,xmm14
    7db2f95041d4:	jrcxz  0x7db2f95041db
    7db2f95041d6:	jmp    0x7db2f9505c35
    7db2f95041db:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7db2f95041e5:	mov    eax,0x0
    7db2f95041ea:	mov    DWORD PTR [r12+0x324],0x0
    7db2f95041f6:	mov    rbp,rax
    7db2f95041f9:	lea    r13,[r12]
    7db2f95041fd:	movabs r14,0x184fc213c0
    7db2f9504207:	mov    r15d,0x410634
    7db2f950420d:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    7db2f9504217:	movdqu xmm1,XMMWORD PTR [r12+0x130]
    7db2f9504221:	pshufd xmm1,xmm1,0x44
    7db2f9504226:	movdqu xmm14,XMMWORD PTR [r12+0x110]
    7db2f9504230:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f9504235:	movdqa xmm14,xmm0
    7db2f950423a:	movdqu xmm15,XMMWORD PTR [rip+0x282d]        # 0x7db2f9506a70
    7db2f9504243:	pand   xmm14,xmm15
    7db2f9504248:	movdqu xmm15,XMMWORD PTR [rip+0x282f]        # 0x7db2f9506a80
    7db2f9504251:	pcmpeqq xmm14,xmm15
    7db2f9504257:	movdqa xmm15,xmm0
    7db2f950425c:	cmpunordpd xmm15,xmm0
    7db2f9504262:	por    xmm14,xmm15
    7db2f9504267:	pmovmskb ecx,xmm14
    7db2f950426c:	jrcxz  0x7db2f9504273
    7db2f950426e:	jmp    0x7db2f9505cbb
    7db2f9504273:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7db2f950427d:	mov    eax,0x0
    7db2f9504282:	mov    DWORD PTR [r12+0x324],0x0
    7db2f950428e:	mov    rbp,rax
    7db2f9504291:	lea    r13,[r12]
    7db2f9504295:	movabs r14,0x184fc21026
    7db2f950429f:	mov    r15d,0x410638
    7db2f95042a5:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7db2f95042af:	movdqu xmm1,XMMWORD PTR [r12+0x130]
    7db2f95042b9:	pshufd xmm1,xmm1,0x44
    7db2f95042be:	movdqu xmm14,XMMWORD PTR [r12+0x170]
    7db2f95042c8:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f95042cd:	movdqa xmm14,xmm0
    7db2f95042d2:	movdqu xmm15,XMMWORD PTR [rip+0x2795]        # 0x7db2f9506a70
    7db2f95042db:	pand   xmm14,xmm15
    7db2f95042e0:	movdqu xmm15,XMMWORD PTR [rip+0x2797]        # 0x7db2f9506a80
    7db2f95042e9:	pcmpeqq xmm14,xmm15
    7db2f95042ef:	movdqa xmm15,xmm0
    7db2f95042f4:	cmpunordpd xmm15,xmm0
    7db2f95042fa:	por    xmm14,xmm15
    7db2f95042ff:	pmovmskb ecx,xmm14
    7db2f9504304:	jrcxz  0x7db2f950430b
    7db2f9504306:	jmp    0x7db2f9505d41
    7db2f950430b:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7db2f9504315:	mov    eax,0x0
    7db2f950431a:	mov    DWORD PTR [r12+0x324],0x0
    7db2f9504326:	mov    rbp,rax
    7db2f9504329:	lea    r13,[r12]
    7db2f950432d:	movabs r14,0x184fc21072
    7db2f9504337:	mov    r15d,0x41063c
    7db2f950433d:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7db2f9504347:	movdqu xmm1,XMMWORD PTR [r12+0x130]
    7db2f9504351:	pshufd xmm1,xmm1,0x44
    7db2f9504356:	movdqu xmm14,XMMWORD PTR [r12+0x230]
    7db2f9504360:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f9504365:	movdqa xmm14,xmm0
    7db2f950436a:	movdqu xmm15,XMMWORD PTR [rip+0x26fd]        # 0x7db2f9506a70
    7db2f9504373:	pand   xmm14,xmm15
    7db2f9504378:	movdqu xmm15,XMMWORD PTR [rip+0x26ff]        # 0x7db2f9506a80
    7db2f9504381:	pcmpeqq xmm14,xmm15
    7db2f9504387:	movdqa xmm15,xmm0
    7db2f950438c:	cmpunordpd xmm15,xmm0
    7db2f9504392:	por    xmm14,xmm15
    7db2f9504397:	pmovmskb ecx,xmm14
    7db2f950439c:	jrcxz  0x7db2f95043a3
    7db2f950439e:	jmp    0x7db2f9505dc7
    7db2f95043a3:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7db2f95043ad:	mov    eax,0x0
    7db2f95043b2:	mov    DWORD PTR [r12+0x324],0x0
    7db2f95043be:	mov    rbp,rax
    7db2f95043c1:	mov    r13,QWORD PTR [r12+0xf8]
    7db2f95043c9:	add    r13,0x90
    7db2f95043d0:	mov    r14,r13
    7db2f95043d3:	add    r14,0x10
    7db2f95043d7:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7db2f95043dd:	movdqu xmm3,XMMWORD PTR [r14]
    7db2f95043e2:	movdqu XMMWORD PTR [r12+0x140],xmm2
    7db2f95043ec:	movdqu XMMWORD PTR [r12+0x130],xmm3
    7db2f95043f6:	lea    r13,[r12]
    7db2f95043fa:	movabs r14,0x184fd61271
    7db2f9504404:	mov    r15d,0x410644
    7db2f950440a:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7db2f9504414:	movdqu xmm1,XMMWORD PTR [r12+0x270]
    7db2f950441e:	pshufd xmm1,xmm1,0x44
    7db2f9504423:	movdqu xmm14,XMMWORD PTR [r12+0x220]
    7db2f950442d:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f9504432:	movdqa xmm14,xmm0
    7db2f9504437:	movdqu xmm15,XMMWORD PTR [rip+0x2630]        # 0x7db2f9506a70
    7db2f9504440:	pand   xmm14,xmm15
    7db2f9504445:	movdqu xmm15,XMMWORD PTR [rip+0x2632]        # 0x7db2f9506a80
    7db2f950444e:	pcmpeqq xmm14,xmm15
    7db2f9504454:	movdqa xmm15,xmm0
    7db2f9504459:	cmpunordpd xmm15,xmm0
    7db2f950445f:	por    xmm14,xmm15
    7db2f9504464:	pmovmskb ecx,xmm14
    7db2f9504469:	jrcxz  0x7db2f9504470
    7db2f950446b:	jmp    0x7db2f9505e4d
    7db2f9504470:	movdqu XMMWORD PTR [r12+0x220],xmm0
    7db2f950447a:	mov    eax,0x0
    7db2f950447f:	mov    DWORD PTR [r12+0x324],0x0
    7db2f950448b:	mov    rbp,rax
    7db2f950448e:	mov    r13,QWORD PTR [r12+0xf8]
    7db2f9504496:	add    r13,0x10
    7db2f950449a:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    7db2f95044a0:	movdqu XMMWORD PTR [r12+0x240],xmm2
    7db2f95044aa:	lea    r13,[r12]
    7db2f95044ae:	movabs r14,0x184fd61040
    7db2f95044b8:	mov    r15d,0x41064c
    7db2f95044be:	movdqu xmm0,XMMWORD PTR [r12+0x130]
    7db2f95044c8:	movdqu xmm1,XMMWORD PTR [r12+0x270]
    7db2f95044d2:	pshufd xmm1,xmm1,0x44
    7db2f95044d7:	movdqu xmm14,XMMWORD PTR [r12+0x110]
    7db2f95044e1:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f95044e6:	movdqa xmm14,xmm0
    7db2f95044eb:	movdqu xmm15,XMMWORD PTR [rip+0x257c]        # 0x7db2f9506a70
    7db2f95044f4:	pand   xmm14,xmm15
    7db2f95044f9:	movdqu xmm15,XMMWORD PTR [rip+0x257e]        # 0x7db2f9506a80
    7db2f9504502:	pcmpeqq xmm14,xmm15
    7db2f9504508:	movdqa xmm15,xmm0
    7db2f950450d:	cmpunordpd xmm15,xmm0
    7db2f9504513:	por    xmm14,xmm15
    7db2f9504518:	pmovmskb ecx,xmm14
    7db2f950451d:	jrcxz  0x7db2f9504524
    7db2f950451f:	jmp    0x7db2f9505ed3
    7db2f9504524:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7db2f950452e:	mov    eax,0x0
    7db2f9504533:	mov    DWORD PTR [r12+0x324],0x0
    7db2f950453f:	mov    rbp,rax
    7db2f9504542:	lea    r13,[r12]
    7db2f9504546:	movabs r14,0x184fd61066
    7db2f9504550:	mov    r15d,0x410650
    7db2f9504556:	movdqu xmm0,XMMWORD PTR [r12+0x140]
    7db2f9504560:	movdqu xmm1,XMMWORD PTR [r12+0x270]
    7db2f950456a:	pshufd xmm1,xmm1,0x44
    7db2f950456f:	movdqu xmm14,XMMWORD PTR [r12+0x170]
    7db2f9504579:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f950457e:	movdqa xmm14,xmm0
    7db2f9504583:	movdqu xmm15,XMMWORD PTR [rip+0x24e4]        # 0x7db2f9506a70
    7db2f950458c:	pand   xmm14,xmm15
    7db2f9504591:	movdqu xmm15,XMMWORD PTR [rip+0x24e6]        # 0x7db2f9506a80
    7db2f950459a:	pcmpeqq xmm14,xmm15
    7db2f95045a0:	movdqa xmm15,xmm0
    7db2f95045a5:	cmpunordpd xmm15,xmm0
    7db2f95045ab:	por    xmm14,xmm15
    7db2f95045b0:	pmovmskb ecx,xmm14
    7db2f95045b5:	jrcxz  0x7db2f95045bc
    7db2f95045b7:	jmp    0x7db2f9505f59
    7db2f95045bc:	movdqu XMMWORD PTR [r12+0x170],xmm0
    7db2f95045c6:	mov    eax,0x0
    7db2f95045cb:	mov    DWORD PTR [r12+0x324],0x0
    7db2f95045d7:	mov    rbp,rax
    7db2f95045da:	lea    r13,[r12]
    7db2f95045de:	movabs r14,0x184fd61272
    7db2f95045e8:	mov    r15d,0x410654
    7db2f95045ee:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    7db2f95045f8:	movdqu xmm1,XMMWORD PTR [r12+0x270]
    7db2f9504602:	pshufd xmm1,xmm1,0x44
    7db2f9504607:	movdqu xmm14,XMMWORD PTR [r12+0x230]
    7db2f9504611:	vfmadd213pd xmm0,xmm1,xmm14
    7db2f9504616:	movdqa xmm14,xmm0
    7db2f950461b:	movdqu xmm15,XMMWORD PTR [rip+0x244c]        # 0x7db2f9506a70
    7db2f9504624:	pand   xmm14,xmm15
    7db2f9504629:	movdqu xmm15,XMMWORD PTR [rip+0x244e]        # 0x7db2f9506a80
    7db2f9504632:	pcmpeqq xmm14,xmm15
    7db2f9504638:	movdqa xmm15,xmm0
    7db2f950463d:	cmpunordpd xmm15,xmm0
    7db2f9504643:	por    xmm14,xmm15
    7db2f9504648:	pmovmskb ecx,xmm14
    7db2f950464d:	jrcxz  0x7db2f9504654
    7db2f950464f:	jmp    0x7db2f9505fdf
    7db2f9504654:	movdqu XMMWORD PTR [r12+0x230],xmm0
    7db2f950465e:	mov    eax,0x0
    7db2f9504663:	mov    DWORD PTR [r12+0x324],0x0
    7db2f950466f:	mov    rbp,rax
    7db2f9504672:	mov    r13,QWORD PTR [r12+0x60]
    7db2f9504677:	mov    r14,r13
    7db2f950467a:	add    r14,0x10
    7db2f950467e:	movdqu xmm2,XMMWORD PTR [r12+0x110]
    7db2f9504688:	movdqu xmm3,XMMWORD PTR [r12+0x170]
    7db2f9504692:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7db2f9504698:	mov    r15d,0x0
    7db2f950469e:	mov    DWORD PTR [r12+0x32c],r15d
    7db2f95046a6:	movdqu XMMWORD PTR [r14],xmm3
    7db2f95046ab:	add    r13,0x20
    7db2f95046af:	mov    r14,r13
    7db2f95046b2:	add    r14,0x10
    7db2f95046b6:	movdqu xmm2,XMMWORD PTR [r12+0x220]
    7db2f95046c0:	movdqu xmm3,XMMWORD PTR [r12+0x230]
    7db2f95046ca:	movdqu XMMWORD PTR [r13+0x0],xmm2
    7db2f95046d0:	movdqu XMMWORD PTR [r14],xmm3
    7db2f95046d5:	mov    rcx,QWORD PTR [r12+0x380]
    7db2f95046dd:	jrcxz  0x7db2f95046e4
    7db2f95046df:	jmp    0x7db2f950618d
    7db2f95046e4:	mov    rdx,rbx
    7db2f95046e7:	shr    rdx,0x10
    7db2f95046eb:	and    edx,0xc000
    7db2f95046f1:	mov    rax,rbx
    7db2f95046f4:	shr    rax,0x15
    7db2f95046f8:	and    eax,0x100
    7db2f95046fd:	xor    eax,0x100
    7db2f9504702:	or     edx,eax
    7db2f9504704:	mov    rax,rbx
    7db2f9504707:	shr    rax,0x1c
    7db2f950470b:	and    eax,0x1
    7db2f950470e:	or     edx,eax
    7db2f9504710:	mov    QWORD PTR [rsp],rdx
    7db2f9504714:	mov    rax,rbx
    7db2f9504717:	shr    rax,0x1e
    7db2f950471b:	and    eax,0x1
    7db2f950471e:	xor    eax,0x1
    7db2f9504721:	test   rax,rax
    7db2f9504724:	jne    0x7db2f9502c02
    7db2f950472a:	jmp    0x7db2f950472f
    7db2f950472f:	mov    r13d,DWORD PTR [r12+0x48]
    7db2f9504734:	add    r13d,0x1
    7db2f9504738:	mov    QWORD PTR [r12+0x48],r13
    7db2f950473d:	sub    r13d,0x1f4
    7db2f9504744:	mov    rcx,QWORD PTR [r12+0x380]
    7db2f950474c:	jrcxz  0x7db2f9504753
    7db2f950474e:	jmp    0x7db2f95061bb
    7db2f9504753:	jne    0x7db2f9502be4
    7db2f9504759:	mov    r11,rax
    7db2f950475c:	lahf
    7db2f950475d:	seto   al
    7db2f9504760:	mov    WORD PTR [rsp],ax
    7db2f9504764:	mov    rax,r11
    7db2f9504767:	jmp    0x7db2f950476c
    7db2f950476c:	mov    r13d,0x430000
    7db2f9504772:	mov    QWORD PTR [r12+0x40],r13
    7db2f9504777:	mov    r13d,0x0
    7db2f950477d:	mov    QWORD PTR [r12+0x48],r13
    7db2f9504782:	mov    r13d,0x430c50
    7db2f9504788:	mov    r14,QWORD PTR [r13+0x0]
    7db2f950478c:	mov    r13d,0x0
    7db2f9504792:	mov    QWORD PTR [r12+0x110],r14
    7db2f950479a:	mov    QWORD PTR [r12+0x118],r13
    7db2f95047a2:	jmp    0x7db2f95047a7
    7db2f95047a7:	mov    r13,QWORD PTR [r12+0x48]
    7db2f95047ac:	mov    r14,QWORD PTR [r12+0x50]
    7db2f95047b1:	add    r14,r13
    7db2f95047b4:	movdqu xmm2,XMMWORD PTR [r14]
    7db2f95047b9:	movdqu XMMWORD PTR [r12+0x120],xmm2
    7db2f95047c3:	add    r13,0x10
    7db2f95047c7:	mov    QWORD PTR [r12+0x48],r13
    7db2f95047cc:	sub    r13,0x200
    7db2f95047d3:	mov    r13,QWORD PTR [r12+0x128]
    7db2f95047db:	mov    r14d,0x0
    7db2f95047e1:	mov    QWORD PTR [r12+0x130],r13
    7db2f95047e9:	mov    QWORD PTR [r12+0x138],r14
    7db2f95047f1:	movdqu xmm2,XMMWORD PTR [r12+0x110]
    7db2f95047fb:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    7db2f9504805:	movdqa xmm0,xmm2
    7db2f9504809:	movdqa xmm1,xmm3
    7db2f950480d:	movq   xmm0,xmm0
    7db2f9504811:	movq   xmm1,xmm1
    7db2f9504815:	addsd  xmm0,xmm1
    7db2f9504819:	movdqa xmm14,xmm0
    7db2f950481e:	movdqu xmm15,XMMWORD PTR [rip+0x2249]        # 0x7db2f9506a70
    7db2f9504827:	pand   xmm14,xmm15
    7db2f950482c:	movdqu xmm15,XMMWORD PTR [rip+0x224b]        # 0x7db2f9506a80
    7db2f9504835:	pcmpeqq xmm14,xmm15
    7db2f950483b:	movdqa xmm15,xmm0
    7db2f9504840:	cmpunordpd xmm15,xmm0
    7db2f9504846:	por    xmm14,xmm15
    7db2f950484b:	pmovmskb ecx,xmm14
    7db2f9504850:	jrcxz  0x7db2f9504857
    7db2f9504852:	jmp    0x7db2f9504b9d
    7db2f9504857:	movdqa xmm4,xmm0
    7db2f950485b:	movdqu xmm2,XMMWORD PTR [r12+0x130]
    7db2f9504865:	movdqa xmm0,xmm4
    7db2f9504869:	movdqa xmm1,xmm2
    7db2f950486d:	movq   xmm0,xmm0
    7db2f9504871:	movq   xmm1,xmm1
    7db2f9504875:	addsd  xmm0,xmm1
    7db2f9504879:	movdqa xmm14,xmm0
    7db2f950487e:	movdqu xmm15,XMMWORD PTR [rip+0x21e9]        # 0x7db2f9506a70
    7db2f9504887:	pand   xmm14,xmm15
    7db2f950488c:	movdqu xmm15,XMMWORD PTR [rip+0x21eb]        # 0x7db2f9506a80
    7db2f9504895:	pcmpeqq xmm14,xmm15
    7db2f950489b:	movdqa xmm15,xmm0
    7db2f95048a0:	cmpunordpd xmm15,xmm0
    7db2f95048a6:	por    xmm14,xmm15
    7db2f95048ab:	pmovmskb ecx,xmm14
    7db2f95048b0:	jrcxz  0x7db2f95048b7
    7db2f95048b2:	jmp    0x7db2f9504bdc
    7db2f95048b7:	movdqa xmm3,xmm0
    7db2f95048bb:	movdqu XMMWORD PTR [r12+0x110],xmm3
    7db2f95048c5:	mov    rcx,QWORD PTR [r12+0x380]
    7db2f95048cd:	jrcxz  0x7db2f95048d4
    7db2f95048cf:	jmp    0x7db2f950624f
    7db2f95048d4:	jne    0x7db2f95048ed
    7db2f95048da:	mov    r11,rax
    7db2f95048dd:	lahf
    7db2f95048de:	seto   al
    7db2f95048e1:	mov    WORD PTR [rsp],ax
    7db2f95048e5:	mov    rax,r11
    7db2f95048e8:	jmp    0x7db2f9504900
    7db2f95048ed:	mov    r11,rax
    7db2f95048f0:	lahf
    7db2f95048f1:	seto   al
    7db2f95048f4:	mov    WORD PTR [rsp],ax
    7db2f95048f8:	mov    rax,r11
    7db2f95048fb:	jmp    0x7db2f95047a7
    7db2f9504900:	mov    r13,QWORD PTR [r12+0xf8]
    7db2f9504908:	mov    r14,r13
    7db2f950490b:	add    r14,0x1a0
    7db2f9504912:	mov    r15,r14
    7db2f9504915:	add    r15,0x8
    7db2f9504919:	mov    rbp,QWORD PTR [r14]
    7db2f950491c:	mov    r14,QWORD PTR [r15]
    7db2f950491f:	mov    QWORD PTR [r12+0xa0],rbp
    7db2f9504927:	mov    QWORD PTR [r12+0x98],r14
    7db2f950492f:	mov    r14,QWORD PTR [r12+0x40]
    7db2f9504934:	add    r14,0xc50
    7db2f950493b:	mov    r15,QWORD PTR [r12+0x110]
    7db2f9504943:	mov    QWORD PTR [r14],r15
    7db2f9504946:	mov    r14d,0x0
    7db2f950494c:	mov    DWORD PTR [r12+0x32c],r14d
    7db2f9504954:	mov    r14,r13
    7db2f9504957:	add    r14,0x190
    7db2f950495e:	mov    r15,r14
    7db2f9504961:	add    r15,0x8
    7db2f9504965:	mov    rbp,QWORD PTR [r14]
    7db2f9504968:	mov    r14,QWORD PTR [r15]
    7db2f950496b:	mov    QWORD PTR [r12+0xe8],rbp
    7db2f9504973:	mov    QWORD PTR [r12+0xf0],r14
    7db2f950497b:	mov    r14,r13
    7db2f950497e:	add    r14,0x180
    7db2f9504985:	mov    r15,r14
    7db2f9504988:	add    r15,0x8
    7db2f950498c:	mov    rbp,QWORD PTR [r14]
    7db2f950498f:	mov    r14,QWORD PTR [r15]
    7db2f9504992:	mov    r15d,0x0
    7db2f9504998:	mov    QWORD PTR [r12+0x1a0],rbp
    7db2f95049a0:	mov    QWORD PTR [r12+0x1a8],r15
    7db2f95049a8:	mov    r15d,0x0
    7db2f95049ae:	mov    QWORD PTR [r12+0x190],r14
    7db2f95049b6:	mov    QWORD PTR [r12+0x198],r15
    7db2f95049be:	mov    r14,r13
    7db2f95049c1:	add    r14,0x170
    7db2f95049c8:	mov    r15,r14
    7db2f95049cb:	add    r15,0x8
    7db2f95049cf:	mov    rbp,QWORD PTR [r14]
    7db2f95049d2:	mov    r14,QWORD PTR [r15]
    7db2f95049d5:	mov    r15d,0x0
    7db2f95049db:	mov    QWORD PTR [r12+0x1c0],rbp
    7db2f95049e3:	mov    QWORD PTR [r12+0x1c8],r15
    7db2f95049eb:	mov    r15d,0x0
    7db2f95049f1:	mov    QWORD PTR [r12+0x1b0],r14
    7db2f95049f9:	mov    QWORD PTR [r12+0x1b8],r15
    7db2f9504a01:	mov    r14,r13
    7db2f9504a04:	add    r14,0x160
    7db2f9504a0b:	mov    r15,r14
    7db2f9504a0e:	add    r15,0x8
    7db2f9504a12:	mov    rbp,QWORD PTR [r14]
    7db2f9504a15:	mov    r14,QWORD PTR [r15]
    7db2f9504a18:	mov    r15d,0x0
    7db2f9504a1e:	mov    QWORD PTR [r12+0x1e0],rbp
    7db2f9504a26:	mov    QWORD PTR [r12+0x1e8],r15
    7db2f9504a2e:	mov    r15d,0x0
    7db2f9504a34:	mov    QWORD PTR [r12+0x1d0],r14
    7db2f9504a3c:	mov    QWORD PTR [r12+0x1d8],r15
    7db2f9504a44:	mov    r14,r13
    7db2f9504a47:	add    r14,0x150
    7db2f9504a4e:	mov    r15,r14
    7db2f9504a51:	add    r15,0x8
    7db2f9504a55:	mov    rbp,QWORD PTR [r14]
    7db2f9504a58:	mov    r14,QWORD PTR [r15]
    7db2f9504a5b:	mov    r15d,0x0
    7db2f9504a61:	mov    QWORD PTR [r12+0x200],rbp
    7db2f9504a69:	mov    QWORD PTR [r12+0x208],r15
    7db2f9504a71:	mov    r15d,0x0
    7db2f9504a77:	mov    QWORD PTR [r12+0x1f0],r14
    7db2f9504a7f:	mov    QWORD PTR [r12+0x1f8],r15
    7db2f9504a87:	add    r13,0x1b0
    7db2f9504a8e:	mov    QWORD PTR [r12+0xf8],r13
    7db2f9504a96:	mov    rcx,QWORD PTR [r12+0x380]
    7db2f9504a9e:	jrcxz  0x7db2f9504aa5
    7db2f9504aa0:	jmp    0x7db2f95062e3
    7db2f9504aa5:	mov    r13,QWORD PTR [r12+0xf0]
    7db2f9504aad:	mov    QWORD PTR [r12+0x100],r13
    7db2f9504ab5:	mov    r11,QWORD PTR [rsp]
    7db2f9504ab9:	mov    QWORD PTR [r12+0x398],r11
    7db2f9504ac1:	mov    rdi,QWORD PTR [r12+0x100]
    7db2f9504ac9:	add    rsp,0x150
    7db2f9504ad0:	movabs r11,0x5a58c9ed2940
    7db2f9504ada:	jmp    r11
    7db2f9504add:	mov    r13d,DWORD PTR [r12+0x98]
    7db2f9504ae5:	mov    r14d,DWORD PTR [r12]
    7db2f9504ae9:	add    r14d,r13d
    7db2f9504aec:	mov    QWORD PTR [r12],r14
    7db2f9504af0:	mov    r13d,0x4103e8
    7db2f9504af6:	mov    QWORD PTR [r12+0xf0],r13
    7db2f9504afe:	mov    r13d,0x410938
    7db2f9504b04:	mov    QWORD PTR [r12+0x100],r13
    7db2f9504b0c:	mov    r11,QWORD PTR [rsp]
    7db2f9504b10:	mov    QWORD PTR [r12+0x398],r11
    7db2f9504b18:	mov    edi,0x410938
    7db2f9504b1d:	mov    QWORD PTR [r12+0x100],rdi
    7db2f9504b25:	add    rsp,0x150
    7db2f9504b2c:	nop    DWORD PTR [rax+0x0]
    7db2f9504b30:	jmp    QWORD PTR [rip+0x2]        # 0x7db2f9504b38
    7db2f9504b36:	xchg   ax,ax
    7db2f9504b38:	xor    BYTE PTR [rdi],dl
    7db2f9504b3a:	push   rax
    7db2f9504b3b:	stc
    7db2f9504b3c:	mov    dl,0x7d
    7db2f9504b3e:	add    BYTE PTR [rax],al
    7db2f9504b40:	rex.W
    7db2f9504b41:	rex.WXB push r8
    7db2f9504b43:	stc
    7db2f9504b44:	mov    dl,0x7d
    7db2f9504b46:	add    BYTE PTR [rax],al
    7db2f9504b48:	movabs r11,0x5a58c9ed2940
    7db2f9504b52:	jmp    r11
    7db2f9504b55:	movdqa xmm0,xmm2
    7db2f9504b59:	movdqa xmm1,xmm3
    7db2f9504b5d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7db2f9504b66:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7db2f9504b6f:	call   0x7db2f9504c20
    7db2f9504b74:	jmp    0x7db2f9502743
    7db2f9504b79:	movdqa xmm0,xmm2
    7db2f9504b7d:	movdqa xmm1,xmm3
    7db2f9504b81:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7db2f9504b8a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7db2f9504b93:	call   0x7db2f9504c20
    7db2f9504b98:	jmp    0x7db2f95027cf
    7db2f9504b9d:	mov    r11,rax
    7db2f9504ba0:	lahf
    7db2f9504ba1:	seto   al
    7db2f9504ba4:	mov    WORD PTR [rsp],ax
    7db2f9504ba8:	mov    rax,r11
    7db2f9504bab:	movdqa xmm0,xmm2
    7db2f9504baf:	movdqa xmm1,xmm3
    7db2f9504bb3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7db2f9504bbc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7db2f9504bc5:	call   0x7db2f9504cf0
    7db2f9504bca:	mov    r11,rax
    7db2f9504bcd:	movzx  eax,WORD PTR [rsp]
    7db2f9504bd1:	add    al,0x7f
    7db2f9504bd3:	sahf
    7db2f9504bd4:	mov    rax,r11
    7db2f9504bd7:	jmp    0x7db2f9504857
    7db2f9504bdc:	mov    r11,rax
    7db2f9504bdf:	lahf
    7db2f9504be0:	seto   al
    7db2f9504be3:	mov    WORD PTR [rsp],ax
    7db2f9504be7:	mov    rax,r11
    7db2f9504bea:	movdqa xmm0,xmm4
    7db2f9504bee:	movdqa xmm1,xmm2
    7db2f9504bf2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7db2f9504bfb:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7db2f9504c04:	call   0x7db2f9504e50
    7db2f9504c09:	mov    r11,rax
    7db2f9504c0c:	movzx  eax,WORD PTR [rsp]
    7db2f9504c10:	add    al,0x7f
    7db2f9504c12:	sahf
    7db2f9504c13:	mov    rax,r11
    7db2f9504c16:	jmp    0x7db2f95048b7
    7db2f9504c1b:	nop    DWORD PTR [rax+rax*1+0x0]
    7db2f9504c20:	sub    rsp,0x8
    7db2f9504c24:	mov    QWORD PTR [r12+0x378],0x3
    7db2f9504c30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7db2f9504c36:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7db2f9504c3c:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9504c44:	stmxcsr DWORD PTR [r12-0x28]
    7db2f9504c4a:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f9504c4f:	test   r10d,0x3f
    7db2f9504c56:	je     0x7db2f9504c7b
    7db2f9504c5c:	mov    r11d,r10d
    7db2f9504c5f:	shr    r10d,1
    7db2f9504c62:	and    r10d,0x1e
    7db2f9504c66:	and    r11d,0x1
    7db2f9504c6a:	or     r10d,r11d
    7db2f9504c6d:	or     DWORD PTR [r12+0x314],r10d
    7db2f9504c75:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f9504c7b:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f9504c81:	lea    rdi,[rsp+0x110]
    7db2f9504c89:	lea    rsi,[rsp+0xf0]
    7db2f9504c91:	lea    rdx,[rsp+0x100]
    7db2f9504c99:	mov    ecx,0x16
    7db2f9504c9e:	mov    r8d,0x0
    7db2f9504ca4:	lea    r9,[r12+0x314]
    7db2f9504cac:	movabs r11,0x5a58c9d39650
    7db2f9504cb6:	call   r11
    7db2f9504cb9:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f9504cbf:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7db2f9504cc5:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7db2f9504ccb:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f9504cd3:	mov    QWORD PTR [r12+0x378],0x2
    7db2f9504cdf:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7db2f9504ce8:	add    rsp,0x8
    7db2f9504cec:	ret
    7db2f9504ced:	nop    DWORD PTR [rax]
    7db2f9504cf0:	sub    rsp,0x8
    7db2f9504cf4:	mov    QWORD PTR [r12+0x378],0x3
    7db2f9504d00:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7db2f9504d06:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7db2f9504d0c:	push   rdx
    7db2f9504d0d:	push   rsi
    7db2f9504d0e:	push   r10
    7db2f9504d10:	push   r11
    7db2f9504d12:	mov    rdx,QWORD PTR [rsp+0x30]
    7db2f9504d17:	mov    r10d,edx
    7db2f9504d1a:	and    r10d,0xc000
    7db2f9504d21:	shl    r10d,0x10
    7db2f9504d25:	mov    r11d,edx
    7db2f9504d28:	and    r11d,0x100
    7db2f9504d2f:	shl    r11d,0x15
    7db2f9504d33:	or     r10d,r11d
    7db2f9504d36:	and    edx,0x1
    7db2f9504d39:	shl    edx,0x1c
    7db2f9504d3c:	or     r10d,edx
    7db2f9504d3f:	btc    r10,0x1d
    7db2f9504d44:	mov    r11d,0xf0000000
    7db2f9504d4a:	and    r11,r10
    7db2f9504d4d:	movabs rsi,0xffffffff0fffffff
    7db2f9504d57:	and    rbx,rsi
    7db2f9504d5a:	or     rbx,r11
    7db2f9504d5d:	pop    r11
    7db2f9504d5f:	pop    r10
    7db2f9504d61:	pop    rsi
    7db2f9504d62:	pop    rdx
    7db2f9504d63:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9504d6b:	stmxcsr DWORD PTR [r12-0x28]
    7db2f9504d71:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f9504d76:	test   r10d,0x3f
    7db2f9504d7d:	je     0x7db2f9504da2
    7db2f9504d83:	mov    r11d,r10d
    7db2f9504d86:	shr    r10d,1
    7db2f9504d89:	and    r10d,0x1e
    7db2f9504d8d:	and    r11d,0x1
    7db2f9504d91:	or     r10d,r11d
    7db2f9504d94:	or     DWORD PTR [r12+0x314],r10d
    7db2f9504d9c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f9504da2:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f9504da8:	lea    rdi,[rsp+0x110]
    7db2f9504db0:	lea    rsi,[rsp+0xf0]
    7db2f9504db8:	lea    rdx,[rsp+0x100]
    7db2f9504dc0:	mov    ecx,0xc
    7db2f9504dc5:	mov    r8d,0x0
    7db2f9504dcb:	lea    r9,[r12+0x314]
    7db2f9504dd3:	movabs r11,0x5a58c9d39650
    7db2f9504ddd:	call   r11
    7db2f9504de0:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f9504de6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7db2f9504dec:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7db2f9504df2:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f9504dfa:	mov    QWORD PTR [r12+0x378],0x2
    7db2f9504e06:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7db2f9504e0f:	mov    rdx,rbx
    7db2f9504e12:	shr    rdx,0x10
    7db2f9504e16:	and    edx,0xc000
    7db2f9504e1c:	mov    rax,rbx
    7db2f9504e1f:	shr    rax,0x15
    7db2f9504e23:	and    eax,0x100
    7db2f9504e28:	xor    eax,0x100
    7db2f9504e2d:	or     edx,eax
    7db2f9504e2f:	mov    rax,rbx
    7db2f9504e32:	shr    rax,0x1c
    7db2f9504e36:	and    eax,0x1
    7db2f9504e39:	or     edx,eax
    7db2f9504e3b:	mov    QWORD PTR [rsp+0x10],rdx
    7db2f9504e40:	add    rsp,0x8
    7db2f9504e44:	ret
    7db2f9504e45:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7db2f9504e50:	sub    rsp,0x8
    7db2f9504e54:	mov    QWORD PTR [r12+0x378],0x3
    7db2f9504e60:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7db2f9504e66:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    7db2f9504e6c:	push   rdx
    7db2f9504e6d:	push   rsi
    7db2f9504e6e:	push   r10
    7db2f9504e70:	push   r11
    7db2f9504e72:	mov    rdx,QWORD PTR [rsp+0x30]
    7db2f9504e77:	mov    r10d,edx
    7db2f9504e7a:	and    r10d,0xc000
    7db2f9504e81:	shl    r10d,0x10
    7db2f9504e85:	mov    r11d,edx
    7db2f9504e88:	and    r11d,0x100
    7db2f9504e8f:	shl    r11d,0x15
    7db2f9504e93:	or     r10d,r11d
    7db2f9504e96:	and    edx,0x1
    7db2f9504e99:	shl    edx,0x1c
    7db2f9504e9c:	or     r10d,edx
    7db2f9504e9f:	btc    r10,0x1d
    7db2f9504ea4:	mov    r11d,0xf0000000
    7db2f9504eaa:	and    r11,r10
    7db2f9504ead:	movabs rsi,0xffffffff0fffffff
    7db2f9504eb7:	and    rbx,rsi
    7db2f9504eba:	or     rbx,r11
    7db2f9504ebd:	pop    r11
    7db2f9504ebf:	pop    r10
    7db2f9504ec1:	pop    rsi
    7db2f9504ec2:	pop    rdx
    7db2f9504ec3:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9504ecb:	stmxcsr DWORD PTR [r12-0x28]
    7db2f9504ed1:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f9504ed6:	test   r10d,0x3f
    7db2f9504edd:	je     0x7db2f9504f02
    7db2f9504ee3:	mov    r11d,r10d
    7db2f9504ee6:	shr    r10d,1
    7db2f9504ee9:	and    r10d,0x1e
    7db2f9504eed:	and    r11d,0x1
    7db2f9504ef1:	or     r10d,r11d
    7db2f9504ef4:	or     DWORD PTR [r12+0x314],r10d
    7db2f9504efc:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f9504f02:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f9504f08:	lea    rdi,[rsp+0x110]
    7db2f9504f10:	lea    rsi,[rsp+0xf0]
    7db2f9504f18:	lea    rdx,[rsp+0x100]
    7db2f9504f20:	mov    ecx,0xc
    7db2f9504f25:	mov    r8d,0x0
    7db2f9504f2b:	lea    r9,[r12+0x314]
    7db2f9504f33:	movabs r11,0x5a58c9d39650
    7db2f9504f3d:	call   r11
    7db2f9504f40:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f9504f46:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7db2f9504f4c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    7db2f9504f52:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f9504f5a:	mov    QWORD PTR [r12+0x378],0x2
    7db2f9504f66:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7db2f9504f6f:	mov    rdx,rbx
    7db2f9504f72:	shr    rdx,0x10
    7db2f9504f76:	and    edx,0xc000
    7db2f9504f7c:	mov    rax,rbx
    7db2f9504f7f:	shr    rax,0x15
    7db2f9504f83:	and    eax,0x100
    7db2f9504f88:	xor    eax,0x100
    7db2f9504f8d:	or     edx,eax
    7db2f9504f8f:	mov    rax,rbx
    7db2f9504f92:	shr    rax,0x1c
    7db2f9504f96:	and    eax,0x1
    7db2f9504f99:	or     edx,eax
    7db2f9504f9b:	mov    QWORD PTR [rsp+0x10],rdx
    7db2f9504fa0:	add    rsp,0x8
    7db2f9504fa4:	ret
    7db2f9504fa5:	mov    QWORD PTR [r12+0x378],0x3
    7db2f9504fb1:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9504fb9:	stmxcsr DWORD PTR [r12-0x28]
    7db2f9504fbf:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f9504fc4:	test   r10d,0x3f
    7db2f9504fcb:	je     0x7db2f9504ff0
    7db2f9504fd1:	mov    r11d,r10d
    7db2f9504fd4:	shr    r10d,1
    7db2f9504fd7:	and    r10d,0x1e
    7db2f9504fdb:	and    r11d,0x1
    7db2f9504fdf:	or     r10d,r11d
    7db2f9504fe2:	or     DWORD PTR [r12+0x314],r10d
    7db2f9504fea:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f9504ff0:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f9504ff6:	movabs r11,0x5a58c9d345e0
    7db2f9505000:	mov    rdi,r13
    7db2f9505003:	mov    rsi,r14
    7db2f9505006:	mov    rdx,r15
    7db2f9505009:	call   r11
    7db2f950500c:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f9505012:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f950501a:	mov    QWORD PTR [r12+0x378],0x2
    7db2f9505026:	jmp    0x7db2f9502fce
    7db2f950502b:	mov    QWORD PTR [r12+0x378],0x3
    7db2f9505037:	mov    QWORD PTR [r12+0x108],rbx
    7db2f950503f:	stmxcsr DWORD PTR [r12-0x28]
    7db2f9505045:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f950504a:	test   r10d,0x3f
    7db2f9505051:	je     0x7db2f9505076
    7db2f9505057:	mov    r11d,r10d
    7db2f950505a:	shr    r10d,1
    7db2f950505d:	and    r10d,0x1e
    7db2f9505061:	and    r11d,0x1
    7db2f9505065:	or     r10d,r11d
    7db2f9505068:	or     DWORD PTR [r12+0x314],r10d
    7db2f9505070:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f9505076:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f950507c:	movabs r11,0x5a58c9d345e0
    7db2f9505086:	mov    rdi,r13
    7db2f9505089:	mov    rsi,r14
    7db2f950508c:	mov    rdx,r15
    7db2f950508f:	call   r11
    7db2f9505092:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f9505098:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f95050a0:	mov    QWORD PTR [r12+0x378],0x2
    7db2f95050ac:	jmp    0x7db2f9503061
    7db2f95050b1:	mov    QWORD PTR [r12+0x378],0x3
    7db2f95050bd:	mov    QWORD PTR [r12+0x108],rbx
    7db2f95050c5:	stmxcsr DWORD PTR [r12-0x28]
    7db2f95050cb:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f95050d0:	test   r10d,0x3f
    7db2f95050d7:	je     0x7db2f95050fc
    7db2f95050dd:	mov    r11d,r10d
    7db2f95050e0:	shr    r10d,1
    7db2f95050e3:	and    r10d,0x1e
    7db2f95050e7:	and    r11d,0x1
    7db2f95050eb:	or     r10d,r11d
    7db2f95050ee:	or     DWORD PTR [r12+0x314],r10d
    7db2f95050f6:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f95050fc:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f9505102:	movabs r11,0x5a58c9d345e0
    7db2f950510c:	mov    rdi,r13
    7db2f950510f:	mov    rsi,r14
    7db2f9505112:	mov    rdx,r15
    7db2f9505115:	call   r11
    7db2f9505118:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f950511e:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f9505126:	mov    QWORD PTR [r12+0x378],0x2
    7db2f9505132:	jmp    0x7db2f950321f
    7db2f9505137:	mov    QWORD PTR [r12+0x378],0x3
    7db2f9505143:	mov    QWORD PTR [r12+0x108],rbx
    7db2f950514b:	stmxcsr DWORD PTR [r12-0x28]
    7db2f9505151:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f9505156:	test   r10d,0x3f
    7db2f950515d:	je     0x7db2f9505182
    7db2f9505163:	mov    r11d,r10d
    7db2f9505166:	shr    r10d,1
    7db2f9505169:	and    r10d,0x1e
    7db2f950516d:	and    r11d,0x1
    7db2f9505171:	or     r10d,r11d
    7db2f9505174:	or     DWORD PTR [r12+0x314],r10d
    7db2f950517c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f9505182:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f9505188:	movabs r11,0x5a58c9d345e0
    7db2f9505192:	mov    rdi,r13
    7db2f9505195:	mov    rsi,r14
    7db2f9505198:	mov    rdx,r15
    7db2f950519b:	call   r11
    7db2f950519e:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f95051a4:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f95051ac:	mov    QWORD PTR [r12+0x378],0x2
    7db2f95051b8:	jmp    0x7db2f95032d1
    7db2f95051bd:	mov    QWORD PTR [r12+0x378],0x3
    7db2f95051c9:	mov    QWORD PTR [r12+0x108],rbx
    7db2f95051d1:	stmxcsr DWORD PTR [r12-0x28]
    7db2f95051d7:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f95051dc:	test   r10d,0x3f
    7db2f95051e3:	je     0x7db2f9505208
    7db2f95051e9:	mov    r11d,r10d
    7db2f95051ec:	shr    r10d,1
    7db2f95051ef:	and    r10d,0x1e
    7db2f95051f3:	and    r11d,0x1
    7db2f95051f7:	or     r10d,r11d
    7db2f95051fa:	or     DWORD PTR [r12+0x314],r10d
    7db2f9505202:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f9505208:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f950520e:	movabs r11,0x5a58c9d345e0
    7db2f9505218:	mov    rdi,r13
    7db2f950521b:	mov    rsi,r14
    7db2f950521e:	mov    rdx,r15
    7db2f9505221:	call   r11
    7db2f9505224:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f950522a:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f9505232:	mov    QWORD PTR [r12+0x378],0x2
    7db2f950523e:	jmp    0x7db2f9503481
    7db2f9505243:	mov    QWORD PTR [r12+0x378],0x3
    7db2f950524f:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9505257:	stmxcsr DWORD PTR [r12-0x28]
    7db2f950525d:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f9505262:	test   r10d,0x3f
    7db2f9505269:	je     0x7db2f950528e
    7db2f950526f:	mov    r11d,r10d
    7db2f9505272:	shr    r10d,1
    7db2f9505275:	and    r10d,0x1e
    7db2f9505279:	and    r11d,0x1
    7db2f950527d:	or     r10d,r11d
    7db2f9505280:	or     DWORD PTR [r12+0x314],r10d
    7db2f9505288:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f950528e:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f9505294:	movabs r11,0x5a58c9d345e0
    7db2f950529e:	mov    rdi,r13
    7db2f95052a1:	mov    rsi,r14
    7db2f95052a4:	mov    rdx,r15
    7db2f95052a7:	call   r11
    7db2f95052aa:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f95052b0:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f95052b8:	mov    QWORD PTR [r12+0x378],0x2
    7db2f95052c4:	jmp    0x7db2f9503519
    7db2f95052c9:	mov    QWORD PTR [r12+0x378],0x3
    7db2f95052d5:	mov    QWORD PTR [r12+0x108],rbx
    7db2f95052dd:	stmxcsr DWORD PTR [r12-0x28]
    7db2f95052e3:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f95052e8:	test   r10d,0x3f
    7db2f95052ef:	je     0x7db2f9505314
    7db2f95052f5:	mov    r11d,r10d
    7db2f95052f8:	shr    r10d,1
    7db2f95052fb:	and    r10d,0x1e
    7db2f95052ff:	and    r11d,0x1
    7db2f9505303:	or     r10d,r11d
    7db2f9505306:	or     DWORD PTR [r12+0x314],r10d
    7db2f950530e:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f9505314:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f950531a:	movabs r11,0x5a58c9d345e0
    7db2f9505324:	mov    rdi,r13
    7db2f9505327:	mov    rsi,r14
    7db2f950532a:	mov    rdx,r15
    7db2f950532d:	call   r11
    7db2f9505330:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f9505336:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f950533e:	mov    QWORD PTR [r12+0x378],0x2
    7db2f950534a:	jmp    0x7db2f95035b1
    7db2f950534f:	mov    QWORD PTR [r12+0x378],0x3
    7db2f950535b:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9505363:	stmxcsr DWORD PTR [r12-0x28]
    7db2f9505369:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f950536e:	test   r10d,0x3f
    7db2f9505375:	je     0x7db2f950539a
    7db2f950537b:	mov    r11d,r10d
    7db2f950537e:	shr    r10d,1
    7db2f9505381:	and    r10d,0x1e
    7db2f9505385:	and    r11d,0x1
    7db2f9505389:	or     r10d,r11d
    7db2f950538c:	or     DWORD PTR [r12+0x314],r10d
    7db2f9505394:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f950539a:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f95053a0:	movabs r11,0x5a58c9d345e0
    7db2f95053aa:	mov    rdi,r13
    7db2f95053ad:	mov    rsi,r14
    7db2f95053b0:	mov    rdx,r15
    7db2f95053b3:	call   r11
    7db2f95053b6:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f95053bc:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f95053c4:	mov    QWORD PTR [r12+0x378],0x2
    7db2f95053d0:	jmp    0x7db2f9503665
    7db2f95053d5:	mov    QWORD PTR [r12+0x378],0x3
    7db2f95053e1:	mov    QWORD PTR [r12+0x108],rbx
    7db2f95053e9:	stmxcsr DWORD PTR [r12-0x28]
    7db2f95053ef:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f95053f4:	test   r10d,0x3f
    7db2f95053fb:	je     0x7db2f9505420
    7db2f9505401:	mov    r11d,r10d
    7db2f9505404:	shr    r10d,1
    7db2f9505407:	and    r10d,0x1e
    7db2f950540b:	and    r11d,0x1
    7db2f950540f:	or     r10d,r11d
    7db2f9505412:	or     DWORD PTR [r12+0x314],r10d
    7db2f950541a:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f9505420:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f9505426:	movabs r11,0x5a58c9d345e0
    7db2f9505430:	mov    rdi,r13
    7db2f9505433:	mov    rsi,r14
    7db2f9505436:	mov    rdx,r15
    7db2f9505439:	call   r11
    7db2f950543c:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f9505442:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f950544a:	mov    QWORD PTR [r12+0x378],0x2
    7db2f9505456:	jmp    0x7db2f950376d
    7db2f950545b:	mov    QWORD PTR [r12+0x378],0x3
    7db2f9505467:	mov    QWORD PTR [r12+0x108],rbx
    7db2f950546f:	stmxcsr DWORD PTR [r12-0x28]
    7db2f9505475:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f950547a:	test   r10d,0x3f
    7db2f9505481:	je     0x7db2f95054a6
    7db2f9505487:	mov    r11d,r10d
    7db2f950548a:	shr    r10d,1
    7db2f950548d:	and    r10d,0x1e
    7db2f9505491:	and    r11d,0x1
    7db2f9505495:	or     r10d,r11d
    7db2f9505498:	or     DWORD PTR [r12+0x314],r10d
    7db2f95054a0:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f95054a6:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f95054ac:	movabs r11,0x5a58c9d345e0
    7db2f95054b6:	mov    rdi,r13
    7db2f95054b9:	mov    rsi,r14
    7db2f95054bc:	mov    rdx,r15
    7db2f95054bf:	call   r11
    7db2f95054c2:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f95054c8:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f95054d0:	mov    QWORD PTR [r12+0x378],0x2
    7db2f95054dc:	jmp    0x7db2f9503805
    7db2f95054e1:	mov    QWORD PTR [r12+0x378],0x3
    7db2f95054ed:	mov    QWORD PTR [r12+0x108],rbx
    7db2f95054f5:	stmxcsr DWORD PTR [r12-0x28]
    7db2f95054fb:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f9505500:	test   r10d,0x3f
    7db2f9505507:	je     0x7db2f950552c
    7db2f950550d:	mov    r11d,r10d
    7db2f9505510:	shr    r10d,1
    7db2f9505513:	and    r10d,0x1e
    7db2f9505517:	and    r11d,0x1
    7db2f950551b:	or     r10d,r11d
    7db2f950551e:	or     DWORD PTR [r12+0x314],r10d
    7db2f9505526:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f950552c:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f9505532:	movabs r11,0x5a58c9d345e0
    7db2f950553c:	mov    rdi,r13
    7db2f950553f:	mov    rsi,r14
    7db2f9505542:	mov    rdx,r15
    7db2f9505545:	call   r11
    7db2f9505548:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f950554e:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f9505556:	mov    QWORD PTR [r12+0x378],0x2
    7db2f9505562:	jmp    0x7db2f950389d
    7db2f9505567:	mov    QWORD PTR [r12+0x378],0x3
    7db2f9505573:	mov    QWORD PTR [r12+0x108],rbx
    7db2f950557b:	stmxcsr DWORD PTR [r12-0x28]
    7db2f9505581:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f9505586:	test   r10d,0x3f
    7db2f950558d:	je     0x7db2f95055b2
    7db2f9505593:	mov    r11d,r10d
    7db2f9505596:	shr    r10d,1
    7db2f9505599:	and    r10d,0x1e
    7db2f950559d:	and    r11d,0x1
    7db2f95055a1:	or     r10d,r11d
    7db2f95055a4:	or     DWORD PTR [r12+0x314],r10d
    7db2f95055ac:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f95055b2:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f95055b8:	movabs r11,0x5a58c9d345e0
    7db2f95055c2:	mov    rdi,r13
    7db2f95055c5:	mov    rsi,r14
    7db2f95055c8:	mov    rdx,r15
    7db2f95055cb:	call   r11
    7db2f95055ce:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f95055d4:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f95055dc:	mov    QWORD PTR [r12+0x378],0x2
    7db2f95055e8:	jmp    0x7db2f9503935
    7db2f95055ed:	mov    QWORD PTR [r12+0x378],0x3
    7db2f95055f9:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9505601:	stmxcsr DWORD PTR [r12-0x28]
    7db2f9505607:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f950560c:	test   r10d,0x3f
    7db2f9505613:	je     0x7db2f9505638
    7db2f9505619:	mov    r11d,r10d
    7db2f950561c:	shr    r10d,1
    7db2f950561f:	and    r10d,0x1e
    7db2f9505623:	and    r11d,0x1
    7db2f9505627:	or     r10d,r11d
    7db2f950562a:	or     DWORD PTR [r12+0x314],r10d
    7db2f9505632:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f9505638:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f950563e:	movabs r11,0x5a58c9d345e0
    7db2f9505648:	mov    rdi,r13
    7db2f950564b:	mov    rsi,r14
    7db2f950564e:	mov    rdx,r15
    7db2f9505651:	call   r11
    7db2f9505654:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f950565a:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f9505662:	mov    QWORD PTR [r12+0x378],0x2
    7db2f950566e:	jmp    0x7db2f9503a05
    7db2f9505673:	mov    QWORD PTR [r12+0x378],0x3
    7db2f950567f:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9505687:	stmxcsr DWORD PTR [r12-0x28]
    7db2f950568d:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f9505692:	test   r10d,0x3f
    7db2f9505699:	je     0x7db2f95056be
    7db2f950569f:	mov    r11d,r10d
    7db2f95056a2:	shr    r10d,1
    7db2f95056a5:	and    r10d,0x1e
    7db2f95056a9:	and    r11d,0x1
    7db2f95056ad:	or     r10d,r11d
    7db2f95056b0:	or     DWORD PTR [r12+0x314],r10d
    7db2f95056b8:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f95056be:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f95056c4:	movabs r11,0x5a58c9d345e0
    7db2f95056ce:	mov    rdi,r13
    7db2f95056d1:	mov    rsi,r14
    7db2f95056d4:	mov    rdx,r15
    7db2f95056d7:	call   r11
    7db2f95056da:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f95056e0:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f95056e8:	mov    QWORD PTR [r12+0x378],0x2
    7db2f95056f4:	jmp    0x7db2f9503a9d
    7db2f95056f9:	mov    QWORD PTR [r12+0x378],0x3
    7db2f9505705:	mov    QWORD PTR [r12+0x108],rbx
    7db2f950570d:	stmxcsr DWORD PTR [r12-0x28]
    7db2f9505713:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f9505718:	test   r10d,0x3f
    7db2f950571f:	je     0x7db2f9505744
    7db2f9505725:	mov    r11d,r10d
    7db2f9505728:	shr    r10d,1
    7db2f950572b:	and    r10d,0x1e
    7db2f950572f:	and    r11d,0x1
    7db2f9505733:	or     r10d,r11d
    7db2f9505736:	or     DWORD PTR [r12+0x314],r10d
    7db2f950573e:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f9505744:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f950574a:	movabs r11,0x5a58c9d345e0
    7db2f9505754:	mov    rdi,r13
    7db2f9505757:	mov    rsi,r14
    7db2f950575a:	mov    rdx,r15
    7db2f950575d:	call   r11
    7db2f9505760:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f9505766:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f950576e:	mov    QWORD PTR [r12+0x378],0x2
    7db2f950577a:	jmp    0x7db2f9503b54
    7db2f950577f:	mov    QWORD PTR [r12+0x378],0x3
    7db2f950578b:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9505793:	stmxcsr DWORD PTR [r12-0x28]
    7db2f9505799:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f950579e:	test   r10d,0x3f
    7db2f95057a5:	je     0x7db2f95057ca
    7db2f95057ab:	mov    r11d,r10d
    7db2f95057ae:	shr    r10d,1
    7db2f95057b1:	and    r10d,0x1e
    7db2f95057b5:	and    r11d,0x1
    7db2f95057b9:	or     r10d,r11d
    7db2f95057bc:	or     DWORD PTR [r12+0x314],r10d
    7db2f95057c4:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f95057ca:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f95057d0:	movabs r11,0x5a58c9d345e0
    7db2f95057da:	mov    rdi,r13
    7db2f95057dd:	mov    rsi,r14
    7db2f95057e0:	mov    rdx,r15
    7db2f95057e3:	call   r11
    7db2f95057e6:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f95057ec:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f95057f4:	mov    QWORD PTR [r12+0x378],0x2
    7db2f9505800:	jmp    0x7db2f9503bec
    7db2f9505805:	mov    QWORD PTR [r12+0x378],0x3
    7db2f9505811:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9505819:	stmxcsr DWORD PTR [r12-0x28]
    7db2f950581f:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f9505824:	test   r10d,0x3f
    7db2f950582b:	je     0x7db2f9505850
    7db2f9505831:	mov    r11d,r10d
    7db2f9505834:	shr    r10d,1
    7db2f9505837:	and    r10d,0x1e
    7db2f950583b:	and    r11d,0x1
    7db2f950583f:	or     r10d,r11d
    7db2f9505842:	or     DWORD PTR [r12+0x314],r10d
    7db2f950584a:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f9505850:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f9505856:	movabs r11,0x5a58c9d345e0
    7db2f9505860:	mov    rdi,r13
    7db2f9505863:	mov    rsi,r14
    7db2f9505866:	mov    rdx,r15
    7db2f9505869:	call   r11
    7db2f950586c:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f9505872:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f950587a:	mov    QWORD PTR [r12+0x378],0x2
    7db2f9505886:	jmp    0x7db2f9503cd2
    7db2f950588b:	mov    QWORD PTR [r12+0x378],0x3
    7db2f9505897:	mov    QWORD PTR [r12+0x108],rbx
    7db2f950589f:	stmxcsr DWORD PTR [r12-0x28]
    7db2f95058a5:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f95058aa:	test   r10d,0x3f
    7db2f95058b1:	je     0x7db2f95058d6
    7db2f95058b7:	mov    r11d,r10d
    7db2f95058ba:	shr    r10d,1
    7db2f95058bd:	and    r10d,0x1e
    7db2f95058c1:	and    r11d,0x1
    7db2f95058c5:	or     r10d,r11d
    7db2f95058c8:	or     DWORD PTR [r12+0x314],r10d
    7db2f95058d0:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f95058d6:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f95058dc:	movabs r11,0x5a58c9d345e0
    7db2f95058e6:	mov    rdi,r13
    7db2f95058e9:	mov    rsi,r14
    7db2f95058ec:	mov    rdx,r15
    7db2f95058ef:	call   r11
    7db2f95058f2:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f95058f8:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f9505900:	mov    QWORD PTR [r12+0x378],0x2
    7db2f950590c:	jmp    0x7db2f9503d6a
    7db2f9505911:	mov    QWORD PTR [r12+0x378],0x3
    7db2f950591d:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9505925:	stmxcsr DWORD PTR [r12-0x28]
    7db2f950592b:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f9505930:	test   r10d,0x3f
    7db2f9505937:	je     0x7db2f950595c
    7db2f950593d:	mov    r11d,r10d
    7db2f9505940:	shr    r10d,1
    7db2f9505943:	and    r10d,0x1e
    7db2f9505947:	and    r11d,0x1
    7db2f950594b:	or     r10d,r11d
    7db2f950594e:	or     DWORD PTR [r12+0x314],r10d
    7db2f9505956:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f950595c:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f9505962:	movabs r11,0x5a58c9d345e0
    7db2f950596c:	mov    rdi,r13
    7db2f950596f:	mov    rsi,r14
    7db2f9505972:	mov    rdx,r15
    7db2f9505975:	call   r11
    7db2f9505978:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f950597e:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f9505986:	mov    QWORD PTR [r12+0x378],0x2
    7db2f9505992:	jmp    0x7db2f9503e02
    7db2f9505997:	mov    QWORD PTR [r12+0x378],0x3
    7db2f95059a3:	mov    QWORD PTR [r12+0x108],rbx
    7db2f95059ab:	stmxcsr DWORD PTR [r12-0x28]
    7db2f95059b1:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f95059b6:	test   r10d,0x3f
    7db2f95059bd:	je     0x7db2f95059e2
    7db2f95059c3:	mov    r11d,r10d
    7db2f95059c6:	shr    r10d,1
    7db2f95059c9:	and    r10d,0x1e
    7db2f95059cd:	and    r11d,0x1
    7db2f95059d1:	or     r10d,r11d
    7db2f95059d4:	or     DWORD PTR [r12+0x314],r10d
    7db2f95059dc:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f95059e2:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f95059e8:	movabs r11,0x5a58c9d345e0
    7db2f95059f2:	mov    rdi,r13
    7db2f95059f5:	mov    rsi,r14
    7db2f95059f8:	mov    rdx,r15
    7db2f95059fb:	call   r11
    7db2f95059fe:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f9505a04:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f9505a0c:	mov    QWORD PTR [r12+0x378],0x2
    7db2f9505a18:	jmp    0x7db2f9503e9a
    7db2f9505a1d:	mov    QWORD PTR [r12+0x378],0x3
    7db2f9505a29:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9505a31:	stmxcsr DWORD PTR [r12-0x28]
    7db2f9505a37:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f9505a3c:	test   r10d,0x3f
    7db2f9505a43:	je     0x7db2f9505a68
    7db2f9505a49:	mov    r11d,r10d
    7db2f9505a4c:	shr    r10d,1
    7db2f9505a4f:	and    r10d,0x1e
    7db2f9505a53:	and    r11d,0x1
    7db2f9505a57:	or     r10d,r11d
    7db2f9505a5a:	or     DWORD PTR [r12+0x314],r10d
    7db2f9505a62:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f9505a68:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f9505a6e:	movabs r11,0x5a58c9d345e0
    7db2f9505a78:	mov    rdi,r13
    7db2f9505a7b:	mov    rsi,r14
    7db2f9505a7e:	mov    rdx,r15
    7db2f9505a81:	call   r11
    7db2f9505a84:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f9505a8a:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f9505a92:	mov    QWORD PTR [r12+0x378],0x2
    7db2f9505a9e:	jmp    0x7db2f9503f64
    7db2f9505aa3:	mov    QWORD PTR [r12+0x378],0x3
    7db2f9505aaf:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9505ab7:	stmxcsr DWORD PTR [r12-0x28]
    7db2f9505abd:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f9505ac2:	test   r10d,0x3f
    7db2f9505ac9:	je     0x7db2f9505aee
    7db2f9505acf:	mov    r11d,r10d
    7db2f9505ad2:	shr    r10d,1
    7db2f9505ad5:	and    r10d,0x1e
    7db2f9505ad9:	and    r11d,0x1
    7db2f9505add:	or     r10d,r11d
    7db2f9505ae0:	or     DWORD PTR [r12+0x314],r10d
    7db2f9505ae8:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f9505aee:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f9505af4:	movabs r11,0x5a58c9d345e0
    7db2f9505afe:	mov    rdi,r13
    7db2f9505b01:	mov    rsi,r14
    7db2f9505b04:	mov    rdx,r15
    7db2f9505b07:	call   r11
    7db2f9505b0a:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f9505b10:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f9505b18:	mov    QWORD PTR [r12+0x378],0x2
    7db2f9505b24:	jmp    0x7db2f9503ffc
    7db2f9505b29:	mov    QWORD PTR [r12+0x378],0x3
    7db2f9505b35:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9505b3d:	stmxcsr DWORD PTR [r12-0x28]
    7db2f9505b43:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f9505b48:	test   r10d,0x3f
    7db2f9505b4f:	je     0x7db2f9505b74
    7db2f9505b55:	mov    r11d,r10d
    7db2f9505b58:	shr    r10d,1
    7db2f9505b5b:	and    r10d,0x1e
    7db2f9505b5f:	and    r11d,0x1
    7db2f9505b63:	or     r10d,r11d
    7db2f9505b66:	or     DWORD PTR [r12+0x314],r10d
    7db2f9505b6e:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f9505b74:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f9505b7a:	movabs r11,0x5a58c9d345e0
    7db2f9505b84:	mov    rdi,r13
    7db2f9505b87:	mov    rsi,r14
    7db2f9505b8a:	mov    rdx,r15
    7db2f9505b8d:	call   r11
    7db2f9505b90:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f9505b96:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f9505b9e:	mov    QWORD PTR [r12+0x378],0x2
    7db2f9505baa:	jmp    0x7db2f9504094
    7db2f9505baf:	mov    QWORD PTR [r12+0x378],0x3
    7db2f9505bbb:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9505bc3:	stmxcsr DWORD PTR [r12-0x28]
    7db2f9505bc9:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f9505bce:	test   r10d,0x3f
    7db2f9505bd5:	je     0x7db2f9505bfa
    7db2f9505bdb:	mov    r11d,r10d
    7db2f9505bde:	shr    r10d,1
    7db2f9505be1:	and    r10d,0x1e
    7db2f9505be5:	and    r11d,0x1
    7db2f9505be9:	or     r10d,r11d
    7db2f9505bec:	or     DWORD PTR [r12+0x314],r10d
    7db2f9505bf4:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f9505bfa:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f9505c00:	movabs r11,0x5a58c9d345e0
    7db2f9505c0a:	mov    rdi,r13
    7db2f9505c0d:	mov    rsi,r14
    7db2f9505c10:	mov    rdx,r15
    7db2f9505c13:	call   r11
    7db2f9505c16:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f9505c1c:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f9505c24:	mov    QWORD PTR [r12+0x378],0x2
    7db2f9505c30:	jmp    0x7db2f950412c
    7db2f9505c35:	mov    QWORD PTR [r12+0x378],0x3
    7db2f9505c41:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9505c49:	stmxcsr DWORD PTR [r12-0x28]
    7db2f9505c4f:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f9505c54:	test   r10d,0x3f
    7db2f9505c5b:	je     0x7db2f9505c80
    7db2f9505c61:	mov    r11d,r10d
    7db2f9505c64:	shr    r10d,1
    7db2f9505c67:	and    r10d,0x1e
    7db2f9505c6b:	and    r11d,0x1
    7db2f9505c6f:	or     r10d,r11d
    7db2f9505c72:	or     DWORD PTR [r12+0x314],r10d
    7db2f9505c7a:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f9505c80:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f9505c86:	movabs r11,0x5a58c9d345e0
    7db2f9505c90:	mov    rdi,r13
    7db2f9505c93:	mov    rsi,r14
    7db2f9505c96:	mov    rdx,r15
    7db2f9505c99:	call   r11
    7db2f9505c9c:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f9505ca2:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f9505caa:	mov    QWORD PTR [r12+0x378],0x2
    7db2f9505cb6:	jmp    0x7db2f95041f6
    7db2f9505cbb:	mov    QWORD PTR [r12+0x378],0x3
    7db2f9505cc7:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9505ccf:	stmxcsr DWORD PTR [r12-0x28]
    7db2f9505cd5:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f9505cda:	test   r10d,0x3f
    7db2f9505ce1:	je     0x7db2f9505d06
    7db2f9505ce7:	mov    r11d,r10d
    7db2f9505cea:	shr    r10d,1
    7db2f9505ced:	and    r10d,0x1e
    7db2f9505cf1:	and    r11d,0x1
    7db2f9505cf5:	or     r10d,r11d
    7db2f9505cf8:	or     DWORD PTR [r12+0x314],r10d
    7db2f9505d00:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f9505d06:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f9505d0c:	movabs r11,0x5a58c9d345e0
    7db2f9505d16:	mov    rdi,r13
    7db2f9505d19:	mov    rsi,r14
    7db2f9505d1c:	mov    rdx,r15
    7db2f9505d1f:	call   r11
    7db2f9505d22:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f9505d28:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f9505d30:	mov    QWORD PTR [r12+0x378],0x2
    7db2f9505d3c:	jmp    0x7db2f950428e
    7db2f9505d41:	mov    QWORD PTR [r12+0x378],0x3
    7db2f9505d4d:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9505d55:	stmxcsr DWORD PTR [r12-0x28]
    7db2f9505d5b:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f9505d60:	test   r10d,0x3f
    7db2f9505d67:	je     0x7db2f9505d8c
    7db2f9505d6d:	mov    r11d,r10d
    7db2f9505d70:	shr    r10d,1
    7db2f9505d73:	and    r10d,0x1e
    7db2f9505d77:	and    r11d,0x1
    7db2f9505d7b:	or     r10d,r11d
    7db2f9505d7e:	or     DWORD PTR [r12+0x314],r10d
    7db2f9505d86:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f9505d8c:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f9505d92:	movabs r11,0x5a58c9d345e0
    7db2f9505d9c:	mov    rdi,r13
    7db2f9505d9f:	mov    rsi,r14
    7db2f9505da2:	mov    rdx,r15
    7db2f9505da5:	call   r11
    7db2f9505da8:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f9505dae:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f9505db6:	mov    QWORD PTR [r12+0x378],0x2
    7db2f9505dc2:	jmp    0x7db2f9504326
    7db2f9505dc7:	mov    QWORD PTR [r12+0x378],0x3
    7db2f9505dd3:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9505ddb:	stmxcsr DWORD PTR [r12-0x28]
    7db2f9505de1:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f9505de6:	test   r10d,0x3f
    7db2f9505ded:	je     0x7db2f9505e12
    7db2f9505df3:	mov    r11d,r10d
    7db2f9505df6:	shr    r10d,1
    7db2f9505df9:	and    r10d,0x1e
    7db2f9505dfd:	and    r11d,0x1
    7db2f9505e01:	or     r10d,r11d
    7db2f9505e04:	or     DWORD PTR [r12+0x314],r10d
    7db2f9505e0c:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f9505e12:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f9505e18:	movabs r11,0x5a58c9d345e0
    7db2f9505e22:	mov    rdi,r13
    7db2f9505e25:	mov    rsi,r14
    7db2f9505e28:	mov    rdx,r15
    7db2f9505e2b:	call   r11
    7db2f9505e2e:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f9505e34:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f9505e3c:	mov    QWORD PTR [r12+0x378],0x2
    7db2f9505e48:	jmp    0x7db2f95043be
    7db2f9505e4d:	mov    QWORD PTR [r12+0x378],0x3
    7db2f9505e59:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9505e61:	stmxcsr DWORD PTR [r12-0x28]
    7db2f9505e67:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f9505e6c:	test   r10d,0x3f
    7db2f9505e73:	je     0x7db2f9505e98
    7db2f9505e79:	mov    r11d,r10d
    7db2f9505e7c:	shr    r10d,1
    7db2f9505e7f:	and    r10d,0x1e
    7db2f9505e83:	and    r11d,0x1
    7db2f9505e87:	or     r10d,r11d
    7db2f9505e8a:	or     DWORD PTR [r12+0x314],r10d
    7db2f9505e92:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f9505e98:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f9505e9e:	movabs r11,0x5a58c9d345e0
    7db2f9505ea8:	mov    rdi,r13
    7db2f9505eab:	mov    rsi,r14
    7db2f9505eae:	mov    rdx,r15
    7db2f9505eb1:	call   r11
    7db2f9505eb4:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f9505eba:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f9505ec2:	mov    QWORD PTR [r12+0x378],0x2
    7db2f9505ece:	jmp    0x7db2f950448b
    7db2f9505ed3:	mov    QWORD PTR [r12+0x378],0x3
    7db2f9505edf:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9505ee7:	stmxcsr DWORD PTR [r12-0x28]
    7db2f9505eed:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f9505ef2:	test   r10d,0x3f
    7db2f9505ef9:	je     0x7db2f9505f1e
    7db2f9505eff:	mov    r11d,r10d
    7db2f9505f02:	shr    r10d,1
    7db2f9505f05:	and    r10d,0x1e
    7db2f9505f09:	and    r11d,0x1
    7db2f9505f0d:	or     r10d,r11d
    7db2f9505f10:	or     DWORD PTR [r12+0x314],r10d
    7db2f9505f18:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f9505f1e:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f9505f24:	movabs r11,0x5a58c9d345e0
    7db2f9505f2e:	mov    rdi,r13
    7db2f9505f31:	mov    rsi,r14
    7db2f9505f34:	mov    rdx,r15
    7db2f9505f37:	call   r11
    7db2f9505f3a:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f9505f40:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f9505f48:	mov    QWORD PTR [r12+0x378],0x2
    7db2f9505f54:	jmp    0x7db2f950453f
    7db2f9505f59:	mov    QWORD PTR [r12+0x378],0x3
    7db2f9505f65:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9505f6d:	stmxcsr DWORD PTR [r12-0x28]
    7db2f9505f73:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f9505f78:	test   r10d,0x3f
    7db2f9505f7f:	je     0x7db2f9505fa4
    7db2f9505f85:	mov    r11d,r10d
    7db2f9505f88:	shr    r10d,1
    7db2f9505f8b:	and    r10d,0x1e
    7db2f9505f8f:	and    r11d,0x1
    7db2f9505f93:	or     r10d,r11d
    7db2f9505f96:	or     DWORD PTR [r12+0x314],r10d
    7db2f9505f9e:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f9505fa4:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f9505faa:	movabs r11,0x5a58c9d345e0
    7db2f9505fb4:	mov    rdi,r13
    7db2f9505fb7:	mov    rsi,r14
    7db2f9505fba:	mov    rdx,r15
    7db2f9505fbd:	call   r11
    7db2f9505fc0:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f9505fc6:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f9505fce:	mov    QWORD PTR [r12+0x378],0x2
    7db2f9505fda:	jmp    0x7db2f95045d7
    7db2f9505fdf:	mov    QWORD PTR [r12+0x378],0x3
    7db2f9505feb:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9505ff3:	stmxcsr DWORD PTR [r12-0x28]
    7db2f9505ff9:	mov    r10d,DWORD PTR [r12-0x28]
    7db2f9505ffe:	test   r10d,0x3f
    7db2f9506005:	je     0x7db2f950602a
    7db2f950600b:	mov    r11d,r10d
    7db2f950600e:	shr    r10d,1
    7db2f9506011:	and    r10d,0x1e
    7db2f9506015:	and    r11d,0x1
    7db2f9506019:	or     r10d,r11d
    7db2f950601c:	or     DWORD PTR [r12+0x314],r10d
    7db2f9506024:	and    DWORD PTR [r12-0x28],0xffffffc0
    7db2f950602a:	ldmxcsr DWORD PTR [r12-0x38]
    7db2f9506030:	movabs r11,0x5a58c9d345e0
    7db2f950603a:	mov    rdi,r13
    7db2f950603d:	mov    rsi,r14
    7db2f9506040:	mov    rdx,r15
    7db2f9506043:	call   r11
    7db2f9506046:	ldmxcsr DWORD PTR [r12-0x28]
    7db2f950604c:	mov    rbx,QWORD PTR [r12+0x108]
    7db2f9506054:	mov    QWORD PTR [r12+0x378],0x2
    7db2f9506060:	jmp    0x7db2f950466f
    7db2f9506065:	mov    eax,0x4103f0
    7db2f950606a:	mov    QWORD PTR [r12+0x100],rax
    7db2f9506072:	push   rdx
    7db2f9506073:	push   rsi
    7db2f9506074:	push   r10
    7db2f9506076:	push   r11
    7db2f9506078:	mov    r11,rax
    7db2f950607b:	lahf
    7db2f950607c:	seto   al
    7db2f950607f:	mov    WORD PTR [rsp+0x20],ax
    7db2f9506084:	mov    rax,r11
    7db2f9506087:	mov    rdx,QWORD PTR [rsp+0x20]
    7db2f950608c:	mov    r10d,edx
    7db2f950608f:	and    r10d,0xc000
    7db2f9506096:	shl    r10d,0x10
    7db2f950609a:	mov    r11d,edx
    7db2f950609d:	and    r11d,0x100
    7db2f95060a4:	shl    r11d,0x15
    7db2f95060a8:	or     r10d,r11d
    7db2f95060ab:	and    edx,0x1
    7db2f95060ae:	shl    edx,0x1c
    7db2f95060b1:	or     r10d,edx
    7db2f95060b4:	btc    r10,0x1d
    7db2f95060b9:	mov    r11d,0xf0000000
    7db2f95060bf:	and    r11,r10
    7db2f95060c2:	movabs rsi,0xffffffff0fffffff
    7db2f95060cc:	and    rbx,rsi
    7db2f95060cf:	or     rbx,r11
    7db2f95060d2:	pop    r11
    7db2f95060d4:	pop    r10
    7db2f95060d6:	pop    rsi
    7db2f95060d7:	pop    rdx
    7db2f95060d8:	mov    QWORD PTR [r12+0x108],rbx
    7db2f95060e0:	add    rsp,0x150
    7db2f95060e7:	mov    eax,0xc
    7db2f95060ec:	movabs r11,0x5a58c9ed2ca0
    7db2f95060f6:	jmp    r11
    7db2f95060f9:	mov    eax,0x41047c
    7db2f95060fe:	mov    QWORD PTR [r12+0x100],rax
    7db2f9506106:	push   rdx
    7db2f9506107:	push   rsi
    7db2f9506108:	push   r10
    7db2f950610a:	push   r11
    7db2f950610c:	mov    r11,rax
    7db2f950610f:	lahf
    7db2f9506110:	seto   al
    7db2f9506113:	mov    WORD PTR [rsp+0x20],ax
    7db2f9506118:	mov    rax,r11
    7db2f950611b:	mov    rdx,QWORD PTR [rsp+0x20]
    7db2f9506120:	mov    r10d,edx
    7db2f9506123:	and    r10d,0xc000
    7db2f950612a:	shl    r10d,0x10
    7db2f950612e:	mov    r11d,edx
    7db2f9506131:	and    r11d,0x100
    7db2f9506138:	shl    r11d,0x15
    7db2f950613c:	or     r10d,r11d
    7db2f950613f:	and    edx,0x1
    7db2f9506142:	shl    edx,0x1c
    7db2f9506145:	or     r10d,edx
    7db2f9506148:	btc    r10,0x1d
    7db2f950614d:	mov    r11d,0xf0000000
    7db2f9506153:	and    r11,r10
    7db2f9506156:	movabs rsi,0xffffffff0fffffff
    7db2f9506160:	and    rbx,rsi
    7db2f9506163:	or     rbx,r11
    7db2f9506166:	pop    r11
    7db2f9506168:	pop    r10
    7db2f950616a:	pop    rsi
    7db2f950616b:	pop    rdx
    7db2f950616c:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9506174:	add    rsp,0x150
    7db2f950617b:	mov    eax,0xc
    7db2f9506180:	movabs r11,0x5a58c9ed2ca0
    7db2f950618a:	jmp    r11
    7db2f950618d:	mov    eax,0x410660
    7db2f9506192:	mov    QWORD PTR [r12+0x100],rax
    7db2f950619a:	mov    QWORD PTR [r12+0x108],rbx
    7db2f95061a2:	add    rsp,0x150
    7db2f95061a9:	mov    eax,0xc
    7db2f95061ae:	movabs r11,0x5a58c9ed2ca0
    7db2f95061b8:	jmp    r11
    7db2f95061bb:	mov    eax,0x41066c
    7db2f95061c0:	mov    QWORD PTR [r12+0x100],rax
    7db2f95061c8:	push   rdx
    7db2f95061c9:	push   rsi
    7db2f95061ca:	push   r10
    7db2f95061cc:	push   r11
    7db2f95061ce:	mov    r11,rax
    7db2f95061d1:	lahf
    7db2f95061d2:	seto   al
    7db2f95061d5:	mov    WORD PTR [rsp+0x20],ax
    7db2f95061da:	mov    rax,r11
    7db2f95061dd:	mov    rdx,QWORD PTR [rsp+0x20]
    7db2f95061e2:	mov    r10d,edx
    7db2f95061e5:	and    r10d,0xc000
    7db2f95061ec:	shl    r10d,0x10
    7db2f95061f0:	mov    r11d,edx
    7db2f95061f3:	and    r11d,0x100
    7db2f95061fa:	shl    r11d,0x15
    7db2f95061fe:	or     r10d,r11d
    7db2f9506201:	and    edx,0x1
    7db2f9506204:	shl    edx,0x1c
    7db2f9506207:	or     r10d,edx
    7db2f950620a:	btc    r10,0x1d
    7db2f950620f:	mov    r11d,0xf0000000
    7db2f9506215:	and    r11,r10
    7db2f9506218:	movabs rsi,0xffffffff0fffffff
    7db2f9506222:	and    rbx,rsi
    7db2f9506225:	or     rbx,r11
    7db2f9506228:	pop    r11
    7db2f950622a:	pop    r10
    7db2f950622c:	pop    rsi
    7db2f950622d:	pop    rdx
    7db2f950622e:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9506236:	add    rsp,0x150
    7db2f950623d:	mov    eax,0xc
    7db2f9506242:	movabs r11,0x5a58c9ed2ca0
    7db2f950624c:	jmp    r11
    7db2f950624f:	mov    eax,0x410694
    7db2f9506254:	mov    QWORD PTR [r12+0x100],rax
    7db2f950625c:	push   rdx
    7db2f950625d:	push   rsi
    7db2f950625e:	push   r10
    7db2f9506260:	push   r11
    7db2f9506262:	mov    r11,rax
    7db2f9506265:	lahf
    7db2f9506266:	seto   al
    7db2f9506269:	mov    WORD PTR [rsp+0x20],ax
    7db2f950626e:	mov    rax,r11
    7db2f9506271:	mov    rdx,QWORD PTR [rsp+0x20]
    7db2f9506276:	mov    r10d,edx
    7db2f9506279:	and    r10d,0xc000
    7db2f9506280:	shl    r10d,0x10
    7db2f9506284:	mov    r11d,edx
    7db2f9506287:	and    r11d,0x100
    7db2f950628e:	shl    r11d,0x15
    7db2f9506292:	or     r10d,r11d
    7db2f9506295:	and    edx,0x1
    7db2f9506298:	shl    edx,0x1c
    7db2f950629b:	or     r10d,edx
    7db2f950629e:	btc    r10,0x1d
    7db2f95062a3:	mov    r11d,0xf0000000
    7db2f95062a9:	and    r11,r10
    7db2f95062ac:	movabs rsi,0xffffffff0fffffff
    7db2f95062b6:	and    rbx,rsi
    7db2f95062b9:	or     rbx,r11
    7db2f95062bc:	pop    r11
    7db2f95062be:	pop    r10
    7db2f95062c0:	pop    rsi
    7db2f95062c1:	pop    rdx
    7db2f95062c2:	mov    QWORD PTR [r12+0x108],rbx
    7db2f95062ca:	add    rsp,0x150
    7db2f95062d1:	mov    eax,0xc
    7db2f95062d6:	movabs r11,0x5a58c9ed2ca0
    7db2f95062e0:	jmp    r11
    7db2f95062e3:	mov    eax,0x4106b8
    7db2f95062e8:	mov    QWORD PTR [r12+0x100],rax
    7db2f95062f0:	push   rdx
    7db2f95062f1:	push   rsi
    7db2f95062f2:	push   r10
    7db2f95062f4:	push   r11
    7db2f95062f6:	mov    rdx,QWORD PTR [rsp+0x20]
    7db2f95062fb:	mov    r10d,edx
    7db2f95062fe:	and    r10d,0xc000
    7db2f9506305:	shl    r10d,0x10
    7db2f9506309:	mov    r11d,edx
    7db2f950630c:	and    r11d,0x100
    7db2f9506313:	shl    r11d,0x15
    7db2f9506317:	or     r10d,r11d
    7db2f950631a:	and    edx,0x1
    7db2f950631d:	shl    edx,0x1c
    7db2f9506320:	or     r10d,edx
    7db2f9506323:	btc    r10,0x1d
    7db2f9506328:	mov    r11d,0xf0000000
    7db2f950632e:	and    r11,r10
    7db2f9506331:	movabs rsi,0xffffffff0fffffff
    7db2f950633b:	and    rbx,rsi
    7db2f950633e:	or     rbx,r11
    7db2f9506341:	pop    r11
    7db2f9506343:	pop    r10
    7db2f9506345:	pop    rsi
    7db2f9506346:	pop    rdx
    7db2f9506347:	mov    QWORD PTR [r12+0x108],rbx
    7db2f950634f:	add    rsp,0x150
    7db2f9506356:	mov    eax,0xc
    7db2f950635b:	movabs r11,0x5a58c9ed2ca0
    7db2f9506365:	jmp    r11
    7db2f9506368:	nop    DWORD PTR [rax+rax*1+0x0]
    7db2f9506370:	sub    rsp,0x150
    7db2f9506377:	mov    r11,QWORD PTR [r12+0x398]
    7db2f950637f:	mov    QWORD PTR [rsp],r11
    7db2f9506383:	cmp    DWORD PTR [r12+0x310],0x0
    7db2f950638c:	je     0x7db2f9506417
    7db2f9506392:	push   rdx
    7db2f9506393:	push   rsi
    7db2f9506394:	push   r10
    7db2f9506396:	push   r11
    7db2f9506398:	mov    rdx,QWORD PTR [rsp+0x20]
    7db2f950639d:	mov    r10d,edx
    7db2f95063a0:	and    r10d,0xc000
    7db2f95063a7:	shl    r10d,0x10
    7db2f95063ab:	mov    r11d,edx
    7db2f95063ae:	and    r11d,0x100
    7db2f95063b5:	shl    r11d,0x15
    7db2f95063b9:	or     r10d,r11d
    7db2f95063bc:	and    edx,0x1
    7db2f95063bf:	shl    edx,0x1c
    7db2f95063c2:	or     r10d,edx
    7db2f95063c5:	btc    r10,0x1d
    7db2f95063ca:	mov    r11d,0xf0000000
    7db2f95063d0:	and    r11,r10
    7db2f95063d3:	movabs rsi,0xffffffff0fffffff
    7db2f95063dd:	and    rbx,rsi
    7db2f95063e0:	or     rbx,r11
    7db2f95063e3:	pop    r11
    7db2f95063e5:	pop    r10
    7db2f95063e7:	pop    rsi
    7db2f95063e8:	pop    rdx
    7db2f95063e9:	mov    QWORD PTR [r12+0x108],rbx
    7db2f95063f1:	mov    eax,0x4103f4
    7db2f95063f6:	mov    QWORD PTR [r12+0x100],rax
    7db2f95063fe:	add    rsp,0x150
    7db2f9506405:	mov    eax,0x3
    7db2f950640a:	movabs r11,0x5a58c9ed2ca0
    7db2f9506414:	jmp    r11
    7db2f9506417:	jmp    0x7db2f950225d
    7db2f950641c:	nop    DWORD PTR [rax+0x0]
    7db2f9506420:	sub    rsp,0x150
    7db2f9506427:	mov    r11,QWORD PTR [r12+0x398]
    7db2f950642f:	mov    QWORD PTR [rsp],r11
    7db2f9506433:	cmp    DWORD PTR [r12+0x310],0x0
    7db2f950643c:	je     0x7db2f95064c7
    7db2f9506442:	push   rdx
    7db2f9506443:	push   rsi
    7db2f9506444:	push   r10
    7db2f9506446:	push   r11
    7db2f9506448:	mov    rdx,QWORD PTR [rsp+0x20]
    7db2f950644d:	mov    r10d,edx
    7db2f9506450:	and    r10d,0xc000
    7db2f9506457:	shl    r10d,0x10
    7db2f950645b:	mov    r11d,edx
    7db2f950645e:	and    r11d,0x100
    7db2f9506465:	shl    r11d,0x15
    7db2f9506469:	or     r10d,r11d
    7db2f950646c:	and    edx,0x1
    7db2f950646f:	shl    edx,0x1c
    7db2f9506472:	or     r10d,edx
    7db2f9506475:	btc    r10,0x1d
    7db2f950647a:	mov    r11d,0xf0000000
    7db2f9506480:	and    r11,r10
    7db2f9506483:	movabs rsi,0xffffffff0fffffff
    7db2f950648d:	and    rbx,rsi
    7db2f9506490:	or     rbx,r11
    7db2f9506493:	pop    r11
    7db2f9506495:	pop    r10
    7db2f9506497:	pop    rsi
    7db2f9506498:	pop    rdx
    7db2f9506499:	mov    QWORD PTR [r12+0x108],rbx
    7db2f95064a1:	mov    eax,0x410440
    7db2f95064a6:	mov    QWORD PTR [r12+0x100],rax
    7db2f95064ae:	add    rsp,0x150
    7db2f95064b5:	mov    eax,0x3
    7db2f95064ba:	movabs r11,0x5a58c9ed2ca0
    7db2f95064c4:	jmp    r11
    7db2f95064c7:	mov    r11,rax
    7db2f95064ca:	movzx  eax,WORD PTR [rsp]
    7db2f95064ce:	add    al,0x7f
    7db2f95064d0:	sahf
    7db2f95064d1:	mov    rax,r11
    7db2f95064d4:	jmp    0x7db2f95023d4
    7db2f95064d9:	nop    DWORD PTR [rax+0x0]
    7db2f95064e0:	sub    rsp,0x150
    7db2f95064e7:	mov    r11,QWORD PTR [r12+0x398]
    7db2f95064ef:	mov    QWORD PTR [rsp],r11
    7db2f95064f3:	cmp    DWORD PTR [r12+0x310],0x0
    7db2f95064fc:	je     0x7db2f9506587
    7db2f9506502:	push   rdx
    7db2f9506503:	push   rsi
    7db2f9506504:	push   r10
    7db2f9506506:	push   r11
    7db2f9506508:	mov    rdx,QWORD PTR [rsp+0x20]
    7db2f950650d:	mov    r10d,edx
    7db2f9506510:	and    r10d,0xc000
    7db2f9506517:	shl    r10d,0x10
    7db2f950651b:	mov    r11d,edx
    7db2f950651e:	and    r11d,0x100
    7db2f9506525:	shl    r11d,0x15
    7db2f9506529:	or     r10d,r11d
    7db2f950652c:	and    edx,0x1
    7db2f950652f:	shl    edx,0x1c
    7db2f9506532:	or     r10d,edx
    7db2f9506535:	btc    r10,0x1d
    7db2f950653a:	mov    r11d,0xf0000000
    7db2f9506540:	and    r11,r10
    7db2f9506543:	movabs rsi,0xffffffff0fffffff
    7db2f950654d:	and    rbx,rsi
    7db2f9506550:	or     rbx,r11
    7db2f9506553:	pop    r11
    7db2f9506555:	pop    r10
    7db2f9506557:	pop    rsi
    7db2f9506558:	pop    rdx
    7db2f9506559:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9506561:	mov    eax,0x410480
    7db2f9506566:	mov    QWORD PTR [r12+0x100],rax
    7db2f950656e:	add    rsp,0x150
    7db2f9506575:	mov    eax,0x3
    7db2f950657a:	movabs r11,0x5a58c9ed2ca0
    7db2f9506584:	jmp    r11
    7db2f9506587:	jmp    0x7db2f9502822
    7db2f950658c:	nop    DWORD PTR [rax+0x0]
    7db2f9506590:	sub    rsp,0x150
    7db2f9506597:	mov    r11,QWORD PTR [r12+0x398]
    7db2f950659f:	mov    QWORD PTR [rsp],r11
    7db2f95065a3:	cmp    DWORD PTR [r12+0x310],0x0
    7db2f95065ac:	je     0x7db2f9506637
    7db2f95065b2:	push   rdx
    7db2f95065b3:	push   rsi
    7db2f95065b4:	push   r10
    7db2f95065b6:	push   r11
    7db2f95065b8:	mov    rdx,QWORD PTR [rsp+0x20]
    7db2f95065bd:	mov    r10d,edx
    7db2f95065c0:	and    r10d,0xc000
    7db2f95065c7:	shl    r10d,0x10
    7db2f95065cb:	mov    r11d,edx
    7db2f95065ce:	and    r11d,0x100
    7db2f95065d5:	shl    r11d,0x15
    7db2f95065d9:	or     r10d,r11d
    7db2f95065dc:	and    edx,0x1
    7db2f95065df:	shl    edx,0x1c
    7db2f95065e2:	or     r10d,edx
    7db2f95065e5:	btc    r10,0x1d
    7db2f95065ea:	mov    r11d,0xf0000000
    7db2f95065f0:	and    r11,r10
    7db2f95065f3:	movabs rsi,0xffffffff0fffffff
    7db2f95065fd:	and    rbx,rsi
    7db2f9506600:	or     rbx,r11
    7db2f9506603:	pop    r11
    7db2f9506605:	pop    r10
    7db2f9506607:	pop    rsi
    7db2f9506608:	pop    rdx
    7db2f9506609:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9506611:	mov    eax,0x4104ec
    7db2f9506616:	mov    QWORD PTR [r12+0x100],rax
    7db2f950661e:	add    rsp,0x150
    7db2f9506625:	mov    eax,0x3
    7db2f950662a:	movabs r11,0x5a58c9ed2ca0
    7db2f9506634:	jmp    r11
    7db2f9506637:	mov    r11,rax
    7db2f950663a:	movzx  eax,WORD PTR [rsp]
    7db2f950663e:	add    al,0x7f
    7db2f9506640:	sahf
    7db2f9506641:	mov    rax,r11
    7db2f9506644:	jmp    0x7db2f9502be4
    7db2f9506649:	nop    DWORD PTR [rax+0x0]
    7db2f9506650:	sub    rsp,0x150
    7db2f9506657:	mov    r11,QWORD PTR [r12+0x398]
    7db2f950665f:	mov    QWORD PTR [rsp],r11
    7db2f9506663:	cmp    DWORD PTR [r12+0x310],0x0
    7db2f950666c:	je     0x7db2f95066f7
    7db2f9506672:	push   rdx
    7db2f9506673:	push   rsi
    7db2f9506674:	push   r10
    7db2f9506676:	push   r11
    7db2f9506678:	mov    rdx,QWORD PTR [rsp+0x20]
    7db2f950667d:	mov    r10d,edx
    7db2f9506680:	and    r10d,0xc000
    7db2f9506687:	shl    r10d,0x10
    7db2f950668b:	mov    r11d,edx
    7db2f950668e:	and    r11d,0x100
    7db2f9506695:	shl    r11d,0x15
    7db2f9506699:	or     r10d,r11d
    7db2f950669c:	and    edx,0x1
    7db2f950669f:	shl    edx,0x1c
    7db2f95066a2:	or     r10d,edx
    7db2f95066a5:	btc    r10,0x1d
    7db2f95066aa:	mov    r11d,0xf0000000
    7db2f95066b0:	and    r11,r10
    7db2f95066b3:	movabs rsi,0xffffffff0fffffff
    7db2f95066bd:	and    rbx,rsi
    7db2f95066c0:	or     rbx,r11
    7db2f95066c3:	pop    r11
    7db2f95066c5:	pop    r10
    7db2f95066c7:	pop    rsi
    7db2f95066c8:	pop    rdx
    7db2f95066c9:	mov    QWORD PTR [r12+0x108],rbx
    7db2f95066d1:	mov    eax,0x4104f0
    7db2f95066d6:	mov    QWORD PTR [r12+0x100],rax
    7db2f95066de:	add    rsp,0x150
    7db2f95066e5:	mov    eax,0x3
    7db2f95066ea:	movabs r11,0x5a58c9ed2ca0
    7db2f95066f4:	jmp    r11
    7db2f95066f7:	jmp    0x7db2f9502c02
    7db2f95066fc:	nop    DWORD PTR [rax+0x0]
    7db2f9506700:	sub    rsp,0x150
    7db2f9506707:	mov    r11,QWORD PTR [r12+0x398]
    7db2f950670f:	mov    QWORD PTR [rsp],r11
    7db2f9506713:	cmp    DWORD PTR [r12+0x310],0x0
    7db2f950671c:	je     0x7db2f95067a7
    7db2f9506722:	push   rdx
    7db2f9506723:	push   rsi
    7db2f9506724:	push   r10
    7db2f9506726:	push   r11
    7db2f9506728:	mov    rdx,QWORD PTR [rsp+0x20]
    7db2f950672d:	mov    r10d,edx
    7db2f9506730:	and    r10d,0xc000
    7db2f9506737:	shl    r10d,0x10
    7db2f950673b:	mov    r11d,edx
    7db2f950673e:	and    r11d,0x100
    7db2f9506745:	shl    r11d,0x15
    7db2f9506749:	or     r10d,r11d
    7db2f950674c:	and    edx,0x1
    7db2f950674f:	shl    edx,0x1c
    7db2f9506752:	or     r10d,edx
    7db2f9506755:	btc    r10,0x1d
    7db2f950675a:	mov    r11d,0xf0000000
    7db2f9506760:	and    r11,r10
    7db2f9506763:	movabs rsi,0xffffffff0fffffff
    7db2f950676d:	and    rbx,rsi
    7db2f9506770:	or     rbx,r11
    7db2f9506773:	pop    r11
    7db2f9506775:	pop    r10
    7db2f9506777:	pop    rsi
    7db2f9506778:	pop    rdx
    7db2f9506779:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9506781:	mov    eax,0x410664
    7db2f9506786:	mov    QWORD PTR [r12+0x100],rax
    7db2f950678e:	add    rsp,0x150
    7db2f9506795:	mov    eax,0x3
    7db2f950679a:	movabs r11,0x5a58c9ed2ca0
    7db2f95067a4:	jmp    r11
    7db2f95067a7:	jmp    0x7db2f950472f
    7db2f95067ac:	nop    DWORD PTR [rax+0x0]
    7db2f95067b0:	sub    rsp,0x150
    7db2f95067b7:	mov    r11,QWORD PTR [r12+0x398]
    7db2f95067bf:	mov    QWORD PTR [rsp],r11
    7db2f95067c3:	cmp    DWORD PTR [r12+0x310],0x0
    7db2f95067cc:	je     0x7db2f9506857
    7db2f95067d2:	push   rdx
    7db2f95067d3:	push   rsi
    7db2f95067d4:	push   r10
    7db2f95067d6:	push   r11
    7db2f95067d8:	mov    rdx,QWORD PTR [rsp+0x20]
    7db2f95067dd:	mov    r10d,edx
    7db2f95067e0:	and    r10d,0xc000
    7db2f95067e7:	shl    r10d,0x10
    7db2f95067eb:	mov    r11d,edx
    7db2f95067ee:	and    r11d,0x100
    7db2f95067f5:	shl    r11d,0x15
    7db2f95067f9:	or     r10d,r11d
    7db2f95067fc:	and    edx,0x1
    7db2f95067ff:	shl    edx,0x1c
    7db2f9506802:	or     r10d,edx
    7db2f9506805:	btc    r10,0x1d
    7db2f950680a:	mov    r11d,0xf0000000
    7db2f9506810:	and    r11,r10
    7db2f9506813:	movabs rsi,0xffffffff0fffffff
    7db2f950681d:	and    rbx,rsi
    7db2f9506820:	or     rbx,r11
    7db2f9506823:	pop    r11
    7db2f9506825:	pop    r10
    7db2f9506827:	pop    rsi
    7db2f9506828:	pop    rdx
    7db2f9506829:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9506831:	mov    eax,0x410670
    7db2f9506836:	mov    QWORD PTR [r12+0x100],rax
    7db2f950683e:	add    rsp,0x150
    7db2f9506845:	mov    eax,0x3
    7db2f950684a:	movabs r11,0x5a58c9ed2ca0
    7db2f9506854:	jmp    r11
    7db2f9506857:	jmp    0x7db2f950476c
    7db2f950685c:	nop    DWORD PTR [rax+0x0]
    7db2f9506860:	sub    rsp,0x150
    7db2f9506867:	mov    r11,QWORD PTR [r12+0x398]
    7db2f950686f:	mov    QWORD PTR [rsp],r11
    7db2f9506873:	cmp    DWORD PTR [r12+0x310],0x0
    7db2f950687c:	je     0x7db2f9506907
    7db2f9506882:	push   rdx
    7db2f9506883:	push   rsi
    7db2f9506884:	push   r10
    7db2f9506886:	push   r11
    7db2f9506888:	mov    rdx,QWORD PTR [rsp+0x20]
    7db2f950688d:	mov    r10d,edx
    7db2f9506890:	and    r10d,0xc000
    7db2f9506897:	shl    r10d,0x10
    7db2f950689b:	mov    r11d,edx
    7db2f950689e:	and    r11d,0x100
    7db2f95068a5:	shl    r11d,0x15
    7db2f95068a9:	or     r10d,r11d
    7db2f95068ac:	and    edx,0x1
    7db2f95068af:	shl    edx,0x1c
    7db2f95068b2:	or     r10d,edx
    7db2f95068b5:	btc    r10,0x1d
    7db2f95068ba:	mov    r11d,0xf0000000
    7db2f95068c0:	and    r11,r10
    7db2f95068c3:	movabs rsi,0xffffffff0fffffff
    7db2f95068cd:	and    rbx,rsi
    7db2f95068d0:	or     rbx,r11
    7db2f95068d3:	pop    r11
    7db2f95068d5:	pop    r10
    7db2f95068d7:	pop    rsi
    7db2f95068d8:	pop    rdx
    7db2f95068d9:	mov    QWORD PTR [r12+0x108],rbx
    7db2f95068e1:	mov    eax,0x41067c
    7db2f95068e6:	mov    QWORD PTR [r12+0x100],rax
    7db2f95068ee:	add    rsp,0x150
    7db2f95068f5:	mov    eax,0x3
    7db2f95068fa:	movabs r11,0x5a58c9ed2ca0
    7db2f9506904:	jmp    r11
    7db2f9506907:	jmp    0x7db2f95047a7
    7db2f950690c:	nop    DWORD PTR [rax+0x0]
    7db2f9506910:	sub    rsp,0x150
    7db2f9506917:	mov    r11,QWORD PTR [r12+0x398]
    7db2f950691f:	mov    QWORD PTR [rsp],r11
    7db2f9506923:	cmp    DWORD PTR [r12+0x310],0x0
    7db2f950692c:	je     0x7db2f95069b7
    7db2f9506932:	push   rdx
    7db2f9506933:	push   rsi
    7db2f9506934:	push   r10
    7db2f9506936:	push   r11
    7db2f9506938:	mov    rdx,QWORD PTR [rsp+0x20]
    7db2f950693d:	mov    r10d,edx
    7db2f9506940:	and    r10d,0xc000
    7db2f9506947:	shl    r10d,0x10
    7db2f950694b:	mov    r11d,edx
    7db2f950694e:	and    r11d,0x100
    7db2f9506955:	shl    r11d,0x15
    7db2f9506959:	or     r10d,r11d
    7db2f950695c:	and    edx,0x1
    7db2f950695f:	shl    edx,0x1c
    7db2f9506962:	or     r10d,edx
    7db2f9506965:	btc    r10,0x1d
    7db2f950696a:	mov    r11d,0xf0000000
    7db2f9506970:	and    r11,r10
    7db2f9506973:	movabs rsi,0xffffffff0fffffff
    7db2f950697d:	and    rbx,rsi
    7db2f9506980:	or     rbx,r11
    7db2f9506983:	pop    r11
    7db2f9506985:	pop    r10
    7db2f9506987:	pop    rsi
    7db2f9506988:	pop    rdx
    7db2f9506989:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9506991:	mov    eax,0x410698
    7db2f9506996:	mov    QWORD PTR [r12+0x100],rax
    7db2f950699e:	add    rsp,0x150
    7db2f95069a5:	mov    eax,0x3
    7db2f95069aa:	movabs r11,0x5a58c9ed2ca0
    7db2f95069b4:	jmp    r11
    7db2f95069b7:	jmp    0x7db2f9504900
    7db2f95069bc:	nop    DWORD PTR [rax+0x0]
    7db2f95069c0:	sub    rsp,0x150
    7db2f95069c7:	mov    r11,QWORD PTR [r12+0x398]
    7db2f95069cf:	mov    QWORD PTR [rsp],r11
    7db2f95069d3:	cmp    DWORD PTR [r12+0x310],0x0
    7db2f95069dc:	je     0x7db2f9506a67
    7db2f95069e2:	push   rdx
    7db2f95069e3:	push   rsi
    7db2f95069e4:	push   r10
    7db2f95069e6:	push   r11
    7db2f95069e8:	mov    rdx,QWORD PTR [rsp+0x20]
    7db2f95069ed:	mov    r10d,edx
    7db2f95069f0:	and    r10d,0xc000
    7db2f95069f7:	shl    r10d,0x10
    7db2f95069fb:	mov    r11d,edx
    7db2f95069fe:	and    r11d,0x100
    7db2f9506a05:	shl    r11d,0x15
    7db2f9506a09:	or     r10d,r11d
    7db2f9506a0c:	and    edx,0x1
    7db2f9506a0f:	shl    edx,0x1c
    7db2f9506a12:	or     r10d,edx
    7db2f9506a15:	btc    r10,0x1d
    7db2f9506a1a:	mov    r11d,0xf0000000
    7db2f9506a20:	and    r11,r10
    7db2f9506a23:	movabs rsi,0xffffffff0fffffff
    7db2f9506a2d:	and    rbx,rsi
    7db2f9506a30:	or     rbx,r11
    7db2f9506a33:	pop    r11
    7db2f9506a35:	pop    r10
    7db2f9506a37:	pop    rsi
    7db2f9506a38:	pop    rdx
    7db2f9506a39:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9506a41:	mov    eax,0x4103e0
    7db2f9506a46:	mov    QWORD PTR [r12+0x100],rax
    7db2f9506a4e:	add    rsp,0x150
    7db2f9506a55:	mov    eax,0x3
    7db2f9506a5a:	movabs r11,0x5a58c9ed2ca0
    7db2f9506a64:	jmp    r11
    7db2f9506a67:	jmp    0x7db2f9504add
    7db2f9506a6c:	nop    DWORD PTR [rax+0x0]
    7db2f9506a70:	(bad)
    7db2f9506a71:	(bad)
    7db2f9506a72:	(bad)
    7db2f9506a73:	(bad)
    7db2f9506a74:	(bad)
    7db2f9506a75:	(bad)
    7db2f9506a76:	(bad)
    7db2f9506a77:	jg     0x7db2f9506a78
    7db2f9506a79:	(bad)
    7db2f9506a7a:	(bad)
    7db2f9506a7b:	(bad)
    7db2f9506a7c:	(bad)
    7db2f9506a7d:	(bad)
    7db2f9506a7e:	(bad)
    7db2f9506a7f:	jg     0x7db2f9506a81
    7db2f9506a81:	add    BYTE PTR [rax],al
    7db2f9506a83:	add    BYTE PTR [rax],al
    7db2f9506a85:	add    BYTE PTR [rax],dl
    7db2f9506a87:	add    BYTE PTR [rax],al
    7db2f9506a89:	add    BYTE PTR [rax],al
    7db2f9506a8b:	add    BYTE PTR [rax],al
    7db2f9506a8d:	add    BYTE PTR [rax],dl
	...
