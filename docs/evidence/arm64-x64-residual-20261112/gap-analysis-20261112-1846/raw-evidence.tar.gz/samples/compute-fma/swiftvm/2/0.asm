
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/2/0.bin:     file format binary


Disassembly of section .data:

00007db2f94fe000 <.data>:
    7db2f94fe000:	sub    rsp,0x10
    7db2f94fe004:	mov    r11,QWORD PTR [r12+0x398]
    7db2f94fe00c:	mov    QWORD PTR [rsp],r11
    7db2f94fe010:	mov    r13,QWORD PTR [r12+0xf8]
    7db2f94fe018:	sub    r13,0x1b0
    7db2f94fe01f:	mov    QWORD PTR [r12+0xf8],r13
    7db2f94fe027:	mov    r14d,0x420000
    7db2f94fe02d:	mov    QWORD PTR [r12+0x40],r14
    7db2f94fe032:	mov    r14d,0x420000
    7db2f94fe038:	mov    QWORD PTR [r12+0x48],r14
    7db2f94fe03d:	mov    r14,r13
    7db2f94fe040:	add    r14,0x1a0
    7db2f94fe047:	mov    r15,r14
    7db2f94fe04a:	add    r15,0x8
    7db2f94fe04e:	mov    rbp,QWORD PTR [r12+0xa0]
    7db2f94fe056:	mov    r8,QWORD PTR [r12+0x98]
    7db2f94fe05e:	mov    QWORD PTR [r14],rbp
    7db2f94fe061:	mov    r14d,0x0
    7db2f94fe067:	mov    DWORD PTR [r12+0x32c],r14d
    7db2f94fe06f:	mov    QWORD PTR [r15],r8
    7db2f94fe072:	mov    r14d,0x420a30
    7db2f94fe078:	movdqu xmm2,XMMWORD PTR [r14]
    7db2f94fe07d:	movdqu XMMWORD PTR [r12+0x110],xmm2
    7db2f94fe087:	mov    r14d,0x4209c0
    7db2f94fe08d:	movdqu xmm3,XMMWORD PTR [r14]
    7db2f94fe092:	movdqu XMMWORD PTR [r12+0x120],xmm3
    7db2f94fe09c:	mov    r14d,0x420a50
    7db2f94fe0a2:	movdqu xmm4,XMMWORD PTR [r14]
    7db2f94fe0a7:	movdqu XMMWORD PTR [r12+0x130],xmm4
    7db2f94fe0b1:	mov    r14d,0x4209f0
    7db2f94fe0b7:	movdqu xmm5,XMMWORD PTR [r14]
    7db2f94fe0bc:	movdqu XMMWORD PTR [r12+0x140],xmm5
    7db2f94fe0c6:	mov    r14d,0x430000
    7db2f94fe0cc:	mov    rax,r14
    7db2f94fe0cf:	add    rax,0xc60
    7db2f94fe0d5:	mov    QWORD PTR [r12+0x98],rax
    7db2f94fe0dd:	mov    r15d,0x420a60
    7db2f94fe0e3:	movdqu xmm6,XMMWORD PTR [r15]
    7db2f94fe0e8:	movdqu XMMWORD PTR [r12+0x150],xmm6
    7db2f94fe0f2:	mov    r15,QWORD PTR [r12+0x98]
    7db2f94fe0fa:	add    r15,0x10
    7db2f94fe0fe:	mov    rdi,QWORD PTR [r12+0x98]
    7db2f94fe106:	movdqu XMMWORD PTR [rdi],xmm2
    7db2f94fe10a:	movdqu XMMWORD PTR [r15],xmm3
    7db2f94fe10f:	mov    r15,QWORD PTR [r12+0x98]
    7db2f94fe117:	add    r15,0x20
    7db2f94fe11b:	mov    rbp,r15
    7db2f94fe11e:	add    rbp,0x10
    7db2f94fe122:	movdqu XMMWORD PTR [r15],xmm4
    7db2f94fe127:	movdqu XMMWORD PTR [rbp+0x0],xmm5
    7db2f94fe12c:	mov    r15d,0x4209b0
    7db2f94fe132:	movdqu xmm4,XMMWORD PTR [r15]
    7db2f94fe137:	movdqu XMMWORD PTR [r12+0x130],xmm4
    7db2f94fe141:	mov    r15d,0x4209a0
    7db2f94fe147:	movdqu xmm5,XMMWORD PTR [r15]
    7db2f94fe14c:	movdqu XMMWORD PTR [r12+0x140],xmm5
    7db2f94fe156:	mov    r15,QWORD PTR [r12+0x98]
    7db2f94fe15e:	add    r15,0x100
    7db2f94fe165:	mov    rbp,r15
    7db2f94fe168:	add    rbp,0x10
    7db2f94fe16c:	movdqu XMMWORD PTR [r15],xmm2
    7db2f94fe171:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    7db2f94fe176:	mov    r15,QWORD PTR [r12+0x98]
    7db2f94fe17e:	add    r15,0x40
    7db2f94fe182:	mov    rbp,r15
    7db2f94fe185:	add    rbp,0x10
    7db2f94fe189:	movdqu XMMWORD PTR [r15],xmm6
    7db2f94fe18e:	movdqu XMMWORD PTR [rbp+0x0],xmm4
    7db2f94fe193:	mov    r15d,0x420990
    7db2f94fe199:	movdqu xmm2,XMMWORD PTR [r15]
    7db2f94fe19e:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7db2f94fe1a8:	mov    r15d,0x420a00
    7db2f94fe1ae:	movdqu xmm3,XMMWORD PTR [r15]
    7db2f94fe1b3:	movdqu XMMWORD PTR [r12+0x150],xmm3
    7db2f94fe1bd:	mov    r15d,0xf8d3
    7db2f94fe1c3:	mov    QWORD PTR [r12+0x48],r15
    7db2f94fe1c8:	mov    r15,QWORD PTR [r12+0x98]
    7db2f94fe1d0:	add    r15,0x60
    7db2f94fe1d4:	mov    rbp,r15
    7db2f94fe1d7:	add    rbp,0x10
    7db2f94fe1db:	movdqu XMMWORD PTR [r15],xmm5
    7db2f94fe1e0:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7db2f94fe1e5:	mov    r15d,0x420a10
    7db2f94fe1eb:	movdqu xmm2,XMMWORD PTR [r15]
    7db2f94fe1f0:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7db2f94fe1fa:	mov    r15d,0x4209e0
    7db2f94fe200:	movdqu xmm4,XMMWORD PTR [r15]
    7db2f94fe205:	movdqu XMMWORD PTR [r12+0x140],xmm4
    7db2f94fe20f:	mov    r15d,0xf8d3
    7db2f94fe215:	mov    ebp,0x421d
    7db2f94fe21a:	and    ebp,0xffff
    7db2f94fe220:	mov    rax,r15
    7db2f94fe223:	movabs rcx,0xffffffff0000ffff
    7db2f94fe22d:	and    rax,rcx
    7db2f94fe230:	mov    rdx,rbp
    7db2f94fe233:	shl    rdx,0x10
    7db2f94fe237:	mov    ecx,0xffff0000
    7db2f94fe23c:	and    rdx,rcx
    7db2f94fe23f:	or     rax,rdx
    7db2f94fe242:	mov    r8d,eax
    7db2f94fe245:	mov    QWORD PTR [r12+0x48],r8
    7db2f94fe24a:	mov    r15,QWORD PTR [r12+0x98]
    7db2f94fe252:	add    r15,0x80
    7db2f94fe259:	mov    rbp,r15
    7db2f94fe25c:	add    rbp,0x10
    7db2f94fe260:	movdqu XMMWORD PTR [r15],xmm3
    7db2f94fe265:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7db2f94fe26a:	mov    r15d,0x420a80
    7db2f94fe270:	movdqu xmm2,XMMWORD PTR [r15]
    7db2f94fe275:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7db2f94fe27f:	mov    r15d,0x420a90
    7db2f94fe285:	movdqu xmm3,XMMWORD PTR [r15]
    7db2f94fe28a:	movdqu XMMWORD PTR [r12+0x150],xmm3
    7db2f94fe294:	mov    r15d,0x3e8
    7db2f94fe29a:	mov    QWORD PTR [r12+0xa0],r15
    7db2f94fe2a2:	mov    r15,QWORD PTR [r12+0x98]
    7db2f94fe2aa:	add    r15,0xa0
    7db2f94fe2b1:	mov    rbp,r15
    7db2f94fe2b4:	add    rbp,0x10
    7db2f94fe2b8:	movdqu XMMWORD PTR [r15],xmm4
    7db2f94fe2bd:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7db2f94fe2c2:	mov    r15d,0x420a70
    7db2f94fe2c8:	movdqu xmm2,XMMWORD PTR [r15]
    7db2f94fe2cd:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7db2f94fe2d7:	mov    r15d,0x420a20
    7db2f94fe2dd:	movdqu xmm4,XMMWORD PTR [r15]
    7db2f94fe2e2:	movdqu XMMWORD PTR [r12+0x140],xmm4
    7db2f94fe2ec:	mov    r15,r13
    7db2f94fe2ef:	add    r15,0x150
    7db2f94fe2f6:	mov    rbp,r15
    7db2f94fe2f9:	add    rbp,0x8
    7db2f94fe2fd:	mov    r9,QWORD PTR [r12+0x200]
    7db2f94fe305:	mov    r14,QWORD PTR [r12+0x1f0]
    7db2f94fe30d:	mov    QWORD PTR [r15],r9
    7db2f94fe310:	mov    QWORD PTR [rbp+0x0],r14
    7db2f94fe314:	mov    r14,QWORD PTR [r12+0x98]
    7db2f94fe31c:	add    r14,0xc0
    7db2f94fe323:	mov    r15,r14
    7db2f94fe326:	add    r15,0x10
    7db2f94fe32a:	movdqu XMMWORD PTR [r14],xmm3
    7db2f94fe32f:	movdqu XMMWORD PTR [r15],xmm2
    7db2f94fe334:	mov    r14d,0x420a40
    7db2f94fe33a:	movdqu xmm2,XMMWORD PTR [r14]
    7db2f94fe33f:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7db2f94fe349:	mov    r14d,0x420aa8
    7db2f94fe34f:	mov    r15,QWORD PTR [r14]
    7db2f94fe352:	mov    r14d,0x0
    7db2f94fe358:	mov    QWORD PTR [r12+0x110],r15
    7db2f94fe360:	mov    QWORD PTR [r12+0x118],r14
    7db2f94fe368:	mov    r14d,0x420ab0
    7db2f94fe36e:	mov    QWORD PTR [r12+0x40],r14
    7db2f94fe373:	mov    r14,QWORD PTR [r12+0x98]
    7db2f94fe37b:	add    r14,0xe0
    7db2f94fe382:	mov    rbp,r14
    7db2f94fe385:	add    rbp,0x10
    7db2f94fe389:	movdqu XMMWORD PTR [r14],xmm4
    7db2f94fe38e:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7db2f94fe393:	mov    r14d,0x420b10
    7db2f94fe399:	movdqu xmm2,XMMWORD PTR [r14]
    7db2f94fe39e:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7db2f94fe3a8:	mov    r14,QWORD PTR [r12+0x98]
    7db2f94fe3b0:	add    r14,0x120
    7db2f94fe3b7:	mov    QWORD PTR [r14],r15
    7db2f94fe3ba:	mov    r14d,0x420af0
    7db2f94fe3c0:	mov    r15d,0x420b00
    7db2f94fe3c6:	movdqu xmm3,XMMWORD PTR [r14]
    7db2f94fe3cb:	movdqu xmm4,XMMWORD PTR [r15]
    7db2f94fe3d0:	movdqu XMMWORD PTR [r12+0x120],xmm3
    7db2f94fe3da:	movdqu XMMWORD PTR [r12+0x110],xmm4
    7db2f94fe3e4:	mov    r14,r13
    7db2f94fe3e7:	add    r14,0x130
    7db2f94fe3ee:	movdqu XMMWORD PTR [r14],xmm2
    7db2f94fe3f3:	mov    r14,r13
    7db2f94fe3f6:	add    r14,0x160
    7db2f94fe3fd:	mov    r15,r14
    7db2f94fe400:	add    r15,0x8
    7db2f94fe404:	mov    rbp,QWORD PTR [r12+0x1e0]
    7db2f94fe40c:	mov    r9,QWORD PTR [r12+0x1d0]
    7db2f94fe414:	mov    QWORD PTR [r14],rbp
    7db2f94fe417:	mov    QWORD PTR [r15],r9
    7db2f94fe41a:	mov    r14,r13
    7db2f94fe41d:	add    r14,0x110
    7db2f94fe424:	mov    r15,r14
    7db2f94fe427:	add    r15,0x10
    7db2f94fe42b:	movdqu XMMWORD PTR [r14],xmm3
    7db2f94fe430:	movdqu XMMWORD PTR [r15],xmm4
    7db2f94fe435:	mov    r14d,0x420ab0
    7db2f94fe43b:	mov    r15d,0x420ac0
    7db2f94fe441:	movdqu xmm2,XMMWORD PTR [r14]
    7db2f94fe446:	movdqu xmm3,XMMWORD PTR [r15]
    7db2f94fe44b:	movdqu XMMWORD PTR [r12+0x110],xmm2
    7db2f94fe455:	movdqu XMMWORD PTR [r12+0x120],xmm3
    7db2f94fe45f:	mov    r14,r13
    7db2f94fe462:	add    r14,0x170
    7db2f94fe469:	mov    r15,r14
    7db2f94fe46c:	add    r15,0x8
    7db2f94fe470:	mov    rbp,QWORD PTR [r12+0x1c0]
    7db2f94fe478:	mov    r9,QWORD PTR [r12+0x1b0]
    7db2f94fe480:	mov    QWORD PTR [r14],rbp
    7db2f94fe483:	mov    QWORD PTR [r15],r9
    7db2f94fe486:	mov    r14,r13
    7db2f94fe489:	add    r14,0x180
    7db2f94fe490:	mov    r15,r14
    7db2f94fe493:	add    r15,0x8
    7db2f94fe497:	mov    rbp,QWORD PTR [r12+0x1a0]
    7db2f94fe49f:	mov    r9,QWORD PTR [r12+0x190]
    7db2f94fe4a7:	mov    QWORD PTR [r14],rbp
    7db2f94fe4aa:	mov    QWORD PTR [r15],r9
    7db2f94fe4ad:	mov    r14,r13
    7db2f94fe4b0:	add    r14,0xd0
    7db2f94fe4b7:	mov    r15,r14
    7db2f94fe4ba:	add    r15,0x10
    7db2f94fe4be:	movdqu XMMWORD PTR [r14],xmm2
    7db2f94fe4c3:	movdqu XMMWORD PTR [r15],xmm3
    7db2f94fe4c8:	mov    r14d,0x420ad0
    7db2f94fe4ce:	mov    r15d,0x420ae0
    7db2f94fe4d4:	movdqu xmm2,XMMWORD PTR [r14]
    7db2f94fe4d9:	movdqu xmm3,XMMWORD PTR [r15]
    7db2f94fe4de:	movdqu XMMWORD PTR [r12+0x110],xmm2
    7db2f94fe4e8:	movdqu XMMWORD PTR [r12+0x130],xmm3
    7db2f94fe4f2:	mov    r14,r13
    7db2f94fe4f5:	add    r14,0x190
    7db2f94fe4fc:	mov    r15,r14
    7db2f94fe4ff:	add    r15,0x8
    7db2f94fe503:	mov    rbp,QWORD PTR [r12+0xe8]
    7db2f94fe50b:	mov    r9,QWORD PTR [r12+0xf0]
    7db2f94fe513:	mov    QWORD PTR [r14],rbp
    7db2f94fe516:	mov    QWORD PTR [r15],r9
    7db2f94fe519:	mov    r14,QWORD PTR [r12+0x98]
    7db2f94fe521:	add    r14,0x128
    7db2f94fe528:	mov    DWORD PTR [r14],r8d
    7db2f94fe52b:	mov    r14,r13
    7db2f94fe52e:	add    r14,0xf0
    7db2f94fe535:	mov    r15,r14
    7db2f94fe538:	add    r15,0x10
    7db2f94fe53c:	movdqu XMMWORD PTR [r14],xmm2
    7db2f94fe541:	movdqu XMMWORD PTR [r15],xmm3
    7db2f94fe546:	add    r13,0xd0
    7db2f94fe54d:	mov    QWORD PTR [r12],r13
    7db2f94fe551:	mov    r13d,0x0
    7db2f94fe557:	mov    rcx,QWORD PTR [r12+0x98]
    7db2f94fe55f:	or     r13,rcx
    7db2f94fe562:	mov    QWORD PTR [r12+0x8],r13
    7db2f94fe567:	mov    r13d,0x12c
    7db2f94fe56d:	mov    QWORD PTR [r12+0x10],r13
    7db2f94fe572:	mov    r13d,0x410284
    7db2f94fe578:	mov    QWORD PTR [r12+0xf0],r13
    7db2f94fe580:	mov    r13d,0x4106bc
    7db2f94fe586:	mov    QWORD PTR [r12+0x100],r13
    7db2f94fe58e:	mov    r11,QWORD PTR [rsp]
    7db2f94fe592:	mov    QWORD PTR [r12+0x398],r11
    7db2f94fe59a:	mov    edi,0x4106bc
    7db2f94fe59f:	mov    QWORD PTR [r12+0x100],rdi
    7db2f94fe5a7:	add    rsp,0x10
    7db2f94fe5ab:	nop    DWORD PTR [rax+rax*1+0x0]
    7db2f94fe5b0:	jmp    QWORD PTR [rip+0x2]        # 0x7db2f94fe5b8
    7db2f94fe5b6:	xchg   ax,ax
    7db2f94fe5b8:	loopne 0x7db2f94fe59f
    7db2f94fe5ba:	rex.WRXB stc
    7db2f94fe5bc:	mov    dl,0x7d
    7db2f94fe5be:	add    BYTE PTR [rax],al
    7db2f94fe5c0:	enter  0x4fe5,0xf9
    7db2f94fe5c4:	mov    dl,0x7d
    7db2f94fe5c6:	add    BYTE PTR [rax],al
    7db2f94fe5c8:	movabs r11,0x5a58c9ed2940
    7db2f94fe5d2:	jmp    r11
    7db2f94fe5d5:	nop
    7db2f94fe5d6:	nop
    7db2f94fe5d7:	nop
