
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/2/2.bin:     file format binary


Disassembly of section .data:

00007db2f9500b80 <.data>:
    7db2f9500b80:	sub    rsp,0x10
    7db2f9500b84:	mov    r13d,DWORD PTR [r12+0xa0]
    7db2f9500b8c:	sub    r13d,0x1
    7db2f9500b90:	mov    QWORD PTR [r12+0xa0],r13
    7db2f9500b98:	mov    rcx,QWORD PTR [r12+0x380]
    7db2f9500ba0:	jrcxz  0x7db2f9500ba7
    7db2f9500ba2:	jmp    0x7db2f9500d3d
    7db2f9500ba7:	jne    0x7db2f9500bc0
    7db2f9500bad:	mov    r11,rax
    7db2f9500bb0:	lahf
    7db2f9500bb1:	seto   al
    7db2f9500bb4:	mov    WORD PTR [rsp],ax
    7db2f9500bb8:	mov    rax,r11
    7db2f9500bbb:	jmp    0x7db2f9500bd3
    7db2f9500bc0:	mov    r11,rax
    7db2f9500bc3:	lahf
    7db2f9500bc4:	seto   al
    7db2f9500bc7:	mov    WORD PTR [rsp],ax
    7db2f9500bcb:	mov    rax,r11
    7db2f9500bce:	jmp    0x7db2f9500ca5
    7db2f9500bd3:	mov    r13,QWORD PTR [r12+0xf8]
    7db2f9500bdb:	mov    r14,r13
    7db2f9500bde:	add    r14,0xf0
    7db2f9500be5:	mov    r15,QWORD PTR [r14]
    7db2f9500be8:	mov    QWORD PTR [r12+0x98],r15
    7db2f9500bf0:	mov    r14d,0x80
    7db2f9500bf6:	mov    QWORD PTR [r12+0x40],r14
    7db2f9500bfb:	mov    r14,r13
    7db2f9500bfe:	add    r14,0xd0
    7db2f9500c05:	mov    QWORD PTR [r12],r14
    7db2f9500c09:	mov    r14,r13
    7db2f9500c0c:	add    r14,0x14c
    7db2f9500c13:	mov    QWORD PTR [r12+0x8],r14
    7db2f9500c18:	mov    r14d,0x1
    7db2f9500c1e:	mov    QWORD PTR [r12+0x10],r14
    7db2f9500c23:	add    r13,0x14c
    7db2f9500c2a:	movzx  r14d,BYTE PTR [r12+0x40]
    7db2f9500c30:	mov    BYTE PTR [r13+0x0],r14b
    7db2f9500c34:	mov    r13d,0x0
    7db2f9500c3a:	mov    DWORD PTR [r12+0x32c],r13d
    7db2f9500c42:	mov    r13d,0x4102a8
    7db2f9500c48:	mov    QWORD PTR [r12+0xf0],r13
    7db2f9500c50:	mov    r13d,0x4106bc
    7db2f9500c56:	mov    QWORD PTR [r12+0x100],r13
    7db2f9500c5e:	mov    r11,QWORD PTR [rsp]
    7db2f9500c62:	mov    QWORD PTR [r12+0x398],r11
    7db2f9500c6a:	mov    edi,0x4106bc
    7db2f9500c6f:	mov    QWORD PTR [r12+0x100],rdi
    7db2f9500c77:	add    rsp,0x10
    7db2f9500c7b:	nop    DWORD PTR [rax+rax*1+0x0]
    7db2f9500c80:	jmp    QWORD PTR [rip+0x2]        # 0x7db2f9500c88
    7db2f9500c86:	xchg   ax,ax
    7db2f9500c88:	loopne 0x7db2f9500c6f
    7db2f9500c8a:	rex.WRXB stc
    7db2f9500c8c:	mov    dl,0x7d
    7db2f9500c8e:	add    BYTE PTR [rax],al
    7db2f9500c90:	cwde
    7db2f9500c91:	or     al,0x50
    7db2f9500c93:	stc
    7db2f9500c94:	mov    dl,0x7d
    7db2f9500c96:	add    BYTE PTR [rax],al
    7db2f9500c98:	movabs r11,0x5a58c9ed2940
    7db2f9500ca2:	jmp    r11
    7db2f9500ca5:	mov    r13,QWORD PTR [r12+0xf8]
    7db2f9500cad:	add    r13,0xd0
    7db2f9500cb4:	mov    QWORD PTR [r12],r13
    7db2f9500cb8:	mov    r13d,0x0
    7db2f9500cbe:	mov    r14,QWORD PTR [r12+0x98]
    7db2f9500cc6:	or     r13,r14
    7db2f9500cc9:	mov    QWORD PTR [r12+0x8],r13
    7db2f9500cce:	mov    r13d,0x12c
    7db2f9500cd4:	mov    QWORD PTR [r12+0x10],r13
    7db2f9500cd9:	mov    r13d,0x410284
    7db2f9500cdf:	mov    QWORD PTR [r12+0xf0],r13
    7db2f9500ce7:	mov    r13d,0x4106bc
    7db2f9500ced:	mov    QWORD PTR [r12+0x100],r13
    7db2f9500cf5:	mov    r11,QWORD PTR [rsp]
    7db2f9500cf9:	mov    QWORD PTR [r12+0x398],r11
    7db2f9500d01:	mov    edi,0x4106bc
    7db2f9500d06:	mov    QWORD PTR [r12+0x100],rdi
    7db2f9500d0e:	add    rsp,0x10
    7db2f9500d12:	nop    WORD PTR [rax+rax*1+0x0]
    7db2f9500d18:	jmp    QWORD PTR [rip+0x2]        # 0x7db2f9500d20
    7db2f9500d1e:	xchg   ax,ax
    7db2f9500d20:	loopne 0x7db2f9500d07
    7db2f9500d22:	rex.WRXB stc
    7db2f9500d24:	mov    dl,0x7d
    7db2f9500d26:	add    BYTE PTR [rax],al
    7db2f9500d28:	xor    BYTE PTR [rip+0x7db2f950],cl        # 0x7db37703067e
    7db2f9500d2e:	add    BYTE PTR [rax],al
    7db2f9500d30:	movabs r11,0x5a58c9ed2940
    7db2f9500d3a:	jmp    r11
    7db2f9500d3d:	mov    eax,0x410288
    7db2f9500d42:	mov    QWORD PTR [r12+0x100],rax
    7db2f9500d4a:	push   rdx
    7db2f9500d4b:	push   rsi
    7db2f9500d4c:	push   r10
    7db2f9500d4e:	push   r11
    7db2f9500d50:	mov    r11,rax
    7db2f9500d53:	lahf
    7db2f9500d54:	seto   al
    7db2f9500d57:	mov    WORD PTR [rsp+0x20],ax
    7db2f9500d5c:	mov    rax,r11
    7db2f9500d5f:	mov    rdx,QWORD PTR [rsp+0x20]
    7db2f9500d64:	mov    r10d,edx
    7db2f9500d67:	and    r10d,0xc000
    7db2f9500d6e:	shl    r10d,0x10
    7db2f9500d72:	mov    r11d,edx
    7db2f9500d75:	and    r11d,0x100
    7db2f9500d7c:	shl    r11d,0x15
    7db2f9500d80:	or     r10d,r11d
    7db2f9500d83:	and    edx,0x1
    7db2f9500d86:	shl    edx,0x1c
    7db2f9500d89:	or     r10d,edx
    7db2f9500d8c:	btc    r10,0x1d
    7db2f9500d91:	mov    r11d,0xf0000000
    7db2f9500d97:	and    r11,r10
    7db2f9500d9a:	movabs rsi,0xffffffff0fffffff
    7db2f9500da4:	and    rbx,rsi
    7db2f9500da7:	or     rbx,r11
    7db2f9500daa:	pop    r11
    7db2f9500dac:	pop    r10
    7db2f9500dae:	pop    rsi
    7db2f9500daf:	pop    rdx
    7db2f9500db0:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9500db8:	add    rsp,0x10
    7db2f9500dbc:	mov    eax,0xc
    7db2f9500dc1:	movabs r11,0x5a58c9ed2ca0
    7db2f9500dcb:	jmp    r11
    7db2f9500dce:	xchg   ax,ax
    7db2f9500dd0:	sub    rsp,0x10
    7db2f9500dd4:	mov    r11,QWORD PTR [r12+0x398]
    7db2f9500ddc:	mov    QWORD PTR [rsp],r11
    7db2f9500de0:	jmp    0x7db2f9500bd3
    7db2f9500de5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7db2f9500df0:	sub    rsp,0x10
    7db2f9500df4:	mov    r11,QWORD PTR [r12+0x398]
    7db2f9500dfc:	mov    QWORD PTR [rsp],r11
    7db2f9500e00:	jmp    0x7db2f9500ca5
    7db2f9500e05:	nop
    7db2f9500e06:	nop
    7db2f9500e07:	nop
