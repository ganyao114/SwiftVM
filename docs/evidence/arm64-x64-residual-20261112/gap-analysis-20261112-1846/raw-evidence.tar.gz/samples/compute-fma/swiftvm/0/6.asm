
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/0/6.bin:     file format binary


Disassembly of section .data:

00007076cdd01730 <.data>:
    7076cdd01730:	sub    rsp,0x10
    7076cdd01734:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd0173c:	mov    QWORD PTR [rsp],r11
    7076cdd01740:	mov    r13d,DWORD PTR [r12]
    7076cdd01744:	mov    r14d,r13d
    7076cdd01747:	mov    r14d,r14d
    7076cdd0174a:	shr    r14d,0x10
    7076cdd0174e:	xor    r13d,r14d
    7076cdd01751:	mov    QWORD PTR [r12+0x40],r13
    7076cdd01756:	mov    r14d,0x352d
    7076cdd0175c:	mov    QWORD PTR [r12+0x48],r14
    7076cdd01761:	mov    r14d,0x352d
    7076cdd01767:	mov    r15d,0x7feb
    7076cdd0176d:	and    r15d,0xffff
    7076cdd01774:	mov    rax,r14
    7076cdd01777:	movabs rcx,0xffffffff0000ffff
    7076cdd01781:	and    rax,rcx
    7076cdd01784:	mov    rdx,r15
    7076cdd01787:	shl    rdx,0x10
    7076cdd0178b:	mov    ecx,0xffff0000
    7076cdd01790:	and    rdx,rcx
    7076cdd01793:	or     rax,rdx
    7076cdd01796:	mov    ebp,eax
    7076cdd01798:	mov    QWORD PTR [r12+0x48],rbp
    7076cdd0179d:	mov    r14d,0x0
    7076cdd017a3:	imul   r13d,ebp
    7076cdd017a7:	mov    r15d,r14d
    7076cdd017aa:	add    r15d,r13d
    7076cdd017ad:	mov    QWORD PTR [r12+0x40],r15
    7076cdd017b2:	mov    r13d,0xa68b
    7076cdd017b8:	mov    QWORD PTR [r12+0x48],r13
    7076cdd017bd:	mov    r13d,0xa68b
    7076cdd017c3:	mov    r14d,0x846c
    7076cdd017c9:	and    r14d,0xffff
    7076cdd017d0:	mov    rax,r13
    7076cdd017d3:	movabs rcx,0xffffffff0000ffff
    7076cdd017dd:	and    rax,rcx
    7076cdd017e0:	mov    rdx,r14
    7076cdd017e3:	shl    rdx,0x10
    7076cdd017e7:	mov    ecx,0xffff0000
    7076cdd017ec:	and    rdx,rcx
    7076cdd017ef:	or     rax,rdx
    7076cdd017f2:	mov    ebp,eax
    7076cdd017f4:	mov    QWORD PTR [r12+0x48],rbp
    7076cdd017f9:	mov    r13d,r15d
    7076cdd017fc:	mov    r13d,r13d
    7076cdd017ff:	shr    r13d,0xf
    7076cdd01803:	xor    r15d,r13d
    7076cdd01806:	mov    QWORD PTR [r12+0x40],r15
    7076cdd0180b:	mov    r13d,0x0
    7076cdd01811:	imul   r15d,ebp
    7076cdd01815:	mov    r14d,r13d
    7076cdd01818:	add    r14d,r15d
    7076cdd0181b:	mov    QWORD PTR [r12+0x40],r14
    7076cdd01820:	mov    r13d,r14d
    7076cdd01823:	mov    r13d,r13d
    7076cdd01826:	shr    r13d,0x10
    7076cdd0182a:	xor    r14d,r13d
    7076cdd0182d:	mov    QWORD PTR [r12],r14
    7076cdd01831:	mov    rcx,QWORD PTR [r12+0x380]
    7076cdd01839:	jrcxz  0x7076cdd01840
    7076cdd0183b:	jmp    0x7076cdd01875
    7076cdd01840:	mov    r13,QWORD PTR [r12+0xf0]
    7076cdd01848:	mov    QWORD PTR [r12+0x100],r13
    7076cdd01850:	mov    r11,QWORD PTR [rsp]
    7076cdd01854:	mov    QWORD PTR [r12+0x398],r11
    7076cdd0185c:	mov    rdi,QWORD PTR [r12+0x100]
    7076cdd01864:	add    rsp,0x10
    7076cdd01868:	movabs r11,0x5b61e73e9940
    7076cdd01872:	jmp    r11
    7076cdd01875:	mov    eax,0x41095c
    7076cdd0187a:	mov    QWORD PTR [r12+0x100],rax
    7076cdd01882:	push   rdx
    7076cdd01883:	push   rsi
    7076cdd01884:	push   r10
    7076cdd01886:	push   r11
    7076cdd01888:	mov    rdx,QWORD PTR [rsp+0x20]
    7076cdd0188d:	mov    r10d,edx
    7076cdd01890:	and    r10d,0xc000
    7076cdd01897:	shl    r10d,0x10
    7076cdd0189b:	mov    r11d,edx
    7076cdd0189e:	and    r11d,0x100
    7076cdd018a5:	shl    r11d,0x15
    7076cdd018a9:	or     r10d,r11d
    7076cdd018ac:	and    edx,0x1
    7076cdd018af:	shl    edx,0x1c
    7076cdd018b2:	or     r10d,edx
    7076cdd018b5:	btc    r10,0x1d
    7076cdd018ba:	mov    r11d,0xf0000000
    7076cdd018c0:	and    r11,r10
    7076cdd018c3:	movabs rsi,0xffffffff0fffffff
    7076cdd018cd:	and    rbx,rsi
    7076cdd018d0:	or     rbx,r11
    7076cdd018d3:	pop    r11
    7076cdd018d5:	pop    r10
    7076cdd018d7:	pop    rsi
    7076cdd018d8:	pop    rdx
    7076cdd018d9:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd018e1:	add    rsp,0x10
    7076cdd018e5:	mov    eax,0xc
    7076cdd018ea:	movabs r11,0x5b61e73e9ca0
    7076cdd018f4:	jmp    r11
    7076cdd018f7:	nop
