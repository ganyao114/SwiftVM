
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/2/5.bin:     file format binary


Disassembly of section .data:

00007db2f9501220 <.data>:
    7db2f9501220:	sub    rsp,0x30
    7db2f9501224:	mov    r11,QWORD PTR [r12+0x398]
    7db2f950122c:	mov    QWORD PTR [rsp+0x18],r11
    7db2f9501231:	mov    rax,QWORD PTR [r12+0xf8]
    7db2f9501239:	mov    r14,QWORD PTR [r12+0xf8]
    7db2f9501241:	add    r14,0xd0
    7db2f9501248:	mov    r15,r14
    7db2f950124b:	add    r15,0x4
    7db2f950124f:	mov    ebp,DWORD PTR [r14]
    7db2f9501252:	mov    r14d,DWORD PTR [r15]
    7db2f9501255:	mov    QWORD PTR [r12+0x40],rbp
    7db2f950125a:	mov    QWORD PTR [r12+0x50],r14
    7db2f950125f:	mov    r15,QWORD PTR [r12+0xf8]
    7db2f9501267:	add    r15,0xd8
    7db2f950126e:	mov    r8,r15
    7db2f9501271:	add    r8,0x4
    7db2f9501275:	mov    r9d,DWORD PTR [r15]
    7db2f9501278:	mov    eax,DWORD PTR [r8]
    7db2f950127b:	mov    QWORD PTR [rsp],rax
    7db2f950127f:	mov    QWORD PTR [r12+0x58],r9
    7db2f9501284:	mov    rax,QWORD PTR [rsp]
    7db2f9501288:	mov    QWORD PTR [r12+0x60],rax
    7db2f950128d:	mov    r8d,0x430c20
    7db2f9501293:	mov    QWORD PTR [r12+0x48],r8
    7db2f9501298:	mov    r8d,0x0
    7db2f950129e:	mov    QWORD PTR [r12+0xa0],r8
    7db2f95012a6:	movabs rcx,0xff00ff00ff00ff
    7db2f95012b0:	mov    r8,rbp
    7db2f95012b3:	and    r8,rcx
    7db2f95012b6:	shl    r8,0x8
    7db2f95012ba:	movabs rcx,0xff00ff00ff00ff00
    7db2f95012c4:	mov    r13,rbp
    7db2f95012c7:	and    r13,rcx
    7db2f95012ca:	shr    r13,0x8
    7db2f95012ce:	or     r13,r8
    7db2f95012d1:	movabs rcx,0xffff0000ffff
    7db2f95012db:	mov    rbp,r13
    7db2f95012de:	and    rbp,rcx
    7db2f95012e1:	shl    rbp,0x10
    7db2f95012e5:	movabs rcx,0xffff0000ffff0000
    7db2f95012ef:	and    r13,rcx
    7db2f95012f2:	shr    r13,0x10
    7db2f95012f6:	or     r13,rbp
    7db2f95012f9:	mov    ecx,0xffffffff
    7db2f95012fe:	and    r13,rcx
    7db2f9501301:	mov    QWORD PTR [r12+0x40],r13
    7db2f9501306:	movabs rcx,0xff00ff00ff00ff
    7db2f9501310:	mov    rbp,r14
    7db2f9501313:	and    rbp,rcx
    7db2f9501316:	shl    rbp,0x8
    7db2f950131a:	movabs rcx,0xff00ff00ff00ff00
    7db2f9501324:	mov    r8,r14
    7db2f9501327:	and    r8,rcx
    7db2f950132a:	shr    r8,0x8
    7db2f950132e:	or     r8,rbp
    7db2f9501331:	movabs rcx,0xffff0000ffff
    7db2f950133b:	mov    r14,r8
    7db2f950133e:	and    r14,rcx
    7db2f9501341:	shl    r14,0x10
    7db2f9501345:	movabs rcx,0xffff0000ffff0000
    7db2f950134f:	and    r8,rcx
    7db2f9501352:	shr    r8,0x10
    7db2f9501356:	or     r8,r14
    7db2f9501359:	mov    ecx,0xffffffff
    7db2f950135e:	and    r8,rcx
    7db2f9501361:	mov    QWORD PTR [r12+0x50],r8
    7db2f9501366:	mov    r14d,0x430000
    7db2f950136c:	add    r14,0xd8c
    7db2f9501373:	mov    QWORD PTR [r12+0x98],r14
    7db2f950137b:	mov    r14d,0x430c20
    7db2f9501381:	mov    ebp,0x430c24
    7db2f9501386:	mov    rax,r13
    7db2f9501389:	mov    eax,eax
    7db2f950138b:	mov    r15d,eax
    7db2f950138e:	mov    rax,r8
    7db2f9501391:	mov    eax,eax
    7db2f9501393:	mov    r13d,eax
    7db2f9501396:	mov    DWORD PTR [r14],r15d
    7db2f9501399:	mov    r14d,0x0
    7db2f950139f:	mov    DWORD PTR [r12+0x32c],r14d
    7db2f95013a7:	mov    DWORD PTR [rbp+0x0],r13d
    7db2f95013ab:	movabs rcx,0xff00ff00ff00ff
    7db2f95013b5:	mov    r13,r9
    7db2f95013b8:	and    r13,rcx
    7db2f95013bb:	shl    r13,0x8
    7db2f95013bf:	movabs rcx,0xff00ff00ff00ff00
    7db2f95013c9:	mov    r14,r9
    7db2f95013cc:	and    r14,rcx
    7db2f95013cf:	shr    r14,0x8
    7db2f95013d3:	or     r14,r13
    7db2f95013d6:	movabs rcx,0xffff0000ffff
    7db2f95013e0:	mov    r13,r14
    7db2f95013e3:	and    r13,rcx
    7db2f95013e6:	shl    r13,0x10
    7db2f95013ea:	movabs rcx,0xffff0000ffff0000
    7db2f95013f4:	and    r14,rcx
    7db2f95013f7:	shr    r14,0x10
    7db2f95013fb:	or     r14,r13
    7db2f95013fe:	mov    ecx,0xffffffff
    7db2f9501403:	and    r14,rcx
    7db2f9501406:	mov    QWORD PTR [r12+0x40],r14
    7db2f950140b:	movabs rcx,0xff00ff00ff00ff
    7db2f9501415:	mov    r13,QWORD PTR [rsp]
    7db2f9501419:	and    r13,rcx
    7db2f950141c:	shl    r13,0x8
    7db2f9501420:	movabs rcx,0xff00ff00ff00ff00
    7db2f950142a:	mov    r15,QWORD PTR [rsp]
    7db2f950142e:	and    r15,rcx
    7db2f9501431:	shr    r15,0x8
    7db2f9501435:	or     r15,r13
    7db2f9501438:	movabs rcx,0xffff0000ffff
    7db2f9501442:	mov    r13,r15
    7db2f9501445:	and    r13,rcx
    7db2f9501448:	shl    r13,0x10
    7db2f950144c:	movabs rcx,0xffff0000ffff0000
    7db2f9501456:	and    r15,rcx
    7db2f9501459:	shr    r15,0x10
    7db2f950145d:	or     r15,r13
    7db2f9501460:	mov    ecx,0xffffffff
    7db2f9501465:	and    r15,rcx
    7db2f9501468:	mov    QWORD PTR [r12+0x58],r15
    7db2f950146d:	mov    r13,QWORD PTR [r12+0xf8]
    7db2f9501475:	add    r13,0xe0
    7db2f950147c:	mov    rbp,r13
    7db2f950147f:	add    rbp,0x4
    7db2f9501483:	mov    r8d,DWORD PTR [r13+0x0]
    7db2f9501487:	mov    eax,DWORD PTR [rbp+0x0]
    7db2f950148a:	mov    QWORD PTR [rsp+0x8],rax
    7db2f950148f:	mov    QWORD PTR [r12+0x50],r8
    7db2f9501494:	mov    rax,QWORD PTR [rsp+0x8]
    7db2f9501499:	mov    QWORD PTR [r12+0x60],rax
    7db2f950149e:	mov    ebp,0x430c28
    7db2f95014a3:	mov    r9d,0x430c2c
    7db2f95014a9:	mov    rax,r14
    7db2f95014ac:	mov    eax,eax
    7db2f95014ae:	mov    r13d,eax
    7db2f95014b1:	mov    rax,r15
    7db2f95014b4:	mov    eax,eax
    7db2f95014b6:	mov    r14d,eax
    7db2f95014b9:	mov    DWORD PTR [rbp+0x0],r13d
    7db2f95014bd:	mov    DWORD PTR [r9],r14d
    7db2f95014c0:	movabs rcx,0xff00ff00ff00ff
    7db2f95014ca:	mov    r13,r8
    7db2f95014cd:	and    r13,rcx
    7db2f95014d0:	shl    r13,0x8
    7db2f95014d4:	movabs rcx,0xff00ff00ff00ff00
    7db2f95014de:	mov    r14,r8
    7db2f95014e1:	and    r14,rcx
    7db2f95014e4:	shr    r14,0x8
    7db2f95014e8:	or     r14,r13
    7db2f95014eb:	movabs rcx,0xffff0000ffff
    7db2f95014f5:	mov    r13,r14
    7db2f95014f8:	and    r13,rcx
    7db2f95014fb:	shl    r13,0x10
    7db2f95014ff:	movabs rcx,0xffff0000ffff0000
    7db2f9501509:	and    r14,rcx
    7db2f950150c:	shr    r14,0x10
    7db2f9501510:	or     r14,r13
    7db2f9501513:	mov    ecx,0xffffffff
    7db2f9501518:	and    r14,rcx
    7db2f950151b:	mov    QWORD PTR [r12+0x40],r14
    7db2f9501520:	movabs rcx,0xff00ff00ff00ff
    7db2f950152a:	mov    r13,QWORD PTR [rsp+0x8]
    7db2f950152f:	and    r13,rcx
    7db2f9501532:	shl    r13,0x8
    7db2f9501536:	movabs rcx,0xff00ff00ff00ff00
    7db2f9501540:	mov    r15,QWORD PTR [rsp+0x8]
    7db2f9501545:	and    r15,rcx
    7db2f9501548:	shr    r15,0x8
    7db2f950154c:	or     r15,r13
    7db2f950154f:	movabs rcx,0xffff0000ffff
    7db2f9501559:	mov    r13,r15
    7db2f950155c:	and    r13,rcx
    7db2f950155f:	shl    r13,0x10
    7db2f9501563:	movabs rcx,0xffff0000ffff0000
    7db2f950156d:	and    r15,rcx
    7db2f9501570:	shr    r15,0x10
    7db2f9501574:	or     r15,r13
    7db2f9501577:	mov    ecx,0xffffffff
    7db2f950157c:	and    r15,rcx
    7db2f950157f:	mov    QWORD PTR [r12+0x58],r15
    7db2f9501584:	mov    r13,QWORD PTR [r12+0xf8]
    7db2f950158c:	add    r13,0xe8
    7db2f9501593:	mov    rbp,r13
    7db2f9501596:	add    rbp,0x4
    7db2f950159a:	mov    r8d,DWORD PTR [r13+0x0]
    7db2f950159e:	mov    eax,DWORD PTR [rbp+0x0]
    7db2f95015a1:	mov    QWORD PTR [rsp+0x10],rax
    7db2f95015a6:	mov    QWORD PTR [r12+0x50],r8
    7db2f95015ab:	mov    rax,QWORD PTR [rsp+0x10]
    7db2f95015b0:	mov    QWORD PTR [r12+0x60],rax
    7db2f95015b5:	mov    ebp,0x430c30
    7db2f95015ba:	mov    r9d,0x430c34
    7db2f95015c0:	mov    rax,r14
    7db2f95015c3:	mov    eax,eax
    7db2f95015c5:	mov    r13d,eax
    7db2f95015c8:	mov    rax,r15
    7db2f95015cb:	mov    eax,eax
    7db2f95015cd:	mov    r14d,eax
    7db2f95015d0:	mov    DWORD PTR [rbp+0x0],r13d
    7db2f95015d4:	mov    DWORD PTR [r9],r14d
    7db2f95015d7:	movabs rcx,0xff00ff00ff00ff
    7db2f95015e1:	mov    r13,r8
    7db2f95015e4:	and    r13,rcx
    7db2f95015e7:	shl    r13,0x8
    7db2f95015eb:	movabs rcx,0xff00ff00ff00ff00
    7db2f95015f5:	mov    r14,r8
    7db2f95015f8:	and    r14,rcx
    7db2f95015fb:	shr    r14,0x8
    7db2f95015ff:	or     r14,r13
    7db2f9501602:	movabs rcx,0xffff0000ffff
    7db2f950160c:	mov    r13,r14
    7db2f950160f:	and    r13,rcx
    7db2f9501612:	shl    r13,0x10
    7db2f9501616:	movabs rcx,0xffff0000ffff0000
    7db2f9501620:	and    r14,rcx
    7db2f9501623:	shr    r14,0x10
    7db2f9501627:	or     r14,r13
    7db2f950162a:	mov    ecx,0xffffffff
    7db2f950162f:	and    r14,rcx
    7db2f9501632:	mov    QWORD PTR [r12+0x40],r14
    7db2f9501637:	movabs rcx,0xff00ff00ff00ff
    7db2f9501641:	mov    r13,QWORD PTR [rsp+0x10]
    7db2f9501646:	and    r13,rcx
    7db2f9501649:	shl    r13,0x8
    7db2f950164d:	movabs rcx,0xff00ff00ff00ff00
    7db2f9501657:	mov    r15,QWORD PTR [rsp+0x10]
    7db2f950165c:	and    r15,rcx
    7db2f950165f:	shr    r15,0x8
    7db2f9501663:	or     r15,r13
    7db2f9501666:	movabs rcx,0xffff0000ffff
    7db2f9501670:	mov    r13,r15
    7db2f9501673:	and    r13,rcx
    7db2f9501676:	shl    r13,0x10
    7db2f950167a:	movabs rcx,0xffff0000ffff0000
    7db2f9501684:	and    r15,rcx
    7db2f9501687:	shr    r15,0x10
    7db2f950168b:	or     r15,r13
    7db2f950168e:	mov    ecx,0xffffffff
    7db2f9501693:	and    r15,rcx
    7db2f9501696:	mov    QWORD PTR [r12+0x50],r15
    7db2f950169b:	mov    r13d,0x430c38
    7db2f95016a1:	mov    ebp,0x430c3c
    7db2f95016a6:	mov    rax,r14
    7db2f95016a9:	mov    eax,eax
    7db2f95016ab:	mov    r8d,eax
    7db2f95016ae:	mov    rax,r15
    7db2f95016b1:	mov    eax,eax
    7db2f95016b3:	mov    r14d,eax
    7db2f95016b6:	mov    DWORD PTR [r13+0x0],r8d
    7db2f95016ba:	mov    DWORD PTR [rbp+0x0],r14d
    7db2f95016be:	mov    r13d,0x11
    7db2f95016c4:	mov    QWORD PTR [r12],r13
    7db2f95016c8:	mov    r13d,0x41034c
    7db2f95016ce:	mov    QWORD PTR [r12+0xf0],r13
    7db2f95016d6:	mov    r13d,0x410938
    7db2f95016dc:	mov    QWORD PTR [r12+0x100],r13
    7db2f95016e4:	mov    r11,QWORD PTR [rsp+0x18]
    7db2f95016e9:	mov    QWORD PTR [r12+0x398],r11
    7db2f95016f1:	mov    edi,0x410938
    7db2f95016f6:	mov    QWORD PTR [r12+0x100],rdi
    7db2f95016fe:	add    rsp,0x30
    7db2f9501702:	nop    WORD PTR [rax+rax*1+0x0]
    7db2f9501708:	jmp    QWORD PTR [rip+0x2]        # 0x7db2f9501710
    7db2f950170e:	xchg   ax,ax
    7db2f9501710:	xor    BYTE PTR [rdi],dl
    7db2f9501712:	push   rax
    7db2f9501713:	stc
    7db2f9501714:	mov    dl,0x7d
    7db2f9501716:	add    BYTE PTR [rax],al
    7db2f9501718:	and    BYTE PTR [rdi],dl
    7db2f950171a:	push   rax
    7db2f950171b:	stc
    7db2f950171c:	mov    dl,0x7d
    7db2f950171e:	add    BYTE PTR [rax],al
    7db2f9501720:	movabs r11,0x5a58c9ed2940
    7db2f950172a:	jmp    r11
    7db2f950172d:	nop
    7db2f950172e:	nop
    7db2f950172f:	nop
