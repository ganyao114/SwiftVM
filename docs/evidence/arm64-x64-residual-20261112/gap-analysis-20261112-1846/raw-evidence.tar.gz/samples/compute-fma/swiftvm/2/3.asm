
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/2/3.bin:     file format binary


Disassembly of section .data:

00007db2f9500e10 <.data>:
    7db2f9500e10:	sub    rsp,0x10
    7db2f9500e14:	mov    r11,QWORD PTR [r12+0x398]
    7db2f9500e1c:	mov    QWORD PTR [rsp],r11
    7db2f9500e20:	mov    r13,QWORD PTR [r12+0xf8]
    7db2f9500e28:	mov    r14,r13
    7db2f9500e2b:	add    r14,0x138
    7db2f9500e32:	mov    r15,QWORD PTR [r14]
    7db2f9500e35:	mov    QWORD PTR [r12+0x40],r15
    7db2f9500e3a:	add    r13,0x148
    7db2f9500e41:	mov    r14d,0x0
    7db2f9500e47:	mov    BYTE PTR [r13+0x0],r14b
    7db2f9500e4b:	mov    r13d,0x0
    7db2f9500e51:	mov    DWORD PTR [r12+0x32c],r13d
    7db2f9500e59:	sub    r15,0x38
    7db2f9500e5d:	je     0x7db2f9500e76
    7db2f9500e63:	mov    r11,rax
    7db2f9500e66:	lahf
    7db2f9500e67:	seto   al
    7db2f9500e6a:	mov    WORD PTR [rsp],ax
    7db2f9500e6e:	mov    rax,r11
    7db2f9500e71:	jmp    0x7db2f9500e89
    7db2f9500e76:	mov    r11,rax
    7db2f9500e79:	lahf
    7db2f9500e7a:	seto   al
    7db2f9500e7d:	mov    WORD PTR [rsp],ax
    7db2f9500e81:	mov    rax,r11
    7db2f9500e84:	jmp    0x7db2f9500f15
    7db2f9500e89:	mov    r13,QWORD PTR [r12+0xf8]
    7db2f9500e91:	mov    r14,r13
    7db2f9500e94:	add    r14,0xd0
    7db2f9500e9b:	mov    QWORD PTR [r12],r14
    7db2f9500e9f:	add    r13,0x148
    7db2f9500ea6:	mov    QWORD PTR [r12+0x8],r13
    7db2f9500eab:	mov    r13d,0x1
    7db2f9500eb1:	mov    QWORD PTR [r12+0x10],r13
    7db2f9500eb6:	mov    r13d,0x4102c8
    7db2f9500ebc:	mov    QWORD PTR [r12+0xf0],r13
    7db2f9500ec4:	mov    r13d,0x4106bc
    7db2f9500eca:	mov    QWORD PTR [r12+0x100],r13
    7db2f9500ed2:	mov    r11,QWORD PTR [rsp]
    7db2f9500ed6:	mov    QWORD PTR [r12+0x398],r11
    7db2f9500ede:	mov    edi,0x4106bc
    7db2f9500ee3:	mov    QWORD PTR [r12+0x100],rdi
    7db2f9500eeb:	add    rsp,0x10
    7db2f9500eef:	nop
    7db2f9500ef0:	jmp    QWORD PTR [rip+0x2]        # 0x7db2f9500ef8
    7db2f9500ef6:	xchg   ax,ax
    7db2f9500ef8:	loopne 0x7db2f9500edf
    7db2f9500efa:	rex.WRXB stc
    7db2f9500efc:	mov    dl,0x7d
    7db2f9500efe:	add    BYTE PTR [rax],al
    7db2f9500f00:	or     BYTE PTR [rdi],cl
    7db2f9500f02:	push   rax
    7db2f9500f03:	stc
    7db2f9500f04:	mov    dl,0x7d
    7db2f9500f06:	add    BYTE PTR [rax],al
    7db2f9500f08:	movabs r11,0x5a58c9ed2940
    7db2f9500f12:	jmp    r11
    7db2f9500f15:	mov    r13,QWORD PTR [r12+0x98]
    7db2f9500f1d:	ror    r13,0x3d
    7db2f9500f21:	and    r13,0xfffffffffffffff8
    7db2f9500f25:	mov    r14,QWORD PTR [r12+0xf8]
    7db2f9500f2d:	mov    r15,r14
    7db2f9500f30:	add    r15,0xd0
    7db2f9500f37:	mov    QWORD PTR [r12],r15
    7db2f9500f3b:	mov    r15,r14
    7db2f9500f3e:	add    r15,0x140
    7db2f9500f45:	mov    QWORD PTR [r12+0x8],r15
    7db2f9500f4a:	mov    r15d,0x8
    7db2f9500f50:	mov    QWORD PTR [r12+0x10],r15
    7db2f9500f55:	movabs rcx,0xff00ff00ff00ff
    7db2f9500f5f:	mov    r15,r13
    7db2f9500f62:	and    r15,rcx
    7db2f9500f65:	shl    r15,0x8
    7db2f9500f69:	movabs rcx,0xff00ff00ff00ff00
    7db2f9500f73:	and    r13,rcx
    7db2f9500f76:	shr    r13,0x8
    7db2f9500f7a:	or     r13,r15
    7db2f9500f7d:	movabs rcx,0xffff0000ffff
    7db2f9500f87:	mov    r15,r13
    7db2f9500f8a:	and    r15,rcx
    7db2f9500f8d:	shl    r15,0x10
    7db2f9500f91:	movabs rcx,0xffff0000ffff0000
    7db2f9500f9b:	and    r13,rcx
    7db2f9500f9e:	shr    r13,0x10
    7db2f9500fa2:	or     r13,r15
    7db2f9500fa5:	mov    r15,r13
    7db2f9500fa8:	shl    r15,0x20
    7db2f9500fac:	shr    r13,0x20
    7db2f9500fb0:	or     r13,r15
    7db2f9500fb3:	mov    QWORD PTR [r12+0x40],r13
    7db2f9500fb8:	add    r14,0x140
    7db2f9500fbf:	mov    QWORD PTR [r14],r13
    7db2f9500fc2:	mov    r13d,0x0
    7db2f9500fc8:	mov    DWORD PTR [r12+0x32c],r13d
    7db2f9500fd0:	mov    r13d,0x4102f0
    7db2f9500fd6:	mov    QWORD PTR [r12+0xf0],r13
    7db2f9500fde:	mov    r13d,0x4106bc
    7db2f9500fe4:	mov    QWORD PTR [r12+0x100],r13
    7db2f9500fec:	mov    r11,QWORD PTR [rsp]
    7db2f9500ff0:	mov    QWORD PTR [r12+0x398],r11
    7db2f9500ff8:	mov    edi,0x4106bc
    7db2f9500ffd:	mov    QWORD PTR [r12+0x100],rdi
    7db2f9501005:	add    rsp,0x10
    7db2f9501009:	nop    DWORD PTR [rax+0x0]
    7db2f9501010:	jmp    QWORD PTR [rip+0x2]        # 0x7db2f9501018
    7db2f9501016:	xchg   ax,ax
    7db2f9501018:	loopne 0x7db2f9500fff
    7db2f950101a:	rex.WRXB stc
    7db2f950101c:	mov    dl,0x7d
    7db2f950101e:	add    BYTE PTR [rax],al
    7db2f9501020:	sub    BYTE PTR [rax],dl
    7db2f9501022:	push   rax
    7db2f9501023:	stc
    7db2f9501024:	mov    dl,0x7d
    7db2f9501026:	add    BYTE PTR [rax],al
    7db2f9501028:	movabs r11,0x5a58c9ed2940
    7db2f9501032:	jmp    r11
    7db2f9501035:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7db2f9501040:	sub    rsp,0x10
    7db2f9501044:	mov    r11,QWORD PTR [r12+0x398]
    7db2f950104c:	mov    QWORD PTR [rsp],r11
    7db2f9501050:	jmp    0x7db2f9500e89
    7db2f9501055:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7db2f9501060:	sub    rsp,0x10
    7db2f9501064:	mov    r11,QWORD PTR [r12+0x398]
    7db2f950106c:	mov    QWORD PTR [rsp],r11
    7db2f9501070:	jmp    0x7db2f9500f15
    7db2f9501075:	nop
    7db2f9501076:	nop
    7db2f9501077:	nop
