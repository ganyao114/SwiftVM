
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/0/3.bin:     file format binary


Disassembly of section .data:

00007076cdd00e10 <.data>:
    7076cdd00e10:	sub    rsp,0x10
    7076cdd00e14:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd00e1c:	mov    QWORD PTR [rsp],r11
    7076cdd00e20:	mov    r13,QWORD PTR [r12+0xf8]
    7076cdd00e28:	mov    r14,r13
    7076cdd00e2b:	add    r14,0x138
    7076cdd00e32:	mov    r15,QWORD PTR [r14]
    7076cdd00e35:	mov    QWORD PTR [r12+0x40],r15
    7076cdd00e3a:	add    r13,0x148
    7076cdd00e41:	mov    r14d,0x0
    7076cdd00e47:	mov    BYTE PTR [r13+0x0],r14b
    7076cdd00e4b:	mov    r13d,0x0
    7076cdd00e51:	mov    DWORD PTR [r12+0x32c],r13d
    7076cdd00e59:	sub    r15,0x38
    7076cdd00e5d:	je     0x7076cdd00e76
    7076cdd00e63:	mov    r11,rax
    7076cdd00e66:	lahf
    7076cdd00e67:	seto   al
    7076cdd00e6a:	mov    WORD PTR [rsp],ax
    7076cdd00e6e:	mov    rax,r11
    7076cdd00e71:	jmp    0x7076cdd00e89
    7076cdd00e76:	mov    r11,rax
    7076cdd00e79:	lahf
    7076cdd00e7a:	seto   al
    7076cdd00e7d:	mov    WORD PTR [rsp],ax
    7076cdd00e81:	mov    rax,r11
    7076cdd00e84:	jmp    0x7076cdd00f15
    7076cdd00e89:	mov    r13,QWORD PTR [r12+0xf8]
    7076cdd00e91:	mov    r14,r13
    7076cdd00e94:	add    r14,0xd0
    7076cdd00e9b:	mov    QWORD PTR [r12],r14
    7076cdd00e9f:	add    r13,0x148
    7076cdd00ea6:	mov    QWORD PTR [r12+0x8],r13
    7076cdd00eab:	mov    r13d,0x1
    7076cdd00eb1:	mov    QWORD PTR [r12+0x10],r13
    7076cdd00eb6:	mov    r13d,0x4102c8
    7076cdd00ebc:	mov    QWORD PTR [r12+0xf0],r13
    7076cdd00ec4:	mov    r13d,0x4106bc
    7076cdd00eca:	mov    QWORD PTR [r12+0x100],r13
    7076cdd00ed2:	mov    r11,QWORD PTR [rsp]
    7076cdd00ed6:	mov    QWORD PTR [r12+0x398],r11
    7076cdd00ede:	mov    edi,0x4106bc
    7076cdd00ee3:	mov    QWORD PTR [r12+0x100],rdi
    7076cdd00eeb:	add    rsp,0x10
    7076cdd00eef:	nop
    7076cdd00ef0:	jmp    QWORD PTR [rip+0x2]        # 0x7076cdd00ef8
    7076cdd00ef6:	xchg   ax,ax
    7076cdd00ef8:	loopne 0x7076cdd00edf
    7076cdd00efa:	iret
    7076cdd00efb:	int    0x76
    7076cdd00efd:	jo     0x7076cdd00eff
    7076cdd00eff:	add    BYTE PTR [rax],cl
    7076cdd00f01:	(bad)
    7076cdd00f03:	int    0x76
    7076cdd00f05:	jo     0x7076cdd00f07
    7076cdd00f07:	add    BYTE PTR [rcx-0x45],cl
    7076cdd00f0a:	rex cdq
    7076cdd00f0c:	ds out 0x61,eax
    7076cdd00f0f:	pop    rbx
    7076cdd00f10:	add    BYTE PTR [rax],al
    7076cdd00f12:	jmp    r11
    7076cdd00f15:	mov    r13,QWORD PTR [r12+0x98]
    7076cdd00f1d:	ror    r13,0x3d
    7076cdd00f21:	and    r13,0xfffffffffffffff8
    7076cdd00f25:	mov    r14,QWORD PTR [r12+0xf8]
    7076cdd00f2d:	mov    r15,r14
    7076cdd00f30:	add    r15,0xd0
    7076cdd00f37:	mov    QWORD PTR [r12],r15
    7076cdd00f3b:	mov    r15,r14
    7076cdd00f3e:	add    r15,0x140
    7076cdd00f45:	mov    QWORD PTR [r12+0x8],r15
    7076cdd00f4a:	mov    r15d,0x8
    7076cdd00f50:	mov    QWORD PTR [r12+0x10],r15
    7076cdd00f55:	movabs rcx,0xff00ff00ff00ff
    7076cdd00f5f:	mov    r15,r13
    7076cdd00f62:	and    r15,rcx
    7076cdd00f65:	shl    r15,0x8
    7076cdd00f69:	movabs rcx,0xff00ff00ff00ff00
    7076cdd00f73:	and    r13,rcx
    7076cdd00f76:	shr    r13,0x8
    7076cdd00f7a:	or     r13,r15
    7076cdd00f7d:	movabs rcx,0xffff0000ffff
    7076cdd00f87:	mov    r15,r13
    7076cdd00f8a:	and    r15,rcx
    7076cdd00f8d:	shl    r15,0x10
    7076cdd00f91:	movabs rcx,0xffff0000ffff0000
    7076cdd00f9b:	and    r13,rcx
    7076cdd00f9e:	shr    r13,0x10
    7076cdd00fa2:	or     r13,r15
    7076cdd00fa5:	mov    r15,r13
    7076cdd00fa8:	shl    r15,0x20
    7076cdd00fac:	shr    r13,0x20
    7076cdd00fb0:	or     r13,r15
    7076cdd00fb3:	mov    QWORD PTR [r12+0x40],r13
    7076cdd00fb8:	add    r14,0x140
    7076cdd00fbf:	mov    QWORD PTR [r14],r13
    7076cdd00fc2:	mov    r13d,0x0
    7076cdd00fc8:	mov    DWORD PTR [r12+0x32c],r13d
    7076cdd00fd0:	mov    r13d,0x4102f0
    7076cdd00fd6:	mov    QWORD PTR [r12+0xf0],r13
    7076cdd00fde:	mov    r13d,0x4106bc
    7076cdd00fe4:	mov    QWORD PTR [r12+0x100],r13
    7076cdd00fec:	mov    r11,QWORD PTR [rsp]
    7076cdd00ff0:	mov    QWORD PTR [r12+0x398],r11
    7076cdd00ff8:	mov    edi,0x4106bc
    7076cdd00ffd:	mov    QWORD PTR [r12+0x100],rdi
    7076cdd01005:	add    rsp,0x10
    7076cdd01009:	nop    DWORD PTR [rax+0x0]
    7076cdd01010:	jmp    QWORD PTR [rip+0x2]        # 0x7076cdd01018
    7076cdd01016:	xchg   ax,ax
    7076cdd01018:	loopne 0x7076cdd00fff
    7076cdd0101a:	iret
    7076cdd0101b:	int    0x76
    7076cdd0101d:	jo     0x7076cdd0101f
    7076cdd0101f:	add    BYTE PTR [rax],ch
    7076cdd01021:	adc    al,dl
    7076cdd01023:	int    0x76
    7076cdd01025:	jo     0x7076cdd01027
    7076cdd01027:	add    BYTE PTR [rcx-0x45],cl
    7076cdd0102a:	rex cdq
    7076cdd0102c:	ds out 0x61,eax
    7076cdd0102f:	pop    rbx
    7076cdd01030:	add    BYTE PTR [rax],al
    7076cdd01032:	jmp    r11
    7076cdd01035:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7076cdd01040:	sub    rsp,0x10
    7076cdd01044:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd0104c:	mov    QWORD PTR [rsp],r11
    7076cdd01050:	jmp    0x7076cdd00e89
    7076cdd01055:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7076cdd01060:	sub    rsp,0x10
    7076cdd01064:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd0106c:	mov    QWORD PTR [rsp],r11
    7076cdd01070:	jmp    0x7076cdd00f15
    7076cdd01075:	nop
    7076cdd01076:	nop
    7076cdd01077:	nop
