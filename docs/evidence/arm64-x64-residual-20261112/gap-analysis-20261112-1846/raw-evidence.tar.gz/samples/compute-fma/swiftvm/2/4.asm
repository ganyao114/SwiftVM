
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/2/4.bin:     file format binary


Disassembly of section .data:

00007db2f9501080 <.data>:
    7db2f9501080:	sub    rsp,0x10
    7db2f9501084:	mov    r11,QWORD PTR [r12+0x398]
    7db2f950108c:	mov    QWORD PTR [rsp],r11
    7db2f9501090:	mov    r13,QWORD PTR [r12+0xf8]
    7db2f9501098:	add    r13,0x138
    7db2f950109f:	mov    r14,QWORD PTR [r13+0x0]
    7db2f95010a3:	mov    QWORD PTR [r12+0x40],r14
    7db2f95010a8:	sub    r14,0x38
    7db2f95010ac:	mov    rcx,QWORD PTR [r12+0x380]
    7db2f95010b4:	jrcxz  0x7db2f95010bb
    7db2f95010b6:	jmp    0x7db2f950118d
    7db2f95010bb:	jne    0x7db2f95010d4
    7db2f95010c1:	mov    r11,rax
    7db2f95010c4:	lahf
    7db2f95010c5:	seto   al
    7db2f95010c8:	mov    WORD PTR [rsp],ax
    7db2f95010cc:	mov    rax,r11
    7db2f95010cf:	jmp    0x7db2f95010e7
    7db2f95010d4:	mov    r11,rax
    7db2f95010d7:	lahf
    7db2f95010d8:	seto   al
    7db2f95010db:	mov    WORD PTR [rsp],ax
    7db2f95010df:	mov    rax,r11
    7db2f95010e2:	jmp    0x7db2f950113d
    7db2f95010e7:	mov    r13d,0x4102d4
    7db2f95010ed:	mov    QWORD PTR [r12+0x100],r13
    7db2f95010f5:	mov    r11,QWORD PTR [rsp]
    7db2f95010f9:	mov    QWORD PTR [r12+0x398],r11
    7db2f9501101:	mov    edi,0x4102d4
    7db2f9501106:	mov    QWORD PTR [r12+0x100],rdi
    7db2f950110e:	add    rsp,0x10
    7db2f9501112:	nop    WORD PTR [rax+rax*1+0x0]
    7db2f9501118:	jmp    QWORD PTR [rip+0x2]        # 0x7db2f9501120
    7db2f950111e:	xchg   ax,ax
    7db2f9501120:	(bad)
    7db2f9501121:	adc    BYTE PTR [rax-0x7],dl
    7db2f9501124:	mov    dl,0x7d
    7db2f9501126:	add    BYTE PTR [rax],al
    7db2f9501128:	xor    BYTE PTR [rcx],dl
    7db2f950112a:	push   rax
    7db2f950112b:	stc
    7db2f950112c:	mov    dl,0x7d
    7db2f950112e:	add    BYTE PTR [rax],al
    7db2f9501130:	movabs r11,0x5a58c9ed2940
    7db2f950113a:	jmp    r11
    7db2f950113d:	mov    r13d,0x4102b8
    7db2f9501143:	mov    QWORD PTR [r12+0x100],r13
    7db2f950114b:	mov    r11,QWORD PTR [rsp]
    7db2f950114f:	mov    QWORD PTR [r12+0x398],r11
    7db2f9501157:	mov    edi,0x4102b8
    7db2f950115c:	mov    QWORD PTR [r12+0x100],rdi
    7db2f9501164:	add    rsp,0x10
    7db2f9501168:	jmp    QWORD PTR [rip+0x2]        # 0x7db2f9501170
    7db2f950116e:	xchg   ax,ax
    7db2f9501170:	rex adc BYTE PTR [rax-0x7],dl
    7db2f9501174:	mov    dl,0x7d
    7db2f9501176:	add    BYTE PTR [rax],al
    7db2f9501178:	adc    BYTE PTR [rcx],0x50
    7db2f950117b:	stc
    7db2f950117c:	mov    dl,0x7d
    7db2f950117e:	add    BYTE PTR [rax],al
    7db2f9501180:	movabs r11,0x5a58c9ed2940
    7db2f950118a:	jmp    r11
    7db2f950118d:	mov    eax,0x4102d0
    7db2f9501192:	mov    QWORD PTR [r12+0x100],rax
    7db2f950119a:	push   rdx
    7db2f950119b:	push   rsi
    7db2f950119c:	push   r10
    7db2f950119e:	push   r11
    7db2f95011a0:	mov    r11,rax
    7db2f95011a3:	lahf
    7db2f95011a4:	seto   al
    7db2f95011a7:	mov    WORD PTR [rsp+0x20],ax
    7db2f95011ac:	mov    rax,r11
    7db2f95011af:	mov    rdx,QWORD PTR [rsp+0x20]
    7db2f95011b4:	mov    r10d,edx
    7db2f95011b7:	and    r10d,0xc000
    7db2f95011be:	shl    r10d,0x10
    7db2f95011c2:	mov    r11d,edx
    7db2f95011c5:	and    r11d,0x100
    7db2f95011cc:	shl    r11d,0x15
    7db2f95011d0:	or     r10d,r11d
    7db2f95011d3:	and    edx,0x1
    7db2f95011d6:	shl    edx,0x1c
    7db2f95011d9:	or     r10d,edx
    7db2f95011dc:	btc    r10,0x1d
    7db2f95011e1:	mov    r11d,0xf0000000
    7db2f95011e7:	and    r11,r10
    7db2f95011ea:	movabs rsi,0xffffffff0fffffff
    7db2f95011f4:	and    rbx,rsi
    7db2f95011f7:	or     rbx,r11
    7db2f95011fa:	pop    r11
    7db2f95011fc:	pop    r10
    7db2f95011fe:	pop    rsi
    7db2f95011ff:	pop    rdx
    7db2f9501200:	mov    QWORD PTR [r12+0x108],rbx
    7db2f9501208:	add    rsp,0x10
    7db2f950120c:	mov    eax,0xc
    7db2f9501211:	movabs r11,0x5a58c9ed2ca0
    7db2f950121b:	jmp    r11
    7db2f950121e:	nop
    7db2f950121f:	nop
