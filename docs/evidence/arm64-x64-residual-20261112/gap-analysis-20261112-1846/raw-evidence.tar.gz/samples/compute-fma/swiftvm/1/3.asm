
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/1/3.bin:     file format binary


Disassembly of section .data:

000072fde4f00e10 <.data>:
    72fde4f00e10:	sub    rsp,0x10
    72fde4f00e14:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f00e1c:	mov    QWORD PTR [rsp],r11
    72fde4f00e20:	mov    r13,QWORD PTR [r12+0xf8]
    72fde4f00e28:	mov    r14,r13
    72fde4f00e2b:	add    r14,0x138
    72fde4f00e32:	mov    r15,QWORD PTR [r14]
    72fde4f00e35:	mov    QWORD PTR [r12+0x40],r15
    72fde4f00e3a:	add    r13,0x148
    72fde4f00e41:	mov    r14d,0x0
    72fde4f00e47:	mov    BYTE PTR [r13+0x0],r14b
    72fde4f00e4b:	mov    r13d,0x0
    72fde4f00e51:	mov    DWORD PTR [r12+0x32c],r13d
    72fde4f00e59:	sub    r15,0x38
    72fde4f00e5d:	je     0x72fde4f00e76
    72fde4f00e63:	mov    r11,rax
    72fde4f00e66:	lahf
    72fde4f00e67:	seto   al
    72fde4f00e6a:	mov    WORD PTR [rsp],ax
    72fde4f00e6e:	mov    rax,r11
    72fde4f00e71:	jmp    0x72fde4f00e89
    72fde4f00e76:	mov    r11,rax
    72fde4f00e79:	lahf
    72fde4f00e7a:	seto   al
    72fde4f00e7d:	mov    WORD PTR [rsp],ax
    72fde4f00e81:	mov    rax,r11
    72fde4f00e84:	jmp    0x72fde4f00f15
    72fde4f00e89:	mov    r13,QWORD PTR [r12+0xf8]
    72fde4f00e91:	mov    r14,r13
    72fde4f00e94:	add    r14,0xd0
    72fde4f00e9b:	mov    QWORD PTR [r12],r14
    72fde4f00e9f:	add    r13,0x148
    72fde4f00ea6:	mov    QWORD PTR [r12+0x8],r13
    72fde4f00eab:	mov    r13d,0x1
    72fde4f00eb1:	mov    QWORD PTR [r12+0x10],r13
    72fde4f00eb6:	mov    r13d,0x4102c8
    72fde4f00ebc:	mov    QWORD PTR [r12+0xf0],r13
    72fde4f00ec4:	mov    r13d,0x4106bc
    72fde4f00eca:	mov    QWORD PTR [r12+0x100],r13
    72fde4f00ed2:	mov    r11,QWORD PTR [rsp]
    72fde4f00ed6:	mov    QWORD PTR [r12+0x398],r11
    72fde4f00ede:	mov    edi,0x4106bc
    72fde4f00ee3:	mov    QWORD PTR [r12+0x100],rdi
    72fde4f00eeb:	add    rsp,0x10
    72fde4f00eef:	nop
    72fde4f00ef0:	jmp    QWORD PTR [rip+0x2]        # 0x72fde4f00ef8
    72fde4f00ef6:	xchg   ax,ax
    72fde4f00ef8:	loopne 0x72fde4f00edf
    72fde4f00efa:	out    dx,eax
    72fde4f00efb:	in     al,0xfd
    72fde4f00efd:	jb     0x72fde4f00eff
    72fde4f00eff:	add    BYTE PTR [rax],cl
    72fde4f00f01:	(bad)
    72fde4f00f03:	in     al,0xfd
    72fde4f00f05:	jb     0x72fde4f00f07
    72fde4f00f07:	add    BYTE PTR [rcx-0x45],cl
    72fde4f00f0a:	rex or ebp,esi
    72fde4f00f0d:	sahf
    72fde4f00f0e:	int    0x5c
    72fde4f00f10:	add    BYTE PTR [rax],al
    72fde4f00f12:	jmp    r11
    72fde4f00f15:	mov    r13,QWORD PTR [r12+0x98]
    72fde4f00f1d:	ror    r13,0x3d
    72fde4f00f21:	and    r13,0xfffffffffffffff8
    72fde4f00f25:	mov    r14,QWORD PTR [r12+0xf8]
    72fde4f00f2d:	mov    r15,r14
    72fde4f00f30:	add    r15,0xd0
    72fde4f00f37:	mov    QWORD PTR [r12],r15
    72fde4f00f3b:	mov    r15,r14
    72fde4f00f3e:	add    r15,0x140
    72fde4f00f45:	mov    QWORD PTR [r12+0x8],r15
    72fde4f00f4a:	mov    r15d,0x8
    72fde4f00f50:	mov    QWORD PTR [r12+0x10],r15
    72fde4f00f55:	movabs rcx,0xff00ff00ff00ff
    72fde4f00f5f:	mov    r15,r13
    72fde4f00f62:	and    r15,rcx
    72fde4f00f65:	shl    r15,0x8
    72fde4f00f69:	movabs rcx,0xff00ff00ff00ff00
    72fde4f00f73:	and    r13,rcx
    72fde4f00f76:	shr    r13,0x8
    72fde4f00f7a:	or     r13,r15
    72fde4f00f7d:	movabs rcx,0xffff0000ffff
    72fde4f00f87:	mov    r15,r13
    72fde4f00f8a:	and    r15,rcx
    72fde4f00f8d:	shl    r15,0x10
    72fde4f00f91:	movabs rcx,0xffff0000ffff0000
    72fde4f00f9b:	and    r13,rcx
    72fde4f00f9e:	shr    r13,0x10
    72fde4f00fa2:	or     r13,r15
    72fde4f00fa5:	mov    r15,r13
    72fde4f00fa8:	shl    r15,0x20
    72fde4f00fac:	shr    r13,0x20
    72fde4f00fb0:	or     r13,r15
    72fde4f00fb3:	mov    QWORD PTR [r12+0x40],r13
    72fde4f00fb8:	add    r14,0x140
    72fde4f00fbf:	mov    QWORD PTR [r14],r13
    72fde4f00fc2:	mov    r13d,0x0
    72fde4f00fc8:	mov    DWORD PTR [r12+0x32c],r13d
    72fde4f00fd0:	mov    r13d,0x4102f0
    72fde4f00fd6:	mov    QWORD PTR [r12+0xf0],r13
    72fde4f00fde:	mov    r13d,0x4106bc
    72fde4f00fe4:	mov    QWORD PTR [r12+0x100],r13
    72fde4f00fec:	mov    r11,QWORD PTR [rsp]
    72fde4f00ff0:	mov    QWORD PTR [r12+0x398],r11
    72fde4f00ff8:	mov    edi,0x4106bc
    72fde4f00ffd:	mov    QWORD PTR [r12+0x100],rdi
    72fde4f01005:	add    rsp,0x10
    72fde4f01009:	nop    DWORD PTR [rax+0x0]
    72fde4f01010:	jmp    QWORD PTR [rip+0x2]        # 0x72fde4f01018
    72fde4f01016:	xchg   ax,ax
    72fde4f01018:	loopne 0x72fde4f00fff
    72fde4f0101a:	out    dx,eax
    72fde4f0101b:	in     al,0xfd
    72fde4f0101d:	jb     0x72fde4f0101f
    72fde4f0101f:	add    BYTE PTR [rax],ch
    72fde4f01021:	adc    al,dh
    72fde4f01023:	in     al,0xfd
    72fde4f01025:	jb     0x72fde4f01027
    72fde4f01027:	add    BYTE PTR [rcx-0x45],cl
    72fde4f0102a:	rex or ebp,esi
    72fde4f0102d:	sahf
    72fde4f0102e:	int    0x5c
    72fde4f01030:	add    BYTE PTR [rax],al
    72fde4f01032:	jmp    r11
    72fde4f01035:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72fde4f01040:	sub    rsp,0x10
    72fde4f01044:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f0104c:	mov    QWORD PTR [rsp],r11
    72fde4f01050:	jmp    0x72fde4f00e89
    72fde4f01055:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    72fde4f01060:	sub    rsp,0x10
    72fde4f01064:	mov    r11,QWORD PTR [r12+0x398]
    72fde4f0106c:	mov    QWORD PTR [rsp],r11
    72fde4f01070:	jmp    0x72fde4f00f15
    72fde4f01075:	nop
    72fde4f01076:	nop
    72fde4f01077:	nop
