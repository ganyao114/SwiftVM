
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute-fma/swiftvm/0/4.bin:     file format binary


Disassembly of section .data:

00007076cdd01080 <.data>:
    7076cdd01080:	sub    rsp,0x10
    7076cdd01084:	mov    r11,QWORD PTR [r12+0x398]
    7076cdd0108c:	mov    QWORD PTR [rsp],r11
    7076cdd01090:	mov    r13,QWORD PTR [r12+0xf8]
    7076cdd01098:	add    r13,0x138
    7076cdd0109f:	mov    r14,QWORD PTR [r13+0x0]
    7076cdd010a3:	mov    QWORD PTR [r12+0x40],r14
    7076cdd010a8:	sub    r14,0x38
    7076cdd010ac:	mov    rcx,QWORD PTR [r12+0x380]
    7076cdd010b4:	jrcxz  0x7076cdd010bb
    7076cdd010b6:	jmp    0x7076cdd0118d
    7076cdd010bb:	jne    0x7076cdd010d4
    7076cdd010c1:	mov    r11,rax
    7076cdd010c4:	lahf
    7076cdd010c5:	seto   al
    7076cdd010c8:	mov    WORD PTR [rsp],ax
    7076cdd010cc:	mov    rax,r11
    7076cdd010cf:	jmp    0x7076cdd010e7
    7076cdd010d4:	mov    r11,rax
    7076cdd010d7:	lahf
    7076cdd010d8:	seto   al
    7076cdd010db:	mov    WORD PTR [rsp],ax
    7076cdd010df:	mov    rax,r11
    7076cdd010e2:	jmp    0x7076cdd0113d
    7076cdd010e7:	mov    r13d,0x4102d4
    7076cdd010ed:	mov    QWORD PTR [r12+0x100],r13
    7076cdd010f5:	mov    r11,QWORD PTR [rsp]
    7076cdd010f9:	mov    QWORD PTR [r12+0x398],r11
    7076cdd01101:	mov    edi,0x4102d4
    7076cdd01106:	mov    QWORD PTR [r12+0x100],rdi
    7076cdd0110e:	add    rsp,0x10
    7076cdd01112:	nop    WORD PTR [rax+rax*1+0x0]
    7076cdd01118:	jmp    QWORD PTR [rip+0x2]        # 0x7076cdd01120
    7076cdd0111e:	xchg   ax,ax
    7076cdd01120:	(bad)
    7076cdd01121:	adc    al,dl
    7076cdd01123:	int    0x76
    7076cdd01125:	jo     0x7076cdd01127
    7076cdd01127:	add    BYTE PTR [rax],dh
    7076cdd01129:	adc    eax,edx
    7076cdd0112b:	int    0x76
    7076cdd0112d:	jo     0x7076cdd0112f
    7076cdd0112f:	add    BYTE PTR [rcx-0x45],cl
    7076cdd01132:	rex cdq
    7076cdd01134:	ds out 0x61,eax
    7076cdd01137:	pop    rbx
    7076cdd01138:	add    BYTE PTR [rax],al
    7076cdd0113a:	jmp    r11
    7076cdd0113d:	mov    r13d,0x4102b8
    7076cdd01143:	mov    QWORD PTR [r12+0x100],r13
    7076cdd0114b:	mov    r11,QWORD PTR [rsp]
    7076cdd0114f:	mov    QWORD PTR [r12+0x398],r11
    7076cdd01157:	mov    edi,0x4102b8
    7076cdd0115c:	mov    QWORD PTR [r12+0x100],rdi
    7076cdd01164:	add    rsp,0x10
    7076cdd01168:	jmp    QWORD PTR [rip+0x2]        # 0x7076cdd01170
    7076cdd0116e:	xchg   ax,ax
    7076cdd01170:	rex adc al,dl
    7076cdd01173:	int    0x76
    7076cdd01175:	jo     0x7076cdd01177
    7076cdd01177:	add    BYTE PTR [rax+0x76cdd011],al
    7076cdd0117d:	jo     0x7076cdd0117f
    7076cdd0117f:	add    BYTE PTR [rcx-0x45],cl
    7076cdd01182:	rex cdq
    7076cdd01184:	ds out 0x61,eax
    7076cdd01187:	pop    rbx
    7076cdd01188:	add    BYTE PTR [rax],al
    7076cdd0118a:	jmp    r11
    7076cdd0118d:	mov    eax,0x4102d0
    7076cdd01192:	mov    QWORD PTR [r12+0x100],rax
    7076cdd0119a:	push   rdx
    7076cdd0119b:	push   rsi
    7076cdd0119c:	push   r10
    7076cdd0119e:	push   r11
    7076cdd011a0:	mov    r11,rax
    7076cdd011a3:	lahf
    7076cdd011a4:	seto   al
    7076cdd011a7:	mov    WORD PTR [rsp+0x20],ax
    7076cdd011ac:	mov    rax,r11
    7076cdd011af:	mov    rdx,QWORD PTR [rsp+0x20]
    7076cdd011b4:	mov    r10d,edx
    7076cdd011b7:	and    r10d,0xc000
    7076cdd011be:	shl    r10d,0x10
    7076cdd011c2:	mov    r11d,edx
    7076cdd011c5:	and    r11d,0x100
    7076cdd011cc:	shl    r11d,0x15
    7076cdd011d0:	or     r10d,r11d
    7076cdd011d3:	and    edx,0x1
    7076cdd011d6:	shl    edx,0x1c
    7076cdd011d9:	or     r10d,edx
    7076cdd011dc:	btc    r10,0x1d
    7076cdd011e1:	mov    r11d,0xf0000000
    7076cdd011e7:	and    r11,r10
    7076cdd011ea:	movabs rsi,0xffffffff0fffffff
    7076cdd011f4:	and    rbx,rsi
    7076cdd011f7:	or     rbx,r11
    7076cdd011fa:	pop    r11
    7076cdd011fc:	pop    r10
    7076cdd011fe:	pop    rsi
    7076cdd011ff:	pop    rdx
    7076cdd01200:	mov    QWORD PTR [r12+0x108],rbx
    7076cdd01208:	add    rsp,0x10
    7076cdd0120c:	mov    eax,0xc
    7076cdd01211:	movabs r11,0x5b61e73e9ca0
    7076cdd0121b:	jmp    r11
    7076cdd0121e:	nop
    7076cdd0121f:	nop
