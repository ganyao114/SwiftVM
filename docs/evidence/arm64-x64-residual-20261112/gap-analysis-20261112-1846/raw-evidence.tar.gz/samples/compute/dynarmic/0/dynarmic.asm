0000705c0adce69b  nop [rax+rax*1], eax
0000705c0adce6a0  mov rax, [r15+0xF8]
0000705c0adce6a7  lea r14, [rax-0x1E0]
0000705c0adce6ae  mov [r15+0xF8], r14
0000705c0adce6b5  lea rax, [r14+0x1D0]
0000705c0adce6bc  mov r12, [r15+0xA0]
0000705c0adce6c3  mov r11, [r15+0x98]
0000705c0adce6ca  mov [r13+rax*1], r12
0000705c0adce6cf  lea rax, [r14+0x1D8]
0000705c0adce6d6  mov [r13+rax*1], r11
0000705c0adce6db  mov eax, 0x420AA0
0000705c0adce6e0  movups xmm1, [r13+rax*1]
0000705c0adce6e6  mov eax, 0x420A30
0000705c0adce6eb  movups xmm15, [r13+rax*1]
0000705c0adce6f1  mov eax, 0x420AC0
0000705c0adce6f6  movups xmm14, [r13+rax*1]
0000705c0adce6fc  mov eax, 0x420A60
0000705c0adce701  movups xmm13, [r13+rax*1]
0000705c0adce707  mov qword ptr [r15+0x98], 0x430CD0
0000705c0adce712  mov eax, 0x420AD0
0000705c0adce717  movups xmm12, [r13+rax*1]
0000705c0adce71d  mov eax, 0x430CD0
0000705c0adce722  movups [r13+rax*1], xmm1
0000705c0adce728  mov eax, 0x430CE0
0000705c0adce72d  movups [r13+rax*1], xmm15
0000705c0adce733  mov eax, 0x430CF0
0000705c0adce738  movups [r13+rax*1], xmm14
0000705c0adce73e  mov eax, 0x430D00
0000705c0adce743  movups [r13+rax*1], xmm13
0000705c0adce749  mov eax, 0x420A20
0000705c0adce74e  movups xmm14, [r13+rax*1]
0000705c0adce754  mov eax, 0x420A10
0000705c0adce759  movups xmm13, [r13+rax*1]
0000705c0adce75f  mov eax, 0x430DD0
0000705c0adce764  movups [r13+rax*1], xmm1
0000705c0adce76a  mov eax, 0x430DE0
0000705c0adce76f  movups [r13+rax*1], xmm15
0000705c0adce775  mov eax, 0x430D10
0000705c0adce77a  movups [r13+rax*1], xmm12
0000705c0adce780  mov eax, 0x430D20
0000705c0adce785  movups [r13+rax*1], xmm14
0000705c0adce78b  mov eax, 0x420A00
0000705c0adce790  movups xmm1, [r13+rax*1]
0000705c0adce796  mov eax, 0x420A70
0000705c0adce79b  movups xmm15, [r13+rax*1]
0000705c0adce7a1  mov eax, 0x430D30
0000705c0adce7a6  movups [r13+rax*1], xmm13
0000705c0adce7ac  mov eax, 0x430D40
0000705c0adce7b1  movups [r13+rax*1], xmm1
0000705c0adce7b7  mov eax, 0x420A80
0000705c0adce7bc  movups xmm1, [r13+rax*1]
0000705c0adce7c2  mov eax, 0x420A50
0000705c0adce7c7  movups xmm14, [r13+rax*1]
0000705c0adce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
0000705c0adce7d5  mov eax, 0x430D50
0000705c0adce7da  movups [r13+rax*1], xmm15
0000705c0adce7e0  mov eax, 0x430D60
0000705c0adce7e5  movups [r13+rax*1], xmm1
0000705c0adce7eb  mov eax, 0x420AF0
0000705c0adce7f0  movups xmm1, [r13+rax*1]
0000705c0adce7f6  mov eax, 0x420B00
0000705c0adce7fb  movups xmm15, [r13+rax*1]
0000705c0adce801  movaps [r15+0x150], xmm15
0000705c0adce809  mov qword ptr [r15+0xA0], 0x3E8
0000705c0adce814  mov eax, 0x430D70
0000705c0adce819  movups [r13+rax*1], xmm14
0000705c0adce81f  mov eax, 0x430D80
0000705c0adce824  movups [r13+rax*1], xmm1
0000705c0adce82a  mov eax, 0x420AE0
0000705c0adce82f  movups xmm1, [r13+rax*1]
0000705c0adce835  mov eax, 0x420A90
0000705c0adce83a  movups xmm14, [r13+rax*1]
0000705c0adce840  movaps [r15+0x140], xmm14
0000705c0adce848  lea rax, [r14+0x180]
0000705c0adce84f  movq xmm13, qword ptr [r15+0x200]
0000705c0adce858  movq xmm12, qword ptr [r15+0x1F0]
0000705c0adce861  movq r12, xmm13
0000705c0adce866  movq r11, xmm12
0000705c0adce86b  mov [r13+rax*1], r12
0000705c0adce870  lea rax, [r14+0x188]
0000705c0adce877  mov [r13+rax*1], r11
0000705c0adce87c  mov eax, 0x430D90
0000705c0adce881  movups [r13+rax*1], xmm15
0000705c0adce887  mov eax, 0x430DA0
0000705c0adce88c  movups [r13+rax*1], xmm1
0000705c0adce892  mov eax, 0x420AB0
0000705c0adce897  movups xmm1, [r13+rax*1]
0000705c0adce89d  mov eax, 0x420B18
0000705c0adce8a2  mov r12, [r13+rax*1]
0000705c0adce8a7  movq xmm15, r12
0000705c0adce8ac  mov qword ptr [r15+0x40], 0x420B20
0000705c0adce8b4  mov eax, 0x430DB0
0000705c0adce8b9  movups [r13+rax*1], xmm14
0000705c0adce8bf  mov eax, 0x430DC0
0000705c0adce8c4  movups [r13+rax*1], xmm1
0000705c0adce8ca  mov eax, 0x420B80
0000705c0adce8cf  movups xmm1, [r13+rax*1]
0000705c0adce8d5  movq rax, xmm15
0000705c0adce8da  mov r12d, 0x430DF0
0000705c0adce8e0  mov [r13+r12*1], rax
0000705c0adce8e5  mov eax, 0x420B60
0000705c0adce8ea  movups xmm15, [r13+rax*1]
0000705c0adce8f0  mov eax, 0x420B70
0000705c0adce8f5  movups xmm14, [r13+rax*1]
0000705c0adce8fb  lea rax, [r14+0x160]
0000705c0adce902  movups [r13+rax*1], xmm1
0000705c0adce908  lea rax, [r14+0x190]
0000705c0adce90f  movq xmm1, qword ptr [r15+0x1E0]
0000705c0adce918  movq xmm13, qword ptr [r15+0x1D0]
0000705c0adce921  movq r12, xmm1
0000705c0adce926  movq r11, xmm13
0000705c0adce92b  mov [r13+rax*1], r12
0000705c0adce930  lea rax, [r14+0x198]
0000705c0adce937  mov [r13+rax*1], r11
0000705c0adce93c  lea rax, [r14+0x140]
0000705c0adce943  movups [r13+rax*1], xmm15
0000705c0adce949  lea rax, [r14+0x150]
0000705c0adce950  movups [r13+rax*1], xmm14
0000705c0adce956  mov eax, 0x420B20
0000705c0adce95b  movups xmm1, [r13+rax*1]
0000705c0adce961  mov eax, 0x420B30
0000705c0adce966  movups xmm15, [r13+rax*1]
0000705c0adce96c  movaps [r15+0x120], xmm15
0000705c0adce974  lea rax, [r14+0x1A0]
0000705c0adce97b  movq xmm14, qword ptr [r15+0x1C0]
0000705c0adce984  movq xmm13, qword ptr [r15+0x1B0]
0000705c0adce98d  movq r12, xmm14
0000705c0adce992  movq r11, xmm13
0000705c0adce997  mov [r13+rax*1], r12
0000705c0adce99c  lea rax, [r14+0x1A8]
0000705c0adce9a3  mov [r13+rax*1], r11
0000705c0adce9a8  lea rax, [r14+0x1B0]
0000705c0adce9af  movq xmm14, qword ptr [r15+0x1A0]
0000705c0adce9b8  movq xmm13, qword ptr [r15+0x190]
0000705c0adce9c1  movq r12, xmm14
0000705c0adce9c6  movq r11, xmm13
0000705c0adce9cb  mov [r13+rax*1], r12
0000705c0adce9d0  lea rax, [r14+0x1B8]
0000705c0adce9d7  mov [r13+rax*1], r11
0000705c0adce9dc  lea rax, [r14+0x100]
0000705c0adce9e3  movups [r13+rax*1], xmm1
0000705c0adce9e9  lea rax, [r14+0x110]
0000705c0adce9f0  movups [r13+rax*1], xmm15
0000705c0adce9f6  mov eax, 0x420B40
0000705c0adce9fb  movups xmm1, [r13+rax*1]
0000705c0adcea01  mov eax, 0x420B50
0000705c0adcea06  movups xmm15, [r13+rax*1]
0000705c0adcea0c  movaps [r15+0x110], xmm1
0000705c0adcea14  movaps [r15+0x130], xmm15
0000705c0adcea1c  lea rax, [r14+0x1C0]
0000705c0adcea23  mov r12, [r15+0xE8]
0000705c0adcea2a  mov r11, [r15+0xF0]
0000705c0adcea31  mov [r13+rax*1], r12
0000705c0adcea36  lea rax, [r14+0x1C8]
0000705c0adcea3d  mov [r13+rax*1], r11
0000705c0adcea42  mov eax, 0x430DF8
0000705c0adcea47  mov r12d, 0x421DF8D3
0000705c0adcea4d  mov [r13+rax*1], r12d
0000705c0adcea52  lea rax, [r14+0x120]
0000705c0adcea59  movups [r13+rax*1], xmm1
0000705c0adcea5f  lea rax, [r14+0x130]
0000705c0adcea66  movups [r13+rax*1], xmm15
0000705c0adcea6c  lea rax, [r14+0x100]
0000705c0adcea73  mov [r15], rax
0000705c0adcea76  mov qword ptr [r15+0x08], 0x430CD0
0000705c0adcea7e  mov qword ptr [r15+0x10], 0x12C
0000705c0adcea86  mov qword ptr [r15+0xF0], 0x410284
0000705c0adcea91  mov r14d, [r15+0x320]
0000705c0adcea98  mov eax, 0x410284
0000705c0adcea9d  mov rcx, 0x705C0ADD07C0
0000705c0adceaa7  mov [r15+r14*8+0x328], rax
0000705c0adceaaf  mov [r15+r14*8+0x368], rcx
0000705c0adceab7  add r14d, 0x01
0000705c0adceabb  and r14d, 0x07
0000705c0adceabf  mov [r15+0x320], r14d
0000705c0adceac6  cmp dword ptr [r15+0x318], 0x00
0000705c0adceace  jz 0x0000705C0ADCED70
0000705c0adcead4  nop [rax+rax*1], ax
0000705c0adceadd  nop [rax+rax*1], eax
0000705c0adceae5  mov eax, 0x410728
0000705c0adceaea  mov [r15+0x100], rax
0000705c0adceaf1  jmp 0x0000705C0ABFE110
0000705c0adceaf6  int3
0000705c0adceaf7  call 0x0000705C0AC0BC20
0000705c0adceafc  jmp 0x0000705C0ADCE6CF
0000705c0adceb01  call 0x0000705C0AC0A9A0
0000705c0adceb06  jmp 0x0000705C0ADCE6DB
0000705c0adceb0b  call 0x0000705C0ABFF430
0000705c0adceb10  jmp 0x0000705C0ADCE6E6
0000705c0adceb15  call 0x0000705C0AC0E760
0000705c0adceb1a  jmp 0x0000705C0ADCE6F1
0000705c0adceb1f  call 0x0000705C0AC0D4E0
0000705c0adceb24  jmp 0x0000705C0ADCE6FC
0000705c0adceb29  call 0x0000705C0AC0C260
0000705c0adceb2e  jmp 0x0000705C0ADCE707
0000705c0adceb33  call 0x0000705C0AC0AFE0
0000705c0adceb38  jmp 0x0000705C0ADCE71D
0000705c0adceb3d  call 0x0000705C0ABFF540
0000705c0adceb42  jmp 0x0000705C0ADCE728
0000705c0adceb47  call 0x0000705C0AC0E880
0000705c0adceb4c  jmp 0x0000705C0ADCE733
0000705c0adceb51  call 0x0000705C0AC0D600
0000705c0adceb56  jmp 0x0000705C0ADCE73E
0000705c0adceb5b  call 0x0000705C0AC0C380
0000705c0adceb60  jmp 0x0000705C0ADCE749
0000705c0adceb65  call 0x0000705C0AC0D4E0
0000705c0adceb6a  jmp 0x0000705C0ADCE754
0000705c0adceb6f  call 0x0000705C0AC0C260
0000705c0adceb74  jmp 0x0000705C0ADCE75F
0000705c0adceb79  call 0x0000705C0ABFF540
0000705c0adceb7e  jmp 0x0000705C0ADCE76A
0000705c0adceb83  call 0x0000705C0AC0E880
0000705c0adceb88  jmp 0x0000705C0ADCE775
0000705c0adceb8d  call 0x0000705C0AC0B100
0000705c0adceb92  jmp 0x0000705C0ADCE780
0000705c0adceb97  call 0x0000705C0AC0D600
0000705c0adceb9c  jmp 0x0000705C0ADCE78B
0000705c0adceba1  call 0x0000705C0ABFF430
0000705c0adceba6  jmp 0x0000705C0ADCE796
0000705c0adcebab  call 0x0000705C0AC0E760
0000705c0adcebb0  jmp 0x0000705C0ADCE7A1
0000705c0adcebb5  call 0x0000705C0AC0C380
0000705c0adcebba  jmp 0x0000705C0ADCE7AC
0000705c0adcebbf  call 0x0000705C0ABFF540
0000705c0adcebc4  jmp 0x0000705C0ADCE7B7
0000705c0adcebc9  call 0x0000705C0ABFF430
0000705c0adcebce  jmp 0x0000705C0ADCE7C2
0000705c0adcebd3  call 0x0000705C0AC0D4E0
0000705c0adcebd8  jmp 0x0000705C0ADCE7CD
0000705c0adcebdd  call 0x0000705C0AC0E880
0000705c0adcebe2  jmp 0x0000705C0ADCE7E0
0000705c0adcebe7  call 0x0000705C0ABFF540
0000705c0adcebec  jmp 0x0000705C0ADCE7EB
0000705c0adcebf1  call 0x0000705C0ABFF430
0000705c0adcebf6  jmp 0x0000705C0ADCE7F6
0000705c0adcebfb  call 0x0000705C0AC0E760
0000705c0adcec00  jmp 0x0000705C0ADCE801
0000705c0adcec05  call 0x0000705C0AC0D600
0000705c0adcec0a  jmp 0x0000705C0ADCE81F
0000705c0adcec0f  call 0x0000705C0ABFF540
0000705c0adcec14  jmp 0x0000705C0ADCE82A
0000705c0adcec19  call 0x0000705C0ABFF430
0000705c0adcec1e  jmp 0x0000705C0ADCE835
0000705c0adcec23  call 0x0000705C0AC0D4E0
0000705c0adcec28  jmp 0x0000705C0ADCE840
0000705c0adcec2d  call 0x0000705C0AC0BC20
0000705c0adcec32  jmp 0x0000705C0ADCE870
0000705c0adcec37  call 0x0000705C0AC0A9A0
0000705c0adcec3c  jmp 0x0000705C0ADCE87C
0000705c0adcec41  call 0x0000705C0AC0E880
0000705c0adcec46  jmp 0x0000705C0ADCE887
0000705c0adcec4b  call 0x0000705C0ABFF540
0000705c0adcec50  jmp 0x0000705C0ADCE892
0000705c0adcec55  call 0x0000705C0ABFF430
0000705c0adcec5a  jmp 0x0000705C0ADCE89D
0000705c0adcec5f  call 0x0000705C0AC0B720
0000705c0adcec64  jmp 0x0000705C0ADCE8A7
0000705c0adcec69  call 0x0000705C0AC0D600
0000705c0adcec6e  jmp 0x0000705C0ADCE8BF
0000705c0adcec73  call 0x0000705C0ABFF540
0000705c0adcec78  jmp 0x0000705C0ADCE8CA
0000705c0adcec7d  call 0x0000705C0ABFF430
0000705c0adcec82  jmp 0x0000705C0ADCE8D5
0000705c0adcec87  call 0x0000705C0ACB4CB0
0000705c0adcec8c  jmp 0x0000705C0ADCE8E5
0000705c0adcec91  call 0x0000705C0AC0E760
0000705c0adcec96  jmp 0x0000705C0ADCE8F0
0000705c0adcec9b  call 0x0000705C0AC0D4E0
0000705c0adceca0  jmp 0x0000705C0ADCE8FB
0000705c0adceca5  call 0x0000705C0ABFF540
0000705c0adcecaa  jmp 0x0000705C0ADCE908
0000705c0adcecaf  call 0x0000705C0AC0BC20
0000705c0adcecb4  jmp 0x0000705C0ADCE930
0000705c0adcecb9  call 0x0000705C0AC0A9A0
0000705c0adcecbe  jmp 0x0000705C0ADCE93C
0000705c0adcecc3  call 0x0000705C0AC0E880
0000705c0adcecc8  jmp 0x0000705C0ADCE949
0000705c0adceccd  call 0x0000705C0AC0D600
0000705c0adcecd2  jmp 0x0000705C0ADCE956
0000705c0adcecd7  call 0x0000705C0ABFF430
0000705c0adcecdc  jmp 0x0000705C0ADCE961
0000705c0adcece1  call 0x0000705C0AC0E760
0000705c0adcece6  jmp 0x0000705C0ADCE96C
0000705c0adceceb  call 0x0000705C0AC0BC20
0000705c0adcecf0  jmp 0x0000705C0ADCE99C
0000705c0adcecf5  call 0x0000705C0AC0A9A0
0000705c0adcecfa  jmp 0x0000705C0ADCE9A8
0000705c0adcecff  call 0x0000705C0AC0BC20
0000705c0adced04  jmp 0x0000705C0ADCE9D0
0000705c0adced09  call 0x0000705C0AC0A9A0
0000705c0adced0e  jmp 0x0000705C0ADCE9DC
0000705c0adced13  call 0x0000705C0ABFF540
0000705c0adced18  jmp 0x0000705C0ADCE9E9
0000705c0adced1d  call 0x0000705C0AC0E880
0000705c0adced22  jmp 0x0000705C0ADCE9F6
0000705c0adced27  call 0x0000705C0ABFF430
0000705c0adced2c  jmp 0x0000705C0ADCEA01
0000705c0adced31  call 0x0000705C0AC0E760
0000705c0adced36  jmp 0x0000705C0ADCEA0C
0000705c0adced3b  call 0x0000705C0AC0BC20
0000705c0adced40  jmp 0x0000705C0ADCEA36
0000705c0adced45  call 0x0000705C0AC0A9A0
0000705c0adced4a  jmp 0x0000705C0ADCEA42
0000705c0adced4f  call 0x0000705C0AC0BAE0
0000705c0adced54  jmp 0x0000705C0ADCEA52
0000705c0adced59  call 0x0000705C0ABFF540
0000705c0adced5e  jmp 0x0000705C0ADCEA5F
0000705c0adced63  call 0x0000705C0AC0E880
0000705c0adced68  jmp 0x0000705C0ADCEA6C
0000705c0adced6d  int3
0000705c0adced6e  nop
0000705c0adced70  mov rax, [r15]
0000705c0adced73  lea r14, [rax+0x20]
0000705c0adced77  mov r12, [r13+r14*1]
0000705c0adced7c  mov r14, [r15+0x10]
0000705c0adced80  lea r11, [r12+r14*1]
0000705c0adced84  mov [r15+0x40], r11
0000705c0adced88  lea r12, [rax+0x20]
0000705c0adced8c  mov [r13+r12*1], r11
0000705c0adced91  test r14, r14
0000705c0adced94  setz r14b
0000705c0adced98  movzx r14, r14b
0000705c0adced9c  mov [rsp+0x414], r14b
0000705c0adceda4  cmp byte ptr [rsp+0x414], 0x00
0000705c0adcedac  jz 0x0000705C0ADCEDDE
0000705c0adcedae  cmp dword ptr [r15+0x318], 0x00
0000705c0adcedb6  mov eax, 0x4109A0
0000705c0adcedbb  mov [r15+0x100], rax
0000705c0adcedc2  jz 0x0000705C0ABFE0A0
0000705c0adcedc8  nop [rax+rax*1], eax
0000705c0adcedcd  mov eax, 0x4109A0
0000705c0adcedd2  mov [r15+0x100], rax
0000705c0adcedd9  jmp 0x0000705C0ABFE110
0000705c0adcedde  cmp dword ptr [r15+0x318], 0x00
0000705c0adcede6  jz 0x0000705C0ADCEE30
0000705c0adcedec  nop [rax+rax*1], ax
0000705c0adcedf5  nop [rax+rax*1], eax
0000705c0adcedfd  mov eax, 0x410738
0000705c0adcee02  mov [r15+0x100], rax
0000705c0adcee09  jmp 0x0000705C0ABFE110
0000705c0adcee0e  int3
0000705c0adcee0f  call 0x0000705C0ACE27E0
0000705c0adcee14  jmp 0x0000705C0ADCED7C
0000705c0adcee19  call 0x0000705C0ACC0860
0000705c0adcee1e  jmp 0x0000705C0ADCED91
0000705c0adcee23  int3
0000705c0adcee24  nop [rax+rax*1], ax
0000705c0adcee2d  nop [rax], eax
0000705c0adcee30  mov rax, [r15+0xF8]
0000705c0adcee37  lea r14, [rax-0x150]
0000705c0adcee3e  mov [r15+0xF8], r14
0000705c0adcee45  mov rax, [r15]
0000705c0adcee48  lea r12, [rax+0x68]
0000705c0adcee4c  mov r11, [r13+r12*1]
0000705c0adcee51  mov [r15+0x88], r11
0000705c0adcee58  lea r12, [rax+0x28]
0000705c0adcee5c  mov [r15+0x40], r12
0000705c0adcee60  mov [r15+0x48], r14
0000705c0adcee64  mov qword ptr [r15+0x50], 0x420B90
0000705c0adcee6c  lea rax, [r14+0x100]
0000705c0adcee73  mov r12, [r15+0xE8]
0000705c0adcee7a  mov r11, [r15+0xD8]
0000705c0adcee81  mov [r13+rax*1], r12
0000705c0adcee86  lea rax, [r14+0x108]
0000705c0adcee8d  mov [r13+rax*1], r11
0000705c0adcee92  lea rax, [r14+0x110]
0000705c0adcee99  mov r12, [r15+0xD0]
0000705c0adceea0  mov r11, [r15+0xC8]
0000705c0adceea7  mov [r13+rax*1], r12
0000705c0adceeac  lea rax, [r14+0x118]
0000705c0adceeb3  mov [r13+rax*1], r11
0000705c0adceeb8  lea rax, [r14+0x120]
0000705c0adceebf  mov r12, [r15+0xC0]
0000705c0adceec6  mov r11, [r15+0xB8]
0000705c0adceecd  mov [r13+rax*1], r12
0000705c0adceed2  lea rax, [r14+0x128]
0000705c0adceed9  mov [r13+rax*1], r11
0000705c0adceede  lea rax, [r14+0x130]
0000705c0adceee5  mov r12, [r15+0xB0]
0000705c0adceeec  mov r11, [r15+0xA8]
0000705c0adceef3  mov [r13+rax*1], r12
0000705c0adceef8  lea rax, [r14+0x138]
0000705c0adceeff  mov [r13+rax*1], r11
0000705c0adcef04  lea rax, [r14+0x140]
0000705c0adcef0b  mov r12, [r15+0xA0]
0000705c0adcef12  mov r11, [r15+0x98]
0000705c0adcef19  mov [r13+rax*1], r12
0000705c0adcef1e  lea rax, [r14+0x148]
0000705c0adcef25  mov [r13+rax*1], r11
0000705c0adcef2a  cmp dword ptr [r15+0x318], 0x00
0000705c0adcef32  jz 0x0000705C0ADCEFD0
0000705c0adcef38  nop [rax+rax*1], ax
0000705c0adcef41  nop [rax+rax*1], eax
0000705c0adcef49  mov eax, 0x410770
0000705c0adcef4e  mov [r15+0x100], rax
0000705c0adcef55  jmp 0x0000705C0ABFE110
0000705c0adcef5a  int3
0000705c0adcef5b  call 0x0000705C0ACC0370
0000705c0adcef60  jmp 0x0000705C0ADCEE51
0000705c0adcef65  call 0x0000705C0AC0BC20
0000705c0adcef6a  jmp 0x0000705C0ADCEE86
0000705c0adcef6f  call 0x0000705C0AC0A9A0
0000705c0adcef74  jmp 0x0000705C0ADCEE92
0000705c0adcef79  call 0x0000705C0AC0BC20
0000705c0adcef7e  jmp 0x0000705C0ADCEEAC
0000705c0adcef83  call 0x0000705C0AC0A9A0
0000705c0adcef88  jmp 0x0000705C0ADCEEB8
0000705c0adcef8d  call 0x0000705C0AC0BC20
0000705c0adcef92  jmp 0x0000705C0ADCEED2
0000705c0adcef97  call 0x0000705C0AC0A9A0
0000705c0adcef9c  jmp 0x0000705C0ADCEEDE
0000705c0adcefa1  call 0x0000705C0AC0BC20
0000705c0adcefa6  jmp 0x0000705C0ADCEEF8
0000705c0adcefab  call 0x0000705C0AC0A9A0
0000705c0adcefb0  jmp 0x0000705C0ADCEF04
0000705c0adcefb5  call 0x0000705C0AC0BC20
0000705c0adcefba  jmp 0x0000705C0ADCEF1E
0000705c0adcefbf  call 0x0000705C0AC0A9A0
0000705c0adcefc4  jmp 0x0000705C0ADCEF2A
0000705c0adcefc9  int3
0000705c0adcefca  nop [rax+rax*1], ax
0000705c0adcefd0  mov rax, [r15+0x08]
0000705c0adcefd4  movzx r14d, byte ptr [r13+rax*1]
0000705c0adcefda  movzx r14d, r14b
0000705c0adcefde  mov [rsp+0x10], r14d
0000705c0adcefe3  mov r14d, r14d
0000705c0adcefe6  mov [r15+0x58], r14
0000705c0adcefea  lea r14, [rax+0x01]
0000705c0adcefee  mov [r15+0x08], r14
0000705c0adceff2  mov rax, [r15+0x88]
0000705c0adceff9  lea r14, [rax+0x01]
0000705c0adceffd  mov r12, [r15]
0000705c0adcf000  lea r11, [r12+0x68]
0000705c0adcf005  mov [r13+r11*1], r14
0000705c0adcf00a  lea r14, [r12+rax*1]
0000705c0adcf00e  mov [r15+0x60], r14
0000705c0adcf012  lea rax, [r14+0x28]
0000705c0adcf016  mov r11d, [rsp+0x10]
0000705c0adcf01b  movzx r14d, r11b
0000705c0adcf01f  mov [r13+rax*1], r14b
0000705c0adcf024  lea rax, [r12+0x68]
0000705c0adcf029  mov r14, [r13+rax*1]
0000705c0adcf02e  mov [r15+0x88], r14
0000705c0adcf035  xor eax, eax
0000705c0adcf037  mov r12d, 0x40
0000705c0adcf03d  cmp r14, r12
0000705c0adcf040  cmc
0000705c0adcf041  lahf
0000705c0adcf042  seto al
0000705c0adcf045  mov [r15+0x108], eax
0000705c0adcf04c  mov eax, [r15+0x108]
0000705c0adcf053  sahf
0000705c0adcf054  jnz 0x0000705C0ADCF086
0000705c0adcf056  cmp dword ptr [r15+0x318], 0x00
0000705c0adcf05e  jz 0x0000705C0ADCF170
0000705c0adcf064  nop [rax+rax*1], ax
0000705c0adcf06d  nop [rax+rax*1], eax
0000705c0adcf075  mov eax, 0x410790
0000705c0adcf07a  mov [r15+0x100], rax
0000705c0adcf081  jmp 0x0000705C0ABFE110
0000705c0adcf086  cmp dword ptr [r15+0x318], 0x00
0000705c0adcf08e  jz 0x0000705C0ADCF0E0
0000705c0adcf094  nop [rax+rax*1], ax
0000705c0adcf09d  nop [rax+rax*1], eax
0000705c0adcf0a5  mov eax, 0x410768
0000705c0adcf0aa  mov [r15+0x100], rax
0000705c0adcf0b1  jmp 0x0000705C0ABFE110
0000705c0adcf0b6  int3
0000705c0adcf0b7  call 0x0000705C0AC0D860
0000705c0adcf0bc  jmp 0x0000705C0ADCEFDA
0000705c0adcf0c1  call 0x0000705C0ACB36E0
0000705c0adcf0c6  jmp 0x0000705C0ADCF00A
0000705c0adcf0cb  call 0x0000705C0AC0DD60
0000705c0adcf0d0  jmp 0x0000705C0ADCF024
0000705c0adcf0d5  call 0x0000705C0AC0DC20
0000705c0adcf0da  jmp 0x0000705C0ADCF02E
0000705c0adcf0df  int3
0000705c0adcf0e0  mov rax, [r15+0x10]
0000705c0adcf0e4  lea r14, [rax-0x01]
0000705c0adcf0e8  mov [r15+0x10], r14
0000705c0adcf0ec  test r14, r14
0000705c0adcf0ef  setz r14b
0000705c0adcf0f3  movzx r14, r14b
0000705c0adcf0f7  mov [rsp+0x414], r14b
0000705c0adcf0ff  cmp byte ptr [rsp+0x414], 0x00
0000705c0adcf107  jz 0x0000705C0ADCF139
0000705c0adcf109  cmp dword ptr [r15+0x318], 0x00
0000705c0adcf111  jz 0x0000705C0ADD0670
0000705c0adcf117  nop [rax+rax*1], ax
0000705c0adcf120  nop [rax+rax*1], eax
0000705c0adcf128  mov eax, 0x410988
0000705c0adcf12d  mov [r15+0x100], rax
0000705c0adcf134  jmp 0x0000705C0ABFE110
0000705c0adcf139  cmp dword ptr [r15+0x318], 0x00
0000705c0adcf141  jz 0x0000705C0ADCEFD0
0000705c0adcf147  nop [rax+rax*1], ax
0000705c0adcf150  nop [rax+rax*1], eax
0000705c0adcf158  mov eax, 0x410770
0000705c0adcf15d  mov [r15+0x100], rax
0000705c0adcf164  jmp 0x0000705C0ABFE110
0000705c0adcf169  int3
0000705c0adcf16a  int3
0000705c0adcf16b  nop [rax+rax*1], eax
0000705c0adcf170  mov rax, [r15+0x40]
0000705c0adcf174  movzx r14d, byte ptr [r13+rax*1]
0000705c0adcf17a  movaps xmm1, [r15+0x110]
0000705c0adcf182  pinsrb xmm1, r14d, 0x00
0000705c0adcf189  lea r14, [rax+0x01]
0000705c0adcf18d  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf193  movaps xmm15, [r15+0x120]
0000705c0adcf19b  pinsrb xmm15, r12d, 0x00
0000705c0adcf1a2  lea r14, [rax+0x02]
0000705c0adcf1a6  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf1ac  movaps xmm14, [r15+0x130]
0000705c0adcf1b4  pinsrb xmm14, r12d, 0x00
0000705c0adcf1bb  lea r14, [rax+0x03]
0000705c0adcf1bf  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf1c5  movaps xmm13, [r15+0x140]
0000705c0adcf1cd  pinsrb xmm13, r12d, 0x00
0000705c0adcf1d4  lea r14, [rax+0x04]
0000705c0adcf1d8  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf1de  pinsrb xmm1, r12d, 0x01
0000705c0adcf1e5  lea r14, [rax+0x05]
0000705c0adcf1e9  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf1ef  pinsrb xmm15, r12d, 0x01
0000705c0adcf1f6  lea r14, [rax+0x06]
0000705c0adcf1fa  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf200  pinsrb xmm14, r12d, 0x01
0000705c0adcf207  lea r14, [rax+0x07]
0000705c0adcf20b  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf211  pinsrb xmm13, r12d, 0x01
0000705c0adcf218  lea r14, [rax+0x08]
0000705c0adcf21c  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf222  pinsrb xmm1, r12d, 0x02
0000705c0adcf229  lea r14, [rax+0x09]
0000705c0adcf22d  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf233  pinsrb xmm15, r12d, 0x02
0000705c0adcf23a  lea r14, [rax+0x0A]
0000705c0adcf23e  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf244  pinsrb xmm14, r12d, 0x02
0000705c0adcf24b  lea r14, [rax+0x0B]
0000705c0adcf24f  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf255  pinsrb xmm13, r12d, 0x02
0000705c0adcf25c  lea r14, [rax+0x0C]
0000705c0adcf260  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf266  pinsrb xmm1, r12d, 0x03
0000705c0adcf26d  lea r14, [rax+0x0D]
0000705c0adcf271  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf277  pinsrb xmm15, r12d, 0x03
0000705c0adcf27e  lea r14, [rax+0x0E]
0000705c0adcf282  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf288  pinsrb xmm14, r12d, 0x03
0000705c0adcf28f  lea r14, [rax+0x0F]
0000705c0adcf293  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf299  pinsrb xmm13, r12d, 0x03
0000705c0adcf2a0  lea r14, [rax+0x10]
0000705c0adcf2a4  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf2aa  pinsrb xmm1, r12d, 0x04
0000705c0adcf2b1  lea r14, [rax+0x11]
0000705c0adcf2b5  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf2bb  pinsrb xmm15, r12d, 0x04
0000705c0adcf2c2  lea r14, [rax+0x12]
0000705c0adcf2c6  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf2cc  pinsrb xmm14, r12d, 0x04
0000705c0adcf2d3  lea r14, [rax+0x13]
0000705c0adcf2d7  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf2dd  pinsrb xmm13, r12d, 0x04
0000705c0adcf2e4  lea r14, [rax+0x14]
0000705c0adcf2e8  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf2ee  pinsrb xmm1, r12d, 0x05
0000705c0adcf2f5  lea r14, [rax+0x15]
0000705c0adcf2f9  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf2ff  pinsrb xmm15, r12d, 0x05
0000705c0adcf306  lea r14, [rax+0x16]
0000705c0adcf30a  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf310  pinsrb xmm14, r12d, 0x05
0000705c0adcf317  lea r14, [rax+0x17]
0000705c0adcf31b  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf321  pinsrb xmm13, r12d, 0x05
0000705c0adcf328  lea r14, [rax+0x18]
0000705c0adcf32c  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf332  pinsrb xmm1, r12d, 0x06
0000705c0adcf339  lea r14, [rax+0x19]
0000705c0adcf33d  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf343  pinsrb xmm15, r12d, 0x06
0000705c0adcf34a  lea r14, [rax+0x1A]
0000705c0adcf34e  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf354  pinsrb xmm14, r12d, 0x06
0000705c0adcf35b  lea r14, [rax+0x1B]
0000705c0adcf35f  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf365  pinsrb xmm13, r12d, 0x06
0000705c0adcf36c  lea r14, [rax+0x1C]
0000705c0adcf370  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf376  pinsrb xmm1, r12d, 0x07
0000705c0adcf37d  lea r14, [rax+0x1D]
0000705c0adcf381  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf387  pinsrb xmm15, r12d, 0x07
0000705c0adcf38e  lea r14, [rax+0x1E]
0000705c0adcf392  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf398  pinsrb xmm14, r12d, 0x07
0000705c0adcf39f  lea r14, [rax+0x1F]
0000705c0adcf3a3  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf3a9  pinsrb xmm13, r12d, 0x07
0000705c0adcf3b0  lea r14, [rax+0x20]
0000705c0adcf3b4  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf3ba  pinsrb xmm1, r12d, 0x08
0000705c0adcf3c1  lea r14, [rax+0x21]
0000705c0adcf3c5  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf3cb  pinsrb xmm15, r12d, 0x08
0000705c0adcf3d2  lea r14, [rax+0x22]
0000705c0adcf3d6  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf3dc  pinsrb xmm14, r12d, 0x08
0000705c0adcf3e3  lea r14, [rax+0x23]
0000705c0adcf3e7  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf3ed  pinsrb xmm13, r12d, 0x08
0000705c0adcf3f4  lea r14, [rax+0x24]
0000705c0adcf3f8  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf3fe  pinsrb xmm1, r12d, 0x09
0000705c0adcf405  lea r14, [rax+0x25]
0000705c0adcf409  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf40f  pinsrb xmm15, r12d, 0x09
0000705c0adcf416  lea r14, [rax+0x26]
0000705c0adcf41a  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf420  pinsrb xmm14, r12d, 0x09
0000705c0adcf427  lea r14, [rax+0x27]
0000705c0adcf42b  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf431  pinsrb xmm13, r12d, 0x09
0000705c0adcf438  lea r14, [rax+0x28]
0000705c0adcf43c  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf442  pinsrb xmm1, r12d, 0x0A
0000705c0adcf449  lea r14, [rax+0x29]
0000705c0adcf44d  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf453  pinsrb xmm15, r12d, 0x0A
0000705c0adcf45a  lea r14, [rax+0x2A]
0000705c0adcf45e  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf464  pinsrb xmm14, r12d, 0x0A
0000705c0adcf46b  lea r14, [rax+0x2B]
0000705c0adcf46f  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf475  pinsrb xmm13, r12d, 0x0A
0000705c0adcf47c  lea r14, [rax+0x2C]
0000705c0adcf480  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf486  pinsrb xmm1, r12d, 0x0B
0000705c0adcf48d  lea r14, [rax+0x2D]
0000705c0adcf491  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf497  pinsrb xmm15, r12d, 0x0B
0000705c0adcf49e  lea r14, [rax+0x2E]
0000705c0adcf4a2  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf4a8  pinsrb xmm14, r12d, 0x0B
0000705c0adcf4af  lea r14, [rax+0x2F]
0000705c0adcf4b3  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf4b9  pinsrb xmm13, r12d, 0x0B
0000705c0adcf4c0  lea r14, [rax+0x30]
0000705c0adcf4c4  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf4ca  pinsrb xmm1, r12d, 0x0C
0000705c0adcf4d1  lea r14, [rax+0x31]
0000705c0adcf4d5  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf4db  pinsrb xmm15, r12d, 0x0C
0000705c0adcf4e2  lea r14, [rax+0x32]
0000705c0adcf4e6  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf4ec  pinsrb xmm14, r12d, 0x0C
0000705c0adcf4f3  lea r14, [rax+0x33]
0000705c0adcf4f7  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf4fd  pinsrb xmm13, r12d, 0x0C
0000705c0adcf504  lea r14, [rax+0x34]
0000705c0adcf508  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf50e  pinsrb xmm1, r12d, 0x0D
0000705c0adcf515  lea r14, [rax+0x35]
0000705c0adcf519  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf51f  pinsrb xmm15, r12d, 0x0D
0000705c0adcf526  lea r14, [rax+0x36]
0000705c0adcf52a  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf530  pinsrb xmm14, r12d, 0x0D
0000705c0adcf537  lea r14, [rax+0x37]
0000705c0adcf53b  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf541  pinsrb xmm13, r12d, 0x0D
0000705c0adcf548  lea r14, [rax+0x38]
0000705c0adcf54c  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf552  pinsrb xmm1, r12d, 0x0E
0000705c0adcf559  lea r14, [rax+0x39]
0000705c0adcf55d  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf563  pinsrb xmm15, r12d, 0x0E
0000705c0adcf56a  lea r14, [rax+0x3A]
0000705c0adcf56e  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf574  pinsrb xmm14, r12d, 0x0E
0000705c0adcf57b  lea r14, [rax+0x3B]
0000705c0adcf57f  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf585  pinsrb xmm13, r12d, 0x0E
0000705c0adcf58c  lea r14, [rax+0x3C]
0000705c0adcf590  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf596  pinsrb xmm1, r12d, 0x0F
0000705c0adcf59d  movaps [r15+0x110], xmm1
0000705c0adcf5a5  lea r14, [rax+0x3D]
0000705c0adcf5a9  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf5af  pinsrb xmm15, r12d, 0x0F
0000705c0adcf5b6  movaps [r15+0x120], xmm15
0000705c0adcf5be  lea r14, [rax+0x3E]
0000705c0adcf5c2  movzx r12d, byte ptr [r13+r14*1]
0000705c0adcf5c8  pinsrb xmm14, r12d, 0x0F
0000705c0adcf5cf  movaps [r15+0x130], xmm14
0000705c0adcf5d7  lea r14, [rax+0x3F]
0000705c0adcf5db  movzx eax, byte ptr [r13+r14*1]
0000705c0adcf5e1  pinsrb xmm13, eax, 0x0F
0000705c0adcf5e8  movaps [r15+0x140], xmm13
0000705c0adcf5f0  movq xmm1, qword ptr [r15+0x120]
0000705c0adcf5f9  pmovzxbw xmm1, xmm1
0000705c0adcf5fe  psllw xmm1, 0x00
0000705c0adcf603  movaps [r15+0x150], xmm1
0000705c0adcf60b  movq xmm1, qword ptr [r15+0x130]
0000705c0adcf614  pmovzxbw xmm1, xmm1
0000705c0adcf619  psllw xmm1, 0x00
0000705c0adcf61e  movaps [r15+0x160], xmm1
0000705c0adcf626  movq xmm1, qword ptr [r15+0x110]
0000705c0adcf62f  pmovzxbw xmm1, xmm1
0000705c0adcf634  psllw xmm1, 0x00
0000705c0adcf639  movaps [r15+0x170], xmm1
0000705c0adcf641  movaps xmm15, [r15+0x110]
0000705c0adcf649  pextrq rax, xmm15, 0x01
0000705c0adcf650  movq xmm15, rax
0000705c0adcf655  pmovzxbw xmm15, xmm15
0000705c0adcf65b  psllw xmm15, 0x00
0000705c0adcf661  movaps [r15+0x180], xmm15
0000705c0adcf669  movaps xmm14, [r15+0x120]
0000705c0adcf671  pextrq rax, xmm14, 0x01
0000705c0adcf678  movq xmm14, rax
0000705c0adcf67d  pmovzxbw xmm14, xmm14
0000705c0adcf683  psllw xmm14, 0x00
0000705c0adcf689  movaps [r15+0x210], xmm14
0000705c0adcf691  movaps xmm13, [r15+0x130]
0000705c0adcf699  pextrq rax, xmm13, 0x01
0000705c0adcf6a0  movq xmm13, rax
0000705c0adcf6a5  pmovzxbw xmm13, xmm13
0000705c0adcf6ab  psllw xmm13, 0x00
0000705c0adcf6b1  movaps [r15+0x220], xmm13
0000705c0adcf6b9  movq xmm12, qword ptr [r15+0x140]
0000705c0adcf6c2  pmovzxbw xmm12, xmm12
0000705c0adcf6c8  psllw xmm12, 0x00
0000705c0adcf6ce  movaps [r15+0x250], xmm12
0000705c0adcf6d6  movaps xmm12, [r15+0x140]
0000705c0adcf6de  pextrq rax, xmm12, 0x01
0000705c0adcf6e5  movq xmm12, rax
0000705c0adcf6ea  pmovzxbw xmm12, xmm12
0000705c0adcf6f0  psllw xmm12, 0x00
0000705c0adcf6f6  movaps [r15+0x110], xmm12
0000705c0adcf6fe  movq xmm11, qword ptr [r15+0x150]
0000705c0adcf707  pmovzxwd xmm11, xmm11
0000705c0adcf70d  pslld xmm11, 0x10
0000705c0adcf713  movq xmm10, qword ptr [r15+0x160]
0000705c0adcf71c  pmovzxwd xmm10, xmm10
0000705c0adcf722  pslld xmm10, 0x08
0000705c0adcf728  pextrq rax, xmm1, 0x01
0000705c0adcf72f  movq xmm1, rax
0000705c0adcf734  pmovzxwd xmm1, xmm1
0000705c0adcf739  pslld xmm1, 0x00
0000705c0adcf73e  movaps [r15+0x260], xmm1
0000705c0adcf746  pextrq rax, xmm15, 0x01
0000705c0adcf74d  movq xmm15, rax
0000705c0adcf752  pmovzxwd xmm15, xmm15
0000705c0adcf758  pslld xmm15, 0x00
0000705c0adcf75e  movaps [r15+0x270], xmm15
0000705c0adcf766  movq xmm9, qword ptr [r15+0x170]
0000705c0adcf76f  pmovzxwd xmm9, xmm9
0000705c0adcf775  pslld xmm9, 0x00
0000705c0adcf77b  pextrq rax, xmm14, 0x01
0000705c0adcf782  movq xmm14, rax
0000705c0adcf787  pmovzxwd xmm14, xmm14
0000705c0adcf78d  pslld xmm14, 0x10
0000705c0adcf793  movaps [r15+0x280], xmm14
0000705c0adcf79b  movq xmm8, qword ptr [r15+0x180]
0000705c0adcf7a4  pmovzxwd xmm8, xmm8
0000705c0adcf7aa  pslld xmm8, 0x00
0000705c0adcf7b0  movq xmm7, qword ptr [r15+0x210]
0000705c0adcf7b9  pmovzxwd xmm7, xmm7
0000705c0adcf7be  pslld xmm7, 0x10
0000705c0adcf7c3  movaps xmm6, [r15+0x150]
0000705c0adcf7cb  pextrq rax, xmm6, 0x01
0000705c0adcf7d2  movq xmm6, rax
0000705c0adcf7d7  pmovzxwd xmm6, xmm6
0000705c0adcf7dc  pslld xmm6, 0x10
0000705c0adcf7e1  por xmm11, xmm10
0000705c0adcf7e6  movaps [r15+0x230], xmm11
0000705c0adcf7ee  pextrq rax, xmm13, 0x01
0000705c0adcf7f5  movq xmm13, rax
0000705c0adcf7fa  pmovzxwd xmm13, xmm13
0000705c0adcf800  pslld xmm13, 0x08
0000705c0adcf806  movaps [r15+0x240], xmm13
0000705c0adcf80e  movq xmm10, qword ptr [r15+0x220]
0000705c0adcf817  pmovzxwd xmm10, xmm10
0000705c0adcf81d  pslld xmm10, 0x08
0000705c0adcf823  movaps xmm5, [r15+0x160]
0000705c0adcf82b  pextrq rax, xmm5, 0x01
0000705c0adcf832  movq xmm5, rax
0000705c0adcf837  pmovzxwd xmm5, xmm5
0000705c0adcf83c  pslld xmm5, 0x08
0000705c0adcf841  pslld xmm9, 0x18
0000705c0adcf847  pslld xmm15, 0x18
0000705c0adcf84d  pslld xmm8, 0x18
0000705c0adcf853  movq xmm4, qword ptr [r15+0x250]
0000705c0adcf85c  pmovzxwd xmm4, xmm4
0000705c0adcf861  pslld xmm4, 0x00
0000705c0adcf866  por xmm14, xmm13
0000705c0adcf86b  por xmm7, xmm10
0000705c0adcf870  movaps [r15+0x210], xmm7
0000705c0adcf878  pslld xmm1, 0x18
0000705c0adcf87d  movaps [r15+0x220], xmm1
0000705c0adcf885  por xmm6, xmm5
0000705c0adcf889  por xmm11, xmm9
0000705c0adcf88e  movaps [r15+0x160], xmm11
0000705c0adcf896  pextrq rax, xmm12, 0x01
0000705c0adcf89d  movq xmm13, rax
0000705c0adcf8a2  pmovzxwd xmm13, xmm13
0000705c0adcf8a8  pslld xmm13, 0x00
0000705c0adcf8ae  movaps [r15+0x170], xmm13
0000705c0adcf8b6  movq xmm12, qword ptr [r15+0x110]
0000705c0adcf8bf  pmovzxwd xmm12, xmm12
0000705c0adcf8c5  pslld xmm12, 0x00
0000705c0adcf8cb  por xmm14, xmm15
0000705c0adcf8d0  por xmm7, xmm8
0000705c0adcf8d5  movaps xmm15, [r15+0x250]
0000705c0adcf8dd  pextrq rax, xmm15, 0x01
0000705c0adcf8e4  movq xmm15, rax
0000705c0adcf8e9  pmovzxwd xmm15, xmm15
0000705c0adcf8ef  pslld xmm15, 0x00
0000705c0adcf8f5  movaps [r15+0x180], xmm15
0000705c0adcf8fd  por xmm6, xmm1
0000705c0adcf901  movaps [r15+0x150], xmm6
0000705c0adcf909  por xmm11, xmm4
0000705c0adcf90e  movaps [r15+0x140], xmm11
0000705c0adcf916  por xmm7, xmm12
0000705c0adcf91b  movaps [r15+0x110], xmm7
0000705c0adcf923  por xmm14, xmm13
0000705c0adcf928  movaps [r15+0x120], xmm14
0000705c0adcf930  por xmm6, xmm15
0000705c0adcf935  movaps [r15+0x130], xmm6
0000705c0adcf93d  mov rax, [r15+0xF8]
0000705c0adcf944  lea r14, [rax+0x20]
0000705c0adcf948  movups [r13+r14*1], xmm7
0000705c0adcf94e  lea r14, [rax+0x30]
0000705c0adcf952  movups [r13+r14*1], xmm14
0000705c0adcf958  movups [r13+rax*1], xmm11
0000705c0adcf95e  lea r14, [rax+0x10]
0000705c0adcf962  movups [r13+r14*1], xmm6
0000705c0adcf968  mov r14d, [r13+rax*1]
0000705c0adcf96d  mov rax, [r15+0x48]
0000705c0adcf971  mov [r15+0x68], rax
0000705c0adcf975  mov qword ptr [r15+0x58], 0x04
0000705c0adcf97d  lea r12, [rax+0x04]
0000705c0adcf981  mov r11d, [r13+r12*1]
0000705c0adcf986  mov [rsp+0x10], r11d
0000705c0adcf98b  mov r11d, r11d
0000705c0adcf98e  mov [r15+0x70], r11
0000705c0adcf992  lea r12, [rax+0x38]
0000705c0adcf996  mov r11d, [r13+r12*1]
0000705c0adcf99b  lea r12, [rax+0x24]
0000705c0adcf99f  mov r10d, [r13+r12*1]
0000705c0adcf9a4  mov [rsp+0x20], r10d
0000705c0adcf9a9  mov r10d, r10d
0000705c0adcf9ac  mov [r15+0x90], r10
0000705c0adcf9b3  mov [rsp+0x30], rax
0000705c0adcf9b8  xor eax, eax
0000705c0adcf9ba  mov r12d, 0x04
0000705c0adcf9c0  mov r10d, 0xC0
0000705c0adcf9c6  cmp r12, r10
0000705c0adcf9c9  cmc
0000705c0adcf9ca  lahf
0000705c0adcf9cb  seto al
0000705c0adcf9ce  mov [r15+0x108], eax
0000705c0adcf9d5  mov eax, [rsp+0x10]
0000705c0adcf9d9  mov r12d, [rsp+0x10]
0000705c0adcf9de  shrd eax, r12d, 0x07
0000705c0adcf9e3  mov [rsp+0x10], r11d
0000705c0adcf9e8  mov r10d, [rsp+0x10]
0000705c0adcf9ed  shrd r11d, r10d, 0x11
0000705c0adcf9f2  mov r9d, [rsp+0x20]
0000705c0adcf9f7  lea r8d, [r9d+r14d*1]
0000705c0adcf9fc  rorx r14d, r12d, 0x12
0000705c0adcfa02  xor eax, r14d
0000705c0adcfa05  rorx r14d, r10d, 0x13
0000705c0adcfa0b  xor r11d, r14d
0000705c0adcfa0e  mov [rsp+0x10], r11d
0000705c0adcfa13  mov r11d, r11d
0000705c0adcfa16  mov [r15+0x88], r11
0000705c0adcfa1d  mov [rsp+0x20], r12d
0000705c0adcfa22  shr r12d, 0x03
0000705c0adcfa26  xor eax, r12d
0000705c0adcfa29  mov [rsp+0x40], eax
0000705c0adcfa2d  mov eax, eax
0000705c0adcfa2f  mov [r15+0x80], rax
0000705c0adcfa36  shr r10d, 0x0A
0000705c0adcfa3a  mov eax, [rsp+0x10]
0000705c0adcfa3e  xor eax, r10d
0000705c0adcfa41  mov [rsp+0x10], eax
0000705c0adcfa45  mov eax, eax
0000705c0adcfa47  mov [r15+0x78], rax
0000705c0adcfa4b  mov eax, [rsp+0x40]
0000705c0adcfa4f  lea r14d, [r8d+eax*1]
0000705c0adcfa54  mov eax, [rsp+0x10]
0000705c0adcfa58  lea r12d, [r14d+eax*1]
0000705c0adcfa5d  mov rax, [rsp+0x30]
0000705c0adcfa62  lea r14, [rax+0x40]
0000705c0adcfa66  mov [r13+r14*1], r12d
0000705c0adcfa6b  mov eax, [rsp+0x20]
0000705c0adcfa6f  mov eax, eax
0000705c0adcfa71  mov [r15+0x60], rax
0000705c0adcfa75  mov eax, [r15+0x108]
0000705c0adcfa7c  sahf
0000705c0adcfa7d  jnz 0x0000705C0ADCFAAF
0000705c0adcfa7f  cmp dword ptr [r15+0x318], 0x00
0000705c0adcfa87  jz 0x0000705C0ADCFF70
0000705c0adcfa8d  nop [rax+rax*1], ax
0000705c0adcfa96  nop [rax+rax*1], eax
0000705c0adcfa9e  mov eax, 0x41088C
0000705c0adcfaa3  mov [r15+0x100], rax
0000705c0adcfaaa  jmp 0x0000705C0ABFE110
0000705c0adcfaaf  cmp dword ptr [r15+0x318], 0x00
0000705c0adcfab7  jz 0x0000705C0ADCFDC0
0000705c0adcfabd  nop [rax+rax*1], ax
0000705c0adcfac6  nop [rax+rax*1], eax
0000705c0adcface  mov eax, 0x410844
0000705c0adcfad3  mov [r15+0x100], rax
0000705c0adcfada  jmp 0x0000705C0ABFE110
0000705c0adcfadf  int3
0000705c0adcfae0  call 0x0000705C0AC0D860
0000705c0adcfae5  jmp 0x0000705C0ADCF17A
0000705c0adcfaea  call 0x0000705C0ACE2420
0000705c0adcfaef  jmp 0x0000705C0ADCF193
0000705c0adcfaf4  call 0x0000705C0ACE2420
0000705c0adcfaf9  jmp 0x0000705C0ADCF1AC
0000705c0adcfafe  call 0x0000705C0ACE2420
0000705c0adcfb03  jmp 0x0000705C0ADCF1C5
0000705c0adcfb08  call 0x0000705C0ACE2420
0000705c0adcfb0d  jmp 0x0000705C0ADCF1DE
0000705c0adcfb12  call 0x0000705C0ACE2420
0000705c0adcfb17  jmp 0x0000705C0ADCF1EF
0000705c0adcfb1c  call 0x0000705C0ACE2420
0000705c0adcfb21  jmp 0x0000705C0ADCF200
0000705c0adcfb26  call 0x0000705C0ACE2420
0000705c0adcfb2b  jmp 0x0000705C0ADCF211
0000705c0adcfb30  call 0x0000705C0ACE2420
0000705c0adcfb35  jmp 0x0000705C0ADCF222
0000705c0adcfb3a  call 0x0000705C0ACE2420
0000705c0adcfb3f  jmp 0x0000705C0ADCF233
0000705c0adcfb44  call 0x0000705C0ACE2420
0000705c0adcfb49  jmp 0x0000705C0ADCF244
0000705c0adcfb4e  call 0x0000705C0ACE2420
0000705c0adcfb53  jmp 0x0000705C0ADCF255
0000705c0adcfb58  call 0x0000705C0ACE2420
0000705c0adcfb5d  jmp 0x0000705C0ADCF266
0000705c0adcfb62  call 0x0000705C0ACE2420
0000705c0adcfb67  jmp 0x0000705C0ADCF277
0000705c0adcfb6c  call 0x0000705C0ACE2420
0000705c0adcfb71  jmp 0x0000705C0ADCF288
0000705c0adcfb76  call 0x0000705C0ACE2420
0000705c0adcfb7b  jmp 0x0000705C0ADCF299
0000705c0adcfb80  call 0x0000705C0ACE2420
0000705c0adcfb85  jmp 0x0000705C0ADCF2AA
0000705c0adcfb8a  call 0x0000705C0ACE2420
0000705c0adcfb8f  jmp 0x0000705C0ADCF2BB
0000705c0adcfb94  call 0x0000705C0ACE2420
0000705c0adcfb99  jmp 0x0000705C0ADCF2CC
0000705c0adcfb9e  call 0x0000705C0ACE2420
0000705c0adcfba3  jmp 0x0000705C0ADCF2DD
0000705c0adcfba8  call 0x0000705C0ACE2420
0000705c0adcfbad  jmp 0x0000705C0ADCF2EE
0000705c0adcfbb2  call 0x0000705C0ACE2420
0000705c0adcfbb7  jmp 0x0000705C0ADCF2FF
0000705c0adcfbbc  call 0x0000705C0ACE2420
0000705c0adcfbc1  jmp 0x0000705C0ADCF310
0000705c0adcfbc6  call 0x0000705C0ACE2420
0000705c0adcfbcb  jmp 0x0000705C0ADCF321
0000705c0adcfbd0  call 0x0000705C0ACE2420
0000705c0adcfbd5  jmp 0x0000705C0ADCF332
0000705c0adcfbda  call 0x0000705C0ACE2420
0000705c0adcfbdf  jmp 0x0000705C0ADCF343
0000705c0adcfbe4  call 0x0000705C0ACE2420
0000705c0adcfbe9  jmp 0x0000705C0ADCF354
0000705c0adcfbee  call 0x0000705C0ACE2420
0000705c0adcfbf3  jmp 0x0000705C0ADCF365
0000705c0adcfbf8  call 0x0000705C0ACE2420
0000705c0adcfbfd  jmp 0x0000705C0ADCF376
0000705c0adcfc02  call 0x0000705C0ACE2420
0000705c0adcfc07  jmp 0x0000705C0ADCF387
0000705c0adcfc0c  call 0x0000705C0ACE2420
0000705c0adcfc11  jmp 0x0000705C0ADCF398
0000705c0adcfc16  call 0x0000705C0ACE2420
0000705c0adcfc1b  jmp 0x0000705C0ADCF3A9
0000705c0adcfc20  call 0x0000705C0ACE2420
0000705c0adcfc25  jmp 0x0000705C0ADCF3BA
0000705c0adcfc2a  call 0x0000705C0ACE2420
0000705c0adcfc2f  jmp 0x0000705C0ADCF3CB
0000705c0adcfc34  call 0x0000705C0ACE2420
0000705c0adcfc39  jmp 0x0000705C0ADCF3DC
0000705c0adcfc3e  call 0x0000705C0ACE2420
0000705c0adcfc43  jmp 0x0000705C0ADCF3ED
0000705c0adcfc48  call 0x0000705C0ACE2420
0000705c0adcfc4d  jmp 0x0000705C0ADCF3FE
0000705c0adcfc52  call 0x0000705C0ACE2420
0000705c0adcfc57  jmp 0x0000705C0ADCF40F
0000705c0adcfc5c  call 0x0000705C0ACE2420
0000705c0adcfc61  jmp 0x0000705C0ADCF420
0000705c0adcfc66  call 0x0000705C0ACE2420
0000705c0adcfc6b  jmp 0x0000705C0ADCF431
0000705c0adcfc70  call 0x0000705C0ACE2420
0000705c0adcfc75  jmp 0x0000705C0ADCF442
0000705c0adcfc7a  call 0x0000705C0ACE2420
0000705c0adcfc7f  jmp 0x0000705C0ADCF453
0000705c0adcfc84  call 0x0000705C0ACE2420
0000705c0adcfc89  jmp 0x0000705C0ADCF464
0000705c0adcfc8e  call 0x0000705C0ACE2420
0000705c0adcfc93  jmp 0x0000705C0ADCF475
0000705c0adcfc98  call 0x0000705C0ACE2420
0000705c0adcfc9d  jmp 0x0000705C0ADCF486
0000705c0adcfca2  call 0x0000705C0ACE2420
0000705c0adcfca7  jmp 0x0000705C0ADCF497
0000705c0adcfcac  call 0x0000705C0ACE2420
0000705c0adcfcb1  jmp 0x0000705C0ADCF4A8
0000705c0adcfcb6  call 0x0000705C0ACE2420
0000705c0adcfcbb  jmp 0x0000705C0ADCF4B9
0000705c0adcfcc0  call 0x0000705C0ACE2420
0000705c0adcfcc5  jmp 0x0000705C0ADCF4CA
0000705c0adcfcca  call 0x0000705C0ACE2420
0000705c0adcfccf  jmp 0x0000705C0ADCF4DB
0000705c0adcfcd4  call 0x0000705C0ACE2420
0000705c0adcfcd9  jmp 0x0000705C0ADCF4EC
0000705c0adcfcde  call 0x0000705C0ACE2420
0000705c0adcfce3  jmp 0x0000705C0ADCF4FD
0000705c0adcfce8  call 0x0000705C0ACE2420
0000705c0adcfced  jmp 0x0000705C0ADCF50E
0000705c0adcfcf2  call 0x0000705C0ACE2420
0000705c0adcfcf7  jmp 0x0000705C0ADCF51F
0000705c0adcfcfc  call 0x0000705C0ACE2420
0000705c0adcfd01  jmp 0x0000705C0ADCF530
0000705c0adcfd06  call 0x0000705C0ACE2420
0000705c0adcfd0b  jmp 0x0000705C0ADCF541
0000705c0adcfd10  call 0x0000705C0ACE2420
0000705c0adcfd15  jmp 0x0000705C0ADCF552
0000705c0adcfd1a  call 0x0000705C0ACE2420
0000705c0adcfd1f  jmp 0x0000705C0ADCF563
0000705c0adcfd24  call 0x0000705C0ACE2420
0000705c0adcfd29  jmp 0x0000705C0ADCF574
0000705c0adcfd2e  call 0x0000705C0ACE2420
0000705c0adcfd33  jmp 0x0000705C0ADCF585
0000705c0adcfd38  call 0x0000705C0ACE2420
0000705c0adcfd3d  jmp 0x0000705C0ADCF596
0000705c0adcfd42  call 0x0000705C0ACE2420
0000705c0adcfd47  jmp 0x0000705C0ADCF5AF
0000705c0adcfd4c  call 0x0000705C0ACE2420
0000705c0adcfd51  jmp 0x0000705C0ADCF5C8
0000705c0adcfd56  call 0x0000705C0ACD5610
0000705c0adcfd5b  jmp 0x0000705C0ADCF5E1
0000705c0adcfd60  call 0x0000705C0ACDC580
0000705c0adcfd65  jmp 0x0000705C0ADCF94E
0000705c0adcfd6a  call 0x0000705C0ACE46C0
0000705c0adcfd6f  jmp 0x0000705C0ADCF958
0000705c0adcfd74  call 0x0000705C0AC09E90
0000705c0adcfd79  jmp 0x0000705C0ADCF95E
0000705c0adcfd7e  call 0x0000705C0ACDB310
0000705c0adcfd83  jmp 0x0000705C0ADCF968
0000705c0adcfd88  call 0x0000705C0AC0DAE0
0000705c0adcfd8d  jmp 0x0000705C0ADCF96D
0000705c0adcfd92  call 0x0000705C0ACC0230
0000705c0adcfd97  jmp 0x0000705C0ADCF986
0000705c0adcfd9c  call 0x0000705C0ACC0230
0000705c0adcfda1  jmp 0x0000705C0ADCF99B
0000705c0adcfda6  call 0x0000705C0ACBEFC0
0000705c0adcfdab  jmp 0x0000705C0ADCF9A4
0000705c0adcfdb0  call 0x0000705C0ACE2BA0
0000705c0adcfdb5  jmp 0x0000705C0ADCFA6B
0000705c0adcfdba  int3
0000705c0adcfdbb  nop [rax+rax*1], eax
0000705c0adcfdc0  mov rax, [r15+0x48]
0000705c0adcfdc4  mov r14, [r15+0x58]
0000705c0adcfdc8  lea r12, [rax+r14*1]
0000705c0adcfdcc  mov [r15+0x68], r12
0000705c0adcfdd0  lea rax, [r14+0x04]
0000705c0adcfdd4  mov [r15+0x58], rax
0000705c0adcfdd8  lea r14, [r12+0x04]
0000705c0adcfddd  mov r11d, [r13+r14*1]
0000705c0adcfde2  mov [rsp+0x10], r11d
0000705c0adcfde7  mov r11d, r11d
0000705c0adcfdea  mov [r15+0x70], r11
0000705c0adcfdee  lea r14, [r12+0x38]
0000705c0adcfdf3  mov r11d, [r13+r14*1]
0000705c0adcfdf8  lea r14, [r12+0x24]
0000705c0adcfdfd  mov r10d, [r13+r14*1]
0000705c0adcfe02  mov [rsp+0x20], r10d
0000705c0adcfe07  mov r10d, r10d
0000705c0adcfe0a  mov [r15+0x90], r10
0000705c0adcfe11  mov [rsp+0x30], rax
0000705c0adcfe16  xor eax, eax
0000705c0adcfe18  mov r14, [rsp+0x30]
0000705c0adcfe1d  mov r10d, 0xC0
0000705c0adcfe23  cmp r14, r10
0000705c0adcfe26  cmc
0000705c0adcfe27  lahf
0000705c0adcfe28  seto al
0000705c0adcfe2b  mov [r15+0x108], eax
0000705c0adcfe32  mov eax, [rsp+0x10]
0000705c0adcfe36  mov r14d, [rsp+0x10]
0000705c0adcfe3b  shrd eax, r14d, 0x07
0000705c0adcfe40  mov [rsp+0x10], r11d
0000705c0adcfe45  mov r10d, [rsp+0x10]
0000705c0adcfe4a  shrd r11d, r10d, 0x11
0000705c0adcfe4f  mov r9d, [r15+0x60]
0000705c0adcfe53  mov r8d, [rsp+0x20]
0000705c0adcfe58  lea ebp, [r8d+r9d*1]
0000705c0adcfe5d  rorx r9d, r14d, 0x12
0000705c0adcfe63  xor eax, r9d
0000705c0adcfe66  rorx r9d, r10d, 0x13
0000705c0adcfe6c  xor r11d, r9d
0000705c0adcfe6f  mov [rsp+0x10], r11d
0000705c0adcfe74  mov r11d, r11d
0000705c0adcfe77  mov [r15+0x88], r11
0000705c0adcfe7e  mov [rsp+0x20], r14d
0000705c0adcfe83  shr r14d, 0x03
0000705c0adcfe87  xor eax, r14d
0000705c0adcfe8a  mov [rsp+0x30], eax
0000705c0adcfe8e  mov eax, eax
0000705c0adcfe90  mov [r15+0x80], rax
0000705c0adcfe97  shr r10d, 0x0A
0000705c0adcfe9b  mov eax, [rsp+0x10]
0000705c0adcfe9f  xor eax, r10d
0000705c0adcfea2  mov [rsp+0x10], eax
0000705c0adcfea6  mov eax, eax
0000705c0adcfea8  mov [r15+0x78], rax
0000705c0adcfeac  mov eax, [rsp+0x30]
0000705c0adcfeb0  lea r14d, [ebp+eax*1]
0000705c0adcfeb6  mov eax, [rsp+0x10]
0000705c0adcfeba  lea r11d, [r14d+eax*1]
0000705c0adcfebf  lea rax, [r12+0x40]
0000705c0adcfec4  mov [r13+rax*1], r11d
0000705c0adcfec9  mov eax, [rsp+0x20]
0000705c0adcfecd  mov eax, eax
0000705c0adcfecf  mov [r15+0x60], rax
0000705c0adcfed3  mov eax, [r15+0x108]
0000705c0adcfeda  sahf
0000705c0adcfedb  jnz 0x0000705C0ADCFF0D
0000705c0adcfedd  cmp dword ptr [r15+0x318], 0x00
0000705c0adcfee5  jz 0x0000705C0ADCFF70
0000705c0adcfeeb  nop [rax+rax*1], ax
0000705c0adcfef4  nop [rax+rax*1], eax
0000705c0adcfefc  mov eax, 0x41088C
0000705c0adcff01  mov [r15+0x100], rax
0000705c0adcff08  jmp 0x0000705C0ABFE110
0000705c0adcff0d  cmp dword ptr [r15+0x318], 0x00
0000705c0adcff15  jz 0x0000705C0ADCFDC0
0000705c0adcff1b  nop [rax+rax*1], ax
0000705c0adcff24  nop [rax+rax*1], eax
0000705c0adcff2c  mov eax, 0x410844
0000705c0adcff31  mov [r15+0x100], rax
0000705c0adcff38  jmp 0x0000705C0ABFE110
0000705c0adcff3d  int3
0000705c0adcff3e  call 0x0000705C0ACE1430
0000705c0adcff43  jmp 0x0000705C0ADCFDE2
0000705c0adcff48  call 0x0000705C0ACE1430
0000705c0adcff4d  jmp 0x0000705C0ADCFDF8
0000705c0adcff52  call 0x0000705C0ACE01C0
0000705c0adcff57  jmp 0x0000705C0ADCFE02
0000705c0adcff5c  call 0x0000705C0AC0A860
0000705c0adcff61  jmp 0x0000705C0ADCFEC9
0000705c0adcff66  int3
0000705c0adcff67  nop [rax+rax*1], ax
0000705c0adcff70  mov rax, [r15]
0000705c0adcff73  mov r14d, [r13+rax*1]
0000705c0adcff78  lea r12, [rax+0x04]
0000705c0adcff7c  mov r11d, [r13+r12*1]
0000705c0adcff81  mov [rsp+0x10], r14d
0000705c0adcff86  mov r14d, r14d
0000705c0adcff89  mov [r15+0x78], r14
0000705c0adcff8d  mov [rsp+0x20], r11d
0000705c0adcff92  mov r11d, r11d
0000705c0adcff95  mov [r15+0x80], r11
0000705c0adcff9c  lea r14, [rax+0x08]
0000705c0adcffa0  mov r12d, [r13+r14*1]
0000705c0adcffa5  lea r14, [rax+0x0C]
0000705c0adcffa9  mov r11d, [r13+r14*1]
0000705c0adcffae  mov [rsp+0x30], r12d
0000705c0adcffb3  mov r12d, r12d
0000705c0adcffb6  mov [r15+0x70], r12
0000705c0adcffba  mov [rsp+0x40], r11d
0000705c0adcffbf  mov r11d, r11d
0000705c0adcffc2  mov [r15+0x68], r11
0000705c0adcffc6  lea r14, [rax+0x18]
0000705c0adcffca  mov r12d, [r13+r14*1]
0000705c0adcffcf  lea r14, [rax+0x1C]
0000705c0adcffd3  mov r11d, [r13+r14*1]
0000705c0adcffd8  mov [rsp+0x50], r12d
0000705c0adcffdd  mov r12d, r12d
0000705c0adcffe0  mov [r15+0x58], r12
0000705c0adcffe4  mov [rsp+0x60], r11d
0000705c0adcffe9  mov r11d, r11d
0000705c0adcffec  mov [r15+0x60], r11
0000705c0adcfff0  lea r14, [rax+0x10]
0000705c0adcfff4  mov r12d, [r13+r14*1]
0000705c0adcfff9  lea r14, [rax+0x14]
0000705c0adcfffd  mov eax, [r13+r14*1]
0000705c0add0002  mov [rsp+0x70], r12d
0000705c0add0007  mov r12d, r12d
0000705c0add000a  mov [r15+0x18], r12
0000705c0add000e  mov [rsp+0x80], eax
0000705c0add0015  mov eax, eax
0000705c0add0017  mov [r15+0x90], rax
0000705c0add001e  mov eax, [rsp+0x70]
0000705c0add0022  mov eax, eax
0000705c0add0024  mov [r15+0x30], rax
0000705c0add0028  mov eax, [rsp+0x50]
0000705c0add002c  mov eax, eax
0000705c0add002e  mov [r15+0xA0], rax
0000705c0add0035  mov eax, [rsp+0x30]
0000705c0add0039  mov eax, eax
0000705c0add003b  mov [r15+0x28], rax
0000705c0add003f  mov eax, [rsp+0x20]
0000705c0add0043  mov eax, eax
0000705c0add0045  mov [r15+0x98], rax
0000705c0add004c  mov eax, [rsp+0x10]
0000705c0add0050  mov eax, eax
0000705c0add0052  mov [r15+0x38], rax
0000705c0add0056  mov eax, [rsp+0x70]
0000705c0add005a  mov r14d, [rsp+0x70]
0000705c0add005f  shrd eax, r14d, 0x06
0000705c0add0064  mov [rsp+0x70], r14d
0000705c0add0069  mov r12d, [rsp+0x80]
0000705c0add0071  and r14d, r12d
0000705c0add0074  mov r11d, [rsp+0x10]
0000705c0add0079  mov r10d, [rsp+0x10]
0000705c0add007e  shrd r11d, r10d, 0x02
0000705c0add0083  mov [rsp+0x10], r12d
0000705c0add0088  mov r12d, r12d
0000705c0add008b  mov [r15+0x20], r12
0000705c0add008f  mov r12, [r15+0x50]
0000705c0add0093  mov r9d, [r13+r12*1]
0000705c0add0098  mov r12d, [rsp+0x50]
0000705c0add009d  mov r8d, [rsp+0x70]
0000705c0add00a2  andn ebp, r8d, r12d
0000705c0add00a7  mov edi, [rsp+0x60]
0000705c0add00ab  lea esi, [r14d+edi*1]
0000705c0add00b0  rorx r14d, r8d, 0x0B
0000705c0add00b6  xor eax, r14d
0000705c0add00b9  rorx r14d, r10d, 0x0D
0000705c0add00bf  xor r11d, r14d
0000705c0add00c2  lea edi, [esi+ebp*1]
0000705c0add00c6  mov r14, [r15+0x48]
0000705c0add00ca  mov ebp, [r13+r14*1]
0000705c0add00cf  mov r14d, [rsp+0x30]
0000705c0add00d4  mov esi, [rsp+0x20]
0000705c0add00d8  and r14d, esi
0000705c0add00db  mov [rsp+0x20], r14d
0000705c0add00e0  mov r14d, r14d
0000705c0add00e3  mov [r15+0xD8], r14
0000705c0add00ea  lea r14d, [edi+r9d*1]
0000705c0add00ef  mov r9d, [rsp+0x30]
0000705c0add00f4  xor r9d, esi
0000705c0add00f7  rorx edi, r8d, 0x19
0000705c0add00fd  xor eax, edi
0000705c0add00ff  and r9d, r10d
0000705c0add0102  rorx edi, r10d, 0x16
0000705c0add0108  xor r11d, edi
0000705c0add010b  mov [rsp+0x30], r11d
0000705c0add0110  mov r11d, r11d
0000705c0add0113  mov [r15+0xD0], r11
0000705c0add011a  lea r11d, [r14d+ebp*1]
0000705c0add011f  mov r10d, [rsp+0x20]
0000705c0add0124  xor r9d, r10d
0000705c0add0127  lea r14d, [r11d+eax*1]
0000705c0add012c  mov qword ptr [r15+0x88], 0x04
0000705c0add0137  mov eax, [rsp+0x30]
0000705c0add013b  lea r11d, [r9d+eax*1]
0000705c0add0140  mov eax, [rsp+0x40]
0000705c0add0144  lea r10d, [r14d+eax*1]
0000705c0add0149  mov r10d, r10d
0000705c0add014c  mov [r15+0xB8], r10
0000705c0add0153  xor eax, eax
0000705c0add0155  mov r10d, 0x04
0000705c0add015b  mov r9d, 0x100
0000705c0add0161  cmp r10, r9
0000705c0add0164  cmc
0000705c0add0165  lahf
0000705c0add0166  seto al
0000705c0add0169  mov [r15+0x108], eax
0000705c0add0170  lea eax, [r11d+r14d*1]
0000705c0add0175  mov eax, eax
0000705c0add0177  mov [r15+0xA8], rax
0000705c0add017e  mov r12d, r12d
0000705c0add0181  mov [r15+0xB0], r12
0000705c0add0188  mov eax, [rsp+0x10]
0000705c0add018c  mov eax, eax
0000705c0add018e  mov [r15+0xC0], rax
0000705c0add0195  mov r8d, r8d
0000705c0add0198  mov [r15+0xC8], r8
0000705c0add019f  mov eax, [r15+0x108]
0000705c0add01a6  sahf
0000705c0add01a7  jnz 0x0000705C0ADD01D9
0000705c0add01a9  cmp dword ptr [r15+0x318], 0x00
0000705c0add01b1  jz 0x0000705C0ADD04A0
0000705c0add01b7  nop [rax+rax*1], ax
0000705c0add01c0  nop [rax+rax*1], eax
0000705c0add01c8  mov eax, 0x41094C
0000705c0add01cd  mov [r15+0x100], rax
0000705c0add01d4  jmp 0x0000705C0ABFE110
0000705c0add01d9  cmp dword ptr [r15+0x318], 0x00
0000705c0add01e1  jz 0x0000705C0ADD0270
0000705c0add01e7  nop [rax+rax*1], ax
0000705c0add01f0  nop [rax+rax*1], eax
0000705c0add01f8  mov eax, 0x4108C0
0000705c0add01fd  mov [r15+0x100], rax
0000705c0add0204  jmp 0x0000705C0ABFE110
0000705c0add0209  int3
0000705c0add020a  call 0x0000705C0AC0DAE0
0000705c0add020f  jmp 0x0000705C0ADCFF78
0000705c0add0214  call 0x0000705C0ACC0230
0000705c0add0219  jmp 0x0000705C0ADCFF81
0000705c0add021e  call 0x0000705C0ACE26A0
0000705c0add0223  jmp 0x0000705C0ADCFFA5
0000705c0add0228  call 0x0000705C0ACE1430
0000705c0add022d  jmp 0x0000705C0ADCFFAE
0000705c0add0232  call 0x0000705C0ACE26A0
0000705c0add0237  jmp 0x0000705C0ADCFFCF
0000705c0add023c  call 0x0000705C0ACE1430
0000705c0add0241  jmp 0x0000705C0ADCFFD8
0000705c0add0246  call 0x0000705C0ACE26A0
0000705c0add024b  jmp 0x0000705C0ADCFFF9
0000705c0add0250  call 0x0000705C0ACD5890
0000705c0add0255  jmp 0x0000705C0ADD0002
0000705c0add025a  call 0x0000705C0ACBDD50
0000705c0add025f  jmp 0x0000705C0ADD0098
0000705c0add0264  call 0x0000705C0ACDA580
0000705c0add0269  jmp 0x0000705C0ADD00CF
0000705c0add026e  int3
0000705c0add026f  nop
0000705c0add0270  mov eax, [r15+0xB8]
0000705c0add0277  mov [rsp+0x10], eax
0000705c0add027b  mov eax, eax
0000705c0add027d  mov [r15+0x30], rax
0000705c0add0281  mov eax, [r15+0xC0]
0000705c0add0288  mov [rsp+0x20], eax
0000705c0add028c  mov eax, eax
0000705c0add028e  mov [r15+0xA0], rax
0000705c0add0295  mov eax, [r15+0x28]
0000705c0add0299  mov r14d, [r15+0x98]
0000705c0add02a0  mov [rsp+0x30], r14d
0000705c0add02a5  mov r14d, r14d
0000705c0add02a8  mov [r15+0x28], r14
0000705c0add02ac  mov r14d, [r15+0x38]
0000705c0add02b0  mov [rsp+0x40], r14d
0000705c0add02b5  mov r14d, r14d
0000705c0add02b8  mov [r15+0x98], r14
0000705c0add02bf  mov r14d, [r15+0xA8]
0000705c0add02c6  mov [rsp+0x50], r14d
0000705c0add02cb  mov r14d, r14d
0000705c0add02ce  mov [r15+0x38], r14
0000705c0add02d2  mov r14d, [rsp+0x10]
0000705c0add02d7  mov r12d, [rsp+0x10]
0000705c0add02dc  shrd r14d, r12d, 0x06
0000705c0add02e1  mov r11d, [r15+0xC8]
0000705c0add02e8  mov [rsp+0x10], r12d
0000705c0add02ed  and r12d, r11d
0000705c0add02f0  mov r10d, [rsp+0x50]
0000705c0add02f5  mov r9d, [rsp+0x50]
0000705c0add02fa  shrd r10d, r9d, 0x02
0000705c0add02ff  mov [rsp+0x50], r11d
0000705c0add0304  mov r11d, r11d
0000705c0add0307  mov [r15+0x20], r11
0000705c0add030b  mov r11, [r15+0x88]
0000705c0add0312  mov r8, [r15+0x50]
0000705c0add0316  lea rbp, [r8+r11*1]
0000705c0add031a  mov r8d, [r13+rbp*1]
0000705c0add031f  mov ebp, [rsp+0x20]
0000705c0add0323  mov edi, [rsp+0x10]
0000705c0add0327  andn esi, edi, ebp
0000705c0add032c  mov edx, [r15+0xB0]
0000705c0add0333  lea ecx, [r12d+edx*1]
0000705c0add0338  rorx r12d, edi, 0x0B
0000705c0add033e  xor r14d, r12d
0000705c0add0341  rorx r12d, r9d, 0x0D
0000705c0add0347  xor r10d, r12d
0000705c0add034a  lea r12d, [ecx+esi*1]
0000705c0add034f  mov rsi, [r15+0x48]
0000705c0add0353  lea rdx, [rsi+r11*1]
0000705c0add0357  mov esi, [r13+rdx*1]
0000705c0add035c  mov edx, [rsp+0x30]
0000705c0add0360  mov ecx, [rsp+0x40]
0000705c0add0364  and edx, ecx
0000705c0add0366  mov [rsp+0x10], edx
0000705c0add036a  mov edx, edx
0000705c0add036c  mov [r15+0xD8], rdx
0000705c0add0373  lea edx, [r12d+r8d*1]
0000705c0add0378  mov r12d, [rsp+0x30]
0000705c0add037d  xor r12d, ecx
0000705c0add0380  rorx r8d, edi, 0x19
0000705c0add0386  xor r14d, r8d
0000705c0add0389  and r12d, r9d
0000705c0add038c  rorx r8d, r9d, 0x16
0000705c0add0392  xor r10d, r8d
0000705c0add0395  mov [rsp+0x20], r10d
0000705c0add039a  mov r10d, r10d
0000705c0add039d  mov [r15+0xD0], r10
0000705c0add03a4  lea r10d, [edx+esi*1]
0000705c0add03a9  mov r9d, [rsp+0x10]
0000705c0add03ae  xor r12d, r9d
0000705c0add03b1  lea r9d, [r10d+r14d*1]
0000705c0add03b6  lea r14, [r11+0x04]
0000705c0add03ba  mov [r15+0x88], r14
0000705c0add03c1  mov r11d, [rsp+0x20]
0000705c0add03c6  lea r10d, [r12d+r11d*1]
0000705c0add03cb  lea r11d, [r9d+eax*1]
0000705c0add03d0  mov r11d, r11d
0000705c0add03d3  mov [r15+0xB8], r11
0000705c0add03da  xor eax, eax
0000705c0add03dc  mov r12d, 0x100
0000705c0add03e2  cmp r14, r12
0000705c0add03e5  cmc
0000705c0add03e6  lahf
0000705c0add03e7  seto al
0000705c0add03ea  mov [r15+0x108], eax
0000705c0add03f1  lea eax, [r10d+r9d*1]
0000705c0add03f6  mov eax, eax
0000705c0add03f8  mov [r15+0xA8], rax
0000705c0add03ff  mov ebp, ebp
0000705c0add0401  mov [r15+0xB0], rbp
0000705c0add0408  mov eax, [rsp+0x50]
0000705c0add040c  mov eax, eax
0000705c0add040e  mov [r15+0xC0], rax
0000705c0add0415  mov edi, edi
0000705c0add0417  mov [r15+0xC8], rdi
0000705c0add041e  mov eax, [r15+0x108]
0000705c0add0425  sahf
0000705c0add0426  jnz 0x0000705C0ADD0458
0000705c0add0428  cmp dword ptr [r15+0x318], 0x00
0000705c0add0430  jz 0x0000705C0ADD04A0
0000705c0add0436  nop [rax+rax*1], ax
0000705c0add043f  nop [rax+rax*1], eax
0000705c0add0447  mov eax, 0x41094C
0000705c0add044c  mov [r15+0x100], rax
0000705c0add0453  jmp 0x0000705C0ABFE110
0000705c0add0458  cmp dword ptr [r15+0x318], 0x00
0000705c0add0460  jz 0x0000705C0ADD0270
0000705c0add0466  nop [rax+rax*1], ax
0000705c0add046f  nop [rax+rax*1], eax
0000705c0add0477  mov eax, 0x4108C0
0000705c0add047c  mov [r15+0x100], rax
0000705c0add0483  jmp 0x0000705C0ABFE110
0000705c0add0488  int3
0000705c0add0489  call 0x0000705C0AC49010
0000705c0add048e  jmp 0x0000705C0ADD031F
0000705c0add0493  call 0x0000705C0AC25930
0000705c0add0498  jmp 0x0000705C0ADD035C
0000705c0add049d  int3
0000705c0add049e  nop
0000705c0add04a0  mov eax, [r15+0x98]
0000705c0add04a7  mov r14d, [r15+0x70]
0000705c0add04ab  lea r12d, [eax+r14d*1]
0000705c0add04b0  mov eax, [r15+0x28]
0000705c0add04b4  mov r14d, [r15+0x68]
0000705c0add04b8  lea r11d, [eax+r14d*1]
0000705c0add04bd  mov qword ptr [r15+0x88], 0x00
0000705c0add04c8  mov eax, [r15+0xA8]
0000705c0add04cf  mov r14d, [r15+0x78]
0000705c0add04d3  lea r10d, [eax+r14d*1]
0000705c0add04d8  mov [rsp+0x10], r10d
0000705c0add04dd  mov r10d, r10d
0000705c0add04e0  mov [r15+0x78], r10
0000705c0add04e4  mov eax, [r15+0x38]
0000705c0add04e8  mov r14d, [r15+0x80]
0000705c0add04ef  lea r10d, [eax+r14d*1]
0000705c0add04f4  mov [rsp+0x20], r10d
0000705c0add04f9  mov r10d, r10d
0000705c0add04fc  mov [r15+0x80], r10
0000705c0add0503  mov rax, [r15]
0000705c0add0506  lea r14, [rax+0x08]
0000705c0add050a  mov [r13+r14*1], r12d
0000705c0add050f  lea r14, [rax+0x0C]
0000705c0add0513  mov [r13+r14*1], r11d
0000705c0add0518  mov r14d, [r15+0xB8]
0000705c0add051f  mov r12d, [r15+0x18]
0000705c0add0523  lea r11d, [r14d+r12d*1]
0000705c0add0528  mov [rsp+0x30], r11d
0000705c0add052d  mov r11d, r11d
0000705c0add0530  mov [r15+0x68], r11
0000705c0add0534  mov r14d, [r15+0x30]
0000705c0add0538  mov r12d, [r15+0x90]
0000705c0add053f  lea r11d, [r14d+r12d*1]
0000705c0add0544  mov [rsp+0x40], r11d
0000705c0add0549  mov r11d, r11d
0000705c0add054c  mov [r15+0x70], r11
0000705c0add0550  mov r14d, [r15+0x20]
0000705c0add0554  mov r12d, [r15+0x58]
0000705c0add0558  lea r11d, [r14d+r12d*1]
0000705c0add055d  mov [rsp+0x50], r11d
0000705c0add0562  mov r11d, r11d
0000705c0add0565  mov [r15+0x58], r11
0000705c0add0569  mov r14d, [r15+0xA0]
0000705c0add0570  mov r12d, [r15+0x60]
0000705c0add0574  lea r11d, [r14d+r12d*1]
0000705c0add0579  mov [rsp+0x60], r11d
0000705c0add057e  mov r11d, r11d
0000705c0add0581  mov [r15+0x60], r11
0000705c0add0585  mov r14d, [rsp+0x10]
0000705c0add058a  mov [r13+rax*1], r14d
0000705c0add058f  lea r14, [rax+0x04]
0000705c0add0593  mov r12d, [rsp+0x20]
0000705c0add0598  mov [r13+r14*1], r12d
0000705c0add059d  lea r14, [rax+0x10]
0000705c0add05a1  mov r12d, [rsp+0x30]
0000705c0add05a6  mov [r13+r14*1], r12d
0000705c0add05ab  lea r14, [rax+0x14]
0000705c0add05af  mov r12d, [rsp+0x40]
0000705c0add05b4  mov [r13+r14*1], r12d
0000705c0add05b9  lea r14, [rax+0x18]
0000705c0add05bd  mov r12d, [rsp+0x50]
0000705c0add05c2  mov [r13+r14*1], r12d
0000705c0add05c7  lea r14, [rax+0x1C]
0000705c0add05cb  mov r12d, [rsp+0x60]
0000705c0add05d0  mov [r13+r14*1], r12d
0000705c0add05d5  lea r14, [rax+0x68]
0000705c0add05d9  xor eax, eax
0000705c0add05db  mov [r13+r14*1], rax
0000705c0add05e0  cmp dword ptr [r15+0x318], 0x00
0000705c0add05e8  jz 0x0000705C0ADCF0E0
0000705c0add05ee  nop [rax+rax*1], ax
0000705c0add05f7  nop [rax+rax*1], eax
0000705c0add05ff  mov eax, 0x410768
0000705c0add0604  mov [r15+0x100], rax
0000705c0add060b  jmp 0x0000705C0ABFE110
0000705c0add0610  int3
0000705c0add0611  call 0x0000705C0ACE2BA0
0000705c0add0616  jmp 0x0000705C0ADD050F
0000705c0add061b  call 0x0000705C0ACE1920
0000705c0add0620  jmp 0x0000705C0ADD0518
0000705c0add0625  call 0x0000705C0AC0DFE0
0000705c0add062a  jmp 0x0000705C0ADD058F
0000705c0add062f  call 0x0000705C0ACE2BA0
0000705c0add0634  jmp 0x0000705C0ADD059D
0000705c0add0639  call 0x0000705C0ACE2BA0
0000705c0add063e  jmp 0x0000705C0ADD05AB
0000705c0add0643  call 0x0000705C0ACE2BA0
0000705c0add0648  jmp 0x0000705C0ADD05B9
0000705c0add064d  call 0x0000705C0ACE2BA0
0000705c0add0652  jmp 0x0000705C0ADD05C7
0000705c0add0657  call 0x0000705C0ACE2BA0
0000705c0add065c  jmp 0x0000705C0ADD05D5
0000705c0add0661  call 0x0000705C0ACD5EB0
0000705c0add0666  jmp 0x0000705C0ADD05E0
0000705c0add066b  int3
0000705c0add066c  nop [rax], eax
0000705c0add0670  mov rax, [r15+0xF8]
0000705c0add0677  lea r14, [rax+0x140]
0000705c0add067e  mov r12, [r13+r14*1]
0000705c0add0683  lea r14, [rax+0x148]
0000705c0add068a  mov r11, [r13+r14*1]
0000705c0add068f  mov [r15+0xA0], r12
0000705c0add0696  mov [r15+0x98], r11
0000705c0add069d  lea r14, [rax+0x130]
0000705c0add06a4  mov r12, [r13+r14*1]
0000705c0add06a9  lea r14, [rax+0x138]
0000705c0add06b0  mov r11, [r13+r14*1]
0000705c0add06b5  mov [r15+0xB0], r12
0000705c0add06bc  mov [r15+0xA8], r11
0000705c0add06c3  lea r14, [rax+0x120]
0000705c0add06ca  mov r12, [r13+r14*1]
0000705c0add06cf  lea r14, [rax+0x128]
0000705c0add06d6  mov r11, [r13+r14*1]
0000705c0add06db  mov [r15+0xC0], r12
0000705c0add06e2  mov [r15+0xB8], r11
0000705c0add06e9  lea r14, [rax+0x110]
0000705c0add06f0  mov r12, [r13+r14*1]
0000705c0add06f5  lea r14, [rax+0x118]
0000705c0add06fc  mov r11, [r13+r14*1]
0000705c0add0701  mov [r15+0xD0], r12
0000705c0add0708  mov [r15+0xC8], r11
0000705c0add070f  lea r14, [rax+0x100]
0000705c0add0716  mov r12, [r13+r14*1]
0000705c0add071b  lea r14, [rax+0x108]
0000705c0add0722  mov r11, [r13+r14*1]
0000705c0add0727  mov [r15+0xE8], r12
0000705c0add072e  mov [r15+0xD8], r11
0000705c0add0735  lea r14, [rax+0x150]
0000705c0add073c  mov [r15+0xF8], r14
0000705c0add0743  mov rax, [r15+0xF0]
0000705c0add074a  mov [r15+0x100], rax
0000705c0add0751  jmp 0x0000705C0ADCE5C0
0000705c0add0756  int3
0000705c0add0757  call 0x0000705C0ACE27E0
0000705c0add075c  jmp 0x0000705C0ADD0683
0000705c0add0761  call 0x0000705C0ACE1570
0000705c0add0766  jmp 0x0000705C0ADD068F
0000705c0add076b  call 0x0000705C0ACE27E0
0000705c0add0770  jmp 0x0000705C0ADD06A9
0000705c0add0775  call 0x0000705C0ACE1570
0000705c0add077a  jmp 0x0000705C0ADD06B5
0000705c0add077f  call 0x0000705C0ACE27E0
0000705c0add0784  jmp 0x0000705C0ADD06CF
0000705c0add0789  call 0x0000705C0ACE1570
0000705c0add078e  jmp 0x0000705C0ADD06DB
0000705c0add0793  call 0x0000705C0ACE27E0
0000705c0add0798  jmp 0x0000705C0ADD06F5
0000705c0add079d  call 0x0000705C0ACE1570
0000705c0add07a2  jmp 0x0000705C0ADD0701
0000705c0add07a7  call 0x0000705C0ACE27E0
0000705c0add07ac  jmp 0x0000705C0ADD071B
0000705c0add07b1  call 0x0000705C0ACE1570
0000705c0add07b6  jmp 0x0000705C0ADD0727
0000705c0add07bb  int3
0000705c0add07bc  nop [rax], eax
0000705c0add07c0  mov eax, [r15+0xA0]
0000705c0add07c7  mov [rsp+0x10], eax
0000705c0add07cb  xor eax, eax
0000705c0add07cd  mov r14d, [rsp+0x10]
0000705c0add07d2  sub r14d, 0x01
0000705c0add07d6  cmc
0000705c0add07d7  lahf
0000705c0add07d8  seto al
0000705c0add07db  mov [r15+0x108], eax
0000705c0add07e2  mov r14d, r14d
0000705c0add07e5  mov [r15+0xA0], r14
0000705c0add07ec  mov eax, [r15+0x108]
0000705c0add07f3  sahf
0000705c0add07f4  jnz 0x0000705C0ADD0826
0000705c0add07f6  cmp dword ptr [r15+0x318], 0x00
0000705c0add07fe  jz 0x0000705C0ADD0900
0000705c0add0804  nop [rax+rax*1], ax
0000705c0add080d  nop [rax+rax*1], eax
0000705c0add0815  mov eax, 0x41028C
0000705c0add081a  mov [r15+0x100], rax
0000705c0add0821  jmp 0x0000705C0ABFE110
0000705c0add0826  cmp dword ptr [r15+0x318], 0x00
0000705c0add082e  jz 0x0000705C0ADD0860
0000705c0add0834  nop [rax+rax*1], ax
0000705c0add083d  nop [rax+rax*1], eax
0000705c0add0845  mov eax, 0x410274
0000705c0add084a  mov [r15+0x100], rax
0000705c0add0851  jmp 0x0000705C0ABFE110
0000705c0add0856  int3
0000705c0add0857  int3
0000705c0add0858  nop [rax+rax*1], eax
0000705c0add0860  mov rax, [r15+0xF8]
0000705c0add0867  lea r14, [rax+0x100]
0000705c0add086e  mov [r15], r14
0000705c0add0871  mov rax, [r15+0x98]
0000705c0add0878  mov [r15+0x08], rax
0000705c0add087c  mov qword ptr [r15+0x10], 0x12C
0000705c0add0884  mov qword ptr [r15+0xF0], 0x410284
0000705c0add088f  mov r14d, [r15+0x320]
0000705c0add0896  mov eax, 0x410284
0000705c0add089b  mov rcx, 0x705C0ADD07C0
0000705c0add08a5  mov [r15+r14*8+0x328], rax
0000705c0add08ad  mov [r15+r14*8+0x368], rcx
0000705c0add08b5  add r14d, 0x01
0000705c0add08b9  and r14d, 0x07
0000705c0add08bd  mov [r15+0x320], r14d
0000705c0add08c4  cmp dword ptr [r15+0x318], 0x00
0000705c0add08cc  jz 0x0000705C0ADCED70
0000705c0add08d2  nop [rax+rax*1], ax
0000705c0add08db  nop [rax+rax*1], eax
0000705c0add08e3  mov eax, 0x410728
0000705c0add08e8  mov [r15+0x100], rax
0000705c0add08ef  jmp 0x0000705C0ABFE110
0000705c0add08f4  int3
0000705c0add08f5  int3
0000705c0add08f6  nop [rax+rax*1], ax
0000705c0add08ff  nop
0000705c0add0900  mov rax, [r15+0xF8]
0000705c0add0907  lea r14, [rax+0x120]
0000705c0add090e  mov r12, [r13+r14*1]
0000705c0add0913  mov [r15+0x98], r12
0000705c0add091a  mov qword ptr [r15+0x40], 0x80
0000705c0add0922  lea r14, [rax+0x100]
0000705c0add0929  mov [r15], r14
0000705c0add092c  lea r14, [rax+0x17C]
0000705c0add0933  mov [r15+0x08], r14
0000705c0add0937  mov qword ptr [r15+0x10], 0x01
0000705c0add093f  lea r14, [rax+0x17C]
0000705c0add0946  mov eax, 0x80
0000705c0add094b  mov [r13+r14*1], al
0000705c0add0950  mov qword ptr [r15+0xF0], 0x4102A8
0000705c0add095b  mov r14d, [r15+0x320]
0000705c0add0962  mov eax, 0x4102A8
0000705c0add0967  mov rcx, 0x705C0ADD09E0
0000705c0add0971  mov [r15+r14*8+0x328], rax
0000705c0add0979  mov [r15+r14*8+0x368], rcx
0000705c0add0981  add r14d, 0x01
0000705c0add0985  and r14d, 0x07
0000705c0add0989  mov [r15+0x320], r14d
0000705c0add0990  cmp dword ptr [r15+0x318], 0x00
0000705c0add0998  jz 0x0000705C0ADCED70
0000705c0add099e  nop [rax+rax*1], ax
0000705c0add09a7  nop [rax+rax*1], eax
0000705c0add09af  mov eax, 0x410728
0000705c0add09b4  mov [r15+0x100], rax
0000705c0add09bb  jmp 0x0000705C0ABFE110
0000705c0add09c0  int3
0000705c0add09c1  call 0x0000705C0ACE27E0
0000705c0add09c6  jmp 0x0000705C0ADD0913
0000705c0add09cb  call 0x0000705C0ACD5AF0
0000705c0add09d0  jmp 0x0000705C0ADD0950
0000705c0add09d5  int3
0000705c0add09d6  nop [rax+rax*1], ax
0000705c0add09df  nop
0000705c0add09e0  mov rax, [r15+0xF8]
0000705c0add09e7  lea r14, [rax+0x168]
0000705c0add09ee  mov r12, [r13+r14*1]
0000705c0add09f3  mov [r15+0x40], r12
0000705c0add09f7  lea r14, [rax+0x178]
0000705c0add09fe  xor eax, eax
0000705c0add0a00  mov [r13+r14*1], al
0000705c0add0a05  xor eax, eax
0000705c0add0a07  mov r14d, 0x38
0000705c0add0a0d  cmp r12, r14
0000705c0add0a10  cmc
0000705c0add0a11  lahf
0000705c0add0a12  seto al
0000705c0add0a15  mov [r15+0x108], eax
0000705c0add0a1c  mov eax, [r15+0x108]
0000705c0add0a23  sahf
0000705c0add0a24  jz 0x0000705C0ADD0A56
0000705c0add0a26  cmp dword ptr [r15+0x318], 0x00
0000705c0add0a2e  jz 0x0000705C0ADD0AA0
0000705c0add0a34  nop [rax+rax*1], ax
0000705c0add0a3d  nop [rax+rax*1], eax
0000705c0add0a45  mov eax, 0x4102B8
0000705c0add0a4a  mov [r15+0x100], rax
0000705c0add0a51  jmp 0x0000705C0ABFE110
0000705c0add0a56  cmp dword ptr [r15+0x318], 0x00
0000705c0add0a5e  jz 0x0000705C0ADD0BF0
0000705c0add0a64  nop [rax+rax*1], ax
0000705c0add0a6d  nop [rax+rax*1], eax
0000705c0add0a75  mov eax, 0x4102D4
0000705c0add0a7a  mov [r15+0x100], rax
0000705c0add0a81  jmp 0x0000705C0ABFE110
0000705c0add0a86  int3
0000705c0add0a87  call 0x0000705C0ACE27E0
0000705c0add0a8c  jmp 0x0000705C0ADD09F3
0000705c0add0a91  call 0x0000705C0ACD5AF0
0000705c0add0a96  jmp 0x0000705C0ADD0A05
0000705c0add0a9b  int3
0000705c0add0a9c  nop [rax], eax
0000705c0add0aa0  mov rax, [r15+0xF8]
0000705c0add0aa7  lea r14, [rax+0x100]
0000705c0add0aae  mov [r15], r14
0000705c0add0ab1  lea r14, [rax+0x178]
0000705c0add0ab8  mov [r15+0x08], r14
0000705c0add0abc  mov qword ptr [r15+0x10], 0x01
0000705c0add0ac4  mov qword ptr [r15+0xF0], 0x4102C8
0000705c0add0acf  mov r14d, [r15+0x320]
0000705c0add0ad6  mov eax, 0x4102C8
0000705c0add0adb  mov rcx, 0x705C0ADD0B40
0000705c0add0ae5  mov [r15+r14*8+0x328], rax
0000705c0add0aed  mov [r15+r14*8+0x368], rcx
0000705c0add0af5  add r14d, 0x01
0000705c0add0af9  and r14d, 0x07
0000705c0add0afd  mov [r15+0x320], r14d
0000705c0add0b04  cmp dword ptr [r15+0x318], 0x00
0000705c0add0b0c  jz 0x0000705C0ADCED70
0000705c0add0b12  nop [rax+rax*1], ax
0000705c0add0b1b  nop [rax+rax*1], eax
0000705c0add0b23  mov eax, 0x410728
0000705c0add0b28  mov [r15+0x100], rax
0000705c0add0b2f  jmp 0x0000705C0ABFE110
0000705c0add0b34  int3
0000705c0add0b35  int3
0000705c0add0b36  nop [rax+rax*1], ax
0000705c0add0b3f  nop
0000705c0add0b40  mov rax, [r15+0xF8]
0000705c0add0b47  lea r14, [rax+0x168]
0000705c0add0b4e  mov rax, [r13+r14*1]
0000705c0add0b53  mov [r15+0x40], rax
0000705c0add0b57  mov [rsp+0x10], rax
0000705c0add0b5c  xor eax, eax
0000705c0add0b5e  mov r14, [rsp+0x10]
0000705c0add0b63  mov r12d, 0x38
0000705c0add0b69  cmp r14, r12
0000705c0add0b6c  cmc
0000705c0add0b6d  lahf
0000705c0add0b6e  seto al
0000705c0add0b71  mov [r15+0x108], eax
0000705c0add0b78  mov eax, [r15+0x108]
0000705c0add0b7f  sahf
0000705c0add0b80  jnz 0x0000705C0ADD0BB2
0000705c0add0b82  cmp dword ptr [r15+0x318], 0x00
0000705c0add0b8a  jz 0x0000705C0ADD0BF0
0000705c0add0b90  nop [rax+rax*1], ax
0000705c0add0b99  nop [rax+rax*1], eax
0000705c0add0ba1  mov eax, 0x4102D4
0000705c0add0ba6  mov [r15+0x100], rax
0000705c0add0bad  jmp 0x0000705C0ABFE110
0000705c0add0bb2  cmp dword ptr [r15+0x318], 0x00
0000705c0add0bba  jz 0x0000705C0ADD0AA0
0000705c0add0bc0  nop [rax+rax*1], ax
0000705c0add0bc9  nop [rax+rax*1], eax
0000705c0add0bd1  mov eax, 0x4102B8
0000705c0add0bd6  mov [r15+0x100], rax
0000705c0add0bdd  jmp 0x0000705C0ABFE110
0000705c0add0be2  int3
0000705c0add0be3  call 0x0000705C0ACD59C0
0000705c0add0be8  jmp 0x0000705C0ADD0B53
0000705c0add0bed  int3
0000705c0add0bee  nop
0000705c0add0bf0  mov rax, [r15+0x98]
0000705c0add0bf7  rorx r14, rax, 0x3D
0000705c0add0bfd  and r14, 0xFFFFFFFFFFFFFFF8
0000705c0add0c01  mov rax, [r15+0xF8]
0000705c0add0c08  lea r12, [rax+0x100]
0000705c0add0c0f  mov [r15], r12
0000705c0add0c12  lea r12, [rax+0x170]
0000705c0add0c19  mov [r15+0x08], r12
0000705c0add0c1d  mov qword ptr [r15+0x10], 0x08
0000705c0add0c25  bswap r14
0000705c0add0c28  mov [r15+0x40], r14
0000705c0add0c2c  lea r12, [rax+0x170]
0000705c0add0c33  mov [r13+r12*1], r14
0000705c0add0c38  mov qword ptr [r15+0xF0], 0x4102F0
0000705c0add0c43  mov r14d, [r15+0x320]
0000705c0add0c4a  mov eax, 0x4102F0
0000705c0add0c4f  mov rcx, 0x705C0ADD0CC0
0000705c0add0c59  mov [r15+r14*8+0x328], rax
0000705c0add0c61  mov [r15+r14*8+0x368], rcx
0000705c0add0c69  add r14d, 0x01
0000705c0add0c6d  and r14d, 0x07
0000705c0add0c71  mov [r15+0x320], r14d
0000705c0add0c78  cmp dword ptr [r15+0x318], 0x00
0000705c0add0c80  jz 0x0000705C0ADCED70
0000705c0add0c86  nop [rax+rax*1], ax
0000705c0add0c8f  nop [rax+rax*1], eax
0000705c0add0c97  mov eax, 0x410728
0000705c0add0c9c  mov [r15+0x100], rax
0000705c0add0ca3  jmp 0x0000705C0ABFE110
0000705c0add0ca8  int3
0000705c0add0ca9  call 0x0000705C0ACC3FE0
0000705c0add0cae  jmp 0x0000705C0ADD0C38
0000705c0add0cb3  int3
0000705c0add0cb4  nop [rax+rax*1], ax
0000705c0add0cbd  nop [rax], eax
0000705c0add0cc0  mov rax, [r15+0xF8]
0000705c0add0cc7  lea r14, [rax+0x100]
0000705c0add0cce  mov r12d, [r13+r14*1]
0000705c0add0cd3  lea r14, [rax+0x104]
0000705c0add0cda  mov r11d, [r13+r14*1]
0000705c0add0cdf  mov qword ptr [r15+0x48], 0x430C90
0000705c0add0ce7  lea r14, [rax+0x108]
0000705c0add0cee  mov r10d, [r13+r14*1]
0000705c0add0cf3  lea r14, [rax+0x10C]
0000705c0add0cfa  mov r9d, [r13+r14*1]
0000705c0add0cff  bswap r12d
0000705c0add0d02  bswap r11d
0000705c0add0d05  mov qword ptr [r15+0xA0], 0x00
0000705c0add0d10  mov r14d, 0x430C90
0000705c0add0d16  mov [r13+r14*1], r12d
0000705c0add0d1b  mov r14d, 0x430C94
0000705c0add0d21  mov [r13+r14*1], r11d
0000705c0add0d26  bswap r10d
0000705c0add0d29  lea r14, [rax+0x110]
0000705c0add0d30  mov r12d, [r13+r14*1]
0000705c0add0d35  bswap r9d
0000705c0add0d38  lea r14, [rax+0x114]
0000705c0add0d3f  mov r11d, [r13+r14*1]
0000705c0add0d44  mov qword ptr [r15+0x98], 0x430DFC
0000705c0add0d4f  mov r14d, 0x430C98
0000705c0add0d55  mov [r13+r14*1], r10d
0000705c0add0d5a  mov r14d, 0x430C9C
0000705c0add0d60  mov [r13+r14*1], r9d
0000705c0add0d65  bswap r12d
0000705c0add0d68  lea r14, [rax+0x118]
0000705c0add0d6f  mov r10d, [r13+r14*1]
0000705c0add0d74  bswap r11d
0000705c0add0d77  mov [rsp+0x10], r11d
0000705c0add0d7c  mov r11d, r11d
0000705c0add0d7f  mov [r15+0x58], r11
0000705c0add0d83  lea r14, [rax+0x11C]
0000705c0add0d8a  mov eax, [r13+r14*1]
0000705c0add0d8f  mov [rsp+0x20], eax
0000705c0add0d93  mov eax, eax
0000705c0add0d95  mov [r15+0x60], rax
0000705c0add0d99  mov eax, 0x430CA0
0000705c0add0d9e  mov [r13+rax*1], r12d
0000705c0add0da3  mov eax, 0x430CA4
0000705c0add0da8  mov r14d, [rsp+0x10]
0000705c0add0dad  mov [r13+rax*1], r14d
0000705c0add0db2  bswap r10d
0000705c0add0db5  mov [rsp+0x10], r10d
0000705c0add0dba  mov r10d, r10d
0000705c0add0dbd  mov [r15+0x40], r10
0000705c0add0dc1  mov eax, [rsp+0x20]
0000705c0add0dc5  bswap eax
0000705c0add0dc7  mov [rsp+0x20], eax
0000705c0add0dcb  mov eax, eax
0000705c0add0dcd  mov [r15+0x50], rax
0000705c0add0dd1  mov eax, 0x430CA8
0000705c0add0dd6  mov r14d, [rsp+0x10]
0000705c0add0ddb  mov [r13+rax*1], r14d
0000705c0add0de0  mov eax, 0x430CAC
0000705c0add0de5  mov r14d, [rsp+0x20]
0000705c0add0dea  mov [r13+rax*1], r14d
0000705c0add0def  mov eax, [r15+0xA0]
0000705c0add0df6  lea r14d, [eax+0x11]
0000705c0add0dfb  mov r14d, r14d
0000705c0add0dfe  mov [r15], r14
0000705c0add0e01  mov qword ptr [r15+0xF0], 0x41035C
0000705c0add0e0c  mov r14d, [r15+0x320]
0000705c0add0e13  mov eax, 0x41035C
0000705c0add0e18  mov rcx, 0x705C0ADD0F90
0000705c0add0e22  mov [r15+r14*8+0x328], rax
0000705c0add0e2a  mov [r15+r14*8+0x368], rcx
0000705c0add0e32  add r14d, 0x01
0000705c0add0e36  and r14d, 0x07
0000705c0add0e3a  mov [r15+0x320], r14d
0000705c0add0e41  cmp dword ptr [r15+0x318], 0x00
0000705c0add0e49  jz 0x0000705C0ADD0F20
0000705c0add0e4f  nop [rax+rax*1], ax
0000705c0add0e58  nop [rax+rax*1], eax
0000705c0add0e60  mov eax, 0x4109A4
0000705c0add0e65  mov [r15+0x100], rax
0000705c0add0e6c  jmp 0x0000705C0ABFE110
0000705c0add0e71  int3
0000705c0add0e72  call 0x0000705C0ACE26A0
0000705c0add0e77  jmp 0x0000705C0ADD0CD3
0000705c0add0e7c  call 0x0000705C0ACE1430
0000705c0add0e81  jmp 0x0000705C0ADD0CDF
0000705c0add0e86  call 0x0000705C0ACE01C0
0000705c0add0e8b  jmp 0x0000705C0ADD0CF3
0000705c0add0e90  call 0x0000705C0ACDEF50
0000705c0add0e95  jmp 0x0000705C0ADD0CFF
0000705c0add0e9a  call 0x0000705C0ACE2BA0
0000705c0add0e9f  jmp 0x0000705C0ADD0D1B
0000705c0add0ea4  call 0x0000705C0ACE1920
0000705c0add0ea9  jmp 0x0000705C0ADD0D26
0000705c0add0eae  call 0x0000705C0ACE26A0
0000705c0add0eb3  jmp 0x0000705C0ADD0D35
0000705c0add0eb8  call 0x0000705C0ACE1430
0000705c0add0ebd  jmp 0x0000705C0ADD0D44
0000705c0add0ec2  call 0x0000705C0ACE06B0
0000705c0add0ec7  jmp 0x0000705C0ADD0D5A
0000705c0add0ecc  call 0x0000705C0ACDF440
0000705c0add0ed1  jmp 0x0000705C0ADD0D65
0000705c0add0ed6  call 0x0000705C0ACE01C0
0000705c0add0edb  jmp 0x0000705C0ADD0D74
0000705c0add0ee0  call 0x0000705C0ACD5890
0000705c0add0ee5  jmp 0x0000705C0ADD0D8F
0000705c0add0eea  call 0x0000705C0AC0BAE0
0000705c0add0eef  jmp 0x0000705C0ADD0DA3
0000705c0add0ef4  call 0x0000705C0AC0DFE0
0000705c0add0ef9  jmp 0x0000705C0ADD0DB2
0000705c0add0efe  call 0x0000705C0AC0DFE0
0000705c0add0f03  jmp 0x0000705C0ADD0DE0
0000705c0add0f08  call 0x0000705C0AC0DFE0
0000705c0add0f0d  jmp 0x0000705C0ADD0DEF
0000705c0add0f12  int3
0000705c0add0f13  nop [rax+rax*1], ax
0000705c0add0f1c  nop [rax], eax
0000705c0add0f20  mov eax, [r15]
0000705c0add0f23  mov [rsp+0x10], eax
0000705c0add0f27  shr eax, 0x10
0000705c0add0f2a  mov r14d, [rsp+0x10]
0000705c0add0f2f  xor r14d, eax
0000705c0add0f32  imul r14d, r14d, 0x7FEB352D
0000705c0add0f39  mov eax, 0x846CA68B
0000705c0add0f3e  mov eax, eax
0000705c0add0f40  mov [r15+0x48], rax
0000705c0add0f44  mov [rsp+0x10], r14d
0000705c0add0f49  shr r14d, 0x0F
0000705c0add0f4d  mov eax, [rsp+0x10]
0000705c0add0f51  xor eax, r14d
0000705c0add0f54  imul eax, eax, 0x846CA68B
0000705c0add0f5a  mov [rsp+0x10], eax
0000705c0add0f5e  mov eax, eax
0000705c0add0f60  mov [r15+0x40], rax
0000705c0add0f64  mov eax, [rsp+0x10]
0000705c0add0f68  shr eax, 0x10
0000705c0add0f6b  mov r14d, [rsp+0x10]
0000705c0add0f70  xor r14d, eax
0000705c0add0f73  mov r14d, r14d
0000705c0add0f76  mov [r15], r14
0000705c0add0f79  mov rax, [r15+0xF0]
0000705c0add0f80  mov [r15+0x100], rax
0000705c0add0f87  jmp 0x0000705C0ADCE5C0
0000705c0add0f8c  int3
0000705c0add0f8d  int3
0000705c0add0f8e  nop
0000705c0add0f90  mov rax, [r15+0xA0]
0000705c0add0f97  mov [rsp+0x10], rax
0000705c0add0f9c  shl rax, 0x02
0000705c0add0fa0  mov r14, [r15+0x98]
0000705c0add0fa7  lea r12, [r14+rax*1]
0000705c0add0fab  mov eax, [r15]
0000705c0add0fae  mov [r13+r12*1], eax
0000705c0add0fb3  mov rax, [rsp+0x10]
0000705c0add0fb8  lea r14, [rax+0x01]
0000705c0add0fbc  mov [r15+0xA0], r14
0000705c0add0fc3  xor eax, eax
0000705c0add0fc5  mov r12d, 0x400
0000705c0add0fcb  cmp r14, r12
0000705c0add0fce  cmc
0000705c0add0fcf  lahf
0000705c0add0fd0  seto al
0000705c0add0fd3  mov [r15+0x108], eax
0000705c0add0fda  mov eax, [r15+0x108]
0000705c0add0fe1  sahf
0000705c0add0fe2  jnz 0x0000705C0ADD1014
0000705c0add0fe4  cmp dword ptr [r15+0x318], 0x00
0000705c0add0fec  jz 0x0000705C0ADD10E0
0000705c0add0ff2  nop [rax+rax*1], ax
0000705c0add0ffb  nop [rax+rax*1], eax
0000705c0add1003  mov eax, 0x41036C
0000705c0add1008  mov [r15+0x100], rax
0000705c0add100f  jmp 0x0000705C0ABFE110
0000705c0add1014  cmp dword ptr [r15+0x318], 0x00
0000705c0add101c  jz 0x0000705C0ADD1050
0000705c0add1022  nop [rax+rax*1], ax
0000705c0add102b  nop [rax+rax*1], eax
0000705c0add1033  mov eax, 0x410354
0000705c0add1038  mov [r15+0x100], rax
0000705c0add103f  jmp 0x0000705C0ABFE110
0000705c0add1044  int3
0000705c0add1045  call 0x0000705C0ACB4B70
0000705c0add104a  jmp 0x0000705C0ADD0FB3
0000705c0add104f  int3
0000705c0add1050  mov eax, [r15+0xA0]
0000705c0add1057  lea r14d, [eax+0x11]
0000705c0add105c  mov r14d, r14d
0000705c0add105f  mov [r15], r14
0000705c0add1062  mov qword ptr [r15+0xF0], 0x41035C
0000705c0add106d  mov r14d, [r15+0x320]
0000705c0add1074  mov eax, 0x41035C
0000705c0add1079  mov rcx, 0x705C0ADD0F90
0000705c0add1083  mov [r15+r14*8+0x328], rax
0000705c0add108b  mov [r15+r14*8+0x368], rcx
0000705c0add1093  add r14d, 0x01
0000705c0add1097  and r14d, 0x07
0000705c0add109b  mov [r15+0x320], r14d
0000705c0add10a2  cmp dword ptr [r15+0x318], 0x00
0000705c0add10aa  jz 0x0000705C0ADD0F20
0000705c0add10b0  nop [rax+rax*1], ax
0000705c0add10b9  nop [rax+rax*1], eax
0000705c0add10c1  mov eax, 0x4109A4
0000705c0add10c6  mov [r15+0x100], rax
0000705c0add10cd  jmp 0x0000705C0ABFE110
0000705c0add10d2  int3
0000705c0add10d3  int3
0000705c0add10d4  nop [rax+rax*1], ax
0000705c0add10dd  nop [rax], eax
0000705c0add10e0  mov qword ptr [r15+0x40], 0x01
0000705c0add10e8  cmp dword ptr [r15+0x318], 0x00
0000705c0add10f0  jz 0x0000705C0ADD1120
0000705c0add10f6  nop [rax+rax*1], ax
0000705c0add10ff  nop [rax+rax*1], eax
0000705c0add1107  mov eax, 0x410388
0000705c0add110c  mov [r15+0x100], rax
0000705c0add1113  jmp 0x0000705C0ABFE110
0000705c0add1118  int3
0000705c0add1119  int3
0000705c0add111a  nop [rax+rax*1], ax
0000705c0add1120  mov rax, [r15+0x40]
0000705c0add1124  mov [rsp+0x10], rax
0000705c0add1129  shl rax, 0x02
0000705c0add112d  mov r14, [r15+0x98]
0000705c0add1134  lea r12, [r14+rax*1]
0000705c0add1138  mov eax, [r13+r12*1]
0000705c0add113d  mov [rsp+0x20], eax
0000705c0add1141  mov eax, eax
0000705c0add1143  mov [r15+0x48], rax
0000705c0add1147  mov rax, [rsp+0x10]
0000705c0add114c  mov [r15+0x50], rax
0000705c0add1150  mov eax, [r15+0x50]
0000705c0add1154  lea r12d, [eax-0x01]
0000705c0add1159  mov r12d, r12d
0000705c0add115c  mov [r15+0x58], r12
0000705c0add1160  mov rax, [r15+0x58]
0000705c0add1164  mov r12d, eax
0000705c0add1167  mov r12d, r12d
0000705c0add116a  shl r12, 0x02
0000705c0add116e  lea rax, [r14+r12*1]
0000705c0add1172  mov r14d, [r13+rax*1]
0000705c0add1177  mov [rsp+0x10], r14d
0000705c0add117c  mov r14d, r14d
0000705c0add117f  mov [r15+0x60], r14
0000705c0add1183  xor eax, eax
0000705c0add1185  mov r14d, [rsp+0x10]
0000705c0add118a  mov r12d, [rsp+0x20]
0000705c0add118f  cmp r14d, r12d
0000705c0add1192  cmc
0000705c0add1193  lahf
0000705c0add1194  seto al
0000705c0add1197  mov [r15+0x108], eax
0000705c0add119e  mov eax, [r15+0x108]
0000705c0add11a5  sahf
0000705c0add11a6  cmc
0000705c0add11a7  jbe 0x0000705C0ADD11D9
0000705c0add11a9  cmp dword ptr [r15+0x318], 0x00
0000705c0add11b1  jz 0x0000705C0ADD1220
0000705c0add11b7  nop [rax+rax*1], ax
0000705c0add11c0  nop [rax+rax*1], eax
0000705c0add11c8  mov eax, 0x4103A0
0000705c0add11cd  mov [r15+0x100], rax
0000705c0add11d4  jmp 0x0000705C0ABFE110
0000705c0add11d9  cmp dword ptr [r15+0x318], 0x00
0000705c0add11e1  jz 0x0000705C0ADD14C0
0000705c0add11e7  nop [rax+rax*1], ax
0000705c0add11f0  nop [rax+rax*1], eax
0000705c0add11f8  mov eax, 0x410378
0000705c0add11fd  mov [r15+0x100], rax
0000705c0add1204  jmp 0x0000705C0ABFE110
0000705c0add1209  int3
0000705c0add120a  call 0x0000705C0ACB4690
0000705c0add120f  jmp 0x0000705C0ADD113D
0000705c0add1214  call 0x0000705C0AC0DAE0
0000705c0add1219  jmp 0x0000705C0ADD1177
0000705c0add121e  int3
0000705c0add121f  nop
0000705c0add1220  mov rax, [r15+0x50]
0000705c0add1224  mov [rsp+0x10], rax
0000705c0add1229  shl rax, 0x02
0000705c0add122d  mov r14, [r15+0x98]
0000705c0add1234  lea r12, [r14+rax*1]
0000705c0add1238  mov eax, [r15+0x60]
0000705c0add123c  mov [r13+r12*1], eax
0000705c0add1241  mov rax, [rsp+0x10]
0000705c0add1246  lea r14, [rax-0x01]
0000705c0add124a  mov [r15+0x50], r14
0000705c0add124e  mov rax, [r15+0x58]
0000705c0add1252  test rax, rax
0000705c0add1255  setz al
0000705c0add1258  movzx rax, al
0000705c0add125c  mov [rsp+0x414], al
0000705c0add1263  cmp byte ptr [rsp+0x414], 0x00
0000705c0add126b  jz 0x0000705C0ADD129D
0000705c0add126d  cmp dword ptr [r15+0x318], 0x00
0000705c0add1275  jz 0x0000705C0ADD12E0
0000705c0add127b  nop [rax+rax*1], ax
0000705c0add1284  nop [rax+rax*1], eax
0000705c0add128c  mov eax, 0x4103AC
0000705c0add1291  mov [r15+0x100], rax
0000705c0add1298  jmp 0x0000705C0ABFE110
0000705c0add129d  cmp dword ptr [r15+0x318], 0x00
0000705c0add12a5  jz 0x0000705C0ADD13E0
0000705c0add12ab  nop [rax+rax*1], ax
0000705c0add12b4  nop [rax+rax*1], eax
0000705c0add12bc  mov eax, 0x410390
0000705c0add12c1  mov [r15+0x100], rax
0000705c0add12c8  jmp 0x0000705C0ABFE110
0000705c0add12cd  int3
0000705c0add12ce  call 0x0000705C0ACB4B70
0000705c0add12d3  jmp 0x0000705C0ADD1241
0000705c0add12d8  int3
0000705c0add12d9  nop [rax], eax
0000705c0add12e0  cmp dword ptr [r15+0x318], 0x00
0000705c0add12e8  jz 0x0000705C0ADD1320
0000705c0add12ee  nop [rax+rax*1], ax
0000705c0add12f7  nop [rax+rax*1], eax
0000705c0add12ff  mov eax, 0x410374
0000705c0add1304  mov [r15+0x100], rax
0000705c0add130b  jmp 0x0000705C0ABFE110
0000705c0add1310  int3
0000705c0add1311  int3
0000705c0add1312  nop [rax+rax*1], ax
0000705c0add131b  nop [rax+rax*1], eax
0000705c0add1320  mov qword ptr [r15+0x50], 0x00
0000705c0add1328  mov rax, [r15+0x40]
0000705c0add132c  lea r14, [rax+0x01]
0000705c0add1330  mov [r15+0x40], r14
0000705c0add1334  mov rax, [r15+0x98]
0000705c0add133b  mov r12d, [r15+0x48]
0000705c0add133f  mov [r13+rax*1], r12d
0000705c0add1344  xor eax, eax
0000705c0add1346  mov r12d, 0x400
0000705c0add134c  cmp r14, r12
0000705c0add134f  cmc
0000705c0add1350  lahf
0000705c0add1351  seto al
0000705c0add1354  mov [r15+0x108], eax
0000705c0add135b  mov eax, [r15+0x108]
0000705c0add1362  sahf
0000705c0add1363  jz 0x0000705C0ADD1395
0000705c0add1365  cmp dword ptr [r15+0x318], 0x00
0000705c0add136d  jz 0x0000705C0ADD1120
0000705c0add1373  nop [rax+rax*1], ax
0000705c0add137c  nop [rax+rax*1], eax
0000705c0add1384  mov eax, 0x410388
0000705c0add1389  mov [r15+0x100], rax
0000705c0add1390  jmp 0x0000705C0ABFE110
0000705c0add1395  cmp dword ptr [r15+0x318], 0x00
0000705c0add139d  jz 0x0000705C0ADD1580
0000705c0add13a3  nop [rax+rax*1], ax
0000705c0add13ac  nop [rax+rax*1], eax
0000705c0add13b4  mov eax, 0x4103B0
0000705c0add13b9  mov [r15+0x100], rax
0000705c0add13c0  jmp 0x0000705C0ABFE110
0000705c0add13c5  int3
0000705c0add13c6  call 0x0000705C0AC0BAE0
0000705c0add13cb  jmp 0x0000705C0ADD1344
0000705c0add13d0  int3
0000705c0add13d1  nop [rax+rax*1], ax
0000705c0add13da  nop [rax+rax*1], ax
0000705c0add13e0  mov eax, [r15+0x50]
0000705c0add13e4  lea r14d, [eax-0x01]
0000705c0add13e9  mov r14d, r14d
0000705c0add13ec  mov [r15+0x58], r14
0000705c0add13f0  mov rax, [r15+0x58]
0000705c0add13f4  mov r14d, eax
0000705c0add13f7  mov r14d, r14d
0000705c0add13fa  shl r14, 0x02
0000705c0add13fe  mov rax, [r15+0x98]
0000705c0add1405  lea r12, [rax+r14*1]
0000705c0add1409  mov eax, [r13+r12*1]
0000705c0add140e  mov [rsp+0x10], eax
0000705c0add1412  mov eax, eax
0000705c0add1414  mov [r15+0x60], rax
0000705c0add1418  mov eax, [r15+0x48]
0000705c0add141c  mov [rsp+0x20], eax
0000705c0add1420  xor eax, eax
0000705c0add1422  mov r14d, [rsp+0x10]
0000705c0add1427  mov r12d, [rsp+0x20]
0000705c0add142c  cmp r14d, r12d
0000705c0add142f  cmc
0000705c0add1430  lahf
0000705c0add1431  seto al
0000705c0add1434  mov [r15+0x108], eax
0000705c0add143b  mov eax, [r15+0x108]
0000705c0add1442  sahf
0000705c0add1443  cmc
0000705c0add1444  jbe 0x0000705C0ADD1476
0000705c0add1446  cmp dword ptr [r15+0x318], 0x00
0000705c0add144e  jz 0x0000705C0ADD1220
0000705c0add1454  nop [rax+rax*1], ax
0000705c0add145d  nop [rax+rax*1], eax
0000705c0add1465  mov eax, 0x4103A0
0000705c0add146a  mov [r15+0x100], rax
0000705c0add1471  jmp 0x0000705C0ABFE110
0000705c0add1476  cmp dword ptr [r15+0x318], 0x00
0000705c0add147e  jz 0x0000705C0ADD14C0
0000705c0add1484  nop [rax+rax*1], ax
0000705c0add148d  nop [rax+rax*1], eax
0000705c0add1495  mov eax, 0x410378
0000705c0add149a  mov [r15+0x100], rax
0000705c0add14a1  jmp 0x0000705C0ABFE110
0000705c0add14a6  int3
0000705c0add14a7  call 0x0000705C0ACB4690
0000705c0add14ac  jmp 0x0000705C0ADD140E
0000705c0add14b1  int3
0000705c0add14b2  nop [rax+rax*1], ax
0000705c0add14bb  nop [rax+rax*1], eax
0000705c0add14c0  mov rax, [r15+0x40]
0000705c0add14c4  lea r14, [rax+0x01]
0000705c0add14c8  mov [r15+0x40], r14
0000705c0add14cc  mov rax, [r15+0x50]
0000705c0add14d0  mov r12d, eax
0000705c0add14d3  mov r12d, r12d
0000705c0add14d6  shl r12, 0x02
0000705c0add14da  mov rax, [r15+0x98]
0000705c0add14e1  lea r11, [rax+r12*1]
0000705c0add14e5  mov eax, [r15+0x48]
0000705c0add14e9  mov [r13+r11*1], eax
0000705c0add14ee  xor eax, eax
0000705c0add14f0  mov r12d, 0x400
0000705c0add14f6  cmp r14, r12
0000705c0add14f9  cmc
0000705c0add14fa  lahf
0000705c0add14fb  seto al
0000705c0add14fe  mov [r15+0x108], eax
0000705c0add1505  mov eax, [r15+0x108]
0000705c0add150c  sahf
0000705c0add150d  jz 0x0000705C0ADD153F
0000705c0add150f  cmp dword ptr [r15+0x318], 0x00
0000705c0add1517  jz 0x0000705C0ADD1120
0000705c0add151d  nop [rax+rax*1], ax
0000705c0add1526  nop [rax+rax*1], eax
0000705c0add152e  mov eax, 0x410388
0000705c0add1533  mov [r15+0x100], rax
0000705c0add153a  jmp 0x0000705C0ABFE110
0000705c0add153f  cmp dword ptr [r15+0x318], 0x00
0000705c0add1547  jz 0x0000705C0ADD1580
0000705c0add154d  nop [rax+rax*1], ax
0000705c0add1556  nop [rax+rax*1], eax
0000705c0add155e  mov eax, 0x4103B0
0000705c0add1563  mov [r15+0x100], rax
0000705c0add156a  jmp 0x0000705C0ABFE110
0000705c0add156f  int3
0000705c0add1570  call 0x0000705C0ACA4270
0000705c0add1575  jmp 0x0000705C0ADD14EE
0000705c0add157a  int3
0000705c0add157b  nop [rax+rax*1], eax
0000705c0add1580  mov qword ptr [r15+0x40], 0x430000
0000705c0add1588  mov eax, 0x430CB0
0000705c0add158d  mov r14, [r13+rax*1]
0000705c0add1592  mov rax, [r15+0x98]
0000705c0add1599  mov r12d, [r13+rax*1]
0000705c0add159e  lea r11, [rax+0x04]
0000705c0add15a2  mov eax, [r13+r11*1]
0000705c0add15a7  mov r12d, r12d
0000705c0add15aa  mov [r15+0x68], r12
0000705c0add15ae  mov eax, eax
0000705c0add15b0  mov [r15+0x60], rax
0000705c0add15b4  mov rax, [r15+0x68]
0000705c0add15b8  mov [r15+0x68], rax
0000705c0add15bc  mov qword ptr [r15+0x58], 0x02
0000705c0add15c4  mov [rsp+0x10], rax
0000705c0add15c9  xor eax, eax
0000705c0add15cb  mov r12d, 0x02
0000705c0add15d1  mov r11d, 0x400
0000705c0add15d7  cmp r12, r11
0000705c0add15da  cmc
0000705c0add15db  lahf
0000705c0add15dc  seto al
0000705c0add15df  mov [r15+0x108], eax
0000705c0add15e6  mov rax, [r15+0x60]
0000705c0add15ea  mov r12d, 0x02
0000705c0add15f0  imul rax, r12
0000705c0add15f4  mov [r15+0x50], rax
0000705c0add15f8  mov rax, [rsp+0x10]
0000705c0add15fd  lea r12, [rax+r14*1]
0000705c0add1601  mov [r15+0x48], r12
0000705c0add1605  mov eax, [r15+0x108]
0000705c0add160c  sahf
0000705c0add160d  jnz 0x0000705C0ADD163F
0000705c0add160f  cmp dword ptr [r15+0x318], 0x00
0000705c0add1617  jz 0x0000705C0ADD17B0
0000705c0add161d  nop [rax+rax*1], ax
0000705c0add1626  nop [rax+rax*1], eax
0000705c0add162e  mov eax, 0x4103E0
0000705c0add1633  mov [r15+0x100], rax
0000705c0add163a  jmp 0x0000705C0ABFE110
0000705c0add163f  cmp dword ptr [r15+0x318], 0x00
0000705c0add1647  jz 0x0000705C0ADD1690
0000705c0add164d  nop [rax+rax*1], ax
0000705c0add1656  nop [rax+rax*1], eax
0000705c0add165e  mov eax, 0x4103C0
0000705c0add1663  mov [r15+0x100], rax
0000705c0add166a  jmp 0x0000705C0ABFE110
0000705c0add166f  int3
0000705c0add1670  call 0x0000705C0AC0DC20
0000705c0add1675  jmp 0x0000705C0ADD1592
0000705c0add167a  call 0x0000705C0AC0B5E0
0000705c0add167f  jmp 0x0000705C0ADD159E
0000705c0add1684  call 0x0000705C0ACA3D90
0000705c0add1689  jmp 0x0000705C0ADD15A7
0000705c0add168e  int3
0000705c0add168f  nop
0000705c0add1690  mov rax, [r15+0x98]
0000705c0add1697  mov r14, [r15+0x58]
0000705c0add169b  mov [rsp+0x10], r14
0000705c0add16a0  shl r14, 0x02
0000705c0add16a4  lea r12, [rax+r14*1]
0000705c0add16a8  mov eax, [r13+r12*1]
0000705c0add16ad  lea r14, [r12+0x04]
0000705c0add16b2  mov r12d, [r13+r14*1]
0000705c0add16b7  mov eax, eax
0000705c0add16b9  mov [r15+0x68], rax
0000705c0add16bd  mov r12d, r12d
0000705c0add16c0  mov [r15+0x60], r12
0000705c0add16c4  mov rax, [r15+0x68]
0000705c0add16c8  mov [rsp+0x20], rax
0000705c0add16cd  mov r14, [rsp+0x10]
0000705c0add16d2  imul rax, r14
0000705c0add16d6  mov r12, [rsp+0x20]
0000705c0add16db  lea r11, [r12+rax*1]
0000705c0add16df  mov [r15+0x68], r11
0000705c0add16e3  lea rax, [r14+0x02]
0000705c0add16e7  mov [r15+0x58], rax
0000705c0add16eb  mov [rsp+0x10], rax
0000705c0add16f0  xor eax, eax
0000705c0add16f2  mov r14, [rsp+0x10]
0000705c0add16f7  mov r12d, 0x400
0000705c0add16fd  cmp r14, r12
0000705c0add1700  cmc
0000705c0add1701  lahf
0000705c0add1702  seto al
0000705c0add1705  mov [r15+0x108], eax
0000705c0add170c  mov rax, [r15+0x50]
0000705c0add1710  mov r12, [r15+0x60]
0000705c0add1714  imul r14, r12
0000705c0add1718  lea r12, [rax+r14*1]
0000705c0add171c  mov [r15+0x50], r12
0000705c0add1720  mov rax, [r15+0x48]
0000705c0add1724  lea r14, [r11+rax*1]
0000705c0add1728  mov [r15+0x48], r14
0000705c0add172c  mov eax, [r15+0x108]
0000705c0add1733  sahf
0000705c0add1734  jnz 0x0000705C0ADD1766
0000705c0add1736  cmp dword ptr [r15+0x318], 0x00
0000705c0add173e  jz 0x0000705C0ADD17B0
0000705c0add1744  nop [rax+rax*1], ax
0000705c0add174d  nop [rax+rax*1], eax
0000705c0add1755  mov eax, 0x4103E0
0000705c0add175a  mov [r15+0x100], rax
0000705c0add1761  jmp 0x0000705C0ABFE110
0000705c0add1766  cmp dword ptr [r15+0x318], 0x00
0000705c0add176e  jz 0x0000705C0ADD1690
0000705c0add1774  nop [rax+rax*1], ax
0000705c0add177d  nop [rax+rax*1], eax
0000705c0add1785  mov eax, 0x4103C0
0000705c0add178a  mov [r15+0x100], rax
0000705c0add1791  jmp 0x0000705C0ABFE110
0000705c0add1796  int3
0000705c0add1797  call 0x0000705C0ACB4690
0000705c0add179c  jmp 0x0000705C0ADD16AD
0000705c0add17a1  call 0x0000705C0ACE26A0
0000705c0add17a6  jmp 0x0000705C0ADD16B7
0000705c0add17ab  int3
0000705c0add17ac  nop [rax], eax
0000705c0add17b0  mov qword ptr [r15+0x98], 0x00
0000705c0add17bb  mov rax, [r15+0x50]
0000705c0add17bf  mov r14, [r15+0x48]
0000705c0add17c3  lea r12, [rax+r14*1]
0000705c0add17c7  mov [r15+0x48], r12
0000705c0add17cb  mov rax, [r15+0x40]
0000705c0add17cf  lea r14, [rax+0xCB0]
0000705c0add17d6  mov [r13+r14*1], r12
0000705c0add17db  mov qword ptr [r15], 0x01
0000705c0add17e2  mov qword ptr [r15+0xF0], 0x4103F8
0000705c0add17ed  mov r14d, [r15+0x320]
0000705c0add17f4  mov eax, 0x4103F8
0000705c0add17f9  mov rcx, 0x705C0ADD1860
0000705c0add1803  mov [r15+r14*8+0x328], rax
0000705c0add180b  mov [r15+r14*8+0x368], rcx
0000705c0add1813  add r14d, 0x01
0000705c0add1817  and r14d, 0x07
0000705c0add181b  mov [r15+0x320], r14d
0000705c0add1822  cmp dword ptr [r15+0x318], 0x00
0000705c0add182a  jz 0x0000705C0ADD0F20
0000705c0add1830  nop [rax+rax*1], ax
0000705c0add1839  nop [rax+rax*1], eax
0000705c0add1841  mov eax, 0x4109A4
0000705c0add1846  mov [r15+0x100], rax
0000705c0add184d  jmp 0x0000705C0ABFE110
0000705c0add1852  int3
0000705c0add1853  call 0x0000705C0ACE2CE0
0000705c0add1858  jmp 0x0000705C0ADD17DB
0000705c0add185d  int3
0000705c0add185e  nop
0000705c0add1860  mov eax, [r15+0x98]
0000705c0add1867  lea r14d, [eax+0x01]
0000705c0add186c  mov [rsp+0x10], r14d
0000705c0add1871  mov r14d, r14d
0000705c0add1874  mov [r15+0x98], r14
0000705c0add187b  xor eax, eax
0000705c0add187d  mov r14d, [rsp+0x10]
0000705c0add1882  cmp r14d, 0x10000
0000705c0add1889  cmc
0000705c0add188a  lahf
0000705c0add188b  seto al
0000705c0add188e  mov [r15+0x108], eax
0000705c0add1895  mov eax, [r15+0x108]
0000705c0add189c  sahf
0000705c0add189d  jnz 0x0000705C0ADD18CF
0000705c0add189f  cmp dword ptr [r15+0x318], 0x00
0000705c0add18a7  jz 0x0000705C0ADD19A0
0000705c0add18ad  nop [rax+rax*1], ax
0000705c0add18b6  nop [rax+rax*1], eax
0000705c0add18be  mov eax, 0x410404
0000705c0add18c3  mov [r15+0x100], rax
0000705c0add18ca  jmp 0x0000705C0ABFE110
0000705c0add18cf  cmp dword ptr [r15+0x318], 0x00
0000705c0add18d7  jz 0x0000705C0ADD1910
0000705c0add18dd  nop [rax+rax*1], ax
0000705c0add18e6  nop [rax+rax*1], eax
0000705c0add18ee  mov eax, 0x4103F0
0000705c0add18f3  mov [r15+0x100], rax
0000705c0add18fa  jmp 0x0000705C0ABFE110
0000705c0add18ff  int3
0000705c0add1900  int3
0000705c0add1901  nop [rax+rax*1], ax
0000705c0add190a  nop [rax+rax*1], ax
0000705c0add1910  mov eax, [r15]
0000705c0add1913  mov r14d, [r15+0x98]
0000705c0add191a  lea r12d, [eax+r14d*1]
0000705c0add191f  mov r12d, r12d
0000705c0add1922  mov [r15], r12
0000705c0add1925  mov qword ptr [r15+0xF0], 0x4103F8
0000705c0add1930  mov r14d, [r15+0x320]
0000705c0add1937  mov eax, 0x4103F8
0000705c0add193c  mov rcx, 0x705C0ADD1860
0000705c0add1946  mov [r15+r14*8+0x328], rax
0000705c0add194e  mov [r15+r14*8+0x368], rcx
0000705c0add1956  add r14d, 0x01
0000705c0add195a  and r14d, 0x07
0000705c0add195e  mov [r15+0x320], r14d
0000705c0add1965  cmp dword ptr [r15+0x318], 0x00
0000705c0add196d  jz 0x0000705C0ADD0F20
0000705c0add1973  nop [rax+rax*1], ax
0000705c0add197c  nop [rax+rax*1], eax
0000705c0add1984  mov eax, 0x4109A4
0000705c0add1989  mov [r15+0x100], rax
0000705c0add1990  jmp 0x0000705C0ABFE110
0000705c0add1995  int3
0000705c0add1996  int3
0000705c0add1997  nop [rax+rax*1], ax
0000705c0add19a0  vmovaps xmm1, [0x0000705C0A9FE010]
0000705c0add19a8  movq xmm1, xmm1
0000705c0add19ac  movaps [r15+0x110], xmm1
0000705c0add19b4  mov eax, 0x420B10
0000705c0add19b9  mov r14, [r13+rax*1]
0000705c0add19be  movq xmm1, r14
0000705c0add19c3  movaps [r15+0x120], xmm1
0000705c0add19cb  vmovaps xmm1, [0x0000705C0A9FE020]
0000705c0add19d3  movq xmm1, xmm1
0000705c0add19d7  movaps [r15+0x140], xmm1
0000705c0add19df  vmovaps xmm1, [0x0000705C0A9FE030]
0000705c0add19e7  vpbroadcastq xmm1, xmm1
0000705c0add19ec  movaps [r15+0x150], xmm1
0000705c0add19f4  mov qword ptr [r15+0x40], 0x02
0000705c0add19fc  vmovaps xmm15, [0x0000705C0A9FE040]
0000705c0add1a04  movq xmm15, xmm15
0000705c0add1a09  movaps [r15+0x160], xmm15
0000705c0add1a11  vmovaps xmm15, [0x0000705C0A9FE050]
0000705c0add1a19  vpbroadcastq xmm15, xmm15
0000705c0add1a1e  movaps [r15+0x130], xmm15
0000705c0add1a26  mov rax, [r15+0x40]
0000705c0add1a2a  vmovq xmm14, rax
0000705c0add1a2f  vpbroadcastq xmm14, xmm14
0000705c0add1a34  movaps [r15+0x170], xmm14
0000705c0add1a3c  mov eax, 0x420A40
0000705c0add1a41  movups xmm13, [r13+rax*1]
0000705c0add1a47  mov qword ptr [r15+0x40], 0x431E00
0000705c0add1a4f  mov eax, [r15]
0000705c0add1a52  mov r14d, 0x430CB8
0000705c0add1a58  mov [r13+r14*1], eax
0000705c0add1a5d  mov qword ptr [r15+0x50], 0x432000
0000705c0add1a65  vpmovqd xmm12, xmm13
0000705c0add1a6b  pxor xmm11, xmm11
0000705c0add1a70  punpcklqdq xmm12, xmm11
0000705c0add1a75  movaps [r15+0x210], xmm12
0000705c0add1a7d  movq xmm12, qword ptr [r15+0x140]
0000705c0add1a86  movq xmm11, qword ptr [r15+0x120]
0000705c0add1a8f  psubd xmm12, xmm11
0000705c0add1a94  movq xmm12, xmm12
0000705c0add1a99  paddq xmm13, xmm14
0000705c0add1a9e  movaps [r15+0x180], xmm13
0000705c0add1aa6  movq xmm14, qword ptr [r15+0x160]
0000705c0add1aaf  paddd xmm11, xmm14
0000705c0add1ab4  movq xmm11, xmm11
0000705c0add1ab9  movq xmm11, xmm11
0000705c0add1abe  movaps [r15+0x120], xmm11
0000705c0add1ac6  pmovzxdq xmm12, xmm12
0000705c0add1acc  psllq xmm12, 0x00
0000705c0add1ad2  movq xmm14, qword ptr [r15+0x210]
0000705c0add1adb  movq xmm13, qword ptr [r15+0x110]
0000705c0add1ae4  paddd xmm14, xmm13
0000705c0add1ae9  movq xmm14, xmm14
0000705c0add1aee  vcvtuqq2pd xmm12, xmm12
0000705c0add1af4  pmovzxdq xmm14, xmm14
0000705c0add1afa  psllq xmm14, 0x00
0000705c0add1b00  vcvtuqq2pd xmm14, xmm14
0000705c0add1b06  movaps xmm13, xmm12
0000705c0add1b0a  mulpd xmm13, xmm1
0000705c0add1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
0000705c0add1b15  ptest xmm11, xmm11
0000705c0add1b1b  jnz 0x0000705C0ADD1C0F
0000705c0add1b21  movaps [r15+0x220], xmm13
0000705c0add1b29  mov eax, 0x432000
0000705c0add1b2e  movups [r13+rax*1], xmm13
0000705c0add1b34  movaps xmm1, xmm14
0000705c0add1b38  mulpd xmm1, xmm15
0000705c0add1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
0000705c0add1b42  ptest xmm13, xmm13
0000705c0add1b48  jnz 0x0000705C0ADD1D5C
0000705c0add1b4e  movaps [r15+0x210], xmm1
0000705c0add1b56  mov eax, 0x431E00
0000705c0add1b5b  movups [r13+rax*1], xmm1
0000705c0add1b61  mov qword ptr [r15+0x48], 0x10
0000705c0add1b69  xor eax, eax
0000705c0add1b6b  mov r14d, 0x10
0000705c0add1b71  mov r12d, 0x200
0000705c0add1b77  cmp r14, r12
0000705c0add1b7a  cmc
0000705c0add1b7b  lahf
0000705c0add1b7c  seto al
0000705c0add1b7f  mov [r15+0x108], eax
0000705c0add1b86  mov eax, [r15+0x108]
0000705c0add1b8d  sahf
0000705c0add1b8e  jnz 0x0000705C0ADD1BC0
0000705c0add1b90  cmp dword ptr [r15+0x318], 0x00
0000705c0add1b98  jz 0x0000705C0ADD2300
0000705c0add1b9e  nop [rax+rax*1], ax
0000705c0add1ba7  nop [rax+rax*1], eax
0000705c0add1baf  mov eax, 0x410490
0000705c0add1bb4  mov [r15+0x100], rax
0000705c0add1bbb  jmp 0x0000705C0ABFE110
0000705c0add1bc0  cmp dword ptr [r15+0x318], 0x00
0000705c0add1bc8  jz 0x0000705C0ADD1EB0
0000705c0add1bce  nop [rax+rax*1], ax
0000705c0add1bd7  nop [rax+rax*1], eax
0000705c0add1bdf  mov eax, 0x410450
0000705c0add1be4  mov [r15+0x100], rax
0000705c0add1beb  jmp 0x0000705C0ABFE110
0000705c0add1bf0  int3
0000705c0add1bf1  call 0x0000705C0AC0DC20
0000705c0add1bf6  jmp 0x0000705C0ADD19BE
0000705c0add1bfb  call 0x0000705C0AC0C260
0000705c0add1c00  jmp 0x0000705C0ADD1A47
0000705c0add1c05  call 0x0000705C0ACD5D70
0000705c0add1c0a  jmp 0x0000705C0ADD1A5D
0000705c0add1c0f  sub rsp, 0x08
0000705c0add1c13  push rax
0000705c0add1c14  push rcx
0000705c0add1c15  push rdx
0000705c0add1c16  push rdi
0000705c0add1c17  push rsi
0000705c0add1c18  push r8
0000705c0add1c1a  push r9
0000705c0add1c1c  push r10
0000705c0add1c1e  push r11
0000705c0add1c20  sub rsp, 0xF0
0000705c0add1c27  vmovaps [rsp], xmm0
0000705c0add1c2c  vmovaps [rsp+0x10], xmm1
0000705c0add1c32  vmovaps [rsp+0x20], xmm2
0000705c0add1c38  vmovaps [rsp+0x30], xmm3
0000705c0add1c3e  vmovaps [rsp+0x40], xmm4
0000705c0add1c44  vmovaps [rsp+0x50], xmm5
0000705c0add1c4a  vmovaps [rsp+0x60], xmm6
0000705c0add1c50  vmovaps [rsp+0x70], xmm7
0000705c0add1c56  vmovaps [rsp+0x80], xmm8
0000705c0add1c5f  vmovaps [rsp+0x90], xmm9
0000705c0add1c68  vmovaps [rsp+0xA0], xmm10
0000705c0add1c71  vmovaps [rsp+0xB0], xmm11
0000705c0add1c7a  vmovaps [rsp+0xC0], xmm12
0000705c0add1c83  vmovaps [rsp+0xD0], xmm14
0000705c0add1c8c  vmovaps [rsp+0xE0], xmm15
0000705c0add1c95  sub rsp, 0x30
0000705c0add1c99  movaps [rsp], xmm13
0000705c0add1c9e  movaps [rsp+0x10], xmm12
0000705c0add1ca4  movaps [rsp+0x20], xmm1
0000705c0add1ca9  lea rdi, [rsp]
0000705c0add1cad  mov esi, 0x00
0000705c0add1cb2  mov rax, 0x5969C28C4530
0000705c0add1cbc  call rax
0000705c0add1cbe  movaps xmm13, [rsp]
0000705c0add1cc3  add rsp, 0x30
0000705c0add1cc7  vmovaps xmm0, [rsp]
0000705c0add1ccc  vmovaps xmm1, [rsp+0x10]
0000705c0add1cd2  vmovaps xmm2, [rsp+0x20]
0000705c0add1cd8  vmovaps xmm3, [rsp+0x30]
0000705c0add1cde  vmovaps xmm4, [rsp+0x40]
0000705c0add1ce4  vmovaps xmm5, [rsp+0x50]
0000705c0add1cea  vmovaps xmm6, [rsp+0x60]
0000705c0add1cf0  vmovaps xmm7, [rsp+0x70]
0000705c0add1cf6  vmovaps xmm8, [rsp+0x80]
0000705c0add1cff  vmovaps xmm9, [rsp+0x90]
0000705c0add1d08  vmovaps xmm10, [rsp+0xA0]
0000705c0add1d11  vmovaps xmm11, [rsp+0xB0]
0000705c0add1d1a  vmovaps xmm12, [rsp+0xC0]
0000705c0add1d23  vmovaps xmm14, [rsp+0xD0]
0000705c0add1d2c  vmovaps xmm15, [rsp+0xE0]
0000705c0add1d35  add rsp, 0xF0
0000705c0add1d3c  pop r11
0000705c0add1d3e  pop r10
0000705c0add1d40  pop r9
0000705c0add1d42  pop r8
0000705c0add1d44  pop rsi
0000705c0add1d45  pop rdi
0000705c0add1d46  pop rdx
0000705c0add1d47  pop rcx
0000705c0add1d48  pop rax
0000705c0add1d49  add rsp, 0x08
0000705c0add1d4d  jmp 0x0000705C0ADD1B21
0000705c0add1d52  call 0x0000705C0AC0C380
0000705c0add1d57  jmp 0x0000705C0ADD1B34
0000705c0add1d5c  sub rsp, 0x08
0000705c0add1d60  push rax
0000705c0add1d61  push rcx
0000705c0add1d62  push rdx
0000705c0add1d63  push rdi
0000705c0add1d64  push rsi
0000705c0add1d65  push r8
0000705c0add1d67  push r9
0000705c0add1d69  push r10
0000705c0add1d6b  push r11
0000705c0add1d6d  sub rsp, 0xF0
0000705c0add1d74  vmovaps [rsp], xmm0
0000705c0add1d79  vmovaps [rsp+0x10], xmm2
0000705c0add1d7f  vmovaps [rsp+0x20], xmm3
0000705c0add1d85  vmovaps [rsp+0x30], xmm4
0000705c0add1d8b  vmovaps [rsp+0x40], xmm5
0000705c0add1d91  vmovaps [rsp+0x50], xmm6
0000705c0add1d97  vmovaps [rsp+0x60], xmm7
0000705c0add1d9d  vmovaps [rsp+0x70], xmm8
0000705c0add1da3  vmovaps [rsp+0x80], xmm9
0000705c0add1dac  vmovaps [rsp+0x90], xmm10
0000705c0add1db5  vmovaps [rsp+0xA0], xmm11
0000705c0add1dbe  vmovaps [rsp+0xB0], xmm12
0000705c0add1dc7  vmovaps [rsp+0xC0], xmm13
0000705c0add1dd0  vmovaps [rsp+0xD0], xmm14
0000705c0add1dd9  vmovaps [rsp+0xE0], xmm15
0000705c0add1de2  sub rsp, 0x30
0000705c0add1de6  movaps [rsp], xmm1
0000705c0add1dea  movaps [rsp+0x10], xmm14
0000705c0add1df0  movaps [rsp+0x20], xmm15
0000705c0add1df6  lea rdi, [rsp]
0000705c0add1dfa  mov esi, 0x00
0000705c0add1dff  mov rax, 0x5969C28C4530
0000705c0add1e09  call rax
0000705c0add1e0b  movaps xmm1, [rsp]
0000705c0add1e0f  add rsp, 0x30
0000705c0add1e13  vmovaps xmm0, [rsp]
0000705c0add1e18  vmovaps xmm2, [rsp+0x10]
0000705c0add1e1e  vmovaps xmm3, [rsp+0x20]
0000705c0add1e24  vmovaps xmm4, [rsp+0x30]
0000705c0add1e2a  vmovaps xmm5, [rsp+0x40]
0000705c0add1e30  vmovaps xmm6, [rsp+0x50]
0000705c0add1e36  vmovaps xmm7, [rsp+0x60]
0000705c0add1e3c  vmovaps xmm8, [rsp+0x70]
0000705c0add1e42  vmovaps xmm9, [rsp+0x80]
0000705c0add1e4b  vmovaps xmm10, [rsp+0x90]
0000705c0add1e54  vmovaps xmm11, [rsp+0xA0]
0000705c0add1e5d  vmovaps xmm12, [rsp+0xB0]
0000705c0add1e66  vmovaps xmm13, [rsp+0xC0]
0000705c0add1e6f  vmovaps xmm14, [rsp+0xD0]
0000705c0add1e78  vmovaps xmm15, [rsp+0xE0]
0000705c0add1e81  add rsp, 0xF0
0000705c0add1e88  pop r11
0000705c0add1e8a  pop r10
0000705c0add1e8c  pop r9
0000705c0add1e8e  pop r8
0000705c0add1e90  pop rsi
0000705c0add1e91  pop rdi
0000705c0add1e92  pop rdx
0000705c0add1e93  pop rcx
0000705c0add1e94  pop rax
0000705c0add1e95  add rsp, 0x08
0000705c0add1e99  jmp 0x0000705C0ADD1B4E
0000705c0add1e9e  call 0x0000705C0ABFF540
0000705c0add1ea3  jmp 0x0000705C0ADD1B61
0000705c0add1ea8  int3
0000705c0add1ea9  nop [rax], eax
0000705c0add1eb0  movaps xmm1, [r15+0x180]
0000705c0add1eb8  vpmovqd xmm15, xmm1
0000705c0add1ebe  pxor xmm14, xmm14
0000705c0add1ec3  punpcklqdq xmm15, xmm14
0000705c0add1ec8  movaps [r15+0x210], xmm15
0000705c0add1ed0  movq xmm15, qword ptr [r15+0x140]
0000705c0add1ed9  movq xmm14, qword ptr [r15+0x120]
0000705c0add1ee2  psubd xmm15, xmm14
0000705c0add1ee7  movq xmm15, xmm15
0000705c0add1eec  movaps xmm13, [r15+0x170]
0000705c0add1ef4  paddq xmm1, xmm13
0000705c0add1ef9  movaps [r15+0x180], xmm1
0000705c0add1f01  movq xmm1, qword ptr [r15+0x160]
0000705c0add1f0a  paddd xmm14, xmm1
0000705c0add1f0f  movq xmm14, xmm14
0000705c0add1f14  movq xmm14, xmm14
0000705c0add1f19  movaps [r15+0x120], xmm14
0000705c0add1f21  pmovzxdq xmm15, xmm15
0000705c0add1f27  psllq xmm15, 0x00
0000705c0add1f2d  movq xmm1, qword ptr [r15+0x210]
0000705c0add1f36  movq xmm14, qword ptr [r15+0x110]
0000705c0add1f3f  paddd xmm1, xmm14
0000705c0add1f44  movq xmm1, xmm1
0000705c0add1f48  vcvtuqq2pd xmm15, xmm15
0000705c0add1f4e  pmovzxdq xmm1, xmm1
0000705c0add1f53  psllq xmm1, 0x00
0000705c0add1f58  vcvtuqq2pd xmm1, xmm1
0000705c0add1f5e  movaps xmm14, [r15+0x150]
0000705c0add1f66  movaps xmm13, xmm15
0000705c0add1f6a  mulpd xmm13, xmm14
0000705c0add1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
0000705c0add1f75  ptest xmm12, xmm12
0000705c0add1f7b  jnz 0x0000705C0ADD205E
0000705c0add1f81  movaps [r15+0x220], xmm13
0000705c0add1f89  mov rax, [r15+0x48]
0000705c0add1f8d  mov r14, [r15+0x50]
0000705c0add1f91  lea r12, [r14+rax*1]
0000705c0add1f95  movups [r13+r12*1], xmm13
0000705c0add1f9b  movaps xmm15, [r15+0x130]
0000705c0add1fa3  movaps xmm14, xmm1
0000705c0add1fa7  mulpd xmm14, xmm15
0000705c0add1fac  vcmppd xmm13, xmm14, xmm14, 0x03
0000705c0add1fb2  ptest xmm13, xmm13
0000705c0add1fb8  jnz 0x0000705C0ADD21AC
0000705c0add1fbe  movaps [r15+0x210], xmm14
0000705c0add1fc6  mov r14, [r15+0x40]
0000705c0add1fca  lea r12, [r14+rax*1]
0000705c0add1fce  movups [r13+r12*1], xmm14
0000705c0add1fd4  lea r14, [rax+0x10]
0000705c0add1fd8  mov [r15+0x48], r14
0000705c0add1fdc  xor eax, eax
0000705c0add1fde  mov r12d, 0x200
0000705c0add1fe4  cmp r14, r12
0000705c0add1fe7  cmc
0000705c0add1fe8  lahf
0000705c0add1fe9  seto al
0000705c0add1fec  mov [r15+0x108], eax
0000705c0add1ff3  mov eax, [r15+0x108]
0000705c0add1ffa  sahf
0000705c0add1ffb  jnz 0x0000705C0ADD202D
0000705c0add1ffd  cmp dword ptr [r15+0x318], 0x00
0000705c0add2005  jz 0x0000705C0ADD2300
0000705c0add200b  nop [rax+rax*1], ax
0000705c0add2014  nop [rax+rax*1], eax
0000705c0add201c  mov eax, 0x410490
0000705c0add2021  mov [r15+0x100], rax
0000705c0add2028  jmp 0x0000705C0ABFE110
0000705c0add202d  cmp dword ptr [r15+0x318], 0x00
0000705c0add2035  jz 0x0000705C0ADD1EB0
0000705c0add203b  nop [rax+rax*1], ax
0000705c0add2044  nop [rax+rax*1], eax
0000705c0add204c  mov eax, 0x410450
0000705c0add2051  mov [r15+0x100], rax
0000705c0add2058  jmp 0x0000705C0ABFE110
0000705c0add205d  int3
0000705c0add205e  sub rsp, 0x08
0000705c0add2062  push rax
0000705c0add2063  push rcx
0000705c0add2064  push rdx
0000705c0add2065  push rdi
0000705c0add2066  push rsi
0000705c0add2067  push r8
0000705c0add2069  push r9
0000705c0add206b  push r10
0000705c0add206d  push r11
0000705c0add206f  sub rsp, 0xF0
0000705c0add2076  vmovaps [rsp], xmm0
0000705c0add207b  vmovaps [rsp+0x10], xmm1
0000705c0add2081  vmovaps [rsp+0x20], xmm2
0000705c0add2087  vmovaps [rsp+0x30], xmm3
0000705c0add208d  vmovaps [rsp+0x40], xmm4
0000705c0add2093  vmovaps [rsp+0x50], xmm5
0000705c0add2099  vmovaps [rsp+0x60], xmm6
0000705c0add209f  vmovaps [rsp+0x70], xmm7
0000705c0add20a5  vmovaps [rsp+0x80], xmm8
0000705c0add20ae  vmovaps [rsp+0x90], xmm9
0000705c0add20b7  vmovaps [rsp+0xA0], xmm10
0000705c0add20c0  vmovaps [rsp+0xB0], xmm11
0000705c0add20c9  vmovaps [rsp+0xC0], xmm12
0000705c0add20d2  vmovaps [rsp+0xD0], xmm14
0000705c0add20db  vmovaps [rsp+0xE0], xmm15
0000705c0add20e4  sub rsp, 0x30
0000705c0add20e8  movaps [rsp], xmm13
0000705c0add20ed  movaps [rsp+0x10], xmm15
0000705c0add20f3  movaps [rsp+0x20], xmm14
0000705c0add20f9  lea rdi, [rsp]
0000705c0add20fd  mov esi, 0x00
0000705c0add2102  mov rax, 0x5969C28C4530
0000705c0add210c  call rax
0000705c0add210e  movaps xmm13, [rsp]
0000705c0add2113  add rsp, 0x30
0000705c0add2117  vmovaps xmm0, [rsp]
0000705c0add211c  vmovaps xmm1, [rsp+0x10]
0000705c0add2122  vmovaps xmm2, [rsp+0x20]
0000705c0add2128  vmovaps xmm3, [rsp+0x30]
0000705c0add212e  vmovaps xmm4, [rsp+0x40]
0000705c0add2134  vmovaps xmm5, [rsp+0x50]
0000705c0add213a  vmovaps xmm6, [rsp+0x60]
0000705c0add2140  vmovaps xmm7, [rsp+0x70]
0000705c0add2146  vmovaps xmm8, [rsp+0x80]
0000705c0add214f  vmovaps xmm9, [rsp+0x90]
0000705c0add2158  vmovaps xmm10, [rsp+0xA0]
0000705c0add2161  vmovaps xmm11, [rsp+0xB0]
0000705c0add216a  vmovaps xmm12, [rsp+0xC0]
0000705c0add2173  vmovaps xmm14, [rsp+0xD0]
0000705c0add217c  vmovaps xmm15, [rsp+0xE0]
0000705c0add2185  add rsp, 0xF0
0000705c0add218c  pop r11
0000705c0add218e  pop r10
0000705c0add2190  pop r9
0000705c0add2192  pop r8
0000705c0add2194  pop rsi
0000705c0add2195  pop rdi
0000705c0add2196  pop rdx
0000705c0add2197  pop rcx
0000705c0add2198  pop rax
0000705c0add2199  add rsp, 0x08
0000705c0add219d  jmp 0x0000705C0ADD1F81
0000705c0add21a2  call 0x0000705C0ACC2240
0000705c0add21a7  jmp 0x0000705C0ADD1F9B
0000705c0add21ac  sub rsp, 0x08
0000705c0add21b0  push rax
0000705c0add21b1  push rcx
0000705c0add21b2  push rdx
0000705c0add21b3  push rdi
0000705c0add21b4  push rsi
0000705c0add21b5  push r8
0000705c0add21b7  push r9
0000705c0add21b9  push r10
0000705c0add21bb  push r11
0000705c0add21bd  sub rsp, 0xF0
0000705c0add21c4  vmovaps [rsp], xmm0
0000705c0add21c9  vmovaps [rsp+0x10], xmm1
0000705c0add21cf  vmovaps [rsp+0x20], xmm2
0000705c0add21d5  vmovaps [rsp+0x30], xmm3
0000705c0add21db  vmovaps [rsp+0x40], xmm4
0000705c0add21e1  vmovaps [rsp+0x50], xmm5
0000705c0add21e7  vmovaps [rsp+0x60], xmm6
0000705c0add21ed  vmovaps [rsp+0x70], xmm7
0000705c0add21f3  vmovaps [rsp+0x80], xmm8
0000705c0add21fc  vmovaps [rsp+0x90], xmm9
0000705c0add2205  vmovaps [rsp+0xA0], xmm10
0000705c0add220e  vmovaps [rsp+0xB0], xmm11
0000705c0add2217  vmovaps [rsp+0xC0], xmm12
0000705c0add2220  vmovaps [rsp+0xD0], xmm13
0000705c0add2229  vmovaps [rsp+0xE0], xmm15
0000705c0add2232  sub rsp, 0x30
0000705c0add2236  movaps [rsp], xmm14
0000705c0add223b  movaps [rsp+0x10], xmm1
0000705c0add2240  movaps [rsp+0x20], xmm15
0000705c0add2246  lea rdi, [rsp]
0000705c0add224a  mov esi, 0x00
0000705c0add224f  mov rax, 0x5969C28C4530
0000705c0add2259  call rax
0000705c0add225b  movaps xmm14, [rsp]
0000705c0add2260  add rsp, 0x30
0000705c0add2264  vmovaps xmm0, [rsp]
0000705c0add2269  vmovaps xmm1, [rsp+0x10]
0000705c0add226f  vmovaps xmm2, [rsp+0x20]
0000705c0add2275  vmovaps xmm3, [rsp+0x30]
0000705c0add227b  vmovaps xmm4, [rsp+0x40]
0000705c0add2281  vmovaps xmm5, [rsp+0x50]
0000705c0add2287  vmovaps xmm6, [rsp+0x60]
0000705c0add228d  vmovaps xmm7, [rsp+0x70]
0000705c0add2293  vmovaps xmm8, [rsp+0x80]
0000705c0add229c  vmovaps xmm9, [rsp+0x90]
0000705c0add22a5  vmovaps xmm10, [rsp+0xA0]
0000705c0add22ae  vmovaps xmm11, [rsp+0xB0]
0000705c0add22b7  vmovaps xmm12, [rsp+0xC0]
0000705c0add22c0  vmovaps xmm13, [rsp+0xD0]
0000705c0add22c9  vmovaps xmm15, [rsp+0xE0]
0000705c0add22d2  add rsp, 0xF0
0000705c0add22d9  pop r11
0000705c0add22db  pop r10
0000705c0add22dd  pop r9
0000705c0add22df  pop r8
0000705c0add22e1  pop rsi
0000705c0add22e2  pop rdi
0000705c0add22e3  pop rdx
0000705c0add22e4  pop rcx
0000705c0add22e5  pop rax
0000705c0add22e6  add rsp, 0x08
0000705c0add22ea  jmp 0x0000705C0ADD1FBE
0000705c0add22ef  call 0x0000705C0ACC34C0
0000705c0add22f4  jmp 0x0000705C0ADD1FD4
0000705c0add22f9  int3
0000705c0add22fa  nop [rax+rax*1], ax
0000705c0add2300  mov rax, [r15+0x50]
0000705c0add2304  lea r14, [rax+0x80]
0000705c0add230b  movups xmm1, [r13+r14*1]
0000705c0add2311  lea r14, [rax+0x90]
0000705c0add2318  movups xmm15, [r13+r14*1]
0000705c0add231e  vxorps xmm14, xmm14, xmm14
0000705c0add2323  vpbroadcastq xmm14, xmm14
0000705c0add2328  lea r14, [rax+0x40]
0000705c0add232c  movups xmm13, [r13+r14*1]
0000705c0add2332  lea r14, [rax+0x50]
0000705c0add2336  movups xmm12, [r13+r14*1]
0000705c0add233c  mov qword ptr [r15+0x48], 0x00
0000705c0add2344  movups xmm11, [r13+rax*1]
0000705c0add234a  lea r14, [rax+0x10]
0000705c0add234e  movups xmm10, [r13+r14*1]
0000705c0add2354  mov r14, [r15+0xF8]
0000705c0add235b  lea r12, [r14+0xE0]
0000705c0add2362  movups [r13+r12*1], xmm15
0000705c0add2368  lea r12, [r14+0xF0]
0000705c0add236f  movups [r13+r12*1], xmm1
0000705c0add2375  lea r12, [rax+0xC0]
0000705c0add237c  movups xmm1, [r13+r12*1]
0000705c0add2382  lea r12, [rax+0xD0]
0000705c0add2389  movups xmm15, [r13+r12*1]
0000705c0add238f  lea r12, [rax+0x140]
0000705c0add2396  movups xmm9, [r13+r12*1]
0000705c0add239c  lea r12, [rax+0x150]
0000705c0add23a3  movups xmm8, [r13+r12*1]
0000705c0add23a9  lea r12, [rax+0x180]
0000705c0add23b0  movups xmm7, [r13+r12*1]
0000705c0add23b6  lea r12, [rax+0x190]
0000705c0add23bd  movups xmm6, [r13+r12*1]
0000705c0add23c3  lea r12, [r14+0xC0]
0000705c0add23ca  movups [r13+r12*1], xmm15
0000705c0add23d0  lea r12, [r14+0xD0]
0000705c0add23d7  movups [r13+r12*1], xmm1
0000705c0add23dd  lea r12, [rax+0x100]
0000705c0add23e4  movups xmm1, [r13+r12*1]
0000705c0add23ea  lea r12, [rax+0x110]
0000705c0add23f1  movups xmm15, [r13+r12*1]
0000705c0add23f7  lea r12, [rax+0x1C0]
0000705c0add23fe  movups xmm5, [r13+r12*1]
0000705c0add2404  lea r12, [rax+0x1D0]
0000705c0add240b  movups xmm4, [r13+r12*1]
0000705c0add2411  lea r12, [rax+0x20]
0000705c0add2415  movups xmm3, [r13+r12*1]
0000705c0add241b  lea r12, [rax+0x30]
0000705c0add241f  movups xmm2, [r13+r12*1]
0000705c0add2425  movaps [r15+0x1F0], xmm2
0000705c0add242d  lea r12, [r14+0x20]
0000705c0add2431  movups [r13+r12*1], xmm1
0000705c0add2437  lea r12, [r14+0x30]
0000705c0add243b  movups [r13+r12*1], xmm12
0000705c0add2441  lea r12, [rax+0x60]
0000705c0add2445  movups xmm1, [r13+r12*1]
0000705c0add244b  lea r12, [rax+0x70]
0000705c0add244f  movups xmm12, [r13+r12*1]
0000705c0add2455  lea r12, [r14+0x60]
0000705c0add2459  movups [r13+r12*1], xmm11
0000705c0add245f  lea r12, [r14+0x70]
0000705c0add2463  movups [r13+r12*1], xmm5
0000705c0add2469  lea r12, [rax+0xE0]
0000705c0add2470  movups xmm11, [r13+r12*1]
0000705c0add2476  lea r12, [rax+0xF0]
0000705c0add247d  movups xmm5, [r13+r12*1]
0000705c0add2483  lea r12, [rax+0x120]
0000705c0add248a  vmovaps [rsp+0x10], xmm1
0000705c0add2490  movups xmm1, [r13+r12*1]
0000705c0add2496  lea r12, [rax+0x130]
0000705c0add249d  vmovaps [rsp+0x20], xmm1
0000705c0add24a3  movups xmm1, [r13+r12*1]
0000705c0add24a9  lea r12, [r14+0xA0]
0000705c0add24b0  movups [r13+r12*1], xmm12
0000705c0add24b6  lea r12, [r14+0xB0]
0000705c0add24bd  vmovaps xmm12, [rsp+0x10]
0000705c0add24c3  movups [r13+r12*1], xmm12
0000705c0add24c9  lea r12, [rax+0xA0]
0000705c0add24d0  movups xmm12, [r13+r12*1]
0000705c0add24d6  lea r12, [rax+0xB0]
0000705c0add24dd  vmovaps [rsp+0x10], xmm1
0000705c0add24e3  movups xmm1, [r13+r12*1]
0000705c0add24e9  lea r12, [rax+0x160]
0000705c0add24f0  vmovaps [rsp+0x30], xmm1
0000705c0add24f6  movups xmm1, [r13+r12*1]
0000705c0add24fc  lea r12, [rax+0x170]
0000705c0add2503  vmovaps [rsp+0x40], xmm1
0000705c0add2509  movups xmm1, [r13+r12*1]
0000705c0add250f  movaps [r15+0x2B0], xmm1
0000705c0add2517  lea r12, [rax+0x1A0]
0000705c0add251e  vmovaps [rsp+0x50], xmm1
0000705c0add2524  movups xmm1, [r13+r12*1]
0000705c0add252a  lea r12, [rax+0x1B0]
0000705c0add2531  vmovaps [rsp+0x60], xmm1
0000705c0add2537  movups xmm1, [r13+r12*1]
0000705c0add253d  vmovaps [rsp+0x70], xmm1
0000705c0add2543  vmovaps xmm1, [rsp+0x60]
0000705c0add2549  movaps [r15+0x290], xmm1
0000705c0add2551  vmovaps [rsp+0x60], xmm1
0000705c0add2557  vmovaps xmm1, [rsp+0x70]
0000705c0add255d  movaps [r15+0x1E0], xmm1
0000705c0add2565  lea r12, [r14+0x80]
0000705c0add256c  vmovaps [rsp+0x70], xmm1
0000705c0add2572  vmovaps xmm1, [rsp+0x30]
0000705c0add2578  movups [r13+r12*1], xmm1
0000705c0add257e  lea r12, [r14+0x90]
0000705c0add2585  movups [r13+r12*1], xmm12
0000705c0add258b  lea r12, [rax+0x1E0]
0000705c0add2592  movups xmm1, [r13+r12*1]
0000705c0add2598  lea r12, [rax+0x1F0]
0000705c0add259f  movups xmm12, [r13+r12*1]
0000705c0add25a5  mov qword ptr [r15+0x50], 0x432200
0000705c0add25ad  lea rax, [r14+0x40]
0000705c0add25b1  vmovaps [rsp+0x30], xmm1
0000705c0add25b7  vmovaps xmm1, [rsp+0x40]
0000705c0add25bd  movups [r13+rax*1], xmm1
0000705c0add25c3  lea rax, [r14+0x50]
0000705c0add25c7  movups [r13+rax*1], xmm10
0000705c0add25cd  movups [r13+r14*1], xmm12
0000705c0add25d3  lea rax, [r14+0x10]
0000705c0add25d7  vmovaps xmm1, [rsp+0x30]
0000705c0add25dd  movups [r13+rax*1], xmm1
0000705c0add25e3  mov rax, [r15+0x40]
0000705c0add25e7  vmovaps [rsp+0x30], xmm3
0000705c0add25ed  vmovaps xmm1, [rsp+0x30]
0000705c0add25f3  por xmm3, xmm1
0000705c0add25f7  vmovaps [rsp+0x30], xmm6
0000705c0add25fd  vmovaps xmm12, [rsp+0x30]
0000705c0add2603  por xmm6, xmm12
0000705c0add2608  lea r12, [rax+0x30]
0000705c0add260c  mov r11, [r13+r12*1]
0000705c0add2611  lea r12, [rax+0x38]
0000705c0add2615  mov r10, [r13+r12*1]
0000705c0add261a  movq xmm12, r11
0000705c0add261f  movq xmm10, r10
0000705c0add2624  movq xmm12, xmm12
0000705c0add2629  vmovaps [rsp+0x30], xmm12
0000705c0add262f  movq xmm12, xmm12
0000705c0add2634  movaps [r15+0x130], xmm12
0000705c0add263c  movq xmm10, xmm10
0000705c0add2641  vmovaps [rsp+0x40], xmm10
0000705c0add2647  movq xmm10, xmm10
0000705c0add264c  movaps [r15+0x280], xmm10
0000705c0add2654  vmovaps [rsp+0x80], xmm9
0000705c0add265d  vmovaps xmm12, [rsp+0x80]
0000705c0add2666  por xmm9, xmm12
0000705c0add266b  lea r12, [rax+0x20]
0000705c0add266f  mov r11, [r13+r12*1]
0000705c0add2674  lea r12, [rax+0x28]
0000705c0add2678  mov r10, [r13+r12*1]
0000705c0add267d  movq xmm12, r11
0000705c0add2682  movq xmm10, r10
0000705c0add2687  movq xmm12, xmm12
0000705c0add268c  vmovaps [rsp+0x80], xmm12
0000705c0add2695  movq xmm12, xmm12
0000705c0add269a  movaps [r15+0x150], xmm12
0000705c0add26a2  movq xmm10, xmm10
0000705c0add26a7  vmovaps [rsp+0x90], xmm10
0000705c0add26b0  movq xmm10, xmm10
0000705c0add26b5  movaps [r15+0x140], xmm10
0000705c0add26bd  lea r12, [rax+0x10]
0000705c0add26c1  mov r11, [r13+r12*1]
0000705c0add26c6  lea r12, [rax+0x18]
0000705c0add26ca  mov r10, [r13+r12*1]
0000705c0add26cf  movq xmm12, r11
0000705c0add26d4  movq xmm10, r10
0000705c0add26d9  movq xmm12, xmm12
0000705c0add26de  vmovaps [rsp+0xA0], xmm12
0000705c0add26e7  movq xmm12, xmm12
0000705c0add26ec  movaps [r15+0x170], xmm12
0000705c0add26f4  movq xmm10, xmm10
0000705c0add26f9  vmovaps [rsp+0xB0], xmm10
0000705c0add2702  movq xmm10, xmm10
0000705c0add2707  movaps [r15+0x160], xmm10
0000705c0add270f  mov r12, [r13+rax*1]
0000705c0add2714  vmovq xmm12, r12
0000705c0add2719  vpbroadcastq xmm12, xmm12
0000705c0add271e  lea r12, [rax+0x08]
0000705c0add2722  mov rax, [r13+r12*1]
0000705c0add2727  movq xmm10, rax
0000705c0add272c  movaps [r15+0x230], xmm10
0000705c0add2734  lea rax, [r14+0x50]
0000705c0add2738  movups xmm10, [r13+rax*1]
0000705c0add273e  lea rax, [r14+0x60]
0000705c0add2742  vmovaps [rsp+0xC0], xmm1
0000705c0add274b  movups xmm1, [r13+rax*1]
0000705c0add2751  lea rax, [r14+0x30]
0000705c0add2755  vmovaps [rsp+0xD0], xmm1
0000705c0add275e  movups xmm1, [r13+rax*1]
0000705c0add2764  mov qword ptr [r15+0x60], 0x432200
0000705c0add276c  mov qword ptr [r15+0x58], 0x40
0000705c0add2774  vmovaps [rsp+0xE0], xmm1
0000705c0add277d  vmovaps [rsp+0xF0], xmm15
0000705c0add2786  vmovaps xmm15, [rsp+0xC0]
0000705c0add278f  vmovaps [rsp+0xC0], xmm14
0000705c0add2798  movaps xmm1, xmm12
0000705c0add279c  mulpd xmm1, xmm15
0000705c0add27a1  vcmppd xmm14, xmm1, xmm1, 0x03
0000705c0add27a6  ptest xmm14, xmm14
0000705c0add27ac  jnz 0x0000705C0ADD3863
0000705c0add27b2  movq xmm15, qword ptr [r15+0x230]
0000705c0add27bb  vmovaps [rsp+0x100], xmm15
0000705c0add27c4  vpermilpd xmm15, xmm15, 0x00
0000705c0add27ca  vmovaps [rsp+0x110], xmm1
0000705c0add27d3  vmovaps xmm1, [rsp+0xE0]
0000705c0add27dc  vmovaps [rsp+0xE0], xmm13
0000705c0add27e5  movaps xmm14, xmm1
0000705c0add27e9  mulpd xmm14, xmm15
0000705c0add27ee  vcmppd xmm13, xmm14, xmm14, 0x03
0000705c0add27f4  ptest xmm13, xmm13
0000705c0add27fa  jnz 0x0000705C0ADD39A5
0000705c0add2800  vxorps xmm1, xmm1, xmm1
0000705c0add2804  vpbroadcastq xmm1, xmm1
0000705c0add2809  vmovaps xmm13, [rsp+0xD0]
0000705c0add2812  vmovaps [rsp+0xD0], xmm1
0000705c0add281b  movaps xmm15, xmm12
0000705c0add281f  mulpd xmm15, xmm13
0000705c0add2824  vcmppd xmm1, xmm15, xmm15, 0x03
0000705c0add282a  ptest xmm1, xmm1
0000705c0add282f  jnz 0x0000705C0ADD3AE8
0000705c0add2835  movaps xmm1, xmm12
0000705c0add2839  mulpd xmm1, xmm10
0000705c0add283e  vcmppd xmm13, xmm1, xmm1, 0x03
0000705c0add2843  ptest xmm13, xmm13
0000705c0add2849  jnz 0x0000705C0ADD3C2C
0000705c0add284f  movaps xmm13, xmm12
0000705c0add2853  mulpd xmm13, xmm2
0000705c0add2858  vcmppd xmm10, xmm13, xmm13, 0x03
0000705c0add285e  ptest xmm10, xmm10
0000705c0add2864  jnz 0x0000705C0ADD3D6E
0000705c0add286a  vmovaps [rsp+0x120], xmm7
0000705c0add2873  vmovaps xmm12, [rsp+0x120]
0000705c0add287c  por xmm7, xmm12
0000705c0add2881  vmovaps xmm12, [rsp+0xE0]
0000705c0add288a  vmovaps xmm10, [rsp+0xE0]
0000705c0add2893  por xmm12, xmm10
0000705c0add2898  vmovaps xmm2, [rsp+0x100]
0000705c0add28a1  vpermilpd xmm2, xmm2, 0x00
0000705c0add28a7  vmovaps [rsp+0xE0], xmm1
0000705c0add28b0  vmovaps [rsp+0x120], xmm15
0000705c0add28b9  movaps xmm1, xmm10
0000705c0add28bd  mulpd xmm1, xmm2
0000705c0add28c1  vcmppd xmm15, xmm1, xmm1, 0x03
0000705c0add28c6  ptest xmm15, xmm15
0000705c0add28cc  jnz 0x0000705C0ADD3EB1
0000705c0add28d2  xor eax, eax
0000705c0add28d4  mov r12d, 0x40
0000705c0add28da  mov r11d, 0x200
0000705c0add28e0  cmp r12, r11
0000705c0add28e3  cmc
0000705c0add28e4  lahf
0000705c0add28e5  seto al
0000705c0add28e8  mov [r15+0x108], eax
0000705c0add28ef  vmovaps xmm10, [rsp+0x110]
0000705c0add28f8  vmovaps xmm2, [rsp+0xD0]
0000705c0add2901  vmovaps [rsp+0xD0], xmm1
0000705c0add290a  movaps xmm15, xmm10
0000705c0add290e  addpd xmm15, xmm2
0000705c0add2913  vcmppd xmm1, xmm15, xmm15, 0x03
0000705c0add2919  ptest xmm1, xmm1
0000705c0add291e  jnz 0x0000705C0ADD3FF2
0000705c0add2924  vmovaps xmm10, [rsp+0x120]
0000705c0add292d  vmovaps [rsp+0x110], xmm15
0000705c0add2936  vmovaps xmm15, [rsp+0xC0]
0000705c0add293f  vmovaps [rsp+0xC0], xmm14
0000705c0add2948  movaps xmm1, xmm10
0000705c0add294c  addpd xmm1, xmm15
0000705c0add2951  vcmppd xmm14, xmm1, xmm1, 0x03
0000705c0add2956  ptest xmm14, xmm14
0000705c0add295c  jnz 0x0000705C0ADD4135
0000705c0add2962  vmovaps xmm10, [rsp+0xE0]
0000705c0add296b  vmovaps [rsp+0xE0], xmm1
0000705c0add2974  movaps xmm14, xmm10
0000705c0add2978  addpd xmm14, xmm15
0000705c0add297d  vcmppd xmm1, xmm14, xmm14, 0x03
0000705c0add2983  ptest xmm1, xmm1
0000705c0add2988  jnz 0x0000705C0ADD4277
0000705c0add298e  vmovaps xmm1, [rsp+0x10]
0000705c0add2994  vmovaps xmm15, [rsp+0x10]
0000705c0add299a  por xmm1, xmm15
0000705c0add299f  vmovaps xmm15, [rsp+0x20]
0000705c0add29a5  vmovaps xmm10, [rsp+0x20]
0000705c0add29ab  por xmm15, xmm10
0000705c0add29b0  vmovaps [rsp+0x10], xmm5
0000705c0add29b6  vmovaps xmm10, [rsp+0x10]
0000705c0add29bc  por xmm5, xmm10
0000705c0add29c1  vmovaps [rsp+0x10], xmm11
0000705c0add29c7  vmovaps xmm10, [rsp+0x10]
0000705c0add29cd  por xmm11, xmm10
0000705c0add29d2  vmovaps [rsp+0x10], xmm4
0000705c0add29d8  vmovaps xmm10, [rsp+0x10]
0000705c0add29de  por xmm4, xmm10
0000705c0add29e3  vmovaps [rsp+0x10], xmm8
0000705c0add29e9  vmovaps xmm10, [rsp+0x10]
0000705c0add29ef  por xmm8, xmm10
0000705c0add29f4  vmovaps xmm10, [rsp+0xF0]
0000705c0add29fd  vmovaps [rsp+0x10], xmm1
0000705c0add2a03  vmovaps xmm1, [rsp+0xF0]
0000705c0add2a0c  por xmm10, xmm1
0000705c0add2a11  lea rax, [r14+0xA0]
0000705c0add2a18  movups xmm1, [r13+rax*1]
0000705c0add2a1e  lea rax, [r14+0xB0]
0000705c0add2a25  vmovaps [rsp+0x20], xmm1
0000705c0add2a2b  movups xmm1, [r13+rax*1]
0000705c0add2a31  vmovaps [rsp+0xF0], xmm1
0000705c0add2a3a  vmovaps [rsp+0x120], xmm15
0000705c0add2a43  movaps xmm1, xmm13
0000705c0add2a47  addpd xmm1, xmm2
0000705c0add2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
0000705c0add2a50  ptest xmm15, xmm15
0000705c0add2a56  jnz 0x0000705C0ADD43CF
0000705c0add2a5c  lea rax, [r14+0xF0]
0000705c0add2a63  movups xmm15, [r13+rax*1]
0000705c0add2a69  vmovaps xmm2, [rsp+0xE0]
0000705c0add2a72  vmovaps [rsp+0xE0], xmm1
0000705c0add2a7b  vmovaps xmm1, [rsp+0xD0]
0000705c0add2a84  vmovaps [rsp+0xD0], xmm15
0000705c0add2a8d  movaps xmm13, xmm2
0000705c0add2a91  addpd xmm13, xmm1
0000705c0add2a96  vcmppd xmm15, xmm13, xmm13, 0x03
0000705c0add2a9c  ptest xmm15, xmm15
0000705c0add2aa2  jnz 0x0000705C0ADD451A
0000705c0add2aa8  vmovaps xmm15, [rsp+0xC0]
0000705c0add2ab1  movaps xmm1, xmm14
0000705c0add2ab5  addpd xmm1, xmm15
0000705c0add2aba  vcmppd xmm2, xmm1, xmm1, 0x03
0000705c0add2abf  ptest xmm2, xmm2
0000705c0add2ac4  jnz 0x0000705C0ADD465C
0000705c0add2aca  vmovaps xmm15, [rsp+0x100]
0000705c0add2ad3  vpermilpd xmm15, xmm15, 0x00
0000705c0add2ad9  vmovaps xmm2, [rsp+0xF0]
0000705c0add2ae2  vmovaps [rsp+0xC0], xmm1
0000705c0add2aeb  movaps xmm14, xmm2
0000705c0add2aef  mulpd xmm14, xmm15
0000705c0add2af4  vcmppd xmm1, xmm14, xmm14, 0x03
0000705c0add2afa  ptest xmm1, xmm1
0000705c0add2aff  jnz 0x0000705C0ADD479E
0000705c0add2b05  vmovaps xmm1, [rsp+0xA0]
0000705c0add2b0e  vpermilpd xmm1, xmm1, 0x00
0000705c0add2b14  vmovaps xmm2, [rsp+0xD0]
0000705c0add2b1d  vmovaps [rsp+0xD0], xmm14
0000705c0add2b26  movaps xmm15, xmm2
0000705c0add2b2a  mulpd xmm15, xmm1
0000705c0add2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
0000705c0add2b35  ptest xmm14, xmm14
0000705c0add2b3b  jnz 0x0000705C0ADD48E1
0000705c0add2b41  lea rax, [r14+0xE0]
0000705c0add2b48  movups xmm1, [r13+rax*1]
0000705c0add2b4e  vmovaps xmm14, [rsp+0x100]
0000705c0add2b57  vpermilpd xmm14, xmm14, 0x00
0000705c0add2b5d  vmovaps [rsp+0xF0], xmm1
0000705c0add2b66  vmovaps xmm1, [rsp+0x20]
0000705c0add2b6c  vmovaps [rsp+0x20], xmm15
0000705c0add2b72  movaps xmm2, xmm1
0000705c0add2b75  mulpd xmm2, xmm14
0000705c0add2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
0000705c0add2b7f  ptest xmm15, xmm15
0000705c0add2b85  jnz 0x0000705C0ADD4A2D
0000705c0add2b8b  vmovaps [rsp+0x100], xmm10
0000705c0add2b94  vmovaps xmm1, [rsp+0x100]
0000705c0add2b9d  por xmm10, xmm1
0000705c0add2ba2  movaps [r15+0x300], xmm10
0000705c0add2baa  vmovaps [rsp+0x100], xmm8
0000705c0add2bb3  vmovaps xmm1, [rsp+0x100]
0000705c0add2bbc  por xmm8, xmm1
0000705c0add2bc1  movaps [r15+0x190], xmm8
0000705c0add2bc9  vmovaps xmm1, [rsp+0xA0]
0000705c0add2bd2  vpermilpd xmm1, xmm1, 0x00
0000705c0add2bd8  vmovaps xmm14, [rsp+0xF0]
0000705c0add2be1  vmovaps [rsp+0xF0], xmm13
0000705c0add2bea  movaps xmm15, xmm14
0000705c0add2bee  mulpd xmm15, xmm1
0000705c0add2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
0000705c0add2bf9  ptest xmm13, xmm13
0000705c0add2bff  jnz 0x0000705C0ADD4B6E
0000705c0add2c05  lea rax, [r14+0x90]
0000705c0add2c0c  movups xmm1, [r13+rax*1]
0000705c0add2c12  vmovaps [rsp+0x100], xmm4
0000705c0add2c1b  vmovaps xmm14, [rsp+0x100]
0000705c0add2c24  por xmm4, xmm14
0000705c0add2c29  movaps [r15+0x1C0], xmm4
0000705c0add2c31  vmovaps [rsp+0x100], xmm11
0000705c0add2c3a  vmovaps xmm14, [rsp+0x100]
0000705c0add2c43  por xmm11, xmm14
0000705c0add2c48  movaps [r15+0x200], xmm11
0000705c0add2c50  vmovaps [rsp+0x100], xmm5
0000705c0add2c59  vmovaps xmm14, [rsp+0x100]
0000705c0add2c62  por xmm5, xmm14
0000705c0add2c67  movaps [r15+0x2D0], xmm5
0000705c0add2c6f  vmovaps xmm14, [rsp+0x120]
0000705c0add2c78  vmovaps xmm13, [rsp+0x120]
0000705c0add2c81  por xmm14, xmm13
0000705c0add2c86  movaps [r15+0x2E0], xmm14
0000705c0add2c8e  vmovaps [rsp+0x100], xmm1
0000705c0add2c97  vmovaps xmm1, [rsp+0x110]
0000705c0add2ca0  vmovaps [rsp+0x110], xmm15
0000705c0add2ca9  vmovaps xmm15, [rsp+0xD0]
0000705c0add2cb2  vmovaps [rsp+0xD0], xmm14
0000705c0add2cbb  movaps xmm13, xmm1
0000705c0add2cbf  addpd xmm13, xmm15
0000705c0add2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
0000705c0add2cca  ptest xmm14, xmm14
0000705c0add2cd0  jnz 0x0000705C0ADD4CBB
0000705c0add2cd6  vmovaps xmm1, [rsp+0xA0]
0000705c0add2cdf  vpermilpd xmm1, xmm1, 0x00
0000705c0add2ce5  vmovaps xmm14, [rsp+0x100]
0000705c0add2cee  vmovaps [rsp+0x100], xmm13
0000705c0add2cf7  movaps xmm15, xmm14
0000705c0add2cfb  mulpd xmm15, xmm1
0000705c0add2d00  vcmppd xmm13, xmm15, xmm15, 0x03
0000705c0add2d06  ptest xmm13, xmm13
0000705c0add2d0c  jnz 0x0000705C0ADD4DFE
0000705c0add2d12  lea rax, [r14+0x80]
0000705c0add2d19  movups xmm1, [r13+rax*1]
0000705c0add2d1f  vmovaps xmm13, [rsp+0xE0]
0000705c0add2d28  vmovaps [rsp+0xE0], xmm1
0000705c0add2d31  movaps xmm14, xmm13
0000705c0add2d35  addpd xmm14, xmm2
0000705c0add2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
0000705c0add2d40  ptest xmm1, xmm1
0000705c0add2d45  jnz 0x0000705C0ADD4F4B
0000705c0add2d4b  vmovaps xmm13, [rsp+0xF0]
0000705c0add2d54  vmovaps xmm2, [rsp+0x20]
0000705c0add2d5a  vmovaps [rsp+0x20], xmm15
0000705c0add2d60  movaps xmm1, xmm13
0000705c0add2d64  addpd xmm1, xmm2
0000705c0add2d68  vcmppd xmm15, xmm1, xmm1, 0x03
0000705c0add2d6d  ptest xmm15, xmm15
0000705c0add2d73  jnz 0x0000705C0ADD508E
0000705c0add2d79  vmovaps xmm15, [rsp+0x10]
0000705c0add2d7f  vmovaps xmm13, [rsp+0x10]
0000705c0add2d85  por xmm15, xmm13
0000705c0add2d8a  movaps [r15+0x2F0], xmm15
0000705c0add2d92  vmovaps xmm13, [rsp+0xA0]
0000705c0add2d9b  vpermilpd xmm13, xmm13, 0x00
0000705c0add2da1  vmovaps [rsp+0x10], xmm1
0000705c0add2da7  vmovaps xmm1, [rsp+0xE0]
0000705c0add2db0  vmovaps [rsp+0xA0], xmm15
0000705c0add2db9  movaps xmm2, xmm1
0000705c0add2dbc  mulpd xmm2, xmm13
0000705c0add2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
0000705c0add2dc6  ptest xmm15, xmm15
0000705c0add2dcc  jnz 0x0000705C0ADD51CF
0000705c0add2dd2  lea rax, [r14+0xD0]
0000705c0add2dd9  movups xmm1, [r13+rax*1]
0000705c0add2ddf  vmovaps xmm13, [rsp+0xC0]
0000705c0add2de8  vmovaps [rsp+0xC0], xmm1
0000705c0add2df1  vmovaps xmm1, [rsp+0x110]
0000705c0add2dfa  vmovaps [rsp+0xE0], xmm14
0000705c0add2e03  movaps xmm15, xmm13
0000705c0add2e07  addpd xmm15, xmm1
0000705c0add2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
0000705c0add2e12  ptest xmm14, xmm14
0000705c0add2e18  jnz 0x0000705C0ADD531A
0000705c0add2e1e  vmovaps xmm1, [rsp+0xB0]
0000705c0add2e27  vpermilpd xmm1, xmm1, 0x00
0000705c0add2e2d  movaps xmm14, xmm11
0000705c0add2e31  mulpd xmm14, xmm1
0000705c0add2e36  vcmppd xmm13, xmm14, xmm14, 0x03
0000705c0add2e3c  ptest xmm13, xmm13
0000705c0add2e42  jnz 0x0000705C0ADD545D
0000705c0add2e48  movaps [r15+0x260], xmm14
0000705c0add2e50  vxorps xmm1, xmm1, xmm1
0000705c0add2e54  vpbroadcastq xmm1, xmm1
0000705c0add2e59  movaps [r15+0x1B0], xmm1
0000705c0add2e61  vmovaps xmm1, [rsp+0xB0]
0000705c0add2e6a  vpermilpd xmm1, xmm1, 0x00
0000705c0add2e70  vmovaps xmm11, [rsp+0xC0]
0000705c0add2e79  vmovaps [rsp+0xC0], xmm15
0000705c0add2e82  movaps xmm13, xmm11
0000705c0add2e86  mulpd xmm13, xmm1
0000705c0add2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
0000705c0add2e91  ptest xmm15, xmm15
0000705c0add2e97  jnz 0x0000705C0ADD55A0
0000705c0add2e9d  lea rax, [r14+0xC0]
0000705c0add2ea4  movups xmm1, [r13+rax*1]
0000705c0add2eaa  vmovaps xmm11, [rsp+0x100]
0000705c0add2eb3  vmovaps [rsp+0xF0], xmm1
0000705c0add2ebc  vmovaps xmm1, [rsp+0x20]
0000705c0add2ec2  vmovaps [rsp+0x20], xmm14
0000705c0add2ec8  movaps xmm15, xmm11
0000705c0add2ecc  addpd xmm15, xmm1
0000705c0add2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
0000705c0add2ed7  ptest xmm14, xmm14
0000705c0add2edd  jnz 0x0000705C0ADD56ED
0000705c0add2ee3  vmovaps [rsp+0x100], xmm9
0000705c0add2eec  vmovaps xmm1, [rsp+0x100]
0000705c0add2ef5  por xmm9, xmm1
0000705c0add2efa  movaps [r15+0x270], xmm9
0000705c0add2f02  vmovaps [rsp+0x100], xmm6
0000705c0add2f0b  vmovaps xmm1, [rsp+0x100]
0000705c0add2f14  por xmm6, xmm1
0000705c0add2f18  movaps [r15+0x1A0], xmm6
0000705c0add2f20  vmovaps xmm14, [rsp+0xB0]
0000705c0add2f29  vpermilpd xmm14, xmm14, 0x00
0000705c0add2f2f  vmovaps xmm6, [rsp+0xF0]
0000705c0add2f38  vmovaps [rsp+0xF0], xmm1
0000705c0add2f41  movaps xmm11, xmm6
0000705c0add2f45  mulpd xmm11, xmm14
0000705c0add2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
0000705c0add2f50  ptest xmm1, xmm1
0000705c0add2f55  jnz 0x0000705C0ADD5830
0000705c0add2f5b  lea rax, [r14+0x20]
0000705c0add2f5f  movups xmm1, [r13+rax*1]
0000705c0add2f65  movaps [r15+0x110], xmm1
0000705c0add2f6d  vmovaps xmm6, [rsp+0xE0]
0000705c0add2f76  vmovaps [rsp+0xE0], xmm1
0000705c0add2f7f  movaps xmm14, xmm6
0000705c0add2f83  addpd xmm14, xmm2
0000705c0add2f88  vcmppd xmm1, xmm14, xmm14, 0x03
0000705c0add2f8e  ptest xmm1, xmm1
0000705c0add2f93  jnz 0x0000705C0ADD597D
0000705c0add2f99  vmovaps xmm1, [rsp+0xB0]
0000705c0add2fa2  vpermilpd xmm1, xmm1, 0x00
0000705c0add2fa8  movaps xmm6, xmm5
0000705c0add2fab  mulpd xmm6, xmm1
0000705c0add2faf  vcmppd xmm2, xmm6, xmm6, 0x03
0000705c0add2fb4  ptest xmm2, xmm2
0000705c0add2fb9  jnz 0x0000705C0ADD5ABF
0000705c0add2fbf  vmovaps xmm5, [rsp+0x10]
0000705c0add2fc5  movaps xmm1, xmm5
0000705c0add2fc8  addpd xmm1, xmm13
0000705c0add2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
0000705c0add2fd2  ptest xmm2, xmm2
0000705c0add2fd7  jnz 0x0000705C0ADD5BFF
0000705c0add2fdd  vmovaps xmm13, [rsp+0x80]
0000705c0add2fe6  vpermilpd xmm13, xmm13, 0x00
0000705c0add2fec  vmovaps xmm2, [rsp+0xE0]
0000705c0add2ff5  vmovaps [rsp+0x10], xmm1
0000705c0add2ffb  movaps xmm5, xmm2
0000705c0add2ffe  mulpd xmm5, xmm13
0000705c0add3003  vcmppd xmm1, xmm5, xmm5, 0x03
0000705c0add3008  ptest xmm1, xmm1
0000705c0add300d  jnz 0x0000705C0ADD5D40
0000705c0add3013  vmovaps xmm1, [rsp+0x80]
0000705c0add301c  vpermilpd xmm1, xmm1, 0x00
0000705c0add3022  movaps xmm13, xmm10
0000705c0add3026  mulpd xmm13, xmm1
0000705c0add302b  vcmppd xmm2, xmm13, xmm13, 0x03
0000705c0add3031  ptest xmm2, xmm2
0000705c0add3036  jnz 0x0000705C0ADD5E81
0000705c0add303c  vmovaps xmm10, [rsp+0x20]
0000705c0add3042  movaps xmm1, xmm15
0000705c0add3046  addpd xmm1, xmm10
0000705c0add304b  vcmppd xmm2, xmm1, xmm1, 0x03
0000705c0add3050  ptest xmm2, xmm2
0000705c0add3055  jnz 0x0000705C0ADD5FC4
0000705c0add305b  vmovaps xmm10, [rsp+0xC0]
0000705c0add3064  movaps xmm15, xmm10
0000705c0add3068  addpd xmm15, xmm11
0000705c0add306d  vcmppd xmm2, xmm15, xmm15, 0x03
0000705c0add3073  ptest xmm2, xmm2
0000705c0add3078  jnz 0x0000705C0ADD6106
0000705c0add307e  vmovaps xmm11, [rsp+0x80]
0000705c0add3087  vpermilpd xmm11, xmm11, 0x00
0000705c0add308d  vmovaps xmm2, [rsp+0xD0]
0000705c0add3096  vmovaps [rsp+0x20], xmm1
0000705c0add309c  movaps xmm10, xmm2
0000705c0add30a0  mulpd xmm10, xmm11
0000705c0add30a5  vcmppd xmm1, xmm10, xmm10, 0x03
0000705c0add30ab  ptest xmm1, xmm1
0000705c0add30b0  jnz 0x0000705C0ADD624A
0000705c0add30b6  vmovaps xmm1, [rsp+0x80]
0000705c0add30bf  vpermilpd xmm1, xmm1, 0x00
0000705c0add30c5  vmovaps xmm2, [rsp+0xA0]
0000705c0add30ce  vmovaps [rsp+0x80], xmm15
0000705c0add30d7  movaps xmm11, xmm2
0000705c0add30db  mulpd xmm11, xmm1
0000705c0add30e0  vcmppd xmm15, xmm11, xmm11, 0x03
0000705c0add30e6  ptest xmm15, xmm15
0000705c0add30ec  jnz 0x0000705C0ADD638D
0000705c0add30f2  movaps xmm1, xmm14
0000705c0add30f6  addpd xmm1, xmm6
0000705c0add30fa  vcmppd xmm15, xmm1, xmm1, 0x03
0000705c0add30ff  ptest xmm15, xmm15
0000705c0add3105  jnz 0x0000705C0ADD64CF
0000705c0add310b  vmovaps xmm14, [rsp+0x10]
0000705c0add3111  movaps xmm15, xmm14
0000705c0add3115  addpd xmm15, xmm5
0000705c0add311a  vcmppd xmm6, xmm15, xmm15, 0x03
0000705c0add3120  ptest xmm6, xmm6
0000705c0add3125  jnz 0x0000705C0ADD6610
0000705c0add312b  vmovaps xmm14, [rsp+0x90]
0000705c0add3134  vpermilpd xmm14, xmm14, 0x00
0000705c0add313a  movaps xmm6, xmm9
0000705c0add313e  mulpd xmm6, xmm14
0000705c0add3143  vcmppd xmm5, xmm6, xmm6, 0x03
0000705c0add3148  ptest xmm5, xmm5
0000705c0add314d  jnz 0x0000705C0ADD6753
0000705c0add3153  vmovaps xmm9, [rsp+0x80]
0000705c0add315c  movaps xmm14, xmm9
0000705c0add3160  addpd xmm14, xmm13
0000705c0add3165  vcmppd xmm5, xmm14, xmm14, 0x03
0000705c0add316b  ptest xmm5, xmm5
0000705c0add3170  jnz 0x0000705C0ADD6895
0000705c0add3176  vmovaps xmm9, [rsp+0x20]
0000705c0add317c  movaps xmm13, xmm9
0000705c0add3180  addpd xmm13, xmm10
0000705c0add3185  vcmppd xmm5, xmm13, xmm13, 0x03
0000705c0add318b  ptest xmm5, xmm5
0000705c0add3190  jnz 0x0000705C0ADD69D9
0000705c0add3196  vmovaps [rsp+0x10], xmm12
0000705c0add319c  vmovaps xmm10, [rsp+0x10]
0000705c0add31a2  por xmm12, xmm10
0000705c0add31a7  movaps [r15+0x250], xmm12
0000705c0add31af  vmovaps [rsp+0x10], xmm7
0000705c0add31b5  vmovaps xmm12, [rsp+0x10]
0000705c0add31bb  por xmm7, xmm12
0000705c0add31c0  movaps [r15+0x2A0], xmm7
0000705c0add31c8  vmovaps [rsp+0x10], xmm3
0000705c0add31ce  vmovaps xmm12, [rsp+0x10]
0000705c0add31d4  por xmm3, xmm12
0000705c0add31d9  movaps [r15+0x1D0], xmm3
0000705c0add31e1  lea rax, [r14+0x40]
0000705c0add31e5  movups xmm12, [r13+rax*1]
0000705c0add31eb  movaps [r15+0x2C0], xmm12
0000705c0add31f3  vmovaps xmm10, [rsp+0x90]
0000705c0add31fc  vpermilpd xmm10, xmm10, 0x00
0000705c0add3202  movaps xmm9, xmm8
0000705c0add3206  mulpd xmm9, xmm10
0000705c0add320b  vcmppd xmm5, xmm9, xmm9, 0x03
0000705c0add3211  ptest xmm5, xmm5
0000705c0add3216  jnz 0x0000705C0ADD6B27
0000705c0add321c  movaps xmm10, xmm1
0000705c0add3220  addpd xmm10, xmm11
0000705c0add3225  vcmppd xmm8, xmm10, xmm10, 0x03
0000705c0add322b  ptest xmm8, xmm8
0000705c0add3231  jnz 0x0000705C0ADD6C6B
0000705c0add3237  movaps xmm1, xmm15
0000705c0add323b  addpd xmm1, xmm6
0000705c0add323f  vcmppd xmm11, xmm1, xmm1, 0x03
0000705c0add3244  ptest xmm11, xmm11
0000705c0add324a  jnz 0x0000705C0ADD6DAE
0000705c0add3250  vmovaps xmm15, [rsp+0x90]
0000705c0add3259  vpermilpd xmm15, xmm15, 0x00
0000705c0add325f  movaps xmm11, xmm12
0000705c0add3263  mulpd xmm11, xmm15
0000705c0add3268  vcmppd xmm8, xmm11, xmm11, 0x03
0000705c0add326e  ptest xmm8, xmm8
0000705c0add3274  jnz 0x0000705C0ADD6EEF
0000705c0add327a  vmovaps xmm15, [rsp+0x90]
0000705c0add3283  vpermilpd xmm15, xmm15, 0x00
0000705c0add3289  vmovaps xmm8, [rsp+0x50]
0000705c0add328f  movaps xmm12, xmm8
0000705c0add3293  mulpd xmm12, xmm15
0000705c0add3298  vcmppd xmm6, xmm12, xmm12, 0x03
0000705c0add329e  ptest xmm6, xmm6
0000705c0add32a3  jnz 0x0000705C0ADD7033
0000705c0add32a9  vmovaps xmm15, [rsp+0x30]
0000705c0add32af  vpermilpd xmm15, xmm15, 0x00
0000705c0add32b5  movaps xmm8, xmm7
0000705c0add32b9  mulpd xmm8, xmm15
0000705c0add32be  vcmppd xmm6, xmm8, xmm8, 0x03
0000705c0add32c4  ptest xmm6, xmm6
0000705c0add32c9  jnz 0x0000705C0ADD7177
0000705c0add32cf  movaps xmm15, xmm14
0000705c0add32d3  addpd xmm15, xmm9
0000705c0add32d8  vcmppd xmm7, xmm15, xmm15, 0x03
0000705c0add32de  ptest xmm7, xmm7
0000705c0add32e3  jnz 0x0000705C0ADD72BA
0000705c0add32e9  vmovaps xmm14, [rsp+0x30]
0000705c0add32ef  vpermilpd xmm14, xmm14, 0x00
0000705c0add32f5  vmovaps xmm7, [rsp+0xF0]
0000705c0add32fe  movaps xmm9, xmm7
0000705c0add3302  mulpd xmm9, xmm14
0000705c0add3307  vcmppd xmm6, xmm9, xmm9, 0x03
0000705c0add330d  ptest xmm6, xmm6
0000705c0add3312  jnz 0x0000705C0ADD73FE
0000705c0add3318  movaps xmm14, xmm13
0000705c0add331c  addpd xmm14, xmm11
0000705c0add3321  vcmppd xmm7, xmm14, xmm14, 0x03
0000705c0add3327  ptest xmm7, xmm7
0000705c0add332c  jnz 0x0000705C0ADD7541
0000705c0add3332  vmovaps xmm13, [rsp+0x30]
0000705c0add3338  vpermilpd xmm13, xmm13, 0x00
0000705c0add333e  vmovaps xmm7, [rsp+0x60]
0000705c0add3344  movaps xmm11, xmm7
0000705c0add3348  mulpd xmm11, xmm13
0000705c0add334d  vcmppd xmm6, xmm11, xmm11, 0x03
0000705c0add3353  ptest xmm6, xmm6
0000705c0add3358  jnz 0x0000705C0ADD7685
0000705c0add335e  movaps xmm13, xmm10
0000705c0add3362  addpd xmm13, xmm12
0000705c0add3367  vcmppd xmm7, xmm13, xmm13, 0x03
0000705c0add336d  ptest xmm7, xmm7
0000705c0add3372  jnz 0x0000705C0ADD77C8
0000705c0add3378  vmovaps xmm12, [rsp+0x30]
0000705c0add337e  vpermilpd xmm12, xmm12, 0x00
0000705c0add3384  vmovaps xmm7, [rsp+0x70]
0000705c0add338a  movaps xmm10, xmm7
0000705c0add338e  mulpd xmm10, xmm12
0000705c0add3393  vcmppd xmm6, xmm10, xmm10, 0x03
0000705c0add3399  ptest xmm6, xmm6
0000705c0add339e  jnz 0x0000705C0ADD790C
0000705c0add33a4  movaps xmm12, xmm1
0000705c0add33a8  addpd xmm12, xmm8
0000705c0add33ad  vcmppd xmm7, xmm12, xmm12, 0x03
0000705c0add33b3  ptest xmm7, xmm7
0000705c0add33b8  jnz 0x0000705C0ADD7A4F
0000705c0add33be  lea rax, [r14+0x70]
0000705c0add33c2  movups xmm1, [r13+rax*1]
0000705c0add33c8  movaps [r15+0x240], xmm1
0000705c0add33d0  movaps xmm8, xmm15
0000705c0add33d4  addpd xmm8, xmm9
0000705c0add33d9  vcmppd xmm7, xmm8, xmm8, 0x03
0000705c0add33df  ptest xmm7, xmm7
0000705c0add33e4  jnz 0x0000705C0ADD7B9C
0000705c0add33ea  movaps [r15+0x170], xmm8
0000705c0add33f2  vmovaps xmm15, [rsp+0x40]
0000705c0add33f8  vpermilpd xmm15, xmm15, 0x00
0000705c0add33fe  movaps xmm9, xmm1
0000705c0add3402  mulpd xmm9, xmm15
0000705c0add3407  vcmppd xmm7, xmm9, xmm9, 0x03
0000705c0add340d  ptest xmm7, xmm7
0000705c0add3412  jnz 0x0000705C0ADD7CE0
0000705c0add3418  vmovaps xmm1, [rsp+0x40]
0000705c0add341e  vpermilpd xmm1, xmm1, 0x00
0000705c0add3424  movaps xmm15, xmm4
0000705c0add3428  mulpd xmm15, xmm1
0000705c0add342d  vcmppd xmm7, xmm15, xmm15, 0x03
0000705c0add3433  ptest xmm7, xmm7
0000705c0add3438  jnz 0x0000705C0ADD7E23
0000705c0add343e  movaps [r15+0x180], xmm15
0000705c0add3446  movaps xmm1, xmm14
0000705c0add344a  addpd xmm1, xmm11
0000705c0add344f  vcmppd xmm7, xmm1, xmm1, 0x03
0000705c0add3454  ptest xmm7, xmm7
0000705c0add3459  jnz 0x0000705C0ADD7F65
0000705c0add345f  movaps [r15+0x210], xmm1
0000705c0add3467  movups xmm14, [r13+r14*1]
0000705c0add346d  lea rax, [r14+0x10]
0000705c0add3471  movups xmm11, [r13+rax*1]
0000705c0add3477  movaps [r15+0x230], xmm11
0000705c0add347f  movaps xmm7, xmm13
0000705c0add3483  addpd xmm7, xmm10
0000705c0add3488  vcmppd xmm6, xmm7, xmm7, 0x03
0000705c0add348d  ptest xmm6, xmm6
0000705c0add3492  jnz 0x0000705C0ADD80BB
0000705c0add3498  movaps [r15+0x130], xmm7
0000705c0add34a0  vmovaps xmm13, [rsp+0x40]
0000705c0add34a6  vpermilpd xmm13, xmm13, 0x00
0000705c0add34ac  movaps xmm10, xmm11
0000705c0add34b0  mulpd xmm10, xmm13
0000705c0add34b5  vcmppd xmm6, xmm10, xmm10, 0x03
0000705c0add34bb  ptest xmm6, xmm6
0000705c0add34c0  jnz 0x0000705C0ADD81FD
0000705c0add34c6  movaps [r15+0x220], xmm10
0000705c0add34ce  vmovaps xmm13, [rsp+0x40]
0000705c0add34d4  vpermilpd xmm13, xmm13, 0x00
0000705c0add34da  movaps xmm11, xmm14
0000705c0add34de  mulpd xmm11, xmm13
0000705c0add34e3  vcmppd xmm6, xmm11, xmm11, 0x03
0000705c0add34e9  ptest xmm6, xmm6
0000705c0add34ee  jnz 0x0000705C0ADD8341
0000705c0add34f4  movaps xmm14, xmm12
0000705c0add34f8  addpd xmm14, xmm9
0000705c0add34fd  vcmppd xmm13, xmm14, xmm14, 0x03
0000705c0add3503  ptest xmm13, xmm13
0000705c0add3509  jnz 0x0000705C0ADD8485
0000705c0add350f  movaps [r15+0x140], xmm14
0000705c0add3517  movaps xmm13, xmm8
0000705c0add351b  addpd xmm13, xmm15
0000705c0add3520  vcmppd xmm12, xmm13, xmm13, 0x03
0000705c0add3526  ptest xmm12, xmm12
0000705c0add352c  jnz 0x0000705C0ADD85C9
0000705c0add3532  movaps [r15+0x150], xmm13
0000705c0add353a  movaps xmm15, xmm1
0000705c0add353e  addpd xmm15, xmm10
0000705c0add3543  vcmppd xmm12, xmm15, xmm15, 0x03
0000705c0add3549  ptest xmm12, xmm12
0000705c0add354f  jnz 0x0000705C0ADD870D
0000705c0add3555  movaps [r15+0x160], xmm15
0000705c0add355d  movaps xmm1, xmm7
0000705c0add3560  addpd xmm1, xmm11
0000705c0add3565  vcmppd xmm12, xmm1, xmm1, 0x03
0000705c0add356a  ptest xmm12, xmm12
0000705c0add3570  jnz 0x0000705C0ADD8850
0000705c0add3576  movaps [r15+0x120], xmm1
0000705c0add357e  mov eax, 0x432200
0000705c0add3583  movups [r13+rax*1], xmm14
0000705c0add3589  mov eax, 0x432210
0000705c0add358e  movups [r13+rax*1], xmm13
0000705c0add3594  mov eax, 0x432220
0000705c0add3599  movups [r13+rax*1], xmm15
0000705c0add359f  mov eax, 0x432230
0000705c0add35a4  movups [r13+rax*1], xmm1
0000705c0add35aa  mov eax, [r15+0x108]
0000705c0add35b1  sahf
0000705c0add35b2  jnz 0x0000705C0ADD35E4
0000705c0add35b4  cmp dword ptr [r15+0x318], 0x00
0000705c0add35bc  jz 0x0000705C0ADDEAE0
0000705c0add35c2  nop [rax+rax*1], ax
0000705c0add35cb  nop [rax+rax*1], eax
0000705c0add35d3  mov eax, 0x4106D0
0000705c0add35d8  mov [r15+0x100], rax
0000705c0add35df  jmp 0x0000705C0ABFE110
0000705c0add35e4  cmp dword ptr [r15+0x318], 0x00
0000705c0add35ec  jz 0x0000705C0ADD89C0
0000705c0add35f2  nop [rax+rax*1], ax
0000705c0add35fb  nop [rax+rax*1], eax
0000705c0add3603  mov eax, 0x410504
0000705c0add3608  mov [r15+0x100], rax
0000705c0add360f  jmp 0x0000705C0ABFE110
0000705c0add3614  int3
0000705c0add3615  call 0x0000705C0ACD64F0
0000705c0add361a  jmp 0x0000705C0ADD2311
0000705c0add361f  call 0x0000705C0ACE5820
0000705c0add3624  jmp 0x0000705C0ADD231E
0000705c0add3629  call 0x0000705C0ACE3320
0000705c0add362e  jmp 0x0000705C0ADD2332
0000705c0add3633  call 0x0000705C0ACE20A0
0000705c0add3638  jmp 0x0000705C0ADD233C
0000705c0add363d  call 0x0000705C0AC09D70
0000705c0add3642  jmp 0x0000705C0ADD234A
0000705c0add3647  call 0x0000705C0ACDFBC0
0000705c0add364c  jmp 0x0000705C0ADD2354
0000705c0add3651  call 0x0000705C0ACC4740
0000705c0add3656  jmp 0x0000705C0ADD2368
0000705c0add365b  call 0x0000705C0ACB5400
0000705c0add3660  jmp 0x0000705C0ADD2375
0000705c0add3665  call 0x0000705C0ACB52F0
0000705c0add366a  jmp 0x0000705C0ADD2382
0000705c0add366f  call 0x0000705C0ACC4620
0000705c0add3674  jmp 0x0000705C0ADD238F
0000705c0add3679  call 0x0000705C0ACBD750
0000705c0add367e  jmp 0x0000705C0ADD239C
0000705c0add3683  call 0x0000705C0ACBC4E0
0000705c0add3688  jmp 0x0000705C0ADD23A9
0000705c0add368d  call 0x0000705C0ACBB270
0000705c0add3692  jmp 0x0000705C0ADD23B6
0000705c0add3697  call 0x0000705C0ACBA000
0000705c0add369c  jmp 0x0000705C0ADD23C3
0000705c0add36a1  call 0x0000705C0ACC4740
0000705c0add36a6  jmp 0x0000705C0ADD23D0
0000705c0add36ab  call 0x0000705C0ACB5400
0000705c0add36b0  jmp 0x0000705C0ADD23DD
0000705c0add36b5  call 0x0000705C0ACB52F0
0000705c0add36ba  jmp 0x0000705C0ADD23EA
0000705c0add36bf  call 0x0000705C0ACC4620
0000705c0add36c4  jmp 0x0000705C0ADD23F7
0000705c0add36c9  call 0x0000705C0ACB8D90
0000705c0add36ce  jmp 0x0000705C0ADD2404
0000705c0add36d3  call 0x0000705C0ACB8A20
0000705c0add36d8  jmp 0x0000705C0ADD2411
0000705c0add36dd  call 0x0000705C0ACB77B0
0000705c0add36e2  jmp 0x0000705C0ADD241B
0000705c0add36e7  call 0x0000705C0ACB6550
0000705c0add36ec  jmp 0x0000705C0ADD2425
0000705c0add36f1  call 0x0000705C0ACB5400
0000705c0add36f6  jmp 0x0000705C0ADD2437
0000705c0add36fb  call 0x0000705C0ACC0FC0
0000705c0add3700  jmp 0x0000705C0ADD2441
0000705c0add3705  call 0x0000705C0ACB52F0
0000705c0add370a  jmp 0x0000705C0ADD244B
0000705c0add370f  call 0x0000705C0ACC0EA0
0000705c0add3714  jmp 0x0000705C0ADD2455
0000705c0add3719  call 0x0000705C0ACBFD50
0000705c0add371e  jmp 0x0000705C0ADD245F
0000705c0add3723  call 0x0000705C0ACB8EA0
0000705c0add3728  jmp 0x0000705C0ADD2469
0000705c0add372d  call 0x0000705C0ACBFC30
0000705c0add3732  jmp 0x0000705C0ADD2476
0000705c0add3737  call 0x0000705C0ACB8D90
0000705c0add373c  jmp 0x0000705C0ADD2483
0000705c0add3741  call 0x0000705C0ACB52F0
0000705c0add3746  jmp 0x0000705C0ADD2496
0000705c0add374b  call 0x0000705C0ACB52F0
0000705c0add3750  jmp 0x0000705C0ADD24A9
0000705c0add3755  call 0x0000705C0ACC0FC0
0000705c0add375a  jmp 0x0000705C0ADD24B6
0000705c0add375f  call 0x0000705C0ACC0FC0
0000705c0add3764  jmp 0x0000705C0ADD24C9
0000705c0add3769  call 0x0000705C0ACC0EA0
0000705c0add376e  jmp 0x0000705C0ADD24D6
0000705c0add3773  call 0x0000705C0ACB52F0
0000705c0add3778  jmp 0x0000705C0ADD24E9
0000705c0add377d  call 0x0000705C0ACB52F0
0000705c0add3782  jmp 0x0000705C0ADD24FC
0000705c0add3787  call 0x0000705C0ACB52F0
0000705c0add378c  jmp 0x0000705C0ADD250F
0000705c0add3791  call 0x0000705C0ACB52F0
0000705c0add3796  jmp 0x0000705C0ADD252A
0000705c0add379b  call 0x0000705C0ACB52F0
0000705c0add37a0  jmp 0x0000705C0ADD253D
0000705c0add37a5  call 0x0000705C0ACB5400
0000705c0add37aa  jmp 0x0000705C0ADD257E
0000705c0add37af  call 0x0000705C0ACC0FC0
0000705c0add37b4  jmp 0x0000705C0ADD258B
0000705c0add37b9  call 0x0000705C0ACB52F0
0000705c0add37be  jmp 0x0000705C0ADD2598
0000705c0add37c3  call 0x0000705C0ACC0EA0
0000705c0add37c8  jmp 0x0000705C0ADD25A5
0000705c0add37cd  call 0x0000705C0ABFF540
0000705c0add37d2  jmp 0x0000705C0ADD25C3
0000705c0add37d7  call 0x0000705C0AC08C20
0000705c0add37dc  jmp 0x0000705C0ADD25CD
0000705c0add37e1  call 0x0000705C0ACE21C0
0000705c0add37e6  jmp 0x0000705C0ADD25D3
0000705c0add37eb  call 0x0000705C0ABFF540
0000705c0add37f0  jmp 0x0000705C0ADD25E3
0000705c0add37f5  call 0x0000705C0ACC0370
0000705c0add37fa  jmp 0x0000705C0ADD2611
0000705c0add37ff  call 0x0000705C0ACBF100
0000705c0add3804  jmp 0x0000705C0ADD261A
0000705c0add3809  call 0x0000705C0ACC0370
0000705c0add380e  jmp 0x0000705C0ADD2674
0000705c0add3813  call 0x0000705C0ACBF100
0000705c0add3818  jmp 0x0000705C0ADD267D
0000705c0add381d  call 0x0000705C0ACC0370
0000705c0add3822  jmp 0x0000705C0ADD26C6
0000705c0add3827  call 0x0000705C0ACBF100
0000705c0add382c  jmp 0x0000705C0ADD26CF
0000705c0add3831  call 0x0000705C0AC0B720
0000705c0add3836  jmp 0x0000705C0ADD2714
0000705c0add383b  call 0x0000705C0ACB47C0
0000705c0add3840  jmp 0x0000705C0ADD2727
0000705c0add3845  call 0x0000705C0AC08B00
0000705c0add384a  jmp 0x0000705C0ADD273E
0000705c0add384f  call 0x0000705C0ABFF430
0000705c0add3854  jmp 0x0000705C0ADD2751
0000705c0add3859  call 0x0000705C0ABFF430
0000705c0add385e  jmp 0x0000705C0ADD2764
0000705c0add3863  sub rsp, 0x08
0000705c0add3867  push rax
0000705c0add3868  push rcx
0000705c0add3869  push rdx
0000705c0add386a  push rdi
0000705c0add386b  push rsi
0000705c0add386c  push r8
0000705c0add386e  push r9
0000705c0add3870  push r10
0000705c0add3872  push r11
0000705c0add3874  sub rsp, 0xF0
0000705c0add387b  vmovaps [rsp], xmm0
0000705c0add3880  vmovaps [rsp+0x10], xmm2
0000705c0add3886  vmovaps [rsp+0x20], xmm3
0000705c0add388c  vmovaps [rsp+0x30], xmm4
0000705c0add3892  vmovaps [rsp+0x40], xmm5
0000705c0add3898  vmovaps [rsp+0x50], xmm6
0000705c0add389e  vmovaps [rsp+0x60], xmm7
0000705c0add38a4  vmovaps [rsp+0x70], xmm8
0000705c0add38aa  vmovaps [rsp+0x80], xmm9
0000705c0add38b3  vmovaps [rsp+0x90], xmm10
0000705c0add38bc  vmovaps [rsp+0xA0], xmm11
0000705c0add38c5  vmovaps [rsp+0xB0], xmm12
0000705c0add38ce  vmovaps [rsp+0xC0], xmm13
0000705c0add38d7  vmovaps [rsp+0xD0], xmm14
0000705c0add38e0  vmovaps [rsp+0xE0], xmm15
0000705c0add38e9  sub rsp, 0x30
0000705c0add38ed  movaps [rsp], xmm1
0000705c0add38f1  movaps [rsp+0x10], xmm12
0000705c0add38f7  movaps [rsp+0x20], xmm15
0000705c0add38fd  lea rdi, [rsp]
0000705c0add3901  mov esi, 0x00
0000705c0add3906  mov rax, 0x5969C28C4530
0000705c0add3910  call rax
0000705c0add3912  movaps xmm1, [rsp]
0000705c0add3916  add rsp, 0x30
0000705c0add391a  vmovaps xmm0, [rsp]
0000705c0add391f  vmovaps xmm2, [rsp+0x10]
0000705c0add3925  vmovaps xmm3, [rsp+0x20]
0000705c0add392b  vmovaps xmm4, [rsp+0x30]
0000705c0add3931  vmovaps xmm5, [rsp+0x40]
0000705c0add3937  vmovaps xmm6, [rsp+0x50]
0000705c0add393d  vmovaps xmm7, [rsp+0x60]
0000705c0add3943  vmovaps xmm8, [rsp+0x70]
0000705c0add3949  vmovaps xmm9, [rsp+0x80]
0000705c0add3952  vmovaps xmm10, [rsp+0x90]
0000705c0add395b  vmovaps xmm11, [rsp+0xA0]
0000705c0add3964  vmovaps xmm12, [rsp+0xB0]
0000705c0add396d  vmovaps xmm13, [rsp+0xC0]
0000705c0add3976  vmovaps xmm14, [rsp+0xD0]
0000705c0add397f  vmovaps xmm15, [rsp+0xE0]
0000705c0add3988  add rsp, 0xF0
0000705c0add398f  pop r11
0000705c0add3991  pop r10
0000705c0add3993  pop r9
0000705c0add3995  pop r8
0000705c0add3997  pop rsi
0000705c0add3998  pop rdi
0000705c0add3999  pop rdx
0000705c0add399a  pop rcx
0000705c0add399b  pop rax
0000705c0add399c  add rsp, 0x08
0000705c0add39a0  jmp 0x0000705C0ADD27B2
0000705c0add39a5  sub rsp, 0x08
0000705c0add39a9  push rax
0000705c0add39aa  push rcx
0000705c0add39ab  push rdx
0000705c0add39ac  push rdi
0000705c0add39ad  push rsi
0000705c0add39ae  push r8
0000705c0add39b0  push r9
0000705c0add39b2  push r10
0000705c0add39b4  push r11
0000705c0add39b6  sub rsp, 0xF0
0000705c0add39bd  vmovaps [rsp], xmm0
0000705c0add39c2  vmovaps [rsp+0x10], xmm1
0000705c0add39c8  vmovaps [rsp+0x20], xmm2
0000705c0add39ce  vmovaps [rsp+0x30], xmm3
0000705c0add39d4  vmovaps [rsp+0x40], xmm4
0000705c0add39da  vmovaps [rsp+0x50], xmm5
0000705c0add39e0  vmovaps [rsp+0x60], xmm6
0000705c0add39e6  vmovaps [rsp+0x70], xmm7
0000705c0add39ec  vmovaps [rsp+0x80], xmm8
0000705c0add39f5  vmovaps [rsp+0x90], xmm9
0000705c0add39fe  vmovaps [rsp+0xA0], xmm10
0000705c0add3a07  vmovaps [rsp+0xB0], xmm11
0000705c0add3a10  vmovaps [rsp+0xC0], xmm12
0000705c0add3a19  vmovaps [rsp+0xD0], xmm13
0000705c0add3a22  vmovaps [rsp+0xE0], xmm15
0000705c0add3a2b  sub rsp, 0x30
0000705c0add3a2f  movaps [rsp], xmm14
0000705c0add3a34  movaps [rsp+0x10], xmm1
0000705c0add3a39  movaps [rsp+0x20], xmm15
0000705c0add3a3f  lea rdi, [rsp]
0000705c0add3a43  mov esi, 0x00
0000705c0add3a48  mov rax, 0x5969C28C4530
0000705c0add3a52  call rax
0000705c0add3a54  movaps xmm14, [rsp]
0000705c0add3a59  add rsp, 0x30
0000705c0add3a5d  vmovaps xmm0, [rsp]
0000705c0add3a62  vmovaps xmm1, [rsp+0x10]
0000705c0add3a68  vmovaps xmm2, [rsp+0x20]
0000705c0add3a6e  vmovaps xmm3, [rsp+0x30]
0000705c0add3a74  vmovaps xmm4, [rsp+0x40]
0000705c0add3a7a  vmovaps xmm5, [rsp+0x50]
0000705c0add3a80  vmovaps xmm6, [rsp+0x60]
0000705c0add3a86  vmovaps xmm7, [rsp+0x70]
0000705c0add3a8c  vmovaps xmm8, [rsp+0x80]
0000705c0add3a95  vmovaps xmm9, [rsp+0x90]
0000705c0add3a9e  vmovaps xmm10, [rsp+0xA0]
0000705c0add3aa7  vmovaps xmm11, [rsp+0xB0]
0000705c0add3ab0  vmovaps xmm12, [rsp+0xC0]
0000705c0add3ab9  vmovaps xmm13, [rsp+0xD0]
0000705c0add3ac2  vmovaps xmm15, [rsp+0xE0]
0000705c0add3acb  add rsp, 0xF0
0000705c0add3ad2  pop r11
0000705c0add3ad4  pop r10
0000705c0add3ad6  pop r9
0000705c0add3ad8  pop r8
0000705c0add3ada  pop rsi
0000705c0add3adb  pop rdi
0000705c0add3adc  pop rdx
0000705c0add3add  pop rcx
0000705c0add3ade  pop rax
0000705c0add3adf  add rsp, 0x08
0000705c0add3ae3  jmp 0x0000705C0ADD2800
0000705c0add3ae8  sub rsp, 0x08
0000705c0add3aec  push rax
0000705c0add3aed  push rcx
0000705c0add3aee  push rdx
0000705c0add3aef  push rdi
0000705c0add3af0  push rsi
0000705c0add3af1  push r8
0000705c0add3af3  push r9
0000705c0add3af5  push r10
0000705c0add3af7  push r11
0000705c0add3af9  sub rsp, 0xF0
0000705c0add3b00  vmovaps [rsp], xmm0
0000705c0add3b05  vmovaps [rsp+0x10], xmm1
0000705c0add3b0b  vmovaps [rsp+0x20], xmm2
0000705c0add3b11  vmovaps [rsp+0x30], xmm3
0000705c0add3b17  vmovaps [rsp+0x40], xmm4
0000705c0add3b1d  vmovaps [rsp+0x50], xmm5
0000705c0add3b23  vmovaps [rsp+0x60], xmm6
0000705c0add3b29  vmovaps [rsp+0x70], xmm7
0000705c0add3b2f  vmovaps [rsp+0x80], xmm8
0000705c0add3b38  vmovaps [rsp+0x90], xmm9
0000705c0add3b41  vmovaps [rsp+0xA0], xmm10
0000705c0add3b4a  vmovaps [rsp+0xB0], xmm11
0000705c0add3b53  vmovaps [rsp+0xC0], xmm12
0000705c0add3b5c  vmovaps [rsp+0xD0], xmm13
0000705c0add3b65  vmovaps [rsp+0xE0], xmm14
0000705c0add3b6e  sub rsp, 0x30
0000705c0add3b72  movaps [rsp], xmm15
0000705c0add3b77  movaps [rsp+0x10], xmm12
0000705c0add3b7d  movaps [rsp+0x20], xmm13
0000705c0add3b83  lea rdi, [rsp]
0000705c0add3b87  mov esi, 0x00
0000705c0add3b8c  mov rax, 0x5969C28C4530
0000705c0add3b96  call rax
0000705c0add3b98  movaps xmm15, [rsp]
0000705c0add3b9d  add rsp, 0x30
0000705c0add3ba1  vmovaps xmm0, [rsp]
0000705c0add3ba6  vmovaps xmm1, [rsp+0x10]
0000705c0add3bac  vmovaps xmm2, [rsp+0x20]
0000705c0add3bb2  vmovaps xmm3, [rsp+0x30]
0000705c0add3bb8  vmovaps xmm4, [rsp+0x40]
0000705c0add3bbe  vmovaps xmm5, [rsp+0x50]
0000705c0add3bc4  vmovaps xmm6, [rsp+0x60]
0000705c0add3bca  vmovaps xmm7, [rsp+0x70]
0000705c0add3bd0  vmovaps xmm8, [rsp+0x80]
0000705c0add3bd9  vmovaps xmm9, [rsp+0x90]
0000705c0add3be2  vmovaps xmm10, [rsp+0xA0]
0000705c0add3beb  vmovaps xmm11, [rsp+0xB0]
0000705c0add3bf4  vmovaps xmm12, [rsp+0xC0]
0000705c0add3bfd  vmovaps xmm13, [rsp+0xD0]
0000705c0add3c06  vmovaps xmm14, [rsp+0xE0]
0000705c0add3c0f  add rsp, 0xF0
0000705c0add3c16  pop r11
0000705c0add3c18  pop r10
0000705c0add3c1a  pop r9
0000705c0add3c1c  pop r8
0000705c0add3c1e  pop rsi
0000705c0add3c1f  pop rdi
0000705c0add3c20  pop rdx
0000705c0add3c21  pop rcx
0000705c0add3c22  pop rax
0000705c0add3c23  add rsp, 0x08
0000705c0add3c27  jmp 0x0000705C0ADD2835
0000705c0add3c2c  sub rsp, 0x08
0000705c0add3c30  push rax
0000705c0add3c31  push rcx
0000705c0add3c32  push rdx
0000705c0add3c33  push rdi
0000705c0add3c34  push rsi
0000705c0add3c35  push r8
0000705c0add3c37  push r9
0000705c0add3c39  push r10
0000705c0add3c3b  push r11
0000705c0add3c3d  sub rsp, 0xF0
0000705c0add3c44  vmovaps [rsp], xmm0
0000705c0add3c49  vmovaps [rsp+0x10], xmm2
0000705c0add3c4f  vmovaps [rsp+0x20], xmm3
0000705c0add3c55  vmovaps [rsp+0x30], xmm4
0000705c0add3c5b  vmovaps [rsp+0x40], xmm5
0000705c0add3c61  vmovaps [rsp+0x50], xmm6
0000705c0add3c67  vmovaps [rsp+0x60], xmm7
0000705c0add3c6d  vmovaps [rsp+0x70], xmm8
0000705c0add3c73  vmovaps [rsp+0x80], xmm9
0000705c0add3c7c  vmovaps [rsp+0x90], xmm10
0000705c0add3c85  vmovaps [rsp+0xA0], xmm11
0000705c0add3c8e  vmovaps [rsp+0xB0], xmm12
0000705c0add3c97  vmovaps [rsp+0xC0], xmm13
0000705c0add3ca0  vmovaps [rsp+0xD0], xmm14
0000705c0add3ca9  vmovaps [rsp+0xE0], xmm15
0000705c0add3cb2  sub rsp, 0x30
0000705c0add3cb6  movaps [rsp], xmm1
0000705c0add3cba  movaps [rsp+0x10], xmm12
0000705c0add3cc0  movaps [rsp+0x20], xmm10
0000705c0add3cc6  lea rdi, [rsp]
0000705c0add3cca  mov esi, 0x00
0000705c0add3ccf  mov rax, 0x5969C28C4530
0000705c0add3cd9  call rax
0000705c0add3cdb  movaps xmm1, [rsp]
0000705c0add3cdf  add rsp, 0x30
0000705c0add3ce3  vmovaps xmm0, [rsp]
0000705c0add3ce8  vmovaps xmm2, [rsp+0x10]
0000705c0add3cee  vmovaps xmm3, [rsp+0x20]
0000705c0add3cf4  vmovaps xmm4, [rsp+0x30]
0000705c0add3cfa  vmovaps xmm5, [rsp+0x40]
0000705c0add3d00  vmovaps xmm6, [rsp+0x50]
0000705c0add3d06  vmovaps xmm7, [rsp+0x60]
0000705c0add3d0c  vmovaps xmm8, [rsp+0x70]
0000705c0add3d12  vmovaps xmm9, [rsp+0x80]
0000705c0add3d1b  vmovaps xmm10, [rsp+0x90]
0000705c0add3d24  vmovaps xmm11, [rsp+0xA0]
0000705c0add3d2d  vmovaps xmm12, [rsp+0xB0]
0000705c0add3d36  vmovaps xmm13, [rsp+0xC0]
0000705c0add3d3f  vmovaps xmm14, [rsp+0xD0]
0000705c0add3d48  vmovaps xmm15, [rsp+0xE0]
0000705c0add3d51  add rsp, 0xF0
0000705c0add3d58  pop r11
0000705c0add3d5a  pop r10
0000705c0add3d5c  pop r9
0000705c0add3d5e  pop r8
0000705c0add3d60  pop rsi
0000705c0add3d61  pop rdi
0000705c0add3d62  pop rdx
0000705c0add3d63  pop rcx
0000705c0add3d64  pop rax
0000705c0add3d65  add rsp, 0x08
0000705c0add3d69  jmp 0x0000705C0ADD284F
0000705c0add3d6e  sub rsp, 0x08
0000705c0add3d72  push rax
0000705c0add3d73  push rcx
0000705c0add3d74  push rdx
0000705c0add3d75  push rdi
0000705c0add3d76  push rsi
0000705c0add3d77  push r8
0000705c0add3d79  push r9
0000705c0add3d7b  push r10
0000705c0add3d7d  push r11
0000705c0add3d7f  sub rsp, 0xF0
0000705c0add3d86  vmovaps [rsp], xmm0
0000705c0add3d8b  vmovaps [rsp+0x10], xmm1
0000705c0add3d91  vmovaps [rsp+0x20], xmm2
0000705c0add3d97  vmovaps [rsp+0x30], xmm3
0000705c0add3d9d  vmovaps [rsp+0x40], xmm4
0000705c0add3da3  vmovaps [rsp+0x50], xmm5
0000705c0add3da9  vmovaps [rsp+0x60], xmm6
0000705c0add3daf  vmovaps [rsp+0x70], xmm7
0000705c0add3db5  vmovaps [rsp+0x80], xmm8
0000705c0add3dbe  vmovaps [rsp+0x90], xmm9
0000705c0add3dc7  vmovaps [rsp+0xA0], xmm10
0000705c0add3dd0  vmovaps [rsp+0xB0], xmm11
0000705c0add3dd9  vmovaps [rsp+0xC0], xmm12
0000705c0add3de2  vmovaps [rsp+0xD0], xmm14
0000705c0add3deb  vmovaps [rsp+0xE0], xmm15
0000705c0add3df4  sub rsp, 0x30
0000705c0add3df8  movaps [rsp], xmm13
0000705c0add3dfd  movaps [rsp+0x10], xmm12
0000705c0add3e03  movaps [rsp+0x20], xmm2
0000705c0add3e08  lea rdi, [rsp]
0000705c0add3e0c  mov esi, 0x00
0000705c0add3e11  mov rax, 0x5969C28C4530
0000705c0add3e1b  call rax
0000705c0add3e1d  movaps xmm13, [rsp]
0000705c0add3e22  add rsp, 0x30
0000705c0add3e26  vmovaps xmm0, [rsp]
0000705c0add3e2b  vmovaps xmm1, [rsp+0x10]
0000705c0add3e31  vmovaps xmm2, [rsp+0x20]
0000705c0add3e37  vmovaps xmm3, [rsp+0x30]
0000705c0add3e3d  vmovaps xmm4, [rsp+0x40]
0000705c0add3e43  vmovaps xmm5, [rsp+0x50]
0000705c0add3e49  vmovaps xmm6, [rsp+0x60]
0000705c0add3e4f  vmovaps xmm7, [rsp+0x70]
0000705c0add3e55  vmovaps xmm8, [rsp+0x80]
0000705c0add3e5e  vmovaps xmm9, [rsp+0x90]
0000705c0add3e67  vmovaps xmm10, [rsp+0xA0]
0000705c0add3e70  vmovaps xmm11, [rsp+0xB0]
0000705c0add3e79  vmovaps xmm12, [rsp+0xC0]
0000705c0add3e82  vmovaps xmm14, [rsp+0xD0]
0000705c0add3e8b  vmovaps xmm15, [rsp+0xE0]
0000705c0add3e94  add rsp, 0xF0
0000705c0add3e9b  pop r11
0000705c0add3e9d  pop r10
0000705c0add3e9f  pop r9
0000705c0add3ea1  pop r8
0000705c0add3ea3  pop rsi
0000705c0add3ea4  pop rdi
0000705c0add3ea5  pop rdx
0000705c0add3ea6  pop rcx
0000705c0add3ea7  pop rax
0000705c0add3ea8  add rsp, 0x08
0000705c0add3eac  jmp 0x0000705C0ADD286A
0000705c0add3eb1  sub rsp, 0x08
0000705c0add3eb5  push rax
0000705c0add3eb6  push rcx
0000705c0add3eb7  push rdx
0000705c0add3eb8  push rdi
0000705c0add3eb9  push rsi
0000705c0add3eba  push r8
0000705c0add3ebc  push r9
0000705c0add3ebe  push r10
0000705c0add3ec0  push r11
0000705c0add3ec2  sub rsp, 0xF0
0000705c0add3ec9  vmovaps [rsp], xmm0
0000705c0add3ece  vmovaps [rsp+0x10], xmm2
0000705c0add3ed4  vmovaps [rsp+0x20], xmm3
0000705c0add3eda  vmovaps [rsp+0x30], xmm4
0000705c0add3ee0  vmovaps [rsp+0x40], xmm5
0000705c0add3ee6  vmovaps [rsp+0x50], xmm6
0000705c0add3eec  vmovaps [rsp+0x60], xmm7
0000705c0add3ef2  vmovaps [rsp+0x70], xmm8
0000705c0add3ef8  vmovaps [rsp+0x80], xmm9
0000705c0add3f01  vmovaps [rsp+0x90], xmm10
0000705c0add3f0a  vmovaps [rsp+0xA0], xmm11
0000705c0add3f13  vmovaps [rsp+0xB0], xmm12
0000705c0add3f1c  vmovaps [rsp+0xC0], xmm13
0000705c0add3f25  vmovaps [rsp+0xD0], xmm14
0000705c0add3f2e  vmovaps [rsp+0xE0], xmm15
0000705c0add3f37  sub rsp, 0x30
0000705c0add3f3b  movaps [rsp], xmm1
0000705c0add3f3f  movaps [rsp+0x10], xmm10
0000705c0add3f45  movaps [rsp+0x20], xmm2
0000705c0add3f4a  lea rdi, [rsp]
0000705c0add3f4e  mov esi, 0x00
0000705c0add3f53  mov rax, 0x5969C28C4530
0000705c0add3f5d  call rax
0000705c0add3f5f  movaps xmm1, [rsp]
0000705c0add3f63  add rsp, 0x30
0000705c0add3f67  vmovaps xmm0, [rsp]
0000705c0add3f6c  vmovaps xmm2, [rsp+0x10]
0000705c0add3f72  vmovaps xmm3, [rsp+0x20]
0000705c0add3f78  vmovaps xmm4, [rsp+0x30]
0000705c0add3f7e  vmovaps xmm5, [rsp+0x40]
0000705c0add3f84  vmovaps xmm6, [rsp+0x50]
0000705c0add3f8a  vmovaps xmm7, [rsp+0x60]
0000705c0add3f90  vmovaps xmm8, [rsp+0x70]
0000705c0add3f96  vmovaps xmm9, [rsp+0x80]
0000705c0add3f9f  vmovaps xmm10, [rsp+0x90]
0000705c0add3fa8  vmovaps xmm11, [rsp+0xA0]
0000705c0add3fb1  vmovaps xmm12, [rsp+0xB0]
0000705c0add3fba  vmovaps xmm13, [rsp+0xC0]
0000705c0add3fc3  vmovaps xmm14, [rsp+0xD0]
0000705c0add3fcc  vmovaps xmm15, [rsp+0xE0]
0000705c0add3fd5  add rsp, 0xF0
0000705c0add3fdc  pop r11
0000705c0add3fde  pop r10
0000705c0add3fe0  pop r9
0000705c0add3fe2  pop r8
0000705c0add3fe4  pop rsi
0000705c0add3fe5  pop rdi
0000705c0add3fe6  pop rdx
0000705c0add3fe7  pop rcx
0000705c0add3fe8  pop rax
0000705c0add3fe9  add rsp, 0x08
0000705c0add3fed  jmp 0x0000705C0ADD28D2
0000705c0add3ff2  sub rsp, 0x08
0000705c0add3ff6  push rax
0000705c0add3ff7  push rcx
0000705c0add3ff8  push rdx
0000705c0add3ff9  push rdi
0000705c0add3ffa  push rsi
0000705c0add3ffb  push r8
0000705c0add3ffd  push r9
0000705c0add3fff  push r10
0000705c0add4001  push r11
0000705c0add4003  sub rsp, 0xF0
0000705c0add400a  vmovaps [rsp], xmm0
0000705c0add400f  vmovaps [rsp+0x10], xmm1
0000705c0add4015  vmovaps [rsp+0x20], xmm2
0000705c0add401b  vmovaps [rsp+0x30], xmm3
0000705c0add4021  vmovaps [rsp+0x40], xmm4
0000705c0add4027  vmovaps [rsp+0x50], xmm5
0000705c0add402d  vmovaps [rsp+0x60], xmm6
0000705c0add4033  vmovaps [rsp+0x70], xmm7
0000705c0add4039  vmovaps [rsp+0x80], xmm8
0000705c0add4042  vmovaps [rsp+0x90], xmm9
0000705c0add404b  vmovaps [rsp+0xA0], xmm10
0000705c0add4054  vmovaps [rsp+0xB0], xmm11
0000705c0add405d  vmovaps [rsp+0xC0], xmm12
0000705c0add4066  vmovaps [rsp+0xD0], xmm13
0000705c0add406f  vmovaps [rsp+0xE0], xmm14
0000705c0add4078  sub rsp, 0x30
0000705c0add407c  movaps [rsp], xmm15
0000705c0add4081  movaps [rsp+0x10], xmm10
0000705c0add4087  movaps [rsp+0x20], xmm2
0000705c0add408c  lea rdi, [rsp]
0000705c0add4090  mov esi, 0x00
0000705c0add4095  mov rax, 0x5969C28C4530
0000705c0add409f  call rax
0000705c0add40a1  movaps xmm15, [rsp]
0000705c0add40a6  add rsp, 0x30
0000705c0add40aa  vmovaps xmm0, [rsp]
0000705c0add40af  vmovaps xmm1, [rsp+0x10]
0000705c0add40b5  vmovaps xmm2, [rsp+0x20]
0000705c0add40bb  vmovaps xmm3, [rsp+0x30]
0000705c0add40c1  vmovaps xmm4, [rsp+0x40]
0000705c0add40c7  vmovaps xmm5, [rsp+0x50]
0000705c0add40cd  vmovaps xmm6, [rsp+0x60]
0000705c0add40d3  vmovaps xmm7, [rsp+0x70]
0000705c0add40d9  vmovaps xmm8, [rsp+0x80]
0000705c0add40e2  vmovaps xmm9, [rsp+0x90]
0000705c0add40eb  vmovaps xmm10, [rsp+0xA0]
0000705c0add40f4  vmovaps xmm11, [rsp+0xB0]
0000705c0add40fd  vmovaps xmm12, [rsp+0xC0]
0000705c0add4106  vmovaps xmm13, [rsp+0xD0]
0000705c0add410f  vmovaps xmm14, [rsp+0xE0]
0000705c0add4118  add rsp, 0xF0
0000705c0add411f  pop r11
0000705c0add4121  pop r10
0000705c0add4123  pop r9
0000705c0add4125  pop r8
0000705c0add4127  pop rsi
0000705c0add4128  pop rdi
0000705c0add4129  pop rdx
0000705c0add412a  pop rcx
0000705c0add412b  pop rax
0000705c0add412c  add rsp, 0x08
0000705c0add4130  jmp 0x0000705C0ADD2924
0000705c0add4135  sub rsp, 0x08
0000705c0add4139  push rax
0000705c0add413a  push rcx
0000705c0add413b  push rdx
0000705c0add413c  push rdi
0000705c0add413d  push rsi
0000705c0add413e  push r8
0000705c0add4140  push r9
0000705c0add4142  push r10
0000705c0add4144  push r11
0000705c0add4146  sub rsp, 0xF0
0000705c0add414d  vmovaps [rsp], xmm0
0000705c0add4152  vmovaps [rsp+0x10], xmm2
0000705c0add4158  vmovaps [rsp+0x20], xmm3
0000705c0add415e  vmovaps [rsp+0x30], xmm4
0000705c0add4164  vmovaps [rsp+0x40], xmm5
0000705c0add416a  vmovaps [rsp+0x50], xmm6
0000705c0add4170  vmovaps [rsp+0x60], xmm7
0000705c0add4176  vmovaps [rsp+0x70], xmm8
0000705c0add417c  vmovaps [rsp+0x80], xmm9
0000705c0add4185  vmovaps [rsp+0x90], xmm10
0000705c0add418e  vmovaps [rsp+0xA0], xmm11
0000705c0add4197  vmovaps [rsp+0xB0], xmm12
0000705c0add41a0  vmovaps [rsp+0xC0], xmm13
0000705c0add41a9  vmovaps [rsp+0xD0], xmm14
0000705c0add41b2  vmovaps [rsp+0xE0], xmm15
0000705c0add41bb  sub rsp, 0x30
0000705c0add41bf  movaps [rsp], xmm1
0000705c0add41c3  movaps [rsp+0x10], xmm10
0000705c0add41c9  movaps [rsp+0x20], xmm15
0000705c0add41cf  lea rdi, [rsp]
0000705c0add41d3  mov esi, 0x00
0000705c0add41d8  mov rax, 0x5969C28C4530
0000705c0add41e2  call rax
0000705c0add41e4  movaps xmm1, [rsp]
0000705c0add41e8  add rsp, 0x30
0000705c0add41ec  vmovaps xmm0, [rsp]
0000705c0add41f1  vmovaps xmm2, [rsp+0x10]
0000705c0add41f7  vmovaps xmm3, [rsp+0x20]
0000705c0add41fd  vmovaps xmm4, [rsp+0x30]
0000705c0add4203  vmovaps xmm5, [rsp+0x40]
0000705c0add4209  vmovaps xmm6, [rsp+0x50]
0000705c0add420f  vmovaps xmm7, [rsp+0x60]
0000705c0add4215  vmovaps xmm8, [rsp+0x70]
0000705c0add421b  vmovaps xmm9, [rsp+0x80]
0000705c0add4224  vmovaps xmm10, [rsp+0x90]
0000705c0add422d  vmovaps xmm11, [rsp+0xA0]
0000705c0add4236  vmovaps xmm12, [rsp+0xB0]
0000705c0add423f  vmovaps xmm13, [rsp+0xC0]
0000705c0add4248  vmovaps xmm14, [rsp+0xD0]
0000705c0add4251  vmovaps xmm15, [rsp+0xE0]
0000705c0add425a  add rsp, 0xF0
0000705c0add4261  pop r11
0000705c0add4263  pop r10
0000705c0add4265  pop r9
0000705c0add4267  pop r8
0000705c0add4269  pop rsi
0000705c0add426a  pop rdi
0000705c0add426b  pop rdx
0000705c0add426c  pop rcx
0000705c0add426d  pop rax
0000705c0add426e  add rsp, 0x08
0000705c0add4272  jmp 0x0000705C0ADD2962
0000705c0add4277  sub rsp, 0x08
0000705c0add427b  push rax
0000705c0add427c  push rcx
0000705c0add427d  push rdx
0000705c0add427e  push rdi
0000705c0add427f  push rsi
0000705c0add4280  push r8
0000705c0add4282  push r9
0000705c0add4284  push r10
0000705c0add4286  push r11
0000705c0add4288  sub rsp, 0xF0
0000705c0add428f  vmovaps [rsp], xmm0
0000705c0add4294  vmovaps [rsp+0x10], xmm1
0000705c0add429a  vmovaps [rsp+0x20], xmm2
0000705c0add42a0  vmovaps [rsp+0x30], xmm3
0000705c0add42a6  vmovaps [rsp+0x40], xmm4
0000705c0add42ac  vmovaps [rsp+0x50], xmm5
0000705c0add42b2  vmovaps [rsp+0x60], xmm6
0000705c0add42b8  vmovaps [rsp+0x70], xmm7
0000705c0add42be  vmovaps [rsp+0x80], xmm8
0000705c0add42c7  vmovaps [rsp+0x90], xmm9
0000705c0add42d0  vmovaps [rsp+0xA0], xmm10
0000705c0add42d9  vmovaps [rsp+0xB0], xmm11
0000705c0add42e2  vmovaps [rsp+0xC0], xmm12
0000705c0add42eb  vmovaps [rsp+0xD0], xmm13
0000705c0add42f4  vmovaps [rsp+0xE0], xmm15
0000705c0add42fd  sub rsp, 0x30
0000705c0add4301  movaps [rsp], xmm14
0000705c0add4306  movaps [rsp+0x10], xmm10
0000705c0add430c  movaps [rsp+0x20], xmm15
0000705c0add4312  lea rdi, [rsp]
0000705c0add4316  mov esi, 0x00
0000705c0add431b  mov rax, 0x5969C28C4530
0000705c0add4325  call rax
0000705c0add4327  movaps xmm14, [rsp]
0000705c0add432c  add rsp, 0x30
0000705c0add4330  vmovaps xmm0, [rsp]
0000705c0add4335  vmovaps xmm1, [rsp+0x10]
0000705c0add433b  vmovaps xmm2, [rsp+0x20]
0000705c0add4341  vmovaps xmm3, [rsp+0x30]
0000705c0add4347  vmovaps xmm4, [rsp+0x40]
0000705c0add434d  vmovaps xmm5, [rsp+0x50]
0000705c0add4353  vmovaps xmm6, [rsp+0x60]
0000705c0add4359  vmovaps xmm7, [rsp+0x70]
0000705c0add435f  vmovaps xmm8, [rsp+0x80]
0000705c0add4368  vmovaps xmm9, [rsp+0x90]
0000705c0add4371  vmovaps xmm10, [rsp+0xA0]
0000705c0add437a  vmovaps xmm11, [rsp+0xB0]
0000705c0add4383  vmovaps xmm12, [rsp+0xC0]
0000705c0add438c  vmovaps xmm13, [rsp+0xD0]
0000705c0add4395  vmovaps xmm15, [rsp+0xE0]
0000705c0add439e  add rsp, 0xF0
0000705c0add43a5  pop r11
0000705c0add43a7  pop r10
0000705c0add43a9  pop r9
0000705c0add43ab  pop r8
0000705c0add43ad  pop rsi
0000705c0add43ae  pop rdi
0000705c0add43af  pop rdx
0000705c0add43b0  pop rcx
0000705c0add43b1  pop rax
0000705c0add43b2  add rsp, 0x08
0000705c0add43b6  jmp 0x0000705C0ADD298E
0000705c0add43bb  call 0x0000705C0ABFF430
0000705c0add43c0  jmp 0x0000705C0ADD2A1E
0000705c0add43c5  call 0x0000705C0ABFF430
0000705c0add43ca  jmp 0x0000705C0ADD2A31
0000705c0add43cf  sub rsp, 0x08
0000705c0add43d3  push rax
0000705c0add43d4  push rcx
0000705c0add43d5  push rdx
0000705c0add43d6  push rdi
0000705c0add43d7  push rsi
0000705c0add43d8  push r8
0000705c0add43da  push r9
0000705c0add43dc  push r10
0000705c0add43de  push r11
0000705c0add43e0  sub rsp, 0xF0
0000705c0add43e7  vmovaps [rsp], xmm0
0000705c0add43ec  vmovaps [rsp+0x10], xmm2
0000705c0add43f2  vmovaps [rsp+0x20], xmm3
0000705c0add43f8  vmovaps [rsp+0x30], xmm4
0000705c0add43fe  vmovaps [rsp+0x40], xmm5
0000705c0add4404  vmovaps [rsp+0x50], xmm6
0000705c0add440a  vmovaps [rsp+0x60], xmm7
0000705c0add4410  vmovaps [rsp+0x70], xmm8
0000705c0add4416  vmovaps [rsp+0x80], xmm9
0000705c0add441f  vmovaps [rsp+0x90], xmm10
0000705c0add4428  vmovaps [rsp+0xA0], xmm11
0000705c0add4431  vmovaps [rsp+0xB0], xmm12
0000705c0add443a  vmovaps [rsp+0xC0], xmm13
0000705c0add4443  vmovaps [rsp+0xD0], xmm14
0000705c0add444c  vmovaps [rsp+0xE0], xmm15
0000705c0add4455  sub rsp, 0x30
0000705c0add4459  movaps [rsp], xmm1
0000705c0add445d  movaps [rsp+0x10], xmm13
0000705c0add4463  movaps [rsp+0x20], xmm2
0000705c0add4468  lea rdi, [rsp]
0000705c0add446c  mov esi, 0x00
0000705c0add4471  mov rax, 0x5969C28C4530
0000705c0add447b  call rax
0000705c0add447d  movaps xmm1, [rsp]
0000705c0add4481  add rsp, 0x30
0000705c0add4485  vmovaps xmm0, [rsp]
0000705c0add448a  vmovaps xmm2, [rsp+0x10]
0000705c0add4490  vmovaps xmm3, [rsp+0x20]
0000705c0add4496  vmovaps xmm4, [rsp+0x30]
0000705c0add449c  vmovaps xmm5, [rsp+0x40]
0000705c0add44a2  vmovaps xmm6, [rsp+0x50]
0000705c0add44a8  vmovaps xmm7, [rsp+0x60]
0000705c0add44ae  vmovaps xmm8, [rsp+0x70]
0000705c0add44b4  vmovaps xmm9, [rsp+0x80]
0000705c0add44bd  vmovaps xmm10, [rsp+0x90]
0000705c0add44c6  vmovaps xmm11, [rsp+0xA0]
0000705c0add44cf  vmovaps xmm12, [rsp+0xB0]
0000705c0add44d8  vmovaps xmm13, [rsp+0xC0]
0000705c0add44e1  vmovaps xmm14, [rsp+0xD0]
0000705c0add44ea  vmovaps xmm15, [rsp+0xE0]
0000705c0add44f3  add rsp, 0xF0
0000705c0add44fa  pop r11
0000705c0add44fc  pop r10
0000705c0add44fe  pop r9
0000705c0add4500  pop r8
0000705c0add4502  pop rsi
0000705c0add4503  pop rdi
0000705c0add4504  pop rdx
0000705c0add4505  pop rcx
0000705c0add4506  pop rax
0000705c0add4507  add rsp, 0x08
0000705c0add450b  jmp 0x0000705C0ADD2A5C
0000705c0add4510  call 0x0000705C0AC0E760
0000705c0add4515  jmp 0x0000705C0ADD2A69
0000705c0add451a  sub rsp, 0x08
0000705c0add451e  push rax
0000705c0add451f  push rcx
0000705c0add4520  push rdx
0000705c0add4521  push rdi
0000705c0add4522  push rsi
0000705c0add4523  push r8
0000705c0add4525  push r9
0000705c0add4527  push r10
0000705c0add4529  push r11
0000705c0add452b  sub rsp, 0xF0
0000705c0add4532  vmovaps [rsp], xmm0
0000705c0add4537  vmovaps [rsp+0x10], xmm1
0000705c0add453d  vmovaps [rsp+0x20], xmm2
0000705c0add4543  vmovaps [rsp+0x30], xmm3
0000705c0add4549  vmovaps [rsp+0x40], xmm4
0000705c0add454f  vmovaps [rsp+0x50], xmm5
0000705c0add4555  vmovaps [rsp+0x60], xmm6
0000705c0add455b  vmovaps [rsp+0x70], xmm7
0000705c0add4561  vmovaps [rsp+0x80], xmm8
0000705c0add456a  vmovaps [rsp+0x90], xmm9
0000705c0add4573  vmovaps [rsp+0xA0], xmm10
0000705c0add457c  vmovaps [rsp+0xB0], xmm11
0000705c0add4585  vmovaps [rsp+0xC0], xmm12
0000705c0add458e  vmovaps [rsp+0xD0], xmm14
0000705c0add4597  vmovaps [rsp+0xE0], xmm15
0000705c0add45a0  sub rsp, 0x30
0000705c0add45a4  movaps [rsp], xmm13
0000705c0add45a9  movaps [rsp+0x10], xmm2
0000705c0add45ae  movaps [rsp+0x20], xmm1
0000705c0add45b3  lea rdi, [rsp]
0000705c0add45b7  mov esi, 0x00
0000705c0add45bc  mov rax, 0x5969C28C4530
0000705c0add45c6  call rax
0000705c0add45c8  movaps xmm13, [rsp]
0000705c0add45cd  add rsp, 0x30
0000705c0add45d1  vmovaps xmm0, [rsp]
0000705c0add45d6  vmovaps xmm1, [rsp+0x10]
0000705c0add45dc  vmovaps xmm2, [rsp+0x20]
0000705c0add45e2  vmovaps xmm3, [rsp+0x30]
0000705c0add45e8  vmovaps xmm4, [rsp+0x40]
0000705c0add45ee  vmovaps xmm5, [rsp+0x50]
0000705c0add45f4  vmovaps xmm6, [rsp+0x60]
0000705c0add45fa  vmovaps xmm7, [rsp+0x70]
0000705c0add4600  vmovaps xmm8, [rsp+0x80]
0000705c0add4609  vmovaps xmm9, [rsp+0x90]
0000705c0add4612  vmovaps xmm10, [rsp+0xA0]
0000705c0add461b  vmovaps xmm11, [rsp+0xB0]
0000705c0add4624  vmovaps xmm12, [rsp+0xC0]
0000705c0add462d  vmovaps xmm14, [rsp+0xD0]
0000705c0add4636  vmovaps xmm15, [rsp+0xE0]
0000705c0add463f  add rsp, 0xF0
0000705c0add4646  pop r11
0000705c0add4648  pop r10
0000705c0add464a  pop r9
0000705c0add464c  pop r8
0000705c0add464e  pop rsi
0000705c0add464f  pop rdi
0000705c0add4650  pop rdx
0000705c0add4651  pop rcx
0000705c0add4652  pop rax
0000705c0add4653  add rsp, 0x08
0000705c0add4657  jmp 0x0000705C0ADD2AA8
0000705c0add465c  sub rsp, 0x08
0000705c0add4660  push rax
0000705c0add4661  push rcx
0000705c0add4662  push rdx
0000705c0add4663  push rdi
0000705c0add4664  push rsi
0000705c0add4665  push r8
0000705c0add4667  push r9
0000705c0add4669  push r10
0000705c0add466b  push r11
0000705c0add466d  sub rsp, 0xF0
0000705c0add4674  vmovaps [rsp], xmm0
0000705c0add4679  vmovaps [rsp+0x10], xmm2
0000705c0add467f  vmovaps [rsp+0x20], xmm3
0000705c0add4685  vmovaps [rsp+0x30], xmm4
0000705c0add468b  vmovaps [rsp+0x40], xmm5
0000705c0add4691  vmovaps [rsp+0x50], xmm6
0000705c0add4697  vmovaps [rsp+0x60], xmm7
0000705c0add469d  vmovaps [rsp+0x70], xmm8
0000705c0add46a3  vmovaps [rsp+0x80], xmm9
0000705c0add46ac  vmovaps [rsp+0x90], xmm10
0000705c0add46b5  vmovaps [rsp+0xA0], xmm11
0000705c0add46be  vmovaps [rsp+0xB0], xmm12
0000705c0add46c7  vmovaps [rsp+0xC0], xmm13
0000705c0add46d0  vmovaps [rsp+0xD0], xmm14
0000705c0add46d9  vmovaps [rsp+0xE0], xmm15
0000705c0add46e2  sub rsp, 0x30
0000705c0add46e6  movaps [rsp], xmm1
0000705c0add46ea  movaps [rsp+0x10], xmm14
0000705c0add46f0  movaps [rsp+0x20], xmm15
0000705c0add46f6  lea rdi, [rsp]
0000705c0add46fa  mov esi, 0x00
0000705c0add46ff  mov rax, 0x5969C28C4530
0000705c0add4709  call rax
0000705c0add470b  movaps xmm1, [rsp]
0000705c0add470f  add rsp, 0x30
0000705c0add4713  vmovaps xmm0, [rsp]
0000705c0add4718  vmovaps xmm2, [rsp+0x10]
0000705c0add471e  vmovaps xmm3, [rsp+0x20]
0000705c0add4724  vmovaps xmm4, [rsp+0x30]
0000705c0add472a  vmovaps xmm5, [rsp+0x40]
0000705c0add4730  vmovaps xmm6, [rsp+0x50]
0000705c0add4736  vmovaps xmm7, [rsp+0x60]
0000705c0add473c  vmovaps xmm8, [rsp+0x70]
0000705c0add4742  vmovaps xmm9, [rsp+0x80]
0000705c0add474b  vmovaps xmm10, [rsp+0x90]
0000705c0add4754  vmovaps xmm11, [rsp+0xA0]
0000705c0add475d  vmovaps xmm12, [rsp+0xB0]
0000705c0add4766  vmovaps xmm13, [rsp+0xC0]
0000705c0add476f  vmovaps xmm14, [rsp+0xD0]
0000705c0add4778  vmovaps xmm15, [rsp+0xE0]
0000705c0add4781  add rsp, 0xF0
0000705c0add4788  pop r11
0000705c0add478a  pop r10
0000705c0add478c  pop r9
0000705c0add478e  pop r8
0000705c0add4790  pop rsi
0000705c0add4791  pop rdi
0000705c0add4792  pop rdx
0000705c0add4793  pop rcx
0000705c0add4794  pop rax
0000705c0add4795  add rsp, 0x08
0000705c0add4799  jmp 0x0000705C0ADD2ACA
0000705c0add479e  sub rsp, 0x08
0000705c0add47a2  push rax
0000705c0add47a3  push rcx
0000705c0add47a4  push rdx
0000705c0add47a5  push rdi
0000705c0add47a6  push rsi
0000705c0add47a7  push r8
0000705c0add47a9  push r9
0000705c0add47ab  push r10
0000705c0add47ad  push r11
0000705c0add47af  sub rsp, 0xF0
0000705c0add47b6  vmovaps [rsp], xmm0
0000705c0add47bb  vmovaps [rsp+0x10], xmm1
0000705c0add47c1  vmovaps [rsp+0x20], xmm2
0000705c0add47c7  vmovaps [rsp+0x30], xmm3
0000705c0add47cd  vmovaps [rsp+0x40], xmm4
0000705c0add47d3  vmovaps [rsp+0x50], xmm5
0000705c0add47d9  vmovaps [rsp+0x60], xmm6
0000705c0add47df  vmovaps [rsp+0x70], xmm7
0000705c0add47e5  vmovaps [rsp+0x80], xmm8
0000705c0add47ee  vmovaps [rsp+0x90], xmm9
0000705c0add47f7  vmovaps [rsp+0xA0], xmm10
0000705c0add4800  vmovaps [rsp+0xB0], xmm11
0000705c0add4809  vmovaps [rsp+0xC0], xmm12
0000705c0add4812  vmovaps [rsp+0xD0], xmm13
0000705c0add481b  vmovaps [rsp+0xE0], xmm15
0000705c0add4824  sub rsp, 0x30
0000705c0add4828  movaps [rsp], xmm14
0000705c0add482d  movaps [rsp+0x10], xmm2
0000705c0add4832  movaps [rsp+0x20], xmm15
0000705c0add4838  lea rdi, [rsp]
0000705c0add483c  mov esi, 0x00
0000705c0add4841  mov rax, 0x5969C28C4530
0000705c0add484b  call rax
0000705c0add484d  movaps xmm14, [rsp]
0000705c0add4852  add rsp, 0x30
0000705c0add4856  vmovaps xmm0, [rsp]
0000705c0add485b  vmovaps xmm1, [rsp+0x10]
0000705c0add4861  vmovaps xmm2, [rsp+0x20]
0000705c0add4867  vmovaps xmm3, [rsp+0x30]
0000705c0add486d  vmovaps xmm4, [rsp+0x40]
0000705c0add4873  vmovaps xmm5, [rsp+0x50]
0000705c0add4879  vmovaps xmm6, [rsp+0x60]
0000705c0add487f  vmovaps xmm7, [rsp+0x70]
0000705c0add4885  vmovaps xmm8, [rsp+0x80]
0000705c0add488e  vmovaps xmm9, [rsp+0x90]
0000705c0add4897  vmovaps xmm10, [rsp+0xA0]
0000705c0add48a0  vmovaps xmm11, [rsp+0xB0]
0000705c0add48a9  vmovaps xmm12, [rsp+0xC0]
0000705c0add48b2  vmovaps xmm13, [rsp+0xD0]
0000705c0add48bb  vmovaps xmm15, [rsp+0xE0]
0000705c0add48c4  add rsp, 0xF0
0000705c0add48cb  pop r11
0000705c0add48cd  pop r10
0000705c0add48cf  pop r9
0000705c0add48d1  pop r8
0000705c0add48d3  pop rsi
0000705c0add48d4  pop rdi
0000705c0add48d5  pop rdx
0000705c0add48d6  pop rcx
0000705c0add48d7  pop rax
0000705c0add48d8  add rsp, 0x08
0000705c0add48dc  jmp 0x0000705C0ADD2B05
0000705c0add48e1  sub rsp, 0x08
0000705c0add48e5  push rax
0000705c0add48e6  push rcx
0000705c0add48e7  push rdx
0000705c0add48e8  push rdi
0000705c0add48e9  push rsi
0000705c0add48ea  push r8
0000705c0add48ec  push r9
0000705c0add48ee  push r10
0000705c0add48f0  push r11
0000705c0add48f2  sub rsp, 0xF0
0000705c0add48f9  vmovaps [rsp], xmm0
0000705c0add48fe  vmovaps [rsp+0x10], xmm1
0000705c0add4904  vmovaps [rsp+0x20], xmm2
0000705c0add490a  vmovaps [rsp+0x30], xmm3
0000705c0add4910  vmovaps [rsp+0x40], xmm4
0000705c0add4916  vmovaps [rsp+0x50], xmm5
0000705c0add491c  vmovaps [rsp+0x60], xmm6
0000705c0add4922  vmovaps [rsp+0x70], xmm7
0000705c0add4928  vmovaps [rsp+0x80], xmm8
0000705c0add4931  vmovaps [rsp+0x90], xmm9
0000705c0add493a  vmovaps [rsp+0xA0], xmm10
0000705c0add4943  vmovaps [rsp+0xB0], xmm11
0000705c0add494c  vmovaps [rsp+0xC0], xmm12
0000705c0add4955  vmovaps [rsp+0xD0], xmm13
0000705c0add495e  vmovaps [rsp+0xE0], xmm14
0000705c0add4967  sub rsp, 0x30
0000705c0add496b  movaps [rsp], xmm15
0000705c0add4970  movaps [rsp+0x10], xmm2
0000705c0add4975  movaps [rsp+0x20], xmm1
0000705c0add497a  lea rdi, [rsp]
0000705c0add497e  mov esi, 0x00
0000705c0add4983  mov rax, 0x5969C28C4530
0000705c0add498d  call rax
0000705c0add498f  movaps xmm15, [rsp]
0000705c0add4994  add rsp, 0x30
0000705c0add4998  vmovaps xmm0, [rsp]
0000705c0add499d  vmovaps xmm1, [rsp+0x10]
0000705c0add49a3  vmovaps xmm2, [rsp+0x20]
0000705c0add49a9  vmovaps xmm3, [rsp+0x30]
0000705c0add49af  vmovaps xmm4, [rsp+0x40]
0000705c0add49b5  vmovaps xmm5, [rsp+0x50]
0000705c0add49bb  vmovaps xmm6, [rsp+0x60]
0000705c0add49c1  vmovaps xmm7, [rsp+0x70]
0000705c0add49c7  vmovaps xmm8, [rsp+0x80]
0000705c0add49d0  vmovaps xmm9, [rsp+0x90]
0000705c0add49d9  vmovaps xmm10, [rsp+0xA0]
0000705c0add49e2  vmovaps xmm11, [rsp+0xB0]
0000705c0add49eb  vmovaps xmm12, [rsp+0xC0]
0000705c0add49f4  vmovaps xmm13, [rsp+0xD0]
0000705c0add49fd  vmovaps xmm14, [rsp+0xE0]
0000705c0add4a06  add rsp, 0xF0
0000705c0add4a0d  pop r11
0000705c0add4a0f  pop r10
0000705c0add4a11  pop r9
0000705c0add4a13  pop r8
0000705c0add4a15  pop rsi
0000705c0add4a16  pop rdi
0000705c0add4a17  pop rdx
0000705c0add4a18  pop rcx
0000705c0add4a19  pop rax
0000705c0add4a1a  add rsp, 0x08
0000705c0add4a1e  jmp 0x0000705C0ADD2B41
0000705c0add4a23  call 0x0000705C0ABFF430
0000705c0add4a28  jmp 0x0000705C0ADD2B4E
0000705c0add4a2d  sub rsp, 0x08
0000705c0add4a31  push rax
0000705c0add4a32  push rcx
0000705c0add4a33  push rdx
0000705c0add4a34  push rdi
0000705c0add4a35  push rsi
0000705c0add4a36  push r8
0000705c0add4a38  push r9
0000705c0add4a3a  push r10
0000705c0add4a3c  push r11
0000705c0add4a3e  sub rsp, 0xF0
0000705c0add4a45  vmovaps [rsp], xmm0
0000705c0add4a4a  vmovaps [rsp+0x10], xmm1
0000705c0add4a50  vmovaps [rsp+0x20], xmm3
0000705c0add4a56  vmovaps [rsp+0x30], xmm4
0000705c0add4a5c  vmovaps [rsp+0x40], xmm5
0000705c0add4a62  vmovaps [rsp+0x50], xmm6
0000705c0add4a68  vmovaps [rsp+0x60], xmm7
0000705c0add4a6e  vmovaps [rsp+0x70], xmm8
0000705c0add4a74  vmovaps [rsp+0x80], xmm9
0000705c0add4a7d  vmovaps [rsp+0x90], xmm10
0000705c0add4a86  vmovaps [rsp+0xA0], xmm11
0000705c0add4a8f  vmovaps [rsp+0xB0], xmm12
0000705c0add4a98  vmovaps [rsp+0xC0], xmm13
0000705c0add4aa1  vmovaps [rsp+0xD0], xmm14
0000705c0add4aaa  vmovaps [rsp+0xE0], xmm15
0000705c0add4ab3  sub rsp, 0x30
0000705c0add4ab7  movaps [rsp], xmm2
0000705c0add4abb  movaps [rsp+0x10], xmm1
0000705c0add4ac0  movaps [rsp+0x20], xmm14
0000705c0add4ac6  lea rdi, [rsp]
0000705c0add4aca  mov esi, 0x00
0000705c0add4acf  mov rax, 0x5969C28C4530
0000705c0add4ad9  call rax
0000705c0add4adb  movaps xmm2, [rsp]
0000705c0add4adf  add rsp, 0x30
0000705c0add4ae3  vmovaps xmm0, [rsp]
0000705c0add4ae8  vmovaps xmm1, [rsp+0x10]
0000705c0add4aee  vmovaps xmm3, [rsp+0x20]
0000705c0add4af4  vmovaps xmm4, [rsp+0x30]
0000705c0add4afa  vmovaps xmm5, [rsp+0x40]
0000705c0add4b00  vmovaps xmm6, [rsp+0x50]
0000705c0add4b06  vmovaps xmm7, [rsp+0x60]
0000705c0add4b0c  vmovaps xmm8, [rsp+0x70]
0000705c0add4b12  vmovaps xmm9, [rsp+0x80]
0000705c0add4b1b  vmovaps xmm10, [rsp+0x90]
0000705c0add4b24  vmovaps xmm11, [rsp+0xA0]
0000705c0add4b2d  vmovaps xmm12, [rsp+0xB0]
0000705c0add4b36  vmovaps xmm13, [rsp+0xC0]
0000705c0add4b3f  vmovaps xmm14, [rsp+0xD0]
0000705c0add4b48  vmovaps xmm15, [rsp+0xE0]
0000705c0add4b51  add rsp, 0xF0
0000705c0add4b58  pop r11
0000705c0add4b5a  pop r10
0000705c0add4b5c  pop r9
0000705c0add4b5e  pop r8
0000705c0add4b60  pop rsi
0000705c0add4b61  pop rdi
0000705c0add4b62  pop rdx
0000705c0add4b63  pop rcx
0000705c0add4b64  pop rax
0000705c0add4b65  add rsp, 0x08
0000705c0add4b69  jmp 0x0000705C0ADD2B8B
0000705c0add4b6e  sub rsp, 0x08
0000705c0add4b72  push rax
0000705c0add4b73  push rcx
0000705c0add4b74  push rdx
0000705c0add4b75  push rdi
0000705c0add4b76  push rsi
0000705c0add4b77  push r8
0000705c0add4b79  push r9
0000705c0add4b7b  push r10
0000705c0add4b7d  push r11
0000705c0add4b7f  sub rsp, 0xF0
0000705c0add4b86  vmovaps [rsp], xmm0
0000705c0add4b8b  vmovaps [rsp+0x10], xmm1
0000705c0add4b91  vmovaps [rsp+0x20], xmm2
0000705c0add4b97  vmovaps [rsp+0x30], xmm3
0000705c0add4b9d  vmovaps [rsp+0x40], xmm4
0000705c0add4ba3  vmovaps [rsp+0x50], xmm5
0000705c0add4ba9  vmovaps [rsp+0x60], xmm6
0000705c0add4baf  vmovaps [rsp+0x70], xmm7
0000705c0add4bb5  vmovaps [rsp+0x80], xmm8
0000705c0add4bbe  vmovaps [rsp+0x90], xmm9
0000705c0add4bc7  vmovaps [rsp+0xA0], xmm10
0000705c0add4bd0  vmovaps [rsp+0xB0], xmm11
0000705c0add4bd9  vmovaps [rsp+0xC0], xmm12
0000705c0add4be2  vmovaps [rsp+0xD0], xmm13
0000705c0add4beb  vmovaps [rsp+0xE0], xmm14
0000705c0add4bf4  sub rsp, 0x30
0000705c0add4bf8  movaps [rsp], xmm15
0000705c0add4bfd  movaps [rsp+0x10], xmm14
0000705c0add4c03  movaps [rsp+0x20], xmm1
0000705c0add4c08  lea rdi, [rsp]
0000705c0add4c0c  mov esi, 0x00
0000705c0add4c11  mov rax, 0x5969C28C4530
0000705c0add4c1b  call rax
0000705c0add4c1d  movaps xmm15, [rsp]
0000705c0add4c22  add rsp, 0x30
0000705c0add4c26  vmovaps xmm0, [rsp]
0000705c0add4c2b  vmovaps xmm1, [rsp+0x10]
0000705c0add4c31  vmovaps xmm2, [rsp+0x20]
0000705c0add4c37  vmovaps xmm3, [rsp+0x30]
0000705c0add4c3d  vmovaps xmm4, [rsp+0x40]
0000705c0add4c43  vmovaps xmm5, [rsp+0x50]
0000705c0add4c49  vmovaps xmm6, [rsp+0x60]
0000705c0add4c4f  vmovaps xmm7, [rsp+0x70]
0000705c0add4c55  vmovaps xmm8, [rsp+0x80]
0000705c0add4c5e  vmovaps xmm9, [rsp+0x90]
0000705c0add4c67  vmovaps xmm10, [rsp+0xA0]
0000705c0add4c70  vmovaps xmm11, [rsp+0xB0]
0000705c0add4c79  vmovaps xmm12, [rsp+0xC0]
0000705c0add4c82  vmovaps xmm13, [rsp+0xD0]
0000705c0add4c8b  vmovaps xmm14, [rsp+0xE0]
0000705c0add4c94  add rsp, 0xF0
0000705c0add4c9b  pop r11
0000705c0add4c9d  pop r10
0000705c0add4c9f  pop r9
0000705c0add4ca1  pop r8
0000705c0add4ca3  pop rsi
0000705c0add4ca4  pop rdi
0000705c0add4ca5  pop rdx
0000705c0add4ca6  pop rcx
0000705c0add4ca7  pop rax
0000705c0add4ca8  add rsp, 0x08
0000705c0add4cac  jmp 0x0000705C0ADD2C05
0000705c0add4cb1  call 0x0000705C0ABFF430
0000705c0add4cb6  jmp 0x0000705C0ADD2C12
0000705c0add4cbb  sub rsp, 0x08
0000705c0add4cbf  push rax
0000705c0add4cc0  push rcx
0000705c0add4cc1  push rdx
0000705c0add4cc2  push rdi
0000705c0add4cc3  push rsi
0000705c0add4cc4  push r8
0000705c0add4cc6  push r9
0000705c0add4cc8  push r10
0000705c0add4cca  push r11
0000705c0add4ccc  sub rsp, 0xF0
0000705c0add4cd3  vmovaps [rsp], xmm0
0000705c0add4cd8  vmovaps [rsp+0x10], xmm1
0000705c0add4cde  vmovaps [rsp+0x20], xmm2
0000705c0add4ce4  vmovaps [rsp+0x30], xmm3
0000705c0add4cea  vmovaps [rsp+0x40], xmm4
0000705c0add4cf0  vmovaps [rsp+0x50], xmm5
0000705c0add4cf6  vmovaps [rsp+0x60], xmm6
0000705c0add4cfc  vmovaps [rsp+0x70], xmm7
0000705c0add4d02  vmovaps [rsp+0x80], xmm8
0000705c0add4d0b  vmovaps [rsp+0x90], xmm9
0000705c0add4d14  vmovaps [rsp+0xA0], xmm10
0000705c0add4d1d  vmovaps [rsp+0xB0], xmm11
0000705c0add4d26  vmovaps [rsp+0xC0], xmm12
0000705c0add4d2f  vmovaps [rsp+0xD0], xmm14
0000705c0add4d38  vmovaps [rsp+0xE0], xmm15
0000705c0add4d41  sub rsp, 0x30
0000705c0add4d45  movaps [rsp], xmm13
0000705c0add4d4a  movaps [rsp+0x10], xmm1
0000705c0add4d4f  movaps [rsp+0x20], xmm15
0000705c0add4d55  lea rdi, [rsp]
0000705c0add4d59  mov esi, 0x00
0000705c0add4d5e  mov rax, 0x5969C28C4530
0000705c0add4d68  call rax
0000705c0add4d6a  movaps xmm13, [rsp]
0000705c0add4d6f  add rsp, 0x30
0000705c0add4d73  vmovaps xmm0, [rsp]
0000705c0add4d78  vmovaps xmm1, [rsp+0x10]
0000705c0add4d7e  vmovaps xmm2, [rsp+0x20]
0000705c0add4d84  vmovaps xmm3, [rsp+0x30]
0000705c0add4d8a  vmovaps xmm4, [rsp+0x40]
0000705c0add4d90  vmovaps xmm5, [rsp+0x50]
0000705c0add4d96  vmovaps xmm6, [rsp+0x60]
0000705c0add4d9c  vmovaps xmm7, [rsp+0x70]
0000705c0add4da2  vmovaps xmm8, [rsp+0x80]
0000705c0add4dab  vmovaps xmm9, [rsp+0x90]
0000705c0add4db4  vmovaps xmm10, [rsp+0xA0]
0000705c0add4dbd  vmovaps xmm11, [rsp+0xB0]
0000705c0add4dc6  vmovaps xmm12, [rsp+0xC0]
0000705c0add4dcf  vmovaps xmm14, [rsp+0xD0]
0000705c0add4dd8  vmovaps xmm15, [rsp+0xE0]
0000705c0add4de1  add rsp, 0xF0
0000705c0add4de8  pop r11
0000705c0add4dea  pop r10
0000705c0add4dec  pop r9
0000705c0add4dee  pop r8
0000705c0add4df0  pop rsi
0000705c0add4df1  pop rdi
0000705c0add4df2  pop rdx
0000705c0add4df3  pop rcx
0000705c0add4df4  pop rax
0000705c0add4df5  add rsp, 0x08
0000705c0add4df9  jmp 0x0000705C0ADD2CD6
0000705c0add4dfe  sub rsp, 0x08
0000705c0add4e02  push rax
0000705c0add4e03  push rcx
0000705c0add4e04  push rdx
0000705c0add4e05  push rdi
0000705c0add4e06  push rsi
0000705c0add4e07  push r8
0000705c0add4e09  push r9
0000705c0add4e0b  push r10
0000705c0add4e0d  push r11
0000705c0add4e0f  sub rsp, 0xF0
0000705c0add4e16  vmovaps [rsp], xmm0
0000705c0add4e1b  vmovaps [rsp+0x10], xmm1
0000705c0add4e21  vmovaps [rsp+0x20], xmm2
0000705c0add4e27  vmovaps [rsp+0x30], xmm3
0000705c0add4e2d  vmovaps [rsp+0x40], xmm4
0000705c0add4e33  vmovaps [rsp+0x50], xmm5
0000705c0add4e39  vmovaps [rsp+0x60], xmm6
0000705c0add4e3f  vmovaps [rsp+0x70], xmm7
0000705c0add4e45  vmovaps [rsp+0x80], xmm8
0000705c0add4e4e  vmovaps [rsp+0x90], xmm9
0000705c0add4e57  vmovaps [rsp+0xA0], xmm10
0000705c0add4e60  vmovaps [rsp+0xB0], xmm11
0000705c0add4e69  vmovaps [rsp+0xC0], xmm12
0000705c0add4e72  vmovaps [rsp+0xD0], xmm13
0000705c0add4e7b  vmovaps [rsp+0xE0], xmm14
0000705c0add4e84  sub rsp, 0x30
0000705c0add4e88  movaps [rsp], xmm15
0000705c0add4e8d  movaps [rsp+0x10], xmm14
0000705c0add4e93  movaps [rsp+0x20], xmm1
0000705c0add4e98  lea rdi, [rsp]
0000705c0add4e9c  mov esi, 0x00
0000705c0add4ea1  mov rax, 0x5969C28C4530
0000705c0add4eab  call rax
0000705c0add4ead  movaps xmm15, [rsp]
0000705c0add4eb2  add rsp, 0x30
0000705c0add4eb6  vmovaps xmm0, [rsp]
0000705c0add4ebb  vmovaps xmm1, [rsp+0x10]
0000705c0add4ec1  vmovaps xmm2, [rsp+0x20]
0000705c0add4ec7  vmovaps xmm3, [rsp+0x30]
0000705c0add4ecd  vmovaps xmm4, [rsp+0x40]
0000705c0add4ed3  vmovaps xmm5, [rsp+0x50]
0000705c0add4ed9  vmovaps xmm6, [rsp+0x60]
0000705c0add4edf  vmovaps xmm7, [rsp+0x70]
0000705c0add4ee5  vmovaps xmm8, [rsp+0x80]
0000705c0add4eee  vmovaps xmm9, [rsp+0x90]
0000705c0add4ef7  vmovaps xmm10, [rsp+0xA0]
0000705c0add4f00  vmovaps xmm11, [rsp+0xB0]
0000705c0add4f09  vmovaps xmm12, [rsp+0xC0]
0000705c0add4f12  vmovaps xmm13, [rsp+0xD0]
0000705c0add4f1b  vmovaps xmm14, [rsp+0xE0]
0000705c0add4f24  add rsp, 0xF0
0000705c0add4f2b  pop r11
0000705c0add4f2d  pop r10
0000705c0add4f2f  pop r9
0000705c0add4f31  pop r8
0000705c0add4f33  pop rsi
0000705c0add4f34  pop rdi
0000705c0add4f35  pop rdx
0000705c0add4f36  pop rcx
0000705c0add4f37  pop rax
0000705c0add4f38  add rsp, 0x08
0000705c0add4f3c  jmp 0x0000705C0ADD2D12
0000705c0add4f41  call 0x0000705C0ABFF430
0000705c0add4f46  jmp 0x0000705C0ADD2D1F
0000705c0add4f4b  sub rsp, 0x08
0000705c0add4f4f  push rax
0000705c0add4f50  push rcx
0000705c0add4f51  push rdx
0000705c0add4f52  push rdi
0000705c0add4f53  push rsi
0000705c0add4f54  push r8
0000705c0add4f56  push r9
0000705c0add4f58  push r10
0000705c0add4f5a  push r11
0000705c0add4f5c  sub rsp, 0xF0
0000705c0add4f63  vmovaps [rsp], xmm0
0000705c0add4f68  vmovaps [rsp+0x10], xmm1
0000705c0add4f6e  vmovaps [rsp+0x20], xmm2
0000705c0add4f74  vmovaps [rsp+0x30], xmm3
0000705c0add4f7a  vmovaps [rsp+0x40], xmm4
0000705c0add4f80  vmovaps [rsp+0x50], xmm5
0000705c0add4f86  vmovaps [rsp+0x60], xmm6
0000705c0add4f8c  vmovaps [rsp+0x70], xmm7
0000705c0add4f92  vmovaps [rsp+0x80], xmm8
0000705c0add4f9b  vmovaps [rsp+0x90], xmm9
0000705c0add4fa4  vmovaps [rsp+0xA0], xmm10
0000705c0add4fad  vmovaps [rsp+0xB0], xmm11
0000705c0add4fb6  vmovaps [rsp+0xC0], xmm12
0000705c0add4fbf  vmovaps [rsp+0xD0], xmm13
0000705c0add4fc8  vmovaps [rsp+0xE0], xmm15
0000705c0add4fd1  sub rsp, 0x30
0000705c0add4fd5  movaps [rsp], xmm14
0000705c0add4fda  movaps [rsp+0x10], xmm13
0000705c0add4fe0  movaps [rsp+0x20], xmm2
0000705c0add4fe5  lea rdi, [rsp]
0000705c0add4fe9  mov esi, 0x00
0000705c0add4fee  mov rax, 0x5969C28C4530
0000705c0add4ff8  call rax
0000705c0add4ffa  movaps xmm14, [rsp]
0000705c0add4fff  add rsp, 0x30
0000705c0add5003  vmovaps xmm0, [rsp]
0000705c0add5008  vmovaps xmm1, [rsp+0x10]
0000705c0add500e  vmovaps xmm2, [rsp+0x20]
0000705c0add5014  vmovaps xmm3, [rsp+0x30]
0000705c0add501a  vmovaps xmm4, [rsp+0x40]
0000705c0add5020  vmovaps xmm5, [rsp+0x50]
0000705c0add5026  vmovaps xmm6, [rsp+0x60]
0000705c0add502c  vmovaps xmm7, [rsp+0x70]
0000705c0add5032  vmovaps xmm8, [rsp+0x80]
0000705c0add503b  vmovaps xmm9, [rsp+0x90]
0000705c0add5044  vmovaps xmm10, [rsp+0xA0]
0000705c0add504d  vmovaps xmm11, [rsp+0xB0]
0000705c0add5056  vmovaps xmm12, [rsp+0xC0]
0000705c0add505f  vmovaps xmm13, [rsp+0xD0]
0000705c0add5068  vmovaps xmm15, [rsp+0xE0]
0000705c0add5071  add rsp, 0xF0
0000705c0add5078  pop r11
0000705c0add507a  pop r10
0000705c0add507c  pop r9
0000705c0add507e  pop r8
0000705c0add5080  pop rsi
0000705c0add5081  pop rdi
0000705c0add5082  pop rdx
0000705c0add5083  pop rcx
0000705c0add5084  pop rax
0000705c0add5085  add rsp, 0x08
0000705c0add5089  jmp 0x0000705C0ADD2D4B
0000705c0add508e  sub rsp, 0x08
0000705c0add5092  push rax
0000705c0add5093  push rcx
0000705c0add5094  push rdx
0000705c0add5095  push rdi
0000705c0add5096  push rsi
0000705c0add5097  push r8
0000705c0add5099  push r9
0000705c0add509b  push r10
0000705c0add509d  push r11
0000705c0add509f  sub rsp, 0xF0
0000705c0add50a6  vmovaps [rsp], xmm0
0000705c0add50ab  vmovaps [rsp+0x10], xmm2
0000705c0add50b1  vmovaps [rsp+0x20], xmm3
0000705c0add50b7  vmovaps [rsp+0x30], xmm4
0000705c0add50bd  vmovaps [rsp+0x40], xmm5
0000705c0add50c3  vmovaps [rsp+0x50], xmm6
0000705c0add50c9  vmovaps [rsp+0x60], xmm7
0000705c0add50cf  vmovaps [rsp+0x70], xmm8
0000705c0add50d5  vmovaps [rsp+0x80], xmm9
0000705c0add50de  vmovaps [rsp+0x90], xmm10
0000705c0add50e7  vmovaps [rsp+0xA0], xmm11
0000705c0add50f0  vmovaps [rsp+0xB0], xmm12
0000705c0add50f9  vmovaps [rsp+0xC0], xmm13
0000705c0add5102  vmovaps [rsp+0xD0], xmm14
0000705c0add510b  vmovaps [rsp+0xE0], xmm15
0000705c0add5114  sub rsp, 0x30
0000705c0add5118  movaps [rsp], xmm1
0000705c0add511c  movaps [rsp+0x10], xmm13
0000705c0add5122  movaps [rsp+0x20], xmm2
0000705c0add5127  lea rdi, [rsp]
0000705c0add512b  mov esi, 0x00
0000705c0add5130  mov rax, 0x5969C28C4530
0000705c0add513a  call rax
0000705c0add513c  movaps xmm1, [rsp]
0000705c0add5140  add rsp, 0x30
0000705c0add5144  vmovaps xmm0, [rsp]
0000705c0add5149  vmovaps xmm2, [rsp+0x10]
0000705c0add514f  vmovaps xmm3, [rsp+0x20]
0000705c0add5155  vmovaps xmm4, [rsp+0x30]
0000705c0add515b  vmovaps xmm5, [rsp+0x40]
0000705c0add5161  vmovaps xmm6, [rsp+0x50]
0000705c0add5167  vmovaps xmm7, [rsp+0x60]
0000705c0add516d  vmovaps xmm8, [rsp+0x70]
0000705c0add5173  vmovaps xmm9, [rsp+0x80]
0000705c0add517c  vmovaps xmm10, [rsp+0x90]
0000705c0add5185  vmovaps xmm11, [rsp+0xA0]
0000705c0add518e  vmovaps xmm12, [rsp+0xB0]
0000705c0add5197  vmovaps xmm13, [rsp+0xC0]
0000705c0add51a0  vmovaps xmm14, [rsp+0xD0]
0000705c0add51a9  vmovaps xmm15, [rsp+0xE0]
0000705c0add51b2  add rsp, 0xF0
0000705c0add51b9  pop r11
0000705c0add51bb  pop r10
0000705c0add51bd  pop r9
0000705c0add51bf  pop r8
0000705c0add51c1  pop rsi
0000705c0add51c2  pop rdi
0000705c0add51c3  pop rdx
0000705c0add51c4  pop rcx
0000705c0add51c5  pop rax
0000705c0add51c6  add rsp, 0x08
0000705c0add51ca  jmp 0x0000705C0ADD2D79
0000705c0add51cf  sub rsp, 0x08
0000705c0add51d3  push rax
0000705c0add51d4  push rcx
0000705c0add51d5  push rdx
0000705c0add51d6  push rdi
0000705c0add51d7  push rsi
0000705c0add51d8  push r8
0000705c0add51da  push r9
0000705c0add51dc  push r10
0000705c0add51de  push r11
0000705c0add51e0  sub rsp, 0xF0
0000705c0add51e7  vmovaps [rsp], xmm0
0000705c0add51ec  vmovaps [rsp+0x10], xmm1
0000705c0add51f2  vmovaps [rsp+0x20], xmm3
0000705c0add51f8  vmovaps [rsp+0x30], xmm4
0000705c0add51fe  vmovaps [rsp+0x40], xmm5
0000705c0add5204  vmovaps [rsp+0x50], xmm6
0000705c0add520a  vmovaps [rsp+0x60], xmm7
0000705c0add5210  vmovaps [rsp+0x70], xmm8
0000705c0add5216  vmovaps [rsp+0x80], xmm9
0000705c0add521f  vmovaps [rsp+0x90], xmm10
0000705c0add5228  vmovaps [rsp+0xA0], xmm11
0000705c0add5231  vmovaps [rsp+0xB0], xmm12
0000705c0add523a  vmovaps [rsp+0xC0], xmm13
0000705c0add5243  vmovaps [rsp+0xD0], xmm14
0000705c0add524c  vmovaps [rsp+0xE0], xmm15
0000705c0add5255  sub rsp, 0x30
0000705c0add5259  movaps [rsp], xmm2
0000705c0add525d  movaps [rsp+0x10], xmm1
0000705c0add5262  movaps [rsp+0x20], xmm13
0000705c0add5268  lea rdi, [rsp]
0000705c0add526c  mov esi, 0x00
0000705c0add5271  mov rax, 0x5969C28C4530
0000705c0add527b  call rax
0000705c0add527d  movaps xmm2, [rsp]
0000705c0add5281  add rsp, 0x30
0000705c0add5285  vmovaps xmm0, [rsp]
0000705c0add528a  vmovaps xmm1, [rsp+0x10]
0000705c0add5290  vmovaps xmm3, [rsp+0x20]
0000705c0add5296  vmovaps xmm4, [rsp+0x30]
0000705c0add529c  vmovaps xmm5, [rsp+0x40]
0000705c0add52a2  vmovaps xmm6, [rsp+0x50]
0000705c0add52a8  vmovaps xmm7, [rsp+0x60]
0000705c0add52ae  vmovaps xmm8, [rsp+0x70]
0000705c0add52b4  vmovaps xmm9, [rsp+0x80]
0000705c0add52bd  vmovaps xmm10, [rsp+0x90]
0000705c0add52c6  vmovaps xmm11, [rsp+0xA0]
0000705c0add52cf  vmovaps xmm12, [rsp+0xB0]
0000705c0add52d8  vmovaps xmm13, [rsp+0xC0]
0000705c0add52e1  vmovaps xmm14, [rsp+0xD0]
0000705c0add52ea  vmovaps xmm15, [rsp+0xE0]
0000705c0add52f3  add rsp, 0xF0
0000705c0add52fa  pop r11
0000705c0add52fc  pop r10
0000705c0add52fe  pop r9
0000705c0add5300  pop r8
0000705c0add5302  pop rsi
0000705c0add5303  pop rdi
0000705c0add5304  pop rdx
0000705c0add5305  pop rcx
0000705c0add5306  pop rax
0000705c0add5307  add rsp, 0x08
0000705c0add530b  jmp 0x0000705C0ADD2DD2
0000705c0add5310  call 0x0000705C0ABFF430
0000705c0add5315  jmp 0x0000705C0ADD2DDF
0000705c0add531a  sub rsp, 0x08
0000705c0add531e  push rax
0000705c0add531f  push rcx
0000705c0add5320  push rdx
0000705c0add5321  push rdi
0000705c0add5322  push rsi
0000705c0add5323  push r8
0000705c0add5325  push r9
0000705c0add5327  push r10
0000705c0add5329  push r11
0000705c0add532b  sub rsp, 0xF0
0000705c0add5332  vmovaps [rsp], xmm0
0000705c0add5337  vmovaps [rsp+0x10], xmm1
0000705c0add533d  vmovaps [rsp+0x20], xmm2
0000705c0add5343  vmovaps [rsp+0x30], xmm3
0000705c0add5349  vmovaps [rsp+0x40], xmm4
0000705c0add534f  vmovaps [rsp+0x50], xmm5
0000705c0add5355  vmovaps [rsp+0x60], xmm6
0000705c0add535b  vmovaps [rsp+0x70], xmm7
0000705c0add5361  vmovaps [rsp+0x80], xmm8
0000705c0add536a  vmovaps [rsp+0x90], xmm9
0000705c0add5373  vmovaps [rsp+0xA0], xmm10
0000705c0add537c  vmovaps [rsp+0xB0], xmm11
0000705c0add5385  vmovaps [rsp+0xC0], xmm12
0000705c0add538e  vmovaps [rsp+0xD0], xmm13
0000705c0add5397  vmovaps [rsp+0xE0], xmm14
0000705c0add53a0  sub rsp, 0x30
0000705c0add53a4  movaps [rsp], xmm15
0000705c0add53a9  movaps [rsp+0x10], xmm13
0000705c0add53af  movaps [rsp+0x20], xmm1
0000705c0add53b4  lea rdi, [rsp]
0000705c0add53b8  mov esi, 0x00
0000705c0add53bd  mov rax, 0x5969C28C4530
0000705c0add53c7  call rax
0000705c0add53c9  movaps xmm15, [rsp]
0000705c0add53ce  add rsp, 0x30
0000705c0add53d2  vmovaps xmm0, [rsp]
0000705c0add53d7  vmovaps xmm1, [rsp+0x10]
0000705c0add53dd  vmovaps xmm2, [rsp+0x20]
0000705c0add53e3  vmovaps xmm3, [rsp+0x30]
0000705c0add53e9  vmovaps xmm4, [rsp+0x40]
0000705c0add53ef  vmovaps xmm5, [rsp+0x50]
0000705c0add53f5  vmovaps xmm6, [rsp+0x60]
0000705c0add53fb  vmovaps xmm7, [rsp+0x70]
0000705c0add5401  vmovaps xmm8, [rsp+0x80]
0000705c0add540a  vmovaps xmm9, [rsp+0x90]
0000705c0add5413  vmovaps xmm10, [rsp+0xA0]
0000705c0add541c  vmovaps xmm11, [rsp+0xB0]
0000705c0add5425  vmovaps xmm12, [rsp+0xC0]
0000705c0add542e  vmovaps xmm13, [rsp+0xD0]
0000705c0add5437  vmovaps xmm14, [rsp+0xE0]
0000705c0add5440  add rsp, 0xF0
0000705c0add5447  pop r11
0000705c0add5449  pop r10
0000705c0add544b  pop r9
0000705c0add544d  pop r8
0000705c0add544f  pop rsi
0000705c0add5450  pop rdi
0000705c0add5451  pop rdx
0000705c0add5452  pop rcx
0000705c0add5453  pop rax
0000705c0add5454  add rsp, 0x08
0000705c0add5458  jmp 0x0000705C0ADD2E1E
0000705c0add545d  sub rsp, 0x08
0000705c0add5461  push rax
0000705c0add5462  push rcx
0000705c0add5463  push rdx
0000705c0add5464  push rdi
0000705c0add5465  push rsi
0000705c0add5466  push r8
0000705c0add5468  push r9
0000705c0add546a  push r10
0000705c0add546c  push r11
0000705c0add546e  sub rsp, 0xF0
0000705c0add5475  vmovaps [rsp], xmm0
0000705c0add547a  vmovaps [rsp+0x10], xmm1
0000705c0add5480  vmovaps [rsp+0x20], xmm2
0000705c0add5486  vmovaps [rsp+0x30], xmm3
0000705c0add548c  vmovaps [rsp+0x40], xmm4
0000705c0add5492  vmovaps [rsp+0x50], xmm5
0000705c0add5498  vmovaps [rsp+0x60], xmm6
0000705c0add549e  vmovaps [rsp+0x70], xmm7
0000705c0add54a4  vmovaps [rsp+0x80], xmm8
0000705c0add54ad  vmovaps [rsp+0x90], xmm9
0000705c0add54b6  vmovaps [rsp+0xA0], xmm10
0000705c0add54bf  vmovaps [rsp+0xB0], xmm11
0000705c0add54c8  vmovaps [rsp+0xC0], xmm12
0000705c0add54d1  vmovaps [rsp+0xD0], xmm13
0000705c0add54da  vmovaps [rsp+0xE0], xmm15
0000705c0add54e3  sub rsp, 0x30
0000705c0add54e7  movaps [rsp], xmm14
0000705c0add54ec  movaps [rsp+0x10], xmm11
0000705c0add54f2  movaps [rsp+0x20], xmm1
0000705c0add54f7  lea rdi, [rsp]
0000705c0add54fb  mov esi, 0x00
0000705c0add5500  mov rax, 0x5969C28C4530
0000705c0add550a  call rax
0000705c0add550c  movaps xmm14, [rsp]
0000705c0add5511  add rsp, 0x30
0000705c0add5515  vmovaps xmm0, [rsp]
0000705c0add551a  vmovaps xmm1, [rsp+0x10]
0000705c0add5520  vmovaps xmm2, [rsp+0x20]
0000705c0add5526  vmovaps xmm3, [rsp+0x30]
0000705c0add552c  vmovaps xmm4, [rsp+0x40]
0000705c0add5532  vmovaps xmm5, [rsp+0x50]
0000705c0add5538  vmovaps xmm6, [rsp+0x60]
0000705c0add553e  vmovaps xmm7, [rsp+0x70]
0000705c0add5544  vmovaps xmm8, [rsp+0x80]
0000705c0add554d  vmovaps xmm9, [rsp+0x90]
0000705c0add5556  vmovaps xmm10, [rsp+0xA0]
0000705c0add555f  vmovaps xmm11, [rsp+0xB0]
0000705c0add5568  vmovaps xmm12, [rsp+0xC0]
0000705c0add5571  vmovaps xmm13, [rsp+0xD0]
0000705c0add557a  vmovaps xmm15, [rsp+0xE0]
0000705c0add5583  add rsp, 0xF0
0000705c0add558a  pop r11
0000705c0add558c  pop r10
0000705c0add558e  pop r9
0000705c0add5590  pop r8
0000705c0add5592  pop rsi
0000705c0add5593  pop rdi
0000705c0add5594  pop rdx
0000705c0add5595  pop rcx
0000705c0add5596  pop rax
0000705c0add5597  add rsp, 0x08
0000705c0add559b  jmp 0x0000705C0ADD2E48
0000705c0add55a0  sub rsp, 0x08
0000705c0add55a4  push rax
0000705c0add55a5  push rcx
0000705c0add55a6  push rdx
0000705c0add55a7  push rdi
0000705c0add55a8  push rsi
0000705c0add55a9  push r8
0000705c0add55ab  push r9
0000705c0add55ad  push r10
0000705c0add55af  push r11
0000705c0add55b1  sub rsp, 0xF0
0000705c0add55b8  vmovaps [rsp], xmm0
0000705c0add55bd  vmovaps [rsp+0x10], xmm1
0000705c0add55c3  vmovaps [rsp+0x20], xmm2
0000705c0add55c9  vmovaps [rsp+0x30], xmm3
0000705c0add55cf  vmovaps [rsp+0x40], xmm4
0000705c0add55d5  vmovaps [rsp+0x50], xmm5
0000705c0add55db  vmovaps [rsp+0x60], xmm6
0000705c0add55e1  vmovaps [rsp+0x70], xmm7
0000705c0add55e7  vmovaps [rsp+0x80], xmm8
0000705c0add55f0  vmovaps [rsp+0x90], xmm9
0000705c0add55f9  vmovaps [rsp+0xA0], xmm10
0000705c0add5602  vmovaps [rsp+0xB0], xmm11
0000705c0add560b  vmovaps [rsp+0xC0], xmm12
0000705c0add5614  vmovaps [rsp+0xD0], xmm14
0000705c0add561d  vmovaps [rsp+0xE0], xmm15
0000705c0add5626  sub rsp, 0x30
0000705c0add562a  movaps [rsp], xmm13
0000705c0add562f  movaps [rsp+0x10], xmm11
0000705c0add5635  movaps [rsp+0x20], xmm1
0000705c0add563a  lea rdi, [rsp]
0000705c0add563e  mov esi, 0x00
0000705c0add5643  mov rax, 0x5969C28C4530
0000705c0add564d  call rax
0000705c0add564f  movaps xmm13, [rsp]
0000705c0add5654  add rsp, 0x30
0000705c0add5658  vmovaps xmm0, [rsp]
0000705c0add565d  vmovaps xmm1, [rsp+0x10]
0000705c0add5663  vmovaps xmm2, [rsp+0x20]
0000705c0add5669  vmovaps xmm3, [rsp+0x30]
0000705c0add566f  vmovaps xmm4, [rsp+0x40]
0000705c0add5675  vmovaps xmm5, [rsp+0x50]
0000705c0add567b  vmovaps xmm6, [rsp+0x60]
0000705c0add5681  vmovaps xmm7, [rsp+0x70]
0000705c0add5687  vmovaps xmm8, [rsp+0x80]
0000705c0add5690  vmovaps xmm9, [rsp+0x90]
0000705c0add5699  vmovaps xmm10, [rsp+0xA0]
0000705c0add56a2  vmovaps xmm11, [rsp+0xB0]
0000705c0add56ab  vmovaps xmm12, [rsp+0xC0]
0000705c0add56b4  vmovaps xmm14, [rsp+0xD0]
0000705c0add56bd  vmovaps xmm15, [rsp+0xE0]
0000705c0add56c6  add rsp, 0xF0
0000705c0add56cd  pop r11
0000705c0add56cf  pop r10
0000705c0add56d1  pop r9
0000705c0add56d3  pop r8
0000705c0add56d5  pop rsi
0000705c0add56d6  pop rdi
0000705c0add56d7  pop rdx
0000705c0add56d8  pop rcx
0000705c0add56d9  pop rax
0000705c0add56da  add rsp, 0x08
0000705c0add56de  jmp 0x0000705C0ADD2E9D
0000705c0add56e3  call 0x0000705C0ABFF430
0000705c0add56e8  jmp 0x0000705C0ADD2EAA
0000705c0add56ed  sub rsp, 0x08
0000705c0add56f1  push rax
0000705c0add56f2  push rcx
0000705c0add56f3  push rdx
0000705c0add56f4  push rdi
0000705c0add56f5  push rsi
0000705c0add56f6  push r8
0000705c0add56f8  push r9
0000705c0add56fa  push r10
0000705c0add56fc  push r11
0000705c0add56fe  sub rsp, 0xF0
0000705c0add5705  vmovaps [rsp], xmm0
0000705c0add570a  vmovaps [rsp+0x10], xmm1
0000705c0add5710  vmovaps [rsp+0x20], xmm2
0000705c0add5716  vmovaps [rsp+0x30], xmm3
0000705c0add571c  vmovaps [rsp+0x40], xmm4
0000705c0add5722  vmovaps [rsp+0x50], xmm5
0000705c0add5728  vmovaps [rsp+0x60], xmm6
0000705c0add572e  vmovaps [rsp+0x70], xmm7
0000705c0add5734  vmovaps [rsp+0x80], xmm8
0000705c0add573d  vmovaps [rsp+0x90], xmm9
0000705c0add5746  vmovaps [rsp+0xA0], xmm10
0000705c0add574f  vmovaps [rsp+0xB0], xmm11
0000705c0add5758  vmovaps [rsp+0xC0], xmm12
0000705c0add5761  vmovaps [rsp+0xD0], xmm13
0000705c0add576a  vmovaps [rsp+0xE0], xmm14
0000705c0add5773  sub rsp, 0x30
0000705c0add5777  movaps [rsp], xmm15
0000705c0add577c  movaps [rsp+0x10], xmm11
0000705c0add5782  movaps [rsp+0x20], xmm1
0000705c0add5787  lea rdi, [rsp]
0000705c0add578b  mov esi, 0x00
0000705c0add5790  mov rax, 0x5969C28C4530
0000705c0add579a  call rax
0000705c0add579c  movaps xmm15, [rsp]
0000705c0add57a1  add rsp, 0x30
0000705c0add57a5  vmovaps xmm0, [rsp]
0000705c0add57aa  vmovaps xmm1, [rsp+0x10]
0000705c0add57b0  vmovaps xmm2, [rsp+0x20]
0000705c0add57b6  vmovaps xmm3, [rsp+0x30]
0000705c0add57bc  vmovaps xmm4, [rsp+0x40]
0000705c0add57c2  vmovaps xmm5, [rsp+0x50]
0000705c0add57c8  vmovaps xmm6, [rsp+0x60]
0000705c0add57ce  vmovaps xmm7, [rsp+0x70]
0000705c0add57d4  vmovaps xmm8, [rsp+0x80]
0000705c0add57dd  vmovaps xmm9, [rsp+0x90]
0000705c0add57e6  vmovaps xmm10, [rsp+0xA0]
0000705c0add57ef  vmovaps xmm11, [rsp+0xB0]
0000705c0add57f8  vmovaps xmm12, [rsp+0xC0]
0000705c0add5801  vmovaps xmm13, [rsp+0xD0]
0000705c0add580a  vmovaps xmm14, [rsp+0xE0]
0000705c0add5813  add rsp, 0xF0
0000705c0add581a  pop r11
0000705c0add581c  pop r10
0000705c0add581e  pop r9
0000705c0add5820  pop r8
0000705c0add5822  pop rsi
0000705c0add5823  pop rdi
0000705c0add5824  pop rdx
0000705c0add5825  pop rcx
0000705c0add5826  pop rax
0000705c0add5827  add rsp, 0x08
0000705c0add582b  jmp 0x0000705C0ADD2EE3
0000705c0add5830  sub rsp, 0x08
0000705c0add5834  push rax
0000705c0add5835  push rcx
0000705c0add5836  push rdx
0000705c0add5837  push rdi
0000705c0add5838  push rsi
0000705c0add5839  push r8
0000705c0add583b  push r9
0000705c0add583d  push r10
0000705c0add583f  push r11
0000705c0add5841  sub rsp, 0xF0
0000705c0add5848  vmovaps [rsp], xmm0
0000705c0add584d  vmovaps [rsp+0x10], xmm1
0000705c0add5853  vmovaps [rsp+0x20], xmm2
0000705c0add5859  vmovaps [rsp+0x30], xmm3
0000705c0add585f  vmovaps [rsp+0x40], xmm4
0000705c0add5865  vmovaps [rsp+0x50], xmm5
0000705c0add586b  vmovaps [rsp+0x60], xmm6
0000705c0add5871  vmovaps [rsp+0x70], xmm7
0000705c0add5877  vmovaps [rsp+0x80], xmm8
0000705c0add5880  vmovaps [rsp+0x90], xmm9
0000705c0add5889  vmovaps [rsp+0xA0], xmm10
0000705c0add5892  vmovaps [rsp+0xB0], xmm12
0000705c0add589b  vmovaps [rsp+0xC0], xmm13
0000705c0add58a4  vmovaps [rsp+0xD0], xmm14
0000705c0add58ad  vmovaps [rsp+0xE0], xmm15
0000705c0add58b6  sub rsp, 0x30
0000705c0add58ba  movaps [rsp], xmm11
0000705c0add58bf  movaps [rsp+0x10], xmm6
0000705c0add58c4  movaps [rsp+0x20], xmm14
0000705c0add58ca  lea rdi, [rsp]
0000705c0add58ce  mov esi, 0x00
0000705c0add58d3  mov rax, 0x5969C28C4530
0000705c0add58dd  call rax
0000705c0add58df  movaps xmm11, [rsp]
0000705c0add58e4  add rsp, 0x30
0000705c0add58e8  vmovaps xmm0, [rsp]
0000705c0add58ed  vmovaps xmm1, [rsp+0x10]
0000705c0add58f3  vmovaps xmm2, [rsp+0x20]
0000705c0add58f9  vmovaps xmm3, [rsp+0x30]
0000705c0add58ff  vmovaps xmm4, [rsp+0x40]
0000705c0add5905  vmovaps xmm5, [rsp+0x50]
0000705c0add590b  vmovaps xmm6, [rsp+0x60]
0000705c0add5911  vmovaps xmm7, [rsp+0x70]
0000705c0add5917  vmovaps xmm8, [rsp+0x80]
0000705c0add5920  vmovaps xmm9, [rsp+0x90]
0000705c0add5929  vmovaps xmm10, [rsp+0xA0]
0000705c0add5932  vmovaps xmm12, [rsp+0xB0]
0000705c0add593b  vmovaps xmm13, [rsp+0xC0]
0000705c0add5944  vmovaps xmm14, [rsp+0xD0]
0000705c0add594d  vmovaps xmm15, [rsp+0xE0]
0000705c0add5956  add rsp, 0xF0
0000705c0add595d  pop r11
0000705c0add595f  pop r10
0000705c0add5961  pop r9
0000705c0add5963  pop r8
0000705c0add5965  pop rsi
0000705c0add5966  pop rdi
0000705c0add5967  pop rdx
0000705c0add5968  pop rcx
0000705c0add5969  pop rax
0000705c0add596a  add rsp, 0x08
0000705c0add596e  jmp 0x0000705C0ADD2F5B
0000705c0add5973  call 0x0000705C0ABFF430
0000705c0add5978  jmp 0x0000705C0ADD2F65
0000705c0add597d  sub rsp, 0x08
0000705c0add5981  push rax
0000705c0add5982  push rcx
0000705c0add5983  push rdx
0000705c0add5984  push rdi
0000705c0add5985  push rsi
0000705c0add5986  push r8
0000705c0add5988  push r9
0000705c0add598a  push r10
0000705c0add598c  push r11
0000705c0add598e  sub rsp, 0xF0
0000705c0add5995  vmovaps [rsp], xmm0
0000705c0add599a  vmovaps [rsp+0x10], xmm1
0000705c0add59a0  vmovaps [rsp+0x20], xmm2
0000705c0add59a6  vmovaps [rsp+0x30], xmm3
0000705c0add59ac  vmovaps [rsp+0x40], xmm4
0000705c0add59b2  vmovaps [rsp+0x50], xmm5
0000705c0add59b8  vmovaps [rsp+0x60], xmm6
0000705c0add59be  vmovaps [rsp+0x70], xmm7
0000705c0add59c4  vmovaps [rsp+0x80], xmm8
0000705c0add59cd  vmovaps [rsp+0x90], xmm9
0000705c0add59d6  vmovaps [rsp+0xA0], xmm10
0000705c0add59df  vmovaps [rsp+0xB0], xmm11
0000705c0add59e8  vmovaps [rsp+0xC0], xmm12
0000705c0add59f1  vmovaps [rsp+0xD0], xmm13
0000705c0add59fa  vmovaps [rsp+0xE0], xmm15
0000705c0add5a03  sub rsp, 0x30
0000705c0add5a07  movaps [rsp], xmm14
0000705c0add5a0c  movaps [rsp+0x10], xmm6
0000705c0add5a11  movaps [rsp+0x20], xmm2
0000705c0add5a16  lea rdi, [rsp]
0000705c0add5a1a  mov esi, 0x00
0000705c0add5a1f  mov rax, 0x5969C28C4530
0000705c0add5a29  call rax
0000705c0add5a2b  movaps xmm14, [rsp]
0000705c0add5a30  add rsp, 0x30
0000705c0add5a34  vmovaps xmm0, [rsp]
0000705c0add5a39  vmovaps xmm1, [rsp+0x10]
0000705c0add5a3f  vmovaps xmm2, [rsp+0x20]
0000705c0add5a45  vmovaps xmm3, [rsp+0x30]
0000705c0add5a4b  vmovaps xmm4, [rsp+0x40]
0000705c0add5a51  vmovaps xmm5, [rsp+0x50]
0000705c0add5a57  vmovaps xmm6, [rsp+0x60]
0000705c0add5a5d  vmovaps xmm7, [rsp+0x70]
0000705c0add5a63  vmovaps xmm8, [rsp+0x80]
0000705c0add5a6c  vmovaps xmm9, [rsp+0x90]
0000705c0add5a75  vmovaps xmm10, [rsp+0xA0]
0000705c0add5a7e  vmovaps xmm11, [rsp+0xB0]
0000705c0add5a87  vmovaps xmm12, [rsp+0xC0]
0000705c0add5a90  vmovaps xmm13, [rsp+0xD0]
0000705c0add5a99  vmovaps xmm15, [rsp+0xE0]
0000705c0add5aa2  add rsp, 0xF0
0000705c0add5aa9  pop r11
0000705c0add5aab  pop r10
0000705c0add5aad  pop r9
0000705c0add5aaf  pop r8
0000705c0add5ab1  pop rsi
0000705c0add5ab2  pop rdi
0000705c0add5ab3  pop rdx
0000705c0add5ab4  pop rcx
0000705c0add5ab5  pop rax
0000705c0add5ab6  add rsp, 0x08
0000705c0add5aba  jmp 0x0000705C0ADD2F99
0000705c0add5abf  sub rsp, 0x08
0000705c0add5ac3  push rax
0000705c0add5ac4  push rcx
0000705c0add5ac5  push rdx
0000705c0add5ac6  push rdi
0000705c0add5ac7  push rsi
0000705c0add5ac8  push r8
0000705c0add5aca  push r9
0000705c0add5acc  push r10
0000705c0add5ace  push r11
0000705c0add5ad0  sub rsp, 0xF0
0000705c0add5ad7  vmovaps [rsp], xmm0
0000705c0add5adc  vmovaps [rsp+0x10], xmm1
0000705c0add5ae2  vmovaps [rsp+0x20], xmm2
0000705c0add5ae8  vmovaps [rsp+0x30], xmm3
0000705c0add5aee  vmovaps [rsp+0x40], xmm4
0000705c0add5af4  vmovaps [rsp+0x50], xmm5
0000705c0add5afa  vmovaps [rsp+0x60], xmm7
0000705c0add5b00  vmovaps [rsp+0x70], xmm8
0000705c0add5b06  vmovaps [rsp+0x80], xmm9
0000705c0add5b0f  vmovaps [rsp+0x90], xmm10
0000705c0add5b18  vmovaps [rsp+0xA0], xmm11
0000705c0add5b21  vmovaps [rsp+0xB0], xmm12
0000705c0add5b2a  vmovaps [rsp+0xC0], xmm13
0000705c0add5b33  vmovaps [rsp+0xD0], xmm14
0000705c0add5b3c  vmovaps [rsp+0xE0], xmm15
0000705c0add5b45  sub rsp, 0x30
0000705c0add5b49  movaps [rsp], xmm6
0000705c0add5b4d  movaps [rsp+0x10], xmm5
0000705c0add5b52  movaps [rsp+0x20], xmm1
0000705c0add5b57  lea rdi, [rsp]
0000705c0add5b5b  mov esi, 0x00
0000705c0add5b60  mov rax, 0x5969C28C4530
0000705c0add5b6a  call rax
0000705c0add5b6c  movaps xmm6, [rsp]
0000705c0add5b70  add rsp, 0x30
0000705c0add5b74  vmovaps xmm0, [rsp]
0000705c0add5b79  vmovaps xmm1, [rsp+0x10]
0000705c0add5b7f  vmovaps xmm2, [rsp+0x20]
0000705c0add5b85  vmovaps xmm3, [rsp+0x30]
0000705c0add5b8b  vmovaps xmm4, [rsp+0x40]
0000705c0add5b91  vmovaps xmm5, [rsp+0x50]
0000705c0add5b97  vmovaps xmm7, [rsp+0x60]
0000705c0add5b9d  vmovaps xmm8, [rsp+0x70]
0000705c0add5ba3  vmovaps xmm9, [rsp+0x80]
0000705c0add5bac  vmovaps xmm10, [rsp+0x90]
0000705c0add5bb5  vmovaps xmm11, [rsp+0xA0]
0000705c0add5bbe  vmovaps xmm12, [rsp+0xB0]
0000705c0add5bc7  vmovaps xmm13, [rsp+0xC0]
0000705c0add5bd0  vmovaps xmm14, [rsp+0xD0]
0000705c0add5bd9  vmovaps xmm15, [rsp+0xE0]
0000705c0add5be2  add rsp, 0xF0
0000705c0add5be9  pop r11
0000705c0add5beb  pop r10
0000705c0add5bed  pop r9
0000705c0add5bef  pop r8
0000705c0add5bf1  pop rsi
0000705c0add5bf2  pop rdi
0000705c0add5bf3  pop rdx
0000705c0add5bf4  pop rcx
0000705c0add5bf5  pop rax
0000705c0add5bf6  add rsp, 0x08
0000705c0add5bfa  jmp 0x0000705C0ADD2FBF
0000705c0add5bff  sub rsp, 0x08
0000705c0add5c03  push rax
0000705c0add5c04  push rcx
0000705c0add5c05  push rdx
0000705c0add5c06  push rdi
0000705c0add5c07  push rsi
0000705c0add5c08  push r8
0000705c0add5c0a  push r9
0000705c0add5c0c  push r10
0000705c0add5c0e  push r11
0000705c0add5c10  sub rsp, 0xF0
0000705c0add5c17  vmovaps [rsp], xmm0
0000705c0add5c1c  vmovaps [rsp+0x10], xmm2
0000705c0add5c22  vmovaps [rsp+0x20], xmm3
0000705c0add5c28  vmovaps [rsp+0x30], xmm4
0000705c0add5c2e  vmovaps [rsp+0x40], xmm5
0000705c0add5c34  vmovaps [rsp+0x50], xmm6
0000705c0add5c3a  vmovaps [rsp+0x60], xmm7
0000705c0add5c40  vmovaps [rsp+0x70], xmm8
0000705c0add5c46  vmovaps [rsp+0x80], xmm9
0000705c0add5c4f  vmovaps [rsp+0x90], xmm10
0000705c0add5c58  vmovaps [rsp+0xA0], xmm11
0000705c0add5c61  vmovaps [rsp+0xB0], xmm12
0000705c0add5c6a  vmovaps [rsp+0xC0], xmm13
0000705c0add5c73  vmovaps [rsp+0xD0], xmm14
0000705c0add5c7c  vmovaps [rsp+0xE0], xmm15
0000705c0add5c85  sub rsp, 0x30
0000705c0add5c89  movaps [rsp], xmm1
0000705c0add5c8d  movaps [rsp+0x10], xmm5
0000705c0add5c92  movaps [rsp+0x20], xmm13
0000705c0add5c98  lea rdi, [rsp]
0000705c0add5c9c  mov esi, 0x00
0000705c0add5ca1  mov rax, 0x5969C28C4530
0000705c0add5cab  call rax
0000705c0add5cad  movaps xmm1, [rsp]
0000705c0add5cb1  add rsp, 0x30
0000705c0add5cb5  vmovaps xmm0, [rsp]
0000705c0add5cba  vmovaps xmm2, [rsp+0x10]
0000705c0add5cc0  vmovaps xmm3, [rsp+0x20]
0000705c0add5cc6  vmovaps xmm4, [rsp+0x30]
0000705c0add5ccc  vmovaps xmm5, [rsp+0x40]
0000705c0add5cd2  vmovaps xmm6, [rsp+0x50]
0000705c0add5cd8  vmovaps xmm7, [rsp+0x60]
0000705c0add5cde  vmovaps xmm8, [rsp+0x70]
0000705c0add5ce4  vmovaps xmm9, [rsp+0x80]
0000705c0add5ced  vmovaps xmm10, [rsp+0x90]
0000705c0add5cf6  vmovaps xmm11, [rsp+0xA0]
0000705c0add5cff  vmovaps xmm12, [rsp+0xB0]
0000705c0add5d08  vmovaps xmm13, [rsp+0xC0]
0000705c0add5d11  vmovaps xmm14, [rsp+0xD0]
0000705c0add5d1a  vmovaps xmm15, [rsp+0xE0]
0000705c0add5d23  add rsp, 0xF0
0000705c0add5d2a  pop r11
0000705c0add5d2c  pop r10
0000705c0add5d2e  pop r9
0000705c0add5d30  pop r8
0000705c0add5d32  pop rsi
0000705c0add5d33  pop rdi
0000705c0add5d34  pop rdx
0000705c0add5d35  pop rcx
0000705c0add5d36  pop rax
0000705c0add5d37  add rsp, 0x08
0000705c0add5d3b  jmp 0x0000705C0ADD2FDD
0000705c0add5d40  sub rsp, 0x08
0000705c0add5d44  push rax
0000705c0add5d45  push rcx
0000705c0add5d46  push rdx
0000705c0add5d47  push rdi
0000705c0add5d48  push rsi
0000705c0add5d49  push r8
0000705c0add5d4b  push r9
0000705c0add5d4d  push r10
0000705c0add5d4f  push r11
0000705c0add5d51  sub rsp, 0xF0
0000705c0add5d58  vmovaps [rsp], xmm0
0000705c0add5d5d  vmovaps [rsp+0x10], xmm1
0000705c0add5d63  vmovaps [rsp+0x20], xmm2
0000705c0add5d69  vmovaps [rsp+0x30], xmm3
0000705c0add5d6f  vmovaps [rsp+0x40], xmm4
0000705c0add5d75  vmovaps [rsp+0x50], xmm6
0000705c0add5d7b  vmovaps [rsp+0x60], xmm7
0000705c0add5d81  vmovaps [rsp+0x70], xmm8
0000705c0add5d87  vmovaps [rsp+0x80], xmm9
0000705c0add5d90  vmovaps [rsp+0x90], xmm10
0000705c0add5d99  vmovaps [rsp+0xA0], xmm11
0000705c0add5da2  vmovaps [rsp+0xB0], xmm12
0000705c0add5dab  vmovaps [rsp+0xC0], xmm13
0000705c0add5db4  vmovaps [rsp+0xD0], xmm14
0000705c0add5dbd  vmovaps [rsp+0xE0], xmm15
0000705c0add5dc6  sub rsp, 0x30
0000705c0add5dca  movaps [rsp], xmm5
0000705c0add5dce  movaps [rsp+0x10], xmm2
0000705c0add5dd3  movaps [rsp+0x20], xmm13
0000705c0add5dd9  lea rdi, [rsp]
0000705c0add5ddd  mov esi, 0x00
0000705c0add5de2  mov rax, 0x5969C28C4530
0000705c0add5dec  call rax
0000705c0add5dee  movaps xmm5, [rsp]
0000705c0add5df2  add rsp, 0x30
0000705c0add5df6  vmovaps xmm0, [rsp]
0000705c0add5dfb  vmovaps xmm1, [rsp+0x10]
0000705c0add5e01  vmovaps xmm2, [rsp+0x20]
0000705c0add5e07  vmovaps xmm3, [rsp+0x30]
0000705c0add5e0d  vmovaps xmm4, [rsp+0x40]
0000705c0add5e13  vmovaps xmm6, [rsp+0x50]
0000705c0add5e19  vmovaps xmm7, [rsp+0x60]
0000705c0add5e1f  vmovaps xmm8, [rsp+0x70]
0000705c0add5e25  vmovaps xmm9, [rsp+0x80]
0000705c0add5e2e  vmovaps xmm10, [rsp+0x90]
0000705c0add5e37  vmovaps xmm11, [rsp+0xA0]
0000705c0add5e40  vmovaps xmm12, [rsp+0xB0]
0000705c0add5e49  vmovaps xmm13, [rsp+0xC0]
0000705c0add5e52  vmovaps xmm14, [rsp+0xD0]
0000705c0add5e5b  vmovaps xmm15, [rsp+0xE0]
0000705c0add5e64  add rsp, 0xF0
0000705c0add5e6b  pop r11
0000705c0add5e6d  pop r10
0000705c0add5e6f  pop r9
0000705c0add5e71  pop r8
0000705c0add5e73  pop rsi
0000705c0add5e74  pop rdi
0000705c0add5e75  pop rdx
0000705c0add5e76  pop rcx
0000705c0add5e77  pop rax
0000705c0add5e78  add rsp, 0x08
0000705c0add5e7c  jmp 0x0000705C0ADD3013
0000705c0add5e81  sub rsp, 0x08
0000705c0add5e85  push rax
0000705c0add5e86  push rcx
0000705c0add5e87  push rdx
0000705c0add5e88  push rdi
0000705c0add5e89  push rsi
0000705c0add5e8a  push r8
0000705c0add5e8c  push r9
0000705c0add5e8e  push r10
0000705c0add5e90  push r11
0000705c0add5e92  sub rsp, 0xF0
0000705c0add5e99  vmovaps [rsp], xmm0
0000705c0add5e9e  vmovaps [rsp+0x10], xmm1
0000705c0add5ea4  vmovaps [rsp+0x20], xmm2
0000705c0add5eaa  vmovaps [rsp+0x30], xmm3
0000705c0add5eb0  vmovaps [rsp+0x40], xmm4
0000705c0add5eb6  vmovaps [rsp+0x50], xmm5
0000705c0add5ebc  vmovaps [rsp+0x60], xmm6
0000705c0add5ec2  vmovaps [rsp+0x70], xmm7
0000705c0add5ec8  vmovaps [rsp+0x80], xmm8
0000705c0add5ed1  vmovaps [rsp+0x90], xmm9
0000705c0add5eda  vmovaps [rsp+0xA0], xmm10
0000705c0add5ee3  vmovaps [rsp+0xB0], xmm11
0000705c0add5eec  vmovaps [rsp+0xC0], xmm12
0000705c0add5ef5  vmovaps [rsp+0xD0], xmm14
0000705c0add5efe  vmovaps [rsp+0xE0], xmm15
0000705c0add5f07  sub rsp, 0x30
0000705c0add5f0b  movaps [rsp], xmm13
0000705c0add5f10  movaps [rsp+0x10], xmm10
0000705c0add5f16  movaps [rsp+0x20], xmm1
0000705c0add5f1b  lea rdi, [rsp]
0000705c0add5f1f  mov esi, 0x00
0000705c0add5f24  mov rax, 0x5969C28C4530
0000705c0add5f2e  call rax
0000705c0add5f30  movaps xmm13, [rsp]
0000705c0add5f35  add rsp, 0x30
0000705c0add5f39  vmovaps xmm0, [rsp]
0000705c0add5f3e  vmovaps xmm1, [rsp+0x10]
0000705c0add5f44  vmovaps xmm2, [rsp+0x20]
0000705c0add5f4a  vmovaps xmm3, [rsp+0x30]
0000705c0add5f50  vmovaps xmm4, [rsp+0x40]
0000705c0add5f56  vmovaps xmm5, [rsp+0x50]
0000705c0add5f5c  vmovaps xmm6, [rsp+0x60]
0000705c0add5f62  vmovaps xmm7, [rsp+0x70]
0000705c0add5f68  vmovaps xmm8, [rsp+0x80]
0000705c0add5f71  vmovaps xmm9, [rsp+0x90]
0000705c0add5f7a  vmovaps xmm10, [rsp+0xA0]
0000705c0add5f83  vmovaps xmm11, [rsp+0xB0]
0000705c0add5f8c  vmovaps xmm12, [rsp+0xC0]
0000705c0add5f95  vmovaps xmm14, [rsp+0xD0]
0000705c0add5f9e  vmovaps xmm15, [rsp+0xE0]
0000705c0add5fa7  add rsp, 0xF0
0000705c0add5fae  pop r11
0000705c0add5fb0  pop r10
0000705c0add5fb2  pop r9
0000705c0add5fb4  pop r8
0000705c0add5fb6  pop rsi
0000705c0add5fb7  pop rdi
0000705c0add5fb8  pop rdx
0000705c0add5fb9  pop rcx
0000705c0add5fba  pop rax
0000705c0add5fbb  add rsp, 0x08
0000705c0add5fbf  jmp 0x0000705C0ADD303C
0000705c0add5fc4  sub rsp, 0x08
0000705c0add5fc8  push rax
0000705c0add5fc9  push rcx
0000705c0add5fca  push rdx
0000705c0add5fcb  push rdi
0000705c0add5fcc  push rsi
0000705c0add5fcd  push r8
0000705c0add5fcf  push r9
0000705c0add5fd1  push r10
0000705c0add5fd3  push r11
0000705c0add5fd5  sub rsp, 0xF0
0000705c0add5fdc  vmovaps [rsp], xmm0
0000705c0add5fe1  vmovaps [rsp+0x10], xmm2
0000705c0add5fe7  vmovaps [rsp+0x20], xmm3
0000705c0add5fed  vmovaps [rsp+0x30], xmm4
0000705c0add5ff3  vmovaps [rsp+0x40], xmm5
0000705c0add5ff9  vmovaps [rsp+0x50], xmm6
0000705c0add5fff  vmovaps [rsp+0x60], xmm7
0000705c0add6005  vmovaps [rsp+0x70], xmm8
0000705c0add600b  vmovaps [rsp+0x80], xmm9
0000705c0add6014  vmovaps [rsp+0x90], xmm10
0000705c0add601d  vmovaps [rsp+0xA0], xmm11
0000705c0add6026  vmovaps [rsp+0xB0], xmm12
0000705c0add602f  vmovaps [rsp+0xC0], xmm13
0000705c0add6038  vmovaps [rsp+0xD0], xmm14
0000705c0add6041  vmovaps [rsp+0xE0], xmm15
0000705c0add604a  sub rsp, 0x30
0000705c0add604e  movaps [rsp], xmm1
0000705c0add6052  movaps [rsp+0x10], xmm15
0000705c0add6058  movaps [rsp+0x20], xmm10
0000705c0add605e  lea rdi, [rsp]
0000705c0add6062  mov esi, 0x00
0000705c0add6067  mov rax, 0x5969C28C4530
0000705c0add6071  call rax
0000705c0add6073  movaps xmm1, [rsp]
0000705c0add6077  add rsp, 0x30
0000705c0add607b  vmovaps xmm0, [rsp]
0000705c0add6080  vmovaps xmm2, [rsp+0x10]
0000705c0add6086  vmovaps xmm3, [rsp+0x20]
0000705c0add608c  vmovaps xmm4, [rsp+0x30]
0000705c0add6092  vmovaps xmm5, [rsp+0x40]
0000705c0add6098  vmovaps xmm6, [rsp+0x50]
0000705c0add609e  vmovaps xmm7, [rsp+0x60]
0000705c0add60a4  vmovaps xmm8, [rsp+0x70]
0000705c0add60aa  vmovaps xmm9, [rsp+0x80]
0000705c0add60b3  vmovaps xmm10, [rsp+0x90]
0000705c0add60bc  vmovaps xmm11, [rsp+0xA0]
0000705c0add60c5  vmovaps xmm12, [rsp+0xB0]
0000705c0add60ce  vmovaps xmm13, [rsp+0xC0]
0000705c0add60d7  vmovaps xmm14, [rsp+0xD0]
0000705c0add60e0  vmovaps xmm15, [rsp+0xE0]
0000705c0add60e9  add rsp, 0xF0
0000705c0add60f0  pop r11
0000705c0add60f2  pop r10
0000705c0add60f4  pop r9
0000705c0add60f6  pop r8
0000705c0add60f8  pop rsi
0000705c0add60f9  pop rdi
0000705c0add60fa  pop rdx
0000705c0add60fb  pop rcx
0000705c0add60fc  pop rax
0000705c0add60fd  add rsp, 0x08
0000705c0add6101  jmp 0x0000705C0ADD305B
0000705c0add6106  sub rsp, 0x08
0000705c0add610a  push rax
0000705c0add610b  push rcx
0000705c0add610c  push rdx
0000705c0add610d  push rdi
0000705c0add610e  push rsi
0000705c0add610f  push r8
0000705c0add6111  push r9
0000705c0add6113  push r10
0000705c0add6115  push r11
0000705c0add6117  sub rsp, 0xF0
0000705c0add611e  vmovaps [rsp], xmm0
0000705c0add6123  vmovaps [rsp+0x10], xmm1
0000705c0add6129  vmovaps [rsp+0x20], xmm2
0000705c0add612f  vmovaps [rsp+0x30], xmm3
0000705c0add6135  vmovaps [rsp+0x40], xmm4
0000705c0add613b  vmovaps [rsp+0x50], xmm5
0000705c0add6141  vmovaps [rsp+0x60], xmm6
0000705c0add6147  vmovaps [rsp+0x70], xmm7
0000705c0add614d  vmovaps [rsp+0x80], xmm8
0000705c0add6156  vmovaps [rsp+0x90], xmm9
0000705c0add615f  vmovaps [rsp+0xA0], xmm10
0000705c0add6168  vmovaps [rsp+0xB0], xmm11
0000705c0add6171  vmovaps [rsp+0xC0], xmm12
0000705c0add617a  vmovaps [rsp+0xD0], xmm13
0000705c0add6183  vmovaps [rsp+0xE0], xmm14
0000705c0add618c  sub rsp, 0x30
0000705c0add6190  movaps [rsp], xmm15
0000705c0add6195  movaps [rsp+0x10], xmm10
0000705c0add619b  movaps [rsp+0x20], xmm11
0000705c0add61a1  lea rdi, [rsp]
0000705c0add61a5  mov esi, 0x00
0000705c0add61aa  mov rax, 0x5969C28C4530
0000705c0add61b4  call rax
0000705c0add61b6  movaps xmm15, [rsp]
0000705c0add61bb  add rsp, 0x30
0000705c0add61bf  vmovaps xmm0, [rsp]
0000705c0add61c4  vmovaps xmm1, [rsp+0x10]
0000705c0add61ca  vmovaps xmm2, [rsp+0x20]
0000705c0add61d0  vmovaps xmm3, [rsp+0x30]
0000705c0add61d6  vmovaps xmm4, [rsp+0x40]
0000705c0add61dc  vmovaps xmm5, [rsp+0x50]
0000705c0add61e2  vmovaps xmm6, [rsp+0x60]
0000705c0add61e8  vmovaps xmm7, [rsp+0x70]
0000705c0add61ee  vmovaps xmm8, [rsp+0x80]
0000705c0add61f7  vmovaps xmm9, [rsp+0x90]
0000705c0add6200  vmovaps xmm10, [rsp+0xA0]
0000705c0add6209  vmovaps xmm11, [rsp+0xB0]
0000705c0add6212  vmovaps xmm12, [rsp+0xC0]
0000705c0add621b  vmovaps xmm13, [rsp+0xD0]
0000705c0add6224  vmovaps xmm14, [rsp+0xE0]
0000705c0add622d  add rsp, 0xF0
0000705c0add6234  pop r11
0000705c0add6236  pop r10
0000705c0add6238  pop r9
0000705c0add623a  pop r8
0000705c0add623c  pop rsi
0000705c0add623d  pop rdi
0000705c0add623e  pop rdx
0000705c0add623f  pop rcx
0000705c0add6240  pop rax
0000705c0add6241  add rsp, 0x08
0000705c0add6245  jmp 0x0000705C0ADD307E
0000705c0add624a  sub rsp, 0x08
0000705c0add624e  push rax
0000705c0add624f  push rcx
0000705c0add6250  push rdx
0000705c0add6251  push rdi
0000705c0add6252  push rsi
0000705c0add6253  push r8
0000705c0add6255  push r9
0000705c0add6257  push r10
0000705c0add6259  push r11
0000705c0add625b  sub rsp, 0xF0
0000705c0add6262  vmovaps [rsp], xmm0
0000705c0add6267  vmovaps [rsp+0x10], xmm1
0000705c0add626d  vmovaps [rsp+0x20], xmm2
0000705c0add6273  vmovaps [rsp+0x30], xmm3
0000705c0add6279  vmovaps [rsp+0x40], xmm4
0000705c0add627f  vmovaps [rsp+0x50], xmm5
0000705c0add6285  vmovaps [rsp+0x60], xmm6
0000705c0add628b  vmovaps [rsp+0x70], xmm7
0000705c0add6291  vmovaps [rsp+0x80], xmm8
0000705c0add629a  vmovaps [rsp+0x90], xmm9
0000705c0add62a3  vmovaps [rsp+0xA0], xmm11
0000705c0add62ac  vmovaps [rsp+0xB0], xmm12
0000705c0add62b5  vmovaps [rsp+0xC0], xmm13
0000705c0add62be  vmovaps [rsp+0xD0], xmm14
0000705c0add62c7  vmovaps [rsp+0xE0], xmm15
0000705c0add62d0  sub rsp, 0x30
0000705c0add62d4  movaps [rsp], xmm10
0000705c0add62d9  movaps [rsp+0x10], xmm2
0000705c0add62de  movaps [rsp+0x20], xmm11
0000705c0add62e4  lea rdi, [rsp]
0000705c0add62e8  mov esi, 0x00
0000705c0add62ed  mov rax, 0x5969C28C4530
0000705c0add62f7  call rax
0000705c0add62f9  movaps xmm10, [rsp]
0000705c0add62fe  add rsp, 0x30
0000705c0add6302  vmovaps xmm0, [rsp]
0000705c0add6307  vmovaps xmm1, [rsp+0x10]
0000705c0add630d  vmovaps xmm2, [rsp+0x20]
0000705c0add6313  vmovaps xmm3, [rsp+0x30]
0000705c0add6319  vmovaps xmm4, [rsp+0x40]
0000705c0add631f  vmovaps xmm5, [rsp+0x50]
0000705c0add6325  vmovaps xmm6, [rsp+0x60]
0000705c0add632b  vmovaps xmm7, [rsp+0x70]
0000705c0add6331  vmovaps xmm8, [rsp+0x80]
0000705c0add633a  vmovaps xmm9, [rsp+0x90]
0000705c0add6343  vmovaps xmm11, [rsp+0xA0]
0000705c0add634c  vmovaps xmm12, [rsp+0xB0]
0000705c0add6355  vmovaps xmm13, [rsp+0xC0]
0000705c0add635e  vmovaps xmm14, [rsp+0xD0]
0000705c0add6367  vmovaps xmm15, [rsp+0xE0]
0000705c0add6370  add rsp, 0xF0
0000705c0add6377  pop r11
0000705c0add6379  pop r10
0000705c0add637b  pop r9
0000705c0add637d  pop r8
0000705c0add637f  pop rsi
0000705c0add6380  pop rdi
0000705c0add6381  pop rdx
0000705c0add6382  pop rcx
0000705c0add6383  pop rax
0000705c0add6384  add rsp, 0x08
0000705c0add6388  jmp 0x0000705C0ADD30B6
0000705c0add638d  sub rsp, 0x08
0000705c0add6391  push rax
0000705c0add6392  push rcx
0000705c0add6393  push rdx
0000705c0add6394  push rdi
0000705c0add6395  push rsi
0000705c0add6396  push r8
0000705c0add6398  push r9
0000705c0add639a  push r10
0000705c0add639c  push r11
0000705c0add639e  sub rsp, 0xF0
0000705c0add63a5  vmovaps [rsp], xmm0
0000705c0add63aa  vmovaps [rsp+0x10], xmm1
0000705c0add63b0  vmovaps [rsp+0x20], xmm2
0000705c0add63b6  vmovaps [rsp+0x30], xmm3
0000705c0add63bc  vmovaps [rsp+0x40], xmm4
0000705c0add63c2  vmovaps [rsp+0x50], xmm5
0000705c0add63c8  vmovaps [rsp+0x60], xmm6
0000705c0add63ce  vmovaps [rsp+0x70], xmm7
0000705c0add63d4  vmovaps [rsp+0x80], xmm8
0000705c0add63dd  vmovaps [rsp+0x90], xmm9
0000705c0add63e6  vmovaps [rsp+0xA0], xmm10
0000705c0add63ef  vmovaps [rsp+0xB0], xmm12
0000705c0add63f8  vmovaps [rsp+0xC0], xmm13
0000705c0add6401  vmovaps [rsp+0xD0], xmm14
0000705c0add640a  vmovaps [rsp+0xE0], xmm15
0000705c0add6413  sub rsp, 0x30
0000705c0add6417  movaps [rsp], xmm11
0000705c0add641c  movaps [rsp+0x10], xmm2
0000705c0add6421  movaps [rsp+0x20], xmm1
0000705c0add6426  lea rdi, [rsp]
0000705c0add642a  mov esi, 0x00
0000705c0add642f  mov rax, 0x5969C28C4530
0000705c0add6439  call rax
0000705c0add643b  movaps xmm11, [rsp]
0000705c0add6440  add rsp, 0x30
0000705c0add6444  vmovaps xmm0, [rsp]
0000705c0add6449  vmovaps xmm1, [rsp+0x10]
0000705c0add644f  vmovaps xmm2, [rsp+0x20]
0000705c0add6455  vmovaps xmm3, [rsp+0x30]
0000705c0add645b  vmovaps xmm4, [rsp+0x40]
0000705c0add6461  vmovaps xmm5, [rsp+0x50]
0000705c0add6467  vmovaps xmm6, [rsp+0x60]
0000705c0add646d  vmovaps xmm7, [rsp+0x70]
0000705c0add6473  vmovaps xmm8, [rsp+0x80]
0000705c0add647c  vmovaps xmm9, [rsp+0x90]
0000705c0add6485  vmovaps xmm10, [rsp+0xA0]
0000705c0add648e  vmovaps xmm12, [rsp+0xB0]
0000705c0add6497  vmovaps xmm13, [rsp+0xC0]
0000705c0add64a0  vmovaps xmm14, [rsp+0xD0]
0000705c0add64a9  vmovaps xmm15, [rsp+0xE0]
0000705c0add64b2  add rsp, 0xF0
0000705c0add64b9  pop r11
0000705c0add64bb  pop r10
0000705c0add64bd  pop r9
0000705c0add64bf  pop r8
0000705c0add64c1  pop rsi
0000705c0add64c2  pop rdi
0000705c0add64c3  pop rdx
0000705c0add64c4  pop rcx
0000705c0add64c5  pop rax
0000705c0add64c6  add rsp, 0x08
0000705c0add64ca  jmp 0x0000705C0ADD30F2
0000705c0add64cf  sub rsp, 0x08
0000705c0add64d3  push rax
0000705c0add64d4  push rcx
0000705c0add64d5  push rdx
0000705c0add64d6  push rdi
0000705c0add64d7  push rsi
0000705c0add64d8  push r8
0000705c0add64da  push r9
0000705c0add64dc  push r10
0000705c0add64de  push r11
0000705c0add64e0  sub rsp, 0xF0
0000705c0add64e7  vmovaps [rsp], xmm0
0000705c0add64ec  vmovaps [rsp+0x10], xmm2
0000705c0add64f2  vmovaps [rsp+0x20], xmm3
0000705c0add64f8  vmovaps [rsp+0x30], xmm4
0000705c0add64fe  vmovaps [rsp+0x40], xmm5
0000705c0add6504  vmovaps [rsp+0x50], xmm6
0000705c0add650a  vmovaps [rsp+0x60], xmm7
0000705c0add6510  vmovaps [rsp+0x70], xmm8
0000705c0add6516  vmovaps [rsp+0x80], xmm9
0000705c0add651f  vmovaps [rsp+0x90], xmm10
0000705c0add6528  vmovaps [rsp+0xA0], xmm11
0000705c0add6531  vmovaps [rsp+0xB0], xmm12
0000705c0add653a  vmovaps [rsp+0xC0], xmm13
0000705c0add6543  vmovaps [rsp+0xD0], xmm14
0000705c0add654c  vmovaps [rsp+0xE0], xmm15
0000705c0add6555  sub rsp, 0x30
0000705c0add6559  movaps [rsp], xmm1
0000705c0add655d  movaps [rsp+0x10], xmm14
0000705c0add6563  movaps [rsp+0x20], xmm6
0000705c0add6568  lea rdi, [rsp]
0000705c0add656c  mov esi, 0x00
0000705c0add6571  mov rax, 0x5969C28C4530
0000705c0add657b  call rax
0000705c0add657d  movaps xmm1, [rsp]
0000705c0add6581  add rsp, 0x30
0000705c0add6585  vmovaps xmm0, [rsp]
0000705c0add658a  vmovaps xmm2, [rsp+0x10]
0000705c0add6590  vmovaps xmm3, [rsp+0x20]
0000705c0add6596  vmovaps xmm4, [rsp+0x30]
0000705c0add659c  vmovaps xmm5, [rsp+0x40]
0000705c0add65a2  vmovaps xmm6, [rsp+0x50]
0000705c0add65a8  vmovaps xmm7, [rsp+0x60]
0000705c0add65ae  vmovaps xmm8, [rsp+0x70]
0000705c0add65b4  vmovaps xmm9, [rsp+0x80]
0000705c0add65bd  vmovaps xmm10, [rsp+0x90]
0000705c0add65c6  vmovaps xmm11, [rsp+0xA0]
0000705c0add65cf  vmovaps xmm12, [rsp+0xB0]
0000705c0add65d8  vmovaps xmm13, [rsp+0xC0]
0000705c0add65e1  vmovaps xmm14, [rsp+0xD0]
0000705c0add65ea  vmovaps xmm15, [rsp+0xE0]
0000705c0add65f3  add rsp, 0xF0
0000705c0add65fa  pop r11
0000705c0add65fc  pop r10
0000705c0add65fe  pop r9
0000705c0add6600  pop r8
0000705c0add6602  pop rsi
0000705c0add6603  pop rdi
0000705c0add6604  pop rdx
0000705c0add6605  pop rcx
0000705c0add6606  pop rax
0000705c0add6607  add rsp, 0x08
0000705c0add660b  jmp 0x0000705C0ADD310B
0000705c0add6610  sub rsp, 0x08
0000705c0add6614  push rax
0000705c0add6615  push rcx
0000705c0add6616  push rdx
0000705c0add6617  push rdi
0000705c0add6618  push rsi
0000705c0add6619  push r8
0000705c0add661b  push r9
0000705c0add661d  push r10
0000705c0add661f  push r11
0000705c0add6621  sub rsp, 0xF0
0000705c0add6628  vmovaps [rsp], xmm0
0000705c0add662d  vmovaps [rsp+0x10], xmm1
0000705c0add6633  vmovaps [rsp+0x20], xmm2
0000705c0add6639  vmovaps [rsp+0x30], xmm3
0000705c0add663f  vmovaps [rsp+0x40], xmm4
0000705c0add6645  vmovaps [rsp+0x50], xmm5
0000705c0add664b  vmovaps [rsp+0x60], xmm6
0000705c0add6651  vmovaps [rsp+0x70], xmm7
0000705c0add6657  vmovaps [rsp+0x80], xmm8
0000705c0add6660  vmovaps [rsp+0x90], xmm9
0000705c0add6669  vmovaps [rsp+0xA0], xmm10
0000705c0add6672  vmovaps [rsp+0xB0], xmm11
0000705c0add667b  vmovaps [rsp+0xC0], xmm12
0000705c0add6684  vmovaps [rsp+0xD0], xmm13
0000705c0add668d  vmovaps [rsp+0xE0], xmm14
0000705c0add6696  sub rsp, 0x30
0000705c0add669a  movaps [rsp], xmm15
0000705c0add669f  movaps [rsp+0x10], xmm14
0000705c0add66a5  movaps [rsp+0x20], xmm5
0000705c0add66aa  lea rdi, [rsp]
0000705c0add66ae  mov esi, 0x00
0000705c0add66b3  mov rax, 0x5969C28C4530
0000705c0add66bd  call rax
0000705c0add66bf  movaps xmm15, [rsp]
0000705c0add66c4  add rsp, 0x30
0000705c0add66c8  vmovaps xmm0, [rsp]
0000705c0add66cd  vmovaps xmm1, [rsp+0x10]
0000705c0add66d3  vmovaps xmm2, [rsp+0x20]
0000705c0add66d9  vmovaps xmm3, [rsp+0x30]
0000705c0add66df  vmovaps xmm4, [rsp+0x40]
0000705c0add66e5  vmovaps xmm5, [rsp+0x50]
0000705c0add66eb  vmovaps xmm6, [rsp+0x60]
0000705c0add66f1  vmovaps xmm7, [rsp+0x70]
0000705c0add66f7  vmovaps xmm8, [rsp+0x80]
0000705c0add6700  vmovaps xmm9, [rsp+0x90]
0000705c0add6709  vmovaps xmm10, [rsp+0xA0]
0000705c0add6712  vmovaps xmm11, [rsp+0xB0]
0000705c0add671b  vmovaps xmm12, [rsp+0xC0]
0000705c0add6724  vmovaps xmm13, [rsp+0xD0]
0000705c0add672d  vmovaps xmm14, [rsp+0xE0]
0000705c0add6736  add rsp, 0xF0
0000705c0add673d  pop r11
0000705c0add673f  pop r10
0000705c0add6741  pop r9
0000705c0add6743  pop r8
0000705c0add6745  pop rsi
0000705c0add6746  pop rdi
0000705c0add6747  pop rdx
0000705c0add6748  pop rcx
0000705c0add6749  pop rax
0000705c0add674a  add rsp, 0x08
0000705c0add674e  jmp 0x0000705C0ADD312B
0000705c0add6753  sub rsp, 0x08
0000705c0add6757  push rax
0000705c0add6758  push rcx
0000705c0add6759  push rdx
0000705c0add675a  push rdi
0000705c0add675b  push rsi
0000705c0add675c  push r8
0000705c0add675e  push r9
0000705c0add6760  push r10
0000705c0add6762  push r11
0000705c0add6764  sub rsp, 0xF0
0000705c0add676b  vmovaps [rsp], xmm0
0000705c0add6770  vmovaps [rsp+0x10], xmm1
0000705c0add6776  vmovaps [rsp+0x20], xmm2
0000705c0add677c  vmovaps [rsp+0x30], xmm3
0000705c0add6782  vmovaps [rsp+0x40], xmm4
0000705c0add6788  vmovaps [rsp+0x50], xmm5
0000705c0add678e  vmovaps [rsp+0x60], xmm7
0000705c0add6794  vmovaps [rsp+0x70], xmm8
0000705c0add679a  vmovaps [rsp+0x80], xmm9
0000705c0add67a3  vmovaps [rsp+0x90], xmm10
0000705c0add67ac  vmovaps [rsp+0xA0], xmm11
0000705c0add67b5  vmovaps [rsp+0xB0], xmm12
0000705c0add67be  vmovaps [rsp+0xC0], xmm13
0000705c0add67c7  vmovaps [rsp+0xD0], xmm14
0000705c0add67d0  vmovaps [rsp+0xE0], xmm15
0000705c0add67d9  sub rsp, 0x30
0000705c0add67dd  movaps [rsp], xmm6
0000705c0add67e1  movaps [rsp+0x10], xmm9
0000705c0add67e7  movaps [rsp+0x20], xmm14
0000705c0add67ed  lea rdi, [rsp]
0000705c0add67f1  mov esi, 0x00
0000705c0add67f6  mov rax, 0x5969C28C4530
0000705c0add6800  call rax
0000705c0add6802  movaps xmm6, [rsp]
0000705c0add6806  add rsp, 0x30
0000705c0add680a  vmovaps xmm0, [rsp]
0000705c0add680f  vmovaps xmm1, [rsp+0x10]
0000705c0add6815  vmovaps xmm2, [rsp+0x20]
0000705c0add681b  vmovaps xmm3, [rsp+0x30]
0000705c0add6821  vmovaps xmm4, [rsp+0x40]
0000705c0add6827  vmovaps xmm5, [rsp+0x50]
0000705c0add682d  vmovaps xmm7, [rsp+0x60]
0000705c0add6833  vmovaps xmm8, [rsp+0x70]
0000705c0add6839  vmovaps xmm9, [rsp+0x80]
0000705c0add6842  vmovaps xmm10, [rsp+0x90]
0000705c0add684b  vmovaps xmm11, [rsp+0xA0]
0000705c0add6854  vmovaps xmm12, [rsp+0xB0]
0000705c0add685d  vmovaps xmm13, [rsp+0xC0]
0000705c0add6866  vmovaps xmm14, [rsp+0xD0]
0000705c0add686f  vmovaps xmm15, [rsp+0xE0]
0000705c0add6878  add rsp, 0xF0
0000705c0add687f  pop r11
0000705c0add6881  pop r10
0000705c0add6883  pop r9
0000705c0add6885  pop r8
0000705c0add6887  pop rsi
0000705c0add6888  pop rdi
0000705c0add6889  pop rdx
0000705c0add688a  pop rcx
0000705c0add688b  pop rax
0000705c0add688c  add rsp, 0x08
0000705c0add6890  jmp 0x0000705C0ADD3153
0000705c0add6895  sub rsp, 0x08
0000705c0add6899  push rax
0000705c0add689a  push rcx
0000705c0add689b  push rdx
0000705c0add689c  push rdi
0000705c0add689d  push rsi
0000705c0add689e  push r8
0000705c0add68a0  push r9
0000705c0add68a2  push r10
0000705c0add68a4  push r11
0000705c0add68a6  sub rsp, 0xF0
0000705c0add68ad  vmovaps [rsp], xmm0
0000705c0add68b2  vmovaps [rsp+0x10], xmm1
0000705c0add68b8  vmovaps [rsp+0x20], xmm2
0000705c0add68be  vmovaps [rsp+0x30], xmm3
0000705c0add68c4  vmovaps [rsp+0x40], xmm4
0000705c0add68ca  vmovaps [rsp+0x50], xmm5
0000705c0add68d0  vmovaps [rsp+0x60], xmm6
0000705c0add68d6  vmovaps [rsp+0x70], xmm7
0000705c0add68dc  vmovaps [rsp+0x80], xmm8
0000705c0add68e5  vmovaps [rsp+0x90], xmm9
0000705c0add68ee  vmovaps [rsp+0xA0], xmm10
0000705c0add68f7  vmovaps [rsp+0xB0], xmm11
0000705c0add6900  vmovaps [rsp+0xC0], xmm12
0000705c0add6909  vmovaps [rsp+0xD0], xmm13
0000705c0add6912  vmovaps [rsp+0xE0], xmm15
0000705c0add691b  sub rsp, 0x30
0000705c0add691f  movaps [rsp], xmm14
0000705c0add6924  movaps [rsp+0x10], xmm9
0000705c0add692a  movaps [rsp+0x20], xmm13
0000705c0add6930  lea rdi, [rsp]
0000705c0add6934  mov esi, 0x00
0000705c0add6939  mov rax, 0x5969C28C4530
0000705c0add6943  call rax
0000705c0add6945  movaps xmm14, [rsp]
0000705c0add694a  add rsp, 0x30
0000705c0add694e  vmovaps xmm0, [rsp]
0000705c0add6953  vmovaps xmm1, [rsp+0x10]
0000705c0add6959  vmovaps xmm2, [rsp+0x20]
0000705c0add695f  vmovaps xmm3, [rsp+0x30]
0000705c0add6965  vmovaps xmm4, [rsp+0x40]
0000705c0add696b  vmovaps xmm5, [rsp+0x50]
0000705c0add6971  vmovaps xmm6, [rsp+0x60]
0000705c0add6977  vmovaps xmm7, [rsp+0x70]
0000705c0add697d  vmovaps xmm8, [rsp+0x80]
0000705c0add6986  vmovaps xmm9, [rsp+0x90]
0000705c0add698f  vmovaps xmm10, [rsp+0xA0]
0000705c0add6998  vmovaps xmm11, [rsp+0xB0]
0000705c0add69a1  vmovaps xmm12, [rsp+0xC0]
0000705c0add69aa  vmovaps xmm13, [rsp+0xD0]
0000705c0add69b3  vmovaps xmm15, [rsp+0xE0]
0000705c0add69bc  add rsp, 0xF0
0000705c0add69c3  pop r11
0000705c0add69c5  pop r10
0000705c0add69c7  pop r9
0000705c0add69c9  pop r8
0000705c0add69cb  pop rsi
0000705c0add69cc  pop rdi
0000705c0add69cd  pop rdx
0000705c0add69ce  pop rcx
0000705c0add69cf  pop rax
0000705c0add69d0  add rsp, 0x08
0000705c0add69d4  jmp 0x0000705C0ADD3176
0000705c0add69d9  sub rsp, 0x08
0000705c0add69dd  push rax
0000705c0add69de  push rcx
0000705c0add69df  push rdx
0000705c0add69e0  push rdi
0000705c0add69e1  push rsi
0000705c0add69e2  push r8
0000705c0add69e4  push r9
0000705c0add69e6  push r10
0000705c0add69e8  push r11
0000705c0add69ea  sub rsp, 0xF0
0000705c0add69f1  vmovaps [rsp], xmm0
0000705c0add69f6  vmovaps [rsp+0x10], xmm1
0000705c0add69fc  vmovaps [rsp+0x20], xmm2
0000705c0add6a02  vmovaps [rsp+0x30], xmm3
0000705c0add6a08  vmovaps [rsp+0x40], xmm4
0000705c0add6a0e  vmovaps [rsp+0x50], xmm5
0000705c0add6a14  vmovaps [rsp+0x60], xmm6
0000705c0add6a1a  vmovaps [rsp+0x70], xmm7
0000705c0add6a20  vmovaps [rsp+0x80], xmm8
0000705c0add6a29  vmovaps [rsp+0x90], xmm9
0000705c0add6a32  vmovaps [rsp+0xA0], xmm10
0000705c0add6a3b  vmovaps [rsp+0xB0], xmm11
0000705c0add6a44  vmovaps [rsp+0xC0], xmm12
0000705c0add6a4d  vmovaps [rsp+0xD0], xmm14
0000705c0add6a56  vmovaps [rsp+0xE0], xmm15
0000705c0add6a5f  sub rsp, 0x30
0000705c0add6a63  movaps [rsp], xmm13
0000705c0add6a68  movaps [rsp+0x10], xmm9
0000705c0add6a6e  movaps [rsp+0x20], xmm10
0000705c0add6a74  lea rdi, [rsp]
0000705c0add6a78  mov esi, 0x00
0000705c0add6a7d  mov rax, 0x5969C28C4530
0000705c0add6a87  call rax
0000705c0add6a89  movaps xmm13, [rsp]
0000705c0add6a8e  add rsp, 0x30
0000705c0add6a92  vmovaps xmm0, [rsp]
0000705c0add6a97  vmovaps xmm1, [rsp+0x10]
0000705c0add6a9d  vmovaps xmm2, [rsp+0x20]
0000705c0add6aa3  vmovaps xmm3, [rsp+0x30]
0000705c0add6aa9  vmovaps xmm4, [rsp+0x40]
0000705c0add6aaf  vmovaps xmm5, [rsp+0x50]
0000705c0add6ab5  vmovaps xmm6, [rsp+0x60]
0000705c0add6abb  vmovaps xmm7, [rsp+0x70]
0000705c0add6ac1  vmovaps xmm8, [rsp+0x80]
0000705c0add6aca  vmovaps xmm9, [rsp+0x90]
0000705c0add6ad3  vmovaps xmm10, [rsp+0xA0]
0000705c0add6adc  vmovaps xmm11, [rsp+0xB0]
0000705c0add6ae5  vmovaps xmm12, [rsp+0xC0]
0000705c0add6aee  vmovaps xmm14, [rsp+0xD0]
0000705c0add6af7  vmovaps xmm15, [rsp+0xE0]
0000705c0add6b00  add rsp, 0xF0
0000705c0add6b07  pop r11
0000705c0add6b09  pop r10
0000705c0add6b0b  pop r9
0000705c0add6b0d  pop r8
0000705c0add6b0f  pop rsi
0000705c0add6b10  pop rdi
0000705c0add6b11  pop rdx
0000705c0add6b12  pop rcx
0000705c0add6b13  pop rax
0000705c0add6b14  add rsp, 0x08
0000705c0add6b18  jmp 0x0000705C0ADD3196
0000705c0add6b1d  call 0x0000705C0AC0AFE0
0000705c0add6b22  jmp 0x0000705C0ADD31EB
0000705c0add6b27  sub rsp, 0x08
0000705c0add6b2b  push rax
0000705c0add6b2c  push rcx
0000705c0add6b2d  push rdx
0000705c0add6b2e  push rdi
0000705c0add6b2f  push rsi
0000705c0add6b30  push r8
0000705c0add6b32  push r9
0000705c0add6b34  push r10
0000705c0add6b36  push r11
0000705c0add6b38  sub rsp, 0xF0
0000705c0add6b3f  vmovaps [rsp], xmm0
0000705c0add6b44  vmovaps [rsp+0x10], xmm1
0000705c0add6b4a  vmovaps [rsp+0x20], xmm2
0000705c0add6b50  vmovaps [rsp+0x30], xmm3
0000705c0add6b56  vmovaps [rsp+0x40], xmm4
0000705c0add6b5c  vmovaps [rsp+0x50], xmm5
0000705c0add6b62  vmovaps [rsp+0x60], xmm6
0000705c0add6b68  vmovaps [rsp+0x70], xmm7
0000705c0add6b6e  vmovaps [rsp+0x80], xmm8
0000705c0add6b77  vmovaps [rsp+0x90], xmm10
0000705c0add6b80  vmovaps [rsp+0xA0], xmm11
0000705c0add6b89  vmovaps [rsp+0xB0], xmm12
0000705c0add6b92  vmovaps [rsp+0xC0], xmm13
0000705c0add6b9b  vmovaps [rsp+0xD0], xmm14
0000705c0add6ba4  vmovaps [rsp+0xE0], xmm15
0000705c0add6bad  sub rsp, 0x30
0000705c0add6bb1  movaps [rsp], xmm9
0000705c0add6bb6  movaps [rsp+0x10], xmm8
0000705c0add6bbc  movaps [rsp+0x20], xmm10
0000705c0add6bc2  lea rdi, [rsp]
0000705c0add6bc6  mov esi, 0x00
0000705c0add6bcb  mov rax, 0x5969C28C4530
0000705c0add6bd5  call rax
0000705c0add6bd7  movaps xmm9, [rsp]
0000705c0add6bdc  add rsp, 0x30
0000705c0add6be0  vmovaps xmm0, [rsp]
0000705c0add6be5  vmovaps xmm1, [rsp+0x10]
0000705c0add6beb  vmovaps xmm2, [rsp+0x20]
0000705c0add6bf1  vmovaps xmm3, [rsp+0x30]
0000705c0add6bf7  vmovaps xmm4, [rsp+0x40]
0000705c0add6bfd  vmovaps xmm5, [rsp+0x50]
0000705c0add6c03  vmovaps xmm6, [rsp+0x60]
0000705c0add6c09  vmovaps xmm7, [rsp+0x70]
0000705c0add6c0f  vmovaps xmm8, [rsp+0x80]
0000705c0add6c18  vmovaps xmm10, [rsp+0x90]
0000705c0add6c21  vmovaps xmm11, [rsp+0xA0]
0000705c0add6c2a  vmovaps xmm12, [rsp+0xB0]
0000705c0add6c33  vmovaps xmm13, [rsp+0xC0]
0000705c0add6c3c  vmovaps xmm14, [rsp+0xD0]
0000705c0add6c45  vmovaps xmm15, [rsp+0xE0]
0000705c0add6c4e  add rsp, 0xF0
0000705c0add6c55  pop r11
0000705c0add6c57  pop r10
0000705c0add6c59  pop r9
0000705c0add6c5b  pop r8
0000705c0add6c5d  pop rsi
0000705c0add6c5e  pop rdi
0000705c0add6c5f  pop rdx
0000705c0add6c60  pop rcx
0000705c0add6c61  pop rax
0000705c0add6c62  add rsp, 0x08
0000705c0add6c66  jmp 0x0000705C0ADD321C
0000705c0add6c6b  sub rsp, 0x08
0000705c0add6c6f  push rax
0000705c0add6c70  push rcx
0000705c0add6c71  push rdx
0000705c0add6c72  push rdi
0000705c0add6c73  push rsi
0000705c0add6c74  push r8
0000705c0add6c76  push r9
0000705c0add6c78  push r10
0000705c0add6c7a  push r11
0000705c0add6c7c  sub rsp, 0xF0
0000705c0add6c83  vmovaps [rsp], xmm0
0000705c0add6c88  vmovaps [rsp+0x10], xmm1
0000705c0add6c8e  vmovaps [rsp+0x20], xmm2
0000705c0add6c94  vmovaps [rsp+0x30], xmm3
0000705c0add6c9a  vmovaps [rsp+0x40], xmm4
0000705c0add6ca0  vmovaps [rsp+0x50], xmm5
0000705c0add6ca6  vmovaps [rsp+0x60], xmm6
0000705c0add6cac  vmovaps [rsp+0x70], xmm7
0000705c0add6cb2  vmovaps [rsp+0x80], xmm8
0000705c0add6cbb  vmovaps [rsp+0x90], xmm9
0000705c0add6cc4  vmovaps [rsp+0xA0], xmm11
0000705c0add6ccd  vmovaps [rsp+0xB0], xmm12
0000705c0add6cd6  vmovaps [rsp+0xC0], xmm13
0000705c0add6cdf  vmovaps [rsp+0xD0], xmm14
0000705c0add6ce8  vmovaps [rsp+0xE0], xmm15
0000705c0add6cf1  sub rsp, 0x30
0000705c0add6cf5  movaps [rsp], xmm10
0000705c0add6cfa  movaps [rsp+0x10], xmm1
0000705c0add6cff  movaps [rsp+0x20], xmm11
0000705c0add6d05  lea rdi, [rsp]
0000705c0add6d09  mov esi, 0x00
0000705c0add6d0e  mov rax, 0x5969C28C4530
0000705c0add6d18  call rax
0000705c0add6d1a  movaps xmm10, [rsp]
0000705c0add6d1f  add rsp, 0x30
0000705c0add6d23  vmovaps xmm0, [rsp]
0000705c0add6d28  vmovaps xmm1, [rsp+0x10]
0000705c0add6d2e  vmovaps xmm2, [rsp+0x20]
0000705c0add6d34  vmovaps xmm3, [rsp+0x30]
0000705c0add6d3a  vmovaps xmm4, [rsp+0x40]
0000705c0add6d40  vmovaps xmm5, [rsp+0x50]
0000705c0add6d46  vmovaps xmm6, [rsp+0x60]
0000705c0add6d4c  vmovaps xmm7, [rsp+0x70]
0000705c0add6d52  vmovaps xmm8, [rsp+0x80]
0000705c0add6d5b  vmovaps xmm9, [rsp+0x90]
0000705c0add6d64  vmovaps xmm11, [rsp+0xA0]
0000705c0add6d6d  vmovaps xmm12, [rsp+0xB0]
0000705c0add6d76  vmovaps xmm13, [rsp+0xC0]
0000705c0add6d7f  vmovaps xmm14, [rsp+0xD0]
0000705c0add6d88  vmovaps xmm15, [rsp+0xE0]
0000705c0add6d91  add rsp, 0xF0
0000705c0add6d98  pop r11
0000705c0add6d9a  pop r10
0000705c0add6d9c  pop r9
0000705c0add6d9e  pop r8
0000705c0add6da0  pop rsi
0000705c0add6da1  pop rdi
0000705c0add6da2  pop rdx
0000705c0add6da3  pop rcx
0000705c0add6da4  pop rax
0000705c0add6da5  add rsp, 0x08
0000705c0add6da9  jmp 0x0000705C0ADD3237
0000705c0add6dae  sub rsp, 0x08
0000705c0add6db2  push rax
0000705c0add6db3  push rcx
0000705c0add6db4  push rdx
0000705c0add6db5  push rdi
0000705c0add6db6  push rsi
0000705c0add6db7  push r8
0000705c0add6db9  push r9
0000705c0add6dbb  push r10
0000705c0add6dbd  push r11
0000705c0add6dbf  sub rsp, 0xF0
0000705c0add6dc6  vmovaps [rsp], xmm0
0000705c0add6dcb  vmovaps [rsp+0x10], xmm2
0000705c0add6dd1  vmovaps [rsp+0x20], xmm3
0000705c0add6dd7  vmovaps [rsp+0x30], xmm4
0000705c0add6ddd  vmovaps [rsp+0x40], xmm5
0000705c0add6de3  vmovaps [rsp+0x50], xmm6
0000705c0add6de9  vmovaps [rsp+0x60], xmm7
0000705c0add6def  vmovaps [rsp+0x70], xmm8
0000705c0add6df5  vmovaps [rsp+0x80], xmm9
0000705c0add6dfe  vmovaps [rsp+0x90], xmm10
0000705c0add6e07  vmovaps [rsp+0xA0], xmm11
0000705c0add6e10  vmovaps [rsp+0xB0], xmm12
0000705c0add6e19  vmovaps [rsp+0xC0], xmm13
0000705c0add6e22  vmovaps [rsp+0xD0], xmm14
0000705c0add6e2b  vmovaps [rsp+0xE0], xmm15
0000705c0add6e34  sub rsp, 0x30
0000705c0add6e38  movaps [rsp], xmm1
0000705c0add6e3c  movaps [rsp+0x10], xmm15
0000705c0add6e42  movaps [rsp+0x20], xmm6
0000705c0add6e47  lea rdi, [rsp]
0000705c0add6e4b  mov esi, 0x00
0000705c0add6e50  mov rax, 0x5969C28C4530
0000705c0add6e5a  call rax
0000705c0add6e5c  movaps xmm1, [rsp]
0000705c0add6e60  add rsp, 0x30
0000705c0add6e64  vmovaps xmm0, [rsp]
0000705c0add6e69  vmovaps xmm2, [rsp+0x10]
0000705c0add6e6f  vmovaps xmm3, [rsp+0x20]
0000705c0add6e75  vmovaps xmm4, [rsp+0x30]
0000705c0add6e7b  vmovaps xmm5, [rsp+0x40]
0000705c0add6e81  vmovaps xmm6, [rsp+0x50]
0000705c0add6e87  vmovaps xmm7, [rsp+0x60]
0000705c0add6e8d  vmovaps xmm8, [rsp+0x70]
0000705c0add6e93  vmovaps xmm9, [rsp+0x80]
0000705c0add6e9c  vmovaps xmm10, [rsp+0x90]
0000705c0add6ea5  vmovaps xmm11, [rsp+0xA0]
0000705c0add6eae  vmovaps xmm12, [rsp+0xB0]
0000705c0add6eb7  vmovaps xmm13, [rsp+0xC0]
0000705c0add6ec0  vmovaps xmm14, [rsp+0xD0]
0000705c0add6ec9  vmovaps xmm15, [rsp+0xE0]
0000705c0add6ed2  add rsp, 0xF0
0000705c0add6ed9  pop r11
0000705c0add6edb  pop r10
0000705c0add6edd  pop r9
0000705c0add6edf  pop r8
0000705c0add6ee1  pop rsi
0000705c0add6ee2  pop rdi
0000705c0add6ee3  pop rdx
0000705c0add6ee4  pop rcx
0000705c0add6ee5  pop rax
0000705c0add6ee6  add rsp, 0x08
0000705c0add6eea  jmp 0x0000705C0ADD3250
0000705c0add6eef  sub rsp, 0x08
0000705c0add6ef3  push rax
0000705c0add6ef4  push rcx
0000705c0add6ef5  push rdx
0000705c0add6ef6  push rdi
0000705c0add6ef7  push rsi
0000705c0add6ef8  push r8
0000705c0add6efa  push r9
0000705c0add6efc  push r10
0000705c0add6efe  push r11
0000705c0add6f00  sub rsp, 0xF0
0000705c0add6f07  vmovaps [rsp], xmm0
0000705c0add6f0c  vmovaps [rsp+0x10], xmm1
0000705c0add6f12  vmovaps [rsp+0x20], xmm2
0000705c0add6f18  vmovaps [rsp+0x30], xmm3
0000705c0add6f1e  vmovaps [rsp+0x40], xmm4
0000705c0add6f24  vmovaps [rsp+0x50], xmm5
0000705c0add6f2a  vmovaps [rsp+0x60], xmm6
0000705c0add6f30  vmovaps [rsp+0x70], xmm7
0000705c0add6f36  vmovaps [rsp+0x80], xmm8
0000705c0add6f3f  vmovaps [rsp+0x90], xmm9
0000705c0add6f48  vmovaps [rsp+0xA0], xmm10
0000705c0add6f51  vmovaps [rsp+0xB0], xmm12
0000705c0add6f5a  vmovaps [rsp+0xC0], xmm13
0000705c0add6f63  vmovaps [rsp+0xD0], xmm14
0000705c0add6f6c  vmovaps [rsp+0xE0], xmm15
0000705c0add6f75  sub rsp, 0x30
0000705c0add6f79  movaps [rsp], xmm11
0000705c0add6f7e  movaps [rsp+0x10], xmm12
0000705c0add6f84  movaps [rsp+0x20], xmm15
0000705c0add6f8a  lea rdi, [rsp]
0000705c0add6f8e  mov esi, 0x00
0000705c0add6f93  mov rax, 0x5969C28C4530
0000705c0add6f9d  call rax
0000705c0add6f9f  movaps xmm11, [rsp]
0000705c0add6fa4  add rsp, 0x30
0000705c0add6fa8  vmovaps xmm0, [rsp]
0000705c0add6fad  vmovaps xmm1, [rsp+0x10]
0000705c0add6fb3  vmovaps xmm2, [rsp+0x20]
0000705c0add6fb9  vmovaps xmm3, [rsp+0x30]
0000705c0add6fbf  vmovaps xmm4, [rsp+0x40]
0000705c0add6fc5  vmovaps xmm5, [rsp+0x50]
0000705c0add6fcb  vmovaps xmm6, [rsp+0x60]
0000705c0add6fd1  vmovaps xmm7, [rsp+0x70]
0000705c0add6fd7  vmovaps xmm8, [rsp+0x80]
0000705c0add6fe0  vmovaps xmm9, [rsp+0x90]
0000705c0add6fe9  vmovaps xmm10, [rsp+0xA0]
0000705c0add6ff2  vmovaps xmm12, [rsp+0xB0]
0000705c0add6ffb  vmovaps xmm13, [rsp+0xC0]
0000705c0add7004  vmovaps xmm14, [rsp+0xD0]
0000705c0add700d  vmovaps xmm15, [rsp+0xE0]
0000705c0add7016  add rsp, 0xF0
0000705c0add701d  pop r11
0000705c0add701f  pop r10
0000705c0add7021  pop r9
0000705c0add7023  pop r8
0000705c0add7025  pop rsi
0000705c0add7026  pop rdi
0000705c0add7027  pop rdx
0000705c0add7028  pop rcx
0000705c0add7029  pop rax
0000705c0add702a  add rsp, 0x08
0000705c0add702e  jmp 0x0000705C0ADD327A
0000705c0add7033  sub rsp, 0x08
0000705c0add7037  push rax
0000705c0add7038  push rcx
0000705c0add7039  push rdx
0000705c0add703a  push rdi
0000705c0add703b  push rsi
0000705c0add703c  push r8
0000705c0add703e  push r9
0000705c0add7040  push r10
0000705c0add7042  push r11
0000705c0add7044  sub rsp, 0xF0
0000705c0add704b  vmovaps [rsp], xmm0
0000705c0add7050  vmovaps [rsp+0x10], xmm1
0000705c0add7056  vmovaps [rsp+0x20], xmm2
0000705c0add705c  vmovaps [rsp+0x30], xmm3
0000705c0add7062  vmovaps [rsp+0x40], xmm4
0000705c0add7068  vmovaps [rsp+0x50], xmm5
0000705c0add706e  vmovaps [rsp+0x60], xmm6
0000705c0add7074  vmovaps [rsp+0x70], xmm7
0000705c0add707a  vmovaps [rsp+0x80], xmm8
0000705c0add7083  vmovaps [rsp+0x90], xmm9
0000705c0add708c  vmovaps [rsp+0xA0], xmm10
0000705c0add7095  vmovaps [rsp+0xB0], xmm11
0000705c0add709e  vmovaps [rsp+0xC0], xmm13
0000705c0add70a7  vmovaps [rsp+0xD0], xmm14
0000705c0add70b0  vmovaps [rsp+0xE0], xmm15
0000705c0add70b9  sub rsp, 0x30
0000705c0add70bd  movaps [rsp], xmm12
0000705c0add70c2  movaps [rsp+0x10], xmm8
0000705c0add70c8  movaps [rsp+0x20], xmm15
0000705c0add70ce  lea rdi, [rsp]
0000705c0add70d2  mov esi, 0x00
0000705c0add70d7  mov rax, 0x5969C28C4530
0000705c0add70e1  call rax
0000705c0add70e3  movaps xmm12, [rsp]
0000705c0add70e8  add rsp, 0x30
0000705c0add70ec  vmovaps xmm0, [rsp]
0000705c0add70f1  vmovaps xmm1, [rsp+0x10]
0000705c0add70f7  vmovaps xmm2, [rsp+0x20]
0000705c0add70fd  vmovaps xmm3, [rsp+0x30]
0000705c0add7103  vmovaps xmm4, [rsp+0x40]
0000705c0add7109  vmovaps xmm5, [rsp+0x50]
0000705c0add710f  vmovaps xmm6, [rsp+0x60]
0000705c0add7115  vmovaps xmm7, [rsp+0x70]
0000705c0add711b  vmovaps xmm8, [rsp+0x80]
0000705c0add7124  vmovaps xmm9, [rsp+0x90]
0000705c0add712d  vmovaps xmm10, [rsp+0xA0]
0000705c0add7136  vmovaps xmm11, [rsp+0xB0]
0000705c0add713f  vmovaps xmm13, [rsp+0xC0]
0000705c0add7148  vmovaps xmm14, [rsp+0xD0]
0000705c0add7151  vmovaps xmm15, [rsp+0xE0]
0000705c0add715a  add rsp, 0xF0
0000705c0add7161  pop r11
0000705c0add7163  pop r10
0000705c0add7165  pop r9
0000705c0add7167  pop r8
0000705c0add7169  pop rsi
0000705c0add716a  pop rdi
0000705c0add716b  pop rdx
0000705c0add716c  pop rcx
0000705c0add716d  pop rax
0000705c0add716e  add rsp, 0x08
0000705c0add7172  jmp 0x0000705C0ADD32A9
0000705c0add7177  sub rsp, 0x08
0000705c0add717b  push rax
0000705c0add717c  push rcx
0000705c0add717d  push rdx
0000705c0add717e  push rdi
0000705c0add717f  push rsi
0000705c0add7180  push r8
0000705c0add7182  push r9
0000705c0add7184  push r10
0000705c0add7186  push r11
0000705c0add7188  sub rsp, 0xF0
0000705c0add718f  vmovaps [rsp], xmm0
0000705c0add7194  vmovaps [rsp+0x10], xmm1
0000705c0add719a  vmovaps [rsp+0x20], xmm2
0000705c0add71a0  vmovaps [rsp+0x30], xmm3
0000705c0add71a6  vmovaps [rsp+0x40], xmm4
0000705c0add71ac  vmovaps [rsp+0x50], xmm5
0000705c0add71b2  vmovaps [rsp+0x60], xmm6
0000705c0add71b8  vmovaps [rsp+0x70], xmm7
0000705c0add71be  vmovaps [rsp+0x80], xmm9
0000705c0add71c7  vmovaps [rsp+0x90], xmm10
0000705c0add71d0  vmovaps [rsp+0xA0], xmm11
0000705c0add71d9  vmovaps [rsp+0xB0], xmm12
0000705c0add71e2  vmovaps [rsp+0xC0], xmm13
0000705c0add71eb  vmovaps [rsp+0xD0], xmm14
0000705c0add71f4  vmovaps [rsp+0xE0], xmm15
0000705c0add71fd  sub rsp, 0x30
0000705c0add7201  movaps [rsp], xmm8
0000705c0add7206  movaps [rsp+0x10], xmm7
0000705c0add720b  movaps [rsp+0x20], xmm15
0000705c0add7211  lea rdi, [rsp]
0000705c0add7215  mov esi, 0x00
0000705c0add721a  mov rax, 0x5969C28C4530
0000705c0add7224  call rax
0000705c0add7226  movaps xmm8, [rsp]
0000705c0add722b  add rsp, 0x30
0000705c0add722f  vmovaps xmm0, [rsp]
0000705c0add7234  vmovaps xmm1, [rsp+0x10]
0000705c0add723a  vmovaps xmm2, [rsp+0x20]
0000705c0add7240  vmovaps xmm3, [rsp+0x30]
0000705c0add7246  vmovaps xmm4, [rsp+0x40]
0000705c0add724c  vmovaps xmm5, [rsp+0x50]
0000705c0add7252  vmovaps xmm6, [rsp+0x60]
0000705c0add7258  vmovaps xmm7, [rsp+0x70]
0000705c0add725e  vmovaps xmm9, [rsp+0x80]
0000705c0add7267  vmovaps xmm10, [rsp+0x90]
0000705c0add7270  vmovaps xmm11, [rsp+0xA0]
0000705c0add7279  vmovaps xmm12, [rsp+0xB0]
0000705c0add7282  vmovaps xmm13, [rsp+0xC0]
0000705c0add728b  vmovaps xmm14, [rsp+0xD0]
0000705c0add7294  vmovaps xmm15, [rsp+0xE0]
0000705c0add729d  add rsp, 0xF0
0000705c0add72a4  pop r11
0000705c0add72a6  pop r10
0000705c0add72a8  pop r9
0000705c0add72aa  pop r8
0000705c0add72ac  pop rsi
0000705c0add72ad  pop rdi
0000705c0add72ae  pop rdx
0000705c0add72af  pop rcx
0000705c0add72b0  pop rax
0000705c0add72b1  add rsp, 0x08
0000705c0add72b5  jmp 0x0000705C0ADD32CF
0000705c0add72ba  sub rsp, 0x08
0000705c0add72be  push rax
0000705c0add72bf  push rcx
0000705c0add72c0  push rdx
0000705c0add72c1  push rdi
0000705c0add72c2  push rsi
0000705c0add72c3  push r8
0000705c0add72c5  push r9
0000705c0add72c7  push r10
0000705c0add72c9  push r11
0000705c0add72cb  sub rsp, 0xF0
0000705c0add72d2  vmovaps [rsp], xmm0
0000705c0add72d7  vmovaps [rsp+0x10], xmm1
0000705c0add72dd  vmovaps [rsp+0x20], xmm2
0000705c0add72e3  vmovaps [rsp+0x30], xmm3
0000705c0add72e9  vmovaps [rsp+0x40], xmm4
0000705c0add72ef  vmovaps [rsp+0x50], xmm5
0000705c0add72f5  vmovaps [rsp+0x60], xmm6
0000705c0add72fb  vmovaps [rsp+0x70], xmm7
0000705c0add7301  vmovaps [rsp+0x80], xmm8
0000705c0add730a  vmovaps [rsp+0x90], xmm9
0000705c0add7313  vmovaps [rsp+0xA0], xmm10
0000705c0add731c  vmovaps [rsp+0xB0], xmm11
0000705c0add7325  vmovaps [rsp+0xC0], xmm12
0000705c0add732e  vmovaps [rsp+0xD0], xmm13
0000705c0add7337  vmovaps [rsp+0xE0], xmm14
0000705c0add7340  sub rsp, 0x30
0000705c0add7344  movaps [rsp], xmm15
0000705c0add7349  movaps [rsp+0x10], xmm14
0000705c0add734f  movaps [rsp+0x20], xmm9
0000705c0add7355  lea rdi, [rsp]
0000705c0add7359  mov esi, 0x00
0000705c0add735e  mov rax, 0x5969C28C4530
0000705c0add7368  call rax
0000705c0add736a  movaps xmm15, [rsp]
0000705c0add736f  add rsp, 0x30
0000705c0add7373  vmovaps xmm0, [rsp]
0000705c0add7378  vmovaps xmm1, [rsp+0x10]
0000705c0add737e  vmovaps xmm2, [rsp+0x20]
0000705c0add7384  vmovaps xmm3, [rsp+0x30]
0000705c0add738a  vmovaps xmm4, [rsp+0x40]
0000705c0add7390  vmovaps xmm5, [rsp+0x50]
0000705c0add7396  vmovaps xmm6, [rsp+0x60]
0000705c0add739c  vmovaps xmm7, [rsp+0x70]
0000705c0add73a2  vmovaps xmm8, [rsp+0x80]
0000705c0add73ab  vmovaps xmm9, [rsp+0x90]
0000705c0add73b4  vmovaps xmm10, [rsp+0xA0]
0000705c0add73bd  vmovaps xmm11, [rsp+0xB0]
0000705c0add73c6  vmovaps xmm12, [rsp+0xC0]
0000705c0add73cf  vmovaps xmm13, [rsp+0xD0]
0000705c0add73d8  vmovaps xmm14, [rsp+0xE0]
0000705c0add73e1  add rsp, 0xF0
0000705c0add73e8  pop r11
0000705c0add73ea  pop r10
0000705c0add73ec  pop r9
0000705c0add73ee  pop r8
0000705c0add73f0  pop rsi
0000705c0add73f1  pop rdi
0000705c0add73f2  pop rdx
0000705c0add73f3  pop rcx
0000705c0add73f4  pop rax
0000705c0add73f5  add rsp, 0x08
0000705c0add73f9  jmp 0x0000705C0ADD32E9
0000705c0add73fe  sub rsp, 0x08
0000705c0add7402  push rax
0000705c0add7403  push rcx
0000705c0add7404  push rdx
0000705c0add7405  push rdi
0000705c0add7406  push rsi
0000705c0add7407  push r8
0000705c0add7409  push r9
0000705c0add740b  push r10
0000705c0add740d  push r11
0000705c0add740f  sub rsp, 0xF0
0000705c0add7416  vmovaps [rsp], xmm0
0000705c0add741b  vmovaps [rsp+0x10], xmm1
0000705c0add7421  vmovaps [rsp+0x20], xmm2
0000705c0add7427  vmovaps [rsp+0x30], xmm3
0000705c0add742d  vmovaps [rsp+0x40], xmm4
0000705c0add7433  vmovaps [rsp+0x50], xmm5
0000705c0add7439  vmovaps [rsp+0x60], xmm6
0000705c0add743f  vmovaps [rsp+0x70], xmm7
0000705c0add7445  vmovaps [rsp+0x80], xmm8
0000705c0add744e  vmovaps [rsp+0x90], xmm10
0000705c0add7457  vmovaps [rsp+0xA0], xmm11
0000705c0add7460  vmovaps [rsp+0xB0], xmm12
0000705c0add7469  vmovaps [rsp+0xC0], xmm13
0000705c0add7472  vmovaps [rsp+0xD0], xmm14
0000705c0add747b  vmovaps [rsp+0xE0], xmm15
0000705c0add7484  sub rsp, 0x30
0000705c0add7488  movaps [rsp], xmm9
0000705c0add748d  movaps [rsp+0x10], xmm7
0000705c0add7492  movaps [rsp+0x20], xmm14
0000705c0add7498  lea rdi, [rsp]
0000705c0add749c  mov esi, 0x00
0000705c0add74a1  mov rax, 0x5969C28C4530
0000705c0add74ab  call rax
0000705c0add74ad  movaps xmm9, [rsp]
0000705c0add74b2  add rsp, 0x30
0000705c0add74b6  vmovaps xmm0, [rsp]
0000705c0add74bb  vmovaps xmm1, [rsp+0x10]
0000705c0add74c1  vmovaps xmm2, [rsp+0x20]
0000705c0add74c7  vmovaps xmm3, [rsp+0x30]
0000705c0add74cd  vmovaps xmm4, [rsp+0x40]
0000705c0add74d3  vmovaps xmm5, [rsp+0x50]
0000705c0add74d9  vmovaps xmm6, [rsp+0x60]
0000705c0add74df  vmovaps xmm7, [rsp+0x70]
0000705c0add74e5  vmovaps xmm8, [rsp+0x80]
0000705c0add74ee  vmovaps xmm10, [rsp+0x90]
0000705c0add74f7  vmovaps xmm11, [rsp+0xA0]
0000705c0add7500  vmovaps xmm12, [rsp+0xB0]
0000705c0add7509  vmovaps xmm13, [rsp+0xC0]
0000705c0add7512  vmovaps xmm14, [rsp+0xD0]
0000705c0add751b  vmovaps xmm15, [rsp+0xE0]
0000705c0add7524  add rsp, 0xF0
0000705c0add752b  pop r11
0000705c0add752d  pop r10
0000705c0add752f  pop r9
0000705c0add7531  pop r8
0000705c0add7533  pop rsi
0000705c0add7534  pop rdi
0000705c0add7535  pop rdx
0000705c0add7536  pop rcx
0000705c0add7537  pop rax
0000705c0add7538  add rsp, 0x08
0000705c0add753c  jmp 0x0000705C0ADD3318
0000705c0add7541  sub rsp, 0x08
0000705c0add7545  push rax
0000705c0add7546  push rcx
0000705c0add7547  push rdx
0000705c0add7548  push rdi
0000705c0add7549  push rsi
0000705c0add754a  push r8
0000705c0add754c  push r9
0000705c0add754e  push r10
0000705c0add7550  push r11
0000705c0add7552  sub rsp, 0xF0
0000705c0add7559  vmovaps [rsp], xmm0
0000705c0add755e  vmovaps [rsp+0x10], xmm1
0000705c0add7564  vmovaps [rsp+0x20], xmm2
0000705c0add756a  vmovaps [rsp+0x30], xmm3
0000705c0add7570  vmovaps [rsp+0x40], xmm4
0000705c0add7576  vmovaps [rsp+0x50], xmm5
0000705c0add757c  vmovaps [rsp+0x60], xmm6
0000705c0add7582  vmovaps [rsp+0x70], xmm7
0000705c0add7588  vmovaps [rsp+0x80], xmm8
0000705c0add7591  vmovaps [rsp+0x90], xmm9
0000705c0add759a  vmovaps [rsp+0xA0], xmm10
0000705c0add75a3  vmovaps [rsp+0xB0], xmm11
0000705c0add75ac  vmovaps [rsp+0xC0], xmm12
0000705c0add75b5  vmovaps [rsp+0xD0], xmm13
0000705c0add75be  vmovaps [rsp+0xE0], xmm15
0000705c0add75c7  sub rsp, 0x30
0000705c0add75cb  movaps [rsp], xmm14
0000705c0add75d0  movaps [rsp+0x10], xmm13
0000705c0add75d6  movaps [rsp+0x20], xmm11
0000705c0add75dc  lea rdi, [rsp]
0000705c0add75e0  mov esi, 0x00
0000705c0add75e5  mov rax, 0x5969C28C4530
0000705c0add75ef  call rax
0000705c0add75f1  movaps xmm14, [rsp]
0000705c0add75f6  add rsp, 0x30
0000705c0add75fa  vmovaps xmm0, [rsp]
0000705c0add75ff  vmovaps xmm1, [rsp+0x10]
0000705c0add7605  vmovaps xmm2, [rsp+0x20]
0000705c0add760b  vmovaps xmm3, [rsp+0x30]
0000705c0add7611  vmovaps xmm4, [rsp+0x40]
0000705c0add7617  vmovaps xmm5, [rsp+0x50]
0000705c0add761d  vmovaps xmm6, [rsp+0x60]
0000705c0add7623  vmovaps xmm7, [rsp+0x70]
0000705c0add7629  vmovaps xmm8, [rsp+0x80]
0000705c0add7632  vmovaps xmm9, [rsp+0x90]
0000705c0add763b  vmovaps xmm10, [rsp+0xA0]
0000705c0add7644  vmovaps xmm11, [rsp+0xB0]
0000705c0add764d  vmovaps xmm12, [rsp+0xC0]
0000705c0add7656  vmovaps xmm13, [rsp+0xD0]
0000705c0add765f  vmovaps xmm15, [rsp+0xE0]
0000705c0add7668  add rsp, 0xF0
0000705c0add766f  pop r11
0000705c0add7671  pop r10
0000705c0add7673  pop r9
0000705c0add7675  pop r8
0000705c0add7677  pop rsi
0000705c0add7678  pop rdi
0000705c0add7679  pop rdx
0000705c0add767a  pop rcx
0000705c0add767b  pop rax
0000705c0add767c  add rsp, 0x08
0000705c0add7680  jmp 0x0000705C0ADD3332
0000705c0add7685  sub rsp, 0x08
0000705c0add7689  push rax
0000705c0add768a  push rcx
0000705c0add768b  push rdx
0000705c0add768c  push rdi
0000705c0add768d  push rsi
0000705c0add768e  push r8
0000705c0add7690  push r9
0000705c0add7692  push r10
0000705c0add7694  push r11
0000705c0add7696  sub rsp, 0xF0
0000705c0add769d  vmovaps [rsp], xmm0
0000705c0add76a2  vmovaps [rsp+0x10], xmm1
0000705c0add76a8  vmovaps [rsp+0x20], xmm2
0000705c0add76ae  vmovaps [rsp+0x30], xmm3
0000705c0add76b4  vmovaps [rsp+0x40], xmm4
0000705c0add76ba  vmovaps [rsp+0x50], xmm5
0000705c0add76c0  vmovaps [rsp+0x60], xmm6
0000705c0add76c6  vmovaps [rsp+0x70], xmm7
0000705c0add76cc  vmovaps [rsp+0x80], xmm8
0000705c0add76d5  vmovaps [rsp+0x90], xmm9
0000705c0add76de  vmovaps [rsp+0xA0], xmm10
0000705c0add76e7  vmovaps [rsp+0xB0], xmm12
0000705c0add76f0  vmovaps [rsp+0xC0], xmm13
0000705c0add76f9  vmovaps [rsp+0xD0], xmm14
0000705c0add7702  vmovaps [rsp+0xE0], xmm15
0000705c0add770b  sub rsp, 0x30
0000705c0add770f  movaps [rsp], xmm11
0000705c0add7714  movaps [rsp+0x10], xmm7
0000705c0add7719  movaps [rsp+0x20], xmm13
0000705c0add771f  lea rdi, [rsp]
0000705c0add7723  mov esi, 0x00
0000705c0add7728  mov rax, 0x5969C28C4530
0000705c0add7732  call rax
0000705c0add7734  movaps xmm11, [rsp]
0000705c0add7739  add rsp, 0x30
0000705c0add773d  vmovaps xmm0, [rsp]
0000705c0add7742  vmovaps xmm1, [rsp+0x10]
0000705c0add7748  vmovaps xmm2, [rsp+0x20]
0000705c0add774e  vmovaps xmm3, [rsp+0x30]
0000705c0add7754  vmovaps xmm4, [rsp+0x40]
0000705c0add775a  vmovaps xmm5, [rsp+0x50]
0000705c0add7760  vmovaps xmm6, [rsp+0x60]
0000705c0add7766  vmovaps xmm7, [rsp+0x70]
0000705c0add776c  vmovaps xmm8, [rsp+0x80]
0000705c0add7775  vmovaps xmm9, [rsp+0x90]
0000705c0add777e  vmovaps xmm10, [rsp+0xA0]
0000705c0add7787  vmovaps xmm12, [rsp+0xB0]
0000705c0add7790  vmovaps xmm13, [rsp+0xC0]
0000705c0add7799  vmovaps xmm14, [rsp+0xD0]
0000705c0add77a2  vmovaps xmm15, [rsp+0xE0]
0000705c0add77ab  add rsp, 0xF0
0000705c0add77b2  pop r11
0000705c0add77b4  pop r10
0000705c0add77b6  pop r9
0000705c0add77b8  pop r8
0000705c0add77ba  pop rsi
0000705c0add77bb  pop rdi
0000705c0add77bc  pop rdx
0000705c0add77bd  pop rcx
0000705c0add77be  pop rax
0000705c0add77bf  add rsp, 0x08
0000705c0add77c3  jmp 0x0000705C0ADD335E
0000705c0add77c8  sub rsp, 0x08
0000705c0add77cc  push rax
0000705c0add77cd  push rcx
0000705c0add77ce  push rdx
0000705c0add77cf  push rdi
0000705c0add77d0  push rsi
0000705c0add77d1  push r8
0000705c0add77d3  push r9
0000705c0add77d5  push r10
0000705c0add77d7  push r11
0000705c0add77d9  sub rsp, 0xF0
0000705c0add77e0  vmovaps [rsp], xmm0
0000705c0add77e5  vmovaps [rsp+0x10], xmm1
0000705c0add77eb  vmovaps [rsp+0x20], xmm2
0000705c0add77f1  vmovaps [rsp+0x30], xmm3
0000705c0add77f7  vmovaps [rsp+0x40], xmm4
0000705c0add77fd  vmovaps [rsp+0x50], xmm5
0000705c0add7803  vmovaps [rsp+0x60], xmm6
0000705c0add7809  vmovaps [rsp+0x70], xmm7
0000705c0add780f  vmovaps [rsp+0x80], xmm8
0000705c0add7818  vmovaps [rsp+0x90], xmm9
0000705c0add7821  vmovaps [rsp+0xA0], xmm10
0000705c0add782a  vmovaps [rsp+0xB0], xmm11
0000705c0add7833  vmovaps [rsp+0xC0], xmm12
0000705c0add783c  vmovaps [rsp+0xD0], xmm14
0000705c0add7845  vmovaps [rsp+0xE0], xmm15
0000705c0add784e  sub rsp, 0x30
0000705c0add7852  movaps [rsp], xmm13
0000705c0add7857  movaps [rsp+0x10], xmm10
0000705c0add785d  movaps [rsp+0x20], xmm12
0000705c0add7863  lea rdi, [rsp]
0000705c0add7867  mov esi, 0x00
0000705c0add786c  mov rax, 0x5969C28C4530
0000705c0add7876  call rax
0000705c0add7878  movaps xmm13, [rsp]
0000705c0add787d  add rsp, 0x30
0000705c0add7881  vmovaps xmm0, [rsp]
0000705c0add7886  vmovaps xmm1, [rsp+0x10]
0000705c0add788c  vmovaps xmm2, [rsp+0x20]
0000705c0add7892  vmovaps xmm3, [rsp+0x30]
0000705c0add7898  vmovaps xmm4, [rsp+0x40]
0000705c0add789e  vmovaps xmm5, [rsp+0x50]
0000705c0add78a4  vmovaps xmm6, [rsp+0x60]
0000705c0add78aa  vmovaps xmm7, [rsp+0x70]
0000705c0add78b0  vmovaps xmm8, [rsp+0x80]
0000705c0add78b9  vmovaps xmm9, [rsp+0x90]
0000705c0add78c2  vmovaps xmm10, [rsp+0xA0]
0000705c0add78cb  vmovaps xmm11, [rsp+0xB0]
0000705c0add78d4  vmovaps xmm12, [rsp+0xC0]
0000705c0add78dd  vmovaps xmm14, [rsp+0xD0]
0000705c0add78e6  vmovaps xmm15, [rsp+0xE0]
0000705c0add78ef  add rsp, 0xF0
0000705c0add78f6  pop r11
0000705c0add78f8  pop r10
0000705c0add78fa  pop r9
0000705c0add78fc  pop r8
0000705c0add78fe  pop rsi
0000705c0add78ff  pop rdi
0000705c0add7900  pop rdx
0000705c0add7901  pop rcx
0000705c0add7902  pop rax
0000705c0add7903  add rsp, 0x08
0000705c0add7907  jmp 0x0000705C0ADD3378
0000705c0add790c  sub rsp, 0x08
0000705c0add7910  push rax
0000705c0add7911  push rcx
0000705c0add7912  push rdx
0000705c0add7913  push rdi
0000705c0add7914  push rsi
0000705c0add7915  push r8
0000705c0add7917  push r9
0000705c0add7919  push r10
0000705c0add791b  push r11
0000705c0add791d  sub rsp, 0xF0
0000705c0add7924  vmovaps [rsp], xmm0
0000705c0add7929  vmovaps [rsp+0x10], xmm1
0000705c0add792f  vmovaps [rsp+0x20], xmm2
0000705c0add7935  vmovaps [rsp+0x30], xmm3
0000705c0add793b  vmovaps [rsp+0x40], xmm4
0000705c0add7941  vmovaps [rsp+0x50], xmm5
0000705c0add7947  vmovaps [rsp+0x60], xmm6
0000705c0add794d  vmovaps [rsp+0x70], xmm7
0000705c0add7953  vmovaps [rsp+0x80], xmm8
0000705c0add795c  vmovaps [rsp+0x90], xmm9
0000705c0add7965  vmovaps [rsp+0xA0], xmm11
0000705c0add796e  vmovaps [rsp+0xB0], xmm12
0000705c0add7977  vmovaps [rsp+0xC0], xmm13
0000705c0add7980  vmovaps [rsp+0xD0], xmm14
0000705c0add7989  vmovaps [rsp+0xE0], xmm15
0000705c0add7992  sub rsp, 0x30
0000705c0add7996  movaps [rsp], xmm10
0000705c0add799b  movaps [rsp+0x10], xmm7
0000705c0add79a0  movaps [rsp+0x20], xmm12
0000705c0add79a6  lea rdi, [rsp]
0000705c0add79aa  mov esi, 0x00
0000705c0add79af  mov rax, 0x5969C28C4530
0000705c0add79b9  call rax
0000705c0add79bb  movaps xmm10, [rsp]
0000705c0add79c0  add rsp, 0x30
0000705c0add79c4  vmovaps xmm0, [rsp]
0000705c0add79c9  vmovaps xmm1, [rsp+0x10]
0000705c0add79cf  vmovaps xmm2, [rsp+0x20]
0000705c0add79d5  vmovaps xmm3, [rsp+0x30]
0000705c0add79db  vmovaps xmm4, [rsp+0x40]
0000705c0add79e1  vmovaps xmm5, [rsp+0x50]
0000705c0add79e7  vmovaps xmm6, [rsp+0x60]
0000705c0add79ed  vmovaps xmm7, [rsp+0x70]
0000705c0add79f3  vmovaps xmm8, [rsp+0x80]
0000705c0add79fc  vmovaps xmm9, [rsp+0x90]
0000705c0add7a05  vmovaps xmm11, [rsp+0xA0]
0000705c0add7a0e  vmovaps xmm12, [rsp+0xB0]
0000705c0add7a17  vmovaps xmm13, [rsp+0xC0]
0000705c0add7a20  vmovaps xmm14, [rsp+0xD0]
0000705c0add7a29  vmovaps xmm15, [rsp+0xE0]
0000705c0add7a32  add rsp, 0xF0
0000705c0add7a39  pop r11
0000705c0add7a3b  pop r10
0000705c0add7a3d  pop r9
0000705c0add7a3f  pop r8
0000705c0add7a41  pop rsi
0000705c0add7a42  pop rdi
0000705c0add7a43  pop rdx
0000705c0add7a44  pop rcx
0000705c0add7a45  pop rax
0000705c0add7a46  add rsp, 0x08
0000705c0add7a4a  jmp 0x0000705C0ADD33A4
0000705c0add7a4f  sub rsp, 0x08
0000705c0add7a53  push rax
0000705c0add7a54  push rcx
0000705c0add7a55  push rdx
0000705c0add7a56  push rdi
0000705c0add7a57  push rsi
0000705c0add7a58  push r8
0000705c0add7a5a  push r9
0000705c0add7a5c  push r10
0000705c0add7a5e  push r11
0000705c0add7a60  sub rsp, 0xF0
0000705c0add7a67  vmovaps [rsp], xmm0
0000705c0add7a6c  vmovaps [rsp+0x10], xmm1
0000705c0add7a72  vmovaps [rsp+0x20], xmm2
0000705c0add7a78  vmovaps [rsp+0x30], xmm3
0000705c0add7a7e  vmovaps [rsp+0x40], xmm4
0000705c0add7a84  vmovaps [rsp+0x50], xmm5
0000705c0add7a8a  vmovaps [rsp+0x60], xmm6
0000705c0add7a90  vmovaps [rsp+0x70], xmm7
0000705c0add7a96  vmovaps [rsp+0x80], xmm8
0000705c0add7a9f  vmovaps [rsp+0x90], xmm9
0000705c0add7aa8  vmovaps [rsp+0xA0], xmm10
0000705c0add7ab1  vmovaps [rsp+0xB0], xmm11
0000705c0add7aba  vmovaps [rsp+0xC0], xmm13
0000705c0add7ac3  vmovaps [rsp+0xD0], xmm14
0000705c0add7acc  vmovaps [rsp+0xE0], xmm15
0000705c0add7ad5  sub rsp, 0x30
0000705c0add7ad9  movaps [rsp], xmm12
0000705c0add7ade  movaps [rsp+0x10], xmm1
0000705c0add7ae3  movaps [rsp+0x20], xmm8
0000705c0add7ae9  lea rdi, [rsp]
0000705c0add7aed  mov esi, 0x00
0000705c0add7af2  mov rax, 0x5969C28C4530
0000705c0add7afc  call rax
0000705c0add7afe  movaps xmm12, [rsp]
0000705c0add7b03  add rsp, 0x30
0000705c0add7b07  vmovaps xmm0, [rsp]
0000705c0add7b0c  vmovaps xmm1, [rsp+0x10]
0000705c0add7b12  vmovaps xmm2, [rsp+0x20]
0000705c0add7b18  vmovaps xmm3, [rsp+0x30]
0000705c0add7b1e  vmovaps xmm4, [rsp+0x40]
0000705c0add7b24  vmovaps xmm5, [rsp+0x50]
0000705c0add7b2a  vmovaps xmm6, [rsp+0x60]
0000705c0add7b30  vmovaps xmm7, [rsp+0x70]
0000705c0add7b36  vmovaps xmm8, [rsp+0x80]
0000705c0add7b3f  vmovaps xmm9, [rsp+0x90]
0000705c0add7b48  vmovaps xmm10, [rsp+0xA0]
0000705c0add7b51  vmovaps xmm11, [rsp+0xB0]
0000705c0add7b5a  vmovaps xmm13, [rsp+0xC0]
0000705c0add7b63  vmovaps xmm14, [rsp+0xD0]
0000705c0add7b6c  vmovaps xmm15, [rsp+0xE0]
0000705c0add7b75  add rsp, 0xF0
0000705c0add7b7c  pop r11
0000705c0add7b7e  pop r10
0000705c0add7b80  pop r9
0000705c0add7b82  pop r8
0000705c0add7b84  pop rsi
0000705c0add7b85  pop rdi
0000705c0add7b86  pop rdx
0000705c0add7b87  pop rcx
0000705c0add7b88  pop rax
0000705c0add7b89  add rsp, 0x08
0000705c0add7b8d  jmp 0x0000705C0ADD33BE
0000705c0add7b92  call 0x0000705C0ABFF430
0000705c0add7b97  jmp 0x0000705C0ADD33C8
0000705c0add7b9c  sub rsp, 0x08
0000705c0add7ba0  push rax
0000705c0add7ba1  push rcx
0000705c0add7ba2  push rdx
0000705c0add7ba3  push rdi
0000705c0add7ba4  push rsi
0000705c0add7ba5  push r8
0000705c0add7ba7  push r9
0000705c0add7ba9  push r10
0000705c0add7bab  push r11
0000705c0add7bad  sub rsp, 0xF0
0000705c0add7bb4  vmovaps [rsp], xmm0
0000705c0add7bb9  vmovaps [rsp+0x10], xmm1
0000705c0add7bbf  vmovaps [rsp+0x20], xmm2
0000705c0add7bc5  vmovaps [rsp+0x30], xmm3
0000705c0add7bcb  vmovaps [rsp+0x40], xmm4
0000705c0add7bd1  vmovaps [rsp+0x50], xmm5
0000705c0add7bd7  vmovaps [rsp+0x60], xmm6
0000705c0add7bdd  vmovaps [rsp+0x70], xmm7
0000705c0add7be3  vmovaps [rsp+0x80], xmm9
0000705c0add7bec  vmovaps [rsp+0x90], xmm10
0000705c0add7bf5  vmovaps [rsp+0xA0], xmm11
0000705c0add7bfe  vmovaps [rsp+0xB0], xmm12
0000705c0add7c07  vmovaps [rsp+0xC0], xmm13
0000705c0add7c10  vmovaps [rsp+0xD0], xmm14
0000705c0add7c19  vmovaps [rsp+0xE0], xmm15
0000705c0add7c22  sub rsp, 0x30
0000705c0add7c26  movaps [rsp], xmm8
0000705c0add7c2b  movaps [rsp+0x10], xmm15
0000705c0add7c31  movaps [rsp+0x20], xmm9
0000705c0add7c37  lea rdi, [rsp]
0000705c0add7c3b  mov esi, 0x00
0000705c0add7c40  mov rax, 0x5969C28C4530
0000705c0add7c4a  call rax
0000705c0add7c4c  movaps xmm8, [rsp]
0000705c0add7c51  add rsp, 0x30
0000705c0add7c55  vmovaps xmm0, [rsp]
0000705c0add7c5a  vmovaps xmm1, [rsp+0x10]
0000705c0add7c60  vmovaps xmm2, [rsp+0x20]
0000705c0add7c66  vmovaps xmm3, [rsp+0x30]
0000705c0add7c6c  vmovaps xmm4, [rsp+0x40]
0000705c0add7c72  vmovaps xmm5, [rsp+0x50]
0000705c0add7c78  vmovaps xmm6, [rsp+0x60]
0000705c0add7c7e  vmovaps xmm7, [rsp+0x70]
0000705c0add7c84  vmovaps xmm9, [rsp+0x80]
0000705c0add7c8d  vmovaps xmm10, [rsp+0x90]
0000705c0add7c96  vmovaps xmm11, [rsp+0xA0]
0000705c0add7c9f  vmovaps xmm12, [rsp+0xB0]
0000705c0add7ca8  vmovaps xmm13, [rsp+0xC0]
0000705c0add7cb1  vmovaps xmm14, [rsp+0xD0]
0000705c0add7cba  vmovaps xmm15, [rsp+0xE0]
0000705c0add7cc3  add rsp, 0xF0
0000705c0add7cca  pop r11
0000705c0add7ccc  pop r10
0000705c0add7cce  pop r9
0000705c0add7cd0  pop r8
0000705c0add7cd2  pop rsi
0000705c0add7cd3  pop rdi
0000705c0add7cd4  pop rdx
0000705c0add7cd5  pop rcx
0000705c0add7cd6  pop rax
0000705c0add7cd7  add rsp, 0x08
0000705c0add7cdb  jmp 0x0000705C0ADD33EA
0000705c0add7ce0  sub rsp, 0x08
0000705c0add7ce4  push rax
0000705c0add7ce5  push rcx
0000705c0add7ce6  push rdx
0000705c0add7ce7  push rdi
0000705c0add7ce8  push rsi
0000705c0add7ce9  push r8
0000705c0add7ceb  push r9
0000705c0add7ced  push r10
0000705c0add7cef  push r11
0000705c0add7cf1  sub rsp, 0xF0
0000705c0add7cf8  vmovaps [rsp], xmm0
0000705c0add7cfd  vmovaps [rsp+0x10], xmm1
0000705c0add7d03  vmovaps [rsp+0x20], xmm2
0000705c0add7d09  vmovaps [rsp+0x30], xmm3
0000705c0add7d0f  vmovaps [rsp+0x40], xmm4
0000705c0add7d15  vmovaps [rsp+0x50], xmm5
0000705c0add7d1b  vmovaps [rsp+0x60], xmm6
0000705c0add7d21  vmovaps [rsp+0x70], xmm7
0000705c0add7d27  vmovaps [rsp+0x80], xmm8
0000705c0add7d30  vmovaps [rsp+0x90], xmm10
0000705c0add7d39  vmovaps [rsp+0xA0], xmm11
0000705c0add7d42  vmovaps [rsp+0xB0], xmm12
0000705c0add7d4b  vmovaps [rsp+0xC0], xmm13
0000705c0add7d54  vmovaps [rsp+0xD0], xmm14
0000705c0add7d5d  vmovaps [rsp+0xE0], xmm15
0000705c0add7d66  sub rsp, 0x30
0000705c0add7d6a  movaps [rsp], xmm9
0000705c0add7d6f  movaps [rsp+0x10], xmm1
0000705c0add7d74  movaps [rsp+0x20], xmm15
0000705c0add7d7a  lea rdi, [rsp]
0000705c0add7d7e  mov esi, 0x00
0000705c0add7d83  mov rax, 0x5969C28C4530
0000705c0add7d8d  call rax
0000705c0add7d8f  movaps xmm9, [rsp]
0000705c0add7d94  add rsp, 0x30
0000705c0add7d98  vmovaps xmm0, [rsp]
0000705c0add7d9d  vmovaps xmm1, [rsp+0x10]
0000705c0add7da3  vmovaps xmm2, [rsp+0x20]
0000705c0add7da9  vmovaps xmm3, [rsp+0x30]
0000705c0add7daf  vmovaps xmm4, [rsp+0x40]
0000705c0add7db5  vmovaps xmm5, [rsp+0x50]
0000705c0add7dbb  vmovaps xmm6, [rsp+0x60]
0000705c0add7dc1  vmovaps xmm7, [rsp+0x70]
0000705c0add7dc7  vmovaps xmm8, [rsp+0x80]
0000705c0add7dd0  vmovaps xmm10, [rsp+0x90]
0000705c0add7dd9  vmovaps xmm11, [rsp+0xA0]
0000705c0add7de2  vmovaps xmm12, [rsp+0xB0]
0000705c0add7deb  vmovaps xmm13, [rsp+0xC0]
0000705c0add7df4  vmovaps xmm14, [rsp+0xD0]
0000705c0add7dfd  vmovaps xmm15, [rsp+0xE0]
0000705c0add7e06  add rsp, 0xF0
0000705c0add7e0d  pop r11
0000705c0add7e0f  pop r10
0000705c0add7e11  pop r9
0000705c0add7e13  pop r8
0000705c0add7e15  pop rsi
0000705c0add7e16  pop rdi
0000705c0add7e17  pop rdx
0000705c0add7e18  pop rcx
0000705c0add7e19  pop rax
0000705c0add7e1a  add rsp, 0x08
0000705c0add7e1e  jmp 0x0000705C0ADD3418
0000705c0add7e23  sub rsp, 0x08
0000705c0add7e27  push rax
0000705c0add7e28  push rcx
0000705c0add7e29  push rdx
0000705c0add7e2a  push rdi
0000705c0add7e2b  push rsi
0000705c0add7e2c  push r8
0000705c0add7e2e  push r9
0000705c0add7e30  push r10
0000705c0add7e32  push r11
0000705c0add7e34  sub rsp, 0xF0
0000705c0add7e3b  vmovaps [rsp], xmm0
0000705c0add7e40  vmovaps [rsp+0x10], xmm1
0000705c0add7e46  vmovaps [rsp+0x20], xmm2
0000705c0add7e4c  vmovaps [rsp+0x30], xmm3
0000705c0add7e52  vmovaps [rsp+0x40], xmm4
0000705c0add7e58  vmovaps [rsp+0x50], xmm5
0000705c0add7e5e  vmovaps [rsp+0x60], xmm6
0000705c0add7e64  vmovaps [rsp+0x70], xmm7
0000705c0add7e6a  vmovaps [rsp+0x80], xmm8
0000705c0add7e73  vmovaps [rsp+0x90], xmm9
0000705c0add7e7c  vmovaps [rsp+0xA0], xmm10
0000705c0add7e85  vmovaps [rsp+0xB0], xmm11
0000705c0add7e8e  vmovaps [rsp+0xC0], xmm12
0000705c0add7e97  vmovaps [rsp+0xD0], xmm13
0000705c0add7ea0  vmovaps [rsp+0xE0], xmm14
0000705c0add7ea9  sub rsp, 0x30
0000705c0add7ead  movaps [rsp], xmm15
0000705c0add7eb2  movaps [rsp+0x10], xmm4
0000705c0add7eb7  movaps [rsp+0x20], xmm1
0000705c0add7ebc  lea rdi, [rsp]
0000705c0add7ec0  mov esi, 0x00
0000705c0add7ec5  mov rax, 0x5969C28C4530
0000705c0add7ecf  call rax
0000705c0add7ed1  movaps xmm15, [rsp]
0000705c0add7ed6  add rsp, 0x30
0000705c0add7eda  vmovaps xmm0, [rsp]
0000705c0add7edf  vmovaps xmm1, [rsp+0x10]
0000705c0add7ee5  vmovaps xmm2, [rsp+0x20]
0000705c0add7eeb  vmovaps xmm3, [rsp+0x30]
0000705c0add7ef1  vmovaps xmm4, [rsp+0x40]
0000705c0add7ef7  vmovaps xmm5, [rsp+0x50]
0000705c0add7efd  vmovaps xmm6, [rsp+0x60]
0000705c0add7f03  vmovaps xmm7, [rsp+0x70]
0000705c0add7f09  vmovaps xmm8, [rsp+0x80]
0000705c0add7f12  vmovaps xmm9, [rsp+0x90]
0000705c0add7f1b  vmovaps xmm10, [rsp+0xA0]
0000705c0add7f24  vmovaps xmm11, [rsp+0xB0]
0000705c0add7f2d  vmovaps xmm12, [rsp+0xC0]
0000705c0add7f36  vmovaps xmm13, [rsp+0xD0]
0000705c0add7f3f  vmovaps xmm14, [rsp+0xE0]
0000705c0add7f48  add rsp, 0xF0
0000705c0add7f4f  pop r11
0000705c0add7f51  pop r10
0000705c0add7f53  pop r9
0000705c0add7f55  pop r8
0000705c0add7f57  pop rsi
0000705c0add7f58  pop rdi
0000705c0add7f59  pop rdx
0000705c0add7f5a  pop rcx
0000705c0add7f5b  pop rax
0000705c0add7f5c  add rsp, 0x08
0000705c0add7f60  jmp 0x0000705C0ADD343E
0000705c0add7f65  sub rsp, 0x08
0000705c0add7f69  push rax
0000705c0add7f6a  push rcx
0000705c0add7f6b  push rdx
0000705c0add7f6c  push rdi
0000705c0add7f6d  push rsi
0000705c0add7f6e  push r8
0000705c0add7f70  push r9
0000705c0add7f72  push r10
0000705c0add7f74  push r11
0000705c0add7f76  sub rsp, 0xF0
0000705c0add7f7d  vmovaps [rsp], xmm0
0000705c0add7f82  vmovaps [rsp+0x10], xmm2
0000705c0add7f88  vmovaps [rsp+0x20], xmm3
0000705c0add7f8e  vmovaps [rsp+0x30], xmm4
0000705c0add7f94  vmovaps [rsp+0x40], xmm5
0000705c0add7f9a  vmovaps [rsp+0x50], xmm6
0000705c0add7fa0  vmovaps [rsp+0x60], xmm7
0000705c0add7fa6  vmovaps [rsp+0x70], xmm8
0000705c0add7fac  vmovaps [rsp+0x80], xmm9
0000705c0add7fb5  vmovaps [rsp+0x90], xmm10
0000705c0add7fbe  vmovaps [rsp+0xA0], xmm11
0000705c0add7fc7  vmovaps [rsp+0xB0], xmm12
0000705c0add7fd0  vmovaps [rsp+0xC0], xmm13
0000705c0add7fd9  vmovaps [rsp+0xD0], xmm14
0000705c0add7fe2  vmovaps [rsp+0xE0], xmm15
0000705c0add7feb  sub rsp, 0x30
0000705c0add7fef  movaps [rsp], xmm1
0000705c0add7ff3  movaps [rsp+0x10], xmm14
0000705c0add7ff9  movaps [rsp+0x20], xmm11
0000705c0add7fff  lea rdi, [rsp]
0000705c0add8003  mov esi, 0x00
0000705c0add8008  mov rax, 0x5969C28C4530
0000705c0add8012  call rax
0000705c0add8014  movaps xmm1, [rsp]
0000705c0add8018  add rsp, 0x30
0000705c0add801c  vmovaps xmm0, [rsp]
0000705c0add8021  vmovaps xmm2, [rsp+0x10]
0000705c0add8027  vmovaps xmm3, [rsp+0x20]
0000705c0add802d  vmovaps xmm4, [rsp+0x30]
0000705c0add8033  vmovaps xmm5, [rsp+0x40]
0000705c0add8039  vmovaps xmm6, [rsp+0x50]
0000705c0add803f  vmovaps xmm7, [rsp+0x60]
0000705c0add8045  vmovaps xmm8, [rsp+0x70]
0000705c0add804b  vmovaps xmm9, [rsp+0x80]
0000705c0add8054  vmovaps xmm10, [rsp+0x90]
0000705c0add805d  vmovaps xmm11, [rsp+0xA0]
0000705c0add8066  vmovaps xmm12, [rsp+0xB0]
0000705c0add806f  vmovaps xmm13, [rsp+0xC0]
0000705c0add8078  vmovaps xmm14, [rsp+0xD0]
0000705c0add8081  vmovaps xmm15, [rsp+0xE0]
0000705c0add808a  add rsp, 0xF0
0000705c0add8091  pop r11
0000705c0add8093  pop r10
0000705c0add8095  pop r9
0000705c0add8097  pop r8
0000705c0add8099  pop rsi
0000705c0add809a  pop rdi
0000705c0add809b  pop rdx
0000705c0add809c  pop rcx
0000705c0add809d  pop rax
0000705c0add809e  add rsp, 0x08
0000705c0add80a2  jmp 0x0000705C0ADD345F
0000705c0add80a7  call 0x0000705C0ACE45A0
0000705c0add80ac  jmp 0x0000705C0ADD346D
0000705c0add80b1  call 0x0000705C0AC09D70
0000705c0add80b6  jmp 0x0000705C0ADD3477
0000705c0add80bb  sub rsp, 0x08
0000705c0add80bf  push rax
0000705c0add80c0  push rcx
0000705c0add80c1  push rdx
0000705c0add80c2  push rdi
0000705c0add80c3  push rsi
0000705c0add80c4  push r8
0000705c0add80c6  push r9
0000705c0add80c8  push r10
0000705c0add80ca  push r11
0000705c0add80cc  sub rsp, 0xF0
0000705c0add80d3  vmovaps [rsp], xmm0
0000705c0add80d8  vmovaps [rsp+0x10], xmm1
0000705c0add80de  vmovaps [rsp+0x20], xmm2
0000705c0add80e4  vmovaps [rsp+0x30], xmm3
0000705c0add80ea  vmovaps [rsp+0x40], xmm4
0000705c0add80f0  vmovaps [rsp+0x50], xmm5
0000705c0add80f6  vmovaps [rsp+0x60], xmm6
0000705c0add80fc  vmovaps [rsp+0x70], xmm8
0000705c0add8102  vmovaps [rsp+0x80], xmm9
0000705c0add810b  vmovaps [rsp+0x90], xmm10
0000705c0add8114  vmovaps [rsp+0xA0], xmm11
0000705c0add811d  vmovaps [rsp+0xB0], xmm12
0000705c0add8126  vmovaps [rsp+0xC0], xmm13
0000705c0add812f  vmovaps [rsp+0xD0], xmm14
0000705c0add8138  vmovaps [rsp+0xE0], xmm15
0000705c0add8141  sub rsp, 0x30
0000705c0add8145  movaps [rsp], xmm7
0000705c0add8149  movaps [rsp+0x10], xmm13
0000705c0add814f  movaps [rsp+0x20], xmm10
0000705c0add8155  lea rdi, [rsp]
0000705c0add8159  mov esi, 0x00
0000705c0add815e  mov rax, 0x5969C28C4530
0000705c0add8168  call rax
0000705c0add816a  movaps xmm7, [rsp]
0000705c0add816e  add rsp, 0x30
0000705c0add8172  vmovaps xmm0, [rsp]
0000705c0add8177  vmovaps xmm1, [rsp+0x10]
0000705c0add817d  vmovaps xmm2, [rsp+0x20]
0000705c0add8183  vmovaps xmm3, [rsp+0x30]
0000705c0add8189  vmovaps xmm4, [rsp+0x40]
0000705c0add818f  vmovaps xmm5, [rsp+0x50]
0000705c0add8195  vmovaps xmm6, [rsp+0x60]
0000705c0add819b  vmovaps xmm8, [rsp+0x70]
0000705c0add81a1  vmovaps xmm9, [rsp+0x80]
0000705c0add81aa  vmovaps xmm10, [rsp+0x90]
0000705c0add81b3  vmovaps xmm11, [rsp+0xA0]
0000705c0add81bc  vmovaps xmm12, [rsp+0xB0]
0000705c0add81c5  vmovaps xmm13, [rsp+0xC0]
0000705c0add81ce  vmovaps xmm14, [rsp+0xD0]
0000705c0add81d7  vmovaps xmm15, [rsp+0xE0]
0000705c0add81e0  add rsp, 0xF0
0000705c0add81e7  pop r11
0000705c0add81e9  pop r10
0000705c0add81eb  pop r9
0000705c0add81ed  pop r8
0000705c0add81ef  pop rsi
0000705c0add81f0  pop rdi
0000705c0add81f1  pop rdx
0000705c0add81f2  pop rcx
0000705c0add81f3  pop rax
0000705c0add81f4  add rsp, 0x08
0000705c0add81f8  jmp 0x0000705C0ADD3498
0000705c0add81fd  sub rsp, 0x08
0000705c0add8201  push rax
0000705c0add8202  push rcx
0000705c0add8203  push rdx
0000705c0add8204  push rdi
0000705c0add8205  push rsi
0000705c0add8206  push r8
0000705c0add8208  push r9
0000705c0add820a  push r10
0000705c0add820c  push r11
0000705c0add820e  sub rsp, 0xF0
0000705c0add8215  vmovaps [rsp], xmm0
0000705c0add821a  vmovaps [rsp+0x10], xmm1
0000705c0add8220  vmovaps [rsp+0x20], xmm2
0000705c0add8226  vmovaps [rsp+0x30], xmm3
0000705c0add822c  vmovaps [rsp+0x40], xmm4
0000705c0add8232  vmovaps [rsp+0x50], xmm5
0000705c0add8238  vmovaps [rsp+0x60], xmm6
0000705c0add823e  vmovaps [rsp+0x70], xmm7
0000705c0add8244  vmovaps [rsp+0x80], xmm8
0000705c0add824d  vmovaps [rsp+0x90], xmm9
0000705c0add8256  vmovaps [rsp+0xA0], xmm11
0000705c0add825f  vmovaps [rsp+0xB0], xmm12
0000705c0add8268  vmovaps [rsp+0xC0], xmm13
0000705c0add8271  vmovaps [rsp+0xD0], xmm14
0000705c0add827a  vmovaps [rsp+0xE0], xmm15
0000705c0add8283  sub rsp, 0x30
0000705c0add8287  movaps [rsp], xmm10
0000705c0add828c  movaps [rsp+0x10], xmm11
0000705c0add8292  movaps [rsp+0x20], xmm13
0000705c0add8298  lea rdi, [rsp]
0000705c0add829c  mov esi, 0x00
0000705c0add82a1  mov rax, 0x5969C28C4530
0000705c0add82ab  call rax
0000705c0add82ad  movaps xmm10, [rsp]
0000705c0add82b2  add rsp, 0x30
0000705c0add82b6  vmovaps xmm0, [rsp]
0000705c0add82bb  vmovaps xmm1, [rsp+0x10]
0000705c0add82c1  vmovaps xmm2, [rsp+0x20]
0000705c0add82c7  vmovaps xmm3, [rsp+0x30]
0000705c0add82cd  vmovaps xmm4, [rsp+0x40]
0000705c0add82d3  vmovaps xmm5, [rsp+0x50]
0000705c0add82d9  vmovaps xmm6, [rsp+0x60]
0000705c0add82df  vmovaps xmm7, [rsp+0x70]
0000705c0add82e5  vmovaps xmm8, [rsp+0x80]
0000705c0add82ee  vmovaps xmm9, [rsp+0x90]
0000705c0add82f7  vmovaps xmm11, [rsp+0xA0]
0000705c0add8300  vmovaps xmm12, [rsp+0xB0]
0000705c0add8309  vmovaps xmm13, [rsp+0xC0]
0000705c0add8312  vmovaps xmm14, [rsp+0xD0]
0000705c0add831b  vmovaps xmm15, [rsp+0xE0]
0000705c0add8324  add rsp, 0xF0
0000705c0add832b  pop r11
0000705c0add832d  pop r10
0000705c0add832f  pop r9
0000705c0add8331  pop r8
0000705c0add8333  pop rsi
0000705c0add8334  pop rdi
0000705c0add8335  pop rdx
0000705c0add8336  pop rcx
0000705c0add8337  pop rax
0000705c0add8338  add rsp, 0x08
0000705c0add833c  jmp 0x0000705C0ADD34C6
0000705c0add8341  sub rsp, 0x08
0000705c0add8345  push rax
0000705c0add8346  push rcx
0000705c0add8347  push rdx
0000705c0add8348  push rdi
0000705c0add8349  push rsi
0000705c0add834a  push r8
0000705c0add834c  push r9
0000705c0add834e  push r10
0000705c0add8350  push r11
0000705c0add8352  sub rsp, 0xF0
0000705c0add8359  vmovaps [rsp], xmm0
0000705c0add835e  vmovaps [rsp+0x10], xmm1
0000705c0add8364  vmovaps [rsp+0x20], xmm2
0000705c0add836a  vmovaps [rsp+0x30], xmm3
0000705c0add8370  vmovaps [rsp+0x40], xmm4
0000705c0add8376  vmovaps [rsp+0x50], xmm5
0000705c0add837c  vmovaps [rsp+0x60], xmm6
0000705c0add8382  vmovaps [rsp+0x70], xmm7
0000705c0add8388  vmovaps [rsp+0x80], xmm8
0000705c0add8391  vmovaps [rsp+0x90], xmm9
0000705c0add839a  vmovaps [rsp+0xA0], xmm10
0000705c0add83a3  vmovaps [rsp+0xB0], xmm12
0000705c0add83ac  vmovaps [rsp+0xC0], xmm13
0000705c0add83b5  vmovaps [rsp+0xD0], xmm14
0000705c0add83be  vmovaps [rsp+0xE0], xmm15
0000705c0add83c7  sub rsp, 0x30
0000705c0add83cb  movaps [rsp], xmm11
0000705c0add83d0  movaps [rsp+0x10], xmm14
0000705c0add83d6  movaps [rsp+0x20], xmm13
0000705c0add83dc  lea rdi, [rsp]
0000705c0add83e0  mov esi, 0x00
0000705c0add83e5  mov rax, 0x5969C28C4530
0000705c0add83ef  call rax
0000705c0add83f1  movaps xmm11, [rsp]
0000705c0add83f6  add rsp, 0x30
0000705c0add83fa  vmovaps xmm0, [rsp]
0000705c0add83ff  vmovaps xmm1, [rsp+0x10]
0000705c0add8405  vmovaps xmm2, [rsp+0x20]
0000705c0add840b  vmovaps xmm3, [rsp+0x30]
0000705c0add8411  vmovaps xmm4, [rsp+0x40]
0000705c0add8417  vmovaps xmm5, [rsp+0x50]
0000705c0add841d  vmovaps xmm6, [rsp+0x60]
0000705c0add8423  vmovaps xmm7, [rsp+0x70]
0000705c0add8429  vmovaps xmm8, [rsp+0x80]
0000705c0add8432  vmovaps xmm9, [rsp+0x90]
0000705c0add843b  vmovaps xmm10, [rsp+0xA0]
0000705c0add8444  vmovaps xmm12, [rsp+0xB0]
0000705c0add844d  vmovaps xmm13, [rsp+0xC0]
0000705c0add8456  vmovaps xmm14, [rsp+0xD0]
0000705c0add845f  vmovaps xmm15, [rsp+0xE0]
0000705c0add8468  add rsp, 0xF0
0000705c0add846f  pop r11
0000705c0add8471  pop r10
0000705c0add8473  pop r9
0000705c0add8475  pop r8
0000705c0add8477  pop rsi
0000705c0add8478  pop rdi
0000705c0add8479  pop rdx
0000705c0add847a  pop rcx
0000705c0add847b  pop rax
0000705c0add847c  add rsp, 0x08
0000705c0add8480  jmp 0x0000705C0ADD34F4
0000705c0add8485  sub rsp, 0x08
0000705c0add8489  push rax
0000705c0add848a  push rcx
0000705c0add848b  push rdx
0000705c0add848c  push rdi
0000705c0add848d  push rsi
0000705c0add848e  push r8
0000705c0add8490  push r9
0000705c0add8492  push r10
0000705c0add8494  push r11
0000705c0add8496  sub rsp, 0xF0
0000705c0add849d  vmovaps [rsp], xmm0
0000705c0add84a2  vmovaps [rsp+0x10], xmm1
0000705c0add84a8  vmovaps [rsp+0x20], xmm2
0000705c0add84ae  vmovaps [rsp+0x30], xmm3
0000705c0add84b4  vmovaps [rsp+0x40], xmm4
0000705c0add84ba  vmovaps [rsp+0x50], xmm5
0000705c0add84c0  vmovaps [rsp+0x60], xmm6
0000705c0add84c6  vmovaps [rsp+0x70], xmm7
0000705c0add84cc  vmovaps [rsp+0x80], xmm8
0000705c0add84d5  vmovaps [rsp+0x90], xmm9
0000705c0add84de  vmovaps [rsp+0xA0], xmm10
0000705c0add84e7  vmovaps [rsp+0xB0], xmm11
0000705c0add84f0  vmovaps [rsp+0xC0], xmm12
0000705c0add84f9  vmovaps [rsp+0xD0], xmm13
0000705c0add8502  vmovaps [rsp+0xE0], xmm15
0000705c0add850b  sub rsp, 0x30
0000705c0add850f  movaps [rsp], xmm14
0000705c0add8514  movaps [rsp+0x10], xmm12
0000705c0add851a  movaps [rsp+0x20], xmm9
0000705c0add8520  lea rdi, [rsp]
0000705c0add8524  mov esi, 0x00
0000705c0add8529  mov rax, 0x5969C28C4530
0000705c0add8533  call rax
0000705c0add8535  movaps xmm14, [rsp]
0000705c0add853a  add rsp, 0x30
0000705c0add853e  vmovaps xmm0, [rsp]
0000705c0add8543  vmovaps xmm1, [rsp+0x10]
0000705c0add8549  vmovaps xmm2, [rsp+0x20]
0000705c0add854f  vmovaps xmm3, [rsp+0x30]
0000705c0add8555  vmovaps xmm4, [rsp+0x40]
0000705c0add855b  vmovaps xmm5, [rsp+0x50]
0000705c0add8561  vmovaps xmm6, [rsp+0x60]
0000705c0add8567  vmovaps xmm7, [rsp+0x70]
0000705c0add856d  vmovaps xmm8, [rsp+0x80]
0000705c0add8576  vmovaps xmm9, [rsp+0x90]
0000705c0add857f  vmovaps xmm10, [rsp+0xA0]
0000705c0add8588  vmovaps xmm11, [rsp+0xB0]
0000705c0add8591  vmovaps xmm12, [rsp+0xC0]
0000705c0add859a  vmovaps xmm13, [rsp+0xD0]
0000705c0add85a3  vmovaps xmm15, [rsp+0xE0]
0000705c0add85ac  add rsp, 0xF0
0000705c0add85b3  pop r11
0000705c0add85b5  pop r10
0000705c0add85b7  pop r9
0000705c0add85b9  pop r8
0000705c0add85bb  pop rsi
0000705c0add85bc  pop rdi
0000705c0add85bd  pop rdx
0000705c0add85be  pop rcx
0000705c0add85bf  pop rax
0000705c0add85c0  add rsp, 0x08
0000705c0add85c4  jmp 0x0000705C0ADD350F
0000705c0add85c9  sub rsp, 0x08
0000705c0add85cd  push rax
0000705c0add85ce  push rcx
0000705c0add85cf  push rdx
0000705c0add85d0  push rdi
0000705c0add85d1  push rsi
0000705c0add85d2  push r8
0000705c0add85d4  push r9
0000705c0add85d6  push r10
0000705c0add85d8  push r11
0000705c0add85da  sub rsp, 0xF0
0000705c0add85e1  vmovaps [rsp], xmm0
0000705c0add85e6  vmovaps [rsp+0x10], xmm1
0000705c0add85ec  vmovaps [rsp+0x20], xmm2
0000705c0add85f2  vmovaps [rsp+0x30], xmm3
0000705c0add85f8  vmovaps [rsp+0x40], xmm4
0000705c0add85fe  vmovaps [rsp+0x50], xmm5
0000705c0add8604  vmovaps [rsp+0x60], xmm6
0000705c0add860a  vmovaps [rsp+0x70], xmm7
0000705c0add8610  vmovaps [rsp+0x80], xmm8
0000705c0add8619  vmovaps [rsp+0x90], xmm9
0000705c0add8622  vmovaps [rsp+0xA0], xmm10
0000705c0add862b  vmovaps [rsp+0xB0], xmm11
0000705c0add8634  vmovaps [rsp+0xC0], xmm12
0000705c0add863d  vmovaps [rsp+0xD0], xmm14
0000705c0add8646  vmovaps [rsp+0xE0], xmm15
0000705c0add864f  sub rsp, 0x30
0000705c0add8653  movaps [rsp], xmm13
0000705c0add8658  movaps [rsp+0x10], xmm8
0000705c0add865e  movaps [rsp+0x20], xmm15
0000705c0add8664  lea rdi, [rsp]
0000705c0add8668  mov esi, 0x00
0000705c0add866d  mov rax, 0x5969C28C4530
0000705c0add8677  call rax
0000705c0add8679  movaps xmm13, [rsp]
0000705c0add867e  add rsp, 0x30
0000705c0add8682  vmovaps xmm0, [rsp]
0000705c0add8687  vmovaps xmm1, [rsp+0x10]
0000705c0add868d  vmovaps xmm2, [rsp+0x20]
0000705c0add8693  vmovaps xmm3, [rsp+0x30]
0000705c0add8699  vmovaps xmm4, [rsp+0x40]
0000705c0add869f  vmovaps xmm5, [rsp+0x50]
0000705c0add86a5  vmovaps xmm6, [rsp+0x60]
0000705c0add86ab  vmovaps xmm7, [rsp+0x70]
0000705c0add86b1  vmovaps xmm8, [rsp+0x80]
0000705c0add86ba  vmovaps xmm9, [rsp+0x90]
0000705c0add86c3  vmovaps xmm10, [rsp+0xA0]
0000705c0add86cc  vmovaps xmm11, [rsp+0xB0]
0000705c0add86d5  vmovaps xmm12, [rsp+0xC0]
0000705c0add86de  vmovaps xmm14, [rsp+0xD0]
0000705c0add86e7  vmovaps xmm15, [rsp+0xE0]
0000705c0add86f0  add rsp, 0xF0
0000705c0add86f7  pop r11
0000705c0add86f9  pop r10
0000705c0add86fb  pop r9
0000705c0add86fd  pop r8
0000705c0add86ff  pop rsi
0000705c0add8700  pop rdi
0000705c0add8701  pop rdx
0000705c0add8702  pop rcx
0000705c0add8703  pop rax
0000705c0add8704  add rsp, 0x08
0000705c0add8708  jmp 0x0000705C0ADD3532
0000705c0add870d  sub rsp, 0x08
0000705c0add8711  push rax
0000705c0add8712  push rcx
0000705c0add8713  push rdx
0000705c0add8714  push rdi
0000705c0add8715  push rsi
0000705c0add8716  push r8
0000705c0add8718  push r9
0000705c0add871a  push r10
0000705c0add871c  push r11
0000705c0add871e  sub rsp, 0xF0
0000705c0add8725  vmovaps [rsp], xmm0
0000705c0add872a  vmovaps [rsp+0x10], xmm1
0000705c0add8730  vmovaps [rsp+0x20], xmm2
0000705c0add8736  vmovaps [rsp+0x30], xmm3
0000705c0add873c  vmovaps [rsp+0x40], xmm4
0000705c0add8742  vmovaps [rsp+0x50], xmm5
0000705c0add8748  vmovaps [rsp+0x60], xmm6
0000705c0add874e  vmovaps [rsp+0x70], xmm7
0000705c0add8754  vmovaps [rsp+0x80], xmm8
0000705c0add875d  vmovaps [rsp+0x90], xmm9
0000705c0add8766  vmovaps [rsp+0xA0], xmm10
0000705c0add876f  vmovaps [rsp+0xB0], xmm11
0000705c0add8778  vmovaps [rsp+0xC0], xmm12
0000705c0add8781  vmovaps [rsp+0xD0], xmm13
0000705c0add878a  vmovaps [rsp+0xE0], xmm14
0000705c0add8793  sub rsp, 0x30
0000705c0add8797  movaps [rsp], xmm15
0000705c0add879c  movaps [rsp+0x10], xmm1
0000705c0add87a1  movaps [rsp+0x20], xmm10
0000705c0add87a7  lea rdi, [rsp]
0000705c0add87ab  mov esi, 0x00
0000705c0add87b0  mov rax, 0x5969C28C4530
0000705c0add87ba  call rax
0000705c0add87bc  movaps xmm15, [rsp]
0000705c0add87c1  add rsp, 0x30
0000705c0add87c5  vmovaps xmm0, [rsp]
0000705c0add87ca  vmovaps xmm1, [rsp+0x10]
0000705c0add87d0  vmovaps xmm2, [rsp+0x20]
0000705c0add87d6  vmovaps xmm3, [rsp+0x30]
0000705c0add87dc  vmovaps xmm4, [rsp+0x40]
0000705c0add87e2  vmovaps xmm5, [rsp+0x50]
0000705c0add87e8  vmovaps xmm6, [rsp+0x60]
0000705c0add87ee  vmovaps xmm7, [rsp+0x70]
0000705c0add87f4  vmovaps xmm8, [rsp+0x80]
0000705c0add87fd  vmovaps xmm9, [rsp+0x90]
0000705c0add8806  vmovaps xmm10, [rsp+0xA0]
0000705c0add880f  vmovaps xmm11, [rsp+0xB0]
0000705c0add8818  vmovaps xmm12, [rsp+0xC0]
0000705c0add8821  vmovaps xmm13, [rsp+0xD0]
0000705c0add882a  vmovaps xmm14, [rsp+0xE0]
0000705c0add8833  add rsp, 0xF0
0000705c0add883a  pop r11
0000705c0add883c  pop r10
0000705c0add883e  pop r9
0000705c0add8840  pop r8
0000705c0add8842  pop rsi
0000705c0add8843  pop rdi
0000705c0add8844  pop rdx
0000705c0add8845  pop rcx
0000705c0add8846  pop rax
0000705c0add8847  add rsp, 0x08
0000705c0add884b  jmp 0x0000705C0ADD3555
0000705c0add8850  sub rsp, 0x08
0000705c0add8854  push rax
0000705c0add8855  push rcx
0000705c0add8856  push rdx
0000705c0add8857  push rdi
0000705c0add8858  push rsi
0000705c0add8859  push r8
0000705c0add885b  push r9
0000705c0add885d  push r10
0000705c0add885f  push r11
0000705c0add8861  sub rsp, 0xF0
0000705c0add8868  vmovaps [rsp], xmm0
0000705c0add886d  vmovaps [rsp+0x10], xmm2
0000705c0add8873  vmovaps [rsp+0x20], xmm3
0000705c0add8879  vmovaps [rsp+0x30], xmm4
0000705c0add887f  vmovaps [rsp+0x40], xmm5
0000705c0add8885  vmovaps [rsp+0x50], xmm6
0000705c0add888b  vmovaps [rsp+0x60], xmm7
0000705c0add8891  vmovaps [rsp+0x70], xmm8
0000705c0add8897  vmovaps [rsp+0x80], xmm9
0000705c0add88a0  vmovaps [rsp+0x90], xmm10
0000705c0add88a9  vmovaps [rsp+0xA0], xmm11
0000705c0add88b2  vmovaps [rsp+0xB0], xmm12
0000705c0add88bb  vmovaps [rsp+0xC0], xmm13
0000705c0add88c4  vmovaps [rsp+0xD0], xmm14
0000705c0add88cd  vmovaps [rsp+0xE0], xmm15
0000705c0add88d6  sub rsp, 0x30
0000705c0add88da  movaps [rsp], xmm1
0000705c0add88de  movaps [rsp+0x10], xmm7
0000705c0add88e3  movaps [rsp+0x20], xmm11
0000705c0add88e9  lea rdi, [rsp]
0000705c0add88ed  mov esi, 0x00
0000705c0add88f2  mov rax, 0x5969C28C4530
0000705c0add88fc  call rax
0000705c0add88fe  movaps xmm1, [rsp]
0000705c0add8902  add rsp, 0x30
0000705c0add8906  vmovaps xmm0, [rsp]
0000705c0add890b  vmovaps xmm2, [rsp+0x10]
0000705c0add8911  vmovaps xmm3, [rsp+0x20]
0000705c0add8917  vmovaps xmm4, [rsp+0x30]
0000705c0add891d  vmovaps xmm5, [rsp+0x40]
0000705c0add8923  vmovaps xmm6, [rsp+0x50]
0000705c0add8929  vmovaps xmm7, [rsp+0x60]
0000705c0add892f  vmovaps xmm8, [rsp+0x70]
0000705c0add8935  vmovaps xmm9, [rsp+0x80]
0000705c0add893e  vmovaps xmm10, [rsp+0x90]
0000705c0add8947  vmovaps xmm11, [rsp+0xA0]
0000705c0add8950  vmovaps xmm12, [rsp+0xB0]
0000705c0add8959  vmovaps xmm13, [rsp+0xC0]
0000705c0add8962  vmovaps xmm14, [rsp+0xD0]
0000705c0add896b  vmovaps xmm15, [rsp+0xE0]
0000705c0add8974  add rsp, 0xF0
0000705c0add897b  pop r11
0000705c0add897d  pop r10
0000705c0add897f  pop r9
0000705c0add8981  pop r8
0000705c0add8983  pop rsi
0000705c0add8984  pop rdi
0000705c0add8985  pop rdx
0000705c0add8986  pop rcx
0000705c0add8987  pop rax
0000705c0add8988  add rsp, 0x08
0000705c0add898c  jmp 0x0000705C0ADD3576
0000705c0add8991  call 0x0000705C0AC0D600
0000705c0add8996  jmp 0x0000705C0ADD3589
0000705c0add899b  call 0x0000705C0AC0C380
0000705c0add89a0  jmp 0x0000705C0ADD3594
0000705c0add89a5  call 0x0000705C0AC0E880
0000705c0add89aa  jmp 0x0000705C0ADD359F
0000705c0add89af  call 0x0000705C0ABFF540
0000705c0add89b4  jmp 0x0000705C0ADD35AA
0000705c0add89b9  int3
0000705c0add89ba  nop [rax+rax*1], ax
0000705c0add89c0  mov rax, [r15+0x40]
0000705c0add89c4  mov r14, [r15+0x58]
0000705c0add89c8  lea r12, [rax+r14*1]
0000705c0add89cc  movaps xmm1, [r15+0x1D0]
0000705c0add89d4  vmovaps [rsp+0x10], xmm1
0000705c0add89da  vmovaps xmm15, [rsp+0x10]
0000705c0add89e0  por xmm1, xmm15
0000705c0add89e5  movaps xmm14, [r15+0x1A0]
0000705c0add89ed  vmovaps [rsp+0x10], xmm14
0000705c0add89f3  vmovaps xmm13, [rsp+0x10]
0000705c0add89f9  por xmm14, xmm13
0000705c0add89fe  lea rax, [r12+0x30]
0000705c0add8a03  mov r11, [r13+rax*1]
0000705c0add8a08  lea rax, [r12+0x38]
0000705c0add8a0d  mov r10, [r13+rax*1]
0000705c0add8a12  movq xmm13, r11
0000705c0add8a17  movq xmm12, r10
0000705c0add8a1c  movq xmm13, xmm13
0000705c0add8a21  vmovaps [rsp+0x10], xmm13
0000705c0add8a27  movq xmm13, xmm13
0000705c0add8a2c  movaps [r15+0x130], xmm13
0000705c0add8a34  movq xmm12, xmm12
0000705c0add8a39  vmovaps [rsp+0x20], xmm12
0000705c0add8a3f  movq xmm12, xmm12
0000705c0add8a44  movaps [r15+0x280], xmm12
0000705c0add8a4c  movaps xmm13, [r15+0x270]
0000705c0add8a54  vmovaps [rsp+0x30], xmm13
0000705c0add8a5a  vmovaps xmm12, [rsp+0x30]
0000705c0add8a60  por xmm13, xmm12
0000705c0add8a65  lea rax, [r12+0x20]
0000705c0add8a6a  mov r11, [r13+rax*1]
0000705c0add8a6f  lea rax, [r12+0x28]
0000705c0add8a74  mov r10, [r13+rax*1]
0000705c0add8a79  movq xmm12, r11
0000705c0add8a7e  movq xmm11, r10
0000705c0add8a83  movq xmm12, xmm12
0000705c0add8a88  vmovaps [rsp+0x30], xmm12
0000705c0add8a8e  movq xmm12, xmm12
0000705c0add8a93  movaps [r15+0x150], xmm12
0000705c0add8a9b  movq xmm11, xmm11
0000705c0add8aa0  vmovaps [rsp+0x40], xmm11
0000705c0add8aa6  movq xmm11, xmm11
0000705c0add8aab  movaps [r15+0x140], xmm11
0000705c0add8ab3  lea rax, [r12+0x10]
0000705c0add8ab8  mov r11, [r13+rax*1]
0000705c0add8abd  lea rax, [r12+0x18]
0000705c0add8ac2  mov r10, [r13+rax*1]
0000705c0add8ac7  movq xmm12, r11
0000705c0add8acc  movq xmm11, r10
0000705c0add8ad1  movq xmm12, xmm12
0000705c0add8ad6  vmovaps [rsp+0x50], xmm12
0000705c0add8adc  movq xmm12, xmm12
0000705c0add8ae1  movaps [r15+0x170], xmm12
0000705c0add8ae9  movq xmm11, xmm11
0000705c0add8aee  vmovaps [rsp+0x60], xmm11
0000705c0add8af4  movq xmm11, xmm11
0000705c0add8af9  movaps [r15+0x160], xmm11
0000705c0add8b01  mov rax, [r13+r12*1]
0000705c0add8b06  vmovq xmm12, rax
0000705c0add8b0b  vpbroadcastq xmm12, xmm12
0000705c0add8b10  lea rax, [r12+0x08]
0000705c0add8b15  mov r12, [r13+rax*1]
0000705c0add8b1a  movq xmm11, r12
0000705c0add8b1f  movaps [r15+0x230], xmm11
0000705c0add8b27  mov rax, [r15+0xF8]
0000705c0add8b2e  lea r12, [rax+0x50]
0000705c0add8b32  movups xmm11, [r13+r12*1]
0000705c0add8b38  lea r12, [rax+0x60]
0000705c0add8b3c  movups xmm10, [r13+r12*1]
0000705c0add8b42  lea r12, [rax+0x30]
0000705c0add8b46  movups xmm9, [r13+r12*1]
0000705c0add8b4c  mov r12, [r15+0x50]
0000705c0add8b50  lea r11, [r12+r14*1]
0000705c0add8b54  mov [r15+0x60], r11
0000705c0add8b58  lea r12, [r14+0x40]
0000705c0add8b5c  mov [r15+0x58], r12
0000705c0add8b60  movaps xmm8, xmm12
0000705c0add8b64  mulpd xmm8, xmm15
0000705c0add8b69  vcmppd xmm7, xmm8, xmm8, 0x03
0000705c0add8b6f  ptest xmm7, xmm7
0000705c0add8b74  jnz 0x0000705C0ADD9997
0000705c0add8b7a  movq xmm15, qword ptr [r15+0x230]
0000705c0add8b83  vmovaps [rsp+0x70], xmm15
0000705c0add8b89  vpermilpd xmm15, xmm15, 0x00
0000705c0add8b8f  movaps xmm7, xmm9
0000705c0add8b93  mulpd xmm7, xmm15
0000705c0add8b98  vcmppd xmm6, xmm7, xmm7, 0x03
0000705c0add8b9d  ptest xmm6, xmm6
0000705c0add8ba2  jnz 0x0000705C0ADD9ADB
0000705c0add8ba8  vxorps xmm15, xmm15, xmm15
0000705c0add8bad  vpbroadcastq xmm15, xmm15
0000705c0add8bb2  movaps xmm9, xmm12
0000705c0add8bb6  mulpd xmm9, xmm10
0000705c0add8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
0000705c0add8bc1  ptest xmm6, xmm6
0000705c0add8bc6  jnz 0x0000705C0ADD9C1D
0000705c0add8bcc  movaps xmm10, xmm12
0000705c0add8bd0  mulpd xmm10, xmm11
0000705c0add8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
0000705c0add8bdb  ptest xmm6, xmm6
0000705c0add8be0  jnz 0x0000705C0ADD9D61
0000705c0add8be6  movaps xmm11, [r15+0x1F0]
0000705c0add8bee  movaps xmm6, xmm12
0000705c0add8bf2  mulpd xmm6, xmm11
0000705c0add8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
0000705c0add8bfc  ptest xmm5, xmm5
0000705c0add8c01  jnz 0x0000705C0ADD9EA5
0000705c0add8c07  movaps xmm12, [r15+0x2A0]
0000705c0add8c0f  vmovaps [rsp+0x80], xmm12
0000705c0add8c18  vmovaps xmm11, [rsp+0x80]
0000705c0add8c21  por xmm12, xmm11
0000705c0add8c26  movaps xmm11, [r15+0x250]
0000705c0add8c2e  vmovaps [rsp+0x80], xmm11
0000705c0add8c37  vmovaps xmm5, [rsp+0x80]
0000705c0add8c40  por xmm11, xmm5
0000705c0add8c45  vmovaps xmm4, [rsp+0x70]
0000705c0add8c4b  vpermilpd xmm4, xmm4, 0x00
0000705c0add8c51  movaps xmm3, xmm5
0000705c0add8c54  mulpd xmm3, xmm4
0000705c0add8c58  vcmppd xmm2, xmm3, xmm3, 0x03
0000705c0add8c5d  ptest xmm2, xmm2
0000705c0add8c62  jnz 0x0000705C0ADD9FE7
0000705c0add8c68  mov [rsp+0x80], rax
0000705c0add8c70  xor eax, eax
0000705c0add8c72  mov r14d, 0x200
0000705c0add8c78  cmp r12, r14
0000705c0add8c7b  cmc
0000705c0add8c7c  lahf
0000705c0add8c7d  seto al
0000705c0add8c80  mov [r15+0x108], eax
0000705c0add8c87  movaps xmm5, xmm8
0000705c0add8c8b  addpd xmm5, xmm15
0000705c0add8c90  vcmppd xmm4, xmm5, xmm5, 0x03
0000705c0add8c95  ptest xmm4, xmm4
0000705c0add8c9a  jnz 0x0000705C0ADDA127
0000705c0add8ca0  movaps xmm8, [r15+0x1B0]
0000705c0add8ca8  movaps xmm4, xmm9
0000705c0add8cac  addpd xmm4, xmm8
0000705c0add8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
0000705c0add8cb6  ptest xmm2, xmm2
0000705c0add8cbb  jnz 0x0000705C0ADDA269
0000705c0add8cc1  movaps xmm9, xmm10
0000705c0add8cc5  addpd xmm9, xmm8
0000705c0add8cca  vcmppd xmm2, xmm9, xmm9, 0x03
0000705c0add8cd0  ptest xmm2, xmm2
0000705c0add8cd5  jnz 0x0000705C0ADDA3AB
0000705c0add8cdb  movaps xmm10, [r15+0x2F0]
0000705c0add8ce3  vmovaps [rsp+0x90], xmm10
0000705c0add8cec  vmovaps xmm8, [rsp+0x90]
0000705c0add8cf5  por xmm10, xmm8
0000705c0add8cfa  movaps xmm8, [r15+0x2E0]
0000705c0add8d02  vmovaps [rsp+0x90], xmm8
0000705c0add8d0b  vmovaps xmm2, [rsp+0x90]
0000705c0add8d14  por xmm8, xmm2
0000705c0add8d19  movaps xmm2, [r15+0x2D0]
0000705c0add8d21  vmovaps [rsp+0x90], xmm2
0000705c0add8d2a  vmovaps [rsp+0xA0], xmm1
0000705c0add8d33  vmovaps xmm1, [rsp+0x90]
0000705c0add8d3c  por xmm2, xmm1
0000705c0add8d40  movaps xmm1, [r15+0x200]
0000705c0add8d48  vmovaps [rsp+0x90], xmm1
0000705c0add8d51  vmovaps [rsp+0xB0], xmm15
0000705c0add8d5a  vmovaps xmm15, [rsp+0x90]
0000705c0add8d63  por xmm1, xmm15
0000705c0add8d68  movaps xmm15, [r15+0x1C0]
0000705c0add8d70  vmovaps [rsp+0x90], xmm15
0000705c0add8d79  vmovaps [rsp+0xC0], xmm1
0000705c0add8d82  vmovaps xmm1, [rsp+0x90]
0000705c0add8d8b  por xmm15, xmm1
0000705c0add8d90  movaps xmm1, [r15+0x190]
0000705c0add8d98  vmovaps [rsp+0x90], xmm1
0000705c0add8da1  vmovaps [rsp+0xD0], xmm15
0000705c0add8daa  vmovaps xmm15, [rsp+0x90]
0000705c0add8db3  por xmm1, xmm15
0000705c0add8db8  movaps xmm15, [r15+0x300]
0000705c0add8dc0  vmovaps [rsp+0x90], xmm15
0000705c0add8dc9  vmovaps [rsp+0xE0], xmm1
0000705c0add8dd2  vmovaps xmm1, [rsp+0x90]
0000705c0add8ddb  por xmm15, xmm1
0000705c0add8de0  mov rax, [rsp+0x80]
0000705c0add8de8  lea r14, [rax+0xA0]
0000705c0add8def  movups xmm1, [r13+r14*1]
0000705c0add8df5  lea r14, [rax+0xB0]
0000705c0add8dfc  vmovaps [rsp+0x80], xmm1
0000705c0add8e05  movups xmm1, [r13+r14*1]
0000705c0add8e0b  vmovaps [rsp+0x90], xmm1
0000705c0add8e14  vmovaps [rsp+0xF0], xmm15
0000705c0add8e1d  vmovaps xmm15, [rsp+0xB0]
0000705c0add8e26  vmovaps [rsp+0xB0], xmm14
0000705c0add8e2f  movaps xmm1, xmm6
0000705c0add8e32  addpd xmm1, xmm15
0000705c0add8e37  vcmppd xmm14, xmm1, xmm1, 0x03
0000705c0add8e3c  ptest xmm14, xmm14
0000705c0add8e42  jnz 0x0000705C0ADDA503
0000705c0add8e48  lea r14, [rax+0xF0]
0000705c0add8e4f  movups xmm15, [r13+r14*1]
0000705c0add8e55  movaps xmm14, xmm4
0000705c0add8e59  addpd xmm14, xmm3
0000705c0add8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
0000705c0add8e64  ptest xmm6, xmm6
0000705c0add8e69  jnz 0x0000705C0ADDA64E
0000705c0add8e6f  movaps xmm6, xmm9
0000705c0add8e73  addpd xmm6, xmm7
0000705c0add8e77  vcmppd xmm4, xmm6, xmm6, 0x03
0000705c0add8e7c  ptest xmm4, xmm4
0000705c0add8e81  jnz 0x0000705C0ADDA790
0000705c0add8e87  vmovaps xmm9, [rsp+0x70]
0000705c0add8e8d  vpermilpd xmm9, xmm9, 0x00
0000705c0add8e93  vmovaps xmm4, [rsp+0x90]
0000705c0add8e9c  movaps xmm7, xmm4
0000705c0add8e9f  mulpd xmm7, xmm9
0000705c0add8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
0000705c0add8ea9  ptest xmm3, xmm3
0000705c0add8eae  jnz 0x0000705C0ADDA8D1
0000705c0add8eb4  vmovaps xmm9, [rsp+0x50]
0000705c0add8eba  vpermilpd xmm9, xmm9, 0x00
0000705c0add8ec0  movaps xmm4, xmm15
0000705c0add8ec4  mulpd xmm4, xmm9
0000705c0add8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
0000705c0add8ece  ptest xmm3, xmm3
0000705c0add8ed3  jnz 0x0000705C0ADDAA12
0000705c0add8ed9  lea r14, [rax+0xE0]
0000705c0add8ee0  movups xmm15, [r13+r14*1]
0000705c0add8ee6  vmovaps xmm9, [rsp+0x70]
0000705c0add8eec  vpermilpd xmm9, xmm9, 0x00
0000705c0add8ef2  vmovaps [rsp+0x70], xmm1
0000705c0add8ef8  vmovaps xmm1, [rsp+0x80]
0000705c0add8f01  vmovaps [rsp+0x80], xmm15
0000705c0add8f0a  movaps xmm3, xmm1
0000705c0add8f0d  mulpd xmm3, xmm9
0000705c0add8f12  vcmppd xmm15, xmm3, xmm3, 0x03
0000705c0add8f17  ptest xmm15, xmm15
0000705c0add8f1d  jnz 0x0000705C0ADDAB5E
0000705c0add8f23  vmovaps xmm1, [rsp+0xF0]
0000705c0add8f2c  vmovaps xmm15, [rsp+0xF0]
0000705c0add8f35  por xmm1, xmm15
0000705c0add8f3a  movaps [r15+0x300], xmm1
0000705c0add8f42  vmovaps xmm15, [rsp+0xE0]
0000705c0add8f4b  vmovaps xmm9, [rsp+0xE0]
0000705c0add8f54  por xmm15, xmm9
0000705c0add8f59  movaps [r15+0x190], xmm15
0000705c0add8f61  vmovaps xmm9, [rsp+0x50]
0000705c0add8f67  vpermilpd xmm9, xmm9, 0x00
0000705c0add8f6d  vmovaps [rsp+0x90], xmm1
0000705c0add8f76  vmovaps [rsp+0xE0], xmm15
0000705c0add8f7f  vmovaps xmm15, [rsp+0x80]
0000705c0add8f88  vmovaps [rsp+0x80], xmm14
0000705c0add8f91  movaps xmm1, xmm15
0000705c0add8f95  mulpd xmm1, xmm9
0000705c0add8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
0000705c0add8f9f  ptest xmm14, xmm14
0000705c0add8fa5  jnz 0x0000705C0ADDAC9F
0000705c0add8fab  lea r14, [rax+0x90]
0000705c0add8fb2  movups xmm15, [r13+r14*1]
0000705c0add8fb8  vmovaps xmm14, [rsp+0xD0]
0000705c0add8fc1  vmovaps xmm9, [rsp+0xD0]
0000705c0add8fca  por xmm14, xmm9
0000705c0add8fcf  movaps [r15+0x1C0], xmm14
0000705c0add8fd7  vmovaps xmm9, [rsp+0xC0]
0000705c0add8fe0  vmovaps [rsp+0xD0], xmm1
0000705c0add8fe9  vmovaps xmm1, [rsp+0xC0]
0000705c0add8ff2  por xmm9, xmm1
0000705c0add8ff7  movaps [r15+0x200], xmm9
0000705c0add8fff  vmovaps [rsp+0xC0], xmm2
0000705c0add9008  vmovaps xmm1, [rsp+0xC0]
0000705c0add9011  por xmm2, xmm1
0000705c0add9015  movaps [r15+0x2D0], xmm2
0000705c0add901d  vmovaps [rsp+0xC0], xmm8
0000705c0add9026  vmovaps xmm1, [rsp+0xC0]
0000705c0add902f  por xmm8, xmm1
0000705c0add9034  movaps [r15+0x2E0], xmm8
0000705c0add903c  vmovaps [rsp+0xC0], xmm15
0000705c0add9045  movaps xmm1, xmm5
0000705c0add9048  addpd xmm1, xmm7
0000705c0add904c  vcmppd xmm15, xmm1, xmm1, 0x03
0000705c0add9051  ptest xmm15, xmm15
0000705c0add9057  jnz 0x0000705C0ADDADEB
0000705c0add905d  vmovaps xmm15, [rsp+0x50]
0000705c0add9063  vpermilpd xmm15, xmm15, 0x00
0000705c0add9069  vmovaps xmm5, [rsp+0xC0]
0000705c0add9072  vmovaps [rsp+0xC0], xmm1
0000705c0add907b  movaps xmm7, xmm5
0000705c0add907e  mulpd xmm7, xmm15
0000705c0add9083  vcmppd xmm1, xmm7, xmm7, 0x03
0000705c0add9088  ptest xmm1, xmm1
0000705c0add908d  jnz 0x0000705C0ADDAF2B
0000705c0add9093  lea r14, [rax+0x80]
0000705c0add909a  movups xmm1, [r13+r14*1]
0000705c0add90a0  vmovaps xmm5, [rsp+0x70]
0000705c0add90a6  vmovaps [rsp+0x70], xmm1
0000705c0add90ac  movaps xmm15, xmm5
0000705c0add90b0  addpd xmm15, xmm3
0000705c0add90b5  vcmppd xmm1, xmm15, xmm15, 0x03
0000705c0add90bb  ptest xmm1, xmm1
0000705c0add90c0  jnz 0x0000705C0ADDB076
0000705c0add90c6  vmovaps xmm5, [rsp+0x80]
0000705c0add90cf  movaps xmm1, xmm5
0000705c0add90d2  addpd xmm1, xmm4
0000705c0add90d6  vcmppd xmm3, xmm1, xmm1, 0x03
0000705c0add90db  ptest xmm3, xmm3
0000705c0add90e0  jnz 0x0000705C0ADDB1B8
0000705c0add90e6  vmovaps [rsp+0x80], xmm10
0000705c0add90ef  vmovaps xmm5, [rsp+0x80]
0000705c0add90f8  por xmm10, xmm5
0000705c0add90fd  movaps [r15+0x2F0], xmm10
0000705c0add9105  vmovaps xmm5, [rsp+0x50]
0000705c0add910b  vpermilpd xmm5, xmm5, 0x00
0000705c0add9111  vmovaps xmm3, [rsp+0x70]
0000705c0add9117  vmovaps [rsp+0x50], xmm1
0000705c0add911d  movaps xmm4, xmm3
0000705c0add9120  mulpd xmm4, xmm5
0000705c0add9124  vcmppd xmm1, xmm4, xmm4, 0x03
0000705c0add9129  ptest xmm1, xmm1
0000705c0add912e  jnz 0x0000705C0ADDB2F8
0000705c0add9134  lea r14, [rax+0xD0]
0000705c0add913b  movups xmm1, [r13+r14*1]
0000705c0add9141  vmovaps xmm3, [rsp+0xD0]
0000705c0add914a  vmovaps [rsp+0x70], xmm1
0000705c0add9150  movaps xmm5, xmm6
0000705c0add9153  addpd xmm5, xmm3
0000705c0add9157  vcmppd xmm1, xmm5, xmm5, 0x03
0000705c0add915c  ptest xmm1, xmm1
0000705c0add9161  jnz 0x0000705C0ADDB442
0000705c0add9167  vmovaps xmm1, [rsp+0x60]
0000705c0add916d  vpermilpd xmm1, xmm1, 0x00
0000705c0add9173  movaps xmm6, xmm9
0000705c0add9177  mulpd xmm6, xmm1
0000705c0add917b  vcmppd xmm3, xmm6, xmm6, 0x03
0000705c0add9180  ptest xmm3, xmm3
0000705c0add9185  jnz 0x0000705C0ADDB582
0000705c0add918b  movaps [r15+0x260], xmm6
0000705c0add9193  vxorps xmm1, xmm1, xmm1
0000705c0add9197  vpbroadcastq xmm1, xmm1
0000705c0add919c  movaps [r15+0x1B0], xmm1
0000705c0add91a4  vmovaps xmm1, [rsp+0x60]
0000705c0add91aa  vpermilpd xmm1, xmm1, 0x00
0000705c0add91b0  vmovaps xmm3, [rsp+0x70]
0000705c0add91b6  vmovaps [rsp+0x70], xmm15
0000705c0add91bc  movaps xmm9, xmm3
0000705c0add91c0  mulpd xmm9, xmm1
0000705c0add91c5  vcmppd xmm15, xmm9, xmm9, 0x03
0000705c0add91cb  ptest xmm15, xmm15
0000705c0add91d1  jnz 0x0000705C0ADDB6C3
0000705c0add91d7  lea r14, [rax+0xC0]
0000705c0add91de  movups xmm1, [r13+r14*1]
0000705c0add91e4  vmovaps xmm3, [rsp+0xC0]
0000705c0add91ed  vmovaps [rsp+0x80], xmm1
0000705c0add91f6  movaps xmm15, xmm3
0000705c0add91fa  addpd xmm15, xmm7
0000705c0add91ff  vcmppd xmm1, xmm15, xmm15, 0x03
0000705c0add9205  ptest xmm1, xmm1
0000705c0add920a  jnz 0x0000705C0ADDB80F
0000705c0add9210  vmovaps [rsp+0xC0], xmm13
0000705c0add9219  vmovaps xmm1, [rsp+0xC0]
0000705c0add9222  por xmm13, xmm1
0000705c0add9227  movaps [r15+0x270], xmm13
0000705c0add922f  vmovaps xmm1, [rsp+0xB0]
0000705c0add9238  vmovaps xmm7, [rsp+0xB0]
0000705c0add9241  por xmm1, xmm7
0000705c0add9245  movaps [r15+0x1A0], xmm1
0000705c0add924d  vmovaps xmm1, [rsp+0x60]
0000705c0add9253  vpermilpd xmm1, xmm1, 0x00
0000705c0add9259  vmovaps [rsp+0xB0], xmm1
0000705c0add9262  vmovaps xmm1, [rsp+0x80]
0000705c0add926b  vmovaps [rsp+0x80], xmm15
0000705c0add9274  vmovaps xmm15, [rsp+0xB0]
0000705c0add927d  vmovaps [rsp+0xB0], xmm14
0000705c0add9286  movaps xmm3, xmm1
0000705c0add9289  mulpd xmm3, xmm15
0000705c0add928e  vcmppd xmm14, xmm3, xmm3, 0x03
0000705c0add9293  ptest xmm14, xmm14
0000705c0add9299  jnz 0x0000705C0ADDB951
0000705c0add929f  lea r14, [rax+0x20]
0000705c0add92a3  movups xmm1, [r13+r14*1]
0000705c0add92a9  movaps [r15+0x110], xmm1
0000705c0add92b1  vmovaps xmm14, [rsp+0x70]
0000705c0add92b7  vmovaps [rsp+0x70], xmm1
0000705c0add92bd  movaps xmm15, xmm14
0000705c0add92c1  addpd xmm15, xmm4
0000705c0add92c6  vcmppd xmm1, xmm15, xmm15, 0x03
0000705c0add92cc  ptest xmm1, xmm1
0000705c0add92d1  jnz 0x0000705C0ADDBA9C
0000705c0add92d7  vmovaps xmm1, [rsp+0x60]
0000705c0add92dd  vpermilpd xmm1, xmm1, 0x00
0000705c0add92e3  movaps xmm14, xmm2
0000705c0add92e7  mulpd xmm14, xmm1
0000705c0add92ec  vcmppd xmm4, xmm14, xmm14, 0x03
0000705c0add92f2  ptest xmm4, xmm4
0000705c0add92f7  jnz 0x0000705C0ADDBBDF
0000705c0add92fd  vmovaps xmm4, [rsp+0x50]
0000705c0add9303  movaps xmm1, xmm4
0000705c0add9306  addpd xmm1, xmm9
0000705c0add930b  vcmppd xmm2, xmm1, xmm1, 0x03
0000705c0add9310  ptest xmm2, xmm2
0000705c0add9315  jnz 0x0000705C0ADDBD21
0000705c0add931b  vmovaps xmm9, [rsp+0x30]
0000705c0add9321  vpermilpd xmm9, xmm9, 0x00
0000705c0add9327  vmovaps xmm2, [rsp+0x70]
0000705c0add932d  vmovaps [rsp+0x50], xmm1
0000705c0add9333  movaps xmm4, xmm2
0000705c0add9336  mulpd xmm4, xmm9
0000705c0add933b  vcmppd xmm1, xmm4, xmm4, 0x03
0000705c0add9340  ptest xmm1, xmm1
0000705c0add9345  jnz 0x0000705C0ADDBE62
0000705c0add934b  vmovaps xmm1, [rsp+0x30]
0000705c0add9351  vpermilpd xmm1, xmm1, 0x00
0000705c0add9357  vmovaps xmm2, [rsp+0x90]
0000705c0add9360  vmovaps [rsp+0x60], xmm15
0000705c0add9366  movaps xmm9, xmm2
0000705c0add936a  mulpd xmm9, xmm1
0000705c0add936f  vcmppd xmm15, xmm9, xmm9, 0x03
0000705c0add9375  ptest xmm15, xmm15
0000705c0add937b  jnz 0x0000705C0ADDBFA3
0000705c0add9381  vmovaps xmm15, [rsp+0x80]
0000705c0add938a  movaps xmm1, xmm15
0000705c0add938e  addpd xmm1, xmm6
0000705c0add9392  vcmppd xmm2, xmm1, xmm1, 0x03
0000705c0add9397  ptest xmm2, xmm2
0000705c0add939c  jnz 0x0000705C0ADDC0E5
0000705c0add93a2  movaps xmm15, xmm5
0000705c0add93a6  addpd xmm15, xmm3
0000705c0add93ab  vcmppd xmm6, xmm15, xmm15, 0x03
0000705c0add93b1  ptest xmm6, xmm6
0000705c0add93b6  jnz 0x0000705C0ADDC226
0000705c0add93bc  vmovaps xmm6, [rsp+0x30]
0000705c0add93c2  vpermilpd xmm6, xmm6, 0x00
0000705c0add93c8  movaps xmm5, xmm8
0000705c0add93cc  mulpd xmm5, xmm6
0000705c0add93d0  vcmppd xmm3, xmm5, xmm5, 0x03
0000705c0add93d5  ptest xmm3, xmm3
0000705c0add93da  jnz 0x0000705C0ADDC368
0000705c0add93e0  vmovaps xmm8, [rsp+0x30]
0000705c0add93e6  vpermilpd xmm8, xmm8, 0x00
0000705c0add93ec  movaps xmm6, xmm10
0000705c0add93f0  mulpd xmm6, xmm8
0000705c0add93f5  vcmppd xmm3, xmm6, xmm6, 0x03
0000705c0add93fa  ptest xmm3, xmm3
0000705c0add93ff  jnz 0x0000705C0ADDC4A9
0000705c0add9405  vmovaps xmm8, [rsp+0x60]
0000705c0add940b  movaps xmm10, xmm8
0000705c0add940f  addpd xmm10, xmm14
0000705c0add9414  vcmppd xmm3, xmm10, xmm10, 0x03
0000705c0add941a  ptest xmm3, xmm3
0000705c0add941f  jnz 0x0000705C0ADDC5EB
0000705c0add9425  vmovaps xmm8, [rsp+0x50]
0000705c0add942b  movaps xmm14, xmm8
0000705c0add942f  addpd xmm14, xmm4
0000705c0add9434  vcmppd xmm3, xmm14, xmm14, 0x03
0000705c0add943a  ptest xmm3, xmm3
0000705c0add943f  jnz 0x0000705C0ADDC72F
0000705c0add9445  vmovaps xmm8, [rsp+0x40]
0000705c0add944b  vpermilpd xmm8, xmm8, 0x00
0000705c0add9451  movaps xmm4, xmm13
0000705c0add9455  mulpd xmm4, xmm8
0000705c0add945a  vcmppd xmm3, xmm4, xmm4, 0x03
0000705c0add945f  ptest xmm3, xmm3
0000705c0add9464  jnz 0x0000705C0ADDC872
0000705c0add946a  movaps xmm13, xmm15
0000705c0add946e  addpd xmm13, xmm9
0000705c0add9473  vcmppd xmm8, xmm13, xmm13, 0x03
0000705c0add9479  ptest xmm8, xmm8
0000705c0add947f  jnz 0x0000705C0ADDC9B4
0000705c0add9485  movaps xmm15, xmm1
0000705c0add9489  addpd xmm15, xmm5
0000705c0add948e  vcmppd xmm9, xmm15, xmm15, 0x03
0000705c0add9494  ptest xmm9, xmm9
0000705c0add949a  jnz 0x0000705C0ADDCAF8
0000705c0add94a0  vmovaps [rsp+0x30], xmm11
0000705c0add94a6  vmovaps xmm1, [rsp+0x30]
0000705c0add94ac  por xmm11, xmm1
0000705c0add94b1  movaps [r15+0x250], xmm11
0000705c0add94b9  vmovaps [rsp+0x30], xmm12
0000705c0add94bf  vmovaps xmm1, [rsp+0x30]
0000705c0add94c5  por xmm12, xmm1
0000705c0add94ca  movaps [r15+0x2A0], xmm12
0000705c0add94d2  vmovaps xmm1, [rsp+0xA0]
0000705c0add94db  vmovaps xmm11, [rsp+0xA0]
0000705c0add94e4  por xmm1, xmm11
0000705c0add94e9  movaps [r15+0x1D0], xmm1
0000705c0add94f1  lea r14, [rax+0x40]
0000705c0add94f5  movups xmm1, [r13+r14*1]
0000705c0add94fb  movaps [r15+0x2C0], xmm1
0000705c0add9503  vmovaps xmm11, [rsp+0x40]
0000705c0add9509  vpermilpd xmm11, xmm11, 0x00
0000705c0add950f  vmovaps xmm8, [rsp+0xE0]
0000705c0add9518  movaps xmm9, xmm8
0000705c0add951c  mulpd xmm9, xmm11
0000705c0add9521  vcmppd xmm5, xmm9, xmm9, 0x03
0000705c0add9527  ptest xmm5, xmm5
0000705c0add952c  jnz 0x0000705C0ADDCC44
0000705c0add9532  movaps xmm11, xmm10
0000705c0add9536  addpd xmm11, xmm6
0000705c0add953b  vcmppd xmm8, xmm11, xmm11, 0x03
0000705c0add9541  ptest xmm8, xmm8
0000705c0add9547  jnz 0x0000705C0ADDCD88
0000705c0add954d  movaps xmm10, xmm14
0000705c0add9551  addpd xmm10, xmm4
0000705c0add9556  vcmppd xmm8, xmm10, xmm10, 0x03
0000705c0add955c  ptest xmm8, xmm8
0000705c0add9562  jnz 0x0000705C0ADDCECB
0000705c0add9568  vmovaps xmm14, [rsp+0x40]
0000705c0add956e  vpermilpd xmm14, xmm14, 0x00
0000705c0add9574  movaps xmm8, xmm1
0000705c0add9578  mulpd xmm8, xmm14
0000705c0add957d  vcmppd xmm6, xmm8, xmm8, 0x03
0000705c0add9583  ptest xmm6, xmm6
0000705c0add9588  jnz 0x0000705C0ADDD00E
0000705c0add958e  movaps xmm1, [r15+0x2B0]
0000705c0add9596  vmovaps xmm14, [rsp+0x40]
0000705c0add959c  vpermilpd xmm14, xmm14, 0x00
0000705c0add95a2  movaps xmm6, xmm1
0000705c0add95a5  mulpd xmm6, xmm14
0000705c0add95aa  vcmppd xmm5, xmm6, xmm6, 0x03
0000705c0add95af  ptest xmm5, xmm5
0000705c0add95b4  jnz 0x0000705C0ADDD151
0000705c0add95ba  vmovaps xmm1, [rsp+0x10]
0000705c0add95c0  vpermilpd xmm1, xmm1, 0x00
0000705c0add95c6  movaps xmm14, xmm12
0000705c0add95ca  mulpd xmm14, xmm1
0000705c0add95cf  vcmppd xmm5, xmm14, xmm14, 0x03
0000705c0add95d5  ptest xmm5, xmm5
0000705c0add95da  jnz 0x0000705C0ADDD292
0000705c0add95e0  movaps xmm1, xmm13
0000705c0add95e4  addpd xmm1, xmm9
0000705c0add95e9  vcmppd xmm12, xmm1, xmm1, 0x03
0000705c0add95ee  ptest xmm12, xmm12
0000705c0add95f4  jnz 0x0000705C0ADDD3D5
0000705c0add95fa  vmovaps xmm13, [rsp+0x10]
0000705c0add9600  vpermilpd xmm13, xmm13, 0x00
0000705c0add9606  movaps xmm12, xmm7
0000705c0add960a  mulpd xmm12, xmm13
0000705c0add960f  vcmppd xmm9, xmm12, xmm12, 0x03
0000705c0add9615  ptest xmm9, xmm9
0000705c0add961b  jnz 0x0000705C0ADDD517
0000705c0add9621  movaps xmm13, xmm15
0000705c0add9625  addpd xmm13, xmm8
0000705c0add962a  vcmppd xmm9, xmm13, xmm13, 0x03
0000705c0add9630  ptest xmm9, xmm9
0000705c0add9636  jnz 0x0000705C0ADDD65A
0000705c0add963c  movaps xmm15, [r15+0x290]
0000705c0add9644  vmovaps xmm9, [rsp+0x10]
0000705c0add964a  vpermilpd xmm9, xmm9, 0x00
0000705c0add9650  movaps xmm8, xmm15
0000705c0add9654  mulpd xmm8, xmm9
0000705c0add9659  vcmppd xmm7, xmm8, xmm8, 0x03
0000705c0add965f  ptest xmm7, xmm7
0000705c0add9664  jnz 0x0000705C0ADDD79E
0000705c0add966a  movaps xmm15, xmm11
0000705c0add966e  addpd xmm15, xmm6
0000705c0add9673  vcmppd xmm9, xmm15, xmm15, 0x03
0000705c0add9679  ptest xmm9, xmm9
0000705c0add967f  jnz 0x0000705C0ADDD8E2
0000705c0add9685  movaps xmm11, [r15+0x1E0]
0000705c0add968d  vmovaps xmm9, [rsp+0x10]
0000705c0add9693  vpermilpd xmm9, xmm9, 0x00
0000705c0add9699  movaps xmm7, xmm11
0000705c0add969d  mulpd xmm7, xmm9
0000705c0add96a2  vcmppd xmm6, xmm7, xmm7, 0x03
0000705c0add96a7  ptest xmm6, xmm6
0000705c0add96ac  jnz 0x0000705C0ADDDA25
0000705c0add96b2  movaps xmm11, xmm10
0000705c0add96b6  addpd xmm11, xmm14
0000705c0add96bb  vcmppd xmm9, xmm11, xmm11, 0x03
0000705c0add96c1  ptest xmm9, xmm9
0000705c0add96c7  jnz 0x0000705C0ADDDB67
0000705c0add96cd  lea r14, [rax+0x70]
0000705c0add96d1  movups xmm14, [r13+r14*1]
0000705c0add96d7  movaps [r15+0x240], xmm14
0000705c0add96df  movaps xmm10, xmm1
0000705c0add96e3  addpd xmm10, xmm12
0000705c0add96e8  vcmppd xmm9, xmm10, xmm10, 0x03
0000705c0add96ee  ptest xmm9, xmm9
0000705c0add96f4  jnz 0x0000705C0ADDDCB5
0000705c0add96fa  movaps [r15+0x170], xmm10
0000705c0add9702  vmovaps xmm1, [rsp+0x20]
0000705c0add9708  vpermilpd xmm1, xmm1, 0x00
0000705c0add970e  movaps xmm12, xmm14
0000705c0add9712  mulpd xmm12, xmm1
0000705c0add9717  vcmppd xmm9, xmm12, xmm12, 0x03
0000705c0add971d  ptest xmm9, xmm9
0000705c0add9723  jnz 0x0000705C0ADDDDF8
0000705c0add9729  vmovaps xmm1, [rsp+0x20]
0000705c0add972f  vpermilpd xmm1, xmm1, 0x00
0000705c0add9735  vmovaps xmm9, [rsp+0xB0]
0000705c0add973e  movaps xmm14, xmm9
0000705c0add9742  mulpd xmm14, xmm1
0000705c0add9747  vcmppd xmm6, xmm14, xmm14, 0x03
0000705c0add974d  ptest xmm6, xmm6
0000705c0add9752  jnz 0x0000705C0ADDDF3B
0000705c0add9758  movaps [r15+0x180], xmm14
0000705c0add9760  movaps xmm1, xmm13
0000705c0add9764  addpd xmm1, xmm8
0000705c0add9769  vcmppd xmm9, xmm1, xmm1, 0x03
0000705c0add976e  ptest xmm9, xmm9
0000705c0add9774  jnz 0x0000705C0ADDE07E
0000705c0add977a  movaps [r15+0x210], xmm1
0000705c0add9782  movups xmm13, [r13+rax*1]
0000705c0add9788  lea r14, [rax+0x10]
0000705c0add978c  movups xmm9, [r13+r14*1]
0000705c0add9792  movaps [r15+0x230], xmm9
0000705c0add979a  movaps xmm8, xmm15
0000705c0add979e  addpd xmm8, xmm7
0000705c0add97a3  vcmppd xmm6, xmm8, xmm8, 0x03
0000705c0add97a9  ptest xmm6, xmm6
0000705c0add97ae  jnz 0x0000705C0ADDE1D4
0000705c0add97b4  movaps [r15+0x130], xmm8
0000705c0add97bc  vmovaps xmm15, [rsp+0x20]
0000705c0add97c2  vpermilpd xmm15, xmm15, 0x00
0000705c0add97c8  movaps xmm7, xmm9
0000705c0add97cc  mulpd xmm7, xmm15
0000705c0add97d1  vcmppd xmm6, xmm7, xmm7, 0x03
0000705c0add97d6  ptest xmm6, xmm6
0000705c0add97db  jnz 0x0000705C0ADDE317
0000705c0add97e1  movaps [r15+0x220], xmm7
0000705c0add97e9  vmovaps xmm15, [rsp+0x20]
0000705c0add97ef  vpermilpd xmm15, xmm15, 0x00
0000705c0add97f5  movaps xmm9, xmm13
0000705c0add97f9  mulpd xmm9, xmm15
0000705c0add97fe  vcmppd xmm6, xmm9, xmm9, 0x03
0000705c0add9804  ptest xmm6, xmm6
0000705c0add9809  jnz 0x0000705C0ADDE459
0000705c0add980f  movaps xmm15, xmm11
0000705c0add9813  addpd xmm15, xmm12
0000705c0add9818  vcmppd xmm13, xmm15, xmm15, 0x03
0000705c0add981e  ptest xmm13, xmm13
0000705c0add9824  jnz 0x0000705C0ADDE59D
0000705c0add982a  movaps [r15+0x140], xmm15
0000705c0add9832  movaps xmm13, xmm10
0000705c0add9836  addpd xmm13, xmm14
0000705c0add983b  vcmppd xmm12, xmm13, xmm13, 0x03
0000705c0add9841  ptest xmm12, xmm12
0000705c0add9847  jnz 0x0000705C0ADDE6E1
0000705c0add984d  movaps [r15+0x150], xmm13
0000705c0add9855  movaps xmm14, xmm1
0000705c0add9859  addpd xmm14, xmm7
0000705c0add985e  vcmppd xmm12, xmm14, xmm14, 0x03
0000705c0add9864  ptest xmm12, xmm12
0000705c0add986a  jnz 0x0000705C0ADDE825
0000705c0add9870  movaps [r15+0x160], xmm14
0000705c0add9878  movaps xmm1, xmm8
0000705c0add987c  addpd xmm1, xmm9
0000705c0add9881  vcmppd xmm12, xmm1, xmm1, 0x03
0000705c0add9886  ptest xmm12, xmm12
0000705c0add988c  jnz 0x0000705C0ADDE967
0000705c0add9892  movaps [r15+0x120], xmm1
0000705c0add989a  movups [r13+r11*1], xmm15
0000705c0add98a0  lea rax, [r11+0x10]
0000705c0add98a4  movups [r13+rax*1], xmm13
0000705c0add98aa  lea rax, [r11+0x20]
0000705c0add98ae  movups [r13+rax*1], xmm14
0000705c0add98b4  lea rax, [r11+0x30]
0000705c0add98b8  movups [r13+rax*1], xmm1
0000705c0add98be  mov eax, [r15+0x108]
0000705c0add98c5  sahf
0000705c0add98c6  jnz 0x0000705C0ADD98F8
0000705c0add98c8  cmp dword ptr [r15+0x318], 0x00
0000705c0add98d0  jz 0x0000705C0ADDEAE0
0000705c0add98d6  nop [rax+rax*1], ax
0000705c0add98df  nop [rax+rax*1], eax
0000705c0add98e7  mov eax, 0x4106D0
0000705c0add98ec  mov [r15+0x100], rax
0000705c0add98f3  jmp 0x0000705C0ABFE110
0000705c0add98f8  cmp dword ptr [r15+0x318], 0x00
0000705c0add9900  jz 0x0000705C0ADD89C0
0000705c0add9906  nop [rax+rax*1], ax
0000705c0add990f  nop [rax+rax*1], eax
0000705c0add9917  mov eax, 0x410504
0000705c0add991c  mov [r15+0x100], rax
0000705c0add9923  jmp 0x0000705C0ABFE110
0000705c0add9928  int3
0000705c0add9929  call 0x0000705C0AC0A4B0
0000705c0add992e  jmp 0x0000705C0ADD8A08
0000705c0add9933  call 0x0000705C0AC09240
0000705c0add9938  jmp 0x0000705C0ADD8A12
0000705c0add993d  call 0x0000705C0AC0A4B0
0000705c0add9942  jmp 0x0000705C0ADD8A6F
0000705c0add9947  call 0x0000705C0AC09240
0000705c0add994c  jmp 0x0000705C0ADD8A79
0000705c0add9951  call 0x0000705C0AC0A4B0
0000705c0add9956  jmp 0x0000705C0ADD8ABD
0000705c0add995b  call 0x0000705C0AC09240
0000705c0add9960  jmp 0x0000705C0ADD8AC7
0000705c0add9965  call 0x0000705C0ACB47C0
0000705c0add996a  jmp 0x0000705C0ADD8B06
0000705c0add996f  call 0x0000705C0AC0B720
0000705c0add9974  jmp 0x0000705C0ADD8B1A
0000705c0add9979  call 0x0000705C0ACBFC30
0000705c0add997e  jmp 0x0000705C0ADD8B38
0000705c0add9983  call 0x0000705C0ACBE9C0
0000705c0add9988  jmp 0x0000705C0ADD8B42
0000705c0add998d  call 0x0000705C0ACBD750
0000705c0add9992  jmp 0x0000705C0ADD8B4C
0000705c0add9997  sub rsp, 0x08
0000705c0add999b  push rax
0000705c0add999c  push rcx
0000705c0add999d  push rdx
0000705c0add999e  push rdi
0000705c0add999f  push rsi
0000705c0add99a0  push r8
0000705c0add99a2  push r9
0000705c0add99a4  push r10
0000705c0add99a6  push r11
0000705c0add99a8  sub rsp, 0xF0
0000705c0add99af  vmovaps [rsp], xmm0
0000705c0add99b4  vmovaps [rsp+0x10], xmm1
0000705c0add99ba  vmovaps [rsp+0x20], xmm2
0000705c0add99c0  vmovaps [rsp+0x30], xmm3
0000705c0add99c6  vmovaps [rsp+0x40], xmm4
0000705c0add99cc  vmovaps [rsp+0x50], xmm5
0000705c0add99d2  vmovaps [rsp+0x60], xmm6
0000705c0add99d8  vmovaps [rsp+0x70], xmm7
0000705c0add99de  vmovaps [rsp+0x80], xmm9
0000705c0add99e7  vmovaps [rsp+0x90], xmm10
0000705c0add99f0  vmovaps [rsp+0xA0], xmm11
0000705c0add99f9  vmovaps [rsp+0xB0], xmm12
0000705c0add9a02  vmovaps [rsp+0xC0], xmm13
0000705c0add9a0b  vmovaps [rsp+0xD0], xmm14
0000705c0add9a14  vmovaps [rsp+0xE0], xmm15
0000705c0add9a1d  sub rsp, 0x30
0000705c0add9a21  movaps [rsp], xmm8
0000705c0add9a26  movaps [rsp+0x10], xmm12
0000705c0add9a2c  movaps [rsp+0x20], xmm15
0000705c0add9a32  lea rdi, [rsp]
0000705c0add9a36  mov esi, 0x00
0000705c0add9a3b  mov rax, 0x5969C28C4530
0000705c0add9a45  call rax
0000705c0add9a47  movaps xmm8, [rsp]
0000705c0add9a4c  add rsp, 0x30
0000705c0add9a50  vmovaps xmm0, [rsp]
0000705c0add9a55  vmovaps xmm1, [rsp+0x10]
0000705c0add9a5b  vmovaps xmm2, [rsp+0x20]
0000705c0add9a61  vmovaps xmm3, [rsp+0x30]
0000705c0add9a67  vmovaps xmm4, [rsp+0x40]
0000705c0add9a6d  vmovaps xmm5, [rsp+0x50]
0000705c0add9a73  vmovaps xmm6, [rsp+0x60]
0000705c0add9a79  vmovaps xmm7, [rsp+0x70]
0000705c0add9a7f  vmovaps xmm9, [rsp+0x80]
0000705c0add9a88  vmovaps xmm10, [rsp+0x90]
0000705c0add9a91  vmovaps xmm11, [rsp+0xA0]
0000705c0add9a9a  vmovaps xmm12, [rsp+0xB0]
0000705c0add9aa3  vmovaps xmm13, [rsp+0xC0]
0000705c0add9aac  vmovaps xmm14, [rsp+0xD0]
0000705c0add9ab5  vmovaps xmm15, [rsp+0xE0]
0000705c0add9abe  add rsp, 0xF0
0000705c0add9ac5  pop r11
0000705c0add9ac7  pop r10
0000705c0add9ac9  pop r9
0000705c0add9acb  pop r8
0000705c0add9acd  pop rsi
0000705c0add9ace  pop rdi
0000705c0add9acf  pop rdx
0000705c0add9ad0  pop rcx
0000705c0add9ad1  pop rax
0000705c0add9ad2  add rsp, 0x08
0000705c0add9ad6  jmp 0x0000705C0ADD8B7A
0000705c0add9adb  sub rsp, 0x08
0000705c0add9adf  push rax
0000705c0add9ae0  push rcx
0000705c0add9ae1  push rdx
0000705c0add9ae2  push rdi
0000705c0add9ae3  push rsi
0000705c0add9ae4  push r8
0000705c0add9ae6  push r9
0000705c0add9ae8  push r10
0000705c0add9aea  push r11
0000705c0add9aec  sub rsp, 0xF0
0000705c0add9af3  vmovaps [rsp], xmm0
0000705c0add9af8  vmovaps [rsp+0x10], xmm1
0000705c0add9afe  vmovaps [rsp+0x20], xmm2
0000705c0add9b04  vmovaps [rsp+0x30], xmm3
0000705c0add9b0a  vmovaps [rsp+0x40], xmm4
0000705c0add9b10  vmovaps [rsp+0x50], xmm5
0000705c0add9b16  vmovaps [rsp+0x60], xmm6
0000705c0add9b1c  vmovaps [rsp+0x70], xmm8
0000705c0add9b22  vmovaps [rsp+0x80], xmm9
0000705c0add9b2b  vmovaps [rsp+0x90], xmm10
0000705c0add9b34  vmovaps [rsp+0xA0], xmm11
0000705c0add9b3d  vmovaps [rsp+0xB0], xmm12
0000705c0add9b46  vmovaps [rsp+0xC0], xmm13
0000705c0add9b4f  vmovaps [rsp+0xD0], xmm14
0000705c0add9b58  vmovaps [rsp+0xE0], xmm15
0000705c0add9b61  sub rsp, 0x30
0000705c0add9b65  movaps [rsp], xmm7
0000705c0add9b69  movaps [rsp+0x10], xmm9
0000705c0add9b6f  movaps [rsp+0x20], xmm15
0000705c0add9b75  lea rdi, [rsp]
0000705c0add9b79  mov esi, 0x00
0000705c0add9b7e  mov rax, 0x5969C28C4530
0000705c0add9b88  call rax
0000705c0add9b8a  movaps xmm7, [rsp]
0000705c0add9b8e  add rsp, 0x30
0000705c0add9b92  vmovaps xmm0, [rsp]
0000705c0add9b97  vmovaps xmm1, [rsp+0x10]
0000705c0add9b9d  vmovaps xmm2, [rsp+0x20]
0000705c0add9ba3  vmovaps xmm3, [rsp+0x30]
0000705c0add9ba9  vmovaps xmm4, [rsp+0x40]
0000705c0add9baf  vmovaps xmm5, [rsp+0x50]
0000705c0add9bb5  vmovaps xmm6, [rsp+0x60]
0000705c0add9bbb  vmovaps xmm8, [rsp+0x70]
0000705c0add9bc1  vmovaps xmm9, [rsp+0x80]
0000705c0add9bca  vmovaps xmm10, [rsp+0x90]
0000705c0add9bd3  vmovaps xmm11, [rsp+0xA0]
0000705c0add9bdc  vmovaps xmm12, [rsp+0xB0]
0000705c0add9be5  vmovaps xmm13, [rsp+0xC0]
0000705c0add9bee  vmovaps xmm14, [rsp+0xD0]
0000705c0add9bf7  vmovaps xmm15, [rsp+0xE0]
0000705c0add9c00  add rsp, 0xF0
0000705c0add9c07  pop r11
0000705c0add9c09  pop r10
0000705c0add9c0b  pop r9
0000705c0add9c0d  pop r8
0000705c0add9c0f  pop rsi
0000705c0add9c10  pop rdi
0000705c0add9c11  pop rdx
0000705c0add9c12  pop rcx
0000705c0add9c13  pop rax
0000705c0add9c14  add rsp, 0x08
0000705c0add9c18  jmp 0x0000705C0ADD8BA8
0000705c0add9c1d  sub rsp, 0x08
0000705c0add9c21  push rax
0000705c0add9c22  push rcx
0000705c0add9c23  push rdx
0000705c0add9c24  push rdi
0000705c0add9c25  push rsi
0000705c0add9c26  push r8
0000705c0add9c28  push r9
0000705c0add9c2a  push r10
0000705c0add9c2c  push r11
0000705c0add9c2e  sub rsp, 0xF0
0000705c0add9c35  vmovaps [rsp], xmm0
0000705c0add9c3a  vmovaps [rsp+0x10], xmm1
0000705c0add9c40  vmovaps [rsp+0x20], xmm2
0000705c0add9c46  vmovaps [rsp+0x30], xmm3
0000705c0add9c4c  vmovaps [rsp+0x40], xmm4
0000705c0add9c52  vmovaps [rsp+0x50], xmm5
0000705c0add9c58  vmovaps [rsp+0x60], xmm6
0000705c0add9c5e  vmovaps [rsp+0x70], xmm7
0000705c0add9c64  vmovaps [rsp+0x80], xmm8
0000705c0add9c6d  vmovaps [rsp+0x90], xmm10
0000705c0add9c76  vmovaps [rsp+0xA0], xmm11
0000705c0add9c7f  vmovaps [rsp+0xB0], xmm12
0000705c0add9c88  vmovaps [rsp+0xC0], xmm13
0000705c0add9c91  vmovaps [rsp+0xD0], xmm14
0000705c0add9c9a  vmovaps [rsp+0xE0], xmm15
0000705c0add9ca3  sub rsp, 0x30
0000705c0add9ca7  movaps [rsp], xmm9
0000705c0add9cac  movaps [rsp+0x10], xmm12
0000705c0add9cb2  movaps [rsp+0x20], xmm10
0000705c0add9cb8  lea rdi, [rsp]
0000705c0add9cbc  mov esi, 0x00
0000705c0add9cc1  mov rax, 0x5969C28C4530
0000705c0add9ccb  call rax
0000705c0add9ccd  movaps xmm9, [rsp]
0000705c0add9cd2  add rsp, 0x30
0000705c0add9cd6  vmovaps xmm0, [rsp]
0000705c0add9cdb  vmovaps xmm1, [rsp+0x10]
0000705c0add9ce1  vmovaps xmm2, [rsp+0x20]
0000705c0add9ce7  vmovaps xmm3, [rsp+0x30]
0000705c0add9ced  vmovaps xmm4, [rsp+0x40]
0000705c0add9cf3  vmovaps xmm5, [rsp+0x50]
0000705c0add9cf9  vmovaps xmm6, [rsp+0x60]
0000705c0add9cff  vmovaps xmm7, [rsp+0x70]
0000705c0add9d05  vmovaps xmm8, [rsp+0x80]
0000705c0add9d0e  vmovaps xmm10, [rsp+0x90]
0000705c0add9d17  vmovaps xmm11, [rsp+0xA0]
0000705c0add9d20  vmovaps xmm12, [rsp+0xB0]
0000705c0add9d29  vmovaps xmm13, [rsp+0xC0]
0000705c0add9d32  vmovaps xmm14, [rsp+0xD0]
0000705c0add9d3b  vmovaps xmm15, [rsp+0xE0]
0000705c0add9d44  add rsp, 0xF0
0000705c0add9d4b  pop r11
0000705c0add9d4d  pop r10
0000705c0add9d4f  pop r9
0000705c0add9d51  pop r8
0000705c0add9d53  pop rsi
0000705c0add9d54  pop rdi
0000705c0add9d55  pop rdx
0000705c0add9d56  pop rcx
0000705c0add9d57  pop rax
0000705c0add9d58  add rsp, 0x08
0000705c0add9d5c  jmp 0x0000705C0ADD8BCC
0000705c0add9d61  sub rsp, 0x08
0000705c0add9d65  push rax
0000705c0add9d66  push rcx
0000705c0add9d67  push rdx
0000705c0add9d68  push rdi
0000705c0add9d69  push rsi
0000705c0add9d6a  push r8
0000705c0add9d6c  push r9
0000705c0add9d6e  push r10
0000705c0add9d70  push r11
0000705c0add9d72  sub rsp, 0xF0
0000705c0add9d79  vmovaps [rsp], xmm0
0000705c0add9d7e  vmovaps [rsp+0x10], xmm1
0000705c0add9d84  vmovaps [rsp+0x20], xmm2
0000705c0add9d8a  vmovaps [rsp+0x30], xmm3
0000705c0add9d90  vmovaps [rsp+0x40], xmm4
0000705c0add9d96  vmovaps [rsp+0x50], xmm5
0000705c0add9d9c  vmovaps [rsp+0x60], xmm6
0000705c0add9da2  vmovaps [rsp+0x70], xmm7
0000705c0add9da8  vmovaps [rsp+0x80], xmm8
0000705c0add9db1  vmovaps [rsp+0x90], xmm9
0000705c0add9dba  vmovaps [rsp+0xA0], xmm11
0000705c0add9dc3  vmovaps [rsp+0xB0], xmm12
0000705c0add9dcc  vmovaps [rsp+0xC0], xmm13
0000705c0add9dd5  vmovaps [rsp+0xD0], xmm14
0000705c0add9dde  vmovaps [rsp+0xE0], xmm15
0000705c0add9de7  sub rsp, 0x30
0000705c0add9deb  movaps [rsp], xmm10
0000705c0add9df0  movaps [rsp+0x10], xmm12
0000705c0add9df6  movaps [rsp+0x20], xmm11
0000705c0add9dfc  lea rdi, [rsp]
0000705c0add9e00  mov esi, 0x00
0000705c0add9e05  mov rax, 0x5969C28C4530
0000705c0add9e0f  call rax
0000705c0add9e11  movaps xmm10, [rsp]
0000705c0add9e16  add rsp, 0x30
0000705c0add9e1a  vmovaps xmm0, [rsp]
0000705c0add9e1f  vmovaps xmm1, [rsp+0x10]
0000705c0add9e25  vmovaps xmm2, [rsp+0x20]
0000705c0add9e2b  vmovaps xmm3, [rsp+0x30]
0000705c0add9e31  vmovaps xmm4, [rsp+0x40]
0000705c0add9e37  vmovaps xmm5, [rsp+0x50]
0000705c0add9e3d  vmovaps xmm6, [rsp+0x60]
0000705c0add9e43  vmovaps xmm7, [rsp+0x70]
0000705c0add9e49  vmovaps xmm8, [rsp+0x80]
0000705c0add9e52  vmovaps xmm9, [rsp+0x90]
0000705c0add9e5b  vmovaps xmm11, [rsp+0xA0]
0000705c0add9e64  vmovaps xmm12, [rsp+0xB0]
0000705c0add9e6d  vmovaps xmm13, [rsp+0xC0]
0000705c0add9e76  vmovaps xmm14, [rsp+0xD0]
0000705c0add9e7f  vmovaps xmm15, [rsp+0xE0]
0000705c0add9e88  add rsp, 0xF0
0000705c0add9e8f  pop r11
0000705c0add9e91  pop r10
0000705c0add9e93  pop r9
0000705c0add9e95  pop r8
0000705c0add9e97  pop rsi
0000705c0add9e98  pop rdi
0000705c0add9e99  pop rdx
0000705c0add9e9a  pop rcx
0000705c0add9e9b  pop rax
0000705c0add9e9c  add rsp, 0x08
0000705c0add9ea0  jmp 0x0000705C0ADD8BE6
0000705c0add9ea5  sub rsp, 0x08
0000705c0add9ea9  push rax
0000705c0add9eaa  push rcx
0000705c0add9eab  push rdx
0000705c0add9eac  push rdi
0000705c0add9ead  push rsi
0000705c0add9eae  push r8
0000705c0add9eb0  push r9
0000705c0add9eb2  push r10
0000705c0add9eb4  push r11
0000705c0add9eb6  sub rsp, 0xF0
0000705c0add9ebd  vmovaps [rsp], xmm0
0000705c0add9ec2  vmovaps [rsp+0x10], xmm1
0000705c0add9ec8  vmovaps [rsp+0x20], xmm2
0000705c0add9ece  vmovaps [rsp+0x30], xmm3
0000705c0add9ed4  vmovaps [rsp+0x40], xmm4
0000705c0add9eda  vmovaps [rsp+0x50], xmm5
0000705c0add9ee0  vmovaps [rsp+0x60], xmm7
0000705c0add9ee6  vmovaps [rsp+0x70], xmm8
0000705c0add9eec  vmovaps [rsp+0x80], xmm9
0000705c0add9ef5  vmovaps [rsp+0x90], xmm10
0000705c0add9efe  vmovaps [rsp+0xA0], xmm11
0000705c0add9f07  vmovaps [rsp+0xB0], xmm12
0000705c0add9f10  vmovaps [rsp+0xC0], xmm13
0000705c0add9f19  vmovaps [rsp+0xD0], xmm14
0000705c0add9f22  vmovaps [rsp+0xE0], xmm15
0000705c0add9f2b  sub rsp, 0x30
0000705c0add9f2f  movaps [rsp], xmm6
0000705c0add9f33  movaps [rsp+0x10], xmm12
0000705c0add9f39  movaps [rsp+0x20], xmm11
0000705c0add9f3f  lea rdi, [rsp]
0000705c0add9f43  mov esi, 0x00
0000705c0add9f48  mov rax, 0x5969C28C4530
0000705c0add9f52  call rax
0000705c0add9f54  movaps xmm6, [rsp]
0000705c0add9f58  add rsp, 0x30
0000705c0add9f5c  vmovaps xmm0, [rsp]
0000705c0add9f61  vmovaps xmm1, [rsp+0x10]
0000705c0add9f67  vmovaps xmm2, [rsp+0x20]
0000705c0add9f6d  vmovaps xmm3, [rsp+0x30]
0000705c0add9f73  vmovaps xmm4, [rsp+0x40]
0000705c0add9f79  vmovaps xmm5, [rsp+0x50]
0000705c0add9f7f  vmovaps xmm7, [rsp+0x60]
0000705c0add9f85  vmovaps xmm8, [rsp+0x70]
0000705c0add9f8b  vmovaps xmm9, [rsp+0x80]
0000705c0add9f94  vmovaps xmm10, [rsp+0x90]
0000705c0add9f9d  vmovaps xmm11, [rsp+0xA0]
0000705c0add9fa6  vmovaps xmm12, [rsp+0xB0]
0000705c0add9faf  vmovaps xmm13, [rsp+0xC0]
0000705c0add9fb8  vmovaps xmm14, [rsp+0xD0]
0000705c0add9fc1  vmovaps xmm15, [rsp+0xE0]
0000705c0add9fca  add rsp, 0xF0
0000705c0add9fd1  pop r11
0000705c0add9fd3  pop r10
0000705c0add9fd5  pop r9
0000705c0add9fd7  pop r8
0000705c0add9fd9  pop rsi
0000705c0add9fda  pop rdi
0000705c0add9fdb  pop rdx
0000705c0add9fdc  pop rcx
0000705c0add9fdd  pop rax
0000705c0add9fde  add rsp, 0x08
0000705c0add9fe2  jmp 0x0000705C0ADD8C07
0000705c0add9fe7  sub rsp, 0x08
0000705c0add9feb  push rax
0000705c0add9fec  push rcx
0000705c0add9fed  push rdx
0000705c0add9fee  push rdi
0000705c0add9fef  push rsi
0000705c0add9ff0  push r8
0000705c0add9ff2  push r9
0000705c0add9ff4  push r10
0000705c0add9ff6  push r11
0000705c0add9ff8  sub rsp, 0xF0
0000705c0add9fff  vmovaps [rsp], xmm0
0000705c0adda004  vmovaps [rsp+0x10], xmm1
0000705c0adda00a  vmovaps [rsp+0x20], xmm2
0000705c0adda010  vmovaps [rsp+0x30], xmm4
0000705c0adda016  vmovaps [rsp+0x40], xmm5
0000705c0adda01c  vmovaps [rsp+0x50], xmm6
0000705c0adda022  vmovaps [rsp+0x60], xmm7
0000705c0adda028  vmovaps [rsp+0x70], xmm8
0000705c0adda02e  vmovaps [rsp+0x80], xmm9
0000705c0adda037  vmovaps [rsp+0x90], xmm10
0000705c0adda040  vmovaps [rsp+0xA0], xmm11
0000705c0adda049  vmovaps [rsp+0xB0], xmm12
0000705c0adda052  vmovaps [rsp+0xC0], xmm13
0000705c0adda05b  vmovaps [rsp+0xD0], xmm14
0000705c0adda064  vmovaps [rsp+0xE0], xmm15
0000705c0adda06d  sub rsp, 0x30
0000705c0adda071  movaps [rsp], xmm3
0000705c0adda075  movaps [rsp+0x10], xmm5
0000705c0adda07a  movaps [rsp+0x20], xmm4
0000705c0adda07f  lea rdi, [rsp]
0000705c0adda083  mov esi, 0x00
0000705c0adda088  mov rax, 0x5969C28C4530
0000705c0adda092  call rax
0000705c0adda094  movaps xmm3, [rsp]
0000705c0adda098  add rsp, 0x30
0000705c0adda09c  vmovaps xmm0, [rsp]
0000705c0adda0a1  vmovaps xmm1, [rsp+0x10]
0000705c0adda0a7  vmovaps xmm2, [rsp+0x20]
0000705c0adda0ad  vmovaps xmm4, [rsp+0x30]
0000705c0adda0b3  vmovaps xmm5, [rsp+0x40]
0000705c0adda0b9  vmovaps xmm6, [rsp+0x50]
0000705c0adda0bf  vmovaps xmm7, [rsp+0x60]
0000705c0adda0c5  vmovaps xmm8, [rsp+0x70]
0000705c0adda0cb  vmovaps xmm9, [rsp+0x80]
0000705c0adda0d4  vmovaps xmm10, [rsp+0x90]
0000705c0adda0dd  vmovaps xmm11, [rsp+0xA0]
0000705c0adda0e6  vmovaps xmm12, [rsp+0xB0]
0000705c0adda0ef  vmovaps xmm13, [rsp+0xC0]
0000705c0adda0f8  vmovaps xmm14, [rsp+0xD0]
0000705c0adda101  vmovaps xmm15, [rsp+0xE0]
0000705c0adda10a  add rsp, 0xF0
0000705c0adda111  pop r11
0000705c0adda113  pop r10
0000705c0adda115  pop r9
0000705c0adda117  pop r8
0000705c0adda119  pop rsi
0000705c0adda11a  pop rdi
0000705c0adda11b  pop rdx
0000705c0adda11c  pop rcx
0000705c0adda11d  pop rax
0000705c0adda11e  add rsp, 0x08
0000705c0adda122  jmp 0x0000705C0ADD8C68
0000705c0adda127  sub rsp, 0x08
0000705c0adda12b  push rax
0000705c0adda12c  push rcx
0000705c0adda12d  push rdx
0000705c0adda12e  push rdi
0000705c0adda12f  push rsi
0000705c0adda130  push r8
0000705c0adda132  push r9
0000705c0adda134  push r10
0000705c0adda136  push r11
0000705c0adda138  sub rsp, 0xF0
0000705c0adda13f  vmovaps [rsp], xmm0
0000705c0adda144  vmovaps [rsp+0x10], xmm1
0000705c0adda14a  vmovaps [rsp+0x20], xmm2
0000705c0adda150  vmovaps [rsp+0x30], xmm3
0000705c0adda156  vmovaps [rsp+0x40], xmm4
0000705c0adda15c  vmovaps [rsp+0x50], xmm6
0000705c0adda162  vmovaps [rsp+0x60], xmm7
0000705c0adda168  vmovaps [rsp+0x70], xmm8
0000705c0adda16e  vmovaps [rsp+0x80], xmm9
0000705c0adda177  vmovaps [rsp+0x90], xmm10
0000705c0adda180  vmovaps [rsp+0xA0], xmm11
0000705c0adda189  vmovaps [rsp+0xB0], xmm12
0000705c0adda192  vmovaps [rsp+0xC0], xmm13
0000705c0adda19b  vmovaps [rsp+0xD0], xmm14
0000705c0adda1a4  vmovaps [rsp+0xE0], xmm15
0000705c0adda1ad  sub rsp, 0x30
0000705c0adda1b1  movaps [rsp], xmm5
0000705c0adda1b5  movaps [rsp+0x10], xmm8
0000705c0adda1bb  movaps [rsp+0x20], xmm15
0000705c0adda1c1  lea rdi, [rsp]
0000705c0adda1c5  mov esi, 0x00
0000705c0adda1ca  mov rax, 0x5969C28C4530
0000705c0adda1d4  call rax
0000705c0adda1d6  movaps xmm5, [rsp]
0000705c0adda1da  add rsp, 0x30
0000705c0adda1de  vmovaps xmm0, [rsp]
0000705c0adda1e3  vmovaps xmm1, [rsp+0x10]
0000705c0adda1e9  vmovaps xmm2, [rsp+0x20]
0000705c0adda1ef  vmovaps xmm3, [rsp+0x30]
0000705c0adda1f5  vmovaps xmm4, [rsp+0x40]
0000705c0adda1fb  vmovaps xmm6, [rsp+0x50]
0000705c0adda201  vmovaps xmm7, [rsp+0x60]
0000705c0adda207  vmovaps xmm8, [rsp+0x70]
0000705c0adda20d  vmovaps xmm9, [rsp+0x80]
0000705c0adda216  vmovaps xmm10, [rsp+0x90]
0000705c0adda21f  vmovaps xmm11, [rsp+0xA0]
0000705c0adda228  vmovaps xmm12, [rsp+0xB0]
0000705c0adda231  vmovaps xmm13, [rsp+0xC0]
0000705c0adda23a  vmovaps xmm14, [rsp+0xD0]
0000705c0adda243  vmovaps xmm15, [rsp+0xE0]
0000705c0adda24c  add rsp, 0xF0
0000705c0adda253  pop r11
0000705c0adda255  pop r10
0000705c0adda257  pop r9
0000705c0adda259  pop r8
0000705c0adda25b  pop rsi
0000705c0adda25c  pop rdi
0000705c0adda25d  pop rdx
0000705c0adda25e  pop rcx
0000705c0adda25f  pop rax
0000705c0adda260  add rsp, 0x08
0000705c0adda264  jmp 0x0000705C0ADD8CA0
0000705c0adda269  sub rsp, 0x08
0000705c0adda26d  push rax
0000705c0adda26e  push rcx
0000705c0adda26f  push rdx
0000705c0adda270  push rdi
0000705c0adda271  push rsi
0000705c0adda272  push r8
0000705c0adda274  push r9
0000705c0adda276  push r10
0000705c0adda278  push r11
0000705c0adda27a  sub rsp, 0xF0
0000705c0adda281  vmovaps [rsp], xmm0
0000705c0adda286  vmovaps [rsp+0x10], xmm1
0000705c0adda28c  vmovaps [rsp+0x20], xmm2
0000705c0adda292  vmovaps [rsp+0x30], xmm3
0000705c0adda298  vmovaps [rsp+0x40], xmm5
0000705c0adda29e  vmovaps [rsp+0x50], xmm6
0000705c0adda2a4  vmovaps [rsp+0x60], xmm7
0000705c0adda2aa  vmovaps [rsp+0x70], xmm8
0000705c0adda2b0  vmovaps [rsp+0x80], xmm9
0000705c0adda2b9  vmovaps [rsp+0x90], xmm10
0000705c0adda2c2  vmovaps [rsp+0xA0], xmm11
0000705c0adda2cb  vmovaps [rsp+0xB0], xmm12
0000705c0adda2d4  vmovaps [rsp+0xC0], xmm13
0000705c0adda2dd  vmovaps [rsp+0xD0], xmm14
0000705c0adda2e6  vmovaps [rsp+0xE0], xmm15
0000705c0adda2ef  sub rsp, 0x30
0000705c0adda2f3  movaps [rsp], xmm4
0000705c0adda2f7  movaps [rsp+0x10], xmm9
0000705c0adda2fd  movaps [rsp+0x20], xmm8
0000705c0adda303  lea rdi, [rsp]
0000705c0adda307  mov esi, 0x00
0000705c0adda30c  mov rax, 0x5969C28C4530
0000705c0adda316  call rax
0000705c0adda318  movaps xmm4, [rsp]
0000705c0adda31c  add rsp, 0x30
0000705c0adda320  vmovaps xmm0, [rsp]
0000705c0adda325  vmovaps xmm1, [rsp+0x10]
0000705c0adda32b  vmovaps xmm2, [rsp+0x20]
0000705c0adda331  vmovaps xmm3, [rsp+0x30]
0000705c0adda337  vmovaps xmm5, [rsp+0x40]
0000705c0adda33d  vmovaps xmm6, [rsp+0x50]
0000705c0adda343  vmovaps xmm7, [rsp+0x60]
0000705c0adda349  vmovaps xmm8, [rsp+0x70]
0000705c0adda34f  vmovaps xmm9, [rsp+0x80]
0000705c0adda358  vmovaps xmm10, [rsp+0x90]
0000705c0adda361  vmovaps xmm11, [rsp+0xA0]
0000705c0adda36a  vmovaps xmm12, [rsp+0xB0]
0000705c0adda373  vmovaps xmm13, [rsp+0xC0]
0000705c0adda37c  vmovaps xmm14, [rsp+0xD0]
0000705c0adda385  vmovaps xmm15, [rsp+0xE0]
0000705c0adda38e  add rsp, 0xF0
0000705c0adda395  pop r11
0000705c0adda397  pop r10
0000705c0adda399  pop r9
0000705c0adda39b  pop r8
0000705c0adda39d  pop rsi
0000705c0adda39e  pop rdi
0000705c0adda39f  pop rdx
0000705c0adda3a0  pop rcx
0000705c0adda3a1  pop rax
0000705c0adda3a2  add rsp, 0x08
0000705c0adda3a6  jmp 0x0000705C0ADD8CC1
0000705c0adda3ab  sub rsp, 0x08
0000705c0adda3af  push rax
0000705c0adda3b0  push rcx
0000705c0adda3b1  push rdx
0000705c0adda3b2  push rdi
0000705c0adda3b3  push rsi
0000705c0adda3b4  push r8
0000705c0adda3b6  push r9
0000705c0adda3b8  push r10
0000705c0adda3ba  push r11
0000705c0adda3bc  sub rsp, 0xF0
0000705c0adda3c3  vmovaps [rsp], xmm0
0000705c0adda3c8  vmovaps [rsp+0x10], xmm1
0000705c0adda3ce  vmovaps [rsp+0x20], xmm2
0000705c0adda3d4  vmovaps [rsp+0x30], xmm3
0000705c0adda3da  vmovaps [rsp+0x40], xmm4
0000705c0adda3e0  vmovaps [rsp+0x50], xmm5
0000705c0adda3e6  vmovaps [rsp+0x60], xmm6
0000705c0adda3ec  vmovaps [rsp+0x70], xmm7
0000705c0adda3f2  vmovaps [rsp+0x80], xmm8
0000705c0adda3fb  vmovaps [rsp+0x90], xmm10
0000705c0adda404  vmovaps [rsp+0xA0], xmm11
0000705c0adda40d  vmovaps [rsp+0xB0], xmm12
0000705c0adda416  vmovaps [rsp+0xC0], xmm13
0000705c0adda41f  vmovaps [rsp+0xD0], xmm14
0000705c0adda428  vmovaps [rsp+0xE0], xmm15
0000705c0adda431  sub rsp, 0x30
0000705c0adda435  movaps [rsp], xmm9
0000705c0adda43a  movaps [rsp+0x10], xmm10
0000705c0adda440  movaps [rsp+0x20], xmm8
0000705c0adda446  lea rdi, [rsp]
0000705c0adda44a  mov esi, 0x00
0000705c0adda44f  mov rax, 0x5969C28C4530
0000705c0adda459  call rax
0000705c0adda45b  movaps xmm9, [rsp]
0000705c0adda460  add rsp, 0x30
0000705c0adda464  vmovaps xmm0, [rsp]
0000705c0adda469  vmovaps xmm1, [rsp+0x10]
0000705c0adda46f  vmovaps xmm2, [rsp+0x20]
0000705c0adda475  vmovaps xmm3, [rsp+0x30]
0000705c0adda47b  vmovaps xmm4, [rsp+0x40]
0000705c0adda481  vmovaps xmm5, [rsp+0x50]
0000705c0adda487  vmovaps xmm6, [rsp+0x60]
0000705c0adda48d  vmovaps xmm7, [rsp+0x70]
0000705c0adda493  vmovaps xmm8, [rsp+0x80]
0000705c0adda49c  vmovaps xmm10, [rsp+0x90]
0000705c0adda4a5  vmovaps xmm11, [rsp+0xA0]
0000705c0adda4ae  vmovaps xmm12, [rsp+0xB0]
0000705c0adda4b7  vmovaps xmm13, [rsp+0xC0]
0000705c0adda4c0  vmovaps xmm14, [rsp+0xD0]
0000705c0adda4c9  vmovaps xmm15, [rsp+0xE0]
0000705c0adda4d2  add rsp, 0xF0
0000705c0adda4d9  pop r11
0000705c0adda4db  pop r10
0000705c0adda4dd  pop r9
0000705c0adda4df  pop r8
0000705c0adda4e1  pop rsi
0000705c0adda4e2  pop rdi
0000705c0adda4e3  pop rdx
0000705c0adda4e4  pop rcx
0000705c0adda4e5  pop rax
0000705c0adda4e6  add rsp, 0x08
0000705c0adda4ea  jmp 0x0000705C0ADD8CDB
0000705c0adda4ef  call 0x0000705C0ACD64F0
0000705c0adda4f4  jmp 0x0000705C0ADD8DF5
0000705c0adda4f9  call 0x0000705C0ACD64F0
0000705c0adda4fe  jmp 0x0000705C0ADD8E0B
0000705c0adda503  sub rsp, 0x08
0000705c0adda507  push rax
0000705c0adda508  push rcx
0000705c0adda509  push rdx
0000705c0adda50a  push rdi
0000705c0adda50b  push rsi
0000705c0adda50c  push r8
0000705c0adda50e  push r9
0000705c0adda510  push r10
0000705c0adda512  push r11
0000705c0adda514  sub rsp, 0xF0
0000705c0adda51b  vmovaps [rsp], xmm0
0000705c0adda520  vmovaps [rsp+0x10], xmm2
0000705c0adda526  vmovaps [rsp+0x20], xmm3
0000705c0adda52c  vmovaps [rsp+0x30], xmm4
0000705c0adda532  vmovaps [rsp+0x40], xmm5
0000705c0adda538  vmovaps [rsp+0x50], xmm6
0000705c0adda53e  vmovaps [rsp+0x60], xmm7
0000705c0adda544  vmovaps [rsp+0x70], xmm8
0000705c0adda54a  vmovaps [rsp+0x80], xmm9
0000705c0adda553  vmovaps [rsp+0x90], xmm10
0000705c0adda55c  vmovaps [rsp+0xA0], xmm11
0000705c0adda565  vmovaps [rsp+0xB0], xmm12
0000705c0adda56e  vmovaps [rsp+0xC0], xmm13
0000705c0adda577  vmovaps [rsp+0xD0], xmm14
0000705c0adda580  vmovaps [rsp+0xE0], xmm15
0000705c0adda589  sub rsp, 0x30
0000705c0adda58d  movaps [rsp], xmm1
0000705c0adda591  movaps [rsp+0x10], xmm6
0000705c0adda596  movaps [rsp+0x20], xmm15
0000705c0adda59c  lea rdi, [rsp]
0000705c0adda5a0  mov esi, 0x00
0000705c0adda5a5  mov rax, 0x5969C28C4530
0000705c0adda5af  call rax
0000705c0adda5b1  movaps xmm1, [rsp]
0000705c0adda5b5  add rsp, 0x30
0000705c0adda5b9  vmovaps xmm0, [rsp]
0000705c0adda5be  vmovaps xmm2, [rsp+0x10]
0000705c0adda5c4  vmovaps xmm3, [rsp+0x20]
0000705c0adda5ca  vmovaps xmm4, [rsp+0x30]
0000705c0adda5d0  vmovaps xmm5, [rsp+0x40]
0000705c0adda5d6  vmovaps xmm6, [rsp+0x50]
0000705c0adda5dc  vmovaps xmm7, [rsp+0x60]
0000705c0adda5e2  vmovaps xmm8, [rsp+0x70]
0000705c0adda5e8  vmovaps xmm9, [rsp+0x80]
0000705c0adda5f1  vmovaps xmm10, [rsp+0x90]
0000705c0adda5fa  vmovaps xmm11, [rsp+0xA0]
0000705c0adda603  vmovaps xmm12, [rsp+0xB0]
0000705c0adda60c  vmovaps xmm13, [rsp+0xC0]
0000705c0adda615  vmovaps xmm14, [rsp+0xD0]
0000705c0adda61e  vmovaps xmm15, [rsp+0xE0]
0000705c0adda627  add rsp, 0xF0
0000705c0adda62e  pop r11
0000705c0adda630  pop r10
0000705c0adda632  pop r9
0000705c0adda634  pop r8
0000705c0adda636  pop rsi
0000705c0adda637  pop rdi
0000705c0adda638  pop rdx
0000705c0adda639  pop rcx
0000705c0adda63a  pop rax
0000705c0adda63b  add rsp, 0x08
0000705c0adda63f  jmp 0x0000705C0ADD8E48
0000705c0adda644  call 0x0000705C0ACE5820
0000705c0adda649  jmp 0x0000705C0ADD8E55
0000705c0adda64e  sub rsp, 0x08
0000705c0adda652  push rax
0000705c0adda653  push rcx
0000705c0adda654  push rdx
0000705c0adda655  push rdi
0000705c0adda656  push rsi
0000705c0adda657  push r8
0000705c0adda659  push r9
0000705c0adda65b  push r10
0000705c0adda65d  push r11
0000705c0adda65f  sub rsp, 0xF0
0000705c0adda666  vmovaps [rsp], xmm0
0000705c0adda66b  vmovaps [rsp+0x10], xmm1
0000705c0adda671  vmovaps [rsp+0x20], xmm2
0000705c0adda677  vmovaps [rsp+0x30], xmm3
0000705c0adda67d  vmovaps [rsp+0x40], xmm4
0000705c0adda683  vmovaps [rsp+0x50], xmm5
0000705c0adda689  vmovaps [rsp+0x60], xmm6
0000705c0adda68f  vmovaps [rsp+0x70], xmm7
0000705c0adda695  vmovaps [rsp+0x80], xmm8
0000705c0adda69e  vmovaps [rsp+0x90], xmm9
0000705c0adda6a7  vmovaps [rsp+0xA0], xmm10
0000705c0adda6b0  vmovaps [rsp+0xB0], xmm11
0000705c0adda6b9  vmovaps [rsp+0xC0], xmm12
0000705c0adda6c2  vmovaps [rsp+0xD0], xmm13
0000705c0adda6cb  vmovaps [rsp+0xE0], xmm15
0000705c0adda6d4  sub rsp, 0x30
0000705c0adda6d8  movaps [rsp], xmm14
0000705c0adda6dd  movaps [rsp+0x10], xmm4
0000705c0adda6e2  movaps [rsp+0x20], xmm3
0000705c0adda6e7  lea rdi, [rsp]
0000705c0adda6eb  mov esi, 0x00
0000705c0adda6f0  mov rax, 0x5969C28C4530
0000705c0adda6fa  call rax
0000705c0adda6fc  movaps xmm14, [rsp]
0000705c0adda701  add rsp, 0x30
0000705c0adda705  vmovaps xmm0, [rsp]
0000705c0adda70a  vmovaps xmm1, [rsp+0x10]
0000705c0adda710  vmovaps xmm2, [rsp+0x20]
0000705c0adda716  vmovaps xmm3, [rsp+0x30]
0000705c0adda71c  vmovaps xmm4, [rsp+0x40]
0000705c0adda722  vmovaps xmm5, [rsp+0x50]
0000705c0adda728  vmovaps xmm6, [rsp+0x60]
0000705c0adda72e  vmovaps xmm7, [rsp+0x70]
0000705c0adda734  vmovaps xmm8, [rsp+0x80]
0000705c0adda73d  vmovaps xmm9, [rsp+0x90]
0000705c0adda746  vmovaps xmm10, [rsp+0xA0]
0000705c0adda74f  vmovaps xmm11, [rsp+0xB0]
0000705c0adda758  vmovaps xmm12, [rsp+0xC0]
0000705c0adda761  vmovaps xmm13, [rsp+0xD0]
0000705c0adda76a  vmovaps xmm15, [rsp+0xE0]
0000705c0adda773  add rsp, 0xF0
0000705c0adda77a  pop r11
0000705c0adda77c  pop r10
0000705c0adda77e  pop r9
0000705c0adda780  pop r8
0000705c0adda782  pop rsi
0000705c0adda783  pop rdi
0000705c0adda784  pop rdx
0000705c0adda785  pop rcx
0000705c0adda786  pop rax
0000705c0adda787  add rsp, 0x08
0000705c0adda78b  jmp 0x0000705C0ADD8E6F
0000705c0adda790  sub rsp, 0x08
0000705c0adda794  push rax
0000705c0adda795  push rcx
0000705c0adda796  push rdx
0000705c0adda797  push rdi
0000705c0adda798  push rsi
0000705c0adda799  push r8
0000705c0adda79b  push r9
0000705c0adda79d  push r10
0000705c0adda79f  push r11
0000705c0adda7a1  sub rsp, 0xF0
0000705c0adda7a8  vmovaps [rsp], xmm0
0000705c0adda7ad  vmovaps [rsp+0x10], xmm1
0000705c0adda7b3  vmovaps [rsp+0x20], xmm2
0000705c0adda7b9  vmovaps [rsp+0x30], xmm3
0000705c0adda7bf  vmovaps [rsp+0x40], xmm4
0000705c0adda7c5  vmovaps [rsp+0x50], xmm5
0000705c0adda7cb  vmovaps [rsp+0x60], xmm7
0000705c0adda7d1  vmovaps [rsp+0x70], xmm8
0000705c0adda7d7  vmovaps [rsp+0x80], xmm9
0000705c0adda7e0  vmovaps [rsp+0x90], xmm10
0000705c0adda7e9  vmovaps [rsp+0xA0], xmm11
0000705c0adda7f2  vmovaps [rsp+0xB0], xmm12
0000705c0adda7fb  vmovaps [rsp+0xC0], xmm13
0000705c0adda804  vmovaps [rsp+0xD0], xmm14
0000705c0adda80d  vmovaps [rsp+0xE0], xmm15
0000705c0adda816  sub rsp, 0x30
0000705c0adda81a  movaps [rsp], xmm6
0000705c0adda81e  movaps [rsp+0x10], xmm9
0000705c0adda824  movaps [rsp+0x20], xmm7
0000705c0adda829  lea rdi, [rsp]
0000705c0adda82d  mov esi, 0x00
0000705c0adda832  mov rax, 0x5969C28C4530
0000705c0adda83c  call rax
0000705c0adda83e  movaps xmm6, [rsp]
0000705c0adda842  add rsp, 0x30
0000705c0adda846  vmovaps xmm0, [rsp]
0000705c0adda84b  vmovaps xmm1, [rsp+0x10]
0000705c0adda851  vmovaps xmm2, [rsp+0x20]
0000705c0adda857  vmovaps xmm3, [rsp+0x30]
0000705c0adda85d  vmovaps xmm4, [rsp+0x40]
0000705c0adda863  vmovaps xmm5, [rsp+0x50]
0000705c0adda869  vmovaps xmm7, [rsp+0x60]
0000705c0adda86f  vmovaps xmm8, [rsp+0x70]
0000705c0adda875  vmovaps xmm9, [rsp+0x80]
0000705c0adda87e  vmovaps xmm10, [rsp+0x90]
0000705c0adda887  vmovaps xmm11, [rsp+0xA0]
0000705c0adda890  vmovaps xmm12, [rsp+0xB0]
0000705c0adda899  vmovaps xmm13, [rsp+0xC0]
0000705c0adda8a2  vmovaps xmm14, [rsp+0xD0]
0000705c0adda8ab  vmovaps xmm15, [rsp+0xE0]
0000705c0adda8b4  add rsp, 0xF0
0000705c0adda8bb  pop r11
0000705c0adda8bd  pop r10
0000705c0adda8bf  pop r9
0000705c0adda8c1  pop r8
0000705c0adda8c3  pop rsi
0000705c0adda8c4  pop rdi
0000705c0adda8c5  pop rdx
0000705c0adda8c6  pop rcx
0000705c0adda8c7  pop rax
0000705c0adda8c8  add rsp, 0x08
0000705c0adda8cc  jmp 0x0000705C0ADD8E87
0000705c0adda8d1  sub rsp, 0x08
0000705c0adda8d5  push rax
0000705c0adda8d6  push rcx
0000705c0adda8d7  push rdx
0000705c0adda8d8  push rdi
0000705c0adda8d9  push rsi
0000705c0adda8da  push r8
0000705c0adda8dc  push r9
0000705c0adda8de  push r10
0000705c0adda8e0  push r11
0000705c0adda8e2  sub rsp, 0xF0
0000705c0adda8e9  vmovaps [rsp], xmm0
0000705c0adda8ee  vmovaps [rsp+0x10], xmm1
0000705c0adda8f4  vmovaps [rsp+0x20], xmm2
0000705c0adda8fa  vmovaps [rsp+0x30], xmm3
0000705c0adda900  vmovaps [rsp+0x40], xmm4
0000705c0adda906  vmovaps [rsp+0x50], xmm5
0000705c0adda90c  vmovaps [rsp+0x60], xmm6
0000705c0adda912  vmovaps [rsp+0x70], xmm8
0000705c0adda918  vmovaps [rsp+0x80], xmm9
0000705c0adda921  vmovaps [rsp+0x90], xmm10
0000705c0adda92a  vmovaps [rsp+0xA0], xmm11
0000705c0adda933  vmovaps [rsp+0xB0], xmm12
0000705c0adda93c  vmovaps [rsp+0xC0], xmm13
0000705c0adda945  vmovaps [rsp+0xD0], xmm14
0000705c0adda94e  vmovaps [rsp+0xE0], xmm15
0000705c0adda957  sub rsp, 0x30
0000705c0adda95b  movaps [rsp], xmm7
0000705c0adda95f  movaps [rsp+0x10], xmm4
0000705c0adda964  movaps [rsp+0x20], xmm9
0000705c0adda96a  lea rdi, [rsp]
0000705c0adda96e  mov esi, 0x00
0000705c0adda973  mov rax, 0x5969C28C4530
0000705c0adda97d  call rax
0000705c0adda97f  movaps xmm7, [rsp]
0000705c0adda983  add rsp, 0x30
0000705c0adda987  vmovaps xmm0, [rsp]
0000705c0adda98c  vmovaps xmm1, [rsp+0x10]
0000705c0adda992  vmovaps xmm2, [rsp+0x20]
0000705c0adda998  vmovaps xmm3, [rsp+0x30]
0000705c0adda99e  vmovaps xmm4, [rsp+0x40]
0000705c0adda9a4  vmovaps xmm5, [rsp+0x50]
0000705c0adda9aa  vmovaps xmm6, [rsp+0x60]
0000705c0adda9b0  vmovaps xmm8, [rsp+0x70]
0000705c0adda9b6  vmovaps xmm9, [rsp+0x80]
0000705c0adda9bf  vmovaps xmm10, [rsp+0x90]
0000705c0adda9c8  vmovaps xmm11, [rsp+0xA0]
0000705c0adda9d1  vmovaps xmm12, [rsp+0xB0]
0000705c0adda9da  vmovaps xmm13, [rsp+0xC0]
0000705c0adda9e3  vmovaps xmm14, [rsp+0xD0]
0000705c0adda9ec  vmovaps xmm15, [rsp+0xE0]
0000705c0adda9f5  add rsp, 0xF0
0000705c0adda9fc  pop r11
0000705c0adda9fe  pop r10
0000705c0addaa00  pop r9
0000705c0addaa02  pop r8
0000705c0addaa04  pop rsi
0000705c0addaa05  pop rdi
0000705c0addaa06  pop rdx
0000705c0addaa07  pop rcx
0000705c0addaa08  pop rax
0000705c0addaa09  add rsp, 0x08
0000705c0addaa0d  jmp 0x0000705C0ADD8EB4
0000705c0addaa12  sub rsp, 0x08
0000705c0addaa16  push rax
0000705c0addaa17  push rcx
0000705c0addaa18  push rdx
0000705c0addaa19  push rdi
0000705c0addaa1a  push rsi
0000705c0addaa1b  push r8
0000705c0addaa1d  push r9
0000705c0addaa1f  push r10
0000705c0addaa21  push r11
0000705c0addaa23  sub rsp, 0xF0
0000705c0addaa2a  vmovaps [rsp], xmm0
0000705c0addaa2f  vmovaps [rsp+0x10], xmm1
0000705c0addaa35  vmovaps [rsp+0x20], xmm2
0000705c0addaa3b  vmovaps [rsp+0x30], xmm3
0000705c0addaa41  vmovaps [rsp+0x40], xmm5
0000705c0addaa47  vmovaps [rsp+0x50], xmm6
0000705c0addaa4d  vmovaps [rsp+0x60], xmm7
0000705c0addaa53  vmovaps [rsp+0x70], xmm8
0000705c0addaa59  vmovaps [rsp+0x80], xmm9
0000705c0addaa62  vmovaps [rsp+0x90], xmm10
0000705c0addaa6b  vmovaps [rsp+0xA0], xmm11
0000705c0addaa74  vmovaps [rsp+0xB0], xmm12
0000705c0addaa7d  vmovaps [rsp+0xC0], xmm13
0000705c0addaa86  vmovaps [rsp+0xD0], xmm14
0000705c0addaa8f  vmovaps [rsp+0xE0], xmm15
0000705c0addaa98  sub rsp, 0x30
0000705c0addaa9c  movaps [rsp], xmm4
0000705c0addaaa0  movaps [rsp+0x10], xmm15
0000705c0addaaa6  movaps [rsp+0x20], xmm9
0000705c0addaaac  lea rdi, [rsp]
0000705c0addaab0  mov esi, 0x00
0000705c0addaab5  mov rax, 0x5969C28C4530
0000705c0addaabf  call rax
0000705c0addaac1  movaps xmm4, [rsp]
0000705c0addaac5  add rsp, 0x30
0000705c0addaac9  vmovaps xmm0, [rsp]
0000705c0addaace  vmovaps xmm1, [rsp+0x10]
0000705c0addaad4  vmovaps xmm2, [rsp+0x20]
0000705c0addaada  vmovaps xmm3, [rsp+0x30]
0000705c0addaae0  vmovaps xmm5, [rsp+0x40]
0000705c0addaae6  vmovaps xmm6, [rsp+0x50]
0000705c0addaaec  vmovaps xmm7, [rsp+0x60]
0000705c0addaaf2  vmovaps xmm8, [rsp+0x70]
0000705c0addaaf8  vmovaps xmm9, [rsp+0x80]
0000705c0addab01  vmovaps xmm10, [rsp+0x90]
0000705c0addab0a  vmovaps xmm11, [rsp+0xA0]
0000705c0addab13  vmovaps xmm12, [rsp+0xB0]
0000705c0addab1c  vmovaps xmm13, [rsp+0xC0]
0000705c0addab25  vmovaps xmm14, [rsp+0xD0]
0000705c0addab2e  vmovaps xmm15, [rsp+0xE0]
0000705c0addab37  add rsp, 0xF0
0000705c0addab3e  pop r11
0000705c0addab40  pop r10
0000705c0addab42  pop r9
0000705c0addab44  pop r8
0000705c0addab46  pop rsi
0000705c0addab47  pop rdi
0000705c0addab48  pop rdx
0000705c0addab49  pop rcx
0000705c0addab4a  pop rax
0000705c0addab4b  add rsp, 0x08
0000705c0addab4f  jmp 0x0000705C0ADD8ED9
0000705c0addab54  call 0x0000705C0ACE5820
0000705c0addab59  jmp 0x0000705C0ADD8EE6
0000705c0addab5e  sub rsp, 0x08
0000705c0addab62  push rax
0000705c0addab63  push rcx
0000705c0addab64  push rdx
0000705c0addab65  push rdi
0000705c0addab66  push rsi
0000705c0addab67  push r8
0000705c0addab69  push r9
0000705c0addab6b  push r10
0000705c0addab6d  push r11
0000705c0addab6f  sub rsp, 0xF0
0000705c0addab76  vmovaps [rsp], xmm0
0000705c0addab7b  vmovaps [rsp+0x10], xmm1
0000705c0addab81  vmovaps [rsp+0x20], xmm2
0000705c0addab87  vmovaps [rsp+0x30], xmm4
0000705c0addab8d  vmovaps [rsp+0x40], xmm5
0000705c0addab93  vmovaps [rsp+0x50], xmm6
0000705c0addab99  vmovaps [rsp+0x60], xmm7
0000705c0addab9f  vmovaps [rsp+0x70], xmm8
0000705c0addaba5  vmovaps [rsp+0x80], xmm9
0000705c0addabae  vmovaps [rsp+0x90], xmm10
0000705c0addabb7  vmovaps [rsp+0xA0], xmm11
0000705c0addabc0  vmovaps [rsp+0xB0], xmm12
0000705c0addabc9  vmovaps [rsp+0xC0], xmm13
0000705c0addabd2  vmovaps [rsp+0xD0], xmm14
0000705c0addabdb  vmovaps [rsp+0xE0], xmm15
0000705c0addabe4  sub rsp, 0x30
0000705c0addabe8  movaps [rsp], xmm3
0000705c0addabec  movaps [rsp+0x10], xmm1
0000705c0addabf1  movaps [rsp+0x20], xmm9
0000705c0addabf7  lea rdi, [rsp]
0000705c0addabfb  mov esi, 0x00
0000705c0addac00  mov rax, 0x5969C28C4530
0000705c0addac0a  call rax
0000705c0addac0c  movaps xmm3, [rsp]
0000705c0addac10  add rsp, 0x30
0000705c0addac14  vmovaps xmm0, [rsp]
0000705c0addac19  vmovaps xmm1, [rsp+0x10]
0000705c0addac1f  vmovaps xmm2, [rsp+0x20]
0000705c0addac25  vmovaps xmm4, [rsp+0x30]
0000705c0addac2b  vmovaps xmm5, [rsp+0x40]
0000705c0addac31  vmovaps xmm6, [rsp+0x50]
0000705c0addac37  vmovaps xmm7, [rsp+0x60]
0000705c0addac3d  vmovaps xmm8, [rsp+0x70]
0000705c0addac43  vmovaps xmm9, [rsp+0x80]
0000705c0addac4c  vmovaps xmm10, [rsp+0x90]
0000705c0addac55  vmovaps xmm11, [rsp+0xA0]
0000705c0addac5e  vmovaps xmm12, [rsp+0xB0]
0000705c0addac67  vmovaps xmm13, [rsp+0xC0]
0000705c0addac70  vmovaps xmm14, [rsp+0xD0]
0000705c0addac79  vmovaps xmm15, [rsp+0xE0]
0000705c0addac82  add rsp, 0xF0
0000705c0addac89  pop r11
0000705c0addac8b  pop r10
0000705c0addac8d  pop r9
0000705c0addac8f  pop r8
0000705c0addac91  pop rsi
0000705c0addac92  pop rdi
0000705c0addac93  pop rdx
0000705c0addac94  pop rcx
0000705c0addac95  pop rax
0000705c0addac96  add rsp, 0x08
0000705c0addac9a  jmp 0x0000705C0ADD8F23
0000705c0addac9f  sub rsp, 0x08
0000705c0addaca3  push rax
0000705c0addaca4  push rcx
0000705c0addaca5  push rdx
0000705c0addaca6  push rdi
0000705c0addaca7  push rsi
0000705c0addaca8  push r8
0000705c0addacaa  push r9
0000705c0addacac  push r10
0000705c0addacae  push r11
0000705c0addacb0  sub rsp, 0xF0
0000705c0addacb7  vmovaps [rsp], xmm0
0000705c0addacbc  vmovaps [rsp+0x10], xmm2
0000705c0addacc2  vmovaps [rsp+0x20], xmm3
0000705c0addacc8  vmovaps [rsp+0x30], xmm4
0000705c0addacce  vmovaps [rsp+0x40], xmm5
0000705c0addacd4  vmovaps [rsp+0x50], xmm6
0000705c0addacda  vmovaps [rsp+0x60], xmm7
0000705c0addace0  vmovaps [rsp+0x70], xmm8
0000705c0addace6  vmovaps [rsp+0x80], xmm9
0000705c0addacef  vmovaps [rsp+0x90], xmm10
0000705c0addacf8  vmovaps [rsp+0xA0], xmm11
0000705c0addad01  vmovaps [rsp+0xB0], xmm12
0000705c0addad0a  vmovaps [rsp+0xC0], xmm13
0000705c0addad13  vmovaps [rsp+0xD0], xmm14
0000705c0addad1c  vmovaps [rsp+0xE0], xmm15
0000705c0addad25  sub rsp, 0x30
0000705c0addad29  movaps [rsp], xmm1
0000705c0addad2d  movaps [rsp+0x10], xmm15
0000705c0addad33  movaps [rsp+0x20], xmm9
0000705c0addad39  lea rdi, [rsp]
0000705c0addad3d  mov esi, 0x00
0000705c0addad42  mov rax, 0x5969C28C4530
0000705c0addad4c  call rax
0000705c0addad4e  movaps xmm1, [rsp]
0000705c0addad52  add rsp, 0x30
0000705c0addad56  vmovaps xmm0, [rsp]
0000705c0addad5b  vmovaps xmm2, [rsp+0x10]
0000705c0addad61  vmovaps xmm3, [rsp+0x20]
0000705c0addad67  vmovaps xmm4, [rsp+0x30]
0000705c0addad6d  vmovaps xmm5, [rsp+0x40]
0000705c0addad73  vmovaps xmm6, [rsp+0x50]
0000705c0addad79  vmovaps xmm7, [rsp+0x60]
0000705c0addad7f  vmovaps xmm8, [rsp+0x70]
0000705c0addad85  vmovaps xmm9, [rsp+0x80]
0000705c0addad8e  vmovaps xmm10, [rsp+0x90]
0000705c0addad97  vmovaps xmm11, [rsp+0xA0]
0000705c0addada0  vmovaps xmm12, [rsp+0xB0]
0000705c0addada9  vmovaps xmm13, [rsp+0xC0]
0000705c0addadb2  vmovaps xmm14, [rsp+0xD0]
0000705c0addadbb  vmovaps xmm15, [rsp+0xE0]
0000705c0addadc4  add rsp, 0xF0
0000705c0addadcb  pop r11
0000705c0addadcd  pop r10
0000705c0addadcf  pop r9
0000705c0addadd1  pop r8
0000705c0addadd3  pop rsi
0000705c0addadd4  pop rdi
0000705c0addadd5  pop rdx
0000705c0addadd6  pop rcx
0000705c0addadd7  pop rax
0000705c0addadd8  add rsp, 0x08
0000705c0addaddc  jmp 0x0000705C0ADD8FAB
0000705c0addade1  call 0x0000705C0ACE5820
0000705c0addade6  jmp 0x0000705C0ADD8FB8
0000705c0addadeb  sub rsp, 0x08
0000705c0addadef  push rax
0000705c0addadf0  push rcx
0000705c0addadf1  push rdx
0000705c0addadf2  push rdi
0000705c0addadf3  push rsi
0000705c0addadf4  push r8
0000705c0addadf6  push r9
0000705c0addadf8  push r10
0000705c0addadfa  push r11
0000705c0addadfc  sub rsp, 0xF0
0000705c0addae03  vmovaps [rsp], xmm0
0000705c0addae08  vmovaps [rsp+0x10], xmm2
0000705c0addae0e  vmovaps [rsp+0x20], xmm3
0000705c0addae14  vmovaps [rsp+0x30], xmm4
0000705c0addae1a  vmovaps [rsp+0x40], xmm5
0000705c0addae20  vmovaps [rsp+0x50], xmm6
0000705c0addae26  vmovaps [rsp+0x60], xmm7
0000705c0addae2c  vmovaps [rsp+0x70], xmm8
0000705c0addae32  vmovaps [rsp+0x80], xmm9
0000705c0addae3b  vmovaps [rsp+0x90], xmm10
0000705c0addae44  vmovaps [rsp+0xA0], xmm11
0000705c0addae4d  vmovaps [rsp+0xB0], xmm12
0000705c0addae56  vmovaps [rsp+0xC0], xmm13
0000705c0addae5f  vmovaps [rsp+0xD0], xmm14
0000705c0addae68  vmovaps [rsp+0xE0], xmm15
0000705c0addae71  sub rsp, 0x30
0000705c0addae75  movaps [rsp], xmm1
0000705c0addae79  movaps [rsp+0x10], xmm5
0000705c0addae7e  movaps [rsp+0x20], xmm7
0000705c0addae83  lea rdi, [rsp]
0000705c0addae87  mov esi, 0x00
0000705c0addae8c  mov rax, 0x5969C28C4530
0000705c0addae96  call rax
0000705c0addae98  movaps xmm1, [rsp]
0000705c0addae9c  add rsp, 0x30
0000705c0addaea0  vmovaps xmm0, [rsp]
0000705c0addaea5  vmovaps xmm2, [rsp+0x10]
0000705c0addaeab  vmovaps xmm3, [rsp+0x20]
0000705c0addaeb1  vmovaps xmm4, [rsp+0x30]
0000705c0addaeb7  vmovaps xmm5, [rsp+0x40]
0000705c0addaebd  vmovaps xmm6, [rsp+0x50]
0000705c0addaec3  vmovaps xmm7, [rsp+0x60]
0000705c0addaec9  vmovaps xmm8, [rsp+0x70]
0000705c0addaecf  vmovaps xmm9, [rsp+0x80]
0000705c0addaed8  vmovaps xmm10, [rsp+0x90]
0000705c0addaee1  vmovaps xmm11, [rsp+0xA0]
0000705c0addaeea  vmovaps xmm12, [rsp+0xB0]
0000705c0addaef3  vmovaps xmm13, [rsp+0xC0]
0000705c0addaefc  vmovaps xmm14, [rsp+0xD0]
0000705c0addaf05  vmovaps xmm15, [rsp+0xE0]
0000705c0addaf0e  add rsp, 0xF0
0000705c0addaf15  pop r11
0000705c0addaf17  pop r10
0000705c0addaf19  pop r9
0000705c0addaf1b  pop r8
0000705c0addaf1d  pop rsi
0000705c0addaf1e  pop rdi
0000705c0addaf1f  pop rdx
0000705c0addaf20  pop rcx
0000705c0addaf21  pop rax
0000705c0addaf22  add rsp, 0x08
0000705c0addaf26  jmp 0x0000705C0ADD905D
0000705c0addaf2b  sub rsp, 0x08
0000705c0addaf2f  push rax
0000705c0addaf30  push rcx
0000705c0addaf31  push rdx
0000705c0addaf32  push rdi
0000705c0addaf33  push rsi
0000705c0addaf34  push r8
0000705c0addaf36  push r9
0000705c0addaf38  push r10
0000705c0addaf3a  push r11
0000705c0addaf3c  sub rsp, 0xF0
0000705c0addaf43  vmovaps [rsp], xmm0
0000705c0addaf48  vmovaps [rsp+0x10], xmm1
0000705c0addaf4e  vmovaps [rsp+0x20], xmm2
0000705c0addaf54  vmovaps [rsp+0x30], xmm3
0000705c0addaf5a  vmovaps [rsp+0x40], xmm4
0000705c0addaf60  vmovaps [rsp+0x50], xmm5
0000705c0addaf66  vmovaps [rsp+0x60], xmm6
0000705c0addaf6c  vmovaps [rsp+0x70], xmm8
0000705c0addaf72  vmovaps [rsp+0x80], xmm9
0000705c0addaf7b  vmovaps [rsp+0x90], xmm10
0000705c0addaf84  vmovaps [rsp+0xA0], xmm11
0000705c0addaf8d  vmovaps [rsp+0xB0], xmm12
0000705c0addaf96  vmovaps [rsp+0xC0], xmm13
0000705c0addaf9f  vmovaps [rsp+0xD0], xmm14
0000705c0addafa8  vmovaps [rsp+0xE0], xmm15
0000705c0addafb1  sub rsp, 0x30
0000705c0addafb5  movaps [rsp], xmm7
0000705c0addafb9  movaps [rsp+0x10], xmm5
0000705c0addafbe  movaps [rsp+0x20], xmm15
0000705c0addafc4  lea rdi, [rsp]
0000705c0addafc8  mov esi, 0x00
0000705c0addafcd  mov rax, 0x5969C28C4530
0000705c0addafd7  call rax
0000705c0addafd9  movaps xmm7, [rsp]
0000705c0addafdd  add rsp, 0x30
0000705c0addafe1  vmovaps xmm0, [rsp]
0000705c0addafe6  vmovaps xmm1, [rsp+0x10]
0000705c0addafec  vmovaps xmm2, [rsp+0x20]
0000705c0addaff2  vmovaps xmm3, [rsp+0x30]
0000705c0addaff8  vmovaps xmm4, [rsp+0x40]
0000705c0addaffe  vmovaps xmm5, [rsp+0x50]
0000705c0addb004  vmovaps xmm6, [rsp+0x60]
0000705c0addb00a  vmovaps xmm8, [rsp+0x70]
0000705c0addb010  vmovaps xmm9, [rsp+0x80]
0000705c0addb019  vmovaps xmm10, [rsp+0x90]
0000705c0addb022  vmovaps xmm11, [rsp+0xA0]
0000705c0addb02b  vmovaps xmm12, [rsp+0xB0]
0000705c0addb034  vmovaps xmm13, [rsp+0xC0]
0000705c0addb03d  vmovaps xmm14, [rsp+0xD0]
0000705c0addb046  vmovaps xmm15, [rsp+0xE0]
0000705c0addb04f  add rsp, 0xF0
0000705c0addb056  pop r11
0000705c0addb058  pop r10
0000705c0addb05a  pop r9
0000705c0addb05c  pop r8
0000705c0addb05e  pop rsi
0000705c0addb05f  pop rdi
0000705c0addb060  pop rdx
0000705c0addb061  pop rcx
0000705c0addb062  pop rax
0000705c0addb063  add rsp, 0x08
0000705c0addb067  jmp 0x0000705C0ADD9093
0000705c0addb06c  call 0x0000705C0ACD64F0
0000705c0addb071  jmp 0x0000705C0ADD90A0
0000705c0addb076  sub rsp, 0x08
0000705c0addb07a  push rax
0000705c0addb07b  push rcx
0000705c0addb07c  push rdx
0000705c0addb07d  push rdi
0000705c0addb07e  push rsi
0000705c0addb07f  push r8
0000705c0addb081  push r9
0000705c0addb083  push r10
0000705c0addb085  push r11
0000705c0addb087  sub rsp, 0xF0
0000705c0addb08e  vmovaps [rsp], xmm0
0000705c0addb093  vmovaps [rsp+0x10], xmm1
0000705c0addb099  vmovaps [rsp+0x20], xmm2
0000705c0addb09f  vmovaps [rsp+0x30], xmm3
0000705c0addb0a5  vmovaps [rsp+0x40], xmm4
0000705c0addb0ab  vmovaps [rsp+0x50], xmm5
0000705c0addb0b1  vmovaps [rsp+0x60], xmm6
0000705c0addb0b7  vmovaps [rsp+0x70], xmm7
0000705c0addb0bd  vmovaps [rsp+0x80], xmm8
0000705c0addb0c6  vmovaps [rsp+0x90], xmm9
0000705c0addb0cf  vmovaps [rsp+0xA0], xmm10
0000705c0addb0d8  vmovaps [rsp+0xB0], xmm11
0000705c0addb0e1  vmovaps [rsp+0xC0], xmm12
0000705c0addb0ea  vmovaps [rsp+0xD0], xmm13
0000705c0addb0f3  vmovaps [rsp+0xE0], xmm14
0000705c0addb0fc  sub rsp, 0x30
0000705c0addb100  movaps [rsp], xmm15
0000705c0addb105  movaps [rsp+0x10], xmm5
0000705c0addb10a  movaps [rsp+0x20], xmm3
0000705c0addb10f  lea rdi, [rsp]
0000705c0addb113  mov esi, 0x00
0000705c0addb118  mov rax, 0x5969C28C4530
0000705c0addb122  call rax
0000705c0addb124  movaps xmm15, [rsp]
0000705c0addb129  add rsp, 0x30
0000705c0addb12d  vmovaps xmm0, [rsp]
0000705c0addb132  vmovaps xmm1, [rsp+0x10]
0000705c0addb138  vmovaps xmm2, [rsp+0x20]
0000705c0addb13e  vmovaps xmm3, [rsp+0x30]
0000705c0addb144  vmovaps xmm4, [rsp+0x40]
0000705c0addb14a  vmovaps xmm5, [rsp+0x50]
0000705c0addb150  vmovaps xmm6, [rsp+0x60]
0000705c0addb156  vmovaps xmm7, [rsp+0x70]
0000705c0addb15c  vmovaps xmm8, [rsp+0x80]
0000705c0addb165  vmovaps xmm9, [rsp+0x90]
0000705c0addb16e  vmovaps xmm10, [rsp+0xA0]
0000705c0addb177  vmovaps xmm11, [rsp+0xB0]
0000705c0addb180  vmovaps xmm12, [rsp+0xC0]
0000705c0addb189  vmovaps xmm13, [rsp+0xD0]
0000705c0addb192  vmovaps xmm14, [rsp+0xE0]
0000705c0addb19b  add rsp, 0xF0
0000705c0addb1a2  pop r11
0000705c0addb1a4  pop r10
0000705c0addb1a6  pop r9
0000705c0addb1a8  pop r8
0000705c0addb1aa  pop rsi
0000705c0addb1ab  pop rdi
0000705c0addb1ac  pop rdx
0000705c0addb1ad  pop rcx
0000705c0addb1ae  pop rax
0000705c0addb1af  add rsp, 0x08
0000705c0addb1b3  jmp 0x0000705C0ADD90C6
0000705c0addb1b8  sub rsp, 0x08
0000705c0addb1bc  push rax
0000705c0addb1bd  push rcx
0000705c0addb1be  push rdx
0000705c0addb1bf  push rdi
0000705c0addb1c0  push rsi
0000705c0addb1c1  push r8
0000705c0addb1c3  push r9
0000705c0addb1c5  push r10
0000705c0addb1c7  push r11
0000705c0addb1c9  sub rsp, 0xF0
0000705c0addb1d0  vmovaps [rsp], xmm0
0000705c0addb1d5  vmovaps [rsp+0x10], xmm2
0000705c0addb1db  vmovaps [rsp+0x20], xmm3
0000705c0addb1e1  vmovaps [rsp+0x30], xmm4
0000705c0addb1e7  vmovaps [rsp+0x40], xmm5
0000705c0addb1ed  vmovaps [rsp+0x50], xmm6
0000705c0addb1f3  vmovaps [rsp+0x60], xmm7
0000705c0addb1f9  vmovaps [rsp+0x70], xmm8
0000705c0addb1ff  vmovaps [rsp+0x80], xmm9
0000705c0addb208  vmovaps [rsp+0x90], xmm10
0000705c0addb211  vmovaps [rsp+0xA0], xmm11
0000705c0addb21a  vmovaps [rsp+0xB0], xmm12
0000705c0addb223  vmovaps [rsp+0xC0], xmm13
0000705c0addb22c  vmovaps [rsp+0xD0], xmm14
0000705c0addb235  vmovaps [rsp+0xE0], xmm15
0000705c0addb23e  sub rsp, 0x30
0000705c0addb242  movaps [rsp], xmm1
0000705c0addb246  movaps [rsp+0x10], xmm5
0000705c0addb24b  movaps [rsp+0x20], xmm4
0000705c0addb250  lea rdi, [rsp]
0000705c0addb254  mov esi, 0x00
0000705c0addb259  mov rax, 0x5969C28C4530
0000705c0addb263  call rax
0000705c0addb265  movaps xmm1, [rsp]
0000705c0addb269  add rsp, 0x30
0000705c0addb26d  vmovaps xmm0, [rsp]
0000705c0addb272  vmovaps xmm2, [rsp+0x10]
0000705c0addb278  vmovaps xmm3, [rsp+0x20]
0000705c0addb27e  vmovaps xmm4, [rsp+0x30]
0000705c0addb284  vmovaps xmm5, [rsp+0x40]
0000705c0addb28a  vmovaps xmm6, [rsp+0x50]
0000705c0addb290  vmovaps xmm7, [rsp+0x60]
0000705c0addb296  vmovaps xmm8, [rsp+0x70]
0000705c0addb29c  vmovaps xmm9, [rsp+0x80]
0000705c0addb2a5  vmovaps xmm10, [rsp+0x90]
0000705c0addb2ae  vmovaps xmm11, [rsp+0xA0]
0000705c0addb2b7  vmovaps xmm12, [rsp+0xB0]
0000705c0addb2c0  vmovaps xmm13, [rsp+0xC0]
0000705c0addb2c9  vmovaps xmm14, [rsp+0xD0]
0000705c0addb2d2  vmovaps xmm15, [rsp+0xE0]
0000705c0addb2db  add rsp, 0xF0
0000705c0addb2e2  pop r11
0000705c0addb2e4  pop r10
0000705c0addb2e6  pop r9
0000705c0addb2e8  pop r8
0000705c0addb2ea  pop rsi
0000705c0addb2eb  pop rdi
0000705c0addb2ec  pop rdx
0000705c0addb2ed  pop rcx
0000705c0addb2ee  pop rax
0000705c0addb2ef  add rsp, 0x08
0000705c0addb2f3  jmp 0x0000705C0ADD90E6
0000705c0addb2f8  sub rsp, 0x08
0000705c0addb2fc  push rax
0000705c0addb2fd  push rcx
0000705c0addb2fe  push rdx
0000705c0addb2ff  push rdi
0000705c0addb300  push rsi
0000705c0addb301  push r8
0000705c0addb303  push r9
0000705c0addb305  push r10
0000705c0addb307  push r11
0000705c0addb309  sub rsp, 0xF0
0000705c0addb310  vmovaps [rsp], xmm0
0000705c0addb315  vmovaps [rsp+0x10], xmm1
0000705c0addb31b  vmovaps [rsp+0x20], xmm2
0000705c0addb321  vmovaps [rsp+0x30], xmm3
0000705c0addb327  vmovaps [rsp+0x40], xmm5
0000705c0addb32d  vmovaps [rsp+0x50], xmm6
0000705c0addb333  vmovaps [rsp+0x60], xmm7
0000705c0addb339  vmovaps [rsp+0x70], xmm8
0000705c0addb33f  vmovaps [rsp+0x80], xmm9
0000705c0addb348  vmovaps [rsp+0x90], xmm10
0000705c0addb351  vmovaps [rsp+0xA0], xmm11
0000705c0addb35a  vmovaps [rsp+0xB0], xmm12
0000705c0addb363  vmovaps [rsp+0xC0], xmm13
0000705c0addb36c  vmovaps [rsp+0xD0], xmm14
0000705c0addb375  vmovaps [rsp+0xE0], xmm15
0000705c0addb37e  sub rsp, 0x30
0000705c0addb382  movaps [rsp], xmm4
0000705c0addb386  movaps [rsp+0x10], xmm3
0000705c0addb38b  movaps [rsp+0x20], xmm5
0000705c0addb390  lea rdi, [rsp]
0000705c0addb394  mov esi, 0x00
0000705c0addb399  mov rax, 0x5969C28C4530
0000705c0addb3a3  call rax
0000705c0addb3a5  movaps xmm4, [rsp]
0000705c0addb3a9  add rsp, 0x30
0000705c0addb3ad  vmovaps xmm0, [rsp]
0000705c0addb3b2  vmovaps xmm1, [rsp+0x10]
0000705c0addb3b8  vmovaps xmm2, [rsp+0x20]
0000705c0addb3be  vmovaps xmm3, [rsp+0x30]
0000705c0addb3c4  vmovaps xmm5, [rsp+0x40]
0000705c0addb3ca  vmovaps xmm6, [rsp+0x50]
0000705c0addb3d0  vmovaps xmm7, [rsp+0x60]
0000705c0addb3d6  vmovaps xmm8, [rsp+0x70]
0000705c0addb3dc  vmovaps xmm9, [rsp+0x80]
0000705c0addb3e5  vmovaps xmm10, [rsp+0x90]
0000705c0addb3ee  vmovaps xmm11, [rsp+0xA0]
0000705c0addb3f7  vmovaps xmm12, [rsp+0xB0]
0000705c0addb400  vmovaps xmm13, [rsp+0xC0]
0000705c0addb409  vmovaps xmm14, [rsp+0xD0]
0000705c0addb412  vmovaps xmm15, [rsp+0xE0]
0000705c0addb41b  add rsp, 0xF0
0000705c0addb422  pop r11
0000705c0addb424  pop r10
0000705c0addb426  pop r9
0000705c0addb428  pop r8
0000705c0addb42a  pop rsi
0000705c0addb42b  pop rdi
0000705c0addb42c  pop rdx
0000705c0addb42d  pop rcx
0000705c0addb42e  pop rax
0000705c0addb42f  add rsp, 0x08
0000705c0addb433  jmp 0x0000705C0ADD9134
0000705c0addb438  call 0x0000705C0ACD64F0
0000705c0addb43d  jmp 0x0000705C0ADD9141
0000705c0addb442  sub rsp, 0x08
0000705c0addb446  push rax
0000705c0addb447  push rcx
0000705c0addb448  push rdx
0000705c0addb449  push rdi
0000705c0addb44a  push rsi
0000705c0addb44b  push r8
0000705c0addb44d  push r9
0000705c0addb44f  push r10
0000705c0addb451  push r11
0000705c0addb453  sub rsp, 0xF0
0000705c0addb45a  vmovaps [rsp], xmm0
0000705c0addb45f  vmovaps [rsp+0x10], xmm1
0000705c0addb465  vmovaps [rsp+0x20], xmm2
0000705c0addb46b  vmovaps [rsp+0x30], xmm3
0000705c0addb471  vmovaps [rsp+0x40], xmm4
0000705c0addb477  vmovaps [rsp+0x50], xmm6
0000705c0addb47d  vmovaps [rsp+0x60], xmm7
0000705c0addb483  vmovaps [rsp+0x70], xmm8
0000705c0addb489  vmovaps [rsp+0x80], xmm9
0000705c0addb492  vmovaps [rsp+0x90], xmm10
0000705c0addb49b  vmovaps [rsp+0xA0], xmm11
0000705c0addb4a4  vmovaps [rsp+0xB0], xmm12
0000705c0addb4ad  vmovaps [rsp+0xC0], xmm13
0000705c0addb4b6  vmovaps [rsp+0xD0], xmm14
0000705c0addb4bf  vmovaps [rsp+0xE0], xmm15
0000705c0addb4c8  sub rsp, 0x30
0000705c0addb4cc  movaps [rsp], xmm5
0000705c0addb4d0  movaps [rsp+0x10], xmm6
0000705c0addb4d5  movaps [rsp+0x20], xmm3
0000705c0addb4da  lea rdi, [rsp]
0000705c0addb4de  mov esi, 0x00
0000705c0addb4e3  mov rax, 0x5969C28C4530
0000705c0addb4ed  call rax
0000705c0addb4ef  movaps xmm5, [rsp]
0000705c0addb4f3  add rsp, 0x30
0000705c0addb4f7  vmovaps xmm0, [rsp]
0000705c0addb4fc  vmovaps xmm1, [rsp+0x10]
0000705c0addb502  vmovaps xmm2, [rsp+0x20]
0000705c0addb508  vmovaps xmm3, [rsp+0x30]
0000705c0addb50e  vmovaps xmm4, [rsp+0x40]
0000705c0addb514  vmovaps xmm6, [rsp+0x50]
0000705c0addb51a  vmovaps xmm7, [rsp+0x60]
0000705c0addb520  vmovaps xmm8, [rsp+0x70]
0000705c0addb526  vmovaps xmm9, [rsp+0x80]
0000705c0addb52f  vmovaps xmm10, [rsp+0x90]
0000705c0addb538  vmovaps xmm11, [rsp+0xA0]
0000705c0addb541  vmovaps xmm12, [rsp+0xB0]
0000705c0addb54a  vmovaps xmm13, [rsp+0xC0]
0000705c0addb553  vmovaps xmm14, [rsp+0xD0]
0000705c0addb55c  vmovaps xmm15, [rsp+0xE0]
0000705c0addb565  add rsp, 0xF0
0000705c0addb56c  pop r11
0000705c0addb56e  pop r10
0000705c0addb570  pop r9
0000705c0addb572  pop r8
0000705c0addb574  pop rsi
0000705c0addb575  pop rdi
0000705c0addb576  pop rdx
0000705c0addb577  pop rcx
0000705c0addb578  pop rax
0000705c0addb579  add rsp, 0x08
0000705c0addb57d  jmp 0x0000705C0ADD9167
0000705c0addb582  sub rsp, 0x08
0000705c0addb586  push rax
0000705c0addb587  push rcx
0000705c0addb588  push rdx
0000705c0addb589  push rdi
0000705c0addb58a  push rsi
0000705c0addb58b  push r8
0000705c0addb58d  push r9
0000705c0addb58f  push r10
0000705c0addb591  push r11
0000705c0addb593  sub rsp, 0xF0
0000705c0addb59a  vmovaps [rsp], xmm0
0000705c0addb59f  vmovaps [rsp+0x10], xmm1
0000705c0addb5a5  vmovaps [rsp+0x20], xmm2
0000705c0addb5ab  vmovaps [rsp+0x30], xmm3
0000705c0addb5b1  vmovaps [rsp+0x40], xmm4
0000705c0addb5b7  vmovaps [rsp+0x50], xmm5
0000705c0addb5bd  vmovaps [rsp+0x60], xmm7
0000705c0addb5c3  vmovaps [rsp+0x70], xmm8
0000705c0addb5c9  vmovaps [rsp+0x80], xmm9
0000705c0addb5d2  vmovaps [rsp+0x90], xmm10
0000705c0addb5db  vmovaps [rsp+0xA0], xmm11
0000705c0addb5e4  vmovaps [rsp+0xB0], xmm12
0000705c0addb5ed  vmovaps [rsp+0xC0], xmm13
0000705c0addb5f6  vmovaps [rsp+0xD0], xmm14
0000705c0addb5ff  vmovaps [rsp+0xE0], xmm15
0000705c0addb608  sub rsp, 0x30
0000705c0addb60c  movaps [rsp], xmm6
0000705c0addb610  movaps [rsp+0x10], xmm9
0000705c0addb616  movaps [rsp+0x20], xmm1
0000705c0addb61b  lea rdi, [rsp]
0000705c0addb61f  mov esi, 0x00
0000705c0addb624  mov rax, 0x5969C28C4530
0000705c0addb62e  call rax
0000705c0addb630  movaps xmm6, [rsp]
0000705c0addb634  add rsp, 0x30
0000705c0addb638  vmovaps xmm0, [rsp]
0000705c0addb63d  vmovaps xmm1, [rsp+0x10]
0000705c0addb643  vmovaps xmm2, [rsp+0x20]
0000705c0addb649  vmovaps xmm3, [rsp+0x30]
0000705c0addb64f  vmovaps xmm4, [rsp+0x40]
0000705c0addb655  vmovaps xmm5, [rsp+0x50]
0000705c0addb65b  vmovaps xmm7, [rsp+0x60]
0000705c0addb661  vmovaps xmm8, [rsp+0x70]
0000705c0addb667  vmovaps xmm9, [rsp+0x80]
0000705c0addb670  vmovaps xmm10, [rsp+0x90]
0000705c0addb679  vmovaps xmm11, [rsp+0xA0]
0000705c0addb682  vmovaps xmm12, [rsp+0xB0]
0000705c0addb68b  vmovaps xmm13, [rsp+0xC0]
0000705c0addb694  vmovaps xmm14, [rsp+0xD0]
0000705c0addb69d  vmovaps xmm15, [rsp+0xE0]
0000705c0addb6a6  add rsp, 0xF0
0000705c0addb6ad  pop r11
0000705c0addb6af  pop r10
0000705c0addb6b1  pop r9
0000705c0addb6b3  pop r8
0000705c0addb6b5  pop rsi
0000705c0addb6b6  pop rdi
0000705c0addb6b7  pop rdx
0000705c0addb6b8  pop rcx
0000705c0addb6b9  pop rax
0000705c0addb6ba  add rsp, 0x08
0000705c0addb6be  jmp 0x0000705C0ADD918B
0000705c0addb6c3  sub rsp, 0x08
0000705c0addb6c7  push rax
0000705c0addb6c8  push rcx
0000705c0addb6c9  push rdx
0000705c0addb6ca  push rdi
0000705c0addb6cb  push rsi
0000705c0addb6cc  push r8
0000705c0addb6ce  push r9
0000705c0addb6d0  push r10
0000705c0addb6d2  push r11
0000705c0addb6d4  sub rsp, 0xF0
0000705c0addb6db  vmovaps [rsp], xmm0
0000705c0addb6e0  vmovaps [rsp+0x10], xmm1
0000705c0addb6e6  vmovaps [rsp+0x20], xmm2
0000705c0addb6ec  vmovaps [rsp+0x30], xmm3
0000705c0addb6f2  vmovaps [rsp+0x40], xmm4
0000705c0addb6f8  vmovaps [rsp+0x50], xmm5
0000705c0addb6fe  vmovaps [rsp+0x60], xmm6
0000705c0addb704  vmovaps [rsp+0x70], xmm7
0000705c0addb70a  vmovaps [rsp+0x80], xmm8
0000705c0addb713  vmovaps [rsp+0x90], xmm10
0000705c0addb71c  vmovaps [rsp+0xA0], xmm11
0000705c0addb725  vmovaps [rsp+0xB0], xmm12
0000705c0addb72e  vmovaps [rsp+0xC0], xmm13
0000705c0addb737  vmovaps [rsp+0xD0], xmm14
0000705c0addb740  vmovaps [rsp+0xE0], xmm15
0000705c0addb749  sub rsp, 0x30
0000705c0addb74d  movaps [rsp], xmm9
0000705c0addb752  movaps [rsp+0x10], xmm3
0000705c0addb757  movaps [rsp+0x20], xmm1
0000705c0addb75c  lea rdi, [rsp]
0000705c0addb760  mov esi, 0x00
0000705c0addb765  mov rax, 0x5969C28C4530
0000705c0addb76f  call rax
0000705c0addb771  movaps xmm9, [rsp]
0000705c0addb776  add rsp, 0x30
0000705c0addb77a  vmovaps xmm0, [rsp]
0000705c0addb77f  vmovaps xmm1, [rsp+0x10]
0000705c0addb785  vmovaps xmm2, [rsp+0x20]
0000705c0addb78b  vmovaps xmm3, [rsp+0x30]
0000705c0addb791  vmovaps xmm4, [rsp+0x40]
0000705c0addb797  vmovaps xmm5, [rsp+0x50]
0000705c0addb79d  vmovaps xmm6, [rsp+0x60]
0000705c0addb7a3  vmovaps xmm7, [rsp+0x70]
0000705c0addb7a9  vmovaps xmm8, [rsp+0x80]
0000705c0addb7b2  vmovaps xmm10, [rsp+0x90]
0000705c0addb7bb  vmovaps xmm11, [rsp+0xA0]
0000705c0addb7c4  vmovaps xmm12, [rsp+0xB0]
0000705c0addb7cd  vmovaps xmm13, [rsp+0xC0]
0000705c0addb7d6  vmovaps xmm14, [rsp+0xD0]
0000705c0addb7df  vmovaps xmm15, [rsp+0xE0]
0000705c0addb7e8  add rsp, 0xF0
0000705c0addb7ef  pop r11
0000705c0addb7f1  pop r10
0000705c0addb7f3  pop r9
0000705c0addb7f5  pop r8
0000705c0addb7f7  pop rsi
0000705c0addb7f8  pop rdi
0000705c0addb7f9  pop rdx
0000705c0addb7fa  pop rcx
0000705c0addb7fb  pop rax
0000705c0addb7fc  add rsp, 0x08
0000705c0addb800  jmp 0x0000705C0ADD91D7
0000705c0addb805  call 0x0000705C0ACD64F0
0000705c0addb80a  jmp 0x0000705C0ADD91E4
0000705c0addb80f  sub rsp, 0x08
0000705c0addb813  push rax
0000705c0addb814  push rcx
0000705c0addb815  push rdx
0000705c0addb816  push rdi
0000705c0addb817  push rsi
0000705c0addb818  push r8
0000705c0addb81a  push r9
0000705c0addb81c  push r10
0000705c0addb81e  push r11
0000705c0addb820  sub rsp, 0xF0
0000705c0addb827  vmovaps [rsp], xmm0
0000705c0addb82c  vmovaps [rsp+0x10], xmm1
0000705c0addb832  vmovaps [rsp+0x20], xmm2
0000705c0addb838  vmovaps [rsp+0x30], xmm3
0000705c0addb83e  vmovaps [rsp+0x40], xmm4
0000705c0addb844  vmovaps [rsp+0x50], xmm5
0000705c0addb84a  vmovaps [rsp+0x60], xmm6
0000705c0addb850  vmovaps [rsp+0x70], xmm7
0000705c0addb856  vmovaps [rsp+0x80], xmm8
0000705c0addb85f  vmovaps [rsp+0x90], xmm9
0000705c0addb868  vmovaps [rsp+0xA0], xmm10
0000705c0addb871  vmovaps [rsp+0xB0], xmm11
0000705c0addb87a  vmovaps [rsp+0xC0], xmm12
0000705c0addb883  vmovaps [rsp+0xD0], xmm13
0000705c0addb88c  vmovaps [rsp+0xE0], xmm14
0000705c0addb895  sub rsp, 0x30
0000705c0addb899  movaps [rsp], xmm15
0000705c0addb89e  movaps [rsp+0x10], xmm3
0000705c0addb8a3  movaps [rsp+0x20], xmm7
0000705c0addb8a8  lea rdi, [rsp]
0000705c0addb8ac  mov esi, 0x00
0000705c0addb8b1  mov rax, 0x5969C28C4530
0000705c0addb8bb  call rax
0000705c0addb8bd  movaps xmm15, [rsp]
0000705c0addb8c2  add rsp, 0x30
0000705c0addb8c6  vmovaps xmm0, [rsp]
0000705c0addb8cb  vmovaps xmm1, [rsp+0x10]
0000705c0addb8d1  vmovaps xmm2, [rsp+0x20]
0000705c0addb8d7  vmovaps xmm3, [rsp+0x30]
0000705c0addb8dd  vmovaps xmm4, [rsp+0x40]
0000705c0addb8e3  vmovaps xmm5, [rsp+0x50]
0000705c0addb8e9  vmovaps xmm6, [rsp+0x60]
0000705c0addb8ef  vmovaps xmm7, [rsp+0x70]
0000705c0addb8f5  vmovaps xmm8, [rsp+0x80]
0000705c0addb8fe  vmovaps xmm9, [rsp+0x90]
0000705c0addb907  vmovaps xmm10, [rsp+0xA0]
0000705c0addb910  vmovaps xmm11, [rsp+0xB0]
0000705c0addb919  vmovaps xmm12, [rsp+0xC0]
0000705c0addb922  vmovaps xmm13, [rsp+0xD0]
0000705c0addb92b  vmovaps xmm14, [rsp+0xE0]
0000705c0addb934  add rsp, 0xF0
0000705c0addb93b  pop r11
0000705c0addb93d  pop r10
0000705c0addb93f  pop r9
0000705c0addb941  pop r8
0000705c0addb943  pop rsi
0000705c0addb944  pop rdi
0000705c0addb945  pop rdx
0000705c0addb946  pop rcx
0000705c0addb947  pop rax
0000705c0addb948  add rsp, 0x08
0000705c0addb94c  jmp 0x0000705C0ADD9210
0000705c0addb951  sub rsp, 0x08
0000705c0addb955  push rax
0000705c0addb956  push rcx
0000705c0addb957  push rdx
0000705c0addb958  push rdi
0000705c0addb959  push rsi
0000705c0addb95a  push r8
0000705c0addb95c  push r9
0000705c0addb95e  push r10
0000705c0addb960  push r11
0000705c0addb962  sub rsp, 0xF0
0000705c0addb969  vmovaps [rsp], xmm0
0000705c0addb96e  vmovaps [rsp+0x10], xmm1
0000705c0addb974  vmovaps [rsp+0x20], xmm2
0000705c0addb97a  vmovaps [rsp+0x30], xmm4
0000705c0addb980  vmovaps [rsp+0x40], xmm5
0000705c0addb986  vmovaps [rsp+0x50], xmm6
0000705c0addb98c  vmovaps [rsp+0x60], xmm7
0000705c0addb992  vmovaps [rsp+0x70], xmm8
0000705c0addb998  vmovaps [rsp+0x80], xmm9
0000705c0addb9a1  vmovaps [rsp+0x90], xmm10
0000705c0addb9aa  vmovaps [rsp+0xA0], xmm11
0000705c0addb9b3  vmovaps [rsp+0xB0], xmm12
0000705c0addb9bc  vmovaps [rsp+0xC0], xmm13
0000705c0addb9c5  vmovaps [rsp+0xD0], xmm14
0000705c0addb9ce  vmovaps [rsp+0xE0], xmm15
0000705c0addb9d7  sub rsp, 0x30
0000705c0addb9db  movaps [rsp], xmm3
0000705c0addb9df  movaps [rsp+0x10], xmm1
0000705c0addb9e4  movaps [rsp+0x20], xmm15
0000705c0addb9ea  lea rdi, [rsp]
0000705c0addb9ee  mov esi, 0x00
0000705c0addb9f3  mov rax, 0x5969C28C4530
0000705c0addb9fd  call rax
0000705c0addb9ff  movaps xmm3, [rsp]
0000705c0addba03  add rsp, 0x30
0000705c0addba07  vmovaps xmm0, [rsp]
0000705c0addba0c  vmovaps xmm1, [rsp+0x10]
0000705c0addba12  vmovaps xmm2, [rsp+0x20]
0000705c0addba18  vmovaps xmm4, [rsp+0x30]
0000705c0addba1e  vmovaps xmm5, [rsp+0x40]
0000705c0addba24  vmovaps xmm6, [rsp+0x50]
0000705c0addba2a  vmovaps xmm7, [rsp+0x60]
0000705c0addba30  vmovaps xmm8, [rsp+0x70]
0000705c0addba36  vmovaps xmm9, [rsp+0x80]
0000705c0addba3f  vmovaps xmm10, [rsp+0x90]
0000705c0addba48  vmovaps xmm11, [rsp+0xA0]
0000705c0addba51  vmovaps xmm12, [rsp+0xB0]
0000705c0addba5a  vmovaps xmm13, [rsp+0xC0]
0000705c0addba63  vmovaps xmm14, [rsp+0xD0]
0000705c0addba6c  vmovaps xmm15, [rsp+0xE0]
0000705c0addba75  add rsp, 0xF0
0000705c0addba7c  pop r11
0000705c0addba7e  pop r10
0000705c0addba80  pop r9
0000705c0addba82  pop r8
0000705c0addba84  pop rsi
0000705c0addba85  pop rdi
0000705c0addba86  pop rdx
0000705c0addba87  pop rcx
0000705c0addba88  pop rax
0000705c0addba89  add rsp, 0x08
0000705c0addba8d  jmp 0x0000705C0ADD929F
0000705c0addba92  call 0x0000705C0ACD64F0
0000705c0addba97  jmp 0x0000705C0ADD92A9
0000705c0addba9c  sub rsp, 0x08
0000705c0addbaa0  push rax
0000705c0addbaa1  push rcx
0000705c0addbaa2  push rdx
0000705c0addbaa3  push rdi
0000705c0addbaa4  push rsi
0000705c0addbaa5  push r8
0000705c0addbaa7  push r9
0000705c0addbaa9  push r10
0000705c0addbaab  push r11
0000705c0addbaad  sub rsp, 0xF0
0000705c0addbab4  vmovaps [rsp], xmm0
0000705c0addbab9  vmovaps [rsp+0x10], xmm1
0000705c0addbabf  vmovaps [rsp+0x20], xmm2
0000705c0addbac5  vmovaps [rsp+0x30], xmm3
0000705c0addbacb  vmovaps [rsp+0x40], xmm4
0000705c0addbad1  vmovaps [rsp+0x50], xmm5
0000705c0addbad7  vmovaps [rsp+0x60], xmm6
0000705c0addbadd  vmovaps [rsp+0x70], xmm7
0000705c0addbae3  vmovaps [rsp+0x80], xmm8
0000705c0addbaec  vmovaps [rsp+0x90], xmm9
0000705c0addbaf5  vmovaps [rsp+0xA0], xmm10
0000705c0addbafe  vmovaps [rsp+0xB0], xmm11
0000705c0addbb07  vmovaps [rsp+0xC0], xmm12
0000705c0addbb10  vmovaps [rsp+0xD0], xmm13
0000705c0addbb19  vmovaps [rsp+0xE0], xmm14
0000705c0addbb22  sub rsp, 0x30
0000705c0addbb26  movaps [rsp], xmm15
0000705c0addbb2b  movaps [rsp+0x10], xmm14
0000705c0addbb31  movaps [rsp+0x20], xmm4
0000705c0addbb36  lea rdi, [rsp]
0000705c0addbb3a  mov esi, 0x00
0000705c0addbb3f  mov rax, 0x5969C28C4530
0000705c0addbb49  call rax
0000705c0addbb4b  movaps xmm15, [rsp]
0000705c0addbb50  add rsp, 0x30
0000705c0addbb54  vmovaps xmm0, [rsp]
0000705c0addbb59  vmovaps xmm1, [rsp+0x10]
0000705c0addbb5f  vmovaps xmm2, [rsp+0x20]
0000705c0addbb65  vmovaps xmm3, [rsp+0x30]
0000705c0addbb6b  vmovaps xmm4, [rsp+0x40]
0000705c0addbb71  vmovaps xmm5, [rsp+0x50]
0000705c0addbb77  vmovaps xmm6, [rsp+0x60]
0000705c0addbb7d  vmovaps xmm7, [rsp+0x70]
0000705c0addbb83  vmovaps xmm8, [rsp+0x80]
0000705c0addbb8c  vmovaps xmm9, [rsp+0x90]
0000705c0addbb95  vmovaps xmm10, [rsp+0xA0]
0000705c0addbb9e  vmovaps xmm11, [rsp+0xB0]
0000705c0addbba7  vmovaps xmm12, [rsp+0xC0]
0000705c0addbbb0  vmovaps xmm13, [rsp+0xD0]
0000705c0addbbb9  vmovaps xmm14, [rsp+0xE0]
0000705c0addbbc2  add rsp, 0xF0
0000705c0addbbc9  pop r11
0000705c0addbbcb  pop r10
0000705c0addbbcd  pop r9
0000705c0addbbcf  pop r8
0000705c0addbbd1  pop rsi
0000705c0addbbd2  pop rdi
0000705c0addbbd3  pop rdx
0000705c0addbbd4  pop rcx
0000705c0addbbd5  pop rax
0000705c0addbbd6  add rsp, 0x08
0000705c0addbbda  jmp 0x0000705C0ADD92D7
0000705c0addbbdf  sub rsp, 0x08
0000705c0addbbe3  push rax
0000705c0addbbe4  push rcx
0000705c0addbbe5  push rdx
0000705c0addbbe6  push rdi
0000705c0addbbe7  push rsi
0000705c0addbbe8  push r8
0000705c0addbbea  push r9
0000705c0addbbec  push r10
0000705c0addbbee  push r11
0000705c0addbbf0  sub rsp, 0xF0
0000705c0addbbf7  vmovaps [rsp], xmm0
0000705c0addbbfc  vmovaps [rsp+0x10], xmm1
0000705c0addbc02  vmovaps [rsp+0x20], xmm2
0000705c0addbc08  vmovaps [rsp+0x30], xmm3
0000705c0addbc0e  vmovaps [rsp+0x40], xmm4
0000705c0addbc14  vmovaps [rsp+0x50], xmm5
0000705c0addbc1a  vmovaps [rsp+0x60], xmm6
0000705c0addbc20  vmovaps [rsp+0x70], xmm7
0000705c0addbc26  vmovaps [rsp+0x80], xmm8
0000705c0addbc2f  vmovaps [rsp+0x90], xmm9
0000705c0addbc38  vmovaps [rsp+0xA0], xmm10
0000705c0addbc41  vmovaps [rsp+0xB0], xmm11
0000705c0addbc4a  vmovaps [rsp+0xC0], xmm12
0000705c0addbc53  vmovaps [rsp+0xD0], xmm13
0000705c0addbc5c  vmovaps [rsp+0xE0], xmm15
0000705c0addbc65  sub rsp, 0x30
0000705c0addbc69  movaps [rsp], xmm14
0000705c0addbc6e  movaps [rsp+0x10], xmm2
0000705c0addbc73  movaps [rsp+0x20], xmm1
0000705c0addbc78  lea rdi, [rsp]
0000705c0addbc7c  mov esi, 0x00
0000705c0addbc81  mov rax, 0x5969C28C4530
0000705c0addbc8b  call rax
0000705c0addbc8d  movaps xmm14, [rsp]
0000705c0addbc92  add rsp, 0x30
0000705c0addbc96  vmovaps xmm0, [rsp]
0000705c0addbc9b  vmovaps xmm1, [rsp+0x10]
0000705c0addbca1  vmovaps xmm2, [rsp+0x20]
0000705c0addbca7  vmovaps xmm3, [rsp+0x30]
0000705c0addbcad  vmovaps xmm4, [rsp+0x40]
0000705c0addbcb3  vmovaps xmm5, [rsp+0x50]
0000705c0addbcb9  vmovaps xmm6, [rsp+0x60]
0000705c0addbcbf  vmovaps xmm7, [rsp+0x70]
0000705c0addbcc5  vmovaps xmm8, [rsp+0x80]
0000705c0addbcce  vmovaps xmm9, [rsp+0x90]
0000705c0addbcd7  vmovaps xmm10, [rsp+0xA0]
0000705c0addbce0  vmovaps xmm11, [rsp+0xB0]
0000705c0addbce9  vmovaps xmm12, [rsp+0xC0]
0000705c0addbcf2  vmovaps xmm13, [rsp+0xD0]
0000705c0addbcfb  vmovaps xmm15, [rsp+0xE0]
0000705c0addbd04  add rsp, 0xF0
0000705c0addbd0b  pop r11
0000705c0addbd0d  pop r10
0000705c0addbd0f  pop r9
0000705c0addbd11  pop r8
0000705c0addbd13  pop rsi
0000705c0addbd14  pop rdi
0000705c0addbd15  pop rdx
0000705c0addbd16  pop rcx
0000705c0addbd17  pop rax
0000705c0addbd18  add rsp, 0x08
0000705c0addbd1c  jmp 0x0000705C0ADD92FD
0000705c0addbd21  sub rsp, 0x08
0000705c0addbd25  push rax
0000705c0addbd26  push rcx
0000705c0addbd27  push rdx
0000705c0addbd28  push rdi
0000705c0addbd29  push rsi
0000705c0addbd2a  push r8
0000705c0addbd2c  push r9
0000705c0addbd2e  push r10
0000705c0addbd30  push r11
0000705c0addbd32  sub rsp, 0xF0
0000705c0addbd39  vmovaps [rsp], xmm0
0000705c0addbd3e  vmovaps [rsp+0x10], xmm2
0000705c0addbd44  vmovaps [rsp+0x20], xmm3
0000705c0addbd4a  vmovaps [rsp+0x30], xmm4
0000705c0addbd50  vmovaps [rsp+0x40], xmm5
0000705c0addbd56  vmovaps [rsp+0x50], xmm6
0000705c0addbd5c  vmovaps [rsp+0x60], xmm7
0000705c0addbd62  vmovaps [rsp+0x70], xmm8
0000705c0addbd68  vmovaps [rsp+0x80], xmm9
0000705c0addbd71  vmovaps [rsp+0x90], xmm10
0000705c0addbd7a  vmovaps [rsp+0xA0], xmm11
0000705c0addbd83  vmovaps [rsp+0xB0], xmm12
0000705c0addbd8c  vmovaps [rsp+0xC0], xmm13
0000705c0addbd95  vmovaps [rsp+0xD0], xmm14
0000705c0addbd9e  vmovaps [rsp+0xE0], xmm15
0000705c0addbda7  sub rsp, 0x30
0000705c0addbdab  movaps [rsp], xmm1
0000705c0addbdaf  movaps [rsp+0x10], xmm4
0000705c0addbdb4  movaps [rsp+0x20], xmm9
0000705c0addbdba  lea rdi, [rsp]
0000705c0addbdbe  mov esi, 0x00
0000705c0addbdc3  mov rax, 0x5969C28C4530
0000705c0addbdcd  call rax
0000705c0addbdcf  movaps xmm1, [rsp]
0000705c0addbdd3  add rsp, 0x30
0000705c0addbdd7  vmovaps xmm0, [rsp]
0000705c0addbddc  vmovaps xmm2, [rsp+0x10]
0000705c0addbde2  vmovaps xmm3, [rsp+0x20]
0000705c0addbde8  vmovaps xmm4, [rsp+0x30]
0000705c0addbdee  vmovaps xmm5, [rsp+0x40]
0000705c0addbdf4  vmovaps xmm6, [rsp+0x50]
0000705c0addbdfa  vmovaps xmm7, [rsp+0x60]
0000705c0addbe00  vmovaps xmm8, [rsp+0x70]
0000705c0addbe06  vmovaps xmm9, [rsp+0x80]
0000705c0addbe0f  vmovaps xmm10, [rsp+0x90]
0000705c0addbe18  vmovaps xmm11, [rsp+0xA0]
0000705c0addbe21  vmovaps xmm12, [rsp+0xB0]
0000705c0addbe2a  vmovaps xmm13, [rsp+0xC0]
0000705c0addbe33  vmovaps xmm14, [rsp+0xD0]
0000705c0addbe3c  vmovaps xmm15, [rsp+0xE0]
0000705c0addbe45  add rsp, 0xF0
0000705c0addbe4c  pop r11
0000705c0addbe4e  pop r10
0000705c0addbe50  pop r9
0000705c0addbe52  pop r8
0000705c0addbe54  pop rsi
0000705c0addbe55  pop rdi
0000705c0addbe56  pop rdx
0000705c0addbe57  pop rcx
0000705c0addbe58  pop rax
0000705c0addbe59  add rsp, 0x08
0000705c0addbe5d  jmp 0x0000705C0ADD931B
0000705c0addbe62  sub rsp, 0x08
0000705c0addbe66  push rax
0000705c0addbe67  push rcx
0000705c0addbe68  push rdx
0000705c0addbe69  push rdi
0000705c0addbe6a  push rsi
0000705c0addbe6b  push r8
0000705c0addbe6d  push r9
0000705c0addbe6f  push r10
0000705c0addbe71  push r11
0000705c0addbe73  sub rsp, 0xF0
0000705c0addbe7a  vmovaps [rsp], xmm0
0000705c0addbe7f  vmovaps [rsp+0x10], xmm1
0000705c0addbe85  vmovaps [rsp+0x20], xmm2
0000705c0addbe8b  vmovaps [rsp+0x30], xmm3
0000705c0addbe91  vmovaps [rsp+0x40], xmm5
0000705c0addbe97  vmovaps [rsp+0x50], xmm6
0000705c0addbe9d  vmovaps [rsp+0x60], xmm7
0000705c0addbea3  vmovaps [rsp+0x70], xmm8
0000705c0addbea9  vmovaps [rsp+0x80], xmm9
0000705c0addbeb2  vmovaps [rsp+0x90], xmm10
0000705c0addbebb  vmovaps [rsp+0xA0], xmm11
0000705c0addbec4  vmovaps [rsp+0xB0], xmm12
0000705c0addbecd  vmovaps [rsp+0xC0], xmm13
0000705c0addbed6  vmovaps [rsp+0xD0], xmm14
0000705c0addbedf  vmovaps [rsp+0xE0], xmm15
0000705c0addbee8  sub rsp, 0x30
0000705c0addbeec  movaps [rsp], xmm4
0000705c0addbef0  movaps [rsp+0x10], xmm2
0000705c0addbef5  movaps [rsp+0x20], xmm9
0000705c0addbefb  lea rdi, [rsp]
0000705c0addbeff  mov esi, 0x00
0000705c0addbf04  mov rax, 0x5969C28C4530
0000705c0addbf0e  call rax
0000705c0addbf10  movaps xmm4, [rsp]
0000705c0addbf14  add rsp, 0x30
0000705c0addbf18  vmovaps xmm0, [rsp]
0000705c0addbf1d  vmovaps xmm1, [rsp+0x10]
0000705c0addbf23  vmovaps xmm2, [rsp+0x20]
0000705c0addbf29  vmovaps xmm3, [rsp+0x30]
0000705c0addbf2f  vmovaps xmm5, [rsp+0x40]
0000705c0addbf35  vmovaps xmm6, [rsp+0x50]
0000705c0addbf3b  vmovaps xmm7, [rsp+0x60]
0000705c0addbf41  vmovaps xmm8, [rsp+0x70]
0000705c0addbf47  vmovaps xmm9, [rsp+0x80]
0000705c0addbf50  vmovaps xmm10, [rsp+0x90]
0000705c0addbf59  vmovaps xmm11, [rsp+0xA0]
0000705c0addbf62  vmovaps xmm12, [rsp+0xB0]
0000705c0addbf6b  vmovaps xmm13, [rsp+0xC0]
0000705c0addbf74  vmovaps xmm14, [rsp+0xD0]
0000705c0addbf7d  vmovaps xmm15, [rsp+0xE0]
0000705c0addbf86  add rsp, 0xF0
0000705c0addbf8d  pop r11
0000705c0addbf8f  pop r10
0000705c0addbf91  pop r9
0000705c0addbf93  pop r8
0000705c0addbf95  pop rsi
0000705c0addbf96  pop rdi
0000705c0addbf97  pop rdx
0000705c0addbf98  pop rcx
0000705c0addbf99  pop rax
0000705c0addbf9a  add rsp, 0x08
0000705c0addbf9e  jmp 0x0000705C0ADD934B
0000705c0addbfa3  sub rsp, 0x08
0000705c0addbfa7  push rax
0000705c0addbfa8  push rcx
0000705c0addbfa9  push rdx
0000705c0addbfaa  push rdi
0000705c0addbfab  push rsi
0000705c0addbfac  push r8
0000705c0addbfae  push r9
0000705c0addbfb0  push r10
0000705c0addbfb2  push r11
0000705c0addbfb4  sub rsp, 0xF0
0000705c0addbfbb  vmovaps [rsp], xmm0
0000705c0addbfc0  vmovaps [rsp+0x10], xmm1
0000705c0addbfc6  vmovaps [rsp+0x20], xmm2
0000705c0addbfcc  vmovaps [rsp+0x30], xmm3
0000705c0addbfd2  vmovaps [rsp+0x40], xmm4
0000705c0addbfd8  vmovaps [rsp+0x50], xmm5
0000705c0addbfde  vmovaps [rsp+0x60], xmm6
0000705c0addbfe4  vmovaps [rsp+0x70], xmm7
0000705c0addbfea  vmovaps [rsp+0x80], xmm8
0000705c0addbff3  vmovaps [rsp+0x90], xmm10
0000705c0addbffc  vmovaps [rsp+0xA0], xmm11
0000705c0addc005  vmovaps [rsp+0xB0], xmm12
0000705c0addc00e  vmovaps [rsp+0xC0], xmm13
0000705c0addc017  vmovaps [rsp+0xD0], xmm14
0000705c0addc020  vmovaps [rsp+0xE0], xmm15
0000705c0addc029  sub rsp, 0x30
0000705c0addc02d  movaps [rsp], xmm9
0000705c0addc032  movaps [rsp+0x10], xmm2
0000705c0addc037  movaps [rsp+0x20], xmm1
0000705c0addc03c  lea rdi, [rsp]
0000705c0addc040  mov esi, 0x00
0000705c0addc045  mov rax, 0x5969C28C4530
0000705c0addc04f  call rax
0000705c0addc051  movaps xmm9, [rsp]
0000705c0addc056  add rsp, 0x30
0000705c0addc05a  vmovaps xmm0, [rsp]
0000705c0addc05f  vmovaps xmm1, [rsp+0x10]
0000705c0addc065  vmovaps xmm2, [rsp+0x20]
0000705c0addc06b  vmovaps xmm3, [rsp+0x30]
0000705c0addc071  vmovaps xmm4, [rsp+0x40]
0000705c0addc077  vmovaps xmm5, [rsp+0x50]
0000705c0addc07d  vmovaps xmm6, [rsp+0x60]
0000705c0addc083  vmovaps xmm7, [rsp+0x70]
0000705c0addc089  vmovaps xmm8, [rsp+0x80]
0000705c0addc092  vmovaps xmm10, [rsp+0x90]
0000705c0addc09b  vmovaps xmm11, [rsp+0xA0]
0000705c0addc0a4  vmovaps xmm12, [rsp+0xB0]
0000705c0addc0ad  vmovaps xmm13, [rsp+0xC0]
0000705c0addc0b6  vmovaps xmm14, [rsp+0xD0]
0000705c0addc0bf  vmovaps xmm15, [rsp+0xE0]
0000705c0addc0c8  add rsp, 0xF0
0000705c0addc0cf  pop r11
0000705c0addc0d1  pop r10
0000705c0addc0d3  pop r9
0000705c0addc0d5  pop r8
0000705c0addc0d7  pop rsi
0000705c0addc0d8  pop rdi
0000705c0addc0d9  pop rdx
0000705c0addc0da  pop rcx
0000705c0addc0db  pop rax
0000705c0addc0dc  add rsp, 0x08
0000705c0addc0e0  jmp 0x0000705C0ADD9381
0000705c0addc0e5  sub rsp, 0x08
0000705c0addc0e9  push rax
0000705c0addc0ea  push rcx
0000705c0addc0eb  push rdx
0000705c0addc0ec  push rdi
0000705c0addc0ed  push rsi
0000705c0addc0ee  push r8
0000705c0addc0f0  push r9
0000705c0addc0f2  push r10
0000705c0addc0f4  push r11
0000705c0addc0f6  sub rsp, 0xF0
0000705c0addc0fd  vmovaps [rsp], xmm0
0000705c0addc102  vmovaps [rsp+0x10], xmm2
0000705c0addc108  vmovaps [rsp+0x20], xmm3
0000705c0addc10e  vmovaps [rsp+0x30], xmm4
0000705c0addc114  vmovaps [rsp+0x40], xmm5
0000705c0addc11a  vmovaps [rsp+0x50], xmm6
0000705c0addc120  vmovaps [rsp+0x60], xmm7
0000705c0addc126  vmovaps [rsp+0x70], xmm8
0000705c0addc12c  vmovaps [rsp+0x80], xmm9
0000705c0addc135  vmovaps [rsp+0x90], xmm10
0000705c0addc13e  vmovaps [rsp+0xA0], xmm11
0000705c0addc147  vmovaps [rsp+0xB0], xmm12
0000705c0addc150  vmovaps [rsp+0xC0], xmm13
0000705c0addc159  vmovaps [rsp+0xD0], xmm14
0000705c0addc162  vmovaps [rsp+0xE0], xmm15
0000705c0addc16b  sub rsp, 0x30
0000705c0addc16f  movaps [rsp], xmm1
0000705c0addc173  movaps [rsp+0x10], xmm15
0000705c0addc179  movaps [rsp+0x20], xmm6
0000705c0addc17e  lea rdi, [rsp]
0000705c0addc182  mov esi, 0x00
0000705c0addc187  mov rax, 0x5969C28C4530
0000705c0addc191  call rax
0000705c0addc193  movaps xmm1, [rsp]
0000705c0addc197  add rsp, 0x30
0000705c0addc19b  vmovaps xmm0, [rsp]
0000705c0addc1a0  vmovaps xmm2, [rsp+0x10]
0000705c0addc1a6  vmovaps xmm3, [rsp+0x20]
0000705c0addc1ac  vmovaps xmm4, [rsp+0x30]
0000705c0addc1b2  vmovaps xmm5, [rsp+0x40]
0000705c0addc1b8  vmovaps xmm6, [rsp+0x50]
0000705c0addc1be  vmovaps xmm7, [rsp+0x60]
0000705c0addc1c4  vmovaps xmm8, [rsp+0x70]
0000705c0addc1ca  vmovaps xmm9, [rsp+0x80]
0000705c0addc1d3  vmovaps xmm10, [rsp+0x90]
0000705c0addc1dc  vmovaps xmm11, [rsp+0xA0]
0000705c0addc1e5  vmovaps xmm12, [rsp+0xB0]
0000705c0addc1ee  vmovaps xmm13, [rsp+0xC0]
0000705c0addc1f7  vmovaps xmm14, [rsp+0xD0]
0000705c0addc200  vmovaps xmm15, [rsp+0xE0]
0000705c0addc209  add rsp, 0xF0
0000705c0addc210  pop r11
0000705c0addc212  pop r10
0000705c0addc214  pop r9
0000705c0addc216  pop r8
0000705c0addc218  pop rsi
0000705c0addc219  pop rdi
0000705c0addc21a  pop rdx
0000705c0addc21b  pop rcx
0000705c0addc21c  pop rax
0000705c0addc21d  add rsp, 0x08
0000705c0addc221  jmp 0x0000705C0ADD93A2
0000705c0addc226  sub rsp, 0x08
0000705c0addc22a  push rax
0000705c0addc22b  push rcx
0000705c0addc22c  push rdx
0000705c0addc22d  push rdi
0000705c0addc22e  push rsi
0000705c0addc22f  push r8
0000705c0addc231  push r9
0000705c0addc233  push r10
0000705c0addc235  push r11
0000705c0addc237  sub rsp, 0xF0
0000705c0addc23e  vmovaps [rsp], xmm0
0000705c0addc243  vmovaps [rsp+0x10], xmm1
0000705c0addc249  vmovaps [rsp+0x20], xmm2
0000705c0addc24f  vmovaps [rsp+0x30], xmm3
0000705c0addc255  vmovaps [rsp+0x40], xmm4
0000705c0addc25b  vmovaps [rsp+0x50], xmm5
0000705c0addc261  vmovaps [rsp+0x60], xmm6
0000705c0addc267  vmovaps [rsp+0x70], xmm7
0000705c0addc26d  vmovaps [rsp+0x80], xmm8
0000705c0addc276  vmovaps [rsp+0x90], xmm9
0000705c0addc27f  vmovaps [rsp+0xA0], xmm10
0000705c0addc288  vmovaps [rsp+0xB0], xmm11
0000705c0addc291  vmovaps [rsp+0xC0], xmm12
0000705c0addc29a  vmovaps [rsp+0xD0], xmm13
0000705c0addc2a3  vmovaps [rsp+0xE0], xmm14
0000705c0addc2ac  sub rsp, 0x30
0000705c0addc2b0  movaps [rsp], xmm15
0000705c0addc2b5  movaps [rsp+0x10], xmm5
0000705c0addc2ba  movaps [rsp+0x20], xmm3
0000705c0addc2bf  lea rdi, [rsp]
0000705c0addc2c3  mov esi, 0x00
0000705c0addc2c8  mov rax, 0x5969C28C4530
0000705c0addc2d2  call rax
0000705c0addc2d4  movaps xmm15, [rsp]
0000705c0addc2d9  add rsp, 0x30
0000705c0addc2dd  vmovaps xmm0, [rsp]
0000705c0addc2e2  vmovaps xmm1, [rsp+0x10]
0000705c0addc2e8  vmovaps xmm2, [rsp+0x20]
0000705c0addc2ee  vmovaps xmm3, [rsp+0x30]
0000705c0addc2f4  vmovaps xmm4, [rsp+0x40]
0000705c0addc2fa  vmovaps xmm5, [rsp+0x50]
0000705c0addc300  vmovaps xmm6, [rsp+0x60]
0000705c0addc306  vmovaps xmm7, [rsp+0x70]
0000705c0addc30c  vmovaps xmm8, [rsp+0x80]
0000705c0addc315  vmovaps xmm9, [rsp+0x90]
0000705c0addc31e  vmovaps xmm10, [rsp+0xA0]
0000705c0addc327  vmovaps xmm11, [rsp+0xB0]
0000705c0addc330  vmovaps xmm12, [rsp+0xC0]
0000705c0addc339  vmovaps xmm13, [rsp+0xD0]
0000705c0addc342  vmovaps xmm14, [rsp+0xE0]
0000705c0addc34b  add rsp, 0xF0
0000705c0addc352  pop r11
0000705c0addc354  pop r10
0000705c0addc356  pop r9
0000705c0addc358  pop r8
0000705c0addc35a  pop rsi
0000705c0addc35b  pop rdi
0000705c0addc35c  pop rdx
0000705c0addc35d  pop rcx
0000705c0addc35e  pop rax
0000705c0addc35f  add rsp, 0x08
0000705c0addc363  jmp 0x0000705C0ADD93BC
0000705c0addc368  sub rsp, 0x08
0000705c0addc36c  push rax
0000705c0addc36d  push rcx
0000705c0addc36e  push rdx
0000705c0addc36f  push rdi
0000705c0addc370  push rsi
0000705c0addc371  push r8
0000705c0addc373  push r9
0000705c0addc375  push r10
0000705c0addc377  push r11
0000705c0addc379  sub rsp, 0xF0
0000705c0addc380  vmovaps [rsp], xmm0
0000705c0addc385  vmovaps [rsp+0x10], xmm1
0000705c0addc38b  vmovaps [rsp+0x20], xmm2
0000705c0addc391  vmovaps [rsp+0x30], xmm3
0000705c0addc397  vmovaps [rsp+0x40], xmm4
0000705c0addc39d  vmovaps [rsp+0x50], xmm6
0000705c0addc3a3  vmovaps [rsp+0x60], xmm7
0000705c0addc3a9  vmovaps [rsp+0x70], xmm8
0000705c0addc3af  vmovaps [rsp+0x80], xmm9
0000705c0addc3b8  vmovaps [rsp+0x90], xmm10
0000705c0addc3c1  vmovaps [rsp+0xA0], xmm11
0000705c0addc3ca  vmovaps [rsp+0xB0], xmm12
0000705c0addc3d3  vmovaps [rsp+0xC0], xmm13
0000705c0addc3dc  vmovaps [rsp+0xD0], xmm14
0000705c0addc3e5  vmovaps [rsp+0xE0], xmm15
0000705c0addc3ee  sub rsp, 0x30
0000705c0addc3f2  movaps [rsp], xmm5
0000705c0addc3f6  movaps [rsp+0x10], xmm8
0000705c0addc3fc  movaps [rsp+0x20], xmm6
0000705c0addc401  lea rdi, [rsp]
0000705c0addc405  mov esi, 0x00
0000705c0addc40a  mov rax, 0x5969C28C4530
0000705c0addc414  call rax
0000705c0addc416  movaps xmm5, [rsp]
0000705c0addc41a  add rsp, 0x30
0000705c0addc41e  vmovaps xmm0, [rsp]
0000705c0addc423  vmovaps xmm1, [rsp+0x10]
0000705c0addc429  vmovaps xmm2, [rsp+0x20]
0000705c0addc42f  vmovaps xmm3, [rsp+0x30]
0000705c0addc435  vmovaps xmm4, [rsp+0x40]
0000705c0addc43b  vmovaps xmm6, [rsp+0x50]
0000705c0addc441  vmovaps xmm7, [rsp+0x60]
0000705c0addc447  vmovaps xmm8, [rsp+0x70]
0000705c0addc44d  vmovaps xmm9, [rsp+0x80]
0000705c0addc456  vmovaps xmm10, [rsp+0x90]
0000705c0addc45f  vmovaps xmm11, [rsp+0xA0]
0000705c0addc468  vmovaps xmm12, [rsp+0xB0]
0000705c0addc471  vmovaps xmm13, [rsp+0xC0]
0000705c0addc47a  vmovaps xmm14, [rsp+0xD0]
0000705c0addc483  vmovaps xmm15, [rsp+0xE0]
0000705c0addc48c  add rsp, 0xF0
0000705c0addc493  pop r11
0000705c0addc495  pop r10
0000705c0addc497  pop r9
0000705c0addc499  pop r8
0000705c0addc49b  pop rsi
0000705c0addc49c  pop rdi
0000705c0addc49d  pop rdx
0000705c0addc49e  pop rcx
0000705c0addc49f  pop rax
0000705c0addc4a0  add rsp, 0x08
0000705c0addc4a4  jmp 0x0000705C0ADD93E0
0000705c0addc4a9  sub rsp, 0x08
0000705c0addc4ad  push rax
0000705c0addc4ae  push rcx
0000705c0addc4af  push rdx
0000705c0addc4b0  push rdi
0000705c0addc4b1  push rsi
0000705c0addc4b2  push r8
0000705c0addc4b4  push r9
0000705c0addc4b6  push r10
0000705c0addc4b8  push r11
0000705c0addc4ba  sub rsp, 0xF0
0000705c0addc4c1  vmovaps [rsp], xmm0
0000705c0addc4c6  vmovaps [rsp+0x10], xmm1
0000705c0addc4cc  vmovaps [rsp+0x20], xmm2
0000705c0addc4d2  vmovaps [rsp+0x30], xmm3
0000705c0addc4d8  vmovaps [rsp+0x40], xmm4
0000705c0addc4de  vmovaps [rsp+0x50], xmm5
0000705c0addc4e4  vmovaps [rsp+0x60], xmm7
0000705c0addc4ea  vmovaps [rsp+0x70], xmm8
0000705c0addc4f0  vmovaps [rsp+0x80], xmm9
0000705c0addc4f9  vmovaps [rsp+0x90], xmm10
0000705c0addc502  vmovaps [rsp+0xA0], xmm11
0000705c0addc50b  vmovaps [rsp+0xB0], xmm12
0000705c0addc514  vmovaps [rsp+0xC0], xmm13
0000705c0addc51d  vmovaps [rsp+0xD0], xmm14
0000705c0addc526  vmovaps [rsp+0xE0], xmm15
0000705c0addc52f  sub rsp, 0x30
0000705c0addc533  movaps [rsp], xmm6
0000705c0addc537  movaps [rsp+0x10], xmm10
0000705c0addc53d  movaps [rsp+0x20], xmm8
0000705c0addc543  lea rdi, [rsp]
0000705c0addc547  mov esi, 0x00
0000705c0addc54c  mov rax, 0x5969C28C4530
0000705c0addc556  call rax
0000705c0addc558  movaps xmm6, [rsp]
0000705c0addc55c  add rsp, 0x30
0000705c0addc560  vmovaps xmm0, [rsp]
0000705c0addc565  vmovaps xmm1, [rsp+0x10]
0000705c0addc56b  vmovaps xmm2, [rsp+0x20]
0000705c0addc571  vmovaps xmm3, [rsp+0x30]
0000705c0addc577  vmovaps xmm4, [rsp+0x40]
0000705c0addc57d  vmovaps xmm5, [rsp+0x50]
0000705c0addc583  vmovaps xmm7, [rsp+0x60]
0000705c0addc589  vmovaps xmm8, [rsp+0x70]
0000705c0addc58f  vmovaps xmm9, [rsp+0x80]
0000705c0addc598  vmovaps xmm10, [rsp+0x90]
0000705c0addc5a1  vmovaps xmm11, [rsp+0xA0]
0000705c0addc5aa  vmovaps xmm12, [rsp+0xB0]
0000705c0addc5b3  vmovaps xmm13, [rsp+0xC0]
0000705c0addc5bc  vmovaps xmm14, [rsp+0xD0]
0000705c0addc5c5  vmovaps xmm15, [rsp+0xE0]
0000705c0addc5ce  add rsp, 0xF0
0000705c0addc5d5  pop r11
0000705c0addc5d7  pop r10
0000705c0addc5d9  pop r9
0000705c0addc5db  pop r8
0000705c0addc5dd  pop rsi
0000705c0addc5de  pop rdi
0000705c0addc5df  pop rdx
0000705c0addc5e0  pop rcx
0000705c0addc5e1  pop rax
0000705c0addc5e2  add rsp, 0x08
0000705c0addc5e6  jmp 0x0000705C0ADD9405
0000705c0addc5eb  sub rsp, 0x08
0000705c0addc5ef  push rax
0000705c0addc5f0  push rcx
0000705c0addc5f1  push rdx
0000705c0addc5f2  push rdi
0000705c0addc5f3  push rsi
0000705c0addc5f4  push r8
0000705c0addc5f6  push r9
0000705c0addc5f8  push r10
0000705c0addc5fa  push r11
0000705c0addc5fc  sub rsp, 0xF0
0000705c0addc603  vmovaps [rsp], xmm0
0000705c0addc608  vmovaps [rsp+0x10], xmm1
0000705c0addc60e  vmovaps [rsp+0x20], xmm2
0000705c0addc614  vmovaps [rsp+0x30], xmm3
0000705c0addc61a  vmovaps [rsp+0x40], xmm4
0000705c0addc620  vmovaps [rsp+0x50], xmm5
0000705c0addc626  vmovaps [rsp+0x60], xmm6
0000705c0addc62c  vmovaps [rsp+0x70], xmm7
0000705c0addc632  vmovaps [rsp+0x80], xmm8
0000705c0addc63b  vmovaps [rsp+0x90], xmm9
0000705c0addc644  vmovaps [rsp+0xA0], xmm11
0000705c0addc64d  vmovaps [rsp+0xB0], xmm12
0000705c0addc656  vmovaps [rsp+0xC0], xmm13
0000705c0addc65f  vmovaps [rsp+0xD0], xmm14
0000705c0addc668  vmovaps [rsp+0xE0], xmm15
0000705c0addc671  sub rsp, 0x30
0000705c0addc675  movaps [rsp], xmm10
0000705c0addc67a  movaps [rsp+0x10], xmm8
0000705c0addc680  movaps [rsp+0x20], xmm14
0000705c0addc686  lea rdi, [rsp]
0000705c0addc68a  mov esi, 0x00
0000705c0addc68f  mov rax, 0x5969C28C4530
0000705c0addc699  call rax
0000705c0addc69b  movaps xmm10, [rsp]
0000705c0addc6a0  add rsp, 0x30
0000705c0addc6a4  vmovaps xmm0, [rsp]
0000705c0addc6a9  vmovaps xmm1, [rsp+0x10]
0000705c0addc6af  vmovaps xmm2, [rsp+0x20]
0000705c0addc6b5  vmovaps xmm3, [rsp+0x30]
0000705c0addc6bb  vmovaps xmm4, [rsp+0x40]
0000705c0addc6c1  vmovaps xmm5, [rsp+0x50]
0000705c0addc6c7  vmovaps xmm6, [rsp+0x60]
0000705c0addc6cd  vmovaps xmm7, [rsp+0x70]
0000705c0addc6d3  vmovaps xmm8, [rsp+0x80]
0000705c0addc6dc  vmovaps xmm9, [rsp+0x90]
0000705c0addc6e5  vmovaps xmm11, [rsp+0xA0]
0000705c0addc6ee  vmovaps xmm12, [rsp+0xB0]
0000705c0addc6f7  vmovaps xmm13, [rsp+0xC0]
0000705c0addc700  vmovaps xmm14, [rsp+0xD0]
0000705c0addc709  vmovaps xmm15, [rsp+0xE0]
0000705c0addc712  add rsp, 0xF0
0000705c0addc719  pop r11
0000705c0addc71b  pop r10
0000705c0addc71d  pop r9
0000705c0addc71f  pop r8
0000705c0addc721  pop rsi
0000705c0addc722  pop rdi
0000705c0addc723  pop rdx
0000705c0addc724  pop rcx
0000705c0addc725  pop rax
0000705c0addc726  add rsp, 0x08
0000705c0addc72a  jmp 0x0000705C0ADD9425
0000705c0addc72f  sub rsp, 0x08
0000705c0addc733  push rax
0000705c0addc734  push rcx
0000705c0addc735  push rdx
0000705c0addc736  push rdi
0000705c0addc737  push rsi
0000705c0addc738  push r8
0000705c0addc73a  push r9
0000705c0addc73c  push r10
0000705c0addc73e  push r11
0000705c0addc740  sub rsp, 0xF0
0000705c0addc747  vmovaps [rsp], xmm0
0000705c0addc74c  vmovaps [rsp+0x10], xmm1
0000705c0addc752  vmovaps [rsp+0x20], xmm2
0000705c0addc758  vmovaps [rsp+0x30], xmm3
0000705c0addc75e  vmovaps [rsp+0x40], xmm4
0000705c0addc764  vmovaps [rsp+0x50], xmm5
0000705c0addc76a  vmovaps [rsp+0x60], xmm6
0000705c0addc770  vmovaps [rsp+0x70], xmm7
0000705c0addc776  vmovaps [rsp+0x80], xmm8
0000705c0addc77f  vmovaps [rsp+0x90], xmm9
0000705c0addc788  vmovaps [rsp+0xA0], xmm10
0000705c0addc791  vmovaps [rsp+0xB0], xmm11
0000705c0addc79a  vmovaps [rsp+0xC0], xmm12
0000705c0addc7a3  vmovaps [rsp+0xD0], xmm13
0000705c0addc7ac  vmovaps [rsp+0xE0], xmm15
0000705c0addc7b5  sub rsp, 0x30
0000705c0addc7b9  movaps [rsp], xmm14
0000705c0addc7be  movaps [rsp+0x10], xmm8
0000705c0addc7c4  movaps [rsp+0x20], xmm4
0000705c0addc7c9  lea rdi, [rsp]
0000705c0addc7cd  mov esi, 0x00
0000705c0addc7d2  mov rax, 0x5969C28C4530
0000705c0addc7dc  call rax
0000705c0addc7de  movaps xmm14, [rsp]
0000705c0addc7e3  add rsp, 0x30
0000705c0addc7e7  vmovaps xmm0, [rsp]
0000705c0addc7ec  vmovaps xmm1, [rsp+0x10]
0000705c0addc7f2  vmovaps xmm2, [rsp+0x20]
0000705c0addc7f8  vmovaps xmm3, [rsp+0x30]
0000705c0addc7fe  vmovaps xmm4, [rsp+0x40]
0000705c0addc804  vmovaps xmm5, [rsp+0x50]
0000705c0addc80a  vmovaps xmm6, [rsp+0x60]
0000705c0addc810  vmovaps xmm7, [rsp+0x70]
0000705c0addc816  vmovaps xmm8, [rsp+0x80]
0000705c0addc81f  vmovaps xmm9, [rsp+0x90]
0000705c0addc828  vmovaps xmm10, [rsp+0xA0]
0000705c0addc831  vmovaps xmm11, [rsp+0xB0]
0000705c0addc83a  vmovaps xmm12, [rsp+0xC0]
0000705c0addc843  vmovaps xmm13, [rsp+0xD0]
0000705c0addc84c  vmovaps xmm15, [rsp+0xE0]
0000705c0addc855  add rsp, 0xF0
0000705c0addc85c  pop r11
0000705c0addc85e  pop r10
0000705c0addc860  pop r9
0000705c0addc862  pop r8
0000705c0addc864  pop rsi
0000705c0addc865  pop rdi
0000705c0addc866  pop rdx
0000705c0addc867  pop rcx
0000705c0addc868  pop rax
0000705c0addc869  add rsp, 0x08
0000705c0addc86d  jmp 0x0000705C0ADD9445
0000705c0addc872  sub rsp, 0x08
0000705c0addc876  push rax
0000705c0addc877  push rcx
0000705c0addc878  push rdx
0000705c0addc879  push rdi
0000705c0addc87a  push rsi
0000705c0addc87b  push r8
0000705c0addc87d  push r9
0000705c0addc87f  push r10
0000705c0addc881  push r11
0000705c0addc883  sub rsp, 0xF0
0000705c0addc88a  vmovaps [rsp], xmm0
0000705c0addc88f  vmovaps [rsp+0x10], xmm1
0000705c0addc895  vmovaps [rsp+0x20], xmm2
0000705c0addc89b  vmovaps [rsp+0x30], xmm3
0000705c0addc8a1  vmovaps [rsp+0x40], xmm5
0000705c0addc8a7  vmovaps [rsp+0x50], xmm6
0000705c0addc8ad  vmovaps [rsp+0x60], xmm7
0000705c0addc8b3  vmovaps [rsp+0x70], xmm8
0000705c0addc8b9  vmovaps [rsp+0x80], xmm9
0000705c0addc8c2  vmovaps [rsp+0x90], xmm10
0000705c0addc8cb  vmovaps [rsp+0xA0], xmm11
0000705c0addc8d4  vmovaps [rsp+0xB0], xmm12
0000705c0addc8dd  vmovaps [rsp+0xC0], xmm13
0000705c0addc8e6  vmovaps [rsp+0xD0], xmm14
0000705c0addc8ef  vmovaps [rsp+0xE0], xmm15
0000705c0addc8f8  sub rsp, 0x30
0000705c0addc8fc  movaps [rsp], xmm4
0000705c0addc900  movaps [rsp+0x10], xmm13
0000705c0addc906  movaps [rsp+0x20], xmm8
0000705c0addc90c  lea rdi, [rsp]
0000705c0addc910  mov esi, 0x00
0000705c0addc915  mov rax, 0x5969C28C4530
0000705c0addc91f  call rax
0000705c0addc921  movaps xmm4, [rsp]
0000705c0addc925  add rsp, 0x30
0000705c0addc929  vmovaps xmm0, [rsp]
0000705c0addc92e  vmovaps xmm1, [rsp+0x10]
0000705c0addc934  vmovaps xmm2, [rsp+0x20]
0000705c0addc93a  vmovaps xmm3, [rsp+0x30]
0000705c0addc940  vmovaps xmm5, [rsp+0x40]
0000705c0addc946  vmovaps xmm6, [rsp+0x50]
0000705c0addc94c  vmovaps xmm7, [rsp+0x60]
0000705c0addc952  vmovaps xmm8, [rsp+0x70]
0000705c0addc958  vmovaps xmm9, [rsp+0x80]
0000705c0addc961  vmovaps xmm10, [rsp+0x90]
0000705c0addc96a  vmovaps xmm11, [rsp+0xA0]
0000705c0addc973  vmovaps xmm12, [rsp+0xB0]
0000705c0addc97c  vmovaps xmm13, [rsp+0xC0]
0000705c0addc985  vmovaps xmm14, [rsp+0xD0]
0000705c0addc98e  vmovaps xmm15, [rsp+0xE0]
0000705c0addc997  add rsp, 0xF0
0000705c0addc99e  pop r11
0000705c0addc9a0  pop r10
0000705c0addc9a2  pop r9
0000705c0addc9a4  pop r8
0000705c0addc9a6  pop rsi
0000705c0addc9a7  pop rdi
0000705c0addc9a8  pop rdx
0000705c0addc9a9  pop rcx
0000705c0addc9aa  pop rax
0000705c0addc9ab  add rsp, 0x08
0000705c0addc9af  jmp 0x0000705C0ADD946A
0000705c0addc9b4  sub rsp, 0x08
0000705c0addc9b8  push rax
0000705c0addc9b9  push rcx
0000705c0addc9ba  push rdx
0000705c0addc9bb  push rdi
0000705c0addc9bc  push rsi
0000705c0addc9bd  push r8
0000705c0addc9bf  push r9
0000705c0addc9c1  push r10
0000705c0addc9c3  push r11
0000705c0addc9c5  sub rsp, 0xF0
0000705c0addc9cc  vmovaps [rsp], xmm0
0000705c0addc9d1  vmovaps [rsp+0x10], xmm1
0000705c0addc9d7  vmovaps [rsp+0x20], xmm2
0000705c0addc9dd  vmovaps [rsp+0x30], xmm3
0000705c0addc9e3  vmovaps [rsp+0x40], xmm4
0000705c0addc9e9  vmovaps [rsp+0x50], xmm5
0000705c0addc9ef  vmovaps [rsp+0x60], xmm6
0000705c0addc9f5  vmovaps [rsp+0x70], xmm7
0000705c0addc9fb  vmovaps [rsp+0x80], xmm8
0000705c0addca04  vmovaps [rsp+0x90], xmm9
0000705c0addca0d  vmovaps [rsp+0xA0], xmm10
0000705c0addca16  vmovaps [rsp+0xB0], xmm11
0000705c0addca1f  vmovaps [rsp+0xC0], xmm12
0000705c0addca28  vmovaps [rsp+0xD0], xmm14
0000705c0addca31  vmovaps [rsp+0xE0], xmm15
0000705c0addca3a  sub rsp, 0x30
0000705c0addca3e  movaps [rsp], xmm13
0000705c0addca43  movaps [rsp+0x10], xmm15
0000705c0addca49  movaps [rsp+0x20], xmm9
0000705c0addca4f  lea rdi, [rsp]
0000705c0addca53  mov esi, 0x00
0000705c0addca58  mov rax, 0x5969C28C4530
0000705c0addca62  call rax
0000705c0addca64  movaps xmm13, [rsp]
0000705c0addca69  add rsp, 0x30
0000705c0addca6d  vmovaps xmm0, [rsp]
0000705c0addca72  vmovaps xmm1, [rsp+0x10]
0000705c0addca78  vmovaps xmm2, [rsp+0x20]
0000705c0addca7e  vmovaps xmm3, [rsp+0x30]
0000705c0addca84  vmovaps xmm4, [rsp+0x40]
0000705c0addca8a  vmovaps xmm5, [rsp+0x50]
0000705c0addca90  vmovaps xmm6, [rsp+0x60]
0000705c0addca96  vmovaps xmm7, [rsp+0x70]
0000705c0addca9c  vmovaps xmm8, [rsp+0x80]
0000705c0addcaa5  vmovaps xmm9, [rsp+0x90]
0000705c0addcaae  vmovaps xmm10, [rsp+0xA0]
0000705c0addcab7  vmovaps xmm11, [rsp+0xB0]
0000705c0addcac0  vmovaps xmm12, [rsp+0xC0]
0000705c0addcac9  vmovaps xmm14, [rsp+0xD0]
0000705c0addcad2  vmovaps xmm15, [rsp+0xE0]
0000705c0addcadb  add rsp, 0xF0
0000705c0addcae2  pop r11
0000705c0addcae4  pop r10
0000705c0addcae6  pop r9
0000705c0addcae8  pop r8
0000705c0addcaea  pop rsi
0000705c0addcaeb  pop rdi
0000705c0addcaec  pop rdx
0000705c0addcaed  pop rcx
0000705c0addcaee  pop rax
0000705c0addcaef  add rsp, 0x08
0000705c0addcaf3  jmp 0x0000705C0ADD9485
0000705c0addcaf8  sub rsp, 0x08
0000705c0addcafc  push rax
0000705c0addcafd  push rcx
0000705c0addcafe  push rdx
0000705c0addcaff  push rdi
0000705c0addcb00  push rsi
0000705c0addcb01  push r8
0000705c0addcb03  push r9
0000705c0addcb05  push r10
0000705c0addcb07  push r11
0000705c0addcb09  sub rsp, 0xF0
0000705c0addcb10  vmovaps [rsp], xmm0
0000705c0addcb15  vmovaps [rsp+0x10], xmm1
0000705c0addcb1b  vmovaps [rsp+0x20], xmm2
0000705c0addcb21  vmovaps [rsp+0x30], xmm3
0000705c0addcb27  vmovaps [rsp+0x40], xmm4
0000705c0addcb2d  vmovaps [rsp+0x50], xmm5
0000705c0addcb33  vmovaps [rsp+0x60], xmm6
0000705c0addcb39  vmovaps [rsp+0x70], xmm7
0000705c0addcb3f  vmovaps [rsp+0x80], xmm8
0000705c0addcb48  vmovaps [rsp+0x90], xmm9
0000705c0addcb51  vmovaps [rsp+0xA0], xmm10
0000705c0addcb5a  vmovaps [rsp+0xB0], xmm11
0000705c0addcb63  vmovaps [rsp+0xC0], xmm12
0000705c0addcb6c  vmovaps [rsp+0xD0], xmm13
0000705c0addcb75  vmovaps [rsp+0xE0], xmm14
0000705c0addcb7e  sub rsp, 0x30
0000705c0addcb82  movaps [rsp], xmm15
0000705c0addcb87  movaps [rsp+0x10], xmm1
0000705c0addcb8c  movaps [rsp+0x20], xmm5
0000705c0addcb91  lea rdi, [rsp]
0000705c0addcb95  mov esi, 0x00
0000705c0addcb9a  mov rax, 0x5969C28C4530
0000705c0addcba4  call rax
0000705c0addcba6  movaps xmm15, [rsp]
0000705c0addcbab  add rsp, 0x30
0000705c0addcbaf  vmovaps xmm0, [rsp]
0000705c0addcbb4  vmovaps xmm1, [rsp+0x10]
0000705c0addcbba  vmovaps xmm2, [rsp+0x20]
0000705c0addcbc0  vmovaps xmm3, [rsp+0x30]
0000705c0addcbc6  vmovaps xmm4, [rsp+0x40]
0000705c0addcbcc  vmovaps xmm5, [rsp+0x50]
0000705c0addcbd2  vmovaps xmm6, [rsp+0x60]
0000705c0addcbd8  vmovaps xmm7, [rsp+0x70]
0000705c0addcbde  vmovaps xmm8, [rsp+0x80]
0000705c0addcbe7  vmovaps xmm9, [rsp+0x90]
0000705c0addcbf0  vmovaps xmm10, [rsp+0xA0]
0000705c0addcbf9  vmovaps xmm11, [rsp+0xB0]
0000705c0addcc02  vmovaps xmm12, [rsp+0xC0]
0000705c0addcc0b  vmovaps xmm13, [rsp+0xD0]
0000705c0addcc14  vmovaps xmm14, [rsp+0xE0]
0000705c0addcc1d  add rsp, 0xF0
0000705c0addcc24  pop r11
0000705c0addcc26  pop r10
0000705c0addcc28  pop r9
0000705c0addcc2a  pop r8
0000705c0addcc2c  pop rsi
0000705c0addcc2d  pop rdi
0000705c0addcc2e  pop rdx
0000705c0addcc2f  pop rcx
0000705c0addcc30  pop rax
0000705c0addcc31  add rsp, 0x08
0000705c0addcc35  jmp 0x0000705C0ADD94A0
0000705c0addcc3a  call 0x0000705C0ACD64F0
0000705c0addcc3f  jmp 0x0000705C0ADD94FB
0000705c0addcc44  sub rsp, 0x08
0000705c0addcc48  push rax
0000705c0addcc49  push rcx
0000705c0addcc4a  push rdx
0000705c0addcc4b  push rdi
0000705c0addcc4c  push rsi
0000705c0addcc4d  push r8
0000705c0addcc4f  push r9
0000705c0addcc51  push r10
0000705c0addcc53  push r11
0000705c0addcc55  sub rsp, 0xF0
0000705c0addcc5c  vmovaps [rsp], xmm0
0000705c0addcc61  vmovaps [rsp+0x10], xmm1
0000705c0addcc67  vmovaps [rsp+0x20], xmm2
0000705c0addcc6d  vmovaps [rsp+0x30], xmm3
0000705c0addcc73  vmovaps [rsp+0x40], xmm4
0000705c0addcc79  vmovaps [rsp+0x50], xmm5
0000705c0addcc7f  vmovaps [rsp+0x60], xmm6
0000705c0addcc85  vmovaps [rsp+0x70], xmm7
0000705c0addcc8b  vmovaps [rsp+0x80], xmm8
0000705c0addcc94  vmovaps [rsp+0x90], xmm10
0000705c0addcc9d  vmovaps [rsp+0xA0], xmm11
0000705c0addcca6  vmovaps [rsp+0xB0], xmm12
0000705c0addccaf  vmovaps [rsp+0xC0], xmm13
0000705c0addccb8  vmovaps [rsp+0xD0], xmm14
0000705c0addccc1  vmovaps [rsp+0xE0], xmm15
0000705c0addccca  sub rsp, 0x30
0000705c0addccce  movaps [rsp], xmm9
0000705c0addccd3  movaps [rsp+0x10], xmm8
0000705c0addccd9  movaps [rsp+0x20], xmm11
0000705c0addccdf  lea rdi, [rsp]
0000705c0addcce3  mov esi, 0x00
0000705c0addcce8  mov rax, 0x5969C28C4530
0000705c0addccf2  call rax
0000705c0addccf4  movaps xmm9, [rsp]
0000705c0addccf9  add rsp, 0x30
0000705c0addccfd  vmovaps xmm0, [rsp]
0000705c0addcd02  vmovaps xmm1, [rsp+0x10]
0000705c0addcd08  vmovaps xmm2, [rsp+0x20]
0000705c0addcd0e  vmovaps xmm3, [rsp+0x30]
0000705c0addcd14  vmovaps xmm4, [rsp+0x40]
0000705c0addcd1a  vmovaps xmm5, [rsp+0x50]
0000705c0addcd20  vmovaps xmm6, [rsp+0x60]
0000705c0addcd26  vmovaps xmm7, [rsp+0x70]
0000705c0addcd2c  vmovaps xmm8, [rsp+0x80]
0000705c0addcd35  vmovaps xmm10, [rsp+0x90]
0000705c0addcd3e  vmovaps xmm11, [rsp+0xA0]
0000705c0addcd47  vmovaps xmm12, [rsp+0xB0]
0000705c0addcd50  vmovaps xmm13, [rsp+0xC0]
0000705c0addcd59  vmovaps xmm14, [rsp+0xD0]
0000705c0addcd62  vmovaps xmm15, [rsp+0xE0]
0000705c0addcd6b  add rsp, 0xF0
0000705c0addcd72  pop r11
0000705c0addcd74  pop r10
0000705c0addcd76  pop r9
0000705c0addcd78  pop r8
0000705c0addcd7a  pop rsi
0000705c0addcd7b  pop rdi
0000705c0addcd7c  pop rdx
0000705c0addcd7d  pop rcx
0000705c0addcd7e  pop rax
0000705c0addcd7f  add rsp, 0x08
0000705c0addcd83  jmp 0x0000705C0ADD9532
0000705c0addcd88  sub rsp, 0x08
0000705c0addcd8c  push rax
0000705c0addcd8d  push rcx
0000705c0addcd8e  push rdx
0000705c0addcd8f  push rdi
0000705c0addcd90  push rsi
0000705c0addcd91  push r8
0000705c0addcd93  push r9
0000705c0addcd95  push r10
0000705c0addcd97  push r11
0000705c0addcd99  sub rsp, 0xF0
0000705c0addcda0  vmovaps [rsp], xmm0
0000705c0addcda5  vmovaps [rsp+0x10], xmm1
0000705c0addcdab  vmovaps [rsp+0x20], xmm2
0000705c0addcdb1  vmovaps [rsp+0x30], xmm3
0000705c0addcdb7  vmovaps [rsp+0x40], xmm4
0000705c0addcdbd  vmovaps [rsp+0x50], xmm5
0000705c0addcdc3  vmovaps [rsp+0x60], xmm6
0000705c0addcdc9  vmovaps [rsp+0x70], xmm7
0000705c0addcdcf  vmovaps [rsp+0x80], xmm8
0000705c0addcdd8  vmovaps [rsp+0x90], xmm9
0000705c0addcde1  vmovaps [rsp+0xA0], xmm10
0000705c0addcdea  vmovaps [rsp+0xB0], xmm12
0000705c0addcdf3  vmovaps [rsp+0xC0], xmm13
0000705c0addcdfc  vmovaps [rsp+0xD0], xmm14
0000705c0addce05  vmovaps [rsp+0xE0], xmm15
0000705c0addce0e  sub rsp, 0x30
0000705c0addce12  movaps [rsp], xmm11
0000705c0addce17  movaps [rsp+0x10], xmm10
0000705c0addce1d  movaps [rsp+0x20], xmm6
0000705c0addce22  lea rdi, [rsp]
0000705c0addce26  mov esi, 0x00
0000705c0addce2b  mov rax, 0x5969C28C4530
0000705c0addce35  call rax
0000705c0addce37  movaps xmm11, [rsp]
0000705c0addce3c  add rsp, 0x30
0000705c0addce40  vmovaps xmm0, [rsp]
0000705c0addce45  vmovaps xmm1, [rsp+0x10]
0000705c0addce4b  vmovaps xmm2, [rsp+0x20]
0000705c0addce51  vmovaps xmm3, [rsp+0x30]
0000705c0addce57  vmovaps xmm4, [rsp+0x40]
0000705c0addce5d  vmovaps xmm5, [rsp+0x50]
0000705c0addce63  vmovaps xmm6, [rsp+0x60]
0000705c0addce69  vmovaps xmm7, [rsp+0x70]
0000705c0addce6f  vmovaps xmm8, [rsp+0x80]
0000705c0addce78  vmovaps xmm9, [rsp+0x90]
0000705c0addce81  vmovaps xmm10, [rsp+0xA0]
0000705c0addce8a  vmovaps xmm12, [rsp+0xB0]
0000705c0addce93  vmovaps xmm13, [rsp+0xC0]
0000705c0addce9c  vmovaps xmm14, [rsp+0xD0]
0000705c0addcea5  vmovaps xmm15, [rsp+0xE0]
0000705c0addceae  add rsp, 0xF0
0000705c0addceb5  pop r11
0000705c0addceb7  pop r10
0000705c0addceb9  pop r9
0000705c0addcebb  pop r8
0000705c0addcebd  pop rsi
0000705c0addcebe  pop rdi
0000705c0addcebf  pop rdx
0000705c0addcec0  pop rcx
0000705c0addcec1  pop rax
0000705c0addcec2  add rsp, 0x08
0000705c0addcec6  jmp 0x0000705C0ADD954D
0000705c0addcecb  sub rsp, 0x08
0000705c0addcecf  push rax
0000705c0addced0  push rcx
0000705c0addced1  push rdx
0000705c0addced2  push rdi
0000705c0addced3  push rsi
0000705c0addced4  push r8
0000705c0addced6  push r9
0000705c0addced8  push r10
0000705c0addceda  push r11
0000705c0addcedc  sub rsp, 0xF0
0000705c0addcee3  vmovaps [rsp], xmm0
0000705c0addcee8  vmovaps [rsp+0x10], xmm1
0000705c0addceee  vmovaps [rsp+0x20], xmm2
0000705c0addcef4  vmovaps [rsp+0x30], xmm3
0000705c0addcefa  vmovaps [rsp+0x40], xmm4
0000705c0addcf00  vmovaps [rsp+0x50], xmm5
0000705c0addcf06  vmovaps [rsp+0x60], xmm6
0000705c0addcf0c  vmovaps [rsp+0x70], xmm7
0000705c0addcf12  vmovaps [rsp+0x80], xmm8
0000705c0addcf1b  vmovaps [rsp+0x90], xmm9
0000705c0addcf24  vmovaps [rsp+0xA0], xmm11
0000705c0addcf2d  vmovaps [rsp+0xB0], xmm12
0000705c0addcf36  vmovaps [rsp+0xC0], xmm13
0000705c0addcf3f  vmovaps [rsp+0xD0], xmm14
0000705c0addcf48  vmovaps [rsp+0xE0], xmm15
0000705c0addcf51  sub rsp, 0x30
0000705c0addcf55  movaps [rsp], xmm10
0000705c0addcf5a  movaps [rsp+0x10], xmm14
0000705c0addcf60  movaps [rsp+0x20], xmm4
0000705c0addcf65  lea rdi, [rsp]
0000705c0addcf69  mov esi, 0x00
0000705c0addcf6e  mov rax, 0x5969C28C4530
0000705c0addcf78  call rax
0000705c0addcf7a  movaps xmm10, [rsp]
0000705c0addcf7f  add rsp, 0x30
0000705c0addcf83  vmovaps xmm0, [rsp]
0000705c0addcf88  vmovaps xmm1, [rsp+0x10]
0000705c0addcf8e  vmovaps xmm2, [rsp+0x20]
0000705c0addcf94  vmovaps xmm3, [rsp+0x30]
0000705c0addcf9a  vmovaps xmm4, [rsp+0x40]
0000705c0addcfa0  vmovaps xmm5, [rsp+0x50]
0000705c0addcfa6  vmovaps xmm6, [rsp+0x60]
0000705c0addcfac  vmovaps xmm7, [rsp+0x70]
0000705c0addcfb2  vmovaps xmm8, [rsp+0x80]
0000705c0addcfbb  vmovaps xmm9, [rsp+0x90]
0000705c0addcfc4  vmovaps xmm11, [rsp+0xA0]
0000705c0addcfcd  vmovaps xmm12, [rsp+0xB0]
0000705c0addcfd6  vmovaps xmm13, [rsp+0xC0]
0000705c0addcfdf  vmovaps xmm14, [rsp+0xD0]
0000705c0addcfe8  vmovaps xmm15, [rsp+0xE0]
0000705c0addcff1  add rsp, 0xF0
0000705c0addcff8  pop r11
0000705c0addcffa  pop r10
0000705c0addcffc  pop r9
0000705c0addcffe  pop r8
0000705c0addd000  pop rsi
0000705c0addd001  pop rdi
0000705c0addd002  pop rdx
0000705c0addd003  pop rcx
0000705c0addd004  pop rax
0000705c0addd005  add rsp, 0x08
0000705c0addd009  jmp 0x0000705C0ADD9568
0000705c0addd00e  sub rsp, 0x08
0000705c0addd012  push rax
0000705c0addd013  push rcx
0000705c0addd014  push rdx
0000705c0addd015  push rdi
0000705c0addd016  push rsi
0000705c0addd017  push r8
0000705c0addd019  push r9
0000705c0addd01b  push r10
0000705c0addd01d  push r11
0000705c0addd01f  sub rsp, 0xF0
0000705c0addd026  vmovaps [rsp], xmm0
0000705c0addd02b  vmovaps [rsp+0x10], xmm1
0000705c0addd031  vmovaps [rsp+0x20], xmm2
0000705c0addd037  vmovaps [rsp+0x30], xmm3
0000705c0addd03d  vmovaps [rsp+0x40], xmm4
0000705c0addd043  vmovaps [rsp+0x50], xmm5
0000705c0addd049  vmovaps [rsp+0x60], xmm6
0000705c0addd04f  vmovaps [rsp+0x70], xmm7
0000705c0addd055  vmovaps [rsp+0x80], xmm9
0000705c0addd05e  vmovaps [rsp+0x90], xmm10
0000705c0addd067  vmovaps [rsp+0xA0], xmm11
0000705c0addd070  vmovaps [rsp+0xB0], xmm12
0000705c0addd079  vmovaps [rsp+0xC0], xmm13
0000705c0addd082  vmovaps [rsp+0xD0], xmm14
0000705c0addd08b  vmovaps [rsp+0xE0], xmm15
0000705c0addd094  sub rsp, 0x30
0000705c0addd098  movaps [rsp], xmm8
0000705c0addd09d  movaps [rsp+0x10], xmm1
0000705c0addd0a2  movaps [rsp+0x20], xmm14
0000705c0addd0a8  lea rdi, [rsp]
0000705c0addd0ac  mov esi, 0x00
0000705c0addd0b1  mov rax, 0x5969C28C4530
0000705c0addd0bb  call rax
0000705c0addd0bd  movaps xmm8, [rsp]
0000705c0addd0c2  add rsp, 0x30
0000705c0addd0c6  vmovaps xmm0, [rsp]
0000705c0addd0cb  vmovaps xmm1, [rsp+0x10]
0000705c0addd0d1  vmovaps xmm2, [rsp+0x20]
0000705c0addd0d7  vmovaps xmm3, [rsp+0x30]
0000705c0addd0dd  vmovaps xmm4, [rsp+0x40]
0000705c0addd0e3  vmovaps xmm5, [rsp+0x50]
0000705c0addd0e9  vmovaps xmm6, [rsp+0x60]
0000705c0addd0ef  vmovaps xmm7, [rsp+0x70]
0000705c0addd0f5  vmovaps xmm9, [rsp+0x80]
0000705c0addd0fe  vmovaps xmm10, [rsp+0x90]
0000705c0addd107  vmovaps xmm11, [rsp+0xA0]
0000705c0addd110  vmovaps xmm12, [rsp+0xB0]
0000705c0addd119  vmovaps xmm13, [rsp+0xC0]
0000705c0addd122  vmovaps xmm14, [rsp+0xD0]
0000705c0addd12b  vmovaps xmm15, [rsp+0xE0]
0000705c0addd134  add rsp, 0xF0
0000705c0addd13b  pop r11
0000705c0addd13d  pop r10
0000705c0addd13f  pop r9
0000705c0addd141  pop r8
0000705c0addd143  pop rsi
0000705c0addd144  pop rdi
0000705c0addd145  pop rdx
0000705c0addd146  pop rcx
0000705c0addd147  pop rax
0000705c0addd148  add rsp, 0x08
0000705c0addd14c  jmp 0x0000705C0ADD958E
0000705c0addd151  sub rsp, 0x08
0000705c0addd155  push rax
0000705c0addd156  push rcx
0000705c0addd157  push rdx
0000705c0addd158  push rdi
0000705c0addd159  push rsi
0000705c0addd15a  push r8
0000705c0addd15c  push r9
0000705c0addd15e  push r10
0000705c0addd160  push r11
0000705c0addd162  sub rsp, 0xF0
0000705c0addd169  vmovaps [rsp], xmm0
0000705c0addd16e  vmovaps [rsp+0x10], xmm1
0000705c0addd174  vmovaps [rsp+0x20], xmm2
0000705c0addd17a  vmovaps [rsp+0x30], xmm3
0000705c0addd180  vmovaps [rsp+0x40], xmm4
0000705c0addd186  vmovaps [rsp+0x50], xmm5
0000705c0addd18c  vmovaps [rsp+0x60], xmm7
0000705c0addd192  vmovaps [rsp+0x70], xmm8
0000705c0addd198  vmovaps [rsp+0x80], xmm9
0000705c0addd1a1  vmovaps [rsp+0x90], xmm10
0000705c0addd1aa  vmovaps [rsp+0xA0], xmm11
0000705c0addd1b3  vmovaps [rsp+0xB0], xmm12
0000705c0addd1bc  vmovaps [rsp+0xC0], xmm13
0000705c0addd1c5  vmovaps [rsp+0xD0], xmm14
0000705c0addd1ce  vmovaps [rsp+0xE0], xmm15
0000705c0addd1d7  sub rsp, 0x30
0000705c0addd1db  movaps [rsp], xmm6
0000705c0addd1df  movaps [rsp+0x10], xmm1
0000705c0addd1e4  movaps [rsp+0x20], xmm14
0000705c0addd1ea  lea rdi, [rsp]
0000705c0addd1ee  mov esi, 0x00
0000705c0addd1f3  mov rax, 0x5969C28C4530
0000705c0addd1fd  call rax
0000705c0addd1ff  movaps xmm6, [rsp]
0000705c0addd203  add rsp, 0x30
0000705c0addd207  vmovaps xmm0, [rsp]
0000705c0addd20c  vmovaps xmm1, [rsp+0x10]
0000705c0addd212  vmovaps xmm2, [rsp+0x20]
0000705c0addd218  vmovaps xmm3, [rsp+0x30]
0000705c0addd21e  vmovaps xmm4, [rsp+0x40]
0000705c0addd224  vmovaps xmm5, [rsp+0x50]
0000705c0addd22a  vmovaps xmm7, [rsp+0x60]
0000705c0addd230  vmovaps xmm8, [rsp+0x70]
0000705c0addd236  vmovaps xmm9, [rsp+0x80]
0000705c0addd23f  vmovaps xmm10, [rsp+0x90]
0000705c0addd248  vmovaps xmm11, [rsp+0xA0]
0000705c0addd251  vmovaps xmm12, [rsp+0xB0]
0000705c0addd25a  vmovaps xmm13, [rsp+0xC0]
0000705c0addd263  vmovaps xmm14, [rsp+0xD0]
0000705c0addd26c  vmovaps xmm15, [rsp+0xE0]
0000705c0addd275  add rsp, 0xF0
0000705c0addd27c  pop r11
0000705c0addd27e  pop r10
0000705c0addd280  pop r9
0000705c0addd282  pop r8
0000705c0addd284  pop rsi
0000705c0addd285  pop rdi
0000705c0addd286  pop rdx
0000705c0addd287  pop rcx
0000705c0addd288  pop rax
0000705c0addd289  add rsp, 0x08
0000705c0addd28d  jmp 0x0000705C0ADD95BA
0000705c0addd292  sub rsp, 0x08
0000705c0addd296  push rax
0000705c0addd297  push rcx
0000705c0addd298  push rdx
0000705c0addd299  push rdi
0000705c0addd29a  push rsi
0000705c0addd29b  push r8
0000705c0addd29d  push r9
0000705c0addd29f  push r10
0000705c0addd2a1  push r11
0000705c0addd2a3  sub rsp, 0xF0
0000705c0addd2aa  vmovaps [rsp], xmm0
0000705c0addd2af  vmovaps [rsp+0x10], xmm1
0000705c0addd2b5  vmovaps [rsp+0x20], xmm2
0000705c0addd2bb  vmovaps [rsp+0x30], xmm3
0000705c0addd2c1  vmovaps [rsp+0x40], xmm4
0000705c0addd2c7  vmovaps [rsp+0x50], xmm5
0000705c0addd2cd  vmovaps [rsp+0x60], xmm6
0000705c0addd2d3  vmovaps [rsp+0x70], xmm7
0000705c0addd2d9  vmovaps [rsp+0x80], xmm8
0000705c0addd2e2  vmovaps [rsp+0x90], xmm9
0000705c0addd2eb  vmovaps [rsp+0xA0], xmm10
0000705c0addd2f4  vmovaps [rsp+0xB0], xmm11
0000705c0addd2fd  vmovaps [rsp+0xC0], xmm12
0000705c0addd306  vmovaps [rsp+0xD0], xmm13
0000705c0addd30f  vmovaps [rsp+0xE0], xmm15
0000705c0addd318  sub rsp, 0x30
0000705c0addd31c  movaps [rsp], xmm14
0000705c0addd321  movaps [rsp+0x10], xmm12
0000705c0addd327  movaps [rsp+0x20], xmm1
0000705c0addd32c  lea rdi, [rsp]
0000705c0addd330  mov esi, 0x00
0000705c0addd335  mov rax, 0x5969C28C4530
0000705c0addd33f  call rax
0000705c0addd341  movaps xmm14, [rsp]
0000705c0addd346  add rsp, 0x30
0000705c0addd34a  vmovaps xmm0, [rsp]
0000705c0addd34f  vmovaps xmm1, [rsp+0x10]
0000705c0addd355  vmovaps xmm2, [rsp+0x20]
0000705c0addd35b  vmovaps xmm3, [rsp+0x30]
0000705c0addd361  vmovaps xmm4, [rsp+0x40]
0000705c0addd367  vmovaps xmm5, [rsp+0x50]
0000705c0addd36d  vmovaps xmm6, [rsp+0x60]
0000705c0addd373  vmovaps xmm7, [rsp+0x70]
0000705c0addd379  vmovaps xmm8, [rsp+0x80]
0000705c0addd382  vmovaps xmm9, [rsp+0x90]
0000705c0addd38b  vmovaps xmm10, [rsp+0xA0]
0000705c0addd394  vmovaps xmm11, [rsp+0xB0]
0000705c0addd39d  vmovaps xmm12, [rsp+0xC0]
0000705c0addd3a6  vmovaps xmm13, [rsp+0xD0]
0000705c0addd3af  vmovaps xmm15, [rsp+0xE0]
0000705c0addd3b8  add rsp, 0xF0
0000705c0addd3bf  pop r11
0000705c0addd3c1  pop r10
0000705c0addd3c3  pop r9
0000705c0addd3c5  pop r8
0000705c0addd3c7  pop rsi
0000705c0addd3c8  pop rdi
0000705c0addd3c9  pop rdx
0000705c0addd3ca  pop rcx
0000705c0addd3cb  pop rax
0000705c0addd3cc  add rsp, 0x08
0000705c0addd3d0  jmp 0x0000705C0ADD95E0
0000705c0addd3d5  sub rsp, 0x08
0000705c0addd3d9  push rax
0000705c0addd3da  push rcx
0000705c0addd3db  push rdx
0000705c0addd3dc  push rdi
0000705c0addd3dd  push rsi
0000705c0addd3de  push r8
0000705c0addd3e0  push r9
0000705c0addd3e2  push r10
0000705c0addd3e4  push r11
0000705c0addd3e6  sub rsp, 0xF0
0000705c0addd3ed  vmovaps [rsp], xmm0
0000705c0addd3f2  vmovaps [rsp+0x10], xmm2
0000705c0addd3f8  vmovaps [rsp+0x20], xmm3
0000705c0addd3fe  vmovaps [rsp+0x30], xmm4
0000705c0addd404  vmovaps [rsp+0x40], xmm5
0000705c0addd40a  vmovaps [rsp+0x50], xmm6
0000705c0addd410  vmovaps [rsp+0x60], xmm7
0000705c0addd416  vmovaps [rsp+0x70], xmm8
0000705c0addd41c  vmovaps [rsp+0x80], xmm9
0000705c0addd425  vmovaps [rsp+0x90], xmm10
0000705c0addd42e  vmovaps [rsp+0xA0], xmm11
0000705c0addd437  vmovaps [rsp+0xB0], xmm12
0000705c0addd440  vmovaps [rsp+0xC0], xmm13
0000705c0addd449  vmovaps [rsp+0xD0], xmm14
0000705c0addd452  vmovaps [rsp+0xE0], xmm15
0000705c0addd45b  sub rsp, 0x30
0000705c0addd45f  movaps [rsp], xmm1
0000705c0addd463  movaps [rsp+0x10], xmm13
0000705c0addd469  movaps [rsp+0x20], xmm9
0000705c0addd46f  lea rdi, [rsp]
0000705c0addd473  mov esi, 0x00
0000705c0addd478  mov rax, 0x5969C28C4530
0000705c0addd482  call rax
0000705c0addd484  movaps xmm1, [rsp]
0000705c0addd488  add rsp, 0x30
0000705c0addd48c  vmovaps xmm0, [rsp]
0000705c0addd491  vmovaps xmm2, [rsp+0x10]
0000705c0addd497  vmovaps xmm3, [rsp+0x20]
0000705c0addd49d  vmovaps xmm4, [rsp+0x30]
0000705c0addd4a3  vmovaps xmm5, [rsp+0x40]
0000705c0addd4a9  vmovaps xmm6, [rsp+0x50]
0000705c0addd4af  vmovaps xmm7, [rsp+0x60]
0000705c0addd4b5  vmovaps xmm8, [rsp+0x70]
0000705c0addd4bb  vmovaps xmm9, [rsp+0x80]
0000705c0addd4c4  vmovaps xmm10, [rsp+0x90]
0000705c0addd4cd  vmovaps xmm11, [rsp+0xA0]
0000705c0addd4d6  vmovaps xmm12, [rsp+0xB0]
0000705c0addd4df  vmovaps xmm13, [rsp+0xC0]
0000705c0addd4e8  vmovaps xmm14, [rsp+0xD0]
0000705c0addd4f1  vmovaps xmm15, [rsp+0xE0]
0000705c0addd4fa  add rsp, 0xF0
0000705c0addd501  pop r11
0000705c0addd503  pop r10
0000705c0addd505  pop r9
0000705c0addd507  pop r8
0000705c0addd509  pop rsi
0000705c0addd50a  pop rdi
0000705c0addd50b  pop rdx
0000705c0addd50c  pop rcx
0000705c0addd50d  pop rax
0000705c0addd50e  add rsp, 0x08
0000705c0addd512  jmp 0x0000705C0ADD95FA
0000705c0addd517  sub rsp, 0x08
0000705c0addd51b  push rax
0000705c0addd51c  push rcx
0000705c0addd51d  push rdx
0000705c0addd51e  push rdi
0000705c0addd51f  push rsi
0000705c0addd520  push r8
0000705c0addd522  push r9
0000705c0addd524  push r10
0000705c0addd526  push r11
0000705c0addd528  sub rsp, 0xF0
0000705c0addd52f  vmovaps [rsp], xmm0
0000705c0addd534  vmovaps [rsp+0x10], xmm1
0000705c0addd53a  vmovaps [rsp+0x20], xmm2
0000705c0addd540  vmovaps [rsp+0x30], xmm3
0000705c0addd546  vmovaps [rsp+0x40], xmm4
0000705c0addd54c  vmovaps [rsp+0x50], xmm5
0000705c0addd552  vmovaps [rsp+0x60], xmm6
0000705c0addd558  vmovaps [rsp+0x70], xmm7
0000705c0addd55e  vmovaps [rsp+0x80], xmm8
0000705c0addd567  vmovaps [rsp+0x90], xmm9
0000705c0addd570  vmovaps [rsp+0xA0], xmm10
0000705c0addd579  vmovaps [rsp+0xB0], xmm11
0000705c0addd582  vmovaps [rsp+0xC0], xmm13
0000705c0addd58b  vmovaps [rsp+0xD0], xmm14
0000705c0addd594  vmovaps [rsp+0xE0], xmm15
0000705c0addd59d  sub rsp, 0x30
0000705c0addd5a1  movaps [rsp], xmm12
0000705c0addd5a6  movaps [rsp+0x10], xmm7
0000705c0addd5ab  movaps [rsp+0x20], xmm13
0000705c0addd5b1  lea rdi, [rsp]
0000705c0addd5b5  mov esi, 0x00
0000705c0addd5ba  mov rax, 0x5969C28C4530
0000705c0addd5c4  call rax
0000705c0addd5c6  movaps xmm12, [rsp]
0000705c0addd5cb  add rsp, 0x30
0000705c0addd5cf  vmovaps xmm0, [rsp]
0000705c0addd5d4  vmovaps xmm1, [rsp+0x10]
0000705c0addd5da  vmovaps xmm2, [rsp+0x20]
0000705c0addd5e0  vmovaps xmm3, [rsp+0x30]
0000705c0addd5e6  vmovaps xmm4, [rsp+0x40]
0000705c0addd5ec  vmovaps xmm5, [rsp+0x50]
0000705c0addd5f2  vmovaps xmm6, [rsp+0x60]
0000705c0addd5f8  vmovaps xmm7, [rsp+0x70]
0000705c0addd5fe  vmovaps xmm8, [rsp+0x80]
0000705c0addd607  vmovaps xmm9, [rsp+0x90]
0000705c0addd610  vmovaps xmm10, [rsp+0xA0]
0000705c0addd619  vmovaps xmm11, [rsp+0xB0]
0000705c0addd622  vmovaps xmm13, [rsp+0xC0]
0000705c0addd62b  vmovaps xmm14, [rsp+0xD0]
0000705c0addd634  vmovaps xmm15, [rsp+0xE0]
0000705c0addd63d  add rsp, 0xF0
0000705c0addd644  pop r11
0000705c0addd646  pop r10
0000705c0addd648  pop r9
0000705c0addd64a  pop r8
0000705c0addd64c  pop rsi
0000705c0addd64d  pop rdi
0000705c0addd64e  pop rdx
0000705c0addd64f  pop rcx
0000705c0addd650  pop rax
0000705c0addd651  add rsp, 0x08
0000705c0addd655  jmp 0x0000705C0ADD9621
0000705c0addd65a  sub rsp, 0x08
0000705c0addd65e  push rax
0000705c0addd65f  push rcx
0000705c0addd660  push rdx
0000705c0addd661  push rdi
0000705c0addd662  push rsi
0000705c0addd663  push r8
0000705c0addd665  push r9
0000705c0addd667  push r10
0000705c0addd669  push r11
0000705c0addd66b  sub rsp, 0xF0
0000705c0addd672  vmovaps [rsp], xmm0
0000705c0addd677  vmovaps [rsp+0x10], xmm1
0000705c0addd67d  vmovaps [rsp+0x20], xmm2
0000705c0addd683  vmovaps [rsp+0x30], xmm3
0000705c0addd689  vmovaps [rsp+0x40], xmm4
0000705c0addd68f  vmovaps [rsp+0x50], xmm5
0000705c0addd695  vmovaps [rsp+0x60], xmm6
0000705c0addd69b  vmovaps [rsp+0x70], xmm7
0000705c0addd6a1  vmovaps [rsp+0x80], xmm8
0000705c0addd6aa  vmovaps [rsp+0x90], xmm9
0000705c0addd6b3  vmovaps [rsp+0xA0], xmm10
0000705c0addd6bc  vmovaps [rsp+0xB0], xmm11
0000705c0addd6c5  vmovaps [rsp+0xC0], xmm12
0000705c0addd6ce  vmovaps [rsp+0xD0], xmm14
0000705c0addd6d7  vmovaps [rsp+0xE0], xmm15
0000705c0addd6e0  sub rsp, 0x30
0000705c0addd6e4  movaps [rsp], xmm13
0000705c0addd6e9  movaps [rsp+0x10], xmm15
0000705c0addd6ef  movaps [rsp+0x20], xmm8
0000705c0addd6f5  lea rdi, [rsp]
0000705c0addd6f9  mov esi, 0x00
0000705c0addd6fe  mov rax, 0x5969C28C4530
0000705c0addd708  call rax
0000705c0addd70a  movaps xmm13, [rsp]
0000705c0addd70f  add rsp, 0x30
0000705c0addd713  vmovaps xmm0, [rsp]
0000705c0addd718  vmovaps xmm1, [rsp+0x10]
0000705c0addd71e  vmovaps xmm2, [rsp+0x20]
0000705c0addd724  vmovaps xmm3, [rsp+0x30]
0000705c0addd72a  vmovaps xmm4, [rsp+0x40]
0000705c0addd730  vmovaps xmm5, [rsp+0x50]
0000705c0addd736  vmovaps xmm6, [rsp+0x60]
0000705c0addd73c  vmovaps xmm7, [rsp+0x70]
0000705c0addd742  vmovaps xmm8, [rsp+0x80]
0000705c0addd74b  vmovaps xmm9, [rsp+0x90]
0000705c0addd754  vmovaps xmm10, [rsp+0xA0]
0000705c0addd75d  vmovaps xmm11, [rsp+0xB0]
0000705c0addd766  vmovaps xmm12, [rsp+0xC0]
0000705c0addd76f  vmovaps xmm14, [rsp+0xD0]
0000705c0addd778  vmovaps xmm15, [rsp+0xE0]
0000705c0addd781  add rsp, 0xF0
0000705c0addd788  pop r11
0000705c0addd78a  pop r10
0000705c0addd78c  pop r9
0000705c0addd78e  pop r8
0000705c0addd790  pop rsi
0000705c0addd791  pop rdi
0000705c0addd792  pop rdx
0000705c0addd793  pop rcx
0000705c0addd794  pop rax
0000705c0addd795  add rsp, 0x08
0000705c0addd799  jmp 0x0000705C0ADD963C
0000705c0addd79e  sub rsp, 0x08
0000705c0addd7a2  push rax
0000705c0addd7a3  push rcx
0000705c0addd7a4  push rdx
0000705c0addd7a5  push rdi
0000705c0addd7a6  push rsi
0000705c0addd7a7  push r8
0000705c0addd7a9  push r9
0000705c0addd7ab  push r10
0000705c0addd7ad  push r11
0000705c0addd7af  sub rsp, 0xF0
0000705c0addd7b6  vmovaps [rsp], xmm0
0000705c0addd7bb  vmovaps [rsp+0x10], xmm1
0000705c0addd7c1  vmovaps [rsp+0x20], xmm2
0000705c0addd7c7  vmovaps [rsp+0x30], xmm3
0000705c0addd7cd  vmovaps [rsp+0x40], xmm4
0000705c0addd7d3  vmovaps [rsp+0x50], xmm5
0000705c0addd7d9  vmovaps [rsp+0x60], xmm6
0000705c0addd7df  vmovaps [rsp+0x70], xmm7
0000705c0addd7e5  vmovaps [rsp+0x80], xmm9
0000705c0addd7ee  vmovaps [rsp+0x90], xmm10
0000705c0addd7f7  vmovaps [rsp+0xA0], xmm11
0000705c0addd800  vmovaps [rsp+0xB0], xmm12
0000705c0addd809  vmovaps [rsp+0xC0], xmm13
0000705c0addd812  vmovaps [rsp+0xD0], xmm14
0000705c0addd81b  vmovaps [rsp+0xE0], xmm15
0000705c0addd824  sub rsp, 0x30
0000705c0addd828  movaps [rsp], xmm8
0000705c0addd82d  movaps [rsp+0x10], xmm15
0000705c0addd833  movaps [rsp+0x20], xmm9
0000705c0addd839  lea rdi, [rsp]
0000705c0addd83d  mov esi, 0x00
0000705c0addd842  mov rax, 0x5969C28C4530
0000705c0addd84c  call rax
0000705c0addd84e  movaps xmm8, [rsp]
0000705c0addd853  add rsp, 0x30
0000705c0addd857  vmovaps xmm0, [rsp]
0000705c0addd85c  vmovaps xmm1, [rsp+0x10]
0000705c0addd862  vmovaps xmm2, [rsp+0x20]
0000705c0addd868  vmovaps xmm3, [rsp+0x30]
0000705c0addd86e  vmovaps xmm4, [rsp+0x40]
0000705c0addd874  vmovaps xmm5, [rsp+0x50]
0000705c0addd87a  vmovaps xmm6, [rsp+0x60]
0000705c0addd880  vmovaps xmm7, [rsp+0x70]
0000705c0addd886  vmovaps xmm9, [rsp+0x80]
0000705c0addd88f  vmovaps xmm10, [rsp+0x90]
0000705c0addd898  vmovaps xmm11, [rsp+0xA0]
0000705c0addd8a1  vmovaps xmm12, [rsp+0xB0]
0000705c0addd8aa  vmovaps xmm13, [rsp+0xC0]
0000705c0addd8b3  vmovaps xmm14, [rsp+0xD0]
0000705c0addd8bc  vmovaps xmm15, [rsp+0xE0]
0000705c0addd8c5  add rsp, 0xF0
0000705c0addd8cc  pop r11
0000705c0addd8ce  pop r10
0000705c0addd8d0  pop r9
0000705c0addd8d2  pop r8
0000705c0addd8d4  pop rsi
0000705c0addd8d5  pop rdi
0000705c0addd8d6  pop rdx
0000705c0addd8d7  pop rcx
0000705c0addd8d8  pop rax
0000705c0addd8d9  add rsp, 0x08
0000705c0addd8dd  jmp 0x0000705C0ADD966A
0000705c0addd8e2  sub rsp, 0x08
0000705c0addd8e6  push rax
0000705c0addd8e7  push rcx
0000705c0addd8e8  push rdx
0000705c0addd8e9  push rdi
0000705c0addd8ea  push rsi
0000705c0addd8eb  push r8
0000705c0addd8ed  push r9
0000705c0addd8ef  push r10
0000705c0addd8f1  push r11
0000705c0addd8f3  sub rsp, 0xF0
0000705c0addd8fa  vmovaps [rsp], xmm0
0000705c0addd8ff  vmovaps [rsp+0x10], xmm1
0000705c0addd905  vmovaps [rsp+0x20], xmm2
0000705c0addd90b  vmovaps [rsp+0x30], xmm3
0000705c0addd911  vmovaps [rsp+0x40], xmm4
0000705c0addd917  vmovaps [rsp+0x50], xmm5
0000705c0addd91d  vmovaps [rsp+0x60], xmm6
0000705c0addd923  vmovaps [rsp+0x70], xmm7
0000705c0addd929  vmovaps [rsp+0x80], xmm8
0000705c0addd932  vmovaps [rsp+0x90], xmm9
0000705c0addd93b  vmovaps [rsp+0xA0], xmm10
0000705c0addd944  vmovaps [rsp+0xB0], xmm11
0000705c0addd94d  vmovaps [rsp+0xC0], xmm12
0000705c0addd956  vmovaps [rsp+0xD0], xmm13
0000705c0addd95f  vmovaps [rsp+0xE0], xmm14
0000705c0addd968  sub rsp, 0x30
0000705c0addd96c  movaps [rsp], xmm15
0000705c0addd971  movaps [rsp+0x10], xmm11
0000705c0addd977  movaps [rsp+0x20], xmm6
0000705c0addd97c  lea rdi, [rsp]
0000705c0addd980  mov esi, 0x00
0000705c0addd985  mov rax, 0x5969C28C4530
0000705c0addd98f  call rax
0000705c0addd991  movaps xmm15, [rsp]
0000705c0addd996  add rsp, 0x30
0000705c0addd99a  vmovaps xmm0, [rsp]
0000705c0addd99f  vmovaps xmm1, [rsp+0x10]
0000705c0addd9a5  vmovaps xmm2, [rsp+0x20]
0000705c0addd9ab  vmovaps xmm3, [rsp+0x30]
0000705c0addd9b1  vmovaps xmm4, [rsp+0x40]
0000705c0addd9b7  vmovaps xmm5, [rsp+0x50]
0000705c0addd9bd  vmovaps xmm6, [rsp+0x60]
0000705c0addd9c3  vmovaps xmm7, [rsp+0x70]
0000705c0addd9c9  vmovaps xmm8, [rsp+0x80]
0000705c0addd9d2  vmovaps xmm9, [rsp+0x90]
0000705c0addd9db  vmovaps xmm10, [rsp+0xA0]
0000705c0addd9e4  vmovaps xmm11, [rsp+0xB0]
0000705c0addd9ed  vmovaps xmm12, [rsp+0xC0]
0000705c0addd9f6  vmovaps xmm13, [rsp+0xD0]
0000705c0addd9ff  vmovaps xmm14, [rsp+0xE0]
0000705c0addda08  add rsp, 0xF0
0000705c0addda0f  pop r11
0000705c0addda11  pop r10
0000705c0addda13  pop r9
0000705c0addda15  pop r8
0000705c0addda17  pop rsi
0000705c0addda18  pop rdi
0000705c0addda19  pop rdx
0000705c0addda1a  pop rcx
0000705c0addda1b  pop rax
0000705c0addda1c  add rsp, 0x08
0000705c0addda20  jmp 0x0000705C0ADD9685
0000705c0addda25  sub rsp, 0x08
0000705c0addda29  push rax
0000705c0addda2a  push rcx
0000705c0addda2b  push rdx
0000705c0addda2c  push rdi
0000705c0addda2d  push rsi
0000705c0addda2e  push r8
0000705c0addda30  push r9
0000705c0addda32  push r10
0000705c0addda34  push r11
0000705c0addda36  sub rsp, 0xF0
0000705c0addda3d  vmovaps [rsp], xmm0
0000705c0addda42  vmovaps [rsp+0x10], xmm1
0000705c0addda48  vmovaps [rsp+0x20], xmm2
0000705c0addda4e  vmovaps [rsp+0x30], xmm3
0000705c0addda54  vmovaps [rsp+0x40], xmm4
0000705c0addda5a  vmovaps [rsp+0x50], xmm5
0000705c0addda60  vmovaps [rsp+0x60], xmm6
0000705c0addda66  vmovaps [rsp+0x70], xmm8
0000705c0addda6c  vmovaps [rsp+0x80], xmm9
0000705c0addda75  vmovaps [rsp+0x90], xmm10
0000705c0addda7e  vmovaps [rsp+0xA0], xmm11
0000705c0addda87  vmovaps [rsp+0xB0], xmm12
0000705c0addda90  vmovaps [rsp+0xC0], xmm13
0000705c0addda99  vmovaps [rsp+0xD0], xmm14
0000705c0adddaa2  vmovaps [rsp+0xE0], xmm15
0000705c0adddaab  sub rsp, 0x30
0000705c0adddaaf  movaps [rsp], xmm7
0000705c0adddab3  movaps [rsp+0x10], xmm11
0000705c0adddab9  movaps [rsp+0x20], xmm9
0000705c0adddabf  lea rdi, [rsp]
0000705c0adddac3  mov esi, 0x00
0000705c0adddac8  mov rax, 0x5969C28C4530
0000705c0adddad2  call rax
0000705c0adddad4  movaps xmm7, [rsp]
0000705c0adddad8  add rsp, 0x30
0000705c0adddadc  vmovaps xmm0, [rsp]
0000705c0adddae1  vmovaps xmm1, [rsp+0x10]
0000705c0adddae7  vmovaps xmm2, [rsp+0x20]
0000705c0adddaed  vmovaps xmm3, [rsp+0x30]
0000705c0adddaf3  vmovaps xmm4, [rsp+0x40]
0000705c0adddaf9  vmovaps xmm5, [rsp+0x50]
0000705c0adddaff  vmovaps xmm6, [rsp+0x60]
0000705c0adddb05  vmovaps xmm8, [rsp+0x70]
0000705c0adddb0b  vmovaps xmm9, [rsp+0x80]
0000705c0adddb14  vmovaps xmm10, [rsp+0x90]
0000705c0adddb1d  vmovaps xmm11, [rsp+0xA0]
0000705c0adddb26  vmovaps xmm12, [rsp+0xB0]
0000705c0adddb2f  vmovaps xmm13, [rsp+0xC0]
0000705c0adddb38  vmovaps xmm14, [rsp+0xD0]
0000705c0adddb41  vmovaps xmm15, [rsp+0xE0]
0000705c0adddb4a  add rsp, 0xF0
0000705c0adddb51  pop r11
0000705c0adddb53  pop r10
0000705c0adddb55  pop r9
0000705c0adddb57  pop r8
0000705c0adddb59  pop rsi
0000705c0adddb5a  pop rdi
0000705c0adddb5b  pop rdx
0000705c0adddb5c  pop rcx
0000705c0adddb5d  pop rax
0000705c0adddb5e  add rsp, 0x08
0000705c0adddb62  jmp 0x0000705C0ADD96B2
0000705c0adddb67  sub rsp, 0x08
0000705c0adddb6b  push rax
0000705c0adddb6c  push rcx
0000705c0adddb6d  push rdx
0000705c0adddb6e  push rdi
0000705c0adddb6f  push rsi
0000705c0adddb70  push r8
0000705c0adddb72  push r9
0000705c0adddb74  push r10
0000705c0adddb76  push r11
0000705c0adddb78  sub rsp, 0xF0
0000705c0adddb7f  vmovaps [rsp], xmm0
0000705c0adddb84  vmovaps [rsp+0x10], xmm1
0000705c0adddb8a  vmovaps [rsp+0x20], xmm2
0000705c0adddb90  vmovaps [rsp+0x30], xmm3
0000705c0adddb96  vmovaps [rsp+0x40], xmm4
0000705c0adddb9c  vmovaps [rsp+0x50], xmm5
0000705c0adddba2  vmovaps [rsp+0x60], xmm6
0000705c0adddba8  vmovaps [rsp+0x70], xmm7
0000705c0adddbae  vmovaps [rsp+0x80], xmm8
0000705c0adddbb7  vmovaps [rsp+0x90], xmm9
0000705c0adddbc0  vmovaps [rsp+0xA0], xmm10
0000705c0adddbc9  vmovaps [rsp+0xB0], xmm12
0000705c0adddbd2  vmovaps [rsp+0xC0], xmm13
0000705c0adddbdb  vmovaps [rsp+0xD0], xmm14
0000705c0adddbe4  vmovaps [rsp+0xE0], xmm15
0000705c0adddbed  sub rsp, 0x30
0000705c0adddbf1  movaps [rsp], xmm11
0000705c0adddbf6  movaps [rsp+0x10], xmm10
0000705c0adddbfc  movaps [rsp+0x20], xmm14
0000705c0adddc02  lea rdi, [rsp]
0000705c0adddc06  mov esi, 0x00
0000705c0adddc0b  mov rax, 0x5969C28C4530
0000705c0adddc15  call rax
0000705c0adddc17  movaps xmm11, [rsp]
0000705c0adddc1c  add rsp, 0x30
0000705c0adddc20  vmovaps xmm0, [rsp]
0000705c0adddc25  vmovaps xmm1, [rsp+0x10]
0000705c0adddc2b  vmovaps xmm2, [rsp+0x20]
0000705c0adddc31  vmovaps xmm3, [rsp+0x30]
0000705c0adddc37  vmovaps xmm4, [rsp+0x40]
0000705c0adddc3d  vmovaps xmm5, [rsp+0x50]
0000705c0adddc43  vmovaps xmm6, [rsp+0x60]
0000705c0adddc49  vmovaps xmm7, [rsp+0x70]
0000705c0adddc4f  vmovaps xmm8, [rsp+0x80]
0000705c0adddc58  vmovaps xmm9, [rsp+0x90]
0000705c0adddc61  vmovaps xmm10, [rsp+0xA0]
0000705c0adddc6a  vmovaps xmm12, [rsp+0xB0]
0000705c0adddc73  vmovaps xmm13, [rsp+0xC0]
0000705c0adddc7c  vmovaps xmm14, [rsp+0xD0]
0000705c0adddc85  vmovaps xmm15, [rsp+0xE0]
0000705c0adddc8e  add rsp, 0xF0
0000705c0adddc95  pop r11
0000705c0adddc97  pop r10
0000705c0adddc99  pop r9
0000705c0adddc9b  pop r8
0000705c0adddc9d  pop rsi
0000705c0adddc9e  pop rdi
0000705c0adddc9f  pop rdx
0000705c0adddca0  pop rcx
0000705c0adddca1  pop rax
0000705c0adddca2  add rsp, 0x08
0000705c0adddca6  jmp 0x0000705C0ADD96CD
0000705c0adddcab  call 0x0000705C0ACE45A0
0000705c0adddcb0  jmp 0x0000705C0ADD96D7
0000705c0adddcb5  sub rsp, 0x08
0000705c0adddcb9  push rax
0000705c0adddcba  push rcx
0000705c0adddcbb  push rdx
0000705c0adddcbc  push rdi
0000705c0adddcbd  push rsi
0000705c0adddcbe  push r8
0000705c0adddcc0  push r9
0000705c0adddcc2  push r10
0000705c0adddcc4  push r11
0000705c0adddcc6  sub rsp, 0xF0
0000705c0adddccd  vmovaps [rsp], xmm0
0000705c0adddcd2  vmovaps [rsp+0x10], xmm1
0000705c0adddcd8  vmovaps [rsp+0x20], xmm2
0000705c0adddcde  vmovaps [rsp+0x30], xmm3
0000705c0adddce4  vmovaps [rsp+0x40], xmm4
0000705c0adddcea  vmovaps [rsp+0x50], xmm5
0000705c0adddcf0  vmovaps [rsp+0x60], xmm6
0000705c0adddcf6  vmovaps [rsp+0x70], xmm7
0000705c0adddcfc  vmovaps [rsp+0x80], xmm8
0000705c0adddd05  vmovaps [rsp+0x90], xmm9
0000705c0adddd0e  vmovaps [rsp+0xA0], xmm11
0000705c0adddd17  vmovaps [rsp+0xB0], xmm12
0000705c0adddd20  vmovaps [rsp+0xC0], xmm13
0000705c0adddd29  vmovaps [rsp+0xD0], xmm14
0000705c0adddd32  vmovaps [rsp+0xE0], xmm15
0000705c0adddd3b  sub rsp, 0x30
0000705c0adddd3f  movaps [rsp], xmm10
0000705c0adddd44  movaps [rsp+0x10], xmm1
0000705c0adddd49  movaps [rsp+0x20], xmm12
0000705c0adddd4f  lea rdi, [rsp]
0000705c0adddd53  mov esi, 0x00
0000705c0adddd58  mov rax, 0x5969C28C4530
0000705c0adddd62  call rax
0000705c0adddd64  movaps xmm10, [rsp]
0000705c0adddd69  add rsp, 0x30
0000705c0adddd6d  vmovaps xmm0, [rsp]
0000705c0adddd72  vmovaps xmm1, [rsp+0x10]
0000705c0adddd78  vmovaps xmm2, [rsp+0x20]
0000705c0adddd7e  vmovaps xmm3, [rsp+0x30]
0000705c0adddd84  vmovaps xmm4, [rsp+0x40]
0000705c0adddd8a  vmovaps xmm5, [rsp+0x50]
0000705c0adddd90  vmovaps xmm6, [rsp+0x60]
0000705c0adddd96  vmovaps xmm7, [rsp+0x70]
0000705c0adddd9c  vmovaps xmm8, [rsp+0x80]
0000705c0adddda5  vmovaps xmm9, [rsp+0x90]
0000705c0addddae  vmovaps xmm11, [rsp+0xA0]
0000705c0addddb7  vmovaps xmm12, [rsp+0xB0]
0000705c0addddc0  vmovaps xmm13, [rsp+0xC0]
0000705c0addddc9  vmovaps xmm14, [rsp+0xD0]
0000705c0addddd2  vmovaps xmm15, [rsp+0xE0]
0000705c0adddddb  add rsp, 0xF0
0000705c0adddde2  pop r11
0000705c0adddde4  pop r10
0000705c0adddde6  pop r9
0000705c0adddde8  pop r8
0000705c0addddea  pop rsi
0000705c0addddeb  pop rdi
0000705c0addddec  pop rdx
0000705c0adddded  pop rcx
0000705c0addddee  pop rax
0000705c0addddef  add rsp, 0x08
0000705c0addddf3  jmp 0x0000705C0ADD96FA
0000705c0addddf8  sub rsp, 0x08
0000705c0addddfc  push rax
0000705c0addddfd  push rcx
0000705c0addddfe  push rdx
0000705c0addddff  push rdi
0000705c0addde00  push rsi
0000705c0addde01  push r8
0000705c0addde03  push r9
0000705c0addde05  push r10
0000705c0addde07  push r11
0000705c0addde09  sub rsp, 0xF0
0000705c0addde10  vmovaps [rsp], xmm0
0000705c0addde15  vmovaps [rsp+0x10], xmm1
0000705c0addde1b  vmovaps [rsp+0x20], xmm2
0000705c0addde21  vmovaps [rsp+0x30], xmm3
0000705c0addde27  vmovaps [rsp+0x40], xmm4
0000705c0addde2d  vmovaps [rsp+0x50], xmm5
0000705c0addde33  vmovaps [rsp+0x60], xmm6
0000705c0addde39  vmovaps [rsp+0x70], xmm7
0000705c0addde3f  vmovaps [rsp+0x80], xmm8
0000705c0addde48  vmovaps [rsp+0x90], xmm9
0000705c0addde51  vmovaps [rsp+0xA0], xmm10
0000705c0addde5a  vmovaps [rsp+0xB0], xmm11
0000705c0addde63  vmovaps [rsp+0xC0], xmm13
0000705c0addde6c  vmovaps [rsp+0xD0], xmm14
0000705c0addde75  vmovaps [rsp+0xE0], xmm15
0000705c0addde7e  sub rsp, 0x30
0000705c0addde82  movaps [rsp], xmm12
0000705c0addde87  movaps [rsp+0x10], xmm14
0000705c0addde8d  movaps [rsp+0x20], xmm1
0000705c0addde92  lea rdi, [rsp]
0000705c0addde96  mov esi, 0x00
0000705c0addde9b  mov rax, 0x5969C28C4530
0000705c0adddea5  call rax
0000705c0adddea7  movaps xmm12, [rsp]
0000705c0adddeac  add rsp, 0x30
0000705c0adddeb0  vmovaps xmm0, [rsp]
0000705c0adddeb5  vmovaps xmm1, [rsp+0x10]
0000705c0adddebb  vmovaps xmm2, [rsp+0x20]
0000705c0adddec1  vmovaps xmm3, [rsp+0x30]
0000705c0adddec7  vmovaps xmm4, [rsp+0x40]
0000705c0adddecd  vmovaps xmm5, [rsp+0x50]
0000705c0addded3  vmovaps xmm6, [rsp+0x60]
0000705c0addded9  vmovaps xmm7, [rsp+0x70]
0000705c0adddedf  vmovaps xmm8, [rsp+0x80]
0000705c0adddee8  vmovaps xmm9, [rsp+0x90]
0000705c0adddef1  vmovaps xmm10, [rsp+0xA0]
0000705c0adddefa  vmovaps xmm11, [rsp+0xB0]
0000705c0adddf03  vmovaps xmm13, [rsp+0xC0]
0000705c0adddf0c  vmovaps xmm14, [rsp+0xD0]
0000705c0adddf15  vmovaps xmm15, [rsp+0xE0]
0000705c0adddf1e  add rsp, 0xF0
0000705c0adddf25  pop r11
0000705c0adddf27  pop r10
0000705c0adddf29  pop r9
0000705c0adddf2b  pop r8
0000705c0adddf2d  pop rsi
0000705c0adddf2e  pop rdi
0000705c0adddf2f  pop rdx
0000705c0adddf30  pop rcx
0000705c0adddf31  pop rax
0000705c0adddf32  add rsp, 0x08
0000705c0adddf36  jmp 0x0000705C0ADD9729
0000705c0adddf3b  sub rsp, 0x08
0000705c0adddf3f  push rax
0000705c0adddf40  push rcx
0000705c0adddf41  push rdx
0000705c0adddf42  push rdi
0000705c0adddf43  push rsi
0000705c0adddf44  push r8
0000705c0adddf46  push r9
0000705c0adddf48  push r10
0000705c0adddf4a  push r11
0000705c0adddf4c  sub rsp, 0xF0
0000705c0adddf53  vmovaps [rsp], xmm0
0000705c0adddf58  vmovaps [rsp+0x10], xmm1
0000705c0adddf5e  vmovaps [rsp+0x20], xmm2
0000705c0adddf64  vmovaps [rsp+0x30], xmm3
0000705c0adddf6a  vmovaps [rsp+0x40], xmm4
0000705c0adddf70  vmovaps [rsp+0x50], xmm5
0000705c0adddf76  vmovaps [rsp+0x60], xmm6
0000705c0adddf7c  vmovaps [rsp+0x70], xmm7
0000705c0adddf82  vmovaps [rsp+0x80], xmm8
0000705c0adddf8b  vmovaps [rsp+0x90], xmm9
0000705c0adddf94  vmovaps [rsp+0xA0], xmm10
0000705c0adddf9d  vmovaps [rsp+0xB0], xmm11
0000705c0adddfa6  vmovaps [rsp+0xC0], xmm12
0000705c0adddfaf  vmovaps [rsp+0xD0], xmm13
0000705c0adddfb8  vmovaps [rsp+0xE0], xmm15
0000705c0adddfc1  sub rsp, 0x30
0000705c0adddfc5  movaps [rsp], xmm14
0000705c0adddfca  movaps [rsp+0x10], xmm9
0000705c0adddfd0  movaps [rsp+0x20], xmm1
0000705c0adddfd5  lea rdi, [rsp]
0000705c0adddfd9  mov esi, 0x00
0000705c0adddfde  mov rax, 0x5969C28C4530
0000705c0adddfe8  call rax
0000705c0adddfea  movaps xmm14, [rsp]
0000705c0adddfef  add rsp, 0x30
0000705c0adddff3  vmovaps xmm0, [rsp]
0000705c0adddff8  vmovaps xmm1, [rsp+0x10]
0000705c0adddffe  vmovaps xmm2, [rsp+0x20]
0000705c0adde004  vmovaps xmm3, [rsp+0x30]
0000705c0adde00a  vmovaps xmm4, [rsp+0x40]
0000705c0adde010  vmovaps xmm5, [rsp+0x50]
0000705c0adde016  vmovaps xmm6, [rsp+0x60]
0000705c0adde01c  vmovaps xmm7, [rsp+0x70]
0000705c0adde022  vmovaps xmm8, [rsp+0x80]
0000705c0adde02b  vmovaps xmm9, [rsp+0x90]
0000705c0adde034  vmovaps xmm10, [rsp+0xA0]
0000705c0adde03d  vmovaps xmm11, [rsp+0xB0]
0000705c0adde046  vmovaps xmm12, [rsp+0xC0]
0000705c0adde04f  vmovaps xmm13, [rsp+0xD0]
0000705c0adde058  vmovaps xmm15, [rsp+0xE0]
0000705c0adde061  add rsp, 0xF0
0000705c0adde068  pop r11
0000705c0adde06a  pop r10
0000705c0adde06c  pop r9
0000705c0adde06e  pop r8
0000705c0adde070  pop rsi
0000705c0adde071  pop rdi
0000705c0adde072  pop rdx
0000705c0adde073  pop rcx
0000705c0adde074  pop rax
0000705c0adde075  add rsp, 0x08
0000705c0adde079  jmp 0x0000705C0ADD9758
0000705c0adde07e  sub rsp, 0x08
0000705c0adde082  push rax
0000705c0adde083  push rcx
0000705c0adde084  push rdx
0000705c0adde085  push rdi
0000705c0adde086  push rsi
0000705c0adde087  push r8
0000705c0adde089  push r9
0000705c0adde08b  push r10
0000705c0adde08d  push r11
0000705c0adde08f  sub rsp, 0xF0
0000705c0adde096  vmovaps [rsp], xmm0
0000705c0adde09b  vmovaps [rsp+0x10], xmm2
0000705c0adde0a1  vmovaps [rsp+0x20], xmm3
0000705c0adde0a7  vmovaps [rsp+0x30], xmm4
0000705c0adde0ad  vmovaps [rsp+0x40], xmm5
0000705c0adde0b3  vmovaps [rsp+0x50], xmm6
0000705c0adde0b9  vmovaps [rsp+0x60], xmm7
0000705c0adde0bf  vmovaps [rsp+0x70], xmm8
0000705c0adde0c5  vmovaps [rsp+0x80], xmm9
0000705c0adde0ce  vmovaps [rsp+0x90], xmm10
0000705c0adde0d7  vmovaps [rsp+0xA0], xmm11
0000705c0adde0e0  vmovaps [rsp+0xB0], xmm12
0000705c0adde0e9  vmovaps [rsp+0xC0], xmm13
0000705c0adde0f2  vmovaps [rsp+0xD0], xmm14
0000705c0adde0fb  vmovaps [rsp+0xE0], xmm15
0000705c0adde104  sub rsp, 0x30
0000705c0adde108  movaps [rsp], xmm1
0000705c0adde10c  movaps [rsp+0x10], xmm13
0000705c0adde112  movaps [rsp+0x20], xmm8
0000705c0adde118  lea rdi, [rsp]
0000705c0adde11c  mov esi, 0x00
0000705c0adde121  mov rax, 0x5969C28C4530
0000705c0adde12b  call rax
0000705c0adde12d  movaps xmm1, [rsp]
0000705c0adde131  add rsp, 0x30
0000705c0adde135  vmovaps xmm0, [rsp]
0000705c0adde13a  vmovaps xmm2, [rsp+0x10]
0000705c0adde140  vmovaps xmm3, [rsp+0x20]
0000705c0adde146  vmovaps xmm4, [rsp+0x30]
0000705c0adde14c  vmovaps xmm5, [rsp+0x40]
0000705c0adde152  vmovaps xmm6, [rsp+0x50]
0000705c0adde158  vmovaps xmm7, [rsp+0x60]
0000705c0adde15e  vmovaps xmm8, [rsp+0x70]
0000705c0adde164  vmovaps xmm9, [rsp+0x80]
0000705c0adde16d  vmovaps xmm10, [rsp+0x90]
0000705c0adde176  vmovaps xmm11, [rsp+0xA0]
0000705c0adde17f  vmovaps xmm12, [rsp+0xB0]
0000705c0adde188  vmovaps xmm13, [rsp+0xC0]
0000705c0adde191  vmovaps xmm14, [rsp+0xD0]
0000705c0adde19a  vmovaps xmm15, [rsp+0xE0]
0000705c0adde1a3  add rsp, 0xF0
0000705c0adde1aa  pop r11
0000705c0adde1ac  pop r10
0000705c0adde1ae  pop r9
0000705c0adde1b0  pop r8
0000705c0adde1b2  pop rsi
0000705c0adde1b3  pop rdi
0000705c0adde1b4  pop rdx
0000705c0adde1b5  pop rcx
0000705c0adde1b6  pop rax
0000705c0adde1b7  add rsp, 0x08
0000705c0adde1bb  jmp 0x0000705C0ADD977A
0000705c0adde1c0  call 0x0000705C0AC0C260
0000705c0adde1c5  jmp 0x0000705C0ADD9788
0000705c0adde1ca  call 0x0000705C0ACDE950
0000705c0adde1cf  jmp 0x0000705C0ADD9792
0000705c0adde1d4  sub rsp, 0x08
0000705c0adde1d8  push rax
0000705c0adde1d9  push rcx
0000705c0adde1da  push rdx
0000705c0adde1db  push rdi
0000705c0adde1dc  push rsi
0000705c0adde1dd  push r8
0000705c0adde1df  push r9
0000705c0adde1e1  push r10
0000705c0adde1e3  push r11
0000705c0adde1e5  sub rsp, 0xF0
0000705c0adde1ec  vmovaps [rsp], xmm0
0000705c0adde1f1  vmovaps [rsp+0x10], xmm1
0000705c0adde1f7  vmovaps [rsp+0x20], xmm2
0000705c0adde1fd  vmovaps [rsp+0x30], xmm3
0000705c0adde203  vmovaps [rsp+0x40], xmm4
0000705c0adde209  vmovaps [rsp+0x50], xmm5
0000705c0adde20f  vmovaps [rsp+0x60], xmm6
0000705c0adde215  vmovaps [rsp+0x70], xmm7
0000705c0adde21b  vmovaps [rsp+0x80], xmm9
0000705c0adde224  vmovaps [rsp+0x90], xmm10
0000705c0adde22d  vmovaps [rsp+0xA0], xmm11
0000705c0adde236  vmovaps [rsp+0xB0], xmm12
0000705c0adde23f  vmovaps [rsp+0xC0], xmm13
0000705c0adde248  vmovaps [rsp+0xD0], xmm14
0000705c0adde251  vmovaps [rsp+0xE0], xmm15
0000705c0adde25a  sub rsp, 0x30
0000705c0adde25e  movaps [rsp], xmm8
0000705c0adde263  movaps [rsp+0x10], xmm15
0000705c0adde269  movaps [rsp+0x20], xmm7
0000705c0adde26e  lea rdi, [rsp]
0000705c0adde272  mov esi, 0x00
0000705c0adde277  mov rax, 0x5969C28C4530
0000705c0adde281  call rax
0000705c0adde283  movaps xmm8, [rsp]
0000705c0adde288  add rsp, 0x30
0000705c0adde28c  vmovaps xmm0, [rsp]
0000705c0adde291  vmovaps xmm1, [rsp+0x10]
0000705c0adde297  vmovaps xmm2, [rsp+0x20]
0000705c0adde29d  vmovaps xmm3, [rsp+0x30]
0000705c0adde2a3  vmovaps xmm4, [rsp+0x40]
0000705c0adde2a9  vmovaps xmm5, [rsp+0x50]
0000705c0adde2af  vmovaps xmm6, [rsp+0x60]
0000705c0adde2b5  vmovaps xmm7, [rsp+0x70]
0000705c0adde2bb  vmovaps xmm9, [rsp+0x80]
0000705c0adde2c4  vmovaps xmm10, [rsp+0x90]
0000705c0adde2cd  vmovaps xmm11, [rsp+0xA0]
0000705c0adde2d6  vmovaps xmm12, [rsp+0xB0]
0000705c0adde2df  vmovaps xmm13, [rsp+0xC0]
0000705c0adde2e8  vmovaps xmm14, [rsp+0xD0]
0000705c0adde2f1  vmovaps xmm15, [rsp+0xE0]
0000705c0adde2fa  add rsp, 0xF0
0000705c0adde301  pop r11
0000705c0adde303  pop r10
0000705c0adde305  pop r9
0000705c0adde307  pop r8
0000705c0adde309  pop rsi
0000705c0adde30a  pop rdi
0000705c0adde30b  pop rdx
0000705c0adde30c  pop rcx
0000705c0adde30d  pop rax
0000705c0adde30e  add rsp, 0x08
0000705c0adde312  jmp 0x0000705C0ADD97B4
0000705c0adde317  sub rsp, 0x08
0000705c0adde31b  push rax
0000705c0adde31c  push rcx
0000705c0adde31d  push rdx
0000705c0adde31e  push rdi
0000705c0adde31f  push rsi
0000705c0adde320  push r8
0000705c0adde322  push r9
0000705c0adde324  push r10
0000705c0adde326  push r11
0000705c0adde328  sub rsp, 0xF0
0000705c0adde32f  vmovaps [rsp], xmm0
0000705c0adde334  vmovaps [rsp+0x10], xmm1
0000705c0adde33a  vmovaps [rsp+0x20], xmm2
0000705c0adde340  vmovaps [rsp+0x30], xmm3
0000705c0adde346  vmovaps [rsp+0x40], xmm4
0000705c0adde34c  vmovaps [rsp+0x50], xmm5
0000705c0adde352  vmovaps [rsp+0x60], xmm6
0000705c0adde358  vmovaps [rsp+0x70], xmm8
0000705c0adde35e  vmovaps [rsp+0x80], xmm9
0000705c0adde367  vmovaps [rsp+0x90], xmm10
0000705c0adde370  vmovaps [rsp+0xA0], xmm11
0000705c0adde379  vmovaps [rsp+0xB0], xmm12
0000705c0adde382  vmovaps [rsp+0xC0], xmm13
0000705c0adde38b  vmovaps [rsp+0xD0], xmm14
0000705c0adde394  vmovaps [rsp+0xE0], xmm15
0000705c0adde39d  sub rsp, 0x30
0000705c0adde3a1  movaps [rsp], xmm7
0000705c0adde3a5  movaps [rsp+0x10], xmm9
0000705c0adde3ab  movaps [rsp+0x20], xmm15
0000705c0adde3b1  lea rdi, [rsp]
0000705c0adde3b5  mov esi, 0x00
0000705c0adde3ba  mov rax, 0x5969C28C4530
0000705c0adde3c4  call rax
0000705c0adde3c6  movaps xmm7, [rsp]
0000705c0adde3ca  add rsp, 0x30
0000705c0adde3ce  vmovaps xmm0, [rsp]
0000705c0adde3d3  vmovaps xmm1, [rsp+0x10]
0000705c0adde3d9  vmovaps xmm2, [rsp+0x20]
0000705c0adde3df  vmovaps xmm3, [rsp+0x30]
0000705c0adde3e5  vmovaps xmm4, [rsp+0x40]
0000705c0adde3eb  vmovaps xmm5, [rsp+0x50]
0000705c0adde3f1  vmovaps xmm6, [rsp+0x60]
0000705c0adde3f7  vmovaps xmm8, [rsp+0x70]
0000705c0adde3fd  vmovaps xmm9, [rsp+0x80]
0000705c0adde406  vmovaps xmm10, [rsp+0x90]
0000705c0adde40f  vmovaps xmm11, [rsp+0xA0]
0000705c0adde418  vmovaps xmm12, [rsp+0xB0]
0000705c0adde421  vmovaps xmm13, [rsp+0xC0]
0000705c0adde42a  vmovaps xmm14, [rsp+0xD0]
0000705c0adde433  vmovaps xmm15, [rsp+0xE0]
0000705c0adde43c  add rsp, 0xF0
0000705c0adde443  pop r11
0000705c0adde445  pop r10
0000705c0adde447  pop r9
0000705c0adde449  pop r8
0000705c0adde44b  pop rsi
0000705c0adde44c  pop rdi
0000705c0adde44d  pop rdx
0000705c0adde44e  pop rcx
0000705c0adde44f  pop rax
0000705c0adde450  add rsp, 0x08
0000705c0adde454  jmp 0x0000705C0ADD97E1
0000705c0adde459  sub rsp, 0x08
0000705c0adde45d  push rax
0000705c0adde45e  push rcx
0000705c0adde45f  push rdx
0000705c0adde460  push rdi
0000705c0adde461  push rsi
0000705c0adde462  push r8
0000705c0adde464  push r9
0000705c0adde466  push r10
0000705c0adde468  push r11
0000705c0adde46a  sub rsp, 0xF0
0000705c0adde471  vmovaps [rsp], xmm0
0000705c0adde476  vmovaps [rsp+0x10], xmm1
0000705c0adde47c  vmovaps [rsp+0x20], xmm2
0000705c0adde482  vmovaps [rsp+0x30], xmm3
0000705c0adde488  vmovaps [rsp+0x40], xmm4
0000705c0adde48e  vmovaps [rsp+0x50], xmm5
0000705c0adde494  vmovaps [rsp+0x60], xmm6
0000705c0adde49a  vmovaps [rsp+0x70], xmm7
0000705c0adde4a0  vmovaps [rsp+0x80], xmm8
0000705c0adde4a9  vmovaps [rsp+0x90], xmm10
0000705c0adde4b2  vmovaps [rsp+0xA0], xmm11
0000705c0adde4bb  vmovaps [rsp+0xB0], xmm12
0000705c0adde4c4  vmovaps [rsp+0xC0], xmm13
0000705c0adde4cd  vmovaps [rsp+0xD0], xmm14
0000705c0adde4d6  vmovaps [rsp+0xE0], xmm15
0000705c0adde4df  sub rsp, 0x30
0000705c0adde4e3  movaps [rsp], xmm9
0000705c0adde4e8  movaps [rsp+0x10], xmm13
0000705c0adde4ee  movaps [rsp+0x20], xmm15
0000705c0adde4f4  lea rdi, [rsp]
0000705c0adde4f8  mov esi, 0x00
0000705c0adde4fd  mov rax, 0x5969C28C4530
0000705c0adde507  call rax
0000705c0adde509  movaps xmm9, [rsp]
0000705c0adde50e  add rsp, 0x30
0000705c0adde512  vmovaps xmm0, [rsp]
0000705c0adde517  vmovaps xmm1, [rsp+0x10]
0000705c0adde51d  vmovaps xmm2, [rsp+0x20]
0000705c0adde523  vmovaps xmm3, [rsp+0x30]
0000705c0adde529  vmovaps xmm4, [rsp+0x40]
0000705c0adde52f  vmovaps xmm5, [rsp+0x50]
0000705c0adde535  vmovaps xmm6, [rsp+0x60]
0000705c0adde53b  vmovaps xmm7, [rsp+0x70]
0000705c0adde541  vmovaps xmm8, [rsp+0x80]
0000705c0adde54a  vmovaps xmm10, [rsp+0x90]
0000705c0adde553  vmovaps xmm11, [rsp+0xA0]
0000705c0adde55c  vmovaps xmm12, [rsp+0xB0]
0000705c0adde565  vmovaps xmm13, [rsp+0xC0]
0000705c0adde56e  vmovaps xmm14, [rsp+0xD0]
0000705c0adde577  vmovaps xmm15, [rsp+0xE0]
0000705c0adde580  add rsp, 0xF0
0000705c0adde587  pop r11
0000705c0adde589  pop r10
0000705c0adde58b  pop r9
0000705c0adde58d  pop r8
0000705c0adde58f  pop rsi
0000705c0adde590  pop rdi
0000705c0adde591  pop rdx
0000705c0adde592  pop rcx
0000705c0adde593  pop rax
0000705c0adde594  add rsp, 0x08
0000705c0adde598  jmp 0x0000705C0ADD980F
0000705c0adde59d  sub rsp, 0x08
0000705c0adde5a1  push rax
0000705c0adde5a2  push rcx
0000705c0adde5a3  push rdx
0000705c0adde5a4  push rdi
0000705c0adde5a5  push rsi
0000705c0adde5a6  push r8
0000705c0adde5a8  push r9
0000705c0adde5aa  push r10
0000705c0adde5ac  push r11
0000705c0adde5ae  sub rsp, 0xF0
0000705c0adde5b5  vmovaps [rsp], xmm0
0000705c0adde5ba  vmovaps [rsp+0x10], xmm1
0000705c0adde5c0  vmovaps [rsp+0x20], xmm2
0000705c0adde5c6  vmovaps [rsp+0x30], xmm3
0000705c0adde5cc  vmovaps [rsp+0x40], xmm4
0000705c0adde5d2  vmovaps [rsp+0x50], xmm5
0000705c0adde5d8  vmovaps [rsp+0x60], xmm6
0000705c0adde5de  vmovaps [rsp+0x70], xmm7
0000705c0adde5e4  vmovaps [rsp+0x80], xmm8
0000705c0adde5ed  vmovaps [rsp+0x90], xmm9
0000705c0adde5f6  vmovaps [rsp+0xA0], xmm10
0000705c0adde5ff  vmovaps [rsp+0xB0], xmm11
0000705c0adde608  vmovaps [rsp+0xC0], xmm12
0000705c0adde611  vmovaps [rsp+0xD0], xmm13
0000705c0adde61a  vmovaps [rsp+0xE0], xmm14
0000705c0adde623  sub rsp, 0x30
0000705c0adde627  movaps [rsp], xmm15
0000705c0adde62c  movaps [rsp+0x10], xmm11
0000705c0adde632  movaps [rsp+0x20], xmm12
0000705c0adde638  lea rdi, [rsp]
0000705c0adde63c  mov esi, 0x00
0000705c0adde641  mov rax, 0x5969C28C4530
0000705c0adde64b  call rax
0000705c0adde64d  movaps xmm15, [rsp]
0000705c0adde652  add rsp, 0x30
0000705c0adde656  vmovaps xmm0, [rsp]
0000705c0adde65b  vmovaps xmm1, [rsp+0x10]
0000705c0adde661  vmovaps xmm2, [rsp+0x20]
0000705c0adde667  vmovaps xmm3, [rsp+0x30]
0000705c0adde66d  vmovaps xmm4, [rsp+0x40]
0000705c0adde673  vmovaps xmm5, [rsp+0x50]
0000705c0adde679  vmovaps xmm6, [rsp+0x60]
0000705c0adde67f  vmovaps xmm7, [rsp+0x70]
0000705c0adde685  vmovaps xmm8, [rsp+0x80]
0000705c0adde68e  vmovaps xmm9, [rsp+0x90]
0000705c0adde697  vmovaps xmm10, [rsp+0xA0]
0000705c0adde6a0  vmovaps xmm11, [rsp+0xB0]
0000705c0adde6a9  vmovaps xmm12, [rsp+0xC0]
0000705c0adde6b2  vmovaps xmm13, [rsp+0xD0]
0000705c0adde6bb  vmovaps xmm14, [rsp+0xE0]
0000705c0adde6c4  add rsp, 0xF0
0000705c0adde6cb  pop r11
0000705c0adde6cd  pop r10
0000705c0adde6cf  pop r9
0000705c0adde6d1  pop r8
0000705c0adde6d3  pop rsi
0000705c0adde6d4  pop rdi
0000705c0adde6d5  pop rdx
0000705c0adde6d6  pop rcx
0000705c0adde6d7  pop rax
0000705c0adde6d8  add rsp, 0x08
0000705c0adde6dc  jmp 0x0000705C0ADD982A
0000705c0adde6e1  sub rsp, 0x08
0000705c0adde6e5  push rax
0000705c0adde6e6  push rcx
0000705c0adde6e7  push rdx
0000705c0adde6e8  push rdi
0000705c0adde6e9  push rsi
0000705c0adde6ea  push r8
0000705c0adde6ec  push r9
0000705c0adde6ee  push r10
0000705c0adde6f0  push r11
0000705c0adde6f2  sub rsp, 0xF0
0000705c0adde6f9  vmovaps [rsp], xmm0
0000705c0adde6fe  vmovaps [rsp+0x10], xmm1
0000705c0adde704  vmovaps [rsp+0x20], xmm2
0000705c0adde70a  vmovaps [rsp+0x30], xmm3
0000705c0adde710  vmovaps [rsp+0x40], xmm4
0000705c0adde716  vmovaps [rsp+0x50], xmm5
0000705c0adde71c  vmovaps [rsp+0x60], xmm6
0000705c0adde722  vmovaps [rsp+0x70], xmm7
0000705c0adde728  vmovaps [rsp+0x80], xmm8
0000705c0adde731  vmovaps [rsp+0x90], xmm9
0000705c0adde73a  vmovaps [rsp+0xA0], xmm10
0000705c0adde743  vmovaps [rsp+0xB0], xmm11
0000705c0adde74c  vmovaps [rsp+0xC0], xmm12
0000705c0adde755  vmovaps [rsp+0xD0], xmm14
0000705c0adde75e  vmovaps [rsp+0xE0], xmm15
0000705c0adde767  sub rsp, 0x30
0000705c0adde76b  movaps [rsp], xmm13
0000705c0adde770  movaps [rsp+0x10], xmm10
0000705c0adde776  movaps [rsp+0x20], xmm14
0000705c0adde77c  lea rdi, [rsp]
0000705c0adde780  mov esi, 0x00
0000705c0adde785  mov rax, 0x5969C28C4530
0000705c0adde78f  call rax
0000705c0adde791  movaps xmm13, [rsp]
0000705c0adde796  add rsp, 0x30
0000705c0adde79a  vmovaps xmm0, [rsp]
0000705c0adde79f  vmovaps xmm1, [rsp+0x10]
0000705c0adde7a5  vmovaps xmm2, [rsp+0x20]
0000705c0adde7ab  vmovaps xmm3, [rsp+0x30]
0000705c0adde7b1  vmovaps xmm4, [rsp+0x40]
0000705c0adde7b7  vmovaps xmm5, [rsp+0x50]
0000705c0adde7bd  vmovaps xmm6, [rsp+0x60]
0000705c0adde7c3  vmovaps xmm7, [rsp+0x70]
0000705c0adde7c9  vmovaps xmm8, [rsp+0x80]
0000705c0adde7d2  vmovaps xmm9, [rsp+0x90]
0000705c0adde7db  vmovaps xmm10, [rsp+0xA0]
0000705c0adde7e4  vmovaps xmm11, [rsp+0xB0]
0000705c0adde7ed  vmovaps xmm12, [rsp+0xC0]
0000705c0adde7f6  vmovaps xmm14, [rsp+0xD0]
0000705c0adde7ff  vmovaps xmm15, [rsp+0xE0]
0000705c0adde808  add rsp, 0xF0
0000705c0adde80f  pop r11
0000705c0adde811  pop r10
0000705c0adde813  pop r9
0000705c0adde815  pop r8
0000705c0adde817  pop rsi
0000705c0adde818  pop rdi
0000705c0adde819  pop rdx
0000705c0adde81a  pop rcx
0000705c0adde81b  pop rax
0000705c0adde81c  add rsp, 0x08
0000705c0adde820  jmp 0x0000705C0ADD984D
0000705c0adde825  sub rsp, 0x08
0000705c0adde829  push rax
0000705c0adde82a  push rcx
0000705c0adde82b  push rdx
0000705c0adde82c  push rdi
0000705c0adde82d  push rsi
0000705c0adde82e  push r8
0000705c0adde830  push r9
0000705c0adde832  push r10
0000705c0adde834  push r11
0000705c0adde836  sub rsp, 0xF0
0000705c0adde83d  vmovaps [rsp], xmm0
0000705c0adde842  vmovaps [rsp+0x10], xmm1
0000705c0adde848  vmovaps [rsp+0x20], xmm2
0000705c0adde84e  vmovaps [rsp+0x30], xmm3
0000705c0adde854  vmovaps [rsp+0x40], xmm4
0000705c0adde85a  vmovaps [rsp+0x50], xmm5
0000705c0adde860  vmovaps [rsp+0x60], xmm6
0000705c0adde866  vmovaps [rsp+0x70], xmm7
0000705c0adde86c  vmovaps [rsp+0x80], xmm8
0000705c0adde875  vmovaps [rsp+0x90], xmm9
0000705c0adde87e  vmovaps [rsp+0xA0], xmm10
0000705c0adde887  vmovaps [rsp+0xB0], xmm11
0000705c0adde890  vmovaps [rsp+0xC0], xmm12
0000705c0adde899  vmovaps [rsp+0xD0], xmm13
0000705c0adde8a2  vmovaps [rsp+0xE0], xmm15
0000705c0adde8ab  sub rsp, 0x30
0000705c0adde8af  movaps [rsp], xmm14
0000705c0adde8b4  movaps [rsp+0x10], xmm1
0000705c0adde8b9  movaps [rsp+0x20], xmm7
0000705c0adde8be  lea rdi, [rsp]
0000705c0adde8c2  mov esi, 0x00
0000705c0adde8c7  mov rax, 0x5969C28C4530
0000705c0adde8d1  call rax
0000705c0adde8d3  movaps xmm14, [rsp]
0000705c0adde8d8  add rsp, 0x30
0000705c0adde8dc  vmovaps xmm0, [rsp]
0000705c0adde8e1  vmovaps xmm1, [rsp+0x10]
0000705c0adde8e7  vmovaps xmm2, [rsp+0x20]
0000705c0adde8ed  vmovaps xmm3, [rsp+0x30]
0000705c0adde8f3  vmovaps xmm4, [rsp+0x40]
0000705c0adde8f9  vmovaps xmm5, [rsp+0x50]
0000705c0adde8ff  vmovaps xmm6, [rsp+0x60]
0000705c0adde905  vmovaps xmm7, [rsp+0x70]
0000705c0adde90b  vmovaps xmm8, [rsp+0x80]
0000705c0adde914  vmovaps xmm9, [rsp+0x90]
0000705c0adde91d  vmovaps xmm10, [rsp+0xA0]
0000705c0adde926  vmovaps xmm11, [rsp+0xB0]
0000705c0adde92f  vmovaps xmm12, [rsp+0xC0]
0000705c0adde938  vmovaps xmm13, [rsp+0xD0]
0000705c0adde941  vmovaps xmm15, [rsp+0xE0]
0000705c0adde94a  add rsp, 0xF0
0000705c0adde951  pop r11
0000705c0adde953  pop r10
0000705c0adde955  pop r9
0000705c0adde957  pop r8
0000705c0adde959  pop rsi
0000705c0adde95a  pop rdi
0000705c0adde95b  pop rdx
0000705c0adde95c  pop rcx
0000705c0adde95d  pop rax
0000705c0adde95e  add rsp, 0x08
0000705c0adde962  jmp 0x0000705C0ADD9870
0000705c0adde967  sub rsp, 0x08
0000705c0adde96b  push rax
0000705c0adde96c  push rcx
0000705c0adde96d  push rdx
0000705c0adde96e  push rdi
0000705c0adde96f  push rsi
0000705c0adde970  push r8
0000705c0adde972  push r9
0000705c0adde974  push r10
0000705c0adde976  push r11
0000705c0adde978  sub rsp, 0xF0
0000705c0adde97f  vmovaps [rsp], xmm0
0000705c0adde984  vmovaps [rsp+0x10], xmm2
0000705c0adde98a  vmovaps [rsp+0x20], xmm3
0000705c0adde990  vmovaps [rsp+0x30], xmm4
0000705c0adde996  vmovaps [rsp+0x40], xmm5
0000705c0adde99c  vmovaps [rsp+0x50], xmm6
0000705c0adde9a2  vmovaps [rsp+0x60], xmm7
0000705c0adde9a8  vmovaps [rsp+0x70], xmm8
0000705c0adde9ae  vmovaps [rsp+0x80], xmm9
0000705c0adde9b7  vmovaps [rsp+0x90], xmm10
0000705c0adde9c0  vmovaps [rsp+0xA0], xmm11
0000705c0adde9c9  vmovaps [rsp+0xB0], xmm12
0000705c0adde9d2  vmovaps [rsp+0xC0], xmm13
0000705c0adde9db  vmovaps [rsp+0xD0], xmm14
0000705c0adde9e4  vmovaps [rsp+0xE0], xmm15
0000705c0adde9ed  sub rsp, 0x30
0000705c0adde9f1  movaps [rsp], xmm1
0000705c0adde9f5  movaps [rsp+0x10], xmm8
0000705c0adde9fb  movaps [rsp+0x20], xmm9
0000705c0addea01  lea rdi, [rsp]
0000705c0addea05  mov esi, 0x00
0000705c0addea0a  mov rax, 0x5969C28C4530
0000705c0addea14  call rax
0000705c0addea16  movaps xmm1, [rsp]
0000705c0addea1a  add rsp, 0x30
0000705c0addea1e  vmovaps xmm0, [rsp]
0000705c0addea23  vmovaps xmm2, [rsp+0x10]
0000705c0addea29  vmovaps xmm3, [rsp+0x20]
0000705c0addea2f  vmovaps xmm4, [rsp+0x30]
0000705c0addea35  vmovaps xmm5, [rsp+0x40]
0000705c0addea3b  vmovaps xmm6, [rsp+0x50]
0000705c0addea41  vmovaps xmm7, [rsp+0x60]
0000705c0addea47  vmovaps xmm8, [rsp+0x70]
0000705c0addea4d  vmovaps xmm9, [rsp+0x80]
0000705c0addea56  vmovaps xmm10, [rsp+0x90]
0000705c0addea5f  vmovaps xmm11, [rsp+0xA0]
0000705c0addea68  vmovaps xmm12, [rsp+0xB0]
0000705c0addea71  vmovaps xmm13, [rsp+0xC0]
0000705c0addea7a  vmovaps xmm14, [rsp+0xD0]
0000705c0addea83  vmovaps xmm15, [rsp+0xE0]
0000705c0addea8c  add rsp, 0xF0
0000705c0addea93  pop r11
0000705c0addea95  pop r10
0000705c0addea97  pop r9
0000705c0addea99  pop r8
0000705c0addea9b  pop rsi
0000705c0addea9c  pop rdi
0000705c0addea9d  pop rdx
0000705c0addea9e  pop rcx
0000705c0addea9f  pop rax
0000705c0addeaa0  add rsp, 0x08
0000705c0addeaa4  jmp 0x0000705C0ADD9892
0000705c0addeaa9  call 0x0000705C0ACB3E40
0000705c0addeaae  jmp 0x0000705C0ADD98A0
0000705c0addeab3  call 0x0000705C0AC0C380
0000705c0addeab8  jmp 0x0000705C0ADD98AA
0000705c0addeabd  call 0x0000705C0AC0D600
0000705c0addeac2  jmp 0x0000705C0ADD98B4
0000705c0addeac7  call 0x0000705C0ABFF540
0000705c0addeacc  jmp 0x0000705C0ADD98BE
0000705c0addead1  int3
0000705c0addead2  nop [rax+rax*1], ax
0000705c0addeadb  nop [rax+rax*1], eax
0000705c0addeae0  mov eax, [r15+0x48]
0000705c0addeae4  lea r14d, [eax+0x01]
0000705c0addeae9  mov [rsp+0x10], r14d
0000705c0addeaee  mov r14d, r14d
0000705c0addeaf1  mov [r15+0x48], r14
0000705c0addeaf5  xor eax, eax
0000705c0addeaf7  mov r14d, [rsp+0x10]
0000705c0addeafc  cmp r14d, 0x1F4
0000705c0addeb03  cmc
0000705c0addeb04  lahf
0000705c0addeb05  seto al
0000705c0addeb08  mov [r15+0x108], eax
0000705c0addeb0f  mov eax, [r15+0x108]
0000705c0addeb16  sahf
0000705c0addeb17  jnz 0x0000705C0ADDEB49
0000705c0addeb19  cmp dword ptr [r15+0x318], 0x00
0000705c0addeb21  jz 0x0000705C0ADE4C90
0000705c0addeb27  nop [rax+rax*1], ax
0000705c0addeb30  nop [rax+rax*1], eax
0000705c0addeb38  mov eax, 0x4106DC
0000705c0addeb3d  mov [r15+0x100], rax
0000705c0addeb44  jmp 0x0000705C0ABFE110
0000705c0addeb49  cmp dword ptr [r15+0x318], 0x00
0000705c0addeb51  jz 0x0000705C0ADDEB80
0000705c0addeb57  nop [rax+rax*1], ax
0000705c0addeb60  nop [rax+rax*1], eax
0000705c0addeb68  mov eax, 0x410500
0000705c0addeb6d  mov [r15+0x100], rax
0000705c0addeb74  jmp 0x0000705C0ABFE110
0000705c0addeb79  int3
0000705c0addeb7a  int3
0000705c0addeb7b  nop [rax+rax*1], eax
0000705c0addeb80  mov rax, [r15+0x40]
0000705c0addeb84  movaps xmm1, [r15+0x1D0]
0000705c0addeb8c  vmovaps [rsp+0x10], xmm1
0000705c0addeb92  vmovaps xmm15, [rsp+0x10]
0000705c0addeb98  por xmm1, xmm15
0000705c0addeb9d  movaps xmm14, [r15+0x1A0]
0000705c0addeba5  vmovaps [rsp+0x10], xmm14
0000705c0addebab  vmovaps xmm13, [rsp+0x10]
0000705c0addebb1  por xmm14, xmm13
0000705c0addebb6  lea r14, [rax+0x30]
0000705c0addebba  mov r12, [r13+r14*1]
0000705c0addebbf  lea r14, [rax+0x38]
0000705c0addebc3  mov r11, [r13+r14*1]
0000705c0addebc8  movq xmm13, r12
0000705c0addebcd  movq xmm12, r11
0000705c0addebd2  movq xmm13, xmm13
0000705c0addebd7  vmovaps [rsp+0x10], xmm13
0000705c0addebdd  movq xmm13, xmm13
0000705c0addebe2  movaps [r15+0x130], xmm13
0000705c0addebea  movq xmm12, xmm12
0000705c0addebef  vmovaps [rsp+0x20], xmm12
0000705c0addebf5  movq xmm12, xmm12
0000705c0addebfa  movaps [r15+0x280], xmm12
0000705c0addec02  movaps xmm13, [r15+0x270]
0000705c0addec0a  vmovaps [rsp+0x30], xmm13
0000705c0addec10  vmovaps xmm12, [rsp+0x30]
0000705c0addec16  por xmm13, xmm12
0000705c0addec1b  lea r14, [rax+0x20]
0000705c0addec1f  mov r12, [r13+r14*1]
0000705c0addec24  lea r14, [rax+0x28]
0000705c0addec28  mov r11, [r13+r14*1]
0000705c0addec2d  movq xmm12, r12
0000705c0addec32  movq xmm11, r11
0000705c0addec37  movq xmm12, xmm12
0000705c0addec3c  vmovaps [rsp+0x30], xmm12
0000705c0addec42  movq xmm12, xmm12
0000705c0addec47  movaps [r15+0x150], xmm12
0000705c0addec4f  movq xmm11, xmm11
0000705c0addec54  vmovaps [rsp+0x40], xmm11
0000705c0addec5a  movq xmm11, xmm11
0000705c0addec5f  movaps [r15+0x140], xmm11
0000705c0addec67  lea r14, [rax+0x10]
0000705c0addec6b  mov r12, [r13+r14*1]
0000705c0addec70  lea r14, [rax+0x18]
0000705c0addec74  mov r11, [r13+r14*1]
0000705c0addec79  movq xmm12, r12
0000705c0addec7e  movq xmm11, r11
0000705c0addec83  movq xmm12, xmm12
0000705c0addec88  vmovaps [rsp+0x50], xmm12
0000705c0addec8e  movq xmm12, xmm12
0000705c0addec93  movaps [r15+0x170], xmm12
0000705c0addec9b  movq xmm11, xmm11
0000705c0addeca0  vmovaps [rsp+0x60], xmm11
0000705c0addeca6  movq xmm11, xmm11
0000705c0addecab  movaps [r15+0x160], xmm11
0000705c0addecb3  mov r14, [r13+rax*1]
0000705c0addecb8  vmovq xmm12, r14
0000705c0addecbd  vpbroadcastq xmm12, xmm12
0000705c0addecc2  lea r14, [rax+0x08]
0000705c0addecc6  mov rax, [r13+r14*1]
0000705c0addeccb  movq xmm11, rax
0000705c0addecd0  movaps [r15+0x230], xmm11
0000705c0addecd8  mov rax, [r15+0xF8]
0000705c0addecdf  lea r14, [rax+0x50]
0000705c0addece3  movups xmm11, [r13+r14*1]
0000705c0addece9  lea r14, [rax+0x60]
0000705c0addeced  movups xmm10, [r13+r14*1]
0000705c0addecf3  lea r14, [rax+0x30]
0000705c0addecf7  movups xmm9, [r13+r14*1]
0000705c0addecfd  mov r14, [r15+0x50]
0000705c0added01  mov [r15+0x60], r14
0000705c0added05  mov qword ptr [r15+0x58], 0x40
0000705c0added0d  movaps xmm8, xmm12
0000705c0added11  mulpd xmm8, xmm15
0000705c0added16  vcmppd xmm7, xmm8, xmm8, 0x03
0000705c0added1c  ptest xmm7, xmm7
0000705c0added21  jnz 0x0000705C0ADDFB4A
0000705c0added27  movq xmm15, qword ptr [r15+0x230]
0000705c0added30  vmovaps [rsp+0x70], xmm15
0000705c0added36  vpermilpd xmm15, xmm15, 0x00
0000705c0added3c  movaps xmm7, xmm9
0000705c0added40  mulpd xmm7, xmm15
0000705c0added45  vcmppd xmm6, xmm7, xmm7, 0x03
0000705c0added4a  ptest xmm6, xmm6
0000705c0added4f  jnz 0x0000705C0ADDFC8E
0000705c0added55  vxorps xmm15, xmm15, xmm15
0000705c0added5a  vpbroadcastq xmm15, xmm15
0000705c0added5f  movaps xmm9, xmm12
0000705c0added63  mulpd xmm9, xmm10
0000705c0added68  vcmppd xmm6, xmm9, xmm9, 0x03
0000705c0added6e  ptest xmm6, xmm6
0000705c0added73  jnz 0x0000705C0ADDFDD0
0000705c0added79  movaps xmm10, xmm12
0000705c0added7d  mulpd xmm10, xmm11
0000705c0added82  vcmppd xmm6, xmm10, xmm10, 0x03
0000705c0added88  ptest xmm6, xmm6
0000705c0added8d  jnz 0x0000705C0ADDFF14
0000705c0added93  movaps xmm11, [r15+0x1F0]
0000705c0added9b  movaps xmm6, xmm12
0000705c0added9f  mulpd xmm6, xmm11
0000705c0addeda4  vcmppd xmm5, xmm6, xmm6, 0x03
0000705c0addeda9  ptest xmm5, xmm5
0000705c0addedae  jnz 0x0000705C0ADE0058
0000705c0addedb4  movaps xmm12, [r15+0x2A0]
0000705c0addedbc  vmovaps [rsp+0x80], xmm12
0000705c0addedc5  vmovaps xmm11, [rsp+0x80]
0000705c0addedce  por xmm12, xmm11
0000705c0addedd3  movaps xmm11, [r15+0x250]
0000705c0addeddb  vmovaps [rsp+0x80], xmm11
0000705c0addede4  vmovaps xmm5, [rsp+0x80]
0000705c0addeded  por xmm11, xmm5
0000705c0addedf2  vmovaps xmm4, [rsp+0x70]
0000705c0addedf8  vpermilpd xmm4, xmm4, 0x00
0000705c0addedfe  movaps xmm3, xmm5
0000705c0addee01  mulpd xmm3, xmm4
0000705c0addee05  vcmppd xmm2, xmm3, xmm3, 0x03
0000705c0addee0a  ptest xmm2, xmm2
0000705c0addee0f  jnz 0x0000705C0ADE019A
0000705c0addee15  mov [rsp+0x80], rax
0000705c0addee1d  xor eax, eax
0000705c0addee1f  mov r12d, 0x40
0000705c0addee25  mov r11d, 0x200
0000705c0addee2b  cmp r12, r11
0000705c0addee2e  cmc
0000705c0addee2f  lahf
0000705c0addee30  seto al
0000705c0addee33  mov [r15+0x108], eax
0000705c0addee3a  movaps xmm5, xmm8
0000705c0addee3e  addpd xmm5, xmm15
0000705c0addee43  vcmppd xmm4, xmm5, xmm5, 0x03
0000705c0addee48  ptest xmm4, xmm4
0000705c0addee4d  jnz 0x0000705C0ADE02DA
0000705c0addee53  movaps xmm8, [r15+0x1B0]
0000705c0addee5b  movaps xmm4, xmm9
0000705c0addee5f  addpd xmm4, xmm8
0000705c0addee64  vcmppd xmm2, xmm4, xmm4, 0x03
0000705c0addee69  ptest xmm2, xmm2
0000705c0addee6e  jnz 0x0000705C0ADE041C
0000705c0addee74  movaps xmm9, xmm10
0000705c0addee78  addpd xmm9, xmm8
0000705c0addee7d  vcmppd xmm2, xmm9, xmm9, 0x03
0000705c0addee83  ptest xmm2, xmm2
0000705c0addee88  jnz 0x0000705C0ADE055E
0000705c0addee8e  movaps xmm10, [r15+0x2F0]
0000705c0addee96  vmovaps [rsp+0x90], xmm10
0000705c0addee9f  vmovaps xmm8, [rsp+0x90]
0000705c0addeea8  por xmm10, xmm8
0000705c0addeead  movaps xmm8, [r15+0x2E0]
0000705c0addeeb5  vmovaps [rsp+0x90], xmm8
0000705c0addeebe  vmovaps xmm2, [rsp+0x90]
0000705c0addeec7  por xmm8, xmm2
0000705c0addeecc  movaps xmm2, [r15+0x2D0]
0000705c0addeed4  vmovaps [rsp+0x90], xmm2
0000705c0addeedd  vmovaps [rsp+0xA0], xmm1
0000705c0addeee6  vmovaps xmm1, [rsp+0x90]
0000705c0addeeef  por xmm2, xmm1
0000705c0addeef3  movaps xmm1, [r15+0x200]
0000705c0addeefb  vmovaps [rsp+0x90], xmm1
0000705c0addef04  vmovaps [rsp+0xB0], xmm15
0000705c0addef0d  vmovaps xmm15, [rsp+0x90]
0000705c0addef16  por xmm1, xmm15
0000705c0addef1b  movaps xmm15, [r15+0x1C0]
0000705c0addef23  vmovaps [rsp+0x90], xmm15
0000705c0addef2c  vmovaps [rsp+0xC0], xmm1
0000705c0addef35  vmovaps xmm1, [rsp+0x90]
0000705c0addef3e  por xmm15, xmm1
0000705c0addef43  movaps xmm1, [r15+0x190]
0000705c0addef4b  vmovaps [rsp+0x90], xmm1
0000705c0addef54  vmovaps [rsp+0xD0], xmm15
0000705c0addef5d  vmovaps xmm15, [rsp+0x90]
0000705c0addef66  por xmm1, xmm15
0000705c0addef6b  movaps xmm15, [r15+0x300]
0000705c0addef73  vmovaps [rsp+0x90], xmm15
0000705c0addef7c  vmovaps [rsp+0xE0], xmm1
0000705c0addef85  vmovaps xmm1, [rsp+0x90]
0000705c0addef8e  por xmm15, xmm1
0000705c0addef93  mov rax, [rsp+0x80]
0000705c0addef9b  lea r12, [rax+0xA0]
0000705c0addefa2  movups xmm1, [r13+r12*1]
0000705c0addefa8  lea r12, [rax+0xB0]
0000705c0addefaf  vmovaps [rsp+0x80], xmm1
0000705c0addefb8  movups xmm1, [r13+r12*1]
0000705c0addefbe  vmovaps [rsp+0x90], xmm1
0000705c0addefc7  vmovaps [rsp+0xF0], xmm15
0000705c0addefd0  vmovaps xmm15, [rsp+0xB0]
0000705c0addefd9  vmovaps [rsp+0xB0], xmm14
0000705c0addefe2  movaps xmm1, xmm6
0000705c0addefe5  addpd xmm1, xmm15
0000705c0addefea  vcmppd xmm14, xmm1, xmm1, 0x03
0000705c0addefef  ptest xmm14, xmm14
0000705c0addeff5  jnz 0x0000705C0ADE06B6
0000705c0addeffb  lea r12, [rax+0xF0]
0000705c0addf002  movups xmm15, [r13+r12*1]
0000705c0addf008  movaps xmm14, xmm4
0000705c0addf00c  addpd xmm14, xmm3
0000705c0addf011  vcmppd xmm6, xmm14, xmm14, 0x03
0000705c0addf017  ptest xmm6, xmm6
0000705c0addf01c  jnz 0x0000705C0ADE0801
0000705c0addf022  movaps xmm6, xmm9
0000705c0addf026  addpd xmm6, xmm7
0000705c0addf02a  vcmppd xmm4, xmm6, xmm6, 0x03
0000705c0addf02f  ptest xmm4, xmm4
0000705c0addf034  jnz 0x0000705C0ADE0943
0000705c0addf03a  vmovaps xmm9, [rsp+0x70]
0000705c0addf040  vpermilpd xmm9, xmm9, 0x00
0000705c0addf046  vmovaps xmm4, [rsp+0x90]
0000705c0addf04f  movaps xmm7, xmm4
0000705c0addf052  mulpd xmm7, xmm9
0000705c0addf057  vcmppd xmm3, xmm7, xmm7, 0x03
0000705c0addf05c  ptest xmm3, xmm3
0000705c0addf061  jnz 0x0000705C0ADE0A84
0000705c0addf067  vmovaps xmm9, [rsp+0x50]
0000705c0addf06d  vpermilpd xmm9, xmm9, 0x00
0000705c0addf073  movaps xmm4, xmm15
0000705c0addf077  mulpd xmm4, xmm9
0000705c0addf07c  vcmppd xmm3, xmm4, xmm4, 0x03
0000705c0addf081  ptest xmm3, xmm3
0000705c0addf086  jnz 0x0000705C0ADE0BC5
0000705c0addf08c  lea r12, [rax+0xE0]
0000705c0addf093  movups xmm15, [r13+r12*1]
0000705c0addf099  vmovaps xmm9, [rsp+0x70]
0000705c0addf09f  vpermilpd xmm9, xmm9, 0x00
0000705c0addf0a5  vmovaps [rsp+0x70], xmm1
0000705c0addf0ab  vmovaps xmm1, [rsp+0x80]
0000705c0addf0b4  vmovaps [rsp+0x80], xmm15
0000705c0addf0bd  movaps xmm3, xmm1
0000705c0addf0c0  mulpd xmm3, xmm9
0000705c0addf0c5  vcmppd xmm15, xmm3, xmm3, 0x03
0000705c0addf0ca  ptest xmm15, xmm15
0000705c0addf0d0  jnz 0x0000705C0ADE0D11
0000705c0addf0d6  vmovaps xmm1, [rsp+0xF0]
0000705c0addf0df  vmovaps xmm15, [rsp+0xF0]
0000705c0addf0e8  por xmm1, xmm15
0000705c0addf0ed  movaps [r15+0x300], xmm1
0000705c0addf0f5  vmovaps xmm15, [rsp+0xE0]
0000705c0addf0fe  vmovaps xmm9, [rsp+0xE0]
0000705c0addf107  por xmm15, xmm9
0000705c0addf10c  movaps [r15+0x190], xmm15
0000705c0addf114  vmovaps xmm9, [rsp+0x50]
0000705c0addf11a  vpermilpd xmm9, xmm9, 0x00
0000705c0addf120  vmovaps [rsp+0x90], xmm1
0000705c0addf129  vmovaps [rsp+0xE0], xmm15
0000705c0addf132  vmovaps xmm15, [rsp+0x80]
0000705c0addf13b  vmovaps [rsp+0x80], xmm14
0000705c0addf144  movaps xmm1, xmm15
0000705c0addf148  mulpd xmm1, xmm9
0000705c0addf14d  vcmppd xmm14, xmm1, xmm1, 0x03
0000705c0addf152  ptest xmm14, xmm14
0000705c0addf158  jnz 0x0000705C0ADE0E52
0000705c0addf15e  lea r12, [rax+0x90]
0000705c0addf165  movups xmm15, [r13+r12*1]
0000705c0addf16b  vmovaps xmm14, [rsp+0xD0]
0000705c0addf174  vmovaps xmm9, [rsp+0xD0]
0000705c0addf17d  por xmm14, xmm9
0000705c0addf182  movaps [r15+0x1C0], xmm14
0000705c0addf18a  vmovaps xmm9, [rsp+0xC0]
0000705c0addf193  vmovaps [rsp+0xD0], xmm1
0000705c0addf19c  vmovaps xmm1, [rsp+0xC0]
0000705c0addf1a5  por xmm9, xmm1
0000705c0addf1aa  movaps [r15+0x200], xmm9
0000705c0addf1b2  vmovaps [rsp+0xC0], xmm2
0000705c0addf1bb  vmovaps xmm1, [rsp+0xC0]
0000705c0addf1c4  por xmm2, xmm1
0000705c0addf1c8  movaps [r15+0x2D0], xmm2
0000705c0addf1d0  vmovaps [rsp+0xC0], xmm8
0000705c0addf1d9  vmovaps xmm1, [rsp+0xC0]
0000705c0addf1e2  por xmm8, xmm1
0000705c0addf1e7  movaps [r15+0x2E0], xmm8
0000705c0addf1ef  vmovaps [rsp+0xC0], xmm15
0000705c0addf1f8  movaps xmm1, xmm5
0000705c0addf1fb  addpd xmm1, xmm7
0000705c0addf1ff  vcmppd xmm15, xmm1, xmm1, 0x03
0000705c0addf204  ptest xmm15, xmm15
0000705c0addf20a  jnz 0x0000705C0ADE0F9E
0000705c0addf210  vmovaps xmm15, [rsp+0x50]
0000705c0addf216  vpermilpd xmm15, xmm15, 0x00
0000705c0addf21c  vmovaps xmm5, [rsp+0xC0]
0000705c0addf225  vmovaps [rsp+0xC0], xmm1
0000705c0addf22e  movaps xmm7, xmm5
0000705c0addf231  mulpd xmm7, xmm15
0000705c0addf236  vcmppd xmm1, xmm7, xmm7, 0x03
0000705c0addf23b  ptest xmm1, xmm1
0000705c0addf240  jnz 0x0000705C0ADE10DE
0000705c0addf246  lea r12, [rax+0x80]
0000705c0addf24d  movups xmm1, [r13+r12*1]
0000705c0addf253  vmovaps xmm5, [rsp+0x70]
0000705c0addf259  vmovaps [rsp+0x70], xmm1
0000705c0addf25f  movaps xmm15, xmm5
0000705c0addf263  addpd xmm15, xmm3
0000705c0addf268  vcmppd xmm1, xmm15, xmm15, 0x03
0000705c0addf26e  ptest xmm1, xmm1
0000705c0addf273  jnz 0x0000705C0ADE1229
0000705c0addf279  vmovaps xmm5, [rsp+0x80]
0000705c0addf282  movaps xmm1, xmm5
0000705c0addf285  addpd xmm1, xmm4
0000705c0addf289  vcmppd xmm3, xmm1, xmm1, 0x03
0000705c0addf28e  ptest xmm3, xmm3
0000705c0addf293  jnz 0x0000705C0ADE136B
0000705c0addf299  vmovaps [rsp+0x80], xmm10
0000705c0addf2a2  vmovaps xmm5, [rsp+0x80]
0000705c0addf2ab  por xmm10, xmm5
0000705c0addf2b0  movaps [r15+0x2F0], xmm10
0000705c0addf2b8  vmovaps xmm5, [rsp+0x50]
0000705c0addf2be  vpermilpd xmm5, xmm5, 0x00
0000705c0addf2c4  vmovaps xmm3, [rsp+0x70]
0000705c0addf2ca  vmovaps [rsp+0x50], xmm1
0000705c0addf2d0  movaps xmm4, xmm3
0000705c0addf2d3  mulpd xmm4, xmm5
0000705c0addf2d7  vcmppd xmm1, xmm4, xmm4, 0x03
0000705c0addf2dc  ptest xmm1, xmm1
0000705c0addf2e1  jnz 0x0000705C0ADE14AB
0000705c0addf2e7  lea r12, [rax+0xD0]
0000705c0addf2ee  movups xmm1, [r13+r12*1]
0000705c0addf2f4  vmovaps xmm3, [rsp+0xD0]
0000705c0addf2fd  vmovaps [rsp+0x70], xmm1
0000705c0addf303  movaps xmm5, xmm6
0000705c0addf306  addpd xmm5, xmm3
0000705c0addf30a  vcmppd xmm1, xmm5, xmm5, 0x03
0000705c0addf30f  ptest xmm1, xmm1
0000705c0addf314  jnz 0x0000705C0ADE15F5
0000705c0addf31a  vmovaps xmm1, [rsp+0x60]
0000705c0addf320  vpermilpd xmm1, xmm1, 0x00
0000705c0addf326  movaps xmm6, xmm9
0000705c0addf32a  mulpd xmm6, xmm1
0000705c0addf32e  vcmppd xmm3, xmm6, xmm6, 0x03
0000705c0addf333  ptest xmm3, xmm3
0000705c0addf338  jnz 0x0000705C0ADE1735
0000705c0addf33e  movaps [r15+0x260], xmm6
0000705c0addf346  vxorps xmm1, xmm1, xmm1
0000705c0addf34a  vpbroadcastq xmm1, xmm1
0000705c0addf34f  movaps [r15+0x1B0], xmm1
0000705c0addf357  vmovaps xmm1, [rsp+0x60]
0000705c0addf35d  vpermilpd xmm1, xmm1, 0x00
0000705c0addf363  vmovaps xmm3, [rsp+0x70]
0000705c0addf369  vmovaps [rsp+0x70], xmm15
0000705c0addf36f  movaps xmm9, xmm3
0000705c0addf373  mulpd xmm9, xmm1
0000705c0addf378  vcmppd xmm15, xmm9, xmm9, 0x03
0000705c0addf37e  ptest xmm15, xmm15
0000705c0addf384  jnz 0x0000705C0ADE1876
0000705c0addf38a  lea r12, [rax+0xC0]
0000705c0addf391  movups xmm1, [r13+r12*1]
0000705c0addf397  vmovaps xmm3, [rsp+0xC0]
0000705c0addf3a0  vmovaps [rsp+0x80], xmm1
0000705c0addf3a9  movaps xmm15, xmm3
0000705c0addf3ad  addpd xmm15, xmm7
0000705c0addf3b2  vcmppd xmm1, xmm15, xmm15, 0x03
0000705c0addf3b8  ptest xmm1, xmm1
0000705c0addf3bd  jnz 0x0000705C0ADE19C2
0000705c0addf3c3  vmovaps [rsp+0xC0], xmm13
0000705c0addf3cc  vmovaps xmm1, [rsp+0xC0]
0000705c0addf3d5  por xmm13, xmm1
0000705c0addf3da  movaps [r15+0x270], xmm13
0000705c0addf3e2  vmovaps xmm1, [rsp+0xB0]
0000705c0addf3eb  vmovaps xmm7, [rsp+0xB0]
0000705c0addf3f4  por xmm1, xmm7
0000705c0addf3f8  movaps [r15+0x1A0], xmm1
0000705c0addf400  vmovaps xmm1, [rsp+0x60]
0000705c0addf406  vpermilpd xmm1, xmm1, 0x00
0000705c0addf40c  vmovaps [rsp+0xB0], xmm1
0000705c0addf415  vmovaps xmm1, [rsp+0x80]
0000705c0addf41e  vmovaps [rsp+0x80], xmm15
0000705c0addf427  vmovaps xmm15, [rsp+0xB0]
0000705c0addf430  vmovaps [rsp+0xB0], xmm14
0000705c0addf439  movaps xmm3, xmm1
0000705c0addf43c  mulpd xmm3, xmm15
0000705c0addf441  vcmppd xmm14, xmm3, xmm3, 0x03
0000705c0addf446  ptest xmm14, xmm14
0000705c0addf44c  jnz 0x0000705C0ADE1B04
0000705c0addf452  lea r12, [rax+0x20]
0000705c0addf456  movups xmm1, [r13+r12*1]
0000705c0addf45c  movaps [r15+0x110], xmm1
0000705c0addf464  vmovaps xmm14, [rsp+0x70]
0000705c0addf46a  vmovaps [rsp+0x70], xmm1
0000705c0addf470  movaps xmm15, xmm14
0000705c0addf474  addpd xmm15, xmm4
0000705c0addf479  vcmppd xmm1, xmm15, xmm15, 0x03
0000705c0addf47f  ptest xmm1, xmm1
0000705c0addf484  jnz 0x0000705C0ADE1C4F
0000705c0addf48a  vmovaps xmm1, [rsp+0x60]
0000705c0addf490  vpermilpd xmm1, xmm1, 0x00
0000705c0addf496  movaps xmm14, xmm2
0000705c0addf49a  mulpd xmm14, xmm1
0000705c0addf49f  vcmppd xmm4, xmm14, xmm14, 0x03
0000705c0addf4a5  ptest xmm4, xmm4
0000705c0addf4aa  jnz 0x0000705C0ADE1D92
0000705c0addf4b0  vmovaps xmm4, [rsp+0x50]
0000705c0addf4b6  movaps xmm1, xmm4
0000705c0addf4b9  addpd xmm1, xmm9
0000705c0addf4be  vcmppd xmm2, xmm1, xmm1, 0x03
0000705c0addf4c3  ptest xmm2, xmm2
0000705c0addf4c8  jnz 0x0000705C0ADE1ED4
0000705c0addf4ce  vmovaps xmm9, [rsp+0x30]
0000705c0addf4d4  vpermilpd xmm9, xmm9, 0x00
0000705c0addf4da  vmovaps xmm2, [rsp+0x70]
0000705c0addf4e0  vmovaps [rsp+0x50], xmm1
0000705c0addf4e6  movaps xmm4, xmm2
0000705c0addf4e9  mulpd xmm4, xmm9
0000705c0addf4ee  vcmppd xmm1, xmm4, xmm4, 0x03
0000705c0addf4f3  ptest xmm1, xmm1
0000705c0addf4f8  jnz 0x0000705C0ADE2015
0000705c0addf4fe  vmovaps xmm1, [rsp+0x30]
0000705c0addf504  vpermilpd xmm1, xmm1, 0x00
0000705c0addf50a  vmovaps xmm2, [rsp+0x90]
0000705c0addf513  vmovaps [rsp+0x60], xmm15
0000705c0addf519  movaps xmm9, xmm2
0000705c0addf51d  mulpd xmm9, xmm1
0000705c0addf522  vcmppd xmm15, xmm9, xmm9, 0x03
0000705c0addf528  ptest xmm15, xmm15
0000705c0addf52e  jnz 0x0000705C0ADE2156
0000705c0addf534  vmovaps xmm15, [rsp+0x80]
0000705c0addf53d  movaps xmm1, xmm15
0000705c0addf541  addpd xmm1, xmm6
0000705c0addf545  vcmppd xmm2, xmm1, xmm1, 0x03
0000705c0addf54a  ptest xmm2, xmm2
0000705c0addf54f  jnz 0x0000705C0ADE2298
0000705c0addf555  movaps xmm15, xmm5
0000705c0addf559  addpd xmm15, xmm3
0000705c0addf55e  vcmppd xmm6, xmm15, xmm15, 0x03
0000705c0addf564  ptest xmm6, xmm6
0000705c0addf569  jnz 0x0000705C0ADE23D9
0000705c0addf56f  vmovaps xmm6, [rsp+0x30]
0000705c0addf575  vpermilpd xmm6, xmm6, 0x00
0000705c0addf57b  movaps xmm5, xmm8
0000705c0addf57f  mulpd xmm5, xmm6
0000705c0addf583  vcmppd xmm3, xmm5, xmm5, 0x03
0000705c0addf588  ptest xmm3, xmm3
0000705c0addf58d  jnz 0x0000705C0ADE251B
0000705c0addf593  vmovaps xmm8, [rsp+0x30]
0000705c0addf599  vpermilpd xmm8, xmm8, 0x00
0000705c0addf59f  movaps xmm6, xmm10
0000705c0addf5a3  mulpd xmm6, xmm8
0000705c0addf5a8  vcmppd xmm3, xmm6, xmm6, 0x03
0000705c0addf5ad  ptest xmm3, xmm3
0000705c0addf5b2  jnz 0x0000705C0ADE265C
0000705c0addf5b8  vmovaps xmm8, [rsp+0x60]
0000705c0addf5be  movaps xmm10, xmm8
0000705c0addf5c2  addpd xmm10, xmm14
0000705c0addf5c7  vcmppd xmm3, xmm10, xmm10, 0x03
0000705c0addf5cd  ptest xmm3, xmm3
0000705c0addf5d2  jnz 0x0000705C0ADE279E
0000705c0addf5d8  vmovaps xmm8, [rsp+0x50]
0000705c0addf5de  movaps xmm14, xmm8
0000705c0addf5e2  addpd xmm14, xmm4
0000705c0addf5e7  vcmppd xmm3, xmm14, xmm14, 0x03
0000705c0addf5ed  ptest xmm3, xmm3
0000705c0addf5f2  jnz 0x0000705C0ADE28E2
0000705c0addf5f8  vmovaps xmm8, [rsp+0x40]
0000705c0addf5fe  vpermilpd xmm8, xmm8, 0x00
0000705c0addf604  movaps xmm4, xmm13
0000705c0addf608  mulpd xmm4, xmm8
0000705c0addf60d  vcmppd xmm3, xmm4, xmm4, 0x03
0000705c0addf612  ptest xmm3, xmm3
0000705c0addf617  jnz 0x0000705C0ADE2A25
0000705c0addf61d  movaps xmm13, xmm15
0000705c0addf621  addpd xmm13, xmm9
0000705c0addf626  vcmppd xmm8, xmm13, xmm13, 0x03
0000705c0addf62c  ptest xmm8, xmm8
0000705c0addf632  jnz 0x0000705C0ADE2B67
0000705c0addf638  movaps xmm15, xmm1
0000705c0addf63c  addpd xmm15, xmm5
0000705c0addf641  vcmppd xmm9, xmm15, xmm15, 0x03
0000705c0addf647  ptest xmm9, xmm9
0000705c0addf64d  jnz 0x0000705C0ADE2CAB
0000705c0addf653  vmovaps [rsp+0x30], xmm11
0000705c0addf659  vmovaps xmm1, [rsp+0x30]
0000705c0addf65f  por xmm11, xmm1
0000705c0addf664  movaps [r15+0x250], xmm11
0000705c0addf66c  vmovaps [rsp+0x30], xmm12
0000705c0addf672  vmovaps xmm1, [rsp+0x30]
0000705c0addf678  por xmm12, xmm1
0000705c0addf67d  movaps [r15+0x2A0], xmm12
0000705c0addf685  vmovaps xmm1, [rsp+0xA0]
0000705c0addf68e  vmovaps xmm11, [rsp+0xA0]
0000705c0addf697  por xmm1, xmm11
0000705c0addf69c  movaps [r15+0x1D0], xmm1
0000705c0addf6a4  lea r12, [rax+0x40]
0000705c0addf6a8  movups xmm1, [r13+r12*1]
0000705c0addf6ae  movaps [r15+0x2C0], xmm1
0000705c0addf6b6  vmovaps xmm11, [rsp+0x40]
0000705c0addf6bc  vpermilpd xmm11, xmm11, 0x00
0000705c0addf6c2  vmovaps xmm8, [rsp+0xE0]
0000705c0addf6cb  movaps xmm9, xmm8
0000705c0addf6cf  mulpd xmm9, xmm11
0000705c0addf6d4  vcmppd xmm5, xmm9, xmm9, 0x03
0000705c0addf6da  ptest xmm5, xmm5
0000705c0addf6df  jnz 0x0000705C0ADE2DF7
0000705c0addf6e5  movaps xmm11, xmm10
0000705c0addf6e9  addpd xmm11, xmm6
0000705c0addf6ee  vcmppd xmm8, xmm11, xmm11, 0x03
0000705c0addf6f4  ptest xmm8, xmm8
0000705c0addf6fa  jnz 0x0000705C0ADE2F3B
0000705c0addf700  movaps xmm10, xmm14
0000705c0addf704  addpd xmm10, xmm4
0000705c0addf709  vcmppd xmm8, xmm10, xmm10, 0x03
0000705c0addf70f  ptest xmm8, xmm8
0000705c0addf715  jnz 0x0000705C0ADE307E
0000705c0addf71b  vmovaps xmm14, [rsp+0x40]
0000705c0addf721  vpermilpd xmm14, xmm14, 0x00
0000705c0addf727  movaps xmm8, xmm1
0000705c0addf72b  mulpd xmm8, xmm14
0000705c0addf730  vcmppd xmm6, xmm8, xmm8, 0x03
0000705c0addf736  ptest xmm6, xmm6
0000705c0addf73b  jnz 0x0000705C0ADE31C1
0000705c0addf741  movaps xmm1, [r15+0x2B0]
0000705c0addf749  vmovaps xmm14, [rsp+0x40]
0000705c0addf74f  vpermilpd xmm14, xmm14, 0x00
0000705c0addf755  movaps xmm6, xmm1
0000705c0addf758  mulpd xmm6, xmm14
0000705c0addf75d  vcmppd xmm5, xmm6, xmm6, 0x03
0000705c0addf762  ptest xmm5, xmm5
0000705c0addf767  jnz 0x0000705C0ADE3304
0000705c0addf76d  vmovaps xmm1, [rsp+0x10]
0000705c0addf773  vpermilpd xmm1, xmm1, 0x00
0000705c0addf779  movaps xmm14, xmm12
0000705c0addf77d  mulpd xmm14, xmm1
0000705c0addf782  vcmppd xmm5, xmm14, xmm14, 0x03
0000705c0addf788  ptest xmm5, xmm5
0000705c0addf78d  jnz 0x0000705C0ADE3445
0000705c0addf793  movaps xmm1, xmm13
0000705c0addf797  addpd xmm1, xmm9
0000705c0addf79c  vcmppd xmm12, xmm1, xmm1, 0x03
0000705c0addf7a1  ptest xmm12, xmm12
0000705c0addf7a7  jnz 0x0000705C0ADE3588
0000705c0addf7ad  vmovaps xmm13, [rsp+0x10]
0000705c0addf7b3  vpermilpd xmm13, xmm13, 0x00
0000705c0addf7b9  movaps xmm12, xmm7
0000705c0addf7bd  mulpd xmm12, xmm13
0000705c0addf7c2  vcmppd xmm9, xmm12, xmm12, 0x03
0000705c0addf7c8  ptest xmm9, xmm9
0000705c0addf7ce  jnz 0x0000705C0ADE36CA
0000705c0addf7d4  movaps xmm13, xmm15
0000705c0addf7d8  addpd xmm13, xmm8
0000705c0addf7dd  vcmppd xmm9, xmm13, xmm13, 0x03
0000705c0addf7e3  ptest xmm9, xmm9
0000705c0addf7e9  jnz 0x0000705C0ADE380D
0000705c0addf7ef  movaps xmm15, [r15+0x290]
0000705c0addf7f7  vmovaps xmm9, [rsp+0x10]
0000705c0addf7fd  vpermilpd xmm9, xmm9, 0x00
0000705c0addf803  movaps xmm8, xmm15
0000705c0addf807  mulpd xmm8, xmm9
0000705c0addf80c  vcmppd xmm7, xmm8, xmm8, 0x03
0000705c0addf812  ptest xmm7, xmm7
0000705c0addf817  jnz 0x0000705C0ADE3951
0000705c0addf81d  movaps xmm15, xmm11
0000705c0addf821  addpd xmm15, xmm6
0000705c0addf826  vcmppd xmm9, xmm15, xmm15, 0x03
0000705c0addf82c  ptest xmm9, xmm9
0000705c0addf832  jnz 0x0000705C0ADE3A95
0000705c0addf838  movaps xmm11, [r15+0x1E0]
0000705c0addf840  vmovaps xmm9, [rsp+0x10]
0000705c0addf846  vpermilpd xmm9, xmm9, 0x00
0000705c0addf84c  movaps xmm7, xmm11
0000705c0addf850  mulpd xmm7, xmm9
0000705c0addf855  vcmppd xmm6, xmm7, xmm7, 0x03
0000705c0addf85a  ptest xmm6, xmm6
0000705c0addf85f  jnz 0x0000705C0ADE3BD8
0000705c0addf865  movaps xmm11, xmm10
0000705c0addf869  addpd xmm11, xmm14
0000705c0addf86e  vcmppd xmm9, xmm11, xmm11, 0x03
0000705c0addf874  ptest xmm9, xmm9
0000705c0addf87a  jnz 0x0000705C0ADE3D1A
0000705c0addf880  lea r12, [rax+0x70]
0000705c0addf884  movups xmm14, [r13+r12*1]
0000705c0addf88a  movaps [r15+0x240], xmm14
0000705c0addf892  movaps xmm10, xmm1
0000705c0addf896  addpd xmm10, xmm12
0000705c0addf89b  vcmppd xmm9, xmm10, xmm10, 0x03
0000705c0addf8a1  ptest xmm9, xmm9
0000705c0addf8a7  jnz 0x0000705C0ADE3E68
0000705c0addf8ad  movaps [r15+0x170], xmm10
0000705c0addf8b5  vmovaps xmm1, [rsp+0x20]
0000705c0addf8bb  vpermilpd xmm1, xmm1, 0x00
0000705c0addf8c1  movaps xmm12, xmm14
0000705c0addf8c5  mulpd xmm12, xmm1
0000705c0addf8ca  vcmppd xmm9, xmm12, xmm12, 0x03
0000705c0addf8d0  ptest xmm9, xmm9
0000705c0addf8d6  jnz 0x0000705C0ADE3FAB
0000705c0addf8dc  vmovaps xmm1, [rsp+0x20]
0000705c0addf8e2  vpermilpd xmm1, xmm1, 0x00
0000705c0addf8e8  vmovaps xmm9, [rsp+0xB0]
0000705c0addf8f1  movaps xmm14, xmm9
0000705c0addf8f5  mulpd xmm14, xmm1
0000705c0addf8fa  vcmppd xmm6, xmm14, xmm14, 0x03
0000705c0addf900  ptest xmm6, xmm6
0000705c0addf905  jnz 0x0000705C0ADE40EE
0000705c0addf90b  movaps [r15+0x180], xmm14
0000705c0addf913  movaps xmm1, xmm13
0000705c0addf917  addpd xmm1, xmm8
0000705c0addf91c  vcmppd xmm9, xmm1, xmm1, 0x03
0000705c0addf921  ptest xmm9, xmm9
0000705c0addf927  jnz 0x0000705C0ADE4231
0000705c0addf92d  movaps [r15+0x210], xmm1
0000705c0addf935  movups xmm13, [r13+rax*1]
0000705c0addf93b  lea r12, [rax+0x10]
0000705c0addf93f  movups xmm9, [r13+r12*1]
0000705c0addf945  movaps [r15+0x230], xmm9
0000705c0addf94d  movaps xmm8, xmm15
0000705c0addf951  addpd xmm8, xmm7
0000705c0addf956  vcmppd xmm6, xmm8, xmm8, 0x03
0000705c0addf95c  ptest xmm6, xmm6
0000705c0addf961  jnz 0x0000705C0ADE4387
0000705c0addf967  movaps [r15+0x130], xmm8
0000705c0addf96f  vmovaps xmm15, [rsp+0x20]
0000705c0addf975  vpermilpd xmm15, xmm15, 0x00
0000705c0addf97b  movaps xmm7, xmm9
0000705c0addf97f  mulpd xmm7, xmm15
0000705c0addf984  vcmppd xmm6, xmm7, xmm7, 0x03
0000705c0addf989  ptest xmm6, xmm6
0000705c0addf98e  jnz 0x0000705C0ADE44CA
0000705c0addf994  movaps [r15+0x220], xmm7
0000705c0addf99c  vmovaps xmm15, [rsp+0x20]
0000705c0addf9a2  vpermilpd xmm15, xmm15, 0x00
0000705c0addf9a8  movaps xmm9, xmm13
0000705c0addf9ac  mulpd xmm9, xmm15
0000705c0addf9b1  vcmppd xmm6, xmm9, xmm9, 0x03
0000705c0addf9b7  ptest xmm6, xmm6
0000705c0addf9bc  jnz 0x0000705C0ADE460C
0000705c0addf9c2  movaps xmm15, xmm11
0000705c0addf9c6  addpd xmm15, xmm12
0000705c0addf9cb  vcmppd xmm13, xmm15, xmm15, 0x03
0000705c0addf9d1  ptest xmm13, xmm13
0000705c0addf9d7  jnz 0x0000705C0ADE4750
0000705c0addf9dd  movaps [r15+0x140], xmm15
0000705c0addf9e5  movaps xmm13, xmm10
0000705c0addf9e9  addpd xmm13, xmm14
0000705c0addf9ee  vcmppd xmm12, xmm13, xmm13, 0x03
0000705c0addf9f4  ptest xmm12, xmm12
0000705c0addf9fa  jnz 0x0000705C0ADE4894
0000705c0addfa00  movaps [r15+0x150], xmm13
0000705c0addfa08  movaps xmm14, xmm1
0000705c0addfa0c  addpd xmm14, xmm7
0000705c0addfa11  vcmppd xmm12, xmm14, xmm14, 0x03
0000705c0addfa17  ptest xmm12, xmm12
0000705c0addfa1d  jnz 0x0000705C0ADE49D8
0000705c0addfa23  movaps [r15+0x160], xmm14
0000705c0addfa2b  movaps xmm1, xmm8
0000705c0addfa2f  addpd xmm1, xmm9
0000705c0addfa34  vcmppd xmm12, xmm1, xmm1, 0x03
0000705c0addfa39  ptest xmm12, xmm12
0000705c0addfa3f  jnz 0x0000705C0ADE4B1A
0000705c0addfa45  movaps [r15+0x120], xmm1
0000705c0addfa4d  movups [r13+r14*1], xmm15
0000705c0addfa53  lea rax, [r14+0x10]
0000705c0addfa57  movups [r13+rax*1], xmm13
0000705c0addfa5d  lea rax, [r14+0x20]
0000705c0addfa61  movups [r13+rax*1], xmm14
0000705c0addfa67  lea rax, [r14+0x30]
0000705c0addfa6b  movups [r13+rax*1], xmm1
0000705c0addfa71  mov eax, [r15+0x108]
0000705c0addfa78  sahf
0000705c0addfa79  jnz 0x0000705C0ADDFAAB
0000705c0addfa7b  cmp dword ptr [r15+0x318], 0x00
0000705c0addfa83  jz 0x0000705C0ADDEAE0
0000705c0addfa89  nop [rax+rax*1], ax
0000705c0addfa92  nop [rax+rax*1], eax
0000705c0addfa9a  mov eax, 0x4106D0
0000705c0addfa9f  mov [r15+0x100], rax
0000705c0addfaa6  jmp 0x0000705C0ABFE110
0000705c0addfaab  cmp dword ptr [r15+0x318], 0x00
0000705c0addfab3  jz 0x0000705C0ADD89C0
0000705c0addfab9  nop [rax+rax*1], ax
0000705c0addfac2  nop [rax+rax*1], eax
0000705c0addfaca  mov eax, 0x410504
0000705c0addfacf  mov [r15+0x100], rax
0000705c0addfad6  jmp 0x0000705C0ABFE110
0000705c0addfadb  int3
0000705c0addfadc  call 0x0000705C0ACE27E0
0000705c0addfae1  jmp 0x0000705C0ADDEBBF
0000705c0addfae6  call 0x0000705C0ACE1570
0000705c0addfaeb  jmp 0x0000705C0ADDEBC8
0000705c0addfaf0  call 0x0000705C0ACE27E0
0000705c0addfaf5  jmp 0x0000705C0ADDEC24
0000705c0addfafa  call 0x0000705C0ACE1570
0000705c0addfaff  jmp 0x0000705C0ADDEC2D
0000705c0addfb04  call 0x0000705C0ACE27E0
0000705c0addfb09  jmp 0x0000705C0ADDEC70
0000705c0addfb0e  call 0x0000705C0ACE1570
0000705c0addfb13  jmp 0x0000705C0ADDEC79
0000705c0addfb18  call 0x0000705C0AC0DC20
0000705c0addfb1d  jmp 0x0000705C0ADDECB8
0000705c0addfb22  call 0x0000705C0ACD59C0
0000705c0addfb27  jmp 0x0000705C0ADDECCB
0000705c0addfb2c  call 0x0000705C0ACE0E30
0000705c0addfb31  jmp 0x0000705C0ADDECE9
0000705c0addfb36  call 0x0000705C0ACDFBC0
0000705c0addfb3b  jmp 0x0000705C0ADDECF3
0000705c0addfb40  call 0x0000705C0ACDE950
0000705c0addfb45  jmp 0x0000705C0ADDECFD
0000705c0addfb4a  sub rsp, 0x08
0000705c0addfb4e  push rax
0000705c0addfb4f  push rcx
0000705c0addfb50  push rdx
0000705c0addfb51  push rdi
0000705c0addfb52  push rsi
0000705c0addfb53  push r8
0000705c0addfb55  push r9
0000705c0addfb57  push r10
0000705c0addfb59  push r11
0000705c0addfb5b  sub rsp, 0xF0
0000705c0addfb62  vmovaps [rsp], xmm0
0000705c0addfb67  vmovaps [rsp+0x10], xmm1
0000705c0addfb6d  vmovaps [rsp+0x20], xmm2
0000705c0addfb73  vmovaps [rsp+0x30], xmm3
0000705c0addfb79  vmovaps [rsp+0x40], xmm4
0000705c0addfb7f  vmovaps [rsp+0x50], xmm5
0000705c0addfb85  vmovaps [rsp+0x60], xmm6
0000705c0addfb8b  vmovaps [rsp+0x70], xmm7
0000705c0addfb91  vmovaps [rsp+0x80], xmm9
0000705c0addfb9a  vmovaps [rsp+0x90], xmm10
0000705c0addfba3  vmovaps [rsp+0xA0], xmm11
0000705c0addfbac  vmovaps [rsp+0xB0], xmm12
0000705c0addfbb5  vmovaps [rsp+0xC0], xmm13
0000705c0addfbbe  vmovaps [rsp+0xD0], xmm14
0000705c0addfbc7  vmovaps [rsp+0xE0], xmm15
0000705c0addfbd0  sub rsp, 0x30
0000705c0addfbd4  movaps [rsp], xmm8
0000705c0addfbd9  movaps [rsp+0x10], xmm12
0000705c0addfbdf  movaps [rsp+0x20], xmm15
0000705c0addfbe5  lea rdi, [rsp]
0000705c0addfbe9  mov esi, 0x00
0000705c0addfbee  mov rax, 0x5969C28C4530
0000705c0addfbf8  call rax
0000705c0addfbfa  movaps xmm8, [rsp]
0000705c0addfbff  add rsp, 0x30
0000705c0addfc03  vmovaps xmm0, [rsp]
0000705c0addfc08  vmovaps xmm1, [rsp+0x10]
0000705c0addfc0e  vmovaps xmm2, [rsp+0x20]
0000705c0addfc14  vmovaps xmm3, [rsp+0x30]
0000705c0addfc1a  vmovaps xmm4, [rsp+0x40]
0000705c0addfc20  vmovaps xmm5, [rsp+0x50]
0000705c0addfc26  vmovaps xmm6, [rsp+0x60]
0000705c0addfc2c  vmovaps xmm7, [rsp+0x70]
0000705c0addfc32  vmovaps xmm9, [rsp+0x80]
0000705c0addfc3b  vmovaps xmm10, [rsp+0x90]
0000705c0addfc44  vmovaps xmm11, [rsp+0xA0]
0000705c0addfc4d  vmovaps xmm12, [rsp+0xB0]
0000705c0addfc56  vmovaps xmm13, [rsp+0xC0]
0000705c0addfc5f  vmovaps xmm14, [rsp+0xD0]
0000705c0addfc68  vmovaps xmm15, [rsp+0xE0]
0000705c0addfc71  add rsp, 0xF0
0000705c0addfc78  pop r11
0000705c0addfc7a  pop r10
0000705c0addfc7c  pop r9
0000705c0addfc7e  pop r8
0000705c0addfc80  pop rsi
0000705c0addfc81  pop rdi
0000705c0addfc82  pop rdx
0000705c0addfc83  pop rcx
0000705c0addfc84  pop rax
0000705c0addfc85  add rsp, 0x08
0000705c0addfc89  jmp 0x0000705C0ADDED27
0000705c0addfc8e  sub rsp, 0x08
0000705c0addfc92  push rax
0000705c0addfc93  push rcx
0000705c0addfc94  push rdx
0000705c0addfc95  push rdi
0000705c0addfc96  push rsi
0000705c0addfc97  push r8
0000705c0addfc99  push r9
0000705c0addfc9b  push r10
0000705c0addfc9d  push r11
0000705c0addfc9f  sub rsp, 0xF0
0000705c0addfca6  vmovaps [rsp], xmm0
0000705c0addfcab  vmovaps [rsp+0x10], xmm1
0000705c0addfcb1  vmovaps [rsp+0x20], xmm2
0000705c0addfcb7  vmovaps [rsp+0x30], xmm3
0000705c0addfcbd  vmovaps [rsp+0x40], xmm4
0000705c0addfcc3  vmovaps [rsp+0x50], xmm5
0000705c0addfcc9  vmovaps [rsp+0x60], xmm6
0000705c0addfccf  vmovaps [rsp+0x70], xmm8
0000705c0addfcd5  vmovaps [rsp+0x80], xmm9
0000705c0addfcde  vmovaps [rsp+0x90], xmm10
0000705c0addfce7  vmovaps [rsp+0xA0], xmm11
0000705c0addfcf0  vmovaps [rsp+0xB0], xmm12
0000705c0addfcf9  vmovaps [rsp+0xC0], xmm13
0000705c0addfd02  vmovaps [rsp+0xD0], xmm14
0000705c0addfd0b  vmovaps [rsp+0xE0], xmm15
0000705c0addfd14  sub rsp, 0x30
0000705c0addfd18  movaps [rsp], xmm7
0000705c0addfd1c  movaps [rsp+0x10], xmm9
0000705c0addfd22  movaps [rsp+0x20], xmm15
0000705c0addfd28  lea rdi, [rsp]
0000705c0addfd2c  mov esi, 0x00
0000705c0addfd31  mov rax, 0x5969C28C4530
0000705c0addfd3b  call rax
0000705c0addfd3d  movaps xmm7, [rsp]
0000705c0addfd41  add rsp, 0x30
0000705c0addfd45  vmovaps xmm0, [rsp]
0000705c0addfd4a  vmovaps xmm1, [rsp+0x10]
0000705c0addfd50  vmovaps xmm2, [rsp+0x20]
0000705c0addfd56  vmovaps xmm3, [rsp+0x30]
0000705c0addfd5c  vmovaps xmm4, [rsp+0x40]
0000705c0addfd62  vmovaps xmm5, [rsp+0x50]
0000705c0addfd68  vmovaps xmm6, [rsp+0x60]
0000705c0addfd6e  vmovaps xmm8, [rsp+0x70]
0000705c0addfd74  vmovaps xmm9, [rsp+0x80]
0000705c0addfd7d  vmovaps xmm10, [rsp+0x90]
0000705c0addfd86  vmovaps xmm11, [rsp+0xA0]
0000705c0addfd8f  vmovaps xmm12, [rsp+0xB0]
0000705c0addfd98  vmovaps xmm13, [rsp+0xC0]
0000705c0addfda1  vmovaps xmm14, [rsp+0xD0]
0000705c0addfdaa  vmovaps xmm15, [rsp+0xE0]
0000705c0addfdb3  add rsp, 0xF0
0000705c0addfdba  pop r11
0000705c0addfdbc  pop r10
0000705c0addfdbe  pop r9
0000705c0addfdc0  pop r8
0000705c0addfdc2  pop rsi
0000705c0addfdc3  pop rdi
0000705c0addfdc4  pop rdx
0000705c0addfdc5  pop rcx
0000705c0addfdc6  pop rax
0000705c0addfdc7  add rsp, 0x08
0000705c0addfdcb  jmp 0x0000705C0ADDED55
0000705c0addfdd0  sub rsp, 0x08
0000705c0addfdd4  push rax
0000705c0addfdd5  push rcx
0000705c0addfdd6  push rdx
0000705c0addfdd7  push rdi
0000705c0addfdd8  push rsi
0000705c0addfdd9  push r8
0000705c0addfddb  push r9
0000705c0addfddd  push r10
0000705c0addfddf  push r11
0000705c0addfde1  sub rsp, 0xF0
0000705c0addfde8  vmovaps [rsp], xmm0
0000705c0addfded  vmovaps [rsp+0x10], xmm1
0000705c0addfdf3  vmovaps [rsp+0x20], xmm2
0000705c0addfdf9  vmovaps [rsp+0x30], xmm3
0000705c0addfdff  vmovaps [rsp+0x40], xmm4
0000705c0addfe05  vmovaps [rsp+0x50], xmm5
0000705c0addfe0b  vmovaps [rsp+0x60], xmm6
0000705c0addfe11  vmovaps [rsp+0x70], xmm7
0000705c0addfe17  vmovaps [rsp+0x80], xmm8
0000705c0addfe20  vmovaps [rsp+0x90], xmm10
0000705c0addfe29  vmovaps [rsp+0xA0], xmm11
0000705c0addfe32  vmovaps [rsp+0xB0], xmm12
0000705c0addfe3b  vmovaps [rsp+0xC0], xmm13
0000705c0addfe44  vmovaps [rsp+0xD0], xmm14
0000705c0addfe4d  vmovaps [rsp+0xE0], xmm15
0000705c0addfe56  sub rsp, 0x30
0000705c0addfe5a  movaps [rsp], xmm9
0000705c0addfe5f  movaps [rsp+0x10], xmm12
0000705c0addfe65  movaps [rsp+0x20], xmm10
0000705c0addfe6b  lea rdi, [rsp]
0000705c0addfe6f  mov esi, 0x00
0000705c0addfe74  mov rax, 0x5969C28C4530
0000705c0addfe7e  call rax
0000705c0addfe80  movaps xmm9, [rsp]
0000705c0addfe85  add rsp, 0x30
0000705c0addfe89  vmovaps xmm0, [rsp]
0000705c0addfe8e  vmovaps xmm1, [rsp+0x10]
0000705c0addfe94  vmovaps xmm2, [rsp+0x20]
0000705c0addfe9a  vmovaps xmm3, [rsp+0x30]
0000705c0addfea0  vmovaps xmm4, [rsp+0x40]
0000705c0addfea6  vmovaps xmm5, [rsp+0x50]
0000705c0addfeac  vmovaps xmm6, [rsp+0x60]
0000705c0addfeb2  vmovaps xmm7, [rsp+0x70]
0000705c0addfeb8  vmovaps xmm8, [rsp+0x80]
0000705c0addfec1  vmovaps xmm10, [rsp+0x90]
0000705c0addfeca  vmovaps xmm11, [rsp+0xA0]
0000705c0addfed3  vmovaps xmm12, [rsp+0xB0]
0000705c0addfedc  vmovaps xmm13, [rsp+0xC0]
0000705c0addfee5  vmovaps xmm14, [rsp+0xD0]
0000705c0addfeee  vmovaps xmm15, [rsp+0xE0]
0000705c0addfef7  add rsp, 0xF0
0000705c0addfefe  pop r11
0000705c0addff00  pop r10
0000705c0addff02  pop r9
0000705c0addff04  pop r8
0000705c0addff06  pop rsi
0000705c0addff07  pop rdi
0000705c0addff08  pop rdx
0000705c0addff09  pop rcx
0000705c0addff0a  pop rax
0000705c0addff0b  add rsp, 0x08
0000705c0addff0f  jmp 0x0000705C0ADDED79
0000705c0addff14  sub rsp, 0x08
0000705c0addff18  push rax
0000705c0addff19  push rcx
0000705c0addff1a  push rdx
0000705c0addff1b  push rdi
0000705c0addff1c  push rsi
0000705c0addff1d  push r8
0000705c0addff1f  push r9
0000705c0addff21  push r10
0000705c0addff23  push r11
0000705c0addff25  sub rsp, 0xF0
0000705c0addff2c  vmovaps [rsp], xmm0
0000705c0addff31  vmovaps [rsp+0x10], xmm1
0000705c0addff37  vmovaps [rsp+0x20], xmm2
0000705c0addff3d  vmovaps [rsp+0x30], xmm3
0000705c0addff43  vmovaps [rsp+0x40], xmm4
0000705c0addff49  vmovaps [rsp+0x50], xmm5
0000705c0addff4f  vmovaps [rsp+0x60], xmm6
0000705c0addff55  vmovaps [rsp+0x70], xmm7
0000705c0addff5b  vmovaps [rsp+0x80], xmm8
0000705c0addff64  vmovaps [rsp+0x90], xmm9
0000705c0addff6d  vmovaps [rsp+0xA0], xmm11
0000705c0addff76  vmovaps [rsp+0xB0], xmm12
0000705c0addff7f  vmovaps [rsp+0xC0], xmm13
0000705c0addff88  vmovaps [rsp+0xD0], xmm14
0000705c0addff91  vmovaps [rsp+0xE0], xmm15
0000705c0addff9a  sub rsp, 0x30
0000705c0addff9e  movaps [rsp], xmm10
0000705c0addffa3  movaps [rsp+0x10], xmm12
0000705c0addffa9  movaps [rsp+0x20], xmm11
0000705c0addffaf  lea rdi, [rsp]
0000705c0addffb3  mov esi, 0x00
0000705c0addffb8  mov rax, 0x5969C28C4530
0000705c0addffc2  call rax
0000705c0addffc4  movaps xmm10, [rsp]
0000705c0addffc9  add rsp, 0x30
0000705c0addffcd  vmovaps xmm0, [rsp]
0000705c0addffd2  vmovaps xmm1, [rsp+0x10]
0000705c0addffd8  vmovaps xmm2, [rsp+0x20]
0000705c0addffde  vmovaps xmm3, [rsp+0x30]
0000705c0addffe4  vmovaps xmm4, [rsp+0x40]
0000705c0addffea  vmovaps xmm5, [rsp+0x50]
0000705c0addfff0  vmovaps xmm6, [rsp+0x60]
0000705c0addfff6  vmovaps xmm7, [rsp+0x70]
0000705c0addfffc  vmovaps xmm8, [rsp+0x80]
0000705c0ade0005  vmovaps xmm9, [rsp+0x90]
0000705c0ade000e  vmovaps xmm11, [rsp+0xA0]
0000705c0ade0017  vmovaps xmm12, [rsp+0xB0]
0000705c0ade0020  vmovaps xmm13, [rsp+0xC0]
0000705c0ade0029  vmovaps xmm14, [rsp+0xD0]
0000705c0ade0032  vmovaps xmm15, [rsp+0xE0]
0000705c0ade003b  add rsp, 0xF0
0000705c0ade0042  pop r11
0000705c0ade0044  pop r10
0000705c0ade0046  pop r9
0000705c0ade0048  pop r8
0000705c0ade004a  pop rsi
0000705c0ade004b  pop rdi
0000705c0ade004c  pop rdx
0000705c0ade004d  pop rcx
0000705c0ade004e  pop rax
0000705c0ade004f  add rsp, 0x08
0000705c0ade0053  jmp 0x0000705C0ADDED93
0000705c0ade0058  sub rsp, 0x08
0000705c0ade005c  push rax
0000705c0ade005d  push rcx
0000705c0ade005e  push rdx
0000705c0ade005f  push rdi
0000705c0ade0060  push rsi
0000705c0ade0061  push r8
0000705c0ade0063  push r9
0000705c0ade0065  push r10
0000705c0ade0067  push r11
0000705c0ade0069  sub rsp, 0xF0
0000705c0ade0070  vmovaps [rsp], xmm0
0000705c0ade0075  vmovaps [rsp+0x10], xmm1
0000705c0ade007b  vmovaps [rsp+0x20], xmm2
0000705c0ade0081  vmovaps [rsp+0x30], xmm3
0000705c0ade0087  vmovaps [rsp+0x40], xmm4
0000705c0ade008d  vmovaps [rsp+0x50], xmm5
0000705c0ade0093  vmovaps [rsp+0x60], xmm7
0000705c0ade0099  vmovaps [rsp+0x70], xmm8
0000705c0ade009f  vmovaps [rsp+0x80], xmm9
0000705c0ade00a8  vmovaps [rsp+0x90], xmm10
0000705c0ade00b1  vmovaps [rsp+0xA0], xmm11
0000705c0ade00ba  vmovaps [rsp+0xB0], xmm12
0000705c0ade00c3  vmovaps [rsp+0xC0], xmm13
0000705c0ade00cc  vmovaps [rsp+0xD0], xmm14
0000705c0ade00d5  vmovaps [rsp+0xE0], xmm15
0000705c0ade00de  sub rsp, 0x30
0000705c0ade00e2  movaps [rsp], xmm6
0000705c0ade00e6  movaps [rsp+0x10], xmm12
0000705c0ade00ec  movaps [rsp+0x20], xmm11
0000705c0ade00f2  lea rdi, [rsp]
0000705c0ade00f6  mov esi, 0x00
0000705c0ade00fb  mov rax, 0x5969C28C4530
0000705c0ade0105  call rax
0000705c0ade0107  movaps xmm6, [rsp]
0000705c0ade010b  add rsp, 0x30
0000705c0ade010f  vmovaps xmm0, [rsp]
0000705c0ade0114  vmovaps xmm1, [rsp+0x10]
0000705c0ade011a  vmovaps xmm2, [rsp+0x20]
0000705c0ade0120  vmovaps xmm3, [rsp+0x30]
0000705c0ade0126  vmovaps xmm4, [rsp+0x40]
0000705c0ade012c  vmovaps xmm5, [rsp+0x50]
0000705c0ade0132  vmovaps xmm7, [rsp+0x60]
0000705c0ade0138  vmovaps xmm8, [rsp+0x70]
0000705c0ade013e  vmovaps xmm9, [rsp+0x80]
0000705c0ade0147  vmovaps xmm10, [rsp+0x90]
0000705c0ade0150  vmovaps xmm11, [rsp+0xA0]
0000705c0ade0159  vmovaps xmm12, [rsp+0xB0]
0000705c0ade0162  vmovaps xmm13, [rsp+0xC0]
0000705c0ade016b  vmovaps xmm14, [rsp+0xD0]
0000705c0ade0174  vmovaps xmm15, [rsp+0xE0]
0000705c0ade017d  add rsp, 0xF0
0000705c0ade0184  pop r11
0000705c0ade0186  pop r10
0000705c0ade0188  pop r9
0000705c0ade018a  pop r8
0000705c0ade018c  pop rsi
0000705c0ade018d  pop rdi
0000705c0ade018e  pop rdx
0000705c0ade018f  pop rcx
0000705c0ade0190  pop rax
0000705c0ade0191  add rsp, 0x08
0000705c0ade0195  jmp 0x0000705C0ADDEDB4
0000705c0ade019a  sub rsp, 0x08
0000705c0ade019e  push rax
0000705c0ade019f  push rcx
0000705c0ade01a0  push rdx
0000705c0ade01a1  push rdi
0000705c0ade01a2  push rsi
0000705c0ade01a3  push r8
0000705c0ade01a5  push r9
0000705c0ade01a7  push r10
0000705c0ade01a9  push r11
0000705c0ade01ab  sub rsp, 0xF0
0000705c0ade01b2  vmovaps [rsp], xmm0
0000705c0ade01b7  vmovaps [rsp+0x10], xmm1
0000705c0ade01bd  vmovaps [rsp+0x20], xmm2
0000705c0ade01c3  vmovaps [rsp+0x30], xmm4
0000705c0ade01c9  vmovaps [rsp+0x40], xmm5
0000705c0ade01cf  vmovaps [rsp+0x50], xmm6
0000705c0ade01d5  vmovaps [rsp+0x60], xmm7
0000705c0ade01db  vmovaps [rsp+0x70], xmm8
0000705c0ade01e1  vmovaps [rsp+0x80], xmm9
0000705c0ade01ea  vmovaps [rsp+0x90], xmm10
0000705c0ade01f3  vmovaps [rsp+0xA0], xmm11
0000705c0ade01fc  vmovaps [rsp+0xB0], xmm12
0000705c0ade0205  vmovaps [rsp+0xC0], xmm13
0000705c0ade020e  vmovaps [rsp+0xD0], xmm14
0000705c0ade0217  vmovaps [rsp+0xE0], xmm15
0000705c0ade0220  sub rsp, 0x30
0000705c0ade0224  movaps [rsp], xmm3
0000705c0ade0228  movaps [rsp+0x10], xmm5
0000705c0ade022d  movaps [rsp+0x20], xmm4
0000705c0ade0232  lea rdi, [rsp]
0000705c0ade0236  mov esi, 0x00
0000705c0ade023b  mov rax, 0x5969C28C4530
0000705c0ade0245  call rax
0000705c0ade0247  movaps xmm3, [rsp]
0000705c0ade024b  add rsp, 0x30
0000705c0ade024f  vmovaps xmm0, [rsp]
0000705c0ade0254  vmovaps xmm1, [rsp+0x10]
0000705c0ade025a  vmovaps xmm2, [rsp+0x20]
0000705c0ade0260  vmovaps xmm4, [rsp+0x30]
0000705c0ade0266  vmovaps xmm5, [rsp+0x40]
0000705c0ade026c  vmovaps xmm6, [rsp+0x50]
0000705c0ade0272  vmovaps xmm7, [rsp+0x60]
0000705c0ade0278  vmovaps xmm8, [rsp+0x70]
0000705c0ade027e  vmovaps xmm9, [rsp+0x80]
0000705c0ade0287  vmovaps xmm10, [rsp+0x90]
0000705c0ade0290  vmovaps xmm11, [rsp+0xA0]
0000705c0ade0299  vmovaps xmm12, [rsp+0xB0]
0000705c0ade02a2  vmovaps xmm13, [rsp+0xC0]
0000705c0ade02ab  vmovaps xmm14, [rsp+0xD0]
0000705c0ade02b4  vmovaps xmm15, [rsp+0xE0]
0000705c0ade02bd  add rsp, 0xF0
0000705c0ade02c4  pop r11
0000705c0ade02c6  pop r10
0000705c0ade02c8  pop r9
0000705c0ade02ca  pop r8
0000705c0ade02cc  pop rsi
0000705c0ade02cd  pop rdi
0000705c0ade02ce  pop rdx
0000705c0ade02cf  pop rcx
0000705c0ade02d0  pop rax
0000705c0ade02d1  add rsp, 0x08
0000705c0ade02d5  jmp 0x0000705C0ADDEE15
0000705c0ade02da  sub rsp, 0x08
0000705c0ade02de  push rax
0000705c0ade02df  push rcx
0000705c0ade02e0  push rdx
0000705c0ade02e1  push rdi
0000705c0ade02e2  push rsi
0000705c0ade02e3  push r8
0000705c0ade02e5  push r9
0000705c0ade02e7  push r10
0000705c0ade02e9  push r11
0000705c0ade02eb  sub rsp, 0xF0
0000705c0ade02f2  vmovaps [rsp], xmm0
0000705c0ade02f7  vmovaps [rsp+0x10], xmm1
0000705c0ade02fd  vmovaps [rsp+0x20], xmm2
0000705c0ade0303  vmovaps [rsp+0x30], xmm3
0000705c0ade0309  vmovaps [rsp+0x40], xmm4
0000705c0ade030f  vmovaps [rsp+0x50], xmm6
0000705c0ade0315  vmovaps [rsp+0x60], xmm7
0000705c0ade031b  vmovaps [rsp+0x70], xmm8
0000705c0ade0321  vmovaps [rsp+0x80], xmm9
0000705c0ade032a  vmovaps [rsp+0x90], xmm10
0000705c0ade0333  vmovaps [rsp+0xA0], xmm11
0000705c0ade033c  vmovaps [rsp+0xB0], xmm12
0000705c0ade0345  vmovaps [rsp+0xC0], xmm13
0000705c0ade034e  vmovaps [rsp+0xD0], xmm14
0000705c0ade0357  vmovaps [rsp+0xE0], xmm15
0000705c0ade0360  sub rsp, 0x30
0000705c0ade0364  movaps [rsp], xmm5
0000705c0ade0368  movaps [rsp+0x10], xmm8
0000705c0ade036e  movaps [rsp+0x20], xmm15
0000705c0ade0374  lea rdi, [rsp]
0000705c0ade0378  mov esi, 0x00
0000705c0ade037d  mov rax, 0x5969C28C4530
0000705c0ade0387  call rax
0000705c0ade0389  movaps xmm5, [rsp]
0000705c0ade038d  add rsp, 0x30
0000705c0ade0391  vmovaps xmm0, [rsp]
0000705c0ade0396  vmovaps xmm1, [rsp+0x10]
0000705c0ade039c  vmovaps xmm2, [rsp+0x20]
0000705c0ade03a2  vmovaps xmm3, [rsp+0x30]
0000705c0ade03a8  vmovaps xmm4, [rsp+0x40]
0000705c0ade03ae  vmovaps xmm6, [rsp+0x50]
0000705c0ade03b4  vmovaps xmm7, [rsp+0x60]
0000705c0ade03ba  vmovaps xmm8, [rsp+0x70]
0000705c0ade03c0  vmovaps xmm9, [rsp+0x80]
0000705c0ade03c9  vmovaps xmm10, [rsp+0x90]
0000705c0ade03d2  vmovaps xmm11, [rsp+0xA0]
0000705c0ade03db  vmovaps xmm12, [rsp+0xB0]
0000705c0ade03e4  vmovaps xmm13, [rsp+0xC0]
0000705c0ade03ed  vmovaps xmm14, [rsp+0xD0]
0000705c0ade03f6  vmovaps xmm15, [rsp+0xE0]
0000705c0ade03ff  add rsp, 0xF0
0000705c0ade0406  pop r11
0000705c0ade0408  pop r10
0000705c0ade040a  pop r9
0000705c0ade040c  pop r8
0000705c0ade040e  pop rsi
0000705c0ade040f  pop rdi
0000705c0ade0410  pop rdx
0000705c0ade0411  pop rcx
0000705c0ade0412  pop rax
0000705c0ade0413  add rsp, 0x08
0000705c0ade0417  jmp 0x0000705C0ADDEE53
0000705c0ade041c  sub rsp, 0x08
0000705c0ade0420  push rax
0000705c0ade0421  push rcx
0000705c0ade0422  push rdx
0000705c0ade0423  push rdi
0000705c0ade0424  push rsi
0000705c0ade0425  push r8
0000705c0ade0427  push r9
0000705c0ade0429  push r10
0000705c0ade042b  push r11
0000705c0ade042d  sub rsp, 0xF0
0000705c0ade0434  vmovaps [rsp], xmm0
0000705c0ade0439  vmovaps [rsp+0x10], xmm1
0000705c0ade043f  vmovaps [rsp+0x20], xmm2
0000705c0ade0445  vmovaps [rsp+0x30], xmm3
0000705c0ade044b  vmovaps [rsp+0x40], xmm5
0000705c0ade0451  vmovaps [rsp+0x50], xmm6
0000705c0ade0457  vmovaps [rsp+0x60], xmm7
0000705c0ade045d  vmovaps [rsp+0x70], xmm8
0000705c0ade0463  vmovaps [rsp+0x80], xmm9
0000705c0ade046c  vmovaps [rsp+0x90], xmm10
0000705c0ade0475  vmovaps [rsp+0xA0], xmm11
0000705c0ade047e  vmovaps [rsp+0xB0], xmm12
0000705c0ade0487  vmovaps [rsp+0xC0], xmm13
0000705c0ade0490  vmovaps [rsp+0xD0], xmm14
0000705c0ade0499  vmovaps [rsp+0xE0], xmm15
0000705c0ade04a2  sub rsp, 0x30
0000705c0ade04a6  movaps [rsp], xmm4
0000705c0ade04aa  movaps [rsp+0x10], xmm9
0000705c0ade04b0  movaps [rsp+0x20], xmm8
0000705c0ade04b6  lea rdi, [rsp]
0000705c0ade04ba  mov esi, 0x00
0000705c0ade04bf  mov rax, 0x5969C28C4530
0000705c0ade04c9  call rax
0000705c0ade04cb  movaps xmm4, [rsp]
0000705c0ade04cf  add rsp, 0x30
0000705c0ade04d3  vmovaps xmm0, [rsp]
0000705c0ade04d8  vmovaps xmm1, [rsp+0x10]
0000705c0ade04de  vmovaps xmm2, [rsp+0x20]
0000705c0ade04e4  vmovaps xmm3, [rsp+0x30]
0000705c0ade04ea  vmovaps xmm5, [rsp+0x40]
0000705c0ade04f0  vmovaps xmm6, [rsp+0x50]
0000705c0ade04f6  vmovaps xmm7, [rsp+0x60]
0000705c0ade04fc  vmovaps xmm8, [rsp+0x70]
0000705c0ade0502  vmovaps xmm9, [rsp+0x80]
0000705c0ade050b  vmovaps xmm10, [rsp+0x90]
0000705c0ade0514  vmovaps xmm11, [rsp+0xA0]
0000705c0ade051d  vmovaps xmm12, [rsp+0xB0]
0000705c0ade0526  vmovaps xmm13, [rsp+0xC0]
0000705c0ade052f  vmovaps xmm14, [rsp+0xD0]
0000705c0ade0538  vmovaps xmm15, [rsp+0xE0]
0000705c0ade0541  add rsp, 0xF0
0000705c0ade0548  pop r11
0000705c0ade054a  pop r10
0000705c0ade054c  pop r9
0000705c0ade054e  pop r8
0000705c0ade0550  pop rsi
0000705c0ade0551  pop rdi
0000705c0ade0552  pop rdx
0000705c0ade0553  pop rcx
0000705c0ade0554  pop rax
0000705c0ade0555  add rsp, 0x08
0000705c0ade0559  jmp 0x0000705C0ADDEE74
0000705c0ade055e  sub rsp, 0x08
0000705c0ade0562  push rax
0000705c0ade0563  push rcx
0000705c0ade0564  push rdx
0000705c0ade0565  push rdi
0000705c0ade0566  push rsi
0000705c0ade0567  push r8
0000705c0ade0569  push r9
0000705c0ade056b  push r10
0000705c0ade056d  push r11
0000705c0ade056f  sub rsp, 0xF0
0000705c0ade0576  vmovaps [rsp], xmm0
0000705c0ade057b  vmovaps [rsp+0x10], xmm1
0000705c0ade0581  vmovaps [rsp+0x20], xmm2
0000705c0ade0587  vmovaps [rsp+0x30], xmm3
0000705c0ade058d  vmovaps [rsp+0x40], xmm4
0000705c0ade0593  vmovaps [rsp+0x50], xmm5
0000705c0ade0599  vmovaps [rsp+0x60], xmm6
0000705c0ade059f  vmovaps [rsp+0x70], xmm7
0000705c0ade05a5  vmovaps [rsp+0x80], xmm8
0000705c0ade05ae  vmovaps [rsp+0x90], xmm10
0000705c0ade05b7  vmovaps [rsp+0xA0], xmm11
0000705c0ade05c0  vmovaps [rsp+0xB0], xmm12
0000705c0ade05c9  vmovaps [rsp+0xC0], xmm13
0000705c0ade05d2  vmovaps [rsp+0xD0], xmm14
0000705c0ade05db  vmovaps [rsp+0xE0], xmm15
0000705c0ade05e4  sub rsp, 0x30
0000705c0ade05e8  movaps [rsp], xmm9
0000705c0ade05ed  movaps [rsp+0x10], xmm10
0000705c0ade05f3  movaps [rsp+0x20], xmm8
0000705c0ade05f9  lea rdi, [rsp]
0000705c0ade05fd  mov esi, 0x00
0000705c0ade0602  mov rax, 0x5969C28C4530
0000705c0ade060c  call rax
0000705c0ade060e  movaps xmm9, [rsp]
0000705c0ade0613  add rsp, 0x30
0000705c0ade0617  vmovaps xmm0, [rsp]
0000705c0ade061c  vmovaps xmm1, [rsp+0x10]
0000705c0ade0622  vmovaps xmm2, [rsp+0x20]
0000705c0ade0628  vmovaps xmm3, [rsp+0x30]
0000705c0ade062e  vmovaps xmm4, [rsp+0x40]
0000705c0ade0634  vmovaps xmm5, [rsp+0x50]
0000705c0ade063a  vmovaps xmm6, [rsp+0x60]
0000705c0ade0640  vmovaps xmm7, [rsp+0x70]
0000705c0ade0646  vmovaps xmm8, [rsp+0x80]
0000705c0ade064f  vmovaps xmm10, [rsp+0x90]
0000705c0ade0658  vmovaps xmm11, [rsp+0xA0]
0000705c0ade0661  vmovaps xmm12, [rsp+0xB0]
0000705c0ade066a  vmovaps xmm13, [rsp+0xC0]
0000705c0ade0673  vmovaps xmm14, [rsp+0xD0]
0000705c0ade067c  vmovaps xmm15, [rsp+0xE0]
0000705c0ade0685  add rsp, 0xF0
0000705c0ade068c  pop r11
0000705c0ade068e  pop r10
0000705c0ade0690  pop r9
0000705c0ade0692  pop r8
0000705c0ade0694  pop rsi
0000705c0ade0695  pop rdi
0000705c0ade0696  pop rdx
0000705c0ade0697  pop rcx
0000705c0ade0698  pop rax
0000705c0ade0699  add rsp, 0x08
0000705c0ade069d  jmp 0x0000705C0ADDEE8E
0000705c0ade06a2  call 0x0000705C0ACB52F0
0000705c0ade06a7  jmp 0x0000705C0ADDEFA8
0000705c0ade06ac  call 0x0000705C0ACB52F0
0000705c0ade06b1  jmp 0x0000705C0ADDEFBE
0000705c0ade06b6  sub rsp, 0x08
0000705c0ade06ba  push rax
0000705c0ade06bb  push rcx
0000705c0ade06bc  push rdx
0000705c0ade06bd  push rdi
0000705c0ade06be  push rsi
0000705c0ade06bf  push r8
0000705c0ade06c1  push r9
0000705c0ade06c3  push r10
0000705c0ade06c5  push r11
0000705c0ade06c7  sub rsp, 0xF0
0000705c0ade06ce  vmovaps [rsp], xmm0
0000705c0ade06d3  vmovaps [rsp+0x10], xmm2
0000705c0ade06d9  vmovaps [rsp+0x20], xmm3
0000705c0ade06df  vmovaps [rsp+0x30], xmm4
0000705c0ade06e5  vmovaps [rsp+0x40], xmm5
0000705c0ade06eb  vmovaps [rsp+0x50], xmm6
0000705c0ade06f1  vmovaps [rsp+0x60], xmm7
0000705c0ade06f7  vmovaps [rsp+0x70], xmm8
0000705c0ade06fd  vmovaps [rsp+0x80], xmm9
0000705c0ade0706  vmovaps [rsp+0x90], xmm10
0000705c0ade070f  vmovaps [rsp+0xA0], xmm11
0000705c0ade0718  vmovaps [rsp+0xB0], xmm12
0000705c0ade0721  vmovaps [rsp+0xC0], xmm13
0000705c0ade072a  vmovaps [rsp+0xD0], xmm14
0000705c0ade0733  vmovaps [rsp+0xE0], xmm15
0000705c0ade073c  sub rsp, 0x30
0000705c0ade0740  movaps [rsp], xmm1
0000705c0ade0744  movaps [rsp+0x10], xmm6
0000705c0ade0749  movaps [rsp+0x20], xmm15
0000705c0ade074f  lea rdi, [rsp]
0000705c0ade0753  mov esi, 0x00
0000705c0ade0758  mov rax, 0x5969C28C4530
0000705c0ade0762  call rax
0000705c0ade0764  movaps xmm1, [rsp]
0000705c0ade0768  add rsp, 0x30
0000705c0ade076c  vmovaps xmm0, [rsp]
0000705c0ade0771  vmovaps xmm2, [rsp+0x10]
0000705c0ade0777  vmovaps xmm3, [rsp+0x20]
0000705c0ade077d  vmovaps xmm4, [rsp+0x30]
0000705c0ade0783  vmovaps xmm5, [rsp+0x40]
0000705c0ade0789  vmovaps xmm6, [rsp+0x50]
0000705c0ade078f  vmovaps xmm7, [rsp+0x60]
0000705c0ade0795  vmovaps xmm8, [rsp+0x70]
0000705c0ade079b  vmovaps xmm9, [rsp+0x80]
0000705c0ade07a4  vmovaps xmm10, [rsp+0x90]
0000705c0ade07ad  vmovaps xmm11, [rsp+0xA0]
0000705c0ade07b6  vmovaps xmm12, [rsp+0xB0]
0000705c0ade07bf  vmovaps xmm13, [rsp+0xC0]
0000705c0ade07c8  vmovaps xmm14, [rsp+0xD0]
0000705c0ade07d1  vmovaps xmm15, [rsp+0xE0]
0000705c0ade07da  add rsp, 0xF0
0000705c0ade07e1  pop r11
0000705c0ade07e3  pop r10
0000705c0ade07e5  pop r9
0000705c0ade07e7  pop r8
0000705c0ade07e9  pop rsi
0000705c0ade07ea  pop rdi
0000705c0ade07eb  pop rdx
0000705c0ade07ec  pop rcx
0000705c0ade07ed  pop rax
0000705c0ade07ee  add rsp, 0x08
0000705c0ade07f2  jmp 0x0000705C0ADDEFFB
0000705c0ade07f7  call 0x0000705C0ACC4620
0000705c0ade07fc  jmp 0x0000705C0ADDF008
0000705c0ade0801  sub rsp, 0x08
0000705c0ade0805  push rax
0000705c0ade0806  push rcx
0000705c0ade0807  push rdx
0000705c0ade0808  push rdi
0000705c0ade0809  push rsi
0000705c0ade080a  push r8
0000705c0ade080c  push r9
0000705c0ade080e  push r10
0000705c0ade0810  push r11
0000705c0ade0812  sub rsp, 0xF0
0000705c0ade0819  vmovaps [rsp], xmm0
0000705c0ade081e  vmovaps [rsp+0x10], xmm1
0000705c0ade0824  vmovaps [rsp+0x20], xmm2
0000705c0ade082a  vmovaps [rsp+0x30], xmm3
0000705c0ade0830  vmovaps [rsp+0x40], xmm4
0000705c0ade0836  vmovaps [rsp+0x50], xmm5
0000705c0ade083c  vmovaps [rsp+0x60], xmm6
0000705c0ade0842  vmovaps [rsp+0x70], xmm7
0000705c0ade0848  vmovaps [rsp+0x80], xmm8
0000705c0ade0851  vmovaps [rsp+0x90], xmm9
0000705c0ade085a  vmovaps [rsp+0xA0], xmm10
0000705c0ade0863  vmovaps [rsp+0xB0], xmm11
0000705c0ade086c  vmovaps [rsp+0xC0], xmm12
0000705c0ade0875  vmovaps [rsp+0xD0], xmm13
0000705c0ade087e  vmovaps [rsp+0xE0], xmm15
0000705c0ade0887  sub rsp, 0x30
0000705c0ade088b  movaps [rsp], xmm14
0000705c0ade0890  movaps [rsp+0x10], xmm4
0000705c0ade0895  movaps [rsp+0x20], xmm3
0000705c0ade089a  lea rdi, [rsp]
0000705c0ade089e  mov esi, 0x00
0000705c0ade08a3  mov rax, 0x5969C28C4530
0000705c0ade08ad  call rax
0000705c0ade08af  movaps xmm14, [rsp]
0000705c0ade08b4  add rsp, 0x30
0000705c0ade08b8  vmovaps xmm0, [rsp]
0000705c0ade08bd  vmovaps xmm1, [rsp+0x10]
0000705c0ade08c3  vmovaps xmm2, [rsp+0x20]
0000705c0ade08c9  vmovaps xmm3, [rsp+0x30]
0000705c0ade08cf  vmovaps xmm4, [rsp+0x40]
0000705c0ade08d5  vmovaps xmm5, [rsp+0x50]
0000705c0ade08db  vmovaps xmm6, [rsp+0x60]
0000705c0ade08e1  vmovaps xmm7, [rsp+0x70]
0000705c0ade08e7  vmovaps xmm8, [rsp+0x80]
0000705c0ade08f0  vmovaps xmm9, [rsp+0x90]
0000705c0ade08f9  vmovaps xmm10, [rsp+0xA0]
0000705c0ade0902  vmovaps xmm11, [rsp+0xB0]
0000705c0ade090b  vmovaps xmm12, [rsp+0xC0]
0000705c0ade0914  vmovaps xmm13, [rsp+0xD0]
0000705c0ade091d  vmovaps xmm15, [rsp+0xE0]
0000705c0ade0926  add rsp, 0xF0
0000705c0ade092d  pop r11
0000705c0ade092f  pop r10
0000705c0ade0931  pop r9
0000705c0ade0933  pop r8
0000705c0ade0935  pop rsi
0000705c0ade0936  pop rdi
0000705c0ade0937  pop rdx
0000705c0ade0938  pop rcx
0000705c0ade0939  pop rax
0000705c0ade093a  add rsp, 0x08
0000705c0ade093e  jmp 0x0000705C0ADDF022
0000705c0ade0943  sub rsp, 0x08
0000705c0ade0947  push rax
0000705c0ade0948  push rcx
0000705c0ade0949  push rdx
0000705c0ade094a  push rdi
0000705c0ade094b  push rsi
0000705c0ade094c  push r8
0000705c0ade094e  push r9
0000705c0ade0950  push r10
0000705c0ade0952  push r11
0000705c0ade0954  sub rsp, 0xF0
0000705c0ade095b  vmovaps [rsp], xmm0
0000705c0ade0960  vmovaps [rsp+0x10], xmm1
0000705c0ade0966  vmovaps [rsp+0x20], xmm2
0000705c0ade096c  vmovaps [rsp+0x30], xmm3
0000705c0ade0972  vmovaps [rsp+0x40], xmm4
0000705c0ade0978  vmovaps [rsp+0x50], xmm5
0000705c0ade097e  vmovaps [rsp+0x60], xmm7
0000705c0ade0984  vmovaps [rsp+0x70], xmm8
0000705c0ade098a  vmovaps [rsp+0x80], xmm9
0000705c0ade0993  vmovaps [rsp+0x90], xmm10
0000705c0ade099c  vmovaps [rsp+0xA0], xmm11
0000705c0ade09a5  vmovaps [rsp+0xB0], xmm12
0000705c0ade09ae  vmovaps [rsp+0xC0], xmm13
0000705c0ade09b7  vmovaps [rsp+0xD0], xmm14
0000705c0ade09c0  vmovaps [rsp+0xE0], xmm15
0000705c0ade09c9  sub rsp, 0x30
0000705c0ade09cd  movaps [rsp], xmm6
0000705c0ade09d1  movaps [rsp+0x10], xmm9
0000705c0ade09d7  movaps [rsp+0x20], xmm7
0000705c0ade09dc  lea rdi, [rsp]
0000705c0ade09e0  mov esi, 0x00
0000705c0ade09e5  mov rax, 0x5969C28C4530
0000705c0ade09ef  call rax
0000705c0ade09f1  movaps xmm6, [rsp]
0000705c0ade09f5  add rsp, 0x30
0000705c0ade09f9  vmovaps xmm0, [rsp]
0000705c0ade09fe  vmovaps xmm1, [rsp+0x10]
0000705c0ade0a04  vmovaps xmm2, [rsp+0x20]
0000705c0ade0a0a  vmovaps xmm3, [rsp+0x30]
0000705c0ade0a10  vmovaps xmm4, [rsp+0x40]
0000705c0ade0a16  vmovaps xmm5, [rsp+0x50]
0000705c0ade0a1c  vmovaps xmm7, [rsp+0x60]
0000705c0ade0a22  vmovaps xmm8, [rsp+0x70]
0000705c0ade0a28  vmovaps xmm9, [rsp+0x80]
0000705c0ade0a31  vmovaps xmm10, [rsp+0x90]
0000705c0ade0a3a  vmovaps xmm11, [rsp+0xA0]
0000705c0ade0a43  vmovaps xmm12, [rsp+0xB0]
0000705c0ade0a4c  vmovaps xmm13, [rsp+0xC0]
0000705c0ade0a55  vmovaps xmm14, [rsp+0xD0]
0000705c0ade0a5e  vmovaps xmm15, [rsp+0xE0]
0000705c0ade0a67  add rsp, 0xF0
0000705c0ade0a6e  pop r11
0000705c0ade0a70  pop r10
0000705c0ade0a72  pop r9
0000705c0ade0a74  pop r8
0000705c0ade0a76  pop rsi
0000705c0ade0a77  pop rdi
0000705c0ade0a78  pop rdx
0000705c0ade0a79  pop rcx
0000705c0ade0a7a  pop rax
0000705c0ade0a7b  add rsp, 0x08
0000705c0ade0a7f  jmp 0x0000705C0ADDF03A
0000705c0ade0a84  sub rsp, 0x08
0000705c0ade0a88  push rax
0000705c0ade0a89  push rcx
0000705c0ade0a8a  push rdx
0000705c0ade0a8b  push rdi
0000705c0ade0a8c  push rsi
0000705c0ade0a8d  push r8
0000705c0ade0a8f  push r9
0000705c0ade0a91  push r10
0000705c0ade0a93  push r11
0000705c0ade0a95  sub rsp, 0xF0
0000705c0ade0a9c  vmovaps [rsp], xmm0
0000705c0ade0aa1  vmovaps [rsp+0x10], xmm1
0000705c0ade0aa7  vmovaps [rsp+0x20], xmm2
0000705c0ade0aad  vmovaps [rsp+0x30], xmm3
0000705c0ade0ab3  vmovaps [rsp+0x40], xmm4
0000705c0ade0ab9  vmovaps [rsp+0x50], xmm5
0000705c0ade0abf  vmovaps [rsp+0x60], xmm6
0000705c0ade0ac5  vmovaps [rsp+0x70], xmm8
0000705c0ade0acb  vmovaps [rsp+0x80], xmm9
0000705c0ade0ad4  vmovaps [rsp+0x90], xmm10
0000705c0ade0add  vmovaps [rsp+0xA0], xmm11
0000705c0ade0ae6  vmovaps [rsp+0xB0], xmm12
0000705c0ade0aef  vmovaps [rsp+0xC0], xmm13
0000705c0ade0af8  vmovaps [rsp+0xD0], xmm14
0000705c0ade0b01  vmovaps [rsp+0xE0], xmm15
0000705c0ade0b0a  sub rsp, 0x30
0000705c0ade0b0e  movaps [rsp], xmm7
0000705c0ade0b12  movaps [rsp+0x10], xmm4
0000705c0ade0b17  movaps [rsp+0x20], xmm9
0000705c0ade0b1d  lea rdi, [rsp]
0000705c0ade0b21  mov esi, 0x00
0000705c0ade0b26  mov rax, 0x5969C28C4530
0000705c0ade0b30  call rax
0000705c0ade0b32  movaps xmm7, [rsp]
0000705c0ade0b36  add rsp, 0x30
0000705c0ade0b3a  vmovaps xmm0, [rsp]
0000705c0ade0b3f  vmovaps xmm1, [rsp+0x10]
0000705c0ade0b45  vmovaps xmm2, [rsp+0x20]
0000705c0ade0b4b  vmovaps xmm3, [rsp+0x30]
0000705c0ade0b51  vmovaps xmm4, [rsp+0x40]
0000705c0ade0b57  vmovaps xmm5, [rsp+0x50]
0000705c0ade0b5d  vmovaps xmm6, [rsp+0x60]
0000705c0ade0b63  vmovaps xmm8, [rsp+0x70]
0000705c0ade0b69  vmovaps xmm9, [rsp+0x80]
0000705c0ade0b72  vmovaps xmm10, [rsp+0x90]
0000705c0ade0b7b  vmovaps xmm11, [rsp+0xA0]
0000705c0ade0b84  vmovaps xmm12, [rsp+0xB0]
0000705c0ade0b8d  vmovaps xmm13, [rsp+0xC0]
0000705c0ade0b96  vmovaps xmm14, [rsp+0xD0]
0000705c0ade0b9f  vmovaps xmm15, [rsp+0xE0]
0000705c0ade0ba8  add rsp, 0xF0
0000705c0ade0baf  pop r11
0000705c0ade0bb1  pop r10
0000705c0ade0bb3  pop r9
0000705c0ade0bb5  pop r8
0000705c0ade0bb7  pop rsi
0000705c0ade0bb8  pop rdi
0000705c0ade0bb9  pop rdx
0000705c0ade0bba  pop rcx
0000705c0ade0bbb  pop rax
0000705c0ade0bbc  add rsp, 0x08
0000705c0ade0bc0  jmp 0x0000705C0ADDF067
0000705c0ade0bc5  sub rsp, 0x08
0000705c0ade0bc9  push rax
0000705c0ade0bca  push rcx
0000705c0ade0bcb  push rdx
0000705c0ade0bcc  push rdi
0000705c0ade0bcd  push rsi
0000705c0ade0bce  push r8
0000705c0ade0bd0  push r9
0000705c0ade0bd2  push r10
0000705c0ade0bd4  push r11
0000705c0ade0bd6  sub rsp, 0xF0
0000705c0ade0bdd  vmovaps [rsp], xmm0
0000705c0ade0be2  vmovaps [rsp+0x10], xmm1
0000705c0ade0be8  vmovaps [rsp+0x20], xmm2
0000705c0ade0bee  vmovaps [rsp+0x30], xmm3
0000705c0ade0bf4  vmovaps [rsp+0x40], xmm5
0000705c0ade0bfa  vmovaps [rsp+0x50], xmm6
0000705c0ade0c00  vmovaps [rsp+0x60], xmm7
0000705c0ade0c06  vmovaps [rsp+0x70], xmm8
0000705c0ade0c0c  vmovaps [rsp+0x80], xmm9
0000705c0ade0c15  vmovaps [rsp+0x90], xmm10
0000705c0ade0c1e  vmovaps [rsp+0xA0], xmm11
0000705c0ade0c27  vmovaps [rsp+0xB0], xmm12
0000705c0ade0c30  vmovaps [rsp+0xC0], xmm13
0000705c0ade0c39  vmovaps [rsp+0xD0], xmm14
0000705c0ade0c42  vmovaps [rsp+0xE0], xmm15
0000705c0ade0c4b  sub rsp, 0x30
0000705c0ade0c4f  movaps [rsp], xmm4
0000705c0ade0c53  movaps [rsp+0x10], xmm15
0000705c0ade0c59  movaps [rsp+0x20], xmm9
0000705c0ade0c5f  lea rdi, [rsp]
0000705c0ade0c63  mov esi, 0x00
0000705c0ade0c68  mov rax, 0x5969C28C4530
0000705c0ade0c72  call rax
0000705c0ade0c74  movaps xmm4, [rsp]
0000705c0ade0c78  add rsp, 0x30
0000705c0ade0c7c  vmovaps xmm0, [rsp]
0000705c0ade0c81  vmovaps xmm1, [rsp+0x10]
0000705c0ade0c87  vmovaps xmm2, [rsp+0x20]
0000705c0ade0c8d  vmovaps xmm3, [rsp+0x30]
0000705c0ade0c93  vmovaps xmm5, [rsp+0x40]
0000705c0ade0c99  vmovaps xmm6, [rsp+0x50]
0000705c0ade0c9f  vmovaps xmm7, [rsp+0x60]
0000705c0ade0ca5  vmovaps xmm8, [rsp+0x70]
0000705c0ade0cab  vmovaps xmm9, [rsp+0x80]
0000705c0ade0cb4  vmovaps xmm10, [rsp+0x90]
0000705c0ade0cbd  vmovaps xmm11, [rsp+0xA0]
0000705c0ade0cc6  vmovaps xmm12, [rsp+0xB0]
0000705c0ade0ccf  vmovaps xmm13, [rsp+0xC0]
0000705c0ade0cd8  vmovaps xmm14, [rsp+0xD0]
0000705c0ade0ce1  vmovaps xmm15, [rsp+0xE0]
0000705c0ade0cea  add rsp, 0xF0
0000705c0ade0cf1  pop r11
0000705c0ade0cf3  pop r10
0000705c0ade0cf5  pop r9
0000705c0ade0cf7  pop r8
0000705c0ade0cf9  pop rsi
0000705c0ade0cfa  pop rdi
0000705c0ade0cfb  pop rdx
0000705c0ade0cfc  pop rcx
0000705c0ade0cfd  pop rax
0000705c0ade0cfe  add rsp, 0x08
0000705c0ade0d02  jmp 0x0000705C0ADDF08C
0000705c0ade0d07  call 0x0000705C0ACC4620
0000705c0ade0d0c  jmp 0x0000705C0ADDF099
0000705c0ade0d11  sub rsp, 0x08
0000705c0ade0d15  push rax
0000705c0ade0d16  push rcx
0000705c0ade0d17  push rdx
0000705c0ade0d18  push rdi
0000705c0ade0d19  push rsi
0000705c0ade0d1a  push r8
0000705c0ade0d1c  push r9
0000705c0ade0d1e  push r10
0000705c0ade0d20  push r11
0000705c0ade0d22  sub rsp, 0xF0
0000705c0ade0d29  vmovaps [rsp], xmm0
0000705c0ade0d2e  vmovaps [rsp+0x10], xmm1
0000705c0ade0d34  vmovaps [rsp+0x20], xmm2
0000705c0ade0d3a  vmovaps [rsp+0x30], xmm4
0000705c0ade0d40  vmovaps [rsp+0x40], xmm5
0000705c0ade0d46  vmovaps [rsp+0x50], xmm6
0000705c0ade0d4c  vmovaps [rsp+0x60], xmm7
0000705c0ade0d52  vmovaps [rsp+0x70], xmm8
0000705c0ade0d58  vmovaps [rsp+0x80], xmm9
0000705c0ade0d61  vmovaps [rsp+0x90], xmm10
0000705c0ade0d6a  vmovaps [rsp+0xA0], xmm11
0000705c0ade0d73  vmovaps [rsp+0xB0], xmm12
0000705c0ade0d7c  vmovaps [rsp+0xC0], xmm13
0000705c0ade0d85  vmovaps [rsp+0xD0], xmm14
0000705c0ade0d8e  vmovaps [rsp+0xE0], xmm15
0000705c0ade0d97  sub rsp, 0x30
0000705c0ade0d9b  movaps [rsp], xmm3
0000705c0ade0d9f  movaps [rsp+0x10], xmm1
0000705c0ade0da4  movaps [rsp+0x20], xmm9
0000705c0ade0daa  lea rdi, [rsp]
0000705c0ade0dae  mov esi, 0x00
0000705c0ade0db3  mov rax, 0x5969C28C4530
0000705c0ade0dbd  call rax
0000705c0ade0dbf  movaps xmm3, [rsp]
0000705c0ade0dc3  add rsp, 0x30
0000705c0ade0dc7  vmovaps xmm0, [rsp]
0000705c0ade0dcc  vmovaps xmm1, [rsp+0x10]
0000705c0ade0dd2  vmovaps xmm2, [rsp+0x20]
0000705c0ade0dd8  vmovaps xmm4, [rsp+0x30]
0000705c0ade0dde  vmovaps xmm5, [rsp+0x40]
0000705c0ade0de4  vmovaps xmm6, [rsp+0x50]
0000705c0ade0dea  vmovaps xmm7, [rsp+0x60]
0000705c0ade0df0  vmovaps xmm8, [rsp+0x70]
0000705c0ade0df6  vmovaps xmm9, [rsp+0x80]
0000705c0ade0dff  vmovaps xmm10, [rsp+0x90]
0000705c0ade0e08  vmovaps xmm11, [rsp+0xA0]
0000705c0ade0e11  vmovaps xmm12, [rsp+0xB0]
0000705c0ade0e1a  vmovaps xmm13, [rsp+0xC0]
0000705c0ade0e23  vmovaps xmm14, [rsp+0xD0]
0000705c0ade0e2c  vmovaps xmm15, [rsp+0xE0]
0000705c0ade0e35  add rsp, 0xF0
0000705c0ade0e3c  pop r11
0000705c0ade0e3e  pop r10
0000705c0ade0e40  pop r9
0000705c0ade0e42  pop r8
0000705c0ade0e44  pop rsi
0000705c0ade0e45  pop rdi
0000705c0ade0e46  pop rdx
0000705c0ade0e47  pop rcx
0000705c0ade0e48  pop rax
0000705c0ade0e49  add rsp, 0x08
0000705c0ade0e4d  jmp 0x0000705C0ADDF0D6
0000705c0ade0e52  sub rsp, 0x08
0000705c0ade0e56  push rax
0000705c0ade0e57  push rcx
0000705c0ade0e58  push rdx
0000705c0ade0e59  push rdi
0000705c0ade0e5a  push rsi
0000705c0ade0e5b  push r8
0000705c0ade0e5d  push r9
0000705c0ade0e5f  push r10
0000705c0ade0e61  push r11
0000705c0ade0e63  sub rsp, 0xF0
0000705c0ade0e6a  vmovaps [rsp], xmm0
0000705c0ade0e6f  vmovaps [rsp+0x10], xmm2
0000705c0ade0e75  vmovaps [rsp+0x20], xmm3
0000705c0ade0e7b  vmovaps [rsp+0x30], xmm4
0000705c0ade0e81  vmovaps [rsp+0x40], xmm5
0000705c0ade0e87  vmovaps [rsp+0x50], xmm6
0000705c0ade0e8d  vmovaps [rsp+0x60], xmm7
0000705c0ade0e93  vmovaps [rsp+0x70], xmm8
0000705c0ade0e99  vmovaps [rsp+0x80], xmm9
0000705c0ade0ea2  vmovaps [rsp+0x90], xmm10
0000705c0ade0eab  vmovaps [rsp+0xA0], xmm11
0000705c0ade0eb4  vmovaps [rsp+0xB0], xmm12
0000705c0ade0ebd  vmovaps [rsp+0xC0], xmm13
0000705c0ade0ec6  vmovaps [rsp+0xD0], xmm14
0000705c0ade0ecf  vmovaps [rsp+0xE0], xmm15
0000705c0ade0ed8  sub rsp, 0x30
0000705c0ade0edc  movaps [rsp], xmm1
0000705c0ade0ee0  movaps [rsp+0x10], xmm15
0000705c0ade0ee6  movaps [rsp+0x20], xmm9
0000705c0ade0eec  lea rdi, [rsp]
0000705c0ade0ef0  mov esi, 0x00
0000705c0ade0ef5  mov rax, 0x5969C28C4530
0000705c0ade0eff  call rax
0000705c0ade0f01  movaps xmm1, [rsp]
0000705c0ade0f05  add rsp, 0x30
0000705c0ade0f09  vmovaps xmm0, [rsp]
0000705c0ade0f0e  vmovaps xmm2, [rsp+0x10]
0000705c0ade0f14  vmovaps xmm3, [rsp+0x20]
0000705c0ade0f1a  vmovaps xmm4, [rsp+0x30]
0000705c0ade0f20  vmovaps xmm5, [rsp+0x40]
0000705c0ade0f26  vmovaps xmm6, [rsp+0x50]
0000705c0ade0f2c  vmovaps xmm7, [rsp+0x60]
0000705c0ade0f32  vmovaps xmm8, [rsp+0x70]
0000705c0ade0f38  vmovaps xmm9, [rsp+0x80]
0000705c0ade0f41  vmovaps xmm10, [rsp+0x90]
0000705c0ade0f4a  vmovaps xmm11, [rsp+0xA0]
0000705c0ade0f53  vmovaps xmm12, [rsp+0xB0]
0000705c0ade0f5c  vmovaps xmm13, [rsp+0xC0]
0000705c0ade0f65  vmovaps xmm14, [rsp+0xD0]
0000705c0ade0f6e  vmovaps xmm15, [rsp+0xE0]
0000705c0ade0f77  add rsp, 0xF0
0000705c0ade0f7e  pop r11
0000705c0ade0f80  pop r10
0000705c0ade0f82  pop r9
0000705c0ade0f84  pop r8
0000705c0ade0f86  pop rsi
0000705c0ade0f87  pop rdi
0000705c0ade0f88  pop rdx
0000705c0ade0f89  pop rcx
0000705c0ade0f8a  pop rax
0000705c0ade0f8b  add rsp, 0x08
0000705c0ade0f8f  jmp 0x0000705C0ADDF15E
0000705c0ade0f94  call 0x0000705C0ACC4620
0000705c0ade0f99  jmp 0x0000705C0ADDF16B
0000705c0ade0f9e  sub rsp, 0x08
0000705c0ade0fa2  push rax
0000705c0ade0fa3  push rcx
0000705c0ade0fa4  push rdx
0000705c0ade0fa5  push rdi
0000705c0ade0fa6  push rsi
0000705c0ade0fa7  push r8
0000705c0ade0fa9  push r9
0000705c0ade0fab  push r10
0000705c0ade0fad  push r11
0000705c0ade0faf  sub rsp, 0xF0
0000705c0ade0fb6  vmovaps [rsp], xmm0
0000705c0ade0fbb  vmovaps [rsp+0x10], xmm2
0000705c0ade0fc1  vmovaps [rsp+0x20], xmm3
0000705c0ade0fc7  vmovaps [rsp+0x30], xmm4
0000705c0ade0fcd  vmovaps [rsp+0x40], xmm5
0000705c0ade0fd3  vmovaps [rsp+0x50], xmm6
0000705c0ade0fd9  vmovaps [rsp+0x60], xmm7
0000705c0ade0fdf  vmovaps [rsp+0x70], xmm8
0000705c0ade0fe5  vmovaps [rsp+0x80], xmm9
0000705c0ade0fee  vmovaps [rsp+0x90], xmm10
0000705c0ade0ff7  vmovaps [rsp+0xA0], xmm11
0000705c0ade1000  vmovaps [rsp+0xB0], xmm12
0000705c0ade1009  vmovaps [rsp+0xC0], xmm13
0000705c0ade1012  vmovaps [rsp+0xD0], xmm14
0000705c0ade101b  vmovaps [rsp+0xE0], xmm15
0000705c0ade1024  sub rsp, 0x30
0000705c0ade1028  movaps [rsp], xmm1
0000705c0ade102c  movaps [rsp+0x10], xmm5
0000705c0ade1031  movaps [rsp+0x20], xmm7
0000705c0ade1036  lea rdi, [rsp]
0000705c0ade103a  mov esi, 0x00
0000705c0ade103f  mov rax, 0x5969C28C4530
0000705c0ade1049  call rax
0000705c0ade104b  movaps xmm1, [rsp]
0000705c0ade104f  add rsp, 0x30
0000705c0ade1053  vmovaps xmm0, [rsp]
0000705c0ade1058  vmovaps xmm2, [rsp+0x10]
0000705c0ade105e  vmovaps xmm3, [rsp+0x20]
0000705c0ade1064  vmovaps xmm4, [rsp+0x30]
0000705c0ade106a  vmovaps xmm5, [rsp+0x40]
0000705c0ade1070  vmovaps xmm6, [rsp+0x50]
0000705c0ade1076  vmovaps xmm7, [rsp+0x60]
0000705c0ade107c  vmovaps xmm8, [rsp+0x70]
0000705c0ade1082  vmovaps xmm9, [rsp+0x80]
0000705c0ade108b  vmovaps xmm10, [rsp+0x90]
0000705c0ade1094  vmovaps xmm11, [rsp+0xA0]
0000705c0ade109d  vmovaps xmm12, [rsp+0xB0]
0000705c0ade10a6  vmovaps xmm13, [rsp+0xC0]
0000705c0ade10af  vmovaps xmm14, [rsp+0xD0]
0000705c0ade10b8  vmovaps xmm15, [rsp+0xE0]
0000705c0ade10c1  add rsp, 0xF0
0000705c0ade10c8  pop r11
0000705c0ade10ca  pop r10
0000705c0ade10cc  pop r9
0000705c0ade10ce  pop r8
0000705c0ade10d0  pop rsi
0000705c0ade10d1  pop rdi
0000705c0ade10d2  pop rdx
0000705c0ade10d3  pop rcx
0000705c0ade10d4  pop rax
0000705c0ade10d5  add rsp, 0x08
0000705c0ade10d9  jmp 0x0000705C0ADDF210
0000705c0ade10de  sub rsp, 0x08
0000705c0ade10e2  push rax
0000705c0ade10e3  push rcx
0000705c0ade10e4  push rdx
0000705c0ade10e5  push rdi
0000705c0ade10e6  push rsi
0000705c0ade10e7  push r8
0000705c0ade10e9  push r9
0000705c0ade10eb  push r10
0000705c0ade10ed  push r11
0000705c0ade10ef  sub rsp, 0xF0
0000705c0ade10f6  vmovaps [rsp], xmm0
0000705c0ade10fb  vmovaps [rsp+0x10], xmm1
0000705c0ade1101  vmovaps [rsp+0x20], xmm2
0000705c0ade1107  vmovaps [rsp+0x30], xmm3
0000705c0ade110d  vmovaps [rsp+0x40], xmm4
0000705c0ade1113  vmovaps [rsp+0x50], xmm5
0000705c0ade1119  vmovaps [rsp+0x60], xmm6
0000705c0ade111f  vmovaps [rsp+0x70], xmm8
0000705c0ade1125  vmovaps [rsp+0x80], xmm9
0000705c0ade112e  vmovaps [rsp+0x90], xmm10
0000705c0ade1137  vmovaps [rsp+0xA0], xmm11
0000705c0ade1140  vmovaps [rsp+0xB0], xmm12
0000705c0ade1149  vmovaps [rsp+0xC0], xmm13
0000705c0ade1152  vmovaps [rsp+0xD0], xmm14
0000705c0ade115b  vmovaps [rsp+0xE0], xmm15
0000705c0ade1164  sub rsp, 0x30
0000705c0ade1168  movaps [rsp], xmm7
0000705c0ade116c  movaps [rsp+0x10], xmm5
0000705c0ade1171  movaps [rsp+0x20], xmm15
0000705c0ade1177  lea rdi, [rsp]
0000705c0ade117b  mov esi, 0x00
0000705c0ade1180  mov rax, 0x5969C28C4530
0000705c0ade118a  call rax
0000705c0ade118c  movaps xmm7, [rsp]
0000705c0ade1190  add rsp, 0x30
0000705c0ade1194  vmovaps xmm0, [rsp]
0000705c0ade1199  vmovaps xmm1, [rsp+0x10]
0000705c0ade119f  vmovaps xmm2, [rsp+0x20]
0000705c0ade11a5  vmovaps xmm3, [rsp+0x30]
0000705c0ade11ab  vmovaps xmm4, [rsp+0x40]
0000705c0ade11b1  vmovaps xmm5, [rsp+0x50]
0000705c0ade11b7  vmovaps xmm6, [rsp+0x60]
0000705c0ade11bd  vmovaps xmm8, [rsp+0x70]
0000705c0ade11c3  vmovaps xmm9, [rsp+0x80]
0000705c0ade11cc  vmovaps xmm10, [rsp+0x90]
0000705c0ade11d5  vmovaps xmm11, [rsp+0xA0]
0000705c0ade11de  vmovaps xmm12, [rsp+0xB0]
0000705c0ade11e7  vmovaps xmm13, [rsp+0xC0]
0000705c0ade11f0  vmovaps xmm14, [rsp+0xD0]
0000705c0ade11f9  vmovaps xmm15, [rsp+0xE0]
0000705c0ade1202  add rsp, 0xF0
0000705c0ade1209  pop r11
0000705c0ade120b  pop r10
0000705c0ade120d  pop r9
0000705c0ade120f  pop r8
0000705c0ade1211  pop rsi
0000705c0ade1212  pop rdi
0000705c0ade1213  pop rdx
0000705c0ade1214  pop rcx
0000705c0ade1215  pop rax
0000705c0ade1216  add rsp, 0x08
0000705c0ade121a  jmp 0x0000705C0ADDF246
0000705c0ade121f  call 0x0000705C0ACB52F0
0000705c0ade1224  jmp 0x0000705C0ADDF253
0000705c0ade1229  sub rsp, 0x08
0000705c0ade122d  push rax
0000705c0ade122e  push rcx
0000705c0ade122f  push rdx
0000705c0ade1230  push rdi
0000705c0ade1231  push rsi
0000705c0ade1232  push r8
0000705c0ade1234  push r9
0000705c0ade1236  push r10
0000705c0ade1238  push r11
0000705c0ade123a  sub rsp, 0xF0
0000705c0ade1241  vmovaps [rsp], xmm0
0000705c0ade1246  vmovaps [rsp+0x10], xmm1
0000705c0ade124c  vmovaps [rsp+0x20], xmm2
0000705c0ade1252  vmovaps [rsp+0x30], xmm3
0000705c0ade1258  vmovaps [rsp+0x40], xmm4
0000705c0ade125e  vmovaps [rsp+0x50], xmm5
0000705c0ade1264  vmovaps [rsp+0x60], xmm6
0000705c0ade126a  vmovaps [rsp+0x70], xmm7
0000705c0ade1270  vmovaps [rsp+0x80], xmm8
0000705c0ade1279  vmovaps [rsp+0x90], xmm9
0000705c0ade1282  vmovaps [rsp+0xA0], xmm10
0000705c0ade128b  vmovaps [rsp+0xB0], xmm11
0000705c0ade1294  vmovaps [rsp+0xC0], xmm12
0000705c0ade129d  vmovaps [rsp+0xD0], xmm13
0000705c0ade12a6  vmovaps [rsp+0xE0], xmm14
0000705c0ade12af  sub rsp, 0x30
0000705c0ade12b3  movaps [rsp], xmm15
0000705c0ade12b8  movaps [rsp+0x10], xmm5
0000705c0ade12bd  movaps [rsp+0x20], xmm3
0000705c0ade12c2  lea rdi, [rsp]
0000705c0ade12c6  mov esi, 0x00
0000705c0ade12cb  mov rax, 0x5969C28C4530
0000705c0ade12d5  call rax
0000705c0ade12d7  movaps xmm15, [rsp]
0000705c0ade12dc  add rsp, 0x30
0000705c0ade12e0  vmovaps xmm0, [rsp]
0000705c0ade12e5  vmovaps xmm1, [rsp+0x10]
0000705c0ade12eb  vmovaps xmm2, [rsp+0x20]
0000705c0ade12f1  vmovaps xmm3, [rsp+0x30]
0000705c0ade12f7  vmovaps xmm4, [rsp+0x40]
0000705c0ade12fd  vmovaps xmm5, [rsp+0x50]
0000705c0ade1303  vmovaps xmm6, [rsp+0x60]
0000705c0ade1309  vmovaps xmm7, [rsp+0x70]
0000705c0ade130f  vmovaps xmm8, [rsp+0x80]
0000705c0ade1318  vmovaps xmm9, [rsp+0x90]
0000705c0ade1321  vmovaps xmm10, [rsp+0xA0]
0000705c0ade132a  vmovaps xmm11, [rsp+0xB0]
0000705c0ade1333  vmovaps xmm12, [rsp+0xC0]
0000705c0ade133c  vmovaps xmm13, [rsp+0xD0]
0000705c0ade1345  vmovaps xmm14, [rsp+0xE0]
0000705c0ade134e  add rsp, 0xF0
0000705c0ade1355  pop r11
0000705c0ade1357  pop r10
0000705c0ade1359  pop r9
0000705c0ade135b  pop r8
0000705c0ade135d  pop rsi
0000705c0ade135e  pop rdi
0000705c0ade135f  pop rdx
0000705c0ade1360  pop rcx
0000705c0ade1361  pop rax
0000705c0ade1362  add rsp, 0x08
0000705c0ade1366  jmp 0x0000705C0ADDF279
0000705c0ade136b  sub rsp, 0x08
0000705c0ade136f  push rax
0000705c0ade1370  push rcx
0000705c0ade1371  push rdx
0000705c0ade1372  push rdi
0000705c0ade1373  push rsi
0000705c0ade1374  push r8
0000705c0ade1376  push r9
0000705c0ade1378  push r10
0000705c0ade137a  push r11
0000705c0ade137c  sub rsp, 0xF0
0000705c0ade1383  vmovaps [rsp], xmm0
0000705c0ade1388  vmovaps [rsp+0x10], xmm2
0000705c0ade138e  vmovaps [rsp+0x20], xmm3
0000705c0ade1394  vmovaps [rsp+0x30], xmm4
0000705c0ade139a  vmovaps [rsp+0x40], xmm5
0000705c0ade13a0  vmovaps [rsp+0x50], xmm6
0000705c0ade13a6  vmovaps [rsp+0x60], xmm7
0000705c0ade13ac  vmovaps [rsp+0x70], xmm8
0000705c0ade13b2  vmovaps [rsp+0x80], xmm9
0000705c0ade13bb  vmovaps [rsp+0x90], xmm10
0000705c0ade13c4  vmovaps [rsp+0xA0], xmm11
0000705c0ade13cd  vmovaps [rsp+0xB0], xmm12
0000705c0ade13d6  vmovaps [rsp+0xC0], xmm13
0000705c0ade13df  vmovaps [rsp+0xD0], xmm14
0000705c0ade13e8  vmovaps [rsp+0xE0], xmm15
0000705c0ade13f1  sub rsp, 0x30
0000705c0ade13f5  movaps [rsp], xmm1
0000705c0ade13f9  movaps [rsp+0x10], xmm5
0000705c0ade13fe  movaps [rsp+0x20], xmm4
0000705c0ade1403  lea rdi, [rsp]
0000705c0ade1407  mov esi, 0x00
0000705c0ade140c  mov rax, 0x5969C28C4530
0000705c0ade1416  call rax
0000705c0ade1418  movaps xmm1, [rsp]
0000705c0ade141c  add rsp, 0x30
0000705c0ade1420  vmovaps xmm0, [rsp]
0000705c0ade1425  vmovaps xmm2, [rsp+0x10]
0000705c0ade142b  vmovaps xmm3, [rsp+0x20]
0000705c0ade1431  vmovaps xmm4, [rsp+0x30]
0000705c0ade1437  vmovaps xmm5, [rsp+0x40]
0000705c0ade143d  vmovaps xmm6, [rsp+0x50]
0000705c0ade1443  vmovaps xmm7, [rsp+0x60]
0000705c0ade1449  vmovaps xmm8, [rsp+0x70]
0000705c0ade144f  vmovaps xmm9, [rsp+0x80]
0000705c0ade1458  vmovaps xmm10, [rsp+0x90]
0000705c0ade1461  vmovaps xmm11, [rsp+0xA0]
0000705c0ade146a  vmovaps xmm12, [rsp+0xB0]
0000705c0ade1473  vmovaps xmm13, [rsp+0xC0]
0000705c0ade147c  vmovaps xmm14, [rsp+0xD0]
0000705c0ade1485  vmovaps xmm15, [rsp+0xE0]
0000705c0ade148e  add rsp, 0xF0
0000705c0ade1495  pop r11
0000705c0ade1497  pop r10
0000705c0ade1499  pop r9
0000705c0ade149b  pop r8
0000705c0ade149d  pop rsi
0000705c0ade149e  pop rdi
0000705c0ade149f  pop rdx
0000705c0ade14a0  pop rcx
0000705c0ade14a1  pop rax
0000705c0ade14a2  add rsp, 0x08
0000705c0ade14a6  jmp 0x0000705C0ADDF299
0000705c0ade14ab  sub rsp, 0x08
0000705c0ade14af  push rax
0000705c0ade14b0  push rcx
0000705c0ade14b1  push rdx
0000705c0ade14b2  push rdi
0000705c0ade14b3  push rsi
0000705c0ade14b4  push r8
0000705c0ade14b6  push r9
0000705c0ade14b8  push r10
0000705c0ade14ba  push r11
0000705c0ade14bc  sub rsp, 0xF0
0000705c0ade14c3  vmovaps [rsp], xmm0
0000705c0ade14c8  vmovaps [rsp+0x10], xmm1
0000705c0ade14ce  vmovaps [rsp+0x20], xmm2
0000705c0ade14d4  vmovaps [rsp+0x30], xmm3
0000705c0ade14da  vmovaps [rsp+0x40], xmm5
0000705c0ade14e0  vmovaps [rsp+0x50], xmm6
0000705c0ade14e6  vmovaps [rsp+0x60], xmm7
0000705c0ade14ec  vmovaps [rsp+0x70], xmm8
0000705c0ade14f2  vmovaps [rsp+0x80], xmm9
0000705c0ade14fb  vmovaps [rsp+0x90], xmm10
0000705c0ade1504  vmovaps [rsp+0xA0], xmm11
0000705c0ade150d  vmovaps [rsp+0xB0], xmm12
0000705c0ade1516  vmovaps [rsp+0xC0], xmm13
0000705c0ade151f  vmovaps [rsp+0xD0], xmm14
0000705c0ade1528  vmovaps [rsp+0xE0], xmm15
0000705c0ade1531  sub rsp, 0x30
0000705c0ade1535  movaps [rsp], xmm4
0000705c0ade1539  movaps [rsp+0x10], xmm3
0000705c0ade153e  movaps [rsp+0x20], xmm5
0000705c0ade1543  lea rdi, [rsp]
0000705c0ade1547  mov esi, 0x00
0000705c0ade154c  mov rax, 0x5969C28C4530
0000705c0ade1556  call rax
0000705c0ade1558  movaps xmm4, [rsp]
0000705c0ade155c  add rsp, 0x30
0000705c0ade1560  vmovaps xmm0, [rsp]
0000705c0ade1565  vmovaps xmm1, [rsp+0x10]
0000705c0ade156b  vmovaps xmm2, [rsp+0x20]
0000705c0ade1571  vmovaps xmm3, [rsp+0x30]
0000705c0ade1577  vmovaps xmm5, [rsp+0x40]
0000705c0ade157d  vmovaps xmm6, [rsp+0x50]
0000705c0ade1583  vmovaps xmm7, [rsp+0x60]
0000705c0ade1589  vmovaps xmm8, [rsp+0x70]
0000705c0ade158f  vmovaps xmm9, [rsp+0x80]
0000705c0ade1598  vmovaps xmm10, [rsp+0x90]
0000705c0ade15a1  vmovaps xmm11, [rsp+0xA0]
0000705c0ade15aa  vmovaps xmm12, [rsp+0xB0]
0000705c0ade15b3  vmovaps xmm13, [rsp+0xC0]
0000705c0ade15bc  vmovaps xmm14, [rsp+0xD0]
0000705c0ade15c5  vmovaps xmm15, [rsp+0xE0]
0000705c0ade15ce  add rsp, 0xF0
0000705c0ade15d5  pop r11
0000705c0ade15d7  pop r10
0000705c0ade15d9  pop r9
0000705c0ade15db  pop r8
0000705c0ade15dd  pop rsi
0000705c0ade15de  pop rdi
0000705c0ade15df  pop rdx
0000705c0ade15e0  pop rcx
0000705c0ade15e1  pop rax
0000705c0ade15e2  add rsp, 0x08
0000705c0ade15e6  jmp 0x0000705C0ADDF2E7
0000705c0ade15eb  call 0x0000705C0ACB52F0
0000705c0ade15f0  jmp 0x0000705C0ADDF2F4
0000705c0ade15f5  sub rsp, 0x08
0000705c0ade15f9  push rax
0000705c0ade15fa  push rcx
0000705c0ade15fb  push rdx
0000705c0ade15fc  push rdi
0000705c0ade15fd  push rsi
0000705c0ade15fe  push r8
0000705c0ade1600  push r9
0000705c0ade1602  push r10
0000705c0ade1604  push r11
0000705c0ade1606  sub rsp, 0xF0
0000705c0ade160d  vmovaps [rsp], xmm0
0000705c0ade1612  vmovaps [rsp+0x10], xmm1
0000705c0ade1618  vmovaps [rsp+0x20], xmm2
0000705c0ade161e  vmovaps [rsp+0x30], xmm3
0000705c0ade1624  vmovaps [rsp+0x40], xmm4
0000705c0ade162a  vmovaps [rsp+0x50], xmm6
0000705c0ade1630  vmovaps [rsp+0x60], xmm7
0000705c0ade1636  vmovaps [rsp+0x70], xmm8
0000705c0ade163c  vmovaps [rsp+0x80], xmm9
0000705c0ade1645  vmovaps [rsp+0x90], xmm10
0000705c0ade164e  vmovaps [rsp+0xA0], xmm11
0000705c0ade1657  vmovaps [rsp+0xB0], xmm12
0000705c0ade1660  vmovaps [rsp+0xC0], xmm13
0000705c0ade1669  vmovaps [rsp+0xD0], xmm14
0000705c0ade1672  vmovaps [rsp+0xE0], xmm15
0000705c0ade167b  sub rsp, 0x30
0000705c0ade167f  movaps [rsp], xmm5
0000705c0ade1683  movaps [rsp+0x10], xmm6
0000705c0ade1688  movaps [rsp+0x20], xmm3
0000705c0ade168d  lea rdi, [rsp]
0000705c0ade1691  mov esi, 0x00
0000705c0ade1696  mov rax, 0x5969C28C4530
0000705c0ade16a0  call rax
0000705c0ade16a2  movaps xmm5, [rsp]
0000705c0ade16a6  add rsp, 0x30
0000705c0ade16aa  vmovaps xmm0, [rsp]
0000705c0ade16af  vmovaps xmm1, [rsp+0x10]
0000705c0ade16b5  vmovaps xmm2, [rsp+0x20]
0000705c0ade16bb  vmovaps xmm3, [rsp+0x30]
0000705c0ade16c1  vmovaps xmm4, [rsp+0x40]
0000705c0ade16c7  vmovaps xmm6, [rsp+0x50]
0000705c0ade16cd  vmovaps xmm7, [rsp+0x60]
0000705c0ade16d3  vmovaps xmm8, [rsp+0x70]
0000705c0ade16d9  vmovaps xmm9, [rsp+0x80]
0000705c0ade16e2  vmovaps xmm10, [rsp+0x90]
0000705c0ade16eb  vmovaps xmm11, [rsp+0xA0]
0000705c0ade16f4  vmovaps xmm12, [rsp+0xB0]
0000705c0ade16fd  vmovaps xmm13, [rsp+0xC0]
0000705c0ade1706  vmovaps xmm14, [rsp+0xD0]
0000705c0ade170f  vmovaps xmm15, [rsp+0xE0]
0000705c0ade1718  add rsp, 0xF0
0000705c0ade171f  pop r11
0000705c0ade1721  pop r10
0000705c0ade1723  pop r9
0000705c0ade1725  pop r8
0000705c0ade1727  pop rsi
0000705c0ade1728  pop rdi
0000705c0ade1729  pop rdx
0000705c0ade172a  pop rcx
0000705c0ade172b  pop rax
0000705c0ade172c  add rsp, 0x08
0000705c0ade1730  jmp 0x0000705C0ADDF31A
0000705c0ade1735  sub rsp, 0x08
0000705c0ade1739  push rax
0000705c0ade173a  push rcx
0000705c0ade173b  push rdx
0000705c0ade173c  push rdi
0000705c0ade173d  push rsi
0000705c0ade173e  push r8
0000705c0ade1740  push r9
0000705c0ade1742  push r10
0000705c0ade1744  push r11
0000705c0ade1746  sub rsp, 0xF0
0000705c0ade174d  vmovaps [rsp], xmm0
0000705c0ade1752  vmovaps [rsp+0x10], xmm1
0000705c0ade1758  vmovaps [rsp+0x20], xmm2
0000705c0ade175e  vmovaps [rsp+0x30], xmm3
0000705c0ade1764  vmovaps [rsp+0x40], xmm4
0000705c0ade176a  vmovaps [rsp+0x50], xmm5
0000705c0ade1770  vmovaps [rsp+0x60], xmm7
0000705c0ade1776  vmovaps [rsp+0x70], xmm8
0000705c0ade177c  vmovaps [rsp+0x80], xmm9
0000705c0ade1785  vmovaps [rsp+0x90], xmm10
0000705c0ade178e  vmovaps [rsp+0xA0], xmm11
0000705c0ade1797  vmovaps [rsp+0xB0], xmm12
0000705c0ade17a0  vmovaps [rsp+0xC0], xmm13
0000705c0ade17a9  vmovaps [rsp+0xD0], xmm14
0000705c0ade17b2  vmovaps [rsp+0xE0], xmm15
0000705c0ade17bb  sub rsp, 0x30
0000705c0ade17bf  movaps [rsp], xmm6
0000705c0ade17c3  movaps [rsp+0x10], xmm9
0000705c0ade17c9  movaps [rsp+0x20], xmm1
0000705c0ade17ce  lea rdi, [rsp]
0000705c0ade17d2  mov esi, 0x00
0000705c0ade17d7  mov rax, 0x5969C28C4530
0000705c0ade17e1  call rax
0000705c0ade17e3  movaps xmm6, [rsp]
0000705c0ade17e7  add rsp, 0x30
0000705c0ade17eb  vmovaps xmm0, [rsp]
0000705c0ade17f0  vmovaps xmm1, [rsp+0x10]
0000705c0ade17f6  vmovaps xmm2, [rsp+0x20]
0000705c0ade17fc  vmovaps xmm3, [rsp+0x30]
0000705c0ade1802  vmovaps xmm4, [rsp+0x40]
0000705c0ade1808  vmovaps xmm5, [rsp+0x50]
0000705c0ade180e  vmovaps xmm7, [rsp+0x60]
0000705c0ade1814  vmovaps xmm8, [rsp+0x70]
0000705c0ade181a  vmovaps xmm9, [rsp+0x80]
0000705c0ade1823  vmovaps xmm10, [rsp+0x90]
0000705c0ade182c  vmovaps xmm11, [rsp+0xA0]
0000705c0ade1835  vmovaps xmm12, [rsp+0xB0]
0000705c0ade183e  vmovaps xmm13, [rsp+0xC0]
0000705c0ade1847  vmovaps xmm14, [rsp+0xD0]
0000705c0ade1850  vmovaps xmm15, [rsp+0xE0]
0000705c0ade1859  add rsp, 0xF0
0000705c0ade1860  pop r11
0000705c0ade1862  pop r10
0000705c0ade1864  pop r9
0000705c0ade1866  pop r8
0000705c0ade1868  pop rsi
0000705c0ade1869  pop rdi
0000705c0ade186a  pop rdx
0000705c0ade186b  pop rcx
0000705c0ade186c  pop rax
0000705c0ade186d  add rsp, 0x08
0000705c0ade1871  jmp 0x0000705C0ADDF33E
0000705c0ade1876  sub rsp, 0x08
0000705c0ade187a  push rax
0000705c0ade187b  push rcx
0000705c0ade187c  push rdx
0000705c0ade187d  push rdi
0000705c0ade187e  push rsi
0000705c0ade187f  push r8
0000705c0ade1881  push r9
0000705c0ade1883  push r10
0000705c0ade1885  push r11
0000705c0ade1887  sub rsp, 0xF0
0000705c0ade188e  vmovaps [rsp], xmm0
0000705c0ade1893  vmovaps [rsp+0x10], xmm1
0000705c0ade1899  vmovaps [rsp+0x20], xmm2
0000705c0ade189f  vmovaps [rsp+0x30], xmm3
0000705c0ade18a5  vmovaps [rsp+0x40], xmm4
0000705c0ade18ab  vmovaps [rsp+0x50], xmm5
0000705c0ade18b1  vmovaps [rsp+0x60], xmm6
0000705c0ade18b7  vmovaps [rsp+0x70], xmm7
0000705c0ade18bd  vmovaps [rsp+0x80], xmm8
0000705c0ade18c6  vmovaps [rsp+0x90], xmm10
0000705c0ade18cf  vmovaps [rsp+0xA0], xmm11
0000705c0ade18d8  vmovaps [rsp+0xB0], xmm12
0000705c0ade18e1  vmovaps [rsp+0xC0], xmm13
0000705c0ade18ea  vmovaps [rsp+0xD0], xmm14
0000705c0ade18f3  vmovaps [rsp+0xE0], xmm15
0000705c0ade18fc  sub rsp, 0x30
0000705c0ade1900  movaps [rsp], xmm9
0000705c0ade1905  movaps [rsp+0x10], xmm3
0000705c0ade190a  movaps [rsp+0x20], xmm1
0000705c0ade190f  lea rdi, [rsp]
0000705c0ade1913  mov esi, 0x00
0000705c0ade1918  mov rax, 0x5969C28C4530
0000705c0ade1922  call rax
0000705c0ade1924  movaps xmm9, [rsp]
0000705c0ade1929  add rsp, 0x30
0000705c0ade192d  vmovaps xmm0, [rsp]
0000705c0ade1932  vmovaps xmm1, [rsp+0x10]
0000705c0ade1938  vmovaps xmm2, [rsp+0x20]
0000705c0ade193e  vmovaps xmm3, [rsp+0x30]
0000705c0ade1944  vmovaps xmm4, [rsp+0x40]
0000705c0ade194a  vmovaps xmm5, [rsp+0x50]
0000705c0ade1950  vmovaps xmm6, [rsp+0x60]
0000705c0ade1956  vmovaps xmm7, [rsp+0x70]
0000705c0ade195c  vmovaps xmm8, [rsp+0x80]
0000705c0ade1965  vmovaps xmm10, [rsp+0x90]
0000705c0ade196e  vmovaps xmm11, [rsp+0xA0]
0000705c0ade1977  vmovaps xmm12, [rsp+0xB0]
0000705c0ade1980  vmovaps xmm13, [rsp+0xC0]
0000705c0ade1989  vmovaps xmm14, [rsp+0xD0]
0000705c0ade1992  vmovaps xmm15, [rsp+0xE0]
0000705c0ade199b  add rsp, 0xF0
0000705c0ade19a2  pop r11
0000705c0ade19a4  pop r10
0000705c0ade19a6  pop r9
0000705c0ade19a8  pop r8
0000705c0ade19aa  pop rsi
0000705c0ade19ab  pop rdi
0000705c0ade19ac  pop rdx
0000705c0ade19ad  pop rcx
0000705c0ade19ae  pop rax
0000705c0ade19af  add rsp, 0x08
0000705c0ade19b3  jmp 0x0000705C0ADDF38A
0000705c0ade19b8  call 0x0000705C0ACB52F0
0000705c0ade19bd  jmp 0x0000705C0ADDF397
0000705c0ade19c2  sub rsp, 0x08
0000705c0ade19c6  push rax
0000705c0ade19c7  push rcx
0000705c0ade19c8  push rdx
0000705c0ade19c9  push rdi
0000705c0ade19ca  push rsi
0000705c0ade19cb  push r8
0000705c0ade19cd  push r9
0000705c0ade19cf  push r10
0000705c0ade19d1  push r11
0000705c0ade19d3  sub rsp, 0xF0
0000705c0ade19da  vmovaps [rsp], xmm0
0000705c0ade19df  vmovaps [rsp+0x10], xmm1
0000705c0ade19e5  vmovaps [rsp+0x20], xmm2
0000705c0ade19eb  vmovaps [rsp+0x30], xmm3
0000705c0ade19f1  vmovaps [rsp+0x40], xmm4
0000705c0ade19f7  vmovaps [rsp+0x50], xmm5
0000705c0ade19fd  vmovaps [rsp+0x60], xmm6
0000705c0ade1a03  vmovaps [rsp+0x70], xmm7
0000705c0ade1a09  vmovaps [rsp+0x80], xmm8
0000705c0ade1a12  vmovaps [rsp+0x90], xmm9
0000705c0ade1a1b  vmovaps [rsp+0xA0], xmm10
0000705c0ade1a24  vmovaps [rsp+0xB0], xmm11
0000705c0ade1a2d  vmovaps [rsp+0xC0], xmm12
0000705c0ade1a36  vmovaps [rsp+0xD0], xmm13
0000705c0ade1a3f  vmovaps [rsp+0xE0], xmm14
0000705c0ade1a48  sub rsp, 0x30
0000705c0ade1a4c  movaps [rsp], xmm15
0000705c0ade1a51  movaps [rsp+0x10], xmm3
0000705c0ade1a56  movaps [rsp+0x20], xmm7
0000705c0ade1a5b  lea rdi, [rsp]
0000705c0ade1a5f  mov esi, 0x00
0000705c0ade1a64  mov rax, 0x5969C28C4530
0000705c0ade1a6e  call rax
0000705c0ade1a70  movaps xmm15, [rsp]
0000705c0ade1a75  add rsp, 0x30
0000705c0ade1a79  vmovaps xmm0, [rsp]
0000705c0ade1a7e  vmovaps xmm1, [rsp+0x10]
0000705c0ade1a84  vmovaps xmm2, [rsp+0x20]
0000705c0ade1a8a  vmovaps xmm3, [rsp+0x30]
0000705c0ade1a90  vmovaps xmm4, [rsp+0x40]
0000705c0ade1a96  vmovaps xmm5, [rsp+0x50]
0000705c0ade1a9c  vmovaps xmm6, [rsp+0x60]
0000705c0ade1aa2  vmovaps xmm7, [rsp+0x70]
0000705c0ade1aa8  vmovaps xmm8, [rsp+0x80]
0000705c0ade1ab1  vmovaps xmm9, [rsp+0x90]
0000705c0ade1aba  vmovaps xmm10, [rsp+0xA0]
0000705c0ade1ac3  vmovaps xmm11, [rsp+0xB0]
0000705c0ade1acc  vmovaps xmm12, [rsp+0xC0]
0000705c0ade1ad5  vmovaps xmm13, [rsp+0xD0]
0000705c0ade1ade  vmovaps xmm14, [rsp+0xE0]
0000705c0ade1ae7  add rsp, 0xF0
0000705c0ade1aee  pop r11
0000705c0ade1af0  pop r10
0000705c0ade1af2  pop r9
0000705c0ade1af4  pop r8
0000705c0ade1af6  pop rsi
0000705c0ade1af7  pop rdi
0000705c0ade1af8  pop rdx
0000705c0ade1af9  pop rcx
0000705c0ade1afa  pop rax
0000705c0ade1afb  add rsp, 0x08
0000705c0ade1aff  jmp 0x0000705C0ADDF3C3
0000705c0ade1b04  sub rsp, 0x08
0000705c0ade1b08  push rax
0000705c0ade1b09  push rcx
0000705c0ade1b0a  push rdx
0000705c0ade1b0b  push rdi
0000705c0ade1b0c  push rsi
0000705c0ade1b0d  push r8
0000705c0ade1b0f  push r9
0000705c0ade1b11  push r10
0000705c0ade1b13  push r11
0000705c0ade1b15  sub rsp, 0xF0
0000705c0ade1b1c  vmovaps [rsp], xmm0
0000705c0ade1b21  vmovaps [rsp+0x10], xmm1
0000705c0ade1b27  vmovaps [rsp+0x20], xmm2
0000705c0ade1b2d  vmovaps [rsp+0x30], xmm4
0000705c0ade1b33  vmovaps [rsp+0x40], xmm5
0000705c0ade1b39  vmovaps [rsp+0x50], xmm6
0000705c0ade1b3f  vmovaps [rsp+0x60], xmm7
0000705c0ade1b45  vmovaps [rsp+0x70], xmm8
0000705c0ade1b4b  vmovaps [rsp+0x80], xmm9
0000705c0ade1b54  vmovaps [rsp+0x90], xmm10
0000705c0ade1b5d  vmovaps [rsp+0xA0], xmm11
0000705c0ade1b66  vmovaps [rsp+0xB0], xmm12
0000705c0ade1b6f  vmovaps [rsp+0xC0], xmm13
0000705c0ade1b78  vmovaps [rsp+0xD0], xmm14
0000705c0ade1b81  vmovaps [rsp+0xE0], xmm15
0000705c0ade1b8a  sub rsp, 0x30
0000705c0ade1b8e  movaps [rsp], xmm3
0000705c0ade1b92  movaps [rsp+0x10], xmm1
0000705c0ade1b97  movaps [rsp+0x20], xmm15
0000705c0ade1b9d  lea rdi, [rsp]
0000705c0ade1ba1  mov esi, 0x00
0000705c0ade1ba6  mov rax, 0x5969C28C4530
0000705c0ade1bb0  call rax
0000705c0ade1bb2  movaps xmm3, [rsp]
0000705c0ade1bb6  add rsp, 0x30
0000705c0ade1bba  vmovaps xmm0, [rsp]
0000705c0ade1bbf  vmovaps xmm1, [rsp+0x10]
0000705c0ade1bc5  vmovaps xmm2, [rsp+0x20]
0000705c0ade1bcb  vmovaps xmm4, [rsp+0x30]
0000705c0ade1bd1  vmovaps xmm5, [rsp+0x40]
0000705c0ade1bd7  vmovaps xmm6, [rsp+0x50]
0000705c0ade1bdd  vmovaps xmm7, [rsp+0x60]
0000705c0ade1be3  vmovaps xmm8, [rsp+0x70]
0000705c0ade1be9  vmovaps xmm9, [rsp+0x80]
0000705c0ade1bf2  vmovaps xmm10, [rsp+0x90]
0000705c0ade1bfb  vmovaps xmm11, [rsp+0xA0]
0000705c0ade1c04  vmovaps xmm12, [rsp+0xB0]
0000705c0ade1c0d  vmovaps xmm13, [rsp+0xC0]
0000705c0ade1c16  vmovaps xmm14, [rsp+0xD0]
0000705c0ade1c1f  vmovaps xmm15, [rsp+0xE0]
0000705c0ade1c28  add rsp, 0xF0
0000705c0ade1c2f  pop r11
0000705c0ade1c31  pop r10
0000705c0ade1c33  pop r9
0000705c0ade1c35  pop r8
0000705c0ade1c37  pop rsi
0000705c0ade1c38  pop rdi
0000705c0ade1c39  pop rdx
0000705c0ade1c3a  pop rcx
0000705c0ade1c3b  pop rax
0000705c0ade1c3c  add rsp, 0x08
0000705c0ade1c40  jmp 0x0000705C0ADDF452
0000705c0ade1c45  call 0x0000705C0ACB52F0
0000705c0ade1c4a  jmp 0x0000705C0ADDF45C
0000705c0ade1c4f  sub rsp, 0x08
0000705c0ade1c53  push rax
0000705c0ade1c54  push rcx
0000705c0ade1c55  push rdx
0000705c0ade1c56  push rdi
0000705c0ade1c57  push rsi
0000705c0ade1c58  push r8
0000705c0ade1c5a  push r9
0000705c0ade1c5c  push r10
0000705c0ade1c5e  push r11
0000705c0ade1c60  sub rsp, 0xF0
0000705c0ade1c67  vmovaps [rsp], xmm0
0000705c0ade1c6c  vmovaps [rsp+0x10], xmm1
0000705c0ade1c72  vmovaps [rsp+0x20], xmm2
0000705c0ade1c78  vmovaps [rsp+0x30], xmm3
0000705c0ade1c7e  vmovaps [rsp+0x40], xmm4
0000705c0ade1c84  vmovaps [rsp+0x50], xmm5
0000705c0ade1c8a  vmovaps [rsp+0x60], xmm6
0000705c0ade1c90  vmovaps [rsp+0x70], xmm7
0000705c0ade1c96  vmovaps [rsp+0x80], xmm8
0000705c0ade1c9f  vmovaps [rsp+0x90], xmm9
0000705c0ade1ca8  vmovaps [rsp+0xA0], xmm10
0000705c0ade1cb1  vmovaps [rsp+0xB0], xmm11
0000705c0ade1cba  vmovaps [rsp+0xC0], xmm12
0000705c0ade1cc3  vmovaps [rsp+0xD0], xmm13
0000705c0ade1ccc  vmovaps [rsp+0xE0], xmm14
0000705c0ade1cd5  sub rsp, 0x30
0000705c0ade1cd9  movaps [rsp], xmm15
0000705c0ade1cde  movaps [rsp+0x10], xmm14
0000705c0ade1ce4  movaps [rsp+0x20], xmm4
0000705c0ade1ce9  lea rdi, [rsp]
0000705c0ade1ced  mov esi, 0x00
0000705c0ade1cf2  mov rax, 0x5969C28C4530
0000705c0ade1cfc  call rax
0000705c0ade1cfe  movaps xmm15, [rsp]
0000705c0ade1d03  add rsp, 0x30
0000705c0ade1d07  vmovaps xmm0, [rsp]
0000705c0ade1d0c  vmovaps xmm1, [rsp+0x10]
0000705c0ade1d12  vmovaps xmm2, [rsp+0x20]
0000705c0ade1d18  vmovaps xmm3, [rsp+0x30]
0000705c0ade1d1e  vmovaps xmm4, [rsp+0x40]
0000705c0ade1d24  vmovaps xmm5, [rsp+0x50]
0000705c0ade1d2a  vmovaps xmm6, [rsp+0x60]
0000705c0ade1d30  vmovaps xmm7, [rsp+0x70]
0000705c0ade1d36  vmovaps xmm8, [rsp+0x80]
0000705c0ade1d3f  vmovaps xmm9, [rsp+0x90]
0000705c0ade1d48  vmovaps xmm10, [rsp+0xA0]
0000705c0ade1d51  vmovaps xmm11, [rsp+0xB0]
0000705c0ade1d5a  vmovaps xmm12, [rsp+0xC0]
0000705c0ade1d63  vmovaps xmm13, [rsp+0xD0]
0000705c0ade1d6c  vmovaps xmm14, [rsp+0xE0]
0000705c0ade1d75  add rsp, 0xF0
0000705c0ade1d7c  pop r11
0000705c0ade1d7e  pop r10
0000705c0ade1d80  pop r9
0000705c0ade1d82  pop r8
0000705c0ade1d84  pop rsi
0000705c0ade1d85  pop rdi
0000705c0ade1d86  pop rdx
0000705c0ade1d87  pop rcx
0000705c0ade1d88  pop rax
0000705c0ade1d89  add rsp, 0x08
0000705c0ade1d8d  jmp 0x0000705C0ADDF48A
0000705c0ade1d92  sub rsp, 0x08
0000705c0ade1d96  push rax
0000705c0ade1d97  push rcx
0000705c0ade1d98  push rdx
0000705c0ade1d99  push rdi
0000705c0ade1d9a  push rsi
0000705c0ade1d9b  push r8
0000705c0ade1d9d  push r9
0000705c0ade1d9f  push r10
0000705c0ade1da1  push r11
0000705c0ade1da3  sub rsp, 0xF0
0000705c0ade1daa  vmovaps [rsp], xmm0
0000705c0ade1daf  vmovaps [rsp+0x10], xmm1
0000705c0ade1db5  vmovaps [rsp+0x20], xmm2
0000705c0ade1dbb  vmovaps [rsp+0x30], xmm3
0000705c0ade1dc1  vmovaps [rsp+0x40], xmm4
0000705c0ade1dc7  vmovaps [rsp+0x50], xmm5
0000705c0ade1dcd  vmovaps [rsp+0x60], xmm6
0000705c0ade1dd3  vmovaps [rsp+0x70], xmm7
0000705c0ade1dd9  vmovaps [rsp+0x80], xmm8
0000705c0ade1de2  vmovaps [rsp+0x90], xmm9
0000705c0ade1deb  vmovaps [rsp+0xA0], xmm10
0000705c0ade1df4  vmovaps [rsp+0xB0], xmm11
0000705c0ade1dfd  vmovaps [rsp+0xC0], xmm12
0000705c0ade1e06  vmovaps [rsp+0xD0], xmm13
0000705c0ade1e0f  vmovaps [rsp+0xE0], xmm15
0000705c0ade1e18  sub rsp, 0x30
0000705c0ade1e1c  movaps [rsp], xmm14
0000705c0ade1e21  movaps [rsp+0x10], xmm2
0000705c0ade1e26  movaps [rsp+0x20], xmm1
0000705c0ade1e2b  lea rdi, [rsp]
0000705c0ade1e2f  mov esi, 0x00
0000705c0ade1e34  mov rax, 0x5969C28C4530
0000705c0ade1e3e  call rax
0000705c0ade1e40  movaps xmm14, [rsp]
0000705c0ade1e45  add rsp, 0x30
0000705c0ade1e49  vmovaps xmm0, [rsp]
0000705c0ade1e4e  vmovaps xmm1, [rsp+0x10]
0000705c0ade1e54  vmovaps xmm2, [rsp+0x20]
0000705c0ade1e5a  vmovaps xmm3, [rsp+0x30]
0000705c0ade1e60  vmovaps xmm4, [rsp+0x40]
0000705c0ade1e66  vmovaps xmm5, [rsp+0x50]
0000705c0ade1e6c  vmovaps xmm6, [rsp+0x60]
0000705c0ade1e72  vmovaps xmm7, [rsp+0x70]
0000705c0ade1e78  vmovaps xmm8, [rsp+0x80]
0000705c0ade1e81  vmovaps xmm9, [rsp+0x90]
0000705c0ade1e8a  vmovaps xmm10, [rsp+0xA0]
0000705c0ade1e93  vmovaps xmm11, [rsp+0xB0]
0000705c0ade1e9c  vmovaps xmm12, [rsp+0xC0]
0000705c0ade1ea5  vmovaps xmm13, [rsp+0xD0]
0000705c0ade1eae  vmovaps xmm15, [rsp+0xE0]
0000705c0ade1eb7  add rsp, 0xF0
0000705c0ade1ebe  pop r11
0000705c0ade1ec0  pop r10
0000705c0ade1ec2  pop r9
0000705c0ade1ec4  pop r8
0000705c0ade1ec6  pop rsi
0000705c0ade1ec7  pop rdi
0000705c0ade1ec8  pop rdx
0000705c0ade1ec9  pop rcx
0000705c0ade1eca  pop rax
0000705c0ade1ecb  add rsp, 0x08
0000705c0ade1ecf  jmp 0x0000705C0ADDF4B0
0000705c0ade1ed4  sub rsp, 0x08
0000705c0ade1ed8  push rax
0000705c0ade1ed9  push rcx
0000705c0ade1eda  push rdx
0000705c0ade1edb  push rdi
0000705c0ade1edc  push rsi
0000705c0ade1edd  push r8
0000705c0ade1edf  push r9
0000705c0ade1ee1  push r10
0000705c0ade1ee3  push r11
0000705c0ade1ee5  sub rsp, 0xF0
0000705c0ade1eec  vmovaps [rsp], xmm0
0000705c0ade1ef1  vmovaps [rsp+0x10], xmm2
0000705c0ade1ef7  vmovaps [rsp+0x20], xmm3
0000705c0ade1efd  vmovaps [rsp+0x30], xmm4
0000705c0ade1f03  vmovaps [rsp+0x40], xmm5
0000705c0ade1f09  vmovaps [rsp+0x50], xmm6
0000705c0ade1f0f  vmovaps [rsp+0x60], xmm7
0000705c0ade1f15  vmovaps [rsp+0x70], xmm8
0000705c0ade1f1b  vmovaps [rsp+0x80], xmm9
0000705c0ade1f24  vmovaps [rsp+0x90], xmm10
0000705c0ade1f2d  vmovaps [rsp+0xA0], xmm11
0000705c0ade1f36  vmovaps [rsp+0xB0], xmm12
0000705c0ade1f3f  vmovaps [rsp+0xC0], xmm13
0000705c0ade1f48  vmovaps [rsp+0xD0], xmm14
0000705c0ade1f51  vmovaps [rsp+0xE0], xmm15
0000705c0ade1f5a  sub rsp, 0x30
0000705c0ade1f5e  movaps [rsp], xmm1
0000705c0ade1f62  movaps [rsp+0x10], xmm4
0000705c0ade1f67  movaps [rsp+0x20], xmm9
0000705c0ade1f6d  lea rdi, [rsp]
0000705c0ade1f71  mov esi, 0x00
0000705c0ade1f76  mov rax, 0x5969C28C4530
0000705c0ade1f80  call rax
0000705c0ade1f82  movaps xmm1, [rsp]
0000705c0ade1f86  add rsp, 0x30
0000705c0ade1f8a  vmovaps xmm0, [rsp]
0000705c0ade1f8f  vmovaps xmm2, [rsp+0x10]
0000705c0ade1f95  vmovaps xmm3, [rsp+0x20]
0000705c0ade1f9b  vmovaps xmm4, [rsp+0x30]
0000705c0ade1fa1  vmovaps xmm5, [rsp+0x40]
0000705c0ade1fa7  vmovaps xmm6, [rsp+0x50]
0000705c0ade1fad  vmovaps xmm7, [rsp+0x60]
0000705c0ade1fb3  vmovaps xmm8, [rsp+0x70]
0000705c0ade1fb9  vmovaps xmm9, [rsp+0x80]
0000705c0ade1fc2  vmovaps xmm10, [rsp+0x90]
0000705c0ade1fcb  vmovaps xmm11, [rsp+0xA0]
0000705c0ade1fd4  vmovaps xmm12, [rsp+0xB0]
0000705c0ade1fdd  vmovaps xmm13, [rsp+0xC0]
0000705c0ade1fe6  vmovaps xmm14, [rsp+0xD0]
0000705c0ade1fef  vmovaps xmm15, [rsp+0xE0]
0000705c0ade1ff8  add rsp, 0xF0
0000705c0ade1fff  pop r11
0000705c0ade2001  pop r10
0000705c0ade2003  pop r9
0000705c0ade2005  pop r8
0000705c0ade2007  pop rsi
0000705c0ade2008  pop rdi
0000705c0ade2009  pop rdx
0000705c0ade200a  pop rcx
0000705c0ade200b  pop rax
0000705c0ade200c  add rsp, 0x08
0000705c0ade2010  jmp 0x0000705C0ADDF4CE
0000705c0ade2015  sub rsp, 0x08
0000705c0ade2019  push rax
0000705c0ade201a  push rcx
0000705c0ade201b  push rdx
0000705c0ade201c  push rdi
0000705c0ade201d  push rsi
0000705c0ade201e  push r8
0000705c0ade2020  push r9
0000705c0ade2022  push r10
0000705c0ade2024  push r11
0000705c0ade2026  sub rsp, 0xF0
0000705c0ade202d  vmovaps [rsp], xmm0
0000705c0ade2032  vmovaps [rsp+0x10], xmm1
0000705c0ade2038  vmovaps [rsp+0x20], xmm2
0000705c0ade203e  vmovaps [rsp+0x30], xmm3
0000705c0ade2044  vmovaps [rsp+0x40], xmm5
0000705c0ade204a  vmovaps [rsp+0x50], xmm6
0000705c0ade2050  vmovaps [rsp+0x60], xmm7
0000705c0ade2056  vmovaps [rsp+0x70], xmm8
0000705c0ade205c  vmovaps [rsp+0x80], xmm9
0000705c0ade2065  vmovaps [rsp+0x90], xmm10
0000705c0ade206e  vmovaps [rsp+0xA0], xmm11
0000705c0ade2077  vmovaps [rsp+0xB0], xmm12
0000705c0ade2080  vmovaps [rsp+0xC0], xmm13
0000705c0ade2089  vmovaps [rsp+0xD0], xmm14
0000705c0ade2092  vmovaps [rsp+0xE0], xmm15
0000705c0ade209b  sub rsp, 0x30
0000705c0ade209f  movaps [rsp], xmm4
0000705c0ade20a3  movaps [rsp+0x10], xmm2
0000705c0ade20a8  movaps [rsp+0x20], xmm9
0000705c0ade20ae  lea rdi, [rsp]
0000705c0ade20b2  mov esi, 0x00
0000705c0ade20b7  mov rax, 0x5969C28C4530
0000705c0ade20c1  call rax
0000705c0ade20c3  movaps xmm4, [rsp]
0000705c0ade20c7  add rsp, 0x30
0000705c0ade20cb  vmovaps xmm0, [rsp]
0000705c0ade20d0  vmovaps xmm1, [rsp+0x10]
0000705c0ade20d6  vmovaps xmm2, [rsp+0x20]
0000705c0ade20dc  vmovaps xmm3, [rsp+0x30]
0000705c0ade20e2  vmovaps xmm5, [rsp+0x40]
0000705c0ade20e8  vmovaps xmm6, [rsp+0x50]
0000705c0ade20ee  vmovaps xmm7, [rsp+0x60]
0000705c0ade20f4  vmovaps xmm8, [rsp+0x70]
0000705c0ade20fa  vmovaps xmm9, [rsp+0x80]
0000705c0ade2103  vmovaps xmm10, [rsp+0x90]
0000705c0ade210c  vmovaps xmm11, [rsp+0xA0]
0000705c0ade2115  vmovaps xmm12, [rsp+0xB0]
0000705c0ade211e  vmovaps xmm13, [rsp+0xC0]
0000705c0ade2127  vmovaps xmm14, [rsp+0xD0]
0000705c0ade2130  vmovaps xmm15, [rsp+0xE0]
0000705c0ade2139  add rsp, 0xF0
0000705c0ade2140  pop r11
0000705c0ade2142  pop r10
0000705c0ade2144  pop r9
0000705c0ade2146  pop r8
0000705c0ade2148  pop rsi
0000705c0ade2149  pop rdi
0000705c0ade214a  pop rdx
0000705c0ade214b  pop rcx
0000705c0ade214c  pop rax
0000705c0ade214d  add rsp, 0x08
0000705c0ade2151  jmp 0x0000705C0ADDF4FE
0000705c0ade2156  sub rsp, 0x08
0000705c0ade215a  push rax
0000705c0ade215b  push rcx
0000705c0ade215c  push rdx
0000705c0ade215d  push rdi
0000705c0ade215e  push rsi
0000705c0ade215f  push r8
0000705c0ade2161  push r9
0000705c0ade2163  push r10
0000705c0ade2165  push r11
0000705c0ade2167  sub rsp, 0xF0
0000705c0ade216e  vmovaps [rsp], xmm0
0000705c0ade2173  vmovaps [rsp+0x10], xmm1
0000705c0ade2179  vmovaps [rsp+0x20], xmm2
0000705c0ade217f  vmovaps [rsp+0x30], xmm3
0000705c0ade2185  vmovaps [rsp+0x40], xmm4
0000705c0ade218b  vmovaps [rsp+0x50], xmm5
0000705c0ade2191  vmovaps [rsp+0x60], xmm6
0000705c0ade2197  vmovaps [rsp+0x70], xmm7
0000705c0ade219d  vmovaps [rsp+0x80], xmm8
0000705c0ade21a6  vmovaps [rsp+0x90], xmm10
0000705c0ade21af  vmovaps [rsp+0xA0], xmm11
0000705c0ade21b8  vmovaps [rsp+0xB0], xmm12
0000705c0ade21c1  vmovaps [rsp+0xC0], xmm13
0000705c0ade21ca  vmovaps [rsp+0xD0], xmm14
0000705c0ade21d3  vmovaps [rsp+0xE0], xmm15
0000705c0ade21dc  sub rsp, 0x30
0000705c0ade21e0  movaps [rsp], xmm9
0000705c0ade21e5  movaps [rsp+0x10], xmm2
0000705c0ade21ea  movaps [rsp+0x20], xmm1
0000705c0ade21ef  lea rdi, [rsp]
0000705c0ade21f3  mov esi, 0x00
0000705c0ade21f8  mov rax, 0x5969C28C4530
0000705c0ade2202  call rax
0000705c0ade2204  movaps xmm9, [rsp]
0000705c0ade2209  add rsp, 0x30
0000705c0ade220d  vmovaps xmm0, [rsp]
0000705c0ade2212  vmovaps xmm1, [rsp+0x10]
0000705c0ade2218  vmovaps xmm2, [rsp+0x20]
0000705c0ade221e  vmovaps xmm3, [rsp+0x30]
0000705c0ade2224  vmovaps xmm4, [rsp+0x40]
0000705c0ade222a  vmovaps xmm5, [rsp+0x50]
0000705c0ade2230  vmovaps xmm6, [rsp+0x60]
0000705c0ade2236  vmovaps xmm7, [rsp+0x70]
0000705c0ade223c  vmovaps xmm8, [rsp+0x80]
0000705c0ade2245  vmovaps xmm10, [rsp+0x90]
0000705c0ade224e  vmovaps xmm11, [rsp+0xA0]
0000705c0ade2257  vmovaps xmm12, [rsp+0xB0]
0000705c0ade2260  vmovaps xmm13, [rsp+0xC0]
0000705c0ade2269  vmovaps xmm14, [rsp+0xD0]
0000705c0ade2272  vmovaps xmm15, [rsp+0xE0]
0000705c0ade227b  add rsp, 0xF0
0000705c0ade2282  pop r11
0000705c0ade2284  pop r10
0000705c0ade2286  pop r9
0000705c0ade2288  pop r8
0000705c0ade228a  pop rsi
0000705c0ade228b  pop rdi
0000705c0ade228c  pop rdx
0000705c0ade228d  pop rcx
0000705c0ade228e  pop rax
0000705c0ade228f  add rsp, 0x08
0000705c0ade2293  jmp 0x0000705C0ADDF534
0000705c0ade2298  sub rsp, 0x08
0000705c0ade229c  push rax
0000705c0ade229d  push rcx
0000705c0ade229e  push rdx
0000705c0ade229f  push rdi
0000705c0ade22a0  push rsi
0000705c0ade22a1  push r8
0000705c0ade22a3  push r9
0000705c0ade22a5  push r10
0000705c0ade22a7  push r11
0000705c0ade22a9  sub rsp, 0xF0
0000705c0ade22b0  vmovaps [rsp], xmm0
0000705c0ade22b5  vmovaps [rsp+0x10], xmm2
0000705c0ade22bb  vmovaps [rsp+0x20], xmm3
0000705c0ade22c1  vmovaps [rsp+0x30], xmm4
0000705c0ade22c7  vmovaps [rsp+0x40], xmm5
0000705c0ade22cd  vmovaps [rsp+0x50], xmm6
0000705c0ade22d3  vmovaps [rsp+0x60], xmm7
0000705c0ade22d9  vmovaps [rsp+0x70], xmm8
0000705c0ade22df  vmovaps [rsp+0x80], xmm9
0000705c0ade22e8  vmovaps [rsp+0x90], xmm10
0000705c0ade22f1  vmovaps [rsp+0xA0], xmm11
0000705c0ade22fa  vmovaps [rsp+0xB0], xmm12
0000705c0ade2303  vmovaps [rsp+0xC0], xmm13
0000705c0ade230c  vmovaps [rsp+0xD0], xmm14
0000705c0ade2315  vmovaps [rsp+0xE0], xmm15
0000705c0ade231e  sub rsp, 0x30
0000705c0ade2322  movaps [rsp], xmm1
0000705c0ade2326  movaps [rsp+0x10], xmm15
0000705c0ade232c  movaps [rsp+0x20], xmm6
0000705c0ade2331  lea rdi, [rsp]
0000705c0ade2335  mov esi, 0x00
0000705c0ade233a  mov rax, 0x5969C28C4530
0000705c0ade2344  call rax
0000705c0ade2346  movaps xmm1, [rsp]
0000705c0ade234a  add rsp, 0x30
0000705c0ade234e  vmovaps xmm0, [rsp]
0000705c0ade2353  vmovaps xmm2, [rsp+0x10]
0000705c0ade2359  vmovaps xmm3, [rsp+0x20]
0000705c0ade235f  vmovaps xmm4, [rsp+0x30]
0000705c0ade2365  vmovaps xmm5, [rsp+0x40]
0000705c0ade236b  vmovaps xmm6, [rsp+0x50]
0000705c0ade2371  vmovaps xmm7, [rsp+0x60]
0000705c0ade2377  vmovaps xmm8, [rsp+0x70]
0000705c0ade237d  vmovaps xmm9, [rsp+0x80]
0000705c0ade2386  vmovaps xmm10, [rsp+0x90]
0000705c0ade238f  vmovaps xmm11, [rsp+0xA0]
0000705c0ade2398  vmovaps xmm12, [rsp+0xB0]
0000705c0ade23a1  vmovaps xmm13, [rsp+0xC0]
0000705c0ade23aa  vmovaps xmm14, [rsp+0xD0]
0000705c0ade23b3  vmovaps xmm15, [rsp+0xE0]
0000705c0ade23bc  add rsp, 0xF0
0000705c0ade23c3  pop r11
0000705c0ade23c5  pop r10
0000705c0ade23c7  pop r9
0000705c0ade23c9  pop r8
0000705c0ade23cb  pop rsi
0000705c0ade23cc  pop rdi
0000705c0ade23cd  pop rdx
0000705c0ade23ce  pop rcx
0000705c0ade23cf  pop rax
0000705c0ade23d0  add rsp, 0x08
0000705c0ade23d4  jmp 0x0000705C0ADDF555
0000705c0ade23d9  sub rsp, 0x08
0000705c0ade23dd  push rax
0000705c0ade23de  push rcx
0000705c0ade23df  push rdx
0000705c0ade23e0  push rdi
0000705c0ade23e1  push rsi
0000705c0ade23e2  push r8
0000705c0ade23e4  push r9
0000705c0ade23e6  push r10
0000705c0ade23e8  push r11
0000705c0ade23ea  sub rsp, 0xF0
0000705c0ade23f1  vmovaps [rsp], xmm0
0000705c0ade23f6  vmovaps [rsp+0x10], xmm1
0000705c0ade23fc  vmovaps [rsp+0x20], xmm2
0000705c0ade2402  vmovaps [rsp+0x30], xmm3
0000705c0ade2408  vmovaps [rsp+0x40], xmm4
0000705c0ade240e  vmovaps [rsp+0x50], xmm5
0000705c0ade2414  vmovaps [rsp+0x60], xmm6
0000705c0ade241a  vmovaps [rsp+0x70], xmm7
0000705c0ade2420  vmovaps [rsp+0x80], xmm8
0000705c0ade2429  vmovaps [rsp+0x90], xmm9
0000705c0ade2432  vmovaps [rsp+0xA0], xmm10
0000705c0ade243b  vmovaps [rsp+0xB0], xmm11
0000705c0ade2444  vmovaps [rsp+0xC0], xmm12
0000705c0ade244d  vmovaps [rsp+0xD0], xmm13
0000705c0ade2456  vmovaps [rsp+0xE0], xmm14
0000705c0ade245f  sub rsp, 0x30
0000705c0ade2463  movaps [rsp], xmm15
0000705c0ade2468  movaps [rsp+0x10], xmm5
0000705c0ade246d  movaps [rsp+0x20], xmm3
0000705c0ade2472  lea rdi, [rsp]
0000705c0ade2476  mov esi, 0x00
0000705c0ade247b  mov rax, 0x5969C28C4530
0000705c0ade2485  call rax
0000705c0ade2487  movaps xmm15, [rsp]
0000705c0ade248c  add rsp, 0x30
0000705c0ade2490  vmovaps xmm0, [rsp]
0000705c0ade2495  vmovaps xmm1, [rsp+0x10]
0000705c0ade249b  vmovaps xmm2, [rsp+0x20]
0000705c0ade24a1  vmovaps xmm3, [rsp+0x30]
0000705c0ade24a7  vmovaps xmm4, [rsp+0x40]
0000705c0ade24ad  vmovaps xmm5, [rsp+0x50]
0000705c0ade24b3  vmovaps xmm6, [rsp+0x60]
0000705c0ade24b9  vmovaps xmm7, [rsp+0x70]
0000705c0ade24bf  vmovaps xmm8, [rsp+0x80]
0000705c0ade24c8  vmovaps xmm9, [rsp+0x90]
0000705c0ade24d1  vmovaps xmm10, [rsp+0xA0]
0000705c0ade24da  vmovaps xmm11, [rsp+0xB0]
0000705c0ade24e3  vmovaps xmm12, [rsp+0xC0]
0000705c0ade24ec  vmovaps xmm13, [rsp+0xD0]
0000705c0ade24f5  vmovaps xmm14, [rsp+0xE0]
0000705c0ade24fe  add rsp, 0xF0
0000705c0ade2505  pop r11
0000705c0ade2507  pop r10
0000705c0ade2509  pop r9
0000705c0ade250b  pop r8
0000705c0ade250d  pop rsi
0000705c0ade250e  pop rdi
0000705c0ade250f  pop rdx
0000705c0ade2510  pop rcx
0000705c0ade2511  pop rax
0000705c0ade2512  add rsp, 0x08
0000705c0ade2516  jmp 0x0000705C0ADDF56F
0000705c0ade251b  sub rsp, 0x08
0000705c0ade251f  push rax
0000705c0ade2520  push rcx
0000705c0ade2521  push rdx
0000705c0ade2522  push rdi
0000705c0ade2523  push rsi
0000705c0ade2524  push r8
0000705c0ade2526  push r9
0000705c0ade2528  push r10
0000705c0ade252a  push r11
0000705c0ade252c  sub rsp, 0xF0
0000705c0ade2533  vmovaps [rsp], xmm0
0000705c0ade2538  vmovaps [rsp+0x10], xmm1
0000705c0ade253e  vmovaps [rsp+0x20], xmm2
0000705c0ade2544  vmovaps [rsp+0x30], xmm3
0000705c0ade254a  vmovaps [rsp+0x40], xmm4
0000705c0ade2550  vmovaps [rsp+0x50], xmm6
0000705c0ade2556  vmovaps [rsp+0x60], xmm7
0000705c0ade255c  vmovaps [rsp+0x70], xmm8
0000705c0ade2562  vmovaps [rsp+0x80], xmm9
0000705c0ade256b  vmovaps [rsp+0x90], xmm10
0000705c0ade2574  vmovaps [rsp+0xA0], xmm11
0000705c0ade257d  vmovaps [rsp+0xB0], xmm12
0000705c0ade2586  vmovaps [rsp+0xC0], xmm13
0000705c0ade258f  vmovaps [rsp+0xD0], xmm14
0000705c0ade2598  vmovaps [rsp+0xE0], xmm15
0000705c0ade25a1  sub rsp, 0x30
0000705c0ade25a5  movaps [rsp], xmm5
0000705c0ade25a9  movaps [rsp+0x10], xmm8
0000705c0ade25af  movaps [rsp+0x20], xmm6
0000705c0ade25b4  lea rdi, [rsp]
0000705c0ade25b8  mov esi, 0x00
0000705c0ade25bd  mov rax, 0x5969C28C4530
0000705c0ade25c7  call rax
0000705c0ade25c9  movaps xmm5, [rsp]
0000705c0ade25cd  add rsp, 0x30
0000705c0ade25d1  vmovaps xmm0, [rsp]
0000705c0ade25d6  vmovaps xmm1, [rsp+0x10]
0000705c0ade25dc  vmovaps xmm2, [rsp+0x20]
0000705c0ade25e2  vmovaps xmm3, [rsp+0x30]
0000705c0ade25e8  vmovaps xmm4, [rsp+0x40]
0000705c0ade25ee  vmovaps xmm6, [rsp+0x50]
0000705c0ade25f4  vmovaps xmm7, [rsp+0x60]
0000705c0ade25fa  vmovaps xmm8, [rsp+0x70]
0000705c0ade2600  vmovaps xmm9, [rsp+0x80]
0000705c0ade2609  vmovaps xmm10, [rsp+0x90]
0000705c0ade2612  vmovaps xmm11, [rsp+0xA0]
0000705c0ade261b  vmovaps xmm12, [rsp+0xB0]
0000705c0ade2624  vmovaps xmm13, [rsp+0xC0]
0000705c0ade262d  vmovaps xmm14, [rsp+0xD0]
0000705c0ade2636  vmovaps xmm15, [rsp+0xE0]
0000705c0ade263f  add rsp, 0xF0
0000705c0ade2646  pop r11
0000705c0ade2648  pop r10
0000705c0ade264a  pop r9
0000705c0ade264c  pop r8
0000705c0ade264e  pop rsi
0000705c0ade264f  pop rdi
0000705c0ade2650  pop rdx
0000705c0ade2651  pop rcx
0000705c0ade2652  pop rax
0000705c0ade2653  add rsp, 0x08
0000705c0ade2657  jmp 0x0000705C0ADDF593
0000705c0ade265c  sub rsp, 0x08
0000705c0ade2660  push rax
0000705c0ade2661  push rcx
0000705c0ade2662  push rdx
0000705c0ade2663  push rdi
0000705c0ade2664  push rsi
0000705c0ade2665  push r8
0000705c0ade2667  push r9
0000705c0ade2669  push r10
0000705c0ade266b  push r11
0000705c0ade266d  sub rsp, 0xF0
0000705c0ade2674  vmovaps [rsp], xmm0
0000705c0ade2679  vmovaps [rsp+0x10], xmm1
0000705c0ade267f  vmovaps [rsp+0x20], xmm2
0000705c0ade2685  vmovaps [rsp+0x30], xmm3
0000705c0ade268b  vmovaps [rsp+0x40], xmm4
0000705c0ade2691  vmovaps [rsp+0x50], xmm5
0000705c0ade2697  vmovaps [rsp+0x60], xmm7
0000705c0ade269d  vmovaps [rsp+0x70], xmm8
0000705c0ade26a3  vmovaps [rsp+0x80], xmm9
0000705c0ade26ac  vmovaps [rsp+0x90], xmm10
0000705c0ade26b5  vmovaps [rsp+0xA0], xmm11
0000705c0ade26be  vmovaps [rsp+0xB0], xmm12
0000705c0ade26c7  vmovaps [rsp+0xC0], xmm13
0000705c0ade26d0  vmovaps [rsp+0xD0], xmm14
0000705c0ade26d9  vmovaps [rsp+0xE0], xmm15
0000705c0ade26e2  sub rsp, 0x30
0000705c0ade26e6  movaps [rsp], xmm6
0000705c0ade26ea  movaps [rsp+0x10], xmm10
0000705c0ade26f0  movaps [rsp+0x20], xmm8
0000705c0ade26f6  lea rdi, [rsp]
0000705c0ade26fa  mov esi, 0x00
0000705c0ade26ff  mov rax, 0x5969C28C4530
0000705c0ade2709  call rax
0000705c0ade270b  movaps xmm6, [rsp]
0000705c0ade270f  add rsp, 0x30
0000705c0ade2713  vmovaps xmm0, [rsp]
0000705c0ade2718  vmovaps xmm1, [rsp+0x10]
0000705c0ade271e  vmovaps xmm2, [rsp+0x20]
0000705c0ade2724  vmovaps xmm3, [rsp+0x30]
0000705c0ade272a  vmovaps xmm4, [rsp+0x40]
0000705c0ade2730  vmovaps xmm5, [rsp+0x50]
0000705c0ade2736  vmovaps xmm7, [rsp+0x60]
0000705c0ade273c  vmovaps xmm8, [rsp+0x70]
0000705c0ade2742  vmovaps xmm9, [rsp+0x80]
0000705c0ade274b  vmovaps xmm10, [rsp+0x90]
0000705c0ade2754  vmovaps xmm11, [rsp+0xA0]
0000705c0ade275d  vmovaps xmm12, [rsp+0xB0]
0000705c0ade2766  vmovaps xmm13, [rsp+0xC0]
0000705c0ade276f  vmovaps xmm14, [rsp+0xD0]
0000705c0ade2778  vmovaps xmm15, [rsp+0xE0]
0000705c0ade2781  add rsp, 0xF0
0000705c0ade2788  pop r11
0000705c0ade278a  pop r10
0000705c0ade278c  pop r9
0000705c0ade278e  pop r8
0000705c0ade2790  pop rsi
0000705c0ade2791  pop rdi
0000705c0ade2792  pop rdx
0000705c0ade2793  pop rcx
0000705c0ade2794  pop rax
0000705c0ade2795  add rsp, 0x08
0000705c0ade2799  jmp 0x0000705C0ADDF5B8
0000705c0ade279e  sub rsp, 0x08
0000705c0ade27a2  push rax
0000705c0ade27a3  push rcx
0000705c0ade27a4  push rdx
0000705c0ade27a5  push rdi
0000705c0ade27a6  push rsi
0000705c0ade27a7  push r8
0000705c0ade27a9  push r9
0000705c0ade27ab  push r10
0000705c0ade27ad  push r11
0000705c0ade27af  sub rsp, 0xF0
0000705c0ade27b6  vmovaps [rsp], xmm0
0000705c0ade27bb  vmovaps [rsp+0x10], xmm1
0000705c0ade27c1  vmovaps [rsp+0x20], xmm2
0000705c0ade27c7  vmovaps [rsp+0x30], xmm3
0000705c0ade27cd  vmovaps [rsp+0x40], xmm4
0000705c0ade27d3  vmovaps [rsp+0x50], xmm5
0000705c0ade27d9  vmovaps [rsp+0x60], xmm6
0000705c0ade27df  vmovaps [rsp+0x70], xmm7
0000705c0ade27e5  vmovaps [rsp+0x80], xmm8
0000705c0ade27ee  vmovaps [rsp+0x90], xmm9
0000705c0ade27f7  vmovaps [rsp+0xA0], xmm11
0000705c0ade2800  vmovaps [rsp+0xB0], xmm12
0000705c0ade2809  vmovaps [rsp+0xC0], xmm13
0000705c0ade2812  vmovaps [rsp+0xD0], xmm14
0000705c0ade281b  vmovaps [rsp+0xE0], xmm15
0000705c0ade2824  sub rsp, 0x30
0000705c0ade2828  movaps [rsp], xmm10
0000705c0ade282d  movaps [rsp+0x10], xmm8
0000705c0ade2833  movaps [rsp+0x20], xmm14
0000705c0ade2839  lea rdi, [rsp]
0000705c0ade283d  mov esi, 0x00
0000705c0ade2842  mov rax, 0x5969C28C4530
0000705c0ade284c  call rax
0000705c0ade284e  movaps xmm10, [rsp]
0000705c0ade2853  add rsp, 0x30
0000705c0ade2857  vmovaps xmm0, [rsp]
0000705c0ade285c  vmovaps xmm1, [rsp+0x10]
0000705c0ade2862  vmovaps xmm2, [rsp+0x20]
0000705c0ade2868  vmovaps xmm3, [rsp+0x30]
0000705c0ade286e  vmovaps xmm4, [rsp+0x40]
0000705c0ade2874  vmovaps xmm5, [rsp+0x50]
0000705c0ade287a  vmovaps xmm6, [rsp+0x60]
0000705c0ade2880  vmovaps xmm7, [rsp+0x70]
0000705c0ade2886  vmovaps xmm8, [rsp+0x80]
0000705c0ade288f  vmovaps xmm9, [rsp+0x90]
0000705c0ade2898  vmovaps xmm11, [rsp+0xA0]
0000705c0ade28a1  vmovaps xmm12, [rsp+0xB0]
0000705c0ade28aa  vmovaps xmm13, [rsp+0xC0]
0000705c0ade28b3  vmovaps xmm14, [rsp+0xD0]
0000705c0ade28bc  vmovaps xmm15, [rsp+0xE0]
0000705c0ade28c5  add rsp, 0xF0
0000705c0ade28cc  pop r11
0000705c0ade28ce  pop r10
0000705c0ade28d0  pop r9
0000705c0ade28d2  pop r8
0000705c0ade28d4  pop rsi
0000705c0ade28d5  pop rdi
0000705c0ade28d6  pop rdx
0000705c0ade28d7  pop rcx
0000705c0ade28d8  pop rax
0000705c0ade28d9  add rsp, 0x08
0000705c0ade28dd  jmp 0x0000705C0ADDF5D8
0000705c0ade28e2  sub rsp, 0x08
0000705c0ade28e6  push rax
0000705c0ade28e7  push rcx
0000705c0ade28e8  push rdx
0000705c0ade28e9  push rdi
0000705c0ade28ea  push rsi
0000705c0ade28eb  push r8
0000705c0ade28ed  push r9
0000705c0ade28ef  push r10
0000705c0ade28f1  push r11
0000705c0ade28f3  sub rsp, 0xF0
0000705c0ade28fa  vmovaps [rsp], xmm0
0000705c0ade28ff  vmovaps [rsp+0x10], xmm1
0000705c0ade2905  vmovaps [rsp+0x20], xmm2
0000705c0ade290b  vmovaps [rsp+0x30], xmm3
0000705c0ade2911  vmovaps [rsp+0x40], xmm4
0000705c0ade2917  vmovaps [rsp+0x50], xmm5
0000705c0ade291d  vmovaps [rsp+0x60], xmm6
0000705c0ade2923  vmovaps [rsp+0x70], xmm7
0000705c0ade2929  vmovaps [rsp+0x80], xmm8
0000705c0ade2932  vmovaps [rsp+0x90], xmm9
0000705c0ade293b  vmovaps [rsp+0xA0], xmm10
0000705c0ade2944  vmovaps [rsp+0xB0], xmm11
0000705c0ade294d  vmovaps [rsp+0xC0], xmm12
0000705c0ade2956  vmovaps [rsp+0xD0], xmm13
0000705c0ade295f  vmovaps [rsp+0xE0], xmm15
0000705c0ade2968  sub rsp, 0x30
0000705c0ade296c  movaps [rsp], xmm14
0000705c0ade2971  movaps [rsp+0x10], xmm8
0000705c0ade2977  movaps [rsp+0x20], xmm4
0000705c0ade297c  lea rdi, [rsp]
0000705c0ade2980  mov esi, 0x00
0000705c0ade2985  mov rax, 0x5969C28C4530
0000705c0ade298f  call rax
0000705c0ade2991  movaps xmm14, [rsp]
0000705c0ade2996  add rsp, 0x30
0000705c0ade299a  vmovaps xmm0, [rsp]
0000705c0ade299f  vmovaps xmm1, [rsp+0x10]
0000705c0ade29a5  vmovaps xmm2, [rsp+0x20]
0000705c0ade29ab  vmovaps xmm3, [rsp+0x30]
0000705c0ade29b1  vmovaps xmm4, [rsp+0x40]
0000705c0ade29b7  vmovaps xmm5, [rsp+0x50]
0000705c0ade29bd  vmovaps xmm6, [rsp+0x60]
0000705c0ade29c3  vmovaps xmm7, [rsp+0x70]
0000705c0ade29c9  vmovaps xmm8, [rsp+0x80]
0000705c0ade29d2  vmovaps xmm9, [rsp+0x90]
0000705c0ade29db  vmovaps xmm10, [rsp+0xA0]
0000705c0ade29e4  vmovaps xmm11, [rsp+0xB0]
0000705c0ade29ed  vmovaps xmm12, [rsp+0xC0]
0000705c0ade29f6  vmovaps xmm13, [rsp+0xD0]
0000705c0ade29ff  vmovaps xmm15, [rsp+0xE0]
0000705c0ade2a08  add rsp, 0xF0
0000705c0ade2a0f  pop r11
0000705c0ade2a11  pop r10
0000705c0ade2a13  pop r9
0000705c0ade2a15  pop r8
0000705c0ade2a17  pop rsi
0000705c0ade2a18  pop rdi
0000705c0ade2a19  pop rdx
0000705c0ade2a1a  pop rcx
0000705c0ade2a1b  pop rax
0000705c0ade2a1c  add rsp, 0x08
0000705c0ade2a20  jmp 0x0000705C0ADDF5F8
0000705c0ade2a25  sub rsp, 0x08
0000705c0ade2a29  push rax
0000705c0ade2a2a  push rcx
0000705c0ade2a2b  push rdx
0000705c0ade2a2c  push rdi
0000705c0ade2a2d  push rsi
0000705c0ade2a2e  push r8
0000705c0ade2a30  push r9
0000705c0ade2a32  push r10
0000705c0ade2a34  push r11
0000705c0ade2a36  sub rsp, 0xF0
0000705c0ade2a3d  vmovaps [rsp], xmm0
0000705c0ade2a42  vmovaps [rsp+0x10], xmm1
0000705c0ade2a48  vmovaps [rsp+0x20], xmm2
0000705c0ade2a4e  vmovaps [rsp+0x30], xmm3
0000705c0ade2a54  vmovaps [rsp+0x40], xmm5
0000705c0ade2a5a  vmovaps [rsp+0x50], xmm6
0000705c0ade2a60  vmovaps [rsp+0x60], xmm7
0000705c0ade2a66  vmovaps [rsp+0x70], xmm8
0000705c0ade2a6c  vmovaps [rsp+0x80], xmm9
0000705c0ade2a75  vmovaps [rsp+0x90], xmm10
0000705c0ade2a7e  vmovaps [rsp+0xA0], xmm11
0000705c0ade2a87  vmovaps [rsp+0xB0], xmm12
0000705c0ade2a90  vmovaps [rsp+0xC0], xmm13
0000705c0ade2a99  vmovaps [rsp+0xD0], xmm14
0000705c0ade2aa2  vmovaps [rsp+0xE0], xmm15
0000705c0ade2aab  sub rsp, 0x30
0000705c0ade2aaf  movaps [rsp], xmm4
0000705c0ade2ab3  movaps [rsp+0x10], xmm13
0000705c0ade2ab9  movaps [rsp+0x20], xmm8
0000705c0ade2abf  lea rdi, [rsp]
0000705c0ade2ac3  mov esi, 0x00
0000705c0ade2ac8  mov rax, 0x5969C28C4530
0000705c0ade2ad2  call rax
0000705c0ade2ad4  movaps xmm4, [rsp]
0000705c0ade2ad8  add rsp, 0x30
0000705c0ade2adc  vmovaps xmm0, [rsp]
0000705c0ade2ae1  vmovaps xmm1, [rsp+0x10]
0000705c0ade2ae7  vmovaps xmm2, [rsp+0x20]
0000705c0ade2aed  vmovaps xmm3, [rsp+0x30]
0000705c0ade2af3  vmovaps xmm5, [rsp+0x40]
0000705c0ade2af9  vmovaps xmm6, [rsp+0x50]
0000705c0ade2aff  vmovaps xmm7, [rsp+0x60]
0000705c0ade2b05  vmovaps xmm8, [rsp+0x70]
0000705c0ade2b0b  vmovaps xmm9, [rsp+0x80]
0000705c0ade2b14  vmovaps xmm10, [rsp+0x90]
0000705c0ade2b1d  vmovaps xmm11, [rsp+0xA0]
0000705c0ade2b26  vmovaps xmm12, [rsp+0xB0]
0000705c0ade2b2f  vmovaps xmm13, [rsp+0xC0]
0000705c0ade2b38  vmovaps xmm14, [rsp+0xD0]
0000705c0ade2b41  vmovaps xmm15, [rsp+0xE0]
0000705c0ade2b4a  add rsp, 0xF0
0000705c0ade2b51  pop r11
0000705c0ade2b53  pop r10
0000705c0ade2b55  pop r9
0000705c0ade2b57  pop r8
0000705c0ade2b59  pop rsi
0000705c0ade2b5a  pop rdi
0000705c0ade2b5b  pop rdx
0000705c0ade2b5c  pop rcx
0000705c0ade2b5d  pop rax
0000705c0ade2b5e  add rsp, 0x08
0000705c0ade2b62  jmp 0x0000705C0ADDF61D
0000705c0ade2b67  sub rsp, 0x08
0000705c0ade2b6b  push rax
0000705c0ade2b6c  push rcx
0000705c0ade2b6d  push rdx
0000705c0ade2b6e  push rdi
0000705c0ade2b6f  push rsi
0000705c0ade2b70  push r8
0000705c0ade2b72  push r9
0000705c0ade2b74  push r10
0000705c0ade2b76  push r11
0000705c0ade2b78  sub rsp, 0xF0
0000705c0ade2b7f  vmovaps [rsp], xmm0
0000705c0ade2b84  vmovaps [rsp+0x10], xmm1
0000705c0ade2b8a  vmovaps [rsp+0x20], xmm2
0000705c0ade2b90  vmovaps [rsp+0x30], xmm3
0000705c0ade2b96  vmovaps [rsp+0x40], xmm4
0000705c0ade2b9c  vmovaps [rsp+0x50], xmm5
0000705c0ade2ba2  vmovaps [rsp+0x60], xmm6
0000705c0ade2ba8  vmovaps [rsp+0x70], xmm7
0000705c0ade2bae  vmovaps [rsp+0x80], xmm8
0000705c0ade2bb7  vmovaps [rsp+0x90], xmm9
0000705c0ade2bc0  vmovaps [rsp+0xA0], xmm10
0000705c0ade2bc9  vmovaps [rsp+0xB0], xmm11
0000705c0ade2bd2  vmovaps [rsp+0xC0], xmm12
0000705c0ade2bdb  vmovaps [rsp+0xD0], xmm14
0000705c0ade2be4  vmovaps [rsp+0xE0], xmm15
0000705c0ade2bed  sub rsp, 0x30
0000705c0ade2bf1  movaps [rsp], xmm13
0000705c0ade2bf6  movaps [rsp+0x10], xmm15
0000705c0ade2bfc  movaps [rsp+0x20], xmm9
0000705c0ade2c02  lea rdi, [rsp]
0000705c0ade2c06  mov esi, 0x00
0000705c0ade2c0b  mov rax, 0x5969C28C4530
0000705c0ade2c15  call rax
0000705c0ade2c17  movaps xmm13, [rsp]
0000705c0ade2c1c  add rsp, 0x30
0000705c0ade2c20  vmovaps xmm0, [rsp]
0000705c0ade2c25  vmovaps xmm1, [rsp+0x10]
0000705c0ade2c2b  vmovaps xmm2, [rsp+0x20]
0000705c0ade2c31  vmovaps xmm3, [rsp+0x30]
0000705c0ade2c37  vmovaps xmm4, [rsp+0x40]
0000705c0ade2c3d  vmovaps xmm5, [rsp+0x50]
0000705c0ade2c43  vmovaps xmm6, [rsp+0x60]
0000705c0ade2c49  vmovaps xmm7, [rsp+0x70]
0000705c0ade2c4f  vmovaps xmm8, [rsp+0x80]
0000705c0ade2c58  vmovaps xmm9, [rsp+0x90]
0000705c0ade2c61  vmovaps xmm10, [rsp+0xA0]
0000705c0ade2c6a  vmovaps xmm11, [rsp+0xB0]
0000705c0ade2c73  vmovaps xmm12, [rsp+0xC0]
0000705c0ade2c7c  vmovaps xmm14, [rsp+0xD0]
0000705c0ade2c85  vmovaps xmm15, [rsp+0xE0]
0000705c0ade2c8e  add rsp, 0xF0
0000705c0ade2c95  pop r11
0000705c0ade2c97  pop r10
0000705c0ade2c99  pop r9
0000705c0ade2c9b  pop r8
0000705c0ade2c9d  pop rsi
0000705c0ade2c9e  pop rdi
0000705c0ade2c9f  pop rdx
0000705c0ade2ca0  pop rcx
0000705c0ade2ca1  pop rax
0000705c0ade2ca2  add rsp, 0x08
0000705c0ade2ca6  jmp 0x0000705C0ADDF638
0000705c0ade2cab  sub rsp, 0x08
0000705c0ade2caf  push rax
0000705c0ade2cb0  push rcx
0000705c0ade2cb1  push rdx
0000705c0ade2cb2  push rdi
0000705c0ade2cb3  push rsi
0000705c0ade2cb4  push r8
0000705c0ade2cb6  push r9
0000705c0ade2cb8  push r10
0000705c0ade2cba  push r11
0000705c0ade2cbc  sub rsp, 0xF0
0000705c0ade2cc3  vmovaps [rsp], xmm0
0000705c0ade2cc8  vmovaps [rsp+0x10], xmm1
0000705c0ade2cce  vmovaps [rsp+0x20], xmm2
0000705c0ade2cd4  vmovaps [rsp+0x30], xmm3
0000705c0ade2cda  vmovaps [rsp+0x40], xmm4
0000705c0ade2ce0  vmovaps [rsp+0x50], xmm5
0000705c0ade2ce6  vmovaps [rsp+0x60], xmm6
0000705c0ade2cec  vmovaps [rsp+0x70], xmm7
0000705c0ade2cf2  vmovaps [rsp+0x80], xmm8
0000705c0ade2cfb  vmovaps [rsp+0x90], xmm9
0000705c0ade2d04  vmovaps [rsp+0xA0], xmm10
0000705c0ade2d0d  vmovaps [rsp+0xB0], xmm11
0000705c0ade2d16  vmovaps [rsp+0xC0], xmm12
0000705c0ade2d1f  vmovaps [rsp+0xD0], xmm13
0000705c0ade2d28  vmovaps [rsp+0xE0], xmm14
0000705c0ade2d31  sub rsp, 0x30
0000705c0ade2d35  movaps [rsp], xmm15
0000705c0ade2d3a  movaps [rsp+0x10], xmm1
0000705c0ade2d3f  movaps [rsp+0x20], xmm5
0000705c0ade2d44  lea rdi, [rsp]
0000705c0ade2d48  mov esi, 0x00
0000705c0ade2d4d  mov rax, 0x5969C28C4530
0000705c0ade2d57  call rax
0000705c0ade2d59  movaps xmm15, [rsp]
0000705c0ade2d5e  add rsp, 0x30
0000705c0ade2d62  vmovaps xmm0, [rsp]
0000705c0ade2d67  vmovaps xmm1, [rsp+0x10]
0000705c0ade2d6d  vmovaps xmm2, [rsp+0x20]
0000705c0ade2d73  vmovaps xmm3, [rsp+0x30]
0000705c0ade2d79  vmovaps xmm4, [rsp+0x40]
0000705c0ade2d7f  vmovaps xmm5, [rsp+0x50]
0000705c0ade2d85  vmovaps xmm6, [rsp+0x60]
0000705c0ade2d8b  vmovaps xmm7, [rsp+0x70]
0000705c0ade2d91  vmovaps xmm8, [rsp+0x80]
0000705c0ade2d9a  vmovaps xmm9, [rsp+0x90]
0000705c0ade2da3  vmovaps xmm10, [rsp+0xA0]
0000705c0ade2dac  vmovaps xmm11, [rsp+0xB0]
0000705c0ade2db5  vmovaps xmm12, [rsp+0xC0]
0000705c0ade2dbe  vmovaps xmm13, [rsp+0xD0]
0000705c0ade2dc7  vmovaps xmm14, [rsp+0xE0]
0000705c0ade2dd0  add rsp, 0xF0
0000705c0ade2dd7  pop r11
0000705c0ade2dd9  pop r10
0000705c0ade2ddb  pop r9
0000705c0ade2ddd  pop r8
0000705c0ade2ddf  pop rsi
0000705c0ade2de0  pop rdi
0000705c0ade2de1  pop rdx
0000705c0ade2de2  pop rcx
0000705c0ade2de3  pop rax
0000705c0ade2de4  add rsp, 0x08
0000705c0ade2de8  jmp 0x0000705C0ADDF653
0000705c0ade2ded  call 0x0000705C0ACB52F0
0000705c0ade2df2  jmp 0x0000705C0ADDF6AE
0000705c0ade2df7  sub rsp, 0x08
0000705c0ade2dfb  push rax
0000705c0ade2dfc  push rcx
0000705c0ade2dfd  push rdx
0000705c0ade2dfe  push rdi
0000705c0ade2dff  push rsi
0000705c0ade2e00  push r8
0000705c0ade2e02  push r9
0000705c0ade2e04  push r10
0000705c0ade2e06  push r11
0000705c0ade2e08  sub rsp, 0xF0
0000705c0ade2e0f  vmovaps [rsp], xmm0
0000705c0ade2e14  vmovaps [rsp+0x10], xmm1
0000705c0ade2e1a  vmovaps [rsp+0x20], xmm2
0000705c0ade2e20  vmovaps [rsp+0x30], xmm3
0000705c0ade2e26  vmovaps [rsp+0x40], xmm4
0000705c0ade2e2c  vmovaps [rsp+0x50], xmm5
0000705c0ade2e32  vmovaps [rsp+0x60], xmm6
0000705c0ade2e38  vmovaps [rsp+0x70], xmm7
0000705c0ade2e3e  vmovaps [rsp+0x80], xmm8
0000705c0ade2e47  vmovaps [rsp+0x90], xmm10
0000705c0ade2e50  vmovaps [rsp+0xA0], xmm11
0000705c0ade2e59  vmovaps [rsp+0xB0], xmm12
0000705c0ade2e62  vmovaps [rsp+0xC0], xmm13
0000705c0ade2e6b  vmovaps [rsp+0xD0], xmm14
0000705c0ade2e74  vmovaps [rsp+0xE0], xmm15
0000705c0ade2e7d  sub rsp, 0x30
0000705c0ade2e81  movaps [rsp], xmm9
0000705c0ade2e86  movaps [rsp+0x10], xmm8
0000705c0ade2e8c  movaps [rsp+0x20], xmm11
0000705c0ade2e92  lea rdi, [rsp]
0000705c0ade2e96  mov esi, 0x00
0000705c0ade2e9b  mov rax, 0x5969C28C4530
0000705c0ade2ea5  call rax
0000705c0ade2ea7  movaps xmm9, [rsp]
0000705c0ade2eac  add rsp, 0x30
0000705c0ade2eb0  vmovaps xmm0, [rsp]
0000705c0ade2eb5  vmovaps xmm1, [rsp+0x10]
0000705c0ade2ebb  vmovaps xmm2, [rsp+0x20]
0000705c0ade2ec1  vmovaps xmm3, [rsp+0x30]
0000705c0ade2ec7  vmovaps xmm4, [rsp+0x40]
0000705c0ade2ecd  vmovaps xmm5, [rsp+0x50]
0000705c0ade2ed3  vmovaps xmm6, [rsp+0x60]
0000705c0ade2ed9  vmovaps xmm7, [rsp+0x70]
0000705c0ade2edf  vmovaps xmm8, [rsp+0x80]
0000705c0ade2ee8  vmovaps xmm10, [rsp+0x90]
0000705c0ade2ef1  vmovaps xmm11, [rsp+0xA0]
0000705c0ade2efa  vmovaps xmm12, [rsp+0xB0]
0000705c0ade2f03  vmovaps xmm13, [rsp+0xC0]
0000705c0ade2f0c  vmovaps xmm14, [rsp+0xD0]
0000705c0ade2f15  vmovaps xmm15, [rsp+0xE0]
0000705c0ade2f1e  add rsp, 0xF0
0000705c0ade2f25  pop r11
0000705c0ade2f27  pop r10
0000705c0ade2f29  pop r9
0000705c0ade2f2b  pop r8
0000705c0ade2f2d  pop rsi
0000705c0ade2f2e  pop rdi
0000705c0ade2f2f  pop rdx
0000705c0ade2f30  pop rcx
0000705c0ade2f31  pop rax
0000705c0ade2f32  add rsp, 0x08
0000705c0ade2f36  jmp 0x0000705C0ADDF6E5
0000705c0ade2f3b  sub rsp, 0x08
0000705c0ade2f3f  push rax
0000705c0ade2f40  push rcx
0000705c0ade2f41  push rdx
0000705c0ade2f42  push rdi
0000705c0ade2f43  push rsi
0000705c0ade2f44  push r8
0000705c0ade2f46  push r9
0000705c0ade2f48  push r10
0000705c0ade2f4a  push r11
0000705c0ade2f4c  sub rsp, 0xF0
0000705c0ade2f53  vmovaps [rsp], xmm0
0000705c0ade2f58  vmovaps [rsp+0x10], xmm1
0000705c0ade2f5e  vmovaps [rsp+0x20], xmm2
0000705c0ade2f64  vmovaps [rsp+0x30], xmm3
0000705c0ade2f6a  vmovaps [rsp+0x40], xmm4
0000705c0ade2f70  vmovaps [rsp+0x50], xmm5
0000705c0ade2f76  vmovaps [rsp+0x60], xmm6
0000705c0ade2f7c  vmovaps [rsp+0x70], xmm7
0000705c0ade2f82  vmovaps [rsp+0x80], xmm8
0000705c0ade2f8b  vmovaps [rsp+0x90], xmm9
0000705c0ade2f94  vmovaps [rsp+0xA0], xmm10
0000705c0ade2f9d  vmovaps [rsp+0xB0], xmm12
0000705c0ade2fa6  vmovaps [rsp+0xC0], xmm13
0000705c0ade2faf  vmovaps [rsp+0xD0], xmm14
0000705c0ade2fb8  vmovaps [rsp+0xE0], xmm15
0000705c0ade2fc1  sub rsp, 0x30
0000705c0ade2fc5  movaps [rsp], xmm11
0000705c0ade2fca  movaps [rsp+0x10], xmm10
0000705c0ade2fd0  movaps [rsp+0x20], xmm6
0000705c0ade2fd5  lea rdi, [rsp]
0000705c0ade2fd9  mov esi, 0x00
0000705c0ade2fde  mov rax, 0x5969C28C4530
0000705c0ade2fe8  call rax
0000705c0ade2fea  movaps xmm11, [rsp]
0000705c0ade2fef  add rsp, 0x30
0000705c0ade2ff3  vmovaps xmm0, [rsp]
0000705c0ade2ff8  vmovaps xmm1, [rsp+0x10]
0000705c0ade2ffe  vmovaps xmm2, [rsp+0x20]
0000705c0ade3004  vmovaps xmm3, [rsp+0x30]
0000705c0ade300a  vmovaps xmm4, [rsp+0x40]
0000705c0ade3010  vmovaps xmm5, [rsp+0x50]
0000705c0ade3016  vmovaps xmm6, [rsp+0x60]
0000705c0ade301c  vmovaps xmm7, [rsp+0x70]
0000705c0ade3022  vmovaps xmm8, [rsp+0x80]
0000705c0ade302b  vmovaps xmm9, [rsp+0x90]
0000705c0ade3034  vmovaps xmm10, [rsp+0xA0]
0000705c0ade303d  vmovaps xmm12, [rsp+0xB0]
0000705c0ade3046  vmovaps xmm13, [rsp+0xC0]
0000705c0ade304f  vmovaps xmm14, [rsp+0xD0]
0000705c0ade3058  vmovaps xmm15, [rsp+0xE0]
0000705c0ade3061  add rsp, 0xF0
0000705c0ade3068  pop r11
0000705c0ade306a  pop r10
0000705c0ade306c  pop r9
0000705c0ade306e  pop r8
0000705c0ade3070  pop rsi
0000705c0ade3071  pop rdi
0000705c0ade3072  pop rdx
0000705c0ade3073  pop rcx
0000705c0ade3074  pop rax
0000705c0ade3075  add rsp, 0x08
0000705c0ade3079  jmp 0x0000705C0ADDF700
0000705c0ade307e  sub rsp, 0x08
0000705c0ade3082  push rax
0000705c0ade3083  push rcx
0000705c0ade3084  push rdx
0000705c0ade3085  push rdi
0000705c0ade3086  push rsi
0000705c0ade3087  push r8
0000705c0ade3089  push r9
0000705c0ade308b  push r10
0000705c0ade308d  push r11
0000705c0ade308f  sub rsp, 0xF0
0000705c0ade3096  vmovaps [rsp], xmm0
0000705c0ade309b  vmovaps [rsp+0x10], xmm1
0000705c0ade30a1  vmovaps [rsp+0x20], xmm2
0000705c0ade30a7  vmovaps [rsp+0x30], xmm3
0000705c0ade30ad  vmovaps [rsp+0x40], xmm4
0000705c0ade30b3  vmovaps [rsp+0x50], xmm5
0000705c0ade30b9  vmovaps [rsp+0x60], xmm6
0000705c0ade30bf  vmovaps [rsp+0x70], xmm7
0000705c0ade30c5  vmovaps [rsp+0x80], xmm8
0000705c0ade30ce  vmovaps [rsp+0x90], xmm9
0000705c0ade30d7  vmovaps [rsp+0xA0], xmm11
0000705c0ade30e0  vmovaps [rsp+0xB0], xmm12
0000705c0ade30e9  vmovaps [rsp+0xC0], xmm13
0000705c0ade30f2  vmovaps [rsp+0xD0], xmm14
0000705c0ade30fb  vmovaps [rsp+0xE0], xmm15
0000705c0ade3104  sub rsp, 0x30
0000705c0ade3108  movaps [rsp], xmm10
0000705c0ade310d  movaps [rsp+0x10], xmm14
0000705c0ade3113  movaps [rsp+0x20], xmm4
0000705c0ade3118  lea rdi, [rsp]
0000705c0ade311c  mov esi, 0x00
0000705c0ade3121  mov rax, 0x5969C28C4530
0000705c0ade312b  call rax
0000705c0ade312d  movaps xmm10, [rsp]
0000705c0ade3132  add rsp, 0x30
0000705c0ade3136  vmovaps xmm0, [rsp]
0000705c0ade313b  vmovaps xmm1, [rsp+0x10]
0000705c0ade3141  vmovaps xmm2, [rsp+0x20]
0000705c0ade3147  vmovaps xmm3, [rsp+0x30]
0000705c0ade314d  vmovaps xmm4, [rsp+0x40]
0000705c0ade3153  vmovaps xmm5, [rsp+0x50]
0000705c0ade3159  vmovaps xmm6, [rsp+0x60]
0000705c0ade315f  vmovaps xmm7, [rsp+0x70]
0000705c0ade3165  vmovaps xmm8, [rsp+0x80]
0000705c0ade316e  vmovaps xmm9, [rsp+0x90]
0000705c0ade3177  vmovaps xmm11, [rsp+0xA0]
0000705c0ade3180  vmovaps xmm12, [rsp+0xB0]
0000705c0ade3189  vmovaps xmm13, [rsp+0xC0]
0000705c0ade3192  vmovaps xmm14, [rsp+0xD0]
0000705c0ade319b  vmovaps xmm15, [rsp+0xE0]
0000705c0ade31a4  add rsp, 0xF0
0000705c0ade31ab  pop r11
0000705c0ade31ad  pop r10
0000705c0ade31af  pop r9
0000705c0ade31b1  pop r8
0000705c0ade31b3  pop rsi
0000705c0ade31b4  pop rdi
0000705c0ade31b5  pop rdx
0000705c0ade31b6  pop rcx
0000705c0ade31b7  pop rax
0000705c0ade31b8  add rsp, 0x08
0000705c0ade31bc  jmp 0x0000705C0ADDF71B
0000705c0ade31c1  sub rsp, 0x08
0000705c0ade31c5  push rax
0000705c0ade31c6  push rcx
0000705c0ade31c7  push rdx
0000705c0ade31c8  push rdi
0000705c0ade31c9  push rsi
0000705c0ade31ca  push r8
0000705c0ade31cc  push r9
0000705c0ade31ce  push r10
0000705c0ade31d0  push r11
0000705c0ade31d2  sub rsp, 0xF0
0000705c0ade31d9  vmovaps [rsp], xmm0
0000705c0ade31de  vmovaps [rsp+0x10], xmm1
0000705c0ade31e4  vmovaps [rsp+0x20], xmm2
0000705c0ade31ea  vmovaps [rsp+0x30], xmm3
0000705c0ade31f0  vmovaps [rsp+0x40], xmm4
0000705c0ade31f6  vmovaps [rsp+0x50], xmm5
0000705c0ade31fc  vmovaps [rsp+0x60], xmm6
0000705c0ade3202  vmovaps [rsp+0x70], xmm7
0000705c0ade3208  vmovaps [rsp+0x80], xmm9
0000705c0ade3211  vmovaps [rsp+0x90], xmm10
0000705c0ade321a  vmovaps [rsp+0xA0], xmm11
0000705c0ade3223  vmovaps [rsp+0xB0], xmm12
0000705c0ade322c  vmovaps [rsp+0xC0], xmm13
0000705c0ade3235  vmovaps [rsp+0xD0], xmm14
0000705c0ade323e  vmovaps [rsp+0xE0], xmm15
0000705c0ade3247  sub rsp, 0x30
0000705c0ade324b  movaps [rsp], xmm8
0000705c0ade3250  movaps [rsp+0x10], xmm1
0000705c0ade3255  movaps [rsp+0x20], xmm14
0000705c0ade325b  lea rdi, [rsp]
0000705c0ade325f  mov esi, 0x00
0000705c0ade3264  mov rax, 0x5969C28C4530
0000705c0ade326e  call rax
0000705c0ade3270  movaps xmm8, [rsp]
0000705c0ade3275  add rsp, 0x30
0000705c0ade3279  vmovaps xmm0, [rsp]
0000705c0ade327e  vmovaps xmm1, [rsp+0x10]
0000705c0ade3284  vmovaps xmm2, [rsp+0x20]
0000705c0ade328a  vmovaps xmm3, [rsp+0x30]
0000705c0ade3290  vmovaps xmm4, [rsp+0x40]
0000705c0ade3296  vmovaps xmm5, [rsp+0x50]
0000705c0ade329c  vmovaps xmm6, [rsp+0x60]
0000705c0ade32a2  vmovaps xmm7, [rsp+0x70]
0000705c0ade32a8  vmovaps xmm9, [rsp+0x80]
0000705c0ade32b1  vmovaps xmm10, [rsp+0x90]
0000705c0ade32ba  vmovaps xmm11, [rsp+0xA0]
0000705c0ade32c3  vmovaps xmm12, [rsp+0xB0]
0000705c0ade32cc  vmovaps xmm13, [rsp+0xC0]
0000705c0ade32d5  vmovaps xmm14, [rsp+0xD0]
0000705c0ade32de  vmovaps xmm15, [rsp+0xE0]
0000705c0ade32e7  add rsp, 0xF0
0000705c0ade32ee  pop r11
0000705c0ade32f0  pop r10
0000705c0ade32f2  pop r9
0000705c0ade32f4  pop r8
0000705c0ade32f6  pop rsi
0000705c0ade32f7  pop rdi
0000705c0ade32f8  pop rdx
0000705c0ade32f9  pop rcx
0000705c0ade32fa  pop rax
0000705c0ade32fb  add rsp, 0x08
0000705c0ade32ff  jmp 0x0000705C0ADDF741
0000705c0ade3304  sub rsp, 0x08
0000705c0ade3308  push rax
0000705c0ade3309  push rcx
0000705c0ade330a  push rdx
0000705c0ade330b  push rdi
0000705c0ade330c  push rsi
0000705c0ade330d  push r8
0000705c0ade330f  push r9
0000705c0ade3311  push r10
0000705c0ade3313  push r11
0000705c0ade3315  sub rsp, 0xF0
0000705c0ade331c  vmovaps [rsp], xmm0
0000705c0ade3321  vmovaps [rsp+0x10], xmm1
0000705c0ade3327  vmovaps [rsp+0x20], xmm2
0000705c0ade332d  vmovaps [rsp+0x30], xmm3
0000705c0ade3333  vmovaps [rsp+0x40], xmm4
0000705c0ade3339  vmovaps [rsp+0x50], xmm5
0000705c0ade333f  vmovaps [rsp+0x60], xmm7
0000705c0ade3345  vmovaps [rsp+0x70], xmm8
0000705c0ade334b  vmovaps [rsp+0x80], xmm9
0000705c0ade3354  vmovaps [rsp+0x90], xmm10
0000705c0ade335d  vmovaps [rsp+0xA0], xmm11
0000705c0ade3366  vmovaps [rsp+0xB0], xmm12
0000705c0ade336f  vmovaps [rsp+0xC0], xmm13
0000705c0ade3378  vmovaps [rsp+0xD0], xmm14
0000705c0ade3381  vmovaps [rsp+0xE0], xmm15
0000705c0ade338a  sub rsp, 0x30
0000705c0ade338e  movaps [rsp], xmm6
0000705c0ade3392  movaps [rsp+0x10], xmm1
0000705c0ade3397  movaps [rsp+0x20], xmm14
0000705c0ade339d  lea rdi, [rsp]
0000705c0ade33a1  mov esi, 0x00
0000705c0ade33a6  mov rax, 0x5969C28C4530
0000705c0ade33b0  call rax
0000705c0ade33b2  movaps xmm6, [rsp]
0000705c0ade33b6  add rsp, 0x30
0000705c0ade33ba  vmovaps xmm0, [rsp]
0000705c0ade33bf  vmovaps xmm1, [rsp+0x10]
0000705c0ade33c5  vmovaps xmm2, [rsp+0x20]
0000705c0ade33cb  vmovaps xmm3, [rsp+0x30]
0000705c0ade33d1  vmovaps xmm4, [rsp+0x40]
0000705c0ade33d7  vmovaps xmm5, [rsp+0x50]
0000705c0ade33dd  vmovaps xmm7, [rsp+0x60]
0000705c0ade33e3  vmovaps xmm8, [rsp+0x70]
0000705c0ade33e9  vmovaps xmm9, [rsp+0x80]
0000705c0ade33f2  vmovaps xmm10, [rsp+0x90]
0000705c0ade33fb  vmovaps xmm11, [rsp+0xA0]
0000705c0ade3404  vmovaps xmm12, [rsp+0xB0]
0000705c0ade340d  vmovaps xmm13, [rsp+0xC0]
0000705c0ade3416  vmovaps xmm14, [rsp+0xD0]
0000705c0ade341f  vmovaps xmm15, [rsp+0xE0]
0000705c0ade3428  add rsp, 0xF0
0000705c0ade342f  pop r11
0000705c0ade3431  pop r10
0000705c0ade3433  pop r9
0000705c0ade3435  pop r8
0000705c0ade3437  pop rsi
0000705c0ade3438  pop rdi
0000705c0ade3439  pop rdx
0000705c0ade343a  pop rcx
0000705c0ade343b  pop rax
0000705c0ade343c  add rsp, 0x08
0000705c0ade3440  jmp 0x0000705C0ADDF76D
0000705c0ade3445  sub rsp, 0x08
0000705c0ade3449  push rax
0000705c0ade344a  push rcx
0000705c0ade344b  push rdx
0000705c0ade344c  push rdi
0000705c0ade344d  push rsi
0000705c0ade344e  push r8
0000705c0ade3450  push r9
0000705c0ade3452  push r10
0000705c0ade3454  push r11
0000705c0ade3456  sub rsp, 0xF0
0000705c0ade345d  vmovaps [rsp], xmm0
0000705c0ade3462  vmovaps [rsp+0x10], xmm1
0000705c0ade3468  vmovaps [rsp+0x20], xmm2
0000705c0ade346e  vmovaps [rsp+0x30], xmm3
0000705c0ade3474  vmovaps [rsp+0x40], xmm4
0000705c0ade347a  vmovaps [rsp+0x50], xmm5
0000705c0ade3480  vmovaps [rsp+0x60], xmm6
0000705c0ade3486  vmovaps [rsp+0x70], xmm7
0000705c0ade348c  vmovaps [rsp+0x80], xmm8
0000705c0ade3495  vmovaps [rsp+0x90], xmm9
0000705c0ade349e  vmovaps [rsp+0xA0], xmm10
0000705c0ade34a7  vmovaps [rsp+0xB0], xmm11
0000705c0ade34b0  vmovaps [rsp+0xC0], xmm12
0000705c0ade34b9  vmovaps [rsp+0xD0], xmm13
0000705c0ade34c2  vmovaps [rsp+0xE0], xmm15
0000705c0ade34cb  sub rsp, 0x30
0000705c0ade34cf  movaps [rsp], xmm14
0000705c0ade34d4  movaps [rsp+0x10], xmm12
0000705c0ade34da  movaps [rsp+0x20], xmm1
0000705c0ade34df  lea rdi, [rsp]
0000705c0ade34e3  mov esi, 0x00
0000705c0ade34e8  mov rax, 0x5969C28C4530
0000705c0ade34f2  call rax
0000705c0ade34f4  movaps xmm14, [rsp]
0000705c0ade34f9  add rsp, 0x30
0000705c0ade34fd  vmovaps xmm0, [rsp]
0000705c0ade3502  vmovaps xmm1, [rsp+0x10]
0000705c0ade3508  vmovaps xmm2, [rsp+0x20]
0000705c0ade350e  vmovaps xmm3, [rsp+0x30]
0000705c0ade3514  vmovaps xmm4, [rsp+0x40]
0000705c0ade351a  vmovaps xmm5, [rsp+0x50]
0000705c0ade3520  vmovaps xmm6, [rsp+0x60]
0000705c0ade3526  vmovaps xmm7, [rsp+0x70]
0000705c0ade352c  vmovaps xmm8, [rsp+0x80]
0000705c0ade3535  vmovaps xmm9, [rsp+0x90]
0000705c0ade353e  vmovaps xmm10, [rsp+0xA0]
0000705c0ade3547  vmovaps xmm11, [rsp+0xB0]
0000705c0ade3550  vmovaps xmm12, [rsp+0xC0]
0000705c0ade3559  vmovaps xmm13, [rsp+0xD0]
0000705c0ade3562  vmovaps xmm15, [rsp+0xE0]
0000705c0ade356b  add rsp, 0xF0
0000705c0ade3572  pop r11
0000705c0ade3574  pop r10
0000705c0ade3576  pop r9
0000705c0ade3578  pop r8
0000705c0ade357a  pop rsi
0000705c0ade357b  pop rdi
0000705c0ade357c  pop rdx
0000705c0ade357d  pop rcx
0000705c0ade357e  pop rax
0000705c0ade357f  add rsp, 0x08
0000705c0ade3583  jmp 0x0000705C0ADDF793
0000705c0ade3588  sub rsp, 0x08
0000705c0ade358c  push rax
0000705c0ade358d  push rcx
0000705c0ade358e  push rdx
0000705c0ade358f  push rdi
0000705c0ade3590  push rsi
0000705c0ade3591  push r8
0000705c0ade3593  push r9
0000705c0ade3595  push r10
0000705c0ade3597  push r11
0000705c0ade3599  sub rsp, 0xF0
0000705c0ade35a0  vmovaps [rsp], xmm0
0000705c0ade35a5  vmovaps [rsp+0x10], xmm2
0000705c0ade35ab  vmovaps [rsp+0x20], xmm3
0000705c0ade35b1  vmovaps [rsp+0x30], xmm4
0000705c0ade35b7  vmovaps [rsp+0x40], xmm5
0000705c0ade35bd  vmovaps [rsp+0x50], xmm6
0000705c0ade35c3  vmovaps [rsp+0x60], xmm7
0000705c0ade35c9  vmovaps [rsp+0x70], xmm8
0000705c0ade35cf  vmovaps [rsp+0x80], xmm9
0000705c0ade35d8  vmovaps [rsp+0x90], xmm10
0000705c0ade35e1  vmovaps [rsp+0xA0], xmm11
0000705c0ade35ea  vmovaps [rsp+0xB0], xmm12
0000705c0ade35f3  vmovaps [rsp+0xC0], xmm13
0000705c0ade35fc  vmovaps [rsp+0xD0], xmm14
0000705c0ade3605  vmovaps [rsp+0xE0], xmm15
0000705c0ade360e  sub rsp, 0x30
0000705c0ade3612  movaps [rsp], xmm1
0000705c0ade3616  movaps [rsp+0x10], xmm13
0000705c0ade361c  movaps [rsp+0x20], xmm9
0000705c0ade3622  lea rdi, [rsp]
0000705c0ade3626  mov esi, 0x00
0000705c0ade362b  mov rax, 0x5969C28C4530
0000705c0ade3635  call rax
0000705c0ade3637  movaps xmm1, [rsp]
0000705c0ade363b  add rsp, 0x30
0000705c0ade363f  vmovaps xmm0, [rsp]
0000705c0ade3644  vmovaps xmm2, [rsp+0x10]
0000705c0ade364a  vmovaps xmm3, [rsp+0x20]
0000705c0ade3650  vmovaps xmm4, [rsp+0x30]
0000705c0ade3656  vmovaps xmm5, [rsp+0x40]
0000705c0ade365c  vmovaps xmm6, [rsp+0x50]
0000705c0ade3662  vmovaps xmm7, [rsp+0x60]
0000705c0ade3668  vmovaps xmm8, [rsp+0x70]
0000705c0ade366e  vmovaps xmm9, [rsp+0x80]
0000705c0ade3677  vmovaps xmm10, [rsp+0x90]
0000705c0ade3680  vmovaps xmm11, [rsp+0xA0]
0000705c0ade3689  vmovaps xmm12, [rsp+0xB0]
0000705c0ade3692  vmovaps xmm13, [rsp+0xC0]
0000705c0ade369b  vmovaps xmm14, [rsp+0xD0]
0000705c0ade36a4  vmovaps xmm15, [rsp+0xE0]
0000705c0ade36ad  add rsp, 0xF0
0000705c0ade36b4  pop r11
0000705c0ade36b6  pop r10
0000705c0ade36b8  pop r9
0000705c0ade36ba  pop r8
0000705c0ade36bc  pop rsi
0000705c0ade36bd  pop rdi
0000705c0ade36be  pop rdx
0000705c0ade36bf  pop rcx
0000705c0ade36c0  pop rax
0000705c0ade36c1  add rsp, 0x08
0000705c0ade36c5  jmp 0x0000705C0ADDF7AD
0000705c0ade36ca  sub rsp, 0x08
0000705c0ade36ce  push rax
0000705c0ade36cf  push rcx
0000705c0ade36d0  push rdx
0000705c0ade36d1  push rdi
0000705c0ade36d2  push rsi
0000705c0ade36d3  push r8
0000705c0ade36d5  push r9
0000705c0ade36d7  push r10
0000705c0ade36d9  push r11
0000705c0ade36db  sub rsp, 0xF0
0000705c0ade36e2  vmovaps [rsp], xmm0
0000705c0ade36e7  vmovaps [rsp+0x10], xmm1
0000705c0ade36ed  vmovaps [rsp+0x20], xmm2
0000705c0ade36f3  vmovaps [rsp+0x30], xmm3
0000705c0ade36f9  vmovaps [rsp+0x40], xmm4
0000705c0ade36ff  vmovaps [rsp+0x50], xmm5
0000705c0ade3705  vmovaps [rsp+0x60], xmm6
0000705c0ade370b  vmovaps [rsp+0x70], xmm7
0000705c0ade3711  vmovaps [rsp+0x80], xmm8
0000705c0ade371a  vmovaps [rsp+0x90], xmm9
0000705c0ade3723  vmovaps [rsp+0xA0], xmm10
0000705c0ade372c  vmovaps [rsp+0xB0], xmm11
0000705c0ade3735  vmovaps [rsp+0xC0], xmm13
0000705c0ade373e  vmovaps [rsp+0xD0], xmm14
0000705c0ade3747  vmovaps [rsp+0xE0], xmm15
0000705c0ade3750  sub rsp, 0x30
0000705c0ade3754  movaps [rsp], xmm12
0000705c0ade3759  movaps [rsp+0x10], xmm7
0000705c0ade375e  movaps [rsp+0x20], xmm13
0000705c0ade3764  lea rdi, [rsp]
0000705c0ade3768  mov esi, 0x00
0000705c0ade376d  mov rax, 0x5969C28C4530
0000705c0ade3777  call rax
0000705c0ade3779  movaps xmm12, [rsp]
0000705c0ade377e  add rsp, 0x30
0000705c0ade3782  vmovaps xmm0, [rsp]
0000705c0ade3787  vmovaps xmm1, [rsp+0x10]
0000705c0ade378d  vmovaps xmm2, [rsp+0x20]
0000705c0ade3793  vmovaps xmm3, [rsp+0x30]
0000705c0ade3799  vmovaps xmm4, [rsp+0x40]
0000705c0ade379f  vmovaps xmm5, [rsp+0x50]
0000705c0ade37a5  vmovaps xmm6, [rsp+0x60]
0000705c0ade37ab  vmovaps xmm7, [rsp+0x70]
0000705c0ade37b1  vmovaps xmm8, [rsp+0x80]
0000705c0ade37ba  vmovaps xmm9, [rsp+0x90]
0000705c0ade37c3  vmovaps xmm10, [rsp+0xA0]
0000705c0ade37cc  vmovaps xmm11, [rsp+0xB0]
0000705c0ade37d5  vmovaps xmm13, [rsp+0xC0]
0000705c0ade37de  vmovaps xmm14, [rsp+0xD0]
0000705c0ade37e7  vmovaps xmm15, [rsp+0xE0]
0000705c0ade37f0  add rsp, 0xF0
0000705c0ade37f7  pop r11
0000705c0ade37f9  pop r10
0000705c0ade37fb  pop r9
0000705c0ade37fd  pop r8
0000705c0ade37ff  pop rsi
0000705c0ade3800  pop rdi
0000705c0ade3801  pop rdx
0000705c0ade3802  pop rcx
0000705c0ade3803  pop rax
0000705c0ade3804  add rsp, 0x08
0000705c0ade3808  jmp 0x0000705C0ADDF7D4
0000705c0ade380d  sub rsp, 0x08
0000705c0ade3811  push rax
0000705c0ade3812  push rcx
0000705c0ade3813  push rdx
0000705c0ade3814  push rdi
0000705c0ade3815  push rsi
0000705c0ade3816  push r8
0000705c0ade3818  push r9
0000705c0ade381a  push r10
0000705c0ade381c  push r11
0000705c0ade381e  sub rsp, 0xF0
0000705c0ade3825  vmovaps [rsp], xmm0
0000705c0ade382a  vmovaps [rsp+0x10], xmm1
0000705c0ade3830  vmovaps [rsp+0x20], xmm2
0000705c0ade3836  vmovaps [rsp+0x30], xmm3
0000705c0ade383c  vmovaps [rsp+0x40], xmm4
0000705c0ade3842  vmovaps [rsp+0x50], xmm5
0000705c0ade3848  vmovaps [rsp+0x60], xmm6
0000705c0ade384e  vmovaps [rsp+0x70], xmm7
0000705c0ade3854  vmovaps [rsp+0x80], xmm8
0000705c0ade385d  vmovaps [rsp+0x90], xmm9
0000705c0ade3866  vmovaps [rsp+0xA0], xmm10
0000705c0ade386f  vmovaps [rsp+0xB0], xmm11
0000705c0ade3878  vmovaps [rsp+0xC0], xmm12
0000705c0ade3881  vmovaps [rsp+0xD0], xmm14
0000705c0ade388a  vmovaps [rsp+0xE0], xmm15
0000705c0ade3893  sub rsp, 0x30
0000705c0ade3897  movaps [rsp], xmm13
0000705c0ade389c  movaps [rsp+0x10], xmm15
0000705c0ade38a2  movaps [rsp+0x20], xmm8
0000705c0ade38a8  lea rdi, [rsp]
0000705c0ade38ac  mov esi, 0x00
0000705c0ade38b1  mov rax, 0x5969C28C4530
0000705c0ade38bb  call rax
0000705c0ade38bd  movaps xmm13, [rsp]
0000705c0ade38c2  add rsp, 0x30
0000705c0ade38c6  vmovaps xmm0, [rsp]
0000705c0ade38cb  vmovaps xmm1, [rsp+0x10]
0000705c0ade38d1  vmovaps xmm2, [rsp+0x20]
0000705c0ade38d7  vmovaps xmm3, [rsp+0x30]
0000705c0ade38dd  vmovaps xmm4, [rsp+0x40]
0000705c0ade38e3  vmovaps xmm5, [rsp+0x50]
0000705c0ade38e9  vmovaps xmm6, [rsp+0x60]
0000705c0ade38ef  vmovaps xmm7, [rsp+0x70]
0000705c0ade38f5  vmovaps xmm8, [rsp+0x80]
0000705c0ade38fe  vmovaps xmm9, [rsp+0x90]
0000705c0ade3907  vmovaps xmm10, [rsp+0xA0]
0000705c0ade3910  vmovaps xmm11, [rsp+0xB0]
0000705c0ade3919  vmovaps xmm12, [rsp+0xC0]
0000705c0ade3922  vmovaps xmm14, [rsp+0xD0]
0000705c0ade392b  vmovaps xmm15, [rsp+0xE0]
0000705c0ade3934  add rsp, 0xF0
0000705c0ade393b  pop r11
0000705c0ade393d  pop r10
0000705c0ade393f  pop r9
0000705c0ade3941  pop r8
0000705c0ade3943  pop rsi
0000705c0ade3944  pop rdi
0000705c0ade3945  pop rdx
0000705c0ade3946  pop rcx
0000705c0ade3947  pop rax
0000705c0ade3948  add rsp, 0x08
0000705c0ade394c  jmp 0x0000705C0ADDF7EF
0000705c0ade3951  sub rsp, 0x08
0000705c0ade3955  push rax
0000705c0ade3956  push rcx
0000705c0ade3957  push rdx
0000705c0ade3958  push rdi
0000705c0ade3959  push rsi
0000705c0ade395a  push r8
0000705c0ade395c  push r9
0000705c0ade395e  push r10
0000705c0ade3960  push r11
0000705c0ade3962  sub rsp, 0xF0
0000705c0ade3969  vmovaps [rsp], xmm0
0000705c0ade396e  vmovaps [rsp+0x10], xmm1
0000705c0ade3974  vmovaps [rsp+0x20], xmm2
0000705c0ade397a  vmovaps [rsp+0x30], xmm3
0000705c0ade3980  vmovaps [rsp+0x40], xmm4
0000705c0ade3986  vmovaps [rsp+0x50], xmm5
0000705c0ade398c  vmovaps [rsp+0x60], xmm6
0000705c0ade3992  vmovaps [rsp+0x70], xmm7
0000705c0ade3998  vmovaps [rsp+0x80], xmm9
0000705c0ade39a1  vmovaps [rsp+0x90], xmm10
0000705c0ade39aa  vmovaps [rsp+0xA0], xmm11
0000705c0ade39b3  vmovaps [rsp+0xB0], xmm12
0000705c0ade39bc  vmovaps [rsp+0xC0], xmm13
0000705c0ade39c5  vmovaps [rsp+0xD0], xmm14
0000705c0ade39ce  vmovaps [rsp+0xE0], xmm15
0000705c0ade39d7  sub rsp, 0x30
0000705c0ade39db  movaps [rsp], xmm8
0000705c0ade39e0  movaps [rsp+0x10], xmm15
0000705c0ade39e6  movaps [rsp+0x20], xmm9
0000705c0ade39ec  lea rdi, [rsp]
0000705c0ade39f0  mov esi, 0x00
0000705c0ade39f5  mov rax, 0x5969C28C4530
0000705c0ade39ff  call rax
0000705c0ade3a01  movaps xmm8, [rsp]
0000705c0ade3a06  add rsp, 0x30
0000705c0ade3a0a  vmovaps xmm0, [rsp]
0000705c0ade3a0f  vmovaps xmm1, [rsp+0x10]
0000705c0ade3a15  vmovaps xmm2, [rsp+0x20]
0000705c0ade3a1b  vmovaps xmm3, [rsp+0x30]
0000705c0ade3a21  vmovaps xmm4, [rsp+0x40]
0000705c0ade3a27  vmovaps xmm5, [rsp+0x50]
0000705c0ade3a2d  vmovaps xmm6, [rsp+0x60]
0000705c0ade3a33  vmovaps xmm7, [rsp+0x70]
0000705c0ade3a39  vmovaps xmm9, [rsp+0x80]
0000705c0ade3a42  vmovaps xmm10, [rsp+0x90]
0000705c0ade3a4b  vmovaps xmm11, [rsp+0xA0]
0000705c0ade3a54  vmovaps xmm12, [rsp+0xB0]
0000705c0ade3a5d  vmovaps xmm13, [rsp+0xC0]
0000705c0ade3a66  vmovaps xmm14, [rsp+0xD0]
0000705c0ade3a6f  vmovaps xmm15, [rsp+0xE0]
0000705c0ade3a78  add rsp, 0xF0
0000705c0ade3a7f  pop r11
0000705c0ade3a81  pop r10
0000705c0ade3a83  pop r9
0000705c0ade3a85  pop r8
0000705c0ade3a87  pop rsi
0000705c0ade3a88  pop rdi
0000705c0ade3a89  pop rdx
0000705c0ade3a8a  pop rcx
0000705c0ade3a8b  pop rax
0000705c0ade3a8c  add rsp, 0x08
0000705c0ade3a90  jmp 0x0000705C0ADDF81D
0000705c0ade3a95  sub rsp, 0x08
0000705c0ade3a99  push rax
0000705c0ade3a9a  push rcx
0000705c0ade3a9b  push rdx
0000705c0ade3a9c  push rdi
0000705c0ade3a9d  push rsi
0000705c0ade3a9e  push r8
0000705c0ade3aa0  push r9
0000705c0ade3aa2  push r10
0000705c0ade3aa4  push r11
0000705c0ade3aa6  sub rsp, 0xF0
0000705c0ade3aad  vmovaps [rsp], xmm0
0000705c0ade3ab2  vmovaps [rsp+0x10], xmm1
0000705c0ade3ab8  vmovaps [rsp+0x20], xmm2
0000705c0ade3abe  vmovaps [rsp+0x30], xmm3
0000705c0ade3ac4  vmovaps [rsp+0x40], xmm4
0000705c0ade3aca  vmovaps [rsp+0x50], xmm5
0000705c0ade3ad0  vmovaps [rsp+0x60], xmm6
0000705c0ade3ad6  vmovaps [rsp+0x70], xmm7
0000705c0ade3adc  vmovaps [rsp+0x80], xmm8
0000705c0ade3ae5  vmovaps [rsp+0x90], xmm9
0000705c0ade3aee  vmovaps [rsp+0xA0], xmm10
0000705c0ade3af7  vmovaps [rsp+0xB0], xmm11
0000705c0ade3b00  vmovaps [rsp+0xC0], xmm12
0000705c0ade3b09  vmovaps [rsp+0xD0], xmm13
0000705c0ade3b12  vmovaps [rsp+0xE0], xmm14
0000705c0ade3b1b  sub rsp, 0x30
0000705c0ade3b1f  movaps [rsp], xmm15
0000705c0ade3b24  movaps [rsp+0x10], xmm11
0000705c0ade3b2a  movaps [rsp+0x20], xmm6
0000705c0ade3b2f  lea rdi, [rsp]
0000705c0ade3b33  mov esi, 0x00
0000705c0ade3b38  mov rax, 0x5969C28C4530
0000705c0ade3b42  call rax
0000705c0ade3b44  movaps xmm15, [rsp]
0000705c0ade3b49  add rsp, 0x30
0000705c0ade3b4d  vmovaps xmm0, [rsp]
0000705c0ade3b52  vmovaps xmm1, [rsp+0x10]
0000705c0ade3b58  vmovaps xmm2, [rsp+0x20]
0000705c0ade3b5e  vmovaps xmm3, [rsp+0x30]
0000705c0ade3b64  vmovaps xmm4, [rsp+0x40]
0000705c0ade3b6a  vmovaps xmm5, [rsp+0x50]
0000705c0ade3b70  vmovaps xmm6, [rsp+0x60]
0000705c0ade3b76  vmovaps xmm7, [rsp+0x70]
0000705c0ade3b7c  vmovaps xmm8, [rsp+0x80]
0000705c0ade3b85  vmovaps xmm9, [rsp+0x90]
0000705c0ade3b8e  vmovaps xmm10, [rsp+0xA0]
0000705c0ade3b97  vmovaps xmm11, [rsp+0xB0]
0000705c0ade3ba0  vmovaps xmm12, [rsp+0xC0]
0000705c0ade3ba9  vmovaps xmm13, [rsp+0xD0]
0000705c0ade3bb2  vmovaps xmm14, [rsp+0xE0]
0000705c0ade3bbb  add rsp, 0xF0
0000705c0ade3bc2  pop r11
0000705c0ade3bc4  pop r10
0000705c0ade3bc6  pop r9
0000705c0ade3bc8  pop r8
0000705c0ade3bca  pop rsi
0000705c0ade3bcb  pop rdi
0000705c0ade3bcc  pop rdx
0000705c0ade3bcd  pop rcx
0000705c0ade3bce  pop rax
0000705c0ade3bcf  add rsp, 0x08
0000705c0ade3bd3  jmp 0x0000705C0ADDF838
0000705c0ade3bd8  sub rsp, 0x08
0000705c0ade3bdc  push rax
0000705c0ade3bdd  push rcx
0000705c0ade3bde  push rdx
0000705c0ade3bdf  push rdi
0000705c0ade3be0  push rsi
0000705c0ade3be1  push r8
0000705c0ade3be3  push r9
0000705c0ade3be5  push r10
0000705c0ade3be7  push r11
0000705c0ade3be9  sub rsp, 0xF0
0000705c0ade3bf0  vmovaps [rsp], xmm0
0000705c0ade3bf5  vmovaps [rsp+0x10], xmm1
0000705c0ade3bfb  vmovaps [rsp+0x20], xmm2
0000705c0ade3c01  vmovaps [rsp+0x30], xmm3
0000705c0ade3c07  vmovaps [rsp+0x40], xmm4
0000705c0ade3c0d  vmovaps [rsp+0x50], xmm5
0000705c0ade3c13  vmovaps [rsp+0x60], xmm6
0000705c0ade3c19  vmovaps [rsp+0x70], xmm8
0000705c0ade3c1f  vmovaps [rsp+0x80], xmm9
0000705c0ade3c28  vmovaps [rsp+0x90], xmm10
0000705c0ade3c31  vmovaps [rsp+0xA0], xmm11
0000705c0ade3c3a  vmovaps [rsp+0xB0], xmm12
0000705c0ade3c43  vmovaps [rsp+0xC0], xmm13
0000705c0ade3c4c  vmovaps [rsp+0xD0], xmm14
0000705c0ade3c55  vmovaps [rsp+0xE0], xmm15
0000705c0ade3c5e  sub rsp, 0x30
0000705c0ade3c62  movaps [rsp], xmm7
0000705c0ade3c66  movaps [rsp+0x10], xmm11
0000705c0ade3c6c  movaps [rsp+0x20], xmm9
0000705c0ade3c72  lea rdi, [rsp]
0000705c0ade3c76  mov esi, 0x00
0000705c0ade3c7b  mov rax, 0x5969C28C4530
0000705c0ade3c85  call rax
0000705c0ade3c87  movaps xmm7, [rsp]
0000705c0ade3c8b  add rsp, 0x30
0000705c0ade3c8f  vmovaps xmm0, [rsp]
0000705c0ade3c94  vmovaps xmm1, [rsp+0x10]
0000705c0ade3c9a  vmovaps xmm2, [rsp+0x20]
0000705c0ade3ca0  vmovaps xmm3, [rsp+0x30]
0000705c0ade3ca6  vmovaps xmm4, [rsp+0x40]
0000705c0ade3cac  vmovaps xmm5, [rsp+0x50]
0000705c0ade3cb2  vmovaps xmm6, [rsp+0x60]
0000705c0ade3cb8  vmovaps xmm8, [rsp+0x70]
0000705c0ade3cbe  vmovaps xmm9, [rsp+0x80]
0000705c0ade3cc7  vmovaps xmm10, [rsp+0x90]
0000705c0ade3cd0  vmovaps xmm11, [rsp+0xA0]
0000705c0ade3cd9  vmovaps xmm12, [rsp+0xB0]
0000705c0ade3ce2  vmovaps xmm13, [rsp+0xC0]
0000705c0ade3ceb  vmovaps xmm14, [rsp+0xD0]
0000705c0ade3cf4  vmovaps xmm15, [rsp+0xE0]
0000705c0ade3cfd  add rsp, 0xF0
0000705c0ade3d04  pop r11
0000705c0ade3d06  pop r10
0000705c0ade3d08  pop r9
0000705c0ade3d0a  pop r8
0000705c0ade3d0c  pop rsi
0000705c0ade3d0d  pop rdi
0000705c0ade3d0e  pop rdx
0000705c0ade3d0f  pop rcx
0000705c0ade3d10  pop rax
0000705c0ade3d11  add rsp, 0x08
0000705c0ade3d15  jmp 0x0000705C0ADDF865
0000705c0ade3d1a  sub rsp, 0x08
0000705c0ade3d1e  push rax
0000705c0ade3d1f  push rcx
0000705c0ade3d20  push rdx
0000705c0ade3d21  push rdi
0000705c0ade3d22  push rsi
0000705c0ade3d23  push r8
0000705c0ade3d25  push r9
0000705c0ade3d27  push r10
0000705c0ade3d29  push r11
0000705c0ade3d2b  sub rsp, 0xF0
0000705c0ade3d32  vmovaps [rsp], xmm0
0000705c0ade3d37  vmovaps [rsp+0x10], xmm1
0000705c0ade3d3d  vmovaps [rsp+0x20], xmm2
0000705c0ade3d43  vmovaps [rsp+0x30], xmm3
0000705c0ade3d49  vmovaps [rsp+0x40], xmm4
0000705c0ade3d4f  vmovaps [rsp+0x50], xmm5
0000705c0ade3d55  vmovaps [rsp+0x60], xmm6
0000705c0ade3d5b  vmovaps [rsp+0x70], xmm7
0000705c0ade3d61  vmovaps [rsp+0x80], xmm8
0000705c0ade3d6a  vmovaps [rsp+0x90], xmm9
0000705c0ade3d73  vmovaps [rsp+0xA0], xmm10
0000705c0ade3d7c  vmovaps [rsp+0xB0], xmm12
0000705c0ade3d85  vmovaps [rsp+0xC0], xmm13
0000705c0ade3d8e  vmovaps [rsp+0xD0], xmm14
0000705c0ade3d97  vmovaps [rsp+0xE0], xmm15
0000705c0ade3da0  sub rsp, 0x30
0000705c0ade3da4  movaps [rsp], xmm11
0000705c0ade3da9  movaps [rsp+0x10], xmm10
0000705c0ade3daf  movaps [rsp+0x20], xmm14
0000705c0ade3db5  lea rdi, [rsp]
0000705c0ade3db9  mov esi, 0x00
0000705c0ade3dbe  mov rax, 0x5969C28C4530
0000705c0ade3dc8  call rax
0000705c0ade3dca  movaps xmm11, [rsp]
0000705c0ade3dcf  add rsp, 0x30
0000705c0ade3dd3  vmovaps xmm0, [rsp]
0000705c0ade3dd8  vmovaps xmm1, [rsp+0x10]
0000705c0ade3dde  vmovaps xmm2, [rsp+0x20]
0000705c0ade3de4  vmovaps xmm3, [rsp+0x30]
0000705c0ade3dea  vmovaps xmm4, [rsp+0x40]
0000705c0ade3df0  vmovaps xmm5, [rsp+0x50]
0000705c0ade3df6  vmovaps xmm6, [rsp+0x60]
0000705c0ade3dfc  vmovaps xmm7, [rsp+0x70]
0000705c0ade3e02  vmovaps xmm8, [rsp+0x80]
0000705c0ade3e0b  vmovaps xmm9, [rsp+0x90]
0000705c0ade3e14  vmovaps xmm10, [rsp+0xA0]
0000705c0ade3e1d  vmovaps xmm12, [rsp+0xB0]
0000705c0ade3e26  vmovaps xmm13, [rsp+0xC0]
0000705c0ade3e2f  vmovaps xmm14, [rsp+0xD0]
0000705c0ade3e38  vmovaps xmm15, [rsp+0xE0]
0000705c0ade3e41  add rsp, 0xF0
0000705c0ade3e48  pop r11
0000705c0ade3e4a  pop r10
0000705c0ade3e4c  pop r9
0000705c0ade3e4e  pop r8
0000705c0ade3e50  pop rsi
0000705c0ade3e51  pop rdi
0000705c0ade3e52  pop rdx
0000705c0ade3e53  pop rcx
0000705c0ade3e54  pop rax
0000705c0ade3e55  add rsp, 0x08
0000705c0ade3e59  jmp 0x0000705C0ADDF880
0000705c0ade3e5e  call 0x0000705C0ACC33A0
0000705c0ade3e63  jmp 0x0000705C0ADDF88A
0000705c0ade3e68  sub rsp, 0x08
0000705c0ade3e6c  push rax
0000705c0ade3e6d  push rcx
0000705c0ade3e6e  push rdx
0000705c0ade3e6f  push rdi
0000705c0ade3e70  push rsi
0000705c0ade3e71  push r8
0000705c0ade3e73  push r9
0000705c0ade3e75  push r10
0000705c0ade3e77  push r11
0000705c0ade3e79  sub rsp, 0xF0
0000705c0ade3e80  vmovaps [rsp], xmm0
0000705c0ade3e85  vmovaps [rsp+0x10], xmm1
0000705c0ade3e8b  vmovaps [rsp+0x20], xmm2
0000705c0ade3e91  vmovaps [rsp+0x30], xmm3
0000705c0ade3e97  vmovaps [rsp+0x40], xmm4
0000705c0ade3e9d  vmovaps [rsp+0x50], xmm5
0000705c0ade3ea3  vmovaps [rsp+0x60], xmm6
0000705c0ade3ea9  vmovaps [rsp+0x70], xmm7
0000705c0ade3eaf  vmovaps [rsp+0x80], xmm8
0000705c0ade3eb8  vmovaps [rsp+0x90], xmm9
0000705c0ade3ec1  vmovaps [rsp+0xA0], xmm11
0000705c0ade3eca  vmovaps [rsp+0xB0], xmm12
0000705c0ade3ed3  vmovaps [rsp+0xC0], xmm13
0000705c0ade3edc  vmovaps [rsp+0xD0], xmm14
0000705c0ade3ee5  vmovaps [rsp+0xE0], xmm15
0000705c0ade3eee  sub rsp, 0x30
0000705c0ade3ef2  movaps [rsp], xmm10
0000705c0ade3ef7  movaps [rsp+0x10], xmm1
0000705c0ade3efc  movaps [rsp+0x20], xmm12
0000705c0ade3f02  lea rdi, [rsp]
0000705c0ade3f06  mov esi, 0x00
0000705c0ade3f0b  mov rax, 0x5969C28C4530
0000705c0ade3f15  call rax
0000705c0ade3f17  movaps xmm10, [rsp]
0000705c0ade3f1c  add rsp, 0x30
0000705c0ade3f20  vmovaps xmm0, [rsp]
0000705c0ade3f25  vmovaps xmm1, [rsp+0x10]
0000705c0ade3f2b  vmovaps xmm2, [rsp+0x20]
0000705c0ade3f31  vmovaps xmm3, [rsp+0x30]
0000705c0ade3f37  vmovaps xmm4, [rsp+0x40]
0000705c0ade3f3d  vmovaps xmm5, [rsp+0x50]
0000705c0ade3f43  vmovaps xmm6, [rsp+0x60]
0000705c0ade3f49  vmovaps xmm7, [rsp+0x70]
0000705c0ade3f4f  vmovaps xmm8, [rsp+0x80]
0000705c0ade3f58  vmovaps xmm9, [rsp+0x90]
0000705c0ade3f61  vmovaps xmm11, [rsp+0xA0]
0000705c0ade3f6a  vmovaps xmm12, [rsp+0xB0]
0000705c0ade3f73  vmovaps xmm13, [rsp+0xC0]
0000705c0ade3f7c  vmovaps xmm14, [rsp+0xD0]
0000705c0ade3f85  vmovaps xmm15, [rsp+0xE0]
0000705c0ade3f8e  add rsp, 0xF0
0000705c0ade3f95  pop r11
0000705c0ade3f97  pop r10
0000705c0ade3f99  pop r9
0000705c0ade3f9b  pop r8
0000705c0ade3f9d  pop rsi
0000705c0ade3f9e  pop rdi
0000705c0ade3f9f  pop rdx
0000705c0ade3fa0  pop rcx
0000705c0ade3fa1  pop rax
0000705c0ade3fa2  add rsp, 0x08
0000705c0ade3fa6  jmp 0x0000705C0ADDF8AD
0000705c0ade3fab  sub rsp, 0x08
0000705c0ade3faf  push rax
0000705c0ade3fb0  push rcx
0000705c0ade3fb1  push rdx
0000705c0ade3fb2  push rdi
0000705c0ade3fb3  push rsi
0000705c0ade3fb4  push r8
0000705c0ade3fb6  push r9
0000705c0ade3fb8  push r10
0000705c0ade3fba  push r11
0000705c0ade3fbc  sub rsp, 0xF0
0000705c0ade3fc3  vmovaps [rsp], xmm0
0000705c0ade3fc8  vmovaps [rsp+0x10], xmm1
0000705c0ade3fce  vmovaps [rsp+0x20], xmm2
0000705c0ade3fd4  vmovaps [rsp+0x30], xmm3
0000705c0ade3fda  vmovaps [rsp+0x40], xmm4
0000705c0ade3fe0  vmovaps [rsp+0x50], xmm5
0000705c0ade3fe6  vmovaps [rsp+0x60], xmm6
0000705c0ade3fec  vmovaps [rsp+0x70], xmm7
0000705c0ade3ff2  vmovaps [rsp+0x80], xmm8
0000705c0ade3ffb  vmovaps [rsp+0x90], xmm9
0000705c0ade4004  vmovaps [rsp+0xA0], xmm10
0000705c0ade400d  vmovaps [rsp+0xB0], xmm11
0000705c0ade4016  vmovaps [rsp+0xC0], xmm13
0000705c0ade401f  vmovaps [rsp+0xD0], xmm14
0000705c0ade4028  vmovaps [rsp+0xE0], xmm15
0000705c0ade4031  sub rsp, 0x30
0000705c0ade4035  movaps [rsp], xmm12
0000705c0ade403a  movaps [rsp+0x10], xmm14
0000705c0ade4040  movaps [rsp+0x20], xmm1
0000705c0ade4045  lea rdi, [rsp]
0000705c0ade4049  mov esi, 0x00
0000705c0ade404e  mov rax, 0x5969C28C4530
0000705c0ade4058  call rax
0000705c0ade405a  movaps xmm12, [rsp]
0000705c0ade405f  add rsp, 0x30
0000705c0ade4063  vmovaps xmm0, [rsp]
0000705c0ade4068  vmovaps xmm1, [rsp+0x10]
0000705c0ade406e  vmovaps xmm2, [rsp+0x20]
0000705c0ade4074  vmovaps xmm3, [rsp+0x30]
0000705c0ade407a  vmovaps xmm4, [rsp+0x40]
0000705c0ade4080  vmovaps xmm5, [rsp+0x50]
0000705c0ade4086  vmovaps xmm6, [rsp+0x60]
0000705c0ade408c  vmovaps xmm7, [rsp+0x70]
0000705c0ade4092  vmovaps xmm8, [rsp+0x80]
0000705c0ade409b  vmovaps xmm9, [rsp+0x90]
0000705c0ade40a4  vmovaps xmm10, [rsp+0xA0]
0000705c0ade40ad  vmovaps xmm11, [rsp+0xB0]
0000705c0ade40b6  vmovaps xmm13, [rsp+0xC0]
0000705c0ade40bf  vmovaps xmm14, [rsp+0xD0]
0000705c0ade40c8  vmovaps xmm15, [rsp+0xE0]
0000705c0ade40d1  add rsp, 0xF0
0000705c0ade40d8  pop r11
0000705c0ade40da  pop r10
0000705c0ade40dc  pop r9
0000705c0ade40de  pop r8
0000705c0ade40e0  pop rsi
0000705c0ade40e1  pop rdi
0000705c0ade40e2  pop rdx
0000705c0ade40e3  pop rcx
0000705c0ade40e4  pop rax
0000705c0ade40e5  add rsp, 0x08
0000705c0ade40e9  jmp 0x0000705C0ADDF8DC
0000705c0ade40ee  sub rsp, 0x08
0000705c0ade40f2  push rax
0000705c0ade40f3  push rcx
0000705c0ade40f4  push rdx
0000705c0ade40f5  push rdi
0000705c0ade40f6  push rsi
0000705c0ade40f7  push r8
0000705c0ade40f9  push r9
0000705c0ade40fb  push r10
0000705c0ade40fd  push r11
0000705c0ade40ff  sub rsp, 0xF0
0000705c0ade4106  vmovaps [rsp], xmm0
0000705c0ade410b  vmovaps [rsp+0x10], xmm1
0000705c0ade4111  vmovaps [rsp+0x20], xmm2
0000705c0ade4117  vmovaps [rsp+0x30], xmm3
0000705c0ade411d  vmovaps [rsp+0x40], xmm4
0000705c0ade4123  vmovaps [rsp+0x50], xmm5
0000705c0ade4129  vmovaps [rsp+0x60], xmm6
0000705c0ade412f  vmovaps [rsp+0x70], xmm7
0000705c0ade4135  vmovaps [rsp+0x80], xmm8
0000705c0ade413e  vmovaps [rsp+0x90], xmm9
0000705c0ade4147  vmovaps [rsp+0xA0], xmm10
0000705c0ade4150  vmovaps [rsp+0xB0], xmm11
0000705c0ade4159  vmovaps [rsp+0xC0], xmm12
0000705c0ade4162  vmovaps [rsp+0xD0], xmm13
0000705c0ade416b  vmovaps [rsp+0xE0], xmm15
0000705c0ade4174  sub rsp, 0x30
0000705c0ade4178  movaps [rsp], xmm14
0000705c0ade417d  movaps [rsp+0x10], xmm9
0000705c0ade4183  movaps [rsp+0x20], xmm1
0000705c0ade4188  lea rdi, [rsp]
0000705c0ade418c  mov esi, 0x00
0000705c0ade4191  mov rax, 0x5969C28C4530
0000705c0ade419b  call rax
0000705c0ade419d  movaps xmm14, [rsp]
0000705c0ade41a2  add rsp, 0x30
0000705c0ade41a6  vmovaps xmm0, [rsp]
0000705c0ade41ab  vmovaps xmm1, [rsp+0x10]
0000705c0ade41b1  vmovaps xmm2, [rsp+0x20]
0000705c0ade41b7  vmovaps xmm3, [rsp+0x30]
0000705c0ade41bd  vmovaps xmm4, [rsp+0x40]
0000705c0ade41c3  vmovaps xmm5, [rsp+0x50]
0000705c0ade41c9  vmovaps xmm6, [rsp+0x60]
0000705c0ade41cf  vmovaps xmm7, [rsp+0x70]
0000705c0ade41d5  vmovaps xmm8, [rsp+0x80]
0000705c0ade41de  vmovaps xmm9, [rsp+0x90]
0000705c0ade41e7  vmovaps xmm10, [rsp+0xA0]
0000705c0ade41f0  vmovaps xmm11, [rsp+0xB0]
0000705c0ade41f9  vmovaps xmm12, [rsp+0xC0]
0000705c0ade4202  vmovaps xmm13, [rsp+0xD0]
0000705c0ade420b  vmovaps xmm15, [rsp+0xE0]
0000705c0ade4214  add rsp, 0xF0
0000705c0ade421b  pop r11
0000705c0ade421d  pop r10
0000705c0ade421f  pop r9
0000705c0ade4221  pop r8
0000705c0ade4223  pop rsi
0000705c0ade4224  pop rdi
0000705c0ade4225  pop rdx
0000705c0ade4226  pop rcx
0000705c0ade4227  pop rax
0000705c0ade4228  add rsp, 0x08
0000705c0ade422c  jmp 0x0000705C0ADDF90B
0000705c0ade4231  sub rsp, 0x08
0000705c0ade4235  push rax
0000705c0ade4236  push rcx
0000705c0ade4237  push rdx
0000705c0ade4238  push rdi
0000705c0ade4239  push rsi
0000705c0ade423a  push r8
0000705c0ade423c  push r9
0000705c0ade423e  push r10
0000705c0ade4240  push r11
0000705c0ade4242  sub rsp, 0xF0
0000705c0ade4249  vmovaps [rsp], xmm0
0000705c0ade424e  vmovaps [rsp+0x10], xmm2
0000705c0ade4254  vmovaps [rsp+0x20], xmm3
0000705c0ade425a  vmovaps [rsp+0x30], xmm4
0000705c0ade4260  vmovaps [rsp+0x40], xmm5
0000705c0ade4266  vmovaps [rsp+0x50], xmm6
0000705c0ade426c  vmovaps [rsp+0x60], xmm7
0000705c0ade4272  vmovaps [rsp+0x70], xmm8
0000705c0ade4278  vmovaps [rsp+0x80], xmm9
0000705c0ade4281  vmovaps [rsp+0x90], xmm10
0000705c0ade428a  vmovaps [rsp+0xA0], xmm11
0000705c0ade4293  vmovaps [rsp+0xB0], xmm12
0000705c0ade429c  vmovaps [rsp+0xC0], xmm13
0000705c0ade42a5  vmovaps [rsp+0xD0], xmm14
0000705c0ade42ae  vmovaps [rsp+0xE0], xmm15
0000705c0ade42b7  sub rsp, 0x30
0000705c0ade42bb  movaps [rsp], xmm1
0000705c0ade42bf  movaps [rsp+0x10], xmm13
0000705c0ade42c5  movaps [rsp+0x20], xmm8
0000705c0ade42cb  lea rdi, [rsp]
0000705c0ade42cf  mov esi, 0x00
0000705c0ade42d4  mov rax, 0x5969C28C4530
0000705c0ade42de  call rax
0000705c0ade42e0  movaps xmm1, [rsp]
0000705c0ade42e4  add rsp, 0x30
0000705c0ade42e8  vmovaps xmm0, [rsp]
0000705c0ade42ed  vmovaps xmm2, [rsp+0x10]
0000705c0ade42f3  vmovaps xmm3, [rsp+0x20]
0000705c0ade42f9  vmovaps xmm4, [rsp+0x30]
0000705c0ade42ff  vmovaps xmm5, [rsp+0x40]
0000705c0ade4305  vmovaps xmm6, [rsp+0x50]
0000705c0ade430b  vmovaps xmm7, [rsp+0x60]
0000705c0ade4311  vmovaps xmm8, [rsp+0x70]
0000705c0ade4317  vmovaps xmm9, [rsp+0x80]
0000705c0ade4320  vmovaps xmm10, [rsp+0x90]
0000705c0ade4329  vmovaps xmm11, [rsp+0xA0]
0000705c0ade4332  vmovaps xmm12, [rsp+0xB0]
0000705c0ade433b  vmovaps xmm13, [rsp+0xC0]
0000705c0ade4344  vmovaps xmm14, [rsp+0xD0]
0000705c0ade434d  vmovaps xmm15, [rsp+0xE0]
0000705c0ade4356  add rsp, 0xF0
0000705c0ade435d  pop r11
0000705c0ade435f  pop r10
0000705c0ade4361  pop r9
0000705c0ade4363  pop r8
0000705c0ade4365  pop rsi
0000705c0ade4366  pop rdi
0000705c0ade4367  pop rdx
0000705c0ade4368  pop rcx
0000705c0ade4369  pop rax
0000705c0ade436a  add rsp, 0x08
0000705c0ade436e  jmp 0x0000705C0ADDF92D
0000705c0ade4373  call 0x0000705C0AC0C260
0000705c0ade4378  jmp 0x0000705C0ADDF93B
0000705c0ade437d  call 0x0000705C0ACBD750
0000705c0ade4382  jmp 0x0000705C0ADDF945
0000705c0ade4387  sub rsp, 0x08
0000705c0ade438b  push rax
0000705c0ade438c  push rcx
0000705c0ade438d  push rdx
0000705c0ade438e  push rdi
0000705c0ade438f  push rsi
0000705c0ade4390  push r8
0000705c0ade4392  push r9
0000705c0ade4394  push r10
0000705c0ade4396  push r11
0000705c0ade4398  sub rsp, 0xF0
0000705c0ade439f  vmovaps [rsp], xmm0
0000705c0ade43a4  vmovaps [rsp+0x10], xmm1
0000705c0ade43aa  vmovaps [rsp+0x20], xmm2
0000705c0ade43b0  vmovaps [rsp+0x30], xmm3
0000705c0ade43b6  vmovaps [rsp+0x40], xmm4
0000705c0ade43bc  vmovaps [rsp+0x50], xmm5
0000705c0ade43c2  vmovaps [rsp+0x60], xmm6
0000705c0ade43c8  vmovaps [rsp+0x70], xmm7
0000705c0ade43ce  vmovaps [rsp+0x80], xmm9
0000705c0ade43d7  vmovaps [rsp+0x90], xmm10
0000705c0ade43e0  vmovaps [rsp+0xA0], xmm11
0000705c0ade43e9  vmovaps [rsp+0xB0], xmm12
0000705c0ade43f2  vmovaps [rsp+0xC0], xmm13
0000705c0ade43fb  vmovaps [rsp+0xD0], xmm14
0000705c0ade4404  vmovaps [rsp+0xE0], xmm15
0000705c0ade440d  sub rsp, 0x30
0000705c0ade4411  movaps [rsp], xmm8
0000705c0ade4416  movaps [rsp+0x10], xmm15
0000705c0ade441c  movaps [rsp+0x20], xmm7
0000705c0ade4421  lea rdi, [rsp]
0000705c0ade4425  mov esi, 0x00
0000705c0ade442a  mov rax, 0x5969C28C4530
0000705c0ade4434  call rax
0000705c0ade4436  movaps xmm8, [rsp]
0000705c0ade443b  add rsp, 0x30
0000705c0ade443f  vmovaps xmm0, [rsp]
0000705c0ade4444  vmovaps xmm1, [rsp+0x10]
0000705c0ade444a  vmovaps xmm2, [rsp+0x20]
0000705c0ade4450  vmovaps xmm3, [rsp+0x30]
0000705c0ade4456  vmovaps xmm4, [rsp+0x40]
0000705c0ade445c  vmovaps xmm5, [rsp+0x50]
0000705c0ade4462  vmovaps xmm6, [rsp+0x60]
0000705c0ade4468  vmovaps xmm7, [rsp+0x70]
0000705c0ade446e  vmovaps xmm9, [rsp+0x80]
0000705c0ade4477  vmovaps xmm10, [rsp+0x90]
0000705c0ade4480  vmovaps xmm11, [rsp+0xA0]
0000705c0ade4489  vmovaps xmm12, [rsp+0xB0]
0000705c0ade4492  vmovaps xmm13, [rsp+0xC0]
0000705c0ade449b  vmovaps xmm14, [rsp+0xD0]
0000705c0ade44a4  vmovaps xmm15, [rsp+0xE0]
0000705c0ade44ad  add rsp, 0xF0
0000705c0ade44b4  pop r11
0000705c0ade44b6  pop r10
0000705c0ade44b8  pop r9
0000705c0ade44ba  pop r8
0000705c0ade44bc  pop rsi
0000705c0ade44bd  pop rdi
0000705c0ade44be  pop rdx
0000705c0ade44bf  pop rcx
0000705c0ade44c0  pop rax
0000705c0ade44c1  add rsp, 0x08
0000705c0ade44c5  jmp 0x0000705C0ADDF967
0000705c0ade44ca  sub rsp, 0x08
0000705c0ade44ce  push rax
0000705c0ade44cf  push rcx
0000705c0ade44d0  push rdx
0000705c0ade44d1  push rdi
0000705c0ade44d2  push rsi
0000705c0ade44d3  push r8
0000705c0ade44d5  push r9
0000705c0ade44d7  push r10
0000705c0ade44d9  push r11
0000705c0ade44db  sub rsp, 0xF0
0000705c0ade44e2  vmovaps [rsp], xmm0
0000705c0ade44e7  vmovaps [rsp+0x10], xmm1
0000705c0ade44ed  vmovaps [rsp+0x20], xmm2
0000705c0ade44f3  vmovaps [rsp+0x30], xmm3
0000705c0ade44f9  vmovaps [rsp+0x40], xmm4
0000705c0ade44ff  vmovaps [rsp+0x50], xmm5
0000705c0ade4505  vmovaps [rsp+0x60], xmm6
0000705c0ade450b  vmovaps [rsp+0x70], xmm8
0000705c0ade4511  vmovaps [rsp+0x80], xmm9
0000705c0ade451a  vmovaps [rsp+0x90], xmm10
0000705c0ade4523  vmovaps [rsp+0xA0], xmm11
0000705c0ade452c  vmovaps [rsp+0xB0], xmm12
0000705c0ade4535  vmovaps [rsp+0xC0], xmm13
0000705c0ade453e  vmovaps [rsp+0xD0], xmm14
0000705c0ade4547  vmovaps [rsp+0xE0], xmm15
0000705c0ade4550  sub rsp, 0x30
0000705c0ade4554  movaps [rsp], xmm7
0000705c0ade4558  movaps [rsp+0x10], xmm9
0000705c0ade455e  movaps [rsp+0x20], xmm15
0000705c0ade4564  lea rdi, [rsp]
0000705c0ade4568  mov esi, 0x00
0000705c0ade456d  mov rax, 0x5969C28C4530
0000705c0ade4577  call rax
0000705c0ade4579  movaps xmm7, [rsp]
0000705c0ade457d  add rsp, 0x30
0000705c0ade4581  vmovaps xmm0, [rsp]
0000705c0ade4586  vmovaps xmm1, [rsp+0x10]
0000705c0ade458c  vmovaps xmm2, [rsp+0x20]
0000705c0ade4592  vmovaps xmm3, [rsp+0x30]
0000705c0ade4598  vmovaps xmm4, [rsp+0x40]
0000705c0ade459e  vmovaps xmm5, [rsp+0x50]
0000705c0ade45a4  vmovaps xmm6, [rsp+0x60]
0000705c0ade45aa  vmovaps xmm8, [rsp+0x70]
0000705c0ade45b0  vmovaps xmm9, [rsp+0x80]
0000705c0ade45b9  vmovaps xmm10, [rsp+0x90]
0000705c0ade45c2  vmovaps xmm11, [rsp+0xA0]
0000705c0ade45cb  vmovaps xmm12, [rsp+0xB0]
0000705c0ade45d4  vmovaps xmm13, [rsp+0xC0]
0000705c0ade45dd  vmovaps xmm14, [rsp+0xD0]
0000705c0ade45e6  vmovaps xmm15, [rsp+0xE0]
0000705c0ade45ef  add rsp, 0xF0
0000705c0ade45f6  pop r11
0000705c0ade45f8  pop r10
0000705c0ade45fa  pop r9
0000705c0ade45fc  pop r8
0000705c0ade45fe  pop rsi
0000705c0ade45ff  pop rdi
0000705c0ade4600  pop rdx
0000705c0ade4601  pop rcx
0000705c0ade4602  pop rax
0000705c0ade4603  add rsp, 0x08
0000705c0ade4607  jmp 0x0000705C0ADDF994
0000705c0ade460c  sub rsp, 0x08
0000705c0ade4610  push rax
0000705c0ade4611  push rcx
0000705c0ade4612  push rdx
0000705c0ade4613  push rdi
0000705c0ade4614  push rsi
0000705c0ade4615  push r8
0000705c0ade4617  push r9
0000705c0ade4619  push r10
0000705c0ade461b  push r11
0000705c0ade461d  sub rsp, 0xF0
0000705c0ade4624  vmovaps [rsp], xmm0
0000705c0ade4629  vmovaps [rsp+0x10], xmm1
0000705c0ade462f  vmovaps [rsp+0x20], xmm2
0000705c0ade4635  vmovaps [rsp+0x30], xmm3
0000705c0ade463b  vmovaps [rsp+0x40], xmm4
0000705c0ade4641  vmovaps [rsp+0x50], xmm5
0000705c0ade4647  vmovaps [rsp+0x60], xmm6
0000705c0ade464d  vmovaps [rsp+0x70], xmm7
0000705c0ade4653  vmovaps [rsp+0x80], xmm8
0000705c0ade465c  vmovaps [rsp+0x90], xmm10
0000705c0ade4665  vmovaps [rsp+0xA0], xmm11
0000705c0ade466e  vmovaps [rsp+0xB0], xmm12
0000705c0ade4677  vmovaps [rsp+0xC0], xmm13
0000705c0ade4680  vmovaps [rsp+0xD0], xmm14
0000705c0ade4689  vmovaps [rsp+0xE0], xmm15
0000705c0ade4692  sub rsp, 0x30
0000705c0ade4696  movaps [rsp], xmm9
0000705c0ade469b  movaps [rsp+0x10], xmm13
0000705c0ade46a1  movaps [rsp+0x20], xmm15
0000705c0ade46a7  lea rdi, [rsp]
0000705c0ade46ab  mov esi, 0x00
0000705c0ade46b0  mov rax, 0x5969C28C4530
0000705c0ade46ba  call rax
0000705c0ade46bc  movaps xmm9, [rsp]
0000705c0ade46c1  add rsp, 0x30
0000705c0ade46c5  vmovaps xmm0, [rsp]
0000705c0ade46ca  vmovaps xmm1, [rsp+0x10]
0000705c0ade46d0  vmovaps xmm2, [rsp+0x20]
0000705c0ade46d6  vmovaps xmm3, [rsp+0x30]
0000705c0ade46dc  vmovaps xmm4, [rsp+0x40]
0000705c0ade46e2  vmovaps xmm5, [rsp+0x50]
0000705c0ade46e8  vmovaps xmm6, [rsp+0x60]
0000705c0ade46ee  vmovaps xmm7, [rsp+0x70]
0000705c0ade46f4  vmovaps xmm8, [rsp+0x80]
0000705c0ade46fd  vmovaps xmm10, [rsp+0x90]
0000705c0ade4706  vmovaps xmm11, [rsp+0xA0]
0000705c0ade470f  vmovaps xmm12, [rsp+0xB0]
0000705c0ade4718  vmovaps xmm13, [rsp+0xC0]
0000705c0ade4721  vmovaps xmm14, [rsp+0xD0]
0000705c0ade472a  vmovaps xmm15, [rsp+0xE0]
0000705c0ade4733  add rsp, 0xF0
0000705c0ade473a  pop r11
0000705c0ade473c  pop r10
0000705c0ade473e  pop r9
0000705c0ade4740  pop r8
0000705c0ade4742  pop rsi
0000705c0ade4743  pop rdi
0000705c0ade4744  pop rdx
0000705c0ade4745  pop rcx
0000705c0ade4746  pop rax
0000705c0ade4747  add rsp, 0x08
0000705c0ade474b  jmp 0x0000705C0ADDF9C2
0000705c0ade4750  sub rsp, 0x08
0000705c0ade4754  push rax
0000705c0ade4755  push rcx
0000705c0ade4756  push rdx
0000705c0ade4757  push rdi
0000705c0ade4758  push rsi
0000705c0ade4759  push r8
0000705c0ade475b  push r9
0000705c0ade475d  push r10
0000705c0ade475f  push r11
0000705c0ade4761  sub rsp, 0xF0
0000705c0ade4768  vmovaps [rsp], xmm0
0000705c0ade476d  vmovaps [rsp+0x10], xmm1
0000705c0ade4773  vmovaps [rsp+0x20], xmm2
0000705c0ade4779  vmovaps [rsp+0x30], xmm3
0000705c0ade477f  vmovaps [rsp+0x40], xmm4
0000705c0ade4785  vmovaps [rsp+0x50], xmm5
0000705c0ade478b  vmovaps [rsp+0x60], xmm6
0000705c0ade4791  vmovaps [rsp+0x70], xmm7
0000705c0ade4797  vmovaps [rsp+0x80], xmm8
0000705c0ade47a0  vmovaps [rsp+0x90], xmm9
0000705c0ade47a9  vmovaps [rsp+0xA0], xmm10
0000705c0ade47b2  vmovaps [rsp+0xB0], xmm11
0000705c0ade47bb  vmovaps [rsp+0xC0], xmm12
0000705c0ade47c4  vmovaps [rsp+0xD0], xmm13
0000705c0ade47cd  vmovaps [rsp+0xE0], xmm14
0000705c0ade47d6  sub rsp, 0x30
0000705c0ade47da  movaps [rsp], xmm15
0000705c0ade47df  movaps [rsp+0x10], xmm11
0000705c0ade47e5  movaps [rsp+0x20], xmm12
0000705c0ade47eb  lea rdi, [rsp]
0000705c0ade47ef  mov esi, 0x00
0000705c0ade47f4  mov rax, 0x5969C28C4530
0000705c0ade47fe  call rax
0000705c0ade4800  movaps xmm15, [rsp]
0000705c0ade4805  add rsp, 0x30
0000705c0ade4809  vmovaps xmm0, [rsp]
0000705c0ade480e  vmovaps xmm1, [rsp+0x10]
0000705c0ade4814  vmovaps xmm2, [rsp+0x20]
0000705c0ade481a  vmovaps xmm3, [rsp+0x30]
0000705c0ade4820  vmovaps xmm4, [rsp+0x40]
0000705c0ade4826  vmovaps xmm5, [rsp+0x50]
0000705c0ade482c  vmovaps xmm6, [rsp+0x60]
0000705c0ade4832  vmovaps xmm7, [rsp+0x70]
0000705c0ade4838  vmovaps xmm8, [rsp+0x80]
0000705c0ade4841  vmovaps xmm9, [rsp+0x90]
0000705c0ade484a  vmovaps xmm10, [rsp+0xA0]
0000705c0ade4853  vmovaps xmm11, [rsp+0xB0]
0000705c0ade485c  vmovaps xmm12, [rsp+0xC0]
0000705c0ade4865  vmovaps xmm13, [rsp+0xD0]
0000705c0ade486e  vmovaps xmm14, [rsp+0xE0]
0000705c0ade4877  add rsp, 0xF0
0000705c0ade487e  pop r11
0000705c0ade4880  pop r10
0000705c0ade4882  pop r9
0000705c0ade4884  pop r8
0000705c0ade4886  pop rsi
0000705c0ade4887  pop rdi
0000705c0ade4888  pop rdx
0000705c0ade4889  pop rcx
0000705c0ade488a  pop rax
0000705c0ade488b  add rsp, 0x08
0000705c0ade488f  jmp 0x0000705C0ADDF9DD
0000705c0ade4894  sub rsp, 0x08
0000705c0ade4898  push rax
0000705c0ade4899  push rcx
0000705c0ade489a  push rdx
0000705c0ade489b  push rdi
0000705c0ade489c  push rsi
0000705c0ade489d  push r8
0000705c0ade489f  push r9
0000705c0ade48a1  push r10
0000705c0ade48a3  push r11
0000705c0ade48a5  sub rsp, 0xF0
0000705c0ade48ac  vmovaps [rsp], xmm0
0000705c0ade48b1  vmovaps [rsp+0x10], xmm1
0000705c0ade48b7  vmovaps [rsp+0x20], xmm2
0000705c0ade48bd  vmovaps [rsp+0x30], xmm3
0000705c0ade48c3  vmovaps [rsp+0x40], xmm4
0000705c0ade48c9  vmovaps [rsp+0x50], xmm5
0000705c0ade48cf  vmovaps [rsp+0x60], xmm6
0000705c0ade48d5  vmovaps [rsp+0x70], xmm7
0000705c0ade48db  vmovaps [rsp+0x80], xmm8
0000705c0ade48e4  vmovaps [rsp+0x90], xmm9
0000705c0ade48ed  vmovaps [rsp+0xA0], xmm10
0000705c0ade48f6  vmovaps [rsp+0xB0], xmm11
0000705c0ade48ff  vmovaps [rsp+0xC0], xmm12
0000705c0ade4908  vmovaps [rsp+0xD0], xmm14
0000705c0ade4911  vmovaps [rsp+0xE0], xmm15
0000705c0ade491a  sub rsp, 0x30
0000705c0ade491e  movaps [rsp], xmm13
0000705c0ade4923  movaps [rsp+0x10], xmm10
0000705c0ade4929  movaps [rsp+0x20], xmm14
0000705c0ade492f  lea rdi, [rsp]
0000705c0ade4933  mov esi, 0x00
0000705c0ade4938  mov rax, 0x5969C28C4530
0000705c0ade4942  call rax
0000705c0ade4944  movaps xmm13, [rsp]
0000705c0ade4949  add rsp, 0x30
0000705c0ade494d  vmovaps xmm0, [rsp]
0000705c0ade4952  vmovaps xmm1, [rsp+0x10]
0000705c0ade4958  vmovaps xmm2, [rsp+0x20]
0000705c0ade495e  vmovaps xmm3, [rsp+0x30]
0000705c0ade4964  vmovaps xmm4, [rsp+0x40]
0000705c0ade496a  vmovaps xmm5, [rsp+0x50]
0000705c0ade4970  vmovaps xmm6, [rsp+0x60]
0000705c0ade4976  vmovaps xmm7, [rsp+0x70]
0000705c0ade497c  vmovaps xmm8, [rsp+0x80]
0000705c0ade4985  vmovaps xmm9, [rsp+0x90]
0000705c0ade498e  vmovaps xmm10, [rsp+0xA0]
0000705c0ade4997  vmovaps xmm11, [rsp+0xB0]
0000705c0ade49a0  vmovaps xmm12, [rsp+0xC0]
0000705c0ade49a9  vmovaps xmm14, [rsp+0xD0]
0000705c0ade49b2  vmovaps xmm15, [rsp+0xE0]
0000705c0ade49bb  add rsp, 0xF0
0000705c0ade49c2  pop r11
0000705c0ade49c4  pop r10
0000705c0ade49c6  pop r9
0000705c0ade49c8  pop r8
0000705c0ade49ca  pop rsi
0000705c0ade49cb  pop rdi
0000705c0ade49cc  pop rdx
0000705c0ade49cd  pop rcx
0000705c0ade49ce  pop rax
0000705c0ade49cf  add rsp, 0x08
0000705c0ade49d3  jmp 0x0000705C0ADDFA00
0000705c0ade49d8  sub rsp, 0x08
0000705c0ade49dc  push rax
0000705c0ade49dd  push rcx
0000705c0ade49de  push rdx
0000705c0ade49df  push rdi
0000705c0ade49e0  push rsi
0000705c0ade49e1  push r8
0000705c0ade49e3  push r9
0000705c0ade49e5  push r10
0000705c0ade49e7  push r11
0000705c0ade49e9  sub rsp, 0xF0
0000705c0ade49f0  vmovaps [rsp], xmm0
0000705c0ade49f5  vmovaps [rsp+0x10], xmm1
0000705c0ade49fb  vmovaps [rsp+0x20], xmm2
0000705c0ade4a01  vmovaps [rsp+0x30], xmm3
0000705c0ade4a07  vmovaps [rsp+0x40], xmm4
0000705c0ade4a0d  vmovaps [rsp+0x50], xmm5
0000705c0ade4a13  vmovaps [rsp+0x60], xmm6
0000705c0ade4a19  vmovaps [rsp+0x70], xmm7
0000705c0ade4a1f  vmovaps [rsp+0x80], xmm8
0000705c0ade4a28  vmovaps [rsp+0x90], xmm9
0000705c0ade4a31  vmovaps [rsp+0xA0], xmm10
0000705c0ade4a3a  vmovaps [rsp+0xB0], xmm11
0000705c0ade4a43  vmovaps [rsp+0xC0], xmm12
0000705c0ade4a4c  vmovaps [rsp+0xD0], xmm13
0000705c0ade4a55  vmovaps [rsp+0xE0], xmm15
0000705c0ade4a5e  sub rsp, 0x30
0000705c0ade4a62  movaps [rsp], xmm14
0000705c0ade4a67  movaps [rsp+0x10], xmm1
0000705c0ade4a6c  movaps [rsp+0x20], xmm7
0000705c0ade4a71  lea rdi, [rsp]
0000705c0ade4a75  mov esi, 0x00
0000705c0ade4a7a  mov rax, 0x5969C28C4530
0000705c0ade4a84  call rax
0000705c0ade4a86  movaps xmm14, [rsp]
0000705c0ade4a8b  add rsp, 0x30
0000705c0ade4a8f  vmovaps xmm0, [rsp]
0000705c0ade4a94  vmovaps xmm1, [rsp+0x10]
0000705c0ade4a9a  vmovaps xmm2, [rsp+0x20]
0000705c0ade4aa0  vmovaps xmm3, [rsp+0x30]
0000705c0ade4aa6  vmovaps xmm4, [rsp+0x40]
0000705c0ade4aac  vmovaps xmm5, [rsp+0x50]
0000705c0ade4ab2  vmovaps xmm6, [rsp+0x60]
0000705c0ade4ab8  vmovaps xmm7, [rsp+0x70]
0000705c0ade4abe  vmovaps xmm8, [rsp+0x80]
0000705c0ade4ac7  vmovaps xmm9, [rsp+0x90]
0000705c0ade4ad0  vmovaps xmm10, [rsp+0xA0]
0000705c0ade4ad9  vmovaps xmm11, [rsp+0xB0]
0000705c0ade4ae2  vmovaps xmm12, [rsp+0xC0]
0000705c0ade4aeb  vmovaps xmm13, [rsp+0xD0]
0000705c0ade4af4  vmovaps xmm15, [rsp+0xE0]
0000705c0ade4afd  add rsp, 0xF0
0000705c0ade4b04  pop r11
0000705c0ade4b06  pop r10
0000705c0ade4b08  pop r9
0000705c0ade4b0a  pop r8
0000705c0ade4b0c  pop rsi
0000705c0ade4b0d  pop rdi
0000705c0ade4b0e  pop rdx
0000705c0ade4b0f  pop rcx
0000705c0ade4b10  pop rax
0000705c0ade4b11  add rsp, 0x08
0000705c0ade4b15  jmp 0x0000705C0ADDFA23
0000705c0ade4b1a  sub rsp, 0x08
0000705c0ade4b1e  push rax
0000705c0ade4b1f  push rcx
0000705c0ade4b20  push rdx
0000705c0ade4b21  push rdi
0000705c0ade4b22  push rsi
0000705c0ade4b23  push r8
0000705c0ade4b25  push r9
0000705c0ade4b27  push r10
0000705c0ade4b29  push r11
0000705c0ade4b2b  sub rsp, 0xF0
0000705c0ade4b32  vmovaps [rsp], xmm0
0000705c0ade4b37  vmovaps [rsp+0x10], xmm2
0000705c0ade4b3d  vmovaps [rsp+0x20], xmm3
0000705c0ade4b43  vmovaps [rsp+0x30], xmm4
0000705c0ade4b49  vmovaps [rsp+0x40], xmm5
0000705c0ade4b4f  vmovaps [rsp+0x50], xmm6
0000705c0ade4b55  vmovaps [rsp+0x60], xmm7
0000705c0ade4b5b  vmovaps [rsp+0x70], xmm8
0000705c0ade4b61  vmovaps [rsp+0x80], xmm9
0000705c0ade4b6a  vmovaps [rsp+0x90], xmm10
0000705c0ade4b73  vmovaps [rsp+0xA0], xmm11
0000705c0ade4b7c  vmovaps [rsp+0xB0], xmm12
0000705c0ade4b85  vmovaps [rsp+0xC0], xmm13
0000705c0ade4b8e  vmovaps [rsp+0xD0], xmm14
0000705c0ade4b97  vmovaps [rsp+0xE0], xmm15
0000705c0ade4ba0  sub rsp, 0x30
0000705c0ade4ba4  movaps [rsp], xmm1
0000705c0ade4ba8  movaps [rsp+0x10], xmm8
0000705c0ade4bae  movaps [rsp+0x20], xmm9
0000705c0ade4bb4  lea rdi, [rsp]
0000705c0ade4bb8  mov esi, 0x00
0000705c0ade4bbd  mov rax, 0x5969C28C4530
0000705c0ade4bc7  call rax
0000705c0ade4bc9  movaps xmm1, [rsp]
0000705c0ade4bcd  add rsp, 0x30
0000705c0ade4bd1  vmovaps xmm0, [rsp]
0000705c0ade4bd6  vmovaps xmm2, [rsp+0x10]
0000705c0ade4bdc  vmovaps xmm3, [rsp+0x20]
0000705c0ade4be2  vmovaps xmm4, [rsp+0x30]
0000705c0ade4be8  vmovaps xmm5, [rsp+0x40]
0000705c0ade4bee  vmovaps xmm6, [rsp+0x50]
0000705c0ade4bf4  vmovaps xmm7, [rsp+0x60]
0000705c0ade4bfa  vmovaps xmm8, [rsp+0x70]
0000705c0ade4c00  vmovaps xmm9, [rsp+0x80]
0000705c0ade4c09  vmovaps xmm10, [rsp+0x90]
0000705c0ade4c12  vmovaps xmm11, [rsp+0xA0]
0000705c0ade4c1b  vmovaps xmm12, [rsp+0xB0]
0000705c0ade4c24  vmovaps xmm13, [rsp+0xC0]
0000705c0ade4c2d  vmovaps xmm14, [rsp+0xD0]
0000705c0ade4c36  vmovaps xmm15, [rsp+0xE0]
0000705c0ade4c3f  add rsp, 0xF0
0000705c0ade4c46  pop r11
0000705c0ade4c48  pop r10
0000705c0ade4c4a  pop r9
0000705c0ade4c4c  pop r8
0000705c0ade4c4e  pop rsi
0000705c0ade4c4f  pop rdi
0000705c0ade4c50  pop rdx
0000705c0ade4c51  pop rcx
0000705c0ade4c52  pop rax
0000705c0ade4c53  add rsp, 0x08
0000705c0ade4c57  jmp 0x0000705C0ADDFA45
0000705c0ade4c5c  call 0x0000705C0ACE5940
0000705c0ade4c61  jmp 0x0000705C0ADDFA53
0000705c0ade4c66  call 0x0000705C0AC0C380
0000705c0ade4c6b  jmp 0x0000705C0ADDFA5D
0000705c0ade4c70  call 0x0000705C0AC0D600
0000705c0ade4c75  jmp 0x0000705C0ADDFA67
0000705c0ade4c7a  call 0x0000705C0ABFF540
0000705c0ade4c7f  jmp 0x0000705C0ADDFA71
0000705c0ade4c84  int3
0000705c0ade4c85  nop [rax+rax*1], ax
0000705c0ade4c8e  nop
0000705c0ade4c90  mov qword ptr [r15+0x40], 0x430000
0000705c0ade4c98  mov eax, 0x430CC0
0000705c0ade4c9d  mov r14, [r13+rax*1]
0000705c0ade4ca2  movq xmm1, r14
0000705c0ade4ca7  mov rax, [r15+0x50]
0000705c0ade4cab  movups xmm15, [r13+rax*1]
0000705c0ade4cb1  movaps [r15+0x120], xmm15
0000705c0ade4cb9  mov qword ptr [r15+0x48], 0x10
0000705c0ade4cc1  xor eax, eax
0000705c0ade4cc3  mov r14d, 0x10
0000705c0ade4cc9  mov r12d, 0x200
0000705c0ade4ccf  cmp r14, r12
0000705c0ade4cd2  cmc
0000705c0ade4cd3  lahf
0000705c0ade4cd4  seto al
0000705c0ade4cd7  mov [r15+0x108], eax
0000705c0ade4cde  pextrq rax, xmm15, 0x01
0000705c0ade4ce5  movq xmm14, rax
0000705c0ade4cea  movaps [r15+0x130], xmm14
0000705c0ade4cf2  movq rax, xmm1
0000705c0ade4cf7  movq r14, xmm15
0000705c0ade4cfc  vmovq xmm1, rax
0000705c0ade4d01  vmovq xmm15, r14
0000705c0ade4d06  movaps xmm13, xmm1
0000705c0ade4d0a  addsd xmm13, xmm15
0000705c0ade4d0f  ucomisd xmm13, xmm13
0000705c0ade4d14  jp 0x0000705C0ADE4DD3
0000705c0ade4d1a  movq xmm13, xmm13
0000705c0ade4d1f  movq rax, xmm13
0000705c0ade4d24  movq r14, xmm14
0000705c0ade4d29  vmovq xmm1, rax
0000705c0ade4d2e  vmovq xmm15, r14
0000705c0ade4d33  movaps xmm14, xmm1
0000705c0ade4d37  addsd xmm14, xmm15
0000705c0ade4d3c  ucomisd xmm14, xmm14
0000705c0ade4d41  jp 0x0000705C0ADE4E1B
0000705c0ade4d47  movq xmm14, xmm14
0000705c0ade4d4c  movaps [r15+0x110], xmm14
0000705c0ade4d54  mov eax, [r15+0x108]
0000705c0ade4d5b  sahf
0000705c0ade4d5c  jnz 0x0000705C0ADE4D8E
0000705c0ade4d5e  cmp dword ptr [r15+0x318], 0x00
0000705c0ade4d66  jz 0x0000705C0ADE5030
0000705c0ade4d6c  nop [rax+rax*1], ax
0000705c0ade4d75  nop [rax+rax*1], eax
0000705c0ade4d7d  mov eax, 0x410704
0000705c0ade4d82  mov [r15+0x100], rax
0000705c0ade4d89  jmp 0x0000705C0ABFE110
0000705c0ade4d8e  cmp dword ptr [r15+0x318], 0x00
0000705c0ade4d96  jz 0x0000705C0ADE4E70
0000705c0ade4d9c  nop [rax+rax*1], ax
0000705c0ade4da5  nop [rax+rax*1], eax
0000705c0ade4dad  mov eax, 0x4106E8
0000705c0ade4db2  mov [r15+0x100], rax
0000705c0ade4db9  jmp 0x0000705C0ABFE110
0000705c0ade4dbe  int3
0000705c0ade4dbf  call 0x0000705C0AC0DC20
0000705c0ade4dc4  jmp 0x0000705C0ADE4CA2
0000705c0ade4dc9  call 0x0000705C0AC0E760
0000705c0ade4dce  jmp 0x0000705C0ADE4CB1
0000705c0ade4dd3  ucomisd xmm1, xmm15
0000705c0ade4dd8  jp 0x0000705C0ADE4DE7
0000705c0ade4dda  movaps xmm13, [0x0000705C0A9FE060]
0000705c0ade4de2  jmp 0x0000705C0ADE4D1A
0000705c0ade4de7  vxorps xmm0, xmm1, xmm15
0000705c0ade4dec  pextrw eax, xmm0, 0x03
0000705c0ade4df1  and eax, 0x7FF8
0000705c0ade4df6  cmp eax, 0x08
0000705c0ade4df9  jnz 0x0000705C0ADE4D1A
0000705c0ade4dff  movq rax, xmm15
0000705c0ade4e04  shl rax, 0x0D
0000705c0ade4e08  jbe 0x0000705C0ADE4D1A
0000705c0ade4e0e  vorps xmm13, xmm15, [0x0000705C0A9FE070]
0000705c0ade4e16  jmp 0x0000705C0ADE4D1A
0000705c0ade4e1b  ucomisd xmm1, xmm15
0000705c0ade4e20  jp 0x0000705C0ADE4E2F
0000705c0ade4e22  movaps xmm14, [0x0000705C0A9FE060]
0000705c0ade4e2a  jmp 0x0000705C0ADE4D47
0000705c0ade4e2f  vxorps xmm0, xmm1, xmm15
0000705c0ade4e34  pextrw eax, xmm0, 0x03
0000705c0ade4e39  and eax, 0x7FF8
0000705c0ade4e3e  cmp eax, 0x08
0000705c0ade4e41  jnz 0x0000705C0ADE4D47
0000705c0ade4e47  movq rax, xmm15
0000705c0ade4e4c  shl rax, 0x0D
0000705c0ade4e50  jbe 0x0000705C0ADE4D47
0000705c0ade4e56  vorps xmm14, xmm15, [0x0000705C0A9FE070]
0000705c0ade4e5e  jmp 0x0000705C0ADE4D47
0000705c0ade4e63  int3
0000705c0ade4e64  nop [rax+rax*1], ax
0000705c0ade4e6d  nop [rax], eax
0000705c0ade4e70  mov rax, [r15+0x48]
0000705c0ade4e74  mov r14, [r15+0x50]
0000705c0ade4e78  lea r12, [r14+rax*1]
0000705c0ade4e7c  movups xmm1, [r13+r12*1]
0000705c0ade4e82  movaps [r15+0x120], xmm1
0000705c0ade4e8a  lea r14, [rax+0x10]
0000705c0ade4e8e  mov [r15+0x48], r14
0000705c0ade4e92  xor eax, eax
0000705c0ade4e94  mov r12d, 0x200
0000705c0ade4e9a  cmp r14, r12
0000705c0ade4e9d  cmc
0000705c0ade4e9e  lahf
0000705c0ade4e9f  seto al
0000705c0ade4ea2  mov [r15+0x108], eax
0000705c0ade4ea9  pextrq rax, xmm1, 0x01
0000705c0ade4eb0  movq xmm15, rax
0000705c0ade4eb5  movaps [r15+0x130], xmm15
0000705c0ade4ebd  movaps xmm14, [r15+0x110]
0000705c0ade4ec5  movq rax, xmm14
0000705c0ade4eca  movq r14, xmm1
0000705c0ade4ecf  vmovq xmm1, rax
0000705c0ade4ed4  vmovq xmm14, r14
0000705c0ade4ed9  movaps xmm13, xmm1
0000705c0ade4edd  addsd xmm13, xmm14
0000705c0ade4ee2  ucomisd xmm13, xmm13
0000705c0ade4ee7  jp 0x0000705C0ADE4F9C
0000705c0ade4eed  movq xmm13, xmm13
0000705c0ade4ef2  movq rax, xmm13
0000705c0ade4ef7  movq r14, xmm15
0000705c0ade4efc  vmovq xmm1, rax
0000705c0ade4f01  vmovq xmm15, r14
0000705c0ade4f06  movaps xmm14, xmm1
0000705c0ade4f0a  addsd xmm14, xmm15
0000705c0ade4f0f  ucomisd xmm14, xmm14
0000705c0ade4f14  jp 0x0000705C0ADE4FE4
0000705c0ade4f1a  movq xmm14, xmm14
0000705c0ade4f1f  movaps [r15+0x110], xmm14
0000705c0ade4f27  mov eax, [r15+0x108]
0000705c0ade4f2e  sahf
0000705c0ade4f2f  jnz 0x0000705C0ADE4F61
0000705c0ade4f31  cmp dword ptr [r15+0x318], 0x00
0000705c0ade4f39  jz 0x0000705C0ADE5030
0000705c0ade4f3f  nop [rax+rax*1], ax
0000705c0ade4f48  nop [rax+rax*1], eax
0000705c0ade4f50  mov eax, 0x410704
0000705c0ade4f55  mov [r15+0x100], rax
0000705c0ade4f5c  jmp 0x0000705C0ABFE110
0000705c0ade4f61  cmp dword ptr [r15+0x318], 0x00
0000705c0ade4f69  jz 0x0000705C0ADE4E70
0000705c0ade4f6f  nop [rax+rax*1], ax
0000705c0ade4f78  nop [rax+rax*1], eax
0000705c0ade4f80  mov eax, 0x4106E8
0000705c0ade4f85  mov [r15+0x100], rax
0000705c0ade4f8c  jmp 0x0000705C0ABFE110
0000705c0ade4f91  int3
0000705c0ade4f92  call 0x0000705C0ACB52F0
0000705c0ade4f97  jmp 0x0000705C0ADE4E82
0000705c0ade4f9c  ucomisd xmm1, xmm14
0000705c0ade4fa1  jp 0x0000705C0ADE4FB0
0000705c0ade4fa3  movaps xmm13, [0x0000705C0A9FE060]
0000705c0ade4fab  jmp 0x0000705C0ADE4EED
0000705c0ade4fb0  vxorps xmm0, xmm1, xmm14
0000705c0ade4fb5  pextrw eax, xmm0, 0x03
0000705c0ade4fba  and eax, 0x7FF8
0000705c0ade4fbf  cmp eax, 0x08
0000705c0ade4fc2  jnz 0x0000705C0ADE4EED
0000705c0ade4fc8  movq rax, xmm14
0000705c0ade4fcd  shl rax, 0x0D
0000705c0ade4fd1  jbe 0x0000705C0ADE4EED
0000705c0ade4fd7  vorps xmm13, xmm14, [0x0000705C0A9FE070]
0000705c0ade4fdf  jmp 0x0000705C0ADE4EED
0000705c0ade4fe4  ucomisd xmm1, xmm15
0000705c0ade4fe9  jp 0x0000705C0ADE4FF8
0000705c0ade4feb  movaps xmm14, [0x0000705C0A9FE060]
0000705c0ade4ff3  jmp 0x0000705C0ADE4F1A
0000705c0ade4ff8  vxorps xmm0, xmm1, xmm15
0000705c0ade4ffd  pextrw eax, xmm0, 0x03
0000705c0ade5002  and eax, 0x7FF8
0000705c0ade5007  cmp eax, 0x08
0000705c0ade500a  jnz 0x0000705C0ADE4F1A
0000705c0ade5010  movq rax, xmm15
0000705c0ade5015  shl rax, 0x0D
0000705c0ade5019  jbe 0x0000705C0ADE4F1A
0000705c0ade501f  vorps xmm14, xmm15, [0x0000705C0A9FE070]
0000705c0ade5027  jmp 0x0000705C0ADE4F1A
0000705c0ade502c  int3
0000705c0ade502d  nop [rax], eax
0000705c0ade5030  mov rax, [r15+0xF8]
0000705c0ade5037  lea r14, [rax+0x1D0]
0000705c0ade503e  mov r12, [r13+r14*1]
0000705c0ade5043  lea r14, [rax+0x1D8]
0000705c0ade504a  mov r11, [r13+r14*1]
0000705c0ade504f  mov [r15+0xA0], r12
0000705c0ade5056  mov [r15+0x98], r11
0000705c0ade505d  mov r14, [r15+0x40]
0000705c0ade5061  lea r12, [r14+0xCC0]
0000705c0ade5068  movaps xmm1, [r15+0x110]
0000705c0ade5070  movq r14, xmm1
0000705c0ade5075  mov [r13+r12*1], r14
0000705c0ade507a  lea r14, [rax+0x1C0]
0000705c0ade5081  mov r12, [r13+r14*1]
0000705c0ade5086  lea r14, [rax+0x1C8]
0000705c0ade508d  mov r11, [r13+r14*1]
0000705c0ade5092  mov [r15+0xE8], r12
0000705c0ade5099  mov [r15+0xF0], r11
0000705c0ade50a0  lea r14, [rax+0x1B0]
0000705c0ade50a7  mov r12, [r13+r14*1]
0000705c0ade50ac  lea r14, [rax+0x1B8]
0000705c0ade50b3  mov r10, [r13+r14*1]
0000705c0ade50b8  movq xmm1, r12
0000705c0ade50bd  movq xmm15, r10
0000705c0ade50c2  movq xmm1, xmm1
0000705c0ade50c6  movq xmm1, xmm1
0000705c0ade50ca  movaps [r15+0x1A0], xmm1
0000705c0ade50d2  movq xmm15, xmm15
0000705c0ade50d7  movq xmm15, xmm15
0000705c0ade50dc  movaps [r15+0x190], xmm15
0000705c0ade50e4  lea r14, [rax+0x1A0]
0000705c0ade50eb  mov r12, [r13+r14*1]
0000705c0ade50f0  lea r14, [rax+0x1A8]
0000705c0ade50f7  mov r10, [r13+r14*1]
0000705c0ade50fc  movq xmm1, r12
0000705c0ade5101  movq xmm15, r10
0000705c0ade5106  movq xmm1, xmm1
0000705c0ade510a  movq xmm1, xmm1
0000705c0ade510e  movaps [r15+0x1C0], xmm1
0000705c0ade5116  movq xmm15, xmm15
0000705c0ade511b  movq xmm15, xmm15
0000705c0ade5120  movaps [r15+0x1B0], xmm15
0000705c0ade5128  lea r14, [rax+0x190]
0000705c0ade512f  mov r12, [r13+r14*1]
0000705c0ade5134  lea r14, [rax+0x198]
0000705c0ade513b  mov r10, [r13+r14*1]
0000705c0ade5140  movq xmm1, r12
0000705c0ade5145  movq xmm15, r10
0000705c0ade514a  movq xmm1, xmm1
0000705c0ade514e  movq xmm1, xmm1
0000705c0ade5152  movaps [r15+0x1E0], xmm1
0000705c0ade515a  movq xmm15, xmm15
0000705c0ade515f  movq xmm15, xmm15
0000705c0ade5164  movaps [r15+0x1D0], xmm15
0000705c0ade516c  lea r14, [rax+0x180]
0000705c0ade5173  mov r12, [r13+r14*1]
0000705c0ade5178  lea r14, [rax+0x188]
0000705c0ade517f  mov r10, [r13+r14*1]
0000705c0ade5184  movq xmm1, r12
0000705c0ade5189  movq xmm15, r10
0000705c0ade518e  movq xmm1, xmm1
0000705c0ade5192  movq xmm1, xmm1
0000705c0ade5196  movaps [r15+0x200], xmm1
0000705c0ade519e  movq xmm15, xmm15
0000705c0ade51a3  movq xmm15, xmm15
0000705c0ade51a8  movaps [r15+0x1F0], xmm15
0000705c0ade51b0  lea r14, [rax+0x1E0]
0000705c0ade51b7  mov [r15+0xF8], r14
0000705c0ade51be  mov [r15+0x100], r11
0000705c0ade51c5  jmp 0x0000705C0ADCE5C0
0000705c0ade51ca  int3
0000705c0ade51cb  call 0x0000705C0ACE27E0
0000705c0ade51d0  jmp 0x0000705C0ADE5043
0000705c0ade51d5  call 0x0000705C0ACE1570
0000705c0ade51da  jmp 0x0000705C0ADE504F
0000705c0ade51df  call 0x0000705C0ACC3FE0
0000705c0ade51e4  jmp 0x0000705C0ADE507A
0000705c0ade51e9  call 0x0000705C0ACE27E0
0000705c0ade51ee  jmp 0x0000705C0ADE5086
0000705c0ade51f3  call 0x0000705C0ACE1570
0000705c0ade51f8  jmp 0x0000705C0ADE5092
0000705c0ade51fd  call 0x0000705C0ACE27E0
0000705c0ade5202  jmp 0x0000705C0ADE50AC
0000705c0ade5207  call 0x0000705C0ACE0300
0000705c0ade520c  jmp 0x0000705C0ADE50B8
0000705c0ade5211  call 0x0000705C0ACE27E0
0000705c0ade5216  jmp 0x0000705C0ADE50F0
0000705c0ade521b  call 0x0000705C0ACE0300
0000705c0ade5220  jmp 0x0000705C0ADE50FC
0000705c0ade5225  call 0x0000705C0ACE27E0
0000705c0ade522a  jmp 0x0000705C0ADE5134
0000705c0ade522f  call 0x0000705C0ACE0300
0000705c0ade5234  jmp 0x0000705C0ADE5140
0000705c0ade5239  call 0x0000705C0ACE27E0
0000705c0ade523e  jmp 0x0000705C0ADE5178
0000705c0ade5243  call 0x0000705C0ACE0300
0000705c0ade5248  jmp 0x0000705C0ADE5184
0000705c0ade524d  int3
0000705c0ade524e  nop
0000705c0ade5250  mov qword ptr [r15+0x100], 0x04
0000705c0ade525b  mov esi, 0x00
0000705c0ade5260  mov edx, 0x09
0000705c0ade5265  mov rdi, 0x7FFE3EC39E70
0000705c0ade526f  mov rax, 0x5969C2757970
0000705c0ade5279  call rax
0000705c0ade527b  cmp dword ptr [r15+0x318], 0x00
0000705c0ade5283  jnz 0x0000705C0ABFE110
0000705c0ade5289  jmp 0x0000705C0ABFE0A0
0000705c0ade528e  int3
0000705c0ade528f  int3
