00007e1ec07ce69b  nop [rax+rax*1], eax
00007e1ec07ce6a0  mov rax, [r15+0xF8]
00007e1ec07ce6a7  lea r14, [rax-0x1E0]
00007e1ec07ce6ae  mov [r15+0xF8], r14
00007e1ec07ce6b5  lea rax, [r14+0x1D0]
00007e1ec07ce6bc  mov r12, [r15+0xA0]
00007e1ec07ce6c3  mov r11, [r15+0x98]
00007e1ec07ce6ca  mov [r13+rax*1], r12
00007e1ec07ce6cf  lea rax, [r14+0x1D8]
00007e1ec07ce6d6  mov [r13+rax*1], r11
00007e1ec07ce6db  mov eax, 0x420AA0
00007e1ec07ce6e0  movups xmm1, [r13+rax*1]
00007e1ec07ce6e6  mov eax, 0x420A30
00007e1ec07ce6eb  movups xmm15, [r13+rax*1]
00007e1ec07ce6f1  mov eax, 0x420AC0
00007e1ec07ce6f6  movups xmm14, [r13+rax*1]
00007e1ec07ce6fc  mov eax, 0x420A60
00007e1ec07ce701  movups xmm13, [r13+rax*1]
00007e1ec07ce707  mov qword ptr [r15+0x98], 0x430CD0
00007e1ec07ce712  mov eax, 0x420AD0
00007e1ec07ce717  movups xmm12, [r13+rax*1]
00007e1ec07ce71d  mov eax, 0x430CD0
00007e1ec07ce722  movups [r13+rax*1], xmm1
00007e1ec07ce728  mov eax, 0x430CE0
00007e1ec07ce72d  movups [r13+rax*1], xmm15
00007e1ec07ce733  mov eax, 0x430CF0
00007e1ec07ce738  movups [r13+rax*1], xmm14
00007e1ec07ce73e  mov eax, 0x430D00
00007e1ec07ce743  movups [r13+rax*1], xmm13
00007e1ec07ce749  mov eax, 0x420A20
00007e1ec07ce74e  movups xmm14, [r13+rax*1]
00007e1ec07ce754  mov eax, 0x420A10
00007e1ec07ce759  movups xmm13, [r13+rax*1]
00007e1ec07ce75f  mov eax, 0x430DD0
00007e1ec07ce764  movups [r13+rax*1], xmm1
00007e1ec07ce76a  mov eax, 0x430DE0
00007e1ec07ce76f  movups [r13+rax*1], xmm15
00007e1ec07ce775  mov eax, 0x430D10
00007e1ec07ce77a  movups [r13+rax*1], xmm12
00007e1ec07ce780  mov eax, 0x430D20
00007e1ec07ce785  movups [r13+rax*1], xmm14
00007e1ec07ce78b  mov eax, 0x420A00
00007e1ec07ce790  movups xmm1, [r13+rax*1]
00007e1ec07ce796  mov eax, 0x420A70
00007e1ec07ce79b  movups xmm15, [r13+rax*1]
00007e1ec07ce7a1  mov eax, 0x430D30
00007e1ec07ce7a6  movups [r13+rax*1], xmm13
00007e1ec07ce7ac  mov eax, 0x430D40
00007e1ec07ce7b1  movups [r13+rax*1], xmm1
00007e1ec07ce7b7  mov eax, 0x420A80
00007e1ec07ce7bc  movups xmm1, [r13+rax*1]
00007e1ec07ce7c2  mov eax, 0x420A50
00007e1ec07ce7c7  movups xmm14, [r13+rax*1]
00007e1ec07ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007e1ec07ce7d5  mov eax, 0x430D50
00007e1ec07ce7da  movups [r13+rax*1], xmm15
00007e1ec07ce7e0  mov eax, 0x430D60
00007e1ec07ce7e5  movups [r13+rax*1], xmm1
00007e1ec07ce7eb  mov eax, 0x420AF0
00007e1ec07ce7f0  movups xmm1, [r13+rax*1]
00007e1ec07ce7f6  mov eax, 0x420B00
00007e1ec07ce7fb  movups xmm15, [r13+rax*1]
00007e1ec07ce801  movaps [r15+0x150], xmm15
00007e1ec07ce809  mov qword ptr [r15+0xA0], 0x3E8
00007e1ec07ce814  mov eax, 0x430D70
00007e1ec07ce819  movups [r13+rax*1], xmm14
00007e1ec07ce81f  mov eax, 0x430D80
00007e1ec07ce824  movups [r13+rax*1], xmm1
00007e1ec07ce82a  mov eax, 0x420AE0
00007e1ec07ce82f  movups xmm1, [r13+rax*1]
00007e1ec07ce835  mov eax, 0x420A90
00007e1ec07ce83a  movups xmm14, [r13+rax*1]
00007e1ec07ce840  movaps [r15+0x140], xmm14
00007e1ec07ce848  lea rax, [r14+0x180]
00007e1ec07ce84f  movq xmm13, qword ptr [r15+0x200]
00007e1ec07ce858  movq xmm12, qword ptr [r15+0x1F0]
00007e1ec07ce861  movq r12, xmm13
00007e1ec07ce866  movq r11, xmm12
00007e1ec07ce86b  mov [r13+rax*1], r12
00007e1ec07ce870  lea rax, [r14+0x188]
00007e1ec07ce877  mov [r13+rax*1], r11
00007e1ec07ce87c  mov eax, 0x430D90
00007e1ec07ce881  movups [r13+rax*1], xmm15
00007e1ec07ce887  mov eax, 0x430DA0
00007e1ec07ce88c  movups [r13+rax*1], xmm1
00007e1ec07ce892  mov eax, 0x420AB0
00007e1ec07ce897  movups xmm1, [r13+rax*1]
00007e1ec07ce89d  mov eax, 0x420B18
00007e1ec07ce8a2  mov r12, [r13+rax*1]
00007e1ec07ce8a7  movq xmm15, r12
00007e1ec07ce8ac  mov qword ptr [r15+0x40], 0x420B20
00007e1ec07ce8b4  mov eax, 0x430DB0
00007e1ec07ce8b9  movups [r13+rax*1], xmm14
00007e1ec07ce8bf  mov eax, 0x430DC0
00007e1ec07ce8c4  movups [r13+rax*1], xmm1
00007e1ec07ce8ca  mov eax, 0x420B80
00007e1ec07ce8cf  movups xmm1, [r13+rax*1]
00007e1ec07ce8d5  movq rax, xmm15
00007e1ec07ce8da  mov r12d, 0x430DF0
00007e1ec07ce8e0  mov [r13+r12*1], rax
00007e1ec07ce8e5  mov eax, 0x420B60
00007e1ec07ce8ea  movups xmm15, [r13+rax*1]
00007e1ec07ce8f0  mov eax, 0x420B70
00007e1ec07ce8f5  movups xmm14, [r13+rax*1]
00007e1ec07ce8fb  lea rax, [r14+0x160]
00007e1ec07ce902  movups [r13+rax*1], xmm1
00007e1ec07ce908  lea rax, [r14+0x190]
00007e1ec07ce90f  movq xmm1, qword ptr [r15+0x1E0]
00007e1ec07ce918  movq xmm13, qword ptr [r15+0x1D0]
00007e1ec07ce921  movq r12, xmm1
00007e1ec07ce926  movq r11, xmm13
00007e1ec07ce92b  mov [r13+rax*1], r12
00007e1ec07ce930  lea rax, [r14+0x198]
00007e1ec07ce937  mov [r13+rax*1], r11
00007e1ec07ce93c  lea rax, [r14+0x140]
00007e1ec07ce943  movups [r13+rax*1], xmm15
00007e1ec07ce949  lea rax, [r14+0x150]
00007e1ec07ce950  movups [r13+rax*1], xmm14
00007e1ec07ce956  mov eax, 0x420B20
00007e1ec07ce95b  movups xmm1, [r13+rax*1]
00007e1ec07ce961  mov eax, 0x420B30
00007e1ec07ce966  movups xmm15, [r13+rax*1]
00007e1ec07ce96c  movaps [r15+0x120], xmm15
00007e1ec07ce974  lea rax, [r14+0x1A0]
00007e1ec07ce97b  movq xmm14, qword ptr [r15+0x1C0]
00007e1ec07ce984  movq xmm13, qword ptr [r15+0x1B0]
00007e1ec07ce98d  movq r12, xmm14
00007e1ec07ce992  movq r11, xmm13
00007e1ec07ce997  mov [r13+rax*1], r12
00007e1ec07ce99c  lea rax, [r14+0x1A8]
00007e1ec07ce9a3  mov [r13+rax*1], r11
00007e1ec07ce9a8  lea rax, [r14+0x1B0]
00007e1ec07ce9af  movq xmm14, qword ptr [r15+0x1A0]
00007e1ec07ce9b8  movq xmm13, qword ptr [r15+0x190]
00007e1ec07ce9c1  movq r12, xmm14
00007e1ec07ce9c6  movq r11, xmm13
00007e1ec07ce9cb  mov [r13+rax*1], r12
00007e1ec07ce9d0  lea rax, [r14+0x1B8]
00007e1ec07ce9d7  mov [r13+rax*1], r11
00007e1ec07ce9dc  lea rax, [r14+0x100]
00007e1ec07ce9e3  movups [r13+rax*1], xmm1
00007e1ec07ce9e9  lea rax, [r14+0x110]
00007e1ec07ce9f0  movups [r13+rax*1], xmm15
00007e1ec07ce9f6  mov eax, 0x420B40
00007e1ec07ce9fb  movups xmm1, [r13+rax*1]
00007e1ec07cea01  mov eax, 0x420B50
00007e1ec07cea06  movups xmm15, [r13+rax*1]
00007e1ec07cea0c  movaps [r15+0x110], xmm1
00007e1ec07cea14  movaps [r15+0x130], xmm15
00007e1ec07cea1c  lea rax, [r14+0x1C0]
00007e1ec07cea23  mov r12, [r15+0xE8]
00007e1ec07cea2a  mov r11, [r15+0xF0]
00007e1ec07cea31  mov [r13+rax*1], r12
00007e1ec07cea36  lea rax, [r14+0x1C8]
00007e1ec07cea3d  mov [r13+rax*1], r11
00007e1ec07cea42  mov eax, 0x430DF8
00007e1ec07cea47  mov r12d, 0x421DF8D3
00007e1ec07cea4d  mov [r13+rax*1], r12d
00007e1ec07cea52  lea rax, [r14+0x120]
00007e1ec07cea59  movups [r13+rax*1], xmm1
00007e1ec07cea5f  lea rax, [r14+0x130]
00007e1ec07cea66  movups [r13+rax*1], xmm15
00007e1ec07cea6c  lea rax, [r14+0x100]
00007e1ec07cea73  mov [r15], rax
00007e1ec07cea76  mov qword ptr [r15+0x08], 0x430CD0
00007e1ec07cea7e  mov qword ptr [r15+0x10], 0x12C
00007e1ec07cea86  mov qword ptr [r15+0xF0], 0x410284
00007e1ec07cea91  mov r14d, [r15+0x320]
00007e1ec07cea98  mov eax, 0x410284
00007e1ec07cea9d  mov rcx, 0x7E1EC07D07C0
00007e1ec07ceaa7  mov [r15+r14*8+0x328], rax
00007e1ec07ceaaf  mov [r15+r14*8+0x368], rcx
00007e1ec07ceab7  add r14d, 0x01
00007e1ec07ceabb  and r14d, 0x07
00007e1ec07ceabf  mov [r15+0x320], r14d
00007e1ec07ceac6  cmp dword ptr [r15+0x318], 0x00
00007e1ec07ceace  jz 0x00007E1EC07CED70
00007e1ec07cead4  nop [rax+rax*1], ax
00007e1ec07ceadd  nop [rax+rax*1], eax
00007e1ec07ceae5  mov eax, 0x410728
00007e1ec07ceaea  mov [r15+0x100], rax
00007e1ec07ceaf1  jmp 0x00007E1EC05FE110
00007e1ec07ceaf6  int3
00007e1ec07ceaf7  call 0x00007E1EC060BC20
00007e1ec07ceafc  jmp 0x00007E1EC07CE6CF
00007e1ec07ceb01  call 0x00007E1EC060A9A0
00007e1ec07ceb06  jmp 0x00007E1EC07CE6DB
00007e1ec07ceb0b  call 0x00007E1EC05FF430
00007e1ec07ceb10  jmp 0x00007E1EC07CE6E6
00007e1ec07ceb15  call 0x00007E1EC060E760
00007e1ec07ceb1a  jmp 0x00007E1EC07CE6F1
00007e1ec07ceb1f  call 0x00007E1EC060D4E0
00007e1ec07ceb24  jmp 0x00007E1EC07CE6FC
00007e1ec07ceb29  call 0x00007E1EC060C260
00007e1ec07ceb2e  jmp 0x00007E1EC07CE707
00007e1ec07ceb33  call 0x00007E1EC060AFE0
00007e1ec07ceb38  jmp 0x00007E1EC07CE71D
00007e1ec07ceb3d  call 0x00007E1EC05FF540
00007e1ec07ceb42  jmp 0x00007E1EC07CE728
00007e1ec07ceb47  call 0x00007E1EC060E880
00007e1ec07ceb4c  jmp 0x00007E1EC07CE733
00007e1ec07ceb51  call 0x00007E1EC060D600
00007e1ec07ceb56  jmp 0x00007E1EC07CE73E
00007e1ec07ceb5b  call 0x00007E1EC060C380
00007e1ec07ceb60  jmp 0x00007E1EC07CE749
00007e1ec07ceb65  call 0x00007E1EC060D4E0
00007e1ec07ceb6a  jmp 0x00007E1EC07CE754
00007e1ec07ceb6f  call 0x00007E1EC060C260
00007e1ec07ceb74  jmp 0x00007E1EC07CE75F
00007e1ec07ceb79  call 0x00007E1EC05FF540
00007e1ec07ceb7e  jmp 0x00007E1EC07CE76A
00007e1ec07ceb83  call 0x00007E1EC060E880
00007e1ec07ceb88  jmp 0x00007E1EC07CE775
00007e1ec07ceb8d  call 0x00007E1EC060B100
00007e1ec07ceb92  jmp 0x00007E1EC07CE780
00007e1ec07ceb97  call 0x00007E1EC060D600
00007e1ec07ceb9c  jmp 0x00007E1EC07CE78B
00007e1ec07ceba1  call 0x00007E1EC05FF430
00007e1ec07ceba6  jmp 0x00007E1EC07CE796
00007e1ec07cebab  call 0x00007E1EC060E760
00007e1ec07cebb0  jmp 0x00007E1EC07CE7A1
00007e1ec07cebb5  call 0x00007E1EC060C380
00007e1ec07cebba  jmp 0x00007E1EC07CE7AC
00007e1ec07cebbf  call 0x00007E1EC05FF540
00007e1ec07cebc4  jmp 0x00007E1EC07CE7B7
00007e1ec07cebc9  call 0x00007E1EC05FF430
00007e1ec07cebce  jmp 0x00007E1EC07CE7C2
00007e1ec07cebd3  call 0x00007E1EC060D4E0
00007e1ec07cebd8  jmp 0x00007E1EC07CE7CD
00007e1ec07cebdd  call 0x00007E1EC060E880
00007e1ec07cebe2  jmp 0x00007E1EC07CE7E0
00007e1ec07cebe7  call 0x00007E1EC05FF540
00007e1ec07cebec  jmp 0x00007E1EC07CE7EB
00007e1ec07cebf1  call 0x00007E1EC05FF430
00007e1ec07cebf6  jmp 0x00007E1EC07CE7F6
00007e1ec07cebfb  call 0x00007E1EC060E760
00007e1ec07cec00  jmp 0x00007E1EC07CE801
00007e1ec07cec05  call 0x00007E1EC060D600
00007e1ec07cec0a  jmp 0x00007E1EC07CE81F
00007e1ec07cec0f  call 0x00007E1EC05FF540
00007e1ec07cec14  jmp 0x00007E1EC07CE82A
00007e1ec07cec19  call 0x00007E1EC05FF430
00007e1ec07cec1e  jmp 0x00007E1EC07CE835
00007e1ec07cec23  call 0x00007E1EC060D4E0
00007e1ec07cec28  jmp 0x00007E1EC07CE840
00007e1ec07cec2d  call 0x00007E1EC060BC20
00007e1ec07cec32  jmp 0x00007E1EC07CE870
00007e1ec07cec37  call 0x00007E1EC060A9A0
00007e1ec07cec3c  jmp 0x00007E1EC07CE87C
00007e1ec07cec41  call 0x00007E1EC060E880
00007e1ec07cec46  jmp 0x00007E1EC07CE887
00007e1ec07cec4b  call 0x00007E1EC05FF540
00007e1ec07cec50  jmp 0x00007E1EC07CE892
00007e1ec07cec55  call 0x00007E1EC05FF430
00007e1ec07cec5a  jmp 0x00007E1EC07CE89D
00007e1ec07cec5f  call 0x00007E1EC060B720
00007e1ec07cec64  jmp 0x00007E1EC07CE8A7
00007e1ec07cec69  call 0x00007E1EC060D600
00007e1ec07cec6e  jmp 0x00007E1EC07CE8BF
00007e1ec07cec73  call 0x00007E1EC05FF540
00007e1ec07cec78  jmp 0x00007E1EC07CE8CA
00007e1ec07cec7d  call 0x00007E1EC05FF430
00007e1ec07cec82  jmp 0x00007E1EC07CE8D5
00007e1ec07cec87  call 0x00007E1EC06B4CB0
00007e1ec07cec8c  jmp 0x00007E1EC07CE8E5
00007e1ec07cec91  call 0x00007E1EC060E760
00007e1ec07cec96  jmp 0x00007E1EC07CE8F0
00007e1ec07cec9b  call 0x00007E1EC060D4E0
00007e1ec07ceca0  jmp 0x00007E1EC07CE8FB
00007e1ec07ceca5  call 0x00007E1EC05FF540
00007e1ec07cecaa  jmp 0x00007E1EC07CE908
00007e1ec07cecaf  call 0x00007E1EC060BC20
00007e1ec07cecb4  jmp 0x00007E1EC07CE930
00007e1ec07cecb9  call 0x00007E1EC060A9A0
00007e1ec07cecbe  jmp 0x00007E1EC07CE93C
00007e1ec07cecc3  call 0x00007E1EC060E880
00007e1ec07cecc8  jmp 0x00007E1EC07CE949
00007e1ec07ceccd  call 0x00007E1EC060D600
00007e1ec07cecd2  jmp 0x00007E1EC07CE956
00007e1ec07cecd7  call 0x00007E1EC05FF430
00007e1ec07cecdc  jmp 0x00007E1EC07CE961
00007e1ec07cece1  call 0x00007E1EC060E760
00007e1ec07cece6  jmp 0x00007E1EC07CE96C
00007e1ec07ceceb  call 0x00007E1EC060BC20
00007e1ec07cecf0  jmp 0x00007E1EC07CE99C
00007e1ec07cecf5  call 0x00007E1EC060A9A0
00007e1ec07cecfa  jmp 0x00007E1EC07CE9A8
00007e1ec07cecff  call 0x00007E1EC060BC20
00007e1ec07ced04  jmp 0x00007E1EC07CE9D0
00007e1ec07ced09  call 0x00007E1EC060A9A0
00007e1ec07ced0e  jmp 0x00007E1EC07CE9DC
00007e1ec07ced13  call 0x00007E1EC05FF540
00007e1ec07ced18  jmp 0x00007E1EC07CE9E9
00007e1ec07ced1d  call 0x00007E1EC060E880
00007e1ec07ced22  jmp 0x00007E1EC07CE9F6
00007e1ec07ced27  call 0x00007E1EC05FF430
00007e1ec07ced2c  jmp 0x00007E1EC07CEA01
00007e1ec07ced31  call 0x00007E1EC060E760
00007e1ec07ced36  jmp 0x00007E1EC07CEA0C
00007e1ec07ced3b  call 0x00007E1EC060BC20
00007e1ec07ced40  jmp 0x00007E1EC07CEA36
00007e1ec07ced45  call 0x00007E1EC060A9A0
00007e1ec07ced4a  jmp 0x00007E1EC07CEA42
00007e1ec07ced4f  call 0x00007E1EC060BAE0
00007e1ec07ced54  jmp 0x00007E1EC07CEA52
00007e1ec07ced59  call 0x00007E1EC05FF540
00007e1ec07ced5e  jmp 0x00007E1EC07CEA5F
00007e1ec07ced63  call 0x00007E1EC060E880
00007e1ec07ced68  jmp 0x00007E1EC07CEA6C
00007e1ec07ced6d  int3
00007e1ec07ced6e  nop
00007e1ec07ced70  mov rax, [r15]
00007e1ec07ced73  lea r14, [rax+0x20]
00007e1ec07ced77  mov r12, [r13+r14*1]
00007e1ec07ced7c  mov r14, [r15+0x10]
00007e1ec07ced80  lea r11, [r12+r14*1]
00007e1ec07ced84  mov [r15+0x40], r11
00007e1ec07ced88  lea r12, [rax+0x20]
00007e1ec07ced8c  mov [r13+r12*1], r11
00007e1ec07ced91  test r14, r14
00007e1ec07ced94  setz r14b
00007e1ec07ced98  movzx r14, r14b
00007e1ec07ced9c  mov [rsp+0x414], r14b
00007e1ec07ceda4  cmp byte ptr [rsp+0x414], 0x00
00007e1ec07cedac  jz 0x00007E1EC07CEDDE
00007e1ec07cedae  cmp dword ptr [r15+0x318], 0x00
00007e1ec07cedb6  mov eax, 0x4109A0
00007e1ec07cedbb  mov [r15+0x100], rax
00007e1ec07cedc2  jz 0x00007E1EC05FE0A0
00007e1ec07cedc8  nop [rax+rax*1], eax
00007e1ec07cedcd  mov eax, 0x4109A0
00007e1ec07cedd2  mov [r15+0x100], rax
00007e1ec07cedd9  jmp 0x00007E1EC05FE110
00007e1ec07cedde  cmp dword ptr [r15+0x318], 0x00
00007e1ec07cede6  jz 0x00007E1EC07CEE30
00007e1ec07cedec  nop [rax+rax*1], ax
00007e1ec07cedf5  nop [rax+rax*1], eax
00007e1ec07cedfd  mov eax, 0x410738
00007e1ec07cee02  mov [r15+0x100], rax
00007e1ec07cee09  jmp 0x00007E1EC05FE110
00007e1ec07cee0e  int3
00007e1ec07cee0f  call 0x00007E1EC06E27E0
00007e1ec07cee14  jmp 0x00007E1EC07CED7C
00007e1ec07cee19  call 0x00007E1EC06C0860
00007e1ec07cee1e  jmp 0x00007E1EC07CED91
00007e1ec07cee23  int3
00007e1ec07cee24  nop [rax+rax*1], ax
00007e1ec07cee2d  nop [rax], eax
00007e1ec07cee30  mov rax, [r15+0xF8]
00007e1ec07cee37  lea r14, [rax-0x150]
00007e1ec07cee3e  mov [r15+0xF8], r14
00007e1ec07cee45  mov rax, [r15]
00007e1ec07cee48  lea r12, [rax+0x68]
00007e1ec07cee4c  mov r11, [r13+r12*1]
00007e1ec07cee51  mov [r15+0x88], r11
00007e1ec07cee58  lea r12, [rax+0x28]
00007e1ec07cee5c  mov [r15+0x40], r12
00007e1ec07cee60  mov [r15+0x48], r14
00007e1ec07cee64  mov qword ptr [r15+0x50], 0x420B90
00007e1ec07cee6c  lea rax, [r14+0x100]
00007e1ec07cee73  mov r12, [r15+0xE8]
00007e1ec07cee7a  mov r11, [r15+0xD8]
00007e1ec07cee81  mov [r13+rax*1], r12
00007e1ec07cee86  lea rax, [r14+0x108]
00007e1ec07cee8d  mov [r13+rax*1], r11
00007e1ec07cee92  lea rax, [r14+0x110]
00007e1ec07cee99  mov r12, [r15+0xD0]
00007e1ec07ceea0  mov r11, [r15+0xC8]
00007e1ec07ceea7  mov [r13+rax*1], r12
00007e1ec07ceeac  lea rax, [r14+0x118]
00007e1ec07ceeb3  mov [r13+rax*1], r11
00007e1ec07ceeb8  lea rax, [r14+0x120]
00007e1ec07ceebf  mov r12, [r15+0xC0]
00007e1ec07ceec6  mov r11, [r15+0xB8]
00007e1ec07ceecd  mov [r13+rax*1], r12
00007e1ec07ceed2  lea rax, [r14+0x128]
00007e1ec07ceed9  mov [r13+rax*1], r11
00007e1ec07ceede  lea rax, [r14+0x130]
00007e1ec07ceee5  mov r12, [r15+0xB0]
00007e1ec07ceeec  mov r11, [r15+0xA8]
00007e1ec07ceef3  mov [r13+rax*1], r12
00007e1ec07ceef8  lea rax, [r14+0x138]
00007e1ec07ceeff  mov [r13+rax*1], r11
00007e1ec07cef04  lea rax, [r14+0x140]
00007e1ec07cef0b  mov r12, [r15+0xA0]
00007e1ec07cef12  mov r11, [r15+0x98]
00007e1ec07cef19  mov [r13+rax*1], r12
00007e1ec07cef1e  lea rax, [r14+0x148]
00007e1ec07cef25  mov [r13+rax*1], r11
00007e1ec07cef2a  cmp dword ptr [r15+0x318], 0x00
00007e1ec07cef32  jz 0x00007E1EC07CEFD0
00007e1ec07cef38  nop [rax+rax*1], ax
00007e1ec07cef41  nop [rax+rax*1], eax
00007e1ec07cef49  mov eax, 0x410770
00007e1ec07cef4e  mov [r15+0x100], rax
00007e1ec07cef55  jmp 0x00007E1EC05FE110
00007e1ec07cef5a  int3
00007e1ec07cef5b  call 0x00007E1EC06C0370
00007e1ec07cef60  jmp 0x00007E1EC07CEE51
00007e1ec07cef65  call 0x00007E1EC060BC20
00007e1ec07cef6a  jmp 0x00007E1EC07CEE86
00007e1ec07cef6f  call 0x00007E1EC060A9A0
00007e1ec07cef74  jmp 0x00007E1EC07CEE92
00007e1ec07cef79  call 0x00007E1EC060BC20
00007e1ec07cef7e  jmp 0x00007E1EC07CEEAC
00007e1ec07cef83  call 0x00007E1EC060A9A0
00007e1ec07cef88  jmp 0x00007E1EC07CEEB8
00007e1ec07cef8d  call 0x00007E1EC060BC20
00007e1ec07cef92  jmp 0x00007E1EC07CEED2
00007e1ec07cef97  call 0x00007E1EC060A9A0
00007e1ec07cef9c  jmp 0x00007E1EC07CEEDE
00007e1ec07cefa1  call 0x00007E1EC060BC20
00007e1ec07cefa6  jmp 0x00007E1EC07CEEF8
00007e1ec07cefab  call 0x00007E1EC060A9A0
00007e1ec07cefb0  jmp 0x00007E1EC07CEF04
00007e1ec07cefb5  call 0x00007E1EC060BC20
00007e1ec07cefba  jmp 0x00007E1EC07CEF1E
00007e1ec07cefbf  call 0x00007E1EC060A9A0
00007e1ec07cefc4  jmp 0x00007E1EC07CEF2A
00007e1ec07cefc9  int3
00007e1ec07cefca  nop [rax+rax*1], ax
00007e1ec07cefd0  mov rax, [r15+0x08]
00007e1ec07cefd4  movzx r14d, byte ptr [r13+rax*1]
00007e1ec07cefda  movzx r14d, r14b
00007e1ec07cefde  mov [rsp+0x10], r14d
00007e1ec07cefe3  mov r14d, r14d
00007e1ec07cefe6  mov [r15+0x58], r14
00007e1ec07cefea  lea r14, [rax+0x01]
00007e1ec07cefee  mov [r15+0x08], r14
00007e1ec07ceff2  mov rax, [r15+0x88]
00007e1ec07ceff9  lea r14, [rax+0x01]
00007e1ec07ceffd  mov r12, [r15]
00007e1ec07cf000  lea r11, [r12+0x68]
00007e1ec07cf005  mov [r13+r11*1], r14
00007e1ec07cf00a  lea r14, [r12+rax*1]
00007e1ec07cf00e  mov [r15+0x60], r14
00007e1ec07cf012  lea rax, [r14+0x28]
00007e1ec07cf016  mov r11d, [rsp+0x10]
00007e1ec07cf01b  movzx r14d, r11b
00007e1ec07cf01f  mov [r13+rax*1], r14b
00007e1ec07cf024  lea rax, [r12+0x68]
00007e1ec07cf029  mov r14, [r13+rax*1]
00007e1ec07cf02e  mov [r15+0x88], r14
00007e1ec07cf035  xor eax, eax
00007e1ec07cf037  mov r12d, 0x40
00007e1ec07cf03d  cmp r14, r12
00007e1ec07cf040  cmc
00007e1ec07cf041  lahf
00007e1ec07cf042  seto al
00007e1ec07cf045  mov [r15+0x108], eax
00007e1ec07cf04c  mov eax, [r15+0x108]
00007e1ec07cf053  sahf
00007e1ec07cf054  jnz 0x00007E1EC07CF086
00007e1ec07cf056  cmp dword ptr [r15+0x318], 0x00
00007e1ec07cf05e  jz 0x00007E1EC07CF170
00007e1ec07cf064  nop [rax+rax*1], ax
00007e1ec07cf06d  nop [rax+rax*1], eax
00007e1ec07cf075  mov eax, 0x410790
00007e1ec07cf07a  mov [r15+0x100], rax
00007e1ec07cf081  jmp 0x00007E1EC05FE110
00007e1ec07cf086  cmp dword ptr [r15+0x318], 0x00
00007e1ec07cf08e  jz 0x00007E1EC07CF0E0
00007e1ec07cf094  nop [rax+rax*1], ax
00007e1ec07cf09d  nop [rax+rax*1], eax
00007e1ec07cf0a5  mov eax, 0x410768
00007e1ec07cf0aa  mov [r15+0x100], rax
00007e1ec07cf0b1  jmp 0x00007E1EC05FE110
00007e1ec07cf0b6  int3
00007e1ec07cf0b7  call 0x00007E1EC060D860
00007e1ec07cf0bc  jmp 0x00007E1EC07CEFDA
00007e1ec07cf0c1  call 0x00007E1EC06B36E0
00007e1ec07cf0c6  jmp 0x00007E1EC07CF00A
00007e1ec07cf0cb  call 0x00007E1EC060DD60
00007e1ec07cf0d0  jmp 0x00007E1EC07CF024
00007e1ec07cf0d5  call 0x00007E1EC060DC20
00007e1ec07cf0da  jmp 0x00007E1EC07CF02E
00007e1ec07cf0df  int3
00007e1ec07cf0e0  mov rax, [r15+0x10]
00007e1ec07cf0e4  lea r14, [rax-0x01]
00007e1ec07cf0e8  mov [r15+0x10], r14
00007e1ec07cf0ec  test r14, r14
00007e1ec07cf0ef  setz r14b
00007e1ec07cf0f3  movzx r14, r14b
00007e1ec07cf0f7  mov [rsp+0x414], r14b
00007e1ec07cf0ff  cmp byte ptr [rsp+0x414], 0x00
00007e1ec07cf107  jz 0x00007E1EC07CF139
00007e1ec07cf109  cmp dword ptr [r15+0x318], 0x00
00007e1ec07cf111  jz 0x00007E1EC07D0670
00007e1ec07cf117  nop [rax+rax*1], ax
00007e1ec07cf120  nop [rax+rax*1], eax
00007e1ec07cf128  mov eax, 0x410988
00007e1ec07cf12d  mov [r15+0x100], rax
00007e1ec07cf134  jmp 0x00007E1EC05FE110
00007e1ec07cf139  cmp dword ptr [r15+0x318], 0x00
00007e1ec07cf141  jz 0x00007E1EC07CEFD0
00007e1ec07cf147  nop [rax+rax*1], ax
00007e1ec07cf150  nop [rax+rax*1], eax
00007e1ec07cf158  mov eax, 0x410770
00007e1ec07cf15d  mov [r15+0x100], rax
00007e1ec07cf164  jmp 0x00007E1EC05FE110
00007e1ec07cf169  int3
00007e1ec07cf16a  int3
00007e1ec07cf16b  nop [rax+rax*1], eax
00007e1ec07cf170  mov rax, [r15+0x40]
00007e1ec07cf174  movzx r14d, byte ptr [r13+rax*1]
00007e1ec07cf17a  movaps xmm1, [r15+0x110]
00007e1ec07cf182  pinsrb xmm1, r14d, 0x00
00007e1ec07cf189  lea r14, [rax+0x01]
00007e1ec07cf18d  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf193  movaps xmm15, [r15+0x120]
00007e1ec07cf19b  pinsrb xmm15, r12d, 0x00
00007e1ec07cf1a2  lea r14, [rax+0x02]
00007e1ec07cf1a6  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf1ac  movaps xmm14, [r15+0x130]
00007e1ec07cf1b4  pinsrb xmm14, r12d, 0x00
00007e1ec07cf1bb  lea r14, [rax+0x03]
00007e1ec07cf1bf  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf1c5  movaps xmm13, [r15+0x140]
00007e1ec07cf1cd  pinsrb xmm13, r12d, 0x00
00007e1ec07cf1d4  lea r14, [rax+0x04]
00007e1ec07cf1d8  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf1de  pinsrb xmm1, r12d, 0x01
00007e1ec07cf1e5  lea r14, [rax+0x05]
00007e1ec07cf1e9  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf1ef  pinsrb xmm15, r12d, 0x01
00007e1ec07cf1f6  lea r14, [rax+0x06]
00007e1ec07cf1fa  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf200  pinsrb xmm14, r12d, 0x01
00007e1ec07cf207  lea r14, [rax+0x07]
00007e1ec07cf20b  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf211  pinsrb xmm13, r12d, 0x01
00007e1ec07cf218  lea r14, [rax+0x08]
00007e1ec07cf21c  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf222  pinsrb xmm1, r12d, 0x02
00007e1ec07cf229  lea r14, [rax+0x09]
00007e1ec07cf22d  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf233  pinsrb xmm15, r12d, 0x02
00007e1ec07cf23a  lea r14, [rax+0x0A]
00007e1ec07cf23e  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf244  pinsrb xmm14, r12d, 0x02
00007e1ec07cf24b  lea r14, [rax+0x0B]
00007e1ec07cf24f  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf255  pinsrb xmm13, r12d, 0x02
00007e1ec07cf25c  lea r14, [rax+0x0C]
00007e1ec07cf260  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf266  pinsrb xmm1, r12d, 0x03
00007e1ec07cf26d  lea r14, [rax+0x0D]
00007e1ec07cf271  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf277  pinsrb xmm15, r12d, 0x03
00007e1ec07cf27e  lea r14, [rax+0x0E]
00007e1ec07cf282  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf288  pinsrb xmm14, r12d, 0x03
00007e1ec07cf28f  lea r14, [rax+0x0F]
00007e1ec07cf293  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf299  pinsrb xmm13, r12d, 0x03
00007e1ec07cf2a0  lea r14, [rax+0x10]
00007e1ec07cf2a4  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf2aa  pinsrb xmm1, r12d, 0x04
00007e1ec07cf2b1  lea r14, [rax+0x11]
00007e1ec07cf2b5  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf2bb  pinsrb xmm15, r12d, 0x04
00007e1ec07cf2c2  lea r14, [rax+0x12]
00007e1ec07cf2c6  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf2cc  pinsrb xmm14, r12d, 0x04
00007e1ec07cf2d3  lea r14, [rax+0x13]
00007e1ec07cf2d7  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf2dd  pinsrb xmm13, r12d, 0x04
00007e1ec07cf2e4  lea r14, [rax+0x14]
00007e1ec07cf2e8  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf2ee  pinsrb xmm1, r12d, 0x05
00007e1ec07cf2f5  lea r14, [rax+0x15]
00007e1ec07cf2f9  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf2ff  pinsrb xmm15, r12d, 0x05
00007e1ec07cf306  lea r14, [rax+0x16]
00007e1ec07cf30a  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf310  pinsrb xmm14, r12d, 0x05
00007e1ec07cf317  lea r14, [rax+0x17]
00007e1ec07cf31b  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf321  pinsrb xmm13, r12d, 0x05
00007e1ec07cf328  lea r14, [rax+0x18]
00007e1ec07cf32c  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf332  pinsrb xmm1, r12d, 0x06
00007e1ec07cf339  lea r14, [rax+0x19]
00007e1ec07cf33d  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf343  pinsrb xmm15, r12d, 0x06
00007e1ec07cf34a  lea r14, [rax+0x1A]
00007e1ec07cf34e  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf354  pinsrb xmm14, r12d, 0x06
00007e1ec07cf35b  lea r14, [rax+0x1B]
00007e1ec07cf35f  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf365  pinsrb xmm13, r12d, 0x06
00007e1ec07cf36c  lea r14, [rax+0x1C]
00007e1ec07cf370  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf376  pinsrb xmm1, r12d, 0x07
00007e1ec07cf37d  lea r14, [rax+0x1D]
00007e1ec07cf381  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf387  pinsrb xmm15, r12d, 0x07
00007e1ec07cf38e  lea r14, [rax+0x1E]
00007e1ec07cf392  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf398  pinsrb xmm14, r12d, 0x07
00007e1ec07cf39f  lea r14, [rax+0x1F]
00007e1ec07cf3a3  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf3a9  pinsrb xmm13, r12d, 0x07
00007e1ec07cf3b0  lea r14, [rax+0x20]
00007e1ec07cf3b4  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf3ba  pinsrb xmm1, r12d, 0x08
00007e1ec07cf3c1  lea r14, [rax+0x21]
00007e1ec07cf3c5  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf3cb  pinsrb xmm15, r12d, 0x08
00007e1ec07cf3d2  lea r14, [rax+0x22]
00007e1ec07cf3d6  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf3dc  pinsrb xmm14, r12d, 0x08
00007e1ec07cf3e3  lea r14, [rax+0x23]
00007e1ec07cf3e7  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf3ed  pinsrb xmm13, r12d, 0x08
00007e1ec07cf3f4  lea r14, [rax+0x24]
00007e1ec07cf3f8  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf3fe  pinsrb xmm1, r12d, 0x09
00007e1ec07cf405  lea r14, [rax+0x25]
00007e1ec07cf409  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf40f  pinsrb xmm15, r12d, 0x09
00007e1ec07cf416  lea r14, [rax+0x26]
00007e1ec07cf41a  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf420  pinsrb xmm14, r12d, 0x09
00007e1ec07cf427  lea r14, [rax+0x27]
00007e1ec07cf42b  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf431  pinsrb xmm13, r12d, 0x09
00007e1ec07cf438  lea r14, [rax+0x28]
00007e1ec07cf43c  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf442  pinsrb xmm1, r12d, 0x0A
00007e1ec07cf449  lea r14, [rax+0x29]
00007e1ec07cf44d  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf453  pinsrb xmm15, r12d, 0x0A
00007e1ec07cf45a  lea r14, [rax+0x2A]
00007e1ec07cf45e  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf464  pinsrb xmm14, r12d, 0x0A
00007e1ec07cf46b  lea r14, [rax+0x2B]
00007e1ec07cf46f  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf475  pinsrb xmm13, r12d, 0x0A
00007e1ec07cf47c  lea r14, [rax+0x2C]
00007e1ec07cf480  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf486  pinsrb xmm1, r12d, 0x0B
00007e1ec07cf48d  lea r14, [rax+0x2D]
00007e1ec07cf491  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf497  pinsrb xmm15, r12d, 0x0B
00007e1ec07cf49e  lea r14, [rax+0x2E]
00007e1ec07cf4a2  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf4a8  pinsrb xmm14, r12d, 0x0B
00007e1ec07cf4af  lea r14, [rax+0x2F]
00007e1ec07cf4b3  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf4b9  pinsrb xmm13, r12d, 0x0B
00007e1ec07cf4c0  lea r14, [rax+0x30]
00007e1ec07cf4c4  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf4ca  pinsrb xmm1, r12d, 0x0C
00007e1ec07cf4d1  lea r14, [rax+0x31]
00007e1ec07cf4d5  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf4db  pinsrb xmm15, r12d, 0x0C
00007e1ec07cf4e2  lea r14, [rax+0x32]
00007e1ec07cf4e6  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf4ec  pinsrb xmm14, r12d, 0x0C
00007e1ec07cf4f3  lea r14, [rax+0x33]
00007e1ec07cf4f7  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf4fd  pinsrb xmm13, r12d, 0x0C
00007e1ec07cf504  lea r14, [rax+0x34]
00007e1ec07cf508  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf50e  pinsrb xmm1, r12d, 0x0D
00007e1ec07cf515  lea r14, [rax+0x35]
00007e1ec07cf519  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf51f  pinsrb xmm15, r12d, 0x0D
00007e1ec07cf526  lea r14, [rax+0x36]
00007e1ec07cf52a  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf530  pinsrb xmm14, r12d, 0x0D
00007e1ec07cf537  lea r14, [rax+0x37]
00007e1ec07cf53b  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf541  pinsrb xmm13, r12d, 0x0D
00007e1ec07cf548  lea r14, [rax+0x38]
00007e1ec07cf54c  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf552  pinsrb xmm1, r12d, 0x0E
00007e1ec07cf559  lea r14, [rax+0x39]
00007e1ec07cf55d  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf563  pinsrb xmm15, r12d, 0x0E
00007e1ec07cf56a  lea r14, [rax+0x3A]
00007e1ec07cf56e  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf574  pinsrb xmm14, r12d, 0x0E
00007e1ec07cf57b  lea r14, [rax+0x3B]
00007e1ec07cf57f  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf585  pinsrb xmm13, r12d, 0x0E
00007e1ec07cf58c  lea r14, [rax+0x3C]
00007e1ec07cf590  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf596  pinsrb xmm1, r12d, 0x0F
00007e1ec07cf59d  movaps [r15+0x110], xmm1
00007e1ec07cf5a5  lea r14, [rax+0x3D]
00007e1ec07cf5a9  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf5af  pinsrb xmm15, r12d, 0x0F
00007e1ec07cf5b6  movaps [r15+0x120], xmm15
00007e1ec07cf5be  lea r14, [rax+0x3E]
00007e1ec07cf5c2  movzx r12d, byte ptr [r13+r14*1]
00007e1ec07cf5c8  pinsrb xmm14, r12d, 0x0F
00007e1ec07cf5cf  movaps [r15+0x130], xmm14
00007e1ec07cf5d7  lea r14, [rax+0x3F]
00007e1ec07cf5db  movzx eax, byte ptr [r13+r14*1]
00007e1ec07cf5e1  pinsrb xmm13, eax, 0x0F
00007e1ec07cf5e8  movaps [r15+0x140], xmm13
00007e1ec07cf5f0  movq xmm1, qword ptr [r15+0x120]
00007e1ec07cf5f9  pmovzxbw xmm1, xmm1
00007e1ec07cf5fe  psllw xmm1, 0x00
00007e1ec07cf603  movaps [r15+0x150], xmm1
00007e1ec07cf60b  movq xmm1, qword ptr [r15+0x130]
00007e1ec07cf614  pmovzxbw xmm1, xmm1
00007e1ec07cf619  psllw xmm1, 0x00
00007e1ec07cf61e  movaps [r15+0x160], xmm1
00007e1ec07cf626  movq xmm1, qword ptr [r15+0x110]
00007e1ec07cf62f  pmovzxbw xmm1, xmm1
00007e1ec07cf634  psllw xmm1, 0x00
00007e1ec07cf639  movaps [r15+0x170], xmm1
00007e1ec07cf641  movaps xmm15, [r15+0x110]
00007e1ec07cf649  pextrq rax, xmm15, 0x01
00007e1ec07cf650  movq xmm15, rax
00007e1ec07cf655  pmovzxbw xmm15, xmm15
00007e1ec07cf65b  psllw xmm15, 0x00
00007e1ec07cf661  movaps [r15+0x180], xmm15
00007e1ec07cf669  movaps xmm14, [r15+0x120]
00007e1ec07cf671  pextrq rax, xmm14, 0x01
00007e1ec07cf678  movq xmm14, rax
00007e1ec07cf67d  pmovzxbw xmm14, xmm14
00007e1ec07cf683  psllw xmm14, 0x00
00007e1ec07cf689  movaps [r15+0x210], xmm14
00007e1ec07cf691  movaps xmm13, [r15+0x130]
00007e1ec07cf699  pextrq rax, xmm13, 0x01
00007e1ec07cf6a0  movq xmm13, rax
00007e1ec07cf6a5  pmovzxbw xmm13, xmm13
00007e1ec07cf6ab  psllw xmm13, 0x00
00007e1ec07cf6b1  movaps [r15+0x220], xmm13
00007e1ec07cf6b9  movq xmm12, qword ptr [r15+0x140]
00007e1ec07cf6c2  pmovzxbw xmm12, xmm12
00007e1ec07cf6c8  psllw xmm12, 0x00
00007e1ec07cf6ce  movaps [r15+0x250], xmm12
00007e1ec07cf6d6  movaps xmm12, [r15+0x140]
00007e1ec07cf6de  pextrq rax, xmm12, 0x01
00007e1ec07cf6e5  movq xmm12, rax
00007e1ec07cf6ea  pmovzxbw xmm12, xmm12
00007e1ec07cf6f0  psllw xmm12, 0x00
00007e1ec07cf6f6  movaps [r15+0x110], xmm12
00007e1ec07cf6fe  movq xmm11, qword ptr [r15+0x150]
00007e1ec07cf707  pmovzxwd xmm11, xmm11
00007e1ec07cf70d  pslld xmm11, 0x10
00007e1ec07cf713  movq xmm10, qword ptr [r15+0x160]
00007e1ec07cf71c  pmovzxwd xmm10, xmm10
00007e1ec07cf722  pslld xmm10, 0x08
00007e1ec07cf728  pextrq rax, xmm1, 0x01
00007e1ec07cf72f  movq xmm1, rax
00007e1ec07cf734  pmovzxwd xmm1, xmm1
00007e1ec07cf739  pslld xmm1, 0x00
00007e1ec07cf73e  movaps [r15+0x260], xmm1
00007e1ec07cf746  pextrq rax, xmm15, 0x01
00007e1ec07cf74d  movq xmm15, rax
00007e1ec07cf752  pmovzxwd xmm15, xmm15
00007e1ec07cf758  pslld xmm15, 0x00
00007e1ec07cf75e  movaps [r15+0x270], xmm15
00007e1ec07cf766  movq xmm9, qword ptr [r15+0x170]
00007e1ec07cf76f  pmovzxwd xmm9, xmm9
00007e1ec07cf775  pslld xmm9, 0x00
00007e1ec07cf77b  pextrq rax, xmm14, 0x01
00007e1ec07cf782  movq xmm14, rax
00007e1ec07cf787  pmovzxwd xmm14, xmm14
00007e1ec07cf78d  pslld xmm14, 0x10
00007e1ec07cf793  movaps [r15+0x280], xmm14
00007e1ec07cf79b  movq xmm8, qword ptr [r15+0x180]
00007e1ec07cf7a4  pmovzxwd xmm8, xmm8
00007e1ec07cf7aa  pslld xmm8, 0x00
00007e1ec07cf7b0  movq xmm7, qword ptr [r15+0x210]
00007e1ec07cf7b9  pmovzxwd xmm7, xmm7
00007e1ec07cf7be  pslld xmm7, 0x10
00007e1ec07cf7c3  movaps xmm6, [r15+0x150]
00007e1ec07cf7cb  pextrq rax, xmm6, 0x01
00007e1ec07cf7d2  movq xmm6, rax
00007e1ec07cf7d7  pmovzxwd xmm6, xmm6
00007e1ec07cf7dc  pslld xmm6, 0x10
00007e1ec07cf7e1  por xmm11, xmm10
00007e1ec07cf7e6  movaps [r15+0x230], xmm11
00007e1ec07cf7ee  pextrq rax, xmm13, 0x01
00007e1ec07cf7f5  movq xmm13, rax
00007e1ec07cf7fa  pmovzxwd xmm13, xmm13
00007e1ec07cf800  pslld xmm13, 0x08
00007e1ec07cf806  movaps [r15+0x240], xmm13
00007e1ec07cf80e  movq xmm10, qword ptr [r15+0x220]
00007e1ec07cf817  pmovzxwd xmm10, xmm10
00007e1ec07cf81d  pslld xmm10, 0x08
00007e1ec07cf823  movaps xmm5, [r15+0x160]
00007e1ec07cf82b  pextrq rax, xmm5, 0x01
00007e1ec07cf832  movq xmm5, rax
00007e1ec07cf837  pmovzxwd xmm5, xmm5
00007e1ec07cf83c  pslld xmm5, 0x08
00007e1ec07cf841  pslld xmm9, 0x18
00007e1ec07cf847  pslld xmm15, 0x18
00007e1ec07cf84d  pslld xmm8, 0x18
00007e1ec07cf853  movq xmm4, qword ptr [r15+0x250]
00007e1ec07cf85c  pmovzxwd xmm4, xmm4
00007e1ec07cf861  pslld xmm4, 0x00
00007e1ec07cf866  por xmm14, xmm13
00007e1ec07cf86b  por xmm7, xmm10
00007e1ec07cf870  movaps [r15+0x210], xmm7
00007e1ec07cf878  pslld xmm1, 0x18
00007e1ec07cf87d  movaps [r15+0x220], xmm1
00007e1ec07cf885  por xmm6, xmm5
00007e1ec07cf889  por xmm11, xmm9
00007e1ec07cf88e  movaps [r15+0x160], xmm11
00007e1ec07cf896  pextrq rax, xmm12, 0x01
00007e1ec07cf89d  movq xmm13, rax
00007e1ec07cf8a2  pmovzxwd xmm13, xmm13
00007e1ec07cf8a8  pslld xmm13, 0x00
00007e1ec07cf8ae  movaps [r15+0x170], xmm13
00007e1ec07cf8b6  movq xmm12, qword ptr [r15+0x110]
00007e1ec07cf8bf  pmovzxwd xmm12, xmm12
00007e1ec07cf8c5  pslld xmm12, 0x00
00007e1ec07cf8cb  por xmm14, xmm15
00007e1ec07cf8d0  por xmm7, xmm8
00007e1ec07cf8d5  movaps xmm15, [r15+0x250]
00007e1ec07cf8dd  pextrq rax, xmm15, 0x01
00007e1ec07cf8e4  movq xmm15, rax
00007e1ec07cf8e9  pmovzxwd xmm15, xmm15
00007e1ec07cf8ef  pslld xmm15, 0x00
00007e1ec07cf8f5  movaps [r15+0x180], xmm15
00007e1ec07cf8fd  por xmm6, xmm1
00007e1ec07cf901  movaps [r15+0x150], xmm6
00007e1ec07cf909  por xmm11, xmm4
00007e1ec07cf90e  movaps [r15+0x140], xmm11
00007e1ec07cf916  por xmm7, xmm12
00007e1ec07cf91b  movaps [r15+0x110], xmm7
00007e1ec07cf923  por xmm14, xmm13
00007e1ec07cf928  movaps [r15+0x120], xmm14
00007e1ec07cf930  por xmm6, xmm15
00007e1ec07cf935  movaps [r15+0x130], xmm6
00007e1ec07cf93d  mov rax, [r15+0xF8]
00007e1ec07cf944  lea r14, [rax+0x20]
00007e1ec07cf948  movups [r13+r14*1], xmm7
00007e1ec07cf94e  lea r14, [rax+0x30]
00007e1ec07cf952  movups [r13+r14*1], xmm14
00007e1ec07cf958  movups [r13+rax*1], xmm11
00007e1ec07cf95e  lea r14, [rax+0x10]
00007e1ec07cf962  movups [r13+r14*1], xmm6
00007e1ec07cf968  mov r14d, [r13+rax*1]
00007e1ec07cf96d  mov rax, [r15+0x48]
00007e1ec07cf971  mov [r15+0x68], rax
00007e1ec07cf975  mov qword ptr [r15+0x58], 0x04
00007e1ec07cf97d  lea r12, [rax+0x04]
00007e1ec07cf981  mov r11d, [r13+r12*1]
00007e1ec07cf986  mov [rsp+0x10], r11d
00007e1ec07cf98b  mov r11d, r11d
00007e1ec07cf98e  mov [r15+0x70], r11
00007e1ec07cf992  lea r12, [rax+0x38]
00007e1ec07cf996  mov r11d, [r13+r12*1]
00007e1ec07cf99b  lea r12, [rax+0x24]
00007e1ec07cf99f  mov r10d, [r13+r12*1]
00007e1ec07cf9a4  mov [rsp+0x20], r10d
00007e1ec07cf9a9  mov r10d, r10d
00007e1ec07cf9ac  mov [r15+0x90], r10
00007e1ec07cf9b3  mov [rsp+0x30], rax
00007e1ec07cf9b8  xor eax, eax
00007e1ec07cf9ba  mov r12d, 0x04
00007e1ec07cf9c0  mov r10d, 0xC0
00007e1ec07cf9c6  cmp r12, r10
00007e1ec07cf9c9  cmc
00007e1ec07cf9ca  lahf
00007e1ec07cf9cb  seto al
00007e1ec07cf9ce  mov [r15+0x108], eax
00007e1ec07cf9d5  mov eax, [rsp+0x10]
00007e1ec07cf9d9  mov r12d, [rsp+0x10]
00007e1ec07cf9de  shrd eax, r12d, 0x07
00007e1ec07cf9e3  mov [rsp+0x10], r11d
00007e1ec07cf9e8  mov r10d, [rsp+0x10]
00007e1ec07cf9ed  shrd r11d, r10d, 0x11
00007e1ec07cf9f2  mov r9d, [rsp+0x20]
00007e1ec07cf9f7  lea r8d, [r9d+r14d*1]
00007e1ec07cf9fc  rorx r14d, r12d, 0x12
00007e1ec07cfa02  xor eax, r14d
00007e1ec07cfa05  rorx r14d, r10d, 0x13
00007e1ec07cfa0b  xor r11d, r14d
00007e1ec07cfa0e  mov [rsp+0x10], r11d
00007e1ec07cfa13  mov r11d, r11d
00007e1ec07cfa16  mov [r15+0x88], r11
00007e1ec07cfa1d  mov [rsp+0x20], r12d
00007e1ec07cfa22  shr r12d, 0x03
00007e1ec07cfa26  xor eax, r12d
00007e1ec07cfa29  mov [rsp+0x40], eax
00007e1ec07cfa2d  mov eax, eax
00007e1ec07cfa2f  mov [r15+0x80], rax
00007e1ec07cfa36  shr r10d, 0x0A
00007e1ec07cfa3a  mov eax, [rsp+0x10]
00007e1ec07cfa3e  xor eax, r10d
00007e1ec07cfa41  mov [rsp+0x10], eax
00007e1ec07cfa45  mov eax, eax
00007e1ec07cfa47  mov [r15+0x78], rax
00007e1ec07cfa4b  mov eax, [rsp+0x40]
00007e1ec07cfa4f  lea r14d, [r8d+eax*1]
00007e1ec07cfa54  mov eax, [rsp+0x10]
00007e1ec07cfa58  lea r12d, [r14d+eax*1]
00007e1ec07cfa5d  mov rax, [rsp+0x30]
00007e1ec07cfa62  lea r14, [rax+0x40]
00007e1ec07cfa66  mov [r13+r14*1], r12d
00007e1ec07cfa6b  mov eax, [rsp+0x20]
00007e1ec07cfa6f  mov eax, eax
00007e1ec07cfa71  mov [r15+0x60], rax
00007e1ec07cfa75  mov eax, [r15+0x108]
00007e1ec07cfa7c  sahf
00007e1ec07cfa7d  jnz 0x00007E1EC07CFAAF
00007e1ec07cfa7f  cmp dword ptr [r15+0x318], 0x00
00007e1ec07cfa87  jz 0x00007E1EC07CFF70
00007e1ec07cfa8d  nop [rax+rax*1], ax
00007e1ec07cfa96  nop [rax+rax*1], eax
00007e1ec07cfa9e  mov eax, 0x41088C
00007e1ec07cfaa3  mov [r15+0x100], rax
00007e1ec07cfaaa  jmp 0x00007E1EC05FE110
00007e1ec07cfaaf  cmp dword ptr [r15+0x318], 0x00
00007e1ec07cfab7  jz 0x00007E1EC07CFDC0
00007e1ec07cfabd  nop [rax+rax*1], ax
00007e1ec07cfac6  nop [rax+rax*1], eax
00007e1ec07cface  mov eax, 0x410844
00007e1ec07cfad3  mov [r15+0x100], rax
00007e1ec07cfada  jmp 0x00007E1EC05FE110
00007e1ec07cfadf  int3
00007e1ec07cfae0  call 0x00007E1EC060D860
00007e1ec07cfae5  jmp 0x00007E1EC07CF17A
00007e1ec07cfaea  call 0x00007E1EC06E2420
00007e1ec07cfaef  jmp 0x00007E1EC07CF193
00007e1ec07cfaf4  call 0x00007E1EC06E2420
00007e1ec07cfaf9  jmp 0x00007E1EC07CF1AC
00007e1ec07cfafe  call 0x00007E1EC06E2420
00007e1ec07cfb03  jmp 0x00007E1EC07CF1C5
00007e1ec07cfb08  call 0x00007E1EC06E2420
00007e1ec07cfb0d  jmp 0x00007E1EC07CF1DE
00007e1ec07cfb12  call 0x00007E1EC06E2420
00007e1ec07cfb17  jmp 0x00007E1EC07CF1EF
00007e1ec07cfb1c  call 0x00007E1EC06E2420
00007e1ec07cfb21  jmp 0x00007E1EC07CF200
00007e1ec07cfb26  call 0x00007E1EC06E2420
00007e1ec07cfb2b  jmp 0x00007E1EC07CF211
00007e1ec07cfb30  call 0x00007E1EC06E2420
00007e1ec07cfb35  jmp 0x00007E1EC07CF222
00007e1ec07cfb3a  call 0x00007E1EC06E2420
00007e1ec07cfb3f  jmp 0x00007E1EC07CF233
00007e1ec07cfb44  call 0x00007E1EC06E2420
00007e1ec07cfb49  jmp 0x00007E1EC07CF244
00007e1ec07cfb4e  call 0x00007E1EC06E2420
00007e1ec07cfb53  jmp 0x00007E1EC07CF255
00007e1ec07cfb58  call 0x00007E1EC06E2420
00007e1ec07cfb5d  jmp 0x00007E1EC07CF266
00007e1ec07cfb62  call 0x00007E1EC06E2420
00007e1ec07cfb67  jmp 0x00007E1EC07CF277
00007e1ec07cfb6c  call 0x00007E1EC06E2420
00007e1ec07cfb71  jmp 0x00007E1EC07CF288
00007e1ec07cfb76  call 0x00007E1EC06E2420
00007e1ec07cfb7b  jmp 0x00007E1EC07CF299
00007e1ec07cfb80  call 0x00007E1EC06E2420
00007e1ec07cfb85  jmp 0x00007E1EC07CF2AA
00007e1ec07cfb8a  call 0x00007E1EC06E2420
00007e1ec07cfb8f  jmp 0x00007E1EC07CF2BB
00007e1ec07cfb94  call 0x00007E1EC06E2420
00007e1ec07cfb99  jmp 0x00007E1EC07CF2CC
00007e1ec07cfb9e  call 0x00007E1EC06E2420
00007e1ec07cfba3  jmp 0x00007E1EC07CF2DD
00007e1ec07cfba8  call 0x00007E1EC06E2420
00007e1ec07cfbad  jmp 0x00007E1EC07CF2EE
00007e1ec07cfbb2  call 0x00007E1EC06E2420
00007e1ec07cfbb7  jmp 0x00007E1EC07CF2FF
00007e1ec07cfbbc  call 0x00007E1EC06E2420
00007e1ec07cfbc1  jmp 0x00007E1EC07CF310
00007e1ec07cfbc6  call 0x00007E1EC06E2420
00007e1ec07cfbcb  jmp 0x00007E1EC07CF321
00007e1ec07cfbd0  call 0x00007E1EC06E2420
00007e1ec07cfbd5  jmp 0x00007E1EC07CF332
00007e1ec07cfbda  call 0x00007E1EC06E2420
00007e1ec07cfbdf  jmp 0x00007E1EC07CF343
00007e1ec07cfbe4  call 0x00007E1EC06E2420
00007e1ec07cfbe9  jmp 0x00007E1EC07CF354
00007e1ec07cfbee  call 0x00007E1EC06E2420
00007e1ec07cfbf3  jmp 0x00007E1EC07CF365
00007e1ec07cfbf8  call 0x00007E1EC06E2420
00007e1ec07cfbfd  jmp 0x00007E1EC07CF376
00007e1ec07cfc02  call 0x00007E1EC06E2420
00007e1ec07cfc07  jmp 0x00007E1EC07CF387
00007e1ec07cfc0c  call 0x00007E1EC06E2420
00007e1ec07cfc11  jmp 0x00007E1EC07CF398
00007e1ec07cfc16  call 0x00007E1EC06E2420
00007e1ec07cfc1b  jmp 0x00007E1EC07CF3A9
00007e1ec07cfc20  call 0x00007E1EC06E2420
00007e1ec07cfc25  jmp 0x00007E1EC07CF3BA
00007e1ec07cfc2a  call 0x00007E1EC06E2420
00007e1ec07cfc2f  jmp 0x00007E1EC07CF3CB
00007e1ec07cfc34  call 0x00007E1EC06E2420
00007e1ec07cfc39  jmp 0x00007E1EC07CF3DC
00007e1ec07cfc3e  call 0x00007E1EC06E2420
00007e1ec07cfc43  jmp 0x00007E1EC07CF3ED
00007e1ec07cfc48  call 0x00007E1EC06E2420
00007e1ec07cfc4d  jmp 0x00007E1EC07CF3FE
00007e1ec07cfc52  call 0x00007E1EC06E2420
00007e1ec07cfc57  jmp 0x00007E1EC07CF40F
00007e1ec07cfc5c  call 0x00007E1EC06E2420
00007e1ec07cfc61  jmp 0x00007E1EC07CF420
00007e1ec07cfc66  call 0x00007E1EC06E2420
00007e1ec07cfc6b  jmp 0x00007E1EC07CF431
00007e1ec07cfc70  call 0x00007E1EC06E2420
00007e1ec07cfc75  jmp 0x00007E1EC07CF442
00007e1ec07cfc7a  call 0x00007E1EC06E2420
00007e1ec07cfc7f  jmp 0x00007E1EC07CF453
00007e1ec07cfc84  call 0x00007E1EC06E2420
00007e1ec07cfc89  jmp 0x00007E1EC07CF464
00007e1ec07cfc8e  call 0x00007E1EC06E2420
00007e1ec07cfc93  jmp 0x00007E1EC07CF475
00007e1ec07cfc98  call 0x00007E1EC06E2420
00007e1ec07cfc9d  jmp 0x00007E1EC07CF486
00007e1ec07cfca2  call 0x00007E1EC06E2420
00007e1ec07cfca7  jmp 0x00007E1EC07CF497
00007e1ec07cfcac  call 0x00007E1EC06E2420
00007e1ec07cfcb1  jmp 0x00007E1EC07CF4A8
00007e1ec07cfcb6  call 0x00007E1EC06E2420
00007e1ec07cfcbb  jmp 0x00007E1EC07CF4B9
00007e1ec07cfcc0  call 0x00007E1EC06E2420
00007e1ec07cfcc5  jmp 0x00007E1EC07CF4CA
00007e1ec07cfcca  call 0x00007E1EC06E2420
00007e1ec07cfccf  jmp 0x00007E1EC07CF4DB
00007e1ec07cfcd4  call 0x00007E1EC06E2420
00007e1ec07cfcd9  jmp 0x00007E1EC07CF4EC
00007e1ec07cfcde  call 0x00007E1EC06E2420
00007e1ec07cfce3  jmp 0x00007E1EC07CF4FD
00007e1ec07cfce8  call 0x00007E1EC06E2420
00007e1ec07cfced  jmp 0x00007E1EC07CF50E
00007e1ec07cfcf2  call 0x00007E1EC06E2420
00007e1ec07cfcf7  jmp 0x00007E1EC07CF51F
00007e1ec07cfcfc  call 0x00007E1EC06E2420
00007e1ec07cfd01  jmp 0x00007E1EC07CF530
00007e1ec07cfd06  call 0x00007E1EC06E2420
00007e1ec07cfd0b  jmp 0x00007E1EC07CF541
00007e1ec07cfd10  call 0x00007E1EC06E2420
00007e1ec07cfd15  jmp 0x00007E1EC07CF552
00007e1ec07cfd1a  call 0x00007E1EC06E2420
00007e1ec07cfd1f  jmp 0x00007E1EC07CF563
00007e1ec07cfd24  call 0x00007E1EC06E2420
00007e1ec07cfd29  jmp 0x00007E1EC07CF574
00007e1ec07cfd2e  call 0x00007E1EC06E2420
00007e1ec07cfd33  jmp 0x00007E1EC07CF585
00007e1ec07cfd38  call 0x00007E1EC06E2420
00007e1ec07cfd3d  jmp 0x00007E1EC07CF596
00007e1ec07cfd42  call 0x00007E1EC06E2420
00007e1ec07cfd47  jmp 0x00007E1EC07CF5AF
00007e1ec07cfd4c  call 0x00007E1EC06E2420
00007e1ec07cfd51  jmp 0x00007E1EC07CF5C8
00007e1ec07cfd56  call 0x00007E1EC06D5610
00007e1ec07cfd5b  jmp 0x00007E1EC07CF5E1
00007e1ec07cfd60  call 0x00007E1EC06DC580
00007e1ec07cfd65  jmp 0x00007E1EC07CF94E
00007e1ec07cfd6a  call 0x00007E1EC06E46C0
00007e1ec07cfd6f  jmp 0x00007E1EC07CF958
00007e1ec07cfd74  call 0x00007E1EC0609E90
00007e1ec07cfd79  jmp 0x00007E1EC07CF95E
00007e1ec07cfd7e  call 0x00007E1EC06DB310
00007e1ec07cfd83  jmp 0x00007E1EC07CF968
00007e1ec07cfd88  call 0x00007E1EC060DAE0
00007e1ec07cfd8d  jmp 0x00007E1EC07CF96D
00007e1ec07cfd92  call 0x00007E1EC06C0230
00007e1ec07cfd97  jmp 0x00007E1EC07CF986
00007e1ec07cfd9c  call 0x00007E1EC06C0230
00007e1ec07cfda1  jmp 0x00007E1EC07CF99B
00007e1ec07cfda6  call 0x00007E1EC06BEFC0
00007e1ec07cfdab  jmp 0x00007E1EC07CF9A4
00007e1ec07cfdb0  call 0x00007E1EC06E2BA0
00007e1ec07cfdb5  jmp 0x00007E1EC07CFA6B
00007e1ec07cfdba  int3
00007e1ec07cfdbb  nop [rax+rax*1], eax
00007e1ec07cfdc0  mov rax, [r15+0x48]
00007e1ec07cfdc4  mov r14, [r15+0x58]
00007e1ec07cfdc8  lea r12, [rax+r14*1]
00007e1ec07cfdcc  mov [r15+0x68], r12
00007e1ec07cfdd0  lea rax, [r14+0x04]
00007e1ec07cfdd4  mov [r15+0x58], rax
00007e1ec07cfdd8  lea r14, [r12+0x04]
00007e1ec07cfddd  mov r11d, [r13+r14*1]
00007e1ec07cfde2  mov [rsp+0x10], r11d
00007e1ec07cfde7  mov r11d, r11d
00007e1ec07cfdea  mov [r15+0x70], r11
00007e1ec07cfdee  lea r14, [r12+0x38]
00007e1ec07cfdf3  mov r11d, [r13+r14*1]
00007e1ec07cfdf8  lea r14, [r12+0x24]
00007e1ec07cfdfd  mov r10d, [r13+r14*1]
00007e1ec07cfe02  mov [rsp+0x20], r10d
00007e1ec07cfe07  mov r10d, r10d
00007e1ec07cfe0a  mov [r15+0x90], r10
00007e1ec07cfe11  mov [rsp+0x30], rax
00007e1ec07cfe16  xor eax, eax
00007e1ec07cfe18  mov r14, [rsp+0x30]
00007e1ec07cfe1d  mov r10d, 0xC0
00007e1ec07cfe23  cmp r14, r10
00007e1ec07cfe26  cmc
00007e1ec07cfe27  lahf
00007e1ec07cfe28  seto al
00007e1ec07cfe2b  mov [r15+0x108], eax
00007e1ec07cfe32  mov eax, [rsp+0x10]
00007e1ec07cfe36  mov r14d, [rsp+0x10]
00007e1ec07cfe3b  shrd eax, r14d, 0x07
00007e1ec07cfe40  mov [rsp+0x10], r11d
00007e1ec07cfe45  mov r10d, [rsp+0x10]
00007e1ec07cfe4a  shrd r11d, r10d, 0x11
00007e1ec07cfe4f  mov r9d, [r15+0x60]
00007e1ec07cfe53  mov r8d, [rsp+0x20]
00007e1ec07cfe58  lea ebp, [r8d+r9d*1]
00007e1ec07cfe5d  rorx r9d, r14d, 0x12
00007e1ec07cfe63  xor eax, r9d
00007e1ec07cfe66  rorx r9d, r10d, 0x13
00007e1ec07cfe6c  xor r11d, r9d
00007e1ec07cfe6f  mov [rsp+0x10], r11d
00007e1ec07cfe74  mov r11d, r11d
00007e1ec07cfe77  mov [r15+0x88], r11
00007e1ec07cfe7e  mov [rsp+0x20], r14d
00007e1ec07cfe83  shr r14d, 0x03
00007e1ec07cfe87  xor eax, r14d
00007e1ec07cfe8a  mov [rsp+0x30], eax
00007e1ec07cfe8e  mov eax, eax
00007e1ec07cfe90  mov [r15+0x80], rax
00007e1ec07cfe97  shr r10d, 0x0A
00007e1ec07cfe9b  mov eax, [rsp+0x10]
00007e1ec07cfe9f  xor eax, r10d
00007e1ec07cfea2  mov [rsp+0x10], eax
00007e1ec07cfea6  mov eax, eax
00007e1ec07cfea8  mov [r15+0x78], rax
00007e1ec07cfeac  mov eax, [rsp+0x30]
00007e1ec07cfeb0  lea r14d, [ebp+eax*1]
00007e1ec07cfeb6  mov eax, [rsp+0x10]
00007e1ec07cfeba  lea r11d, [r14d+eax*1]
00007e1ec07cfebf  lea rax, [r12+0x40]
00007e1ec07cfec4  mov [r13+rax*1], r11d
00007e1ec07cfec9  mov eax, [rsp+0x20]
00007e1ec07cfecd  mov eax, eax
00007e1ec07cfecf  mov [r15+0x60], rax
00007e1ec07cfed3  mov eax, [r15+0x108]
00007e1ec07cfeda  sahf
00007e1ec07cfedb  jnz 0x00007E1EC07CFF0D
00007e1ec07cfedd  cmp dword ptr [r15+0x318], 0x00
00007e1ec07cfee5  jz 0x00007E1EC07CFF70
00007e1ec07cfeeb  nop [rax+rax*1], ax
00007e1ec07cfef4  nop [rax+rax*1], eax
00007e1ec07cfefc  mov eax, 0x41088C
00007e1ec07cff01  mov [r15+0x100], rax
00007e1ec07cff08  jmp 0x00007E1EC05FE110
00007e1ec07cff0d  cmp dword ptr [r15+0x318], 0x00
00007e1ec07cff15  jz 0x00007E1EC07CFDC0
00007e1ec07cff1b  nop [rax+rax*1], ax
00007e1ec07cff24  nop [rax+rax*1], eax
00007e1ec07cff2c  mov eax, 0x410844
00007e1ec07cff31  mov [r15+0x100], rax
00007e1ec07cff38  jmp 0x00007E1EC05FE110
00007e1ec07cff3d  int3
00007e1ec07cff3e  call 0x00007E1EC06E1430
00007e1ec07cff43  jmp 0x00007E1EC07CFDE2
00007e1ec07cff48  call 0x00007E1EC06E1430
00007e1ec07cff4d  jmp 0x00007E1EC07CFDF8
00007e1ec07cff52  call 0x00007E1EC06E01C0
00007e1ec07cff57  jmp 0x00007E1EC07CFE02
00007e1ec07cff5c  call 0x00007E1EC060A860
00007e1ec07cff61  jmp 0x00007E1EC07CFEC9
00007e1ec07cff66  int3
00007e1ec07cff67  nop [rax+rax*1], ax
00007e1ec07cff70  mov rax, [r15]
00007e1ec07cff73  mov r14d, [r13+rax*1]
00007e1ec07cff78  lea r12, [rax+0x04]
00007e1ec07cff7c  mov r11d, [r13+r12*1]
00007e1ec07cff81  mov [rsp+0x10], r14d
00007e1ec07cff86  mov r14d, r14d
00007e1ec07cff89  mov [r15+0x78], r14
00007e1ec07cff8d  mov [rsp+0x20], r11d
00007e1ec07cff92  mov r11d, r11d
00007e1ec07cff95  mov [r15+0x80], r11
00007e1ec07cff9c  lea r14, [rax+0x08]
00007e1ec07cffa0  mov r12d, [r13+r14*1]
00007e1ec07cffa5  lea r14, [rax+0x0C]
00007e1ec07cffa9  mov r11d, [r13+r14*1]
00007e1ec07cffae  mov [rsp+0x30], r12d
00007e1ec07cffb3  mov r12d, r12d
00007e1ec07cffb6  mov [r15+0x70], r12
00007e1ec07cffba  mov [rsp+0x40], r11d
00007e1ec07cffbf  mov r11d, r11d
00007e1ec07cffc2  mov [r15+0x68], r11
00007e1ec07cffc6  lea r14, [rax+0x18]
00007e1ec07cffca  mov r12d, [r13+r14*1]
00007e1ec07cffcf  lea r14, [rax+0x1C]
00007e1ec07cffd3  mov r11d, [r13+r14*1]
00007e1ec07cffd8  mov [rsp+0x50], r12d
00007e1ec07cffdd  mov r12d, r12d
00007e1ec07cffe0  mov [r15+0x58], r12
00007e1ec07cffe4  mov [rsp+0x60], r11d
00007e1ec07cffe9  mov r11d, r11d
00007e1ec07cffec  mov [r15+0x60], r11
00007e1ec07cfff0  lea r14, [rax+0x10]
00007e1ec07cfff4  mov r12d, [r13+r14*1]
00007e1ec07cfff9  lea r14, [rax+0x14]
00007e1ec07cfffd  mov eax, [r13+r14*1]
00007e1ec07d0002  mov [rsp+0x70], r12d
00007e1ec07d0007  mov r12d, r12d
00007e1ec07d000a  mov [r15+0x18], r12
00007e1ec07d000e  mov [rsp+0x80], eax
00007e1ec07d0015  mov eax, eax
00007e1ec07d0017  mov [r15+0x90], rax
00007e1ec07d001e  mov eax, [rsp+0x70]
00007e1ec07d0022  mov eax, eax
00007e1ec07d0024  mov [r15+0x30], rax
00007e1ec07d0028  mov eax, [rsp+0x50]
00007e1ec07d002c  mov eax, eax
00007e1ec07d002e  mov [r15+0xA0], rax
00007e1ec07d0035  mov eax, [rsp+0x30]
00007e1ec07d0039  mov eax, eax
00007e1ec07d003b  mov [r15+0x28], rax
00007e1ec07d003f  mov eax, [rsp+0x20]
00007e1ec07d0043  mov eax, eax
00007e1ec07d0045  mov [r15+0x98], rax
00007e1ec07d004c  mov eax, [rsp+0x10]
00007e1ec07d0050  mov eax, eax
00007e1ec07d0052  mov [r15+0x38], rax
00007e1ec07d0056  mov eax, [rsp+0x70]
00007e1ec07d005a  mov r14d, [rsp+0x70]
00007e1ec07d005f  shrd eax, r14d, 0x06
00007e1ec07d0064  mov [rsp+0x70], r14d
00007e1ec07d0069  mov r12d, [rsp+0x80]
00007e1ec07d0071  and r14d, r12d
00007e1ec07d0074  mov r11d, [rsp+0x10]
00007e1ec07d0079  mov r10d, [rsp+0x10]
00007e1ec07d007e  shrd r11d, r10d, 0x02
00007e1ec07d0083  mov [rsp+0x10], r12d
00007e1ec07d0088  mov r12d, r12d
00007e1ec07d008b  mov [r15+0x20], r12
00007e1ec07d008f  mov r12, [r15+0x50]
00007e1ec07d0093  mov r9d, [r13+r12*1]
00007e1ec07d0098  mov r12d, [rsp+0x50]
00007e1ec07d009d  mov r8d, [rsp+0x70]
00007e1ec07d00a2  andn ebp, r8d, r12d
00007e1ec07d00a7  mov edi, [rsp+0x60]
00007e1ec07d00ab  lea esi, [r14d+edi*1]
00007e1ec07d00b0  rorx r14d, r8d, 0x0B
00007e1ec07d00b6  xor eax, r14d
00007e1ec07d00b9  rorx r14d, r10d, 0x0D
00007e1ec07d00bf  xor r11d, r14d
00007e1ec07d00c2  lea edi, [esi+ebp*1]
00007e1ec07d00c6  mov r14, [r15+0x48]
00007e1ec07d00ca  mov ebp, [r13+r14*1]
00007e1ec07d00cf  mov r14d, [rsp+0x30]
00007e1ec07d00d4  mov esi, [rsp+0x20]
00007e1ec07d00d8  and r14d, esi
00007e1ec07d00db  mov [rsp+0x20], r14d
00007e1ec07d00e0  mov r14d, r14d
00007e1ec07d00e3  mov [r15+0xD8], r14
00007e1ec07d00ea  lea r14d, [edi+r9d*1]
00007e1ec07d00ef  mov r9d, [rsp+0x30]
00007e1ec07d00f4  xor r9d, esi
00007e1ec07d00f7  rorx edi, r8d, 0x19
00007e1ec07d00fd  xor eax, edi
00007e1ec07d00ff  and r9d, r10d
00007e1ec07d0102  rorx edi, r10d, 0x16
00007e1ec07d0108  xor r11d, edi
00007e1ec07d010b  mov [rsp+0x30], r11d
00007e1ec07d0110  mov r11d, r11d
00007e1ec07d0113  mov [r15+0xD0], r11
00007e1ec07d011a  lea r11d, [r14d+ebp*1]
00007e1ec07d011f  mov r10d, [rsp+0x20]
00007e1ec07d0124  xor r9d, r10d
00007e1ec07d0127  lea r14d, [r11d+eax*1]
00007e1ec07d012c  mov qword ptr [r15+0x88], 0x04
00007e1ec07d0137  mov eax, [rsp+0x30]
00007e1ec07d013b  lea r11d, [r9d+eax*1]
00007e1ec07d0140  mov eax, [rsp+0x40]
00007e1ec07d0144  lea r10d, [r14d+eax*1]
00007e1ec07d0149  mov r10d, r10d
00007e1ec07d014c  mov [r15+0xB8], r10
00007e1ec07d0153  xor eax, eax
00007e1ec07d0155  mov r10d, 0x04
00007e1ec07d015b  mov r9d, 0x100
00007e1ec07d0161  cmp r10, r9
00007e1ec07d0164  cmc
00007e1ec07d0165  lahf
00007e1ec07d0166  seto al
00007e1ec07d0169  mov [r15+0x108], eax
00007e1ec07d0170  lea eax, [r11d+r14d*1]
00007e1ec07d0175  mov eax, eax
00007e1ec07d0177  mov [r15+0xA8], rax
00007e1ec07d017e  mov r12d, r12d
00007e1ec07d0181  mov [r15+0xB0], r12
00007e1ec07d0188  mov eax, [rsp+0x10]
00007e1ec07d018c  mov eax, eax
00007e1ec07d018e  mov [r15+0xC0], rax
00007e1ec07d0195  mov r8d, r8d
00007e1ec07d0198  mov [r15+0xC8], r8
00007e1ec07d019f  mov eax, [r15+0x108]
00007e1ec07d01a6  sahf
00007e1ec07d01a7  jnz 0x00007E1EC07D01D9
00007e1ec07d01a9  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d01b1  jz 0x00007E1EC07D04A0
00007e1ec07d01b7  nop [rax+rax*1], ax
00007e1ec07d01c0  nop [rax+rax*1], eax
00007e1ec07d01c8  mov eax, 0x41094C
00007e1ec07d01cd  mov [r15+0x100], rax
00007e1ec07d01d4  jmp 0x00007E1EC05FE110
00007e1ec07d01d9  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d01e1  jz 0x00007E1EC07D0270
00007e1ec07d01e7  nop [rax+rax*1], ax
00007e1ec07d01f0  nop [rax+rax*1], eax
00007e1ec07d01f8  mov eax, 0x4108C0
00007e1ec07d01fd  mov [r15+0x100], rax
00007e1ec07d0204  jmp 0x00007E1EC05FE110
00007e1ec07d0209  int3
00007e1ec07d020a  call 0x00007E1EC060DAE0
00007e1ec07d020f  jmp 0x00007E1EC07CFF78
00007e1ec07d0214  call 0x00007E1EC06C0230
00007e1ec07d0219  jmp 0x00007E1EC07CFF81
00007e1ec07d021e  call 0x00007E1EC06E26A0
00007e1ec07d0223  jmp 0x00007E1EC07CFFA5
00007e1ec07d0228  call 0x00007E1EC06E1430
00007e1ec07d022d  jmp 0x00007E1EC07CFFAE
00007e1ec07d0232  call 0x00007E1EC06E26A0
00007e1ec07d0237  jmp 0x00007E1EC07CFFCF
00007e1ec07d023c  call 0x00007E1EC06E1430
00007e1ec07d0241  jmp 0x00007E1EC07CFFD8
00007e1ec07d0246  call 0x00007E1EC06E26A0
00007e1ec07d024b  jmp 0x00007E1EC07CFFF9
00007e1ec07d0250  call 0x00007E1EC06D5890
00007e1ec07d0255  jmp 0x00007E1EC07D0002
00007e1ec07d025a  call 0x00007E1EC06BDD50
00007e1ec07d025f  jmp 0x00007E1EC07D0098
00007e1ec07d0264  call 0x00007E1EC06DA580
00007e1ec07d0269  jmp 0x00007E1EC07D00CF
00007e1ec07d026e  int3
00007e1ec07d026f  nop
00007e1ec07d0270  mov eax, [r15+0xB8]
00007e1ec07d0277  mov [rsp+0x10], eax
00007e1ec07d027b  mov eax, eax
00007e1ec07d027d  mov [r15+0x30], rax
00007e1ec07d0281  mov eax, [r15+0xC0]
00007e1ec07d0288  mov [rsp+0x20], eax
00007e1ec07d028c  mov eax, eax
00007e1ec07d028e  mov [r15+0xA0], rax
00007e1ec07d0295  mov eax, [r15+0x28]
00007e1ec07d0299  mov r14d, [r15+0x98]
00007e1ec07d02a0  mov [rsp+0x30], r14d
00007e1ec07d02a5  mov r14d, r14d
00007e1ec07d02a8  mov [r15+0x28], r14
00007e1ec07d02ac  mov r14d, [r15+0x38]
00007e1ec07d02b0  mov [rsp+0x40], r14d
00007e1ec07d02b5  mov r14d, r14d
00007e1ec07d02b8  mov [r15+0x98], r14
00007e1ec07d02bf  mov r14d, [r15+0xA8]
00007e1ec07d02c6  mov [rsp+0x50], r14d
00007e1ec07d02cb  mov r14d, r14d
00007e1ec07d02ce  mov [r15+0x38], r14
00007e1ec07d02d2  mov r14d, [rsp+0x10]
00007e1ec07d02d7  mov r12d, [rsp+0x10]
00007e1ec07d02dc  shrd r14d, r12d, 0x06
00007e1ec07d02e1  mov r11d, [r15+0xC8]
00007e1ec07d02e8  mov [rsp+0x10], r12d
00007e1ec07d02ed  and r12d, r11d
00007e1ec07d02f0  mov r10d, [rsp+0x50]
00007e1ec07d02f5  mov r9d, [rsp+0x50]
00007e1ec07d02fa  shrd r10d, r9d, 0x02
00007e1ec07d02ff  mov [rsp+0x50], r11d
00007e1ec07d0304  mov r11d, r11d
00007e1ec07d0307  mov [r15+0x20], r11
00007e1ec07d030b  mov r11, [r15+0x88]
00007e1ec07d0312  mov r8, [r15+0x50]
00007e1ec07d0316  lea rbp, [r8+r11*1]
00007e1ec07d031a  mov r8d, [r13+rbp*1]
00007e1ec07d031f  mov ebp, [rsp+0x20]
00007e1ec07d0323  mov edi, [rsp+0x10]
00007e1ec07d0327  andn esi, edi, ebp
00007e1ec07d032c  mov edx, [r15+0xB0]
00007e1ec07d0333  lea ecx, [r12d+edx*1]
00007e1ec07d0338  rorx r12d, edi, 0x0B
00007e1ec07d033e  xor r14d, r12d
00007e1ec07d0341  rorx r12d, r9d, 0x0D
00007e1ec07d0347  xor r10d, r12d
00007e1ec07d034a  lea r12d, [ecx+esi*1]
00007e1ec07d034f  mov rsi, [r15+0x48]
00007e1ec07d0353  lea rdx, [rsi+r11*1]
00007e1ec07d0357  mov esi, [r13+rdx*1]
00007e1ec07d035c  mov edx, [rsp+0x30]
00007e1ec07d0360  mov ecx, [rsp+0x40]
00007e1ec07d0364  and edx, ecx
00007e1ec07d0366  mov [rsp+0x10], edx
00007e1ec07d036a  mov edx, edx
00007e1ec07d036c  mov [r15+0xD8], rdx
00007e1ec07d0373  lea edx, [r12d+r8d*1]
00007e1ec07d0378  mov r12d, [rsp+0x30]
00007e1ec07d037d  xor r12d, ecx
00007e1ec07d0380  rorx r8d, edi, 0x19
00007e1ec07d0386  xor r14d, r8d
00007e1ec07d0389  and r12d, r9d
00007e1ec07d038c  rorx r8d, r9d, 0x16
00007e1ec07d0392  xor r10d, r8d
00007e1ec07d0395  mov [rsp+0x20], r10d
00007e1ec07d039a  mov r10d, r10d
00007e1ec07d039d  mov [r15+0xD0], r10
00007e1ec07d03a4  lea r10d, [edx+esi*1]
00007e1ec07d03a9  mov r9d, [rsp+0x10]
00007e1ec07d03ae  xor r12d, r9d
00007e1ec07d03b1  lea r9d, [r10d+r14d*1]
00007e1ec07d03b6  lea r14, [r11+0x04]
00007e1ec07d03ba  mov [r15+0x88], r14
00007e1ec07d03c1  mov r11d, [rsp+0x20]
00007e1ec07d03c6  lea r10d, [r12d+r11d*1]
00007e1ec07d03cb  lea r11d, [r9d+eax*1]
00007e1ec07d03d0  mov r11d, r11d
00007e1ec07d03d3  mov [r15+0xB8], r11
00007e1ec07d03da  xor eax, eax
00007e1ec07d03dc  mov r12d, 0x100
00007e1ec07d03e2  cmp r14, r12
00007e1ec07d03e5  cmc
00007e1ec07d03e6  lahf
00007e1ec07d03e7  seto al
00007e1ec07d03ea  mov [r15+0x108], eax
00007e1ec07d03f1  lea eax, [r10d+r9d*1]
00007e1ec07d03f6  mov eax, eax
00007e1ec07d03f8  mov [r15+0xA8], rax
00007e1ec07d03ff  mov ebp, ebp
00007e1ec07d0401  mov [r15+0xB0], rbp
00007e1ec07d0408  mov eax, [rsp+0x50]
00007e1ec07d040c  mov eax, eax
00007e1ec07d040e  mov [r15+0xC0], rax
00007e1ec07d0415  mov edi, edi
00007e1ec07d0417  mov [r15+0xC8], rdi
00007e1ec07d041e  mov eax, [r15+0x108]
00007e1ec07d0425  sahf
00007e1ec07d0426  jnz 0x00007E1EC07D0458
00007e1ec07d0428  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d0430  jz 0x00007E1EC07D04A0
00007e1ec07d0436  nop [rax+rax*1], ax
00007e1ec07d043f  nop [rax+rax*1], eax
00007e1ec07d0447  mov eax, 0x41094C
00007e1ec07d044c  mov [r15+0x100], rax
00007e1ec07d0453  jmp 0x00007E1EC05FE110
00007e1ec07d0458  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d0460  jz 0x00007E1EC07D0270
00007e1ec07d0466  nop [rax+rax*1], ax
00007e1ec07d046f  nop [rax+rax*1], eax
00007e1ec07d0477  mov eax, 0x4108C0
00007e1ec07d047c  mov [r15+0x100], rax
00007e1ec07d0483  jmp 0x00007E1EC05FE110
00007e1ec07d0488  int3
00007e1ec07d0489  call 0x00007E1EC0649010
00007e1ec07d048e  jmp 0x00007E1EC07D031F
00007e1ec07d0493  call 0x00007E1EC0625930
00007e1ec07d0498  jmp 0x00007E1EC07D035C
00007e1ec07d049d  int3
00007e1ec07d049e  nop
00007e1ec07d04a0  mov eax, [r15+0x98]
00007e1ec07d04a7  mov r14d, [r15+0x70]
00007e1ec07d04ab  lea r12d, [eax+r14d*1]
00007e1ec07d04b0  mov eax, [r15+0x28]
00007e1ec07d04b4  mov r14d, [r15+0x68]
00007e1ec07d04b8  lea r11d, [eax+r14d*1]
00007e1ec07d04bd  mov qword ptr [r15+0x88], 0x00
00007e1ec07d04c8  mov eax, [r15+0xA8]
00007e1ec07d04cf  mov r14d, [r15+0x78]
00007e1ec07d04d3  lea r10d, [eax+r14d*1]
00007e1ec07d04d8  mov [rsp+0x10], r10d
00007e1ec07d04dd  mov r10d, r10d
00007e1ec07d04e0  mov [r15+0x78], r10
00007e1ec07d04e4  mov eax, [r15+0x38]
00007e1ec07d04e8  mov r14d, [r15+0x80]
00007e1ec07d04ef  lea r10d, [eax+r14d*1]
00007e1ec07d04f4  mov [rsp+0x20], r10d
00007e1ec07d04f9  mov r10d, r10d
00007e1ec07d04fc  mov [r15+0x80], r10
00007e1ec07d0503  mov rax, [r15]
00007e1ec07d0506  lea r14, [rax+0x08]
00007e1ec07d050a  mov [r13+r14*1], r12d
00007e1ec07d050f  lea r14, [rax+0x0C]
00007e1ec07d0513  mov [r13+r14*1], r11d
00007e1ec07d0518  mov r14d, [r15+0xB8]
00007e1ec07d051f  mov r12d, [r15+0x18]
00007e1ec07d0523  lea r11d, [r14d+r12d*1]
00007e1ec07d0528  mov [rsp+0x30], r11d
00007e1ec07d052d  mov r11d, r11d
00007e1ec07d0530  mov [r15+0x68], r11
00007e1ec07d0534  mov r14d, [r15+0x30]
00007e1ec07d0538  mov r12d, [r15+0x90]
00007e1ec07d053f  lea r11d, [r14d+r12d*1]
00007e1ec07d0544  mov [rsp+0x40], r11d
00007e1ec07d0549  mov r11d, r11d
00007e1ec07d054c  mov [r15+0x70], r11
00007e1ec07d0550  mov r14d, [r15+0x20]
00007e1ec07d0554  mov r12d, [r15+0x58]
00007e1ec07d0558  lea r11d, [r14d+r12d*1]
00007e1ec07d055d  mov [rsp+0x50], r11d
00007e1ec07d0562  mov r11d, r11d
00007e1ec07d0565  mov [r15+0x58], r11
00007e1ec07d0569  mov r14d, [r15+0xA0]
00007e1ec07d0570  mov r12d, [r15+0x60]
00007e1ec07d0574  lea r11d, [r14d+r12d*1]
00007e1ec07d0579  mov [rsp+0x60], r11d
00007e1ec07d057e  mov r11d, r11d
00007e1ec07d0581  mov [r15+0x60], r11
00007e1ec07d0585  mov r14d, [rsp+0x10]
00007e1ec07d058a  mov [r13+rax*1], r14d
00007e1ec07d058f  lea r14, [rax+0x04]
00007e1ec07d0593  mov r12d, [rsp+0x20]
00007e1ec07d0598  mov [r13+r14*1], r12d
00007e1ec07d059d  lea r14, [rax+0x10]
00007e1ec07d05a1  mov r12d, [rsp+0x30]
00007e1ec07d05a6  mov [r13+r14*1], r12d
00007e1ec07d05ab  lea r14, [rax+0x14]
00007e1ec07d05af  mov r12d, [rsp+0x40]
00007e1ec07d05b4  mov [r13+r14*1], r12d
00007e1ec07d05b9  lea r14, [rax+0x18]
00007e1ec07d05bd  mov r12d, [rsp+0x50]
00007e1ec07d05c2  mov [r13+r14*1], r12d
00007e1ec07d05c7  lea r14, [rax+0x1C]
00007e1ec07d05cb  mov r12d, [rsp+0x60]
00007e1ec07d05d0  mov [r13+r14*1], r12d
00007e1ec07d05d5  lea r14, [rax+0x68]
00007e1ec07d05d9  xor eax, eax
00007e1ec07d05db  mov [r13+r14*1], rax
00007e1ec07d05e0  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d05e8  jz 0x00007E1EC07CF0E0
00007e1ec07d05ee  nop [rax+rax*1], ax
00007e1ec07d05f7  nop [rax+rax*1], eax
00007e1ec07d05ff  mov eax, 0x410768
00007e1ec07d0604  mov [r15+0x100], rax
00007e1ec07d060b  jmp 0x00007E1EC05FE110
00007e1ec07d0610  int3
00007e1ec07d0611  call 0x00007E1EC06E2BA0
00007e1ec07d0616  jmp 0x00007E1EC07D050F
00007e1ec07d061b  call 0x00007E1EC06E1920
00007e1ec07d0620  jmp 0x00007E1EC07D0518
00007e1ec07d0625  call 0x00007E1EC060DFE0
00007e1ec07d062a  jmp 0x00007E1EC07D058F
00007e1ec07d062f  call 0x00007E1EC06E2BA0
00007e1ec07d0634  jmp 0x00007E1EC07D059D
00007e1ec07d0639  call 0x00007E1EC06E2BA0
00007e1ec07d063e  jmp 0x00007E1EC07D05AB
00007e1ec07d0643  call 0x00007E1EC06E2BA0
00007e1ec07d0648  jmp 0x00007E1EC07D05B9
00007e1ec07d064d  call 0x00007E1EC06E2BA0
00007e1ec07d0652  jmp 0x00007E1EC07D05C7
00007e1ec07d0657  call 0x00007E1EC06E2BA0
00007e1ec07d065c  jmp 0x00007E1EC07D05D5
00007e1ec07d0661  call 0x00007E1EC06D5EB0
00007e1ec07d0666  jmp 0x00007E1EC07D05E0
00007e1ec07d066b  int3
00007e1ec07d066c  nop [rax], eax
00007e1ec07d0670  mov rax, [r15+0xF8]
00007e1ec07d0677  lea r14, [rax+0x140]
00007e1ec07d067e  mov r12, [r13+r14*1]
00007e1ec07d0683  lea r14, [rax+0x148]
00007e1ec07d068a  mov r11, [r13+r14*1]
00007e1ec07d068f  mov [r15+0xA0], r12
00007e1ec07d0696  mov [r15+0x98], r11
00007e1ec07d069d  lea r14, [rax+0x130]
00007e1ec07d06a4  mov r12, [r13+r14*1]
00007e1ec07d06a9  lea r14, [rax+0x138]
00007e1ec07d06b0  mov r11, [r13+r14*1]
00007e1ec07d06b5  mov [r15+0xB0], r12
00007e1ec07d06bc  mov [r15+0xA8], r11
00007e1ec07d06c3  lea r14, [rax+0x120]
00007e1ec07d06ca  mov r12, [r13+r14*1]
00007e1ec07d06cf  lea r14, [rax+0x128]
00007e1ec07d06d6  mov r11, [r13+r14*1]
00007e1ec07d06db  mov [r15+0xC0], r12
00007e1ec07d06e2  mov [r15+0xB8], r11
00007e1ec07d06e9  lea r14, [rax+0x110]
00007e1ec07d06f0  mov r12, [r13+r14*1]
00007e1ec07d06f5  lea r14, [rax+0x118]
00007e1ec07d06fc  mov r11, [r13+r14*1]
00007e1ec07d0701  mov [r15+0xD0], r12
00007e1ec07d0708  mov [r15+0xC8], r11
00007e1ec07d070f  lea r14, [rax+0x100]
00007e1ec07d0716  mov r12, [r13+r14*1]
00007e1ec07d071b  lea r14, [rax+0x108]
00007e1ec07d0722  mov r11, [r13+r14*1]
00007e1ec07d0727  mov [r15+0xE8], r12
00007e1ec07d072e  mov [r15+0xD8], r11
00007e1ec07d0735  lea r14, [rax+0x150]
00007e1ec07d073c  mov [r15+0xF8], r14
00007e1ec07d0743  mov rax, [r15+0xF0]
00007e1ec07d074a  mov [r15+0x100], rax
00007e1ec07d0751  jmp 0x00007E1EC07CE5C0
00007e1ec07d0756  int3
00007e1ec07d0757  call 0x00007E1EC06E27E0
00007e1ec07d075c  jmp 0x00007E1EC07D0683
00007e1ec07d0761  call 0x00007E1EC06E1570
00007e1ec07d0766  jmp 0x00007E1EC07D068F
00007e1ec07d076b  call 0x00007E1EC06E27E0
00007e1ec07d0770  jmp 0x00007E1EC07D06A9
00007e1ec07d0775  call 0x00007E1EC06E1570
00007e1ec07d077a  jmp 0x00007E1EC07D06B5
00007e1ec07d077f  call 0x00007E1EC06E27E0
00007e1ec07d0784  jmp 0x00007E1EC07D06CF
00007e1ec07d0789  call 0x00007E1EC06E1570
00007e1ec07d078e  jmp 0x00007E1EC07D06DB
00007e1ec07d0793  call 0x00007E1EC06E27E0
00007e1ec07d0798  jmp 0x00007E1EC07D06F5
00007e1ec07d079d  call 0x00007E1EC06E1570
00007e1ec07d07a2  jmp 0x00007E1EC07D0701
00007e1ec07d07a7  call 0x00007E1EC06E27E0
00007e1ec07d07ac  jmp 0x00007E1EC07D071B
00007e1ec07d07b1  call 0x00007E1EC06E1570
00007e1ec07d07b6  jmp 0x00007E1EC07D0727
00007e1ec07d07bb  int3
00007e1ec07d07bc  nop [rax], eax
00007e1ec07d07c0  mov eax, [r15+0xA0]
00007e1ec07d07c7  mov [rsp+0x10], eax
00007e1ec07d07cb  xor eax, eax
00007e1ec07d07cd  mov r14d, [rsp+0x10]
00007e1ec07d07d2  sub r14d, 0x01
00007e1ec07d07d6  cmc
00007e1ec07d07d7  lahf
00007e1ec07d07d8  seto al
00007e1ec07d07db  mov [r15+0x108], eax
00007e1ec07d07e2  mov r14d, r14d
00007e1ec07d07e5  mov [r15+0xA0], r14
00007e1ec07d07ec  mov eax, [r15+0x108]
00007e1ec07d07f3  sahf
00007e1ec07d07f4  jnz 0x00007E1EC07D0826
00007e1ec07d07f6  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d07fe  jz 0x00007E1EC07D0900
00007e1ec07d0804  nop [rax+rax*1], ax
00007e1ec07d080d  nop [rax+rax*1], eax
00007e1ec07d0815  mov eax, 0x41028C
00007e1ec07d081a  mov [r15+0x100], rax
00007e1ec07d0821  jmp 0x00007E1EC05FE110
00007e1ec07d0826  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d082e  jz 0x00007E1EC07D0860
00007e1ec07d0834  nop [rax+rax*1], ax
00007e1ec07d083d  nop [rax+rax*1], eax
00007e1ec07d0845  mov eax, 0x410274
00007e1ec07d084a  mov [r15+0x100], rax
00007e1ec07d0851  jmp 0x00007E1EC05FE110
00007e1ec07d0856  int3
00007e1ec07d0857  int3
00007e1ec07d0858  nop [rax+rax*1], eax
00007e1ec07d0860  mov rax, [r15+0xF8]
00007e1ec07d0867  lea r14, [rax+0x100]
00007e1ec07d086e  mov [r15], r14
00007e1ec07d0871  mov rax, [r15+0x98]
00007e1ec07d0878  mov [r15+0x08], rax
00007e1ec07d087c  mov qword ptr [r15+0x10], 0x12C
00007e1ec07d0884  mov qword ptr [r15+0xF0], 0x410284
00007e1ec07d088f  mov r14d, [r15+0x320]
00007e1ec07d0896  mov eax, 0x410284
00007e1ec07d089b  mov rcx, 0x7E1EC07D07C0
00007e1ec07d08a5  mov [r15+r14*8+0x328], rax
00007e1ec07d08ad  mov [r15+r14*8+0x368], rcx
00007e1ec07d08b5  add r14d, 0x01
00007e1ec07d08b9  and r14d, 0x07
00007e1ec07d08bd  mov [r15+0x320], r14d
00007e1ec07d08c4  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d08cc  jz 0x00007E1EC07CED70
00007e1ec07d08d2  nop [rax+rax*1], ax
00007e1ec07d08db  nop [rax+rax*1], eax
00007e1ec07d08e3  mov eax, 0x410728
00007e1ec07d08e8  mov [r15+0x100], rax
00007e1ec07d08ef  jmp 0x00007E1EC05FE110
00007e1ec07d08f4  int3
00007e1ec07d08f5  int3
00007e1ec07d08f6  nop [rax+rax*1], ax
00007e1ec07d08ff  nop
00007e1ec07d0900  mov rax, [r15+0xF8]
00007e1ec07d0907  lea r14, [rax+0x120]
00007e1ec07d090e  mov r12, [r13+r14*1]
00007e1ec07d0913  mov [r15+0x98], r12
00007e1ec07d091a  mov qword ptr [r15+0x40], 0x80
00007e1ec07d0922  lea r14, [rax+0x100]
00007e1ec07d0929  mov [r15], r14
00007e1ec07d092c  lea r14, [rax+0x17C]
00007e1ec07d0933  mov [r15+0x08], r14
00007e1ec07d0937  mov qword ptr [r15+0x10], 0x01
00007e1ec07d093f  lea r14, [rax+0x17C]
00007e1ec07d0946  mov eax, 0x80
00007e1ec07d094b  mov [r13+r14*1], al
00007e1ec07d0950  mov qword ptr [r15+0xF0], 0x4102A8
00007e1ec07d095b  mov r14d, [r15+0x320]
00007e1ec07d0962  mov eax, 0x4102A8
00007e1ec07d0967  mov rcx, 0x7E1EC07D09E0
00007e1ec07d0971  mov [r15+r14*8+0x328], rax
00007e1ec07d0979  mov [r15+r14*8+0x368], rcx
00007e1ec07d0981  add r14d, 0x01
00007e1ec07d0985  and r14d, 0x07
00007e1ec07d0989  mov [r15+0x320], r14d
00007e1ec07d0990  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d0998  jz 0x00007E1EC07CED70
00007e1ec07d099e  nop [rax+rax*1], ax
00007e1ec07d09a7  nop [rax+rax*1], eax
00007e1ec07d09af  mov eax, 0x410728
00007e1ec07d09b4  mov [r15+0x100], rax
00007e1ec07d09bb  jmp 0x00007E1EC05FE110
00007e1ec07d09c0  int3
00007e1ec07d09c1  call 0x00007E1EC06E27E0
00007e1ec07d09c6  jmp 0x00007E1EC07D0913
00007e1ec07d09cb  call 0x00007E1EC06D5AF0
00007e1ec07d09d0  jmp 0x00007E1EC07D0950
00007e1ec07d09d5  int3
00007e1ec07d09d6  nop [rax+rax*1], ax
00007e1ec07d09df  nop
00007e1ec07d09e0  mov rax, [r15+0xF8]
00007e1ec07d09e7  lea r14, [rax+0x168]
00007e1ec07d09ee  mov r12, [r13+r14*1]
00007e1ec07d09f3  mov [r15+0x40], r12
00007e1ec07d09f7  lea r14, [rax+0x178]
00007e1ec07d09fe  xor eax, eax
00007e1ec07d0a00  mov [r13+r14*1], al
00007e1ec07d0a05  xor eax, eax
00007e1ec07d0a07  mov r14d, 0x38
00007e1ec07d0a0d  cmp r12, r14
00007e1ec07d0a10  cmc
00007e1ec07d0a11  lahf
00007e1ec07d0a12  seto al
00007e1ec07d0a15  mov [r15+0x108], eax
00007e1ec07d0a1c  mov eax, [r15+0x108]
00007e1ec07d0a23  sahf
00007e1ec07d0a24  jz 0x00007E1EC07D0A56
00007e1ec07d0a26  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d0a2e  jz 0x00007E1EC07D0AA0
00007e1ec07d0a34  nop [rax+rax*1], ax
00007e1ec07d0a3d  nop [rax+rax*1], eax
00007e1ec07d0a45  mov eax, 0x4102B8
00007e1ec07d0a4a  mov [r15+0x100], rax
00007e1ec07d0a51  jmp 0x00007E1EC05FE110
00007e1ec07d0a56  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d0a5e  jz 0x00007E1EC07D0BF0
00007e1ec07d0a64  nop [rax+rax*1], ax
00007e1ec07d0a6d  nop [rax+rax*1], eax
00007e1ec07d0a75  mov eax, 0x4102D4
00007e1ec07d0a7a  mov [r15+0x100], rax
00007e1ec07d0a81  jmp 0x00007E1EC05FE110
00007e1ec07d0a86  int3
00007e1ec07d0a87  call 0x00007E1EC06E27E0
00007e1ec07d0a8c  jmp 0x00007E1EC07D09F3
00007e1ec07d0a91  call 0x00007E1EC06D5AF0
00007e1ec07d0a96  jmp 0x00007E1EC07D0A05
00007e1ec07d0a9b  int3
00007e1ec07d0a9c  nop [rax], eax
00007e1ec07d0aa0  mov rax, [r15+0xF8]
00007e1ec07d0aa7  lea r14, [rax+0x100]
00007e1ec07d0aae  mov [r15], r14
00007e1ec07d0ab1  lea r14, [rax+0x178]
00007e1ec07d0ab8  mov [r15+0x08], r14
00007e1ec07d0abc  mov qword ptr [r15+0x10], 0x01
00007e1ec07d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007e1ec07d0acf  mov r14d, [r15+0x320]
00007e1ec07d0ad6  mov eax, 0x4102C8
00007e1ec07d0adb  mov rcx, 0x7E1EC07D0B40
00007e1ec07d0ae5  mov [r15+r14*8+0x328], rax
00007e1ec07d0aed  mov [r15+r14*8+0x368], rcx
00007e1ec07d0af5  add r14d, 0x01
00007e1ec07d0af9  and r14d, 0x07
00007e1ec07d0afd  mov [r15+0x320], r14d
00007e1ec07d0b04  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d0b0c  jz 0x00007E1EC07CED70
00007e1ec07d0b12  nop [rax+rax*1], ax
00007e1ec07d0b1b  nop [rax+rax*1], eax
00007e1ec07d0b23  mov eax, 0x410728
00007e1ec07d0b28  mov [r15+0x100], rax
00007e1ec07d0b2f  jmp 0x00007E1EC05FE110
00007e1ec07d0b34  int3
00007e1ec07d0b35  int3
00007e1ec07d0b36  nop [rax+rax*1], ax
00007e1ec07d0b3f  nop
00007e1ec07d0b40  mov rax, [r15+0xF8]
00007e1ec07d0b47  lea r14, [rax+0x168]
00007e1ec07d0b4e  mov rax, [r13+r14*1]
00007e1ec07d0b53  mov [r15+0x40], rax
00007e1ec07d0b57  mov [rsp+0x10], rax
00007e1ec07d0b5c  xor eax, eax
00007e1ec07d0b5e  mov r14, [rsp+0x10]
00007e1ec07d0b63  mov r12d, 0x38
00007e1ec07d0b69  cmp r14, r12
00007e1ec07d0b6c  cmc
00007e1ec07d0b6d  lahf
00007e1ec07d0b6e  seto al
00007e1ec07d0b71  mov [r15+0x108], eax
00007e1ec07d0b78  mov eax, [r15+0x108]
00007e1ec07d0b7f  sahf
00007e1ec07d0b80  jnz 0x00007E1EC07D0BB2
00007e1ec07d0b82  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d0b8a  jz 0x00007E1EC07D0BF0
00007e1ec07d0b90  nop [rax+rax*1], ax
00007e1ec07d0b99  nop [rax+rax*1], eax
00007e1ec07d0ba1  mov eax, 0x4102D4
00007e1ec07d0ba6  mov [r15+0x100], rax
00007e1ec07d0bad  jmp 0x00007E1EC05FE110
00007e1ec07d0bb2  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d0bba  jz 0x00007E1EC07D0AA0
00007e1ec07d0bc0  nop [rax+rax*1], ax
00007e1ec07d0bc9  nop [rax+rax*1], eax
00007e1ec07d0bd1  mov eax, 0x4102B8
00007e1ec07d0bd6  mov [r15+0x100], rax
00007e1ec07d0bdd  jmp 0x00007E1EC05FE110
00007e1ec07d0be2  int3
00007e1ec07d0be3  call 0x00007E1EC06D59C0
00007e1ec07d0be8  jmp 0x00007E1EC07D0B53
00007e1ec07d0bed  int3
00007e1ec07d0bee  nop
00007e1ec07d0bf0  mov rax, [r15+0x98]
00007e1ec07d0bf7  rorx r14, rax, 0x3D
00007e1ec07d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007e1ec07d0c01  mov rax, [r15+0xF8]
00007e1ec07d0c08  lea r12, [rax+0x100]
00007e1ec07d0c0f  mov [r15], r12
00007e1ec07d0c12  lea r12, [rax+0x170]
00007e1ec07d0c19  mov [r15+0x08], r12
00007e1ec07d0c1d  mov qword ptr [r15+0x10], 0x08
00007e1ec07d0c25  bswap r14
00007e1ec07d0c28  mov [r15+0x40], r14
00007e1ec07d0c2c  lea r12, [rax+0x170]
00007e1ec07d0c33  mov [r13+r12*1], r14
00007e1ec07d0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007e1ec07d0c43  mov r14d, [r15+0x320]
00007e1ec07d0c4a  mov eax, 0x4102F0
00007e1ec07d0c4f  mov rcx, 0x7E1EC07D0CC0
00007e1ec07d0c59  mov [r15+r14*8+0x328], rax
00007e1ec07d0c61  mov [r15+r14*8+0x368], rcx
00007e1ec07d0c69  add r14d, 0x01
00007e1ec07d0c6d  and r14d, 0x07
00007e1ec07d0c71  mov [r15+0x320], r14d
00007e1ec07d0c78  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d0c80  jz 0x00007E1EC07CED70
00007e1ec07d0c86  nop [rax+rax*1], ax
00007e1ec07d0c8f  nop [rax+rax*1], eax
00007e1ec07d0c97  mov eax, 0x410728
00007e1ec07d0c9c  mov [r15+0x100], rax
00007e1ec07d0ca3  jmp 0x00007E1EC05FE110
00007e1ec07d0ca8  int3
00007e1ec07d0ca9  call 0x00007E1EC06C3FE0
00007e1ec07d0cae  jmp 0x00007E1EC07D0C38
00007e1ec07d0cb3  int3
00007e1ec07d0cb4  nop [rax+rax*1], ax
00007e1ec07d0cbd  nop [rax], eax
00007e1ec07d0cc0  mov rax, [r15+0xF8]
00007e1ec07d0cc7  lea r14, [rax+0x100]
00007e1ec07d0cce  mov r12d, [r13+r14*1]
00007e1ec07d0cd3  lea r14, [rax+0x104]
00007e1ec07d0cda  mov r11d, [r13+r14*1]
00007e1ec07d0cdf  mov qword ptr [r15+0x48], 0x430C90
00007e1ec07d0ce7  lea r14, [rax+0x108]
00007e1ec07d0cee  mov r10d, [r13+r14*1]
00007e1ec07d0cf3  lea r14, [rax+0x10C]
00007e1ec07d0cfa  mov r9d, [r13+r14*1]
00007e1ec07d0cff  bswap r12d
00007e1ec07d0d02  bswap r11d
00007e1ec07d0d05  mov qword ptr [r15+0xA0], 0x00
00007e1ec07d0d10  mov r14d, 0x430C90
00007e1ec07d0d16  mov [r13+r14*1], r12d
00007e1ec07d0d1b  mov r14d, 0x430C94
00007e1ec07d0d21  mov [r13+r14*1], r11d
00007e1ec07d0d26  bswap r10d
00007e1ec07d0d29  lea r14, [rax+0x110]
00007e1ec07d0d30  mov r12d, [r13+r14*1]
00007e1ec07d0d35  bswap r9d
00007e1ec07d0d38  lea r14, [rax+0x114]
00007e1ec07d0d3f  mov r11d, [r13+r14*1]
00007e1ec07d0d44  mov qword ptr [r15+0x98], 0x430DFC
00007e1ec07d0d4f  mov r14d, 0x430C98
00007e1ec07d0d55  mov [r13+r14*1], r10d
00007e1ec07d0d5a  mov r14d, 0x430C9C
00007e1ec07d0d60  mov [r13+r14*1], r9d
00007e1ec07d0d65  bswap r12d
00007e1ec07d0d68  lea r14, [rax+0x118]
00007e1ec07d0d6f  mov r10d, [r13+r14*1]
00007e1ec07d0d74  bswap r11d
00007e1ec07d0d77  mov [rsp+0x10], r11d
00007e1ec07d0d7c  mov r11d, r11d
00007e1ec07d0d7f  mov [r15+0x58], r11
00007e1ec07d0d83  lea r14, [rax+0x11C]
00007e1ec07d0d8a  mov eax, [r13+r14*1]
00007e1ec07d0d8f  mov [rsp+0x20], eax
00007e1ec07d0d93  mov eax, eax
00007e1ec07d0d95  mov [r15+0x60], rax
00007e1ec07d0d99  mov eax, 0x430CA0
00007e1ec07d0d9e  mov [r13+rax*1], r12d
00007e1ec07d0da3  mov eax, 0x430CA4
00007e1ec07d0da8  mov r14d, [rsp+0x10]
00007e1ec07d0dad  mov [r13+rax*1], r14d
00007e1ec07d0db2  bswap r10d
00007e1ec07d0db5  mov [rsp+0x10], r10d
00007e1ec07d0dba  mov r10d, r10d
00007e1ec07d0dbd  mov [r15+0x40], r10
00007e1ec07d0dc1  mov eax, [rsp+0x20]
00007e1ec07d0dc5  bswap eax
00007e1ec07d0dc7  mov [rsp+0x20], eax
00007e1ec07d0dcb  mov eax, eax
00007e1ec07d0dcd  mov [r15+0x50], rax
00007e1ec07d0dd1  mov eax, 0x430CA8
00007e1ec07d0dd6  mov r14d, [rsp+0x10]
00007e1ec07d0ddb  mov [r13+rax*1], r14d
00007e1ec07d0de0  mov eax, 0x430CAC
00007e1ec07d0de5  mov r14d, [rsp+0x20]
00007e1ec07d0dea  mov [r13+rax*1], r14d
00007e1ec07d0def  mov eax, [r15+0xA0]
00007e1ec07d0df6  lea r14d, [eax+0x11]
00007e1ec07d0dfb  mov r14d, r14d
00007e1ec07d0dfe  mov [r15], r14
00007e1ec07d0e01  mov qword ptr [r15+0xF0], 0x41035C
00007e1ec07d0e0c  mov r14d, [r15+0x320]
00007e1ec07d0e13  mov eax, 0x41035C
00007e1ec07d0e18  mov rcx, 0x7E1EC07D0F90
00007e1ec07d0e22  mov [r15+r14*8+0x328], rax
00007e1ec07d0e2a  mov [r15+r14*8+0x368], rcx
00007e1ec07d0e32  add r14d, 0x01
00007e1ec07d0e36  and r14d, 0x07
00007e1ec07d0e3a  mov [r15+0x320], r14d
00007e1ec07d0e41  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d0e49  jz 0x00007E1EC07D0F20
00007e1ec07d0e4f  nop [rax+rax*1], ax
00007e1ec07d0e58  nop [rax+rax*1], eax
00007e1ec07d0e60  mov eax, 0x4109A4
00007e1ec07d0e65  mov [r15+0x100], rax
00007e1ec07d0e6c  jmp 0x00007E1EC05FE110
00007e1ec07d0e71  int3
00007e1ec07d0e72  call 0x00007E1EC06E26A0
00007e1ec07d0e77  jmp 0x00007E1EC07D0CD3
00007e1ec07d0e7c  call 0x00007E1EC06E1430
00007e1ec07d0e81  jmp 0x00007E1EC07D0CDF
00007e1ec07d0e86  call 0x00007E1EC06E01C0
00007e1ec07d0e8b  jmp 0x00007E1EC07D0CF3
00007e1ec07d0e90  call 0x00007E1EC06DEF50
00007e1ec07d0e95  jmp 0x00007E1EC07D0CFF
00007e1ec07d0e9a  call 0x00007E1EC06E2BA0
00007e1ec07d0e9f  jmp 0x00007E1EC07D0D1B
00007e1ec07d0ea4  call 0x00007E1EC06E1920
00007e1ec07d0ea9  jmp 0x00007E1EC07D0D26
00007e1ec07d0eae  call 0x00007E1EC06E26A0
00007e1ec07d0eb3  jmp 0x00007E1EC07D0D35
00007e1ec07d0eb8  call 0x00007E1EC06E1430
00007e1ec07d0ebd  jmp 0x00007E1EC07D0D44
00007e1ec07d0ec2  call 0x00007E1EC06E06B0
00007e1ec07d0ec7  jmp 0x00007E1EC07D0D5A
00007e1ec07d0ecc  call 0x00007E1EC06DF440
00007e1ec07d0ed1  jmp 0x00007E1EC07D0D65
00007e1ec07d0ed6  call 0x00007E1EC06E01C0
00007e1ec07d0edb  jmp 0x00007E1EC07D0D74
00007e1ec07d0ee0  call 0x00007E1EC06D5890
00007e1ec07d0ee5  jmp 0x00007E1EC07D0D8F
00007e1ec07d0eea  call 0x00007E1EC060BAE0
00007e1ec07d0eef  jmp 0x00007E1EC07D0DA3
00007e1ec07d0ef4  call 0x00007E1EC060DFE0
00007e1ec07d0ef9  jmp 0x00007E1EC07D0DB2
00007e1ec07d0efe  call 0x00007E1EC060DFE0
00007e1ec07d0f03  jmp 0x00007E1EC07D0DE0
00007e1ec07d0f08  call 0x00007E1EC060DFE0
00007e1ec07d0f0d  jmp 0x00007E1EC07D0DEF
00007e1ec07d0f12  int3
00007e1ec07d0f13  nop [rax+rax*1], ax
00007e1ec07d0f1c  nop [rax], eax
00007e1ec07d0f20  mov eax, [r15]
00007e1ec07d0f23  mov [rsp+0x10], eax
00007e1ec07d0f27  shr eax, 0x10
00007e1ec07d0f2a  mov r14d, [rsp+0x10]
00007e1ec07d0f2f  xor r14d, eax
00007e1ec07d0f32  imul r14d, r14d, 0x7FEB352D
00007e1ec07d0f39  mov eax, 0x846CA68B
00007e1ec07d0f3e  mov eax, eax
00007e1ec07d0f40  mov [r15+0x48], rax
00007e1ec07d0f44  mov [rsp+0x10], r14d
00007e1ec07d0f49  shr r14d, 0x0F
00007e1ec07d0f4d  mov eax, [rsp+0x10]
00007e1ec07d0f51  xor eax, r14d
00007e1ec07d0f54  imul eax, eax, 0x846CA68B
00007e1ec07d0f5a  mov [rsp+0x10], eax
00007e1ec07d0f5e  mov eax, eax
00007e1ec07d0f60  mov [r15+0x40], rax
00007e1ec07d0f64  mov eax, [rsp+0x10]
00007e1ec07d0f68  shr eax, 0x10
00007e1ec07d0f6b  mov r14d, [rsp+0x10]
00007e1ec07d0f70  xor r14d, eax
00007e1ec07d0f73  mov r14d, r14d
00007e1ec07d0f76  mov [r15], r14
00007e1ec07d0f79  mov rax, [r15+0xF0]
00007e1ec07d0f80  mov [r15+0x100], rax
00007e1ec07d0f87  jmp 0x00007E1EC07CE5C0
00007e1ec07d0f8c  int3
00007e1ec07d0f8d  int3
00007e1ec07d0f8e  nop
00007e1ec07d0f90  mov rax, [r15+0xA0]
00007e1ec07d0f97  mov [rsp+0x10], rax
00007e1ec07d0f9c  shl rax, 0x02
00007e1ec07d0fa0  mov r14, [r15+0x98]
00007e1ec07d0fa7  lea r12, [r14+rax*1]
00007e1ec07d0fab  mov eax, [r15]
00007e1ec07d0fae  mov [r13+r12*1], eax
00007e1ec07d0fb3  mov rax, [rsp+0x10]
00007e1ec07d0fb8  lea r14, [rax+0x01]
00007e1ec07d0fbc  mov [r15+0xA0], r14
00007e1ec07d0fc3  xor eax, eax
00007e1ec07d0fc5  mov r12d, 0x400
00007e1ec07d0fcb  cmp r14, r12
00007e1ec07d0fce  cmc
00007e1ec07d0fcf  lahf
00007e1ec07d0fd0  seto al
00007e1ec07d0fd3  mov [r15+0x108], eax
00007e1ec07d0fda  mov eax, [r15+0x108]
00007e1ec07d0fe1  sahf
00007e1ec07d0fe2  jnz 0x00007E1EC07D1014
00007e1ec07d0fe4  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d0fec  jz 0x00007E1EC07D10E0
00007e1ec07d0ff2  nop [rax+rax*1], ax
00007e1ec07d0ffb  nop [rax+rax*1], eax
00007e1ec07d1003  mov eax, 0x41036C
00007e1ec07d1008  mov [r15+0x100], rax
00007e1ec07d100f  jmp 0x00007E1EC05FE110
00007e1ec07d1014  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d101c  jz 0x00007E1EC07D1050
00007e1ec07d1022  nop [rax+rax*1], ax
00007e1ec07d102b  nop [rax+rax*1], eax
00007e1ec07d1033  mov eax, 0x410354
00007e1ec07d1038  mov [r15+0x100], rax
00007e1ec07d103f  jmp 0x00007E1EC05FE110
00007e1ec07d1044  int3
00007e1ec07d1045  call 0x00007E1EC06B4B70
00007e1ec07d104a  jmp 0x00007E1EC07D0FB3
00007e1ec07d104f  int3
00007e1ec07d1050  mov eax, [r15+0xA0]
00007e1ec07d1057  lea r14d, [eax+0x11]
00007e1ec07d105c  mov r14d, r14d
00007e1ec07d105f  mov [r15], r14
00007e1ec07d1062  mov qword ptr [r15+0xF0], 0x41035C
00007e1ec07d106d  mov r14d, [r15+0x320]
00007e1ec07d1074  mov eax, 0x41035C
00007e1ec07d1079  mov rcx, 0x7E1EC07D0F90
00007e1ec07d1083  mov [r15+r14*8+0x328], rax
00007e1ec07d108b  mov [r15+r14*8+0x368], rcx
00007e1ec07d1093  add r14d, 0x01
00007e1ec07d1097  and r14d, 0x07
00007e1ec07d109b  mov [r15+0x320], r14d
00007e1ec07d10a2  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d10aa  jz 0x00007E1EC07D0F20
00007e1ec07d10b0  nop [rax+rax*1], ax
00007e1ec07d10b9  nop [rax+rax*1], eax
00007e1ec07d10c1  mov eax, 0x4109A4
00007e1ec07d10c6  mov [r15+0x100], rax
00007e1ec07d10cd  jmp 0x00007E1EC05FE110
00007e1ec07d10d2  int3
00007e1ec07d10d3  int3
00007e1ec07d10d4  nop [rax+rax*1], ax
00007e1ec07d10dd  nop [rax], eax
00007e1ec07d10e0  mov qword ptr [r15+0x40], 0x01
00007e1ec07d10e8  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d10f0  jz 0x00007E1EC07D1120
00007e1ec07d10f6  nop [rax+rax*1], ax
00007e1ec07d10ff  nop [rax+rax*1], eax
00007e1ec07d1107  mov eax, 0x410388
00007e1ec07d110c  mov [r15+0x100], rax
00007e1ec07d1113  jmp 0x00007E1EC05FE110
00007e1ec07d1118  int3
00007e1ec07d1119  int3
00007e1ec07d111a  nop [rax+rax*1], ax
00007e1ec07d1120  mov rax, [r15+0x40]
00007e1ec07d1124  mov [rsp+0x10], rax
00007e1ec07d1129  shl rax, 0x02
00007e1ec07d112d  mov r14, [r15+0x98]
00007e1ec07d1134  lea r12, [r14+rax*1]
00007e1ec07d1138  mov eax, [r13+r12*1]
00007e1ec07d113d  mov [rsp+0x20], eax
00007e1ec07d1141  mov eax, eax
00007e1ec07d1143  mov [r15+0x48], rax
00007e1ec07d1147  mov rax, [rsp+0x10]
00007e1ec07d114c  mov [r15+0x50], rax
00007e1ec07d1150  mov eax, [r15+0x50]
00007e1ec07d1154  lea r12d, [eax-0x01]
00007e1ec07d1159  mov r12d, r12d
00007e1ec07d115c  mov [r15+0x58], r12
00007e1ec07d1160  mov rax, [r15+0x58]
00007e1ec07d1164  mov r12d, eax
00007e1ec07d1167  mov r12d, r12d
00007e1ec07d116a  shl r12, 0x02
00007e1ec07d116e  lea rax, [r14+r12*1]
00007e1ec07d1172  mov r14d, [r13+rax*1]
00007e1ec07d1177  mov [rsp+0x10], r14d
00007e1ec07d117c  mov r14d, r14d
00007e1ec07d117f  mov [r15+0x60], r14
00007e1ec07d1183  xor eax, eax
00007e1ec07d1185  mov r14d, [rsp+0x10]
00007e1ec07d118a  mov r12d, [rsp+0x20]
00007e1ec07d118f  cmp r14d, r12d
00007e1ec07d1192  cmc
00007e1ec07d1193  lahf
00007e1ec07d1194  seto al
00007e1ec07d1197  mov [r15+0x108], eax
00007e1ec07d119e  mov eax, [r15+0x108]
00007e1ec07d11a5  sahf
00007e1ec07d11a6  cmc
00007e1ec07d11a7  jbe 0x00007E1EC07D11D9
00007e1ec07d11a9  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d11b1  jz 0x00007E1EC07D1220
00007e1ec07d11b7  nop [rax+rax*1], ax
00007e1ec07d11c0  nop [rax+rax*1], eax
00007e1ec07d11c8  mov eax, 0x4103A0
00007e1ec07d11cd  mov [r15+0x100], rax
00007e1ec07d11d4  jmp 0x00007E1EC05FE110
00007e1ec07d11d9  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d11e1  jz 0x00007E1EC07D14C0
00007e1ec07d11e7  nop [rax+rax*1], ax
00007e1ec07d11f0  nop [rax+rax*1], eax
00007e1ec07d11f8  mov eax, 0x410378
00007e1ec07d11fd  mov [r15+0x100], rax
00007e1ec07d1204  jmp 0x00007E1EC05FE110
00007e1ec07d1209  int3
00007e1ec07d120a  call 0x00007E1EC06B4690
00007e1ec07d120f  jmp 0x00007E1EC07D113D
00007e1ec07d1214  call 0x00007E1EC060DAE0
00007e1ec07d1219  jmp 0x00007E1EC07D1177
00007e1ec07d121e  int3
00007e1ec07d121f  nop
00007e1ec07d1220  mov rax, [r15+0x50]
00007e1ec07d1224  mov [rsp+0x10], rax
00007e1ec07d1229  shl rax, 0x02
00007e1ec07d122d  mov r14, [r15+0x98]
00007e1ec07d1234  lea r12, [r14+rax*1]
00007e1ec07d1238  mov eax, [r15+0x60]
00007e1ec07d123c  mov [r13+r12*1], eax
00007e1ec07d1241  mov rax, [rsp+0x10]
00007e1ec07d1246  lea r14, [rax-0x01]
00007e1ec07d124a  mov [r15+0x50], r14
00007e1ec07d124e  mov rax, [r15+0x58]
00007e1ec07d1252  test rax, rax
00007e1ec07d1255  setz al
00007e1ec07d1258  movzx rax, al
00007e1ec07d125c  mov [rsp+0x414], al
00007e1ec07d1263  cmp byte ptr [rsp+0x414], 0x00
00007e1ec07d126b  jz 0x00007E1EC07D129D
00007e1ec07d126d  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d1275  jz 0x00007E1EC07D12E0
00007e1ec07d127b  nop [rax+rax*1], ax
00007e1ec07d1284  nop [rax+rax*1], eax
00007e1ec07d128c  mov eax, 0x4103AC
00007e1ec07d1291  mov [r15+0x100], rax
00007e1ec07d1298  jmp 0x00007E1EC05FE110
00007e1ec07d129d  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d12a5  jz 0x00007E1EC07D13E0
00007e1ec07d12ab  nop [rax+rax*1], ax
00007e1ec07d12b4  nop [rax+rax*1], eax
00007e1ec07d12bc  mov eax, 0x410390
00007e1ec07d12c1  mov [r15+0x100], rax
00007e1ec07d12c8  jmp 0x00007E1EC05FE110
00007e1ec07d12cd  int3
00007e1ec07d12ce  call 0x00007E1EC06B4B70
00007e1ec07d12d3  jmp 0x00007E1EC07D1241
00007e1ec07d12d8  int3
00007e1ec07d12d9  nop [rax], eax
00007e1ec07d12e0  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d12e8  jz 0x00007E1EC07D1320
00007e1ec07d12ee  nop [rax+rax*1], ax
00007e1ec07d12f7  nop [rax+rax*1], eax
00007e1ec07d12ff  mov eax, 0x410374
00007e1ec07d1304  mov [r15+0x100], rax
00007e1ec07d130b  jmp 0x00007E1EC05FE110
00007e1ec07d1310  int3
00007e1ec07d1311  int3
00007e1ec07d1312  nop [rax+rax*1], ax
00007e1ec07d131b  nop [rax+rax*1], eax
00007e1ec07d1320  mov qword ptr [r15+0x50], 0x00
00007e1ec07d1328  mov rax, [r15+0x40]
00007e1ec07d132c  lea r14, [rax+0x01]
00007e1ec07d1330  mov [r15+0x40], r14
00007e1ec07d1334  mov rax, [r15+0x98]
00007e1ec07d133b  mov r12d, [r15+0x48]
00007e1ec07d133f  mov [r13+rax*1], r12d
00007e1ec07d1344  xor eax, eax
00007e1ec07d1346  mov r12d, 0x400
00007e1ec07d134c  cmp r14, r12
00007e1ec07d134f  cmc
00007e1ec07d1350  lahf
00007e1ec07d1351  seto al
00007e1ec07d1354  mov [r15+0x108], eax
00007e1ec07d135b  mov eax, [r15+0x108]
00007e1ec07d1362  sahf
00007e1ec07d1363  jz 0x00007E1EC07D1395
00007e1ec07d1365  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d136d  jz 0x00007E1EC07D1120
00007e1ec07d1373  nop [rax+rax*1], ax
00007e1ec07d137c  nop [rax+rax*1], eax
00007e1ec07d1384  mov eax, 0x410388
00007e1ec07d1389  mov [r15+0x100], rax
00007e1ec07d1390  jmp 0x00007E1EC05FE110
00007e1ec07d1395  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d139d  jz 0x00007E1EC07D1580
00007e1ec07d13a3  nop [rax+rax*1], ax
00007e1ec07d13ac  nop [rax+rax*1], eax
00007e1ec07d13b4  mov eax, 0x4103B0
00007e1ec07d13b9  mov [r15+0x100], rax
00007e1ec07d13c0  jmp 0x00007E1EC05FE110
00007e1ec07d13c5  int3
00007e1ec07d13c6  call 0x00007E1EC060BAE0
00007e1ec07d13cb  jmp 0x00007E1EC07D1344
00007e1ec07d13d0  int3
00007e1ec07d13d1  nop [rax+rax*1], ax
00007e1ec07d13da  nop [rax+rax*1], ax
00007e1ec07d13e0  mov eax, [r15+0x50]
00007e1ec07d13e4  lea r14d, [eax-0x01]
00007e1ec07d13e9  mov r14d, r14d
00007e1ec07d13ec  mov [r15+0x58], r14
00007e1ec07d13f0  mov rax, [r15+0x58]
00007e1ec07d13f4  mov r14d, eax
00007e1ec07d13f7  mov r14d, r14d
00007e1ec07d13fa  shl r14, 0x02
00007e1ec07d13fe  mov rax, [r15+0x98]
00007e1ec07d1405  lea r12, [rax+r14*1]
00007e1ec07d1409  mov eax, [r13+r12*1]
00007e1ec07d140e  mov [rsp+0x10], eax
00007e1ec07d1412  mov eax, eax
00007e1ec07d1414  mov [r15+0x60], rax
00007e1ec07d1418  mov eax, [r15+0x48]
00007e1ec07d141c  mov [rsp+0x20], eax
00007e1ec07d1420  xor eax, eax
00007e1ec07d1422  mov r14d, [rsp+0x10]
00007e1ec07d1427  mov r12d, [rsp+0x20]
00007e1ec07d142c  cmp r14d, r12d
00007e1ec07d142f  cmc
00007e1ec07d1430  lahf
00007e1ec07d1431  seto al
00007e1ec07d1434  mov [r15+0x108], eax
00007e1ec07d143b  mov eax, [r15+0x108]
00007e1ec07d1442  sahf
00007e1ec07d1443  cmc
00007e1ec07d1444  jbe 0x00007E1EC07D1476
00007e1ec07d1446  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d144e  jz 0x00007E1EC07D1220
00007e1ec07d1454  nop [rax+rax*1], ax
00007e1ec07d145d  nop [rax+rax*1], eax
00007e1ec07d1465  mov eax, 0x4103A0
00007e1ec07d146a  mov [r15+0x100], rax
00007e1ec07d1471  jmp 0x00007E1EC05FE110
00007e1ec07d1476  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d147e  jz 0x00007E1EC07D14C0
00007e1ec07d1484  nop [rax+rax*1], ax
00007e1ec07d148d  nop [rax+rax*1], eax
00007e1ec07d1495  mov eax, 0x410378
00007e1ec07d149a  mov [r15+0x100], rax
00007e1ec07d14a1  jmp 0x00007E1EC05FE110
00007e1ec07d14a6  int3
00007e1ec07d14a7  call 0x00007E1EC06B4690
00007e1ec07d14ac  jmp 0x00007E1EC07D140E
00007e1ec07d14b1  int3
00007e1ec07d14b2  nop [rax+rax*1], ax
00007e1ec07d14bb  nop [rax+rax*1], eax
00007e1ec07d14c0  mov rax, [r15+0x40]
00007e1ec07d14c4  lea r14, [rax+0x01]
00007e1ec07d14c8  mov [r15+0x40], r14
00007e1ec07d14cc  mov rax, [r15+0x50]
00007e1ec07d14d0  mov r12d, eax
00007e1ec07d14d3  mov r12d, r12d
00007e1ec07d14d6  shl r12, 0x02
00007e1ec07d14da  mov rax, [r15+0x98]
00007e1ec07d14e1  lea r11, [rax+r12*1]
00007e1ec07d14e5  mov eax, [r15+0x48]
00007e1ec07d14e9  mov [r13+r11*1], eax
00007e1ec07d14ee  xor eax, eax
00007e1ec07d14f0  mov r12d, 0x400
00007e1ec07d14f6  cmp r14, r12
00007e1ec07d14f9  cmc
00007e1ec07d14fa  lahf
00007e1ec07d14fb  seto al
00007e1ec07d14fe  mov [r15+0x108], eax
00007e1ec07d1505  mov eax, [r15+0x108]
00007e1ec07d150c  sahf
00007e1ec07d150d  jz 0x00007E1EC07D153F
00007e1ec07d150f  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d1517  jz 0x00007E1EC07D1120
00007e1ec07d151d  nop [rax+rax*1], ax
00007e1ec07d1526  nop [rax+rax*1], eax
00007e1ec07d152e  mov eax, 0x410388
00007e1ec07d1533  mov [r15+0x100], rax
00007e1ec07d153a  jmp 0x00007E1EC05FE110
00007e1ec07d153f  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d1547  jz 0x00007E1EC07D1580
00007e1ec07d154d  nop [rax+rax*1], ax
00007e1ec07d1556  nop [rax+rax*1], eax
00007e1ec07d155e  mov eax, 0x4103B0
00007e1ec07d1563  mov [r15+0x100], rax
00007e1ec07d156a  jmp 0x00007E1EC05FE110
00007e1ec07d156f  int3
00007e1ec07d1570  call 0x00007E1EC06A4270
00007e1ec07d1575  jmp 0x00007E1EC07D14EE
00007e1ec07d157a  int3
00007e1ec07d157b  nop [rax+rax*1], eax
00007e1ec07d1580  mov qword ptr [r15+0x40], 0x430000
00007e1ec07d1588  mov eax, 0x430CB0
00007e1ec07d158d  mov r14, [r13+rax*1]
00007e1ec07d1592  mov rax, [r15+0x98]
00007e1ec07d1599  mov r12d, [r13+rax*1]
00007e1ec07d159e  lea r11, [rax+0x04]
00007e1ec07d15a2  mov eax, [r13+r11*1]
00007e1ec07d15a7  mov r12d, r12d
00007e1ec07d15aa  mov [r15+0x68], r12
00007e1ec07d15ae  mov eax, eax
00007e1ec07d15b0  mov [r15+0x60], rax
00007e1ec07d15b4  mov rax, [r15+0x68]
00007e1ec07d15b8  mov [r15+0x68], rax
00007e1ec07d15bc  mov qword ptr [r15+0x58], 0x02
00007e1ec07d15c4  mov [rsp+0x10], rax
00007e1ec07d15c9  xor eax, eax
00007e1ec07d15cb  mov r12d, 0x02
00007e1ec07d15d1  mov r11d, 0x400
00007e1ec07d15d7  cmp r12, r11
00007e1ec07d15da  cmc
00007e1ec07d15db  lahf
00007e1ec07d15dc  seto al
00007e1ec07d15df  mov [r15+0x108], eax
00007e1ec07d15e6  mov rax, [r15+0x60]
00007e1ec07d15ea  mov r12d, 0x02
00007e1ec07d15f0  imul rax, r12
00007e1ec07d15f4  mov [r15+0x50], rax
00007e1ec07d15f8  mov rax, [rsp+0x10]
00007e1ec07d15fd  lea r12, [rax+r14*1]
00007e1ec07d1601  mov [r15+0x48], r12
00007e1ec07d1605  mov eax, [r15+0x108]
00007e1ec07d160c  sahf
00007e1ec07d160d  jnz 0x00007E1EC07D163F
00007e1ec07d160f  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d1617  jz 0x00007E1EC07D17B0
00007e1ec07d161d  nop [rax+rax*1], ax
00007e1ec07d1626  nop [rax+rax*1], eax
00007e1ec07d162e  mov eax, 0x4103E0
00007e1ec07d1633  mov [r15+0x100], rax
00007e1ec07d163a  jmp 0x00007E1EC05FE110
00007e1ec07d163f  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d1647  jz 0x00007E1EC07D1690
00007e1ec07d164d  nop [rax+rax*1], ax
00007e1ec07d1656  nop [rax+rax*1], eax
00007e1ec07d165e  mov eax, 0x4103C0
00007e1ec07d1663  mov [r15+0x100], rax
00007e1ec07d166a  jmp 0x00007E1EC05FE110
00007e1ec07d166f  int3
00007e1ec07d1670  call 0x00007E1EC060DC20
00007e1ec07d1675  jmp 0x00007E1EC07D1592
00007e1ec07d167a  call 0x00007E1EC060B5E0
00007e1ec07d167f  jmp 0x00007E1EC07D159E
00007e1ec07d1684  call 0x00007E1EC06A3D90
00007e1ec07d1689  jmp 0x00007E1EC07D15A7
00007e1ec07d168e  int3
00007e1ec07d168f  nop
00007e1ec07d1690  mov rax, [r15+0x98]
00007e1ec07d1697  mov r14, [r15+0x58]
00007e1ec07d169b  mov [rsp+0x10], r14
00007e1ec07d16a0  shl r14, 0x02
00007e1ec07d16a4  lea r12, [rax+r14*1]
00007e1ec07d16a8  mov eax, [r13+r12*1]
00007e1ec07d16ad  lea r14, [r12+0x04]
00007e1ec07d16b2  mov r12d, [r13+r14*1]
00007e1ec07d16b7  mov eax, eax
00007e1ec07d16b9  mov [r15+0x68], rax
00007e1ec07d16bd  mov r12d, r12d
00007e1ec07d16c0  mov [r15+0x60], r12
00007e1ec07d16c4  mov rax, [r15+0x68]
00007e1ec07d16c8  mov [rsp+0x20], rax
00007e1ec07d16cd  mov r14, [rsp+0x10]
00007e1ec07d16d2  imul rax, r14
00007e1ec07d16d6  mov r12, [rsp+0x20]
00007e1ec07d16db  lea r11, [r12+rax*1]
00007e1ec07d16df  mov [r15+0x68], r11
00007e1ec07d16e3  lea rax, [r14+0x02]
00007e1ec07d16e7  mov [r15+0x58], rax
00007e1ec07d16eb  mov [rsp+0x10], rax
00007e1ec07d16f0  xor eax, eax
00007e1ec07d16f2  mov r14, [rsp+0x10]
00007e1ec07d16f7  mov r12d, 0x400
00007e1ec07d16fd  cmp r14, r12
00007e1ec07d1700  cmc
00007e1ec07d1701  lahf
00007e1ec07d1702  seto al
00007e1ec07d1705  mov [r15+0x108], eax
00007e1ec07d170c  mov rax, [r15+0x50]
00007e1ec07d1710  mov r12, [r15+0x60]
00007e1ec07d1714  imul r14, r12
00007e1ec07d1718  lea r12, [rax+r14*1]
00007e1ec07d171c  mov [r15+0x50], r12
00007e1ec07d1720  mov rax, [r15+0x48]
00007e1ec07d1724  lea r14, [r11+rax*1]
00007e1ec07d1728  mov [r15+0x48], r14
00007e1ec07d172c  mov eax, [r15+0x108]
00007e1ec07d1733  sahf
00007e1ec07d1734  jnz 0x00007E1EC07D1766
00007e1ec07d1736  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d173e  jz 0x00007E1EC07D17B0
00007e1ec07d1744  nop [rax+rax*1], ax
00007e1ec07d174d  nop [rax+rax*1], eax
00007e1ec07d1755  mov eax, 0x4103E0
00007e1ec07d175a  mov [r15+0x100], rax
00007e1ec07d1761  jmp 0x00007E1EC05FE110
00007e1ec07d1766  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d176e  jz 0x00007E1EC07D1690
00007e1ec07d1774  nop [rax+rax*1], ax
00007e1ec07d177d  nop [rax+rax*1], eax
00007e1ec07d1785  mov eax, 0x4103C0
00007e1ec07d178a  mov [r15+0x100], rax
00007e1ec07d1791  jmp 0x00007E1EC05FE110
00007e1ec07d1796  int3
00007e1ec07d1797  call 0x00007E1EC06B4690
00007e1ec07d179c  jmp 0x00007E1EC07D16AD
00007e1ec07d17a1  call 0x00007E1EC06E26A0
00007e1ec07d17a6  jmp 0x00007E1EC07D16B7
00007e1ec07d17ab  int3
00007e1ec07d17ac  nop [rax], eax
00007e1ec07d17b0  mov qword ptr [r15+0x98], 0x00
00007e1ec07d17bb  mov rax, [r15+0x50]
00007e1ec07d17bf  mov r14, [r15+0x48]
00007e1ec07d17c3  lea r12, [rax+r14*1]
00007e1ec07d17c7  mov [r15+0x48], r12
00007e1ec07d17cb  mov rax, [r15+0x40]
00007e1ec07d17cf  lea r14, [rax+0xCB0]
00007e1ec07d17d6  mov [r13+r14*1], r12
00007e1ec07d17db  mov qword ptr [r15], 0x01
00007e1ec07d17e2  mov qword ptr [r15+0xF0], 0x4103F8
00007e1ec07d17ed  mov r14d, [r15+0x320]
00007e1ec07d17f4  mov eax, 0x4103F8
00007e1ec07d17f9  mov rcx, 0x7E1EC07D1860
00007e1ec07d1803  mov [r15+r14*8+0x328], rax
00007e1ec07d180b  mov [r15+r14*8+0x368], rcx
00007e1ec07d1813  add r14d, 0x01
00007e1ec07d1817  and r14d, 0x07
00007e1ec07d181b  mov [r15+0x320], r14d
00007e1ec07d1822  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d182a  jz 0x00007E1EC07D0F20
00007e1ec07d1830  nop [rax+rax*1], ax
00007e1ec07d1839  nop [rax+rax*1], eax
00007e1ec07d1841  mov eax, 0x4109A4
00007e1ec07d1846  mov [r15+0x100], rax
00007e1ec07d184d  jmp 0x00007E1EC05FE110
00007e1ec07d1852  int3
00007e1ec07d1853  call 0x00007E1EC06E2CE0
00007e1ec07d1858  jmp 0x00007E1EC07D17DB
00007e1ec07d185d  int3
00007e1ec07d185e  nop
00007e1ec07d1860  mov eax, [r15+0x98]
00007e1ec07d1867  lea r14d, [eax+0x01]
00007e1ec07d186c  mov [rsp+0x10], r14d
00007e1ec07d1871  mov r14d, r14d
00007e1ec07d1874  mov [r15+0x98], r14
00007e1ec07d187b  xor eax, eax
00007e1ec07d187d  mov r14d, [rsp+0x10]
00007e1ec07d1882  cmp r14d, 0x10000
00007e1ec07d1889  cmc
00007e1ec07d188a  lahf
00007e1ec07d188b  seto al
00007e1ec07d188e  mov [r15+0x108], eax
00007e1ec07d1895  mov eax, [r15+0x108]
00007e1ec07d189c  sahf
00007e1ec07d189d  jnz 0x00007E1EC07D18CF
00007e1ec07d189f  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d18a7  jz 0x00007E1EC07D19A0
00007e1ec07d18ad  nop [rax+rax*1], ax
00007e1ec07d18b6  nop [rax+rax*1], eax
00007e1ec07d18be  mov eax, 0x410404
00007e1ec07d18c3  mov [r15+0x100], rax
00007e1ec07d18ca  jmp 0x00007E1EC05FE110
00007e1ec07d18cf  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d18d7  jz 0x00007E1EC07D1910
00007e1ec07d18dd  nop [rax+rax*1], ax
00007e1ec07d18e6  nop [rax+rax*1], eax
00007e1ec07d18ee  mov eax, 0x4103F0
00007e1ec07d18f3  mov [r15+0x100], rax
00007e1ec07d18fa  jmp 0x00007E1EC05FE110
00007e1ec07d18ff  int3
00007e1ec07d1900  int3
00007e1ec07d1901  nop [rax+rax*1], ax
00007e1ec07d190a  nop [rax+rax*1], ax
00007e1ec07d1910  mov eax, [r15]
00007e1ec07d1913  mov r14d, [r15+0x98]
00007e1ec07d191a  lea r12d, [eax+r14d*1]
00007e1ec07d191f  mov r12d, r12d
00007e1ec07d1922  mov [r15], r12
00007e1ec07d1925  mov qword ptr [r15+0xF0], 0x4103F8
00007e1ec07d1930  mov r14d, [r15+0x320]
00007e1ec07d1937  mov eax, 0x4103F8
00007e1ec07d193c  mov rcx, 0x7E1EC07D1860
00007e1ec07d1946  mov [r15+r14*8+0x328], rax
00007e1ec07d194e  mov [r15+r14*8+0x368], rcx
00007e1ec07d1956  add r14d, 0x01
00007e1ec07d195a  and r14d, 0x07
00007e1ec07d195e  mov [r15+0x320], r14d
00007e1ec07d1965  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d196d  jz 0x00007E1EC07D0F20
00007e1ec07d1973  nop [rax+rax*1], ax
00007e1ec07d197c  nop [rax+rax*1], eax
00007e1ec07d1984  mov eax, 0x4109A4
00007e1ec07d1989  mov [r15+0x100], rax
00007e1ec07d1990  jmp 0x00007E1EC05FE110
00007e1ec07d1995  int3
00007e1ec07d1996  int3
00007e1ec07d1997  nop [rax+rax*1], ax
00007e1ec07d19a0  vmovaps xmm1, [0x00007E1EC03FE010]
00007e1ec07d19a8  movq xmm1, xmm1
00007e1ec07d19ac  movaps [r15+0x110], xmm1
00007e1ec07d19b4  mov eax, 0x420B10
00007e1ec07d19b9  mov r14, [r13+rax*1]
00007e1ec07d19be  movq xmm1, r14
00007e1ec07d19c3  movaps [r15+0x120], xmm1
00007e1ec07d19cb  vmovaps xmm1, [0x00007E1EC03FE020]
00007e1ec07d19d3  movq xmm1, xmm1
00007e1ec07d19d7  movaps [r15+0x140], xmm1
00007e1ec07d19df  vmovaps xmm1, [0x00007E1EC03FE030]
00007e1ec07d19e7  vpbroadcastq xmm1, xmm1
00007e1ec07d19ec  movaps [r15+0x150], xmm1
00007e1ec07d19f4  mov qword ptr [r15+0x40], 0x02
00007e1ec07d19fc  vmovaps xmm15, [0x00007E1EC03FE040]
00007e1ec07d1a04  movq xmm15, xmm15
00007e1ec07d1a09  movaps [r15+0x160], xmm15
00007e1ec07d1a11  vmovaps xmm15, [0x00007E1EC03FE050]
00007e1ec07d1a19  vpbroadcastq xmm15, xmm15
00007e1ec07d1a1e  movaps [r15+0x130], xmm15
00007e1ec07d1a26  mov rax, [r15+0x40]
00007e1ec07d1a2a  vmovq xmm14, rax
00007e1ec07d1a2f  vpbroadcastq xmm14, xmm14
00007e1ec07d1a34  movaps [r15+0x170], xmm14
00007e1ec07d1a3c  mov eax, 0x420A40
00007e1ec07d1a41  movups xmm13, [r13+rax*1]
00007e1ec07d1a47  mov qword ptr [r15+0x40], 0x431E00
00007e1ec07d1a4f  mov eax, [r15]
00007e1ec07d1a52  mov r14d, 0x430CB8
00007e1ec07d1a58  mov [r13+r14*1], eax
00007e1ec07d1a5d  mov qword ptr [r15+0x50], 0x432000
00007e1ec07d1a65  vpmovqd xmm12, xmm13
00007e1ec07d1a6b  pxor xmm11, xmm11
00007e1ec07d1a70  punpcklqdq xmm12, xmm11
00007e1ec07d1a75  movaps [r15+0x210], xmm12
00007e1ec07d1a7d  movq xmm12, qword ptr [r15+0x140]
00007e1ec07d1a86  movq xmm11, qword ptr [r15+0x120]
00007e1ec07d1a8f  psubd xmm12, xmm11
00007e1ec07d1a94  movq xmm12, xmm12
00007e1ec07d1a99  paddq xmm13, xmm14
00007e1ec07d1a9e  movaps [r15+0x180], xmm13
00007e1ec07d1aa6  movq xmm14, qword ptr [r15+0x160]
00007e1ec07d1aaf  paddd xmm11, xmm14
00007e1ec07d1ab4  movq xmm11, xmm11
00007e1ec07d1ab9  movq xmm11, xmm11
00007e1ec07d1abe  movaps [r15+0x120], xmm11
00007e1ec07d1ac6  pmovzxdq xmm12, xmm12
00007e1ec07d1acc  psllq xmm12, 0x00
00007e1ec07d1ad2  movq xmm14, qword ptr [r15+0x210]
00007e1ec07d1adb  movq xmm13, qword ptr [r15+0x110]
00007e1ec07d1ae4  paddd xmm14, xmm13
00007e1ec07d1ae9  movq xmm14, xmm14
00007e1ec07d1aee  vcvtuqq2pd xmm12, xmm12
00007e1ec07d1af4  pmovzxdq xmm14, xmm14
00007e1ec07d1afa  psllq xmm14, 0x00
00007e1ec07d1b00  vcvtuqq2pd xmm14, xmm14
00007e1ec07d1b06  movaps xmm13, xmm12
00007e1ec07d1b0a  mulpd xmm13, xmm1
00007e1ec07d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007e1ec07d1b15  ptest xmm11, xmm11
00007e1ec07d1b1b  jnz 0x00007E1EC07D1C0F
00007e1ec07d1b21  movaps [r15+0x220], xmm13
00007e1ec07d1b29  mov eax, 0x432000
00007e1ec07d1b2e  movups [r13+rax*1], xmm13
00007e1ec07d1b34  movaps xmm1, xmm14
00007e1ec07d1b38  mulpd xmm1, xmm15
00007e1ec07d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007e1ec07d1b42  ptest xmm13, xmm13
00007e1ec07d1b48  jnz 0x00007E1EC07D1D5C
00007e1ec07d1b4e  movaps [r15+0x210], xmm1
00007e1ec07d1b56  mov eax, 0x431E00
00007e1ec07d1b5b  movups [r13+rax*1], xmm1
00007e1ec07d1b61  mov qword ptr [r15+0x48], 0x10
00007e1ec07d1b69  xor eax, eax
00007e1ec07d1b6b  mov r14d, 0x10
00007e1ec07d1b71  mov r12d, 0x200
00007e1ec07d1b77  cmp r14, r12
00007e1ec07d1b7a  cmc
00007e1ec07d1b7b  lahf
00007e1ec07d1b7c  seto al
00007e1ec07d1b7f  mov [r15+0x108], eax
00007e1ec07d1b86  mov eax, [r15+0x108]
00007e1ec07d1b8d  sahf
00007e1ec07d1b8e  jnz 0x00007E1EC07D1BC0
00007e1ec07d1b90  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d1b98  jz 0x00007E1EC07D2300
00007e1ec07d1b9e  nop [rax+rax*1], ax
00007e1ec07d1ba7  nop [rax+rax*1], eax
00007e1ec07d1baf  mov eax, 0x410490
00007e1ec07d1bb4  mov [r15+0x100], rax
00007e1ec07d1bbb  jmp 0x00007E1EC05FE110
00007e1ec07d1bc0  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d1bc8  jz 0x00007E1EC07D1EB0
00007e1ec07d1bce  nop [rax+rax*1], ax
00007e1ec07d1bd7  nop [rax+rax*1], eax
00007e1ec07d1bdf  mov eax, 0x410450
00007e1ec07d1be4  mov [r15+0x100], rax
00007e1ec07d1beb  jmp 0x00007E1EC05FE110
00007e1ec07d1bf0  int3
00007e1ec07d1bf1  call 0x00007E1EC060DC20
00007e1ec07d1bf6  jmp 0x00007E1EC07D19BE
00007e1ec07d1bfb  call 0x00007E1EC060C260
00007e1ec07d1c00  jmp 0x00007E1EC07D1A47
00007e1ec07d1c05  call 0x00007E1EC06D5D70
00007e1ec07d1c0a  jmp 0x00007E1EC07D1A5D
00007e1ec07d1c0f  sub rsp, 0x08
00007e1ec07d1c13  push rax
00007e1ec07d1c14  push rcx
00007e1ec07d1c15  push rdx
00007e1ec07d1c16  push rdi
00007e1ec07d1c17  push rsi
00007e1ec07d1c18  push r8
00007e1ec07d1c1a  push r9
00007e1ec07d1c1c  push r10
00007e1ec07d1c1e  push r11
00007e1ec07d1c20  sub rsp, 0xF0
00007e1ec07d1c27  vmovaps [rsp], xmm0
00007e1ec07d1c2c  vmovaps [rsp+0x10], xmm1
00007e1ec07d1c32  vmovaps [rsp+0x20], xmm2
00007e1ec07d1c38  vmovaps [rsp+0x30], xmm3
00007e1ec07d1c3e  vmovaps [rsp+0x40], xmm4
00007e1ec07d1c44  vmovaps [rsp+0x50], xmm5
00007e1ec07d1c4a  vmovaps [rsp+0x60], xmm6
00007e1ec07d1c50  vmovaps [rsp+0x70], xmm7
00007e1ec07d1c56  vmovaps [rsp+0x80], xmm8
00007e1ec07d1c5f  vmovaps [rsp+0x90], xmm9
00007e1ec07d1c68  vmovaps [rsp+0xA0], xmm10
00007e1ec07d1c71  vmovaps [rsp+0xB0], xmm11
00007e1ec07d1c7a  vmovaps [rsp+0xC0], xmm12
00007e1ec07d1c83  vmovaps [rsp+0xD0], xmm14
00007e1ec07d1c8c  vmovaps [rsp+0xE0], xmm15
00007e1ec07d1c95  sub rsp, 0x30
00007e1ec07d1c99  movaps [rsp], xmm13
00007e1ec07d1c9e  movaps [rsp+0x10], xmm12
00007e1ec07d1ca4  movaps [rsp+0x20], xmm1
00007e1ec07d1ca9  lea rdi, [rsp]
00007e1ec07d1cad  mov esi, 0x00
00007e1ec07d1cb2  mov rax, 0x5E00FF778530
00007e1ec07d1cbc  call rax
00007e1ec07d1cbe  movaps xmm13, [rsp]
00007e1ec07d1cc3  add rsp, 0x30
00007e1ec07d1cc7  vmovaps xmm0, [rsp]
00007e1ec07d1ccc  vmovaps xmm1, [rsp+0x10]
00007e1ec07d1cd2  vmovaps xmm2, [rsp+0x20]
00007e1ec07d1cd8  vmovaps xmm3, [rsp+0x30]
00007e1ec07d1cde  vmovaps xmm4, [rsp+0x40]
00007e1ec07d1ce4  vmovaps xmm5, [rsp+0x50]
00007e1ec07d1cea  vmovaps xmm6, [rsp+0x60]
00007e1ec07d1cf0  vmovaps xmm7, [rsp+0x70]
00007e1ec07d1cf6  vmovaps xmm8, [rsp+0x80]
00007e1ec07d1cff  vmovaps xmm9, [rsp+0x90]
00007e1ec07d1d08  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d1d11  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d1d1a  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d1d23  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d1d2c  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d1d35  add rsp, 0xF0
00007e1ec07d1d3c  pop r11
00007e1ec07d1d3e  pop r10
00007e1ec07d1d40  pop r9
00007e1ec07d1d42  pop r8
00007e1ec07d1d44  pop rsi
00007e1ec07d1d45  pop rdi
00007e1ec07d1d46  pop rdx
00007e1ec07d1d47  pop rcx
00007e1ec07d1d48  pop rax
00007e1ec07d1d49  add rsp, 0x08
00007e1ec07d1d4d  jmp 0x00007E1EC07D1B21
00007e1ec07d1d52  call 0x00007E1EC060C380
00007e1ec07d1d57  jmp 0x00007E1EC07D1B34
00007e1ec07d1d5c  sub rsp, 0x08
00007e1ec07d1d60  push rax
00007e1ec07d1d61  push rcx
00007e1ec07d1d62  push rdx
00007e1ec07d1d63  push rdi
00007e1ec07d1d64  push rsi
00007e1ec07d1d65  push r8
00007e1ec07d1d67  push r9
00007e1ec07d1d69  push r10
00007e1ec07d1d6b  push r11
00007e1ec07d1d6d  sub rsp, 0xF0
00007e1ec07d1d74  vmovaps [rsp], xmm0
00007e1ec07d1d79  vmovaps [rsp+0x10], xmm2
00007e1ec07d1d7f  vmovaps [rsp+0x20], xmm3
00007e1ec07d1d85  vmovaps [rsp+0x30], xmm4
00007e1ec07d1d8b  vmovaps [rsp+0x40], xmm5
00007e1ec07d1d91  vmovaps [rsp+0x50], xmm6
00007e1ec07d1d97  vmovaps [rsp+0x60], xmm7
00007e1ec07d1d9d  vmovaps [rsp+0x70], xmm8
00007e1ec07d1da3  vmovaps [rsp+0x80], xmm9
00007e1ec07d1dac  vmovaps [rsp+0x90], xmm10
00007e1ec07d1db5  vmovaps [rsp+0xA0], xmm11
00007e1ec07d1dbe  vmovaps [rsp+0xB0], xmm12
00007e1ec07d1dc7  vmovaps [rsp+0xC0], xmm13
00007e1ec07d1dd0  vmovaps [rsp+0xD0], xmm14
00007e1ec07d1dd9  vmovaps [rsp+0xE0], xmm15
00007e1ec07d1de2  sub rsp, 0x30
00007e1ec07d1de6  movaps [rsp], xmm1
00007e1ec07d1dea  movaps [rsp+0x10], xmm14
00007e1ec07d1df0  movaps [rsp+0x20], xmm15
00007e1ec07d1df6  lea rdi, [rsp]
00007e1ec07d1dfa  mov esi, 0x00
00007e1ec07d1dff  mov rax, 0x5E00FF778530
00007e1ec07d1e09  call rax
00007e1ec07d1e0b  movaps xmm1, [rsp]
00007e1ec07d1e0f  add rsp, 0x30
00007e1ec07d1e13  vmovaps xmm0, [rsp]
00007e1ec07d1e18  vmovaps xmm2, [rsp+0x10]
00007e1ec07d1e1e  vmovaps xmm3, [rsp+0x20]
00007e1ec07d1e24  vmovaps xmm4, [rsp+0x30]
00007e1ec07d1e2a  vmovaps xmm5, [rsp+0x40]
00007e1ec07d1e30  vmovaps xmm6, [rsp+0x50]
00007e1ec07d1e36  vmovaps xmm7, [rsp+0x60]
00007e1ec07d1e3c  vmovaps xmm8, [rsp+0x70]
00007e1ec07d1e42  vmovaps xmm9, [rsp+0x80]
00007e1ec07d1e4b  vmovaps xmm10, [rsp+0x90]
00007e1ec07d1e54  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d1e5d  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d1e66  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d1e6f  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d1e78  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d1e81  add rsp, 0xF0
00007e1ec07d1e88  pop r11
00007e1ec07d1e8a  pop r10
00007e1ec07d1e8c  pop r9
00007e1ec07d1e8e  pop r8
00007e1ec07d1e90  pop rsi
00007e1ec07d1e91  pop rdi
00007e1ec07d1e92  pop rdx
00007e1ec07d1e93  pop rcx
00007e1ec07d1e94  pop rax
00007e1ec07d1e95  add rsp, 0x08
00007e1ec07d1e99  jmp 0x00007E1EC07D1B4E
00007e1ec07d1e9e  call 0x00007E1EC05FF540
00007e1ec07d1ea3  jmp 0x00007E1EC07D1B61
00007e1ec07d1ea8  int3
00007e1ec07d1ea9  nop [rax], eax
00007e1ec07d1eb0  movaps xmm1, [r15+0x180]
00007e1ec07d1eb8  vpmovqd xmm15, xmm1
00007e1ec07d1ebe  pxor xmm14, xmm14
00007e1ec07d1ec3  punpcklqdq xmm15, xmm14
00007e1ec07d1ec8  movaps [r15+0x210], xmm15
00007e1ec07d1ed0  movq xmm15, qword ptr [r15+0x140]
00007e1ec07d1ed9  movq xmm14, qword ptr [r15+0x120]
00007e1ec07d1ee2  psubd xmm15, xmm14
00007e1ec07d1ee7  movq xmm15, xmm15
00007e1ec07d1eec  movaps xmm13, [r15+0x170]
00007e1ec07d1ef4  paddq xmm1, xmm13
00007e1ec07d1ef9  movaps [r15+0x180], xmm1
00007e1ec07d1f01  movq xmm1, qword ptr [r15+0x160]
00007e1ec07d1f0a  paddd xmm14, xmm1
00007e1ec07d1f0f  movq xmm14, xmm14
00007e1ec07d1f14  movq xmm14, xmm14
00007e1ec07d1f19  movaps [r15+0x120], xmm14
00007e1ec07d1f21  pmovzxdq xmm15, xmm15
00007e1ec07d1f27  psllq xmm15, 0x00
00007e1ec07d1f2d  movq xmm1, qword ptr [r15+0x210]
00007e1ec07d1f36  movq xmm14, qword ptr [r15+0x110]
00007e1ec07d1f3f  paddd xmm1, xmm14
00007e1ec07d1f44  movq xmm1, xmm1
00007e1ec07d1f48  vcvtuqq2pd xmm15, xmm15
00007e1ec07d1f4e  pmovzxdq xmm1, xmm1
00007e1ec07d1f53  psllq xmm1, 0x00
00007e1ec07d1f58  vcvtuqq2pd xmm1, xmm1
00007e1ec07d1f5e  movaps xmm14, [r15+0x150]
00007e1ec07d1f66  movaps xmm13, xmm15
00007e1ec07d1f6a  mulpd xmm13, xmm14
00007e1ec07d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007e1ec07d1f75  ptest xmm12, xmm12
00007e1ec07d1f7b  jnz 0x00007E1EC07D205E
00007e1ec07d1f81  movaps [r15+0x220], xmm13
00007e1ec07d1f89  mov rax, [r15+0x48]
00007e1ec07d1f8d  mov r14, [r15+0x50]
00007e1ec07d1f91  lea r12, [r14+rax*1]
00007e1ec07d1f95  movups [r13+r12*1], xmm13
00007e1ec07d1f9b  movaps xmm15, [r15+0x130]
00007e1ec07d1fa3  movaps xmm14, xmm1
00007e1ec07d1fa7  mulpd xmm14, xmm15
00007e1ec07d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007e1ec07d1fb2  ptest xmm13, xmm13
00007e1ec07d1fb8  jnz 0x00007E1EC07D21AC
00007e1ec07d1fbe  movaps [r15+0x210], xmm14
00007e1ec07d1fc6  mov r14, [r15+0x40]
00007e1ec07d1fca  lea r12, [r14+rax*1]
00007e1ec07d1fce  movups [r13+r12*1], xmm14
00007e1ec07d1fd4  lea r14, [rax+0x10]
00007e1ec07d1fd8  mov [r15+0x48], r14
00007e1ec07d1fdc  xor eax, eax
00007e1ec07d1fde  mov r12d, 0x200
00007e1ec07d1fe4  cmp r14, r12
00007e1ec07d1fe7  cmc
00007e1ec07d1fe8  lahf
00007e1ec07d1fe9  seto al
00007e1ec07d1fec  mov [r15+0x108], eax
00007e1ec07d1ff3  mov eax, [r15+0x108]
00007e1ec07d1ffa  sahf
00007e1ec07d1ffb  jnz 0x00007E1EC07D202D
00007e1ec07d1ffd  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d2005  jz 0x00007E1EC07D2300
00007e1ec07d200b  nop [rax+rax*1], ax
00007e1ec07d2014  nop [rax+rax*1], eax
00007e1ec07d201c  mov eax, 0x410490
00007e1ec07d2021  mov [r15+0x100], rax
00007e1ec07d2028  jmp 0x00007E1EC05FE110
00007e1ec07d202d  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d2035  jz 0x00007E1EC07D1EB0
00007e1ec07d203b  nop [rax+rax*1], ax
00007e1ec07d2044  nop [rax+rax*1], eax
00007e1ec07d204c  mov eax, 0x410450
00007e1ec07d2051  mov [r15+0x100], rax
00007e1ec07d2058  jmp 0x00007E1EC05FE110
00007e1ec07d205d  int3
00007e1ec07d205e  sub rsp, 0x08
00007e1ec07d2062  push rax
00007e1ec07d2063  push rcx
00007e1ec07d2064  push rdx
00007e1ec07d2065  push rdi
00007e1ec07d2066  push rsi
00007e1ec07d2067  push r8
00007e1ec07d2069  push r9
00007e1ec07d206b  push r10
00007e1ec07d206d  push r11
00007e1ec07d206f  sub rsp, 0xF0
00007e1ec07d2076  vmovaps [rsp], xmm0
00007e1ec07d207b  vmovaps [rsp+0x10], xmm1
00007e1ec07d2081  vmovaps [rsp+0x20], xmm2
00007e1ec07d2087  vmovaps [rsp+0x30], xmm3
00007e1ec07d208d  vmovaps [rsp+0x40], xmm4
00007e1ec07d2093  vmovaps [rsp+0x50], xmm5
00007e1ec07d2099  vmovaps [rsp+0x60], xmm6
00007e1ec07d209f  vmovaps [rsp+0x70], xmm7
00007e1ec07d20a5  vmovaps [rsp+0x80], xmm8
00007e1ec07d20ae  vmovaps [rsp+0x90], xmm9
00007e1ec07d20b7  vmovaps [rsp+0xA0], xmm10
00007e1ec07d20c0  vmovaps [rsp+0xB0], xmm11
00007e1ec07d20c9  vmovaps [rsp+0xC0], xmm12
00007e1ec07d20d2  vmovaps [rsp+0xD0], xmm14
00007e1ec07d20db  vmovaps [rsp+0xE0], xmm15
00007e1ec07d20e4  sub rsp, 0x30
00007e1ec07d20e8  movaps [rsp], xmm13
00007e1ec07d20ed  movaps [rsp+0x10], xmm15
00007e1ec07d20f3  movaps [rsp+0x20], xmm14
00007e1ec07d20f9  lea rdi, [rsp]
00007e1ec07d20fd  mov esi, 0x00
00007e1ec07d2102  mov rax, 0x5E00FF778530
00007e1ec07d210c  call rax
00007e1ec07d210e  movaps xmm13, [rsp]
00007e1ec07d2113  add rsp, 0x30
00007e1ec07d2117  vmovaps xmm0, [rsp]
00007e1ec07d211c  vmovaps xmm1, [rsp+0x10]
00007e1ec07d2122  vmovaps xmm2, [rsp+0x20]
00007e1ec07d2128  vmovaps xmm3, [rsp+0x30]
00007e1ec07d212e  vmovaps xmm4, [rsp+0x40]
00007e1ec07d2134  vmovaps xmm5, [rsp+0x50]
00007e1ec07d213a  vmovaps xmm6, [rsp+0x60]
00007e1ec07d2140  vmovaps xmm7, [rsp+0x70]
00007e1ec07d2146  vmovaps xmm8, [rsp+0x80]
00007e1ec07d214f  vmovaps xmm9, [rsp+0x90]
00007e1ec07d2158  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d2161  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d216a  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d2173  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d217c  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d2185  add rsp, 0xF0
00007e1ec07d218c  pop r11
00007e1ec07d218e  pop r10
00007e1ec07d2190  pop r9
00007e1ec07d2192  pop r8
00007e1ec07d2194  pop rsi
00007e1ec07d2195  pop rdi
00007e1ec07d2196  pop rdx
00007e1ec07d2197  pop rcx
00007e1ec07d2198  pop rax
00007e1ec07d2199  add rsp, 0x08
00007e1ec07d219d  jmp 0x00007E1EC07D1F81
00007e1ec07d21a2  call 0x00007E1EC06C2240
00007e1ec07d21a7  jmp 0x00007E1EC07D1F9B
00007e1ec07d21ac  sub rsp, 0x08
00007e1ec07d21b0  push rax
00007e1ec07d21b1  push rcx
00007e1ec07d21b2  push rdx
00007e1ec07d21b3  push rdi
00007e1ec07d21b4  push rsi
00007e1ec07d21b5  push r8
00007e1ec07d21b7  push r9
00007e1ec07d21b9  push r10
00007e1ec07d21bb  push r11
00007e1ec07d21bd  sub rsp, 0xF0
00007e1ec07d21c4  vmovaps [rsp], xmm0
00007e1ec07d21c9  vmovaps [rsp+0x10], xmm1
00007e1ec07d21cf  vmovaps [rsp+0x20], xmm2
00007e1ec07d21d5  vmovaps [rsp+0x30], xmm3
00007e1ec07d21db  vmovaps [rsp+0x40], xmm4
00007e1ec07d21e1  vmovaps [rsp+0x50], xmm5
00007e1ec07d21e7  vmovaps [rsp+0x60], xmm6
00007e1ec07d21ed  vmovaps [rsp+0x70], xmm7
00007e1ec07d21f3  vmovaps [rsp+0x80], xmm8
00007e1ec07d21fc  vmovaps [rsp+0x90], xmm9
00007e1ec07d2205  vmovaps [rsp+0xA0], xmm10
00007e1ec07d220e  vmovaps [rsp+0xB0], xmm11
00007e1ec07d2217  vmovaps [rsp+0xC0], xmm12
00007e1ec07d2220  vmovaps [rsp+0xD0], xmm13
00007e1ec07d2229  vmovaps [rsp+0xE0], xmm15
00007e1ec07d2232  sub rsp, 0x30
00007e1ec07d2236  movaps [rsp], xmm14
00007e1ec07d223b  movaps [rsp+0x10], xmm1
00007e1ec07d2240  movaps [rsp+0x20], xmm15
00007e1ec07d2246  lea rdi, [rsp]
00007e1ec07d224a  mov esi, 0x00
00007e1ec07d224f  mov rax, 0x5E00FF778530
00007e1ec07d2259  call rax
00007e1ec07d225b  movaps xmm14, [rsp]
00007e1ec07d2260  add rsp, 0x30
00007e1ec07d2264  vmovaps xmm0, [rsp]
00007e1ec07d2269  vmovaps xmm1, [rsp+0x10]
00007e1ec07d226f  vmovaps xmm2, [rsp+0x20]
00007e1ec07d2275  vmovaps xmm3, [rsp+0x30]
00007e1ec07d227b  vmovaps xmm4, [rsp+0x40]
00007e1ec07d2281  vmovaps xmm5, [rsp+0x50]
00007e1ec07d2287  vmovaps xmm6, [rsp+0x60]
00007e1ec07d228d  vmovaps xmm7, [rsp+0x70]
00007e1ec07d2293  vmovaps xmm8, [rsp+0x80]
00007e1ec07d229c  vmovaps xmm9, [rsp+0x90]
00007e1ec07d22a5  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d22ae  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d22b7  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d22c0  vmovaps xmm13, [rsp+0xD0]
00007e1ec07d22c9  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d22d2  add rsp, 0xF0
00007e1ec07d22d9  pop r11
00007e1ec07d22db  pop r10
00007e1ec07d22dd  pop r9
00007e1ec07d22df  pop r8
00007e1ec07d22e1  pop rsi
00007e1ec07d22e2  pop rdi
00007e1ec07d22e3  pop rdx
00007e1ec07d22e4  pop rcx
00007e1ec07d22e5  pop rax
00007e1ec07d22e6  add rsp, 0x08
00007e1ec07d22ea  jmp 0x00007E1EC07D1FBE
00007e1ec07d22ef  call 0x00007E1EC06C34C0
00007e1ec07d22f4  jmp 0x00007E1EC07D1FD4
00007e1ec07d22f9  int3
00007e1ec07d22fa  nop [rax+rax*1], ax
00007e1ec07d2300  mov rax, [r15+0x50]
00007e1ec07d2304  lea r14, [rax+0x80]
00007e1ec07d230b  movups xmm1, [r13+r14*1]
00007e1ec07d2311  lea r14, [rax+0x90]
00007e1ec07d2318  movups xmm15, [r13+r14*1]
00007e1ec07d231e  vxorps xmm14, xmm14, xmm14
00007e1ec07d2323  vpbroadcastq xmm14, xmm14
00007e1ec07d2328  lea r14, [rax+0x40]
00007e1ec07d232c  movups xmm13, [r13+r14*1]
00007e1ec07d2332  lea r14, [rax+0x50]
00007e1ec07d2336  movups xmm12, [r13+r14*1]
00007e1ec07d233c  mov qword ptr [r15+0x48], 0x00
00007e1ec07d2344  movups xmm11, [r13+rax*1]
00007e1ec07d234a  lea r14, [rax+0x10]
00007e1ec07d234e  movups xmm10, [r13+r14*1]
00007e1ec07d2354  mov r14, [r15+0xF8]
00007e1ec07d235b  lea r12, [r14+0xE0]
00007e1ec07d2362  movups [r13+r12*1], xmm15
00007e1ec07d2368  lea r12, [r14+0xF0]
00007e1ec07d236f  movups [r13+r12*1], xmm1
00007e1ec07d2375  lea r12, [rax+0xC0]
00007e1ec07d237c  movups xmm1, [r13+r12*1]
00007e1ec07d2382  lea r12, [rax+0xD0]
00007e1ec07d2389  movups xmm15, [r13+r12*1]
00007e1ec07d238f  lea r12, [rax+0x140]
00007e1ec07d2396  movups xmm9, [r13+r12*1]
00007e1ec07d239c  lea r12, [rax+0x150]
00007e1ec07d23a3  movups xmm8, [r13+r12*1]
00007e1ec07d23a9  lea r12, [rax+0x180]
00007e1ec07d23b0  movups xmm7, [r13+r12*1]
00007e1ec07d23b6  lea r12, [rax+0x190]
00007e1ec07d23bd  movups xmm6, [r13+r12*1]
00007e1ec07d23c3  lea r12, [r14+0xC0]
00007e1ec07d23ca  movups [r13+r12*1], xmm15
00007e1ec07d23d0  lea r12, [r14+0xD0]
00007e1ec07d23d7  movups [r13+r12*1], xmm1
00007e1ec07d23dd  lea r12, [rax+0x100]
00007e1ec07d23e4  movups xmm1, [r13+r12*1]
00007e1ec07d23ea  lea r12, [rax+0x110]
00007e1ec07d23f1  movups xmm15, [r13+r12*1]
00007e1ec07d23f7  lea r12, [rax+0x1C0]
00007e1ec07d23fe  movups xmm5, [r13+r12*1]
00007e1ec07d2404  lea r12, [rax+0x1D0]
00007e1ec07d240b  movups xmm4, [r13+r12*1]
00007e1ec07d2411  lea r12, [rax+0x20]
00007e1ec07d2415  movups xmm3, [r13+r12*1]
00007e1ec07d241b  lea r12, [rax+0x30]
00007e1ec07d241f  movups xmm2, [r13+r12*1]
00007e1ec07d2425  movaps [r15+0x1F0], xmm2
00007e1ec07d242d  lea r12, [r14+0x20]
00007e1ec07d2431  movups [r13+r12*1], xmm1
00007e1ec07d2437  lea r12, [r14+0x30]
00007e1ec07d243b  movups [r13+r12*1], xmm12
00007e1ec07d2441  lea r12, [rax+0x60]
00007e1ec07d2445  movups xmm1, [r13+r12*1]
00007e1ec07d244b  lea r12, [rax+0x70]
00007e1ec07d244f  movups xmm12, [r13+r12*1]
00007e1ec07d2455  lea r12, [r14+0x60]
00007e1ec07d2459  movups [r13+r12*1], xmm11
00007e1ec07d245f  lea r12, [r14+0x70]
00007e1ec07d2463  movups [r13+r12*1], xmm5
00007e1ec07d2469  lea r12, [rax+0xE0]
00007e1ec07d2470  movups xmm11, [r13+r12*1]
00007e1ec07d2476  lea r12, [rax+0xF0]
00007e1ec07d247d  movups xmm5, [r13+r12*1]
00007e1ec07d2483  lea r12, [rax+0x120]
00007e1ec07d248a  vmovaps [rsp+0x10], xmm1
00007e1ec07d2490  movups xmm1, [r13+r12*1]
00007e1ec07d2496  lea r12, [rax+0x130]
00007e1ec07d249d  vmovaps [rsp+0x20], xmm1
00007e1ec07d24a3  movups xmm1, [r13+r12*1]
00007e1ec07d24a9  lea r12, [r14+0xA0]
00007e1ec07d24b0  movups [r13+r12*1], xmm12
00007e1ec07d24b6  lea r12, [r14+0xB0]
00007e1ec07d24bd  vmovaps xmm12, [rsp+0x10]
00007e1ec07d24c3  movups [r13+r12*1], xmm12
00007e1ec07d24c9  lea r12, [rax+0xA0]
00007e1ec07d24d0  movups xmm12, [r13+r12*1]
00007e1ec07d24d6  lea r12, [rax+0xB0]
00007e1ec07d24dd  vmovaps [rsp+0x10], xmm1
00007e1ec07d24e3  movups xmm1, [r13+r12*1]
00007e1ec07d24e9  lea r12, [rax+0x160]
00007e1ec07d24f0  vmovaps [rsp+0x30], xmm1
00007e1ec07d24f6  movups xmm1, [r13+r12*1]
00007e1ec07d24fc  lea r12, [rax+0x170]
00007e1ec07d2503  vmovaps [rsp+0x40], xmm1
00007e1ec07d2509  movups xmm1, [r13+r12*1]
00007e1ec07d250f  movaps [r15+0x2B0], xmm1
00007e1ec07d2517  lea r12, [rax+0x1A0]
00007e1ec07d251e  vmovaps [rsp+0x50], xmm1
00007e1ec07d2524  movups xmm1, [r13+r12*1]
00007e1ec07d252a  lea r12, [rax+0x1B0]
00007e1ec07d2531  vmovaps [rsp+0x60], xmm1
00007e1ec07d2537  movups xmm1, [r13+r12*1]
00007e1ec07d253d  vmovaps [rsp+0x70], xmm1
00007e1ec07d2543  vmovaps xmm1, [rsp+0x60]
00007e1ec07d2549  movaps [r15+0x290], xmm1
00007e1ec07d2551  vmovaps [rsp+0x60], xmm1
00007e1ec07d2557  vmovaps xmm1, [rsp+0x70]
00007e1ec07d255d  movaps [r15+0x1E0], xmm1
00007e1ec07d2565  lea r12, [r14+0x80]
00007e1ec07d256c  vmovaps [rsp+0x70], xmm1
00007e1ec07d2572  vmovaps xmm1, [rsp+0x30]
00007e1ec07d2578  movups [r13+r12*1], xmm1
00007e1ec07d257e  lea r12, [r14+0x90]
00007e1ec07d2585  movups [r13+r12*1], xmm12
00007e1ec07d258b  lea r12, [rax+0x1E0]
00007e1ec07d2592  movups xmm1, [r13+r12*1]
00007e1ec07d2598  lea r12, [rax+0x1F0]
00007e1ec07d259f  movups xmm12, [r13+r12*1]
00007e1ec07d25a5  mov qword ptr [r15+0x50], 0x432200
00007e1ec07d25ad  lea rax, [r14+0x40]
00007e1ec07d25b1  vmovaps [rsp+0x30], xmm1
00007e1ec07d25b7  vmovaps xmm1, [rsp+0x40]
00007e1ec07d25bd  movups [r13+rax*1], xmm1
00007e1ec07d25c3  lea rax, [r14+0x50]
00007e1ec07d25c7  movups [r13+rax*1], xmm10
00007e1ec07d25cd  movups [r13+r14*1], xmm12
00007e1ec07d25d3  lea rax, [r14+0x10]
00007e1ec07d25d7  vmovaps xmm1, [rsp+0x30]
00007e1ec07d25dd  movups [r13+rax*1], xmm1
00007e1ec07d25e3  mov rax, [r15+0x40]
00007e1ec07d25e7  vmovaps [rsp+0x30], xmm3
00007e1ec07d25ed  vmovaps xmm1, [rsp+0x30]
00007e1ec07d25f3  por xmm3, xmm1
00007e1ec07d25f7  vmovaps [rsp+0x30], xmm6
00007e1ec07d25fd  vmovaps xmm12, [rsp+0x30]
00007e1ec07d2603  por xmm6, xmm12
00007e1ec07d2608  lea r12, [rax+0x30]
00007e1ec07d260c  mov r11, [r13+r12*1]
00007e1ec07d2611  lea r12, [rax+0x38]
00007e1ec07d2615  mov r10, [r13+r12*1]
00007e1ec07d261a  movq xmm12, r11
00007e1ec07d261f  movq xmm10, r10
00007e1ec07d2624  movq xmm12, xmm12
00007e1ec07d2629  vmovaps [rsp+0x30], xmm12
00007e1ec07d262f  movq xmm12, xmm12
00007e1ec07d2634  movaps [r15+0x130], xmm12
00007e1ec07d263c  movq xmm10, xmm10
00007e1ec07d2641  vmovaps [rsp+0x40], xmm10
00007e1ec07d2647  movq xmm10, xmm10
00007e1ec07d264c  movaps [r15+0x280], xmm10
00007e1ec07d2654  vmovaps [rsp+0x80], xmm9
00007e1ec07d265d  vmovaps xmm12, [rsp+0x80]
00007e1ec07d2666  por xmm9, xmm12
00007e1ec07d266b  lea r12, [rax+0x20]
00007e1ec07d266f  mov r11, [r13+r12*1]
00007e1ec07d2674  lea r12, [rax+0x28]
00007e1ec07d2678  mov r10, [r13+r12*1]
00007e1ec07d267d  movq xmm12, r11
00007e1ec07d2682  movq xmm10, r10
00007e1ec07d2687  movq xmm12, xmm12
00007e1ec07d268c  vmovaps [rsp+0x80], xmm12
00007e1ec07d2695  movq xmm12, xmm12
00007e1ec07d269a  movaps [r15+0x150], xmm12
00007e1ec07d26a2  movq xmm10, xmm10
00007e1ec07d26a7  vmovaps [rsp+0x90], xmm10
00007e1ec07d26b0  movq xmm10, xmm10
00007e1ec07d26b5  movaps [r15+0x140], xmm10
00007e1ec07d26bd  lea r12, [rax+0x10]
00007e1ec07d26c1  mov r11, [r13+r12*1]
00007e1ec07d26c6  lea r12, [rax+0x18]
00007e1ec07d26ca  mov r10, [r13+r12*1]
00007e1ec07d26cf  movq xmm12, r11
00007e1ec07d26d4  movq xmm10, r10
00007e1ec07d26d9  movq xmm12, xmm12
00007e1ec07d26de  vmovaps [rsp+0xA0], xmm12
00007e1ec07d26e7  movq xmm12, xmm12
00007e1ec07d26ec  movaps [r15+0x170], xmm12
00007e1ec07d26f4  movq xmm10, xmm10
00007e1ec07d26f9  vmovaps [rsp+0xB0], xmm10
00007e1ec07d2702  movq xmm10, xmm10
00007e1ec07d2707  movaps [r15+0x160], xmm10
00007e1ec07d270f  mov r12, [r13+rax*1]
00007e1ec07d2714  vmovq xmm12, r12
00007e1ec07d2719  vpbroadcastq xmm12, xmm12
00007e1ec07d271e  lea r12, [rax+0x08]
00007e1ec07d2722  mov rax, [r13+r12*1]
00007e1ec07d2727  movq xmm10, rax
00007e1ec07d272c  movaps [r15+0x230], xmm10
00007e1ec07d2734  lea rax, [r14+0x50]
00007e1ec07d2738  movups xmm10, [r13+rax*1]
00007e1ec07d273e  lea rax, [r14+0x60]
00007e1ec07d2742  vmovaps [rsp+0xC0], xmm1
00007e1ec07d274b  movups xmm1, [r13+rax*1]
00007e1ec07d2751  lea rax, [r14+0x30]
00007e1ec07d2755  vmovaps [rsp+0xD0], xmm1
00007e1ec07d275e  movups xmm1, [r13+rax*1]
00007e1ec07d2764  mov qword ptr [r15+0x60], 0x432200
00007e1ec07d276c  mov qword ptr [r15+0x58], 0x40
00007e1ec07d2774  vmovaps [rsp+0xE0], xmm1
00007e1ec07d277d  vmovaps [rsp+0xF0], xmm15
00007e1ec07d2786  vmovaps xmm15, [rsp+0xC0]
00007e1ec07d278f  vmovaps [rsp+0xC0], xmm14
00007e1ec07d2798  movaps xmm1, xmm12
00007e1ec07d279c  mulpd xmm1, xmm15
00007e1ec07d27a1  vcmppd xmm14, xmm1, xmm1, 0x03
00007e1ec07d27a6  ptest xmm14, xmm14
00007e1ec07d27ac  jnz 0x00007E1EC07D3863
00007e1ec07d27b2  movq xmm15, qword ptr [r15+0x230]
00007e1ec07d27bb  vmovaps [rsp+0x100], xmm15
00007e1ec07d27c4  vpermilpd xmm15, xmm15, 0x00
00007e1ec07d27ca  vmovaps [rsp+0x110], xmm1
00007e1ec07d27d3  vmovaps xmm1, [rsp+0xE0]
00007e1ec07d27dc  vmovaps [rsp+0xE0], xmm13
00007e1ec07d27e5  movaps xmm14, xmm1
00007e1ec07d27e9  mulpd xmm14, xmm15
00007e1ec07d27ee  vcmppd xmm13, xmm14, xmm14, 0x03
00007e1ec07d27f4  ptest xmm13, xmm13
00007e1ec07d27fa  jnz 0x00007E1EC07D39A5
00007e1ec07d2800  vxorps xmm1, xmm1, xmm1
00007e1ec07d2804  vpbroadcastq xmm1, xmm1
00007e1ec07d2809  vmovaps xmm13, [rsp+0xD0]
00007e1ec07d2812  vmovaps [rsp+0xD0], xmm1
00007e1ec07d281b  movaps xmm15, xmm12
00007e1ec07d281f  mulpd xmm15, xmm13
00007e1ec07d2824  vcmppd xmm1, xmm15, xmm15, 0x03
00007e1ec07d282a  ptest xmm1, xmm1
00007e1ec07d282f  jnz 0x00007E1EC07D3AE8
00007e1ec07d2835  movaps xmm1, xmm12
00007e1ec07d2839  mulpd xmm1, xmm10
00007e1ec07d283e  vcmppd xmm13, xmm1, xmm1, 0x03
00007e1ec07d2843  ptest xmm13, xmm13
00007e1ec07d2849  jnz 0x00007E1EC07D3C2C
00007e1ec07d284f  movaps xmm13, xmm12
00007e1ec07d2853  mulpd xmm13, xmm2
00007e1ec07d2858  vcmppd xmm10, xmm13, xmm13, 0x03
00007e1ec07d285e  ptest xmm10, xmm10
00007e1ec07d2864  jnz 0x00007E1EC07D3D6E
00007e1ec07d286a  vmovaps [rsp+0x120], xmm7
00007e1ec07d2873  vmovaps xmm12, [rsp+0x120]
00007e1ec07d287c  por xmm7, xmm12
00007e1ec07d2881  vmovaps xmm12, [rsp+0xE0]
00007e1ec07d288a  vmovaps xmm10, [rsp+0xE0]
00007e1ec07d2893  por xmm12, xmm10
00007e1ec07d2898  vmovaps xmm2, [rsp+0x100]
00007e1ec07d28a1  vpermilpd xmm2, xmm2, 0x00
00007e1ec07d28a7  vmovaps [rsp+0xE0], xmm1
00007e1ec07d28b0  vmovaps [rsp+0x120], xmm15
00007e1ec07d28b9  movaps xmm1, xmm10
00007e1ec07d28bd  mulpd xmm1, xmm2
00007e1ec07d28c1  vcmppd xmm15, xmm1, xmm1, 0x03
00007e1ec07d28c6  ptest xmm15, xmm15
00007e1ec07d28cc  jnz 0x00007E1EC07D3EB1
00007e1ec07d28d2  xor eax, eax
00007e1ec07d28d4  mov r12d, 0x40
00007e1ec07d28da  mov r11d, 0x200
00007e1ec07d28e0  cmp r12, r11
00007e1ec07d28e3  cmc
00007e1ec07d28e4  lahf
00007e1ec07d28e5  seto al
00007e1ec07d28e8  mov [r15+0x108], eax
00007e1ec07d28ef  vmovaps xmm10, [rsp+0x110]
00007e1ec07d28f8  vmovaps xmm2, [rsp+0xD0]
00007e1ec07d2901  vmovaps [rsp+0xD0], xmm1
00007e1ec07d290a  movaps xmm15, xmm10
00007e1ec07d290e  addpd xmm15, xmm2
00007e1ec07d2913  vcmppd xmm1, xmm15, xmm15, 0x03
00007e1ec07d2919  ptest xmm1, xmm1
00007e1ec07d291e  jnz 0x00007E1EC07D3FF2
00007e1ec07d2924  vmovaps xmm10, [rsp+0x120]
00007e1ec07d292d  vmovaps [rsp+0x110], xmm15
00007e1ec07d2936  vmovaps xmm15, [rsp+0xC0]
00007e1ec07d293f  vmovaps [rsp+0xC0], xmm14
00007e1ec07d2948  movaps xmm1, xmm10
00007e1ec07d294c  addpd xmm1, xmm15
00007e1ec07d2951  vcmppd xmm14, xmm1, xmm1, 0x03
00007e1ec07d2956  ptest xmm14, xmm14
00007e1ec07d295c  jnz 0x00007E1EC07D4135
00007e1ec07d2962  vmovaps xmm10, [rsp+0xE0]
00007e1ec07d296b  vmovaps [rsp+0xE0], xmm1
00007e1ec07d2974  movaps xmm14, xmm10
00007e1ec07d2978  addpd xmm14, xmm15
00007e1ec07d297d  vcmppd xmm1, xmm14, xmm14, 0x03
00007e1ec07d2983  ptest xmm1, xmm1
00007e1ec07d2988  jnz 0x00007E1EC07D4277
00007e1ec07d298e  vmovaps xmm1, [rsp+0x10]
00007e1ec07d2994  vmovaps xmm15, [rsp+0x10]
00007e1ec07d299a  por xmm1, xmm15
00007e1ec07d299f  vmovaps xmm15, [rsp+0x20]
00007e1ec07d29a5  vmovaps xmm10, [rsp+0x20]
00007e1ec07d29ab  por xmm15, xmm10
00007e1ec07d29b0  vmovaps [rsp+0x10], xmm5
00007e1ec07d29b6  vmovaps xmm10, [rsp+0x10]
00007e1ec07d29bc  por xmm5, xmm10
00007e1ec07d29c1  vmovaps [rsp+0x10], xmm11
00007e1ec07d29c7  vmovaps xmm10, [rsp+0x10]
00007e1ec07d29cd  por xmm11, xmm10
00007e1ec07d29d2  vmovaps [rsp+0x10], xmm4
00007e1ec07d29d8  vmovaps xmm10, [rsp+0x10]
00007e1ec07d29de  por xmm4, xmm10
00007e1ec07d29e3  vmovaps [rsp+0x10], xmm8
00007e1ec07d29e9  vmovaps xmm10, [rsp+0x10]
00007e1ec07d29ef  por xmm8, xmm10
00007e1ec07d29f4  vmovaps xmm10, [rsp+0xF0]
00007e1ec07d29fd  vmovaps [rsp+0x10], xmm1
00007e1ec07d2a03  vmovaps xmm1, [rsp+0xF0]
00007e1ec07d2a0c  por xmm10, xmm1
00007e1ec07d2a11  lea rax, [r14+0xA0]
00007e1ec07d2a18  movups xmm1, [r13+rax*1]
00007e1ec07d2a1e  lea rax, [r14+0xB0]
00007e1ec07d2a25  vmovaps [rsp+0x20], xmm1
00007e1ec07d2a2b  movups xmm1, [r13+rax*1]
00007e1ec07d2a31  vmovaps [rsp+0xF0], xmm1
00007e1ec07d2a3a  vmovaps [rsp+0x120], xmm15
00007e1ec07d2a43  movaps xmm1, xmm13
00007e1ec07d2a47  addpd xmm1, xmm2
00007e1ec07d2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
00007e1ec07d2a50  ptest xmm15, xmm15
00007e1ec07d2a56  jnz 0x00007E1EC07D43CF
00007e1ec07d2a5c  lea rax, [r14+0xF0]
00007e1ec07d2a63  movups xmm15, [r13+rax*1]
00007e1ec07d2a69  vmovaps xmm2, [rsp+0xE0]
00007e1ec07d2a72  vmovaps [rsp+0xE0], xmm1
00007e1ec07d2a7b  vmovaps xmm1, [rsp+0xD0]
00007e1ec07d2a84  vmovaps [rsp+0xD0], xmm15
00007e1ec07d2a8d  movaps xmm13, xmm2
00007e1ec07d2a91  addpd xmm13, xmm1
00007e1ec07d2a96  vcmppd xmm15, xmm13, xmm13, 0x03
00007e1ec07d2a9c  ptest xmm15, xmm15
00007e1ec07d2aa2  jnz 0x00007E1EC07D451A
00007e1ec07d2aa8  vmovaps xmm15, [rsp+0xC0]
00007e1ec07d2ab1  movaps xmm1, xmm14
00007e1ec07d2ab5  addpd xmm1, xmm15
00007e1ec07d2aba  vcmppd xmm2, xmm1, xmm1, 0x03
00007e1ec07d2abf  ptest xmm2, xmm2
00007e1ec07d2ac4  jnz 0x00007E1EC07D465C
00007e1ec07d2aca  vmovaps xmm15, [rsp+0x100]
00007e1ec07d2ad3  vpermilpd xmm15, xmm15, 0x00
00007e1ec07d2ad9  vmovaps xmm2, [rsp+0xF0]
00007e1ec07d2ae2  vmovaps [rsp+0xC0], xmm1
00007e1ec07d2aeb  movaps xmm14, xmm2
00007e1ec07d2aef  mulpd xmm14, xmm15
00007e1ec07d2af4  vcmppd xmm1, xmm14, xmm14, 0x03
00007e1ec07d2afa  ptest xmm1, xmm1
00007e1ec07d2aff  jnz 0x00007E1EC07D479E
00007e1ec07d2b05  vmovaps xmm1, [rsp+0xA0]
00007e1ec07d2b0e  vpermilpd xmm1, xmm1, 0x00
00007e1ec07d2b14  vmovaps xmm2, [rsp+0xD0]
00007e1ec07d2b1d  vmovaps [rsp+0xD0], xmm14
00007e1ec07d2b26  movaps xmm15, xmm2
00007e1ec07d2b2a  mulpd xmm15, xmm1
00007e1ec07d2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
00007e1ec07d2b35  ptest xmm14, xmm14
00007e1ec07d2b3b  jnz 0x00007E1EC07D48E1
00007e1ec07d2b41  lea rax, [r14+0xE0]
00007e1ec07d2b48  movups xmm1, [r13+rax*1]
00007e1ec07d2b4e  vmovaps xmm14, [rsp+0x100]
00007e1ec07d2b57  vpermilpd xmm14, xmm14, 0x00
00007e1ec07d2b5d  vmovaps [rsp+0xF0], xmm1
00007e1ec07d2b66  vmovaps xmm1, [rsp+0x20]
00007e1ec07d2b6c  vmovaps [rsp+0x20], xmm15
00007e1ec07d2b72  movaps xmm2, xmm1
00007e1ec07d2b75  mulpd xmm2, xmm14
00007e1ec07d2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
00007e1ec07d2b7f  ptest xmm15, xmm15
00007e1ec07d2b85  jnz 0x00007E1EC07D4A2D
00007e1ec07d2b8b  vmovaps [rsp+0x100], xmm10
00007e1ec07d2b94  vmovaps xmm1, [rsp+0x100]
00007e1ec07d2b9d  por xmm10, xmm1
00007e1ec07d2ba2  movaps [r15+0x300], xmm10
00007e1ec07d2baa  vmovaps [rsp+0x100], xmm8
00007e1ec07d2bb3  vmovaps xmm1, [rsp+0x100]
00007e1ec07d2bbc  por xmm8, xmm1
00007e1ec07d2bc1  movaps [r15+0x190], xmm8
00007e1ec07d2bc9  vmovaps xmm1, [rsp+0xA0]
00007e1ec07d2bd2  vpermilpd xmm1, xmm1, 0x00
00007e1ec07d2bd8  vmovaps xmm14, [rsp+0xF0]
00007e1ec07d2be1  vmovaps [rsp+0xF0], xmm13
00007e1ec07d2bea  movaps xmm15, xmm14
00007e1ec07d2bee  mulpd xmm15, xmm1
00007e1ec07d2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
00007e1ec07d2bf9  ptest xmm13, xmm13
00007e1ec07d2bff  jnz 0x00007E1EC07D4B6E
00007e1ec07d2c05  lea rax, [r14+0x90]
00007e1ec07d2c0c  movups xmm1, [r13+rax*1]
00007e1ec07d2c12  vmovaps [rsp+0x100], xmm4
00007e1ec07d2c1b  vmovaps xmm14, [rsp+0x100]
00007e1ec07d2c24  por xmm4, xmm14
00007e1ec07d2c29  movaps [r15+0x1C0], xmm4
00007e1ec07d2c31  vmovaps [rsp+0x100], xmm11
00007e1ec07d2c3a  vmovaps xmm14, [rsp+0x100]
00007e1ec07d2c43  por xmm11, xmm14
00007e1ec07d2c48  movaps [r15+0x200], xmm11
00007e1ec07d2c50  vmovaps [rsp+0x100], xmm5
00007e1ec07d2c59  vmovaps xmm14, [rsp+0x100]
00007e1ec07d2c62  por xmm5, xmm14
00007e1ec07d2c67  movaps [r15+0x2D0], xmm5
00007e1ec07d2c6f  vmovaps xmm14, [rsp+0x120]
00007e1ec07d2c78  vmovaps xmm13, [rsp+0x120]
00007e1ec07d2c81  por xmm14, xmm13
00007e1ec07d2c86  movaps [r15+0x2E0], xmm14
00007e1ec07d2c8e  vmovaps [rsp+0x100], xmm1
00007e1ec07d2c97  vmovaps xmm1, [rsp+0x110]
00007e1ec07d2ca0  vmovaps [rsp+0x110], xmm15
00007e1ec07d2ca9  vmovaps xmm15, [rsp+0xD0]
00007e1ec07d2cb2  vmovaps [rsp+0xD0], xmm14
00007e1ec07d2cbb  movaps xmm13, xmm1
00007e1ec07d2cbf  addpd xmm13, xmm15
00007e1ec07d2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
00007e1ec07d2cca  ptest xmm14, xmm14
00007e1ec07d2cd0  jnz 0x00007E1EC07D4CBB
00007e1ec07d2cd6  vmovaps xmm1, [rsp+0xA0]
00007e1ec07d2cdf  vpermilpd xmm1, xmm1, 0x00
00007e1ec07d2ce5  vmovaps xmm14, [rsp+0x100]
00007e1ec07d2cee  vmovaps [rsp+0x100], xmm13
00007e1ec07d2cf7  movaps xmm15, xmm14
00007e1ec07d2cfb  mulpd xmm15, xmm1
00007e1ec07d2d00  vcmppd xmm13, xmm15, xmm15, 0x03
00007e1ec07d2d06  ptest xmm13, xmm13
00007e1ec07d2d0c  jnz 0x00007E1EC07D4DFE
00007e1ec07d2d12  lea rax, [r14+0x80]
00007e1ec07d2d19  movups xmm1, [r13+rax*1]
00007e1ec07d2d1f  vmovaps xmm13, [rsp+0xE0]
00007e1ec07d2d28  vmovaps [rsp+0xE0], xmm1
00007e1ec07d2d31  movaps xmm14, xmm13
00007e1ec07d2d35  addpd xmm14, xmm2
00007e1ec07d2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
00007e1ec07d2d40  ptest xmm1, xmm1
00007e1ec07d2d45  jnz 0x00007E1EC07D4F4B
00007e1ec07d2d4b  vmovaps xmm13, [rsp+0xF0]
00007e1ec07d2d54  vmovaps xmm2, [rsp+0x20]
00007e1ec07d2d5a  vmovaps [rsp+0x20], xmm15
00007e1ec07d2d60  movaps xmm1, xmm13
00007e1ec07d2d64  addpd xmm1, xmm2
00007e1ec07d2d68  vcmppd xmm15, xmm1, xmm1, 0x03
00007e1ec07d2d6d  ptest xmm15, xmm15
00007e1ec07d2d73  jnz 0x00007E1EC07D508E
00007e1ec07d2d79  vmovaps xmm15, [rsp+0x10]
00007e1ec07d2d7f  vmovaps xmm13, [rsp+0x10]
00007e1ec07d2d85  por xmm15, xmm13
00007e1ec07d2d8a  movaps [r15+0x2F0], xmm15
00007e1ec07d2d92  vmovaps xmm13, [rsp+0xA0]
00007e1ec07d2d9b  vpermilpd xmm13, xmm13, 0x00
00007e1ec07d2da1  vmovaps [rsp+0x10], xmm1
00007e1ec07d2da7  vmovaps xmm1, [rsp+0xE0]
00007e1ec07d2db0  vmovaps [rsp+0xA0], xmm15
00007e1ec07d2db9  movaps xmm2, xmm1
00007e1ec07d2dbc  mulpd xmm2, xmm13
00007e1ec07d2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
00007e1ec07d2dc6  ptest xmm15, xmm15
00007e1ec07d2dcc  jnz 0x00007E1EC07D51CF
00007e1ec07d2dd2  lea rax, [r14+0xD0]
00007e1ec07d2dd9  movups xmm1, [r13+rax*1]
00007e1ec07d2ddf  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d2de8  vmovaps [rsp+0xC0], xmm1
00007e1ec07d2df1  vmovaps xmm1, [rsp+0x110]
00007e1ec07d2dfa  vmovaps [rsp+0xE0], xmm14
00007e1ec07d2e03  movaps xmm15, xmm13
00007e1ec07d2e07  addpd xmm15, xmm1
00007e1ec07d2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
00007e1ec07d2e12  ptest xmm14, xmm14
00007e1ec07d2e18  jnz 0x00007E1EC07D531A
00007e1ec07d2e1e  vmovaps xmm1, [rsp+0xB0]
00007e1ec07d2e27  vpermilpd xmm1, xmm1, 0x00
00007e1ec07d2e2d  movaps xmm14, xmm11
00007e1ec07d2e31  mulpd xmm14, xmm1
00007e1ec07d2e36  vcmppd xmm13, xmm14, xmm14, 0x03
00007e1ec07d2e3c  ptest xmm13, xmm13
00007e1ec07d2e42  jnz 0x00007E1EC07D545D
00007e1ec07d2e48  movaps [r15+0x260], xmm14
00007e1ec07d2e50  vxorps xmm1, xmm1, xmm1
00007e1ec07d2e54  vpbroadcastq xmm1, xmm1
00007e1ec07d2e59  movaps [r15+0x1B0], xmm1
00007e1ec07d2e61  vmovaps xmm1, [rsp+0xB0]
00007e1ec07d2e6a  vpermilpd xmm1, xmm1, 0x00
00007e1ec07d2e70  vmovaps xmm11, [rsp+0xC0]
00007e1ec07d2e79  vmovaps [rsp+0xC0], xmm15
00007e1ec07d2e82  movaps xmm13, xmm11
00007e1ec07d2e86  mulpd xmm13, xmm1
00007e1ec07d2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
00007e1ec07d2e91  ptest xmm15, xmm15
00007e1ec07d2e97  jnz 0x00007E1EC07D55A0
00007e1ec07d2e9d  lea rax, [r14+0xC0]
00007e1ec07d2ea4  movups xmm1, [r13+rax*1]
00007e1ec07d2eaa  vmovaps xmm11, [rsp+0x100]
00007e1ec07d2eb3  vmovaps [rsp+0xF0], xmm1
00007e1ec07d2ebc  vmovaps xmm1, [rsp+0x20]
00007e1ec07d2ec2  vmovaps [rsp+0x20], xmm14
00007e1ec07d2ec8  movaps xmm15, xmm11
00007e1ec07d2ecc  addpd xmm15, xmm1
00007e1ec07d2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
00007e1ec07d2ed7  ptest xmm14, xmm14
00007e1ec07d2edd  jnz 0x00007E1EC07D56ED
00007e1ec07d2ee3  vmovaps [rsp+0x100], xmm9
00007e1ec07d2eec  vmovaps xmm1, [rsp+0x100]
00007e1ec07d2ef5  por xmm9, xmm1
00007e1ec07d2efa  movaps [r15+0x270], xmm9
00007e1ec07d2f02  vmovaps [rsp+0x100], xmm6
00007e1ec07d2f0b  vmovaps xmm1, [rsp+0x100]
00007e1ec07d2f14  por xmm6, xmm1
00007e1ec07d2f18  movaps [r15+0x1A0], xmm6
00007e1ec07d2f20  vmovaps xmm14, [rsp+0xB0]
00007e1ec07d2f29  vpermilpd xmm14, xmm14, 0x00
00007e1ec07d2f2f  vmovaps xmm6, [rsp+0xF0]
00007e1ec07d2f38  vmovaps [rsp+0xF0], xmm1
00007e1ec07d2f41  movaps xmm11, xmm6
00007e1ec07d2f45  mulpd xmm11, xmm14
00007e1ec07d2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
00007e1ec07d2f50  ptest xmm1, xmm1
00007e1ec07d2f55  jnz 0x00007E1EC07D5830
00007e1ec07d2f5b  lea rax, [r14+0x20]
00007e1ec07d2f5f  movups xmm1, [r13+rax*1]
00007e1ec07d2f65  movaps [r15+0x110], xmm1
00007e1ec07d2f6d  vmovaps xmm6, [rsp+0xE0]
00007e1ec07d2f76  vmovaps [rsp+0xE0], xmm1
00007e1ec07d2f7f  movaps xmm14, xmm6
00007e1ec07d2f83  addpd xmm14, xmm2
00007e1ec07d2f88  vcmppd xmm1, xmm14, xmm14, 0x03
00007e1ec07d2f8e  ptest xmm1, xmm1
00007e1ec07d2f93  jnz 0x00007E1EC07D597D
00007e1ec07d2f99  vmovaps xmm1, [rsp+0xB0]
00007e1ec07d2fa2  vpermilpd xmm1, xmm1, 0x00
00007e1ec07d2fa8  movaps xmm6, xmm5
00007e1ec07d2fab  mulpd xmm6, xmm1
00007e1ec07d2faf  vcmppd xmm2, xmm6, xmm6, 0x03
00007e1ec07d2fb4  ptest xmm2, xmm2
00007e1ec07d2fb9  jnz 0x00007E1EC07D5ABF
00007e1ec07d2fbf  vmovaps xmm5, [rsp+0x10]
00007e1ec07d2fc5  movaps xmm1, xmm5
00007e1ec07d2fc8  addpd xmm1, xmm13
00007e1ec07d2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
00007e1ec07d2fd2  ptest xmm2, xmm2
00007e1ec07d2fd7  jnz 0x00007E1EC07D5BFF
00007e1ec07d2fdd  vmovaps xmm13, [rsp+0x80]
00007e1ec07d2fe6  vpermilpd xmm13, xmm13, 0x00
00007e1ec07d2fec  vmovaps xmm2, [rsp+0xE0]
00007e1ec07d2ff5  vmovaps [rsp+0x10], xmm1
00007e1ec07d2ffb  movaps xmm5, xmm2
00007e1ec07d2ffe  mulpd xmm5, xmm13
00007e1ec07d3003  vcmppd xmm1, xmm5, xmm5, 0x03
00007e1ec07d3008  ptest xmm1, xmm1
00007e1ec07d300d  jnz 0x00007E1EC07D5D40
00007e1ec07d3013  vmovaps xmm1, [rsp+0x80]
00007e1ec07d301c  vpermilpd xmm1, xmm1, 0x00
00007e1ec07d3022  movaps xmm13, xmm10
00007e1ec07d3026  mulpd xmm13, xmm1
00007e1ec07d302b  vcmppd xmm2, xmm13, xmm13, 0x03
00007e1ec07d3031  ptest xmm2, xmm2
00007e1ec07d3036  jnz 0x00007E1EC07D5E81
00007e1ec07d303c  vmovaps xmm10, [rsp+0x20]
00007e1ec07d3042  movaps xmm1, xmm15
00007e1ec07d3046  addpd xmm1, xmm10
00007e1ec07d304b  vcmppd xmm2, xmm1, xmm1, 0x03
00007e1ec07d3050  ptest xmm2, xmm2
00007e1ec07d3055  jnz 0x00007E1EC07D5FC4
00007e1ec07d305b  vmovaps xmm10, [rsp+0xC0]
00007e1ec07d3064  movaps xmm15, xmm10
00007e1ec07d3068  addpd xmm15, xmm11
00007e1ec07d306d  vcmppd xmm2, xmm15, xmm15, 0x03
00007e1ec07d3073  ptest xmm2, xmm2
00007e1ec07d3078  jnz 0x00007E1EC07D6106
00007e1ec07d307e  vmovaps xmm11, [rsp+0x80]
00007e1ec07d3087  vpermilpd xmm11, xmm11, 0x00
00007e1ec07d308d  vmovaps xmm2, [rsp+0xD0]
00007e1ec07d3096  vmovaps [rsp+0x20], xmm1
00007e1ec07d309c  movaps xmm10, xmm2
00007e1ec07d30a0  mulpd xmm10, xmm11
00007e1ec07d30a5  vcmppd xmm1, xmm10, xmm10, 0x03
00007e1ec07d30ab  ptest xmm1, xmm1
00007e1ec07d30b0  jnz 0x00007E1EC07D624A
00007e1ec07d30b6  vmovaps xmm1, [rsp+0x80]
00007e1ec07d30bf  vpermilpd xmm1, xmm1, 0x00
00007e1ec07d30c5  vmovaps xmm2, [rsp+0xA0]
00007e1ec07d30ce  vmovaps [rsp+0x80], xmm15
00007e1ec07d30d7  movaps xmm11, xmm2
00007e1ec07d30db  mulpd xmm11, xmm1
00007e1ec07d30e0  vcmppd xmm15, xmm11, xmm11, 0x03
00007e1ec07d30e6  ptest xmm15, xmm15
00007e1ec07d30ec  jnz 0x00007E1EC07D638D
00007e1ec07d30f2  movaps xmm1, xmm14
00007e1ec07d30f6  addpd xmm1, xmm6
00007e1ec07d30fa  vcmppd xmm15, xmm1, xmm1, 0x03
00007e1ec07d30ff  ptest xmm15, xmm15
00007e1ec07d3105  jnz 0x00007E1EC07D64CF
00007e1ec07d310b  vmovaps xmm14, [rsp+0x10]
00007e1ec07d3111  movaps xmm15, xmm14
00007e1ec07d3115  addpd xmm15, xmm5
00007e1ec07d311a  vcmppd xmm6, xmm15, xmm15, 0x03
00007e1ec07d3120  ptest xmm6, xmm6
00007e1ec07d3125  jnz 0x00007E1EC07D6610
00007e1ec07d312b  vmovaps xmm14, [rsp+0x90]
00007e1ec07d3134  vpermilpd xmm14, xmm14, 0x00
00007e1ec07d313a  movaps xmm6, xmm9
00007e1ec07d313e  mulpd xmm6, xmm14
00007e1ec07d3143  vcmppd xmm5, xmm6, xmm6, 0x03
00007e1ec07d3148  ptest xmm5, xmm5
00007e1ec07d314d  jnz 0x00007E1EC07D6753
00007e1ec07d3153  vmovaps xmm9, [rsp+0x80]
00007e1ec07d315c  movaps xmm14, xmm9
00007e1ec07d3160  addpd xmm14, xmm13
00007e1ec07d3165  vcmppd xmm5, xmm14, xmm14, 0x03
00007e1ec07d316b  ptest xmm5, xmm5
00007e1ec07d3170  jnz 0x00007E1EC07D6895
00007e1ec07d3176  vmovaps xmm9, [rsp+0x20]
00007e1ec07d317c  movaps xmm13, xmm9
00007e1ec07d3180  addpd xmm13, xmm10
00007e1ec07d3185  vcmppd xmm5, xmm13, xmm13, 0x03
00007e1ec07d318b  ptest xmm5, xmm5
00007e1ec07d3190  jnz 0x00007E1EC07D69D9
00007e1ec07d3196  vmovaps [rsp+0x10], xmm12
00007e1ec07d319c  vmovaps xmm10, [rsp+0x10]
00007e1ec07d31a2  por xmm12, xmm10
00007e1ec07d31a7  movaps [r15+0x250], xmm12
00007e1ec07d31af  vmovaps [rsp+0x10], xmm7
00007e1ec07d31b5  vmovaps xmm12, [rsp+0x10]
00007e1ec07d31bb  por xmm7, xmm12
00007e1ec07d31c0  movaps [r15+0x2A0], xmm7
00007e1ec07d31c8  vmovaps [rsp+0x10], xmm3
00007e1ec07d31ce  vmovaps xmm12, [rsp+0x10]
00007e1ec07d31d4  por xmm3, xmm12
00007e1ec07d31d9  movaps [r15+0x1D0], xmm3
00007e1ec07d31e1  lea rax, [r14+0x40]
00007e1ec07d31e5  movups xmm12, [r13+rax*1]
00007e1ec07d31eb  movaps [r15+0x2C0], xmm12
00007e1ec07d31f3  vmovaps xmm10, [rsp+0x90]
00007e1ec07d31fc  vpermilpd xmm10, xmm10, 0x00
00007e1ec07d3202  movaps xmm9, xmm8
00007e1ec07d3206  mulpd xmm9, xmm10
00007e1ec07d320b  vcmppd xmm5, xmm9, xmm9, 0x03
00007e1ec07d3211  ptest xmm5, xmm5
00007e1ec07d3216  jnz 0x00007E1EC07D6B27
00007e1ec07d321c  movaps xmm10, xmm1
00007e1ec07d3220  addpd xmm10, xmm11
00007e1ec07d3225  vcmppd xmm8, xmm10, xmm10, 0x03
00007e1ec07d322b  ptest xmm8, xmm8
00007e1ec07d3231  jnz 0x00007E1EC07D6C6B
00007e1ec07d3237  movaps xmm1, xmm15
00007e1ec07d323b  addpd xmm1, xmm6
00007e1ec07d323f  vcmppd xmm11, xmm1, xmm1, 0x03
00007e1ec07d3244  ptest xmm11, xmm11
00007e1ec07d324a  jnz 0x00007E1EC07D6DAE
00007e1ec07d3250  vmovaps xmm15, [rsp+0x90]
00007e1ec07d3259  vpermilpd xmm15, xmm15, 0x00
00007e1ec07d325f  movaps xmm11, xmm12
00007e1ec07d3263  mulpd xmm11, xmm15
00007e1ec07d3268  vcmppd xmm8, xmm11, xmm11, 0x03
00007e1ec07d326e  ptest xmm8, xmm8
00007e1ec07d3274  jnz 0x00007E1EC07D6EEF
00007e1ec07d327a  vmovaps xmm15, [rsp+0x90]
00007e1ec07d3283  vpermilpd xmm15, xmm15, 0x00
00007e1ec07d3289  vmovaps xmm8, [rsp+0x50]
00007e1ec07d328f  movaps xmm12, xmm8
00007e1ec07d3293  mulpd xmm12, xmm15
00007e1ec07d3298  vcmppd xmm6, xmm12, xmm12, 0x03
00007e1ec07d329e  ptest xmm6, xmm6
00007e1ec07d32a3  jnz 0x00007E1EC07D7033
00007e1ec07d32a9  vmovaps xmm15, [rsp+0x30]
00007e1ec07d32af  vpermilpd xmm15, xmm15, 0x00
00007e1ec07d32b5  movaps xmm8, xmm7
00007e1ec07d32b9  mulpd xmm8, xmm15
00007e1ec07d32be  vcmppd xmm6, xmm8, xmm8, 0x03
00007e1ec07d32c4  ptest xmm6, xmm6
00007e1ec07d32c9  jnz 0x00007E1EC07D7177
00007e1ec07d32cf  movaps xmm15, xmm14
00007e1ec07d32d3  addpd xmm15, xmm9
00007e1ec07d32d8  vcmppd xmm7, xmm15, xmm15, 0x03
00007e1ec07d32de  ptest xmm7, xmm7
00007e1ec07d32e3  jnz 0x00007E1EC07D72BA
00007e1ec07d32e9  vmovaps xmm14, [rsp+0x30]
00007e1ec07d32ef  vpermilpd xmm14, xmm14, 0x00
00007e1ec07d32f5  vmovaps xmm7, [rsp+0xF0]
00007e1ec07d32fe  movaps xmm9, xmm7
00007e1ec07d3302  mulpd xmm9, xmm14
00007e1ec07d3307  vcmppd xmm6, xmm9, xmm9, 0x03
00007e1ec07d330d  ptest xmm6, xmm6
00007e1ec07d3312  jnz 0x00007E1EC07D73FE
00007e1ec07d3318  movaps xmm14, xmm13
00007e1ec07d331c  addpd xmm14, xmm11
00007e1ec07d3321  vcmppd xmm7, xmm14, xmm14, 0x03
00007e1ec07d3327  ptest xmm7, xmm7
00007e1ec07d332c  jnz 0x00007E1EC07D7541
00007e1ec07d3332  vmovaps xmm13, [rsp+0x30]
00007e1ec07d3338  vpermilpd xmm13, xmm13, 0x00
00007e1ec07d333e  vmovaps xmm7, [rsp+0x60]
00007e1ec07d3344  movaps xmm11, xmm7
00007e1ec07d3348  mulpd xmm11, xmm13
00007e1ec07d334d  vcmppd xmm6, xmm11, xmm11, 0x03
00007e1ec07d3353  ptest xmm6, xmm6
00007e1ec07d3358  jnz 0x00007E1EC07D7685
00007e1ec07d335e  movaps xmm13, xmm10
00007e1ec07d3362  addpd xmm13, xmm12
00007e1ec07d3367  vcmppd xmm7, xmm13, xmm13, 0x03
00007e1ec07d336d  ptest xmm7, xmm7
00007e1ec07d3372  jnz 0x00007E1EC07D77C8
00007e1ec07d3378  vmovaps xmm12, [rsp+0x30]
00007e1ec07d337e  vpermilpd xmm12, xmm12, 0x00
00007e1ec07d3384  vmovaps xmm7, [rsp+0x70]
00007e1ec07d338a  movaps xmm10, xmm7
00007e1ec07d338e  mulpd xmm10, xmm12
00007e1ec07d3393  vcmppd xmm6, xmm10, xmm10, 0x03
00007e1ec07d3399  ptest xmm6, xmm6
00007e1ec07d339e  jnz 0x00007E1EC07D790C
00007e1ec07d33a4  movaps xmm12, xmm1
00007e1ec07d33a8  addpd xmm12, xmm8
00007e1ec07d33ad  vcmppd xmm7, xmm12, xmm12, 0x03
00007e1ec07d33b3  ptest xmm7, xmm7
00007e1ec07d33b8  jnz 0x00007E1EC07D7A4F
00007e1ec07d33be  lea rax, [r14+0x70]
00007e1ec07d33c2  movups xmm1, [r13+rax*1]
00007e1ec07d33c8  movaps [r15+0x240], xmm1
00007e1ec07d33d0  movaps xmm8, xmm15
00007e1ec07d33d4  addpd xmm8, xmm9
00007e1ec07d33d9  vcmppd xmm7, xmm8, xmm8, 0x03
00007e1ec07d33df  ptest xmm7, xmm7
00007e1ec07d33e4  jnz 0x00007E1EC07D7B9C
00007e1ec07d33ea  movaps [r15+0x170], xmm8
00007e1ec07d33f2  vmovaps xmm15, [rsp+0x40]
00007e1ec07d33f8  vpermilpd xmm15, xmm15, 0x00
00007e1ec07d33fe  movaps xmm9, xmm1
00007e1ec07d3402  mulpd xmm9, xmm15
00007e1ec07d3407  vcmppd xmm7, xmm9, xmm9, 0x03
00007e1ec07d340d  ptest xmm7, xmm7
00007e1ec07d3412  jnz 0x00007E1EC07D7CE0
00007e1ec07d3418  vmovaps xmm1, [rsp+0x40]
00007e1ec07d341e  vpermilpd xmm1, xmm1, 0x00
00007e1ec07d3424  movaps xmm15, xmm4
00007e1ec07d3428  mulpd xmm15, xmm1
00007e1ec07d342d  vcmppd xmm7, xmm15, xmm15, 0x03
00007e1ec07d3433  ptest xmm7, xmm7
00007e1ec07d3438  jnz 0x00007E1EC07D7E23
00007e1ec07d343e  movaps [r15+0x180], xmm15
00007e1ec07d3446  movaps xmm1, xmm14
00007e1ec07d344a  addpd xmm1, xmm11
00007e1ec07d344f  vcmppd xmm7, xmm1, xmm1, 0x03
00007e1ec07d3454  ptest xmm7, xmm7
00007e1ec07d3459  jnz 0x00007E1EC07D7F65
00007e1ec07d345f  movaps [r15+0x210], xmm1
00007e1ec07d3467  movups xmm14, [r13+r14*1]
00007e1ec07d346d  lea rax, [r14+0x10]
00007e1ec07d3471  movups xmm11, [r13+rax*1]
00007e1ec07d3477  movaps [r15+0x230], xmm11
00007e1ec07d347f  movaps xmm7, xmm13
00007e1ec07d3483  addpd xmm7, xmm10
00007e1ec07d3488  vcmppd xmm6, xmm7, xmm7, 0x03
00007e1ec07d348d  ptest xmm6, xmm6
00007e1ec07d3492  jnz 0x00007E1EC07D80BB
00007e1ec07d3498  movaps [r15+0x130], xmm7
00007e1ec07d34a0  vmovaps xmm13, [rsp+0x40]
00007e1ec07d34a6  vpermilpd xmm13, xmm13, 0x00
00007e1ec07d34ac  movaps xmm10, xmm11
00007e1ec07d34b0  mulpd xmm10, xmm13
00007e1ec07d34b5  vcmppd xmm6, xmm10, xmm10, 0x03
00007e1ec07d34bb  ptest xmm6, xmm6
00007e1ec07d34c0  jnz 0x00007E1EC07D81FD
00007e1ec07d34c6  movaps [r15+0x220], xmm10
00007e1ec07d34ce  vmovaps xmm13, [rsp+0x40]
00007e1ec07d34d4  vpermilpd xmm13, xmm13, 0x00
00007e1ec07d34da  movaps xmm11, xmm14
00007e1ec07d34de  mulpd xmm11, xmm13
00007e1ec07d34e3  vcmppd xmm6, xmm11, xmm11, 0x03
00007e1ec07d34e9  ptest xmm6, xmm6
00007e1ec07d34ee  jnz 0x00007E1EC07D8341
00007e1ec07d34f4  movaps xmm14, xmm12
00007e1ec07d34f8  addpd xmm14, xmm9
00007e1ec07d34fd  vcmppd xmm13, xmm14, xmm14, 0x03
00007e1ec07d3503  ptest xmm13, xmm13
00007e1ec07d3509  jnz 0x00007E1EC07D8485
00007e1ec07d350f  movaps [r15+0x140], xmm14
00007e1ec07d3517  movaps xmm13, xmm8
00007e1ec07d351b  addpd xmm13, xmm15
00007e1ec07d3520  vcmppd xmm12, xmm13, xmm13, 0x03
00007e1ec07d3526  ptest xmm12, xmm12
00007e1ec07d352c  jnz 0x00007E1EC07D85C9
00007e1ec07d3532  movaps [r15+0x150], xmm13
00007e1ec07d353a  movaps xmm15, xmm1
00007e1ec07d353e  addpd xmm15, xmm10
00007e1ec07d3543  vcmppd xmm12, xmm15, xmm15, 0x03
00007e1ec07d3549  ptest xmm12, xmm12
00007e1ec07d354f  jnz 0x00007E1EC07D870D
00007e1ec07d3555  movaps [r15+0x160], xmm15
00007e1ec07d355d  movaps xmm1, xmm7
00007e1ec07d3560  addpd xmm1, xmm11
00007e1ec07d3565  vcmppd xmm12, xmm1, xmm1, 0x03
00007e1ec07d356a  ptest xmm12, xmm12
00007e1ec07d3570  jnz 0x00007E1EC07D8850
00007e1ec07d3576  movaps [r15+0x120], xmm1
00007e1ec07d357e  mov eax, 0x432200
00007e1ec07d3583  movups [r13+rax*1], xmm14
00007e1ec07d3589  mov eax, 0x432210
00007e1ec07d358e  movups [r13+rax*1], xmm13
00007e1ec07d3594  mov eax, 0x432220
00007e1ec07d3599  movups [r13+rax*1], xmm15
00007e1ec07d359f  mov eax, 0x432230
00007e1ec07d35a4  movups [r13+rax*1], xmm1
00007e1ec07d35aa  mov eax, [r15+0x108]
00007e1ec07d35b1  sahf
00007e1ec07d35b2  jnz 0x00007E1EC07D35E4
00007e1ec07d35b4  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d35bc  jz 0x00007E1EC07DEAE0
00007e1ec07d35c2  nop [rax+rax*1], ax
00007e1ec07d35cb  nop [rax+rax*1], eax
00007e1ec07d35d3  mov eax, 0x4106D0
00007e1ec07d35d8  mov [r15+0x100], rax
00007e1ec07d35df  jmp 0x00007E1EC05FE110
00007e1ec07d35e4  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d35ec  jz 0x00007E1EC07D89C0
00007e1ec07d35f2  nop [rax+rax*1], ax
00007e1ec07d35fb  nop [rax+rax*1], eax
00007e1ec07d3603  mov eax, 0x410504
00007e1ec07d3608  mov [r15+0x100], rax
00007e1ec07d360f  jmp 0x00007E1EC05FE110
00007e1ec07d3614  int3
00007e1ec07d3615  call 0x00007E1EC06D64F0
00007e1ec07d361a  jmp 0x00007E1EC07D2311
00007e1ec07d361f  call 0x00007E1EC06E5820
00007e1ec07d3624  jmp 0x00007E1EC07D231E
00007e1ec07d3629  call 0x00007E1EC06E3320
00007e1ec07d362e  jmp 0x00007E1EC07D2332
00007e1ec07d3633  call 0x00007E1EC06E20A0
00007e1ec07d3638  jmp 0x00007E1EC07D233C
00007e1ec07d363d  call 0x00007E1EC0609D70
00007e1ec07d3642  jmp 0x00007E1EC07D234A
00007e1ec07d3647  call 0x00007E1EC06DFBC0
00007e1ec07d364c  jmp 0x00007E1EC07D2354
00007e1ec07d3651  call 0x00007E1EC06C4740
00007e1ec07d3656  jmp 0x00007E1EC07D2368
00007e1ec07d365b  call 0x00007E1EC06B5400
00007e1ec07d3660  jmp 0x00007E1EC07D2375
00007e1ec07d3665  call 0x00007E1EC06B52F0
00007e1ec07d366a  jmp 0x00007E1EC07D2382
00007e1ec07d366f  call 0x00007E1EC06C4620
00007e1ec07d3674  jmp 0x00007E1EC07D238F
00007e1ec07d3679  call 0x00007E1EC06BD750
00007e1ec07d367e  jmp 0x00007E1EC07D239C
00007e1ec07d3683  call 0x00007E1EC06BC4E0
00007e1ec07d3688  jmp 0x00007E1EC07D23A9
00007e1ec07d368d  call 0x00007E1EC06BB270
00007e1ec07d3692  jmp 0x00007E1EC07D23B6
00007e1ec07d3697  call 0x00007E1EC06BA000
00007e1ec07d369c  jmp 0x00007E1EC07D23C3
00007e1ec07d36a1  call 0x00007E1EC06C4740
00007e1ec07d36a6  jmp 0x00007E1EC07D23D0
00007e1ec07d36ab  call 0x00007E1EC06B5400
00007e1ec07d36b0  jmp 0x00007E1EC07D23DD
00007e1ec07d36b5  call 0x00007E1EC06B52F0
00007e1ec07d36ba  jmp 0x00007E1EC07D23EA
00007e1ec07d36bf  call 0x00007E1EC06C4620
00007e1ec07d36c4  jmp 0x00007E1EC07D23F7
00007e1ec07d36c9  call 0x00007E1EC06B8D90
00007e1ec07d36ce  jmp 0x00007E1EC07D2404
00007e1ec07d36d3  call 0x00007E1EC06B8A20
00007e1ec07d36d8  jmp 0x00007E1EC07D2411
00007e1ec07d36dd  call 0x00007E1EC06B77B0
00007e1ec07d36e2  jmp 0x00007E1EC07D241B
00007e1ec07d36e7  call 0x00007E1EC06B6550
00007e1ec07d36ec  jmp 0x00007E1EC07D2425
00007e1ec07d36f1  call 0x00007E1EC06B5400
00007e1ec07d36f6  jmp 0x00007E1EC07D2437
00007e1ec07d36fb  call 0x00007E1EC06C0FC0
00007e1ec07d3700  jmp 0x00007E1EC07D2441
00007e1ec07d3705  call 0x00007E1EC06B52F0
00007e1ec07d370a  jmp 0x00007E1EC07D244B
00007e1ec07d370f  call 0x00007E1EC06C0EA0
00007e1ec07d3714  jmp 0x00007E1EC07D2455
00007e1ec07d3719  call 0x00007E1EC06BFD50
00007e1ec07d371e  jmp 0x00007E1EC07D245F
00007e1ec07d3723  call 0x00007E1EC06B8EA0
00007e1ec07d3728  jmp 0x00007E1EC07D2469
00007e1ec07d372d  call 0x00007E1EC06BFC30
00007e1ec07d3732  jmp 0x00007E1EC07D2476
00007e1ec07d3737  call 0x00007E1EC06B8D90
00007e1ec07d373c  jmp 0x00007E1EC07D2483
00007e1ec07d3741  call 0x00007E1EC06B52F0
00007e1ec07d3746  jmp 0x00007E1EC07D2496
00007e1ec07d374b  call 0x00007E1EC06B52F0
00007e1ec07d3750  jmp 0x00007E1EC07D24A9
00007e1ec07d3755  call 0x00007E1EC06C0FC0
00007e1ec07d375a  jmp 0x00007E1EC07D24B6
00007e1ec07d375f  call 0x00007E1EC06C0FC0
00007e1ec07d3764  jmp 0x00007E1EC07D24C9
00007e1ec07d3769  call 0x00007E1EC06C0EA0
00007e1ec07d376e  jmp 0x00007E1EC07D24D6
00007e1ec07d3773  call 0x00007E1EC06B52F0
00007e1ec07d3778  jmp 0x00007E1EC07D24E9
00007e1ec07d377d  call 0x00007E1EC06B52F0
00007e1ec07d3782  jmp 0x00007E1EC07D24FC
00007e1ec07d3787  call 0x00007E1EC06B52F0
00007e1ec07d378c  jmp 0x00007E1EC07D250F
00007e1ec07d3791  call 0x00007E1EC06B52F0
00007e1ec07d3796  jmp 0x00007E1EC07D252A
00007e1ec07d379b  call 0x00007E1EC06B52F0
00007e1ec07d37a0  jmp 0x00007E1EC07D253D
00007e1ec07d37a5  call 0x00007E1EC06B5400
00007e1ec07d37aa  jmp 0x00007E1EC07D257E
00007e1ec07d37af  call 0x00007E1EC06C0FC0
00007e1ec07d37b4  jmp 0x00007E1EC07D258B
00007e1ec07d37b9  call 0x00007E1EC06B52F0
00007e1ec07d37be  jmp 0x00007E1EC07D2598
00007e1ec07d37c3  call 0x00007E1EC06C0EA0
00007e1ec07d37c8  jmp 0x00007E1EC07D25A5
00007e1ec07d37cd  call 0x00007E1EC05FF540
00007e1ec07d37d2  jmp 0x00007E1EC07D25C3
00007e1ec07d37d7  call 0x00007E1EC0608C20
00007e1ec07d37dc  jmp 0x00007E1EC07D25CD
00007e1ec07d37e1  call 0x00007E1EC06E21C0
00007e1ec07d37e6  jmp 0x00007E1EC07D25D3
00007e1ec07d37eb  call 0x00007E1EC05FF540
00007e1ec07d37f0  jmp 0x00007E1EC07D25E3
00007e1ec07d37f5  call 0x00007E1EC06C0370
00007e1ec07d37fa  jmp 0x00007E1EC07D2611
00007e1ec07d37ff  call 0x00007E1EC06BF100
00007e1ec07d3804  jmp 0x00007E1EC07D261A
00007e1ec07d3809  call 0x00007E1EC06C0370
00007e1ec07d380e  jmp 0x00007E1EC07D2674
00007e1ec07d3813  call 0x00007E1EC06BF100
00007e1ec07d3818  jmp 0x00007E1EC07D267D
00007e1ec07d381d  call 0x00007E1EC06C0370
00007e1ec07d3822  jmp 0x00007E1EC07D26C6
00007e1ec07d3827  call 0x00007E1EC06BF100
00007e1ec07d382c  jmp 0x00007E1EC07D26CF
00007e1ec07d3831  call 0x00007E1EC060B720
00007e1ec07d3836  jmp 0x00007E1EC07D2714
00007e1ec07d383b  call 0x00007E1EC06B47C0
00007e1ec07d3840  jmp 0x00007E1EC07D2727
00007e1ec07d3845  call 0x00007E1EC0608B00
00007e1ec07d384a  jmp 0x00007E1EC07D273E
00007e1ec07d384f  call 0x00007E1EC05FF430
00007e1ec07d3854  jmp 0x00007E1EC07D2751
00007e1ec07d3859  call 0x00007E1EC05FF430
00007e1ec07d385e  jmp 0x00007E1EC07D2764
00007e1ec07d3863  sub rsp, 0x08
00007e1ec07d3867  push rax
00007e1ec07d3868  push rcx
00007e1ec07d3869  push rdx
00007e1ec07d386a  push rdi
00007e1ec07d386b  push rsi
00007e1ec07d386c  push r8
00007e1ec07d386e  push r9
00007e1ec07d3870  push r10
00007e1ec07d3872  push r11
00007e1ec07d3874  sub rsp, 0xF0
00007e1ec07d387b  vmovaps [rsp], xmm0
00007e1ec07d3880  vmovaps [rsp+0x10], xmm2
00007e1ec07d3886  vmovaps [rsp+0x20], xmm3
00007e1ec07d388c  vmovaps [rsp+0x30], xmm4
00007e1ec07d3892  vmovaps [rsp+0x40], xmm5
00007e1ec07d3898  vmovaps [rsp+0x50], xmm6
00007e1ec07d389e  vmovaps [rsp+0x60], xmm7
00007e1ec07d38a4  vmovaps [rsp+0x70], xmm8
00007e1ec07d38aa  vmovaps [rsp+0x80], xmm9
00007e1ec07d38b3  vmovaps [rsp+0x90], xmm10
00007e1ec07d38bc  vmovaps [rsp+0xA0], xmm11
00007e1ec07d38c5  vmovaps [rsp+0xB0], xmm12
00007e1ec07d38ce  vmovaps [rsp+0xC0], xmm13
00007e1ec07d38d7  vmovaps [rsp+0xD0], xmm14
00007e1ec07d38e0  vmovaps [rsp+0xE0], xmm15
00007e1ec07d38e9  sub rsp, 0x30
00007e1ec07d38ed  movaps [rsp], xmm1
00007e1ec07d38f1  movaps [rsp+0x10], xmm12
00007e1ec07d38f7  movaps [rsp+0x20], xmm15
00007e1ec07d38fd  lea rdi, [rsp]
00007e1ec07d3901  mov esi, 0x00
00007e1ec07d3906  mov rax, 0x5E00FF778530
00007e1ec07d3910  call rax
00007e1ec07d3912  movaps xmm1, [rsp]
00007e1ec07d3916  add rsp, 0x30
00007e1ec07d391a  vmovaps xmm0, [rsp]
00007e1ec07d391f  vmovaps xmm2, [rsp+0x10]
00007e1ec07d3925  vmovaps xmm3, [rsp+0x20]
00007e1ec07d392b  vmovaps xmm4, [rsp+0x30]
00007e1ec07d3931  vmovaps xmm5, [rsp+0x40]
00007e1ec07d3937  vmovaps xmm6, [rsp+0x50]
00007e1ec07d393d  vmovaps xmm7, [rsp+0x60]
00007e1ec07d3943  vmovaps xmm8, [rsp+0x70]
00007e1ec07d3949  vmovaps xmm9, [rsp+0x80]
00007e1ec07d3952  vmovaps xmm10, [rsp+0x90]
00007e1ec07d395b  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d3964  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d396d  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d3976  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d397f  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d3988  add rsp, 0xF0
00007e1ec07d398f  pop r11
00007e1ec07d3991  pop r10
00007e1ec07d3993  pop r9
00007e1ec07d3995  pop r8
00007e1ec07d3997  pop rsi
00007e1ec07d3998  pop rdi
00007e1ec07d3999  pop rdx
00007e1ec07d399a  pop rcx
00007e1ec07d399b  pop rax
00007e1ec07d399c  add rsp, 0x08
00007e1ec07d39a0  jmp 0x00007E1EC07D27B2
00007e1ec07d39a5  sub rsp, 0x08
00007e1ec07d39a9  push rax
00007e1ec07d39aa  push rcx
00007e1ec07d39ab  push rdx
00007e1ec07d39ac  push rdi
00007e1ec07d39ad  push rsi
00007e1ec07d39ae  push r8
00007e1ec07d39b0  push r9
00007e1ec07d39b2  push r10
00007e1ec07d39b4  push r11
00007e1ec07d39b6  sub rsp, 0xF0
00007e1ec07d39bd  vmovaps [rsp], xmm0
00007e1ec07d39c2  vmovaps [rsp+0x10], xmm1
00007e1ec07d39c8  vmovaps [rsp+0x20], xmm2
00007e1ec07d39ce  vmovaps [rsp+0x30], xmm3
00007e1ec07d39d4  vmovaps [rsp+0x40], xmm4
00007e1ec07d39da  vmovaps [rsp+0x50], xmm5
00007e1ec07d39e0  vmovaps [rsp+0x60], xmm6
00007e1ec07d39e6  vmovaps [rsp+0x70], xmm7
00007e1ec07d39ec  vmovaps [rsp+0x80], xmm8
00007e1ec07d39f5  vmovaps [rsp+0x90], xmm9
00007e1ec07d39fe  vmovaps [rsp+0xA0], xmm10
00007e1ec07d3a07  vmovaps [rsp+0xB0], xmm11
00007e1ec07d3a10  vmovaps [rsp+0xC0], xmm12
00007e1ec07d3a19  vmovaps [rsp+0xD0], xmm13
00007e1ec07d3a22  vmovaps [rsp+0xE0], xmm15
00007e1ec07d3a2b  sub rsp, 0x30
00007e1ec07d3a2f  movaps [rsp], xmm14
00007e1ec07d3a34  movaps [rsp+0x10], xmm1
00007e1ec07d3a39  movaps [rsp+0x20], xmm15
00007e1ec07d3a3f  lea rdi, [rsp]
00007e1ec07d3a43  mov esi, 0x00
00007e1ec07d3a48  mov rax, 0x5E00FF778530
00007e1ec07d3a52  call rax
00007e1ec07d3a54  movaps xmm14, [rsp]
00007e1ec07d3a59  add rsp, 0x30
00007e1ec07d3a5d  vmovaps xmm0, [rsp]
00007e1ec07d3a62  vmovaps xmm1, [rsp+0x10]
00007e1ec07d3a68  vmovaps xmm2, [rsp+0x20]
00007e1ec07d3a6e  vmovaps xmm3, [rsp+0x30]
00007e1ec07d3a74  vmovaps xmm4, [rsp+0x40]
00007e1ec07d3a7a  vmovaps xmm5, [rsp+0x50]
00007e1ec07d3a80  vmovaps xmm6, [rsp+0x60]
00007e1ec07d3a86  vmovaps xmm7, [rsp+0x70]
00007e1ec07d3a8c  vmovaps xmm8, [rsp+0x80]
00007e1ec07d3a95  vmovaps xmm9, [rsp+0x90]
00007e1ec07d3a9e  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d3aa7  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d3ab0  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d3ab9  vmovaps xmm13, [rsp+0xD0]
00007e1ec07d3ac2  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d3acb  add rsp, 0xF0
00007e1ec07d3ad2  pop r11
00007e1ec07d3ad4  pop r10
00007e1ec07d3ad6  pop r9
00007e1ec07d3ad8  pop r8
00007e1ec07d3ada  pop rsi
00007e1ec07d3adb  pop rdi
00007e1ec07d3adc  pop rdx
00007e1ec07d3add  pop rcx
00007e1ec07d3ade  pop rax
00007e1ec07d3adf  add rsp, 0x08
00007e1ec07d3ae3  jmp 0x00007E1EC07D2800
00007e1ec07d3ae8  sub rsp, 0x08
00007e1ec07d3aec  push rax
00007e1ec07d3aed  push rcx
00007e1ec07d3aee  push rdx
00007e1ec07d3aef  push rdi
00007e1ec07d3af0  push rsi
00007e1ec07d3af1  push r8
00007e1ec07d3af3  push r9
00007e1ec07d3af5  push r10
00007e1ec07d3af7  push r11
00007e1ec07d3af9  sub rsp, 0xF0
00007e1ec07d3b00  vmovaps [rsp], xmm0
00007e1ec07d3b05  vmovaps [rsp+0x10], xmm1
00007e1ec07d3b0b  vmovaps [rsp+0x20], xmm2
00007e1ec07d3b11  vmovaps [rsp+0x30], xmm3
00007e1ec07d3b17  vmovaps [rsp+0x40], xmm4
00007e1ec07d3b1d  vmovaps [rsp+0x50], xmm5
00007e1ec07d3b23  vmovaps [rsp+0x60], xmm6
00007e1ec07d3b29  vmovaps [rsp+0x70], xmm7
00007e1ec07d3b2f  vmovaps [rsp+0x80], xmm8
00007e1ec07d3b38  vmovaps [rsp+0x90], xmm9
00007e1ec07d3b41  vmovaps [rsp+0xA0], xmm10
00007e1ec07d3b4a  vmovaps [rsp+0xB0], xmm11
00007e1ec07d3b53  vmovaps [rsp+0xC0], xmm12
00007e1ec07d3b5c  vmovaps [rsp+0xD0], xmm13
00007e1ec07d3b65  vmovaps [rsp+0xE0], xmm14
00007e1ec07d3b6e  sub rsp, 0x30
00007e1ec07d3b72  movaps [rsp], xmm15
00007e1ec07d3b77  movaps [rsp+0x10], xmm12
00007e1ec07d3b7d  movaps [rsp+0x20], xmm13
00007e1ec07d3b83  lea rdi, [rsp]
00007e1ec07d3b87  mov esi, 0x00
00007e1ec07d3b8c  mov rax, 0x5E00FF778530
00007e1ec07d3b96  call rax
00007e1ec07d3b98  movaps xmm15, [rsp]
00007e1ec07d3b9d  add rsp, 0x30
00007e1ec07d3ba1  vmovaps xmm0, [rsp]
00007e1ec07d3ba6  vmovaps xmm1, [rsp+0x10]
00007e1ec07d3bac  vmovaps xmm2, [rsp+0x20]
00007e1ec07d3bb2  vmovaps xmm3, [rsp+0x30]
00007e1ec07d3bb8  vmovaps xmm4, [rsp+0x40]
00007e1ec07d3bbe  vmovaps xmm5, [rsp+0x50]
00007e1ec07d3bc4  vmovaps xmm6, [rsp+0x60]
00007e1ec07d3bca  vmovaps xmm7, [rsp+0x70]
00007e1ec07d3bd0  vmovaps xmm8, [rsp+0x80]
00007e1ec07d3bd9  vmovaps xmm9, [rsp+0x90]
00007e1ec07d3be2  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d3beb  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d3bf4  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d3bfd  vmovaps xmm13, [rsp+0xD0]
00007e1ec07d3c06  vmovaps xmm14, [rsp+0xE0]
00007e1ec07d3c0f  add rsp, 0xF0
00007e1ec07d3c16  pop r11
00007e1ec07d3c18  pop r10
00007e1ec07d3c1a  pop r9
00007e1ec07d3c1c  pop r8
00007e1ec07d3c1e  pop rsi
00007e1ec07d3c1f  pop rdi
00007e1ec07d3c20  pop rdx
00007e1ec07d3c21  pop rcx
00007e1ec07d3c22  pop rax
00007e1ec07d3c23  add rsp, 0x08
00007e1ec07d3c27  jmp 0x00007E1EC07D2835
00007e1ec07d3c2c  sub rsp, 0x08
00007e1ec07d3c30  push rax
00007e1ec07d3c31  push rcx
00007e1ec07d3c32  push rdx
00007e1ec07d3c33  push rdi
00007e1ec07d3c34  push rsi
00007e1ec07d3c35  push r8
00007e1ec07d3c37  push r9
00007e1ec07d3c39  push r10
00007e1ec07d3c3b  push r11
00007e1ec07d3c3d  sub rsp, 0xF0
00007e1ec07d3c44  vmovaps [rsp], xmm0
00007e1ec07d3c49  vmovaps [rsp+0x10], xmm2
00007e1ec07d3c4f  vmovaps [rsp+0x20], xmm3
00007e1ec07d3c55  vmovaps [rsp+0x30], xmm4
00007e1ec07d3c5b  vmovaps [rsp+0x40], xmm5
00007e1ec07d3c61  vmovaps [rsp+0x50], xmm6
00007e1ec07d3c67  vmovaps [rsp+0x60], xmm7
00007e1ec07d3c6d  vmovaps [rsp+0x70], xmm8
00007e1ec07d3c73  vmovaps [rsp+0x80], xmm9
00007e1ec07d3c7c  vmovaps [rsp+0x90], xmm10
00007e1ec07d3c85  vmovaps [rsp+0xA0], xmm11
00007e1ec07d3c8e  vmovaps [rsp+0xB0], xmm12
00007e1ec07d3c97  vmovaps [rsp+0xC0], xmm13
00007e1ec07d3ca0  vmovaps [rsp+0xD0], xmm14
00007e1ec07d3ca9  vmovaps [rsp+0xE0], xmm15
00007e1ec07d3cb2  sub rsp, 0x30
00007e1ec07d3cb6  movaps [rsp], xmm1
00007e1ec07d3cba  movaps [rsp+0x10], xmm12
00007e1ec07d3cc0  movaps [rsp+0x20], xmm10
00007e1ec07d3cc6  lea rdi, [rsp]
00007e1ec07d3cca  mov esi, 0x00
00007e1ec07d3ccf  mov rax, 0x5E00FF778530
00007e1ec07d3cd9  call rax
00007e1ec07d3cdb  movaps xmm1, [rsp]
00007e1ec07d3cdf  add rsp, 0x30
00007e1ec07d3ce3  vmovaps xmm0, [rsp]
00007e1ec07d3ce8  vmovaps xmm2, [rsp+0x10]
00007e1ec07d3cee  vmovaps xmm3, [rsp+0x20]
00007e1ec07d3cf4  vmovaps xmm4, [rsp+0x30]
00007e1ec07d3cfa  vmovaps xmm5, [rsp+0x40]
00007e1ec07d3d00  vmovaps xmm6, [rsp+0x50]
00007e1ec07d3d06  vmovaps xmm7, [rsp+0x60]
00007e1ec07d3d0c  vmovaps xmm8, [rsp+0x70]
00007e1ec07d3d12  vmovaps xmm9, [rsp+0x80]
00007e1ec07d3d1b  vmovaps xmm10, [rsp+0x90]
00007e1ec07d3d24  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d3d2d  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d3d36  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d3d3f  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d3d48  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d3d51  add rsp, 0xF0
00007e1ec07d3d58  pop r11
00007e1ec07d3d5a  pop r10
00007e1ec07d3d5c  pop r9
00007e1ec07d3d5e  pop r8
00007e1ec07d3d60  pop rsi
00007e1ec07d3d61  pop rdi
00007e1ec07d3d62  pop rdx
00007e1ec07d3d63  pop rcx
00007e1ec07d3d64  pop rax
00007e1ec07d3d65  add rsp, 0x08
00007e1ec07d3d69  jmp 0x00007E1EC07D284F
00007e1ec07d3d6e  sub rsp, 0x08
00007e1ec07d3d72  push rax
00007e1ec07d3d73  push rcx
00007e1ec07d3d74  push rdx
00007e1ec07d3d75  push rdi
00007e1ec07d3d76  push rsi
00007e1ec07d3d77  push r8
00007e1ec07d3d79  push r9
00007e1ec07d3d7b  push r10
00007e1ec07d3d7d  push r11
00007e1ec07d3d7f  sub rsp, 0xF0
00007e1ec07d3d86  vmovaps [rsp], xmm0
00007e1ec07d3d8b  vmovaps [rsp+0x10], xmm1
00007e1ec07d3d91  vmovaps [rsp+0x20], xmm2
00007e1ec07d3d97  vmovaps [rsp+0x30], xmm3
00007e1ec07d3d9d  vmovaps [rsp+0x40], xmm4
00007e1ec07d3da3  vmovaps [rsp+0x50], xmm5
00007e1ec07d3da9  vmovaps [rsp+0x60], xmm6
00007e1ec07d3daf  vmovaps [rsp+0x70], xmm7
00007e1ec07d3db5  vmovaps [rsp+0x80], xmm8
00007e1ec07d3dbe  vmovaps [rsp+0x90], xmm9
00007e1ec07d3dc7  vmovaps [rsp+0xA0], xmm10
00007e1ec07d3dd0  vmovaps [rsp+0xB0], xmm11
00007e1ec07d3dd9  vmovaps [rsp+0xC0], xmm12
00007e1ec07d3de2  vmovaps [rsp+0xD0], xmm14
00007e1ec07d3deb  vmovaps [rsp+0xE0], xmm15
00007e1ec07d3df4  sub rsp, 0x30
00007e1ec07d3df8  movaps [rsp], xmm13
00007e1ec07d3dfd  movaps [rsp+0x10], xmm12
00007e1ec07d3e03  movaps [rsp+0x20], xmm2
00007e1ec07d3e08  lea rdi, [rsp]
00007e1ec07d3e0c  mov esi, 0x00
00007e1ec07d3e11  mov rax, 0x5E00FF778530
00007e1ec07d3e1b  call rax
00007e1ec07d3e1d  movaps xmm13, [rsp]
00007e1ec07d3e22  add rsp, 0x30
00007e1ec07d3e26  vmovaps xmm0, [rsp]
00007e1ec07d3e2b  vmovaps xmm1, [rsp+0x10]
00007e1ec07d3e31  vmovaps xmm2, [rsp+0x20]
00007e1ec07d3e37  vmovaps xmm3, [rsp+0x30]
00007e1ec07d3e3d  vmovaps xmm4, [rsp+0x40]
00007e1ec07d3e43  vmovaps xmm5, [rsp+0x50]
00007e1ec07d3e49  vmovaps xmm6, [rsp+0x60]
00007e1ec07d3e4f  vmovaps xmm7, [rsp+0x70]
00007e1ec07d3e55  vmovaps xmm8, [rsp+0x80]
00007e1ec07d3e5e  vmovaps xmm9, [rsp+0x90]
00007e1ec07d3e67  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d3e70  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d3e79  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d3e82  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d3e8b  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d3e94  add rsp, 0xF0
00007e1ec07d3e9b  pop r11
00007e1ec07d3e9d  pop r10
00007e1ec07d3e9f  pop r9
00007e1ec07d3ea1  pop r8
00007e1ec07d3ea3  pop rsi
00007e1ec07d3ea4  pop rdi
00007e1ec07d3ea5  pop rdx
00007e1ec07d3ea6  pop rcx
00007e1ec07d3ea7  pop rax
00007e1ec07d3ea8  add rsp, 0x08
00007e1ec07d3eac  jmp 0x00007E1EC07D286A
00007e1ec07d3eb1  sub rsp, 0x08
00007e1ec07d3eb5  push rax
00007e1ec07d3eb6  push rcx
00007e1ec07d3eb7  push rdx
00007e1ec07d3eb8  push rdi
00007e1ec07d3eb9  push rsi
00007e1ec07d3eba  push r8
00007e1ec07d3ebc  push r9
00007e1ec07d3ebe  push r10
00007e1ec07d3ec0  push r11
00007e1ec07d3ec2  sub rsp, 0xF0
00007e1ec07d3ec9  vmovaps [rsp], xmm0
00007e1ec07d3ece  vmovaps [rsp+0x10], xmm2
00007e1ec07d3ed4  vmovaps [rsp+0x20], xmm3
00007e1ec07d3eda  vmovaps [rsp+0x30], xmm4
00007e1ec07d3ee0  vmovaps [rsp+0x40], xmm5
00007e1ec07d3ee6  vmovaps [rsp+0x50], xmm6
00007e1ec07d3eec  vmovaps [rsp+0x60], xmm7
00007e1ec07d3ef2  vmovaps [rsp+0x70], xmm8
00007e1ec07d3ef8  vmovaps [rsp+0x80], xmm9
00007e1ec07d3f01  vmovaps [rsp+0x90], xmm10
00007e1ec07d3f0a  vmovaps [rsp+0xA0], xmm11
00007e1ec07d3f13  vmovaps [rsp+0xB0], xmm12
00007e1ec07d3f1c  vmovaps [rsp+0xC0], xmm13
00007e1ec07d3f25  vmovaps [rsp+0xD0], xmm14
00007e1ec07d3f2e  vmovaps [rsp+0xE0], xmm15
00007e1ec07d3f37  sub rsp, 0x30
00007e1ec07d3f3b  movaps [rsp], xmm1
00007e1ec07d3f3f  movaps [rsp+0x10], xmm10
00007e1ec07d3f45  movaps [rsp+0x20], xmm2
00007e1ec07d3f4a  lea rdi, [rsp]
00007e1ec07d3f4e  mov esi, 0x00
00007e1ec07d3f53  mov rax, 0x5E00FF778530
00007e1ec07d3f5d  call rax
00007e1ec07d3f5f  movaps xmm1, [rsp]
00007e1ec07d3f63  add rsp, 0x30
00007e1ec07d3f67  vmovaps xmm0, [rsp]
00007e1ec07d3f6c  vmovaps xmm2, [rsp+0x10]
00007e1ec07d3f72  vmovaps xmm3, [rsp+0x20]
00007e1ec07d3f78  vmovaps xmm4, [rsp+0x30]
00007e1ec07d3f7e  vmovaps xmm5, [rsp+0x40]
00007e1ec07d3f84  vmovaps xmm6, [rsp+0x50]
00007e1ec07d3f8a  vmovaps xmm7, [rsp+0x60]
00007e1ec07d3f90  vmovaps xmm8, [rsp+0x70]
00007e1ec07d3f96  vmovaps xmm9, [rsp+0x80]
00007e1ec07d3f9f  vmovaps xmm10, [rsp+0x90]
00007e1ec07d3fa8  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d3fb1  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d3fba  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d3fc3  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d3fcc  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d3fd5  add rsp, 0xF0
00007e1ec07d3fdc  pop r11
00007e1ec07d3fde  pop r10
00007e1ec07d3fe0  pop r9
00007e1ec07d3fe2  pop r8
00007e1ec07d3fe4  pop rsi
00007e1ec07d3fe5  pop rdi
00007e1ec07d3fe6  pop rdx
00007e1ec07d3fe7  pop rcx
00007e1ec07d3fe8  pop rax
00007e1ec07d3fe9  add rsp, 0x08
00007e1ec07d3fed  jmp 0x00007E1EC07D28D2
00007e1ec07d3ff2  sub rsp, 0x08
00007e1ec07d3ff6  push rax
00007e1ec07d3ff7  push rcx
00007e1ec07d3ff8  push rdx
00007e1ec07d3ff9  push rdi
00007e1ec07d3ffa  push rsi
00007e1ec07d3ffb  push r8
00007e1ec07d3ffd  push r9
00007e1ec07d3fff  push r10
00007e1ec07d4001  push r11
00007e1ec07d4003  sub rsp, 0xF0
00007e1ec07d400a  vmovaps [rsp], xmm0
00007e1ec07d400f  vmovaps [rsp+0x10], xmm1
00007e1ec07d4015  vmovaps [rsp+0x20], xmm2
00007e1ec07d401b  vmovaps [rsp+0x30], xmm3
00007e1ec07d4021  vmovaps [rsp+0x40], xmm4
00007e1ec07d4027  vmovaps [rsp+0x50], xmm5
00007e1ec07d402d  vmovaps [rsp+0x60], xmm6
00007e1ec07d4033  vmovaps [rsp+0x70], xmm7
00007e1ec07d4039  vmovaps [rsp+0x80], xmm8
00007e1ec07d4042  vmovaps [rsp+0x90], xmm9
00007e1ec07d404b  vmovaps [rsp+0xA0], xmm10
00007e1ec07d4054  vmovaps [rsp+0xB0], xmm11
00007e1ec07d405d  vmovaps [rsp+0xC0], xmm12
00007e1ec07d4066  vmovaps [rsp+0xD0], xmm13
00007e1ec07d406f  vmovaps [rsp+0xE0], xmm14
00007e1ec07d4078  sub rsp, 0x30
00007e1ec07d407c  movaps [rsp], xmm15
00007e1ec07d4081  movaps [rsp+0x10], xmm10
00007e1ec07d4087  movaps [rsp+0x20], xmm2
00007e1ec07d408c  lea rdi, [rsp]
00007e1ec07d4090  mov esi, 0x00
00007e1ec07d4095  mov rax, 0x5E00FF778530
00007e1ec07d409f  call rax
00007e1ec07d40a1  movaps xmm15, [rsp]
00007e1ec07d40a6  add rsp, 0x30
00007e1ec07d40aa  vmovaps xmm0, [rsp]
00007e1ec07d40af  vmovaps xmm1, [rsp+0x10]
00007e1ec07d40b5  vmovaps xmm2, [rsp+0x20]
00007e1ec07d40bb  vmovaps xmm3, [rsp+0x30]
00007e1ec07d40c1  vmovaps xmm4, [rsp+0x40]
00007e1ec07d40c7  vmovaps xmm5, [rsp+0x50]
00007e1ec07d40cd  vmovaps xmm6, [rsp+0x60]
00007e1ec07d40d3  vmovaps xmm7, [rsp+0x70]
00007e1ec07d40d9  vmovaps xmm8, [rsp+0x80]
00007e1ec07d40e2  vmovaps xmm9, [rsp+0x90]
00007e1ec07d40eb  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d40f4  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d40fd  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d4106  vmovaps xmm13, [rsp+0xD0]
00007e1ec07d410f  vmovaps xmm14, [rsp+0xE0]
00007e1ec07d4118  add rsp, 0xF0
00007e1ec07d411f  pop r11
00007e1ec07d4121  pop r10
00007e1ec07d4123  pop r9
00007e1ec07d4125  pop r8
00007e1ec07d4127  pop rsi
00007e1ec07d4128  pop rdi
00007e1ec07d4129  pop rdx
00007e1ec07d412a  pop rcx
00007e1ec07d412b  pop rax
00007e1ec07d412c  add rsp, 0x08
00007e1ec07d4130  jmp 0x00007E1EC07D2924
00007e1ec07d4135  sub rsp, 0x08
00007e1ec07d4139  push rax
00007e1ec07d413a  push rcx
00007e1ec07d413b  push rdx
00007e1ec07d413c  push rdi
00007e1ec07d413d  push rsi
00007e1ec07d413e  push r8
00007e1ec07d4140  push r9
00007e1ec07d4142  push r10
00007e1ec07d4144  push r11
00007e1ec07d4146  sub rsp, 0xF0
00007e1ec07d414d  vmovaps [rsp], xmm0
00007e1ec07d4152  vmovaps [rsp+0x10], xmm2
00007e1ec07d4158  vmovaps [rsp+0x20], xmm3
00007e1ec07d415e  vmovaps [rsp+0x30], xmm4
00007e1ec07d4164  vmovaps [rsp+0x40], xmm5
00007e1ec07d416a  vmovaps [rsp+0x50], xmm6
00007e1ec07d4170  vmovaps [rsp+0x60], xmm7
00007e1ec07d4176  vmovaps [rsp+0x70], xmm8
00007e1ec07d417c  vmovaps [rsp+0x80], xmm9
00007e1ec07d4185  vmovaps [rsp+0x90], xmm10
00007e1ec07d418e  vmovaps [rsp+0xA0], xmm11
00007e1ec07d4197  vmovaps [rsp+0xB0], xmm12
00007e1ec07d41a0  vmovaps [rsp+0xC0], xmm13
00007e1ec07d41a9  vmovaps [rsp+0xD0], xmm14
00007e1ec07d41b2  vmovaps [rsp+0xE0], xmm15
00007e1ec07d41bb  sub rsp, 0x30
00007e1ec07d41bf  movaps [rsp], xmm1
00007e1ec07d41c3  movaps [rsp+0x10], xmm10
00007e1ec07d41c9  movaps [rsp+0x20], xmm15
00007e1ec07d41cf  lea rdi, [rsp]
00007e1ec07d41d3  mov esi, 0x00
00007e1ec07d41d8  mov rax, 0x5E00FF778530
00007e1ec07d41e2  call rax
00007e1ec07d41e4  movaps xmm1, [rsp]
00007e1ec07d41e8  add rsp, 0x30
00007e1ec07d41ec  vmovaps xmm0, [rsp]
00007e1ec07d41f1  vmovaps xmm2, [rsp+0x10]
00007e1ec07d41f7  vmovaps xmm3, [rsp+0x20]
00007e1ec07d41fd  vmovaps xmm4, [rsp+0x30]
00007e1ec07d4203  vmovaps xmm5, [rsp+0x40]
00007e1ec07d4209  vmovaps xmm6, [rsp+0x50]
00007e1ec07d420f  vmovaps xmm7, [rsp+0x60]
00007e1ec07d4215  vmovaps xmm8, [rsp+0x70]
00007e1ec07d421b  vmovaps xmm9, [rsp+0x80]
00007e1ec07d4224  vmovaps xmm10, [rsp+0x90]
00007e1ec07d422d  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d4236  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d423f  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d4248  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d4251  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d425a  add rsp, 0xF0
00007e1ec07d4261  pop r11
00007e1ec07d4263  pop r10
00007e1ec07d4265  pop r9
00007e1ec07d4267  pop r8
00007e1ec07d4269  pop rsi
00007e1ec07d426a  pop rdi
00007e1ec07d426b  pop rdx
00007e1ec07d426c  pop rcx
00007e1ec07d426d  pop rax
00007e1ec07d426e  add rsp, 0x08
00007e1ec07d4272  jmp 0x00007E1EC07D2962
00007e1ec07d4277  sub rsp, 0x08
00007e1ec07d427b  push rax
00007e1ec07d427c  push rcx
00007e1ec07d427d  push rdx
00007e1ec07d427e  push rdi
00007e1ec07d427f  push rsi
00007e1ec07d4280  push r8
00007e1ec07d4282  push r9
00007e1ec07d4284  push r10
00007e1ec07d4286  push r11
00007e1ec07d4288  sub rsp, 0xF0
00007e1ec07d428f  vmovaps [rsp], xmm0
00007e1ec07d4294  vmovaps [rsp+0x10], xmm1
00007e1ec07d429a  vmovaps [rsp+0x20], xmm2
00007e1ec07d42a0  vmovaps [rsp+0x30], xmm3
00007e1ec07d42a6  vmovaps [rsp+0x40], xmm4
00007e1ec07d42ac  vmovaps [rsp+0x50], xmm5
00007e1ec07d42b2  vmovaps [rsp+0x60], xmm6
00007e1ec07d42b8  vmovaps [rsp+0x70], xmm7
00007e1ec07d42be  vmovaps [rsp+0x80], xmm8
00007e1ec07d42c7  vmovaps [rsp+0x90], xmm9
00007e1ec07d42d0  vmovaps [rsp+0xA0], xmm10
00007e1ec07d42d9  vmovaps [rsp+0xB0], xmm11
00007e1ec07d42e2  vmovaps [rsp+0xC0], xmm12
00007e1ec07d42eb  vmovaps [rsp+0xD0], xmm13
00007e1ec07d42f4  vmovaps [rsp+0xE0], xmm15
00007e1ec07d42fd  sub rsp, 0x30
00007e1ec07d4301  movaps [rsp], xmm14
00007e1ec07d4306  movaps [rsp+0x10], xmm10
00007e1ec07d430c  movaps [rsp+0x20], xmm15
00007e1ec07d4312  lea rdi, [rsp]
00007e1ec07d4316  mov esi, 0x00
00007e1ec07d431b  mov rax, 0x5E00FF778530
00007e1ec07d4325  call rax
00007e1ec07d4327  movaps xmm14, [rsp]
00007e1ec07d432c  add rsp, 0x30
00007e1ec07d4330  vmovaps xmm0, [rsp]
00007e1ec07d4335  vmovaps xmm1, [rsp+0x10]
00007e1ec07d433b  vmovaps xmm2, [rsp+0x20]
00007e1ec07d4341  vmovaps xmm3, [rsp+0x30]
00007e1ec07d4347  vmovaps xmm4, [rsp+0x40]
00007e1ec07d434d  vmovaps xmm5, [rsp+0x50]
00007e1ec07d4353  vmovaps xmm6, [rsp+0x60]
00007e1ec07d4359  vmovaps xmm7, [rsp+0x70]
00007e1ec07d435f  vmovaps xmm8, [rsp+0x80]
00007e1ec07d4368  vmovaps xmm9, [rsp+0x90]
00007e1ec07d4371  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d437a  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d4383  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d438c  vmovaps xmm13, [rsp+0xD0]
00007e1ec07d4395  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d439e  add rsp, 0xF0
00007e1ec07d43a5  pop r11
00007e1ec07d43a7  pop r10
00007e1ec07d43a9  pop r9
00007e1ec07d43ab  pop r8
00007e1ec07d43ad  pop rsi
00007e1ec07d43ae  pop rdi
00007e1ec07d43af  pop rdx
00007e1ec07d43b0  pop rcx
00007e1ec07d43b1  pop rax
00007e1ec07d43b2  add rsp, 0x08
00007e1ec07d43b6  jmp 0x00007E1EC07D298E
00007e1ec07d43bb  call 0x00007E1EC05FF430
00007e1ec07d43c0  jmp 0x00007E1EC07D2A1E
00007e1ec07d43c5  call 0x00007E1EC05FF430
00007e1ec07d43ca  jmp 0x00007E1EC07D2A31
00007e1ec07d43cf  sub rsp, 0x08
00007e1ec07d43d3  push rax
00007e1ec07d43d4  push rcx
00007e1ec07d43d5  push rdx
00007e1ec07d43d6  push rdi
00007e1ec07d43d7  push rsi
00007e1ec07d43d8  push r8
00007e1ec07d43da  push r9
00007e1ec07d43dc  push r10
00007e1ec07d43de  push r11
00007e1ec07d43e0  sub rsp, 0xF0
00007e1ec07d43e7  vmovaps [rsp], xmm0
00007e1ec07d43ec  vmovaps [rsp+0x10], xmm2
00007e1ec07d43f2  vmovaps [rsp+0x20], xmm3
00007e1ec07d43f8  vmovaps [rsp+0x30], xmm4
00007e1ec07d43fe  vmovaps [rsp+0x40], xmm5
00007e1ec07d4404  vmovaps [rsp+0x50], xmm6
00007e1ec07d440a  vmovaps [rsp+0x60], xmm7
00007e1ec07d4410  vmovaps [rsp+0x70], xmm8
00007e1ec07d4416  vmovaps [rsp+0x80], xmm9
00007e1ec07d441f  vmovaps [rsp+0x90], xmm10
00007e1ec07d4428  vmovaps [rsp+0xA0], xmm11
00007e1ec07d4431  vmovaps [rsp+0xB0], xmm12
00007e1ec07d443a  vmovaps [rsp+0xC0], xmm13
00007e1ec07d4443  vmovaps [rsp+0xD0], xmm14
00007e1ec07d444c  vmovaps [rsp+0xE0], xmm15
00007e1ec07d4455  sub rsp, 0x30
00007e1ec07d4459  movaps [rsp], xmm1
00007e1ec07d445d  movaps [rsp+0x10], xmm13
00007e1ec07d4463  movaps [rsp+0x20], xmm2
00007e1ec07d4468  lea rdi, [rsp]
00007e1ec07d446c  mov esi, 0x00
00007e1ec07d4471  mov rax, 0x5E00FF778530
00007e1ec07d447b  call rax
00007e1ec07d447d  movaps xmm1, [rsp]
00007e1ec07d4481  add rsp, 0x30
00007e1ec07d4485  vmovaps xmm0, [rsp]
00007e1ec07d448a  vmovaps xmm2, [rsp+0x10]
00007e1ec07d4490  vmovaps xmm3, [rsp+0x20]
00007e1ec07d4496  vmovaps xmm4, [rsp+0x30]
00007e1ec07d449c  vmovaps xmm5, [rsp+0x40]
00007e1ec07d44a2  vmovaps xmm6, [rsp+0x50]
00007e1ec07d44a8  vmovaps xmm7, [rsp+0x60]
00007e1ec07d44ae  vmovaps xmm8, [rsp+0x70]
00007e1ec07d44b4  vmovaps xmm9, [rsp+0x80]
00007e1ec07d44bd  vmovaps xmm10, [rsp+0x90]
00007e1ec07d44c6  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d44cf  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d44d8  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d44e1  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d44ea  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d44f3  add rsp, 0xF0
00007e1ec07d44fa  pop r11
00007e1ec07d44fc  pop r10
00007e1ec07d44fe  pop r9
00007e1ec07d4500  pop r8
00007e1ec07d4502  pop rsi
00007e1ec07d4503  pop rdi
00007e1ec07d4504  pop rdx
00007e1ec07d4505  pop rcx
00007e1ec07d4506  pop rax
00007e1ec07d4507  add rsp, 0x08
00007e1ec07d450b  jmp 0x00007E1EC07D2A5C
00007e1ec07d4510  call 0x00007E1EC060E760
00007e1ec07d4515  jmp 0x00007E1EC07D2A69
00007e1ec07d451a  sub rsp, 0x08
00007e1ec07d451e  push rax
00007e1ec07d451f  push rcx
00007e1ec07d4520  push rdx
00007e1ec07d4521  push rdi
00007e1ec07d4522  push rsi
00007e1ec07d4523  push r8
00007e1ec07d4525  push r9
00007e1ec07d4527  push r10
00007e1ec07d4529  push r11
00007e1ec07d452b  sub rsp, 0xF0
00007e1ec07d4532  vmovaps [rsp], xmm0
00007e1ec07d4537  vmovaps [rsp+0x10], xmm1
00007e1ec07d453d  vmovaps [rsp+0x20], xmm2
00007e1ec07d4543  vmovaps [rsp+0x30], xmm3
00007e1ec07d4549  vmovaps [rsp+0x40], xmm4
00007e1ec07d454f  vmovaps [rsp+0x50], xmm5
00007e1ec07d4555  vmovaps [rsp+0x60], xmm6
00007e1ec07d455b  vmovaps [rsp+0x70], xmm7
00007e1ec07d4561  vmovaps [rsp+0x80], xmm8
00007e1ec07d456a  vmovaps [rsp+0x90], xmm9
00007e1ec07d4573  vmovaps [rsp+0xA0], xmm10
00007e1ec07d457c  vmovaps [rsp+0xB0], xmm11
00007e1ec07d4585  vmovaps [rsp+0xC0], xmm12
00007e1ec07d458e  vmovaps [rsp+0xD0], xmm14
00007e1ec07d4597  vmovaps [rsp+0xE0], xmm15
00007e1ec07d45a0  sub rsp, 0x30
00007e1ec07d45a4  movaps [rsp], xmm13
00007e1ec07d45a9  movaps [rsp+0x10], xmm2
00007e1ec07d45ae  movaps [rsp+0x20], xmm1
00007e1ec07d45b3  lea rdi, [rsp]
00007e1ec07d45b7  mov esi, 0x00
00007e1ec07d45bc  mov rax, 0x5E00FF778530
00007e1ec07d45c6  call rax
00007e1ec07d45c8  movaps xmm13, [rsp]
00007e1ec07d45cd  add rsp, 0x30
00007e1ec07d45d1  vmovaps xmm0, [rsp]
00007e1ec07d45d6  vmovaps xmm1, [rsp+0x10]
00007e1ec07d45dc  vmovaps xmm2, [rsp+0x20]
00007e1ec07d45e2  vmovaps xmm3, [rsp+0x30]
00007e1ec07d45e8  vmovaps xmm4, [rsp+0x40]
00007e1ec07d45ee  vmovaps xmm5, [rsp+0x50]
00007e1ec07d45f4  vmovaps xmm6, [rsp+0x60]
00007e1ec07d45fa  vmovaps xmm7, [rsp+0x70]
00007e1ec07d4600  vmovaps xmm8, [rsp+0x80]
00007e1ec07d4609  vmovaps xmm9, [rsp+0x90]
00007e1ec07d4612  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d461b  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d4624  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d462d  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d4636  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d463f  add rsp, 0xF0
00007e1ec07d4646  pop r11
00007e1ec07d4648  pop r10
00007e1ec07d464a  pop r9
00007e1ec07d464c  pop r8
00007e1ec07d464e  pop rsi
00007e1ec07d464f  pop rdi
00007e1ec07d4650  pop rdx
00007e1ec07d4651  pop rcx
00007e1ec07d4652  pop rax
00007e1ec07d4653  add rsp, 0x08
00007e1ec07d4657  jmp 0x00007E1EC07D2AA8
00007e1ec07d465c  sub rsp, 0x08
00007e1ec07d4660  push rax
00007e1ec07d4661  push rcx
00007e1ec07d4662  push rdx
00007e1ec07d4663  push rdi
00007e1ec07d4664  push rsi
00007e1ec07d4665  push r8
00007e1ec07d4667  push r9
00007e1ec07d4669  push r10
00007e1ec07d466b  push r11
00007e1ec07d466d  sub rsp, 0xF0
00007e1ec07d4674  vmovaps [rsp], xmm0
00007e1ec07d4679  vmovaps [rsp+0x10], xmm2
00007e1ec07d467f  vmovaps [rsp+0x20], xmm3
00007e1ec07d4685  vmovaps [rsp+0x30], xmm4
00007e1ec07d468b  vmovaps [rsp+0x40], xmm5
00007e1ec07d4691  vmovaps [rsp+0x50], xmm6
00007e1ec07d4697  vmovaps [rsp+0x60], xmm7
00007e1ec07d469d  vmovaps [rsp+0x70], xmm8
00007e1ec07d46a3  vmovaps [rsp+0x80], xmm9
00007e1ec07d46ac  vmovaps [rsp+0x90], xmm10
00007e1ec07d46b5  vmovaps [rsp+0xA0], xmm11
00007e1ec07d46be  vmovaps [rsp+0xB0], xmm12
00007e1ec07d46c7  vmovaps [rsp+0xC0], xmm13
00007e1ec07d46d0  vmovaps [rsp+0xD0], xmm14
00007e1ec07d46d9  vmovaps [rsp+0xE0], xmm15
00007e1ec07d46e2  sub rsp, 0x30
00007e1ec07d46e6  movaps [rsp], xmm1
00007e1ec07d46ea  movaps [rsp+0x10], xmm14
00007e1ec07d46f0  movaps [rsp+0x20], xmm15
00007e1ec07d46f6  lea rdi, [rsp]
00007e1ec07d46fa  mov esi, 0x00
00007e1ec07d46ff  mov rax, 0x5E00FF778530
00007e1ec07d4709  call rax
00007e1ec07d470b  movaps xmm1, [rsp]
00007e1ec07d470f  add rsp, 0x30
00007e1ec07d4713  vmovaps xmm0, [rsp]
00007e1ec07d4718  vmovaps xmm2, [rsp+0x10]
00007e1ec07d471e  vmovaps xmm3, [rsp+0x20]
00007e1ec07d4724  vmovaps xmm4, [rsp+0x30]
00007e1ec07d472a  vmovaps xmm5, [rsp+0x40]
00007e1ec07d4730  vmovaps xmm6, [rsp+0x50]
00007e1ec07d4736  vmovaps xmm7, [rsp+0x60]
00007e1ec07d473c  vmovaps xmm8, [rsp+0x70]
00007e1ec07d4742  vmovaps xmm9, [rsp+0x80]
00007e1ec07d474b  vmovaps xmm10, [rsp+0x90]
00007e1ec07d4754  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d475d  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d4766  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d476f  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d4778  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d4781  add rsp, 0xF0
00007e1ec07d4788  pop r11
00007e1ec07d478a  pop r10
00007e1ec07d478c  pop r9
00007e1ec07d478e  pop r8
00007e1ec07d4790  pop rsi
00007e1ec07d4791  pop rdi
00007e1ec07d4792  pop rdx
00007e1ec07d4793  pop rcx
00007e1ec07d4794  pop rax
00007e1ec07d4795  add rsp, 0x08
00007e1ec07d4799  jmp 0x00007E1EC07D2ACA
00007e1ec07d479e  sub rsp, 0x08
00007e1ec07d47a2  push rax
00007e1ec07d47a3  push rcx
00007e1ec07d47a4  push rdx
00007e1ec07d47a5  push rdi
00007e1ec07d47a6  push rsi
00007e1ec07d47a7  push r8
00007e1ec07d47a9  push r9
00007e1ec07d47ab  push r10
00007e1ec07d47ad  push r11
00007e1ec07d47af  sub rsp, 0xF0
00007e1ec07d47b6  vmovaps [rsp], xmm0
00007e1ec07d47bb  vmovaps [rsp+0x10], xmm1
00007e1ec07d47c1  vmovaps [rsp+0x20], xmm2
00007e1ec07d47c7  vmovaps [rsp+0x30], xmm3
00007e1ec07d47cd  vmovaps [rsp+0x40], xmm4
00007e1ec07d47d3  vmovaps [rsp+0x50], xmm5
00007e1ec07d47d9  vmovaps [rsp+0x60], xmm6
00007e1ec07d47df  vmovaps [rsp+0x70], xmm7
00007e1ec07d47e5  vmovaps [rsp+0x80], xmm8
00007e1ec07d47ee  vmovaps [rsp+0x90], xmm9
00007e1ec07d47f7  vmovaps [rsp+0xA0], xmm10
00007e1ec07d4800  vmovaps [rsp+0xB0], xmm11
00007e1ec07d4809  vmovaps [rsp+0xC0], xmm12
00007e1ec07d4812  vmovaps [rsp+0xD0], xmm13
00007e1ec07d481b  vmovaps [rsp+0xE0], xmm15
00007e1ec07d4824  sub rsp, 0x30
00007e1ec07d4828  movaps [rsp], xmm14
00007e1ec07d482d  movaps [rsp+0x10], xmm2
00007e1ec07d4832  movaps [rsp+0x20], xmm15
00007e1ec07d4838  lea rdi, [rsp]
00007e1ec07d483c  mov esi, 0x00
00007e1ec07d4841  mov rax, 0x5E00FF778530
00007e1ec07d484b  call rax
00007e1ec07d484d  movaps xmm14, [rsp]
00007e1ec07d4852  add rsp, 0x30
00007e1ec07d4856  vmovaps xmm0, [rsp]
00007e1ec07d485b  vmovaps xmm1, [rsp+0x10]
00007e1ec07d4861  vmovaps xmm2, [rsp+0x20]
00007e1ec07d4867  vmovaps xmm3, [rsp+0x30]
00007e1ec07d486d  vmovaps xmm4, [rsp+0x40]
00007e1ec07d4873  vmovaps xmm5, [rsp+0x50]
00007e1ec07d4879  vmovaps xmm6, [rsp+0x60]
00007e1ec07d487f  vmovaps xmm7, [rsp+0x70]
00007e1ec07d4885  vmovaps xmm8, [rsp+0x80]
00007e1ec07d488e  vmovaps xmm9, [rsp+0x90]
00007e1ec07d4897  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d48a0  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d48a9  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d48b2  vmovaps xmm13, [rsp+0xD0]
00007e1ec07d48bb  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d48c4  add rsp, 0xF0
00007e1ec07d48cb  pop r11
00007e1ec07d48cd  pop r10
00007e1ec07d48cf  pop r9
00007e1ec07d48d1  pop r8
00007e1ec07d48d3  pop rsi
00007e1ec07d48d4  pop rdi
00007e1ec07d48d5  pop rdx
00007e1ec07d48d6  pop rcx
00007e1ec07d48d7  pop rax
00007e1ec07d48d8  add rsp, 0x08
00007e1ec07d48dc  jmp 0x00007E1EC07D2B05
00007e1ec07d48e1  sub rsp, 0x08
00007e1ec07d48e5  push rax
00007e1ec07d48e6  push rcx
00007e1ec07d48e7  push rdx
00007e1ec07d48e8  push rdi
00007e1ec07d48e9  push rsi
00007e1ec07d48ea  push r8
00007e1ec07d48ec  push r9
00007e1ec07d48ee  push r10
00007e1ec07d48f0  push r11
00007e1ec07d48f2  sub rsp, 0xF0
00007e1ec07d48f9  vmovaps [rsp], xmm0
00007e1ec07d48fe  vmovaps [rsp+0x10], xmm1
00007e1ec07d4904  vmovaps [rsp+0x20], xmm2
00007e1ec07d490a  vmovaps [rsp+0x30], xmm3
00007e1ec07d4910  vmovaps [rsp+0x40], xmm4
00007e1ec07d4916  vmovaps [rsp+0x50], xmm5
00007e1ec07d491c  vmovaps [rsp+0x60], xmm6
00007e1ec07d4922  vmovaps [rsp+0x70], xmm7
00007e1ec07d4928  vmovaps [rsp+0x80], xmm8
00007e1ec07d4931  vmovaps [rsp+0x90], xmm9
00007e1ec07d493a  vmovaps [rsp+0xA0], xmm10
00007e1ec07d4943  vmovaps [rsp+0xB0], xmm11
00007e1ec07d494c  vmovaps [rsp+0xC0], xmm12
00007e1ec07d4955  vmovaps [rsp+0xD0], xmm13
00007e1ec07d495e  vmovaps [rsp+0xE0], xmm14
00007e1ec07d4967  sub rsp, 0x30
00007e1ec07d496b  movaps [rsp], xmm15
00007e1ec07d4970  movaps [rsp+0x10], xmm2
00007e1ec07d4975  movaps [rsp+0x20], xmm1
00007e1ec07d497a  lea rdi, [rsp]
00007e1ec07d497e  mov esi, 0x00
00007e1ec07d4983  mov rax, 0x5E00FF778530
00007e1ec07d498d  call rax
00007e1ec07d498f  movaps xmm15, [rsp]
00007e1ec07d4994  add rsp, 0x30
00007e1ec07d4998  vmovaps xmm0, [rsp]
00007e1ec07d499d  vmovaps xmm1, [rsp+0x10]
00007e1ec07d49a3  vmovaps xmm2, [rsp+0x20]
00007e1ec07d49a9  vmovaps xmm3, [rsp+0x30]
00007e1ec07d49af  vmovaps xmm4, [rsp+0x40]
00007e1ec07d49b5  vmovaps xmm5, [rsp+0x50]
00007e1ec07d49bb  vmovaps xmm6, [rsp+0x60]
00007e1ec07d49c1  vmovaps xmm7, [rsp+0x70]
00007e1ec07d49c7  vmovaps xmm8, [rsp+0x80]
00007e1ec07d49d0  vmovaps xmm9, [rsp+0x90]
00007e1ec07d49d9  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d49e2  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d49eb  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d49f4  vmovaps xmm13, [rsp+0xD0]
00007e1ec07d49fd  vmovaps xmm14, [rsp+0xE0]
00007e1ec07d4a06  add rsp, 0xF0
00007e1ec07d4a0d  pop r11
00007e1ec07d4a0f  pop r10
00007e1ec07d4a11  pop r9
00007e1ec07d4a13  pop r8
00007e1ec07d4a15  pop rsi
00007e1ec07d4a16  pop rdi
00007e1ec07d4a17  pop rdx
00007e1ec07d4a18  pop rcx
00007e1ec07d4a19  pop rax
00007e1ec07d4a1a  add rsp, 0x08
00007e1ec07d4a1e  jmp 0x00007E1EC07D2B41
00007e1ec07d4a23  call 0x00007E1EC05FF430
00007e1ec07d4a28  jmp 0x00007E1EC07D2B4E
00007e1ec07d4a2d  sub rsp, 0x08
00007e1ec07d4a31  push rax
00007e1ec07d4a32  push rcx
00007e1ec07d4a33  push rdx
00007e1ec07d4a34  push rdi
00007e1ec07d4a35  push rsi
00007e1ec07d4a36  push r8
00007e1ec07d4a38  push r9
00007e1ec07d4a3a  push r10
00007e1ec07d4a3c  push r11
00007e1ec07d4a3e  sub rsp, 0xF0
00007e1ec07d4a45  vmovaps [rsp], xmm0
00007e1ec07d4a4a  vmovaps [rsp+0x10], xmm1
00007e1ec07d4a50  vmovaps [rsp+0x20], xmm3
00007e1ec07d4a56  vmovaps [rsp+0x30], xmm4
00007e1ec07d4a5c  vmovaps [rsp+0x40], xmm5
00007e1ec07d4a62  vmovaps [rsp+0x50], xmm6
00007e1ec07d4a68  vmovaps [rsp+0x60], xmm7
00007e1ec07d4a6e  vmovaps [rsp+0x70], xmm8
00007e1ec07d4a74  vmovaps [rsp+0x80], xmm9
00007e1ec07d4a7d  vmovaps [rsp+0x90], xmm10
00007e1ec07d4a86  vmovaps [rsp+0xA0], xmm11
00007e1ec07d4a8f  vmovaps [rsp+0xB0], xmm12
00007e1ec07d4a98  vmovaps [rsp+0xC0], xmm13
00007e1ec07d4aa1  vmovaps [rsp+0xD0], xmm14
00007e1ec07d4aaa  vmovaps [rsp+0xE0], xmm15
00007e1ec07d4ab3  sub rsp, 0x30
00007e1ec07d4ab7  movaps [rsp], xmm2
00007e1ec07d4abb  movaps [rsp+0x10], xmm1
00007e1ec07d4ac0  movaps [rsp+0x20], xmm14
00007e1ec07d4ac6  lea rdi, [rsp]
00007e1ec07d4aca  mov esi, 0x00
00007e1ec07d4acf  mov rax, 0x5E00FF778530
00007e1ec07d4ad9  call rax
00007e1ec07d4adb  movaps xmm2, [rsp]
00007e1ec07d4adf  add rsp, 0x30
00007e1ec07d4ae3  vmovaps xmm0, [rsp]
00007e1ec07d4ae8  vmovaps xmm1, [rsp+0x10]
00007e1ec07d4aee  vmovaps xmm3, [rsp+0x20]
00007e1ec07d4af4  vmovaps xmm4, [rsp+0x30]
00007e1ec07d4afa  vmovaps xmm5, [rsp+0x40]
00007e1ec07d4b00  vmovaps xmm6, [rsp+0x50]
00007e1ec07d4b06  vmovaps xmm7, [rsp+0x60]
00007e1ec07d4b0c  vmovaps xmm8, [rsp+0x70]
00007e1ec07d4b12  vmovaps xmm9, [rsp+0x80]
00007e1ec07d4b1b  vmovaps xmm10, [rsp+0x90]
00007e1ec07d4b24  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d4b2d  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d4b36  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d4b3f  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d4b48  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d4b51  add rsp, 0xF0
00007e1ec07d4b58  pop r11
00007e1ec07d4b5a  pop r10
00007e1ec07d4b5c  pop r9
00007e1ec07d4b5e  pop r8
00007e1ec07d4b60  pop rsi
00007e1ec07d4b61  pop rdi
00007e1ec07d4b62  pop rdx
00007e1ec07d4b63  pop rcx
00007e1ec07d4b64  pop rax
00007e1ec07d4b65  add rsp, 0x08
00007e1ec07d4b69  jmp 0x00007E1EC07D2B8B
00007e1ec07d4b6e  sub rsp, 0x08
00007e1ec07d4b72  push rax
00007e1ec07d4b73  push rcx
00007e1ec07d4b74  push rdx
00007e1ec07d4b75  push rdi
00007e1ec07d4b76  push rsi
00007e1ec07d4b77  push r8
00007e1ec07d4b79  push r9
00007e1ec07d4b7b  push r10
00007e1ec07d4b7d  push r11
00007e1ec07d4b7f  sub rsp, 0xF0
00007e1ec07d4b86  vmovaps [rsp], xmm0
00007e1ec07d4b8b  vmovaps [rsp+0x10], xmm1
00007e1ec07d4b91  vmovaps [rsp+0x20], xmm2
00007e1ec07d4b97  vmovaps [rsp+0x30], xmm3
00007e1ec07d4b9d  vmovaps [rsp+0x40], xmm4
00007e1ec07d4ba3  vmovaps [rsp+0x50], xmm5
00007e1ec07d4ba9  vmovaps [rsp+0x60], xmm6
00007e1ec07d4baf  vmovaps [rsp+0x70], xmm7
00007e1ec07d4bb5  vmovaps [rsp+0x80], xmm8
00007e1ec07d4bbe  vmovaps [rsp+0x90], xmm9
00007e1ec07d4bc7  vmovaps [rsp+0xA0], xmm10
00007e1ec07d4bd0  vmovaps [rsp+0xB0], xmm11
00007e1ec07d4bd9  vmovaps [rsp+0xC0], xmm12
00007e1ec07d4be2  vmovaps [rsp+0xD0], xmm13
00007e1ec07d4beb  vmovaps [rsp+0xE0], xmm14
00007e1ec07d4bf4  sub rsp, 0x30
00007e1ec07d4bf8  movaps [rsp], xmm15
00007e1ec07d4bfd  movaps [rsp+0x10], xmm14
00007e1ec07d4c03  movaps [rsp+0x20], xmm1
00007e1ec07d4c08  lea rdi, [rsp]
00007e1ec07d4c0c  mov esi, 0x00
00007e1ec07d4c11  mov rax, 0x5E00FF778530
00007e1ec07d4c1b  call rax
00007e1ec07d4c1d  movaps xmm15, [rsp]
00007e1ec07d4c22  add rsp, 0x30
00007e1ec07d4c26  vmovaps xmm0, [rsp]
00007e1ec07d4c2b  vmovaps xmm1, [rsp+0x10]
00007e1ec07d4c31  vmovaps xmm2, [rsp+0x20]
00007e1ec07d4c37  vmovaps xmm3, [rsp+0x30]
00007e1ec07d4c3d  vmovaps xmm4, [rsp+0x40]
00007e1ec07d4c43  vmovaps xmm5, [rsp+0x50]
00007e1ec07d4c49  vmovaps xmm6, [rsp+0x60]
00007e1ec07d4c4f  vmovaps xmm7, [rsp+0x70]
00007e1ec07d4c55  vmovaps xmm8, [rsp+0x80]
00007e1ec07d4c5e  vmovaps xmm9, [rsp+0x90]
00007e1ec07d4c67  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d4c70  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d4c79  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d4c82  vmovaps xmm13, [rsp+0xD0]
00007e1ec07d4c8b  vmovaps xmm14, [rsp+0xE0]
00007e1ec07d4c94  add rsp, 0xF0
00007e1ec07d4c9b  pop r11
00007e1ec07d4c9d  pop r10
00007e1ec07d4c9f  pop r9
00007e1ec07d4ca1  pop r8
00007e1ec07d4ca3  pop rsi
00007e1ec07d4ca4  pop rdi
00007e1ec07d4ca5  pop rdx
00007e1ec07d4ca6  pop rcx
00007e1ec07d4ca7  pop rax
00007e1ec07d4ca8  add rsp, 0x08
00007e1ec07d4cac  jmp 0x00007E1EC07D2C05
00007e1ec07d4cb1  call 0x00007E1EC05FF430
00007e1ec07d4cb6  jmp 0x00007E1EC07D2C12
00007e1ec07d4cbb  sub rsp, 0x08
00007e1ec07d4cbf  push rax
00007e1ec07d4cc0  push rcx
00007e1ec07d4cc1  push rdx
00007e1ec07d4cc2  push rdi
00007e1ec07d4cc3  push rsi
00007e1ec07d4cc4  push r8
00007e1ec07d4cc6  push r9
00007e1ec07d4cc8  push r10
00007e1ec07d4cca  push r11
00007e1ec07d4ccc  sub rsp, 0xF0
00007e1ec07d4cd3  vmovaps [rsp], xmm0
00007e1ec07d4cd8  vmovaps [rsp+0x10], xmm1
00007e1ec07d4cde  vmovaps [rsp+0x20], xmm2
00007e1ec07d4ce4  vmovaps [rsp+0x30], xmm3
00007e1ec07d4cea  vmovaps [rsp+0x40], xmm4
00007e1ec07d4cf0  vmovaps [rsp+0x50], xmm5
00007e1ec07d4cf6  vmovaps [rsp+0x60], xmm6
00007e1ec07d4cfc  vmovaps [rsp+0x70], xmm7
00007e1ec07d4d02  vmovaps [rsp+0x80], xmm8
00007e1ec07d4d0b  vmovaps [rsp+0x90], xmm9
00007e1ec07d4d14  vmovaps [rsp+0xA0], xmm10
00007e1ec07d4d1d  vmovaps [rsp+0xB0], xmm11
00007e1ec07d4d26  vmovaps [rsp+0xC0], xmm12
00007e1ec07d4d2f  vmovaps [rsp+0xD0], xmm14
00007e1ec07d4d38  vmovaps [rsp+0xE0], xmm15
00007e1ec07d4d41  sub rsp, 0x30
00007e1ec07d4d45  movaps [rsp], xmm13
00007e1ec07d4d4a  movaps [rsp+0x10], xmm1
00007e1ec07d4d4f  movaps [rsp+0x20], xmm15
00007e1ec07d4d55  lea rdi, [rsp]
00007e1ec07d4d59  mov esi, 0x00
00007e1ec07d4d5e  mov rax, 0x5E00FF778530
00007e1ec07d4d68  call rax
00007e1ec07d4d6a  movaps xmm13, [rsp]
00007e1ec07d4d6f  add rsp, 0x30
00007e1ec07d4d73  vmovaps xmm0, [rsp]
00007e1ec07d4d78  vmovaps xmm1, [rsp+0x10]
00007e1ec07d4d7e  vmovaps xmm2, [rsp+0x20]
00007e1ec07d4d84  vmovaps xmm3, [rsp+0x30]
00007e1ec07d4d8a  vmovaps xmm4, [rsp+0x40]
00007e1ec07d4d90  vmovaps xmm5, [rsp+0x50]
00007e1ec07d4d96  vmovaps xmm6, [rsp+0x60]
00007e1ec07d4d9c  vmovaps xmm7, [rsp+0x70]
00007e1ec07d4da2  vmovaps xmm8, [rsp+0x80]
00007e1ec07d4dab  vmovaps xmm9, [rsp+0x90]
00007e1ec07d4db4  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d4dbd  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d4dc6  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d4dcf  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d4dd8  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d4de1  add rsp, 0xF0
00007e1ec07d4de8  pop r11
00007e1ec07d4dea  pop r10
00007e1ec07d4dec  pop r9
00007e1ec07d4dee  pop r8
00007e1ec07d4df0  pop rsi
00007e1ec07d4df1  pop rdi
00007e1ec07d4df2  pop rdx
00007e1ec07d4df3  pop rcx
00007e1ec07d4df4  pop rax
00007e1ec07d4df5  add rsp, 0x08
00007e1ec07d4df9  jmp 0x00007E1EC07D2CD6
00007e1ec07d4dfe  sub rsp, 0x08
00007e1ec07d4e02  push rax
00007e1ec07d4e03  push rcx
00007e1ec07d4e04  push rdx
00007e1ec07d4e05  push rdi
00007e1ec07d4e06  push rsi
00007e1ec07d4e07  push r8
00007e1ec07d4e09  push r9
00007e1ec07d4e0b  push r10
00007e1ec07d4e0d  push r11
00007e1ec07d4e0f  sub rsp, 0xF0
00007e1ec07d4e16  vmovaps [rsp], xmm0
00007e1ec07d4e1b  vmovaps [rsp+0x10], xmm1
00007e1ec07d4e21  vmovaps [rsp+0x20], xmm2
00007e1ec07d4e27  vmovaps [rsp+0x30], xmm3
00007e1ec07d4e2d  vmovaps [rsp+0x40], xmm4
00007e1ec07d4e33  vmovaps [rsp+0x50], xmm5
00007e1ec07d4e39  vmovaps [rsp+0x60], xmm6
00007e1ec07d4e3f  vmovaps [rsp+0x70], xmm7
00007e1ec07d4e45  vmovaps [rsp+0x80], xmm8
00007e1ec07d4e4e  vmovaps [rsp+0x90], xmm9
00007e1ec07d4e57  vmovaps [rsp+0xA0], xmm10
00007e1ec07d4e60  vmovaps [rsp+0xB0], xmm11
00007e1ec07d4e69  vmovaps [rsp+0xC0], xmm12
00007e1ec07d4e72  vmovaps [rsp+0xD0], xmm13
00007e1ec07d4e7b  vmovaps [rsp+0xE0], xmm14
00007e1ec07d4e84  sub rsp, 0x30
00007e1ec07d4e88  movaps [rsp], xmm15
00007e1ec07d4e8d  movaps [rsp+0x10], xmm14
00007e1ec07d4e93  movaps [rsp+0x20], xmm1
00007e1ec07d4e98  lea rdi, [rsp]
00007e1ec07d4e9c  mov esi, 0x00
00007e1ec07d4ea1  mov rax, 0x5E00FF778530
00007e1ec07d4eab  call rax
00007e1ec07d4ead  movaps xmm15, [rsp]
00007e1ec07d4eb2  add rsp, 0x30
00007e1ec07d4eb6  vmovaps xmm0, [rsp]
00007e1ec07d4ebb  vmovaps xmm1, [rsp+0x10]
00007e1ec07d4ec1  vmovaps xmm2, [rsp+0x20]
00007e1ec07d4ec7  vmovaps xmm3, [rsp+0x30]
00007e1ec07d4ecd  vmovaps xmm4, [rsp+0x40]
00007e1ec07d4ed3  vmovaps xmm5, [rsp+0x50]
00007e1ec07d4ed9  vmovaps xmm6, [rsp+0x60]
00007e1ec07d4edf  vmovaps xmm7, [rsp+0x70]
00007e1ec07d4ee5  vmovaps xmm8, [rsp+0x80]
00007e1ec07d4eee  vmovaps xmm9, [rsp+0x90]
00007e1ec07d4ef7  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d4f00  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d4f09  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d4f12  vmovaps xmm13, [rsp+0xD0]
00007e1ec07d4f1b  vmovaps xmm14, [rsp+0xE0]
00007e1ec07d4f24  add rsp, 0xF0
00007e1ec07d4f2b  pop r11
00007e1ec07d4f2d  pop r10
00007e1ec07d4f2f  pop r9
00007e1ec07d4f31  pop r8
00007e1ec07d4f33  pop rsi
00007e1ec07d4f34  pop rdi
00007e1ec07d4f35  pop rdx
00007e1ec07d4f36  pop rcx
00007e1ec07d4f37  pop rax
00007e1ec07d4f38  add rsp, 0x08
00007e1ec07d4f3c  jmp 0x00007E1EC07D2D12
00007e1ec07d4f41  call 0x00007E1EC05FF430
00007e1ec07d4f46  jmp 0x00007E1EC07D2D1F
00007e1ec07d4f4b  sub rsp, 0x08
00007e1ec07d4f4f  push rax
00007e1ec07d4f50  push rcx
00007e1ec07d4f51  push rdx
00007e1ec07d4f52  push rdi
00007e1ec07d4f53  push rsi
00007e1ec07d4f54  push r8
00007e1ec07d4f56  push r9
00007e1ec07d4f58  push r10
00007e1ec07d4f5a  push r11
00007e1ec07d4f5c  sub rsp, 0xF0
00007e1ec07d4f63  vmovaps [rsp], xmm0
00007e1ec07d4f68  vmovaps [rsp+0x10], xmm1
00007e1ec07d4f6e  vmovaps [rsp+0x20], xmm2
00007e1ec07d4f74  vmovaps [rsp+0x30], xmm3
00007e1ec07d4f7a  vmovaps [rsp+0x40], xmm4
00007e1ec07d4f80  vmovaps [rsp+0x50], xmm5
00007e1ec07d4f86  vmovaps [rsp+0x60], xmm6
00007e1ec07d4f8c  vmovaps [rsp+0x70], xmm7
00007e1ec07d4f92  vmovaps [rsp+0x80], xmm8
00007e1ec07d4f9b  vmovaps [rsp+0x90], xmm9
00007e1ec07d4fa4  vmovaps [rsp+0xA0], xmm10
00007e1ec07d4fad  vmovaps [rsp+0xB0], xmm11
00007e1ec07d4fb6  vmovaps [rsp+0xC0], xmm12
00007e1ec07d4fbf  vmovaps [rsp+0xD0], xmm13
00007e1ec07d4fc8  vmovaps [rsp+0xE0], xmm15
00007e1ec07d4fd1  sub rsp, 0x30
00007e1ec07d4fd5  movaps [rsp], xmm14
00007e1ec07d4fda  movaps [rsp+0x10], xmm13
00007e1ec07d4fe0  movaps [rsp+0x20], xmm2
00007e1ec07d4fe5  lea rdi, [rsp]
00007e1ec07d4fe9  mov esi, 0x00
00007e1ec07d4fee  mov rax, 0x5E00FF778530
00007e1ec07d4ff8  call rax
00007e1ec07d4ffa  movaps xmm14, [rsp]
00007e1ec07d4fff  add rsp, 0x30
00007e1ec07d5003  vmovaps xmm0, [rsp]
00007e1ec07d5008  vmovaps xmm1, [rsp+0x10]
00007e1ec07d500e  vmovaps xmm2, [rsp+0x20]
00007e1ec07d5014  vmovaps xmm3, [rsp+0x30]
00007e1ec07d501a  vmovaps xmm4, [rsp+0x40]
00007e1ec07d5020  vmovaps xmm5, [rsp+0x50]
00007e1ec07d5026  vmovaps xmm6, [rsp+0x60]
00007e1ec07d502c  vmovaps xmm7, [rsp+0x70]
00007e1ec07d5032  vmovaps xmm8, [rsp+0x80]
00007e1ec07d503b  vmovaps xmm9, [rsp+0x90]
00007e1ec07d5044  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d504d  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d5056  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d505f  vmovaps xmm13, [rsp+0xD0]
00007e1ec07d5068  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d5071  add rsp, 0xF0
00007e1ec07d5078  pop r11
00007e1ec07d507a  pop r10
00007e1ec07d507c  pop r9
00007e1ec07d507e  pop r8
00007e1ec07d5080  pop rsi
00007e1ec07d5081  pop rdi
00007e1ec07d5082  pop rdx
00007e1ec07d5083  pop rcx
00007e1ec07d5084  pop rax
00007e1ec07d5085  add rsp, 0x08
00007e1ec07d5089  jmp 0x00007E1EC07D2D4B
00007e1ec07d508e  sub rsp, 0x08
00007e1ec07d5092  push rax
00007e1ec07d5093  push rcx
00007e1ec07d5094  push rdx
00007e1ec07d5095  push rdi
00007e1ec07d5096  push rsi
00007e1ec07d5097  push r8
00007e1ec07d5099  push r9
00007e1ec07d509b  push r10
00007e1ec07d509d  push r11
00007e1ec07d509f  sub rsp, 0xF0
00007e1ec07d50a6  vmovaps [rsp], xmm0
00007e1ec07d50ab  vmovaps [rsp+0x10], xmm2
00007e1ec07d50b1  vmovaps [rsp+0x20], xmm3
00007e1ec07d50b7  vmovaps [rsp+0x30], xmm4
00007e1ec07d50bd  vmovaps [rsp+0x40], xmm5
00007e1ec07d50c3  vmovaps [rsp+0x50], xmm6
00007e1ec07d50c9  vmovaps [rsp+0x60], xmm7
00007e1ec07d50cf  vmovaps [rsp+0x70], xmm8
00007e1ec07d50d5  vmovaps [rsp+0x80], xmm9
00007e1ec07d50de  vmovaps [rsp+0x90], xmm10
00007e1ec07d50e7  vmovaps [rsp+0xA0], xmm11
00007e1ec07d50f0  vmovaps [rsp+0xB0], xmm12
00007e1ec07d50f9  vmovaps [rsp+0xC0], xmm13
00007e1ec07d5102  vmovaps [rsp+0xD0], xmm14
00007e1ec07d510b  vmovaps [rsp+0xE0], xmm15
00007e1ec07d5114  sub rsp, 0x30
00007e1ec07d5118  movaps [rsp], xmm1
00007e1ec07d511c  movaps [rsp+0x10], xmm13
00007e1ec07d5122  movaps [rsp+0x20], xmm2
00007e1ec07d5127  lea rdi, [rsp]
00007e1ec07d512b  mov esi, 0x00
00007e1ec07d5130  mov rax, 0x5E00FF778530
00007e1ec07d513a  call rax
00007e1ec07d513c  movaps xmm1, [rsp]
00007e1ec07d5140  add rsp, 0x30
00007e1ec07d5144  vmovaps xmm0, [rsp]
00007e1ec07d5149  vmovaps xmm2, [rsp+0x10]
00007e1ec07d514f  vmovaps xmm3, [rsp+0x20]
00007e1ec07d5155  vmovaps xmm4, [rsp+0x30]
00007e1ec07d515b  vmovaps xmm5, [rsp+0x40]
00007e1ec07d5161  vmovaps xmm6, [rsp+0x50]
00007e1ec07d5167  vmovaps xmm7, [rsp+0x60]
00007e1ec07d516d  vmovaps xmm8, [rsp+0x70]
00007e1ec07d5173  vmovaps xmm9, [rsp+0x80]
00007e1ec07d517c  vmovaps xmm10, [rsp+0x90]
00007e1ec07d5185  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d518e  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d5197  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d51a0  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d51a9  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d51b2  add rsp, 0xF0
00007e1ec07d51b9  pop r11
00007e1ec07d51bb  pop r10
00007e1ec07d51bd  pop r9
00007e1ec07d51bf  pop r8
00007e1ec07d51c1  pop rsi
00007e1ec07d51c2  pop rdi
00007e1ec07d51c3  pop rdx
00007e1ec07d51c4  pop rcx
00007e1ec07d51c5  pop rax
00007e1ec07d51c6  add rsp, 0x08
00007e1ec07d51ca  jmp 0x00007E1EC07D2D79
00007e1ec07d51cf  sub rsp, 0x08
00007e1ec07d51d3  push rax
00007e1ec07d51d4  push rcx
00007e1ec07d51d5  push rdx
00007e1ec07d51d6  push rdi
00007e1ec07d51d7  push rsi
00007e1ec07d51d8  push r8
00007e1ec07d51da  push r9
00007e1ec07d51dc  push r10
00007e1ec07d51de  push r11
00007e1ec07d51e0  sub rsp, 0xF0
00007e1ec07d51e7  vmovaps [rsp], xmm0
00007e1ec07d51ec  vmovaps [rsp+0x10], xmm1
00007e1ec07d51f2  vmovaps [rsp+0x20], xmm3
00007e1ec07d51f8  vmovaps [rsp+0x30], xmm4
00007e1ec07d51fe  vmovaps [rsp+0x40], xmm5
00007e1ec07d5204  vmovaps [rsp+0x50], xmm6
00007e1ec07d520a  vmovaps [rsp+0x60], xmm7
00007e1ec07d5210  vmovaps [rsp+0x70], xmm8
00007e1ec07d5216  vmovaps [rsp+0x80], xmm9
00007e1ec07d521f  vmovaps [rsp+0x90], xmm10
00007e1ec07d5228  vmovaps [rsp+0xA0], xmm11
00007e1ec07d5231  vmovaps [rsp+0xB0], xmm12
00007e1ec07d523a  vmovaps [rsp+0xC0], xmm13
00007e1ec07d5243  vmovaps [rsp+0xD0], xmm14
00007e1ec07d524c  vmovaps [rsp+0xE0], xmm15
00007e1ec07d5255  sub rsp, 0x30
00007e1ec07d5259  movaps [rsp], xmm2
00007e1ec07d525d  movaps [rsp+0x10], xmm1
00007e1ec07d5262  movaps [rsp+0x20], xmm13
00007e1ec07d5268  lea rdi, [rsp]
00007e1ec07d526c  mov esi, 0x00
00007e1ec07d5271  mov rax, 0x5E00FF778530
00007e1ec07d527b  call rax
00007e1ec07d527d  movaps xmm2, [rsp]
00007e1ec07d5281  add rsp, 0x30
00007e1ec07d5285  vmovaps xmm0, [rsp]
00007e1ec07d528a  vmovaps xmm1, [rsp+0x10]
00007e1ec07d5290  vmovaps xmm3, [rsp+0x20]
00007e1ec07d5296  vmovaps xmm4, [rsp+0x30]
00007e1ec07d529c  vmovaps xmm5, [rsp+0x40]
00007e1ec07d52a2  vmovaps xmm6, [rsp+0x50]
00007e1ec07d52a8  vmovaps xmm7, [rsp+0x60]
00007e1ec07d52ae  vmovaps xmm8, [rsp+0x70]
00007e1ec07d52b4  vmovaps xmm9, [rsp+0x80]
00007e1ec07d52bd  vmovaps xmm10, [rsp+0x90]
00007e1ec07d52c6  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d52cf  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d52d8  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d52e1  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d52ea  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d52f3  add rsp, 0xF0
00007e1ec07d52fa  pop r11
00007e1ec07d52fc  pop r10
00007e1ec07d52fe  pop r9
00007e1ec07d5300  pop r8
00007e1ec07d5302  pop rsi
00007e1ec07d5303  pop rdi
00007e1ec07d5304  pop rdx
00007e1ec07d5305  pop rcx
00007e1ec07d5306  pop rax
00007e1ec07d5307  add rsp, 0x08
00007e1ec07d530b  jmp 0x00007E1EC07D2DD2
00007e1ec07d5310  call 0x00007E1EC05FF430
00007e1ec07d5315  jmp 0x00007E1EC07D2DDF
00007e1ec07d531a  sub rsp, 0x08
00007e1ec07d531e  push rax
00007e1ec07d531f  push rcx
00007e1ec07d5320  push rdx
00007e1ec07d5321  push rdi
00007e1ec07d5322  push rsi
00007e1ec07d5323  push r8
00007e1ec07d5325  push r9
00007e1ec07d5327  push r10
00007e1ec07d5329  push r11
00007e1ec07d532b  sub rsp, 0xF0
00007e1ec07d5332  vmovaps [rsp], xmm0
00007e1ec07d5337  vmovaps [rsp+0x10], xmm1
00007e1ec07d533d  vmovaps [rsp+0x20], xmm2
00007e1ec07d5343  vmovaps [rsp+0x30], xmm3
00007e1ec07d5349  vmovaps [rsp+0x40], xmm4
00007e1ec07d534f  vmovaps [rsp+0x50], xmm5
00007e1ec07d5355  vmovaps [rsp+0x60], xmm6
00007e1ec07d535b  vmovaps [rsp+0x70], xmm7
00007e1ec07d5361  vmovaps [rsp+0x80], xmm8
00007e1ec07d536a  vmovaps [rsp+0x90], xmm9
00007e1ec07d5373  vmovaps [rsp+0xA0], xmm10
00007e1ec07d537c  vmovaps [rsp+0xB0], xmm11
00007e1ec07d5385  vmovaps [rsp+0xC0], xmm12
00007e1ec07d538e  vmovaps [rsp+0xD0], xmm13
00007e1ec07d5397  vmovaps [rsp+0xE0], xmm14
00007e1ec07d53a0  sub rsp, 0x30
00007e1ec07d53a4  movaps [rsp], xmm15
00007e1ec07d53a9  movaps [rsp+0x10], xmm13
00007e1ec07d53af  movaps [rsp+0x20], xmm1
00007e1ec07d53b4  lea rdi, [rsp]
00007e1ec07d53b8  mov esi, 0x00
00007e1ec07d53bd  mov rax, 0x5E00FF778530
00007e1ec07d53c7  call rax
00007e1ec07d53c9  movaps xmm15, [rsp]
00007e1ec07d53ce  add rsp, 0x30
00007e1ec07d53d2  vmovaps xmm0, [rsp]
00007e1ec07d53d7  vmovaps xmm1, [rsp+0x10]
00007e1ec07d53dd  vmovaps xmm2, [rsp+0x20]
00007e1ec07d53e3  vmovaps xmm3, [rsp+0x30]
00007e1ec07d53e9  vmovaps xmm4, [rsp+0x40]
00007e1ec07d53ef  vmovaps xmm5, [rsp+0x50]
00007e1ec07d53f5  vmovaps xmm6, [rsp+0x60]
00007e1ec07d53fb  vmovaps xmm7, [rsp+0x70]
00007e1ec07d5401  vmovaps xmm8, [rsp+0x80]
00007e1ec07d540a  vmovaps xmm9, [rsp+0x90]
00007e1ec07d5413  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d541c  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d5425  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d542e  vmovaps xmm13, [rsp+0xD0]
00007e1ec07d5437  vmovaps xmm14, [rsp+0xE0]
00007e1ec07d5440  add rsp, 0xF0
00007e1ec07d5447  pop r11
00007e1ec07d5449  pop r10
00007e1ec07d544b  pop r9
00007e1ec07d544d  pop r8
00007e1ec07d544f  pop rsi
00007e1ec07d5450  pop rdi
00007e1ec07d5451  pop rdx
00007e1ec07d5452  pop rcx
00007e1ec07d5453  pop rax
00007e1ec07d5454  add rsp, 0x08
00007e1ec07d5458  jmp 0x00007E1EC07D2E1E
00007e1ec07d545d  sub rsp, 0x08
00007e1ec07d5461  push rax
00007e1ec07d5462  push rcx
00007e1ec07d5463  push rdx
00007e1ec07d5464  push rdi
00007e1ec07d5465  push rsi
00007e1ec07d5466  push r8
00007e1ec07d5468  push r9
00007e1ec07d546a  push r10
00007e1ec07d546c  push r11
00007e1ec07d546e  sub rsp, 0xF0
00007e1ec07d5475  vmovaps [rsp], xmm0
00007e1ec07d547a  vmovaps [rsp+0x10], xmm1
00007e1ec07d5480  vmovaps [rsp+0x20], xmm2
00007e1ec07d5486  vmovaps [rsp+0x30], xmm3
00007e1ec07d548c  vmovaps [rsp+0x40], xmm4
00007e1ec07d5492  vmovaps [rsp+0x50], xmm5
00007e1ec07d5498  vmovaps [rsp+0x60], xmm6
00007e1ec07d549e  vmovaps [rsp+0x70], xmm7
00007e1ec07d54a4  vmovaps [rsp+0x80], xmm8
00007e1ec07d54ad  vmovaps [rsp+0x90], xmm9
00007e1ec07d54b6  vmovaps [rsp+0xA0], xmm10
00007e1ec07d54bf  vmovaps [rsp+0xB0], xmm11
00007e1ec07d54c8  vmovaps [rsp+0xC0], xmm12
00007e1ec07d54d1  vmovaps [rsp+0xD0], xmm13
00007e1ec07d54da  vmovaps [rsp+0xE0], xmm15
00007e1ec07d54e3  sub rsp, 0x30
00007e1ec07d54e7  movaps [rsp], xmm14
00007e1ec07d54ec  movaps [rsp+0x10], xmm11
00007e1ec07d54f2  movaps [rsp+0x20], xmm1
00007e1ec07d54f7  lea rdi, [rsp]
00007e1ec07d54fb  mov esi, 0x00
00007e1ec07d5500  mov rax, 0x5E00FF778530
00007e1ec07d550a  call rax
00007e1ec07d550c  movaps xmm14, [rsp]
00007e1ec07d5511  add rsp, 0x30
00007e1ec07d5515  vmovaps xmm0, [rsp]
00007e1ec07d551a  vmovaps xmm1, [rsp+0x10]
00007e1ec07d5520  vmovaps xmm2, [rsp+0x20]
00007e1ec07d5526  vmovaps xmm3, [rsp+0x30]
00007e1ec07d552c  vmovaps xmm4, [rsp+0x40]
00007e1ec07d5532  vmovaps xmm5, [rsp+0x50]
00007e1ec07d5538  vmovaps xmm6, [rsp+0x60]
00007e1ec07d553e  vmovaps xmm7, [rsp+0x70]
00007e1ec07d5544  vmovaps xmm8, [rsp+0x80]
00007e1ec07d554d  vmovaps xmm9, [rsp+0x90]
00007e1ec07d5556  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d555f  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d5568  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d5571  vmovaps xmm13, [rsp+0xD0]
00007e1ec07d557a  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d5583  add rsp, 0xF0
00007e1ec07d558a  pop r11
00007e1ec07d558c  pop r10
00007e1ec07d558e  pop r9
00007e1ec07d5590  pop r8
00007e1ec07d5592  pop rsi
00007e1ec07d5593  pop rdi
00007e1ec07d5594  pop rdx
00007e1ec07d5595  pop rcx
00007e1ec07d5596  pop rax
00007e1ec07d5597  add rsp, 0x08
00007e1ec07d559b  jmp 0x00007E1EC07D2E48
00007e1ec07d55a0  sub rsp, 0x08
00007e1ec07d55a4  push rax
00007e1ec07d55a5  push rcx
00007e1ec07d55a6  push rdx
00007e1ec07d55a7  push rdi
00007e1ec07d55a8  push rsi
00007e1ec07d55a9  push r8
00007e1ec07d55ab  push r9
00007e1ec07d55ad  push r10
00007e1ec07d55af  push r11
00007e1ec07d55b1  sub rsp, 0xF0
00007e1ec07d55b8  vmovaps [rsp], xmm0
00007e1ec07d55bd  vmovaps [rsp+0x10], xmm1
00007e1ec07d55c3  vmovaps [rsp+0x20], xmm2
00007e1ec07d55c9  vmovaps [rsp+0x30], xmm3
00007e1ec07d55cf  vmovaps [rsp+0x40], xmm4
00007e1ec07d55d5  vmovaps [rsp+0x50], xmm5
00007e1ec07d55db  vmovaps [rsp+0x60], xmm6
00007e1ec07d55e1  vmovaps [rsp+0x70], xmm7
00007e1ec07d55e7  vmovaps [rsp+0x80], xmm8
00007e1ec07d55f0  vmovaps [rsp+0x90], xmm9
00007e1ec07d55f9  vmovaps [rsp+0xA0], xmm10
00007e1ec07d5602  vmovaps [rsp+0xB0], xmm11
00007e1ec07d560b  vmovaps [rsp+0xC0], xmm12
00007e1ec07d5614  vmovaps [rsp+0xD0], xmm14
00007e1ec07d561d  vmovaps [rsp+0xE0], xmm15
00007e1ec07d5626  sub rsp, 0x30
00007e1ec07d562a  movaps [rsp], xmm13
00007e1ec07d562f  movaps [rsp+0x10], xmm11
00007e1ec07d5635  movaps [rsp+0x20], xmm1
00007e1ec07d563a  lea rdi, [rsp]
00007e1ec07d563e  mov esi, 0x00
00007e1ec07d5643  mov rax, 0x5E00FF778530
00007e1ec07d564d  call rax
00007e1ec07d564f  movaps xmm13, [rsp]
00007e1ec07d5654  add rsp, 0x30
00007e1ec07d5658  vmovaps xmm0, [rsp]
00007e1ec07d565d  vmovaps xmm1, [rsp+0x10]
00007e1ec07d5663  vmovaps xmm2, [rsp+0x20]
00007e1ec07d5669  vmovaps xmm3, [rsp+0x30]
00007e1ec07d566f  vmovaps xmm4, [rsp+0x40]
00007e1ec07d5675  vmovaps xmm5, [rsp+0x50]
00007e1ec07d567b  vmovaps xmm6, [rsp+0x60]
00007e1ec07d5681  vmovaps xmm7, [rsp+0x70]
00007e1ec07d5687  vmovaps xmm8, [rsp+0x80]
00007e1ec07d5690  vmovaps xmm9, [rsp+0x90]
00007e1ec07d5699  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d56a2  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d56ab  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d56b4  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d56bd  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d56c6  add rsp, 0xF0
00007e1ec07d56cd  pop r11
00007e1ec07d56cf  pop r10
00007e1ec07d56d1  pop r9
00007e1ec07d56d3  pop r8
00007e1ec07d56d5  pop rsi
00007e1ec07d56d6  pop rdi
00007e1ec07d56d7  pop rdx
00007e1ec07d56d8  pop rcx
00007e1ec07d56d9  pop rax
00007e1ec07d56da  add rsp, 0x08
00007e1ec07d56de  jmp 0x00007E1EC07D2E9D
00007e1ec07d56e3  call 0x00007E1EC05FF430
00007e1ec07d56e8  jmp 0x00007E1EC07D2EAA
00007e1ec07d56ed  sub rsp, 0x08
00007e1ec07d56f1  push rax
00007e1ec07d56f2  push rcx
00007e1ec07d56f3  push rdx
00007e1ec07d56f4  push rdi
00007e1ec07d56f5  push rsi
00007e1ec07d56f6  push r8
00007e1ec07d56f8  push r9
00007e1ec07d56fa  push r10
00007e1ec07d56fc  push r11
00007e1ec07d56fe  sub rsp, 0xF0
00007e1ec07d5705  vmovaps [rsp], xmm0
00007e1ec07d570a  vmovaps [rsp+0x10], xmm1
00007e1ec07d5710  vmovaps [rsp+0x20], xmm2
00007e1ec07d5716  vmovaps [rsp+0x30], xmm3
00007e1ec07d571c  vmovaps [rsp+0x40], xmm4
00007e1ec07d5722  vmovaps [rsp+0x50], xmm5
00007e1ec07d5728  vmovaps [rsp+0x60], xmm6
00007e1ec07d572e  vmovaps [rsp+0x70], xmm7
00007e1ec07d5734  vmovaps [rsp+0x80], xmm8
00007e1ec07d573d  vmovaps [rsp+0x90], xmm9
00007e1ec07d5746  vmovaps [rsp+0xA0], xmm10
00007e1ec07d574f  vmovaps [rsp+0xB0], xmm11
00007e1ec07d5758  vmovaps [rsp+0xC0], xmm12
00007e1ec07d5761  vmovaps [rsp+0xD0], xmm13
00007e1ec07d576a  vmovaps [rsp+0xE0], xmm14
00007e1ec07d5773  sub rsp, 0x30
00007e1ec07d5777  movaps [rsp], xmm15
00007e1ec07d577c  movaps [rsp+0x10], xmm11
00007e1ec07d5782  movaps [rsp+0x20], xmm1
00007e1ec07d5787  lea rdi, [rsp]
00007e1ec07d578b  mov esi, 0x00
00007e1ec07d5790  mov rax, 0x5E00FF778530
00007e1ec07d579a  call rax
00007e1ec07d579c  movaps xmm15, [rsp]
00007e1ec07d57a1  add rsp, 0x30
00007e1ec07d57a5  vmovaps xmm0, [rsp]
00007e1ec07d57aa  vmovaps xmm1, [rsp+0x10]
00007e1ec07d57b0  vmovaps xmm2, [rsp+0x20]
00007e1ec07d57b6  vmovaps xmm3, [rsp+0x30]
00007e1ec07d57bc  vmovaps xmm4, [rsp+0x40]
00007e1ec07d57c2  vmovaps xmm5, [rsp+0x50]
00007e1ec07d57c8  vmovaps xmm6, [rsp+0x60]
00007e1ec07d57ce  vmovaps xmm7, [rsp+0x70]
00007e1ec07d57d4  vmovaps xmm8, [rsp+0x80]
00007e1ec07d57dd  vmovaps xmm9, [rsp+0x90]
00007e1ec07d57e6  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d57ef  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d57f8  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d5801  vmovaps xmm13, [rsp+0xD0]
00007e1ec07d580a  vmovaps xmm14, [rsp+0xE0]
00007e1ec07d5813  add rsp, 0xF0
00007e1ec07d581a  pop r11
00007e1ec07d581c  pop r10
00007e1ec07d581e  pop r9
00007e1ec07d5820  pop r8
00007e1ec07d5822  pop rsi
00007e1ec07d5823  pop rdi
00007e1ec07d5824  pop rdx
00007e1ec07d5825  pop rcx
00007e1ec07d5826  pop rax
00007e1ec07d5827  add rsp, 0x08
00007e1ec07d582b  jmp 0x00007E1EC07D2EE3
00007e1ec07d5830  sub rsp, 0x08
00007e1ec07d5834  push rax
00007e1ec07d5835  push rcx
00007e1ec07d5836  push rdx
00007e1ec07d5837  push rdi
00007e1ec07d5838  push rsi
00007e1ec07d5839  push r8
00007e1ec07d583b  push r9
00007e1ec07d583d  push r10
00007e1ec07d583f  push r11
00007e1ec07d5841  sub rsp, 0xF0
00007e1ec07d5848  vmovaps [rsp], xmm0
00007e1ec07d584d  vmovaps [rsp+0x10], xmm1
00007e1ec07d5853  vmovaps [rsp+0x20], xmm2
00007e1ec07d5859  vmovaps [rsp+0x30], xmm3
00007e1ec07d585f  vmovaps [rsp+0x40], xmm4
00007e1ec07d5865  vmovaps [rsp+0x50], xmm5
00007e1ec07d586b  vmovaps [rsp+0x60], xmm6
00007e1ec07d5871  vmovaps [rsp+0x70], xmm7
00007e1ec07d5877  vmovaps [rsp+0x80], xmm8
00007e1ec07d5880  vmovaps [rsp+0x90], xmm9
00007e1ec07d5889  vmovaps [rsp+0xA0], xmm10
00007e1ec07d5892  vmovaps [rsp+0xB0], xmm12
00007e1ec07d589b  vmovaps [rsp+0xC0], xmm13
00007e1ec07d58a4  vmovaps [rsp+0xD0], xmm14
00007e1ec07d58ad  vmovaps [rsp+0xE0], xmm15
00007e1ec07d58b6  sub rsp, 0x30
00007e1ec07d58ba  movaps [rsp], xmm11
00007e1ec07d58bf  movaps [rsp+0x10], xmm6
00007e1ec07d58c4  movaps [rsp+0x20], xmm14
00007e1ec07d58ca  lea rdi, [rsp]
00007e1ec07d58ce  mov esi, 0x00
00007e1ec07d58d3  mov rax, 0x5E00FF778530
00007e1ec07d58dd  call rax
00007e1ec07d58df  movaps xmm11, [rsp]
00007e1ec07d58e4  add rsp, 0x30
00007e1ec07d58e8  vmovaps xmm0, [rsp]
00007e1ec07d58ed  vmovaps xmm1, [rsp+0x10]
00007e1ec07d58f3  vmovaps xmm2, [rsp+0x20]
00007e1ec07d58f9  vmovaps xmm3, [rsp+0x30]
00007e1ec07d58ff  vmovaps xmm4, [rsp+0x40]
00007e1ec07d5905  vmovaps xmm5, [rsp+0x50]
00007e1ec07d590b  vmovaps xmm6, [rsp+0x60]
00007e1ec07d5911  vmovaps xmm7, [rsp+0x70]
00007e1ec07d5917  vmovaps xmm8, [rsp+0x80]
00007e1ec07d5920  vmovaps xmm9, [rsp+0x90]
00007e1ec07d5929  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d5932  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d593b  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d5944  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d594d  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d5956  add rsp, 0xF0
00007e1ec07d595d  pop r11
00007e1ec07d595f  pop r10
00007e1ec07d5961  pop r9
00007e1ec07d5963  pop r8
00007e1ec07d5965  pop rsi
00007e1ec07d5966  pop rdi
00007e1ec07d5967  pop rdx
00007e1ec07d5968  pop rcx
00007e1ec07d5969  pop rax
00007e1ec07d596a  add rsp, 0x08
00007e1ec07d596e  jmp 0x00007E1EC07D2F5B
00007e1ec07d5973  call 0x00007E1EC05FF430
00007e1ec07d5978  jmp 0x00007E1EC07D2F65
00007e1ec07d597d  sub rsp, 0x08
00007e1ec07d5981  push rax
00007e1ec07d5982  push rcx
00007e1ec07d5983  push rdx
00007e1ec07d5984  push rdi
00007e1ec07d5985  push rsi
00007e1ec07d5986  push r8
00007e1ec07d5988  push r9
00007e1ec07d598a  push r10
00007e1ec07d598c  push r11
00007e1ec07d598e  sub rsp, 0xF0
00007e1ec07d5995  vmovaps [rsp], xmm0
00007e1ec07d599a  vmovaps [rsp+0x10], xmm1
00007e1ec07d59a0  vmovaps [rsp+0x20], xmm2
00007e1ec07d59a6  vmovaps [rsp+0x30], xmm3
00007e1ec07d59ac  vmovaps [rsp+0x40], xmm4
00007e1ec07d59b2  vmovaps [rsp+0x50], xmm5
00007e1ec07d59b8  vmovaps [rsp+0x60], xmm6
00007e1ec07d59be  vmovaps [rsp+0x70], xmm7
00007e1ec07d59c4  vmovaps [rsp+0x80], xmm8
00007e1ec07d59cd  vmovaps [rsp+0x90], xmm9
00007e1ec07d59d6  vmovaps [rsp+0xA0], xmm10
00007e1ec07d59df  vmovaps [rsp+0xB0], xmm11
00007e1ec07d59e8  vmovaps [rsp+0xC0], xmm12
00007e1ec07d59f1  vmovaps [rsp+0xD0], xmm13
00007e1ec07d59fa  vmovaps [rsp+0xE0], xmm15
00007e1ec07d5a03  sub rsp, 0x30
00007e1ec07d5a07  movaps [rsp], xmm14
00007e1ec07d5a0c  movaps [rsp+0x10], xmm6
00007e1ec07d5a11  movaps [rsp+0x20], xmm2
00007e1ec07d5a16  lea rdi, [rsp]
00007e1ec07d5a1a  mov esi, 0x00
00007e1ec07d5a1f  mov rax, 0x5E00FF778530
00007e1ec07d5a29  call rax
00007e1ec07d5a2b  movaps xmm14, [rsp]
00007e1ec07d5a30  add rsp, 0x30
00007e1ec07d5a34  vmovaps xmm0, [rsp]
00007e1ec07d5a39  vmovaps xmm1, [rsp+0x10]
00007e1ec07d5a3f  vmovaps xmm2, [rsp+0x20]
00007e1ec07d5a45  vmovaps xmm3, [rsp+0x30]
00007e1ec07d5a4b  vmovaps xmm4, [rsp+0x40]
00007e1ec07d5a51  vmovaps xmm5, [rsp+0x50]
00007e1ec07d5a57  vmovaps xmm6, [rsp+0x60]
00007e1ec07d5a5d  vmovaps xmm7, [rsp+0x70]
00007e1ec07d5a63  vmovaps xmm8, [rsp+0x80]
00007e1ec07d5a6c  vmovaps xmm9, [rsp+0x90]
00007e1ec07d5a75  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d5a7e  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d5a87  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d5a90  vmovaps xmm13, [rsp+0xD0]
00007e1ec07d5a99  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d5aa2  add rsp, 0xF0
00007e1ec07d5aa9  pop r11
00007e1ec07d5aab  pop r10
00007e1ec07d5aad  pop r9
00007e1ec07d5aaf  pop r8
00007e1ec07d5ab1  pop rsi
00007e1ec07d5ab2  pop rdi
00007e1ec07d5ab3  pop rdx
00007e1ec07d5ab4  pop rcx
00007e1ec07d5ab5  pop rax
00007e1ec07d5ab6  add rsp, 0x08
00007e1ec07d5aba  jmp 0x00007E1EC07D2F99
00007e1ec07d5abf  sub rsp, 0x08
00007e1ec07d5ac3  push rax
00007e1ec07d5ac4  push rcx
00007e1ec07d5ac5  push rdx
00007e1ec07d5ac6  push rdi
00007e1ec07d5ac7  push rsi
00007e1ec07d5ac8  push r8
00007e1ec07d5aca  push r9
00007e1ec07d5acc  push r10
00007e1ec07d5ace  push r11
00007e1ec07d5ad0  sub rsp, 0xF0
00007e1ec07d5ad7  vmovaps [rsp], xmm0
00007e1ec07d5adc  vmovaps [rsp+0x10], xmm1
00007e1ec07d5ae2  vmovaps [rsp+0x20], xmm2
00007e1ec07d5ae8  vmovaps [rsp+0x30], xmm3
00007e1ec07d5aee  vmovaps [rsp+0x40], xmm4
00007e1ec07d5af4  vmovaps [rsp+0x50], xmm5
00007e1ec07d5afa  vmovaps [rsp+0x60], xmm7
00007e1ec07d5b00  vmovaps [rsp+0x70], xmm8
00007e1ec07d5b06  vmovaps [rsp+0x80], xmm9
00007e1ec07d5b0f  vmovaps [rsp+0x90], xmm10
00007e1ec07d5b18  vmovaps [rsp+0xA0], xmm11
00007e1ec07d5b21  vmovaps [rsp+0xB0], xmm12
00007e1ec07d5b2a  vmovaps [rsp+0xC0], xmm13
00007e1ec07d5b33  vmovaps [rsp+0xD0], xmm14
00007e1ec07d5b3c  vmovaps [rsp+0xE0], xmm15
00007e1ec07d5b45  sub rsp, 0x30
00007e1ec07d5b49  movaps [rsp], xmm6
00007e1ec07d5b4d  movaps [rsp+0x10], xmm5
00007e1ec07d5b52  movaps [rsp+0x20], xmm1
00007e1ec07d5b57  lea rdi, [rsp]
00007e1ec07d5b5b  mov esi, 0x00
00007e1ec07d5b60  mov rax, 0x5E00FF778530
00007e1ec07d5b6a  call rax
00007e1ec07d5b6c  movaps xmm6, [rsp]
00007e1ec07d5b70  add rsp, 0x30
00007e1ec07d5b74  vmovaps xmm0, [rsp]
00007e1ec07d5b79  vmovaps xmm1, [rsp+0x10]
00007e1ec07d5b7f  vmovaps xmm2, [rsp+0x20]
00007e1ec07d5b85  vmovaps xmm3, [rsp+0x30]
00007e1ec07d5b8b  vmovaps xmm4, [rsp+0x40]
00007e1ec07d5b91  vmovaps xmm5, [rsp+0x50]
00007e1ec07d5b97  vmovaps xmm7, [rsp+0x60]
00007e1ec07d5b9d  vmovaps xmm8, [rsp+0x70]
00007e1ec07d5ba3  vmovaps xmm9, [rsp+0x80]
00007e1ec07d5bac  vmovaps xmm10, [rsp+0x90]
00007e1ec07d5bb5  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d5bbe  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d5bc7  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d5bd0  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d5bd9  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d5be2  add rsp, 0xF0
00007e1ec07d5be9  pop r11
00007e1ec07d5beb  pop r10
00007e1ec07d5bed  pop r9
00007e1ec07d5bef  pop r8
00007e1ec07d5bf1  pop rsi
00007e1ec07d5bf2  pop rdi
00007e1ec07d5bf3  pop rdx
00007e1ec07d5bf4  pop rcx
00007e1ec07d5bf5  pop rax
00007e1ec07d5bf6  add rsp, 0x08
00007e1ec07d5bfa  jmp 0x00007E1EC07D2FBF
00007e1ec07d5bff  sub rsp, 0x08
00007e1ec07d5c03  push rax
00007e1ec07d5c04  push rcx
00007e1ec07d5c05  push rdx
00007e1ec07d5c06  push rdi
00007e1ec07d5c07  push rsi
00007e1ec07d5c08  push r8
00007e1ec07d5c0a  push r9
00007e1ec07d5c0c  push r10
00007e1ec07d5c0e  push r11
00007e1ec07d5c10  sub rsp, 0xF0
00007e1ec07d5c17  vmovaps [rsp], xmm0
00007e1ec07d5c1c  vmovaps [rsp+0x10], xmm2
00007e1ec07d5c22  vmovaps [rsp+0x20], xmm3
00007e1ec07d5c28  vmovaps [rsp+0x30], xmm4
00007e1ec07d5c2e  vmovaps [rsp+0x40], xmm5
00007e1ec07d5c34  vmovaps [rsp+0x50], xmm6
00007e1ec07d5c3a  vmovaps [rsp+0x60], xmm7
00007e1ec07d5c40  vmovaps [rsp+0x70], xmm8
00007e1ec07d5c46  vmovaps [rsp+0x80], xmm9
00007e1ec07d5c4f  vmovaps [rsp+0x90], xmm10
00007e1ec07d5c58  vmovaps [rsp+0xA0], xmm11
00007e1ec07d5c61  vmovaps [rsp+0xB0], xmm12
00007e1ec07d5c6a  vmovaps [rsp+0xC0], xmm13
00007e1ec07d5c73  vmovaps [rsp+0xD0], xmm14
00007e1ec07d5c7c  vmovaps [rsp+0xE0], xmm15
00007e1ec07d5c85  sub rsp, 0x30
00007e1ec07d5c89  movaps [rsp], xmm1
00007e1ec07d5c8d  movaps [rsp+0x10], xmm5
00007e1ec07d5c92  movaps [rsp+0x20], xmm13
00007e1ec07d5c98  lea rdi, [rsp]
00007e1ec07d5c9c  mov esi, 0x00
00007e1ec07d5ca1  mov rax, 0x5E00FF778530
00007e1ec07d5cab  call rax
00007e1ec07d5cad  movaps xmm1, [rsp]
00007e1ec07d5cb1  add rsp, 0x30
00007e1ec07d5cb5  vmovaps xmm0, [rsp]
00007e1ec07d5cba  vmovaps xmm2, [rsp+0x10]
00007e1ec07d5cc0  vmovaps xmm3, [rsp+0x20]
00007e1ec07d5cc6  vmovaps xmm4, [rsp+0x30]
00007e1ec07d5ccc  vmovaps xmm5, [rsp+0x40]
00007e1ec07d5cd2  vmovaps xmm6, [rsp+0x50]
00007e1ec07d5cd8  vmovaps xmm7, [rsp+0x60]
00007e1ec07d5cde  vmovaps xmm8, [rsp+0x70]
00007e1ec07d5ce4  vmovaps xmm9, [rsp+0x80]
00007e1ec07d5ced  vmovaps xmm10, [rsp+0x90]
00007e1ec07d5cf6  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d5cff  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d5d08  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d5d11  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d5d1a  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d5d23  add rsp, 0xF0
00007e1ec07d5d2a  pop r11
00007e1ec07d5d2c  pop r10
00007e1ec07d5d2e  pop r9
00007e1ec07d5d30  pop r8
00007e1ec07d5d32  pop rsi
00007e1ec07d5d33  pop rdi
00007e1ec07d5d34  pop rdx
00007e1ec07d5d35  pop rcx
00007e1ec07d5d36  pop rax
00007e1ec07d5d37  add rsp, 0x08
00007e1ec07d5d3b  jmp 0x00007E1EC07D2FDD
00007e1ec07d5d40  sub rsp, 0x08
00007e1ec07d5d44  push rax
00007e1ec07d5d45  push rcx
00007e1ec07d5d46  push rdx
00007e1ec07d5d47  push rdi
00007e1ec07d5d48  push rsi
00007e1ec07d5d49  push r8
00007e1ec07d5d4b  push r9
00007e1ec07d5d4d  push r10
00007e1ec07d5d4f  push r11
00007e1ec07d5d51  sub rsp, 0xF0
00007e1ec07d5d58  vmovaps [rsp], xmm0
00007e1ec07d5d5d  vmovaps [rsp+0x10], xmm1
00007e1ec07d5d63  vmovaps [rsp+0x20], xmm2
00007e1ec07d5d69  vmovaps [rsp+0x30], xmm3
00007e1ec07d5d6f  vmovaps [rsp+0x40], xmm4
00007e1ec07d5d75  vmovaps [rsp+0x50], xmm6
00007e1ec07d5d7b  vmovaps [rsp+0x60], xmm7
00007e1ec07d5d81  vmovaps [rsp+0x70], xmm8
00007e1ec07d5d87  vmovaps [rsp+0x80], xmm9
00007e1ec07d5d90  vmovaps [rsp+0x90], xmm10
00007e1ec07d5d99  vmovaps [rsp+0xA0], xmm11
00007e1ec07d5da2  vmovaps [rsp+0xB0], xmm12
00007e1ec07d5dab  vmovaps [rsp+0xC0], xmm13
00007e1ec07d5db4  vmovaps [rsp+0xD0], xmm14
00007e1ec07d5dbd  vmovaps [rsp+0xE0], xmm15
00007e1ec07d5dc6  sub rsp, 0x30
00007e1ec07d5dca  movaps [rsp], xmm5
00007e1ec07d5dce  movaps [rsp+0x10], xmm2
00007e1ec07d5dd3  movaps [rsp+0x20], xmm13
00007e1ec07d5dd9  lea rdi, [rsp]
00007e1ec07d5ddd  mov esi, 0x00
00007e1ec07d5de2  mov rax, 0x5E00FF778530
00007e1ec07d5dec  call rax
00007e1ec07d5dee  movaps xmm5, [rsp]
00007e1ec07d5df2  add rsp, 0x30
00007e1ec07d5df6  vmovaps xmm0, [rsp]
00007e1ec07d5dfb  vmovaps xmm1, [rsp+0x10]
00007e1ec07d5e01  vmovaps xmm2, [rsp+0x20]
00007e1ec07d5e07  vmovaps xmm3, [rsp+0x30]
00007e1ec07d5e0d  vmovaps xmm4, [rsp+0x40]
00007e1ec07d5e13  vmovaps xmm6, [rsp+0x50]
00007e1ec07d5e19  vmovaps xmm7, [rsp+0x60]
00007e1ec07d5e1f  vmovaps xmm8, [rsp+0x70]
00007e1ec07d5e25  vmovaps xmm9, [rsp+0x80]
00007e1ec07d5e2e  vmovaps xmm10, [rsp+0x90]
00007e1ec07d5e37  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d5e40  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d5e49  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d5e52  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d5e5b  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d5e64  add rsp, 0xF0
00007e1ec07d5e6b  pop r11
00007e1ec07d5e6d  pop r10
00007e1ec07d5e6f  pop r9
00007e1ec07d5e71  pop r8
00007e1ec07d5e73  pop rsi
00007e1ec07d5e74  pop rdi
00007e1ec07d5e75  pop rdx
00007e1ec07d5e76  pop rcx
00007e1ec07d5e77  pop rax
00007e1ec07d5e78  add rsp, 0x08
00007e1ec07d5e7c  jmp 0x00007E1EC07D3013
00007e1ec07d5e81  sub rsp, 0x08
00007e1ec07d5e85  push rax
00007e1ec07d5e86  push rcx
00007e1ec07d5e87  push rdx
00007e1ec07d5e88  push rdi
00007e1ec07d5e89  push rsi
00007e1ec07d5e8a  push r8
00007e1ec07d5e8c  push r9
00007e1ec07d5e8e  push r10
00007e1ec07d5e90  push r11
00007e1ec07d5e92  sub rsp, 0xF0
00007e1ec07d5e99  vmovaps [rsp], xmm0
00007e1ec07d5e9e  vmovaps [rsp+0x10], xmm1
00007e1ec07d5ea4  vmovaps [rsp+0x20], xmm2
00007e1ec07d5eaa  vmovaps [rsp+0x30], xmm3
00007e1ec07d5eb0  vmovaps [rsp+0x40], xmm4
00007e1ec07d5eb6  vmovaps [rsp+0x50], xmm5
00007e1ec07d5ebc  vmovaps [rsp+0x60], xmm6
00007e1ec07d5ec2  vmovaps [rsp+0x70], xmm7
00007e1ec07d5ec8  vmovaps [rsp+0x80], xmm8
00007e1ec07d5ed1  vmovaps [rsp+0x90], xmm9
00007e1ec07d5eda  vmovaps [rsp+0xA0], xmm10
00007e1ec07d5ee3  vmovaps [rsp+0xB0], xmm11
00007e1ec07d5eec  vmovaps [rsp+0xC0], xmm12
00007e1ec07d5ef5  vmovaps [rsp+0xD0], xmm14
00007e1ec07d5efe  vmovaps [rsp+0xE0], xmm15
00007e1ec07d5f07  sub rsp, 0x30
00007e1ec07d5f0b  movaps [rsp], xmm13
00007e1ec07d5f10  movaps [rsp+0x10], xmm10
00007e1ec07d5f16  movaps [rsp+0x20], xmm1
00007e1ec07d5f1b  lea rdi, [rsp]
00007e1ec07d5f1f  mov esi, 0x00
00007e1ec07d5f24  mov rax, 0x5E00FF778530
00007e1ec07d5f2e  call rax
00007e1ec07d5f30  movaps xmm13, [rsp]
00007e1ec07d5f35  add rsp, 0x30
00007e1ec07d5f39  vmovaps xmm0, [rsp]
00007e1ec07d5f3e  vmovaps xmm1, [rsp+0x10]
00007e1ec07d5f44  vmovaps xmm2, [rsp+0x20]
00007e1ec07d5f4a  vmovaps xmm3, [rsp+0x30]
00007e1ec07d5f50  vmovaps xmm4, [rsp+0x40]
00007e1ec07d5f56  vmovaps xmm5, [rsp+0x50]
00007e1ec07d5f5c  vmovaps xmm6, [rsp+0x60]
00007e1ec07d5f62  vmovaps xmm7, [rsp+0x70]
00007e1ec07d5f68  vmovaps xmm8, [rsp+0x80]
00007e1ec07d5f71  vmovaps xmm9, [rsp+0x90]
00007e1ec07d5f7a  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d5f83  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d5f8c  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d5f95  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d5f9e  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d5fa7  add rsp, 0xF0
00007e1ec07d5fae  pop r11
00007e1ec07d5fb0  pop r10
00007e1ec07d5fb2  pop r9
00007e1ec07d5fb4  pop r8
00007e1ec07d5fb6  pop rsi
00007e1ec07d5fb7  pop rdi
00007e1ec07d5fb8  pop rdx
00007e1ec07d5fb9  pop rcx
00007e1ec07d5fba  pop rax
00007e1ec07d5fbb  add rsp, 0x08
00007e1ec07d5fbf  jmp 0x00007E1EC07D303C
00007e1ec07d5fc4  sub rsp, 0x08
00007e1ec07d5fc8  push rax
00007e1ec07d5fc9  push rcx
00007e1ec07d5fca  push rdx
00007e1ec07d5fcb  push rdi
00007e1ec07d5fcc  push rsi
00007e1ec07d5fcd  push r8
00007e1ec07d5fcf  push r9
00007e1ec07d5fd1  push r10
00007e1ec07d5fd3  push r11
00007e1ec07d5fd5  sub rsp, 0xF0
00007e1ec07d5fdc  vmovaps [rsp], xmm0
00007e1ec07d5fe1  vmovaps [rsp+0x10], xmm2
00007e1ec07d5fe7  vmovaps [rsp+0x20], xmm3
00007e1ec07d5fed  vmovaps [rsp+0x30], xmm4
00007e1ec07d5ff3  vmovaps [rsp+0x40], xmm5
00007e1ec07d5ff9  vmovaps [rsp+0x50], xmm6
00007e1ec07d5fff  vmovaps [rsp+0x60], xmm7
00007e1ec07d6005  vmovaps [rsp+0x70], xmm8
00007e1ec07d600b  vmovaps [rsp+0x80], xmm9
00007e1ec07d6014  vmovaps [rsp+0x90], xmm10
00007e1ec07d601d  vmovaps [rsp+0xA0], xmm11
00007e1ec07d6026  vmovaps [rsp+0xB0], xmm12
00007e1ec07d602f  vmovaps [rsp+0xC0], xmm13
00007e1ec07d6038  vmovaps [rsp+0xD0], xmm14
00007e1ec07d6041  vmovaps [rsp+0xE0], xmm15
00007e1ec07d604a  sub rsp, 0x30
00007e1ec07d604e  movaps [rsp], xmm1
00007e1ec07d6052  movaps [rsp+0x10], xmm15
00007e1ec07d6058  movaps [rsp+0x20], xmm10
00007e1ec07d605e  lea rdi, [rsp]
00007e1ec07d6062  mov esi, 0x00
00007e1ec07d6067  mov rax, 0x5E00FF778530
00007e1ec07d6071  call rax
00007e1ec07d6073  movaps xmm1, [rsp]
00007e1ec07d6077  add rsp, 0x30
00007e1ec07d607b  vmovaps xmm0, [rsp]
00007e1ec07d6080  vmovaps xmm2, [rsp+0x10]
00007e1ec07d6086  vmovaps xmm3, [rsp+0x20]
00007e1ec07d608c  vmovaps xmm4, [rsp+0x30]
00007e1ec07d6092  vmovaps xmm5, [rsp+0x40]
00007e1ec07d6098  vmovaps xmm6, [rsp+0x50]
00007e1ec07d609e  vmovaps xmm7, [rsp+0x60]
00007e1ec07d60a4  vmovaps xmm8, [rsp+0x70]
00007e1ec07d60aa  vmovaps xmm9, [rsp+0x80]
00007e1ec07d60b3  vmovaps xmm10, [rsp+0x90]
00007e1ec07d60bc  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d60c5  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d60ce  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d60d7  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d60e0  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d60e9  add rsp, 0xF0
00007e1ec07d60f0  pop r11
00007e1ec07d60f2  pop r10
00007e1ec07d60f4  pop r9
00007e1ec07d60f6  pop r8
00007e1ec07d60f8  pop rsi
00007e1ec07d60f9  pop rdi
00007e1ec07d60fa  pop rdx
00007e1ec07d60fb  pop rcx
00007e1ec07d60fc  pop rax
00007e1ec07d60fd  add rsp, 0x08
00007e1ec07d6101  jmp 0x00007E1EC07D305B
00007e1ec07d6106  sub rsp, 0x08
00007e1ec07d610a  push rax
00007e1ec07d610b  push rcx
00007e1ec07d610c  push rdx
00007e1ec07d610d  push rdi
00007e1ec07d610e  push rsi
00007e1ec07d610f  push r8
00007e1ec07d6111  push r9
00007e1ec07d6113  push r10
00007e1ec07d6115  push r11
00007e1ec07d6117  sub rsp, 0xF0
00007e1ec07d611e  vmovaps [rsp], xmm0
00007e1ec07d6123  vmovaps [rsp+0x10], xmm1
00007e1ec07d6129  vmovaps [rsp+0x20], xmm2
00007e1ec07d612f  vmovaps [rsp+0x30], xmm3
00007e1ec07d6135  vmovaps [rsp+0x40], xmm4
00007e1ec07d613b  vmovaps [rsp+0x50], xmm5
00007e1ec07d6141  vmovaps [rsp+0x60], xmm6
00007e1ec07d6147  vmovaps [rsp+0x70], xmm7
00007e1ec07d614d  vmovaps [rsp+0x80], xmm8
00007e1ec07d6156  vmovaps [rsp+0x90], xmm9
00007e1ec07d615f  vmovaps [rsp+0xA0], xmm10
00007e1ec07d6168  vmovaps [rsp+0xB0], xmm11
00007e1ec07d6171  vmovaps [rsp+0xC0], xmm12
00007e1ec07d617a  vmovaps [rsp+0xD0], xmm13
00007e1ec07d6183  vmovaps [rsp+0xE0], xmm14
00007e1ec07d618c  sub rsp, 0x30
00007e1ec07d6190  movaps [rsp], xmm15
00007e1ec07d6195  movaps [rsp+0x10], xmm10
00007e1ec07d619b  movaps [rsp+0x20], xmm11
00007e1ec07d61a1  lea rdi, [rsp]
00007e1ec07d61a5  mov esi, 0x00
00007e1ec07d61aa  mov rax, 0x5E00FF778530
00007e1ec07d61b4  call rax
00007e1ec07d61b6  movaps xmm15, [rsp]
00007e1ec07d61bb  add rsp, 0x30
00007e1ec07d61bf  vmovaps xmm0, [rsp]
00007e1ec07d61c4  vmovaps xmm1, [rsp+0x10]
00007e1ec07d61ca  vmovaps xmm2, [rsp+0x20]
00007e1ec07d61d0  vmovaps xmm3, [rsp+0x30]
00007e1ec07d61d6  vmovaps xmm4, [rsp+0x40]
00007e1ec07d61dc  vmovaps xmm5, [rsp+0x50]
00007e1ec07d61e2  vmovaps xmm6, [rsp+0x60]
00007e1ec07d61e8  vmovaps xmm7, [rsp+0x70]
00007e1ec07d61ee  vmovaps xmm8, [rsp+0x80]
00007e1ec07d61f7  vmovaps xmm9, [rsp+0x90]
00007e1ec07d6200  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d6209  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d6212  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d621b  vmovaps xmm13, [rsp+0xD0]
00007e1ec07d6224  vmovaps xmm14, [rsp+0xE0]
00007e1ec07d622d  add rsp, 0xF0
00007e1ec07d6234  pop r11
00007e1ec07d6236  pop r10
00007e1ec07d6238  pop r9
00007e1ec07d623a  pop r8
00007e1ec07d623c  pop rsi
00007e1ec07d623d  pop rdi
00007e1ec07d623e  pop rdx
00007e1ec07d623f  pop rcx
00007e1ec07d6240  pop rax
00007e1ec07d6241  add rsp, 0x08
00007e1ec07d6245  jmp 0x00007E1EC07D307E
00007e1ec07d624a  sub rsp, 0x08
00007e1ec07d624e  push rax
00007e1ec07d624f  push rcx
00007e1ec07d6250  push rdx
00007e1ec07d6251  push rdi
00007e1ec07d6252  push rsi
00007e1ec07d6253  push r8
00007e1ec07d6255  push r9
00007e1ec07d6257  push r10
00007e1ec07d6259  push r11
00007e1ec07d625b  sub rsp, 0xF0
00007e1ec07d6262  vmovaps [rsp], xmm0
00007e1ec07d6267  vmovaps [rsp+0x10], xmm1
00007e1ec07d626d  vmovaps [rsp+0x20], xmm2
00007e1ec07d6273  vmovaps [rsp+0x30], xmm3
00007e1ec07d6279  vmovaps [rsp+0x40], xmm4
00007e1ec07d627f  vmovaps [rsp+0x50], xmm5
00007e1ec07d6285  vmovaps [rsp+0x60], xmm6
00007e1ec07d628b  vmovaps [rsp+0x70], xmm7
00007e1ec07d6291  vmovaps [rsp+0x80], xmm8
00007e1ec07d629a  vmovaps [rsp+0x90], xmm9
00007e1ec07d62a3  vmovaps [rsp+0xA0], xmm11
00007e1ec07d62ac  vmovaps [rsp+0xB0], xmm12
00007e1ec07d62b5  vmovaps [rsp+0xC0], xmm13
00007e1ec07d62be  vmovaps [rsp+0xD0], xmm14
00007e1ec07d62c7  vmovaps [rsp+0xE0], xmm15
00007e1ec07d62d0  sub rsp, 0x30
00007e1ec07d62d4  movaps [rsp], xmm10
00007e1ec07d62d9  movaps [rsp+0x10], xmm2
00007e1ec07d62de  movaps [rsp+0x20], xmm11
00007e1ec07d62e4  lea rdi, [rsp]
00007e1ec07d62e8  mov esi, 0x00
00007e1ec07d62ed  mov rax, 0x5E00FF778530
00007e1ec07d62f7  call rax
00007e1ec07d62f9  movaps xmm10, [rsp]
00007e1ec07d62fe  add rsp, 0x30
00007e1ec07d6302  vmovaps xmm0, [rsp]
00007e1ec07d6307  vmovaps xmm1, [rsp+0x10]
00007e1ec07d630d  vmovaps xmm2, [rsp+0x20]
00007e1ec07d6313  vmovaps xmm3, [rsp+0x30]
00007e1ec07d6319  vmovaps xmm4, [rsp+0x40]
00007e1ec07d631f  vmovaps xmm5, [rsp+0x50]
00007e1ec07d6325  vmovaps xmm6, [rsp+0x60]
00007e1ec07d632b  vmovaps xmm7, [rsp+0x70]
00007e1ec07d6331  vmovaps xmm8, [rsp+0x80]
00007e1ec07d633a  vmovaps xmm9, [rsp+0x90]
00007e1ec07d6343  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d634c  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d6355  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d635e  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d6367  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d6370  add rsp, 0xF0
00007e1ec07d6377  pop r11
00007e1ec07d6379  pop r10
00007e1ec07d637b  pop r9
00007e1ec07d637d  pop r8
00007e1ec07d637f  pop rsi
00007e1ec07d6380  pop rdi
00007e1ec07d6381  pop rdx
00007e1ec07d6382  pop rcx
00007e1ec07d6383  pop rax
00007e1ec07d6384  add rsp, 0x08
00007e1ec07d6388  jmp 0x00007E1EC07D30B6
00007e1ec07d638d  sub rsp, 0x08
00007e1ec07d6391  push rax
00007e1ec07d6392  push rcx
00007e1ec07d6393  push rdx
00007e1ec07d6394  push rdi
00007e1ec07d6395  push rsi
00007e1ec07d6396  push r8
00007e1ec07d6398  push r9
00007e1ec07d639a  push r10
00007e1ec07d639c  push r11
00007e1ec07d639e  sub rsp, 0xF0
00007e1ec07d63a5  vmovaps [rsp], xmm0
00007e1ec07d63aa  vmovaps [rsp+0x10], xmm1
00007e1ec07d63b0  vmovaps [rsp+0x20], xmm2
00007e1ec07d63b6  vmovaps [rsp+0x30], xmm3
00007e1ec07d63bc  vmovaps [rsp+0x40], xmm4
00007e1ec07d63c2  vmovaps [rsp+0x50], xmm5
00007e1ec07d63c8  vmovaps [rsp+0x60], xmm6
00007e1ec07d63ce  vmovaps [rsp+0x70], xmm7
00007e1ec07d63d4  vmovaps [rsp+0x80], xmm8
00007e1ec07d63dd  vmovaps [rsp+0x90], xmm9
00007e1ec07d63e6  vmovaps [rsp+0xA0], xmm10
00007e1ec07d63ef  vmovaps [rsp+0xB0], xmm12
00007e1ec07d63f8  vmovaps [rsp+0xC0], xmm13
00007e1ec07d6401  vmovaps [rsp+0xD0], xmm14
00007e1ec07d640a  vmovaps [rsp+0xE0], xmm15
00007e1ec07d6413  sub rsp, 0x30
00007e1ec07d6417  movaps [rsp], xmm11
00007e1ec07d641c  movaps [rsp+0x10], xmm2
00007e1ec07d6421  movaps [rsp+0x20], xmm1
00007e1ec07d6426  lea rdi, [rsp]
00007e1ec07d642a  mov esi, 0x00
00007e1ec07d642f  mov rax, 0x5E00FF778530
00007e1ec07d6439  call rax
00007e1ec07d643b  movaps xmm11, [rsp]
00007e1ec07d6440  add rsp, 0x30
00007e1ec07d6444  vmovaps xmm0, [rsp]
00007e1ec07d6449  vmovaps xmm1, [rsp+0x10]
00007e1ec07d644f  vmovaps xmm2, [rsp+0x20]
00007e1ec07d6455  vmovaps xmm3, [rsp+0x30]
00007e1ec07d645b  vmovaps xmm4, [rsp+0x40]
00007e1ec07d6461  vmovaps xmm5, [rsp+0x50]
00007e1ec07d6467  vmovaps xmm6, [rsp+0x60]
00007e1ec07d646d  vmovaps xmm7, [rsp+0x70]
00007e1ec07d6473  vmovaps xmm8, [rsp+0x80]
00007e1ec07d647c  vmovaps xmm9, [rsp+0x90]
00007e1ec07d6485  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d648e  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d6497  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d64a0  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d64a9  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d64b2  add rsp, 0xF0
00007e1ec07d64b9  pop r11
00007e1ec07d64bb  pop r10
00007e1ec07d64bd  pop r9
00007e1ec07d64bf  pop r8
00007e1ec07d64c1  pop rsi
00007e1ec07d64c2  pop rdi
00007e1ec07d64c3  pop rdx
00007e1ec07d64c4  pop rcx
00007e1ec07d64c5  pop rax
00007e1ec07d64c6  add rsp, 0x08
00007e1ec07d64ca  jmp 0x00007E1EC07D30F2
00007e1ec07d64cf  sub rsp, 0x08
00007e1ec07d64d3  push rax
00007e1ec07d64d4  push rcx
00007e1ec07d64d5  push rdx
00007e1ec07d64d6  push rdi
00007e1ec07d64d7  push rsi
00007e1ec07d64d8  push r8
00007e1ec07d64da  push r9
00007e1ec07d64dc  push r10
00007e1ec07d64de  push r11
00007e1ec07d64e0  sub rsp, 0xF0
00007e1ec07d64e7  vmovaps [rsp], xmm0
00007e1ec07d64ec  vmovaps [rsp+0x10], xmm2
00007e1ec07d64f2  vmovaps [rsp+0x20], xmm3
00007e1ec07d64f8  vmovaps [rsp+0x30], xmm4
00007e1ec07d64fe  vmovaps [rsp+0x40], xmm5
00007e1ec07d6504  vmovaps [rsp+0x50], xmm6
00007e1ec07d650a  vmovaps [rsp+0x60], xmm7
00007e1ec07d6510  vmovaps [rsp+0x70], xmm8
00007e1ec07d6516  vmovaps [rsp+0x80], xmm9
00007e1ec07d651f  vmovaps [rsp+0x90], xmm10
00007e1ec07d6528  vmovaps [rsp+0xA0], xmm11
00007e1ec07d6531  vmovaps [rsp+0xB0], xmm12
00007e1ec07d653a  vmovaps [rsp+0xC0], xmm13
00007e1ec07d6543  vmovaps [rsp+0xD0], xmm14
00007e1ec07d654c  vmovaps [rsp+0xE0], xmm15
00007e1ec07d6555  sub rsp, 0x30
00007e1ec07d6559  movaps [rsp], xmm1
00007e1ec07d655d  movaps [rsp+0x10], xmm14
00007e1ec07d6563  movaps [rsp+0x20], xmm6
00007e1ec07d6568  lea rdi, [rsp]
00007e1ec07d656c  mov esi, 0x00
00007e1ec07d6571  mov rax, 0x5E00FF778530
00007e1ec07d657b  call rax
00007e1ec07d657d  movaps xmm1, [rsp]
00007e1ec07d6581  add rsp, 0x30
00007e1ec07d6585  vmovaps xmm0, [rsp]
00007e1ec07d658a  vmovaps xmm2, [rsp+0x10]
00007e1ec07d6590  vmovaps xmm3, [rsp+0x20]
00007e1ec07d6596  vmovaps xmm4, [rsp+0x30]
00007e1ec07d659c  vmovaps xmm5, [rsp+0x40]
00007e1ec07d65a2  vmovaps xmm6, [rsp+0x50]
00007e1ec07d65a8  vmovaps xmm7, [rsp+0x60]
00007e1ec07d65ae  vmovaps xmm8, [rsp+0x70]
00007e1ec07d65b4  vmovaps xmm9, [rsp+0x80]
00007e1ec07d65bd  vmovaps xmm10, [rsp+0x90]
00007e1ec07d65c6  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d65cf  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d65d8  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d65e1  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d65ea  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d65f3  add rsp, 0xF0
00007e1ec07d65fa  pop r11
00007e1ec07d65fc  pop r10
00007e1ec07d65fe  pop r9
00007e1ec07d6600  pop r8
00007e1ec07d6602  pop rsi
00007e1ec07d6603  pop rdi
00007e1ec07d6604  pop rdx
00007e1ec07d6605  pop rcx
00007e1ec07d6606  pop rax
00007e1ec07d6607  add rsp, 0x08
00007e1ec07d660b  jmp 0x00007E1EC07D310B
00007e1ec07d6610  sub rsp, 0x08
00007e1ec07d6614  push rax
00007e1ec07d6615  push rcx
00007e1ec07d6616  push rdx
00007e1ec07d6617  push rdi
00007e1ec07d6618  push rsi
00007e1ec07d6619  push r8
00007e1ec07d661b  push r9
00007e1ec07d661d  push r10
00007e1ec07d661f  push r11
00007e1ec07d6621  sub rsp, 0xF0
00007e1ec07d6628  vmovaps [rsp], xmm0
00007e1ec07d662d  vmovaps [rsp+0x10], xmm1
00007e1ec07d6633  vmovaps [rsp+0x20], xmm2
00007e1ec07d6639  vmovaps [rsp+0x30], xmm3
00007e1ec07d663f  vmovaps [rsp+0x40], xmm4
00007e1ec07d6645  vmovaps [rsp+0x50], xmm5
00007e1ec07d664b  vmovaps [rsp+0x60], xmm6
00007e1ec07d6651  vmovaps [rsp+0x70], xmm7
00007e1ec07d6657  vmovaps [rsp+0x80], xmm8
00007e1ec07d6660  vmovaps [rsp+0x90], xmm9
00007e1ec07d6669  vmovaps [rsp+0xA0], xmm10
00007e1ec07d6672  vmovaps [rsp+0xB0], xmm11
00007e1ec07d667b  vmovaps [rsp+0xC0], xmm12
00007e1ec07d6684  vmovaps [rsp+0xD0], xmm13
00007e1ec07d668d  vmovaps [rsp+0xE0], xmm14
00007e1ec07d6696  sub rsp, 0x30
00007e1ec07d669a  movaps [rsp], xmm15
00007e1ec07d669f  movaps [rsp+0x10], xmm14
00007e1ec07d66a5  movaps [rsp+0x20], xmm5
00007e1ec07d66aa  lea rdi, [rsp]
00007e1ec07d66ae  mov esi, 0x00
00007e1ec07d66b3  mov rax, 0x5E00FF778530
00007e1ec07d66bd  call rax
00007e1ec07d66bf  movaps xmm15, [rsp]
00007e1ec07d66c4  add rsp, 0x30
00007e1ec07d66c8  vmovaps xmm0, [rsp]
00007e1ec07d66cd  vmovaps xmm1, [rsp+0x10]
00007e1ec07d66d3  vmovaps xmm2, [rsp+0x20]
00007e1ec07d66d9  vmovaps xmm3, [rsp+0x30]
00007e1ec07d66df  vmovaps xmm4, [rsp+0x40]
00007e1ec07d66e5  vmovaps xmm5, [rsp+0x50]
00007e1ec07d66eb  vmovaps xmm6, [rsp+0x60]
00007e1ec07d66f1  vmovaps xmm7, [rsp+0x70]
00007e1ec07d66f7  vmovaps xmm8, [rsp+0x80]
00007e1ec07d6700  vmovaps xmm9, [rsp+0x90]
00007e1ec07d6709  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d6712  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d671b  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d6724  vmovaps xmm13, [rsp+0xD0]
00007e1ec07d672d  vmovaps xmm14, [rsp+0xE0]
00007e1ec07d6736  add rsp, 0xF0
00007e1ec07d673d  pop r11
00007e1ec07d673f  pop r10
00007e1ec07d6741  pop r9
00007e1ec07d6743  pop r8
00007e1ec07d6745  pop rsi
00007e1ec07d6746  pop rdi
00007e1ec07d6747  pop rdx
00007e1ec07d6748  pop rcx
00007e1ec07d6749  pop rax
00007e1ec07d674a  add rsp, 0x08
00007e1ec07d674e  jmp 0x00007E1EC07D312B
00007e1ec07d6753  sub rsp, 0x08
00007e1ec07d6757  push rax
00007e1ec07d6758  push rcx
00007e1ec07d6759  push rdx
00007e1ec07d675a  push rdi
00007e1ec07d675b  push rsi
00007e1ec07d675c  push r8
00007e1ec07d675e  push r9
00007e1ec07d6760  push r10
00007e1ec07d6762  push r11
00007e1ec07d6764  sub rsp, 0xF0
00007e1ec07d676b  vmovaps [rsp], xmm0
00007e1ec07d6770  vmovaps [rsp+0x10], xmm1
00007e1ec07d6776  vmovaps [rsp+0x20], xmm2
00007e1ec07d677c  vmovaps [rsp+0x30], xmm3
00007e1ec07d6782  vmovaps [rsp+0x40], xmm4
00007e1ec07d6788  vmovaps [rsp+0x50], xmm5
00007e1ec07d678e  vmovaps [rsp+0x60], xmm7
00007e1ec07d6794  vmovaps [rsp+0x70], xmm8
00007e1ec07d679a  vmovaps [rsp+0x80], xmm9
00007e1ec07d67a3  vmovaps [rsp+0x90], xmm10
00007e1ec07d67ac  vmovaps [rsp+0xA0], xmm11
00007e1ec07d67b5  vmovaps [rsp+0xB0], xmm12
00007e1ec07d67be  vmovaps [rsp+0xC0], xmm13
00007e1ec07d67c7  vmovaps [rsp+0xD0], xmm14
00007e1ec07d67d0  vmovaps [rsp+0xE0], xmm15
00007e1ec07d67d9  sub rsp, 0x30
00007e1ec07d67dd  movaps [rsp], xmm6
00007e1ec07d67e1  movaps [rsp+0x10], xmm9
00007e1ec07d67e7  movaps [rsp+0x20], xmm14
00007e1ec07d67ed  lea rdi, [rsp]
00007e1ec07d67f1  mov esi, 0x00
00007e1ec07d67f6  mov rax, 0x5E00FF778530
00007e1ec07d6800  call rax
00007e1ec07d6802  movaps xmm6, [rsp]
00007e1ec07d6806  add rsp, 0x30
00007e1ec07d680a  vmovaps xmm0, [rsp]
00007e1ec07d680f  vmovaps xmm1, [rsp+0x10]
00007e1ec07d6815  vmovaps xmm2, [rsp+0x20]
00007e1ec07d681b  vmovaps xmm3, [rsp+0x30]
00007e1ec07d6821  vmovaps xmm4, [rsp+0x40]
00007e1ec07d6827  vmovaps xmm5, [rsp+0x50]
00007e1ec07d682d  vmovaps xmm7, [rsp+0x60]
00007e1ec07d6833  vmovaps xmm8, [rsp+0x70]
00007e1ec07d6839  vmovaps xmm9, [rsp+0x80]
00007e1ec07d6842  vmovaps xmm10, [rsp+0x90]
00007e1ec07d684b  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d6854  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d685d  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d6866  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d686f  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d6878  add rsp, 0xF0
00007e1ec07d687f  pop r11
00007e1ec07d6881  pop r10
00007e1ec07d6883  pop r9
00007e1ec07d6885  pop r8
00007e1ec07d6887  pop rsi
00007e1ec07d6888  pop rdi
00007e1ec07d6889  pop rdx
00007e1ec07d688a  pop rcx
00007e1ec07d688b  pop rax
00007e1ec07d688c  add rsp, 0x08
00007e1ec07d6890  jmp 0x00007E1EC07D3153
00007e1ec07d6895  sub rsp, 0x08
00007e1ec07d6899  push rax
00007e1ec07d689a  push rcx
00007e1ec07d689b  push rdx
00007e1ec07d689c  push rdi
00007e1ec07d689d  push rsi
00007e1ec07d689e  push r8
00007e1ec07d68a0  push r9
00007e1ec07d68a2  push r10
00007e1ec07d68a4  push r11
00007e1ec07d68a6  sub rsp, 0xF0
00007e1ec07d68ad  vmovaps [rsp], xmm0
00007e1ec07d68b2  vmovaps [rsp+0x10], xmm1
00007e1ec07d68b8  vmovaps [rsp+0x20], xmm2
00007e1ec07d68be  vmovaps [rsp+0x30], xmm3
00007e1ec07d68c4  vmovaps [rsp+0x40], xmm4
00007e1ec07d68ca  vmovaps [rsp+0x50], xmm5
00007e1ec07d68d0  vmovaps [rsp+0x60], xmm6
00007e1ec07d68d6  vmovaps [rsp+0x70], xmm7
00007e1ec07d68dc  vmovaps [rsp+0x80], xmm8
00007e1ec07d68e5  vmovaps [rsp+0x90], xmm9
00007e1ec07d68ee  vmovaps [rsp+0xA0], xmm10
00007e1ec07d68f7  vmovaps [rsp+0xB0], xmm11
00007e1ec07d6900  vmovaps [rsp+0xC0], xmm12
00007e1ec07d6909  vmovaps [rsp+0xD0], xmm13
00007e1ec07d6912  vmovaps [rsp+0xE0], xmm15
00007e1ec07d691b  sub rsp, 0x30
00007e1ec07d691f  movaps [rsp], xmm14
00007e1ec07d6924  movaps [rsp+0x10], xmm9
00007e1ec07d692a  movaps [rsp+0x20], xmm13
00007e1ec07d6930  lea rdi, [rsp]
00007e1ec07d6934  mov esi, 0x00
00007e1ec07d6939  mov rax, 0x5E00FF778530
00007e1ec07d6943  call rax
00007e1ec07d6945  movaps xmm14, [rsp]
00007e1ec07d694a  add rsp, 0x30
00007e1ec07d694e  vmovaps xmm0, [rsp]
00007e1ec07d6953  vmovaps xmm1, [rsp+0x10]
00007e1ec07d6959  vmovaps xmm2, [rsp+0x20]
00007e1ec07d695f  vmovaps xmm3, [rsp+0x30]
00007e1ec07d6965  vmovaps xmm4, [rsp+0x40]
00007e1ec07d696b  vmovaps xmm5, [rsp+0x50]
00007e1ec07d6971  vmovaps xmm6, [rsp+0x60]
00007e1ec07d6977  vmovaps xmm7, [rsp+0x70]
00007e1ec07d697d  vmovaps xmm8, [rsp+0x80]
00007e1ec07d6986  vmovaps xmm9, [rsp+0x90]
00007e1ec07d698f  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d6998  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d69a1  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d69aa  vmovaps xmm13, [rsp+0xD0]
00007e1ec07d69b3  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d69bc  add rsp, 0xF0
00007e1ec07d69c3  pop r11
00007e1ec07d69c5  pop r10
00007e1ec07d69c7  pop r9
00007e1ec07d69c9  pop r8
00007e1ec07d69cb  pop rsi
00007e1ec07d69cc  pop rdi
00007e1ec07d69cd  pop rdx
00007e1ec07d69ce  pop rcx
00007e1ec07d69cf  pop rax
00007e1ec07d69d0  add rsp, 0x08
00007e1ec07d69d4  jmp 0x00007E1EC07D3176
00007e1ec07d69d9  sub rsp, 0x08
00007e1ec07d69dd  push rax
00007e1ec07d69de  push rcx
00007e1ec07d69df  push rdx
00007e1ec07d69e0  push rdi
00007e1ec07d69e1  push rsi
00007e1ec07d69e2  push r8
00007e1ec07d69e4  push r9
00007e1ec07d69e6  push r10
00007e1ec07d69e8  push r11
00007e1ec07d69ea  sub rsp, 0xF0
00007e1ec07d69f1  vmovaps [rsp], xmm0
00007e1ec07d69f6  vmovaps [rsp+0x10], xmm1
00007e1ec07d69fc  vmovaps [rsp+0x20], xmm2
00007e1ec07d6a02  vmovaps [rsp+0x30], xmm3
00007e1ec07d6a08  vmovaps [rsp+0x40], xmm4
00007e1ec07d6a0e  vmovaps [rsp+0x50], xmm5
00007e1ec07d6a14  vmovaps [rsp+0x60], xmm6
00007e1ec07d6a1a  vmovaps [rsp+0x70], xmm7
00007e1ec07d6a20  vmovaps [rsp+0x80], xmm8
00007e1ec07d6a29  vmovaps [rsp+0x90], xmm9
00007e1ec07d6a32  vmovaps [rsp+0xA0], xmm10
00007e1ec07d6a3b  vmovaps [rsp+0xB0], xmm11
00007e1ec07d6a44  vmovaps [rsp+0xC0], xmm12
00007e1ec07d6a4d  vmovaps [rsp+0xD0], xmm14
00007e1ec07d6a56  vmovaps [rsp+0xE0], xmm15
00007e1ec07d6a5f  sub rsp, 0x30
00007e1ec07d6a63  movaps [rsp], xmm13
00007e1ec07d6a68  movaps [rsp+0x10], xmm9
00007e1ec07d6a6e  movaps [rsp+0x20], xmm10
00007e1ec07d6a74  lea rdi, [rsp]
00007e1ec07d6a78  mov esi, 0x00
00007e1ec07d6a7d  mov rax, 0x5E00FF778530
00007e1ec07d6a87  call rax
00007e1ec07d6a89  movaps xmm13, [rsp]
00007e1ec07d6a8e  add rsp, 0x30
00007e1ec07d6a92  vmovaps xmm0, [rsp]
00007e1ec07d6a97  vmovaps xmm1, [rsp+0x10]
00007e1ec07d6a9d  vmovaps xmm2, [rsp+0x20]
00007e1ec07d6aa3  vmovaps xmm3, [rsp+0x30]
00007e1ec07d6aa9  vmovaps xmm4, [rsp+0x40]
00007e1ec07d6aaf  vmovaps xmm5, [rsp+0x50]
00007e1ec07d6ab5  vmovaps xmm6, [rsp+0x60]
00007e1ec07d6abb  vmovaps xmm7, [rsp+0x70]
00007e1ec07d6ac1  vmovaps xmm8, [rsp+0x80]
00007e1ec07d6aca  vmovaps xmm9, [rsp+0x90]
00007e1ec07d6ad3  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d6adc  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d6ae5  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d6aee  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d6af7  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d6b00  add rsp, 0xF0
00007e1ec07d6b07  pop r11
00007e1ec07d6b09  pop r10
00007e1ec07d6b0b  pop r9
00007e1ec07d6b0d  pop r8
00007e1ec07d6b0f  pop rsi
00007e1ec07d6b10  pop rdi
00007e1ec07d6b11  pop rdx
00007e1ec07d6b12  pop rcx
00007e1ec07d6b13  pop rax
00007e1ec07d6b14  add rsp, 0x08
00007e1ec07d6b18  jmp 0x00007E1EC07D3196
00007e1ec07d6b1d  call 0x00007E1EC060AFE0
00007e1ec07d6b22  jmp 0x00007E1EC07D31EB
00007e1ec07d6b27  sub rsp, 0x08
00007e1ec07d6b2b  push rax
00007e1ec07d6b2c  push rcx
00007e1ec07d6b2d  push rdx
00007e1ec07d6b2e  push rdi
00007e1ec07d6b2f  push rsi
00007e1ec07d6b30  push r8
00007e1ec07d6b32  push r9
00007e1ec07d6b34  push r10
00007e1ec07d6b36  push r11
00007e1ec07d6b38  sub rsp, 0xF0
00007e1ec07d6b3f  vmovaps [rsp], xmm0
00007e1ec07d6b44  vmovaps [rsp+0x10], xmm1
00007e1ec07d6b4a  vmovaps [rsp+0x20], xmm2
00007e1ec07d6b50  vmovaps [rsp+0x30], xmm3
00007e1ec07d6b56  vmovaps [rsp+0x40], xmm4
00007e1ec07d6b5c  vmovaps [rsp+0x50], xmm5
00007e1ec07d6b62  vmovaps [rsp+0x60], xmm6
00007e1ec07d6b68  vmovaps [rsp+0x70], xmm7
00007e1ec07d6b6e  vmovaps [rsp+0x80], xmm8
00007e1ec07d6b77  vmovaps [rsp+0x90], xmm10
00007e1ec07d6b80  vmovaps [rsp+0xA0], xmm11
00007e1ec07d6b89  vmovaps [rsp+0xB0], xmm12
00007e1ec07d6b92  vmovaps [rsp+0xC0], xmm13
00007e1ec07d6b9b  vmovaps [rsp+0xD0], xmm14
00007e1ec07d6ba4  vmovaps [rsp+0xE0], xmm15
00007e1ec07d6bad  sub rsp, 0x30
00007e1ec07d6bb1  movaps [rsp], xmm9
00007e1ec07d6bb6  movaps [rsp+0x10], xmm8
00007e1ec07d6bbc  movaps [rsp+0x20], xmm10
00007e1ec07d6bc2  lea rdi, [rsp]
00007e1ec07d6bc6  mov esi, 0x00
00007e1ec07d6bcb  mov rax, 0x5E00FF778530
00007e1ec07d6bd5  call rax
00007e1ec07d6bd7  movaps xmm9, [rsp]
00007e1ec07d6bdc  add rsp, 0x30
00007e1ec07d6be0  vmovaps xmm0, [rsp]
00007e1ec07d6be5  vmovaps xmm1, [rsp+0x10]
00007e1ec07d6beb  vmovaps xmm2, [rsp+0x20]
00007e1ec07d6bf1  vmovaps xmm3, [rsp+0x30]
00007e1ec07d6bf7  vmovaps xmm4, [rsp+0x40]
00007e1ec07d6bfd  vmovaps xmm5, [rsp+0x50]
00007e1ec07d6c03  vmovaps xmm6, [rsp+0x60]
00007e1ec07d6c09  vmovaps xmm7, [rsp+0x70]
00007e1ec07d6c0f  vmovaps xmm8, [rsp+0x80]
00007e1ec07d6c18  vmovaps xmm10, [rsp+0x90]
00007e1ec07d6c21  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d6c2a  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d6c33  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d6c3c  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d6c45  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d6c4e  add rsp, 0xF0
00007e1ec07d6c55  pop r11
00007e1ec07d6c57  pop r10
00007e1ec07d6c59  pop r9
00007e1ec07d6c5b  pop r8
00007e1ec07d6c5d  pop rsi
00007e1ec07d6c5e  pop rdi
00007e1ec07d6c5f  pop rdx
00007e1ec07d6c60  pop rcx
00007e1ec07d6c61  pop rax
00007e1ec07d6c62  add rsp, 0x08
00007e1ec07d6c66  jmp 0x00007E1EC07D321C
00007e1ec07d6c6b  sub rsp, 0x08
00007e1ec07d6c6f  push rax
00007e1ec07d6c70  push rcx
00007e1ec07d6c71  push rdx
00007e1ec07d6c72  push rdi
00007e1ec07d6c73  push rsi
00007e1ec07d6c74  push r8
00007e1ec07d6c76  push r9
00007e1ec07d6c78  push r10
00007e1ec07d6c7a  push r11
00007e1ec07d6c7c  sub rsp, 0xF0
00007e1ec07d6c83  vmovaps [rsp], xmm0
00007e1ec07d6c88  vmovaps [rsp+0x10], xmm1
00007e1ec07d6c8e  vmovaps [rsp+0x20], xmm2
00007e1ec07d6c94  vmovaps [rsp+0x30], xmm3
00007e1ec07d6c9a  vmovaps [rsp+0x40], xmm4
00007e1ec07d6ca0  vmovaps [rsp+0x50], xmm5
00007e1ec07d6ca6  vmovaps [rsp+0x60], xmm6
00007e1ec07d6cac  vmovaps [rsp+0x70], xmm7
00007e1ec07d6cb2  vmovaps [rsp+0x80], xmm8
00007e1ec07d6cbb  vmovaps [rsp+0x90], xmm9
00007e1ec07d6cc4  vmovaps [rsp+0xA0], xmm11
00007e1ec07d6ccd  vmovaps [rsp+0xB0], xmm12
00007e1ec07d6cd6  vmovaps [rsp+0xC0], xmm13
00007e1ec07d6cdf  vmovaps [rsp+0xD0], xmm14
00007e1ec07d6ce8  vmovaps [rsp+0xE0], xmm15
00007e1ec07d6cf1  sub rsp, 0x30
00007e1ec07d6cf5  movaps [rsp], xmm10
00007e1ec07d6cfa  movaps [rsp+0x10], xmm1
00007e1ec07d6cff  movaps [rsp+0x20], xmm11
00007e1ec07d6d05  lea rdi, [rsp]
00007e1ec07d6d09  mov esi, 0x00
00007e1ec07d6d0e  mov rax, 0x5E00FF778530
00007e1ec07d6d18  call rax
00007e1ec07d6d1a  movaps xmm10, [rsp]
00007e1ec07d6d1f  add rsp, 0x30
00007e1ec07d6d23  vmovaps xmm0, [rsp]
00007e1ec07d6d28  vmovaps xmm1, [rsp+0x10]
00007e1ec07d6d2e  vmovaps xmm2, [rsp+0x20]
00007e1ec07d6d34  vmovaps xmm3, [rsp+0x30]
00007e1ec07d6d3a  vmovaps xmm4, [rsp+0x40]
00007e1ec07d6d40  vmovaps xmm5, [rsp+0x50]
00007e1ec07d6d46  vmovaps xmm6, [rsp+0x60]
00007e1ec07d6d4c  vmovaps xmm7, [rsp+0x70]
00007e1ec07d6d52  vmovaps xmm8, [rsp+0x80]
00007e1ec07d6d5b  vmovaps xmm9, [rsp+0x90]
00007e1ec07d6d64  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d6d6d  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d6d76  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d6d7f  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d6d88  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d6d91  add rsp, 0xF0
00007e1ec07d6d98  pop r11
00007e1ec07d6d9a  pop r10
00007e1ec07d6d9c  pop r9
00007e1ec07d6d9e  pop r8
00007e1ec07d6da0  pop rsi
00007e1ec07d6da1  pop rdi
00007e1ec07d6da2  pop rdx
00007e1ec07d6da3  pop rcx
00007e1ec07d6da4  pop rax
00007e1ec07d6da5  add rsp, 0x08
00007e1ec07d6da9  jmp 0x00007E1EC07D3237
00007e1ec07d6dae  sub rsp, 0x08
00007e1ec07d6db2  push rax
00007e1ec07d6db3  push rcx
00007e1ec07d6db4  push rdx
00007e1ec07d6db5  push rdi
00007e1ec07d6db6  push rsi
00007e1ec07d6db7  push r8
00007e1ec07d6db9  push r9
00007e1ec07d6dbb  push r10
00007e1ec07d6dbd  push r11
00007e1ec07d6dbf  sub rsp, 0xF0
00007e1ec07d6dc6  vmovaps [rsp], xmm0
00007e1ec07d6dcb  vmovaps [rsp+0x10], xmm2
00007e1ec07d6dd1  vmovaps [rsp+0x20], xmm3
00007e1ec07d6dd7  vmovaps [rsp+0x30], xmm4
00007e1ec07d6ddd  vmovaps [rsp+0x40], xmm5
00007e1ec07d6de3  vmovaps [rsp+0x50], xmm6
00007e1ec07d6de9  vmovaps [rsp+0x60], xmm7
00007e1ec07d6def  vmovaps [rsp+0x70], xmm8
00007e1ec07d6df5  vmovaps [rsp+0x80], xmm9
00007e1ec07d6dfe  vmovaps [rsp+0x90], xmm10
00007e1ec07d6e07  vmovaps [rsp+0xA0], xmm11
00007e1ec07d6e10  vmovaps [rsp+0xB0], xmm12
00007e1ec07d6e19  vmovaps [rsp+0xC0], xmm13
00007e1ec07d6e22  vmovaps [rsp+0xD0], xmm14
00007e1ec07d6e2b  vmovaps [rsp+0xE0], xmm15
00007e1ec07d6e34  sub rsp, 0x30
00007e1ec07d6e38  movaps [rsp], xmm1
00007e1ec07d6e3c  movaps [rsp+0x10], xmm15
00007e1ec07d6e42  movaps [rsp+0x20], xmm6
00007e1ec07d6e47  lea rdi, [rsp]
00007e1ec07d6e4b  mov esi, 0x00
00007e1ec07d6e50  mov rax, 0x5E00FF778530
00007e1ec07d6e5a  call rax
00007e1ec07d6e5c  movaps xmm1, [rsp]
00007e1ec07d6e60  add rsp, 0x30
00007e1ec07d6e64  vmovaps xmm0, [rsp]
00007e1ec07d6e69  vmovaps xmm2, [rsp+0x10]
00007e1ec07d6e6f  vmovaps xmm3, [rsp+0x20]
00007e1ec07d6e75  vmovaps xmm4, [rsp+0x30]
00007e1ec07d6e7b  vmovaps xmm5, [rsp+0x40]
00007e1ec07d6e81  vmovaps xmm6, [rsp+0x50]
00007e1ec07d6e87  vmovaps xmm7, [rsp+0x60]
00007e1ec07d6e8d  vmovaps xmm8, [rsp+0x70]
00007e1ec07d6e93  vmovaps xmm9, [rsp+0x80]
00007e1ec07d6e9c  vmovaps xmm10, [rsp+0x90]
00007e1ec07d6ea5  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d6eae  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d6eb7  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d6ec0  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d6ec9  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d6ed2  add rsp, 0xF0
00007e1ec07d6ed9  pop r11
00007e1ec07d6edb  pop r10
00007e1ec07d6edd  pop r9
00007e1ec07d6edf  pop r8
00007e1ec07d6ee1  pop rsi
00007e1ec07d6ee2  pop rdi
00007e1ec07d6ee3  pop rdx
00007e1ec07d6ee4  pop rcx
00007e1ec07d6ee5  pop rax
00007e1ec07d6ee6  add rsp, 0x08
00007e1ec07d6eea  jmp 0x00007E1EC07D3250
00007e1ec07d6eef  sub rsp, 0x08
00007e1ec07d6ef3  push rax
00007e1ec07d6ef4  push rcx
00007e1ec07d6ef5  push rdx
00007e1ec07d6ef6  push rdi
00007e1ec07d6ef7  push rsi
00007e1ec07d6ef8  push r8
00007e1ec07d6efa  push r9
00007e1ec07d6efc  push r10
00007e1ec07d6efe  push r11
00007e1ec07d6f00  sub rsp, 0xF0
00007e1ec07d6f07  vmovaps [rsp], xmm0
00007e1ec07d6f0c  vmovaps [rsp+0x10], xmm1
00007e1ec07d6f12  vmovaps [rsp+0x20], xmm2
00007e1ec07d6f18  vmovaps [rsp+0x30], xmm3
00007e1ec07d6f1e  vmovaps [rsp+0x40], xmm4
00007e1ec07d6f24  vmovaps [rsp+0x50], xmm5
00007e1ec07d6f2a  vmovaps [rsp+0x60], xmm6
00007e1ec07d6f30  vmovaps [rsp+0x70], xmm7
00007e1ec07d6f36  vmovaps [rsp+0x80], xmm8
00007e1ec07d6f3f  vmovaps [rsp+0x90], xmm9
00007e1ec07d6f48  vmovaps [rsp+0xA0], xmm10
00007e1ec07d6f51  vmovaps [rsp+0xB0], xmm12
00007e1ec07d6f5a  vmovaps [rsp+0xC0], xmm13
00007e1ec07d6f63  vmovaps [rsp+0xD0], xmm14
00007e1ec07d6f6c  vmovaps [rsp+0xE0], xmm15
00007e1ec07d6f75  sub rsp, 0x30
00007e1ec07d6f79  movaps [rsp], xmm11
00007e1ec07d6f7e  movaps [rsp+0x10], xmm12
00007e1ec07d6f84  movaps [rsp+0x20], xmm15
00007e1ec07d6f8a  lea rdi, [rsp]
00007e1ec07d6f8e  mov esi, 0x00
00007e1ec07d6f93  mov rax, 0x5E00FF778530
00007e1ec07d6f9d  call rax
00007e1ec07d6f9f  movaps xmm11, [rsp]
00007e1ec07d6fa4  add rsp, 0x30
00007e1ec07d6fa8  vmovaps xmm0, [rsp]
00007e1ec07d6fad  vmovaps xmm1, [rsp+0x10]
00007e1ec07d6fb3  vmovaps xmm2, [rsp+0x20]
00007e1ec07d6fb9  vmovaps xmm3, [rsp+0x30]
00007e1ec07d6fbf  vmovaps xmm4, [rsp+0x40]
00007e1ec07d6fc5  vmovaps xmm5, [rsp+0x50]
00007e1ec07d6fcb  vmovaps xmm6, [rsp+0x60]
00007e1ec07d6fd1  vmovaps xmm7, [rsp+0x70]
00007e1ec07d6fd7  vmovaps xmm8, [rsp+0x80]
00007e1ec07d6fe0  vmovaps xmm9, [rsp+0x90]
00007e1ec07d6fe9  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d6ff2  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d6ffb  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d7004  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d700d  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d7016  add rsp, 0xF0
00007e1ec07d701d  pop r11
00007e1ec07d701f  pop r10
00007e1ec07d7021  pop r9
00007e1ec07d7023  pop r8
00007e1ec07d7025  pop rsi
00007e1ec07d7026  pop rdi
00007e1ec07d7027  pop rdx
00007e1ec07d7028  pop rcx
00007e1ec07d7029  pop rax
00007e1ec07d702a  add rsp, 0x08
00007e1ec07d702e  jmp 0x00007E1EC07D327A
00007e1ec07d7033  sub rsp, 0x08
00007e1ec07d7037  push rax
00007e1ec07d7038  push rcx
00007e1ec07d7039  push rdx
00007e1ec07d703a  push rdi
00007e1ec07d703b  push rsi
00007e1ec07d703c  push r8
00007e1ec07d703e  push r9
00007e1ec07d7040  push r10
00007e1ec07d7042  push r11
00007e1ec07d7044  sub rsp, 0xF0
00007e1ec07d704b  vmovaps [rsp], xmm0
00007e1ec07d7050  vmovaps [rsp+0x10], xmm1
00007e1ec07d7056  vmovaps [rsp+0x20], xmm2
00007e1ec07d705c  vmovaps [rsp+0x30], xmm3
00007e1ec07d7062  vmovaps [rsp+0x40], xmm4
00007e1ec07d7068  vmovaps [rsp+0x50], xmm5
00007e1ec07d706e  vmovaps [rsp+0x60], xmm6
00007e1ec07d7074  vmovaps [rsp+0x70], xmm7
00007e1ec07d707a  vmovaps [rsp+0x80], xmm8
00007e1ec07d7083  vmovaps [rsp+0x90], xmm9
00007e1ec07d708c  vmovaps [rsp+0xA0], xmm10
00007e1ec07d7095  vmovaps [rsp+0xB0], xmm11
00007e1ec07d709e  vmovaps [rsp+0xC0], xmm13
00007e1ec07d70a7  vmovaps [rsp+0xD0], xmm14
00007e1ec07d70b0  vmovaps [rsp+0xE0], xmm15
00007e1ec07d70b9  sub rsp, 0x30
00007e1ec07d70bd  movaps [rsp], xmm12
00007e1ec07d70c2  movaps [rsp+0x10], xmm8
00007e1ec07d70c8  movaps [rsp+0x20], xmm15
00007e1ec07d70ce  lea rdi, [rsp]
00007e1ec07d70d2  mov esi, 0x00
00007e1ec07d70d7  mov rax, 0x5E00FF778530
00007e1ec07d70e1  call rax
00007e1ec07d70e3  movaps xmm12, [rsp]
00007e1ec07d70e8  add rsp, 0x30
00007e1ec07d70ec  vmovaps xmm0, [rsp]
00007e1ec07d70f1  vmovaps xmm1, [rsp+0x10]
00007e1ec07d70f7  vmovaps xmm2, [rsp+0x20]
00007e1ec07d70fd  vmovaps xmm3, [rsp+0x30]
00007e1ec07d7103  vmovaps xmm4, [rsp+0x40]
00007e1ec07d7109  vmovaps xmm5, [rsp+0x50]
00007e1ec07d710f  vmovaps xmm6, [rsp+0x60]
00007e1ec07d7115  vmovaps xmm7, [rsp+0x70]
00007e1ec07d711b  vmovaps xmm8, [rsp+0x80]
00007e1ec07d7124  vmovaps xmm9, [rsp+0x90]
00007e1ec07d712d  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d7136  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d713f  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d7148  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d7151  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d715a  add rsp, 0xF0
00007e1ec07d7161  pop r11
00007e1ec07d7163  pop r10
00007e1ec07d7165  pop r9
00007e1ec07d7167  pop r8
00007e1ec07d7169  pop rsi
00007e1ec07d716a  pop rdi
00007e1ec07d716b  pop rdx
00007e1ec07d716c  pop rcx
00007e1ec07d716d  pop rax
00007e1ec07d716e  add rsp, 0x08
00007e1ec07d7172  jmp 0x00007E1EC07D32A9
00007e1ec07d7177  sub rsp, 0x08
00007e1ec07d717b  push rax
00007e1ec07d717c  push rcx
00007e1ec07d717d  push rdx
00007e1ec07d717e  push rdi
00007e1ec07d717f  push rsi
00007e1ec07d7180  push r8
00007e1ec07d7182  push r9
00007e1ec07d7184  push r10
00007e1ec07d7186  push r11
00007e1ec07d7188  sub rsp, 0xF0
00007e1ec07d718f  vmovaps [rsp], xmm0
00007e1ec07d7194  vmovaps [rsp+0x10], xmm1
00007e1ec07d719a  vmovaps [rsp+0x20], xmm2
00007e1ec07d71a0  vmovaps [rsp+0x30], xmm3
00007e1ec07d71a6  vmovaps [rsp+0x40], xmm4
00007e1ec07d71ac  vmovaps [rsp+0x50], xmm5
00007e1ec07d71b2  vmovaps [rsp+0x60], xmm6
00007e1ec07d71b8  vmovaps [rsp+0x70], xmm7
00007e1ec07d71be  vmovaps [rsp+0x80], xmm9
00007e1ec07d71c7  vmovaps [rsp+0x90], xmm10
00007e1ec07d71d0  vmovaps [rsp+0xA0], xmm11
00007e1ec07d71d9  vmovaps [rsp+0xB0], xmm12
00007e1ec07d71e2  vmovaps [rsp+0xC0], xmm13
00007e1ec07d71eb  vmovaps [rsp+0xD0], xmm14
00007e1ec07d71f4  vmovaps [rsp+0xE0], xmm15
00007e1ec07d71fd  sub rsp, 0x30
00007e1ec07d7201  movaps [rsp], xmm8
00007e1ec07d7206  movaps [rsp+0x10], xmm7
00007e1ec07d720b  movaps [rsp+0x20], xmm15
00007e1ec07d7211  lea rdi, [rsp]
00007e1ec07d7215  mov esi, 0x00
00007e1ec07d721a  mov rax, 0x5E00FF778530
00007e1ec07d7224  call rax
00007e1ec07d7226  movaps xmm8, [rsp]
00007e1ec07d722b  add rsp, 0x30
00007e1ec07d722f  vmovaps xmm0, [rsp]
00007e1ec07d7234  vmovaps xmm1, [rsp+0x10]
00007e1ec07d723a  vmovaps xmm2, [rsp+0x20]
00007e1ec07d7240  vmovaps xmm3, [rsp+0x30]
00007e1ec07d7246  vmovaps xmm4, [rsp+0x40]
00007e1ec07d724c  vmovaps xmm5, [rsp+0x50]
00007e1ec07d7252  vmovaps xmm6, [rsp+0x60]
00007e1ec07d7258  vmovaps xmm7, [rsp+0x70]
00007e1ec07d725e  vmovaps xmm9, [rsp+0x80]
00007e1ec07d7267  vmovaps xmm10, [rsp+0x90]
00007e1ec07d7270  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d7279  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d7282  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d728b  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d7294  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d729d  add rsp, 0xF0
00007e1ec07d72a4  pop r11
00007e1ec07d72a6  pop r10
00007e1ec07d72a8  pop r9
00007e1ec07d72aa  pop r8
00007e1ec07d72ac  pop rsi
00007e1ec07d72ad  pop rdi
00007e1ec07d72ae  pop rdx
00007e1ec07d72af  pop rcx
00007e1ec07d72b0  pop rax
00007e1ec07d72b1  add rsp, 0x08
00007e1ec07d72b5  jmp 0x00007E1EC07D32CF
00007e1ec07d72ba  sub rsp, 0x08
00007e1ec07d72be  push rax
00007e1ec07d72bf  push rcx
00007e1ec07d72c0  push rdx
00007e1ec07d72c1  push rdi
00007e1ec07d72c2  push rsi
00007e1ec07d72c3  push r8
00007e1ec07d72c5  push r9
00007e1ec07d72c7  push r10
00007e1ec07d72c9  push r11
00007e1ec07d72cb  sub rsp, 0xF0
00007e1ec07d72d2  vmovaps [rsp], xmm0
00007e1ec07d72d7  vmovaps [rsp+0x10], xmm1
00007e1ec07d72dd  vmovaps [rsp+0x20], xmm2
00007e1ec07d72e3  vmovaps [rsp+0x30], xmm3
00007e1ec07d72e9  vmovaps [rsp+0x40], xmm4
00007e1ec07d72ef  vmovaps [rsp+0x50], xmm5
00007e1ec07d72f5  vmovaps [rsp+0x60], xmm6
00007e1ec07d72fb  vmovaps [rsp+0x70], xmm7
00007e1ec07d7301  vmovaps [rsp+0x80], xmm8
00007e1ec07d730a  vmovaps [rsp+0x90], xmm9
00007e1ec07d7313  vmovaps [rsp+0xA0], xmm10
00007e1ec07d731c  vmovaps [rsp+0xB0], xmm11
00007e1ec07d7325  vmovaps [rsp+0xC0], xmm12
00007e1ec07d732e  vmovaps [rsp+0xD0], xmm13
00007e1ec07d7337  vmovaps [rsp+0xE0], xmm14
00007e1ec07d7340  sub rsp, 0x30
00007e1ec07d7344  movaps [rsp], xmm15
00007e1ec07d7349  movaps [rsp+0x10], xmm14
00007e1ec07d734f  movaps [rsp+0x20], xmm9
00007e1ec07d7355  lea rdi, [rsp]
00007e1ec07d7359  mov esi, 0x00
00007e1ec07d735e  mov rax, 0x5E00FF778530
00007e1ec07d7368  call rax
00007e1ec07d736a  movaps xmm15, [rsp]
00007e1ec07d736f  add rsp, 0x30
00007e1ec07d7373  vmovaps xmm0, [rsp]
00007e1ec07d7378  vmovaps xmm1, [rsp+0x10]
00007e1ec07d737e  vmovaps xmm2, [rsp+0x20]
00007e1ec07d7384  vmovaps xmm3, [rsp+0x30]
00007e1ec07d738a  vmovaps xmm4, [rsp+0x40]
00007e1ec07d7390  vmovaps xmm5, [rsp+0x50]
00007e1ec07d7396  vmovaps xmm6, [rsp+0x60]
00007e1ec07d739c  vmovaps xmm7, [rsp+0x70]
00007e1ec07d73a2  vmovaps xmm8, [rsp+0x80]
00007e1ec07d73ab  vmovaps xmm9, [rsp+0x90]
00007e1ec07d73b4  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d73bd  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d73c6  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d73cf  vmovaps xmm13, [rsp+0xD0]
00007e1ec07d73d8  vmovaps xmm14, [rsp+0xE0]
00007e1ec07d73e1  add rsp, 0xF0
00007e1ec07d73e8  pop r11
00007e1ec07d73ea  pop r10
00007e1ec07d73ec  pop r9
00007e1ec07d73ee  pop r8
00007e1ec07d73f0  pop rsi
00007e1ec07d73f1  pop rdi
00007e1ec07d73f2  pop rdx
00007e1ec07d73f3  pop rcx
00007e1ec07d73f4  pop rax
00007e1ec07d73f5  add rsp, 0x08
00007e1ec07d73f9  jmp 0x00007E1EC07D32E9
00007e1ec07d73fe  sub rsp, 0x08
00007e1ec07d7402  push rax
00007e1ec07d7403  push rcx
00007e1ec07d7404  push rdx
00007e1ec07d7405  push rdi
00007e1ec07d7406  push rsi
00007e1ec07d7407  push r8
00007e1ec07d7409  push r9
00007e1ec07d740b  push r10
00007e1ec07d740d  push r11
00007e1ec07d740f  sub rsp, 0xF0
00007e1ec07d7416  vmovaps [rsp], xmm0
00007e1ec07d741b  vmovaps [rsp+0x10], xmm1
00007e1ec07d7421  vmovaps [rsp+0x20], xmm2
00007e1ec07d7427  vmovaps [rsp+0x30], xmm3
00007e1ec07d742d  vmovaps [rsp+0x40], xmm4
00007e1ec07d7433  vmovaps [rsp+0x50], xmm5
00007e1ec07d7439  vmovaps [rsp+0x60], xmm6
00007e1ec07d743f  vmovaps [rsp+0x70], xmm7
00007e1ec07d7445  vmovaps [rsp+0x80], xmm8
00007e1ec07d744e  vmovaps [rsp+0x90], xmm10
00007e1ec07d7457  vmovaps [rsp+0xA0], xmm11
00007e1ec07d7460  vmovaps [rsp+0xB0], xmm12
00007e1ec07d7469  vmovaps [rsp+0xC0], xmm13
00007e1ec07d7472  vmovaps [rsp+0xD0], xmm14
00007e1ec07d747b  vmovaps [rsp+0xE0], xmm15
00007e1ec07d7484  sub rsp, 0x30
00007e1ec07d7488  movaps [rsp], xmm9
00007e1ec07d748d  movaps [rsp+0x10], xmm7
00007e1ec07d7492  movaps [rsp+0x20], xmm14
00007e1ec07d7498  lea rdi, [rsp]
00007e1ec07d749c  mov esi, 0x00
00007e1ec07d74a1  mov rax, 0x5E00FF778530
00007e1ec07d74ab  call rax
00007e1ec07d74ad  movaps xmm9, [rsp]
00007e1ec07d74b2  add rsp, 0x30
00007e1ec07d74b6  vmovaps xmm0, [rsp]
00007e1ec07d74bb  vmovaps xmm1, [rsp+0x10]
00007e1ec07d74c1  vmovaps xmm2, [rsp+0x20]
00007e1ec07d74c7  vmovaps xmm3, [rsp+0x30]
00007e1ec07d74cd  vmovaps xmm4, [rsp+0x40]
00007e1ec07d74d3  vmovaps xmm5, [rsp+0x50]
00007e1ec07d74d9  vmovaps xmm6, [rsp+0x60]
00007e1ec07d74df  vmovaps xmm7, [rsp+0x70]
00007e1ec07d74e5  vmovaps xmm8, [rsp+0x80]
00007e1ec07d74ee  vmovaps xmm10, [rsp+0x90]
00007e1ec07d74f7  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d7500  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d7509  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d7512  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d751b  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d7524  add rsp, 0xF0
00007e1ec07d752b  pop r11
00007e1ec07d752d  pop r10
00007e1ec07d752f  pop r9
00007e1ec07d7531  pop r8
00007e1ec07d7533  pop rsi
00007e1ec07d7534  pop rdi
00007e1ec07d7535  pop rdx
00007e1ec07d7536  pop rcx
00007e1ec07d7537  pop rax
00007e1ec07d7538  add rsp, 0x08
00007e1ec07d753c  jmp 0x00007E1EC07D3318
00007e1ec07d7541  sub rsp, 0x08
00007e1ec07d7545  push rax
00007e1ec07d7546  push rcx
00007e1ec07d7547  push rdx
00007e1ec07d7548  push rdi
00007e1ec07d7549  push rsi
00007e1ec07d754a  push r8
00007e1ec07d754c  push r9
00007e1ec07d754e  push r10
00007e1ec07d7550  push r11
00007e1ec07d7552  sub rsp, 0xF0
00007e1ec07d7559  vmovaps [rsp], xmm0
00007e1ec07d755e  vmovaps [rsp+0x10], xmm1
00007e1ec07d7564  vmovaps [rsp+0x20], xmm2
00007e1ec07d756a  vmovaps [rsp+0x30], xmm3
00007e1ec07d7570  vmovaps [rsp+0x40], xmm4
00007e1ec07d7576  vmovaps [rsp+0x50], xmm5
00007e1ec07d757c  vmovaps [rsp+0x60], xmm6
00007e1ec07d7582  vmovaps [rsp+0x70], xmm7
00007e1ec07d7588  vmovaps [rsp+0x80], xmm8
00007e1ec07d7591  vmovaps [rsp+0x90], xmm9
00007e1ec07d759a  vmovaps [rsp+0xA0], xmm10
00007e1ec07d75a3  vmovaps [rsp+0xB0], xmm11
00007e1ec07d75ac  vmovaps [rsp+0xC0], xmm12
00007e1ec07d75b5  vmovaps [rsp+0xD0], xmm13
00007e1ec07d75be  vmovaps [rsp+0xE0], xmm15
00007e1ec07d75c7  sub rsp, 0x30
00007e1ec07d75cb  movaps [rsp], xmm14
00007e1ec07d75d0  movaps [rsp+0x10], xmm13
00007e1ec07d75d6  movaps [rsp+0x20], xmm11
00007e1ec07d75dc  lea rdi, [rsp]
00007e1ec07d75e0  mov esi, 0x00
00007e1ec07d75e5  mov rax, 0x5E00FF778530
00007e1ec07d75ef  call rax
00007e1ec07d75f1  movaps xmm14, [rsp]
00007e1ec07d75f6  add rsp, 0x30
00007e1ec07d75fa  vmovaps xmm0, [rsp]
00007e1ec07d75ff  vmovaps xmm1, [rsp+0x10]
00007e1ec07d7605  vmovaps xmm2, [rsp+0x20]
00007e1ec07d760b  vmovaps xmm3, [rsp+0x30]
00007e1ec07d7611  vmovaps xmm4, [rsp+0x40]
00007e1ec07d7617  vmovaps xmm5, [rsp+0x50]
00007e1ec07d761d  vmovaps xmm6, [rsp+0x60]
00007e1ec07d7623  vmovaps xmm7, [rsp+0x70]
00007e1ec07d7629  vmovaps xmm8, [rsp+0x80]
00007e1ec07d7632  vmovaps xmm9, [rsp+0x90]
00007e1ec07d763b  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d7644  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d764d  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d7656  vmovaps xmm13, [rsp+0xD0]
00007e1ec07d765f  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d7668  add rsp, 0xF0
00007e1ec07d766f  pop r11
00007e1ec07d7671  pop r10
00007e1ec07d7673  pop r9
00007e1ec07d7675  pop r8
00007e1ec07d7677  pop rsi
00007e1ec07d7678  pop rdi
00007e1ec07d7679  pop rdx
00007e1ec07d767a  pop rcx
00007e1ec07d767b  pop rax
00007e1ec07d767c  add rsp, 0x08
00007e1ec07d7680  jmp 0x00007E1EC07D3332
00007e1ec07d7685  sub rsp, 0x08
00007e1ec07d7689  push rax
00007e1ec07d768a  push rcx
00007e1ec07d768b  push rdx
00007e1ec07d768c  push rdi
00007e1ec07d768d  push rsi
00007e1ec07d768e  push r8
00007e1ec07d7690  push r9
00007e1ec07d7692  push r10
00007e1ec07d7694  push r11
00007e1ec07d7696  sub rsp, 0xF0
00007e1ec07d769d  vmovaps [rsp], xmm0
00007e1ec07d76a2  vmovaps [rsp+0x10], xmm1
00007e1ec07d76a8  vmovaps [rsp+0x20], xmm2
00007e1ec07d76ae  vmovaps [rsp+0x30], xmm3
00007e1ec07d76b4  vmovaps [rsp+0x40], xmm4
00007e1ec07d76ba  vmovaps [rsp+0x50], xmm5
00007e1ec07d76c0  vmovaps [rsp+0x60], xmm6
00007e1ec07d76c6  vmovaps [rsp+0x70], xmm7
00007e1ec07d76cc  vmovaps [rsp+0x80], xmm8
00007e1ec07d76d5  vmovaps [rsp+0x90], xmm9
00007e1ec07d76de  vmovaps [rsp+0xA0], xmm10
00007e1ec07d76e7  vmovaps [rsp+0xB0], xmm12
00007e1ec07d76f0  vmovaps [rsp+0xC0], xmm13
00007e1ec07d76f9  vmovaps [rsp+0xD0], xmm14
00007e1ec07d7702  vmovaps [rsp+0xE0], xmm15
00007e1ec07d770b  sub rsp, 0x30
00007e1ec07d770f  movaps [rsp], xmm11
00007e1ec07d7714  movaps [rsp+0x10], xmm7
00007e1ec07d7719  movaps [rsp+0x20], xmm13
00007e1ec07d771f  lea rdi, [rsp]
00007e1ec07d7723  mov esi, 0x00
00007e1ec07d7728  mov rax, 0x5E00FF778530
00007e1ec07d7732  call rax
00007e1ec07d7734  movaps xmm11, [rsp]
00007e1ec07d7739  add rsp, 0x30
00007e1ec07d773d  vmovaps xmm0, [rsp]
00007e1ec07d7742  vmovaps xmm1, [rsp+0x10]
00007e1ec07d7748  vmovaps xmm2, [rsp+0x20]
00007e1ec07d774e  vmovaps xmm3, [rsp+0x30]
00007e1ec07d7754  vmovaps xmm4, [rsp+0x40]
00007e1ec07d775a  vmovaps xmm5, [rsp+0x50]
00007e1ec07d7760  vmovaps xmm6, [rsp+0x60]
00007e1ec07d7766  vmovaps xmm7, [rsp+0x70]
00007e1ec07d776c  vmovaps xmm8, [rsp+0x80]
00007e1ec07d7775  vmovaps xmm9, [rsp+0x90]
00007e1ec07d777e  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d7787  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d7790  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d7799  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d77a2  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d77ab  add rsp, 0xF0
00007e1ec07d77b2  pop r11
00007e1ec07d77b4  pop r10
00007e1ec07d77b6  pop r9
00007e1ec07d77b8  pop r8
00007e1ec07d77ba  pop rsi
00007e1ec07d77bb  pop rdi
00007e1ec07d77bc  pop rdx
00007e1ec07d77bd  pop rcx
00007e1ec07d77be  pop rax
00007e1ec07d77bf  add rsp, 0x08
00007e1ec07d77c3  jmp 0x00007E1EC07D335E
00007e1ec07d77c8  sub rsp, 0x08
00007e1ec07d77cc  push rax
00007e1ec07d77cd  push rcx
00007e1ec07d77ce  push rdx
00007e1ec07d77cf  push rdi
00007e1ec07d77d0  push rsi
00007e1ec07d77d1  push r8
00007e1ec07d77d3  push r9
00007e1ec07d77d5  push r10
00007e1ec07d77d7  push r11
00007e1ec07d77d9  sub rsp, 0xF0
00007e1ec07d77e0  vmovaps [rsp], xmm0
00007e1ec07d77e5  vmovaps [rsp+0x10], xmm1
00007e1ec07d77eb  vmovaps [rsp+0x20], xmm2
00007e1ec07d77f1  vmovaps [rsp+0x30], xmm3
00007e1ec07d77f7  vmovaps [rsp+0x40], xmm4
00007e1ec07d77fd  vmovaps [rsp+0x50], xmm5
00007e1ec07d7803  vmovaps [rsp+0x60], xmm6
00007e1ec07d7809  vmovaps [rsp+0x70], xmm7
00007e1ec07d780f  vmovaps [rsp+0x80], xmm8
00007e1ec07d7818  vmovaps [rsp+0x90], xmm9
00007e1ec07d7821  vmovaps [rsp+0xA0], xmm10
00007e1ec07d782a  vmovaps [rsp+0xB0], xmm11
00007e1ec07d7833  vmovaps [rsp+0xC0], xmm12
00007e1ec07d783c  vmovaps [rsp+0xD0], xmm14
00007e1ec07d7845  vmovaps [rsp+0xE0], xmm15
00007e1ec07d784e  sub rsp, 0x30
00007e1ec07d7852  movaps [rsp], xmm13
00007e1ec07d7857  movaps [rsp+0x10], xmm10
00007e1ec07d785d  movaps [rsp+0x20], xmm12
00007e1ec07d7863  lea rdi, [rsp]
00007e1ec07d7867  mov esi, 0x00
00007e1ec07d786c  mov rax, 0x5E00FF778530
00007e1ec07d7876  call rax
00007e1ec07d7878  movaps xmm13, [rsp]
00007e1ec07d787d  add rsp, 0x30
00007e1ec07d7881  vmovaps xmm0, [rsp]
00007e1ec07d7886  vmovaps xmm1, [rsp+0x10]
00007e1ec07d788c  vmovaps xmm2, [rsp+0x20]
00007e1ec07d7892  vmovaps xmm3, [rsp+0x30]
00007e1ec07d7898  vmovaps xmm4, [rsp+0x40]
00007e1ec07d789e  vmovaps xmm5, [rsp+0x50]
00007e1ec07d78a4  vmovaps xmm6, [rsp+0x60]
00007e1ec07d78aa  vmovaps xmm7, [rsp+0x70]
00007e1ec07d78b0  vmovaps xmm8, [rsp+0x80]
00007e1ec07d78b9  vmovaps xmm9, [rsp+0x90]
00007e1ec07d78c2  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d78cb  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d78d4  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d78dd  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d78e6  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d78ef  add rsp, 0xF0
00007e1ec07d78f6  pop r11
00007e1ec07d78f8  pop r10
00007e1ec07d78fa  pop r9
00007e1ec07d78fc  pop r8
00007e1ec07d78fe  pop rsi
00007e1ec07d78ff  pop rdi
00007e1ec07d7900  pop rdx
00007e1ec07d7901  pop rcx
00007e1ec07d7902  pop rax
00007e1ec07d7903  add rsp, 0x08
00007e1ec07d7907  jmp 0x00007E1EC07D3378
00007e1ec07d790c  sub rsp, 0x08
00007e1ec07d7910  push rax
00007e1ec07d7911  push rcx
00007e1ec07d7912  push rdx
00007e1ec07d7913  push rdi
00007e1ec07d7914  push rsi
00007e1ec07d7915  push r8
00007e1ec07d7917  push r9
00007e1ec07d7919  push r10
00007e1ec07d791b  push r11
00007e1ec07d791d  sub rsp, 0xF0
00007e1ec07d7924  vmovaps [rsp], xmm0
00007e1ec07d7929  vmovaps [rsp+0x10], xmm1
00007e1ec07d792f  vmovaps [rsp+0x20], xmm2
00007e1ec07d7935  vmovaps [rsp+0x30], xmm3
00007e1ec07d793b  vmovaps [rsp+0x40], xmm4
00007e1ec07d7941  vmovaps [rsp+0x50], xmm5
00007e1ec07d7947  vmovaps [rsp+0x60], xmm6
00007e1ec07d794d  vmovaps [rsp+0x70], xmm7
00007e1ec07d7953  vmovaps [rsp+0x80], xmm8
00007e1ec07d795c  vmovaps [rsp+0x90], xmm9
00007e1ec07d7965  vmovaps [rsp+0xA0], xmm11
00007e1ec07d796e  vmovaps [rsp+0xB0], xmm12
00007e1ec07d7977  vmovaps [rsp+0xC0], xmm13
00007e1ec07d7980  vmovaps [rsp+0xD0], xmm14
00007e1ec07d7989  vmovaps [rsp+0xE0], xmm15
00007e1ec07d7992  sub rsp, 0x30
00007e1ec07d7996  movaps [rsp], xmm10
00007e1ec07d799b  movaps [rsp+0x10], xmm7
00007e1ec07d79a0  movaps [rsp+0x20], xmm12
00007e1ec07d79a6  lea rdi, [rsp]
00007e1ec07d79aa  mov esi, 0x00
00007e1ec07d79af  mov rax, 0x5E00FF778530
00007e1ec07d79b9  call rax
00007e1ec07d79bb  movaps xmm10, [rsp]
00007e1ec07d79c0  add rsp, 0x30
00007e1ec07d79c4  vmovaps xmm0, [rsp]
00007e1ec07d79c9  vmovaps xmm1, [rsp+0x10]
00007e1ec07d79cf  vmovaps xmm2, [rsp+0x20]
00007e1ec07d79d5  vmovaps xmm3, [rsp+0x30]
00007e1ec07d79db  vmovaps xmm4, [rsp+0x40]
00007e1ec07d79e1  vmovaps xmm5, [rsp+0x50]
00007e1ec07d79e7  vmovaps xmm6, [rsp+0x60]
00007e1ec07d79ed  vmovaps xmm7, [rsp+0x70]
00007e1ec07d79f3  vmovaps xmm8, [rsp+0x80]
00007e1ec07d79fc  vmovaps xmm9, [rsp+0x90]
00007e1ec07d7a05  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d7a0e  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d7a17  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d7a20  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d7a29  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d7a32  add rsp, 0xF0
00007e1ec07d7a39  pop r11
00007e1ec07d7a3b  pop r10
00007e1ec07d7a3d  pop r9
00007e1ec07d7a3f  pop r8
00007e1ec07d7a41  pop rsi
00007e1ec07d7a42  pop rdi
00007e1ec07d7a43  pop rdx
00007e1ec07d7a44  pop rcx
00007e1ec07d7a45  pop rax
00007e1ec07d7a46  add rsp, 0x08
00007e1ec07d7a4a  jmp 0x00007E1EC07D33A4
00007e1ec07d7a4f  sub rsp, 0x08
00007e1ec07d7a53  push rax
00007e1ec07d7a54  push rcx
00007e1ec07d7a55  push rdx
00007e1ec07d7a56  push rdi
00007e1ec07d7a57  push rsi
00007e1ec07d7a58  push r8
00007e1ec07d7a5a  push r9
00007e1ec07d7a5c  push r10
00007e1ec07d7a5e  push r11
00007e1ec07d7a60  sub rsp, 0xF0
00007e1ec07d7a67  vmovaps [rsp], xmm0
00007e1ec07d7a6c  vmovaps [rsp+0x10], xmm1
00007e1ec07d7a72  vmovaps [rsp+0x20], xmm2
00007e1ec07d7a78  vmovaps [rsp+0x30], xmm3
00007e1ec07d7a7e  vmovaps [rsp+0x40], xmm4
00007e1ec07d7a84  vmovaps [rsp+0x50], xmm5
00007e1ec07d7a8a  vmovaps [rsp+0x60], xmm6
00007e1ec07d7a90  vmovaps [rsp+0x70], xmm7
00007e1ec07d7a96  vmovaps [rsp+0x80], xmm8
00007e1ec07d7a9f  vmovaps [rsp+0x90], xmm9
00007e1ec07d7aa8  vmovaps [rsp+0xA0], xmm10
00007e1ec07d7ab1  vmovaps [rsp+0xB0], xmm11
00007e1ec07d7aba  vmovaps [rsp+0xC0], xmm13
00007e1ec07d7ac3  vmovaps [rsp+0xD0], xmm14
00007e1ec07d7acc  vmovaps [rsp+0xE0], xmm15
00007e1ec07d7ad5  sub rsp, 0x30
00007e1ec07d7ad9  movaps [rsp], xmm12
00007e1ec07d7ade  movaps [rsp+0x10], xmm1
00007e1ec07d7ae3  movaps [rsp+0x20], xmm8
00007e1ec07d7ae9  lea rdi, [rsp]
00007e1ec07d7aed  mov esi, 0x00
00007e1ec07d7af2  mov rax, 0x5E00FF778530
00007e1ec07d7afc  call rax
00007e1ec07d7afe  movaps xmm12, [rsp]
00007e1ec07d7b03  add rsp, 0x30
00007e1ec07d7b07  vmovaps xmm0, [rsp]
00007e1ec07d7b0c  vmovaps xmm1, [rsp+0x10]
00007e1ec07d7b12  vmovaps xmm2, [rsp+0x20]
00007e1ec07d7b18  vmovaps xmm3, [rsp+0x30]
00007e1ec07d7b1e  vmovaps xmm4, [rsp+0x40]
00007e1ec07d7b24  vmovaps xmm5, [rsp+0x50]
00007e1ec07d7b2a  vmovaps xmm6, [rsp+0x60]
00007e1ec07d7b30  vmovaps xmm7, [rsp+0x70]
00007e1ec07d7b36  vmovaps xmm8, [rsp+0x80]
00007e1ec07d7b3f  vmovaps xmm9, [rsp+0x90]
00007e1ec07d7b48  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d7b51  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d7b5a  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d7b63  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d7b6c  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d7b75  add rsp, 0xF0
00007e1ec07d7b7c  pop r11
00007e1ec07d7b7e  pop r10
00007e1ec07d7b80  pop r9
00007e1ec07d7b82  pop r8
00007e1ec07d7b84  pop rsi
00007e1ec07d7b85  pop rdi
00007e1ec07d7b86  pop rdx
00007e1ec07d7b87  pop rcx
00007e1ec07d7b88  pop rax
00007e1ec07d7b89  add rsp, 0x08
00007e1ec07d7b8d  jmp 0x00007E1EC07D33BE
00007e1ec07d7b92  call 0x00007E1EC05FF430
00007e1ec07d7b97  jmp 0x00007E1EC07D33C8
00007e1ec07d7b9c  sub rsp, 0x08
00007e1ec07d7ba0  push rax
00007e1ec07d7ba1  push rcx
00007e1ec07d7ba2  push rdx
00007e1ec07d7ba3  push rdi
00007e1ec07d7ba4  push rsi
00007e1ec07d7ba5  push r8
00007e1ec07d7ba7  push r9
00007e1ec07d7ba9  push r10
00007e1ec07d7bab  push r11
00007e1ec07d7bad  sub rsp, 0xF0
00007e1ec07d7bb4  vmovaps [rsp], xmm0
00007e1ec07d7bb9  vmovaps [rsp+0x10], xmm1
00007e1ec07d7bbf  vmovaps [rsp+0x20], xmm2
00007e1ec07d7bc5  vmovaps [rsp+0x30], xmm3
00007e1ec07d7bcb  vmovaps [rsp+0x40], xmm4
00007e1ec07d7bd1  vmovaps [rsp+0x50], xmm5
00007e1ec07d7bd7  vmovaps [rsp+0x60], xmm6
00007e1ec07d7bdd  vmovaps [rsp+0x70], xmm7
00007e1ec07d7be3  vmovaps [rsp+0x80], xmm9
00007e1ec07d7bec  vmovaps [rsp+0x90], xmm10
00007e1ec07d7bf5  vmovaps [rsp+0xA0], xmm11
00007e1ec07d7bfe  vmovaps [rsp+0xB0], xmm12
00007e1ec07d7c07  vmovaps [rsp+0xC0], xmm13
00007e1ec07d7c10  vmovaps [rsp+0xD0], xmm14
00007e1ec07d7c19  vmovaps [rsp+0xE0], xmm15
00007e1ec07d7c22  sub rsp, 0x30
00007e1ec07d7c26  movaps [rsp], xmm8
00007e1ec07d7c2b  movaps [rsp+0x10], xmm15
00007e1ec07d7c31  movaps [rsp+0x20], xmm9
00007e1ec07d7c37  lea rdi, [rsp]
00007e1ec07d7c3b  mov esi, 0x00
00007e1ec07d7c40  mov rax, 0x5E00FF778530
00007e1ec07d7c4a  call rax
00007e1ec07d7c4c  movaps xmm8, [rsp]
00007e1ec07d7c51  add rsp, 0x30
00007e1ec07d7c55  vmovaps xmm0, [rsp]
00007e1ec07d7c5a  vmovaps xmm1, [rsp+0x10]
00007e1ec07d7c60  vmovaps xmm2, [rsp+0x20]
00007e1ec07d7c66  vmovaps xmm3, [rsp+0x30]
00007e1ec07d7c6c  vmovaps xmm4, [rsp+0x40]
00007e1ec07d7c72  vmovaps xmm5, [rsp+0x50]
00007e1ec07d7c78  vmovaps xmm6, [rsp+0x60]
00007e1ec07d7c7e  vmovaps xmm7, [rsp+0x70]
00007e1ec07d7c84  vmovaps xmm9, [rsp+0x80]
00007e1ec07d7c8d  vmovaps xmm10, [rsp+0x90]
00007e1ec07d7c96  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d7c9f  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d7ca8  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d7cb1  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d7cba  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d7cc3  add rsp, 0xF0
00007e1ec07d7cca  pop r11
00007e1ec07d7ccc  pop r10
00007e1ec07d7cce  pop r9
00007e1ec07d7cd0  pop r8
00007e1ec07d7cd2  pop rsi
00007e1ec07d7cd3  pop rdi
00007e1ec07d7cd4  pop rdx
00007e1ec07d7cd5  pop rcx
00007e1ec07d7cd6  pop rax
00007e1ec07d7cd7  add rsp, 0x08
00007e1ec07d7cdb  jmp 0x00007E1EC07D33EA
00007e1ec07d7ce0  sub rsp, 0x08
00007e1ec07d7ce4  push rax
00007e1ec07d7ce5  push rcx
00007e1ec07d7ce6  push rdx
00007e1ec07d7ce7  push rdi
00007e1ec07d7ce8  push rsi
00007e1ec07d7ce9  push r8
00007e1ec07d7ceb  push r9
00007e1ec07d7ced  push r10
00007e1ec07d7cef  push r11
00007e1ec07d7cf1  sub rsp, 0xF0
00007e1ec07d7cf8  vmovaps [rsp], xmm0
00007e1ec07d7cfd  vmovaps [rsp+0x10], xmm1
00007e1ec07d7d03  vmovaps [rsp+0x20], xmm2
00007e1ec07d7d09  vmovaps [rsp+0x30], xmm3
00007e1ec07d7d0f  vmovaps [rsp+0x40], xmm4
00007e1ec07d7d15  vmovaps [rsp+0x50], xmm5
00007e1ec07d7d1b  vmovaps [rsp+0x60], xmm6
00007e1ec07d7d21  vmovaps [rsp+0x70], xmm7
00007e1ec07d7d27  vmovaps [rsp+0x80], xmm8
00007e1ec07d7d30  vmovaps [rsp+0x90], xmm10
00007e1ec07d7d39  vmovaps [rsp+0xA0], xmm11
00007e1ec07d7d42  vmovaps [rsp+0xB0], xmm12
00007e1ec07d7d4b  vmovaps [rsp+0xC0], xmm13
00007e1ec07d7d54  vmovaps [rsp+0xD0], xmm14
00007e1ec07d7d5d  vmovaps [rsp+0xE0], xmm15
00007e1ec07d7d66  sub rsp, 0x30
00007e1ec07d7d6a  movaps [rsp], xmm9
00007e1ec07d7d6f  movaps [rsp+0x10], xmm1
00007e1ec07d7d74  movaps [rsp+0x20], xmm15
00007e1ec07d7d7a  lea rdi, [rsp]
00007e1ec07d7d7e  mov esi, 0x00
00007e1ec07d7d83  mov rax, 0x5E00FF778530
00007e1ec07d7d8d  call rax
00007e1ec07d7d8f  movaps xmm9, [rsp]
00007e1ec07d7d94  add rsp, 0x30
00007e1ec07d7d98  vmovaps xmm0, [rsp]
00007e1ec07d7d9d  vmovaps xmm1, [rsp+0x10]
00007e1ec07d7da3  vmovaps xmm2, [rsp+0x20]
00007e1ec07d7da9  vmovaps xmm3, [rsp+0x30]
00007e1ec07d7daf  vmovaps xmm4, [rsp+0x40]
00007e1ec07d7db5  vmovaps xmm5, [rsp+0x50]
00007e1ec07d7dbb  vmovaps xmm6, [rsp+0x60]
00007e1ec07d7dc1  vmovaps xmm7, [rsp+0x70]
00007e1ec07d7dc7  vmovaps xmm8, [rsp+0x80]
00007e1ec07d7dd0  vmovaps xmm10, [rsp+0x90]
00007e1ec07d7dd9  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d7de2  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d7deb  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d7df4  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d7dfd  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d7e06  add rsp, 0xF0
00007e1ec07d7e0d  pop r11
00007e1ec07d7e0f  pop r10
00007e1ec07d7e11  pop r9
00007e1ec07d7e13  pop r8
00007e1ec07d7e15  pop rsi
00007e1ec07d7e16  pop rdi
00007e1ec07d7e17  pop rdx
00007e1ec07d7e18  pop rcx
00007e1ec07d7e19  pop rax
00007e1ec07d7e1a  add rsp, 0x08
00007e1ec07d7e1e  jmp 0x00007E1EC07D3418
00007e1ec07d7e23  sub rsp, 0x08
00007e1ec07d7e27  push rax
00007e1ec07d7e28  push rcx
00007e1ec07d7e29  push rdx
00007e1ec07d7e2a  push rdi
00007e1ec07d7e2b  push rsi
00007e1ec07d7e2c  push r8
00007e1ec07d7e2e  push r9
00007e1ec07d7e30  push r10
00007e1ec07d7e32  push r11
00007e1ec07d7e34  sub rsp, 0xF0
00007e1ec07d7e3b  vmovaps [rsp], xmm0
00007e1ec07d7e40  vmovaps [rsp+0x10], xmm1
00007e1ec07d7e46  vmovaps [rsp+0x20], xmm2
00007e1ec07d7e4c  vmovaps [rsp+0x30], xmm3
00007e1ec07d7e52  vmovaps [rsp+0x40], xmm4
00007e1ec07d7e58  vmovaps [rsp+0x50], xmm5
00007e1ec07d7e5e  vmovaps [rsp+0x60], xmm6
00007e1ec07d7e64  vmovaps [rsp+0x70], xmm7
00007e1ec07d7e6a  vmovaps [rsp+0x80], xmm8
00007e1ec07d7e73  vmovaps [rsp+0x90], xmm9
00007e1ec07d7e7c  vmovaps [rsp+0xA0], xmm10
00007e1ec07d7e85  vmovaps [rsp+0xB0], xmm11
00007e1ec07d7e8e  vmovaps [rsp+0xC0], xmm12
00007e1ec07d7e97  vmovaps [rsp+0xD0], xmm13
00007e1ec07d7ea0  vmovaps [rsp+0xE0], xmm14
00007e1ec07d7ea9  sub rsp, 0x30
00007e1ec07d7ead  movaps [rsp], xmm15
00007e1ec07d7eb2  movaps [rsp+0x10], xmm4
00007e1ec07d7eb7  movaps [rsp+0x20], xmm1
00007e1ec07d7ebc  lea rdi, [rsp]
00007e1ec07d7ec0  mov esi, 0x00
00007e1ec07d7ec5  mov rax, 0x5E00FF778530
00007e1ec07d7ecf  call rax
00007e1ec07d7ed1  movaps xmm15, [rsp]
00007e1ec07d7ed6  add rsp, 0x30
00007e1ec07d7eda  vmovaps xmm0, [rsp]
00007e1ec07d7edf  vmovaps xmm1, [rsp+0x10]
00007e1ec07d7ee5  vmovaps xmm2, [rsp+0x20]
00007e1ec07d7eeb  vmovaps xmm3, [rsp+0x30]
00007e1ec07d7ef1  vmovaps xmm4, [rsp+0x40]
00007e1ec07d7ef7  vmovaps xmm5, [rsp+0x50]
00007e1ec07d7efd  vmovaps xmm6, [rsp+0x60]
00007e1ec07d7f03  vmovaps xmm7, [rsp+0x70]
00007e1ec07d7f09  vmovaps xmm8, [rsp+0x80]
00007e1ec07d7f12  vmovaps xmm9, [rsp+0x90]
00007e1ec07d7f1b  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d7f24  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d7f2d  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d7f36  vmovaps xmm13, [rsp+0xD0]
00007e1ec07d7f3f  vmovaps xmm14, [rsp+0xE0]
00007e1ec07d7f48  add rsp, 0xF0
00007e1ec07d7f4f  pop r11
00007e1ec07d7f51  pop r10
00007e1ec07d7f53  pop r9
00007e1ec07d7f55  pop r8
00007e1ec07d7f57  pop rsi
00007e1ec07d7f58  pop rdi
00007e1ec07d7f59  pop rdx
00007e1ec07d7f5a  pop rcx
00007e1ec07d7f5b  pop rax
00007e1ec07d7f5c  add rsp, 0x08
00007e1ec07d7f60  jmp 0x00007E1EC07D343E
00007e1ec07d7f65  sub rsp, 0x08
00007e1ec07d7f69  push rax
00007e1ec07d7f6a  push rcx
00007e1ec07d7f6b  push rdx
00007e1ec07d7f6c  push rdi
00007e1ec07d7f6d  push rsi
00007e1ec07d7f6e  push r8
00007e1ec07d7f70  push r9
00007e1ec07d7f72  push r10
00007e1ec07d7f74  push r11
00007e1ec07d7f76  sub rsp, 0xF0
00007e1ec07d7f7d  vmovaps [rsp], xmm0
00007e1ec07d7f82  vmovaps [rsp+0x10], xmm2
00007e1ec07d7f88  vmovaps [rsp+0x20], xmm3
00007e1ec07d7f8e  vmovaps [rsp+0x30], xmm4
00007e1ec07d7f94  vmovaps [rsp+0x40], xmm5
00007e1ec07d7f9a  vmovaps [rsp+0x50], xmm6
00007e1ec07d7fa0  vmovaps [rsp+0x60], xmm7
00007e1ec07d7fa6  vmovaps [rsp+0x70], xmm8
00007e1ec07d7fac  vmovaps [rsp+0x80], xmm9
00007e1ec07d7fb5  vmovaps [rsp+0x90], xmm10
00007e1ec07d7fbe  vmovaps [rsp+0xA0], xmm11
00007e1ec07d7fc7  vmovaps [rsp+0xB0], xmm12
00007e1ec07d7fd0  vmovaps [rsp+0xC0], xmm13
00007e1ec07d7fd9  vmovaps [rsp+0xD0], xmm14
00007e1ec07d7fe2  vmovaps [rsp+0xE0], xmm15
00007e1ec07d7feb  sub rsp, 0x30
00007e1ec07d7fef  movaps [rsp], xmm1
00007e1ec07d7ff3  movaps [rsp+0x10], xmm14
00007e1ec07d7ff9  movaps [rsp+0x20], xmm11
00007e1ec07d7fff  lea rdi, [rsp]
00007e1ec07d8003  mov esi, 0x00
00007e1ec07d8008  mov rax, 0x5E00FF778530
00007e1ec07d8012  call rax
00007e1ec07d8014  movaps xmm1, [rsp]
00007e1ec07d8018  add rsp, 0x30
00007e1ec07d801c  vmovaps xmm0, [rsp]
00007e1ec07d8021  vmovaps xmm2, [rsp+0x10]
00007e1ec07d8027  vmovaps xmm3, [rsp+0x20]
00007e1ec07d802d  vmovaps xmm4, [rsp+0x30]
00007e1ec07d8033  vmovaps xmm5, [rsp+0x40]
00007e1ec07d8039  vmovaps xmm6, [rsp+0x50]
00007e1ec07d803f  vmovaps xmm7, [rsp+0x60]
00007e1ec07d8045  vmovaps xmm8, [rsp+0x70]
00007e1ec07d804b  vmovaps xmm9, [rsp+0x80]
00007e1ec07d8054  vmovaps xmm10, [rsp+0x90]
00007e1ec07d805d  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d8066  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d806f  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d8078  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d8081  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d808a  add rsp, 0xF0
00007e1ec07d8091  pop r11
00007e1ec07d8093  pop r10
00007e1ec07d8095  pop r9
00007e1ec07d8097  pop r8
00007e1ec07d8099  pop rsi
00007e1ec07d809a  pop rdi
00007e1ec07d809b  pop rdx
00007e1ec07d809c  pop rcx
00007e1ec07d809d  pop rax
00007e1ec07d809e  add rsp, 0x08
00007e1ec07d80a2  jmp 0x00007E1EC07D345F
00007e1ec07d80a7  call 0x00007E1EC06E45A0
00007e1ec07d80ac  jmp 0x00007E1EC07D346D
00007e1ec07d80b1  call 0x00007E1EC0609D70
00007e1ec07d80b6  jmp 0x00007E1EC07D3477
00007e1ec07d80bb  sub rsp, 0x08
00007e1ec07d80bf  push rax
00007e1ec07d80c0  push rcx
00007e1ec07d80c1  push rdx
00007e1ec07d80c2  push rdi
00007e1ec07d80c3  push rsi
00007e1ec07d80c4  push r8
00007e1ec07d80c6  push r9
00007e1ec07d80c8  push r10
00007e1ec07d80ca  push r11
00007e1ec07d80cc  sub rsp, 0xF0
00007e1ec07d80d3  vmovaps [rsp], xmm0
00007e1ec07d80d8  vmovaps [rsp+0x10], xmm1
00007e1ec07d80de  vmovaps [rsp+0x20], xmm2
00007e1ec07d80e4  vmovaps [rsp+0x30], xmm3
00007e1ec07d80ea  vmovaps [rsp+0x40], xmm4
00007e1ec07d80f0  vmovaps [rsp+0x50], xmm5
00007e1ec07d80f6  vmovaps [rsp+0x60], xmm6
00007e1ec07d80fc  vmovaps [rsp+0x70], xmm8
00007e1ec07d8102  vmovaps [rsp+0x80], xmm9
00007e1ec07d810b  vmovaps [rsp+0x90], xmm10
00007e1ec07d8114  vmovaps [rsp+0xA0], xmm11
00007e1ec07d811d  vmovaps [rsp+0xB0], xmm12
00007e1ec07d8126  vmovaps [rsp+0xC0], xmm13
00007e1ec07d812f  vmovaps [rsp+0xD0], xmm14
00007e1ec07d8138  vmovaps [rsp+0xE0], xmm15
00007e1ec07d8141  sub rsp, 0x30
00007e1ec07d8145  movaps [rsp], xmm7
00007e1ec07d8149  movaps [rsp+0x10], xmm13
00007e1ec07d814f  movaps [rsp+0x20], xmm10
00007e1ec07d8155  lea rdi, [rsp]
00007e1ec07d8159  mov esi, 0x00
00007e1ec07d815e  mov rax, 0x5E00FF778530
00007e1ec07d8168  call rax
00007e1ec07d816a  movaps xmm7, [rsp]
00007e1ec07d816e  add rsp, 0x30
00007e1ec07d8172  vmovaps xmm0, [rsp]
00007e1ec07d8177  vmovaps xmm1, [rsp+0x10]
00007e1ec07d817d  vmovaps xmm2, [rsp+0x20]
00007e1ec07d8183  vmovaps xmm3, [rsp+0x30]
00007e1ec07d8189  vmovaps xmm4, [rsp+0x40]
00007e1ec07d818f  vmovaps xmm5, [rsp+0x50]
00007e1ec07d8195  vmovaps xmm6, [rsp+0x60]
00007e1ec07d819b  vmovaps xmm8, [rsp+0x70]
00007e1ec07d81a1  vmovaps xmm9, [rsp+0x80]
00007e1ec07d81aa  vmovaps xmm10, [rsp+0x90]
00007e1ec07d81b3  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d81bc  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d81c5  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d81ce  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d81d7  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d81e0  add rsp, 0xF0
00007e1ec07d81e7  pop r11
00007e1ec07d81e9  pop r10
00007e1ec07d81eb  pop r9
00007e1ec07d81ed  pop r8
00007e1ec07d81ef  pop rsi
00007e1ec07d81f0  pop rdi
00007e1ec07d81f1  pop rdx
00007e1ec07d81f2  pop rcx
00007e1ec07d81f3  pop rax
00007e1ec07d81f4  add rsp, 0x08
00007e1ec07d81f8  jmp 0x00007E1EC07D3498
00007e1ec07d81fd  sub rsp, 0x08
00007e1ec07d8201  push rax
00007e1ec07d8202  push rcx
00007e1ec07d8203  push rdx
00007e1ec07d8204  push rdi
00007e1ec07d8205  push rsi
00007e1ec07d8206  push r8
00007e1ec07d8208  push r9
00007e1ec07d820a  push r10
00007e1ec07d820c  push r11
00007e1ec07d820e  sub rsp, 0xF0
00007e1ec07d8215  vmovaps [rsp], xmm0
00007e1ec07d821a  vmovaps [rsp+0x10], xmm1
00007e1ec07d8220  vmovaps [rsp+0x20], xmm2
00007e1ec07d8226  vmovaps [rsp+0x30], xmm3
00007e1ec07d822c  vmovaps [rsp+0x40], xmm4
00007e1ec07d8232  vmovaps [rsp+0x50], xmm5
00007e1ec07d8238  vmovaps [rsp+0x60], xmm6
00007e1ec07d823e  vmovaps [rsp+0x70], xmm7
00007e1ec07d8244  vmovaps [rsp+0x80], xmm8
00007e1ec07d824d  vmovaps [rsp+0x90], xmm9
00007e1ec07d8256  vmovaps [rsp+0xA0], xmm11
00007e1ec07d825f  vmovaps [rsp+0xB0], xmm12
00007e1ec07d8268  vmovaps [rsp+0xC0], xmm13
00007e1ec07d8271  vmovaps [rsp+0xD0], xmm14
00007e1ec07d827a  vmovaps [rsp+0xE0], xmm15
00007e1ec07d8283  sub rsp, 0x30
00007e1ec07d8287  movaps [rsp], xmm10
00007e1ec07d828c  movaps [rsp+0x10], xmm11
00007e1ec07d8292  movaps [rsp+0x20], xmm13
00007e1ec07d8298  lea rdi, [rsp]
00007e1ec07d829c  mov esi, 0x00
00007e1ec07d82a1  mov rax, 0x5E00FF778530
00007e1ec07d82ab  call rax
00007e1ec07d82ad  movaps xmm10, [rsp]
00007e1ec07d82b2  add rsp, 0x30
00007e1ec07d82b6  vmovaps xmm0, [rsp]
00007e1ec07d82bb  vmovaps xmm1, [rsp+0x10]
00007e1ec07d82c1  vmovaps xmm2, [rsp+0x20]
00007e1ec07d82c7  vmovaps xmm3, [rsp+0x30]
00007e1ec07d82cd  vmovaps xmm4, [rsp+0x40]
00007e1ec07d82d3  vmovaps xmm5, [rsp+0x50]
00007e1ec07d82d9  vmovaps xmm6, [rsp+0x60]
00007e1ec07d82df  vmovaps xmm7, [rsp+0x70]
00007e1ec07d82e5  vmovaps xmm8, [rsp+0x80]
00007e1ec07d82ee  vmovaps xmm9, [rsp+0x90]
00007e1ec07d82f7  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d8300  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d8309  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d8312  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d831b  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d8324  add rsp, 0xF0
00007e1ec07d832b  pop r11
00007e1ec07d832d  pop r10
00007e1ec07d832f  pop r9
00007e1ec07d8331  pop r8
00007e1ec07d8333  pop rsi
00007e1ec07d8334  pop rdi
00007e1ec07d8335  pop rdx
00007e1ec07d8336  pop rcx
00007e1ec07d8337  pop rax
00007e1ec07d8338  add rsp, 0x08
00007e1ec07d833c  jmp 0x00007E1EC07D34C6
00007e1ec07d8341  sub rsp, 0x08
00007e1ec07d8345  push rax
00007e1ec07d8346  push rcx
00007e1ec07d8347  push rdx
00007e1ec07d8348  push rdi
00007e1ec07d8349  push rsi
00007e1ec07d834a  push r8
00007e1ec07d834c  push r9
00007e1ec07d834e  push r10
00007e1ec07d8350  push r11
00007e1ec07d8352  sub rsp, 0xF0
00007e1ec07d8359  vmovaps [rsp], xmm0
00007e1ec07d835e  vmovaps [rsp+0x10], xmm1
00007e1ec07d8364  vmovaps [rsp+0x20], xmm2
00007e1ec07d836a  vmovaps [rsp+0x30], xmm3
00007e1ec07d8370  vmovaps [rsp+0x40], xmm4
00007e1ec07d8376  vmovaps [rsp+0x50], xmm5
00007e1ec07d837c  vmovaps [rsp+0x60], xmm6
00007e1ec07d8382  vmovaps [rsp+0x70], xmm7
00007e1ec07d8388  vmovaps [rsp+0x80], xmm8
00007e1ec07d8391  vmovaps [rsp+0x90], xmm9
00007e1ec07d839a  vmovaps [rsp+0xA0], xmm10
00007e1ec07d83a3  vmovaps [rsp+0xB0], xmm12
00007e1ec07d83ac  vmovaps [rsp+0xC0], xmm13
00007e1ec07d83b5  vmovaps [rsp+0xD0], xmm14
00007e1ec07d83be  vmovaps [rsp+0xE0], xmm15
00007e1ec07d83c7  sub rsp, 0x30
00007e1ec07d83cb  movaps [rsp], xmm11
00007e1ec07d83d0  movaps [rsp+0x10], xmm14
00007e1ec07d83d6  movaps [rsp+0x20], xmm13
00007e1ec07d83dc  lea rdi, [rsp]
00007e1ec07d83e0  mov esi, 0x00
00007e1ec07d83e5  mov rax, 0x5E00FF778530
00007e1ec07d83ef  call rax
00007e1ec07d83f1  movaps xmm11, [rsp]
00007e1ec07d83f6  add rsp, 0x30
00007e1ec07d83fa  vmovaps xmm0, [rsp]
00007e1ec07d83ff  vmovaps xmm1, [rsp+0x10]
00007e1ec07d8405  vmovaps xmm2, [rsp+0x20]
00007e1ec07d840b  vmovaps xmm3, [rsp+0x30]
00007e1ec07d8411  vmovaps xmm4, [rsp+0x40]
00007e1ec07d8417  vmovaps xmm5, [rsp+0x50]
00007e1ec07d841d  vmovaps xmm6, [rsp+0x60]
00007e1ec07d8423  vmovaps xmm7, [rsp+0x70]
00007e1ec07d8429  vmovaps xmm8, [rsp+0x80]
00007e1ec07d8432  vmovaps xmm9, [rsp+0x90]
00007e1ec07d843b  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d8444  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d844d  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d8456  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d845f  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d8468  add rsp, 0xF0
00007e1ec07d846f  pop r11
00007e1ec07d8471  pop r10
00007e1ec07d8473  pop r9
00007e1ec07d8475  pop r8
00007e1ec07d8477  pop rsi
00007e1ec07d8478  pop rdi
00007e1ec07d8479  pop rdx
00007e1ec07d847a  pop rcx
00007e1ec07d847b  pop rax
00007e1ec07d847c  add rsp, 0x08
00007e1ec07d8480  jmp 0x00007E1EC07D34F4
00007e1ec07d8485  sub rsp, 0x08
00007e1ec07d8489  push rax
00007e1ec07d848a  push rcx
00007e1ec07d848b  push rdx
00007e1ec07d848c  push rdi
00007e1ec07d848d  push rsi
00007e1ec07d848e  push r8
00007e1ec07d8490  push r9
00007e1ec07d8492  push r10
00007e1ec07d8494  push r11
00007e1ec07d8496  sub rsp, 0xF0
00007e1ec07d849d  vmovaps [rsp], xmm0
00007e1ec07d84a2  vmovaps [rsp+0x10], xmm1
00007e1ec07d84a8  vmovaps [rsp+0x20], xmm2
00007e1ec07d84ae  vmovaps [rsp+0x30], xmm3
00007e1ec07d84b4  vmovaps [rsp+0x40], xmm4
00007e1ec07d84ba  vmovaps [rsp+0x50], xmm5
00007e1ec07d84c0  vmovaps [rsp+0x60], xmm6
00007e1ec07d84c6  vmovaps [rsp+0x70], xmm7
00007e1ec07d84cc  vmovaps [rsp+0x80], xmm8
00007e1ec07d84d5  vmovaps [rsp+0x90], xmm9
00007e1ec07d84de  vmovaps [rsp+0xA0], xmm10
00007e1ec07d84e7  vmovaps [rsp+0xB0], xmm11
00007e1ec07d84f0  vmovaps [rsp+0xC0], xmm12
00007e1ec07d84f9  vmovaps [rsp+0xD0], xmm13
00007e1ec07d8502  vmovaps [rsp+0xE0], xmm15
00007e1ec07d850b  sub rsp, 0x30
00007e1ec07d850f  movaps [rsp], xmm14
00007e1ec07d8514  movaps [rsp+0x10], xmm12
00007e1ec07d851a  movaps [rsp+0x20], xmm9
00007e1ec07d8520  lea rdi, [rsp]
00007e1ec07d8524  mov esi, 0x00
00007e1ec07d8529  mov rax, 0x5E00FF778530
00007e1ec07d8533  call rax
00007e1ec07d8535  movaps xmm14, [rsp]
00007e1ec07d853a  add rsp, 0x30
00007e1ec07d853e  vmovaps xmm0, [rsp]
00007e1ec07d8543  vmovaps xmm1, [rsp+0x10]
00007e1ec07d8549  vmovaps xmm2, [rsp+0x20]
00007e1ec07d854f  vmovaps xmm3, [rsp+0x30]
00007e1ec07d8555  vmovaps xmm4, [rsp+0x40]
00007e1ec07d855b  vmovaps xmm5, [rsp+0x50]
00007e1ec07d8561  vmovaps xmm6, [rsp+0x60]
00007e1ec07d8567  vmovaps xmm7, [rsp+0x70]
00007e1ec07d856d  vmovaps xmm8, [rsp+0x80]
00007e1ec07d8576  vmovaps xmm9, [rsp+0x90]
00007e1ec07d857f  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d8588  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d8591  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d859a  vmovaps xmm13, [rsp+0xD0]
00007e1ec07d85a3  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d85ac  add rsp, 0xF0
00007e1ec07d85b3  pop r11
00007e1ec07d85b5  pop r10
00007e1ec07d85b7  pop r9
00007e1ec07d85b9  pop r8
00007e1ec07d85bb  pop rsi
00007e1ec07d85bc  pop rdi
00007e1ec07d85bd  pop rdx
00007e1ec07d85be  pop rcx
00007e1ec07d85bf  pop rax
00007e1ec07d85c0  add rsp, 0x08
00007e1ec07d85c4  jmp 0x00007E1EC07D350F
00007e1ec07d85c9  sub rsp, 0x08
00007e1ec07d85cd  push rax
00007e1ec07d85ce  push rcx
00007e1ec07d85cf  push rdx
00007e1ec07d85d0  push rdi
00007e1ec07d85d1  push rsi
00007e1ec07d85d2  push r8
00007e1ec07d85d4  push r9
00007e1ec07d85d6  push r10
00007e1ec07d85d8  push r11
00007e1ec07d85da  sub rsp, 0xF0
00007e1ec07d85e1  vmovaps [rsp], xmm0
00007e1ec07d85e6  vmovaps [rsp+0x10], xmm1
00007e1ec07d85ec  vmovaps [rsp+0x20], xmm2
00007e1ec07d85f2  vmovaps [rsp+0x30], xmm3
00007e1ec07d85f8  vmovaps [rsp+0x40], xmm4
00007e1ec07d85fe  vmovaps [rsp+0x50], xmm5
00007e1ec07d8604  vmovaps [rsp+0x60], xmm6
00007e1ec07d860a  vmovaps [rsp+0x70], xmm7
00007e1ec07d8610  vmovaps [rsp+0x80], xmm8
00007e1ec07d8619  vmovaps [rsp+0x90], xmm9
00007e1ec07d8622  vmovaps [rsp+0xA0], xmm10
00007e1ec07d862b  vmovaps [rsp+0xB0], xmm11
00007e1ec07d8634  vmovaps [rsp+0xC0], xmm12
00007e1ec07d863d  vmovaps [rsp+0xD0], xmm14
00007e1ec07d8646  vmovaps [rsp+0xE0], xmm15
00007e1ec07d864f  sub rsp, 0x30
00007e1ec07d8653  movaps [rsp], xmm13
00007e1ec07d8658  movaps [rsp+0x10], xmm8
00007e1ec07d865e  movaps [rsp+0x20], xmm15
00007e1ec07d8664  lea rdi, [rsp]
00007e1ec07d8668  mov esi, 0x00
00007e1ec07d866d  mov rax, 0x5E00FF778530
00007e1ec07d8677  call rax
00007e1ec07d8679  movaps xmm13, [rsp]
00007e1ec07d867e  add rsp, 0x30
00007e1ec07d8682  vmovaps xmm0, [rsp]
00007e1ec07d8687  vmovaps xmm1, [rsp+0x10]
00007e1ec07d868d  vmovaps xmm2, [rsp+0x20]
00007e1ec07d8693  vmovaps xmm3, [rsp+0x30]
00007e1ec07d8699  vmovaps xmm4, [rsp+0x40]
00007e1ec07d869f  vmovaps xmm5, [rsp+0x50]
00007e1ec07d86a5  vmovaps xmm6, [rsp+0x60]
00007e1ec07d86ab  vmovaps xmm7, [rsp+0x70]
00007e1ec07d86b1  vmovaps xmm8, [rsp+0x80]
00007e1ec07d86ba  vmovaps xmm9, [rsp+0x90]
00007e1ec07d86c3  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d86cc  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d86d5  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d86de  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d86e7  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d86f0  add rsp, 0xF0
00007e1ec07d86f7  pop r11
00007e1ec07d86f9  pop r10
00007e1ec07d86fb  pop r9
00007e1ec07d86fd  pop r8
00007e1ec07d86ff  pop rsi
00007e1ec07d8700  pop rdi
00007e1ec07d8701  pop rdx
00007e1ec07d8702  pop rcx
00007e1ec07d8703  pop rax
00007e1ec07d8704  add rsp, 0x08
00007e1ec07d8708  jmp 0x00007E1EC07D3532
00007e1ec07d870d  sub rsp, 0x08
00007e1ec07d8711  push rax
00007e1ec07d8712  push rcx
00007e1ec07d8713  push rdx
00007e1ec07d8714  push rdi
00007e1ec07d8715  push rsi
00007e1ec07d8716  push r8
00007e1ec07d8718  push r9
00007e1ec07d871a  push r10
00007e1ec07d871c  push r11
00007e1ec07d871e  sub rsp, 0xF0
00007e1ec07d8725  vmovaps [rsp], xmm0
00007e1ec07d872a  vmovaps [rsp+0x10], xmm1
00007e1ec07d8730  vmovaps [rsp+0x20], xmm2
00007e1ec07d8736  vmovaps [rsp+0x30], xmm3
00007e1ec07d873c  vmovaps [rsp+0x40], xmm4
00007e1ec07d8742  vmovaps [rsp+0x50], xmm5
00007e1ec07d8748  vmovaps [rsp+0x60], xmm6
00007e1ec07d874e  vmovaps [rsp+0x70], xmm7
00007e1ec07d8754  vmovaps [rsp+0x80], xmm8
00007e1ec07d875d  vmovaps [rsp+0x90], xmm9
00007e1ec07d8766  vmovaps [rsp+0xA0], xmm10
00007e1ec07d876f  vmovaps [rsp+0xB0], xmm11
00007e1ec07d8778  vmovaps [rsp+0xC0], xmm12
00007e1ec07d8781  vmovaps [rsp+0xD0], xmm13
00007e1ec07d878a  vmovaps [rsp+0xE0], xmm14
00007e1ec07d8793  sub rsp, 0x30
00007e1ec07d8797  movaps [rsp], xmm15
00007e1ec07d879c  movaps [rsp+0x10], xmm1
00007e1ec07d87a1  movaps [rsp+0x20], xmm10
00007e1ec07d87a7  lea rdi, [rsp]
00007e1ec07d87ab  mov esi, 0x00
00007e1ec07d87b0  mov rax, 0x5E00FF778530
00007e1ec07d87ba  call rax
00007e1ec07d87bc  movaps xmm15, [rsp]
00007e1ec07d87c1  add rsp, 0x30
00007e1ec07d87c5  vmovaps xmm0, [rsp]
00007e1ec07d87ca  vmovaps xmm1, [rsp+0x10]
00007e1ec07d87d0  vmovaps xmm2, [rsp+0x20]
00007e1ec07d87d6  vmovaps xmm3, [rsp+0x30]
00007e1ec07d87dc  vmovaps xmm4, [rsp+0x40]
00007e1ec07d87e2  vmovaps xmm5, [rsp+0x50]
00007e1ec07d87e8  vmovaps xmm6, [rsp+0x60]
00007e1ec07d87ee  vmovaps xmm7, [rsp+0x70]
00007e1ec07d87f4  vmovaps xmm8, [rsp+0x80]
00007e1ec07d87fd  vmovaps xmm9, [rsp+0x90]
00007e1ec07d8806  vmovaps xmm10, [rsp+0xA0]
00007e1ec07d880f  vmovaps xmm11, [rsp+0xB0]
00007e1ec07d8818  vmovaps xmm12, [rsp+0xC0]
00007e1ec07d8821  vmovaps xmm13, [rsp+0xD0]
00007e1ec07d882a  vmovaps xmm14, [rsp+0xE0]
00007e1ec07d8833  add rsp, 0xF0
00007e1ec07d883a  pop r11
00007e1ec07d883c  pop r10
00007e1ec07d883e  pop r9
00007e1ec07d8840  pop r8
00007e1ec07d8842  pop rsi
00007e1ec07d8843  pop rdi
00007e1ec07d8844  pop rdx
00007e1ec07d8845  pop rcx
00007e1ec07d8846  pop rax
00007e1ec07d8847  add rsp, 0x08
00007e1ec07d884b  jmp 0x00007E1EC07D3555
00007e1ec07d8850  sub rsp, 0x08
00007e1ec07d8854  push rax
00007e1ec07d8855  push rcx
00007e1ec07d8856  push rdx
00007e1ec07d8857  push rdi
00007e1ec07d8858  push rsi
00007e1ec07d8859  push r8
00007e1ec07d885b  push r9
00007e1ec07d885d  push r10
00007e1ec07d885f  push r11
00007e1ec07d8861  sub rsp, 0xF0
00007e1ec07d8868  vmovaps [rsp], xmm0
00007e1ec07d886d  vmovaps [rsp+0x10], xmm2
00007e1ec07d8873  vmovaps [rsp+0x20], xmm3
00007e1ec07d8879  vmovaps [rsp+0x30], xmm4
00007e1ec07d887f  vmovaps [rsp+0x40], xmm5
00007e1ec07d8885  vmovaps [rsp+0x50], xmm6
00007e1ec07d888b  vmovaps [rsp+0x60], xmm7
00007e1ec07d8891  vmovaps [rsp+0x70], xmm8
00007e1ec07d8897  vmovaps [rsp+0x80], xmm9
00007e1ec07d88a0  vmovaps [rsp+0x90], xmm10
00007e1ec07d88a9  vmovaps [rsp+0xA0], xmm11
00007e1ec07d88b2  vmovaps [rsp+0xB0], xmm12
00007e1ec07d88bb  vmovaps [rsp+0xC0], xmm13
00007e1ec07d88c4  vmovaps [rsp+0xD0], xmm14
00007e1ec07d88cd  vmovaps [rsp+0xE0], xmm15
00007e1ec07d88d6  sub rsp, 0x30
00007e1ec07d88da  movaps [rsp], xmm1
00007e1ec07d88de  movaps [rsp+0x10], xmm7
00007e1ec07d88e3  movaps [rsp+0x20], xmm11
00007e1ec07d88e9  lea rdi, [rsp]
00007e1ec07d88ed  mov esi, 0x00
00007e1ec07d88f2  mov rax, 0x5E00FF778530
00007e1ec07d88fc  call rax
00007e1ec07d88fe  movaps xmm1, [rsp]
00007e1ec07d8902  add rsp, 0x30
00007e1ec07d8906  vmovaps xmm0, [rsp]
00007e1ec07d890b  vmovaps xmm2, [rsp+0x10]
00007e1ec07d8911  vmovaps xmm3, [rsp+0x20]
00007e1ec07d8917  vmovaps xmm4, [rsp+0x30]
00007e1ec07d891d  vmovaps xmm5, [rsp+0x40]
00007e1ec07d8923  vmovaps xmm6, [rsp+0x50]
00007e1ec07d8929  vmovaps xmm7, [rsp+0x60]
00007e1ec07d892f  vmovaps xmm8, [rsp+0x70]
00007e1ec07d8935  vmovaps xmm9, [rsp+0x80]
00007e1ec07d893e  vmovaps xmm10, [rsp+0x90]
00007e1ec07d8947  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d8950  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d8959  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d8962  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d896b  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d8974  add rsp, 0xF0
00007e1ec07d897b  pop r11
00007e1ec07d897d  pop r10
00007e1ec07d897f  pop r9
00007e1ec07d8981  pop r8
00007e1ec07d8983  pop rsi
00007e1ec07d8984  pop rdi
00007e1ec07d8985  pop rdx
00007e1ec07d8986  pop rcx
00007e1ec07d8987  pop rax
00007e1ec07d8988  add rsp, 0x08
00007e1ec07d898c  jmp 0x00007E1EC07D3576
00007e1ec07d8991  call 0x00007E1EC060D600
00007e1ec07d8996  jmp 0x00007E1EC07D3589
00007e1ec07d899b  call 0x00007E1EC060C380
00007e1ec07d89a0  jmp 0x00007E1EC07D3594
00007e1ec07d89a5  call 0x00007E1EC060E880
00007e1ec07d89aa  jmp 0x00007E1EC07D359F
00007e1ec07d89af  call 0x00007E1EC05FF540
00007e1ec07d89b4  jmp 0x00007E1EC07D35AA
00007e1ec07d89b9  int3
00007e1ec07d89ba  nop [rax+rax*1], ax
00007e1ec07d89c0  mov rax, [r15+0x40]
00007e1ec07d89c4  mov r14, [r15+0x58]
00007e1ec07d89c8  lea r12, [rax+r14*1]
00007e1ec07d89cc  movaps xmm1, [r15+0x1D0]
00007e1ec07d89d4  vmovaps [rsp+0x10], xmm1
00007e1ec07d89da  vmovaps xmm15, [rsp+0x10]
00007e1ec07d89e0  por xmm1, xmm15
00007e1ec07d89e5  movaps xmm14, [r15+0x1A0]
00007e1ec07d89ed  vmovaps [rsp+0x10], xmm14
00007e1ec07d89f3  vmovaps xmm13, [rsp+0x10]
00007e1ec07d89f9  por xmm14, xmm13
00007e1ec07d89fe  lea rax, [r12+0x30]
00007e1ec07d8a03  mov r11, [r13+rax*1]
00007e1ec07d8a08  lea rax, [r12+0x38]
00007e1ec07d8a0d  mov r10, [r13+rax*1]
00007e1ec07d8a12  movq xmm13, r11
00007e1ec07d8a17  movq xmm12, r10
00007e1ec07d8a1c  movq xmm13, xmm13
00007e1ec07d8a21  vmovaps [rsp+0x10], xmm13
00007e1ec07d8a27  movq xmm13, xmm13
00007e1ec07d8a2c  movaps [r15+0x130], xmm13
00007e1ec07d8a34  movq xmm12, xmm12
00007e1ec07d8a39  vmovaps [rsp+0x20], xmm12
00007e1ec07d8a3f  movq xmm12, xmm12
00007e1ec07d8a44  movaps [r15+0x280], xmm12
00007e1ec07d8a4c  movaps xmm13, [r15+0x270]
00007e1ec07d8a54  vmovaps [rsp+0x30], xmm13
00007e1ec07d8a5a  vmovaps xmm12, [rsp+0x30]
00007e1ec07d8a60  por xmm13, xmm12
00007e1ec07d8a65  lea rax, [r12+0x20]
00007e1ec07d8a6a  mov r11, [r13+rax*1]
00007e1ec07d8a6f  lea rax, [r12+0x28]
00007e1ec07d8a74  mov r10, [r13+rax*1]
00007e1ec07d8a79  movq xmm12, r11
00007e1ec07d8a7e  movq xmm11, r10
00007e1ec07d8a83  movq xmm12, xmm12
00007e1ec07d8a88  vmovaps [rsp+0x30], xmm12
00007e1ec07d8a8e  movq xmm12, xmm12
00007e1ec07d8a93  movaps [r15+0x150], xmm12
00007e1ec07d8a9b  movq xmm11, xmm11
00007e1ec07d8aa0  vmovaps [rsp+0x40], xmm11
00007e1ec07d8aa6  movq xmm11, xmm11
00007e1ec07d8aab  movaps [r15+0x140], xmm11
00007e1ec07d8ab3  lea rax, [r12+0x10]
00007e1ec07d8ab8  mov r11, [r13+rax*1]
00007e1ec07d8abd  lea rax, [r12+0x18]
00007e1ec07d8ac2  mov r10, [r13+rax*1]
00007e1ec07d8ac7  movq xmm12, r11
00007e1ec07d8acc  movq xmm11, r10
00007e1ec07d8ad1  movq xmm12, xmm12
00007e1ec07d8ad6  vmovaps [rsp+0x50], xmm12
00007e1ec07d8adc  movq xmm12, xmm12
00007e1ec07d8ae1  movaps [r15+0x170], xmm12
00007e1ec07d8ae9  movq xmm11, xmm11
00007e1ec07d8aee  vmovaps [rsp+0x60], xmm11
00007e1ec07d8af4  movq xmm11, xmm11
00007e1ec07d8af9  movaps [r15+0x160], xmm11
00007e1ec07d8b01  mov rax, [r13+r12*1]
00007e1ec07d8b06  vmovq xmm12, rax
00007e1ec07d8b0b  vpbroadcastq xmm12, xmm12
00007e1ec07d8b10  lea rax, [r12+0x08]
00007e1ec07d8b15  mov r12, [r13+rax*1]
00007e1ec07d8b1a  movq xmm11, r12
00007e1ec07d8b1f  movaps [r15+0x230], xmm11
00007e1ec07d8b27  mov rax, [r15+0xF8]
00007e1ec07d8b2e  lea r12, [rax+0x50]
00007e1ec07d8b32  movups xmm11, [r13+r12*1]
00007e1ec07d8b38  lea r12, [rax+0x60]
00007e1ec07d8b3c  movups xmm10, [r13+r12*1]
00007e1ec07d8b42  lea r12, [rax+0x30]
00007e1ec07d8b46  movups xmm9, [r13+r12*1]
00007e1ec07d8b4c  mov r12, [r15+0x50]
00007e1ec07d8b50  lea r11, [r12+r14*1]
00007e1ec07d8b54  mov [r15+0x60], r11
00007e1ec07d8b58  lea r12, [r14+0x40]
00007e1ec07d8b5c  mov [r15+0x58], r12
00007e1ec07d8b60  movaps xmm8, xmm12
00007e1ec07d8b64  mulpd xmm8, xmm15
00007e1ec07d8b69  vcmppd xmm7, xmm8, xmm8, 0x03
00007e1ec07d8b6f  ptest xmm7, xmm7
00007e1ec07d8b74  jnz 0x00007E1EC07D9997
00007e1ec07d8b7a  movq xmm15, qword ptr [r15+0x230]
00007e1ec07d8b83  vmovaps [rsp+0x70], xmm15
00007e1ec07d8b89  vpermilpd xmm15, xmm15, 0x00
00007e1ec07d8b8f  movaps xmm7, xmm9
00007e1ec07d8b93  mulpd xmm7, xmm15
00007e1ec07d8b98  vcmppd xmm6, xmm7, xmm7, 0x03
00007e1ec07d8b9d  ptest xmm6, xmm6
00007e1ec07d8ba2  jnz 0x00007E1EC07D9ADB
00007e1ec07d8ba8  vxorps xmm15, xmm15, xmm15
00007e1ec07d8bad  vpbroadcastq xmm15, xmm15
00007e1ec07d8bb2  movaps xmm9, xmm12
00007e1ec07d8bb6  mulpd xmm9, xmm10
00007e1ec07d8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
00007e1ec07d8bc1  ptest xmm6, xmm6
00007e1ec07d8bc6  jnz 0x00007E1EC07D9C1D
00007e1ec07d8bcc  movaps xmm10, xmm12
00007e1ec07d8bd0  mulpd xmm10, xmm11
00007e1ec07d8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
00007e1ec07d8bdb  ptest xmm6, xmm6
00007e1ec07d8be0  jnz 0x00007E1EC07D9D61
00007e1ec07d8be6  movaps xmm11, [r15+0x1F0]
00007e1ec07d8bee  movaps xmm6, xmm12
00007e1ec07d8bf2  mulpd xmm6, xmm11
00007e1ec07d8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
00007e1ec07d8bfc  ptest xmm5, xmm5
00007e1ec07d8c01  jnz 0x00007E1EC07D9EA5
00007e1ec07d8c07  movaps xmm12, [r15+0x2A0]
00007e1ec07d8c0f  vmovaps [rsp+0x80], xmm12
00007e1ec07d8c18  vmovaps xmm11, [rsp+0x80]
00007e1ec07d8c21  por xmm12, xmm11
00007e1ec07d8c26  movaps xmm11, [r15+0x250]
00007e1ec07d8c2e  vmovaps [rsp+0x80], xmm11
00007e1ec07d8c37  vmovaps xmm5, [rsp+0x80]
00007e1ec07d8c40  por xmm11, xmm5
00007e1ec07d8c45  vmovaps xmm4, [rsp+0x70]
00007e1ec07d8c4b  vpermilpd xmm4, xmm4, 0x00
00007e1ec07d8c51  movaps xmm3, xmm5
00007e1ec07d8c54  mulpd xmm3, xmm4
00007e1ec07d8c58  vcmppd xmm2, xmm3, xmm3, 0x03
00007e1ec07d8c5d  ptest xmm2, xmm2
00007e1ec07d8c62  jnz 0x00007E1EC07D9FE7
00007e1ec07d8c68  mov [rsp+0x80], rax
00007e1ec07d8c70  xor eax, eax
00007e1ec07d8c72  mov r14d, 0x200
00007e1ec07d8c78  cmp r12, r14
00007e1ec07d8c7b  cmc
00007e1ec07d8c7c  lahf
00007e1ec07d8c7d  seto al
00007e1ec07d8c80  mov [r15+0x108], eax
00007e1ec07d8c87  movaps xmm5, xmm8
00007e1ec07d8c8b  addpd xmm5, xmm15
00007e1ec07d8c90  vcmppd xmm4, xmm5, xmm5, 0x03
00007e1ec07d8c95  ptest xmm4, xmm4
00007e1ec07d8c9a  jnz 0x00007E1EC07DA127
00007e1ec07d8ca0  movaps xmm8, [r15+0x1B0]
00007e1ec07d8ca8  movaps xmm4, xmm9
00007e1ec07d8cac  addpd xmm4, xmm8
00007e1ec07d8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
00007e1ec07d8cb6  ptest xmm2, xmm2
00007e1ec07d8cbb  jnz 0x00007E1EC07DA269
00007e1ec07d8cc1  movaps xmm9, xmm10
00007e1ec07d8cc5  addpd xmm9, xmm8
00007e1ec07d8cca  vcmppd xmm2, xmm9, xmm9, 0x03
00007e1ec07d8cd0  ptest xmm2, xmm2
00007e1ec07d8cd5  jnz 0x00007E1EC07DA3AB
00007e1ec07d8cdb  movaps xmm10, [r15+0x2F0]
00007e1ec07d8ce3  vmovaps [rsp+0x90], xmm10
00007e1ec07d8cec  vmovaps xmm8, [rsp+0x90]
00007e1ec07d8cf5  por xmm10, xmm8
00007e1ec07d8cfa  movaps xmm8, [r15+0x2E0]
00007e1ec07d8d02  vmovaps [rsp+0x90], xmm8
00007e1ec07d8d0b  vmovaps xmm2, [rsp+0x90]
00007e1ec07d8d14  por xmm8, xmm2
00007e1ec07d8d19  movaps xmm2, [r15+0x2D0]
00007e1ec07d8d21  vmovaps [rsp+0x90], xmm2
00007e1ec07d8d2a  vmovaps [rsp+0xA0], xmm1
00007e1ec07d8d33  vmovaps xmm1, [rsp+0x90]
00007e1ec07d8d3c  por xmm2, xmm1
00007e1ec07d8d40  movaps xmm1, [r15+0x200]
00007e1ec07d8d48  vmovaps [rsp+0x90], xmm1
00007e1ec07d8d51  vmovaps [rsp+0xB0], xmm15
00007e1ec07d8d5a  vmovaps xmm15, [rsp+0x90]
00007e1ec07d8d63  por xmm1, xmm15
00007e1ec07d8d68  movaps xmm15, [r15+0x1C0]
00007e1ec07d8d70  vmovaps [rsp+0x90], xmm15
00007e1ec07d8d79  vmovaps [rsp+0xC0], xmm1
00007e1ec07d8d82  vmovaps xmm1, [rsp+0x90]
00007e1ec07d8d8b  por xmm15, xmm1
00007e1ec07d8d90  movaps xmm1, [r15+0x190]
00007e1ec07d8d98  vmovaps [rsp+0x90], xmm1
00007e1ec07d8da1  vmovaps [rsp+0xD0], xmm15
00007e1ec07d8daa  vmovaps xmm15, [rsp+0x90]
00007e1ec07d8db3  por xmm1, xmm15
00007e1ec07d8db8  movaps xmm15, [r15+0x300]
00007e1ec07d8dc0  vmovaps [rsp+0x90], xmm15
00007e1ec07d8dc9  vmovaps [rsp+0xE0], xmm1
00007e1ec07d8dd2  vmovaps xmm1, [rsp+0x90]
00007e1ec07d8ddb  por xmm15, xmm1
00007e1ec07d8de0  mov rax, [rsp+0x80]
00007e1ec07d8de8  lea r14, [rax+0xA0]
00007e1ec07d8def  movups xmm1, [r13+r14*1]
00007e1ec07d8df5  lea r14, [rax+0xB0]
00007e1ec07d8dfc  vmovaps [rsp+0x80], xmm1
00007e1ec07d8e05  movups xmm1, [r13+r14*1]
00007e1ec07d8e0b  vmovaps [rsp+0x90], xmm1
00007e1ec07d8e14  vmovaps [rsp+0xF0], xmm15
00007e1ec07d8e1d  vmovaps xmm15, [rsp+0xB0]
00007e1ec07d8e26  vmovaps [rsp+0xB0], xmm14
00007e1ec07d8e2f  movaps xmm1, xmm6
00007e1ec07d8e32  addpd xmm1, xmm15
00007e1ec07d8e37  vcmppd xmm14, xmm1, xmm1, 0x03
00007e1ec07d8e3c  ptest xmm14, xmm14
00007e1ec07d8e42  jnz 0x00007E1EC07DA503
00007e1ec07d8e48  lea r14, [rax+0xF0]
00007e1ec07d8e4f  movups xmm15, [r13+r14*1]
00007e1ec07d8e55  movaps xmm14, xmm4
00007e1ec07d8e59  addpd xmm14, xmm3
00007e1ec07d8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
00007e1ec07d8e64  ptest xmm6, xmm6
00007e1ec07d8e69  jnz 0x00007E1EC07DA64E
00007e1ec07d8e6f  movaps xmm6, xmm9
00007e1ec07d8e73  addpd xmm6, xmm7
00007e1ec07d8e77  vcmppd xmm4, xmm6, xmm6, 0x03
00007e1ec07d8e7c  ptest xmm4, xmm4
00007e1ec07d8e81  jnz 0x00007E1EC07DA790
00007e1ec07d8e87  vmovaps xmm9, [rsp+0x70]
00007e1ec07d8e8d  vpermilpd xmm9, xmm9, 0x00
00007e1ec07d8e93  vmovaps xmm4, [rsp+0x90]
00007e1ec07d8e9c  movaps xmm7, xmm4
00007e1ec07d8e9f  mulpd xmm7, xmm9
00007e1ec07d8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
00007e1ec07d8ea9  ptest xmm3, xmm3
00007e1ec07d8eae  jnz 0x00007E1EC07DA8D1
00007e1ec07d8eb4  vmovaps xmm9, [rsp+0x50]
00007e1ec07d8eba  vpermilpd xmm9, xmm9, 0x00
00007e1ec07d8ec0  movaps xmm4, xmm15
00007e1ec07d8ec4  mulpd xmm4, xmm9
00007e1ec07d8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
00007e1ec07d8ece  ptest xmm3, xmm3
00007e1ec07d8ed3  jnz 0x00007E1EC07DAA12
00007e1ec07d8ed9  lea r14, [rax+0xE0]
00007e1ec07d8ee0  movups xmm15, [r13+r14*1]
00007e1ec07d8ee6  vmovaps xmm9, [rsp+0x70]
00007e1ec07d8eec  vpermilpd xmm9, xmm9, 0x00
00007e1ec07d8ef2  vmovaps [rsp+0x70], xmm1
00007e1ec07d8ef8  vmovaps xmm1, [rsp+0x80]
00007e1ec07d8f01  vmovaps [rsp+0x80], xmm15
00007e1ec07d8f0a  movaps xmm3, xmm1
00007e1ec07d8f0d  mulpd xmm3, xmm9
00007e1ec07d8f12  vcmppd xmm15, xmm3, xmm3, 0x03
00007e1ec07d8f17  ptest xmm15, xmm15
00007e1ec07d8f1d  jnz 0x00007E1EC07DAB5E
00007e1ec07d8f23  vmovaps xmm1, [rsp+0xF0]
00007e1ec07d8f2c  vmovaps xmm15, [rsp+0xF0]
00007e1ec07d8f35  por xmm1, xmm15
00007e1ec07d8f3a  movaps [r15+0x300], xmm1
00007e1ec07d8f42  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d8f4b  vmovaps xmm9, [rsp+0xE0]
00007e1ec07d8f54  por xmm15, xmm9
00007e1ec07d8f59  movaps [r15+0x190], xmm15
00007e1ec07d8f61  vmovaps xmm9, [rsp+0x50]
00007e1ec07d8f67  vpermilpd xmm9, xmm9, 0x00
00007e1ec07d8f6d  vmovaps [rsp+0x90], xmm1
00007e1ec07d8f76  vmovaps [rsp+0xE0], xmm15
00007e1ec07d8f7f  vmovaps xmm15, [rsp+0x80]
00007e1ec07d8f88  vmovaps [rsp+0x80], xmm14
00007e1ec07d8f91  movaps xmm1, xmm15
00007e1ec07d8f95  mulpd xmm1, xmm9
00007e1ec07d8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
00007e1ec07d8f9f  ptest xmm14, xmm14
00007e1ec07d8fa5  jnz 0x00007E1EC07DAC9F
00007e1ec07d8fab  lea r14, [rax+0x90]
00007e1ec07d8fb2  movups xmm15, [r13+r14*1]
00007e1ec07d8fb8  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d8fc1  vmovaps xmm9, [rsp+0xD0]
00007e1ec07d8fca  por xmm14, xmm9
00007e1ec07d8fcf  movaps [r15+0x1C0], xmm14
00007e1ec07d8fd7  vmovaps xmm9, [rsp+0xC0]
00007e1ec07d8fe0  vmovaps [rsp+0xD0], xmm1
00007e1ec07d8fe9  vmovaps xmm1, [rsp+0xC0]
00007e1ec07d8ff2  por xmm9, xmm1
00007e1ec07d8ff7  movaps [r15+0x200], xmm9
00007e1ec07d8fff  vmovaps [rsp+0xC0], xmm2
00007e1ec07d9008  vmovaps xmm1, [rsp+0xC0]
00007e1ec07d9011  por xmm2, xmm1
00007e1ec07d9015  movaps [r15+0x2D0], xmm2
00007e1ec07d901d  vmovaps [rsp+0xC0], xmm8
00007e1ec07d9026  vmovaps xmm1, [rsp+0xC0]
00007e1ec07d902f  por xmm8, xmm1
00007e1ec07d9034  movaps [r15+0x2E0], xmm8
00007e1ec07d903c  vmovaps [rsp+0xC0], xmm15
00007e1ec07d9045  movaps xmm1, xmm5
00007e1ec07d9048  addpd xmm1, xmm7
00007e1ec07d904c  vcmppd xmm15, xmm1, xmm1, 0x03
00007e1ec07d9051  ptest xmm15, xmm15
00007e1ec07d9057  jnz 0x00007E1EC07DADEB
00007e1ec07d905d  vmovaps xmm15, [rsp+0x50]
00007e1ec07d9063  vpermilpd xmm15, xmm15, 0x00
00007e1ec07d9069  vmovaps xmm5, [rsp+0xC0]
00007e1ec07d9072  vmovaps [rsp+0xC0], xmm1
00007e1ec07d907b  movaps xmm7, xmm5
00007e1ec07d907e  mulpd xmm7, xmm15
00007e1ec07d9083  vcmppd xmm1, xmm7, xmm7, 0x03
00007e1ec07d9088  ptest xmm1, xmm1
00007e1ec07d908d  jnz 0x00007E1EC07DAF2B
00007e1ec07d9093  lea r14, [rax+0x80]
00007e1ec07d909a  movups xmm1, [r13+r14*1]
00007e1ec07d90a0  vmovaps xmm5, [rsp+0x70]
00007e1ec07d90a6  vmovaps [rsp+0x70], xmm1
00007e1ec07d90ac  movaps xmm15, xmm5
00007e1ec07d90b0  addpd xmm15, xmm3
00007e1ec07d90b5  vcmppd xmm1, xmm15, xmm15, 0x03
00007e1ec07d90bb  ptest xmm1, xmm1
00007e1ec07d90c0  jnz 0x00007E1EC07DB076
00007e1ec07d90c6  vmovaps xmm5, [rsp+0x80]
00007e1ec07d90cf  movaps xmm1, xmm5
00007e1ec07d90d2  addpd xmm1, xmm4
00007e1ec07d90d6  vcmppd xmm3, xmm1, xmm1, 0x03
00007e1ec07d90db  ptest xmm3, xmm3
00007e1ec07d90e0  jnz 0x00007E1EC07DB1B8
00007e1ec07d90e6  vmovaps [rsp+0x80], xmm10
00007e1ec07d90ef  vmovaps xmm5, [rsp+0x80]
00007e1ec07d90f8  por xmm10, xmm5
00007e1ec07d90fd  movaps [r15+0x2F0], xmm10
00007e1ec07d9105  vmovaps xmm5, [rsp+0x50]
00007e1ec07d910b  vpermilpd xmm5, xmm5, 0x00
00007e1ec07d9111  vmovaps xmm3, [rsp+0x70]
00007e1ec07d9117  vmovaps [rsp+0x50], xmm1
00007e1ec07d911d  movaps xmm4, xmm3
00007e1ec07d9120  mulpd xmm4, xmm5
00007e1ec07d9124  vcmppd xmm1, xmm4, xmm4, 0x03
00007e1ec07d9129  ptest xmm1, xmm1
00007e1ec07d912e  jnz 0x00007E1EC07DB2F8
00007e1ec07d9134  lea r14, [rax+0xD0]
00007e1ec07d913b  movups xmm1, [r13+r14*1]
00007e1ec07d9141  vmovaps xmm3, [rsp+0xD0]
00007e1ec07d914a  vmovaps [rsp+0x70], xmm1
00007e1ec07d9150  movaps xmm5, xmm6
00007e1ec07d9153  addpd xmm5, xmm3
00007e1ec07d9157  vcmppd xmm1, xmm5, xmm5, 0x03
00007e1ec07d915c  ptest xmm1, xmm1
00007e1ec07d9161  jnz 0x00007E1EC07DB442
00007e1ec07d9167  vmovaps xmm1, [rsp+0x60]
00007e1ec07d916d  vpermilpd xmm1, xmm1, 0x00
00007e1ec07d9173  movaps xmm6, xmm9
00007e1ec07d9177  mulpd xmm6, xmm1
00007e1ec07d917b  vcmppd xmm3, xmm6, xmm6, 0x03
00007e1ec07d9180  ptest xmm3, xmm3
00007e1ec07d9185  jnz 0x00007E1EC07DB582
00007e1ec07d918b  movaps [r15+0x260], xmm6
00007e1ec07d9193  vxorps xmm1, xmm1, xmm1
00007e1ec07d9197  vpbroadcastq xmm1, xmm1
00007e1ec07d919c  movaps [r15+0x1B0], xmm1
00007e1ec07d91a4  vmovaps xmm1, [rsp+0x60]
00007e1ec07d91aa  vpermilpd xmm1, xmm1, 0x00
00007e1ec07d91b0  vmovaps xmm3, [rsp+0x70]
00007e1ec07d91b6  vmovaps [rsp+0x70], xmm15
00007e1ec07d91bc  movaps xmm9, xmm3
00007e1ec07d91c0  mulpd xmm9, xmm1
00007e1ec07d91c5  vcmppd xmm15, xmm9, xmm9, 0x03
00007e1ec07d91cb  ptest xmm15, xmm15
00007e1ec07d91d1  jnz 0x00007E1EC07DB6C3
00007e1ec07d91d7  lea r14, [rax+0xC0]
00007e1ec07d91de  movups xmm1, [r13+r14*1]
00007e1ec07d91e4  vmovaps xmm3, [rsp+0xC0]
00007e1ec07d91ed  vmovaps [rsp+0x80], xmm1
00007e1ec07d91f6  movaps xmm15, xmm3
00007e1ec07d91fa  addpd xmm15, xmm7
00007e1ec07d91ff  vcmppd xmm1, xmm15, xmm15, 0x03
00007e1ec07d9205  ptest xmm1, xmm1
00007e1ec07d920a  jnz 0x00007E1EC07DB80F
00007e1ec07d9210  vmovaps [rsp+0xC0], xmm13
00007e1ec07d9219  vmovaps xmm1, [rsp+0xC0]
00007e1ec07d9222  por xmm13, xmm1
00007e1ec07d9227  movaps [r15+0x270], xmm13
00007e1ec07d922f  vmovaps xmm1, [rsp+0xB0]
00007e1ec07d9238  vmovaps xmm7, [rsp+0xB0]
00007e1ec07d9241  por xmm1, xmm7
00007e1ec07d9245  movaps [r15+0x1A0], xmm1
00007e1ec07d924d  vmovaps xmm1, [rsp+0x60]
00007e1ec07d9253  vpermilpd xmm1, xmm1, 0x00
00007e1ec07d9259  vmovaps [rsp+0xB0], xmm1
00007e1ec07d9262  vmovaps xmm1, [rsp+0x80]
00007e1ec07d926b  vmovaps [rsp+0x80], xmm15
00007e1ec07d9274  vmovaps xmm15, [rsp+0xB0]
00007e1ec07d927d  vmovaps [rsp+0xB0], xmm14
00007e1ec07d9286  movaps xmm3, xmm1
00007e1ec07d9289  mulpd xmm3, xmm15
00007e1ec07d928e  vcmppd xmm14, xmm3, xmm3, 0x03
00007e1ec07d9293  ptest xmm14, xmm14
00007e1ec07d9299  jnz 0x00007E1EC07DB951
00007e1ec07d929f  lea r14, [rax+0x20]
00007e1ec07d92a3  movups xmm1, [r13+r14*1]
00007e1ec07d92a9  movaps [r15+0x110], xmm1
00007e1ec07d92b1  vmovaps xmm14, [rsp+0x70]
00007e1ec07d92b7  vmovaps [rsp+0x70], xmm1
00007e1ec07d92bd  movaps xmm15, xmm14
00007e1ec07d92c1  addpd xmm15, xmm4
00007e1ec07d92c6  vcmppd xmm1, xmm15, xmm15, 0x03
00007e1ec07d92cc  ptest xmm1, xmm1
00007e1ec07d92d1  jnz 0x00007E1EC07DBA9C
00007e1ec07d92d7  vmovaps xmm1, [rsp+0x60]
00007e1ec07d92dd  vpermilpd xmm1, xmm1, 0x00
00007e1ec07d92e3  movaps xmm14, xmm2
00007e1ec07d92e7  mulpd xmm14, xmm1
00007e1ec07d92ec  vcmppd xmm4, xmm14, xmm14, 0x03
00007e1ec07d92f2  ptest xmm4, xmm4
00007e1ec07d92f7  jnz 0x00007E1EC07DBBDF
00007e1ec07d92fd  vmovaps xmm4, [rsp+0x50]
00007e1ec07d9303  movaps xmm1, xmm4
00007e1ec07d9306  addpd xmm1, xmm9
00007e1ec07d930b  vcmppd xmm2, xmm1, xmm1, 0x03
00007e1ec07d9310  ptest xmm2, xmm2
00007e1ec07d9315  jnz 0x00007E1EC07DBD21
00007e1ec07d931b  vmovaps xmm9, [rsp+0x30]
00007e1ec07d9321  vpermilpd xmm9, xmm9, 0x00
00007e1ec07d9327  vmovaps xmm2, [rsp+0x70]
00007e1ec07d932d  vmovaps [rsp+0x50], xmm1
00007e1ec07d9333  movaps xmm4, xmm2
00007e1ec07d9336  mulpd xmm4, xmm9
00007e1ec07d933b  vcmppd xmm1, xmm4, xmm4, 0x03
00007e1ec07d9340  ptest xmm1, xmm1
00007e1ec07d9345  jnz 0x00007E1EC07DBE62
00007e1ec07d934b  vmovaps xmm1, [rsp+0x30]
00007e1ec07d9351  vpermilpd xmm1, xmm1, 0x00
00007e1ec07d9357  vmovaps xmm2, [rsp+0x90]
00007e1ec07d9360  vmovaps [rsp+0x60], xmm15
00007e1ec07d9366  movaps xmm9, xmm2
00007e1ec07d936a  mulpd xmm9, xmm1
00007e1ec07d936f  vcmppd xmm15, xmm9, xmm9, 0x03
00007e1ec07d9375  ptest xmm15, xmm15
00007e1ec07d937b  jnz 0x00007E1EC07DBFA3
00007e1ec07d9381  vmovaps xmm15, [rsp+0x80]
00007e1ec07d938a  movaps xmm1, xmm15
00007e1ec07d938e  addpd xmm1, xmm6
00007e1ec07d9392  vcmppd xmm2, xmm1, xmm1, 0x03
00007e1ec07d9397  ptest xmm2, xmm2
00007e1ec07d939c  jnz 0x00007E1EC07DC0E5
00007e1ec07d93a2  movaps xmm15, xmm5
00007e1ec07d93a6  addpd xmm15, xmm3
00007e1ec07d93ab  vcmppd xmm6, xmm15, xmm15, 0x03
00007e1ec07d93b1  ptest xmm6, xmm6
00007e1ec07d93b6  jnz 0x00007E1EC07DC226
00007e1ec07d93bc  vmovaps xmm6, [rsp+0x30]
00007e1ec07d93c2  vpermilpd xmm6, xmm6, 0x00
00007e1ec07d93c8  movaps xmm5, xmm8
00007e1ec07d93cc  mulpd xmm5, xmm6
00007e1ec07d93d0  vcmppd xmm3, xmm5, xmm5, 0x03
00007e1ec07d93d5  ptest xmm3, xmm3
00007e1ec07d93da  jnz 0x00007E1EC07DC368
00007e1ec07d93e0  vmovaps xmm8, [rsp+0x30]
00007e1ec07d93e6  vpermilpd xmm8, xmm8, 0x00
00007e1ec07d93ec  movaps xmm6, xmm10
00007e1ec07d93f0  mulpd xmm6, xmm8
00007e1ec07d93f5  vcmppd xmm3, xmm6, xmm6, 0x03
00007e1ec07d93fa  ptest xmm3, xmm3
00007e1ec07d93ff  jnz 0x00007E1EC07DC4A9
00007e1ec07d9405  vmovaps xmm8, [rsp+0x60]
00007e1ec07d940b  movaps xmm10, xmm8
00007e1ec07d940f  addpd xmm10, xmm14
00007e1ec07d9414  vcmppd xmm3, xmm10, xmm10, 0x03
00007e1ec07d941a  ptest xmm3, xmm3
00007e1ec07d941f  jnz 0x00007E1EC07DC5EB
00007e1ec07d9425  vmovaps xmm8, [rsp+0x50]
00007e1ec07d942b  movaps xmm14, xmm8
00007e1ec07d942f  addpd xmm14, xmm4
00007e1ec07d9434  vcmppd xmm3, xmm14, xmm14, 0x03
00007e1ec07d943a  ptest xmm3, xmm3
00007e1ec07d943f  jnz 0x00007E1EC07DC72F
00007e1ec07d9445  vmovaps xmm8, [rsp+0x40]
00007e1ec07d944b  vpermilpd xmm8, xmm8, 0x00
00007e1ec07d9451  movaps xmm4, xmm13
00007e1ec07d9455  mulpd xmm4, xmm8
00007e1ec07d945a  vcmppd xmm3, xmm4, xmm4, 0x03
00007e1ec07d945f  ptest xmm3, xmm3
00007e1ec07d9464  jnz 0x00007E1EC07DC872
00007e1ec07d946a  movaps xmm13, xmm15
00007e1ec07d946e  addpd xmm13, xmm9
00007e1ec07d9473  vcmppd xmm8, xmm13, xmm13, 0x03
00007e1ec07d9479  ptest xmm8, xmm8
00007e1ec07d947f  jnz 0x00007E1EC07DC9B4
00007e1ec07d9485  movaps xmm15, xmm1
00007e1ec07d9489  addpd xmm15, xmm5
00007e1ec07d948e  vcmppd xmm9, xmm15, xmm15, 0x03
00007e1ec07d9494  ptest xmm9, xmm9
00007e1ec07d949a  jnz 0x00007E1EC07DCAF8
00007e1ec07d94a0  vmovaps [rsp+0x30], xmm11
00007e1ec07d94a6  vmovaps xmm1, [rsp+0x30]
00007e1ec07d94ac  por xmm11, xmm1
00007e1ec07d94b1  movaps [r15+0x250], xmm11
00007e1ec07d94b9  vmovaps [rsp+0x30], xmm12
00007e1ec07d94bf  vmovaps xmm1, [rsp+0x30]
00007e1ec07d94c5  por xmm12, xmm1
00007e1ec07d94ca  movaps [r15+0x2A0], xmm12
00007e1ec07d94d2  vmovaps xmm1, [rsp+0xA0]
00007e1ec07d94db  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d94e4  por xmm1, xmm11
00007e1ec07d94e9  movaps [r15+0x1D0], xmm1
00007e1ec07d94f1  lea r14, [rax+0x40]
00007e1ec07d94f5  movups xmm1, [r13+r14*1]
00007e1ec07d94fb  movaps [r15+0x2C0], xmm1
00007e1ec07d9503  vmovaps xmm11, [rsp+0x40]
00007e1ec07d9509  vpermilpd xmm11, xmm11, 0x00
00007e1ec07d950f  vmovaps xmm8, [rsp+0xE0]
00007e1ec07d9518  movaps xmm9, xmm8
00007e1ec07d951c  mulpd xmm9, xmm11
00007e1ec07d9521  vcmppd xmm5, xmm9, xmm9, 0x03
00007e1ec07d9527  ptest xmm5, xmm5
00007e1ec07d952c  jnz 0x00007E1EC07DCC44
00007e1ec07d9532  movaps xmm11, xmm10
00007e1ec07d9536  addpd xmm11, xmm6
00007e1ec07d953b  vcmppd xmm8, xmm11, xmm11, 0x03
00007e1ec07d9541  ptest xmm8, xmm8
00007e1ec07d9547  jnz 0x00007E1EC07DCD88
00007e1ec07d954d  movaps xmm10, xmm14
00007e1ec07d9551  addpd xmm10, xmm4
00007e1ec07d9556  vcmppd xmm8, xmm10, xmm10, 0x03
00007e1ec07d955c  ptest xmm8, xmm8
00007e1ec07d9562  jnz 0x00007E1EC07DCECB
00007e1ec07d9568  vmovaps xmm14, [rsp+0x40]
00007e1ec07d956e  vpermilpd xmm14, xmm14, 0x00
00007e1ec07d9574  movaps xmm8, xmm1
00007e1ec07d9578  mulpd xmm8, xmm14
00007e1ec07d957d  vcmppd xmm6, xmm8, xmm8, 0x03
00007e1ec07d9583  ptest xmm6, xmm6
00007e1ec07d9588  jnz 0x00007E1EC07DD00E
00007e1ec07d958e  movaps xmm1, [r15+0x2B0]
00007e1ec07d9596  vmovaps xmm14, [rsp+0x40]
00007e1ec07d959c  vpermilpd xmm14, xmm14, 0x00
00007e1ec07d95a2  movaps xmm6, xmm1
00007e1ec07d95a5  mulpd xmm6, xmm14
00007e1ec07d95aa  vcmppd xmm5, xmm6, xmm6, 0x03
00007e1ec07d95af  ptest xmm5, xmm5
00007e1ec07d95b4  jnz 0x00007E1EC07DD151
00007e1ec07d95ba  vmovaps xmm1, [rsp+0x10]
00007e1ec07d95c0  vpermilpd xmm1, xmm1, 0x00
00007e1ec07d95c6  movaps xmm14, xmm12
00007e1ec07d95ca  mulpd xmm14, xmm1
00007e1ec07d95cf  vcmppd xmm5, xmm14, xmm14, 0x03
00007e1ec07d95d5  ptest xmm5, xmm5
00007e1ec07d95da  jnz 0x00007E1EC07DD292
00007e1ec07d95e0  movaps xmm1, xmm13
00007e1ec07d95e4  addpd xmm1, xmm9
00007e1ec07d95e9  vcmppd xmm12, xmm1, xmm1, 0x03
00007e1ec07d95ee  ptest xmm12, xmm12
00007e1ec07d95f4  jnz 0x00007E1EC07DD3D5
00007e1ec07d95fa  vmovaps xmm13, [rsp+0x10]
00007e1ec07d9600  vpermilpd xmm13, xmm13, 0x00
00007e1ec07d9606  movaps xmm12, xmm7
00007e1ec07d960a  mulpd xmm12, xmm13
00007e1ec07d960f  vcmppd xmm9, xmm12, xmm12, 0x03
00007e1ec07d9615  ptest xmm9, xmm9
00007e1ec07d961b  jnz 0x00007E1EC07DD517
00007e1ec07d9621  movaps xmm13, xmm15
00007e1ec07d9625  addpd xmm13, xmm8
00007e1ec07d962a  vcmppd xmm9, xmm13, xmm13, 0x03
00007e1ec07d9630  ptest xmm9, xmm9
00007e1ec07d9636  jnz 0x00007E1EC07DD65A
00007e1ec07d963c  movaps xmm15, [r15+0x290]
00007e1ec07d9644  vmovaps xmm9, [rsp+0x10]
00007e1ec07d964a  vpermilpd xmm9, xmm9, 0x00
00007e1ec07d9650  movaps xmm8, xmm15
00007e1ec07d9654  mulpd xmm8, xmm9
00007e1ec07d9659  vcmppd xmm7, xmm8, xmm8, 0x03
00007e1ec07d965f  ptest xmm7, xmm7
00007e1ec07d9664  jnz 0x00007E1EC07DD79E
00007e1ec07d966a  movaps xmm15, xmm11
00007e1ec07d966e  addpd xmm15, xmm6
00007e1ec07d9673  vcmppd xmm9, xmm15, xmm15, 0x03
00007e1ec07d9679  ptest xmm9, xmm9
00007e1ec07d967f  jnz 0x00007E1EC07DD8E2
00007e1ec07d9685  movaps xmm11, [r15+0x1E0]
00007e1ec07d968d  vmovaps xmm9, [rsp+0x10]
00007e1ec07d9693  vpermilpd xmm9, xmm9, 0x00
00007e1ec07d9699  movaps xmm7, xmm11
00007e1ec07d969d  mulpd xmm7, xmm9
00007e1ec07d96a2  vcmppd xmm6, xmm7, xmm7, 0x03
00007e1ec07d96a7  ptest xmm6, xmm6
00007e1ec07d96ac  jnz 0x00007E1EC07DDA25
00007e1ec07d96b2  movaps xmm11, xmm10
00007e1ec07d96b6  addpd xmm11, xmm14
00007e1ec07d96bb  vcmppd xmm9, xmm11, xmm11, 0x03
00007e1ec07d96c1  ptest xmm9, xmm9
00007e1ec07d96c7  jnz 0x00007E1EC07DDB67
00007e1ec07d96cd  lea r14, [rax+0x70]
00007e1ec07d96d1  movups xmm14, [r13+r14*1]
00007e1ec07d96d7  movaps [r15+0x240], xmm14
00007e1ec07d96df  movaps xmm10, xmm1
00007e1ec07d96e3  addpd xmm10, xmm12
00007e1ec07d96e8  vcmppd xmm9, xmm10, xmm10, 0x03
00007e1ec07d96ee  ptest xmm9, xmm9
00007e1ec07d96f4  jnz 0x00007E1EC07DDCB5
00007e1ec07d96fa  movaps [r15+0x170], xmm10
00007e1ec07d9702  vmovaps xmm1, [rsp+0x20]
00007e1ec07d9708  vpermilpd xmm1, xmm1, 0x00
00007e1ec07d970e  movaps xmm12, xmm14
00007e1ec07d9712  mulpd xmm12, xmm1
00007e1ec07d9717  vcmppd xmm9, xmm12, xmm12, 0x03
00007e1ec07d971d  ptest xmm9, xmm9
00007e1ec07d9723  jnz 0x00007E1EC07DDDF8
00007e1ec07d9729  vmovaps xmm1, [rsp+0x20]
00007e1ec07d972f  vpermilpd xmm1, xmm1, 0x00
00007e1ec07d9735  vmovaps xmm9, [rsp+0xB0]
00007e1ec07d973e  movaps xmm14, xmm9
00007e1ec07d9742  mulpd xmm14, xmm1
00007e1ec07d9747  vcmppd xmm6, xmm14, xmm14, 0x03
00007e1ec07d974d  ptest xmm6, xmm6
00007e1ec07d9752  jnz 0x00007E1EC07DDF3B
00007e1ec07d9758  movaps [r15+0x180], xmm14
00007e1ec07d9760  movaps xmm1, xmm13
00007e1ec07d9764  addpd xmm1, xmm8
00007e1ec07d9769  vcmppd xmm9, xmm1, xmm1, 0x03
00007e1ec07d976e  ptest xmm9, xmm9
00007e1ec07d9774  jnz 0x00007E1EC07DE07E
00007e1ec07d977a  movaps [r15+0x210], xmm1
00007e1ec07d9782  movups xmm13, [r13+rax*1]
00007e1ec07d9788  lea r14, [rax+0x10]
00007e1ec07d978c  movups xmm9, [r13+r14*1]
00007e1ec07d9792  movaps [r15+0x230], xmm9
00007e1ec07d979a  movaps xmm8, xmm15
00007e1ec07d979e  addpd xmm8, xmm7
00007e1ec07d97a3  vcmppd xmm6, xmm8, xmm8, 0x03
00007e1ec07d97a9  ptest xmm6, xmm6
00007e1ec07d97ae  jnz 0x00007E1EC07DE1D4
00007e1ec07d97b4  movaps [r15+0x130], xmm8
00007e1ec07d97bc  vmovaps xmm15, [rsp+0x20]
00007e1ec07d97c2  vpermilpd xmm15, xmm15, 0x00
00007e1ec07d97c8  movaps xmm7, xmm9
00007e1ec07d97cc  mulpd xmm7, xmm15
00007e1ec07d97d1  vcmppd xmm6, xmm7, xmm7, 0x03
00007e1ec07d97d6  ptest xmm6, xmm6
00007e1ec07d97db  jnz 0x00007E1EC07DE317
00007e1ec07d97e1  movaps [r15+0x220], xmm7
00007e1ec07d97e9  vmovaps xmm15, [rsp+0x20]
00007e1ec07d97ef  vpermilpd xmm15, xmm15, 0x00
00007e1ec07d97f5  movaps xmm9, xmm13
00007e1ec07d97f9  mulpd xmm9, xmm15
00007e1ec07d97fe  vcmppd xmm6, xmm9, xmm9, 0x03
00007e1ec07d9804  ptest xmm6, xmm6
00007e1ec07d9809  jnz 0x00007E1EC07DE459
00007e1ec07d980f  movaps xmm15, xmm11
00007e1ec07d9813  addpd xmm15, xmm12
00007e1ec07d9818  vcmppd xmm13, xmm15, xmm15, 0x03
00007e1ec07d981e  ptest xmm13, xmm13
00007e1ec07d9824  jnz 0x00007E1EC07DE59D
00007e1ec07d982a  movaps [r15+0x140], xmm15
00007e1ec07d9832  movaps xmm13, xmm10
00007e1ec07d9836  addpd xmm13, xmm14
00007e1ec07d983b  vcmppd xmm12, xmm13, xmm13, 0x03
00007e1ec07d9841  ptest xmm12, xmm12
00007e1ec07d9847  jnz 0x00007E1EC07DE6E1
00007e1ec07d984d  movaps [r15+0x150], xmm13
00007e1ec07d9855  movaps xmm14, xmm1
00007e1ec07d9859  addpd xmm14, xmm7
00007e1ec07d985e  vcmppd xmm12, xmm14, xmm14, 0x03
00007e1ec07d9864  ptest xmm12, xmm12
00007e1ec07d986a  jnz 0x00007E1EC07DE825
00007e1ec07d9870  movaps [r15+0x160], xmm14
00007e1ec07d9878  movaps xmm1, xmm8
00007e1ec07d987c  addpd xmm1, xmm9
00007e1ec07d9881  vcmppd xmm12, xmm1, xmm1, 0x03
00007e1ec07d9886  ptest xmm12, xmm12
00007e1ec07d988c  jnz 0x00007E1EC07DE967
00007e1ec07d9892  movaps [r15+0x120], xmm1
00007e1ec07d989a  movups [r13+r11*1], xmm15
00007e1ec07d98a0  lea rax, [r11+0x10]
00007e1ec07d98a4  movups [r13+rax*1], xmm13
00007e1ec07d98aa  lea rax, [r11+0x20]
00007e1ec07d98ae  movups [r13+rax*1], xmm14
00007e1ec07d98b4  lea rax, [r11+0x30]
00007e1ec07d98b8  movups [r13+rax*1], xmm1
00007e1ec07d98be  mov eax, [r15+0x108]
00007e1ec07d98c5  sahf
00007e1ec07d98c6  jnz 0x00007E1EC07D98F8
00007e1ec07d98c8  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d98d0  jz 0x00007E1EC07DEAE0
00007e1ec07d98d6  nop [rax+rax*1], ax
00007e1ec07d98df  nop [rax+rax*1], eax
00007e1ec07d98e7  mov eax, 0x4106D0
00007e1ec07d98ec  mov [r15+0x100], rax
00007e1ec07d98f3  jmp 0x00007E1EC05FE110
00007e1ec07d98f8  cmp dword ptr [r15+0x318], 0x00
00007e1ec07d9900  jz 0x00007E1EC07D89C0
00007e1ec07d9906  nop [rax+rax*1], ax
00007e1ec07d990f  nop [rax+rax*1], eax
00007e1ec07d9917  mov eax, 0x410504
00007e1ec07d991c  mov [r15+0x100], rax
00007e1ec07d9923  jmp 0x00007E1EC05FE110
00007e1ec07d9928  int3
00007e1ec07d9929  call 0x00007E1EC060A4B0
00007e1ec07d992e  jmp 0x00007E1EC07D8A08
00007e1ec07d9933  call 0x00007E1EC0609240
00007e1ec07d9938  jmp 0x00007E1EC07D8A12
00007e1ec07d993d  call 0x00007E1EC060A4B0
00007e1ec07d9942  jmp 0x00007E1EC07D8A6F
00007e1ec07d9947  call 0x00007E1EC0609240
00007e1ec07d994c  jmp 0x00007E1EC07D8A79
00007e1ec07d9951  call 0x00007E1EC060A4B0
00007e1ec07d9956  jmp 0x00007E1EC07D8ABD
00007e1ec07d995b  call 0x00007E1EC0609240
00007e1ec07d9960  jmp 0x00007E1EC07D8AC7
00007e1ec07d9965  call 0x00007E1EC06B47C0
00007e1ec07d996a  jmp 0x00007E1EC07D8B06
00007e1ec07d996f  call 0x00007E1EC060B720
00007e1ec07d9974  jmp 0x00007E1EC07D8B1A
00007e1ec07d9979  call 0x00007E1EC06BFC30
00007e1ec07d997e  jmp 0x00007E1EC07D8B38
00007e1ec07d9983  call 0x00007E1EC06BE9C0
00007e1ec07d9988  jmp 0x00007E1EC07D8B42
00007e1ec07d998d  call 0x00007E1EC06BD750
00007e1ec07d9992  jmp 0x00007E1EC07D8B4C
00007e1ec07d9997  sub rsp, 0x08
00007e1ec07d999b  push rax
00007e1ec07d999c  push rcx
00007e1ec07d999d  push rdx
00007e1ec07d999e  push rdi
00007e1ec07d999f  push rsi
00007e1ec07d99a0  push r8
00007e1ec07d99a2  push r9
00007e1ec07d99a4  push r10
00007e1ec07d99a6  push r11
00007e1ec07d99a8  sub rsp, 0xF0
00007e1ec07d99af  vmovaps [rsp], xmm0
00007e1ec07d99b4  vmovaps [rsp+0x10], xmm1
00007e1ec07d99ba  vmovaps [rsp+0x20], xmm2
00007e1ec07d99c0  vmovaps [rsp+0x30], xmm3
00007e1ec07d99c6  vmovaps [rsp+0x40], xmm4
00007e1ec07d99cc  vmovaps [rsp+0x50], xmm5
00007e1ec07d99d2  vmovaps [rsp+0x60], xmm6
00007e1ec07d99d8  vmovaps [rsp+0x70], xmm7
00007e1ec07d99de  vmovaps [rsp+0x80], xmm9
00007e1ec07d99e7  vmovaps [rsp+0x90], xmm10
00007e1ec07d99f0  vmovaps [rsp+0xA0], xmm11
00007e1ec07d99f9  vmovaps [rsp+0xB0], xmm12
00007e1ec07d9a02  vmovaps [rsp+0xC0], xmm13
00007e1ec07d9a0b  vmovaps [rsp+0xD0], xmm14
00007e1ec07d9a14  vmovaps [rsp+0xE0], xmm15
00007e1ec07d9a1d  sub rsp, 0x30
00007e1ec07d9a21  movaps [rsp], xmm8
00007e1ec07d9a26  movaps [rsp+0x10], xmm12
00007e1ec07d9a2c  movaps [rsp+0x20], xmm15
00007e1ec07d9a32  lea rdi, [rsp]
00007e1ec07d9a36  mov esi, 0x00
00007e1ec07d9a3b  mov rax, 0x5E00FF778530
00007e1ec07d9a45  call rax
00007e1ec07d9a47  movaps xmm8, [rsp]
00007e1ec07d9a4c  add rsp, 0x30
00007e1ec07d9a50  vmovaps xmm0, [rsp]
00007e1ec07d9a55  vmovaps xmm1, [rsp+0x10]
00007e1ec07d9a5b  vmovaps xmm2, [rsp+0x20]
00007e1ec07d9a61  vmovaps xmm3, [rsp+0x30]
00007e1ec07d9a67  vmovaps xmm4, [rsp+0x40]
00007e1ec07d9a6d  vmovaps xmm5, [rsp+0x50]
00007e1ec07d9a73  vmovaps xmm6, [rsp+0x60]
00007e1ec07d9a79  vmovaps xmm7, [rsp+0x70]
00007e1ec07d9a7f  vmovaps xmm9, [rsp+0x80]
00007e1ec07d9a88  vmovaps xmm10, [rsp+0x90]
00007e1ec07d9a91  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d9a9a  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d9aa3  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d9aac  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d9ab5  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d9abe  add rsp, 0xF0
00007e1ec07d9ac5  pop r11
00007e1ec07d9ac7  pop r10
00007e1ec07d9ac9  pop r9
00007e1ec07d9acb  pop r8
00007e1ec07d9acd  pop rsi
00007e1ec07d9ace  pop rdi
00007e1ec07d9acf  pop rdx
00007e1ec07d9ad0  pop rcx
00007e1ec07d9ad1  pop rax
00007e1ec07d9ad2  add rsp, 0x08
00007e1ec07d9ad6  jmp 0x00007E1EC07D8B7A
00007e1ec07d9adb  sub rsp, 0x08
00007e1ec07d9adf  push rax
00007e1ec07d9ae0  push rcx
00007e1ec07d9ae1  push rdx
00007e1ec07d9ae2  push rdi
00007e1ec07d9ae3  push rsi
00007e1ec07d9ae4  push r8
00007e1ec07d9ae6  push r9
00007e1ec07d9ae8  push r10
00007e1ec07d9aea  push r11
00007e1ec07d9aec  sub rsp, 0xF0
00007e1ec07d9af3  vmovaps [rsp], xmm0
00007e1ec07d9af8  vmovaps [rsp+0x10], xmm1
00007e1ec07d9afe  vmovaps [rsp+0x20], xmm2
00007e1ec07d9b04  vmovaps [rsp+0x30], xmm3
00007e1ec07d9b0a  vmovaps [rsp+0x40], xmm4
00007e1ec07d9b10  vmovaps [rsp+0x50], xmm5
00007e1ec07d9b16  vmovaps [rsp+0x60], xmm6
00007e1ec07d9b1c  vmovaps [rsp+0x70], xmm8
00007e1ec07d9b22  vmovaps [rsp+0x80], xmm9
00007e1ec07d9b2b  vmovaps [rsp+0x90], xmm10
00007e1ec07d9b34  vmovaps [rsp+0xA0], xmm11
00007e1ec07d9b3d  vmovaps [rsp+0xB0], xmm12
00007e1ec07d9b46  vmovaps [rsp+0xC0], xmm13
00007e1ec07d9b4f  vmovaps [rsp+0xD0], xmm14
00007e1ec07d9b58  vmovaps [rsp+0xE0], xmm15
00007e1ec07d9b61  sub rsp, 0x30
00007e1ec07d9b65  movaps [rsp], xmm7
00007e1ec07d9b69  movaps [rsp+0x10], xmm9
00007e1ec07d9b6f  movaps [rsp+0x20], xmm15
00007e1ec07d9b75  lea rdi, [rsp]
00007e1ec07d9b79  mov esi, 0x00
00007e1ec07d9b7e  mov rax, 0x5E00FF778530
00007e1ec07d9b88  call rax
00007e1ec07d9b8a  movaps xmm7, [rsp]
00007e1ec07d9b8e  add rsp, 0x30
00007e1ec07d9b92  vmovaps xmm0, [rsp]
00007e1ec07d9b97  vmovaps xmm1, [rsp+0x10]
00007e1ec07d9b9d  vmovaps xmm2, [rsp+0x20]
00007e1ec07d9ba3  vmovaps xmm3, [rsp+0x30]
00007e1ec07d9ba9  vmovaps xmm4, [rsp+0x40]
00007e1ec07d9baf  vmovaps xmm5, [rsp+0x50]
00007e1ec07d9bb5  vmovaps xmm6, [rsp+0x60]
00007e1ec07d9bbb  vmovaps xmm8, [rsp+0x70]
00007e1ec07d9bc1  vmovaps xmm9, [rsp+0x80]
00007e1ec07d9bca  vmovaps xmm10, [rsp+0x90]
00007e1ec07d9bd3  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d9bdc  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d9be5  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d9bee  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d9bf7  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d9c00  add rsp, 0xF0
00007e1ec07d9c07  pop r11
00007e1ec07d9c09  pop r10
00007e1ec07d9c0b  pop r9
00007e1ec07d9c0d  pop r8
00007e1ec07d9c0f  pop rsi
00007e1ec07d9c10  pop rdi
00007e1ec07d9c11  pop rdx
00007e1ec07d9c12  pop rcx
00007e1ec07d9c13  pop rax
00007e1ec07d9c14  add rsp, 0x08
00007e1ec07d9c18  jmp 0x00007E1EC07D8BA8
00007e1ec07d9c1d  sub rsp, 0x08
00007e1ec07d9c21  push rax
00007e1ec07d9c22  push rcx
00007e1ec07d9c23  push rdx
00007e1ec07d9c24  push rdi
00007e1ec07d9c25  push rsi
00007e1ec07d9c26  push r8
00007e1ec07d9c28  push r9
00007e1ec07d9c2a  push r10
00007e1ec07d9c2c  push r11
00007e1ec07d9c2e  sub rsp, 0xF0
00007e1ec07d9c35  vmovaps [rsp], xmm0
00007e1ec07d9c3a  vmovaps [rsp+0x10], xmm1
00007e1ec07d9c40  vmovaps [rsp+0x20], xmm2
00007e1ec07d9c46  vmovaps [rsp+0x30], xmm3
00007e1ec07d9c4c  vmovaps [rsp+0x40], xmm4
00007e1ec07d9c52  vmovaps [rsp+0x50], xmm5
00007e1ec07d9c58  vmovaps [rsp+0x60], xmm6
00007e1ec07d9c5e  vmovaps [rsp+0x70], xmm7
00007e1ec07d9c64  vmovaps [rsp+0x80], xmm8
00007e1ec07d9c6d  vmovaps [rsp+0x90], xmm10
00007e1ec07d9c76  vmovaps [rsp+0xA0], xmm11
00007e1ec07d9c7f  vmovaps [rsp+0xB0], xmm12
00007e1ec07d9c88  vmovaps [rsp+0xC0], xmm13
00007e1ec07d9c91  vmovaps [rsp+0xD0], xmm14
00007e1ec07d9c9a  vmovaps [rsp+0xE0], xmm15
00007e1ec07d9ca3  sub rsp, 0x30
00007e1ec07d9ca7  movaps [rsp], xmm9
00007e1ec07d9cac  movaps [rsp+0x10], xmm12
00007e1ec07d9cb2  movaps [rsp+0x20], xmm10
00007e1ec07d9cb8  lea rdi, [rsp]
00007e1ec07d9cbc  mov esi, 0x00
00007e1ec07d9cc1  mov rax, 0x5E00FF778530
00007e1ec07d9ccb  call rax
00007e1ec07d9ccd  movaps xmm9, [rsp]
00007e1ec07d9cd2  add rsp, 0x30
00007e1ec07d9cd6  vmovaps xmm0, [rsp]
00007e1ec07d9cdb  vmovaps xmm1, [rsp+0x10]
00007e1ec07d9ce1  vmovaps xmm2, [rsp+0x20]
00007e1ec07d9ce7  vmovaps xmm3, [rsp+0x30]
00007e1ec07d9ced  vmovaps xmm4, [rsp+0x40]
00007e1ec07d9cf3  vmovaps xmm5, [rsp+0x50]
00007e1ec07d9cf9  vmovaps xmm6, [rsp+0x60]
00007e1ec07d9cff  vmovaps xmm7, [rsp+0x70]
00007e1ec07d9d05  vmovaps xmm8, [rsp+0x80]
00007e1ec07d9d0e  vmovaps xmm10, [rsp+0x90]
00007e1ec07d9d17  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d9d20  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d9d29  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d9d32  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d9d3b  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d9d44  add rsp, 0xF0
00007e1ec07d9d4b  pop r11
00007e1ec07d9d4d  pop r10
00007e1ec07d9d4f  pop r9
00007e1ec07d9d51  pop r8
00007e1ec07d9d53  pop rsi
00007e1ec07d9d54  pop rdi
00007e1ec07d9d55  pop rdx
00007e1ec07d9d56  pop rcx
00007e1ec07d9d57  pop rax
00007e1ec07d9d58  add rsp, 0x08
00007e1ec07d9d5c  jmp 0x00007E1EC07D8BCC
00007e1ec07d9d61  sub rsp, 0x08
00007e1ec07d9d65  push rax
00007e1ec07d9d66  push rcx
00007e1ec07d9d67  push rdx
00007e1ec07d9d68  push rdi
00007e1ec07d9d69  push rsi
00007e1ec07d9d6a  push r8
00007e1ec07d9d6c  push r9
00007e1ec07d9d6e  push r10
00007e1ec07d9d70  push r11
00007e1ec07d9d72  sub rsp, 0xF0
00007e1ec07d9d79  vmovaps [rsp], xmm0
00007e1ec07d9d7e  vmovaps [rsp+0x10], xmm1
00007e1ec07d9d84  vmovaps [rsp+0x20], xmm2
00007e1ec07d9d8a  vmovaps [rsp+0x30], xmm3
00007e1ec07d9d90  vmovaps [rsp+0x40], xmm4
00007e1ec07d9d96  vmovaps [rsp+0x50], xmm5
00007e1ec07d9d9c  vmovaps [rsp+0x60], xmm6
00007e1ec07d9da2  vmovaps [rsp+0x70], xmm7
00007e1ec07d9da8  vmovaps [rsp+0x80], xmm8
00007e1ec07d9db1  vmovaps [rsp+0x90], xmm9
00007e1ec07d9dba  vmovaps [rsp+0xA0], xmm11
00007e1ec07d9dc3  vmovaps [rsp+0xB0], xmm12
00007e1ec07d9dcc  vmovaps [rsp+0xC0], xmm13
00007e1ec07d9dd5  vmovaps [rsp+0xD0], xmm14
00007e1ec07d9dde  vmovaps [rsp+0xE0], xmm15
00007e1ec07d9de7  sub rsp, 0x30
00007e1ec07d9deb  movaps [rsp], xmm10
00007e1ec07d9df0  movaps [rsp+0x10], xmm12
00007e1ec07d9df6  movaps [rsp+0x20], xmm11
00007e1ec07d9dfc  lea rdi, [rsp]
00007e1ec07d9e00  mov esi, 0x00
00007e1ec07d9e05  mov rax, 0x5E00FF778530
00007e1ec07d9e0f  call rax
00007e1ec07d9e11  movaps xmm10, [rsp]
00007e1ec07d9e16  add rsp, 0x30
00007e1ec07d9e1a  vmovaps xmm0, [rsp]
00007e1ec07d9e1f  vmovaps xmm1, [rsp+0x10]
00007e1ec07d9e25  vmovaps xmm2, [rsp+0x20]
00007e1ec07d9e2b  vmovaps xmm3, [rsp+0x30]
00007e1ec07d9e31  vmovaps xmm4, [rsp+0x40]
00007e1ec07d9e37  vmovaps xmm5, [rsp+0x50]
00007e1ec07d9e3d  vmovaps xmm6, [rsp+0x60]
00007e1ec07d9e43  vmovaps xmm7, [rsp+0x70]
00007e1ec07d9e49  vmovaps xmm8, [rsp+0x80]
00007e1ec07d9e52  vmovaps xmm9, [rsp+0x90]
00007e1ec07d9e5b  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d9e64  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d9e6d  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d9e76  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d9e7f  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d9e88  add rsp, 0xF0
00007e1ec07d9e8f  pop r11
00007e1ec07d9e91  pop r10
00007e1ec07d9e93  pop r9
00007e1ec07d9e95  pop r8
00007e1ec07d9e97  pop rsi
00007e1ec07d9e98  pop rdi
00007e1ec07d9e99  pop rdx
00007e1ec07d9e9a  pop rcx
00007e1ec07d9e9b  pop rax
00007e1ec07d9e9c  add rsp, 0x08
00007e1ec07d9ea0  jmp 0x00007E1EC07D8BE6
00007e1ec07d9ea5  sub rsp, 0x08
00007e1ec07d9ea9  push rax
00007e1ec07d9eaa  push rcx
00007e1ec07d9eab  push rdx
00007e1ec07d9eac  push rdi
00007e1ec07d9ead  push rsi
00007e1ec07d9eae  push r8
00007e1ec07d9eb0  push r9
00007e1ec07d9eb2  push r10
00007e1ec07d9eb4  push r11
00007e1ec07d9eb6  sub rsp, 0xF0
00007e1ec07d9ebd  vmovaps [rsp], xmm0
00007e1ec07d9ec2  vmovaps [rsp+0x10], xmm1
00007e1ec07d9ec8  vmovaps [rsp+0x20], xmm2
00007e1ec07d9ece  vmovaps [rsp+0x30], xmm3
00007e1ec07d9ed4  vmovaps [rsp+0x40], xmm4
00007e1ec07d9eda  vmovaps [rsp+0x50], xmm5
00007e1ec07d9ee0  vmovaps [rsp+0x60], xmm7
00007e1ec07d9ee6  vmovaps [rsp+0x70], xmm8
00007e1ec07d9eec  vmovaps [rsp+0x80], xmm9
00007e1ec07d9ef5  vmovaps [rsp+0x90], xmm10
00007e1ec07d9efe  vmovaps [rsp+0xA0], xmm11
00007e1ec07d9f07  vmovaps [rsp+0xB0], xmm12
00007e1ec07d9f10  vmovaps [rsp+0xC0], xmm13
00007e1ec07d9f19  vmovaps [rsp+0xD0], xmm14
00007e1ec07d9f22  vmovaps [rsp+0xE0], xmm15
00007e1ec07d9f2b  sub rsp, 0x30
00007e1ec07d9f2f  movaps [rsp], xmm6
00007e1ec07d9f33  movaps [rsp+0x10], xmm12
00007e1ec07d9f39  movaps [rsp+0x20], xmm11
00007e1ec07d9f3f  lea rdi, [rsp]
00007e1ec07d9f43  mov esi, 0x00
00007e1ec07d9f48  mov rax, 0x5E00FF778530
00007e1ec07d9f52  call rax
00007e1ec07d9f54  movaps xmm6, [rsp]
00007e1ec07d9f58  add rsp, 0x30
00007e1ec07d9f5c  vmovaps xmm0, [rsp]
00007e1ec07d9f61  vmovaps xmm1, [rsp+0x10]
00007e1ec07d9f67  vmovaps xmm2, [rsp+0x20]
00007e1ec07d9f6d  vmovaps xmm3, [rsp+0x30]
00007e1ec07d9f73  vmovaps xmm4, [rsp+0x40]
00007e1ec07d9f79  vmovaps xmm5, [rsp+0x50]
00007e1ec07d9f7f  vmovaps xmm7, [rsp+0x60]
00007e1ec07d9f85  vmovaps xmm8, [rsp+0x70]
00007e1ec07d9f8b  vmovaps xmm9, [rsp+0x80]
00007e1ec07d9f94  vmovaps xmm10, [rsp+0x90]
00007e1ec07d9f9d  vmovaps xmm11, [rsp+0xA0]
00007e1ec07d9fa6  vmovaps xmm12, [rsp+0xB0]
00007e1ec07d9faf  vmovaps xmm13, [rsp+0xC0]
00007e1ec07d9fb8  vmovaps xmm14, [rsp+0xD0]
00007e1ec07d9fc1  vmovaps xmm15, [rsp+0xE0]
00007e1ec07d9fca  add rsp, 0xF0
00007e1ec07d9fd1  pop r11
00007e1ec07d9fd3  pop r10
00007e1ec07d9fd5  pop r9
00007e1ec07d9fd7  pop r8
00007e1ec07d9fd9  pop rsi
00007e1ec07d9fda  pop rdi
00007e1ec07d9fdb  pop rdx
00007e1ec07d9fdc  pop rcx
00007e1ec07d9fdd  pop rax
00007e1ec07d9fde  add rsp, 0x08
00007e1ec07d9fe2  jmp 0x00007E1EC07D8C07
00007e1ec07d9fe7  sub rsp, 0x08
00007e1ec07d9feb  push rax
00007e1ec07d9fec  push rcx
00007e1ec07d9fed  push rdx
00007e1ec07d9fee  push rdi
00007e1ec07d9fef  push rsi
00007e1ec07d9ff0  push r8
00007e1ec07d9ff2  push r9
00007e1ec07d9ff4  push r10
00007e1ec07d9ff6  push r11
00007e1ec07d9ff8  sub rsp, 0xF0
00007e1ec07d9fff  vmovaps [rsp], xmm0
00007e1ec07da004  vmovaps [rsp+0x10], xmm1
00007e1ec07da00a  vmovaps [rsp+0x20], xmm2
00007e1ec07da010  vmovaps [rsp+0x30], xmm4
00007e1ec07da016  vmovaps [rsp+0x40], xmm5
00007e1ec07da01c  vmovaps [rsp+0x50], xmm6
00007e1ec07da022  vmovaps [rsp+0x60], xmm7
00007e1ec07da028  vmovaps [rsp+0x70], xmm8
00007e1ec07da02e  vmovaps [rsp+0x80], xmm9
00007e1ec07da037  vmovaps [rsp+0x90], xmm10
00007e1ec07da040  vmovaps [rsp+0xA0], xmm11
00007e1ec07da049  vmovaps [rsp+0xB0], xmm12
00007e1ec07da052  vmovaps [rsp+0xC0], xmm13
00007e1ec07da05b  vmovaps [rsp+0xD0], xmm14
00007e1ec07da064  vmovaps [rsp+0xE0], xmm15
00007e1ec07da06d  sub rsp, 0x30
00007e1ec07da071  movaps [rsp], xmm3
00007e1ec07da075  movaps [rsp+0x10], xmm5
00007e1ec07da07a  movaps [rsp+0x20], xmm4
00007e1ec07da07f  lea rdi, [rsp]
00007e1ec07da083  mov esi, 0x00
00007e1ec07da088  mov rax, 0x5E00FF778530
00007e1ec07da092  call rax
00007e1ec07da094  movaps xmm3, [rsp]
00007e1ec07da098  add rsp, 0x30
00007e1ec07da09c  vmovaps xmm0, [rsp]
00007e1ec07da0a1  vmovaps xmm1, [rsp+0x10]
00007e1ec07da0a7  vmovaps xmm2, [rsp+0x20]
00007e1ec07da0ad  vmovaps xmm4, [rsp+0x30]
00007e1ec07da0b3  vmovaps xmm5, [rsp+0x40]
00007e1ec07da0b9  vmovaps xmm6, [rsp+0x50]
00007e1ec07da0bf  vmovaps xmm7, [rsp+0x60]
00007e1ec07da0c5  vmovaps xmm8, [rsp+0x70]
00007e1ec07da0cb  vmovaps xmm9, [rsp+0x80]
00007e1ec07da0d4  vmovaps xmm10, [rsp+0x90]
00007e1ec07da0dd  vmovaps xmm11, [rsp+0xA0]
00007e1ec07da0e6  vmovaps xmm12, [rsp+0xB0]
00007e1ec07da0ef  vmovaps xmm13, [rsp+0xC0]
00007e1ec07da0f8  vmovaps xmm14, [rsp+0xD0]
00007e1ec07da101  vmovaps xmm15, [rsp+0xE0]
00007e1ec07da10a  add rsp, 0xF0
00007e1ec07da111  pop r11
00007e1ec07da113  pop r10
00007e1ec07da115  pop r9
00007e1ec07da117  pop r8
00007e1ec07da119  pop rsi
00007e1ec07da11a  pop rdi
00007e1ec07da11b  pop rdx
00007e1ec07da11c  pop rcx
00007e1ec07da11d  pop rax
00007e1ec07da11e  add rsp, 0x08
00007e1ec07da122  jmp 0x00007E1EC07D8C68
00007e1ec07da127  sub rsp, 0x08
00007e1ec07da12b  push rax
00007e1ec07da12c  push rcx
00007e1ec07da12d  push rdx
00007e1ec07da12e  push rdi
00007e1ec07da12f  push rsi
00007e1ec07da130  push r8
00007e1ec07da132  push r9
00007e1ec07da134  push r10
00007e1ec07da136  push r11
00007e1ec07da138  sub rsp, 0xF0
00007e1ec07da13f  vmovaps [rsp], xmm0
00007e1ec07da144  vmovaps [rsp+0x10], xmm1
00007e1ec07da14a  vmovaps [rsp+0x20], xmm2
00007e1ec07da150  vmovaps [rsp+0x30], xmm3
00007e1ec07da156  vmovaps [rsp+0x40], xmm4
00007e1ec07da15c  vmovaps [rsp+0x50], xmm6
00007e1ec07da162  vmovaps [rsp+0x60], xmm7
00007e1ec07da168  vmovaps [rsp+0x70], xmm8
00007e1ec07da16e  vmovaps [rsp+0x80], xmm9
00007e1ec07da177  vmovaps [rsp+0x90], xmm10
00007e1ec07da180  vmovaps [rsp+0xA0], xmm11
00007e1ec07da189  vmovaps [rsp+0xB0], xmm12
00007e1ec07da192  vmovaps [rsp+0xC0], xmm13
00007e1ec07da19b  vmovaps [rsp+0xD0], xmm14
00007e1ec07da1a4  vmovaps [rsp+0xE0], xmm15
00007e1ec07da1ad  sub rsp, 0x30
00007e1ec07da1b1  movaps [rsp], xmm5
00007e1ec07da1b5  movaps [rsp+0x10], xmm8
00007e1ec07da1bb  movaps [rsp+0x20], xmm15
00007e1ec07da1c1  lea rdi, [rsp]
00007e1ec07da1c5  mov esi, 0x00
00007e1ec07da1ca  mov rax, 0x5E00FF778530
00007e1ec07da1d4  call rax
00007e1ec07da1d6  movaps xmm5, [rsp]
00007e1ec07da1da  add rsp, 0x30
00007e1ec07da1de  vmovaps xmm0, [rsp]
00007e1ec07da1e3  vmovaps xmm1, [rsp+0x10]
00007e1ec07da1e9  vmovaps xmm2, [rsp+0x20]
00007e1ec07da1ef  vmovaps xmm3, [rsp+0x30]
00007e1ec07da1f5  vmovaps xmm4, [rsp+0x40]
00007e1ec07da1fb  vmovaps xmm6, [rsp+0x50]
00007e1ec07da201  vmovaps xmm7, [rsp+0x60]
00007e1ec07da207  vmovaps xmm8, [rsp+0x70]
00007e1ec07da20d  vmovaps xmm9, [rsp+0x80]
00007e1ec07da216  vmovaps xmm10, [rsp+0x90]
00007e1ec07da21f  vmovaps xmm11, [rsp+0xA0]
00007e1ec07da228  vmovaps xmm12, [rsp+0xB0]
00007e1ec07da231  vmovaps xmm13, [rsp+0xC0]
00007e1ec07da23a  vmovaps xmm14, [rsp+0xD0]
00007e1ec07da243  vmovaps xmm15, [rsp+0xE0]
00007e1ec07da24c  add rsp, 0xF0
00007e1ec07da253  pop r11
00007e1ec07da255  pop r10
00007e1ec07da257  pop r9
00007e1ec07da259  pop r8
00007e1ec07da25b  pop rsi
00007e1ec07da25c  pop rdi
00007e1ec07da25d  pop rdx
00007e1ec07da25e  pop rcx
00007e1ec07da25f  pop rax
00007e1ec07da260  add rsp, 0x08
00007e1ec07da264  jmp 0x00007E1EC07D8CA0
00007e1ec07da269  sub rsp, 0x08
00007e1ec07da26d  push rax
00007e1ec07da26e  push rcx
00007e1ec07da26f  push rdx
00007e1ec07da270  push rdi
00007e1ec07da271  push rsi
00007e1ec07da272  push r8
00007e1ec07da274  push r9
00007e1ec07da276  push r10
00007e1ec07da278  push r11
00007e1ec07da27a  sub rsp, 0xF0
00007e1ec07da281  vmovaps [rsp], xmm0
00007e1ec07da286  vmovaps [rsp+0x10], xmm1
00007e1ec07da28c  vmovaps [rsp+0x20], xmm2
00007e1ec07da292  vmovaps [rsp+0x30], xmm3
00007e1ec07da298  vmovaps [rsp+0x40], xmm5
00007e1ec07da29e  vmovaps [rsp+0x50], xmm6
00007e1ec07da2a4  vmovaps [rsp+0x60], xmm7
00007e1ec07da2aa  vmovaps [rsp+0x70], xmm8
00007e1ec07da2b0  vmovaps [rsp+0x80], xmm9
00007e1ec07da2b9  vmovaps [rsp+0x90], xmm10
00007e1ec07da2c2  vmovaps [rsp+0xA0], xmm11
00007e1ec07da2cb  vmovaps [rsp+0xB0], xmm12
00007e1ec07da2d4  vmovaps [rsp+0xC0], xmm13
00007e1ec07da2dd  vmovaps [rsp+0xD0], xmm14
00007e1ec07da2e6  vmovaps [rsp+0xE0], xmm15
00007e1ec07da2ef  sub rsp, 0x30
00007e1ec07da2f3  movaps [rsp], xmm4
00007e1ec07da2f7  movaps [rsp+0x10], xmm9
00007e1ec07da2fd  movaps [rsp+0x20], xmm8
00007e1ec07da303  lea rdi, [rsp]
00007e1ec07da307  mov esi, 0x00
00007e1ec07da30c  mov rax, 0x5E00FF778530
00007e1ec07da316  call rax
00007e1ec07da318  movaps xmm4, [rsp]
00007e1ec07da31c  add rsp, 0x30
00007e1ec07da320  vmovaps xmm0, [rsp]
00007e1ec07da325  vmovaps xmm1, [rsp+0x10]
00007e1ec07da32b  vmovaps xmm2, [rsp+0x20]
00007e1ec07da331  vmovaps xmm3, [rsp+0x30]
00007e1ec07da337  vmovaps xmm5, [rsp+0x40]
00007e1ec07da33d  vmovaps xmm6, [rsp+0x50]
00007e1ec07da343  vmovaps xmm7, [rsp+0x60]
00007e1ec07da349  vmovaps xmm8, [rsp+0x70]
00007e1ec07da34f  vmovaps xmm9, [rsp+0x80]
00007e1ec07da358  vmovaps xmm10, [rsp+0x90]
00007e1ec07da361  vmovaps xmm11, [rsp+0xA0]
00007e1ec07da36a  vmovaps xmm12, [rsp+0xB0]
00007e1ec07da373  vmovaps xmm13, [rsp+0xC0]
00007e1ec07da37c  vmovaps xmm14, [rsp+0xD0]
00007e1ec07da385  vmovaps xmm15, [rsp+0xE0]
00007e1ec07da38e  add rsp, 0xF0
00007e1ec07da395  pop r11
00007e1ec07da397  pop r10
00007e1ec07da399  pop r9
00007e1ec07da39b  pop r8
00007e1ec07da39d  pop rsi
00007e1ec07da39e  pop rdi
00007e1ec07da39f  pop rdx
00007e1ec07da3a0  pop rcx
00007e1ec07da3a1  pop rax
00007e1ec07da3a2  add rsp, 0x08
00007e1ec07da3a6  jmp 0x00007E1EC07D8CC1
00007e1ec07da3ab  sub rsp, 0x08
00007e1ec07da3af  push rax
00007e1ec07da3b0  push rcx
00007e1ec07da3b1  push rdx
00007e1ec07da3b2  push rdi
00007e1ec07da3b3  push rsi
00007e1ec07da3b4  push r8
00007e1ec07da3b6  push r9
00007e1ec07da3b8  push r10
00007e1ec07da3ba  push r11
00007e1ec07da3bc  sub rsp, 0xF0
00007e1ec07da3c3  vmovaps [rsp], xmm0
00007e1ec07da3c8  vmovaps [rsp+0x10], xmm1
00007e1ec07da3ce  vmovaps [rsp+0x20], xmm2
00007e1ec07da3d4  vmovaps [rsp+0x30], xmm3
00007e1ec07da3da  vmovaps [rsp+0x40], xmm4
00007e1ec07da3e0  vmovaps [rsp+0x50], xmm5
00007e1ec07da3e6  vmovaps [rsp+0x60], xmm6
00007e1ec07da3ec  vmovaps [rsp+0x70], xmm7
00007e1ec07da3f2  vmovaps [rsp+0x80], xmm8
00007e1ec07da3fb  vmovaps [rsp+0x90], xmm10
00007e1ec07da404  vmovaps [rsp+0xA0], xmm11
00007e1ec07da40d  vmovaps [rsp+0xB0], xmm12
00007e1ec07da416  vmovaps [rsp+0xC0], xmm13
00007e1ec07da41f  vmovaps [rsp+0xD0], xmm14
00007e1ec07da428  vmovaps [rsp+0xE0], xmm15
00007e1ec07da431  sub rsp, 0x30
00007e1ec07da435  movaps [rsp], xmm9
00007e1ec07da43a  movaps [rsp+0x10], xmm10
00007e1ec07da440  movaps [rsp+0x20], xmm8
00007e1ec07da446  lea rdi, [rsp]
00007e1ec07da44a  mov esi, 0x00
00007e1ec07da44f  mov rax, 0x5E00FF778530
00007e1ec07da459  call rax
00007e1ec07da45b  movaps xmm9, [rsp]
00007e1ec07da460  add rsp, 0x30
00007e1ec07da464  vmovaps xmm0, [rsp]
00007e1ec07da469  vmovaps xmm1, [rsp+0x10]
00007e1ec07da46f  vmovaps xmm2, [rsp+0x20]
00007e1ec07da475  vmovaps xmm3, [rsp+0x30]
00007e1ec07da47b  vmovaps xmm4, [rsp+0x40]
00007e1ec07da481  vmovaps xmm5, [rsp+0x50]
00007e1ec07da487  vmovaps xmm6, [rsp+0x60]
00007e1ec07da48d  vmovaps xmm7, [rsp+0x70]
00007e1ec07da493  vmovaps xmm8, [rsp+0x80]
00007e1ec07da49c  vmovaps xmm10, [rsp+0x90]
00007e1ec07da4a5  vmovaps xmm11, [rsp+0xA0]
00007e1ec07da4ae  vmovaps xmm12, [rsp+0xB0]
00007e1ec07da4b7  vmovaps xmm13, [rsp+0xC0]
00007e1ec07da4c0  vmovaps xmm14, [rsp+0xD0]
00007e1ec07da4c9  vmovaps xmm15, [rsp+0xE0]
00007e1ec07da4d2  add rsp, 0xF0
00007e1ec07da4d9  pop r11
00007e1ec07da4db  pop r10
00007e1ec07da4dd  pop r9
00007e1ec07da4df  pop r8
00007e1ec07da4e1  pop rsi
00007e1ec07da4e2  pop rdi
00007e1ec07da4e3  pop rdx
00007e1ec07da4e4  pop rcx
00007e1ec07da4e5  pop rax
00007e1ec07da4e6  add rsp, 0x08
00007e1ec07da4ea  jmp 0x00007E1EC07D8CDB
00007e1ec07da4ef  call 0x00007E1EC06D64F0
00007e1ec07da4f4  jmp 0x00007E1EC07D8DF5
00007e1ec07da4f9  call 0x00007E1EC06D64F0
00007e1ec07da4fe  jmp 0x00007E1EC07D8E0B
00007e1ec07da503  sub rsp, 0x08
00007e1ec07da507  push rax
00007e1ec07da508  push rcx
00007e1ec07da509  push rdx
00007e1ec07da50a  push rdi
00007e1ec07da50b  push rsi
00007e1ec07da50c  push r8
00007e1ec07da50e  push r9
00007e1ec07da510  push r10
00007e1ec07da512  push r11
00007e1ec07da514  sub rsp, 0xF0
00007e1ec07da51b  vmovaps [rsp], xmm0
00007e1ec07da520  vmovaps [rsp+0x10], xmm2
00007e1ec07da526  vmovaps [rsp+0x20], xmm3
00007e1ec07da52c  vmovaps [rsp+0x30], xmm4
00007e1ec07da532  vmovaps [rsp+0x40], xmm5
00007e1ec07da538  vmovaps [rsp+0x50], xmm6
00007e1ec07da53e  vmovaps [rsp+0x60], xmm7
00007e1ec07da544  vmovaps [rsp+0x70], xmm8
00007e1ec07da54a  vmovaps [rsp+0x80], xmm9
00007e1ec07da553  vmovaps [rsp+0x90], xmm10
00007e1ec07da55c  vmovaps [rsp+0xA0], xmm11
00007e1ec07da565  vmovaps [rsp+0xB0], xmm12
00007e1ec07da56e  vmovaps [rsp+0xC0], xmm13
00007e1ec07da577  vmovaps [rsp+0xD0], xmm14
00007e1ec07da580  vmovaps [rsp+0xE0], xmm15
00007e1ec07da589  sub rsp, 0x30
00007e1ec07da58d  movaps [rsp], xmm1
00007e1ec07da591  movaps [rsp+0x10], xmm6
00007e1ec07da596  movaps [rsp+0x20], xmm15
00007e1ec07da59c  lea rdi, [rsp]
00007e1ec07da5a0  mov esi, 0x00
00007e1ec07da5a5  mov rax, 0x5E00FF778530
00007e1ec07da5af  call rax
00007e1ec07da5b1  movaps xmm1, [rsp]
00007e1ec07da5b5  add rsp, 0x30
00007e1ec07da5b9  vmovaps xmm0, [rsp]
00007e1ec07da5be  vmovaps xmm2, [rsp+0x10]
00007e1ec07da5c4  vmovaps xmm3, [rsp+0x20]
00007e1ec07da5ca  vmovaps xmm4, [rsp+0x30]
00007e1ec07da5d0  vmovaps xmm5, [rsp+0x40]
00007e1ec07da5d6  vmovaps xmm6, [rsp+0x50]
00007e1ec07da5dc  vmovaps xmm7, [rsp+0x60]
00007e1ec07da5e2  vmovaps xmm8, [rsp+0x70]
00007e1ec07da5e8  vmovaps xmm9, [rsp+0x80]
00007e1ec07da5f1  vmovaps xmm10, [rsp+0x90]
00007e1ec07da5fa  vmovaps xmm11, [rsp+0xA0]
00007e1ec07da603  vmovaps xmm12, [rsp+0xB0]
00007e1ec07da60c  vmovaps xmm13, [rsp+0xC0]
00007e1ec07da615  vmovaps xmm14, [rsp+0xD0]
00007e1ec07da61e  vmovaps xmm15, [rsp+0xE0]
00007e1ec07da627  add rsp, 0xF0
00007e1ec07da62e  pop r11
00007e1ec07da630  pop r10
00007e1ec07da632  pop r9
00007e1ec07da634  pop r8
00007e1ec07da636  pop rsi
00007e1ec07da637  pop rdi
00007e1ec07da638  pop rdx
00007e1ec07da639  pop rcx
00007e1ec07da63a  pop rax
00007e1ec07da63b  add rsp, 0x08
00007e1ec07da63f  jmp 0x00007E1EC07D8E48
00007e1ec07da644  call 0x00007E1EC06E5820
00007e1ec07da649  jmp 0x00007E1EC07D8E55
00007e1ec07da64e  sub rsp, 0x08
00007e1ec07da652  push rax
00007e1ec07da653  push rcx
00007e1ec07da654  push rdx
00007e1ec07da655  push rdi
00007e1ec07da656  push rsi
00007e1ec07da657  push r8
00007e1ec07da659  push r9
00007e1ec07da65b  push r10
00007e1ec07da65d  push r11
00007e1ec07da65f  sub rsp, 0xF0
00007e1ec07da666  vmovaps [rsp], xmm0
00007e1ec07da66b  vmovaps [rsp+0x10], xmm1
00007e1ec07da671  vmovaps [rsp+0x20], xmm2
00007e1ec07da677  vmovaps [rsp+0x30], xmm3
00007e1ec07da67d  vmovaps [rsp+0x40], xmm4
00007e1ec07da683  vmovaps [rsp+0x50], xmm5
00007e1ec07da689  vmovaps [rsp+0x60], xmm6
00007e1ec07da68f  vmovaps [rsp+0x70], xmm7
00007e1ec07da695  vmovaps [rsp+0x80], xmm8
00007e1ec07da69e  vmovaps [rsp+0x90], xmm9
00007e1ec07da6a7  vmovaps [rsp+0xA0], xmm10
00007e1ec07da6b0  vmovaps [rsp+0xB0], xmm11
00007e1ec07da6b9  vmovaps [rsp+0xC0], xmm12
00007e1ec07da6c2  vmovaps [rsp+0xD0], xmm13
00007e1ec07da6cb  vmovaps [rsp+0xE0], xmm15
00007e1ec07da6d4  sub rsp, 0x30
00007e1ec07da6d8  movaps [rsp], xmm14
00007e1ec07da6dd  movaps [rsp+0x10], xmm4
00007e1ec07da6e2  movaps [rsp+0x20], xmm3
00007e1ec07da6e7  lea rdi, [rsp]
00007e1ec07da6eb  mov esi, 0x00
00007e1ec07da6f0  mov rax, 0x5E00FF778530
00007e1ec07da6fa  call rax
00007e1ec07da6fc  movaps xmm14, [rsp]
00007e1ec07da701  add rsp, 0x30
00007e1ec07da705  vmovaps xmm0, [rsp]
00007e1ec07da70a  vmovaps xmm1, [rsp+0x10]
00007e1ec07da710  vmovaps xmm2, [rsp+0x20]
00007e1ec07da716  vmovaps xmm3, [rsp+0x30]
00007e1ec07da71c  vmovaps xmm4, [rsp+0x40]
00007e1ec07da722  vmovaps xmm5, [rsp+0x50]
00007e1ec07da728  vmovaps xmm6, [rsp+0x60]
00007e1ec07da72e  vmovaps xmm7, [rsp+0x70]
00007e1ec07da734  vmovaps xmm8, [rsp+0x80]
00007e1ec07da73d  vmovaps xmm9, [rsp+0x90]
00007e1ec07da746  vmovaps xmm10, [rsp+0xA0]
00007e1ec07da74f  vmovaps xmm11, [rsp+0xB0]
00007e1ec07da758  vmovaps xmm12, [rsp+0xC0]
00007e1ec07da761  vmovaps xmm13, [rsp+0xD0]
00007e1ec07da76a  vmovaps xmm15, [rsp+0xE0]
00007e1ec07da773  add rsp, 0xF0
00007e1ec07da77a  pop r11
00007e1ec07da77c  pop r10
00007e1ec07da77e  pop r9
00007e1ec07da780  pop r8
00007e1ec07da782  pop rsi
00007e1ec07da783  pop rdi
00007e1ec07da784  pop rdx
00007e1ec07da785  pop rcx
00007e1ec07da786  pop rax
00007e1ec07da787  add rsp, 0x08
00007e1ec07da78b  jmp 0x00007E1EC07D8E6F
00007e1ec07da790  sub rsp, 0x08
00007e1ec07da794  push rax
00007e1ec07da795  push rcx
00007e1ec07da796  push rdx
00007e1ec07da797  push rdi
00007e1ec07da798  push rsi
00007e1ec07da799  push r8
00007e1ec07da79b  push r9
00007e1ec07da79d  push r10
00007e1ec07da79f  push r11
00007e1ec07da7a1  sub rsp, 0xF0
00007e1ec07da7a8  vmovaps [rsp], xmm0
00007e1ec07da7ad  vmovaps [rsp+0x10], xmm1
00007e1ec07da7b3  vmovaps [rsp+0x20], xmm2
00007e1ec07da7b9  vmovaps [rsp+0x30], xmm3
00007e1ec07da7bf  vmovaps [rsp+0x40], xmm4
00007e1ec07da7c5  vmovaps [rsp+0x50], xmm5
00007e1ec07da7cb  vmovaps [rsp+0x60], xmm7
00007e1ec07da7d1  vmovaps [rsp+0x70], xmm8
00007e1ec07da7d7  vmovaps [rsp+0x80], xmm9
00007e1ec07da7e0  vmovaps [rsp+0x90], xmm10
00007e1ec07da7e9  vmovaps [rsp+0xA0], xmm11
00007e1ec07da7f2  vmovaps [rsp+0xB0], xmm12
00007e1ec07da7fb  vmovaps [rsp+0xC0], xmm13
00007e1ec07da804  vmovaps [rsp+0xD0], xmm14
00007e1ec07da80d  vmovaps [rsp+0xE0], xmm15
00007e1ec07da816  sub rsp, 0x30
00007e1ec07da81a  movaps [rsp], xmm6
00007e1ec07da81e  movaps [rsp+0x10], xmm9
00007e1ec07da824  movaps [rsp+0x20], xmm7
00007e1ec07da829  lea rdi, [rsp]
00007e1ec07da82d  mov esi, 0x00
00007e1ec07da832  mov rax, 0x5E00FF778530
00007e1ec07da83c  call rax
00007e1ec07da83e  movaps xmm6, [rsp]
00007e1ec07da842  add rsp, 0x30
00007e1ec07da846  vmovaps xmm0, [rsp]
00007e1ec07da84b  vmovaps xmm1, [rsp+0x10]
00007e1ec07da851  vmovaps xmm2, [rsp+0x20]
00007e1ec07da857  vmovaps xmm3, [rsp+0x30]
00007e1ec07da85d  vmovaps xmm4, [rsp+0x40]
00007e1ec07da863  vmovaps xmm5, [rsp+0x50]
00007e1ec07da869  vmovaps xmm7, [rsp+0x60]
00007e1ec07da86f  vmovaps xmm8, [rsp+0x70]
00007e1ec07da875  vmovaps xmm9, [rsp+0x80]
00007e1ec07da87e  vmovaps xmm10, [rsp+0x90]
00007e1ec07da887  vmovaps xmm11, [rsp+0xA0]
00007e1ec07da890  vmovaps xmm12, [rsp+0xB0]
00007e1ec07da899  vmovaps xmm13, [rsp+0xC0]
00007e1ec07da8a2  vmovaps xmm14, [rsp+0xD0]
00007e1ec07da8ab  vmovaps xmm15, [rsp+0xE0]
00007e1ec07da8b4  add rsp, 0xF0
00007e1ec07da8bb  pop r11
00007e1ec07da8bd  pop r10
00007e1ec07da8bf  pop r9
00007e1ec07da8c1  pop r8
00007e1ec07da8c3  pop rsi
00007e1ec07da8c4  pop rdi
00007e1ec07da8c5  pop rdx
00007e1ec07da8c6  pop rcx
00007e1ec07da8c7  pop rax
00007e1ec07da8c8  add rsp, 0x08
00007e1ec07da8cc  jmp 0x00007E1EC07D8E87
00007e1ec07da8d1  sub rsp, 0x08
00007e1ec07da8d5  push rax
00007e1ec07da8d6  push rcx
00007e1ec07da8d7  push rdx
00007e1ec07da8d8  push rdi
00007e1ec07da8d9  push rsi
00007e1ec07da8da  push r8
00007e1ec07da8dc  push r9
00007e1ec07da8de  push r10
00007e1ec07da8e0  push r11
00007e1ec07da8e2  sub rsp, 0xF0
00007e1ec07da8e9  vmovaps [rsp], xmm0
00007e1ec07da8ee  vmovaps [rsp+0x10], xmm1
00007e1ec07da8f4  vmovaps [rsp+0x20], xmm2
00007e1ec07da8fa  vmovaps [rsp+0x30], xmm3
00007e1ec07da900  vmovaps [rsp+0x40], xmm4
00007e1ec07da906  vmovaps [rsp+0x50], xmm5
00007e1ec07da90c  vmovaps [rsp+0x60], xmm6
00007e1ec07da912  vmovaps [rsp+0x70], xmm8
00007e1ec07da918  vmovaps [rsp+0x80], xmm9
00007e1ec07da921  vmovaps [rsp+0x90], xmm10
00007e1ec07da92a  vmovaps [rsp+0xA0], xmm11
00007e1ec07da933  vmovaps [rsp+0xB0], xmm12
00007e1ec07da93c  vmovaps [rsp+0xC0], xmm13
00007e1ec07da945  vmovaps [rsp+0xD0], xmm14
00007e1ec07da94e  vmovaps [rsp+0xE0], xmm15
00007e1ec07da957  sub rsp, 0x30
00007e1ec07da95b  movaps [rsp], xmm7
00007e1ec07da95f  movaps [rsp+0x10], xmm4
00007e1ec07da964  movaps [rsp+0x20], xmm9
00007e1ec07da96a  lea rdi, [rsp]
00007e1ec07da96e  mov esi, 0x00
00007e1ec07da973  mov rax, 0x5E00FF778530
00007e1ec07da97d  call rax
00007e1ec07da97f  movaps xmm7, [rsp]
00007e1ec07da983  add rsp, 0x30
00007e1ec07da987  vmovaps xmm0, [rsp]
00007e1ec07da98c  vmovaps xmm1, [rsp+0x10]
00007e1ec07da992  vmovaps xmm2, [rsp+0x20]
00007e1ec07da998  vmovaps xmm3, [rsp+0x30]
00007e1ec07da99e  vmovaps xmm4, [rsp+0x40]
00007e1ec07da9a4  vmovaps xmm5, [rsp+0x50]
00007e1ec07da9aa  vmovaps xmm6, [rsp+0x60]
00007e1ec07da9b0  vmovaps xmm8, [rsp+0x70]
00007e1ec07da9b6  vmovaps xmm9, [rsp+0x80]
00007e1ec07da9bf  vmovaps xmm10, [rsp+0x90]
00007e1ec07da9c8  vmovaps xmm11, [rsp+0xA0]
00007e1ec07da9d1  vmovaps xmm12, [rsp+0xB0]
00007e1ec07da9da  vmovaps xmm13, [rsp+0xC0]
00007e1ec07da9e3  vmovaps xmm14, [rsp+0xD0]
00007e1ec07da9ec  vmovaps xmm15, [rsp+0xE0]
00007e1ec07da9f5  add rsp, 0xF0
00007e1ec07da9fc  pop r11
00007e1ec07da9fe  pop r10
00007e1ec07daa00  pop r9
00007e1ec07daa02  pop r8
00007e1ec07daa04  pop rsi
00007e1ec07daa05  pop rdi
00007e1ec07daa06  pop rdx
00007e1ec07daa07  pop rcx
00007e1ec07daa08  pop rax
00007e1ec07daa09  add rsp, 0x08
00007e1ec07daa0d  jmp 0x00007E1EC07D8EB4
00007e1ec07daa12  sub rsp, 0x08
00007e1ec07daa16  push rax
00007e1ec07daa17  push rcx
00007e1ec07daa18  push rdx
00007e1ec07daa19  push rdi
00007e1ec07daa1a  push rsi
00007e1ec07daa1b  push r8
00007e1ec07daa1d  push r9
00007e1ec07daa1f  push r10
00007e1ec07daa21  push r11
00007e1ec07daa23  sub rsp, 0xF0
00007e1ec07daa2a  vmovaps [rsp], xmm0
00007e1ec07daa2f  vmovaps [rsp+0x10], xmm1
00007e1ec07daa35  vmovaps [rsp+0x20], xmm2
00007e1ec07daa3b  vmovaps [rsp+0x30], xmm3
00007e1ec07daa41  vmovaps [rsp+0x40], xmm5
00007e1ec07daa47  vmovaps [rsp+0x50], xmm6
00007e1ec07daa4d  vmovaps [rsp+0x60], xmm7
00007e1ec07daa53  vmovaps [rsp+0x70], xmm8
00007e1ec07daa59  vmovaps [rsp+0x80], xmm9
00007e1ec07daa62  vmovaps [rsp+0x90], xmm10
00007e1ec07daa6b  vmovaps [rsp+0xA0], xmm11
00007e1ec07daa74  vmovaps [rsp+0xB0], xmm12
00007e1ec07daa7d  vmovaps [rsp+0xC0], xmm13
00007e1ec07daa86  vmovaps [rsp+0xD0], xmm14
00007e1ec07daa8f  vmovaps [rsp+0xE0], xmm15
00007e1ec07daa98  sub rsp, 0x30
00007e1ec07daa9c  movaps [rsp], xmm4
00007e1ec07daaa0  movaps [rsp+0x10], xmm15
00007e1ec07daaa6  movaps [rsp+0x20], xmm9
00007e1ec07daaac  lea rdi, [rsp]
00007e1ec07daab0  mov esi, 0x00
00007e1ec07daab5  mov rax, 0x5E00FF778530
00007e1ec07daabf  call rax
00007e1ec07daac1  movaps xmm4, [rsp]
00007e1ec07daac5  add rsp, 0x30
00007e1ec07daac9  vmovaps xmm0, [rsp]
00007e1ec07daace  vmovaps xmm1, [rsp+0x10]
00007e1ec07daad4  vmovaps xmm2, [rsp+0x20]
00007e1ec07daada  vmovaps xmm3, [rsp+0x30]
00007e1ec07daae0  vmovaps xmm5, [rsp+0x40]
00007e1ec07daae6  vmovaps xmm6, [rsp+0x50]
00007e1ec07daaec  vmovaps xmm7, [rsp+0x60]
00007e1ec07daaf2  vmovaps xmm8, [rsp+0x70]
00007e1ec07daaf8  vmovaps xmm9, [rsp+0x80]
00007e1ec07dab01  vmovaps xmm10, [rsp+0x90]
00007e1ec07dab0a  vmovaps xmm11, [rsp+0xA0]
00007e1ec07dab13  vmovaps xmm12, [rsp+0xB0]
00007e1ec07dab1c  vmovaps xmm13, [rsp+0xC0]
00007e1ec07dab25  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dab2e  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dab37  add rsp, 0xF0
00007e1ec07dab3e  pop r11
00007e1ec07dab40  pop r10
00007e1ec07dab42  pop r9
00007e1ec07dab44  pop r8
00007e1ec07dab46  pop rsi
00007e1ec07dab47  pop rdi
00007e1ec07dab48  pop rdx
00007e1ec07dab49  pop rcx
00007e1ec07dab4a  pop rax
00007e1ec07dab4b  add rsp, 0x08
00007e1ec07dab4f  jmp 0x00007E1EC07D8ED9
00007e1ec07dab54  call 0x00007E1EC06E5820
00007e1ec07dab59  jmp 0x00007E1EC07D8EE6
00007e1ec07dab5e  sub rsp, 0x08
00007e1ec07dab62  push rax
00007e1ec07dab63  push rcx
00007e1ec07dab64  push rdx
00007e1ec07dab65  push rdi
00007e1ec07dab66  push rsi
00007e1ec07dab67  push r8
00007e1ec07dab69  push r9
00007e1ec07dab6b  push r10
00007e1ec07dab6d  push r11
00007e1ec07dab6f  sub rsp, 0xF0
00007e1ec07dab76  vmovaps [rsp], xmm0
00007e1ec07dab7b  vmovaps [rsp+0x10], xmm1
00007e1ec07dab81  vmovaps [rsp+0x20], xmm2
00007e1ec07dab87  vmovaps [rsp+0x30], xmm4
00007e1ec07dab8d  vmovaps [rsp+0x40], xmm5
00007e1ec07dab93  vmovaps [rsp+0x50], xmm6
00007e1ec07dab99  vmovaps [rsp+0x60], xmm7
00007e1ec07dab9f  vmovaps [rsp+0x70], xmm8
00007e1ec07daba5  vmovaps [rsp+0x80], xmm9
00007e1ec07dabae  vmovaps [rsp+0x90], xmm10
00007e1ec07dabb7  vmovaps [rsp+0xA0], xmm11
00007e1ec07dabc0  vmovaps [rsp+0xB0], xmm12
00007e1ec07dabc9  vmovaps [rsp+0xC0], xmm13
00007e1ec07dabd2  vmovaps [rsp+0xD0], xmm14
00007e1ec07dabdb  vmovaps [rsp+0xE0], xmm15
00007e1ec07dabe4  sub rsp, 0x30
00007e1ec07dabe8  movaps [rsp], xmm3
00007e1ec07dabec  movaps [rsp+0x10], xmm1
00007e1ec07dabf1  movaps [rsp+0x20], xmm9
00007e1ec07dabf7  lea rdi, [rsp]
00007e1ec07dabfb  mov esi, 0x00
00007e1ec07dac00  mov rax, 0x5E00FF778530
00007e1ec07dac0a  call rax
00007e1ec07dac0c  movaps xmm3, [rsp]
00007e1ec07dac10  add rsp, 0x30
00007e1ec07dac14  vmovaps xmm0, [rsp]
00007e1ec07dac19  vmovaps xmm1, [rsp+0x10]
00007e1ec07dac1f  vmovaps xmm2, [rsp+0x20]
00007e1ec07dac25  vmovaps xmm4, [rsp+0x30]
00007e1ec07dac2b  vmovaps xmm5, [rsp+0x40]
00007e1ec07dac31  vmovaps xmm6, [rsp+0x50]
00007e1ec07dac37  vmovaps xmm7, [rsp+0x60]
00007e1ec07dac3d  vmovaps xmm8, [rsp+0x70]
00007e1ec07dac43  vmovaps xmm9, [rsp+0x80]
00007e1ec07dac4c  vmovaps xmm10, [rsp+0x90]
00007e1ec07dac55  vmovaps xmm11, [rsp+0xA0]
00007e1ec07dac5e  vmovaps xmm12, [rsp+0xB0]
00007e1ec07dac67  vmovaps xmm13, [rsp+0xC0]
00007e1ec07dac70  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dac79  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dac82  add rsp, 0xF0
00007e1ec07dac89  pop r11
00007e1ec07dac8b  pop r10
00007e1ec07dac8d  pop r9
00007e1ec07dac8f  pop r8
00007e1ec07dac91  pop rsi
00007e1ec07dac92  pop rdi
00007e1ec07dac93  pop rdx
00007e1ec07dac94  pop rcx
00007e1ec07dac95  pop rax
00007e1ec07dac96  add rsp, 0x08
00007e1ec07dac9a  jmp 0x00007E1EC07D8F23
00007e1ec07dac9f  sub rsp, 0x08
00007e1ec07daca3  push rax
00007e1ec07daca4  push rcx
00007e1ec07daca5  push rdx
00007e1ec07daca6  push rdi
00007e1ec07daca7  push rsi
00007e1ec07daca8  push r8
00007e1ec07dacaa  push r9
00007e1ec07dacac  push r10
00007e1ec07dacae  push r11
00007e1ec07dacb0  sub rsp, 0xF0
00007e1ec07dacb7  vmovaps [rsp], xmm0
00007e1ec07dacbc  vmovaps [rsp+0x10], xmm2
00007e1ec07dacc2  vmovaps [rsp+0x20], xmm3
00007e1ec07dacc8  vmovaps [rsp+0x30], xmm4
00007e1ec07dacce  vmovaps [rsp+0x40], xmm5
00007e1ec07dacd4  vmovaps [rsp+0x50], xmm6
00007e1ec07dacda  vmovaps [rsp+0x60], xmm7
00007e1ec07dace0  vmovaps [rsp+0x70], xmm8
00007e1ec07dace6  vmovaps [rsp+0x80], xmm9
00007e1ec07dacef  vmovaps [rsp+0x90], xmm10
00007e1ec07dacf8  vmovaps [rsp+0xA0], xmm11
00007e1ec07dad01  vmovaps [rsp+0xB0], xmm12
00007e1ec07dad0a  vmovaps [rsp+0xC0], xmm13
00007e1ec07dad13  vmovaps [rsp+0xD0], xmm14
00007e1ec07dad1c  vmovaps [rsp+0xE0], xmm15
00007e1ec07dad25  sub rsp, 0x30
00007e1ec07dad29  movaps [rsp], xmm1
00007e1ec07dad2d  movaps [rsp+0x10], xmm15
00007e1ec07dad33  movaps [rsp+0x20], xmm9
00007e1ec07dad39  lea rdi, [rsp]
00007e1ec07dad3d  mov esi, 0x00
00007e1ec07dad42  mov rax, 0x5E00FF778530
00007e1ec07dad4c  call rax
00007e1ec07dad4e  movaps xmm1, [rsp]
00007e1ec07dad52  add rsp, 0x30
00007e1ec07dad56  vmovaps xmm0, [rsp]
00007e1ec07dad5b  vmovaps xmm2, [rsp+0x10]
00007e1ec07dad61  vmovaps xmm3, [rsp+0x20]
00007e1ec07dad67  vmovaps xmm4, [rsp+0x30]
00007e1ec07dad6d  vmovaps xmm5, [rsp+0x40]
00007e1ec07dad73  vmovaps xmm6, [rsp+0x50]
00007e1ec07dad79  vmovaps xmm7, [rsp+0x60]
00007e1ec07dad7f  vmovaps xmm8, [rsp+0x70]
00007e1ec07dad85  vmovaps xmm9, [rsp+0x80]
00007e1ec07dad8e  vmovaps xmm10, [rsp+0x90]
00007e1ec07dad97  vmovaps xmm11, [rsp+0xA0]
00007e1ec07dada0  vmovaps xmm12, [rsp+0xB0]
00007e1ec07dada9  vmovaps xmm13, [rsp+0xC0]
00007e1ec07dadb2  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dadbb  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dadc4  add rsp, 0xF0
00007e1ec07dadcb  pop r11
00007e1ec07dadcd  pop r10
00007e1ec07dadcf  pop r9
00007e1ec07dadd1  pop r8
00007e1ec07dadd3  pop rsi
00007e1ec07dadd4  pop rdi
00007e1ec07dadd5  pop rdx
00007e1ec07dadd6  pop rcx
00007e1ec07dadd7  pop rax
00007e1ec07dadd8  add rsp, 0x08
00007e1ec07daddc  jmp 0x00007E1EC07D8FAB
00007e1ec07dade1  call 0x00007E1EC06E5820
00007e1ec07dade6  jmp 0x00007E1EC07D8FB8
00007e1ec07dadeb  sub rsp, 0x08
00007e1ec07dadef  push rax
00007e1ec07dadf0  push rcx
00007e1ec07dadf1  push rdx
00007e1ec07dadf2  push rdi
00007e1ec07dadf3  push rsi
00007e1ec07dadf4  push r8
00007e1ec07dadf6  push r9
00007e1ec07dadf8  push r10
00007e1ec07dadfa  push r11
00007e1ec07dadfc  sub rsp, 0xF0
00007e1ec07dae03  vmovaps [rsp], xmm0
00007e1ec07dae08  vmovaps [rsp+0x10], xmm2
00007e1ec07dae0e  vmovaps [rsp+0x20], xmm3
00007e1ec07dae14  vmovaps [rsp+0x30], xmm4
00007e1ec07dae1a  vmovaps [rsp+0x40], xmm5
00007e1ec07dae20  vmovaps [rsp+0x50], xmm6
00007e1ec07dae26  vmovaps [rsp+0x60], xmm7
00007e1ec07dae2c  vmovaps [rsp+0x70], xmm8
00007e1ec07dae32  vmovaps [rsp+0x80], xmm9
00007e1ec07dae3b  vmovaps [rsp+0x90], xmm10
00007e1ec07dae44  vmovaps [rsp+0xA0], xmm11
00007e1ec07dae4d  vmovaps [rsp+0xB0], xmm12
00007e1ec07dae56  vmovaps [rsp+0xC0], xmm13
00007e1ec07dae5f  vmovaps [rsp+0xD0], xmm14
00007e1ec07dae68  vmovaps [rsp+0xE0], xmm15
00007e1ec07dae71  sub rsp, 0x30
00007e1ec07dae75  movaps [rsp], xmm1
00007e1ec07dae79  movaps [rsp+0x10], xmm5
00007e1ec07dae7e  movaps [rsp+0x20], xmm7
00007e1ec07dae83  lea rdi, [rsp]
00007e1ec07dae87  mov esi, 0x00
00007e1ec07dae8c  mov rax, 0x5E00FF778530
00007e1ec07dae96  call rax
00007e1ec07dae98  movaps xmm1, [rsp]
00007e1ec07dae9c  add rsp, 0x30
00007e1ec07daea0  vmovaps xmm0, [rsp]
00007e1ec07daea5  vmovaps xmm2, [rsp+0x10]
00007e1ec07daeab  vmovaps xmm3, [rsp+0x20]
00007e1ec07daeb1  vmovaps xmm4, [rsp+0x30]
00007e1ec07daeb7  vmovaps xmm5, [rsp+0x40]
00007e1ec07daebd  vmovaps xmm6, [rsp+0x50]
00007e1ec07daec3  vmovaps xmm7, [rsp+0x60]
00007e1ec07daec9  vmovaps xmm8, [rsp+0x70]
00007e1ec07daecf  vmovaps xmm9, [rsp+0x80]
00007e1ec07daed8  vmovaps xmm10, [rsp+0x90]
00007e1ec07daee1  vmovaps xmm11, [rsp+0xA0]
00007e1ec07daeea  vmovaps xmm12, [rsp+0xB0]
00007e1ec07daef3  vmovaps xmm13, [rsp+0xC0]
00007e1ec07daefc  vmovaps xmm14, [rsp+0xD0]
00007e1ec07daf05  vmovaps xmm15, [rsp+0xE0]
00007e1ec07daf0e  add rsp, 0xF0
00007e1ec07daf15  pop r11
00007e1ec07daf17  pop r10
00007e1ec07daf19  pop r9
00007e1ec07daf1b  pop r8
00007e1ec07daf1d  pop rsi
00007e1ec07daf1e  pop rdi
00007e1ec07daf1f  pop rdx
00007e1ec07daf20  pop rcx
00007e1ec07daf21  pop rax
00007e1ec07daf22  add rsp, 0x08
00007e1ec07daf26  jmp 0x00007E1EC07D905D
00007e1ec07daf2b  sub rsp, 0x08
00007e1ec07daf2f  push rax
00007e1ec07daf30  push rcx
00007e1ec07daf31  push rdx
00007e1ec07daf32  push rdi
00007e1ec07daf33  push rsi
00007e1ec07daf34  push r8
00007e1ec07daf36  push r9
00007e1ec07daf38  push r10
00007e1ec07daf3a  push r11
00007e1ec07daf3c  sub rsp, 0xF0
00007e1ec07daf43  vmovaps [rsp], xmm0
00007e1ec07daf48  vmovaps [rsp+0x10], xmm1
00007e1ec07daf4e  vmovaps [rsp+0x20], xmm2
00007e1ec07daf54  vmovaps [rsp+0x30], xmm3
00007e1ec07daf5a  vmovaps [rsp+0x40], xmm4
00007e1ec07daf60  vmovaps [rsp+0x50], xmm5
00007e1ec07daf66  vmovaps [rsp+0x60], xmm6
00007e1ec07daf6c  vmovaps [rsp+0x70], xmm8
00007e1ec07daf72  vmovaps [rsp+0x80], xmm9
00007e1ec07daf7b  vmovaps [rsp+0x90], xmm10
00007e1ec07daf84  vmovaps [rsp+0xA0], xmm11
00007e1ec07daf8d  vmovaps [rsp+0xB0], xmm12
00007e1ec07daf96  vmovaps [rsp+0xC0], xmm13
00007e1ec07daf9f  vmovaps [rsp+0xD0], xmm14
00007e1ec07dafa8  vmovaps [rsp+0xE0], xmm15
00007e1ec07dafb1  sub rsp, 0x30
00007e1ec07dafb5  movaps [rsp], xmm7
00007e1ec07dafb9  movaps [rsp+0x10], xmm5
00007e1ec07dafbe  movaps [rsp+0x20], xmm15
00007e1ec07dafc4  lea rdi, [rsp]
00007e1ec07dafc8  mov esi, 0x00
00007e1ec07dafcd  mov rax, 0x5E00FF778530
00007e1ec07dafd7  call rax
00007e1ec07dafd9  movaps xmm7, [rsp]
00007e1ec07dafdd  add rsp, 0x30
00007e1ec07dafe1  vmovaps xmm0, [rsp]
00007e1ec07dafe6  vmovaps xmm1, [rsp+0x10]
00007e1ec07dafec  vmovaps xmm2, [rsp+0x20]
00007e1ec07daff2  vmovaps xmm3, [rsp+0x30]
00007e1ec07daff8  vmovaps xmm4, [rsp+0x40]
00007e1ec07daffe  vmovaps xmm5, [rsp+0x50]
00007e1ec07db004  vmovaps xmm6, [rsp+0x60]
00007e1ec07db00a  vmovaps xmm8, [rsp+0x70]
00007e1ec07db010  vmovaps xmm9, [rsp+0x80]
00007e1ec07db019  vmovaps xmm10, [rsp+0x90]
00007e1ec07db022  vmovaps xmm11, [rsp+0xA0]
00007e1ec07db02b  vmovaps xmm12, [rsp+0xB0]
00007e1ec07db034  vmovaps xmm13, [rsp+0xC0]
00007e1ec07db03d  vmovaps xmm14, [rsp+0xD0]
00007e1ec07db046  vmovaps xmm15, [rsp+0xE0]
00007e1ec07db04f  add rsp, 0xF0
00007e1ec07db056  pop r11
00007e1ec07db058  pop r10
00007e1ec07db05a  pop r9
00007e1ec07db05c  pop r8
00007e1ec07db05e  pop rsi
00007e1ec07db05f  pop rdi
00007e1ec07db060  pop rdx
00007e1ec07db061  pop rcx
00007e1ec07db062  pop rax
00007e1ec07db063  add rsp, 0x08
00007e1ec07db067  jmp 0x00007E1EC07D9093
00007e1ec07db06c  call 0x00007E1EC06D64F0
00007e1ec07db071  jmp 0x00007E1EC07D90A0
00007e1ec07db076  sub rsp, 0x08
00007e1ec07db07a  push rax
00007e1ec07db07b  push rcx
00007e1ec07db07c  push rdx
00007e1ec07db07d  push rdi
00007e1ec07db07e  push rsi
00007e1ec07db07f  push r8
00007e1ec07db081  push r9
00007e1ec07db083  push r10
00007e1ec07db085  push r11
00007e1ec07db087  sub rsp, 0xF0
00007e1ec07db08e  vmovaps [rsp], xmm0
00007e1ec07db093  vmovaps [rsp+0x10], xmm1
00007e1ec07db099  vmovaps [rsp+0x20], xmm2
00007e1ec07db09f  vmovaps [rsp+0x30], xmm3
00007e1ec07db0a5  vmovaps [rsp+0x40], xmm4
00007e1ec07db0ab  vmovaps [rsp+0x50], xmm5
00007e1ec07db0b1  vmovaps [rsp+0x60], xmm6
00007e1ec07db0b7  vmovaps [rsp+0x70], xmm7
00007e1ec07db0bd  vmovaps [rsp+0x80], xmm8
00007e1ec07db0c6  vmovaps [rsp+0x90], xmm9
00007e1ec07db0cf  vmovaps [rsp+0xA0], xmm10
00007e1ec07db0d8  vmovaps [rsp+0xB0], xmm11
00007e1ec07db0e1  vmovaps [rsp+0xC0], xmm12
00007e1ec07db0ea  vmovaps [rsp+0xD0], xmm13
00007e1ec07db0f3  vmovaps [rsp+0xE0], xmm14
00007e1ec07db0fc  sub rsp, 0x30
00007e1ec07db100  movaps [rsp], xmm15
00007e1ec07db105  movaps [rsp+0x10], xmm5
00007e1ec07db10a  movaps [rsp+0x20], xmm3
00007e1ec07db10f  lea rdi, [rsp]
00007e1ec07db113  mov esi, 0x00
00007e1ec07db118  mov rax, 0x5E00FF778530
00007e1ec07db122  call rax
00007e1ec07db124  movaps xmm15, [rsp]
00007e1ec07db129  add rsp, 0x30
00007e1ec07db12d  vmovaps xmm0, [rsp]
00007e1ec07db132  vmovaps xmm1, [rsp+0x10]
00007e1ec07db138  vmovaps xmm2, [rsp+0x20]
00007e1ec07db13e  vmovaps xmm3, [rsp+0x30]
00007e1ec07db144  vmovaps xmm4, [rsp+0x40]
00007e1ec07db14a  vmovaps xmm5, [rsp+0x50]
00007e1ec07db150  vmovaps xmm6, [rsp+0x60]
00007e1ec07db156  vmovaps xmm7, [rsp+0x70]
00007e1ec07db15c  vmovaps xmm8, [rsp+0x80]
00007e1ec07db165  vmovaps xmm9, [rsp+0x90]
00007e1ec07db16e  vmovaps xmm10, [rsp+0xA0]
00007e1ec07db177  vmovaps xmm11, [rsp+0xB0]
00007e1ec07db180  vmovaps xmm12, [rsp+0xC0]
00007e1ec07db189  vmovaps xmm13, [rsp+0xD0]
00007e1ec07db192  vmovaps xmm14, [rsp+0xE0]
00007e1ec07db19b  add rsp, 0xF0
00007e1ec07db1a2  pop r11
00007e1ec07db1a4  pop r10
00007e1ec07db1a6  pop r9
00007e1ec07db1a8  pop r8
00007e1ec07db1aa  pop rsi
00007e1ec07db1ab  pop rdi
00007e1ec07db1ac  pop rdx
00007e1ec07db1ad  pop rcx
00007e1ec07db1ae  pop rax
00007e1ec07db1af  add rsp, 0x08
00007e1ec07db1b3  jmp 0x00007E1EC07D90C6
00007e1ec07db1b8  sub rsp, 0x08
00007e1ec07db1bc  push rax
00007e1ec07db1bd  push rcx
00007e1ec07db1be  push rdx
00007e1ec07db1bf  push rdi
00007e1ec07db1c0  push rsi
00007e1ec07db1c1  push r8
00007e1ec07db1c3  push r9
00007e1ec07db1c5  push r10
00007e1ec07db1c7  push r11
00007e1ec07db1c9  sub rsp, 0xF0
00007e1ec07db1d0  vmovaps [rsp], xmm0
00007e1ec07db1d5  vmovaps [rsp+0x10], xmm2
00007e1ec07db1db  vmovaps [rsp+0x20], xmm3
00007e1ec07db1e1  vmovaps [rsp+0x30], xmm4
00007e1ec07db1e7  vmovaps [rsp+0x40], xmm5
00007e1ec07db1ed  vmovaps [rsp+0x50], xmm6
00007e1ec07db1f3  vmovaps [rsp+0x60], xmm7
00007e1ec07db1f9  vmovaps [rsp+0x70], xmm8
00007e1ec07db1ff  vmovaps [rsp+0x80], xmm9
00007e1ec07db208  vmovaps [rsp+0x90], xmm10
00007e1ec07db211  vmovaps [rsp+0xA0], xmm11
00007e1ec07db21a  vmovaps [rsp+0xB0], xmm12
00007e1ec07db223  vmovaps [rsp+0xC0], xmm13
00007e1ec07db22c  vmovaps [rsp+0xD0], xmm14
00007e1ec07db235  vmovaps [rsp+0xE0], xmm15
00007e1ec07db23e  sub rsp, 0x30
00007e1ec07db242  movaps [rsp], xmm1
00007e1ec07db246  movaps [rsp+0x10], xmm5
00007e1ec07db24b  movaps [rsp+0x20], xmm4
00007e1ec07db250  lea rdi, [rsp]
00007e1ec07db254  mov esi, 0x00
00007e1ec07db259  mov rax, 0x5E00FF778530
00007e1ec07db263  call rax
00007e1ec07db265  movaps xmm1, [rsp]
00007e1ec07db269  add rsp, 0x30
00007e1ec07db26d  vmovaps xmm0, [rsp]
00007e1ec07db272  vmovaps xmm2, [rsp+0x10]
00007e1ec07db278  vmovaps xmm3, [rsp+0x20]
00007e1ec07db27e  vmovaps xmm4, [rsp+0x30]
00007e1ec07db284  vmovaps xmm5, [rsp+0x40]
00007e1ec07db28a  vmovaps xmm6, [rsp+0x50]
00007e1ec07db290  vmovaps xmm7, [rsp+0x60]
00007e1ec07db296  vmovaps xmm8, [rsp+0x70]
00007e1ec07db29c  vmovaps xmm9, [rsp+0x80]
00007e1ec07db2a5  vmovaps xmm10, [rsp+0x90]
00007e1ec07db2ae  vmovaps xmm11, [rsp+0xA0]
00007e1ec07db2b7  vmovaps xmm12, [rsp+0xB0]
00007e1ec07db2c0  vmovaps xmm13, [rsp+0xC0]
00007e1ec07db2c9  vmovaps xmm14, [rsp+0xD0]
00007e1ec07db2d2  vmovaps xmm15, [rsp+0xE0]
00007e1ec07db2db  add rsp, 0xF0
00007e1ec07db2e2  pop r11
00007e1ec07db2e4  pop r10
00007e1ec07db2e6  pop r9
00007e1ec07db2e8  pop r8
00007e1ec07db2ea  pop rsi
00007e1ec07db2eb  pop rdi
00007e1ec07db2ec  pop rdx
00007e1ec07db2ed  pop rcx
00007e1ec07db2ee  pop rax
00007e1ec07db2ef  add rsp, 0x08
00007e1ec07db2f3  jmp 0x00007E1EC07D90E6
00007e1ec07db2f8  sub rsp, 0x08
00007e1ec07db2fc  push rax
00007e1ec07db2fd  push rcx
00007e1ec07db2fe  push rdx
00007e1ec07db2ff  push rdi
00007e1ec07db300  push rsi
00007e1ec07db301  push r8
00007e1ec07db303  push r9
00007e1ec07db305  push r10
00007e1ec07db307  push r11
00007e1ec07db309  sub rsp, 0xF0
00007e1ec07db310  vmovaps [rsp], xmm0
00007e1ec07db315  vmovaps [rsp+0x10], xmm1
00007e1ec07db31b  vmovaps [rsp+0x20], xmm2
00007e1ec07db321  vmovaps [rsp+0x30], xmm3
00007e1ec07db327  vmovaps [rsp+0x40], xmm5
00007e1ec07db32d  vmovaps [rsp+0x50], xmm6
00007e1ec07db333  vmovaps [rsp+0x60], xmm7
00007e1ec07db339  vmovaps [rsp+0x70], xmm8
00007e1ec07db33f  vmovaps [rsp+0x80], xmm9
00007e1ec07db348  vmovaps [rsp+0x90], xmm10
00007e1ec07db351  vmovaps [rsp+0xA0], xmm11
00007e1ec07db35a  vmovaps [rsp+0xB0], xmm12
00007e1ec07db363  vmovaps [rsp+0xC0], xmm13
00007e1ec07db36c  vmovaps [rsp+0xD0], xmm14
00007e1ec07db375  vmovaps [rsp+0xE0], xmm15
00007e1ec07db37e  sub rsp, 0x30
00007e1ec07db382  movaps [rsp], xmm4
00007e1ec07db386  movaps [rsp+0x10], xmm3
00007e1ec07db38b  movaps [rsp+0x20], xmm5
00007e1ec07db390  lea rdi, [rsp]
00007e1ec07db394  mov esi, 0x00
00007e1ec07db399  mov rax, 0x5E00FF778530
00007e1ec07db3a3  call rax
00007e1ec07db3a5  movaps xmm4, [rsp]
00007e1ec07db3a9  add rsp, 0x30
00007e1ec07db3ad  vmovaps xmm0, [rsp]
00007e1ec07db3b2  vmovaps xmm1, [rsp+0x10]
00007e1ec07db3b8  vmovaps xmm2, [rsp+0x20]
00007e1ec07db3be  vmovaps xmm3, [rsp+0x30]
00007e1ec07db3c4  vmovaps xmm5, [rsp+0x40]
00007e1ec07db3ca  vmovaps xmm6, [rsp+0x50]
00007e1ec07db3d0  vmovaps xmm7, [rsp+0x60]
00007e1ec07db3d6  vmovaps xmm8, [rsp+0x70]
00007e1ec07db3dc  vmovaps xmm9, [rsp+0x80]
00007e1ec07db3e5  vmovaps xmm10, [rsp+0x90]
00007e1ec07db3ee  vmovaps xmm11, [rsp+0xA0]
00007e1ec07db3f7  vmovaps xmm12, [rsp+0xB0]
00007e1ec07db400  vmovaps xmm13, [rsp+0xC0]
00007e1ec07db409  vmovaps xmm14, [rsp+0xD0]
00007e1ec07db412  vmovaps xmm15, [rsp+0xE0]
00007e1ec07db41b  add rsp, 0xF0
00007e1ec07db422  pop r11
00007e1ec07db424  pop r10
00007e1ec07db426  pop r9
00007e1ec07db428  pop r8
00007e1ec07db42a  pop rsi
00007e1ec07db42b  pop rdi
00007e1ec07db42c  pop rdx
00007e1ec07db42d  pop rcx
00007e1ec07db42e  pop rax
00007e1ec07db42f  add rsp, 0x08
00007e1ec07db433  jmp 0x00007E1EC07D9134
00007e1ec07db438  call 0x00007E1EC06D64F0
00007e1ec07db43d  jmp 0x00007E1EC07D9141
00007e1ec07db442  sub rsp, 0x08
00007e1ec07db446  push rax
00007e1ec07db447  push rcx
00007e1ec07db448  push rdx
00007e1ec07db449  push rdi
00007e1ec07db44a  push rsi
00007e1ec07db44b  push r8
00007e1ec07db44d  push r9
00007e1ec07db44f  push r10
00007e1ec07db451  push r11
00007e1ec07db453  sub rsp, 0xF0
00007e1ec07db45a  vmovaps [rsp], xmm0
00007e1ec07db45f  vmovaps [rsp+0x10], xmm1
00007e1ec07db465  vmovaps [rsp+0x20], xmm2
00007e1ec07db46b  vmovaps [rsp+0x30], xmm3
00007e1ec07db471  vmovaps [rsp+0x40], xmm4
00007e1ec07db477  vmovaps [rsp+0x50], xmm6
00007e1ec07db47d  vmovaps [rsp+0x60], xmm7
00007e1ec07db483  vmovaps [rsp+0x70], xmm8
00007e1ec07db489  vmovaps [rsp+0x80], xmm9
00007e1ec07db492  vmovaps [rsp+0x90], xmm10
00007e1ec07db49b  vmovaps [rsp+0xA0], xmm11
00007e1ec07db4a4  vmovaps [rsp+0xB0], xmm12
00007e1ec07db4ad  vmovaps [rsp+0xC0], xmm13
00007e1ec07db4b6  vmovaps [rsp+0xD0], xmm14
00007e1ec07db4bf  vmovaps [rsp+0xE0], xmm15
00007e1ec07db4c8  sub rsp, 0x30
00007e1ec07db4cc  movaps [rsp], xmm5
00007e1ec07db4d0  movaps [rsp+0x10], xmm6
00007e1ec07db4d5  movaps [rsp+0x20], xmm3
00007e1ec07db4da  lea rdi, [rsp]
00007e1ec07db4de  mov esi, 0x00
00007e1ec07db4e3  mov rax, 0x5E00FF778530
00007e1ec07db4ed  call rax
00007e1ec07db4ef  movaps xmm5, [rsp]
00007e1ec07db4f3  add rsp, 0x30
00007e1ec07db4f7  vmovaps xmm0, [rsp]
00007e1ec07db4fc  vmovaps xmm1, [rsp+0x10]
00007e1ec07db502  vmovaps xmm2, [rsp+0x20]
00007e1ec07db508  vmovaps xmm3, [rsp+0x30]
00007e1ec07db50e  vmovaps xmm4, [rsp+0x40]
00007e1ec07db514  vmovaps xmm6, [rsp+0x50]
00007e1ec07db51a  vmovaps xmm7, [rsp+0x60]
00007e1ec07db520  vmovaps xmm8, [rsp+0x70]
00007e1ec07db526  vmovaps xmm9, [rsp+0x80]
00007e1ec07db52f  vmovaps xmm10, [rsp+0x90]
00007e1ec07db538  vmovaps xmm11, [rsp+0xA0]
00007e1ec07db541  vmovaps xmm12, [rsp+0xB0]
00007e1ec07db54a  vmovaps xmm13, [rsp+0xC0]
00007e1ec07db553  vmovaps xmm14, [rsp+0xD0]
00007e1ec07db55c  vmovaps xmm15, [rsp+0xE0]
00007e1ec07db565  add rsp, 0xF0
00007e1ec07db56c  pop r11
00007e1ec07db56e  pop r10
00007e1ec07db570  pop r9
00007e1ec07db572  pop r8
00007e1ec07db574  pop rsi
00007e1ec07db575  pop rdi
00007e1ec07db576  pop rdx
00007e1ec07db577  pop rcx
00007e1ec07db578  pop rax
00007e1ec07db579  add rsp, 0x08
00007e1ec07db57d  jmp 0x00007E1EC07D9167
00007e1ec07db582  sub rsp, 0x08
00007e1ec07db586  push rax
00007e1ec07db587  push rcx
00007e1ec07db588  push rdx
00007e1ec07db589  push rdi
00007e1ec07db58a  push rsi
00007e1ec07db58b  push r8
00007e1ec07db58d  push r9
00007e1ec07db58f  push r10
00007e1ec07db591  push r11
00007e1ec07db593  sub rsp, 0xF0
00007e1ec07db59a  vmovaps [rsp], xmm0
00007e1ec07db59f  vmovaps [rsp+0x10], xmm1
00007e1ec07db5a5  vmovaps [rsp+0x20], xmm2
00007e1ec07db5ab  vmovaps [rsp+0x30], xmm3
00007e1ec07db5b1  vmovaps [rsp+0x40], xmm4
00007e1ec07db5b7  vmovaps [rsp+0x50], xmm5
00007e1ec07db5bd  vmovaps [rsp+0x60], xmm7
00007e1ec07db5c3  vmovaps [rsp+0x70], xmm8
00007e1ec07db5c9  vmovaps [rsp+0x80], xmm9
00007e1ec07db5d2  vmovaps [rsp+0x90], xmm10
00007e1ec07db5db  vmovaps [rsp+0xA0], xmm11
00007e1ec07db5e4  vmovaps [rsp+0xB0], xmm12
00007e1ec07db5ed  vmovaps [rsp+0xC0], xmm13
00007e1ec07db5f6  vmovaps [rsp+0xD0], xmm14
00007e1ec07db5ff  vmovaps [rsp+0xE0], xmm15
00007e1ec07db608  sub rsp, 0x30
00007e1ec07db60c  movaps [rsp], xmm6
00007e1ec07db610  movaps [rsp+0x10], xmm9
00007e1ec07db616  movaps [rsp+0x20], xmm1
00007e1ec07db61b  lea rdi, [rsp]
00007e1ec07db61f  mov esi, 0x00
00007e1ec07db624  mov rax, 0x5E00FF778530
00007e1ec07db62e  call rax
00007e1ec07db630  movaps xmm6, [rsp]
00007e1ec07db634  add rsp, 0x30
00007e1ec07db638  vmovaps xmm0, [rsp]
00007e1ec07db63d  vmovaps xmm1, [rsp+0x10]
00007e1ec07db643  vmovaps xmm2, [rsp+0x20]
00007e1ec07db649  vmovaps xmm3, [rsp+0x30]
00007e1ec07db64f  vmovaps xmm4, [rsp+0x40]
00007e1ec07db655  vmovaps xmm5, [rsp+0x50]
00007e1ec07db65b  vmovaps xmm7, [rsp+0x60]
00007e1ec07db661  vmovaps xmm8, [rsp+0x70]
00007e1ec07db667  vmovaps xmm9, [rsp+0x80]
00007e1ec07db670  vmovaps xmm10, [rsp+0x90]
00007e1ec07db679  vmovaps xmm11, [rsp+0xA0]
00007e1ec07db682  vmovaps xmm12, [rsp+0xB0]
00007e1ec07db68b  vmovaps xmm13, [rsp+0xC0]
00007e1ec07db694  vmovaps xmm14, [rsp+0xD0]
00007e1ec07db69d  vmovaps xmm15, [rsp+0xE0]
00007e1ec07db6a6  add rsp, 0xF0
00007e1ec07db6ad  pop r11
00007e1ec07db6af  pop r10
00007e1ec07db6b1  pop r9
00007e1ec07db6b3  pop r8
00007e1ec07db6b5  pop rsi
00007e1ec07db6b6  pop rdi
00007e1ec07db6b7  pop rdx
00007e1ec07db6b8  pop rcx
00007e1ec07db6b9  pop rax
00007e1ec07db6ba  add rsp, 0x08
00007e1ec07db6be  jmp 0x00007E1EC07D918B
00007e1ec07db6c3  sub rsp, 0x08
00007e1ec07db6c7  push rax
00007e1ec07db6c8  push rcx
00007e1ec07db6c9  push rdx
00007e1ec07db6ca  push rdi
00007e1ec07db6cb  push rsi
00007e1ec07db6cc  push r8
00007e1ec07db6ce  push r9
00007e1ec07db6d0  push r10
00007e1ec07db6d2  push r11
00007e1ec07db6d4  sub rsp, 0xF0
00007e1ec07db6db  vmovaps [rsp], xmm0
00007e1ec07db6e0  vmovaps [rsp+0x10], xmm1
00007e1ec07db6e6  vmovaps [rsp+0x20], xmm2
00007e1ec07db6ec  vmovaps [rsp+0x30], xmm3
00007e1ec07db6f2  vmovaps [rsp+0x40], xmm4
00007e1ec07db6f8  vmovaps [rsp+0x50], xmm5
00007e1ec07db6fe  vmovaps [rsp+0x60], xmm6
00007e1ec07db704  vmovaps [rsp+0x70], xmm7
00007e1ec07db70a  vmovaps [rsp+0x80], xmm8
00007e1ec07db713  vmovaps [rsp+0x90], xmm10
00007e1ec07db71c  vmovaps [rsp+0xA0], xmm11
00007e1ec07db725  vmovaps [rsp+0xB0], xmm12
00007e1ec07db72e  vmovaps [rsp+0xC0], xmm13
00007e1ec07db737  vmovaps [rsp+0xD0], xmm14
00007e1ec07db740  vmovaps [rsp+0xE0], xmm15
00007e1ec07db749  sub rsp, 0x30
00007e1ec07db74d  movaps [rsp], xmm9
00007e1ec07db752  movaps [rsp+0x10], xmm3
00007e1ec07db757  movaps [rsp+0x20], xmm1
00007e1ec07db75c  lea rdi, [rsp]
00007e1ec07db760  mov esi, 0x00
00007e1ec07db765  mov rax, 0x5E00FF778530
00007e1ec07db76f  call rax
00007e1ec07db771  movaps xmm9, [rsp]
00007e1ec07db776  add rsp, 0x30
00007e1ec07db77a  vmovaps xmm0, [rsp]
00007e1ec07db77f  vmovaps xmm1, [rsp+0x10]
00007e1ec07db785  vmovaps xmm2, [rsp+0x20]
00007e1ec07db78b  vmovaps xmm3, [rsp+0x30]
00007e1ec07db791  vmovaps xmm4, [rsp+0x40]
00007e1ec07db797  vmovaps xmm5, [rsp+0x50]
00007e1ec07db79d  vmovaps xmm6, [rsp+0x60]
00007e1ec07db7a3  vmovaps xmm7, [rsp+0x70]
00007e1ec07db7a9  vmovaps xmm8, [rsp+0x80]
00007e1ec07db7b2  vmovaps xmm10, [rsp+0x90]
00007e1ec07db7bb  vmovaps xmm11, [rsp+0xA0]
00007e1ec07db7c4  vmovaps xmm12, [rsp+0xB0]
00007e1ec07db7cd  vmovaps xmm13, [rsp+0xC0]
00007e1ec07db7d6  vmovaps xmm14, [rsp+0xD0]
00007e1ec07db7df  vmovaps xmm15, [rsp+0xE0]
00007e1ec07db7e8  add rsp, 0xF0
00007e1ec07db7ef  pop r11
00007e1ec07db7f1  pop r10
00007e1ec07db7f3  pop r9
00007e1ec07db7f5  pop r8
00007e1ec07db7f7  pop rsi
00007e1ec07db7f8  pop rdi
00007e1ec07db7f9  pop rdx
00007e1ec07db7fa  pop rcx
00007e1ec07db7fb  pop rax
00007e1ec07db7fc  add rsp, 0x08
00007e1ec07db800  jmp 0x00007E1EC07D91D7
00007e1ec07db805  call 0x00007E1EC06D64F0
00007e1ec07db80a  jmp 0x00007E1EC07D91E4
00007e1ec07db80f  sub rsp, 0x08
00007e1ec07db813  push rax
00007e1ec07db814  push rcx
00007e1ec07db815  push rdx
00007e1ec07db816  push rdi
00007e1ec07db817  push rsi
00007e1ec07db818  push r8
00007e1ec07db81a  push r9
00007e1ec07db81c  push r10
00007e1ec07db81e  push r11
00007e1ec07db820  sub rsp, 0xF0
00007e1ec07db827  vmovaps [rsp], xmm0
00007e1ec07db82c  vmovaps [rsp+0x10], xmm1
00007e1ec07db832  vmovaps [rsp+0x20], xmm2
00007e1ec07db838  vmovaps [rsp+0x30], xmm3
00007e1ec07db83e  vmovaps [rsp+0x40], xmm4
00007e1ec07db844  vmovaps [rsp+0x50], xmm5
00007e1ec07db84a  vmovaps [rsp+0x60], xmm6
00007e1ec07db850  vmovaps [rsp+0x70], xmm7
00007e1ec07db856  vmovaps [rsp+0x80], xmm8
00007e1ec07db85f  vmovaps [rsp+0x90], xmm9
00007e1ec07db868  vmovaps [rsp+0xA0], xmm10
00007e1ec07db871  vmovaps [rsp+0xB0], xmm11
00007e1ec07db87a  vmovaps [rsp+0xC0], xmm12
00007e1ec07db883  vmovaps [rsp+0xD0], xmm13
00007e1ec07db88c  vmovaps [rsp+0xE0], xmm14
00007e1ec07db895  sub rsp, 0x30
00007e1ec07db899  movaps [rsp], xmm15
00007e1ec07db89e  movaps [rsp+0x10], xmm3
00007e1ec07db8a3  movaps [rsp+0x20], xmm7
00007e1ec07db8a8  lea rdi, [rsp]
00007e1ec07db8ac  mov esi, 0x00
00007e1ec07db8b1  mov rax, 0x5E00FF778530
00007e1ec07db8bb  call rax
00007e1ec07db8bd  movaps xmm15, [rsp]
00007e1ec07db8c2  add rsp, 0x30
00007e1ec07db8c6  vmovaps xmm0, [rsp]
00007e1ec07db8cb  vmovaps xmm1, [rsp+0x10]
00007e1ec07db8d1  vmovaps xmm2, [rsp+0x20]
00007e1ec07db8d7  vmovaps xmm3, [rsp+0x30]
00007e1ec07db8dd  vmovaps xmm4, [rsp+0x40]
00007e1ec07db8e3  vmovaps xmm5, [rsp+0x50]
00007e1ec07db8e9  vmovaps xmm6, [rsp+0x60]
00007e1ec07db8ef  vmovaps xmm7, [rsp+0x70]
00007e1ec07db8f5  vmovaps xmm8, [rsp+0x80]
00007e1ec07db8fe  vmovaps xmm9, [rsp+0x90]
00007e1ec07db907  vmovaps xmm10, [rsp+0xA0]
00007e1ec07db910  vmovaps xmm11, [rsp+0xB0]
00007e1ec07db919  vmovaps xmm12, [rsp+0xC0]
00007e1ec07db922  vmovaps xmm13, [rsp+0xD0]
00007e1ec07db92b  vmovaps xmm14, [rsp+0xE0]
00007e1ec07db934  add rsp, 0xF0
00007e1ec07db93b  pop r11
00007e1ec07db93d  pop r10
00007e1ec07db93f  pop r9
00007e1ec07db941  pop r8
00007e1ec07db943  pop rsi
00007e1ec07db944  pop rdi
00007e1ec07db945  pop rdx
00007e1ec07db946  pop rcx
00007e1ec07db947  pop rax
00007e1ec07db948  add rsp, 0x08
00007e1ec07db94c  jmp 0x00007E1EC07D9210
00007e1ec07db951  sub rsp, 0x08
00007e1ec07db955  push rax
00007e1ec07db956  push rcx
00007e1ec07db957  push rdx
00007e1ec07db958  push rdi
00007e1ec07db959  push rsi
00007e1ec07db95a  push r8
00007e1ec07db95c  push r9
00007e1ec07db95e  push r10
00007e1ec07db960  push r11
00007e1ec07db962  sub rsp, 0xF0
00007e1ec07db969  vmovaps [rsp], xmm0
00007e1ec07db96e  vmovaps [rsp+0x10], xmm1
00007e1ec07db974  vmovaps [rsp+0x20], xmm2
00007e1ec07db97a  vmovaps [rsp+0x30], xmm4
00007e1ec07db980  vmovaps [rsp+0x40], xmm5
00007e1ec07db986  vmovaps [rsp+0x50], xmm6
00007e1ec07db98c  vmovaps [rsp+0x60], xmm7
00007e1ec07db992  vmovaps [rsp+0x70], xmm8
00007e1ec07db998  vmovaps [rsp+0x80], xmm9
00007e1ec07db9a1  vmovaps [rsp+0x90], xmm10
00007e1ec07db9aa  vmovaps [rsp+0xA0], xmm11
00007e1ec07db9b3  vmovaps [rsp+0xB0], xmm12
00007e1ec07db9bc  vmovaps [rsp+0xC0], xmm13
00007e1ec07db9c5  vmovaps [rsp+0xD0], xmm14
00007e1ec07db9ce  vmovaps [rsp+0xE0], xmm15
00007e1ec07db9d7  sub rsp, 0x30
00007e1ec07db9db  movaps [rsp], xmm3
00007e1ec07db9df  movaps [rsp+0x10], xmm1
00007e1ec07db9e4  movaps [rsp+0x20], xmm15
00007e1ec07db9ea  lea rdi, [rsp]
00007e1ec07db9ee  mov esi, 0x00
00007e1ec07db9f3  mov rax, 0x5E00FF778530
00007e1ec07db9fd  call rax
00007e1ec07db9ff  movaps xmm3, [rsp]
00007e1ec07dba03  add rsp, 0x30
00007e1ec07dba07  vmovaps xmm0, [rsp]
00007e1ec07dba0c  vmovaps xmm1, [rsp+0x10]
00007e1ec07dba12  vmovaps xmm2, [rsp+0x20]
00007e1ec07dba18  vmovaps xmm4, [rsp+0x30]
00007e1ec07dba1e  vmovaps xmm5, [rsp+0x40]
00007e1ec07dba24  vmovaps xmm6, [rsp+0x50]
00007e1ec07dba2a  vmovaps xmm7, [rsp+0x60]
00007e1ec07dba30  vmovaps xmm8, [rsp+0x70]
00007e1ec07dba36  vmovaps xmm9, [rsp+0x80]
00007e1ec07dba3f  vmovaps xmm10, [rsp+0x90]
00007e1ec07dba48  vmovaps xmm11, [rsp+0xA0]
00007e1ec07dba51  vmovaps xmm12, [rsp+0xB0]
00007e1ec07dba5a  vmovaps xmm13, [rsp+0xC0]
00007e1ec07dba63  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dba6c  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dba75  add rsp, 0xF0
00007e1ec07dba7c  pop r11
00007e1ec07dba7e  pop r10
00007e1ec07dba80  pop r9
00007e1ec07dba82  pop r8
00007e1ec07dba84  pop rsi
00007e1ec07dba85  pop rdi
00007e1ec07dba86  pop rdx
00007e1ec07dba87  pop rcx
00007e1ec07dba88  pop rax
00007e1ec07dba89  add rsp, 0x08
00007e1ec07dba8d  jmp 0x00007E1EC07D929F
00007e1ec07dba92  call 0x00007E1EC06D64F0
00007e1ec07dba97  jmp 0x00007E1EC07D92A9
00007e1ec07dba9c  sub rsp, 0x08
00007e1ec07dbaa0  push rax
00007e1ec07dbaa1  push rcx
00007e1ec07dbaa2  push rdx
00007e1ec07dbaa3  push rdi
00007e1ec07dbaa4  push rsi
00007e1ec07dbaa5  push r8
00007e1ec07dbaa7  push r9
00007e1ec07dbaa9  push r10
00007e1ec07dbaab  push r11
00007e1ec07dbaad  sub rsp, 0xF0
00007e1ec07dbab4  vmovaps [rsp], xmm0
00007e1ec07dbab9  vmovaps [rsp+0x10], xmm1
00007e1ec07dbabf  vmovaps [rsp+0x20], xmm2
00007e1ec07dbac5  vmovaps [rsp+0x30], xmm3
00007e1ec07dbacb  vmovaps [rsp+0x40], xmm4
00007e1ec07dbad1  vmovaps [rsp+0x50], xmm5
00007e1ec07dbad7  vmovaps [rsp+0x60], xmm6
00007e1ec07dbadd  vmovaps [rsp+0x70], xmm7
00007e1ec07dbae3  vmovaps [rsp+0x80], xmm8
00007e1ec07dbaec  vmovaps [rsp+0x90], xmm9
00007e1ec07dbaf5  vmovaps [rsp+0xA0], xmm10
00007e1ec07dbafe  vmovaps [rsp+0xB0], xmm11
00007e1ec07dbb07  vmovaps [rsp+0xC0], xmm12
00007e1ec07dbb10  vmovaps [rsp+0xD0], xmm13
00007e1ec07dbb19  vmovaps [rsp+0xE0], xmm14
00007e1ec07dbb22  sub rsp, 0x30
00007e1ec07dbb26  movaps [rsp], xmm15
00007e1ec07dbb2b  movaps [rsp+0x10], xmm14
00007e1ec07dbb31  movaps [rsp+0x20], xmm4
00007e1ec07dbb36  lea rdi, [rsp]
00007e1ec07dbb3a  mov esi, 0x00
00007e1ec07dbb3f  mov rax, 0x5E00FF778530
00007e1ec07dbb49  call rax
00007e1ec07dbb4b  movaps xmm15, [rsp]
00007e1ec07dbb50  add rsp, 0x30
00007e1ec07dbb54  vmovaps xmm0, [rsp]
00007e1ec07dbb59  vmovaps xmm1, [rsp+0x10]
00007e1ec07dbb5f  vmovaps xmm2, [rsp+0x20]
00007e1ec07dbb65  vmovaps xmm3, [rsp+0x30]
00007e1ec07dbb6b  vmovaps xmm4, [rsp+0x40]
00007e1ec07dbb71  vmovaps xmm5, [rsp+0x50]
00007e1ec07dbb77  vmovaps xmm6, [rsp+0x60]
00007e1ec07dbb7d  vmovaps xmm7, [rsp+0x70]
00007e1ec07dbb83  vmovaps xmm8, [rsp+0x80]
00007e1ec07dbb8c  vmovaps xmm9, [rsp+0x90]
00007e1ec07dbb95  vmovaps xmm10, [rsp+0xA0]
00007e1ec07dbb9e  vmovaps xmm11, [rsp+0xB0]
00007e1ec07dbba7  vmovaps xmm12, [rsp+0xC0]
00007e1ec07dbbb0  vmovaps xmm13, [rsp+0xD0]
00007e1ec07dbbb9  vmovaps xmm14, [rsp+0xE0]
00007e1ec07dbbc2  add rsp, 0xF0
00007e1ec07dbbc9  pop r11
00007e1ec07dbbcb  pop r10
00007e1ec07dbbcd  pop r9
00007e1ec07dbbcf  pop r8
00007e1ec07dbbd1  pop rsi
00007e1ec07dbbd2  pop rdi
00007e1ec07dbbd3  pop rdx
00007e1ec07dbbd4  pop rcx
00007e1ec07dbbd5  pop rax
00007e1ec07dbbd6  add rsp, 0x08
00007e1ec07dbbda  jmp 0x00007E1EC07D92D7
00007e1ec07dbbdf  sub rsp, 0x08
00007e1ec07dbbe3  push rax
00007e1ec07dbbe4  push rcx
00007e1ec07dbbe5  push rdx
00007e1ec07dbbe6  push rdi
00007e1ec07dbbe7  push rsi
00007e1ec07dbbe8  push r8
00007e1ec07dbbea  push r9
00007e1ec07dbbec  push r10
00007e1ec07dbbee  push r11
00007e1ec07dbbf0  sub rsp, 0xF0
00007e1ec07dbbf7  vmovaps [rsp], xmm0
00007e1ec07dbbfc  vmovaps [rsp+0x10], xmm1
00007e1ec07dbc02  vmovaps [rsp+0x20], xmm2
00007e1ec07dbc08  vmovaps [rsp+0x30], xmm3
00007e1ec07dbc0e  vmovaps [rsp+0x40], xmm4
00007e1ec07dbc14  vmovaps [rsp+0x50], xmm5
00007e1ec07dbc1a  vmovaps [rsp+0x60], xmm6
00007e1ec07dbc20  vmovaps [rsp+0x70], xmm7
00007e1ec07dbc26  vmovaps [rsp+0x80], xmm8
00007e1ec07dbc2f  vmovaps [rsp+0x90], xmm9
00007e1ec07dbc38  vmovaps [rsp+0xA0], xmm10
00007e1ec07dbc41  vmovaps [rsp+0xB0], xmm11
00007e1ec07dbc4a  vmovaps [rsp+0xC0], xmm12
00007e1ec07dbc53  vmovaps [rsp+0xD0], xmm13
00007e1ec07dbc5c  vmovaps [rsp+0xE0], xmm15
00007e1ec07dbc65  sub rsp, 0x30
00007e1ec07dbc69  movaps [rsp], xmm14
00007e1ec07dbc6e  movaps [rsp+0x10], xmm2
00007e1ec07dbc73  movaps [rsp+0x20], xmm1
00007e1ec07dbc78  lea rdi, [rsp]
00007e1ec07dbc7c  mov esi, 0x00
00007e1ec07dbc81  mov rax, 0x5E00FF778530
00007e1ec07dbc8b  call rax
00007e1ec07dbc8d  movaps xmm14, [rsp]
00007e1ec07dbc92  add rsp, 0x30
00007e1ec07dbc96  vmovaps xmm0, [rsp]
00007e1ec07dbc9b  vmovaps xmm1, [rsp+0x10]
00007e1ec07dbca1  vmovaps xmm2, [rsp+0x20]
00007e1ec07dbca7  vmovaps xmm3, [rsp+0x30]
00007e1ec07dbcad  vmovaps xmm4, [rsp+0x40]
00007e1ec07dbcb3  vmovaps xmm5, [rsp+0x50]
00007e1ec07dbcb9  vmovaps xmm6, [rsp+0x60]
00007e1ec07dbcbf  vmovaps xmm7, [rsp+0x70]
00007e1ec07dbcc5  vmovaps xmm8, [rsp+0x80]
00007e1ec07dbcce  vmovaps xmm9, [rsp+0x90]
00007e1ec07dbcd7  vmovaps xmm10, [rsp+0xA0]
00007e1ec07dbce0  vmovaps xmm11, [rsp+0xB0]
00007e1ec07dbce9  vmovaps xmm12, [rsp+0xC0]
00007e1ec07dbcf2  vmovaps xmm13, [rsp+0xD0]
00007e1ec07dbcfb  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dbd04  add rsp, 0xF0
00007e1ec07dbd0b  pop r11
00007e1ec07dbd0d  pop r10
00007e1ec07dbd0f  pop r9
00007e1ec07dbd11  pop r8
00007e1ec07dbd13  pop rsi
00007e1ec07dbd14  pop rdi
00007e1ec07dbd15  pop rdx
00007e1ec07dbd16  pop rcx
00007e1ec07dbd17  pop rax
00007e1ec07dbd18  add rsp, 0x08
00007e1ec07dbd1c  jmp 0x00007E1EC07D92FD
00007e1ec07dbd21  sub rsp, 0x08
00007e1ec07dbd25  push rax
00007e1ec07dbd26  push rcx
00007e1ec07dbd27  push rdx
00007e1ec07dbd28  push rdi
00007e1ec07dbd29  push rsi
00007e1ec07dbd2a  push r8
00007e1ec07dbd2c  push r9
00007e1ec07dbd2e  push r10
00007e1ec07dbd30  push r11
00007e1ec07dbd32  sub rsp, 0xF0
00007e1ec07dbd39  vmovaps [rsp], xmm0
00007e1ec07dbd3e  vmovaps [rsp+0x10], xmm2
00007e1ec07dbd44  vmovaps [rsp+0x20], xmm3
00007e1ec07dbd4a  vmovaps [rsp+0x30], xmm4
00007e1ec07dbd50  vmovaps [rsp+0x40], xmm5
00007e1ec07dbd56  vmovaps [rsp+0x50], xmm6
00007e1ec07dbd5c  vmovaps [rsp+0x60], xmm7
00007e1ec07dbd62  vmovaps [rsp+0x70], xmm8
00007e1ec07dbd68  vmovaps [rsp+0x80], xmm9
00007e1ec07dbd71  vmovaps [rsp+0x90], xmm10
00007e1ec07dbd7a  vmovaps [rsp+0xA0], xmm11
00007e1ec07dbd83  vmovaps [rsp+0xB0], xmm12
00007e1ec07dbd8c  vmovaps [rsp+0xC0], xmm13
00007e1ec07dbd95  vmovaps [rsp+0xD0], xmm14
00007e1ec07dbd9e  vmovaps [rsp+0xE0], xmm15
00007e1ec07dbda7  sub rsp, 0x30
00007e1ec07dbdab  movaps [rsp], xmm1
00007e1ec07dbdaf  movaps [rsp+0x10], xmm4
00007e1ec07dbdb4  movaps [rsp+0x20], xmm9
00007e1ec07dbdba  lea rdi, [rsp]
00007e1ec07dbdbe  mov esi, 0x00
00007e1ec07dbdc3  mov rax, 0x5E00FF778530
00007e1ec07dbdcd  call rax
00007e1ec07dbdcf  movaps xmm1, [rsp]
00007e1ec07dbdd3  add rsp, 0x30
00007e1ec07dbdd7  vmovaps xmm0, [rsp]
00007e1ec07dbddc  vmovaps xmm2, [rsp+0x10]
00007e1ec07dbde2  vmovaps xmm3, [rsp+0x20]
00007e1ec07dbde8  vmovaps xmm4, [rsp+0x30]
00007e1ec07dbdee  vmovaps xmm5, [rsp+0x40]
00007e1ec07dbdf4  vmovaps xmm6, [rsp+0x50]
00007e1ec07dbdfa  vmovaps xmm7, [rsp+0x60]
00007e1ec07dbe00  vmovaps xmm8, [rsp+0x70]
00007e1ec07dbe06  vmovaps xmm9, [rsp+0x80]
00007e1ec07dbe0f  vmovaps xmm10, [rsp+0x90]
00007e1ec07dbe18  vmovaps xmm11, [rsp+0xA0]
00007e1ec07dbe21  vmovaps xmm12, [rsp+0xB0]
00007e1ec07dbe2a  vmovaps xmm13, [rsp+0xC0]
00007e1ec07dbe33  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dbe3c  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dbe45  add rsp, 0xF0
00007e1ec07dbe4c  pop r11
00007e1ec07dbe4e  pop r10
00007e1ec07dbe50  pop r9
00007e1ec07dbe52  pop r8
00007e1ec07dbe54  pop rsi
00007e1ec07dbe55  pop rdi
00007e1ec07dbe56  pop rdx
00007e1ec07dbe57  pop rcx
00007e1ec07dbe58  pop rax
00007e1ec07dbe59  add rsp, 0x08
00007e1ec07dbe5d  jmp 0x00007E1EC07D931B
00007e1ec07dbe62  sub rsp, 0x08
00007e1ec07dbe66  push rax
00007e1ec07dbe67  push rcx
00007e1ec07dbe68  push rdx
00007e1ec07dbe69  push rdi
00007e1ec07dbe6a  push rsi
00007e1ec07dbe6b  push r8
00007e1ec07dbe6d  push r9
00007e1ec07dbe6f  push r10
00007e1ec07dbe71  push r11
00007e1ec07dbe73  sub rsp, 0xF0
00007e1ec07dbe7a  vmovaps [rsp], xmm0
00007e1ec07dbe7f  vmovaps [rsp+0x10], xmm1
00007e1ec07dbe85  vmovaps [rsp+0x20], xmm2
00007e1ec07dbe8b  vmovaps [rsp+0x30], xmm3
00007e1ec07dbe91  vmovaps [rsp+0x40], xmm5
00007e1ec07dbe97  vmovaps [rsp+0x50], xmm6
00007e1ec07dbe9d  vmovaps [rsp+0x60], xmm7
00007e1ec07dbea3  vmovaps [rsp+0x70], xmm8
00007e1ec07dbea9  vmovaps [rsp+0x80], xmm9
00007e1ec07dbeb2  vmovaps [rsp+0x90], xmm10
00007e1ec07dbebb  vmovaps [rsp+0xA0], xmm11
00007e1ec07dbec4  vmovaps [rsp+0xB0], xmm12
00007e1ec07dbecd  vmovaps [rsp+0xC0], xmm13
00007e1ec07dbed6  vmovaps [rsp+0xD0], xmm14
00007e1ec07dbedf  vmovaps [rsp+0xE0], xmm15
00007e1ec07dbee8  sub rsp, 0x30
00007e1ec07dbeec  movaps [rsp], xmm4
00007e1ec07dbef0  movaps [rsp+0x10], xmm2
00007e1ec07dbef5  movaps [rsp+0x20], xmm9
00007e1ec07dbefb  lea rdi, [rsp]
00007e1ec07dbeff  mov esi, 0x00
00007e1ec07dbf04  mov rax, 0x5E00FF778530
00007e1ec07dbf0e  call rax
00007e1ec07dbf10  movaps xmm4, [rsp]
00007e1ec07dbf14  add rsp, 0x30
00007e1ec07dbf18  vmovaps xmm0, [rsp]
00007e1ec07dbf1d  vmovaps xmm1, [rsp+0x10]
00007e1ec07dbf23  vmovaps xmm2, [rsp+0x20]
00007e1ec07dbf29  vmovaps xmm3, [rsp+0x30]
00007e1ec07dbf2f  vmovaps xmm5, [rsp+0x40]
00007e1ec07dbf35  vmovaps xmm6, [rsp+0x50]
00007e1ec07dbf3b  vmovaps xmm7, [rsp+0x60]
00007e1ec07dbf41  vmovaps xmm8, [rsp+0x70]
00007e1ec07dbf47  vmovaps xmm9, [rsp+0x80]
00007e1ec07dbf50  vmovaps xmm10, [rsp+0x90]
00007e1ec07dbf59  vmovaps xmm11, [rsp+0xA0]
00007e1ec07dbf62  vmovaps xmm12, [rsp+0xB0]
00007e1ec07dbf6b  vmovaps xmm13, [rsp+0xC0]
00007e1ec07dbf74  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dbf7d  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dbf86  add rsp, 0xF0
00007e1ec07dbf8d  pop r11
00007e1ec07dbf8f  pop r10
00007e1ec07dbf91  pop r9
00007e1ec07dbf93  pop r8
00007e1ec07dbf95  pop rsi
00007e1ec07dbf96  pop rdi
00007e1ec07dbf97  pop rdx
00007e1ec07dbf98  pop rcx
00007e1ec07dbf99  pop rax
00007e1ec07dbf9a  add rsp, 0x08
00007e1ec07dbf9e  jmp 0x00007E1EC07D934B
00007e1ec07dbfa3  sub rsp, 0x08
00007e1ec07dbfa7  push rax
00007e1ec07dbfa8  push rcx
00007e1ec07dbfa9  push rdx
00007e1ec07dbfaa  push rdi
00007e1ec07dbfab  push rsi
00007e1ec07dbfac  push r8
00007e1ec07dbfae  push r9
00007e1ec07dbfb0  push r10
00007e1ec07dbfb2  push r11
00007e1ec07dbfb4  sub rsp, 0xF0
00007e1ec07dbfbb  vmovaps [rsp], xmm0
00007e1ec07dbfc0  vmovaps [rsp+0x10], xmm1
00007e1ec07dbfc6  vmovaps [rsp+0x20], xmm2
00007e1ec07dbfcc  vmovaps [rsp+0x30], xmm3
00007e1ec07dbfd2  vmovaps [rsp+0x40], xmm4
00007e1ec07dbfd8  vmovaps [rsp+0x50], xmm5
00007e1ec07dbfde  vmovaps [rsp+0x60], xmm6
00007e1ec07dbfe4  vmovaps [rsp+0x70], xmm7
00007e1ec07dbfea  vmovaps [rsp+0x80], xmm8
00007e1ec07dbff3  vmovaps [rsp+0x90], xmm10
00007e1ec07dbffc  vmovaps [rsp+0xA0], xmm11
00007e1ec07dc005  vmovaps [rsp+0xB0], xmm12
00007e1ec07dc00e  vmovaps [rsp+0xC0], xmm13
00007e1ec07dc017  vmovaps [rsp+0xD0], xmm14
00007e1ec07dc020  vmovaps [rsp+0xE0], xmm15
00007e1ec07dc029  sub rsp, 0x30
00007e1ec07dc02d  movaps [rsp], xmm9
00007e1ec07dc032  movaps [rsp+0x10], xmm2
00007e1ec07dc037  movaps [rsp+0x20], xmm1
00007e1ec07dc03c  lea rdi, [rsp]
00007e1ec07dc040  mov esi, 0x00
00007e1ec07dc045  mov rax, 0x5E00FF778530
00007e1ec07dc04f  call rax
00007e1ec07dc051  movaps xmm9, [rsp]
00007e1ec07dc056  add rsp, 0x30
00007e1ec07dc05a  vmovaps xmm0, [rsp]
00007e1ec07dc05f  vmovaps xmm1, [rsp+0x10]
00007e1ec07dc065  vmovaps xmm2, [rsp+0x20]
00007e1ec07dc06b  vmovaps xmm3, [rsp+0x30]
00007e1ec07dc071  vmovaps xmm4, [rsp+0x40]
00007e1ec07dc077  vmovaps xmm5, [rsp+0x50]
00007e1ec07dc07d  vmovaps xmm6, [rsp+0x60]
00007e1ec07dc083  vmovaps xmm7, [rsp+0x70]
00007e1ec07dc089  vmovaps xmm8, [rsp+0x80]
00007e1ec07dc092  vmovaps xmm10, [rsp+0x90]
00007e1ec07dc09b  vmovaps xmm11, [rsp+0xA0]
00007e1ec07dc0a4  vmovaps xmm12, [rsp+0xB0]
00007e1ec07dc0ad  vmovaps xmm13, [rsp+0xC0]
00007e1ec07dc0b6  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dc0bf  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dc0c8  add rsp, 0xF0
00007e1ec07dc0cf  pop r11
00007e1ec07dc0d1  pop r10
00007e1ec07dc0d3  pop r9
00007e1ec07dc0d5  pop r8
00007e1ec07dc0d7  pop rsi
00007e1ec07dc0d8  pop rdi
00007e1ec07dc0d9  pop rdx
00007e1ec07dc0da  pop rcx
00007e1ec07dc0db  pop rax
00007e1ec07dc0dc  add rsp, 0x08
00007e1ec07dc0e0  jmp 0x00007E1EC07D9381
00007e1ec07dc0e5  sub rsp, 0x08
00007e1ec07dc0e9  push rax
00007e1ec07dc0ea  push rcx
00007e1ec07dc0eb  push rdx
00007e1ec07dc0ec  push rdi
00007e1ec07dc0ed  push rsi
00007e1ec07dc0ee  push r8
00007e1ec07dc0f0  push r9
00007e1ec07dc0f2  push r10
00007e1ec07dc0f4  push r11
00007e1ec07dc0f6  sub rsp, 0xF0
00007e1ec07dc0fd  vmovaps [rsp], xmm0
00007e1ec07dc102  vmovaps [rsp+0x10], xmm2
00007e1ec07dc108  vmovaps [rsp+0x20], xmm3
00007e1ec07dc10e  vmovaps [rsp+0x30], xmm4
00007e1ec07dc114  vmovaps [rsp+0x40], xmm5
00007e1ec07dc11a  vmovaps [rsp+0x50], xmm6
00007e1ec07dc120  vmovaps [rsp+0x60], xmm7
00007e1ec07dc126  vmovaps [rsp+0x70], xmm8
00007e1ec07dc12c  vmovaps [rsp+0x80], xmm9
00007e1ec07dc135  vmovaps [rsp+0x90], xmm10
00007e1ec07dc13e  vmovaps [rsp+0xA0], xmm11
00007e1ec07dc147  vmovaps [rsp+0xB0], xmm12
00007e1ec07dc150  vmovaps [rsp+0xC0], xmm13
00007e1ec07dc159  vmovaps [rsp+0xD0], xmm14
00007e1ec07dc162  vmovaps [rsp+0xE0], xmm15
00007e1ec07dc16b  sub rsp, 0x30
00007e1ec07dc16f  movaps [rsp], xmm1
00007e1ec07dc173  movaps [rsp+0x10], xmm15
00007e1ec07dc179  movaps [rsp+0x20], xmm6
00007e1ec07dc17e  lea rdi, [rsp]
00007e1ec07dc182  mov esi, 0x00
00007e1ec07dc187  mov rax, 0x5E00FF778530
00007e1ec07dc191  call rax
00007e1ec07dc193  movaps xmm1, [rsp]
00007e1ec07dc197  add rsp, 0x30
00007e1ec07dc19b  vmovaps xmm0, [rsp]
00007e1ec07dc1a0  vmovaps xmm2, [rsp+0x10]
00007e1ec07dc1a6  vmovaps xmm3, [rsp+0x20]
00007e1ec07dc1ac  vmovaps xmm4, [rsp+0x30]
00007e1ec07dc1b2  vmovaps xmm5, [rsp+0x40]
00007e1ec07dc1b8  vmovaps xmm6, [rsp+0x50]
00007e1ec07dc1be  vmovaps xmm7, [rsp+0x60]
00007e1ec07dc1c4  vmovaps xmm8, [rsp+0x70]
00007e1ec07dc1ca  vmovaps xmm9, [rsp+0x80]
00007e1ec07dc1d3  vmovaps xmm10, [rsp+0x90]
00007e1ec07dc1dc  vmovaps xmm11, [rsp+0xA0]
00007e1ec07dc1e5  vmovaps xmm12, [rsp+0xB0]
00007e1ec07dc1ee  vmovaps xmm13, [rsp+0xC0]
00007e1ec07dc1f7  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dc200  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dc209  add rsp, 0xF0
00007e1ec07dc210  pop r11
00007e1ec07dc212  pop r10
00007e1ec07dc214  pop r9
00007e1ec07dc216  pop r8
00007e1ec07dc218  pop rsi
00007e1ec07dc219  pop rdi
00007e1ec07dc21a  pop rdx
00007e1ec07dc21b  pop rcx
00007e1ec07dc21c  pop rax
00007e1ec07dc21d  add rsp, 0x08
00007e1ec07dc221  jmp 0x00007E1EC07D93A2
00007e1ec07dc226  sub rsp, 0x08
00007e1ec07dc22a  push rax
00007e1ec07dc22b  push rcx
00007e1ec07dc22c  push rdx
00007e1ec07dc22d  push rdi
00007e1ec07dc22e  push rsi
00007e1ec07dc22f  push r8
00007e1ec07dc231  push r9
00007e1ec07dc233  push r10
00007e1ec07dc235  push r11
00007e1ec07dc237  sub rsp, 0xF0
00007e1ec07dc23e  vmovaps [rsp], xmm0
00007e1ec07dc243  vmovaps [rsp+0x10], xmm1
00007e1ec07dc249  vmovaps [rsp+0x20], xmm2
00007e1ec07dc24f  vmovaps [rsp+0x30], xmm3
00007e1ec07dc255  vmovaps [rsp+0x40], xmm4
00007e1ec07dc25b  vmovaps [rsp+0x50], xmm5
00007e1ec07dc261  vmovaps [rsp+0x60], xmm6
00007e1ec07dc267  vmovaps [rsp+0x70], xmm7
00007e1ec07dc26d  vmovaps [rsp+0x80], xmm8
00007e1ec07dc276  vmovaps [rsp+0x90], xmm9
00007e1ec07dc27f  vmovaps [rsp+0xA0], xmm10
00007e1ec07dc288  vmovaps [rsp+0xB0], xmm11
00007e1ec07dc291  vmovaps [rsp+0xC0], xmm12
00007e1ec07dc29a  vmovaps [rsp+0xD0], xmm13
00007e1ec07dc2a3  vmovaps [rsp+0xE0], xmm14
00007e1ec07dc2ac  sub rsp, 0x30
00007e1ec07dc2b0  movaps [rsp], xmm15
00007e1ec07dc2b5  movaps [rsp+0x10], xmm5
00007e1ec07dc2ba  movaps [rsp+0x20], xmm3
00007e1ec07dc2bf  lea rdi, [rsp]
00007e1ec07dc2c3  mov esi, 0x00
00007e1ec07dc2c8  mov rax, 0x5E00FF778530
00007e1ec07dc2d2  call rax
00007e1ec07dc2d4  movaps xmm15, [rsp]
00007e1ec07dc2d9  add rsp, 0x30
00007e1ec07dc2dd  vmovaps xmm0, [rsp]
00007e1ec07dc2e2  vmovaps xmm1, [rsp+0x10]
00007e1ec07dc2e8  vmovaps xmm2, [rsp+0x20]
00007e1ec07dc2ee  vmovaps xmm3, [rsp+0x30]
00007e1ec07dc2f4  vmovaps xmm4, [rsp+0x40]
00007e1ec07dc2fa  vmovaps xmm5, [rsp+0x50]
00007e1ec07dc300  vmovaps xmm6, [rsp+0x60]
00007e1ec07dc306  vmovaps xmm7, [rsp+0x70]
00007e1ec07dc30c  vmovaps xmm8, [rsp+0x80]
00007e1ec07dc315  vmovaps xmm9, [rsp+0x90]
00007e1ec07dc31e  vmovaps xmm10, [rsp+0xA0]
00007e1ec07dc327  vmovaps xmm11, [rsp+0xB0]
00007e1ec07dc330  vmovaps xmm12, [rsp+0xC0]
00007e1ec07dc339  vmovaps xmm13, [rsp+0xD0]
00007e1ec07dc342  vmovaps xmm14, [rsp+0xE0]
00007e1ec07dc34b  add rsp, 0xF0
00007e1ec07dc352  pop r11
00007e1ec07dc354  pop r10
00007e1ec07dc356  pop r9
00007e1ec07dc358  pop r8
00007e1ec07dc35a  pop rsi
00007e1ec07dc35b  pop rdi
00007e1ec07dc35c  pop rdx
00007e1ec07dc35d  pop rcx
00007e1ec07dc35e  pop rax
00007e1ec07dc35f  add rsp, 0x08
00007e1ec07dc363  jmp 0x00007E1EC07D93BC
00007e1ec07dc368  sub rsp, 0x08
00007e1ec07dc36c  push rax
00007e1ec07dc36d  push rcx
00007e1ec07dc36e  push rdx
00007e1ec07dc36f  push rdi
00007e1ec07dc370  push rsi
00007e1ec07dc371  push r8
00007e1ec07dc373  push r9
00007e1ec07dc375  push r10
00007e1ec07dc377  push r11
00007e1ec07dc379  sub rsp, 0xF0
00007e1ec07dc380  vmovaps [rsp], xmm0
00007e1ec07dc385  vmovaps [rsp+0x10], xmm1
00007e1ec07dc38b  vmovaps [rsp+0x20], xmm2
00007e1ec07dc391  vmovaps [rsp+0x30], xmm3
00007e1ec07dc397  vmovaps [rsp+0x40], xmm4
00007e1ec07dc39d  vmovaps [rsp+0x50], xmm6
00007e1ec07dc3a3  vmovaps [rsp+0x60], xmm7
00007e1ec07dc3a9  vmovaps [rsp+0x70], xmm8
00007e1ec07dc3af  vmovaps [rsp+0x80], xmm9
00007e1ec07dc3b8  vmovaps [rsp+0x90], xmm10
00007e1ec07dc3c1  vmovaps [rsp+0xA0], xmm11
00007e1ec07dc3ca  vmovaps [rsp+0xB0], xmm12
00007e1ec07dc3d3  vmovaps [rsp+0xC0], xmm13
00007e1ec07dc3dc  vmovaps [rsp+0xD0], xmm14
00007e1ec07dc3e5  vmovaps [rsp+0xE0], xmm15
00007e1ec07dc3ee  sub rsp, 0x30
00007e1ec07dc3f2  movaps [rsp], xmm5
00007e1ec07dc3f6  movaps [rsp+0x10], xmm8
00007e1ec07dc3fc  movaps [rsp+0x20], xmm6
00007e1ec07dc401  lea rdi, [rsp]
00007e1ec07dc405  mov esi, 0x00
00007e1ec07dc40a  mov rax, 0x5E00FF778530
00007e1ec07dc414  call rax
00007e1ec07dc416  movaps xmm5, [rsp]
00007e1ec07dc41a  add rsp, 0x30
00007e1ec07dc41e  vmovaps xmm0, [rsp]
00007e1ec07dc423  vmovaps xmm1, [rsp+0x10]
00007e1ec07dc429  vmovaps xmm2, [rsp+0x20]
00007e1ec07dc42f  vmovaps xmm3, [rsp+0x30]
00007e1ec07dc435  vmovaps xmm4, [rsp+0x40]
00007e1ec07dc43b  vmovaps xmm6, [rsp+0x50]
00007e1ec07dc441  vmovaps xmm7, [rsp+0x60]
00007e1ec07dc447  vmovaps xmm8, [rsp+0x70]
00007e1ec07dc44d  vmovaps xmm9, [rsp+0x80]
00007e1ec07dc456  vmovaps xmm10, [rsp+0x90]
00007e1ec07dc45f  vmovaps xmm11, [rsp+0xA0]
00007e1ec07dc468  vmovaps xmm12, [rsp+0xB0]
00007e1ec07dc471  vmovaps xmm13, [rsp+0xC0]
00007e1ec07dc47a  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dc483  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dc48c  add rsp, 0xF0
00007e1ec07dc493  pop r11
00007e1ec07dc495  pop r10
00007e1ec07dc497  pop r9
00007e1ec07dc499  pop r8
00007e1ec07dc49b  pop rsi
00007e1ec07dc49c  pop rdi
00007e1ec07dc49d  pop rdx
00007e1ec07dc49e  pop rcx
00007e1ec07dc49f  pop rax
00007e1ec07dc4a0  add rsp, 0x08
00007e1ec07dc4a4  jmp 0x00007E1EC07D93E0
00007e1ec07dc4a9  sub rsp, 0x08
00007e1ec07dc4ad  push rax
00007e1ec07dc4ae  push rcx
00007e1ec07dc4af  push rdx
00007e1ec07dc4b0  push rdi
00007e1ec07dc4b1  push rsi
00007e1ec07dc4b2  push r8
00007e1ec07dc4b4  push r9
00007e1ec07dc4b6  push r10
00007e1ec07dc4b8  push r11
00007e1ec07dc4ba  sub rsp, 0xF0
00007e1ec07dc4c1  vmovaps [rsp], xmm0
00007e1ec07dc4c6  vmovaps [rsp+0x10], xmm1
00007e1ec07dc4cc  vmovaps [rsp+0x20], xmm2
00007e1ec07dc4d2  vmovaps [rsp+0x30], xmm3
00007e1ec07dc4d8  vmovaps [rsp+0x40], xmm4
00007e1ec07dc4de  vmovaps [rsp+0x50], xmm5
00007e1ec07dc4e4  vmovaps [rsp+0x60], xmm7
00007e1ec07dc4ea  vmovaps [rsp+0x70], xmm8
00007e1ec07dc4f0  vmovaps [rsp+0x80], xmm9
00007e1ec07dc4f9  vmovaps [rsp+0x90], xmm10
00007e1ec07dc502  vmovaps [rsp+0xA0], xmm11
00007e1ec07dc50b  vmovaps [rsp+0xB0], xmm12
00007e1ec07dc514  vmovaps [rsp+0xC0], xmm13
00007e1ec07dc51d  vmovaps [rsp+0xD0], xmm14
00007e1ec07dc526  vmovaps [rsp+0xE0], xmm15
00007e1ec07dc52f  sub rsp, 0x30
00007e1ec07dc533  movaps [rsp], xmm6
00007e1ec07dc537  movaps [rsp+0x10], xmm10
00007e1ec07dc53d  movaps [rsp+0x20], xmm8
00007e1ec07dc543  lea rdi, [rsp]
00007e1ec07dc547  mov esi, 0x00
00007e1ec07dc54c  mov rax, 0x5E00FF778530
00007e1ec07dc556  call rax
00007e1ec07dc558  movaps xmm6, [rsp]
00007e1ec07dc55c  add rsp, 0x30
00007e1ec07dc560  vmovaps xmm0, [rsp]
00007e1ec07dc565  vmovaps xmm1, [rsp+0x10]
00007e1ec07dc56b  vmovaps xmm2, [rsp+0x20]
00007e1ec07dc571  vmovaps xmm3, [rsp+0x30]
00007e1ec07dc577  vmovaps xmm4, [rsp+0x40]
00007e1ec07dc57d  vmovaps xmm5, [rsp+0x50]
00007e1ec07dc583  vmovaps xmm7, [rsp+0x60]
00007e1ec07dc589  vmovaps xmm8, [rsp+0x70]
00007e1ec07dc58f  vmovaps xmm9, [rsp+0x80]
00007e1ec07dc598  vmovaps xmm10, [rsp+0x90]
00007e1ec07dc5a1  vmovaps xmm11, [rsp+0xA0]
00007e1ec07dc5aa  vmovaps xmm12, [rsp+0xB0]
00007e1ec07dc5b3  vmovaps xmm13, [rsp+0xC0]
00007e1ec07dc5bc  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dc5c5  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dc5ce  add rsp, 0xF0
00007e1ec07dc5d5  pop r11
00007e1ec07dc5d7  pop r10
00007e1ec07dc5d9  pop r9
00007e1ec07dc5db  pop r8
00007e1ec07dc5dd  pop rsi
00007e1ec07dc5de  pop rdi
00007e1ec07dc5df  pop rdx
00007e1ec07dc5e0  pop rcx
00007e1ec07dc5e1  pop rax
00007e1ec07dc5e2  add rsp, 0x08
00007e1ec07dc5e6  jmp 0x00007E1EC07D9405
00007e1ec07dc5eb  sub rsp, 0x08
00007e1ec07dc5ef  push rax
00007e1ec07dc5f0  push rcx
00007e1ec07dc5f1  push rdx
00007e1ec07dc5f2  push rdi
00007e1ec07dc5f3  push rsi
00007e1ec07dc5f4  push r8
00007e1ec07dc5f6  push r9
00007e1ec07dc5f8  push r10
00007e1ec07dc5fa  push r11
00007e1ec07dc5fc  sub rsp, 0xF0
00007e1ec07dc603  vmovaps [rsp], xmm0
00007e1ec07dc608  vmovaps [rsp+0x10], xmm1
00007e1ec07dc60e  vmovaps [rsp+0x20], xmm2
00007e1ec07dc614  vmovaps [rsp+0x30], xmm3
00007e1ec07dc61a  vmovaps [rsp+0x40], xmm4
00007e1ec07dc620  vmovaps [rsp+0x50], xmm5
00007e1ec07dc626  vmovaps [rsp+0x60], xmm6
00007e1ec07dc62c  vmovaps [rsp+0x70], xmm7
00007e1ec07dc632  vmovaps [rsp+0x80], xmm8
00007e1ec07dc63b  vmovaps [rsp+0x90], xmm9
00007e1ec07dc644  vmovaps [rsp+0xA0], xmm11
00007e1ec07dc64d  vmovaps [rsp+0xB0], xmm12
00007e1ec07dc656  vmovaps [rsp+0xC0], xmm13
00007e1ec07dc65f  vmovaps [rsp+0xD0], xmm14
00007e1ec07dc668  vmovaps [rsp+0xE0], xmm15
00007e1ec07dc671  sub rsp, 0x30
00007e1ec07dc675  movaps [rsp], xmm10
00007e1ec07dc67a  movaps [rsp+0x10], xmm8
00007e1ec07dc680  movaps [rsp+0x20], xmm14
00007e1ec07dc686  lea rdi, [rsp]
00007e1ec07dc68a  mov esi, 0x00
00007e1ec07dc68f  mov rax, 0x5E00FF778530
00007e1ec07dc699  call rax
00007e1ec07dc69b  movaps xmm10, [rsp]
00007e1ec07dc6a0  add rsp, 0x30
00007e1ec07dc6a4  vmovaps xmm0, [rsp]
00007e1ec07dc6a9  vmovaps xmm1, [rsp+0x10]
00007e1ec07dc6af  vmovaps xmm2, [rsp+0x20]
00007e1ec07dc6b5  vmovaps xmm3, [rsp+0x30]
00007e1ec07dc6bb  vmovaps xmm4, [rsp+0x40]
00007e1ec07dc6c1  vmovaps xmm5, [rsp+0x50]
00007e1ec07dc6c7  vmovaps xmm6, [rsp+0x60]
00007e1ec07dc6cd  vmovaps xmm7, [rsp+0x70]
00007e1ec07dc6d3  vmovaps xmm8, [rsp+0x80]
00007e1ec07dc6dc  vmovaps xmm9, [rsp+0x90]
00007e1ec07dc6e5  vmovaps xmm11, [rsp+0xA0]
00007e1ec07dc6ee  vmovaps xmm12, [rsp+0xB0]
00007e1ec07dc6f7  vmovaps xmm13, [rsp+0xC0]
00007e1ec07dc700  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dc709  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dc712  add rsp, 0xF0
00007e1ec07dc719  pop r11
00007e1ec07dc71b  pop r10
00007e1ec07dc71d  pop r9
00007e1ec07dc71f  pop r8
00007e1ec07dc721  pop rsi
00007e1ec07dc722  pop rdi
00007e1ec07dc723  pop rdx
00007e1ec07dc724  pop rcx
00007e1ec07dc725  pop rax
00007e1ec07dc726  add rsp, 0x08
00007e1ec07dc72a  jmp 0x00007E1EC07D9425
00007e1ec07dc72f  sub rsp, 0x08
00007e1ec07dc733  push rax
00007e1ec07dc734  push rcx
00007e1ec07dc735  push rdx
00007e1ec07dc736  push rdi
00007e1ec07dc737  push rsi
00007e1ec07dc738  push r8
00007e1ec07dc73a  push r9
00007e1ec07dc73c  push r10
00007e1ec07dc73e  push r11
00007e1ec07dc740  sub rsp, 0xF0
00007e1ec07dc747  vmovaps [rsp], xmm0
00007e1ec07dc74c  vmovaps [rsp+0x10], xmm1
00007e1ec07dc752  vmovaps [rsp+0x20], xmm2
00007e1ec07dc758  vmovaps [rsp+0x30], xmm3
00007e1ec07dc75e  vmovaps [rsp+0x40], xmm4
00007e1ec07dc764  vmovaps [rsp+0x50], xmm5
00007e1ec07dc76a  vmovaps [rsp+0x60], xmm6
00007e1ec07dc770  vmovaps [rsp+0x70], xmm7
00007e1ec07dc776  vmovaps [rsp+0x80], xmm8
00007e1ec07dc77f  vmovaps [rsp+0x90], xmm9
00007e1ec07dc788  vmovaps [rsp+0xA0], xmm10
00007e1ec07dc791  vmovaps [rsp+0xB0], xmm11
00007e1ec07dc79a  vmovaps [rsp+0xC0], xmm12
00007e1ec07dc7a3  vmovaps [rsp+0xD0], xmm13
00007e1ec07dc7ac  vmovaps [rsp+0xE0], xmm15
00007e1ec07dc7b5  sub rsp, 0x30
00007e1ec07dc7b9  movaps [rsp], xmm14
00007e1ec07dc7be  movaps [rsp+0x10], xmm8
00007e1ec07dc7c4  movaps [rsp+0x20], xmm4
00007e1ec07dc7c9  lea rdi, [rsp]
00007e1ec07dc7cd  mov esi, 0x00
00007e1ec07dc7d2  mov rax, 0x5E00FF778530
00007e1ec07dc7dc  call rax
00007e1ec07dc7de  movaps xmm14, [rsp]
00007e1ec07dc7e3  add rsp, 0x30
00007e1ec07dc7e7  vmovaps xmm0, [rsp]
00007e1ec07dc7ec  vmovaps xmm1, [rsp+0x10]
00007e1ec07dc7f2  vmovaps xmm2, [rsp+0x20]
00007e1ec07dc7f8  vmovaps xmm3, [rsp+0x30]
00007e1ec07dc7fe  vmovaps xmm4, [rsp+0x40]
00007e1ec07dc804  vmovaps xmm5, [rsp+0x50]
00007e1ec07dc80a  vmovaps xmm6, [rsp+0x60]
00007e1ec07dc810  vmovaps xmm7, [rsp+0x70]
00007e1ec07dc816  vmovaps xmm8, [rsp+0x80]
00007e1ec07dc81f  vmovaps xmm9, [rsp+0x90]
00007e1ec07dc828  vmovaps xmm10, [rsp+0xA0]
00007e1ec07dc831  vmovaps xmm11, [rsp+0xB0]
00007e1ec07dc83a  vmovaps xmm12, [rsp+0xC0]
00007e1ec07dc843  vmovaps xmm13, [rsp+0xD0]
00007e1ec07dc84c  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dc855  add rsp, 0xF0
00007e1ec07dc85c  pop r11
00007e1ec07dc85e  pop r10
00007e1ec07dc860  pop r9
00007e1ec07dc862  pop r8
00007e1ec07dc864  pop rsi
00007e1ec07dc865  pop rdi
00007e1ec07dc866  pop rdx
00007e1ec07dc867  pop rcx
00007e1ec07dc868  pop rax
00007e1ec07dc869  add rsp, 0x08
00007e1ec07dc86d  jmp 0x00007E1EC07D9445
00007e1ec07dc872  sub rsp, 0x08
00007e1ec07dc876  push rax
00007e1ec07dc877  push rcx
00007e1ec07dc878  push rdx
00007e1ec07dc879  push rdi
00007e1ec07dc87a  push rsi
00007e1ec07dc87b  push r8
00007e1ec07dc87d  push r9
00007e1ec07dc87f  push r10
00007e1ec07dc881  push r11
00007e1ec07dc883  sub rsp, 0xF0
00007e1ec07dc88a  vmovaps [rsp], xmm0
00007e1ec07dc88f  vmovaps [rsp+0x10], xmm1
00007e1ec07dc895  vmovaps [rsp+0x20], xmm2
00007e1ec07dc89b  vmovaps [rsp+0x30], xmm3
00007e1ec07dc8a1  vmovaps [rsp+0x40], xmm5
00007e1ec07dc8a7  vmovaps [rsp+0x50], xmm6
00007e1ec07dc8ad  vmovaps [rsp+0x60], xmm7
00007e1ec07dc8b3  vmovaps [rsp+0x70], xmm8
00007e1ec07dc8b9  vmovaps [rsp+0x80], xmm9
00007e1ec07dc8c2  vmovaps [rsp+0x90], xmm10
00007e1ec07dc8cb  vmovaps [rsp+0xA0], xmm11
00007e1ec07dc8d4  vmovaps [rsp+0xB0], xmm12
00007e1ec07dc8dd  vmovaps [rsp+0xC0], xmm13
00007e1ec07dc8e6  vmovaps [rsp+0xD0], xmm14
00007e1ec07dc8ef  vmovaps [rsp+0xE0], xmm15
00007e1ec07dc8f8  sub rsp, 0x30
00007e1ec07dc8fc  movaps [rsp], xmm4
00007e1ec07dc900  movaps [rsp+0x10], xmm13
00007e1ec07dc906  movaps [rsp+0x20], xmm8
00007e1ec07dc90c  lea rdi, [rsp]
00007e1ec07dc910  mov esi, 0x00
00007e1ec07dc915  mov rax, 0x5E00FF778530
00007e1ec07dc91f  call rax
00007e1ec07dc921  movaps xmm4, [rsp]
00007e1ec07dc925  add rsp, 0x30
00007e1ec07dc929  vmovaps xmm0, [rsp]
00007e1ec07dc92e  vmovaps xmm1, [rsp+0x10]
00007e1ec07dc934  vmovaps xmm2, [rsp+0x20]
00007e1ec07dc93a  vmovaps xmm3, [rsp+0x30]
00007e1ec07dc940  vmovaps xmm5, [rsp+0x40]
00007e1ec07dc946  vmovaps xmm6, [rsp+0x50]
00007e1ec07dc94c  vmovaps xmm7, [rsp+0x60]
00007e1ec07dc952  vmovaps xmm8, [rsp+0x70]
00007e1ec07dc958  vmovaps xmm9, [rsp+0x80]
00007e1ec07dc961  vmovaps xmm10, [rsp+0x90]
00007e1ec07dc96a  vmovaps xmm11, [rsp+0xA0]
00007e1ec07dc973  vmovaps xmm12, [rsp+0xB0]
00007e1ec07dc97c  vmovaps xmm13, [rsp+0xC0]
00007e1ec07dc985  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dc98e  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dc997  add rsp, 0xF0
00007e1ec07dc99e  pop r11
00007e1ec07dc9a0  pop r10
00007e1ec07dc9a2  pop r9
00007e1ec07dc9a4  pop r8
00007e1ec07dc9a6  pop rsi
00007e1ec07dc9a7  pop rdi
00007e1ec07dc9a8  pop rdx
00007e1ec07dc9a9  pop rcx
00007e1ec07dc9aa  pop rax
00007e1ec07dc9ab  add rsp, 0x08
00007e1ec07dc9af  jmp 0x00007E1EC07D946A
00007e1ec07dc9b4  sub rsp, 0x08
00007e1ec07dc9b8  push rax
00007e1ec07dc9b9  push rcx
00007e1ec07dc9ba  push rdx
00007e1ec07dc9bb  push rdi
00007e1ec07dc9bc  push rsi
00007e1ec07dc9bd  push r8
00007e1ec07dc9bf  push r9
00007e1ec07dc9c1  push r10
00007e1ec07dc9c3  push r11
00007e1ec07dc9c5  sub rsp, 0xF0
00007e1ec07dc9cc  vmovaps [rsp], xmm0
00007e1ec07dc9d1  vmovaps [rsp+0x10], xmm1
00007e1ec07dc9d7  vmovaps [rsp+0x20], xmm2
00007e1ec07dc9dd  vmovaps [rsp+0x30], xmm3
00007e1ec07dc9e3  vmovaps [rsp+0x40], xmm4
00007e1ec07dc9e9  vmovaps [rsp+0x50], xmm5
00007e1ec07dc9ef  vmovaps [rsp+0x60], xmm6
00007e1ec07dc9f5  vmovaps [rsp+0x70], xmm7
00007e1ec07dc9fb  vmovaps [rsp+0x80], xmm8
00007e1ec07dca04  vmovaps [rsp+0x90], xmm9
00007e1ec07dca0d  vmovaps [rsp+0xA0], xmm10
00007e1ec07dca16  vmovaps [rsp+0xB0], xmm11
00007e1ec07dca1f  vmovaps [rsp+0xC0], xmm12
00007e1ec07dca28  vmovaps [rsp+0xD0], xmm14
00007e1ec07dca31  vmovaps [rsp+0xE0], xmm15
00007e1ec07dca3a  sub rsp, 0x30
00007e1ec07dca3e  movaps [rsp], xmm13
00007e1ec07dca43  movaps [rsp+0x10], xmm15
00007e1ec07dca49  movaps [rsp+0x20], xmm9
00007e1ec07dca4f  lea rdi, [rsp]
00007e1ec07dca53  mov esi, 0x00
00007e1ec07dca58  mov rax, 0x5E00FF778530
00007e1ec07dca62  call rax
00007e1ec07dca64  movaps xmm13, [rsp]
00007e1ec07dca69  add rsp, 0x30
00007e1ec07dca6d  vmovaps xmm0, [rsp]
00007e1ec07dca72  vmovaps xmm1, [rsp+0x10]
00007e1ec07dca78  vmovaps xmm2, [rsp+0x20]
00007e1ec07dca7e  vmovaps xmm3, [rsp+0x30]
00007e1ec07dca84  vmovaps xmm4, [rsp+0x40]
00007e1ec07dca8a  vmovaps xmm5, [rsp+0x50]
00007e1ec07dca90  vmovaps xmm6, [rsp+0x60]
00007e1ec07dca96  vmovaps xmm7, [rsp+0x70]
00007e1ec07dca9c  vmovaps xmm8, [rsp+0x80]
00007e1ec07dcaa5  vmovaps xmm9, [rsp+0x90]
00007e1ec07dcaae  vmovaps xmm10, [rsp+0xA0]
00007e1ec07dcab7  vmovaps xmm11, [rsp+0xB0]
00007e1ec07dcac0  vmovaps xmm12, [rsp+0xC0]
00007e1ec07dcac9  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dcad2  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dcadb  add rsp, 0xF0
00007e1ec07dcae2  pop r11
00007e1ec07dcae4  pop r10
00007e1ec07dcae6  pop r9
00007e1ec07dcae8  pop r8
00007e1ec07dcaea  pop rsi
00007e1ec07dcaeb  pop rdi
00007e1ec07dcaec  pop rdx
00007e1ec07dcaed  pop rcx
00007e1ec07dcaee  pop rax
00007e1ec07dcaef  add rsp, 0x08
00007e1ec07dcaf3  jmp 0x00007E1EC07D9485
00007e1ec07dcaf8  sub rsp, 0x08
00007e1ec07dcafc  push rax
00007e1ec07dcafd  push rcx
00007e1ec07dcafe  push rdx
00007e1ec07dcaff  push rdi
00007e1ec07dcb00  push rsi
00007e1ec07dcb01  push r8
00007e1ec07dcb03  push r9
00007e1ec07dcb05  push r10
00007e1ec07dcb07  push r11
00007e1ec07dcb09  sub rsp, 0xF0
00007e1ec07dcb10  vmovaps [rsp], xmm0
00007e1ec07dcb15  vmovaps [rsp+0x10], xmm1
00007e1ec07dcb1b  vmovaps [rsp+0x20], xmm2
00007e1ec07dcb21  vmovaps [rsp+0x30], xmm3
00007e1ec07dcb27  vmovaps [rsp+0x40], xmm4
00007e1ec07dcb2d  vmovaps [rsp+0x50], xmm5
00007e1ec07dcb33  vmovaps [rsp+0x60], xmm6
00007e1ec07dcb39  vmovaps [rsp+0x70], xmm7
00007e1ec07dcb3f  vmovaps [rsp+0x80], xmm8
00007e1ec07dcb48  vmovaps [rsp+0x90], xmm9
00007e1ec07dcb51  vmovaps [rsp+0xA0], xmm10
00007e1ec07dcb5a  vmovaps [rsp+0xB0], xmm11
00007e1ec07dcb63  vmovaps [rsp+0xC0], xmm12
00007e1ec07dcb6c  vmovaps [rsp+0xD0], xmm13
00007e1ec07dcb75  vmovaps [rsp+0xE0], xmm14
00007e1ec07dcb7e  sub rsp, 0x30
00007e1ec07dcb82  movaps [rsp], xmm15
00007e1ec07dcb87  movaps [rsp+0x10], xmm1
00007e1ec07dcb8c  movaps [rsp+0x20], xmm5
00007e1ec07dcb91  lea rdi, [rsp]
00007e1ec07dcb95  mov esi, 0x00
00007e1ec07dcb9a  mov rax, 0x5E00FF778530
00007e1ec07dcba4  call rax
00007e1ec07dcba6  movaps xmm15, [rsp]
00007e1ec07dcbab  add rsp, 0x30
00007e1ec07dcbaf  vmovaps xmm0, [rsp]
00007e1ec07dcbb4  vmovaps xmm1, [rsp+0x10]
00007e1ec07dcbba  vmovaps xmm2, [rsp+0x20]
00007e1ec07dcbc0  vmovaps xmm3, [rsp+0x30]
00007e1ec07dcbc6  vmovaps xmm4, [rsp+0x40]
00007e1ec07dcbcc  vmovaps xmm5, [rsp+0x50]
00007e1ec07dcbd2  vmovaps xmm6, [rsp+0x60]
00007e1ec07dcbd8  vmovaps xmm7, [rsp+0x70]
00007e1ec07dcbde  vmovaps xmm8, [rsp+0x80]
00007e1ec07dcbe7  vmovaps xmm9, [rsp+0x90]
00007e1ec07dcbf0  vmovaps xmm10, [rsp+0xA0]
00007e1ec07dcbf9  vmovaps xmm11, [rsp+0xB0]
00007e1ec07dcc02  vmovaps xmm12, [rsp+0xC0]
00007e1ec07dcc0b  vmovaps xmm13, [rsp+0xD0]
00007e1ec07dcc14  vmovaps xmm14, [rsp+0xE0]
00007e1ec07dcc1d  add rsp, 0xF0
00007e1ec07dcc24  pop r11
00007e1ec07dcc26  pop r10
00007e1ec07dcc28  pop r9
00007e1ec07dcc2a  pop r8
00007e1ec07dcc2c  pop rsi
00007e1ec07dcc2d  pop rdi
00007e1ec07dcc2e  pop rdx
00007e1ec07dcc2f  pop rcx
00007e1ec07dcc30  pop rax
00007e1ec07dcc31  add rsp, 0x08
00007e1ec07dcc35  jmp 0x00007E1EC07D94A0
00007e1ec07dcc3a  call 0x00007E1EC06D64F0
00007e1ec07dcc3f  jmp 0x00007E1EC07D94FB
00007e1ec07dcc44  sub rsp, 0x08
00007e1ec07dcc48  push rax
00007e1ec07dcc49  push rcx
00007e1ec07dcc4a  push rdx
00007e1ec07dcc4b  push rdi
00007e1ec07dcc4c  push rsi
00007e1ec07dcc4d  push r8
00007e1ec07dcc4f  push r9
00007e1ec07dcc51  push r10
00007e1ec07dcc53  push r11
00007e1ec07dcc55  sub rsp, 0xF0
00007e1ec07dcc5c  vmovaps [rsp], xmm0
00007e1ec07dcc61  vmovaps [rsp+0x10], xmm1
00007e1ec07dcc67  vmovaps [rsp+0x20], xmm2
00007e1ec07dcc6d  vmovaps [rsp+0x30], xmm3
00007e1ec07dcc73  vmovaps [rsp+0x40], xmm4
00007e1ec07dcc79  vmovaps [rsp+0x50], xmm5
00007e1ec07dcc7f  vmovaps [rsp+0x60], xmm6
00007e1ec07dcc85  vmovaps [rsp+0x70], xmm7
00007e1ec07dcc8b  vmovaps [rsp+0x80], xmm8
00007e1ec07dcc94  vmovaps [rsp+0x90], xmm10
00007e1ec07dcc9d  vmovaps [rsp+0xA0], xmm11
00007e1ec07dcca6  vmovaps [rsp+0xB0], xmm12
00007e1ec07dccaf  vmovaps [rsp+0xC0], xmm13
00007e1ec07dccb8  vmovaps [rsp+0xD0], xmm14
00007e1ec07dccc1  vmovaps [rsp+0xE0], xmm15
00007e1ec07dccca  sub rsp, 0x30
00007e1ec07dccce  movaps [rsp], xmm9
00007e1ec07dccd3  movaps [rsp+0x10], xmm8
00007e1ec07dccd9  movaps [rsp+0x20], xmm11
00007e1ec07dccdf  lea rdi, [rsp]
00007e1ec07dcce3  mov esi, 0x00
00007e1ec07dcce8  mov rax, 0x5E00FF778530
00007e1ec07dccf2  call rax
00007e1ec07dccf4  movaps xmm9, [rsp]
00007e1ec07dccf9  add rsp, 0x30
00007e1ec07dccfd  vmovaps xmm0, [rsp]
00007e1ec07dcd02  vmovaps xmm1, [rsp+0x10]
00007e1ec07dcd08  vmovaps xmm2, [rsp+0x20]
00007e1ec07dcd0e  vmovaps xmm3, [rsp+0x30]
00007e1ec07dcd14  vmovaps xmm4, [rsp+0x40]
00007e1ec07dcd1a  vmovaps xmm5, [rsp+0x50]
00007e1ec07dcd20  vmovaps xmm6, [rsp+0x60]
00007e1ec07dcd26  vmovaps xmm7, [rsp+0x70]
00007e1ec07dcd2c  vmovaps xmm8, [rsp+0x80]
00007e1ec07dcd35  vmovaps xmm10, [rsp+0x90]
00007e1ec07dcd3e  vmovaps xmm11, [rsp+0xA0]
00007e1ec07dcd47  vmovaps xmm12, [rsp+0xB0]
00007e1ec07dcd50  vmovaps xmm13, [rsp+0xC0]
00007e1ec07dcd59  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dcd62  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dcd6b  add rsp, 0xF0
00007e1ec07dcd72  pop r11
00007e1ec07dcd74  pop r10
00007e1ec07dcd76  pop r9
00007e1ec07dcd78  pop r8
00007e1ec07dcd7a  pop rsi
00007e1ec07dcd7b  pop rdi
00007e1ec07dcd7c  pop rdx
00007e1ec07dcd7d  pop rcx
00007e1ec07dcd7e  pop rax
00007e1ec07dcd7f  add rsp, 0x08
00007e1ec07dcd83  jmp 0x00007E1EC07D9532
00007e1ec07dcd88  sub rsp, 0x08
00007e1ec07dcd8c  push rax
00007e1ec07dcd8d  push rcx
00007e1ec07dcd8e  push rdx
00007e1ec07dcd8f  push rdi
00007e1ec07dcd90  push rsi
00007e1ec07dcd91  push r8
00007e1ec07dcd93  push r9
00007e1ec07dcd95  push r10
00007e1ec07dcd97  push r11
00007e1ec07dcd99  sub rsp, 0xF0
00007e1ec07dcda0  vmovaps [rsp], xmm0
00007e1ec07dcda5  vmovaps [rsp+0x10], xmm1
00007e1ec07dcdab  vmovaps [rsp+0x20], xmm2
00007e1ec07dcdb1  vmovaps [rsp+0x30], xmm3
00007e1ec07dcdb7  vmovaps [rsp+0x40], xmm4
00007e1ec07dcdbd  vmovaps [rsp+0x50], xmm5
00007e1ec07dcdc3  vmovaps [rsp+0x60], xmm6
00007e1ec07dcdc9  vmovaps [rsp+0x70], xmm7
00007e1ec07dcdcf  vmovaps [rsp+0x80], xmm8
00007e1ec07dcdd8  vmovaps [rsp+0x90], xmm9
00007e1ec07dcde1  vmovaps [rsp+0xA0], xmm10
00007e1ec07dcdea  vmovaps [rsp+0xB0], xmm12
00007e1ec07dcdf3  vmovaps [rsp+0xC0], xmm13
00007e1ec07dcdfc  vmovaps [rsp+0xD0], xmm14
00007e1ec07dce05  vmovaps [rsp+0xE0], xmm15
00007e1ec07dce0e  sub rsp, 0x30
00007e1ec07dce12  movaps [rsp], xmm11
00007e1ec07dce17  movaps [rsp+0x10], xmm10
00007e1ec07dce1d  movaps [rsp+0x20], xmm6
00007e1ec07dce22  lea rdi, [rsp]
00007e1ec07dce26  mov esi, 0x00
00007e1ec07dce2b  mov rax, 0x5E00FF778530
00007e1ec07dce35  call rax
00007e1ec07dce37  movaps xmm11, [rsp]
00007e1ec07dce3c  add rsp, 0x30
00007e1ec07dce40  vmovaps xmm0, [rsp]
00007e1ec07dce45  vmovaps xmm1, [rsp+0x10]
00007e1ec07dce4b  vmovaps xmm2, [rsp+0x20]
00007e1ec07dce51  vmovaps xmm3, [rsp+0x30]
00007e1ec07dce57  vmovaps xmm4, [rsp+0x40]
00007e1ec07dce5d  vmovaps xmm5, [rsp+0x50]
00007e1ec07dce63  vmovaps xmm6, [rsp+0x60]
00007e1ec07dce69  vmovaps xmm7, [rsp+0x70]
00007e1ec07dce6f  vmovaps xmm8, [rsp+0x80]
00007e1ec07dce78  vmovaps xmm9, [rsp+0x90]
00007e1ec07dce81  vmovaps xmm10, [rsp+0xA0]
00007e1ec07dce8a  vmovaps xmm12, [rsp+0xB0]
00007e1ec07dce93  vmovaps xmm13, [rsp+0xC0]
00007e1ec07dce9c  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dcea5  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dceae  add rsp, 0xF0
00007e1ec07dceb5  pop r11
00007e1ec07dceb7  pop r10
00007e1ec07dceb9  pop r9
00007e1ec07dcebb  pop r8
00007e1ec07dcebd  pop rsi
00007e1ec07dcebe  pop rdi
00007e1ec07dcebf  pop rdx
00007e1ec07dcec0  pop rcx
00007e1ec07dcec1  pop rax
00007e1ec07dcec2  add rsp, 0x08
00007e1ec07dcec6  jmp 0x00007E1EC07D954D
00007e1ec07dcecb  sub rsp, 0x08
00007e1ec07dcecf  push rax
00007e1ec07dced0  push rcx
00007e1ec07dced1  push rdx
00007e1ec07dced2  push rdi
00007e1ec07dced3  push rsi
00007e1ec07dced4  push r8
00007e1ec07dced6  push r9
00007e1ec07dced8  push r10
00007e1ec07dceda  push r11
00007e1ec07dcedc  sub rsp, 0xF0
00007e1ec07dcee3  vmovaps [rsp], xmm0
00007e1ec07dcee8  vmovaps [rsp+0x10], xmm1
00007e1ec07dceee  vmovaps [rsp+0x20], xmm2
00007e1ec07dcef4  vmovaps [rsp+0x30], xmm3
00007e1ec07dcefa  vmovaps [rsp+0x40], xmm4
00007e1ec07dcf00  vmovaps [rsp+0x50], xmm5
00007e1ec07dcf06  vmovaps [rsp+0x60], xmm6
00007e1ec07dcf0c  vmovaps [rsp+0x70], xmm7
00007e1ec07dcf12  vmovaps [rsp+0x80], xmm8
00007e1ec07dcf1b  vmovaps [rsp+0x90], xmm9
00007e1ec07dcf24  vmovaps [rsp+0xA0], xmm11
00007e1ec07dcf2d  vmovaps [rsp+0xB0], xmm12
00007e1ec07dcf36  vmovaps [rsp+0xC0], xmm13
00007e1ec07dcf3f  vmovaps [rsp+0xD0], xmm14
00007e1ec07dcf48  vmovaps [rsp+0xE0], xmm15
00007e1ec07dcf51  sub rsp, 0x30
00007e1ec07dcf55  movaps [rsp], xmm10
00007e1ec07dcf5a  movaps [rsp+0x10], xmm14
00007e1ec07dcf60  movaps [rsp+0x20], xmm4
00007e1ec07dcf65  lea rdi, [rsp]
00007e1ec07dcf69  mov esi, 0x00
00007e1ec07dcf6e  mov rax, 0x5E00FF778530
00007e1ec07dcf78  call rax
00007e1ec07dcf7a  movaps xmm10, [rsp]
00007e1ec07dcf7f  add rsp, 0x30
00007e1ec07dcf83  vmovaps xmm0, [rsp]
00007e1ec07dcf88  vmovaps xmm1, [rsp+0x10]
00007e1ec07dcf8e  vmovaps xmm2, [rsp+0x20]
00007e1ec07dcf94  vmovaps xmm3, [rsp+0x30]
00007e1ec07dcf9a  vmovaps xmm4, [rsp+0x40]
00007e1ec07dcfa0  vmovaps xmm5, [rsp+0x50]
00007e1ec07dcfa6  vmovaps xmm6, [rsp+0x60]
00007e1ec07dcfac  vmovaps xmm7, [rsp+0x70]
00007e1ec07dcfb2  vmovaps xmm8, [rsp+0x80]
00007e1ec07dcfbb  vmovaps xmm9, [rsp+0x90]
00007e1ec07dcfc4  vmovaps xmm11, [rsp+0xA0]
00007e1ec07dcfcd  vmovaps xmm12, [rsp+0xB0]
00007e1ec07dcfd6  vmovaps xmm13, [rsp+0xC0]
00007e1ec07dcfdf  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dcfe8  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dcff1  add rsp, 0xF0
00007e1ec07dcff8  pop r11
00007e1ec07dcffa  pop r10
00007e1ec07dcffc  pop r9
00007e1ec07dcffe  pop r8
00007e1ec07dd000  pop rsi
00007e1ec07dd001  pop rdi
00007e1ec07dd002  pop rdx
00007e1ec07dd003  pop rcx
00007e1ec07dd004  pop rax
00007e1ec07dd005  add rsp, 0x08
00007e1ec07dd009  jmp 0x00007E1EC07D9568
00007e1ec07dd00e  sub rsp, 0x08
00007e1ec07dd012  push rax
00007e1ec07dd013  push rcx
00007e1ec07dd014  push rdx
00007e1ec07dd015  push rdi
00007e1ec07dd016  push rsi
00007e1ec07dd017  push r8
00007e1ec07dd019  push r9
00007e1ec07dd01b  push r10
00007e1ec07dd01d  push r11
00007e1ec07dd01f  sub rsp, 0xF0
00007e1ec07dd026  vmovaps [rsp], xmm0
00007e1ec07dd02b  vmovaps [rsp+0x10], xmm1
00007e1ec07dd031  vmovaps [rsp+0x20], xmm2
00007e1ec07dd037  vmovaps [rsp+0x30], xmm3
00007e1ec07dd03d  vmovaps [rsp+0x40], xmm4
00007e1ec07dd043  vmovaps [rsp+0x50], xmm5
00007e1ec07dd049  vmovaps [rsp+0x60], xmm6
00007e1ec07dd04f  vmovaps [rsp+0x70], xmm7
00007e1ec07dd055  vmovaps [rsp+0x80], xmm9
00007e1ec07dd05e  vmovaps [rsp+0x90], xmm10
00007e1ec07dd067  vmovaps [rsp+0xA0], xmm11
00007e1ec07dd070  vmovaps [rsp+0xB0], xmm12
00007e1ec07dd079  vmovaps [rsp+0xC0], xmm13
00007e1ec07dd082  vmovaps [rsp+0xD0], xmm14
00007e1ec07dd08b  vmovaps [rsp+0xE0], xmm15
00007e1ec07dd094  sub rsp, 0x30
00007e1ec07dd098  movaps [rsp], xmm8
00007e1ec07dd09d  movaps [rsp+0x10], xmm1
00007e1ec07dd0a2  movaps [rsp+0x20], xmm14
00007e1ec07dd0a8  lea rdi, [rsp]
00007e1ec07dd0ac  mov esi, 0x00
00007e1ec07dd0b1  mov rax, 0x5E00FF778530
00007e1ec07dd0bb  call rax
00007e1ec07dd0bd  movaps xmm8, [rsp]
00007e1ec07dd0c2  add rsp, 0x30
00007e1ec07dd0c6  vmovaps xmm0, [rsp]
00007e1ec07dd0cb  vmovaps xmm1, [rsp+0x10]
00007e1ec07dd0d1  vmovaps xmm2, [rsp+0x20]
00007e1ec07dd0d7  vmovaps xmm3, [rsp+0x30]
00007e1ec07dd0dd  vmovaps xmm4, [rsp+0x40]
00007e1ec07dd0e3  vmovaps xmm5, [rsp+0x50]
00007e1ec07dd0e9  vmovaps xmm6, [rsp+0x60]
00007e1ec07dd0ef  vmovaps xmm7, [rsp+0x70]
00007e1ec07dd0f5  vmovaps xmm9, [rsp+0x80]
00007e1ec07dd0fe  vmovaps xmm10, [rsp+0x90]
00007e1ec07dd107  vmovaps xmm11, [rsp+0xA0]
00007e1ec07dd110  vmovaps xmm12, [rsp+0xB0]
00007e1ec07dd119  vmovaps xmm13, [rsp+0xC0]
00007e1ec07dd122  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dd12b  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dd134  add rsp, 0xF0
00007e1ec07dd13b  pop r11
00007e1ec07dd13d  pop r10
00007e1ec07dd13f  pop r9
00007e1ec07dd141  pop r8
00007e1ec07dd143  pop rsi
00007e1ec07dd144  pop rdi
00007e1ec07dd145  pop rdx
00007e1ec07dd146  pop rcx
00007e1ec07dd147  pop rax
00007e1ec07dd148  add rsp, 0x08
00007e1ec07dd14c  jmp 0x00007E1EC07D958E
00007e1ec07dd151  sub rsp, 0x08
00007e1ec07dd155  push rax
00007e1ec07dd156  push rcx
00007e1ec07dd157  push rdx
00007e1ec07dd158  push rdi
00007e1ec07dd159  push rsi
00007e1ec07dd15a  push r8
00007e1ec07dd15c  push r9
00007e1ec07dd15e  push r10
00007e1ec07dd160  push r11
00007e1ec07dd162  sub rsp, 0xF0
00007e1ec07dd169  vmovaps [rsp], xmm0
00007e1ec07dd16e  vmovaps [rsp+0x10], xmm1
00007e1ec07dd174  vmovaps [rsp+0x20], xmm2
00007e1ec07dd17a  vmovaps [rsp+0x30], xmm3
00007e1ec07dd180  vmovaps [rsp+0x40], xmm4
00007e1ec07dd186  vmovaps [rsp+0x50], xmm5
00007e1ec07dd18c  vmovaps [rsp+0x60], xmm7
00007e1ec07dd192  vmovaps [rsp+0x70], xmm8
00007e1ec07dd198  vmovaps [rsp+0x80], xmm9
00007e1ec07dd1a1  vmovaps [rsp+0x90], xmm10
00007e1ec07dd1aa  vmovaps [rsp+0xA0], xmm11
00007e1ec07dd1b3  vmovaps [rsp+0xB0], xmm12
00007e1ec07dd1bc  vmovaps [rsp+0xC0], xmm13
00007e1ec07dd1c5  vmovaps [rsp+0xD0], xmm14
00007e1ec07dd1ce  vmovaps [rsp+0xE0], xmm15
00007e1ec07dd1d7  sub rsp, 0x30
00007e1ec07dd1db  movaps [rsp], xmm6
00007e1ec07dd1df  movaps [rsp+0x10], xmm1
00007e1ec07dd1e4  movaps [rsp+0x20], xmm14
00007e1ec07dd1ea  lea rdi, [rsp]
00007e1ec07dd1ee  mov esi, 0x00
00007e1ec07dd1f3  mov rax, 0x5E00FF778530
00007e1ec07dd1fd  call rax
00007e1ec07dd1ff  movaps xmm6, [rsp]
00007e1ec07dd203  add rsp, 0x30
00007e1ec07dd207  vmovaps xmm0, [rsp]
00007e1ec07dd20c  vmovaps xmm1, [rsp+0x10]
00007e1ec07dd212  vmovaps xmm2, [rsp+0x20]
00007e1ec07dd218  vmovaps xmm3, [rsp+0x30]
00007e1ec07dd21e  vmovaps xmm4, [rsp+0x40]
00007e1ec07dd224  vmovaps xmm5, [rsp+0x50]
00007e1ec07dd22a  vmovaps xmm7, [rsp+0x60]
00007e1ec07dd230  vmovaps xmm8, [rsp+0x70]
00007e1ec07dd236  vmovaps xmm9, [rsp+0x80]
00007e1ec07dd23f  vmovaps xmm10, [rsp+0x90]
00007e1ec07dd248  vmovaps xmm11, [rsp+0xA0]
00007e1ec07dd251  vmovaps xmm12, [rsp+0xB0]
00007e1ec07dd25a  vmovaps xmm13, [rsp+0xC0]
00007e1ec07dd263  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dd26c  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dd275  add rsp, 0xF0
00007e1ec07dd27c  pop r11
00007e1ec07dd27e  pop r10
00007e1ec07dd280  pop r9
00007e1ec07dd282  pop r8
00007e1ec07dd284  pop rsi
00007e1ec07dd285  pop rdi
00007e1ec07dd286  pop rdx
00007e1ec07dd287  pop rcx
00007e1ec07dd288  pop rax
00007e1ec07dd289  add rsp, 0x08
00007e1ec07dd28d  jmp 0x00007E1EC07D95BA
00007e1ec07dd292  sub rsp, 0x08
00007e1ec07dd296  push rax
00007e1ec07dd297  push rcx
00007e1ec07dd298  push rdx
00007e1ec07dd299  push rdi
00007e1ec07dd29a  push rsi
00007e1ec07dd29b  push r8
00007e1ec07dd29d  push r9
00007e1ec07dd29f  push r10
00007e1ec07dd2a1  push r11
00007e1ec07dd2a3  sub rsp, 0xF0
00007e1ec07dd2aa  vmovaps [rsp], xmm0
00007e1ec07dd2af  vmovaps [rsp+0x10], xmm1
00007e1ec07dd2b5  vmovaps [rsp+0x20], xmm2
00007e1ec07dd2bb  vmovaps [rsp+0x30], xmm3
00007e1ec07dd2c1  vmovaps [rsp+0x40], xmm4
00007e1ec07dd2c7  vmovaps [rsp+0x50], xmm5
00007e1ec07dd2cd  vmovaps [rsp+0x60], xmm6
00007e1ec07dd2d3  vmovaps [rsp+0x70], xmm7
00007e1ec07dd2d9  vmovaps [rsp+0x80], xmm8
00007e1ec07dd2e2  vmovaps [rsp+0x90], xmm9
00007e1ec07dd2eb  vmovaps [rsp+0xA0], xmm10
00007e1ec07dd2f4  vmovaps [rsp+0xB0], xmm11
00007e1ec07dd2fd  vmovaps [rsp+0xC0], xmm12
00007e1ec07dd306  vmovaps [rsp+0xD0], xmm13
00007e1ec07dd30f  vmovaps [rsp+0xE0], xmm15
00007e1ec07dd318  sub rsp, 0x30
00007e1ec07dd31c  movaps [rsp], xmm14
00007e1ec07dd321  movaps [rsp+0x10], xmm12
00007e1ec07dd327  movaps [rsp+0x20], xmm1
00007e1ec07dd32c  lea rdi, [rsp]
00007e1ec07dd330  mov esi, 0x00
00007e1ec07dd335  mov rax, 0x5E00FF778530
00007e1ec07dd33f  call rax
00007e1ec07dd341  movaps xmm14, [rsp]
00007e1ec07dd346  add rsp, 0x30
00007e1ec07dd34a  vmovaps xmm0, [rsp]
00007e1ec07dd34f  vmovaps xmm1, [rsp+0x10]
00007e1ec07dd355  vmovaps xmm2, [rsp+0x20]
00007e1ec07dd35b  vmovaps xmm3, [rsp+0x30]
00007e1ec07dd361  vmovaps xmm4, [rsp+0x40]
00007e1ec07dd367  vmovaps xmm5, [rsp+0x50]
00007e1ec07dd36d  vmovaps xmm6, [rsp+0x60]
00007e1ec07dd373  vmovaps xmm7, [rsp+0x70]
00007e1ec07dd379  vmovaps xmm8, [rsp+0x80]
00007e1ec07dd382  vmovaps xmm9, [rsp+0x90]
00007e1ec07dd38b  vmovaps xmm10, [rsp+0xA0]
00007e1ec07dd394  vmovaps xmm11, [rsp+0xB0]
00007e1ec07dd39d  vmovaps xmm12, [rsp+0xC0]
00007e1ec07dd3a6  vmovaps xmm13, [rsp+0xD0]
00007e1ec07dd3af  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dd3b8  add rsp, 0xF0
00007e1ec07dd3bf  pop r11
00007e1ec07dd3c1  pop r10
00007e1ec07dd3c3  pop r9
00007e1ec07dd3c5  pop r8
00007e1ec07dd3c7  pop rsi
00007e1ec07dd3c8  pop rdi
00007e1ec07dd3c9  pop rdx
00007e1ec07dd3ca  pop rcx
00007e1ec07dd3cb  pop rax
00007e1ec07dd3cc  add rsp, 0x08
00007e1ec07dd3d0  jmp 0x00007E1EC07D95E0
00007e1ec07dd3d5  sub rsp, 0x08
00007e1ec07dd3d9  push rax
00007e1ec07dd3da  push rcx
00007e1ec07dd3db  push rdx
00007e1ec07dd3dc  push rdi
00007e1ec07dd3dd  push rsi
00007e1ec07dd3de  push r8
00007e1ec07dd3e0  push r9
00007e1ec07dd3e2  push r10
00007e1ec07dd3e4  push r11
00007e1ec07dd3e6  sub rsp, 0xF0
00007e1ec07dd3ed  vmovaps [rsp], xmm0
00007e1ec07dd3f2  vmovaps [rsp+0x10], xmm2
00007e1ec07dd3f8  vmovaps [rsp+0x20], xmm3
00007e1ec07dd3fe  vmovaps [rsp+0x30], xmm4
00007e1ec07dd404  vmovaps [rsp+0x40], xmm5
00007e1ec07dd40a  vmovaps [rsp+0x50], xmm6
00007e1ec07dd410  vmovaps [rsp+0x60], xmm7
00007e1ec07dd416  vmovaps [rsp+0x70], xmm8
00007e1ec07dd41c  vmovaps [rsp+0x80], xmm9
00007e1ec07dd425  vmovaps [rsp+0x90], xmm10
00007e1ec07dd42e  vmovaps [rsp+0xA0], xmm11
00007e1ec07dd437  vmovaps [rsp+0xB0], xmm12
00007e1ec07dd440  vmovaps [rsp+0xC0], xmm13
00007e1ec07dd449  vmovaps [rsp+0xD0], xmm14
00007e1ec07dd452  vmovaps [rsp+0xE0], xmm15
00007e1ec07dd45b  sub rsp, 0x30
00007e1ec07dd45f  movaps [rsp], xmm1
00007e1ec07dd463  movaps [rsp+0x10], xmm13
00007e1ec07dd469  movaps [rsp+0x20], xmm9
00007e1ec07dd46f  lea rdi, [rsp]
00007e1ec07dd473  mov esi, 0x00
00007e1ec07dd478  mov rax, 0x5E00FF778530
00007e1ec07dd482  call rax
00007e1ec07dd484  movaps xmm1, [rsp]
00007e1ec07dd488  add rsp, 0x30
00007e1ec07dd48c  vmovaps xmm0, [rsp]
00007e1ec07dd491  vmovaps xmm2, [rsp+0x10]
00007e1ec07dd497  vmovaps xmm3, [rsp+0x20]
00007e1ec07dd49d  vmovaps xmm4, [rsp+0x30]
00007e1ec07dd4a3  vmovaps xmm5, [rsp+0x40]
00007e1ec07dd4a9  vmovaps xmm6, [rsp+0x50]
00007e1ec07dd4af  vmovaps xmm7, [rsp+0x60]
00007e1ec07dd4b5  vmovaps xmm8, [rsp+0x70]
00007e1ec07dd4bb  vmovaps xmm9, [rsp+0x80]
00007e1ec07dd4c4  vmovaps xmm10, [rsp+0x90]
00007e1ec07dd4cd  vmovaps xmm11, [rsp+0xA0]
00007e1ec07dd4d6  vmovaps xmm12, [rsp+0xB0]
00007e1ec07dd4df  vmovaps xmm13, [rsp+0xC0]
00007e1ec07dd4e8  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dd4f1  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dd4fa  add rsp, 0xF0
00007e1ec07dd501  pop r11
00007e1ec07dd503  pop r10
00007e1ec07dd505  pop r9
00007e1ec07dd507  pop r8
00007e1ec07dd509  pop rsi
00007e1ec07dd50a  pop rdi
00007e1ec07dd50b  pop rdx
00007e1ec07dd50c  pop rcx
00007e1ec07dd50d  pop rax
00007e1ec07dd50e  add rsp, 0x08
00007e1ec07dd512  jmp 0x00007E1EC07D95FA
00007e1ec07dd517  sub rsp, 0x08
00007e1ec07dd51b  push rax
00007e1ec07dd51c  push rcx
00007e1ec07dd51d  push rdx
00007e1ec07dd51e  push rdi
00007e1ec07dd51f  push rsi
00007e1ec07dd520  push r8
00007e1ec07dd522  push r9
00007e1ec07dd524  push r10
00007e1ec07dd526  push r11
00007e1ec07dd528  sub rsp, 0xF0
00007e1ec07dd52f  vmovaps [rsp], xmm0
00007e1ec07dd534  vmovaps [rsp+0x10], xmm1
00007e1ec07dd53a  vmovaps [rsp+0x20], xmm2
00007e1ec07dd540  vmovaps [rsp+0x30], xmm3
00007e1ec07dd546  vmovaps [rsp+0x40], xmm4
00007e1ec07dd54c  vmovaps [rsp+0x50], xmm5
00007e1ec07dd552  vmovaps [rsp+0x60], xmm6
00007e1ec07dd558  vmovaps [rsp+0x70], xmm7
00007e1ec07dd55e  vmovaps [rsp+0x80], xmm8
00007e1ec07dd567  vmovaps [rsp+0x90], xmm9
00007e1ec07dd570  vmovaps [rsp+0xA0], xmm10
00007e1ec07dd579  vmovaps [rsp+0xB0], xmm11
00007e1ec07dd582  vmovaps [rsp+0xC0], xmm13
00007e1ec07dd58b  vmovaps [rsp+0xD0], xmm14
00007e1ec07dd594  vmovaps [rsp+0xE0], xmm15
00007e1ec07dd59d  sub rsp, 0x30
00007e1ec07dd5a1  movaps [rsp], xmm12
00007e1ec07dd5a6  movaps [rsp+0x10], xmm7
00007e1ec07dd5ab  movaps [rsp+0x20], xmm13
00007e1ec07dd5b1  lea rdi, [rsp]
00007e1ec07dd5b5  mov esi, 0x00
00007e1ec07dd5ba  mov rax, 0x5E00FF778530
00007e1ec07dd5c4  call rax
00007e1ec07dd5c6  movaps xmm12, [rsp]
00007e1ec07dd5cb  add rsp, 0x30
00007e1ec07dd5cf  vmovaps xmm0, [rsp]
00007e1ec07dd5d4  vmovaps xmm1, [rsp+0x10]
00007e1ec07dd5da  vmovaps xmm2, [rsp+0x20]
00007e1ec07dd5e0  vmovaps xmm3, [rsp+0x30]
00007e1ec07dd5e6  vmovaps xmm4, [rsp+0x40]
00007e1ec07dd5ec  vmovaps xmm5, [rsp+0x50]
00007e1ec07dd5f2  vmovaps xmm6, [rsp+0x60]
00007e1ec07dd5f8  vmovaps xmm7, [rsp+0x70]
00007e1ec07dd5fe  vmovaps xmm8, [rsp+0x80]
00007e1ec07dd607  vmovaps xmm9, [rsp+0x90]
00007e1ec07dd610  vmovaps xmm10, [rsp+0xA0]
00007e1ec07dd619  vmovaps xmm11, [rsp+0xB0]
00007e1ec07dd622  vmovaps xmm13, [rsp+0xC0]
00007e1ec07dd62b  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dd634  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dd63d  add rsp, 0xF0
00007e1ec07dd644  pop r11
00007e1ec07dd646  pop r10
00007e1ec07dd648  pop r9
00007e1ec07dd64a  pop r8
00007e1ec07dd64c  pop rsi
00007e1ec07dd64d  pop rdi
00007e1ec07dd64e  pop rdx
00007e1ec07dd64f  pop rcx
00007e1ec07dd650  pop rax
00007e1ec07dd651  add rsp, 0x08
00007e1ec07dd655  jmp 0x00007E1EC07D9621
00007e1ec07dd65a  sub rsp, 0x08
00007e1ec07dd65e  push rax
00007e1ec07dd65f  push rcx
00007e1ec07dd660  push rdx
00007e1ec07dd661  push rdi
00007e1ec07dd662  push rsi
00007e1ec07dd663  push r8
00007e1ec07dd665  push r9
00007e1ec07dd667  push r10
00007e1ec07dd669  push r11
00007e1ec07dd66b  sub rsp, 0xF0
00007e1ec07dd672  vmovaps [rsp], xmm0
00007e1ec07dd677  vmovaps [rsp+0x10], xmm1
00007e1ec07dd67d  vmovaps [rsp+0x20], xmm2
00007e1ec07dd683  vmovaps [rsp+0x30], xmm3
00007e1ec07dd689  vmovaps [rsp+0x40], xmm4
00007e1ec07dd68f  vmovaps [rsp+0x50], xmm5
00007e1ec07dd695  vmovaps [rsp+0x60], xmm6
00007e1ec07dd69b  vmovaps [rsp+0x70], xmm7
00007e1ec07dd6a1  vmovaps [rsp+0x80], xmm8
00007e1ec07dd6aa  vmovaps [rsp+0x90], xmm9
00007e1ec07dd6b3  vmovaps [rsp+0xA0], xmm10
00007e1ec07dd6bc  vmovaps [rsp+0xB0], xmm11
00007e1ec07dd6c5  vmovaps [rsp+0xC0], xmm12
00007e1ec07dd6ce  vmovaps [rsp+0xD0], xmm14
00007e1ec07dd6d7  vmovaps [rsp+0xE0], xmm15
00007e1ec07dd6e0  sub rsp, 0x30
00007e1ec07dd6e4  movaps [rsp], xmm13
00007e1ec07dd6e9  movaps [rsp+0x10], xmm15
00007e1ec07dd6ef  movaps [rsp+0x20], xmm8
00007e1ec07dd6f5  lea rdi, [rsp]
00007e1ec07dd6f9  mov esi, 0x00
00007e1ec07dd6fe  mov rax, 0x5E00FF778530
00007e1ec07dd708  call rax
00007e1ec07dd70a  movaps xmm13, [rsp]
00007e1ec07dd70f  add rsp, 0x30
00007e1ec07dd713  vmovaps xmm0, [rsp]
00007e1ec07dd718  vmovaps xmm1, [rsp+0x10]
00007e1ec07dd71e  vmovaps xmm2, [rsp+0x20]
00007e1ec07dd724  vmovaps xmm3, [rsp+0x30]
00007e1ec07dd72a  vmovaps xmm4, [rsp+0x40]
00007e1ec07dd730  vmovaps xmm5, [rsp+0x50]
00007e1ec07dd736  vmovaps xmm6, [rsp+0x60]
00007e1ec07dd73c  vmovaps xmm7, [rsp+0x70]
00007e1ec07dd742  vmovaps xmm8, [rsp+0x80]
00007e1ec07dd74b  vmovaps xmm9, [rsp+0x90]
00007e1ec07dd754  vmovaps xmm10, [rsp+0xA0]
00007e1ec07dd75d  vmovaps xmm11, [rsp+0xB0]
00007e1ec07dd766  vmovaps xmm12, [rsp+0xC0]
00007e1ec07dd76f  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dd778  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dd781  add rsp, 0xF0
00007e1ec07dd788  pop r11
00007e1ec07dd78a  pop r10
00007e1ec07dd78c  pop r9
00007e1ec07dd78e  pop r8
00007e1ec07dd790  pop rsi
00007e1ec07dd791  pop rdi
00007e1ec07dd792  pop rdx
00007e1ec07dd793  pop rcx
00007e1ec07dd794  pop rax
00007e1ec07dd795  add rsp, 0x08
00007e1ec07dd799  jmp 0x00007E1EC07D963C
00007e1ec07dd79e  sub rsp, 0x08
00007e1ec07dd7a2  push rax
00007e1ec07dd7a3  push rcx
00007e1ec07dd7a4  push rdx
00007e1ec07dd7a5  push rdi
00007e1ec07dd7a6  push rsi
00007e1ec07dd7a7  push r8
00007e1ec07dd7a9  push r9
00007e1ec07dd7ab  push r10
00007e1ec07dd7ad  push r11
00007e1ec07dd7af  sub rsp, 0xF0
00007e1ec07dd7b6  vmovaps [rsp], xmm0
00007e1ec07dd7bb  vmovaps [rsp+0x10], xmm1
00007e1ec07dd7c1  vmovaps [rsp+0x20], xmm2
00007e1ec07dd7c7  vmovaps [rsp+0x30], xmm3
00007e1ec07dd7cd  vmovaps [rsp+0x40], xmm4
00007e1ec07dd7d3  vmovaps [rsp+0x50], xmm5
00007e1ec07dd7d9  vmovaps [rsp+0x60], xmm6
00007e1ec07dd7df  vmovaps [rsp+0x70], xmm7
00007e1ec07dd7e5  vmovaps [rsp+0x80], xmm9
00007e1ec07dd7ee  vmovaps [rsp+0x90], xmm10
00007e1ec07dd7f7  vmovaps [rsp+0xA0], xmm11
00007e1ec07dd800  vmovaps [rsp+0xB0], xmm12
00007e1ec07dd809  vmovaps [rsp+0xC0], xmm13
00007e1ec07dd812  vmovaps [rsp+0xD0], xmm14
00007e1ec07dd81b  vmovaps [rsp+0xE0], xmm15
00007e1ec07dd824  sub rsp, 0x30
00007e1ec07dd828  movaps [rsp], xmm8
00007e1ec07dd82d  movaps [rsp+0x10], xmm15
00007e1ec07dd833  movaps [rsp+0x20], xmm9
00007e1ec07dd839  lea rdi, [rsp]
00007e1ec07dd83d  mov esi, 0x00
00007e1ec07dd842  mov rax, 0x5E00FF778530
00007e1ec07dd84c  call rax
00007e1ec07dd84e  movaps xmm8, [rsp]
00007e1ec07dd853  add rsp, 0x30
00007e1ec07dd857  vmovaps xmm0, [rsp]
00007e1ec07dd85c  vmovaps xmm1, [rsp+0x10]
00007e1ec07dd862  vmovaps xmm2, [rsp+0x20]
00007e1ec07dd868  vmovaps xmm3, [rsp+0x30]
00007e1ec07dd86e  vmovaps xmm4, [rsp+0x40]
00007e1ec07dd874  vmovaps xmm5, [rsp+0x50]
00007e1ec07dd87a  vmovaps xmm6, [rsp+0x60]
00007e1ec07dd880  vmovaps xmm7, [rsp+0x70]
00007e1ec07dd886  vmovaps xmm9, [rsp+0x80]
00007e1ec07dd88f  vmovaps xmm10, [rsp+0x90]
00007e1ec07dd898  vmovaps xmm11, [rsp+0xA0]
00007e1ec07dd8a1  vmovaps xmm12, [rsp+0xB0]
00007e1ec07dd8aa  vmovaps xmm13, [rsp+0xC0]
00007e1ec07dd8b3  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dd8bc  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dd8c5  add rsp, 0xF0
00007e1ec07dd8cc  pop r11
00007e1ec07dd8ce  pop r10
00007e1ec07dd8d0  pop r9
00007e1ec07dd8d2  pop r8
00007e1ec07dd8d4  pop rsi
00007e1ec07dd8d5  pop rdi
00007e1ec07dd8d6  pop rdx
00007e1ec07dd8d7  pop rcx
00007e1ec07dd8d8  pop rax
00007e1ec07dd8d9  add rsp, 0x08
00007e1ec07dd8dd  jmp 0x00007E1EC07D966A
00007e1ec07dd8e2  sub rsp, 0x08
00007e1ec07dd8e6  push rax
00007e1ec07dd8e7  push rcx
00007e1ec07dd8e8  push rdx
00007e1ec07dd8e9  push rdi
00007e1ec07dd8ea  push rsi
00007e1ec07dd8eb  push r8
00007e1ec07dd8ed  push r9
00007e1ec07dd8ef  push r10
00007e1ec07dd8f1  push r11
00007e1ec07dd8f3  sub rsp, 0xF0
00007e1ec07dd8fa  vmovaps [rsp], xmm0
00007e1ec07dd8ff  vmovaps [rsp+0x10], xmm1
00007e1ec07dd905  vmovaps [rsp+0x20], xmm2
00007e1ec07dd90b  vmovaps [rsp+0x30], xmm3
00007e1ec07dd911  vmovaps [rsp+0x40], xmm4
00007e1ec07dd917  vmovaps [rsp+0x50], xmm5
00007e1ec07dd91d  vmovaps [rsp+0x60], xmm6
00007e1ec07dd923  vmovaps [rsp+0x70], xmm7
00007e1ec07dd929  vmovaps [rsp+0x80], xmm8
00007e1ec07dd932  vmovaps [rsp+0x90], xmm9
00007e1ec07dd93b  vmovaps [rsp+0xA0], xmm10
00007e1ec07dd944  vmovaps [rsp+0xB0], xmm11
00007e1ec07dd94d  vmovaps [rsp+0xC0], xmm12
00007e1ec07dd956  vmovaps [rsp+0xD0], xmm13
00007e1ec07dd95f  vmovaps [rsp+0xE0], xmm14
00007e1ec07dd968  sub rsp, 0x30
00007e1ec07dd96c  movaps [rsp], xmm15
00007e1ec07dd971  movaps [rsp+0x10], xmm11
00007e1ec07dd977  movaps [rsp+0x20], xmm6
00007e1ec07dd97c  lea rdi, [rsp]
00007e1ec07dd980  mov esi, 0x00
00007e1ec07dd985  mov rax, 0x5E00FF778530
00007e1ec07dd98f  call rax
00007e1ec07dd991  movaps xmm15, [rsp]
00007e1ec07dd996  add rsp, 0x30
00007e1ec07dd99a  vmovaps xmm0, [rsp]
00007e1ec07dd99f  vmovaps xmm1, [rsp+0x10]
00007e1ec07dd9a5  vmovaps xmm2, [rsp+0x20]
00007e1ec07dd9ab  vmovaps xmm3, [rsp+0x30]
00007e1ec07dd9b1  vmovaps xmm4, [rsp+0x40]
00007e1ec07dd9b7  vmovaps xmm5, [rsp+0x50]
00007e1ec07dd9bd  vmovaps xmm6, [rsp+0x60]
00007e1ec07dd9c3  vmovaps xmm7, [rsp+0x70]
00007e1ec07dd9c9  vmovaps xmm8, [rsp+0x80]
00007e1ec07dd9d2  vmovaps xmm9, [rsp+0x90]
00007e1ec07dd9db  vmovaps xmm10, [rsp+0xA0]
00007e1ec07dd9e4  vmovaps xmm11, [rsp+0xB0]
00007e1ec07dd9ed  vmovaps xmm12, [rsp+0xC0]
00007e1ec07dd9f6  vmovaps xmm13, [rsp+0xD0]
00007e1ec07dd9ff  vmovaps xmm14, [rsp+0xE0]
00007e1ec07dda08  add rsp, 0xF0
00007e1ec07dda0f  pop r11
00007e1ec07dda11  pop r10
00007e1ec07dda13  pop r9
00007e1ec07dda15  pop r8
00007e1ec07dda17  pop rsi
00007e1ec07dda18  pop rdi
00007e1ec07dda19  pop rdx
00007e1ec07dda1a  pop rcx
00007e1ec07dda1b  pop rax
00007e1ec07dda1c  add rsp, 0x08
00007e1ec07dda20  jmp 0x00007E1EC07D9685
00007e1ec07dda25  sub rsp, 0x08
00007e1ec07dda29  push rax
00007e1ec07dda2a  push rcx
00007e1ec07dda2b  push rdx
00007e1ec07dda2c  push rdi
00007e1ec07dda2d  push rsi
00007e1ec07dda2e  push r8
00007e1ec07dda30  push r9
00007e1ec07dda32  push r10
00007e1ec07dda34  push r11
00007e1ec07dda36  sub rsp, 0xF0
00007e1ec07dda3d  vmovaps [rsp], xmm0
00007e1ec07dda42  vmovaps [rsp+0x10], xmm1
00007e1ec07dda48  vmovaps [rsp+0x20], xmm2
00007e1ec07dda4e  vmovaps [rsp+0x30], xmm3
00007e1ec07dda54  vmovaps [rsp+0x40], xmm4
00007e1ec07dda5a  vmovaps [rsp+0x50], xmm5
00007e1ec07dda60  vmovaps [rsp+0x60], xmm6
00007e1ec07dda66  vmovaps [rsp+0x70], xmm8
00007e1ec07dda6c  vmovaps [rsp+0x80], xmm9
00007e1ec07dda75  vmovaps [rsp+0x90], xmm10
00007e1ec07dda7e  vmovaps [rsp+0xA0], xmm11
00007e1ec07dda87  vmovaps [rsp+0xB0], xmm12
00007e1ec07dda90  vmovaps [rsp+0xC0], xmm13
00007e1ec07dda99  vmovaps [rsp+0xD0], xmm14
00007e1ec07ddaa2  vmovaps [rsp+0xE0], xmm15
00007e1ec07ddaab  sub rsp, 0x30
00007e1ec07ddaaf  movaps [rsp], xmm7
00007e1ec07ddab3  movaps [rsp+0x10], xmm11
00007e1ec07ddab9  movaps [rsp+0x20], xmm9
00007e1ec07ddabf  lea rdi, [rsp]
00007e1ec07ddac3  mov esi, 0x00
00007e1ec07ddac8  mov rax, 0x5E00FF778530
00007e1ec07ddad2  call rax
00007e1ec07ddad4  movaps xmm7, [rsp]
00007e1ec07ddad8  add rsp, 0x30
00007e1ec07ddadc  vmovaps xmm0, [rsp]
00007e1ec07ddae1  vmovaps xmm1, [rsp+0x10]
00007e1ec07ddae7  vmovaps xmm2, [rsp+0x20]
00007e1ec07ddaed  vmovaps xmm3, [rsp+0x30]
00007e1ec07ddaf3  vmovaps xmm4, [rsp+0x40]
00007e1ec07ddaf9  vmovaps xmm5, [rsp+0x50]
00007e1ec07ddaff  vmovaps xmm6, [rsp+0x60]
00007e1ec07ddb05  vmovaps xmm8, [rsp+0x70]
00007e1ec07ddb0b  vmovaps xmm9, [rsp+0x80]
00007e1ec07ddb14  vmovaps xmm10, [rsp+0x90]
00007e1ec07ddb1d  vmovaps xmm11, [rsp+0xA0]
00007e1ec07ddb26  vmovaps xmm12, [rsp+0xB0]
00007e1ec07ddb2f  vmovaps xmm13, [rsp+0xC0]
00007e1ec07ddb38  vmovaps xmm14, [rsp+0xD0]
00007e1ec07ddb41  vmovaps xmm15, [rsp+0xE0]
00007e1ec07ddb4a  add rsp, 0xF0
00007e1ec07ddb51  pop r11
00007e1ec07ddb53  pop r10
00007e1ec07ddb55  pop r9
00007e1ec07ddb57  pop r8
00007e1ec07ddb59  pop rsi
00007e1ec07ddb5a  pop rdi
00007e1ec07ddb5b  pop rdx
00007e1ec07ddb5c  pop rcx
00007e1ec07ddb5d  pop rax
00007e1ec07ddb5e  add rsp, 0x08
00007e1ec07ddb62  jmp 0x00007E1EC07D96B2
00007e1ec07ddb67  sub rsp, 0x08
00007e1ec07ddb6b  push rax
00007e1ec07ddb6c  push rcx
00007e1ec07ddb6d  push rdx
00007e1ec07ddb6e  push rdi
00007e1ec07ddb6f  push rsi
00007e1ec07ddb70  push r8
00007e1ec07ddb72  push r9
00007e1ec07ddb74  push r10
00007e1ec07ddb76  push r11
00007e1ec07ddb78  sub rsp, 0xF0
00007e1ec07ddb7f  vmovaps [rsp], xmm0
00007e1ec07ddb84  vmovaps [rsp+0x10], xmm1
00007e1ec07ddb8a  vmovaps [rsp+0x20], xmm2
00007e1ec07ddb90  vmovaps [rsp+0x30], xmm3
00007e1ec07ddb96  vmovaps [rsp+0x40], xmm4
00007e1ec07ddb9c  vmovaps [rsp+0x50], xmm5
00007e1ec07ddba2  vmovaps [rsp+0x60], xmm6
00007e1ec07ddba8  vmovaps [rsp+0x70], xmm7
00007e1ec07ddbae  vmovaps [rsp+0x80], xmm8
00007e1ec07ddbb7  vmovaps [rsp+0x90], xmm9
00007e1ec07ddbc0  vmovaps [rsp+0xA0], xmm10
00007e1ec07ddbc9  vmovaps [rsp+0xB0], xmm12
00007e1ec07ddbd2  vmovaps [rsp+0xC0], xmm13
00007e1ec07ddbdb  vmovaps [rsp+0xD0], xmm14
00007e1ec07ddbe4  vmovaps [rsp+0xE0], xmm15
00007e1ec07ddbed  sub rsp, 0x30
00007e1ec07ddbf1  movaps [rsp], xmm11
00007e1ec07ddbf6  movaps [rsp+0x10], xmm10
00007e1ec07ddbfc  movaps [rsp+0x20], xmm14
00007e1ec07ddc02  lea rdi, [rsp]
00007e1ec07ddc06  mov esi, 0x00
00007e1ec07ddc0b  mov rax, 0x5E00FF778530
00007e1ec07ddc15  call rax
00007e1ec07ddc17  movaps xmm11, [rsp]
00007e1ec07ddc1c  add rsp, 0x30
00007e1ec07ddc20  vmovaps xmm0, [rsp]
00007e1ec07ddc25  vmovaps xmm1, [rsp+0x10]
00007e1ec07ddc2b  vmovaps xmm2, [rsp+0x20]
00007e1ec07ddc31  vmovaps xmm3, [rsp+0x30]
00007e1ec07ddc37  vmovaps xmm4, [rsp+0x40]
00007e1ec07ddc3d  vmovaps xmm5, [rsp+0x50]
00007e1ec07ddc43  vmovaps xmm6, [rsp+0x60]
00007e1ec07ddc49  vmovaps xmm7, [rsp+0x70]
00007e1ec07ddc4f  vmovaps xmm8, [rsp+0x80]
00007e1ec07ddc58  vmovaps xmm9, [rsp+0x90]
00007e1ec07ddc61  vmovaps xmm10, [rsp+0xA0]
00007e1ec07ddc6a  vmovaps xmm12, [rsp+0xB0]
00007e1ec07ddc73  vmovaps xmm13, [rsp+0xC0]
00007e1ec07ddc7c  vmovaps xmm14, [rsp+0xD0]
00007e1ec07ddc85  vmovaps xmm15, [rsp+0xE0]
00007e1ec07ddc8e  add rsp, 0xF0
00007e1ec07ddc95  pop r11
00007e1ec07ddc97  pop r10
00007e1ec07ddc99  pop r9
00007e1ec07ddc9b  pop r8
00007e1ec07ddc9d  pop rsi
00007e1ec07ddc9e  pop rdi
00007e1ec07ddc9f  pop rdx
00007e1ec07ddca0  pop rcx
00007e1ec07ddca1  pop rax
00007e1ec07ddca2  add rsp, 0x08
00007e1ec07ddca6  jmp 0x00007E1EC07D96CD
00007e1ec07ddcab  call 0x00007E1EC06E45A0
00007e1ec07ddcb0  jmp 0x00007E1EC07D96D7
00007e1ec07ddcb5  sub rsp, 0x08
00007e1ec07ddcb9  push rax
00007e1ec07ddcba  push rcx
00007e1ec07ddcbb  push rdx
00007e1ec07ddcbc  push rdi
00007e1ec07ddcbd  push rsi
00007e1ec07ddcbe  push r8
00007e1ec07ddcc0  push r9
00007e1ec07ddcc2  push r10
00007e1ec07ddcc4  push r11
00007e1ec07ddcc6  sub rsp, 0xF0
00007e1ec07ddccd  vmovaps [rsp], xmm0
00007e1ec07ddcd2  vmovaps [rsp+0x10], xmm1
00007e1ec07ddcd8  vmovaps [rsp+0x20], xmm2
00007e1ec07ddcde  vmovaps [rsp+0x30], xmm3
00007e1ec07ddce4  vmovaps [rsp+0x40], xmm4
00007e1ec07ddcea  vmovaps [rsp+0x50], xmm5
00007e1ec07ddcf0  vmovaps [rsp+0x60], xmm6
00007e1ec07ddcf6  vmovaps [rsp+0x70], xmm7
00007e1ec07ddcfc  vmovaps [rsp+0x80], xmm8
00007e1ec07ddd05  vmovaps [rsp+0x90], xmm9
00007e1ec07ddd0e  vmovaps [rsp+0xA0], xmm11
00007e1ec07ddd17  vmovaps [rsp+0xB0], xmm12
00007e1ec07ddd20  vmovaps [rsp+0xC0], xmm13
00007e1ec07ddd29  vmovaps [rsp+0xD0], xmm14
00007e1ec07ddd32  vmovaps [rsp+0xE0], xmm15
00007e1ec07ddd3b  sub rsp, 0x30
00007e1ec07ddd3f  movaps [rsp], xmm10
00007e1ec07ddd44  movaps [rsp+0x10], xmm1
00007e1ec07ddd49  movaps [rsp+0x20], xmm12
00007e1ec07ddd4f  lea rdi, [rsp]
00007e1ec07ddd53  mov esi, 0x00
00007e1ec07ddd58  mov rax, 0x5E00FF778530
00007e1ec07ddd62  call rax
00007e1ec07ddd64  movaps xmm10, [rsp]
00007e1ec07ddd69  add rsp, 0x30
00007e1ec07ddd6d  vmovaps xmm0, [rsp]
00007e1ec07ddd72  vmovaps xmm1, [rsp+0x10]
00007e1ec07ddd78  vmovaps xmm2, [rsp+0x20]
00007e1ec07ddd7e  vmovaps xmm3, [rsp+0x30]
00007e1ec07ddd84  vmovaps xmm4, [rsp+0x40]
00007e1ec07ddd8a  vmovaps xmm5, [rsp+0x50]
00007e1ec07ddd90  vmovaps xmm6, [rsp+0x60]
00007e1ec07ddd96  vmovaps xmm7, [rsp+0x70]
00007e1ec07ddd9c  vmovaps xmm8, [rsp+0x80]
00007e1ec07ddda5  vmovaps xmm9, [rsp+0x90]
00007e1ec07dddae  vmovaps xmm11, [rsp+0xA0]
00007e1ec07dddb7  vmovaps xmm12, [rsp+0xB0]
00007e1ec07dddc0  vmovaps xmm13, [rsp+0xC0]
00007e1ec07dddc9  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dddd2  vmovaps xmm15, [rsp+0xE0]
00007e1ec07ddddb  add rsp, 0xF0
00007e1ec07ddde2  pop r11
00007e1ec07ddde4  pop r10
00007e1ec07ddde6  pop r9
00007e1ec07ddde8  pop r8
00007e1ec07dddea  pop rsi
00007e1ec07dddeb  pop rdi
00007e1ec07dddec  pop rdx
00007e1ec07ddded  pop rcx
00007e1ec07dddee  pop rax
00007e1ec07dddef  add rsp, 0x08
00007e1ec07dddf3  jmp 0x00007E1EC07D96FA
00007e1ec07dddf8  sub rsp, 0x08
00007e1ec07dddfc  push rax
00007e1ec07dddfd  push rcx
00007e1ec07dddfe  push rdx
00007e1ec07dddff  push rdi
00007e1ec07dde00  push rsi
00007e1ec07dde01  push r8
00007e1ec07dde03  push r9
00007e1ec07dde05  push r10
00007e1ec07dde07  push r11
00007e1ec07dde09  sub rsp, 0xF0
00007e1ec07dde10  vmovaps [rsp], xmm0
00007e1ec07dde15  vmovaps [rsp+0x10], xmm1
00007e1ec07dde1b  vmovaps [rsp+0x20], xmm2
00007e1ec07dde21  vmovaps [rsp+0x30], xmm3
00007e1ec07dde27  vmovaps [rsp+0x40], xmm4
00007e1ec07dde2d  vmovaps [rsp+0x50], xmm5
00007e1ec07dde33  vmovaps [rsp+0x60], xmm6
00007e1ec07dde39  vmovaps [rsp+0x70], xmm7
00007e1ec07dde3f  vmovaps [rsp+0x80], xmm8
00007e1ec07dde48  vmovaps [rsp+0x90], xmm9
00007e1ec07dde51  vmovaps [rsp+0xA0], xmm10
00007e1ec07dde5a  vmovaps [rsp+0xB0], xmm11
00007e1ec07dde63  vmovaps [rsp+0xC0], xmm13
00007e1ec07dde6c  vmovaps [rsp+0xD0], xmm14
00007e1ec07dde75  vmovaps [rsp+0xE0], xmm15
00007e1ec07dde7e  sub rsp, 0x30
00007e1ec07dde82  movaps [rsp], xmm12
00007e1ec07dde87  movaps [rsp+0x10], xmm14
00007e1ec07dde8d  movaps [rsp+0x20], xmm1
00007e1ec07dde92  lea rdi, [rsp]
00007e1ec07dde96  mov esi, 0x00
00007e1ec07dde9b  mov rax, 0x5E00FF778530
00007e1ec07ddea5  call rax
00007e1ec07ddea7  movaps xmm12, [rsp]
00007e1ec07ddeac  add rsp, 0x30
00007e1ec07ddeb0  vmovaps xmm0, [rsp]
00007e1ec07ddeb5  vmovaps xmm1, [rsp+0x10]
00007e1ec07ddebb  vmovaps xmm2, [rsp+0x20]
00007e1ec07ddec1  vmovaps xmm3, [rsp+0x30]
00007e1ec07ddec7  vmovaps xmm4, [rsp+0x40]
00007e1ec07ddecd  vmovaps xmm5, [rsp+0x50]
00007e1ec07dded3  vmovaps xmm6, [rsp+0x60]
00007e1ec07dded9  vmovaps xmm7, [rsp+0x70]
00007e1ec07ddedf  vmovaps xmm8, [rsp+0x80]
00007e1ec07ddee8  vmovaps xmm9, [rsp+0x90]
00007e1ec07ddef1  vmovaps xmm10, [rsp+0xA0]
00007e1ec07ddefa  vmovaps xmm11, [rsp+0xB0]
00007e1ec07ddf03  vmovaps xmm13, [rsp+0xC0]
00007e1ec07ddf0c  vmovaps xmm14, [rsp+0xD0]
00007e1ec07ddf15  vmovaps xmm15, [rsp+0xE0]
00007e1ec07ddf1e  add rsp, 0xF0
00007e1ec07ddf25  pop r11
00007e1ec07ddf27  pop r10
00007e1ec07ddf29  pop r9
00007e1ec07ddf2b  pop r8
00007e1ec07ddf2d  pop rsi
00007e1ec07ddf2e  pop rdi
00007e1ec07ddf2f  pop rdx
00007e1ec07ddf30  pop rcx
00007e1ec07ddf31  pop rax
00007e1ec07ddf32  add rsp, 0x08
00007e1ec07ddf36  jmp 0x00007E1EC07D9729
00007e1ec07ddf3b  sub rsp, 0x08
00007e1ec07ddf3f  push rax
00007e1ec07ddf40  push rcx
00007e1ec07ddf41  push rdx
00007e1ec07ddf42  push rdi
00007e1ec07ddf43  push rsi
00007e1ec07ddf44  push r8
00007e1ec07ddf46  push r9
00007e1ec07ddf48  push r10
00007e1ec07ddf4a  push r11
00007e1ec07ddf4c  sub rsp, 0xF0
00007e1ec07ddf53  vmovaps [rsp], xmm0
00007e1ec07ddf58  vmovaps [rsp+0x10], xmm1
00007e1ec07ddf5e  vmovaps [rsp+0x20], xmm2
00007e1ec07ddf64  vmovaps [rsp+0x30], xmm3
00007e1ec07ddf6a  vmovaps [rsp+0x40], xmm4
00007e1ec07ddf70  vmovaps [rsp+0x50], xmm5
00007e1ec07ddf76  vmovaps [rsp+0x60], xmm6
00007e1ec07ddf7c  vmovaps [rsp+0x70], xmm7
00007e1ec07ddf82  vmovaps [rsp+0x80], xmm8
00007e1ec07ddf8b  vmovaps [rsp+0x90], xmm9
00007e1ec07ddf94  vmovaps [rsp+0xA0], xmm10
00007e1ec07ddf9d  vmovaps [rsp+0xB0], xmm11
00007e1ec07ddfa6  vmovaps [rsp+0xC0], xmm12
00007e1ec07ddfaf  vmovaps [rsp+0xD0], xmm13
00007e1ec07ddfb8  vmovaps [rsp+0xE0], xmm15
00007e1ec07ddfc1  sub rsp, 0x30
00007e1ec07ddfc5  movaps [rsp], xmm14
00007e1ec07ddfca  movaps [rsp+0x10], xmm9
00007e1ec07ddfd0  movaps [rsp+0x20], xmm1
00007e1ec07ddfd5  lea rdi, [rsp]
00007e1ec07ddfd9  mov esi, 0x00
00007e1ec07ddfde  mov rax, 0x5E00FF778530
00007e1ec07ddfe8  call rax
00007e1ec07ddfea  movaps xmm14, [rsp]
00007e1ec07ddfef  add rsp, 0x30
00007e1ec07ddff3  vmovaps xmm0, [rsp]
00007e1ec07ddff8  vmovaps xmm1, [rsp+0x10]
00007e1ec07ddffe  vmovaps xmm2, [rsp+0x20]
00007e1ec07de004  vmovaps xmm3, [rsp+0x30]
00007e1ec07de00a  vmovaps xmm4, [rsp+0x40]
00007e1ec07de010  vmovaps xmm5, [rsp+0x50]
00007e1ec07de016  vmovaps xmm6, [rsp+0x60]
00007e1ec07de01c  vmovaps xmm7, [rsp+0x70]
00007e1ec07de022  vmovaps xmm8, [rsp+0x80]
00007e1ec07de02b  vmovaps xmm9, [rsp+0x90]
00007e1ec07de034  vmovaps xmm10, [rsp+0xA0]
00007e1ec07de03d  vmovaps xmm11, [rsp+0xB0]
00007e1ec07de046  vmovaps xmm12, [rsp+0xC0]
00007e1ec07de04f  vmovaps xmm13, [rsp+0xD0]
00007e1ec07de058  vmovaps xmm15, [rsp+0xE0]
00007e1ec07de061  add rsp, 0xF0
00007e1ec07de068  pop r11
00007e1ec07de06a  pop r10
00007e1ec07de06c  pop r9
00007e1ec07de06e  pop r8
00007e1ec07de070  pop rsi
00007e1ec07de071  pop rdi
00007e1ec07de072  pop rdx
00007e1ec07de073  pop rcx
00007e1ec07de074  pop rax
00007e1ec07de075  add rsp, 0x08
00007e1ec07de079  jmp 0x00007E1EC07D9758
00007e1ec07de07e  sub rsp, 0x08
00007e1ec07de082  push rax
00007e1ec07de083  push rcx
00007e1ec07de084  push rdx
00007e1ec07de085  push rdi
00007e1ec07de086  push rsi
00007e1ec07de087  push r8
00007e1ec07de089  push r9
00007e1ec07de08b  push r10
00007e1ec07de08d  push r11
00007e1ec07de08f  sub rsp, 0xF0
00007e1ec07de096  vmovaps [rsp], xmm0
00007e1ec07de09b  vmovaps [rsp+0x10], xmm2
00007e1ec07de0a1  vmovaps [rsp+0x20], xmm3
00007e1ec07de0a7  vmovaps [rsp+0x30], xmm4
00007e1ec07de0ad  vmovaps [rsp+0x40], xmm5
00007e1ec07de0b3  vmovaps [rsp+0x50], xmm6
00007e1ec07de0b9  vmovaps [rsp+0x60], xmm7
00007e1ec07de0bf  vmovaps [rsp+0x70], xmm8
00007e1ec07de0c5  vmovaps [rsp+0x80], xmm9
00007e1ec07de0ce  vmovaps [rsp+0x90], xmm10
00007e1ec07de0d7  vmovaps [rsp+0xA0], xmm11
00007e1ec07de0e0  vmovaps [rsp+0xB0], xmm12
00007e1ec07de0e9  vmovaps [rsp+0xC0], xmm13
00007e1ec07de0f2  vmovaps [rsp+0xD0], xmm14
00007e1ec07de0fb  vmovaps [rsp+0xE0], xmm15
00007e1ec07de104  sub rsp, 0x30
00007e1ec07de108  movaps [rsp], xmm1
00007e1ec07de10c  movaps [rsp+0x10], xmm13
00007e1ec07de112  movaps [rsp+0x20], xmm8
00007e1ec07de118  lea rdi, [rsp]
00007e1ec07de11c  mov esi, 0x00
00007e1ec07de121  mov rax, 0x5E00FF778530
00007e1ec07de12b  call rax
00007e1ec07de12d  movaps xmm1, [rsp]
00007e1ec07de131  add rsp, 0x30
00007e1ec07de135  vmovaps xmm0, [rsp]
00007e1ec07de13a  vmovaps xmm2, [rsp+0x10]
00007e1ec07de140  vmovaps xmm3, [rsp+0x20]
00007e1ec07de146  vmovaps xmm4, [rsp+0x30]
00007e1ec07de14c  vmovaps xmm5, [rsp+0x40]
00007e1ec07de152  vmovaps xmm6, [rsp+0x50]
00007e1ec07de158  vmovaps xmm7, [rsp+0x60]
00007e1ec07de15e  vmovaps xmm8, [rsp+0x70]
00007e1ec07de164  vmovaps xmm9, [rsp+0x80]
00007e1ec07de16d  vmovaps xmm10, [rsp+0x90]
00007e1ec07de176  vmovaps xmm11, [rsp+0xA0]
00007e1ec07de17f  vmovaps xmm12, [rsp+0xB0]
00007e1ec07de188  vmovaps xmm13, [rsp+0xC0]
00007e1ec07de191  vmovaps xmm14, [rsp+0xD0]
00007e1ec07de19a  vmovaps xmm15, [rsp+0xE0]
00007e1ec07de1a3  add rsp, 0xF0
00007e1ec07de1aa  pop r11
00007e1ec07de1ac  pop r10
00007e1ec07de1ae  pop r9
00007e1ec07de1b0  pop r8
00007e1ec07de1b2  pop rsi
00007e1ec07de1b3  pop rdi
00007e1ec07de1b4  pop rdx
00007e1ec07de1b5  pop rcx
00007e1ec07de1b6  pop rax
00007e1ec07de1b7  add rsp, 0x08
00007e1ec07de1bb  jmp 0x00007E1EC07D977A
00007e1ec07de1c0  call 0x00007E1EC060C260
00007e1ec07de1c5  jmp 0x00007E1EC07D9788
00007e1ec07de1ca  call 0x00007E1EC06DE950
00007e1ec07de1cf  jmp 0x00007E1EC07D9792
00007e1ec07de1d4  sub rsp, 0x08
00007e1ec07de1d8  push rax
00007e1ec07de1d9  push rcx
00007e1ec07de1da  push rdx
00007e1ec07de1db  push rdi
00007e1ec07de1dc  push rsi
00007e1ec07de1dd  push r8
00007e1ec07de1df  push r9
00007e1ec07de1e1  push r10
00007e1ec07de1e3  push r11
00007e1ec07de1e5  sub rsp, 0xF0
00007e1ec07de1ec  vmovaps [rsp], xmm0
00007e1ec07de1f1  vmovaps [rsp+0x10], xmm1
00007e1ec07de1f7  vmovaps [rsp+0x20], xmm2
00007e1ec07de1fd  vmovaps [rsp+0x30], xmm3
00007e1ec07de203  vmovaps [rsp+0x40], xmm4
00007e1ec07de209  vmovaps [rsp+0x50], xmm5
00007e1ec07de20f  vmovaps [rsp+0x60], xmm6
00007e1ec07de215  vmovaps [rsp+0x70], xmm7
00007e1ec07de21b  vmovaps [rsp+0x80], xmm9
00007e1ec07de224  vmovaps [rsp+0x90], xmm10
00007e1ec07de22d  vmovaps [rsp+0xA0], xmm11
00007e1ec07de236  vmovaps [rsp+0xB0], xmm12
00007e1ec07de23f  vmovaps [rsp+0xC0], xmm13
00007e1ec07de248  vmovaps [rsp+0xD0], xmm14
00007e1ec07de251  vmovaps [rsp+0xE0], xmm15
00007e1ec07de25a  sub rsp, 0x30
00007e1ec07de25e  movaps [rsp], xmm8
00007e1ec07de263  movaps [rsp+0x10], xmm15
00007e1ec07de269  movaps [rsp+0x20], xmm7
00007e1ec07de26e  lea rdi, [rsp]
00007e1ec07de272  mov esi, 0x00
00007e1ec07de277  mov rax, 0x5E00FF778530
00007e1ec07de281  call rax
00007e1ec07de283  movaps xmm8, [rsp]
00007e1ec07de288  add rsp, 0x30
00007e1ec07de28c  vmovaps xmm0, [rsp]
00007e1ec07de291  vmovaps xmm1, [rsp+0x10]
00007e1ec07de297  vmovaps xmm2, [rsp+0x20]
00007e1ec07de29d  vmovaps xmm3, [rsp+0x30]
00007e1ec07de2a3  vmovaps xmm4, [rsp+0x40]
00007e1ec07de2a9  vmovaps xmm5, [rsp+0x50]
00007e1ec07de2af  vmovaps xmm6, [rsp+0x60]
00007e1ec07de2b5  vmovaps xmm7, [rsp+0x70]
00007e1ec07de2bb  vmovaps xmm9, [rsp+0x80]
00007e1ec07de2c4  vmovaps xmm10, [rsp+0x90]
00007e1ec07de2cd  vmovaps xmm11, [rsp+0xA0]
00007e1ec07de2d6  vmovaps xmm12, [rsp+0xB0]
00007e1ec07de2df  vmovaps xmm13, [rsp+0xC0]
00007e1ec07de2e8  vmovaps xmm14, [rsp+0xD0]
00007e1ec07de2f1  vmovaps xmm15, [rsp+0xE0]
00007e1ec07de2fa  add rsp, 0xF0
00007e1ec07de301  pop r11
00007e1ec07de303  pop r10
00007e1ec07de305  pop r9
00007e1ec07de307  pop r8
00007e1ec07de309  pop rsi
00007e1ec07de30a  pop rdi
00007e1ec07de30b  pop rdx
00007e1ec07de30c  pop rcx
00007e1ec07de30d  pop rax
00007e1ec07de30e  add rsp, 0x08
00007e1ec07de312  jmp 0x00007E1EC07D97B4
00007e1ec07de317  sub rsp, 0x08
00007e1ec07de31b  push rax
00007e1ec07de31c  push rcx
00007e1ec07de31d  push rdx
00007e1ec07de31e  push rdi
00007e1ec07de31f  push rsi
00007e1ec07de320  push r8
00007e1ec07de322  push r9
00007e1ec07de324  push r10
00007e1ec07de326  push r11
00007e1ec07de328  sub rsp, 0xF0
00007e1ec07de32f  vmovaps [rsp], xmm0
00007e1ec07de334  vmovaps [rsp+0x10], xmm1
00007e1ec07de33a  vmovaps [rsp+0x20], xmm2
00007e1ec07de340  vmovaps [rsp+0x30], xmm3
00007e1ec07de346  vmovaps [rsp+0x40], xmm4
00007e1ec07de34c  vmovaps [rsp+0x50], xmm5
00007e1ec07de352  vmovaps [rsp+0x60], xmm6
00007e1ec07de358  vmovaps [rsp+0x70], xmm8
00007e1ec07de35e  vmovaps [rsp+0x80], xmm9
00007e1ec07de367  vmovaps [rsp+0x90], xmm10
00007e1ec07de370  vmovaps [rsp+0xA0], xmm11
00007e1ec07de379  vmovaps [rsp+0xB0], xmm12
00007e1ec07de382  vmovaps [rsp+0xC0], xmm13
00007e1ec07de38b  vmovaps [rsp+0xD0], xmm14
00007e1ec07de394  vmovaps [rsp+0xE0], xmm15
00007e1ec07de39d  sub rsp, 0x30
00007e1ec07de3a1  movaps [rsp], xmm7
00007e1ec07de3a5  movaps [rsp+0x10], xmm9
00007e1ec07de3ab  movaps [rsp+0x20], xmm15
00007e1ec07de3b1  lea rdi, [rsp]
00007e1ec07de3b5  mov esi, 0x00
00007e1ec07de3ba  mov rax, 0x5E00FF778530
00007e1ec07de3c4  call rax
00007e1ec07de3c6  movaps xmm7, [rsp]
00007e1ec07de3ca  add rsp, 0x30
00007e1ec07de3ce  vmovaps xmm0, [rsp]
00007e1ec07de3d3  vmovaps xmm1, [rsp+0x10]
00007e1ec07de3d9  vmovaps xmm2, [rsp+0x20]
00007e1ec07de3df  vmovaps xmm3, [rsp+0x30]
00007e1ec07de3e5  vmovaps xmm4, [rsp+0x40]
00007e1ec07de3eb  vmovaps xmm5, [rsp+0x50]
00007e1ec07de3f1  vmovaps xmm6, [rsp+0x60]
00007e1ec07de3f7  vmovaps xmm8, [rsp+0x70]
00007e1ec07de3fd  vmovaps xmm9, [rsp+0x80]
00007e1ec07de406  vmovaps xmm10, [rsp+0x90]
00007e1ec07de40f  vmovaps xmm11, [rsp+0xA0]
00007e1ec07de418  vmovaps xmm12, [rsp+0xB0]
00007e1ec07de421  vmovaps xmm13, [rsp+0xC0]
00007e1ec07de42a  vmovaps xmm14, [rsp+0xD0]
00007e1ec07de433  vmovaps xmm15, [rsp+0xE0]
00007e1ec07de43c  add rsp, 0xF0
00007e1ec07de443  pop r11
00007e1ec07de445  pop r10
00007e1ec07de447  pop r9
00007e1ec07de449  pop r8
00007e1ec07de44b  pop rsi
00007e1ec07de44c  pop rdi
00007e1ec07de44d  pop rdx
00007e1ec07de44e  pop rcx
00007e1ec07de44f  pop rax
00007e1ec07de450  add rsp, 0x08
00007e1ec07de454  jmp 0x00007E1EC07D97E1
00007e1ec07de459  sub rsp, 0x08
00007e1ec07de45d  push rax
00007e1ec07de45e  push rcx
00007e1ec07de45f  push rdx
00007e1ec07de460  push rdi
00007e1ec07de461  push rsi
00007e1ec07de462  push r8
00007e1ec07de464  push r9
00007e1ec07de466  push r10
00007e1ec07de468  push r11
00007e1ec07de46a  sub rsp, 0xF0
00007e1ec07de471  vmovaps [rsp], xmm0
00007e1ec07de476  vmovaps [rsp+0x10], xmm1
00007e1ec07de47c  vmovaps [rsp+0x20], xmm2
00007e1ec07de482  vmovaps [rsp+0x30], xmm3
00007e1ec07de488  vmovaps [rsp+0x40], xmm4
00007e1ec07de48e  vmovaps [rsp+0x50], xmm5
00007e1ec07de494  vmovaps [rsp+0x60], xmm6
00007e1ec07de49a  vmovaps [rsp+0x70], xmm7
00007e1ec07de4a0  vmovaps [rsp+0x80], xmm8
00007e1ec07de4a9  vmovaps [rsp+0x90], xmm10
00007e1ec07de4b2  vmovaps [rsp+0xA0], xmm11
00007e1ec07de4bb  vmovaps [rsp+0xB0], xmm12
00007e1ec07de4c4  vmovaps [rsp+0xC0], xmm13
00007e1ec07de4cd  vmovaps [rsp+0xD0], xmm14
00007e1ec07de4d6  vmovaps [rsp+0xE0], xmm15
00007e1ec07de4df  sub rsp, 0x30
00007e1ec07de4e3  movaps [rsp], xmm9
00007e1ec07de4e8  movaps [rsp+0x10], xmm13
00007e1ec07de4ee  movaps [rsp+0x20], xmm15
00007e1ec07de4f4  lea rdi, [rsp]
00007e1ec07de4f8  mov esi, 0x00
00007e1ec07de4fd  mov rax, 0x5E00FF778530
00007e1ec07de507  call rax
00007e1ec07de509  movaps xmm9, [rsp]
00007e1ec07de50e  add rsp, 0x30
00007e1ec07de512  vmovaps xmm0, [rsp]
00007e1ec07de517  vmovaps xmm1, [rsp+0x10]
00007e1ec07de51d  vmovaps xmm2, [rsp+0x20]
00007e1ec07de523  vmovaps xmm3, [rsp+0x30]
00007e1ec07de529  vmovaps xmm4, [rsp+0x40]
00007e1ec07de52f  vmovaps xmm5, [rsp+0x50]
00007e1ec07de535  vmovaps xmm6, [rsp+0x60]
00007e1ec07de53b  vmovaps xmm7, [rsp+0x70]
00007e1ec07de541  vmovaps xmm8, [rsp+0x80]
00007e1ec07de54a  vmovaps xmm10, [rsp+0x90]
00007e1ec07de553  vmovaps xmm11, [rsp+0xA0]
00007e1ec07de55c  vmovaps xmm12, [rsp+0xB0]
00007e1ec07de565  vmovaps xmm13, [rsp+0xC0]
00007e1ec07de56e  vmovaps xmm14, [rsp+0xD0]
00007e1ec07de577  vmovaps xmm15, [rsp+0xE0]
00007e1ec07de580  add rsp, 0xF0
00007e1ec07de587  pop r11
00007e1ec07de589  pop r10
00007e1ec07de58b  pop r9
00007e1ec07de58d  pop r8
00007e1ec07de58f  pop rsi
00007e1ec07de590  pop rdi
00007e1ec07de591  pop rdx
00007e1ec07de592  pop rcx
00007e1ec07de593  pop rax
00007e1ec07de594  add rsp, 0x08
00007e1ec07de598  jmp 0x00007E1EC07D980F
00007e1ec07de59d  sub rsp, 0x08
00007e1ec07de5a1  push rax
00007e1ec07de5a2  push rcx
00007e1ec07de5a3  push rdx
00007e1ec07de5a4  push rdi
00007e1ec07de5a5  push rsi
00007e1ec07de5a6  push r8
00007e1ec07de5a8  push r9
00007e1ec07de5aa  push r10
00007e1ec07de5ac  push r11
00007e1ec07de5ae  sub rsp, 0xF0
00007e1ec07de5b5  vmovaps [rsp], xmm0
00007e1ec07de5ba  vmovaps [rsp+0x10], xmm1
00007e1ec07de5c0  vmovaps [rsp+0x20], xmm2
00007e1ec07de5c6  vmovaps [rsp+0x30], xmm3
00007e1ec07de5cc  vmovaps [rsp+0x40], xmm4
00007e1ec07de5d2  vmovaps [rsp+0x50], xmm5
00007e1ec07de5d8  vmovaps [rsp+0x60], xmm6
00007e1ec07de5de  vmovaps [rsp+0x70], xmm7
00007e1ec07de5e4  vmovaps [rsp+0x80], xmm8
00007e1ec07de5ed  vmovaps [rsp+0x90], xmm9
00007e1ec07de5f6  vmovaps [rsp+0xA0], xmm10
00007e1ec07de5ff  vmovaps [rsp+0xB0], xmm11
00007e1ec07de608  vmovaps [rsp+0xC0], xmm12
00007e1ec07de611  vmovaps [rsp+0xD0], xmm13
00007e1ec07de61a  vmovaps [rsp+0xE0], xmm14
00007e1ec07de623  sub rsp, 0x30
00007e1ec07de627  movaps [rsp], xmm15
00007e1ec07de62c  movaps [rsp+0x10], xmm11
00007e1ec07de632  movaps [rsp+0x20], xmm12
00007e1ec07de638  lea rdi, [rsp]
00007e1ec07de63c  mov esi, 0x00
00007e1ec07de641  mov rax, 0x5E00FF778530
00007e1ec07de64b  call rax
00007e1ec07de64d  movaps xmm15, [rsp]
00007e1ec07de652  add rsp, 0x30
00007e1ec07de656  vmovaps xmm0, [rsp]
00007e1ec07de65b  vmovaps xmm1, [rsp+0x10]
00007e1ec07de661  vmovaps xmm2, [rsp+0x20]
00007e1ec07de667  vmovaps xmm3, [rsp+0x30]
00007e1ec07de66d  vmovaps xmm4, [rsp+0x40]
00007e1ec07de673  vmovaps xmm5, [rsp+0x50]
00007e1ec07de679  vmovaps xmm6, [rsp+0x60]
00007e1ec07de67f  vmovaps xmm7, [rsp+0x70]
00007e1ec07de685  vmovaps xmm8, [rsp+0x80]
00007e1ec07de68e  vmovaps xmm9, [rsp+0x90]
00007e1ec07de697  vmovaps xmm10, [rsp+0xA0]
00007e1ec07de6a0  vmovaps xmm11, [rsp+0xB0]
00007e1ec07de6a9  vmovaps xmm12, [rsp+0xC0]
00007e1ec07de6b2  vmovaps xmm13, [rsp+0xD0]
00007e1ec07de6bb  vmovaps xmm14, [rsp+0xE0]
00007e1ec07de6c4  add rsp, 0xF0
00007e1ec07de6cb  pop r11
00007e1ec07de6cd  pop r10
00007e1ec07de6cf  pop r9
00007e1ec07de6d1  pop r8
00007e1ec07de6d3  pop rsi
00007e1ec07de6d4  pop rdi
00007e1ec07de6d5  pop rdx
00007e1ec07de6d6  pop rcx
00007e1ec07de6d7  pop rax
00007e1ec07de6d8  add rsp, 0x08
00007e1ec07de6dc  jmp 0x00007E1EC07D982A
00007e1ec07de6e1  sub rsp, 0x08
00007e1ec07de6e5  push rax
00007e1ec07de6e6  push rcx
00007e1ec07de6e7  push rdx
00007e1ec07de6e8  push rdi
00007e1ec07de6e9  push rsi
00007e1ec07de6ea  push r8
00007e1ec07de6ec  push r9
00007e1ec07de6ee  push r10
00007e1ec07de6f0  push r11
00007e1ec07de6f2  sub rsp, 0xF0
00007e1ec07de6f9  vmovaps [rsp], xmm0
00007e1ec07de6fe  vmovaps [rsp+0x10], xmm1
00007e1ec07de704  vmovaps [rsp+0x20], xmm2
00007e1ec07de70a  vmovaps [rsp+0x30], xmm3
00007e1ec07de710  vmovaps [rsp+0x40], xmm4
00007e1ec07de716  vmovaps [rsp+0x50], xmm5
00007e1ec07de71c  vmovaps [rsp+0x60], xmm6
00007e1ec07de722  vmovaps [rsp+0x70], xmm7
00007e1ec07de728  vmovaps [rsp+0x80], xmm8
00007e1ec07de731  vmovaps [rsp+0x90], xmm9
00007e1ec07de73a  vmovaps [rsp+0xA0], xmm10
00007e1ec07de743  vmovaps [rsp+0xB0], xmm11
00007e1ec07de74c  vmovaps [rsp+0xC0], xmm12
00007e1ec07de755  vmovaps [rsp+0xD0], xmm14
00007e1ec07de75e  vmovaps [rsp+0xE0], xmm15
00007e1ec07de767  sub rsp, 0x30
00007e1ec07de76b  movaps [rsp], xmm13
00007e1ec07de770  movaps [rsp+0x10], xmm10
00007e1ec07de776  movaps [rsp+0x20], xmm14
00007e1ec07de77c  lea rdi, [rsp]
00007e1ec07de780  mov esi, 0x00
00007e1ec07de785  mov rax, 0x5E00FF778530
00007e1ec07de78f  call rax
00007e1ec07de791  movaps xmm13, [rsp]
00007e1ec07de796  add rsp, 0x30
00007e1ec07de79a  vmovaps xmm0, [rsp]
00007e1ec07de79f  vmovaps xmm1, [rsp+0x10]
00007e1ec07de7a5  vmovaps xmm2, [rsp+0x20]
00007e1ec07de7ab  vmovaps xmm3, [rsp+0x30]
00007e1ec07de7b1  vmovaps xmm4, [rsp+0x40]
00007e1ec07de7b7  vmovaps xmm5, [rsp+0x50]
00007e1ec07de7bd  vmovaps xmm6, [rsp+0x60]
00007e1ec07de7c3  vmovaps xmm7, [rsp+0x70]
00007e1ec07de7c9  vmovaps xmm8, [rsp+0x80]
00007e1ec07de7d2  vmovaps xmm9, [rsp+0x90]
00007e1ec07de7db  vmovaps xmm10, [rsp+0xA0]
00007e1ec07de7e4  vmovaps xmm11, [rsp+0xB0]
00007e1ec07de7ed  vmovaps xmm12, [rsp+0xC0]
00007e1ec07de7f6  vmovaps xmm14, [rsp+0xD0]
00007e1ec07de7ff  vmovaps xmm15, [rsp+0xE0]
00007e1ec07de808  add rsp, 0xF0
00007e1ec07de80f  pop r11
00007e1ec07de811  pop r10
00007e1ec07de813  pop r9
00007e1ec07de815  pop r8
00007e1ec07de817  pop rsi
00007e1ec07de818  pop rdi
00007e1ec07de819  pop rdx
00007e1ec07de81a  pop rcx
00007e1ec07de81b  pop rax
00007e1ec07de81c  add rsp, 0x08
00007e1ec07de820  jmp 0x00007E1EC07D984D
00007e1ec07de825  sub rsp, 0x08
00007e1ec07de829  push rax
00007e1ec07de82a  push rcx
00007e1ec07de82b  push rdx
00007e1ec07de82c  push rdi
00007e1ec07de82d  push rsi
00007e1ec07de82e  push r8
00007e1ec07de830  push r9
00007e1ec07de832  push r10
00007e1ec07de834  push r11
00007e1ec07de836  sub rsp, 0xF0
00007e1ec07de83d  vmovaps [rsp], xmm0
00007e1ec07de842  vmovaps [rsp+0x10], xmm1
00007e1ec07de848  vmovaps [rsp+0x20], xmm2
00007e1ec07de84e  vmovaps [rsp+0x30], xmm3
00007e1ec07de854  vmovaps [rsp+0x40], xmm4
00007e1ec07de85a  vmovaps [rsp+0x50], xmm5
00007e1ec07de860  vmovaps [rsp+0x60], xmm6
00007e1ec07de866  vmovaps [rsp+0x70], xmm7
00007e1ec07de86c  vmovaps [rsp+0x80], xmm8
00007e1ec07de875  vmovaps [rsp+0x90], xmm9
00007e1ec07de87e  vmovaps [rsp+0xA0], xmm10
00007e1ec07de887  vmovaps [rsp+0xB0], xmm11
00007e1ec07de890  vmovaps [rsp+0xC0], xmm12
00007e1ec07de899  vmovaps [rsp+0xD0], xmm13
00007e1ec07de8a2  vmovaps [rsp+0xE0], xmm15
00007e1ec07de8ab  sub rsp, 0x30
00007e1ec07de8af  movaps [rsp], xmm14
00007e1ec07de8b4  movaps [rsp+0x10], xmm1
00007e1ec07de8b9  movaps [rsp+0x20], xmm7
00007e1ec07de8be  lea rdi, [rsp]
00007e1ec07de8c2  mov esi, 0x00
00007e1ec07de8c7  mov rax, 0x5E00FF778530
00007e1ec07de8d1  call rax
00007e1ec07de8d3  movaps xmm14, [rsp]
00007e1ec07de8d8  add rsp, 0x30
00007e1ec07de8dc  vmovaps xmm0, [rsp]
00007e1ec07de8e1  vmovaps xmm1, [rsp+0x10]
00007e1ec07de8e7  vmovaps xmm2, [rsp+0x20]
00007e1ec07de8ed  vmovaps xmm3, [rsp+0x30]
00007e1ec07de8f3  vmovaps xmm4, [rsp+0x40]
00007e1ec07de8f9  vmovaps xmm5, [rsp+0x50]
00007e1ec07de8ff  vmovaps xmm6, [rsp+0x60]
00007e1ec07de905  vmovaps xmm7, [rsp+0x70]
00007e1ec07de90b  vmovaps xmm8, [rsp+0x80]
00007e1ec07de914  vmovaps xmm9, [rsp+0x90]
00007e1ec07de91d  vmovaps xmm10, [rsp+0xA0]
00007e1ec07de926  vmovaps xmm11, [rsp+0xB0]
00007e1ec07de92f  vmovaps xmm12, [rsp+0xC0]
00007e1ec07de938  vmovaps xmm13, [rsp+0xD0]
00007e1ec07de941  vmovaps xmm15, [rsp+0xE0]
00007e1ec07de94a  add rsp, 0xF0
00007e1ec07de951  pop r11
00007e1ec07de953  pop r10
00007e1ec07de955  pop r9
00007e1ec07de957  pop r8
00007e1ec07de959  pop rsi
00007e1ec07de95a  pop rdi
00007e1ec07de95b  pop rdx
00007e1ec07de95c  pop rcx
00007e1ec07de95d  pop rax
00007e1ec07de95e  add rsp, 0x08
00007e1ec07de962  jmp 0x00007E1EC07D9870
00007e1ec07de967  sub rsp, 0x08
00007e1ec07de96b  push rax
00007e1ec07de96c  push rcx
00007e1ec07de96d  push rdx
00007e1ec07de96e  push rdi
00007e1ec07de96f  push rsi
00007e1ec07de970  push r8
00007e1ec07de972  push r9
00007e1ec07de974  push r10
00007e1ec07de976  push r11
00007e1ec07de978  sub rsp, 0xF0
00007e1ec07de97f  vmovaps [rsp], xmm0
00007e1ec07de984  vmovaps [rsp+0x10], xmm2
00007e1ec07de98a  vmovaps [rsp+0x20], xmm3
00007e1ec07de990  vmovaps [rsp+0x30], xmm4
00007e1ec07de996  vmovaps [rsp+0x40], xmm5
00007e1ec07de99c  vmovaps [rsp+0x50], xmm6
00007e1ec07de9a2  vmovaps [rsp+0x60], xmm7
00007e1ec07de9a8  vmovaps [rsp+0x70], xmm8
00007e1ec07de9ae  vmovaps [rsp+0x80], xmm9
00007e1ec07de9b7  vmovaps [rsp+0x90], xmm10
00007e1ec07de9c0  vmovaps [rsp+0xA0], xmm11
00007e1ec07de9c9  vmovaps [rsp+0xB0], xmm12
00007e1ec07de9d2  vmovaps [rsp+0xC0], xmm13
00007e1ec07de9db  vmovaps [rsp+0xD0], xmm14
00007e1ec07de9e4  vmovaps [rsp+0xE0], xmm15
00007e1ec07de9ed  sub rsp, 0x30
00007e1ec07de9f1  movaps [rsp], xmm1
00007e1ec07de9f5  movaps [rsp+0x10], xmm8
00007e1ec07de9fb  movaps [rsp+0x20], xmm9
00007e1ec07dea01  lea rdi, [rsp]
00007e1ec07dea05  mov esi, 0x00
00007e1ec07dea0a  mov rax, 0x5E00FF778530
00007e1ec07dea14  call rax
00007e1ec07dea16  movaps xmm1, [rsp]
00007e1ec07dea1a  add rsp, 0x30
00007e1ec07dea1e  vmovaps xmm0, [rsp]
00007e1ec07dea23  vmovaps xmm2, [rsp+0x10]
00007e1ec07dea29  vmovaps xmm3, [rsp+0x20]
00007e1ec07dea2f  vmovaps xmm4, [rsp+0x30]
00007e1ec07dea35  vmovaps xmm5, [rsp+0x40]
00007e1ec07dea3b  vmovaps xmm6, [rsp+0x50]
00007e1ec07dea41  vmovaps xmm7, [rsp+0x60]
00007e1ec07dea47  vmovaps xmm8, [rsp+0x70]
00007e1ec07dea4d  vmovaps xmm9, [rsp+0x80]
00007e1ec07dea56  vmovaps xmm10, [rsp+0x90]
00007e1ec07dea5f  vmovaps xmm11, [rsp+0xA0]
00007e1ec07dea68  vmovaps xmm12, [rsp+0xB0]
00007e1ec07dea71  vmovaps xmm13, [rsp+0xC0]
00007e1ec07dea7a  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dea83  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dea8c  add rsp, 0xF0
00007e1ec07dea93  pop r11
00007e1ec07dea95  pop r10
00007e1ec07dea97  pop r9
00007e1ec07dea99  pop r8
00007e1ec07dea9b  pop rsi
00007e1ec07dea9c  pop rdi
00007e1ec07dea9d  pop rdx
00007e1ec07dea9e  pop rcx
00007e1ec07dea9f  pop rax
00007e1ec07deaa0  add rsp, 0x08
00007e1ec07deaa4  jmp 0x00007E1EC07D9892
00007e1ec07deaa9  call 0x00007E1EC06B3E40
00007e1ec07deaae  jmp 0x00007E1EC07D98A0
00007e1ec07deab3  call 0x00007E1EC060C380
00007e1ec07deab8  jmp 0x00007E1EC07D98AA
00007e1ec07deabd  call 0x00007E1EC060D600
00007e1ec07deac2  jmp 0x00007E1EC07D98B4
00007e1ec07deac7  call 0x00007E1EC05FF540
00007e1ec07deacc  jmp 0x00007E1EC07D98BE
00007e1ec07dead1  int3
00007e1ec07dead2  nop [rax+rax*1], ax
00007e1ec07deadb  nop [rax+rax*1], eax
00007e1ec07deae0  mov eax, [r15+0x48]
00007e1ec07deae4  lea r14d, [eax+0x01]
00007e1ec07deae9  mov [rsp+0x10], r14d
00007e1ec07deaee  mov r14d, r14d
00007e1ec07deaf1  mov [r15+0x48], r14
00007e1ec07deaf5  xor eax, eax
00007e1ec07deaf7  mov r14d, [rsp+0x10]
00007e1ec07deafc  cmp r14d, 0x1F4
00007e1ec07deb03  cmc
00007e1ec07deb04  lahf
00007e1ec07deb05  seto al
00007e1ec07deb08  mov [r15+0x108], eax
00007e1ec07deb0f  mov eax, [r15+0x108]
00007e1ec07deb16  sahf
00007e1ec07deb17  jnz 0x00007E1EC07DEB49
00007e1ec07deb19  cmp dword ptr [r15+0x318], 0x00
00007e1ec07deb21  jz 0x00007E1EC07E4C90
00007e1ec07deb27  nop [rax+rax*1], ax
00007e1ec07deb30  nop [rax+rax*1], eax
00007e1ec07deb38  mov eax, 0x4106DC
00007e1ec07deb3d  mov [r15+0x100], rax
00007e1ec07deb44  jmp 0x00007E1EC05FE110
00007e1ec07deb49  cmp dword ptr [r15+0x318], 0x00
00007e1ec07deb51  jz 0x00007E1EC07DEB80
00007e1ec07deb57  nop [rax+rax*1], ax
00007e1ec07deb60  nop [rax+rax*1], eax
00007e1ec07deb68  mov eax, 0x410500
00007e1ec07deb6d  mov [r15+0x100], rax
00007e1ec07deb74  jmp 0x00007E1EC05FE110
00007e1ec07deb79  int3
00007e1ec07deb7a  int3
00007e1ec07deb7b  nop [rax+rax*1], eax
00007e1ec07deb80  mov rax, [r15+0x40]
00007e1ec07deb84  movaps xmm1, [r15+0x1D0]
00007e1ec07deb8c  vmovaps [rsp+0x10], xmm1
00007e1ec07deb92  vmovaps xmm15, [rsp+0x10]
00007e1ec07deb98  por xmm1, xmm15
00007e1ec07deb9d  movaps xmm14, [r15+0x1A0]
00007e1ec07deba5  vmovaps [rsp+0x10], xmm14
00007e1ec07debab  vmovaps xmm13, [rsp+0x10]
00007e1ec07debb1  por xmm14, xmm13
00007e1ec07debb6  lea r14, [rax+0x30]
00007e1ec07debba  mov r12, [r13+r14*1]
00007e1ec07debbf  lea r14, [rax+0x38]
00007e1ec07debc3  mov r11, [r13+r14*1]
00007e1ec07debc8  movq xmm13, r12
00007e1ec07debcd  movq xmm12, r11
00007e1ec07debd2  movq xmm13, xmm13
00007e1ec07debd7  vmovaps [rsp+0x10], xmm13
00007e1ec07debdd  movq xmm13, xmm13
00007e1ec07debe2  movaps [r15+0x130], xmm13
00007e1ec07debea  movq xmm12, xmm12
00007e1ec07debef  vmovaps [rsp+0x20], xmm12
00007e1ec07debf5  movq xmm12, xmm12
00007e1ec07debfa  movaps [r15+0x280], xmm12
00007e1ec07dec02  movaps xmm13, [r15+0x270]
00007e1ec07dec0a  vmovaps [rsp+0x30], xmm13
00007e1ec07dec10  vmovaps xmm12, [rsp+0x30]
00007e1ec07dec16  por xmm13, xmm12
00007e1ec07dec1b  lea r14, [rax+0x20]
00007e1ec07dec1f  mov r12, [r13+r14*1]
00007e1ec07dec24  lea r14, [rax+0x28]
00007e1ec07dec28  mov r11, [r13+r14*1]
00007e1ec07dec2d  movq xmm12, r12
00007e1ec07dec32  movq xmm11, r11
00007e1ec07dec37  movq xmm12, xmm12
00007e1ec07dec3c  vmovaps [rsp+0x30], xmm12
00007e1ec07dec42  movq xmm12, xmm12
00007e1ec07dec47  movaps [r15+0x150], xmm12
00007e1ec07dec4f  movq xmm11, xmm11
00007e1ec07dec54  vmovaps [rsp+0x40], xmm11
00007e1ec07dec5a  movq xmm11, xmm11
00007e1ec07dec5f  movaps [r15+0x140], xmm11
00007e1ec07dec67  lea r14, [rax+0x10]
00007e1ec07dec6b  mov r12, [r13+r14*1]
00007e1ec07dec70  lea r14, [rax+0x18]
00007e1ec07dec74  mov r11, [r13+r14*1]
00007e1ec07dec79  movq xmm12, r12
00007e1ec07dec7e  movq xmm11, r11
00007e1ec07dec83  movq xmm12, xmm12
00007e1ec07dec88  vmovaps [rsp+0x50], xmm12
00007e1ec07dec8e  movq xmm12, xmm12
00007e1ec07dec93  movaps [r15+0x170], xmm12
00007e1ec07dec9b  movq xmm11, xmm11
00007e1ec07deca0  vmovaps [rsp+0x60], xmm11
00007e1ec07deca6  movq xmm11, xmm11
00007e1ec07decab  movaps [r15+0x160], xmm11
00007e1ec07decb3  mov r14, [r13+rax*1]
00007e1ec07decb8  vmovq xmm12, r14
00007e1ec07decbd  vpbroadcastq xmm12, xmm12
00007e1ec07decc2  lea r14, [rax+0x08]
00007e1ec07decc6  mov rax, [r13+r14*1]
00007e1ec07deccb  movq xmm11, rax
00007e1ec07decd0  movaps [r15+0x230], xmm11
00007e1ec07decd8  mov rax, [r15+0xF8]
00007e1ec07decdf  lea r14, [rax+0x50]
00007e1ec07dece3  movups xmm11, [r13+r14*1]
00007e1ec07dece9  lea r14, [rax+0x60]
00007e1ec07deced  movups xmm10, [r13+r14*1]
00007e1ec07decf3  lea r14, [rax+0x30]
00007e1ec07decf7  movups xmm9, [r13+r14*1]
00007e1ec07decfd  mov r14, [r15+0x50]
00007e1ec07ded01  mov [r15+0x60], r14
00007e1ec07ded05  mov qword ptr [r15+0x58], 0x40
00007e1ec07ded0d  movaps xmm8, xmm12
00007e1ec07ded11  mulpd xmm8, xmm15
00007e1ec07ded16  vcmppd xmm7, xmm8, xmm8, 0x03
00007e1ec07ded1c  ptest xmm7, xmm7
00007e1ec07ded21  jnz 0x00007E1EC07DFB4A
00007e1ec07ded27  movq xmm15, qword ptr [r15+0x230]
00007e1ec07ded30  vmovaps [rsp+0x70], xmm15
00007e1ec07ded36  vpermilpd xmm15, xmm15, 0x00
00007e1ec07ded3c  movaps xmm7, xmm9
00007e1ec07ded40  mulpd xmm7, xmm15
00007e1ec07ded45  vcmppd xmm6, xmm7, xmm7, 0x03
00007e1ec07ded4a  ptest xmm6, xmm6
00007e1ec07ded4f  jnz 0x00007E1EC07DFC8E
00007e1ec07ded55  vxorps xmm15, xmm15, xmm15
00007e1ec07ded5a  vpbroadcastq xmm15, xmm15
00007e1ec07ded5f  movaps xmm9, xmm12
00007e1ec07ded63  mulpd xmm9, xmm10
00007e1ec07ded68  vcmppd xmm6, xmm9, xmm9, 0x03
00007e1ec07ded6e  ptest xmm6, xmm6
00007e1ec07ded73  jnz 0x00007E1EC07DFDD0
00007e1ec07ded79  movaps xmm10, xmm12
00007e1ec07ded7d  mulpd xmm10, xmm11
00007e1ec07ded82  vcmppd xmm6, xmm10, xmm10, 0x03
00007e1ec07ded88  ptest xmm6, xmm6
00007e1ec07ded8d  jnz 0x00007E1EC07DFF14
00007e1ec07ded93  movaps xmm11, [r15+0x1F0]
00007e1ec07ded9b  movaps xmm6, xmm12
00007e1ec07ded9f  mulpd xmm6, xmm11
00007e1ec07deda4  vcmppd xmm5, xmm6, xmm6, 0x03
00007e1ec07deda9  ptest xmm5, xmm5
00007e1ec07dedae  jnz 0x00007E1EC07E0058
00007e1ec07dedb4  movaps xmm12, [r15+0x2A0]
00007e1ec07dedbc  vmovaps [rsp+0x80], xmm12
00007e1ec07dedc5  vmovaps xmm11, [rsp+0x80]
00007e1ec07dedce  por xmm12, xmm11
00007e1ec07dedd3  movaps xmm11, [r15+0x250]
00007e1ec07deddb  vmovaps [rsp+0x80], xmm11
00007e1ec07dede4  vmovaps xmm5, [rsp+0x80]
00007e1ec07deded  por xmm11, xmm5
00007e1ec07dedf2  vmovaps xmm4, [rsp+0x70]
00007e1ec07dedf8  vpermilpd xmm4, xmm4, 0x00
00007e1ec07dedfe  movaps xmm3, xmm5
00007e1ec07dee01  mulpd xmm3, xmm4
00007e1ec07dee05  vcmppd xmm2, xmm3, xmm3, 0x03
00007e1ec07dee0a  ptest xmm2, xmm2
00007e1ec07dee0f  jnz 0x00007E1EC07E019A
00007e1ec07dee15  mov [rsp+0x80], rax
00007e1ec07dee1d  xor eax, eax
00007e1ec07dee1f  mov r12d, 0x40
00007e1ec07dee25  mov r11d, 0x200
00007e1ec07dee2b  cmp r12, r11
00007e1ec07dee2e  cmc
00007e1ec07dee2f  lahf
00007e1ec07dee30  seto al
00007e1ec07dee33  mov [r15+0x108], eax
00007e1ec07dee3a  movaps xmm5, xmm8
00007e1ec07dee3e  addpd xmm5, xmm15
00007e1ec07dee43  vcmppd xmm4, xmm5, xmm5, 0x03
00007e1ec07dee48  ptest xmm4, xmm4
00007e1ec07dee4d  jnz 0x00007E1EC07E02DA
00007e1ec07dee53  movaps xmm8, [r15+0x1B0]
00007e1ec07dee5b  movaps xmm4, xmm9
00007e1ec07dee5f  addpd xmm4, xmm8
00007e1ec07dee64  vcmppd xmm2, xmm4, xmm4, 0x03
00007e1ec07dee69  ptest xmm2, xmm2
00007e1ec07dee6e  jnz 0x00007E1EC07E041C
00007e1ec07dee74  movaps xmm9, xmm10
00007e1ec07dee78  addpd xmm9, xmm8
00007e1ec07dee7d  vcmppd xmm2, xmm9, xmm9, 0x03
00007e1ec07dee83  ptest xmm2, xmm2
00007e1ec07dee88  jnz 0x00007E1EC07E055E
00007e1ec07dee8e  movaps xmm10, [r15+0x2F0]
00007e1ec07dee96  vmovaps [rsp+0x90], xmm10
00007e1ec07dee9f  vmovaps xmm8, [rsp+0x90]
00007e1ec07deea8  por xmm10, xmm8
00007e1ec07deead  movaps xmm8, [r15+0x2E0]
00007e1ec07deeb5  vmovaps [rsp+0x90], xmm8
00007e1ec07deebe  vmovaps xmm2, [rsp+0x90]
00007e1ec07deec7  por xmm8, xmm2
00007e1ec07deecc  movaps xmm2, [r15+0x2D0]
00007e1ec07deed4  vmovaps [rsp+0x90], xmm2
00007e1ec07deedd  vmovaps [rsp+0xA0], xmm1
00007e1ec07deee6  vmovaps xmm1, [rsp+0x90]
00007e1ec07deeef  por xmm2, xmm1
00007e1ec07deef3  movaps xmm1, [r15+0x200]
00007e1ec07deefb  vmovaps [rsp+0x90], xmm1
00007e1ec07def04  vmovaps [rsp+0xB0], xmm15
00007e1ec07def0d  vmovaps xmm15, [rsp+0x90]
00007e1ec07def16  por xmm1, xmm15
00007e1ec07def1b  movaps xmm15, [r15+0x1C0]
00007e1ec07def23  vmovaps [rsp+0x90], xmm15
00007e1ec07def2c  vmovaps [rsp+0xC0], xmm1
00007e1ec07def35  vmovaps xmm1, [rsp+0x90]
00007e1ec07def3e  por xmm15, xmm1
00007e1ec07def43  movaps xmm1, [r15+0x190]
00007e1ec07def4b  vmovaps [rsp+0x90], xmm1
00007e1ec07def54  vmovaps [rsp+0xD0], xmm15
00007e1ec07def5d  vmovaps xmm15, [rsp+0x90]
00007e1ec07def66  por xmm1, xmm15
00007e1ec07def6b  movaps xmm15, [r15+0x300]
00007e1ec07def73  vmovaps [rsp+0x90], xmm15
00007e1ec07def7c  vmovaps [rsp+0xE0], xmm1
00007e1ec07def85  vmovaps xmm1, [rsp+0x90]
00007e1ec07def8e  por xmm15, xmm1
00007e1ec07def93  mov rax, [rsp+0x80]
00007e1ec07def9b  lea r12, [rax+0xA0]
00007e1ec07defa2  movups xmm1, [r13+r12*1]
00007e1ec07defa8  lea r12, [rax+0xB0]
00007e1ec07defaf  vmovaps [rsp+0x80], xmm1
00007e1ec07defb8  movups xmm1, [r13+r12*1]
00007e1ec07defbe  vmovaps [rsp+0x90], xmm1
00007e1ec07defc7  vmovaps [rsp+0xF0], xmm15
00007e1ec07defd0  vmovaps xmm15, [rsp+0xB0]
00007e1ec07defd9  vmovaps [rsp+0xB0], xmm14
00007e1ec07defe2  movaps xmm1, xmm6
00007e1ec07defe5  addpd xmm1, xmm15
00007e1ec07defea  vcmppd xmm14, xmm1, xmm1, 0x03
00007e1ec07defef  ptest xmm14, xmm14
00007e1ec07deff5  jnz 0x00007E1EC07E06B6
00007e1ec07deffb  lea r12, [rax+0xF0]
00007e1ec07df002  movups xmm15, [r13+r12*1]
00007e1ec07df008  movaps xmm14, xmm4
00007e1ec07df00c  addpd xmm14, xmm3
00007e1ec07df011  vcmppd xmm6, xmm14, xmm14, 0x03
00007e1ec07df017  ptest xmm6, xmm6
00007e1ec07df01c  jnz 0x00007E1EC07E0801
00007e1ec07df022  movaps xmm6, xmm9
00007e1ec07df026  addpd xmm6, xmm7
00007e1ec07df02a  vcmppd xmm4, xmm6, xmm6, 0x03
00007e1ec07df02f  ptest xmm4, xmm4
00007e1ec07df034  jnz 0x00007E1EC07E0943
00007e1ec07df03a  vmovaps xmm9, [rsp+0x70]
00007e1ec07df040  vpermilpd xmm9, xmm9, 0x00
00007e1ec07df046  vmovaps xmm4, [rsp+0x90]
00007e1ec07df04f  movaps xmm7, xmm4
00007e1ec07df052  mulpd xmm7, xmm9
00007e1ec07df057  vcmppd xmm3, xmm7, xmm7, 0x03
00007e1ec07df05c  ptest xmm3, xmm3
00007e1ec07df061  jnz 0x00007E1EC07E0A84
00007e1ec07df067  vmovaps xmm9, [rsp+0x50]
00007e1ec07df06d  vpermilpd xmm9, xmm9, 0x00
00007e1ec07df073  movaps xmm4, xmm15
00007e1ec07df077  mulpd xmm4, xmm9
00007e1ec07df07c  vcmppd xmm3, xmm4, xmm4, 0x03
00007e1ec07df081  ptest xmm3, xmm3
00007e1ec07df086  jnz 0x00007E1EC07E0BC5
00007e1ec07df08c  lea r12, [rax+0xE0]
00007e1ec07df093  movups xmm15, [r13+r12*1]
00007e1ec07df099  vmovaps xmm9, [rsp+0x70]
00007e1ec07df09f  vpermilpd xmm9, xmm9, 0x00
00007e1ec07df0a5  vmovaps [rsp+0x70], xmm1
00007e1ec07df0ab  vmovaps xmm1, [rsp+0x80]
00007e1ec07df0b4  vmovaps [rsp+0x80], xmm15
00007e1ec07df0bd  movaps xmm3, xmm1
00007e1ec07df0c0  mulpd xmm3, xmm9
00007e1ec07df0c5  vcmppd xmm15, xmm3, xmm3, 0x03
00007e1ec07df0ca  ptest xmm15, xmm15
00007e1ec07df0d0  jnz 0x00007E1EC07E0D11
00007e1ec07df0d6  vmovaps xmm1, [rsp+0xF0]
00007e1ec07df0df  vmovaps xmm15, [rsp+0xF0]
00007e1ec07df0e8  por xmm1, xmm15
00007e1ec07df0ed  movaps [r15+0x300], xmm1
00007e1ec07df0f5  vmovaps xmm15, [rsp+0xE0]
00007e1ec07df0fe  vmovaps xmm9, [rsp+0xE0]
00007e1ec07df107  por xmm15, xmm9
00007e1ec07df10c  movaps [r15+0x190], xmm15
00007e1ec07df114  vmovaps xmm9, [rsp+0x50]
00007e1ec07df11a  vpermilpd xmm9, xmm9, 0x00
00007e1ec07df120  vmovaps [rsp+0x90], xmm1
00007e1ec07df129  vmovaps [rsp+0xE0], xmm15
00007e1ec07df132  vmovaps xmm15, [rsp+0x80]
00007e1ec07df13b  vmovaps [rsp+0x80], xmm14
00007e1ec07df144  movaps xmm1, xmm15
00007e1ec07df148  mulpd xmm1, xmm9
00007e1ec07df14d  vcmppd xmm14, xmm1, xmm1, 0x03
00007e1ec07df152  ptest xmm14, xmm14
00007e1ec07df158  jnz 0x00007E1EC07E0E52
00007e1ec07df15e  lea r12, [rax+0x90]
00007e1ec07df165  movups xmm15, [r13+r12*1]
00007e1ec07df16b  vmovaps xmm14, [rsp+0xD0]
00007e1ec07df174  vmovaps xmm9, [rsp+0xD0]
00007e1ec07df17d  por xmm14, xmm9
00007e1ec07df182  movaps [r15+0x1C0], xmm14
00007e1ec07df18a  vmovaps xmm9, [rsp+0xC0]
00007e1ec07df193  vmovaps [rsp+0xD0], xmm1
00007e1ec07df19c  vmovaps xmm1, [rsp+0xC0]
00007e1ec07df1a5  por xmm9, xmm1
00007e1ec07df1aa  movaps [r15+0x200], xmm9
00007e1ec07df1b2  vmovaps [rsp+0xC0], xmm2
00007e1ec07df1bb  vmovaps xmm1, [rsp+0xC0]
00007e1ec07df1c4  por xmm2, xmm1
00007e1ec07df1c8  movaps [r15+0x2D0], xmm2
00007e1ec07df1d0  vmovaps [rsp+0xC0], xmm8
00007e1ec07df1d9  vmovaps xmm1, [rsp+0xC0]
00007e1ec07df1e2  por xmm8, xmm1
00007e1ec07df1e7  movaps [r15+0x2E0], xmm8
00007e1ec07df1ef  vmovaps [rsp+0xC0], xmm15
00007e1ec07df1f8  movaps xmm1, xmm5
00007e1ec07df1fb  addpd xmm1, xmm7
00007e1ec07df1ff  vcmppd xmm15, xmm1, xmm1, 0x03
00007e1ec07df204  ptest xmm15, xmm15
00007e1ec07df20a  jnz 0x00007E1EC07E0F9E
00007e1ec07df210  vmovaps xmm15, [rsp+0x50]
00007e1ec07df216  vpermilpd xmm15, xmm15, 0x00
00007e1ec07df21c  vmovaps xmm5, [rsp+0xC0]
00007e1ec07df225  vmovaps [rsp+0xC0], xmm1
00007e1ec07df22e  movaps xmm7, xmm5
00007e1ec07df231  mulpd xmm7, xmm15
00007e1ec07df236  vcmppd xmm1, xmm7, xmm7, 0x03
00007e1ec07df23b  ptest xmm1, xmm1
00007e1ec07df240  jnz 0x00007E1EC07E10DE
00007e1ec07df246  lea r12, [rax+0x80]
00007e1ec07df24d  movups xmm1, [r13+r12*1]
00007e1ec07df253  vmovaps xmm5, [rsp+0x70]
00007e1ec07df259  vmovaps [rsp+0x70], xmm1
00007e1ec07df25f  movaps xmm15, xmm5
00007e1ec07df263  addpd xmm15, xmm3
00007e1ec07df268  vcmppd xmm1, xmm15, xmm15, 0x03
00007e1ec07df26e  ptest xmm1, xmm1
00007e1ec07df273  jnz 0x00007E1EC07E1229
00007e1ec07df279  vmovaps xmm5, [rsp+0x80]
00007e1ec07df282  movaps xmm1, xmm5
00007e1ec07df285  addpd xmm1, xmm4
00007e1ec07df289  vcmppd xmm3, xmm1, xmm1, 0x03
00007e1ec07df28e  ptest xmm3, xmm3
00007e1ec07df293  jnz 0x00007E1EC07E136B
00007e1ec07df299  vmovaps [rsp+0x80], xmm10
00007e1ec07df2a2  vmovaps xmm5, [rsp+0x80]
00007e1ec07df2ab  por xmm10, xmm5
00007e1ec07df2b0  movaps [r15+0x2F0], xmm10
00007e1ec07df2b8  vmovaps xmm5, [rsp+0x50]
00007e1ec07df2be  vpermilpd xmm5, xmm5, 0x00
00007e1ec07df2c4  vmovaps xmm3, [rsp+0x70]
00007e1ec07df2ca  vmovaps [rsp+0x50], xmm1
00007e1ec07df2d0  movaps xmm4, xmm3
00007e1ec07df2d3  mulpd xmm4, xmm5
00007e1ec07df2d7  vcmppd xmm1, xmm4, xmm4, 0x03
00007e1ec07df2dc  ptest xmm1, xmm1
00007e1ec07df2e1  jnz 0x00007E1EC07E14AB
00007e1ec07df2e7  lea r12, [rax+0xD0]
00007e1ec07df2ee  movups xmm1, [r13+r12*1]
00007e1ec07df2f4  vmovaps xmm3, [rsp+0xD0]
00007e1ec07df2fd  vmovaps [rsp+0x70], xmm1
00007e1ec07df303  movaps xmm5, xmm6
00007e1ec07df306  addpd xmm5, xmm3
00007e1ec07df30a  vcmppd xmm1, xmm5, xmm5, 0x03
00007e1ec07df30f  ptest xmm1, xmm1
00007e1ec07df314  jnz 0x00007E1EC07E15F5
00007e1ec07df31a  vmovaps xmm1, [rsp+0x60]
00007e1ec07df320  vpermilpd xmm1, xmm1, 0x00
00007e1ec07df326  movaps xmm6, xmm9
00007e1ec07df32a  mulpd xmm6, xmm1
00007e1ec07df32e  vcmppd xmm3, xmm6, xmm6, 0x03
00007e1ec07df333  ptest xmm3, xmm3
00007e1ec07df338  jnz 0x00007E1EC07E1735
00007e1ec07df33e  movaps [r15+0x260], xmm6
00007e1ec07df346  vxorps xmm1, xmm1, xmm1
00007e1ec07df34a  vpbroadcastq xmm1, xmm1
00007e1ec07df34f  movaps [r15+0x1B0], xmm1
00007e1ec07df357  vmovaps xmm1, [rsp+0x60]
00007e1ec07df35d  vpermilpd xmm1, xmm1, 0x00
00007e1ec07df363  vmovaps xmm3, [rsp+0x70]
00007e1ec07df369  vmovaps [rsp+0x70], xmm15
00007e1ec07df36f  movaps xmm9, xmm3
00007e1ec07df373  mulpd xmm9, xmm1
00007e1ec07df378  vcmppd xmm15, xmm9, xmm9, 0x03
00007e1ec07df37e  ptest xmm15, xmm15
00007e1ec07df384  jnz 0x00007E1EC07E1876
00007e1ec07df38a  lea r12, [rax+0xC0]
00007e1ec07df391  movups xmm1, [r13+r12*1]
00007e1ec07df397  vmovaps xmm3, [rsp+0xC0]
00007e1ec07df3a0  vmovaps [rsp+0x80], xmm1
00007e1ec07df3a9  movaps xmm15, xmm3
00007e1ec07df3ad  addpd xmm15, xmm7
00007e1ec07df3b2  vcmppd xmm1, xmm15, xmm15, 0x03
00007e1ec07df3b8  ptest xmm1, xmm1
00007e1ec07df3bd  jnz 0x00007E1EC07E19C2
00007e1ec07df3c3  vmovaps [rsp+0xC0], xmm13
00007e1ec07df3cc  vmovaps xmm1, [rsp+0xC0]
00007e1ec07df3d5  por xmm13, xmm1
00007e1ec07df3da  movaps [r15+0x270], xmm13
00007e1ec07df3e2  vmovaps xmm1, [rsp+0xB0]
00007e1ec07df3eb  vmovaps xmm7, [rsp+0xB0]
00007e1ec07df3f4  por xmm1, xmm7
00007e1ec07df3f8  movaps [r15+0x1A0], xmm1
00007e1ec07df400  vmovaps xmm1, [rsp+0x60]
00007e1ec07df406  vpermilpd xmm1, xmm1, 0x00
00007e1ec07df40c  vmovaps [rsp+0xB0], xmm1
00007e1ec07df415  vmovaps xmm1, [rsp+0x80]
00007e1ec07df41e  vmovaps [rsp+0x80], xmm15
00007e1ec07df427  vmovaps xmm15, [rsp+0xB0]
00007e1ec07df430  vmovaps [rsp+0xB0], xmm14
00007e1ec07df439  movaps xmm3, xmm1
00007e1ec07df43c  mulpd xmm3, xmm15
00007e1ec07df441  vcmppd xmm14, xmm3, xmm3, 0x03
00007e1ec07df446  ptest xmm14, xmm14
00007e1ec07df44c  jnz 0x00007E1EC07E1B04
00007e1ec07df452  lea r12, [rax+0x20]
00007e1ec07df456  movups xmm1, [r13+r12*1]
00007e1ec07df45c  movaps [r15+0x110], xmm1
00007e1ec07df464  vmovaps xmm14, [rsp+0x70]
00007e1ec07df46a  vmovaps [rsp+0x70], xmm1
00007e1ec07df470  movaps xmm15, xmm14
00007e1ec07df474  addpd xmm15, xmm4
00007e1ec07df479  vcmppd xmm1, xmm15, xmm15, 0x03
00007e1ec07df47f  ptest xmm1, xmm1
00007e1ec07df484  jnz 0x00007E1EC07E1C4F
00007e1ec07df48a  vmovaps xmm1, [rsp+0x60]
00007e1ec07df490  vpermilpd xmm1, xmm1, 0x00
00007e1ec07df496  movaps xmm14, xmm2
00007e1ec07df49a  mulpd xmm14, xmm1
00007e1ec07df49f  vcmppd xmm4, xmm14, xmm14, 0x03
00007e1ec07df4a5  ptest xmm4, xmm4
00007e1ec07df4aa  jnz 0x00007E1EC07E1D92
00007e1ec07df4b0  vmovaps xmm4, [rsp+0x50]
00007e1ec07df4b6  movaps xmm1, xmm4
00007e1ec07df4b9  addpd xmm1, xmm9
00007e1ec07df4be  vcmppd xmm2, xmm1, xmm1, 0x03
00007e1ec07df4c3  ptest xmm2, xmm2
00007e1ec07df4c8  jnz 0x00007E1EC07E1ED4
00007e1ec07df4ce  vmovaps xmm9, [rsp+0x30]
00007e1ec07df4d4  vpermilpd xmm9, xmm9, 0x00
00007e1ec07df4da  vmovaps xmm2, [rsp+0x70]
00007e1ec07df4e0  vmovaps [rsp+0x50], xmm1
00007e1ec07df4e6  movaps xmm4, xmm2
00007e1ec07df4e9  mulpd xmm4, xmm9
00007e1ec07df4ee  vcmppd xmm1, xmm4, xmm4, 0x03
00007e1ec07df4f3  ptest xmm1, xmm1
00007e1ec07df4f8  jnz 0x00007E1EC07E2015
00007e1ec07df4fe  vmovaps xmm1, [rsp+0x30]
00007e1ec07df504  vpermilpd xmm1, xmm1, 0x00
00007e1ec07df50a  vmovaps xmm2, [rsp+0x90]
00007e1ec07df513  vmovaps [rsp+0x60], xmm15
00007e1ec07df519  movaps xmm9, xmm2
00007e1ec07df51d  mulpd xmm9, xmm1
00007e1ec07df522  vcmppd xmm15, xmm9, xmm9, 0x03
00007e1ec07df528  ptest xmm15, xmm15
00007e1ec07df52e  jnz 0x00007E1EC07E2156
00007e1ec07df534  vmovaps xmm15, [rsp+0x80]
00007e1ec07df53d  movaps xmm1, xmm15
00007e1ec07df541  addpd xmm1, xmm6
00007e1ec07df545  vcmppd xmm2, xmm1, xmm1, 0x03
00007e1ec07df54a  ptest xmm2, xmm2
00007e1ec07df54f  jnz 0x00007E1EC07E2298
00007e1ec07df555  movaps xmm15, xmm5
00007e1ec07df559  addpd xmm15, xmm3
00007e1ec07df55e  vcmppd xmm6, xmm15, xmm15, 0x03
00007e1ec07df564  ptest xmm6, xmm6
00007e1ec07df569  jnz 0x00007E1EC07E23D9
00007e1ec07df56f  vmovaps xmm6, [rsp+0x30]
00007e1ec07df575  vpermilpd xmm6, xmm6, 0x00
00007e1ec07df57b  movaps xmm5, xmm8
00007e1ec07df57f  mulpd xmm5, xmm6
00007e1ec07df583  vcmppd xmm3, xmm5, xmm5, 0x03
00007e1ec07df588  ptest xmm3, xmm3
00007e1ec07df58d  jnz 0x00007E1EC07E251B
00007e1ec07df593  vmovaps xmm8, [rsp+0x30]
00007e1ec07df599  vpermilpd xmm8, xmm8, 0x00
00007e1ec07df59f  movaps xmm6, xmm10
00007e1ec07df5a3  mulpd xmm6, xmm8
00007e1ec07df5a8  vcmppd xmm3, xmm6, xmm6, 0x03
00007e1ec07df5ad  ptest xmm3, xmm3
00007e1ec07df5b2  jnz 0x00007E1EC07E265C
00007e1ec07df5b8  vmovaps xmm8, [rsp+0x60]
00007e1ec07df5be  movaps xmm10, xmm8
00007e1ec07df5c2  addpd xmm10, xmm14
00007e1ec07df5c7  vcmppd xmm3, xmm10, xmm10, 0x03
00007e1ec07df5cd  ptest xmm3, xmm3
00007e1ec07df5d2  jnz 0x00007E1EC07E279E
00007e1ec07df5d8  vmovaps xmm8, [rsp+0x50]
00007e1ec07df5de  movaps xmm14, xmm8
00007e1ec07df5e2  addpd xmm14, xmm4
00007e1ec07df5e7  vcmppd xmm3, xmm14, xmm14, 0x03
00007e1ec07df5ed  ptest xmm3, xmm3
00007e1ec07df5f2  jnz 0x00007E1EC07E28E2
00007e1ec07df5f8  vmovaps xmm8, [rsp+0x40]
00007e1ec07df5fe  vpermilpd xmm8, xmm8, 0x00
00007e1ec07df604  movaps xmm4, xmm13
00007e1ec07df608  mulpd xmm4, xmm8
00007e1ec07df60d  vcmppd xmm3, xmm4, xmm4, 0x03
00007e1ec07df612  ptest xmm3, xmm3
00007e1ec07df617  jnz 0x00007E1EC07E2A25
00007e1ec07df61d  movaps xmm13, xmm15
00007e1ec07df621  addpd xmm13, xmm9
00007e1ec07df626  vcmppd xmm8, xmm13, xmm13, 0x03
00007e1ec07df62c  ptest xmm8, xmm8
00007e1ec07df632  jnz 0x00007E1EC07E2B67
00007e1ec07df638  movaps xmm15, xmm1
00007e1ec07df63c  addpd xmm15, xmm5
00007e1ec07df641  vcmppd xmm9, xmm15, xmm15, 0x03
00007e1ec07df647  ptest xmm9, xmm9
00007e1ec07df64d  jnz 0x00007E1EC07E2CAB
00007e1ec07df653  vmovaps [rsp+0x30], xmm11
00007e1ec07df659  vmovaps xmm1, [rsp+0x30]
00007e1ec07df65f  por xmm11, xmm1
00007e1ec07df664  movaps [r15+0x250], xmm11
00007e1ec07df66c  vmovaps [rsp+0x30], xmm12
00007e1ec07df672  vmovaps xmm1, [rsp+0x30]
00007e1ec07df678  por xmm12, xmm1
00007e1ec07df67d  movaps [r15+0x2A0], xmm12
00007e1ec07df685  vmovaps xmm1, [rsp+0xA0]
00007e1ec07df68e  vmovaps xmm11, [rsp+0xA0]
00007e1ec07df697  por xmm1, xmm11
00007e1ec07df69c  movaps [r15+0x1D0], xmm1
00007e1ec07df6a4  lea r12, [rax+0x40]
00007e1ec07df6a8  movups xmm1, [r13+r12*1]
00007e1ec07df6ae  movaps [r15+0x2C0], xmm1
00007e1ec07df6b6  vmovaps xmm11, [rsp+0x40]
00007e1ec07df6bc  vpermilpd xmm11, xmm11, 0x00
00007e1ec07df6c2  vmovaps xmm8, [rsp+0xE0]
00007e1ec07df6cb  movaps xmm9, xmm8
00007e1ec07df6cf  mulpd xmm9, xmm11
00007e1ec07df6d4  vcmppd xmm5, xmm9, xmm9, 0x03
00007e1ec07df6da  ptest xmm5, xmm5
00007e1ec07df6df  jnz 0x00007E1EC07E2DF7
00007e1ec07df6e5  movaps xmm11, xmm10
00007e1ec07df6e9  addpd xmm11, xmm6
00007e1ec07df6ee  vcmppd xmm8, xmm11, xmm11, 0x03
00007e1ec07df6f4  ptest xmm8, xmm8
00007e1ec07df6fa  jnz 0x00007E1EC07E2F3B
00007e1ec07df700  movaps xmm10, xmm14
00007e1ec07df704  addpd xmm10, xmm4
00007e1ec07df709  vcmppd xmm8, xmm10, xmm10, 0x03
00007e1ec07df70f  ptest xmm8, xmm8
00007e1ec07df715  jnz 0x00007E1EC07E307E
00007e1ec07df71b  vmovaps xmm14, [rsp+0x40]
00007e1ec07df721  vpermilpd xmm14, xmm14, 0x00
00007e1ec07df727  movaps xmm8, xmm1
00007e1ec07df72b  mulpd xmm8, xmm14
00007e1ec07df730  vcmppd xmm6, xmm8, xmm8, 0x03
00007e1ec07df736  ptest xmm6, xmm6
00007e1ec07df73b  jnz 0x00007E1EC07E31C1
00007e1ec07df741  movaps xmm1, [r15+0x2B0]
00007e1ec07df749  vmovaps xmm14, [rsp+0x40]
00007e1ec07df74f  vpermilpd xmm14, xmm14, 0x00
00007e1ec07df755  movaps xmm6, xmm1
00007e1ec07df758  mulpd xmm6, xmm14
00007e1ec07df75d  vcmppd xmm5, xmm6, xmm6, 0x03
00007e1ec07df762  ptest xmm5, xmm5
00007e1ec07df767  jnz 0x00007E1EC07E3304
00007e1ec07df76d  vmovaps xmm1, [rsp+0x10]
00007e1ec07df773  vpermilpd xmm1, xmm1, 0x00
00007e1ec07df779  movaps xmm14, xmm12
00007e1ec07df77d  mulpd xmm14, xmm1
00007e1ec07df782  vcmppd xmm5, xmm14, xmm14, 0x03
00007e1ec07df788  ptest xmm5, xmm5
00007e1ec07df78d  jnz 0x00007E1EC07E3445
00007e1ec07df793  movaps xmm1, xmm13
00007e1ec07df797  addpd xmm1, xmm9
00007e1ec07df79c  vcmppd xmm12, xmm1, xmm1, 0x03
00007e1ec07df7a1  ptest xmm12, xmm12
00007e1ec07df7a7  jnz 0x00007E1EC07E3588
00007e1ec07df7ad  vmovaps xmm13, [rsp+0x10]
00007e1ec07df7b3  vpermilpd xmm13, xmm13, 0x00
00007e1ec07df7b9  movaps xmm12, xmm7
00007e1ec07df7bd  mulpd xmm12, xmm13
00007e1ec07df7c2  vcmppd xmm9, xmm12, xmm12, 0x03
00007e1ec07df7c8  ptest xmm9, xmm9
00007e1ec07df7ce  jnz 0x00007E1EC07E36CA
00007e1ec07df7d4  movaps xmm13, xmm15
00007e1ec07df7d8  addpd xmm13, xmm8
00007e1ec07df7dd  vcmppd xmm9, xmm13, xmm13, 0x03
00007e1ec07df7e3  ptest xmm9, xmm9
00007e1ec07df7e9  jnz 0x00007E1EC07E380D
00007e1ec07df7ef  movaps xmm15, [r15+0x290]
00007e1ec07df7f7  vmovaps xmm9, [rsp+0x10]
00007e1ec07df7fd  vpermilpd xmm9, xmm9, 0x00
00007e1ec07df803  movaps xmm8, xmm15
00007e1ec07df807  mulpd xmm8, xmm9
00007e1ec07df80c  vcmppd xmm7, xmm8, xmm8, 0x03
00007e1ec07df812  ptest xmm7, xmm7
00007e1ec07df817  jnz 0x00007E1EC07E3951
00007e1ec07df81d  movaps xmm15, xmm11
00007e1ec07df821  addpd xmm15, xmm6
00007e1ec07df826  vcmppd xmm9, xmm15, xmm15, 0x03
00007e1ec07df82c  ptest xmm9, xmm9
00007e1ec07df832  jnz 0x00007E1EC07E3A95
00007e1ec07df838  movaps xmm11, [r15+0x1E0]
00007e1ec07df840  vmovaps xmm9, [rsp+0x10]
00007e1ec07df846  vpermilpd xmm9, xmm9, 0x00
00007e1ec07df84c  movaps xmm7, xmm11
00007e1ec07df850  mulpd xmm7, xmm9
00007e1ec07df855  vcmppd xmm6, xmm7, xmm7, 0x03
00007e1ec07df85a  ptest xmm6, xmm6
00007e1ec07df85f  jnz 0x00007E1EC07E3BD8
00007e1ec07df865  movaps xmm11, xmm10
00007e1ec07df869  addpd xmm11, xmm14
00007e1ec07df86e  vcmppd xmm9, xmm11, xmm11, 0x03
00007e1ec07df874  ptest xmm9, xmm9
00007e1ec07df87a  jnz 0x00007E1EC07E3D1A
00007e1ec07df880  lea r12, [rax+0x70]
00007e1ec07df884  movups xmm14, [r13+r12*1]
00007e1ec07df88a  movaps [r15+0x240], xmm14
00007e1ec07df892  movaps xmm10, xmm1
00007e1ec07df896  addpd xmm10, xmm12
00007e1ec07df89b  vcmppd xmm9, xmm10, xmm10, 0x03
00007e1ec07df8a1  ptest xmm9, xmm9
00007e1ec07df8a7  jnz 0x00007E1EC07E3E68
00007e1ec07df8ad  movaps [r15+0x170], xmm10
00007e1ec07df8b5  vmovaps xmm1, [rsp+0x20]
00007e1ec07df8bb  vpermilpd xmm1, xmm1, 0x00
00007e1ec07df8c1  movaps xmm12, xmm14
00007e1ec07df8c5  mulpd xmm12, xmm1
00007e1ec07df8ca  vcmppd xmm9, xmm12, xmm12, 0x03
00007e1ec07df8d0  ptest xmm9, xmm9
00007e1ec07df8d6  jnz 0x00007E1EC07E3FAB
00007e1ec07df8dc  vmovaps xmm1, [rsp+0x20]
00007e1ec07df8e2  vpermilpd xmm1, xmm1, 0x00
00007e1ec07df8e8  vmovaps xmm9, [rsp+0xB0]
00007e1ec07df8f1  movaps xmm14, xmm9
00007e1ec07df8f5  mulpd xmm14, xmm1
00007e1ec07df8fa  vcmppd xmm6, xmm14, xmm14, 0x03
00007e1ec07df900  ptest xmm6, xmm6
00007e1ec07df905  jnz 0x00007E1EC07E40EE
00007e1ec07df90b  movaps [r15+0x180], xmm14
00007e1ec07df913  movaps xmm1, xmm13
00007e1ec07df917  addpd xmm1, xmm8
00007e1ec07df91c  vcmppd xmm9, xmm1, xmm1, 0x03
00007e1ec07df921  ptest xmm9, xmm9
00007e1ec07df927  jnz 0x00007E1EC07E4231
00007e1ec07df92d  movaps [r15+0x210], xmm1
00007e1ec07df935  movups xmm13, [r13+rax*1]
00007e1ec07df93b  lea r12, [rax+0x10]
00007e1ec07df93f  movups xmm9, [r13+r12*1]
00007e1ec07df945  movaps [r15+0x230], xmm9
00007e1ec07df94d  movaps xmm8, xmm15
00007e1ec07df951  addpd xmm8, xmm7
00007e1ec07df956  vcmppd xmm6, xmm8, xmm8, 0x03
00007e1ec07df95c  ptest xmm6, xmm6
00007e1ec07df961  jnz 0x00007E1EC07E4387
00007e1ec07df967  movaps [r15+0x130], xmm8
00007e1ec07df96f  vmovaps xmm15, [rsp+0x20]
00007e1ec07df975  vpermilpd xmm15, xmm15, 0x00
00007e1ec07df97b  movaps xmm7, xmm9
00007e1ec07df97f  mulpd xmm7, xmm15
00007e1ec07df984  vcmppd xmm6, xmm7, xmm7, 0x03
00007e1ec07df989  ptest xmm6, xmm6
00007e1ec07df98e  jnz 0x00007E1EC07E44CA
00007e1ec07df994  movaps [r15+0x220], xmm7
00007e1ec07df99c  vmovaps xmm15, [rsp+0x20]
00007e1ec07df9a2  vpermilpd xmm15, xmm15, 0x00
00007e1ec07df9a8  movaps xmm9, xmm13
00007e1ec07df9ac  mulpd xmm9, xmm15
00007e1ec07df9b1  vcmppd xmm6, xmm9, xmm9, 0x03
00007e1ec07df9b7  ptest xmm6, xmm6
00007e1ec07df9bc  jnz 0x00007E1EC07E460C
00007e1ec07df9c2  movaps xmm15, xmm11
00007e1ec07df9c6  addpd xmm15, xmm12
00007e1ec07df9cb  vcmppd xmm13, xmm15, xmm15, 0x03
00007e1ec07df9d1  ptest xmm13, xmm13
00007e1ec07df9d7  jnz 0x00007E1EC07E4750
00007e1ec07df9dd  movaps [r15+0x140], xmm15
00007e1ec07df9e5  movaps xmm13, xmm10
00007e1ec07df9e9  addpd xmm13, xmm14
00007e1ec07df9ee  vcmppd xmm12, xmm13, xmm13, 0x03
00007e1ec07df9f4  ptest xmm12, xmm12
00007e1ec07df9fa  jnz 0x00007E1EC07E4894
00007e1ec07dfa00  movaps [r15+0x150], xmm13
00007e1ec07dfa08  movaps xmm14, xmm1
00007e1ec07dfa0c  addpd xmm14, xmm7
00007e1ec07dfa11  vcmppd xmm12, xmm14, xmm14, 0x03
00007e1ec07dfa17  ptest xmm12, xmm12
00007e1ec07dfa1d  jnz 0x00007E1EC07E49D8
00007e1ec07dfa23  movaps [r15+0x160], xmm14
00007e1ec07dfa2b  movaps xmm1, xmm8
00007e1ec07dfa2f  addpd xmm1, xmm9
00007e1ec07dfa34  vcmppd xmm12, xmm1, xmm1, 0x03
00007e1ec07dfa39  ptest xmm12, xmm12
00007e1ec07dfa3f  jnz 0x00007E1EC07E4B1A
00007e1ec07dfa45  movaps [r15+0x120], xmm1
00007e1ec07dfa4d  movups [r13+r14*1], xmm15
00007e1ec07dfa53  lea rax, [r14+0x10]
00007e1ec07dfa57  movups [r13+rax*1], xmm13
00007e1ec07dfa5d  lea rax, [r14+0x20]
00007e1ec07dfa61  movups [r13+rax*1], xmm14
00007e1ec07dfa67  lea rax, [r14+0x30]
00007e1ec07dfa6b  movups [r13+rax*1], xmm1
00007e1ec07dfa71  mov eax, [r15+0x108]
00007e1ec07dfa78  sahf
00007e1ec07dfa79  jnz 0x00007E1EC07DFAAB
00007e1ec07dfa7b  cmp dword ptr [r15+0x318], 0x00
00007e1ec07dfa83  jz 0x00007E1EC07DEAE0
00007e1ec07dfa89  nop [rax+rax*1], ax
00007e1ec07dfa92  nop [rax+rax*1], eax
00007e1ec07dfa9a  mov eax, 0x4106D0
00007e1ec07dfa9f  mov [r15+0x100], rax
00007e1ec07dfaa6  jmp 0x00007E1EC05FE110
00007e1ec07dfaab  cmp dword ptr [r15+0x318], 0x00
00007e1ec07dfab3  jz 0x00007E1EC07D89C0
00007e1ec07dfab9  nop [rax+rax*1], ax
00007e1ec07dfac2  nop [rax+rax*1], eax
00007e1ec07dfaca  mov eax, 0x410504
00007e1ec07dfacf  mov [r15+0x100], rax
00007e1ec07dfad6  jmp 0x00007E1EC05FE110
00007e1ec07dfadb  int3
00007e1ec07dfadc  call 0x00007E1EC06E27E0
00007e1ec07dfae1  jmp 0x00007E1EC07DEBBF
00007e1ec07dfae6  call 0x00007E1EC06E1570
00007e1ec07dfaeb  jmp 0x00007E1EC07DEBC8
00007e1ec07dfaf0  call 0x00007E1EC06E27E0
00007e1ec07dfaf5  jmp 0x00007E1EC07DEC24
00007e1ec07dfafa  call 0x00007E1EC06E1570
00007e1ec07dfaff  jmp 0x00007E1EC07DEC2D
00007e1ec07dfb04  call 0x00007E1EC06E27E0
00007e1ec07dfb09  jmp 0x00007E1EC07DEC70
00007e1ec07dfb0e  call 0x00007E1EC06E1570
00007e1ec07dfb13  jmp 0x00007E1EC07DEC79
00007e1ec07dfb18  call 0x00007E1EC060DC20
00007e1ec07dfb1d  jmp 0x00007E1EC07DECB8
00007e1ec07dfb22  call 0x00007E1EC06D59C0
00007e1ec07dfb27  jmp 0x00007E1EC07DECCB
00007e1ec07dfb2c  call 0x00007E1EC06E0E30
00007e1ec07dfb31  jmp 0x00007E1EC07DECE9
00007e1ec07dfb36  call 0x00007E1EC06DFBC0
00007e1ec07dfb3b  jmp 0x00007E1EC07DECF3
00007e1ec07dfb40  call 0x00007E1EC06DE950
00007e1ec07dfb45  jmp 0x00007E1EC07DECFD
00007e1ec07dfb4a  sub rsp, 0x08
00007e1ec07dfb4e  push rax
00007e1ec07dfb4f  push rcx
00007e1ec07dfb50  push rdx
00007e1ec07dfb51  push rdi
00007e1ec07dfb52  push rsi
00007e1ec07dfb53  push r8
00007e1ec07dfb55  push r9
00007e1ec07dfb57  push r10
00007e1ec07dfb59  push r11
00007e1ec07dfb5b  sub rsp, 0xF0
00007e1ec07dfb62  vmovaps [rsp], xmm0
00007e1ec07dfb67  vmovaps [rsp+0x10], xmm1
00007e1ec07dfb6d  vmovaps [rsp+0x20], xmm2
00007e1ec07dfb73  vmovaps [rsp+0x30], xmm3
00007e1ec07dfb79  vmovaps [rsp+0x40], xmm4
00007e1ec07dfb7f  vmovaps [rsp+0x50], xmm5
00007e1ec07dfb85  vmovaps [rsp+0x60], xmm6
00007e1ec07dfb8b  vmovaps [rsp+0x70], xmm7
00007e1ec07dfb91  vmovaps [rsp+0x80], xmm9
00007e1ec07dfb9a  vmovaps [rsp+0x90], xmm10
00007e1ec07dfba3  vmovaps [rsp+0xA0], xmm11
00007e1ec07dfbac  vmovaps [rsp+0xB0], xmm12
00007e1ec07dfbb5  vmovaps [rsp+0xC0], xmm13
00007e1ec07dfbbe  vmovaps [rsp+0xD0], xmm14
00007e1ec07dfbc7  vmovaps [rsp+0xE0], xmm15
00007e1ec07dfbd0  sub rsp, 0x30
00007e1ec07dfbd4  movaps [rsp], xmm8
00007e1ec07dfbd9  movaps [rsp+0x10], xmm12
00007e1ec07dfbdf  movaps [rsp+0x20], xmm15
00007e1ec07dfbe5  lea rdi, [rsp]
00007e1ec07dfbe9  mov esi, 0x00
00007e1ec07dfbee  mov rax, 0x5E00FF778530
00007e1ec07dfbf8  call rax
00007e1ec07dfbfa  movaps xmm8, [rsp]
00007e1ec07dfbff  add rsp, 0x30
00007e1ec07dfc03  vmovaps xmm0, [rsp]
00007e1ec07dfc08  vmovaps xmm1, [rsp+0x10]
00007e1ec07dfc0e  vmovaps xmm2, [rsp+0x20]
00007e1ec07dfc14  vmovaps xmm3, [rsp+0x30]
00007e1ec07dfc1a  vmovaps xmm4, [rsp+0x40]
00007e1ec07dfc20  vmovaps xmm5, [rsp+0x50]
00007e1ec07dfc26  vmovaps xmm6, [rsp+0x60]
00007e1ec07dfc2c  vmovaps xmm7, [rsp+0x70]
00007e1ec07dfc32  vmovaps xmm9, [rsp+0x80]
00007e1ec07dfc3b  vmovaps xmm10, [rsp+0x90]
00007e1ec07dfc44  vmovaps xmm11, [rsp+0xA0]
00007e1ec07dfc4d  vmovaps xmm12, [rsp+0xB0]
00007e1ec07dfc56  vmovaps xmm13, [rsp+0xC0]
00007e1ec07dfc5f  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dfc68  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dfc71  add rsp, 0xF0
00007e1ec07dfc78  pop r11
00007e1ec07dfc7a  pop r10
00007e1ec07dfc7c  pop r9
00007e1ec07dfc7e  pop r8
00007e1ec07dfc80  pop rsi
00007e1ec07dfc81  pop rdi
00007e1ec07dfc82  pop rdx
00007e1ec07dfc83  pop rcx
00007e1ec07dfc84  pop rax
00007e1ec07dfc85  add rsp, 0x08
00007e1ec07dfc89  jmp 0x00007E1EC07DED27
00007e1ec07dfc8e  sub rsp, 0x08
00007e1ec07dfc92  push rax
00007e1ec07dfc93  push rcx
00007e1ec07dfc94  push rdx
00007e1ec07dfc95  push rdi
00007e1ec07dfc96  push rsi
00007e1ec07dfc97  push r8
00007e1ec07dfc99  push r9
00007e1ec07dfc9b  push r10
00007e1ec07dfc9d  push r11
00007e1ec07dfc9f  sub rsp, 0xF0
00007e1ec07dfca6  vmovaps [rsp], xmm0
00007e1ec07dfcab  vmovaps [rsp+0x10], xmm1
00007e1ec07dfcb1  vmovaps [rsp+0x20], xmm2
00007e1ec07dfcb7  vmovaps [rsp+0x30], xmm3
00007e1ec07dfcbd  vmovaps [rsp+0x40], xmm4
00007e1ec07dfcc3  vmovaps [rsp+0x50], xmm5
00007e1ec07dfcc9  vmovaps [rsp+0x60], xmm6
00007e1ec07dfccf  vmovaps [rsp+0x70], xmm8
00007e1ec07dfcd5  vmovaps [rsp+0x80], xmm9
00007e1ec07dfcde  vmovaps [rsp+0x90], xmm10
00007e1ec07dfce7  vmovaps [rsp+0xA0], xmm11
00007e1ec07dfcf0  vmovaps [rsp+0xB0], xmm12
00007e1ec07dfcf9  vmovaps [rsp+0xC0], xmm13
00007e1ec07dfd02  vmovaps [rsp+0xD0], xmm14
00007e1ec07dfd0b  vmovaps [rsp+0xE0], xmm15
00007e1ec07dfd14  sub rsp, 0x30
00007e1ec07dfd18  movaps [rsp], xmm7
00007e1ec07dfd1c  movaps [rsp+0x10], xmm9
00007e1ec07dfd22  movaps [rsp+0x20], xmm15
00007e1ec07dfd28  lea rdi, [rsp]
00007e1ec07dfd2c  mov esi, 0x00
00007e1ec07dfd31  mov rax, 0x5E00FF778530
00007e1ec07dfd3b  call rax
00007e1ec07dfd3d  movaps xmm7, [rsp]
00007e1ec07dfd41  add rsp, 0x30
00007e1ec07dfd45  vmovaps xmm0, [rsp]
00007e1ec07dfd4a  vmovaps xmm1, [rsp+0x10]
00007e1ec07dfd50  vmovaps xmm2, [rsp+0x20]
00007e1ec07dfd56  vmovaps xmm3, [rsp+0x30]
00007e1ec07dfd5c  vmovaps xmm4, [rsp+0x40]
00007e1ec07dfd62  vmovaps xmm5, [rsp+0x50]
00007e1ec07dfd68  vmovaps xmm6, [rsp+0x60]
00007e1ec07dfd6e  vmovaps xmm8, [rsp+0x70]
00007e1ec07dfd74  vmovaps xmm9, [rsp+0x80]
00007e1ec07dfd7d  vmovaps xmm10, [rsp+0x90]
00007e1ec07dfd86  vmovaps xmm11, [rsp+0xA0]
00007e1ec07dfd8f  vmovaps xmm12, [rsp+0xB0]
00007e1ec07dfd98  vmovaps xmm13, [rsp+0xC0]
00007e1ec07dfda1  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dfdaa  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dfdb3  add rsp, 0xF0
00007e1ec07dfdba  pop r11
00007e1ec07dfdbc  pop r10
00007e1ec07dfdbe  pop r9
00007e1ec07dfdc0  pop r8
00007e1ec07dfdc2  pop rsi
00007e1ec07dfdc3  pop rdi
00007e1ec07dfdc4  pop rdx
00007e1ec07dfdc5  pop rcx
00007e1ec07dfdc6  pop rax
00007e1ec07dfdc7  add rsp, 0x08
00007e1ec07dfdcb  jmp 0x00007E1EC07DED55
00007e1ec07dfdd0  sub rsp, 0x08
00007e1ec07dfdd4  push rax
00007e1ec07dfdd5  push rcx
00007e1ec07dfdd6  push rdx
00007e1ec07dfdd7  push rdi
00007e1ec07dfdd8  push rsi
00007e1ec07dfdd9  push r8
00007e1ec07dfddb  push r9
00007e1ec07dfddd  push r10
00007e1ec07dfddf  push r11
00007e1ec07dfde1  sub rsp, 0xF0
00007e1ec07dfde8  vmovaps [rsp], xmm0
00007e1ec07dfded  vmovaps [rsp+0x10], xmm1
00007e1ec07dfdf3  vmovaps [rsp+0x20], xmm2
00007e1ec07dfdf9  vmovaps [rsp+0x30], xmm3
00007e1ec07dfdff  vmovaps [rsp+0x40], xmm4
00007e1ec07dfe05  vmovaps [rsp+0x50], xmm5
00007e1ec07dfe0b  vmovaps [rsp+0x60], xmm6
00007e1ec07dfe11  vmovaps [rsp+0x70], xmm7
00007e1ec07dfe17  vmovaps [rsp+0x80], xmm8
00007e1ec07dfe20  vmovaps [rsp+0x90], xmm10
00007e1ec07dfe29  vmovaps [rsp+0xA0], xmm11
00007e1ec07dfe32  vmovaps [rsp+0xB0], xmm12
00007e1ec07dfe3b  vmovaps [rsp+0xC0], xmm13
00007e1ec07dfe44  vmovaps [rsp+0xD0], xmm14
00007e1ec07dfe4d  vmovaps [rsp+0xE0], xmm15
00007e1ec07dfe56  sub rsp, 0x30
00007e1ec07dfe5a  movaps [rsp], xmm9
00007e1ec07dfe5f  movaps [rsp+0x10], xmm12
00007e1ec07dfe65  movaps [rsp+0x20], xmm10
00007e1ec07dfe6b  lea rdi, [rsp]
00007e1ec07dfe6f  mov esi, 0x00
00007e1ec07dfe74  mov rax, 0x5E00FF778530
00007e1ec07dfe7e  call rax
00007e1ec07dfe80  movaps xmm9, [rsp]
00007e1ec07dfe85  add rsp, 0x30
00007e1ec07dfe89  vmovaps xmm0, [rsp]
00007e1ec07dfe8e  vmovaps xmm1, [rsp+0x10]
00007e1ec07dfe94  vmovaps xmm2, [rsp+0x20]
00007e1ec07dfe9a  vmovaps xmm3, [rsp+0x30]
00007e1ec07dfea0  vmovaps xmm4, [rsp+0x40]
00007e1ec07dfea6  vmovaps xmm5, [rsp+0x50]
00007e1ec07dfeac  vmovaps xmm6, [rsp+0x60]
00007e1ec07dfeb2  vmovaps xmm7, [rsp+0x70]
00007e1ec07dfeb8  vmovaps xmm8, [rsp+0x80]
00007e1ec07dfec1  vmovaps xmm10, [rsp+0x90]
00007e1ec07dfeca  vmovaps xmm11, [rsp+0xA0]
00007e1ec07dfed3  vmovaps xmm12, [rsp+0xB0]
00007e1ec07dfedc  vmovaps xmm13, [rsp+0xC0]
00007e1ec07dfee5  vmovaps xmm14, [rsp+0xD0]
00007e1ec07dfeee  vmovaps xmm15, [rsp+0xE0]
00007e1ec07dfef7  add rsp, 0xF0
00007e1ec07dfefe  pop r11
00007e1ec07dff00  pop r10
00007e1ec07dff02  pop r9
00007e1ec07dff04  pop r8
00007e1ec07dff06  pop rsi
00007e1ec07dff07  pop rdi
00007e1ec07dff08  pop rdx
00007e1ec07dff09  pop rcx
00007e1ec07dff0a  pop rax
00007e1ec07dff0b  add rsp, 0x08
00007e1ec07dff0f  jmp 0x00007E1EC07DED79
00007e1ec07dff14  sub rsp, 0x08
00007e1ec07dff18  push rax
00007e1ec07dff19  push rcx
00007e1ec07dff1a  push rdx
00007e1ec07dff1b  push rdi
00007e1ec07dff1c  push rsi
00007e1ec07dff1d  push r8
00007e1ec07dff1f  push r9
00007e1ec07dff21  push r10
00007e1ec07dff23  push r11
00007e1ec07dff25  sub rsp, 0xF0
00007e1ec07dff2c  vmovaps [rsp], xmm0
00007e1ec07dff31  vmovaps [rsp+0x10], xmm1
00007e1ec07dff37  vmovaps [rsp+0x20], xmm2
00007e1ec07dff3d  vmovaps [rsp+0x30], xmm3
00007e1ec07dff43  vmovaps [rsp+0x40], xmm4
00007e1ec07dff49  vmovaps [rsp+0x50], xmm5
00007e1ec07dff4f  vmovaps [rsp+0x60], xmm6
00007e1ec07dff55  vmovaps [rsp+0x70], xmm7
00007e1ec07dff5b  vmovaps [rsp+0x80], xmm8
00007e1ec07dff64  vmovaps [rsp+0x90], xmm9
00007e1ec07dff6d  vmovaps [rsp+0xA0], xmm11
00007e1ec07dff76  vmovaps [rsp+0xB0], xmm12
00007e1ec07dff7f  vmovaps [rsp+0xC0], xmm13
00007e1ec07dff88  vmovaps [rsp+0xD0], xmm14
00007e1ec07dff91  vmovaps [rsp+0xE0], xmm15
00007e1ec07dff9a  sub rsp, 0x30
00007e1ec07dff9e  movaps [rsp], xmm10
00007e1ec07dffa3  movaps [rsp+0x10], xmm12
00007e1ec07dffa9  movaps [rsp+0x20], xmm11
00007e1ec07dffaf  lea rdi, [rsp]
00007e1ec07dffb3  mov esi, 0x00
00007e1ec07dffb8  mov rax, 0x5E00FF778530
00007e1ec07dffc2  call rax
00007e1ec07dffc4  movaps xmm10, [rsp]
00007e1ec07dffc9  add rsp, 0x30
00007e1ec07dffcd  vmovaps xmm0, [rsp]
00007e1ec07dffd2  vmovaps xmm1, [rsp+0x10]
00007e1ec07dffd8  vmovaps xmm2, [rsp+0x20]
00007e1ec07dffde  vmovaps xmm3, [rsp+0x30]
00007e1ec07dffe4  vmovaps xmm4, [rsp+0x40]
00007e1ec07dffea  vmovaps xmm5, [rsp+0x50]
00007e1ec07dfff0  vmovaps xmm6, [rsp+0x60]
00007e1ec07dfff6  vmovaps xmm7, [rsp+0x70]
00007e1ec07dfffc  vmovaps xmm8, [rsp+0x80]
00007e1ec07e0005  vmovaps xmm9, [rsp+0x90]
00007e1ec07e000e  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e0017  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e0020  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e0029  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e0032  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e003b  add rsp, 0xF0
00007e1ec07e0042  pop r11
00007e1ec07e0044  pop r10
00007e1ec07e0046  pop r9
00007e1ec07e0048  pop r8
00007e1ec07e004a  pop rsi
00007e1ec07e004b  pop rdi
00007e1ec07e004c  pop rdx
00007e1ec07e004d  pop rcx
00007e1ec07e004e  pop rax
00007e1ec07e004f  add rsp, 0x08
00007e1ec07e0053  jmp 0x00007E1EC07DED93
00007e1ec07e0058  sub rsp, 0x08
00007e1ec07e005c  push rax
00007e1ec07e005d  push rcx
00007e1ec07e005e  push rdx
00007e1ec07e005f  push rdi
00007e1ec07e0060  push rsi
00007e1ec07e0061  push r8
00007e1ec07e0063  push r9
00007e1ec07e0065  push r10
00007e1ec07e0067  push r11
00007e1ec07e0069  sub rsp, 0xF0
00007e1ec07e0070  vmovaps [rsp], xmm0
00007e1ec07e0075  vmovaps [rsp+0x10], xmm1
00007e1ec07e007b  vmovaps [rsp+0x20], xmm2
00007e1ec07e0081  vmovaps [rsp+0x30], xmm3
00007e1ec07e0087  vmovaps [rsp+0x40], xmm4
00007e1ec07e008d  vmovaps [rsp+0x50], xmm5
00007e1ec07e0093  vmovaps [rsp+0x60], xmm7
00007e1ec07e0099  vmovaps [rsp+0x70], xmm8
00007e1ec07e009f  vmovaps [rsp+0x80], xmm9
00007e1ec07e00a8  vmovaps [rsp+0x90], xmm10
00007e1ec07e00b1  vmovaps [rsp+0xA0], xmm11
00007e1ec07e00ba  vmovaps [rsp+0xB0], xmm12
00007e1ec07e00c3  vmovaps [rsp+0xC0], xmm13
00007e1ec07e00cc  vmovaps [rsp+0xD0], xmm14
00007e1ec07e00d5  vmovaps [rsp+0xE0], xmm15
00007e1ec07e00de  sub rsp, 0x30
00007e1ec07e00e2  movaps [rsp], xmm6
00007e1ec07e00e6  movaps [rsp+0x10], xmm12
00007e1ec07e00ec  movaps [rsp+0x20], xmm11
00007e1ec07e00f2  lea rdi, [rsp]
00007e1ec07e00f6  mov esi, 0x00
00007e1ec07e00fb  mov rax, 0x5E00FF778530
00007e1ec07e0105  call rax
00007e1ec07e0107  movaps xmm6, [rsp]
00007e1ec07e010b  add rsp, 0x30
00007e1ec07e010f  vmovaps xmm0, [rsp]
00007e1ec07e0114  vmovaps xmm1, [rsp+0x10]
00007e1ec07e011a  vmovaps xmm2, [rsp+0x20]
00007e1ec07e0120  vmovaps xmm3, [rsp+0x30]
00007e1ec07e0126  vmovaps xmm4, [rsp+0x40]
00007e1ec07e012c  vmovaps xmm5, [rsp+0x50]
00007e1ec07e0132  vmovaps xmm7, [rsp+0x60]
00007e1ec07e0138  vmovaps xmm8, [rsp+0x70]
00007e1ec07e013e  vmovaps xmm9, [rsp+0x80]
00007e1ec07e0147  vmovaps xmm10, [rsp+0x90]
00007e1ec07e0150  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e0159  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e0162  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e016b  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e0174  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e017d  add rsp, 0xF0
00007e1ec07e0184  pop r11
00007e1ec07e0186  pop r10
00007e1ec07e0188  pop r9
00007e1ec07e018a  pop r8
00007e1ec07e018c  pop rsi
00007e1ec07e018d  pop rdi
00007e1ec07e018e  pop rdx
00007e1ec07e018f  pop rcx
00007e1ec07e0190  pop rax
00007e1ec07e0191  add rsp, 0x08
00007e1ec07e0195  jmp 0x00007E1EC07DEDB4
00007e1ec07e019a  sub rsp, 0x08
00007e1ec07e019e  push rax
00007e1ec07e019f  push rcx
00007e1ec07e01a0  push rdx
00007e1ec07e01a1  push rdi
00007e1ec07e01a2  push rsi
00007e1ec07e01a3  push r8
00007e1ec07e01a5  push r9
00007e1ec07e01a7  push r10
00007e1ec07e01a9  push r11
00007e1ec07e01ab  sub rsp, 0xF0
00007e1ec07e01b2  vmovaps [rsp], xmm0
00007e1ec07e01b7  vmovaps [rsp+0x10], xmm1
00007e1ec07e01bd  vmovaps [rsp+0x20], xmm2
00007e1ec07e01c3  vmovaps [rsp+0x30], xmm4
00007e1ec07e01c9  vmovaps [rsp+0x40], xmm5
00007e1ec07e01cf  vmovaps [rsp+0x50], xmm6
00007e1ec07e01d5  vmovaps [rsp+0x60], xmm7
00007e1ec07e01db  vmovaps [rsp+0x70], xmm8
00007e1ec07e01e1  vmovaps [rsp+0x80], xmm9
00007e1ec07e01ea  vmovaps [rsp+0x90], xmm10
00007e1ec07e01f3  vmovaps [rsp+0xA0], xmm11
00007e1ec07e01fc  vmovaps [rsp+0xB0], xmm12
00007e1ec07e0205  vmovaps [rsp+0xC0], xmm13
00007e1ec07e020e  vmovaps [rsp+0xD0], xmm14
00007e1ec07e0217  vmovaps [rsp+0xE0], xmm15
00007e1ec07e0220  sub rsp, 0x30
00007e1ec07e0224  movaps [rsp], xmm3
00007e1ec07e0228  movaps [rsp+0x10], xmm5
00007e1ec07e022d  movaps [rsp+0x20], xmm4
00007e1ec07e0232  lea rdi, [rsp]
00007e1ec07e0236  mov esi, 0x00
00007e1ec07e023b  mov rax, 0x5E00FF778530
00007e1ec07e0245  call rax
00007e1ec07e0247  movaps xmm3, [rsp]
00007e1ec07e024b  add rsp, 0x30
00007e1ec07e024f  vmovaps xmm0, [rsp]
00007e1ec07e0254  vmovaps xmm1, [rsp+0x10]
00007e1ec07e025a  vmovaps xmm2, [rsp+0x20]
00007e1ec07e0260  vmovaps xmm4, [rsp+0x30]
00007e1ec07e0266  vmovaps xmm5, [rsp+0x40]
00007e1ec07e026c  vmovaps xmm6, [rsp+0x50]
00007e1ec07e0272  vmovaps xmm7, [rsp+0x60]
00007e1ec07e0278  vmovaps xmm8, [rsp+0x70]
00007e1ec07e027e  vmovaps xmm9, [rsp+0x80]
00007e1ec07e0287  vmovaps xmm10, [rsp+0x90]
00007e1ec07e0290  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e0299  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e02a2  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e02ab  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e02b4  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e02bd  add rsp, 0xF0
00007e1ec07e02c4  pop r11
00007e1ec07e02c6  pop r10
00007e1ec07e02c8  pop r9
00007e1ec07e02ca  pop r8
00007e1ec07e02cc  pop rsi
00007e1ec07e02cd  pop rdi
00007e1ec07e02ce  pop rdx
00007e1ec07e02cf  pop rcx
00007e1ec07e02d0  pop rax
00007e1ec07e02d1  add rsp, 0x08
00007e1ec07e02d5  jmp 0x00007E1EC07DEE15
00007e1ec07e02da  sub rsp, 0x08
00007e1ec07e02de  push rax
00007e1ec07e02df  push rcx
00007e1ec07e02e0  push rdx
00007e1ec07e02e1  push rdi
00007e1ec07e02e2  push rsi
00007e1ec07e02e3  push r8
00007e1ec07e02e5  push r9
00007e1ec07e02e7  push r10
00007e1ec07e02e9  push r11
00007e1ec07e02eb  sub rsp, 0xF0
00007e1ec07e02f2  vmovaps [rsp], xmm0
00007e1ec07e02f7  vmovaps [rsp+0x10], xmm1
00007e1ec07e02fd  vmovaps [rsp+0x20], xmm2
00007e1ec07e0303  vmovaps [rsp+0x30], xmm3
00007e1ec07e0309  vmovaps [rsp+0x40], xmm4
00007e1ec07e030f  vmovaps [rsp+0x50], xmm6
00007e1ec07e0315  vmovaps [rsp+0x60], xmm7
00007e1ec07e031b  vmovaps [rsp+0x70], xmm8
00007e1ec07e0321  vmovaps [rsp+0x80], xmm9
00007e1ec07e032a  vmovaps [rsp+0x90], xmm10
00007e1ec07e0333  vmovaps [rsp+0xA0], xmm11
00007e1ec07e033c  vmovaps [rsp+0xB0], xmm12
00007e1ec07e0345  vmovaps [rsp+0xC0], xmm13
00007e1ec07e034e  vmovaps [rsp+0xD0], xmm14
00007e1ec07e0357  vmovaps [rsp+0xE0], xmm15
00007e1ec07e0360  sub rsp, 0x30
00007e1ec07e0364  movaps [rsp], xmm5
00007e1ec07e0368  movaps [rsp+0x10], xmm8
00007e1ec07e036e  movaps [rsp+0x20], xmm15
00007e1ec07e0374  lea rdi, [rsp]
00007e1ec07e0378  mov esi, 0x00
00007e1ec07e037d  mov rax, 0x5E00FF778530
00007e1ec07e0387  call rax
00007e1ec07e0389  movaps xmm5, [rsp]
00007e1ec07e038d  add rsp, 0x30
00007e1ec07e0391  vmovaps xmm0, [rsp]
00007e1ec07e0396  vmovaps xmm1, [rsp+0x10]
00007e1ec07e039c  vmovaps xmm2, [rsp+0x20]
00007e1ec07e03a2  vmovaps xmm3, [rsp+0x30]
00007e1ec07e03a8  vmovaps xmm4, [rsp+0x40]
00007e1ec07e03ae  vmovaps xmm6, [rsp+0x50]
00007e1ec07e03b4  vmovaps xmm7, [rsp+0x60]
00007e1ec07e03ba  vmovaps xmm8, [rsp+0x70]
00007e1ec07e03c0  vmovaps xmm9, [rsp+0x80]
00007e1ec07e03c9  vmovaps xmm10, [rsp+0x90]
00007e1ec07e03d2  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e03db  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e03e4  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e03ed  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e03f6  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e03ff  add rsp, 0xF0
00007e1ec07e0406  pop r11
00007e1ec07e0408  pop r10
00007e1ec07e040a  pop r9
00007e1ec07e040c  pop r8
00007e1ec07e040e  pop rsi
00007e1ec07e040f  pop rdi
00007e1ec07e0410  pop rdx
00007e1ec07e0411  pop rcx
00007e1ec07e0412  pop rax
00007e1ec07e0413  add rsp, 0x08
00007e1ec07e0417  jmp 0x00007E1EC07DEE53
00007e1ec07e041c  sub rsp, 0x08
00007e1ec07e0420  push rax
00007e1ec07e0421  push rcx
00007e1ec07e0422  push rdx
00007e1ec07e0423  push rdi
00007e1ec07e0424  push rsi
00007e1ec07e0425  push r8
00007e1ec07e0427  push r9
00007e1ec07e0429  push r10
00007e1ec07e042b  push r11
00007e1ec07e042d  sub rsp, 0xF0
00007e1ec07e0434  vmovaps [rsp], xmm0
00007e1ec07e0439  vmovaps [rsp+0x10], xmm1
00007e1ec07e043f  vmovaps [rsp+0x20], xmm2
00007e1ec07e0445  vmovaps [rsp+0x30], xmm3
00007e1ec07e044b  vmovaps [rsp+0x40], xmm5
00007e1ec07e0451  vmovaps [rsp+0x50], xmm6
00007e1ec07e0457  vmovaps [rsp+0x60], xmm7
00007e1ec07e045d  vmovaps [rsp+0x70], xmm8
00007e1ec07e0463  vmovaps [rsp+0x80], xmm9
00007e1ec07e046c  vmovaps [rsp+0x90], xmm10
00007e1ec07e0475  vmovaps [rsp+0xA0], xmm11
00007e1ec07e047e  vmovaps [rsp+0xB0], xmm12
00007e1ec07e0487  vmovaps [rsp+0xC0], xmm13
00007e1ec07e0490  vmovaps [rsp+0xD0], xmm14
00007e1ec07e0499  vmovaps [rsp+0xE0], xmm15
00007e1ec07e04a2  sub rsp, 0x30
00007e1ec07e04a6  movaps [rsp], xmm4
00007e1ec07e04aa  movaps [rsp+0x10], xmm9
00007e1ec07e04b0  movaps [rsp+0x20], xmm8
00007e1ec07e04b6  lea rdi, [rsp]
00007e1ec07e04ba  mov esi, 0x00
00007e1ec07e04bf  mov rax, 0x5E00FF778530
00007e1ec07e04c9  call rax
00007e1ec07e04cb  movaps xmm4, [rsp]
00007e1ec07e04cf  add rsp, 0x30
00007e1ec07e04d3  vmovaps xmm0, [rsp]
00007e1ec07e04d8  vmovaps xmm1, [rsp+0x10]
00007e1ec07e04de  vmovaps xmm2, [rsp+0x20]
00007e1ec07e04e4  vmovaps xmm3, [rsp+0x30]
00007e1ec07e04ea  vmovaps xmm5, [rsp+0x40]
00007e1ec07e04f0  vmovaps xmm6, [rsp+0x50]
00007e1ec07e04f6  vmovaps xmm7, [rsp+0x60]
00007e1ec07e04fc  vmovaps xmm8, [rsp+0x70]
00007e1ec07e0502  vmovaps xmm9, [rsp+0x80]
00007e1ec07e050b  vmovaps xmm10, [rsp+0x90]
00007e1ec07e0514  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e051d  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e0526  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e052f  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e0538  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e0541  add rsp, 0xF0
00007e1ec07e0548  pop r11
00007e1ec07e054a  pop r10
00007e1ec07e054c  pop r9
00007e1ec07e054e  pop r8
00007e1ec07e0550  pop rsi
00007e1ec07e0551  pop rdi
00007e1ec07e0552  pop rdx
00007e1ec07e0553  pop rcx
00007e1ec07e0554  pop rax
00007e1ec07e0555  add rsp, 0x08
00007e1ec07e0559  jmp 0x00007E1EC07DEE74
00007e1ec07e055e  sub rsp, 0x08
00007e1ec07e0562  push rax
00007e1ec07e0563  push rcx
00007e1ec07e0564  push rdx
00007e1ec07e0565  push rdi
00007e1ec07e0566  push rsi
00007e1ec07e0567  push r8
00007e1ec07e0569  push r9
00007e1ec07e056b  push r10
00007e1ec07e056d  push r11
00007e1ec07e056f  sub rsp, 0xF0
00007e1ec07e0576  vmovaps [rsp], xmm0
00007e1ec07e057b  vmovaps [rsp+0x10], xmm1
00007e1ec07e0581  vmovaps [rsp+0x20], xmm2
00007e1ec07e0587  vmovaps [rsp+0x30], xmm3
00007e1ec07e058d  vmovaps [rsp+0x40], xmm4
00007e1ec07e0593  vmovaps [rsp+0x50], xmm5
00007e1ec07e0599  vmovaps [rsp+0x60], xmm6
00007e1ec07e059f  vmovaps [rsp+0x70], xmm7
00007e1ec07e05a5  vmovaps [rsp+0x80], xmm8
00007e1ec07e05ae  vmovaps [rsp+0x90], xmm10
00007e1ec07e05b7  vmovaps [rsp+0xA0], xmm11
00007e1ec07e05c0  vmovaps [rsp+0xB0], xmm12
00007e1ec07e05c9  vmovaps [rsp+0xC0], xmm13
00007e1ec07e05d2  vmovaps [rsp+0xD0], xmm14
00007e1ec07e05db  vmovaps [rsp+0xE0], xmm15
00007e1ec07e05e4  sub rsp, 0x30
00007e1ec07e05e8  movaps [rsp], xmm9
00007e1ec07e05ed  movaps [rsp+0x10], xmm10
00007e1ec07e05f3  movaps [rsp+0x20], xmm8
00007e1ec07e05f9  lea rdi, [rsp]
00007e1ec07e05fd  mov esi, 0x00
00007e1ec07e0602  mov rax, 0x5E00FF778530
00007e1ec07e060c  call rax
00007e1ec07e060e  movaps xmm9, [rsp]
00007e1ec07e0613  add rsp, 0x30
00007e1ec07e0617  vmovaps xmm0, [rsp]
00007e1ec07e061c  vmovaps xmm1, [rsp+0x10]
00007e1ec07e0622  vmovaps xmm2, [rsp+0x20]
00007e1ec07e0628  vmovaps xmm3, [rsp+0x30]
00007e1ec07e062e  vmovaps xmm4, [rsp+0x40]
00007e1ec07e0634  vmovaps xmm5, [rsp+0x50]
00007e1ec07e063a  vmovaps xmm6, [rsp+0x60]
00007e1ec07e0640  vmovaps xmm7, [rsp+0x70]
00007e1ec07e0646  vmovaps xmm8, [rsp+0x80]
00007e1ec07e064f  vmovaps xmm10, [rsp+0x90]
00007e1ec07e0658  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e0661  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e066a  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e0673  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e067c  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e0685  add rsp, 0xF0
00007e1ec07e068c  pop r11
00007e1ec07e068e  pop r10
00007e1ec07e0690  pop r9
00007e1ec07e0692  pop r8
00007e1ec07e0694  pop rsi
00007e1ec07e0695  pop rdi
00007e1ec07e0696  pop rdx
00007e1ec07e0697  pop rcx
00007e1ec07e0698  pop rax
00007e1ec07e0699  add rsp, 0x08
00007e1ec07e069d  jmp 0x00007E1EC07DEE8E
00007e1ec07e06a2  call 0x00007E1EC06B52F0
00007e1ec07e06a7  jmp 0x00007E1EC07DEFA8
00007e1ec07e06ac  call 0x00007E1EC06B52F0
00007e1ec07e06b1  jmp 0x00007E1EC07DEFBE
00007e1ec07e06b6  sub rsp, 0x08
00007e1ec07e06ba  push rax
00007e1ec07e06bb  push rcx
00007e1ec07e06bc  push rdx
00007e1ec07e06bd  push rdi
00007e1ec07e06be  push rsi
00007e1ec07e06bf  push r8
00007e1ec07e06c1  push r9
00007e1ec07e06c3  push r10
00007e1ec07e06c5  push r11
00007e1ec07e06c7  sub rsp, 0xF0
00007e1ec07e06ce  vmovaps [rsp], xmm0
00007e1ec07e06d3  vmovaps [rsp+0x10], xmm2
00007e1ec07e06d9  vmovaps [rsp+0x20], xmm3
00007e1ec07e06df  vmovaps [rsp+0x30], xmm4
00007e1ec07e06e5  vmovaps [rsp+0x40], xmm5
00007e1ec07e06eb  vmovaps [rsp+0x50], xmm6
00007e1ec07e06f1  vmovaps [rsp+0x60], xmm7
00007e1ec07e06f7  vmovaps [rsp+0x70], xmm8
00007e1ec07e06fd  vmovaps [rsp+0x80], xmm9
00007e1ec07e0706  vmovaps [rsp+0x90], xmm10
00007e1ec07e070f  vmovaps [rsp+0xA0], xmm11
00007e1ec07e0718  vmovaps [rsp+0xB0], xmm12
00007e1ec07e0721  vmovaps [rsp+0xC0], xmm13
00007e1ec07e072a  vmovaps [rsp+0xD0], xmm14
00007e1ec07e0733  vmovaps [rsp+0xE0], xmm15
00007e1ec07e073c  sub rsp, 0x30
00007e1ec07e0740  movaps [rsp], xmm1
00007e1ec07e0744  movaps [rsp+0x10], xmm6
00007e1ec07e0749  movaps [rsp+0x20], xmm15
00007e1ec07e074f  lea rdi, [rsp]
00007e1ec07e0753  mov esi, 0x00
00007e1ec07e0758  mov rax, 0x5E00FF778530
00007e1ec07e0762  call rax
00007e1ec07e0764  movaps xmm1, [rsp]
00007e1ec07e0768  add rsp, 0x30
00007e1ec07e076c  vmovaps xmm0, [rsp]
00007e1ec07e0771  vmovaps xmm2, [rsp+0x10]
00007e1ec07e0777  vmovaps xmm3, [rsp+0x20]
00007e1ec07e077d  vmovaps xmm4, [rsp+0x30]
00007e1ec07e0783  vmovaps xmm5, [rsp+0x40]
00007e1ec07e0789  vmovaps xmm6, [rsp+0x50]
00007e1ec07e078f  vmovaps xmm7, [rsp+0x60]
00007e1ec07e0795  vmovaps xmm8, [rsp+0x70]
00007e1ec07e079b  vmovaps xmm9, [rsp+0x80]
00007e1ec07e07a4  vmovaps xmm10, [rsp+0x90]
00007e1ec07e07ad  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e07b6  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e07bf  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e07c8  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e07d1  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e07da  add rsp, 0xF0
00007e1ec07e07e1  pop r11
00007e1ec07e07e3  pop r10
00007e1ec07e07e5  pop r9
00007e1ec07e07e7  pop r8
00007e1ec07e07e9  pop rsi
00007e1ec07e07ea  pop rdi
00007e1ec07e07eb  pop rdx
00007e1ec07e07ec  pop rcx
00007e1ec07e07ed  pop rax
00007e1ec07e07ee  add rsp, 0x08
00007e1ec07e07f2  jmp 0x00007E1EC07DEFFB
00007e1ec07e07f7  call 0x00007E1EC06C4620
00007e1ec07e07fc  jmp 0x00007E1EC07DF008
00007e1ec07e0801  sub rsp, 0x08
00007e1ec07e0805  push rax
00007e1ec07e0806  push rcx
00007e1ec07e0807  push rdx
00007e1ec07e0808  push rdi
00007e1ec07e0809  push rsi
00007e1ec07e080a  push r8
00007e1ec07e080c  push r9
00007e1ec07e080e  push r10
00007e1ec07e0810  push r11
00007e1ec07e0812  sub rsp, 0xF0
00007e1ec07e0819  vmovaps [rsp], xmm0
00007e1ec07e081e  vmovaps [rsp+0x10], xmm1
00007e1ec07e0824  vmovaps [rsp+0x20], xmm2
00007e1ec07e082a  vmovaps [rsp+0x30], xmm3
00007e1ec07e0830  vmovaps [rsp+0x40], xmm4
00007e1ec07e0836  vmovaps [rsp+0x50], xmm5
00007e1ec07e083c  vmovaps [rsp+0x60], xmm6
00007e1ec07e0842  vmovaps [rsp+0x70], xmm7
00007e1ec07e0848  vmovaps [rsp+0x80], xmm8
00007e1ec07e0851  vmovaps [rsp+0x90], xmm9
00007e1ec07e085a  vmovaps [rsp+0xA0], xmm10
00007e1ec07e0863  vmovaps [rsp+0xB0], xmm11
00007e1ec07e086c  vmovaps [rsp+0xC0], xmm12
00007e1ec07e0875  vmovaps [rsp+0xD0], xmm13
00007e1ec07e087e  vmovaps [rsp+0xE0], xmm15
00007e1ec07e0887  sub rsp, 0x30
00007e1ec07e088b  movaps [rsp], xmm14
00007e1ec07e0890  movaps [rsp+0x10], xmm4
00007e1ec07e0895  movaps [rsp+0x20], xmm3
00007e1ec07e089a  lea rdi, [rsp]
00007e1ec07e089e  mov esi, 0x00
00007e1ec07e08a3  mov rax, 0x5E00FF778530
00007e1ec07e08ad  call rax
00007e1ec07e08af  movaps xmm14, [rsp]
00007e1ec07e08b4  add rsp, 0x30
00007e1ec07e08b8  vmovaps xmm0, [rsp]
00007e1ec07e08bd  vmovaps xmm1, [rsp+0x10]
00007e1ec07e08c3  vmovaps xmm2, [rsp+0x20]
00007e1ec07e08c9  vmovaps xmm3, [rsp+0x30]
00007e1ec07e08cf  vmovaps xmm4, [rsp+0x40]
00007e1ec07e08d5  vmovaps xmm5, [rsp+0x50]
00007e1ec07e08db  vmovaps xmm6, [rsp+0x60]
00007e1ec07e08e1  vmovaps xmm7, [rsp+0x70]
00007e1ec07e08e7  vmovaps xmm8, [rsp+0x80]
00007e1ec07e08f0  vmovaps xmm9, [rsp+0x90]
00007e1ec07e08f9  vmovaps xmm10, [rsp+0xA0]
00007e1ec07e0902  vmovaps xmm11, [rsp+0xB0]
00007e1ec07e090b  vmovaps xmm12, [rsp+0xC0]
00007e1ec07e0914  vmovaps xmm13, [rsp+0xD0]
00007e1ec07e091d  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e0926  add rsp, 0xF0
00007e1ec07e092d  pop r11
00007e1ec07e092f  pop r10
00007e1ec07e0931  pop r9
00007e1ec07e0933  pop r8
00007e1ec07e0935  pop rsi
00007e1ec07e0936  pop rdi
00007e1ec07e0937  pop rdx
00007e1ec07e0938  pop rcx
00007e1ec07e0939  pop rax
00007e1ec07e093a  add rsp, 0x08
00007e1ec07e093e  jmp 0x00007E1EC07DF022
00007e1ec07e0943  sub rsp, 0x08
00007e1ec07e0947  push rax
00007e1ec07e0948  push rcx
00007e1ec07e0949  push rdx
00007e1ec07e094a  push rdi
00007e1ec07e094b  push rsi
00007e1ec07e094c  push r8
00007e1ec07e094e  push r9
00007e1ec07e0950  push r10
00007e1ec07e0952  push r11
00007e1ec07e0954  sub rsp, 0xF0
00007e1ec07e095b  vmovaps [rsp], xmm0
00007e1ec07e0960  vmovaps [rsp+0x10], xmm1
00007e1ec07e0966  vmovaps [rsp+0x20], xmm2
00007e1ec07e096c  vmovaps [rsp+0x30], xmm3
00007e1ec07e0972  vmovaps [rsp+0x40], xmm4
00007e1ec07e0978  vmovaps [rsp+0x50], xmm5
00007e1ec07e097e  vmovaps [rsp+0x60], xmm7
00007e1ec07e0984  vmovaps [rsp+0x70], xmm8
00007e1ec07e098a  vmovaps [rsp+0x80], xmm9
00007e1ec07e0993  vmovaps [rsp+0x90], xmm10
00007e1ec07e099c  vmovaps [rsp+0xA0], xmm11
00007e1ec07e09a5  vmovaps [rsp+0xB0], xmm12
00007e1ec07e09ae  vmovaps [rsp+0xC0], xmm13
00007e1ec07e09b7  vmovaps [rsp+0xD0], xmm14
00007e1ec07e09c0  vmovaps [rsp+0xE0], xmm15
00007e1ec07e09c9  sub rsp, 0x30
00007e1ec07e09cd  movaps [rsp], xmm6
00007e1ec07e09d1  movaps [rsp+0x10], xmm9
00007e1ec07e09d7  movaps [rsp+0x20], xmm7
00007e1ec07e09dc  lea rdi, [rsp]
00007e1ec07e09e0  mov esi, 0x00
00007e1ec07e09e5  mov rax, 0x5E00FF778530
00007e1ec07e09ef  call rax
00007e1ec07e09f1  movaps xmm6, [rsp]
00007e1ec07e09f5  add rsp, 0x30
00007e1ec07e09f9  vmovaps xmm0, [rsp]
00007e1ec07e09fe  vmovaps xmm1, [rsp+0x10]
00007e1ec07e0a04  vmovaps xmm2, [rsp+0x20]
00007e1ec07e0a0a  vmovaps xmm3, [rsp+0x30]
00007e1ec07e0a10  vmovaps xmm4, [rsp+0x40]
00007e1ec07e0a16  vmovaps xmm5, [rsp+0x50]
00007e1ec07e0a1c  vmovaps xmm7, [rsp+0x60]
00007e1ec07e0a22  vmovaps xmm8, [rsp+0x70]
00007e1ec07e0a28  vmovaps xmm9, [rsp+0x80]
00007e1ec07e0a31  vmovaps xmm10, [rsp+0x90]
00007e1ec07e0a3a  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e0a43  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e0a4c  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e0a55  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e0a5e  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e0a67  add rsp, 0xF0
00007e1ec07e0a6e  pop r11
00007e1ec07e0a70  pop r10
00007e1ec07e0a72  pop r9
00007e1ec07e0a74  pop r8
00007e1ec07e0a76  pop rsi
00007e1ec07e0a77  pop rdi
00007e1ec07e0a78  pop rdx
00007e1ec07e0a79  pop rcx
00007e1ec07e0a7a  pop rax
00007e1ec07e0a7b  add rsp, 0x08
00007e1ec07e0a7f  jmp 0x00007E1EC07DF03A
00007e1ec07e0a84  sub rsp, 0x08
00007e1ec07e0a88  push rax
00007e1ec07e0a89  push rcx
00007e1ec07e0a8a  push rdx
00007e1ec07e0a8b  push rdi
00007e1ec07e0a8c  push rsi
00007e1ec07e0a8d  push r8
00007e1ec07e0a8f  push r9
00007e1ec07e0a91  push r10
00007e1ec07e0a93  push r11
00007e1ec07e0a95  sub rsp, 0xF0
00007e1ec07e0a9c  vmovaps [rsp], xmm0
00007e1ec07e0aa1  vmovaps [rsp+0x10], xmm1
00007e1ec07e0aa7  vmovaps [rsp+0x20], xmm2
00007e1ec07e0aad  vmovaps [rsp+0x30], xmm3
00007e1ec07e0ab3  vmovaps [rsp+0x40], xmm4
00007e1ec07e0ab9  vmovaps [rsp+0x50], xmm5
00007e1ec07e0abf  vmovaps [rsp+0x60], xmm6
00007e1ec07e0ac5  vmovaps [rsp+0x70], xmm8
00007e1ec07e0acb  vmovaps [rsp+0x80], xmm9
00007e1ec07e0ad4  vmovaps [rsp+0x90], xmm10
00007e1ec07e0add  vmovaps [rsp+0xA0], xmm11
00007e1ec07e0ae6  vmovaps [rsp+0xB0], xmm12
00007e1ec07e0aef  vmovaps [rsp+0xC0], xmm13
00007e1ec07e0af8  vmovaps [rsp+0xD0], xmm14
00007e1ec07e0b01  vmovaps [rsp+0xE0], xmm15
00007e1ec07e0b0a  sub rsp, 0x30
00007e1ec07e0b0e  movaps [rsp], xmm7
00007e1ec07e0b12  movaps [rsp+0x10], xmm4
00007e1ec07e0b17  movaps [rsp+0x20], xmm9
00007e1ec07e0b1d  lea rdi, [rsp]
00007e1ec07e0b21  mov esi, 0x00
00007e1ec07e0b26  mov rax, 0x5E00FF778530
00007e1ec07e0b30  call rax
00007e1ec07e0b32  movaps xmm7, [rsp]
00007e1ec07e0b36  add rsp, 0x30
00007e1ec07e0b3a  vmovaps xmm0, [rsp]
00007e1ec07e0b3f  vmovaps xmm1, [rsp+0x10]
00007e1ec07e0b45  vmovaps xmm2, [rsp+0x20]
00007e1ec07e0b4b  vmovaps xmm3, [rsp+0x30]
00007e1ec07e0b51  vmovaps xmm4, [rsp+0x40]
00007e1ec07e0b57  vmovaps xmm5, [rsp+0x50]
00007e1ec07e0b5d  vmovaps xmm6, [rsp+0x60]
00007e1ec07e0b63  vmovaps xmm8, [rsp+0x70]
00007e1ec07e0b69  vmovaps xmm9, [rsp+0x80]
00007e1ec07e0b72  vmovaps xmm10, [rsp+0x90]
00007e1ec07e0b7b  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e0b84  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e0b8d  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e0b96  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e0b9f  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e0ba8  add rsp, 0xF0
00007e1ec07e0baf  pop r11
00007e1ec07e0bb1  pop r10
00007e1ec07e0bb3  pop r9
00007e1ec07e0bb5  pop r8
00007e1ec07e0bb7  pop rsi
00007e1ec07e0bb8  pop rdi
00007e1ec07e0bb9  pop rdx
00007e1ec07e0bba  pop rcx
00007e1ec07e0bbb  pop rax
00007e1ec07e0bbc  add rsp, 0x08
00007e1ec07e0bc0  jmp 0x00007E1EC07DF067
00007e1ec07e0bc5  sub rsp, 0x08
00007e1ec07e0bc9  push rax
00007e1ec07e0bca  push rcx
00007e1ec07e0bcb  push rdx
00007e1ec07e0bcc  push rdi
00007e1ec07e0bcd  push rsi
00007e1ec07e0bce  push r8
00007e1ec07e0bd0  push r9
00007e1ec07e0bd2  push r10
00007e1ec07e0bd4  push r11
00007e1ec07e0bd6  sub rsp, 0xF0
00007e1ec07e0bdd  vmovaps [rsp], xmm0
00007e1ec07e0be2  vmovaps [rsp+0x10], xmm1
00007e1ec07e0be8  vmovaps [rsp+0x20], xmm2
00007e1ec07e0bee  vmovaps [rsp+0x30], xmm3
00007e1ec07e0bf4  vmovaps [rsp+0x40], xmm5
00007e1ec07e0bfa  vmovaps [rsp+0x50], xmm6
00007e1ec07e0c00  vmovaps [rsp+0x60], xmm7
00007e1ec07e0c06  vmovaps [rsp+0x70], xmm8
00007e1ec07e0c0c  vmovaps [rsp+0x80], xmm9
00007e1ec07e0c15  vmovaps [rsp+0x90], xmm10
00007e1ec07e0c1e  vmovaps [rsp+0xA0], xmm11
00007e1ec07e0c27  vmovaps [rsp+0xB0], xmm12
00007e1ec07e0c30  vmovaps [rsp+0xC0], xmm13
00007e1ec07e0c39  vmovaps [rsp+0xD0], xmm14
00007e1ec07e0c42  vmovaps [rsp+0xE0], xmm15
00007e1ec07e0c4b  sub rsp, 0x30
00007e1ec07e0c4f  movaps [rsp], xmm4
00007e1ec07e0c53  movaps [rsp+0x10], xmm15
00007e1ec07e0c59  movaps [rsp+0x20], xmm9
00007e1ec07e0c5f  lea rdi, [rsp]
00007e1ec07e0c63  mov esi, 0x00
00007e1ec07e0c68  mov rax, 0x5E00FF778530
00007e1ec07e0c72  call rax
00007e1ec07e0c74  movaps xmm4, [rsp]
00007e1ec07e0c78  add rsp, 0x30
00007e1ec07e0c7c  vmovaps xmm0, [rsp]
00007e1ec07e0c81  vmovaps xmm1, [rsp+0x10]
00007e1ec07e0c87  vmovaps xmm2, [rsp+0x20]
00007e1ec07e0c8d  vmovaps xmm3, [rsp+0x30]
00007e1ec07e0c93  vmovaps xmm5, [rsp+0x40]
00007e1ec07e0c99  vmovaps xmm6, [rsp+0x50]
00007e1ec07e0c9f  vmovaps xmm7, [rsp+0x60]
00007e1ec07e0ca5  vmovaps xmm8, [rsp+0x70]
00007e1ec07e0cab  vmovaps xmm9, [rsp+0x80]
00007e1ec07e0cb4  vmovaps xmm10, [rsp+0x90]
00007e1ec07e0cbd  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e0cc6  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e0ccf  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e0cd8  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e0ce1  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e0cea  add rsp, 0xF0
00007e1ec07e0cf1  pop r11
00007e1ec07e0cf3  pop r10
00007e1ec07e0cf5  pop r9
00007e1ec07e0cf7  pop r8
00007e1ec07e0cf9  pop rsi
00007e1ec07e0cfa  pop rdi
00007e1ec07e0cfb  pop rdx
00007e1ec07e0cfc  pop rcx
00007e1ec07e0cfd  pop rax
00007e1ec07e0cfe  add rsp, 0x08
00007e1ec07e0d02  jmp 0x00007E1EC07DF08C
00007e1ec07e0d07  call 0x00007E1EC06C4620
00007e1ec07e0d0c  jmp 0x00007E1EC07DF099
00007e1ec07e0d11  sub rsp, 0x08
00007e1ec07e0d15  push rax
00007e1ec07e0d16  push rcx
00007e1ec07e0d17  push rdx
00007e1ec07e0d18  push rdi
00007e1ec07e0d19  push rsi
00007e1ec07e0d1a  push r8
00007e1ec07e0d1c  push r9
00007e1ec07e0d1e  push r10
00007e1ec07e0d20  push r11
00007e1ec07e0d22  sub rsp, 0xF0
00007e1ec07e0d29  vmovaps [rsp], xmm0
00007e1ec07e0d2e  vmovaps [rsp+0x10], xmm1
00007e1ec07e0d34  vmovaps [rsp+0x20], xmm2
00007e1ec07e0d3a  vmovaps [rsp+0x30], xmm4
00007e1ec07e0d40  vmovaps [rsp+0x40], xmm5
00007e1ec07e0d46  vmovaps [rsp+0x50], xmm6
00007e1ec07e0d4c  vmovaps [rsp+0x60], xmm7
00007e1ec07e0d52  vmovaps [rsp+0x70], xmm8
00007e1ec07e0d58  vmovaps [rsp+0x80], xmm9
00007e1ec07e0d61  vmovaps [rsp+0x90], xmm10
00007e1ec07e0d6a  vmovaps [rsp+0xA0], xmm11
00007e1ec07e0d73  vmovaps [rsp+0xB0], xmm12
00007e1ec07e0d7c  vmovaps [rsp+0xC0], xmm13
00007e1ec07e0d85  vmovaps [rsp+0xD0], xmm14
00007e1ec07e0d8e  vmovaps [rsp+0xE0], xmm15
00007e1ec07e0d97  sub rsp, 0x30
00007e1ec07e0d9b  movaps [rsp], xmm3
00007e1ec07e0d9f  movaps [rsp+0x10], xmm1
00007e1ec07e0da4  movaps [rsp+0x20], xmm9
00007e1ec07e0daa  lea rdi, [rsp]
00007e1ec07e0dae  mov esi, 0x00
00007e1ec07e0db3  mov rax, 0x5E00FF778530
00007e1ec07e0dbd  call rax
00007e1ec07e0dbf  movaps xmm3, [rsp]
00007e1ec07e0dc3  add rsp, 0x30
00007e1ec07e0dc7  vmovaps xmm0, [rsp]
00007e1ec07e0dcc  vmovaps xmm1, [rsp+0x10]
00007e1ec07e0dd2  vmovaps xmm2, [rsp+0x20]
00007e1ec07e0dd8  vmovaps xmm4, [rsp+0x30]
00007e1ec07e0dde  vmovaps xmm5, [rsp+0x40]
00007e1ec07e0de4  vmovaps xmm6, [rsp+0x50]
00007e1ec07e0dea  vmovaps xmm7, [rsp+0x60]
00007e1ec07e0df0  vmovaps xmm8, [rsp+0x70]
00007e1ec07e0df6  vmovaps xmm9, [rsp+0x80]
00007e1ec07e0dff  vmovaps xmm10, [rsp+0x90]
00007e1ec07e0e08  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e0e11  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e0e1a  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e0e23  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e0e2c  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e0e35  add rsp, 0xF0
00007e1ec07e0e3c  pop r11
00007e1ec07e0e3e  pop r10
00007e1ec07e0e40  pop r9
00007e1ec07e0e42  pop r8
00007e1ec07e0e44  pop rsi
00007e1ec07e0e45  pop rdi
00007e1ec07e0e46  pop rdx
00007e1ec07e0e47  pop rcx
00007e1ec07e0e48  pop rax
00007e1ec07e0e49  add rsp, 0x08
00007e1ec07e0e4d  jmp 0x00007E1EC07DF0D6
00007e1ec07e0e52  sub rsp, 0x08
00007e1ec07e0e56  push rax
00007e1ec07e0e57  push rcx
00007e1ec07e0e58  push rdx
00007e1ec07e0e59  push rdi
00007e1ec07e0e5a  push rsi
00007e1ec07e0e5b  push r8
00007e1ec07e0e5d  push r9
00007e1ec07e0e5f  push r10
00007e1ec07e0e61  push r11
00007e1ec07e0e63  sub rsp, 0xF0
00007e1ec07e0e6a  vmovaps [rsp], xmm0
00007e1ec07e0e6f  vmovaps [rsp+0x10], xmm2
00007e1ec07e0e75  vmovaps [rsp+0x20], xmm3
00007e1ec07e0e7b  vmovaps [rsp+0x30], xmm4
00007e1ec07e0e81  vmovaps [rsp+0x40], xmm5
00007e1ec07e0e87  vmovaps [rsp+0x50], xmm6
00007e1ec07e0e8d  vmovaps [rsp+0x60], xmm7
00007e1ec07e0e93  vmovaps [rsp+0x70], xmm8
00007e1ec07e0e99  vmovaps [rsp+0x80], xmm9
00007e1ec07e0ea2  vmovaps [rsp+0x90], xmm10
00007e1ec07e0eab  vmovaps [rsp+0xA0], xmm11
00007e1ec07e0eb4  vmovaps [rsp+0xB0], xmm12
00007e1ec07e0ebd  vmovaps [rsp+0xC0], xmm13
00007e1ec07e0ec6  vmovaps [rsp+0xD0], xmm14
00007e1ec07e0ecf  vmovaps [rsp+0xE0], xmm15
00007e1ec07e0ed8  sub rsp, 0x30
00007e1ec07e0edc  movaps [rsp], xmm1
00007e1ec07e0ee0  movaps [rsp+0x10], xmm15
00007e1ec07e0ee6  movaps [rsp+0x20], xmm9
00007e1ec07e0eec  lea rdi, [rsp]
00007e1ec07e0ef0  mov esi, 0x00
00007e1ec07e0ef5  mov rax, 0x5E00FF778530
00007e1ec07e0eff  call rax
00007e1ec07e0f01  movaps xmm1, [rsp]
00007e1ec07e0f05  add rsp, 0x30
00007e1ec07e0f09  vmovaps xmm0, [rsp]
00007e1ec07e0f0e  vmovaps xmm2, [rsp+0x10]
00007e1ec07e0f14  vmovaps xmm3, [rsp+0x20]
00007e1ec07e0f1a  vmovaps xmm4, [rsp+0x30]
00007e1ec07e0f20  vmovaps xmm5, [rsp+0x40]
00007e1ec07e0f26  vmovaps xmm6, [rsp+0x50]
00007e1ec07e0f2c  vmovaps xmm7, [rsp+0x60]
00007e1ec07e0f32  vmovaps xmm8, [rsp+0x70]
00007e1ec07e0f38  vmovaps xmm9, [rsp+0x80]
00007e1ec07e0f41  vmovaps xmm10, [rsp+0x90]
00007e1ec07e0f4a  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e0f53  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e0f5c  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e0f65  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e0f6e  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e0f77  add rsp, 0xF0
00007e1ec07e0f7e  pop r11
00007e1ec07e0f80  pop r10
00007e1ec07e0f82  pop r9
00007e1ec07e0f84  pop r8
00007e1ec07e0f86  pop rsi
00007e1ec07e0f87  pop rdi
00007e1ec07e0f88  pop rdx
00007e1ec07e0f89  pop rcx
00007e1ec07e0f8a  pop rax
00007e1ec07e0f8b  add rsp, 0x08
00007e1ec07e0f8f  jmp 0x00007E1EC07DF15E
00007e1ec07e0f94  call 0x00007E1EC06C4620
00007e1ec07e0f99  jmp 0x00007E1EC07DF16B
00007e1ec07e0f9e  sub rsp, 0x08
00007e1ec07e0fa2  push rax
00007e1ec07e0fa3  push rcx
00007e1ec07e0fa4  push rdx
00007e1ec07e0fa5  push rdi
00007e1ec07e0fa6  push rsi
00007e1ec07e0fa7  push r8
00007e1ec07e0fa9  push r9
00007e1ec07e0fab  push r10
00007e1ec07e0fad  push r11
00007e1ec07e0faf  sub rsp, 0xF0
00007e1ec07e0fb6  vmovaps [rsp], xmm0
00007e1ec07e0fbb  vmovaps [rsp+0x10], xmm2
00007e1ec07e0fc1  vmovaps [rsp+0x20], xmm3
00007e1ec07e0fc7  vmovaps [rsp+0x30], xmm4
00007e1ec07e0fcd  vmovaps [rsp+0x40], xmm5
00007e1ec07e0fd3  vmovaps [rsp+0x50], xmm6
00007e1ec07e0fd9  vmovaps [rsp+0x60], xmm7
00007e1ec07e0fdf  vmovaps [rsp+0x70], xmm8
00007e1ec07e0fe5  vmovaps [rsp+0x80], xmm9
00007e1ec07e0fee  vmovaps [rsp+0x90], xmm10
00007e1ec07e0ff7  vmovaps [rsp+0xA0], xmm11
00007e1ec07e1000  vmovaps [rsp+0xB0], xmm12
00007e1ec07e1009  vmovaps [rsp+0xC0], xmm13
00007e1ec07e1012  vmovaps [rsp+0xD0], xmm14
00007e1ec07e101b  vmovaps [rsp+0xE0], xmm15
00007e1ec07e1024  sub rsp, 0x30
00007e1ec07e1028  movaps [rsp], xmm1
00007e1ec07e102c  movaps [rsp+0x10], xmm5
00007e1ec07e1031  movaps [rsp+0x20], xmm7
00007e1ec07e1036  lea rdi, [rsp]
00007e1ec07e103a  mov esi, 0x00
00007e1ec07e103f  mov rax, 0x5E00FF778530
00007e1ec07e1049  call rax
00007e1ec07e104b  movaps xmm1, [rsp]
00007e1ec07e104f  add rsp, 0x30
00007e1ec07e1053  vmovaps xmm0, [rsp]
00007e1ec07e1058  vmovaps xmm2, [rsp+0x10]
00007e1ec07e105e  vmovaps xmm3, [rsp+0x20]
00007e1ec07e1064  vmovaps xmm4, [rsp+0x30]
00007e1ec07e106a  vmovaps xmm5, [rsp+0x40]
00007e1ec07e1070  vmovaps xmm6, [rsp+0x50]
00007e1ec07e1076  vmovaps xmm7, [rsp+0x60]
00007e1ec07e107c  vmovaps xmm8, [rsp+0x70]
00007e1ec07e1082  vmovaps xmm9, [rsp+0x80]
00007e1ec07e108b  vmovaps xmm10, [rsp+0x90]
00007e1ec07e1094  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e109d  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e10a6  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e10af  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e10b8  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e10c1  add rsp, 0xF0
00007e1ec07e10c8  pop r11
00007e1ec07e10ca  pop r10
00007e1ec07e10cc  pop r9
00007e1ec07e10ce  pop r8
00007e1ec07e10d0  pop rsi
00007e1ec07e10d1  pop rdi
00007e1ec07e10d2  pop rdx
00007e1ec07e10d3  pop rcx
00007e1ec07e10d4  pop rax
00007e1ec07e10d5  add rsp, 0x08
00007e1ec07e10d9  jmp 0x00007E1EC07DF210
00007e1ec07e10de  sub rsp, 0x08
00007e1ec07e10e2  push rax
00007e1ec07e10e3  push rcx
00007e1ec07e10e4  push rdx
00007e1ec07e10e5  push rdi
00007e1ec07e10e6  push rsi
00007e1ec07e10e7  push r8
00007e1ec07e10e9  push r9
00007e1ec07e10eb  push r10
00007e1ec07e10ed  push r11
00007e1ec07e10ef  sub rsp, 0xF0
00007e1ec07e10f6  vmovaps [rsp], xmm0
00007e1ec07e10fb  vmovaps [rsp+0x10], xmm1
00007e1ec07e1101  vmovaps [rsp+0x20], xmm2
00007e1ec07e1107  vmovaps [rsp+0x30], xmm3
00007e1ec07e110d  vmovaps [rsp+0x40], xmm4
00007e1ec07e1113  vmovaps [rsp+0x50], xmm5
00007e1ec07e1119  vmovaps [rsp+0x60], xmm6
00007e1ec07e111f  vmovaps [rsp+0x70], xmm8
00007e1ec07e1125  vmovaps [rsp+0x80], xmm9
00007e1ec07e112e  vmovaps [rsp+0x90], xmm10
00007e1ec07e1137  vmovaps [rsp+0xA0], xmm11
00007e1ec07e1140  vmovaps [rsp+0xB0], xmm12
00007e1ec07e1149  vmovaps [rsp+0xC0], xmm13
00007e1ec07e1152  vmovaps [rsp+0xD0], xmm14
00007e1ec07e115b  vmovaps [rsp+0xE0], xmm15
00007e1ec07e1164  sub rsp, 0x30
00007e1ec07e1168  movaps [rsp], xmm7
00007e1ec07e116c  movaps [rsp+0x10], xmm5
00007e1ec07e1171  movaps [rsp+0x20], xmm15
00007e1ec07e1177  lea rdi, [rsp]
00007e1ec07e117b  mov esi, 0x00
00007e1ec07e1180  mov rax, 0x5E00FF778530
00007e1ec07e118a  call rax
00007e1ec07e118c  movaps xmm7, [rsp]
00007e1ec07e1190  add rsp, 0x30
00007e1ec07e1194  vmovaps xmm0, [rsp]
00007e1ec07e1199  vmovaps xmm1, [rsp+0x10]
00007e1ec07e119f  vmovaps xmm2, [rsp+0x20]
00007e1ec07e11a5  vmovaps xmm3, [rsp+0x30]
00007e1ec07e11ab  vmovaps xmm4, [rsp+0x40]
00007e1ec07e11b1  vmovaps xmm5, [rsp+0x50]
00007e1ec07e11b7  vmovaps xmm6, [rsp+0x60]
00007e1ec07e11bd  vmovaps xmm8, [rsp+0x70]
00007e1ec07e11c3  vmovaps xmm9, [rsp+0x80]
00007e1ec07e11cc  vmovaps xmm10, [rsp+0x90]
00007e1ec07e11d5  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e11de  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e11e7  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e11f0  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e11f9  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e1202  add rsp, 0xF0
00007e1ec07e1209  pop r11
00007e1ec07e120b  pop r10
00007e1ec07e120d  pop r9
00007e1ec07e120f  pop r8
00007e1ec07e1211  pop rsi
00007e1ec07e1212  pop rdi
00007e1ec07e1213  pop rdx
00007e1ec07e1214  pop rcx
00007e1ec07e1215  pop rax
00007e1ec07e1216  add rsp, 0x08
00007e1ec07e121a  jmp 0x00007E1EC07DF246
00007e1ec07e121f  call 0x00007E1EC06B52F0
00007e1ec07e1224  jmp 0x00007E1EC07DF253
00007e1ec07e1229  sub rsp, 0x08
00007e1ec07e122d  push rax
00007e1ec07e122e  push rcx
00007e1ec07e122f  push rdx
00007e1ec07e1230  push rdi
00007e1ec07e1231  push rsi
00007e1ec07e1232  push r8
00007e1ec07e1234  push r9
00007e1ec07e1236  push r10
00007e1ec07e1238  push r11
00007e1ec07e123a  sub rsp, 0xF0
00007e1ec07e1241  vmovaps [rsp], xmm0
00007e1ec07e1246  vmovaps [rsp+0x10], xmm1
00007e1ec07e124c  vmovaps [rsp+0x20], xmm2
00007e1ec07e1252  vmovaps [rsp+0x30], xmm3
00007e1ec07e1258  vmovaps [rsp+0x40], xmm4
00007e1ec07e125e  vmovaps [rsp+0x50], xmm5
00007e1ec07e1264  vmovaps [rsp+0x60], xmm6
00007e1ec07e126a  vmovaps [rsp+0x70], xmm7
00007e1ec07e1270  vmovaps [rsp+0x80], xmm8
00007e1ec07e1279  vmovaps [rsp+0x90], xmm9
00007e1ec07e1282  vmovaps [rsp+0xA0], xmm10
00007e1ec07e128b  vmovaps [rsp+0xB0], xmm11
00007e1ec07e1294  vmovaps [rsp+0xC0], xmm12
00007e1ec07e129d  vmovaps [rsp+0xD0], xmm13
00007e1ec07e12a6  vmovaps [rsp+0xE0], xmm14
00007e1ec07e12af  sub rsp, 0x30
00007e1ec07e12b3  movaps [rsp], xmm15
00007e1ec07e12b8  movaps [rsp+0x10], xmm5
00007e1ec07e12bd  movaps [rsp+0x20], xmm3
00007e1ec07e12c2  lea rdi, [rsp]
00007e1ec07e12c6  mov esi, 0x00
00007e1ec07e12cb  mov rax, 0x5E00FF778530
00007e1ec07e12d5  call rax
00007e1ec07e12d7  movaps xmm15, [rsp]
00007e1ec07e12dc  add rsp, 0x30
00007e1ec07e12e0  vmovaps xmm0, [rsp]
00007e1ec07e12e5  vmovaps xmm1, [rsp+0x10]
00007e1ec07e12eb  vmovaps xmm2, [rsp+0x20]
00007e1ec07e12f1  vmovaps xmm3, [rsp+0x30]
00007e1ec07e12f7  vmovaps xmm4, [rsp+0x40]
00007e1ec07e12fd  vmovaps xmm5, [rsp+0x50]
00007e1ec07e1303  vmovaps xmm6, [rsp+0x60]
00007e1ec07e1309  vmovaps xmm7, [rsp+0x70]
00007e1ec07e130f  vmovaps xmm8, [rsp+0x80]
00007e1ec07e1318  vmovaps xmm9, [rsp+0x90]
00007e1ec07e1321  vmovaps xmm10, [rsp+0xA0]
00007e1ec07e132a  vmovaps xmm11, [rsp+0xB0]
00007e1ec07e1333  vmovaps xmm12, [rsp+0xC0]
00007e1ec07e133c  vmovaps xmm13, [rsp+0xD0]
00007e1ec07e1345  vmovaps xmm14, [rsp+0xE0]
00007e1ec07e134e  add rsp, 0xF0
00007e1ec07e1355  pop r11
00007e1ec07e1357  pop r10
00007e1ec07e1359  pop r9
00007e1ec07e135b  pop r8
00007e1ec07e135d  pop rsi
00007e1ec07e135e  pop rdi
00007e1ec07e135f  pop rdx
00007e1ec07e1360  pop rcx
00007e1ec07e1361  pop rax
00007e1ec07e1362  add rsp, 0x08
00007e1ec07e1366  jmp 0x00007E1EC07DF279
00007e1ec07e136b  sub rsp, 0x08
00007e1ec07e136f  push rax
00007e1ec07e1370  push rcx
00007e1ec07e1371  push rdx
00007e1ec07e1372  push rdi
00007e1ec07e1373  push rsi
00007e1ec07e1374  push r8
00007e1ec07e1376  push r9
00007e1ec07e1378  push r10
00007e1ec07e137a  push r11
00007e1ec07e137c  sub rsp, 0xF0
00007e1ec07e1383  vmovaps [rsp], xmm0
00007e1ec07e1388  vmovaps [rsp+0x10], xmm2
00007e1ec07e138e  vmovaps [rsp+0x20], xmm3
00007e1ec07e1394  vmovaps [rsp+0x30], xmm4
00007e1ec07e139a  vmovaps [rsp+0x40], xmm5
00007e1ec07e13a0  vmovaps [rsp+0x50], xmm6
00007e1ec07e13a6  vmovaps [rsp+0x60], xmm7
00007e1ec07e13ac  vmovaps [rsp+0x70], xmm8
00007e1ec07e13b2  vmovaps [rsp+0x80], xmm9
00007e1ec07e13bb  vmovaps [rsp+0x90], xmm10
00007e1ec07e13c4  vmovaps [rsp+0xA0], xmm11
00007e1ec07e13cd  vmovaps [rsp+0xB0], xmm12
00007e1ec07e13d6  vmovaps [rsp+0xC0], xmm13
00007e1ec07e13df  vmovaps [rsp+0xD0], xmm14
00007e1ec07e13e8  vmovaps [rsp+0xE0], xmm15
00007e1ec07e13f1  sub rsp, 0x30
00007e1ec07e13f5  movaps [rsp], xmm1
00007e1ec07e13f9  movaps [rsp+0x10], xmm5
00007e1ec07e13fe  movaps [rsp+0x20], xmm4
00007e1ec07e1403  lea rdi, [rsp]
00007e1ec07e1407  mov esi, 0x00
00007e1ec07e140c  mov rax, 0x5E00FF778530
00007e1ec07e1416  call rax
00007e1ec07e1418  movaps xmm1, [rsp]
00007e1ec07e141c  add rsp, 0x30
00007e1ec07e1420  vmovaps xmm0, [rsp]
00007e1ec07e1425  vmovaps xmm2, [rsp+0x10]
00007e1ec07e142b  vmovaps xmm3, [rsp+0x20]
00007e1ec07e1431  vmovaps xmm4, [rsp+0x30]
00007e1ec07e1437  vmovaps xmm5, [rsp+0x40]
00007e1ec07e143d  vmovaps xmm6, [rsp+0x50]
00007e1ec07e1443  vmovaps xmm7, [rsp+0x60]
00007e1ec07e1449  vmovaps xmm8, [rsp+0x70]
00007e1ec07e144f  vmovaps xmm9, [rsp+0x80]
00007e1ec07e1458  vmovaps xmm10, [rsp+0x90]
00007e1ec07e1461  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e146a  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e1473  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e147c  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e1485  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e148e  add rsp, 0xF0
00007e1ec07e1495  pop r11
00007e1ec07e1497  pop r10
00007e1ec07e1499  pop r9
00007e1ec07e149b  pop r8
00007e1ec07e149d  pop rsi
00007e1ec07e149e  pop rdi
00007e1ec07e149f  pop rdx
00007e1ec07e14a0  pop rcx
00007e1ec07e14a1  pop rax
00007e1ec07e14a2  add rsp, 0x08
00007e1ec07e14a6  jmp 0x00007E1EC07DF299
00007e1ec07e14ab  sub rsp, 0x08
00007e1ec07e14af  push rax
00007e1ec07e14b0  push rcx
00007e1ec07e14b1  push rdx
00007e1ec07e14b2  push rdi
00007e1ec07e14b3  push rsi
00007e1ec07e14b4  push r8
00007e1ec07e14b6  push r9
00007e1ec07e14b8  push r10
00007e1ec07e14ba  push r11
00007e1ec07e14bc  sub rsp, 0xF0
00007e1ec07e14c3  vmovaps [rsp], xmm0
00007e1ec07e14c8  vmovaps [rsp+0x10], xmm1
00007e1ec07e14ce  vmovaps [rsp+0x20], xmm2
00007e1ec07e14d4  vmovaps [rsp+0x30], xmm3
00007e1ec07e14da  vmovaps [rsp+0x40], xmm5
00007e1ec07e14e0  vmovaps [rsp+0x50], xmm6
00007e1ec07e14e6  vmovaps [rsp+0x60], xmm7
00007e1ec07e14ec  vmovaps [rsp+0x70], xmm8
00007e1ec07e14f2  vmovaps [rsp+0x80], xmm9
00007e1ec07e14fb  vmovaps [rsp+0x90], xmm10
00007e1ec07e1504  vmovaps [rsp+0xA0], xmm11
00007e1ec07e150d  vmovaps [rsp+0xB0], xmm12
00007e1ec07e1516  vmovaps [rsp+0xC0], xmm13
00007e1ec07e151f  vmovaps [rsp+0xD0], xmm14
00007e1ec07e1528  vmovaps [rsp+0xE0], xmm15
00007e1ec07e1531  sub rsp, 0x30
00007e1ec07e1535  movaps [rsp], xmm4
00007e1ec07e1539  movaps [rsp+0x10], xmm3
00007e1ec07e153e  movaps [rsp+0x20], xmm5
00007e1ec07e1543  lea rdi, [rsp]
00007e1ec07e1547  mov esi, 0x00
00007e1ec07e154c  mov rax, 0x5E00FF778530
00007e1ec07e1556  call rax
00007e1ec07e1558  movaps xmm4, [rsp]
00007e1ec07e155c  add rsp, 0x30
00007e1ec07e1560  vmovaps xmm0, [rsp]
00007e1ec07e1565  vmovaps xmm1, [rsp+0x10]
00007e1ec07e156b  vmovaps xmm2, [rsp+0x20]
00007e1ec07e1571  vmovaps xmm3, [rsp+0x30]
00007e1ec07e1577  vmovaps xmm5, [rsp+0x40]
00007e1ec07e157d  vmovaps xmm6, [rsp+0x50]
00007e1ec07e1583  vmovaps xmm7, [rsp+0x60]
00007e1ec07e1589  vmovaps xmm8, [rsp+0x70]
00007e1ec07e158f  vmovaps xmm9, [rsp+0x80]
00007e1ec07e1598  vmovaps xmm10, [rsp+0x90]
00007e1ec07e15a1  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e15aa  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e15b3  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e15bc  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e15c5  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e15ce  add rsp, 0xF0
00007e1ec07e15d5  pop r11
00007e1ec07e15d7  pop r10
00007e1ec07e15d9  pop r9
00007e1ec07e15db  pop r8
00007e1ec07e15dd  pop rsi
00007e1ec07e15de  pop rdi
00007e1ec07e15df  pop rdx
00007e1ec07e15e0  pop rcx
00007e1ec07e15e1  pop rax
00007e1ec07e15e2  add rsp, 0x08
00007e1ec07e15e6  jmp 0x00007E1EC07DF2E7
00007e1ec07e15eb  call 0x00007E1EC06B52F0
00007e1ec07e15f0  jmp 0x00007E1EC07DF2F4
00007e1ec07e15f5  sub rsp, 0x08
00007e1ec07e15f9  push rax
00007e1ec07e15fa  push rcx
00007e1ec07e15fb  push rdx
00007e1ec07e15fc  push rdi
00007e1ec07e15fd  push rsi
00007e1ec07e15fe  push r8
00007e1ec07e1600  push r9
00007e1ec07e1602  push r10
00007e1ec07e1604  push r11
00007e1ec07e1606  sub rsp, 0xF0
00007e1ec07e160d  vmovaps [rsp], xmm0
00007e1ec07e1612  vmovaps [rsp+0x10], xmm1
00007e1ec07e1618  vmovaps [rsp+0x20], xmm2
00007e1ec07e161e  vmovaps [rsp+0x30], xmm3
00007e1ec07e1624  vmovaps [rsp+0x40], xmm4
00007e1ec07e162a  vmovaps [rsp+0x50], xmm6
00007e1ec07e1630  vmovaps [rsp+0x60], xmm7
00007e1ec07e1636  vmovaps [rsp+0x70], xmm8
00007e1ec07e163c  vmovaps [rsp+0x80], xmm9
00007e1ec07e1645  vmovaps [rsp+0x90], xmm10
00007e1ec07e164e  vmovaps [rsp+0xA0], xmm11
00007e1ec07e1657  vmovaps [rsp+0xB0], xmm12
00007e1ec07e1660  vmovaps [rsp+0xC0], xmm13
00007e1ec07e1669  vmovaps [rsp+0xD0], xmm14
00007e1ec07e1672  vmovaps [rsp+0xE0], xmm15
00007e1ec07e167b  sub rsp, 0x30
00007e1ec07e167f  movaps [rsp], xmm5
00007e1ec07e1683  movaps [rsp+0x10], xmm6
00007e1ec07e1688  movaps [rsp+0x20], xmm3
00007e1ec07e168d  lea rdi, [rsp]
00007e1ec07e1691  mov esi, 0x00
00007e1ec07e1696  mov rax, 0x5E00FF778530
00007e1ec07e16a0  call rax
00007e1ec07e16a2  movaps xmm5, [rsp]
00007e1ec07e16a6  add rsp, 0x30
00007e1ec07e16aa  vmovaps xmm0, [rsp]
00007e1ec07e16af  vmovaps xmm1, [rsp+0x10]
00007e1ec07e16b5  vmovaps xmm2, [rsp+0x20]
00007e1ec07e16bb  vmovaps xmm3, [rsp+0x30]
00007e1ec07e16c1  vmovaps xmm4, [rsp+0x40]
00007e1ec07e16c7  vmovaps xmm6, [rsp+0x50]
00007e1ec07e16cd  vmovaps xmm7, [rsp+0x60]
00007e1ec07e16d3  vmovaps xmm8, [rsp+0x70]
00007e1ec07e16d9  vmovaps xmm9, [rsp+0x80]
00007e1ec07e16e2  vmovaps xmm10, [rsp+0x90]
00007e1ec07e16eb  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e16f4  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e16fd  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e1706  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e170f  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e1718  add rsp, 0xF0
00007e1ec07e171f  pop r11
00007e1ec07e1721  pop r10
00007e1ec07e1723  pop r9
00007e1ec07e1725  pop r8
00007e1ec07e1727  pop rsi
00007e1ec07e1728  pop rdi
00007e1ec07e1729  pop rdx
00007e1ec07e172a  pop rcx
00007e1ec07e172b  pop rax
00007e1ec07e172c  add rsp, 0x08
00007e1ec07e1730  jmp 0x00007E1EC07DF31A
00007e1ec07e1735  sub rsp, 0x08
00007e1ec07e1739  push rax
00007e1ec07e173a  push rcx
00007e1ec07e173b  push rdx
00007e1ec07e173c  push rdi
00007e1ec07e173d  push rsi
00007e1ec07e173e  push r8
00007e1ec07e1740  push r9
00007e1ec07e1742  push r10
00007e1ec07e1744  push r11
00007e1ec07e1746  sub rsp, 0xF0
00007e1ec07e174d  vmovaps [rsp], xmm0
00007e1ec07e1752  vmovaps [rsp+0x10], xmm1
00007e1ec07e1758  vmovaps [rsp+0x20], xmm2
00007e1ec07e175e  vmovaps [rsp+0x30], xmm3
00007e1ec07e1764  vmovaps [rsp+0x40], xmm4
00007e1ec07e176a  vmovaps [rsp+0x50], xmm5
00007e1ec07e1770  vmovaps [rsp+0x60], xmm7
00007e1ec07e1776  vmovaps [rsp+0x70], xmm8
00007e1ec07e177c  vmovaps [rsp+0x80], xmm9
00007e1ec07e1785  vmovaps [rsp+0x90], xmm10
00007e1ec07e178e  vmovaps [rsp+0xA0], xmm11
00007e1ec07e1797  vmovaps [rsp+0xB0], xmm12
00007e1ec07e17a0  vmovaps [rsp+0xC0], xmm13
00007e1ec07e17a9  vmovaps [rsp+0xD0], xmm14
00007e1ec07e17b2  vmovaps [rsp+0xE0], xmm15
00007e1ec07e17bb  sub rsp, 0x30
00007e1ec07e17bf  movaps [rsp], xmm6
00007e1ec07e17c3  movaps [rsp+0x10], xmm9
00007e1ec07e17c9  movaps [rsp+0x20], xmm1
00007e1ec07e17ce  lea rdi, [rsp]
00007e1ec07e17d2  mov esi, 0x00
00007e1ec07e17d7  mov rax, 0x5E00FF778530
00007e1ec07e17e1  call rax
00007e1ec07e17e3  movaps xmm6, [rsp]
00007e1ec07e17e7  add rsp, 0x30
00007e1ec07e17eb  vmovaps xmm0, [rsp]
00007e1ec07e17f0  vmovaps xmm1, [rsp+0x10]
00007e1ec07e17f6  vmovaps xmm2, [rsp+0x20]
00007e1ec07e17fc  vmovaps xmm3, [rsp+0x30]
00007e1ec07e1802  vmovaps xmm4, [rsp+0x40]
00007e1ec07e1808  vmovaps xmm5, [rsp+0x50]
00007e1ec07e180e  vmovaps xmm7, [rsp+0x60]
00007e1ec07e1814  vmovaps xmm8, [rsp+0x70]
00007e1ec07e181a  vmovaps xmm9, [rsp+0x80]
00007e1ec07e1823  vmovaps xmm10, [rsp+0x90]
00007e1ec07e182c  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e1835  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e183e  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e1847  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e1850  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e1859  add rsp, 0xF0
00007e1ec07e1860  pop r11
00007e1ec07e1862  pop r10
00007e1ec07e1864  pop r9
00007e1ec07e1866  pop r8
00007e1ec07e1868  pop rsi
00007e1ec07e1869  pop rdi
00007e1ec07e186a  pop rdx
00007e1ec07e186b  pop rcx
00007e1ec07e186c  pop rax
00007e1ec07e186d  add rsp, 0x08
00007e1ec07e1871  jmp 0x00007E1EC07DF33E
00007e1ec07e1876  sub rsp, 0x08
00007e1ec07e187a  push rax
00007e1ec07e187b  push rcx
00007e1ec07e187c  push rdx
00007e1ec07e187d  push rdi
00007e1ec07e187e  push rsi
00007e1ec07e187f  push r8
00007e1ec07e1881  push r9
00007e1ec07e1883  push r10
00007e1ec07e1885  push r11
00007e1ec07e1887  sub rsp, 0xF0
00007e1ec07e188e  vmovaps [rsp], xmm0
00007e1ec07e1893  vmovaps [rsp+0x10], xmm1
00007e1ec07e1899  vmovaps [rsp+0x20], xmm2
00007e1ec07e189f  vmovaps [rsp+0x30], xmm3
00007e1ec07e18a5  vmovaps [rsp+0x40], xmm4
00007e1ec07e18ab  vmovaps [rsp+0x50], xmm5
00007e1ec07e18b1  vmovaps [rsp+0x60], xmm6
00007e1ec07e18b7  vmovaps [rsp+0x70], xmm7
00007e1ec07e18bd  vmovaps [rsp+0x80], xmm8
00007e1ec07e18c6  vmovaps [rsp+0x90], xmm10
00007e1ec07e18cf  vmovaps [rsp+0xA0], xmm11
00007e1ec07e18d8  vmovaps [rsp+0xB0], xmm12
00007e1ec07e18e1  vmovaps [rsp+0xC0], xmm13
00007e1ec07e18ea  vmovaps [rsp+0xD0], xmm14
00007e1ec07e18f3  vmovaps [rsp+0xE0], xmm15
00007e1ec07e18fc  sub rsp, 0x30
00007e1ec07e1900  movaps [rsp], xmm9
00007e1ec07e1905  movaps [rsp+0x10], xmm3
00007e1ec07e190a  movaps [rsp+0x20], xmm1
00007e1ec07e190f  lea rdi, [rsp]
00007e1ec07e1913  mov esi, 0x00
00007e1ec07e1918  mov rax, 0x5E00FF778530
00007e1ec07e1922  call rax
00007e1ec07e1924  movaps xmm9, [rsp]
00007e1ec07e1929  add rsp, 0x30
00007e1ec07e192d  vmovaps xmm0, [rsp]
00007e1ec07e1932  vmovaps xmm1, [rsp+0x10]
00007e1ec07e1938  vmovaps xmm2, [rsp+0x20]
00007e1ec07e193e  vmovaps xmm3, [rsp+0x30]
00007e1ec07e1944  vmovaps xmm4, [rsp+0x40]
00007e1ec07e194a  vmovaps xmm5, [rsp+0x50]
00007e1ec07e1950  vmovaps xmm6, [rsp+0x60]
00007e1ec07e1956  vmovaps xmm7, [rsp+0x70]
00007e1ec07e195c  vmovaps xmm8, [rsp+0x80]
00007e1ec07e1965  vmovaps xmm10, [rsp+0x90]
00007e1ec07e196e  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e1977  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e1980  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e1989  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e1992  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e199b  add rsp, 0xF0
00007e1ec07e19a2  pop r11
00007e1ec07e19a4  pop r10
00007e1ec07e19a6  pop r9
00007e1ec07e19a8  pop r8
00007e1ec07e19aa  pop rsi
00007e1ec07e19ab  pop rdi
00007e1ec07e19ac  pop rdx
00007e1ec07e19ad  pop rcx
00007e1ec07e19ae  pop rax
00007e1ec07e19af  add rsp, 0x08
00007e1ec07e19b3  jmp 0x00007E1EC07DF38A
00007e1ec07e19b8  call 0x00007E1EC06B52F0
00007e1ec07e19bd  jmp 0x00007E1EC07DF397
00007e1ec07e19c2  sub rsp, 0x08
00007e1ec07e19c6  push rax
00007e1ec07e19c7  push rcx
00007e1ec07e19c8  push rdx
00007e1ec07e19c9  push rdi
00007e1ec07e19ca  push rsi
00007e1ec07e19cb  push r8
00007e1ec07e19cd  push r9
00007e1ec07e19cf  push r10
00007e1ec07e19d1  push r11
00007e1ec07e19d3  sub rsp, 0xF0
00007e1ec07e19da  vmovaps [rsp], xmm0
00007e1ec07e19df  vmovaps [rsp+0x10], xmm1
00007e1ec07e19e5  vmovaps [rsp+0x20], xmm2
00007e1ec07e19eb  vmovaps [rsp+0x30], xmm3
00007e1ec07e19f1  vmovaps [rsp+0x40], xmm4
00007e1ec07e19f7  vmovaps [rsp+0x50], xmm5
00007e1ec07e19fd  vmovaps [rsp+0x60], xmm6
00007e1ec07e1a03  vmovaps [rsp+0x70], xmm7
00007e1ec07e1a09  vmovaps [rsp+0x80], xmm8
00007e1ec07e1a12  vmovaps [rsp+0x90], xmm9
00007e1ec07e1a1b  vmovaps [rsp+0xA0], xmm10
00007e1ec07e1a24  vmovaps [rsp+0xB0], xmm11
00007e1ec07e1a2d  vmovaps [rsp+0xC0], xmm12
00007e1ec07e1a36  vmovaps [rsp+0xD0], xmm13
00007e1ec07e1a3f  vmovaps [rsp+0xE0], xmm14
00007e1ec07e1a48  sub rsp, 0x30
00007e1ec07e1a4c  movaps [rsp], xmm15
00007e1ec07e1a51  movaps [rsp+0x10], xmm3
00007e1ec07e1a56  movaps [rsp+0x20], xmm7
00007e1ec07e1a5b  lea rdi, [rsp]
00007e1ec07e1a5f  mov esi, 0x00
00007e1ec07e1a64  mov rax, 0x5E00FF778530
00007e1ec07e1a6e  call rax
00007e1ec07e1a70  movaps xmm15, [rsp]
00007e1ec07e1a75  add rsp, 0x30
00007e1ec07e1a79  vmovaps xmm0, [rsp]
00007e1ec07e1a7e  vmovaps xmm1, [rsp+0x10]
00007e1ec07e1a84  vmovaps xmm2, [rsp+0x20]
00007e1ec07e1a8a  vmovaps xmm3, [rsp+0x30]
00007e1ec07e1a90  vmovaps xmm4, [rsp+0x40]
00007e1ec07e1a96  vmovaps xmm5, [rsp+0x50]
00007e1ec07e1a9c  vmovaps xmm6, [rsp+0x60]
00007e1ec07e1aa2  vmovaps xmm7, [rsp+0x70]
00007e1ec07e1aa8  vmovaps xmm8, [rsp+0x80]
00007e1ec07e1ab1  vmovaps xmm9, [rsp+0x90]
00007e1ec07e1aba  vmovaps xmm10, [rsp+0xA0]
00007e1ec07e1ac3  vmovaps xmm11, [rsp+0xB0]
00007e1ec07e1acc  vmovaps xmm12, [rsp+0xC0]
00007e1ec07e1ad5  vmovaps xmm13, [rsp+0xD0]
00007e1ec07e1ade  vmovaps xmm14, [rsp+0xE0]
00007e1ec07e1ae7  add rsp, 0xF0
00007e1ec07e1aee  pop r11
00007e1ec07e1af0  pop r10
00007e1ec07e1af2  pop r9
00007e1ec07e1af4  pop r8
00007e1ec07e1af6  pop rsi
00007e1ec07e1af7  pop rdi
00007e1ec07e1af8  pop rdx
00007e1ec07e1af9  pop rcx
00007e1ec07e1afa  pop rax
00007e1ec07e1afb  add rsp, 0x08
00007e1ec07e1aff  jmp 0x00007E1EC07DF3C3
00007e1ec07e1b04  sub rsp, 0x08
00007e1ec07e1b08  push rax
00007e1ec07e1b09  push rcx
00007e1ec07e1b0a  push rdx
00007e1ec07e1b0b  push rdi
00007e1ec07e1b0c  push rsi
00007e1ec07e1b0d  push r8
00007e1ec07e1b0f  push r9
00007e1ec07e1b11  push r10
00007e1ec07e1b13  push r11
00007e1ec07e1b15  sub rsp, 0xF0
00007e1ec07e1b1c  vmovaps [rsp], xmm0
00007e1ec07e1b21  vmovaps [rsp+0x10], xmm1
00007e1ec07e1b27  vmovaps [rsp+0x20], xmm2
00007e1ec07e1b2d  vmovaps [rsp+0x30], xmm4
00007e1ec07e1b33  vmovaps [rsp+0x40], xmm5
00007e1ec07e1b39  vmovaps [rsp+0x50], xmm6
00007e1ec07e1b3f  vmovaps [rsp+0x60], xmm7
00007e1ec07e1b45  vmovaps [rsp+0x70], xmm8
00007e1ec07e1b4b  vmovaps [rsp+0x80], xmm9
00007e1ec07e1b54  vmovaps [rsp+0x90], xmm10
00007e1ec07e1b5d  vmovaps [rsp+0xA0], xmm11
00007e1ec07e1b66  vmovaps [rsp+0xB0], xmm12
00007e1ec07e1b6f  vmovaps [rsp+0xC0], xmm13
00007e1ec07e1b78  vmovaps [rsp+0xD0], xmm14
00007e1ec07e1b81  vmovaps [rsp+0xE0], xmm15
00007e1ec07e1b8a  sub rsp, 0x30
00007e1ec07e1b8e  movaps [rsp], xmm3
00007e1ec07e1b92  movaps [rsp+0x10], xmm1
00007e1ec07e1b97  movaps [rsp+0x20], xmm15
00007e1ec07e1b9d  lea rdi, [rsp]
00007e1ec07e1ba1  mov esi, 0x00
00007e1ec07e1ba6  mov rax, 0x5E00FF778530
00007e1ec07e1bb0  call rax
00007e1ec07e1bb2  movaps xmm3, [rsp]
00007e1ec07e1bb6  add rsp, 0x30
00007e1ec07e1bba  vmovaps xmm0, [rsp]
00007e1ec07e1bbf  vmovaps xmm1, [rsp+0x10]
00007e1ec07e1bc5  vmovaps xmm2, [rsp+0x20]
00007e1ec07e1bcb  vmovaps xmm4, [rsp+0x30]
00007e1ec07e1bd1  vmovaps xmm5, [rsp+0x40]
00007e1ec07e1bd7  vmovaps xmm6, [rsp+0x50]
00007e1ec07e1bdd  vmovaps xmm7, [rsp+0x60]
00007e1ec07e1be3  vmovaps xmm8, [rsp+0x70]
00007e1ec07e1be9  vmovaps xmm9, [rsp+0x80]
00007e1ec07e1bf2  vmovaps xmm10, [rsp+0x90]
00007e1ec07e1bfb  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e1c04  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e1c0d  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e1c16  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e1c1f  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e1c28  add rsp, 0xF0
00007e1ec07e1c2f  pop r11
00007e1ec07e1c31  pop r10
00007e1ec07e1c33  pop r9
00007e1ec07e1c35  pop r8
00007e1ec07e1c37  pop rsi
00007e1ec07e1c38  pop rdi
00007e1ec07e1c39  pop rdx
00007e1ec07e1c3a  pop rcx
00007e1ec07e1c3b  pop rax
00007e1ec07e1c3c  add rsp, 0x08
00007e1ec07e1c40  jmp 0x00007E1EC07DF452
00007e1ec07e1c45  call 0x00007E1EC06B52F0
00007e1ec07e1c4a  jmp 0x00007E1EC07DF45C
00007e1ec07e1c4f  sub rsp, 0x08
00007e1ec07e1c53  push rax
00007e1ec07e1c54  push rcx
00007e1ec07e1c55  push rdx
00007e1ec07e1c56  push rdi
00007e1ec07e1c57  push rsi
00007e1ec07e1c58  push r8
00007e1ec07e1c5a  push r9
00007e1ec07e1c5c  push r10
00007e1ec07e1c5e  push r11
00007e1ec07e1c60  sub rsp, 0xF0
00007e1ec07e1c67  vmovaps [rsp], xmm0
00007e1ec07e1c6c  vmovaps [rsp+0x10], xmm1
00007e1ec07e1c72  vmovaps [rsp+0x20], xmm2
00007e1ec07e1c78  vmovaps [rsp+0x30], xmm3
00007e1ec07e1c7e  vmovaps [rsp+0x40], xmm4
00007e1ec07e1c84  vmovaps [rsp+0x50], xmm5
00007e1ec07e1c8a  vmovaps [rsp+0x60], xmm6
00007e1ec07e1c90  vmovaps [rsp+0x70], xmm7
00007e1ec07e1c96  vmovaps [rsp+0x80], xmm8
00007e1ec07e1c9f  vmovaps [rsp+0x90], xmm9
00007e1ec07e1ca8  vmovaps [rsp+0xA0], xmm10
00007e1ec07e1cb1  vmovaps [rsp+0xB0], xmm11
00007e1ec07e1cba  vmovaps [rsp+0xC0], xmm12
00007e1ec07e1cc3  vmovaps [rsp+0xD0], xmm13
00007e1ec07e1ccc  vmovaps [rsp+0xE0], xmm14
00007e1ec07e1cd5  sub rsp, 0x30
00007e1ec07e1cd9  movaps [rsp], xmm15
00007e1ec07e1cde  movaps [rsp+0x10], xmm14
00007e1ec07e1ce4  movaps [rsp+0x20], xmm4
00007e1ec07e1ce9  lea rdi, [rsp]
00007e1ec07e1ced  mov esi, 0x00
00007e1ec07e1cf2  mov rax, 0x5E00FF778530
00007e1ec07e1cfc  call rax
00007e1ec07e1cfe  movaps xmm15, [rsp]
00007e1ec07e1d03  add rsp, 0x30
00007e1ec07e1d07  vmovaps xmm0, [rsp]
00007e1ec07e1d0c  vmovaps xmm1, [rsp+0x10]
00007e1ec07e1d12  vmovaps xmm2, [rsp+0x20]
00007e1ec07e1d18  vmovaps xmm3, [rsp+0x30]
00007e1ec07e1d1e  vmovaps xmm4, [rsp+0x40]
00007e1ec07e1d24  vmovaps xmm5, [rsp+0x50]
00007e1ec07e1d2a  vmovaps xmm6, [rsp+0x60]
00007e1ec07e1d30  vmovaps xmm7, [rsp+0x70]
00007e1ec07e1d36  vmovaps xmm8, [rsp+0x80]
00007e1ec07e1d3f  vmovaps xmm9, [rsp+0x90]
00007e1ec07e1d48  vmovaps xmm10, [rsp+0xA0]
00007e1ec07e1d51  vmovaps xmm11, [rsp+0xB0]
00007e1ec07e1d5a  vmovaps xmm12, [rsp+0xC0]
00007e1ec07e1d63  vmovaps xmm13, [rsp+0xD0]
00007e1ec07e1d6c  vmovaps xmm14, [rsp+0xE0]
00007e1ec07e1d75  add rsp, 0xF0
00007e1ec07e1d7c  pop r11
00007e1ec07e1d7e  pop r10
00007e1ec07e1d80  pop r9
00007e1ec07e1d82  pop r8
00007e1ec07e1d84  pop rsi
00007e1ec07e1d85  pop rdi
00007e1ec07e1d86  pop rdx
00007e1ec07e1d87  pop rcx
00007e1ec07e1d88  pop rax
00007e1ec07e1d89  add rsp, 0x08
00007e1ec07e1d8d  jmp 0x00007E1EC07DF48A
00007e1ec07e1d92  sub rsp, 0x08
00007e1ec07e1d96  push rax
00007e1ec07e1d97  push rcx
00007e1ec07e1d98  push rdx
00007e1ec07e1d99  push rdi
00007e1ec07e1d9a  push rsi
00007e1ec07e1d9b  push r8
00007e1ec07e1d9d  push r9
00007e1ec07e1d9f  push r10
00007e1ec07e1da1  push r11
00007e1ec07e1da3  sub rsp, 0xF0
00007e1ec07e1daa  vmovaps [rsp], xmm0
00007e1ec07e1daf  vmovaps [rsp+0x10], xmm1
00007e1ec07e1db5  vmovaps [rsp+0x20], xmm2
00007e1ec07e1dbb  vmovaps [rsp+0x30], xmm3
00007e1ec07e1dc1  vmovaps [rsp+0x40], xmm4
00007e1ec07e1dc7  vmovaps [rsp+0x50], xmm5
00007e1ec07e1dcd  vmovaps [rsp+0x60], xmm6
00007e1ec07e1dd3  vmovaps [rsp+0x70], xmm7
00007e1ec07e1dd9  vmovaps [rsp+0x80], xmm8
00007e1ec07e1de2  vmovaps [rsp+0x90], xmm9
00007e1ec07e1deb  vmovaps [rsp+0xA0], xmm10
00007e1ec07e1df4  vmovaps [rsp+0xB0], xmm11
00007e1ec07e1dfd  vmovaps [rsp+0xC0], xmm12
00007e1ec07e1e06  vmovaps [rsp+0xD0], xmm13
00007e1ec07e1e0f  vmovaps [rsp+0xE0], xmm15
00007e1ec07e1e18  sub rsp, 0x30
00007e1ec07e1e1c  movaps [rsp], xmm14
00007e1ec07e1e21  movaps [rsp+0x10], xmm2
00007e1ec07e1e26  movaps [rsp+0x20], xmm1
00007e1ec07e1e2b  lea rdi, [rsp]
00007e1ec07e1e2f  mov esi, 0x00
00007e1ec07e1e34  mov rax, 0x5E00FF778530
00007e1ec07e1e3e  call rax
00007e1ec07e1e40  movaps xmm14, [rsp]
00007e1ec07e1e45  add rsp, 0x30
00007e1ec07e1e49  vmovaps xmm0, [rsp]
00007e1ec07e1e4e  vmovaps xmm1, [rsp+0x10]
00007e1ec07e1e54  vmovaps xmm2, [rsp+0x20]
00007e1ec07e1e5a  vmovaps xmm3, [rsp+0x30]
00007e1ec07e1e60  vmovaps xmm4, [rsp+0x40]
00007e1ec07e1e66  vmovaps xmm5, [rsp+0x50]
00007e1ec07e1e6c  vmovaps xmm6, [rsp+0x60]
00007e1ec07e1e72  vmovaps xmm7, [rsp+0x70]
00007e1ec07e1e78  vmovaps xmm8, [rsp+0x80]
00007e1ec07e1e81  vmovaps xmm9, [rsp+0x90]
00007e1ec07e1e8a  vmovaps xmm10, [rsp+0xA0]
00007e1ec07e1e93  vmovaps xmm11, [rsp+0xB0]
00007e1ec07e1e9c  vmovaps xmm12, [rsp+0xC0]
00007e1ec07e1ea5  vmovaps xmm13, [rsp+0xD0]
00007e1ec07e1eae  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e1eb7  add rsp, 0xF0
00007e1ec07e1ebe  pop r11
00007e1ec07e1ec0  pop r10
00007e1ec07e1ec2  pop r9
00007e1ec07e1ec4  pop r8
00007e1ec07e1ec6  pop rsi
00007e1ec07e1ec7  pop rdi
00007e1ec07e1ec8  pop rdx
00007e1ec07e1ec9  pop rcx
00007e1ec07e1eca  pop rax
00007e1ec07e1ecb  add rsp, 0x08
00007e1ec07e1ecf  jmp 0x00007E1EC07DF4B0
00007e1ec07e1ed4  sub rsp, 0x08
00007e1ec07e1ed8  push rax
00007e1ec07e1ed9  push rcx
00007e1ec07e1eda  push rdx
00007e1ec07e1edb  push rdi
00007e1ec07e1edc  push rsi
00007e1ec07e1edd  push r8
00007e1ec07e1edf  push r9
00007e1ec07e1ee1  push r10
00007e1ec07e1ee3  push r11
00007e1ec07e1ee5  sub rsp, 0xF0
00007e1ec07e1eec  vmovaps [rsp], xmm0
00007e1ec07e1ef1  vmovaps [rsp+0x10], xmm2
00007e1ec07e1ef7  vmovaps [rsp+0x20], xmm3
00007e1ec07e1efd  vmovaps [rsp+0x30], xmm4
00007e1ec07e1f03  vmovaps [rsp+0x40], xmm5
00007e1ec07e1f09  vmovaps [rsp+0x50], xmm6
00007e1ec07e1f0f  vmovaps [rsp+0x60], xmm7
00007e1ec07e1f15  vmovaps [rsp+0x70], xmm8
00007e1ec07e1f1b  vmovaps [rsp+0x80], xmm9
00007e1ec07e1f24  vmovaps [rsp+0x90], xmm10
00007e1ec07e1f2d  vmovaps [rsp+0xA0], xmm11
00007e1ec07e1f36  vmovaps [rsp+0xB0], xmm12
00007e1ec07e1f3f  vmovaps [rsp+0xC0], xmm13
00007e1ec07e1f48  vmovaps [rsp+0xD0], xmm14
00007e1ec07e1f51  vmovaps [rsp+0xE0], xmm15
00007e1ec07e1f5a  sub rsp, 0x30
00007e1ec07e1f5e  movaps [rsp], xmm1
00007e1ec07e1f62  movaps [rsp+0x10], xmm4
00007e1ec07e1f67  movaps [rsp+0x20], xmm9
00007e1ec07e1f6d  lea rdi, [rsp]
00007e1ec07e1f71  mov esi, 0x00
00007e1ec07e1f76  mov rax, 0x5E00FF778530
00007e1ec07e1f80  call rax
00007e1ec07e1f82  movaps xmm1, [rsp]
00007e1ec07e1f86  add rsp, 0x30
00007e1ec07e1f8a  vmovaps xmm0, [rsp]
00007e1ec07e1f8f  vmovaps xmm2, [rsp+0x10]
00007e1ec07e1f95  vmovaps xmm3, [rsp+0x20]
00007e1ec07e1f9b  vmovaps xmm4, [rsp+0x30]
00007e1ec07e1fa1  vmovaps xmm5, [rsp+0x40]
00007e1ec07e1fa7  vmovaps xmm6, [rsp+0x50]
00007e1ec07e1fad  vmovaps xmm7, [rsp+0x60]
00007e1ec07e1fb3  vmovaps xmm8, [rsp+0x70]
00007e1ec07e1fb9  vmovaps xmm9, [rsp+0x80]
00007e1ec07e1fc2  vmovaps xmm10, [rsp+0x90]
00007e1ec07e1fcb  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e1fd4  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e1fdd  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e1fe6  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e1fef  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e1ff8  add rsp, 0xF0
00007e1ec07e1fff  pop r11
00007e1ec07e2001  pop r10
00007e1ec07e2003  pop r9
00007e1ec07e2005  pop r8
00007e1ec07e2007  pop rsi
00007e1ec07e2008  pop rdi
00007e1ec07e2009  pop rdx
00007e1ec07e200a  pop rcx
00007e1ec07e200b  pop rax
00007e1ec07e200c  add rsp, 0x08
00007e1ec07e2010  jmp 0x00007E1EC07DF4CE
00007e1ec07e2015  sub rsp, 0x08
00007e1ec07e2019  push rax
00007e1ec07e201a  push rcx
00007e1ec07e201b  push rdx
00007e1ec07e201c  push rdi
00007e1ec07e201d  push rsi
00007e1ec07e201e  push r8
00007e1ec07e2020  push r9
00007e1ec07e2022  push r10
00007e1ec07e2024  push r11
00007e1ec07e2026  sub rsp, 0xF0
00007e1ec07e202d  vmovaps [rsp], xmm0
00007e1ec07e2032  vmovaps [rsp+0x10], xmm1
00007e1ec07e2038  vmovaps [rsp+0x20], xmm2
00007e1ec07e203e  vmovaps [rsp+0x30], xmm3
00007e1ec07e2044  vmovaps [rsp+0x40], xmm5
00007e1ec07e204a  vmovaps [rsp+0x50], xmm6
00007e1ec07e2050  vmovaps [rsp+0x60], xmm7
00007e1ec07e2056  vmovaps [rsp+0x70], xmm8
00007e1ec07e205c  vmovaps [rsp+0x80], xmm9
00007e1ec07e2065  vmovaps [rsp+0x90], xmm10
00007e1ec07e206e  vmovaps [rsp+0xA0], xmm11
00007e1ec07e2077  vmovaps [rsp+0xB0], xmm12
00007e1ec07e2080  vmovaps [rsp+0xC0], xmm13
00007e1ec07e2089  vmovaps [rsp+0xD0], xmm14
00007e1ec07e2092  vmovaps [rsp+0xE0], xmm15
00007e1ec07e209b  sub rsp, 0x30
00007e1ec07e209f  movaps [rsp], xmm4
00007e1ec07e20a3  movaps [rsp+0x10], xmm2
00007e1ec07e20a8  movaps [rsp+0x20], xmm9
00007e1ec07e20ae  lea rdi, [rsp]
00007e1ec07e20b2  mov esi, 0x00
00007e1ec07e20b7  mov rax, 0x5E00FF778530
00007e1ec07e20c1  call rax
00007e1ec07e20c3  movaps xmm4, [rsp]
00007e1ec07e20c7  add rsp, 0x30
00007e1ec07e20cb  vmovaps xmm0, [rsp]
00007e1ec07e20d0  vmovaps xmm1, [rsp+0x10]
00007e1ec07e20d6  vmovaps xmm2, [rsp+0x20]
00007e1ec07e20dc  vmovaps xmm3, [rsp+0x30]
00007e1ec07e20e2  vmovaps xmm5, [rsp+0x40]
00007e1ec07e20e8  vmovaps xmm6, [rsp+0x50]
00007e1ec07e20ee  vmovaps xmm7, [rsp+0x60]
00007e1ec07e20f4  vmovaps xmm8, [rsp+0x70]
00007e1ec07e20fa  vmovaps xmm9, [rsp+0x80]
00007e1ec07e2103  vmovaps xmm10, [rsp+0x90]
00007e1ec07e210c  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e2115  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e211e  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e2127  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e2130  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e2139  add rsp, 0xF0
00007e1ec07e2140  pop r11
00007e1ec07e2142  pop r10
00007e1ec07e2144  pop r9
00007e1ec07e2146  pop r8
00007e1ec07e2148  pop rsi
00007e1ec07e2149  pop rdi
00007e1ec07e214a  pop rdx
00007e1ec07e214b  pop rcx
00007e1ec07e214c  pop rax
00007e1ec07e214d  add rsp, 0x08
00007e1ec07e2151  jmp 0x00007E1EC07DF4FE
00007e1ec07e2156  sub rsp, 0x08
00007e1ec07e215a  push rax
00007e1ec07e215b  push rcx
00007e1ec07e215c  push rdx
00007e1ec07e215d  push rdi
00007e1ec07e215e  push rsi
00007e1ec07e215f  push r8
00007e1ec07e2161  push r9
00007e1ec07e2163  push r10
00007e1ec07e2165  push r11
00007e1ec07e2167  sub rsp, 0xF0
00007e1ec07e216e  vmovaps [rsp], xmm0
00007e1ec07e2173  vmovaps [rsp+0x10], xmm1
00007e1ec07e2179  vmovaps [rsp+0x20], xmm2
00007e1ec07e217f  vmovaps [rsp+0x30], xmm3
00007e1ec07e2185  vmovaps [rsp+0x40], xmm4
00007e1ec07e218b  vmovaps [rsp+0x50], xmm5
00007e1ec07e2191  vmovaps [rsp+0x60], xmm6
00007e1ec07e2197  vmovaps [rsp+0x70], xmm7
00007e1ec07e219d  vmovaps [rsp+0x80], xmm8
00007e1ec07e21a6  vmovaps [rsp+0x90], xmm10
00007e1ec07e21af  vmovaps [rsp+0xA0], xmm11
00007e1ec07e21b8  vmovaps [rsp+0xB0], xmm12
00007e1ec07e21c1  vmovaps [rsp+0xC0], xmm13
00007e1ec07e21ca  vmovaps [rsp+0xD0], xmm14
00007e1ec07e21d3  vmovaps [rsp+0xE0], xmm15
00007e1ec07e21dc  sub rsp, 0x30
00007e1ec07e21e0  movaps [rsp], xmm9
00007e1ec07e21e5  movaps [rsp+0x10], xmm2
00007e1ec07e21ea  movaps [rsp+0x20], xmm1
00007e1ec07e21ef  lea rdi, [rsp]
00007e1ec07e21f3  mov esi, 0x00
00007e1ec07e21f8  mov rax, 0x5E00FF778530
00007e1ec07e2202  call rax
00007e1ec07e2204  movaps xmm9, [rsp]
00007e1ec07e2209  add rsp, 0x30
00007e1ec07e220d  vmovaps xmm0, [rsp]
00007e1ec07e2212  vmovaps xmm1, [rsp+0x10]
00007e1ec07e2218  vmovaps xmm2, [rsp+0x20]
00007e1ec07e221e  vmovaps xmm3, [rsp+0x30]
00007e1ec07e2224  vmovaps xmm4, [rsp+0x40]
00007e1ec07e222a  vmovaps xmm5, [rsp+0x50]
00007e1ec07e2230  vmovaps xmm6, [rsp+0x60]
00007e1ec07e2236  vmovaps xmm7, [rsp+0x70]
00007e1ec07e223c  vmovaps xmm8, [rsp+0x80]
00007e1ec07e2245  vmovaps xmm10, [rsp+0x90]
00007e1ec07e224e  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e2257  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e2260  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e2269  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e2272  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e227b  add rsp, 0xF0
00007e1ec07e2282  pop r11
00007e1ec07e2284  pop r10
00007e1ec07e2286  pop r9
00007e1ec07e2288  pop r8
00007e1ec07e228a  pop rsi
00007e1ec07e228b  pop rdi
00007e1ec07e228c  pop rdx
00007e1ec07e228d  pop rcx
00007e1ec07e228e  pop rax
00007e1ec07e228f  add rsp, 0x08
00007e1ec07e2293  jmp 0x00007E1EC07DF534
00007e1ec07e2298  sub rsp, 0x08
00007e1ec07e229c  push rax
00007e1ec07e229d  push rcx
00007e1ec07e229e  push rdx
00007e1ec07e229f  push rdi
00007e1ec07e22a0  push rsi
00007e1ec07e22a1  push r8
00007e1ec07e22a3  push r9
00007e1ec07e22a5  push r10
00007e1ec07e22a7  push r11
00007e1ec07e22a9  sub rsp, 0xF0
00007e1ec07e22b0  vmovaps [rsp], xmm0
00007e1ec07e22b5  vmovaps [rsp+0x10], xmm2
00007e1ec07e22bb  vmovaps [rsp+0x20], xmm3
00007e1ec07e22c1  vmovaps [rsp+0x30], xmm4
00007e1ec07e22c7  vmovaps [rsp+0x40], xmm5
00007e1ec07e22cd  vmovaps [rsp+0x50], xmm6
00007e1ec07e22d3  vmovaps [rsp+0x60], xmm7
00007e1ec07e22d9  vmovaps [rsp+0x70], xmm8
00007e1ec07e22df  vmovaps [rsp+0x80], xmm9
00007e1ec07e22e8  vmovaps [rsp+0x90], xmm10
00007e1ec07e22f1  vmovaps [rsp+0xA0], xmm11
00007e1ec07e22fa  vmovaps [rsp+0xB0], xmm12
00007e1ec07e2303  vmovaps [rsp+0xC0], xmm13
00007e1ec07e230c  vmovaps [rsp+0xD0], xmm14
00007e1ec07e2315  vmovaps [rsp+0xE0], xmm15
00007e1ec07e231e  sub rsp, 0x30
00007e1ec07e2322  movaps [rsp], xmm1
00007e1ec07e2326  movaps [rsp+0x10], xmm15
00007e1ec07e232c  movaps [rsp+0x20], xmm6
00007e1ec07e2331  lea rdi, [rsp]
00007e1ec07e2335  mov esi, 0x00
00007e1ec07e233a  mov rax, 0x5E00FF778530
00007e1ec07e2344  call rax
00007e1ec07e2346  movaps xmm1, [rsp]
00007e1ec07e234a  add rsp, 0x30
00007e1ec07e234e  vmovaps xmm0, [rsp]
00007e1ec07e2353  vmovaps xmm2, [rsp+0x10]
00007e1ec07e2359  vmovaps xmm3, [rsp+0x20]
00007e1ec07e235f  vmovaps xmm4, [rsp+0x30]
00007e1ec07e2365  vmovaps xmm5, [rsp+0x40]
00007e1ec07e236b  vmovaps xmm6, [rsp+0x50]
00007e1ec07e2371  vmovaps xmm7, [rsp+0x60]
00007e1ec07e2377  vmovaps xmm8, [rsp+0x70]
00007e1ec07e237d  vmovaps xmm9, [rsp+0x80]
00007e1ec07e2386  vmovaps xmm10, [rsp+0x90]
00007e1ec07e238f  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e2398  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e23a1  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e23aa  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e23b3  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e23bc  add rsp, 0xF0
00007e1ec07e23c3  pop r11
00007e1ec07e23c5  pop r10
00007e1ec07e23c7  pop r9
00007e1ec07e23c9  pop r8
00007e1ec07e23cb  pop rsi
00007e1ec07e23cc  pop rdi
00007e1ec07e23cd  pop rdx
00007e1ec07e23ce  pop rcx
00007e1ec07e23cf  pop rax
00007e1ec07e23d0  add rsp, 0x08
00007e1ec07e23d4  jmp 0x00007E1EC07DF555
00007e1ec07e23d9  sub rsp, 0x08
00007e1ec07e23dd  push rax
00007e1ec07e23de  push rcx
00007e1ec07e23df  push rdx
00007e1ec07e23e0  push rdi
00007e1ec07e23e1  push rsi
00007e1ec07e23e2  push r8
00007e1ec07e23e4  push r9
00007e1ec07e23e6  push r10
00007e1ec07e23e8  push r11
00007e1ec07e23ea  sub rsp, 0xF0
00007e1ec07e23f1  vmovaps [rsp], xmm0
00007e1ec07e23f6  vmovaps [rsp+0x10], xmm1
00007e1ec07e23fc  vmovaps [rsp+0x20], xmm2
00007e1ec07e2402  vmovaps [rsp+0x30], xmm3
00007e1ec07e2408  vmovaps [rsp+0x40], xmm4
00007e1ec07e240e  vmovaps [rsp+0x50], xmm5
00007e1ec07e2414  vmovaps [rsp+0x60], xmm6
00007e1ec07e241a  vmovaps [rsp+0x70], xmm7
00007e1ec07e2420  vmovaps [rsp+0x80], xmm8
00007e1ec07e2429  vmovaps [rsp+0x90], xmm9
00007e1ec07e2432  vmovaps [rsp+0xA0], xmm10
00007e1ec07e243b  vmovaps [rsp+0xB0], xmm11
00007e1ec07e2444  vmovaps [rsp+0xC0], xmm12
00007e1ec07e244d  vmovaps [rsp+0xD0], xmm13
00007e1ec07e2456  vmovaps [rsp+0xE0], xmm14
00007e1ec07e245f  sub rsp, 0x30
00007e1ec07e2463  movaps [rsp], xmm15
00007e1ec07e2468  movaps [rsp+0x10], xmm5
00007e1ec07e246d  movaps [rsp+0x20], xmm3
00007e1ec07e2472  lea rdi, [rsp]
00007e1ec07e2476  mov esi, 0x00
00007e1ec07e247b  mov rax, 0x5E00FF778530
00007e1ec07e2485  call rax
00007e1ec07e2487  movaps xmm15, [rsp]
00007e1ec07e248c  add rsp, 0x30
00007e1ec07e2490  vmovaps xmm0, [rsp]
00007e1ec07e2495  vmovaps xmm1, [rsp+0x10]
00007e1ec07e249b  vmovaps xmm2, [rsp+0x20]
00007e1ec07e24a1  vmovaps xmm3, [rsp+0x30]
00007e1ec07e24a7  vmovaps xmm4, [rsp+0x40]
00007e1ec07e24ad  vmovaps xmm5, [rsp+0x50]
00007e1ec07e24b3  vmovaps xmm6, [rsp+0x60]
00007e1ec07e24b9  vmovaps xmm7, [rsp+0x70]
00007e1ec07e24bf  vmovaps xmm8, [rsp+0x80]
00007e1ec07e24c8  vmovaps xmm9, [rsp+0x90]
00007e1ec07e24d1  vmovaps xmm10, [rsp+0xA0]
00007e1ec07e24da  vmovaps xmm11, [rsp+0xB0]
00007e1ec07e24e3  vmovaps xmm12, [rsp+0xC0]
00007e1ec07e24ec  vmovaps xmm13, [rsp+0xD0]
00007e1ec07e24f5  vmovaps xmm14, [rsp+0xE0]
00007e1ec07e24fe  add rsp, 0xF0
00007e1ec07e2505  pop r11
00007e1ec07e2507  pop r10
00007e1ec07e2509  pop r9
00007e1ec07e250b  pop r8
00007e1ec07e250d  pop rsi
00007e1ec07e250e  pop rdi
00007e1ec07e250f  pop rdx
00007e1ec07e2510  pop rcx
00007e1ec07e2511  pop rax
00007e1ec07e2512  add rsp, 0x08
00007e1ec07e2516  jmp 0x00007E1EC07DF56F
00007e1ec07e251b  sub rsp, 0x08
00007e1ec07e251f  push rax
00007e1ec07e2520  push rcx
00007e1ec07e2521  push rdx
00007e1ec07e2522  push rdi
00007e1ec07e2523  push rsi
00007e1ec07e2524  push r8
00007e1ec07e2526  push r9
00007e1ec07e2528  push r10
00007e1ec07e252a  push r11
00007e1ec07e252c  sub rsp, 0xF0
00007e1ec07e2533  vmovaps [rsp], xmm0
00007e1ec07e2538  vmovaps [rsp+0x10], xmm1
00007e1ec07e253e  vmovaps [rsp+0x20], xmm2
00007e1ec07e2544  vmovaps [rsp+0x30], xmm3
00007e1ec07e254a  vmovaps [rsp+0x40], xmm4
00007e1ec07e2550  vmovaps [rsp+0x50], xmm6
00007e1ec07e2556  vmovaps [rsp+0x60], xmm7
00007e1ec07e255c  vmovaps [rsp+0x70], xmm8
00007e1ec07e2562  vmovaps [rsp+0x80], xmm9
00007e1ec07e256b  vmovaps [rsp+0x90], xmm10
00007e1ec07e2574  vmovaps [rsp+0xA0], xmm11
00007e1ec07e257d  vmovaps [rsp+0xB0], xmm12
00007e1ec07e2586  vmovaps [rsp+0xC0], xmm13
00007e1ec07e258f  vmovaps [rsp+0xD0], xmm14
00007e1ec07e2598  vmovaps [rsp+0xE0], xmm15
00007e1ec07e25a1  sub rsp, 0x30
00007e1ec07e25a5  movaps [rsp], xmm5
00007e1ec07e25a9  movaps [rsp+0x10], xmm8
00007e1ec07e25af  movaps [rsp+0x20], xmm6
00007e1ec07e25b4  lea rdi, [rsp]
00007e1ec07e25b8  mov esi, 0x00
00007e1ec07e25bd  mov rax, 0x5E00FF778530
00007e1ec07e25c7  call rax
00007e1ec07e25c9  movaps xmm5, [rsp]
00007e1ec07e25cd  add rsp, 0x30
00007e1ec07e25d1  vmovaps xmm0, [rsp]
00007e1ec07e25d6  vmovaps xmm1, [rsp+0x10]
00007e1ec07e25dc  vmovaps xmm2, [rsp+0x20]
00007e1ec07e25e2  vmovaps xmm3, [rsp+0x30]
00007e1ec07e25e8  vmovaps xmm4, [rsp+0x40]
00007e1ec07e25ee  vmovaps xmm6, [rsp+0x50]
00007e1ec07e25f4  vmovaps xmm7, [rsp+0x60]
00007e1ec07e25fa  vmovaps xmm8, [rsp+0x70]
00007e1ec07e2600  vmovaps xmm9, [rsp+0x80]
00007e1ec07e2609  vmovaps xmm10, [rsp+0x90]
00007e1ec07e2612  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e261b  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e2624  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e262d  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e2636  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e263f  add rsp, 0xF0
00007e1ec07e2646  pop r11
00007e1ec07e2648  pop r10
00007e1ec07e264a  pop r9
00007e1ec07e264c  pop r8
00007e1ec07e264e  pop rsi
00007e1ec07e264f  pop rdi
00007e1ec07e2650  pop rdx
00007e1ec07e2651  pop rcx
00007e1ec07e2652  pop rax
00007e1ec07e2653  add rsp, 0x08
00007e1ec07e2657  jmp 0x00007E1EC07DF593
00007e1ec07e265c  sub rsp, 0x08
00007e1ec07e2660  push rax
00007e1ec07e2661  push rcx
00007e1ec07e2662  push rdx
00007e1ec07e2663  push rdi
00007e1ec07e2664  push rsi
00007e1ec07e2665  push r8
00007e1ec07e2667  push r9
00007e1ec07e2669  push r10
00007e1ec07e266b  push r11
00007e1ec07e266d  sub rsp, 0xF0
00007e1ec07e2674  vmovaps [rsp], xmm0
00007e1ec07e2679  vmovaps [rsp+0x10], xmm1
00007e1ec07e267f  vmovaps [rsp+0x20], xmm2
00007e1ec07e2685  vmovaps [rsp+0x30], xmm3
00007e1ec07e268b  vmovaps [rsp+0x40], xmm4
00007e1ec07e2691  vmovaps [rsp+0x50], xmm5
00007e1ec07e2697  vmovaps [rsp+0x60], xmm7
00007e1ec07e269d  vmovaps [rsp+0x70], xmm8
00007e1ec07e26a3  vmovaps [rsp+0x80], xmm9
00007e1ec07e26ac  vmovaps [rsp+0x90], xmm10
00007e1ec07e26b5  vmovaps [rsp+0xA0], xmm11
00007e1ec07e26be  vmovaps [rsp+0xB0], xmm12
00007e1ec07e26c7  vmovaps [rsp+0xC0], xmm13
00007e1ec07e26d0  vmovaps [rsp+0xD0], xmm14
00007e1ec07e26d9  vmovaps [rsp+0xE0], xmm15
00007e1ec07e26e2  sub rsp, 0x30
00007e1ec07e26e6  movaps [rsp], xmm6
00007e1ec07e26ea  movaps [rsp+0x10], xmm10
00007e1ec07e26f0  movaps [rsp+0x20], xmm8
00007e1ec07e26f6  lea rdi, [rsp]
00007e1ec07e26fa  mov esi, 0x00
00007e1ec07e26ff  mov rax, 0x5E00FF778530
00007e1ec07e2709  call rax
00007e1ec07e270b  movaps xmm6, [rsp]
00007e1ec07e270f  add rsp, 0x30
00007e1ec07e2713  vmovaps xmm0, [rsp]
00007e1ec07e2718  vmovaps xmm1, [rsp+0x10]
00007e1ec07e271e  vmovaps xmm2, [rsp+0x20]
00007e1ec07e2724  vmovaps xmm3, [rsp+0x30]
00007e1ec07e272a  vmovaps xmm4, [rsp+0x40]
00007e1ec07e2730  vmovaps xmm5, [rsp+0x50]
00007e1ec07e2736  vmovaps xmm7, [rsp+0x60]
00007e1ec07e273c  vmovaps xmm8, [rsp+0x70]
00007e1ec07e2742  vmovaps xmm9, [rsp+0x80]
00007e1ec07e274b  vmovaps xmm10, [rsp+0x90]
00007e1ec07e2754  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e275d  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e2766  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e276f  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e2778  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e2781  add rsp, 0xF0
00007e1ec07e2788  pop r11
00007e1ec07e278a  pop r10
00007e1ec07e278c  pop r9
00007e1ec07e278e  pop r8
00007e1ec07e2790  pop rsi
00007e1ec07e2791  pop rdi
00007e1ec07e2792  pop rdx
00007e1ec07e2793  pop rcx
00007e1ec07e2794  pop rax
00007e1ec07e2795  add rsp, 0x08
00007e1ec07e2799  jmp 0x00007E1EC07DF5B8
00007e1ec07e279e  sub rsp, 0x08
00007e1ec07e27a2  push rax
00007e1ec07e27a3  push rcx
00007e1ec07e27a4  push rdx
00007e1ec07e27a5  push rdi
00007e1ec07e27a6  push rsi
00007e1ec07e27a7  push r8
00007e1ec07e27a9  push r9
00007e1ec07e27ab  push r10
00007e1ec07e27ad  push r11
00007e1ec07e27af  sub rsp, 0xF0
00007e1ec07e27b6  vmovaps [rsp], xmm0
00007e1ec07e27bb  vmovaps [rsp+0x10], xmm1
00007e1ec07e27c1  vmovaps [rsp+0x20], xmm2
00007e1ec07e27c7  vmovaps [rsp+0x30], xmm3
00007e1ec07e27cd  vmovaps [rsp+0x40], xmm4
00007e1ec07e27d3  vmovaps [rsp+0x50], xmm5
00007e1ec07e27d9  vmovaps [rsp+0x60], xmm6
00007e1ec07e27df  vmovaps [rsp+0x70], xmm7
00007e1ec07e27e5  vmovaps [rsp+0x80], xmm8
00007e1ec07e27ee  vmovaps [rsp+0x90], xmm9
00007e1ec07e27f7  vmovaps [rsp+0xA0], xmm11
00007e1ec07e2800  vmovaps [rsp+0xB0], xmm12
00007e1ec07e2809  vmovaps [rsp+0xC0], xmm13
00007e1ec07e2812  vmovaps [rsp+0xD0], xmm14
00007e1ec07e281b  vmovaps [rsp+0xE0], xmm15
00007e1ec07e2824  sub rsp, 0x30
00007e1ec07e2828  movaps [rsp], xmm10
00007e1ec07e282d  movaps [rsp+0x10], xmm8
00007e1ec07e2833  movaps [rsp+0x20], xmm14
00007e1ec07e2839  lea rdi, [rsp]
00007e1ec07e283d  mov esi, 0x00
00007e1ec07e2842  mov rax, 0x5E00FF778530
00007e1ec07e284c  call rax
00007e1ec07e284e  movaps xmm10, [rsp]
00007e1ec07e2853  add rsp, 0x30
00007e1ec07e2857  vmovaps xmm0, [rsp]
00007e1ec07e285c  vmovaps xmm1, [rsp+0x10]
00007e1ec07e2862  vmovaps xmm2, [rsp+0x20]
00007e1ec07e2868  vmovaps xmm3, [rsp+0x30]
00007e1ec07e286e  vmovaps xmm4, [rsp+0x40]
00007e1ec07e2874  vmovaps xmm5, [rsp+0x50]
00007e1ec07e287a  vmovaps xmm6, [rsp+0x60]
00007e1ec07e2880  vmovaps xmm7, [rsp+0x70]
00007e1ec07e2886  vmovaps xmm8, [rsp+0x80]
00007e1ec07e288f  vmovaps xmm9, [rsp+0x90]
00007e1ec07e2898  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e28a1  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e28aa  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e28b3  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e28bc  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e28c5  add rsp, 0xF0
00007e1ec07e28cc  pop r11
00007e1ec07e28ce  pop r10
00007e1ec07e28d0  pop r9
00007e1ec07e28d2  pop r8
00007e1ec07e28d4  pop rsi
00007e1ec07e28d5  pop rdi
00007e1ec07e28d6  pop rdx
00007e1ec07e28d7  pop rcx
00007e1ec07e28d8  pop rax
00007e1ec07e28d9  add rsp, 0x08
00007e1ec07e28dd  jmp 0x00007E1EC07DF5D8
00007e1ec07e28e2  sub rsp, 0x08
00007e1ec07e28e6  push rax
00007e1ec07e28e7  push rcx
00007e1ec07e28e8  push rdx
00007e1ec07e28e9  push rdi
00007e1ec07e28ea  push rsi
00007e1ec07e28eb  push r8
00007e1ec07e28ed  push r9
00007e1ec07e28ef  push r10
00007e1ec07e28f1  push r11
00007e1ec07e28f3  sub rsp, 0xF0
00007e1ec07e28fa  vmovaps [rsp], xmm0
00007e1ec07e28ff  vmovaps [rsp+0x10], xmm1
00007e1ec07e2905  vmovaps [rsp+0x20], xmm2
00007e1ec07e290b  vmovaps [rsp+0x30], xmm3
00007e1ec07e2911  vmovaps [rsp+0x40], xmm4
00007e1ec07e2917  vmovaps [rsp+0x50], xmm5
00007e1ec07e291d  vmovaps [rsp+0x60], xmm6
00007e1ec07e2923  vmovaps [rsp+0x70], xmm7
00007e1ec07e2929  vmovaps [rsp+0x80], xmm8
00007e1ec07e2932  vmovaps [rsp+0x90], xmm9
00007e1ec07e293b  vmovaps [rsp+0xA0], xmm10
00007e1ec07e2944  vmovaps [rsp+0xB0], xmm11
00007e1ec07e294d  vmovaps [rsp+0xC0], xmm12
00007e1ec07e2956  vmovaps [rsp+0xD0], xmm13
00007e1ec07e295f  vmovaps [rsp+0xE0], xmm15
00007e1ec07e2968  sub rsp, 0x30
00007e1ec07e296c  movaps [rsp], xmm14
00007e1ec07e2971  movaps [rsp+0x10], xmm8
00007e1ec07e2977  movaps [rsp+0x20], xmm4
00007e1ec07e297c  lea rdi, [rsp]
00007e1ec07e2980  mov esi, 0x00
00007e1ec07e2985  mov rax, 0x5E00FF778530
00007e1ec07e298f  call rax
00007e1ec07e2991  movaps xmm14, [rsp]
00007e1ec07e2996  add rsp, 0x30
00007e1ec07e299a  vmovaps xmm0, [rsp]
00007e1ec07e299f  vmovaps xmm1, [rsp+0x10]
00007e1ec07e29a5  vmovaps xmm2, [rsp+0x20]
00007e1ec07e29ab  vmovaps xmm3, [rsp+0x30]
00007e1ec07e29b1  vmovaps xmm4, [rsp+0x40]
00007e1ec07e29b7  vmovaps xmm5, [rsp+0x50]
00007e1ec07e29bd  vmovaps xmm6, [rsp+0x60]
00007e1ec07e29c3  vmovaps xmm7, [rsp+0x70]
00007e1ec07e29c9  vmovaps xmm8, [rsp+0x80]
00007e1ec07e29d2  vmovaps xmm9, [rsp+0x90]
00007e1ec07e29db  vmovaps xmm10, [rsp+0xA0]
00007e1ec07e29e4  vmovaps xmm11, [rsp+0xB0]
00007e1ec07e29ed  vmovaps xmm12, [rsp+0xC0]
00007e1ec07e29f6  vmovaps xmm13, [rsp+0xD0]
00007e1ec07e29ff  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e2a08  add rsp, 0xF0
00007e1ec07e2a0f  pop r11
00007e1ec07e2a11  pop r10
00007e1ec07e2a13  pop r9
00007e1ec07e2a15  pop r8
00007e1ec07e2a17  pop rsi
00007e1ec07e2a18  pop rdi
00007e1ec07e2a19  pop rdx
00007e1ec07e2a1a  pop rcx
00007e1ec07e2a1b  pop rax
00007e1ec07e2a1c  add rsp, 0x08
00007e1ec07e2a20  jmp 0x00007E1EC07DF5F8
00007e1ec07e2a25  sub rsp, 0x08
00007e1ec07e2a29  push rax
00007e1ec07e2a2a  push rcx
00007e1ec07e2a2b  push rdx
00007e1ec07e2a2c  push rdi
00007e1ec07e2a2d  push rsi
00007e1ec07e2a2e  push r8
00007e1ec07e2a30  push r9
00007e1ec07e2a32  push r10
00007e1ec07e2a34  push r11
00007e1ec07e2a36  sub rsp, 0xF0
00007e1ec07e2a3d  vmovaps [rsp], xmm0
00007e1ec07e2a42  vmovaps [rsp+0x10], xmm1
00007e1ec07e2a48  vmovaps [rsp+0x20], xmm2
00007e1ec07e2a4e  vmovaps [rsp+0x30], xmm3
00007e1ec07e2a54  vmovaps [rsp+0x40], xmm5
00007e1ec07e2a5a  vmovaps [rsp+0x50], xmm6
00007e1ec07e2a60  vmovaps [rsp+0x60], xmm7
00007e1ec07e2a66  vmovaps [rsp+0x70], xmm8
00007e1ec07e2a6c  vmovaps [rsp+0x80], xmm9
00007e1ec07e2a75  vmovaps [rsp+0x90], xmm10
00007e1ec07e2a7e  vmovaps [rsp+0xA0], xmm11
00007e1ec07e2a87  vmovaps [rsp+0xB0], xmm12
00007e1ec07e2a90  vmovaps [rsp+0xC0], xmm13
00007e1ec07e2a99  vmovaps [rsp+0xD0], xmm14
00007e1ec07e2aa2  vmovaps [rsp+0xE0], xmm15
00007e1ec07e2aab  sub rsp, 0x30
00007e1ec07e2aaf  movaps [rsp], xmm4
00007e1ec07e2ab3  movaps [rsp+0x10], xmm13
00007e1ec07e2ab9  movaps [rsp+0x20], xmm8
00007e1ec07e2abf  lea rdi, [rsp]
00007e1ec07e2ac3  mov esi, 0x00
00007e1ec07e2ac8  mov rax, 0x5E00FF778530
00007e1ec07e2ad2  call rax
00007e1ec07e2ad4  movaps xmm4, [rsp]
00007e1ec07e2ad8  add rsp, 0x30
00007e1ec07e2adc  vmovaps xmm0, [rsp]
00007e1ec07e2ae1  vmovaps xmm1, [rsp+0x10]
00007e1ec07e2ae7  vmovaps xmm2, [rsp+0x20]
00007e1ec07e2aed  vmovaps xmm3, [rsp+0x30]
00007e1ec07e2af3  vmovaps xmm5, [rsp+0x40]
00007e1ec07e2af9  vmovaps xmm6, [rsp+0x50]
00007e1ec07e2aff  vmovaps xmm7, [rsp+0x60]
00007e1ec07e2b05  vmovaps xmm8, [rsp+0x70]
00007e1ec07e2b0b  vmovaps xmm9, [rsp+0x80]
00007e1ec07e2b14  vmovaps xmm10, [rsp+0x90]
00007e1ec07e2b1d  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e2b26  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e2b2f  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e2b38  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e2b41  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e2b4a  add rsp, 0xF0
00007e1ec07e2b51  pop r11
00007e1ec07e2b53  pop r10
00007e1ec07e2b55  pop r9
00007e1ec07e2b57  pop r8
00007e1ec07e2b59  pop rsi
00007e1ec07e2b5a  pop rdi
00007e1ec07e2b5b  pop rdx
00007e1ec07e2b5c  pop rcx
00007e1ec07e2b5d  pop rax
00007e1ec07e2b5e  add rsp, 0x08
00007e1ec07e2b62  jmp 0x00007E1EC07DF61D
00007e1ec07e2b67  sub rsp, 0x08
00007e1ec07e2b6b  push rax
00007e1ec07e2b6c  push rcx
00007e1ec07e2b6d  push rdx
00007e1ec07e2b6e  push rdi
00007e1ec07e2b6f  push rsi
00007e1ec07e2b70  push r8
00007e1ec07e2b72  push r9
00007e1ec07e2b74  push r10
00007e1ec07e2b76  push r11
00007e1ec07e2b78  sub rsp, 0xF0
00007e1ec07e2b7f  vmovaps [rsp], xmm0
00007e1ec07e2b84  vmovaps [rsp+0x10], xmm1
00007e1ec07e2b8a  vmovaps [rsp+0x20], xmm2
00007e1ec07e2b90  vmovaps [rsp+0x30], xmm3
00007e1ec07e2b96  vmovaps [rsp+0x40], xmm4
00007e1ec07e2b9c  vmovaps [rsp+0x50], xmm5
00007e1ec07e2ba2  vmovaps [rsp+0x60], xmm6
00007e1ec07e2ba8  vmovaps [rsp+0x70], xmm7
00007e1ec07e2bae  vmovaps [rsp+0x80], xmm8
00007e1ec07e2bb7  vmovaps [rsp+0x90], xmm9
00007e1ec07e2bc0  vmovaps [rsp+0xA0], xmm10
00007e1ec07e2bc9  vmovaps [rsp+0xB0], xmm11
00007e1ec07e2bd2  vmovaps [rsp+0xC0], xmm12
00007e1ec07e2bdb  vmovaps [rsp+0xD0], xmm14
00007e1ec07e2be4  vmovaps [rsp+0xE0], xmm15
00007e1ec07e2bed  sub rsp, 0x30
00007e1ec07e2bf1  movaps [rsp], xmm13
00007e1ec07e2bf6  movaps [rsp+0x10], xmm15
00007e1ec07e2bfc  movaps [rsp+0x20], xmm9
00007e1ec07e2c02  lea rdi, [rsp]
00007e1ec07e2c06  mov esi, 0x00
00007e1ec07e2c0b  mov rax, 0x5E00FF778530
00007e1ec07e2c15  call rax
00007e1ec07e2c17  movaps xmm13, [rsp]
00007e1ec07e2c1c  add rsp, 0x30
00007e1ec07e2c20  vmovaps xmm0, [rsp]
00007e1ec07e2c25  vmovaps xmm1, [rsp+0x10]
00007e1ec07e2c2b  vmovaps xmm2, [rsp+0x20]
00007e1ec07e2c31  vmovaps xmm3, [rsp+0x30]
00007e1ec07e2c37  vmovaps xmm4, [rsp+0x40]
00007e1ec07e2c3d  vmovaps xmm5, [rsp+0x50]
00007e1ec07e2c43  vmovaps xmm6, [rsp+0x60]
00007e1ec07e2c49  vmovaps xmm7, [rsp+0x70]
00007e1ec07e2c4f  vmovaps xmm8, [rsp+0x80]
00007e1ec07e2c58  vmovaps xmm9, [rsp+0x90]
00007e1ec07e2c61  vmovaps xmm10, [rsp+0xA0]
00007e1ec07e2c6a  vmovaps xmm11, [rsp+0xB0]
00007e1ec07e2c73  vmovaps xmm12, [rsp+0xC0]
00007e1ec07e2c7c  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e2c85  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e2c8e  add rsp, 0xF0
00007e1ec07e2c95  pop r11
00007e1ec07e2c97  pop r10
00007e1ec07e2c99  pop r9
00007e1ec07e2c9b  pop r8
00007e1ec07e2c9d  pop rsi
00007e1ec07e2c9e  pop rdi
00007e1ec07e2c9f  pop rdx
00007e1ec07e2ca0  pop rcx
00007e1ec07e2ca1  pop rax
00007e1ec07e2ca2  add rsp, 0x08
00007e1ec07e2ca6  jmp 0x00007E1EC07DF638
00007e1ec07e2cab  sub rsp, 0x08
00007e1ec07e2caf  push rax
00007e1ec07e2cb0  push rcx
00007e1ec07e2cb1  push rdx
00007e1ec07e2cb2  push rdi
00007e1ec07e2cb3  push rsi
00007e1ec07e2cb4  push r8
00007e1ec07e2cb6  push r9
00007e1ec07e2cb8  push r10
00007e1ec07e2cba  push r11
00007e1ec07e2cbc  sub rsp, 0xF0
00007e1ec07e2cc3  vmovaps [rsp], xmm0
00007e1ec07e2cc8  vmovaps [rsp+0x10], xmm1
00007e1ec07e2cce  vmovaps [rsp+0x20], xmm2
00007e1ec07e2cd4  vmovaps [rsp+0x30], xmm3
00007e1ec07e2cda  vmovaps [rsp+0x40], xmm4
00007e1ec07e2ce0  vmovaps [rsp+0x50], xmm5
00007e1ec07e2ce6  vmovaps [rsp+0x60], xmm6
00007e1ec07e2cec  vmovaps [rsp+0x70], xmm7
00007e1ec07e2cf2  vmovaps [rsp+0x80], xmm8
00007e1ec07e2cfb  vmovaps [rsp+0x90], xmm9
00007e1ec07e2d04  vmovaps [rsp+0xA0], xmm10
00007e1ec07e2d0d  vmovaps [rsp+0xB0], xmm11
00007e1ec07e2d16  vmovaps [rsp+0xC0], xmm12
00007e1ec07e2d1f  vmovaps [rsp+0xD0], xmm13
00007e1ec07e2d28  vmovaps [rsp+0xE0], xmm14
00007e1ec07e2d31  sub rsp, 0x30
00007e1ec07e2d35  movaps [rsp], xmm15
00007e1ec07e2d3a  movaps [rsp+0x10], xmm1
00007e1ec07e2d3f  movaps [rsp+0x20], xmm5
00007e1ec07e2d44  lea rdi, [rsp]
00007e1ec07e2d48  mov esi, 0x00
00007e1ec07e2d4d  mov rax, 0x5E00FF778530
00007e1ec07e2d57  call rax
00007e1ec07e2d59  movaps xmm15, [rsp]
00007e1ec07e2d5e  add rsp, 0x30
00007e1ec07e2d62  vmovaps xmm0, [rsp]
00007e1ec07e2d67  vmovaps xmm1, [rsp+0x10]
00007e1ec07e2d6d  vmovaps xmm2, [rsp+0x20]
00007e1ec07e2d73  vmovaps xmm3, [rsp+0x30]
00007e1ec07e2d79  vmovaps xmm4, [rsp+0x40]
00007e1ec07e2d7f  vmovaps xmm5, [rsp+0x50]
00007e1ec07e2d85  vmovaps xmm6, [rsp+0x60]
00007e1ec07e2d8b  vmovaps xmm7, [rsp+0x70]
00007e1ec07e2d91  vmovaps xmm8, [rsp+0x80]
00007e1ec07e2d9a  vmovaps xmm9, [rsp+0x90]
00007e1ec07e2da3  vmovaps xmm10, [rsp+0xA0]
00007e1ec07e2dac  vmovaps xmm11, [rsp+0xB0]
00007e1ec07e2db5  vmovaps xmm12, [rsp+0xC0]
00007e1ec07e2dbe  vmovaps xmm13, [rsp+0xD0]
00007e1ec07e2dc7  vmovaps xmm14, [rsp+0xE0]
00007e1ec07e2dd0  add rsp, 0xF0
00007e1ec07e2dd7  pop r11
00007e1ec07e2dd9  pop r10
00007e1ec07e2ddb  pop r9
00007e1ec07e2ddd  pop r8
00007e1ec07e2ddf  pop rsi
00007e1ec07e2de0  pop rdi
00007e1ec07e2de1  pop rdx
00007e1ec07e2de2  pop rcx
00007e1ec07e2de3  pop rax
00007e1ec07e2de4  add rsp, 0x08
00007e1ec07e2de8  jmp 0x00007E1EC07DF653
00007e1ec07e2ded  call 0x00007E1EC06B52F0
00007e1ec07e2df2  jmp 0x00007E1EC07DF6AE
00007e1ec07e2df7  sub rsp, 0x08
00007e1ec07e2dfb  push rax
00007e1ec07e2dfc  push rcx
00007e1ec07e2dfd  push rdx
00007e1ec07e2dfe  push rdi
00007e1ec07e2dff  push rsi
00007e1ec07e2e00  push r8
00007e1ec07e2e02  push r9
00007e1ec07e2e04  push r10
00007e1ec07e2e06  push r11
00007e1ec07e2e08  sub rsp, 0xF0
00007e1ec07e2e0f  vmovaps [rsp], xmm0
00007e1ec07e2e14  vmovaps [rsp+0x10], xmm1
00007e1ec07e2e1a  vmovaps [rsp+0x20], xmm2
00007e1ec07e2e20  vmovaps [rsp+0x30], xmm3
00007e1ec07e2e26  vmovaps [rsp+0x40], xmm4
00007e1ec07e2e2c  vmovaps [rsp+0x50], xmm5
00007e1ec07e2e32  vmovaps [rsp+0x60], xmm6
00007e1ec07e2e38  vmovaps [rsp+0x70], xmm7
00007e1ec07e2e3e  vmovaps [rsp+0x80], xmm8
00007e1ec07e2e47  vmovaps [rsp+0x90], xmm10
00007e1ec07e2e50  vmovaps [rsp+0xA0], xmm11
00007e1ec07e2e59  vmovaps [rsp+0xB0], xmm12
00007e1ec07e2e62  vmovaps [rsp+0xC0], xmm13
00007e1ec07e2e6b  vmovaps [rsp+0xD0], xmm14
00007e1ec07e2e74  vmovaps [rsp+0xE0], xmm15
00007e1ec07e2e7d  sub rsp, 0x30
00007e1ec07e2e81  movaps [rsp], xmm9
00007e1ec07e2e86  movaps [rsp+0x10], xmm8
00007e1ec07e2e8c  movaps [rsp+0x20], xmm11
00007e1ec07e2e92  lea rdi, [rsp]
00007e1ec07e2e96  mov esi, 0x00
00007e1ec07e2e9b  mov rax, 0x5E00FF778530
00007e1ec07e2ea5  call rax
00007e1ec07e2ea7  movaps xmm9, [rsp]
00007e1ec07e2eac  add rsp, 0x30
00007e1ec07e2eb0  vmovaps xmm0, [rsp]
00007e1ec07e2eb5  vmovaps xmm1, [rsp+0x10]
00007e1ec07e2ebb  vmovaps xmm2, [rsp+0x20]
00007e1ec07e2ec1  vmovaps xmm3, [rsp+0x30]
00007e1ec07e2ec7  vmovaps xmm4, [rsp+0x40]
00007e1ec07e2ecd  vmovaps xmm5, [rsp+0x50]
00007e1ec07e2ed3  vmovaps xmm6, [rsp+0x60]
00007e1ec07e2ed9  vmovaps xmm7, [rsp+0x70]
00007e1ec07e2edf  vmovaps xmm8, [rsp+0x80]
00007e1ec07e2ee8  vmovaps xmm10, [rsp+0x90]
00007e1ec07e2ef1  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e2efa  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e2f03  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e2f0c  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e2f15  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e2f1e  add rsp, 0xF0
00007e1ec07e2f25  pop r11
00007e1ec07e2f27  pop r10
00007e1ec07e2f29  pop r9
00007e1ec07e2f2b  pop r8
00007e1ec07e2f2d  pop rsi
00007e1ec07e2f2e  pop rdi
00007e1ec07e2f2f  pop rdx
00007e1ec07e2f30  pop rcx
00007e1ec07e2f31  pop rax
00007e1ec07e2f32  add rsp, 0x08
00007e1ec07e2f36  jmp 0x00007E1EC07DF6E5
00007e1ec07e2f3b  sub rsp, 0x08
00007e1ec07e2f3f  push rax
00007e1ec07e2f40  push rcx
00007e1ec07e2f41  push rdx
00007e1ec07e2f42  push rdi
00007e1ec07e2f43  push rsi
00007e1ec07e2f44  push r8
00007e1ec07e2f46  push r9
00007e1ec07e2f48  push r10
00007e1ec07e2f4a  push r11
00007e1ec07e2f4c  sub rsp, 0xF0
00007e1ec07e2f53  vmovaps [rsp], xmm0
00007e1ec07e2f58  vmovaps [rsp+0x10], xmm1
00007e1ec07e2f5e  vmovaps [rsp+0x20], xmm2
00007e1ec07e2f64  vmovaps [rsp+0x30], xmm3
00007e1ec07e2f6a  vmovaps [rsp+0x40], xmm4
00007e1ec07e2f70  vmovaps [rsp+0x50], xmm5
00007e1ec07e2f76  vmovaps [rsp+0x60], xmm6
00007e1ec07e2f7c  vmovaps [rsp+0x70], xmm7
00007e1ec07e2f82  vmovaps [rsp+0x80], xmm8
00007e1ec07e2f8b  vmovaps [rsp+0x90], xmm9
00007e1ec07e2f94  vmovaps [rsp+0xA0], xmm10
00007e1ec07e2f9d  vmovaps [rsp+0xB0], xmm12
00007e1ec07e2fa6  vmovaps [rsp+0xC0], xmm13
00007e1ec07e2faf  vmovaps [rsp+0xD0], xmm14
00007e1ec07e2fb8  vmovaps [rsp+0xE0], xmm15
00007e1ec07e2fc1  sub rsp, 0x30
00007e1ec07e2fc5  movaps [rsp], xmm11
00007e1ec07e2fca  movaps [rsp+0x10], xmm10
00007e1ec07e2fd0  movaps [rsp+0x20], xmm6
00007e1ec07e2fd5  lea rdi, [rsp]
00007e1ec07e2fd9  mov esi, 0x00
00007e1ec07e2fde  mov rax, 0x5E00FF778530
00007e1ec07e2fe8  call rax
00007e1ec07e2fea  movaps xmm11, [rsp]
00007e1ec07e2fef  add rsp, 0x30
00007e1ec07e2ff3  vmovaps xmm0, [rsp]
00007e1ec07e2ff8  vmovaps xmm1, [rsp+0x10]
00007e1ec07e2ffe  vmovaps xmm2, [rsp+0x20]
00007e1ec07e3004  vmovaps xmm3, [rsp+0x30]
00007e1ec07e300a  vmovaps xmm4, [rsp+0x40]
00007e1ec07e3010  vmovaps xmm5, [rsp+0x50]
00007e1ec07e3016  vmovaps xmm6, [rsp+0x60]
00007e1ec07e301c  vmovaps xmm7, [rsp+0x70]
00007e1ec07e3022  vmovaps xmm8, [rsp+0x80]
00007e1ec07e302b  vmovaps xmm9, [rsp+0x90]
00007e1ec07e3034  vmovaps xmm10, [rsp+0xA0]
00007e1ec07e303d  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e3046  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e304f  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e3058  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e3061  add rsp, 0xF0
00007e1ec07e3068  pop r11
00007e1ec07e306a  pop r10
00007e1ec07e306c  pop r9
00007e1ec07e306e  pop r8
00007e1ec07e3070  pop rsi
00007e1ec07e3071  pop rdi
00007e1ec07e3072  pop rdx
00007e1ec07e3073  pop rcx
00007e1ec07e3074  pop rax
00007e1ec07e3075  add rsp, 0x08
00007e1ec07e3079  jmp 0x00007E1EC07DF700
00007e1ec07e307e  sub rsp, 0x08
00007e1ec07e3082  push rax
00007e1ec07e3083  push rcx
00007e1ec07e3084  push rdx
00007e1ec07e3085  push rdi
00007e1ec07e3086  push rsi
00007e1ec07e3087  push r8
00007e1ec07e3089  push r9
00007e1ec07e308b  push r10
00007e1ec07e308d  push r11
00007e1ec07e308f  sub rsp, 0xF0
00007e1ec07e3096  vmovaps [rsp], xmm0
00007e1ec07e309b  vmovaps [rsp+0x10], xmm1
00007e1ec07e30a1  vmovaps [rsp+0x20], xmm2
00007e1ec07e30a7  vmovaps [rsp+0x30], xmm3
00007e1ec07e30ad  vmovaps [rsp+0x40], xmm4
00007e1ec07e30b3  vmovaps [rsp+0x50], xmm5
00007e1ec07e30b9  vmovaps [rsp+0x60], xmm6
00007e1ec07e30bf  vmovaps [rsp+0x70], xmm7
00007e1ec07e30c5  vmovaps [rsp+0x80], xmm8
00007e1ec07e30ce  vmovaps [rsp+0x90], xmm9
00007e1ec07e30d7  vmovaps [rsp+0xA0], xmm11
00007e1ec07e30e0  vmovaps [rsp+0xB0], xmm12
00007e1ec07e30e9  vmovaps [rsp+0xC0], xmm13
00007e1ec07e30f2  vmovaps [rsp+0xD0], xmm14
00007e1ec07e30fb  vmovaps [rsp+0xE0], xmm15
00007e1ec07e3104  sub rsp, 0x30
00007e1ec07e3108  movaps [rsp], xmm10
00007e1ec07e310d  movaps [rsp+0x10], xmm14
00007e1ec07e3113  movaps [rsp+0x20], xmm4
00007e1ec07e3118  lea rdi, [rsp]
00007e1ec07e311c  mov esi, 0x00
00007e1ec07e3121  mov rax, 0x5E00FF778530
00007e1ec07e312b  call rax
00007e1ec07e312d  movaps xmm10, [rsp]
00007e1ec07e3132  add rsp, 0x30
00007e1ec07e3136  vmovaps xmm0, [rsp]
00007e1ec07e313b  vmovaps xmm1, [rsp+0x10]
00007e1ec07e3141  vmovaps xmm2, [rsp+0x20]
00007e1ec07e3147  vmovaps xmm3, [rsp+0x30]
00007e1ec07e314d  vmovaps xmm4, [rsp+0x40]
00007e1ec07e3153  vmovaps xmm5, [rsp+0x50]
00007e1ec07e3159  vmovaps xmm6, [rsp+0x60]
00007e1ec07e315f  vmovaps xmm7, [rsp+0x70]
00007e1ec07e3165  vmovaps xmm8, [rsp+0x80]
00007e1ec07e316e  vmovaps xmm9, [rsp+0x90]
00007e1ec07e3177  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e3180  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e3189  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e3192  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e319b  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e31a4  add rsp, 0xF0
00007e1ec07e31ab  pop r11
00007e1ec07e31ad  pop r10
00007e1ec07e31af  pop r9
00007e1ec07e31b1  pop r8
00007e1ec07e31b3  pop rsi
00007e1ec07e31b4  pop rdi
00007e1ec07e31b5  pop rdx
00007e1ec07e31b6  pop rcx
00007e1ec07e31b7  pop rax
00007e1ec07e31b8  add rsp, 0x08
00007e1ec07e31bc  jmp 0x00007E1EC07DF71B
00007e1ec07e31c1  sub rsp, 0x08
00007e1ec07e31c5  push rax
00007e1ec07e31c6  push rcx
00007e1ec07e31c7  push rdx
00007e1ec07e31c8  push rdi
00007e1ec07e31c9  push rsi
00007e1ec07e31ca  push r8
00007e1ec07e31cc  push r9
00007e1ec07e31ce  push r10
00007e1ec07e31d0  push r11
00007e1ec07e31d2  sub rsp, 0xF0
00007e1ec07e31d9  vmovaps [rsp], xmm0
00007e1ec07e31de  vmovaps [rsp+0x10], xmm1
00007e1ec07e31e4  vmovaps [rsp+0x20], xmm2
00007e1ec07e31ea  vmovaps [rsp+0x30], xmm3
00007e1ec07e31f0  vmovaps [rsp+0x40], xmm4
00007e1ec07e31f6  vmovaps [rsp+0x50], xmm5
00007e1ec07e31fc  vmovaps [rsp+0x60], xmm6
00007e1ec07e3202  vmovaps [rsp+0x70], xmm7
00007e1ec07e3208  vmovaps [rsp+0x80], xmm9
00007e1ec07e3211  vmovaps [rsp+0x90], xmm10
00007e1ec07e321a  vmovaps [rsp+0xA0], xmm11
00007e1ec07e3223  vmovaps [rsp+0xB0], xmm12
00007e1ec07e322c  vmovaps [rsp+0xC0], xmm13
00007e1ec07e3235  vmovaps [rsp+0xD0], xmm14
00007e1ec07e323e  vmovaps [rsp+0xE0], xmm15
00007e1ec07e3247  sub rsp, 0x30
00007e1ec07e324b  movaps [rsp], xmm8
00007e1ec07e3250  movaps [rsp+0x10], xmm1
00007e1ec07e3255  movaps [rsp+0x20], xmm14
00007e1ec07e325b  lea rdi, [rsp]
00007e1ec07e325f  mov esi, 0x00
00007e1ec07e3264  mov rax, 0x5E00FF778530
00007e1ec07e326e  call rax
00007e1ec07e3270  movaps xmm8, [rsp]
00007e1ec07e3275  add rsp, 0x30
00007e1ec07e3279  vmovaps xmm0, [rsp]
00007e1ec07e327e  vmovaps xmm1, [rsp+0x10]
00007e1ec07e3284  vmovaps xmm2, [rsp+0x20]
00007e1ec07e328a  vmovaps xmm3, [rsp+0x30]
00007e1ec07e3290  vmovaps xmm4, [rsp+0x40]
00007e1ec07e3296  vmovaps xmm5, [rsp+0x50]
00007e1ec07e329c  vmovaps xmm6, [rsp+0x60]
00007e1ec07e32a2  vmovaps xmm7, [rsp+0x70]
00007e1ec07e32a8  vmovaps xmm9, [rsp+0x80]
00007e1ec07e32b1  vmovaps xmm10, [rsp+0x90]
00007e1ec07e32ba  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e32c3  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e32cc  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e32d5  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e32de  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e32e7  add rsp, 0xF0
00007e1ec07e32ee  pop r11
00007e1ec07e32f0  pop r10
00007e1ec07e32f2  pop r9
00007e1ec07e32f4  pop r8
00007e1ec07e32f6  pop rsi
00007e1ec07e32f7  pop rdi
00007e1ec07e32f8  pop rdx
00007e1ec07e32f9  pop rcx
00007e1ec07e32fa  pop rax
00007e1ec07e32fb  add rsp, 0x08
00007e1ec07e32ff  jmp 0x00007E1EC07DF741
00007e1ec07e3304  sub rsp, 0x08
00007e1ec07e3308  push rax
00007e1ec07e3309  push rcx
00007e1ec07e330a  push rdx
00007e1ec07e330b  push rdi
00007e1ec07e330c  push rsi
00007e1ec07e330d  push r8
00007e1ec07e330f  push r9
00007e1ec07e3311  push r10
00007e1ec07e3313  push r11
00007e1ec07e3315  sub rsp, 0xF0
00007e1ec07e331c  vmovaps [rsp], xmm0
00007e1ec07e3321  vmovaps [rsp+0x10], xmm1
00007e1ec07e3327  vmovaps [rsp+0x20], xmm2
00007e1ec07e332d  vmovaps [rsp+0x30], xmm3
00007e1ec07e3333  vmovaps [rsp+0x40], xmm4
00007e1ec07e3339  vmovaps [rsp+0x50], xmm5
00007e1ec07e333f  vmovaps [rsp+0x60], xmm7
00007e1ec07e3345  vmovaps [rsp+0x70], xmm8
00007e1ec07e334b  vmovaps [rsp+0x80], xmm9
00007e1ec07e3354  vmovaps [rsp+0x90], xmm10
00007e1ec07e335d  vmovaps [rsp+0xA0], xmm11
00007e1ec07e3366  vmovaps [rsp+0xB0], xmm12
00007e1ec07e336f  vmovaps [rsp+0xC0], xmm13
00007e1ec07e3378  vmovaps [rsp+0xD0], xmm14
00007e1ec07e3381  vmovaps [rsp+0xE0], xmm15
00007e1ec07e338a  sub rsp, 0x30
00007e1ec07e338e  movaps [rsp], xmm6
00007e1ec07e3392  movaps [rsp+0x10], xmm1
00007e1ec07e3397  movaps [rsp+0x20], xmm14
00007e1ec07e339d  lea rdi, [rsp]
00007e1ec07e33a1  mov esi, 0x00
00007e1ec07e33a6  mov rax, 0x5E00FF778530
00007e1ec07e33b0  call rax
00007e1ec07e33b2  movaps xmm6, [rsp]
00007e1ec07e33b6  add rsp, 0x30
00007e1ec07e33ba  vmovaps xmm0, [rsp]
00007e1ec07e33bf  vmovaps xmm1, [rsp+0x10]
00007e1ec07e33c5  vmovaps xmm2, [rsp+0x20]
00007e1ec07e33cb  vmovaps xmm3, [rsp+0x30]
00007e1ec07e33d1  vmovaps xmm4, [rsp+0x40]
00007e1ec07e33d7  vmovaps xmm5, [rsp+0x50]
00007e1ec07e33dd  vmovaps xmm7, [rsp+0x60]
00007e1ec07e33e3  vmovaps xmm8, [rsp+0x70]
00007e1ec07e33e9  vmovaps xmm9, [rsp+0x80]
00007e1ec07e33f2  vmovaps xmm10, [rsp+0x90]
00007e1ec07e33fb  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e3404  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e340d  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e3416  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e341f  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e3428  add rsp, 0xF0
00007e1ec07e342f  pop r11
00007e1ec07e3431  pop r10
00007e1ec07e3433  pop r9
00007e1ec07e3435  pop r8
00007e1ec07e3437  pop rsi
00007e1ec07e3438  pop rdi
00007e1ec07e3439  pop rdx
00007e1ec07e343a  pop rcx
00007e1ec07e343b  pop rax
00007e1ec07e343c  add rsp, 0x08
00007e1ec07e3440  jmp 0x00007E1EC07DF76D
00007e1ec07e3445  sub rsp, 0x08
00007e1ec07e3449  push rax
00007e1ec07e344a  push rcx
00007e1ec07e344b  push rdx
00007e1ec07e344c  push rdi
00007e1ec07e344d  push rsi
00007e1ec07e344e  push r8
00007e1ec07e3450  push r9
00007e1ec07e3452  push r10
00007e1ec07e3454  push r11
00007e1ec07e3456  sub rsp, 0xF0
00007e1ec07e345d  vmovaps [rsp], xmm0
00007e1ec07e3462  vmovaps [rsp+0x10], xmm1
00007e1ec07e3468  vmovaps [rsp+0x20], xmm2
00007e1ec07e346e  vmovaps [rsp+0x30], xmm3
00007e1ec07e3474  vmovaps [rsp+0x40], xmm4
00007e1ec07e347a  vmovaps [rsp+0x50], xmm5
00007e1ec07e3480  vmovaps [rsp+0x60], xmm6
00007e1ec07e3486  vmovaps [rsp+0x70], xmm7
00007e1ec07e348c  vmovaps [rsp+0x80], xmm8
00007e1ec07e3495  vmovaps [rsp+0x90], xmm9
00007e1ec07e349e  vmovaps [rsp+0xA0], xmm10
00007e1ec07e34a7  vmovaps [rsp+0xB0], xmm11
00007e1ec07e34b0  vmovaps [rsp+0xC0], xmm12
00007e1ec07e34b9  vmovaps [rsp+0xD0], xmm13
00007e1ec07e34c2  vmovaps [rsp+0xE0], xmm15
00007e1ec07e34cb  sub rsp, 0x30
00007e1ec07e34cf  movaps [rsp], xmm14
00007e1ec07e34d4  movaps [rsp+0x10], xmm12
00007e1ec07e34da  movaps [rsp+0x20], xmm1
00007e1ec07e34df  lea rdi, [rsp]
00007e1ec07e34e3  mov esi, 0x00
00007e1ec07e34e8  mov rax, 0x5E00FF778530
00007e1ec07e34f2  call rax
00007e1ec07e34f4  movaps xmm14, [rsp]
00007e1ec07e34f9  add rsp, 0x30
00007e1ec07e34fd  vmovaps xmm0, [rsp]
00007e1ec07e3502  vmovaps xmm1, [rsp+0x10]
00007e1ec07e3508  vmovaps xmm2, [rsp+0x20]
00007e1ec07e350e  vmovaps xmm3, [rsp+0x30]
00007e1ec07e3514  vmovaps xmm4, [rsp+0x40]
00007e1ec07e351a  vmovaps xmm5, [rsp+0x50]
00007e1ec07e3520  vmovaps xmm6, [rsp+0x60]
00007e1ec07e3526  vmovaps xmm7, [rsp+0x70]
00007e1ec07e352c  vmovaps xmm8, [rsp+0x80]
00007e1ec07e3535  vmovaps xmm9, [rsp+0x90]
00007e1ec07e353e  vmovaps xmm10, [rsp+0xA0]
00007e1ec07e3547  vmovaps xmm11, [rsp+0xB0]
00007e1ec07e3550  vmovaps xmm12, [rsp+0xC0]
00007e1ec07e3559  vmovaps xmm13, [rsp+0xD0]
00007e1ec07e3562  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e356b  add rsp, 0xF0
00007e1ec07e3572  pop r11
00007e1ec07e3574  pop r10
00007e1ec07e3576  pop r9
00007e1ec07e3578  pop r8
00007e1ec07e357a  pop rsi
00007e1ec07e357b  pop rdi
00007e1ec07e357c  pop rdx
00007e1ec07e357d  pop rcx
00007e1ec07e357e  pop rax
00007e1ec07e357f  add rsp, 0x08
00007e1ec07e3583  jmp 0x00007E1EC07DF793
00007e1ec07e3588  sub rsp, 0x08
00007e1ec07e358c  push rax
00007e1ec07e358d  push rcx
00007e1ec07e358e  push rdx
00007e1ec07e358f  push rdi
00007e1ec07e3590  push rsi
00007e1ec07e3591  push r8
00007e1ec07e3593  push r9
00007e1ec07e3595  push r10
00007e1ec07e3597  push r11
00007e1ec07e3599  sub rsp, 0xF0
00007e1ec07e35a0  vmovaps [rsp], xmm0
00007e1ec07e35a5  vmovaps [rsp+0x10], xmm2
00007e1ec07e35ab  vmovaps [rsp+0x20], xmm3
00007e1ec07e35b1  vmovaps [rsp+0x30], xmm4
00007e1ec07e35b7  vmovaps [rsp+0x40], xmm5
00007e1ec07e35bd  vmovaps [rsp+0x50], xmm6
00007e1ec07e35c3  vmovaps [rsp+0x60], xmm7
00007e1ec07e35c9  vmovaps [rsp+0x70], xmm8
00007e1ec07e35cf  vmovaps [rsp+0x80], xmm9
00007e1ec07e35d8  vmovaps [rsp+0x90], xmm10
00007e1ec07e35e1  vmovaps [rsp+0xA0], xmm11
00007e1ec07e35ea  vmovaps [rsp+0xB0], xmm12
00007e1ec07e35f3  vmovaps [rsp+0xC0], xmm13
00007e1ec07e35fc  vmovaps [rsp+0xD0], xmm14
00007e1ec07e3605  vmovaps [rsp+0xE0], xmm15
00007e1ec07e360e  sub rsp, 0x30
00007e1ec07e3612  movaps [rsp], xmm1
00007e1ec07e3616  movaps [rsp+0x10], xmm13
00007e1ec07e361c  movaps [rsp+0x20], xmm9
00007e1ec07e3622  lea rdi, [rsp]
00007e1ec07e3626  mov esi, 0x00
00007e1ec07e362b  mov rax, 0x5E00FF778530
00007e1ec07e3635  call rax
00007e1ec07e3637  movaps xmm1, [rsp]
00007e1ec07e363b  add rsp, 0x30
00007e1ec07e363f  vmovaps xmm0, [rsp]
00007e1ec07e3644  vmovaps xmm2, [rsp+0x10]
00007e1ec07e364a  vmovaps xmm3, [rsp+0x20]
00007e1ec07e3650  vmovaps xmm4, [rsp+0x30]
00007e1ec07e3656  vmovaps xmm5, [rsp+0x40]
00007e1ec07e365c  vmovaps xmm6, [rsp+0x50]
00007e1ec07e3662  vmovaps xmm7, [rsp+0x60]
00007e1ec07e3668  vmovaps xmm8, [rsp+0x70]
00007e1ec07e366e  vmovaps xmm9, [rsp+0x80]
00007e1ec07e3677  vmovaps xmm10, [rsp+0x90]
00007e1ec07e3680  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e3689  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e3692  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e369b  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e36a4  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e36ad  add rsp, 0xF0
00007e1ec07e36b4  pop r11
00007e1ec07e36b6  pop r10
00007e1ec07e36b8  pop r9
00007e1ec07e36ba  pop r8
00007e1ec07e36bc  pop rsi
00007e1ec07e36bd  pop rdi
00007e1ec07e36be  pop rdx
00007e1ec07e36bf  pop rcx
00007e1ec07e36c0  pop rax
00007e1ec07e36c1  add rsp, 0x08
00007e1ec07e36c5  jmp 0x00007E1EC07DF7AD
00007e1ec07e36ca  sub rsp, 0x08
00007e1ec07e36ce  push rax
00007e1ec07e36cf  push rcx
00007e1ec07e36d0  push rdx
00007e1ec07e36d1  push rdi
00007e1ec07e36d2  push rsi
00007e1ec07e36d3  push r8
00007e1ec07e36d5  push r9
00007e1ec07e36d7  push r10
00007e1ec07e36d9  push r11
00007e1ec07e36db  sub rsp, 0xF0
00007e1ec07e36e2  vmovaps [rsp], xmm0
00007e1ec07e36e7  vmovaps [rsp+0x10], xmm1
00007e1ec07e36ed  vmovaps [rsp+0x20], xmm2
00007e1ec07e36f3  vmovaps [rsp+0x30], xmm3
00007e1ec07e36f9  vmovaps [rsp+0x40], xmm4
00007e1ec07e36ff  vmovaps [rsp+0x50], xmm5
00007e1ec07e3705  vmovaps [rsp+0x60], xmm6
00007e1ec07e370b  vmovaps [rsp+0x70], xmm7
00007e1ec07e3711  vmovaps [rsp+0x80], xmm8
00007e1ec07e371a  vmovaps [rsp+0x90], xmm9
00007e1ec07e3723  vmovaps [rsp+0xA0], xmm10
00007e1ec07e372c  vmovaps [rsp+0xB0], xmm11
00007e1ec07e3735  vmovaps [rsp+0xC0], xmm13
00007e1ec07e373e  vmovaps [rsp+0xD0], xmm14
00007e1ec07e3747  vmovaps [rsp+0xE0], xmm15
00007e1ec07e3750  sub rsp, 0x30
00007e1ec07e3754  movaps [rsp], xmm12
00007e1ec07e3759  movaps [rsp+0x10], xmm7
00007e1ec07e375e  movaps [rsp+0x20], xmm13
00007e1ec07e3764  lea rdi, [rsp]
00007e1ec07e3768  mov esi, 0x00
00007e1ec07e376d  mov rax, 0x5E00FF778530
00007e1ec07e3777  call rax
00007e1ec07e3779  movaps xmm12, [rsp]
00007e1ec07e377e  add rsp, 0x30
00007e1ec07e3782  vmovaps xmm0, [rsp]
00007e1ec07e3787  vmovaps xmm1, [rsp+0x10]
00007e1ec07e378d  vmovaps xmm2, [rsp+0x20]
00007e1ec07e3793  vmovaps xmm3, [rsp+0x30]
00007e1ec07e3799  vmovaps xmm4, [rsp+0x40]
00007e1ec07e379f  vmovaps xmm5, [rsp+0x50]
00007e1ec07e37a5  vmovaps xmm6, [rsp+0x60]
00007e1ec07e37ab  vmovaps xmm7, [rsp+0x70]
00007e1ec07e37b1  vmovaps xmm8, [rsp+0x80]
00007e1ec07e37ba  vmovaps xmm9, [rsp+0x90]
00007e1ec07e37c3  vmovaps xmm10, [rsp+0xA0]
00007e1ec07e37cc  vmovaps xmm11, [rsp+0xB0]
00007e1ec07e37d5  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e37de  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e37e7  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e37f0  add rsp, 0xF0
00007e1ec07e37f7  pop r11
00007e1ec07e37f9  pop r10
00007e1ec07e37fb  pop r9
00007e1ec07e37fd  pop r8
00007e1ec07e37ff  pop rsi
00007e1ec07e3800  pop rdi
00007e1ec07e3801  pop rdx
00007e1ec07e3802  pop rcx
00007e1ec07e3803  pop rax
00007e1ec07e3804  add rsp, 0x08
00007e1ec07e3808  jmp 0x00007E1EC07DF7D4
00007e1ec07e380d  sub rsp, 0x08
00007e1ec07e3811  push rax
00007e1ec07e3812  push rcx
00007e1ec07e3813  push rdx
00007e1ec07e3814  push rdi
00007e1ec07e3815  push rsi
00007e1ec07e3816  push r8
00007e1ec07e3818  push r9
00007e1ec07e381a  push r10
00007e1ec07e381c  push r11
00007e1ec07e381e  sub rsp, 0xF0
00007e1ec07e3825  vmovaps [rsp], xmm0
00007e1ec07e382a  vmovaps [rsp+0x10], xmm1
00007e1ec07e3830  vmovaps [rsp+0x20], xmm2
00007e1ec07e3836  vmovaps [rsp+0x30], xmm3
00007e1ec07e383c  vmovaps [rsp+0x40], xmm4
00007e1ec07e3842  vmovaps [rsp+0x50], xmm5
00007e1ec07e3848  vmovaps [rsp+0x60], xmm6
00007e1ec07e384e  vmovaps [rsp+0x70], xmm7
00007e1ec07e3854  vmovaps [rsp+0x80], xmm8
00007e1ec07e385d  vmovaps [rsp+0x90], xmm9
00007e1ec07e3866  vmovaps [rsp+0xA0], xmm10
00007e1ec07e386f  vmovaps [rsp+0xB0], xmm11
00007e1ec07e3878  vmovaps [rsp+0xC0], xmm12
00007e1ec07e3881  vmovaps [rsp+0xD0], xmm14
00007e1ec07e388a  vmovaps [rsp+0xE0], xmm15
00007e1ec07e3893  sub rsp, 0x30
00007e1ec07e3897  movaps [rsp], xmm13
00007e1ec07e389c  movaps [rsp+0x10], xmm15
00007e1ec07e38a2  movaps [rsp+0x20], xmm8
00007e1ec07e38a8  lea rdi, [rsp]
00007e1ec07e38ac  mov esi, 0x00
00007e1ec07e38b1  mov rax, 0x5E00FF778530
00007e1ec07e38bb  call rax
00007e1ec07e38bd  movaps xmm13, [rsp]
00007e1ec07e38c2  add rsp, 0x30
00007e1ec07e38c6  vmovaps xmm0, [rsp]
00007e1ec07e38cb  vmovaps xmm1, [rsp+0x10]
00007e1ec07e38d1  vmovaps xmm2, [rsp+0x20]
00007e1ec07e38d7  vmovaps xmm3, [rsp+0x30]
00007e1ec07e38dd  vmovaps xmm4, [rsp+0x40]
00007e1ec07e38e3  vmovaps xmm5, [rsp+0x50]
00007e1ec07e38e9  vmovaps xmm6, [rsp+0x60]
00007e1ec07e38ef  vmovaps xmm7, [rsp+0x70]
00007e1ec07e38f5  vmovaps xmm8, [rsp+0x80]
00007e1ec07e38fe  vmovaps xmm9, [rsp+0x90]
00007e1ec07e3907  vmovaps xmm10, [rsp+0xA0]
00007e1ec07e3910  vmovaps xmm11, [rsp+0xB0]
00007e1ec07e3919  vmovaps xmm12, [rsp+0xC0]
00007e1ec07e3922  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e392b  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e3934  add rsp, 0xF0
00007e1ec07e393b  pop r11
00007e1ec07e393d  pop r10
00007e1ec07e393f  pop r9
00007e1ec07e3941  pop r8
00007e1ec07e3943  pop rsi
00007e1ec07e3944  pop rdi
00007e1ec07e3945  pop rdx
00007e1ec07e3946  pop rcx
00007e1ec07e3947  pop rax
00007e1ec07e3948  add rsp, 0x08
00007e1ec07e394c  jmp 0x00007E1EC07DF7EF
00007e1ec07e3951  sub rsp, 0x08
00007e1ec07e3955  push rax
00007e1ec07e3956  push rcx
00007e1ec07e3957  push rdx
00007e1ec07e3958  push rdi
00007e1ec07e3959  push rsi
00007e1ec07e395a  push r8
00007e1ec07e395c  push r9
00007e1ec07e395e  push r10
00007e1ec07e3960  push r11
00007e1ec07e3962  sub rsp, 0xF0
00007e1ec07e3969  vmovaps [rsp], xmm0
00007e1ec07e396e  vmovaps [rsp+0x10], xmm1
00007e1ec07e3974  vmovaps [rsp+0x20], xmm2
00007e1ec07e397a  vmovaps [rsp+0x30], xmm3
00007e1ec07e3980  vmovaps [rsp+0x40], xmm4
00007e1ec07e3986  vmovaps [rsp+0x50], xmm5
00007e1ec07e398c  vmovaps [rsp+0x60], xmm6
00007e1ec07e3992  vmovaps [rsp+0x70], xmm7
00007e1ec07e3998  vmovaps [rsp+0x80], xmm9
00007e1ec07e39a1  vmovaps [rsp+0x90], xmm10
00007e1ec07e39aa  vmovaps [rsp+0xA0], xmm11
00007e1ec07e39b3  vmovaps [rsp+0xB0], xmm12
00007e1ec07e39bc  vmovaps [rsp+0xC0], xmm13
00007e1ec07e39c5  vmovaps [rsp+0xD0], xmm14
00007e1ec07e39ce  vmovaps [rsp+0xE0], xmm15
00007e1ec07e39d7  sub rsp, 0x30
00007e1ec07e39db  movaps [rsp], xmm8
00007e1ec07e39e0  movaps [rsp+0x10], xmm15
00007e1ec07e39e6  movaps [rsp+0x20], xmm9
00007e1ec07e39ec  lea rdi, [rsp]
00007e1ec07e39f0  mov esi, 0x00
00007e1ec07e39f5  mov rax, 0x5E00FF778530
00007e1ec07e39ff  call rax
00007e1ec07e3a01  movaps xmm8, [rsp]
00007e1ec07e3a06  add rsp, 0x30
00007e1ec07e3a0a  vmovaps xmm0, [rsp]
00007e1ec07e3a0f  vmovaps xmm1, [rsp+0x10]
00007e1ec07e3a15  vmovaps xmm2, [rsp+0x20]
00007e1ec07e3a1b  vmovaps xmm3, [rsp+0x30]
00007e1ec07e3a21  vmovaps xmm4, [rsp+0x40]
00007e1ec07e3a27  vmovaps xmm5, [rsp+0x50]
00007e1ec07e3a2d  vmovaps xmm6, [rsp+0x60]
00007e1ec07e3a33  vmovaps xmm7, [rsp+0x70]
00007e1ec07e3a39  vmovaps xmm9, [rsp+0x80]
00007e1ec07e3a42  vmovaps xmm10, [rsp+0x90]
00007e1ec07e3a4b  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e3a54  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e3a5d  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e3a66  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e3a6f  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e3a78  add rsp, 0xF0
00007e1ec07e3a7f  pop r11
00007e1ec07e3a81  pop r10
00007e1ec07e3a83  pop r9
00007e1ec07e3a85  pop r8
00007e1ec07e3a87  pop rsi
00007e1ec07e3a88  pop rdi
00007e1ec07e3a89  pop rdx
00007e1ec07e3a8a  pop rcx
00007e1ec07e3a8b  pop rax
00007e1ec07e3a8c  add rsp, 0x08
00007e1ec07e3a90  jmp 0x00007E1EC07DF81D
00007e1ec07e3a95  sub rsp, 0x08
00007e1ec07e3a99  push rax
00007e1ec07e3a9a  push rcx
00007e1ec07e3a9b  push rdx
00007e1ec07e3a9c  push rdi
00007e1ec07e3a9d  push rsi
00007e1ec07e3a9e  push r8
00007e1ec07e3aa0  push r9
00007e1ec07e3aa2  push r10
00007e1ec07e3aa4  push r11
00007e1ec07e3aa6  sub rsp, 0xF0
00007e1ec07e3aad  vmovaps [rsp], xmm0
00007e1ec07e3ab2  vmovaps [rsp+0x10], xmm1
00007e1ec07e3ab8  vmovaps [rsp+0x20], xmm2
00007e1ec07e3abe  vmovaps [rsp+0x30], xmm3
00007e1ec07e3ac4  vmovaps [rsp+0x40], xmm4
00007e1ec07e3aca  vmovaps [rsp+0x50], xmm5
00007e1ec07e3ad0  vmovaps [rsp+0x60], xmm6
00007e1ec07e3ad6  vmovaps [rsp+0x70], xmm7
00007e1ec07e3adc  vmovaps [rsp+0x80], xmm8
00007e1ec07e3ae5  vmovaps [rsp+0x90], xmm9
00007e1ec07e3aee  vmovaps [rsp+0xA0], xmm10
00007e1ec07e3af7  vmovaps [rsp+0xB0], xmm11
00007e1ec07e3b00  vmovaps [rsp+0xC0], xmm12
00007e1ec07e3b09  vmovaps [rsp+0xD0], xmm13
00007e1ec07e3b12  vmovaps [rsp+0xE0], xmm14
00007e1ec07e3b1b  sub rsp, 0x30
00007e1ec07e3b1f  movaps [rsp], xmm15
00007e1ec07e3b24  movaps [rsp+0x10], xmm11
00007e1ec07e3b2a  movaps [rsp+0x20], xmm6
00007e1ec07e3b2f  lea rdi, [rsp]
00007e1ec07e3b33  mov esi, 0x00
00007e1ec07e3b38  mov rax, 0x5E00FF778530
00007e1ec07e3b42  call rax
00007e1ec07e3b44  movaps xmm15, [rsp]
00007e1ec07e3b49  add rsp, 0x30
00007e1ec07e3b4d  vmovaps xmm0, [rsp]
00007e1ec07e3b52  vmovaps xmm1, [rsp+0x10]
00007e1ec07e3b58  vmovaps xmm2, [rsp+0x20]
00007e1ec07e3b5e  vmovaps xmm3, [rsp+0x30]
00007e1ec07e3b64  vmovaps xmm4, [rsp+0x40]
00007e1ec07e3b6a  vmovaps xmm5, [rsp+0x50]
00007e1ec07e3b70  vmovaps xmm6, [rsp+0x60]
00007e1ec07e3b76  vmovaps xmm7, [rsp+0x70]
00007e1ec07e3b7c  vmovaps xmm8, [rsp+0x80]
00007e1ec07e3b85  vmovaps xmm9, [rsp+0x90]
00007e1ec07e3b8e  vmovaps xmm10, [rsp+0xA0]
00007e1ec07e3b97  vmovaps xmm11, [rsp+0xB0]
00007e1ec07e3ba0  vmovaps xmm12, [rsp+0xC0]
00007e1ec07e3ba9  vmovaps xmm13, [rsp+0xD0]
00007e1ec07e3bb2  vmovaps xmm14, [rsp+0xE0]
00007e1ec07e3bbb  add rsp, 0xF0
00007e1ec07e3bc2  pop r11
00007e1ec07e3bc4  pop r10
00007e1ec07e3bc6  pop r9
00007e1ec07e3bc8  pop r8
00007e1ec07e3bca  pop rsi
00007e1ec07e3bcb  pop rdi
00007e1ec07e3bcc  pop rdx
00007e1ec07e3bcd  pop rcx
00007e1ec07e3bce  pop rax
00007e1ec07e3bcf  add rsp, 0x08
00007e1ec07e3bd3  jmp 0x00007E1EC07DF838
00007e1ec07e3bd8  sub rsp, 0x08
00007e1ec07e3bdc  push rax
00007e1ec07e3bdd  push rcx
00007e1ec07e3bde  push rdx
00007e1ec07e3bdf  push rdi
00007e1ec07e3be0  push rsi
00007e1ec07e3be1  push r8
00007e1ec07e3be3  push r9
00007e1ec07e3be5  push r10
00007e1ec07e3be7  push r11
00007e1ec07e3be9  sub rsp, 0xF0
00007e1ec07e3bf0  vmovaps [rsp], xmm0
00007e1ec07e3bf5  vmovaps [rsp+0x10], xmm1
00007e1ec07e3bfb  vmovaps [rsp+0x20], xmm2
00007e1ec07e3c01  vmovaps [rsp+0x30], xmm3
00007e1ec07e3c07  vmovaps [rsp+0x40], xmm4
00007e1ec07e3c0d  vmovaps [rsp+0x50], xmm5
00007e1ec07e3c13  vmovaps [rsp+0x60], xmm6
00007e1ec07e3c19  vmovaps [rsp+0x70], xmm8
00007e1ec07e3c1f  vmovaps [rsp+0x80], xmm9
00007e1ec07e3c28  vmovaps [rsp+0x90], xmm10
00007e1ec07e3c31  vmovaps [rsp+0xA0], xmm11
00007e1ec07e3c3a  vmovaps [rsp+0xB0], xmm12
00007e1ec07e3c43  vmovaps [rsp+0xC0], xmm13
00007e1ec07e3c4c  vmovaps [rsp+0xD0], xmm14
00007e1ec07e3c55  vmovaps [rsp+0xE0], xmm15
00007e1ec07e3c5e  sub rsp, 0x30
00007e1ec07e3c62  movaps [rsp], xmm7
00007e1ec07e3c66  movaps [rsp+0x10], xmm11
00007e1ec07e3c6c  movaps [rsp+0x20], xmm9
00007e1ec07e3c72  lea rdi, [rsp]
00007e1ec07e3c76  mov esi, 0x00
00007e1ec07e3c7b  mov rax, 0x5E00FF778530
00007e1ec07e3c85  call rax
00007e1ec07e3c87  movaps xmm7, [rsp]
00007e1ec07e3c8b  add rsp, 0x30
00007e1ec07e3c8f  vmovaps xmm0, [rsp]
00007e1ec07e3c94  vmovaps xmm1, [rsp+0x10]
00007e1ec07e3c9a  vmovaps xmm2, [rsp+0x20]
00007e1ec07e3ca0  vmovaps xmm3, [rsp+0x30]
00007e1ec07e3ca6  vmovaps xmm4, [rsp+0x40]
00007e1ec07e3cac  vmovaps xmm5, [rsp+0x50]
00007e1ec07e3cb2  vmovaps xmm6, [rsp+0x60]
00007e1ec07e3cb8  vmovaps xmm8, [rsp+0x70]
00007e1ec07e3cbe  vmovaps xmm9, [rsp+0x80]
00007e1ec07e3cc7  vmovaps xmm10, [rsp+0x90]
00007e1ec07e3cd0  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e3cd9  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e3ce2  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e3ceb  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e3cf4  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e3cfd  add rsp, 0xF0
00007e1ec07e3d04  pop r11
00007e1ec07e3d06  pop r10
00007e1ec07e3d08  pop r9
00007e1ec07e3d0a  pop r8
00007e1ec07e3d0c  pop rsi
00007e1ec07e3d0d  pop rdi
00007e1ec07e3d0e  pop rdx
00007e1ec07e3d0f  pop rcx
00007e1ec07e3d10  pop rax
00007e1ec07e3d11  add rsp, 0x08
00007e1ec07e3d15  jmp 0x00007E1EC07DF865
00007e1ec07e3d1a  sub rsp, 0x08
00007e1ec07e3d1e  push rax
00007e1ec07e3d1f  push rcx
00007e1ec07e3d20  push rdx
00007e1ec07e3d21  push rdi
00007e1ec07e3d22  push rsi
00007e1ec07e3d23  push r8
00007e1ec07e3d25  push r9
00007e1ec07e3d27  push r10
00007e1ec07e3d29  push r11
00007e1ec07e3d2b  sub rsp, 0xF0
00007e1ec07e3d32  vmovaps [rsp], xmm0
00007e1ec07e3d37  vmovaps [rsp+0x10], xmm1
00007e1ec07e3d3d  vmovaps [rsp+0x20], xmm2
00007e1ec07e3d43  vmovaps [rsp+0x30], xmm3
00007e1ec07e3d49  vmovaps [rsp+0x40], xmm4
00007e1ec07e3d4f  vmovaps [rsp+0x50], xmm5
00007e1ec07e3d55  vmovaps [rsp+0x60], xmm6
00007e1ec07e3d5b  vmovaps [rsp+0x70], xmm7
00007e1ec07e3d61  vmovaps [rsp+0x80], xmm8
00007e1ec07e3d6a  vmovaps [rsp+0x90], xmm9
00007e1ec07e3d73  vmovaps [rsp+0xA0], xmm10
00007e1ec07e3d7c  vmovaps [rsp+0xB0], xmm12
00007e1ec07e3d85  vmovaps [rsp+0xC0], xmm13
00007e1ec07e3d8e  vmovaps [rsp+0xD0], xmm14
00007e1ec07e3d97  vmovaps [rsp+0xE0], xmm15
00007e1ec07e3da0  sub rsp, 0x30
00007e1ec07e3da4  movaps [rsp], xmm11
00007e1ec07e3da9  movaps [rsp+0x10], xmm10
00007e1ec07e3daf  movaps [rsp+0x20], xmm14
00007e1ec07e3db5  lea rdi, [rsp]
00007e1ec07e3db9  mov esi, 0x00
00007e1ec07e3dbe  mov rax, 0x5E00FF778530
00007e1ec07e3dc8  call rax
00007e1ec07e3dca  movaps xmm11, [rsp]
00007e1ec07e3dcf  add rsp, 0x30
00007e1ec07e3dd3  vmovaps xmm0, [rsp]
00007e1ec07e3dd8  vmovaps xmm1, [rsp+0x10]
00007e1ec07e3dde  vmovaps xmm2, [rsp+0x20]
00007e1ec07e3de4  vmovaps xmm3, [rsp+0x30]
00007e1ec07e3dea  vmovaps xmm4, [rsp+0x40]
00007e1ec07e3df0  vmovaps xmm5, [rsp+0x50]
00007e1ec07e3df6  vmovaps xmm6, [rsp+0x60]
00007e1ec07e3dfc  vmovaps xmm7, [rsp+0x70]
00007e1ec07e3e02  vmovaps xmm8, [rsp+0x80]
00007e1ec07e3e0b  vmovaps xmm9, [rsp+0x90]
00007e1ec07e3e14  vmovaps xmm10, [rsp+0xA0]
00007e1ec07e3e1d  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e3e26  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e3e2f  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e3e38  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e3e41  add rsp, 0xF0
00007e1ec07e3e48  pop r11
00007e1ec07e3e4a  pop r10
00007e1ec07e3e4c  pop r9
00007e1ec07e3e4e  pop r8
00007e1ec07e3e50  pop rsi
00007e1ec07e3e51  pop rdi
00007e1ec07e3e52  pop rdx
00007e1ec07e3e53  pop rcx
00007e1ec07e3e54  pop rax
00007e1ec07e3e55  add rsp, 0x08
00007e1ec07e3e59  jmp 0x00007E1EC07DF880
00007e1ec07e3e5e  call 0x00007E1EC06C33A0
00007e1ec07e3e63  jmp 0x00007E1EC07DF88A
00007e1ec07e3e68  sub rsp, 0x08
00007e1ec07e3e6c  push rax
00007e1ec07e3e6d  push rcx
00007e1ec07e3e6e  push rdx
00007e1ec07e3e6f  push rdi
00007e1ec07e3e70  push rsi
00007e1ec07e3e71  push r8
00007e1ec07e3e73  push r9
00007e1ec07e3e75  push r10
00007e1ec07e3e77  push r11
00007e1ec07e3e79  sub rsp, 0xF0
00007e1ec07e3e80  vmovaps [rsp], xmm0
00007e1ec07e3e85  vmovaps [rsp+0x10], xmm1
00007e1ec07e3e8b  vmovaps [rsp+0x20], xmm2
00007e1ec07e3e91  vmovaps [rsp+0x30], xmm3
00007e1ec07e3e97  vmovaps [rsp+0x40], xmm4
00007e1ec07e3e9d  vmovaps [rsp+0x50], xmm5
00007e1ec07e3ea3  vmovaps [rsp+0x60], xmm6
00007e1ec07e3ea9  vmovaps [rsp+0x70], xmm7
00007e1ec07e3eaf  vmovaps [rsp+0x80], xmm8
00007e1ec07e3eb8  vmovaps [rsp+0x90], xmm9
00007e1ec07e3ec1  vmovaps [rsp+0xA0], xmm11
00007e1ec07e3eca  vmovaps [rsp+0xB0], xmm12
00007e1ec07e3ed3  vmovaps [rsp+0xC0], xmm13
00007e1ec07e3edc  vmovaps [rsp+0xD0], xmm14
00007e1ec07e3ee5  vmovaps [rsp+0xE0], xmm15
00007e1ec07e3eee  sub rsp, 0x30
00007e1ec07e3ef2  movaps [rsp], xmm10
00007e1ec07e3ef7  movaps [rsp+0x10], xmm1
00007e1ec07e3efc  movaps [rsp+0x20], xmm12
00007e1ec07e3f02  lea rdi, [rsp]
00007e1ec07e3f06  mov esi, 0x00
00007e1ec07e3f0b  mov rax, 0x5E00FF778530
00007e1ec07e3f15  call rax
00007e1ec07e3f17  movaps xmm10, [rsp]
00007e1ec07e3f1c  add rsp, 0x30
00007e1ec07e3f20  vmovaps xmm0, [rsp]
00007e1ec07e3f25  vmovaps xmm1, [rsp+0x10]
00007e1ec07e3f2b  vmovaps xmm2, [rsp+0x20]
00007e1ec07e3f31  vmovaps xmm3, [rsp+0x30]
00007e1ec07e3f37  vmovaps xmm4, [rsp+0x40]
00007e1ec07e3f3d  vmovaps xmm5, [rsp+0x50]
00007e1ec07e3f43  vmovaps xmm6, [rsp+0x60]
00007e1ec07e3f49  vmovaps xmm7, [rsp+0x70]
00007e1ec07e3f4f  vmovaps xmm8, [rsp+0x80]
00007e1ec07e3f58  vmovaps xmm9, [rsp+0x90]
00007e1ec07e3f61  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e3f6a  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e3f73  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e3f7c  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e3f85  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e3f8e  add rsp, 0xF0
00007e1ec07e3f95  pop r11
00007e1ec07e3f97  pop r10
00007e1ec07e3f99  pop r9
00007e1ec07e3f9b  pop r8
00007e1ec07e3f9d  pop rsi
00007e1ec07e3f9e  pop rdi
00007e1ec07e3f9f  pop rdx
00007e1ec07e3fa0  pop rcx
00007e1ec07e3fa1  pop rax
00007e1ec07e3fa2  add rsp, 0x08
00007e1ec07e3fa6  jmp 0x00007E1EC07DF8AD
00007e1ec07e3fab  sub rsp, 0x08
00007e1ec07e3faf  push rax
00007e1ec07e3fb0  push rcx
00007e1ec07e3fb1  push rdx
00007e1ec07e3fb2  push rdi
00007e1ec07e3fb3  push rsi
00007e1ec07e3fb4  push r8
00007e1ec07e3fb6  push r9
00007e1ec07e3fb8  push r10
00007e1ec07e3fba  push r11
00007e1ec07e3fbc  sub rsp, 0xF0
00007e1ec07e3fc3  vmovaps [rsp], xmm0
00007e1ec07e3fc8  vmovaps [rsp+0x10], xmm1
00007e1ec07e3fce  vmovaps [rsp+0x20], xmm2
00007e1ec07e3fd4  vmovaps [rsp+0x30], xmm3
00007e1ec07e3fda  vmovaps [rsp+0x40], xmm4
00007e1ec07e3fe0  vmovaps [rsp+0x50], xmm5
00007e1ec07e3fe6  vmovaps [rsp+0x60], xmm6
00007e1ec07e3fec  vmovaps [rsp+0x70], xmm7
00007e1ec07e3ff2  vmovaps [rsp+0x80], xmm8
00007e1ec07e3ffb  vmovaps [rsp+0x90], xmm9
00007e1ec07e4004  vmovaps [rsp+0xA0], xmm10
00007e1ec07e400d  vmovaps [rsp+0xB0], xmm11
00007e1ec07e4016  vmovaps [rsp+0xC0], xmm13
00007e1ec07e401f  vmovaps [rsp+0xD0], xmm14
00007e1ec07e4028  vmovaps [rsp+0xE0], xmm15
00007e1ec07e4031  sub rsp, 0x30
00007e1ec07e4035  movaps [rsp], xmm12
00007e1ec07e403a  movaps [rsp+0x10], xmm14
00007e1ec07e4040  movaps [rsp+0x20], xmm1
00007e1ec07e4045  lea rdi, [rsp]
00007e1ec07e4049  mov esi, 0x00
00007e1ec07e404e  mov rax, 0x5E00FF778530
00007e1ec07e4058  call rax
00007e1ec07e405a  movaps xmm12, [rsp]
00007e1ec07e405f  add rsp, 0x30
00007e1ec07e4063  vmovaps xmm0, [rsp]
00007e1ec07e4068  vmovaps xmm1, [rsp+0x10]
00007e1ec07e406e  vmovaps xmm2, [rsp+0x20]
00007e1ec07e4074  vmovaps xmm3, [rsp+0x30]
00007e1ec07e407a  vmovaps xmm4, [rsp+0x40]
00007e1ec07e4080  vmovaps xmm5, [rsp+0x50]
00007e1ec07e4086  vmovaps xmm6, [rsp+0x60]
00007e1ec07e408c  vmovaps xmm7, [rsp+0x70]
00007e1ec07e4092  vmovaps xmm8, [rsp+0x80]
00007e1ec07e409b  vmovaps xmm9, [rsp+0x90]
00007e1ec07e40a4  vmovaps xmm10, [rsp+0xA0]
00007e1ec07e40ad  vmovaps xmm11, [rsp+0xB0]
00007e1ec07e40b6  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e40bf  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e40c8  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e40d1  add rsp, 0xF0
00007e1ec07e40d8  pop r11
00007e1ec07e40da  pop r10
00007e1ec07e40dc  pop r9
00007e1ec07e40de  pop r8
00007e1ec07e40e0  pop rsi
00007e1ec07e40e1  pop rdi
00007e1ec07e40e2  pop rdx
00007e1ec07e40e3  pop rcx
00007e1ec07e40e4  pop rax
00007e1ec07e40e5  add rsp, 0x08
00007e1ec07e40e9  jmp 0x00007E1EC07DF8DC
00007e1ec07e40ee  sub rsp, 0x08
00007e1ec07e40f2  push rax
00007e1ec07e40f3  push rcx
00007e1ec07e40f4  push rdx
00007e1ec07e40f5  push rdi
00007e1ec07e40f6  push rsi
00007e1ec07e40f7  push r8
00007e1ec07e40f9  push r9
00007e1ec07e40fb  push r10
00007e1ec07e40fd  push r11
00007e1ec07e40ff  sub rsp, 0xF0
00007e1ec07e4106  vmovaps [rsp], xmm0
00007e1ec07e410b  vmovaps [rsp+0x10], xmm1
00007e1ec07e4111  vmovaps [rsp+0x20], xmm2
00007e1ec07e4117  vmovaps [rsp+0x30], xmm3
00007e1ec07e411d  vmovaps [rsp+0x40], xmm4
00007e1ec07e4123  vmovaps [rsp+0x50], xmm5
00007e1ec07e4129  vmovaps [rsp+0x60], xmm6
00007e1ec07e412f  vmovaps [rsp+0x70], xmm7
00007e1ec07e4135  vmovaps [rsp+0x80], xmm8
00007e1ec07e413e  vmovaps [rsp+0x90], xmm9
00007e1ec07e4147  vmovaps [rsp+0xA0], xmm10
00007e1ec07e4150  vmovaps [rsp+0xB0], xmm11
00007e1ec07e4159  vmovaps [rsp+0xC0], xmm12
00007e1ec07e4162  vmovaps [rsp+0xD0], xmm13
00007e1ec07e416b  vmovaps [rsp+0xE0], xmm15
00007e1ec07e4174  sub rsp, 0x30
00007e1ec07e4178  movaps [rsp], xmm14
00007e1ec07e417d  movaps [rsp+0x10], xmm9
00007e1ec07e4183  movaps [rsp+0x20], xmm1
00007e1ec07e4188  lea rdi, [rsp]
00007e1ec07e418c  mov esi, 0x00
00007e1ec07e4191  mov rax, 0x5E00FF778530
00007e1ec07e419b  call rax
00007e1ec07e419d  movaps xmm14, [rsp]
00007e1ec07e41a2  add rsp, 0x30
00007e1ec07e41a6  vmovaps xmm0, [rsp]
00007e1ec07e41ab  vmovaps xmm1, [rsp+0x10]
00007e1ec07e41b1  vmovaps xmm2, [rsp+0x20]
00007e1ec07e41b7  vmovaps xmm3, [rsp+0x30]
00007e1ec07e41bd  vmovaps xmm4, [rsp+0x40]
00007e1ec07e41c3  vmovaps xmm5, [rsp+0x50]
00007e1ec07e41c9  vmovaps xmm6, [rsp+0x60]
00007e1ec07e41cf  vmovaps xmm7, [rsp+0x70]
00007e1ec07e41d5  vmovaps xmm8, [rsp+0x80]
00007e1ec07e41de  vmovaps xmm9, [rsp+0x90]
00007e1ec07e41e7  vmovaps xmm10, [rsp+0xA0]
00007e1ec07e41f0  vmovaps xmm11, [rsp+0xB0]
00007e1ec07e41f9  vmovaps xmm12, [rsp+0xC0]
00007e1ec07e4202  vmovaps xmm13, [rsp+0xD0]
00007e1ec07e420b  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e4214  add rsp, 0xF0
00007e1ec07e421b  pop r11
00007e1ec07e421d  pop r10
00007e1ec07e421f  pop r9
00007e1ec07e4221  pop r8
00007e1ec07e4223  pop rsi
00007e1ec07e4224  pop rdi
00007e1ec07e4225  pop rdx
00007e1ec07e4226  pop rcx
00007e1ec07e4227  pop rax
00007e1ec07e4228  add rsp, 0x08
00007e1ec07e422c  jmp 0x00007E1EC07DF90B
00007e1ec07e4231  sub rsp, 0x08
00007e1ec07e4235  push rax
00007e1ec07e4236  push rcx
00007e1ec07e4237  push rdx
00007e1ec07e4238  push rdi
00007e1ec07e4239  push rsi
00007e1ec07e423a  push r8
00007e1ec07e423c  push r9
00007e1ec07e423e  push r10
00007e1ec07e4240  push r11
00007e1ec07e4242  sub rsp, 0xF0
00007e1ec07e4249  vmovaps [rsp], xmm0
00007e1ec07e424e  vmovaps [rsp+0x10], xmm2
00007e1ec07e4254  vmovaps [rsp+0x20], xmm3
00007e1ec07e425a  vmovaps [rsp+0x30], xmm4
00007e1ec07e4260  vmovaps [rsp+0x40], xmm5
00007e1ec07e4266  vmovaps [rsp+0x50], xmm6
00007e1ec07e426c  vmovaps [rsp+0x60], xmm7
00007e1ec07e4272  vmovaps [rsp+0x70], xmm8
00007e1ec07e4278  vmovaps [rsp+0x80], xmm9
00007e1ec07e4281  vmovaps [rsp+0x90], xmm10
00007e1ec07e428a  vmovaps [rsp+0xA0], xmm11
00007e1ec07e4293  vmovaps [rsp+0xB0], xmm12
00007e1ec07e429c  vmovaps [rsp+0xC0], xmm13
00007e1ec07e42a5  vmovaps [rsp+0xD0], xmm14
00007e1ec07e42ae  vmovaps [rsp+0xE0], xmm15
00007e1ec07e42b7  sub rsp, 0x30
00007e1ec07e42bb  movaps [rsp], xmm1
00007e1ec07e42bf  movaps [rsp+0x10], xmm13
00007e1ec07e42c5  movaps [rsp+0x20], xmm8
00007e1ec07e42cb  lea rdi, [rsp]
00007e1ec07e42cf  mov esi, 0x00
00007e1ec07e42d4  mov rax, 0x5E00FF778530
00007e1ec07e42de  call rax
00007e1ec07e42e0  movaps xmm1, [rsp]
00007e1ec07e42e4  add rsp, 0x30
00007e1ec07e42e8  vmovaps xmm0, [rsp]
00007e1ec07e42ed  vmovaps xmm2, [rsp+0x10]
00007e1ec07e42f3  vmovaps xmm3, [rsp+0x20]
00007e1ec07e42f9  vmovaps xmm4, [rsp+0x30]
00007e1ec07e42ff  vmovaps xmm5, [rsp+0x40]
00007e1ec07e4305  vmovaps xmm6, [rsp+0x50]
00007e1ec07e430b  vmovaps xmm7, [rsp+0x60]
00007e1ec07e4311  vmovaps xmm8, [rsp+0x70]
00007e1ec07e4317  vmovaps xmm9, [rsp+0x80]
00007e1ec07e4320  vmovaps xmm10, [rsp+0x90]
00007e1ec07e4329  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e4332  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e433b  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e4344  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e434d  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e4356  add rsp, 0xF0
00007e1ec07e435d  pop r11
00007e1ec07e435f  pop r10
00007e1ec07e4361  pop r9
00007e1ec07e4363  pop r8
00007e1ec07e4365  pop rsi
00007e1ec07e4366  pop rdi
00007e1ec07e4367  pop rdx
00007e1ec07e4368  pop rcx
00007e1ec07e4369  pop rax
00007e1ec07e436a  add rsp, 0x08
00007e1ec07e436e  jmp 0x00007E1EC07DF92D
00007e1ec07e4373  call 0x00007E1EC060C260
00007e1ec07e4378  jmp 0x00007E1EC07DF93B
00007e1ec07e437d  call 0x00007E1EC06BD750
00007e1ec07e4382  jmp 0x00007E1EC07DF945
00007e1ec07e4387  sub rsp, 0x08
00007e1ec07e438b  push rax
00007e1ec07e438c  push rcx
00007e1ec07e438d  push rdx
00007e1ec07e438e  push rdi
00007e1ec07e438f  push rsi
00007e1ec07e4390  push r8
00007e1ec07e4392  push r9
00007e1ec07e4394  push r10
00007e1ec07e4396  push r11
00007e1ec07e4398  sub rsp, 0xF0
00007e1ec07e439f  vmovaps [rsp], xmm0
00007e1ec07e43a4  vmovaps [rsp+0x10], xmm1
00007e1ec07e43aa  vmovaps [rsp+0x20], xmm2
00007e1ec07e43b0  vmovaps [rsp+0x30], xmm3
00007e1ec07e43b6  vmovaps [rsp+0x40], xmm4
00007e1ec07e43bc  vmovaps [rsp+0x50], xmm5
00007e1ec07e43c2  vmovaps [rsp+0x60], xmm6
00007e1ec07e43c8  vmovaps [rsp+0x70], xmm7
00007e1ec07e43ce  vmovaps [rsp+0x80], xmm9
00007e1ec07e43d7  vmovaps [rsp+0x90], xmm10
00007e1ec07e43e0  vmovaps [rsp+0xA0], xmm11
00007e1ec07e43e9  vmovaps [rsp+0xB0], xmm12
00007e1ec07e43f2  vmovaps [rsp+0xC0], xmm13
00007e1ec07e43fb  vmovaps [rsp+0xD0], xmm14
00007e1ec07e4404  vmovaps [rsp+0xE0], xmm15
00007e1ec07e440d  sub rsp, 0x30
00007e1ec07e4411  movaps [rsp], xmm8
00007e1ec07e4416  movaps [rsp+0x10], xmm15
00007e1ec07e441c  movaps [rsp+0x20], xmm7
00007e1ec07e4421  lea rdi, [rsp]
00007e1ec07e4425  mov esi, 0x00
00007e1ec07e442a  mov rax, 0x5E00FF778530
00007e1ec07e4434  call rax
00007e1ec07e4436  movaps xmm8, [rsp]
00007e1ec07e443b  add rsp, 0x30
00007e1ec07e443f  vmovaps xmm0, [rsp]
00007e1ec07e4444  vmovaps xmm1, [rsp+0x10]
00007e1ec07e444a  vmovaps xmm2, [rsp+0x20]
00007e1ec07e4450  vmovaps xmm3, [rsp+0x30]
00007e1ec07e4456  vmovaps xmm4, [rsp+0x40]
00007e1ec07e445c  vmovaps xmm5, [rsp+0x50]
00007e1ec07e4462  vmovaps xmm6, [rsp+0x60]
00007e1ec07e4468  vmovaps xmm7, [rsp+0x70]
00007e1ec07e446e  vmovaps xmm9, [rsp+0x80]
00007e1ec07e4477  vmovaps xmm10, [rsp+0x90]
00007e1ec07e4480  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e4489  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e4492  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e449b  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e44a4  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e44ad  add rsp, 0xF0
00007e1ec07e44b4  pop r11
00007e1ec07e44b6  pop r10
00007e1ec07e44b8  pop r9
00007e1ec07e44ba  pop r8
00007e1ec07e44bc  pop rsi
00007e1ec07e44bd  pop rdi
00007e1ec07e44be  pop rdx
00007e1ec07e44bf  pop rcx
00007e1ec07e44c0  pop rax
00007e1ec07e44c1  add rsp, 0x08
00007e1ec07e44c5  jmp 0x00007E1EC07DF967
00007e1ec07e44ca  sub rsp, 0x08
00007e1ec07e44ce  push rax
00007e1ec07e44cf  push rcx
00007e1ec07e44d0  push rdx
00007e1ec07e44d1  push rdi
00007e1ec07e44d2  push rsi
00007e1ec07e44d3  push r8
00007e1ec07e44d5  push r9
00007e1ec07e44d7  push r10
00007e1ec07e44d9  push r11
00007e1ec07e44db  sub rsp, 0xF0
00007e1ec07e44e2  vmovaps [rsp], xmm0
00007e1ec07e44e7  vmovaps [rsp+0x10], xmm1
00007e1ec07e44ed  vmovaps [rsp+0x20], xmm2
00007e1ec07e44f3  vmovaps [rsp+0x30], xmm3
00007e1ec07e44f9  vmovaps [rsp+0x40], xmm4
00007e1ec07e44ff  vmovaps [rsp+0x50], xmm5
00007e1ec07e4505  vmovaps [rsp+0x60], xmm6
00007e1ec07e450b  vmovaps [rsp+0x70], xmm8
00007e1ec07e4511  vmovaps [rsp+0x80], xmm9
00007e1ec07e451a  vmovaps [rsp+0x90], xmm10
00007e1ec07e4523  vmovaps [rsp+0xA0], xmm11
00007e1ec07e452c  vmovaps [rsp+0xB0], xmm12
00007e1ec07e4535  vmovaps [rsp+0xC0], xmm13
00007e1ec07e453e  vmovaps [rsp+0xD0], xmm14
00007e1ec07e4547  vmovaps [rsp+0xE0], xmm15
00007e1ec07e4550  sub rsp, 0x30
00007e1ec07e4554  movaps [rsp], xmm7
00007e1ec07e4558  movaps [rsp+0x10], xmm9
00007e1ec07e455e  movaps [rsp+0x20], xmm15
00007e1ec07e4564  lea rdi, [rsp]
00007e1ec07e4568  mov esi, 0x00
00007e1ec07e456d  mov rax, 0x5E00FF778530
00007e1ec07e4577  call rax
00007e1ec07e4579  movaps xmm7, [rsp]
00007e1ec07e457d  add rsp, 0x30
00007e1ec07e4581  vmovaps xmm0, [rsp]
00007e1ec07e4586  vmovaps xmm1, [rsp+0x10]
00007e1ec07e458c  vmovaps xmm2, [rsp+0x20]
00007e1ec07e4592  vmovaps xmm3, [rsp+0x30]
00007e1ec07e4598  vmovaps xmm4, [rsp+0x40]
00007e1ec07e459e  vmovaps xmm5, [rsp+0x50]
00007e1ec07e45a4  vmovaps xmm6, [rsp+0x60]
00007e1ec07e45aa  vmovaps xmm8, [rsp+0x70]
00007e1ec07e45b0  vmovaps xmm9, [rsp+0x80]
00007e1ec07e45b9  vmovaps xmm10, [rsp+0x90]
00007e1ec07e45c2  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e45cb  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e45d4  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e45dd  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e45e6  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e45ef  add rsp, 0xF0
00007e1ec07e45f6  pop r11
00007e1ec07e45f8  pop r10
00007e1ec07e45fa  pop r9
00007e1ec07e45fc  pop r8
00007e1ec07e45fe  pop rsi
00007e1ec07e45ff  pop rdi
00007e1ec07e4600  pop rdx
00007e1ec07e4601  pop rcx
00007e1ec07e4602  pop rax
00007e1ec07e4603  add rsp, 0x08
00007e1ec07e4607  jmp 0x00007E1EC07DF994
00007e1ec07e460c  sub rsp, 0x08
00007e1ec07e4610  push rax
00007e1ec07e4611  push rcx
00007e1ec07e4612  push rdx
00007e1ec07e4613  push rdi
00007e1ec07e4614  push rsi
00007e1ec07e4615  push r8
00007e1ec07e4617  push r9
00007e1ec07e4619  push r10
00007e1ec07e461b  push r11
00007e1ec07e461d  sub rsp, 0xF0
00007e1ec07e4624  vmovaps [rsp], xmm0
00007e1ec07e4629  vmovaps [rsp+0x10], xmm1
00007e1ec07e462f  vmovaps [rsp+0x20], xmm2
00007e1ec07e4635  vmovaps [rsp+0x30], xmm3
00007e1ec07e463b  vmovaps [rsp+0x40], xmm4
00007e1ec07e4641  vmovaps [rsp+0x50], xmm5
00007e1ec07e4647  vmovaps [rsp+0x60], xmm6
00007e1ec07e464d  vmovaps [rsp+0x70], xmm7
00007e1ec07e4653  vmovaps [rsp+0x80], xmm8
00007e1ec07e465c  vmovaps [rsp+0x90], xmm10
00007e1ec07e4665  vmovaps [rsp+0xA0], xmm11
00007e1ec07e466e  vmovaps [rsp+0xB0], xmm12
00007e1ec07e4677  vmovaps [rsp+0xC0], xmm13
00007e1ec07e4680  vmovaps [rsp+0xD0], xmm14
00007e1ec07e4689  vmovaps [rsp+0xE0], xmm15
00007e1ec07e4692  sub rsp, 0x30
00007e1ec07e4696  movaps [rsp], xmm9
00007e1ec07e469b  movaps [rsp+0x10], xmm13
00007e1ec07e46a1  movaps [rsp+0x20], xmm15
00007e1ec07e46a7  lea rdi, [rsp]
00007e1ec07e46ab  mov esi, 0x00
00007e1ec07e46b0  mov rax, 0x5E00FF778530
00007e1ec07e46ba  call rax
00007e1ec07e46bc  movaps xmm9, [rsp]
00007e1ec07e46c1  add rsp, 0x30
00007e1ec07e46c5  vmovaps xmm0, [rsp]
00007e1ec07e46ca  vmovaps xmm1, [rsp+0x10]
00007e1ec07e46d0  vmovaps xmm2, [rsp+0x20]
00007e1ec07e46d6  vmovaps xmm3, [rsp+0x30]
00007e1ec07e46dc  vmovaps xmm4, [rsp+0x40]
00007e1ec07e46e2  vmovaps xmm5, [rsp+0x50]
00007e1ec07e46e8  vmovaps xmm6, [rsp+0x60]
00007e1ec07e46ee  vmovaps xmm7, [rsp+0x70]
00007e1ec07e46f4  vmovaps xmm8, [rsp+0x80]
00007e1ec07e46fd  vmovaps xmm10, [rsp+0x90]
00007e1ec07e4706  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e470f  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e4718  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e4721  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e472a  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e4733  add rsp, 0xF0
00007e1ec07e473a  pop r11
00007e1ec07e473c  pop r10
00007e1ec07e473e  pop r9
00007e1ec07e4740  pop r8
00007e1ec07e4742  pop rsi
00007e1ec07e4743  pop rdi
00007e1ec07e4744  pop rdx
00007e1ec07e4745  pop rcx
00007e1ec07e4746  pop rax
00007e1ec07e4747  add rsp, 0x08
00007e1ec07e474b  jmp 0x00007E1EC07DF9C2
00007e1ec07e4750  sub rsp, 0x08
00007e1ec07e4754  push rax
00007e1ec07e4755  push rcx
00007e1ec07e4756  push rdx
00007e1ec07e4757  push rdi
00007e1ec07e4758  push rsi
00007e1ec07e4759  push r8
00007e1ec07e475b  push r9
00007e1ec07e475d  push r10
00007e1ec07e475f  push r11
00007e1ec07e4761  sub rsp, 0xF0
00007e1ec07e4768  vmovaps [rsp], xmm0
00007e1ec07e476d  vmovaps [rsp+0x10], xmm1
00007e1ec07e4773  vmovaps [rsp+0x20], xmm2
00007e1ec07e4779  vmovaps [rsp+0x30], xmm3
00007e1ec07e477f  vmovaps [rsp+0x40], xmm4
00007e1ec07e4785  vmovaps [rsp+0x50], xmm5
00007e1ec07e478b  vmovaps [rsp+0x60], xmm6
00007e1ec07e4791  vmovaps [rsp+0x70], xmm7
00007e1ec07e4797  vmovaps [rsp+0x80], xmm8
00007e1ec07e47a0  vmovaps [rsp+0x90], xmm9
00007e1ec07e47a9  vmovaps [rsp+0xA0], xmm10
00007e1ec07e47b2  vmovaps [rsp+0xB0], xmm11
00007e1ec07e47bb  vmovaps [rsp+0xC0], xmm12
00007e1ec07e47c4  vmovaps [rsp+0xD0], xmm13
00007e1ec07e47cd  vmovaps [rsp+0xE0], xmm14
00007e1ec07e47d6  sub rsp, 0x30
00007e1ec07e47da  movaps [rsp], xmm15
00007e1ec07e47df  movaps [rsp+0x10], xmm11
00007e1ec07e47e5  movaps [rsp+0x20], xmm12
00007e1ec07e47eb  lea rdi, [rsp]
00007e1ec07e47ef  mov esi, 0x00
00007e1ec07e47f4  mov rax, 0x5E00FF778530
00007e1ec07e47fe  call rax
00007e1ec07e4800  movaps xmm15, [rsp]
00007e1ec07e4805  add rsp, 0x30
00007e1ec07e4809  vmovaps xmm0, [rsp]
00007e1ec07e480e  vmovaps xmm1, [rsp+0x10]
00007e1ec07e4814  vmovaps xmm2, [rsp+0x20]
00007e1ec07e481a  vmovaps xmm3, [rsp+0x30]
00007e1ec07e4820  vmovaps xmm4, [rsp+0x40]
00007e1ec07e4826  vmovaps xmm5, [rsp+0x50]
00007e1ec07e482c  vmovaps xmm6, [rsp+0x60]
00007e1ec07e4832  vmovaps xmm7, [rsp+0x70]
00007e1ec07e4838  vmovaps xmm8, [rsp+0x80]
00007e1ec07e4841  vmovaps xmm9, [rsp+0x90]
00007e1ec07e484a  vmovaps xmm10, [rsp+0xA0]
00007e1ec07e4853  vmovaps xmm11, [rsp+0xB0]
00007e1ec07e485c  vmovaps xmm12, [rsp+0xC0]
00007e1ec07e4865  vmovaps xmm13, [rsp+0xD0]
00007e1ec07e486e  vmovaps xmm14, [rsp+0xE0]
00007e1ec07e4877  add rsp, 0xF0
00007e1ec07e487e  pop r11
00007e1ec07e4880  pop r10
00007e1ec07e4882  pop r9
00007e1ec07e4884  pop r8
00007e1ec07e4886  pop rsi
00007e1ec07e4887  pop rdi
00007e1ec07e4888  pop rdx
00007e1ec07e4889  pop rcx
00007e1ec07e488a  pop rax
00007e1ec07e488b  add rsp, 0x08
00007e1ec07e488f  jmp 0x00007E1EC07DF9DD
00007e1ec07e4894  sub rsp, 0x08
00007e1ec07e4898  push rax
00007e1ec07e4899  push rcx
00007e1ec07e489a  push rdx
00007e1ec07e489b  push rdi
00007e1ec07e489c  push rsi
00007e1ec07e489d  push r8
00007e1ec07e489f  push r9
00007e1ec07e48a1  push r10
00007e1ec07e48a3  push r11
00007e1ec07e48a5  sub rsp, 0xF0
00007e1ec07e48ac  vmovaps [rsp], xmm0
00007e1ec07e48b1  vmovaps [rsp+0x10], xmm1
00007e1ec07e48b7  vmovaps [rsp+0x20], xmm2
00007e1ec07e48bd  vmovaps [rsp+0x30], xmm3
00007e1ec07e48c3  vmovaps [rsp+0x40], xmm4
00007e1ec07e48c9  vmovaps [rsp+0x50], xmm5
00007e1ec07e48cf  vmovaps [rsp+0x60], xmm6
00007e1ec07e48d5  vmovaps [rsp+0x70], xmm7
00007e1ec07e48db  vmovaps [rsp+0x80], xmm8
00007e1ec07e48e4  vmovaps [rsp+0x90], xmm9
00007e1ec07e48ed  vmovaps [rsp+0xA0], xmm10
00007e1ec07e48f6  vmovaps [rsp+0xB0], xmm11
00007e1ec07e48ff  vmovaps [rsp+0xC0], xmm12
00007e1ec07e4908  vmovaps [rsp+0xD0], xmm14
00007e1ec07e4911  vmovaps [rsp+0xE0], xmm15
00007e1ec07e491a  sub rsp, 0x30
00007e1ec07e491e  movaps [rsp], xmm13
00007e1ec07e4923  movaps [rsp+0x10], xmm10
00007e1ec07e4929  movaps [rsp+0x20], xmm14
00007e1ec07e492f  lea rdi, [rsp]
00007e1ec07e4933  mov esi, 0x00
00007e1ec07e4938  mov rax, 0x5E00FF778530
00007e1ec07e4942  call rax
00007e1ec07e4944  movaps xmm13, [rsp]
00007e1ec07e4949  add rsp, 0x30
00007e1ec07e494d  vmovaps xmm0, [rsp]
00007e1ec07e4952  vmovaps xmm1, [rsp+0x10]
00007e1ec07e4958  vmovaps xmm2, [rsp+0x20]
00007e1ec07e495e  vmovaps xmm3, [rsp+0x30]
00007e1ec07e4964  vmovaps xmm4, [rsp+0x40]
00007e1ec07e496a  vmovaps xmm5, [rsp+0x50]
00007e1ec07e4970  vmovaps xmm6, [rsp+0x60]
00007e1ec07e4976  vmovaps xmm7, [rsp+0x70]
00007e1ec07e497c  vmovaps xmm8, [rsp+0x80]
00007e1ec07e4985  vmovaps xmm9, [rsp+0x90]
00007e1ec07e498e  vmovaps xmm10, [rsp+0xA0]
00007e1ec07e4997  vmovaps xmm11, [rsp+0xB0]
00007e1ec07e49a0  vmovaps xmm12, [rsp+0xC0]
00007e1ec07e49a9  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e49b2  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e49bb  add rsp, 0xF0
00007e1ec07e49c2  pop r11
00007e1ec07e49c4  pop r10
00007e1ec07e49c6  pop r9
00007e1ec07e49c8  pop r8
00007e1ec07e49ca  pop rsi
00007e1ec07e49cb  pop rdi
00007e1ec07e49cc  pop rdx
00007e1ec07e49cd  pop rcx
00007e1ec07e49ce  pop rax
00007e1ec07e49cf  add rsp, 0x08
00007e1ec07e49d3  jmp 0x00007E1EC07DFA00
00007e1ec07e49d8  sub rsp, 0x08
00007e1ec07e49dc  push rax
00007e1ec07e49dd  push rcx
00007e1ec07e49de  push rdx
00007e1ec07e49df  push rdi
00007e1ec07e49e0  push rsi
00007e1ec07e49e1  push r8
00007e1ec07e49e3  push r9
00007e1ec07e49e5  push r10
00007e1ec07e49e7  push r11
00007e1ec07e49e9  sub rsp, 0xF0
00007e1ec07e49f0  vmovaps [rsp], xmm0
00007e1ec07e49f5  vmovaps [rsp+0x10], xmm1
00007e1ec07e49fb  vmovaps [rsp+0x20], xmm2
00007e1ec07e4a01  vmovaps [rsp+0x30], xmm3
00007e1ec07e4a07  vmovaps [rsp+0x40], xmm4
00007e1ec07e4a0d  vmovaps [rsp+0x50], xmm5
00007e1ec07e4a13  vmovaps [rsp+0x60], xmm6
00007e1ec07e4a19  vmovaps [rsp+0x70], xmm7
00007e1ec07e4a1f  vmovaps [rsp+0x80], xmm8
00007e1ec07e4a28  vmovaps [rsp+0x90], xmm9
00007e1ec07e4a31  vmovaps [rsp+0xA0], xmm10
00007e1ec07e4a3a  vmovaps [rsp+0xB0], xmm11
00007e1ec07e4a43  vmovaps [rsp+0xC0], xmm12
00007e1ec07e4a4c  vmovaps [rsp+0xD0], xmm13
00007e1ec07e4a55  vmovaps [rsp+0xE0], xmm15
00007e1ec07e4a5e  sub rsp, 0x30
00007e1ec07e4a62  movaps [rsp], xmm14
00007e1ec07e4a67  movaps [rsp+0x10], xmm1
00007e1ec07e4a6c  movaps [rsp+0x20], xmm7
00007e1ec07e4a71  lea rdi, [rsp]
00007e1ec07e4a75  mov esi, 0x00
00007e1ec07e4a7a  mov rax, 0x5E00FF778530
00007e1ec07e4a84  call rax
00007e1ec07e4a86  movaps xmm14, [rsp]
00007e1ec07e4a8b  add rsp, 0x30
00007e1ec07e4a8f  vmovaps xmm0, [rsp]
00007e1ec07e4a94  vmovaps xmm1, [rsp+0x10]
00007e1ec07e4a9a  vmovaps xmm2, [rsp+0x20]
00007e1ec07e4aa0  vmovaps xmm3, [rsp+0x30]
00007e1ec07e4aa6  vmovaps xmm4, [rsp+0x40]
00007e1ec07e4aac  vmovaps xmm5, [rsp+0x50]
00007e1ec07e4ab2  vmovaps xmm6, [rsp+0x60]
00007e1ec07e4ab8  vmovaps xmm7, [rsp+0x70]
00007e1ec07e4abe  vmovaps xmm8, [rsp+0x80]
00007e1ec07e4ac7  vmovaps xmm9, [rsp+0x90]
00007e1ec07e4ad0  vmovaps xmm10, [rsp+0xA0]
00007e1ec07e4ad9  vmovaps xmm11, [rsp+0xB0]
00007e1ec07e4ae2  vmovaps xmm12, [rsp+0xC0]
00007e1ec07e4aeb  vmovaps xmm13, [rsp+0xD0]
00007e1ec07e4af4  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e4afd  add rsp, 0xF0
00007e1ec07e4b04  pop r11
00007e1ec07e4b06  pop r10
00007e1ec07e4b08  pop r9
00007e1ec07e4b0a  pop r8
00007e1ec07e4b0c  pop rsi
00007e1ec07e4b0d  pop rdi
00007e1ec07e4b0e  pop rdx
00007e1ec07e4b0f  pop rcx
00007e1ec07e4b10  pop rax
00007e1ec07e4b11  add rsp, 0x08
00007e1ec07e4b15  jmp 0x00007E1EC07DFA23
00007e1ec07e4b1a  sub rsp, 0x08
00007e1ec07e4b1e  push rax
00007e1ec07e4b1f  push rcx
00007e1ec07e4b20  push rdx
00007e1ec07e4b21  push rdi
00007e1ec07e4b22  push rsi
00007e1ec07e4b23  push r8
00007e1ec07e4b25  push r9
00007e1ec07e4b27  push r10
00007e1ec07e4b29  push r11
00007e1ec07e4b2b  sub rsp, 0xF0
00007e1ec07e4b32  vmovaps [rsp], xmm0
00007e1ec07e4b37  vmovaps [rsp+0x10], xmm2
00007e1ec07e4b3d  vmovaps [rsp+0x20], xmm3
00007e1ec07e4b43  vmovaps [rsp+0x30], xmm4
00007e1ec07e4b49  vmovaps [rsp+0x40], xmm5
00007e1ec07e4b4f  vmovaps [rsp+0x50], xmm6
00007e1ec07e4b55  vmovaps [rsp+0x60], xmm7
00007e1ec07e4b5b  vmovaps [rsp+0x70], xmm8
00007e1ec07e4b61  vmovaps [rsp+0x80], xmm9
00007e1ec07e4b6a  vmovaps [rsp+0x90], xmm10
00007e1ec07e4b73  vmovaps [rsp+0xA0], xmm11
00007e1ec07e4b7c  vmovaps [rsp+0xB0], xmm12
00007e1ec07e4b85  vmovaps [rsp+0xC0], xmm13
00007e1ec07e4b8e  vmovaps [rsp+0xD0], xmm14
00007e1ec07e4b97  vmovaps [rsp+0xE0], xmm15
00007e1ec07e4ba0  sub rsp, 0x30
00007e1ec07e4ba4  movaps [rsp], xmm1
00007e1ec07e4ba8  movaps [rsp+0x10], xmm8
00007e1ec07e4bae  movaps [rsp+0x20], xmm9
00007e1ec07e4bb4  lea rdi, [rsp]
00007e1ec07e4bb8  mov esi, 0x00
00007e1ec07e4bbd  mov rax, 0x5E00FF778530
00007e1ec07e4bc7  call rax
00007e1ec07e4bc9  movaps xmm1, [rsp]
00007e1ec07e4bcd  add rsp, 0x30
00007e1ec07e4bd1  vmovaps xmm0, [rsp]
00007e1ec07e4bd6  vmovaps xmm2, [rsp+0x10]
00007e1ec07e4bdc  vmovaps xmm3, [rsp+0x20]
00007e1ec07e4be2  vmovaps xmm4, [rsp+0x30]
00007e1ec07e4be8  vmovaps xmm5, [rsp+0x40]
00007e1ec07e4bee  vmovaps xmm6, [rsp+0x50]
00007e1ec07e4bf4  vmovaps xmm7, [rsp+0x60]
00007e1ec07e4bfa  vmovaps xmm8, [rsp+0x70]
00007e1ec07e4c00  vmovaps xmm9, [rsp+0x80]
00007e1ec07e4c09  vmovaps xmm10, [rsp+0x90]
00007e1ec07e4c12  vmovaps xmm11, [rsp+0xA0]
00007e1ec07e4c1b  vmovaps xmm12, [rsp+0xB0]
00007e1ec07e4c24  vmovaps xmm13, [rsp+0xC0]
00007e1ec07e4c2d  vmovaps xmm14, [rsp+0xD0]
00007e1ec07e4c36  vmovaps xmm15, [rsp+0xE0]
00007e1ec07e4c3f  add rsp, 0xF0
00007e1ec07e4c46  pop r11
00007e1ec07e4c48  pop r10
00007e1ec07e4c4a  pop r9
00007e1ec07e4c4c  pop r8
00007e1ec07e4c4e  pop rsi
00007e1ec07e4c4f  pop rdi
00007e1ec07e4c50  pop rdx
00007e1ec07e4c51  pop rcx
00007e1ec07e4c52  pop rax
00007e1ec07e4c53  add rsp, 0x08
00007e1ec07e4c57  jmp 0x00007E1EC07DFA45
00007e1ec07e4c5c  call 0x00007E1EC06E5940
00007e1ec07e4c61  jmp 0x00007E1EC07DFA53
00007e1ec07e4c66  call 0x00007E1EC060C380
00007e1ec07e4c6b  jmp 0x00007E1EC07DFA5D
00007e1ec07e4c70  call 0x00007E1EC060D600
00007e1ec07e4c75  jmp 0x00007E1EC07DFA67
00007e1ec07e4c7a  call 0x00007E1EC05FF540
00007e1ec07e4c7f  jmp 0x00007E1EC07DFA71
00007e1ec07e4c84  int3
00007e1ec07e4c85  nop [rax+rax*1], ax
00007e1ec07e4c8e  nop
00007e1ec07e4c90  mov qword ptr [r15+0x40], 0x430000
00007e1ec07e4c98  mov eax, 0x430CC0
00007e1ec07e4c9d  mov r14, [r13+rax*1]
00007e1ec07e4ca2  movq xmm1, r14
00007e1ec07e4ca7  mov rax, [r15+0x50]
00007e1ec07e4cab  movups xmm15, [r13+rax*1]
00007e1ec07e4cb1  movaps [r15+0x120], xmm15
00007e1ec07e4cb9  mov qword ptr [r15+0x48], 0x10
00007e1ec07e4cc1  xor eax, eax
00007e1ec07e4cc3  mov r14d, 0x10
00007e1ec07e4cc9  mov r12d, 0x200
00007e1ec07e4ccf  cmp r14, r12
00007e1ec07e4cd2  cmc
00007e1ec07e4cd3  lahf
00007e1ec07e4cd4  seto al
00007e1ec07e4cd7  mov [r15+0x108], eax
00007e1ec07e4cde  pextrq rax, xmm15, 0x01
00007e1ec07e4ce5  movq xmm14, rax
00007e1ec07e4cea  movaps [r15+0x130], xmm14
00007e1ec07e4cf2  movq rax, xmm1
00007e1ec07e4cf7  movq r14, xmm15
00007e1ec07e4cfc  vmovq xmm1, rax
00007e1ec07e4d01  vmovq xmm15, r14
00007e1ec07e4d06  movaps xmm13, xmm1
00007e1ec07e4d0a  addsd xmm13, xmm15
00007e1ec07e4d0f  ucomisd xmm13, xmm13
00007e1ec07e4d14  jp 0x00007E1EC07E4DD3
00007e1ec07e4d1a  movq xmm13, xmm13
00007e1ec07e4d1f  movq rax, xmm13
00007e1ec07e4d24  movq r14, xmm14
00007e1ec07e4d29  vmovq xmm1, rax
00007e1ec07e4d2e  vmovq xmm15, r14
00007e1ec07e4d33  movaps xmm14, xmm1
00007e1ec07e4d37  addsd xmm14, xmm15
00007e1ec07e4d3c  ucomisd xmm14, xmm14
00007e1ec07e4d41  jp 0x00007E1EC07E4E1B
00007e1ec07e4d47  movq xmm14, xmm14
00007e1ec07e4d4c  movaps [r15+0x110], xmm14
00007e1ec07e4d54  mov eax, [r15+0x108]
00007e1ec07e4d5b  sahf
00007e1ec07e4d5c  jnz 0x00007E1EC07E4D8E
00007e1ec07e4d5e  cmp dword ptr [r15+0x318], 0x00
00007e1ec07e4d66  jz 0x00007E1EC07E5030
00007e1ec07e4d6c  nop [rax+rax*1], ax
00007e1ec07e4d75  nop [rax+rax*1], eax
00007e1ec07e4d7d  mov eax, 0x410704
00007e1ec07e4d82  mov [r15+0x100], rax
00007e1ec07e4d89  jmp 0x00007E1EC05FE110
00007e1ec07e4d8e  cmp dword ptr [r15+0x318], 0x00
00007e1ec07e4d96  jz 0x00007E1EC07E4E70
00007e1ec07e4d9c  nop [rax+rax*1], ax
00007e1ec07e4da5  nop [rax+rax*1], eax
00007e1ec07e4dad  mov eax, 0x4106E8
00007e1ec07e4db2  mov [r15+0x100], rax
00007e1ec07e4db9  jmp 0x00007E1EC05FE110
00007e1ec07e4dbe  int3
00007e1ec07e4dbf  call 0x00007E1EC060DC20
00007e1ec07e4dc4  jmp 0x00007E1EC07E4CA2
00007e1ec07e4dc9  call 0x00007E1EC060E760
00007e1ec07e4dce  jmp 0x00007E1EC07E4CB1
00007e1ec07e4dd3  ucomisd xmm1, xmm15
00007e1ec07e4dd8  jp 0x00007E1EC07E4DE7
00007e1ec07e4dda  movaps xmm13, [0x00007E1EC03FE060]
00007e1ec07e4de2  jmp 0x00007E1EC07E4D1A
00007e1ec07e4de7  vxorps xmm0, xmm1, xmm15
00007e1ec07e4dec  pextrw eax, xmm0, 0x03
00007e1ec07e4df1  and eax, 0x7FF8
00007e1ec07e4df6  cmp eax, 0x08
00007e1ec07e4df9  jnz 0x00007E1EC07E4D1A
00007e1ec07e4dff  movq rax, xmm15
00007e1ec07e4e04  shl rax, 0x0D
00007e1ec07e4e08  jbe 0x00007E1EC07E4D1A
00007e1ec07e4e0e  vorps xmm13, xmm15, [0x00007E1EC03FE070]
00007e1ec07e4e16  jmp 0x00007E1EC07E4D1A
00007e1ec07e4e1b  ucomisd xmm1, xmm15
00007e1ec07e4e20  jp 0x00007E1EC07E4E2F
00007e1ec07e4e22  movaps xmm14, [0x00007E1EC03FE060]
00007e1ec07e4e2a  jmp 0x00007E1EC07E4D47
00007e1ec07e4e2f  vxorps xmm0, xmm1, xmm15
00007e1ec07e4e34  pextrw eax, xmm0, 0x03
00007e1ec07e4e39  and eax, 0x7FF8
00007e1ec07e4e3e  cmp eax, 0x08
00007e1ec07e4e41  jnz 0x00007E1EC07E4D47
00007e1ec07e4e47  movq rax, xmm15
00007e1ec07e4e4c  shl rax, 0x0D
00007e1ec07e4e50  jbe 0x00007E1EC07E4D47
00007e1ec07e4e56  vorps xmm14, xmm15, [0x00007E1EC03FE070]
00007e1ec07e4e5e  jmp 0x00007E1EC07E4D47
00007e1ec07e4e63  int3
00007e1ec07e4e64  nop [rax+rax*1], ax
00007e1ec07e4e6d  nop [rax], eax
00007e1ec07e4e70  mov rax, [r15+0x48]
00007e1ec07e4e74  mov r14, [r15+0x50]
00007e1ec07e4e78  lea r12, [r14+rax*1]
00007e1ec07e4e7c  movups xmm1, [r13+r12*1]
00007e1ec07e4e82  movaps [r15+0x120], xmm1
00007e1ec07e4e8a  lea r14, [rax+0x10]
00007e1ec07e4e8e  mov [r15+0x48], r14
00007e1ec07e4e92  xor eax, eax
00007e1ec07e4e94  mov r12d, 0x200
00007e1ec07e4e9a  cmp r14, r12
00007e1ec07e4e9d  cmc
00007e1ec07e4e9e  lahf
00007e1ec07e4e9f  seto al
00007e1ec07e4ea2  mov [r15+0x108], eax
00007e1ec07e4ea9  pextrq rax, xmm1, 0x01
00007e1ec07e4eb0  movq xmm15, rax
00007e1ec07e4eb5  movaps [r15+0x130], xmm15
00007e1ec07e4ebd  movaps xmm14, [r15+0x110]
00007e1ec07e4ec5  movq rax, xmm14
00007e1ec07e4eca  movq r14, xmm1
00007e1ec07e4ecf  vmovq xmm1, rax
00007e1ec07e4ed4  vmovq xmm14, r14
00007e1ec07e4ed9  movaps xmm13, xmm1
00007e1ec07e4edd  addsd xmm13, xmm14
00007e1ec07e4ee2  ucomisd xmm13, xmm13
00007e1ec07e4ee7  jp 0x00007E1EC07E4F9C
00007e1ec07e4eed  movq xmm13, xmm13
00007e1ec07e4ef2  movq rax, xmm13
00007e1ec07e4ef7  movq r14, xmm15
00007e1ec07e4efc  vmovq xmm1, rax
00007e1ec07e4f01  vmovq xmm15, r14
00007e1ec07e4f06  movaps xmm14, xmm1
00007e1ec07e4f0a  addsd xmm14, xmm15
00007e1ec07e4f0f  ucomisd xmm14, xmm14
00007e1ec07e4f14  jp 0x00007E1EC07E4FE4
00007e1ec07e4f1a  movq xmm14, xmm14
00007e1ec07e4f1f  movaps [r15+0x110], xmm14
00007e1ec07e4f27  mov eax, [r15+0x108]
00007e1ec07e4f2e  sahf
00007e1ec07e4f2f  jnz 0x00007E1EC07E4F61
00007e1ec07e4f31  cmp dword ptr [r15+0x318], 0x00
00007e1ec07e4f39  jz 0x00007E1EC07E5030
00007e1ec07e4f3f  nop [rax+rax*1], ax
00007e1ec07e4f48  nop [rax+rax*1], eax
00007e1ec07e4f50  mov eax, 0x410704
00007e1ec07e4f55  mov [r15+0x100], rax
00007e1ec07e4f5c  jmp 0x00007E1EC05FE110
00007e1ec07e4f61  cmp dword ptr [r15+0x318], 0x00
00007e1ec07e4f69  jz 0x00007E1EC07E4E70
00007e1ec07e4f6f  nop [rax+rax*1], ax
00007e1ec07e4f78  nop [rax+rax*1], eax
00007e1ec07e4f80  mov eax, 0x4106E8
00007e1ec07e4f85  mov [r15+0x100], rax
00007e1ec07e4f8c  jmp 0x00007E1EC05FE110
00007e1ec07e4f91  int3
00007e1ec07e4f92  call 0x00007E1EC06B52F0
00007e1ec07e4f97  jmp 0x00007E1EC07E4E82
00007e1ec07e4f9c  ucomisd xmm1, xmm14
00007e1ec07e4fa1  jp 0x00007E1EC07E4FB0
00007e1ec07e4fa3  movaps xmm13, [0x00007E1EC03FE060]
00007e1ec07e4fab  jmp 0x00007E1EC07E4EED
00007e1ec07e4fb0  vxorps xmm0, xmm1, xmm14
00007e1ec07e4fb5  pextrw eax, xmm0, 0x03
00007e1ec07e4fba  and eax, 0x7FF8
00007e1ec07e4fbf  cmp eax, 0x08
00007e1ec07e4fc2  jnz 0x00007E1EC07E4EED
00007e1ec07e4fc8  movq rax, xmm14
00007e1ec07e4fcd  shl rax, 0x0D
00007e1ec07e4fd1  jbe 0x00007E1EC07E4EED
00007e1ec07e4fd7  vorps xmm13, xmm14, [0x00007E1EC03FE070]
00007e1ec07e4fdf  jmp 0x00007E1EC07E4EED
00007e1ec07e4fe4  ucomisd xmm1, xmm15
00007e1ec07e4fe9  jp 0x00007E1EC07E4FF8
00007e1ec07e4feb  movaps xmm14, [0x00007E1EC03FE060]
00007e1ec07e4ff3  jmp 0x00007E1EC07E4F1A
00007e1ec07e4ff8  vxorps xmm0, xmm1, xmm15
00007e1ec07e4ffd  pextrw eax, xmm0, 0x03
00007e1ec07e5002  and eax, 0x7FF8
00007e1ec07e5007  cmp eax, 0x08
00007e1ec07e500a  jnz 0x00007E1EC07E4F1A
00007e1ec07e5010  movq rax, xmm15
00007e1ec07e5015  shl rax, 0x0D
00007e1ec07e5019  jbe 0x00007E1EC07E4F1A
00007e1ec07e501f  vorps xmm14, xmm15, [0x00007E1EC03FE070]
00007e1ec07e5027  jmp 0x00007E1EC07E4F1A
00007e1ec07e502c  int3
00007e1ec07e502d  nop [rax], eax
00007e1ec07e5030  mov rax, [r15+0xF8]
00007e1ec07e5037  lea r14, [rax+0x1D0]
00007e1ec07e503e  mov r12, [r13+r14*1]
00007e1ec07e5043  lea r14, [rax+0x1D8]
00007e1ec07e504a  mov r11, [r13+r14*1]
00007e1ec07e504f  mov [r15+0xA0], r12
00007e1ec07e5056  mov [r15+0x98], r11
00007e1ec07e505d  mov r14, [r15+0x40]
00007e1ec07e5061  lea r12, [r14+0xCC0]
00007e1ec07e5068  movaps xmm1, [r15+0x110]
00007e1ec07e5070  movq r14, xmm1
00007e1ec07e5075  mov [r13+r12*1], r14
00007e1ec07e507a  lea r14, [rax+0x1C0]
00007e1ec07e5081  mov r12, [r13+r14*1]
00007e1ec07e5086  lea r14, [rax+0x1C8]
00007e1ec07e508d  mov r11, [r13+r14*1]
00007e1ec07e5092  mov [r15+0xE8], r12
00007e1ec07e5099  mov [r15+0xF0], r11
00007e1ec07e50a0  lea r14, [rax+0x1B0]
00007e1ec07e50a7  mov r12, [r13+r14*1]
00007e1ec07e50ac  lea r14, [rax+0x1B8]
00007e1ec07e50b3  mov r10, [r13+r14*1]
00007e1ec07e50b8  movq xmm1, r12
00007e1ec07e50bd  movq xmm15, r10
00007e1ec07e50c2  movq xmm1, xmm1
00007e1ec07e50c6  movq xmm1, xmm1
00007e1ec07e50ca  movaps [r15+0x1A0], xmm1
00007e1ec07e50d2  movq xmm15, xmm15
00007e1ec07e50d7  movq xmm15, xmm15
00007e1ec07e50dc  movaps [r15+0x190], xmm15
00007e1ec07e50e4  lea r14, [rax+0x1A0]
00007e1ec07e50eb  mov r12, [r13+r14*1]
00007e1ec07e50f0  lea r14, [rax+0x1A8]
00007e1ec07e50f7  mov r10, [r13+r14*1]
00007e1ec07e50fc  movq xmm1, r12
00007e1ec07e5101  movq xmm15, r10
00007e1ec07e5106  movq xmm1, xmm1
00007e1ec07e510a  movq xmm1, xmm1
00007e1ec07e510e  movaps [r15+0x1C0], xmm1
00007e1ec07e5116  movq xmm15, xmm15
00007e1ec07e511b  movq xmm15, xmm15
00007e1ec07e5120  movaps [r15+0x1B0], xmm15
00007e1ec07e5128  lea r14, [rax+0x190]
00007e1ec07e512f  mov r12, [r13+r14*1]
00007e1ec07e5134  lea r14, [rax+0x198]
00007e1ec07e513b  mov r10, [r13+r14*1]
00007e1ec07e5140  movq xmm1, r12
00007e1ec07e5145  movq xmm15, r10
00007e1ec07e514a  movq xmm1, xmm1
00007e1ec07e514e  movq xmm1, xmm1
00007e1ec07e5152  movaps [r15+0x1E0], xmm1
00007e1ec07e515a  movq xmm15, xmm15
00007e1ec07e515f  movq xmm15, xmm15
00007e1ec07e5164  movaps [r15+0x1D0], xmm15
00007e1ec07e516c  lea r14, [rax+0x180]
00007e1ec07e5173  mov r12, [r13+r14*1]
00007e1ec07e5178  lea r14, [rax+0x188]
00007e1ec07e517f  mov r10, [r13+r14*1]
00007e1ec07e5184  movq xmm1, r12
00007e1ec07e5189  movq xmm15, r10
00007e1ec07e518e  movq xmm1, xmm1
00007e1ec07e5192  movq xmm1, xmm1
00007e1ec07e5196  movaps [r15+0x200], xmm1
00007e1ec07e519e  movq xmm15, xmm15
00007e1ec07e51a3  movq xmm15, xmm15
00007e1ec07e51a8  movaps [r15+0x1F0], xmm15
00007e1ec07e51b0  lea r14, [rax+0x1E0]
00007e1ec07e51b7  mov [r15+0xF8], r14
00007e1ec07e51be  mov [r15+0x100], r11
00007e1ec07e51c5  jmp 0x00007E1EC07CE5C0
00007e1ec07e51ca  int3
00007e1ec07e51cb  call 0x00007E1EC06E27E0
00007e1ec07e51d0  jmp 0x00007E1EC07E5043
00007e1ec07e51d5  call 0x00007E1EC06E1570
00007e1ec07e51da  jmp 0x00007E1EC07E504F
00007e1ec07e51df  call 0x00007E1EC06C3FE0
00007e1ec07e51e4  jmp 0x00007E1EC07E507A
00007e1ec07e51e9  call 0x00007E1EC06E27E0
00007e1ec07e51ee  jmp 0x00007E1EC07E5086
00007e1ec07e51f3  call 0x00007E1EC06E1570
00007e1ec07e51f8  jmp 0x00007E1EC07E5092
00007e1ec07e51fd  call 0x00007E1EC06E27E0
00007e1ec07e5202  jmp 0x00007E1EC07E50AC
00007e1ec07e5207  call 0x00007E1EC06E0300
00007e1ec07e520c  jmp 0x00007E1EC07E50B8
00007e1ec07e5211  call 0x00007E1EC06E27E0
00007e1ec07e5216  jmp 0x00007E1EC07E50F0
00007e1ec07e521b  call 0x00007E1EC06E0300
00007e1ec07e5220  jmp 0x00007E1EC07E50FC
00007e1ec07e5225  call 0x00007E1EC06E27E0
00007e1ec07e522a  jmp 0x00007E1EC07E5134
00007e1ec07e522f  call 0x00007E1EC06E0300
00007e1ec07e5234  jmp 0x00007E1EC07E5140
00007e1ec07e5239  call 0x00007E1EC06E27E0
00007e1ec07e523e  jmp 0x00007E1EC07E5178
00007e1ec07e5243  call 0x00007E1EC06E0300
00007e1ec07e5248  jmp 0x00007E1EC07E5184
00007e1ec07e524d  int3
00007e1ec07e524e  nop
00007e1ec07e5250  mov qword ptr [r15+0x100], 0x04
00007e1ec07e525b  mov esi, 0x00
00007e1ec07e5260  mov edx, 0x09
00007e1ec07e5265  mov rdi, 0x7FFE41458B70
00007e1ec07e526f  mov rax, 0x5E00FF60B970
00007e1ec07e5279  call rax
00007e1ec07e527b  cmp dword ptr [r15+0x318], 0x00
00007e1ec07e5283  jnz 0x00007E1EC05FE110
00007e1ec07e5289  jmp 0x00007E1EC05FE0A0
00007e1ec07e528e  int3
00007e1ec07e528f  int3
