
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/1/0.bin:     file format binary


Disassembly of section .data:

000075b0baafe000 <.data>:
    75b0baafe000:	sub    rsp,0x10
    75b0baafe004:	mov    r11,QWORD PTR [r12+0x398]
    75b0baafe00c:	mov    QWORD PTR [rsp],r11
    75b0baafe010:	mov    r13,QWORD PTR [r12+0xf8]
    75b0baafe018:	sub    r13,0x1e0
    75b0baafe01f:	mov    QWORD PTR [r12+0xf8],r13
    75b0baafe027:	mov    r14d,0x420000
    75b0baafe02d:	mov    QWORD PTR [r12+0x40],r14
    75b0baafe032:	mov    r14d,0x420000
    75b0baafe038:	mov    QWORD PTR [r12+0x48],r14
    75b0baafe03d:	mov    r14,r13
    75b0baafe040:	add    r14,0x1d0
    75b0baafe047:	mov    r15,r14
    75b0baafe04a:	add    r15,0x8
    75b0baafe04e:	mov    rbp,QWORD PTR [r12+0xa0]
    75b0baafe056:	mov    r8,QWORD PTR [r12+0x98]
    75b0baafe05e:	mov    QWORD PTR [r14],rbp
    75b0baafe061:	mov    r14d,0x0
    75b0baafe067:	mov    DWORD PTR [r12+0x32c],r14d
    75b0baafe06f:	mov    QWORD PTR [r15],r8
    75b0baafe072:	mov    r14d,0x420aa0
    75b0baafe078:	movdqu xmm2,XMMWORD PTR [r14]
    75b0baafe07d:	movdqu XMMWORD PTR [r12+0x110],xmm2
    75b0baafe087:	mov    r14d,0x420a30
    75b0baafe08d:	movdqu xmm3,XMMWORD PTR [r14]
    75b0baafe092:	movdqu XMMWORD PTR [r12+0x120],xmm3
    75b0baafe09c:	mov    r14d,0x420ac0
    75b0baafe0a2:	movdqu xmm4,XMMWORD PTR [r14]
    75b0baafe0a7:	movdqu XMMWORD PTR [r12+0x130],xmm4
    75b0baafe0b1:	mov    r14d,0x420a60
    75b0baafe0b7:	movdqu xmm5,XMMWORD PTR [r14]
    75b0baafe0bc:	movdqu XMMWORD PTR [r12+0x140],xmm5
    75b0baafe0c6:	mov    r14d,0x430000
    75b0baafe0cc:	mov    rax,r14
    75b0baafe0cf:	add    rax,0xcd0
    75b0baafe0d5:	mov    QWORD PTR [r12+0x98],rax
    75b0baafe0dd:	mov    r15d,0x420ad0
    75b0baafe0e3:	movdqu xmm6,XMMWORD PTR [r15]
    75b0baafe0e8:	movdqu XMMWORD PTR [r12+0x150],xmm6
    75b0baafe0f2:	mov    r15,QWORD PTR [r12+0x98]
    75b0baafe0fa:	add    r15,0x10
    75b0baafe0fe:	mov    rdi,QWORD PTR [r12+0x98]
    75b0baafe106:	movdqu XMMWORD PTR [rdi],xmm2
    75b0baafe10a:	movdqu XMMWORD PTR [r15],xmm3
    75b0baafe10f:	mov    r15,QWORD PTR [r12+0x98]
    75b0baafe117:	add    r15,0x20
    75b0baafe11b:	mov    rbp,r15
    75b0baafe11e:	add    rbp,0x10
    75b0baafe122:	movdqu XMMWORD PTR [r15],xmm4
    75b0baafe127:	movdqu XMMWORD PTR [rbp+0x0],xmm5
    75b0baafe12c:	mov    r15d,0x420a20
    75b0baafe132:	movdqu xmm4,XMMWORD PTR [r15]
    75b0baafe137:	movdqu XMMWORD PTR [r12+0x130],xmm4
    75b0baafe141:	mov    r15d,0x420a10
    75b0baafe147:	movdqu xmm5,XMMWORD PTR [r15]
    75b0baafe14c:	movdqu XMMWORD PTR [r12+0x140],xmm5
    75b0baafe156:	mov    r15,QWORD PTR [r12+0x98]
    75b0baafe15e:	add    r15,0x100
    75b0baafe165:	mov    rbp,r15
    75b0baafe168:	add    rbp,0x10
    75b0baafe16c:	movdqu XMMWORD PTR [r15],xmm2
    75b0baafe171:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    75b0baafe176:	mov    r15,QWORD PTR [r12+0x98]
    75b0baafe17e:	add    r15,0x40
    75b0baafe182:	mov    rbp,r15
    75b0baafe185:	add    rbp,0x10
    75b0baafe189:	movdqu XMMWORD PTR [r15],xmm6
    75b0baafe18e:	movdqu XMMWORD PTR [rbp+0x0],xmm4
    75b0baafe193:	mov    r15d,0x420a00
    75b0baafe199:	movdqu xmm2,XMMWORD PTR [r15]
    75b0baafe19e:	movdqu XMMWORD PTR [r12+0x130],xmm2
    75b0baafe1a8:	mov    r15d,0x420a70
    75b0baafe1ae:	movdqu xmm3,XMMWORD PTR [r15]
    75b0baafe1b3:	movdqu XMMWORD PTR [r12+0x150],xmm3
    75b0baafe1bd:	mov    r15d,0xf8d3
    75b0baafe1c3:	mov    QWORD PTR [r12+0x48],r15
    75b0baafe1c8:	mov    r15,QWORD PTR [r12+0x98]
    75b0baafe1d0:	add    r15,0x60
    75b0baafe1d4:	mov    rbp,r15
    75b0baafe1d7:	add    rbp,0x10
    75b0baafe1db:	movdqu XMMWORD PTR [r15],xmm5
    75b0baafe1e0:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    75b0baafe1e5:	mov    r15d,0x420a80
    75b0baafe1eb:	movdqu xmm2,XMMWORD PTR [r15]
    75b0baafe1f0:	movdqu XMMWORD PTR [r12+0x130],xmm2
    75b0baafe1fa:	mov    r15d,0x420a50
    75b0baafe200:	movdqu xmm4,XMMWORD PTR [r15]
    75b0baafe205:	movdqu XMMWORD PTR [r12+0x140],xmm4
    75b0baafe20f:	mov    r15d,0xf8d3
    75b0baafe215:	mov    ebp,0x421d
    75b0baafe21a:	and    ebp,0xffff
    75b0baafe220:	mov    rax,r15
    75b0baafe223:	movabs rcx,0xffffffff0000ffff
    75b0baafe22d:	and    rax,rcx
    75b0baafe230:	mov    rdx,rbp
    75b0baafe233:	shl    rdx,0x10
    75b0baafe237:	mov    ecx,0xffff0000
    75b0baafe23c:	and    rdx,rcx
    75b0baafe23f:	or     rax,rdx
    75b0baafe242:	mov    r8d,eax
    75b0baafe245:	mov    QWORD PTR [r12+0x48],r8
    75b0baafe24a:	mov    r15,QWORD PTR [r12+0x98]
    75b0baafe252:	add    r15,0x80
    75b0baafe259:	mov    rbp,r15
    75b0baafe25c:	add    rbp,0x10
    75b0baafe260:	movdqu XMMWORD PTR [r15],xmm3
    75b0baafe265:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    75b0baafe26a:	mov    r15d,0x420af0
    75b0baafe270:	movdqu xmm2,XMMWORD PTR [r15]
    75b0baafe275:	movdqu XMMWORD PTR [r12+0x130],xmm2
    75b0baafe27f:	mov    r15d,0x420b00
    75b0baafe285:	movdqu xmm3,XMMWORD PTR [r15]
    75b0baafe28a:	movdqu XMMWORD PTR [r12+0x150],xmm3
    75b0baafe294:	mov    r15d,0x3e8
    75b0baafe29a:	mov    QWORD PTR [r12+0xa0],r15
    75b0baafe2a2:	mov    r15,QWORD PTR [r12+0x98]
    75b0baafe2aa:	add    r15,0xa0
    75b0baafe2b1:	mov    rbp,r15
    75b0baafe2b4:	add    rbp,0x10
    75b0baafe2b8:	movdqu XMMWORD PTR [r15],xmm4
    75b0baafe2bd:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    75b0baafe2c2:	mov    r15d,0x420ae0
    75b0baafe2c8:	movdqu xmm2,XMMWORD PTR [r15]
    75b0baafe2cd:	movdqu XMMWORD PTR [r12+0x130],xmm2
    75b0baafe2d7:	mov    r15d,0x420a90
    75b0baafe2dd:	movdqu xmm4,XMMWORD PTR [r15]
    75b0baafe2e2:	movdqu XMMWORD PTR [r12+0x140],xmm4
    75b0baafe2ec:	mov    r15,r13
    75b0baafe2ef:	add    r15,0x180
    75b0baafe2f6:	mov    rbp,r15
    75b0baafe2f9:	add    rbp,0x8
    75b0baafe2fd:	mov    r9,QWORD PTR [r12+0x200]
    75b0baafe305:	mov    r14,QWORD PTR [r12+0x1f0]
    75b0baafe30d:	mov    QWORD PTR [r15],r9
    75b0baafe310:	mov    QWORD PTR [rbp+0x0],r14
    75b0baafe314:	mov    r14,QWORD PTR [r12+0x98]
    75b0baafe31c:	add    r14,0xc0
    75b0baafe323:	mov    r15,r14
    75b0baafe326:	add    r15,0x10
    75b0baafe32a:	movdqu XMMWORD PTR [r14],xmm3
    75b0baafe32f:	movdqu XMMWORD PTR [r15],xmm2
    75b0baafe334:	mov    r14d,0x420ab0
    75b0baafe33a:	movdqu xmm2,XMMWORD PTR [r14]
    75b0baafe33f:	movdqu XMMWORD PTR [r12+0x130],xmm2
    75b0baafe349:	mov    r14d,0x420b18
    75b0baafe34f:	mov    r15,QWORD PTR [r14]
    75b0baafe352:	mov    r14d,0x0
    75b0baafe358:	mov    QWORD PTR [r12+0x110],r15
    75b0baafe360:	mov    QWORD PTR [r12+0x118],r14
    75b0baafe368:	mov    r14d,0x420b20
    75b0baafe36e:	mov    QWORD PTR [r12+0x40],r14
    75b0baafe373:	mov    r14,QWORD PTR [r12+0x98]
    75b0baafe37b:	add    r14,0xe0
    75b0baafe382:	mov    rbp,r14
    75b0baafe385:	add    rbp,0x10
    75b0baafe389:	movdqu XMMWORD PTR [r14],xmm4
    75b0baafe38e:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    75b0baafe393:	mov    r14d,0x420b80
    75b0baafe399:	movdqu xmm2,XMMWORD PTR [r14]
    75b0baafe39e:	movdqu XMMWORD PTR [r12+0x130],xmm2
    75b0baafe3a8:	mov    r14,QWORD PTR [r12+0x98]
    75b0baafe3b0:	add    r14,0x120
    75b0baafe3b7:	mov    QWORD PTR [r14],r15
    75b0baafe3ba:	mov    r14d,0x420b60
    75b0baafe3c0:	mov    r15d,0x420b70
    75b0baafe3c6:	movdqu xmm3,XMMWORD PTR [r14]
    75b0baafe3cb:	movdqu xmm4,XMMWORD PTR [r15]
    75b0baafe3d0:	movdqu XMMWORD PTR [r12+0x120],xmm3
    75b0baafe3da:	movdqu XMMWORD PTR [r12+0x110],xmm4
    75b0baafe3e4:	mov    r14,r13
    75b0baafe3e7:	add    r14,0x160
    75b0baafe3ee:	movdqu XMMWORD PTR [r14],xmm2
    75b0baafe3f3:	mov    r14,r13
    75b0baafe3f6:	add    r14,0x190
    75b0baafe3fd:	mov    r15,r14
    75b0baafe400:	add    r15,0x8
    75b0baafe404:	mov    rbp,QWORD PTR [r12+0x1e0]
    75b0baafe40c:	mov    r9,QWORD PTR [r12+0x1d0]
    75b0baafe414:	mov    QWORD PTR [r14],rbp
    75b0baafe417:	mov    QWORD PTR [r15],r9
    75b0baafe41a:	mov    r14,r13
    75b0baafe41d:	add    r14,0x140
    75b0baafe424:	mov    r15,r14
    75b0baafe427:	add    r15,0x10
    75b0baafe42b:	movdqu XMMWORD PTR [r14],xmm3
    75b0baafe430:	movdqu XMMWORD PTR [r15],xmm4
    75b0baafe435:	mov    r14d,0x420b20
    75b0baafe43b:	mov    r15d,0x420b30
    75b0baafe441:	movdqu xmm2,XMMWORD PTR [r14]
    75b0baafe446:	movdqu xmm3,XMMWORD PTR [r15]
    75b0baafe44b:	movdqu XMMWORD PTR [r12+0x110],xmm2
    75b0baafe455:	movdqu XMMWORD PTR [r12+0x120],xmm3
    75b0baafe45f:	mov    r14,r13
    75b0baafe462:	add    r14,0x1a0
    75b0baafe469:	mov    r15,r14
    75b0baafe46c:	add    r15,0x8
    75b0baafe470:	mov    rbp,QWORD PTR [r12+0x1c0]
    75b0baafe478:	mov    r9,QWORD PTR [r12+0x1b0]
    75b0baafe480:	mov    QWORD PTR [r14],rbp
    75b0baafe483:	mov    QWORD PTR [r15],r9
    75b0baafe486:	mov    r14,r13
    75b0baafe489:	add    r14,0x1b0
    75b0baafe490:	mov    r15,r14
    75b0baafe493:	add    r15,0x8
    75b0baafe497:	mov    rbp,QWORD PTR [r12+0x1a0]
    75b0baafe49f:	mov    r9,QWORD PTR [r12+0x190]
    75b0baafe4a7:	mov    QWORD PTR [r14],rbp
    75b0baafe4aa:	mov    QWORD PTR [r15],r9
    75b0baafe4ad:	mov    r14,r13
    75b0baafe4b0:	add    r14,0x100
    75b0baafe4b7:	mov    r15,r14
    75b0baafe4ba:	add    r15,0x10
    75b0baafe4be:	movdqu XMMWORD PTR [r14],xmm2
    75b0baafe4c3:	movdqu XMMWORD PTR [r15],xmm3
    75b0baafe4c8:	mov    r14d,0x420b40
    75b0baafe4ce:	mov    r15d,0x420b50
    75b0baafe4d4:	movdqu xmm2,XMMWORD PTR [r14]
    75b0baafe4d9:	movdqu xmm3,XMMWORD PTR [r15]
    75b0baafe4de:	movdqu XMMWORD PTR [r12+0x110],xmm2
    75b0baafe4e8:	movdqu XMMWORD PTR [r12+0x130],xmm3
    75b0baafe4f2:	mov    r14,r13
    75b0baafe4f5:	add    r14,0x1c0
    75b0baafe4fc:	mov    r15,r14
    75b0baafe4ff:	add    r15,0x8
    75b0baafe503:	mov    rbp,QWORD PTR [r12+0xe8]
    75b0baafe50b:	mov    r9,QWORD PTR [r12+0xf0]
    75b0baafe513:	mov    QWORD PTR [r14],rbp
    75b0baafe516:	mov    QWORD PTR [r15],r9
    75b0baafe519:	mov    r14,QWORD PTR [r12+0x98]
    75b0baafe521:	add    r14,0x128
    75b0baafe528:	mov    DWORD PTR [r14],r8d
    75b0baafe52b:	mov    r14,r13
    75b0baafe52e:	add    r14,0x120
    75b0baafe535:	mov    r15,r14
    75b0baafe538:	add    r15,0x10
    75b0baafe53c:	movdqu XMMWORD PTR [r14],xmm2
    75b0baafe541:	movdqu XMMWORD PTR [r15],xmm3
    75b0baafe546:	add    r13,0x100
    75b0baafe54d:	mov    QWORD PTR [r12],r13
    75b0baafe551:	mov    r13d,0x0
    75b0baafe557:	mov    rcx,QWORD PTR [r12+0x98]
    75b0baafe55f:	or     r13,rcx
    75b0baafe562:	mov    QWORD PTR [r12+0x8],r13
    75b0baafe567:	mov    r13d,0x12c
    75b0baafe56d:	mov    QWORD PTR [r12+0x10],r13
    75b0baafe572:	mov    r13d,0x410284
    75b0baafe578:	mov    QWORD PTR [r12+0xf0],r13
    75b0baafe580:	mov    r13d,0x410728
    75b0baafe586:	mov    QWORD PTR [r12+0x100],r13
    75b0baafe58e:	mov    r11,QWORD PTR [rsp]
    75b0baafe592:	mov    QWORD PTR [r12+0x398],r11
    75b0baafe59a:	mov    edi,0x410728
    75b0baafe59f:	mov    QWORD PTR [r12+0x100],rdi
    75b0baafe5a7:	add    rsp,0x10
    75b0baafe5ab:	nop    DWORD PTR [rax+rax*1+0x0]
    75b0baafe5b0:	jmp    QWORD PTR [rip+0x2]        # 0x75b0baafe5b8
    75b0baafe5b6:	xchg   ax,ax
    75b0baafe5b8:	loopne 0x75b0baafe59f
    75b0baafe5ba:	scas   eax,DWORD PTR es:[rdi]
    75b0baafe5bb:	mov    edx,0x75b0
    75b0baafe5c0:	enter  0xafe5,0xba
    75b0baafe5c4:	mov    al,0x75
    75b0baafe5c6:	add    BYTE PTR [rax],al
    75b0baafe5c8:	movabs r11,0x59d8f50c0940
    75b0baafe5d2:	jmp    r11
    75b0baafe5d5:	nop
    75b0baafe5d6:	nop
    75b0baafe5d7:	nop
