
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/2/6.bin:     file format binary


Disassembly of section .data:

00007f716ee00740 <.data>:
    7f716ee00740:	sub    rsp,0x10
    7f716ee00744:	mov    r11,QWORD PTR [r12+0x398]
    7f716ee0074c:	mov    QWORD PTR [rsp],r11
    7f716ee00750:	mov    r13d,DWORD PTR [r12]
    7f716ee00754:	mov    r14d,r13d
    7f716ee00757:	mov    r14d,r14d
    7f716ee0075a:	shr    r14d,0x10
    7f716ee0075e:	xor    r13d,r14d
    7f716ee00761:	mov    QWORD PTR [r12+0x40],r13
    7f716ee00766:	mov    r14d,0x352d
    7f716ee0076c:	mov    QWORD PTR [r12+0x48],r14
    7f716ee00771:	mov    r14d,0x352d
    7f716ee00777:	mov    r15d,0x7feb
    7f716ee0077d:	and    r15d,0xffff
    7f716ee00784:	mov    rax,r14
    7f716ee00787:	movabs rcx,0xffffffff0000ffff
    7f716ee00791:	and    rax,rcx
    7f716ee00794:	mov    rdx,r15
    7f716ee00797:	shl    rdx,0x10
    7f716ee0079b:	mov    ecx,0xffff0000
    7f716ee007a0:	and    rdx,rcx
    7f716ee007a3:	or     rax,rdx
    7f716ee007a6:	mov    ebp,eax
    7f716ee007a8:	mov    QWORD PTR [r12+0x48],rbp
    7f716ee007ad:	mov    r14d,0x0
    7f716ee007b3:	imul   r13d,ebp
    7f716ee007b7:	mov    r15d,r14d
    7f716ee007ba:	add    r15d,r13d
    7f716ee007bd:	mov    QWORD PTR [r12+0x40],r15
    7f716ee007c2:	mov    r13d,0xa68b
    7f716ee007c8:	mov    QWORD PTR [r12+0x48],r13
    7f716ee007cd:	mov    r13d,0xa68b
    7f716ee007d3:	mov    r14d,0x846c
    7f716ee007d9:	and    r14d,0xffff
    7f716ee007e0:	mov    rax,r13
    7f716ee007e3:	movabs rcx,0xffffffff0000ffff
    7f716ee007ed:	and    rax,rcx
    7f716ee007f0:	mov    rdx,r14
    7f716ee007f3:	shl    rdx,0x10
    7f716ee007f7:	mov    ecx,0xffff0000
    7f716ee007fc:	and    rdx,rcx
    7f716ee007ff:	or     rax,rdx
    7f716ee00802:	mov    ebp,eax
    7f716ee00804:	mov    QWORD PTR [r12+0x48],rbp
    7f716ee00809:	mov    r13d,r15d
    7f716ee0080c:	mov    r13d,r13d
    7f716ee0080f:	shr    r13d,0xf
    7f716ee00813:	xor    r15d,r13d
    7f716ee00816:	mov    QWORD PTR [r12+0x40],r15
    7f716ee0081b:	mov    r13d,0x0
    7f716ee00821:	imul   r15d,ebp
    7f716ee00825:	mov    r14d,r13d
    7f716ee00828:	add    r14d,r15d
    7f716ee0082b:	mov    QWORD PTR [r12+0x40],r14
    7f716ee00830:	mov    r13d,r14d
    7f716ee00833:	mov    r13d,r13d
    7f716ee00836:	shr    r13d,0x10
    7f716ee0083a:	xor    r14d,r13d
    7f716ee0083d:	mov    QWORD PTR [r12],r14
    7f716ee00841:	mov    rcx,QWORD PTR [r12+0x380]
    7f716ee00849:	jrcxz  0x7f716ee00850
    7f716ee0084b:	jmp    0x7f716ee00885
    7f716ee00850:	mov    r13,QWORD PTR [r12+0xf0]
    7f716ee00858:	mov    QWORD PTR [r12+0x100],r13
    7f716ee00860:	mov    r11,QWORD PTR [rsp]
    7f716ee00864:	mov    QWORD PTR [r12+0x398],r11
    7f716ee0086c:	mov    rdi,QWORD PTR [r12+0x100]
    7f716ee00874:	add    rsp,0x10
    7f716ee00878:	movabs r11,0x5fdfb8bf7940
    7f716ee00882:	jmp    r11
    7f716ee00885:	mov    eax,0x4109c8
    7f716ee0088a:	mov    QWORD PTR [r12+0x100],rax
    7f716ee00892:	push   rdx
    7f716ee00893:	push   rsi
    7f716ee00894:	push   r10
    7f716ee00896:	push   r11
    7f716ee00898:	mov    rdx,QWORD PTR [rsp+0x20]
    7f716ee0089d:	mov    r10d,edx
    7f716ee008a0:	and    r10d,0xc000
    7f716ee008a7:	shl    r10d,0x10
    7f716ee008ab:	mov    r11d,edx
    7f716ee008ae:	and    r11d,0x100
    7f716ee008b5:	shl    r11d,0x15
    7f716ee008b9:	or     r10d,r11d
    7f716ee008bc:	and    edx,0x1
    7f716ee008bf:	shl    edx,0x1c
    7f716ee008c2:	or     r10d,edx
    7f716ee008c5:	btc    r10,0x1d
    7f716ee008ca:	mov    r11d,0xf0000000
    7f716ee008d0:	and    r11,r10
    7f716ee008d3:	movabs rsi,0xffffffff0fffffff
    7f716ee008dd:	and    rbx,rsi
    7f716ee008e0:	or     rbx,r11
    7f716ee008e3:	pop    r11
    7f716ee008e5:	pop    r10
    7f716ee008e7:	pop    rsi
    7f716ee008e8:	pop    rdx
    7f716ee008e9:	mov    QWORD PTR [r12+0x108],rbx
    7f716ee008f1:	add    rsp,0x10
    7f716ee008f5:	mov    eax,0xc
    7f716ee008fa:	movabs r11,0x5fdfb8bf7ca0
    7f716ee00904:	jmp    r11
    7f716ee00907:	nop
