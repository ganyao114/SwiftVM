
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/0/4.bin:     file format binary


Disassembly of section .data:

000074a37e501080 <.data>:
    74a37e501080:	sub    rsp,0x10
    74a37e501084:	mov    r11,QWORD PTR [r12+0x398]
    74a37e50108c:	mov    QWORD PTR [rsp],r11
    74a37e501090:	mov    r13,QWORD PTR [r12+0xf8]
    74a37e501098:	add    r13,0x168
    74a37e50109f:	mov    r14,QWORD PTR [r13+0x0]
    74a37e5010a3:	mov    QWORD PTR [r12+0x40],r14
    74a37e5010a8:	sub    r14,0x38
    74a37e5010ac:	mov    rcx,QWORD PTR [r12+0x380]
    74a37e5010b4:	jrcxz  0x74a37e5010bb
    74a37e5010b6:	jmp    0x74a37e50118d
    74a37e5010bb:	jne    0x74a37e5010d4
    74a37e5010c1:	mov    r11,rax
    74a37e5010c4:	lahf
    74a37e5010c5:	seto   al
    74a37e5010c8:	mov    WORD PTR [rsp],ax
    74a37e5010cc:	mov    rax,r11
    74a37e5010cf:	jmp    0x74a37e5010e7
    74a37e5010d4:	mov    r11,rax
    74a37e5010d7:	lahf
    74a37e5010d8:	seto   al
    74a37e5010db:	mov    WORD PTR [rsp],ax
    74a37e5010df:	mov    rax,r11
    74a37e5010e2:	jmp    0x74a37e50113d
    74a37e5010e7:	mov    r13d,0x4102d4
    74a37e5010ed:	mov    QWORD PTR [r12+0x100],r13
    74a37e5010f5:	mov    r11,QWORD PTR [rsp]
    74a37e5010f9:	mov    QWORD PTR [r12+0x398],r11
    74a37e501101:	mov    edi,0x4102d4
    74a37e501106:	mov    QWORD PTR [r12+0x100],rdi
    74a37e50110e:	add    rsp,0x10
    74a37e501112:	nop    WORD PTR [rax+rax*1+0x0]
    74a37e501118:	jmp    QWORD PTR [rip+0x2]        # 0x74a37e501120
    74a37e50111e:	xchg   ax,ax
    74a37e501120:	(bad)
    74a37e501121:	adc    BYTE PTR [rax+0x7e],dl
    74a37e501124:	movabs ds:0xa37e501130000074,eax
    74a37e50112d:	je     0x74a37e50112f
    74a37e50112f:	add    BYTE PTR [rcx-0x45],cl
    74a37e501132:	rex cdq
    74a37e501134:	outs   dx,BYTE PTR ds:[rsi]
    74a37e501135:	rex.RX adc eax,0x41000057
    74a37e50113b:	jmp    rbx
    74a37e50113d:	mov    r13d,0x4102b8
    74a37e501143:	mov    QWORD PTR [r12+0x100],r13
    74a37e50114b:	mov    r11,QWORD PTR [rsp]
    74a37e50114f:	mov    QWORD PTR [r12+0x398],r11
    74a37e501157:	mov    edi,0x4102b8
    74a37e50115c:	mov    QWORD PTR [r12+0x100],rdi
    74a37e501164:	add    rsp,0x10
    74a37e501168:	jmp    QWORD PTR [rip+0x2]        # 0x74a37e501170
    74a37e50116e:	xchg   ax,ax
    74a37e501170:	rex adc BYTE PTR [rax+0x7e],dl
    74a37e501174:	movabs ds:0xa37e501180000074,eax
    74a37e50117d:	je     0x74a37e50117f
    74a37e50117f:	add    BYTE PTR [rcx-0x45],cl
    74a37e501182:	rex cdq
    74a37e501184:	outs   dx,BYTE PTR ds:[rsi]
    74a37e501185:	rex.RX adc eax,0x41000057
    74a37e50118b:	jmp    rbx
    74a37e50118d:	mov    eax,0x4102d0
    74a37e501192:	mov    QWORD PTR [r12+0x100],rax
    74a37e50119a:	push   rdx
    74a37e50119b:	push   rsi
    74a37e50119c:	push   r10
    74a37e50119e:	push   r11
    74a37e5011a0:	mov    r11,rax
    74a37e5011a3:	lahf
    74a37e5011a4:	seto   al
    74a37e5011a7:	mov    WORD PTR [rsp+0x20],ax
    74a37e5011ac:	mov    rax,r11
    74a37e5011af:	mov    rdx,QWORD PTR [rsp+0x20]
    74a37e5011b4:	mov    r10d,edx
    74a37e5011b7:	and    r10d,0xc000
    74a37e5011be:	shl    r10d,0x10
    74a37e5011c2:	mov    r11d,edx
    74a37e5011c5:	and    r11d,0x100
    74a37e5011cc:	shl    r11d,0x15
    74a37e5011d0:	or     r10d,r11d
    74a37e5011d3:	and    edx,0x1
    74a37e5011d6:	shl    edx,0x1c
    74a37e5011d9:	or     r10d,edx
    74a37e5011dc:	btc    r10,0x1d
    74a37e5011e1:	mov    r11d,0xf0000000
    74a37e5011e7:	and    r11,r10
    74a37e5011ea:	movabs rsi,0xffffffff0fffffff
    74a37e5011f4:	and    rbx,rsi
    74a37e5011f7:	or     rbx,r11
    74a37e5011fa:	pop    r11
    74a37e5011fc:	pop    r10
    74a37e5011fe:	pop    rsi
    74a37e5011ff:	pop    rdx
    74a37e501200:	mov    QWORD PTR [r12+0x108],rbx
    74a37e501208:	add    rsp,0x10
    74a37e50120c:	mov    eax,0xc
    74a37e501211:	movabs r11,0x5715466e9ca0
    74a37e50121b:	jmp    r11
    74a37e50121e:	nop
    74a37e50121f:	nop
