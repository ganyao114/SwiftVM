
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/1/1.bin:     file format binary


Disassembly of section .data:

000075b0baafe5e0 <.data>:
    75b0baafe5e0:	sub    rsp,0xc0
    75b0baafe5e7:	mov    r11,QWORD PTR [r12+0x398]
    75b0baafe5ef:	mov    QWORD PTR [rsp+0xb0],r11
    75b0baafe5f7:	mov    r13,QWORD PTR [r12]
    75b0baafe5fb:	mov    r14,r13
    75b0baafe5fe:	add    r14,0x20
    75b0baafe602:	mov    r15,QWORD PTR [r14]
    75b0baafe605:	mov    r14,QWORD PTR [r12+0x10]
    75b0baafe60a:	add    r15,r14
    75b0baafe60d:	mov    QWORD PTR [r12+0x40],r15
    75b0baafe612:	add    r13,0x20
    75b0baafe616:	mov    QWORD PTR [r13+0x0],r15
    75b0baafe61a:	mov    r13d,0x0
    75b0baafe620:	mov    DWORD PTR [r12+0x32c],r13d
    75b0baafe628:	mov    rax,r14
    75b0baafe62b:	test   rax,rax
    75b0baafe62e:	je     0x75b0bab00735
    75b0baafe634:	jmp    0x75b0baafe639
    75b0baafe639:	mov    r13,QWORD PTR [r12+0xf8]
    75b0baafe641:	sub    r13,0x150
    75b0baafe648:	mov    QWORD PTR [r12+0xf8],r13
    75b0baafe650:	mov    r14,QWORD PTR [r12]
    75b0baafe654:	mov    r15,r14
    75b0baafe657:	add    r15,0x68
    75b0baafe65b:	mov    rbp,QWORD PTR [r15]
    75b0baafe65e:	mov    QWORD PTR [r12+0x88],rbp
    75b0baafe666:	add    r14,0x28
    75b0baafe66a:	mov    QWORD PTR [r12+0x40],r14
    75b0baafe66f:	mov    QWORD PTR [r12+0x48],r13
    75b0baafe674:	mov    r14d,0x420000
    75b0baafe67a:	add    r14,0xb90
    75b0baafe681:	mov    QWORD PTR [r12+0x50],r14
    75b0baafe686:	mov    r14,r13
    75b0baafe689:	add    r14,0x100
    75b0baafe690:	mov    r15,r14
    75b0baafe693:	add    r15,0x8
    75b0baafe697:	mov    rbp,QWORD PTR [r12+0xe8]
    75b0baafe69f:	mov    r8,QWORD PTR [r12+0xd8]
    75b0baafe6a7:	mov    QWORD PTR [r14],rbp
    75b0baafe6aa:	mov    r14d,0x0
    75b0baafe6b0:	mov    DWORD PTR [r12+0x32c],r14d
    75b0baafe6b8:	mov    QWORD PTR [r15],r8
    75b0baafe6bb:	mov    r14,r13
    75b0baafe6be:	add    r14,0x110
    75b0baafe6c5:	mov    r15,r14
    75b0baafe6c8:	add    r15,0x8
    75b0baafe6cc:	mov    rbp,QWORD PTR [r12+0xd0]
    75b0baafe6d4:	mov    r8,QWORD PTR [r12+0xc8]
    75b0baafe6dc:	mov    QWORD PTR [r14],rbp
    75b0baafe6df:	mov    QWORD PTR [r15],r8
    75b0baafe6e2:	mov    r14,r13
    75b0baafe6e5:	add    r14,0x120
    75b0baafe6ec:	mov    r15,r14
    75b0baafe6ef:	add    r15,0x8
    75b0baafe6f3:	mov    rbp,QWORD PTR [r12+0xc0]
    75b0baafe6fb:	mov    r8,QWORD PTR [r12+0xb8]
    75b0baafe703:	mov    QWORD PTR [r14],rbp
    75b0baafe706:	mov    QWORD PTR [r15],r8
    75b0baafe709:	mov    r14,r13
    75b0baafe70c:	add    r14,0x130
    75b0baafe713:	mov    r15,r14
    75b0baafe716:	add    r15,0x8
    75b0baafe71a:	mov    rbp,QWORD PTR [r12+0xb0]
    75b0baafe722:	mov    r8,QWORD PTR [r12+0xa8]
    75b0baafe72a:	mov    QWORD PTR [r14],rbp
    75b0baafe72d:	mov    QWORD PTR [r15],r8
    75b0baafe730:	add    r13,0x140
    75b0baafe737:	mov    r14,r13
    75b0baafe73a:	add    r14,0x8
    75b0baafe73e:	mov    r15,QWORD PTR [r12+0xa0]
    75b0baafe746:	mov    rbp,QWORD PTR [r12+0x98]
    75b0baafe74e:	mov    QWORD PTR [r13+0x0],r15
    75b0baafe752:	mov    QWORD PTR [r14],rbp
    75b0baafe755:	jmp    0x75b0baafe75a
    75b0baafe75a:	mov    r13,QWORD PTR [r12+0x8]
    75b0baafe75f:	mov    r14,r13
    75b0baafe762:	add    r14,0x1
    75b0baafe766:	movzx  r15d,BYTE PTR [r13+0x0]
    75b0baafe76b:	mov    QWORD PTR [r12+0x58],r15
    75b0baafe770:	mov    QWORD PTR [r12+0x8],r14
    75b0baafe775:	mov    r13,QWORD PTR [r12+0x88]
    75b0baafe77d:	mov    r14,r13
    75b0baafe780:	add    r14,0x1
    75b0baafe784:	mov    QWORD PTR [r12+0x60],r14
    75b0baafe789:	mov    r15,QWORD PTR [r12]
    75b0baafe78d:	mov    rbp,r15
    75b0baafe790:	add    rbp,0x68
    75b0baafe794:	mov    QWORD PTR [rbp+0x0],r14
    75b0baafe798:	mov    r14d,0x0
    75b0baafe79e:	mov    DWORD PTR [r12+0x32c],r14d
    75b0baafe7a6:	mov    r14,r15
    75b0baafe7a9:	add    r14,r13
    75b0baafe7ac:	mov    QWORD PTR [r12+0x60],r14
    75b0baafe7b1:	add    r14,0x28
    75b0baafe7b5:	movzx  r13d,BYTE PTR [r12+0x58]
    75b0baafe7bb:	mov    BYTE PTR [r14],r13b
    75b0baafe7be:	add    r15,0x68
    75b0baafe7c2:	mov    r13,QWORD PTR [r15]
    75b0baafe7c5:	mov    QWORD PTR [r12+0x88],r13
    75b0baafe7cd:	sub    r13,0x40
    75b0baafe7d1:	mov    rcx,QWORD PTR [r12+0x380]
    75b0baafe7d9:	jrcxz  0x75b0baafe7e0
    75b0baafe7db:	jmp    0x75b0bab00780
    75b0baafe7e0:	jne    0x75b0baafe7fd
    75b0baafe7e6:	mov    r11,rax
    75b0baafe7e9:	lahf
    75b0baafe7ea:	seto   al
    75b0baafe7ed:	mov    WORD PTR [rsp+0xb0],ax
    75b0baafe7f5:	mov    rax,r11
    75b0baafe7f8:	jmp    0x75b0baafe814
    75b0baafe7fd:	mov    r11,rax
    75b0baafe800:	lahf
    75b0baafe801:	seto   al
    75b0baafe804:	mov    WORD PTR [rsp+0xb0],ax
    75b0baafe80c:	mov    rax,r11
    75b0baafe80f:	jmp    0x75b0bab00637
    75b0baafe814:	mov    rax,QWORD PTR [r12+0x40]
    75b0baafe819:	mov    eax,0x0
    75b0baafe81e:	mov    QWORD PTR [rsp+0x18],rax
    75b0baafe823:	mov    eax,0x0
    75b0baafe828:	mov    QWORD PTR [rsp+0x10],rax
    75b0baafe82d:	mov    eax,0x0
    75b0baafe832:	mov    QWORD PTR [rsp+0x8],rax
    75b0baafe837:	mov    eax,0x0
    75b0baafe83c:	mov    QWORD PTR [rsp],rax
    75b0baafe840:	mov    rdi,QWORD PTR [r12+0x40]
    75b0baafe845:	movzx  r9d,BYTE PTR [rdi]
    75b0baafe849:	mov    r13,QWORD PTR [rsp+0x18]
    75b0baafe84e:	or     r13,r9
    75b0baafe851:	mov    r9,QWORD PTR [r12+0x40]
    75b0baafe856:	add    r9,0x1
    75b0baafe85a:	movzx  r8d,BYTE PTR [r9]
    75b0baafe85e:	mov    r9,QWORD PTR [rsp+0x10]
    75b0baafe863:	or     r9,r8
    75b0baafe866:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafe86b:	add    r8,0x2
    75b0baafe86f:	movzx  ebp,BYTE PTR [r8]
    75b0baafe873:	mov    r8,QWORD PTR [rsp+0x8]
    75b0baafe878:	or     r8,rbp
    75b0baafe87b:	mov    rbp,QWORD PTR [r12+0x40]
    75b0baafe880:	add    rbp,0x3
    75b0baafe884:	movzx  r15d,BYTE PTR [rbp+0x0]
    75b0baafe889:	mov    rbp,QWORD PTR [rsp]
    75b0baafe88d:	or     rbp,r15
    75b0baafe890:	mov    r15,QWORD PTR [r12+0x40]
    75b0baafe895:	add    r15,0x4
    75b0baafe899:	movzx  r14d,BYTE PTR [r15]
    75b0baafe89d:	mov    r15,r14
    75b0baafe8a0:	shl    r15,0x8
    75b0baafe8a4:	or     r13,r15
    75b0baafe8a7:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafe8ac:	add    r14,0x5
    75b0baafe8b0:	movzx  r15d,BYTE PTR [r14]
    75b0baafe8b4:	mov    r14,r15
    75b0baafe8b7:	shl    r14,0x8
    75b0baafe8bb:	or     r9,r14
    75b0baafe8be:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafe8c3:	add    r14,0x6
    75b0baafe8c7:	movzx  r15d,BYTE PTR [r14]
    75b0baafe8cb:	mov    r14,r15
    75b0baafe8ce:	shl    r14,0x8
    75b0baafe8d2:	or     r8,r14
    75b0baafe8d5:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafe8da:	add    r14,0x7
    75b0baafe8de:	movzx  r15d,BYTE PTR [r14]
    75b0baafe8e2:	mov    r14,r15
    75b0baafe8e5:	shl    r14,0x8
    75b0baafe8e9:	or     rbp,r14
    75b0baafe8ec:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafe8f1:	add    r14,0x8
    75b0baafe8f5:	movzx  r15d,BYTE PTR [r14]
    75b0baafe8f9:	mov    r14,r15
    75b0baafe8fc:	shl    r14,0x10
    75b0baafe900:	or     r13,r14
    75b0baafe903:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafe908:	add    r14,0x9
    75b0baafe90c:	movzx  r15d,BYTE PTR [r14]
    75b0baafe910:	mov    r14,r15
    75b0baafe913:	shl    r14,0x10
    75b0baafe917:	or     r9,r14
    75b0baafe91a:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafe91f:	add    r14,0xa
    75b0baafe923:	movzx  r15d,BYTE PTR [r14]
    75b0baafe927:	mov    r14,r15
    75b0baafe92a:	shl    r14,0x10
    75b0baafe92e:	or     r8,r14
    75b0baafe931:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafe936:	add    r14,0xb
    75b0baafe93a:	movzx  r15d,BYTE PTR [r14]
    75b0baafe93e:	mov    r14,r15
    75b0baafe941:	shl    r14,0x10
    75b0baafe945:	or     rbp,r14
    75b0baafe948:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafe94d:	add    r14,0xc
    75b0baafe951:	movzx  r15d,BYTE PTR [r14]
    75b0baafe955:	mov    r14,r15
    75b0baafe958:	shl    r14,0x18
    75b0baafe95c:	or     r13,r14
    75b0baafe95f:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafe964:	add    r14,0xd
    75b0baafe968:	movzx  r15d,BYTE PTR [r14]
    75b0baafe96c:	mov    r14,r15
    75b0baafe96f:	shl    r14,0x18
    75b0baafe973:	or     r9,r14
    75b0baafe976:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafe97b:	add    r14,0xe
    75b0baafe97f:	movzx  r15d,BYTE PTR [r14]
    75b0baafe983:	mov    r14,r15
    75b0baafe986:	shl    r14,0x18
    75b0baafe98a:	or     r8,r14
    75b0baafe98d:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafe992:	add    r14,0xf
    75b0baafe996:	movzx  r15d,BYTE PTR [r14]
    75b0baafe99a:	mov    r14,r15
    75b0baafe99d:	shl    r14,0x18
    75b0baafe9a1:	or     rbp,r14
    75b0baafe9a4:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafe9a9:	add    r14,0x10
    75b0baafe9ad:	movzx  r15d,BYTE PTR [r14]
    75b0baafe9b1:	mov    r14,r15
    75b0baafe9b4:	shl    r14,0x20
    75b0baafe9b8:	or     r13,r14
    75b0baafe9bb:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafe9c0:	add    r14,0x11
    75b0baafe9c4:	movzx  r15d,BYTE PTR [r14]
    75b0baafe9c8:	mov    r14,r15
    75b0baafe9cb:	shl    r14,0x20
    75b0baafe9cf:	or     r9,r14
    75b0baafe9d2:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafe9d7:	add    r14,0x12
    75b0baafe9db:	movzx  r15d,BYTE PTR [r14]
    75b0baafe9df:	mov    r14,r15
    75b0baafe9e2:	shl    r14,0x20
    75b0baafe9e6:	or     r8,r14
    75b0baafe9e9:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafe9ee:	add    r14,0x13
    75b0baafe9f2:	movzx  r15d,BYTE PTR [r14]
    75b0baafe9f6:	mov    r14,r15
    75b0baafe9f9:	shl    r14,0x20
    75b0baafe9fd:	or     rbp,r14
    75b0baafea00:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafea05:	add    r14,0x14
    75b0baafea09:	movzx  r15d,BYTE PTR [r14]
    75b0baafea0d:	mov    r14,r15
    75b0baafea10:	shl    r14,0x28
    75b0baafea14:	or     r13,r14
    75b0baafea17:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafea1c:	add    r14,0x15
    75b0baafea20:	movzx  r15d,BYTE PTR [r14]
    75b0baafea24:	mov    r14,r15
    75b0baafea27:	shl    r14,0x28
    75b0baafea2b:	or     r9,r14
    75b0baafea2e:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafea33:	add    r14,0x16
    75b0baafea37:	movzx  r15d,BYTE PTR [r14]
    75b0baafea3b:	mov    r14,r15
    75b0baafea3e:	shl    r14,0x28
    75b0baafea42:	or     r8,r14
    75b0baafea45:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafea4a:	add    r14,0x17
    75b0baafea4e:	movzx  r15d,BYTE PTR [r14]
    75b0baafea52:	mov    r14,r15
    75b0baafea55:	shl    r14,0x28
    75b0baafea59:	or     rbp,r14
    75b0baafea5c:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafea61:	add    r14,0x18
    75b0baafea65:	movzx  r15d,BYTE PTR [r14]
    75b0baafea69:	mov    r14,r15
    75b0baafea6c:	shl    r14,0x30
    75b0baafea70:	or     r13,r14
    75b0baafea73:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafea78:	add    r14,0x19
    75b0baafea7c:	movzx  r15d,BYTE PTR [r14]
    75b0baafea80:	mov    r14,r15
    75b0baafea83:	shl    r14,0x30
    75b0baafea87:	or     r9,r14
    75b0baafea8a:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafea8f:	add    r14,0x1a
    75b0baafea93:	movzx  r15d,BYTE PTR [r14]
    75b0baafea97:	mov    r14,r15
    75b0baafea9a:	shl    r14,0x30
    75b0baafea9e:	or     r8,r14
    75b0baafeaa1:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafeaa6:	add    r14,0x1b
    75b0baafeaaa:	movzx  r15d,BYTE PTR [r14]
    75b0baafeaae:	mov    r14,r15
    75b0baafeab1:	shl    r14,0x30
    75b0baafeab5:	or     rbp,r14
    75b0baafeab8:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafeabd:	add    r14,0x1c
    75b0baafeac1:	movzx  r15d,BYTE PTR [r14]
    75b0baafeac5:	mov    r14,r15
    75b0baafeac8:	shl    r14,0x38
    75b0baafeacc:	mov    rax,r13
    75b0baafeacf:	or     rax,r14
    75b0baafead2:	mov    QWORD PTR [rsp+0x28],rax
    75b0baafead7:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafeadc:	add    r14,0x1d
    75b0baafeae0:	movzx  r15d,BYTE PTR [r14]
    75b0baafeae4:	mov    r14,r15
    75b0baafeae7:	shl    r14,0x38
    75b0baafeaeb:	mov    rax,r9
    75b0baafeaee:	or     rax,r14
    75b0baafeaf1:	mov    QWORD PTR [rsp+0x38],rax
    75b0baafeaf6:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafeafb:	add    r14,0x1e
    75b0baafeaff:	movzx  r15d,BYTE PTR [r14]
    75b0baafeb03:	mov    r14,r15
    75b0baafeb06:	shl    r14,0x38
    75b0baafeb0a:	mov    rax,r8
    75b0baafeb0d:	or     rax,r14
    75b0baafeb10:	mov    QWORD PTR [rsp+0x30],rax
    75b0baafeb15:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafeb1a:	add    r14,0x1f
    75b0baafeb1e:	movzx  r15d,BYTE PTR [r14]
    75b0baafeb22:	mov    r14,r15
    75b0baafeb25:	shl    r14,0x38
    75b0baafeb29:	mov    rax,rbp
    75b0baafeb2c:	or     rax,r14
    75b0baafeb2f:	mov    QWORD PTR [rsp+0x20],rax
    75b0baafeb34:	mov    r14,QWORD PTR [r12+0x40]
    75b0baafeb39:	add    r14,0x20
    75b0baafeb3d:	movzx  r15d,BYTE PTR [r14]
    75b0baafeb41:	mov    r14,QWORD PTR [rsp+0x18]
    75b0baafeb46:	or     r14,r15
    75b0baafeb49:	mov    r15,QWORD PTR [r12+0x40]
    75b0baafeb4e:	add    r15,0x21
    75b0baafeb52:	movzx  ebp,BYTE PTR [r15]
    75b0baafeb56:	mov    r15,QWORD PTR [rsp+0x10]
    75b0baafeb5b:	or     r15,rbp
    75b0baafeb5e:	mov    rbp,QWORD PTR [r12+0x40]
    75b0baafeb63:	add    rbp,0x22
    75b0baafeb67:	movzx  r13d,BYTE PTR [rbp+0x0]
    75b0baafeb6c:	mov    rbp,QWORD PTR [rsp+0x8]
    75b0baafeb71:	or     rbp,r13
    75b0baafeb74:	mov    r13,QWORD PTR [r12+0x40]
    75b0baafeb79:	add    r13,0x23
    75b0baafeb7d:	movzx  r8d,BYTE PTR [r13+0x0]
    75b0baafeb82:	mov    r13,QWORD PTR [rsp]
    75b0baafeb86:	or     r13,r8
    75b0baafeb89:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafeb8e:	add    r8,0x24
    75b0baafeb92:	movzx  r9d,BYTE PTR [r8]
    75b0baafeb96:	mov    r8,r9
    75b0baafeb99:	shl    r8,0x8
    75b0baafeb9d:	or     r14,r8
    75b0baafeba0:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafeba5:	add    r8,0x25
    75b0baafeba9:	movzx  r9d,BYTE PTR [r8]
    75b0baafebad:	mov    r8,r9
    75b0baafebb0:	shl    r8,0x8
    75b0baafebb4:	or     r15,r8
    75b0baafebb7:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafebbc:	add    r8,0x26
    75b0baafebc0:	movzx  r9d,BYTE PTR [r8]
    75b0baafebc4:	mov    r8,r9
    75b0baafebc7:	shl    r8,0x8
    75b0baafebcb:	or     rbp,r8
    75b0baafebce:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafebd3:	add    r8,0x27
    75b0baafebd7:	movzx  r9d,BYTE PTR [r8]
    75b0baafebdb:	mov    r8,r9
    75b0baafebde:	shl    r8,0x8
    75b0baafebe2:	or     r13,r8
    75b0baafebe5:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafebea:	add    r8,0x28
    75b0baafebee:	movzx  r9d,BYTE PTR [r8]
    75b0baafebf2:	mov    r8,r9
    75b0baafebf5:	shl    r8,0x10
    75b0baafebf9:	or     r14,r8
    75b0baafebfc:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafec01:	add    r8,0x29
    75b0baafec05:	movzx  r9d,BYTE PTR [r8]
    75b0baafec09:	mov    r8,r9
    75b0baafec0c:	shl    r8,0x10
    75b0baafec10:	or     r15,r8
    75b0baafec13:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafec18:	add    r8,0x2a
    75b0baafec1c:	movzx  r9d,BYTE PTR [r8]
    75b0baafec20:	mov    r8,r9
    75b0baafec23:	shl    r8,0x10
    75b0baafec27:	or     rbp,r8
    75b0baafec2a:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafec2f:	add    r8,0x2b
    75b0baafec33:	movzx  r9d,BYTE PTR [r8]
    75b0baafec37:	mov    r8,r9
    75b0baafec3a:	shl    r8,0x10
    75b0baafec3e:	or     r13,r8
    75b0baafec41:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafec46:	add    r8,0x2c
    75b0baafec4a:	movzx  r9d,BYTE PTR [r8]
    75b0baafec4e:	mov    r8,r9
    75b0baafec51:	shl    r8,0x18
    75b0baafec55:	or     r14,r8
    75b0baafec58:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafec5d:	add    r8,0x2d
    75b0baafec61:	movzx  r9d,BYTE PTR [r8]
    75b0baafec65:	mov    r8,r9
    75b0baafec68:	shl    r8,0x18
    75b0baafec6c:	or     r15,r8
    75b0baafec6f:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafec74:	add    r8,0x2e
    75b0baafec78:	movzx  r9d,BYTE PTR [r8]
    75b0baafec7c:	mov    r8,r9
    75b0baafec7f:	shl    r8,0x18
    75b0baafec83:	or     rbp,r8
    75b0baafec86:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafec8b:	add    r8,0x2f
    75b0baafec8f:	movzx  r9d,BYTE PTR [r8]
    75b0baafec93:	mov    r8,r9
    75b0baafec96:	shl    r8,0x18
    75b0baafec9a:	or     r13,r8
    75b0baafec9d:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafeca2:	add    r8,0x30
    75b0baafeca6:	movzx  r9d,BYTE PTR [r8]
    75b0baafecaa:	mov    r8,r9
    75b0baafecad:	shl    r8,0x20
    75b0baafecb1:	or     r14,r8
    75b0baafecb4:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafecb9:	add    r8,0x31
    75b0baafecbd:	movzx  r9d,BYTE PTR [r8]
    75b0baafecc1:	mov    r8,r9
    75b0baafecc4:	shl    r8,0x20
    75b0baafecc8:	or     r15,r8
    75b0baafeccb:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafecd0:	add    r8,0x32
    75b0baafecd4:	movzx  r9d,BYTE PTR [r8]
    75b0baafecd8:	mov    r8,r9
    75b0baafecdb:	shl    r8,0x20
    75b0baafecdf:	or     rbp,r8
    75b0baafece2:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafece7:	add    r8,0x33
    75b0baafeceb:	movzx  r9d,BYTE PTR [r8]
    75b0baafecef:	mov    r8,r9
    75b0baafecf2:	shl    r8,0x20
    75b0baafecf6:	or     r13,r8
    75b0baafecf9:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafecfe:	add    r8,0x34
    75b0baafed02:	movzx  r9d,BYTE PTR [r8]
    75b0baafed06:	mov    r8,r9
    75b0baafed09:	shl    r8,0x28
    75b0baafed0d:	or     r14,r8
    75b0baafed10:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafed15:	add    r8,0x35
    75b0baafed19:	movzx  r9d,BYTE PTR [r8]
    75b0baafed1d:	mov    r8,r9
    75b0baafed20:	shl    r8,0x28
    75b0baafed24:	or     r15,r8
    75b0baafed27:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafed2c:	add    r8,0x36
    75b0baafed30:	movzx  r9d,BYTE PTR [r8]
    75b0baafed34:	mov    r8,r9
    75b0baafed37:	shl    r8,0x28
    75b0baafed3b:	or     rbp,r8
    75b0baafed3e:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafed43:	add    r8,0x37
    75b0baafed47:	movzx  r9d,BYTE PTR [r8]
    75b0baafed4b:	mov    r8,r9
    75b0baafed4e:	shl    r8,0x28
    75b0baafed52:	or     r13,r8
    75b0baafed55:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafed5a:	add    r8,0x38
    75b0baafed5e:	movzx  r9d,BYTE PTR [r8]
    75b0baafed62:	mov    r8,r9
    75b0baafed65:	shl    r8,0x30
    75b0baafed69:	or     r14,r8
    75b0baafed6c:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafed71:	add    r8,0x39
    75b0baafed75:	movzx  r9d,BYTE PTR [r8]
    75b0baafed79:	mov    r8,r9
    75b0baafed7c:	shl    r8,0x30
    75b0baafed80:	or     r15,r8
    75b0baafed83:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafed88:	add    r8,0x3a
    75b0baafed8c:	movzx  r9d,BYTE PTR [r8]
    75b0baafed90:	mov    r8,r9
    75b0baafed93:	shl    r8,0x30
    75b0baafed97:	or     rbp,r8
    75b0baafed9a:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafed9f:	add    r8,0x3b
    75b0baafeda3:	movzx  r9d,BYTE PTR [r8]
    75b0baafeda7:	mov    r8,r9
    75b0baafedaa:	shl    r8,0x30
    75b0baafedae:	or     r13,r8
    75b0baafedb1:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafedb6:	add    r8,0x3c
    75b0baafedba:	movzx  r9d,BYTE PTR [r8]
    75b0baafedbe:	mov    r8,r9
    75b0baafedc1:	shl    r8,0x38
    75b0baafedc5:	or     r14,r8
    75b0baafedc8:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafedcd:	add    r8,0x3d
    75b0baafedd1:	movzx  r9d,BYTE PTR [r8]
    75b0baafedd5:	mov    r8,r9
    75b0baafedd8:	shl    r8,0x38
    75b0baafeddc:	or     r15,r8
    75b0baafeddf:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafede4:	add    r8,0x3e
    75b0baafede8:	movzx  r9d,BYTE PTR [r8]
    75b0baafedec:	mov    r8,r9
    75b0baafedef:	shl    r8,0x38
    75b0baafedf3:	or     rbp,r8
    75b0baafedf6:	mov    r8,QWORD PTR [r12+0x40]
    75b0baafedfb:	add    r8,0x3f
    75b0baafedff:	movzx  r9d,BYTE PTR [r8]
    75b0baafee03:	mov    r8,r9
    75b0baafee06:	shl    r8,0x38
    75b0baafee0a:	mov    rax,r13
    75b0baafee0d:	or     rax,r8
    75b0baafee10:	mov    QWORD PTR [rsp+0x40],rax
    75b0baafee15:	mov    r8d,0x0
    75b0baafee1b:	mov    QWORD PTR [r12+0x58],r8
    75b0baafee20:	mov    r8d,0x0
    75b0baafee26:	mov    r9,QWORD PTR [rsp+0x38]
    75b0baafee2b:	and    r9,0xff
    75b0baafee32:	and    r9,0xffff
    75b0baafee39:	mov    r13,r8
    75b0baafee3c:	or     r13,r9
    75b0baafee3f:	mov    r9,QWORD PTR [rsp+0x38]
    75b0baafee44:	shr    r9,0x8
    75b0baafee48:	and    r9,0xff
    75b0baafee4f:	and    r9,0xffff
    75b0baafee56:	shl    r9,0x10
    75b0baafee5a:	or     r13,r9
    75b0baafee5d:	mov    r9,QWORD PTR [rsp+0x38]
    75b0baafee62:	shr    r9,0x10
    75b0baafee66:	and    r9,0xff
    75b0baafee6d:	and    r9,0xffff
    75b0baafee74:	shl    r9,0x20
    75b0baafee78:	or     r13,r9
    75b0baafee7b:	mov    r9,QWORD PTR [rsp+0x38]
    75b0baafee80:	shr    r9,0x18
    75b0baafee84:	and    r9,0xff
    75b0baafee8b:	and    r9,0xffff
    75b0baafee92:	shl    r9,0x30
    75b0baafee96:	or     r13,r9
    75b0baafee99:	mov    r9,QWORD PTR [rsp+0x38]
    75b0baafee9e:	shr    r9,0x20
    75b0baafeea2:	and    r9,0xff
    75b0baafeea9:	and    r9,0xffff
    75b0baafeeb0:	or     r8,r9
    75b0baafeeb3:	mov    r9,QWORD PTR [rsp+0x38]
    75b0baafeeb8:	shr    r9,0x28
    75b0baafeebc:	and    r9,0xff
    75b0baafeec3:	and    r9,0xffff
    75b0baafeeca:	shl    r9,0x10
    75b0baafeece:	or     r8,r9
    75b0baafeed1:	mov    r9,QWORD PTR [rsp+0x38]
    75b0baafeed6:	shr    r9,0x30
    75b0baafeeda:	and    r9,0xff
    75b0baafeee1:	and    r9,0xffff
    75b0baafeee8:	shl    r9,0x20
    75b0baafeeec:	or     r8,r9
    75b0baafeeef:	mov    r9,QWORD PTR [rsp+0x38]
    75b0baafeef4:	shr    r9,0x38
    75b0baafeef8:	and    r9,0xff
    75b0baafeeff:	and    r9,0xffff
    75b0baafef06:	shl    r9,0x30
    75b0baafef0a:	or     r8,r9
    75b0baafef0d:	mov    QWORD PTR [r12+0x150],r13
    75b0baafef15:	mov    QWORD PTR [r12+0x158],r8
    75b0baafef1d:	mov    r13d,0x0
    75b0baafef23:	mov    r8,QWORD PTR [rsp+0x30]
    75b0baafef28:	and    r8,0xff
    75b0baafef2f:	and    r8,0xffff
    75b0baafef36:	mov    r9,r13
    75b0baafef39:	or     r9,r8
    75b0baafef3c:	mov    r8,QWORD PTR [rsp+0x30]
    75b0baafef41:	shr    r8,0x8
    75b0baafef45:	and    r8,0xff
    75b0baafef4c:	and    r8,0xffff
    75b0baafef53:	shl    r8,0x10
    75b0baafef57:	or     r9,r8
    75b0baafef5a:	mov    r8,QWORD PTR [rsp+0x30]
    75b0baafef5f:	shr    r8,0x10
    75b0baafef63:	and    r8,0xff
    75b0baafef6a:	and    r8,0xffff
    75b0baafef71:	shl    r8,0x20
    75b0baafef75:	or     r9,r8
    75b0baafef78:	mov    r8,QWORD PTR [rsp+0x30]
    75b0baafef7d:	shr    r8,0x18
    75b0baafef81:	and    r8,0xff
    75b0baafef88:	and    r8,0xffff
    75b0baafef8f:	shl    r8,0x30
    75b0baafef93:	mov    rax,r9
    75b0baafef96:	or     rax,r8
    75b0baafef99:	mov    QWORD PTR [rsp+0x50],rax
    75b0baafef9e:	mov    r8,QWORD PTR [rsp+0x30]
    75b0baafefa3:	shr    r8,0x20
    75b0baafefa7:	and    r8,0xff
    75b0baafefae:	and    r8,0xffff
    75b0baafefb5:	or     r13,r8
    75b0baafefb8:	mov    r8,QWORD PTR [rsp+0x30]
    75b0baafefbd:	shr    r8,0x28
    75b0baafefc1:	and    r8,0xff
    75b0baafefc8:	and    r8,0xffff
    75b0baafefcf:	shl    r8,0x10
    75b0baafefd3:	or     r13,r8
    75b0baafefd6:	mov    r8,QWORD PTR [rsp+0x30]
    75b0baafefdb:	shr    r8,0x30
    75b0baafefdf:	and    r8,0xff
    75b0baafefe6:	and    r8,0xffff
    75b0baafefed:	shl    r8,0x20
    75b0baafeff1:	or     r13,r8
    75b0baafeff4:	mov    r8,QWORD PTR [rsp+0x30]
    75b0baafeff9:	shr    r8,0x38
    75b0baafeffd:	and    r8,0xff
    75b0baaff004:	and    r8,0xffff
    75b0baaff00b:	shl    r8,0x30
    75b0baaff00f:	mov    rax,r13
    75b0baaff012:	or     rax,r8
    75b0baaff015:	mov    QWORD PTR [rsp+0x48],rax
    75b0baaff01a:	mov    r8d,0x0
    75b0baaff020:	mov    r13,QWORD PTR [rsp+0x28]
    75b0baaff025:	and    r13,0xff
    75b0baaff02c:	and    r13,0xffff
    75b0baaff033:	mov    r9,r8
    75b0baaff036:	or     r9,r13
    75b0baaff039:	mov    r13,QWORD PTR [rsp+0x28]
    75b0baaff03e:	shr    r13,0x8
    75b0baaff042:	and    r13,0xff
    75b0baaff049:	and    r13,0xffff
    75b0baaff050:	shl    r13,0x10
    75b0baaff054:	or     r9,r13
    75b0baaff057:	mov    r13,QWORD PTR [rsp+0x28]
    75b0baaff05c:	shr    r13,0x10
    75b0baaff060:	and    r13,0xff
    75b0baaff067:	and    r13,0xffff
    75b0baaff06e:	shl    r13,0x20
    75b0baaff072:	or     r9,r13
    75b0baaff075:	mov    r13,QWORD PTR [rsp+0x28]
    75b0baaff07a:	shr    r13,0x18
    75b0baaff07e:	and    r13,0xff
    75b0baaff085:	and    r13,0xffff
    75b0baaff08c:	shl    r13,0x30
    75b0baaff090:	mov    rax,r9
    75b0baaff093:	or     rax,r13
    75b0baaff096:	mov    QWORD PTR [rsp+0x58],rax
    75b0baaff09b:	mov    r13,QWORD PTR [rsp+0x28]
    75b0baaff0a0:	shr    r13,0x20
    75b0baaff0a4:	and    r13,0xff
    75b0baaff0ab:	and    r13,0xffff
    75b0baaff0b2:	or     r8,r13
    75b0baaff0b5:	mov    r13,QWORD PTR [rsp+0x28]
    75b0baaff0ba:	shr    r13,0x28
    75b0baaff0be:	and    r13,0xff
    75b0baaff0c5:	and    r13,0xffff
    75b0baaff0cc:	shl    r13,0x10
    75b0baaff0d0:	or     r8,r13
    75b0baaff0d3:	mov    r13,QWORD PTR [rsp+0x28]
    75b0baaff0d8:	shr    r13,0x30
    75b0baaff0dc:	and    r13,0xff
    75b0baaff0e3:	and    r13,0xffff
    75b0baaff0ea:	shl    r13,0x20
    75b0baaff0ee:	or     r8,r13
    75b0baaff0f1:	mov    r13,QWORD PTR [rsp+0x28]
    75b0baaff0f6:	shr    r13,0x38
    75b0baaff0fa:	and    r13,0xff
    75b0baaff101:	and    r13,0xffff
    75b0baaff108:	shl    r13,0x30
    75b0baaff10c:	mov    rax,r8
    75b0baaff10f:	or     rax,r13
    75b0baaff112:	mov    QWORD PTR [rsp+0x60],rax
    75b0baaff117:	mov    r13d,0x0
    75b0baaff11d:	mov    r9,r14
    75b0baaff120:	and    r9,0xff
    75b0baaff127:	and    r9,0xffff
    75b0baaff12e:	mov    r8,r13
    75b0baaff131:	or     r8,r9
    75b0baaff134:	mov    r9,r14
    75b0baaff137:	shr    r9,0x8
    75b0baaff13b:	and    r9,0xff
    75b0baaff142:	and    r9,0xffff
    75b0baaff149:	shl    r9,0x10
    75b0baaff14d:	or     r8,r9
    75b0baaff150:	mov    r9,r14
    75b0baaff153:	shr    r9,0x10
    75b0baaff157:	and    r9,0xff
    75b0baaff15e:	and    r9,0xffff
    75b0baaff165:	shl    r9,0x20
    75b0baaff169:	or     r8,r9
    75b0baaff16c:	mov    r9,r14
    75b0baaff16f:	shr    r9,0x18
    75b0baaff173:	and    r9,0xff
    75b0baaff17a:	and    r9,0xffff
    75b0baaff181:	shl    r9,0x30
    75b0baaff185:	mov    rax,r8
    75b0baaff188:	or     rax,r9
    75b0baaff18b:	mov    QWORD PTR [rsp+0x68],rax
    75b0baaff190:	mov    r9,r14
    75b0baaff193:	shr    r9,0x20
    75b0baaff197:	and    r9,0xff
    75b0baaff19e:	and    r9,0xffff
    75b0baaff1a5:	or     r13,r9
    75b0baaff1a8:	mov    r9,r14
    75b0baaff1ab:	shr    r9,0x28
    75b0baaff1af:	and    r9,0xff
    75b0baaff1b6:	and    r9,0xffff
    75b0baaff1bd:	shl    r9,0x10
    75b0baaff1c1:	or     r13,r9
    75b0baaff1c4:	mov    r9,r14
    75b0baaff1c7:	shr    r9,0x30
    75b0baaff1cb:	and    r9,0xff
    75b0baaff1d2:	and    r9,0xffff
    75b0baaff1d9:	shl    r9,0x20
    75b0baaff1dd:	or     r13,r9
    75b0baaff1e0:	shr    r14,0x38
    75b0baaff1e4:	and    r14,0xff
    75b0baaff1eb:	and    r14,0xffff
    75b0baaff1f2:	shl    r14,0x30
    75b0baaff1f6:	or     r13,r14
    75b0baaff1f9:	mov    r14d,0x0
    75b0baaff1ff:	mov    r9,r15
    75b0baaff202:	and    r9,0xff
    75b0baaff209:	and    r9,0xffff
    75b0baaff210:	mov    r8,r14
    75b0baaff213:	or     r8,r9
    75b0baaff216:	mov    r9,r15
    75b0baaff219:	shr    r9,0x8
    75b0baaff21d:	and    r9,0xff
    75b0baaff224:	and    r9,0xffff
    75b0baaff22b:	shl    r9,0x10
    75b0baaff22f:	or     r8,r9
    75b0baaff232:	mov    r9,r15
    75b0baaff235:	shr    r9,0x10
    75b0baaff239:	and    r9,0xff
    75b0baaff240:	and    r9,0xffff
    75b0baaff247:	shl    r9,0x20
    75b0baaff24b:	or     r8,r9
    75b0baaff24e:	mov    r9,r15
    75b0baaff251:	shr    r9,0x18
    75b0baaff255:	and    r9,0xff
    75b0baaff25c:	and    r9,0xffff
    75b0baaff263:	shl    r9,0x30
    75b0baaff267:	or     r8,r9
    75b0baaff26a:	mov    r9,r15
    75b0baaff26d:	shr    r9,0x20
    75b0baaff271:	and    r9,0xff
    75b0baaff278:	and    r9,0xffff
    75b0baaff27f:	or     r14,r9
    75b0baaff282:	mov    r9,r15
    75b0baaff285:	shr    r9,0x28
    75b0baaff289:	and    r9,0xff
    75b0baaff290:	and    r9,0xffff
    75b0baaff297:	shl    r9,0x10
    75b0baaff29b:	or     r14,r9
    75b0baaff29e:	mov    r9,r15
    75b0baaff2a1:	shr    r9,0x30
    75b0baaff2a5:	and    r9,0xff
    75b0baaff2ac:	and    r9,0xffff
    75b0baaff2b3:	shl    r9,0x20
    75b0baaff2b7:	or     r14,r9
    75b0baaff2ba:	shr    r15,0x38
    75b0baaff2be:	and    r15,0xff
    75b0baaff2c5:	and    r15,0xffff
    75b0baaff2cc:	shl    r15,0x30
    75b0baaff2d0:	or     r14,r15
    75b0baaff2d3:	mov    QWORD PTR [r12+0x210],r8
    75b0baaff2db:	mov    QWORD PTR [r12+0x218],r14
    75b0baaff2e3:	mov    r14d,0x0
    75b0baaff2e9:	mov    r15,rbp
    75b0baaff2ec:	and    r15,0xff
    75b0baaff2f3:	and    r15,0xffff
    75b0baaff2fa:	mov    r8,r14
    75b0baaff2fd:	or     r8,r15
    75b0baaff300:	mov    r15,rbp
    75b0baaff303:	shr    r15,0x8
    75b0baaff307:	and    r15,0xff
    75b0baaff30e:	and    r15,0xffff
    75b0baaff315:	shl    r15,0x10
    75b0baaff319:	or     r8,r15
    75b0baaff31c:	mov    r15,rbp
    75b0baaff31f:	shr    r15,0x10
    75b0baaff323:	and    r15,0xff
    75b0baaff32a:	and    r15,0xffff
    75b0baaff331:	shl    r15,0x20
    75b0baaff335:	or     r8,r15
    75b0baaff338:	mov    r15,rbp
    75b0baaff33b:	shr    r15,0x18
    75b0baaff33f:	and    r15,0xff
    75b0baaff346:	and    r15,0xffff
    75b0baaff34d:	shl    r15,0x30
    75b0baaff351:	or     r8,r15
    75b0baaff354:	mov    r15,rbp
    75b0baaff357:	shr    r15,0x20
    75b0baaff35b:	and    r15,0xff
    75b0baaff362:	and    r15,0xffff
    75b0baaff369:	or     r14,r15
    75b0baaff36c:	mov    r15,rbp
    75b0baaff36f:	shr    r15,0x28
    75b0baaff373:	and    r15,0xff
    75b0baaff37a:	and    r15,0xffff
    75b0baaff381:	shl    r15,0x10
    75b0baaff385:	or     r14,r15
    75b0baaff388:	mov    r15,rbp
    75b0baaff38b:	shr    r15,0x30
    75b0baaff38f:	and    r15,0xff
    75b0baaff396:	and    r15,0xffff
    75b0baaff39d:	shl    r15,0x20
    75b0baaff3a1:	or     r14,r15
    75b0baaff3a4:	shr    rbp,0x38
    75b0baaff3a8:	and    rbp,0xff
    75b0baaff3af:	and    rbp,0xffff
    75b0baaff3b6:	shl    rbp,0x30
    75b0baaff3ba:	or     r14,rbp
    75b0baaff3bd:	mov    r15d,0x0
    75b0baaff3c3:	mov    rbp,QWORD PTR [rsp+0x20]
    75b0baaff3c8:	and    rbp,0xff
    75b0baaff3cf:	and    rbp,0xffff
    75b0baaff3d6:	mov    r9,r15
    75b0baaff3d9:	or     r9,rbp
    75b0baaff3dc:	mov    rbp,QWORD PTR [rsp+0x20]
    75b0baaff3e1:	shr    rbp,0x8
    75b0baaff3e5:	and    rbp,0xff
    75b0baaff3ec:	and    rbp,0xffff
    75b0baaff3f3:	shl    rbp,0x10
    75b0baaff3f7:	or     r9,rbp
    75b0baaff3fa:	mov    rbp,QWORD PTR [rsp+0x20]
    75b0baaff3ff:	shr    rbp,0x10
    75b0baaff403:	and    rbp,0xff
    75b0baaff40a:	and    rbp,0xffff
    75b0baaff411:	shl    rbp,0x20
    75b0baaff415:	or     r9,rbp
    75b0baaff418:	mov    rbp,QWORD PTR [rsp+0x20]
    75b0baaff41d:	shr    rbp,0x18
    75b0baaff421:	and    rbp,0xff
    75b0baaff428:	and    rbp,0xffff
    75b0baaff42f:	shl    rbp,0x30
    75b0baaff433:	mov    rax,r9
    75b0baaff436:	or     rax,rbp
    75b0baaff439:	mov    QWORD PTR [rsp+0x78],rax
    75b0baaff43e:	mov    rbp,QWORD PTR [rsp+0x20]
    75b0baaff443:	shr    rbp,0x20
    75b0baaff447:	and    rbp,0xff
    75b0baaff44e:	and    rbp,0xffff
    75b0baaff455:	or     r15,rbp
    75b0baaff458:	mov    rbp,QWORD PTR [rsp+0x20]
    75b0baaff45d:	shr    rbp,0x28
    75b0baaff461:	and    rbp,0xff
    75b0baaff468:	and    rbp,0xffff
    75b0baaff46f:	shl    rbp,0x10
    75b0baaff473:	or     r15,rbp
    75b0baaff476:	mov    rbp,QWORD PTR [rsp+0x20]
    75b0baaff47b:	shr    rbp,0x30
    75b0baaff47f:	and    rbp,0xff
    75b0baaff486:	and    rbp,0xffff
    75b0baaff48d:	shl    rbp,0x20
    75b0baaff491:	or     r15,rbp
    75b0baaff494:	mov    rbp,QWORD PTR [rsp+0x20]
    75b0baaff499:	shr    rbp,0x38
    75b0baaff49d:	and    rbp,0xff
    75b0baaff4a4:	and    rbp,0xffff
    75b0baaff4ab:	shl    rbp,0x30
    75b0baaff4af:	mov    rax,r15
    75b0baaff4b2:	or     rax,rbp
    75b0baaff4b5:	mov    QWORD PTR [rsp+0x70],rax
    75b0baaff4ba:	mov    rax,QWORD PTR [rsp+0x78]
    75b0baaff4bf:	mov    QWORD PTR [r12+0x250],rax
    75b0baaff4c7:	mov    rax,QWORD PTR [rsp+0x70]
    75b0baaff4cc:	mov    QWORD PTR [r12+0x258],rax
    75b0baaff4d4:	mov    ebp,0x0
    75b0baaff4d9:	mov    r15,QWORD PTR [rsp+0x40]
    75b0baaff4de:	and    r15,0xff
    75b0baaff4e5:	and    r15,0xffff
    75b0baaff4ec:	mov    r9,rbp
    75b0baaff4ef:	or     r9,r15
    75b0baaff4f2:	mov    r15,QWORD PTR [rsp+0x40]
    75b0baaff4f7:	shr    r15,0x8
    75b0baaff4fb:	and    r15,0xff
    75b0baaff502:	and    r15,0xffff
    75b0baaff509:	shl    r15,0x10
    75b0baaff50d:	or     r9,r15
    75b0baaff510:	mov    r15,QWORD PTR [rsp+0x40]
    75b0baaff515:	shr    r15,0x10
    75b0baaff519:	and    r15,0xff
    75b0baaff520:	and    r15,0xffff
    75b0baaff527:	shl    r15,0x20
    75b0baaff52b:	or     r9,r15
    75b0baaff52e:	mov    r15,QWORD PTR [rsp+0x40]
    75b0baaff533:	shr    r15,0x18
    75b0baaff537:	and    r15,0xff
    75b0baaff53e:	and    r15,0xffff
    75b0baaff545:	shl    r15,0x30
    75b0baaff549:	mov    rax,r9
    75b0baaff54c:	or     rax,r15
    75b0baaff54f:	mov    QWORD PTR [rsp+0x80],rax
    75b0baaff557:	mov    r15,QWORD PTR [rsp+0x40]
    75b0baaff55c:	shr    r15,0x20
    75b0baaff560:	and    r15,0xff
    75b0baaff567:	and    r15,0xffff
    75b0baaff56e:	or     rbp,r15
    75b0baaff571:	mov    r15,QWORD PTR [rsp+0x40]
    75b0baaff576:	shr    r15,0x28
    75b0baaff57a:	and    r15,0xff
    75b0baaff581:	and    r15,0xffff
    75b0baaff588:	shl    r15,0x10
    75b0baaff58c:	or     rbp,r15
    75b0baaff58f:	mov    r15,QWORD PTR [rsp+0x40]
    75b0baaff594:	shr    r15,0x30
    75b0baaff598:	and    r15,0xff
    75b0baaff59f:	and    r15,0xffff
    75b0baaff5a6:	shl    r15,0x20
    75b0baaff5aa:	or     rbp,r15
    75b0baaff5ad:	mov    r15,QWORD PTR [rsp+0x40]
    75b0baaff5b2:	shr    r15,0x38
    75b0baaff5b6:	and    r15,0xff
    75b0baaff5bd:	and    r15,0xffff
    75b0baaff5c4:	shl    r15,0x30
    75b0baaff5c8:	mov    rax,rbp
    75b0baaff5cb:	or     rax,r15
    75b0baaff5ce:	mov    QWORD PTR [rsp+0x88],rax
    75b0baaff5d6:	movdqu xmm2,XMMWORD PTR [r12+0x150]
    75b0baaff5e0:	pxor   xmm0,xmm0
    75b0baaff5e4:	movdqa xmm3,xmm0
    75b0baaff5e8:	movdqa xmm0,xmm2
    75b0baaff5ec:	movdqa xmm1,xmm3
    75b0baaff5f0:	punpcklwd xmm0,xmm1
    75b0baaff5f4:	movdqa xmm4,xmm0
    75b0baaff5f8:	movdqa xmm0,xmm4
    75b0baaff5fc:	pslld  xmm0,0x10
    75b0baaff601:	movdqa xmm3,xmm0
    75b0baaff605:	mov    r15d,0x0
    75b0baaff60b:	mov    r9,QWORD PTR [rsp+0x50]
    75b0baaff610:	and    r9,0xffff
    75b0baaff617:	shl    r9,0x8
    75b0baaff61b:	mov    ecx,0xffffffff
    75b0baaff620:	and    r9,rcx
    75b0baaff623:	mov    rbp,r15
    75b0baaff626:	or     rbp,r9
    75b0baaff629:	mov    r9,QWORD PTR [rsp+0x50]
    75b0baaff62e:	shr    r9,0x10
    75b0baaff632:	and    r9,0xffff
    75b0baaff639:	shl    r9,0x8
    75b0baaff63d:	mov    ecx,0xffffffff
    75b0baaff642:	and    r9,rcx
    75b0baaff645:	shl    r9,0x20
    75b0baaff649:	or     rbp,r9
    75b0baaff64c:	mov    r9,QWORD PTR [rsp+0x50]
    75b0baaff651:	shr    r9,0x20
    75b0baaff655:	and    r9,0xffff
    75b0baaff65c:	shl    r9,0x8
    75b0baaff660:	mov    ecx,0xffffffff
    75b0baaff665:	and    r9,rcx
    75b0baaff668:	or     r15,r9
    75b0baaff66b:	mov    r9,QWORD PTR [rsp+0x50]
    75b0baaff670:	shr    r9,0x30
    75b0baaff674:	and    r9,0xffff
    75b0baaff67b:	shl    r9,0x8
    75b0baaff67f:	mov    ecx,0xffffffff
    75b0baaff684:	and    r9,rcx
    75b0baaff687:	shl    r9,0x20
    75b0baaff68b:	or     r15,r9
    75b0baaff68e:	mov    QWORD PTR [r12+0x240],rbp
    75b0baaff696:	mov    QWORD PTR [r12+0x248],r15
    75b0baaff69e:	mov    r15d,0x0
    75b0baaff6a4:	mov    rbp,QWORD PTR [rsp+0x60]
    75b0baaff6a9:	and    rbp,0xffff
    75b0baaff6b0:	mov    ecx,0xffffffff
    75b0baaff6b5:	and    rbp,rcx
    75b0baaff6b8:	mov    r9,r15
    75b0baaff6bb:	or     r9,rbp
    75b0baaff6be:	mov    rbp,QWORD PTR [rsp+0x60]
    75b0baaff6c3:	shr    rbp,0x10
    75b0baaff6c7:	and    rbp,0xffff
    75b0baaff6ce:	mov    ecx,0xffffffff
    75b0baaff6d3:	and    rbp,rcx
    75b0baaff6d6:	shl    rbp,0x20
    75b0baaff6da:	or     r9,rbp
    75b0baaff6dd:	mov    rbp,QWORD PTR [rsp+0x60]
    75b0baaff6e2:	shr    rbp,0x20
    75b0baaff6e6:	and    rbp,0xffff
    75b0baaff6ed:	mov    ecx,0xffffffff
    75b0baaff6f2:	and    rbp,rcx
    75b0baaff6f5:	or     r15,rbp
    75b0baaff6f8:	mov    rbp,QWORD PTR [rsp+0x60]
    75b0baaff6fd:	shr    rbp,0x30
    75b0baaff701:	and    rbp,0xffff
    75b0baaff708:	mov    ecx,0xffffffff
    75b0baaff70d:	and    rbp,rcx
    75b0baaff710:	shl    rbp,0x20
    75b0baaff714:	or     r15,rbp
    75b0baaff717:	mov    QWORD PTR [r12+0x260],r9
    75b0baaff71f:	mov    QWORD PTR [r12+0x268],r15
    75b0baaff727:	mov    r15d,0x0
    75b0baaff72d:	mov    rbp,r13
    75b0baaff730:	and    rbp,0xffff
    75b0baaff737:	mov    ecx,0xffffffff
    75b0baaff73c:	and    rbp,rcx
    75b0baaff73f:	mov    r9,r15
    75b0baaff742:	or     r9,rbp
    75b0baaff745:	mov    rbp,r13
    75b0baaff748:	shr    rbp,0x10
    75b0baaff74c:	and    rbp,0xffff
    75b0baaff753:	mov    ecx,0xffffffff
    75b0baaff758:	and    rbp,rcx
    75b0baaff75b:	shl    rbp,0x20
    75b0baaff75f:	or     r9,rbp
    75b0baaff762:	mov    rbp,r13
    75b0baaff765:	shr    rbp,0x20
    75b0baaff769:	and    rbp,0xffff
    75b0baaff770:	mov    ecx,0xffffffff
    75b0baaff775:	and    rbp,rcx
    75b0baaff778:	or     r15,rbp
    75b0baaff77b:	shr    r13,0x30
    75b0baaff77f:	and    r13,0xffff
    75b0baaff786:	mov    ecx,0xffffffff
    75b0baaff78b:	and    r13,rcx
    75b0baaff78e:	shl    r13,0x20
    75b0baaff792:	or     r15,r13
    75b0baaff795:	mov    QWORD PTR [r12+0x270],r9
    75b0baaff79d:	mov    QWORD PTR [r12+0x278],r15
    75b0baaff7a5:	mov    r13d,0x0
    75b0baaff7ab:	mov    r15,QWORD PTR [rsp+0x58]
    75b0baaff7b0:	and    r15,0xffff
    75b0baaff7b7:	mov    ecx,0xffffffff
    75b0baaff7bc:	and    r15,rcx
    75b0baaff7bf:	mov    rbp,r13
    75b0baaff7c2:	or     rbp,r15
    75b0baaff7c5:	mov    r15,QWORD PTR [rsp+0x58]
    75b0baaff7ca:	shr    r15,0x10
    75b0baaff7ce:	and    r15,0xffff
    75b0baaff7d5:	mov    ecx,0xffffffff
    75b0baaff7da:	and    r15,rcx
    75b0baaff7dd:	shl    r15,0x20
    75b0baaff7e1:	or     rbp,r15
    75b0baaff7e4:	mov    r15,QWORD PTR [rsp+0x58]
    75b0baaff7e9:	shr    r15,0x20
    75b0baaff7ed:	and    r15,0xffff
    75b0baaff7f4:	mov    ecx,0xffffffff
    75b0baaff7f9:	and    r15,rcx
    75b0baaff7fc:	or     r13,r15
    75b0baaff7ff:	mov    r15,QWORD PTR [rsp+0x58]
    75b0baaff804:	shr    r15,0x30
    75b0baaff808:	and    r15,0xffff
    75b0baaff80f:	mov    ecx,0xffffffff
    75b0baaff814:	and    r15,rcx
    75b0baaff817:	shl    r15,0x20
    75b0baaff81b:	or     r13,r15
    75b0baaff81e:	mov    QWORD PTR [r12+0x170],rbp
    75b0baaff826:	mov    QWORD PTR [r12+0x178],r13
    75b0baaff82e:	movdqu xmm4,XMMWORD PTR [r12+0x210]
    75b0baaff838:	pxor   xmm0,xmm0
    75b0baaff83c:	movdqa xmm5,xmm0
    75b0baaff840:	movdqa xmm0,xmm4
    75b0baaff844:	movdqa xmm1,xmm5
    75b0baaff848:	punpckhwd xmm0,xmm1
    75b0baaff84c:	movdqa xmm6,xmm0
    75b0baaff850:	movdqa xmm0,xmm6
    75b0baaff854:	pslld  xmm0,0x10
    75b0baaff859:	movdqa xmm5,xmm0
    75b0baaff85d:	movdqu XMMWORD PTR [r12+0x280],xmm5
    75b0baaff867:	mov    r13d,0x0
    75b0baaff86d:	mov    r15,QWORD PTR [rsp+0x68]
    75b0baaff872:	and    r15,0xffff
    75b0baaff879:	mov    ecx,0xffffffff
    75b0baaff87e:	and    r15,rcx
    75b0baaff881:	mov    rbp,r13
    75b0baaff884:	or     rbp,r15
    75b0baaff887:	mov    r15,QWORD PTR [rsp+0x68]
    75b0baaff88c:	shr    r15,0x10
    75b0baaff890:	and    r15,0xffff
    75b0baaff897:	mov    ecx,0xffffffff
    75b0baaff89c:	and    r15,rcx
    75b0baaff89f:	shl    r15,0x20
    75b0baaff8a3:	or     rbp,r15
    75b0baaff8a6:	mov    r15,QWORD PTR [rsp+0x68]
    75b0baaff8ab:	shr    r15,0x20
    75b0baaff8af:	and    r15,0xffff
    75b0baaff8b6:	mov    ecx,0xffffffff
    75b0baaff8bb:	and    r15,rcx
    75b0baaff8be:	or     r13,r15
    75b0baaff8c1:	mov    r15,QWORD PTR [rsp+0x68]
    75b0baaff8c6:	shr    r15,0x30
    75b0baaff8ca:	and    r15,0xffff
    75b0baaff8d1:	mov    ecx,0xffffffff
    75b0baaff8d6:	and    r15,rcx
    75b0baaff8d9:	shl    r15,0x20
    75b0baaff8dd:	or     r13,r15
    75b0baaff8e0:	mov    QWORD PTR [r12+0x180],rbp
    75b0baaff8e8:	mov    QWORD PTR [r12+0x188],r13
    75b0baaff8f0:	pxor   xmm0,xmm0
    75b0baaff8f4:	movdqa xmm6,xmm0
    75b0baaff8f8:	movdqa xmm0,xmm4
    75b0baaff8fc:	movdqa xmm1,xmm6
    75b0baaff900:	punpcklwd xmm0,xmm1
    75b0baaff904:	movdqa xmm7,xmm0
    75b0baaff908:	movdqa xmm0,xmm7
    75b0baaff90c:	pslld  xmm0,0x10
    75b0baaff911:	movdqa xmm4,xmm0
    75b0baaff915:	pxor   xmm0,xmm0
    75b0baaff919:	movdqa xmm6,xmm0
    75b0baaff91d:	movdqa xmm0,xmm2
    75b0baaff921:	movdqa xmm1,xmm6
    75b0baaff925:	punpckhwd xmm0,xmm1
    75b0baaff929:	movdqa xmm7,xmm0
    75b0baaff92d:	movdqa xmm0,xmm7
    75b0baaff931:	pslld  xmm0,0x10
    75b0baaff936:	movdqa xmm2,xmm0
    75b0baaff93a:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    75b0baaff944:	movdqa xmm1,xmm6
    75b0baaff948:	por    xmm3,xmm1
    75b0baaff94c:	movdqu XMMWORD PTR [r12+0x230],xmm3
    75b0baaff956:	mov    r13d,0x0
    75b0baaff95c:	mov    r15,r14
    75b0baaff95f:	and    r15,0xffff
    75b0baaff966:	shl    r15,0x8
    75b0baaff96a:	mov    ecx,0xffffffff
    75b0baaff96f:	and    r15,rcx
    75b0baaff972:	mov    rbp,r13
    75b0baaff975:	or     rbp,r15
    75b0baaff978:	mov    r15,r14
    75b0baaff97b:	shr    r15,0x10
    75b0baaff97f:	and    r15,0xffff
    75b0baaff986:	shl    r15,0x8
    75b0baaff98a:	mov    ecx,0xffffffff
    75b0baaff98f:	and    r15,rcx
    75b0baaff992:	shl    r15,0x20
    75b0baaff996:	or     rbp,r15
    75b0baaff999:	mov    r15,r14
    75b0baaff99c:	shr    r15,0x20
    75b0baaff9a0:	and    r15,0xffff
    75b0baaff9a7:	shl    r15,0x8
    75b0baaff9ab:	mov    ecx,0xffffffff
    75b0baaff9b0:	and    r15,rcx
    75b0baaff9b3:	or     r13,r15
    75b0baaff9b6:	shr    r14,0x30
    75b0baaff9ba:	and    r14,0xffff
    75b0baaff9c1:	shl    r14,0x8
    75b0baaff9c5:	mov    ecx,0xffffffff
    75b0baaff9ca:	and    r14,rcx
    75b0baaff9cd:	shl    r14,0x20
    75b0baaff9d1:	or     r13,r14
    75b0baaff9d4:	mov    QWORD PTR [r12+0x240],rbp
    75b0baaff9dc:	mov    QWORD PTR [r12+0x248],r13
    75b0baaff9e4:	mov    r13d,0x0
    75b0baaff9ea:	mov    r14,r8
    75b0baaff9ed:	and    r14,0xffff
    75b0baaff9f4:	shl    r14,0x8
    75b0baaff9f8:	mov    ecx,0xffffffff
    75b0baaff9fd:	and    r14,rcx
    75b0baaffa00:	mov    r15,r13
    75b0baaffa03:	or     r15,r14
    75b0baaffa06:	mov    r14,r8
    75b0baaffa09:	shr    r14,0x10
    75b0baaffa0d:	and    r14,0xffff
    75b0baaffa14:	shl    r14,0x8
    75b0baaffa18:	mov    ecx,0xffffffff
    75b0baaffa1d:	and    r14,rcx
    75b0baaffa20:	shl    r14,0x20
    75b0baaffa24:	or     r15,r14
    75b0baaffa27:	mov    r14,r8
    75b0baaffa2a:	shr    r14,0x20
    75b0baaffa2e:	and    r14,0xffff
    75b0baaffa35:	shl    r14,0x8
    75b0baaffa39:	mov    ecx,0xffffffff
    75b0baaffa3e:	and    r14,rcx
    75b0baaffa41:	or     r13,r14
    75b0baaffa44:	shr    r8,0x30
    75b0baaffa48:	and    r8,0xffff
    75b0baaffa4f:	shl    r8,0x8
    75b0baaffa53:	mov    ecx,0xffffffff
    75b0baaffa58:	and    r8,rcx
    75b0baaffa5b:	shl    r8,0x20
    75b0baaffa5f:	or     r13,r8
    75b0baaffa62:	mov    QWORD PTR [r12+0x220],r15
    75b0baaffa6a:	mov    QWORD PTR [r12+0x228],r13
    75b0baaffa72:	mov    r13d,0x0
    75b0baaffa78:	mov    r14,QWORD PTR [rsp+0x48]
    75b0baaffa7d:	and    r14,0xffff
    75b0baaffa84:	shl    r14,0x8
    75b0baaffa88:	mov    ecx,0xffffffff
    75b0baaffa8d:	and    r14,rcx
    75b0baaffa90:	mov    r15,r13
    75b0baaffa93:	or     r15,r14
    75b0baaffa96:	mov    r14,QWORD PTR [rsp+0x48]
    75b0baaffa9b:	shr    r14,0x10
    75b0baaffa9f:	and    r14,0xffff
    75b0baaffaa6:	shl    r14,0x8
    75b0baaffaaa:	mov    ecx,0xffffffff
    75b0baaffaaf:	and    r14,rcx
    75b0baaffab2:	shl    r14,0x20
    75b0baaffab6:	or     r15,r14
    75b0baaffab9:	mov    r14,QWORD PTR [rsp+0x48]
    75b0baaffabe:	shr    r14,0x20
    75b0baaffac2:	and    r14,0xffff
    75b0baaffac9:	shl    r14,0x8
    75b0baaffacd:	mov    ecx,0xffffffff
    75b0baaffad2:	and    r14,rcx
    75b0baaffad5:	or     r13,r14
    75b0baaffad8:	mov    r14,QWORD PTR [rsp+0x48]
    75b0baaffadd:	shr    r14,0x30
    75b0baaffae1:	and    r14,0xffff
    75b0baaffae8:	shl    r14,0x8
    75b0baaffaec:	mov    ecx,0xffffffff
    75b0baaffaf1:	and    r14,rcx
    75b0baaffaf4:	shl    r14,0x20
    75b0baaffaf8:	or     r13,r14
    75b0baaffafb:	mov    QWORD PTR [r12+0x160],r15
    75b0baaffb03:	mov    QWORD PTR [r12+0x168],r13
    75b0baaffb0b:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    75b0baaffb15:	movdqa xmm0,xmm6
    75b0baaffb19:	pslld  xmm0,0x18
    75b0baaffb1e:	movdqa xmm7,xmm0
    75b0baaffb22:	movdqu XMMWORD PTR [r12+0x170],xmm7
    75b0baaffb2c:	movdqu xmm6,XMMWORD PTR [r12+0x270]
    75b0baaffb36:	movdqa xmm0,xmm6
    75b0baaffb3a:	pslld  xmm0,0x18
    75b0baaffb3f:	movdqa xmm8,xmm0
    75b0baaffb44:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    75b0baaffb4e:	movdqa xmm0,xmm6
    75b0baaffb52:	pslld  xmm0,0x18
    75b0baaffb57:	movdqa xmm9,xmm0
    75b0baaffb5c:	movdqu XMMWORD PTR [r12+0x180],xmm9
    75b0baaffb66:	mov    r13d,0x0
    75b0baaffb6c:	mov    r14,QWORD PTR [rsp+0x78]
    75b0baaffb71:	and    r14,0xffff
    75b0baaffb78:	mov    ecx,0xffffffff
    75b0baaffb7d:	and    r14,rcx
    75b0baaffb80:	mov    r15,r13
    75b0baaffb83:	or     r15,r14
    75b0baaffb86:	mov    r14,QWORD PTR [rsp+0x78]
    75b0baaffb8b:	shr    r14,0x10
    75b0baaffb8f:	and    r14,0xffff
    75b0baaffb96:	mov    ecx,0xffffffff
    75b0baaffb9b:	and    r14,rcx
    75b0baaffb9e:	shl    r14,0x20
    75b0baaffba2:	or     r15,r14
    75b0baaffba5:	mov    r14,QWORD PTR [rsp+0x78]
    75b0baaffbaa:	shr    r14,0x20
    75b0baaffbae:	and    r14,0xffff
    75b0baaffbb5:	mov    ecx,0xffffffff
    75b0baaffbba:	and    r14,rcx
    75b0baaffbbd:	or     r13,r14
    75b0baaffbc0:	mov    r14,QWORD PTR [rsp+0x78]
    75b0baaffbc5:	shr    r14,0x30
    75b0baaffbc9:	and    r14,0xffff
    75b0baaffbd0:	mov    ecx,0xffffffff
    75b0baaffbd5:	and    r14,rcx
    75b0baaffbd8:	shl    r14,0x20
    75b0baaffbdc:	or     r13,r14
    75b0baaffbdf:	mov    QWORD PTR [r12+0x140],r15
    75b0baaffbe7:	mov    QWORD PTR [r12+0x148],r13
    75b0baaffbef:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    75b0baaffbf9:	movdqa xmm1,xmm6
    75b0baaffbfd:	por    xmm5,xmm1
    75b0baaffc01:	movdqu xmm6,XMMWORD PTR [r12+0x220]
    75b0baaffc0b:	movdqa xmm1,xmm6
    75b0baaffc0f:	por    xmm4,xmm1
    75b0baaffc13:	movdqu XMMWORD PTR [r12+0x210],xmm4
    75b0baaffc1d:	movdqu xmm6,XMMWORD PTR [r12+0x260]
    75b0baaffc27:	movdqa xmm0,xmm6
    75b0baaffc2b:	pslld  xmm0,0x18
    75b0baaffc30:	movdqa xmm10,xmm0
    75b0baaffc35:	movdqu XMMWORD PTR [r12+0x220],xmm10
    75b0baaffc3f:	movdqu xmm6,XMMWORD PTR [r12+0x160]
    75b0baaffc49:	movdqa xmm1,xmm6
    75b0baaffc4d:	por    xmm2,xmm1
    75b0baaffc51:	movdqa xmm1,xmm7
    75b0baaffc55:	por    xmm3,xmm1
    75b0baaffc59:	movdqu XMMWORD PTR [r12+0x160],xmm3
    75b0baaffc63:	mov    r13d,0x0
    75b0baaffc69:	mov    r14,QWORD PTR [rsp+0x88]
    75b0baaffc71:	and    r14,0xffff
    75b0baaffc78:	mov    ecx,0xffffffff
    75b0baaffc7d:	and    r14,rcx
    75b0baaffc80:	mov    r15,r13
    75b0baaffc83:	or     r15,r14
    75b0baaffc86:	mov    r14,QWORD PTR [rsp+0x88]
    75b0baaffc8e:	shr    r14,0x10
    75b0baaffc92:	and    r14,0xffff
    75b0baaffc99:	mov    ecx,0xffffffff
    75b0baaffc9e:	and    r14,rcx
    75b0baaffca1:	shl    r14,0x20
    75b0baaffca5:	or     r15,r14
    75b0baaffca8:	mov    r14,QWORD PTR [rsp+0x88]
    75b0baaffcb0:	shr    r14,0x20
    75b0baaffcb4:	and    r14,0xffff
    75b0baaffcbb:	mov    ecx,0xffffffff
    75b0baaffcc0:	and    r14,rcx
    75b0baaffcc3:	or     r13,r14
    75b0baaffcc6:	mov    r14,QWORD PTR [rsp+0x88]
    75b0baaffcce:	shr    r14,0x30
    75b0baaffcd2:	and    r14,0xffff
    75b0baaffcd9:	mov    ecx,0xffffffff
    75b0baaffcde:	and    r14,rcx
    75b0baaffce1:	shl    r14,0x20
    75b0baaffce5:	or     r13,r14
    75b0baaffce8:	mov    QWORD PTR [r12+0x170],r15
    75b0baaffcf0:	mov    QWORD PTR [r12+0x178],r13
    75b0baaffcf8:	mov    r13d,0x0
    75b0baaffcfe:	mov    r14,QWORD PTR [rsp+0x80]
    75b0baaffd06:	and    r14,0xffff
    75b0baaffd0d:	mov    ecx,0xffffffff
    75b0baaffd12:	and    r14,rcx
    75b0baaffd15:	mov    r15,r13
    75b0baaffd18:	or     r15,r14
    75b0baaffd1b:	mov    r14,QWORD PTR [rsp+0x80]
    75b0baaffd23:	shr    r14,0x10
    75b0baaffd27:	and    r14,0xffff
    75b0baaffd2e:	mov    ecx,0xffffffff
    75b0baaffd33:	and    r14,rcx
    75b0baaffd36:	shl    r14,0x20
    75b0baaffd3a:	or     r15,r14
    75b0baaffd3d:	mov    r14,QWORD PTR [rsp+0x80]
    75b0baaffd45:	shr    r14,0x20
    75b0baaffd49:	and    r14,0xffff
    75b0baaffd50:	mov    ecx,0xffffffff
    75b0baaffd55:	and    r14,rcx
    75b0baaffd58:	or     r13,r14
    75b0baaffd5b:	mov    r14,QWORD PTR [rsp+0x80]
    75b0baaffd63:	shr    r14,0x30
    75b0baaffd67:	and    r14,0xffff
    75b0baaffd6e:	mov    ecx,0xffffffff
    75b0baaffd73:	and    r14,rcx
    75b0baaffd76:	shl    r14,0x20
    75b0baaffd7a:	or     r13,r14
    75b0baaffd7d:	mov    QWORD PTR [r12+0x110],r15
    75b0baaffd85:	mov    QWORD PTR [r12+0x118],r13
    75b0baaffd8d:	movdqa xmm1,xmm8
    75b0baaffd92:	por    xmm5,xmm1
    75b0baaffd96:	movdqa xmm1,xmm9
    75b0baaffd9b:	por    xmm4,xmm1
    75b0baaffd9f:	mov    r13d,0x0
    75b0baaffda5:	mov    r14,QWORD PTR [rsp+0x70]
    75b0baaffdaa:	and    r14,0xffff
    75b0baaffdb1:	mov    ecx,0xffffffff
    75b0baaffdb6:	and    r14,rcx
    75b0baaffdb9:	mov    r15,r13
    75b0baaffdbc:	or     r15,r14
    75b0baaffdbf:	mov    r14,QWORD PTR [rsp+0x70]
    75b0baaffdc4:	shr    r14,0x10
    75b0baaffdc8:	and    r14,0xffff
    75b0baaffdcf:	mov    ecx,0xffffffff
    75b0baaffdd4:	and    r14,rcx
    75b0baaffdd7:	shl    r14,0x20
    75b0baaffddb:	or     r15,r14
    75b0baaffdde:	mov    r14,QWORD PTR [rsp+0x70]
    75b0baaffde3:	shr    r14,0x20
    75b0baaffde7:	and    r14,0xffff
    75b0baaffdee:	mov    ecx,0xffffffff
    75b0baaffdf3:	and    r14,rcx
    75b0baaffdf6:	or     r13,r14
    75b0baaffdf9:	mov    r14,QWORD PTR [rsp+0x70]
    75b0baaffdfe:	shr    r14,0x30
    75b0baaffe02:	and    r14,0xffff
    75b0baaffe09:	mov    ecx,0xffffffff
    75b0baaffe0e:	and    r14,rcx
    75b0baaffe11:	shl    r14,0x20
    75b0baaffe15:	or     r13,r14
    75b0baaffe18:	mov    QWORD PTR [r12+0x180],r15
    75b0baaffe20:	mov    QWORD PTR [r12+0x188],r13
    75b0baaffe28:	movdqa xmm1,xmm10
    75b0baaffe2d:	por    xmm2,xmm1
    75b0baaffe31:	movdqu XMMWORD PTR [r12+0x150],xmm2
    75b0baaffe3b:	movdqu xmm6,XMMWORD PTR [r12+0x140]
    75b0baaffe45:	movdqa xmm1,xmm6
    75b0baaffe49:	por    xmm3,xmm1
    75b0baaffe4d:	movdqu XMMWORD PTR [r12+0x140],xmm3
    75b0baaffe57:	movdqu xmm6,XMMWORD PTR [r12+0x110]
    75b0baaffe61:	movdqa xmm1,xmm6
    75b0baaffe65:	por    xmm4,xmm1
    75b0baaffe69:	movdqu XMMWORD PTR [r12+0x110],xmm4
    75b0baaffe73:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    75b0baaffe7d:	movdqa xmm1,xmm6
    75b0baaffe81:	por    xmm5,xmm1
    75b0baaffe85:	movdqu XMMWORD PTR [r12+0x120],xmm5
    75b0baaffe8f:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    75b0baaffe99:	movdqa xmm1,xmm6
    75b0baaffe9d:	por    xmm2,xmm1
    75b0baaffea1:	movdqu XMMWORD PTR [r12+0x130],xmm2
    75b0baaffeab:	mov    r13,QWORD PTR [r12+0xf8]
    75b0baaffeb3:	mov    r14,r13
    75b0baaffeb6:	add    r14,0x20
    75b0baaffeba:	mov    r15,r14
    75b0baaffebd:	add    r15,0x10
    75b0baaffec1:	movdqu XMMWORD PTR [r14],xmm4
    75b0baaffec6:	mov    r14d,0x0
    75b0baaffecc:	mov    DWORD PTR [r12+0x32c],r14d
    75b0baaffed4:	movdqu XMMWORD PTR [r15],xmm5
    75b0baaffed9:	mov    r14,r13
    75b0baaffedc:	add    r14,0x10
    75b0baaffee0:	movdqu XMMWORD PTR [r13+0x0],xmm3
    75b0baaffee6:	movdqu XMMWORD PTR [r14],xmm2
    75b0baaffeeb:	mov    r14d,DWORD PTR [r13+0x0]
    75b0baaffeef:	mov    QWORD PTR [r12+0x60],r14
    75b0baaffef4:	jmp    0x75b0baaffef9
    75b0baaffef9:	mov    r13,QWORD PTR [r12+0x58]
    75b0baaffefe:	mov    r14,QWORD PTR [r12+0x48]
    75b0baafff03:	add    r14,r13
    75b0baafff06:	mov    QWORD PTR [r12+0x68],r14
    75b0baafff0b:	add    r13,0x4
    75b0baafff0f:	mov    QWORD PTR [r12+0x58],r13
    75b0baafff14:	mov    r15,r14
    75b0baafff17:	add    r15,0x4
    75b0baafff1b:	mov    eax,DWORD PTR [r15]
    75b0baafff1e:	mov    QWORD PTR [r12+0x70],rax
    75b0baafff23:	mov    r15,r14
    75b0baafff26:	add    r15,0x38
    75b0baafff2a:	mov    r8d,DWORD PTR [r15]
    75b0baafff2d:	mov    QWORD PTR [r12+0x78],r8
    75b0baafff32:	mov    r15,r14
    75b0baafff35:	add    r15,0x24
    75b0baafff39:	mov    r9d,DWORD PTR [r15]
    75b0baafff3c:	mov    QWORD PTR [r12+0x90],r9
    75b0baafff44:	sub    r13,0xc0
    75b0baafff4b:	setne  BYTE PTR [rsp+0xb8]
    75b0baafff53:	mov    r11,rax
    75b0baafff56:	lahf
    75b0baafff57:	seto   al
    75b0baafff5a:	mov    WORD PTR [rsp+0xb0],ax
    75b0baafff62:	mov    rax,r11
    75b0baafff65:	mov    r13d,DWORD PTR [r12+0x70]
    75b0baafff6a:	mov    r13d,r13d
    75b0baafff6d:	mov    r13d,r13d
    75b0baafff70:	ror    r13d,0x7
    75b0baafff74:	mov    QWORD PTR [r12+0x80],r13
    75b0baafff7c:	mov    r15d,r8d
    75b0baafff7f:	mov    r15d,r15d
    75b0baafff82:	ror    r15d,0x11
    75b0baafff86:	mov    QWORD PTR [r12+0x88],r15
    75b0baafff8e:	mov    ebp,DWORD PTR [r12+0x60]
    75b0baafff93:	add    r9d,ebp
    75b0baafff96:	mov    QWORD PTR [r12+0x60],r9
    75b0baafff9b:	mov    ebp,DWORD PTR [r12+0x70]
    75b0baafffa0:	mov    ebp,ebp
    75b0baafffa2:	mov    ebp,ebp
    75b0baafffa4:	ror    ebp,0x12
    75b0baafffa7:	xor    r13d,ebp
    75b0baafffaa:	mov    QWORD PTR [r12+0x80],r13
    75b0baafffb2:	mov    ebp,r8d
    75b0baafffb5:	mov    ebp,ebp
    75b0baafffb7:	ror    ebp,0x13
    75b0baafffba:	xor    r15d,ebp
    75b0baafffbd:	mov    QWORD PTR [r12+0x88],r15
    75b0baafffc5:	mov    ebp,DWORD PTR [r12+0x70]
    75b0baafffca:	mov    ebp,ebp
    75b0baafffcc:	mov    ebp,ebp
    75b0baafffce:	shr    ebp,0x3
    75b0baafffd1:	xor    r13d,ebp
    75b0baafffd4:	mov    QWORD PTR [r12+0x80],r13
    75b0baafffdc:	mov    r8d,r8d
    75b0baafffdf:	shr    r8d,0xa
    75b0baafffe3:	xor    r15d,r8d
    75b0baafffe6:	mov    QWORD PTR [r12+0x78],r15
    75b0baafffeb:	add    r9d,r13d
    75b0baafffee:	mov    QWORD PTR [r12+0x60],r9
    75b0baaffff3:	add    r9d,r15d
    75b0baaffff6:	mov    QWORD PTR [r12+0x60],r9
    75b0baaffffb:	add    r14,0x40
    75b0baafffff:	mov    DWORD PTR [r14],r9d
    75b0bab00002:	mov    r13d,0x0
    75b0bab00008:	mov    DWORD PTR [r12+0x32c],r13d
    75b0bab00010:	mov    r13d,0x0
    75b0bab00016:	mov    ecx,DWORD PTR [r12+0x70]
    75b0bab0001b:	mov    ecx,ecx
    75b0bab0001d:	mov    r14d,r13d
    75b0bab00020:	or     r14d,ecx
    75b0bab00023:	mov    QWORD PTR [r12+0x60],r14
    75b0bab00028:	mov    rcx,QWORD PTR [r12+0x380]
    75b0bab00030:	jrcxz  0x75b0bab00037
    75b0bab00032:	jmp    0x75b0bab0081a
    75b0bab00037:	cmp    BYTE PTR [rsp+0xb8],0x0
    75b0bab0003f:	jne    0x75b0baaffef9
    75b0bab00045:	jmp    0x75b0bab0004a
    75b0bab0004a:	mov    r13,QWORD PTR [r12]
    75b0bab0004e:	mov    r14,r13
    75b0bab00051:	add    r14,0x4
    75b0bab00055:	mov    r15d,DWORD PTR [r13+0x0]
    75b0bab00059:	mov    ebp,DWORD PTR [r14]
    75b0bab0005c:	mov    QWORD PTR [r12+0x78],r15
    75b0bab00061:	mov    QWORD PTR [r12+0x80],rbp
    75b0bab00069:	mov    r14,r13
    75b0bab0006c:	add    r14,0x8
    75b0bab00070:	mov    r8,r14
    75b0bab00073:	add    r8,0x4
    75b0bab00077:	mov    r9d,DWORD PTR [r14]
    75b0bab0007a:	mov    eax,DWORD PTR [r8]
    75b0bab0007d:	mov    QWORD PTR [rsp+0x90],rax
    75b0bab00085:	mov    QWORD PTR [r12+0x70],r9
    75b0bab0008a:	mov    rax,QWORD PTR [rsp+0x90]
    75b0bab00092:	mov    QWORD PTR [r12+0x68],rax
    75b0bab00097:	mov    r8,r13
    75b0bab0009a:	add    r8,0x18
    75b0bab0009e:	mov    r14,r8
    75b0bab000a1:	add    r14,0x4
    75b0bab000a5:	mov    eax,DWORD PTR [r8]
    75b0bab000a8:	mov    QWORD PTR [rsp+0x98],rax
    75b0bab000b0:	mov    r8d,DWORD PTR [r14]
    75b0bab000b3:	mov    rax,QWORD PTR [rsp+0x98]
    75b0bab000bb:	mov    QWORD PTR [r12+0x58],rax
    75b0bab000c0:	mov    QWORD PTR [r12+0x60],r8
    75b0bab000c5:	add    r13,0x10
    75b0bab000c9:	mov    r14,r13
    75b0bab000cc:	add    r14,0x4
    75b0bab000d0:	mov    eax,DWORD PTR [r13+0x0]
    75b0bab000d4:	mov    QWORD PTR [rsp+0xa0],rax
    75b0bab000dc:	mov    eax,DWORD PTR [r14]
    75b0bab000df:	mov    QWORD PTR [rsp+0xa8],rax
    75b0bab000e7:	mov    rax,QWORD PTR [rsp+0xa0]
    75b0bab000ef:	mov    QWORD PTR [r12+0x18],rax
    75b0bab000f4:	mov    rax,QWORD PTR [rsp+0xa8]
    75b0bab000fc:	mov    QWORD PTR [r12+0x90],rax
    75b0bab00104:	mov    r14d,0x0
    75b0bab0010a:	mov    QWORD PTR [r12+0x88],r14
    75b0bab00112:	mov    r14d,0x0
    75b0bab00118:	mov    r13d,r14d
    75b0bab0011b:	or     r13d,r15d
    75b0bab0011e:	mov    QWORD PTR [r12+0xa8],r13
    75b0bab00126:	mov    r13d,0x0
    75b0bab0012c:	mov    r14d,r13d
    75b0bab0012f:	or     r14d,ebp
    75b0bab00132:	mov    QWORD PTR [r12+0x38],r14
    75b0bab00137:	mov    r13d,0x0
    75b0bab0013d:	mov    r14d,r13d
    75b0bab00140:	or     r14d,r9d
    75b0bab00143:	mov    QWORD PTR [r12+0x98],r14
    75b0bab0014b:	mov    r13d,0x0
    75b0bab00151:	mov    ecx,DWORD PTR [rsp+0x90]
    75b0bab00158:	mov    r14d,r13d
    75b0bab0015b:	or     r14d,ecx
    75b0bab0015e:	mov    QWORD PTR [r12+0x28],r14
    75b0bab00163:	mov    r13d,0x0
    75b0bab00169:	mov    r14d,r13d
    75b0bab0016c:	or     r14d,r8d
    75b0bab0016f:	mov    QWORD PTR [r12+0xb0],r14
    75b0bab00177:	mov    r13d,0x0
    75b0bab0017d:	mov    ecx,DWORD PTR [rsp+0x98]
    75b0bab00184:	mov    r14d,r13d
    75b0bab00187:	or     r14d,ecx
    75b0bab0018a:	mov    QWORD PTR [r12+0xc0],r14
    75b0bab00192:	mov    r13d,0x0
    75b0bab00198:	mov    ecx,DWORD PTR [rsp+0xa8]
    75b0bab0019f:	mov    r14d,r13d
    75b0bab001a2:	or     r14d,ecx
    75b0bab001a5:	mov    QWORD PTR [r12+0xc8],r14
    75b0bab001ad:	mov    r13d,0x0
    75b0bab001b3:	mov    ecx,DWORD PTR [rsp+0xa0]
    75b0bab001ba:	mov    r14d,r13d
    75b0bab001bd:	or     r14d,ecx
    75b0bab001c0:	mov    QWORD PTR [r12+0xb8],r14
    75b0bab001c8:	jmp    0x75b0bab001cd
    75b0bab001cd:	mov    r13d,0x0
    75b0bab001d3:	mov    r14d,DWORD PTR [r12+0xb8]
    75b0bab001db:	mov    eax,r13d
    75b0bab001de:	or     eax,r14d
    75b0bab001e1:	mov    QWORD PTR [r12+0x30],rax
    75b0bab001e6:	mov    r13d,0x0
    75b0bab001ec:	mov    ebp,DWORD PTR [r12+0xc0]
    75b0bab001f4:	mov    eax,r13d
    75b0bab001f7:	or     eax,ebp
    75b0bab001f9:	mov    QWORD PTR [r12+0xa0],rax
    75b0bab00201:	mov    r13d,0x0
    75b0bab00207:	mov    ebp,DWORD PTR [r12+0x28]
    75b0bab0020c:	mov    eax,r13d
    75b0bab0020f:	or     eax,ebp
    75b0bab00211:	mov    QWORD PTR [r12+0xc0],rax
    75b0bab00219:	mov    r13d,0x0
    75b0bab0021f:	mov    ebp,DWORD PTR [r12+0x98]
    75b0bab00227:	mov    eax,r13d
    75b0bab0022a:	or     eax,ebp
    75b0bab0022c:	mov    QWORD PTR [r12+0x28],rax
    75b0bab00231:	mov    r13d,0x0
    75b0bab00237:	mov    ebp,DWORD PTR [r12+0x38]
    75b0bab0023c:	mov    eax,r13d
    75b0bab0023f:	or     eax,ebp
    75b0bab00241:	mov    QWORD PTR [r12+0x98],rax
    75b0bab00249:	mov    r13d,0x0
    75b0bab0024f:	mov    ebp,DWORD PTR [r12+0xa8]
    75b0bab00257:	mov    eax,r13d
    75b0bab0025a:	or     eax,ebp
    75b0bab0025c:	mov    QWORD PTR [r12+0x38],rax
    75b0bab00261:	mov    r14d,r14d
    75b0bab00264:	ror    r14d,0x6
    75b0bab00268:	mov    QWORD PTR [r12+0xb8],r14
    75b0bab00270:	mov    r13d,DWORD PTR [r12+0xc8]
    75b0bab00278:	mov    ebp,DWORD PTR [r12+0x30]
    75b0bab0027d:	mov    ebp,ebp
    75b0bab0027f:	and    ebp,r13d
    75b0bab00282:	mov    QWORD PTR [r12+0xa8],rbp
    75b0bab0028a:	mov    r9d,DWORD PTR [r12+0x38]
    75b0bab0028f:	mov    r9d,r9d
    75b0bab00292:	mov    r9d,r9d
    75b0bab00295:	ror    r9d,0x2
    75b0bab00299:	mov    QWORD PTR [r12+0xd0],r9
    75b0bab002a1:	mov    r15d,0x0
    75b0bab002a7:	mov    eax,r15d
    75b0bab002aa:	or     eax,r13d
    75b0bab002ad:	mov    QWORD PTR [r12+0x20],rax
    75b0bab002b2:	mov    rax,QWORD PTR [r12+0x88]
    75b0bab002ba:	mov    r15,QWORD PTR [r12+0x50]
    75b0bab002bf:	mov    rcx,QWORD PTR [r12+0x88]
    75b0bab002c7:	add    r15,rcx
    75b0bab002ca:	mov    r13d,DWORD PTR [r15]
    75b0bab002cd:	mov    QWORD PTR [r12+0xc8],r13
    75b0bab002d5:	mov    ecx,DWORD PTR [r12+0x30]
    75b0bab002da:	mov    ecx,ecx
    75b0bab002dc:	mov    r15d,DWORD PTR [r12+0xa0]
    75b0bab002e4:	mov    r15d,r15d
    75b0bab002e7:	not    rcx
    75b0bab002ea:	and    r15d,ecx
    75b0bab002ed:	mov    QWORD PTR [r12+0xd8],r15
    75b0bab002f5:	mov    r8d,DWORD PTR [r12+0xb0]
    75b0bab002fd:	add    ebp,r8d
    75b0bab00300:	mov    QWORD PTR [r12+0xa8],rbp
    75b0bab00308:	mov    r8d,DWORD PTR [r12+0x30]
    75b0bab0030d:	mov    r8d,r8d
    75b0bab00310:	mov    r8d,r8d
    75b0bab00313:	ror    r8d,0xb
    75b0bab00317:	xor    r14d,r8d
    75b0bab0031a:	mov    QWORD PTR [r12+0xb0],r14
    75b0bab00322:	mov    r8d,DWORD PTR [r12+0x38]
    75b0bab00327:	mov    r8d,r8d
    75b0bab0032a:	mov    r8d,r8d
    75b0bab0032d:	ror    r8d,0xd
    75b0bab00331:	xor    r9d,r8d
    75b0bab00334:	mov    QWORD PTR [r12+0xd0],r9
    75b0bab0033c:	add    ebp,r15d
    75b0bab0033f:	mov    QWORD PTR [r12+0xa8],rbp
    75b0bab00347:	mov    r15,QWORD PTR [r12+0x48]
    75b0bab0034c:	mov    rcx,QWORD PTR [r12+0x88]
    75b0bab00354:	add    r15,rcx
    75b0bab00357:	mov    r8d,DWORD PTR [r15]
    75b0bab0035a:	mov    QWORD PTR [r12+0xb8],r8
    75b0bab00362:	mov    ecx,DWORD PTR [r12+0x98]
    75b0bab0036a:	mov    ecx,ecx
    75b0bab0036c:	mov    eax,DWORD PTR [r12+0x28]
    75b0bab00371:	mov    eax,eax
    75b0bab00373:	and    eax,ecx
    75b0bab00375:	mov    QWORD PTR [r12+0xd8],rax
    75b0bab0037d:	add    ebp,r13d
    75b0bab00380:	mov    QWORD PTR [r12+0xa8],rbp
    75b0bab00388:	mov    ecx,DWORD PTR [r12+0x98]
    75b0bab00390:	mov    ecx,ecx
    75b0bab00392:	mov    r13d,DWORD PTR [r12+0x28]
    75b0bab00397:	mov    r13d,r13d
    75b0bab0039a:	xor    r13d,ecx
    75b0bab0039d:	mov    QWORD PTR [r12+0xc8],r13
    75b0bab003a5:	mov    r15d,DWORD PTR [r12+0x30]
    75b0bab003aa:	mov    r15d,r15d
    75b0bab003ad:	mov    r15d,r15d
    75b0bab003b0:	ror    r15d,0x19
    75b0bab003b4:	xor    r14d,r15d
    75b0bab003b7:	mov    QWORD PTR [r12+0xb0],r14
    75b0bab003bf:	mov    ecx,DWORD PTR [r12+0x38]
    75b0bab003c4:	mov    ecx,ecx
    75b0bab003c6:	and    r13d,ecx
    75b0bab003c9:	mov    QWORD PTR [r12+0xc8],r13
    75b0bab003d1:	mov    r15d,DWORD PTR [r12+0x38]
    75b0bab003d6:	mov    r15d,r15d
    75b0bab003d9:	mov    r15d,r15d
    75b0bab003dc:	ror    r15d,0x16
    75b0bab003e0:	xor    r9d,r15d
    75b0bab003e3:	mov    QWORD PTR [r12+0xd0],r9
    75b0bab003eb:	add    ebp,r8d
    75b0bab003ee:	mov    QWORD PTR [r12+0xa8],rbp
    75b0bab003f6:	mov    ecx,DWORD PTR [r12+0xd8]
    75b0bab003fe:	mov    ecx,ecx
    75b0bab00400:	xor    r13d,ecx
    75b0bab00403:	mov    QWORD PTR [r12+0xb8],r13
    75b0bab0040b:	add    ebp,r14d
    75b0bab0040e:	mov    QWORD PTR [r12+0xa8],rbp
    75b0bab00416:	mov    r14,QWORD PTR [r12+0x88]
    75b0bab0041e:	add    r14,0x4
    75b0bab00422:	mov    QWORD PTR [r12+0x88],r14
    75b0bab0042a:	add    r13d,r9d
    75b0bab0042d:	mov    QWORD PTR [r12+0xb0],r13
    75b0bab00435:	mov    ecx,DWORD PTR [r12+0xc0]
    75b0bab0043d:	mov    ecx,ecx
    75b0bab0043f:	mov    r15d,ebp
    75b0bab00442:	add    r15d,ecx
    75b0bab00445:	mov    QWORD PTR [r12+0xb8],r15
    75b0bab0044d:	sub    r14,0x100
    75b0bab00454:	setne  BYTE PTR [rsp+0xb8]
    75b0bab0045c:	mov    r11,rax
    75b0bab0045f:	lahf
    75b0bab00460:	seto   al
    75b0bab00463:	mov    WORD PTR [rsp+0xb0],ax
    75b0bab0046b:	mov    rax,r11
    75b0bab0046e:	add    r13d,ebp
    75b0bab00471:	mov    QWORD PTR [r12+0xa8],r13
    75b0bab00479:	mov    r13d,0x0
    75b0bab0047f:	mov    ecx,DWORD PTR [r12+0xa0]
    75b0bab00487:	mov    ecx,ecx
    75b0bab00489:	mov    r14d,r13d
    75b0bab0048c:	or     r14d,ecx
    75b0bab0048f:	mov    QWORD PTR [r12+0xb0],r14
    75b0bab00497:	mov    r13d,0x0
    75b0bab0049d:	mov    ecx,DWORD PTR [r12+0x20]
    75b0bab004a2:	mov    ecx,ecx
    75b0bab004a4:	mov    r14d,r13d
    75b0bab004a7:	or     r14d,ecx
    75b0bab004aa:	mov    QWORD PTR [r12+0xc0],r14
    75b0bab004b2:	mov    r13d,0x0
    75b0bab004b8:	mov    ecx,DWORD PTR [r12+0x30]
    75b0bab004bd:	mov    ecx,ecx
    75b0bab004bf:	mov    r14d,r13d
    75b0bab004c2:	or     r14d,ecx
    75b0bab004c5:	mov    QWORD PTR [r12+0xc8],r14
    75b0bab004cd:	mov    rcx,QWORD PTR [r12+0x380]
    75b0bab004d5:	jrcxz  0x75b0bab004dc
    75b0bab004d7:	jmp    0x75b0bab008a2
    75b0bab004dc:	cmp    BYTE PTR [rsp+0xb8],0x0
    75b0bab004e4:	jne    0x75b0bab001cd
    75b0bab004ea:	jmp    0x75b0bab004ef
    75b0bab004ef:	mov    r13d,DWORD PTR [r12+0x70]
    75b0bab004f4:	mov    r14d,DWORD PTR [r12+0x98]
    75b0bab004fc:	add    r14d,r13d
    75b0bab004ff:	mov    QWORD PTR [r12+0x70],r14
    75b0bab00504:	mov    r13d,DWORD PTR [r12+0x68]
    75b0bab00509:	mov    r15d,DWORD PTR [r12+0x28]
    75b0bab0050e:	add    r15d,r13d
    75b0bab00511:	mov    QWORD PTR [r12+0x68],r15
    75b0bab00516:	mov    r13d,0x0
    75b0bab0051c:	mov    QWORD PTR [r12+0x88],r13
    75b0bab00524:	mov    r13d,DWORD PTR [r12+0x78]
    75b0bab00529:	mov    ebp,DWORD PTR [r12+0xa8]
    75b0bab00531:	add    ebp,r13d
    75b0bab00534:	mov    QWORD PTR [r12+0x78],rbp
    75b0bab00539:	mov    r13d,DWORD PTR [r12+0x80]
    75b0bab00541:	mov    r8d,DWORD PTR [r12+0x38]
    75b0bab00546:	add    r8d,r13d
    75b0bab00549:	mov    QWORD PTR [r12+0x80],r8
    75b0bab00551:	mov    rax,QWORD PTR [r12]
    75b0bab00555:	mov    r9,QWORD PTR [r12]
    75b0bab00559:	add    r9,0x8
    75b0bab0055d:	mov    r13,r9
    75b0bab00560:	add    r13,0x4
    75b0bab00564:	mov    DWORD PTR [r9],r14d
    75b0bab00567:	mov    r14d,0x0
    75b0bab0056d:	mov    DWORD PTR [r12+0x32c],r14d
    75b0bab00575:	mov    DWORD PTR [r13+0x0],r15d
    75b0bab00579:	mov    r13d,DWORD PTR [r12+0x18]
    75b0bab0057e:	mov    r14d,DWORD PTR [r12+0xb8]
    75b0bab00586:	add    r14d,r13d
    75b0bab00589:	mov    QWORD PTR [r12+0x68],r14
    75b0bab0058e:	mov    r13d,DWORD PTR [r12+0x90]
    75b0bab00596:	mov    r15d,DWORD PTR [r12+0x30]
    75b0bab0059b:	add    r15d,r13d
    75b0bab0059e:	mov    QWORD PTR [r12+0x70],r15
    75b0bab005a3:	mov    r13d,DWORD PTR [r12+0x58]
    75b0bab005a8:	mov    r9d,DWORD PTR [r12+0x20]
    75b0bab005ad:	mov    eax,r9d
    75b0bab005b0:	add    eax,r13d
    75b0bab005b3:	mov    QWORD PTR [r12+0x58],rax
    75b0bab005b8:	mov    r13d,DWORD PTR [r12+0x60]
    75b0bab005bd:	mov    r9d,DWORD PTR [r12+0xa0]
    75b0bab005c5:	add    r9d,r13d
    75b0bab005c8:	mov    QWORD PTR [r12+0x60],r9
    75b0bab005cd:	mov    r13,QWORD PTR [r12]
    75b0bab005d1:	add    r13,0x4
    75b0bab005d5:	mov    rdi,QWORD PTR [r12]
    75b0bab005d9:	mov    DWORD PTR [rdi],ebp
    75b0bab005db:	mov    DWORD PTR [r13+0x0],r8d
    75b0bab005df:	mov    r13,QWORD PTR [r12]
    75b0bab005e3:	add    r13,0x10
    75b0bab005e7:	mov    rbp,r13
    75b0bab005ea:	add    rbp,0x4
    75b0bab005ee:	mov    DWORD PTR [r13+0x0],r14d
    75b0bab005f2:	mov    DWORD PTR [rbp+0x0],r15d
    75b0bab005f6:	mov    r13,QWORD PTR [r12]
    75b0bab005fa:	add    r13,0x18
    75b0bab005fe:	mov    r14,r13
    75b0bab00601:	add    r14,0x4
    75b0bab00605:	mov    eax,DWORD PTR [r12+0x58]
    75b0bab0060a:	mov    DWORD PTR [r13+0x0],eax
    75b0bab0060e:	mov    DWORD PTR [r14],r9d
    75b0bab00611:	mov    r13,QWORD PTR [r12]
    75b0bab00615:	add    r13,0x68
    75b0bab00619:	mov    r14d,0x0
    75b0bab0061f:	mov    QWORD PTR [r13+0x0],r14
    75b0bab00623:	mov    rcx,QWORD PTR [r12+0x380]
    75b0bab0062b:	jrcxz  0x75b0bab00632
    75b0bab0062d:	jmp    0x75b0bab0092a
    75b0bab00632:	jmp    0x75b0bab00637
    75b0bab00637:	mov    r13,QWORD PTR [r12+0x10]
    75b0bab0063c:	sub    r13,0x1
    75b0bab00640:	mov    QWORD PTR [r12+0x10],r13
    75b0bab00645:	mov    rax,r13
    75b0bab00648:	test   rax,rax
    75b0bab0064b:	je     0x75b0bab00656
    75b0bab00651:	jmp    0x75b0baafe75a
    75b0bab00656:	mov    r13,QWORD PTR [r12+0xf8]
    75b0bab0065e:	mov    r14,r13
    75b0bab00661:	add    r14,0x140
    75b0bab00668:	mov    r15,r14
    75b0bab0066b:	add    r15,0x8
    75b0bab0066f:	mov    rbp,QWORD PTR [r14]
    75b0bab00672:	mov    r14,QWORD PTR [r15]
    75b0bab00675:	mov    QWORD PTR [r12+0xa0],rbp
    75b0bab0067d:	mov    QWORD PTR [r12+0x98],r14
    75b0bab00685:	mov    r14,r13
    75b0bab00688:	add    r14,0x130
    75b0bab0068f:	mov    r15,r14
    75b0bab00692:	add    r15,0x8
    75b0bab00696:	mov    rbp,QWORD PTR [r14]
    75b0bab00699:	mov    r14,QWORD PTR [r15]
    75b0bab0069c:	mov    QWORD PTR [r12+0xb0],rbp
    75b0bab006a4:	mov    QWORD PTR [r12+0xa8],r14
    75b0bab006ac:	mov    r14,r13
    75b0bab006af:	add    r14,0x120
    75b0bab006b6:	mov    r15,r14
    75b0bab006b9:	add    r15,0x8
    75b0bab006bd:	mov    rbp,QWORD PTR [r14]
    75b0bab006c0:	mov    r14,QWORD PTR [r15]
    75b0bab006c3:	mov    QWORD PTR [r12+0xc0],rbp
    75b0bab006cb:	mov    QWORD PTR [r12+0xb8],r14
    75b0bab006d3:	mov    r14,r13
    75b0bab006d6:	add    r14,0x110
    75b0bab006dd:	mov    r15,r14
    75b0bab006e0:	add    r15,0x8
    75b0bab006e4:	mov    rbp,QWORD PTR [r14]
    75b0bab006e7:	mov    r14,QWORD PTR [r15]
    75b0bab006ea:	mov    QWORD PTR [r12+0xd0],rbp
    75b0bab006f2:	mov    QWORD PTR [r12+0xc8],r14
    75b0bab006fa:	mov    r14,r13
    75b0bab006fd:	add    r14,0x100
    75b0bab00704:	mov    r15,r14
    75b0bab00707:	add    r15,0x8
    75b0bab0070b:	mov    rbp,QWORD PTR [r14]
    75b0bab0070e:	mov    r14,QWORD PTR [r15]
    75b0bab00711:	mov    QWORD PTR [r12+0xe8],rbp
    75b0bab00719:	mov    QWORD PTR [r12+0xd8],r14
    75b0bab00721:	add    r13,0x150
    75b0bab00728:	mov    QWORD PTR [r12+0xf8],r13
    75b0bab00730:	jmp    0x75b0bab00735
    75b0bab00735:	mov    rcx,QWORD PTR [r12+0x380]
    75b0bab0073d:	jrcxz  0x75b0bab00744
    75b0bab0073f:	jmp    0x75b0bab009b2
    75b0bab00744:	mov    r13,QWORD PTR [r12+0xf0]
    75b0bab0074c:	mov    QWORD PTR [r12+0x100],r13
    75b0bab00754:	mov    r11,QWORD PTR [rsp+0xb0]
    75b0bab0075c:	mov    QWORD PTR [r12+0x398],r11
    75b0bab00764:	mov    rdi,QWORD PTR [r12+0x100]
    75b0bab0076c:	add    rsp,0xc0
    75b0bab00773:	movabs r11,0x59d8f50c0940
    75b0bab0077d:	jmp    r11
    75b0bab00780:	mov    eax,0x41078c
    75b0bab00785:	mov    QWORD PTR [r12+0x100],rax
    75b0bab0078d:	push   rdx
    75b0bab0078e:	push   rsi
    75b0bab0078f:	push   r10
    75b0bab00791:	push   r11
    75b0bab00793:	mov    r11,rax
    75b0bab00796:	lahf
    75b0bab00797:	seto   al
    75b0bab0079a:	mov    WORD PTR [rsp+0xd0],ax
    75b0bab007a2:	mov    rax,r11
    75b0bab007a5:	mov    rdx,QWORD PTR [rsp+0xd0]
    75b0bab007ad:	mov    r10d,edx
    75b0bab007b0:	and    r10d,0xc000
    75b0bab007b7:	shl    r10d,0x10
    75b0bab007bb:	mov    r11d,edx
    75b0bab007be:	and    r11d,0x100
    75b0bab007c5:	shl    r11d,0x15
    75b0bab007c9:	or     r10d,r11d
    75b0bab007cc:	and    edx,0x1
    75b0bab007cf:	shl    edx,0x1c
    75b0bab007d2:	or     r10d,edx
    75b0bab007d5:	btc    r10,0x1d
    75b0bab007da:	mov    r11d,0xf0000000
    75b0bab007e0:	and    r11,r10
    75b0bab007e3:	movabs rsi,0xffffffff0fffffff
    75b0bab007ed:	and    rbx,rsi
    75b0bab007f0:	or     rbx,r11
    75b0bab007f3:	pop    r11
    75b0bab007f5:	pop    r10
    75b0bab007f7:	pop    rsi
    75b0bab007f8:	pop    rdx
    75b0bab007f9:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab00801:	add    rsp,0xc0
    75b0bab00808:	mov    eax,0xc
    75b0bab0080d:	movabs r11,0x59d8f50c0ca0
    75b0bab00817:	jmp    r11
    75b0bab0081a:	mov    eax,0x410888
    75b0bab0081f:	mov    QWORD PTR [r12+0x100],rax
    75b0bab00827:	push   rdx
    75b0bab00828:	push   rsi
    75b0bab00829:	push   r10
    75b0bab0082b:	push   r11
    75b0bab0082d:	mov    rdx,QWORD PTR [rsp+0xd0]
    75b0bab00835:	mov    r10d,edx
    75b0bab00838:	and    r10d,0xc000
    75b0bab0083f:	shl    r10d,0x10
    75b0bab00843:	mov    r11d,edx
    75b0bab00846:	and    r11d,0x100
    75b0bab0084d:	shl    r11d,0x15
    75b0bab00851:	or     r10d,r11d
    75b0bab00854:	and    edx,0x1
    75b0bab00857:	shl    edx,0x1c
    75b0bab0085a:	or     r10d,edx
    75b0bab0085d:	btc    r10,0x1d
    75b0bab00862:	mov    r11d,0xf0000000
    75b0bab00868:	and    r11,r10
    75b0bab0086b:	movabs rsi,0xffffffff0fffffff
    75b0bab00875:	and    rbx,rsi
    75b0bab00878:	or     rbx,r11
    75b0bab0087b:	pop    r11
    75b0bab0087d:	pop    r10
    75b0bab0087f:	pop    rsi
    75b0bab00880:	pop    rdx
    75b0bab00881:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab00889:	add    rsp,0xc0
    75b0bab00890:	mov    eax,0xc
    75b0bab00895:	movabs r11,0x59d8f50c0ca0
    75b0bab0089f:	jmp    r11
    75b0bab008a2:	mov    eax,0x410948
    75b0bab008a7:	mov    QWORD PTR [r12+0x100],rax
    75b0bab008af:	push   rdx
    75b0bab008b0:	push   rsi
    75b0bab008b1:	push   r10
    75b0bab008b3:	push   r11
    75b0bab008b5:	mov    rdx,QWORD PTR [rsp+0xd0]
    75b0bab008bd:	mov    r10d,edx
    75b0bab008c0:	and    r10d,0xc000
    75b0bab008c7:	shl    r10d,0x10
    75b0bab008cb:	mov    r11d,edx
    75b0bab008ce:	and    r11d,0x100
    75b0bab008d5:	shl    r11d,0x15
    75b0bab008d9:	or     r10d,r11d
    75b0bab008dc:	and    edx,0x1
    75b0bab008df:	shl    edx,0x1c
    75b0bab008e2:	or     r10d,edx
    75b0bab008e5:	btc    r10,0x1d
    75b0bab008ea:	mov    r11d,0xf0000000
    75b0bab008f0:	and    r11,r10
    75b0bab008f3:	movabs rsi,0xffffffff0fffffff
    75b0bab008fd:	and    rbx,rsi
    75b0bab00900:	or     rbx,r11
    75b0bab00903:	pop    r11
    75b0bab00905:	pop    r10
    75b0bab00907:	pop    rsi
    75b0bab00908:	pop    rdx
    75b0bab00909:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab00911:	add    rsp,0xc0
    75b0bab00918:	mov    eax,0xc
    75b0bab0091d:	movabs r11,0x59d8f50c0ca0
    75b0bab00927:	jmp    r11
    75b0bab0092a:	mov    eax,0x410984
    75b0bab0092f:	mov    QWORD PTR [r12+0x100],rax
    75b0bab00937:	push   rdx
    75b0bab00938:	push   rsi
    75b0bab00939:	push   r10
    75b0bab0093b:	push   r11
    75b0bab0093d:	mov    rdx,QWORD PTR [rsp+0xd0]
    75b0bab00945:	mov    r10d,edx
    75b0bab00948:	and    r10d,0xc000
    75b0bab0094f:	shl    r10d,0x10
    75b0bab00953:	mov    r11d,edx
    75b0bab00956:	and    r11d,0x100
    75b0bab0095d:	shl    r11d,0x15
    75b0bab00961:	or     r10d,r11d
    75b0bab00964:	and    edx,0x1
    75b0bab00967:	shl    edx,0x1c
    75b0bab0096a:	or     r10d,edx
    75b0bab0096d:	btc    r10,0x1d
    75b0bab00972:	mov    r11d,0xf0000000
    75b0bab00978:	and    r11,r10
    75b0bab0097b:	movabs rsi,0xffffffff0fffffff
    75b0bab00985:	and    rbx,rsi
    75b0bab00988:	or     rbx,r11
    75b0bab0098b:	pop    r11
    75b0bab0098d:	pop    r10
    75b0bab0098f:	pop    rsi
    75b0bab00990:	pop    rdx
    75b0bab00991:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab00999:	add    rsp,0xc0
    75b0bab009a0:	mov    eax,0xc
    75b0bab009a5:	movabs r11,0x59d8f50c0ca0
    75b0bab009af:	jmp    r11
    75b0bab009b2:	mov    eax,0x4109a0
    75b0bab009b7:	mov    QWORD PTR [r12+0x100],rax
    75b0bab009bf:	push   rdx
    75b0bab009c0:	push   rsi
    75b0bab009c1:	push   r10
    75b0bab009c3:	push   r11
    75b0bab009c5:	mov    rdx,QWORD PTR [rsp+0xd0]
    75b0bab009cd:	mov    r10d,edx
    75b0bab009d0:	and    r10d,0xc000
    75b0bab009d7:	shl    r10d,0x10
    75b0bab009db:	mov    r11d,edx
    75b0bab009de:	and    r11d,0x100
    75b0bab009e5:	shl    r11d,0x15
    75b0bab009e9:	or     r10d,r11d
    75b0bab009ec:	and    edx,0x1
    75b0bab009ef:	shl    edx,0x1c
    75b0bab009f2:	or     r10d,edx
    75b0bab009f5:	btc    r10,0x1d
    75b0bab009fa:	mov    r11d,0xf0000000
    75b0bab00a00:	and    r11,r10
    75b0bab00a03:	movabs rsi,0xffffffff0fffffff
    75b0bab00a0d:	and    rbx,rsi
    75b0bab00a10:	or     rbx,r11
    75b0bab00a13:	pop    r11
    75b0bab00a15:	pop    r10
    75b0bab00a17:	pop    rsi
    75b0bab00a18:	pop    rdx
    75b0bab00a19:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab00a21:	add    rsp,0xc0
    75b0bab00a28:	mov    eax,0xc
    75b0bab00a2d:	movabs r11,0x59d8f50c0ca0
    75b0bab00a37:	jmp    r11
    75b0bab00a3a:	nop    WORD PTR [rax+rax*1+0x0]
    75b0bab00a40:	sub    rsp,0xc0
    75b0bab00a47:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab00a4f:	mov    QWORD PTR [rsp+0xb0],r11
    75b0bab00a57:	jmp    0x75b0baafe639
    75b0bab00a5c:	nop    DWORD PTR [rax+0x0]
    75b0bab00a60:	sub    rsp,0xc0
    75b0bab00a67:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab00a6f:	mov    QWORD PTR [rsp+0xb0],r11
    75b0bab00a77:	jmp    0x75b0baafe75a
    75b0bab00a7c:	nop    DWORD PTR [rax+0x0]
    75b0bab00a80:	sub    rsp,0xc0
    75b0bab00a87:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab00a8f:	mov    QWORD PTR [rsp+0xb0],r11
    75b0bab00a97:	jmp    0x75b0baafe814
    75b0bab00a9c:	nop    DWORD PTR [rax+0x0]
    75b0bab00aa0:	sub    rsp,0xc0
    75b0bab00aa7:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab00aaf:	mov    QWORD PTR [rsp+0xb0],r11
    75b0bab00ab7:	jmp    0x75b0baaffef9
    75b0bab00abc:	nop    DWORD PTR [rax+0x0]
    75b0bab00ac0:	sub    rsp,0xc0
    75b0bab00ac7:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab00acf:	mov    QWORD PTR [rsp+0xb0],r11
    75b0bab00ad7:	jmp    0x75b0bab0004a
    75b0bab00adc:	nop    DWORD PTR [rax+0x0]
    75b0bab00ae0:	sub    rsp,0xc0
    75b0bab00ae7:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab00aef:	mov    QWORD PTR [rsp+0xb0],r11
    75b0bab00af7:	jmp    0x75b0bab001cd
    75b0bab00afc:	nop    DWORD PTR [rax+0x0]
    75b0bab00b00:	sub    rsp,0xc0
    75b0bab00b07:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab00b0f:	mov    QWORD PTR [rsp+0xb0],r11
    75b0bab00b17:	jmp    0x75b0bab004ef
    75b0bab00b1c:	nop    DWORD PTR [rax+0x0]
    75b0bab00b20:	sub    rsp,0xc0
    75b0bab00b27:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab00b2f:	mov    QWORD PTR [rsp+0xb0],r11
    75b0bab00b37:	jmp    0x75b0bab00637
    75b0bab00b3c:	nop    DWORD PTR [rax+0x0]
    75b0bab00b40:	sub    rsp,0xc0
    75b0bab00b47:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab00b4f:	mov    QWORD PTR [rsp+0xb0],r11
    75b0bab00b57:	jmp    0x75b0bab00656
    75b0bab00b5c:	nop    DWORD PTR [rax+0x0]
    75b0bab00b60:	sub    rsp,0xc0
    75b0bab00b67:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab00b6f:	mov    QWORD PTR [rsp+0xb0],r11
    75b0bab00b77:	jmp    0x75b0bab00735
