
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/1/7.bin:     file format binary


Disassembly of section .data:

000075b0bab01910 <.data>:
    75b0bab01910:	sub    rsp,0x10
    75b0bab01914:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab0191c:	mov    QWORD PTR [rsp],r11
    75b0bab01920:	mov    r13,QWORD PTR [r12+0xa0]
    75b0bab01928:	mov    r14,r13
    75b0bab0192b:	shl    r14,0x2
    75b0bab0192f:	mov    r15,QWORD PTR [r12+0x98]
    75b0bab01937:	add    r15,r14
    75b0bab0193a:	mov    r14d,DWORD PTR [r12]
    75b0bab0193e:	mov    DWORD PTR [r15],r14d
    75b0bab01941:	mov    r14d,0x0
    75b0bab01947:	mov    DWORD PTR [r12+0x32c],r14d
    75b0bab0194f:	add    r13,0x1
    75b0bab01953:	mov    QWORD PTR [r12+0xa0],r13
    75b0bab0195b:	sub    r13,0x400
    75b0bab01962:	mov    rcx,QWORD PTR [r12+0x380]
    75b0bab0196a:	jrcxz  0x75b0bab01971
    75b0bab0196c:	jmp    0x75b0bab01d4d
    75b0bab01971:	jne    0x75b0bab0198a
    75b0bab01977:	mov    r11,rax
    75b0bab0197a:	lahf
    75b0bab0197b:	seto   al
    75b0bab0197e:	mov    WORD PTR [rsp],ax
    75b0bab01982:	mov    rax,r11
    75b0bab01985:	jmp    0x75b0bab0199d
    75b0bab0198a:	mov    r11,rax
    75b0bab0198d:	lahf
    75b0bab0198e:	seto   al
    75b0bab01991:	mov    WORD PTR [rsp],ax
    75b0bab01995:	mov    rax,r11
    75b0bab01998:	jmp    0x75b0bab01cdd
    75b0bab0199d:	mov    r13d,0x1
    75b0bab019a3:	mov    QWORD PTR [r12+0x40],r13
    75b0bab019a8:	mov    r11,rax
    75b0bab019ab:	movzx  eax,WORD PTR [rsp]
    75b0bab019af:	add    al,0x7f
    75b0bab019b1:	sahf
    75b0bab019b2:	mov    rax,r11
    75b0bab019b5:	jmp    0x75b0bab019ba
    75b0bab019ba:	mov    r13,QWORD PTR [r12+0x40]
    75b0bab019bf:	mov    r14,r13
    75b0bab019c2:	lea    r14,[r14*4+0x0]
    75b0bab019ca:	mov    r15,QWORD PTR [r12+0x98]
    75b0bab019d2:	mov    r11,rax
    75b0bab019d5:	lahf
    75b0bab019d6:	seto   al
    75b0bab019d9:	mov    WORD PTR [rsp],ax
    75b0bab019dd:	mov    rax,r11
    75b0bab019e0:	add    r15,r14
    75b0bab019e3:	mov    r14d,DWORD PTR [r15]
    75b0bab019e6:	mov    QWORD PTR [r12+0x48],r14
    75b0bab019eb:	mov    r14d,0x0
    75b0bab019f1:	or     r14,r13
    75b0bab019f4:	mov    QWORD PTR [r12+0x50],r14
    75b0bab019f9:	jmp    0x75b0bab019fe
    75b0bab019fe:	mov    r13d,DWORD PTR [r12+0x50]
    75b0bab01a03:	sub    r13d,0x1
    75b0bab01a07:	mov    QWORD PTR [r12+0x58],r13
    75b0bab01a0c:	mov    ecx,0xffffffff
    75b0bab01a11:	mov    r14,r13
    75b0bab01a14:	and    r14,rcx
    75b0bab01a17:	shl    r14,0x2
    75b0bab01a1b:	mov    r13,QWORD PTR [r12+0x98]
    75b0bab01a23:	add    r13,r14
    75b0bab01a26:	mov    r14d,DWORD PTR [r13+0x0]
    75b0bab01a2a:	mov    QWORD PTR [r12+0x60],r14
    75b0bab01a2f:	mov    r13d,DWORD PTR [r12+0x48]
    75b0bab01a34:	sub    r14d,r13d
    75b0bab01a37:	mov    rcx,QWORD PTR [r12+0x380]
    75b0bab01a3f:	jrcxz  0x75b0bab01a46
    75b0bab01a41:	jmp    0x75b0bab01dde
    75b0bab01a46:	jbe    0x75b0bab01a5f
    75b0bab01a4c:	mov    r11,rax
    75b0bab01a4f:	lahf
    75b0bab01a50:	seto   al
    75b0bab01a53:	mov    WORD PTR [rsp],ax
    75b0bab01a57:	mov    rax,r11
    75b0bab01a5a:	jmp    0x75b0bab01a72
    75b0bab01a5f:	mov    r11,rax
    75b0bab01a62:	lahf
    75b0bab01a63:	seto   al
    75b0bab01a66:	mov    WORD PTR [rsp],ax
    75b0bab01a6a:	mov    rax,r11
    75b0bab01a6d:	jmp    0x75b0bab01af1
    75b0bab01a72:	mov    r13,QWORD PTR [r12+0x50]
    75b0bab01a77:	mov    r14,r13
    75b0bab01a7a:	shl    r14,0x2
    75b0bab01a7e:	mov    r15,QWORD PTR [r12+0x98]
    75b0bab01a86:	add    r15,r14
    75b0bab01a89:	mov    r14d,DWORD PTR [r12+0x60]
    75b0bab01a8e:	mov    DWORD PTR [r15],r14d
    75b0bab01a91:	mov    r14d,0x0
    75b0bab01a97:	mov    DWORD PTR [r12+0x32c],r14d
    75b0bab01a9f:	sub    r13,0x1
    75b0bab01aa3:	mov    QWORD PTR [r12+0x50],r13
    75b0bab01aa8:	mov    rcx,QWORD PTR [r12+0x380]
    75b0bab01ab0:	jrcxz  0x75b0bab01ab7
    75b0bab01ab2:	jmp    0x75b0bab01e6f
    75b0bab01ab7:	mov    r13,QWORD PTR [r12+0x58]
    75b0bab01abc:	mov    rax,r13
    75b0bab01abf:	test   rax,rax
    75b0bab01ac2:	jne    0x75b0bab019fe
    75b0bab01ac8:	jmp    0x75b0bab01acd
    75b0bab01acd:	mov    rcx,QWORD PTR [r12+0x380]
    75b0bab01ad5:	jrcxz  0x75b0bab01adc
    75b0bab01ad7:	jmp    0x75b0bab01ef1
    75b0bab01adc:	jmp    0x75b0bab01ae1
    75b0bab01ae1:	mov    r13d,0x0
    75b0bab01ae7:	mov    QWORD PTR [r12+0x50],r13
    75b0bab01aec:	jmp    0x75b0bab01af1
    75b0bab01af1:	mov    r13,QWORD PTR [r12+0x40]
    75b0bab01af6:	add    r13,0x1
    75b0bab01afa:	mov    QWORD PTR [r12+0x40],r13
    75b0bab01aff:	mov    r14,QWORD PTR [r12+0x50]
    75b0bab01b04:	mov    ecx,0xffffffff
    75b0bab01b09:	and    r14,rcx
    75b0bab01b0c:	shl    r14,0x2
    75b0bab01b10:	mov    r15,QWORD PTR [r12+0x98]
    75b0bab01b18:	add    r15,r14
    75b0bab01b1b:	mov    r14d,DWORD PTR [r12+0x48]
    75b0bab01b20:	mov    DWORD PTR [r15],r14d
    75b0bab01b23:	mov    r14d,0x0
    75b0bab01b29:	mov    DWORD PTR [r12+0x32c],r14d
    75b0bab01b31:	sub    r13,0x400
    75b0bab01b38:	jne    0x75b0bab019ba
    75b0bab01b3e:	mov    r11,rax
    75b0bab01b41:	lahf
    75b0bab01b42:	seto   al
    75b0bab01b45:	mov    WORD PTR [rsp],ax
    75b0bab01b49:	mov    rax,r11
    75b0bab01b4c:	jmp    0x75b0bab01b51
    75b0bab01b51:	mov    r13d,0x430000
    75b0bab01b57:	mov    QWORD PTR [r12+0x40],r13
    75b0bab01b5c:	mov    r13d,0x0
    75b0bab01b62:	mov    QWORD PTR [r12+0x58],r13
    75b0bab01b67:	mov    r13d,0x0
    75b0bab01b6d:	mov    QWORD PTR [r12+0x50],r13
    75b0bab01b72:	mov    r13d,0x430cb0
    75b0bab01b78:	mov    r14,QWORD PTR [r13+0x0]
    75b0bab01b7c:	mov    QWORD PTR [r12+0x48],r14
    75b0bab01b81:	jmp    0x75b0bab01b86
    75b0bab01b86:	mov    r13,QWORD PTR [r12+0x58]
    75b0bab01b8b:	mov    r14,r13
    75b0bab01b8e:	shl    r14,0x2
    75b0bab01b92:	mov    r15,QWORD PTR [r12+0x98]
    75b0bab01b9a:	add    r15,r14
    75b0bab01b9d:	mov    QWORD PTR [r12+0x60],r15
    75b0bab01ba2:	mov    r14,r15
    75b0bab01ba5:	add    r14,0x4
    75b0bab01ba9:	mov    ebp,DWORD PTR [r15]
    75b0bab01bac:	mov    r15d,DWORD PTR [r14]
    75b0bab01baf:	mov    QWORD PTR [r12+0x60],r15
    75b0bab01bb4:	mov    r14,rbp
    75b0bab01bb7:	imul   r14,r13
    75b0bab01bbb:	mov    r8,rbp
    75b0bab01bbe:	add    r8,r14
    75b0bab01bc1:	mov    QWORD PTR [r12+0x68],r8
    75b0bab01bc6:	add    r13,0x2
    75b0bab01bca:	mov    QWORD PTR [r12+0x58],r13
    75b0bab01bcf:	mov    r14,r13
    75b0bab01bd2:	sub    r14,0x400
    75b0bab01bd9:	mov    r14,QWORD PTR [r12+0x50]
    75b0bab01bde:	setne  BYTE PTR [rsp+0x8]
    75b0bab01be3:	mov    r11,rax
    75b0bab01be6:	lahf
    75b0bab01be7:	seto   al
    75b0bab01bea:	mov    WORD PTR [rsp],ax
    75b0bab01bee:	mov    rax,r11
    75b0bab01bf1:	imul   r13,r15
    75b0bab01bf5:	add    r14,r13
    75b0bab01bf8:	mov    QWORD PTR [r12+0x50],r14
    75b0bab01bfd:	mov    r13,QWORD PTR [r12+0x48]
    75b0bab01c02:	add    r8,r13
    75b0bab01c05:	mov    QWORD PTR [r12+0x48],r8
    75b0bab01c0a:	mov    rcx,QWORD PTR [r12+0x380]
    75b0bab01c12:	jrcxz  0x75b0bab01c19
    75b0bab01c14:	jmp    0x75b0bab01f73
    75b0bab01c19:	cmp    BYTE PTR [rsp+0x8],0x0
    75b0bab01c1e:	jne    0x75b0bab01b86
    75b0bab01c24:	jmp    0x75b0bab01c29
    75b0bab01c29:	mov    r13d,0x0
    75b0bab01c2f:	mov    QWORD PTR [r12+0x98],r13
    75b0bab01c37:	mov    r13,QWORD PTR [r12+0x48]
    75b0bab01c3c:	mov    r14,QWORD PTR [r12+0x50]
    75b0bab01c41:	add    r14,r13
    75b0bab01c44:	mov    QWORD PTR [r12+0x48],r14
    75b0bab01c49:	mov    r13d,0x1
    75b0bab01c4f:	mov    QWORD PTR [r12],r13
    75b0bab01c53:	mov    r13,QWORD PTR [r12+0x40]
    75b0bab01c58:	add    r13,0xcb0
    75b0bab01c5f:	mov    QWORD PTR [r13+0x0],r14
    75b0bab01c63:	mov    r13d,0x0
    75b0bab01c69:	mov    DWORD PTR [r12+0x32c],r13d
    75b0bab01c71:	mov    r13d,0x1
    75b0bab01c77:	mov    QWORD PTR [r12],r13
    75b0bab01c7b:	mov    r13d,0x4103f8
    75b0bab01c81:	mov    QWORD PTR [r12+0xf0],r13
    75b0bab01c89:	mov    r13d,0x4109a4
    75b0bab01c8f:	mov    QWORD PTR [r12+0x100],r13
    75b0bab01c97:	mov    r11,QWORD PTR [rsp]
    75b0bab01c9b:	mov    QWORD PTR [r12+0x398],r11
    75b0bab01ca3:	mov    edi,0x4109a4
    75b0bab01ca8:	mov    QWORD PTR [r12+0x100],rdi
    75b0bab01cb0:	add    rsp,0x10
    75b0bab01cb4:	nop    DWORD PTR [rax+0x0]
    75b0bab01cb8:	jmp    QWORD PTR [rip+0x2]        # 0x75b0bab01cc0
    75b0bab01cbe:	xchg   ax,ax
    75b0bab01cc0:	rex (bad)
    75b0bab01cc2:	mov    al,0xba
    75b0bab01cc4:	mov    al,0x75
    75b0bab01cc6:	add    BYTE PTR [rax],al
    75b0bab01cc8:	rcr    BYTE PTR [rax+rsi*4],1
    75b0bab01ccb:	mov    edx,0x75b0
    75b0bab01cd0:	movabs r11,0x59d8f50c0940
    75b0bab01cda:	jmp    r11
    75b0bab01cdd:	mov    r13d,DWORD PTR [r12+0xa0]
    75b0bab01ce5:	add    r13d,0x11
    75b0bab01ce9:	mov    QWORD PTR [r12],r13
    75b0bab01ced:	mov    r13d,0x41035c
    75b0bab01cf3:	mov    QWORD PTR [r12+0xf0],r13
    75b0bab01cfb:	mov    r13d,0x4109a4
    75b0bab01d01:	mov    QWORD PTR [r12+0x100],r13
    75b0bab01d09:	mov    r11,QWORD PTR [rsp]
    75b0bab01d0d:	mov    QWORD PTR [r12+0x398],r11
    75b0bab01d15:	mov    edi,0x4109a4
    75b0bab01d1a:	mov    QWORD PTR [r12+0x100],rdi
    75b0bab01d22:	add    rsp,0x10
    75b0bab01d26:	xchg   ax,ax
    75b0bab01d28:	jmp    QWORD PTR [rip+0x2]        # 0x75b0bab01d30
    75b0bab01d2e:	xchg   ax,ax
    75b0bab01d30:	rex (bad)
    75b0bab01d32:	mov    al,0xba
    75b0bab01d34:	mov    al,0x75
    75b0bab01d36:	add    BYTE PTR [rax],al
    75b0bab01d38:	rex sbb eax,0x75b0bab0
    75b0bab01d3e:	add    BYTE PTR [rax],al
    75b0bab01d40:	movabs r11,0x59d8f50c0940
    75b0bab01d4a:	jmp    r11
    75b0bab01d4d:	mov    eax,0x410368
    75b0bab01d52:	mov    QWORD PTR [r12+0x100],rax
    75b0bab01d5a:	push   rdx
    75b0bab01d5b:	push   rsi
    75b0bab01d5c:	push   r10
    75b0bab01d5e:	push   r11
    75b0bab01d60:	mov    r11,rax
    75b0bab01d63:	lahf
    75b0bab01d64:	seto   al
    75b0bab01d67:	mov    WORD PTR [rsp+0x20],ax
    75b0bab01d6c:	mov    rax,r11
    75b0bab01d6f:	mov    rdx,QWORD PTR [rsp+0x20]
    75b0bab01d74:	mov    r10d,edx
    75b0bab01d77:	and    r10d,0xc000
    75b0bab01d7e:	shl    r10d,0x10
    75b0bab01d82:	mov    r11d,edx
    75b0bab01d85:	and    r11d,0x100
    75b0bab01d8c:	shl    r11d,0x15
    75b0bab01d90:	or     r10d,r11d
    75b0bab01d93:	and    edx,0x1
    75b0bab01d96:	shl    edx,0x1c
    75b0bab01d99:	or     r10d,edx
    75b0bab01d9c:	btc    r10,0x1d
    75b0bab01da1:	mov    r11d,0xf0000000
    75b0bab01da7:	and    r11,r10
    75b0bab01daa:	movabs rsi,0xffffffff0fffffff
    75b0bab01db4:	and    rbx,rsi
    75b0bab01db7:	or     rbx,r11
    75b0bab01dba:	pop    r11
    75b0bab01dbc:	pop    r10
    75b0bab01dbe:	pop    rsi
    75b0bab01dbf:	pop    rdx
    75b0bab01dc0:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab01dc8:	add    rsp,0x10
    75b0bab01dcc:	mov    eax,0xc
    75b0bab01dd1:	movabs r11,0x59d8f50c0ca0
    75b0bab01ddb:	jmp    r11
    75b0bab01dde:	mov    eax,0x41039c
    75b0bab01de3:	mov    QWORD PTR [r12+0x100],rax
    75b0bab01deb:	push   rdx
    75b0bab01dec:	push   rsi
    75b0bab01ded:	push   r10
    75b0bab01def:	push   r11
    75b0bab01df1:	mov    r11,rax
    75b0bab01df4:	lahf
    75b0bab01df5:	seto   al
    75b0bab01df8:	mov    WORD PTR [rsp+0x20],ax
    75b0bab01dfd:	mov    rax,r11
    75b0bab01e00:	mov    rdx,QWORD PTR [rsp+0x20]
    75b0bab01e05:	mov    r10d,edx
    75b0bab01e08:	and    r10d,0xc000
    75b0bab01e0f:	shl    r10d,0x10
    75b0bab01e13:	mov    r11d,edx
    75b0bab01e16:	and    r11d,0x100
    75b0bab01e1d:	shl    r11d,0x15
    75b0bab01e21:	or     r10d,r11d
    75b0bab01e24:	and    edx,0x1
    75b0bab01e27:	shl    edx,0x1c
    75b0bab01e2a:	or     r10d,edx
    75b0bab01e2d:	btc    r10,0x1d
    75b0bab01e32:	mov    r11d,0xf0000000
    75b0bab01e38:	and    r11,r10
    75b0bab01e3b:	movabs rsi,0xffffffff0fffffff
    75b0bab01e45:	and    rbx,rsi
    75b0bab01e48:	or     rbx,r11
    75b0bab01e4b:	pop    r11
    75b0bab01e4d:	pop    r10
    75b0bab01e4f:	pop    rsi
    75b0bab01e50:	pop    rdx
    75b0bab01e51:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab01e59:	add    rsp,0x10
    75b0bab01e5d:	mov    eax,0xc
    75b0bab01e62:	movabs r11,0x59d8f50c0ca0
    75b0bab01e6c:	jmp    r11
    75b0bab01e6f:	mov    eax,0x4103a8
    75b0bab01e74:	mov    QWORD PTR [r12+0x100],rax
    75b0bab01e7c:	push   rdx
    75b0bab01e7d:	push   rsi
    75b0bab01e7e:	push   r10
    75b0bab01e80:	push   r11
    75b0bab01e82:	mov    rdx,QWORD PTR [rsp+0x20]
    75b0bab01e87:	mov    r10d,edx
    75b0bab01e8a:	and    r10d,0xc000
    75b0bab01e91:	shl    r10d,0x10
    75b0bab01e95:	mov    r11d,edx
    75b0bab01e98:	and    r11d,0x100
    75b0bab01e9f:	shl    r11d,0x15
    75b0bab01ea3:	or     r10d,r11d
    75b0bab01ea6:	and    edx,0x1
    75b0bab01ea9:	shl    edx,0x1c
    75b0bab01eac:	or     r10d,edx
    75b0bab01eaf:	btc    r10,0x1d
    75b0bab01eb4:	mov    r11d,0xf0000000
    75b0bab01eba:	and    r11,r10
    75b0bab01ebd:	movabs rsi,0xffffffff0fffffff
    75b0bab01ec7:	and    rbx,rsi
    75b0bab01eca:	or     rbx,r11
    75b0bab01ecd:	pop    r11
    75b0bab01ecf:	pop    r10
    75b0bab01ed1:	pop    rsi
    75b0bab01ed2:	pop    rdx
    75b0bab01ed3:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab01edb:	add    rsp,0x10
    75b0bab01edf:	mov    eax,0xc
    75b0bab01ee4:	movabs r11,0x59d8f50c0ca0
    75b0bab01eee:	jmp    r11
    75b0bab01ef1:	mov    eax,0x4103ac
    75b0bab01ef6:	mov    QWORD PTR [r12+0x100],rax
    75b0bab01efe:	push   rdx
    75b0bab01eff:	push   rsi
    75b0bab01f00:	push   r10
    75b0bab01f02:	push   r11
    75b0bab01f04:	mov    rdx,QWORD PTR [rsp+0x20]
    75b0bab01f09:	mov    r10d,edx
    75b0bab01f0c:	and    r10d,0xc000
    75b0bab01f13:	shl    r10d,0x10
    75b0bab01f17:	mov    r11d,edx
    75b0bab01f1a:	and    r11d,0x100
    75b0bab01f21:	shl    r11d,0x15
    75b0bab01f25:	or     r10d,r11d
    75b0bab01f28:	and    edx,0x1
    75b0bab01f2b:	shl    edx,0x1c
    75b0bab01f2e:	or     r10d,edx
    75b0bab01f31:	btc    r10,0x1d
    75b0bab01f36:	mov    r11d,0xf0000000
    75b0bab01f3c:	and    r11,r10
    75b0bab01f3f:	movabs rsi,0xffffffff0fffffff
    75b0bab01f49:	and    rbx,rsi
    75b0bab01f4c:	or     rbx,r11
    75b0bab01f4f:	pop    r11
    75b0bab01f51:	pop    r10
    75b0bab01f53:	pop    rsi
    75b0bab01f54:	pop    rdx
    75b0bab01f55:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab01f5d:	add    rsp,0x10
    75b0bab01f61:	mov    eax,0xc
    75b0bab01f66:	movabs r11,0x59d8f50c0ca0
    75b0bab01f70:	jmp    r11
    75b0bab01f73:	mov    eax,0x4103dc
    75b0bab01f78:	mov    QWORD PTR [r12+0x100],rax
    75b0bab01f80:	push   rdx
    75b0bab01f81:	push   rsi
    75b0bab01f82:	push   r10
    75b0bab01f84:	push   r11
    75b0bab01f86:	mov    rdx,QWORD PTR [rsp+0x20]
    75b0bab01f8b:	mov    r10d,edx
    75b0bab01f8e:	and    r10d,0xc000
    75b0bab01f95:	shl    r10d,0x10
    75b0bab01f99:	mov    r11d,edx
    75b0bab01f9c:	and    r11d,0x100
    75b0bab01fa3:	shl    r11d,0x15
    75b0bab01fa7:	or     r10d,r11d
    75b0bab01faa:	and    edx,0x1
    75b0bab01fad:	shl    edx,0x1c
    75b0bab01fb0:	or     r10d,edx
    75b0bab01fb3:	btc    r10,0x1d
    75b0bab01fb8:	mov    r11d,0xf0000000
    75b0bab01fbe:	and    r11,r10
    75b0bab01fc1:	movabs rsi,0xffffffff0fffffff
    75b0bab01fcb:	and    rbx,rsi
    75b0bab01fce:	or     rbx,r11
    75b0bab01fd1:	pop    r11
    75b0bab01fd3:	pop    r10
    75b0bab01fd5:	pop    rsi
    75b0bab01fd6:	pop    rdx
    75b0bab01fd7:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab01fdf:	add    rsp,0x10
    75b0bab01fe3:	mov    eax,0xc
    75b0bab01fe8:	movabs r11,0x59d8f50c0ca0
    75b0bab01ff2:	jmp    r11
    75b0bab01ff5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab02000:	sub    rsp,0x10
    75b0bab02004:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab0200c:	mov    QWORD PTR [rsp],r11
    75b0bab02010:	jmp    0x75b0bab0199d
    75b0bab02015:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab02020:	sub    rsp,0x10
    75b0bab02024:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab0202c:	mov    QWORD PTR [rsp],r11
    75b0bab02030:	mov    r11,rax
    75b0bab02033:	movzx  eax,WORD PTR [rsp]
    75b0bab02037:	add    al,0x7f
    75b0bab02039:	sahf
    75b0bab0203a:	mov    rax,r11
    75b0bab0203d:	jmp    0x75b0bab019ba
    75b0bab02042:	data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab02050:	sub    rsp,0x10
    75b0bab02054:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab0205c:	mov    QWORD PTR [rsp],r11
    75b0bab02060:	jmp    0x75b0bab019fe
    75b0bab02065:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab02070:	sub    rsp,0x10
    75b0bab02074:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab0207c:	mov    QWORD PTR [rsp],r11
    75b0bab02080:	jmp    0x75b0bab01a72
    75b0bab02085:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab02090:	sub    rsp,0x10
    75b0bab02094:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab0209c:	mov    QWORD PTR [rsp],r11
    75b0bab020a0:	jmp    0x75b0bab01acd
    75b0bab020a5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab020b0:	sub    rsp,0x10
    75b0bab020b4:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab020bc:	mov    QWORD PTR [rsp],r11
    75b0bab020c0:	jmp    0x75b0bab01ae1
    75b0bab020c5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab020d0:	sub    rsp,0x10
    75b0bab020d4:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab020dc:	mov    QWORD PTR [rsp],r11
    75b0bab020e0:	jmp    0x75b0bab01af1
    75b0bab020e5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab020f0:	sub    rsp,0x10
    75b0bab020f4:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab020fc:	mov    QWORD PTR [rsp],r11
    75b0bab02100:	jmp    0x75b0bab01b51
    75b0bab02105:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab02110:	sub    rsp,0x10
    75b0bab02114:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab0211c:	mov    QWORD PTR [rsp],r11
    75b0bab02120:	jmp    0x75b0bab01b86
    75b0bab02125:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab02130:	sub    rsp,0x10
    75b0bab02134:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab0213c:	mov    QWORD PTR [rsp],r11
    75b0bab02140:	jmp    0x75b0bab01c29
    75b0bab02145:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    75b0bab02150:	sub    rsp,0x10
    75b0bab02154:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab0215c:	mov    QWORD PTR [rsp],r11
    75b0bab02160:	jmp    0x75b0bab01cdd
    75b0bab02165:	nop
    75b0bab02166:	nop
    75b0bab02167:	nop
