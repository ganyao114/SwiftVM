
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/0/1.bin:     file format binary


Disassembly of section .data:

000074a37e4fe5e0 <.data>:
    74a37e4fe5e0:	sub    rsp,0xc0
    74a37e4fe5e7:	mov    r11,QWORD PTR [r12+0x398]
    74a37e4fe5ef:	mov    QWORD PTR [rsp+0xb0],r11
    74a37e4fe5f7:	mov    r13,QWORD PTR [r12]
    74a37e4fe5fb:	mov    r14,r13
    74a37e4fe5fe:	add    r14,0x20
    74a37e4fe602:	mov    r15,QWORD PTR [r14]
    74a37e4fe605:	mov    r14,QWORD PTR [r12+0x10]
    74a37e4fe60a:	add    r15,r14
    74a37e4fe60d:	mov    QWORD PTR [r12+0x40],r15
    74a37e4fe612:	add    r13,0x20
    74a37e4fe616:	mov    QWORD PTR [r13+0x0],r15
    74a37e4fe61a:	mov    r13d,0x0
    74a37e4fe620:	mov    DWORD PTR [r12+0x32c],r13d
    74a37e4fe628:	mov    rax,r14
    74a37e4fe62b:	test   rax,rax
    74a37e4fe62e:	je     0x74a37e500735
    74a37e4fe634:	jmp    0x74a37e4fe639
    74a37e4fe639:	mov    r13,QWORD PTR [r12+0xf8]
    74a37e4fe641:	sub    r13,0x150
    74a37e4fe648:	mov    QWORD PTR [r12+0xf8],r13
    74a37e4fe650:	mov    r14,QWORD PTR [r12]
    74a37e4fe654:	mov    r15,r14
    74a37e4fe657:	add    r15,0x68
    74a37e4fe65b:	mov    rbp,QWORD PTR [r15]
    74a37e4fe65e:	mov    QWORD PTR [r12+0x88],rbp
    74a37e4fe666:	add    r14,0x28
    74a37e4fe66a:	mov    QWORD PTR [r12+0x40],r14
    74a37e4fe66f:	mov    QWORD PTR [r12+0x48],r13
    74a37e4fe674:	mov    r14d,0x420000
    74a37e4fe67a:	add    r14,0xb90
    74a37e4fe681:	mov    QWORD PTR [r12+0x50],r14
    74a37e4fe686:	mov    r14,r13
    74a37e4fe689:	add    r14,0x100
    74a37e4fe690:	mov    r15,r14
    74a37e4fe693:	add    r15,0x8
    74a37e4fe697:	mov    rbp,QWORD PTR [r12+0xe8]
    74a37e4fe69f:	mov    r8,QWORD PTR [r12+0xd8]
    74a37e4fe6a7:	mov    QWORD PTR [r14],rbp
    74a37e4fe6aa:	mov    r14d,0x0
    74a37e4fe6b0:	mov    DWORD PTR [r12+0x32c],r14d
    74a37e4fe6b8:	mov    QWORD PTR [r15],r8
    74a37e4fe6bb:	mov    r14,r13
    74a37e4fe6be:	add    r14,0x110
    74a37e4fe6c5:	mov    r15,r14
    74a37e4fe6c8:	add    r15,0x8
    74a37e4fe6cc:	mov    rbp,QWORD PTR [r12+0xd0]
    74a37e4fe6d4:	mov    r8,QWORD PTR [r12+0xc8]
    74a37e4fe6dc:	mov    QWORD PTR [r14],rbp
    74a37e4fe6df:	mov    QWORD PTR [r15],r8
    74a37e4fe6e2:	mov    r14,r13
    74a37e4fe6e5:	add    r14,0x120
    74a37e4fe6ec:	mov    r15,r14
    74a37e4fe6ef:	add    r15,0x8
    74a37e4fe6f3:	mov    rbp,QWORD PTR [r12+0xc0]
    74a37e4fe6fb:	mov    r8,QWORD PTR [r12+0xb8]
    74a37e4fe703:	mov    QWORD PTR [r14],rbp
    74a37e4fe706:	mov    QWORD PTR [r15],r8
    74a37e4fe709:	mov    r14,r13
    74a37e4fe70c:	add    r14,0x130
    74a37e4fe713:	mov    r15,r14
    74a37e4fe716:	add    r15,0x8
    74a37e4fe71a:	mov    rbp,QWORD PTR [r12+0xb0]
    74a37e4fe722:	mov    r8,QWORD PTR [r12+0xa8]
    74a37e4fe72a:	mov    QWORD PTR [r14],rbp
    74a37e4fe72d:	mov    QWORD PTR [r15],r8
    74a37e4fe730:	add    r13,0x140
    74a37e4fe737:	mov    r14,r13
    74a37e4fe73a:	add    r14,0x8
    74a37e4fe73e:	mov    r15,QWORD PTR [r12+0xa0]
    74a37e4fe746:	mov    rbp,QWORD PTR [r12+0x98]
    74a37e4fe74e:	mov    QWORD PTR [r13+0x0],r15
    74a37e4fe752:	mov    QWORD PTR [r14],rbp
    74a37e4fe755:	jmp    0x74a37e4fe75a
    74a37e4fe75a:	mov    r13,QWORD PTR [r12+0x8]
    74a37e4fe75f:	mov    r14,r13
    74a37e4fe762:	add    r14,0x1
    74a37e4fe766:	movzx  r15d,BYTE PTR [r13+0x0]
    74a37e4fe76b:	mov    QWORD PTR [r12+0x58],r15
    74a37e4fe770:	mov    QWORD PTR [r12+0x8],r14
    74a37e4fe775:	mov    r13,QWORD PTR [r12+0x88]
    74a37e4fe77d:	mov    r14,r13
    74a37e4fe780:	add    r14,0x1
    74a37e4fe784:	mov    QWORD PTR [r12+0x60],r14
    74a37e4fe789:	mov    r15,QWORD PTR [r12]
    74a37e4fe78d:	mov    rbp,r15
    74a37e4fe790:	add    rbp,0x68
    74a37e4fe794:	mov    QWORD PTR [rbp+0x0],r14
    74a37e4fe798:	mov    r14d,0x0
    74a37e4fe79e:	mov    DWORD PTR [r12+0x32c],r14d
    74a37e4fe7a6:	mov    r14,r15
    74a37e4fe7a9:	add    r14,r13
    74a37e4fe7ac:	mov    QWORD PTR [r12+0x60],r14
    74a37e4fe7b1:	add    r14,0x28
    74a37e4fe7b5:	movzx  r13d,BYTE PTR [r12+0x58]
    74a37e4fe7bb:	mov    BYTE PTR [r14],r13b
    74a37e4fe7be:	add    r15,0x68
    74a37e4fe7c2:	mov    r13,QWORD PTR [r15]
    74a37e4fe7c5:	mov    QWORD PTR [r12+0x88],r13
    74a37e4fe7cd:	sub    r13,0x40
    74a37e4fe7d1:	mov    rcx,QWORD PTR [r12+0x380]
    74a37e4fe7d9:	jrcxz  0x74a37e4fe7e0
    74a37e4fe7db:	jmp    0x74a37e500780
    74a37e4fe7e0:	jne    0x74a37e4fe7fd
    74a37e4fe7e6:	mov    r11,rax
    74a37e4fe7e9:	lahf
    74a37e4fe7ea:	seto   al
    74a37e4fe7ed:	mov    WORD PTR [rsp+0xb0],ax
    74a37e4fe7f5:	mov    rax,r11
    74a37e4fe7f8:	jmp    0x74a37e4fe814
    74a37e4fe7fd:	mov    r11,rax
    74a37e4fe800:	lahf
    74a37e4fe801:	seto   al
    74a37e4fe804:	mov    WORD PTR [rsp+0xb0],ax
    74a37e4fe80c:	mov    rax,r11
    74a37e4fe80f:	jmp    0x74a37e500637
    74a37e4fe814:	mov    rax,QWORD PTR [r12+0x40]
    74a37e4fe819:	mov    eax,0x0
    74a37e4fe81e:	mov    QWORD PTR [rsp+0x18],rax
    74a37e4fe823:	mov    eax,0x0
    74a37e4fe828:	mov    QWORD PTR [rsp+0x10],rax
    74a37e4fe82d:	mov    eax,0x0
    74a37e4fe832:	mov    QWORD PTR [rsp+0x8],rax
    74a37e4fe837:	mov    eax,0x0
    74a37e4fe83c:	mov    QWORD PTR [rsp],rax
    74a37e4fe840:	mov    rdi,QWORD PTR [r12+0x40]
    74a37e4fe845:	movzx  r9d,BYTE PTR [rdi]
    74a37e4fe849:	mov    r13,QWORD PTR [rsp+0x18]
    74a37e4fe84e:	or     r13,r9
    74a37e4fe851:	mov    r9,QWORD PTR [r12+0x40]
    74a37e4fe856:	add    r9,0x1
    74a37e4fe85a:	movzx  r8d,BYTE PTR [r9]
    74a37e4fe85e:	mov    r9,QWORD PTR [rsp+0x10]
    74a37e4fe863:	or     r9,r8
    74a37e4fe866:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4fe86b:	add    r8,0x2
    74a37e4fe86f:	movzx  ebp,BYTE PTR [r8]
    74a37e4fe873:	mov    r8,QWORD PTR [rsp+0x8]
    74a37e4fe878:	or     r8,rbp
    74a37e4fe87b:	mov    rbp,QWORD PTR [r12+0x40]
    74a37e4fe880:	add    rbp,0x3
    74a37e4fe884:	movzx  r15d,BYTE PTR [rbp+0x0]
    74a37e4fe889:	mov    rbp,QWORD PTR [rsp]
    74a37e4fe88d:	or     rbp,r15
    74a37e4fe890:	mov    r15,QWORD PTR [r12+0x40]
    74a37e4fe895:	add    r15,0x4
    74a37e4fe899:	movzx  r14d,BYTE PTR [r15]
    74a37e4fe89d:	mov    r15,r14
    74a37e4fe8a0:	shl    r15,0x8
    74a37e4fe8a4:	or     r13,r15
    74a37e4fe8a7:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4fe8ac:	add    r14,0x5
    74a37e4fe8b0:	movzx  r15d,BYTE PTR [r14]
    74a37e4fe8b4:	mov    r14,r15
    74a37e4fe8b7:	shl    r14,0x8
    74a37e4fe8bb:	or     r9,r14
    74a37e4fe8be:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4fe8c3:	add    r14,0x6
    74a37e4fe8c7:	movzx  r15d,BYTE PTR [r14]
    74a37e4fe8cb:	mov    r14,r15
    74a37e4fe8ce:	shl    r14,0x8
    74a37e4fe8d2:	or     r8,r14
    74a37e4fe8d5:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4fe8da:	add    r14,0x7
    74a37e4fe8de:	movzx  r15d,BYTE PTR [r14]
    74a37e4fe8e2:	mov    r14,r15
    74a37e4fe8e5:	shl    r14,0x8
    74a37e4fe8e9:	or     rbp,r14
    74a37e4fe8ec:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4fe8f1:	add    r14,0x8
    74a37e4fe8f5:	movzx  r15d,BYTE PTR [r14]
    74a37e4fe8f9:	mov    r14,r15
    74a37e4fe8fc:	shl    r14,0x10
    74a37e4fe900:	or     r13,r14
    74a37e4fe903:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4fe908:	add    r14,0x9
    74a37e4fe90c:	movzx  r15d,BYTE PTR [r14]
    74a37e4fe910:	mov    r14,r15
    74a37e4fe913:	shl    r14,0x10
    74a37e4fe917:	or     r9,r14
    74a37e4fe91a:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4fe91f:	add    r14,0xa
    74a37e4fe923:	movzx  r15d,BYTE PTR [r14]
    74a37e4fe927:	mov    r14,r15
    74a37e4fe92a:	shl    r14,0x10
    74a37e4fe92e:	or     r8,r14
    74a37e4fe931:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4fe936:	add    r14,0xb
    74a37e4fe93a:	movzx  r15d,BYTE PTR [r14]
    74a37e4fe93e:	mov    r14,r15
    74a37e4fe941:	shl    r14,0x10
    74a37e4fe945:	or     rbp,r14
    74a37e4fe948:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4fe94d:	add    r14,0xc
    74a37e4fe951:	movzx  r15d,BYTE PTR [r14]
    74a37e4fe955:	mov    r14,r15
    74a37e4fe958:	shl    r14,0x18
    74a37e4fe95c:	or     r13,r14
    74a37e4fe95f:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4fe964:	add    r14,0xd
    74a37e4fe968:	movzx  r15d,BYTE PTR [r14]
    74a37e4fe96c:	mov    r14,r15
    74a37e4fe96f:	shl    r14,0x18
    74a37e4fe973:	or     r9,r14
    74a37e4fe976:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4fe97b:	add    r14,0xe
    74a37e4fe97f:	movzx  r15d,BYTE PTR [r14]
    74a37e4fe983:	mov    r14,r15
    74a37e4fe986:	shl    r14,0x18
    74a37e4fe98a:	or     r8,r14
    74a37e4fe98d:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4fe992:	add    r14,0xf
    74a37e4fe996:	movzx  r15d,BYTE PTR [r14]
    74a37e4fe99a:	mov    r14,r15
    74a37e4fe99d:	shl    r14,0x18
    74a37e4fe9a1:	or     rbp,r14
    74a37e4fe9a4:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4fe9a9:	add    r14,0x10
    74a37e4fe9ad:	movzx  r15d,BYTE PTR [r14]
    74a37e4fe9b1:	mov    r14,r15
    74a37e4fe9b4:	shl    r14,0x20
    74a37e4fe9b8:	or     r13,r14
    74a37e4fe9bb:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4fe9c0:	add    r14,0x11
    74a37e4fe9c4:	movzx  r15d,BYTE PTR [r14]
    74a37e4fe9c8:	mov    r14,r15
    74a37e4fe9cb:	shl    r14,0x20
    74a37e4fe9cf:	or     r9,r14
    74a37e4fe9d2:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4fe9d7:	add    r14,0x12
    74a37e4fe9db:	movzx  r15d,BYTE PTR [r14]
    74a37e4fe9df:	mov    r14,r15
    74a37e4fe9e2:	shl    r14,0x20
    74a37e4fe9e6:	or     r8,r14
    74a37e4fe9e9:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4fe9ee:	add    r14,0x13
    74a37e4fe9f2:	movzx  r15d,BYTE PTR [r14]
    74a37e4fe9f6:	mov    r14,r15
    74a37e4fe9f9:	shl    r14,0x20
    74a37e4fe9fd:	or     rbp,r14
    74a37e4fea00:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4fea05:	add    r14,0x14
    74a37e4fea09:	movzx  r15d,BYTE PTR [r14]
    74a37e4fea0d:	mov    r14,r15
    74a37e4fea10:	shl    r14,0x28
    74a37e4fea14:	or     r13,r14
    74a37e4fea17:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4fea1c:	add    r14,0x15
    74a37e4fea20:	movzx  r15d,BYTE PTR [r14]
    74a37e4fea24:	mov    r14,r15
    74a37e4fea27:	shl    r14,0x28
    74a37e4fea2b:	or     r9,r14
    74a37e4fea2e:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4fea33:	add    r14,0x16
    74a37e4fea37:	movzx  r15d,BYTE PTR [r14]
    74a37e4fea3b:	mov    r14,r15
    74a37e4fea3e:	shl    r14,0x28
    74a37e4fea42:	or     r8,r14
    74a37e4fea45:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4fea4a:	add    r14,0x17
    74a37e4fea4e:	movzx  r15d,BYTE PTR [r14]
    74a37e4fea52:	mov    r14,r15
    74a37e4fea55:	shl    r14,0x28
    74a37e4fea59:	or     rbp,r14
    74a37e4fea5c:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4fea61:	add    r14,0x18
    74a37e4fea65:	movzx  r15d,BYTE PTR [r14]
    74a37e4fea69:	mov    r14,r15
    74a37e4fea6c:	shl    r14,0x30
    74a37e4fea70:	or     r13,r14
    74a37e4fea73:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4fea78:	add    r14,0x19
    74a37e4fea7c:	movzx  r15d,BYTE PTR [r14]
    74a37e4fea80:	mov    r14,r15
    74a37e4fea83:	shl    r14,0x30
    74a37e4fea87:	or     r9,r14
    74a37e4fea8a:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4fea8f:	add    r14,0x1a
    74a37e4fea93:	movzx  r15d,BYTE PTR [r14]
    74a37e4fea97:	mov    r14,r15
    74a37e4fea9a:	shl    r14,0x30
    74a37e4fea9e:	or     r8,r14
    74a37e4feaa1:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4feaa6:	add    r14,0x1b
    74a37e4feaaa:	movzx  r15d,BYTE PTR [r14]
    74a37e4feaae:	mov    r14,r15
    74a37e4feab1:	shl    r14,0x30
    74a37e4feab5:	or     rbp,r14
    74a37e4feab8:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4feabd:	add    r14,0x1c
    74a37e4feac1:	movzx  r15d,BYTE PTR [r14]
    74a37e4feac5:	mov    r14,r15
    74a37e4feac8:	shl    r14,0x38
    74a37e4feacc:	mov    rax,r13
    74a37e4feacf:	or     rax,r14
    74a37e4fead2:	mov    QWORD PTR [rsp+0x28],rax
    74a37e4fead7:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4feadc:	add    r14,0x1d
    74a37e4feae0:	movzx  r15d,BYTE PTR [r14]
    74a37e4feae4:	mov    r14,r15
    74a37e4feae7:	shl    r14,0x38
    74a37e4feaeb:	mov    rax,r9
    74a37e4feaee:	or     rax,r14
    74a37e4feaf1:	mov    QWORD PTR [rsp+0x38],rax
    74a37e4feaf6:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4feafb:	add    r14,0x1e
    74a37e4feaff:	movzx  r15d,BYTE PTR [r14]
    74a37e4feb03:	mov    r14,r15
    74a37e4feb06:	shl    r14,0x38
    74a37e4feb0a:	mov    rax,r8
    74a37e4feb0d:	or     rax,r14
    74a37e4feb10:	mov    QWORD PTR [rsp+0x30],rax
    74a37e4feb15:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4feb1a:	add    r14,0x1f
    74a37e4feb1e:	movzx  r15d,BYTE PTR [r14]
    74a37e4feb22:	mov    r14,r15
    74a37e4feb25:	shl    r14,0x38
    74a37e4feb29:	mov    rax,rbp
    74a37e4feb2c:	or     rax,r14
    74a37e4feb2f:	mov    QWORD PTR [rsp+0x20],rax
    74a37e4feb34:	mov    r14,QWORD PTR [r12+0x40]
    74a37e4feb39:	add    r14,0x20
    74a37e4feb3d:	movzx  r15d,BYTE PTR [r14]
    74a37e4feb41:	mov    r14,QWORD PTR [rsp+0x18]
    74a37e4feb46:	or     r14,r15
    74a37e4feb49:	mov    r15,QWORD PTR [r12+0x40]
    74a37e4feb4e:	add    r15,0x21
    74a37e4feb52:	movzx  ebp,BYTE PTR [r15]
    74a37e4feb56:	mov    r15,QWORD PTR [rsp+0x10]
    74a37e4feb5b:	or     r15,rbp
    74a37e4feb5e:	mov    rbp,QWORD PTR [r12+0x40]
    74a37e4feb63:	add    rbp,0x22
    74a37e4feb67:	movzx  r13d,BYTE PTR [rbp+0x0]
    74a37e4feb6c:	mov    rbp,QWORD PTR [rsp+0x8]
    74a37e4feb71:	or     rbp,r13
    74a37e4feb74:	mov    r13,QWORD PTR [r12+0x40]
    74a37e4feb79:	add    r13,0x23
    74a37e4feb7d:	movzx  r8d,BYTE PTR [r13+0x0]
    74a37e4feb82:	mov    r13,QWORD PTR [rsp]
    74a37e4feb86:	or     r13,r8
    74a37e4feb89:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4feb8e:	add    r8,0x24
    74a37e4feb92:	movzx  r9d,BYTE PTR [r8]
    74a37e4feb96:	mov    r8,r9
    74a37e4feb99:	shl    r8,0x8
    74a37e4feb9d:	or     r14,r8
    74a37e4feba0:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4feba5:	add    r8,0x25
    74a37e4feba9:	movzx  r9d,BYTE PTR [r8]
    74a37e4febad:	mov    r8,r9
    74a37e4febb0:	shl    r8,0x8
    74a37e4febb4:	or     r15,r8
    74a37e4febb7:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4febbc:	add    r8,0x26
    74a37e4febc0:	movzx  r9d,BYTE PTR [r8]
    74a37e4febc4:	mov    r8,r9
    74a37e4febc7:	shl    r8,0x8
    74a37e4febcb:	or     rbp,r8
    74a37e4febce:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4febd3:	add    r8,0x27
    74a37e4febd7:	movzx  r9d,BYTE PTR [r8]
    74a37e4febdb:	mov    r8,r9
    74a37e4febde:	shl    r8,0x8
    74a37e4febe2:	or     r13,r8
    74a37e4febe5:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4febea:	add    r8,0x28
    74a37e4febee:	movzx  r9d,BYTE PTR [r8]
    74a37e4febf2:	mov    r8,r9
    74a37e4febf5:	shl    r8,0x10
    74a37e4febf9:	or     r14,r8
    74a37e4febfc:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4fec01:	add    r8,0x29
    74a37e4fec05:	movzx  r9d,BYTE PTR [r8]
    74a37e4fec09:	mov    r8,r9
    74a37e4fec0c:	shl    r8,0x10
    74a37e4fec10:	or     r15,r8
    74a37e4fec13:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4fec18:	add    r8,0x2a
    74a37e4fec1c:	movzx  r9d,BYTE PTR [r8]
    74a37e4fec20:	mov    r8,r9
    74a37e4fec23:	shl    r8,0x10
    74a37e4fec27:	or     rbp,r8
    74a37e4fec2a:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4fec2f:	add    r8,0x2b
    74a37e4fec33:	movzx  r9d,BYTE PTR [r8]
    74a37e4fec37:	mov    r8,r9
    74a37e4fec3a:	shl    r8,0x10
    74a37e4fec3e:	or     r13,r8
    74a37e4fec41:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4fec46:	add    r8,0x2c
    74a37e4fec4a:	movzx  r9d,BYTE PTR [r8]
    74a37e4fec4e:	mov    r8,r9
    74a37e4fec51:	shl    r8,0x18
    74a37e4fec55:	or     r14,r8
    74a37e4fec58:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4fec5d:	add    r8,0x2d
    74a37e4fec61:	movzx  r9d,BYTE PTR [r8]
    74a37e4fec65:	mov    r8,r9
    74a37e4fec68:	shl    r8,0x18
    74a37e4fec6c:	or     r15,r8
    74a37e4fec6f:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4fec74:	add    r8,0x2e
    74a37e4fec78:	movzx  r9d,BYTE PTR [r8]
    74a37e4fec7c:	mov    r8,r9
    74a37e4fec7f:	shl    r8,0x18
    74a37e4fec83:	or     rbp,r8
    74a37e4fec86:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4fec8b:	add    r8,0x2f
    74a37e4fec8f:	movzx  r9d,BYTE PTR [r8]
    74a37e4fec93:	mov    r8,r9
    74a37e4fec96:	shl    r8,0x18
    74a37e4fec9a:	or     r13,r8
    74a37e4fec9d:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4feca2:	add    r8,0x30
    74a37e4feca6:	movzx  r9d,BYTE PTR [r8]
    74a37e4fecaa:	mov    r8,r9
    74a37e4fecad:	shl    r8,0x20
    74a37e4fecb1:	or     r14,r8
    74a37e4fecb4:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4fecb9:	add    r8,0x31
    74a37e4fecbd:	movzx  r9d,BYTE PTR [r8]
    74a37e4fecc1:	mov    r8,r9
    74a37e4fecc4:	shl    r8,0x20
    74a37e4fecc8:	or     r15,r8
    74a37e4feccb:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4fecd0:	add    r8,0x32
    74a37e4fecd4:	movzx  r9d,BYTE PTR [r8]
    74a37e4fecd8:	mov    r8,r9
    74a37e4fecdb:	shl    r8,0x20
    74a37e4fecdf:	or     rbp,r8
    74a37e4fece2:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4fece7:	add    r8,0x33
    74a37e4feceb:	movzx  r9d,BYTE PTR [r8]
    74a37e4fecef:	mov    r8,r9
    74a37e4fecf2:	shl    r8,0x20
    74a37e4fecf6:	or     r13,r8
    74a37e4fecf9:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4fecfe:	add    r8,0x34
    74a37e4fed02:	movzx  r9d,BYTE PTR [r8]
    74a37e4fed06:	mov    r8,r9
    74a37e4fed09:	shl    r8,0x28
    74a37e4fed0d:	or     r14,r8
    74a37e4fed10:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4fed15:	add    r8,0x35
    74a37e4fed19:	movzx  r9d,BYTE PTR [r8]
    74a37e4fed1d:	mov    r8,r9
    74a37e4fed20:	shl    r8,0x28
    74a37e4fed24:	or     r15,r8
    74a37e4fed27:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4fed2c:	add    r8,0x36
    74a37e4fed30:	movzx  r9d,BYTE PTR [r8]
    74a37e4fed34:	mov    r8,r9
    74a37e4fed37:	shl    r8,0x28
    74a37e4fed3b:	or     rbp,r8
    74a37e4fed3e:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4fed43:	add    r8,0x37
    74a37e4fed47:	movzx  r9d,BYTE PTR [r8]
    74a37e4fed4b:	mov    r8,r9
    74a37e4fed4e:	shl    r8,0x28
    74a37e4fed52:	or     r13,r8
    74a37e4fed55:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4fed5a:	add    r8,0x38
    74a37e4fed5e:	movzx  r9d,BYTE PTR [r8]
    74a37e4fed62:	mov    r8,r9
    74a37e4fed65:	shl    r8,0x30
    74a37e4fed69:	or     r14,r8
    74a37e4fed6c:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4fed71:	add    r8,0x39
    74a37e4fed75:	movzx  r9d,BYTE PTR [r8]
    74a37e4fed79:	mov    r8,r9
    74a37e4fed7c:	shl    r8,0x30
    74a37e4fed80:	or     r15,r8
    74a37e4fed83:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4fed88:	add    r8,0x3a
    74a37e4fed8c:	movzx  r9d,BYTE PTR [r8]
    74a37e4fed90:	mov    r8,r9
    74a37e4fed93:	shl    r8,0x30
    74a37e4fed97:	or     rbp,r8
    74a37e4fed9a:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4fed9f:	add    r8,0x3b
    74a37e4feda3:	movzx  r9d,BYTE PTR [r8]
    74a37e4feda7:	mov    r8,r9
    74a37e4fedaa:	shl    r8,0x30
    74a37e4fedae:	or     r13,r8
    74a37e4fedb1:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4fedb6:	add    r8,0x3c
    74a37e4fedba:	movzx  r9d,BYTE PTR [r8]
    74a37e4fedbe:	mov    r8,r9
    74a37e4fedc1:	shl    r8,0x38
    74a37e4fedc5:	or     r14,r8
    74a37e4fedc8:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4fedcd:	add    r8,0x3d
    74a37e4fedd1:	movzx  r9d,BYTE PTR [r8]
    74a37e4fedd5:	mov    r8,r9
    74a37e4fedd8:	shl    r8,0x38
    74a37e4feddc:	or     r15,r8
    74a37e4feddf:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4fede4:	add    r8,0x3e
    74a37e4fede8:	movzx  r9d,BYTE PTR [r8]
    74a37e4fedec:	mov    r8,r9
    74a37e4fedef:	shl    r8,0x38
    74a37e4fedf3:	or     rbp,r8
    74a37e4fedf6:	mov    r8,QWORD PTR [r12+0x40]
    74a37e4fedfb:	add    r8,0x3f
    74a37e4fedff:	movzx  r9d,BYTE PTR [r8]
    74a37e4fee03:	mov    r8,r9
    74a37e4fee06:	shl    r8,0x38
    74a37e4fee0a:	mov    rax,r13
    74a37e4fee0d:	or     rax,r8
    74a37e4fee10:	mov    QWORD PTR [rsp+0x40],rax
    74a37e4fee15:	mov    r8d,0x0
    74a37e4fee1b:	mov    QWORD PTR [r12+0x58],r8
    74a37e4fee20:	mov    r8d,0x0
    74a37e4fee26:	mov    r9,QWORD PTR [rsp+0x38]
    74a37e4fee2b:	and    r9,0xff
    74a37e4fee32:	and    r9,0xffff
    74a37e4fee39:	mov    r13,r8
    74a37e4fee3c:	or     r13,r9
    74a37e4fee3f:	mov    r9,QWORD PTR [rsp+0x38]
    74a37e4fee44:	shr    r9,0x8
    74a37e4fee48:	and    r9,0xff
    74a37e4fee4f:	and    r9,0xffff
    74a37e4fee56:	shl    r9,0x10
    74a37e4fee5a:	or     r13,r9
    74a37e4fee5d:	mov    r9,QWORD PTR [rsp+0x38]
    74a37e4fee62:	shr    r9,0x10
    74a37e4fee66:	and    r9,0xff
    74a37e4fee6d:	and    r9,0xffff
    74a37e4fee74:	shl    r9,0x20
    74a37e4fee78:	or     r13,r9
    74a37e4fee7b:	mov    r9,QWORD PTR [rsp+0x38]
    74a37e4fee80:	shr    r9,0x18
    74a37e4fee84:	and    r9,0xff
    74a37e4fee8b:	and    r9,0xffff
    74a37e4fee92:	shl    r9,0x30
    74a37e4fee96:	or     r13,r9
    74a37e4fee99:	mov    r9,QWORD PTR [rsp+0x38]
    74a37e4fee9e:	shr    r9,0x20
    74a37e4feea2:	and    r9,0xff
    74a37e4feea9:	and    r9,0xffff
    74a37e4feeb0:	or     r8,r9
    74a37e4feeb3:	mov    r9,QWORD PTR [rsp+0x38]
    74a37e4feeb8:	shr    r9,0x28
    74a37e4feebc:	and    r9,0xff
    74a37e4feec3:	and    r9,0xffff
    74a37e4feeca:	shl    r9,0x10
    74a37e4feece:	or     r8,r9
    74a37e4feed1:	mov    r9,QWORD PTR [rsp+0x38]
    74a37e4feed6:	shr    r9,0x30
    74a37e4feeda:	and    r9,0xff
    74a37e4feee1:	and    r9,0xffff
    74a37e4feee8:	shl    r9,0x20
    74a37e4feeec:	or     r8,r9
    74a37e4feeef:	mov    r9,QWORD PTR [rsp+0x38]
    74a37e4feef4:	shr    r9,0x38
    74a37e4feef8:	and    r9,0xff
    74a37e4feeff:	and    r9,0xffff
    74a37e4fef06:	shl    r9,0x30
    74a37e4fef0a:	or     r8,r9
    74a37e4fef0d:	mov    QWORD PTR [r12+0x150],r13
    74a37e4fef15:	mov    QWORD PTR [r12+0x158],r8
    74a37e4fef1d:	mov    r13d,0x0
    74a37e4fef23:	mov    r8,QWORD PTR [rsp+0x30]
    74a37e4fef28:	and    r8,0xff
    74a37e4fef2f:	and    r8,0xffff
    74a37e4fef36:	mov    r9,r13
    74a37e4fef39:	or     r9,r8
    74a37e4fef3c:	mov    r8,QWORD PTR [rsp+0x30]
    74a37e4fef41:	shr    r8,0x8
    74a37e4fef45:	and    r8,0xff
    74a37e4fef4c:	and    r8,0xffff
    74a37e4fef53:	shl    r8,0x10
    74a37e4fef57:	or     r9,r8
    74a37e4fef5a:	mov    r8,QWORD PTR [rsp+0x30]
    74a37e4fef5f:	shr    r8,0x10
    74a37e4fef63:	and    r8,0xff
    74a37e4fef6a:	and    r8,0xffff
    74a37e4fef71:	shl    r8,0x20
    74a37e4fef75:	or     r9,r8
    74a37e4fef78:	mov    r8,QWORD PTR [rsp+0x30]
    74a37e4fef7d:	shr    r8,0x18
    74a37e4fef81:	and    r8,0xff
    74a37e4fef88:	and    r8,0xffff
    74a37e4fef8f:	shl    r8,0x30
    74a37e4fef93:	mov    rax,r9
    74a37e4fef96:	or     rax,r8
    74a37e4fef99:	mov    QWORD PTR [rsp+0x50],rax
    74a37e4fef9e:	mov    r8,QWORD PTR [rsp+0x30]
    74a37e4fefa3:	shr    r8,0x20
    74a37e4fefa7:	and    r8,0xff
    74a37e4fefae:	and    r8,0xffff
    74a37e4fefb5:	or     r13,r8
    74a37e4fefb8:	mov    r8,QWORD PTR [rsp+0x30]
    74a37e4fefbd:	shr    r8,0x28
    74a37e4fefc1:	and    r8,0xff
    74a37e4fefc8:	and    r8,0xffff
    74a37e4fefcf:	shl    r8,0x10
    74a37e4fefd3:	or     r13,r8
    74a37e4fefd6:	mov    r8,QWORD PTR [rsp+0x30]
    74a37e4fefdb:	shr    r8,0x30
    74a37e4fefdf:	and    r8,0xff
    74a37e4fefe6:	and    r8,0xffff
    74a37e4fefed:	shl    r8,0x20
    74a37e4feff1:	or     r13,r8
    74a37e4feff4:	mov    r8,QWORD PTR [rsp+0x30]
    74a37e4feff9:	shr    r8,0x38
    74a37e4feffd:	and    r8,0xff
    74a37e4ff004:	and    r8,0xffff
    74a37e4ff00b:	shl    r8,0x30
    74a37e4ff00f:	mov    rax,r13
    74a37e4ff012:	or     rax,r8
    74a37e4ff015:	mov    QWORD PTR [rsp+0x48],rax
    74a37e4ff01a:	mov    r8d,0x0
    74a37e4ff020:	mov    r13,QWORD PTR [rsp+0x28]
    74a37e4ff025:	and    r13,0xff
    74a37e4ff02c:	and    r13,0xffff
    74a37e4ff033:	mov    r9,r8
    74a37e4ff036:	or     r9,r13
    74a37e4ff039:	mov    r13,QWORD PTR [rsp+0x28]
    74a37e4ff03e:	shr    r13,0x8
    74a37e4ff042:	and    r13,0xff
    74a37e4ff049:	and    r13,0xffff
    74a37e4ff050:	shl    r13,0x10
    74a37e4ff054:	or     r9,r13
    74a37e4ff057:	mov    r13,QWORD PTR [rsp+0x28]
    74a37e4ff05c:	shr    r13,0x10
    74a37e4ff060:	and    r13,0xff
    74a37e4ff067:	and    r13,0xffff
    74a37e4ff06e:	shl    r13,0x20
    74a37e4ff072:	or     r9,r13
    74a37e4ff075:	mov    r13,QWORD PTR [rsp+0x28]
    74a37e4ff07a:	shr    r13,0x18
    74a37e4ff07e:	and    r13,0xff
    74a37e4ff085:	and    r13,0xffff
    74a37e4ff08c:	shl    r13,0x30
    74a37e4ff090:	mov    rax,r9
    74a37e4ff093:	or     rax,r13
    74a37e4ff096:	mov    QWORD PTR [rsp+0x58],rax
    74a37e4ff09b:	mov    r13,QWORD PTR [rsp+0x28]
    74a37e4ff0a0:	shr    r13,0x20
    74a37e4ff0a4:	and    r13,0xff
    74a37e4ff0ab:	and    r13,0xffff
    74a37e4ff0b2:	or     r8,r13
    74a37e4ff0b5:	mov    r13,QWORD PTR [rsp+0x28]
    74a37e4ff0ba:	shr    r13,0x28
    74a37e4ff0be:	and    r13,0xff
    74a37e4ff0c5:	and    r13,0xffff
    74a37e4ff0cc:	shl    r13,0x10
    74a37e4ff0d0:	or     r8,r13
    74a37e4ff0d3:	mov    r13,QWORD PTR [rsp+0x28]
    74a37e4ff0d8:	shr    r13,0x30
    74a37e4ff0dc:	and    r13,0xff
    74a37e4ff0e3:	and    r13,0xffff
    74a37e4ff0ea:	shl    r13,0x20
    74a37e4ff0ee:	or     r8,r13
    74a37e4ff0f1:	mov    r13,QWORD PTR [rsp+0x28]
    74a37e4ff0f6:	shr    r13,0x38
    74a37e4ff0fa:	and    r13,0xff
    74a37e4ff101:	and    r13,0xffff
    74a37e4ff108:	shl    r13,0x30
    74a37e4ff10c:	mov    rax,r8
    74a37e4ff10f:	or     rax,r13
    74a37e4ff112:	mov    QWORD PTR [rsp+0x60],rax
    74a37e4ff117:	mov    r13d,0x0
    74a37e4ff11d:	mov    r9,r14
    74a37e4ff120:	and    r9,0xff
    74a37e4ff127:	and    r9,0xffff
    74a37e4ff12e:	mov    r8,r13
    74a37e4ff131:	or     r8,r9
    74a37e4ff134:	mov    r9,r14
    74a37e4ff137:	shr    r9,0x8
    74a37e4ff13b:	and    r9,0xff
    74a37e4ff142:	and    r9,0xffff
    74a37e4ff149:	shl    r9,0x10
    74a37e4ff14d:	or     r8,r9
    74a37e4ff150:	mov    r9,r14
    74a37e4ff153:	shr    r9,0x10
    74a37e4ff157:	and    r9,0xff
    74a37e4ff15e:	and    r9,0xffff
    74a37e4ff165:	shl    r9,0x20
    74a37e4ff169:	or     r8,r9
    74a37e4ff16c:	mov    r9,r14
    74a37e4ff16f:	shr    r9,0x18
    74a37e4ff173:	and    r9,0xff
    74a37e4ff17a:	and    r9,0xffff
    74a37e4ff181:	shl    r9,0x30
    74a37e4ff185:	mov    rax,r8
    74a37e4ff188:	or     rax,r9
    74a37e4ff18b:	mov    QWORD PTR [rsp+0x68],rax
    74a37e4ff190:	mov    r9,r14
    74a37e4ff193:	shr    r9,0x20
    74a37e4ff197:	and    r9,0xff
    74a37e4ff19e:	and    r9,0xffff
    74a37e4ff1a5:	or     r13,r9
    74a37e4ff1a8:	mov    r9,r14
    74a37e4ff1ab:	shr    r9,0x28
    74a37e4ff1af:	and    r9,0xff
    74a37e4ff1b6:	and    r9,0xffff
    74a37e4ff1bd:	shl    r9,0x10
    74a37e4ff1c1:	or     r13,r9
    74a37e4ff1c4:	mov    r9,r14
    74a37e4ff1c7:	shr    r9,0x30
    74a37e4ff1cb:	and    r9,0xff
    74a37e4ff1d2:	and    r9,0xffff
    74a37e4ff1d9:	shl    r9,0x20
    74a37e4ff1dd:	or     r13,r9
    74a37e4ff1e0:	shr    r14,0x38
    74a37e4ff1e4:	and    r14,0xff
    74a37e4ff1eb:	and    r14,0xffff
    74a37e4ff1f2:	shl    r14,0x30
    74a37e4ff1f6:	or     r13,r14
    74a37e4ff1f9:	mov    r14d,0x0
    74a37e4ff1ff:	mov    r9,r15
    74a37e4ff202:	and    r9,0xff
    74a37e4ff209:	and    r9,0xffff
    74a37e4ff210:	mov    r8,r14
    74a37e4ff213:	or     r8,r9
    74a37e4ff216:	mov    r9,r15
    74a37e4ff219:	shr    r9,0x8
    74a37e4ff21d:	and    r9,0xff
    74a37e4ff224:	and    r9,0xffff
    74a37e4ff22b:	shl    r9,0x10
    74a37e4ff22f:	or     r8,r9
    74a37e4ff232:	mov    r9,r15
    74a37e4ff235:	shr    r9,0x10
    74a37e4ff239:	and    r9,0xff
    74a37e4ff240:	and    r9,0xffff
    74a37e4ff247:	shl    r9,0x20
    74a37e4ff24b:	or     r8,r9
    74a37e4ff24e:	mov    r9,r15
    74a37e4ff251:	shr    r9,0x18
    74a37e4ff255:	and    r9,0xff
    74a37e4ff25c:	and    r9,0xffff
    74a37e4ff263:	shl    r9,0x30
    74a37e4ff267:	or     r8,r9
    74a37e4ff26a:	mov    r9,r15
    74a37e4ff26d:	shr    r9,0x20
    74a37e4ff271:	and    r9,0xff
    74a37e4ff278:	and    r9,0xffff
    74a37e4ff27f:	or     r14,r9
    74a37e4ff282:	mov    r9,r15
    74a37e4ff285:	shr    r9,0x28
    74a37e4ff289:	and    r9,0xff
    74a37e4ff290:	and    r9,0xffff
    74a37e4ff297:	shl    r9,0x10
    74a37e4ff29b:	or     r14,r9
    74a37e4ff29e:	mov    r9,r15
    74a37e4ff2a1:	shr    r9,0x30
    74a37e4ff2a5:	and    r9,0xff
    74a37e4ff2ac:	and    r9,0xffff
    74a37e4ff2b3:	shl    r9,0x20
    74a37e4ff2b7:	or     r14,r9
    74a37e4ff2ba:	shr    r15,0x38
    74a37e4ff2be:	and    r15,0xff
    74a37e4ff2c5:	and    r15,0xffff
    74a37e4ff2cc:	shl    r15,0x30
    74a37e4ff2d0:	or     r14,r15
    74a37e4ff2d3:	mov    QWORD PTR [r12+0x210],r8
    74a37e4ff2db:	mov    QWORD PTR [r12+0x218],r14
    74a37e4ff2e3:	mov    r14d,0x0
    74a37e4ff2e9:	mov    r15,rbp
    74a37e4ff2ec:	and    r15,0xff
    74a37e4ff2f3:	and    r15,0xffff
    74a37e4ff2fa:	mov    r8,r14
    74a37e4ff2fd:	or     r8,r15
    74a37e4ff300:	mov    r15,rbp
    74a37e4ff303:	shr    r15,0x8
    74a37e4ff307:	and    r15,0xff
    74a37e4ff30e:	and    r15,0xffff
    74a37e4ff315:	shl    r15,0x10
    74a37e4ff319:	or     r8,r15
    74a37e4ff31c:	mov    r15,rbp
    74a37e4ff31f:	shr    r15,0x10
    74a37e4ff323:	and    r15,0xff
    74a37e4ff32a:	and    r15,0xffff
    74a37e4ff331:	shl    r15,0x20
    74a37e4ff335:	or     r8,r15
    74a37e4ff338:	mov    r15,rbp
    74a37e4ff33b:	shr    r15,0x18
    74a37e4ff33f:	and    r15,0xff
    74a37e4ff346:	and    r15,0xffff
    74a37e4ff34d:	shl    r15,0x30
    74a37e4ff351:	or     r8,r15
    74a37e4ff354:	mov    r15,rbp
    74a37e4ff357:	shr    r15,0x20
    74a37e4ff35b:	and    r15,0xff
    74a37e4ff362:	and    r15,0xffff
    74a37e4ff369:	or     r14,r15
    74a37e4ff36c:	mov    r15,rbp
    74a37e4ff36f:	shr    r15,0x28
    74a37e4ff373:	and    r15,0xff
    74a37e4ff37a:	and    r15,0xffff
    74a37e4ff381:	shl    r15,0x10
    74a37e4ff385:	or     r14,r15
    74a37e4ff388:	mov    r15,rbp
    74a37e4ff38b:	shr    r15,0x30
    74a37e4ff38f:	and    r15,0xff
    74a37e4ff396:	and    r15,0xffff
    74a37e4ff39d:	shl    r15,0x20
    74a37e4ff3a1:	or     r14,r15
    74a37e4ff3a4:	shr    rbp,0x38
    74a37e4ff3a8:	and    rbp,0xff
    74a37e4ff3af:	and    rbp,0xffff
    74a37e4ff3b6:	shl    rbp,0x30
    74a37e4ff3ba:	or     r14,rbp
    74a37e4ff3bd:	mov    r15d,0x0
    74a37e4ff3c3:	mov    rbp,QWORD PTR [rsp+0x20]
    74a37e4ff3c8:	and    rbp,0xff
    74a37e4ff3cf:	and    rbp,0xffff
    74a37e4ff3d6:	mov    r9,r15
    74a37e4ff3d9:	or     r9,rbp
    74a37e4ff3dc:	mov    rbp,QWORD PTR [rsp+0x20]
    74a37e4ff3e1:	shr    rbp,0x8
    74a37e4ff3e5:	and    rbp,0xff
    74a37e4ff3ec:	and    rbp,0xffff
    74a37e4ff3f3:	shl    rbp,0x10
    74a37e4ff3f7:	or     r9,rbp
    74a37e4ff3fa:	mov    rbp,QWORD PTR [rsp+0x20]
    74a37e4ff3ff:	shr    rbp,0x10
    74a37e4ff403:	and    rbp,0xff
    74a37e4ff40a:	and    rbp,0xffff
    74a37e4ff411:	shl    rbp,0x20
    74a37e4ff415:	or     r9,rbp
    74a37e4ff418:	mov    rbp,QWORD PTR [rsp+0x20]
    74a37e4ff41d:	shr    rbp,0x18
    74a37e4ff421:	and    rbp,0xff
    74a37e4ff428:	and    rbp,0xffff
    74a37e4ff42f:	shl    rbp,0x30
    74a37e4ff433:	mov    rax,r9
    74a37e4ff436:	or     rax,rbp
    74a37e4ff439:	mov    QWORD PTR [rsp+0x78],rax
    74a37e4ff43e:	mov    rbp,QWORD PTR [rsp+0x20]
    74a37e4ff443:	shr    rbp,0x20
    74a37e4ff447:	and    rbp,0xff
    74a37e4ff44e:	and    rbp,0xffff
    74a37e4ff455:	or     r15,rbp
    74a37e4ff458:	mov    rbp,QWORD PTR [rsp+0x20]
    74a37e4ff45d:	shr    rbp,0x28
    74a37e4ff461:	and    rbp,0xff
    74a37e4ff468:	and    rbp,0xffff
    74a37e4ff46f:	shl    rbp,0x10
    74a37e4ff473:	or     r15,rbp
    74a37e4ff476:	mov    rbp,QWORD PTR [rsp+0x20]
    74a37e4ff47b:	shr    rbp,0x30
    74a37e4ff47f:	and    rbp,0xff
    74a37e4ff486:	and    rbp,0xffff
    74a37e4ff48d:	shl    rbp,0x20
    74a37e4ff491:	or     r15,rbp
    74a37e4ff494:	mov    rbp,QWORD PTR [rsp+0x20]
    74a37e4ff499:	shr    rbp,0x38
    74a37e4ff49d:	and    rbp,0xff
    74a37e4ff4a4:	and    rbp,0xffff
    74a37e4ff4ab:	shl    rbp,0x30
    74a37e4ff4af:	mov    rax,r15
    74a37e4ff4b2:	or     rax,rbp
    74a37e4ff4b5:	mov    QWORD PTR [rsp+0x70],rax
    74a37e4ff4ba:	mov    rax,QWORD PTR [rsp+0x78]
    74a37e4ff4bf:	mov    QWORD PTR [r12+0x250],rax
    74a37e4ff4c7:	mov    rax,QWORD PTR [rsp+0x70]
    74a37e4ff4cc:	mov    QWORD PTR [r12+0x258],rax
    74a37e4ff4d4:	mov    ebp,0x0
    74a37e4ff4d9:	mov    r15,QWORD PTR [rsp+0x40]
    74a37e4ff4de:	and    r15,0xff
    74a37e4ff4e5:	and    r15,0xffff
    74a37e4ff4ec:	mov    r9,rbp
    74a37e4ff4ef:	or     r9,r15
    74a37e4ff4f2:	mov    r15,QWORD PTR [rsp+0x40]
    74a37e4ff4f7:	shr    r15,0x8
    74a37e4ff4fb:	and    r15,0xff
    74a37e4ff502:	and    r15,0xffff
    74a37e4ff509:	shl    r15,0x10
    74a37e4ff50d:	or     r9,r15
    74a37e4ff510:	mov    r15,QWORD PTR [rsp+0x40]
    74a37e4ff515:	shr    r15,0x10
    74a37e4ff519:	and    r15,0xff
    74a37e4ff520:	and    r15,0xffff
    74a37e4ff527:	shl    r15,0x20
    74a37e4ff52b:	or     r9,r15
    74a37e4ff52e:	mov    r15,QWORD PTR [rsp+0x40]
    74a37e4ff533:	shr    r15,0x18
    74a37e4ff537:	and    r15,0xff
    74a37e4ff53e:	and    r15,0xffff
    74a37e4ff545:	shl    r15,0x30
    74a37e4ff549:	mov    rax,r9
    74a37e4ff54c:	or     rax,r15
    74a37e4ff54f:	mov    QWORD PTR [rsp+0x80],rax
    74a37e4ff557:	mov    r15,QWORD PTR [rsp+0x40]
    74a37e4ff55c:	shr    r15,0x20
    74a37e4ff560:	and    r15,0xff
    74a37e4ff567:	and    r15,0xffff
    74a37e4ff56e:	or     rbp,r15
    74a37e4ff571:	mov    r15,QWORD PTR [rsp+0x40]
    74a37e4ff576:	shr    r15,0x28
    74a37e4ff57a:	and    r15,0xff
    74a37e4ff581:	and    r15,0xffff
    74a37e4ff588:	shl    r15,0x10
    74a37e4ff58c:	or     rbp,r15
    74a37e4ff58f:	mov    r15,QWORD PTR [rsp+0x40]
    74a37e4ff594:	shr    r15,0x30
    74a37e4ff598:	and    r15,0xff
    74a37e4ff59f:	and    r15,0xffff
    74a37e4ff5a6:	shl    r15,0x20
    74a37e4ff5aa:	or     rbp,r15
    74a37e4ff5ad:	mov    r15,QWORD PTR [rsp+0x40]
    74a37e4ff5b2:	shr    r15,0x38
    74a37e4ff5b6:	and    r15,0xff
    74a37e4ff5bd:	and    r15,0xffff
    74a37e4ff5c4:	shl    r15,0x30
    74a37e4ff5c8:	mov    rax,rbp
    74a37e4ff5cb:	or     rax,r15
    74a37e4ff5ce:	mov    QWORD PTR [rsp+0x88],rax
    74a37e4ff5d6:	movdqu xmm2,XMMWORD PTR [r12+0x150]
    74a37e4ff5e0:	pxor   xmm0,xmm0
    74a37e4ff5e4:	movdqa xmm3,xmm0
    74a37e4ff5e8:	movdqa xmm0,xmm2
    74a37e4ff5ec:	movdqa xmm1,xmm3
    74a37e4ff5f0:	punpcklwd xmm0,xmm1
    74a37e4ff5f4:	movdqa xmm4,xmm0
    74a37e4ff5f8:	movdqa xmm0,xmm4
    74a37e4ff5fc:	pslld  xmm0,0x10
    74a37e4ff601:	movdqa xmm3,xmm0
    74a37e4ff605:	mov    r15d,0x0
    74a37e4ff60b:	mov    r9,QWORD PTR [rsp+0x50]
    74a37e4ff610:	and    r9,0xffff
    74a37e4ff617:	shl    r9,0x8
    74a37e4ff61b:	mov    ecx,0xffffffff
    74a37e4ff620:	and    r9,rcx
    74a37e4ff623:	mov    rbp,r15
    74a37e4ff626:	or     rbp,r9
    74a37e4ff629:	mov    r9,QWORD PTR [rsp+0x50]
    74a37e4ff62e:	shr    r9,0x10
    74a37e4ff632:	and    r9,0xffff
    74a37e4ff639:	shl    r9,0x8
    74a37e4ff63d:	mov    ecx,0xffffffff
    74a37e4ff642:	and    r9,rcx
    74a37e4ff645:	shl    r9,0x20
    74a37e4ff649:	or     rbp,r9
    74a37e4ff64c:	mov    r9,QWORD PTR [rsp+0x50]
    74a37e4ff651:	shr    r9,0x20
    74a37e4ff655:	and    r9,0xffff
    74a37e4ff65c:	shl    r9,0x8
    74a37e4ff660:	mov    ecx,0xffffffff
    74a37e4ff665:	and    r9,rcx
    74a37e4ff668:	or     r15,r9
    74a37e4ff66b:	mov    r9,QWORD PTR [rsp+0x50]
    74a37e4ff670:	shr    r9,0x30
    74a37e4ff674:	and    r9,0xffff
    74a37e4ff67b:	shl    r9,0x8
    74a37e4ff67f:	mov    ecx,0xffffffff
    74a37e4ff684:	and    r9,rcx
    74a37e4ff687:	shl    r9,0x20
    74a37e4ff68b:	or     r15,r9
    74a37e4ff68e:	mov    QWORD PTR [r12+0x240],rbp
    74a37e4ff696:	mov    QWORD PTR [r12+0x248],r15
    74a37e4ff69e:	mov    r15d,0x0
    74a37e4ff6a4:	mov    rbp,QWORD PTR [rsp+0x60]
    74a37e4ff6a9:	and    rbp,0xffff
    74a37e4ff6b0:	mov    ecx,0xffffffff
    74a37e4ff6b5:	and    rbp,rcx
    74a37e4ff6b8:	mov    r9,r15
    74a37e4ff6bb:	or     r9,rbp
    74a37e4ff6be:	mov    rbp,QWORD PTR [rsp+0x60]
    74a37e4ff6c3:	shr    rbp,0x10
    74a37e4ff6c7:	and    rbp,0xffff
    74a37e4ff6ce:	mov    ecx,0xffffffff
    74a37e4ff6d3:	and    rbp,rcx
    74a37e4ff6d6:	shl    rbp,0x20
    74a37e4ff6da:	or     r9,rbp
    74a37e4ff6dd:	mov    rbp,QWORD PTR [rsp+0x60]
    74a37e4ff6e2:	shr    rbp,0x20
    74a37e4ff6e6:	and    rbp,0xffff
    74a37e4ff6ed:	mov    ecx,0xffffffff
    74a37e4ff6f2:	and    rbp,rcx
    74a37e4ff6f5:	or     r15,rbp
    74a37e4ff6f8:	mov    rbp,QWORD PTR [rsp+0x60]
    74a37e4ff6fd:	shr    rbp,0x30
    74a37e4ff701:	and    rbp,0xffff
    74a37e4ff708:	mov    ecx,0xffffffff
    74a37e4ff70d:	and    rbp,rcx
    74a37e4ff710:	shl    rbp,0x20
    74a37e4ff714:	or     r15,rbp
    74a37e4ff717:	mov    QWORD PTR [r12+0x260],r9
    74a37e4ff71f:	mov    QWORD PTR [r12+0x268],r15
    74a37e4ff727:	mov    r15d,0x0
    74a37e4ff72d:	mov    rbp,r13
    74a37e4ff730:	and    rbp,0xffff
    74a37e4ff737:	mov    ecx,0xffffffff
    74a37e4ff73c:	and    rbp,rcx
    74a37e4ff73f:	mov    r9,r15
    74a37e4ff742:	or     r9,rbp
    74a37e4ff745:	mov    rbp,r13
    74a37e4ff748:	shr    rbp,0x10
    74a37e4ff74c:	and    rbp,0xffff
    74a37e4ff753:	mov    ecx,0xffffffff
    74a37e4ff758:	and    rbp,rcx
    74a37e4ff75b:	shl    rbp,0x20
    74a37e4ff75f:	or     r9,rbp
    74a37e4ff762:	mov    rbp,r13
    74a37e4ff765:	shr    rbp,0x20
    74a37e4ff769:	and    rbp,0xffff
    74a37e4ff770:	mov    ecx,0xffffffff
    74a37e4ff775:	and    rbp,rcx
    74a37e4ff778:	or     r15,rbp
    74a37e4ff77b:	shr    r13,0x30
    74a37e4ff77f:	and    r13,0xffff
    74a37e4ff786:	mov    ecx,0xffffffff
    74a37e4ff78b:	and    r13,rcx
    74a37e4ff78e:	shl    r13,0x20
    74a37e4ff792:	or     r15,r13
    74a37e4ff795:	mov    QWORD PTR [r12+0x270],r9
    74a37e4ff79d:	mov    QWORD PTR [r12+0x278],r15
    74a37e4ff7a5:	mov    r13d,0x0
    74a37e4ff7ab:	mov    r15,QWORD PTR [rsp+0x58]
    74a37e4ff7b0:	and    r15,0xffff
    74a37e4ff7b7:	mov    ecx,0xffffffff
    74a37e4ff7bc:	and    r15,rcx
    74a37e4ff7bf:	mov    rbp,r13
    74a37e4ff7c2:	or     rbp,r15
    74a37e4ff7c5:	mov    r15,QWORD PTR [rsp+0x58]
    74a37e4ff7ca:	shr    r15,0x10
    74a37e4ff7ce:	and    r15,0xffff
    74a37e4ff7d5:	mov    ecx,0xffffffff
    74a37e4ff7da:	and    r15,rcx
    74a37e4ff7dd:	shl    r15,0x20
    74a37e4ff7e1:	or     rbp,r15
    74a37e4ff7e4:	mov    r15,QWORD PTR [rsp+0x58]
    74a37e4ff7e9:	shr    r15,0x20
    74a37e4ff7ed:	and    r15,0xffff
    74a37e4ff7f4:	mov    ecx,0xffffffff
    74a37e4ff7f9:	and    r15,rcx
    74a37e4ff7fc:	or     r13,r15
    74a37e4ff7ff:	mov    r15,QWORD PTR [rsp+0x58]
    74a37e4ff804:	shr    r15,0x30
    74a37e4ff808:	and    r15,0xffff
    74a37e4ff80f:	mov    ecx,0xffffffff
    74a37e4ff814:	and    r15,rcx
    74a37e4ff817:	shl    r15,0x20
    74a37e4ff81b:	or     r13,r15
    74a37e4ff81e:	mov    QWORD PTR [r12+0x170],rbp
    74a37e4ff826:	mov    QWORD PTR [r12+0x178],r13
    74a37e4ff82e:	movdqu xmm4,XMMWORD PTR [r12+0x210]
    74a37e4ff838:	pxor   xmm0,xmm0
    74a37e4ff83c:	movdqa xmm5,xmm0
    74a37e4ff840:	movdqa xmm0,xmm4
    74a37e4ff844:	movdqa xmm1,xmm5
    74a37e4ff848:	punpckhwd xmm0,xmm1
    74a37e4ff84c:	movdqa xmm6,xmm0
    74a37e4ff850:	movdqa xmm0,xmm6
    74a37e4ff854:	pslld  xmm0,0x10
    74a37e4ff859:	movdqa xmm5,xmm0
    74a37e4ff85d:	movdqu XMMWORD PTR [r12+0x280],xmm5
    74a37e4ff867:	mov    r13d,0x0
    74a37e4ff86d:	mov    r15,QWORD PTR [rsp+0x68]
    74a37e4ff872:	and    r15,0xffff
    74a37e4ff879:	mov    ecx,0xffffffff
    74a37e4ff87e:	and    r15,rcx
    74a37e4ff881:	mov    rbp,r13
    74a37e4ff884:	or     rbp,r15
    74a37e4ff887:	mov    r15,QWORD PTR [rsp+0x68]
    74a37e4ff88c:	shr    r15,0x10
    74a37e4ff890:	and    r15,0xffff
    74a37e4ff897:	mov    ecx,0xffffffff
    74a37e4ff89c:	and    r15,rcx
    74a37e4ff89f:	shl    r15,0x20
    74a37e4ff8a3:	or     rbp,r15
    74a37e4ff8a6:	mov    r15,QWORD PTR [rsp+0x68]
    74a37e4ff8ab:	shr    r15,0x20
    74a37e4ff8af:	and    r15,0xffff
    74a37e4ff8b6:	mov    ecx,0xffffffff
    74a37e4ff8bb:	and    r15,rcx
    74a37e4ff8be:	or     r13,r15
    74a37e4ff8c1:	mov    r15,QWORD PTR [rsp+0x68]
    74a37e4ff8c6:	shr    r15,0x30
    74a37e4ff8ca:	and    r15,0xffff
    74a37e4ff8d1:	mov    ecx,0xffffffff
    74a37e4ff8d6:	and    r15,rcx
    74a37e4ff8d9:	shl    r15,0x20
    74a37e4ff8dd:	or     r13,r15
    74a37e4ff8e0:	mov    QWORD PTR [r12+0x180],rbp
    74a37e4ff8e8:	mov    QWORD PTR [r12+0x188],r13
    74a37e4ff8f0:	pxor   xmm0,xmm0
    74a37e4ff8f4:	movdqa xmm6,xmm0
    74a37e4ff8f8:	movdqa xmm0,xmm4
    74a37e4ff8fc:	movdqa xmm1,xmm6
    74a37e4ff900:	punpcklwd xmm0,xmm1
    74a37e4ff904:	movdqa xmm7,xmm0
    74a37e4ff908:	movdqa xmm0,xmm7
    74a37e4ff90c:	pslld  xmm0,0x10
    74a37e4ff911:	movdqa xmm4,xmm0
    74a37e4ff915:	pxor   xmm0,xmm0
    74a37e4ff919:	movdqa xmm6,xmm0
    74a37e4ff91d:	movdqa xmm0,xmm2
    74a37e4ff921:	movdqa xmm1,xmm6
    74a37e4ff925:	punpckhwd xmm0,xmm1
    74a37e4ff929:	movdqa xmm7,xmm0
    74a37e4ff92d:	movdqa xmm0,xmm7
    74a37e4ff931:	pslld  xmm0,0x10
    74a37e4ff936:	movdqa xmm2,xmm0
    74a37e4ff93a:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    74a37e4ff944:	movdqa xmm1,xmm6
    74a37e4ff948:	por    xmm3,xmm1
    74a37e4ff94c:	movdqu XMMWORD PTR [r12+0x230],xmm3
    74a37e4ff956:	mov    r13d,0x0
    74a37e4ff95c:	mov    r15,r14
    74a37e4ff95f:	and    r15,0xffff
    74a37e4ff966:	shl    r15,0x8
    74a37e4ff96a:	mov    ecx,0xffffffff
    74a37e4ff96f:	and    r15,rcx
    74a37e4ff972:	mov    rbp,r13
    74a37e4ff975:	or     rbp,r15
    74a37e4ff978:	mov    r15,r14
    74a37e4ff97b:	shr    r15,0x10
    74a37e4ff97f:	and    r15,0xffff
    74a37e4ff986:	shl    r15,0x8
    74a37e4ff98a:	mov    ecx,0xffffffff
    74a37e4ff98f:	and    r15,rcx
    74a37e4ff992:	shl    r15,0x20
    74a37e4ff996:	or     rbp,r15
    74a37e4ff999:	mov    r15,r14
    74a37e4ff99c:	shr    r15,0x20
    74a37e4ff9a0:	and    r15,0xffff
    74a37e4ff9a7:	shl    r15,0x8
    74a37e4ff9ab:	mov    ecx,0xffffffff
    74a37e4ff9b0:	and    r15,rcx
    74a37e4ff9b3:	or     r13,r15
    74a37e4ff9b6:	shr    r14,0x30
    74a37e4ff9ba:	and    r14,0xffff
    74a37e4ff9c1:	shl    r14,0x8
    74a37e4ff9c5:	mov    ecx,0xffffffff
    74a37e4ff9ca:	and    r14,rcx
    74a37e4ff9cd:	shl    r14,0x20
    74a37e4ff9d1:	or     r13,r14
    74a37e4ff9d4:	mov    QWORD PTR [r12+0x240],rbp
    74a37e4ff9dc:	mov    QWORD PTR [r12+0x248],r13
    74a37e4ff9e4:	mov    r13d,0x0
    74a37e4ff9ea:	mov    r14,r8
    74a37e4ff9ed:	and    r14,0xffff
    74a37e4ff9f4:	shl    r14,0x8
    74a37e4ff9f8:	mov    ecx,0xffffffff
    74a37e4ff9fd:	and    r14,rcx
    74a37e4ffa00:	mov    r15,r13
    74a37e4ffa03:	or     r15,r14
    74a37e4ffa06:	mov    r14,r8
    74a37e4ffa09:	shr    r14,0x10
    74a37e4ffa0d:	and    r14,0xffff
    74a37e4ffa14:	shl    r14,0x8
    74a37e4ffa18:	mov    ecx,0xffffffff
    74a37e4ffa1d:	and    r14,rcx
    74a37e4ffa20:	shl    r14,0x20
    74a37e4ffa24:	or     r15,r14
    74a37e4ffa27:	mov    r14,r8
    74a37e4ffa2a:	shr    r14,0x20
    74a37e4ffa2e:	and    r14,0xffff
    74a37e4ffa35:	shl    r14,0x8
    74a37e4ffa39:	mov    ecx,0xffffffff
    74a37e4ffa3e:	and    r14,rcx
    74a37e4ffa41:	or     r13,r14
    74a37e4ffa44:	shr    r8,0x30
    74a37e4ffa48:	and    r8,0xffff
    74a37e4ffa4f:	shl    r8,0x8
    74a37e4ffa53:	mov    ecx,0xffffffff
    74a37e4ffa58:	and    r8,rcx
    74a37e4ffa5b:	shl    r8,0x20
    74a37e4ffa5f:	or     r13,r8
    74a37e4ffa62:	mov    QWORD PTR [r12+0x220],r15
    74a37e4ffa6a:	mov    QWORD PTR [r12+0x228],r13
    74a37e4ffa72:	mov    r13d,0x0
    74a37e4ffa78:	mov    r14,QWORD PTR [rsp+0x48]
    74a37e4ffa7d:	and    r14,0xffff
    74a37e4ffa84:	shl    r14,0x8
    74a37e4ffa88:	mov    ecx,0xffffffff
    74a37e4ffa8d:	and    r14,rcx
    74a37e4ffa90:	mov    r15,r13
    74a37e4ffa93:	or     r15,r14
    74a37e4ffa96:	mov    r14,QWORD PTR [rsp+0x48]
    74a37e4ffa9b:	shr    r14,0x10
    74a37e4ffa9f:	and    r14,0xffff
    74a37e4ffaa6:	shl    r14,0x8
    74a37e4ffaaa:	mov    ecx,0xffffffff
    74a37e4ffaaf:	and    r14,rcx
    74a37e4ffab2:	shl    r14,0x20
    74a37e4ffab6:	or     r15,r14
    74a37e4ffab9:	mov    r14,QWORD PTR [rsp+0x48]
    74a37e4ffabe:	shr    r14,0x20
    74a37e4ffac2:	and    r14,0xffff
    74a37e4ffac9:	shl    r14,0x8
    74a37e4ffacd:	mov    ecx,0xffffffff
    74a37e4ffad2:	and    r14,rcx
    74a37e4ffad5:	or     r13,r14
    74a37e4ffad8:	mov    r14,QWORD PTR [rsp+0x48]
    74a37e4ffadd:	shr    r14,0x30
    74a37e4ffae1:	and    r14,0xffff
    74a37e4ffae8:	shl    r14,0x8
    74a37e4ffaec:	mov    ecx,0xffffffff
    74a37e4ffaf1:	and    r14,rcx
    74a37e4ffaf4:	shl    r14,0x20
    74a37e4ffaf8:	or     r13,r14
    74a37e4ffafb:	mov    QWORD PTR [r12+0x160],r15
    74a37e4ffb03:	mov    QWORD PTR [r12+0x168],r13
    74a37e4ffb0b:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    74a37e4ffb15:	movdqa xmm0,xmm6
    74a37e4ffb19:	pslld  xmm0,0x18
    74a37e4ffb1e:	movdqa xmm7,xmm0
    74a37e4ffb22:	movdqu XMMWORD PTR [r12+0x170],xmm7
    74a37e4ffb2c:	movdqu xmm6,XMMWORD PTR [r12+0x270]
    74a37e4ffb36:	movdqa xmm0,xmm6
    74a37e4ffb3a:	pslld  xmm0,0x18
    74a37e4ffb3f:	movdqa xmm8,xmm0
    74a37e4ffb44:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    74a37e4ffb4e:	movdqa xmm0,xmm6
    74a37e4ffb52:	pslld  xmm0,0x18
    74a37e4ffb57:	movdqa xmm9,xmm0
    74a37e4ffb5c:	movdqu XMMWORD PTR [r12+0x180],xmm9
    74a37e4ffb66:	mov    r13d,0x0
    74a37e4ffb6c:	mov    r14,QWORD PTR [rsp+0x78]
    74a37e4ffb71:	and    r14,0xffff
    74a37e4ffb78:	mov    ecx,0xffffffff
    74a37e4ffb7d:	and    r14,rcx
    74a37e4ffb80:	mov    r15,r13
    74a37e4ffb83:	or     r15,r14
    74a37e4ffb86:	mov    r14,QWORD PTR [rsp+0x78]
    74a37e4ffb8b:	shr    r14,0x10
    74a37e4ffb8f:	and    r14,0xffff
    74a37e4ffb96:	mov    ecx,0xffffffff
    74a37e4ffb9b:	and    r14,rcx
    74a37e4ffb9e:	shl    r14,0x20
    74a37e4ffba2:	or     r15,r14
    74a37e4ffba5:	mov    r14,QWORD PTR [rsp+0x78]
    74a37e4ffbaa:	shr    r14,0x20
    74a37e4ffbae:	and    r14,0xffff
    74a37e4ffbb5:	mov    ecx,0xffffffff
    74a37e4ffbba:	and    r14,rcx
    74a37e4ffbbd:	or     r13,r14
    74a37e4ffbc0:	mov    r14,QWORD PTR [rsp+0x78]
    74a37e4ffbc5:	shr    r14,0x30
    74a37e4ffbc9:	and    r14,0xffff
    74a37e4ffbd0:	mov    ecx,0xffffffff
    74a37e4ffbd5:	and    r14,rcx
    74a37e4ffbd8:	shl    r14,0x20
    74a37e4ffbdc:	or     r13,r14
    74a37e4ffbdf:	mov    QWORD PTR [r12+0x140],r15
    74a37e4ffbe7:	mov    QWORD PTR [r12+0x148],r13
    74a37e4ffbef:	movdqu xmm6,XMMWORD PTR [r12+0x240]
    74a37e4ffbf9:	movdqa xmm1,xmm6
    74a37e4ffbfd:	por    xmm5,xmm1
    74a37e4ffc01:	movdqu xmm6,XMMWORD PTR [r12+0x220]
    74a37e4ffc0b:	movdqa xmm1,xmm6
    74a37e4ffc0f:	por    xmm4,xmm1
    74a37e4ffc13:	movdqu XMMWORD PTR [r12+0x210],xmm4
    74a37e4ffc1d:	movdqu xmm6,XMMWORD PTR [r12+0x260]
    74a37e4ffc27:	movdqa xmm0,xmm6
    74a37e4ffc2b:	pslld  xmm0,0x18
    74a37e4ffc30:	movdqa xmm10,xmm0
    74a37e4ffc35:	movdqu XMMWORD PTR [r12+0x220],xmm10
    74a37e4ffc3f:	movdqu xmm6,XMMWORD PTR [r12+0x160]
    74a37e4ffc49:	movdqa xmm1,xmm6
    74a37e4ffc4d:	por    xmm2,xmm1
    74a37e4ffc51:	movdqa xmm1,xmm7
    74a37e4ffc55:	por    xmm3,xmm1
    74a37e4ffc59:	movdqu XMMWORD PTR [r12+0x160],xmm3
    74a37e4ffc63:	mov    r13d,0x0
    74a37e4ffc69:	mov    r14,QWORD PTR [rsp+0x88]
    74a37e4ffc71:	and    r14,0xffff
    74a37e4ffc78:	mov    ecx,0xffffffff
    74a37e4ffc7d:	and    r14,rcx
    74a37e4ffc80:	mov    r15,r13
    74a37e4ffc83:	or     r15,r14
    74a37e4ffc86:	mov    r14,QWORD PTR [rsp+0x88]
    74a37e4ffc8e:	shr    r14,0x10
    74a37e4ffc92:	and    r14,0xffff
    74a37e4ffc99:	mov    ecx,0xffffffff
    74a37e4ffc9e:	and    r14,rcx
    74a37e4ffca1:	shl    r14,0x20
    74a37e4ffca5:	or     r15,r14
    74a37e4ffca8:	mov    r14,QWORD PTR [rsp+0x88]
    74a37e4ffcb0:	shr    r14,0x20
    74a37e4ffcb4:	and    r14,0xffff
    74a37e4ffcbb:	mov    ecx,0xffffffff
    74a37e4ffcc0:	and    r14,rcx
    74a37e4ffcc3:	or     r13,r14
    74a37e4ffcc6:	mov    r14,QWORD PTR [rsp+0x88]
    74a37e4ffcce:	shr    r14,0x30
    74a37e4ffcd2:	and    r14,0xffff
    74a37e4ffcd9:	mov    ecx,0xffffffff
    74a37e4ffcde:	and    r14,rcx
    74a37e4ffce1:	shl    r14,0x20
    74a37e4ffce5:	or     r13,r14
    74a37e4ffce8:	mov    QWORD PTR [r12+0x170],r15
    74a37e4ffcf0:	mov    QWORD PTR [r12+0x178],r13
    74a37e4ffcf8:	mov    r13d,0x0
    74a37e4ffcfe:	mov    r14,QWORD PTR [rsp+0x80]
    74a37e4ffd06:	and    r14,0xffff
    74a37e4ffd0d:	mov    ecx,0xffffffff
    74a37e4ffd12:	and    r14,rcx
    74a37e4ffd15:	mov    r15,r13
    74a37e4ffd18:	or     r15,r14
    74a37e4ffd1b:	mov    r14,QWORD PTR [rsp+0x80]
    74a37e4ffd23:	shr    r14,0x10
    74a37e4ffd27:	and    r14,0xffff
    74a37e4ffd2e:	mov    ecx,0xffffffff
    74a37e4ffd33:	and    r14,rcx
    74a37e4ffd36:	shl    r14,0x20
    74a37e4ffd3a:	or     r15,r14
    74a37e4ffd3d:	mov    r14,QWORD PTR [rsp+0x80]
    74a37e4ffd45:	shr    r14,0x20
    74a37e4ffd49:	and    r14,0xffff
    74a37e4ffd50:	mov    ecx,0xffffffff
    74a37e4ffd55:	and    r14,rcx
    74a37e4ffd58:	or     r13,r14
    74a37e4ffd5b:	mov    r14,QWORD PTR [rsp+0x80]
    74a37e4ffd63:	shr    r14,0x30
    74a37e4ffd67:	and    r14,0xffff
    74a37e4ffd6e:	mov    ecx,0xffffffff
    74a37e4ffd73:	and    r14,rcx
    74a37e4ffd76:	shl    r14,0x20
    74a37e4ffd7a:	or     r13,r14
    74a37e4ffd7d:	mov    QWORD PTR [r12+0x110],r15
    74a37e4ffd85:	mov    QWORD PTR [r12+0x118],r13
    74a37e4ffd8d:	movdqa xmm1,xmm8
    74a37e4ffd92:	por    xmm5,xmm1
    74a37e4ffd96:	movdqa xmm1,xmm9
    74a37e4ffd9b:	por    xmm4,xmm1
    74a37e4ffd9f:	mov    r13d,0x0
    74a37e4ffda5:	mov    r14,QWORD PTR [rsp+0x70]
    74a37e4ffdaa:	and    r14,0xffff
    74a37e4ffdb1:	mov    ecx,0xffffffff
    74a37e4ffdb6:	and    r14,rcx
    74a37e4ffdb9:	mov    r15,r13
    74a37e4ffdbc:	or     r15,r14
    74a37e4ffdbf:	mov    r14,QWORD PTR [rsp+0x70]
    74a37e4ffdc4:	shr    r14,0x10
    74a37e4ffdc8:	and    r14,0xffff
    74a37e4ffdcf:	mov    ecx,0xffffffff
    74a37e4ffdd4:	and    r14,rcx
    74a37e4ffdd7:	shl    r14,0x20
    74a37e4ffddb:	or     r15,r14
    74a37e4ffdde:	mov    r14,QWORD PTR [rsp+0x70]
    74a37e4ffde3:	shr    r14,0x20
    74a37e4ffde7:	and    r14,0xffff
    74a37e4ffdee:	mov    ecx,0xffffffff
    74a37e4ffdf3:	and    r14,rcx
    74a37e4ffdf6:	or     r13,r14
    74a37e4ffdf9:	mov    r14,QWORD PTR [rsp+0x70]
    74a37e4ffdfe:	shr    r14,0x30
    74a37e4ffe02:	and    r14,0xffff
    74a37e4ffe09:	mov    ecx,0xffffffff
    74a37e4ffe0e:	and    r14,rcx
    74a37e4ffe11:	shl    r14,0x20
    74a37e4ffe15:	or     r13,r14
    74a37e4ffe18:	mov    QWORD PTR [r12+0x180],r15
    74a37e4ffe20:	mov    QWORD PTR [r12+0x188],r13
    74a37e4ffe28:	movdqa xmm1,xmm10
    74a37e4ffe2d:	por    xmm2,xmm1
    74a37e4ffe31:	movdqu XMMWORD PTR [r12+0x150],xmm2
    74a37e4ffe3b:	movdqu xmm6,XMMWORD PTR [r12+0x140]
    74a37e4ffe45:	movdqa xmm1,xmm6
    74a37e4ffe49:	por    xmm3,xmm1
    74a37e4ffe4d:	movdqu XMMWORD PTR [r12+0x140],xmm3
    74a37e4ffe57:	movdqu xmm6,XMMWORD PTR [r12+0x110]
    74a37e4ffe61:	movdqa xmm1,xmm6
    74a37e4ffe65:	por    xmm4,xmm1
    74a37e4ffe69:	movdqu XMMWORD PTR [r12+0x110],xmm4
    74a37e4ffe73:	movdqu xmm6,XMMWORD PTR [r12+0x170]
    74a37e4ffe7d:	movdqa xmm1,xmm6
    74a37e4ffe81:	por    xmm5,xmm1
    74a37e4ffe85:	movdqu XMMWORD PTR [r12+0x120],xmm5
    74a37e4ffe8f:	movdqu xmm6,XMMWORD PTR [r12+0x180]
    74a37e4ffe99:	movdqa xmm1,xmm6
    74a37e4ffe9d:	por    xmm2,xmm1
    74a37e4ffea1:	movdqu XMMWORD PTR [r12+0x130],xmm2
    74a37e4ffeab:	mov    r13,QWORD PTR [r12+0xf8]
    74a37e4ffeb3:	mov    r14,r13
    74a37e4ffeb6:	add    r14,0x20
    74a37e4ffeba:	mov    r15,r14
    74a37e4ffebd:	add    r15,0x10
    74a37e4ffec1:	movdqu XMMWORD PTR [r14],xmm4
    74a37e4ffec6:	mov    r14d,0x0
    74a37e4ffecc:	mov    DWORD PTR [r12+0x32c],r14d
    74a37e4ffed4:	movdqu XMMWORD PTR [r15],xmm5
    74a37e4ffed9:	mov    r14,r13
    74a37e4ffedc:	add    r14,0x10
    74a37e4ffee0:	movdqu XMMWORD PTR [r13+0x0],xmm3
    74a37e4ffee6:	movdqu XMMWORD PTR [r14],xmm2
    74a37e4ffeeb:	mov    r14d,DWORD PTR [r13+0x0]
    74a37e4ffeef:	mov    QWORD PTR [r12+0x60],r14
    74a37e4ffef4:	jmp    0x74a37e4ffef9
    74a37e4ffef9:	mov    r13,QWORD PTR [r12+0x58]
    74a37e4ffefe:	mov    r14,QWORD PTR [r12+0x48]
    74a37e4fff03:	add    r14,r13
    74a37e4fff06:	mov    QWORD PTR [r12+0x68],r14
    74a37e4fff0b:	add    r13,0x4
    74a37e4fff0f:	mov    QWORD PTR [r12+0x58],r13
    74a37e4fff14:	mov    r15,r14
    74a37e4fff17:	add    r15,0x4
    74a37e4fff1b:	mov    eax,DWORD PTR [r15]
    74a37e4fff1e:	mov    QWORD PTR [r12+0x70],rax
    74a37e4fff23:	mov    r15,r14
    74a37e4fff26:	add    r15,0x38
    74a37e4fff2a:	mov    r8d,DWORD PTR [r15]
    74a37e4fff2d:	mov    QWORD PTR [r12+0x78],r8
    74a37e4fff32:	mov    r15,r14
    74a37e4fff35:	add    r15,0x24
    74a37e4fff39:	mov    r9d,DWORD PTR [r15]
    74a37e4fff3c:	mov    QWORD PTR [r12+0x90],r9
    74a37e4fff44:	sub    r13,0xc0
    74a37e4fff4b:	setne  BYTE PTR [rsp+0xb8]
    74a37e4fff53:	mov    r11,rax
    74a37e4fff56:	lahf
    74a37e4fff57:	seto   al
    74a37e4fff5a:	mov    WORD PTR [rsp+0xb0],ax
    74a37e4fff62:	mov    rax,r11
    74a37e4fff65:	mov    r13d,DWORD PTR [r12+0x70]
    74a37e4fff6a:	mov    r13d,r13d
    74a37e4fff6d:	mov    r13d,r13d
    74a37e4fff70:	ror    r13d,0x7
    74a37e4fff74:	mov    QWORD PTR [r12+0x80],r13
    74a37e4fff7c:	mov    r15d,r8d
    74a37e4fff7f:	mov    r15d,r15d
    74a37e4fff82:	ror    r15d,0x11
    74a37e4fff86:	mov    QWORD PTR [r12+0x88],r15
    74a37e4fff8e:	mov    ebp,DWORD PTR [r12+0x60]
    74a37e4fff93:	add    r9d,ebp
    74a37e4fff96:	mov    QWORD PTR [r12+0x60],r9
    74a37e4fff9b:	mov    ebp,DWORD PTR [r12+0x70]
    74a37e4fffa0:	mov    ebp,ebp
    74a37e4fffa2:	mov    ebp,ebp
    74a37e4fffa4:	ror    ebp,0x12
    74a37e4fffa7:	xor    r13d,ebp
    74a37e4fffaa:	mov    QWORD PTR [r12+0x80],r13
    74a37e4fffb2:	mov    ebp,r8d
    74a37e4fffb5:	mov    ebp,ebp
    74a37e4fffb7:	ror    ebp,0x13
    74a37e4fffba:	xor    r15d,ebp
    74a37e4fffbd:	mov    QWORD PTR [r12+0x88],r15
    74a37e4fffc5:	mov    ebp,DWORD PTR [r12+0x70]
    74a37e4fffca:	mov    ebp,ebp
    74a37e4fffcc:	mov    ebp,ebp
    74a37e4fffce:	shr    ebp,0x3
    74a37e4fffd1:	xor    r13d,ebp
    74a37e4fffd4:	mov    QWORD PTR [r12+0x80],r13
    74a37e4fffdc:	mov    r8d,r8d
    74a37e4fffdf:	shr    r8d,0xa
    74a37e4fffe3:	xor    r15d,r8d
    74a37e4fffe6:	mov    QWORD PTR [r12+0x78],r15
    74a37e4fffeb:	add    r9d,r13d
    74a37e4fffee:	mov    QWORD PTR [r12+0x60],r9
    74a37e4ffff3:	add    r9d,r15d
    74a37e4ffff6:	mov    QWORD PTR [r12+0x60],r9
    74a37e4ffffb:	add    r14,0x40
    74a37e4fffff:	mov    DWORD PTR [r14],r9d
    74a37e500002:	mov    r13d,0x0
    74a37e500008:	mov    DWORD PTR [r12+0x32c],r13d
    74a37e500010:	mov    r13d,0x0
    74a37e500016:	mov    ecx,DWORD PTR [r12+0x70]
    74a37e50001b:	mov    ecx,ecx
    74a37e50001d:	mov    r14d,r13d
    74a37e500020:	or     r14d,ecx
    74a37e500023:	mov    QWORD PTR [r12+0x60],r14
    74a37e500028:	mov    rcx,QWORD PTR [r12+0x380]
    74a37e500030:	jrcxz  0x74a37e500037
    74a37e500032:	jmp    0x74a37e50081a
    74a37e500037:	cmp    BYTE PTR [rsp+0xb8],0x0
    74a37e50003f:	jne    0x74a37e4ffef9
    74a37e500045:	jmp    0x74a37e50004a
    74a37e50004a:	mov    r13,QWORD PTR [r12]
    74a37e50004e:	mov    r14,r13
    74a37e500051:	add    r14,0x4
    74a37e500055:	mov    r15d,DWORD PTR [r13+0x0]
    74a37e500059:	mov    ebp,DWORD PTR [r14]
    74a37e50005c:	mov    QWORD PTR [r12+0x78],r15
    74a37e500061:	mov    QWORD PTR [r12+0x80],rbp
    74a37e500069:	mov    r14,r13
    74a37e50006c:	add    r14,0x8
    74a37e500070:	mov    r8,r14
    74a37e500073:	add    r8,0x4
    74a37e500077:	mov    r9d,DWORD PTR [r14]
    74a37e50007a:	mov    eax,DWORD PTR [r8]
    74a37e50007d:	mov    QWORD PTR [rsp+0x90],rax
    74a37e500085:	mov    QWORD PTR [r12+0x70],r9
    74a37e50008a:	mov    rax,QWORD PTR [rsp+0x90]
    74a37e500092:	mov    QWORD PTR [r12+0x68],rax
    74a37e500097:	mov    r8,r13
    74a37e50009a:	add    r8,0x18
    74a37e50009e:	mov    r14,r8
    74a37e5000a1:	add    r14,0x4
    74a37e5000a5:	mov    eax,DWORD PTR [r8]
    74a37e5000a8:	mov    QWORD PTR [rsp+0x98],rax
    74a37e5000b0:	mov    r8d,DWORD PTR [r14]
    74a37e5000b3:	mov    rax,QWORD PTR [rsp+0x98]
    74a37e5000bb:	mov    QWORD PTR [r12+0x58],rax
    74a37e5000c0:	mov    QWORD PTR [r12+0x60],r8
    74a37e5000c5:	add    r13,0x10
    74a37e5000c9:	mov    r14,r13
    74a37e5000cc:	add    r14,0x4
    74a37e5000d0:	mov    eax,DWORD PTR [r13+0x0]
    74a37e5000d4:	mov    QWORD PTR [rsp+0xa0],rax
    74a37e5000dc:	mov    eax,DWORD PTR [r14]
    74a37e5000df:	mov    QWORD PTR [rsp+0xa8],rax
    74a37e5000e7:	mov    rax,QWORD PTR [rsp+0xa0]
    74a37e5000ef:	mov    QWORD PTR [r12+0x18],rax
    74a37e5000f4:	mov    rax,QWORD PTR [rsp+0xa8]
    74a37e5000fc:	mov    QWORD PTR [r12+0x90],rax
    74a37e500104:	mov    r14d,0x0
    74a37e50010a:	mov    QWORD PTR [r12+0x88],r14
    74a37e500112:	mov    r14d,0x0
    74a37e500118:	mov    r13d,r14d
    74a37e50011b:	or     r13d,r15d
    74a37e50011e:	mov    QWORD PTR [r12+0xa8],r13
    74a37e500126:	mov    r13d,0x0
    74a37e50012c:	mov    r14d,r13d
    74a37e50012f:	or     r14d,ebp
    74a37e500132:	mov    QWORD PTR [r12+0x38],r14
    74a37e500137:	mov    r13d,0x0
    74a37e50013d:	mov    r14d,r13d
    74a37e500140:	or     r14d,r9d
    74a37e500143:	mov    QWORD PTR [r12+0x98],r14
    74a37e50014b:	mov    r13d,0x0
    74a37e500151:	mov    ecx,DWORD PTR [rsp+0x90]
    74a37e500158:	mov    r14d,r13d
    74a37e50015b:	or     r14d,ecx
    74a37e50015e:	mov    QWORD PTR [r12+0x28],r14
    74a37e500163:	mov    r13d,0x0
    74a37e500169:	mov    r14d,r13d
    74a37e50016c:	or     r14d,r8d
    74a37e50016f:	mov    QWORD PTR [r12+0xb0],r14
    74a37e500177:	mov    r13d,0x0
    74a37e50017d:	mov    ecx,DWORD PTR [rsp+0x98]
    74a37e500184:	mov    r14d,r13d
    74a37e500187:	or     r14d,ecx
    74a37e50018a:	mov    QWORD PTR [r12+0xc0],r14
    74a37e500192:	mov    r13d,0x0
    74a37e500198:	mov    ecx,DWORD PTR [rsp+0xa8]
    74a37e50019f:	mov    r14d,r13d
    74a37e5001a2:	or     r14d,ecx
    74a37e5001a5:	mov    QWORD PTR [r12+0xc8],r14
    74a37e5001ad:	mov    r13d,0x0
    74a37e5001b3:	mov    ecx,DWORD PTR [rsp+0xa0]
    74a37e5001ba:	mov    r14d,r13d
    74a37e5001bd:	or     r14d,ecx
    74a37e5001c0:	mov    QWORD PTR [r12+0xb8],r14
    74a37e5001c8:	jmp    0x74a37e5001cd
    74a37e5001cd:	mov    r13d,0x0
    74a37e5001d3:	mov    r14d,DWORD PTR [r12+0xb8]
    74a37e5001db:	mov    eax,r13d
    74a37e5001de:	or     eax,r14d
    74a37e5001e1:	mov    QWORD PTR [r12+0x30],rax
    74a37e5001e6:	mov    r13d,0x0
    74a37e5001ec:	mov    ebp,DWORD PTR [r12+0xc0]
    74a37e5001f4:	mov    eax,r13d
    74a37e5001f7:	or     eax,ebp
    74a37e5001f9:	mov    QWORD PTR [r12+0xa0],rax
    74a37e500201:	mov    r13d,0x0
    74a37e500207:	mov    ebp,DWORD PTR [r12+0x28]
    74a37e50020c:	mov    eax,r13d
    74a37e50020f:	or     eax,ebp
    74a37e500211:	mov    QWORD PTR [r12+0xc0],rax
    74a37e500219:	mov    r13d,0x0
    74a37e50021f:	mov    ebp,DWORD PTR [r12+0x98]
    74a37e500227:	mov    eax,r13d
    74a37e50022a:	or     eax,ebp
    74a37e50022c:	mov    QWORD PTR [r12+0x28],rax
    74a37e500231:	mov    r13d,0x0
    74a37e500237:	mov    ebp,DWORD PTR [r12+0x38]
    74a37e50023c:	mov    eax,r13d
    74a37e50023f:	or     eax,ebp
    74a37e500241:	mov    QWORD PTR [r12+0x98],rax
    74a37e500249:	mov    r13d,0x0
    74a37e50024f:	mov    ebp,DWORD PTR [r12+0xa8]
    74a37e500257:	mov    eax,r13d
    74a37e50025a:	or     eax,ebp
    74a37e50025c:	mov    QWORD PTR [r12+0x38],rax
    74a37e500261:	mov    r14d,r14d
    74a37e500264:	ror    r14d,0x6
    74a37e500268:	mov    QWORD PTR [r12+0xb8],r14
    74a37e500270:	mov    r13d,DWORD PTR [r12+0xc8]
    74a37e500278:	mov    ebp,DWORD PTR [r12+0x30]
    74a37e50027d:	mov    ebp,ebp
    74a37e50027f:	and    ebp,r13d
    74a37e500282:	mov    QWORD PTR [r12+0xa8],rbp
    74a37e50028a:	mov    r9d,DWORD PTR [r12+0x38]
    74a37e50028f:	mov    r9d,r9d
    74a37e500292:	mov    r9d,r9d
    74a37e500295:	ror    r9d,0x2
    74a37e500299:	mov    QWORD PTR [r12+0xd0],r9
    74a37e5002a1:	mov    r15d,0x0
    74a37e5002a7:	mov    eax,r15d
    74a37e5002aa:	or     eax,r13d
    74a37e5002ad:	mov    QWORD PTR [r12+0x20],rax
    74a37e5002b2:	mov    rax,QWORD PTR [r12+0x88]
    74a37e5002ba:	mov    r15,QWORD PTR [r12+0x50]
    74a37e5002bf:	mov    rcx,QWORD PTR [r12+0x88]
    74a37e5002c7:	add    r15,rcx
    74a37e5002ca:	mov    r13d,DWORD PTR [r15]
    74a37e5002cd:	mov    QWORD PTR [r12+0xc8],r13
    74a37e5002d5:	mov    ecx,DWORD PTR [r12+0x30]
    74a37e5002da:	mov    ecx,ecx
    74a37e5002dc:	mov    r15d,DWORD PTR [r12+0xa0]
    74a37e5002e4:	mov    r15d,r15d
    74a37e5002e7:	not    rcx
    74a37e5002ea:	and    r15d,ecx
    74a37e5002ed:	mov    QWORD PTR [r12+0xd8],r15
    74a37e5002f5:	mov    r8d,DWORD PTR [r12+0xb0]
    74a37e5002fd:	add    ebp,r8d
    74a37e500300:	mov    QWORD PTR [r12+0xa8],rbp
    74a37e500308:	mov    r8d,DWORD PTR [r12+0x30]
    74a37e50030d:	mov    r8d,r8d
    74a37e500310:	mov    r8d,r8d
    74a37e500313:	ror    r8d,0xb
    74a37e500317:	xor    r14d,r8d
    74a37e50031a:	mov    QWORD PTR [r12+0xb0],r14
    74a37e500322:	mov    r8d,DWORD PTR [r12+0x38]
    74a37e500327:	mov    r8d,r8d
    74a37e50032a:	mov    r8d,r8d
    74a37e50032d:	ror    r8d,0xd
    74a37e500331:	xor    r9d,r8d
    74a37e500334:	mov    QWORD PTR [r12+0xd0],r9
    74a37e50033c:	add    ebp,r15d
    74a37e50033f:	mov    QWORD PTR [r12+0xa8],rbp
    74a37e500347:	mov    r15,QWORD PTR [r12+0x48]
    74a37e50034c:	mov    rcx,QWORD PTR [r12+0x88]
    74a37e500354:	add    r15,rcx
    74a37e500357:	mov    r8d,DWORD PTR [r15]
    74a37e50035a:	mov    QWORD PTR [r12+0xb8],r8
    74a37e500362:	mov    ecx,DWORD PTR [r12+0x98]
    74a37e50036a:	mov    ecx,ecx
    74a37e50036c:	mov    eax,DWORD PTR [r12+0x28]
    74a37e500371:	mov    eax,eax
    74a37e500373:	and    eax,ecx
    74a37e500375:	mov    QWORD PTR [r12+0xd8],rax
    74a37e50037d:	add    ebp,r13d
    74a37e500380:	mov    QWORD PTR [r12+0xa8],rbp
    74a37e500388:	mov    ecx,DWORD PTR [r12+0x98]
    74a37e500390:	mov    ecx,ecx
    74a37e500392:	mov    r13d,DWORD PTR [r12+0x28]
    74a37e500397:	mov    r13d,r13d
    74a37e50039a:	xor    r13d,ecx
    74a37e50039d:	mov    QWORD PTR [r12+0xc8],r13
    74a37e5003a5:	mov    r15d,DWORD PTR [r12+0x30]
    74a37e5003aa:	mov    r15d,r15d
    74a37e5003ad:	mov    r15d,r15d
    74a37e5003b0:	ror    r15d,0x19
    74a37e5003b4:	xor    r14d,r15d
    74a37e5003b7:	mov    QWORD PTR [r12+0xb0],r14
    74a37e5003bf:	mov    ecx,DWORD PTR [r12+0x38]
    74a37e5003c4:	mov    ecx,ecx
    74a37e5003c6:	and    r13d,ecx
    74a37e5003c9:	mov    QWORD PTR [r12+0xc8],r13
    74a37e5003d1:	mov    r15d,DWORD PTR [r12+0x38]
    74a37e5003d6:	mov    r15d,r15d
    74a37e5003d9:	mov    r15d,r15d
    74a37e5003dc:	ror    r15d,0x16
    74a37e5003e0:	xor    r9d,r15d
    74a37e5003e3:	mov    QWORD PTR [r12+0xd0],r9
    74a37e5003eb:	add    ebp,r8d
    74a37e5003ee:	mov    QWORD PTR [r12+0xa8],rbp
    74a37e5003f6:	mov    ecx,DWORD PTR [r12+0xd8]
    74a37e5003fe:	mov    ecx,ecx
    74a37e500400:	xor    r13d,ecx
    74a37e500403:	mov    QWORD PTR [r12+0xb8],r13
    74a37e50040b:	add    ebp,r14d
    74a37e50040e:	mov    QWORD PTR [r12+0xa8],rbp
    74a37e500416:	mov    r14,QWORD PTR [r12+0x88]
    74a37e50041e:	add    r14,0x4
    74a37e500422:	mov    QWORD PTR [r12+0x88],r14
    74a37e50042a:	add    r13d,r9d
    74a37e50042d:	mov    QWORD PTR [r12+0xb0],r13
    74a37e500435:	mov    ecx,DWORD PTR [r12+0xc0]
    74a37e50043d:	mov    ecx,ecx
    74a37e50043f:	mov    r15d,ebp
    74a37e500442:	add    r15d,ecx
    74a37e500445:	mov    QWORD PTR [r12+0xb8],r15
    74a37e50044d:	sub    r14,0x100
    74a37e500454:	setne  BYTE PTR [rsp+0xb8]
    74a37e50045c:	mov    r11,rax
    74a37e50045f:	lahf
    74a37e500460:	seto   al
    74a37e500463:	mov    WORD PTR [rsp+0xb0],ax
    74a37e50046b:	mov    rax,r11
    74a37e50046e:	add    r13d,ebp
    74a37e500471:	mov    QWORD PTR [r12+0xa8],r13
    74a37e500479:	mov    r13d,0x0
    74a37e50047f:	mov    ecx,DWORD PTR [r12+0xa0]
    74a37e500487:	mov    ecx,ecx
    74a37e500489:	mov    r14d,r13d
    74a37e50048c:	or     r14d,ecx
    74a37e50048f:	mov    QWORD PTR [r12+0xb0],r14
    74a37e500497:	mov    r13d,0x0
    74a37e50049d:	mov    ecx,DWORD PTR [r12+0x20]
    74a37e5004a2:	mov    ecx,ecx
    74a37e5004a4:	mov    r14d,r13d
    74a37e5004a7:	or     r14d,ecx
    74a37e5004aa:	mov    QWORD PTR [r12+0xc0],r14
    74a37e5004b2:	mov    r13d,0x0
    74a37e5004b8:	mov    ecx,DWORD PTR [r12+0x30]
    74a37e5004bd:	mov    ecx,ecx
    74a37e5004bf:	mov    r14d,r13d
    74a37e5004c2:	or     r14d,ecx
    74a37e5004c5:	mov    QWORD PTR [r12+0xc8],r14
    74a37e5004cd:	mov    rcx,QWORD PTR [r12+0x380]
    74a37e5004d5:	jrcxz  0x74a37e5004dc
    74a37e5004d7:	jmp    0x74a37e5008a2
    74a37e5004dc:	cmp    BYTE PTR [rsp+0xb8],0x0
    74a37e5004e4:	jne    0x74a37e5001cd
    74a37e5004ea:	jmp    0x74a37e5004ef
    74a37e5004ef:	mov    r13d,DWORD PTR [r12+0x70]
    74a37e5004f4:	mov    r14d,DWORD PTR [r12+0x98]
    74a37e5004fc:	add    r14d,r13d
    74a37e5004ff:	mov    QWORD PTR [r12+0x70],r14
    74a37e500504:	mov    r13d,DWORD PTR [r12+0x68]
    74a37e500509:	mov    r15d,DWORD PTR [r12+0x28]
    74a37e50050e:	add    r15d,r13d
    74a37e500511:	mov    QWORD PTR [r12+0x68],r15
    74a37e500516:	mov    r13d,0x0
    74a37e50051c:	mov    QWORD PTR [r12+0x88],r13
    74a37e500524:	mov    r13d,DWORD PTR [r12+0x78]
    74a37e500529:	mov    ebp,DWORD PTR [r12+0xa8]
    74a37e500531:	add    ebp,r13d
    74a37e500534:	mov    QWORD PTR [r12+0x78],rbp
    74a37e500539:	mov    r13d,DWORD PTR [r12+0x80]
    74a37e500541:	mov    r8d,DWORD PTR [r12+0x38]
    74a37e500546:	add    r8d,r13d
    74a37e500549:	mov    QWORD PTR [r12+0x80],r8
    74a37e500551:	mov    rax,QWORD PTR [r12]
    74a37e500555:	mov    r9,QWORD PTR [r12]
    74a37e500559:	add    r9,0x8
    74a37e50055d:	mov    r13,r9
    74a37e500560:	add    r13,0x4
    74a37e500564:	mov    DWORD PTR [r9],r14d
    74a37e500567:	mov    r14d,0x0
    74a37e50056d:	mov    DWORD PTR [r12+0x32c],r14d
    74a37e500575:	mov    DWORD PTR [r13+0x0],r15d
    74a37e500579:	mov    r13d,DWORD PTR [r12+0x18]
    74a37e50057e:	mov    r14d,DWORD PTR [r12+0xb8]
    74a37e500586:	add    r14d,r13d
    74a37e500589:	mov    QWORD PTR [r12+0x68],r14
    74a37e50058e:	mov    r13d,DWORD PTR [r12+0x90]
    74a37e500596:	mov    r15d,DWORD PTR [r12+0x30]
    74a37e50059b:	add    r15d,r13d
    74a37e50059e:	mov    QWORD PTR [r12+0x70],r15
    74a37e5005a3:	mov    r13d,DWORD PTR [r12+0x58]
    74a37e5005a8:	mov    r9d,DWORD PTR [r12+0x20]
    74a37e5005ad:	mov    eax,r9d
    74a37e5005b0:	add    eax,r13d
    74a37e5005b3:	mov    QWORD PTR [r12+0x58],rax
    74a37e5005b8:	mov    r13d,DWORD PTR [r12+0x60]
    74a37e5005bd:	mov    r9d,DWORD PTR [r12+0xa0]
    74a37e5005c5:	add    r9d,r13d
    74a37e5005c8:	mov    QWORD PTR [r12+0x60],r9
    74a37e5005cd:	mov    r13,QWORD PTR [r12]
    74a37e5005d1:	add    r13,0x4
    74a37e5005d5:	mov    rdi,QWORD PTR [r12]
    74a37e5005d9:	mov    DWORD PTR [rdi],ebp
    74a37e5005db:	mov    DWORD PTR [r13+0x0],r8d
    74a37e5005df:	mov    r13,QWORD PTR [r12]
    74a37e5005e3:	add    r13,0x10
    74a37e5005e7:	mov    rbp,r13
    74a37e5005ea:	add    rbp,0x4
    74a37e5005ee:	mov    DWORD PTR [r13+0x0],r14d
    74a37e5005f2:	mov    DWORD PTR [rbp+0x0],r15d
    74a37e5005f6:	mov    r13,QWORD PTR [r12]
    74a37e5005fa:	add    r13,0x18
    74a37e5005fe:	mov    r14,r13
    74a37e500601:	add    r14,0x4
    74a37e500605:	mov    eax,DWORD PTR [r12+0x58]
    74a37e50060a:	mov    DWORD PTR [r13+0x0],eax
    74a37e50060e:	mov    DWORD PTR [r14],r9d
    74a37e500611:	mov    r13,QWORD PTR [r12]
    74a37e500615:	add    r13,0x68
    74a37e500619:	mov    r14d,0x0
    74a37e50061f:	mov    QWORD PTR [r13+0x0],r14
    74a37e500623:	mov    rcx,QWORD PTR [r12+0x380]
    74a37e50062b:	jrcxz  0x74a37e500632
    74a37e50062d:	jmp    0x74a37e50092a
    74a37e500632:	jmp    0x74a37e500637
    74a37e500637:	mov    r13,QWORD PTR [r12+0x10]
    74a37e50063c:	sub    r13,0x1
    74a37e500640:	mov    QWORD PTR [r12+0x10],r13
    74a37e500645:	mov    rax,r13
    74a37e500648:	test   rax,rax
    74a37e50064b:	je     0x74a37e500656
    74a37e500651:	jmp    0x74a37e4fe75a
    74a37e500656:	mov    r13,QWORD PTR [r12+0xf8]
    74a37e50065e:	mov    r14,r13
    74a37e500661:	add    r14,0x140
    74a37e500668:	mov    r15,r14
    74a37e50066b:	add    r15,0x8
    74a37e50066f:	mov    rbp,QWORD PTR [r14]
    74a37e500672:	mov    r14,QWORD PTR [r15]
    74a37e500675:	mov    QWORD PTR [r12+0xa0],rbp
    74a37e50067d:	mov    QWORD PTR [r12+0x98],r14
    74a37e500685:	mov    r14,r13
    74a37e500688:	add    r14,0x130
    74a37e50068f:	mov    r15,r14
    74a37e500692:	add    r15,0x8
    74a37e500696:	mov    rbp,QWORD PTR [r14]
    74a37e500699:	mov    r14,QWORD PTR [r15]
    74a37e50069c:	mov    QWORD PTR [r12+0xb0],rbp
    74a37e5006a4:	mov    QWORD PTR [r12+0xa8],r14
    74a37e5006ac:	mov    r14,r13
    74a37e5006af:	add    r14,0x120
    74a37e5006b6:	mov    r15,r14
    74a37e5006b9:	add    r15,0x8
    74a37e5006bd:	mov    rbp,QWORD PTR [r14]
    74a37e5006c0:	mov    r14,QWORD PTR [r15]
    74a37e5006c3:	mov    QWORD PTR [r12+0xc0],rbp
    74a37e5006cb:	mov    QWORD PTR [r12+0xb8],r14
    74a37e5006d3:	mov    r14,r13
    74a37e5006d6:	add    r14,0x110
    74a37e5006dd:	mov    r15,r14
    74a37e5006e0:	add    r15,0x8
    74a37e5006e4:	mov    rbp,QWORD PTR [r14]
    74a37e5006e7:	mov    r14,QWORD PTR [r15]
    74a37e5006ea:	mov    QWORD PTR [r12+0xd0],rbp
    74a37e5006f2:	mov    QWORD PTR [r12+0xc8],r14
    74a37e5006fa:	mov    r14,r13
    74a37e5006fd:	add    r14,0x100
    74a37e500704:	mov    r15,r14
    74a37e500707:	add    r15,0x8
    74a37e50070b:	mov    rbp,QWORD PTR [r14]
    74a37e50070e:	mov    r14,QWORD PTR [r15]
    74a37e500711:	mov    QWORD PTR [r12+0xe8],rbp
    74a37e500719:	mov    QWORD PTR [r12+0xd8],r14
    74a37e500721:	add    r13,0x150
    74a37e500728:	mov    QWORD PTR [r12+0xf8],r13
    74a37e500730:	jmp    0x74a37e500735
    74a37e500735:	mov    rcx,QWORD PTR [r12+0x380]
    74a37e50073d:	jrcxz  0x74a37e500744
    74a37e50073f:	jmp    0x74a37e5009b2
    74a37e500744:	mov    r13,QWORD PTR [r12+0xf0]
    74a37e50074c:	mov    QWORD PTR [r12+0x100],r13
    74a37e500754:	mov    r11,QWORD PTR [rsp+0xb0]
    74a37e50075c:	mov    QWORD PTR [r12+0x398],r11
    74a37e500764:	mov    rdi,QWORD PTR [r12+0x100]
    74a37e50076c:	add    rsp,0xc0
    74a37e500773:	movabs r11,0x5715466e9940
    74a37e50077d:	jmp    r11
    74a37e500780:	mov    eax,0x41078c
    74a37e500785:	mov    QWORD PTR [r12+0x100],rax
    74a37e50078d:	push   rdx
    74a37e50078e:	push   rsi
    74a37e50078f:	push   r10
    74a37e500791:	push   r11
    74a37e500793:	mov    r11,rax
    74a37e500796:	lahf
    74a37e500797:	seto   al
    74a37e50079a:	mov    WORD PTR [rsp+0xd0],ax
    74a37e5007a2:	mov    rax,r11
    74a37e5007a5:	mov    rdx,QWORD PTR [rsp+0xd0]
    74a37e5007ad:	mov    r10d,edx
    74a37e5007b0:	and    r10d,0xc000
    74a37e5007b7:	shl    r10d,0x10
    74a37e5007bb:	mov    r11d,edx
    74a37e5007be:	and    r11d,0x100
    74a37e5007c5:	shl    r11d,0x15
    74a37e5007c9:	or     r10d,r11d
    74a37e5007cc:	and    edx,0x1
    74a37e5007cf:	shl    edx,0x1c
    74a37e5007d2:	or     r10d,edx
    74a37e5007d5:	btc    r10,0x1d
    74a37e5007da:	mov    r11d,0xf0000000
    74a37e5007e0:	and    r11,r10
    74a37e5007e3:	movabs rsi,0xffffffff0fffffff
    74a37e5007ed:	and    rbx,rsi
    74a37e5007f0:	or     rbx,r11
    74a37e5007f3:	pop    r11
    74a37e5007f5:	pop    r10
    74a37e5007f7:	pop    rsi
    74a37e5007f8:	pop    rdx
    74a37e5007f9:	mov    QWORD PTR [r12+0x108],rbx
    74a37e500801:	add    rsp,0xc0
    74a37e500808:	mov    eax,0xc
    74a37e50080d:	movabs r11,0x5715466e9ca0
    74a37e500817:	jmp    r11
    74a37e50081a:	mov    eax,0x410888
    74a37e50081f:	mov    QWORD PTR [r12+0x100],rax
    74a37e500827:	push   rdx
    74a37e500828:	push   rsi
    74a37e500829:	push   r10
    74a37e50082b:	push   r11
    74a37e50082d:	mov    rdx,QWORD PTR [rsp+0xd0]
    74a37e500835:	mov    r10d,edx
    74a37e500838:	and    r10d,0xc000
    74a37e50083f:	shl    r10d,0x10
    74a37e500843:	mov    r11d,edx
    74a37e500846:	and    r11d,0x100
    74a37e50084d:	shl    r11d,0x15
    74a37e500851:	or     r10d,r11d
    74a37e500854:	and    edx,0x1
    74a37e500857:	shl    edx,0x1c
    74a37e50085a:	or     r10d,edx
    74a37e50085d:	btc    r10,0x1d
    74a37e500862:	mov    r11d,0xf0000000
    74a37e500868:	and    r11,r10
    74a37e50086b:	movabs rsi,0xffffffff0fffffff
    74a37e500875:	and    rbx,rsi
    74a37e500878:	or     rbx,r11
    74a37e50087b:	pop    r11
    74a37e50087d:	pop    r10
    74a37e50087f:	pop    rsi
    74a37e500880:	pop    rdx
    74a37e500881:	mov    QWORD PTR [r12+0x108],rbx
    74a37e500889:	add    rsp,0xc0
    74a37e500890:	mov    eax,0xc
    74a37e500895:	movabs r11,0x5715466e9ca0
    74a37e50089f:	jmp    r11
    74a37e5008a2:	mov    eax,0x410948
    74a37e5008a7:	mov    QWORD PTR [r12+0x100],rax
    74a37e5008af:	push   rdx
    74a37e5008b0:	push   rsi
    74a37e5008b1:	push   r10
    74a37e5008b3:	push   r11
    74a37e5008b5:	mov    rdx,QWORD PTR [rsp+0xd0]
    74a37e5008bd:	mov    r10d,edx
    74a37e5008c0:	and    r10d,0xc000
    74a37e5008c7:	shl    r10d,0x10
    74a37e5008cb:	mov    r11d,edx
    74a37e5008ce:	and    r11d,0x100
    74a37e5008d5:	shl    r11d,0x15
    74a37e5008d9:	or     r10d,r11d
    74a37e5008dc:	and    edx,0x1
    74a37e5008df:	shl    edx,0x1c
    74a37e5008e2:	or     r10d,edx
    74a37e5008e5:	btc    r10,0x1d
    74a37e5008ea:	mov    r11d,0xf0000000
    74a37e5008f0:	and    r11,r10
    74a37e5008f3:	movabs rsi,0xffffffff0fffffff
    74a37e5008fd:	and    rbx,rsi
    74a37e500900:	or     rbx,r11
    74a37e500903:	pop    r11
    74a37e500905:	pop    r10
    74a37e500907:	pop    rsi
    74a37e500908:	pop    rdx
    74a37e500909:	mov    QWORD PTR [r12+0x108],rbx
    74a37e500911:	add    rsp,0xc0
    74a37e500918:	mov    eax,0xc
    74a37e50091d:	movabs r11,0x5715466e9ca0
    74a37e500927:	jmp    r11
    74a37e50092a:	mov    eax,0x410984
    74a37e50092f:	mov    QWORD PTR [r12+0x100],rax
    74a37e500937:	push   rdx
    74a37e500938:	push   rsi
    74a37e500939:	push   r10
    74a37e50093b:	push   r11
    74a37e50093d:	mov    rdx,QWORD PTR [rsp+0xd0]
    74a37e500945:	mov    r10d,edx
    74a37e500948:	and    r10d,0xc000
    74a37e50094f:	shl    r10d,0x10
    74a37e500953:	mov    r11d,edx
    74a37e500956:	and    r11d,0x100
    74a37e50095d:	shl    r11d,0x15
    74a37e500961:	or     r10d,r11d
    74a37e500964:	and    edx,0x1
    74a37e500967:	shl    edx,0x1c
    74a37e50096a:	or     r10d,edx
    74a37e50096d:	btc    r10,0x1d
    74a37e500972:	mov    r11d,0xf0000000
    74a37e500978:	and    r11,r10
    74a37e50097b:	movabs rsi,0xffffffff0fffffff
    74a37e500985:	and    rbx,rsi
    74a37e500988:	or     rbx,r11
    74a37e50098b:	pop    r11
    74a37e50098d:	pop    r10
    74a37e50098f:	pop    rsi
    74a37e500990:	pop    rdx
    74a37e500991:	mov    QWORD PTR [r12+0x108],rbx
    74a37e500999:	add    rsp,0xc0
    74a37e5009a0:	mov    eax,0xc
    74a37e5009a5:	movabs r11,0x5715466e9ca0
    74a37e5009af:	jmp    r11
    74a37e5009b2:	mov    eax,0x4109a0
    74a37e5009b7:	mov    QWORD PTR [r12+0x100],rax
    74a37e5009bf:	push   rdx
    74a37e5009c0:	push   rsi
    74a37e5009c1:	push   r10
    74a37e5009c3:	push   r11
    74a37e5009c5:	mov    rdx,QWORD PTR [rsp+0xd0]
    74a37e5009cd:	mov    r10d,edx
    74a37e5009d0:	and    r10d,0xc000
    74a37e5009d7:	shl    r10d,0x10
    74a37e5009db:	mov    r11d,edx
    74a37e5009de:	and    r11d,0x100
    74a37e5009e5:	shl    r11d,0x15
    74a37e5009e9:	or     r10d,r11d
    74a37e5009ec:	and    edx,0x1
    74a37e5009ef:	shl    edx,0x1c
    74a37e5009f2:	or     r10d,edx
    74a37e5009f5:	btc    r10,0x1d
    74a37e5009fa:	mov    r11d,0xf0000000
    74a37e500a00:	and    r11,r10
    74a37e500a03:	movabs rsi,0xffffffff0fffffff
    74a37e500a0d:	and    rbx,rsi
    74a37e500a10:	or     rbx,r11
    74a37e500a13:	pop    r11
    74a37e500a15:	pop    r10
    74a37e500a17:	pop    rsi
    74a37e500a18:	pop    rdx
    74a37e500a19:	mov    QWORD PTR [r12+0x108],rbx
    74a37e500a21:	add    rsp,0xc0
    74a37e500a28:	mov    eax,0xc
    74a37e500a2d:	movabs r11,0x5715466e9ca0
    74a37e500a37:	jmp    r11
    74a37e500a3a:	nop    WORD PTR [rax+rax*1+0x0]
    74a37e500a40:	sub    rsp,0xc0
    74a37e500a47:	mov    r11,QWORD PTR [r12+0x398]
    74a37e500a4f:	mov    QWORD PTR [rsp+0xb0],r11
    74a37e500a57:	jmp    0x74a37e4fe639
    74a37e500a5c:	nop    DWORD PTR [rax+0x0]
    74a37e500a60:	sub    rsp,0xc0
    74a37e500a67:	mov    r11,QWORD PTR [r12+0x398]
    74a37e500a6f:	mov    QWORD PTR [rsp+0xb0],r11
    74a37e500a77:	jmp    0x74a37e4fe75a
    74a37e500a7c:	nop    DWORD PTR [rax+0x0]
    74a37e500a80:	sub    rsp,0xc0
    74a37e500a87:	mov    r11,QWORD PTR [r12+0x398]
    74a37e500a8f:	mov    QWORD PTR [rsp+0xb0],r11
    74a37e500a97:	jmp    0x74a37e4fe814
    74a37e500a9c:	nop    DWORD PTR [rax+0x0]
    74a37e500aa0:	sub    rsp,0xc0
    74a37e500aa7:	mov    r11,QWORD PTR [r12+0x398]
    74a37e500aaf:	mov    QWORD PTR [rsp+0xb0],r11
    74a37e500ab7:	jmp    0x74a37e4ffef9
    74a37e500abc:	nop    DWORD PTR [rax+0x0]
    74a37e500ac0:	sub    rsp,0xc0
    74a37e500ac7:	mov    r11,QWORD PTR [r12+0x398]
    74a37e500acf:	mov    QWORD PTR [rsp+0xb0],r11
    74a37e500ad7:	jmp    0x74a37e50004a
    74a37e500adc:	nop    DWORD PTR [rax+0x0]
    74a37e500ae0:	sub    rsp,0xc0
    74a37e500ae7:	mov    r11,QWORD PTR [r12+0x398]
    74a37e500aef:	mov    QWORD PTR [rsp+0xb0],r11
    74a37e500af7:	jmp    0x74a37e5001cd
    74a37e500afc:	nop    DWORD PTR [rax+0x0]
    74a37e500b00:	sub    rsp,0xc0
    74a37e500b07:	mov    r11,QWORD PTR [r12+0x398]
    74a37e500b0f:	mov    QWORD PTR [rsp+0xb0],r11
    74a37e500b17:	jmp    0x74a37e5004ef
    74a37e500b1c:	nop    DWORD PTR [rax+0x0]
    74a37e500b20:	sub    rsp,0xc0
    74a37e500b27:	mov    r11,QWORD PTR [r12+0x398]
    74a37e500b2f:	mov    QWORD PTR [rsp+0xb0],r11
    74a37e500b37:	jmp    0x74a37e500637
    74a37e500b3c:	nop    DWORD PTR [rax+0x0]
    74a37e500b40:	sub    rsp,0xc0
    74a37e500b47:	mov    r11,QWORD PTR [r12+0x398]
    74a37e500b4f:	mov    QWORD PTR [rsp+0xb0],r11
    74a37e500b57:	jmp    0x74a37e500656
    74a37e500b5c:	nop    DWORD PTR [rax+0x0]
    74a37e500b60:	sub    rsp,0xc0
    74a37e500b67:	mov    r11,QWORD PTR [r12+0x398]
    74a37e500b6f:	mov    QWORD PTR [rsp+0xb0],r11
    74a37e500b77:	jmp    0x74a37e500735
