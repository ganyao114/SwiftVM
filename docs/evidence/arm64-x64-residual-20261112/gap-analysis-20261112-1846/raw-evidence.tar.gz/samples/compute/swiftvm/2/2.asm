
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/2/2.bin:     file format binary


Disassembly of section .data:

00007f716edffb80 <.data>:
    7f716edffb80:	sub    rsp,0x10
    7f716edffb84:	mov    r13d,DWORD PTR [r12+0xa0]
    7f716edffb8c:	sub    r13d,0x1
    7f716edffb90:	mov    QWORD PTR [r12+0xa0],r13
    7f716edffb98:	mov    rcx,QWORD PTR [r12+0x380]
    7f716edffba0:	jrcxz  0x7f716edffba7
    7f716edffba2:	jmp    0x7f716edffd3d
    7f716edffba7:	jne    0x7f716edffbc0
    7f716edffbad:	mov    r11,rax
    7f716edffbb0:	lahf
    7f716edffbb1:	seto   al
    7f716edffbb4:	mov    WORD PTR [rsp],ax
    7f716edffbb8:	mov    rax,r11
    7f716edffbbb:	jmp    0x7f716edffbd3
    7f716edffbc0:	mov    r11,rax
    7f716edffbc3:	lahf
    7f716edffbc4:	seto   al
    7f716edffbc7:	mov    WORD PTR [rsp],ax
    7f716edffbcb:	mov    rax,r11
    7f716edffbce:	jmp    0x7f716edffca5
    7f716edffbd3:	mov    r13,QWORD PTR [r12+0xf8]
    7f716edffbdb:	mov    r14,r13
    7f716edffbde:	add    r14,0x120
    7f716edffbe5:	mov    r15,QWORD PTR [r14]
    7f716edffbe8:	mov    QWORD PTR [r12+0x98],r15
    7f716edffbf0:	mov    r14d,0x80
    7f716edffbf6:	mov    QWORD PTR [r12+0x40],r14
    7f716edffbfb:	mov    r14,r13
    7f716edffbfe:	add    r14,0x100
    7f716edffc05:	mov    QWORD PTR [r12],r14
    7f716edffc09:	mov    r14,r13
    7f716edffc0c:	add    r14,0x17c
    7f716edffc13:	mov    QWORD PTR [r12+0x8],r14
    7f716edffc18:	mov    r14d,0x1
    7f716edffc1e:	mov    QWORD PTR [r12+0x10],r14
    7f716edffc23:	add    r13,0x17c
    7f716edffc2a:	movzx  r14d,BYTE PTR [r12+0x40]
    7f716edffc30:	mov    BYTE PTR [r13+0x0],r14b
    7f716edffc34:	mov    r13d,0x0
    7f716edffc3a:	mov    DWORD PTR [r12+0x32c],r13d
    7f716edffc42:	mov    r13d,0x4102a8
    7f716edffc48:	mov    QWORD PTR [r12+0xf0],r13
    7f716edffc50:	mov    r13d,0x410728
    7f716edffc56:	mov    QWORD PTR [r12+0x100],r13
    7f716edffc5e:	mov    r11,QWORD PTR [rsp]
    7f716edffc62:	mov    QWORD PTR [r12+0x398],r11
    7f716edffc6a:	mov    edi,0x410728
    7f716edffc6f:	mov    QWORD PTR [r12+0x100],rdi
    7f716edffc77:	add    rsp,0x10
    7f716edffc7b:	nop    DWORD PTR [rax+rax*1+0x0]
    7f716edffc80:	jmp    QWORD PTR [rip+0x2]        # 0x7f716edffc88
    7f716edffc86:	xchg   ax,ax
    7f716edffc88:	loopne 0x7f716edffc5f
    7f716edffc8a:	fild   QWORD PTR [rsi+0x71]
    7f716edffc8d:	jg     0x7f716edffc8f
    7f716edffc8f:	add    BYTE PTR [rax+0x716edffc],bl
    7f716edffc95:	jg     0x7f716edffc97
    7f716edffc97:	add    BYTE PTR [rcx-0x45],cl
    7f716edffc9a:	rex jns 0x7f716edffc5c
    7f716edffc9d:	mov    eax,0x5fdf
    7f716edffca2:	jmp    r11
    7f716edffca5:	mov    r13,QWORD PTR [r12+0xf8]
    7f716edffcad:	add    r13,0x100
    7f716edffcb4:	mov    QWORD PTR [r12],r13
    7f716edffcb8:	mov    r13d,0x0
    7f716edffcbe:	mov    r14,QWORD PTR [r12+0x98]
    7f716edffcc6:	or     r13,r14
    7f716edffcc9:	mov    QWORD PTR [r12+0x8],r13
    7f716edffcce:	mov    r13d,0x12c
    7f716edffcd4:	mov    QWORD PTR [r12+0x10],r13
    7f716edffcd9:	mov    r13d,0x410284
    7f716edffcdf:	mov    QWORD PTR [r12+0xf0],r13
    7f716edffce7:	mov    r13d,0x410728
    7f716edffced:	mov    QWORD PTR [r12+0x100],r13
    7f716edffcf5:	mov    r11,QWORD PTR [rsp]
    7f716edffcf9:	mov    QWORD PTR [r12+0x398],r11
    7f716edffd01:	mov    edi,0x410728
    7f716edffd06:	mov    QWORD PTR [r12+0x100],rdi
    7f716edffd0e:	add    rsp,0x10
    7f716edffd12:	nop    WORD PTR [rax+rax*1+0x0]
    7f716edffd18:	jmp    QWORD PTR [rip+0x2]        # 0x7f716edffd20
    7f716edffd1e:	xchg   ax,ax
    7f716edffd20:	loopne 0x7f716edffcf7
    7f716edffd22:	fild   QWORD PTR [rsi+0x71]
    7f716edffd25:	jg     0x7f716edffd27
    7f716edffd27:	add    BYTE PTR [rax],dh
    7f716edffd29:	std
    7f716edffd2a:	fild   QWORD PTR [rsi+0x71]
    7f716edffd2d:	jg     0x7f716edffd2f
    7f716edffd2f:	add    BYTE PTR [rcx-0x45],cl
    7f716edffd32:	rex jns 0x7f716edffcf4
    7f716edffd35:	mov    eax,0x5fdf
    7f716edffd3a:	jmp    r11
    7f716edffd3d:	mov    eax,0x410288
    7f716edffd42:	mov    QWORD PTR [r12+0x100],rax
    7f716edffd4a:	push   rdx
    7f716edffd4b:	push   rsi
    7f716edffd4c:	push   r10
    7f716edffd4e:	push   r11
    7f716edffd50:	mov    r11,rax
    7f716edffd53:	lahf
    7f716edffd54:	seto   al
    7f716edffd57:	mov    WORD PTR [rsp+0x20],ax
    7f716edffd5c:	mov    rax,r11
    7f716edffd5f:	mov    rdx,QWORD PTR [rsp+0x20]
    7f716edffd64:	mov    r10d,edx
    7f716edffd67:	and    r10d,0xc000
    7f716edffd6e:	shl    r10d,0x10
    7f716edffd72:	mov    r11d,edx
    7f716edffd75:	and    r11d,0x100
    7f716edffd7c:	shl    r11d,0x15
    7f716edffd80:	or     r10d,r11d
    7f716edffd83:	and    edx,0x1
    7f716edffd86:	shl    edx,0x1c
    7f716edffd89:	or     r10d,edx
    7f716edffd8c:	btc    r10,0x1d
    7f716edffd91:	mov    r11d,0xf0000000
    7f716edffd97:	and    r11,r10
    7f716edffd9a:	movabs rsi,0xffffffff0fffffff
    7f716edffda4:	and    rbx,rsi
    7f716edffda7:	or     rbx,r11
    7f716edffdaa:	pop    r11
    7f716edffdac:	pop    r10
    7f716edffdae:	pop    rsi
    7f716edffdaf:	pop    rdx
    7f716edffdb0:	mov    QWORD PTR [r12+0x108],rbx
    7f716edffdb8:	add    rsp,0x10
    7f716edffdbc:	mov    eax,0xc
    7f716edffdc1:	movabs r11,0x5fdfb8bf7ca0
    7f716edffdcb:	jmp    r11
    7f716edffdce:	xchg   ax,ax
    7f716edffdd0:	sub    rsp,0x10
    7f716edffdd4:	mov    r11,QWORD PTR [r12+0x398]
    7f716edffddc:	mov    QWORD PTR [rsp],r11
    7f716edffde0:	jmp    0x7f716edffbd3
    7f716edffde5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7f716edffdf0:	sub    rsp,0x10
    7f716edffdf4:	mov    r11,QWORD PTR [r12+0x398]
    7f716edffdfc:	mov    QWORD PTR [rsp],r11
    7f716edffe00:	jmp    0x7f716edffca5
    7f716edffe05:	nop
    7f716edffe06:	nop
    7f716edffe07:	nop
