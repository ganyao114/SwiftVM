
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/0/3.bin:     file format binary


Disassembly of section .data:

000074a37e500e10 <.data>:
    74a37e500e10:	sub    rsp,0x10
    74a37e500e14:	mov    r11,QWORD PTR [r12+0x398]
    74a37e500e1c:	mov    QWORD PTR [rsp],r11
    74a37e500e20:	mov    r13,QWORD PTR [r12+0xf8]
    74a37e500e28:	mov    r14,r13
    74a37e500e2b:	add    r14,0x168
    74a37e500e32:	mov    r15,QWORD PTR [r14]
    74a37e500e35:	mov    QWORD PTR [r12+0x40],r15
    74a37e500e3a:	add    r13,0x178
    74a37e500e41:	mov    r14d,0x0
    74a37e500e47:	mov    BYTE PTR [r13+0x0],r14b
    74a37e500e4b:	mov    r13d,0x0
    74a37e500e51:	mov    DWORD PTR [r12+0x32c],r13d
    74a37e500e59:	sub    r15,0x38
    74a37e500e5d:	je     0x74a37e500e76
    74a37e500e63:	mov    r11,rax
    74a37e500e66:	lahf
    74a37e500e67:	seto   al
    74a37e500e6a:	mov    WORD PTR [rsp],ax
    74a37e500e6e:	mov    rax,r11
    74a37e500e71:	jmp    0x74a37e500e89
    74a37e500e76:	mov    r11,rax
    74a37e500e79:	lahf
    74a37e500e7a:	seto   al
    74a37e500e7d:	mov    WORD PTR [rsp],ax
    74a37e500e81:	mov    rax,r11
    74a37e500e84:	jmp    0x74a37e500f15
    74a37e500e89:	mov    r13,QWORD PTR [r12+0xf8]
    74a37e500e91:	mov    r14,r13
    74a37e500e94:	add    r14,0x100
    74a37e500e9b:	mov    QWORD PTR [r12],r14
    74a37e500e9f:	add    r13,0x178
    74a37e500ea6:	mov    QWORD PTR [r12+0x8],r13
    74a37e500eab:	mov    r13d,0x1
    74a37e500eb1:	mov    QWORD PTR [r12+0x10],r13
    74a37e500eb6:	mov    r13d,0x4102c8
    74a37e500ebc:	mov    QWORD PTR [r12+0xf0],r13
    74a37e500ec4:	mov    r13d,0x410728
    74a37e500eca:	mov    QWORD PTR [r12+0x100],r13
    74a37e500ed2:	mov    r11,QWORD PTR [rsp]
    74a37e500ed6:	mov    QWORD PTR [r12+0x398],r11
    74a37e500ede:	mov    edi,0x410728
    74a37e500ee3:	mov    QWORD PTR [r12+0x100],rdi
    74a37e500eeb:	add    rsp,0x10
    74a37e500eef:	nop
    74a37e500ef0:	jmp    QWORD PTR [rip+0x2]        # 0x74a37e500ef8
    74a37e500ef6:	xchg   ax,ax
    74a37e500ef8:	loopne 0x74a37e500edf
    74a37e500efa:	rex.WRXB jle 0x74a37e500ea0
    74a37e500efd:	je     0x74a37e500eff
    74a37e500eff:	add    BYTE PTR [rax],cl
    74a37e500f01:	movmskps edi,(bad)
    74a37e500f02:	push   rax
    74a37e500f03:	jle    0x74a37e500ea8
    74a37e500f05:	je     0x74a37e500f07
    74a37e500f07:	add    BYTE PTR [rcx-0x45],cl
    74a37e500f0a:	rex cdq
    74a37e500f0c:	outs   dx,BYTE PTR ds:[rsi]
    74a37e500f0d:	rex.RX adc eax,0x41000057
    74a37e500f13:	jmp    rbx
    74a37e500f15:	mov    r13,QWORD PTR [r12+0x98]
    74a37e500f1d:	ror    r13,0x3d
    74a37e500f21:	and    r13,0xfffffffffffffff8
    74a37e500f25:	mov    r14,QWORD PTR [r12+0xf8]
    74a37e500f2d:	mov    r15,r14
    74a37e500f30:	add    r15,0x100
    74a37e500f37:	mov    QWORD PTR [r12],r15
    74a37e500f3b:	mov    r15,r14
    74a37e500f3e:	add    r15,0x170
    74a37e500f45:	mov    QWORD PTR [r12+0x8],r15
    74a37e500f4a:	mov    r15d,0x8
    74a37e500f50:	mov    QWORD PTR [r12+0x10],r15
    74a37e500f55:	movabs rcx,0xff00ff00ff00ff
    74a37e500f5f:	mov    r15,r13
    74a37e500f62:	and    r15,rcx
    74a37e500f65:	shl    r15,0x8
    74a37e500f69:	movabs rcx,0xff00ff00ff00ff00
    74a37e500f73:	and    r13,rcx
    74a37e500f76:	shr    r13,0x8
    74a37e500f7a:	or     r13,r15
    74a37e500f7d:	movabs rcx,0xffff0000ffff
    74a37e500f87:	mov    r15,r13
    74a37e500f8a:	and    r15,rcx
    74a37e500f8d:	shl    r15,0x10
    74a37e500f91:	movabs rcx,0xffff0000ffff0000
    74a37e500f9b:	and    r13,rcx
    74a37e500f9e:	shr    r13,0x10
    74a37e500fa2:	or     r13,r15
    74a37e500fa5:	mov    r15,r13
    74a37e500fa8:	shl    r15,0x20
    74a37e500fac:	shr    r13,0x20
    74a37e500fb0:	or     r13,r15
    74a37e500fb3:	mov    QWORD PTR [r12+0x40],r13
    74a37e500fb8:	add    r14,0x170
    74a37e500fbf:	mov    QWORD PTR [r14],r13
    74a37e500fc2:	mov    r13d,0x0
    74a37e500fc8:	mov    DWORD PTR [r12+0x32c],r13d
    74a37e500fd0:	mov    r13d,0x4102f0
    74a37e500fd6:	mov    QWORD PTR [r12+0xf0],r13
    74a37e500fde:	mov    r13d,0x410728
    74a37e500fe4:	mov    QWORD PTR [r12+0x100],r13
    74a37e500fec:	mov    r11,QWORD PTR [rsp]
    74a37e500ff0:	mov    QWORD PTR [r12+0x398],r11
    74a37e500ff8:	mov    edi,0x410728
    74a37e500ffd:	mov    QWORD PTR [r12+0x100],rdi
    74a37e501005:	add    rsp,0x10
    74a37e501009:	nop    DWORD PTR [rax+0x0]
    74a37e501010:	jmp    QWORD PTR [rip+0x2]        # 0x74a37e501018
    74a37e501016:	xchg   ax,ax
    74a37e501018:	loopne 0x74a37e500fff
    74a37e50101a:	rex.WRXB jle 0x74a37e500fc0
    74a37e50101d:	je     0x74a37e50101f
    74a37e50101f:	add    BYTE PTR [rax],ch
    74a37e501021:	adc    BYTE PTR [rax+0x7e],dl
    74a37e501024:	movabs ds:0x6e9940bb49000074,eax
    74a37e50102d:	rex.RX adc eax,0x41000057
    74a37e501033:	jmp    rbx
    74a37e501035:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e501040:	sub    rsp,0x10
    74a37e501044:	mov    r11,QWORD PTR [r12+0x398]
    74a37e50104c:	mov    QWORD PTR [rsp],r11
    74a37e501050:	jmp    0x74a37e500e89
    74a37e501055:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e501060:	sub    rsp,0x10
    74a37e501064:	mov    r11,QWORD PTR [r12+0x398]
    74a37e50106c:	mov    QWORD PTR [rsp],r11
    74a37e501070:	jmp    0x74a37e500f15
    74a37e501075:	nop
    74a37e501076:	nop
    74a37e501077:	nop
