
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/1/6.bin:     file format binary


Disassembly of section .data:

000075b0bab01740 <.data>:
    75b0bab01740:	sub    rsp,0x10
    75b0bab01744:	mov    r11,QWORD PTR [r12+0x398]
    75b0bab0174c:	mov    QWORD PTR [rsp],r11
    75b0bab01750:	mov    r13d,DWORD PTR [r12]
    75b0bab01754:	mov    r14d,r13d
    75b0bab01757:	mov    r14d,r14d
    75b0bab0175a:	shr    r14d,0x10
    75b0bab0175e:	xor    r13d,r14d
    75b0bab01761:	mov    QWORD PTR [r12+0x40],r13
    75b0bab01766:	mov    r14d,0x352d
    75b0bab0176c:	mov    QWORD PTR [r12+0x48],r14
    75b0bab01771:	mov    r14d,0x352d
    75b0bab01777:	mov    r15d,0x7feb
    75b0bab0177d:	and    r15d,0xffff
    75b0bab01784:	mov    rax,r14
    75b0bab01787:	movabs rcx,0xffffffff0000ffff
    75b0bab01791:	and    rax,rcx
    75b0bab01794:	mov    rdx,r15
    75b0bab01797:	shl    rdx,0x10
    75b0bab0179b:	mov    ecx,0xffff0000
    75b0bab017a0:	and    rdx,rcx
    75b0bab017a3:	or     rax,rdx
    75b0bab017a6:	mov    ebp,eax
    75b0bab017a8:	mov    QWORD PTR [r12+0x48],rbp
    75b0bab017ad:	mov    r14d,0x0
    75b0bab017b3:	imul   r13d,ebp
    75b0bab017b7:	mov    r15d,r14d
    75b0bab017ba:	add    r15d,r13d
    75b0bab017bd:	mov    QWORD PTR [r12+0x40],r15
    75b0bab017c2:	mov    r13d,0xa68b
    75b0bab017c8:	mov    QWORD PTR [r12+0x48],r13
    75b0bab017cd:	mov    r13d,0xa68b
    75b0bab017d3:	mov    r14d,0x846c
    75b0bab017d9:	and    r14d,0xffff
    75b0bab017e0:	mov    rax,r13
    75b0bab017e3:	movabs rcx,0xffffffff0000ffff
    75b0bab017ed:	and    rax,rcx
    75b0bab017f0:	mov    rdx,r14
    75b0bab017f3:	shl    rdx,0x10
    75b0bab017f7:	mov    ecx,0xffff0000
    75b0bab017fc:	and    rdx,rcx
    75b0bab017ff:	or     rax,rdx
    75b0bab01802:	mov    ebp,eax
    75b0bab01804:	mov    QWORD PTR [r12+0x48],rbp
    75b0bab01809:	mov    r13d,r15d
    75b0bab0180c:	mov    r13d,r13d
    75b0bab0180f:	shr    r13d,0xf
    75b0bab01813:	xor    r15d,r13d
    75b0bab01816:	mov    QWORD PTR [r12+0x40],r15
    75b0bab0181b:	mov    r13d,0x0
    75b0bab01821:	imul   r15d,ebp
    75b0bab01825:	mov    r14d,r13d
    75b0bab01828:	add    r14d,r15d
    75b0bab0182b:	mov    QWORD PTR [r12+0x40],r14
    75b0bab01830:	mov    r13d,r14d
    75b0bab01833:	mov    r13d,r13d
    75b0bab01836:	shr    r13d,0x10
    75b0bab0183a:	xor    r14d,r13d
    75b0bab0183d:	mov    QWORD PTR [r12],r14
    75b0bab01841:	mov    rcx,QWORD PTR [r12+0x380]
    75b0bab01849:	jrcxz  0x75b0bab01850
    75b0bab0184b:	jmp    0x75b0bab01885
    75b0bab01850:	mov    r13,QWORD PTR [r12+0xf0]
    75b0bab01858:	mov    QWORD PTR [r12+0x100],r13
    75b0bab01860:	mov    r11,QWORD PTR [rsp]
    75b0bab01864:	mov    QWORD PTR [r12+0x398],r11
    75b0bab0186c:	mov    rdi,QWORD PTR [r12+0x100]
    75b0bab01874:	add    rsp,0x10
    75b0bab01878:	movabs r11,0x59d8f50c0940
    75b0bab01882:	jmp    r11
    75b0bab01885:	mov    eax,0x4109c8
    75b0bab0188a:	mov    QWORD PTR [r12+0x100],rax
    75b0bab01892:	push   rdx
    75b0bab01893:	push   rsi
    75b0bab01894:	push   r10
    75b0bab01896:	push   r11
    75b0bab01898:	mov    rdx,QWORD PTR [rsp+0x20]
    75b0bab0189d:	mov    r10d,edx
    75b0bab018a0:	and    r10d,0xc000
    75b0bab018a7:	shl    r10d,0x10
    75b0bab018ab:	mov    r11d,edx
    75b0bab018ae:	and    r11d,0x100
    75b0bab018b5:	shl    r11d,0x15
    75b0bab018b9:	or     r10d,r11d
    75b0bab018bc:	and    edx,0x1
    75b0bab018bf:	shl    edx,0x1c
    75b0bab018c2:	or     r10d,edx
    75b0bab018c5:	btc    r10,0x1d
    75b0bab018ca:	mov    r11d,0xf0000000
    75b0bab018d0:	and    r11,r10
    75b0bab018d3:	movabs rsi,0xffffffff0fffffff
    75b0bab018dd:	and    rbx,rsi
    75b0bab018e0:	or     rbx,r11
    75b0bab018e3:	pop    r11
    75b0bab018e5:	pop    r10
    75b0bab018e7:	pop    rsi
    75b0bab018e8:	pop    rdx
    75b0bab018e9:	mov    QWORD PTR [r12+0x108],rbx
    75b0bab018f1:	add    rsp,0x10
    75b0bab018f5:	mov    eax,0xc
    75b0bab018fa:	movabs r11,0x59d8f50c0ca0
    75b0bab01904:	jmp    r11
    75b0bab01907:	nop
