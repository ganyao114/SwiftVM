
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/2/0.bin:     file format binary


Disassembly of section .data:

00007f716edfd000 <.data>:
    7f716edfd000:	sub    rsp,0x10
    7f716edfd004:	mov    r11,QWORD PTR [r12+0x398]
    7f716edfd00c:	mov    QWORD PTR [rsp],r11
    7f716edfd010:	mov    r13,QWORD PTR [r12+0xf8]
    7f716edfd018:	sub    r13,0x1e0
    7f716edfd01f:	mov    QWORD PTR [r12+0xf8],r13
    7f716edfd027:	mov    r14d,0x420000
    7f716edfd02d:	mov    QWORD PTR [r12+0x40],r14
    7f716edfd032:	mov    r14d,0x420000
    7f716edfd038:	mov    QWORD PTR [r12+0x48],r14
    7f716edfd03d:	mov    r14,r13
    7f716edfd040:	add    r14,0x1d0
    7f716edfd047:	mov    r15,r14
    7f716edfd04a:	add    r15,0x8
    7f716edfd04e:	mov    rbp,QWORD PTR [r12+0xa0]
    7f716edfd056:	mov    r8,QWORD PTR [r12+0x98]
    7f716edfd05e:	mov    QWORD PTR [r14],rbp
    7f716edfd061:	mov    r14d,0x0
    7f716edfd067:	mov    DWORD PTR [r12+0x32c],r14d
    7f716edfd06f:	mov    QWORD PTR [r15],r8
    7f716edfd072:	mov    r14d,0x420aa0
    7f716edfd078:	movdqu xmm2,XMMWORD PTR [r14]
    7f716edfd07d:	movdqu XMMWORD PTR [r12+0x110],xmm2
    7f716edfd087:	mov    r14d,0x420a30
    7f716edfd08d:	movdqu xmm3,XMMWORD PTR [r14]
    7f716edfd092:	movdqu XMMWORD PTR [r12+0x120],xmm3
    7f716edfd09c:	mov    r14d,0x420ac0
    7f716edfd0a2:	movdqu xmm4,XMMWORD PTR [r14]
    7f716edfd0a7:	movdqu XMMWORD PTR [r12+0x130],xmm4
    7f716edfd0b1:	mov    r14d,0x420a60
    7f716edfd0b7:	movdqu xmm5,XMMWORD PTR [r14]
    7f716edfd0bc:	movdqu XMMWORD PTR [r12+0x140],xmm5
    7f716edfd0c6:	mov    r14d,0x430000
    7f716edfd0cc:	mov    rax,r14
    7f716edfd0cf:	add    rax,0xcd0
    7f716edfd0d5:	mov    QWORD PTR [r12+0x98],rax
    7f716edfd0dd:	mov    r15d,0x420ad0
    7f716edfd0e3:	movdqu xmm6,XMMWORD PTR [r15]
    7f716edfd0e8:	movdqu XMMWORD PTR [r12+0x150],xmm6
    7f716edfd0f2:	mov    r15,QWORD PTR [r12+0x98]
    7f716edfd0fa:	add    r15,0x10
    7f716edfd0fe:	mov    rdi,QWORD PTR [r12+0x98]
    7f716edfd106:	movdqu XMMWORD PTR [rdi],xmm2
    7f716edfd10a:	movdqu XMMWORD PTR [r15],xmm3
    7f716edfd10f:	mov    r15,QWORD PTR [r12+0x98]
    7f716edfd117:	add    r15,0x20
    7f716edfd11b:	mov    rbp,r15
    7f716edfd11e:	add    rbp,0x10
    7f716edfd122:	movdqu XMMWORD PTR [r15],xmm4
    7f716edfd127:	movdqu XMMWORD PTR [rbp+0x0],xmm5
    7f716edfd12c:	mov    r15d,0x420a20
    7f716edfd132:	movdqu xmm4,XMMWORD PTR [r15]
    7f716edfd137:	movdqu XMMWORD PTR [r12+0x130],xmm4
    7f716edfd141:	mov    r15d,0x420a10
    7f716edfd147:	movdqu xmm5,XMMWORD PTR [r15]
    7f716edfd14c:	movdqu XMMWORD PTR [r12+0x140],xmm5
    7f716edfd156:	mov    r15,QWORD PTR [r12+0x98]
    7f716edfd15e:	add    r15,0x100
    7f716edfd165:	mov    rbp,r15
    7f716edfd168:	add    rbp,0x10
    7f716edfd16c:	movdqu XMMWORD PTR [r15],xmm2
    7f716edfd171:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    7f716edfd176:	mov    r15,QWORD PTR [r12+0x98]
    7f716edfd17e:	add    r15,0x40
    7f716edfd182:	mov    rbp,r15
    7f716edfd185:	add    rbp,0x10
    7f716edfd189:	movdqu XMMWORD PTR [r15],xmm6
    7f716edfd18e:	movdqu XMMWORD PTR [rbp+0x0],xmm4
    7f716edfd193:	mov    r15d,0x420a00
    7f716edfd199:	movdqu xmm2,XMMWORD PTR [r15]
    7f716edfd19e:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7f716edfd1a8:	mov    r15d,0x420a70
    7f716edfd1ae:	movdqu xmm3,XMMWORD PTR [r15]
    7f716edfd1b3:	movdqu XMMWORD PTR [r12+0x150],xmm3
    7f716edfd1bd:	mov    r15d,0xf8d3
    7f716edfd1c3:	mov    QWORD PTR [r12+0x48],r15
    7f716edfd1c8:	mov    r15,QWORD PTR [r12+0x98]
    7f716edfd1d0:	add    r15,0x60
    7f716edfd1d4:	mov    rbp,r15
    7f716edfd1d7:	add    rbp,0x10
    7f716edfd1db:	movdqu XMMWORD PTR [r15],xmm5
    7f716edfd1e0:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7f716edfd1e5:	mov    r15d,0x420a80
    7f716edfd1eb:	movdqu xmm2,XMMWORD PTR [r15]
    7f716edfd1f0:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7f716edfd1fa:	mov    r15d,0x420a50
    7f716edfd200:	movdqu xmm4,XMMWORD PTR [r15]
    7f716edfd205:	movdqu XMMWORD PTR [r12+0x140],xmm4
    7f716edfd20f:	mov    r15d,0xf8d3
    7f716edfd215:	mov    ebp,0x421d
    7f716edfd21a:	and    ebp,0xffff
    7f716edfd220:	mov    rax,r15
    7f716edfd223:	movabs rcx,0xffffffff0000ffff
    7f716edfd22d:	and    rax,rcx
    7f716edfd230:	mov    rdx,rbp
    7f716edfd233:	shl    rdx,0x10
    7f716edfd237:	mov    ecx,0xffff0000
    7f716edfd23c:	and    rdx,rcx
    7f716edfd23f:	or     rax,rdx
    7f716edfd242:	mov    r8d,eax
    7f716edfd245:	mov    QWORD PTR [r12+0x48],r8
    7f716edfd24a:	mov    r15,QWORD PTR [r12+0x98]
    7f716edfd252:	add    r15,0x80
    7f716edfd259:	mov    rbp,r15
    7f716edfd25c:	add    rbp,0x10
    7f716edfd260:	movdqu XMMWORD PTR [r15],xmm3
    7f716edfd265:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7f716edfd26a:	mov    r15d,0x420af0
    7f716edfd270:	movdqu xmm2,XMMWORD PTR [r15]
    7f716edfd275:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7f716edfd27f:	mov    r15d,0x420b00
    7f716edfd285:	movdqu xmm3,XMMWORD PTR [r15]
    7f716edfd28a:	movdqu XMMWORD PTR [r12+0x150],xmm3
    7f716edfd294:	mov    r15d,0x3e8
    7f716edfd29a:	mov    QWORD PTR [r12+0xa0],r15
    7f716edfd2a2:	mov    r15,QWORD PTR [r12+0x98]
    7f716edfd2aa:	add    r15,0xa0
    7f716edfd2b1:	mov    rbp,r15
    7f716edfd2b4:	add    rbp,0x10
    7f716edfd2b8:	movdqu XMMWORD PTR [r15],xmm4
    7f716edfd2bd:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7f716edfd2c2:	mov    r15d,0x420ae0
    7f716edfd2c8:	movdqu xmm2,XMMWORD PTR [r15]
    7f716edfd2cd:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7f716edfd2d7:	mov    r15d,0x420a90
    7f716edfd2dd:	movdqu xmm4,XMMWORD PTR [r15]
    7f716edfd2e2:	movdqu XMMWORD PTR [r12+0x140],xmm4
    7f716edfd2ec:	mov    r15,r13
    7f716edfd2ef:	add    r15,0x180
    7f716edfd2f6:	mov    rbp,r15
    7f716edfd2f9:	add    rbp,0x8
    7f716edfd2fd:	mov    r9,QWORD PTR [r12+0x200]
    7f716edfd305:	mov    r14,QWORD PTR [r12+0x1f0]
    7f716edfd30d:	mov    QWORD PTR [r15],r9
    7f716edfd310:	mov    QWORD PTR [rbp+0x0],r14
    7f716edfd314:	mov    r14,QWORD PTR [r12+0x98]
    7f716edfd31c:	add    r14,0xc0
    7f716edfd323:	mov    r15,r14
    7f716edfd326:	add    r15,0x10
    7f716edfd32a:	movdqu XMMWORD PTR [r14],xmm3
    7f716edfd32f:	movdqu XMMWORD PTR [r15],xmm2
    7f716edfd334:	mov    r14d,0x420ab0
    7f716edfd33a:	movdqu xmm2,XMMWORD PTR [r14]
    7f716edfd33f:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7f716edfd349:	mov    r14d,0x420b18
    7f716edfd34f:	mov    r15,QWORD PTR [r14]
    7f716edfd352:	mov    r14d,0x0
    7f716edfd358:	mov    QWORD PTR [r12+0x110],r15
    7f716edfd360:	mov    QWORD PTR [r12+0x118],r14
    7f716edfd368:	mov    r14d,0x420b20
    7f716edfd36e:	mov    QWORD PTR [r12+0x40],r14
    7f716edfd373:	mov    r14,QWORD PTR [r12+0x98]
    7f716edfd37b:	add    r14,0xe0
    7f716edfd382:	mov    rbp,r14
    7f716edfd385:	add    rbp,0x10
    7f716edfd389:	movdqu XMMWORD PTR [r14],xmm4
    7f716edfd38e:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    7f716edfd393:	mov    r14d,0x420b80
    7f716edfd399:	movdqu xmm2,XMMWORD PTR [r14]
    7f716edfd39e:	movdqu XMMWORD PTR [r12+0x130],xmm2
    7f716edfd3a8:	mov    r14,QWORD PTR [r12+0x98]
    7f716edfd3b0:	add    r14,0x120
    7f716edfd3b7:	mov    QWORD PTR [r14],r15
    7f716edfd3ba:	mov    r14d,0x420b60
    7f716edfd3c0:	mov    r15d,0x420b70
    7f716edfd3c6:	movdqu xmm3,XMMWORD PTR [r14]
    7f716edfd3cb:	movdqu xmm4,XMMWORD PTR [r15]
    7f716edfd3d0:	movdqu XMMWORD PTR [r12+0x120],xmm3
    7f716edfd3da:	movdqu XMMWORD PTR [r12+0x110],xmm4
    7f716edfd3e4:	mov    r14,r13
    7f716edfd3e7:	add    r14,0x160
    7f716edfd3ee:	movdqu XMMWORD PTR [r14],xmm2
    7f716edfd3f3:	mov    r14,r13
    7f716edfd3f6:	add    r14,0x190
    7f716edfd3fd:	mov    r15,r14
    7f716edfd400:	add    r15,0x8
    7f716edfd404:	mov    rbp,QWORD PTR [r12+0x1e0]
    7f716edfd40c:	mov    r9,QWORD PTR [r12+0x1d0]
    7f716edfd414:	mov    QWORD PTR [r14],rbp
    7f716edfd417:	mov    QWORD PTR [r15],r9
    7f716edfd41a:	mov    r14,r13
    7f716edfd41d:	add    r14,0x140
    7f716edfd424:	mov    r15,r14
    7f716edfd427:	add    r15,0x10
    7f716edfd42b:	movdqu XMMWORD PTR [r14],xmm3
    7f716edfd430:	movdqu XMMWORD PTR [r15],xmm4
    7f716edfd435:	mov    r14d,0x420b20
    7f716edfd43b:	mov    r15d,0x420b30
    7f716edfd441:	movdqu xmm2,XMMWORD PTR [r14]
    7f716edfd446:	movdqu xmm3,XMMWORD PTR [r15]
    7f716edfd44b:	movdqu XMMWORD PTR [r12+0x110],xmm2
    7f716edfd455:	movdqu XMMWORD PTR [r12+0x120],xmm3
    7f716edfd45f:	mov    r14,r13
    7f716edfd462:	add    r14,0x1a0
    7f716edfd469:	mov    r15,r14
    7f716edfd46c:	add    r15,0x8
    7f716edfd470:	mov    rbp,QWORD PTR [r12+0x1c0]
    7f716edfd478:	mov    r9,QWORD PTR [r12+0x1b0]
    7f716edfd480:	mov    QWORD PTR [r14],rbp
    7f716edfd483:	mov    QWORD PTR [r15],r9
    7f716edfd486:	mov    r14,r13
    7f716edfd489:	add    r14,0x1b0
    7f716edfd490:	mov    r15,r14
    7f716edfd493:	add    r15,0x8
    7f716edfd497:	mov    rbp,QWORD PTR [r12+0x1a0]
    7f716edfd49f:	mov    r9,QWORD PTR [r12+0x190]
    7f716edfd4a7:	mov    QWORD PTR [r14],rbp
    7f716edfd4aa:	mov    QWORD PTR [r15],r9
    7f716edfd4ad:	mov    r14,r13
    7f716edfd4b0:	add    r14,0x100
    7f716edfd4b7:	mov    r15,r14
    7f716edfd4ba:	add    r15,0x10
    7f716edfd4be:	movdqu XMMWORD PTR [r14],xmm2
    7f716edfd4c3:	movdqu XMMWORD PTR [r15],xmm3
    7f716edfd4c8:	mov    r14d,0x420b40
    7f716edfd4ce:	mov    r15d,0x420b50
    7f716edfd4d4:	movdqu xmm2,XMMWORD PTR [r14]
    7f716edfd4d9:	movdqu xmm3,XMMWORD PTR [r15]
    7f716edfd4de:	movdqu XMMWORD PTR [r12+0x110],xmm2
    7f716edfd4e8:	movdqu XMMWORD PTR [r12+0x130],xmm3
    7f716edfd4f2:	mov    r14,r13
    7f716edfd4f5:	add    r14,0x1c0
    7f716edfd4fc:	mov    r15,r14
    7f716edfd4ff:	add    r15,0x8
    7f716edfd503:	mov    rbp,QWORD PTR [r12+0xe8]
    7f716edfd50b:	mov    r9,QWORD PTR [r12+0xf0]
    7f716edfd513:	mov    QWORD PTR [r14],rbp
    7f716edfd516:	mov    QWORD PTR [r15],r9
    7f716edfd519:	mov    r14,QWORD PTR [r12+0x98]
    7f716edfd521:	add    r14,0x128
    7f716edfd528:	mov    DWORD PTR [r14],r8d
    7f716edfd52b:	mov    r14,r13
    7f716edfd52e:	add    r14,0x120
    7f716edfd535:	mov    r15,r14
    7f716edfd538:	add    r15,0x10
    7f716edfd53c:	movdqu XMMWORD PTR [r14],xmm2
    7f716edfd541:	movdqu XMMWORD PTR [r15],xmm3
    7f716edfd546:	add    r13,0x100
    7f716edfd54d:	mov    QWORD PTR [r12],r13
    7f716edfd551:	mov    r13d,0x0
    7f716edfd557:	mov    rcx,QWORD PTR [r12+0x98]
    7f716edfd55f:	or     r13,rcx
    7f716edfd562:	mov    QWORD PTR [r12+0x8],r13
    7f716edfd567:	mov    r13d,0x12c
    7f716edfd56d:	mov    QWORD PTR [r12+0x10],r13
    7f716edfd572:	mov    r13d,0x410284
    7f716edfd578:	mov    QWORD PTR [r12+0xf0],r13
    7f716edfd580:	mov    r13d,0x410728
    7f716edfd586:	mov    QWORD PTR [r12+0x100],r13
    7f716edfd58e:	mov    r11,QWORD PTR [rsp]
    7f716edfd592:	mov    QWORD PTR [r12+0x398],r11
    7f716edfd59a:	mov    edi,0x410728
    7f716edfd59f:	mov    QWORD PTR [r12+0x100],rdi
    7f716edfd5a7:	add    rsp,0x10
    7f716edfd5ab:	nop    DWORD PTR [rax+rax*1+0x0]
    7f716edfd5b0:	jmp    QWORD PTR [rip+0x2]        # 0x7f716edfd5b8
    7f716edfd5b6:	xchg   ax,ax
    7f716edfd5b8:	loopne 0x7f716edfd58f
    7f716edfd5ba:	fild   QWORD PTR [rsi+0x71]
    7f716edfd5bd:	jg     0x7f716edfd5bf
    7f716edfd5bf:	add    al,cl
    7f716edfd5c1:	{rex2 0xdf} movq mm6,QWORD PTR [r25+0x7f]
    7f716edfd5c6:	add    BYTE PTR [rax],al
    7f716edfd5c8:	movabs r11,0x5fdfb8bf7940
    7f716edfd5d2:	jmp    r11
    7f716edfd5d5:	nop
    7f716edfd5d6:	nop
    7f716edfd5d7:	nop
