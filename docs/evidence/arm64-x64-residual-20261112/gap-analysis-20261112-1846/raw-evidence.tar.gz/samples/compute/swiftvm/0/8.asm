
/home/proton/.cache/SwiftVM/arm64-x64-gap-analysis-20261112-1846/samples/compute/swiftvm/0/8.bin:     file format binary


Disassembly of section .data:

000074a37e502170 <.data>:
    74a37e502170:	sub    rsp,0x150
    74a37e502177:	mov    r11,QWORD PTR [r12+0x398]
    74a37e50217f:	mov    QWORD PTR [rsp],r11
    74a37e502183:	cmp    DWORD PTR [r12+0x310],0x0
    74a37e50218c:	je     0x74a37e502217
    74a37e502192:	push   rdx
    74a37e502193:	push   rsi
    74a37e502194:	push   r10
    74a37e502196:	push   r11
    74a37e502198:	mov    rdx,QWORD PTR [rsp+0x20]
    74a37e50219d:	mov    r10d,edx
    74a37e5021a0:	and    r10d,0xc000
    74a37e5021a7:	shl    r10d,0x10
    74a37e5021ab:	mov    r11d,edx
    74a37e5021ae:	and    r11d,0x100
    74a37e5021b5:	shl    r11d,0x15
    74a37e5021b9:	or     r10d,r11d
    74a37e5021bc:	and    edx,0x1
    74a37e5021bf:	shl    edx,0x1c
    74a37e5021c2:	or     r10d,edx
    74a37e5021c5:	btc    r10,0x1d
    74a37e5021ca:	mov    r11d,0xf0000000
    74a37e5021d0:	and    r11,r10
    74a37e5021d3:	movabs rsi,0xffffffff0fffffff
    74a37e5021dd:	and    rbx,rsi
    74a37e5021e0:	or     rbx,r11
    74a37e5021e3:	pop    r11
    74a37e5021e5:	pop    r10
    74a37e5021e7:	pop    rsi
    74a37e5021e8:	pop    rdx
    74a37e5021e9:	mov    QWORD PTR [r12+0x108],rbx
    74a37e5021f1:	mov    eax,0x4103f8
    74a37e5021f6:	mov    QWORD PTR [r12+0x100],rax
    74a37e5021fe:	add    rsp,0x150
    74a37e502205:	mov    eax,0x3
    74a37e50220a:	movabs r11,0x5715466e9ca0
    74a37e502214:	jmp    r11
    74a37e502217:	mov    r13d,DWORD PTR [r12+0x98]
    74a37e50221f:	add    r13d,0x1
    74a37e502223:	mov    QWORD PTR [r12+0x98],r13
    74a37e50222b:	sub    r13d,0x10000
    74a37e502232:	mov    rcx,QWORD PTR [r12+0x380]
    74a37e50223a:	jrcxz  0x74a37e502241
    74a37e50223c:	jmp    0x74a37e50bbf5
    74a37e502241:	jne    0x74a37e50225a
    74a37e502247:	mov    r11,rax
    74a37e50224a:	lahf
    74a37e50224b:	seto   al
    74a37e50224e:	mov    WORD PTR [rsp],ax
    74a37e502252:	mov    rax,r11
    74a37e502255:	jmp    0x74a37e50226d
    74a37e50225a:	mov    r11,rax
    74a37e50225d:	lahf
    74a37e50225e:	seto   al
    74a37e502261:	mov    WORD PTR [rsp],ax
    74a37e502265:	mov    rax,r11
    74a37e502268:	jmp    0x74a37e504d43
    74a37e50226d:	mov    r13d,0x420000
    74a37e502273:	mov    QWORD PTR [r12+0x40],r13
    74a37e502278:	movabs r13,0x100000001
    74a37e502282:	mov    r14d,0x0
    74a37e502288:	mov    QWORD PTR [r12+0x110],r13
    74a37e502290:	mov    QWORD PTR [r12+0x118],r14
    74a37e502298:	movabs r13,0x3fa0000000000000
    74a37e5022a2:	mov    QWORD PTR [r12+0x50],r13
    74a37e5022a7:	mov    r13d,0x420b10
    74a37e5022ad:	mov    r14,QWORD PTR [r13+0x0]
    74a37e5022b1:	mov    r13d,0x0
    74a37e5022b7:	mov    QWORD PTR [r12+0x120],r14
    74a37e5022bf:	mov    QWORD PTR [r12+0x128],r13
    74a37e5022c7:	movabs r13,0x4100000041
    74a37e5022d1:	mov    r14d,0x0
    74a37e5022d7:	mov    QWORD PTR [r12+0x140],r13
    74a37e5022df:	mov    QWORD PTR [r12+0x148],r14
    74a37e5022e7:	movabs r13,0x3fc0000000000000
    74a37e5022f1:	movabs r14,0x3fc0000000000000
    74a37e5022fb:	mov    QWORD PTR [r12+0x150],r13
    74a37e502303:	mov    QWORD PTR [r12+0x158],r14
    74a37e50230b:	movabs r13,0x200000002
    74a37e502315:	mov    r14d,0x0
    74a37e50231b:	mov    QWORD PTR [r12+0x160],r13
    74a37e502323:	mov    QWORD PTR [r12+0x168],r14
    74a37e50232b:	movabs r13,0x3fa0000000000000
    74a37e502335:	mov    QWORD PTR [r12+0x130],r13
    74a37e50233d:	mov    QWORD PTR [r12+0x138],r13
    74a37e502345:	mov    r13d,0x2
    74a37e50234b:	mov    QWORD PTR [r12+0x170],r13
    74a37e502353:	mov    QWORD PTR [r12+0x178],r13
    74a37e50235b:	mov    r13d,0x420000
    74a37e502361:	mov    QWORD PTR [r12+0x40],r13
    74a37e502366:	mov    r13d,0x430000
    74a37e50236c:	mov    QWORD PTR [r12+0x50],r13
    74a37e502371:	mov    r13d,0x420a40
    74a37e502377:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    74a37e50237d:	movdqu XMMWORD PTR [r12+0x180],xmm2
    74a37e502387:	mov    r13d,0x0
    74a37e50238d:	mov    QWORD PTR [r12+0x48],r13
    74a37e502392:	mov    r13d,0x431000
    74a37e502398:	add    r13,0xe00
    74a37e50239f:	mov    QWORD PTR [r12+0x40],r13
    74a37e5023a4:	mov    r13d,0x430cb8
    74a37e5023aa:	mov    r14d,DWORD PTR [r12]
    74a37e5023ae:	mov    DWORD PTR [r13+0x0],r14d
    74a37e5023b2:	mov    r13d,0x0
    74a37e5023b8:	mov    DWORD PTR [r12+0x32c],r13d
    74a37e5023c0:	mov    r13d,0x432000
    74a37e5023c6:	mov    QWORD PTR [r12+0x50],r13
    74a37e5023cb:	mov    r11,rax
    74a37e5023ce:	movzx  eax,WORD PTR [rsp]
    74a37e5023d2:	add    al,0x7f
    74a37e5023d4:	sahf
    74a37e5023d5:	mov    rax,r11
    74a37e5023d8:	jmp    0x74a37e5023dd
    74a37e5023dd:	mov    r13,QWORD PTR [r12+0x180]
    74a37e5023e5:	mov    r14,QWORD PTR [r12+0x188]
    74a37e5023ed:	mov    r15d,0x0
    74a37e5023f3:	mov    r11,rax
    74a37e5023f6:	lahf
    74a37e5023f7:	seto   al
    74a37e5023fa:	mov    WORD PTR [rsp],ax
    74a37e5023fe:	mov    rax,r11
    74a37e502401:	mov    ecx,0xffffffff
    74a37e502406:	and    r13,rcx
    74a37e502409:	mov    rbp,r15
    74a37e50240c:	or     rbp,r13
    74a37e50240f:	mov    ecx,0xffffffff
    74a37e502414:	and    r14,rcx
    74a37e502417:	shl    r14,0x20
    74a37e50241b:	or     rbp,r14
    74a37e50241e:	mov    QWORD PTR [r12+0x210],rbp
    74a37e502426:	mov    QWORD PTR [r12+0x218],r15
    74a37e50242e:	movdqu xmm2,XMMWORD PTR [r12+0x140]
    74a37e502438:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    74a37e502442:	movdqa xmm1,xmm3
    74a37e502446:	psubd  xmm2,xmm1
    74a37e50244a:	movdqa xmm14,xmm2
    74a37e50244f:	movdqa xmm1,xmm14
    74a37e502454:	movq   rax,xmm1
    74a37e502459:	mov    r13,rax
    74a37e50245c:	movdqu xmm2,XMMWORD PTR [r12+0x180]
    74a37e502466:	movdqu xmm4,XMMWORD PTR [r12+0x170]
    74a37e502470:	movdqa xmm1,xmm4
    74a37e502474:	paddq  xmm2,xmm1
    74a37e502478:	movdqu XMMWORD PTR [r12+0x180],xmm2
    74a37e502482:	movdqu xmm2,XMMWORD PTR [r12+0x160]
    74a37e50248c:	movdqa xmm1,xmm2
    74a37e502490:	paddd  xmm3,xmm1
    74a37e502494:	movdqa xmm14,xmm3
    74a37e502499:	movdqa xmm1,xmm14
    74a37e50249e:	movq   rax,xmm1
    74a37e5024a3:	mov    r14,rax
    74a37e5024a6:	mov    r15d,0x0
    74a37e5024ac:	mov    QWORD PTR [r12+0x120],r14
    74a37e5024b4:	mov    QWORD PTR [r12+0x128],r15
    74a37e5024bc:	mov    r14d,0x0
    74a37e5024c2:	mov    ecx,0xffffffff
    74a37e5024c7:	mov    r15,r13
    74a37e5024ca:	and    r15,rcx
    74a37e5024cd:	mov    rbp,r14
    74a37e5024d0:	or     rbp,r15
    74a37e5024d3:	shr    r13,0x20
    74a37e5024d7:	mov    ecx,0xffffffff
    74a37e5024dc:	and    r13,rcx
    74a37e5024df:	or     r14,r13
    74a37e5024e2:	mov    QWORD PTR [r12+0x220],rbp
    74a37e5024ea:	mov    QWORD PTR [r12+0x228],r14
    74a37e5024f2:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    74a37e5024fc:	movdqu xmm3,XMMWORD PTR [r12+0x110]
    74a37e502506:	movdqa xmm1,xmm3
    74a37e50250a:	paddd  xmm2,xmm1
    74a37e50250e:	movdqa xmm14,xmm2
    74a37e502513:	movdqa xmm1,xmm14
    74a37e502518:	movq   rax,xmm1
    74a37e50251d:	mov    r13,rax
    74a37e502520:	mov    r14d,0x0
    74a37e502526:	mov    QWORD PTR [r12+0x210],r13
    74a37e50252e:	mov    QWORD PTR [r12+0x218],r14
    74a37e502536:	lea    r13,[r12]
    74a37e50253a:	movabs r14,0xb6e61da31
    74a37e502544:	mov    r15d,0x410468
    74a37e50254a:	mov    rdx,QWORD PTR [rsp]
    74a37e50254e:	mov    r10d,edx
    74a37e502551:	and    r10d,0xc000
    74a37e502558:	shl    r10d,0x10
    74a37e50255c:	mov    r11d,edx
    74a37e50255f:	and    r11d,0x100
    74a37e502566:	shl    r11d,0x15
    74a37e50256a:	or     r10d,r11d
    74a37e50256d:	and    edx,0x1
    74a37e502570:	shl    edx,0x1c
    74a37e502573:	or     r10d,edx
    74a37e502576:	btc    r10,0x1d
    74a37e50257b:	mov    r11d,0xf0000000
    74a37e502581:	and    r11,r10
    74a37e502584:	movabs rsi,0xffffffff0fffffff
    74a37e50258e:	and    rbx,rsi
    74a37e502591:	or     rbx,r11
    74a37e502594:	mov    QWORD PTR [r12+0x378],0x3
    74a37e5025a0:	mov    QWORD PTR [r12+0x108],rbx
    74a37e5025a8:	stmxcsr DWORD PTR [r12-0x28]
    74a37e5025ae:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e5025b3:	test   r10d,0x3f
    74a37e5025ba:	je     0x74a37e5025df
    74a37e5025c0:	mov    r11d,r10d
    74a37e5025c3:	shr    r10d,1
    74a37e5025c6:	and    r10d,0x1e
    74a37e5025ca:	and    r11d,0x1
    74a37e5025ce:	or     r10d,r11d
    74a37e5025d1:	or     DWORD PTR [r12+0x314],r10d
    74a37e5025d9:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e5025df:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e5025e5:	movabs r11,0x57154654b5e0
    74a37e5025ef:	mov    rdi,r13
    74a37e5025f2:	mov    rsi,r14
    74a37e5025f5:	mov    rdx,r15
    74a37e5025f8:	call   r11
    74a37e5025fb:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e502601:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e502609:	mov    QWORD PTR [r12+0x378],0x2
    74a37e502615:	mov    rbp,rax
    74a37e502618:	mov    r13,QWORD PTR [r12+0x210]
    74a37e502620:	mov    r14d,0x0
    74a37e502626:	mov    ecx,0xffffffff
    74a37e50262b:	mov    r15,r13
    74a37e50262e:	and    r15,rcx
    74a37e502631:	mov    rbp,r14
    74a37e502634:	or     rbp,r15
    74a37e502637:	shr    r13,0x20
    74a37e50263b:	mov    ecx,0xffffffff
    74a37e502640:	and    r13,rcx
    74a37e502643:	or     r14,r13
    74a37e502646:	mov    QWORD PTR [r12+0x210],rbp
    74a37e50264e:	mov    QWORD PTR [r12+0x218],r14
    74a37e502656:	lea    r13,[r12]
    74a37e50265a:	movabs r14,0xb6e61da10
    74a37e502664:	mov    r15d,0x410470
    74a37e50266a:	mov    QWORD PTR [r12+0x378],0x3
    74a37e502676:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50267e:	stmxcsr DWORD PTR [r12-0x28]
    74a37e502684:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e502689:	test   r10d,0x3f
    74a37e502690:	je     0x74a37e5026b5
    74a37e502696:	mov    r11d,r10d
    74a37e502699:	shr    r10d,1
    74a37e50269c:	and    r10d,0x1e
    74a37e5026a0:	and    r11d,0x1
    74a37e5026a4:	or     r10d,r11d
    74a37e5026a7:	or     DWORD PTR [r12+0x314],r10d
    74a37e5026af:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e5026b5:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e5026bb:	movabs r11,0x57154654b5e0
    74a37e5026c5:	mov    rdi,r13
    74a37e5026c8:	mov    rsi,r14
    74a37e5026cb:	mov    rdx,r15
    74a37e5026ce:	call   r11
    74a37e5026d1:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e5026d7:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e5026df:	mov    QWORD PTR [r12+0x378],0x2
    74a37e5026eb:	mov    rbp,rax
    74a37e5026ee:	movdqu xmm2,XMMWORD PTR [r12+0x220]
    74a37e5026f8:	movdqu xmm3,XMMWORD PTR [r12+0x150]
    74a37e502702:	movdqa xmm0,xmm2
    74a37e502706:	movdqa xmm1,xmm3
    74a37e50270a:	mulpd  xmm0,xmm1
    74a37e50270e:	movdqa xmm14,xmm0
    74a37e502713:	movdqu xmm15,XMMWORD PTR [rip+0x9f34]        # 0x74a37e50c650
    74a37e50271c:	pand   xmm14,xmm15
    74a37e502721:	movdqu xmm15,XMMWORD PTR [rip+0x9f36]        # 0x74a37e50c660
    74a37e50272a:	pcmpeqq xmm14,xmm15
    74a37e502730:	movdqa xmm15,xmm0
    74a37e502735:	cmpunordpd xmm15,xmm0
    74a37e50273b:	por    xmm14,xmm15
    74a37e502740:	pmovmskb ecx,xmm14
    74a37e502745:	jrcxz  0x74a37e50274c
    74a37e502747:	jmp    0x74a37e504dbd
    74a37e50274c:	movdqa xmm4,xmm0
    74a37e502750:	movdqu XMMWORD PTR [r12+0x220],xmm4
    74a37e50275a:	mov    r13,QWORD PTR [r12+0x48]
    74a37e50275f:	mov    r14,QWORD PTR [r12+0x50]
    74a37e502764:	add    r14,r13
    74a37e502767:	movdqu XMMWORD PTR [r14],xmm4
    74a37e50276c:	mov    r14d,0x0
    74a37e502772:	mov    DWORD PTR [r12+0x32c],r14d
    74a37e50277a:	movdqu xmm2,XMMWORD PTR [r12+0x210]
    74a37e502784:	movdqu xmm3,XMMWORD PTR [r12+0x130]
    74a37e50278e:	movdqa xmm0,xmm2
    74a37e502792:	movdqa xmm1,xmm3
    74a37e502796:	mulpd  xmm0,xmm1
    74a37e50279a:	movdqa xmm14,xmm0
    74a37e50279f:	movdqu xmm15,XMMWORD PTR [rip+0x9ea8]        # 0x74a37e50c650
    74a37e5027a8:	pand   xmm14,xmm15
    74a37e5027ad:	movdqu xmm15,XMMWORD PTR [rip+0x9eaa]        # 0x74a37e50c660
    74a37e5027b6:	pcmpeqq xmm14,xmm15
    74a37e5027bc:	movdqa xmm15,xmm0
    74a37e5027c1:	cmpunordpd xmm15,xmm0
    74a37e5027c7:	por    xmm14,xmm15
    74a37e5027cc:	pmovmskb ecx,xmm14
    74a37e5027d1:	jrcxz  0x74a37e5027d8
    74a37e5027d3:	jmp    0x74a37e504de1
    74a37e5027d8:	movdqa xmm4,xmm0
    74a37e5027dc:	movdqu XMMWORD PTR [r12+0x210],xmm4
    74a37e5027e6:	mov    r14,QWORD PTR [r12+0x40]
    74a37e5027eb:	add    r14,r13
    74a37e5027ee:	movdqu XMMWORD PTR [r14],xmm4
    74a37e5027f3:	add    r13,0x10
    74a37e5027f7:	mov    QWORD PTR [r12+0x48],r13
    74a37e5027fc:	sub    r13,0x200
    74a37e502803:	mov    rcx,QWORD PTR [r12+0x380]
    74a37e50280b:	jrcxz  0x74a37e502812
    74a37e50280d:	jmp    0x74a37e50bc89
    74a37e502812:	jne    0x74a37e5023dd
    74a37e502818:	mov    r11,rax
    74a37e50281b:	lahf
    74a37e50281c:	seto   al
    74a37e50281f:	mov    WORD PTR [rsp],ax
    74a37e502823:	mov    rax,r11
    74a37e502826:	jmp    0x74a37e50282b
    74a37e50282b:	mov    r13,QWORD PTR [r12+0x50]
    74a37e502830:	mov    r14,r13
    74a37e502833:	add    r14,0x80
    74a37e50283a:	mov    r15,r14
    74a37e50283d:	add    r15,0x10
    74a37e502841:	movdqu xmm2,XMMWORD PTR [r14]
    74a37e502846:	movdqu xmm3,XMMWORD PTR [r15]
    74a37e50284b:	movdqu XMMWORD PTR [r12+0x130],xmm2
    74a37e502855:	movdqu XMMWORD PTR [r12+0x110],xmm3
    74a37e50285f:	mov    r14d,0x0
    74a37e502865:	mov    r15d,0x0
    74a37e50286b:	mov    QWORD PTR [r12+0x1b0],r14
    74a37e502873:	mov    QWORD PTR [r12+0x1b8],r15
    74a37e50287b:	mov    r14,r13
    74a37e50287e:	add    r14,0x40
    74a37e502882:	mov    r15,r14
    74a37e502885:	add    r15,0x10
    74a37e502889:	movdqu xmm4,XMMWORD PTR [r14]
    74a37e50288e:	movdqu xmm5,XMMWORD PTR [r15]
    74a37e502893:	movdqu XMMWORD PTR [r12+0x250],xmm4
    74a37e50289d:	movdqu XMMWORD PTR [r12+0x120],xmm5
    74a37e5028a7:	mov    r14d,0x0
    74a37e5028ad:	mov    QWORD PTR [r12+0x48],r14
    74a37e5028b2:	mov    r14,r13
    74a37e5028b5:	add    r14,0x10
    74a37e5028b9:	movdqu xmm4,XMMWORD PTR [r13+0x0]
    74a37e5028bf:	movdqu xmm6,XMMWORD PTR [r14]
    74a37e5028c4:	movdqu XMMWORD PTR [r12+0x170],xmm4
    74a37e5028ce:	movdqu XMMWORD PTR [r12+0x180],xmm6
    74a37e5028d8:	mov    r14,QWORD PTR [r12+0xf8]
    74a37e5028e0:	mov    r15,r14
    74a37e5028e3:	add    r15,0xe0
    74a37e5028ea:	mov    rbp,r15
    74a37e5028ed:	add    rbp,0x10
    74a37e5028f1:	movdqu XMMWORD PTR [r15],xmm3
    74a37e5028f6:	mov    r15d,0x0
    74a37e5028fc:	mov    DWORD PTR [r12+0x32c],r15d
    74a37e502904:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    74a37e502909:	mov    r15,r13
    74a37e50290c:	add    r15,0xc0
    74a37e502913:	mov    rbp,r15
    74a37e502916:	add    rbp,0x10
    74a37e50291a:	movdqu xmm2,XMMWORD PTR [r15]
    74a37e50291f:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    74a37e502924:	movdqu XMMWORD PTR [r12+0x130],xmm2
    74a37e50292e:	movdqu XMMWORD PTR [r12+0x110],xmm3
    74a37e502938:	mov    r15,r13
    74a37e50293b:	add    r15,0x140
    74a37e502942:	mov    rbp,r15
    74a37e502945:	add    rbp,0x10
    74a37e502949:	movdqu xmm7,XMMWORD PTR [r15]
    74a37e50294e:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    74a37e502954:	movdqu XMMWORD PTR [r12+0x270],xmm7
    74a37e50295e:	movdqu XMMWORD PTR [r12+0x190],xmm8
    74a37e502968:	mov    r15,r13
    74a37e50296b:	add    r15,0x180
    74a37e502972:	mov    rbp,r15
    74a37e502975:	add    rbp,0x10
    74a37e502979:	movdqu xmm7,XMMWORD PTR [r15]
    74a37e50297e:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    74a37e502984:	movdqu XMMWORD PTR [r12+0x2a0],xmm7
    74a37e50298e:	movdqu XMMWORD PTR [r12+0x1a0],xmm8
    74a37e502998:	mov    r15,r14
    74a37e50299b:	add    r15,0xc0
    74a37e5029a2:	mov    rbp,r15
    74a37e5029a5:	add    rbp,0x10
    74a37e5029a9:	movdqu XMMWORD PTR [r15],xmm3
    74a37e5029ae:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    74a37e5029b3:	mov    r15,r13
    74a37e5029b6:	add    r15,0x100
    74a37e5029bd:	mov    rbp,r15
    74a37e5029c0:	add    rbp,0x10
    74a37e5029c4:	movdqu xmm2,XMMWORD PTR [r15]
    74a37e5029c9:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    74a37e5029ce:	movdqu XMMWORD PTR [r12+0x110],xmm2
    74a37e5029d8:	movdqu XMMWORD PTR [r12+0x300],xmm3
    74a37e5029e2:	mov    r15,r13
    74a37e5029e5:	add    r15,0x1c0
    74a37e5029ec:	mov    rbp,r15
    74a37e5029ef:	add    rbp,0x10
    74a37e5029f3:	movdqu xmm3,XMMWORD PTR [r15]
    74a37e5029f8:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    74a37e5029fd:	movdqu XMMWORD PTR [r12+0x240],xmm3
    74a37e502a07:	movdqu XMMWORD PTR [r12+0x1c0],xmm7
    74a37e502a11:	mov    r15,r13
    74a37e502a14:	add    r15,0x20
    74a37e502a18:	mov    rbp,r15
    74a37e502a1b:	add    rbp,0x10
    74a37e502a1f:	movdqu xmm7,XMMWORD PTR [r15]
    74a37e502a24:	movdqu xmm8,XMMWORD PTR [rbp+0x0]
    74a37e502a2a:	movdqu XMMWORD PTR [r12+0x1d0],xmm7
    74a37e502a34:	movdqu XMMWORD PTR [r12+0x1f0],xmm8
    74a37e502a3e:	mov    r15,r14
    74a37e502a41:	add    r15,0x20
    74a37e502a45:	mov    rbp,r15
    74a37e502a48:	add    rbp,0x10
    74a37e502a4c:	movdqu XMMWORD PTR [r15],xmm2
    74a37e502a51:	movdqu XMMWORD PTR [rbp+0x0],xmm5
    74a37e502a56:	mov    r15,r13
    74a37e502a59:	add    r15,0x60
    74a37e502a5d:	mov    rbp,r15
    74a37e502a60:	add    rbp,0x10
    74a37e502a64:	movdqu xmm2,XMMWORD PTR [r15]
    74a37e502a69:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    74a37e502a6e:	movdqu XMMWORD PTR [r12+0x110],xmm2
    74a37e502a78:	movdqu XMMWORD PTR [r12+0x120],xmm5
    74a37e502a82:	mov    r15,r14
    74a37e502a85:	add    r15,0x60
    74a37e502a89:	mov    rbp,r15
    74a37e502a8c:	add    rbp,0x10
    74a37e502a90:	movdqu XMMWORD PTR [r15],xmm4
    74a37e502a95:	movdqu XMMWORD PTR [rbp+0x0],xmm3
    74a37e502a9a:	mov    r15,r13
    74a37e502a9d:	add    r15,0xe0
    74a37e502aa4:	mov    rbp,r15
    74a37e502aa7:	add    rbp,0x10
    74a37e502aab:	movdqu xmm3,XMMWORD PTR [r15]
    74a37e502ab0:	movdqu xmm4,XMMWORD PTR [rbp+0x0]
    74a37e502ab5:	movdqu XMMWORD PTR [r12+0x200],xmm3
    74a37e502abf:	movdqu XMMWORD PTR [r12+0x2d0],xmm4
    74a37e502ac9:	mov    r15,r13
    74a37e502acc:	add    r15,0x120
    74a37e502ad3:	mov    rbp,r15
    74a37e502ad6:	add    rbp,0x10
    74a37e502ada:	movdqu xmm3,XMMWORD PTR [r15]
    74a37e502adf:	movdqu xmm4,XMMWORD PTR [rbp+0x0]
    74a37e502ae4:	movdqu XMMWORD PTR [r12+0x2e0],xmm3
    74a37e502aee:	movdqu XMMWORD PTR [r12+0x2f0],xmm4
    74a37e502af8:	mov    r15,r14
    74a37e502afb:	add    r15,0xa0
    74a37e502b02:	mov    rbp,r15
    74a37e502b05:	add    rbp,0x10
    74a37e502b09:	movdqu XMMWORD PTR [r15],xmm5
    74a37e502b0e:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    74a37e502b13:	mov    r15,r13
    74a37e502b16:	add    r15,0xa0
    74a37e502b1d:	mov    rbp,r15
    74a37e502b20:	add    rbp,0x10
    74a37e502b24:	movdqu xmm2,XMMWORD PTR [r15]
    74a37e502b29:	movdqu xmm3,XMMWORD PTR [rbp+0x0]
    74a37e502b2e:	movdqu XMMWORD PTR [r12+0x110],xmm2
    74a37e502b38:	movdqu XMMWORD PTR [r12+0x120],xmm3
    74a37e502b42:	mov    r15,r13
    74a37e502b45:	add    r15,0x160
    74a37e502b4c:	mov    rbp,r15
    74a37e502b4f:	add    rbp,0x10
    74a37e502b53:	movdqu xmm4,XMMWORD PTR [r15]
    74a37e502b58:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    74a37e502b5d:	movdqu XMMWORD PTR [r12+0x2c0],xmm4
    74a37e502b67:	movdqu XMMWORD PTR [r12+0x2b0],xmm5
    74a37e502b71:	mov    r15,r13
    74a37e502b74:	add    r15,0x1a0
    74a37e502b7b:	mov    rbp,r15
    74a37e502b7e:	add    rbp,0x10
    74a37e502b82:	movdqu xmm5,XMMWORD PTR [r15]
    74a37e502b87:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    74a37e502b8c:	movdqu XMMWORD PTR [r12+0x290],xmm5
    74a37e502b96:	movdqu XMMWORD PTR [r12+0x1e0],xmm7
    74a37e502ba0:	mov    r15,r14
    74a37e502ba3:	add    r15,0x80
    74a37e502baa:	mov    rbp,r15
    74a37e502bad:	add    rbp,0x10
    74a37e502bb1:	movdqu XMMWORD PTR [r15],xmm3
    74a37e502bb6:	movdqu XMMWORD PTR [rbp+0x0],xmm2
    74a37e502bbb:	add    r13,0x1e0
    74a37e502bc2:	mov    r15,r13
    74a37e502bc5:	add    r15,0x10
    74a37e502bc9:	movdqu xmm2,XMMWORD PTR [r13+0x0]
    74a37e502bcf:	movdqu xmm3,XMMWORD PTR [r15]
    74a37e502bd4:	movdqu XMMWORD PTR [r12+0x230],xmm2
    74a37e502bde:	movdqu XMMWORD PTR [r12+0x280],xmm3
    74a37e502be8:	mov    r13d,0x432000
    74a37e502bee:	add    r13,0x200
    74a37e502bf5:	mov    QWORD PTR [r12+0x50],r13
    74a37e502bfa:	mov    r13,r14
    74a37e502bfd:	add    r13,0x40
    74a37e502c01:	mov    r15,r13
    74a37e502c04:	add    r15,0x10
    74a37e502c08:	movdqu XMMWORD PTR [r13+0x0],xmm4
    74a37e502c0e:	movdqu XMMWORD PTR [r15],xmm6
    74a37e502c13:	mov    r13,r14
    74a37e502c16:	add    r13,0x10
    74a37e502c1a:	movdqu XMMWORD PTR [r14],xmm3
    74a37e502c1f:	movdqu XMMWORD PTR [r13+0x0],xmm2
    74a37e502c25:	mov    r11,rax
    74a37e502c28:	movzx  eax,WORD PTR [rsp]
    74a37e502c2c:	add    al,0x7f
    74a37e502c2e:	sahf
    74a37e502c2f:	mov    rax,r11
    74a37e502c32:	jmp    0x74a37e502c37
    74a37e502c37:	mov    r13d,0x0
    74a37e502c3d:	mov    QWORD PTR [r12+0x58],r13
    74a37e502c42:	mov    r11,rax
    74a37e502c45:	lahf
    74a37e502c46:	seto   al
    74a37e502c49:	mov    WORD PTR [rsp],ax
    74a37e502c4d:	mov    rax,r11
    74a37e502c50:	jmp    0x74a37e502c55
    74a37e502c55:	mov    r13,QWORD PTR [r12+0x58]
    74a37e502c5a:	mov    r14,QWORD PTR [r12+0x40]
    74a37e502c5f:	add    r14,r13
    74a37e502c62:	mov    QWORD PTR [r12+0x60],r14
    74a37e502c67:	movdqu xmm2,XMMWORD PTR [r12+0x1d0]
    74a37e502c71:	movdqa xmm0,xmm2
    74a37e502c75:	movdqa xmm1,xmm2
    74a37e502c79:	por    xmm0,xmm1
    74a37e502c7d:	movdqu XMMWORD PTR [r12+0x2c0],xmm0
    74a37e502c87:	movdqu xmm4,XMMWORD PTR [r12+0x1a0]
    74a37e502c91:	movdqa xmm0,xmm4
    74a37e502c95:	movdqa xmm1,xmm4
    74a37e502c99:	por    xmm0,xmm1
    74a37e502c9d:	movdqu XMMWORD PTR [r12+0x120],xmm0
    74a37e502ca7:	mov    r15,r14
    74a37e502caa:	add    r15,0x30
    74a37e502cae:	mov    rbp,r15
    74a37e502cb1:	add    rbp,0x8
    74a37e502cb5:	mov    r8,QWORD PTR [r15]
    74a37e502cb8:	mov    r15,QWORD PTR [rbp+0x0]
    74a37e502cbc:	mov    ebp,0x0
    74a37e502cc1:	mov    QWORD PTR [r12+0x130],r8
    74a37e502cc9:	mov    QWORD PTR [r12+0x138],rbp
    74a37e502cd1:	mov    ebp,0x0
    74a37e502cd6:	mov    QWORD PTR [r12+0x280],r15
    74a37e502cde:	mov    QWORD PTR [r12+0x288],rbp
    74a37e502ce6:	movdqu xmm5,XMMWORD PTR [r12+0x270]
    74a37e502cf0:	movdqa xmm0,xmm5
    74a37e502cf4:	movdqa xmm1,xmm5
    74a37e502cf8:	por    xmm0,xmm1
    74a37e502cfc:	movdqu XMMWORD PTR [r12+0x1a0],xmm0
    74a37e502d06:	mov    r15,r14
    74a37e502d09:	add    r15,0x20
    74a37e502d0d:	mov    rbp,r15
    74a37e502d10:	add    rbp,0x8
    74a37e502d14:	mov    r8,QWORD PTR [r15]
    74a37e502d17:	mov    r15,QWORD PTR [rbp+0x0]
    74a37e502d1b:	mov    ebp,0x0
    74a37e502d20:	mov    QWORD PTR [r12+0x150],r8
    74a37e502d28:	mov    QWORD PTR [r12+0x158],rbp
    74a37e502d30:	mov    ebp,0x0
    74a37e502d35:	mov    QWORD PTR [r12+0x140],r15
    74a37e502d3d:	mov    QWORD PTR [r12+0x148],rbp
    74a37e502d45:	mov    r15,r14
    74a37e502d48:	add    r15,0x10
    74a37e502d4c:	mov    rbp,r15
    74a37e502d4f:	add    rbp,0x8
    74a37e502d53:	mov    r8,QWORD PTR [r15]
    74a37e502d56:	mov    r15,QWORD PTR [rbp+0x0]
    74a37e502d5a:	mov    ebp,0x0
    74a37e502d5f:	mov    QWORD PTR [r12+0x170],r8
    74a37e502d67:	mov    QWORD PTR [r12+0x178],rbp
    74a37e502d6f:	mov    ebp,0x0
    74a37e502d74:	mov    QWORD PTR [r12+0x160],r15
    74a37e502d7c:	mov    QWORD PTR [r12+0x168],rbp
    74a37e502d84:	mov    r15d,0x8
    74a37e502d8a:	mov    rbp,QWORD PTR [r14]
    74a37e502d8d:	mov    QWORD PTR [r12+0x180],rbp
    74a37e502d95:	mov    QWORD PTR [r12+0x188],rbp
    74a37e502d9d:	add    r14,r15
    74a37e502da0:	mov    QWORD PTR [r12+0x60],r14
    74a37e502da5:	mov    r15,QWORD PTR [r14]
    74a37e502da8:	mov    r14d,0x0
    74a37e502dae:	mov    QWORD PTR [r12+0x230],r15
    74a37e502db6:	mov    QWORD PTR [r12+0x238],r14
    74a37e502dbe:	mov    r14,QWORD PTR [r12+0xf8]
    74a37e502dc6:	mov    r15,r14
    74a37e502dc9:	add    r15,0x50
    74a37e502dcd:	mov    rbp,r15
    74a37e502dd0:	add    rbp,0x10
    74a37e502dd4:	movdqu xmm6,XMMWORD PTR [r15]
    74a37e502dd9:	movdqu xmm7,XMMWORD PTR [rbp+0x0]
    74a37e502dde:	movdqu XMMWORD PTR [r12+0x220],xmm6
    74a37e502de8:	movdqu XMMWORD PTR [r12+0x210],xmm7
    74a37e502df2:	mov    r15,r14
    74a37e502df5:	add    r15,0x30
    74a37e502df9:	movdqu xmm8,XMMWORD PTR [r15]
    74a37e502dfe:	movdqu XMMWORD PTR [r12+0x110],xmm8
    74a37e502e08:	mov    r15,QWORD PTR [r12+0x50]
    74a37e502e0d:	add    r15,r13
    74a37e502e10:	mov    QWORD PTR [r12+0x60],r15
    74a37e502e15:	add    r13,0x40
    74a37e502e19:	mov    QWORD PTR [r12+0x58],r13
    74a37e502e1e:	movdqu xmm9,XMMWORD PTR [r12+0x180]
    74a37e502e28:	movdqa xmm0,xmm9
    74a37e502e2d:	movdqa xmm1,xmm2
    74a37e502e31:	mulpd  xmm0,xmm1
    74a37e502e35:	movdqa xmm14,xmm0
    74a37e502e3a:	movdqu xmm15,XMMWORD PTR [rip+0x980d]        # 0x74a37e50c650
    74a37e502e43:	pand   xmm14,xmm15
    74a37e502e48:	movdqu xmm15,XMMWORD PTR [rip+0x980f]        # 0x74a37e50c660
    74a37e502e51:	pcmpeqq xmm14,xmm15
    74a37e502e57:	movdqa xmm15,xmm0
    74a37e502e5c:	cmpunordpd xmm15,xmm0
    74a37e502e62:	por    xmm14,xmm15
    74a37e502e67:	pmovmskb ecx,xmm14
    74a37e502e6c:	jrcxz  0x74a37e502e73
    74a37e502e6e:	jmp    0x74a37e504e05
    74a37e502e73:	movdqa xmm10,xmm0
    74a37e502e78:	movdqu xmm2,XMMWORD PTR [r12+0x230]
    74a37e502e82:	movdqa xmm0,xmm8
    74a37e502e87:	movdqa xmm1,xmm2
    74a37e502e8b:	pshufd xmm1,xmm1,0x44
    74a37e502e90:	mulpd  xmm0,xmm1
    74a37e502e94:	movdqa xmm14,xmm0
    74a37e502e99:	movdqu xmm15,XMMWORD PTR [rip+0x97ae]        # 0x74a37e50c650
    74a37e502ea2:	pand   xmm14,xmm15
    74a37e502ea7:	movdqu xmm15,XMMWORD PTR [rip+0x97b0]        # 0x74a37e50c660
    74a37e502eb0:	pcmpeqq xmm14,xmm15
    74a37e502eb6:	movdqa xmm15,xmm0
    74a37e502ebb:	cmpunordpd xmm15,xmm0
    74a37e502ec1:	por    xmm14,xmm15
    74a37e502ec6:	pmovmskb ecx,xmm14
    74a37e502ecb:	jrcxz  0x74a37e502ed2
    74a37e502ecd:	jmp    0x74a37e504e2a
    74a37e502ed2:	movdqa xmm11,xmm0
    74a37e502ed7:	movdqu XMMWORD PTR [r12+0x260],xmm11
    74a37e502ee1:	mov    ebp,0x0
    74a37e502ee6:	mov    r8d,0x0
    74a37e502eec:	mov    QWORD PTR [r12+0x110],rbp
    74a37e502ef4:	mov    QWORD PTR [r12+0x118],r8
    74a37e502efc:	movdqa xmm0,xmm9
    74a37e502f01:	movdqa xmm1,xmm7
    74a37e502f05:	mulpd  xmm0,xmm1
    74a37e502f09:	movdqa xmm14,xmm0
    74a37e502f0e:	movdqu xmm15,XMMWORD PTR [rip+0x9739]        # 0x74a37e50c650
    74a37e502f17:	pand   xmm14,xmm15
    74a37e502f1c:	movdqu xmm15,XMMWORD PTR [rip+0x973b]        # 0x74a37e50c660
    74a37e502f25:	pcmpeqq xmm14,xmm15
    74a37e502f2b:	movdqa xmm15,xmm0
    74a37e502f30:	cmpunordpd xmm15,xmm0
    74a37e502f36:	por    xmm14,xmm15
    74a37e502f3b:	pmovmskb ecx,xmm14
    74a37e502f40:	jrcxz  0x74a37e502f47
    74a37e502f42:	jmp    0x74a37e504e4f
    74a37e502f47:	movdqa xmm8,xmm0
    74a37e502f4c:	movdqa xmm0,xmm9
    74a37e502f51:	movdqa xmm1,xmm6
    74a37e502f55:	mulpd  xmm0,xmm1
    74a37e502f59:	movdqa xmm14,xmm0
    74a37e502f5e:	movdqu xmm15,XMMWORD PTR [rip+0x96e9]        # 0x74a37e50c650
    74a37e502f67:	pand   xmm14,xmm15
    74a37e502f6c:	movdqu xmm15,XMMWORD PTR [rip+0x96eb]        # 0x74a37e50c660
    74a37e502f75:	pcmpeqq xmm14,xmm15
    74a37e502f7b:	movdqa xmm15,xmm0
    74a37e502f80:	cmpunordpd xmm15,xmm0
    74a37e502f86:	por    xmm14,xmm15
    74a37e502f8b:	pmovmskb ecx,xmm14
    74a37e502f90:	jrcxz  0x74a37e502f97
    74a37e502f92:	jmp    0x74a37e504e74
    74a37e502f97:	movdqa xmm7,xmm0
    74a37e502f9b:	movdqu xmm6,XMMWORD PTR [r12+0x1f0]
    74a37e502fa5:	movdqa xmm0,xmm9
    74a37e502faa:	movdqa xmm1,xmm6
    74a37e502fae:	mulpd  xmm0,xmm1
    74a37e502fb2:	movdqa xmm14,xmm0
    74a37e502fb7:	movdqu xmm15,XMMWORD PTR [rip+0x9690]        # 0x74a37e50c650
    74a37e502fc0:	pand   xmm14,xmm15
    74a37e502fc5:	movdqu xmm15,XMMWORD PTR [rip+0x9692]        # 0x74a37e50c660
    74a37e502fce:	pcmpeqq xmm14,xmm15
    74a37e502fd4:	movdqa xmm15,xmm0
    74a37e502fd9:	cmpunordpd xmm15,xmm0
    74a37e502fdf:	por    xmm14,xmm15
    74a37e502fe4:	pmovmskb ecx,xmm14
    74a37e502fe9:	jrcxz  0x74a37e502ff0
    74a37e502feb:	jmp    0x74a37e504e99
    74a37e502ff0:	movdqa xmm12,xmm0
    74a37e502ff5:	movdqu XMMWORD PTR [r12+0x180],xmm12
    74a37e502fff:	movdqu xmm6,XMMWORD PTR [r12+0x2a0]
    74a37e503009:	movdqa xmm0,xmm6
    74a37e50300d:	movdqa xmm1,xmm6
    74a37e503011:	por    xmm0,xmm1
    74a37e503015:	movdqu XMMWORD PTR [r12+0x1d0],xmm0
    74a37e50301f:	movdqu xmm9,XMMWORD PTR [r12+0x250]
    74a37e503029:	movdqa xmm0,xmm9
    74a37e50302e:	movdqa xmm1,xmm9
    74a37e503033:	por    xmm0,xmm1
    74a37e503037:	movdqu XMMWORD PTR [r12+0x2a0],xmm0
    74a37e503041:	movdqa xmm0,xmm9
    74a37e503046:	movdqa xmm1,xmm2
    74a37e50304a:	pshufd xmm1,xmm1,0x44
    74a37e50304f:	mulpd  xmm0,xmm1
    74a37e503053:	movdqa xmm14,xmm0
    74a37e503058:	movdqu xmm15,XMMWORD PTR [rip+0x95ef]        # 0x74a37e50c650
    74a37e503061:	pand   xmm14,xmm15
    74a37e503066:	movdqu xmm15,XMMWORD PTR [rip+0x95f1]        # 0x74a37e50c660
    74a37e50306f:	pcmpeqq xmm14,xmm15
    74a37e503075:	movdqa xmm15,xmm0
    74a37e50307a:	cmpunordpd xmm15,xmm0
    74a37e503080:	por    xmm14,xmm15
    74a37e503085:	pmovmskb ecx,xmm14
    74a37e50308a:	jrcxz  0x74a37e503091
    74a37e50308c:	jmp    0x74a37e504ebe
    74a37e503091:	movdqa xmm4,xmm0
    74a37e503095:	movdqu XMMWORD PTR [r12+0x250],xmm4
    74a37e50309f:	sub    r13,0x200
    74a37e5030a6:	movdqu xmm9,XMMWORD PTR [r12+0x110]
    74a37e5030b0:	movdqa xmm0,xmm10
    74a37e5030b5:	movdqa xmm1,xmm9
    74a37e5030ba:	addpd  xmm0,xmm1
    74a37e5030be:	movdqa xmm14,xmm0
    74a37e5030c3:	movdqu xmm15,XMMWORD PTR [rip+0x9584]        # 0x74a37e50c650
    74a37e5030cc:	pand   xmm14,xmm15
    74a37e5030d1:	movdqu xmm15,XMMWORD PTR [rip+0x9586]        # 0x74a37e50c660
    74a37e5030da:	pcmpeqq xmm14,xmm15
    74a37e5030e0:	movdqa xmm15,xmm0
    74a37e5030e5:	cmpunordpd xmm15,xmm0
    74a37e5030eb:	por    xmm14,xmm15
    74a37e5030f0:	pmovmskb ecx,xmm14
    74a37e5030f5:	jrcxz  0x74a37e5030fc
    74a37e5030f7:	jmp    0x74a37e504ee3
    74a37e5030fc:	movdqu XMMWORD PTR [r12+0x240],xmm0
    74a37e503106:	movdqu xmm10,XMMWORD PTR [r12+0x1b0]
    74a37e503110:	movdqa xmm0,xmm8
    74a37e503115:	movdqa xmm1,xmm10
    74a37e50311a:	addpd  xmm0,xmm1
    74a37e50311e:	movdqa xmm14,xmm0
    74a37e503123:	movdqu xmm15,XMMWORD PTR [rip+0x9524]        # 0x74a37e50c650
    74a37e50312c:	pand   xmm14,xmm15
    74a37e503131:	movdqu xmm15,XMMWORD PTR [rip+0x9526]        # 0x74a37e50c660
    74a37e50313a:	pcmpeqq xmm14,xmm15
    74a37e503140:	movdqa xmm15,xmm0
    74a37e503145:	cmpunordpd xmm15,xmm0
    74a37e50314b:	por    xmm14,xmm15
    74a37e503150:	pmovmskb ecx,xmm14
    74a37e503155:	jrcxz  0x74a37e50315c
    74a37e503157:	jmp    0x74a37e504f24
    74a37e50315c:	movdqa xmm6,xmm0
    74a37e503160:	movdqu XMMWORD PTR [r12+0x210],xmm6
    74a37e50316a:	movdqa xmm0,xmm7
    74a37e50316e:	movdqa xmm1,xmm10
    74a37e503173:	addpd  xmm0,xmm1
    74a37e503177:	movdqa xmm14,xmm0
    74a37e50317c:	movdqu xmm15,XMMWORD PTR [rip+0x94cb]        # 0x74a37e50c650
    74a37e503185:	pand   xmm14,xmm15
    74a37e50318a:	movdqu xmm15,XMMWORD PTR [rip+0x94cd]        # 0x74a37e50c660
    74a37e503193:	pcmpeqq xmm14,xmm15
    74a37e503199:	movdqa xmm15,xmm0
    74a37e50319e:	cmpunordpd xmm15,xmm0
    74a37e5031a4:	por    xmm14,xmm15
    74a37e5031a9:	pmovmskb ecx,xmm14
    74a37e5031ae:	jrcxz  0x74a37e5031b5
    74a37e5031b0:	jmp    0x74a37e504f65
    74a37e5031b5:	movdqa xmm8,xmm0
    74a37e5031ba:	movdqu XMMWORD PTR [r12+0x220],xmm8
    74a37e5031c4:	movdqu xmm7,XMMWORD PTR [r12+0x2f0]
    74a37e5031ce:	setne  BYTE PTR [rsp+0x8]
    74a37e5031d3:	mov    r11,rax
    74a37e5031d6:	lahf
    74a37e5031d7:	seto   al
    74a37e5031da:	mov    WORD PTR [rsp],ax
    74a37e5031de:	mov    rax,r11
    74a37e5031e1:	movdqa xmm0,xmm7
    74a37e5031e5:	movdqa xmm1,xmm7
    74a37e5031e9:	por    xmm0,xmm1
    74a37e5031ed:	movdqu XMMWORD PTR [r12+0x1b0],xmm0
    74a37e5031f7:	movdqu xmm10,XMMWORD PTR [r12+0x2e0]
    74a37e503201:	movdqa xmm0,xmm10
    74a37e503206:	movdqa xmm1,xmm10
    74a37e50320b:	por    xmm0,xmm1
    74a37e50320f:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    74a37e503219:	movdqu xmm13,XMMWORD PTR [r12+0x2d0]
    74a37e503223:	movdqa xmm0,xmm13
    74a37e503228:	movdqa xmm1,xmm13
    74a37e50322d:	por    xmm0,xmm1
    74a37e503231:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    74a37e50323b:	movdqu xmm5,XMMWORD PTR [r12+0x200]
    74a37e503245:	movdqa xmm0,xmm5
    74a37e503249:	movdqa xmm1,xmm5
    74a37e50324d:	por    xmm0,xmm1
    74a37e503251:	movdqu XMMWORD PTR [r12+0x2d0],xmm0
    74a37e50325b:	movdqu xmm7,XMMWORD PTR [r12+0x1c0]
    74a37e503265:	movdqa xmm1,xmm7
    74a37e503269:	por    xmm7,xmm1
    74a37e50326d:	movdqu XMMWORD PTR [r12+0x200],xmm7
    74a37e503277:	movdqu xmm3,XMMWORD PTR [r12+0x190]
    74a37e503281:	movdqa xmm1,xmm3
    74a37e503285:	por    xmm3,xmm1
    74a37e503289:	movdqu XMMWORD PTR [r12+0x1c0],xmm3
    74a37e503293:	movdqu xmm10,XMMWORD PTR [r12+0x300]
    74a37e50329d:	movdqa xmm1,xmm10
    74a37e5032a2:	por    xmm10,xmm1
    74a37e5032a7:	movdqu XMMWORD PTR [r12+0x190],xmm10
    74a37e5032b1:	mov    r13,r14
    74a37e5032b4:	add    r13,0xa0
    74a37e5032bb:	mov    rbp,r13
    74a37e5032be:	add    rbp,0x10
    74a37e5032c2:	movdqu xmm13,XMMWORD PTR [r13+0x0]
    74a37e5032c8:	movdqu xmm5,XMMWORD PTR [rbp+0x0]
    74a37e5032cd:	movdqu XMMWORD PTR [r12+0x300],xmm13
    74a37e5032d7:	movdqu XMMWORD PTR [r12+0x270],xmm5
    74a37e5032e1:	movdqa xmm0,xmm12
    74a37e5032e6:	movdqa xmm1,xmm9
    74a37e5032eb:	addpd  xmm0,xmm1
    74a37e5032ef:	movdqa xmm14,xmm0
    74a37e5032f4:	movdqu xmm15,XMMWORD PTR [rip+0x9353]        # 0x74a37e50c650
    74a37e5032fd:	pand   xmm14,xmm15
    74a37e503302:	movdqu xmm15,XMMWORD PTR [rip+0x9355]        # 0x74a37e50c660
    74a37e50330b:	pcmpeqq xmm14,xmm15
    74a37e503311:	movdqa xmm15,xmm0
    74a37e503316:	cmpunordpd xmm15,xmm0
    74a37e50331c:	por    xmm14,xmm15
    74a37e503321:	pmovmskb ecx,xmm14
    74a37e503326:	jrcxz  0x74a37e50332d
    74a37e503328:	jmp    0x74a37e504fa5
    74a37e50332d:	movdqu XMMWORD PTR [r12+0x180],xmm0
    74a37e503337:	mov    r13,r14
    74a37e50333a:	add    r13,0xf0
    74a37e503341:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    74a37e503347:	movdqu XMMWORD PTR [r12+0x110],xmm9
    74a37e503351:	movdqa xmm0,xmm6
    74a37e503355:	movdqa xmm1,xmm4
    74a37e503359:	addpd  xmm0,xmm1
    74a37e50335d:	movdqa xmm14,xmm0
    74a37e503362:	movdqu xmm15,XMMWORD PTR [rip+0x92e5]        # 0x74a37e50c650
    74a37e50336b:	pand   xmm14,xmm15
    74a37e503370:	movdqu xmm15,XMMWORD PTR [rip+0x92e7]        # 0x74a37e50c660
    74a37e503379:	pcmpeqq xmm14,xmm15
    74a37e50337f:	movdqa xmm15,xmm0
    74a37e503384:	cmpunordpd xmm15,xmm0
    74a37e50338a:	por    xmm14,xmm15
    74a37e50338f:	pmovmskb ecx,xmm14
    74a37e503394:	jrcxz  0x74a37e50339b
    74a37e503396:	jmp    0x74a37e504fcb
    74a37e50339b:	movdqa xmm12,xmm0
    74a37e5033a0:	movdqu XMMWORD PTR [r12+0x210],xmm12
    74a37e5033aa:	movdqa xmm0,xmm8
    74a37e5033af:	movdqa xmm1,xmm11
    74a37e5033b4:	addpd  xmm0,xmm1
    74a37e5033b8:	movdqa xmm14,xmm0
    74a37e5033bd:	movdqu xmm15,XMMWORD PTR [rip+0x928a]        # 0x74a37e50c650
    74a37e5033c6:	pand   xmm14,xmm15
    74a37e5033cb:	movdqu xmm15,XMMWORD PTR [rip+0x928c]        # 0x74a37e50c660
    74a37e5033d4:	pcmpeqq xmm14,xmm15
    74a37e5033da:	movdqa xmm15,xmm0
    74a37e5033df:	cmpunordpd xmm15,xmm0
    74a37e5033e5:	por    xmm14,xmm15
    74a37e5033ea:	pmovmskb ecx,xmm14
    74a37e5033ef:	jrcxz  0x74a37e5033f6
    74a37e5033f1:	jmp    0x74a37e504fef
    74a37e5033f6:	movdqa xmm4,xmm0
    74a37e5033fa:	movdqu XMMWORD PTR [r12+0x220],xmm4
    74a37e503404:	movdqa xmm0,xmm5
    74a37e503408:	movdqa xmm1,xmm2
    74a37e50340c:	pshufd xmm1,xmm1,0x44
    74a37e503411:	mulpd  xmm0,xmm1
    74a37e503415:	movdqa xmm14,xmm0
    74a37e50341a:	movdqu xmm15,XMMWORD PTR [rip+0x922d]        # 0x74a37e50c650
    74a37e503423:	pand   xmm14,xmm15
    74a37e503428:	movdqu xmm15,XMMWORD PTR [rip+0x922f]        # 0x74a37e50c660
    74a37e503431:	pcmpeqq xmm14,xmm15
    74a37e503437:	movdqa xmm15,xmm0
    74a37e50343c:	cmpunordpd xmm15,xmm0
    74a37e503442:	por    xmm14,xmm15
    74a37e503447:	pmovmskb ecx,xmm14
    74a37e50344c:	jrcxz  0x74a37e503453
    74a37e50344e:	jmp    0x74a37e505015
    74a37e503453:	movdqa xmm6,xmm0
    74a37e503457:	movdqu XMMWORD PTR [r12+0x270],xmm6
    74a37e503461:	movdqu xmm5,XMMWORD PTR [r12+0x170]
    74a37e50346b:	movdqa xmm0,xmm9
    74a37e503470:	movdqa xmm1,xmm5
    74a37e503474:	pshufd xmm1,xmm1,0x44
    74a37e503479:	mulpd  xmm0,xmm1
    74a37e50347d:	movdqa xmm14,xmm0
    74a37e503482:	movdqu xmm15,XMMWORD PTR [rip+0x91c5]        # 0x74a37e50c650
    74a37e50348b:	pand   xmm14,xmm15
    74a37e503490:	movdqu xmm15,XMMWORD PTR [rip+0x91c7]        # 0x74a37e50c660
    74a37e503499:	pcmpeqq xmm14,xmm15
    74a37e50349f:	movdqa xmm15,xmm0
    74a37e5034a4:	cmpunordpd xmm15,xmm0
    74a37e5034aa:	por    xmm14,xmm15
    74a37e5034af:	pmovmskb ecx,xmm14
    74a37e5034b4:	jrcxz  0x74a37e5034bb
    74a37e5034b6:	jmp    0x74a37e505039
    74a37e5034bb:	movdqa xmm8,xmm0
    74a37e5034c0:	movdqu XMMWORD PTR [r12+0x250],xmm8
    74a37e5034ca:	mov    r13,r14
    74a37e5034cd:	add    r13,0xe0
    74a37e5034d4:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    74a37e5034da:	movdqu XMMWORD PTR [r12+0x110],xmm9
    74a37e5034e4:	movdqa xmm0,xmm13
    74a37e5034e9:	movdqa xmm1,xmm2
    74a37e5034ed:	pshufd xmm1,xmm1,0x44
    74a37e5034f2:	mulpd  xmm0,xmm1
    74a37e5034f6:	movdqa xmm14,xmm0
    74a37e5034fb:	movdqu xmm15,XMMWORD PTR [rip+0x914c]        # 0x74a37e50c650
    74a37e503504:	pand   xmm14,xmm15
    74a37e503509:	movdqu xmm15,XMMWORD PTR [rip+0x914e]        # 0x74a37e50c660
    74a37e503512:	pcmpeqq xmm14,xmm15
    74a37e503518:	movdqa xmm15,xmm0
    74a37e50351d:	cmpunordpd xmm15,xmm0
    74a37e503523:	por    xmm14,xmm15
    74a37e503528:	pmovmskb ecx,xmm14
    74a37e50352d:	jrcxz  0x74a37e503534
    74a37e50352f:	jmp    0x74a37e50505e
    74a37e503534:	movdqa xmm11,xmm0
    74a37e503539:	movdqu XMMWORD PTR [r12+0x230],xmm11
    74a37e503543:	movdqa xmm0,xmm10
    74a37e503548:	movdqa xmm1,xmm10
    74a37e50354d:	por    xmm0,xmm1
    74a37e503551:	movdqu XMMWORD PTR [r12+0x300],xmm0
    74a37e50355b:	movdqa xmm0,xmm3
    74a37e50355f:	movdqa xmm1,xmm3
    74a37e503563:	por    xmm0,xmm1
    74a37e503567:	movdqu XMMWORD PTR [r12+0x190],xmm0
    74a37e503571:	movdqa xmm0,xmm9
    74a37e503576:	movdqa xmm1,xmm5
    74a37e50357a:	pshufd xmm1,xmm1,0x44
    74a37e50357f:	mulpd  xmm0,xmm1
    74a37e503583:	movdqa xmm14,xmm0
    74a37e503588:	movdqu xmm15,XMMWORD PTR [rip+0x90bf]        # 0x74a37e50c650
    74a37e503591:	pand   xmm14,xmm15
    74a37e503596:	movdqu xmm15,XMMWORD PTR [rip+0x90c1]        # 0x74a37e50c660
    74a37e50359f:	pcmpeqq xmm14,xmm15
    74a37e5035a5:	movdqa xmm15,xmm0
    74a37e5035aa:	cmpunordpd xmm15,xmm0
    74a37e5035b0:	por    xmm14,xmm15
    74a37e5035b5:	pmovmskb ecx,xmm14
    74a37e5035ba:	jrcxz  0x74a37e5035c1
    74a37e5035bc:	jmp    0x74a37e505083
    74a37e5035c1:	movdqa xmm2,xmm0
    74a37e5035c5:	movdqu XMMWORD PTR [r12+0x260],xmm2
    74a37e5035cf:	mov    r13,r14
    74a37e5035d2:	add    r13,0x90
    74a37e5035d9:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    74a37e5035df:	movdqu XMMWORD PTR [r12+0x110],xmm9
    74a37e5035e9:	movdqa xmm0,xmm7
    74a37e5035ed:	movdqa xmm1,xmm7
    74a37e5035f1:	por    xmm0,xmm1
    74a37e5035f5:	movdqu XMMWORD PTR [r12+0x1c0],xmm0
    74a37e5035ff:	movdqu xmm13,XMMWORD PTR [r12+0x2d0]
    74a37e503609:	movdqu xmm1,XMMWORD PTR [r12+0x2d0]
    74a37e503613:	por    xmm13,xmm1
    74a37e503618:	movdqu XMMWORD PTR [r12+0x200],xmm13
    74a37e503622:	movdqu xmm7,XMMWORD PTR [r12+0x2e0]
    74a37e50362c:	movdqu xmm1,XMMWORD PTR [r12+0x2e0]
    74a37e503636:	por    xmm7,xmm1
    74a37e50363a:	movdqu XMMWORD PTR [r12+0x2d0],xmm7
    74a37e503644:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    74a37e50364e:	movdqu xmm1,XMMWORD PTR [r12+0x2f0]
    74a37e503658:	por    xmm0,xmm1
    74a37e50365c:	movdqu XMMWORD PTR [r12+0x2e0],xmm0
    74a37e503666:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    74a37e503670:	movdqa xmm1,xmm6
    74a37e503674:	addpd  xmm0,xmm1
    74a37e503678:	movdqa xmm14,xmm0
    74a37e50367d:	movdqu xmm15,XMMWORD PTR [rip+0x8fca]        # 0x74a37e50c650
    74a37e503686:	pand   xmm14,xmm15
    74a37e50368b:	movdqu xmm15,XMMWORD PTR [rip+0x8fcc]        # 0x74a37e50c660
    74a37e503694:	pcmpeqq xmm14,xmm15
    74a37e50369a:	movdqa xmm15,xmm0
    74a37e50369f:	cmpunordpd xmm15,xmm0
    74a37e5036a5:	por    xmm14,xmm15
    74a37e5036aa:	pmovmskb ecx,xmm14
    74a37e5036af:	jrcxz  0x74a37e5036b6
    74a37e5036b1:	jmp    0x74a37e5050a8
    74a37e5036b6:	movdqa xmm3,xmm0
    74a37e5036ba:	movdqu XMMWORD PTR [r12+0x240],xmm3
    74a37e5036c4:	movdqa xmm0,xmm9
    74a37e5036c9:	movdqa xmm1,xmm5
    74a37e5036cd:	pshufd xmm1,xmm1,0x44
    74a37e5036d2:	mulpd  xmm0,xmm1
    74a37e5036d6:	movdqa xmm14,xmm0
    74a37e5036db:	movdqu xmm15,XMMWORD PTR [rip+0x8f6c]        # 0x74a37e50c650
    74a37e5036e4:	pand   xmm14,xmm15
    74a37e5036e9:	movdqu xmm15,XMMWORD PTR [rip+0x8f6e]        # 0x74a37e50c660
    74a37e5036f2:	pcmpeqq xmm14,xmm15
    74a37e5036f8:	movdqa xmm15,xmm0
    74a37e5036fd:	cmpunordpd xmm15,xmm0
    74a37e503703:	por    xmm14,xmm15
    74a37e503708:	pmovmskb ecx,xmm14
    74a37e50370d:	jrcxz  0x74a37e503714
    74a37e50370f:	jmp    0x74a37e5050d2
    74a37e503714:	movdqa xmm6,xmm0
    74a37e503718:	movdqu XMMWORD PTR [r12+0x270],xmm6
    74a37e503722:	mov    r13,r14
    74a37e503725:	add    r13,0x80
    74a37e50372c:	movdqu xmm9,XMMWORD PTR [r13+0x0]
    74a37e503732:	movdqu XMMWORD PTR [r12+0x110],xmm9
    74a37e50373c:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    74a37e503746:	movdqa xmm1,xmm11
    74a37e50374b:	addpd  xmm0,xmm1
    74a37e50374f:	movdqa xmm14,xmm0
    74a37e503754:	movdqu xmm15,XMMWORD PTR [rip+0x8ef3]        # 0x74a37e50c650
    74a37e50375d:	pand   xmm14,xmm15
    74a37e503762:	movdqu xmm15,XMMWORD PTR [rip+0x8ef5]        # 0x74a37e50c660
    74a37e50376b:	pcmpeqq xmm14,xmm15
    74a37e503771:	movdqa xmm15,xmm0
    74a37e503776:	cmpunordpd xmm15,xmm0
    74a37e50377c:	por    xmm14,xmm15
    74a37e503781:	pmovmskb ecx,xmm14
    74a37e503786:	jrcxz  0x74a37e50378d
    74a37e503788:	jmp    0x74a37e5050f7
    74a37e50378d:	movdqa xmm10,xmm0
    74a37e503792:	movdqu XMMWORD PTR [r12+0x180],xmm10
    74a37e50379c:	movdqa xmm0,xmm12
    74a37e5037a1:	movdqa xmm1,xmm8
    74a37e5037a6:	addpd  xmm0,xmm1
    74a37e5037aa:	movdqa xmm14,xmm0
    74a37e5037af:	movdqu xmm15,XMMWORD PTR [rip+0x8e98]        # 0x74a37e50c650
    74a37e5037b8:	pand   xmm14,xmm15
    74a37e5037bd:	movdqu xmm15,XMMWORD PTR [rip+0x8e9a]        # 0x74a37e50c660
    74a37e5037c6:	pcmpeqq xmm14,xmm15
    74a37e5037cc:	movdqa xmm15,xmm0
    74a37e5037d1:	cmpunordpd xmm15,xmm0
    74a37e5037d7:	por    xmm14,xmm15
    74a37e5037dc:	pmovmskb ecx,xmm14
    74a37e5037e1:	jrcxz  0x74a37e5037e8
    74a37e5037e3:	jmp    0x74a37e505122
    74a37e5037e8:	movdqa xmm11,xmm0
    74a37e5037ed:	movdqu XMMWORD PTR [r12+0x210],xmm11
    74a37e5037f7:	movdqu xmm0,XMMWORD PTR [r12+0x1b0]
    74a37e503801:	movdqu xmm1,XMMWORD PTR [r12+0x1b0]
    74a37e50380b:	por    xmm0,xmm1
    74a37e50380f:	movdqu XMMWORD PTR [r12+0x2f0],xmm0
    74a37e503819:	movdqa xmm0,xmm9
    74a37e50381e:	movdqa xmm1,xmm5
    74a37e503822:	pshufd xmm1,xmm1,0x44
    74a37e503827:	mulpd  xmm0,xmm1
    74a37e50382b:	movdqa xmm14,xmm0
    74a37e503830:	movdqu xmm15,XMMWORD PTR [rip+0x8e17]        # 0x74a37e50c650
    74a37e503839:	pand   xmm14,xmm15
    74a37e50383e:	movdqu xmm15,XMMWORD PTR [rip+0x8e19]        # 0x74a37e50c660
    74a37e503847:	pcmpeqq xmm14,xmm15
    74a37e50384d:	movdqa xmm15,xmm0
    74a37e503852:	cmpunordpd xmm15,xmm0
    74a37e503858:	por    xmm14,xmm15
    74a37e50385d:	pmovmskb ecx,xmm14
    74a37e503862:	jrcxz  0x74a37e503869
    74a37e503864:	jmp    0x74a37e505148
    74a37e503869:	movdqa xmm12,xmm0
    74a37e50386e:	movdqu XMMWORD PTR [r12+0x170],xmm12
    74a37e503878:	mov    r13,r14
    74a37e50387b:	add    r13,0xd0
    74a37e503882:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    74a37e503888:	movdqu XMMWORD PTR [r12+0x110],xmm5
    74a37e503892:	movdqa xmm0,xmm4
    74a37e503896:	movdqa xmm1,xmm2
    74a37e50389a:	addpd  xmm0,xmm1
    74a37e50389e:	movdqa xmm14,xmm0
    74a37e5038a3:	movdqu xmm15,XMMWORD PTR [rip+0x8da4]        # 0x74a37e50c650
    74a37e5038ac:	pand   xmm14,xmm15
    74a37e5038b1:	movdqu xmm15,XMMWORD PTR [rip+0x8da6]        # 0x74a37e50c660
    74a37e5038ba:	pcmpeqq xmm14,xmm15
    74a37e5038c0:	movdqa xmm15,xmm0
    74a37e5038c5:	cmpunordpd xmm15,xmm0
    74a37e5038cb:	por    xmm14,xmm15
    74a37e5038d0:	pmovmskb ecx,xmm14
    74a37e5038d5:	jrcxz  0x74a37e5038dc
    74a37e5038d7:	jmp    0x74a37e50516d
    74a37e5038dc:	movdqa xmm9,xmm0
    74a37e5038e1:	movdqu XMMWORD PTR [r12+0x220],xmm9
    74a37e5038eb:	movdqu xmm2,XMMWORD PTR [r12+0x160]
    74a37e5038f5:	movdqa xmm0,xmm13
    74a37e5038fa:	movdqa xmm1,xmm2
    74a37e5038fe:	pshufd xmm1,xmm1,0x44
    74a37e503903:	mulpd  xmm0,xmm1
    74a37e503907:	movdqa xmm14,xmm0
    74a37e50390c:	movdqu xmm15,XMMWORD PTR [rip+0x8d3b]        # 0x74a37e50c650
    74a37e503915:	pand   xmm14,xmm15
    74a37e50391a:	movdqu xmm15,XMMWORD PTR [rip+0x8d3d]        # 0x74a37e50c660
    74a37e503923:	pcmpeqq xmm14,xmm15
    74a37e503929:	movdqa xmm15,xmm0
    74a37e50392e:	cmpunordpd xmm15,xmm0
    74a37e503934:	por    xmm14,xmm15
    74a37e503939:	pmovmskb ecx,xmm14
    74a37e50393e:	jrcxz  0x74a37e503945
    74a37e503940:	jmp    0x74a37e505191
    74a37e503945:	movdqa xmm4,xmm0
    74a37e503949:	movdqu XMMWORD PTR [r12+0x260],xmm4
    74a37e503953:	mov    r13d,0x0
    74a37e503959:	mov    ebp,0x0
    74a37e50395e:	mov    QWORD PTR [r12+0x1b0],r13
    74a37e503966:	mov    QWORD PTR [r12+0x1b8],rbp
    74a37e50396e:	movdqa xmm0,xmm5
    74a37e503972:	movdqa xmm1,xmm2
    74a37e503976:	pshufd xmm1,xmm1,0x44
    74a37e50397b:	mulpd  xmm0,xmm1
    74a37e50397f:	movdqa xmm14,xmm0
    74a37e503984:	movdqu xmm15,XMMWORD PTR [rip+0x8cc3]        # 0x74a37e50c650
    74a37e50398d:	pand   xmm14,xmm15
    74a37e503992:	movdqu xmm15,XMMWORD PTR [rip+0x8cc5]        # 0x74a37e50c660
    74a37e50399b:	pcmpeqq xmm14,xmm15
    74a37e5039a1:	movdqa xmm15,xmm0
    74a37e5039a6:	cmpunordpd xmm15,xmm0
    74a37e5039ac:	por    xmm14,xmm15
    74a37e5039b1:	pmovmskb ecx,xmm14
    74a37e5039b6:	jrcxz  0x74a37e5039bd
    74a37e5039b8:	jmp    0x74a37e5051b6
    74a37e5039bd:	movdqa xmm13,xmm0
    74a37e5039c2:	movdqu XMMWORD PTR [r12+0x230],xmm13
    74a37e5039cc:	mov    r13,r14
    74a37e5039cf:	add    r13,0xc0
    74a37e5039d6:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    74a37e5039dc:	movdqu XMMWORD PTR [r12+0x110],xmm5
    74a37e5039e6:	movdqa xmm0,xmm3
    74a37e5039ea:	movdqa xmm1,xmm6
    74a37e5039ee:	addpd  xmm0,xmm1
    74a37e5039f2:	movdqa xmm14,xmm0
    74a37e5039f7:	movdqu xmm15,XMMWORD PTR [rip+0x8c50]        # 0x74a37e50c650
    74a37e503a00:	pand   xmm14,xmm15
    74a37e503a05:	movdqu xmm15,XMMWORD PTR [rip+0x8c52]        # 0x74a37e50c660
    74a37e503a0e:	pcmpeqq xmm14,xmm15
    74a37e503a14:	movdqa xmm15,xmm0
    74a37e503a19:	cmpunordpd xmm15,xmm0
    74a37e503a1f:	por    xmm14,xmm15
    74a37e503a24:	pmovmskb ecx,xmm14
    74a37e503a29:	jrcxz  0x74a37e503a30
    74a37e503a2b:	jmp    0x74a37e5051da
    74a37e503a30:	movdqa xmm8,xmm0
    74a37e503a35:	movdqu XMMWORD PTR [r12+0x240],xmm8
    74a37e503a3f:	movdqu xmm0,XMMWORD PTR [r12+0x1a0]
    74a37e503a49:	movdqu xmm1,XMMWORD PTR [r12+0x1a0]
    74a37e503a53:	por    xmm0,xmm1
    74a37e503a57:	movdqu XMMWORD PTR [r12+0x270],xmm0
    74a37e503a61:	movdqu xmm6,XMMWORD PTR [r12+0x120]
    74a37e503a6b:	movdqu xmm1,XMMWORD PTR [r12+0x120]
    74a37e503a75:	por    xmm6,xmm1
    74a37e503a79:	movdqu XMMWORD PTR [r12+0x1a0],xmm6
    74a37e503a83:	movdqa xmm0,xmm5
    74a37e503a87:	movdqa xmm1,xmm2
    74a37e503a8b:	pshufd xmm1,xmm1,0x44
    74a37e503a90:	mulpd  xmm0,xmm1
    74a37e503a94:	movdqa xmm14,xmm0
    74a37e503a99:	movdqu xmm15,XMMWORD PTR [rip+0x8bae]        # 0x74a37e50c650
    74a37e503aa2:	pand   xmm14,xmm15
    74a37e503aa7:	movdqu xmm15,XMMWORD PTR [rip+0x8bb0]        # 0x74a37e50c660
    74a37e503ab0:	pcmpeqq xmm14,xmm15
    74a37e503ab6:	movdqa xmm15,xmm0
    74a37e503abb:	cmpunordpd xmm15,xmm0
    74a37e503ac1:	por    xmm14,xmm15
    74a37e503ac6:	pmovmskb ecx,xmm14
    74a37e503acb:	jrcxz  0x74a37e503ad2
    74a37e503acd:	jmp    0x74a37e5051fe
    74a37e503ad2:	movdqa xmm6,xmm0
    74a37e503ad6:	movdqu XMMWORD PTR [r12+0x250],xmm6
    74a37e503ae0:	mov    r13,r14
    74a37e503ae3:	add    r13,0x20
    74a37e503ae7:	movdqu xmm5,XMMWORD PTR [r13+0x0]
    74a37e503aed:	movdqu XMMWORD PTR [r12+0x110],xmm5
    74a37e503af7:	movdqa xmm0,xmm10
    74a37e503afc:	movdqa xmm1,xmm12
    74a37e503b01:	addpd  xmm0,xmm1
    74a37e503b05:	movdqa xmm14,xmm0
    74a37e503b0a:	movdqu xmm15,XMMWORD PTR [rip+0x8b3d]        # 0x74a37e50c650
    74a37e503b13:	pand   xmm14,xmm15
    74a37e503b18:	movdqu xmm15,XMMWORD PTR [rip+0x8b3f]        # 0x74a37e50c660
    74a37e503b21:	pcmpeqq xmm14,xmm15
    74a37e503b27:	movdqa xmm15,xmm0
    74a37e503b2c:	cmpunordpd xmm15,xmm0
    74a37e503b32:	por    xmm14,xmm15
    74a37e503b37:	pmovmskb ecx,xmm14
    74a37e503b3c:	jrcxz  0x74a37e503b43
    74a37e503b3e:	jmp    0x74a37e505222
    74a37e503b43:	movdqa xmm3,xmm0
    74a37e503b47:	movdqa xmm0,xmm7
    74a37e503b4b:	movdqa xmm1,xmm2
    74a37e503b4f:	pshufd xmm1,xmm1,0x44
    74a37e503b54:	mulpd  xmm0,xmm1
    74a37e503b58:	movdqa xmm14,xmm0
    74a37e503b5d:	movdqu xmm15,XMMWORD PTR [rip+0x8aea]        # 0x74a37e50c650
    74a37e503b66:	pand   xmm14,xmm15
    74a37e503b6b:	movdqu xmm15,XMMWORD PTR [rip+0x8aec]        # 0x74a37e50c660
    74a37e503b74:	pcmpeqq xmm14,xmm15
    74a37e503b7a:	movdqa xmm15,xmm0
    74a37e503b7f:	cmpunordpd xmm15,xmm0
    74a37e503b85:	por    xmm14,xmm15
    74a37e503b8a:	pmovmskb ecx,xmm14
    74a37e503b8f:	jrcxz  0x74a37e503b96
    74a37e503b91:	jmp    0x74a37e505248
    74a37e503b96:	movdqa xmm10,xmm0
    74a37e503b9b:	movdqa xmm0,xmm11
    74a37e503ba0:	movdqa xmm1,xmm13
    74a37e503ba5:	addpd  xmm0,xmm1
    74a37e503ba9:	movdqa xmm14,xmm0
    74a37e503bae:	movdqu xmm15,XMMWORD PTR [rip+0x8a99]        # 0x74a37e50c650
    74a37e503bb7:	pand   xmm14,xmm15
    74a37e503bbc:	movdqu xmm15,XMMWORD PTR [rip+0x8a9b]        # 0x74a37e50c660
    74a37e503bc5:	pcmpeqq xmm14,xmm15
    74a37e503bcb:	movdqa xmm15,xmm0
    74a37e503bd0:	cmpunordpd xmm15,xmm0
    74a37e503bd6:	por    xmm14,xmm15
    74a37e503bdb:	pmovmskb ecx,xmm14
    74a37e503be0:	jrcxz  0x74a37e503be7
    74a37e503be2:	jmp    0x74a37e50526c
    74a37e503be7:	movdqa xmm2,xmm0
    74a37e503beb:	movdqu xmm7,XMMWORD PTR [r12+0x150]
    74a37e503bf5:	movdqa xmm0,xmm5
    74a37e503bf9:	movdqa xmm1,xmm7
    74a37e503bfd:	pshufd xmm1,xmm1,0x44
    74a37e503c02:	mulpd  xmm0,xmm1
    74a37e503c06:	movdqa xmm14,xmm0
    74a37e503c0b:	movdqu xmm15,XMMWORD PTR [rip+0x8a3c]        # 0x74a37e50c650
    74a37e503c14:	pand   xmm14,xmm15
    74a37e503c19:	movdqu xmm15,XMMWORD PTR [rip+0x8a3e]        # 0x74a37e50c660
    74a37e503c22:	pcmpeqq xmm14,xmm15
    74a37e503c28:	movdqa xmm15,xmm0
    74a37e503c2d:	cmpunordpd xmm15,xmm0
    74a37e503c33:	por    xmm14,xmm15
    74a37e503c38:	pmovmskb ecx,xmm14
    74a37e503c3d:	jrcxz  0x74a37e503c44
    74a37e503c3f:	jmp    0x74a37e505292
    74a37e503c44:	movdqa xmm11,xmm0
    74a37e503c49:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    74a37e503c53:	movdqa xmm1,xmm7
    74a37e503c57:	pshufd xmm1,xmm1,0x44
    74a37e503c5c:	mulpd  xmm0,xmm1
    74a37e503c60:	movdqa xmm14,xmm0
    74a37e503c65:	movdqu xmm15,XMMWORD PTR [rip+0x89e2]        # 0x74a37e50c650
    74a37e503c6e:	pand   xmm14,xmm15
    74a37e503c73:	movdqu xmm15,XMMWORD PTR [rip+0x89e4]        # 0x74a37e50c660
    74a37e503c7c:	pcmpeqq xmm14,xmm15
    74a37e503c82:	movdqa xmm15,xmm0
    74a37e503c87:	cmpunordpd xmm15,xmm0
    74a37e503c8d:	por    xmm14,xmm15
    74a37e503c92:	pmovmskb ecx,xmm14
    74a37e503c97:	jrcxz  0x74a37e503c9e
    74a37e503c99:	jmp    0x74a37e5052b6
    74a37e503c9e:	movdqa xmm5,xmm0
    74a37e503ca2:	movdqa xmm0,xmm8
    74a37e503ca7:	movdqa xmm1,xmm4
    74a37e503cab:	addpd  xmm0,xmm1
    74a37e503caf:	movdqa xmm14,xmm0
    74a37e503cb4:	movdqu xmm15,XMMWORD PTR [rip+0x8993]        # 0x74a37e50c650
    74a37e503cbd:	pand   xmm14,xmm15
    74a37e503cc2:	movdqu xmm15,XMMWORD PTR [rip+0x8995]        # 0x74a37e50c660
    74a37e503ccb:	pcmpeqq xmm14,xmm15
    74a37e503cd1:	movdqa xmm15,xmm0
    74a37e503cd6:	cmpunordpd xmm15,xmm0
    74a37e503cdc:	por    xmm14,xmm15
    74a37e503ce1:	pmovmskb ecx,xmm14
    74a37e503ce6:	jrcxz  0x74a37e503ced
    74a37e503ce8:	jmp    0x74a37e5052e0
    74a37e503ced:	movdqa xmm12,xmm0
    74a37e503cf2:	movdqu XMMWORD PTR [r12+0x240],xmm12
    74a37e503cfc:	movdqa xmm0,xmm9
    74a37e503d01:	movdqa xmm1,xmm6
    74a37e503d05:	addpd  xmm0,xmm1
    74a37e503d09:	movdqa xmm14,xmm0
    74a37e503d0e:	movdqu xmm15,XMMWORD PTR [rip+0x8939]        # 0x74a37e50c650
    74a37e503d17:	pand   xmm14,xmm15
    74a37e503d1c:	movdqu xmm15,XMMWORD PTR [rip+0x893b]        # 0x74a37e50c660
    74a37e503d25:	pcmpeqq xmm14,xmm15
    74a37e503d2b:	movdqa xmm15,xmm0
    74a37e503d30:	cmpunordpd xmm15,xmm0
    74a37e503d36:	por    xmm14,xmm15
    74a37e503d3b:	pmovmskb ecx,xmm14
    74a37e503d40:	jrcxz  0x74a37e503d47
    74a37e503d42:	jmp    0x74a37e505305
    74a37e503d47:	movdqa xmm4,xmm0
    74a37e503d4b:	movdqu XMMWORD PTR [r12+0x220],xmm4
    74a37e503d55:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    74a37e503d5f:	movdqa xmm1,xmm7
    74a37e503d63:	pshufd xmm1,xmm1,0x44
    74a37e503d68:	mulpd  xmm0,xmm1
    74a37e503d6c:	movdqa xmm14,xmm0
    74a37e503d71:	movdqu xmm15,XMMWORD PTR [rip+0x88d6]        # 0x74a37e50c650
    74a37e503d7a:	pand   xmm14,xmm15
    74a37e503d7f:	movdqu xmm15,XMMWORD PTR [rip+0x88d8]        # 0x74a37e50c660
    74a37e503d88:	pcmpeqq xmm14,xmm15
    74a37e503d8e:	movdqa xmm15,xmm0
    74a37e503d93:	cmpunordpd xmm15,xmm0
    74a37e503d99:	por    xmm14,xmm15
    74a37e503d9e:	pmovmskb ecx,xmm14
    74a37e503da3:	jrcxz  0x74a37e503daa
    74a37e503da5:	jmp    0x74a37e50532a
    74a37e503daa:	movdqa xmm6,xmm0
    74a37e503dae:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    74a37e503db8:	movdqa xmm1,xmm7
    74a37e503dbc:	pshufd xmm1,xmm1,0x44
    74a37e503dc1:	mulpd  xmm0,xmm1
    74a37e503dc5:	movdqa xmm14,xmm0
    74a37e503dca:	movdqu xmm15,XMMWORD PTR [rip+0x887d]        # 0x74a37e50c650
    74a37e503dd3:	pand   xmm14,xmm15
    74a37e503dd8:	movdqu xmm15,XMMWORD PTR [rip+0x887f]        # 0x74a37e50c660
    74a37e503de1:	pcmpeqq xmm14,xmm15
    74a37e503de7:	movdqa xmm15,xmm0
    74a37e503dec:	cmpunordpd xmm15,xmm0
    74a37e503df2:	por    xmm14,xmm15
    74a37e503df7:	pmovmskb ecx,xmm14
    74a37e503dfc:	jrcxz  0x74a37e503e03
    74a37e503dfe:	jmp    0x74a37e505354
    74a37e503e03:	movdqa xmm8,xmm0
    74a37e503e08:	movdqu XMMWORD PTR [r12+0x150],xmm8
    74a37e503e12:	movdqa xmm0,xmm3
    74a37e503e16:	movdqa xmm1,xmm10
    74a37e503e1b:	addpd  xmm0,xmm1
    74a37e503e1f:	movdqa xmm14,xmm0
    74a37e503e24:	movdqu xmm15,XMMWORD PTR [rip+0x8823]        # 0x74a37e50c650
    74a37e503e2d:	pand   xmm14,xmm15
    74a37e503e32:	movdqu xmm15,XMMWORD PTR [rip+0x8825]        # 0x74a37e50c660
    74a37e503e3b:	pcmpeqq xmm14,xmm15
    74a37e503e41:	movdqa xmm15,xmm0
    74a37e503e46:	cmpunordpd xmm15,xmm0
    74a37e503e4c:	por    xmm14,xmm15
    74a37e503e51:	pmovmskb ecx,xmm14
    74a37e503e56:	jrcxz  0x74a37e503e5d
    74a37e503e58:	jmp    0x74a37e50537e
    74a37e503e5d:	movdqa xmm7,xmm0
    74a37e503e61:	movdqu XMMWORD PTR [r12+0x160],xmm7
    74a37e503e6b:	movdqa xmm0,xmm2
    74a37e503e6f:	movdqa xmm1,xmm11
    74a37e503e74:	addpd  xmm0,xmm1
    74a37e503e78:	movdqa xmm14,xmm0
    74a37e503e7d:	movdqu xmm15,XMMWORD PTR [rip+0x87ca]        # 0x74a37e50c650
    74a37e503e86:	pand   xmm14,xmm15
    74a37e503e8b:	movdqu xmm15,XMMWORD PTR [rip+0x87cc]        # 0x74a37e50c660
    74a37e503e94:	pcmpeqq xmm14,xmm15
    74a37e503e9a:	movdqa xmm15,xmm0
    74a37e503e9f:	cmpunordpd xmm15,xmm0
    74a37e503ea5:	por    xmm14,xmm15
    74a37e503eaa:	pmovmskb ecx,xmm14
    74a37e503eaf:	jrcxz  0x74a37e503eb6
    74a37e503eb1:	jmp    0x74a37e5053a3
    74a37e503eb6:	movdqa xmm3,xmm0
    74a37e503eba:	movdqu XMMWORD PTR [r12+0x170],xmm3
    74a37e503ec4:	movdqu xmm2,XMMWORD PTR [r12+0x140]
    74a37e503ece:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    74a37e503ed8:	movdqa xmm1,xmm2
    74a37e503edc:	pshufd xmm1,xmm1,0x44
    74a37e503ee1:	mulpd  xmm0,xmm1
    74a37e503ee5:	movdqa xmm14,xmm0
    74a37e503eea:	movdqu xmm15,XMMWORD PTR [rip+0x875d]        # 0x74a37e50c650
    74a37e503ef3:	pand   xmm14,xmm15
    74a37e503ef8:	movdqu xmm15,XMMWORD PTR [rip+0x875f]        # 0x74a37e50c660
    74a37e503f01:	pcmpeqq xmm14,xmm15
    74a37e503f07:	movdqa xmm15,xmm0
    74a37e503f0c:	cmpunordpd xmm15,xmm0
    74a37e503f12:	por    xmm14,xmm15
    74a37e503f17:	pmovmskb ecx,xmm14
    74a37e503f1c:	jrcxz  0x74a37e503f23
    74a37e503f1e:	jmp    0x74a37e5053c8
    74a37e503f23:	movdqa xmm9,xmm0
    74a37e503f28:	movdqu XMMWORD PTR [r12+0x180],xmm9
    74a37e503f32:	movdqa xmm0,xmm4
    74a37e503f36:	movdqa xmm1,xmm5
    74a37e503f3a:	addpd  xmm0,xmm1
    74a37e503f3e:	movdqa xmm14,xmm0
    74a37e503f43:	movdqu xmm15,XMMWORD PTR [rip+0x8704]        # 0x74a37e50c650
    74a37e503f4c:	pand   xmm14,xmm15
    74a37e503f51:	movdqu xmm15,XMMWORD PTR [rip+0x8706]        # 0x74a37e50c660
    74a37e503f5a:	pcmpeqq xmm14,xmm15
    74a37e503f60:	movdqa xmm15,xmm0
    74a37e503f65:	cmpunordpd xmm15,xmm0
    74a37e503f6b:	por    xmm14,xmm15
    74a37e503f70:	pmovmskb ecx,xmm14
    74a37e503f75:	jrcxz  0x74a37e503f7c
    74a37e503f77:	jmp    0x74a37e5053f2
    74a37e503f7c:	movdqa xmm10,xmm0
    74a37e503f81:	movdqu XMMWORD PTR [r12+0x210],xmm10
    74a37e503f8b:	movdqa xmm0,xmm12
    74a37e503f90:	movdqa xmm1,xmm6
    74a37e503f94:	addpd  xmm0,xmm1
    74a37e503f98:	movdqa xmm14,xmm0
    74a37e503f9d:	movdqu xmm15,XMMWORD PTR [rip+0x86aa]        # 0x74a37e50c650
    74a37e503fa6:	pand   xmm14,xmm15
    74a37e503fab:	movdqu xmm15,XMMWORD PTR [rip+0x86ac]        # 0x74a37e50c660
    74a37e503fb4:	pcmpeqq xmm14,xmm15
    74a37e503fba:	movdqa xmm15,xmm0
    74a37e503fbf:	cmpunordpd xmm15,xmm0
    74a37e503fc5:	por    xmm14,xmm15
    74a37e503fca:	pmovmskb ecx,xmm14
    74a37e503fcf:	jrcxz  0x74a37e503fd6
    74a37e503fd1:	jmp    0x74a37e505416
    74a37e503fd6:	movdqa xmm4,xmm0
    74a37e503fda:	movdqu XMMWORD PTR [r12+0x230],xmm4
    74a37e503fe4:	movdqu xmm5,XMMWORD PTR [r12+0x2a0]
    74a37e503fee:	movdqu xmm1,XMMWORD PTR [r12+0x2a0]
    74a37e503ff8:	por    xmm5,xmm1
    74a37e503ffc:	movdqu XMMWORD PTR [r12+0x250],xmm5
    74a37e504006:	movdqu xmm5,XMMWORD PTR [r12+0x1d0]
    74a37e504010:	movdqu xmm1,XMMWORD PTR [r12+0x1d0]
    74a37e50401a:	por    xmm5,xmm1
    74a37e50401e:	movdqu XMMWORD PTR [r12+0x2a0],xmm5
    74a37e504028:	movdqu xmm6,XMMWORD PTR [r12+0x2c0]
    74a37e504032:	movdqu xmm1,XMMWORD PTR [r12+0x2c0]
    74a37e50403c:	por    xmm6,xmm1
    74a37e504040:	movdqu XMMWORD PTR [r12+0x1d0],xmm6
    74a37e50404a:	mov    r13,r14
    74a37e50404d:	add    r13,0x40
    74a37e504051:	movdqu xmm6,XMMWORD PTR [r13+0x0]
    74a37e504057:	movdqu XMMWORD PTR [r12+0x2c0],xmm6
    74a37e504061:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    74a37e50406b:	movdqa xmm1,xmm2
    74a37e50406f:	pshufd xmm1,xmm1,0x44
    74a37e504074:	mulpd  xmm0,xmm1
    74a37e504078:	movdqa xmm14,xmm0
    74a37e50407d:	movdqu xmm15,XMMWORD PTR [rip+0x85ca]        # 0x74a37e50c650
    74a37e504086:	pand   xmm14,xmm15
    74a37e50408b:	movdqu xmm15,XMMWORD PTR [rip+0x85cc]        # 0x74a37e50c660
    74a37e504094:	pcmpeqq xmm14,xmm15
    74a37e50409a:	movdqa xmm15,xmm0
    74a37e50409f:	cmpunordpd xmm15,xmm0
    74a37e5040a5:	por    xmm14,xmm15
    74a37e5040aa:	pmovmskb ecx,xmm14
    74a37e5040af:	jrcxz  0x74a37e5040b6
    74a37e5040b1:	jmp    0x74a37e50543b
    74a37e5040b6:	movdqa xmm11,xmm0
    74a37e5040bb:	movdqa xmm0,xmm7
    74a37e5040bf:	movdqa xmm1,xmm8
    74a37e5040c4:	addpd  xmm0,xmm1
    74a37e5040c8:	movdqa xmm14,xmm0
    74a37e5040cd:	movdqu xmm15,XMMWORD PTR [rip+0x857a]        # 0x74a37e50c650
    74a37e5040d6:	pand   xmm14,xmm15
    74a37e5040db:	movdqu xmm15,XMMWORD PTR [rip+0x857c]        # 0x74a37e50c660
    74a37e5040e4:	pcmpeqq xmm14,xmm15
    74a37e5040ea:	movdqa xmm15,xmm0
    74a37e5040ef:	cmpunordpd xmm15,xmm0
    74a37e5040f5:	por    xmm14,xmm15
    74a37e5040fa:	pmovmskb ecx,xmm14
    74a37e5040ff:	jrcxz  0x74a37e504106
    74a37e504101:	jmp    0x74a37e505465
    74a37e504106:	movdqa xmm12,xmm0
    74a37e50410b:	movdqa xmm0,xmm3
    74a37e50410f:	movdqa xmm1,xmm9
    74a37e504114:	addpd  xmm0,xmm1
    74a37e504118:	movdqa xmm14,xmm0
    74a37e50411d:	movdqu xmm15,XMMWORD PTR [rip+0x852a]        # 0x74a37e50c650
    74a37e504126:	pand   xmm14,xmm15
    74a37e50412b:	movdqu xmm15,XMMWORD PTR [rip+0x852c]        # 0x74a37e50c660
    74a37e504134:	pcmpeqq xmm14,xmm15
    74a37e50413a:	movdqa xmm15,xmm0
    74a37e50413f:	cmpunordpd xmm15,xmm0
    74a37e504145:	por    xmm14,xmm15
    74a37e50414a:	pmovmskb ecx,xmm14
    74a37e50414f:	jrcxz  0x74a37e504156
    74a37e504151:	jmp    0x74a37e50548a
    74a37e504156:	movdqa xmm7,xmm0
    74a37e50415a:	movdqu XMMWORD PTR [r12+0x160],xmm7
    74a37e504164:	movdqa xmm0,xmm6
    74a37e504168:	movdqa xmm1,xmm2
    74a37e50416c:	pshufd xmm1,xmm1,0x44
    74a37e504171:	mulpd  xmm0,xmm1
    74a37e504175:	movdqa xmm14,xmm0
    74a37e50417a:	movdqu xmm15,XMMWORD PTR [rip+0x84cd]        # 0x74a37e50c650
    74a37e504183:	pand   xmm14,xmm15
    74a37e504188:	movdqu xmm15,XMMWORD PTR [rip+0x84cf]        # 0x74a37e50c660
    74a37e504191:	pcmpeqq xmm14,xmm15
    74a37e504197:	movdqa xmm15,xmm0
    74a37e50419c:	cmpunordpd xmm15,xmm0
    74a37e5041a2:	por    xmm14,xmm15
    74a37e5041a7:	pmovmskb ecx,xmm14
    74a37e5041ac:	jrcxz  0x74a37e5041b3
    74a37e5041ae:	jmp    0x74a37e5054af
    74a37e5041b3:	movdqa xmm3,xmm0
    74a37e5041b7:	movdqu XMMWORD PTR [r12+0x240],xmm3
    74a37e5041c1:	movdqu xmm6,XMMWORD PTR [r12+0x2b0]
    74a37e5041cb:	movdqa xmm0,xmm6
    74a37e5041cf:	movdqa xmm1,xmm2
    74a37e5041d3:	pshufd xmm1,xmm1,0x44
    74a37e5041d8:	mulpd  xmm0,xmm1
    74a37e5041dc:	movdqa xmm14,xmm0
    74a37e5041e1:	movdqu xmm15,XMMWORD PTR [rip+0x8466]        # 0x74a37e50c650
    74a37e5041ea:	pand   xmm14,xmm15
    74a37e5041ef:	movdqu xmm15,XMMWORD PTR [rip+0x8468]        # 0x74a37e50c660
    74a37e5041f8:	pcmpeqq xmm14,xmm15
    74a37e5041fe:	movdqa xmm15,xmm0
    74a37e504203:	cmpunordpd xmm15,xmm0
    74a37e504209:	por    xmm14,xmm15
    74a37e50420e:	pmovmskb ecx,xmm14
    74a37e504213:	jrcxz  0x74a37e50421a
    74a37e504215:	jmp    0x74a37e5054d3
    74a37e50421a:	movdqa xmm8,xmm0
    74a37e50421f:	movdqu xmm2,XMMWORD PTR [r12+0x130]
    74a37e504229:	movdqa xmm0,xmm5
    74a37e50422d:	movdqa xmm1,xmm2
    74a37e504231:	pshufd xmm1,xmm1,0x44
    74a37e504236:	mulpd  xmm0,xmm1
    74a37e50423a:	movdqa xmm14,xmm0
    74a37e50423f:	movdqu xmm15,XMMWORD PTR [rip+0x8408]        # 0x74a37e50c650
    74a37e504248:	pand   xmm14,xmm15
    74a37e50424d:	movdqu xmm15,XMMWORD PTR [rip+0x840a]        # 0x74a37e50c660
    74a37e504256:	pcmpeqq xmm14,xmm15
    74a37e50425c:	movdqa xmm15,xmm0
    74a37e504261:	cmpunordpd xmm15,xmm0
    74a37e504267:	por    xmm14,xmm15
    74a37e50426c:	pmovmskb ecx,xmm14
    74a37e504271:	jrcxz  0x74a37e504278
    74a37e504273:	jmp    0x74a37e5054f7
    74a37e504278:	movdqa xmm6,xmm0
    74a37e50427c:	movdqu XMMWORD PTR [r12+0x170],xmm6
    74a37e504286:	movdqa xmm0,xmm10
    74a37e50428b:	movdqa xmm1,xmm11
    74a37e504290:	addpd  xmm0,xmm1
    74a37e504294:	movdqa xmm14,xmm0
    74a37e504299:	movdqu xmm15,XMMWORD PTR [rip+0x83ae]        # 0x74a37e50c650
    74a37e5042a2:	pand   xmm14,xmm15
    74a37e5042a7:	movdqu xmm15,XMMWORD PTR [rip+0x83b0]        # 0x74a37e50c660
    74a37e5042b0:	pcmpeqq xmm14,xmm15
    74a37e5042b6:	movdqa xmm15,xmm0
    74a37e5042bb:	cmpunordpd xmm15,xmm0
    74a37e5042c1:	por    xmm14,xmm15
    74a37e5042c6:	pmovmskb ecx,xmm14
    74a37e5042cb:	jrcxz  0x74a37e5042d2
    74a37e5042cd:	jmp    0x74a37e50551b
    74a37e5042d2:	movdqa xmm5,xmm0
    74a37e5042d6:	movdqu XMMWORD PTR [r12+0x180],xmm5
    74a37e5042e0:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    74a37e5042ea:	movdqa xmm1,xmm2
    74a37e5042ee:	pshufd xmm1,xmm1,0x44
    74a37e5042f3:	mulpd  xmm0,xmm1
    74a37e5042f7:	movdqa xmm14,xmm0
    74a37e5042fc:	movdqu xmm15,XMMWORD PTR [rip+0x834b]        # 0x74a37e50c650
    74a37e504305:	pand   xmm14,xmm15
    74a37e50430a:	movdqu xmm15,XMMWORD PTR [rip+0x834d]        # 0x74a37e50c660
    74a37e504313:	pcmpeqq xmm14,xmm15
    74a37e504319:	movdqa xmm15,xmm0
    74a37e50431e:	cmpunordpd xmm15,xmm0
    74a37e504324:	por    xmm14,xmm15
    74a37e504329:	pmovmskb ecx,xmm14
    74a37e50432e:	jrcxz  0x74a37e504335
    74a37e504330:	jmp    0x74a37e505541
    74a37e504335:	movdqa xmm9,xmm0
    74a37e50433a:	movdqu XMMWORD PTR [r12+0x210],xmm9
    74a37e504344:	movdqa xmm0,xmm4
    74a37e504348:	movdqa xmm1,xmm3
    74a37e50434c:	addpd  xmm0,xmm1
    74a37e504350:	movdqa xmm14,xmm0
    74a37e504355:	movdqu xmm15,XMMWORD PTR [rip+0x82f2]        # 0x74a37e50c650
    74a37e50435e:	pand   xmm14,xmm15
    74a37e504363:	movdqu xmm15,XMMWORD PTR [rip+0x82f4]        # 0x74a37e50c660
    74a37e50436c:	pcmpeqq xmm14,xmm15
    74a37e504372:	movdqa xmm15,xmm0
    74a37e504377:	cmpunordpd xmm15,xmm0
    74a37e50437d:	por    xmm14,xmm15
    74a37e504382:	pmovmskb ecx,xmm14
    74a37e504387:	jrcxz  0x74a37e50438e
    74a37e504389:	jmp    0x74a37e50556b
    74a37e50438e:	movdqa xmm10,xmm0
    74a37e504393:	movdqu XMMWORD PTR [r12+0x220],xmm10
    74a37e50439d:	movdqu xmm3,XMMWORD PTR [r12+0x290]
    74a37e5043a7:	movdqa xmm0,xmm3
    74a37e5043ab:	movdqa xmm1,xmm2
    74a37e5043af:	pshufd xmm1,xmm1,0x44
    74a37e5043b4:	mulpd  xmm0,xmm1
    74a37e5043b8:	movdqa xmm14,xmm0
    74a37e5043bd:	movdqu xmm15,XMMWORD PTR [rip+0x828a]        # 0x74a37e50c650
    74a37e5043c6:	pand   xmm14,xmm15
    74a37e5043cb:	movdqu xmm15,XMMWORD PTR [rip+0x828c]        # 0x74a37e50c660
    74a37e5043d4:	pcmpeqq xmm14,xmm15
    74a37e5043da:	movdqa xmm15,xmm0
    74a37e5043df:	cmpunordpd xmm15,xmm0
    74a37e5043e5:	por    xmm14,xmm15
    74a37e5043ea:	pmovmskb ecx,xmm14
    74a37e5043ef:	jrcxz  0x74a37e5043f6
    74a37e5043f1:	jmp    0x74a37e50558f
    74a37e5043f6:	movdqa xmm4,xmm0
    74a37e5043fa:	movdqu XMMWORD PTR [r12+0x230],xmm4
    74a37e504404:	movdqa xmm0,xmm12
    74a37e504409:	movdqa xmm1,xmm8
    74a37e50440e:	addpd  xmm0,xmm1
    74a37e504412:	movdqa xmm14,xmm0
    74a37e504417:	movdqu xmm15,XMMWORD PTR [rip+0x8230]        # 0x74a37e50c650
    74a37e504420:	pand   xmm14,xmm15
    74a37e504425:	movdqu xmm15,XMMWORD PTR [rip+0x8232]        # 0x74a37e50c660
    74a37e50442e:	pcmpeqq xmm14,xmm15
    74a37e504434:	movdqa xmm15,xmm0
    74a37e504439:	cmpunordpd xmm15,xmm0
    74a37e50443f:	por    xmm14,xmm15
    74a37e504444:	pmovmskb ecx,xmm14
    74a37e504449:	jrcxz  0x74a37e504450
    74a37e50444b:	jmp    0x74a37e5055b3
    74a37e504450:	movdqa xmm3,xmm0
    74a37e504454:	movdqu XMMWORD PTR [r12+0x140],xmm3
    74a37e50445e:	movdqu xmm8,XMMWORD PTR [r12+0x1e0]
    74a37e504468:	movdqa xmm0,xmm8
    74a37e50446d:	movdqa xmm1,xmm2
    74a37e504471:	pshufd xmm1,xmm1,0x44
    74a37e504476:	mulpd  xmm0,xmm1
    74a37e50447a:	movdqa xmm14,xmm0
    74a37e50447f:	movdqu xmm15,XMMWORD PTR [rip+0x81c8]        # 0x74a37e50c650
    74a37e504488:	pand   xmm14,xmm15
    74a37e50448d:	movdqu xmm15,XMMWORD PTR [rip+0x81ca]        # 0x74a37e50c660
    74a37e504496:	pcmpeqq xmm14,xmm15
    74a37e50449c:	movdqa xmm15,xmm0
    74a37e5044a1:	cmpunordpd xmm15,xmm0
    74a37e5044a7:	por    xmm14,xmm15
    74a37e5044ac:	pmovmskb ecx,xmm14
    74a37e5044b1:	jrcxz  0x74a37e5044b8
    74a37e5044b3:	jmp    0x74a37e5055d9
    74a37e5044b8:	movdqa xmm11,xmm0
    74a37e5044bd:	movdqu XMMWORD PTR [r12+0x130],xmm11
    74a37e5044c7:	movdqa xmm0,xmm7
    74a37e5044cb:	movdqa xmm1,xmm6
    74a37e5044cf:	addpd  xmm0,xmm1
    74a37e5044d3:	movdqa xmm14,xmm0
    74a37e5044d8:	movdqu xmm15,XMMWORD PTR [rip+0x816f]        # 0x74a37e50c650
    74a37e5044e1:	pand   xmm14,xmm15
    74a37e5044e6:	movdqu xmm15,XMMWORD PTR [rip+0x8171]        # 0x74a37e50c660
    74a37e5044ef:	pcmpeqq xmm14,xmm15
    74a37e5044f5:	movdqa xmm15,xmm0
    74a37e5044fa:	cmpunordpd xmm15,xmm0
    74a37e504500:	por    xmm14,xmm15
    74a37e504505:	pmovmskb ecx,xmm14
    74a37e50450a:	jrcxz  0x74a37e504511
    74a37e50450c:	jmp    0x74a37e5055fe
    74a37e504511:	movdqa xmm2,xmm0
    74a37e504515:	movdqu XMMWORD PTR [r12+0x150],xmm2
    74a37e50451f:	mov    r13,r14
    74a37e504522:	add    r13,0x70
    74a37e504526:	movdqu xmm6,XMMWORD PTR [r13+0x0]
    74a37e50452c:	movdqu XMMWORD PTR [r12+0x240],xmm6
    74a37e504536:	movdqa xmm0,xmm5
    74a37e50453a:	movdqa xmm1,xmm9
    74a37e50453f:	addpd  xmm0,xmm1
    74a37e504543:	movdqa xmm14,xmm0
    74a37e504548:	movdqu xmm15,XMMWORD PTR [rip+0x80ff]        # 0x74a37e50c650
    74a37e504551:	pand   xmm14,xmm15
    74a37e504556:	movdqu xmm15,XMMWORD PTR [rip+0x8101]        # 0x74a37e50c660
    74a37e50455f:	pcmpeqq xmm14,xmm15
    74a37e504565:	movdqa xmm15,xmm0
    74a37e50456a:	cmpunordpd xmm15,xmm0
    74a37e504570:	por    xmm14,xmm15
    74a37e504575:	pmovmskb ecx,xmm14
    74a37e50457a:	jrcxz  0x74a37e504581
    74a37e50457c:	jmp    0x74a37e505622
    74a37e504581:	movdqa xmm7,xmm0
    74a37e504585:	movdqu XMMWORD PTR [r12+0x170],xmm7
    74a37e50458f:	movdqu xmm5,XMMWORD PTR [r12+0x280]
    74a37e504599:	movdqa xmm0,xmm6
    74a37e50459d:	movdqa xmm1,xmm5
    74a37e5045a1:	pshufd xmm1,xmm1,0x44
    74a37e5045a6:	mulpd  xmm0,xmm1
    74a37e5045aa:	movdqa xmm14,xmm0
    74a37e5045af:	movdqu xmm15,XMMWORD PTR [rip+0x8098]        # 0x74a37e50c650
    74a37e5045b8:	pand   xmm14,xmm15
    74a37e5045bd:	movdqu xmm15,XMMWORD PTR [rip+0x809a]        # 0x74a37e50c660
    74a37e5045c6:	pcmpeqq xmm14,xmm15
    74a37e5045cc:	movdqa xmm15,xmm0
    74a37e5045d1:	cmpunordpd xmm15,xmm0
    74a37e5045d7:	por    xmm14,xmm15
    74a37e5045dc:	pmovmskb ecx,xmm14
    74a37e5045e1:	jrcxz  0x74a37e5045e8
    74a37e5045e3:	jmp    0x74a37e505647
    74a37e5045e8:	movdqa xmm8,xmm0
    74a37e5045ed:	movdqu XMMWORD PTR [r12+0x160],xmm8
    74a37e5045f7:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    74a37e504601:	movdqa xmm1,xmm5
    74a37e504605:	pshufd xmm1,xmm1,0x44
    74a37e50460a:	mulpd  xmm0,xmm1
    74a37e50460e:	movdqa xmm14,xmm0
    74a37e504613:	movdqu xmm15,XMMWORD PTR [rip+0x8034]        # 0x74a37e50c650
    74a37e50461c:	pand   xmm14,xmm15
    74a37e504621:	movdqu xmm15,XMMWORD PTR [rip+0x8036]        # 0x74a37e50c660
    74a37e50462a:	pcmpeqq xmm14,xmm15
    74a37e504630:	movdqa xmm15,xmm0
    74a37e504635:	cmpunordpd xmm15,xmm0
    74a37e50463b:	por    xmm14,xmm15
    74a37e504640:	pmovmskb ecx,xmm14
    74a37e504645:	jrcxz  0x74a37e50464c
    74a37e504647:	jmp    0x74a37e50566b
    74a37e50464c:	movdqa xmm6,xmm0
    74a37e504650:	movdqu XMMWORD PTR [r12+0x180],xmm6
    74a37e50465a:	movdqa xmm0,xmm10
    74a37e50465f:	movdqa xmm1,xmm4
    74a37e504663:	addpd  xmm0,xmm1
    74a37e504667:	movdqa xmm14,xmm0
    74a37e50466c:	movdqu xmm15,XMMWORD PTR [rip+0x7fdb]        # 0x74a37e50c650
    74a37e504675:	pand   xmm14,xmm15
    74a37e50467a:	movdqu xmm15,XMMWORD PTR [rip+0x7fdd]        # 0x74a37e50c660
    74a37e504683:	pcmpeqq xmm14,xmm15
    74a37e504689:	movdqa xmm15,xmm0
    74a37e50468e:	cmpunordpd xmm15,xmm0
    74a37e504694:	por    xmm14,xmm15
    74a37e504699:	pmovmskb ecx,xmm14
    74a37e50469e:	jrcxz  0x74a37e5046a5
    74a37e5046a0:	jmp    0x74a37e505695
    74a37e5046a5:	movdqa xmm9,xmm0
    74a37e5046aa:	movdqu XMMWORD PTR [r12+0x210],xmm9
    74a37e5046b4:	mov    r13,r14
    74a37e5046b7:	add    r13,0x10
    74a37e5046bb:	movdqu xmm4,XMMWORD PTR [r14]
    74a37e5046c0:	movdqu xmm10,XMMWORD PTR [r13+0x0]
    74a37e5046c6:	movdqu XMMWORD PTR [r12+0x230],xmm10
    74a37e5046d0:	movdqa xmm0,xmm3
    74a37e5046d4:	movdqa xmm1,xmm11
    74a37e5046d9:	addpd  xmm0,xmm1
    74a37e5046dd:	movdqa xmm14,xmm0
    74a37e5046e2:	movdqu xmm15,XMMWORD PTR [rip+0x7f65]        # 0x74a37e50c650
    74a37e5046eb:	pand   xmm14,xmm15
    74a37e5046f0:	movdqu xmm15,XMMWORD PTR [rip+0x7f67]        # 0x74a37e50c660
    74a37e5046f9:	pcmpeqq xmm14,xmm15
    74a37e5046ff:	movdqa xmm15,xmm0
    74a37e504704:	cmpunordpd xmm15,xmm0
    74a37e50470a:	por    xmm14,xmm15
    74a37e50470f:	pmovmskb ecx,xmm14
    74a37e504714:	jrcxz  0x74a37e50471b
    74a37e504716:	jmp    0x74a37e5056ba
    74a37e50471b:	movdqa xmm12,xmm0
    74a37e504720:	movdqu XMMWORD PTR [r12+0x130],xmm12
    74a37e50472a:	movdqa xmm0,xmm10
    74a37e50472f:	movdqa xmm1,xmm5
    74a37e504733:	pshufd xmm1,xmm1,0x44
    74a37e504738:	mulpd  xmm0,xmm1
    74a37e50473c:	movdqa xmm14,xmm0
    74a37e504741:	movdqu xmm15,XMMWORD PTR [rip+0x7f06]        # 0x74a37e50c650
    74a37e50474a:	pand   xmm14,xmm15
    74a37e50474f:	movdqu xmm15,XMMWORD PTR [rip+0x7f08]        # 0x74a37e50c660
    74a37e504758:	pcmpeqq xmm14,xmm15
    74a37e50475e:	movdqa xmm15,xmm0
    74a37e504763:	cmpunordpd xmm15,xmm0
    74a37e504769:	por    xmm14,xmm15
    74a37e50476e:	pmovmskb ecx,xmm14
    74a37e504773:	jrcxz  0x74a37e50477a
    74a37e504775:	jmp    0x74a37e5056df
    74a37e50477a:	movdqa xmm3,xmm0
    74a37e50477e:	movdqu XMMWORD PTR [r12+0x220],xmm3
    74a37e504788:	movdqa xmm0,xmm4
    74a37e50478c:	movdqa xmm1,xmm5
    74a37e504790:	pshufd xmm1,xmm1,0x44
    74a37e504795:	mulpd  xmm0,xmm1
    74a37e504799:	movdqa xmm14,xmm0
    74a37e50479e:	movdqu xmm15,XMMWORD PTR [rip+0x7ea9]        # 0x74a37e50c650
    74a37e5047a7:	pand   xmm14,xmm15
    74a37e5047ac:	movdqu xmm15,XMMWORD PTR [rip+0x7eab]        # 0x74a37e50c660
    74a37e5047b5:	pcmpeqq xmm14,xmm15
    74a37e5047bb:	movdqa xmm15,xmm0
    74a37e5047c0:	cmpunordpd xmm15,xmm0
    74a37e5047c6:	por    xmm14,xmm15
    74a37e5047cb:	pmovmskb ecx,xmm14
    74a37e5047d0:	jrcxz  0x74a37e5047d7
    74a37e5047d2:	jmp    0x74a37e505704
    74a37e5047d7:	movdqa xmm10,xmm0
    74a37e5047dc:	movdqa xmm0,xmm2
    74a37e5047e0:	movdqa xmm1,xmm8
    74a37e5047e5:	addpd  xmm0,xmm1
    74a37e5047e9:	movdqa xmm14,xmm0
    74a37e5047ee:	movdqu xmm15,XMMWORD PTR [rip+0x7e59]        # 0x74a37e50c650
    74a37e5047f7:	pand   xmm14,xmm15
    74a37e5047fc:	movdqu xmm15,XMMWORD PTR [rip+0x7e5b]        # 0x74a37e50c660
    74a37e504805:	pcmpeqq xmm14,xmm15
    74a37e50480b:	movdqa xmm15,xmm0
    74a37e504810:	cmpunordpd xmm15,xmm0
    74a37e504816:	por    xmm14,xmm15
    74a37e50481b:	pmovmskb ecx,xmm14
    74a37e504820:	jrcxz  0x74a37e504827
    74a37e504822:	jmp    0x74a37e505728
    74a37e504827:	movdqa xmm4,xmm0
    74a37e50482b:	movdqu XMMWORD PTR [r12+0x140],xmm4
    74a37e504835:	movdqa xmm0,xmm7
    74a37e504839:	movdqa xmm1,xmm6
    74a37e50483d:	addpd  xmm0,xmm1
    74a37e504841:	movdqa xmm14,xmm0
    74a37e504846:	movdqu xmm15,XMMWORD PTR [rip+0x7e01]        # 0x74a37e50c650
    74a37e50484f:	pand   xmm14,xmm15
    74a37e504854:	movdqu xmm15,XMMWORD PTR [rip+0x7e03]        # 0x74a37e50c660
    74a37e50485d:	pcmpeqq xmm14,xmm15
    74a37e504863:	movdqa xmm15,xmm0
    74a37e504868:	cmpunordpd xmm15,xmm0
    74a37e50486e:	por    xmm14,xmm15
    74a37e504873:	pmovmskb ecx,xmm14
    74a37e504878:	jrcxz  0x74a37e50487f
    74a37e50487a:	jmp    0x74a37e50574d
    74a37e50487f:	movdqa xmm2,xmm0
    74a37e504883:	movdqu XMMWORD PTR [r12+0x150],xmm2
    74a37e50488d:	movdqa xmm0,xmm9
    74a37e504892:	movdqa xmm1,xmm3
    74a37e504896:	addpd  xmm0,xmm1
    74a37e50489a:	movdqa xmm14,xmm0
    74a37e50489f:	movdqu xmm15,XMMWORD PTR [rip+0x7da8]        # 0x74a37e50c650
    74a37e5048a8:	pand   xmm14,xmm15
    74a37e5048ad:	movdqu xmm15,XMMWORD PTR [rip+0x7daa]        # 0x74a37e50c660
    74a37e5048b6:	pcmpeqq xmm14,xmm15
    74a37e5048bc:	movdqa xmm15,xmm0
    74a37e5048c1:	cmpunordpd xmm15,xmm0
    74a37e5048c7:	por    xmm14,xmm15
    74a37e5048cc:	pmovmskb ecx,xmm14
    74a37e5048d1:	jrcxz  0x74a37e5048d8
    74a37e5048d3:	jmp    0x74a37e505771
    74a37e5048d8:	movdqa xmm5,xmm0
    74a37e5048dc:	movdqu XMMWORD PTR [r12+0x160],xmm5
    74a37e5048e6:	movdqa xmm0,xmm12
    74a37e5048eb:	movdqa xmm1,xmm10
    74a37e5048f0:	addpd  xmm0,xmm1
    74a37e5048f4:	movdqa xmm14,xmm0
    74a37e5048f9:	movdqu xmm15,XMMWORD PTR [rip+0x7d4e]        # 0x74a37e50c650
    74a37e504902:	pand   xmm14,xmm15
    74a37e504907:	movdqu xmm15,XMMWORD PTR [rip+0x7d50]        # 0x74a37e50c660
    74a37e504910:	pcmpeqq xmm14,xmm15
    74a37e504916:	movdqa xmm15,xmm0
    74a37e50491b:	cmpunordpd xmm15,xmm0
    74a37e504921:	por    xmm14,xmm15
    74a37e504926:	pmovmskb ecx,xmm14
    74a37e50492b:	jrcxz  0x74a37e504932
    74a37e50492d:	jmp    0x74a37e505796
    74a37e504932:	movdqa xmm3,xmm0
    74a37e504936:	movdqu XMMWORD PTR [r12+0x120],xmm3
    74a37e504940:	mov    r13,r15
    74a37e504943:	add    r13,0x10
    74a37e504947:	movdqu XMMWORD PTR [r15],xmm4
    74a37e50494c:	mov    r14d,0x0
    74a37e504952:	mov    DWORD PTR [r12+0x32c],r14d
    74a37e50495a:	movdqu XMMWORD PTR [r13+0x0],xmm2
    74a37e504960:	add    r15,0x20
    74a37e504964:	mov    r13,r15
    74a37e504967:	add    r13,0x10
    74a37e50496b:	movdqu XMMWORD PTR [r15],xmm5
    74a37e504970:	movdqu XMMWORD PTR [r13+0x0],xmm3
    74a37e504976:	mov    rcx,QWORD PTR [r12+0x380]
    74a37e50497e:	jrcxz  0x74a37e504985
    74a37e504980:	jmp    0x74a37e50bd1d
    74a37e504985:	cmp    BYTE PTR [rsp+0x8],0x0
    74a37e50498a:	jne    0x74a37e502c55
    74a37e504990:	jmp    0x74a37e504995
    74a37e504995:	mov    r13d,DWORD PTR [r12+0x48]
    74a37e50499a:	add    r13d,0x1
    74a37e50499e:	mov    QWORD PTR [r12+0x48],r13
    74a37e5049a3:	sub    r13d,0x1f4
    74a37e5049aa:	mov    rcx,QWORD PTR [r12+0x380]
    74a37e5049b2:	jrcxz  0x74a37e5049b9
    74a37e5049b4:	jmp    0x74a37e50bda2
    74a37e5049b9:	jne    0x74a37e502c37
    74a37e5049bf:	mov    r11,rax
    74a37e5049c2:	lahf
    74a37e5049c3:	seto   al
    74a37e5049c6:	mov    WORD PTR [rsp],ax
    74a37e5049ca:	mov    rax,r11
    74a37e5049cd:	jmp    0x74a37e5049d2
    74a37e5049d2:	mov    r13d,0x430000
    74a37e5049d8:	mov    QWORD PTR [r12+0x40],r13
    74a37e5049dd:	mov    r13d,0x0
    74a37e5049e3:	mov    QWORD PTR [r12+0x48],r13
    74a37e5049e8:	mov    r13d,0x430cc0
    74a37e5049ee:	mov    r14,QWORD PTR [r13+0x0]
    74a37e5049f2:	mov    r13d,0x0
    74a37e5049f8:	mov    QWORD PTR [r12+0x110],r14
    74a37e504a00:	mov    QWORD PTR [r12+0x118],r13
    74a37e504a08:	jmp    0x74a37e504a0d
    74a37e504a0d:	mov    r13,QWORD PTR [r12+0x48]
    74a37e504a12:	mov    r14,QWORD PTR [r12+0x50]
    74a37e504a17:	add    r14,r13
    74a37e504a1a:	movdqu xmm2,XMMWORD PTR [r14]
    74a37e504a1f:	movdqu XMMWORD PTR [r12+0x120],xmm2
    74a37e504a29:	add    r13,0x10
    74a37e504a2d:	mov    QWORD PTR [r12+0x48],r13
    74a37e504a32:	sub    r13,0x200
    74a37e504a39:	mov    r13,QWORD PTR [r12+0x128]
    74a37e504a41:	mov    r14d,0x0
    74a37e504a47:	mov    QWORD PTR [r12+0x130],r13
    74a37e504a4f:	mov    QWORD PTR [r12+0x138],r14
    74a37e504a57:	movdqu xmm2,XMMWORD PTR [r12+0x110]
    74a37e504a61:	movdqu xmm3,XMMWORD PTR [r12+0x120]
    74a37e504a6b:	movdqa xmm0,xmm2
    74a37e504a6f:	movdqa xmm1,xmm3
    74a37e504a73:	movq   xmm0,xmm0
    74a37e504a77:	movq   xmm1,xmm1
    74a37e504a7b:	addsd  xmm0,xmm1
    74a37e504a7f:	movdqa xmm14,xmm0
    74a37e504a84:	movdqu xmm15,XMMWORD PTR [rip+0x7bc3]        # 0x74a37e50c650
    74a37e504a8d:	pand   xmm14,xmm15
    74a37e504a92:	movdqu xmm15,XMMWORD PTR [rip+0x7bc5]        # 0x74a37e50c660
    74a37e504a9b:	pcmpeqq xmm14,xmm15
    74a37e504aa1:	movdqa xmm15,xmm0
    74a37e504aa6:	cmpunordpd xmm15,xmm0
    74a37e504aac:	por    xmm14,xmm15
    74a37e504ab1:	pmovmskb ecx,xmm14
    74a37e504ab6:	jrcxz  0x74a37e504abd
    74a37e504ab8:	jmp    0x74a37e5057bc
    74a37e504abd:	movdqa xmm4,xmm0
    74a37e504ac1:	movdqu xmm2,XMMWORD PTR [r12+0x130]
    74a37e504acb:	movdqa xmm0,xmm4
    74a37e504acf:	movdqa xmm1,xmm2
    74a37e504ad3:	movq   xmm0,xmm0
    74a37e504ad7:	movq   xmm1,xmm1
    74a37e504adb:	addsd  xmm0,xmm1
    74a37e504adf:	movdqa xmm14,xmm0
    74a37e504ae4:	movdqu xmm15,XMMWORD PTR [rip+0x7b63]        # 0x74a37e50c650
    74a37e504aed:	pand   xmm14,xmm15
    74a37e504af2:	movdqu xmm15,XMMWORD PTR [rip+0x7b65]        # 0x74a37e50c660
    74a37e504afb:	pcmpeqq xmm14,xmm15
    74a37e504b01:	movdqa xmm15,xmm0
    74a37e504b06:	cmpunordpd xmm15,xmm0
    74a37e504b0c:	por    xmm14,xmm15
    74a37e504b11:	pmovmskb ecx,xmm14
    74a37e504b16:	jrcxz  0x74a37e504b1d
    74a37e504b18:	jmp    0x74a37e5057fb
    74a37e504b1d:	movdqa xmm3,xmm0
    74a37e504b21:	movdqu XMMWORD PTR [r12+0x110],xmm3
    74a37e504b2b:	mov    rcx,QWORD PTR [r12+0x380]
    74a37e504b33:	jrcxz  0x74a37e504b3a
    74a37e504b35:	jmp    0x74a37e50be36
    74a37e504b3a:	jne    0x74a37e504b53
    74a37e504b40:	mov    r11,rax
    74a37e504b43:	lahf
    74a37e504b44:	seto   al
    74a37e504b47:	mov    WORD PTR [rsp],ax
    74a37e504b4b:	mov    rax,r11
    74a37e504b4e:	jmp    0x74a37e504b66
    74a37e504b53:	mov    r11,rax
    74a37e504b56:	lahf
    74a37e504b57:	seto   al
    74a37e504b5a:	mov    WORD PTR [rsp],ax
    74a37e504b5e:	mov    rax,r11
    74a37e504b61:	jmp    0x74a37e504a0d
    74a37e504b66:	mov    r13,QWORD PTR [r12+0xf8]
    74a37e504b6e:	mov    r14,r13
    74a37e504b71:	add    r14,0x1d0
    74a37e504b78:	mov    r15,r14
    74a37e504b7b:	add    r15,0x8
    74a37e504b7f:	mov    rbp,QWORD PTR [r14]
    74a37e504b82:	mov    r14,QWORD PTR [r15]
    74a37e504b85:	mov    QWORD PTR [r12+0xa0],rbp
    74a37e504b8d:	mov    QWORD PTR [r12+0x98],r14
    74a37e504b95:	mov    r14,QWORD PTR [r12+0x40]
    74a37e504b9a:	add    r14,0xcc0
    74a37e504ba1:	mov    r15,QWORD PTR [r12+0x110]
    74a37e504ba9:	mov    QWORD PTR [r14],r15
    74a37e504bac:	mov    r14d,0x0
    74a37e504bb2:	mov    DWORD PTR [r12+0x32c],r14d
    74a37e504bba:	mov    r14,r13
    74a37e504bbd:	add    r14,0x1c0
    74a37e504bc4:	mov    r15,r14
    74a37e504bc7:	add    r15,0x8
    74a37e504bcb:	mov    rbp,QWORD PTR [r14]
    74a37e504bce:	mov    r14,QWORD PTR [r15]
    74a37e504bd1:	mov    QWORD PTR [r12+0xe8],rbp
    74a37e504bd9:	mov    QWORD PTR [r12+0xf0],r14
    74a37e504be1:	mov    r14,r13
    74a37e504be4:	add    r14,0x1b0
    74a37e504beb:	mov    r15,r14
    74a37e504bee:	add    r15,0x8
    74a37e504bf2:	mov    rbp,QWORD PTR [r14]
    74a37e504bf5:	mov    r14,QWORD PTR [r15]
    74a37e504bf8:	mov    r15d,0x0
    74a37e504bfe:	mov    QWORD PTR [r12+0x1a0],rbp
    74a37e504c06:	mov    QWORD PTR [r12+0x1a8],r15
    74a37e504c0e:	mov    r15d,0x0
    74a37e504c14:	mov    QWORD PTR [r12+0x190],r14
    74a37e504c1c:	mov    QWORD PTR [r12+0x198],r15
    74a37e504c24:	mov    r14,r13
    74a37e504c27:	add    r14,0x1a0
    74a37e504c2e:	mov    r15,r14
    74a37e504c31:	add    r15,0x8
    74a37e504c35:	mov    rbp,QWORD PTR [r14]
    74a37e504c38:	mov    r14,QWORD PTR [r15]
    74a37e504c3b:	mov    r15d,0x0
    74a37e504c41:	mov    QWORD PTR [r12+0x1c0],rbp
    74a37e504c49:	mov    QWORD PTR [r12+0x1c8],r15
    74a37e504c51:	mov    r15d,0x0
    74a37e504c57:	mov    QWORD PTR [r12+0x1b0],r14
    74a37e504c5f:	mov    QWORD PTR [r12+0x1b8],r15
    74a37e504c67:	mov    r14,r13
    74a37e504c6a:	add    r14,0x190
    74a37e504c71:	mov    r15,r14
    74a37e504c74:	add    r15,0x8
    74a37e504c78:	mov    rbp,QWORD PTR [r14]
    74a37e504c7b:	mov    r14,QWORD PTR [r15]
    74a37e504c7e:	mov    r15d,0x0
    74a37e504c84:	mov    QWORD PTR [r12+0x1e0],rbp
    74a37e504c8c:	mov    QWORD PTR [r12+0x1e8],r15
    74a37e504c94:	mov    r15d,0x0
    74a37e504c9a:	mov    QWORD PTR [r12+0x1d0],r14
    74a37e504ca2:	mov    QWORD PTR [r12+0x1d8],r15
    74a37e504caa:	mov    r14,r13
    74a37e504cad:	add    r14,0x180
    74a37e504cb4:	mov    r15,r14
    74a37e504cb7:	add    r15,0x8
    74a37e504cbb:	mov    rbp,QWORD PTR [r14]
    74a37e504cbe:	mov    r14,QWORD PTR [r15]
    74a37e504cc1:	mov    r15d,0x0
    74a37e504cc7:	mov    QWORD PTR [r12+0x200],rbp
    74a37e504ccf:	mov    QWORD PTR [r12+0x208],r15
    74a37e504cd7:	mov    r15d,0x0
    74a37e504cdd:	mov    QWORD PTR [r12+0x1f0],r14
    74a37e504ce5:	mov    QWORD PTR [r12+0x1f8],r15
    74a37e504ced:	add    r13,0x1e0
    74a37e504cf4:	mov    QWORD PTR [r12+0xf8],r13
    74a37e504cfc:	mov    rcx,QWORD PTR [r12+0x380]
    74a37e504d04:	jrcxz  0x74a37e504d0b
    74a37e504d06:	jmp    0x74a37e50beca
    74a37e504d0b:	mov    r13,QWORD PTR [r12+0xf0]
    74a37e504d13:	mov    QWORD PTR [r12+0x100],r13
    74a37e504d1b:	mov    r11,QWORD PTR [rsp]
    74a37e504d1f:	mov    QWORD PTR [r12+0x398],r11
    74a37e504d27:	mov    rdi,QWORD PTR [r12+0x100]
    74a37e504d2f:	add    rsp,0x150
    74a37e504d36:	movabs r11,0x5715466e9940
    74a37e504d40:	jmp    r11
    74a37e504d43:	mov    r13d,DWORD PTR [r12+0x98]
    74a37e504d4b:	mov    r14d,DWORD PTR [r12]
    74a37e504d4f:	add    r14d,r13d
    74a37e504d52:	mov    QWORD PTR [r12],r14
    74a37e504d56:	mov    r13d,0x4103f8
    74a37e504d5c:	mov    QWORD PTR [r12+0xf0],r13
    74a37e504d64:	mov    r13d,0x4109a4
    74a37e504d6a:	mov    QWORD PTR [r12+0x100],r13
    74a37e504d72:	mov    r11,QWORD PTR [rsp]
    74a37e504d76:	mov    QWORD PTR [r12+0x398],r11
    74a37e504d7e:	mov    edi,0x4109a4
    74a37e504d83:	mov    QWORD PTR [r12+0x100],rdi
    74a37e504d8b:	add    rsp,0x150
    74a37e504d92:	nop    WORD PTR [rax+rax*1+0x0]
    74a37e504d98:	jmp    QWORD PTR [rip+0x2]        # 0x74a37e504da0
    74a37e504d9e:	xchg   ax,ax
    74a37e504da0:	rex (bad)
    74a37e504da2:	push   rax
    74a37e504da3:	jle    0x74a37e504d48
    74a37e504da5:	je     0x74a37e504da7
    74a37e504da7:	add    BYTE PTR [rax-0x5c81afb3],dh
    74a37e504dad:	je     0x74a37e504daf
    74a37e504daf:	add    BYTE PTR [rcx-0x45],cl
    74a37e504db2:	rex cdq
    74a37e504db4:	outs   dx,BYTE PTR ds:[rsi]
    74a37e504db5:	rex.RX adc eax,0x41000057
    74a37e504dbb:	jmp    rbx
    74a37e504dbd:	movdqa xmm0,xmm2
    74a37e504dc1:	movdqa xmm1,xmm3
    74a37e504dc5:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e504dce:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e504dd7:	call   0x74a37e505840
    74a37e504ddc:	jmp    0x74a37e50274c
    74a37e504de1:	movdqa xmm0,xmm2
    74a37e504de5:	movdqa xmm1,xmm3
    74a37e504de9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e504df2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e504dfb:	call   0x74a37e505840
    74a37e504e00:	jmp    0x74a37e5027d8
    74a37e504e05:	movdqa xmm0,xmm9
    74a37e504e0a:	movdqa xmm1,xmm2
    74a37e504e0e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e504e17:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e504e20:	call   0x74a37e505910
    74a37e504e25:	jmp    0x74a37e502e73
    74a37e504e2a:	movdqa xmm0,xmm8
    74a37e504e2f:	movdqa xmm1,xmm2
    74a37e504e33:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e504e3c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e504e45:	call   0x74a37e505a20
    74a37e504e4a:	jmp    0x74a37e502ed2
    74a37e504e4f:	movdqa xmm0,xmm9
    74a37e504e54:	movdqa xmm1,xmm7
    74a37e504e58:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e504e61:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e504e6a:	call   0x74a37e505b40
    74a37e504e6f:	jmp    0x74a37e502f47
    74a37e504e74:	movdqa xmm0,xmm9
    74a37e504e79:	movdqa xmm1,xmm6
    74a37e504e7d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e504e86:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e504e8f:	call   0x74a37e505c60
    74a37e504e94:	jmp    0x74a37e502f97
    74a37e504e99:	movdqa xmm0,xmm9
    74a37e504e9e:	movdqa xmm1,xmm6
    74a37e504ea2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e504eab:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e504eb4:	call   0x74a37e505d80
    74a37e504eb9:	jmp    0x74a37e502ff0
    74a37e504ebe:	movdqa xmm0,xmm9
    74a37e504ec3:	movdqa xmm1,xmm2
    74a37e504ec7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e504ed0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e504ed9:	call   0x74a37e505eb0
    74a37e504ede:	jmp    0x74a37e503091
    74a37e504ee3:	mov    r11,rax
    74a37e504ee6:	lahf
    74a37e504ee7:	seto   al
    74a37e504eea:	mov    WORD PTR [rsp],ax
    74a37e504eee:	mov    rax,r11
    74a37e504ef1:	movdqa xmm0,xmm10
    74a37e504ef6:	movdqa xmm1,xmm9
    74a37e504efb:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e504f04:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e504f0d:	call   0x74a37e505ff0
    74a37e504f12:	mov    r11,rax
    74a37e504f15:	movzx  eax,WORD PTR [rsp]
    74a37e504f19:	add    al,0x7f
    74a37e504f1b:	sahf
    74a37e504f1c:	mov    rax,r11
    74a37e504f1f:	jmp    0x74a37e5030fc
    74a37e504f24:	mov    r11,rax
    74a37e504f27:	lahf
    74a37e504f28:	seto   al
    74a37e504f2b:	mov    WORD PTR [rsp],ax
    74a37e504f2f:	mov    rax,r11
    74a37e504f32:	movdqa xmm0,xmm8
    74a37e504f37:	movdqa xmm1,xmm10
    74a37e504f3c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e504f45:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e504f4e:	call   0x74a37e505ff0
    74a37e504f53:	mov    r11,rax
    74a37e504f56:	movzx  eax,WORD PTR [rsp]
    74a37e504f5a:	add    al,0x7f
    74a37e504f5c:	sahf
    74a37e504f5d:	mov    rax,r11
    74a37e504f60:	jmp    0x74a37e50315c
    74a37e504f65:	mov    r11,rax
    74a37e504f68:	lahf
    74a37e504f69:	seto   al
    74a37e504f6c:	mov    WORD PTR [rsp],ax
    74a37e504f70:	mov    rax,r11
    74a37e504f73:	movdqa xmm0,xmm7
    74a37e504f77:	movdqa xmm1,xmm10
    74a37e504f7c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e504f85:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e504f8e:	call   0x74a37e5061c0
    74a37e504f93:	mov    r11,rax
    74a37e504f96:	movzx  eax,WORD PTR [rsp]
    74a37e504f9a:	add    al,0x7f
    74a37e504f9c:	sahf
    74a37e504f9d:	mov    rax,r11
    74a37e504fa0:	jmp    0x74a37e5031b5
    74a37e504fa5:	movdqa xmm0,xmm12
    74a37e504faa:	movdqa xmm1,xmm9
    74a37e504faf:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e504fb8:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e504fc1:	call   0x74a37e506380
    74a37e504fc6:	jmp    0x74a37e50332d
    74a37e504fcb:	movdqa xmm0,xmm6
    74a37e504fcf:	movdqa xmm1,xmm4
    74a37e504fd3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e504fdc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e504fe5:	call   0x74a37e506580
    74a37e504fea:	jmp    0x74a37e50339b
    74a37e504fef:	movdqa xmm0,xmm8
    74a37e504ff4:	movdqa xmm1,xmm11
    74a37e504ff9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e505002:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e50500b:	call   0x74a37e506770
    74a37e505010:	jmp    0x74a37e5033f6
    74a37e505015:	movdqa xmm0,xmm5
    74a37e505019:	movdqa xmm1,xmm2
    74a37e50501d:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e505026:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e50502f:	call   0x74a37e506960
    74a37e505034:	jmp    0x74a37e503453
    74a37e505039:	movdqa xmm0,xmm9
    74a37e50503e:	movdqa xmm1,xmm5
    74a37e505042:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e50504b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e505054:	call   0x74a37e506b30
    74a37e505059:	jmp    0x74a37e5034bb
    74a37e50505e:	movdqa xmm0,xmm13
    74a37e505063:	movdqa xmm1,xmm2
    74a37e505067:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e505070:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e505079:	call   0x74a37e506d10
    74a37e50507e:	jmp    0x74a37e503534
    74a37e505083:	movdqa xmm0,xmm9
    74a37e505088:	movdqa xmm1,xmm5
    74a37e50508c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e505095:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e50509e:	call   0x74a37e506f00
    74a37e5050a3:	jmp    0x74a37e5035c1
    74a37e5050a8:	movdqu xmm0,XMMWORD PTR [r12+0x240]
    74a37e5050b2:	movdqa xmm1,xmm6
    74a37e5050b6:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e5050bf:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e5050c8:	call   0x74a37e5070c0
    74a37e5050cd:	jmp    0x74a37e5036b6
    74a37e5050d2:	movdqa xmm0,xmm9
    74a37e5050d7:	movdqa xmm1,xmm5
    74a37e5050db:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e5050e4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e5050ed:	call   0x74a37e5072a0
    74a37e5050f2:	jmp    0x74a37e503714
    74a37e5050f7:	movdqu xmm0,XMMWORD PTR [r12+0x180]
    74a37e505101:	movdqa xmm1,xmm11
    74a37e505106:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e50510f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e505118:	call   0x74a37e507480
    74a37e50511d:	jmp    0x74a37e50378d
    74a37e505122:	movdqa xmm0,xmm12
    74a37e505127:	movdqa xmm1,xmm8
    74a37e50512c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e505135:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e50513e:	call   0x74a37e507670
    74a37e505143:	jmp    0x74a37e5037e8
    74a37e505148:	movdqa xmm0,xmm9
    74a37e50514d:	movdqa xmm1,xmm5
    74a37e505151:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e50515a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e505163:	call   0x74a37e507860
    74a37e505168:	jmp    0x74a37e503869
    74a37e50516d:	movdqa xmm0,xmm4
    74a37e505171:	movdqa xmm1,xmm2
    74a37e505175:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e50517e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e505187:	call   0x74a37e507a40
    74a37e50518c:	jmp    0x74a37e5038dc
    74a37e505191:	movdqa xmm0,xmm13
    74a37e505196:	movdqa xmm1,xmm2
    74a37e50519a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e5051a3:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e5051ac:	call   0x74a37e507c20
    74a37e5051b1:	jmp    0x74a37e503945
    74a37e5051b6:	movdqa xmm0,xmm5
    74a37e5051ba:	movdqa xmm1,xmm2
    74a37e5051be:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e5051c7:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e5051d0:	call   0x74a37e507e00
    74a37e5051d5:	jmp    0x74a37e5039bd
    74a37e5051da:	movdqa xmm0,xmm3
    74a37e5051de:	movdqa xmm1,xmm6
    74a37e5051e2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e5051eb:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e5051f4:	call   0x74a37e507fe0
    74a37e5051f9:	jmp    0x74a37e503a30
    74a37e5051fe:	movdqa xmm0,xmm5
    74a37e505202:	movdqa xmm1,xmm2
    74a37e505206:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e50520f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e505218:	call   0x74a37e5081d0
    74a37e50521d:	jmp    0x74a37e503ad2
    74a37e505222:	movdqa xmm0,xmm10
    74a37e505227:	movdqa xmm1,xmm12
    74a37e50522c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e505235:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e50523e:	call   0x74a37e5083c0
    74a37e505243:	jmp    0x74a37e503b43
    74a37e505248:	movdqa xmm0,xmm7
    74a37e50524c:	movdqa xmm1,xmm2
    74a37e505250:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e505259:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e505262:	call   0x74a37e5085c0
    74a37e505267:	jmp    0x74a37e503b96
    74a37e50526c:	movdqa xmm0,xmm11
    74a37e505271:	movdqa xmm1,xmm13
    74a37e505276:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e50527f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e505288:	call   0x74a37e5087a0
    74a37e50528d:	jmp    0x74a37e503be7
    74a37e505292:	movdqa xmm0,xmm5
    74a37e505296:	movdqa xmm1,xmm7
    74a37e50529a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e5052a3:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e5052ac:	call   0x74a37e508980
    74a37e5052b1:	jmp    0x74a37e503c44
    74a37e5052b6:	movdqu xmm0,XMMWORD PTR [r12+0x300]
    74a37e5052c0:	movdqa xmm1,xmm7
    74a37e5052c4:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e5052cd:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e5052d6:	call   0x74a37e508b50
    74a37e5052db:	jmp    0x74a37e503c9e
    74a37e5052e0:	movdqa xmm0,xmm8
    74a37e5052e5:	movdqa xmm1,xmm4
    74a37e5052e9:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e5052f2:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e5052fb:	call   0x74a37e508d20
    74a37e505300:	jmp    0x74a37e503ced
    74a37e505305:	movdqa xmm0,xmm9
    74a37e50530a:	movdqa xmm1,xmm6
    74a37e50530e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e505317:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e505320:	call   0x74a37e508f00
    74a37e505325:	jmp    0x74a37e503d47
    74a37e50532a:	movdqu xmm0,XMMWORD PTR [r12+0x2e0]
    74a37e505334:	movdqa xmm1,xmm7
    74a37e505338:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e505341:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e50534a:	call   0x74a37e5090d0
    74a37e50534f:	jmp    0x74a37e503daa
    74a37e505354:	movdqu xmm0,XMMWORD PTR [r12+0x2f0]
    74a37e50535e:	movdqa xmm1,xmm7
    74a37e505362:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e50536b:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e505374:	call   0x74a37e509290
    74a37e505379:	jmp    0x74a37e503e03
    74a37e50537e:	movdqa xmm0,xmm3
    74a37e505382:	movdqa xmm1,xmm10
    74a37e505387:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e505390:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e505399:	call   0x74a37e509460
    74a37e50539e:	jmp    0x74a37e503e5d
    74a37e5053a3:	movdqa xmm0,xmm2
    74a37e5053a7:	movdqa xmm1,xmm11
    74a37e5053ac:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e5053b5:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e5053be:	call   0x74a37e509630
    74a37e5053c3:	jmp    0x74a37e503eb6
    74a37e5053c8:	movdqu xmm0,XMMWORD PTR [r12+0x270]
    74a37e5053d2:	movdqa xmm1,xmm2
    74a37e5053d6:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e5053df:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e5053e8:	call   0x74a37e5097f0
    74a37e5053ed:	jmp    0x74a37e503f23
    74a37e5053f2:	movdqa xmm0,xmm4
    74a37e5053f6:	movdqa xmm1,xmm5
    74a37e5053fa:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e505403:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e50540c:	call   0x74a37e5099a0
    74a37e505411:	jmp    0x74a37e503f7c
    74a37e505416:	movdqa xmm0,xmm12
    74a37e50541b:	movdqa xmm1,xmm6
    74a37e50541f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e505428:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e505431:	call   0x74a37e509b70
    74a37e505436:	jmp    0x74a37e503fd6
    74a37e50543b:	movdqu xmm0,XMMWORD PTR [r12+0x190]
    74a37e505445:	movdqa xmm1,xmm2
    74a37e505449:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e505452:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e50545b:	call   0x74a37e508980
    74a37e505460:	jmp    0x74a37e5040b6
    74a37e505465:	movdqa xmm0,xmm7
    74a37e505469:	movdqa xmm1,xmm8
    74a37e50546e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e505477:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e505480:	call   0x74a37e508d20
    74a37e505485:	jmp    0x74a37e504106
    74a37e50548a:	movdqa xmm0,xmm3
    74a37e50548e:	movdqa xmm1,xmm9
    74a37e505493:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e50549c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e5054a5:	call   0x74a37e509d30
    74a37e5054aa:	jmp    0x74a37e504156
    74a37e5054af:	movdqa xmm0,xmm6
    74a37e5054b3:	movdqa xmm1,xmm2
    74a37e5054b7:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e5054c0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e5054c9:	call   0x74a37e509f00
    74a37e5054ce:	jmp    0x74a37e5041b3
    74a37e5054d3:	movdqa xmm0,xmm6
    74a37e5054d7:	movdqa xmm1,xmm2
    74a37e5054db:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e5054e4:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e5054ed:	call   0x74a37e509290
    74a37e5054f2:	jmp    0x74a37e50421a
    74a37e5054f7:	movdqa xmm0,xmm5
    74a37e5054fb:	movdqa xmm1,xmm2
    74a37e5054ff:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e505508:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e505511:	call   0x74a37e50a0c0
    74a37e505516:	jmp    0x74a37e504278
    74a37e50551b:	movdqa xmm0,xmm10
    74a37e505520:	movdqa xmm1,xmm11
    74a37e505525:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e50552e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e505537:	call   0x74a37e50a290
    74a37e50553c:	jmp    0x74a37e5042d2
    74a37e505541:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    74a37e50554b:	movdqa xmm1,xmm2
    74a37e50554f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e505558:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e505561:	call   0x74a37e5097f0
    74a37e505566:	jmp    0x74a37e504335
    74a37e50556b:	movdqa xmm0,xmm4
    74a37e50556f:	movdqa xmm1,xmm3
    74a37e505573:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e50557c:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e505585:	call   0x74a37e5099a0
    74a37e50558a:	jmp    0x74a37e50438e
    74a37e50558f:	movdqa xmm0,xmm3
    74a37e505593:	movdqa xmm1,xmm2
    74a37e505597:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e5055a0:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e5055a9:	call   0x74a37e50a460
    74a37e5055ae:	jmp    0x74a37e5043f6
    74a37e5055b3:	movdqa xmm0,xmm12
    74a37e5055b8:	movdqa xmm1,xmm8
    74a37e5055bd:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e5055c6:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e5055cf:	call   0x74a37e50a630
    74a37e5055d4:	jmp    0x74a37e504450
    74a37e5055d9:	movdqa xmm0,xmm8
    74a37e5055de:	movdqa xmm1,xmm2
    74a37e5055e2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e5055eb:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e5055f4:	call   0x74a37e508980
    74a37e5055f9:	jmp    0x74a37e5044b8
    74a37e5055fe:	movdqa xmm0,xmm7
    74a37e505602:	movdqa xmm1,xmm6
    74a37e505606:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e50560f:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e505618:	call   0x74a37e50a800
    74a37e50561d:	jmp    0x74a37e504511
    74a37e505622:	movdqa xmm0,xmm5
    74a37e505626:	movdqa xmm1,xmm9
    74a37e50562b:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e505634:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e50563d:	call   0x74a37e50a9c0
    74a37e505642:	jmp    0x74a37e504581
    74a37e505647:	movdqa xmm0,xmm6
    74a37e50564b:	movdqa xmm1,xmm5
    74a37e50564f:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e505658:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e505661:	call   0x74a37e50ab80
    74a37e505666:	jmp    0x74a37e5045e8
    74a37e50566b:	movdqu xmm0,XMMWORD PTR [r12+0x1c0]
    74a37e505675:	movdqa xmm1,xmm5
    74a37e505679:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e505682:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e50568b:	call   0x74a37e50ad30
    74a37e505690:	jmp    0x74a37e50464c
    74a37e505695:	movdqa xmm0,xmm10
    74a37e50569a:	movdqa xmm1,xmm4
    74a37e50569e:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e5056a7:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e5056b0:	call   0x74a37e50aef0
    74a37e5056b5:	jmp    0x74a37e5046a5
    74a37e5056ba:	movdqa xmm0,xmm3
    74a37e5056be:	movdqa xmm1,xmm11
    74a37e5056c3:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e5056cc:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e5056d5:	call   0x74a37e508d20
    74a37e5056da:	jmp    0x74a37e50471b
    74a37e5056df:	movdqa xmm0,xmm10
    74a37e5056e4:	movdqa xmm1,xmm5
    74a37e5056e8:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e5056f1:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e5056fa:	call   0x74a37e50b0c0
    74a37e5056ff:	jmp    0x74a37e50477a
    74a37e505704:	movdqa xmm0,xmm4
    74a37e505708:	movdqa xmm1,xmm5
    74a37e50570c:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e505715:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e50571e:	call   0x74a37e50b290
    74a37e505723:	jmp    0x74a37e5047d7
    74a37e505728:	movdqa xmm0,xmm2
    74a37e50572c:	movdqa xmm1,xmm8
    74a37e505731:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e50573a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e505743:	call   0x74a37e509b70
    74a37e505748:	jmp    0x74a37e504827
    74a37e50574d:	movdqa xmm0,xmm7
    74a37e505751:	movdqa xmm1,xmm6
    74a37e505755:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e50575e:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e505767:	call   0x74a37e50b460
    74a37e50576c:	jmp    0x74a37e50487f
    74a37e505771:	movdqa xmm0,xmm9
    74a37e505776:	movdqa xmm1,xmm3
    74a37e50577a:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e505783:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e50578c:	call   0x74a37e50b610
    74a37e505791:	jmp    0x74a37e5048d8
    74a37e505796:	movdqa xmm0,xmm12
    74a37e50579b:	movdqa xmm1,xmm10
    74a37e5057a0:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e5057a9:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e5057b2:	call   0x74a37e50b7b0
    74a37e5057b7:	jmp    0x74a37e504932
    74a37e5057bc:	mov    r11,rax
    74a37e5057bf:	lahf
    74a37e5057c0:	seto   al
    74a37e5057c3:	mov    WORD PTR [rsp],ax
    74a37e5057c7:	mov    rax,r11
    74a37e5057ca:	movdqa xmm0,xmm2
    74a37e5057ce:	movdqa xmm1,xmm3
    74a37e5057d2:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e5057db:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e5057e4:	call   0x74a37e50b940
    74a37e5057e9:	mov    r11,rax
    74a37e5057ec:	movzx  eax,WORD PTR [rsp]
    74a37e5057f0:	add    al,0x7f
    74a37e5057f2:	sahf
    74a37e5057f3:	mov    rax,r11
    74a37e5057f6:	jmp    0x74a37e504abd
    74a37e5057fb:	mov    r11,rax
    74a37e5057fe:	lahf
    74a37e5057ff:	seto   al
    74a37e505802:	mov    WORD PTR [rsp],ax
    74a37e505806:	mov    rax,r11
    74a37e505809:	movdqa xmm0,xmm4
    74a37e50580d:	movdqa xmm1,xmm2
    74a37e505811:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    74a37e50581a:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    74a37e505823:	call   0x74a37e50baa0
    74a37e505828:	mov    r11,rax
    74a37e50582b:	movzx  eax,WORD PTR [rsp]
    74a37e50582f:	add    al,0x7f
    74a37e505831:	sahf
    74a37e505832:	mov    rax,r11
    74a37e505835:	jmp    0x74a37e504b1d
    74a37e50583a:	nop    WORD PTR [rax+rax*1+0x0]
    74a37e505840:	sub    rsp,0x8
    74a37e505844:	mov    QWORD PTR [r12+0x378],0x3
    74a37e505850:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e505856:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e50585c:	mov    QWORD PTR [r12+0x108],rbx
    74a37e505864:	stmxcsr DWORD PTR [r12-0x28]
    74a37e50586a:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e50586f:	test   r10d,0x3f
    74a37e505876:	je     0x74a37e50589b
    74a37e50587c:	mov    r11d,r10d
    74a37e50587f:	shr    r10d,1
    74a37e505882:	and    r10d,0x1e
    74a37e505886:	and    r11d,0x1
    74a37e50588a:	or     r10d,r11d
    74a37e50588d:	or     DWORD PTR [r12+0x314],r10d
    74a37e505895:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e50589b:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e5058a1:	lea    rdi,[rsp+0x110]
    74a37e5058a9:	lea    rsi,[rsp+0xf0]
    74a37e5058b1:	lea    rdx,[rsp+0x100]
    74a37e5058b9:	mov    ecx,0x16
    74a37e5058be:	mov    r8d,0x0
    74a37e5058c4:	lea    r9,[r12+0x314]
    74a37e5058cc:	movabs r11,0x571546550650
    74a37e5058d6:	call   r11
    74a37e5058d9:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e5058df:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e5058e5:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e5058eb:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e5058f3:	mov    QWORD PTR [r12+0x378],0x2
    74a37e5058ff:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e505908:	add    rsp,0x8
    74a37e50590c:	ret
    74a37e50590d:	nop    DWORD PTR [rax]
    74a37e505910:	sub    rsp,0x8
    74a37e505914:	mov    QWORD PTR [r12+0x378],0x3
    74a37e505920:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e505926:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e50592c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e505932:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e50593c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e505946:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50594e:	stmxcsr DWORD PTR [r12-0x28]
    74a37e505954:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e505959:	test   r10d,0x3f
    74a37e505960:	je     0x74a37e505985
    74a37e505966:	mov    r11d,r10d
    74a37e505969:	shr    r10d,1
    74a37e50596c:	and    r10d,0x1e
    74a37e505970:	and    r11d,0x1
    74a37e505974:	or     r10d,r11d
    74a37e505977:	or     DWORD PTR [r12+0x314],r10d
    74a37e50597f:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e505985:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e50598b:	lea    rdi,[rsp+0x110]
    74a37e505993:	lea    rsi,[rsp+0xf0]
    74a37e50599b:	lea    rdx,[rsp+0x100]
    74a37e5059a3:	mov    ecx,0x16
    74a37e5059a8:	mov    r8d,0x0
    74a37e5059ae:	lea    r9,[r12+0x314]
    74a37e5059b6:	movabs r11,0x571546550650
    74a37e5059c0:	call   r11
    74a37e5059c3:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e5059c9:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e5059cf:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e5059d5:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e5059db:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e5059e5:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e5059ef:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e5059f7:	mov    QWORD PTR [r12+0x378],0x2
    74a37e505a03:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e505a0c:	add    rsp,0x8
    74a37e505a10:	ret
    74a37e505a11:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e505a20:	sub    rsp,0x8
    74a37e505a24:	mov    QWORD PTR [r12+0x378],0x3
    74a37e505a30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e505a36:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e505a3c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e505a42:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e505a4c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e505a56:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e505a60:	mov    QWORD PTR [r12+0x108],rbx
    74a37e505a68:	stmxcsr DWORD PTR [r12-0x28]
    74a37e505a6e:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e505a73:	test   r10d,0x3f
    74a37e505a7a:	je     0x74a37e505a9f
    74a37e505a80:	mov    r11d,r10d
    74a37e505a83:	shr    r10d,1
    74a37e505a86:	and    r10d,0x1e
    74a37e505a8a:	and    r11d,0x1
    74a37e505a8e:	or     r10d,r11d
    74a37e505a91:	or     DWORD PTR [r12+0x314],r10d
    74a37e505a99:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e505a9f:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e505aa5:	lea    rdi,[rsp+0x110]
    74a37e505aad:	lea    rsi,[rsp+0xf0]
    74a37e505ab5:	lea    rdx,[rsp+0x100]
    74a37e505abd:	mov    ecx,0x56
    74a37e505ac2:	mov    r8d,0x0
    74a37e505ac8:	lea    r9,[r12+0x314]
    74a37e505ad0:	movabs r11,0x571546550650
    74a37e505ada:	call   r11
    74a37e505add:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e505ae3:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e505ae9:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e505aef:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e505af5:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e505aff:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e505b09:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e505b13:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e505b1b:	mov    QWORD PTR [r12+0x378],0x2
    74a37e505b27:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e505b30:	add    rsp,0x8
    74a37e505b34:	ret
    74a37e505b35:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e505b40:	sub    rsp,0x8
    74a37e505b44:	mov    QWORD PTR [r12+0x378],0x3
    74a37e505b50:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e505b56:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e505b5c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e505b62:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e505b6c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e505b76:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e505b80:	mov    QWORD PTR [r12+0x108],rbx
    74a37e505b88:	stmxcsr DWORD PTR [r12-0x28]
    74a37e505b8e:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e505b93:	test   r10d,0x3f
    74a37e505b9a:	je     0x74a37e505bbf
    74a37e505ba0:	mov    r11d,r10d
    74a37e505ba3:	shr    r10d,1
    74a37e505ba6:	and    r10d,0x1e
    74a37e505baa:	and    r11d,0x1
    74a37e505bae:	or     r10d,r11d
    74a37e505bb1:	or     DWORD PTR [r12+0x314],r10d
    74a37e505bb9:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e505bbf:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e505bc5:	lea    rdi,[rsp+0x110]
    74a37e505bcd:	lea    rsi,[rsp+0xf0]
    74a37e505bd5:	lea    rdx,[rsp+0x100]
    74a37e505bdd:	mov    ecx,0x16
    74a37e505be2:	mov    r8d,0x0
    74a37e505be8:	lea    r9,[r12+0x314]
    74a37e505bf0:	movabs r11,0x571546550650
    74a37e505bfa:	call   r11
    74a37e505bfd:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e505c03:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e505c09:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e505c0f:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e505c15:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e505c1f:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e505c29:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e505c33:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e505c3b:	mov    QWORD PTR [r12+0x378],0x2
    74a37e505c47:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e505c50:	add    rsp,0x8
    74a37e505c54:	ret
    74a37e505c55:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e505c60:	sub    rsp,0x8
    74a37e505c64:	mov    QWORD PTR [r12+0x378],0x3
    74a37e505c70:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e505c76:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e505c7c:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e505c86:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e505c90:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e505c9a:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e505ca4:	mov    QWORD PTR [r12+0x108],rbx
    74a37e505cac:	stmxcsr DWORD PTR [r12-0x28]
    74a37e505cb2:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e505cb7:	test   r10d,0x3f
    74a37e505cbe:	je     0x74a37e505ce3
    74a37e505cc4:	mov    r11d,r10d
    74a37e505cc7:	shr    r10d,1
    74a37e505cca:	and    r10d,0x1e
    74a37e505cce:	and    r11d,0x1
    74a37e505cd2:	or     r10d,r11d
    74a37e505cd5:	or     DWORD PTR [r12+0x314],r10d
    74a37e505cdd:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e505ce3:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e505ce9:	lea    rdi,[rsp+0x110]
    74a37e505cf1:	lea    rsi,[rsp+0xf0]
    74a37e505cf9:	lea    rdx,[rsp+0x100]
    74a37e505d01:	mov    ecx,0x16
    74a37e505d06:	mov    r8d,0x0
    74a37e505d0c:	lea    r9,[r12+0x314]
    74a37e505d14:	movabs r11,0x571546550650
    74a37e505d1e:	call   r11
    74a37e505d21:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e505d27:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e505d2d:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e505d33:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e505d3d:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e505d47:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e505d51:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e505d5b:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e505d63:	mov    QWORD PTR [r12+0x378],0x2
    74a37e505d6f:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e505d78:	add    rsp,0x8
    74a37e505d7c:	ret
    74a37e505d7d:	nop    DWORD PTR [rax]
    74a37e505d80:	sub    rsp,0x8
    74a37e505d84:	mov    QWORD PTR [r12+0x378],0x3
    74a37e505d90:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e505d96:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e505d9c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e505da2:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e505dac:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e505db6:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e505dc0:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e505dca:	mov    QWORD PTR [r12+0x108],rbx
    74a37e505dd2:	stmxcsr DWORD PTR [r12-0x28]
    74a37e505dd8:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e505ddd:	test   r10d,0x3f
    74a37e505de4:	je     0x74a37e505e09
    74a37e505dea:	mov    r11d,r10d
    74a37e505ded:	shr    r10d,1
    74a37e505df0:	and    r10d,0x1e
    74a37e505df4:	and    r11d,0x1
    74a37e505df8:	or     r10d,r11d
    74a37e505dfb:	or     DWORD PTR [r12+0x314],r10d
    74a37e505e03:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e505e09:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e505e0f:	lea    rdi,[rsp+0x110]
    74a37e505e17:	lea    rsi,[rsp+0xf0]
    74a37e505e1f:	lea    rdx,[rsp+0x100]
    74a37e505e27:	mov    ecx,0x16
    74a37e505e2c:	mov    r8d,0x0
    74a37e505e32:	lea    r9,[r12+0x314]
    74a37e505e3a:	movabs r11,0x571546550650
    74a37e505e44:	call   r11
    74a37e505e47:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e505e4d:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e505e53:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e505e59:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e505e5f:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e505e69:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e505e73:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e505e7d:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e505e87:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e505e8f:	mov    QWORD PTR [r12+0x378],0x2
    74a37e505e9b:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e505ea4:	add    rsp,0x8
    74a37e505ea8:	ret
    74a37e505ea9:	nop    DWORD PTR [rax+0x0]
    74a37e505eb0:	sub    rsp,0x8
    74a37e505eb4:	mov    QWORD PTR [r12+0x378],0x3
    74a37e505ec0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e505ec6:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e505ecc:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e505ed6:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e505ee0:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e505eea:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e505ef4:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e505efe:	mov    QWORD PTR [r12+0x108],rbx
    74a37e505f06:	stmxcsr DWORD PTR [r12-0x28]
    74a37e505f0c:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e505f11:	test   r10d,0x3f
    74a37e505f18:	je     0x74a37e505f3d
    74a37e505f1e:	mov    r11d,r10d
    74a37e505f21:	shr    r10d,1
    74a37e505f24:	and    r10d,0x1e
    74a37e505f28:	and    r11d,0x1
    74a37e505f2c:	or     r10d,r11d
    74a37e505f2f:	or     DWORD PTR [r12+0x314],r10d
    74a37e505f37:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e505f3d:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e505f43:	lea    rdi,[rsp+0x110]
    74a37e505f4b:	lea    rsi,[rsp+0xf0]
    74a37e505f53:	lea    rdx,[rsp+0x100]
    74a37e505f5b:	mov    ecx,0x56
    74a37e505f60:	mov    r8d,0x0
    74a37e505f66:	lea    r9,[r12+0x314]
    74a37e505f6e:	movabs r11,0x571546550650
    74a37e505f78:	call   r11
    74a37e505f7b:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e505f81:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e505f87:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e505f8d:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e505f97:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e505fa1:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e505fab:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e505fb5:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e505fbf:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e505fc7:	mov    QWORD PTR [r12+0x378],0x2
    74a37e505fd3:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e505fdc:	add    rsp,0x8
    74a37e505fe0:	ret
    74a37e505fe1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e505ff0:	sub    rsp,0x8
    74a37e505ff4:	mov    QWORD PTR [r12+0x378],0x3
    74a37e506000:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e506006:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e50600c:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e506012:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e50601c:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e506026:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e506030:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e50603a:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e506044:	push   rdx
    74a37e506045:	push   rsi
    74a37e506046:	push   r10
    74a37e506048:	push   r11
    74a37e50604a:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e50604f:	mov    r10d,edx
    74a37e506052:	and    r10d,0xc000
    74a37e506059:	shl    r10d,0x10
    74a37e50605d:	mov    r11d,edx
    74a37e506060:	and    r11d,0x100
    74a37e506067:	shl    r11d,0x15
    74a37e50606b:	or     r10d,r11d
    74a37e50606e:	and    edx,0x1
    74a37e506071:	shl    edx,0x1c
    74a37e506074:	or     r10d,edx
    74a37e506077:	btc    r10,0x1d
    74a37e50607c:	mov    r11d,0xf0000000
    74a37e506082:	and    r11,r10
    74a37e506085:	movabs rsi,0xffffffff0fffffff
    74a37e50608f:	and    rbx,rsi
    74a37e506092:	or     rbx,r11
    74a37e506095:	pop    r11
    74a37e506097:	pop    r10
    74a37e506099:	pop    rsi
    74a37e50609a:	pop    rdx
    74a37e50609b:	mov    QWORD PTR [r12+0x108],rbx
    74a37e5060a3:	stmxcsr DWORD PTR [r12-0x28]
    74a37e5060a9:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e5060ae:	test   r10d,0x3f
    74a37e5060b5:	je     0x74a37e5060da
    74a37e5060bb:	mov    r11d,r10d
    74a37e5060be:	shr    r10d,1
    74a37e5060c1:	and    r10d,0x1e
    74a37e5060c5:	and    r11d,0x1
    74a37e5060c9:	or     r10d,r11d
    74a37e5060cc:	or     DWORD PTR [r12+0x314],r10d
    74a37e5060d4:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e5060da:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e5060e0:	lea    rdi,[rsp+0x110]
    74a37e5060e8:	lea    rsi,[rsp+0xf0]
    74a37e5060f0:	lea    rdx,[rsp+0x100]
    74a37e5060f8:	mov    ecx,0x14
    74a37e5060fd:	mov    r8d,0x0
    74a37e506103:	lea    r9,[r12+0x314]
    74a37e50610b:	movabs r11,0x571546550650
    74a37e506115:	call   r11
    74a37e506118:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e50611e:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e506124:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e50612a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e506130:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e50613a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e506144:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e50614e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e506158:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e506162:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50616a:	mov    QWORD PTR [r12+0x378],0x2
    74a37e506176:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e50617f:	mov    rdx,rbx
    74a37e506182:	shr    rdx,0x10
    74a37e506186:	and    edx,0xc000
    74a37e50618c:	mov    rax,rbx
    74a37e50618f:	shr    rax,0x15
    74a37e506193:	and    eax,0x100
    74a37e506198:	xor    eax,0x100
    74a37e50619d:	or     edx,eax
    74a37e50619f:	mov    rax,rbx
    74a37e5061a2:	shr    rax,0x1c
    74a37e5061a6:	and    eax,0x1
    74a37e5061a9:	or     edx,eax
    74a37e5061ab:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e5061b0:	add    rsp,0x8
    74a37e5061b4:	ret
    74a37e5061b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e5061c0:	sub    rsp,0x8
    74a37e5061c4:	mov    QWORD PTR [r12+0x378],0x3
    74a37e5061d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e5061d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e5061dc:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e5061e2:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e5061e8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e5061f2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e5061fc:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e506206:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e506210:	push   rdx
    74a37e506211:	push   rsi
    74a37e506212:	push   r10
    74a37e506214:	push   r11
    74a37e506216:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e50621b:	mov    r10d,edx
    74a37e50621e:	and    r10d,0xc000
    74a37e506225:	shl    r10d,0x10
    74a37e506229:	mov    r11d,edx
    74a37e50622c:	and    r11d,0x100
    74a37e506233:	shl    r11d,0x15
    74a37e506237:	or     r10d,r11d
    74a37e50623a:	and    edx,0x1
    74a37e50623d:	shl    edx,0x1c
    74a37e506240:	or     r10d,edx
    74a37e506243:	btc    r10,0x1d
    74a37e506248:	mov    r11d,0xf0000000
    74a37e50624e:	and    r11,r10
    74a37e506251:	movabs rsi,0xffffffff0fffffff
    74a37e50625b:	and    rbx,rsi
    74a37e50625e:	or     rbx,r11
    74a37e506261:	pop    r11
    74a37e506263:	pop    r10
    74a37e506265:	pop    rsi
    74a37e506266:	pop    rdx
    74a37e506267:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50626f:	stmxcsr DWORD PTR [r12-0x28]
    74a37e506275:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e50627a:	test   r10d,0x3f
    74a37e506281:	je     0x74a37e5062a6
    74a37e506287:	mov    r11d,r10d
    74a37e50628a:	shr    r10d,1
    74a37e50628d:	and    r10d,0x1e
    74a37e506291:	and    r11d,0x1
    74a37e506295:	or     r10d,r11d
    74a37e506298:	or     DWORD PTR [r12+0x314],r10d
    74a37e5062a0:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e5062a6:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e5062ac:	lea    rdi,[rsp+0x110]
    74a37e5062b4:	lea    rsi,[rsp+0xf0]
    74a37e5062bc:	lea    rdx,[rsp+0x100]
    74a37e5062c4:	mov    ecx,0x14
    74a37e5062c9:	mov    r8d,0x0
    74a37e5062cf:	lea    r9,[r12+0x314]
    74a37e5062d7:	movabs r11,0x571546550650
    74a37e5062e1:	call   r11
    74a37e5062e4:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e5062ea:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e5062f0:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e5062f6:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e5062fc:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e506302:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e50630c:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e506316:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e506320:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e50632a:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e506332:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50633e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e506347:	mov    rdx,rbx
    74a37e50634a:	shr    rdx,0x10
    74a37e50634e:	and    edx,0xc000
    74a37e506354:	mov    rax,rbx
    74a37e506357:	shr    rax,0x15
    74a37e50635b:	and    eax,0x100
    74a37e506360:	xor    eax,0x100
    74a37e506365:	or     edx,eax
    74a37e506367:	mov    rax,rbx
    74a37e50636a:	shr    rax,0x1c
    74a37e50636e:	and    eax,0x1
    74a37e506371:	or     edx,eax
    74a37e506373:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e506378:	add    rsp,0x8
    74a37e50637c:	ret
    74a37e50637d:	nop    DWORD PTR [rax]
    74a37e506380:	sub    rsp,0x8
    74a37e506384:	mov    QWORD PTR [r12+0x378],0x3
    74a37e506390:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e506396:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e50639c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e5063a2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e5063a8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e5063ae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e5063b4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e5063be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e5063c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e5063d2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e5063dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e5063e6:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    74a37e5063f0:	push   rdx
    74a37e5063f1:	push   rsi
    74a37e5063f2:	push   r10
    74a37e5063f4:	push   r11
    74a37e5063f6:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e5063fb:	mov    r10d,edx
    74a37e5063fe:	and    r10d,0xc000
    74a37e506405:	shl    r10d,0x10
    74a37e506409:	mov    r11d,edx
    74a37e50640c:	and    r11d,0x100
    74a37e506413:	shl    r11d,0x15
    74a37e506417:	or     r10d,r11d
    74a37e50641a:	and    edx,0x1
    74a37e50641d:	shl    edx,0x1c
    74a37e506420:	or     r10d,edx
    74a37e506423:	btc    r10,0x1d
    74a37e506428:	mov    r11d,0xf0000000
    74a37e50642e:	and    r11,r10
    74a37e506431:	movabs rsi,0xffffffff0fffffff
    74a37e50643b:	and    rbx,rsi
    74a37e50643e:	or     rbx,r11
    74a37e506441:	pop    r11
    74a37e506443:	pop    r10
    74a37e506445:	pop    rsi
    74a37e506446:	pop    rdx
    74a37e506447:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50644f:	stmxcsr DWORD PTR [r12-0x28]
    74a37e506455:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e50645a:	test   r10d,0x3f
    74a37e506461:	je     0x74a37e506486
    74a37e506467:	mov    r11d,r10d
    74a37e50646a:	shr    r10d,1
    74a37e50646d:	and    r10d,0x1e
    74a37e506471:	and    r11d,0x1
    74a37e506475:	or     r10d,r11d
    74a37e506478:	or     DWORD PTR [r12+0x314],r10d
    74a37e506480:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e506486:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e50648c:	lea    rdi,[rsp+0x110]
    74a37e506494:	lea    rsi,[rsp+0xf0]
    74a37e50649c:	lea    rdx,[rsp+0x100]
    74a37e5064a4:	mov    ecx,0x14
    74a37e5064a9:	mov    r8d,0x0
    74a37e5064af:	lea    r9,[r12+0x314]
    74a37e5064b7:	movabs r11,0x571546550650
    74a37e5064c1:	call   r11
    74a37e5064c4:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e5064ca:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e5064d0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e5064d6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e5064dc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e5064e2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e5064e8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e5064ee:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e5064f8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e506502:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e50650c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e506516:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e506520:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    74a37e50652a:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e506532:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50653e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e506547:	mov    rdx,rbx
    74a37e50654a:	shr    rdx,0x10
    74a37e50654e:	and    edx,0xc000
    74a37e506554:	mov    rax,rbx
    74a37e506557:	shr    rax,0x15
    74a37e50655b:	and    eax,0x100
    74a37e506560:	xor    eax,0x100
    74a37e506565:	or     edx,eax
    74a37e506567:	mov    rax,rbx
    74a37e50656a:	shr    rax,0x1c
    74a37e50656e:	and    eax,0x1
    74a37e506571:	or     edx,eax
    74a37e506573:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e506578:	add    rsp,0x8
    74a37e50657c:	ret
    74a37e50657d:	nop    DWORD PTR [rax]
    74a37e506580:	sub    rsp,0x8
    74a37e506584:	mov    QWORD PTR [r12+0x378],0x3
    74a37e506590:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e506596:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e50659c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e5065a2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e5065a8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e5065ae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e5065b4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e5065be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e5065c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e5065d2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e5065dc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    74a37e5065e6:	push   rdx
    74a37e5065e7:	push   rsi
    74a37e5065e8:	push   r10
    74a37e5065ea:	push   r11
    74a37e5065ec:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e5065f1:	mov    r10d,edx
    74a37e5065f4:	and    r10d,0xc000
    74a37e5065fb:	shl    r10d,0x10
    74a37e5065ff:	mov    r11d,edx
    74a37e506602:	and    r11d,0x100
    74a37e506609:	shl    r11d,0x15
    74a37e50660d:	or     r10d,r11d
    74a37e506610:	and    edx,0x1
    74a37e506613:	shl    edx,0x1c
    74a37e506616:	or     r10d,edx
    74a37e506619:	btc    r10,0x1d
    74a37e50661e:	mov    r11d,0xf0000000
    74a37e506624:	and    r11,r10
    74a37e506627:	movabs rsi,0xffffffff0fffffff
    74a37e506631:	and    rbx,rsi
    74a37e506634:	or     rbx,r11
    74a37e506637:	pop    r11
    74a37e506639:	pop    r10
    74a37e50663b:	pop    rsi
    74a37e50663c:	pop    rdx
    74a37e50663d:	mov    QWORD PTR [r12+0x108],rbx
    74a37e506645:	stmxcsr DWORD PTR [r12-0x28]
    74a37e50664b:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e506650:	test   r10d,0x3f
    74a37e506657:	je     0x74a37e50667c
    74a37e50665d:	mov    r11d,r10d
    74a37e506660:	shr    r10d,1
    74a37e506663:	and    r10d,0x1e
    74a37e506667:	and    r11d,0x1
    74a37e50666b:	or     r10d,r11d
    74a37e50666e:	or     DWORD PTR [r12+0x314],r10d
    74a37e506676:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e50667c:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e506682:	lea    rdi,[rsp+0x110]
    74a37e50668a:	lea    rsi,[rsp+0xf0]
    74a37e506692:	lea    rdx,[rsp+0x100]
    74a37e50669a:	mov    ecx,0x14
    74a37e50669f:	mov    r8d,0x0
    74a37e5066a5:	lea    r9,[r12+0x314]
    74a37e5066ad:	movabs r11,0x571546550650
    74a37e5066b7:	call   r11
    74a37e5066ba:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e5066c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e5066c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e5066cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e5066d2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e5066d8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e5066de:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e5066e4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e5066ee:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e5066f8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e506702:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e50670c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    74a37e506716:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50671e:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50672a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e506733:	mov    rdx,rbx
    74a37e506736:	shr    rdx,0x10
    74a37e50673a:	and    edx,0xc000
    74a37e506740:	mov    rax,rbx
    74a37e506743:	shr    rax,0x15
    74a37e506747:	and    eax,0x100
    74a37e50674c:	xor    eax,0x100
    74a37e506751:	or     edx,eax
    74a37e506753:	mov    rax,rbx
    74a37e506756:	shr    rax,0x1c
    74a37e50675a:	and    eax,0x1
    74a37e50675d:	or     edx,eax
    74a37e50675f:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e506764:	add    rsp,0x8
    74a37e506768:	ret
    74a37e506769:	nop    DWORD PTR [rax+0x0]
    74a37e506770:	sub    rsp,0x8
    74a37e506774:	mov    QWORD PTR [r12+0x378],0x3
    74a37e506780:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e506786:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e50678c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e506792:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e506798:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e5067a2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e5067ac:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e5067b6:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e5067c0:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e5067ca:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    74a37e5067d4:	push   rdx
    74a37e5067d5:	push   rsi
    74a37e5067d6:	push   r10
    74a37e5067d8:	push   r11
    74a37e5067da:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e5067df:	mov    r10d,edx
    74a37e5067e2:	and    r10d,0xc000
    74a37e5067e9:	shl    r10d,0x10
    74a37e5067ed:	mov    r11d,edx
    74a37e5067f0:	and    r11d,0x100
    74a37e5067f7:	shl    r11d,0x15
    74a37e5067fb:	or     r10d,r11d
    74a37e5067fe:	and    edx,0x1
    74a37e506801:	shl    edx,0x1c
    74a37e506804:	or     r10d,edx
    74a37e506807:	btc    r10,0x1d
    74a37e50680c:	mov    r11d,0xf0000000
    74a37e506812:	and    r11,r10
    74a37e506815:	movabs rsi,0xffffffff0fffffff
    74a37e50681f:	and    rbx,rsi
    74a37e506822:	or     rbx,r11
    74a37e506825:	pop    r11
    74a37e506827:	pop    r10
    74a37e506829:	pop    rsi
    74a37e50682a:	pop    rdx
    74a37e50682b:	mov    QWORD PTR [r12+0x108],rbx
    74a37e506833:	stmxcsr DWORD PTR [r12-0x28]
    74a37e506839:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e50683e:	test   r10d,0x3f
    74a37e506845:	je     0x74a37e50686a
    74a37e50684b:	mov    r11d,r10d
    74a37e50684e:	shr    r10d,1
    74a37e506851:	and    r10d,0x1e
    74a37e506855:	and    r11d,0x1
    74a37e506859:	or     r10d,r11d
    74a37e50685c:	or     DWORD PTR [r12+0x314],r10d
    74a37e506864:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e50686a:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e506870:	lea    rdi,[rsp+0x110]
    74a37e506878:	lea    rsi,[rsp+0xf0]
    74a37e506880:	lea    rdx,[rsp+0x100]
    74a37e506888:	mov    ecx,0x14
    74a37e50688d:	mov    r8d,0x0
    74a37e506893:	lea    r9,[r12+0x314]
    74a37e50689b:	movabs r11,0x571546550650
    74a37e5068a5:	call   r11
    74a37e5068a8:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e5068ae:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e5068b4:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e5068ba:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e5068c0:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e5068c6:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e5068d0:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e5068da:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e5068e4:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e5068ee:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e5068f8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    74a37e506902:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50690a:	mov    QWORD PTR [r12+0x378],0x2
    74a37e506916:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e50691f:	mov    rdx,rbx
    74a37e506922:	shr    rdx,0x10
    74a37e506926:	and    edx,0xc000
    74a37e50692c:	mov    rax,rbx
    74a37e50692f:	shr    rax,0x15
    74a37e506933:	and    eax,0x100
    74a37e506938:	xor    eax,0x100
    74a37e50693d:	or     edx,eax
    74a37e50693f:	mov    rax,rbx
    74a37e506942:	shr    rax,0x1c
    74a37e506946:	and    eax,0x1
    74a37e506949:	or     edx,eax
    74a37e50694b:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e506950:	add    rsp,0x8
    74a37e506954:	ret
    74a37e506955:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e506960:	sub    rsp,0x8
    74a37e506964:	mov    QWORD PTR [r12+0x378],0x3
    74a37e506970:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e506976:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e50697c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e506982:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e506988:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e50698e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e506998:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e5069a2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e5069ac:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    74a37e5069b6:	push   rdx
    74a37e5069b7:	push   rsi
    74a37e5069b8:	push   r10
    74a37e5069ba:	push   r11
    74a37e5069bc:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e5069c1:	mov    r10d,edx
    74a37e5069c4:	and    r10d,0xc000
    74a37e5069cb:	shl    r10d,0x10
    74a37e5069cf:	mov    r11d,edx
    74a37e5069d2:	and    r11d,0x100
    74a37e5069d9:	shl    r11d,0x15
    74a37e5069dd:	or     r10d,r11d
    74a37e5069e0:	and    edx,0x1
    74a37e5069e3:	shl    edx,0x1c
    74a37e5069e6:	or     r10d,edx
    74a37e5069e9:	btc    r10,0x1d
    74a37e5069ee:	mov    r11d,0xf0000000
    74a37e5069f4:	and    r11,r10
    74a37e5069f7:	movabs rsi,0xffffffff0fffffff
    74a37e506a01:	and    rbx,rsi
    74a37e506a04:	or     rbx,r11
    74a37e506a07:	pop    r11
    74a37e506a09:	pop    r10
    74a37e506a0b:	pop    rsi
    74a37e506a0c:	pop    rdx
    74a37e506a0d:	mov    QWORD PTR [r12+0x108],rbx
    74a37e506a15:	stmxcsr DWORD PTR [r12-0x28]
    74a37e506a1b:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e506a20:	test   r10d,0x3f
    74a37e506a27:	je     0x74a37e506a4c
    74a37e506a2d:	mov    r11d,r10d
    74a37e506a30:	shr    r10d,1
    74a37e506a33:	and    r10d,0x1e
    74a37e506a37:	and    r11d,0x1
    74a37e506a3b:	or     r10d,r11d
    74a37e506a3e:	or     DWORD PTR [r12+0x314],r10d
    74a37e506a46:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e506a4c:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e506a52:	lea    rdi,[rsp+0x110]
    74a37e506a5a:	lea    rsi,[rsp+0xf0]
    74a37e506a62:	lea    rdx,[rsp+0x100]
    74a37e506a6a:	mov    ecx,0x56
    74a37e506a6f:	mov    r8d,0x0
    74a37e506a75:	lea    r9,[r12+0x314]
    74a37e506a7d:	movabs r11,0x571546550650
    74a37e506a87:	call   r11
    74a37e506a8a:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e506a90:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e506a96:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e506a9c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e506aa2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e506aa8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e506aae:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e506ab8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e506ac2:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e506acc:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    74a37e506ad6:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e506ade:	mov    QWORD PTR [r12+0x378],0x2
    74a37e506aea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e506af3:	mov    rdx,rbx
    74a37e506af6:	shr    rdx,0x10
    74a37e506afa:	and    edx,0xc000
    74a37e506b00:	mov    rax,rbx
    74a37e506b03:	shr    rax,0x15
    74a37e506b07:	and    eax,0x100
    74a37e506b0c:	xor    eax,0x100
    74a37e506b11:	or     edx,eax
    74a37e506b13:	mov    rax,rbx
    74a37e506b16:	shr    rax,0x1c
    74a37e506b1a:	and    eax,0x1
    74a37e506b1d:	or     edx,eax
    74a37e506b1f:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e506b24:	add    rsp,0x8
    74a37e506b28:	ret
    74a37e506b29:	nop    DWORD PTR [rax+0x0]
    74a37e506b30:	sub    rsp,0x8
    74a37e506b34:	mov    QWORD PTR [r12+0x378],0x3
    74a37e506b40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e506b46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e506b4c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e506b52:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e506b58:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e506b5e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e506b64:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e506b6e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e506b78:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e506b82:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    74a37e506b8c:	push   rdx
    74a37e506b8d:	push   rsi
    74a37e506b8e:	push   r10
    74a37e506b90:	push   r11
    74a37e506b92:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e506b97:	mov    r10d,edx
    74a37e506b9a:	and    r10d,0xc000
    74a37e506ba1:	shl    r10d,0x10
    74a37e506ba5:	mov    r11d,edx
    74a37e506ba8:	and    r11d,0x100
    74a37e506baf:	shl    r11d,0x15
    74a37e506bb3:	or     r10d,r11d
    74a37e506bb6:	and    edx,0x1
    74a37e506bb9:	shl    edx,0x1c
    74a37e506bbc:	or     r10d,edx
    74a37e506bbf:	btc    r10,0x1d
    74a37e506bc4:	mov    r11d,0xf0000000
    74a37e506bca:	and    r11,r10
    74a37e506bcd:	movabs rsi,0xffffffff0fffffff
    74a37e506bd7:	and    rbx,rsi
    74a37e506bda:	or     rbx,r11
    74a37e506bdd:	pop    r11
    74a37e506bdf:	pop    r10
    74a37e506be1:	pop    rsi
    74a37e506be2:	pop    rdx
    74a37e506be3:	mov    QWORD PTR [r12+0x108],rbx
    74a37e506beb:	stmxcsr DWORD PTR [r12-0x28]
    74a37e506bf1:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e506bf6:	test   r10d,0x3f
    74a37e506bfd:	je     0x74a37e506c22
    74a37e506c03:	mov    r11d,r10d
    74a37e506c06:	shr    r10d,1
    74a37e506c09:	and    r10d,0x1e
    74a37e506c0d:	and    r11d,0x1
    74a37e506c11:	or     r10d,r11d
    74a37e506c14:	or     DWORD PTR [r12+0x314],r10d
    74a37e506c1c:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e506c22:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e506c28:	lea    rdi,[rsp+0x110]
    74a37e506c30:	lea    rsi,[rsp+0xf0]
    74a37e506c38:	lea    rdx,[rsp+0x100]
    74a37e506c40:	mov    ecx,0x56
    74a37e506c45:	mov    r8d,0x0
    74a37e506c4b:	lea    r9,[r12+0x314]
    74a37e506c53:	movabs r11,0x571546550650
    74a37e506c5d:	call   r11
    74a37e506c60:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e506c66:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e506c6c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e506c72:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e506c78:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e506c7e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e506c84:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e506c8a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e506c94:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e506c9e:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e506ca8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    74a37e506cb2:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e506cba:	mov    QWORD PTR [r12+0x378],0x2
    74a37e506cc6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e506ccf:	mov    rdx,rbx
    74a37e506cd2:	shr    rdx,0x10
    74a37e506cd6:	and    edx,0xc000
    74a37e506cdc:	mov    rax,rbx
    74a37e506cdf:	shr    rax,0x15
    74a37e506ce3:	and    eax,0x100
    74a37e506ce8:	xor    eax,0x100
    74a37e506ced:	or     edx,eax
    74a37e506cef:	mov    rax,rbx
    74a37e506cf2:	shr    rax,0x1c
    74a37e506cf6:	and    eax,0x1
    74a37e506cf9:	or     edx,eax
    74a37e506cfb:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e506d00:	add    rsp,0x8
    74a37e506d04:	ret
    74a37e506d05:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e506d10:	sub    rsp,0x8
    74a37e506d14:	mov    QWORD PTR [r12+0x378],0x3
    74a37e506d20:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e506d26:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e506d2c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e506d32:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e506d38:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e506d3e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e506d44:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e506d4e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e506d58:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e506d62:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e506d6c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    74a37e506d76:	push   rdx
    74a37e506d77:	push   rsi
    74a37e506d78:	push   r10
    74a37e506d7a:	push   r11
    74a37e506d7c:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e506d81:	mov    r10d,edx
    74a37e506d84:	and    r10d,0xc000
    74a37e506d8b:	shl    r10d,0x10
    74a37e506d8f:	mov    r11d,edx
    74a37e506d92:	and    r11d,0x100
    74a37e506d99:	shl    r11d,0x15
    74a37e506d9d:	or     r10d,r11d
    74a37e506da0:	and    edx,0x1
    74a37e506da3:	shl    edx,0x1c
    74a37e506da6:	or     r10d,edx
    74a37e506da9:	btc    r10,0x1d
    74a37e506dae:	mov    r11d,0xf0000000
    74a37e506db4:	and    r11,r10
    74a37e506db7:	movabs rsi,0xffffffff0fffffff
    74a37e506dc1:	and    rbx,rsi
    74a37e506dc4:	or     rbx,r11
    74a37e506dc7:	pop    r11
    74a37e506dc9:	pop    r10
    74a37e506dcb:	pop    rsi
    74a37e506dcc:	pop    rdx
    74a37e506dcd:	mov    QWORD PTR [r12+0x108],rbx
    74a37e506dd5:	stmxcsr DWORD PTR [r12-0x28]
    74a37e506ddb:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e506de0:	test   r10d,0x3f
    74a37e506de7:	je     0x74a37e506e0c
    74a37e506ded:	mov    r11d,r10d
    74a37e506df0:	shr    r10d,1
    74a37e506df3:	and    r10d,0x1e
    74a37e506df7:	and    r11d,0x1
    74a37e506dfb:	or     r10d,r11d
    74a37e506dfe:	or     DWORD PTR [r12+0x314],r10d
    74a37e506e06:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e506e0c:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e506e12:	lea    rdi,[rsp+0x110]
    74a37e506e1a:	lea    rsi,[rsp+0xf0]
    74a37e506e22:	lea    rdx,[rsp+0x100]
    74a37e506e2a:	mov    ecx,0x56
    74a37e506e2f:	mov    r8d,0x0
    74a37e506e35:	lea    r9,[r12+0x314]
    74a37e506e3d:	movabs r11,0x571546550650
    74a37e506e47:	call   r11
    74a37e506e4a:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e506e50:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e506e56:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e506e5c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e506e62:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e506e68:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e506e6e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e506e74:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e506e7e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e506e88:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e506e92:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e506e9c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    74a37e506ea6:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e506eae:	mov    QWORD PTR [r12+0x378],0x2
    74a37e506eba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e506ec3:	mov    rdx,rbx
    74a37e506ec6:	shr    rdx,0x10
    74a37e506eca:	and    edx,0xc000
    74a37e506ed0:	mov    rax,rbx
    74a37e506ed3:	shr    rax,0x15
    74a37e506ed7:	and    eax,0x100
    74a37e506edc:	xor    eax,0x100
    74a37e506ee1:	or     edx,eax
    74a37e506ee3:	mov    rax,rbx
    74a37e506ee6:	shr    rax,0x1c
    74a37e506eea:	and    eax,0x1
    74a37e506eed:	or     edx,eax
    74a37e506eef:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e506ef4:	add    rsp,0x8
    74a37e506ef8:	ret
    74a37e506ef9:	nop    DWORD PTR [rax+0x0]
    74a37e506f00:	sub    rsp,0x8
    74a37e506f04:	mov    QWORD PTR [r12+0x378],0x3
    74a37e506f10:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e506f16:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e506f1c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e506f22:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e506f28:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e506f32:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e506f3c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e506f46:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e506f50:	push   rdx
    74a37e506f51:	push   rsi
    74a37e506f52:	push   r10
    74a37e506f54:	push   r11
    74a37e506f56:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e506f5b:	mov    r10d,edx
    74a37e506f5e:	and    r10d,0xc000
    74a37e506f65:	shl    r10d,0x10
    74a37e506f69:	mov    r11d,edx
    74a37e506f6c:	and    r11d,0x100
    74a37e506f73:	shl    r11d,0x15
    74a37e506f77:	or     r10d,r11d
    74a37e506f7a:	and    edx,0x1
    74a37e506f7d:	shl    edx,0x1c
    74a37e506f80:	or     r10d,edx
    74a37e506f83:	btc    r10,0x1d
    74a37e506f88:	mov    r11d,0xf0000000
    74a37e506f8e:	and    r11,r10
    74a37e506f91:	movabs rsi,0xffffffff0fffffff
    74a37e506f9b:	and    rbx,rsi
    74a37e506f9e:	or     rbx,r11
    74a37e506fa1:	pop    r11
    74a37e506fa3:	pop    r10
    74a37e506fa5:	pop    rsi
    74a37e506fa6:	pop    rdx
    74a37e506fa7:	mov    QWORD PTR [r12+0x108],rbx
    74a37e506faf:	stmxcsr DWORD PTR [r12-0x28]
    74a37e506fb5:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e506fba:	test   r10d,0x3f
    74a37e506fc1:	je     0x74a37e506fe6
    74a37e506fc7:	mov    r11d,r10d
    74a37e506fca:	shr    r10d,1
    74a37e506fcd:	and    r10d,0x1e
    74a37e506fd1:	and    r11d,0x1
    74a37e506fd5:	or     r10d,r11d
    74a37e506fd8:	or     DWORD PTR [r12+0x314],r10d
    74a37e506fe0:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e506fe6:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e506fec:	lea    rdi,[rsp+0x110]
    74a37e506ff4:	lea    rsi,[rsp+0xf0]
    74a37e506ffc:	lea    rdx,[rsp+0x100]
    74a37e507004:	mov    ecx,0x56
    74a37e507009:	mov    r8d,0x0
    74a37e50700f:	lea    r9,[r12+0x314]
    74a37e507017:	movabs r11,0x571546550650
    74a37e507021:	call   r11
    74a37e507024:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e50702a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e507030:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e507036:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e50703c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e507042:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e50704c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e507056:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e507060:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e50706a:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e507072:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50707e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e507087:	mov    rdx,rbx
    74a37e50708a:	shr    rdx,0x10
    74a37e50708e:	and    edx,0xc000
    74a37e507094:	mov    rax,rbx
    74a37e507097:	shr    rax,0x15
    74a37e50709b:	and    eax,0x100
    74a37e5070a0:	xor    eax,0x100
    74a37e5070a5:	or     edx,eax
    74a37e5070a7:	mov    rax,rbx
    74a37e5070aa:	shr    rax,0x1c
    74a37e5070ae:	and    eax,0x1
    74a37e5070b1:	or     edx,eax
    74a37e5070b3:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e5070b8:	add    rsp,0x8
    74a37e5070bc:	ret
    74a37e5070bd:	nop    DWORD PTR [rax]
    74a37e5070c0:	sub    rsp,0x8
    74a37e5070c4:	mov    QWORD PTR [r12+0x378],0x3
    74a37e5070d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e5070d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e5070dc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e5070e2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e5070e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e5070ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e5070f8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e507102:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e50710c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e507116:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    74a37e507120:	push   rdx
    74a37e507121:	push   rsi
    74a37e507122:	push   r10
    74a37e507124:	push   r11
    74a37e507126:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e50712b:	mov    r10d,edx
    74a37e50712e:	and    r10d,0xc000
    74a37e507135:	shl    r10d,0x10
    74a37e507139:	mov    r11d,edx
    74a37e50713c:	and    r11d,0x100
    74a37e507143:	shl    r11d,0x15
    74a37e507147:	or     r10d,r11d
    74a37e50714a:	and    edx,0x1
    74a37e50714d:	shl    edx,0x1c
    74a37e507150:	or     r10d,edx
    74a37e507153:	btc    r10,0x1d
    74a37e507158:	mov    r11d,0xf0000000
    74a37e50715e:	and    r11,r10
    74a37e507161:	movabs rsi,0xffffffff0fffffff
    74a37e50716b:	and    rbx,rsi
    74a37e50716e:	or     rbx,r11
    74a37e507171:	pop    r11
    74a37e507173:	pop    r10
    74a37e507175:	pop    rsi
    74a37e507176:	pop    rdx
    74a37e507177:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50717f:	stmxcsr DWORD PTR [r12-0x28]
    74a37e507185:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e50718a:	test   r10d,0x3f
    74a37e507191:	je     0x74a37e5071b6
    74a37e507197:	mov    r11d,r10d
    74a37e50719a:	shr    r10d,1
    74a37e50719d:	and    r10d,0x1e
    74a37e5071a1:	and    r11d,0x1
    74a37e5071a5:	or     r10d,r11d
    74a37e5071a8:	or     DWORD PTR [r12+0x314],r10d
    74a37e5071b0:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e5071b6:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e5071bc:	lea    rdi,[rsp+0x110]
    74a37e5071c4:	lea    rsi,[rsp+0xf0]
    74a37e5071cc:	lea    rdx,[rsp+0x100]
    74a37e5071d4:	mov    ecx,0x14
    74a37e5071d9:	mov    r8d,0x0
    74a37e5071df:	lea    r9,[r12+0x314]
    74a37e5071e7:	movabs r11,0x571546550650
    74a37e5071f1:	call   r11
    74a37e5071f4:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e5071fa:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e507200:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e507206:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e50720c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e507212:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e507218:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e507222:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e50722c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e507236:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e507240:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    74a37e50724a:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e507252:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50725e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e507267:	mov    rdx,rbx
    74a37e50726a:	shr    rdx,0x10
    74a37e50726e:	and    edx,0xc000
    74a37e507274:	mov    rax,rbx
    74a37e507277:	shr    rax,0x15
    74a37e50727b:	and    eax,0x100
    74a37e507280:	xor    eax,0x100
    74a37e507285:	or     edx,eax
    74a37e507287:	mov    rax,rbx
    74a37e50728a:	shr    rax,0x1c
    74a37e50728e:	and    eax,0x1
    74a37e507291:	or     edx,eax
    74a37e507293:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e507298:	add    rsp,0x8
    74a37e50729c:	ret
    74a37e50729d:	nop    DWORD PTR [rax]
    74a37e5072a0:	sub    rsp,0x8
    74a37e5072a4:	mov    QWORD PTR [r12+0x378],0x3
    74a37e5072b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e5072b6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e5072bc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e5072c2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e5072c8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e5072ce:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e5072d8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e5072e2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e5072ec:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e5072f6:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    74a37e507300:	push   rdx
    74a37e507301:	push   rsi
    74a37e507302:	push   r10
    74a37e507304:	push   r11
    74a37e507306:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e50730b:	mov    r10d,edx
    74a37e50730e:	and    r10d,0xc000
    74a37e507315:	shl    r10d,0x10
    74a37e507319:	mov    r11d,edx
    74a37e50731c:	and    r11d,0x100
    74a37e507323:	shl    r11d,0x15
    74a37e507327:	or     r10d,r11d
    74a37e50732a:	and    edx,0x1
    74a37e50732d:	shl    edx,0x1c
    74a37e507330:	or     r10d,edx
    74a37e507333:	btc    r10,0x1d
    74a37e507338:	mov    r11d,0xf0000000
    74a37e50733e:	and    r11,r10
    74a37e507341:	movabs rsi,0xffffffff0fffffff
    74a37e50734b:	and    rbx,rsi
    74a37e50734e:	or     rbx,r11
    74a37e507351:	pop    r11
    74a37e507353:	pop    r10
    74a37e507355:	pop    rsi
    74a37e507356:	pop    rdx
    74a37e507357:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50735f:	stmxcsr DWORD PTR [r12-0x28]
    74a37e507365:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e50736a:	test   r10d,0x3f
    74a37e507371:	je     0x74a37e507396
    74a37e507377:	mov    r11d,r10d
    74a37e50737a:	shr    r10d,1
    74a37e50737d:	and    r10d,0x1e
    74a37e507381:	and    r11d,0x1
    74a37e507385:	or     r10d,r11d
    74a37e507388:	or     DWORD PTR [r12+0x314],r10d
    74a37e507390:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e507396:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e50739c:	lea    rdi,[rsp+0x110]
    74a37e5073a4:	lea    rsi,[rsp+0xf0]
    74a37e5073ac:	lea    rdx,[rsp+0x100]
    74a37e5073b4:	mov    ecx,0x56
    74a37e5073b9:	mov    r8d,0x0
    74a37e5073bf:	lea    r9,[r12+0x314]
    74a37e5073c7:	movabs r11,0x571546550650
    74a37e5073d1:	call   r11
    74a37e5073d4:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e5073da:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e5073e0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e5073e6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e5073ec:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e5073f2:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e5073f8:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e507402:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e50740c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e507416:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e507420:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    74a37e50742a:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e507432:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50743e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e507447:	mov    rdx,rbx
    74a37e50744a:	shr    rdx,0x10
    74a37e50744e:	and    edx,0xc000
    74a37e507454:	mov    rax,rbx
    74a37e507457:	shr    rax,0x15
    74a37e50745b:	and    eax,0x100
    74a37e507460:	xor    eax,0x100
    74a37e507465:	or     edx,eax
    74a37e507467:	mov    rax,rbx
    74a37e50746a:	shr    rax,0x1c
    74a37e50746e:	and    eax,0x1
    74a37e507471:	or     edx,eax
    74a37e507473:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e507478:	add    rsp,0x8
    74a37e50747c:	ret
    74a37e50747d:	nop    DWORD PTR [rax]
    74a37e507480:	sub    rsp,0x8
    74a37e507484:	mov    QWORD PTR [r12+0x378],0x3
    74a37e507490:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e507496:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e50749c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e5074a2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e5074a8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e5074ae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e5074b4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e5074be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e5074c8:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e5074d2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e5074dc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    74a37e5074e6:	push   rdx
    74a37e5074e7:	push   rsi
    74a37e5074e8:	push   r10
    74a37e5074ea:	push   r11
    74a37e5074ec:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e5074f1:	mov    r10d,edx
    74a37e5074f4:	and    r10d,0xc000
    74a37e5074fb:	shl    r10d,0x10
    74a37e5074ff:	mov    r11d,edx
    74a37e507502:	and    r11d,0x100
    74a37e507509:	shl    r11d,0x15
    74a37e50750d:	or     r10d,r11d
    74a37e507510:	and    edx,0x1
    74a37e507513:	shl    edx,0x1c
    74a37e507516:	or     r10d,edx
    74a37e507519:	btc    r10,0x1d
    74a37e50751e:	mov    r11d,0xf0000000
    74a37e507524:	and    r11,r10
    74a37e507527:	movabs rsi,0xffffffff0fffffff
    74a37e507531:	and    rbx,rsi
    74a37e507534:	or     rbx,r11
    74a37e507537:	pop    r11
    74a37e507539:	pop    r10
    74a37e50753b:	pop    rsi
    74a37e50753c:	pop    rdx
    74a37e50753d:	mov    QWORD PTR [r12+0x108],rbx
    74a37e507545:	stmxcsr DWORD PTR [r12-0x28]
    74a37e50754b:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e507550:	test   r10d,0x3f
    74a37e507557:	je     0x74a37e50757c
    74a37e50755d:	mov    r11d,r10d
    74a37e507560:	shr    r10d,1
    74a37e507563:	and    r10d,0x1e
    74a37e507567:	and    r11d,0x1
    74a37e50756b:	or     r10d,r11d
    74a37e50756e:	or     DWORD PTR [r12+0x314],r10d
    74a37e507576:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e50757c:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e507582:	lea    rdi,[rsp+0x110]
    74a37e50758a:	lea    rsi,[rsp+0xf0]
    74a37e507592:	lea    rdx,[rsp+0x100]
    74a37e50759a:	mov    ecx,0x14
    74a37e50759f:	mov    r8d,0x0
    74a37e5075a5:	lea    r9,[r12+0x314]
    74a37e5075ad:	movabs r11,0x571546550650
    74a37e5075b7:	call   r11
    74a37e5075ba:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e5075c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e5075c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e5075cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e5075d2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e5075d8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e5075de:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e5075e4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e5075ee:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e5075f8:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e507602:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e50760c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    74a37e507616:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50761e:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50762a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e507633:	mov    rdx,rbx
    74a37e507636:	shr    rdx,0x10
    74a37e50763a:	and    edx,0xc000
    74a37e507640:	mov    rax,rbx
    74a37e507643:	shr    rax,0x15
    74a37e507647:	and    eax,0x100
    74a37e50764c:	xor    eax,0x100
    74a37e507651:	or     edx,eax
    74a37e507653:	mov    rax,rbx
    74a37e507656:	shr    rax,0x1c
    74a37e50765a:	and    eax,0x1
    74a37e50765d:	or     edx,eax
    74a37e50765f:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e507664:	add    rsp,0x8
    74a37e507668:	ret
    74a37e507669:	nop    DWORD PTR [rax+0x0]
    74a37e507670:	sub    rsp,0x8
    74a37e507674:	mov    QWORD PTR [r12+0x378],0x3
    74a37e507680:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e507686:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e50768c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e507692:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e507698:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e50769e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e5076a4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e5076ae:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e5076b8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e5076c2:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e5076cc:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    74a37e5076d6:	push   rdx
    74a37e5076d7:	push   rsi
    74a37e5076d8:	push   r10
    74a37e5076da:	push   r11
    74a37e5076dc:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e5076e1:	mov    r10d,edx
    74a37e5076e4:	and    r10d,0xc000
    74a37e5076eb:	shl    r10d,0x10
    74a37e5076ef:	mov    r11d,edx
    74a37e5076f2:	and    r11d,0x100
    74a37e5076f9:	shl    r11d,0x15
    74a37e5076fd:	or     r10d,r11d
    74a37e507700:	and    edx,0x1
    74a37e507703:	shl    edx,0x1c
    74a37e507706:	or     r10d,edx
    74a37e507709:	btc    r10,0x1d
    74a37e50770e:	mov    r11d,0xf0000000
    74a37e507714:	and    r11,r10
    74a37e507717:	movabs rsi,0xffffffff0fffffff
    74a37e507721:	and    rbx,rsi
    74a37e507724:	or     rbx,r11
    74a37e507727:	pop    r11
    74a37e507729:	pop    r10
    74a37e50772b:	pop    rsi
    74a37e50772c:	pop    rdx
    74a37e50772d:	mov    QWORD PTR [r12+0x108],rbx
    74a37e507735:	stmxcsr DWORD PTR [r12-0x28]
    74a37e50773b:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e507740:	test   r10d,0x3f
    74a37e507747:	je     0x74a37e50776c
    74a37e50774d:	mov    r11d,r10d
    74a37e507750:	shr    r10d,1
    74a37e507753:	and    r10d,0x1e
    74a37e507757:	and    r11d,0x1
    74a37e50775b:	or     r10d,r11d
    74a37e50775e:	or     DWORD PTR [r12+0x314],r10d
    74a37e507766:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e50776c:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e507772:	lea    rdi,[rsp+0x110]
    74a37e50777a:	lea    rsi,[rsp+0xf0]
    74a37e507782:	lea    rdx,[rsp+0x100]
    74a37e50778a:	mov    ecx,0x14
    74a37e50778f:	mov    r8d,0x0
    74a37e507795:	lea    r9,[r12+0x314]
    74a37e50779d:	movabs r11,0x571546550650
    74a37e5077a7:	call   r11
    74a37e5077aa:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e5077b0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e5077b6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e5077bc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e5077c2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e5077c8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e5077ce:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e5077d4:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e5077de:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e5077e8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e5077f2:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e5077fc:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    74a37e507806:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50780e:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50781a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e507823:	mov    rdx,rbx
    74a37e507826:	shr    rdx,0x10
    74a37e50782a:	and    edx,0xc000
    74a37e507830:	mov    rax,rbx
    74a37e507833:	shr    rax,0x15
    74a37e507837:	and    eax,0x100
    74a37e50783c:	xor    eax,0x100
    74a37e507841:	or     edx,eax
    74a37e507843:	mov    rax,rbx
    74a37e507846:	shr    rax,0x1c
    74a37e50784a:	and    eax,0x1
    74a37e50784d:	or     edx,eax
    74a37e50784f:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e507854:	add    rsp,0x8
    74a37e507858:	ret
    74a37e507859:	nop    DWORD PTR [rax+0x0]
    74a37e507860:	sub    rsp,0x8
    74a37e507864:	mov    QWORD PTR [r12+0x378],0x3
    74a37e507870:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e507876:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e50787c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e507882:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e507888:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e50788e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e507894:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e50789e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e5078a8:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e5078b2:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    74a37e5078bc:	push   rdx
    74a37e5078bd:	push   rsi
    74a37e5078be:	push   r10
    74a37e5078c0:	push   r11
    74a37e5078c2:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e5078c7:	mov    r10d,edx
    74a37e5078ca:	and    r10d,0xc000
    74a37e5078d1:	shl    r10d,0x10
    74a37e5078d5:	mov    r11d,edx
    74a37e5078d8:	and    r11d,0x100
    74a37e5078df:	shl    r11d,0x15
    74a37e5078e3:	or     r10d,r11d
    74a37e5078e6:	and    edx,0x1
    74a37e5078e9:	shl    edx,0x1c
    74a37e5078ec:	or     r10d,edx
    74a37e5078ef:	btc    r10,0x1d
    74a37e5078f4:	mov    r11d,0xf0000000
    74a37e5078fa:	and    r11,r10
    74a37e5078fd:	movabs rsi,0xffffffff0fffffff
    74a37e507907:	and    rbx,rsi
    74a37e50790a:	or     rbx,r11
    74a37e50790d:	pop    r11
    74a37e50790f:	pop    r10
    74a37e507911:	pop    rsi
    74a37e507912:	pop    rdx
    74a37e507913:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50791b:	stmxcsr DWORD PTR [r12-0x28]
    74a37e507921:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e507926:	test   r10d,0x3f
    74a37e50792d:	je     0x74a37e507952
    74a37e507933:	mov    r11d,r10d
    74a37e507936:	shr    r10d,1
    74a37e507939:	and    r10d,0x1e
    74a37e50793d:	and    r11d,0x1
    74a37e507941:	or     r10d,r11d
    74a37e507944:	or     DWORD PTR [r12+0x314],r10d
    74a37e50794c:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e507952:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e507958:	lea    rdi,[rsp+0x110]
    74a37e507960:	lea    rsi,[rsp+0xf0]
    74a37e507968:	lea    rdx,[rsp+0x100]
    74a37e507970:	mov    ecx,0x56
    74a37e507975:	mov    r8d,0x0
    74a37e50797b:	lea    r9,[r12+0x314]
    74a37e507983:	movabs r11,0x571546550650
    74a37e50798d:	call   r11
    74a37e507990:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e507996:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e50799c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e5079a2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e5079a8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e5079ae:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e5079b4:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e5079ba:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e5079c4:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e5079ce:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e5079d8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    74a37e5079e2:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e5079ea:	mov    QWORD PTR [r12+0x378],0x2
    74a37e5079f6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e5079ff:	mov    rdx,rbx
    74a37e507a02:	shr    rdx,0x10
    74a37e507a06:	and    edx,0xc000
    74a37e507a0c:	mov    rax,rbx
    74a37e507a0f:	shr    rax,0x15
    74a37e507a13:	and    eax,0x100
    74a37e507a18:	xor    eax,0x100
    74a37e507a1d:	or     edx,eax
    74a37e507a1f:	mov    rax,rbx
    74a37e507a22:	shr    rax,0x1c
    74a37e507a26:	and    eax,0x1
    74a37e507a29:	or     edx,eax
    74a37e507a2b:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e507a30:	add    rsp,0x8
    74a37e507a34:	ret
    74a37e507a35:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e507a40:	sub    rsp,0x8
    74a37e507a44:	mov    QWORD PTR [r12+0x378],0x3
    74a37e507a50:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e507a56:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e507a5c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e507a62:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e507a68:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e507a6e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e507a74:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e507a7e:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e507a88:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e507a92:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    74a37e507a9c:	push   rdx
    74a37e507a9d:	push   rsi
    74a37e507a9e:	push   r10
    74a37e507aa0:	push   r11
    74a37e507aa2:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e507aa7:	mov    r10d,edx
    74a37e507aaa:	and    r10d,0xc000
    74a37e507ab1:	shl    r10d,0x10
    74a37e507ab5:	mov    r11d,edx
    74a37e507ab8:	and    r11d,0x100
    74a37e507abf:	shl    r11d,0x15
    74a37e507ac3:	or     r10d,r11d
    74a37e507ac6:	and    edx,0x1
    74a37e507ac9:	shl    edx,0x1c
    74a37e507acc:	or     r10d,edx
    74a37e507acf:	btc    r10,0x1d
    74a37e507ad4:	mov    r11d,0xf0000000
    74a37e507ada:	and    r11,r10
    74a37e507add:	movabs rsi,0xffffffff0fffffff
    74a37e507ae7:	and    rbx,rsi
    74a37e507aea:	or     rbx,r11
    74a37e507aed:	pop    r11
    74a37e507aef:	pop    r10
    74a37e507af1:	pop    rsi
    74a37e507af2:	pop    rdx
    74a37e507af3:	mov    QWORD PTR [r12+0x108],rbx
    74a37e507afb:	stmxcsr DWORD PTR [r12-0x28]
    74a37e507b01:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e507b06:	test   r10d,0x3f
    74a37e507b0d:	je     0x74a37e507b32
    74a37e507b13:	mov    r11d,r10d
    74a37e507b16:	shr    r10d,1
    74a37e507b19:	and    r10d,0x1e
    74a37e507b1d:	and    r11d,0x1
    74a37e507b21:	or     r10d,r11d
    74a37e507b24:	or     DWORD PTR [r12+0x314],r10d
    74a37e507b2c:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e507b32:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e507b38:	lea    rdi,[rsp+0x110]
    74a37e507b40:	lea    rsi,[rsp+0xf0]
    74a37e507b48:	lea    rdx,[rsp+0x100]
    74a37e507b50:	mov    ecx,0x14
    74a37e507b55:	mov    r8d,0x0
    74a37e507b5b:	lea    r9,[r12+0x314]
    74a37e507b63:	movabs r11,0x571546550650
    74a37e507b6d:	call   r11
    74a37e507b70:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e507b76:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e507b7c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e507b82:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e507b88:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e507b8e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e507b94:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e507b9a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e507ba4:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e507bae:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e507bb8:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    74a37e507bc2:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e507bca:	mov    QWORD PTR [r12+0x378],0x2
    74a37e507bd6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e507bdf:	mov    rdx,rbx
    74a37e507be2:	shr    rdx,0x10
    74a37e507be6:	and    edx,0xc000
    74a37e507bec:	mov    rax,rbx
    74a37e507bef:	shr    rax,0x15
    74a37e507bf3:	and    eax,0x100
    74a37e507bf8:	xor    eax,0x100
    74a37e507bfd:	or     edx,eax
    74a37e507bff:	mov    rax,rbx
    74a37e507c02:	shr    rax,0x1c
    74a37e507c06:	and    eax,0x1
    74a37e507c09:	or     edx,eax
    74a37e507c0b:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e507c10:	add    rsp,0x8
    74a37e507c14:	ret
    74a37e507c15:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e507c20:	sub    rsp,0x8
    74a37e507c24:	mov    QWORD PTR [r12+0x378],0x3
    74a37e507c30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e507c36:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e507c3c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e507c42:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e507c48:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e507c4e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e507c58:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e507c62:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e507c6c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e507c76:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    74a37e507c80:	push   rdx
    74a37e507c81:	push   rsi
    74a37e507c82:	push   r10
    74a37e507c84:	push   r11
    74a37e507c86:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e507c8b:	mov    r10d,edx
    74a37e507c8e:	and    r10d,0xc000
    74a37e507c95:	shl    r10d,0x10
    74a37e507c99:	mov    r11d,edx
    74a37e507c9c:	and    r11d,0x100
    74a37e507ca3:	shl    r11d,0x15
    74a37e507ca7:	or     r10d,r11d
    74a37e507caa:	and    edx,0x1
    74a37e507cad:	shl    edx,0x1c
    74a37e507cb0:	or     r10d,edx
    74a37e507cb3:	btc    r10,0x1d
    74a37e507cb8:	mov    r11d,0xf0000000
    74a37e507cbe:	and    r11,r10
    74a37e507cc1:	movabs rsi,0xffffffff0fffffff
    74a37e507ccb:	and    rbx,rsi
    74a37e507cce:	or     rbx,r11
    74a37e507cd1:	pop    r11
    74a37e507cd3:	pop    r10
    74a37e507cd5:	pop    rsi
    74a37e507cd6:	pop    rdx
    74a37e507cd7:	mov    QWORD PTR [r12+0x108],rbx
    74a37e507cdf:	stmxcsr DWORD PTR [r12-0x28]
    74a37e507ce5:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e507cea:	test   r10d,0x3f
    74a37e507cf1:	je     0x74a37e507d16
    74a37e507cf7:	mov    r11d,r10d
    74a37e507cfa:	shr    r10d,1
    74a37e507cfd:	and    r10d,0x1e
    74a37e507d01:	and    r11d,0x1
    74a37e507d05:	or     r10d,r11d
    74a37e507d08:	or     DWORD PTR [r12+0x314],r10d
    74a37e507d10:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e507d16:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e507d1c:	lea    rdi,[rsp+0x110]
    74a37e507d24:	lea    rsi,[rsp+0xf0]
    74a37e507d2c:	lea    rdx,[rsp+0x100]
    74a37e507d34:	mov    ecx,0x56
    74a37e507d39:	mov    r8d,0x0
    74a37e507d3f:	lea    r9,[r12+0x314]
    74a37e507d47:	movabs r11,0x571546550650
    74a37e507d51:	call   r11
    74a37e507d54:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e507d5a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e507d60:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e507d66:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e507d6c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e507d72:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e507d78:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e507d82:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e507d8c:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e507d96:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e507da0:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    74a37e507daa:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e507db2:	mov    QWORD PTR [r12+0x378],0x2
    74a37e507dbe:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e507dc7:	mov    rdx,rbx
    74a37e507dca:	shr    rdx,0x10
    74a37e507dce:	and    edx,0xc000
    74a37e507dd4:	mov    rax,rbx
    74a37e507dd7:	shr    rax,0x15
    74a37e507ddb:	and    eax,0x100
    74a37e507de0:	xor    eax,0x100
    74a37e507de5:	or     edx,eax
    74a37e507de7:	mov    rax,rbx
    74a37e507dea:	shr    rax,0x1c
    74a37e507dee:	and    eax,0x1
    74a37e507df1:	or     edx,eax
    74a37e507df3:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e507df8:	add    rsp,0x8
    74a37e507dfc:	ret
    74a37e507dfd:	nop    DWORD PTR [rax]
    74a37e507e00:	sub    rsp,0x8
    74a37e507e04:	mov    QWORD PTR [r12+0x378],0x3
    74a37e507e10:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e507e16:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e507e1c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e507e22:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e507e28:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e507e2e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e507e34:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e507e3e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e507e48:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e507e52:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e507e5c:	push   rdx
    74a37e507e5d:	push   rsi
    74a37e507e5e:	push   r10
    74a37e507e60:	push   r11
    74a37e507e62:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e507e67:	mov    r10d,edx
    74a37e507e6a:	and    r10d,0xc000
    74a37e507e71:	shl    r10d,0x10
    74a37e507e75:	mov    r11d,edx
    74a37e507e78:	and    r11d,0x100
    74a37e507e7f:	shl    r11d,0x15
    74a37e507e83:	or     r10d,r11d
    74a37e507e86:	and    edx,0x1
    74a37e507e89:	shl    edx,0x1c
    74a37e507e8c:	or     r10d,edx
    74a37e507e8f:	btc    r10,0x1d
    74a37e507e94:	mov    r11d,0xf0000000
    74a37e507e9a:	and    r11,r10
    74a37e507e9d:	movabs rsi,0xffffffff0fffffff
    74a37e507ea7:	and    rbx,rsi
    74a37e507eaa:	or     rbx,r11
    74a37e507ead:	pop    r11
    74a37e507eaf:	pop    r10
    74a37e507eb1:	pop    rsi
    74a37e507eb2:	pop    rdx
    74a37e507eb3:	mov    QWORD PTR [r12+0x108],rbx
    74a37e507ebb:	stmxcsr DWORD PTR [r12-0x28]
    74a37e507ec1:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e507ec6:	test   r10d,0x3f
    74a37e507ecd:	je     0x74a37e507ef2
    74a37e507ed3:	mov    r11d,r10d
    74a37e507ed6:	shr    r10d,1
    74a37e507ed9:	and    r10d,0x1e
    74a37e507edd:	and    r11d,0x1
    74a37e507ee1:	or     r10d,r11d
    74a37e507ee4:	or     DWORD PTR [r12+0x314],r10d
    74a37e507eec:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e507ef2:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e507ef8:	lea    rdi,[rsp+0x110]
    74a37e507f00:	lea    rsi,[rsp+0xf0]
    74a37e507f08:	lea    rdx,[rsp+0x100]
    74a37e507f10:	mov    ecx,0x56
    74a37e507f15:	mov    r8d,0x0
    74a37e507f1b:	lea    r9,[r12+0x314]
    74a37e507f23:	movabs r11,0x571546550650
    74a37e507f2d:	call   r11
    74a37e507f30:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e507f36:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e507f3c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e507f42:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e507f48:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e507f4e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e507f54:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e507f5a:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e507f64:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e507f6e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e507f78:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e507f82:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e507f8a:	mov    QWORD PTR [r12+0x378],0x2
    74a37e507f96:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e507f9f:	mov    rdx,rbx
    74a37e507fa2:	shr    rdx,0x10
    74a37e507fa6:	and    edx,0xc000
    74a37e507fac:	mov    rax,rbx
    74a37e507faf:	shr    rax,0x15
    74a37e507fb3:	and    eax,0x100
    74a37e507fb8:	xor    eax,0x100
    74a37e507fbd:	or     edx,eax
    74a37e507fbf:	mov    rax,rbx
    74a37e507fc2:	shr    rax,0x1c
    74a37e507fc6:	and    eax,0x1
    74a37e507fc9:	or     edx,eax
    74a37e507fcb:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e507fd0:	add    rsp,0x8
    74a37e507fd4:	ret
    74a37e507fd5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e507fe0:	sub    rsp,0x8
    74a37e507fe4:	mov    QWORD PTR [r12+0x378],0x3
    74a37e507ff0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e507ff6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e507ffc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e508002:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e508008:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e50800e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e508014:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e50801e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e508028:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e508032:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e50803c:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    74a37e508046:	push   rdx
    74a37e508047:	push   rsi
    74a37e508048:	push   r10
    74a37e50804a:	push   r11
    74a37e50804c:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e508051:	mov    r10d,edx
    74a37e508054:	and    r10d,0xc000
    74a37e50805b:	shl    r10d,0x10
    74a37e50805f:	mov    r11d,edx
    74a37e508062:	and    r11d,0x100
    74a37e508069:	shl    r11d,0x15
    74a37e50806d:	or     r10d,r11d
    74a37e508070:	and    edx,0x1
    74a37e508073:	shl    edx,0x1c
    74a37e508076:	or     r10d,edx
    74a37e508079:	btc    r10,0x1d
    74a37e50807e:	mov    r11d,0xf0000000
    74a37e508084:	and    r11,r10
    74a37e508087:	movabs rsi,0xffffffff0fffffff
    74a37e508091:	and    rbx,rsi
    74a37e508094:	or     rbx,r11
    74a37e508097:	pop    r11
    74a37e508099:	pop    r10
    74a37e50809b:	pop    rsi
    74a37e50809c:	pop    rdx
    74a37e50809d:	mov    QWORD PTR [r12+0x108],rbx
    74a37e5080a5:	stmxcsr DWORD PTR [r12-0x28]
    74a37e5080ab:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e5080b0:	test   r10d,0x3f
    74a37e5080b7:	je     0x74a37e5080dc
    74a37e5080bd:	mov    r11d,r10d
    74a37e5080c0:	shr    r10d,1
    74a37e5080c3:	and    r10d,0x1e
    74a37e5080c7:	and    r11d,0x1
    74a37e5080cb:	or     r10d,r11d
    74a37e5080ce:	or     DWORD PTR [r12+0x314],r10d
    74a37e5080d6:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e5080dc:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e5080e2:	lea    rdi,[rsp+0x110]
    74a37e5080ea:	lea    rsi,[rsp+0xf0]
    74a37e5080f2:	lea    rdx,[rsp+0x100]
    74a37e5080fa:	mov    ecx,0x14
    74a37e5080ff:	mov    r8d,0x0
    74a37e508105:	lea    r9,[r12+0x314]
    74a37e50810d:	movabs r11,0x571546550650
    74a37e508117:	call   r11
    74a37e50811a:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e508120:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e508126:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e50812c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e508132:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e508138:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e50813e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e508144:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e50814e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e508158:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e508162:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e50816c:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    74a37e508176:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50817e:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50818a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e508193:	mov    rdx,rbx
    74a37e508196:	shr    rdx,0x10
    74a37e50819a:	and    edx,0xc000
    74a37e5081a0:	mov    rax,rbx
    74a37e5081a3:	shr    rax,0x15
    74a37e5081a7:	and    eax,0x100
    74a37e5081ac:	xor    eax,0x100
    74a37e5081b1:	or     edx,eax
    74a37e5081b3:	mov    rax,rbx
    74a37e5081b6:	shr    rax,0x1c
    74a37e5081ba:	and    eax,0x1
    74a37e5081bd:	or     edx,eax
    74a37e5081bf:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e5081c4:	add    rsp,0x8
    74a37e5081c8:	ret
    74a37e5081c9:	nop    DWORD PTR [rax+0x0]
    74a37e5081d0:	sub    rsp,0x8
    74a37e5081d4:	mov    QWORD PTR [r12+0x378],0x3
    74a37e5081e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e5081e6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e5081ec:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e5081f2:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e5081f8:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e508202:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e50820c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e508216:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e508220:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e50822a:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    74a37e508234:	push   rdx
    74a37e508235:	push   rsi
    74a37e508236:	push   r10
    74a37e508238:	push   r11
    74a37e50823a:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e50823f:	mov    r10d,edx
    74a37e508242:	and    r10d,0xc000
    74a37e508249:	shl    r10d,0x10
    74a37e50824d:	mov    r11d,edx
    74a37e508250:	and    r11d,0x100
    74a37e508257:	shl    r11d,0x15
    74a37e50825b:	or     r10d,r11d
    74a37e50825e:	and    edx,0x1
    74a37e508261:	shl    edx,0x1c
    74a37e508264:	or     r10d,edx
    74a37e508267:	btc    r10,0x1d
    74a37e50826c:	mov    r11d,0xf0000000
    74a37e508272:	and    r11,r10
    74a37e508275:	movabs rsi,0xffffffff0fffffff
    74a37e50827f:	and    rbx,rsi
    74a37e508282:	or     rbx,r11
    74a37e508285:	pop    r11
    74a37e508287:	pop    r10
    74a37e508289:	pop    rsi
    74a37e50828a:	pop    rdx
    74a37e50828b:	mov    QWORD PTR [r12+0x108],rbx
    74a37e508293:	stmxcsr DWORD PTR [r12-0x28]
    74a37e508299:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e50829e:	test   r10d,0x3f
    74a37e5082a5:	je     0x74a37e5082ca
    74a37e5082ab:	mov    r11d,r10d
    74a37e5082ae:	shr    r10d,1
    74a37e5082b1:	and    r10d,0x1e
    74a37e5082b5:	and    r11d,0x1
    74a37e5082b9:	or     r10d,r11d
    74a37e5082bc:	or     DWORD PTR [r12+0x314],r10d
    74a37e5082c4:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e5082ca:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e5082d0:	lea    rdi,[rsp+0x110]
    74a37e5082d8:	lea    rsi,[rsp+0xf0]
    74a37e5082e0:	lea    rdx,[rsp+0x100]
    74a37e5082e8:	mov    ecx,0x56
    74a37e5082ed:	mov    r8d,0x0
    74a37e5082f3:	lea    r9,[r12+0x314]
    74a37e5082fb:	movabs r11,0x571546550650
    74a37e508305:	call   r11
    74a37e508308:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e50830e:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e508314:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e50831a:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e508320:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e508326:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e508330:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e50833a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e508344:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e50834e:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e508358:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    74a37e508362:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50836a:	mov    QWORD PTR [r12+0x378],0x2
    74a37e508376:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e50837f:	mov    rdx,rbx
    74a37e508382:	shr    rdx,0x10
    74a37e508386:	and    edx,0xc000
    74a37e50838c:	mov    rax,rbx
    74a37e50838f:	shr    rax,0x15
    74a37e508393:	and    eax,0x100
    74a37e508398:	xor    eax,0x100
    74a37e50839d:	or     edx,eax
    74a37e50839f:	mov    rax,rbx
    74a37e5083a2:	shr    rax,0x1c
    74a37e5083a6:	and    eax,0x1
    74a37e5083a9:	or     edx,eax
    74a37e5083ab:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e5083b0:	add    rsp,0x8
    74a37e5083b4:	ret
    74a37e5083b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e5083c0:	sub    rsp,0x8
    74a37e5083c4:	mov    QWORD PTR [r12+0x378],0x3
    74a37e5083d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e5083d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e5083dc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e5083e2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e5083e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e5083ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e5083f8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e508402:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e50840c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e508416:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e508420:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    74a37e50842a:	push   rdx
    74a37e50842b:	push   rsi
    74a37e50842c:	push   r10
    74a37e50842e:	push   r11
    74a37e508430:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e508435:	mov    r10d,edx
    74a37e508438:	and    r10d,0xc000
    74a37e50843f:	shl    r10d,0x10
    74a37e508443:	mov    r11d,edx
    74a37e508446:	and    r11d,0x100
    74a37e50844d:	shl    r11d,0x15
    74a37e508451:	or     r10d,r11d
    74a37e508454:	and    edx,0x1
    74a37e508457:	shl    edx,0x1c
    74a37e50845a:	or     r10d,edx
    74a37e50845d:	btc    r10,0x1d
    74a37e508462:	mov    r11d,0xf0000000
    74a37e508468:	and    r11,r10
    74a37e50846b:	movabs rsi,0xffffffff0fffffff
    74a37e508475:	and    rbx,rsi
    74a37e508478:	or     rbx,r11
    74a37e50847b:	pop    r11
    74a37e50847d:	pop    r10
    74a37e50847f:	pop    rsi
    74a37e508480:	pop    rdx
    74a37e508481:	mov    QWORD PTR [r12+0x108],rbx
    74a37e508489:	stmxcsr DWORD PTR [r12-0x28]
    74a37e50848f:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e508494:	test   r10d,0x3f
    74a37e50849b:	je     0x74a37e5084c0
    74a37e5084a1:	mov    r11d,r10d
    74a37e5084a4:	shr    r10d,1
    74a37e5084a7:	and    r10d,0x1e
    74a37e5084ab:	and    r11d,0x1
    74a37e5084af:	or     r10d,r11d
    74a37e5084b2:	or     DWORD PTR [r12+0x314],r10d
    74a37e5084ba:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e5084c0:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e5084c6:	lea    rdi,[rsp+0x110]
    74a37e5084ce:	lea    rsi,[rsp+0xf0]
    74a37e5084d6:	lea    rdx,[rsp+0x100]
    74a37e5084de:	mov    ecx,0x14
    74a37e5084e3:	mov    r8d,0x0
    74a37e5084e9:	lea    r9,[r12+0x314]
    74a37e5084f1:	movabs r11,0x571546550650
    74a37e5084fb:	call   r11
    74a37e5084fe:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e508504:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e50850a:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e508510:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e508516:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e50851c:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e508522:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e50852c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e508536:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e508540:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e50854a:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e508554:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    74a37e50855e:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e508566:	mov    QWORD PTR [r12+0x378],0x2
    74a37e508572:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e50857b:	mov    rdx,rbx
    74a37e50857e:	shr    rdx,0x10
    74a37e508582:	and    edx,0xc000
    74a37e508588:	mov    rax,rbx
    74a37e50858b:	shr    rax,0x15
    74a37e50858f:	and    eax,0x100
    74a37e508594:	xor    eax,0x100
    74a37e508599:	or     edx,eax
    74a37e50859b:	mov    rax,rbx
    74a37e50859e:	shr    rax,0x1c
    74a37e5085a2:	and    eax,0x1
    74a37e5085a5:	or     edx,eax
    74a37e5085a7:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e5085ac:	add    rsp,0x8
    74a37e5085b0:	ret
    74a37e5085b1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e5085c0:	sub    rsp,0x8
    74a37e5085c4:	mov    QWORD PTR [r12+0x378],0x3
    74a37e5085d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e5085d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e5085dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e5085e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e5085e8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e5085ee:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e5085f4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e5085fe:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e508608:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e508612:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    74a37e50861c:	push   rdx
    74a37e50861d:	push   rsi
    74a37e50861e:	push   r10
    74a37e508620:	push   r11
    74a37e508622:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e508627:	mov    r10d,edx
    74a37e50862a:	and    r10d,0xc000
    74a37e508631:	shl    r10d,0x10
    74a37e508635:	mov    r11d,edx
    74a37e508638:	and    r11d,0x100
    74a37e50863f:	shl    r11d,0x15
    74a37e508643:	or     r10d,r11d
    74a37e508646:	and    edx,0x1
    74a37e508649:	shl    edx,0x1c
    74a37e50864c:	or     r10d,edx
    74a37e50864f:	btc    r10,0x1d
    74a37e508654:	mov    r11d,0xf0000000
    74a37e50865a:	and    r11,r10
    74a37e50865d:	movabs rsi,0xffffffff0fffffff
    74a37e508667:	and    rbx,rsi
    74a37e50866a:	or     rbx,r11
    74a37e50866d:	pop    r11
    74a37e50866f:	pop    r10
    74a37e508671:	pop    rsi
    74a37e508672:	pop    rdx
    74a37e508673:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50867b:	stmxcsr DWORD PTR [r12-0x28]
    74a37e508681:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e508686:	test   r10d,0x3f
    74a37e50868d:	je     0x74a37e5086b2
    74a37e508693:	mov    r11d,r10d
    74a37e508696:	shr    r10d,1
    74a37e508699:	and    r10d,0x1e
    74a37e50869d:	and    r11d,0x1
    74a37e5086a1:	or     r10d,r11d
    74a37e5086a4:	or     DWORD PTR [r12+0x314],r10d
    74a37e5086ac:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e5086b2:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e5086b8:	lea    rdi,[rsp+0x110]
    74a37e5086c0:	lea    rsi,[rsp+0xf0]
    74a37e5086c8:	lea    rdx,[rsp+0x100]
    74a37e5086d0:	mov    ecx,0x56
    74a37e5086d5:	mov    r8d,0x0
    74a37e5086db:	lea    r9,[r12+0x314]
    74a37e5086e3:	movabs r11,0x571546550650
    74a37e5086ed:	call   r11
    74a37e5086f0:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e5086f6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e5086fc:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e508702:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e508708:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e50870e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e508714:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e50871a:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e508724:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e50872e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e508738:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    74a37e508742:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50874a:	mov    QWORD PTR [r12+0x378],0x2
    74a37e508756:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e50875f:	mov    rdx,rbx
    74a37e508762:	shr    rdx,0x10
    74a37e508766:	and    edx,0xc000
    74a37e50876c:	mov    rax,rbx
    74a37e50876f:	shr    rax,0x15
    74a37e508773:	and    eax,0x100
    74a37e508778:	xor    eax,0x100
    74a37e50877d:	or     edx,eax
    74a37e50877f:	mov    rax,rbx
    74a37e508782:	shr    rax,0x1c
    74a37e508786:	and    eax,0x1
    74a37e508789:	or     edx,eax
    74a37e50878b:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e508790:	add    rsp,0x8
    74a37e508794:	ret
    74a37e508795:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e5087a0:	sub    rsp,0x8
    74a37e5087a4:	mov    QWORD PTR [r12+0x378],0x3
    74a37e5087b0:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e5087b6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e5087bc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e5087c2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e5087c8:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e5087d2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e5087dc:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e5087e6:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e5087f0:	movdqu XMMWORD PTR [rsp+0xd0],xmm13
    74a37e5087fa:	push   rdx
    74a37e5087fb:	push   rsi
    74a37e5087fc:	push   r10
    74a37e5087fe:	push   r11
    74a37e508800:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e508805:	mov    r10d,edx
    74a37e508808:	and    r10d,0xc000
    74a37e50880f:	shl    r10d,0x10
    74a37e508813:	mov    r11d,edx
    74a37e508816:	and    r11d,0x100
    74a37e50881d:	shl    r11d,0x15
    74a37e508821:	or     r10d,r11d
    74a37e508824:	and    edx,0x1
    74a37e508827:	shl    edx,0x1c
    74a37e50882a:	or     r10d,edx
    74a37e50882d:	btc    r10,0x1d
    74a37e508832:	mov    r11d,0xf0000000
    74a37e508838:	and    r11,r10
    74a37e50883b:	movabs rsi,0xffffffff0fffffff
    74a37e508845:	and    rbx,rsi
    74a37e508848:	or     rbx,r11
    74a37e50884b:	pop    r11
    74a37e50884d:	pop    r10
    74a37e50884f:	pop    rsi
    74a37e508850:	pop    rdx
    74a37e508851:	mov    QWORD PTR [r12+0x108],rbx
    74a37e508859:	stmxcsr DWORD PTR [r12-0x28]
    74a37e50885f:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e508864:	test   r10d,0x3f
    74a37e50886b:	je     0x74a37e508890
    74a37e508871:	mov    r11d,r10d
    74a37e508874:	shr    r10d,1
    74a37e508877:	and    r10d,0x1e
    74a37e50887b:	and    r11d,0x1
    74a37e50887f:	or     r10d,r11d
    74a37e508882:	or     DWORD PTR [r12+0x314],r10d
    74a37e50888a:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e508890:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e508896:	lea    rdi,[rsp+0x110]
    74a37e50889e:	lea    rsi,[rsp+0xf0]
    74a37e5088a6:	lea    rdx,[rsp+0x100]
    74a37e5088ae:	mov    ecx,0x14
    74a37e5088b3:	mov    r8d,0x0
    74a37e5088b9:	lea    r9,[r12+0x314]
    74a37e5088c1:	movabs r11,0x571546550650
    74a37e5088cb:	call   r11
    74a37e5088ce:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e5088d4:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e5088da:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e5088e0:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e5088e6:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e5088ec:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e5088f6:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e508900:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e50890a:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e508914:	movdqu xmm13,XMMWORD PTR [rsp+0xd0]
    74a37e50891e:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e508926:	mov    QWORD PTR [r12+0x378],0x2
    74a37e508932:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e50893b:	mov    rdx,rbx
    74a37e50893e:	shr    rdx,0x10
    74a37e508942:	and    edx,0xc000
    74a37e508948:	mov    rax,rbx
    74a37e50894b:	shr    rax,0x15
    74a37e50894f:	and    eax,0x100
    74a37e508954:	xor    eax,0x100
    74a37e508959:	or     edx,eax
    74a37e50895b:	mov    rax,rbx
    74a37e50895e:	shr    rax,0x1c
    74a37e508962:	and    eax,0x1
    74a37e508965:	or     edx,eax
    74a37e508967:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e50896c:	add    rsp,0x8
    74a37e508970:	ret
    74a37e508971:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e508980:	sub    rsp,0x8
    74a37e508984:	mov    QWORD PTR [r12+0x378],0x3
    74a37e508990:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e508996:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e50899c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e5089a2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e5089a8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e5089ae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e5089b4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e5089be:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e5089c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e5089d2:	push   rdx
    74a37e5089d3:	push   rsi
    74a37e5089d4:	push   r10
    74a37e5089d6:	push   r11
    74a37e5089d8:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e5089dd:	mov    r10d,edx
    74a37e5089e0:	and    r10d,0xc000
    74a37e5089e7:	shl    r10d,0x10
    74a37e5089eb:	mov    r11d,edx
    74a37e5089ee:	and    r11d,0x100
    74a37e5089f5:	shl    r11d,0x15
    74a37e5089f9:	or     r10d,r11d
    74a37e5089fc:	and    edx,0x1
    74a37e5089ff:	shl    edx,0x1c
    74a37e508a02:	or     r10d,edx
    74a37e508a05:	btc    r10,0x1d
    74a37e508a0a:	mov    r11d,0xf0000000
    74a37e508a10:	and    r11,r10
    74a37e508a13:	movabs rsi,0xffffffff0fffffff
    74a37e508a1d:	and    rbx,rsi
    74a37e508a20:	or     rbx,r11
    74a37e508a23:	pop    r11
    74a37e508a25:	pop    r10
    74a37e508a27:	pop    rsi
    74a37e508a28:	pop    rdx
    74a37e508a29:	mov    QWORD PTR [r12+0x108],rbx
    74a37e508a31:	stmxcsr DWORD PTR [r12-0x28]
    74a37e508a37:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e508a3c:	test   r10d,0x3f
    74a37e508a43:	je     0x74a37e508a68
    74a37e508a49:	mov    r11d,r10d
    74a37e508a4c:	shr    r10d,1
    74a37e508a4f:	and    r10d,0x1e
    74a37e508a53:	and    r11d,0x1
    74a37e508a57:	or     r10d,r11d
    74a37e508a5a:	or     DWORD PTR [r12+0x314],r10d
    74a37e508a62:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e508a68:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e508a6e:	lea    rdi,[rsp+0x110]
    74a37e508a76:	lea    rsi,[rsp+0xf0]
    74a37e508a7e:	lea    rdx,[rsp+0x100]
    74a37e508a86:	mov    ecx,0x56
    74a37e508a8b:	mov    r8d,0x0
    74a37e508a91:	lea    r9,[r12+0x314]
    74a37e508a99:	movabs r11,0x571546550650
    74a37e508aa3:	call   r11
    74a37e508aa6:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e508aac:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e508ab2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e508ab8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e508abe:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e508ac4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e508aca:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e508ad0:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e508ada:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e508ae4:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e508aee:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e508af6:	mov    QWORD PTR [r12+0x378],0x2
    74a37e508b02:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e508b0b:	mov    rdx,rbx
    74a37e508b0e:	shr    rdx,0x10
    74a37e508b12:	and    edx,0xc000
    74a37e508b18:	mov    rax,rbx
    74a37e508b1b:	shr    rax,0x15
    74a37e508b1f:	and    eax,0x100
    74a37e508b24:	xor    eax,0x100
    74a37e508b29:	or     edx,eax
    74a37e508b2b:	mov    rax,rbx
    74a37e508b2e:	shr    rax,0x1c
    74a37e508b32:	and    eax,0x1
    74a37e508b35:	or     edx,eax
    74a37e508b37:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e508b3c:	add    rsp,0x8
    74a37e508b40:	ret
    74a37e508b41:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e508b50:	sub    rsp,0x8
    74a37e508b54:	mov    QWORD PTR [r12+0x378],0x3
    74a37e508b60:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e508b66:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e508b6c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e508b72:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e508b78:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e508b7e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e508b88:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e508b92:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e508b9c:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e508ba6:	push   rdx
    74a37e508ba7:	push   rsi
    74a37e508ba8:	push   r10
    74a37e508baa:	push   r11
    74a37e508bac:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e508bb1:	mov    r10d,edx
    74a37e508bb4:	and    r10d,0xc000
    74a37e508bbb:	shl    r10d,0x10
    74a37e508bbf:	mov    r11d,edx
    74a37e508bc2:	and    r11d,0x100
    74a37e508bc9:	shl    r11d,0x15
    74a37e508bcd:	or     r10d,r11d
    74a37e508bd0:	and    edx,0x1
    74a37e508bd3:	shl    edx,0x1c
    74a37e508bd6:	or     r10d,edx
    74a37e508bd9:	btc    r10,0x1d
    74a37e508bde:	mov    r11d,0xf0000000
    74a37e508be4:	and    r11,r10
    74a37e508be7:	movabs rsi,0xffffffff0fffffff
    74a37e508bf1:	and    rbx,rsi
    74a37e508bf4:	or     rbx,r11
    74a37e508bf7:	pop    r11
    74a37e508bf9:	pop    r10
    74a37e508bfb:	pop    rsi
    74a37e508bfc:	pop    rdx
    74a37e508bfd:	mov    QWORD PTR [r12+0x108],rbx
    74a37e508c05:	stmxcsr DWORD PTR [r12-0x28]
    74a37e508c0b:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e508c10:	test   r10d,0x3f
    74a37e508c17:	je     0x74a37e508c3c
    74a37e508c1d:	mov    r11d,r10d
    74a37e508c20:	shr    r10d,1
    74a37e508c23:	and    r10d,0x1e
    74a37e508c27:	and    r11d,0x1
    74a37e508c2b:	or     r10d,r11d
    74a37e508c2e:	or     DWORD PTR [r12+0x314],r10d
    74a37e508c36:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e508c3c:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e508c42:	lea    rdi,[rsp+0x110]
    74a37e508c4a:	lea    rsi,[rsp+0xf0]
    74a37e508c52:	lea    rdx,[rsp+0x100]
    74a37e508c5a:	mov    ecx,0x56
    74a37e508c5f:	mov    r8d,0x0
    74a37e508c65:	lea    r9,[r12+0x314]
    74a37e508c6d:	movabs r11,0x571546550650
    74a37e508c77:	call   r11
    74a37e508c7a:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e508c80:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e508c86:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e508c8c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e508c92:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e508c98:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e508c9e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e508ca8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e508cb2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e508cbc:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e508cc6:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e508cce:	mov    QWORD PTR [r12+0x378],0x2
    74a37e508cda:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e508ce3:	mov    rdx,rbx
    74a37e508ce6:	shr    rdx,0x10
    74a37e508cea:	and    edx,0xc000
    74a37e508cf0:	mov    rax,rbx
    74a37e508cf3:	shr    rax,0x15
    74a37e508cf7:	and    eax,0x100
    74a37e508cfc:	xor    eax,0x100
    74a37e508d01:	or     edx,eax
    74a37e508d03:	mov    rax,rbx
    74a37e508d06:	shr    rax,0x1c
    74a37e508d0a:	and    eax,0x1
    74a37e508d0d:	or     edx,eax
    74a37e508d0f:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e508d14:	add    rsp,0x8
    74a37e508d18:	ret
    74a37e508d19:	nop    DWORD PTR [rax+0x0]
    74a37e508d20:	sub    rsp,0x8
    74a37e508d24:	mov    QWORD PTR [r12+0x378],0x3
    74a37e508d30:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e508d36:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e508d3c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e508d42:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e508d48:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e508d4e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e508d54:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e508d5e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e508d68:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e508d72:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e508d7c:	push   rdx
    74a37e508d7d:	push   rsi
    74a37e508d7e:	push   r10
    74a37e508d80:	push   r11
    74a37e508d82:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e508d87:	mov    r10d,edx
    74a37e508d8a:	and    r10d,0xc000
    74a37e508d91:	shl    r10d,0x10
    74a37e508d95:	mov    r11d,edx
    74a37e508d98:	and    r11d,0x100
    74a37e508d9f:	shl    r11d,0x15
    74a37e508da3:	or     r10d,r11d
    74a37e508da6:	and    edx,0x1
    74a37e508da9:	shl    edx,0x1c
    74a37e508dac:	or     r10d,edx
    74a37e508daf:	btc    r10,0x1d
    74a37e508db4:	mov    r11d,0xf0000000
    74a37e508dba:	and    r11,r10
    74a37e508dbd:	movabs rsi,0xffffffff0fffffff
    74a37e508dc7:	and    rbx,rsi
    74a37e508dca:	or     rbx,r11
    74a37e508dcd:	pop    r11
    74a37e508dcf:	pop    r10
    74a37e508dd1:	pop    rsi
    74a37e508dd2:	pop    rdx
    74a37e508dd3:	mov    QWORD PTR [r12+0x108],rbx
    74a37e508ddb:	stmxcsr DWORD PTR [r12-0x28]
    74a37e508de1:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e508de6:	test   r10d,0x3f
    74a37e508ded:	je     0x74a37e508e12
    74a37e508df3:	mov    r11d,r10d
    74a37e508df6:	shr    r10d,1
    74a37e508df9:	and    r10d,0x1e
    74a37e508dfd:	and    r11d,0x1
    74a37e508e01:	or     r10d,r11d
    74a37e508e04:	or     DWORD PTR [r12+0x314],r10d
    74a37e508e0c:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e508e12:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e508e18:	lea    rdi,[rsp+0x110]
    74a37e508e20:	lea    rsi,[rsp+0xf0]
    74a37e508e28:	lea    rdx,[rsp+0x100]
    74a37e508e30:	mov    ecx,0x14
    74a37e508e35:	mov    r8d,0x0
    74a37e508e3b:	lea    r9,[r12+0x314]
    74a37e508e43:	movabs r11,0x571546550650
    74a37e508e4d:	call   r11
    74a37e508e50:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e508e56:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e508e5c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e508e62:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e508e68:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e508e6e:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e508e74:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e508e7a:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e508e84:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e508e8e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e508e98:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e508ea2:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e508eaa:	mov    QWORD PTR [r12+0x378],0x2
    74a37e508eb6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e508ebf:	mov    rdx,rbx
    74a37e508ec2:	shr    rdx,0x10
    74a37e508ec6:	and    edx,0xc000
    74a37e508ecc:	mov    rax,rbx
    74a37e508ecf:	shr    rax,0x15
    74a37e508ed3:	and    eax,0x100
    74a37e508ed8:	xor    eax,0x100
    74a37e508edd:	or     edx,eax
    74a37e508edf:	mov    rax,rbx
    74a37e508ee2:	shr    rax,0x1c
    74a37e508ee6:	and    eax,0x1
    74a37e508ee9:	or     edx,eax
    74a37e508eeb:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e508ef0:	add    rsp,0x8
    74a37e508ef4:	ret
    74a37e508ef5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e508f00:	sub    rsp,0x8
    74a37e508f04:	mov    QWORD PTR [r12+0x378],0x3
    74a37e508f10:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e508f16:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e508f1c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e508f22:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e508f28:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e508f2e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e508f38:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e508f42:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e508f4c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e508f56:	push   rdx
    74a37e508f57:	push   rsi
    74a37e508f58:	push   r10
    74a37e508f5a:	push   r11
    74a37e508f5c:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e508f61:	mov    r10d,edx
    74a37e508f64:	and    r10d,0xc000
    74a37e508f6b:	shl    r10d,0x10
    74a37e508f6f:	mov    r11d,edx
    74a37e508f72:	and    r11d,0x100
    74a37e508f79:	shl    r11d,0x15
    74a37e508f7d:	or     r10d,r11d
    74a37e508f80:	and    edx,0x1
    74a37e508f83:	shl    edx,0x1c
    74a37e508f86:	or     r10d,edx
    74a37e508f89:	btc    r10,0x1d
    74a37e508f8e:	mov    r11d,0xf0000000
    74a37e508f94:	and    r11,r10
    74a37e508f97:	movabs rsi,0xffffffff0fffffff
    74a37e508fa1:	and    rbx,rsi
    74a37e508fa4:	or     rbx,r11
    74a37e508fa7:	pop    r11
    74a37e508fa9:	pop    r10
    74a37e508fab:	pop    rsi
    74a37e508fac:	pop    rdx
    74a37e508fad:	mov    QWORD PTR [r12+0x108],rbx
    74a37e508fb5:	stmxcsr DWORD PTR [r12-0x28]
    74a37e508fbb:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e508fc0:	test   r10d,0x3f
    74a37e508fc7:	je     0x74a37e508fec
    74a37e508fcd:	mov    r11d,r10d
    74a37e508fd0:	shr    r10d,1
    74a37e508fd3:	and    r10d,0x1e
    74a37e508fd7:	and    r11d,0x1
    74a37e508fdb:	or     r10d,r11d
    74a37e508fde:	or     DWORD PTR [r12+0x314],r10d
    74a37e508fe6:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e508fec:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e508ff2:	lea    rdi,[rsp+0x110]
    74a37e508ffa:	lea    rsi,[rsp+0xf0]
    74a37e509002:	lea    rdx,[rsp+0x100]
    74a37e50900a:	mov    ecx,0x14
    74a37e50900f:	mov    r8d,0x0
    74a37e509015:	lea    r9,[r12+0x314]
    74a37e50901d:	movabs r11,0x571546550650
    74a37e509027:	call   r11
    74a37e50902a:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e509030:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e509036:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e50903c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e509042:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e509048:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e50904e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e509058:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e509062:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e50906c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e509076:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50907e:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50908a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e509093:	mov    rdx,rbx
    74a37e509096:	shr    rdx,0x10
    74a37e50909a:	and    edx,0xc000
    74a37e5090a0:	mov    rax,rbx
    74a37e5090a3:	shr    rax,0x15
    74a37e5090a7:	and    eax,0x100
    74a37e5090ac:	xor    eax,0x100
    74a37e5090b1:	or     edx,eax
    74a37e5090b3:	mov    rax,rbx
    74a37e5090b6:	shr    rax,0x1c
    74a37e5090ba:	and    eax,0x1
    74a37e5090bd:	or     edx,eax
    74a37e5090bf:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e5090c4:	add    rsp,0x8
    74a37e5090c8:	ret
    74a37e5090c9:	nop    DWORD PTR [rax+0x0]
    74a37e5090d0:	sub    rsp,0x8
    74a37e5090d4:	mov    QWORD PTR [r12+0x378],0x3
    74a37e5090e0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e5090e6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e5090ec:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e5090f2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e5090f8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e5090fe:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e509108:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e509112:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e50911c:	push   rdx
    74a37e50911d:	push   rsi
    74a37e50911e:	push   r10
    74a37e509120:	push   r11
    74a37e509122:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e509127:	mov    r10d,edx
    74a37e50912a:	and    r10d,0xc000
    74a37e509131:	shl    r10d,0x10
    74a37e509135:	mov    r11d,edx
    74a37e509138:	and    r11d,0x100
    74a37e50913f:	shl    r11d,0x15
    74a37e509143:	or     r10d,r11d
    74a37e509146:	and    edx,0x1
    74a37e509149:	shl    edx,0x1c
    74a37e50914c:	or     r10d,edx
    74a37e50914f:	btc    r10,0x1d
    74a37e509154:	mov    r11d,0xf0000000
    74a37e50915a:	and    r11,r10
    74a37e50915d:	movabs rsi,0xffffffff0fffffff
    74a37e509167:	and    rbx,rsi
    74a37e50916a:	or     rbx,r11
    74a37e50916d:	pop    r11
    74a37e50916f:	pop    r10
    74a37e509171:	pop    rsi
    74a37e509172:	pop    rdx
    74a37e509173:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50917b:	stmxcsr DWORD PTR [r12-0x28]
    74a37e509181:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e509186:	test   r10d,0x3f
    74a37e50918d:	je     0x74a37e5091b2
    74a37e509193:	mov    r11d,r10d
    74a37e509196:	shr    r10d,1
    74a37e509199:	and    r10d,0x1e
    74a37e50919d:	and    r11d,0x1
    74a37e5091a1:	or     r10d,r11d
    74a37e5091a4:	or     DWORD PTR [r12+0x314],r10d
    74a37e5091ac:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e5091b2:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e5091b8:	lea    rdi,[rsp+0x110]
    74a37e5091c0:	lea    rsi,[rsp+0xf0]
    74a37e5091c8:	lea    rdx,[rsp+0x100]
    74a37e5091d0:	mov    ecx,0x56
    74a37e5091d5:	mov    r8d,0x0
    74a37e5091db:	lea    r9,[r12+0x314]
    74a37e5091e3:	movabs r11,0x571546550650
    74a37e5091ed:	call   r11
    74a37e5091f0:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e5091f6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e5091fc:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e509202:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e509208:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e50920e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e509214:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e50921e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e509228:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e509232:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50923a:	mov    QWORD PTR [r12+0x378],0x2
    74a37e509246:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e50924f:	mov    rdx,rbx
    74a37e509252:	shr    rdx,0x10
    74a37e509256:	and    edx,0xc000
    74a37e50925c:	mov    rax,rbx
    74a37e50925f:	shr    rax,0x15
    74a37e509263:	and    eax,0x100
    74a37e509268:	xor    eax,0x100
    74a37e50926d:	or     edx,eax
    74a37e50926f:	mov    rax,rbx
    74a37e509272:	shr    rax,0x1c
    74a37e509276:	and    eax,0x1
    74a37e509279:	or     edx,eax
    74a37e50927b:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e509280:	add    rsp,0x8
    74a37e509284:	ret
    74a37e509285:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e509290:	sub    rsp,0x8
    74a37e509294:	mov    QWORD PTR [r12+0x378],0x3
    74a37e5092a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e5092a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e5092ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e5092b2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e5092b8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e5092be:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e5092c4:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e5092ce:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e5092d8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e5092e2:	push   rdx
    74a37e5092e3:	push   rsi
    74a37e5092e4:	push   r10
    74a37e5092e6:	push   r11
    74a37e5092e8:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e5092ed:	mov    r10d,edx
    74a37e5092f0:	and    r10d,0xc000
    74a37e5092f7:	shl    r10d,0x10
    74a37e5092fb:	mov    r11d,edx
    74a37e5092fe:	and    r11d,0x100
    74a37e509305:	shl    r11d,0x15
    74a37e509309:	or     r10d,r11d
    74a37e50930c:	and    edx,0x1
    74a37e50930f:	shl    edx,0x1c
    74a37e509312:	or     r10d,edx
    74a37e509315:	btc    r10,0x1d
    74a37e50931a:	mov    r11d,0xf0000000
    74a37e509320:	and    r11,r10
    74a37e509323:	movabs rsi,0xffffffff0fffffff
    74a37e50932d:	and    rbx,rsi
    74a37e509330:	or     rbx,r11
    74a37e509333:	pop    r11
    74a37e509335:	pop    r10
    74a37e509337:	pop    rsi
    74a37e509338:	pop    rdx
    74a37e509339:	mov    QWORD PTR [r12+0x108],rbx
    74a37e509341:	stmxcsr DWORD PTR [r12-0x28]
    74a37e509347:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e50934c:	test   r10d,0x3f
    74a37e509353:	je     0x74a37e509378
    74a37e509359:	mov    r11d,r10d
    74a37e50935c:	shr    r10d,1
    74a37e50935f:	and    r10d,0x1e
    74a37e509363:	and    r11d,0x1
    74a37e509367:	or     r10d,r11d
    74a37e50936a:	or     DWORD PTR [r12+0x314],r10d
    74a37e509372:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e509378:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e50937e:	lea    rdi,[rsp+0x110]
    74a37e509386:	lea    rsi,[rsp+0xf0]
    74a37e50938e:	lea    rdx,[rsp+0x100]
    74a37e509396:	mov    ecx,0x56
    74a37e50939b:	mov    r8d,0x0
    74a37e5093a1:	lea    r9,[r12+0x314]
    74a37e5093a9:	movabs r11,0x571546550650
    74a37e5093b3:	call   r11
    74a37e5093b6:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e5093bc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e5093c2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e5093c8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e5093ce:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e5093d4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e5093da:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e5093e0:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e5093ea:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e5093f4:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e5093fe:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e509406:	mov    QWORD PTR [r12+0x378],0x2
    74a37e509412:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e50941b:	mov    rdx,rbx
    74a37e50941e:	shr    rdx,0x10
    74a37e509422:	and    edx,0xc000
    74a37e509428:	mov    rax,rbx
    74a37e50942b:	shr    rax,0x15
    74a37e50942f:	and    eax,0x100
    74a37e509434:	xor    eax,0x100
    74a37e509439:	or     edx,eax
    74a37e50943b:	mov    rax,rbx
    74a37e50943e:	shr    rax,0x1c
    74a37e509442:	and    eax,0x1
    74a37e509445:	or     edx,eax
    74a37e509447:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e50944c:	add    rsp,0x8
    74a37e509450:	ret
    74a37e509451:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e509460:	sub    rsp,0x8
    74a37e509464:	mov    QWORD PTR [r12+0x378],0x3
    74a37e509470:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e509476:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e50947c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e509482:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e509488:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e50948e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e509498:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e5094a2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e5094ac:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e5094b6:	push   rdx
    74a37e5094b7:	push   rsi
    74a37e5094b8:	push   r10
    74a37e5094ba:	push   r11
    74a37e5094bc:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e5094c1:	mov    r10d,edx
    74a37e5094c4:	and    r10d,0xc000
    74a37e5094cb:	shl    r10d,0x10
    74a37e5094cf:	mov    r11d,edx
    74a37e5094d2:	and    r11d,0x100
    74a37e5094d9:	shl    r11d,0x15
    74a37e5094dd:	or     r10d,r11d
    74a37e5094e0:	and    edx,0x1
    74a37e5094e3:	shl    edx,0x1c
    74a37e5094e6:	or     r10d,edx
    74a37e5094e9:	btc    r10,0x1d
    74a37e5094ee:	mov    r11d,0xf0000000
    74a37e5094f4:	and    r11,r10
    74a37e5094f7:	movabs rsi,0xffffffff0fffffff
    74a37e509501:	and    rbx,rsi
    74a37e509504:	or     rbx,r11
    74a37e509507:	pop    r11
    74a37e509509:	pop    r10
    74a37e50950b:	pop    rsi
    74a37e50950c:	pop    rdx
    74a37e50950d:	mov    QWORD PTR [r12+0x108],rbx
    74a37e509515:	stmxcsr DWORD PTR [r12-0x28]
    74a37e50951b:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e509520:	test   r10d,0x3f
    74a37e509527:	je     0x74a37e50954c
    74a37e50952d:	mov    r11d,r10d
    74a37e509530:	shr    r10d,1
    74a37e509533:	and    r10d,0x1e
    74a37e509537:	and    r11d,0x1
    74a37e50953b:	or     r10d,r11d
    74a37e50953e:	or     DWORD PTR [r12+0x314],r10d
    74a37e509546:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e50954c:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e509552:	lea    rdi,[rsp+0x110]
    74a37e50955a:	lea    rsi,[rsp+0xf0]
    74a37e509562:	lea    rdx,[rsp+0x100]
    74a37e50956a:	mov    ecx,0x14
    74a37e50956f:	mov    r8d,0x0
    74a37e509575:	lea    r9,[r12+0x314]
    74a37e50957d:	movabs r11,0x571546550650
    74a37e509587:	call   r11
    74a37e50958a:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e509590:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e509596:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e50959c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e5095a2:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e5095a8:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e5095ae:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e5095b8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e5095c2:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e5095cc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e5095d6:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e5095de:	mov    QWORD PTR [r12+0x378],0x2
    74a37e5095ea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e5095f3:	mov    rdx,rbx
    74a37e5095f6:	shr    rdx,0x10
    74a37e5095fa:	and    edx,0xc000
    74a37e509600:	mov    rax,rbx
    74a37e509603:	shr    rax,0x15
    74a37e509607:	and    eax,0x100
    74a37e50960c:	xor    eax,0x100
    74a37e509611:	or     edx,eax
    74a37e509613:	mov    rax,rbx
    74a37e509616:	shr    rax,0x1c
    74a37e50961a:	and    eax,0x1
    74a37e50961d:	or     edx,eax
    74a37e50961f:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e509624:	add    rsp,0x8
    74a37e509628:	ret
    74a37e509629:	nop    DWORD PTR [rax+0x0]
    74a37e509630:	sub    rsp,0x8
    74a37e509634:	mov    QWORD PTR [r12+0x378],0x3
    74a37e509640:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e509646:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e50964c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e509652:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e509658:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e50965e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e509668:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e509672:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e50967c:	push   rdx
    74a37e50967d:	push   rsi
    74a37e50967e:	push   r10
    74a37e509680:	push   r11
    74a37e509682:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e509687:	mov    r10d,edx
    74a37e50968a:	and    r10d,0xc000
    74a37e509691:	shl    r10d,0x10
    74a37e509695:	mov    r11d,edx
    74a37e509698:	and    r11d,0x100
    74a37e50969f:	shl    r11d,0x15
    74a37e5096a3:	or     r10d,r11d
    74a37e5096a6:	and    edx,0x1
    74a37e5096a9:	shl    edx,0x1c
    74a37e5096ac:	or     r10d,edx
    74a37e5096af:	btc    r10,0x1d
    74a37e5096b4:	mov    r11d,0xf0000000
    74a37e5096ba:	and    r11,r10
    74a37e5096bd:	movabs rsi,0xffffffff0fffffff
    74a37e5096c7:	and    rbx,rsi
    74a37e5096ca:	or     rbx,r11
    74a37e5096cd:	pop    r11
    74a37e5096cf:	pop    r10
    74a37e5096d1:	pop    rsi
    74a37e5096d2:	pop    rdx
    74a37e5096d3:	mov    QWORD PTR [r12+0x108],rbx
    74a37e5096db:	stmxcsr DWORD PTR [r12-0x28]
    74a37e5096e1:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e5096e6:	test   r10d,0x3f
    74a37e5096ed:	je     0x74a37e509712
    74a37e5096f3:	mov    r11d,r10d
    74a37e5096f6:	shr    r10d,1
    74a37e5096f9:	and    r10d,0x1e
    74a37e5096fd:	and    r11d,0x1
    74a37e509701:	or     r10d,r11d
    74a37e509704:	or     DWORD PTR [r12+0x314],r10d
    74a37e50970c:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e509712:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e509718:	lea    rdi,[rsp+0x110]
    74a37e509720:	lea    rsi,[rsp+0xf0]
    74a37e509728:	lea    rdx,[rsp+0x100]
    74a37e509730:	mov    ecx,0x14
    74a37e509735:	mov    r8d,0x0
    74a37e50973b:	lea    r9,[r12+0x314]
    74a37e509743:	movabs r11,0x571546550650
    74a37e50974d:	call   r11
    74a37e509750:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e509756:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e50975c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e509762:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e509768:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e50976e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e509774:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e50977e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e509788:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e509792:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50979a:	mov    QWORD PTR [r12+0x378],0x2
    74a37e5097a6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e5097af:	mov    rdx,rbx
    74a37e5097b2:	shr    rdx,0x10
    74a37e5097b6:	and    edx,0xc000
    74a37e5097bc:	mov    rax,rbx
    74a37e5097bf:	shr    rax,0x15
    74a37e5097c3:	and    eax,0x100
    74a37e5097c8:	xor    eax,0x100
    74a37e5097cd:	or     edx,eax
    74a37e5097cf:	mov    rax,rbx
    74a37e5097d2:	shr    rax,0x1c
    74a37e5097d6:	and    eax,0x1
    74a37e5097d9:	or     edx,eax
    74a37e5097db:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e5097e0:	add    rsp,0x8
    74a37e5097e4:	ret
    74a37e5097e5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e5097f0:	sub    rsp,0x8
    74a37e5097f4:	mov    QWORD PTR [r12+0x378],0x3
    74a37e509800:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e509806:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e50980c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e509812:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e509818:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e50981e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e509824:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e50982e:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e509838:	push   rdx
    74a37e509839:	push   rsi
    74a37e50983a:	push   r10
    74a37e50983c:	push   r11
    74a37e50983e:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e509843:	mov    r10d,edx
    74a37e509846:	and    r10d,0xc000
    74a37e50984d:	shl    r10d,0x10
    74a37e509851:	mov    r11d,edx
    74a37e509854:	and    r11d,0x100
    74a37e50985b:	shl    r11d,0x15
    74a37e50985f:	or     r10d,r11d
    74a37e509862:	and    edx,0x1
    74a37e509865:	shl    edx,0x1c
    74a37e509868:	or     r10d,edx
    74a37e50986b:	btc    r10,0x1d
    74a37e509870:	mov    r11d,0xf0000000
    74a37e509876:	and    r11,r10
    74a37e509879:	movabs rsi,0xffffffff0fffffff
    74a37e509883:	and    rbx,rsi
    74a37e509886:	or     rbx,r11
    74a37e509889:	pop    r11
    74a37e50988b:	pop    r10
    74a37e50988d:	pop    rsi
    74a37e50988e:	pop    rdx
    74a37e50988f:	mov    QWORD PTR [r12+0x108],rbx
    74a37e509897:	stmxcsr DWORD PTR [r12-0x28]
    74a37e50989d:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e5098a2:	test   r10d,0x3f
    74a37e5098a9:	je     0x74a37e5098ce
    74a37e5098af:	mov    r11d,r10d
    74a37e5098b2:	shr    r10d,1
    74a37e5098b5:	and    r10d,0x1e
    74a37e5098b9:	and    r11d,0x1
    74a37e5098bd:	or     r10d,r11d
    74a37e5098c0:	or     DWORD PTR [r12+0x314],r10d
    74a37e5098c8:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e5098ce:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e5098d4:	lea    rdi,[rsp+0x110]
    74a37e5098dc:	lea    rsi,[rsp+0xf0]
    74a37e5098e4:	lea    rdx,[rsp+0x100]
    74a37e5098ec:	mov    ecx,0x56
    74a37e5098f1:	mov    r8d,0x0
    74a37e5098f7:	lea    r9,[r12+0x314]
    74a37e5098ff:	movabs r11,0x571546550650
    74a37e509909:	call   r11
    74a37e50990c:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e509912:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e509918:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e50991e:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e509924:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e50992a:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e509930:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e509936:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e509940:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e50994a:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e509952:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50995e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e509967:	mov    rdx,rbx
    74a37e50996a:	shr    rdx,0x10
    74a37e50996e:	and    edx,0xc000
    74a37e509974:	mov    rax,rbx
    74a37e509977:	shr    rax,0x15
    74a37e50997b:	and    eax,0x100
    74a37e509980:	xor    eax,0x100
    74a37e509985:	or     edx,eax
    74a37e509987:	mov    rax,rbx
    74a37e50998a:	shr    rax,0x1c
    74a37e50998e:	and    eax,0x1
    74a37e509991:	or     edx,eax
    74a37e509993:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e509998:	add    rsp,0x8
    74a37e50999c:	ret
    74a37e50999d:	nop    DWORD PTR [rax]
    74a37e5099a0:	sub    rsp,0x8
    74a37e5099a4:	mov    QWORD PTR [r12+0x378],0x3
    74a37e5099b0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e5099b6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e5099bc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e5099c2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e5099c8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e5099ce:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e5099d4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e5099de:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e5099e8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e5099f2:	push   rdx
    74a37e5099f3:	push   rsi
    74a37e5099f4:	push   r10
    74a37e5099f6:	push   r11
    74a37e5099f8:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e5099fd:	mov    r10d,edx
    74a37e509a00:	and    r10d,0xc000
    74a37e509a07:	shl    r10d,0x10
    74a37e509a0b:	mov    r11d,edx
    74a37e509a0e:	and    r11d,0x100
    74a37e509a15:	shl    r11d,0x15
    74a37e509a19:	or     r10d,r11d
    74a37e509a1c:	and    edx,0x1
    74a37e509a1f:	shl    edx,0x1c
    74a37e509a22:	or     r10d,edx
    74a37e509a25:	btc    r10,0x1d
    74a37e509a2a:	mov    r11d,0xf0000000
    74a37e509a30:	and    r11,r10
    74a37e509a33:	movabs rsi,0xffffffff0fffffff
    74a37e509a3d:	and    rbx,rsi
    74a37e509a40:	or     rbx,r11
    74a37e509a43:	pop    r11
    74a37e509a45:	pop    r10
    74a37e509a47:	pop    rsi
    74a37e509a48:	pop    rdx
    74a37e509a49:	mov    QWORD PTR [r12+0x108],rbx
    74a37e509a51:	stmxcsr DWORD PTR [r12-0x28]
    74a37e509a57:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e509a5c:	test   r10d,0x3f
    74a37e509a63:	je     0x74a37e509a88
    74a37e509a69:	mov    r11d,r10d
    74a37e509a6c:	shr    r10d,1
    74a37e509a6f:	and    r10d,0x1e
    74a37e509a73:	and    r11d,0x1
    74a37e509a77:	or     r10d,r11d
    74a37e509a7a:	or     DWORD PTR [r12+0x314],r10d
    74a37e509a82:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e509a88:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e509a8e:	lea    rdi,[rsp+0x110]
    74a37e509a96:	lea    rsi,[rsp+0xf0]
    74a37e509a9e:	lea    rdx,[rsp+0x100]
    74a37e509aa6:	mov    ecx,0x14
    74a37e509aab:	mov    r8d,0x0
    74a37e509ab1:	lea    r9,[r12+0x314]
    74a37e509ab9:	movabs r11,0x571546550650
    74a37e509ac3:	call   r11
    74a37e509ac6:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e509acc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e509ad2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e509ad8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e509ade:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e509ae4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e509aea:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e509af0:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e509afa:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e509b04:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e509b0e:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e509b16:	mov    QWORD PTR [r12+0x378],0x2
    74a37e509b22:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e509b2b:	mov    rdx,rbx
    74a37e509b2e:	shr    rdx,0x10
    74a37e509b32:	and    edx,0xc000
    74a37e509b38:	mov    rax,rbx
    74a37e509b3b:	shr    rax,0x15
    74a37e509b3f:	and    eax,0x100
    74a37e509b44:	xor    eax,0x100
    74a37e509b49:	or     edx,eax
    74a37e509b4b:	mov    rax,rbx
    74a37e509b4e:	shr    rax,0x1c
    74a37e509b52:	and    eax,0x1
    74a37e509b55:	or     edx,eax
    74a37e509b57:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e509b5c:	add    rsp,0x8
    74a37e509b60:	ret
    74a37e509b61:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e509b70:	sub    rsp,0x8
    74a37e509b74:	mov    QWORD PTR [r12+0x378],0x3
    74a37e509b80:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e509b86:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e509b8c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e509b92:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e509b98:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e509ba2:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e509bac:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e509bb6:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e509bc0:	push   rdx
    74a37e509bc1:	push   rsi
    74a37e509bc2:	push   r10
    74a37e509bc4:	push   r11
    74a37e509bc6:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e509bcb:	mov    r10d,edx
    74a37e509bce:	and    r10d,0xc000
    74a37e509bd5:	shl    r10d,0x10
    74a37e509bd9:	mov    r11d,edx
    74a37e509bdc:	and    r11d,0x100
    74a37e509be3:	shl    r11d,0x15
    74a37e509be7:	or     r10d,r11d
    74a37e509bea:	and    edx,0x1
    74a37e509bed:	shl    edx,0x1c
    74a37e509bf0:	or     r10d,edx
    74a37e509bf3:	btc    r10,0x1d
    74a37e509bf8:	mov    r11d,0xf0000000
    74a37e509bfe:	and    r11,r10
    74a37e509c01:	movabs rsi,0xffffffff0fffffff
    74a37e509c0b:	and    rbx,rsi
    74a37e509c0e:	or     rbx,r11
    74a37e509c11:	pop    r11
    74a37e509c13:	pop    r10
    74a37e509c15:	pop    rsi
    74a37e509c16:	pop    rdx
    74a37e509c17:	mov    QWORD PTR [r12+0x108],rbx
    74a37e509c1f:	stmxcsr DWORD PTR [r12-0x28]
    74a37e509c25:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e509c2a:	test   r10d,0x3f
    74a37e509c31:	je     0x74a37e509c56
    74a37e509c37:	mov    r11d,r10d
    74a37e509c3a:	shr    r10d,1
    74a37e509c3d:	and    r10d,0x1e
    74a37e509c41:	and    r11d,0x1
    74a37e509c45:	or     r10d,r11d
    74a37e509c48:	or     DWORD PTR [r12+0x314],r10d
    74a37e509c50:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e509c56:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e509c5c:	lea    rdi,[rsp+0x110]
    74a37e509c64:	lea    rsi,[rsp+0xf0]
    74a37e509c6c:	lea    rdx,[rsp+0x100]
    74a37e509c74:	mov    ecx,0x14
    74a37e509c79:	mov    r8d,0x0
    74a37e509c7f:	lea    r9,[r12+0x314]
    74a37e509c87:	movabs r11,0x571546550650
    74a37e509c91:	call   r11
    74a37e509c94:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e509c9a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e509ca0:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e509ca6:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e509cac:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e509cb2:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e509cbc:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e509cc6:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e509cd0:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e509cda:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e509ce2:	mov    QWORD PTR [r12+0x378],0x2
    74a37e509cee:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e509cf7:	mov    rdx,rbx
    74a37e509cfa:	shr    rdx,0x10
    74a37e509cfe:	and    edx,0xc000
    74a37e509d04:	mov    rax,rbx
    74a37e509d07:	shr    rax,0x15
    74a37e509d0b:	and    eax,0x100
    74a37e509d10:	xor    eax,0x100
    74a37e509d15:	or     edx,eax
    74a37e509d17:	mov    rax,rbx
    74a37e509d1a:	shr    rax,0x1c
    74a37e509d1e:	and    eax,0x1
    74a37e509d21:	or     edx,eax
    74a37e509d23:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e509d28:	add    rsp,0x8
    74a37e509d2c:	ret
    74a37e509d2d:	nop    DWORD PTR [rax]
    74a37e509d30:	sub    rsp,0x8
    74a37e509d34:	mov    QWORD PTR [r12+0x378],0x3
    74a37e509d40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e509d46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e509d4c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e509d52:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e509d58:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e509d5e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e509d68:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e509d72:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e509d7c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e509d86:	push   rdx
    74a37e509d87:	push   rsi
    74a37e509d88:	push   r10
    74a37e509d8a:	push   r11
    74a37e509d8c:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e509d91:	mov    r10d,edx
    74a37e509d94:	and    r10d,0xc000
    74a37e509d9b:	shl    r10d,0x10
    74a37e509d9f:	mov    r11d,edx
    74a37e509da2:	and    r11d,0x100
    74a37e509da9:	shl    r11d,0x15
    74a37e509dad:	or     r10d,r11d
    74a37e509db0:	and    edx,0x1
    74a37e509db3:	shl    edx,0x1c
    74a37e509db6:	or     r10d,edx
    74a37e509db9:	btc    r10,0x1d
    74a37e509dbe:	mov    r11d,0xf0000000
    74a37e509dc4:	and    r11,r10
    74a37e509dc7:	movabs rsi,0xffffffff0fffffff
    74a37e509dd1:	and    rbx,rsi
    74a37e509dd4:	or     rbx,r11
    74a37e509dd7:	pop    r11
    74a37e509dd9:	pop    r10
    74a37e509ddb:	pop    rsi
    74a37e509ddc:	pop    rdx
    74a37e509ddd:	mov    QWORD PTR [r12+0x108],rbx
    74a37e509de5:	stmxcsr DWORD PTR [r12-0x28]
    74a37e509deb:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e509df0:	test   r10d,0x3f
    74a37e509df7:	je     0x74a37e509e1c
    74a37e509dfd:	mov    r11d,r10d
    74a37e509e00:	shr    r10d,1
    74a37e509e03:	and    r10d,0x1e
    74a37e509e07:	and    r11d,0x1
    74a37e509e0b:	or     r10d,r11d
    74a37e509e0e:	or     DWORD PTR [r12+0x314],r10d
    74a37e509e16:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e509e1c:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e509e22:	lea    rdi,[rsp+0x110]
    74a37e509e2a:	lea    rsi,[rsp+0xf0]
    74a37e509e32:	lea    rdx,[rsp+0x100]
    74a37e509e3a:	mov    ecx,0x14
    74a37e509e3f:	mov    r8d,0x0
    74a37e509e45:	lea    r9,[r12+0x314]
    74a37e509e4d:	movabs r11,0x571546550650
    74a37e509e57:	call   r11
    74a37e509e5a:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e509e60:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e509e66:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e509e6c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e509e72:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e509e78:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e509e7e:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e509e88:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e509e92:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e509e9c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e509ea6:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e509eae:	mov    QWORD PTR [r12+0x378],0x2
    74a37e509eba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e509ec3:	mov    rdx,rbx
    74a37e509ec6:	shr    rdx,0x10
    74a37e509eca:	and    edx,0xc000
    74a37e509ed0:	mov    rax,rbx
    74a37e509ed3:	shr    rax,0x15
    74a37e509ed7:	and    eax,0x100
    74a37e509edc:	xor    eax,0x100
    74a37e509ee1:	or     edx,eax
    74a37e509ee3:	mov    rax,rbx
    74a37e509ee6:	shr    rax,0x1c
    74a37e509eea:	and    eax,0x1
    74a37e509eed:	or     edx,eax
    74a37e509eef:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e509ef4:	add    rsp,0x8
    74a37e509ef8:	ret
    74a37e509ef9:	nop    DWORD PTR [rax+0x0]
    74a37e509f00:	sub    rsp,0x8
    74a37e509f04:	mov    QWORD PTR [r12+0x378],0x3
    74a37e509f10:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e509f16:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e509f1c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e509f22:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e509f28:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e509f2e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e509f38:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e509f42:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e509f4c:	push   rdx
    74a37e509f4d:	push   rsi
    74a37e509f4e:	push   r10
    74a37e509f50:	push   r11
    74a37e509f52:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e509f57:	mov    r10d,edx
    74a37e509f5a:	and    r10d,0xc000
    74a37e509f61:	shl    r10d,0x10
    74a37e509f65:	mov    r11d,edx
    74a37e509f68:	and    r11d,0x100
    74a37e509f6f:	shl    r11d,0x15
    74a37e509f73:	or     r10d,r11d
    74a37e509f76:	and    edx,0x1
    74a37e509f79:	shl    edx,0x1c
    74a37e509f7c:	or     r10d,edx
    74a37e509f7f:	btc    r10,0x1d
    74a37e509f84:	mov    r11d,0xf0000000
    74a37e509f8a:	and    r11,r10
    74a37e509f8d:	movabs rsi,0xffffffff0fffffff
    74a37e509f97:	and    rbx,rsi
    74a37e509f9a:	or     rbx,r11
    74a37e509f9d:	pop    r11
    74a37e509f9f:	pop    r10
    74a37e509fa1:	pop    rsi
    74a37e509fa2:	pop    rdx
    74a37e509fa3:	mov    QWORD PTR [r12+0x108],rbx
    74a37e509fab:	stmxcsr DWORD PTR [r12-0x28]
    74a37e509fb1:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e509fb6:	test   r10d,0x3f
    74a37e509fbd:	je     0x74a37e509fe2
    74a37e509fc3:	mov    r11d,r10d
    74a37e509fc6:	shr    r10d,1
    74a37e509fc9:	and    r10d,0x1e
    74a37e509fcd:	and    r11d,0x1
    74a37e509fd1:	or     r10d,r11d
    74a37e509fd4:	or     DWORD PTR [r12+0x314],r10d
    74a37e509fdc:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e509fe2:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e509fe8:	lea    rdi,[rsp+0x110]
    74a37e509ff0:	lea    rsi,[rsp+0xf0]
    74a37e509ff8:	lea    rdx,[rsp+0x100]
    74a37e50a000:	mov    ecx,0x56
    74a37e50a005:	mov    r8d,0x0
    74a37e50a00b:	lea    r9,[r12+0x314]
    74a37e50a013:	movabs r11,0x571546550650
    74a37e50a01d:	call   r11
    74a37e50a020:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e50a026:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e50a02c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e50a032:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e50a038:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e50a03e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e50a044:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e50a04e:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e50a058:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e50a062:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50a06a:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50a076:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e50a07f:	mov    rdx,rbx
    74a37e50a082:	shr    rdx,0x10
    74a37e50a086:	and    edx,0xc000
    74a37e50a08c:	mov    rax,rbx
    74a37e50a08f:	shr    rax,0x15
    74a37e50a093:	and    eax,0x100
    74a37e50a098:	xor    eax,0x100
    74a37e50a09d:	or     edx,eax
    74a37e50a09f:	mov    rax,rbx
    74a37e50a0a2:	shr    rax,0x1c
    74a37e50a0a6:	and    eax,0x1
    74a37e50a0a9:	or     edx,eax
    74a37e50a0ab:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e50a0b0:	add    rsp,0x8
    74a37e50a0b4:	ret
    74a37e50a0b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e50a0c0:	sub    rsp,0x8
    74a37e50a0c4:	mov    QWORD PTR [r12+0x378],0x3
    74a37e50a0d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e50a0d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e50a0dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e50a0e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e50a0e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e50a0ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e50a0f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e50a102:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e50a10c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e50a116:	push   rdx
    74a37e50a117:	push   rsi
    74a37e50a118:	push   r10
    74a37e50a11a:	push   r11
    74a37e50a11c:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e50a121:	mov    r10d,edx
    74a37e50a124:	and    r10d,0xc000
    74a37e50a12b:	shl    r10d,0x10
    74a37e50a12f:	mov    r11d,edx
    74a37e50a132:	and    r11d,0x100
    74a37e50a139:	shl    r11d,0x15
    74a37e50a13d:	or     r10d,r11d
    74a37e50a140:	and    edx,0x1
    74a37e50a143:	shl    edx,0x1c
    74a37e50a146:	or     r10d,edx
    74a37e50a149:	btc    r10,0x1d
    74a37e50a14e:	mov    r11d,0xf0000000
    74a37e50a154:	and    r11,r10
    74a37e50a157:	movabs rsi,0xffffffff0fffffff
    74a37e50a161:	and    rbx,rsi
    74a37e50a164:	or     rbx,r11
    74a37e50a167:	pop    r11
    74a37e50a169:	pop    r10
    74a37e50a16b:	pop    rsi
    74a37e50a16c:	pop    rdx
    74a37e50a16d:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50a175:	stmxcsr DWORD PTR [r12-0x28]
    74a37e50a17b:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e50a180:	test   r10d,0x3f
    74a37e50a187:	je     0x74a37e50a1ac
    74a37e50a18d:	mov    r11d,r10d
    74a37e50a190:	shr    r10d,1
    74a37e50a193:	and    r10d,0x1e
    74a37e50a197:	and    r11d,0x1
    74a37e50a19b:	or     r10d,r11d
    74a37e50a19e:	or     DWORD PTR [r12+0x314],r10d
    74a37e50a1a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e50a1ac:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e50a1b2:	lea    rdi,[rsp+0x110]
    74a37e50a1ba:	lea    rsi,[rsp+0xf0]
    74a37e50a1c2:	lea    rdx,[rsp+0x100]
    74a37e50a1ca:	mov    ecx,0x56
    74a37e50a1cf:	mov    r8d,0x0
    74a37e50a1d5:	lea    r9,[r12+0x314]
    74a37e50a1dd:	movabs r11,0x571546550650
    74a37e50a1e7:	call   r11
    74a37e50a1ea:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e50a1f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e50a1f6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e50a1fc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e50a202:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e50a208:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e50a20e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e50a218:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e50a222:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e50a22c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e50a236:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50a23e:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50a24a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e50a253:	mov    rdx,rbx
    74a37e50a256:	shr    rdx,0x10
    74a37e50a25a:	and    edx,0xc000
    74a37e50a260:	mov    rax,rbx
    74a37e50a263:	shr    rax,0x15
    74a37e50a267:	and    eax,0x100
    74a37e50a26c:	xor    eax,0x100
    74a37e50a271:	or     edx,eax
    74a37e50a273:	mov    rax,rbx
    74a37e50a276:	shr    rax,0x1c
    74a37e50a27a:	and    eax,0x1
    74a37e50a27d:	or     edx,eax
    74a37e50a27f:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e50a284:	add    rsp,0x8
    74a37e50a288:	ret
    74a37e50a289:	nop    DWORD PTR [rax+0x0]
    74a37e50a290:	sub    rsp,0x8
    74a37e50a294:	mov    QWORD PTR [r12+0x378],0x3
    74a37e50a2a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e50a2a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e50a2ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e50a2b2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e50a2b8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e50a2be:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e50a2c8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e50a2d2:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e50a2dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e50a2e6:	push   rdx
    74a37e50a2e7:	push   rsi
    74a37e50a2e8:	push   r10
    74a37e50a2ea:	push   r11
    74a37e50a2ec:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e50a2f1:	mov    r10d,edx
    74a37e50a2f4:	and    r10d,0xc000
    74a37e50a2fb:	shl    r10d,0x10
    74a37e50a2ff:	mov    r11d,edx
    74a37e50a302:	and    r11d,0x100
    74a37e50a309:	shl    r11d,0x15
    74a37e50a30d:	or     r10d,r11d
    74a37e50a310:	and    edx,0x1
    74a37e50a313:	shl    edx,0x1c
    74a37e50a316:	or     r10d,edx
    74a37e50a319:	btc    r10,0x1d
    74a37e50a31e:	mov    r11d,0xf0000000
    74a37e50a324:	and    r11,r10
    74a37e50a327:	movabs rsi,0xffffffff0fffffff
    74a37e50a331:	and    rbx,rsi
    74a37e50a334:	or     rbx,r11
    74a37e50a337:	pop    r11
    74a37e50a339:	pop    r10
    74a37e50a33b:	pop    rsi
    74a37e50a33c:	pop    rdx
    74a37e50a33d:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50a345:	stmxcsr DWORD PTR [r12-0x28]
    74a37e50a34b:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e50a350:	test   r10d,0x3f
    74a37e50a357:	je     0x74a37e50a37c
    74a37e50a35d:	mov    r11d,r10d
    74a37e50a360:	shr    r10d,1
    74a37e50a363:	and    r10d,0x1e
    74a37e50a367:	and    r11d,0x1
    74a37e50a36b:	or     r10d,r11d
    74a37e50a36e:	or     DWORD PTR [r12+0x314],r10d
    74a37e50a376:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e50a37c:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e50a382:	lea    rdi,[rsp+0x110]
    74a37e50a38a:	lea    rsi,[rsp+0xf0]
    74a37e50a392:	lea    rdx,[rsp+0x100]
    74a37e50a39a:	mov    ecx,0x14
    74a37e50a39f:	mov    r8d,0x0
    74a37e50a3a5:	lea    r9,[r12+0x314]
    74a37e50a3ad:	movabs r11,0x571546550650
    74a37e50a3b7:	call   r11
    74a37e50a3ba:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e50a3c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e50a3c6:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e50a3cc:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e50a3d2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e50a3d8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e50a3de:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e50a3e8:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e50a3f2:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e50a3fc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e50a406:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50a40e:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50a41a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e50a423:	mov    rdx,rbx
    74a37e50a426:	shr    rdx,0x10
    74a37e50a42a:	and    edx,0xc000
    74a37e50a430:	mov    rax,rbx
    74a37e50a433:	shr    rax,0x15
    74a37e50a437:	and    eax,0x100
    74a37e50a43c:	xor    eax,0x100
    74a37e50a441:	or     edx,eax
    74a37e50a443:	mov    rax,rbx
    74a37e50a446:	shr    rax,0x1c
    74a37e50a44a:	and    eax,0x1
    74a37e50a44d:	or     edx,eax
    74a37e50a44f:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e50a454:	add    rsp,0x8
    74a37e50a458:	ret
    74a37e50a459:	nop    DWORD PTR [rax+0x0]
    74a37e50a460:	sub    rsp,0x8
    74a37e50a464:	mov    QWORD PTR [r12+0x378],0x3
    74a37e50a470:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e50a476:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e50a47c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e50a482:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e50a488:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e50a48e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e50a498:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e50a4a2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e50a4ac:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e50a4b6:	push   rdx
    74a37e50a4b7:	push   rsi
    74a37e50a4b8:	push   r10
    74a37e50a4ba:	push   r11
    74a37e50a4bc:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e50a4c1:	mov    r10d,edx
    74a37e50a4c4:	and    r10d,0xc000
    74a37e50a4cb:	shl    r10d,0x10
    74a37e50a4cf:	mov    r11d,edx
    74a37e50a4d2:	and    r11d,0x100
    74a37e50a4d9:	shl    r11d,0x15
    74a37e50a4dd:	or     r10d,r11d
    74a37e50a4e0:	and    edx,0x1
    74a37e50a4e3:	shl    edx,0x1c
    74a37e50a4e6:	or     r10d,edx
    74a37e50a4e9:	btc    r10,0x1d
    74a37e50a4ee:	mov    r11d,0xf0000000
    74a37e50a4f4:	and    r11,r10
    74a37e50a4f7:	movabs rsi,0xffffffff0fffffff
    74a37e50a501:	and    rbx,rsi
    74a37e50a504:	or     rbx,r11
    74a37e50a507:	pop    r11
    74a37e50a509:	pop    r10
    74a37e50a50b:	pop    rsi
    74a37e50a50c:	pop    rdx
    74a37e50a50d:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50a515:	stmxcsr DWORD PTR [r12-0x28]
    74a37e50a51b:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e50a520:	test   r10d,0x3f
    74a37e50a527:	je     0x74a37e50a54c
    74a37e50a52d:	mov    r11d,r10d
    74a37e50a530:	shr    r10d,1
    74a37e50a533:	and    r10d,0x1e
    74a37e50a537:	and    r11d,0x1
    74a37e50a53b:	or     r10d,r11d
    74a37e50a53e:	or     DWORD PTR [r12+0x314],r10d
    74a37e50a546:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e50a54c:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e50a552:	lea    rdi,[rsp+0x110]
    74a37e50a55a:	lea    rsi,[rsp+0xf0]
    74a37e50a562:	lea    rdx,[rsp+0x100]
    74a37e50a56a:	mov    ecx,0x56
    74a37e50a56f:	mov    r8d,0x0
    74a37e50a575:	lea    r9,[r12+0x314]
    74a37e50a57d:	movabs r11,0x571546550650
    74a37e50a587:	call   r11
    74a37e50a58a:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e50a590:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e50a596:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e50a59c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e50a5a2:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e50a5a8:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e50a5ae:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e50a5b8:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e50a5c2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e50a5cc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e50a5d6:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50a5de:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50a5ea:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e50a5f3:	mov    rdx,rbx
    74a37e50a5f6:	shr    rdx,0x10
    74a37e50a5fa:	and    edx,0xc000
    74a37e50a600:	mov    rax,rbx
    74a37e50a603:	shr    rax,0x15
    74a37e50a607:	and    eax,0x100
    74a37e50a60c:	xor    eax,0x100
    74a37e50a611:	or     edx,eax
    74a37e50a613:	mov    rax,rbx
    74a37e50a616:	shr    rax,0x1c
    74a37e50a61a:	and    eax,0x1
    74a37e50a61d:	or     edx,eax
    74a37e50a61f:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e50a624:	add    rsp,0x8
    74a37e50a628:	ret
    74a37e50a629:	nop    DWORD PTR [rax+0x0]
    74a37e50a630:	sub    rsp,0x8
    74a37e50a634:	mov    QWORD PTR [r12+0x378],0x3
    74a37e50a640:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e50a646:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e50a64c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e50a652:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e50a658:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e50a65e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e50a668:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e50a672:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e50a67c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e50a686:	push   rdx
    74a37e50a687:	push   rsi
    74a37e50a688:	push   r10
    74a37e50a68a:	push   r11
    74a37e50a68c:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e50a691:	mov    r10d,edx
    74a37e50a694:	and    r10d,0xc000
    74a37e50a69b:	shl    r10d,0x10
    74a37e50a69f:	mov    r11d,edx
    74a37e50a6a2:	and    r11d,0x100
    74a37e50a6a9:	shl    r11d,0x15
    74a37e50a6ad:	or     r10d,r11d
    74a37e50a6b0:	and    edx,0x1
    74a37e50a6b3:	shl    edx,0x1c
    74a37e50a6b6:	or     r10d,edx
    74a37e50a6b9:	btc    r10,0x1d
    74a37e50a6be:	mov    r11d,0xf0000000
    74a37e50a6c4:	and    r11,r10
    74a37e50a6c7:	movabs rsi,0xffffffff0fffffff
    74a37e50a6d1:	and    rbx,rsi
    74a37e50a6d4:	or     rbx,r11
    74a37e50a6d7:	pop    r11
    74a37e50a6d9:	pop    r10
    74a37e50a6db:	pop    rsi
    74a37e50a6dc:	pop    rdx
    74a37e50a6dd:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50a6e5:	stmxcsr DWORD PTR [r12-0x28]
    74a37e50a6eb:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e50a6f0:	test   r10d,0x3f
    74a37e50a6f7:	je     0x74a37e50a71c
    74a37e50a6fd:	mov    r11d,r10d
    74a37e50a700:	shr    r10d,1
    74a37e50a703:	and    r10d,0x1e
    74a37e50a707:	and    r11d,0x1
    74a37e50a70b:	or     r10d,r11d
    74a37e50a70e:	or     DWORD PTR [r12+0x314],r10d
    74a37e50a716:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e50a71c:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e50a722:	lea    rdi,[rsp+0x110]
    74a37e50a72a:	lea    rsi,[rsp+0xf0]
    74a37e50a732:	lea    rdx,[rsp+0x100]
    74a37e50a73a:	mov    ecx,0x14
    74a37e50a73f:	mov    r8d,0x0
    74a37e50a745:	lea    r9,[r12+0x314]
    74a37e50a74d:	movabs r11,0x571546550650
    74a37e50a757:	call   r11
    74a37e50a75a:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e50a760:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e50a766:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e50a76c:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e50a772:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e50a778:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e50a77e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e50a788:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e50a792:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e50a79c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e50a7a6:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50a7ae:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50a7ba:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e50a7c3:	mov    rdx,rbx
    74a37e50a7c6:	shr    rdx,0x10
    74a37e50a7ca:	and    edx,0xc000
    74a37e50a7d0:	mov    rax,rbx
    74a37e50a7d3:	shr    rax,0x15
    74a37e50a7d7:	and    eax,0x100
    74a37e50a7dc:	xor    eax,0x100
    74a37e50a7e1:	or     edx,eax
    74a37e50a7e3:	mov    rax,rbx
    74a37e50a7e6:	shr    rax,0x1c
    74a37e50a7ea:	and    eax,0x1
    74a37e50a7ed:	or     edx,eax
    74a37e50a7ef:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e50a7f4:	add    rsp,0x8
    74a37e50a7f8:	ret
    74a37e50a7f9:	nop    DWORD PTR [rax+0x0]
    74a37e50a800:	sub    rsp,0x8
    74a37e50a804:	mov    QWORD PTR [r12+0x378],0x3
    74a37e50a810:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e50a816:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e50a81c:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e50a822:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e50a828:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e50a82e:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e50a838:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e50a842:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e50a84c:	push   rdx
    74a37e50a84d:	push   rsi
    74a37e50a84e:	push   r10
    74a37e50a850:	push   r11
    74a37e50a852:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e50a857:	mov    r10d,edx
    74a37e50a85a:	and    r10d,0xc000
    74a37e50a861:	shl    r10d,0x10
    74a37e50a865:	mov    r11d,edx
    74a37e50a868:	and    r11d,0x100
    74a37e50a86f:	shl    r11d,0x15
    74a37e50a873:	or     r10d,r11d
    74a37e50a876:	and    edx,0x1
    74a37e50a879:	shl    edx,0x1c
    74a37e50a87c:	or     r10d,edx
    74a37e50a87f:	btc    r10,0x1d
    74a37e50a884:	mov    r11d,0xf0000000
    74a37e50a88a:	and    r11,r10
    74a37e50a88d:	movabs rsi,0xffffffff0fffffff
    74a37e50a897:	and    rbx,rsi
    74a37e50a89a:	or     rbx,r11
    74a37e50a89d:	pop    r11
    74a37e50a89f:	pop    r10
    74a37e50a8a1:	pop    rsi
    74a37e50a8a2:	pop    rdx
    74a37e50a8a3:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50a8ab:	stmxcsr DWORD PTR [r12-0x28]
    74a37e50a8b1:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e50a8b6:	test   r10d,0x3f
    74a37e50a8bd:	je     0x74a37e50a8e2
    74a37e50a8c3:	mov    r11d,r10d
    74a37e50a8c6:	shr    r10d,1
    74a37e50a8c9:	and    r10d,0x1e
    74a37e50a8cd:	and    r11d,0x1
    74a37e50a8d1:	or     r10d,r11d
    74a37e50a8d4:	or     DWORD PTR [r12+0x314],r10d
    74a37e50a8dc:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e50a8e2:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e50a8e8:	lea    rdi,[rsp+0x110]
    74a37e50a8f0:	lea    rsi,[rsp+0xf0]
    74a37e50a8f8:	lea    rdx,[rsp+0x100]
    74a37e50a900:	mov    ecx,0x14
    74a37e50a905:	mov    r8d,0x0
    74a37e50a90b:	lea    r9,[r12+0x314]
    74a37e50a913:	movabs r11,0x571546550650
    74a37e50a91d:	call   r11
    74a37e50a920:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e50a926:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e50a92c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e50a932:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e50a938:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e50a93e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e50a944:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e50a94e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e50a958:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e50a962:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50a96a:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50a976:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e50a97f:	mov    rdx,rbx
    74a37e50a982:	shr    rdx,0x10
    74a37e50a986:	and    edx,0xc000
    74a37e50a98c:	mov    rax,rbx
    74a37e50a98f:	shr    rax,0x15
    74a37e50a993:	and    eax,0x100
    74a37e50a998:	xor    eax,0x100
    74a37e50a99d:	or     edx,eax
    74a37e50a99f:	mov    rax,rbx
    74a37e50a9a2:	shr    rax,0x1c
    74a37e50a9a6:	and    eax,0x1
    74a37e50a9a9:	or     edx,eax
    74a37e50a9ab:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e50a9b0:	add    rsp,0x8
    74a37e50a9b4:	ret
    74a37e50a9b5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e50a9c0:	sub    rsp,0x8
    74a37e50a9c4:	mov    QWORD PTR [r12+0x378],0x3
    74a37e50a9d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e50a9d6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e50a9dc:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e50a9e2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e50a9e8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e50a9ee:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e50a9f8:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e50aa02:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e50aa0c:	push   rdx
    74a37e50aa0d:	push   rsi
    74a37e50aa0e:	push   r10
    74a37e50aa10:	push   r11
    74a37e50aa12:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e50aa17:	mov    r10d,edx
    74a37e50aa1a:	and    r10d,0xc000
    74a37e50aa21:	shl    r10d,0x10
    74a37e50aa25:	mov    r11d,edx
    74a37e50aa28:	and    r11d,0x100
    74a37e50aa2f:	shl    r11d,0x15
    74a37e50aa33:	or     r10d,r11d
    74a37e50aa36:	and    edx,0x1
    74a37e50aa39:	shl    edx,0x1c
    74a37e50aa3c:	or     r10d,edx
    74a37e50aa3f:	btc    r10,0x1d
    74a37e50aa44:	mov    r11d,0xf0000000
    74a37e50aa4a:	and    r11,r10
    74a37e50aa4d:	movabs rsi,0xffffffff0fffffff
    74a37e50aa57:	and    rbx,rsi
    74a37e50aa5a:	or     rbx,r11
    74a37e50aa5d:	pop    r11
    74a37e50aa5f:	pop    r10
    74a37e50aa61:	pop    rsi
    74a37e50aa62:	pop    rdx
    74a37e50aa63:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50aa6b:	stmxcsr DWORD PTR [r12-0x28]
    74a37e50aa71:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e50aa76:	test   r10d,0x3f
    74a37e50aa7d:	je     0x74a37e50aaa2
    74a37e50aa83:	mov    r11d,r10d
    74a37e50aa86:	shr    r10d,1
    74a37e50aa89:	and    r10d,0x1e
    74a37e50aa8d:	and    r11d,0x1
    74a37e50aa91:	or     r10d,r11d
    74a37e50aa94:	or     DWORD PTR [r12+0x314],r10d
    74a37e50aa9c:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e50aaa2:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e50aaa8:	lea    rdi,[rsp+0x110]
    74a37e50aab0:	lea    rsi,[rsp+0xf0]
    74a37e50aab8:	lea    rdx,[rsp+0x100]
    74a37e50aac0:	mov    ecx,0x14
    74a37e50aac5:	mov    r8d,0x0
    74a37e50aacb:	lea    r9,[r12+0x314]
    74a37e50aad3:	movabs r11,0x571546550650
    74a37e50aadd:	call   r11
    74a37e50aae0:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e50aae6:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e50aaec:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e50aaf2:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e50aaf8:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e50aafe:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e50ab04:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e50ab0e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e50ab18:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e50ab22:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50ab2a:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50ab36:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e50ab3f:	mov    rdx,rbx
    74a37e50ab42:	shr    rdx,0x10
    74a37e50ab46:	and    edx,0xc000
    74a37e50ab4c:	mov    rax,rbx
    74a37e50ab4f:	shr    rax,0x15
    74a37e50ab53:	and    eax,0x100
    74a37e50ab58:	xor    eax,0x100
    74a37e50ab5d:	or     edx,eax
    74a37e50ab5f:	mov    rax,rbx
    74a37e50ab62:	shr    rax,0x1c
    74a37e50ab66:	and    eax,0x1
    74a37e50ab69:	or     edx,eax
    74a37e50ab6b:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e50ab70:	add    rsp,0x8
    74a37e50ab74:	ret
    74a37e50ab75:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e50ab80:	sub    rsp,0x8
    74a37e50ab84:	mov    QWORD PTR [r12+0x378],0x3
    74a37e50ab90:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e50ab96:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e50ab9c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e50aba2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e50aba8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e50abae:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e50abb4:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e50abbe:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e50abc8:	push   rdx
    74a37e50abc9:	push   rsi
    74a37e50abca:	push   r10
    74a37e50abcc:	push   r11
    74a37e50abce:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e50abd3:	mov    r10d,edx
    74a37e50abd6:	and    r10d,0xc000
    74a37e50abdd:	shl    r10d,0x10
    74a37e50abe1:	mov    r11d,edx
    74a37e50abe4:	and    r11d,0x100
    74a37e50abeb:	shl    r11d,0x15
    74a37e50abef:	or     r10d,r11d
    74a37e50abf2:	and    edx,0x1
    74a37e50abf5:	shl    edx,0x1c
    74a37e50abf8:	or     r10d,edx
    74a37e50abfb:	btc    r10,0x1d
    74a37e50ac00:	mov    r11d,0xf0000000
    74a37e50ac06:	and    r11,r10
    74a37e50ac09:	movabs rsi,0xffffffff0fffffff
    74a37e50ac13:	and    rbx,rsi
    74a37e50ac16:	or     rbx,r11
    74a37e50ac19:	pop    r11
    74a37e50ac1b:	pop    r10
    74a37e50ac1d:	pop    rsi
    74a37e50ac1e:	pop    rdx
    74a37e50ac1f:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50ac27:	stmxcsr DWORD PTR [r12-0x28]
    74a37e50ac2d:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e50ac32:	test   r10d,0x3f
    74a37e50ac39:	je     0x74a37e50ac5e
    74a37e50ac3f:	mov    r11d,r10d
    74a37e50ac42:	shr    r10d,1
    74a37e50ac45:	and    r10d,0x1e
    74a37e50ac49:	and    r11d,0x1
    74a37e50ac4d:	or     r10d,r11d
    74a37e50ac50:	or     DWORD PTR [r12+0x314],r10d
    74a37e50ac58:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e50ac5e:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e50ac64:	lea    rdi,[rsp+0x110]
    74a37e50ac6c:	lea    rsi,[rsp+0xf0]
    74a37e50ac74:	lea    rdx,[rsp+0x100]
    74a37e50ac7c:	mov    ecx,0x56
    74a37e50ac81:	mov    r8d,0x0
    74a37e50ac87:	lea    r9,[r12+0x314]
    74a37e50ac8f:	movabs r11,0x571546550650
    74a37e50ac99:	call   r11
    74a37e50ac9c:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e50aca2:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e50aca8:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e50acae:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e50acb4:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e50acba:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e50acc0:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e50acc6:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e50acd0:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e50acda:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50ace2:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50acee:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e50acf7:	mov    rdx,rbx
    74a37e50acfa:	shr    rdx,0x10
    74a37e50acfe:	and    edx,0xc000
    74a37e50ad04:	mov    rax,rbx
    74a37e50ad07:	shr    rax,0x15
    74a37e50ad0b:	and    eax,0x100
    74a37e50ad10:	xor    eax,0x100
    74a37e50ad15:	or     edx,eax
    74a37e50ad17:	mov    rax,rbx
    74a37e50ad1a:	shr    rax,0x1c
    74a37e50ad1e:	and    eax,0x1
    74a37e50ad21:	or     edx,eax
    74a37e50ad23:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e50ad28:	add    rsp,0x8
    74a37e50ad2c:	ret
    74a37e50ad2d:	nop    DWORD PTR [rax]
    74a37e50ad30:	sub    rsp,0x8
    74a37e50ad34:	mov    QWORD PTR [r12+0x378],0x3
    74a37e50ad40:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e50ad46:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e50ad4c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e50ad52:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e50ad58:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e50ad5e:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e50ad68:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e50ad72:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e50ad7c:	push   rdx
    74a37e50ad7d:	push   rsi
    74a37e50ad7e:	push   r10
    74a37e50ad80:	push   r11
    74a37e50ad82:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e50ad87:	mov    r10d,edx
    74a37e50ad8a:	and    r10d,0xc000
    74a37e50ad91:	shl    r10d,0x10
    74a37e50ad95:	mov    r11d,edx
    74a37e50ad98:	and    r11d,0x100
    74a37e50ad9f:	shl    r11d,0x15
    74a37e50ada3:	or     r10d,r11d
    74a37e50ada6:	and    edx,0x1
    74a37e50ada9:	shl    edx,0x1c
    74a37e50adac:	or     r10d,edx
    74a37e50adaf:	btc    r10,0x1d
    74a37e50adb4:	mov    r11d,0xf0000000
    74a37e50adba:	and    r11,r10
    74a37e50adbd:	movabs rsi,0xffffffff0fffffff
    74a37e50adc7:	and    rbx,rsi
    74a37e50adca:	or     rbx,r11
    74a37e50adcd:	pop    r11
    74a37e50adcf:	pop    r10
    74a37e50add1:	pop    rsi
    74a37e50add2:	pop    rdx
    74a37e50add3:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50addb:	stmxcsr DWORD PTR [r12-0x28]
    74a37e50ade1:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e50ade6:	test   r10d,0x3f
    74a37e50aded:	je     0x74a37e50ae12
    74a37e50adf3:	mov    r11d,r10d
    74a37e50adf6:	shr    r10d,1
    74a37e50adf9:	and    r10d,0x1e
    74a37e50adfd:	and    r11d,0x1
    74a37e50ae01:	or     r10d,r11d
    74a37e50ae04:	or     DWORD PTR [r12+0x314],r10d
    74a37e50ae0c:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e50ae12:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e50ae18:	lea    rdi,[rsp+0x110]
    74a37e50ae20:	lea    rsi,[rsp+0xf0]
    74a37e50ae28:	lea    rdx,[rsp+0x100]
    74a37e50ae30:	mov    ecx,0x56
    74a37e50ae35:	mov    r8d,0x0
    74a37e50ae3b:	lea    r9,[r12+0x314]
    74a37e50ae43:	movabs r11,0x571546550650
    74a37e50ae4d:	call   r11
    74a37e50ae50:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e50ae56:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e50ae5c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e50ae62:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e50ae68:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e50ae6e:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e50ae74:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e50ae7e:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e50ae88:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e50ae92:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50ae9a:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50aea6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e50aeaf:	mov    rdx,rbx
    74a37e50aeb2:	shr    rdx,0x10
    74a37e50aeb6:	and    edx,0xc000
    74a37e50aebc:	mov    rax,rbx
    74a37e50aebf:	shr    rax,0x15
    74a37e50aec3:	and    eax,0x100
    74a37e50aec8:	xor    eax,0x100
    74a37e50aecd:	or     edx,eax
    74a37e50aecf:	mov    rax,rbx
    74a37e50aed2:	shr    rax,0x1c
    74a37e50aed6:	and    eax,0x1
    74a37e50aed9:	or     edx,eax
    74a37e50aedb:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e50aee0:	add    rsp,0x8
    74a37e50aee4:	ret
    74a37e50aee5:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e50aef0:	sub    rsp,0x8
    74a37e50aef4:	mov    QWORD PTR [r12+0x378],0x3
    74a37e50af00:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e50af06:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e50af0c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e50af12:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e50af18:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e50af1e:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e50af24:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e50af2e:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e50af38:	movdqu XMMWORD PTR [rsp+0xb0],xmm11
    74a37e50af42:	push   rdx
    74a37e50af43:	push   rsi
    74a37e50af44:	push   r10
    74a37e50af46:	push   r11
    74a37e50af48:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e50af4d:	mov    r10d,edx
    74a37e50af50:	and    r10d,0xc000
    74a37e50af57:	shl    r10d,0x10
    74a37e50af5b:	mov    r11d,edx
    74a37e50af5e:	and    r11d,0x100
    74a37e50af65:	shl    r11d,0x15
    74a37e50af69:	or     r10d,r11d
    74a37e50af6c:	and    edx,0x1
    74a37e50af6f:	shl    edx,0x1c
    74a37e50af72:	or     r10d,edx
    74a37e50af75:	btc    r10,0x1d
    74a37e50af7a:	mov    r11d,0xf0000000
    74a37e50af80:	and    r11,r10
    74a37e50af83:	movabs rsi,0xffffffff0fffffff
    74a37e50af8d:	and    rbx,rsi
    74a37e50af90:	or     rbx,r11
    74a37e50af93:	pop    r11
    74a37e50af95:	pop    r10
    74a37e50af97:	pop    rsi
    74a37e50af98:	pop    rdx
    74a37e50af99:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50afa1:	stmxcsr DWORD PTR [r12-0x28]
    74a37e50afa7:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e50afac:	test   r10d,0x3f
    74a37e50afb3:	je     0x74a37e50afd8
    74a37e50afb9:	mov    r11d,r10d
    74a37e50afbc:	shr    r10d,1
    74a37e50afbf:	and    r10d,0x1e
    74a37e50afc3:	and    r11d,0x1
    74a37e50afc7:	or     r10d,r11d
    74a37e50afca:	or     DWORD PTR [r12+0x314],r10d
    74a37e50afd2:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e50afd8:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e50afde:	lea    rdi,[rsp+0x110]
    74a37e50afe6:	lea    rsi,[rsp+0xf0]
    74a37e50afee:	lea    rdx,[rsp+0x100]
    74a37e50aff6:	mov    ecx,0x14
    74a37e50affb:	mov    r8d,0x0
    74a37e50b001:	lea    r9,[r12+0x314]
    74a37e50b009:	movabs r11,0x571546550650
    74a37e50b013:	call   r11
    74a37e50b016:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e50b01c:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e50b022:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e50b028:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e50b02e:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e50b034:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e50b03a:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e50b040:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e50b04a:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e50b054:	movdqu xmm11,XMMWORD PTR [rsp+0xb0]
    74a37e50b05e:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50b066:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50b072:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e50b07b:	mov    rdx,rbx
    74a37e50b07e:	shr    rdx,0x10
    74a37e50b082:	and    edx,0xc000
    74a37e50b088:	mov    rax,rbx
    74a37e50b08b:	shr    rax,0x15
    74a37e50b08f:	and    eax,0x100
    74a37e50b094:	xor    eax,0x100
    74a37e50b099:	or     edx,eax
    74a37e50b09b:	mov    rax,rbx
    74a37e50b09e:	shr    rax,0x1c
    74a37e50b0a2:	and    eax,0x1
    74a37e50b0a5:	or     edx,eax
    74a37e50b0a7:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e50b0ac:	add    rsp,0x8
    74a37e50b0b0:	ret
    74a37e50b0b1:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e50b0c0:	sub    rsp,0x8
    74a37e50b0c4:	mov    QWORD PTR [r12+0x378],0x3
    74a37e50b0d0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e50b0d6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e50b0dc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e50b0e2:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e50b0e8:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e50b0ee:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e50b0f8:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e50b102:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e50b10c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e50b116:	push   rdx
    74a37e50b117:	push   rsi
    74a37e50b118:	push   r10
    74a37e50b11a:	push   r11
    74a37e50b11c:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e50b121:	mov    r10d,edx
    74a37e50b124:	and    r10d,0xc000
    74a37e50b12b:	shl    r10d,0x10
    74a37e50b12f:	mov    r11d,edx
    74a37e50b132:	and    r11d,0x100
    74a37e50b139:	shl    r11d,0x15
    74a37e50b13d:	or     r10d,r11d
    74a37e50b140:	and    edx,0x1
    74a37e50b143:	shl    edx,0x1c
    74a37e50b146:	or     r10d,edx
    74a37e50b149:	btc    r10,0x1d
    74a37e50b14e:	mov    r11d,0xf0000000
    74a37e50b154:	and    r11,r10
    74a37e50b157:	movabs rsi,0xffffffff0fffffff
    74a37e50b161:	and    rbx,rsi
    74a37e50b164:	or     rbx,r11
    74a37e50b167:	pop    r11
    74a37e50b169:	pop    r10
    74a37e50b16b:	pop    rsi
    74a37e50b16c:	pop    rdx
    74a37e50b16d:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50b175:	stmxcsr DWORD PTR [r12-0x28]
    74a37e50b17b:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e50b180:	test   r10d,0x3f
    74a37e50b187:	je     0x74a37e50b1ac
    74a37e50b18d:	mov    r11d,r10d
    74a37e50b190:	shr    r10d,1
    74a37e50b193:	and    r10d,0x1e
    74a37e50b197:	and    r11d,0x1
    74a37e50b19b:	or     r10d,r11d
    74a37e50b19e:	or     DWORD PTR [r12+0x314],r10d
    74a37e50b1a6:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e50b1ac:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e50b1b2:	lea    rdi,[rsp+0x110]
    74a37e50b1ba:	lea    rsi,[rsp+0xf0]
    74a37e50b1c2:	lea    rdx,[rsp+0x100]
    74a37e50b1ca:	mov    ecx,0x56
    74a37e50b1cf:	mov    r8d,0x0
    74a37e50b1d5:	lea    r9,[r12+0x314]
    74a37e50b1dd:	movabs r11,0x571546550650
    74a37e50b1e7:	call   r11
    74a37e50b1ea:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e50b1f0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e50b1f6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e50b1fc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e50b202:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e50b208:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e50b20e:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e50b218:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e50b222:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e50b22c:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e50b236:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50b23e:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50b24a:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e50b253:	mov    rdx,rbx
    74a37e50b256:	shr    rdx,0x10
    74a37e50b25a:	and    edx,0xc000
    74a37e50b260:	mov    rax,rbx
    74a37e50b263:	shr    rax,0x15
    74a37e50b267:	and    eax,0x100
    74a37e50b26c:	xor    eax,0x100
    74a37e50b271:	or     edx,eax
    74a37e50b273:	mov    rax,rbx
    74a37e50b276:	shr    rax,0x1c
    74a37e50b27a:	and    eax,0x1
    74a37e50b27d:	or     edx,eax
    74a37e50b27f:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e50b284:	add    rsp,0x8
    74a37e50b288:	ret
    74a37e50b289:	nop    DWORD PTR [rax+0x0]
    74a37e50b290:	sub    rsp,0x8
    74a37e50b294:	mov    QWORD PTR [r12+0x378],0x3
    74a37e50b2a0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e50b2a6:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e50b2ac:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e50b2b2:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e50b2b8:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e50b2be:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e50b2c4:	movdqu XMMWORD PTR [rsp+0x80],xmm8
    74a37e50b2ce:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e50b2d8:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e50b2e2:	push   rdx
    74a37e50b2e3:	push   rsi
    74a37e50b2e4:	push   r10
    74a37e50b2e6:	push   r11
    74a37e50b2e8:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e50b2ed:	mov    r10d,edx
    74a37e50b2f0:	and    r10d,0xc000
    74a37e50b2f7:	shl    r10d,0x10
    74a37e50b2fb:	mov    r11d,edx
    74a37e50b2fe:	and    r11d,0x100
    74a37e50b305:	shl    r11d,0x15
    74a37e50b309:	or     r10d,r11d
    74a37e50b30c:	and    edx,0x1
    74a37e50b30f:	shl    edx,0x1c
    74a37e50b312:	or     r10d,edx
    74a37e50b315:	btc    r10,0x1d
    74a37e50b31a:	mov    r11d,0xf0000000
    74a37e50b320:	and    r11,r10
    74a37e50b323:	movabs rsi,0xffffffff0fffffff
    74a37e50b32d:	and    rbx,rsi
    74a37e50b330:	or     rbx,r11
    74a37e50b333:	pop    r11
    74a37e50b335:	pop    r10
    74a37e50b337:	pop    rsi
    74a37e50b338:	pop    rdx
    74a37e50b339:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50b341:	stmxcsr DWORD PTR [r12-0x28]
    74a37e50b347:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e50b34c:	test   r10d,0x3f
    74a37e50b353:	je     0x74a37e50b378
    74a37e50b359:	mov    r11d,r10d
    74a37e50b35c:	shr    r10d,1
    74a37e50b35f:	and    r10d,0x1e
    74a37e50b363:	and    r11d,0x1
    74a37e50b367:	or     r10d,r11d
    74a37e50b36a:	or     DWORD PTR [r12+0x314],r10d
    74a37e50b372:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e50b378:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e50b37e:	lea    rdi,[rsp+0x110]
    74a37e50b386:	lea    rsi,[rsp+0xf0]
    74a37e50b38e:	lea    rdx,[rsp+0x100]
    74a37e50b396:	mov    ecx,0x56
    74a37e50b39b:	mov    r8d,0x0
    74a37e50b3a1:	lea    r9,[r12+0x314]
    74a37e50b3a9:	movabs r11,0x571546550650
    74a37e50b3b3:	call   r11
    74a37e50b3b6:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e50b3bc:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e50b3c2:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e50b3c8:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e50b3ce:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e50b3d4:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e50b3da:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e50b3e0:	movdqu xmm8,XMMWORD PTR [rsp+0x80]
    74a37e50b3ea:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e50b3f4:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e50b3fe:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50b406:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50b412:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e50b41b:	mov    rdx,rbx
    74a37e50b41e:	shr    rdx,0x10
    74a37e50b422:	and    edx,0xc000
    74a37e50b428:	mov    rax,rbx
    74a37e50b42b:	shr    rax,0x15
    74a37e50b42f:	and    eax,0x100
    74a37e50b434:	xor    eax,0x100
    74a37e50b439:	or     edx,eax
    74a37e50b43b:	mov    rax,rbx
    74a37e50b43e:	shr    rax,0x1c
    74a37e50b442:	and    eax,0x1
    74a37e50b445:	or     edx,eax
    74a37e50b447:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e50b44c:	add    rsp,0x8
    74a37e50b450:	ret
    74a37e50b451:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e50b460:	sub    rsp,0x8
    74a37e50b464:	mov    QWORD PTR [r12+0x378],0x3
    74a37e50b470:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e50b476:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e50b47c:	movdqu XMMWORD PTR [rsp+0x60],xmm6
    74a37e50b482:	movdqu XMMWORD PTR [rsp+0x70],xmm7
    74a37e50b488:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e50b492:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e50b49c:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e50b4a6:	push   rdx
    74a37e50b4a7:	push   rsi
    74a37e50b4a8:	push   r10
    74a37e50b4aa:	push   r11
    74a37e50b4ac:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e50b4b1:	mov    r10d,edx
    74a37e50b4b4:	and    r10d,0xc000
    74a37e50b4bb:	shl    r10d,0x10
    74a37e50b4bf:	mov    r11d,edx
    74a37e50b4c2:	and    r11d,0x100
    74a37e50b4c9:	shl    r11d,0x15
    74a37e50b4cd:	or     r10d,r11d
    74a37e50b4d0:	and    edx,0x1
    74a37e50b4d3:	shl    edx,0x1c
    74a37e50b4d6:	or     r10d,edx
    74a37e50b4d9:	btc    r10,0x1d
    74a37e50b4de:	mov    r11d,0xf0000000
    74a37e50b4e4:	and    r11,r10
    74a37e50b4e7:	movabs rsi,0xffffffff0fffffff
    74a37e50b4f1:	and    rbx,rsi
    74a37e50b4f4:	or     rbx,r11
    74a37e50b4f7:	pop    r11
    74a37e50b4f9:	pop    r10
    74a37e50b4fb:	pop    rsi
    74a37e50b4fc:	pop    rdx
    74a37e50b4fd:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50b505:	stmxcsr DWORD PTR [r12-0x28]
    74a37e50b50b:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e50b510:	test   r10d,0x3f
    74a37e50b517:	je     0x74a37e50b53c
    74a37e50b51d:	mov    r11d,r10d
    74a37e50b520:	shr    r10d,1
    74a37e50b523:	and    r10d,0x1e
    74a37e50b527:	and    r11d,0x1
    74a37e50b52b:	or     r10d,r11d
    74a37e50b52e:	or     DWORD PTR [r12+0x314],r10d
    74a37e50b536:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e50b53c:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e50b542:	lea    rdi,[rsp+0x110]
    74a37e50b54a:	lea    rsi,[rsp+0xf0]
    74a37e50b552:	lea    rdx,[rsp+0x100]
    74a37e50b55a:	mov    ecx,0x14
    74a37e50b55f:	mov    r8d,0x0
    74a37e50b565:	lea    r9,[r12+0x314]
    74a37e50b56d:	movabs r11,0x571546550650
    74a37e50b577:	call   r11
    74a37e50b57a:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e50b580:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e50b586:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e50b58c:	movdqu xmm6,XMMWORD PTR [rsp+0x60]
    74a37e50b592:	movdqu xmm7,XMMWORD PTR [rsp+0x70]
    74a37e50b598:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e50b5a2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e50b5ac:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e50b5b6:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50b5be:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50b5ca:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e50b5d3:	mov    rdx,rbx
    74a37e50b5d6:	shr    rdx,0x10
    74a37e50b5da:	and    edx,0xc000
    74a37e50b5e0:	mov    rax,rbx
    74a37e50b5e3:	shr    rax,0x15
    74a37e50b5e7:	and    eax,0x100
    74a37e50b5ec:	xor    eax,0x100
    74a37e50b5f1:	or     edx,eax
    74a37e50b5f3:	mov    rax,rbx
    74a37e50b5f6:	shr    rax,0x1c
    74a37e50b5fa:	and    eax,0x1
    74a37e50b5fd:	or     edx,eax
    74a37e50b5ff:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e50b604:	add    rsp,0x8
    74a37e50b608:	ret
    74a37e50b609:	nop    DWORD PTR [rax+0x0]
    74a37e50b610:	sub    rsp,0x8
    74a37e50b614:	mov    QWORD PTR [r12+0x378],0x3
    74a37e50b620:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e50b626:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e50b62c:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e50b632:	movdqu XMMWORD PTR [rsp+0x90],xmm9
    74a37e50b63c:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e50b646:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e50b650:	push   rdx
    74a37e50b651:	push   rsi
    74a37e50b652:	push   r10
    74a37e50b654:	push   r11
    74a37e50b656:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e50b65b:	mov    r10d,edx
    74a37e50b65e:	and    r10d,0xc000
    74a37e50b665:	shl    r10d,0x10
    74a37e50b669:	mov    r11d,edx
    74a37e50b66c:	and    r11d,0x100
    74a37e50b673:	shl    r11d,0x15
    74a37e50b677:	or     r10d,r11d
    74a37e50b67a:	and    edx,0x1
    74a37e50b67d:	shl    edx,0x1c
    74a37e50b680:	or     r10d,edx
    74a37e50b683:	btc    r10,0x1d
    74a37e50b688:	mov    r11d,0xf0000000
    74a37e50b68e:	and    r11,r10
    74a37e50b691:	movabs rsi,0xffffffff0fffffff
    74a37e50b69b:	and    rbx,rsi
    74a37e50b69e:	or     rbx,r11
    74a37e50b6a1:	pop    r11
    74a37e50b6a3:	pop    r10
    74a37e50b6a5:	pop    rsi
    74a37e50b6a6:	pop    rdx
    74a37e50b6a7:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50b6af:	stmxcsr DWORD PTR [r12-0x28]
    74a37e50b6b5:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e50b6ba:	test   r10d,0x3f
    74a37e50b6c1:	je     0x74a37e50b6e6
    74a37e50b6c7:	mov    r11d,r10d
    74a37e50b6ca:	shr    r10d,1
    74a37e50b6cd:	and    r10d,0x1e
    74a37e50b6d1:	and    r11d,0x1
    74a37e50b6d5:	or     r10d,r11d
    74a37e50b6d8:	or     DWORD PTR [r12+0x314],r10d
    74a37e50b6e0:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e50b6e6:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e50b6ec:	lea    rdi,[rsp+0x110]
    74a37e50b6f4:	lea    rsi,[rsp+0xf0]
    74a37e50b6fc:	lea    rdx,[rsp+0x100]
    74a37e50b704:	mov    ecx,0x14
    74a37e50b709:	mov    r8d,0x0
    74a37e50b70f:	lea    r9,[r12+0x314]
    74a37e50b717:	movabs r11,0x571546550650
    74a37e50b721:	call   r11
    74a37e50b724:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e50b72a:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e50b730:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e50b736:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e50b73c:	movdqu xmm9,XMMWORD PTR [rsp+0x90]
    74a37e50b746:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e50b750:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e50b75a:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50b762:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50b76e:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e50b777:	mov    rdx,rbx
    74a37e50b77a:	shr    rdx,0x10
    74a37e50b77e:	and    edx,0xc000
    74a37e50b784:	mov    rax,rbx
    74a37e50b787:	shr    rax,0x15
    74a37e50b78b:	and    eax,0x100
    74a37e50b790:	xor    eax,0x100
    74a37e50b795:	or     edx,eax
    74a37e50b797:	mov    rax,rbx
    74a37e50b79a:	shr    rax,0x1c
    74a37e50b79e:	and    eax,0x1
    74a37e50b7a1:	or     edx,eax
    74a37e50b7a3:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e50b7a8:	add    rsp,0x8
    74a37e50b7ac:	ret
    74a37e50b7ad:	nop    DWORD PTR [rax]
    74a37e50b7b0:	sub    rsp,0x8
    74a37e50b7b4:	mov    QWORD PTR [r12+0x378],0x3
    74a37e50b7c0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e50b7c6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e50b7cc:	movdqu XMMWORD PTR [rsp+0x50],xmm5
    74a37e50b7d2:	movdqu XMMWORD PTR [rsp+0xa0],xmm10
    74a37e50b7dc:	movdqu XMMWORD PTR [rsp+0xc0],xmm12
    74a37e50b7e6:	push   rdx
    74a37e50b7e7:	push   rsi
    74a37e50b7e8:	push   r10
    74a37e50b7ea:	push   r11
    74a37e50b7ec:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e50b7f1:	mov    r10d,edx
    74a37e50b7f4:	and    r10d,0xc000
    74a37e50b7fb:	shl    r10d,0x10
    74a37e50b7ff:	mov    r11d,edx
    74a37e50b802:	and    r11d,0x100
    74a37e50b809:	shl    r11d,0x15
    74a37e50b80d:	or     r10d,r11d
    74a37e50b810:	and    edx,0x1
    74a37e50b813:	shl    edx,0x1c
    74a37e50b816:	or     r10d,edx
    74a37e50b819:	btc    r10,0x1d
    74a37e50b81e:	mov    r11d,0xf0000000
    74a37e50b824:	and    r11,r10
    74a37e50b827:	movabs rsi,0xffffffff0fffffff
    74a37e50b831:	and    rbx,rsi
    74a37e50b834:	or     rbx,r11
    74a37e50b837:	pop    r11
    74a37e50b839:	pop    r10
    74a37e50b83b:	pop    rsi
    74a37e50b83c:	pop    rdx
    74a37e50b83d:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50b845:	stmxcsr DWORD PTR [r12-0x28]
    74a37e50b84b:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e50b850:	test   r10d,0x3f
    74a37e50b857:	je     0x74a37e50b87c
    74a37e50b85d:	mov    r11d,r10d
    74a37e50b860:	shr    r10d,1
    74a37e50b863:	and    r10d,0x1e
    74a37e50b867:	and    r11d,0x1
    74a37e50b86b:	or     r10d,r11d
    74a37e50b86e:	or     DWORD PTR [r12+0x314],r10d
    74a37e50b876:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e50b87c:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e50b882:	lea    rdi,[rsp+0x110]
    74a37e50b88a:	lea    rsi,[rsp+0xf0]
    74a37e50b892:	lea    rdx,[rsp+0x100]
    74a37e50b89a:	mov    ecx,0x14
    74a37e50b89f:	mov    r8d,0x0
    74a37e50b8a5:	lea    r9,[r12+0x314]
    74a37e50b8ad:	movabs r11,0x571546550650
    74a37e50b8b7:	call   r11
    74a37e50b8ba:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e50b8c0:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e50b8c6:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e50b8cc:	movdqu xmm5,XMMWORD PTR [rsp+0x50]
    74a37e50b8d2:	movdqu xmm10,XMMWORD PTR [rsp+0xa0]
    74a37e50b8dc:	movdqu xmm12,XMMWORD PTR [rsp+0xc0]
    74a37e50b8e6:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50b8ee:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50b8fa:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e50b903:	mov    rdx,rbx
    74a37e50b906:	shr    rdx,0x10
    74a37e50b90a:	and    edx,0xc000
    74a37e50b910:	mov    rax,rbx
    74a37e50b913:	shr    rax,0x15
    74a37e50b917:	and    eax,0x100
    74a37e50b91c:	xor    eax,0x100
    74a37e50b921:	or     edx,eax
    74a37e50b923:	mov    rax,rbx
    74a37e50b926:	shr    rax,0x1c
    74a37e50b92a:	and    eax,0x1
    74a37e50b92d:	or     edx,eax
    74a37e50b92f:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e50b934:	add    rsp,0x8
    74a37e50b938:	ret
    74a37e50b939:	nop    DWORD PTR [rax+0x0]
    74a37e50b940:	sub    rsp,0x8
    74a37e50b944:	mov    QWORD PTR [r12+0x378],0x3
    74a37e50b950:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e50b956:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    74a37e50b95c:	push   rdx
    74a37e50b95d:	push   rsi
    74a37e50b95e:	push   r10
    74a37e50b960:	push   r11
    74a37e50b962:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e50b967:	mov    r10d,edx
    74a37e50b96a:	and    r10d,0xc000
    74a37e50b971:	shl    r10d,0x10
    74a37e50b975:	mov    r11d,edx
    74a37e50b978:	and    r11d,0x100
    74a37e50b97f:	shl    r11d,0x15
    74a37e50b983:	or     r10d,r11d
    74a37e50b986:	and    edx,0x1
    74a37e50b989:	shl    edx,0x1c
    74a37e50b98c:	or     r10d,edx
    74a37e50b98f:	btc    r10,0x1d
    74a37e50b994:	mov    r11d,0xf0000000
    74a37e50b99a:	and    r11,r10
    74a37e50b99d:	movabs rsi,0xffffffff0fffffff
    74a37e50b9a7:	and    rbx,rsi
    74a37e50b9aa:	or     rbx,r11
    74a37e50b9ad:	pop    r11
    74a37e50b9af:	pop    r10
    74a37e50b9b1:	pop    rsi
    74a37e50b9b2:	pop    rdx
    74a37e50b9b3:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50b9bb:	stmxcsr DWORD PTR [r12-0x28]
    74a37e50b9c1:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e50b9c6:	test   r10d,0x3f
    74a37e50b9cd:	je     0x74a37e50b9f2
    74a37e50b9d3:	mov    r11d,r10d
    74a37e50b9d6:	shr    r10d,1
    74a37e50b9d9:	and    r10d,0x1e
    74a37e50b9dd:	and    r11d,0x1
    74a37e50b9e1:	or     r10d,r11d
    74a37e50b9e4:	or     DWORD PTR [r12+0x314],r10d
    74a37e50b9ec:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e50b9f2:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e50b9f8:	lea    rdi,[rsp+0x110]
    74a37e50ba00:	lea    rsi,[rsp+0xf0]
    74a37e50ba08:	lea    rdx,[rsp+0x100]
    74a37e50ba10:	mov    ecx,0xc
    74a37e50ba15:	mov    r8d,0x0
    74a37e50ba1b:	lea    r9,[r12+0x314]
    74a37e50ba23:	movabs r11,0x571546550650
    74a37e50ba2d:	call   r11
    74a37e50ba30:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e50ba36:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e50ba3c:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    74a37e50ba42:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50ba4a:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50ba56:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e50ba5f:	mov    rdx,rbx
    74a37e50ba62:	shr    rdx,0x10
    74a37e50ba66:	and    edx,0xc000
    74a37e50ba6c:	mov    rax,rbx
    74a37e50ba6f:	shr    rax,0x15
    74a37e50ba73:	and    eax,0x100
    74a37e50ba78:	xor    eax,0x100
    74a37e50ba7d:	or     edx,eax
    74a37e50ba7f:	mov    rax,rbx
    74a37e50ba82:	shr    rax,0x1c
    74a37e50ba86:	and    eax,0x1
    74a37e50ba89:	or     edx,eax
    74a37e50ba8b:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e50ba90:	add    rsp,0x8
    74a37e50ba94:	ret
    74a37e50ba95:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    74a37e50baa0:	sub    rsp,0x8
    74a37e50baa4:	mov    QWORD PTR [r12+0x378],0x3
    74a37e50bab0:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    74a37e50bab6:	movdqu XMMWORD PTR [rsp+0x40],xmm4
    74a37e50babc:	push   rdx
    74a37e50babd:	push   rsi
    74a37e50babe:	push   r10
    74a37e50bac0:	push   r11
    74a37e50bac2:	mov    rdx,QWORD PTR [rsp+0x30]
    74a37e50bac7:	mov    r10d,edx
    74a37e50baca:	and    r10d,0xc000
    74a37e50bad1:	shl    r10d,0x10
    74a37e50bad5:	mov    r11d,edx
    74a37e50bad8:	and    r11d,0x100
    74a37e50badf:	shl    r11d,0x15
    74a37e50bae3:	or     r10d,r11d
    74a37e50bae6:	and    edx,0x1
    74a37e50bae9:	shl    edx,0x1c
    74a37e50baec:	or     r10d,edx
    74a37e50baef:	btc    r10,0x1d
    74a37e50baf4:	mov    r11d,0xf0000000
    74a37e50bafa:	and    r11,r10
    74a37e50bafd:	movabs rsi,0xffffffff0fffffff
    74a37e50bb07:	and    rbx,rsi
    74a37e50bb0a:	or     rbx,r11
    74a37e50bb0d:	pop    r11
    74a37e50bb0f:	pop    r10
    74a37e50bb11:	pop    rsi
    74a37e50bb12:	pop    rdx
    74a37e50bb13:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50bb1b:	stmxcsr DWORD PTR [r12-0x28]
    74a37e50bb21:	mov    r10d,DWORD PTR [r12-0x28]
    74a37e50bb26:	test   r10d,0x3f
    74a37e50bb2d:	je     0x74a37e50bb52
    74a37e50bb33:	mov    r11d,r10d
    74a37e50bb36:	shr    r10d,1
    74a37e50bb39:	and    r10d,0x1e
    74a37e50bb3d:	and    r11d,0x1
    74a37e50bb41:	or     r10d,r11d
    74a37e50bb44:	or     DWORD PTR [r12+0x314],r10d
    74a37e50bb4c:	and    DWORD PTR [r12-0x28],0xffffffc0
    74a37e50bb52:	ldmxcsr DWORD PTR [r12-0x38]
    74a37e50bb58:	lea    rdi,[rsp+0x110]
    74a37e50bb60:	lea    rsi,[rsp+0xf0]
    74a37e50bb68:	lea    rdx,[rsp+0x100]
    74a37e50bb70:	mov    ecx,0xc
    74a37e50bb75:	mov    r8d,0x0
    74a37e50bb7b:	lea    r9,[r12+0x314]
    74a37e50bb83:	movabs r11,0x571546550650
    74a37e50bb8d:	call   r11
    74a37e50bb90:	ldmxcsr DWORD PTR [r12-0x28]
    74a37e50bb96:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    74a37e50bb9c:	movdqu xmm4,XMMWORD PTR [rsp+0x40]
    74a37e50bba2:	mov    rbx,QWORD PTR [r12+0x108]
    74a37e50bbaa:	mov    QWORD PTR [r12+0x378],0x2
    74a37e50bbb6:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    74a37e50bbbf:	mov    rdx,rbx
    74a37e50bbc2:	shr    rdx,0x10
    74a37e50bbc6:	and    edx,0xc000
    74a37e50bbcc:	mov    rax,rbx
    74a37e50bbcf:	shr    rax,0x15
    74a37e50bbd3:	and    eax,0x100
    74a37e50bbd8:	xor    eax,0x100
    74a37e50bbdd:	or     edx,eax
    74a37e50bbdf:	mov    rax,rbx
    74a37e50bbe2:	shr    rax,0x1c
    74a37e50bbe6:	and    eax,0x1
    74a37e50bbe9:	or     edx,eax
    74a37e50bbeb:	mov    QWORD PTR [rsp+0x10],rdx
    74a37e50bbf0:	add    rsp,0x8
    74a37e50bbf4:	ret
    74a37e50bbf5:	mov    eax,0x410400
    74a37e50bbfa:	mov    QWORD PTR [r12+0x100],rax
    74a37e50bc02:	push   rdx
    74a37e50bc03:	push   rsi
    74a37e50bc04:	push   r10
    74a37e50bc06:	push   r11
    74a37e50bc08:	mov    r11,rax
    74a37e50bc0b:	lahf
    74a37e50bc0c:	seto   al
    74a37e50bc0f:	mov    WORD PTR [rsp+0x20],ax
    74a37e50bc14:	mov    rax,r11
    74a37e50bc17:	mov    rdx,QWORD PTR [rsp+0x20]
    74a37e50bc1c:	mov    r10d,edx
    74a37e50bc1f:	and    r10d,0xc000
    74a37e50bc26:	shl    r10d,0x10
    74a37e50bc2a:	mov    r11d,edx
    74a37e50bc2d:	and    r11d,0x100
    74a37e50bc34:	shl    r11d,0x15
    74a37e50bc38:	or     r10d,r11d
    74a37e50bc3b:	and    edx,0x1
    74a37e50bc3e:	shl    edx,0x1c
    74a37e50bc41:	or     r10d,edx
    74a37e50bc44:	btc    r10,0x1d
    74a37e50bc49:	mov    r11d,0xf0000000
    74a37e50bc4f:	and    r11,r10
    74a37e50bc52:	movabs rsi,0xffffffff0fffffff
    74a37e50bc5c:	and    rbx,rsi
    74a37e50bc5f:	or     rbx,r11
    74a37e50bc62:	pop    r11
    74a37e50bc64:	pop    r10
    74a37e50bc66:	pop    rsi
    74a37e50bc67:	pop    rdx
    74a37e50bc68:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50bc70:	add    rsp,0x150
    74a37e50bc77:	mov    eax,0xc
    74a37e50bc7c:	movabs r11,0x5715466e9ca0
    74a37e50bc86:	jmp    r11
    74a37e50bc89:	mov    eax,0x41048c
    74a37e50bc8e:	mov    QWORD PTR [r12+0x100],rax
    74a37e50bc96:	push   rdx
    74a37e50bc97:	push   rsi
    74a37e50bc98:	push   r10
    74a37e50bc9a:	push   r11
    74a37e50bc9c:	mov    r11,rax
    74a37e50bc9f:	lahf
    74a37e50bca0:	seto   al
    74a37e50bca3:	mov    WORD PTR [rsp+0x20],ax
    74a37e50bca8:	mov    rax,r11
    74a37e50bcab:	mov    rdx,QWORD PTR [rsp+0x20]
    74a37e50bcb0:	mov    r10d,edx
    74a37e50bcb3:	and    r10d,0xc000
    74a37e50bcba:	shl    r10d,0x10
    74a37e50bcbe:	mov    r11d,edx
    74a37e50bcc1:	and    r11d,0x100
    74a37e50bcc8:	shl    r11d,0x15
    74a37e50bccc:	or     r10d,r11d
    74a37e50bccf:	and    edx,0x1
    74a37e50bcd2:	shl    edx,0x1c
    74a37e50bcd5:	or     r10d,edx
    74a37e50bcd8:	btc    r10,0x1d
    74a37e50bcdd:	mov    r11d,0xf0000000
    74a37e50bce3:	and    r11,r10
    74a37e50bce6:	movabs rsi,0xffffffff0fffffff
    74a37e50bcf0:	and    rbx,rsi
    74a37e50bcf3:	or     rbx,r11
    74a37e50bcf6:	pop    r11
    74a37e50bcf8:	pop    r10
    74a37e50bcfa:	pop    rsi
    74a37e50bcfb:	pop    rdx
    74a37e50bcfc:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50bd04:	add    rsp,0x150
    74a37e50bd0b:	mov    eax,0xc
    74a37e50bd10:	movabs r11,0x5715466e9ca0
    74a37e50bd1a:	jmp    r11
    74a37e50bd1d:	mov    eax,0x4106cc
    74a37e50bd22:	mov    QWORD PTR [r12+0x100],rax
    74a37e50bd2a:	push   rdx
    74a37e50bd2b:	push   rsi
    74a37e50bd2c:	push   r10
    74a37e50bd2e:	push   r11
    74a37e50bd30:	mov    rdx,QWORD PTR [rsp+0x20]
    74a37e50bd35:	mov    r10d,edx
    74a37e50bd38:	and    r10d,0xc000
    74a37e50bd3f:	shl    r10d,0x10
    74a37e50bd43:	mov    r11d,edx
    74a37e50bd46:	and    r11d,0x100
    74a37e50bd4d:	shl    r11d,0x15
    74a37e50bd51:	or     r10d,r11d
    74a37e50bd54:	and    edx,0x1
    74a37e50bd57:	shl    edx,0x1c
    74a37e50bd5a:	or     r10d,edx
    74a37e50bd5d:	btc    r10,0x1d
    74a37e50bd62:	mov    r11d,0xf0000000
    74a37e50bd68:	and    r11,r10
    74a37e50bd6b:	movabs rsi,0xffffffff0fffffff
    74a37e50bd75:	and    rbx,rsi
    74a37e50bd78:	or     rbx,r11
    74a37e50bd7b:	pop    r11
    74a37e50bd7d:	pop    r10
    74a37e50bd7f:	pop    rsi
    74a37e50bd80:	pop    rdx
    74a37e50bd81:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50bd89:	add    rsp,0x150
    74a37e50bd90:	mov    eax,0xc
    74a37e50bd95:	movabs r11,0x5715466e9ca0
    74a37e50bd9f:	jmp    r11
    74a37e50bda2:	mov    eax,0x4106d8
    74a37e50bda7:	mov    QWORD PTR [r12+0x100],rax
    74a37e50bdaf:	push   rdx
    74a37e50bdb0:	push   rsi
    74a37e50bdb1:	push   r10
    74a37e50bdb3:	push   r11
    74a37e50bdb5:	mov    r11,rax
    74a37e50bdb8:	lahf
    74a37e50bdb9:	seto   al
    74a37e50bdbc:	mov    WORD PTR [rsp+0x20],ax
    74a37e50bdc1:	mov    rax,r11
    74a37e50bdc4:	mov    rdx,QWORD PTR [rsp+0x20]
    74a37e50bdc9:	mov    r10d,edx
    74a37e50bdcc:	and    r10d,0xc000
    74a37e50bdd3:	shl    r10d,0x10
    74a37e50bdd7:	mov    r11d,edx
    74a37e50bdda:	and    r11d,0x100
    74a37e50bde1:	shl    r11d,0x15
    74a37e50bde5:	or     r10d,r11d
    74a37e50bde8:	and    edx,0x1
    74a37e50bdeb:	shl    edx,0x1c
    74a37e50bdee:	or     r10d,edx
    74a37e50bdf1:	btc    r10,0x1d
    74a37e50bdf6:	mov    r11d,0xf0000000
    74a37e50bdfc:	and    r11,r10
    74a37e50bdff:	movabs rsi,0xffffffff0fffffff
    74a37e50be09:	and    rbx,rsi
    74a37e50be0c:	or     rbx,r11
    74a37e50be0f:	pop    r11
    74a37e50be11:	pop    r10
    74a37e50be13:	pop    rsi
    74a37e50be14:	pop    rdx
    74a37e50be15:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50be1d:	add    rsp,0x150
    74a37e50be24:	mov    eax,0xc
    74a37e50be29:	movabs r11,0x5715466e9ca0
    74a37e50be33:	jmp    r11
    74a37e50be36:	mov    eax,0x410700
    74a37e50be3b:	mov    QWORD PTR [r12+0x100],rax
    74a37e50be43:	push   rdx
    74a37e50be44:	push   rsi
    74a37e50be45:	push   r10
    74a37e50be47:	push   r11
    74a37e50be49:	mov    r11,rax
    74a37e50be4c:	lahf
    74a37e50be4d:	seto   al
    74a37e50be50:	mov    WORD PTR [rsp+0x20],ax
    74a37e50be55:	mov    rax,r11
    74a37e50be58:	mov    rdx,QWORD PTR [rsp+0x20]
    74a37e50be5d:	mov    r10d,edx
    74a37e50be60:	and    r10d,0xc000
    74a37e50be67:	shl    r10d,0x10
    74a37e50be6b:	mov    r11d,edx
    74a37e50be6e:	and    r11d,0x100
    74a37e50be75:	shl    r11d,0x15
    74a37e50be79:	or     r10d,r11d
    74a37e50be7c:	and    edx,0x1
    74a37e50be7f:	shl    edx,0x1c
    74a37e50be82:	or     r10d,edx
    74a37e50be85:	btc    r10,0x1d
    74a37e50be8a:	mov    r11d,0xf0000000
    74a37e50be90:	and    r11,r10
    74a37e50be93:	movabs rsi,0xffffffff0fffffff
    74a37e50be9d:	and    rbx,rsi
    74a37e50bea0:	or     rbx,r11
    74a37e50bea3:	pop    r11
    74a37e50bea5:	pop    r10
    74a37e50bea7:	pop    rsi
    74a37e50bea8:	pop    rdx
    74a37e50bea9:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50beb1:	add    rsp,0x150
    74a37e50beb8:	mov    eax,0xc
    74a37e50bebd:	movabs r11,0x5715466e9ca0
    74a37e50bec7:	jmp    r11
    74a37e50beca:	mov    eax,0x410724
    74a37e50becf:	mov    QWORD PTR [r12+0x100],rax
    74a37e50bed7:	push   rdx
    74a37e50bed8:	push   rsi
    74a37e50bed9:	push   r10
    74a37e50bedb:	push   r11
    74a37e50bedd:	mov    rdx,QWORD PTR [rsp+0x20]
    74a37e50bee2:	mov    r10d,edx
    74a37e50bee5:	and    r10d,0xc000
    74a37e50beec:	shl    r10d,0x10
    74a37e50bef0:	mov    r11d,edx
    74a37e50bef3:	and    r11d,0x100
    74a37e50befa:	shl    r11d,0x15
    74a37e50befe:	or     r10d,r11d
    74a37e50bf01:	and    edx,0x1
    74a37e50bf04:	shl    edx,0x1c
    74a37e50bf07:	or     r10d,edx
    74a37e50bf0a:	btc    r10,0x1d
    74a37e50bf0f:	mov    r11d,0xf0000000
    74a37e50bf15:	and    r11,r10
    74a37e50bf18:	movabs rsi,0xffffffff0fffffff
    74a37e50bf22:	and    rbx,rsi
    74a37e50bf25:	or     rbx,r11
    74a37e50bf28:	pop    r11
    74a37e50bf2a:	pop    r10
    74a37e50bf2c:	pop    rsi
    74a37e50bf2d:	pop    rdx
    74a37e50bf2e:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50bf36:	add    rsp,0x150
    74a37e50bf3d:	mov    eax,0xc
    74a37e50bf42:	movabs r11,0x5715466e9ca0
    74a37e50bf4c:	jmp    r11
    74a37e50bf4f:	nop
    74a37e50bf50:	sub    rsp,0x150
    74a37e50bf57:	mov    r11,QWORD PTR [r12+0x398]
    74a37e50bf5f:	mov    QWORD PTR [rsp],r11
    74a37e50bf63:	cmp    DWORD PTR [r12+0x310],0x0
    74a37e50bf6c:	je     0x74a37e50bff7
    74a37e50bf72:	push   rdx
    74a37e50bf73:	push   rsi
    74a37e50bf74:	push   r10
    74a37e50bf76:	push   r11
    74a37e50bf78:	mov    rdx,QWORD PTR [rsp+0x20]
    74a37e50bf7d:	mov    r10d,edx
    74a37e50bf80:	and    r10d,0xc000
    74a37e50bf87:	shl    r10d,0x10
    74a37e50bf8b:	mov    r11d,edx
    74a37e50bf8e:	and    r11d,0x100
    74a37e50bf95:	shl    r11d,0x15
    74a37e50bf99:	or     r10d,r11d
    74a37e50bf9c:	and    edx,0x1
    74a37e50bf9f:	shl    edx,0x1c
    74a37e50bfa2:	or     r10d,edx
    74a37e50bfa5:	btc    r10,0x1d
    74a37e50bfaa:	mov    r11d,0xf0000000
    74a37e50bfb0:	and    r11,r10
    74a37e50bfb3:	movabs rsi,0xffffffff0fffffff
    74a37e50bfbd:	and    rbx,rsi
    74a37e50bfc0:	or     rbx,r11
    74a37e50bfc3:	pop    r11
    74a37e50bfc5:	pop    r10
    74a37e50bfc7:	pop    rsi
    74a37e50bfc8:	pop    rdx
    74a37e50bfc9:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50bfd1:	mov    eax,0x410404
    74a37e50bfd6:	mov    QWORD PTR [r12+0x100],rax
    74a37e50bfde:	add    rsp,0x150
    74a37e50bfe5:	mov    eax,0x3
    74a37e50bfea:	movabs r11,0x5715466e9ca0
    74a37e50bff4:	jmp    r11
    74a37e50bff7:	jmp    0x74a37e50226d
    74a37e50bffc:	nop    DWORD PTR [rax+0x0]
    74a37e50c000:	sub    rsp,0x150
    74a37e50c007:	mov    r11,QWORD PTR [r12+0x398]
    74a37e50c00f:	mov    QWORD PTR [rsp],r11
    74a37e50c013:	cmp    DWORD PTR [r12+0x310],0x0
    74a37e50c01c:	je     0x74a37e50c0a7
    74a37e50c022:	push   rdx
    74a37e50c023:	push   rsi
    74a37e50c024:	push   r10
    74a37e50c026:	push   r11
    74a37e50c028:	mov    rdx,QWORD PTR [rsp+0x20]
    74a37e50c02d:	mov    r10d,edx
    74a37e50c030:	and    r10d,0xc000
    74a37e50c037:	shl    r10d,0x10
    74a37e50c03b:	mov    r11d,edx
    74a37e50c03e:	and    r11d,0x100
    74a37e50c045:	shl    r11d,0x15
    74a37e50c049:	or     r10d,r11d
    74a37e50c04c:	and    edx,0x1
    74a37e50c04f:	shl    edx,0x1c
    74a37e50c052:	or     r10d,edx
    74a37e50c055:	btc    r10,0x1d
    74a37e50c05a:	mov    r11d,0xf0000000
    74a37e50c060:	and    r11,r10
    74a37e50c063:	movabs rsi,0xffffffff0fffffff
    74a37e50c06d:	and    rbx,rsi
    74a37e50c070:	or     rbx,r11
    74a37e50c073:	pop    r11
    74a37e50c075:	pop    r10
    74a37e50c077:	pop    rsi
    74a37e50c078:	pop    rdx
    74a37e50c079:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50c081:	mov    eax,0x410450
    74a37e50c086:	mov    QWORD PTR [r12+0x100],rax
    74a37e50c08e:	add    rsp,0x150
    74a37e50c095:	mov    eax,0x3
    74a37e50c09a:	movabs r11,0x5715466e9ca0
    74a37e50c0a4:	jmp    r11
    74a37e50c0a7:	mov    r11,rax
    74a37e50c0aa:	movzx  eax,WORD PTR [rsp]
    74a37e50c0ae:	add    al,0x7f
    74a37e50c0b0:	sahf
    74a37e50c0b1:	mov    rax,r11
    74a37e50c0b4:	jmp    0x74a37e5023dd
    74a37e50c0b9:	nop    DWORD PTR [rax+0x0]
    74a37e50c0c0:	sub    rsp,0x150
    74a37e50c0c7:	mov    r11,QWORD PTR [r12+0x398]
    74a37e50c0cf:	mov    QWORD PTR [rsp],r11
    74a37e50c0d3:	cmp    DWORD PTR [r12+0x310],0x0
    74a37e50c0dc:	je     0x74a37e50c167
    74a37e50c0e2:	push   rdx
    74a37e50c0e3:	push   rsi
    74a37e50c0e4:	push   r10
    74a37e50c0e6:	push   r11
    74a37e50c0e8:	mov    rdx,QWORD PTR [rsp+0x20]
    74a37e50c0ed:	mov    r10d,edx
    74a37e50c0f0:	and    r10d,0xc000
    74a37e50c0f7:	shl    r10d,0x10
    74a37e50c0fb:	mov    r11d,edx
    74a37e50c0fe:	and    r11d,0x100
    74a37e50c105:	shl    r11d,0x15
    74a37e50c109:	or     r10d,r11d
    74a37e50c10c:	and    edx,0x1
    74a37e50c10f:	shl    edx,0x1c
    74a37e50c112:	or     r10d,edx
    74a37e50c115:	btc    r10,0x1d
    74a37e50c11a:	mov    r11d,0xf0000000
    74a37e50c120:	and    r11,r10
    74a37e50c123:	movabs rsi,0xffffffff0fffffff
    74a37e50c12d:	and    rbx,rsi
    74a37e50c130:	or     rbx,r11
    74a37e50c133:	pop    r11
    74a37e50c135:	pop    r10
    74a37e50c137:	pop    rsi
    74a37e50c138:	pop    rdx
    74a37e50c139:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50c141:	mov    eax,0x410490
    74a37e50c146:	mov    QWORD PTR [r12+0x100],rax
    74a37e50c14e:	add    rsp,0x150
    74a37e50c155:	mov    eax,0x3
    74a37e50c15a:	movabs r11,0x5715466e9ca0
    74a37e50c164:	jmp    r11
    74a37e50c167:	jmp    0x74a37e50282b
    74a37e50c16c:	nop    DWORD PTR [rax+0x0]
    74a37e50c170:	sub    rsp,0x150
    74a37e50c177:	mov    r11,QWORD PTR [r12+0x398]
    74a37e50c17f:	mov    QWORD PTR [rsp],r11
    74a37e50c183:	cmp    DWORD PTR [r12+0x310],0x0
    74a37e50c18c:	je     0x74a37e50c217
    74a37e50c192:	push   rdx
    74a37e50c193:	push   rsi
    74a37e50c194:	push   r10
    74a37e50c196:	push   r11
    74a37e50c198:	mov    rdx,QWORD PTR [rsp+0x20]
    74a37e50c19d:	mov    r10d,edx
    74a37e50c1a0:	and    r10d,0xc000
    74a37e50c1a7:	shl    r10d,0x10
    74a37e50c1ab:	mov    r11d,edx
    74a37e50c1ae:	and    r11d,0x100
    74a37e50c1b5:	shl    r11d,0x15
    74a37e50c1b9:	or     r10d,r11d
    74a37e50c1bc:	and    edx,0x1
    74a37e50c1bf:	shl    edx,0x1c
    74a37e50c1c2:	or     r10d,edx
    74a37e50c1c5:	btc    r10,0x1d
    74a37e50c1ca:	mov    r11d,0xf0000000
    74a37e50c1d0:	and    r11,r10
    74a37e50c1d3:	movabs rsi,0xffffffff0fffffff
    74a37e50c1dd:	and    rbx,rsi
    74a37e50c1e0:	or     rbx,r11
    74a37e50c1e3:	pop    r11
    74a37e50c1e5:	pop    r10
    74a37e50c1e7:	pop    rsi
    74a37e50c1e8:	pop    rdx
    74a37e50c1e9:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50c1f1:	mov    eax,0x410500
    74a37e50c1f6:	mov    QWORD PTR [r12+0x100],rax
    74a37e50c1fe:	add    rsp,0x150
    74a37e50c205:	mov    eax,0x3
    74a37e50c20a:	movabs r11,0x5715466e9ca0
    74a37e50c214:	jmp    r11
    74a37e50c217:	mov    r11,rax
    74a37e50c21a:	movzx  eax,WORD PTR [rsp]
    74a37e50c21e:	add    al,0x7f
    74a37e50c220:	sahf
    74a37e50c221:	mov    rax,r11
    74a37e50c224:	jmp    0x74a37e502c37
    74a37e50c229:	nop    DWORD PTR [rax+0x0]
    74a37e50c230:	sub    rsp,0x150
    74a37e50c237:	mov    r11,QWORD PTR [r12+0x398]
    74a37e50c23f:	mov    QWORD PTR [rsp],r11
    74a37e50c243:	cmp    DWORD PTR [r12+0x310],0x0
    74a37e50c24c:	je     0x74a37e50c2d7
    74a37e50c252:	push   rdx
    74a37e50c253:	push   rsi
    74a37e50c254:	push   r10
    74a37e50c256:	push   r11
    74a37e50c258:	mov    rdx,QWORD PTR [rsp+0x20]
    74a37e50c25d:	mov    r10d,edx
    74a37e50c260:	and    r10d,0xc000
    74a37e50c267:	shl    r10d,0x10
    74a37e50c26b:	mov    r11d,edx
    74a37e50c26e:	and    r11d,0x100
    74a37e50c275:	shl    r11d,0x15
    74a37e50c279:	or     r10d,r11d
    74a37e50c27c:	and    edx,0x1
    74a37e50c27f:	shl    edx,0x1c
    74a37e50c282:	or     r10d,edx
    74a37e50c285:	btc    r10,0x1d
    74a37e50c28a:	mov    r11d,0xf0000000
    74a37e50c290:	and    r11,r10
    74a37e50c293:	movabs rsi,0xffffffff0fffffff
    74a37e50c29d:	and    rbx,rsi
    74a37e50c2a0:	or     rbx,r11
    74a37e50c2a3:	pop    r11
    74a37e50c2a5:	pop    r10
    74a37e50c2a7:	pop    rsi
    74a37e50c2a8:	pop    rdx
    74a37e50c2a9:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50c2b1:	mov    eax,0x410504
    74a37e50c2b6:	mov    QWORD PTR [r12+0x100],rax
    74a37e50c2be:	add    rsp,0x150
    74a37e50c2c5:	mov    eax,0x3
    74a37e50c2ca:	movabs r11,0x5715466e9ca0
    74a37e50c2d4:	jmp    r11
    74a37e50c2d7:	jmp    0x74a37e502c55
    74a37e50c2dc:	nop    DWORD PTR [rax+0x0]
    74a37e50c2e0:	sub    rsp,0x150
    74a37e50c2e7:	mov    r11,QWORD PTR [r12+0x398]
    74a37e50c2ef:	mov    QWORD PTR [rsp],r11
    74a37e50c2f3:	cmp    DWORD PTR [r12+0x310],0x0
    74a37e50c2fc:	je     0x74a37e50c387
    74a37e50c302:	push   rdx
    74a37e50c303:	push   rsi
    74a37e50c304:	push   r10
    74a37e50c306:	push   r11
    74a37e50c308:	mov    rdx,QWORD PTR [rsp+0x20]
    74a37e50c30d:	mov    r10d,edx
    74a37e50c310:	and    r10d,0xc000
    74a37e50c317:	shl    r10d,0x10
    74a37e50c31b:	mov    r11d,edx
    74a37e50c31e:	and    r11d,0x100
    74a37e50c325:	shl    r11d,0x15
    74a37e50c329:	or     r10d,r11d
    74a37e50c32c:	and    edx,0x1
    74a37e50c32f:	shl    edx,0x1c
    74a37e50c332:	or     r10d,edx
    74a37e50c335:	btc    r10,0x1d
    74a37e50c33a:	mov    r11d,0xf0000000
    74a37e50c340:	and    r11,r10
    74a37e50c343:	movabs rsi,0xffffffff0fffffff
    74a37e50c34d:	and    rbx,rsi
    74a37e50c350:	or     rbx,r11
    74a37e50c353:	pop    r11
    74a37e50c355:	pop    r10
    74a37e50c357:	pop    rsi
    74a37e50c358:	pop    rdx
    74a37e50c359:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50c361:	mov    eax,0x4106d0
    74a37e50c366:	mov    QWORD PTR [r12+0x100],rax
    74a37e50c36e:	add    rsp,0x150
    74a37e50c375:	mov    eax,0x3
    74a37e50c37a:	movabs r11,0x5715466e9ca0
    74a37e50c384:	jmp    r11
    74a37e50c387:	jmp    0x74a37e504995
    74a37e50c38c:	nop    DWORD PTR [rax+0x0]
    74a37e50c390:	sub    rsp,0x150
    74a37e50c397:	mov    r11,QWORD PTR [r12+0x398]
    74a37e50c39f:	mov    QWORD PTR [rsp],r11
    74a37e50c3a3:	cmp    DWORD PTR [r12+0x310],0x0
    74a37e50c3ac:	je     0x74a37e50c437
    74a37e50c3b2:	push   rdx
    74a37e50c3b3:	push   rsi
    74a37e50c3b4:	push   r10
    74a37e50c3b6:	push   r11
    74a37e50c3b8:	mov    rdx,QWORD PTR [rsp+0x20]
    74a37e50c3bd:	mov    r10d,edx
    74a37e50c3c0:	and    r10d,0xc000
    74a37e50c3c7:	shl    r10d,0x10
    74a37e50c3cb:	mov    r11d,edx
    74a37e50c3ce:	and    r11d,0x100
    74a37e50c3d5:	shl    r11d,0x15
    74a37e50c3d9:	or     r10d,r11d
    74a37e50c3dc:	and    edx,0x1
    74a37e50c3df:	shl    edx,0x1c
    74a37e50c3e2:	or     r10d,edx
    74a37e50c3e5:	btc    r10,0x1d
    74a37e50c3ea:	mov    r11d,0xf0000000
    74a37e50c3f0:	and    r11,r10
    74a37e50c3f3:	movabs rsi,0xffffffff0fffffff
    74a37e50c3fd:	and    rbx,rsi
    74a37e50c400:	or     rbx,r11
    74a37e50c403:	pop    r11
    74a37e50c405:	pop    r10
    74a37e50c407:	pop    rsi
    74a37e50c408:	pop    rdx
    74a37e50c409:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50c411:	mov    eax,0x4106dc
    74a37e50c416:	mov    QWORD PTR [r12+0x100],rax
    74a37e50c41e:	add    rsp,0x150
    74a37e50c425:	mov    eax,0x3
    74a37e50c42a:	movabs r11,0x5715466e9ca0
    74a37e50c434:	jmp    r11
    74a37e50c437:	jmp    0x74a37e5049d2
    74a37e50c43c:	nop    DWORD PTR [rax+0x0]
    74a37e50c440:	sub    rsp,0x150
    74a37e50c447:	mov    r11,QWORD PTR [r12+0x398]
    74a37e50c44f:	mov    QWORD PTR [rsp],r11
    74a37e50c453:	cmp    DWORD PTR [r12+0x310],0x0
    74a37e50c45c:	je     0x74a37e50c4e7
    74a37e50c462:	push   rdx
    74a37e50c463:	push   rsi
    74a37e50c464:	push   r10
    74a37e50c466:	push   r11
    74a37e50c468:	mov    rdx,QWORD PTR [rsp+0x20]
    74a37e50c46d:	mov    r10d,edx
    74a37e50c470:	and    r10d,0xc000
    74a37e50c477:	shl    r10d,0x10
    74a37e50c47b:	mov    r11d,edx
    74a37e50c47e:	and    r11d,0x100
    74a37e50c485:	shl    r11d,0x15
    74a37e50c489:	or     r10d,r11d
    74a37e50c48c:	and    edx,0x1
    74a37e50c48f:	shl    edx,0x1c
    74a37e50c492:	or     r10d,edx
    74a37e50c495:	btc    r10,0x1d
    74a37e50c49a:	mov    r11d,0xf0000000
    74a37e50c4a0:	and    r11,r10
    74a37e50c4a3:	movabs rsi,0xffffffff0fffffff
    74a37e50c4ad:	and    rbx,rsi
    74a37e50c4b0:	or     rbx,r11
    74a37e50c4b3:	pop    r11
    74a37e50c4b5:	pop    r10
    74a37e50c4b7:	pop    rsi
    74a37e50c4b8:	pop    rdx
    74a37e50c4b9:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50c4c1:	mov    eax,0x4106e8
    74a37e50c4c6:	mov    QWORD PTR [r12+0x100],rax
    74a37e50c4ce:	add    rsp,0x150
    74a37e50c4d5:	mov    eax,0x3
    74a37e50c4da:	movabs r11,0x5715466e9ca0
    74a37e50c4e4:	jmp    r11
    74a37e50c4e7:	jmp    0x74a37e504a0d
    74a37e50c4ec:	nop    DWORD PTR [rax+0x0]
    74a37e50c4f0:	sub    rsp,0x150
    74a37e50c4f7:	mov    r11,QWORD PTR [r12+0x398]
    74a37e50c4ff:	mov    QWORD PTR [rsp],r11
    74a37e50c503:	cmp    DWORD PTR [r12+0x310],0x0
    74a37e50c50c:	je     0x74a37e50c597
    74a37e50c512:	push   rdx
    74a37e50c513:	push   rsi
    74a37e50c514:	push   r10
    74a37e50c516:	push   r11
    74a37e50c518:	mov    rdx,QWORD PTR [rsp+0x20]
    74a37e50c51d:	mov    r10d,edx
    74a37e50c520:	and    r10d,0xc000
    74a37e50c527:	shl    r10d,0x10
    74a37e50c52b:	mov    r11d,edx
    74a37e50c52e:	and    r11d,0x100
    74a37e50c535:	shl    r11d,0x15
    74a37e50c539:	or     r10d,r11d
    74a37e50c53c:	and    edx,0x1
    74a37e50c53f:	shl    edx,0x1c
    74a37e50c542:	or     r10d,edx
    74a37e50c545:	btc    r10,0x1d
    74a37e50c54a:	mov    r11d,0xf0000000
    74a37e50c550:	and    r11,r10
    74a37e50c553:	movabs rsi,0xffffffff0fffffff
    74a37e50c55d:	and    rbx,rsi
    74a37e50c560:	or     rbx,r11
    74a37e50c563:	pop    r11
    74a37e50c565:	pop    r10
    74a37e50c567:	pop    rsi
    74a37e50c568:	pop    rdx
    74a37e50c569:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50c571:	mov    eax,0x410704
    74a37e50c576:	mov    QWORD PTR [r12+0x100],rax
    74a37e50c57e:	add    rsp,0x150
    74a37e50c585:	mov    eax,0x3
    74a37e50c58a:	movabs r11,0x5715466e9ca0
    74a37e50c594:	jmp    r11
    74a37e50c597:	jmp    0x74a37e504b66
    74a37e50c59c:	nop    DWORD PTR [rax+0x0]
    74a37e50c5a0:	sub    rsp,0x150
    74a37e50c5a7:	mov    r11,QWORD PTR [r12+0x398]
    74a37e50c5af:	mov    QWORD PTR [rsp],r11
    74a37e50c5b3:	cmp    DWORD PTR [r12+0x310],0x0
    74a37e50c5bc:	je     0x74a37e50c647
    74a37e50c5c2:	push   rdx
    74a37e50c5c3:	push   rsi
    74a37e50c5c4:	push   r10
    74a37e50c5c6:	push   r11
    74a37e50c5c8:	mov    rdx,QWORD PTR [rsp+0x20]
    74a37e50c5cd:	mov    r10d,edx
    74a37e50c5d0:	and    r10d,0xc000
    74a37e50c5d7:	shl    r10d,0x10
    74a37e50c5db:	mov    r11d,edx
    74a37e50c5de:	and    r11d,0x100
    74a37e50c5e5:	shl    r11d,0x15
    74a37e50c5e9:	or     r10d,r11d
    74a37e50c5ec:	and    edx,0x1
    74a37e50c5ef:	shl    edx,0x1c
    74a37e50c5f2:	or     r10d,edx
    74a37e50c5f5:	btc    r10,0x1d
    74a37e50c5fa:	mov    r11d,0xf0000000
    74a37e50c600:	and    r11,r10
    74a37e50c603:	movabs rsi,0xffffffff0fffffff
    74a37e50c60d:	and    rbx,rsi
    74a37e50c610:	or     rbx,r11
    74a37e50c613:	pop    r11
    74a37e50c615:	pop    r10
    74a37e50c617:	pop    rsi
    74a37e50c618:	pop    rdx
    74a37e50c619:	mov    QWORD PTR [r12+0x108],rbx
    74a37e50c621:	mov    eax,0x4103f0
    74a37e50c626:	mov    QWORD PTR [r12+0x100],rax
    74a37e50c62e:	add    rsp,0x150
    74a37e50c635:	mov    eax,0x3
    74a37e50c63a:	movabs r11,0x5715466e9ca0
    74a37e50c644:	jmp    r11
    74a37e50c647:	jmp    0x74a37e504d43
    74a37e50c64c:	nop    DWORD PTR [rax+0x0]
    74a37e50c650:	(bad)
    74a37e50c651:	(bad)
    74a37e50c652:	(bad)
    74a37e50c653:	(bad)
    74a37e50c654:	(bad)
    74a37e50c655:	(bad)
    74a37e50c656:	(bad)
    74a37e50c657:	jg     0x74a37e50c658
    74a37e50c659:	(bad)
    74a37e50c65a:	(bad)
    74a37e50c65b:	(bad)
    74a37e50c65c:	(bad)
    74a37e50c65d:	(bad)
    74a37e50c65e:	(bad)
    74a37e50c65f:	jg     0x74a37e50c661
    74a37e50c661:	add    BYTE PTR [rax],al
    74a37e50c663:	add    BYTE PTR [rax],al
    74a37e50c665:	add    BYTE PTR [rax],dl
    74a37e50c667:	add    BYTE PTR [rax],al
    74a37e50c669:	add    BYTE PTR [rax],al
    74a37e50c66b:	add    BYTE PTR [rax],al
    74a37e50c66d:	add    BYTE PTR [rax],dl
	...
